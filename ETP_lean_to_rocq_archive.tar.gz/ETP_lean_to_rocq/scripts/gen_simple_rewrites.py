#!/usr/bin/env python3
"""Generate Rocq proofs for SimpleRewrite implications.

Parses Lean4 SimpleRewrite theorems of the form:
  theorem EqA_implies_EqB (G : Type*) [Magma G] (h : EqA G) : EqB G :=
    λ x y z w => h x y z w w

and generates Rocq equivalents:
  Theorem EqA_implies_EqB (G : Type) `{Magma G} (h : EqA G) : EqB G.
  Proof. intros x y z w. exact (h x y z w w). Qed.
"""

import re
import os
from pathlib import Path

LEAN_DIR = Path("/home/azureuser/ETP_lean_reference/equational_theories/Generated/SimpleRewrites/theorems")
OUT_DIR = Path("/home/azureuser/ETP_lean_to_rocq/theories/Generated/SimpleRewrites")

# Parse a SimpleRewrite theorem
# Pattern: theorem Name (G : Type*) [Magma G] (h : EqA G) : EqB G := λ vars => h args
THEOREM_RE = re.compile(
    r'theorem\s+(Equation\d+_implies_Equation\d+)\s+'
    r'\(G\s*:\s*Type\*?\)\s*\[Magma\s+G\]\s*'
    r'\(h\s*:\s*(Equation\d+)\s+G\)\s*:\s*(Equation\d+)\s+G\s*:=\s*'
    r'(?:λ|fun)\s+([^=]+?)\s*(?:=>|⇒)\s*h\s+(.*?)$'
)


def parse_lean_file(filepath):
    """Parse a Lean4 SimpleRewrite file and extract theorem info."""
    theorems = []
    with open(filepath, 'r') as f:
        for line in f:
            line = line.strip()
            m = THEOREM_RE.match(line)
            if m:
                name = m.group(1)
                src_eq = m.group(2)
                tgt_eq = m.group(3)
                lambda_vars = m.group(4).strip().split()
                h_args = m.group(5).strip().split()
                theorems.append({
                    'name': name,
                    'src': src_eq,
                    'tgt': tgt_eq,
                    'vars': lambda_vars,
                    'args': h_args,
                })
    return theorems


def gen_rocq_theorem(thm):
    """Generate a Rocq theorem string."""
    name = thm['name']
    src = thm['src']
    tgt = thm['tgt']
    vars_ = thm['vars']
    args = thm['args']

    var_str = " ".join(vars_)
    arg_str = " ".join(args)

    return (
        f"Theorem {name}\n"
        f"  (G : Type) `{{Magma G}} (h : {src} G) : {tgt} G.\n"
        f"Proof. intros {var_str}. exact (h {arg_str}). Qed.\n"
    )


def main():
    OUT_DIR.mkdir(parents=True, exist_ok=True)

    all_files = sorted(LEAN_DIR.glob("*.lean"))
    total_thms = 0
    rocq_files = []

    for lean_file in all_files:
        theorems = parse_lean_file(lean_file)
        if not theorems:
            continue

        basename = lean_file.stem
        outpath = OUT_DIR / f"{basename}.v"
        rocq_files.append(basename)

        with open(outpath, 'w') as f:
            f.write(f"(** * SimpleRewrites/{basename}\n\n")
            f.write(f"    Auto-generated from Lean4 SimpleRewrites. *)\n\n")
            f.write("From Stdlib Require Import Utf8.\n\n")
            f.write("From ETP Require Import Magma.\n")
            f.write("From ETP.Equations Require Import All.\n\n")
            f.write("Open Scope magma_scope.\n\n")

            for thm in theorems:
                f.write(gen_rocq_theorem(thm))
                f.write("\n")
                total_thms += 1

        print(f"  {outpath.name}: {len(theorems)} theorems", file=os.sys.stderr)

    # Write All.v
    allpath = OUT_DIR / "All.v"
    with open(allpath, 'w') as f:
        f.write("(** * All SimpleRewrites — re-exports all SimpleRewrite files *)\n\n")
        for name in rocq_files:
            f.write(f"From ETP.Generated.SimpleRewrites Require Export {name}.\n")

    print(f"\nTotal: {total_thms} theorems across {len(rocq_files)} files", file=os.sys.stderr)
    print(f"Wrote {allpath}", file=os.sys.stderr)


if __name__ == "__main__":
    main()
