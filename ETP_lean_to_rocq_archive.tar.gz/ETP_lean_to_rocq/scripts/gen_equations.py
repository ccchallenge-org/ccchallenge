#!/usr/bin/env python3
"""Generate Rocq equation definitions from Lean4 source files.

Parses all `equation N := expr` and `-- equation N := expr` lines from
the Lean4 Equations/*.lean files and produces Rocq Definition statements.
"""

import re
import sys
import os
from pathlib import Path

LEAN_DIR = Path("/home/azureuser/ETP_lean_reference/equational_theories/Equations")

# Files to parse (in order)
EQUATION_FILES = [
    "Basic.lean",
    "Eqns1_999.lean",
    "Eqns1000_1999.lean",
    "Eqns2000_2999.lean",
    "Eqns3000_3999.lean",
    "Eqns4000_4694.lean",
]

# Regex to match equation definitions (both active and commented out)
EQ_RE = re.compile(r'^(?:--|)\s*equation\s+(\d+)\s*:=\s*(.+?)\s*$')


def parse_lean_expr(expr_str: str):
    """Parse a Lean4 magma expression into a Rocq expression string.

    Variables: x, y, z, w (and potentially others)
    Operation: ◇ (infix, left-associative in Lean4)

    Returns: (rocq_expr, set_of_variables)
    """
    # Tokenize
    tokens = tokenize(expr_str)
    # Parse
    ast, rest = parse_eq(tokens)
    if rest:
        raise ValueError(f"Unparsed tokens: {rest} in '{expr_str}'")
    return ast


def tokenize(s):
    """Tokenize a Lean4 magma expression."""
    tokens = []
    i = 0
    while i < len(s):
        c = s[i]
        if c in ' \t':
            i += 1
        elif c == '(':
            tokens.append('(')
            i += 1
        elif c == ')':
            tokens.append(')')
            i += 1
        elif c == '=':
            tokens.append('=')
            i += 1
        elif c == '◇' or (i + 2 < len(s) and s[i:i+3] == '◇'):
            # ◇ is a multi-byte UTF-8 character
            # Find the ◇ character
            if s[i] == '◇':
                tokens.append('◇')
                i += 1
            else:
                tokens.append('◇')
                i += 3
        elif c.isalpha() or c == '_':
            j = i
            while j < len(s) and (s[j].isalnum() or s[j] == '_'):
                j += 1
            tokens.append(s[i:j])
            i = j
        else:
            # Try multi-byte ◇
            if ord(c) > 127:
                # Could be ◇ (U+25C7, encoded as 3 bytes in UTF-8)
                tokens.append(c)
                i += 1
            else:
                raise ValueError(f"Unexpected character '{c}' (ord {ord(c)}) in '{s}'")
    return tokens


def parse_eq(tokens):
    """Parse: expr = expr"""
    lhs, rest = parse_expr(tokens)
    if not rest or rest[0] != '=':
        raise ValueError(f"Expected '=' but got {rest}")
    rhs, rest = parse_expr(rest[1:])
    return (lhs, rhs), rest


def parse_expr(tokens):
    """Parse a magma expression with ◇ as left-associative infix operator."""
    left, rest = parse_atom(tokens)
    while rest and rest[0] == '◇':
        right, rest = parse_atom(rest[1:])
        left = ('op', left, right)
    return left, rest


def parse_atom(tokens):
    """Parse an atom: variable or parenthesized expression."""
    if not tokens:
        raise ValueError("Unexpected end of input")
    if tokens[0] == '(':
        expr, rest = parse_expr(tokens[1:])
        if not rest or rest[0] != ')':
            raise ValueError(f"Expected ')' but got {rest}")
        return expr, rest[1:]
    elif tokens[0] not in ('=', '◇', '(', ')'):
        return ('var', tokens[0]), tokens[1:]
    else:
        raise ValueError(f"Unexpected token '{tokens[0]}'")


def collect_vars(ast):
    """Collect all variable names from an AST, in order of first appearance."""
    seen = set()
    result = []
    def walk(node):
        if node[0] == 'var':
            if node[1] not in seen:
                seen.add(node[1])
                result.append(node[1])
        elif node[0] == 'op':
            walk(node[1])
            walk(node[2])
    walk(ast)
    return result


def ast_to_rocq(ast):
    """Convert an AST to a Rocq expression string."""
    if ast[0] == 'var':
        return ast[1]
    elif ast[0] == 'op':
        l = ast_to_rocq(ast[1])
        r = ast_to_rocq(ast[2])
        # Add parens if child is an op (since ◇ is already left-assoc,
        # we need parens for right-nesting)
        if ast[1][0] == 'op':
            l = f"({l})"
        if ast[2][0] == 'op':
            r = f"({r})"
        return f"{l} ◇ {r}"
    raise ValueError(f"Unknown AST node: {ast}")


def generate_definition(num, expr_str):
    """Generate a Rocq Definition for an equation."""
    try:
        (lhs_ast, rhs_ast), _ = parse_eq(tokenize(expr_str))
    except ValueError as e:
        print(f"  (* Skipping Equation{num}: parse error: {e} *)", file=sys.stderr)
        return None

    # Collect all variables (from both sides, in order of first appearance)
    all_vars = []
    seen = set()
    for v in collect_vars(lhs_ast) + collect_vars(rhs_ast):
        if v not in seen:
            seen.add(v)
            all_vars.append(v)

    lhs_rocq = ast_to_rocq(lhs_ast)
    rhs_rocq = ast_to_rocq(rhs_ast)

    # Build quantifier
    if len(all_vars) == 0:
        quant = ""
        body = f"{lhs_rocq} = {rhs_rocq}"
    elif len(all_vars) == 1:
        quant = f"forall {all_vars[0]} : G, "
        body = f"{lhs_rocq} = {rhs_rocq}"
    else:
        var_list = " ".join(all_vars)
        quant = f"forall {var_list} : G, "
        body = f"{lhs_rocq} = {rhs_rocq}"

    return f"Definition Equation{num} (G : Type) `{{Magma G}} : Prop :=\n  {quant}{body}.\n"


def parse_all_equations():
    """Parse all equation definitions from Lean4 source files."""
    equations = {}  # num -> expr_str

    for filename in EQUATION_FILES:
        filepath = LEAN_DIR / filename
        if not filepath.exists():
            print(f"Warning: {filepath} not found", file=sys.stderr)
            continue

        with open(filepath, 'r') as f:
            for line in f:
                m = EQ_RE.match(line.strip())
                if m:
                    num = int(m.group(1))
                    expr = m.group(2)
                    if num not in equations:
                        equations[num] = expr

    return equations


def main():
    equations = parse_all_equations()
    print(f"Parsed {len(equations)} equations", file=sys.stderr)

    # Sort by equation number
    sorted_nums = sorted(equations.keys())

    # Generate output
    header = """(** * AllEquations — all 4694 equational laws for magmas

    Auto-generated from the Lean4 Equational Theories Project.
    Each [EquationN] is a [Prop] asserting that a magma [(G, ◇)] satisfies
    a particular universally quantified identity. *)

From Stdlib Require Import Utf8.

From ETP Require Import Magma.

Open Scope magma_scope.

"""

    # Split into multiple files for compilation speed
    files = {}
    for num in sorted_nums:
        if num <= 999:
            key = "Eqns1_999"
        elif num <= 1999:
            key = "Eqns1000_1999"
        elif num <= 2999:
            key = "Eqns2000_2999"
        elif num <= 3999:
            key = "Eqns3000_3999"
        else:
            key = "Eqns4000_4694"

        if key not in files:
            files[key] = []
        files[key].append(num)

    out_dir = Path("/home/azureuser/ETP_lean_to_rocq/theories/Equations")
    out_dir.mkdir(exist_ok=True)

    for key, nums in files.items():
        outpath = out_dir / f"{key}.v"
        with open(outpath, 'w') as f:
            lo = min(nums)
            hi = max(nums)
            f.write(f"(** * Equations {lo}–{hi}\n\n")
            f.write(f"    Auto-generated from the Lean4 Equational Theories Project. *)\n\n")
            f.write("From Stdlib Require Import Utf8.\n\n")
            f.write("From ETP Require Import Magma.\n\n")
            f.write("Open Scope magma_scope.\n\n")

            for num in nums:
                defn = generate_definition(num, equations[num])
                if defn:
                    f.write(defn)
                    f.write("\n")

        print(f"Wrote {outpath} ({len(nums)} equations)", file=sys.stderr)

    # Write the All.v file that imports everything
    allpath = out_dir / "All.v"
    with open(allpath, 'w') as f:
        f.write("(** * All Equations — re-exports all equation files *)\n\n")
        for key in sorted(files.keys()):
            f.write(f"From ETP.Equations Require Export {key}.\n")

    print(f"Wrote {allpath}", file=sys.stderr)
    print(f"Total: {len(sorted_nums)} equations across {len(files)} files", file=sys.stderr)


if __name__ == "__main__":
    main()
