#!/usr/bin/env python3
"""Generate Rocq proofs for Equation1 implications.

Parses Lean4 Generated/Equation1.lean and generates Rocq equivalents.
All proofs are `intro x. reflexivity.`
"""

import re
from pathlib import Path

LEAN_FILE = Path("/home/azureuser/ETP_lean_reference/equational_theories/Generated/Equation1.lean")
OUT_FILE = Path("/home/azureuser/ETP_lean_to_rocq/theories/Generated/Equation1.v")

THEOREM_RE = re.compile(
    r'theorem\s+(Equation\d+_implies_Equation1)\s+'
    r'\(G:\s*Type\s*_\)\s*\[Magma\s+G\]\s*'
    r'\(h:\s*(Equation\d+)\s+G\)\s*:\s*Equation1\s+G'
)


def main():
    theorems = []
    with open(LEAN_FILE, 'r') as f:
        for line in f:
            m = THEOREM_RE.search(line)
            if m:
                theorems.append((m.group(1), m.group(2)))

    with open(OUT_FILE, 'w') as f:
        f.write("(** * Equation1 — every equation implies Equation 1 (x = x)\n\n")
        f.write("    Auto-generated from Lean4 Generated/Equation1.lean. *)\n\n")
        f.write("From Stdlib Require Import Utf8.\n\n")
        f.write("From ETP Require Import Magma.\n")
        f.write("From ETP.Equations Require Import All.\n\n")
        f.write("Open Scope magma_scope.\n\n")

        for name, src in theorems:
            f.write(f"Theorem {name}\n")
            f.write(f"  (G : Type) `{{Magma G}} (h : {src} G) : Equation1 G.\n")
            f.write(f"Proof. intro x. reflexivity. Qed.\n\n")

    print(f"Generated {len(theorems)} theorems to {OUT_FILE}")


if __name__ == "__main__":
    main()
