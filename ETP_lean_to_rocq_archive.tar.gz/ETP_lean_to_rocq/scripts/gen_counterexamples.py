#!/usr/bin/env python3
"""Generate Rocq counterexample proofs from Lean4 All4x4Tables and FinitePoly files.

Parses Lean4 counterexample files, evaluates magma operations in Python,
and generates Rocq proofs for each satisfied/refuted equation.
"""

import re
import json
import sys
import itertools
from pathlib import Path

# Paths
LEAN_DIR = Path("/home/azureuser/ETP_lean_reference/equational_theories")
ALL4X4_DIR = LEAN_DIR / "Generated" / "All4x4Tables"
FINITEPOLY_DIR = LEAN_DIR / "Generated" / "FinitePoly"
ROCQ_EQ_DIR = Path("/home/azureuser/ETP_lean_to_rocq/theories/Equations")
OUT_DIR = Path("/home/azureuser/ETP_lean_to_rocq/theories/Generated")


# =========================================================================
# Expression AST and evaluation
# =========================================================================

class Var:
    __slots__ = ('name',)
    def __init__(self, name):
        self.name = name

class Op:
    __slots__ = ('left', 'right')
    def __init__(self, left, right):
        self.left = left
        self.right = right


def tokenize_expr(s):
    """Tokenize a magma expression string."""
    tokens = []
    i = 0
    while i < len(s):
        c = s[i]
        if c.isspace():
            i += 1
        elif c in '()':
            tokens.append(c)
            i += 1
        elif c == '\u25c7':  # ◇
            tokens.append('◇')
            i += 1
        elif c.isalpha() or c == '_':
            j = i
            while j < len(s) and (s[j].isalnum() or s[j] == '_'):
                j += 1
            tokens.append(s[i:j])
            i = j
        else:
            i += 1
    return tokens


def parse_expr(tokens, pos):
    """Parse expression: expr = term ('◇' term)*"""
    left, pos = parse_term(tokens, pos)
    while pos < len(tokens) and tokens[pos] == '◇':
        pos += 1  # skip ◇
        right, pos = parse_term(tokens, pos)
        left = Op(left, right)
    return left, pos


def parse_term(tokens, pos):
    """Parse term: IDENT | '(' expr ')'"""
    if tokens[pos] == '(':
        pos += 1  # skip (
        expr, pos = parse_expr(tokens, pos)
        assert tokens[pos] == ')', f"Expected ) at pos {pos}, got {tokens[pos]}"
        pos += 1  # skip )
        return expr, pos
    else:
        return Var(tokens[pos]), pos + 1


def eval_expr(expr, env, op_table):
    """Evaluate expression given variable bindings and operation table."""
    if isinstance(expr, Var):
        return env[expr.name]
    else:
        l = eval_expr(expr.left, env, op_table)
        r = eval_expr(expr.right, env, op_table)
        return op_table[l][r]


# =========================================================================
# Equation parsing
# =========================================================================

EQ_DEF_RE = re.compile(
    r'Definition\s+Equation(\d+)\s+\(G\s*:\s*Type\)\s*`\{Magma\s+G\}\s*:\s*Prop\s*:=\s*\n\s*forall\s+([\w\s]+?)\s*:\s*G\s*,\s*(.*?)\s*\.',
    re.DOTALL
)

def load_equations(eq_dir):
    """Load all equation definitions from Rocq files."""
    equations = {}
    for vfile in sorted(eq_dir.glob("Eqns*.v")):
        content = vfile.read_text()
        for m in EQ_DEF_RE.finditer(content):
            num = int(m.group(1))
            var_str = m.group(2).strip()
            body = m.group(3).strip()

            var_names = var_str.split()

            # Split on top-level = (not inside parens)
            eq_parts = split_equation(body)
            if eq_parts is None:
                continue
            lhs_str, rhs_str = eq_parts

            try:
                lhs_tokens = tokenize_expr(lhs_str)
                rhs_tokens = tokenize_expr(rhs_str)
                lhs_ast, _ = parse_expr(lhs_tokens, 0)
                rhs_ast, _ = parse_expr(rhs_tokens, 0)
                equations[num] = (var_names, lhs_ast, rhs_ast)
            except Exception:
                continue
    return equations


def split_equation(body):
    """Split 'LHS = RHS' at the top-level = sign."""
    depth = 0
    for i, c in enumerate(body):
        if c == '(':
            depth += 1
        elif c == ')':
            depth -= 1
        elif c == '=' and depth == 0:
            return body[:i].strip(), body[i+1:].strip()
    return None


# =========================================================================
# Lean4 file parsing
# =========================================================================

def parse_all4x4_file(filepath):
    """Parse Lean4 All4x4Tables file -> (table, n, sat_list, ref_list)"""
    content = filepath.read_text()

    table_m = re.search(r'finOpTable\s+"(\[\[.*?\]\])"', content)
    if not table_m:
        return None
    table = json.loads(table_m.group(1))
    n = len(table)

    facts_m = re.search(r'Facts\s+G\s+\[([\d,\s]*)\]\s+\[([\d,\s]*)\]', content)
    if not facts_m:
        return None
    sat_list = [int(x.strip()) for x in facts_m.group(1).split(',') if x.strip()]
    ref_list = [int(x.strip()) for x in facts_m.group(2).split(',') if x.strip()]

    return table, n, sat_list, ref_list


def parse_finitepoly_file(filepath):
    """Parse Lean4 FinitePoly file -> (table, n, sat_list, ref_list)"""
    content = filepath.read_text()

    poly_m = re.search(r'memoFinOp\s+fun\s+x\s+y\s+=>\s+(.*)', content)
    if not poly_m:
        return None
    poly_expr = poly_m.group(1).strip()

    fin_m = re.search(r'Magma\s+\(Fin\s+(\d+)\)', content)
    if not fin_m:
        return None
    n = int(fin_m.group(1))

    table = build_poly_table(poly_expr, n)
    if table is None:
        return None

    facts_m = re.search(r'Facts\s+G\s+\[([\d,\s]*)\]\s+\[([\d,\s]*)\]', content)
    if not facts_m:
        return None
    sat_list = [int(x.strip()) for x in facts_m.group(1).split(',') if x.strip()]
    ref_list = [int(x.strip()) for x in facts_m.group(2).split(',') if x.strip()]

    return table, n, sat_list, ref_list


def build_poly_table(poly_expr, n):
    """Evaluate a Lean4 polynomial expression to build operation table."""
    # Lean4 uses natural number arithmetic on Fin n, which wraps mod n
    # Expressions like: x + 2 * y, x * x + x * y + y, etc.
    safe_globals = {"__builtins__": {}}
    try:
        table = []
        for x_val in range(n):
            row = []
            for y_val in range(n):
                result = eval(poly_expr, safe_globals, {"x": x_val, "y": y_val})
                row.append(int(result) % n)
            table.append(row)
        return table
    except Exception as e:
        print(f"    poly eval error: {e}: {poly_expr!r}", file=sys.stderr)
        return None


# =========================================================================
# Counterexample finding
# =========================================================================

def find_counterexample(eq_info, op_table, n):
    """Find variable values where equation fails."""
    var_names, lhs, rhs = eq_info
    n_vars = len(var_names)

    for vals in itertools.product(range(n), repeat=n_vars):
        env = dict(zip(var_names, vals))
        try:
            lhs_val = eval_expr(lhs, env, op_table)
            rhs_val = eval_expr(rhs, env, op_table)
            if lhs_val != rhs_val:
                return vals
        except Exception:
            continue
    return None


def verify_sat(eq_info, op_table, n):
    """Verify that equation is satisfied on all inputs."""
    var_names, lhs, rhs = eq_info
    n_vars = len(var_names)

    for vals in itertools.product(range(n), repeat=n_vars):
        env = dict(zip(var_names, vals))
        try:
            lhs_val = eval_expr(lhs, env, op_table)
            rhs_val = eval_expr(rhs, env, op_table)
            if lhs_val != rhs_val:
                return False
        except Exception:
            return False
    return True


# =========================================================================
# Rocq code generation
# =========================================================================

def fin_con(n, val):
    """Get constructor name: F7_3 for n=7, val=3."""
    return f"F{n}_{val}"


def gen_op_def(ref_name, table, n):
    """Generate Rocq operation definition."""
    lines = [f"Definition {ref_name}_op (x y : Fin{n}) : Fin{n} :="]
    lines.append("  match x, y with")
    for i in range(n):
        parts = []
        for j in range(n):
            parts.append(f"| {fin_con(n,i)}, {fin_con(n,j)} => {fin_con(n,table[i][j])}")
        lines.append("  " + " ".join(parts))
    lines.append("  end.")
    return "\n".join(lines)


def gen_magma_instance(ref_name, n):
    return f"#[local] Instance {ref_name}_inst : Magma Fin{n} := {{| magma_op := {ref_name}_op |}}."


def gen_sat_lemma(ref_name, eq_num, var_names, n):
    """Generate positive (satisfaction) proof."""
    var_str = " ".join(var_names)
    destruct_str = ", ".join(var_names)
    n_vars = len(var_names)
    return (
        f"Lemma {ref_name}_sat{eq_num} : @Equation{eq_num} Fin{n} {ref_name}_inst.\n"
        f"Proof. unfold Equation{eq_num}, magma_op, {ref_name}_inst, {ref_name}_op. "
        f"intros {var_str}. destruct {destruct_str}; reflexivity. Qed."
    )


def gen_ref_lemma(ref_name, eq_num, counterex, var_names, n):
    """Generate negative (refutation) proof."""
    args = " ".join(fin_con(n, v) for v in counterex)
    return (
        f"Lemma {ref_name}_not{eq_num} : ~ @Equation{eq_num} Fin{n} {ref_name}_inst.\n"
        f"Proof. unfold Equation{eq_num}. intro H. "
        f"specialize (H {args}). "
        f"unfold magma_op, {ref_name}_inst, {ref_name}_op in H. discriminate H. Qed."
    )


def gen_rocq_file(results_list, source_type, batch_num):
    """Generate a single Rocq file for a batch of refutations."""
    prefix = "All4x4" if source_type == 'all4x4' else "FinitePoly"
    lines = []
    lines.append(f"(** * {prefix} counterexamples — batch {batch_num}")
    lines.append(f"    Auto-generated from Lean4 {prefix} files. *)")
    lines.append("")
    lines.append("From Stdlib Require Import Utf8.")
    lines.append("")
    lines.append("From ETP Require Import Magma.")
    lines.append("From ETP Require Import FinMagma.")
    lines.append("From ETP.Equations Require Import All.")
    lines.append("")
    lines.append("Open Scope magma_scope.")
    lines.append("")

    for results in results_list:
        ref_name = results['ref_name']
        table = results['table']
        n = results['n']

        lines.append(f"(** ---- {ref_name} (Fin{n}) ---- *)")
        lines.append("")
        lines.append(gen_op_def(ref_name, table, n))
        lines.append("")
        lines.append(gen_magma_instance(ref_name, n))
        lines.append("")

        for eq_num, var_names in results['sat']:
            lines.append(gen_sat_lemma(ref_name, eq_num, var_names, n))
            lines.append("")

        for eq_num, var_names, counterex in results['ref']:
            lines.append(gen_ref_lemma(ref_name, eq_num, counterex, var_names, n))
            lines.append("")

    return "\n".join(lines)


# =========================================================================
# Main
# =========================================================================

def process_refutation(filepath, equations, source_type, max_fin=13):
    """Process one Lean4 refutation file."""
    if source_type == 'all4x4':
        parsed = parse_all4x4_file(filepath)
    else:
        parsed = parse_finitepoly_file(filepath)

    if parsed is None:
        return None

    table, n, sat_list, ref_list = parsed
    if n > max_fin:
        return None
    # Extract number from filename: Refutation123 -> 123
    num_str = filepath.stem.replace('Refutation', '')
    ref_name = f"ref{source_type[0]}{num_str}"  # refa0, refp14, etc.

    results = {
        'ref_name': ref_name,
        'table': table,
        'n': n,
        'sat': [],
        'ref': [],
        'skipped_sat': 0,
        'skipped_ref': 0,
    }

    for eq_num in sat_list:
        if eq_num not in equations:
            results['skipped_sat'] += 1
            continue
        eq_info = equations[eq_num]
        var_names = eq_info[0]
        if verify_sat(eq_info, table, n):
            results['sat'].append((eq_num, var_names))
        else:
            results['skipped_sat'] += 1

    for eq_num in ref_list:
        if eq_num not in equations:
            results['skipped_ref'] += 1
            continue
        eq_info = equations[eq_num]
        var_names = eq_info[0]
        counterex = find_counterexample(eq_info, table, n)
        if counterex:
            results['ref'].append((eq_num, var_names, counterex))
        else:
            results['skipped_ref'] += 1

    return results


def process_source(source_type, lean_dir, equations, batch_size, limit=0, max_fin=13):
    """Process all files from one source (All4x4Tables or FinitePoly)."""
    lean_files = sorted(lean_dir.glob("Refutation*.lean"))
    if limit > 0:
        lean_files = lean_files[:limit]
    prefix = "All4x4Tables" if source_type == 'all4x4' else "FinitePoly"
    out_dir = OUT_DIR / prefix
    out_dir.mkdir(parents=True, exist_ok=True)

    print(f"\nProcessing {len(lean_files)} {prefix} files...", file=sys.stderr)

    total_sat = 0
    total_ref = 0
    total_skipped = 0

    batch = []
    batch_num = 0
    rocq_files = []

    for i, lean_file in enumerate(lean_files):
        results = process_refutation(lean_file, equations, source_type, max_fin)
        if results is None:
            print(f"  SKIP {lean_file.name}: parse error or Fin too large", file=sys.stderr)
            continue

        batch.append(results)
        total_sat += len(results['sat'])
        total_ref += len(results['ref'])
        total_skipped += results['skipped_sat'] + results['skipped_ref']

        if len(batch) >= batch_size or i == len(lean_files) - 1:
            batch_num += 1
            fname = f"Batch{batch_num:03d}"
            rocq_content = gen_rocq_file(batch, source_type, batch_num)
            outpath = out_dir / f"{fname}.v"
            outpath.write_text(rocq_content)
            rocq_files.append(fname)

            n_sat = sum(len(r['sat']) for r in batch)
            n_ref = sum(len(r['ref']) for r in batch)
            print(f"  {fname}.v: {len(batch)} refutations, {n_sat} sat, {n_ref} ref", file=sys.stderr)
            batch = []

    # Write All.v
    if rocq_files:
        allpath = out_dir / "All.v"
        with open(allpath, 'w') as f:
            f.write(f"(** * All {prefix} counterexamples *)\n\n")
            for name in rocq_files:
                f.write(f"From ETP.Generated.{prefix} Require Export {name}.\n")

    print(f"\n{prefix} total: {total_sat} sat, {total_ref} ref, {total_skipped} skipped", file=sys.stderr)
    return rocq_files


def main():
    import argparse
    parser = argparse.ArgumentParser(description='Generate Rocq counterexample proofs')
    parser.add_argument('--batch-size', type=int, default=20,
                       help='Refutations per .v file (default: 20)')
    parser.add_argument('--limit', type=int, default=0,
                       help='Max files to process per source (0=all)')
    parser.add_argument('--source', choices=['all', 'all4x4', 'finitepoly'], default='all',
                       help='Which source to process')
    parser.add_argument('--max-fin', type=int, default=13,
                       help='Max Fin size to support (default: 13)')
    args = parser.parse_args()

    print("Loading equations...", file=sys.stderr)
    equations = load_equations(ROCQ_EQ_DIR)
    print(f"  Loaded {len(equations)} equations", file=sys.stderr)

    all_rocq_files = {}

    if args.source in ('all', 'all4x4'):
        all_rocq_files['all4x4'] = process_source(
            'all4x4', ALL4X4_DIR, equations, args.batch_size, args.limit, args.max_fin)

    if args.source in ('all', 'finitepoly'):
        all_rocq_files['finitepoly'] = process_source(
            'finitepoly', FINITEPOLY_DIR, equations, args.batch_size, args.limit, args.max_fin)

    # Print _CoqProject entries
    print("\n# Add to _CoqProject:", file=sys.stderr)
    if 'all4x4' in all_rocq_files:
        for f in all_rocq_files['all4x4']:
            print(f"  theories/Generated/All4x4Tables/{f}.v", file=sys.stderr)
        print(f"  theories/Generated/All4x4Tables/All.v", file=sys.stderr)
    if 'finitepoly' in all_rocq_files:
        for f in all_rocq_files['finitepoly']:
            print(f"  theories/Generated/FinitePoly/{f}.v", file=sys.stderr)
        print(f"  theories/Generated/FinitePoly/All.v", file=sys.stderr)


if __name__ == "__main__":
    main()
