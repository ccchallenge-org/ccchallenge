#!/usr/bin/env python3
"""Generate Rocq proofs for TrivialBruteforce implications.

Parses Lean4 TrivialBruteforce/theorems/ files and generates Rocq equivalents.
"""

import re
import os
from pathlib import Path

LEAN_DIR = Path("/home/azureuser/ETP_lean_reference/equational_theories/Generated/TrivialBruteforce/theorems")
OUT_DIR = Path("/home/azureuser/ETP_lean_to_rocq/theories/Generated/TrivialBruteforce")

# Patterns for different proof styles
APPLY_RE = re.compile(
    r'theorem\s+(Equation\d+_implies_Equation\d+)\s+'
    r'\(G:\s*Type\s*_\)\s*\[Magma\s+G\]\s*'
    r'\(h:\s*(Equation\d+)\s+G\)\s*:\s*(Equation\d+)\s+G\s*:=\s*by\s*$'
)

PROOF_LINE_RE = re.compile(r'^\s+(repeat intro|apply h|exact h|rfl|simp_all|simp \[.*\]|rw \[.*\]|rewrite \[.*\]|exact .*|have .*|conv.*|symm|congr|funext|assumption|ring.*)')


def parse_lean_file(filepath):
    """Parse a Lean4 TrivialBruteforce file and extract theorem info."""
    theorems = []
    with open(filepath, 'r') as f:
        lines = f.readlines()

    i = 0
    while i < len(lines):
        line = lines[i].strip()

        # Skip @[equational_result]
        if line == '@[equational_result]':
            i += 1
            continue

        m = APPLY_RE.match(line)
        if m:
            name = m.group(1)
            src_eq = m.group(2)
            tgt_eq = m.group(3)
            # Collect proof lines
            proof_lines = []
            i += 1
            while i < len(lines):
                pline = lines[i].rstrip()
                if pline.strip() == '' or pline.startswith('@[') or (APPLY_RE.match(pline.strip())):
                    break
                proof_lines.append(pline.strip())
                i += 1
            theorems.append({
                'name': name,
                'src': src_eq,
                'tgt': tgt_eq,
                'lean_proof': proof_lines,
            })
            continue
        i += 1
    return theorems


def lean_to_rocq_proof(proof_lines):
    """Convert Lean4 proof steps to Rocq tactic script."""
    tactics = []
    for line in proof_lines:
        if line == 'repeat intro':
            tactics.append('repeat intro x')
        elif line == 'apply h':
            tactics.append('apply h')
        elif line == 'exact h':
            tactics.append('exact h')
        elif line == 'rfl':
            tactics.append('reflexivity')
        elif line == 'symm':
            tactics.append('symmetry')
        elif line == 'congr':
            tactics.append('f_equal')
        elif line == 'assumption':
            tactics.append('assumption')
        elif line.startswith('simp_all'):
            tactics.append('simpl in *; auto')
        elif line.startswith('simp ['):
            tactics.append('simpl; auto')
        elif line.startswith('exact '):
            # Try to translate, but may need manual work
            tactics.append(f'(* {line} *) admit')
        elif line.startswith('rw [') or line.startswith('rewrite ['):
            # Extract rewrite target
            tactics.append(f'(* {line} *) admit')
        elif line.startswith('have '):
            tactics.append(f'(* {line} *) admit')
        elif line.startswith('conv'):
            tactics.append(f'(* {line} *) admit')
        else:
            tactics.append(f'(* {line} *) admit')
    return tactics


def classify_proof(proof_lines):
    """Classify the proof type for targeted translation."""
    if proof_lines == ['repeat intro', 'apply h']:
        return 'apply'
    elif proof_lines == ['repeat intro', 'exact h']:
        return 'exact'
    elif len(proof_lines) >= 1 and proof_lines[0] == 'repeat intro' and all(
        l in ('apply h', 'exact h', 'rfl', 'symm', 'congr', 'assumption')
        for l in proof_lines[1:]
    ):
        return 'simple'
    else:
        return 'complex'


def gen_rocq_theorem(thm):
    """Generate a Rocq theorem string."""
    name = thm['name']
    src = thm['src']
    tgt = thm['tgt']
    proof_type = classify_proof(thm['lean_proof'])

    if proof_type == 'apply':
        return (
            f"Theorem {name}\n"
            f"  (G : Type) `{{Magma G}} (h : {src} G) : {tgt} G.\n"
            f"Proof. unfold {src} in h. unfold {tgt}. intros. apply h. Qed.\n"
        )
    elif proof_type == 'exact':
        return (
            f"Theorem {name}\n"
            f"  (G : Type) `{{Magma G}} (h : {src} G) : {tgt} G.\n"
            f"Proof. unfold {src} in h. unfold {tgt}. intros. exact (h _). Qed.\n"
        )
    elif proof_type == 'simple':
        tactics = lean_to_rocq_proof(thm['lean_proof'])
        tactic_str = ". ".join(tactics) + "."
        return (
            f"Theorem {name}\n"
            f"  (G : Type) `{{Magma G}} (h : {src} G) : {tgt} G.\n"
            f"Proof. unfold {src} in h. unfold {tgt}. {tactic_str} Qed.\n"
        )
    else:
        # Complex proof - skip for now
        return None


def main():
    OUT_DIR.mkdir(parents=True, exist_ok=True)

    lean_files = sorted(LEAN_DIR.glob("*.lean"))
    total_ported = 0
    total_skipped = 0
    rocq_files = []

    for lean_file in lean_files:
        theorems = parse_lean_file(lean_file)
        if not theorems:
            continue

        basename = lean_file.stem
        outpath = OUT_DIR / f"{basename}.v"

        ported = []
        skipped = 0
        for thm in theorems:
            proof_type = classify_proof(thm['lean_proof'])
            if proof_type in ('apply',):
                rocq = gen_rocq_theorem(thm)
                if rocq:
                    ported.append(rocq)
                else:
                    skipped += 1
            else:
                skipped += 1

        if not ported:
            print(f"  {lean_file.name}: skipped all {len(theorems)} theorems", file=os.sys.stderr)
            total_skipped += len(theorems)
            continue

        rocq_files.append(basename)

        with open(outpath, 'w') as f:
            f.write(f"(** * TrivialBruteforce/{basename}\n\n")
            f.write(f"    Auto-generated from Lean4 TrivialBruteforce. *)\n\n")
            f.write("From Stdlib Require Import Utf8.\n\n")
            f.write("From ETP Require Import Magma.\n")
            f.write("From ETP.Equations Require Import All.\n\n")
            f.write("Open Scope magma_scope.\n\n")

            for rocq in ported:
                f.write(rocq)
                f.write("\n")

        total_ported += len(ported)
        total_skipped += skipped
        print(f"  {outpath.name}: {len(ported)} ported, {skipped} skipped", file=os.sys.stderr)

    # Write All.v
    if rocq_files:
        allpath = OUT_DIR / "All.v"
        with open(allpath, 'w') as f:
            f.write("(** * All TrivialBruteforce — re-exports all TrivialBruteforce files *)\n\n")
            for name in rocq_files:
                f.write(f"From ETP.Generated.TrivialBruteforce Require Export {name}.\n")
        print(f"\nWrote {allpath}", file=os.sys.stderr)

    print(f"\nTotal: {total_ported} ported, {total_skipped} skipped", file=os.sys.stderr)


if __name__ == "__main__":
    main()
