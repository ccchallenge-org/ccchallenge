(** * Preorder — implication ordering on magma laws

    Ported from [equational_theories/Preorder.lean].

    A law [l₁] implies [l₂] when every magma satisfying [l₁] also
    satisfies [l₂].  This gives a preorder on [MagmaLaw]. *)

From Stdlib Require Import Utf8.

From ETP Require Import Magma.
From ETP Require Import FreeMagma.
From ETP Require Import MagmaLaw.

Open Scope magma_scope.

(** ======================================================================= *)
(** ** Implication between laws                                              *)
(** ======================================================================= *)

(** [law_implies l₁ l₂] holds when every magma satisfying [l₁] also
    satisfies [l₂]. *)

Definition law_implies {A B : Type}
  (l1 : MagmaLaw A) (l2 : MagmaLaw B) : Prop :=
  forall (G : Type) (M : Magma G),
    @satisfies A G M l1 -> @satisfies B G M l2.

(** [law_iff l₁ l₂] holds when [l₁] and [l₂] are satisfied by exactly
    the same magmas. *)

Definition law_iff {A B : Type}
  (l1 : MagmaLaw A) (l2 : MagmaLaw B) : Prop :=
  forall (G : Type) (M : Magma G),
    @satisfies A G M l1 <-> @satisfies B G M l2.

(** ======================================================================= *)
(** ** Basic properties                                                      *)
(** ======================================================================= *)

Lemma law_iff_symm :
  forall {A B : Type} {l1 : MagmaLaw A} {l2 : MagmaLaw B},
    law_iff l1 l2 -> law_iff l2 l1.
Proof.
  intros A B l1 l2 H G M.
  specialize (H G M). destruct H. split; assumption.
Qed.

Lemma law_iff_trans :
  forall {A B C : Type} {l1 : MagmaLaw A} {l2 : MagmaLaw B} {l3 : MagmaLaw C},
    law_iff l1 l2 -> law_iff l2 l3 -> law_iff l1 l3.
Proof.
  intros A B C l1 l2 l3 H12 H23 G M.
  specialize (H12 G M). specialize (H23 G M).
  destruct H12, H23. split; auto.
Qed.

Lemma law_iff_implies :
  forall {A B : Type} {l1 : MagmaLaw A} {l2 : MagmaLaw B},
    law_iff l1 l2 -> law_implies l1 l2.
Proof.
  intros A B l1 l2 H G M Hsat.
  apply (H G M). exact Hsat.
Qed.

Lemma law_iff_implies_rev :
  forall {A B : Type} {l1 : MagmaLaw A} {l2 : MagmaLaw B},
    law_iff l1 l2 -> law_implies l2 l1.
Proof.
  intros. apply law_iff_implies. apply law_iff_symm. assumption.
Qed.

(** ======================================================================= *)
(** ** Preorder structure                                                    *)
(** ======================================================================= *)

Lemma law_implies_refl :
  forall {A : Type} (l : MagmaLaw A), law_implies l l.
Proof.
  intros A l G M H. exact H.
Qed.

Lemma law_implies_trans :
  forall {A : Type} {l1 l2 l3 : MagmaLaw A},
    law_implies l1 l2 -> law_implies l2 l3 -> law_implies l1 l3.
Proof.
  intros A l1 l2 l3 H12 H23 G M H1.
  apply H23. apply H12. exact H1.
Qed.

(** ======================================================================= *)
(** ** Extremal elements                                                     *)
(** ======================================================================= *)

From ETP Require Import Equations.

(** [law1] (x = x) is the maximal element: every law implies it. *)
Lemma law1_maximal :
  forall (l : MagmaLaw nat), law_implies l law1.
Proof.
  intros l G M _ φ.
  unfold satisfiesPhi, law1. simpl. reflexivity.
Qed.

(** A magma satisfying law [0 = 1] (all elements equal) satisfies every
    law. *)
Lemma evalInMagma_all_equal :
  forall {A G : Type} `{Magma G} (Heq : forall x y : G, x = y)
    (φ : A -> G) (t1 t2 : FreeMagma A),
    evalInMagma φ t1 = evalInMagma φ t2.
Proof.
  intros. apply Heq.
Qed.

Lemma all_equal_satisfies_any :
  forall {G : Type} {M : Magma G},
    (forall x y : G, x = y) ->
    forall {A : Type} (l : MagmaLaw A), @satisfies A G M l.
Proof.
  intros G M Heq A l φ.
  unfold satisfiesPhi.
  apply Heq.
Qed.
