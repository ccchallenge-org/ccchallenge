(** * FinMagma — finite types and magma construction infrastructure

    Provides small finite types [Fin2] through [Fin13] with decidable
    equality.  These are used to construct concrete counterexample magmas. *)

From Stdlib Require Import Utf8.
From Stdlib Require Import Bool.

From ETP Require Import Magma.

Open Scope magma_scope.

(** ** Finite types *)

Inductive Fin2 : Type := F2_0 | F2_1.
Inductive Fin3 : Type := F3_0 | F3_1 | F3_2.
Inductive Fin4 : Type := F4_0 | F4_1 | F4_2 | F4_3.
Inductive Fin5 : Type := F5_0 | F5_1 | F5_2 | F5_3 | F5_4.
Inductive Fin6 : Type := F6_0 | F6_1 | F6_2 | F6_3 | F6_4 | F6_5.
Inductive Fin7 : Type := F7_0 | F7_1 | F7_2 | F7_3 | F7_4 | F7_5 | F7_6.
Inductive Fin8 : Type := F8_0 | F8_1 | F8_2 | F8_3 | F8_4 | F8_5 | F8_6 | F8_7.
Inductive Fin9 : Type := F9_0 | F9_1 | F9_2 | F9_3 | F9_4 | F9_5 | F9_6 | F9_7 | F9_8.
Inductive Fin10 : Type := F10_0 | F10_1 | F10_2 | F10_3 | F10_4 | F10_5 | F10_6 | F10_7 | F10_8 | F10_9.
Inductive Fin11 : Type := F11_0 | F11_1 | F11_2 | F11_3 | F11_4 | F11_5 | F11_6 | F11_7 | F11_8 | F11_9 | F11_10.
Inductive Fin12 : Type := F12_0 | F12_1 | F12_2 | F12_3 | F12_4 | F12_5 | F12_6 | F12_7 | F12_8 | F12_9 | F12_10 | F12_11.
Inductive Fin13 : Type := F13_0 | F13_1 | F13_2 | F13_3 | F13_4 | F13_5 | F13_6 | F13_7 | F13_8 | F13_9 | F13_10 | F13_11 | F13_12.

(** ** Decidable equality *)

Lemma Fin2_eq_dec : forall x y : Fin2, {x = y} + {x <> y}.
Proof. decide equality. Defined.

Lemma Fin3_eq_dec : forall x y : Fin3, {x = y} + {x <> y}.
Proof. decide equality. Defined.

Lemma Fin4_eq_dec : forall x y : Fin4, {x = y} + {x <> y}.
Proof. decide equality. Defined.

Lemma Fin5_eq_dec : forall x y : Fin5, {x = y} + {x <> y}.
Proof. decide equality. Defined.

Lemma Fin6_eq_dec : forall x y : Fin6, {x = y} + {x <> y}.
Proof. decide equality. Defined.

Lemma Fin7_eq_dec : forall x y : Fin7, {x = y} + {x <> y}.
Proof. decide equality. Defined.

Lemma Fin8_eq_dec : forall x y : Fin8, {x = y} + {x <> y}.
Proof. decide equality. Defined.

Lemma Fin9_eq_dec : forall x y : Fin9, {x = y} + {x <> y}.
Proof. decide equality. Defined.

Lemma Fin10_eq_dec : forall x y : Fin10, {x = y} + {x <> y}.
Proof. decide equality. Defined.

Lemma Fin11_eq_dec : forall x y : Fin11, {x = y} + {x <> y}.
Proof. decide equality. Defined.

Lemma Fin12_eq_dec : forall x y : Fin12, {x = y} + {x <> y}.
Proof. decide equality. Defined.

Lemma Fin13_eq_dec : forall x y : Fin13, {x = y} + {x <> y}.
Proof. decide equality. Defined.

(** ** Magma construction *)

Definition FinMagma2 (op : Fin2 -> Fin2 -> Fin2) : Magma Fin2 :=
  {| magma_op := op |}.

Definition FinMagma3 (op : Fin3 -> Fin3 -> Fin3) : Magma Fin3 :=
  {| magma_op := op |}.

Definition FinMagma4 (op : Fin4 -> Fin4 -> Fin4) : Magma Fin4 :=
  {| magma_op := op |}.

Definition FinMagma5 (op : Fin5 -> Fin5 -> Fin5) : Magma Fin5 :=
  {| magma_op := op |}.

Definition FinMagma6 (op : Fin6 -> Fin6 -> Fin6) : Magma Fin6 :=
  {| magma_op := op |}.

Definition FinMagma7 (op : Fin7 -> Fin7 -> Fin7) : Magma Fin7 :=
  {| magma_op := op |}.

Definition FinMagma8 (op : Fin8 -> Fin8 -> Fin8) : Magma Fin8 :=
  {| magma_op := op |}.

Definition FinMagma9 (op : Fin9 -> Fin9 -> Fin9) : Magma Fin9 :=
  {| magma_op := op |}.

Definition FinMagma10 (op : Fin10 -> Fin10 -> Fin10) : Magma Fin10 :=
  {| magma_op := op |}.

Definition FinMagma11 (op : Fin11 -> Fin11 -> Fin11) : Magma Fin11 :=
  {| magma_op := op |}.

Definition FinMagma12 (op : Fin12 -> Fin12 -> Fin12) : Magma Fin12 :=
  {| magma_op := op |}.

Definition FinMagma13 (op : Fin13 -> Fin13 -> Fin13) : Magma Fin13 :=
  {| magma_op := op |}.

