(** * Equations — named equational laws for magmas

    This file re-exports all 4694+ equation definitions from
    the auto-generated [Equations/] sub-directory and adds
    MagmaLaw representations and utility definitions. *)

From Stdlib Require Import Utf8.

From ETP Require Import Magma.
From ETP.Equations Require Export All.

Open Scope magma_scope.

(** ======================================================================= *)
(** ** Negated forms (for counterexample statements)                         *)
(** ======================================================================= *)

Definition notEquation (P : Type -> Prop) (G : Type) : Prop := ~ P G.

(** ======================================================================= *)
(** ** MagmaLaw representations for selected equations                       *)
(** ======================================================================= *)

(** We also provide [MagmaLaw] encodings of the key equations so that
    the generic satisfaction framework from [MagmaLaw.v] can be used.

    Variables are drawn from [nat].  Convention:  0 = x,  1 = y,  2 = z,
    3 = w. *)

From ETP Require Import FreeMagma.
From ETP Require Import MagmaLaw.

(** x = x *)
Definition law1 : MagmaLaw nat :=
  {| law_lhs := Leaf 0
   ; law_rhs := Leaf 0 |}.

(** x ◇ y = y ◇ x *)
Definition law43 : MagmaLaw nat :=
  {| law_lhs := Fork (Leaf 0) (Leaf 1)
   ; law_rhs := Fork (Leaf 1) (Leaf 0) |}.

(** x ◇ (y ◇ z) = (x ◇ y) ◇ z *)
Definition law4512 : MagmaLaw nat :=
  {| law_lhs := Fork (Leaf 0) (Fork (Leaf 1) (Leaf 2))
   ; law_rhs := Fork (Fork (Leaf 0) (Leaf 1)) (Leaf 2) |}.
