(** Quick test: can destruct handle Fin7 with 3 variables? *)
From Stdlib Require Import Utf8.
From ETP Require Import Magma.
From ETP Require Import FinMagma.
From ETP.Equations Require Import All.
Open Scope magma_scope.

(** Operation from All4x4Tables Refutation0: 7x7 table *)
Definition ref0_op (x y : Fin7) : Fin7 :=
  match x, y with
  | F7_0, F7_0 => F7_0 | F7_0, F7_1 => F7_2 | F7_0, F7_2 => F7_1
  | F7_0, F7_3 => F7_4 | F7_0, F7_4 => F7_3 | F7_0, F7_5 => F7_6
  | F7_0, F7_6 => F7_5
  | F7_1, F7_0 => F7_3 | F7_1, F7_1 => F7_1 | F7_1, F7_2 => F7_5
  | F7_1, F7_3 => F7_0 | F7_1, F7_4 => F7_6 | F7_1, F7_5 => F7_2
  | F7_1, F7_6 => F7_4
  | F7_2, F7_0 => F7_4 | F7_2, F7_1 => F7_6 | F7_2, F7_2 => F7_2
  | F7_2, F7_3 => F7_5 | F7_2, F7_4 => F7_0 | F7_2, F7_5 => F7_3
  | F7_2, F7_6 => F7_1
  | F7_3, F7_0 => F7_6 | F7_3, F7_1 => F7_5 | F7_3, F7_2 => F7_4
  | F7_3, F7_3 => F7_3 | F7_3, F7_4 => F7_2 | F7_3, F7_5 => F7_1
  | F7_3, F7_6 => F7_0
  | F7_4, F7_0 => F7_5 | F7_4, F7_1 => F7_3 | F7_4, F7_2 => F7_6
  | F7_4, F7_3 => F7_1 | F7_4, F7_4 => F7_4 | F7_4, F7_5 => F7_0
  | F7_4, F7_6 => F7_2
  | F7_5, F7_0 => F7_2 | F7_5, F7_1 => F7_4 | F7_5, F7_2 => F7_0
  | F7_5, F7_3 => F7_6 | F7_5, F7_4 => F7_1 | F7_5, F7_5 => F7_5
  | F7_5, F7_6 => F7_3
  | F7_6, F7_0 => F7_1 | F7_6, F7_1 => F7_0 | F7_6, F7_2 => F7_3
  | F7_6, F7_3 => F7_2 | F7_6, F7_4 => F7_5 | F7_6, F7_5 => F7_4
  | F7_6, F7_6 => F7_6
  end.

#[local] Instance M_ref0 : Magma Fin7 := {| magma_op := ref0_op |}.

(** Test 2-var equation: 7^2 = 49 cases *)
Lemma ref0_Eq1286 : Equation1286 Fin7 (H := M_ref0).
Proof.
  unfold Equation1286, magma_op, M_ref0, ref0_op.
  intros x y. destruct x, y; reflexivity.
Qed.

(** Test another 2-var equation: Equation2301 has 2 vars *)
Lemma ref0_Eq2301 : Equation2301 Fin7 (H := M_ref0).
Proof.
  unfold Equation2301, magma_op, M_ref0, ref0_op.
  intros x y. destruct x, y; reflexivity.
Qed.

(** Test negative: find ONE counterexample *)
Lemma ref0_not_Eq50 : ~ Equation50 Fin7 (H := M_ref0).
Proof.
  unfold Equation50. intro H.
  specialize (H F7_0 F7_1).
  unfold magma_op, M_ref0, ref0_op in H. discriminate H.
Qed.
