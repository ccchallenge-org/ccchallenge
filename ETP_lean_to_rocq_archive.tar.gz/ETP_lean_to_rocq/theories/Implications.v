(** * Implications — example implication proofs and counterexamples

    This file demonstrates the two main proof patterns from the
    Equational Theories Project:

    1. **Implication**:  EquationA G -> EquationB G
       Proved by algebraic manipulation under a universally quantified
       magma.

    2. **Non-implication** (counterexample):
       ∃ G (M : Magma G), EquationA G ∧ ¬ EquationB G
       Proved by exhibiting a concrete finite magma.

    NOTE: Equation numbering follows the official Lean4 catalogue.
    Some important equations:
      Equation 1:    x = x                   (reflexivity)
      Equation 2:    x = y                   (all elements equal)
      Equation 3:    x = x ◇ x              (idempotence, reversed)
      Equation 4:    x = x ◇ y              (left absorption)
      Equation 5:    x = y ◇ x              (right absorption)
      Equation 43:   x ◇ y = y ◇ x          (commutativity)
      Equation 46:   x ◇ y = z ◇ w          (all products equal)
      Equation 4512: x ◇ (y ◇ z) = (x ◇ y) ◇ z  (associativity) *)

From Stdlib Require Import Utf8.
From Stdlib Require Import Bool.

From ETP Require Import Magma.
From ETP Require Import FreeMagma.
From ETP Require Import MagmaLaw.
From ETP Require Import Equations.

Open Scope magma_scope.

(** ======================================================================= *)
(** ** Trivial implications                                                  *)
(** ======================================================================= *)

(** Every equation implies Equation 1 (reflexivity: x = x). *)

Theorem Equation1_holds (G : Type) `{Magma G} : Equation1 G.
Proof.
  unfold Equation1.
  intro x. reflexivity.
Qed.

(** Equation 2 (x = y) implies every equation that uses only
    equalities between terms.  Here we show it implies Equation 43. *)

Theorem Equation2_implies_Equation43
  (G : Type) `{Magma G} (h : Equation2 G) : Equation43 G.
Proof.
  unfold Equation2 in h.
  unfold Equation43.
  intros x y.
  transitivity x.
  - symmetry. apply h.
  - apply h.
Qed.

(** Equation 2 implies Equation 4512 by the same reasoning. *)

Theorem Equation2_implies_Equation4512
  (G : Type) `{Magma G} (h : Equation2 G) : Equation4512 G.
Proof.
  unfold Equation2 in h.
  unfold Equation4512.
  intros x y z.
  transitivity x.
  - symmetry. apply h.
  - apply h.
Qed.

(** ======================================================================= *)
(** ** Equation 4 (left absorption: x = x ◇ y) implications                 *)
(** ======================================================================= *)

(** If x = x ◇ y for all x, y then x = x ◇ x. *)

Theorem Equation4_implies_Equation3
  (G : Type) `{Magma G} (h : Equation4 G) : Equation3 G.
Proof.
  unfold Equation4 in h.
  unfold Equation3.
  intro x. apply h.
Qed.

(** ======================================================================= *)
(** ** Equation 5 (right absorption: x = y ◇ x) implications                *)
(** ======================================================================= *)

(** If x = y ◇ x for all x, y then x = x ◇ x. *)

Theorem Equation5_implies_Equation3
  (G : Type) `{Magma G} (h : Equation5 G) : Equation3 G.
Proof.
  unfold Equation5 in h.
  unfold Equation3.
  intro x. apply h.
Qed.

(** ======================================================================= *)
(** ** Equation 46 (all products equal) implications                         *)
(** ======================================================================= *)

(** If all products are equal, then commutativity holds. *)

Theorem Equation46_implies_Equation43
  (G : Type) `{Magma G} (h : Equation46 G) : Equation43 G.
Proof.
  unfold Equation46 in h.
  unfold Equation43.
  intros x y.
  transitivity (y ◇ y).
  - apply h.
  - symmetry. apply h.
Qed.

(** If all products are equal, then associativity holds. *)

Theorem Equation46_implies_Equation4512
  (G : Type) `{Magma G} (h : Equation46 G) : Equation4512 G.
Proof.
  unfold Equation46 in h.
  unfold Equation4512.
  intros x y z.
  apply h.
Qed.

(** ======================================================================= *)
(** ** Non-implications (counterexamples)                                    *)
(** ======================================================================= *)

(** --- Three-element magma on a custom type ------------------------------ *)

Inductive Three : Type := A | B | C.

(** We define a commutative but non-associative operation on Three.
    Cayley table (reading row ◇ column):

        | A | B | C
      --+---+---+---
      A | A | C | B
      B | C | B | A
      C | B | A | C

    This is commutative by inspection.  But:
      A ◇ (B ◇ C) = A ◇ A = A
      (A ◇ B) ◇ C = C ◇ C = C
    so A ◇ (B ◇ C) ≠ (A ◇ B) ◇ C.
*)

Definition three_op (x y : Three) : Three :=
  match x, y with
  | A, A => A | A, B => C | A, C => B
  | B, A => C | B, B => B | B, C => A
  | C, A => B | C, B => A | C, C => C
  end.

#[local]
Instance Magma_three : Magma Three := {| magma_op := three_op |}.

(** Three_op is commutative. *)
Lemma three_comm : Equation43 Three (H := Magma_three).
Proof.
  unfold Equation43, magma_op, Magma_three, three_op.
  intros x y; destruct x, y; reflexivity.
Qed.

(** Three_op is NOT associative. *)
Lemma three_not_assoc : ~ Equation4512 Three (H := Magma_three).
Proof.
  unfold Equation4512.
  intro H.
  specialize (H A B C).
  unfold magma_op, Magma_three, three_op in H.
  discriminate H.
Qed.

(** Commutativity does NOT imply associativity. *)
Theorem Equation43_not_implies_Equation4512 :
  exists (G : Type) (M : Magma G), Equation43 G /\ ~ Equation4512 G.
Proof.
  exists Three, Magma_three.
  split.
  - exact three_comm.
  - exact three_not_assoc.
Qed.

(** --- Two-element magma (bool with left projection) --------------------- *)

(** Cayley table on bool (true/false):
      | T | F
    --+---+---
    T | T | T
    F | F | F

    This is x ◇ y = x (left projection). *)

Definition left_proj (a b : bool) : bool := a.

#[local]
Instance Magma_left : Magma bool := {| magma_op := left_proj |}.

(** Left projection satisfies Equation 3: x = x ◇ x. *)
Lemma left_Equation3 : Equation3 bool (H := Magma_left).
Proof.
  unfold Equation3, magma_op, Magma_left, left_proj.
  intro x. reflexivity.
Qed.

(** Left projection is NOT commutative: T ◇ F = T ≠ F = F ◇ T. *)
Lemma left_not_comm : ~ Equation43 bool (H := Magma_left).
Proof.
  unfold Equation43.
  intro H.
  specialize (H true false).
  unfold magma_op, Magma_left, left_proj in H.
  discriminate H.
Qed.

(** Left projection is associative: x ◇ (y ◇ z) = x = (x ◇ y) ◇ z. *)
Lemma left_assoc : Equation4512 bool (H := Magma_left).
Proof.
  unfold Equation4512, magma_op, Magma_left, left_proj.
  intros x y z. reflexivity.
Qed.

(** Equation 3 (x = x ◇ x) does NOT imply commutativity. *)
Theorem Equation3_not_implies_Equation43 :
  exists (G : Type) (M : Magma G), Equation3 G /\ ~ Equation43 G.
Proof.
  exists bool, Magma_left.
  split.
  - exact left_Equation3.
  - exact left_not_comm.
Qed.

(** Associativity does NOT imply commutativity. *)
Theorem Equation4512_not_implies_Equation43 :
  exists (G : Type) (M : Magma G), Equation4512 G /\ ~ Equation43 G.
Proof.
  exists bool, Magma_left.
  split.
  - exact left_assoc.
  - exact left_not_comm.
Qed.

(** ======================================================================= *)
(** ** MagmaLaw-based satisfaction example                                   *)
(** ======================================================================= *)

(** Show that the [Three] magma satisfies [law43] via the generic
    [satisfies] predicate. *)

Lemma Three_satisfies_law43 :
  satisfies Three (H := Magma_three) law43.
Proof.
  unfold satisfies, satisfiesPhi, law43.
  simpl.
  intro φ.
  unfold magma_op, Magma_three, three_op.
  destruct (φ 0), (φ 1); reflexivity.
Qed.
