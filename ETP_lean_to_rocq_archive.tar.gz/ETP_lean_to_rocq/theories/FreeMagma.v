(** * FreeMagma — the free magma on a generator type *)

From Stdlib Require Import Utf8.
From Stdlib Require Import Bool.
From Stdlib Require Import Arith.
From Stdlib Require Import List.
From Stdlib Require Import Program.Equality.

From ETP Require Import Magma.

Import ListNotations.
Open Scope magma_scope.

(** ---------- inductive definition ---------------------------------------- *)

Inductive FreeMagma (A : Type) : Type :=
  | Leaf : A -> FreeMagma A
  | Fork : FreeMagma A -> FreeMagma A -> FreeMagma A.

Arguments Leaf {A} _.
Arguments Fork {A} _ _.

(** ---------- Magma instance ---------------------------------------------- *)

#[global]
Instance FreeMagma_Magma (A : Type) : Magma (FreeMagma A) :=
  {| magma_op := Fork |}.

(** ---------- decidable equality ------------------------------------------ *)

Section DecEq.

  Context {A : Type}.
  Variable A_eq_dec : forall (x y : A), {x = y} + {x <> y}.

  Fixpoint FreeMagma_eq_dec (t1 t2 : FreeMagma A)
    : {t1 = t2} + {t1 <> t2}.
  Proof.
    decide equality; apply A_eq_dec.
  Defined.

End DecEq.

(** ---------- evaluation (interpret a free-magma tree in a magma) --------- *)

Section Eval.

  Context {A G : Type} `{Magma G}.

  (** Evaluate a [FreeMagma A] in [G] using an environment [φ : A -> G]. *)
  Fixpoint evalInMagma (φ : A -> G) (t : FreeMagma A) : G :=
    match t with
    | Leaf a   => φ a
    | Fork l r => (evalInMagma φ l) ◇ (evalInMagma φ r)
    end.

End Eval.

(** Unicode alias matching the Lean4 notation [E.lhs ⬝ φ]. *)
Notation "t '⬝' φ" := (evalInMagma φ t)
  (at level 40, left associativity) : magma_scope.

(** ---------- functorial map (fmap) --------------------------------------- *)

Fixpoint fmapFreeMagma {A B : Type} (f : A -> B) (t : FreeMagma A)
  : FreeMagma B :=
  match t with
  | Leaf a   => Leaf (f a)
  | Fork l r => Fork (fmapFreeMagma f l) (fmapFreeMagma f r)
  end.

(** ---------- membership -------------------------------------------------- *)

Fixpoint FreeMagma_mem {A : Type}
  (eq_dec : forall x y : A, {x = y} + {x <> y})
  (a : A) (t : FreeMagma A) : bool :=
  match t with
  | Leaf b   => if eq_dec a b then true else false
  | Fork l r => orb (FreeMagma_mem eq_dec a l) (FreeMagma_mem eq_dec a r)
  end.

(** ---------- size (number of leaves) ------------------------------------- *)

Fixpoint FreeMagma_size {A : Type} (t : FreeMagma A) : nat :=
  match t with
  | Leaf _   => 1
  | Fork l r => FreeMagma_size l + FreeMagma_size r
  end.

(** ---------- basic lemmas ------------------------------------------------ *)

Lemma evalInMagma_Leaf :
  forall {A G : Type} `{Magma G} (φ : A -> G) (a : A),
    evalInMagma φ (Leaf a) = φ a.
Proof. reflexivity. Qed.

Lemma evalInMagma_Fork :
  forall {A G : Type} `{Magma G} (φ : A -> G) (l r : FreeMagma A),
    evalInMagma φ (Fork l r) = (evalInMagma φ l) ◇ (evalInMagma φ r).
Proof. reflexivity. Qed.

Lemma fmapFreeMagma_id :
  forall {A : Type} (t : FreeMagma A),
    fmapFreeMagma (fun x => x) t = t.
Proof.
  induction t as [a | l IHl r IHr]; simpl.
  - reflexivity.
  - rewrite IHl, IHr. reflexivity.
Qed.

Lemma fmapFreeMagma_comp :
  forall {A B C : Type} (f : A -> B) (g : B -> C) (t : FreeMagma A),
    fmapFreeMagma g (fmapFreeMagma f t) = fmapFreeMagma (fun x => g (f x)) t.
Proof.
  induction t as [a | l IHl r IHr]; simpl.
  - reflexivity.
  - rewrite IHl, IHr. reflexivity.
Qed.

Lemma evalInMagma_fmap :
  forall {A B G : Type} `{Magma G} (f : A -> B) (φ : B -> G) (t : FreeMagma A),
    evalInMagma φ (fmapFreeMagma f t) = evalInMagma (fun a => φ (f a)) t.
Proof.
  induction t as [a | l IHl r IHr]; simpl.
  - reflexivity.
  - rewrite IHl, IHr. reflexivity.
Qed.
