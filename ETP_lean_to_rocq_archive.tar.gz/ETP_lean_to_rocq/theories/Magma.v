(** * Magma — a type equipped with a single binary operation *)

(** We use [From Rocq Require] when targeting Rocq 9.0+.
    For Coq 8.x compatibility, replace [From Rocq] with [From Coq]. *)

From Stdlib Require Import Utf8.

(** ---------- typeclass -------------------------------------------------- *)

Class Magma (A : Type) : Type :=
  { magma_op : A -> A -> A }.

(** Diamond notation, at precedence level 65 (left-associative, same as in
    the Lean4 project). *)

Declare Scope magma_scope.
Delimit Scope magma_scope with magma.
Open Scope magma_scope.

Notation "x ◇ y" := (magma_op x y)
  (at level 65, left associativity) : magma_scope.

(** ---------- convenience: Magma from Nat addition (example) ------------- *)

(** Any type with a binary [op] can be wrapped.  We provide a few
    canonical helpers so that concrete finite magmas can be built
    easily in counterexamples. *)

(** Build a Magma instance from a plain function. *)
Definition Build_Magma_from_fun {A : Type} (f : A -> A -> A) : Magma A :=
  {| magma_op := f |}.
