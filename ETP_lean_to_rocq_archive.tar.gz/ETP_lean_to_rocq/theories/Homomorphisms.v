(** * Homomorphisms — magma homomorphisms and isomorphisms

    Ported from [equational_theories/Homomorphisms.lean].

    We avoid Mathlib-specific infrastructure (FunLike, EquivLike) and
    use plain Rocq records and functions instead. *)

From Stdlib Require Import Utf8.
From Stdlib Require Import FunctionalExtensionality.
From Stdlib Require Import ProofIrrelevance.

From ETP Require Import Magma.

Open Scope magma_scope.

(** ======================================================================= *)
(** ** Magma homomorphisms                                                   *)
(** ======================================================================= *)

(** A [MagmaHom G H] is a function [G → H] that preserves the operation. *)

Record MagmaHom (G H : Type) `{Magma G} `{Magma H} : Type :=
  { hom_fun : G -> H
  ; hom_map_op : forall x y : G, hom_fun (x ◇ y) = hom_fun x ◇ hom_fun y
  }.

Arguments hom_fun {G H _ _} _ _.
Arguments hom_map_op {G H _ _} _ _ _.

(** Apply a homomorphism as a function. *)
Coercion hom_fun : MagmaHom >-> Funclass.

(** Extensionality for homomorphisms. *)
Lemma MagmaHom_ext :
  forall {G H : Type} `{Magma G} `{Magma H} (f g : MagmaHom G H),
    (forall x, hom_fun f x = hom_fun g x) -> f = g.
Proof.
  intros G H MG MH [f Hf] [g Hg] Heq.
  simpl in Heq.
  assert (f = g) as -> by (apply functional_extensionality; apply Heq).
  f_equal.
  apply proof_irrelevance.
Qed.

(** Composition of homomorphisms. *)
Definition MagmaHom_comp {G H I : Type} `{Magma G} `{Magma H} `{Magma I}
  (f : MagmaHom G H) (g : MagmaHom H I) : MagmaHom G I :=
  {| hom_fun := fun x => g (f x)
   ; hom_map_op := fun x y =>
       eq_trans (f_equal g (hom_map_op f x y)) (hom_map_op g (f x) (f y))
  |}.

(** Composition is associative. *)
Lemma MagmaHom_comp_assoc :
  forall {G H I J : Type} `{Magma G} `{Magma H} `{Magma I} `{Magma J}
    (f : MagmaHom G H) (g : MagmaHom H I) (h : MagmaHom I J),
    MagmaHom_comp f (MagmaHom_comp g h) = MagmaHom_comp (MagmaHom_comp f g) h.
Proof.
  intros. apply MagmaHom_ext. intro x. reflexivity.
Qed.

(** The identity homomorphism. *)
Definition MagmaHom_id (G : Type) `{Magma G} : MagmaHom G G :=
  {| hom_fun := fun x => x
   ; hom_map_op := fun _ _ => eq_refl
  |}.

(** ======================================================================= *)
(** ** Magma isomorphisms                                                    *)
(** ======================================================================= *)

(** A [MagmaEquiv G H] is a bijection [G ≃ H] preserving the operation. *)

Record MagmaEquiv (G H : Type) `{Magma G} `{Magma H} : Type :=
  { equiv_fun    : G -> H
  ; equiv_inv    : H -> G
  ; equiv_left   : forall x, equiv_inv (equiv_fun x) = x
  ; equiv_right  : forall y, equiv_fun (equiv_inv y) = y
  ; equiv_map_op : forall x y : G, equiv_fun (x ◇ y) = equiv_fun x ◇ equiv_fun y
  }.

Arguments equiv_fun {G H _ _} _ _.
Arguments equiv_inv {G H _ _} _ _.
Arguments equiv_left {G H _ _} _ _.
Arguments equiv_right {G H _ _} _ _.
Arguments equiv_map_op {G H _ _} _ _ _.

Coercion equiv_fun : MagmaEquiv >-> Funclass.

(** Every isomorphism yields a homomorphism. *)
Definition MagmaEquiv_to_hom {G H : Type} `{Magma G} `{Magma H}
  (e : MagmaEquiv G H) : MagmaHom G H :=
  {| hom_fun := equiv_fun e
   ; hom_map_op := equiv_map_op e
  |}.

(** The identity isomorphism. *)
Definition MagmaEquiv_id (G : Type) `{Magma G} : MagmaEquiv G G :=
  {| equiv_fun := fun x => x
   ; equiv_inv := fun x => x
   ; equiv_left := fun _ => eq_refl
   ; equiv_right := fun _ => eq_refl
   ; equiv_map_op := fun _ _ => eq_refl
  |}.

(** Composition of isomorphisms. *)
Definition MagmaEquiv_comp {G H I : Type} `{Magma G} `{Magma H} `{Magma I}
  (e1 : MagmaEquiv G H) (e2 : MagmaEquiv H I) : MagmaEquiv G I.
Proof.
  refine {| equiv_fun := fun x => e2 (e1 x)
          ; equiv_inv := fun z => equiv_inv e1 (equiv_inv e2 z)
          ; equiv_map_op := fun x y => _
          |}.
  - intro x. rewrite equiv_left. apply equiv_left.
  - intro y. rewrite equiv_right. apply equiv_right.
  - rewrite equiv_map_op. apply equiv_map_op.
Defined.

(** The inverse isomorphism preserves the operation. *)
Lemma MagmaEquiv_symm_map_op :
  forall {G H : Type} `{Magma G} `{Magma H} (e : MagmaEquiv G H) (x y : H),
    equiv_inv e (x ◇ y) = equiv_inv e x ◇ equiv_inv e y.
Proof.
  intros G H MG MH e x y.
  set (a := equiv_inv e x).
  set (b := equiv_inv e y).
  assert (Hx : equiv_fun e a = x) by apply equiv_right.
  assert (Hy : equiv_fun e b = y) by apply equiv_right.
  rewrite <- Hx, <- Hy.
  rewrite <- (equiv_map_op e a b).
  apply equiv_left.
Qed.

(** The inverse isomorphism. *)
Definition MagmaEquiv_symm {G H : Type} `{Magma G} `{Magma H}
  (e : MagmaEquiv G H) : MagmaEquiv H G :=
  {| equiv_fun := equiv_inv e
   ; equiv_inv := equiv_fun e
   ; equiv_left := equiv_right e
   ; equiv_right := equiv_left e
   ; equiv_map_op := MagmaEquiv_symm_map_op e
  |}.

(** Composing with the identity on the right. *)
Lemma MagmaEquiv_comp_id :
  forall {G H : Type} `{Magma G} `{Magma H} (e : MagmaEquiv G H),
    forall x, MagmaEquiv_comp e (MagmaEquiv_id H) x = e x.
Proof.
  intros. reflexivity.
Qed.

(** Composing with the identity on the left. *)
Lemma MagmaEquiv_id_comp :
  forall {G H : Type} `{Magma G} `{Magma H} (e : MagmaEquiv G H),
    forall x, MagmaEquiv_comp (MagmaEquiv_id G) e x = e x.
Proof.
  intros. reflexivity.
Qed.

(** Double inverse is the identity. *)
Lemma MagmaEquiv_symm_symm :
  forall {G H : Type} `{Magma G} `{Magma H} (e : MagmaEquiv G H) (x : G),
    MagmaEquiv_symm (MagmaEquiv_symm e) x = e x.
Proof.
  intros. reflexivity.
Qed.
