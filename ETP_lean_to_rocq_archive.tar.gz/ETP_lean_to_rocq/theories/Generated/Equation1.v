(** * Equation1 — every equation implies Equation 1 (x = x)

    Auto-generated from Lean4 Generated/Equation1.lean. *)

From Stdlib Require Import Utf8.

From ETP Require Import Magma.
From ETP.Equations Require Import All.

Open Scope magma_scope.

Theorem Equation47_implies_Equation1
  (G : Type) `{Magma G} (h : Equation47 G) : Equation1 G.
Proof. intro x. reflexivity. Qed.

Theorem Equation99_implies_Equation1
  (G : Type) `{Magma G} (h : Equation99 G) : Equation1 G.
Proof. intro x. reflexivity. Qed.

Theorem Equation151_implies_Equation1
  (G : Type) `{Magma G} (h : Equation151 G) : Equation1 G.
Proof. intro x. reflexivity. Qed.

Theorem Equation203_implies_Equation1
  (G : Type) `{Magma G} (h : Equation203 G) : Equation1 G.
Proof. intro x. reflexivity. Qed.

Theorem Equation255_implies_Equation1
  (G : Type) `{Magma G} (h : Equation255 G) : Equation1 G.
Proof. intro x. reflexivity. Qed.

Theorem Equation411_implies_Equation1
  (G : Type) `{Magma G} (h : Equation411 G) : Equation1 G.
Proof. intro x. reflexivity. Qed.

Theorem Equation614_implies_Equation1
  (G : Type) `{Magma G} (h : Equation614 G) : Equation1 G.
Proof. intro x. reflexivity. Qed.

Theorem Equation817_implies_Equation1
  (G : Type) `{Magma G} (h : Equation817 G) : Equation1 G.
Proof. intro x. reflexivity. Qed.

Theorem Equation1020_implies_Equation1
  (G : Type) `{Magma G} (h : Equation1020 G) : Equation1 G.
Proof. intro x. reflexivity. Qed.

Theorem Equation1223_implies_Equation1
  (G : Type) `{Magma G} (h : Equation1223 G) : Equation1 G.
Proof. intro x. reflexivity. Qed.

Theorem Equation1426_implies_Equation1
  (G : Type) `{Magma G} (h : Equation1426 G) : Equation1 G.
Proof. intro x. reflexivity. Qed.

Theorem Equation1629_implies_Equation1
  (G : Type) `{Magma G} (h : Equation1629 G) : Equation1 G.
Proof. intro x. reflexivity. Qed.

Theorem Equation1832_implies_Equation1
  (G : Type) `{Magma G} (h : Equation1832 G) : Equation1 G.
Proof. intro x. reflexivity. Qed.

Theorem Equation2035_implies_Equation1
  (G : Type) `{Magma G} (h : Equation2035 G) : Equation1 G.
Proof. intro x. reflexivity. Qed.

Theorem Equation2238_implies_Equation1
  (G : Type) `{Magma G} (h : Equation2238 G) : Equation1 G.
Proof. intro x. reflexivity. Qed.

Theorem Equation2441_implies_Equation1
  (G : Type) `{Magma G} (h : Equation2441 G) : Equation1 G.
Proof. intro x. reflexivity. Qed.

Theorem Equation2644_implies_Equation1
  (G : Type) `{Magma G} (h : Equation2644 G) : Equation1 G.
Proof. intro x. reflexivity. Qed.

Theorem Equation2847_implies_Equation1
  (G : Type) `{Magma G} (h : Equation2847 G) : Equation1 G.
Proof. intro x. reflexivity. Qed.

Theorem Equation3050_implies_Equation1
  (G : Type) `{Magma G} (h : Equation3050 G) : Equation1 G.
Proof. intro x. reflexivity. Qed.

Theorem Equation3253_implies_Equation1
  (G : Type) `{Magma G} (h : Equation3253 G) : Equation1 G.
Proof. intro x. reflexivity. Qed.

Theorem Equation3456_implies_Equation1
  (G : Type) `{Magma G} (h : Equation3456 G) : Equation1 G.
Proof. intro x. reflexivity. Qed.

Theorem Equation3659_implies_Equation1
  (G : Type) `{Magma G} (h : Equation3659 G) : Equation1 G.
Proof. intro x. reflexivity. Qed.

Theorem Equation3862_implies_Equation1
  (G : Type) `{Magma G} (h : Equation3862 G) : Equation1 G.
Proof. intro x. reflexivity. Qed.

Theorem Equation4065_implies_Equation1
  (G : Type) `{Magma G} (h : Equation4065 G) : Equation1 G.
Proof. intro x. reflexivity. Qed.

Theorem Equation4268_implies_Equation1
  (G : Type) `{Magma G} (h : Equation4268 G) : Equation1 G.
Proof. intro x. reflexivity. Qed.

Theorem Equation4269_implies_Equation1
  (G : Type) `{Magma G} (h : Equation4269 G) : Equation1 G.
Proof. intro x. reflexivity. Qed.

Theorem Equation4270_implies_Equation1
  (G : Type) `{Magma G} (h : Equation4270 G) : Equation1 G.
Proof. intro x. reflexivity. Qed.

Theorem Equation4272_implies_Equation1
  (G : Type) `{Magma G} (h : Equation4272 G) : Equation1 G.
Proof. intro x. reflexivity. Qed.

Theorem Equation4273_implies_Equation1
  (G : Type) `{Magma G} (h : Equation4273 G) : Equation1 G.
Proof. intro x. reflexivity. Qed.

Theorem Equation4275_implies_Equation1
  (G : Type) `{Magma G} (h : Equation4275 G) : Equation1 G.
Proof. intro x. reflexivity. Qed.

Theorem Equation4276_implies_Equation1
  (G : Type) `{Magma G} (h : Equation4276 G) : Equation1 G.
Proof. intro x. reflexivity. Qed.

Theorem Equation4283_implies_Equation1
  (G : Type) `{Magma G} (h : Equation4283 G) : Equation1 G.
Proof. intro x. reflexivity. Qed.

Theorem Equation4284_implies_Equation1
  (G : Type) `{Magma G} (h : Equation4284 G) : Equation1 G.
Proof. intro x. reflexivity. Qed.

Theorem Equation4290_implies_Equation1
  (G : Type) `{Magma G} (h : Equation4290 G) : Equation1 G.
Proof. intro x. reflexivity. Qed.

Theorem Equation4291_implies_Equation1
  (G : Type) `{Magma G} (h : Equation4291 G) : Equation1 G.
Proof. intro x. reflexivity. Qed.

Theorem Equation4293_implies_Equation1
  (G : Type) `{Magma G} (h : Equation4293 G) : Equation1 G.
Proof. intro x. reflexivity. Qed.

Theorem Equation4314_implies_Equation1
  (G : Type) `{Magma G} (h : Equation4314 G) : Equation1 G.
Proof. intro x. reflexivity. Qed.

Theorem Equation4320_implies_Equation1
  (G : Type) `{Magma G} (h : Equation4320 G) : Equation1 G.
Proof. intro x. reflexivity. Qed.

Theorem Equation4321_implies_Equation1
  (G : Type) `{Magma G} (h : Equation4321 G) : Equation1 G.
Proof. intro x. reflexivity. Qed.

Theorem Equation4343_implies_Equation1
  (G : Type) `{Magma G} (h : Equation4343 G) : Equation1 G.
Proof. intro x. reflexivity. Qed.

Theorem Equation4380_implies_Equation1
  (G : Type) `{Magma G} (h : Equation4380 G) : Equation1 G.
Proof. intro x. reflexivity. Qed.

Theorem Equation4584_implies_Equation1
  (G : Type) `{Magma G} (h : Equation4584 G) : Equation1 G.
Proof. intro x. reflexivity. Qed.

Theorem Equation4585_implies_Equation1
  (G : Type) `{Magma G} (h : Equation4585 G) : Equation1 G.
Proof. intro x. reflexivity. Qed.

Theorem Equation4588_implies_Equation1
  (G : Type) `{Magma G} (h : Equation4588 G) : Equation1 G.
Proof. intro x. reflexivity. Qed.

Theorem Equation4590_implies_Equation1
  (G : Type) `{Magma G} (h : Equation4590 G) : Equation1 G.
Proof. intro x. reflexivity. Qed.

Theorem Equation4591_implies_Equation1
  (G : Type) `{Magma G} (h : Equation4591 G) : Equation1 G.
Proof. intro x. reflexivity. Qed.

Theorem Equation4597_implies_Equation1
  (G : Type) `{Magma G} (h : Equation4597 G) : Equation1 G.
Proof. intro x. reflexivity. Qed.

Theorem Equation4598_implies_Equation1
  (G : Type) `{Magma G} (h : Equation4598 G) : Equation1 G.
Proof. intro x. reflexivity. Qed.

Theorem Equation4599_implies_Equation1
  (G : Type) `{Magma G} (h : Equation4599 G) : Equation1 G.
Proof. intro x. reflexivity. Qed.

Theorem Equation4605_implies_Equation1
  (G : Type) `{Magma G} (h : Equation4605 G) : Equation1 G.
Proof. intro x. reflexivity. Qed.

Theorem Equation4606_implies_Equation1
  (G : Type) `{Magma G} (h : Equation4606 G) : Equation1 G.
Proof. intro x. reflexivity. Qed.

Theorem Equation4608_implies_Equation1
  (G : Type) `{Magma G} (h : Equation4608 G) : Equation1 G.
Proof. intro x. reflexivity. Qed.

Theorem Equation4629_implies_Equation1
  (G : Type) `{Magma G} (h : Equation4629 G) : Equation1 G.
Proof. intro x. reflexivity. Qed.

Theorem Equation4635_implies_Equation1
  (G : Type) `{Magma G} (h : Equation4635 G) : Equation1 G.
Proof. intro x. reflexivity. Qed.

Theorem Equation4636_implies_Equation1
  (G : Type) `{Magma G} (h : Equation4636 G) : Equation1 G.
Proof. intro x. reflexivity. Qed.

Theorem Equation4658_implies_Equation1
  (G : Type) `{Magma G} (h : Equation4658 G) : Equation1 G.
Proof. intro x. reflexivity. Qed.

Theorem Equation4666_implies_Equation1
  (G : Type) `{Magma G} (h : Equation4666 G) : Equation1 G.
Proof. intro x. reflexivity. Qed.

