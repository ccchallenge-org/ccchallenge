(** * FinitePoly counterexamples — batch 12
    Auto-generated from Lean4 FinitePoly files. *)

From Stdlib Require Import Utf8.

From ETP Require Import Magma.
From ETP Require Import FinMagma.
From ETP.Equations Require Import All.

Open Scope magma_scope.

(** ---- reff622 (Fin5) ---- *)

Definition reff622_op (x y : Fin5) : Fin5 :=
  match x, y with
  | F5_0, F5_0 => F5_0 | F5_0, F5_1 => F5_0 | F5_0, F5_2 => F5_2 | F5_0, F5_3 => F5_1 | F5_0, F5_4 => F5_2
  | F5_1, F5_0 => F5_3 | F5_1, F5_1 => F5_1 | F5_1, F5_2 => F5_1 | F5_1, F5_3 => F5_3 | F5_1, F5_4 => F5_2
  | F5_2, F5_0 => F5_3 | F5_2, F5_1 => F5_4 | F5_2, F5_2 => F5_2 | F5_2, F5_3 => F5_2 | F5_2, F5_4 => F5_4
  | F5_3, F5_0 => F5_0 | F5_3, F5_1 => F5_4 | F5_3, F5_2 => F5_0 | F5_3, F5_3 => F5_3 | F5_3, F5_4 => F5_3
  | F5_4, F5_0 => F5_4 | F5_4, F5_1 => F5_1 | F5_4, F5_2 => F5_0 | F5_4, F5_3 => F5_1 | F5_4, F5_4 => F5_4
  end.

#[local] Instance reff622_inst : Magma Fin5 := {| magma_op := reff622_op |}.

Lemma reff622_sat260 : @Equation260 Fin5 reff622_inst.
Proof. unfold Equation260, magma_op, reff622_inst, reff622_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff622_sat616 : @Equation616 Fin5 reff622_inst.
Proof. unfold Equation616, magma_op, reff622_inst, reff622_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff622_sat1228 : @Equation1228 Fin5 reff622_inst.
Proof. unfold Equation1228, magma_op, reff622_inst, reff622_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff622_sat1479 : @Equation1479 Fin5 reff622_inst.
Proof. unfold Equation1479, magma_op, reff622_inst, reff622_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff622_sat1682 : @Equation1682 Fin5 reff622_inst.
Proof. unfold Equation1682, magma_op, reff622_inst, reff622_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff622_sat1885 : @Equation1885 Fin5 reff622_inst.
Proof. unfold Equation1885, magma_op, reff622_inst, reff622_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff622_sat2050 : @Equation2050 Fin5 reff622_inst.
Proof. unfold Equation2050, magma_op, reff622_inst, reff622_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff622_sat2659 : @Equation2659 Fin5 reff622_inst.
Proof. unfold Equation2659, magma_op, reff622_inst, reff622_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff622_sat2699 : @Equation2699 Fin5 reff622_inst.
Proof. unfold Equation2699, magma_op, reff622_inst, reff622_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff622_sat3055 : @Equation3055 Fin5 reff622_inst.
Proof. unfold Equation3055, magma_op, reff622_inst, reff622_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff622_sat3065 : @Equation3065 Fin5 reff622_inst.
Proof. unfold Equation3065, magma_op, reff622_inst, reff622_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff622_sat3068 : @Equation3068 Fin5 reff622_inst.
Proof. unfold Equation3068, magma_op, reff622_inst, reff622_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff622_sat3512 : @Equation3512 Fin5 reff622_inst.
Proof. unfold Equation3512, magma_op, reff622_inst, reff622_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff622_sat4070 : @Equation4070 Fin5 reff622_inst.
Proof. unfold Equation4070, magma_op, reff622_inst, reff622_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff622_not50 : ~ @Equation50 Fin5 reff622_inst.
Proof. unfold Equation50. intro H. specialize (H F5_0 F5_2). unfold magma_op, reff622_inst, reff622_op in H. discriminate H. Qed.

Lemma reff622_not53 : ~ @Equation53 Fin5 reff622_inst.
Proof. unfold Equation53. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff622_inst, reff622_op in H. discriminate H. Qed.

Lemma reff622_not55 : ~ @Equation55 Fin5 reff622_inst.
Proof. unfold Equation55. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff622_inst, reff622_op in H. discriminate H. Qed.

Lemma reff622_not56 : ~ @Equation56 Fin5 reff622_inst.
Proof. unfold Equation56. intro H. specialize (H F5_0 F5_2). unfold magma_op, reff622_inst, reff622_op in H. discriminate H. Qed.

Lemma reff622_not63 : ~ @Equation63 Fin5 reff622_inst.
Proof. unfold Equation63. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff622_inst, reff622_op in H. discriminate H. Qed.

Lemma reff622_not65 : ~ @Equation65 Fin5 reff622_inst.
Proof. unfold Equation65. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff622_inst, reff622_op in H. discriminate H. Qed.

Lemma reff622_not66 : ~ @Equation66 Fin5 reff622_inst.
Proof. unfold Equation66. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff622_inst, reff622_op in H. discriminate H. Qed.

Lemma reff622_not72 : ~ @Equation72 Fin5 reff622_inst.
Proof. unfold Equation72. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff622_inst, reff622_op in H. discriminate H. Qed.

Lemma reff622_not73 : ~ @Equation73 Fin5 reff622_inst.
Proof. unfold Equation73. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff622_inst, reff622_op in H. discriminate H. Qed.

Lemma reff622_not75 : ~ @Equation75 Fin5 reff622_inst.
Proof. unfold Equation75. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff622_inst, reff622_op in H. discriminate H. Qed.

Lemma reff622_not102 : ~ @Equation102 Fin5 reff622_inst.
Proof. unfold Equation102. intro H. specialize (H F5_0 F5_2). unfold magma_op, reff622_inst, reff622_op in H. discriminate H. Qed.

Lemma reff622_not105 : ~ @Equation105 Fin5 reff622_inst.
Proof. unfold Equation105. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff622_inst, reff622_op in H. discriminate H. Qed.

Lemma reff622_not107 : ~ @Equation107 Fin5 reff622_inst.
Proof. unfold Equation107. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff622_inst, reff622_op in H. discriminate H. Qed.

Lemma reff622_not108 : ~ @Equation108 Fin5 reff622_inst.
Proof. unfold Equation108. intro H. specialize (H F5_0 F5_2). unfold magma_op, reff622_inst, reff622_op in H. discriminate H. Qed.

Lemma reff622_not115 : ~ @Equation115 Fin5 reff622_inst.
Proof. unfold Equation115. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff622_inst, reff622_op in H. discriminate H. Qed.

Lemma reff622_not117 : ~ @Equation117 Fin5 reff622_inst.
Proof. unfold Equation117. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff622_inst, reff622_op in H. discriminate H. Qed.

Lemma reff622_not118 : ~ @Equation118 Fin5 reff622_inst.
Proof. unfold Equation118. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff622_inst, reff622_op in H. discriminate H. Qed.

Lemma reff622_not124 : ~ @Equation124 Fin5 reff622_inst.
Proof. unfold Equation124. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff622_inst, reff622_op in H. discriminate H. Qed.

Lemma reff622_not125 : ~ @Equation125 Fin5 reff622_inst.
Proof. unfold Equation125. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff622_inst, reff622_op in H. discriminate H. Qed.

Lemma reff622_not127 : ~ @Equation127 Fin5 reff622_inst.
Proof. unfold Equation127. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff622_inst, reff622_op in H. discriminate H. Qed.

Lemma reff622_not154 : ~ @Equation154 Fin5 reff622_inst.
Proof. unfold Equation154. intro H. specialize (H F5_0 F5_2). unfold magma_op, reff622_inst, reff622_op in H. discriminate H. Qed.

Lemma reff622_not157 : ~ @Equation157 Fin5 reff622_inst.
Proof. unfold Equation157. intro H. specialize (H F5_0 F5_2). unfold magma_op, reff622_inst, reff622_op in H. discriminate H. Qed.

Lemma reff622_not159 : ~ @Equation159 Fin5 reff622_inst.
Proof. unfold Equation159. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff622_inst, reff622_op in H. discriminate H. Qed.

Lemma reff622_not160 : ~ @Equation160 Fin5 reff622_inst.
Proof. unfold Equation160. intro H. specialize (H F5_0 F5_2). unfold magma_op, reff622_inst, reff622_op in H. discriminate H. Qed.

Lemma reff622_not169 : ~ @Equation169 Fin5 reff622_inst.
Proof. unfold Equation169. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff622_inst, reff622_op in H. discriminate H. Qed.

Lemma reff622_not170 : ~ @Equation170 Fin5 reff622_inst.
Proof. unfold Equation170. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff622_inst, reff622_op in H. discriminate H. Qed.

Lemma reff622_not176 : ~ @Equation176 Fin5 reff622_inst.
Proof. unfold Equation176. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff622_inst, reff622_op in H. discriminate H. Qed.

Lemma reff622_not177 : ~ @Equation177 Fin5 reff622_inst.
Proof. unfold Equation177. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff622_inst, reff622_op in H. discriminate H. Qed.

Lemma reff622_not179 : ~ @Equation179 Fin5 reff622_inst.
Proof. unfold Equation179. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff622_inst, reff622_op in H. discriminate H. Qed.

Lemma reff622_not206 : ~ @Equation206 Fin5 reff622_inst.
Proof. unfold Equation206. intro H. specialize (H F5_0 F5_2). unfold magma_op, reff622_inst, reff622_op in H. discriminate H. Qed.

Lemma reff622_not209 : ~ @Equation209 Fin5 reff622_inst.
Proof. unfold Equation209. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff622_inst, reff622_op in H. discriminate H. Qed.

Lemma reff622_not211 : ~ @Equation211 Fin5 reff622_inst.
Proof. unfold Equation211. intro H. specialize (H F5_0 F5_2). unfold magma_op, reff622_inst, reff622_op in H. discriminate H. Qed.

Lemma reff622_not212 : ~ @Equation212 Fin5 reff622_inst.
Proof. unfold Equation212. intro H. specialize (H F5_0 F5_2). unfold magma_op, reff622_inst, reff622_op in H. discriminate H. Qed.

Lemma reff622_not219 : ~ @Equation219 Fin5 reff622_inst.
Proof. unfold Equation219. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff622_inst, reff622_op in H. discriminate H. Qed.

Lemma reff622_not221 : ~ @Equation221 Fin5 reff622_inst.
Proof. unfold Equation221. intro H. specialize (H F5_0 F5_2). unfold magma_op, reff622_inst, reff622_op in H. discriminate H. Qed.

Lemma reff622_not222 : ~ @Equation222 Fin5 reff622_inst.
Proof. unfold Equation222. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff622_inst, reff622_op in H. discriminate H. Qed.

Lemma reff622_not228 : ~ @Equation228 Fin5 reff622_inst.
Proof. unfold Equation228. intro H. specialize (H F5_0 F5_2). unfold magma_op, reff622_inst, reff622_op in H. discriminate H. Qed.

Lemma reff622_not229 : ~ @Equation229 Fin5 reff622_inst.
Proof. unfold Equation229. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff622_inst, reff622_op in H. discriminate H. Qed.

Lemma reff622_not231 : ~ @Equation231 Fin5 reff622_inst.
Proof. unfold Equation231. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff622_inst, reff622_op in H. discriminate H. Qed.

Lemma reff622_not258 : ~ @Equation258 Fin5 reff622_inst.
Proof. unfold Equation258. intro H. specialize (H F5_0 F5_2). unfold magma_op, reff622_inst, reff622_op in H. discriminate H. Qed.

Lemma reff622_not261 : ~ @Equation261 Fin5 reff622_inst.
Proof. unfold Equation261. intro H. specialize (H F5_0 F5_3). unfold magma_op, reff622_inst, reff622_op in H. discriminate H. Qed.

Lemma reff622_not263 : ~ @Equation263 Fin5 reff622_inst.
Proof. unfold Equation263. intro H. specialize (H F5_0 F5_2). unfold magma_op, reff622_inst, reff622_op in H. discriminate H. Qed.

Lemma reff622_not264 : ~ @Equation264 Fin5 reff622_inst.
Proof. unfold Equation264. intro H. specialize (H F5_0 F5_2). unfold magma_op, reff622_inst, reff622_op in H. discriminate H. Qed.

Lemma reff622_not271 : ~ @Equation271 Fin5 reff622_inst.
Proof. unfold Equation271. intro H. specialize (H F5_0 F5_2). unfold magma_op, reff622_inst, reff622_op in H. discriminate H. Qed.

Lemma reff622_not273 : ~ @Equation273 Fin5 reff622_inst.
Proof. unfold Equation273. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff622_inst, reff622_op in H. discriminate H. Qed.

Lemma reff622_not274 : ~ @Equation274 Fin5 reff622_inst.
Proof. unfold Equation274. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff622_inst, reff622_op in H. discriminate H. Qed.

Lemma reff622_not280 : ~ @Equation280 Fin5 reff622_inst.
Proof. unfold Equation280. intro H. specialize (H F5_0 F5_4). unfold magma_op, reff622_inst, reff622_op in H. discriminate H. Qed.

Lemma reff622_not281 : ~ @Equation281 Fin5 reff622_inst.
Proof. unfold Equation281. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff622_inst, reff622_op in H. discriminate H. Qed.

Lemma reff622_not283 : ~ @Equation283 Fin5 reff622_inst.
Proof. unfold Equation283. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff622_inst, reff622_op in H. discriminate H. Qed.

Lemma reff622_not412 : ~ @Equation412 Fin5 reff622_inst.
Proof. unfold Equation412. intro H. specialize (H F5_0 F5_2). unfold magma_op, reff622_inst, reff622_op in H. discriminate H. Qed.

Lemma reff622_not413 : ~ @Equation413 Fin5 reff622_inst.
Proof. unfold Equation413. intro H. specialize (H F5_0 F5_4). unfold magma_op, reff622_inst, reff622_op in H. discriminate H. Qed.

Lemma reff622_not414 : ~ @Equation414 Fin5 reff622_inst.
Proof. unfold Equation414. intro H. specialize (H F5_0 F5_2). unfold magma_op, reff622_inst, reff622_op in H. discriminate H. Qed.

Lemma reff622_not416 : ~ @Equation416 Fin5 reff622_inst.
Proof. unfold Equation416. intro H. specialize (H F5_0 F5_4). unfold magma_op, reff622_inst, reff622_op in H. discriminate H. Qed.

Lemma reff622_not417 : ~ @Equation417 Fin5 reff622_inst.
Proof. unfold Equation417. intro H. specialize (H F5_0 F5_2). unfold magma_op, reff622_inst, reff622_op in H. discriminate H. Qed.

Lemma reff622_not419 : ~ @Equation419 Fin5 reff622_inst.
Proof. unfold Equation419. intro H. specialize (H F5_0 F5_2). unfold magma_op, reff622_inst, reff622_op in H. discriminate H. Qed.

Lemma reff622_not420 : ~ @Equation420 Fin5 reff622_inst.
Proof. unfold Equation420. intro H. specialize (H F5_0 F5_2). unfold magma_op, reff622_inst, reff622_op in H. discriminate H. Qed.

Lemma reff622_not426 : ~ @Equation426 Fin5 reff622_inst.
Proof. unfold Equation426. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff622_inst, reff622_op in H. discriminate H. Qed.

Lemma reff622_not427 : ~ @Equation427 Fin5 reff622_inst.
Proof. unfold Equation427. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff622_inst, reff622_op in H. discriminate H. Qed.

Lemma reff622_not429 : ~ @Equation429 Fin5 reff622_inst.
Proof. unfold Equation429. intro H. specialize (H F5_0 F5_2). unfold magma_op, reff622_inst, reff622_op in H. discriminate H. Qed.

Lemma reff622_not430 : ~ @Equation430 Fin5 reff622_inst.
Proof. unfold Equation430. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff622_inst, reff622_op in H. discriminate H. Qed.

Lemma reff622_not436 : ~ @Equation436 Fin5 reff622_inst.
Proof. unfold Equation436. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff622_inst, reff622_op in H. discriminate H. Qed.

Lemma reff622_not437 : ~ @Equation437 Fin5 reff622_inst.
Proof. unfold Equation437. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff622_inst, reff622_op in H. discriminate H. Qed.

Lemma reff622_not439 : ~ @Equation439 Fin5 reff622_inst.
Proof. unfold Equation439. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff622_inst, reff622_op in H. discriminate H. Qed.

Lemma reff622_not440 : ~ @Equation440 Fin5 reff622_inst.
Proof. unfold Equation440. intro H. specialize (H F5_0 F5_2). unfold magma_op, reff622_inst, reff622_op in H. discriminate H. Qed.

Lemma reff622_not463 : ~ @Equation463 Fin5 reff622_inst.
Proof. unfold Equation463. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff622_inst, reff622_op in H. discriminate H. Qed.

Lemma reff622_not464 : ~ @Equation464 Fin5 reff622_inst.
Proof. unfold Equation464. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff622_inst, reff622_op in H. discriminate H. Qed.

Lemma reff622_not466 : ~ @Equation466 Fin5 reff622_inst.
Proof. unfold Equation466. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff622_inst, reff622_op in H. discriminate H. Qed.

Lemma reff622_not467 : ~ @Equation467 Fin5 reff622_inst.
Proof. unfold Equation467. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff622_inst, reff622_op in H. discriminate H. Qed.

Lemma reff622_not473 : ~ @Equation473 Fin5 reff622_inst.
Proof. unfold Equation473. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff622_inst, reff622_op in H. discriminate H. Qed.

Lemma reff622_not474 : ~ @Equation474 Fin5 reff622_inst.
Proof. unfold Equation474. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff622_inst, reff622_op in H. discriminate H. Qed.

Lemma reff622_not476 : ~ @Equation476 Fin5 reff622_inst.
Proof. unfold Equation476. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff622_inst, reff622_op in H. discriminate H. Qed.

Lemma reff622_not477 : ~ @Equation477 Fin5 reff622_inst.
Proof. unfold Equation477. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff622_inst, reff622_op in H. discriminate H. Qed.

Lemma reff622_not500 : ~ @Equation500 Fin5 reff622_inst.
Proof. unfold Equation500. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff622_inst, reff622_op in H. discriminate H. Qed.

Lemma reff622_not501 : ~ @Equation501 Fin5 reff622_inst.
Proof. unfold Equation501. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff622_inst, reff622_op in H. discriminate H. Qed.

Lemma reff622_not503 : ~ @Equation503 Fin5 reff622_inst.
Proof. unfold Equation503. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff622_inst, reff622_op in H. discriminate H. Qed.

Lemma reff622_not504 : ~ @Equation504 Fin5 reff622_inst.
Proof. unfold Equation504. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff622_inst, reff622_op in H. discriminate H. Qed.

Lemma reff622_not510 : ~ @Equation510 Fin5 reff622_inst.
Proof. unfold Equation510. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff622_inst, reff622_op in H. discriminate H. Qed.

Lemma reff622_not511 : ~ @Equation511 Fin5 reff622_inst.
Proof. unfold Equation511. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff622_inst, reff622_op in H. discriminate H. Qed.

Lemma reff622_not513 : ~ @Equation513 Fin5 reff622_inst.
Proof. unfold Equation513. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff622_inst, reff622_op in H. discriminate H. Qed.

Lemma reff622_not615 : ~ @Equation615 Fin5 reff622_inst.
Proof. unfold Equation615. intro H. specialize (H F5_0 F5_2). unfold magma_op, reff622_inst, reff622_op in H. discriminate H. Qed.

Lemma reff622_not617 : ~ @Equation617 Fin5 reff622_inst.
Proof. unfold Equation617. intro H. specialize (H F5_0 F5_2). unfold magma_op, reff622_inst, reff622_op in H. discriminate H. Qed.

Lemma reff622_not619 : ~ @Equation619 Fin5 reff622_inst.
Proof. unfold Equation619. intro H. specialize (H F5_0 F5_4). unfold magma_op, reff622_inst, reff622_op in H. discriminate H. Qed.

Lemma reff622_not620 : ~ @Equation620 Fin5 reff622_inst.
Proof. unfold Equation620. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff622_inst, reff622_op in H. discriminate H. Qed.

Lemma reff622_not622 : ~ @Equation622 Fin5 reff622_inst.
Proof. unfold Equation622. intro H. specialize (H F5_0 F5_4). unfold magma_op, reff622_inst, reff622_op in H. discriminate H. Qed.

Lemma reff622_not623 : ~ @Equation623 Fin5 reff622_inst.
Proof. unfold Equation623. intro H. specialize (H F5_0 F5_2). unfold magma_op, reff622_inst, reff622_op in H. discriminate H. Qed.

Lemma reff622_not629 : ~ @Equation629 Fin5 reff622_inst.
Proof. unfold Equation629. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff622_inst, reff622_op in H. discriminate H. Qed.

Lemma reff622_not630 : ~ @Equation630 Fin5 reff622_inst.
Proof. unfold Equation630. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff622_inst, reff622_op in H. discriminate H. Qed.

Lemma reff622_not632 : ~ @Equation632 Fin5 reff622_inst.
Proof. unfold Equation632. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff622_inst, reff622_op in H. discriminate H. Qed.

Lemma reff622_not633 : ~ @Equation633 Fin5 reff622_inst.
Proof. unfold Equation633. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff622_inst, reff622_op in H. discriminate H. Qed.

Lemma reff622_not639 : ~ @Equation639 Fin5 reff622_inst.
Proof. unfold Equation639. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff622_inst, reff622_op in H. discriminate H. Qed.

Lemma reff622_not640 : ~ @Equation640 Fin5 reff622_inst.
Proof. unfold Equation640. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff622_inst, reff622_op in H. discriminate H. Qed.

Lemma reff622_not642 : ~ @Equation642 Fin5 reff622_inst.
Proof. unfold Equation642. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff622_inst, reff622_op in H. discriminate H. Qed.

Lemma reff622_not643 : ~ @Equation643 Fin5 reff622_inst.
Proof. unfold Equation643. intro H. specialize (H F5_0 F5_2). unfold magma_op, reff622_inst, reff622_op in H. discriminate H. Qed.

Lemma reff622_not666 : ~ @Equation666 Fin5 reff622_inst.
Proof. unfold Equation666. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff622_inst, reff622_op in H. discriminate H. Qed.

Lemma reff622_not667 : ~ @Equation667 Fin5 reff622_inst.
Proof. unfold Equation667. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff622_inst, reff622_op in H. discriminate H. Qed.

Lemma reff622_not669 : ~ @Equation669 Fin5 reff622_inst.
Proof. unfold Equation669. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff622_inst, reff622_op in H. discriminate H. Qed.

Lemma reff622_not670 : ~ @Equation670 Fin5 reff622_inst.
Proof. unfold Equation670. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff622_inst, reff622_op in H. discriminate H. Qed.

Lemma reff622_not676 : ~ @Equation676 Fin5 reff622_inst.
Proof. unfold Equation676. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff622_inst, reff622_op in H. discriminate H. Qed.

Lemma reff622_not677 : ~ @Equation677 Fin5 reff622_inst.
Proof. unfold Equation677. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff622_inst, reff622_op in H. discriminate H. Qed.

Lemma reff622_not679 : ~ @Equation679 Fin5 reff622_inst.
Proof. unfold Equation679. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff622_inst, reff622_op in H. discriminate H. Qed.

Lemma reff622_not680 : ~ @Equation680 Fin5 reff622_inst.
Proof. unfold Equation680. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff622_inst, reff622_op in H. discriminate H. Qed.

Lemma reff622_not703 : ~ @Equation703 Fin5 reff622_inst.
Proof. unfold Equation703. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff622_inst, reff622_op in H. discriminate H. Qed.

Lemma reff622_not704 : ~ @Equation704 Fin5 reff622_inst.
Proof. unfold Equation704. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff622_inst, reff622_op in H. discriminate H. Qed.

Lemma reff622_not706 : ~ @Equation706 Fin5 reff622_inst.
Proof. unfold Equation706. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff622_inst, reff622_op in H. discriminate H. Qed.

Lemma reff622_not707 : ~ @Equation707 Fin5 reff622_inst.
Proof. unfold Equation707. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff622_inst, reff622_op in H. discriminate H. Qed.

Lemma reff622_not713 : ~ @Equation713 Fin5 reff622_inst.
Proof. unfold Equation713. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff622_inst, reff622_op in H. discriminate H. Qed.

Lemma reff622_not714 : ~ @Equation714 Fin5 reff622_inst.
Proof. unfold Equation714. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff622_inst, reff622_op in H. discriminate H. Qed.

Lemma reff622_not716 : ~ @Equation716 Fin5 reff622_inst.
Proof. unfold Equation716. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff622_inst, reff622_op in H. discriminate H. Qed.

Lemma reff622_not818 : ~ @Equation818 Fin5 reff622_inst.
Proof. unfold Equation818. intro H. specialize (H F5_0 F5_2). unfold magma_op, reff622_inst, reff622_op in H. discriminate H. Qed.

Lemma reff622_not819 : ~ @Equation819 Fin5 reff622_inst.
Proof. unfold Equation819. intro H. specialize (H F5_0 F5_4). unfold magma_op, reff622_inst, reff622_op in H. discriminate H. Qed.

Lemma reff622_not820 : ~ @Equation820 Fin5 reff622_inst.
Proof. unfold Equation820. intro H. specialize (H F5_0 F5_2). unfold magma_op, reff622_inst, reff622_op in H. discriminate H. Qed.

Lemma reff622_not822 : ~ @Equation822 Fin5 reff622_inst.
Proof. unfold Equation822. intro H. specialize (H F5_0 F5_2). unfold magma_op, reff622_inst, reff622_op in H. discriminate H. Qed.

Lemma reff622_not823 : ~ @Equation823 Fin5 reff622_inst.
Proof. unfold Equation823. intro H. specialize (H F5_0 F5_2). unfold magma_op, reff622_inst, reff622_op in H. discriminate H. Qed.

Lemma reff622_not825 : ~ @Equation825 Fin5 reff622_inst.
Proof. unfold Equation825. intro H. specialize (H F5_0 F5_2). unfold magma_op, reff622_inst, reff622_op in H. discriminate H. Qed.

Lemma reff622_not826 : ~ @Equation826 Fin5 reff622_inst.
Proof. unfold Equation826. intro H. specialize (H F5_0 F5_2). unfold magma_op, reff622_inst, reff622_op in H. discriminate H. Qed.

Lemma reff622_not832 : ~ @Equation832 Fin5 reff622_inst.
Proof. unfold Equation832. intro H. specialize (H F5_0 F5_4). unfold magma_op, reff622_inst, reff622_op in H. discriminate H. Qed.

Lemma reff622_not835 : ~ @Equation835 Fin5 reff622_inst.
Proof. unfold Equation835. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff622_inst, reff622_op in H. discriminate H. Qed.

Lemma reff622_not836 : ~ @Equation836 Fin5 reff622_inst.
Proof. unfold Equation836. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff622_inst, reff622_op in H. discriminate H. Qed.

Lemma reff622_not842 : ~ @Equation842 Fin5 reff622_inst.
Proof. unfold Equation842. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff622_inst, reff622_op in H. discriminate H. Qed.

Lemma reff622_not843 : ~ @Equation843 Fin5 reff622_inst.
Proof. unfold Equation843. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff622_inst, reff622_op in H. discriminate H. Qed.

Lemma reff622_not845 : ~ @Equation845 Fin5 reff622_inst.
Proof. unfold Equation845. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff622_inst, reff622_op in H. discriminate H. Qed.

Lemma reff622_not846 : ~ @Equation846 Fin5 reff622_inst.
Proof. unfold Equation846. intro H. specialize (H F5_0 F5_2). unfold magma_op, reff622_inst, reff622_op in H. discriminate H. Qed.

Lemma reff622_not869 : ~ @Equation869 Fin5 reff622_inst.
Proof. unfold Equation869. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff622_inst, reff622_op in H. discriminate H. Qed.

Lemma reff622_not870 : ~ @Equation870 Fin5 reff622_inst.
Proof. unfold Equation870. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff622_inst, reff622_op in H. discriminate H. Qed.

Lemma reff622_not872 : ~ @Equation872 Fin5 reff622_inst.
Proof. unfold Equation872. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff622_inst, reff622_op in H. discriminate H. Qed.

Lemma reff622_not873 : ~ @Equation873 Fin5 reff622_inst.
Proof. unfold Equation873. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff622_inst, reff622_op in H. discriminate H. Qed.

Lemma reff622_not879 : ~ @Equation879 Fin5 reff622_inst.
Proof. unfold Equation879. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff622_inst, reff622_op in H. discriminate H. Qed.

Lemma reff622_not880 : ~ @Equation880 Fin5 reff622_inst.
Proof. unfold Equation880. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff622_inst, reff622_op in H. discriminate H. Qed.

Lemma reff622_not882 : ~ @Equation882 Fin5 reff622_inst.
Proof. unfold Equation882. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff622_inst, reff622_op in H. discriminate H. Qed.

Lemma reff622_not883 : ~ @Equation883 Fin5 reff622_inst.
Proof. unfold Equation883. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff622_inst, reff622_op in H. discriminate H. Qed.

Lemma reff622_not906 : ~ @Equation906 Fin5 reff622_inst.
Proof. unfold Equation906. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff622_inst, reff622_op in H. discriminate H. Qed.

Lemma reff622_not907 : ~ @Equation907 Fin5 reff622_inst.
Proof. unfold Equation907. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff622_inst, reff622_op in H. discriminate H. Qed.

Lemma reff622_not909 : ~ @Equation909 Fin5 reff622_inst.
Proof. unfold Equation909. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff622_inst, reff622_op in H. discriminate H. Qed.

Lemma reff622_not910 : ~ @Equation910 Fin5 reff622_inst.
Proof. unfold Equation910. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff622_inst, reff622_op in H. discriminate H. Qed.

Lemma reff622_not916 : ~ @Equation916 Fin5 reff622_inst.
Proof. unfold Equation916. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff622_inst, reff622_op in H. discriminate H. Qed.

Lemma reff622_not917 : ~ @Equation917 Fin5 reff622_inst.
Proof. unfold Equation917. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff622_inst, reff622_op in H. discriminate H. Qed.

Lemma reff622_not919 : ~ @Equation919 Fin5 reff622_inst.
Proof. unfold Equation919. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff622_inst, reff622_op in H. discriminate H. Qed.

Lemma reff622_not1021 : ~ @Equation1021 Fin5 reff622_inst.
Proof. unfold Equation1021. intro H. specialize (H F5_0 F5_2). unfold magma_op, reff622_inst, reff622_op in H. discriminate H. Qed.

Lemma reff622_not1022 : ~ @Equation1022 Fin5 reff622_inst.
Proof. unfold Equation1022. intro H. specialize (H F5_0 F5_2). unfold magma_op, reff622_inst, reff622_op in H. discriminate H. Qed.

Lemma reff622_not1023 : ~ @Equation1023 Fin5 reff622_inst.
Proof. unfold Equation1023. intro H. specialize (H F5_0 F5_2). unfold magma_op, reff622_inst, reff622_op in H. discriminate H. Qed.

Lemma reff622_not1025 : ~ @Equation1025 Fin5 reff622_inst.
Proof. unfold Equation1025. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff622_inst, reff622_op in H. discriminate H. Qed.

Lemma reff622_not1026 : ~ @Equation1026 Fin5 reff622_inst.
Proof. unfold Equation1026. intro H. specialize (H F5_0 F5_4). unfold magma_op, reff622_inst, reff622_op in H. discriminate H. Qed.

Lemma reff622_not1028 : ~ @Equation1028 Fin5 reff622_inst.
Proof. unfold Equation1028. intro H. specialize (H F5_0 F5_2). unfold magma_op, reff622_inst, reff622_op in H. discriminate H. Qed.

Lemma reff622_not1029 : ~ @Equation1029 Fin5 reff622_inst.
Proof. unfold Equation1029. intro H. specialize (H F5_0 F5_2). unfold magma_op, reff622_inst, reff622_op in H. discriminate H. Qed.

Lemma reff622_not1035 : ~ @Equation1035 Fin5 reff622_inst.
Proof. unfold Equation1035. intro H. specialize (H F5_0 F5_4). unfold magma_op, reff622_inst, reff622_op in H. discriminate H. Qed.

Lemma reff622_not1036 : ~ @Equation1036 Fin5 reff622_inst.
Proof. unfold Equation1036. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff622_inst, reff622_op in H. discriminate H. Qed.

Lemma reff622_not1038 : ~ @Equation1038 Fin5 reff622_inst.
Proof. unfold Equation1038. intro H. specialize (H F5_0 F5_2). unfold magma_op, reff622_inst, reff622_op in H. discriminate H. Qed.

Lemma reff622_not1039 : ~ @Equation1039 Fin5 reff622_inst.
Proof. unfold Equation1039. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff622_inst, reff622_op in H. discriminate H. Qed.

Lemma reff622_not1045 : ~ @Equation1045 Fin5 reff622_inst.
Proof. unfold Equation1045. intro H. specialize (H F5_0 F5_2). unfold magma_op, reff622_inst, reff622_op in H. discriminate H. Qed.

Lemma reff622_not1046 : ~ @Equation1046 Fin5 reff622_inst.
Proof. unfold Equation1046. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff622_inst, reff622_op in H. discriminate H. Qed.

Lemma reff622_not1048 : ~ @Equation1048 Fin5 reff622_inst.
Proof. unfold Equation1048. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff622_inst, reff622_op in H. discriminate H. Qed.

Lemma reff622_not1049 : ~ @Equation1049 Fin5 reff622_inst.
Proof. unfold Equation1049. intro H. specialize (H F5_0 F5_2). unfold magma_op, reff622_inst, reff622_op in H. discriminate H. Qed.

Lemma reff622_not1072 : ~ @Equation1072 Fin5 reff622_inst.
Proof. unfold Equation1072. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff622_inst, reff622_op in H. discriminate H. Qed.

Lemma reff622_not1073 : ~ @Equation1073 Fin5 reff622_inst.
Proof. unfold Equation1073. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff622_inst, reff622_op in H. discriminate H. Qed.

Lemma reff622_not1075 : ~ @Equation1075 Fin5 reff622_inst.
Proof. unfold Equation1075. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff622_inst, reff622_op in H. discriminate H. Qed.

Lemma reff622_not1076 : ~ @Equation1076 Fin5 reff622_inst.
Proof. unfold Equation1076. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff622_inst, reff622_op in H. discriminate H. Qed.

Lemma reff622_not1082 : ~ @Equation1082 Fin5 reff622_inst.
Proof. unfold Equation1082. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff622_inst, reff622_op in H. discriminate H. Qed.

Lemma reff622_not1083 : ~ @Equation1083 Fin5 reff622_inst.
Proof. unfold Equation1083. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff622_inst, reff622_op in H. discriminate H. Qed.

Lemma reff622_not1085 : ~ @Equation1085 Fin5 reff622_inst.
Proof. unfold Equation1085. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff622_inst, reff622_op in H. discriminate H. Qed.

Lemma reff622_not1086 : ~ @Equation1086 Fin5 reff622_inst.
Proof. unfold Equation1086. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff622_inst, reff622_op in H. discriminate H. Qed.

Lemma reff622_not1109 : ~ @Equation1109 Fin5 reff622_inst.
Proof. unfold Equation1109. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff622_inst, reff622_op in H. discriminate H. Qed.

Lemma reff622_not1110 : ~ @Equation1110 Fin5 reff622_inst.
Proof. unfold Equation1110. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff622_inst, reff622_op in H. discriminate H. Qed.

Lemma reff622_not1112 : ~ @Equation1112 Fin5 reff622_inst.
Proof. unfold Equation1112. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff622_inst, reff622_op in H. discriminate H. Qed.

Lemma reff622_not1113 : ~ @Equation1113 Fin5 reff622_inst.
Proof. unfold Equation1113. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff622_inst, reff622_op in H. discriminate H. Qed.

Lemma reff622_not1119 : ~ @Equation1119 Fin5 reff622_inst.
Proof. unfold Equation1119. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff622_inst, reff622_op in H. discriminate H. Qed.

Lemma reff622_not1120 : ~ @Equation1120 Fin5 reff622_inst.
Proof. unfold Equation1120. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff622_inst, reff622_op in H. discriminate H. Qed.

Lemma reff622_not1122 : ~ @Equation1122 Fin5 reff622_inst.
Proof. unfold Equation1122. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff622_inst, reff622_op in H. discriminate H. Qed.

Lemma reff622_not1224 : ~ @Equation1224 Fin5 reff622_inst.
Proof. unfold Equation1224. intro H. specialize (H F5_0 F5_2). unfold magma_op, reff622_inst, reff622_op in H. discriminate H. Qed.

Lemma reff622_not1225 : ~ @Equation1225 Fin5 reff622_inst.
Proof. unfold Equation1225. intro H. specialize (H F5_0 F5_2). unfold magma_op, reff622_inst, reff622_op in H. discriminate H. Qed.

Lemma reff622_not1226 : ~ @Equation1226 Fin5 reff622_inst.
Proof. unfold Equation1226. intro H. specialize (H F5_0 F5_2). unfold magma_op, reff622_inst, reff622_op in H. discriminate H. Qed.

Lemma reff622_not1229 : ~ @Equation1229 Fin5 reff622_inst.
Proof. unfold Equation1229. intro H. specialize (H F5_0 F5_3). unfold magma_op, reff622_inst, reff622_op in H. discriminate H. Qed.

Lemma reff622_not1231 : ~ @Equation1231 Fin5 reff622_inst.
Proof. unfold Equation1231. intro H. specialize (H F5_0 F5_2). unfold magma_op, reff622_inst, reff622_op in H. discriminate H. Qed.

Lemma reff622_not1232 : ~ @Equation1232 Fin5 reff622_inst.
Proof. unfold Equation1232. intro H. specialize (H F5_0 F5_2). unfold magma_op, reff622_inst, reff622_op in H. discriminate H. Qed.

Lemma reff622_not1238 : ~ @Equation1238 Fin5 reff622_inst.
Proof. unfold Equation1238. intro H. specialize (H F5_0 F5_4). unfold magma_op, reff622_inst, reff622_op in H. discriminate H. Qed.

Lemma reff622_not1239 : ~ @Equation1239 Fin5 reff622_inst.
Proof. unfold Equation1239. intro H. specialize (H F5_0 F5_2). unfold magma_op, reff622_inst, reff622_op in H. discriminate H. Qed.

Lemma reff622_not1241 : ~ @Equation1241 Fin5 reff622_inst.
Proof. unfold Equation1241. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff622_inst, reff622_op in H. discriminate H. Qed.

Lemma reff622_not1242 : ~ @Equation1242 Fin5 reff622_inst.
Proof. unfold Equation1242. intro H. specialize (H F5_0 F5_2). unfold magma_op, reff622_inst, reff622_op in H. discriminate H. Qed.

Lemma reff622_not1248 : ~ @Equation1248 Fin5 reff622_inst.
Proof. unfold Equation1248. intro H. specialize (H F5_0 F5_4). unfold magma_op, reff622_inst, reff622_op in H. discriminate H. Qed.

Lemma reff622_not1249 : ~ @Equation1249 Fin5 reff622_inst.
Proof. unfold Equation1249. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff622_inst, reff622_op in H. discriminate H. Qed.

Lemma reff622_not1251 : ~ @Equation1251 Fin5 reff622_inst.
Proof. unfold Equation1251. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff622_inst, reff622_op in H. discriminate H. Qed.

Lemma reff622_not1252 : ~ @Equation1252 Fin5 reff622_inst.
Proof. unfold Equation1252. intro H. specialize (H F5_0 F5_2). unfold magma_op, reff622_inst, reff622_op in H. discriminate H. Qed.

Lemma reff622_not1275 : ~ @Equation1275 Fin5 reff622_inst.
Proof. unfold Equation1275. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff622_inst, reff622_op in H. discriminate H. Qed.

Lemma reff622_not1276 : ~ @Equation1276 Fin5 reff622_inst.
Proof. unfold Equation1276. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff622_inst, reff622_op in H. discriminate H. Qed.

Lemma reff622_not1278 : ~ @Equation1278 Fin5 reff622_inst.
Proof. unfold Equation1278. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff622_inst, reff622_op in H. discriminate H. Qed.

Lemma reff622_not1279 : ~ @Equation1279 Fin5 reff622_inst.
Proof. unfold Equation1279. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff622_inst, reff622_op in H. discriminate H. Qed.

Lemma reff622_not1285 : ~ @Equation1285 Fin5 reff622_inst.
Proof. unfold Equation1285. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff622_inst, reff622_op in H. discriminate H. Qed.

Lemma reff622_not1286 : ~ @Equation1286 Fin5 reff622_inst.
Proof. unfold Equation1286. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff622_inst, reff622_op in H. discriminate H. Qed.

Lemma reff622_not1288 : ~ @Equation1288 Fin5 reff622_inst.
Proof. unfold Equation1288. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff622_inst, reff622_op in H. discriminate H. Qed.

Lemma reff622_not1289 : ~ @Equation1289 Fin5 reff622_inst.
Proof. unfold Equation1289. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff622_inst, reff622_op in H. discriminate H. Qed.

Lemma reff622_not1312 : ~ @Equation1312 Fin5 reff622_inst.
Proof. unfold Equation1312. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff622_inst, reff622_op in H. discriminate H. Qed.

Lemma reff622_not1313 : ~ @Equation1313 Fin5 reff622_inst.
Proof. unfold Equation1313. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff622_inst, reff622_op in H. discriminate H. Qed.

Lemma reff622_not1315 : ~ @Equation1315 Fin5 reff622_inst.
Proof. unfold Equation1315. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff622_inst, reff622_op in H. discriminate H. Qed.

Lemma reff622_not1316 : ~ @Equation1316 Fin5 reff622_inst.
Proof. unfold Equation1316. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff622_inst, reff622_op in H. discriminate H. Qed.

Lemma reff622_not1322 : ~ @Equation1322 Fin5 reff622_inst.
Proof. unfold Equation1322. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff622_inst, reff622_op in H. discriminate H. Qed.

Lemma reff622_not1323 : ~ @Equation1323 Fin5 reff622_inst.
Proof. unfold Equation1323. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff622_inst, reff622_op in H. discriminate H. Qed.

Lemma reff622_not1325 : ~ @Equation1325 Fin5 reff622_inst.
Proof. unfold Equation1325. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff622_inst, reff622_op in H. discriminate H. Qed.

Lemma reff622_not1427 : ~ @Equation1427 Fin5 reff622_inst.
Proof. unfold Equation1427. intro H. specialize (H F5_0 F5_2). unfold magma_op, reff622_inst, reff622_op in H. discriminate H. Qed.

Lemma reff622_not1428 : ~ @Equation1428 Fin5 reff622_inst.
Proof. unfold Equation1428. intro H. specialize (H F5_0 F5_4). unfold magma_op, reff622_inst, reff622_op in H. discriminate H. Qed.

Lemma reff622_not1429 : ~ @Equation1429 Fin5 reff622_inst.
Proof. unfold Equation1429. intro H. specialize (H F5_0 F5_2). unfold magma_op, reff622_inst, reff622_op in H. discriminate H. Qed.

Lemma reff622_not1431 : ~ @Equation1431 Fin5 reff622_inst.
Proof. unfold Equation1431. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff622_inst, reff622_op in H. discriminate H. Qed.

Lemma reff622_not1432 : ~ @Equation1432 Fin5 reff622_inst.
Proof. unfold Equation1432. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff622_inst, reff622_op in H. discriminate H. Qed.

Lemma reff622_not1434 : ~ @Equation1434 Fin5 reff622_inst.
Proof. unfold Equation1434. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff622_inst, reff622_op in H. discriminate H. Qed.

Lemma reff622_not1435 : ~ @Equation1435 Fin5 reff622_inst.
Proof. unfold Equation1435. intro H. specialize (H F5_0 F5_2). unfold magma_op, reff622_inst, reff622_op in H. discriminate H. Qed.

Lemma reff622_not1441 : ~ @Equation1441 Fin5 reff622_inst.
Proof. unfold Equation1441. intro H. specialize (H F5_0 F5_2). unfold magma_op, reff622_inst, reff622_op in H. discriminate H. Qed.

Lemma reff622_not1442 : ~ @Equation1442 Fin5 reff622_inst.
Proof. unfold Equation1442. intro H. specialize (H F5_0 F5_2). unfold magma_op, reff622_inst, reff622_op in H. discriminate H. Qed.

Lemma reff622_not1444 : ~ @Equation1444 Fin5 reff622_inst.
Proof. unfold Equation1444. intro H. specialize (H F5_0 F5_2). unfold magma_op, reff622_inst, reff622_op in H. discriminate H. Qed.

Lemma reff622_not1445 : ~ @Equation1445 Fin5 reff622_inst.
Proof. unfold Equation1445. intro H. specialize (H F5_0 F5_2). unfold magma_op, reff622_inst, reff622_op in H. discriminate H. Qed.

Lemma reff622_not1451 : ~ @Equation1451 Fin5 reff622_inst.
Proof. unfold Equation1451. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff622_inst, reff622_op in H. discriminate H. Qed.

Lemma reff622_not1452 : ~ @Equation1452 Fin5 reff622_inst.
Proof. unfold Equation1452. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff622_inst, reff622_op in H. discriminate H. Qed.

Lemma reff622_not1454 : ~ @Equation1454 Fin5 reff622_inst.
Proof. unfold Equation1454. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff622_inst, reff622_op in H. discriminate H. Qed.

Lemma reff622_not1455 : ~ @Equation1455 Fin5 reff622_inst.
Proof. unfold Equation1455. intro H. specialize (H F5_0 F5_2). unfold magma_op, reff622_inst, reff622_op in H. discriminate H. Qed.

Lemma reff622_not1478 : ~ @Equation1478 Fin5 reff622_inst.
Proof. unfold Equation1478. intro H. specialize (H F5_0 F5_4). unfold magma_op, reff622_inst, reff622_op in H. discriminate H. Qed.

Lemma reff622_not1481 : ~ @Equation1481 Fin5 reff622_inst.
Proof. unfold Equation1481. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff622_inst, reff622_op in H. discriminate H. Qed.

Lemma reff622_not1488 : ~ @Equation1488 Fin5 reff622_inst.
Proof. unfold Equation1488. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff622_inst, reff622_op in H. discriminate H. Qed.

Lemma reff622_not1489 : ~ @Equation1489 Fin5 reff622_inst.
Proof. unfold Equation1489. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff622_inst, reff622_op in H. discriminate H. Qed.

Lemma reff622_not1491 : ~ @Equation1491 Fin5 reff622_inst.
Proof. unfold Equation1491. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff622_inst, reff622_op in H. discriminate H. Qed.

Lemma reff622_not1492 : ~ @Equation1492 Fin5 reff622_inst.
Proof. unfold Equation1492. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff622_inst, reff622_op in H. discriminate H. Qed.

Lemma reff622_not1515 : ~ @Equation1515 Fin5 reff622_inst.
Proof. unfold Equation1515. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff622_inst, reff622_op in H. discriminate H. Qed.

Lemma reff622_not1516 : ~ @Equation1516 Fin5 reff622_inst.
Proof. unfold Equation1516. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff622_inst, reff622_op in H. discriminate H. Qed.

Lemma reff622_not1518 : ~ @Equation1518 Fin5 reff622_inst.
Proof. unfold Equation1518. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff622_inst, reff622_op in H. discriminate H. Qed.

Lemma reff622_not1519 : ~ @Equation1519 Fin5 reff622_inst.
Proof. unfold Equation1519. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff622_inst, reff622_op in H. discriminate H. Qed.

Lemma reff622_not1525 : ~ @Equation1525 Fin5 reff622_inst.
Proof. unfold Equation1525. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff622_inst, reff622_op in H. discriminate H. Qed.

Lemma reff622_not1526 : ~ @Equation1526 Fin5 reff622_inst.
Proof. unfold Equation1526. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff622_inst, reff622_op in H. discriminate H. Qed.

Lemma reff622_not1528 : ~ @Equation1528 Fin5 reff622_inst.
Proof. unfold Equation1528. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff622_inst, reff622_op in H. discriminate H. Qed.

Lemma reff622_not1630 : ~ @Equation1630 Fin5 reff622_inst.
Proof. unfold Equation1630. intro H. specialize (H F5_0 F5_2). unfold magma_op, reff622_inst, reff622_op in H. discriminate H. Qed.

Lemma reff622_not1631 : ~ @Equation1631 Fin5 reff622_inst.
Proof. unfold Equation1631. intro H. specialize (H F5_0 F5_2). unfold magma_op, reff622_inst, reff622_op in H. discriminate H. Qed.

Lemma reff622_not1632 : ~ @Equation1632 Fin5 reff622_inst.
Proof. unfold Equation1632. intro H. specialize (H F5_0 F5_2). unfold magma_op, reff622_inst, reff622_op in H. discriminate H. Qed.

Lemma reff622_not1634 : ~ @Equation1634 Fin5 reff622_inst.
Proof. unfold Equation1634. intro H. specialize (H F5_0 F5_4). unfold magma_op, reff622_inst, reff622_op in H. discriminate H. Qed.

Lemma reff622_not1635 : ~ @Equation1635 Fin5 reff622_inst.
Proof. unfold Equation1635. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff622_inst, reff622_op in H. discriminate H. Qed.

Lemma reff622_not1637 : ~ @Equation1637 Fin5 reff622_inst.
Proof. unfold Equation1637. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff622_inst, reff622_op in H. discriminate H. Qed.

Lemma reff622_not1638 : ~ @Equation1638 Fin5 reff622_inst.
Proof. unfold Equation1638. intro H. specialize (H F5_0 F5_2). unfold magma_op, reff622_inst, reff622_op in H. discriminate H. Qed.

Lemma reff622_not1644 : ~ @Equation1644 Fin5 reff622_inst.
Proof. unfold Equation1644. intro H. specialize (H F5_0 F5_2). unfold magma_op, reff622_inst, reff622_op in H. discriminate H. Qed.

Lemma reff622_not1645 : ~ @Equation1645 Fin5 reff622_inst.
Proof. unfold Equation1645. intro H. specialize (H F5_0 F5_2). unfold magma_op, reff622_inst, reff622_op in H. discriminate H. Qed.

Lemma reff622_not1647 : ~ @Equation1647 Fin5 reff622_inst.
Proof. unfold Equation1647. intro H. specialize (H F5_0 F5_2). unfold magma_op, reff622_inst, reff622_op in H. discriminate H. Qed.

Lemma reff622_not1648 : ~ @Equation1648 Fin5 reff622_inst.
Proof. unfold Equation1648. intro H. specialize (H F5_0 F5_2). unfold magma_op, reff622_inst, reff622_op in H. discriminate H. Qed.

Lemma reff622_not1654 : ~ @Equation1654 Fin5 reff622_inst.
Proof. unfold Equation1654. intro H. specialize (H F5_0 F5_2). unfold magma_op, reff622_inst, reff622_op in H. discriminate H. Qed.

Lemma reff622_not1655 : ~ @Equation1655 Fin5 reff622_inst.
Proof. unfold Equation1655. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff622_inst, reff622_op in H. discriminate H. Qed.

Lemma reff622_not1657 : ~ @Equation1657 Fin5 reff622_inst.
Proof. unfold Equation1657. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff622_inst, reff622_op in H. discriminate H. Qed.

Lemma reff622_not1658 : ~ @Equation1658 Fin5 reff622_inst.
Proof. unfold Equation1658. intro H. specialize (H F5_0 F5_2). unfold magma_op, reff622_inst, reff622_op in H. discriminate H. Qed.

Lemma reff622_not1681 : ~ @Equation1681 Fin5 reff622_inst.
Proof. unfold Equation1681. intro H. specialize (H F5_0 F5_4). unfold magma_op, reff622_inst, reff622_op in H. discriminate H. Qed.

Lemma reff622_not1684 : ~ @Equation1684 Fin5 reff622_inst.
Proof. unfold Equation1684. intro H. specialize (H F5_0 F5_2). unfold magma_op, reff622_inst, reff622_op in H. discriminate H. Qed.

Lemma reff622_not1685 : ~ @Equation1685 Fin5 reff622_inst.
Proof. unfold Equation1685. intro H. specialize (H F5_0 F5_3). unfold magma_op, reff622_inst, reff622_op in H. discriminate H. Qed.

Lemma reff622_not1691 : ~ @Equation1691 Fin5 reff622_inst.
Proof. unfold Equation1691. intro H. specialize (H F5_0 F5_4). unfold magma_op, reff622_inst, reff622_op in H. discriminate H. Qed.

Lemma reff622_not1692 : ~ @Equation1692 Fin5 reff622_inst.
Proof. unfold Equation1692. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff622_inst, reff622_op in H. discriminate H. Qed.

Lemma reff622_not1694 : ~ @Equation1694 Fin5 reff622_inst.
Proof. unfold Equation1694. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff622_inst, reff622_op in H. discriminate H. Qed.

Lemma reff622_not1695 : ~ @Equation1695 Fin5 reff622_inst.
Proof. unfold Equation1695. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff622_inst, reff622_op in H. discriminate H. Qed.

Lemma reff622_not1718 : ~ @Equation1718 Fin5 reff622_inst.
Proof. unfold Equation1718. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff622_inst, reff622_op in H. discriminate H. Qed.

Lemma reff622_not1719 : ~ @Equation1719 Fin5 reff622_inst.
Proof. unfold Equation1719. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff622_inst, reff622_op in H. discriminate H. Qed.

Lemma reff622_not1721 : ~ @Equation1721 Fin5 reff622_inst.
Proof. unfold Equation1721. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff622_inst, reff622_op in H. discriminate H. Qed.

Lemma reff622_not1722 : ~ @Equation1722 Fin5 reff622_inst.
Proof. unfold Equation1722. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff622_inst, reff622_op in H. discriminate H. Qed.

Lemma reff622_not1728 : ~ @Equation1728 Fin5 reff622_inst.
Proof. unfold Equation1728. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff622_inst, reff622_op in H. discriminate H. Qed.

Lemma reff622_not1729 : ~ @Equation1729 Fin5 reff622_inst.
Proof. unfold Equation1729. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff622_inst, reff622_op in H. discriminate H. Qed.

Lemma reff622_not1731 : ~ @Equation1731 Fin5 reff622_inst.
Proof. unfold Equation1731. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff622_inst, reff622_op in H. discriminate H. Qed.

Lemma reff622_not1833 : ~ @Equation1833 Fin5 reff622_inst.
Proof. unfold Equation1833. intro H. specialize (H F5_0 F5_2). unfold magma_op, reff622_inst, reff622_op in H. discriminate H. Qed.

Lemma reff622_not1834 : ~ @Equation1834 Fin5 reff622_inst.
Proof. unfold Equation1834. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff622_inst, reff622_op in H. discriminate H. Qed.

Lemma reff622_not1835 : ~ @Equation1835 Fin5 reff622_inst.
Proof. unfold Equation1835. intro H. specialize (H F5_0 F5_2). unfold magma_op, reff622_inst, reff622_op in H. discriminate H. Qed.

Lemma reff622_not1837 : ~ @Equation1837 Fin5 reff622_inst.
Proof. unfold Equation1837. intro H. specialize (H F5_0 F5_2). unfold magma_op, reff622_inst, reff622_op in H. discriminate H. Qed.

Lemma reff622_not1838 : ~ @Equation1838 Fin5 reff622_inst.
Proof. unfold Equation1838. intro H. specialize (H F5_0 F5_2). unfold magma_op, reff622_inst, reff622_op in H. discriminate H. Qed.

Lemma reff622_not1840 : ~ @Equation1840 Fin5 reff622_inst.
Proof. unfold Equation1840. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff622_inst, reff622_op in H. discriminate H. Qed.

Lemma reff622_not1841 : ~ @Equation1841 Fin5 reff622_inst.
Proof. unfold Equation1841. intro H. specialize (H F5_0 F5_2). unfold magma_op, reff622_inst, reff622_op in H. discriminate H. Qed.

Lemma reff622_not1847 : ~ @Equation1847 Fin5 reff622_inst.
Proof. unfold Equation1847. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff622_inst, reff622_op in H. discriminate H. Qed.

Lemma reff622_not1848 : ~ @Equation1848 Fin5 reff622_inst.
Proof. unfold Equation1848. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff622_inst, reff622_op in H. discriminate H. Qed.

Lemma reff622_not1850 : ~ @Equation1850 Fin5 reff622_inst.
Proof. unfold Equation1850. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff622_inst, reff622_op in H. discriminate H. Qed.

Lemma reff622_not1851 : ~ @Equation1851 Fin5 reff622_inst.
Proof. unfold Equation1851. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff622_inst, reff622_op in H. discriminate H. Qed.

Lemma reff622_not1857 : ~ @Equation1857 Fin5 reff622_inst.
Proof. unfold Equation1857. intro H. specialize (H F5_0 F5_2). unfold magma_op, reff622_inst, reff622_op in H. discriminate H. Qed.

Lemma reff622_not1858 : ~ @Equation1858 Fin5 reff622_inst.
Proof. unfold Equation1858. intro H. specialize (H F5_0 F5_2). unfold magma_op, reff622_inst, reff622_op in H. discriminate H. Qed.

Lemma reff622_not1860 : ~ @Equation1860 Fin5 reff622_inst.
Proof. unfold Equation1860. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff622_inst, reff622_op in H. discriminate H. Qed.

Lemma reff622_not1861 : ~ @Equation1861 Fin5 reff622_inst.
Proof. unfold Equation1861. intro H. specialize (H F5_0 F5_2). unfold magma_op, reff622_inst, reff622_op in H. discriminate H. Qed.

Lemma reff622_not1884 : ~ @Equation1884 Fin5 reff622_inst.
Proof. unfold Equation1884. intro H. specialize (H F5_0 F5_4). unfold magma_op, reff622_inst, reff622_op in H. discriminate H. Qed.

Lemma reff622_not1887 : ~ @Equation1887 Fin5 reff622_inst.
Proof. unfold Equation1887. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff622_inst, reff622_op in H. discriminate H. Qed.

Lemma reff622_not1888 : ~ @Equation1888 Fin5 reff622_inst.
Proof. unfold Equation1888. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff622_inst, reff622_op in H. discriminate H. Qed.

Lemma reff622_not1894 : ~ @Equation1894 Fin5 reff622_inst.
Proof. unfold Equation1894. intro H. specialize (H F5_0 F5_2). unfold magma_op, reff622_inst, reff622_op in H. discriminate H. Qed.

Lemma reff622_not1895 : ~ @Equation1895 Fin5 reff622_inst.
Proof. unfold Equation1895. intro H. specialize (H F5_0 F5_2). unfold magma_op, reff622_inst, reff622_op in H. discriminate H. Qed.

Lemma reff622_not1897 : ~ @Equation1897 Fin5 reff622_inst.
Proof. unfold Equation1897. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff622_inst, reff622_op in H. discriminate H. Qed.

Lemma reff622_not1898 : ~ @Equation1898 Fin5 reff622_inst.
Proof. unfold Equation1898. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff622_inst, reff622_op in H. discriminate H. Qed.

Lemma reff622_not1921 : ~ @Equation1921 Fin5 reff622_inst.
Proof. unfold Equation1921. intro H. specialize (H F5_0 F5_2). unfold magma_op, reff622_inst, reff622_op in H. discriminate H. Qed.

Lemma reff622_not1922 : ~ @Equation1922 Fin5 reff622_inst.
Proof. unfold Equation1922. intro H. specialize (H F5_0 F5_2). unfold magma_op, reff622_inst, reff622_op in H. discriminate H. Qed.

Lemma reff622_not1924 : ~ @Equation1924 Fin5 reff622_inst.
Proof. unfold Equation1924. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff622_inst, reff622_op in H. discriminate H. Qed.

Lemma reff622_not1925 : ~ @Equation1925 Fin5 reff622_inst.
Proof. unfold Equation1925. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff622_inst, reff622_op in H. discriminate H. Qed.

Lemma reff622_not1931 : ~ @Equation1931 Fin5 reff622_inst.
Proof. unfold Equation1931. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff622_inst, reff622_op in H. discriminate H. Qed.

Lemma reff622_not1932 : ~ @Equation1932 Fin5 reff622_inst.
Proof. unfold Equation1932. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff622_inst, reff622_op in H. discriminate H. Qed.

Lemma reff622_not1934 : ~ @Equation1934 Fin5 reff622_inst.
Proof. unfold Equation1934. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff622_inst, reff622_op in H. discriminate H. Qed.

Lemma reff622_not2036 : ~ @Equation2036 Fin5 reff622_inst.
Proof. unfold Equation2036. intro H. specialize (H F5_0 F5_2). unfold magma_op, reff622_inst, reff622_op in H. discriminate H. Qed.

Lemma reff622_not2037 : ~ @Equation2037 Fin5 reff622_inst.
Proof. unfold Equation2037. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff622_inst, reff622_op in H. discriminate H. Qed.

Lemma reff622_not2038 : ~ @Equation2038 Fin5 reff622_inst.
Proof. unfold Equation2038. intro H. specialize (H F5_0 F5_2). unfold magma_op, reff622_inst, reff622_op in H. discriminate H. Qed.

Lemma reff622_not2040 : ~ @Equation2040 Fin5 reff622_inst.
Proof. unfold Equation2040. intro H. specialize (H F5_0 F5_2). unfold magma_op, reff622_inst, reff622_op in H. discriminate H. Qed.

Lemma reff622_not2041 : ~ @Equation2041 Fin5 reff622_inst.
Proof. unfold Equation2041. intro H. specialize (H F5_0 F5_2). unfold magma_op, reff622_inst, reff622_op in H. discriminate H. Qed.

Lemma reff622_not2043 : ~ @Equation2043 Fin5 reff622_inst.
Proof. unfold Equation2043. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff622_inst, reff622_op in H. discriminate H. Qed.

Lemma reff622_not2044 : ~ @Equation2044 Fin5 reff622_inst.
Proof. unfold Equation2044. intro H. specialize (H F5_0 F5_2). unfold magma_op, reff622_inst, reff622_op in H. discriminate H. Qed.

Lemma reff622_not2051 : ~ @Equation2051 Fin5 reff622_inst.
Proof. unfold Equation2051. intro H. specialize (H F5_0 F5_3). unfold magma_op, reff622_inst, reff622_op in H. discriminate H. Qed.

Lemma reff622_not2053 : ~ @Equation2053 Fin5 reff622_inst.
Proof. unfold Equation2053. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff622_inst, reff622_op in H. discriminate H. Qed.

Lemma reff622_not2054 : ~ @Equation2054 Fin5 reff622_inst.
Proof. unfold Equation2054. intro H. specialize (H F5_0 F5_3). unfold magma_op, reff622_inst, reff622_op in H. discriminate H. Qed.

Lemma reff622_not2060 : ~ @Equation2060 Fin5 reff622_inst.
Proof. unfold Equation2060. intro H. specialize (H F5_0 F5_2). unfold magma_op, reff622_inst, reff622_op in H. discriminate H. Qed.

Lemma reff622_not2061 : ~ @Equation2061 Fin5 reff622_inst.
Proof. unfold Equation2061. intro H. specialize (H F5_0 F5_2). unfold magma_op, reff622_inst, reff622_op in H. discriminate H. Qed.

Lemma reff622_not2063 : ~ @Equation2063 Fin5 reff622_inst.
Proof. unfold Equation2063. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff622_inst, reff622_op in H. discriminate H. Qed.

Lemma reff622_not2064 : ~ @Equation2064 Fin5 reff622_inst.
Proof. unfold Equation2064. intro H. specialize (H F5_0 F5_2). unfold magma_op, reff622_inst, reff622_op in H. discriminate H. Qed.

Lemma reff622_not2087 : ~ @Equation2087 Fin5 reff622_inst.
Proof. unfold Equation2087. intro H. specialize (H F5_0 F5_4). unfold magma_op, reff622_inst, reff622_op in H. discriminate H. Qed.

Lemma reff622_not2088 : ~ @Equation2088 Fin5 reff622_inst.
Proof. unfold Equation2088. intro H. specialize (H F5_0 F5_2). unfold magma_op, reff622_inst, reff622_op in H. discriminate H. Qed.

Lemma reff622_not2090 : ~ @Equation2090 Fin5 reff622_inst.
Proof. unfold Equation2090. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff622_inst, reff622_op in H. discriminate H. Qed.

Lemma reff622_not2091 : ~ @Equation2091 Fin5 reff622_inst.
Proof. unfold Equation2091. intro H. specialize (H F5_0 F5_2). unfold magma_op, reff622_inst, reff622_op in H. discriminate H. Qed.

Lemma reff622_not2097 : ~ @Equation2097 Fin5 reff622_inst.
Proof. unfold Equation2097. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff622_inst, reff622_op in H. discriminate H. Qed.

Lemma reff622_not2098 : ~ @Equation2098 Fin5 reff622_inst.
Proof. unfold Equation2098. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff622_inst, reff622_op in H. discriminate H. Qed.

Lemma reff622_not2100 : ~ @Equation2100 Fin5 reff622_inst.
Proof. unfold Equation2100. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff622_inst, reff622_op in H. discriminate H. Qed.

Lemma reff622_not2101 : ~ @Equation2101 Fin5 reff622_inst.
Proof. unfold Equation2101. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff622_inst, reff622_op in H. discriminate H. Qed.

Lemma reff622_not2124 : ~ @Equation2124 Fin5 reff622_inst.
Proof. unfold Equation2124. intro H. specialize (H F5_0 F5_4). unfold magma_op, reff622_inst, reff622_op in H. discriminate H. Qed.

Lemma reff622_not2127 : ~ @Equation2127 Fin5 reff622_inst.
Proof. unfold Equation2127. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff622_inst, reff622_op in H. discriminate H. Qed.

Lemma reff622_not2128 : ~ @Equation2128 Fin5 reff622_inst.
Proof. unfold Equation2128. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff622_inst, reff622_op in H. discriminate H. Qed.

Lemma reff622_not2134 : ~ @Equation2134 Fin5 reff622_inst.
Proof. unfold Equation2134. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff622_inst, reff622_op in H. discriminate H. Qed.

Lemma reff622_not2135 : ~ @Equation2135 Fin5 reff622_inst.
Proof. unfold Equation2135. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff622_inst, reff622_op in H. discriminate H. Qed.

Lemma reff622_not2137 : ~ @Equation2137 Fin5 reff622_inst.
Proof. unfold Equation2137. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff622_inst, reff622_op in H. discriminate H. Qed.

Lemma reff622_not2239 : ~ @Equation2239 Fin5 reff622_inst.
Proof. unfold Equation2239. intro H. specialize (H F5_0 F5_2). unfold magma_op, reff622_inst, reff622_op in H. discriminate H. Qed.

Lemma reff622_not2240 : ~ @Equation2240 Fin5 reff622_inst.
Proof. unfold Equation2240. intro H. specialize (H F5_0 F5_2). unfold magma_op, reff622_inst, reff622_op in H. discriminate H. Qed.

Lemma reff622_not2241 : ~ @Equation2241 Fin5 reff622_inst.
Proof. unfold Equation2241. intro H. specialize (H F5_0 F5_2). unfold magma_op, reff622_inst, reff622_op in H. discriminate H. Qed.

Lemma reff622_not2243 : ~ @Equation2243 Fin5 reff622_inst.
Proof. unfold Equation2243. intro H. specialize (H F5_0 F5_4). unfold magma_op, reff622_inst, reff622_op in H. discriminate H. Qed.

Lemma reff622_not2244 : ~ @Equation2244 Fin5 reff622_inst.
Proof. unfold Equation2244. intro H. specialize (H F5_0 F5_2). unfold magma_op, reff622_inst, reff622_op in H. discriminate H. Qed.

Lemma reff622_not2246 : ~ @Equation2246 Fin5 reff622_inst.
Proof. unfold Equation2246. intro H. specialize (H F5_0 F5_2). unfold magma_op, reff622_inst, reff622_op in H. discriminate H. Qed.

Lemma reff622_not2247 : ~ @Equation2247 Fin5 reff622_inst.
Proof. unfold Equation2247. intro H. specialize (H F5_0 F5_2). unfold magma_op, reff622_inst, reff622_op in H. discriminate H. Qed.

Lemma reff622_not2253 : ~ @Equation2253 Fin5 reff622_inst.
Proof. unfold Equation2253. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff622_inst, reff622_op in H. discriminate H. Qed.

Lemma reff622_not2254 : ~ @Equation2254 Fin5 reff622_inst.
Proof. unfold Equation2254. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff622_inst, reff622_op in H. discriminate H. Qed.

Lemma reff622_not2256 : ~ @Equation2256 Fin5 reff622_inst.
Proof. unfold Equation2256. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff622_inst, reff622_op in H. discriminate H. Qed.

Lemma reff622_not2257 : ~ @Equation2257 Fin5 reff622_inst.
Proof. unfold Equation2257. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff622_inst, reff622_op in H. discriminate H. Qed.

Lemma reff622_not2263 : ~ @Equation2263 Fin5 reff622_inst.
Proof. unfold Equation2263. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff622_inst, reff622_op in H. discriminate H. Qed.

Lemma reff622_not2264 : ~ @Equation2264 Fin5 reff622_inst.
Proof. unfold Equation2264. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff622_inst, reff622_op in H. discriminate H. Qed.

Lemma reff622_not2266 : ~ @Equation2266 Fin5 reff622_inst.
Proof. unfold Equation2266. intro H. specialize (H F5_0 F5_2). unfold magma_op, reff622_inst, reff622_op in H. discriminate H. Qed.

Lemma reff622_not2267 : ~ @Equation2267 Fin5 reff622_inst.
Proof. unfold Equation2267. intro H. specialize (H F5_0 F5_2). unfold magma_op, reff622_inst, reff622_op in H. discriminate H. Qed.

Lemma reff622_not2290 : ~ @Equation2290 Fin5 reff622_inst.
Proof. unfold Equation2290. intro H. specialize (H F5_0 F5_4). unfold magma_op, reff622_inst, reff622_op in H. discriminate H. Qed.

Lemma reff622_not2291 : ~ @Equation2291 Fin5 reff622_inst.
Proof. unfold Equation2291. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff622_inst, reff622_op in H. discriminate H. Qed.

Lemma reff622_not2293 : ~ @Equation2293 Fin5 reff622_inst.
Proof. unfold Equation2293. intro H. specialize (H F5_0 F5_2). unfold magma_op, reff622_inst, reff622_op in H. discriminate H. Qed.

Lemma reff622_not2294 : ~ @Equation2294 Fin5 reff622_inst.
Proof. unfold Equation2294. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff622_inst, reff622_op in H. discriminate H. Qed.

Lemma reff622_not2300 : ~ @Equation2300 Fin5 reff622_inst.
Proof. unfold Equation2300. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff622_inst, reff622_op in H. discriminate H. Qed.

Lemma reff622_not2301 : ~ @Equation2301 Fin5 reff622_inst.
Proof. unfold Equation2301. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff622_inst, reff622_op in H. discriminate H. Qed.

Lemma reff622_not2303 : ~ @Equation2303 Fin5 reff622_inst.
Proof. unfold Equation2303. intro H. specialize (H F5_0 F5_2). unfold magma_op, reff622_inst, reff622_op in H. discriminate H. Qed.

Lemma reff622_not2304 : ~ @Equation2304 Fin5 reff622_inst.
Proof. unfold Equation2304. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff622_inst, reff622_op in H. discriminate H. Qed.

Lemma reff622_not2327 : ~ @Equation2327 Fin5 reff622_inst.
Proof. unfold Equation2327. intro H. specialize (H F5_0 F5_2). unfold magma_op, reff622_inst, reff622_op in H. discriminate H. Qed.

Lemma reff622_not2328 : ~ @Equation2328 Fin5 reff622_inst.
Proof. unfold Equation2328. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff622_inst, reff622_op in H. discriminate H. Qed.

Lemma reff622_not2330 : ~ @Equation2330 Fin5 reff622_inst.
Proof. unfold Equation2330. intro H. specialize (H F5_0 F5_2). unfold magma_op, reff622_inst, reff622_op in H. discriminate H. Qed.

Lemma reff622_not2331 : ~ @Equation2331 Fin5 reff622_inst.
Proof. unfold Equation2331. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff622_inst, reff622_op in H. discriminate H. Qed.

Lemma reff622_not2337 : ~ @Equation2337 Fin5 reff622_inst.
Proof. unfold Equation2337. intro H. specialize (H F5_0 F5_2). unfold magma_op, reff622_inst, reff622_op in H. discriminate H. Qed.

Lemma reff622_not2338 : ~ @Equation2338 Fin5 reff622_inst.
Proof. unfold Equation2338. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff622_inst, reff622_op in H. discriminate H. Qed.

Lemma reff622_not2340 : ~ @Equation2340 Fin5 reff622_inst.
Proof. unfold Equation2340. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff622_inst, reff622_op in H. discriminate H. Qed.

Lemma reff622_not2442 : ~ @Equation2442 Fin5 reff622_inst.
Proof. unfold Equation2442. intro H. specialize (H F5_0 F5_2). unfold magma_op, reff622_inst, reff622_op in H. discriminate H. Qed.

Lemma reff622_not2443 : ~ @Equation2443 Fin5 reff622_inst.
Proof. unfold Equation2443. intro H. specialize (H F5_0 F5_2). unfold magma_op, reff622_inst, reff622_op in H. discriminate H. Qed.

Lemma reff622_not2444 : ~ @Equation2444 Fin5 reff622_inst.
Proof. unfold Equation2444. intro H. specialize (H F5_0 F5_2). unfold magma_op, reff622_inst, reff622_op in H. discriminate H. Qed.

Lemma reff622_not2446 : ~ @Equation2446 Fin5 reff622_inst.
Proof. unfold Equation2446. intro H. specialize (H F5_0 F5_2). unfold magma_op, reff622_inst, reff622_op in H. discriminate H. Qed.

Lemma reff622_not2447 : ~ @Equation2447 Fin5 reff622_inst.
Proof. unfold Equation2447. intro H. specialize (H F5_0 F5_2). unfold magma_op, reff622_inst, reff622_op in H. discriminate H. Qed.

Lemma reff622_not2449 : ~ @Equation2449 Fin5 reff622_inst.
Proof. unfold Equation2449. intro H. specialize (H F5_0 F5_2). unfold magma_op, reff622_inst, reff622_op in H. discriminate H. Qed.

Lemma reff622_not2450 : ~ @Equation2450 Fin5 reff622_inst.
Proof. unfold Equation2450. intro H. specialize (H F5_0 F5_2). unfold magma_op, reff622_inst, reff622_op in H. discriminate H. Qed.

Lemma reff622_not2456 : ~ @Equation2456 Fin5 reff622_inst.
Proof. unfold Equation2456. intro H. specialize (H F5_0 F5_4). unfold magma_op, reff622_inst, reff622_op in H. discriminate H. Qed.

Lemma reff622_not2457 : ~ @Equation2457 Fin5 reff622_inst.
Proof. unfold Equation2457. intro H. specialize (H F5_0 F5_2). unfold magma_op, reff622_inst, reff622_op in H. discriminate H. Qed.

Lemma reff622_not2459 : ~ @Equation2459 Fin5 reff622_inst.
Proof. unfold Equation2459. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff622_inst, reff622_op in H. discriminate H. Qed.

Lemma reff622_not2460 : ~ @Equation2460 Fin5 reff622_inst.
Proof. unfold Equation2460. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff622_inst, reff622_op in H. discriminate H. Qed.

Lemma reff622_not2466 : ~ @Equation2466 Fin5 reff622_inst.
Proof. unfold Equation2466. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff622_inst, reff622_op in H. discriminate H. Qed.

Lemma reff622_not2467 : ~ @Equation2467 Fin5 reff622_inst.
Proof. unfold Equation2467. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff622_inst, reff622_op in H. discriminate H. Qed.

Lemma reff622_not2469 : ~ @Equation2469 Fin5 reff622_inst.
Proof. unfold Equation2469. intro H. specialize (H F5_0 F5_2). unfold magma_op, reff622_inst, reff622_op in H. discriminate H. Qed.

Lemma reff622_not2470 : ~ @Equation2470 Fin5 reff622_inst.
Proof. unfold Equation2470. intro H. specialize (H F5_0 F5_2). unfold magma_op, reff622_inst, reff622_op in H. discriminate H. Qed.

Lemma reff622_not2493 : ~ @Equation2493 Fin5 reff622_inst.
Proof. unfold Equation2493. intro H. specialize (H F5_0 F5_4). unfold magma_op, reff622_inst, reff622_op in H. discriminate H. Qed.

Lemma reff622_not2494 : ~ @Equation2494 Fin5 reff622_inst.
Proof. unfold Equation2494. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff622_inst, reff622_op in H. discriminate H. Qed.

Lemma reff622_not2496 : ~ @Equation2496 Fin5 reff622_inst.
Proof. unfold Equation2496. intro H. specialize (H F5_0 F5_2). unfold magma_op, reff622_inst, reff622_op in H. discriminate H. Qed.

Lemma reff622_not2497 : ~ @Equation2497 Fin5 reff622_inst.
Proof. unfold Equation2497. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff622_inst, reff622_op in H. discriminate H. Qed.

Lemma reff622_not2503 : ~ @Equation2503 Fin5 reff622_inst.
Proof. unfold Equation2503. intro H. specialize (H F5_0 F5_2). unfold magma_op, reff622_inst, reff622_op in H. discriminate H. Qed.

Lemma reff622_not2504 : ~ @Equation2504 Fin5 reff622_inst.
Proof. unfold Equation2504. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff622_inst, reff622_op in H. discriminate H. Qed.

Lemma reff622_not2506 : ~ @Equation2506 Fin5 reff622_inst.
Proof. unfold Equation2506. intro H. specialize (H F5_0 F5_2). unfold magma_op, reff622_inst, reff622_op in H. discriminate H. Qed.

Lemma reff622_not2507 : ~ @Equation2507 Fin5 reff622_inst.
Proof. unfold Equation2507. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff622_inst, reff622_op in H. discriminate H. Qed.

Lemma reff622_not2530 : ~ @Equation2530 Fin5 reff622_inst.
Proof. unfold Equation2530. intro H. specialize (H F5_0 F5_4). unfold magma_op, reff622_inst, reff622_op in H. discriminate H. Qed.

Lemma reff622_not2531 : ~ @Equation2531 Fin5 reff622_inst.
Proof. unfold Equation2531. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff622_inst, reff622_op in H. discriminate H. Qed.

Lemma reff622_not2533 : ~ @Equation2533 Fin5 reff622_inst.
Proof. unfold Equation2533. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff622_inst, reff622_op in H. discriminate H. Qed.

Lemma reff622_not2534 : ~ @Equation2534 Fin5 reff622_inst.
Proof. unfold Equation2534. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff622_inst, reff622_op in H. discriminate H. Qed.

Lemma reff622_not2540 : ~ @Equation2540 Fin5 reff622_inst.
Proof. unfold Equation2540. intro H. specialize (H F5_0 F5_2). unfold magma_op, reff622_inst, reff622_op in H. discriminate H. Qed.

Lemma reff622_not2541 : ~ @Equation2541 Fin5 reff622_inst.
Proof. unfold Equation2541. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff622_inst, reff622_op in H. discriminate H. Qed.

Lemma reff622_not2543 : ~ @Equation2543 Fin5 reff622_inst.
Proof. unfold Equation2543. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff622_inst, reff622_op in H. discriminate H. Qed.

Lemma reff622_not2645 : ~ @Equation2645 Fin5 reff622_inst.
Proof. unfold Equation2645. intro H. specialize (H F5_0 F5_2). unfold magma_op, reff622_inst, reff622_op in H. discriminate H. Qed.

Lemma reff622_not2646 : ~ @Equation2646 Fin5 reff622_inst.
Proof. unfold Equation2646. intro H. specialize (H F5_0 F5_2). unfold magma_op, reff622_inst, reff622_op in H. discriminate H. Qed.

Lemma reff622_not2647 : ~ @Equation2647 Fin5 reff622_inst.
Proof. unfold Equation2647. intro H. specialize (H F5_0 F5_2). unfold magma_op, reff622_inst, reff622_op in H. discriminate H. Qed.

Lemma reff622_not2649 : ~ @Equation2649 Fin5 reff622_inst.
Proof. unfold Equation2649. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff622_inst, reff622_op in H. discriminate H. Qed.

Lemma reff622_not2650 : ~ @Equation2650 Fin5 reff622_inst.
Proof. unfold Equation2650. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff622_inst, reff622_op in H. discriminate H. Qed.

Lemma reff622_not2652 : ~ @Equation2652 Fin5 reff622_inst.
Proof. unfold Equation2652. intro H. specialize (H F5_0 F5_2). unfold magma_op, reff622_inst, reff622_op in H. discriminate H. Qed.

Lemma reff622_not2653 : ~ @Equation2653 Fin5 reff622_inst.
Proof. unfold Equation2653. intro H. specialize (H F5_0 F5_2). unfold magma_op, reff622_inst, reff622_op in H. discriminate H. Qed.

Lemma reff622_not2660 : ~ @Equation2660 Fin5 reff622_inst.
Proof. unfold Equation2660. intro H. specialize (H F5_0 F5_3). unfold magma_op, reff622_inst, reff622_op in H. discriminate H. Qed.

Lemma reff622_not2662 : ~ @Equation2662 Fin5 reff622_inst.
Proof. unfold Equation2662. intro H. specialize (H F5_0 F5_2). unfold magma_op, reff622_inst, reff622_op in H. discriminate H. Qed.

Lemma reff622_not2663 : ~ @Equation2663 Fin5 reff622_inst.
Proof. unfold Equation2663. intro H. specialize (H F5_0 F5_2). unfold magma_op, reff622_inst, reff622_op in H. discriminate H. Qed.

Lemma reff622_not2669 : ~ @Equation2669 Fin5 reff622_inst.
Proof. unfold Equation2669. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff622_inst, reff622_op in H. discriminate H. Qed.

Lemma reff622_not2670 : ~ @Equation2670 Fin5 reff622_inst.
Proof. unfold Equation2670. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff622_inst, reff622_op in H. discriminate H. Qed.

Lemma reff622_not2672 : ~ @Equation2672 Fin5 reff622_inst.
Proof. unfold Equation2672. intro H. specialize (H F5_0 F5_2). unfold magma_op, reff622_inst, reff622_op in H. discriminate H. Qed.

Lemma reff622_not2673 : ~ @Equation2673 Fin5 reff622_inst.
Proof. unfold Equation2673. intro H. specialize (H F5_0 F5_2). unfold magma_op, reff622_inst, reff622_op in H. discriminate H. Qed.

Lemma reff622_not2696 : ~ @Equation2696 Fin5 reff622_inst.
Proof. unfold Equation2696. intro H. specialize (H F5_0 F5_4). unfold magma_op, reff622_inst, reff622_op in H. discriminate H. Qed.

Lemma reff622_not2697 : ~ @Equation2697 Fin5 reff622_inst.
Proof. unfold Equation2697. intro H. specialize (H F5_0 F5_2). unfold magma_op, reff622_inst, reff622_op in H. discriminate H. Qed.

Lemma reff622_not2700 : ~ @Equation2700 Fin5 reff622_inst.
Proof. unfold Equation2700. intro H. specialize (H F5_0 F5_2). unfold magma_op, reff622_inst, reff622_op in H. discriminate H. Qed.

Lemma reff622_not2706 : ~ @Equation2706 Fin5 reff622_inst.
Proof. unfold Equation2706. intro H. specialize (H F5_0 F5_4). unfold magma_op, reff622_inst, reff622_op in H. discriminate H. Qed.

Lemma reff622_not2707 : ~ @Equation2707 Fin5 reff622_inst.
Proof. unfold Equation2707. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff622_inst, reff622_op in H. discriminate H. Qed.

Lemma reff622_not2709 : ~ @Equation2709 Fin5 reff622_inst.
Proof. unfold Equation2709. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff622_inst, reff622_op in H. discriminate H. Qed.

Lemma reff622_not2710 : ~ @Equation2710 Fin5 reff622_inst.
Proof. unfold Equation2710. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff622_inst, reff622_op in H. discriminate H. Qed.

Lemma reff622_not2733 : ~ @Equation2733 Fin5 reff622_inst.
Proof. unfold Equation2733. intro H. specialize (H F5_0 F5_4). unfold magma_op, reff622_inst, reff622_op in H. discriminate H. Qed.

Lemma reff622_not2734 : ~ @Equation2734 Fin5 reff622_inst.
Proof. unfold Equation2734. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff622_inst, reff622_op in H. discriminate H. Qed.

Lemma reff622_not2736 : ~ @Equation2736 Fin5 reff622_inst.
Proof. unfold Equation2736. intro H. specialize (H F5_0 F5_2). unfold magma_op, reff622_inst, reff622_op in H. discriminate H. Qed.

Lemma reff622_not2737 : ~ @Equation2737 Fin5 reff622_inst.
Proof. unfold Equation2737. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff622_inst, reff622_op in H. discriminate H. Qed.

Lemma reff622_not2743 : ~ @Equation2743 Fin5 reff622_inst.
Proof. unfold Equation2743. intro H. specialize (H F5_0 F5_2). unfold magma_op, reff622_inst, reff622_op in H. discriminate H. Qed.

Lemma reff622_not2744 : ~ @Equation2744 Fin5 reff622_inst.
Proof. unfold Equation2744. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff622_inst, reff622_op in H. discriminate H. Qed.

Lemma reff622_not2746 : ~ @Equation2746 Fin5 reff622_inst.
Proof. unfold Equation2746. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff622_inst, reff622_op in H. discriminate H. Qed.

Lemma reff622_not2848 : ~ @Equation2848 Fin5 reff622_inst.
Proof. unfold Equation2848. intro H. specialize (H F5_0 F5_2). unfold magma_op, reff622_inst, reff622_op in H. discriminate H. Qed.

Lemma reff622_not2849 : ~ @Equation2849 Fin5 reff622_inst.
Proof. unfold Equation2849. intro H. specialize (H F5_0 F5_2). unfold magma_op, reff622_inst, reff622_op in H. discriminate H. Qed.

Lemma reff622_not2850 : ~ @Equation2850 Fin5 reff622_inst.
Proof. unfold Equation2850. intro H. specialize (H F5_0 F5_2). unfold magma_op, reff622_inst, reff622_op in H. discriminate H. Qed.

Lemma reff622_not2853 : ~ @Equation2853 Fin5 reff622_inst.
Proof. unfold Equation2853. intro H. specialize (H F5_0 F5_3). unfold magma_op, reff622_inst, reff622_op in H. discriminate H. Qed.

Lemma reff622_not2855 : ~ @Equation2855 Fin5 reff622_inst.
Proof. unfold Equation2855. intro H. specialize (H F5_0 F5_2). unfold magma_op, reff622_inst, reff622_op in H. discriminate H. Qed.

Lemma reff622_not2856 : ~ @Equation2856 Fin5 reff622_inst.
Proof. unfold Equation2856. intro H. specialize (H F5_0 F5_2). unfold magma_op, reff622_inst, reff622_op in H. discriminate H. Qed.

Lemma reff622_not2863 : ~ @Equation2863 Fin5 reff622_inst.
Proof. unfold Equation2863. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff622_inst, reff622_op in H. discriminate H. Qed.

Lemma reff622_not2865 : ~ @Equation2865 Fin5 reff622_inst.
Proof. unfold Equation2865. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff622_inst, reff622_op in H. discriminate H. Qed.

Lemma reff622_not2866 : ~ @Equation2866 Fin5 reff622_inst.
Proof. unfold Equation2866. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff622_inst, reff622_op in H. discriminate H. Qed.

Lemma reff622_not2873 : ~ @Equation2873 Fin5 reff622_inst.
Proof. unfold Equation2873. intro H. specialize (H F5_0 F5_3). unfold magma_op, reff622_inst, reff622_op in H. discriminate H. Qed.

Lemma reff622_not2875 : ~ @Equation2875 Fin5 reff622_inst.
Proof. unfold Equation2875. intro H. specialize (H F5_0 F5_2). unfold magma_op, reff622_inst, reff622_op in H. discriminate H. Qed.

Lemma reff622_not2876 : ~ @Equation2876 Fin5 reff622_inst.
Proof. unfold Equation2876. intro H. specialize (H F5_0 F5_2). unfold magma_op, reff622_inst, reff622_op in H. discriminate H. Qed.

Lemma reff622_not2899 : ~ @Equation2899 Fin5 reff622_inst.
Proof. unfold Equation2899. intro H. specialize (H F5_0 F5_4). unfold magma_op, reff622_inst, reff622_op in H. discriminate H. Qed.

Lemma reff622_not2900 : ~ @Equation2900 Fin5 reff622_inst.
Proof. unfold Equation2900. intro H. specialize (H F5_0 F5_2). unfold magma_op, reff622_inst, reff622_op in H. discriminate H. Qed.

Lemma reff622_not2902 : ~ @Equation2902 Fin5 reff622_inst.
Proof. unfold Equation2902. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff622_inst, reff622_op in H. discriminate H. Qed.

Lemma reff622_not2903 : ~ @Equation2903 Fin5 reff622_inst.
Proof. unfold Equation2903. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff622_inst, reff622_op in H. discriminate H. Qed.

Lemma reff622_not2909 : ~ @Equation2909 Fin5 reff622_inst.
Proof. unfold Equation2909. intro H. specialize (H F5_0 F5_3). unfold magma_op, reff622_inst, reff622_op in H. discriminate H. Qed.

Lemma reff622_not2910 : ~ @Equation2910 Fin5 reff622_inst.
Proof. unfold Equation2910. intro H. specialize (H F5_0 F5_3). unfold magma_op, reff622_inst, reff622_op in H. discriminate H. Qed.

Lemma reff622_not2912 : ~ @Equation2912 Fin5 reff622_inst.
Proof. unfold Equation2912. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff622_inst, reff622_op in H. discriminate H. Qed.

Lemma reff622_not2913 : ~ @Equation2913 Fin5 reff622_inst.
Proof. unfold Equation2913. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff622_inst, reff622_op in H. discriminate H. Qed.

Lemma reff622_not2936 : ~ @Equation2936 Fin5 reff622_inst.
Proof. unfold Equation2936. intro H. specialize (H F5_0 F5_4). unfold magma_op, reff622_inst, reff622_op in H. discriminate H. Qed.

Lemma reff622_not2937 : ~ @Equation2937 Fin5 reff622_inst.
Proof. unfold Equation2937. intro H. specialize (H F5_0 F5_3). unfold magma_op, reff622_inst, reff622_op in H. discriminate H. Qed.

Lemma reff622_not2939 : ~ @Equation2939 Fin5 reff622_inst.
Proof. unfold Equation2939. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff622_inst, reff622_op in H. discriminate H. Qed.

Lemma reff622_not2940 : ~ @Equation2940 Fin5 reff622_inst.
Proof. unfold Equation2940. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff622_inst, reff622_op in H. discriminate H. Qed.

Lemma reff622_not2946 : ~ @Equation2946 Fin5 reff622_inst.
Proof. unfold Equation2946. intro H. specialize (H F5_0 F5_4). unfold magma_op, reff622_inst, reff622_op in H. discriminate H. Qed.

Lemma reff622_not2947 : ~ @Equation2947 Fin5 reff622_inst.
Proof. unfold Equation2947. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff622_inst, reff622_op in H. discriminate H. Qed.

Lemma reff622_not2949 : ~ @Equation2949 Fin5 reff622_inst.
Proof. unfold Equation2949. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff622_inst, reff622_op in H. discriminate H. Qed.

Lemma reff622_not3051 : ~ @Equation3051 Fin5 reff622_inst.
Proof. unfold Equation3051. intro H. specialize (H F5_0 F5_2). unfold magma_op, reff622_inst, reff622_op in H. discriminate H. Qed.

Lemma reff622_not3052 : ~ @Equation3052 Fin5 reff622_inst.
Proof. unfold Equation3052. intro H. specialize (H F5_0 F5_2). unfold magma_op, reff622_inst, reff622_op in H. discriminate H. Qed.

Lemma reff622_not3053 : ~ @Equation3053 Fin5 reff622_inst.
Proof. unfold Equation3053. intro H. specialize (H F5_0 F5_2). unfold magma_op, reff622_inst, reff622_op in H. discriminate H. Qed.

Lemma reff622_not3056 : ~ @Equation3056 Fin5 reff622_inst.
Proof. unfold Equation3056. intro H. specialize (H F5_0 F5_3). unfold magma_op, reff622_inst, reff622_op in H. discriminate H. Qed.

Lemma reff622_not3058 : ~ @Equation3058 Fin5 reff622_inst.
Proof. unfold Equation3058. intro H. specialize (H F5_0 F5_2). unfold magma_op, reff622_inst, reff622_op in H. discriminate H. Qed.

Lemma reff622_not3059 : ~ @Equation3059 Fin5 reff622_inst.
Proof. unfold Equation3059. intro H. specialize (H F5_0 F5_2). unfold magma_op, reff622_inst, reff622_op in H. discriminate H. Qed.

Lemma reff622_not3066 : ~ @Equation3066 Fin5 reff622_inst.
Proof. unfold Equation3066. intro H. specialize (H F5_0 F5_2). unfold magma_op, reff622_inst, reff622_op in H. discriminate H. Qed.

Lemma reff622_not3069 : ~ @Equation3069 Fin5 reff622_inst.
Proof. unfold Equation3069. intro H. specialize (H F5_0 F5_2). unfold magma_op, reff622_inst, reff622_op in H. discriminate H. Qed.

Lemma reff622_not3075 : ~ @Equation3075 Fin5 reff622_inst.
Proof. unfold Equation3075. intro H. specialize (H F5_0 F5_4). unfold magma_op, reff622_inst, reff622_op in H. discriminate H. Qed.

Lemma reff622_not3076 : ~ @Equation3076 Fin5 reff622_inst.
Proof. unfold Equation3076. intro H. specialize (H F5_0 F5_3). unfold magma_op, reff622_inst, reff622_op in H. discriminate H. Qed.

Lemma reff622_not3078 : ~ @Equation3078 Fin5 reff622_inst.
Proof. unfold Equation3078. intro H. specialize (H F5_0 F5_2). unfold magma_op, reff622_inst, reff622_op in H. discriminate H. Qed.

Lemma reff622_not3079 : ~ @Equation3079 Fin5 reff622_inst.
Proof. unfold Equation3079. intro H. specialize (H F5_0 F5_2). unfold magma_op, reff622_inst, reff622_op in H. discriminate H. Qed.

Lemma reff622_not3102 : ~ @Equation3102 Fin5 reff622_inst.
Proof. unfold Equation3102. intro H. specialize (H F5_0 F5_4). unfold magma_op, reff622_inst, reff622_op in H. discriminate H. Qed.

Lemma reff622_not3103 : ~ @Equation3103 Fin5 reff622_inst.
Proof. unfold Equation3103. intro H. specialize (H F5_0 F5_2). unfold magma_op, reff622_inst, reff622_op in H. discriminate H. Qed.

Lemma reff622_not3105 : ~ @Equation3105 Fin5 reff622_inst.
Proof. unfold Equation3105. intro H. specialize (H F5_0 F5_2). unfold magma_op, reff622_inst, reff622_op in H. discriminate H. Qed.

Lemma reff622_not3106 : ~ @Equation3106 Fin5 reff622_inst.
Proof. unfold Equation3106. intro H. specialize (H F5_0 F5_2). unfold magma_op, reff622_inst, reff622_op in H. discriminate H. Qed.

Lemma reff622_not3112 : ~ @Equation3112 Fin5 reff622_inst.
Proof. unfold Equation3112. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff622_inst, reff622_op in H. discriminate H. Qed.

Lemma reff622_not3113 : ~ @Equation3113 Fin5 reff622_inst.
Proof. unfold Equation3113. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff622_inst, reff622_op in H. discriminate H. Qed.

Lemma reff622_not3115 : ~ @Equation3115 Fin5 reff622_inst.
Proof. unfold Equation3115. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff622_inst, reff622_op in H. discriminate H. Qed.

Lemma reff622_not3116 : ~ @Equation3116 Fin5 reff622_inst.
Proof. unfold Equation3116. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff622_inst, reff622_op in H. discriminate H. Qed.

Lemma reff622_not3139 : ~ @Equation3139 Fin5 reff622_inst.
Proof. unfold Equation3139. intro H. specialize (H F5_0 F5_4). unfold magma_op, reff622_inst, reff622_op in H. discriminate H. Qed.

Lemma reff622_not3140 : ~ @Equation3140 Fin5 reff622_inst.
Proof. unfold Equation3140. intro H. specialize (H F5_0 F5_2). unfold magma_op, reff622_inst, reff622_op in H. discriminate H. Qed.

Lemma reff622_not3142 : ~ @Equation3142 Fin5 reff622_inst.
Proof. unfold Equation3142. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff622_inst, reff622_op in H. discriminate H. Qed.

Lemma reff622_not3143 : ~ @Equation3143 Fin5 reff622_inst.
Proof. unfold Equation3143. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff622_inst, reff622_op in H. discriminate H. Qed.

Lemma reff622_not3149 : ~ @Equation3149 Fin5 reff622_inst.
Proof. unfold Equation3149. intro H. specialize (H F5_0 F5_4). unfold magma_op, reff622_inst, reff622_op in H. discriminate H. Qed.

Lemma reff622_not3150 : ~ @Equation3150 Fin5 reff622_inst.
Proof. unfold Equation3150. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff622_inst, reff622_op in H. discriminate H. Qed.

Lemma reff622_not3152 : ~ @Equation3152 Fin5 reff622_inst.
Proof. unfold Equation3152. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff622_inst, reff622_op in H. discriminate H. Qed.

Lemma reff622_not3254 : ~ @Equation3254 Fin5 reff622_inst.
Proof. unfold Equation3254. intro H. specialize (H F5_0 F5_2). unfold magma_op, reff622_inst, reff622_op in H. discriminate H. Qed.

Lemma reff622_not3255 : ~ @Equation3255 Fin5 reff622_inst.
Proof. unfold Equation3255. intro H. specialize (H F5_0 F5_4). unfold magma_op, reff622_inst, reff622_op in H. discriminate H. Qed.

Lemma reff622_not3256 : ~ @Equation3256 Fin5 reff622_inst.
Proof. unfold Equation3256. intro H. specialize (H F5_0 F5_2). unfold magma_op, reff622_inst, reff622_op in H. discriminate H. Qed.

Lemma reff622_not3258 : ~ @Equation3258 Fin5 reff622_inst.
Proof. unfold Equation3258. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff622_inst, reff622_op in H. discriminate H. Qed.

Lemma reff622_not3259 : ~ @Equation3259 Fin5 reff622_inst.
Proof. unfold Equation3259. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff622_inst, reff622_op in H. discriminate H. Qed.

Lemma reff622_not3261 : ~ @Equation3261 Fin5 reff622_inst.
Proof. unfold Equation3261. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff622_inst, reff622_op in H. discriminate H. Qed.

Lemma reff622_not3262 : ~ @Equation3262 Fin5 reff622_inst.
Proof. unfold Equation3262. intro H. specialize (H F5_0 F5_2). unfold magma_op, reff622_inst, reff622_op in H. discriminate H. Qed.

Lemma reff622_not3268 : ~ @Equation3268 Fin5 reff622_inst.
Proof. unfold Equation3268. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff622_inst, reff622_op in H. discriminate H. Qed.

Lemma reff622_not3269 : ~ @Equation3269 Fin5 reff622_inst.
Proof. unfold Equation3269. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff622_inst, reff622_op in H. discriminate H. Qed.

Lemma reff622_not3271 : ~ @Equation3271 Fin5 reff622_inst.
Proof. unfold Equation3271. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff622_inst, reff622_op in H. discriminate H. Qed.

Lemma reff622_not3272 : ~ @Equation3272 Fin5 reff622_inst.
Proof. unfold Equation3272. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff622_inst, reff622_op in H. discriminate H. Qed.

Lemma reff622_not3278 : ~ @Equation3278 Fin5 reff622_inst.
Proof. unfold Equation3278. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff622_inst, reff622_op in H. discriminate H. Qed.

Lemma reff622_not3279 : ~ @Equation3279 Fin5 reff622_inst.
Proof. unfold Equation3279. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff622_inst, reff622_op in H. discriminate H. Qed.

Lemma reff622_not3281 : ~ @Equation3281 Fin5 reff622_inst.
Proof. unfold Equation3281. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff622_inst, reff622_op in H. discriminate H. Qed.

Lemma reff622_not3306 : ~ @Equation3306 Fin5 reff622_inst.
Proof. unfold Equation3306. intro H. specialize (H F5_0 F5_3). unfold magma_op, reff622_inst, reff622_op in H. discriminate H. Qed.

Lemma reff622_not3308 : ~ @Equation3308 Fin5 reff622_inst.
Proof. unfold Equation3308. intro H. specialize (H F5_0 F5_2). unfold magma_op, reff622_inst, reff622_op in H. discriminate H. Qed.

Lemma reff622_not3309 : ~ @Equation3309 Fin5 reff622_inst.
Proof. unfold Equation3309. intro H. specialize (H F5_0 F5_3). unfold magma_op, reff622_inst, reff622_op in H. discriminate H. Qed.

Lemma reff622_not3315 : ~ @Equation3315 Fin5 reff622_inst.
Proof. unfold Equation3315. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff622_inst, reff622_op in H. discriminate H. Qed.

Lemma reff622_not3316 : ~ @Equation3316 Fin5 reff622_inst.
Proof. unfold Equation3316. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff622_inst, reff622_op in H. discriminate H. Qed.

Lemma reff622_not3318 : ~ @Equation3318 Fin5 reff622_inst.
Proof. unfold Equation3318. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff622_inst, reff622_op in H. discriminate H. Qed.

Lemma reff622_not3342 : ~ @Equation3342 Fin5 reff622_inst.
Proof. unfold Equation3342. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff622_inst, reff622_op in H. discriminate H. Qed.

Lemma reff622_not3343 : ~ @Equation3343 Fin5 reff622_inst.
Proof. unfold Equation3343. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff622_inst, reff622_op in H. discriminate H. Qed.

Lemma reff622_not3345 : ~ @Equation3345 Fin5 reff622_inst.
Proof. unfold Equation3345. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff622_inst, reff622_op in H. discriminate H. Qed.

Lemma reff622_not3346 : ~ @Equation3346 Fin5 reff622_inst.
Proof. unfold Equation3346. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff622_inst, reff622_op in H. discriminate H. Qed.

Lemma reff622_not3352 : ~ @Equation3352 Fin5 reff622_inst.
Proof. unfold Equation3352. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff622_inst, reff622_op in H. discriminate H. Qed.

Lemma reff622_not3353 : ~ @Equation3353 Fin5 reff622_inst.
Proof. unfold Equation3353. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff622_inst, reff622_op in H. discriminate H. Qed.

Lemma reff622_not3457 : ~ @Equation3457 Fin5 reff622_inst.
Proof. unfold Equation3457. intro H. specialize (H F5_0 F5_2). unfold magma_op, reff622_inst, reff622_op in H. discriminate H. Qed.

Lemma reff622_not3458 : ~ @Equation3458 Fin5 reff622_inst.
Proof. unfold Equation3458. intro H. specialize (H F5_0 F5_2). unfold magma_op, reff622_inst, reff622_op in H. discriminate H. Qed.

Lemma reff622_not3459 : ~ @Equation3459 Fin5 reff622_inst.
Proof. unfold Equation3459. intro H. specialize (H F5_0 F5_2). unfold magma_op, reff622_inst, reff622_op in H. discriminate H. Qed.

Lemma reff622_not3461 : ~ @Equation3461 Fin5 reff622_inst.
Proof. unfold Equation3461. intro H. specialize (H F5_0 F5_4). unfold magma_op, reff622_inst, reff622_op in H. discriminate H. Qed.

Lemma reff622_not3462 : ~ @Equation3462 Fin5 reff622_inst.
Proof. unfold Equation3462. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff622_inst, reff622_op in H. discriminate H. Qed.

Lemma reff622_not3464 : ~ @Equation3464 Fin5 reff622_inst.
Proof. unfold Equation3464. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff622_inst, reff622_op in H. discriminate H. Qed.

Lemma reff622_not3465 : ~ @Equation3465 Fin5 reff622_inst.
Proof. unfold Equation3465. intro H. specialize (H F5_0 F5_2). unfold magma_op, reff622_inst, reff622_op in H. discriminate H. Qed.

Lemma reff622_not3472 : ~ @Equation3472 Fin5 reff622_inst.
Proof. unfold Equation3472. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff622_inst, reff622_op in H. discriminate H. Qed.

Lemma reff622_not3474 : ~ @Equation3474 Fin5 reff622_inst.
Proof. unfold Equation3474. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff622_inst, reff622_op in H. discriminate H. Qed.

Lemma reff622_not3475 : ~ @Equation3475 Fin5 reff622_inst.
Proof. unfold Equation3475. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff622_inst, reff622_op in H. discriminate H. Qed.

Lemma reff622_not3481 : ~ @Equation3481 Fin5 reff622_inst.
Proof. unfold Equation3481. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff622_inst, reff622_op in H. discriminate H. Qed.

Lemma reff622_not3482 : ~ @Equation3482 Fin5 reff622_inst.
Proof. unfold Equation3482. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff622_inst, reff622_op in H. discriminate H. Qed.

Lemma reff622_not3484 : ~ @Equation3484 Fin5 reff622_inst.
Proof. unfold Equation3484. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff622_inst, reff622_op in H. discriminate H. Qed.

Lemma reff622_not3509 : ~ @Equation3509 Fin5 reff622_inst.
Proof. unfold Equation3509. intro H. specialize (H F5_0 F5_3). unfold magma_op, reff622_inst, reff622_op in H. discriminate H. Qed.

Lemma reff622_not3511 : ~ @Equation3511 Fin5 reff622_inst.
Proof. unfold Equation3511. intro H. specialize (H F5_0 F5_2). unfold magma_op, reff622_inst, reff622_op in H. discriminate H. Qed.

Lemma reff622_not3518 : ~ @Equation3518 Fin5 reff622_inst.
Proof. unfold Equation3518. intro H. specialize (H F5_0 F5_2). unfold magma_op, reff622_inst, reff622_op in H. discriminate H. Qed.

Lemma reff622_not3519 : ~ @Equation3519 Fin5 reff622_inst.
Proof. unfold Equation3519. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff622_inst, reff622_op in H. discriminate H. Qed.

Lemma reff622_not3521 : ~ @Equation3521 Fin5 reff622_inst.
Proof. unfold Equation3521. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff622_inst, reff622_op in H. discriminate H. Qed.

Lemma reff622_not3545 : ~ @Equation3545 Fin5 reff622_inst.
Proof. unfold Equation3545. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff622_inst, reff622_op in H. discriminate H. Qed.

Lemma reff622_not3546 : ~ @Equation3546 Fin5 reff622_inst.
Proof. unfold Equation3546. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff622_inst, reff622_op in H. discriminate H. Qed.

Lemma reff622_not3548 : ~ @Equation3548 Fin5 reff622_inst.
Proof. unfold Equation3548. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff622_inst, reff622_op in H. discriminate H. Qed.

Lemma reff622_not3549 : ~ @Equation3549 Fin5 reff622_inst.
Proof. unfold Equation3549. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff622_inst, reff622_op in H. discriminate H. Qed.

Lemma reff622_not3555 : ~ @Equation3555 Fin5 reff622_inst.
Proof. unfold Equation3555. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff622_inst, reff622_op in H. discriminate H. Qed.

Lemma reff622_not3556 : ~ @Equation3556 Fin5 reff622_inst.
Proof. unfold Equation3556. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff622_inst, reff622_op in H. discriminate H. Qed.

Lemma reff622_not3558 : ~ @Equation3558 Fin5 reff622_inst.
Proof. unfold Equation3558. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff622_inst, reff622_op in H. discriminate H. Qed.

Lemma reff622_not3660 : ~ @Equation3660 Fin5 reff622_inst.
Proof. unfold Equation3660. intro H. specialize (H F5_0 F5_2). unfold magma_op, reff622_inst, reff622_op in H. discriminate H. Qed.

Lemma reff622_not3661 : ~ @Equation3661 Fin5 reff622_inst.
Proof. unfold Equation3661. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff622_inst, reff622_op in H. discriminate H. Qed.

Lemma reff622_not3662 : ~ @Equation3662 Fin5 reff622_inst.
Proof. unfold Equation3662. intro H. specialize (H F5_0 F5_2). unfold magma_op, reff622_inst, reff622_op in H. discriminate H. Qed.

Lemma reff622_not3664 : ~ @Equation3664 Fin5 reff622_inst.
Proof. unfold Equation3664. intro H. specialize (H F5_0 F5_2). unfold magma_op, reff622_inst, reff622_op in H. discriminate H. Qed.

Lemma reff622_not3665 : ~ @Equation3665 Fin5 reff622_inst.
Proof. unfold Equation3665. intro H. specialize (H F5_0 F5_2). unfold magma_op, reff622_inst, reff622_op in H. discriminate H. Qed.

Lemma reff622_not3667 : ~ @Equation3667 Fin5 reff622_inst.
Proof. unfold Equation3667. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff622_inst, reff622_op in H. discriminate H. Qed.

Lemma reff622_not3668 : ~ @Equation3668 Fin5 reff622_inst.
Proof. unfold Equation3668. intro H. specialize (H F5_0 F5_2). unfold magma_op, reff622_inst, reff622_op in H. discriminate H. Qed.

Lemma reff622_not3674 : ~ @Equation3674 Fin5 reff622_inst.
Proof. unfold Equation3674. intro H. specialize (H F5_0 F5_4). unfold magma_op, reff622_inst, reff622_op in H. discriminate H. Qed.

Lemma reff622_not3677 : ~ @Equation3677 Fin5 reff622_inst.
Proof. unfold Equation3677. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff622_inst, reff622_op in H. discriminate H. Qed.

Lemma reff622_not3678 : ~ @Equation3678 Fin5 reff622_inst.
Proof. unfold Equation3678. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff622_inst, reff622_op in H. discriminate H. Qed.

Lemma reff622_not3684 : ~ @Equation3684 Fin5 reff622_inst.
Proof. unfold Equation3684. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff622_inst, reff622_op in H. discriminate H. Qed.

Lemma reff622_not3685 : ~ @Equation3685 Fin5 reff622_inst.
Proof. unfold Equation3685. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff622_inst, reff622_op in H. discriminate H. Qed.

Lemma reff622_not3687 : ~ @Equation3687 Fin5 reff622_inst.
Proof. unfold Equation3687. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff622_inst, reff622_op in H. discriminate H. Qed.

Lemma reff622_not3712 : ~ @Equation3712 Fin5 reff622_inst.
Proof. unfold Equation3712. intro H. specialize (H F5_0 F5_3). unfold magma_op, reff622_inst, reff622_op in H. discriminate H. Qed.

Lemma reff622_not3714 : ~ @Equation3714 Fin5 reff622_inst.
Proof. unfold Equation3714. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff622_inst, reff622_op in H. discriminate H. Qed.

Lemma reff622_not3721 : ~ @Equation3721 Fin5 reff622_inst.
Proof. unfold Equation3721. intro H. specialize (H F5_0 F5_2). unfold magma_op, reff622_inst, reff622_op in H. discriminate H. Qed.

Lemma reff622_not3724 : ~ @Equation3724 Fin5 reff622_inst.
Proof. unfold Equation3724. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff622_inst, reff622_op in H. discriminate H. Qed.

Lemma reff622_not3725 : ~ @Equation3725 Fin5 reff622_inst.
Proof. unfold Equation3725. intro H. specialize (H F5_0 F5_3). unfold magma_op, reff622_inst, reff622_op in H. discriminate H. Qed.

Lemma reff622_not3748 : ~ @Equation3748 Fin5 reff622_inst.
Proof. unfold Equation3748. intro H. specialize (H F5_0 F5_2). unfold magma_op, reff622_inst, reff622_op in H. discriminate H. Qed.

Lemma reff622_not3749 : ~ @Equation3749 Fin5 reff622_inst.
Proof. unfold Equation3749. intro H. specialize (H F5_0 F5_2). unfold magma_op, reff622_inst, reff622_op in H. discriminate H. Qed.

Lemma reff622_not3751 : ~ @Equation3751 Fin5 reff622_inst.
Proof. unfold Equation3751. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff622_inst, reff622_op in H. discriminate H. Qed.

Lemma reff622_not3752 : ~ @Equation3752 Fin5 reff622_inst.
Proof. unfold Equation3752. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff622_inst, reff622_op in H. discriminate H. Qed.

Lemma reff622_not3758 : ~ @Equation3758 Fin5 reff622_inst.
Proof. unfold Equation3758. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff622_inst, reff622_op in H. discriminate H. Qed.

Lemma reff622_not3759 : ~ @Equation3759 Fin5 reff622_inst.
Proof. unfold Equation3759. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff622_inst, reff622_op in H. discriminate H. Qed.

Lemma reff622_not3761 : ~ @Equation3761 Fin5 reff622_inst.
Proof. unfold Equation3761. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff622_inst, reff622_op in H. discriminate H. Qed.

Lemma reff622_not3864 : ~ @Equation3864 Fin5 reff622_inst.
Proof. unfold Equation3864. intro H. specialize (H F5_0 F5_2). unfold magma_op, reff622_inst, reff622_op in H. discriminate H. Qed.

Lemma reff622_not3865 : ~ @Equation3865 Fin5 reff622_inst.
Proof. unfold Equation3865. intro H. specialize (H F5_0 F5_2). unfold magma_op, reff622_inst, reff622_op in H. discriminate H. Qed.

Lemma reff622_not3867 : ~ @Equation3867 Fin5 reff622_inst.
Proof. unfold Equation3867. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff622_inst, reff622_op in H. discriminate H. Qed.

Lemma reff622_not3868 : ~ @Equation3868 Fin5 reff622_inst.
Proof. unfold Equation3868. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff622_inst, reff622_op in H. discriminate H. Qed.

Lemma reff622_not3870 : ~ @Equation3870 Fin5 reff622_inst.
Proof. unfold Equation3870. intro H. specialize (H F5_0 F5_2). unfold magma_op, reff622_inst, reff622_op in H. discriminate H. Qed.

Lemma reff622_not3871 : ~ @Equation3871 Fin5 reff622_inst.
Proof. unfold Equation3871. intro H. specialize (H F5_0 F5_2). unfold magma_op, reff622_inst, reff622_op in H. discriminate H. Qed.

Lemma reff622_not3877 : ~ @Equation3877 Fin5 reff622_inst.
Proof. unfold Equation3877. intro H. specialize (H F5_0 F5_4). unfold magma_op, reff622_inst, reff622_op in H. discriminate H. Qed.

Lemma reff622_not3878 : ~ @Equation3878 Fin5 reff622_inst.
Proof. unfold Equation3878. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff622_inst, reff622_op in H. discriminate H. Qed.

Lemma reff622_not3880 : ~ @Equation3880 Fin5 reff622_inst.
Proof. unfold Equation3880. intro H. specialize (H F5_0 F5_2). unfold magma_op, reff622_inst, reff622_op in H. discriminate H. Qed.

Lemma reff622_not3881 : ~ @Equation3881 Fin5 reff622_inst.
Proof. unfold Equation3881. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff622_inst, reff622_op in H. discriminate H. Qed.

Lemma reff622_not3887 : ~ @Equation3887 Fin5 reff622_inst.
Proof. unfold Equation3887. intro H. specialize (H F5_0 F5_2). unfold magma_op, reff622_inst, reff622_op in H. discriminate H. Qed.

Lemma reff622_not3888 : ~ @Equation3888 Fin5 reff622_inst.
Proof. unfold Equation3888. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff622_inst, reff622_op in H. discriminate H. Qed.

Lemma reff622_not3890 : ~ @Equation3890 Fin5 reff622_inst.
Proof. unfold Equation3890. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff622_inst, reff622_op in H. discriminate H. Qed.

Lemma reff622_not3917 : ~ @Equation3917 Fin5 reff622_inst.
Proof. unfold Equation3917. intro H. specialize (H F5_0 F5_2). unfold magma_op, reff622_inst, reff622_op in H. discriminate H. Qed.

Lemma reff622_not3918 : ~ @Equation3918 Fin5 reff622_inst.
Proof. unfold Equation3918. intro H. specialize (H F5_0 F5_4). unfold magma_op, reff622_inst, reff622_op in H. discriminate H. Qed.

Lemma reff622_not3924 : ~ @Equation3924 Fin5 reff622_inst.
Proof. unfold Equation3924. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff622_inst, reff622_op in H. discriminate H. Qed.

Lemma reff622_not3925 : ~ @Equation3925 Fin5 reff622_inst.
Proof. unfold Equation3925. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff622_inst, reff622_op in H. discriminate H. Qed.

Lemma reff622_not3927 : ~ @Equation3927 Fin5 reff622_inst.
Proof. unfold Equation3927. intro H. specialize (H F5_0 F5_2). unfold magma_op, reff622_inst, reff622_op in H. discriminate H. Qed.

Lemma reff622_not3928 : ~ @Equation3928 Fin5 reff622_inst.
Proof. unfold Equation3928. intro H. specialize (H F5_0 F5_3). unfold magma_op, reff622_inst, reff622_op in H. discriminate H. Qed.

Lemma reff622_not3951 : ~ @Equation3951 Fin5 reff622_inst.
Proof. unfold Equation3951. intro H. specialize (H F5_0 F5_2). unfold magma_op, reff622_inst, reff622_op in H. discriminate H. Qed.

Lemma reff622_not3952 : ~ @Equation3952 Fin5 reff622_inst.
Proof. unfold Equation3952. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff622_inst, reff622_op in H. discriminate H. Qed.

Lemma reff622_not3954 : ~ @Equation3954 Fin5 reff622_inst.
Proof. unfold Equation3954. intro H. specialize (H F5_0 F5_2). unfold magma_op, reff622_inst, reff622_op in H. discriminate H. Qed.

Lemma reff622_not3955 : ~ @Equation3955 Fin5 reff622_inst.
Proof. unfold Equation3955. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff622_inst, reff622_op in H. discriminate H. Qed.

Lemma reff622_not3961 : ~ @Equation3961 Fin5 reff622_inst.
Proof. unfold Equation3961. intro H. specialize (H F5_0 F5_2). unfold magma_op, reff622_inst, reff622_op in H. discriminate H. Qed.

Lemma reff622_not3962 : ~ @Equation3962 Fin5 reff622_inst.
Proof. unfold Equation3962. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff622_inst, reff622_op in H. discriminate H. Qed.

Lemma reff622_not3964 : ~ @Equation3964 Fin5 reff622_inst.
Proof. unfold Equation3964. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff622_inst, reff622_op in H. discriminate H. Qed.

Lemma reff622_not4066 : ~ @Equation4066 Fin5 reff622_inst.
Proof. unfold Equation4066. intro H. specialize (H F5_0 F5_2). unfold magma_op, reff622_inst, reff622_op in H. discriminate H. Qed.

Lemma reff622_not4067 : ~ @Equation4067 Fin5 reff622_inst.
Proof. unfold Equation4067. intro H. specialize (H F5_0 F5_2). unfold magma_op, reff622_inst, reff622_op in H. discriminate H. Qed.

Lemma reff622_not4068 : ~ @Equation4068 Fin5 reff622_inst.
Proof. unfold Equation4068. intro H. specialize (H F5_0 F5_2). unfold magma_op, reff622_inst, reff622_op in H. discriminate H. Qed.

Lemma reff622_not4071 : ~ @Equation4071 Fin5 reff622_inst.
Proof. unfold Equation4071. intro H. specialize (H F5_0 F5_3). unfold magma_op, reff622_inst, reff622_op in H. discriminate H. Qed.

Lemma reff622_not4073 : ~ @Equation4073 Fin5 reff622_inst.
Proof. unfold Equation4073. intro H. specialize (H F5_0 F5_2). unfold magma_op, reff622_inst, reff622_op in H. discriminate H. Qed.

Lemma reff622_not4074 : ~ @Equation4074 Fin5 reff622_inst.
Proof. unfold Equation4074. intro H. specialize (H F5_0 F5_2). unfold magma_op, reff622_inst, reff622_op in H. discriminate H. Qed.

Lemma reff622_not4080 : ~ @Equation4080 Fin5 reff622_inst.
Proof. unfold Equation4080. intro H. specialize (H F5_0 F5_4). unfold magma_op, reff622_inst, reff622_op in H. discriminate H. Qed.

Lemma reff622_not4081 : ~ @Equation4081 Fin5 reff622_inst.
Proof. unfold Equation4081. intro H. specialize (H F5_0 F5_2). unfold magma_op, reff622_inst, reff622_op in H. discriminate H. Qed.

Lemma reff622_not4083 : ~ @Equation4083 Fin5 reff622_inst.
Proof. unfold Equation4083. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff622_inst, reff622_op in H. discriminate H. Qed.

Lemma reff622_not4084 : ~ @Equation4084 Fin5 reff622_inst.
Proof. unfold Equation4084. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff622_inst, reff622_op in H. discriminate H. Qed.

Lemma reff622_not4090 : ~ @Equation4090 Fin5 reff622_inst.
Proof. unfold Equation4090. intro H. specialize (H F5_0 F5_4). unfold magma_op, reff622_inst, reff622_op in H. discriminate H. Qed.

Lemma reff622_not4091 : ~ @Equation4091 Fin5 reff622_inst.
Proof. unfold Equation4091. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff622_inst, reff622_op in H. discriminate H. Qed.

Lemma reff622_not4093 : ~ @Equation4093 Fin5 reff622_inst.
Proof. unfold Equation4093. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff622_inst, reff622_op in H. discriminate H. Qed.

Lemma reff622_not4120 : ~ @Equation4120 Fin5 reff622_inst.
Proof. unfold Equation4120. intro H. specialize (H F5_0 F5_2). unfold magma_op, reff622_inst, reff622_op in H. discriminate H. Qed.

Lemma reff622_not4121 : ~ @Equation4121 Fin5 reff622_inst.
Proof. unfold Equation4121. intro H. specialize (H F5_0 F5_3). unfold magma_op, reff622_inst, reff622_op in H. discriminate H. Qed.

Lemma reff622_not4127 : ~ @Equation4127 Fin5 reff622_inst.
Proof. unfold Equation4127. intro H. specialize (H F5_0 F5_2). unfold magma_op, reff622_inst, reff622_op in H. discriminate H. Qed.

Lemma reff622_not4128 : ~ @Equation4128 Fin5 reff622_inst.
Proof. unfold Equation4128. intro H. specialize (H F5_0 F5_2). unfold magma_op, reff622_inst, reff622_op in H. discriminate H. Qed.

Lemma reff622_not4130 : ~ @Equation4130 Fin5 reff622_inst.
Proof. unfold Equation4130. intro H. specialize (H F5_0 F5_2). unfold magma_op, reff622_inst, reff622_op in H. discriminate H. Qed.

Lemma reff622_not4131 : ~ @Equation4131 Fin5 reff622_inst.
Proof. unfold Equation4131. intro H. specialize (H F5_0 F5_3). unfold magma_op, reff622_inst, reff622_op in H. discriminate H. Qed.

Lemma reff622_not4155 : ~ @Equation4155 Fin5 reff622_inst.
Proof. unfold Equation4155. intro H. specialize (H F5_0 F5_4). unfold magma_op, reff622_inst, reff622_op in H. discriminate H. Qed.

Lemma reff622_not4157 : ~ @Equation4157 Fin5 reff622_inst.
Proof. unfold Equation4157. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff622_inst, reff622_op in H. discriminate H. Qed.

Lemma reff622_not4158 : ~ @Equation4158 Fin5 reff622_inst.
Proof. unfold Equation4158. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff622_inst, reff622_op in H. discriminate H. Qed.

Lemma reff622_not4164 : ~ @Equation4164 Fin5 reff622_inst.
Proof. unfold Equation4164. intro H. specialize (H F5_0 F5_2). unfold magma_op, reff622_inst, reff622_op in H. discriminate H. Qed.

Lemma reff622_not4165 : ~ @Equation4165 Fin5 reff622_inst.
Proof. unfold Equation4165. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff622_inst, reff622_op in H. discriminate H. Qed.

Lemma reff622_not4167 : ~ @Equation4167 Fin5 reff622_inst.
Proof. unfold Equation4167. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff622_inst, reff622_op in H. discriminate H. Qed.

Lemma reff622_not4268 : ~ @Equation4268 Fin5 reff622_inst.
Proof. unfold Equation4268. intro H. specialize (H F5_0 F5_2). unfold magma_op, reff622_inst, reff622_op in H. discriminate H. Qed.

Lemma reff622_not4269 : ~ @Equation4269 Fin5 reff622_inst.
Proof. unfold Equation4269. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff622_inst, reff622_op in H. discriminate H. Qed.

Lemma reff622_not4270 : ~ @Equation4270 Fin5 reff622_inst.
Proof. unfold Equation4270. intro H. specialize (H F5_0 F5_2). unfold magma_op, reff622_inst, reff622_op in H. discriminate H. Qed.

Lemma reff622_not4272 : ~ @Equation4272 Fin5 reff622_inst.
Proof. unfold Equation4272. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff622_inst, reff622_op in H. discriminate H. Qed.

Lemma reff622_not4273 : ~ @Equation4273 Fin5 reff622_inst.
Proof. unfold Equation4273. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff622_inst, reff622_op in H. discriminate H. Qed.

Lemma reff622_not4275 : ~ @Equation4275 Fin5 reff622_inst.
Proof. unfold Equation4275. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff622_inst, reff622_op in H. discriminate H. Qed.

Lemma reff622_not4276 : ~ @Equation4276 Fin5 reff622_inst.
Proof. unfold Equation4276. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff622_inst, reff622_op in H. discriminate H. Qed.

Lemma reff622_not4283 : ~ @Equation4283 Fin5 reff622_inst.
Proof. unfold Equation4283. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff622_inst, reff622_op in H. discriminate H. Qed.

Lemma reff622_not4284 : ~ @Equation4284 Fin5 reff622_inst.
Proof. unfold Equation4284. intro H. specialize (H F5_0 F5_3). unfold magma_op, reff622_inst, reff622_op in H. discriminate H. Qed.

Lemma reff622_not4290 : ~ @Equation4290 Fin5 reff622_inst.
Proof. unfold Equation4290. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff622_inst, reff622_op in H. discriminate H. Qed.

Lemma reff622_not4291 : ~ @Equation4291 Fin5 reff622_inst.
Proof. unfold Equation4291. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff622_inst, reff622_op in H. discriminate H. Qed.

Lemma reff622_not4293 : ~ @Equation4293 Fin5 reff622_inst.
Proof. unfold Equation4293. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff622_inst, reff622_op in H. discriminate H. Qed.

Lemma reff622_not4314 : ~ @Equation4314 Fin5 reff622_inst.
Proof. unfold Equation4314. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff622_inst, reff622_op in H. discriminate H. Qed.

Lemma reff622_not4320 : ~ @Equation4320 Fin5 reff622_inst.
Proof. unfold Equation4320. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff622_inst, reff622_op in H. discriminate H. Qed.

Lemma reff622_not4321 : ~ @Equation4321 Fin5 reff622_inst.
Proof. unfold Equation4321. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff622_inst, reff622_op in H. discriminate H. Qed.

Lemma reff622_not4343 : ~ @Equation4343 Fin5 reff622_inst.
Proof. unfold Equation4343. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff622_inst, reff622_op in H. discriminate H. Qed.

Lemma reff622_not4396 : ~ @Equation4396 Fin5 reff622_inst.
Proof. unfold Equation4396. intro H. specialize (H F5_0 F5_3). unfold magma_op, reff622_inst, reff622_op in H. discriminate H. Qed.

Lemma reff622_not4398 : ~ @Equation4398 Fin5 reff622_inst.
Proof. unfold Equation4398. intro H. specialize (H F5_0 F5_2). unfold magma_op, reff622_inst, reff622_op in H. discriminate H. Qed.

Lemma reff622_not4399 : ~ @Equation4399 Fin5 reff622_inst.
Proof. unfold Equation4399. intro H. specialize (H F5_0 F5_3). unfold magma_op, reff622_inst, reff622_op in H. discriminate H. Qed.

Lemma reff622_not4405 : ~ @Equation4405 Fin5 reff622_inst.
Proof. unfold Equation4405. intro H. specialize (H F5_0 F5_2). unfold magma_op, reff622_inst, reff622_op in H. discriminate H. Qed.

Lemma reff622_not4406 : ~ @Equation4406 Fin5 reff622_inst.
Proof. unfold Equation4406. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff622_inst, reff622_op in H. discriminate H. Qed.

Lemma reff622_not4408 : ~ @Equation4408 Fin5 reff622_inst.
Proof. unfold Equation4408. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff622_inst, reff622_op in H. discriminate H. Qed.

Lemma reff622_not4433 : ~ @Equation4433 Fin5 reff622_inst.
Proof. unfold Equation4433. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff622_inst, reff622_op in H. discriminate H. Qed.

Lemma reff622_not4435 : ~ @Equation4435 Fin5 reff622_inst.
Proof. unfold Equation4435. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff622_inst, reff622_op in H. discriminate H. Qed.

Lemma reff622_not4436 : ~ @Equation4436 Fin5 reff622_inst.
Proof. unfold Equation4436. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff622_inst, reff622_op in H. discriminate H. Qed.

Lemma reff622_not4442 : ~ @Equation4442 Fin5 reff622_inst.
Proof. unfold Equation4442. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff622_inst, reff622_op in H. discriminate H. Qed.

Lemma reff622_not4443 : ~ @Equation4443 Fin5 reff622_inst.
Proof. unfold Equation4443. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff622_inst, reff622_op in H. discriminate H. Qed.

Lemma reff622_not4445 : ~ @Equation4445 Fin5 reff622_inst.
Proof. unfold Equation4445. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff622_inst, reff622_op in H. discriminate H. Qed.

Lemma reff622_not4472 : ~ @Equation4472 Fin5 reff622_inst.
Proof. unfold Equation4472. intro H. specialize (H F5_0 F5_2). unfold magma_op, reff622_inst, reff622_op in H. discriminate H. Qed.

Lemma reff622_not4473 : ~ @Equation4473 Fin5 reff622_inst.
Proof. unfold Equation4473. intro H. specialize (H F5_0 F5_3). unfold magma_op, reff622_inst, reff622_op in H. discriminate H. Qed.

Lemma reff622_not4479 : ~ @Equation4479 Fin5 reff622_inst.
Proof. unfold Equation4479. intro H. specialize (H F5_0 F5_2). unfold magma_op, reff622_inst, reff622_op in H. discriminate H. Qed.

Lemma reff622_not4480 : ~ @Equation4480 Fin5 reff622_inst.
Proof. unfold Equation4480. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff622_inst, reff622_op in H. discriminate H. Qed.

Lemma reff622_not4482 : ~ @Equation4482 Fin5 reff622_inst.
Proof. unfold Equation4482. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff622_inst, reff622_op in H. discriminate H. Qed.

Lemma reff622_not4583 : ~ @Equation4583 Fin5 reff622_inst.
Proof. unfold Equation4583. intro H. specialize (H F5_0 F5_2). unfold magma_op, reff622_inst, reff622_op in H. discriminate H. Qed.

Lemma reff622_not4584 : ~ @Equation4584 Fin5 reff622_inst.
Proof. unfold Equation4584. intro H. specialize (H F5_0 F5_2). unfold magma_op, reff622_inst, reff622_op in H. discriminate H. Qed.

Lemma reff622_not4585 : ~ @Equation4585 Fin5 reff622_inst.
Proof. unfold Equation4585. intro H. specialize (H F5_0 F5_2). unfold magma_op, reff622_inst, reff622_op in H. discriminate H. Qed.

Lemma reff622_not4587 : ~ @Equation4587 Fin5 reff622_inst.
Proof. unfold Equation4587. intro H. specialize (H F5_0 F5_4). unfold magma_op, reff622_inst, reff622_op in H. discriminate H. Qed.

Lemma reff622_not4588 : ~ @Equation4588 Fin5 reff622_inst.
Proof. unfold Equation4588. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff622_inst, reff622_op in H. discriminate H. Qed.

Lemma reff622_not4590 : ~ @Equation4590 Fin5 reff622_inst.
Proof. unfold Equation4590. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff622_inst, reff622_op in H. discriminate H. Qed.

Lemma reff622_not4591 : ~ @Equation4591 Fin5 reff622_inst.
Proof. unfold Equation4591. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff622_inst, reff622_op in H. discriminate H. Qed.

Lemma reff622_not4598 : ~ @Equation4598 Fin5 reff622_inst.
Proof. unfold Equation4598. intro H. specialize (H F5_0 F5_2). unfold magma_op, reff622_inst, reff622_op in H. discriminate H. Qed.

Lemma reff622_not4599 : ~ @Equation4599 Fin5 reff622_inst.
Proof. unfold Equation4599. intro H. specialize (H F5_0 F5_3). unfold magma_op, reff622_inst, reff622_op in H. discriminate H. Qed.

Lemma reff622_not4605 : ~ @Equation4605 Fin5 reff622_inst.
Proof. unfold Equation4605. intro H. specialize (H F5_0 F5_2). unfold magma_op, reff622_inst, reff622_op in H. discriminate H. Qed.

Lemma reff622_not4606 : ~ @Equation4606 Fin5 reff622_inst.
Proof. unfold Equation4606. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff622_inst, reff622_op in H. discriminate H. Qed.

Lemma reff622_not4608 : ~ @Equation4608 Fin5 reff622_inst.
Proof. unfold Equation4608. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff622_inst, reff622_op in H. discriminate H. Qed.

Lemma reff622_not4629 : ~ @Equation4629 Fin5 reff622_inst.
Proof. unfold Equation4629. intro H. specialize (H F5_0 F5_2). unfold magma_op, reff622_inst, reff622_op in H. discriminate H. Qed.

Lemma reff622_not4635 : ~ @Equation4635 Fin5 reff622_inst.
Proof. unfold Equation4635. intro H. specialize (H F5_0 F5_2). unfold magma_op, reff622_inst, reff622_op in H. discriminate H. Qed.

Lemma reff622_not4636 : ~ @Equation4636 Fin5 reff622_inst.
Proof. unfold Equation4636. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff622_inst, reff622_op in H. discriminate H. Qed.

Lemma reff622_not4658 : ~ @Equation4658 Fin5 reff622_inst.
Proof. unfold Equation4658. intro H. specialize (H F5_0 F5_2). unfold magma_op, reff622_inst, reff622_op in H. discriminate H. Qed.

(** ---- reff636 (Fin5) ---- *)

Definition reff636_op (x y : Fin5) : Fin5 :=
  match x, y with
  | F5_0, F5_0 => F5_0 | F5_0, F5_1 => F5_3 | F5_0, F5_2 => F5_1 | F5_0, F5_3 => F5_4 | F5_0, F5_4 => F5_2
  | F5_1, F5_0 => F5_2 | F5_1, F5_1 => F5_0 | F5_1, F5_2 => F5_3 | F5_1, F5_3 => F5_1 | F5_1, F5_4 => F5_4
  | F5_2, F5_0 => F5_4 | F5_2, F5_1 => F5_2 | F5_2, F5_2 => F5_0 | F5_2, F5_3 => F5_3 | F5_2, F5_4 => F5_1
  | F5_3, F5_0 => F5_1 | F5_3, F5_1 => F5_4 | F5_3, F5_2 => F5_2 | F5_3, F5_3 => F5_0 | F5_3, F5_4 => F5_3
  | F5_4, F5_0 => F5_3 | F5_4, F5_1 => F5_1 | F5_4, F5_2 => F5_4 | F5_4, F5_3 => F5_2 | F5_4, F5_4 => F5_0
  end.

#[local] Instance reff636_inst : Magma Fin5 := {| magma_op := reff636_op |}.

Lemma reff636_sat107 : @Equation107 Fin5 reff636_inst.
Proof. unfold Equation107, magma_op, reff636_inst, reff636_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff636_sat117 : @Equation117 Fin5 reff636_inst.
Proof. unfold Equation117, magma_op, reff636_inst, reff636_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff636_sat437 : @Equation437 Fin5 reff636_inst.
Proof. unfold Equation437, magma_op, reff636_inst, reff636_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff636_sat481 : @Equation481 Fin5 reff636_inst.
Proof. unfold Equation481, magma_op, reff636_inst, reff636_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff636_sat562 : @Equation562 Fin5 reff636_inst.
Proof. unfold Equation562, magma_op, reff636_inst, reff636_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff636_sat1454 : @Equation1454 Fin5 reff636_inst.
Proof. unfold Equation1454, magma_op, reff636_inst, reff636_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff636_sat1496 : @Equation1496 Fin5 reff636_inst.
Proof. unfold Equation1496, magma_op, reff636_inst, reff636_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff636_sat1523 : @Equation1523 Fin5 reff636_inst.
Proof. unfold Equation1523, magma_op, reff636_inst, reff636_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff636_sat2100 : @Equation2100 Fin5 reff636_inst.
Proof. unfold Equation2100, magma_op, reff636_inst, reff636_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff636_sat2132 : @Equation2132 Fin5 reff636_inst.
Proof. unfold Equation2132, magma_op, reff636_inst, reff636_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff636_sat2146 : @Equation2146 Fin5 reff636_inst.
Proof. unfold Equation2146, magma_op, reff636_inst, reff636_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff636_sat3106 : @Equation3106 Fin5 reff636_inst.
Proof. unfold Equation3106, magma_op, reff636_inst, reff636_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff636_sat3161 : @Equation3161 Fin5 reff636_inst.
Proof. unfold Equation3161, magma_op, reff636_inst, reff636_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff636_not47 : ~ @Equation47 Fin5 reff636_inst.
Proof. unfold Equation47. intro H. specialize (H F5_1). unfold magma_op, reff636_inst, reff636_op in H. discriminate H. Qed.

Lemma reff636_not102 : ~ @Equation102 Fin5 reff636_inst.
Proof. unfold Equation102. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff636_inst, reff636_op in H. discriminate H. Qed.

Lemma reff636_not105 : ~ @Equation105 Fin5 reff636_inst.
Proof. unfold Equation105. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff636_inst, reff636_op in H. discriminate H. Qed.

Lemma reff636_not108 : ~ @Equation108 Fin5 reff636_inst.
Proof. unfold Equation108. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff636_inst, reff636_op in H. discriminate H. Qed.

Lemma reff636_not115 : ~ @Equation115 Fin5 reff636_inst.
Proof. unfold Equation115. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff636_inst, reff636_op in H. discriminate H. Qed.

Lemma reff636_not118 : ~ @Equation118 Fin5 reff636_inst.
Proof. unfold Equation118. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff636_inst, reff636_op in H. discriminate H. Qed.

Lemma reff636_not124 : ~ @Equation124 Fin5 reff636_inst.
Proof. unfold Equation124. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff636_inst, reff636_op in H. discriminate H. Qed.

Lemma reff636_not125 : ~ @Equation125 Fin5 reff636_inst.
Proof. unfold Equation125. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff636_inst, reff636_op in H. discriminate H. Qed.

Lemma reff636_not127 : ~ @Equation127 Fin5 reff636_inst.
Proof. unfold Equation127. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff636_inst, reff636_op in H. discriminate H. Qed.

Lemma reff636_not151 : ~ @Equation151 Fin5 reff636_inst.
Proof. unfold Equation151. intro H. specialize (H F5_1). unfold magma_op, reff636_inst, reff636_op in H. discriminate H. Qed.

Lemma reff636_not203 : ~ @Equation203 Fin5 reff636_inst.
Proof. unfold Equation203. intro H. specialize (H F5_1). unfold magma_op, reff636_inst, reff636_op in H. discriminate H. Qed.

Lemma reff636_not255 : ~ @Equation255 Fin5 reff636_inst.
Proof. unfold Equation255. intro H. specialize (H F5_1). unfold magma_op, reff636_inst, reff636_op in H. discriminate H. Qed.

Lemma reff636_not412 : ~ @Equation412 Fin5 reff636_inst.
Proof. unfold Equation412. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff636_inst, reff636_op in H. discriminate H. Qed.

Lemma reff636_not413 : ~ @Equation413 Fin5 reff636_inst.
Proof. unfold Equation413. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff636_inst, reff636_op in H. discriminate H. Qed.

Lemma reff636_not416 : ~ @Equation416 Fin5 reff636_inst.
Proof. unfold Equation416. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff636_inst, reff636_op in H. discriminate H. Qed.

Lemma reff636_not417 : ~ @Equation417 Fin5 reff636_inst.
Proof. unfold Equation417. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff636_inst, reff636_op in H. discriminate H. Qed.

Lemma reff636_not419 : ~ @Equation419 Fin5 reff636_inst.
Proof. unfold Equation419. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff636_inst, reff636_op in H. discriminate H. Qed.

Lemma reff636_not420 : ~ @Equation420 Fin5 reff636_inst.
Proof. unfold Equation420. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff636_inst, reff636_op in H. discriminate H. Qed.

Lemma reff636_not426 : ~ @Equation426 Fin5 reff636_inst.
Proof. unfold Equation426. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff636_inst, reff636_op in H. discriminate H. Qed.

Lemma reff636_not427 : ~ @Equation427 Fin5 reff636_inst.
Proof. unfold Equation427. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff636_inst, reff636_op in H. discriminate H. Qed.

Lemma reff636_not430 : ~ @Equation430 Fin5 reff636_inst.
Proof. unfold Equation430. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff636_inst, reff636_op in H. discriminate H. Qed.

Lemma reff636_not436 : ~ @Equation436 Fin5 reff636_inst.
Proof. unfold Equation436. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff636_inst, reff636_op in H. discriminate H. Qed.

Lemma reff636_not439 : ~ @Equation439 Fin5 reff636_inst.
Proof. unfold Equation439. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff636_inst, reff636_op in H. discriminate H. Qed.

Lemma reff636_not440 : ~ @Equation440 Fin5 reff636_inst.
Proof. unfold Equation440. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff636_inst, reff636_op in H. discriminate H. Qed.

Lemma reff636_not463 : ~ @Equation463 Fin5 reff636_inst.
Proof. unfold Equation463. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff636_inst, reff636_op in H. discriminate H. Qed.

Lemma reff636_not464 : ~ @Equation464 Fin5 reff636_inst.
Proof. unfold Equation464. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff636_inst, reff636_op in H. discriminate H. Qed.

Lemma reff636_not466 : ~ @Equation466 Fin5 reff636_inst.
Proof. unfold Equation466. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff636_inst, reff636_op in H. discriminate H. Qed.

Lemma reff636_not467 : ~ @Equation467 Fin5 reff636_inst.
Proof. unfold Equation467. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff636_inst, reff636_op in H. discriminate H. Qed.

Lemma reff636_not474 : ~ @Equation474 Fin5 reff636_inst.
Proof. unfold Equation474. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff636_inst, reff636_op in H. discriminate H. Qed.

Lemma reff636_not476 : ~ @Equation476 Fin5 reff636_inst.
Proof. unfold Equation476. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff636_inst, reff636_op in H. discriminate H. Qed.

Lemma reff636_not500 : ~ @Equation500 Fin5 reff636_inst.
Proof. unfold Equation500. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff636_inst, reff636_op in H. discriminate H. Qed.

Lemma reff636_not501 : ~ @Equation501 Fin5 reff636_inst.
Proof. unfold Equation501. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff636_inst, reff636_op in H. discriminate H. Qed.

Lemma reff636_not503 : ~ @Equation503 Fin5 reff636_inst.
Proof. unfold Equation503. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff636_inst, reff636_op in H. discriminate H. Qed.

Lemma reff636_not504 : ~ @Equation504 Fin5 reff636_inst.
Proof. unfold Equation504. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff636_inst, reff636_op in H. discriminate H. Qed.

Lemma reff636_not510 : ~ @Equation510 Fin5 reff636_inst.
Proof. unfold Equation510. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff636_inst, reff636_op in H. discriminate H. Qed.

Lemma reff636_not511 : ~ @Equation511 Fin5 reff636_inst.
Proof. unfold Equation511. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff636_inst, reff636_op in H. discriminate H. Qed.

Lemma reff636_not614 : ~ @Equation614 Fin5 reff636_inst.
Proof. unfold Equation614. intro H. specialize (H F5_1). unfold magma_op, reff636_inst, reff636_op in H. discriminate H. Qed.

Lemma reff636_not817 : ~ @Equation817 Fin5 reff636_inst.
Proof. unfold Equation817. intro H. specialize (H F5_1). unfold magma_op, reff636_inst, reff636_op in H. discriminate H. Qed.

Lemma reff636_not1020 : ~ @Equation1020 Fin5 reff636_inst.
Proof. unfold Equation1020. intro H. specialize (H F5_1). unfold magma_op, reff636_inst, reff636_op in H. discriminate H. Qed.

Lemma reff636_not1223 : ~ @Equation1223 Fin5 reff636_inst.
Proof. unfold Equation1223. intro H. specialize (H F5_1). unfold magma_op, reff636_inst, reff636_op in H. discriminate H. Qed.

Lemma reff636_not1427 : ~ @Equation1427 Fin5 reff636_inst.
Proof. unfold Equation1427. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff636_inst, reff636_op in H. discriminate H. Qed.

Lemma reff636_not1428 : ~ @Equation1428 Fin5 reff636_inst.
Proof. unfold Equation1428. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff636_inst, reff636_op in H. discriminate H. Qed.

Lemma reff636_not1431 : ~ @Equation1431 Fin5 reff636_inst.
Proof. unfold Equation1431. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff636_inst, reff636_op in H. discriminate H. Qed.

Lemma reff636_not1432 : ~ @Equation1432 Fin5 reff636_inst.
Proof. unfold Equation1432. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff636_inst, reff636_op in H. discriminate H. Qed.

Lemma reff636_not1434 : ~ @Equation1434 Fin5 reff636_inst.
Proof. unfold Equation1434. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff636_inst, reff636_op in H. discriminate H. Qed.

Lemma reff636_not1435 : ~ @Equation1435 Fin5 reff636_inst.
Proof. unfold Equation1435. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff636_inst, reff636_op in H. discriminate H. Qed.

Lemma reff636_not1441 : ~ @Equation1441 Fin5 reff636_inst.
Proof. unfold Equation1441. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff636_inst, reff636_op in H. discriminate H. Qed.

Lemma reff636_not1442 : ~ @Equation1442 Fin5 reff636_inst.
Proof. unfold Equation1442. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff636_inst, reff636_op in H. discriminate H. Qed.

Lemma reff636_not1444 : ~ @Equation1444 Fin5 reff636_inst.
Proof. unfold Equation1444. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff636_inst, reff636_op in H. discriminate H. Qed.

Lemma reff636_not1445 : ~ @Equation1445 Fin5 reff636_inst.
Proof. unfold Equation1445. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff636_inst, reff636_op in H. discriminate H. Qed.

Lemma reff636_not1451 : ~ @Equation1451 Fin5 reff636_inst.
Proof. unfold Equation1451. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff636_inst, reff636_op in H. discriminate H. Qed.

Lemma reff636_not1452 : ~ @Equation1452 Fin5 reff636_inst.
Proof. unfold Equation1452. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff636_inst, reff636_op in H. discriminate H. Qed.

Lemma reff636_not1455 : ~ @Equation1455 Fin5 reff636_inst.
Proof. unfold Equation1455. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff636_inst, reff636_op in H. discriminate H. Qed.

Lemma reff636_not1478 : ~ @Equation1478 Fin5 reff636_inst.
Proof. unfold Equation1478. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff636_inst, reff636_op in H. discriminate H. Qed.

Lemma reff636_not1479 : ~ @Equation1479 Fin5 reff636_inst.
Proof. unfold Equation1479. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff636_inst, reff636_op in H. discriminate H. Qed.

Lemma reff636_not1481 : ~ @Equation1481 Fin5 reff636_inst.
Proof. unfold Equation1481. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff636_inst, reff636_op in H. discriminate H. Qed.

Lemma reff636_not1482 : ~ @Equation1482 Fin5 reff636_inst.
Proof. unfold Equation1482. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff636_inst, reff636_op in H. discriminate H. Qed.

Lemma reff636_not1489 : ~ @Equation1489 Fin5 reff636_inst.
Proof. unfold Equation1489. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff636_inst, reff636_op in H. discriminate H. Qed.

Lemma reff636_not1491 : ~ @Equation1491 Fin5 reff636_inst.
Proof. unfold Equation1491. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff636_inst, reff636_op in H. discriminate H. Qed.

Lemma reff636_not1516 : ~ @Equation1516 Fin5 reff636_inst.
Proof. unfold Equation1516. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff636_inst, reff636_op in H. discriminate H. Qed.

Lemma reff636_not1518 : ~ @Equation1518 Fin5 reff636_inst.
Proof. unfold Equation1518. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff636_inst, reff636_op in H. discriminate H. Qed.

Lemma reff636_not1525 : ~ @Equation1525 Fin5 reff636_inst.
Proof. unfold Equation1525. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff636_inst, reff636_op in H. discriminate H. Qed.

Lemma reff636_not1526 : ~ @Equation1526 Fin5 reff636_inst.
Proof. unfold Equation1526. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff636_inst, reff636_op in H. discriminate H. Qed.

Lemma reff636_not1528 : ~ @Equation1528 Fin5 reff636_inst.
Proof. unfold Equation1528. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff636_inst, reff636_op in H. discriminate H. Qed.

Lemma reff636_not1629 : ~ @Equation1629 Fin5 reff636_inst.
Proof. unfold Equation1629. intro H. specialize (H F5_1). unfold magma_op, reff636_inst, reff636_op in H. discriminate H. Qed.

Lemma reff636_not1832 : ~ @Equation1832 Fin5 reff636_inst.
Proof. unfold Equation1832. intro H. specialize (H F5_1). unfold magma_op, reff636_inst, reff636_op in H. discriminate H. Qed.

Lemma reff636_not2036 : ~ @Equation2036 Fin5 reff636_inst.
Proof. unfold Equation2036. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff636_inst, reff636_op in H. discriminate H. Qed.

Lemma reff636_not2037 : ~ @Equation2037 Fin5 reff636_inst.
Proof. unfold Equation2037. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff636_inst, reff636_op in H. discriminate H. Qed.

Lemma reff636_not2040 : ~ @Equation2040 Fin5 reff636_inst.
Proof. unfold Equation2040. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff636_inst, reff636_op in H. discriminate H. Qed.

Lemma reff636_not2043 : ~ @Equation2043 Fin5 reff636_inst.
Proof. unfold Equation2043. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff636_inst, reff636_op in H. discriminate H. Qed.

Lemma reff636_not2044 : ~ @Equation2044 Fin5 reff636_inst.
Proof. unfold Equation2044. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff636_inst, reff636_op in H. discriminate H. Qed.

Lemma reff636_not2050 : ~ @Equation2050 Fin5 reff636_inst.
Proof. unfold Equation2050. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff636_inst, reff636_op in H. discriminate H. Qed.

Lemma reff636_not2051 : ~ @Equation2051 Fin5 reff636_inst.
Proof. unfold Equation2051. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff636_inst, reff636_op in H. discriminate H. Qed.

Lemma reff636_not2053 : ~ @Equation2053 Fin5 reff636_inst.
Proof. unfold Equation2053. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff636_inst, reff636_op in H. discriminate H. Qed.

Lemma reff636_not2054 : ~ @Equation2054 Fin5 reff636_inst.
Proof. unfold Equation2054. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff636_inst, reff636_op in H. discriminate H. Qed.

Lemma reff636_not2060 : ~ @Equation2060 Fin5 reff636_inst.
Proof. unfold Equation2060. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff636_inst, reff636_op in H. discriminate H. Qed.

Lemma reff636_not2061 : ~ @Equation2061 Fin5 reff636_inst.
Proof. unfold Equation2061. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff636_inst, reff636_op in H. discriminate H. Qed.

Lemma reff636_not2063 : ~ @Equation2063 Fin5 reff636_inst.
Proof. unfold Equation2063. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff636_inst, reff636_op in H. discriminate H. Qed.

Lemma reff636_not2064 : ~ @Equation2064 Fin5 reff636_inst.
Proof. unfold Equation2064. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff636_inst, reff636_op in H. discriminate H. Qed.

Lemma reff636_not2087 : ~ @Equation2087 Fin5 reff636_inst.
Proof. unfold Equation2087. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff636_inst, reff636_op in H. discriminate H. Qed.

Lemma reff636_not2088 : ~ @Equation2088 Fin5 reff636_inst.
Proof. unfold Equation2088. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff636_inst, reff636_op in H. discriminate H. Qed.

Lemma reff636_not2090 : ~ @Equation2090 Fin5 reff636_inst.
Proof. unfold Equation2090. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff636_inst, reff636_op in H. discriminate H. Qed.

Lemma reff636_not2091 : ~ @Equation2091 Fin5 reff636_inst.
Proof. unfold Equation2091. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff636_inst, reff636_op in H. discriminate H. Qed.

Lemma reff636_not2097 : ~ @Equation2097 Fin5 reff636_inst.
Proof. unfold Equation2097. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff636_inst, reff636_op in H. discriminate H. Qed.

Lemma reff636_not2098 : ~ @Equation2098 Fin5 reff636_inst.
Proof. unfold Equation2098. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff636_inst, reff636_op in H. discriminate H. Qed.

Lemma reff636_not2101 : ~ @Equation2101 Fin5 reff636_inst.
Proof. unfold Equation2101. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff636_inst, reff636_op in H. discriminate H. Qed.

Lemma reff636_not2125 : ~ @Equation2125 Fin5 reff636_inst.
Proof. unfold Equation2125. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff636_inst, reff636_op in H. discriminate H. Qed.

Lemma reff636_not2127 : ~ @Equation2127 Fin5 reff636_inst.
Proof. unfold Equation2127. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff636_inst, reff636_op in H. discriminate H. Qed.

Lemma reff636_not2134 : ~ @Equation2134 Fin5 reff636_inst.
Proof. unfold Equation2134. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff636_inst, reff636_op in H. discriminate H. Qed.

Lemma reff636_not2137 : ~ @Equation2137 Fin5 reff636_inst.
Proof. unfold Equation2137. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff636_inst, reff636_op in H. discriminate H. Qed.

Lemma reff636_not2238 : ~ @Equation2238 Fin5 reff636_inst.
Proof. unfold Equation2238. intro H. specialize (H F5_1). unfold magma_op, reff636_inst, reff636_op in H. discriminate H. Qed.

Lemma reff636_not2441 : ~ @Equation2441 Fin5 reff636_inst.
Proof. unfold Equation2441. intro H. specialize (H F5_1). unfold magma_op, reff636_inst, reff636_op in H. discriminate H. Qed.

Lemma reff636_not2644 : ~ @Equation2644 Fin5 reff636_inst.
Proof. unfold Equation2644. intro H. specialize (H F5_1). unfold magma_op, reff636_inst, reff636_op in H. discriminate H. Qed.

Lemma reff636_not2847 : ~ @Equation2847 Fin5 reff636_inst.
Proof. unfold Equation2847. intro H. specialize (H F5_1). unfold magma_op, reff636_inst, reff636_op in H. discriminate H. Qed.

Lemma reff636_not3051 : ~ @Equation3051 Fin5 reff636_inst.
Proof. unfold Equation3051. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff636_inst, reff636_op in H. discriminate H. Qed.

Lemma reff636_not3052 : ~ @Equation3052 Fin5 reff636_inst.
Proof. unfold Equation3052. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff636_inst, reff636_op in H. discriminate H. Qed.

Lemma reff636_not3053 : ~ @Equation3053 Fin5 reff636_inst.
Proof. unfold Equation3053. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff636_inst, reff636_op in H. discriminate H. Qed.

Lemma reff636_not3055 : ~ @Equation3055 Fin5 reff636_inst.
Proof. unfold Equation3055. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff636_inst, reff636_op in H. discriminate H. Qed.

Lemma reff636_not3058 : ~ @Equation3058 Fin5 reff636_inst.
Proof. unfold Equation3058. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff636_inst, reff636_op in H. discriminate H. Qed.

Lemma reff636_not3059 : ~ @Equation3059 Fin5 reff636_inst.
Proof. unfold Equation3059. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff636_inst, reff636_op in H. discriminate H. Qed.

Lemma reff636_not3065 : ~ @Equation3065 Fin5 reff636_inst.
Proof. unfold Equation3065. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff636_inst, reff636_op in H. discriminate H. Qed.

Lemma reff636_not3066 : ~ @Equation3066 Fin5 reff636_inst.
Proof. unfold Equation3066. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff636_inst, reff636_op in H. discriminate H. Qed.

Lemma reff636_not3069 : ~ @Equation3069 Fin5 reff636_inst.
Proof. unfold Equation3069. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff636_inst, reff636_op in H. discriminate H. Qed.

Lemma reff636_not3075 : ~ @Equation3075 Fin5 reff636_inst.
Proof. unfold Equation3075. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff636_inst, reff636_op in H. discriminate H. Qed.

Lemma reff636_not3076 : ~ @Equation3076 Fin5 reff636_inst.
Proof. unfold Equation3076. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff636_inst, reff636_op in H. discriminate H. Qed.

Lemma reff636_not3078 : ~ @Equation3078 Fin5 reff636_inst.
Proof. unfold Equation3078. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff636_inst, reff636_op in H. discriminate H. Qed.

Lemma reff636_not3102 : ~ @Equation3102 Fin5 reff636_inst.
Proof. unfold Equation3102. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff636_inst, reff636_op in H. discriminate H. Qed.

Lemma reff636_not3103 : ~ @Equation3103 Fin5 reff636_inst.
Proof. unfold Equation3103. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff636_inst, reff636_op in H. discriminate H. Qed.

Lemma reff636_not3105 : ~ @Equation3105 Fin5 reff636_inst.
Proof. unfold Equation3105. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff636_inst, reff636_op in H. discriminate H. Qed.

Lemma reff636_not3112 : ~ @Equation3112 Fin5 reff636_inst.
Proof. unfold Equation3112. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff636_inst, reff636_op in H. discriminate H. Qed.

Lemma reff636_not3113 : ~ @Equation3113 Fin5 reff636_inst.
Proof. unfold Equation3113. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff636_inst, reff636_op in H. discriminate H. Qed.

Lemma reff636_not3115 : ~ @Equation3115 Fin5 reff636_inst.
Proof. unfold Equation3115. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff636_inst, reff636_op in H. discriminate H. Qed.

Lemma reff636_not3116 : ~ @Equation3116 Fin5 reff636_inst.
Proof. unfold Equation3116. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff636_inst, reff636_op in H. discriminate H. Qed.

Lemma reff636_not3140 : ~ @Equation3140 Fin5 reff636_inst.
Proof. unfold Equation3140. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff636_inst, reff636_op in H. discriminate H. Qed.

Lemma reff636_not3142 : ~ @Equation3142 Fin5 reff636_inst.
Proof. unfold Equation3142. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff636_inst, reff636_op in H. discriminate H. Qed.

Lemma reff636_not3143 : ~ @Equation3143 Fin5 reff636_inst.
Proof. unfold Equation3143. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff636_inst, reff636_op in H. discriminate H. Qed.

Lemma reff636_not3149 : ~ @Equation3149 Fin5 reff636_inst.
Proof. unfold Equation3149. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff636_inst, reff636_op in H. discriminate H. Qed.

Lemma reff636_not3152 : ~ @Equation3152 Fin5 reff636_inst.
Proof. unfold Equation3152. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff636_inst, reff636_op in H. discriminate H. Qed.

Lemma reff636_not3253 : ~ @Equation3253 Fin5 reff636_inst.
Proof. unfold Equation3253. intro H. specialize (H F5_1). unfold magma_op, reff636_inst, reff636_op in H. discriminate H. Qed.

Lemma reff636_not3456 : ~ @Equation3456 Fin5 reff636_inst.
Proof. unfold Equation3456. intro H. specialize (H F5_1). unfold magma_op, reff636_inst, reff636_op in H. discriminate H. Qed.

Lemma reff636_not3660 : ~ @Equation3660 Fin5 reff636_inst.
Proof. unfold Equation3660. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff636_inst, reff636_op in H. discriminate H. Qed.

Lemma reff636_not3661 : ~ @Equation3661 Fin5 reff636_inst.
Proof. unfold Equation3661. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff636_inst, reff636_op in H. discriminate H. Qed.

Lemma reff636_not3664 : ~ @Equation3664 Fin5 reff636_inst.
Proof. unfold Equation3664. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff636_inst, reff636_op in H. discriminate H. Qed.

Lemma reff636_not3667 : ~ @Equation3667 Fin5 reff636_inst.
Proof. unfold Equation3667. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff636_inst, reff636_op in H. discriminate H. Qed.

Lemma reff636_not3668 : ~ @Equation3668 Fin5 reff636_inst.
Proof. unfold Equation3668. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff636_inst, reff636_op in H. discriminate H. Qed.

Lemma reff636_not3674 : ~ @Equation3674 Fin5 reff636_inst.
Proof. unfold Equation3674. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff636_inst, reff636_op in H. discriminate H. Qed.

Lemma reff636_not3675 : ~ @Equation3675 Fin5 reff636_inst.
Proof. unfold Equation3675. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff636_inst, reff636_op in H. discriminate H. Qed.

Lemma reff636_not3678 : ~ @Equation3678 Fin5 reff636_inst.
Proof. unfold Equation3678. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff636_inst, reff636_op in H. discriminate H. Qed.

Lemma reff636_not3685 : ~ @Equation3685 Fin5 reff636_inst.
Proof. unfold Equation3685. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff636_inst, reff636_op in H. discriminate H. Qed.

Lemma reff636_not3687 : ~ @Equation3687 Fin5 reff636_inst.
Proof. unfold Equation3687. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff636_inst, reff636_op in H. discriminate H. Qed.

Lemma reff636_not3712 : ~ @Equation3712 Fin5 reff636_inst.
Proof. unfold Equation3712. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff636_inst, reff636_op in H. discriminate H. Qed.

Lemma reff636_not3714 : ~ @Equation3714 Fin5 reff636_inst.
Proof. unfold Equation3714. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff636_inst, reff636_op in H. discriminate H. Qed.

Lemma reff636_not3721 : ~ @Equation3721 Fin5 reff636_inst.
Proof. unfold Equation3721. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff636_inst, reff636_op in H. discriminate H. Qed.

Lemma reff636_not3722 : ~ @Equation3722 Fin5 reff636_inst.
Proof. unfold Equation3722. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff636_inst, reff636_op in H. discriminate H. Qed.

Lemma reff636_not3724 : ~ @Equation3724 Fin5 reff636_inst.
Proof. unfold Equation3724. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff636_inst, reff636_op in H. discriminate H. Qed.

Lemma reff636_not3725 : ~ @Equation3725 Fin5 reff636_inst.
Proof. unfold Equation3725. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff636_inst, reff636_op in H. discriminate H. Qed.

Lemma reff636_not3748 : ~ @Equation3748 Fin5 reff636_inst.
Proof. unfold Equation3748. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff636_inst, reff636_op in H. discriminate H. Qed.

Lemma reff636_not3751 : ~ @Equation3751 Fin5 reff636_inst.
Proof. unfold Equation3751. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff636_inst, reff636_op in H. discriminate H. Qed.

Lemma reff636_not3752 : ~ @Equation3752 Fin5 reff636_inst.
Proof. unfold Equation3752. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff636_inst, reff636_op in H. discriminate H. Qed.

Lemma reff636_not3759 : ~ @Equation3759 Fin5 reff636_inst.
Proof. unfold Equation3759. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff636_inst, reff636_op in H. discriminate H. Qed.

Lemma reff636_not3761 : ~ @Equation3761 Fin5 reff636_inst.
Proof. unfold Equation3761. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff636_inst, reff636_op in H. discriminate H. Qed.

Lemma reff636_not3862 : ~ @Equation3862 Fin5 reff636_inst.
Proof. unfold Equation3862. intro H. specialize (H F5_1). unfold magma_op, reff636_inst, reff636_op in H. discriminate H. Qed.

Lemma reff636_not4065 : ~ @Equation4065 Fin5 reff636_inst.
Proof. unfold Equation4065. intro H. specialize (H F5_1). unfold magma_op, reff636_inst, reff636_op in H. discriminate H. Qed.

Lemma reff636_not4268 : ~ @Equation4268 Fin5 reff636_inst.
Proof. unfold Equation4268. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff636_inst, reff636_op in H. discriminate H. Qed.

Lemma reff636_not4269 : ~ @Equation4269 Fin5 reff636_inst.
Proof. unfold Equation4269. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff636_inst, reff636_op in H. discriminate H. Qed.

Lemma reff636_not4272 : ~ @Equation4272 Fin5 reff636_inst.
Proof. unfold Equation4272. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff636_inst, reff636_op in H. discriminate H. Qed.

Lemma reff636_not4273 : ~ @Equation4273 Fin5 reff636_inst.
Proof. unfold Equation4273. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff636_inst, reff636_op in H. discriminate H. Qed.

Lemma reff636_not4275 : ~ @Equation4275 Fin5 reff636_inst.
Proof. unfold Equation4275. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff636_inst, reff636_op in H. discriminate H. Qed.

Lemma reff636_not4276 : ~ @Equation4276 Fin5 reff636_inst.
Proof. unfold Equation4276. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff636_inst, reff636_op in H. discriminate H. Qed.

Lemma reff636_not4283 : ~ @Equation4283 Fin5 reff636_inst.
Proof. unfold Equation4283. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff636_inst, reff636_op in H. discriminate H. Qed.

Lemma reff636_not4284 : ~ @Equation4284 Fin5 reff636_inst.
Proof. unfold Equation4284. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff636_inst, reff636_op in H. discriminate H. Qed.

Lemma reff636_not4290 : ~ @Equation4290 Fin5 reff636_inst.
Proof. unfold Equation4290. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff636_inst, reff636_op in H. discriminate H. Qed.

Lemma reff636_not4291 : ~ @Equation4291 Fin5 reff636_inst.
Proof. unfold Equation4291. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff636_inst, reff636_op in H. discriminate H. Qed.

Lemma reff636_not4293 : ~ @Equation4293 Fin5 reff636_inst.
Proof. unfold Equation4293. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff636_inst, reff636_op in H. discriminate H. Qed.

Lemma reff636_not4314 : ~ @Equation4314 Fin5 reff636_inst.
Proof. unfold Equation4314. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff636_inst, reff636_op in H. discriminate H. Qed.

Lemma reff636_not4320 : ~ @Equation4320 Fin5 reff636_inst.
Proof. unfold Equation4320. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff636_inst, reff636_op in H. discriminate H. Qed.

Lemma reff636_not4343 : ~ @Equation4343 Fin5 reff636_inst.
Proof. unfold Equation4343. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff636_inst, reff636_op in H. discriminate H. Qed.

Lemma reff636_not4380 : ~ @Equation4380 Fin5 reff636_inst.
Proof. unfold Equation4380. intro H. specialize (H F5_1). unfold magma_op, reff636_inst, reff636_op in H. discriminate H. Qed.

Lemma reff636_not4583 : ~ @Equation4583 Fin5 reff636_inst.
Proof. unfold Equation4583. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff636_inst, reff636_op in H. discriminate H. Qed.

Lemma reff636_not4584 : ~ @Equation4584 Fin5 reff636_inst.
Proof. unfold Equation4584. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff636_inst, reff636_op in H. discriminate H. Qed.

Lemma reff636_not4585 : ~ @Equation4585 Fin5 reff636_inst.
Proof. unfold Equation4585. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff636_inst, reff636_op in H. discriminate H. Qed.

Lemma reff636_not4587 : ~ @Equation4587 Fin5 reff636_inst.
Proof. unfold Equation4587. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff636_inst, reff636_op in H. discriminate H. Qed.

Lemma reff636_not4588 : ~ @Equation4588 Fin5 reff636_inst.
Proof. unfold Equation4588. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff636_inst, reff636_op in H. discriminate H. Qed.

Lemma reff636_not4591 : ~ @Equation4591 Fin5 reff636_inst.
Proof. unfold Equation4591. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff636_inst, reff636_op in H. discriminate H. Qed.

Lemma reff636_not4598 : ~ @Equation4598 Fin5 reff636_inst.
Proof. unfold Equation4598. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff636_inst, reff636_op in H. discriminate H. Qed.

Lemma reff636_not4599 : ~ @Equation4599 Fin5 reff636_inst.
Proof. unfold Equation4599. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff636_inst, reff636_op in H. discriminate H. Qed.

Lemma reff636_not4605 : ~ @Equation4605 Fin5 reff636_inst.
Proof. unfold Equation4605. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff636_inst, reff636_op in H. discriminate H. Qed.

Lemma reff636_not4606 : ~ @Equation4606 Fin5 reff636_inst.
Proof. unfold Equation4606. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff636_inst, reff636_op in H. discriminate H. Qed.

Lemma reff636_not4608 : ~ @Equation4608 Fin5 reff636_inst.
Proof. unfold Equation4608. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff636_inst, reff636_op in H. discriminate H. Qed.

Lemma reff636_not4629 : ~ @Equation4629 Fin5 reff636_inst.
Proof. unfold Equation4629. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff636_inst, reff636_op in H. discriminate H. Qed.

Lemma reff636_not4635 : ~ @Equation4635 Fin5 reff636_inst.
Proof. unfold Equation4635. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff636_inst, reff636_op in H. discriminate H. Qed.

Lemma reff636_not4636 : ~ @Equation4636 Fin5 reff636_inst.
Proof. unfold Equation4636. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff636_inst, reff636_op in H. discriminate H. Qed.

(** ---- reff656 (Fin5) ---- *)

Definition reff656_op (x y : Fin5) : Fin5 :=
  match x, y with
  | F5_0, F5_0 => F5_0 | F5_0, F5_1 => F5_3 | F5_0, F5_2 => F5_1 | F5_0, F5_3 => F5_4 | F5_0, F5_4 => F5_2
  | F5_1, F5_0 => F5_1 | F5_1, F5_1 => F5_4 | F5_1, F5_2 => F5_2 | F5_1, F5_3 => F5_0 | F5_1, F5_4 => F5_3
  | F5_2, F5_0 => F5_2 | F5_2, F5_1 => F5_0 | F5_2, F5_2 => F5_3 | F5_2, F5_3 => F5_1 | F5_2, F5_4 => F5_4
  | F5_3, F5_0 => F5_3 | F5_3, F5_1 => F5_1 | F5_3, F5_2 => F5_4 | F5_3, F5_3 => F5_2 | F5_3, F5_4 => F5_0
  | F5_4, F5_0 => F5_4 | F5_4, F5_1 => F5_2 | F5_4, F5_2 => F5_0 | F5_4, F5_3 => F5_3 | F5_4, F5_4 => F5_1
  end.

#[local] Instance reff656_inst : Magma Fin5 := {| magma_op := reff656_op |}.

Lemma reff656_sat160 : @Equation160 Fin5 reff656_inst.
Proof. unfold Equation160, magma_op, reff656_inst, reff656_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff656_sat167 : @Equation167 Fin5 reff656_inst.
Proof. unfold Equation167, magma_op, reff656_inst, reff656_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff656_sat212 : @Equation212 Fin5 reff656_inst.
Proof. unfold Equation212, magma_op, reff656_inst, reff656_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff656_sat221 : @Equation221 Fin5 reff656_inst.
Proof. unfold Equation221, magma_op, reff656_inst, reff656_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff656_sat452 : @Equation452 Fin5 reff656_inst.
Proof. unfold Equation452, magma_op, reff656_inst, reff656_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff656_sat501 : @Equation501 Fin5 reff656_inst.
Proof. unfold Equation501, magma_op, reff656_inst, reff656_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff656_sat562 : @Equation562 Fin5 reff656_inst.
Proof. unfold Equation562, magma_op, reff656_inst, reff656_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff656_sat1252 : @Equation1252 Fin5 reff656_inst.
Proof. unfold Equation1252, magma_op, reff656_inst, reff656_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff656_sat1276 : @Equation1276 Fin5 reff656_inst.
Proof. unfold Equation1276, magma_op, reff656_inst, reff656_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff656_sat1278 : @Equation1278 Fin5 reff656_inst.
Proof. unfold Equation1278, magma_op, reff656_inst, reff656_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff656_sat1285 : @Equation1285 Fin5 reff656_inst.
Proof. unfold Equation1285, magma_op, reff656_inst, reff656_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff656_sat4273 : @Equation4273 Fin5 reff656_inst.
Proof. unfold Equation4273, magma_op, reff656_inst, reff656_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff656_not47 : ~ @Equation47 Fin5 reff656_inst.
Proof. unfold Equation47. intro H. specialize (H F5_1). unfold magma_op, reff656_inst, reff656_op in H. discriminate H. Qed.

Lemma reff656_not99 : ~ @Equation99 Fin5 reff656_inst.
Proof. unfold Equation99. intro H. specialize (H F5_1). unfold magma_op, reff656_inst, reff656_op in H. discriminate H. Qed.

Lemma reff656_not154 : ~ @Equation154 Fin5 reff656_inst.
Proof. unfold Equation154. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff656_inst, reff656_op in H. discriminate H. Qed.

Lemma reff656_not157 : ~ @Equation157 Fin5 reff656_inst.
Proof. unfold Equation157. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff656_inst, reff656_op in H. discriminate H. Qed.

Lemma reff656_not159 : ~ @Equation159 Fin5 reff656_inst.
Proof. unfold Equation159. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff656_inst, reff656_op in H. discriminate H. Qed.

Lemma reff656_not169 : ~ @Equation169 Fin5 reff656_inst.
Proof. unfold Equation169. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff656_inst, reff656_op in H. discriminate H. Qed.

Lemma reff656_not170 : ~ @Equation170 Fin5 reff656_inst.
Proof. unfold Equation170. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff656_inst, reff656_op in H. discriminate H. Qed.

Lemma reff656_not176 : ~ @Equation176 Fin5 reff656_inst.
Proof. unfold Equation176. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff656_inst, reff656_op in H. discriminate H. Qed.

Lemma reff656_not177 : ~ @Equation177 Fin5 reff656_inst.
Proof. unfold Equation177. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff656_inst, reff656_op in H. discriminate H. Qed.

Lemma reff656_not179 : ~ @Equation179 Fin5 reff656_inst.
Proof. unfold Equation179. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff656_inst, reff656_op in H. discriminate H. Qed.

Lemma reff656_not206 : ~ @Equation206 Fin5 reff656_inst.
Proof. unfold Equation206. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff656_inst, reff656_op in H. discriminate H. Qed.

Lemma reff656_not209 : ~ @Equation209 Fin5 reff656_inst.
Proof. unfold Equation209. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff656_inst, reff656_op in H. discriminate H. Qed.

Lemma reff656_not211 : ~ @Equation211 Fin5 reff656_inst.
Proof. unfold Equation211. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff656_inst, reff656_op in H. discriminate H. Qed.

Lemma reff656_not219 : ~ @Equation219 Fin5 reff656_inst.
Proof. unfold Equation219. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff656_inst, reff656_op in H. discriminate H. Qed.

Lemma reff656_not222 : ~ @Equation222 Fin5 reff656_inst.
Proof. unfold Equation222. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff656_inst, reff656_op in H. discriminate H. Qed.

Lemma reff656_not228 : ~ @Equation228 Fin5 reff656_inst.
Proof. unfold Equation228. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff656_inst, reff656_op in H. discriminate H. Qed.

Lemma reff656_not229 : ~ @Equation229 Fin5 reff656_inst.
Proof. unfold Equation229. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff656_inst, reff656_op in H. discriminate H. Qed.

Lemma reff656_not231 : ~ @Equation231 Fin5 reff656_inst.
Proof. unfold Equation231. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff656_inst, reff656_op in H. discriminate H. Qed.

Lemma reff656_not255 : ~ @Equation255 Fin5 reff656_inst.
Proof. unfold Equation255. intro H. specialize (H F5_1). unfold magma_op, reff656_inst, reff656_op in H. discriminate H. Qed.

Lemma reff656_not412 : ~ @Equation412 Fin5 reff656_inst.
Proof. unfold Equation412. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff656_inst, reff656_op in H. discriminate H. Qed.

Lemma reff656_not413 : ~ @Equation413 Fin5 reff656_inst.
Proof. unfold Equation413. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff656_inst, reff656_op in H. discriminate H. Qed.

Lemma reff656_not414 : ~ @Equation414 Fin5 reff656_inst.
Proof. unfold Equation414. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff656_inst, reff656_op in H. discriminate H. Qed.

Lemma reff656_not416 : ~ @Equation416 Fin5 reff656_inst.
Proof. unfold Equation416. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff656_inst, reff656_op in H. discriminate H. Qed.

Lemma reff656_not419 : ~ @Equation419 Fin5 reff656_inst.
Proof. unfold Equation419. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff656_inst, reff656_op in H. discriminate H. Qed.

Lemma reff656_not420 : ~ @Equation420 Fin5 reff656_inst.
Proof. unfold Equation420. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff656_inst, reff656_op in H. discriminate H. Qed.

Lemma reff656_not426 : ~ @Equation426 Fin5 reff656_inst.
Proof. unfold Equation426. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff656_inst, reff656_op in H. discriminate H. Qed.

Lemma reff656_not427 : ~ @Equation427 Fin5 reff656_inst.
Proof. unfold Equation427. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff656_inst, reff656_op in H. discriminate H. Qed.

Lemma reff656_not430 : ~ @Equation430 Fin5 reff656_inst.
Proof. unfold Equation430. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff656_inst, reff656_op in H. discriminate H. Qed.

Lemma reff656_not436 : ~ @Equation436 Fin5 reff656_inst.
Proof. unfold Equation436. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff656_inst, reff656_op in H. discriminate H. Qed.

Lemma reff656_not437 : ~ @Equation437 Fin5 reff656_inst.
Proof. unfold Equation437. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff656_inst, reff656_op in H. discriminate H. Qed.

Lemma reff656_not439 : ~ @Equation439 Fin5 reff656_inst.
Proof. unfold Equation439. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff656_inst, reff656_op in H. discriminate H. Qed.

Lemma reff656_not463 : ~ @Equation463 Fin5 reff656_inst.
Proof. unfold Equation463. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff656_inst, reff656_op in H. discriminate H. Qed.

Lemma reff656_not464 : ~ @Equation464 Fin5 reff656_inst.
Proof. unfold Equation464. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff656_inst, reff656_op in H. discriminate H. Qed.

Lemma reff656_not466 : ~ @Equation466 Fin5 reff656_inst.
Proof. unfold Equation466. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff656_inst, reff656_op in H. discriminate H. Qed.

Lemma reff656_not467 : ~ @Equation467 Fin5 reff656_inst.
Proof. unfold Equation467. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff656_inst, reff656_op in H. discriminate H. Qed.

Lemma reff656_not474 : ~ @Equation474 Fin5 reff656_inst.
Proof. unfold Equation474. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff656_inst, reff656_op in H. discriminate H. Qed.

Lemma reff656_not476 : ~ @Equation476 Fin5 reff656_inst.
Proof. unfold Equation476. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff656_inst, reff656_op in H. discriminate H. Qed.

Lemma reff656_not477 : ~ @Equation477 Fin5 reff656_inst.
Proof. unfold Equation477. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff656_inst, reff656_op in H. discriminate H. Qed.

Lemma reff656_not500 : ~ @Equation500 Fin5 reff656_inst.
Proof. unfold Equation500. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff656_inst, reff656_op in H. discriminate H. Qed.

Lemma reff656_not503 : ~ @Equation503 Fin5 reff656_inst.
Proof. unfold Equation503. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff656_inst, reff656_op in H. discriminate H. Qed.

Lemma reff656_not504 : ~ @Equation504 Fin5 reff656_inst.
Proof. unfold Equation504. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff656_inst, reff656_op in H. discriminate H. Qed.

Lemma reff656_not510 : ~ @Equation510 Fin5 reff656_inst.
Proof. unfold Equation510. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff656_inst, reff656_op in H. discriminate H. Qed.

Lemma reff656_not511 : ~ @Equation511 Fin5 reff656_inst.
Proof. unfold Equation511. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff656_inst, reff656_op in H. discriminate H. Qed.

Lemma reff656_not614 : ~ @Equation614 Fin5 reff656_inst.
Proof. unfold Equation614. intro H. specialize (H F5_1). unfold magma_op, reff656_inst, reff656_op in H. discriminate H. Qed.

Lemma reff656_not817 : ~ @Equation817 Fin5 reff656_inst.
Proof. unfold Equation817. intro H. specialize (H F5_1). unfold magma_op, reff656_inst, reff656_op in H. discriminate H. Qed.

Lemma reff656_not1020 : ~ @Equation1020 Fin5 reff656_inst.
Proof. unfold Equation1020. intro H. specialize (H F5_1). unfold magma_op, reff656_inst, reff656_op in H. discriminate H. Qed.

Lemma reff656_not1224 : ~ @Equation1224 Fin5 reff656_inst.
Proof. unfold Equation1224. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff656_inst, reff656_op in H. discriminate H. Qed.

Lemma reff656_not1225 : ~ @Equation1225 Fin5 reff656_inst.
Proof. unfold Equation1225. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff656_inst, reff656_op in H. discriminate H. Qed.

Lemma reff656_not1226 : ~ @Equation1226 Fin5 reff656_inst.
Proof. unfold Equation1226. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff656_inst, reff656_op in H. discriminate H. Qed.

Lemma reff656_not1228 : ~ @Equation1228 Fin5 reff656_inst.
Proof. unfold Equation1228. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff656_inst, reff656_op in H. discriminate H. Qed.

Lemma reff656_not1229 : ~ @Equation1229 Fin5 reff656_inst.
Proof. unfold Equation1229. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff656_inst, reff656_op in H. discriminate H. Qed.

Lemma reff656_not1231 : ~ @Equation1231 Fin5 reff656_inst.
Proof. unfold Equation1231. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff656_inst, reff656_op in H. discriminate H. Qed.

Lemma reff656_not1232 : ~ @Equation1232 Fin5 reff656_inst.
Proof. unfold Equation1232. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff656_inst, reff656_op in H. discriminate H. Qed.

Lemma reff656_not1238 : ~ @Equation1238 Fin5 reff656_inst.
Proof. unfold Equation1238. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff656_inst, reff656_op in H. discriminate H. Qed.

Lemma reff656_not1239 : ~ @Equation1239 Fin5 reff656_inst.
Proof. unfold Equation1239. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff656_inst, reff656_op in H. discriminate H. Qed.

Lemma reff656_not1241 : ~ @Equation1241 Fin5 reff656_inst.
Proof. unfold Equation1241. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff656_inst, reff656_op in H. discriminate H. Qed.

Lemma reff656_not1242 : ~ @Equation1242 Fin5 reff656_inst.
Proof. unfold Equation1242. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff656_inst, reff656_op in H. discriminate H. Qed.

Lemma reff656_not1248 : ~ @Equation1248 Fin5 reff656_inst.
Proof. unfold Equation1248. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff656_inst, reff656_op in H. discriminate H. Qed.

Lemma reff656_not1249 : ~ @Equation1249 Fin5 reff656_inst.
Proof. unfold Equation1249. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff656_inst, reff656_op in H. discriminate H. Qed.

Lemma reff656_not1251 : ~ @Equation1251 Fin5 reff656_inst.
Proof. unfold Equation1251. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff656_inst, reff656_op in H. discriminate H. Qed.

Lemma reff656_not1275 : ~ @Equation1275 Fin5 reff656_inst.
Proof. unfold Equation1275. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff656_inst, reff656_op in H. discriminate H. Qed.

Lemma reff656_not1279 : ~ @Equation1279 Fin5 reff656_inst.
Proof. unfold Equation1279. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff656_inst, reff656_op in H. discriminate H. Qed.

Lemma reff656_not1286 : ~ @Equation1286 Fin5 reff656_inst.
Proof. unfold Equation1286. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff656_inst, reff656_op in H. discriminate H. Qed.

Lemma reff656_not1288 : ~ @Equation1288 Fin5 reff656_inst.
Proof. unfold Equation1288. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff656_inst, reff656_op in H. discriminate H. Qed.

Lemma reff656_not1289 : ~ @Equation1289 Fin5 reff656_inst.
Proof. unfold Equation1289. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff656_inst, reff656_op in H. discriminate H. Qed.

Lemma reff656_not1312 : ~ @Equation1312 Fin5 reff656_inst.
Proof. unfold Equation1312. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff656_inst, reff656_op in H. discriminate H. Qed.

Lemma reff656_not1313 : ~ @Equation1313 Fin5 reff656_inst.
Proof. unfold Equation1313. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff656_inst, reff656_op in H. discriminate H. Qed.

Lemma reff656_not1315 : ~ @Equation1315 Fin5 reff656_inst.
Proof. unfold Equation1315. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff656_inst, reff656_op in H. discriminate H. Qed.

Lemma reff656_not1316 : ~ @Equation1316 Fin5 reff656_inst.
Proof. unfold Equation1316. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff656_inst, reff656_op in H. discriminate H. Qed.

Lemma reff656_not1322 : ~ @Equation1322 Fin5 reff656_inst.
Proof. unfold Equation1322. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff656_inst, reff656_op in H. discriminate H. Qed.

Lemma reff656_not1323 : ~ @Equation1323 Fin5 reff656_inst.
Proof. unfold Equation1323. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff656_inst, reff656_op in H. discriminate H. Qed.

Lemma reff656_not1325 : ~ @Equation1325 Fin5 reff656_inst.
Proof. unfold Equation1325. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff656_inst, reff656_op in H. discriminate H. Qed.

Lemma reff656_not1426 : ~ @Equation1426 Fin5 reff656_inst.
Proof. unfold Equation1426. intro H. specialize (H F5_1). unfold magma_op, reff656_inst, reff656_op in H. discriminate H. Qed.

Lemma reff656_not1629 : ~ @Equation1629 Fin5 reff656_inst.
Proof. unfold Equation1629. intro H. specialize (H F5_1). unfold magma_op, reff656_inst, reff656_op in H. discriminate H. Qed.

Lemma reff656_not1832 : ~ @Equation1832 Fin5 reff656_inst.
Proof. unfold Equation1832. intro H. specialize (H F5_1). unfold magma_op, reff656_inst, reff656_op in H. discriminate H. Qed.

Lemma reff656_not2035 : ~ @Equation2035 Fin5 reff656_inst.
Proof. unfold Equation2035. intro H. specialize (H F5_1). unfold magma_op, reff656_inst, reff656_op in H. discriminate H. Qed.

Lemma reff656_not2238 : ~ @Equation2238 Fin5 reff656_inst.
Proof. unfold Equation2238. intro H. specialize (H F5_1). unfold magma_op, reff656_inst, reff656_op in H. discriminate H. Qed.

Lemma reff656_not2441 : ~ @Equation2441 Fin5 reff656_inst.
Proof. unfold Equation2441. intro H. specialize (H F5_1). unfold magma_op, reff656_inst, reff656_op in H. discriminate H. Qed.

Lemma reff656_not2644 : ~ @Equation2644 Fin5 reff656_inst.
Proof. unfold Equation2644. intro H. specialize (H F5_1). unfold magma_op, reff656_inst, reff656_op in H. discriminate H. Qed.

Lemma reff656_not2847 : ~ @Equation2847 Fin5 reff656_inst.
Proof. unfold Equation2847. intro H. specialize (H F5_1). unfold magma_op, reff656_inst, reff656_op in H. discriminate H. Qed.

Lemma reff656_not3050 : ~ @Equation3050 Fin5 reff656_inst.
Proof. unfold Equation3050. intro H. specialize (H F5_1). unfold magma_op, reff656_inst, reff656_op in H. discriminate H. Qed.

Lemma reff656_not3253 : ~ @Equation3253 Fin5 reff656_inst.
Proof. unfold Equation3253. intro H. specialize (H F5_1). unfold magma_op, reff656_inst, reff656_op in H. discriminate H. Qed.

Lemma reff656_not3456 : ~ @Equation3456 Fin5 reff656_inst.
Proof. unfold Equation3456. intro H. specialize (H F5_1). unfold magma_op, reff656_inst, reff656_op in H. discriminate H. Qed.

Lemma reff656_not3659 : ~ @Equation3659 Fin5 reff656_inst.
Proof. unfold Equation3659. intro H. specialize (H F5_1). unfold magma_op, reff656_inst, reff656_op in H. discriminate H. Qed.

Lemma reff656_not3862 : ~ @Equation3862 Fin5 reff656_inst.
Proof. unfold Equation3862. intro H. specialize (H F5_1). unfold magma_op, reff656_inst, reff656_op in H. discriminate H. Qed.

Lemma reff656_not4065 : ~ @Equation4065 Fin5 reff656_inst.
Proof. unfold Equation4065. intro H. specialize (H F5_1). unfold magma_op, reff656_inst, reff656_op in H. discriminate H. Qed.

Lemma reff656_not4268 : ~ @Equation4268 Fin5 reff656_inst.
Proof. unfold Equation4268. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff656_inst, reff656_op in H. discriminate H. Qed.

Lemma reff656_not4269 : ~ @Equation4269 Fin5 reff656_inst.
Proof. unfold Equation4269. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff656_inst, reff656_op in H. discriminate H. Qed.

Lemma reff656_not4270 : ~ @Equation4270 Fin5 reff656_inst.
Proof. unfold Equation4270. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff656_inst, reff656_op in H. discriminate H. Qed.

Lemma reff656_not4272 : ~ @Equation4272 Fin5 reff656_inst.
Proof. unfold Equation4272. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff656_inst, reff656_op in H. discriminate H. Qed.

Lemma reff656_not4275 : ~ @Equation4275 Fin5 reff656_inst.
Proof. unfold Equation4275. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff656_inst, reff656_op in H. discriminate H. Qed.

Lemma reff656_not4276 : ~ @Equation4276 Fin5 reff656_inst.
Proof. unfold Equation4276. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff656_inst, reff656_op in H. discriminate H. Qed.

Lemma reff656_not4283 : ~ @Equation4283 Fin5 reff656_inst.
Proof. unfold Equation4283. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff656_inst, reff656_op in H. discriminate H. Qed.

Lemma reff656_not4284 : ~ @Equation4284 Fin5 reff656_inst.
Proof. unfold Equation4284. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff656_inst, reff656_op in H. discriminate H. Qed.

Lemma reff656_not4290 : ~ @Equation4290 Fin5 reff656_inst.
Proof. unfold Equation4290. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff656_inst, reff656_op in H. discriminate H. Qed.

Lemma reff656_not4291 : ~ @Equation4291 Fin5 reff656_inst.
Proof. unfold Equation4291. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff656_inst, reff656_op in H. discriminate H. Qed.

Lemma reff656_not4314 : ~ @Equation4314 Fin5 reff656_inst.
Proof. unfold Equation4314. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff656_inst, reff656_op in H. discriminate H. Qed.

Lemma reff656_not4320 : ~ @Equation4320 Fin5 reff656_inst.
Proof. unfold Equation4320. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff656_inst, reff656_op in H. discriminate H. Qed.

Lemma reff656_not4321 : ~ @Equation4321 Fin5 reff656_inst.
Proof. unfold Equation4321. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff656_inst, reff656_op in H. discriminate H. Qed.

Lemma reff656_not4343 : ~ @Equation4343 Fin5 reff656_inst.
Proof. unfold Equation4343. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff656_inst, reff656_op in H. discriminate H. Qed.

Lemma reff656_not4380 : ~ @Equation4380 Fin5 reff656_inst.
Proof. unfold Equation4380. intro H. specialize (H F5_1). unfold magma_op, reff656_inst, reff656_op in H. discriminate H. Qed.

Lemma reff656_not4583 : ~ @Equation4583 Fin5 reff656_inst.
Proof. unfold Equation4583. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff656_inst, reff656_op in H. discriminate H. Qed.

Lemma reff656_not4584 : ~ @Equation4584 Fin5 reff656_inst.
Proof. unfold Equation4584. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff656_inst, reff656_op in H. discriminate H. Qed.

Lemma reff656_not4585 : ~ @Equation4585 Fin5 reff656_inst.
Proof. unfold Equation4585. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff656_inst, reff656_op in H. discriminate H. Qed.

Lemma reff656_not4587 : ~ @Equation4587 Fin5 reff656_inst.
Proof. unfold Equation4587. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff656_inst, reff656_op in H. discriminate H. Qed.

Lemma reff656_not4588 : ~ @Equation4588 Fin5 reff656_inst.
Proof. unfold Equation4588. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff656_inst, reff656_op in H. discriminate H. Qed.

Lemma reff656_not4590 : ~ @Equation4590 Fin5 reff656_inst.
Proof. unfold Equation4590. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff656_inst, reff656_op in H. discriminate H. Qed.

Lemma reff656_not4591 : ~ @Equation4591 Fin5 reff656_inst.
Proof. unfold Equation4591. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff656_inst, reff656_op in H. discriminate H. Qed.

Lemma reff656_not4599 : ~ @Equation4599 Fin5 reff656_inst.
Proof. unfold Equation4599. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff656_inst, reff656_op in H. discriminate H. Qed.

Lemma reff656_not4605 : ~ @Equation4605 Fin5 reff656_inst.
Proof. unfold Equation4605. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff656_inst, reff656_op in H. discriminate H. Qed.

Lemma reff656_not4606 : ~ @Equation4606 Fin5 reff656_inst.
Proof. unfold Equation4606. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff656_inst, reff656_op in H. discriminate H. Qed.

Lemma reff656_not4608 : ~ @Equation4608 Fin5 reff656_inst.
Proof. unfold Equation4608. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff656_inst, reff656_op in H. discriminate H. Qed.

Lemma reff656_not4629 : ~ @Equation4629 Fin5 reff656_inst.
Proof. unfold Equation4629. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff656_inst, reff656_op in H. discriminate H. Qed.

Lemma reff656_not4635 : ~ @Equation4635 Fin5 reff656_inst.
Proof. unfold Equation4635. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff656_inst, reff656_op in H. discriminate H. Qed.

Lemma reff656_not4636 : ~ @Equation4636 Fin5 reff656_inst.
Proof. unfold Equation4636. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff656_inst, reff656_op in H. discriminate H. Qed.

(** ---- reff66 (Fin2) ---- *)

Definition reff66_op (x y : Fin2) : Fin2 :=
  match x, y with
  | F2_0, F2_0 => F2_0 | F2_0, F2_1 => F2_0
  | F2_1, F2_0 => F2_0 | F2_1, F2_1 => F2_0
  end.

#[local] Instance reff66_inst : Magma Fin2 := {| magma_op := reff66_op |}.

Lemma reff66_sat41 : @Equation41 Fin2 reff66_inst.
Proof. unfold Equation41, magma_op, reff66_inst, reff66_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff66_not47 : ~ @Equation47 Fin2 reff66_inst.
Proof. unfold Equation47. intro H. specialize (H F2_1). unfold magma_op, reff66_inst, reff66_op in H. discriminate H. Qed.

Lemma reff66_not99 : ~ @Equation99 Fin2 reff66_inst.
Proof. unfold Equation99. intro H. specialize (H F2_1). unfold magma_op, reff66_inst, reff66_op in H. discriminate H. Qed.

Lemma reff66_not151 : ~ @Equation151 Fin2 reff66_inst.
Proof. unfold Equation151. intro H. specialize (H F2_1). unfold magma_op, reff66_inst, reff66_op in H. discriminate H. Qed.

Lemma reff66_not203 : ~ @Equation203 Fin2 reff66_inst.
Proof. unfold Equation203. intro H. specialize (H F2_1). unfold magma_op, reff66_inst, reff66_op in H. discriminate H. Qed.

Lemma reff66_not255 : ~ @Equation255 Fin2 reff66_inst.
Proof. unfold Equation255. intro H. specialize (H F2_1). unfold magma_op, reff66_inst, reff66_op in H. discriminate H. Qed.

Lemma reff66_not411 : ~ @Equation411 Fin2 reff66_inst.
Proof. unfold Equation411. intro H. specialize (H F2_1). unfold magma_op, reff66_inst, reff66_op in H. discriminate H. Qed.

Lemma reff66_not614 : ~ @Equation614 Fin2 reff66_inst.
Proof. unfold Equation614. intro H. specialize (H F2_1). unfold magma_op, reff66_inst, reff66_op in H. discriminate H. Qed.

Lemma reff66_not817 : ~ @Equation817 Fin2 reff66_inst.
Proof. unfold Equation817. intro H. specialize (H F2_1). unfold magma_op, reff66_inst, reff66_op in H. discriminate H. Qed.

Lemma reff66_not1020 : ~ @Equation1020 Fin2 reff66_inst.
Proof. unfold Equation1020. intro H. specialize (H F2_1). unfold magma_op, reff66_inst, reff66_op in H. discriminate H. Qed.

Lemma reff66_not1223 : ~ @Equation1223 Fin2 reff66_inst.
Proof. unfold Equation1223. intro H. specialize (H F2_1). unfold magma_op, reff66_inst, reff66_op in H. discriminate H. Qed.

Lemma reff66_not1426 : ~ @Equation1426 Fin2 reff66_inst.
Proof. unfold Equation1426. intro H. specialize (H F2_1). unfold magma_op, reff66_inst, reff66_op in H. discriminate H. Qed.

Lemma reff66_not1629 : ~ @Equation1629 Fin2 reff66_inst.
Proof. unfold Equation1629. intro H. specialize (H F2_1). unfold magma_op, reff66_inst, reff66_op in H. discriminate H. Qed.

Lemma reff66_not1832 : ~ @Equation1832 Fin2 reff66_inst.
Proof. unfold Equation1832. intro H. specialize (H F2_1). unfold magma_op, reff66_inst, reff66_op in H. discriminate H. Qed.

Lemma reff66_not2035 : ~ @Equation2035 Fin2 reff66_inst.
Proof. unfold Equation2035. intro H. specialize (H F2_1). unfold magma_op, reff66_inst, reff66_op in H. discriminate H. Qed.

Lemma reff66_not2238 : ~ @Equation2238 Fin2 reff66_inst.
Proof. unfold Equation2238. intro H. specialize (H F2_1). unfold magma_op, reff66_inst, reff66_op in H. discriminate H. Qed.

Lemma reff66_not2441 : ~ @Equation2441 Fin2 reff66_inst.
Proof. unfold Equation2441. intro H. specialize (H F2_1). unfold magma_op, reff66_inst, reff66_op in H. discriminate H. Qed.

Lemma reff66_not2644 : ~ @Equation2644 Fin2 reff66_inst.
Proof. unfold Equation2644. intro H. specialize (H F2_1). unfold magma_op, reff66_inst, reff66_op in H. discriminate H. Qed.

Lemma reff66_not2847 : ~ @Equation2847 Fin2 reff66_inst.
Proof. unfold Equation2847. intro H. specialize (H F2_1). unfold magma_op, reff66_inst, reff66_op in H. discriminate H. Qed.

Lemma reff66_not3050 : ~ @Equation3050 Fin2 reff66_inst.
Proof. unfold Equation3050. intro H. specialize (H F2_1). unfold magma_op, reff66_inst, reff66_op in H. discriminate H. Qed.

(** ---- reff664 (Fin5) ---- *)

Definition reff664_op (x y : Fin5) : Fin5 :=
  match x, y with
  | F5_0, F5_0 => F5_0 | F5_0, F5_1 => F5_4 | F5_0, F5_2 => F5_3 | F5_0, F5_3 => F5_2 | F5_0, F5_4 => F5_1
  | F5_1, F5_0 => F5_3 | F5_1, F5_1 => F5_2 | F5_1, F5_2 => F5_1 | F5_1, F5_3 => F5_0 | F5_1, F5_4 => F5_4
  | F5_2, F5_0 => F5_1 | F5_2, F5_1 => F5_0 | F5_2, F5_2 => F5_4 | F5_2, F5_3 => F5_3 | F5_2, F5_4 => F5_2
  | F5_3, F5_0 => F5_4 | F5_3, F5_1 => F5_3 | F5_3, F5_2 => F5_2 | F5_3, F5_3 => F5_1 | F5_3, F5_4 => F5_0
  | F5_4, F5_0 => F5_2 | F5_4, F5_1 => F5_1 | F5_4, F5_2 => F5_0 | F5_4, F5_3 => F5_4 | F5_4, F5_4 => F5_3
  end.

#[local] Instance reff664_inst : Magma Fin5 := {| magma_op := reff664_op |}.

Lemma reff664_sat430 : @Equation430 Fin5 reff664_inst.
Proof. unfold Equation430, magma_op, reff664_inst, reff664_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff664_sat1098 : @Equation1098 Fin5 reff664_inst.
Proof. unfold Equation1098, magma_op, reff664_inst, reff664_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff664_sat1110 : @Equation1110 Fin5 reff664_inst.
Proof. unfold Equation1110, magma_op, reff664_inst, reff664_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff664_sat1638 : @Equation1638 Fin5 reff664_inst.
Proof. unfold Equation1638, magma_op, reff664_inst, reff664_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff664_sat1764 : @Equation1764 Fin5 reff664_inst.
Proof. unfold Equation1764, magma_op, reff664_inst, reff664_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff664_sat1858 : @Equation1858 Fin5 reff664_inst.
Proof. unfold Equation1858, magma_op, reff664_inst, reff664_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff664_sat1913 : @Equation1913 Fin5 reff664_inst.
Proof. unfold Equation1913, magma_op, reff664_inst, reff664_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff664_sat2672 : @Equation2672 Fin5 reff664_inst.
Proof. unfold Equation2672, magma_op, reff664_inst, reff664_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff664_sat2722 : @Equation2722 Fin5 reff664_inst.
Proof. unfold Equation2722, magma_op, reff664_inst, reff664_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff664_sat2776 : @Equation2776 Fin5 reff664_inst.
Proof. unfold Equation2776, magma_op, reff664_inst, reff664_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff664_sat3149 : @Equation3149 Fin5 reff664_inst.
Proof. unfold Equation3149, magma_op, reff664_inst, reff664_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff664_sat3185 : @Equation3185 Fin5 reff664_inst.
Proof. unfold Equation3185, magma_op, reff664_inst, reff664_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff664_sat3272 : @Equation3272 Fin5 reff664_inst.
Proof. unfold Equation3272, magma_op, reff664_inst, reff664_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff664_sat3927 : @Equation3927 Fin5 reff664_inst.
Proof. unfold Equation3927, magma_op, reff664_inst, reff664_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff664_sat3973 : @Equation3973 Fin5 reff664_inst.
Proof. unfold Equation3973, magma_op, reff664_inst, reff664_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff664_sat4343 : @Equation4343 Fin5 reff664_inst.
Proof. unfold Equation4343, magma_op, reff664_inst, reff664_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff664_sat4591 : @Equation4591 Fin5 reff664_inst.
Proof. unfold Equation4591, magma_op, reff664_inst, reff664_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff664_not47 : ~ @Equation47 Fin5 reff664_inst.
Proof. unfold Equation47. intro H. specialize (H F5_1). unfold magma_op, reff664_inst, reff664_op in H. discriminate H. Qed.

Lemma reff664_not99 : ~ @Equation99 Fin5 reff664_inst.
Proof. unfold Equation99. intro H. specialize (H F5_1). unfold magma_op, reff664_inst, reff664_op in H. discriminate H. Qed.

Lemma reff664_not151 : ~ @Equation151 Fin5 reff664_inst.
Proof. unfold Equation151. intro H. specialize (H F5_1). unfold magma_op, reff664_inst, reff664_op in H. discriminate H. Qed.

Lemma reff664_not203 : ~ @Equation203 Fin5 reff664_inst.
Proof. unfold Equation203. intro H. specialize (H F5_1). unfold magma_op, reff664_inst, reff664_op in H. discriminate H. Qed.

Lemma reff664_not255 : ~ @Equation255 Fin5 reff664_inst.
Proof. unfold Equation255. intro H. specialize (H F5_1). unfold magma_op, reff664_inst, reff664_op in H. discriminate H. Qed.

Lemma reff664_not307 : ~ @Equation307 Fin5 reff664_inst.
Proof. unfold Equation307. intro H. specialize (H F5_1). unfold magma_op, reff664_inst, reff664_op in H. discriminate H. Qed.

Lemma reff664_not412 : ~ @Equation412 Fin5 reff664_inst.
Proof. unfold Equation412. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff664_inst, reff664_op in H. discriminate H. Qed.

Lemma reff664_not413 : ~ @Equation413 Fin5 reff664_inst.
Proof. unfold Equation413. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff664_inst, reff664_op in H. discriminate H. Qed.

Lemma reff664_not414 : ~ @Equation414 Fin5 reff664_inst.
Proof. unfold Equation414. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff664_inst, reff664_op in H. discriminate H. Qed.

Lemma reff664_not416 : ~ @Equation416 Fin5 reff664_inst.
Proof. unfold Equation416. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff664_inst, reff664_op in H. discriminate H. Qed.

Lemma reff664_not417 : ~ @Equation417 Fin5 reff664_inst.
Proof. unfold Equation417. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff664_inst, reff664_op in H. discriminate H. Qed.

Lemma reff664_not420 : ~ @Equation420 Fin5 reff664_inst.
Proof. unfold Equation420. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff664_inst, reff664_op in H. discriminate H. Qed.

Lemma reff664_not426 : ~ @Equation426 Fin5 reff664_inst.
Proof. unfold Equation426. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff664_inst, reff664_op in H. discriminate H. Qed.

Lemma reff664_not427 : ~ @Equation427 Fin5 reff664_inst.
Proof. unfold Equation427. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff664_inst, reff664_op in H. discriminate H. Qed.

Lemma reff664_not429 : ~ @Equation429 Fin5 reff664_inst.
Proof. unfold Equation429. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff664_inst, reff664_op in H. discriminate H. Qed.

Lemma reff664_not437 : ~ @Equation437 Fin5 reff664_inst.
Proof. unfold Equation437. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff664_inst, reff664_op in H. discriminate H. Qed.

Lemma reff664_not439 : ~ @Equation439 Fin5 reff664_inst.
Proof. unfold Equation439. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff664_inst, reff664_op in H. discriminate H. Qed.

Lemma reff664_not440 : ~ @Equation440 Fin5 reff664_inst.
Proof. unfold Equation440. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff664_inst, reff664_op in H. discriminate H. Qed.

Lemma reff664_not463 : ~ @Equation463 Fin5 reff664_inst.
Proof. unfold Equation463. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff664_inst, reff664_op in H. discriminate H. Qed.

Lemma reff664_not464 : ~ @Equation464 Fin5 reff664_inst.
Proof. unfold Equation464. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff664_inst, reff664_op in H. discriminate H. Qed.

Lemma reff664_not467 : ~ @Equation467 Fin5 reff664_inst.
Proof. unfold Equation467. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff664_inst, reff664_op in H. discriminate H. Qed.

Lemma reff664_not473 : ~ @Equation473 Fin5 reff664_inst.
Proof. unfold Equation473. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff664_inst, reff664_op in H. discriminate H. Qed.

Lemma reff664_not474 : ~ @Equation474 Fin5 reff664_inst.
Proof. unfold Equation474. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff664_inst, reff664_op in H. discriminate H. Qed.

Lemma reff664_not476 : ~ @Equation476 Fin5 reff664_inst.
Proof. unfold Equation476. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff664_inst, reff664_op in H. discriminate H. Qed.

Lemma reff664_not477 : ~ @Equation477 Fin5 reff664_inst.
Proof. unfold Equation477. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff664_inst, reff664_op in H. discriminate H. Qed.

Lemma reff664_not501 : ~ @Equation501 Fin5 reff664_inst.
Proof. unfold Equation501. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff664_inst, reff664_op in H. discriminate H. Qed.

Lemma reff664_not503 : ~ @Equation503 Fin5 reff664_inst.
Proof. unfold Equation503. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff664_inst, reff664_op in H. discriminate H. Qed.

Lemma reff664_not504 : ~ @Equation504 Fin5 reff664_inst.
Proof. unfold Equation504. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff664_inst, reff664_op in H. discriminate H. Qed.

Lemma reff664_not510 : ~ @Equation510 Fin5 reff664_inst.
Proof. unfold Equation510. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff664_inst, reff664_op in H. discriminate H. Qed.

Lemma reff664_not511 : ~ @Equation511 Fin5 reff664_inst.
Proof. unfold Equation511. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff664_inst, reff664_op in H. discriminate H. Qed.

Lemma reff664_not614 : ~ @Equation614 Fin5 reff664_inst.
Proof. unfold Equation614. intro H. specialize (H F5_1). unfold magma_op, reff664_inst, reff664_op in H. discriminate H. Qed.

Lemma reff664_not817 : ~ @Equation817 Fin5 reff664_inst.
Proof. unfold Equation817. intro H. specialize (H F5_1). unfold magma_op, reff664_inst, reff664_op in H. discriminate H. Qed.

Lemma reff664_not1021 : ~ @Equation1021 Fin5 reff664_inst.
Proof. unfold Equation1021. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff664_inst, reff664_op in H. discriminate H. Qed.

Lemma reff664_not1022 : ~ @Equation1022 Fin5 reff664_inst.
Proof. unfold Equation1022. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff664_inst, reff664_op in H. discriminate H. Qed.

Lemma reff664_not1023 : ~ @Equation1023 Fin5 reff664_inst.
Proof. unfold Equation1023. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff664_inst, reff664_op in H. discriminate H. Qed.

Lemma reff664_not1025 : ~ @Equation1025 Fin5 reff664_inst.
Proof. unfold Equation1025. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff664_inst, reff664_op in H. discriminate H. Qed.

Lemma reff664_not1028 : ~ @Equation1028 Fin5 reff664_inst.
Proof. unfold Equation1028. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff664_inst, reff664_op in H. discriminate H. Qed.

Lemma reff664_not1029 : ~ @Equation1029 Fin5 reff664_inst.
Proof. unfold Equation1029. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff664_inst, reff664_op in H. discriminate H. Qed.

Lemma reff664_not1035 : ~ @Equation1035 Fin5 reff664_inst.
Proof. unfold Equation1035. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff664_inst, reff664_op in H. discriminate H. Qed.

Lemma reff664_not1036 : ~ @Equation1036 Fin5 reff664_inst.
Proof. unfold Equation1036. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff664_inst, reff664_op in H. discriminate H. Qed.

Lemma reff664_not1038 : ~ @Equation1038 Fin5 reff664_inst.
Proof. unfold Equation1038. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff664_inst, reff664_op in H. discriminate H. Qed.

Lemma reff664_not1039 : ~ @Equation1039 Fin5 reff664_inst.
Proof. unfold Equation1039. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff664_inst, reff664_op in H. discriminate H. Qed.

Lemma reff664_not1046 : ~ @Equation1046 Fin5 reff664_inst.
Proof. unfold Equation1046. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff664_inst, reff664_op in H. discriminate H. Qed.

Lemma reff664_not1048 : ~ @Equation1048 Fin5 reff664_inst.
Proof. unfold Equation1048. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff664_inst, reff664_op in H. discriminate H. Qed.

Lemma reff664_not1049 : ~ @Equation1049 Fin5 reff664_inst.
Proof. unfold Equation1049. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff664_inst, reff664_op in H. discriminate H. Qed.

Lemma reff664_not1072 : ~ @Equation1072 Fin5 reff664_inst.
Proof. unfold Equation1072. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff664_inst, reff664_op in H. discriminate H. Qed.

Lemma reff664_not1073 : ~ @Equation1073 Fin5 reff664_inst.
Proof. unfold Equation1073. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff664_inst, reff664_op in H. discriminate H. Qed.

Lemma reff664_not1076 : ~ @Equation1076 Fin5 reff664_inst.
Proof. unfold Equation1076. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff664_inst, reff664_op in H. discriminate H. Qed.

Lemma reff664_not1082 : ~ @Equation1082 Fin5 reff664_inst.
Proof. unfold Equation1082. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff664_inst, reff664_op in H. discriminate H. Qed.

Lemma reff664_not1083 : ~ @Equation1083 Fin5 reff664_inst.
Proof. unfold Equation1083. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff664_inst, reff664_op in H. discriminate H. Qed.

Lemma reff664_not1085 : ~ @Equation1085 Fin5 reff664_inst.
Proof. unfold Equation1085. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff664_inst, reff664_op in H. discriminate H. Qed.

Lemma reff664_not1109 : ~ @Equation1109 Fin5 reff664_inst.
Proof. unfold Equation1109. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff664_inst, reff664_op in H. discriminate H. Qed.

Lemma reff664_not1112 : ~ @Equation1112 Fin5 reff664_inst.
Proof. unfold Equation1112. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff664_inst, reff664_op in H. discriminate H. Qed.

Lemma reff664_not1113 : ~ @Equation1113 Fin5 reff664_inst.
Proof. unfold Equation1113. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff664_inst, reff664_op in H. discriminate H. Qed.

Lemma reff664_not1119 : ~ @Equation1119 Fin5 reff664_inst.
Proof. unfold Equation1119. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff664_inst, reff664_op in H. discriminate H. Qed.

Lemma reff664_not1120 : ~ @Equation1120 Fin5 reff664_inst.
Proof. unfold Equation1120. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff664_inst, reff664_op in H. discriminate H. Qed.

Lemma reff664_not1223 : ~ @Equation1223 Fin5 reff664_inst.
Proof. unfold Equation1223. intro H. specialize (H F5_1). unfold magma_op, reff664_inst, reff664_op in H. discriminate H. Qed.

Lemma reff664_not1426 : ~ @Equation1426 Fin5 reff664_inst.
Proof. unfold Equation1426. intro H. specialize (H F5_1). unfold magma_op, reff664_inst, reff664_op in H. discriminate H. Qed.

Lemma reff664_not1630 : ~ @Equation1630 Fin5 reff664_inst.
Proof. unfold Equation1630. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff664_inst, reff664_op in H. discriminate H. Qed.

Lemma reff664_not1631 : ~ @Equation1631 Fin5 reff664_inst.
Proof. unfold Equation1631. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff664_inst, reff664_op in H. discriminate H. Qed.

Lemma reff664_not1632 : ~ @Equation1632 Fin5 reff664_inst.
Proof. unfold Equation1632. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff664_inst, reff664_op in H. discriminate H. Qed.

Lemma reff664_not1634 : ~ @Equation1634 Fin5 reff664_inst.
Proof. unfold Equation1634. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff664_inst, reff664_op in H. discriminate H. Qed.

Lemma reff664_not1635 : ~ @Equation1635 Fin5 reff664_inst.
Proof. unfold Equation1635. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff664_inst, reff664_op in H. discriminate H. Qed.

Lemma reff664_not1637 : ~ @Equation1637 Fin5 reff664_inst.
Proof. unfold Equation1637. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff664_inst, reff664_op in H. discriminate H. Qed.

Lemma reff664_not1644 : ~ @Equation1644 Fin5 reff664_inst.
Proof. unfold Equation1644. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff664_inst, reff664_op in H. discriminate H. Qed.

Lemma reff664_not1645 : ~ @Equation1645 Fin5 reff664_inst.
Proof. unfold Equation1645. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff664_inst, reff664_op in H. discriminate H. Qed.

Lemma reff664_not1648 : ~ @Equation1648 Fin5 reff664_inst.
Proof. unfold Equation1648. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff664_inst, reff664_op in H. discriminate H. Qed.

Lemma reff664_not1654 : ~ @Equation1654 Fin5 reff664_inst.
Proof. unfold Equation1654. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff664_inst, reff664_op in H. discriminate H. Qed.

Lemma reff664_not1655 : ~ @Equation1655 Fin5 reff664_inst.
Proof. unfold Equation1655. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff664_inst, reff664_op in H. discriminate H. Qed.

Lemma reff664_not1657 : ~ @Equation1657 Fin5 reff664_inst.
Proof. unfold Equation1657. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff664_inst, reff664_op in H. discriminate H. Qed.

Lemma reff664_not1658 : ~ @Equation1658 Fin5 reff664_inst.
Proof. unfold Equation1658. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff664_inst, reff664_op in H. discriminate H. Qed.

Lemma reff664_not1681 : ~ @Equation1681 Fin5 reff664_inst.
Proof. unfold Equation1681. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff664_inst, reff664_op in H. discriminate H. Qed.

Lemma reff664_not1684 : ~ @Equation1684 Fin5 reff664_inst.
Proof. unfold Equation1684. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff664_inst, reff664_op in H. discriminate H. Qed.

Lemma reff664_not1685 : ~ @Equation1685 Fin5 reff664_inst.
Proof. unfold Equation1685. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff664_inst, reff664_op in H. discriminate H. Qed.

Lemma reff664_not1692 : ~ @Equation1692 Fin5 reff664_inst.
Proof. unfold Equation1692. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff664_inst, reff664_op in H. discriminate H. Qed.

Lemma reff664_not1694 : ~ @Equation1694 Fin5 reff664_inst.
Proof. unfold Equation1694. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff664_inst, reff664_op in H. discriminate H. Qed.

Lemma reff664_not1695 : ~ @Equation1695 Fin5 reff664_inst.
Proof. unfold Equation1695. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff664_inst, reff664_op in H. discriminate H. Qed.

Lemma reff664_not1718 : ~ @Equation1718 Fin5 reff664_inst.
Proof. unfold Equation1718. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff664_inst, reff664_op in H. discriminate H. Qed.

Lemma reff664_not1719 : ~ @Equation1719 Fin5 reff664_inst.
Proof. unfold Equation1719. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff664_inst, reff664_op in H. discriminate H. Qed.

Lemma reff664_not1721 : ~ @Equation1721 Fin5 reff664_inst.
Proof. unfold Equation1721. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff664_inst, reff664_op in H. discriminate H. Qed.

Lemma reff664_not1728 : ~ @Equation1728 Fin5 reff664_inst.
Proof. unfold Equation1728. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff664_inst, reff664_op in H. discriminate H. Qed.

Lemma reff664_not1729 : ~ @Equation1729 Fin5 reff664_inst.
Proof. unfold Equation1729. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff664_inst, reff664_op in H. discriminate H. Qed.

Lemma reff664_not1833 : ~ @Equation1833 Fin5 reff664_inst.
Proof. unfold Equation1833. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff664_inst, reff664_op in H. discriminate H. Qed.

Lemma reff664_not1834 : ~ @Equation1834 Fin5 reff664_inst.
Proof. unfold Equation1834. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff664_inst, reff664_op in H. discriminate H. Qed.

Lemma reff664_not1835 : ~ @Equation1835 Fin5 reff664_inst.
Proof. unfold Equation1835. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff664_inst, reff664_op in H. discriminate H. Qed.

Lemma reff664_not1837 : ~ @Equation1837 Fin5 reff664_inst.
Proof. unfold Equation1837. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff664_inst, reff664_op in H. discriminate H. Qed.

Lemma reff664_not1838 : ~ @Equation1838 Fin5 reff664_inst.
Proof. unfold Equation1838. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff664_inst, reff664_op in H. discriminate H. Qed.

Lemma reff664_not1841 : ~ @Equation1841 Fin5 reff664_inst.
Proof. unfold Equation1841. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff664_inst, reff664_op in H. discriminate H. Qed.

Lemma reff664_not1847 : ~ @Equation1847 Fin5 reff664_inst.
Proof. unfold Equation1847. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff664_inst, reff664_op in H. discriminate H. Qed.

Lemma reff664_not1848 : ~ @Equation1848 Fin5 reff664_inst.
Proof. unfold Equation1848. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff664_inst, reff664_op in H. discriminate H. Qed.

Lemma reff664_not1850 : ~ @Equation1850 Fin5 reff664_inst.
Proof. unfold Equation1850. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff664_inst, reff664_op in H. discriminate H. Qed.

Lemma reff664_not1851 : ~ @Equation1851 Fin5 reff664_inst.
Proof. unfold Equation1851. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff664_inst, reff664_op in H. discriminate H. Qed.

Lemma reff664_not1857 : ~ @Equation1857 Fin5 reff664_inst.
Proof. unfold Equation1857. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff664_inst, reff664_op in H. discriminate H. Qed.

Lemma reff664_not1860 : ~ @Equation1860 Fin5 reff664_inst.
Proof. unfold Equation1860. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff664_inst, reff664_op in H. discriminate H. Qed.

Lemma reff664_not1861 : ~ @Equation1861 Fin5 reff664_inst.
Proof. unfold Equation1861. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff664_inst, reff664_op in H. discriminate H. Qed.

Lemma reff664_not1884 : ~ @Equation1884 Fin5 reff664_inst.
Proof. unfold Equation1884. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff664_inst, reff664_op in H. discriminate H. Qed.

Lemma reff664_not1887 : ~ @Equation1887 Fin5 reff664_inst.
Proof. unfold Equation1887. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff664_inst, reff664_op in H. discriminate H. Qed.

Lemma reff664_not1888 : ~ @Equation1888 Fin5 reff664_inst.
Proof. unfold Equation1888. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff664_inst, reff664_op in H. discriminate H. Qed.

Lemma reff664_not1894 : ~ @Equation1894 Fin5 reff664_inst.
Proof. unfold Equation1894. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff664_inst, reff664_op in H. discriminate H. Qed.

Lemma reff664_not1895 : ~ @Equation1895 Fin5 reff664_inst.
Proof. unfold Equation1895. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff664_inst, reff664_op in H. discriminate H. Qed.

Lemma reff664_not1897 : ~ @Equation1897 Fin5 reff664_inst.
Proof. unfold Equation1897. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff664_inst, reff664_op in H. discriminate H. Qed.

Lemma reff664_not1922 : ~ @Equation1922 Fin5 reff664_inst.
Proof. unfold Equation1922. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff664_inst, reff664_op in H. discriminate H. Qed.

Lemma reff664_not1924 : ~ @Equation1924 Fin5 reff664_inst.
Proof. unfold Equation1924. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff664_inst, reff664_op in H. discriminate H. Qed.

Lemma reff664_not1925 : ~ @Equation1925 Fin5 reff664_inst.
Proof. unfold Equation1925. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff664_inst, reff664_op in H. discriminate H. Qed.

Lemma reff664_not1931 : ~ @Equation1931 Fin5 reff664_inst.
Proof. unfold Equation1931. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff664_inst, reff664_op in H. discriminate H. Qed.

Lemma reff664_not1932 : ~ @Equation1932 Fin5 reff664_inst.
Proof. unfold Equation1932. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff664_inst, reff664_op in H. discriminate H. Qed.

Lemma reff664_not2035 : ~ @Equation2035 Fin5 reff664_inst.
Proof. unfold Equation2035. intro H. specialize (H F5_1). unfold magma_op, reff664_inst, reff664_op in H. discriminate H. Qed.

Lemma reff664_not2238 : ~ @Equation2238 Fin5 reff664_inst.
Proof. unfold Equation2238. intro H. specialize (H F5_1). unfold magma_op, reff664_inst, reff664_op in H. discriminate H. Qed.

Lemma reff664_not2441 : ~ @Equation2441 Fin5 reff664_inst.
Proof. unfold Equation2441. intro H. specialize (H F5_1). unfold magma_op, reff664_inst, reff664_op in H. discriminate H. Qed.

Lemma reff664_not2645 : ~ @Equation2645 Fin5 reff664_inst.
Proof. unfold Equation2645. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff664_inst, reff664_op in H. discriminate H. Qed.

Lemma reff664_not2646 : ~ @Equation2646 Fin5 reff664_inst.
Proof. unfold Equation2646. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff664_inst, reff664_op in H. discriminate H. Qed.

Lemma reff664_not2647 : ~ @Equation2647 Fin5 reff664_inst.
Proof. unfold Equation2647. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff664_inst, reff664_op in H. discriminate H. Qed.

Lemma reff664_not2649 : ~ @Equation2649 Fin5 reff664_inst.
Proof. unfold Equation2649. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff664_inst, reff664_op in H. discriminate H. Qed.

Lemma reff664_not2652 : ~ @Equation2652 Fin5 reff664_inst.
Proof. unfold Equation2652. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff664_inst, reff664_op in H. discriminate H. Qed.

Lemma reff664_not2653 : ~ @Equation2653 Fin5 reff664_inst.
Proof. unfold Equation2653. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff664_inst, reff664_op in H. discriminate H. Qed.

Lemma reff664_not2659 : ~ @Equation2659 Fin5 reff664_inst.
Proof. unfold Equation2659. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff664_inst, reff664_op in H. discriminate H. Qed.

Lemma reff664_not2662 : ~ @Equation2662 Fin5 reff664_inst.
Proof. unfold Equation2662. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff664_inst, reff664_op in H. discriminate H. Qed.

Lemma reff664_not2663 : ~ @Equation2663 Fin5 reff664_inst.
Proof. unfold Equation2663. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff664_inst, reff664_op in H. discriminate H. Qed.

Lemma reff664_not2669 : ~ @Equation2669 Fin5 reff664_inst.
Proof. unfold Equation2669. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff664_inst, reff664_op in H. discriminate H. Qed.

Lemma reff664_not2670 : ~ @Equation2670 Fin5 reff664_inst.
Proof. unfold Equation2670. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff664_inst, reff664_op in H. discriminate H. Qed.

Lemma reff664_not2673 : ~ @Equation2673 Fin5 reff664_inst.
Proof. unfold Equation2673. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff664_inst, reff664_op in H. discriminate H. Qed.

Lemma reff664_not2696 : ~ @Equation2696 Fin5 reff664_inst.
Proof. unfold Equation2696. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff664_inst, reff664_op in H. discriminate H. Qed.

Lemma reff664_not2697 : ~ @Equation2697 Fin5 reff664_inst.
Proof. unfold Equation2697. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff664_inst, reff664_op in H. discriminate H. Qed.

Lemma reff664_not2700 : ~ @Equation2700 Fin5 reff664_inst.
Proof. unfold Equation2700. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff664_inst, reff664_op in H. discriminate H. Qed.

Lemma reff664_not2706 : ~ @Equation2706 Fin5 reff664_inst.
Proof. unfold Equation2706. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff664_inst, reff664_op in H. discriminate H. Qed.

Lemma reff664_not2707 : ~ @Equation2707 Fin5 reff664_inst.
Proof. unfold Equation2707. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff664_inst, reff664_op in H. discriminate H. Qed.

Lemma reff664_not2709 : ~ @Equation2709 Fin5 reff664_inst.
Proof. unfold Equation2709. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff664_inst, reff664_op in H. discriminate H. Qed.

Lemma reff664_not2733 : ~ @Equation2733 Fin5 reff664_inst.
Proof. unfold Equation2733. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff664_inst, reff664_op in H. discriminate H. Qed.

Lemma reff664_not2734 : ~ @Equation2734 Fin5 reff664_inst.
Proof. unfold Equation2734. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff664_inst, reff664_op in H. discriminate H. Qed.

Lemma reff664_not2736 : ~ @Equation2736 Fin5 reff664_inst.
Proof. unfold Equation2736. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff664_inst, reff664_op in H. discriminate H. Qed.

Lemma reff664_not2743 : ~ @Equation2743 Fin5 reff664_inst.
Proof. unfold Equation2743. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff664_inst, reff664_op in H. discriminate H. Qed.

Lemma reff664_not2744 : ~ @Equation2744 Fin5 reff664_inst.
Proof. unfold Equation2744. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff664_inst, reff664_op in H. discriminate H. Qed.

Lemma reff664_not2746 : ~ @Equation2746 Fin5 reff664_inst.
Proof. unfold Equation2746. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff664_inst, reff664_op in H. discriminate H. Qed.

Lemma reff664_not2847 : ~ @Equation2847 Fin5 reff664_inst.
Proof. unfold Equation2847. intro H. specialize (H F5_1). unfold magma_op, reff664_inst, reff664_op in H. discriminate H. Qed.

Lemma reff664_not3051 : ~ @Equation3051 Fin5 reff664_inst.
Proof. unfold Equation3051. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff664_inst, reff664_op in H. discriminate H. Qed.

Lemma reff664_not3052 : ~ @Equation3052 Fin5 reff664_inst.
Proof. unfold Equation3052. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff664_inst, reff664_op in H. discriminate H. Qed.

Lemma reff664_not3053 : ~ @Equation3053 Fin5 reff664_inst.
Proof. unfold Equation3053. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff664_inst, reff664_op in H. discriminate H. Qed.

Lemma reff664_not3055 : ~ @Equation3055 Fin5 reff664_inst.
Proof. unfold Equation3055. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff664_inst, reff664_op in H. discriminate H. Qed.

Lemma reff664_not3058 : ~ @Equation3058 Fin5 reff664_inst.
Proof. unfold Equation3058. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff664_inst, reff664_op in H. discriminate H. Qed.

Lemma reff664_not3059 : ~ @Equation3059 Fin5 reff664_inst.
Proof. unfold Equation3059. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff664_inst, reff664_op in H. discriminate H. Qed.

Lemma reff664_not3065 : ~ @Equation3065 Fin5 reff664_inst.
Proof. unfold Equation3065. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff664_inst, reff664_op in H. discriminate H. Qed.

Lemma reff664_not3066 : ~ @Equation3066 Fin5 reff664_inst.
Proof. unfold Equation3066. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff664_inst, reff664_op in H. discriminate H. Qed.

Lemma reff664_not3069 : ~ @Equation3069 Fin5 reff664_inst.
Proof. unfold Equation3069. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff664_inst, reff664_op in H. discriminate H. Qed.

Lemma reff664_not3075 : ~ @Equation3075 Fin5 reff664_inst.
Proof. unfold Equation3075. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff664_inst, reff664_op in H. discriminate H. Qed.

Lemma reff664_not3076 : ~ @Equation3076 Fin5 reff664_inst.
Proof. unfold Equation3076. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff664_inst, reff664_op in H. discriminate H. Qed.

Lemma reff664_not3078 : ~ @Equation3078 Fin5 reff664_inst.
Proof. unfold Equation3078. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff664_inst, reff664_op in H. discriminate H. Qed.

Lemma reff664_not3102 : ~ @Equation3102 Fin5 reff664_inst.
Proof. unfold Equation3102. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff664_inst, reff664_op in H. discriminate H. Qed.

Lemma reff664_not3105 : ~ @Equation3105 Fin5 reff664_inst.
Proof. unfold Equation3105. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff664_inst, reff664_op in H. discriminate H. Qed.

Lemma reff664_not3106 : ~ @Equation3106 Fin5 reff664_inst.
Proof. unfold Equation3106. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff664_inst, reff664_op in H. discriminate H. Qed.

Lemma reff664_not3112 : ~ @Equation3112 Fin5 reff664_inst.
Proof. unfold Equation3112. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff664_inst, reff664_op in H. discriminate H. Qed.

Lemma reff664_not3113 : ~ @Equation3113 Fin5 reff664_inst.
Proof. unfold Equation3113. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff664_inst, reff664_op in H. discriminate H. Qed.

Lemma reff664_not3115 : ~ @Equation3115 Fin5 reff664_inst.
Proof. unfold Equation3115. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff664_inst, reff664_op in H. discriminate H. Qed.

Lemma reff664_not3116 : ~ @Equation3116 Fin5 reff664_inst.
Proof. unfold Equation3116. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff664_inst, reff664_op in H. discriminate H. Qed.

Lemma reff664_not3139 : ~ @Equation3139 Fin5 reff664_inst.
Proof. unfold Equation3139. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff664_inst, reff664_op in H. discriminate H. Qed.

Lemma reff664_not3140 : ~ @Equation3140 Fin5 reff664_inst.
Proof. unfold Equation3140. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff664_inst, reff664_op in H. discriminate H. Qed.

Lemma reff664_not3142 : ~ @Equation3142 Fin5 reff664_inst.
Proof. unfold Equation3142. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff664_inst, reff664_op in H. discriminate H. Qed.

Lemma reff664_not3150 : ~ @Equation3150 Fin5 reff664_inst.
Proof. unfold Equation3150. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff664_inst, reff664_op in H. discriminate H. Qed.

Lemma reff664_not3152 : ~ @Equation3152 Fin5 reff664_inst.
Proof. unfold Equation3152. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff664_inst, reff664_op in H. discriminate H. Qed.

Lemma reff664_not3254 : ~ @Equation3254 Fin5 reff664_inst.
Proof. unfold Equation3254. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff664_inst, reff664_op in H. discriminate H. Qed.

Lemma reff664_not3255 : ~ @Equation3255 Fin5 reff664_inst.
Proof. unfold Equation3255. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff664_inst, reff664_op in H. discriminate H. Qed.

Lemma reff664_not3256 : ~ @Equation3256 Fin5 reff664_inst.
Proof. unfold Equation3256. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff664_inst, reff664_op in H. discriminate H. Qed.

Lemma reff664_not3258 : ~ @Equation3258 Fin5 reff664_inst.
Proof. unfold Equation3258. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff664_inst, reff664_op in H. discriminate H. Qed.

Lemma reff664_not3259 : ~ @Equation3259 Fin5 reff664_inst.
Proof. unfold Equation3259. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff664_inst, reff664_op in H. discriminate H. Qed.

Lemma reff664_not3262 : ~ @Equation3262 Fin5 reff664_inst.
Proof. unfold Equation3262. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff664_inst, reff664_op in H. discriminate H. Qed.

Lemma reff664_not3268 : ~ @Equation3268 Fin5 reff664_inst.
Proof. unfold Equation3268. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff664_inst, reff664_op in H. discriminate H. Qed.

Lemma reff664_not3271 : ~ @Equation3271 Fin5 reff664_inst.
Proof. unfold Equation3271. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff664_inst, reff664_op in H. discriminate H. Qed.

Lemma reff664_not3279 : ~ @Equation3279 Fin5 reff664_inst.
Proof. unfold Equation3279. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff664_inst, reff664_op in H. discriminate H. Qed.

Lemma reff664_not3281 : ~ @Equation3281 Fin5 reff664_inst.
Proof. unfold Equation3281. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff664_inst, reff664_op in H. discriminate H. Qed.

Lemma reff664_not3308 : ~ @Equation3308 Fin5 reff664_inst.
Proof. unfold Equation3308. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff664_inst, reff664_op in H. discriminate H. Qed.

Lemma reff664_not3309 : ~ @Equation3309 Fin5 reff664_inst.
Proof. unfold Equation3309. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff664_inst, reff664_op in H. discriminate H. Qed.

Lemma reff664_not3315 : ~ @Equation3315 Fin5 reff664_inst.
Proof. unfold Equation3315. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff664_inst, reff664_op in H. discriminate H. Qed.

Lemma reff664_not3316 : ~ @Equation3316 Fin5 reff664_inst.
Proof. unfold Equation3316. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff664_inst, reff664_op in H. discriminate H. Qed.

Lemma reff664_not3318 : ~ @Equation3318 Fin5 reff664_inst.
Proof. unfold Equation3318. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff664_inst, reff664_op in H. discriminate H. Qed.

Lemma reff664_not3342 : ~ @Equation3342 Fin5 reff664_inst.
Proof. unfold Equation3342. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff664_inst, reff664_op in H. discriminate H. Qed.

Lemma reff664_not3343 : ~ @Equation3343 Fin5 reff664_inst.
Proof. unfold Equation3343. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff664_inst, reff664_op in H. discriminate H. Qed.

Lemma reff664_not3345 : ~ @Equation3345 Fin5 reff664_inst.
Proof. unfold Equation3345. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff664_inst, reff664_op in H. discriminate H. Qed.

Lemma reff664_not3346 : ~ @Equation3346 Fin5 reff664_inst.
Proof. unfold Equation3346. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff664_inst, reff664_op in H. discriminate H. Qed.

Lemma reff664_not3352 : ~ @Equation3352 Fin5 reff664_inst.
Proof. unfold Equation3352. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff664_inst, reff664_op in H. discriminate H. Qed.

Lemma reff664_not3456 : ~ @Equation3456 Fin5 reff664_inst.
Proof. unfold Equation3456. intro H. specialize (H F5_1). unfold magma_op, reff664_inst, reff664_op in H. discriminate H. Qed.

Lemma reff664_not3659 : ~ @Equation3659 Fin5 reff664_inst.
Proof. unfold Equation3659. intro H. specialize (H F5_1). unfold magma_op, reff664_inst, reff664_op in H. discriminate H. Qed.

Lemma reff664_not3864 : ~ @Equation3864 Fin5 reff664_inst.
Proof. unfold Equation3864. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff664_inst, reff664_op in H. discriminate H. Qed.

Lemma reff664_not3865 : ~ @Equation3865 Fin5 reff664_inst.
Proof. unfold Equation3865. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff664_inst, reff664_op in H. discriminate H. Qed.

Lemma reff664_not3867 : ~ @Equation3867 Fin5 reff664_inst.
Proof. unfold Equation3867. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff664_inst, reff664_op in H. discriminate H. Qed.

Lemma reff664_not3870 : ~ @Equation3870 Fin5 reff664_inst.
Proof. unfold Equation3870. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff664_inst, reff664_op in H. discriminate H. Qed.

Lemma reff664_not3871 : ~ @Equation3871 Fin5 reff664_inst.
Proof. unfold Equation3871. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff664_inst, reff664_op in H. discriminate H. Qed.

Lemma reff664_not3877 : ~ @Equation3877 Fin5 reff664_inst.
Proof. unfold Equation3877. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff664_inst, reff664_op in H. discriminate H. Qed.

Lemma reff664_not3878 : ~ @Equation3878 Fin5 reff664_inst.
Proof. unfold Equation3878. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff664_inst, reff664_op in H. discriminate H. Qed.

Lemma reff664_not3880 : ~ @Equation3880 Fin5 reff664_inst.
Proof. unfold Equation3880. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff664_inst, reff664_op in H. discriminate H. Qed.

Lemma reff664_not3881 : ~ @Equation3881 Fin5 reff664_inst.
Proof. unfold Equation3881. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff664_inst, reff664_op in H. discriminate H. Qed.

Lemma reff664_not3888 : ~ @Equation3888 Fin5 reff664_inst.
Proof. unfold Equation3888. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff664_inst, reff664_op in H. discriminate H. Qed.

Lemma reff664_not3890 : ~ @Equation3890 Fin5 reff664_inst.
Proof. unfold Equation3890. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff664_inst, reff664_op in H. discriminate H. Qed.

Lemma reff664_not3917 : ~ @Equation3917 Fin5 reff664_inst.
Proof. unfold Equation3917. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff664_inst, reff664_op in H. discriminate H. Qed.

Lemma reff664_not3918 : ~ @Equation3918 Fin5 reff664_inst.
Proof. unfold Equation3918. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff664_inst, reff664_op in H. discriminate H. Qed.

Lemma reff664_not3924 : ~ @Equation3924 Fin5 reff664_inst.
Proof. unfold Equation3924. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff664_inst, reff664_op in H. discriminate H. Qed.

Lemma reff664_not3925 : ~ @Equation3925 Fin5 reff664_inst.
Proof. unfold Equation3925. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff664_inst, reff664_op in H. discriminate H. Qed.

Lemma reff664_not3928 : ~ @Equation3928 Fin5 reff664_inst.
Proof. unfold Equation3928. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff664_inst, reff664_op in H. discriminate H. Qed.

Lemma reff664_not3952 : ~ @Equation3952 Fin5 reff664_inst.
Proof. unfold Equation3952. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff664_inst, reff664_op in H. discriminate H. Qed.

Lemma reff664_not3954 : ~ @Equation3954 Fin5 reff664_inst.
Proof. unfold Equation3954. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff664_inst, reff664_op in H. discriminate H. Qed.

Lemma reff664_not3955 : ~ @Equation3955 Fin5 reff664_inst.
Proof. unfold Equation3955. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff664_inst, reff664_op in H. discriminate H. Qed.

Lemma reff664_not3961 : ~ @Equation3961 Fin5 reff664_inst.
Proof. unfold Equation3961. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff664_inst, reff664_op in H. discriminate H. Qed.

Lemma reff664_not3964 : ~ @Equation3964 Fin5 reff664_inst.
Proof. unfold Equation3964. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff664_inst, reff664_op in H. discriminate H. Qed.

Lemma reff664_not4065 : ~ @Equation4065 Fin5 reff664_inst.
Proof. unfold Equation4065. intro H. specialize (H F5_1). unfold magma_op, reff664_inst, reff664_op in H. discriminate H. Qed.

Lemma reff664_not4268 : ~ @Equation4268 Fin5 reff664_inst.
Proof. unfold Equation4268. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff664_inst, reff664_op in H. discriminate H. Qed.

Lemma reff664_not4269 : ~ @Equation4269 Fin5 reff664_inst.
Proof. unfold Equation4269. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff664_inst, reff664_op in H. discriminate H. Qed.

Lemma reff664_not4270 : ~ @Equation4270 Fin5 reff664_inst.
Proof. unfold Equation4270. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff664_inst, reff664_op in H. discriminate H. Qed.

Lemma reff664_not4272 : ~ @Equation4272 Fin5 reff664_inst.
Proof. unfold Equation4272. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff664_inst, reff664_op in H. discriminate H. Qed.

Lemma reff664_not4273 : ~ @Equation4273 Fin5 reff664_inst.
Proof. unfold Equation4273. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff664_inst, reff664_op in H. discriminate H. Qed.

Lemma reff664_not4276 : ~ @Equation4276 Fin5 reff664_inst.
Proof. unfold Equation4276. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff664_inst, reff664_op in H. discriminate H. Qed.

Lemma reff664_not4283 : ~ @Equation4283 Fin5 reff664_inst.
Proof. unfold Equation4283. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff664_inst, reff664_op in H. discriminate H. Qed.

Lemma reff664_not4284 : ~ @Equation4284 Fin5 reff664_inst.
Proof. unfold Equation4284. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff664_inst, reff664_op in H. discriminate H. Qed.

Lemma reff664_not4290 : ~ @Equation4290 Fin5 reff664_inst.
Proof. unfold Equation4290. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff664_inst, reff664_op in H. discriminate H. Qed.

Lemma reff664_not4291 : ~ @Equation4291 Fin5 reff664_inst.
Proof. unfold Equation4291. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff664_inst, reff664_op in H. discriminate H. Qed.

Lemma reff664_not4293 : ~ @Equation4293 Fin5 reff664_inst.
Proof. unfold Equation4293. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff664_inst, reff664_op in H. discriminate H. Qed.

Lemma reff664_not4314 : ~ @Equation4314 Fin5 reff664_inst.
Proof. unfold Equation4314. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff664_inst, reff664_op in H. discriminate H. Qed.

Lemma reff664_not4320 : ~ @Equation4320 Fin5 reff664_inst.
Proof. unfold Equation4320. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff664_inst, reff664_op in H. discriminate H. Qed.

Lemma reff664_not4321 : ~ @Equation4321 Fin5 reff664_inst.
Proof. unfold Equation4321. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff664_inst, reff664_op in H. discriminate H. Qed.

Lemma reff664_not4380 : ~ @Equation4380 Fin5 reff664_inst.
Proof. unfold Equation4380. intro H. specialize (H F5_1). unfold magma_op, reff664_inst, reff664_op in H. discriminate H. Qed.

Lemma reff664_not4583 : ~ @Equation4583 Fin5 reff664_inst.
Proof. unfold Equation4583. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff664_inst, reff664_op in H. discriminate H. Qed.

Lemma reff664_not4584 : ~ @Equation4584 Fin5 reff664_inst.
Proof. unfold Equation4584. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff664_inst, reff664_op in H. discriminate H. Qed.

Lemma reff664_not4585 : ~ @Equation4585 Fin5 reff664_inst.
Proof. unfold Equation4585. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff664_inst, reff664_op in H. discriminate H. Qed.

Lemma reff664_not4587 : ~ @Equation4587 Fin5 reff664_inst.
Proof. unfold Equation4587. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff664_inst, reff664_op in H. discriminate H. Qed.

Lemma reff664_not4588 : ~ @Equation4588 Fin5 reff664_inst.
Proof. unfold Equation4588. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff664_inst, reff664_op in H. discriminate H. Qed.

Lemma reff664_not4590 : ~ @Equation4590 Fin5 reff664_inst.
Proof. unfold Equation4590. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff664_inst, reff664_op in H. discriminate H. Qed.

Lemma reff664_not4598 : ~ @Equation4598 Fin5 reff664_inst.
Proof. unfold Equation4598. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff664_inst, reff664_op in H. discriminate H. Qed.

Lemma reff664_not4599 : ~ @Equation4599 Fin5 reff664_inst.
Proof. unfold Equation4599. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff664_inst, reff664_op in H. discriminate H. Qed.

Lemma reff664_not4606 : ~ @Equation4606 Fin5 reff664_inst.
Proof. unfold Equation4606. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff664_inst, reff664_op in H. discriminate H. Qed.

Lemma reff664_not4608 : ~ @Equation4608 Fin5 reff664_inst.
Proof. unfold Equation4608. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff664_inst, reff664_op in H. discriminate H. Qed.

Lemma reff664_not4629 : ~ @Equation4629 Fin5 reff664_inst.
Proof. unfold Equation4629. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff664_inst, reff664_op in H. discriminate H. Qed.

Lemma reff664_not4635 : ~ @Equation4635 Fin5 reff664_inst.
Proof. unfold Equation4635. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff664_inst, reff664_op in H. discriminate H. Qed.

Lemma reff664_not4636 : ~ @Equation4636 Fin5 reff664_inst.
Proof. unfold Equation4636. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff664_inst, reff664_op in H. discriminate H. Qed.

Lemma reff664_not4658 : ~ @Equation4658 Fin5 reff664_inst.
Proof. unfold Equation4658. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff664_inst, reff664_op in H. discriminate H. Qed.

(** ---- reff672 (Fin5) ---- *)

Definition reff672_op (x y : Fin5) : Fin5 :=
  match x, y with
  | F5_0, F5_0 => F5_0 | F5_0, F5_1 => F5_2 | F5_0, F5_2 => F5_4 | F5_0, F5_3 => F5_1 | F5_0, F5_4 => F5_3
  | F5_1, F5_0 => F5_3 | F5_1, F5_1 => F5_0 | F5_1, F5_2 => F5_2 | F5_1, F5_3 => F5_4 | F5_1, F5_4 => F5_1
  | F5_2, F5_0 => F5_1 | F5_2, F5_1 => F5_3 | F5_2, F5_2 => F5_0 | F5_2, F5_3 => F5_2 | F5_2, F5_4 => F5_4
  | F5_3, F5_0 => F5_4 | F5_3, F5_1 => F5_1 | F5_3, F5_2 => F5_3 | F5_3, F5_3 => F5_0 | F5_3, F5_4 => F5_2
  | F5_4, F5_0 => F5_2 | F5_4, F5_1 => F5_4 | F5_4, F5_2 => F5_1 | F5_4, F5_3 => F5_3 | F5_4, F5_4 => F5_0
  end.

#[local] Instance reff672_inst : Magma Fin5 := {| magma_op := reff672_op |}.

Lemma reff672_sat209 : @Equation209 Fin5 reff672_inst.
Proof. unfold Equation209, magma_op, reff672_inst, reff672_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff672_sat211 : @Equation211 Fin5 reff672_inst.
Proof. unfold Equation211, magma_op, reff672_inst, reff672_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff672_sat481 : @Equation481 Fin5 reff672_inst.
Proof. unfold Equation481, magma_op, reff672_inst, reff672_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff672_sat501 : @Equation501 Fin5 reff672_inst.
Proof. unfold Equation501, magma_op, reff672_inst, reff672_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff672_sat1452 : @Equation1452 Fin5 reff672_inst.
Proof. unfold Equation1452, magma_op, reff672_inst, reff672_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff672_sat1496 : @Equation1496 Fin5 reff672_inst.
Proof. unfold Equation1496, magma_op, reff672_inst, reff672_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff672_sat1523 : @Equation1523 Fin5 reff672_inst.
Proof. unfold Equation1523, magma_op, reff672_inst, reff672_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff672_sat2063 : @Equation2063 Fin5 reff672_inst.
Proof. unfold Equation2063, magma_op, reff672_inst, reff672_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff672_sat2132 : @Equation2132 Fin5 reff672_inst.
Proof. unfold Equation2132, magma_op, reff672_inst, reff672_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff672_sat2146 : @Equation2146 Fin5 reff672_inst.
Proof. unfold Equation2146, magma_op, reff672_inst, reff672_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff672_sat3115 : @Equation3115 Fin5 reff672_inst.
Proof. unfold Equation3115, magma_op, reff672_inst, reff672_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff672_sat3161 : @Equation3161 Fin5 reff672_inst.
Proof. unfold Equation3161, magma_op, reff672_inst, reff672_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff672_not47 : ~ @Equation47 Fin5 reff672_inst.
Proof. unfold Equation47. intro H. specialize (H F5_1). unfold magma_op, reff672_inst, reff672_op in H. discriminate H. Qed.

Lemma reff672_not99 : ~ @Equation99 Fin5 reff672_inst.
Proof. unfold Equation99. intro H. specialize (H F5_1). unfold magma_op, reff672_inst, reff672_op in H. discriminate H. Qed.

Lemma reff672_not151 : ~ @Equation151 Fin5 reff672_inst.
Proof. unfold Equation151. intro H. specialize (H F5_1). unfold magma_op, reff672_inst, reff672_op in H. discriminate H. Qed.

Lemma reff672_not206 : ~ @Equation206 Fin5 reff672_inst.
Proof. unfold Equation206. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff672_inst, reff672_op in H. discriminate H. Qed.

Lemma reff672_not212 : ~ @Equation212 Fin5 reff672_inst.
Proof. unfold Equation212. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff672_inst, reff672_op in H. discriminate H. Qed.

Lemma reff672_not219 : ~ @Equation219 Fin5 reff672_inst.
Proof. unfold Equation219. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff672_inst, reff672_op in H. discriminate H. Qed.

Lemma reff672_not221 : ~ @Equation221 Fin5 reff672_inst.
Proof. unfold Equation221. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff672_inst, reff672_op in H. discriminate H. Qed.

Lemma reff672_not222 : ~ @Equation222 Fin5 reff672_inst.
Proof. unfold Equation222. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff672_inst, reff672_op in H. discriminate H. Qed.

Lemma reff672_not228 : ~ @Equation228 Fin5 reff672_inst.
Proof. unfold Equation228. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff672_inst, reff672_op in H. discriminate H. Qed.

Lemma reff672_not229 : ~ @Equation229 Fin5 reff672_inst.
Proof. unfold Equation229. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff672_inst, reff672_op in H. discriminate H. Qed.

Lemma reff672_not231 : ~ @Equation231 Fin5 reff672_inst.
Proof. unfold Equation231. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff672_inst, reff672_op in H. discriminate H. Qed.

Lemma reff672_not255 : ~ @Equation255 Fin5 reff672_inst.
Proof. unfold Equation255. intro H. specialize (H F5_1). unfold magma_op, reff672_inst, reff672_op in H. discriminate H. Qed.

Lemma reff672_not412 : ~ @Equation412 Fin5 reff672_inst.
Proof. unfold Equation412. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff672_inst, reff672_op in H. discriminate H. Qed.

Lemma reff672_not413 : ~ @Equation413 Fin5 reff672_inst.
Proof. unfold Equation413. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff672_inst, reff672_op in H. discriminate H. Qed.

Lemma reff672_not416 : ~ @Equation416 Fin5 reff672_inst.
Proof. unfold Equation416. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff672_inst, reff672_op in H. discriminate H. Qed.

Lemma reff672_not417 : ~ @Equation417 Fin5 reff672_inst.
Proof. unfold Equation417. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff672_inst, reff672_op in H. discriminate H. Qed.

Lemma reff672_not419 : ~ @Equation419 Fin5 reff672_inst.
Proof. unfold Equation419. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff672_inst, reff672_op in H. discriminate H. Qed.

Lemma reff672_not420 : ~ @Equation420 Fin5 reff672_inst.
Proof. unfold Equation420. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff672_inst, reff672_op in H. discriminate H. Qed.

Lemma reff672_not426 : ~ @Equation426 Fin5 reff672_inst.
Proof. unfold Equation426. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff672_inst, reff672_op in H. discriminate H. Qed.

Lemma reff672_not427 : ~ @Equation427 Fin5 reff672_inst.
Proof. unfold Equation427. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff672_inst, reff672_op in H. discriminate H. Qed.

Lemma reff672_not430 : ~ @Equation430 Fin5 reff672_inst.
Proof. unfold Equation430. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff672_inst, reff672_op in H. discriminate H. Qed.

Lemma reff672_not436 : ~ @Equation436 Fin5 reff672_inst.
Proof. unfold Equation436. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff672_inst, reff672_op in H. discriminate H. Qed.

Lemma reff672_not437 : ~ @Equation437 Fin5 reff672_inst.
Proof. unfold Equation437. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff672_inst, reff672_op in H. discriminate H. Qed.

Lemma reff672_not439 : ~ @Equation439 Fin5 reff672_inst.
Proof. unfold Equation439. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff672_inst, reff672_op in H. discriminate H. Qed.

Lemma reff672_not440 : ~ @Equation440 Fin5 reff672_inst.
Proof. unfold Equation440. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff672_inst, reff672_op in H. discriminate H. Qed.

Lemma reff672_not463 : ~ @Equation463 Fin5 reff672_inst.
Proof. unfold Equation463. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff672_inst, reff672_op in H. discriminate H. Qed.

Lemma reff672_not464 : ~ @Equation464 Fin5 reff672_inst.
Proof. unfold Equation464. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff672_inst, reff672_op in H. discriminate H. Qed.

Lemma reff672_not466 : ~ @Equation466 Fin5 reff672_inst.
Proof. unfold Equation466. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff672_inst, reff672_op in H. discriminate H. Qed.

Lemma reff672_not467 : ~ @Equation467 Fin5 reff672_inst.
Proof. unfold Equation467. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff672_inst, reff672_op in H. discriminate H. Qed.

Lemma reff672_not474 : ~ @Equation474 Fin5 reff672_inst.
Proof. unfold Equation474. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff672_inst, reff672_op in H. discriminate H. Qed.

Lemma reff672_not476 : ~ @Equation476 Fin5 reff672_inst.
Proof. unfold Equation476. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff672_inst, reff672_op in H. discriminate H. Qed.

Lemma reff672_not500 : ~ @Equation500 Fin5 reff672_inst.
Proof. unfold Equation500. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff672_inst, reff672_op in H. discriminate H. Qed.

Lemma reff672_not503 : ~ @Equation503 Fin5 reff672_inst.
Proof. unfold Equation503. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff672_inst, reff672_op in H. discriminate H. Qed.

Lemma reff672_not504 : ~ @Equation504 Fin5 reff672_inst.
Proof. unfold Equation504. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff672_inst, reff672_op in H. discriminate H. Qed.

Lemma reff672_not510 : ~ @Equation510 Fin5 reff672_inst.
Proof. unfold Equation510. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff672_inst, reff672_op in H. discriminate H. Qed.

Lemma reff672_not511 : ~ @Equation511 Fin5 reff672_inst.
Proof. unfold Equation511. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff672_inst, reff672_op in H. discriminate H. Qed.

Lemma reff672_not614 : ~ @Equation614 Fin5 reff672_inst.
Proof. unfold Equation614. intro H. specialize (H F5_1). unfold magma_op, reff672_inst, reff672_op in H. discriminate H. Qed.

Lemma reff672_not817 : ~ @Equation817 Fin5 reff672_inst.
Proof. unfold Equation817. intro H. specialize (H F5_1). unfold magma_op, reff672_inst, reff672_op in H. discriminate H. Qed.

Lemma reff672_not1020 : ~ @Equation1020 Fin5 reff672_inst.
Proof. unfold Equation1020. intro H. specialize (H F5_1). unfold magma_op, reff672_inst, reff672_op in H. discriminate H. Qed.

Lemma reff672_not1223 : ~ @Equation1223 Fin5 reff672_inst.
Proof. unfold Equation1223. intro H. specialize (H F5_1). unfold magma_op, reff672_inst, reff672_op in H. discriminate H. Qed.

Lemma reff672_not1427 : ~ @Equation1427 Fin5 reff672_inst.
Proof. unfold Equation1427. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff672_inst, reff672_op in H. discriminate H. Qed.

Lemma reff672_not1428 : ~ @Equation1428 Fin5 reff672_inst.
Proof. unfold Equation1428. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff672_inst, reff672_op in H. discriminate H. Qed.

Lemma reff672_not1431 : ~ @Equation1431 Fin5 reff672_inst.
Proof. unfold Equation1431. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff672_inst, reff672_op in H. discriminate H. Qed.

Lemma reff672_not1432 : ~ @Equation1432 Fin5 reff672_inst.
Proof. unfold Equation1432. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff672_inst, reff672_op in H. discriminate H. Qed.

Lemma reff672_not1434 : ~ @Equation1434 Fin5 reff672_inst.
Proof. unfold Equation1434. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff672_inst, reff672_op in H. discriminate H. Qed.

Lemma reff672_not1435 : ~ @Equation1435 Fin5 reff672_inst.
Proof. unfold Equation1435. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff672_inst, reff672_op in H. discriminate H. Qed.

Lemma reff672_not1441 : ~ @Equation1441 Fin5 reff672_inst.
Proof. unfold Equation1441. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff672_inst, reff672_op in H. discriminate H. Qed.

Lemma reff672_not1442 : ~ @Equation1442 Fin5 reff672_inst.
Proof. unfold Equation1442. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff672_inst, reff672_op in H. discriminate H. Qed.

Lemma reff672_not1444 : ~ @Equation1444 Fin5 reff672_inst.
Proof. unfold Equation1444. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff672_inst, reff672_op in H. discriminate H. Qed.

Lemma reff672_not1445 : ~ @Equation1445 Fin5 reff672_inst.
Proof. unfold Equation1445. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff672_inst, reff672_op in H. discriminate H. Qed.

Lemma reff672_not1451 : ~ @Equation1451 Fin5 reff672_inst.
Proof. unfold Equation1451. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff672_inst, reff672_op in H. discriminate H. Qed.

Lemma reff672_not1454 : ~ @Equation1454 Fin5 reff672_inst.
Proof. unfold Equation1454. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff672_inst, reff672_op in H. discriminate H. Qed.

Lemma reff672_not1455 : ~ @Equation1455 Fin5 reff672_inst.
Proof. unfold Equation1455. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff672_inst, reff672_op in H. discriminate H. Qed.

Lemma reff672_not1478 : ~ @Equation1478 Fin5 reff672_inst.
Proof. unfold Equation1478. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff672_inst, reff672_op in H. discriminate H. Qed.

Lemma reff672_not1479 : ~ @Equation1479 Fin5 reff672_inst.
Proof. unfold Equation1479. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff672_inst, reff672_op in H. discriminate H. Qed.

Lemma reff672_not1481 : ~ @Equation1481 Fin5 reff672_inst.
Proof. unfold Equation1481. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff672_inst, reff672_op in H. discriminate H. Qed.

Lemma reff672_not1482 : ~ @Equation1482 Fin5 reff672_inst.
Proof. unfold Equation1482. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff672_inst, reff672_op in H. discriminate H. Qed.

Lemma reff672_not1489 : ~ @Equation1489 Fin5 reff672_inst.
Proof. unfold Equation1489. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff672_inst, reff672_op in H. discriminate H. Qed.

Lemma reff672_not1491 : ~ @Equation1491 Fin5 reff672_inst.
Proof. unfold Equation1491. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff672_inst, reff672_op in H. discriminate H. Qed.

Lemma reff672_not1516 : ~ @Equation1516 Fin5 reff672_inst.
Proof. unfold Equation1516. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff672_inst, reff672_op in H. discriminate H. Qed.

Lemma reff672_not1518 : ~ @Equation1518 Fin5 reff672_inst.
Proof. unfold Equation1518. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff672_inst, reff672_op in H. discriminate H. Qed.

Lemma reff672_not1525 : ~ @Equation1525 Fin5 reff672_inst.
Proof. unfold Equation1525. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff672_inst, reff672_op in H. discriminate H. Qed.

Lemma reff672_not1526 : ~ @Equation1526 Fin5 reff672_inst.
Proof. unfold Equation1526. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff672_inst, reff672_op in H. discriminate H. Qed.

Lemma reff672_not1528 : ~ @Equation1528 Fin5 reff672_inst.
Proof. unfold Equation1528. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff672_inst, reff672_op in H. discriminate H. Qed.

Lemma reff672_not1629 : ~ @Equation1629 Fin5 reff672_inst.
Proof. unfold Equation1629. intro H. specialize (H F5_1). unfold magma_op, reff672_inst, reff672_op in H. discriminate H. Qed.

Lemma reff672_not1832 : ~ @Equation1832 Fin5 reff672_inst.
Proof. unfold Equation1832. intro H. specialize (H F5_1). unfold magma_op, reff672_inst, reff672_op in H. discriminate H. Qed.

Lemma reff672_not2036 : ~ @Equation2036 Fin5 reff672_inst.
Proof. unfold Equation2036. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff672_inst, reff672_op in H. discriminate H. Qed.

Lemma reff672_not2037 : ~ @Equation2037 Fin5 reff672_inst.
Proof. unfold Equation2037. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff672_inst, reff672_op in H. discriminate H. Qed.

Lemma reff672_not2040 : ~ @Equation2040 Fin5 reff672_inst.
Proof. unfold Equation2040. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff672_inst, reff672_op in H. discriminate H. Qed.

Lemma reff672_not2043 : ~ @Equation2043 Fin5 reff672_inst.
Proof. unfold Equation2043. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff672_inst, reff672_op in H. discriminate H. Qed.

Lemma reff672_not2044 : ~ @Equation2044 Fin5 reff672_inst.
Proof. unfold Equation2044. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff672_inst, reff672_op in H. discriminate H. Qed.

Lemma reff672_not2050 : ~ @Equation2050 Fin5 reff672_inst.
Proof. unfold Equation2050. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff672_inst, reff672_op in H. discriminate H. Qed.

Lemma reff672_not2051 : ~ @Equation2051 Fin5 reff672_inst.
Proof. unfold Equation2051. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff672_inst, reff672_op in H. discriminate H. Qed.

Lemma reff672_not2053 : ~ @Equation2053 Fin5 reff672_inst.
Proof. unfold Equation2053. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff672_inst, reff672_op in H. discriminate H. Qed.

Lemma reff672_not2054 : ~ @Equation2054 Fin5 reff672_inst.
Proof. unfold Equation2054. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff672_inst, reff672_op in H. discriminate H. Qed.

Lemma reff672_not2060 : ~ @Equation2060 Fin5 reff672_inst.
Proof. unfold Equation2060. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff672_inst, reff672_op in H. discriminate H. Qed.

Lemma reff672_not2061 : ~ @Equation2061 Fin5 reff672_inst.
Proof. unfold Equation2061. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff672_inst, reff672_op in H. discriminate H. Qed.

Lemma reff672_not2064 : ~ @Equation2064 Fin5 reff672_inst.
Proof. unfold Equation2064. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff672_inst, reff672_op in H. discriminate H. Qed.

Lemma reff672_not2087 : ~ @Equation2087 Fin5 reff672_inst.
Proof. unfold Equation2087. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff672_inst, reff672_op in H. discriminate H. Qed.

Lemma reff672_not2088 : ~ @Equation2088 Fin5 reff672_inst.
Proof. unfold Equation2088. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff672_inst, reff672_op in H. discriminate H. Qed.

Lemma reff672_not2090 : ~ @Equation2090 Fin5 reff672_inst.
Proof. unfold Equation2090. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff672_inst, reff672_op in H. discriminate H. Qed.

Lemma reff672_not2091 : ~ @Equation2091 Fin5 reff672_inst.
Proof. unfold Equation2091. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff672_inst, reff672_op in H. discriminate H. Qed.

Lemma reff672_not2097 : ~ @Equation2097 Fin5 reff672_inst.
Proof. unfold Equation2097. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff672_inst, reff672_op in H. discriminate H. Qed.

Lemma reff672_not2098 : ~ @Equation2098 Fin5 reff672_inst.
Proof. unfold Equation2098. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff672_inst, reff672_op in H. discriminate H. Qed.

Lemma reff672_not2100 : ~ @Equation2100 Fin5 reff672_inst.
Proof. unfold Equation2100. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff672_inst, reff672_op in H. discriminate H. Qed.

Lemma reff672_not2101 : ~ @Equation2101 Fin5 reff672_inst.
Proof. unfold Equation2101. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff672_inst, reff672_op in H. discriminate H. Qed.

Lemma reff672_not2125 : ~ @Equation2125 Fin5 reff672_inst.
Proof. unfold Equation2125. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff672_inst, reff672_op in H. discriminate H. Qed.

Lemma reff672_not2127 : ~ @Equation2127 Fin5 reff672_inst.
Proof. unfold Equation2127. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff672_inst, reff672_op in H. discriminate H. Qed.

Lemma reff672_not2134 : ~ @Equation2134 Fin5 reff672_inst.
Proof. unfold Equation2134. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff672_inst, reff672_op in H. discriminate H. Qed.

Lemma reff672_not2137 : ~ @Equation2137 Fin5 reff672_inst.
Proof. unfold Equation2137. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff672_inst, reff672_op in H. discriminate H. Qed.

Lemma reff672_not2238 : ~ @Equation2238 Fin5 reff672_inst.
Proof. unfold Equation2238. intro H. specialize (H F5_1). unfold magma_op, reff672_inst, reff672_op in H. discriminate H. Qed.

Lemma reff672_not2441 : ~ @Equation2441 Fin5 reff672_inst.
Proof. unfold Equation2441. intro H. specialize (H F5_1). unfold magma_op, reff672_inst, reff672_op in H. discriminate H. Qed.

Lemma reff672_not2644 : ~ @Equation2644 Fin5 reff672_inst.
Proof. unfold Equation2644. intro H. specialize (H F5_1). unfold magma_op, reff672_inst, reff672_op in H. discriminate H. Qed.

Lemma reff672_not2847 : ~ @Equation2847 Fin5 reff672_inst.
Proof. unfold Equation2847. intro H. specialize (H F5_1). unfold magma_op, reff672_inst, reff672_op in H. discriminate H. Qed.

Lemma reff672_not3051 : ~ @Equation3051 Fin5 reff672_inst.
Proof. unfold Equation3051. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff672_inst, reff672_op in H. discriminate H. Qed.

Lemma reff672_not3052 : ~ @Equation3052 Fin5 reff672_inst.
Proof. unfold Equation3052. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff672_inst, reff672_op in H. discriminate H. Qed.

Lemma reff672_not3053 : ~ @Equation3053 Fin5 reff672_inst.
Proof. unfold Equation3053. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff672_inst, reff672_op in H. discriminate H. Qed.

Lemma reff672_not3055 : ~ @Equation3055 Fin5 reff672_inst.
Proof. unfold Equation3055. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff672_inst, reff672_op in H. discriminate H. Qed.

Lemma reff672_not3058 : ~ @Equation3058 Fin5 reff672_inst.
Proof. unfold Equation3058. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff672_inst, reff672_op in H. discriminate H. Qed.

Lemma reff672_not3059 : ~ @Equation3059 Fin5 reff672_inst.
Proof. unfold Equation3059. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff672_inst, reff672_op in H. discriminate H. Qed.

Lemma reff672_not3065 : ~ @Equation3065 Fin5 reff672_inst.
Proof. unfold Equation3065. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff672_inst, reff672_op in H. discriminate H. Qed.

Lemma reff672_not3066 : ~ @Equation3066 Fin5 reff672_inst.
Proof. unfold Equation3066. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff672_inst, reff672_op in H. discriminate H. Qed.

Lemma reff672_not3069 : ~ @Equation3069 Fin5 reff672_inst.
Proof. unfold Equation3069. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff672_inst, reff672_op in H. discriminate H. Qed.

Lemma reff672_not3075 : ~ @Equation3075 Fin5 reff672_inst.
Proof. unfold Equation3075. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff672_inst, reff672_op in H. discriminate H. Qed.

Lemma reff672_not3076 : ~ @Equation3076 Fin5 reff672_inst.
Proof. unfold Equation3076. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff672_inst, reff672_op in H. discriminate H. Qed.

Lemma reff672_not3078 : ~ @Equation3078 Fin5 reff672_inst.
Proof. unfold Equation3078. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff672_inst, reff672_op in H. discriminate H. Qed.

Lemma reff672_not3102 : ~ @Equation3102 Fin5 reff672_inst.
Proof. unfold Equation3102. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff672_inst, reff672_op in H. discriminate H. Qed.

Lemma reff672_not3103 : ~ @Equation3103 Fin5 reff672_inst.
Proof. unfold Equation3103. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff672_inst, reff672_op in H. discriminate H. Qed.

Lemma reff672_not3105 : ~ @Equation3105 Fin5 reff672_inst.
Proof. unfold Equation3105. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff672_inst, reff672_op in H. discriminate H. Qed.

Lemma reff672_not3106 : ~ @Equation3106 Fin5 reff672_inst.
Proof. unfold Equation3106. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff672_inst, reff672_op in H. discriminate H. Qed.

Lemma reff672_not3112 : ~ @Equation3112 Fin5 reff672_inst.
Proof. unfold Equation3112. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff672_inst, reff672_op in H. discriminate H. Qed.

Lemma reff672_not3113 : ~ @Equation3113 Fin5 reff672_inst.
Proof. unfold Equation3113. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff672_inst, reff672_op in H. discriminate H. Qed.

Lemma reff672_not3116 : ~ @Equation3116 Fin5 reff672_inst.
Proof. unfold Equation3116. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff672_inst, reff672_op in H. discriminate H. Qed.

Lemma reff672_not3140 : ~ @Equation3140 Fin5 reff672_inst.
Proof. unfold Equation3140. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff672_inst, reff672_op in H. discriminate H. Qed.

Lemma reff672_not3142 : ~ @Equation3142 Fin5 reff672_inst.
Proof. unfold Equation3142. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff672_inst, reff672_op in H. discriminate H. Qed.

Lemma reff672_not3143 : ~ @Equation3143 Fin5 reff672_inst.
Proof. unfold Equation3143. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff672_inst, reff672_op in H. discriminate H. Qed.

Lemma reff672_not3149 : ~ @Equation3149 Fin5 reff672_inst.
Proof. unfold Equation3149. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff672_inst, reff672_op in H. discriminate H. Qed.

Lemma reff672_not3152 : ~ @Equation3152 Fin5 reff672_inst.
Proof. unfold Equation3152. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff672_inst, reff672_op in H. discriminate H. Qed.

Lemma reff672_not3253 : ~ @Equation3253 Fin5 reff672_inst.
Proof. unfold Equation3253. intro H. specialize (H F5_1). unfold magma_op, reff672_inst, reff672_op in H. discriminate H. Qed.

Lemma reff672_not3456 : ~ @Equation3456 Fin5 reff672_inst.
Proof. unfold Equation3456. intro H. specialize (H F5_1). unfold magma_op, reff672_inst, reff672_op in H. discriminate H. Qed.

Lemma reff672_not3660 : ~ @Equation3660 Fin5 reff672_inst.
Proof. unfold Equation3660. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff672_inst, reff672_op in H. discriminate H. Qed.

Lemma reff672_not3661 : ~ @Equation3661 Fin5 reff672_inst.
Proof. unfold Equation3661. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff672_inst, reff672_op in H. discriminate H. Qed.

Lemma reff672_not3664 : ~ @Equation3664 Fin5 reff672_inst.
Proof. unfold Equation3664. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff672_inst, reff672_op in H. discriminate H. Qed.

Lemma reff672_not3667 : ~ @Equation3667 Fin5 reff672_inst.
Proof. unfold Equation3667. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff672_inst, reff672_op in H. discriminate H. Qed.

Lemma reff672_not3668 : ~ @Equation3668 Fin5 reff672_inst.
Proof. unfold Equation3668. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff672_inst, reff672_op in H. discriminate H. Qed.

Lemma reff672_not3674 : ~ @Equation3674 Fin5 reff672_inst.
Proof. unfold Equation3674. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff672_inst, reff672_op in H. discriminate H. Qed.

Lemma reff672_not3675 : ~ @Equation3675 Fin5 reff672_inst.
Proof. unfold Equation3675. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff672_inst, reff672_op in H. discriminate H. Qed.

Lemma reff672_not3678 : ~ @Equation3678 Fin5 reff672_inst.
Proof. unfold Equation3678. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff672_inst, reff672_op in H. discriminate H. Qed.

Lemma reff672_not3685 : ~ @Equation3685 Fin5 reff672_inst.
Proof. unfold Equation3685. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff672_inst, reff672_op in H. discriminate H. Qed.

Lemma reff672_not3687 : ~ @Equation3687 Fin5 reff672_inst.
Proof. unfold Equation3687. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff672_inst, reff672_op in H. discriminate H. Qed.

Lemma reff672_not3712 : ~ @Equation3712 Fin5 reff672_inst.
Proof. unfold Equation3712. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff672_inst, reff672_op in H. discriminate H. Qed.

Lemma reff672_not3714 : ~ @Equation3714 Fin5 reff672_inst.
Proof. unfold Equation3714. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff672_inst, reff672_op in H. discriminate H. Qed.

Lemma reff672_not3721 : ~ @Equation3721 Fin5 reff672_inst.
Proof. unfold Equation3721. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff672_inst, reff672_op in H. discriminate H. Qed.

Lemma reff672_not3722 : ~ @Equation3722 Fin5 reff672_inst.
Proof. unfold Equation3722. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff672_inst, reff672_op in H. discriminate H. Qed.

Lemma reff672_not3725 : ~ @Equation3725 Fin5 reff672_inst.
Proof. unfold Equation3725. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff672_inst, reff672_op in H. discriminate H. Qed.

Lemma reff672_not3748 : ~ @Equation3748 Fin5 reff672_inst.
Proof. unfold Equation3748. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff672_inst, reff672_op in H. discriminate H. Qed.

Lemma reff672_not3749 : ~ @Equation3749 Fin5 reff672_inst.
Proof. unfold Equation3749. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff672_inst, reff672_op in H. discriminate H. Qed.

Lemma reff672_not3751 : ~ @Equation3751 Fin5 reff672_inst.
Proof. unfold Equation3751. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff672_inst, reff672_op in H. discriminate H. Qed.

Lemma reff672_not3752 : ~ @Equation3752 Fin5 reff672_inst.
Proof. unfold Equation3752. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff672_inst, reff672_op in H. discriminate H. Qed.

Lemma reff672_not3759 : ~ @Equation3759 Fin5 reff672_inst.
Proof. unfold Equation3759. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff672_inst, reff672_op in H. discriminate H. Qed.

Lemma reff672_not3761 : ~ @Equation3761 Fin5 reff672_inst.
Proof. unfold Equation3761. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff672_inst, reff672_op in H. discriminate H. Qed.

Lemma reff672_not3862 : ~ @Equation3862 Fin5 reff672_inst.
Proof. unfold Equation3862. intro H. specialize (H F5_1). unfold magma_op, reff672_inst, reff672_op in H. discriminate H. Qed.

Lemma reff672_not4065 : ~ @Equation4065 Fin5 reff672_inst.
Proof. unfold Equation4065. intro H. specialize (H F5_1). unfold magma_op, reff672_inst, reff672_op in H. discriminate H. Qed.

Lemma reff672_not4268 : ~ @Equation4268 Fin5 reff672_inst.
Proof. unfold Equation4268. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff672_inst, reff672_op in H. discriminate H. Qed.

Lemma reff672_not4269 : ~ @Equation4269 Fin5 reff672_inst.
Proof. unfold Equation4269. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff672_inst, reff672_op in H. discriminate H. Qed.

Lemma reff672_not4272 : ~ @Equation4272 Fin5 reff672_inst.
Proof. unfold Equation4272. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff672_inst, reff672_op in H. discriminate H. Qed.

Lemma reff672_not4273 : ~ @Equation4273 Fin5 reff672_inst.
Proof. unfold Equation4273. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff672_inst, reff672_op in H. discriminate H. Qed.

Lemma reff672_not4275 : ~ @Equation4275 Fin5 reff672_inst.
Proof. unfold Equation4275. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff672_inst, reff672_op in H. discriminate H. Qed.

Lemma reff672_not4276 : ~ @Equation4276 Fin5 reff672_inst.
Proof. unfold Equation4276. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff672_inst, reff672_op in H. discriminate H. Qed.

Lemma reff672_not4283 : ~ @Equation4283 Fin5 reff672_inst.
Proof. unfold Equation4283. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff672_inst, reff672_op in H. discriminate H. Qed.

Lemma reff672_not4284 : ~ @Equation4284 Fin5 reff672_inst.
Proof. unfold Equation4284. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff672_inst, reff672_op in H. discriminate H. Qed.

Lemma reff672_not4290 : ~ @Equation4290 Fin5 reff672_inst.
Proof. unfold Equation4290. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff672_inst, reff672_op in H. discriminate H. Qed.

Lemma reff672_not4291 : ~ @Equation4291 Fin5 reff672_inst.
Proof. unfold Equation4291. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff672_inst, reff672_op in H. discriminate H. Qed.

Lemma reff672_not4314 : ~ @Equation4314 Fin5 reff672_inst.
Proof. unfold Equation4314. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff672_inst, reff672_op in H. discriminate H. Qed.

Lemma reff672_not4320 : ~ @Equation4320 Fin5 reff672_inst.
Proof. unfold Equation4320. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff672_inst, reff672_op in H. discriminate H. Qed.

Lemma reff672_not4321 : ~ @Equation4321 Fin5 reff672_inst.
Proof. unfold Equation4321. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff672_inst, reff672_op in H. discriminate H. Qed.

Lemma reff672_not4343 : ~ @Equation4343 Fin5 reff672_inst.
Proof. unfold Equation4343. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff672_inst, reff672_op in H. discriminate H. Qed.

Lemma reff672_not4380 : ~ @Equation4380 Fin5 reff672_inst.
Proof. unfold Equation4380. intro H. specialize (H F5_1). unfold magma_op, reff672_inst, reff672_op in H. discriminate H. Qed.

Lemma reff672_not4583 : ~ @Equation4583 Fin5 reff672_inst.
Proof. unfold Equation4583. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff672_inst, reff672_op in H. discriminate H. Qed.

Lemma reff672_not4584 : ~ @Equation4584 Fin5 reff672_inst.
Proof. unfold Equation4584. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff672_inst, reff672_op in H. discriminate H. Qed.

Lemma reff672_not4585 : ~ @Equation4585 Fin5 reff672_inst.
Proof. unfold Equation4585. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff672_inst, reff672_op in H. discriminate H. Qed.

Lemma reff672_not4587 : ~ @Equation4587 Fin5 reff672_inst.
Proof. unfold Equation4587. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff672_inst, reff672_op in H. discriminate H. Qed.

Lemma reff672_not4588 : ~ @Equation4588 Fin5 reff672_inst.
Proof. unfold Equation4588. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff672_inst, reff672_op in H. discriminate H. Qed.

Lemma reff672_not4591 : ~ @Equation4591 Fin5 reff672_inst.
Proof. unfold Equation4591. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff672_inst, reff672_op in H. discriminate H. Qed.

Lemma reff672_not4598 : ~ @Equation4598 Fin5 reff672_inst.
Proof. unfold Equation4598. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff672_inst, reff672_op in H. discriminate H. Qed.

Lemma reff672_not4599 : ~ @Equation4599 Fin5 reff672_inst.
Proof. unfold Equation4599. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff672_inst, reff672_op in H. discriminate H. Qed.

Lemma reff672_not4605 : ~ @Equation4605 Fin5 reff672_inst.
Proof. unfold Equation4605. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff672_inst, reff672_op in H. discriminate H. Qed.

Lemma reff672_not4606 : ~ @Equation4606 Fin5 reff672_inst.
Proof. unfold Equation4606. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff672_inst, reff672_op in H. discriminate H. Qed.

Lemma reff672_not4608 : ~ @Equation4608 Fin5 reff672_inst.
Proof. unfold Equation4608. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff672_inst, reff672_op in H. discriminate H. Qed.

Lemma reff672_not4629 : ~ @Equation4629 Fin5 reff672_inst.
Proof. unfold Equation4629. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff672_inst, reff672_op in H. discriminate H. Qed.

Lemma reff672_not4635 : ~ @Equation4635 Fin5 reff672_inst.
Proof. unfold Equation4635. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff672_inst, reff672_op in H. discriminate H. Qed.

Lemma reff672_not4658 : ~ @Equation4658 Fin5 reff672_inst.
Proof. unfold Equation4658. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff672_inst, reff672_op in H. discriminate H. Qed.

(** ---- reff674 (Fin5) ---- *)

Definition reff674_op (x y : Fin5) : Fin5 :=
  match x, y with
  | F5_0, F5_0 => F5_0 | F5_0, F5_1 => F5_3 | F5_0, F5_2 => F5_1 | F5_0, F5_3 => F5_4 | F5_0, F5_4 => F5_2
  | F5_1, F5_0 => F5_3 | F5_1, F5_1 => F5_1 | F5_1, F5_2 => F5_4 | F5_1, F5_3 => F5_2 | F5_1, F5_4 => F5_0
  | F5_2, F5_0 => F5_1 | F5_2, F5_1 => F5_4 | F5_2, F5_2 => F5_2 | F5_2, F5_3 => F5_0 | F5_2, F5_4 => F5_3
  | F5_3, F5_0 => F5_4 | F5_3, F5_1 => F5_2 | F5_3, F5_2 => F5_0 | F5_3, F5_3 => F5_3 | F5_3, F5_4 => F5_1
  | F5_4, F5_0 => F5_2 | F5_4, F5_1 => F5_0 | F5_4, F5_2 => F5_3 | F5_4, F5_3 => F5_1 | F5_4, F5_4 => F5_4
  end.

#[local] Instance reff674_inst : Magma Fin5 := {| magma_op := reff674_op |}.

Lemma reff674_sat63 : @Equation63 Fin5 reff674_inst.
Proof. unfold Equation63, magma_op, reff674_inst, reff674_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff674_sat65 : @Equation65 Fin5 reff674_inst.
Proof. unfold Equation65, magma_op, reff674_inst, reff674_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff674_sat117 : @Equation117 Fin5 reff674_inst.
Proof. unfold Equation117, magma_op, reff674_inst, reff674_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff674_sat124 : @Equation124 Fin5 reff674_inst.
Proof. unfold Equation124, magma_op, reff674_inst, reff674_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff674_sat206 : @Equation206 Fin5 reff674_inst.
Proof. unfold Equation206, magma_op, reff674_inst, reff674_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff674_sat209 : @Equation209 Fin5 reff674_inst.
Proof. unfold Equation209, magma_op, reff674_inst, reff674_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff674_sat261 : @Equation261 Fin5 reff674_inst.
Proof. unfold Equation261, magma_op, reff674_inst, reff674_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff674_sat271 : @Equation271 Fin5 reff674_inst.
Proof. unfold Equation271, magma_op, reff674_inst, reff674_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff674_sat467 : @Equation467 Fin5 reff674_inst.
Proof. unfold Equation467, magma_op, reff674_inst, reff674_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff674_sat556 : @Equation556 Fin5 reff674_inst.
Proof. unfold Equation556, magma_op, reff674_inst, reff674_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff674_sat562 : @Equation562 Fin5 reff674_inst.
Proof. unfold Equation562, magma_op, reff674_inst, reff674_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff674_sat679 : @Equation679 Fin5 reff674_inst.
Proof. unfold Equation679, magma_op, reff674_inst, reff674_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff674_sat749 : @Equation749 Fin5 reff674_inst.
Proof. unfold Equation749, magma_op, reff674_inst, reff674_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff674_sat775 : @Equation775 Fin5 reff674_inst.
Proof. unfold Equation775, magma_op, reff674_inst, reff674_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff674_sat870 : @Equation870 Fin5 reff674_inst.
Proof. unfold Equation870, magma_op, reff674_inst, reff674_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff674_sat872 : @Equation872 Fin5 reff674_inst.
Proof. unfold Equation872, magma_op, reff674_inst, reff674_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff674_sat879 : @Equation879 Fin5 reff674_inst.
Proof. unfold Equation879, magma_op, reff674_inst, reff674_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff674_sat906 : @Equation906 Fin5 reff674_inst.
Proof. unfold Equation906, magma_op, reff674_inst, reff674_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff674_sat1085 : @Equation1085 Fin5 reff674_inst.
Proof. unfold Equation1085, magma_op, reff674_inst, reff674_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff674_sat1117 : @Equation1117 Fin5 reff674_inst.
Proof. unfold Equation1117, magma_op, reff674_inst, reff674_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff674_sat1131 : @Equation1131 Fin5 reff674_inst.
Proof. unfold Equation1131, magma_op, reff674_inst, reff674_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff674_sat1301 : @Equation1301 Fin5 reff674_inst.
Proof. unfold Equation1301, magma_op, reff674_inst, reff674_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff674_sat1322 : @Equation1322 Fin5 reff674_inst.
Proof. unfold Equation1322, magma_op, reff674_inst, reff674_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff674_sat1355 : @Equation1355 Fin5 reff674_inst.
Proof. unfold Equation1355, magma_op, reff674_inst, reff674_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff674_sat1452 : @Equation1452 Fin5 reff674_inst.
Proof. unfold Equation1452, magma_op, reff674_inst, reff674_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff674_sat1454 : @Equation1454 Fin5 reff674_inst.
Proof. unfold Equation1454, magma_op, reff674_inst, reff674_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff674_sat1489 : @Equation1489 Fin5 reff674_inst.
Proof. unfold Equation1489, magma_op, reff674_inst, reff674_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff674_sat1491 : @Equation1491 Fin5 reff674_inst.
Proof. unfold Equation1491, magma_op, reff674_inst, reff674_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff674_sat1516 : @Equation1516 Fin5 reff674_inst.
Proof. unfold Equation1516, magma_op, reff674_inst, reff674_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff674_sat1518 : @Equation1518 Fin5 reff674_inst.
Proof. unfold Equation1518, magma_op, reff674_inst, reff674_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff674_sat1648 : @Equation1648 Fin5 reff674_inst.
Proof. unfold Equation1648, magma_op, reff674_inst, reff674_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff674_sat1655 : @Equation1655 Fin5 reff674_inst.
Proof. unfold Equation1655, magma_op, reff674_inst, reff674_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff674_sat1685 : @Equation1685 Fin5 reff674_inst.
Proof. unfold Equation1685, magma_op, reff674_inst, reff674_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff674_sat1692 : @Equation1692 Fin5 reff674_inst.
Proof. unfold Equation1692, magma_op, reff674_inst, reff674_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff674_sat1721 : @Equation1721 Fin5 reff674_inst.
Proof. unfold Equation1721, magma_op, reff674_inst, reff674_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff674_sat1728 : @Equation1728 Fin5 reff674_inst.
Proof. unfold Equation1728, magma_op, reff674_inst, reff674_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff674_sat1841 : @Equation1841 Fin5 reff674_inst.
Proof. unfold Equation1841, magma_op, reff674_inst, reff674_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff674_sat1851 : @Equation1851 Fin5 reff674_inst.
Proof. unfold Equation1851, magma_op, reff674_inst, reff674_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff674_sat1895 : @Equation1895 Fin5 reff674_inst.
Proof. unfold Equation1895, magma_op, reff674_inst, reff674_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff674_sat1897 : @Equation1897 Fin5 reff674_inst.
Proof. unfold Equation1897, magma_op, reff674_inst, reff674_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff674_sat1922 : @Equation1922 Fin5 reff674_inst.
Proof. unfold Equation1922, magma_op, reff674_inst, reff674_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff674_sat1924 : @Equation1924 Fin5 reff674_inst.
Proof. unfold Equation1924, magma_op, reff674_inst, reff674_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff674_sat2054 : @Equation2054 Fin5 reff674_inst.
Proof. unfold Equation2054, magma_op, reff674_inst, reff674_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff674_sat2061 : @Equation2061 Fin5 reff674_inst.
Proof. unfold Equation2061, magma_op, reff674_inst, reff674_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff674_sat2063 : @Equation2063 Fin5 reff674_inst.
Proof. unfold Equation2063, magma_op, reff674_inst, reff674_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff674_sat2091 : @Equation2091 Fin5 reff674_inst.
Proof. unfold Equation2091, magma_op, reff674_inst, reff674_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff674_sat2098 : @Equation2098 Fin5 reff674_inst.
Proof. unfold Equation2098, magma_op, reff674_inst, reff674_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff674_sat2100 : @Equation2100 Fin5 reff674_inst.
Proof. unfold Equation2100, magma_op, reff674_inst, reff674_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff674_sat2247 : @Equation2247 Fin5 reff674_inst.
Proof. unfold Equation2247, magma_op, reff674_inst, reff674_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff674_sat2370 : @Equation2370 Fin5 reff674_inst.
Proof. unfold Equation2370, magma_op, reff674_inst, reff674_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff674_sat2383 : @Equation2383 Fin5 reff674_inst.
Proof. unfold Equation2383, magma_op, reff674_inst, reff674_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff674_sat2467 : @Equation2467 Fin5 reff674_inst.
Proof. unfold Equation2467, magma_op, reff674_inst, reff674_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff674_sat2511 : @Equation2511 Fin5 reff674_inst.
Proof. unfold Equation2511, magma_op, reff674_inst, reff674_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff674_sat2538 : @Equation2538 Fin5 reff674_inst.
Proof. unfold Equation2538, magma_op, reff674_inst, reff674_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff674_sat2647 : @Equation2647 Fin5 reff674_inst.
Proof. unfold Equation2647, magma_op, reff674_inst, reff674_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff674_sat2650 : @Equation2650 Fin5 reff674_inst.
Proof. unfold Equation2650, magma_op, reff674_inst, reff674_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff674_sat2660 : @Equation2660 Fin5 reff674_inst.
Proof. unfold Equation2660, magma_op, reff674_inst, reff674_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff674_sat2697 : @Equation2697 Fin5 reff674_inst.
Proof. unfold Equation2697, magma_op, reff674_inst, reff674_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff674_sat2873 : @Equation2873 Fin5 reff674_inst.
Proof. unfold Equation2873, magma_op, reff674_inst, reff674_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff674_sat2928 : @Equation2928 Fin5 reff674_inst.
Proof. unfold Equation2928, magma_op, reff674_inst, reff674_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff674_sat2982 : @Equation2982 Fin5 reff674_inst.
Proof. unfold Equation2982, magma_op, reff674_inst, reff674_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff674_sat3128 : @Equation3128 Fin5 reff674_inst.
Proof. unfold Equation3128, magma_op, reff674_inst, reff674_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff674_sat3140 : @Equation3140 Fin5 reff674_inst.
Proof. unfold Equation3140, magma_op, reff674_inst, reff674_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff674_sat3269 : @Equation3269 Fin5 reff674_inst.
Proof. unfold Equation3269, magma_op, reff674_inst, reff674_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff674_sat3271 : @Equation3271 Fin5 reff674_inst.
Proof. unfold Equation3271, magma_op, reff674_inst, reff674_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff674_sat3474 : @Equation3474 Fin5 reff674_inst.
Proof. unfold Equation3474, magma_op, reff674_inst, reff674_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff674_sat3481 : @Equation3481 Fin5 reff674_inst.
Proof. unfold Equation3481, magma_op, reff674_inst, reff674_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff674_sat3865 : @Equation3865 Fin5 reff674_inst.
Proof. unfold Equation3865, magma_op, reff674_inst, reff674_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff674_sat3868 : @Equation3868 Fin5 reff674_inst.
Proof. unfold Equation3868, magma_op, reff674_inst, reff674_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff674_sat4071 : @Equation4071 Fin5 reff674_inst.
Proof. unfold Equation4071, magma_op, reff674_inst, reff674_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff674_sat4081 : @Equation4081 Fin5 reff674_inst.
Proof. unfold Equation4081, magma_op, reff674_inst, reff674_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff674_not50 : ~ @Equation50 Fin5 reff674_inst.
Proof. unfold Equation50. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff674_inst, reff674_op in H. discriminate H. Qed.

Lemma reff674_not53 : ~ @Equation53 Fin5 reff674_inst.
Proof. unfold Equation53. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff674_inst, reff674_op in H. discriminate H. Qed.

Lemma reff674_not55 : ~ @Equation55 Fin5 reff674_inst.
Proof. unfold Equation55. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff674_inst, reff674_op in H. discriminate H. Qed.

Lemma reff674_not56 : ~ @Equation56 Fin5 reff674_inst.
Proof. unfold Equation56. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff674_inst, reff674_op in H. discriminate H. Qed.

Lemma reff674_not66 : ~ @Equation66 Fin5 reff674_inst.
Proof. unfold Equation66. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff674_inst, reff674_op in H. discriminate H. Qed.

Lemma reff674_not72 : ~ @Equation72 Fin5 reff674_inst.
Proof. unfold Equation72. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff674_inst, reff674_op in H. discriminate H. Qed.

Lemma reff674_not73 : ~ @Equation73 Fin5 reff674_inst.
Proof. unfold Equation73. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff674_inst, reff674_op in H. discriminate H. Qed.

Lemma reff674_not75 : ~ @Equation75 Fin5 reff674_inst.
Proof. unfold Equation75. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff674_inst, reff674_op in H. discriminate H. Qed.

Lemma reff674_not102 : ~ @Equation102 Fin5 reff674_inst.
Proof. unfold Equation102. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff674_inst, reff674_op in H. discriminate H. Qed.

Lemma reff674_not105 : ~ @Equation105 Fin5 reff674_inst.
Proof. unfold Equation105. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff674_inst, reff674_op in H. discriminate H. Qed.

Lemma reff674_not107 : ~ @Equation107 Fin5 reff674_inst.
Proof. unfold Equation107. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff674_inst, reff674_op in H. discriminate H. Qed.

Lemma reff674_not108 : ~ @Equation108 Fin5 reff674_inst.
Proof. unfold Equation108. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff674_inst, reff674_op in H. discriminate H. Qed.

Lemma reff674_not115 : ~ @Equation115 Fin5 reff674_inst.
Proof. unfold Equation115. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff674_inst, reff674_op in H. discriminate H. Qed.

Lemma reff674_not118 : ~ @Equation118 Fin5 reff674_inst.
Proof. unfold Equation118. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff674_inst, reff674_op in H. discriminate H. Qed.

Lemma reff674_not125 : ~ @Equation125 Fin5 reff674_inst.
Proof. unfold Equation125. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff674_inst, reff674_op in H. discriminate H. Qed.

Lemma reff674_not127 : ~ @Equation127 Fin5 reff674_inst.
Proof. unfold Equation127. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff674_inst, reff674_op in H. discriminate H. Qed.

Lemma reff674_not154 : ~ @Equation154 Fin5 reff674_inst.
Proof. unfold Equation154. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff674_inst, reff674_op in H. discriminate H. Qed.

Lemma reff674_not157 : ~ @Equation157 Fin5 reff674_inst.
Proof. unfold Equation157. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff674_inst, reff674_op in H. discriminate H. Qed.

Lemma reff674_not159 : ~ @Equation159 Fin5 reff674_inst.
Proof. unfold Equation159. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff674_inst, reff674_op in H. discriminate H. Qed.

Lemma reff674_not160 : ~ @Equation160 Fin5 reff674_inst.
Proof. unfold Equation160. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff674_inst, reff674_op in H. discriminate H. Qed.

Lemma reff674_not167 : ~ @Equation167 Fin5 reff674_inst.
Proof. unfold Equation167. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff674_inst, reff674_op in H. discriminate H. Qed.

Lemma reff674_not169 : ~ @Equation169 Fin5 reff674_inst.
Proof. unfold Equation169. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff674_inst, reff674_op in H. discriminate H. Qed.

Lemma reff674_not170 : ~ @Equation170 Fin5 reff674_inst.
Proof. unfold Equation170. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff674_inst, reff674_op in H. discriminate H. Qed.

Lemma reff674_not176 : ~ @Equation176 Fin5 reff674_inst.
Proof. unfold Equation176. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff674_inst, reff674_op in H. discriminate H. Qed.

Lemma reff674_not177 : ~ @Equation177 Fin5 reff674_inst.
Proof. unfold Equation177. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff674_inst, reff674_op in H. discriminate H. Qed.

Lemma reff674_not179 : ~ @Equation179 Fin5 reff674_inst.
Proof. unfold Equation179. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff674_inst, reff674_op in H. discriminate H. Qed.

Lemma reff674_not211 : ~ @Equation211 Fin5 reff674_inst.
Proof. unfold Equation211. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff674_inst, reff674_op in H. discriminate H. Qed.

Lemma reff674_not212 : ~ @Equation212 Fin5 reff674_inst.
Proof. unfold Equation212. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff674_inst, reff674_op in H. discriminate H. Qed.

Lemma reff674_not219 : ~ @Equation219 Fin5 reff674_inst.
Proof. unfold Equation219. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff674_inst, reff674_op in H. discriminate H. Qed.

Lemma reff674_not221 : ~ @Equation221 Fin5 reff674_inst.
Proof. unfold Equation221. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff674_inst, reff674_op in H. discriminate H. Qed.

Lemma reff674_not222 : ~ @Equation222 Fin5 reff674_inst.
Proof. unfold Equation222. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff674_inst, reff674_op in H. discriminate H. Qed.

Lemma reff674_not228 : ~ @Equation228 Fin5 reff674_inst.
Proof. unfold Equation228. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff674_inst, reff674_op in H. discriminate H. Qed.

Lemma reff674_not229 : ~ @Equation229 Fin5 reff674_inst.
Proof. unfold Equation229. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff674_inst, reff674_op in H. discriminate H. Qed.

Lemma reff674_not231 : ~ @Equation231 Fin5 reff674_inst.
Proof. unfold Equation231. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff674_inst, reff674_op in H. discriminate H. Qed.

Lemma reff674_not258 : ~ @Equation258 Fin5 reff674_inst.
Proof. unfold Equation258. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff674_inst, reff674_op in H. discriminate H. Qed.

Lemma reff674_not263 : ~ @Equation263 Fin5 reff674_inst.
Proof. unfold Equation263. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff674_inst, reff674_op in H. discriminate H. Qed.

Lemma reff674_not264 : ~ @Equation264 Fin5 reff674_inst.
Proof. unfold Equation264. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff674_inst, reff674_op in H. discriminate H. Qed.

Lemma reff674_not273 : ~ @Equation273 Fin5 reff674_inst.
Proof. unfold Equation273. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff674_inst, reff674_op in H. discriminate H. Qed.

Lemma reff674_not274 : ~ @Equation274 Fin5 reff674_inst.
Proof. unfold Equation274. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff674_inst, reff674_op in H. discriminate H. Qed.

Lemma reff674_not280 : ~ @Equation280 Fin5 reff674_inst.
Proof. unfold Equation280. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff674_inst, reff674_op in H. discriminate H. Qed.

Lemma reff674_not281 : ~ @Equation281 Fin5 reff674_inst.
Proof. unfold Equation281. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff674_inst, reff674_op in H. discriminate H. Qed.

Lemma reff674_not283 : ~ @Equation283 Fin5 reff674_inst.
Proof. unfold Equation283. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff674_inst, reff674_op in H. discriminate H. Qed.

Lemma reff674_not412 : ~ @Equation412 Fin5 reff674_inst.
Proof. unfold Equation412. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff674_inst, reff674_op in H. discriminate H. Qed.

Lemma reff674_not413 : ~ @Equation413 Fin5 reff674_inst.
Proof. unfold Equation413. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff674_inst, reff674_op in H. discriminate H. Qed.

Lemma reff674_not414 : ~ @Equation414 Fin5 reff674_inst.
Proof. unfold Equation414. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff674_inst, reff674_op in H. discriminate H. Qed.

Lemma reff674_not416 : ~ @Equation416 Fin5 reff674_inst.
Proof. unfold Equation416. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff674_inst, reff674_op in H. discriminate H. Qed.

Lemma reff674_not417 : ~ @Equation417 Fin5 reff674_inst.
Proof. unfold Equation417. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff674_inst, reff674_op in H. discriminate H. Qed.

Lemma reff674_not419 : ~ @Equation419 Fin5 reff674_inst.
Proof. unfold Equation419. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff674_inst, reff674_op in H. discriminate H. Qed.

Lemma reff674_not420 : ~ @Equation420 Fin5 reff674_inst.
Proof. unfold Equation420. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff674_inst, reff674_op in H. discriminate H. Qed.

Lemma reff674_not426 : ~ @Equation426 Fin5 reff674_inst.
Proof. unfold Equation426. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff674_inst, reff674_op in H. discriminate H. Qed.

Lemma reff674_not430 : ~ @Equation430 Fin5 reff674_inst.
Proof. unfold Equation430. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff674_inst, reff674_op in H. discriminate H. Qed.

Lemma reff674_not436 : ~ @Equation436 Fin5 reff674_inst.
Proof. unfold Equation436. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff674_inst, reff674_op in H. discriminate H. Qed.

Lemma reff674_not437 : ~ @Equation437 Fin5 reff674_inst.
Proof. unfold Equation437. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff674_inst, reff674_op in H. discriminate H. Qed.

Lemma reff674_not439 : ~ @Equation439 Fin5 reff674_inst.
Proof. unfold Equation439. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff674_inst, reff674_op in H. discriminate H. Qed.

Lemma reff674_not440 : ~ @Equation440 Fin5 reff674_inst.
Proof. unfold Equation440. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff674_inst, reff674_op in H. discriminate H. Qed.

Lemma reff674_not463 : ~ @Equation463 Fin5 reff674_inst.
Proof. unfold Equation463. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff674_inst, reff674_op in H. discriminate H. Qed.

Lemma reff674_not464 : ~ @Equation464 Fin5 reff674_inst.
Proof. unfold Equation464. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff674_inst, reff674_op in H. discriminate H. Qed.

Lemma reff674_not466 : ~ @Equation466 Fin5 reff674_inst.
Proof. unfold Equation466. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff674_inst, reff674_op in H. discriminate H. Qed.

Lemma reff674_not474 : ~ @Equation474 Fin5 reff674_inst.
Proof. unfold Equation474. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff674_inst, reff674_op in H. discriminate H. Qed.

Lemma reff674_not476 : ~ @Equation476 Fin5 reff674_inst.
Proof. unfold Equation476. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff674_inst, reff674_op in H. discriminate H. Qed.

Lemma reff674_not477 : ~ @Equation477 Fin5 reff674_inst.
Proof. unfold Equation477. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff674_inst, reff674_op in H. discriminate H. Qed.

Lemma reff674_not500 : ~ @Equation500 Fin5 reff674_inst.
Proof. unfold Equation500. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff674_inst, reff674_op in H. discriminate H. Qed.

Lemma reff674_not501 : ~ @Equation501 Fin5 reff674_inst.
Proof. unfold Equation501. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff674_inst, reff674_op in H. discriminate H. Qed.

Lemma reff674_not503 : ~ @Equation503 Fin5 reff674_inst.
Proof. unfold Equation503. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff674_inst, reff674_op in H. discriminate H. Qed.

Lemma reff674_not504 : ~ @Equation504 Fin5 reff674_inst.
Proof. unfold Equation504. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff674_inst, reff674_op in H. discriminate H. Qed.

Lemma reff674_not510 : ~ @Equation510 Fin5 reff674_inst.
Proof. unfold Equation510. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff674_inst, reff674_op in H. discriminate H. Qed.

Lemma reff674_not615 : ~ @Equation615 Fin5 reff674_inst.
Proof. unfold Equation615. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff674_inst, reff674_op in H. discriminate H. Qed.

Lemma reff674_not616 : ~ @Equation616 Fin5 reff674_inst.
Proof. unfold Equation616. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff674_inst, reff674_op in H. discriminate H. Qed.

Lemma reff674_not617 : ~ @Equation617 Fin5 reff674_inst.
Proof. unfold Equation617. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff674_inst, reff674_op in H. discriminate H. Qed.

Lemma reff674_not619 : ~ @Equation619 Fin5 reff674_inst.
Proof. unfold Equation619. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff674_inst, reff674_op in H. discriminate H. Qed.

Lemma reff674_not620 : ~ @Equation620 Fin5 reff674_inst.
Proof. unfold Equation620. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff674_inst, reff674_op in H. discriminate H. Qed.

Lemma reff674_not622 : ~ @Equation622 Fin5 reff674_inst.
Proof. unfold Equation622. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff674_inst, reff674_op in H. discriminate H. Qed.

Lemma reff674_not623 : ~ @Equation623 Fin5 reff674_inst.
Proof. unfold Equation623. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff674_inst, reff674_op in H. discriminate H. Qed.

Lemma reff674_not629 : ~ @Equation629 Fin5 reff674_inst.
Proof. unfold Equation629. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff674_inst, reff674_op in H. discriminate H. Qed.

Lemma reff674_not630 : ~ @Equation630 Fin5 reff674_inst.
Proof. unfold Equation630. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff674_inst, reff674_op in H. discriminate H. Qed.

Lemma reff674_not633 : ~ @Equation633 Fin5 reff674_inst.
Proof. unfold Equation633. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff674_inst, reff674_op in H. discriminate H. Qed.

Lemma reff674_not640 : ~ @Equation640 Fin5 reff674_inst.
Proof. unfold Equation640. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff674_inst, reff674_op in H. discriminate H. Qed.

Lemma reff674_not642 : ~ @Equation642 Fin5 reff674_inst.
Proof. unfold Equation642. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff674_inst, reff674_op in H. discriminate H. Qed.

Lemma reff674_not643 : ~ @Equation643 Fin5 reff674_inst.
Proof. unfold Equation643. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff674_inst, reff674_op in H. discriminate H. Qed.

Lemma reff674_not666 : ~ @Equation666 Fin5 reff674_inst.
Proof. unfold Equation666. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff674_inst, reff674_op in H. discriminate H. Qed.

Lemma reff674_not669 : ~ @Equation669 Fin5 reff674_inst.
Proof. unfold Equation669. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff674_inst, reff674_op in H. discriminate H. Qed.

Lemma reff674_not670 : ~ @Equation670 Fin5 reff674_inst.
Proof. unfold Equation670. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff674_inst, reff674_op in H. discriminate H. Qed.

Lemma reff674_not676 : ~ @Equation676 Fin5 reff674_inst.
Proof. unfold Equation676. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff674_inst, reff674_op in H. discriminate H. Qed.

Lemma reff674_not677 : ~ @Equation677 Fin5 reff674_inst.
Proof. unfold Equation677. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff674_inst, reff674_op in H. discriminate H. Qed.

Lemma reff674_not680 : ~ @Equation680 Fin5 reff674_inst.
Proof. unfold Equation680. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff674_inst, reff674_op in H. discriminate H. Qed.

Lemma reff674_not703 : ~ @Equation703 Fin5 reff674_inst.
Proof. unfold Equation703. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff674_inst, reff674_op in H. discriminate H. Qed.

Lemma reff674_not704 : ~ @Equation704 Fin5 reff674_inst.
Proof. unfold Equation704. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff674_inst, reff674_op in H. discriminate H. Qed.

Lemma reff674_not706 : ~ @Equation706 Fin5 reff674_inst.
Proof. unfold Equation706. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff674_inst, reff674_op in H. discriminate H. Qed.

Lemma reff674_not713 : ~ @Equation713 Fin5 reff674_inst.
Proof. unfold Equation713. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff674_inst, reff674_op in H. discriminate H. Qed.

Lemma reff674_not716 : ~ @Equation716 Fin5 reff674_inst.
Proof. unfold Equation716. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff674_inst, reff674_op in H. discriminate H. Qed.

Lemma reff674_not818 : ~ @Equation818 Fin5 reff674_inst.
Proof. unfold Equation818. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff674_inst, reff674_op in H. discriminate H. Qed.

Lemma reff674_not819 : ~ @Equation819 Fin5 reff674_inst.
Proof. unfold Equation819. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff674_inst, reff674_op in H. discriminate H. Qed.

Lemma reff674_not820 : ~ @Equation820 Fin5 reff674_inst.
Proof. unfold Equation820. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff674_inst, reff674_op in H. discriminate H. Qed.

Lemma reff674_not822 : ~ @Equation822 Fin5 reff674_inst.
Proof. unfold Equation822. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff674_inst, reff674_op in H. discriminate H. Qed.

Lemma reff674_not823 : ~ @Equation823 Fin5 reff674_inst.
Proof. unfold Equation823. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff674_inst, reff674_op in H. discriminate H. Qed.

Lemma reff674_not825 : ~ @Equation825 Fin5 reff674_inst.
Proof. unfold Equation825. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff674_inst, reff674_op in H. discriminate H. Qed.

Lemma reff674_not826 : ~ @Equation826 Fin5 reff674_inst.
Proof. unfold Equation826. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff674_inst, reff674_op in H. discriminate H. Qed.

Lemma reff674_not832 : ~ @Equation832 Fin5 reff674_inst.
Proof. unfold Equation832. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff674_inst, reff674_op in H. discriminate H. Qed.

Lemma reff674_not833 : ~ @Equation833 Fin5 reff674_inst.
Proof. unfold Equation833. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff674_inst, reff674_op in H. discriminate H. Qed.

Lemma reff674_not835 : ~ @Equation835 Fin5 reff674_inst.
Proof. unfold Equation835. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff674_inst, reff674_op in H. discriminate H. Qed.

Lemma reff674_not836 : ~ @Equation836 Fin5 reff674_inst.
Proof. unfold Equation836. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff674_inst, reff674_op in H. discriminate H. Qed.

Lemma reff674_not842 : ~ @Equation842 Fin5 reff674_inst.
Proof. unfold Equation842. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff674_inst, reff674_op in H. discriminate H. Qed.

Lemma reff674_not843 : ~ @Equation843 Fin5 reff674_inst.
Proof. unfold Equation843. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff674_inst, reff674_op in H. discriminate H. Qed.

Lemma reff674_not845 : ~ @Equation845 Fin5 reff674_inst.
Proof. unfold Equation845. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff674_inst, reff674_op in H. discriminate H. Qed.

Lemma reff674_not846 : ~ @Equation846 Fin5 reff674_inst.
Proof. unfold Equation846. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff674_inst, reff674_op in H. discriminate H. Qed.

Lemma reff674_not869 : ~ @Equation869 Fin5 reff674_inst.
Proof. unfold Equation869. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff674_inst, reff674_op in H. discriminate H. Qed.

Lemma reff674_not873 : ~ @Equation873 Fin5 reff674_inst.
Proof. unfold Equation873. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff674_inst, reff674_op in H. discriminate H. Qed.

Lemma reff674_not880 : ~ @Equation880 Fin5 reff674_inst.
Proof. unfold Equation880. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff674_inst, reff674_op in H. discriminate H. Qed.

Lemma reff674_not882 : ~ @Equation882 Fin5 reff674_inst.
Proof. unfold Equation882. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff674_inst, reff674_op in H. discriminate H. Qed.

Lemma reff674_not883 : ~ @Equation883 Fin5 reff674_inst.
Proof. unfold Equation883. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff674_inst, reff674_op in H. discriminate H. Qed.

Lemma reff674_not907 : ~ @Equation907 Fin5 reff674_inst.
Proof. unfold Equation907. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff674_inst, reff674_op in H. discriminate H. Qed.

Lemma reff674_not909 : ~ @Equation909 Fin5 reff674_inst.
Proof. unfold Equation909. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff674_inst, reff674_op in H. discriminate H. Qed.

Lemma reff674_not910 : ~ @Equation910 Fin5 reff674_inst.
Proof. unfold Equation910. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff674_inst, reff674_op in H. discriminate H. Qed.

Lemma reff674_not916 : ~ @Equation916 Fin5 reff674_inst.
Proof. unfold Equation916. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff674_inst, reff674_op in H. discriminate H. Qed.

Lemma reff674_not917 : ~ @Equation917 Fin5 reff674_inst.
Proof. unfold Equation917. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff674_inst, reff674_op in H. discriminate H. Qed.

Lemma reff674_not919 : ~ @Equation919 Fin5 reff674_inst.
Proof. unfold Equation919. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff674_inst, reff674_op in H. discriminate H. Qed.

Lemma reff674_not1021 : ~ @Equation1021 Fin5 reff674_inst.
Proof. unfold Equation1021. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff674_inst, reff674_op in H. discriminate H. Qed.

Lemma reff674_not1022 : ~ @Equation1022 Fin5 reff674_inst.
Proof. unfold Equation1022. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff674_inst, reff674_op in H. discriminate H. Qed.

Lemma reff674_not1025 : ~ @Equation1025 Fin5 reff674_inst.
Proof. unfold Equation1025. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff674_inst, reff674_op in H. discriminate H. Qed.

Lemma reff674_not1028 : ~ @Equation1028 Fin5 reff674_inst.
Proof. unfold Equation1028. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff674_inst, reff674_op in H. discriminate H. Qed.

Lemma reff674_not1029 : ~ @Equation1029 Fin5 reff674_inst.
Proof. unfold Equation1029. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff674_inst, reff674_op in H. discriminate H. Qed.

Lemma reff674_not1035 : ~ @Equation1035 Fin5 reff674_inst.
Proof. unfold Equation1035. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff674_inst, reff674_op in H. discriminate H. Qed.

Lemma reff674_not1036 : ~ @Equation1036 Fin5 reff674_inst.
Proof. unfold Equation1036. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff674_inst, reff674_op in H. discriminate H. Qed.

Lemma reff674_not1038 : ~ @Equation1038 Fin5 reff674_inst.
Proof. unfold Equation1038. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff674_inst, reff674_op in H. discriminate H. Qed.

Lemma reff674_not1039 : ~ @Equation1039 Fin5 reff674_inst.
Proof. unfold Equation1039. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff674_inst, reff674_op in H. discriminate H. Qed.

Lemma reff674_not1045 : ~ @Equation1045 Fin5 reff674_inst.
Proof. unfold Equation1045. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff674_inst, reff674_op in H. discriminate H. Qed.

Lemma reff674_not1046 : ~ @Equation1046 Fin5 reff674_inst.
Proof. unfold Equation1046. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff674_inst, reff674_op in H. discriminate H. Qed.

Lemma reff674_not1048 : ~ @Equation1048 Fin5 reff674_inst.
Proof. unfold Equation1048. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff674_inst, reff674_op in H. discriminate H. Qed.

Lemma reff674_not1049 : ~ @Equation1049 Fin5 reff674_inst.
Proof. unfold Equation1049. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff674_inst, reff674_op in H. discriminate H. Qed.

Lemma reff674_not1072 : ~ @Equation1072 Fin5 reff674_inst.
Proof. unfold Equation1072. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff674_inst, reff674_op in H. discriminate H. Qed.

Lemma reff674_not1073 : ~ @Equation1073 Fin5 reff674_inst.
Proof. unfold Equation1073. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff674_inst, reff674_op in H. discriminate H. Qed.

Lemma reff674_not1075 : ~ @Equation1075 Fin5 reff674_inst.
Proof. unfold Equation1075. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff674_inst, reff674_op in H. discriminate H. Qed.

Lemma reff674_not1076 : ~ @Equation1076 Fin5 reff674_inst.
Proof. unfold Equation1076. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff674_inst, reff674_op in H. discriminate H. Qed.

Lemma reff674_not1082 : ~ @Equation1082 Fin5 reff674_inst.
Proof. unfold Equation1082. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff674_inst, reff674_op in H. discriminate H. Qed.

Lemma reff674_not1083 : ~ @Equation1083 Fin5 reff674_inst.
Proof. unfold Equation1083. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff674_inst, reff674_op in H. discriminate H. Qed.

Lemma reff674_not1086 : ~ @Equation1086 Fin5 reff674_inst.
Proof. unfold Equation1086. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff674_inst, reff674_op in H. discriminate H. Qed.

Lemma reff674_not1110 : ~ @Equation1110 Fin5 reff674_inst.
Proof. unfold Equation1110. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff674_inst, reff674_op in H. discriminate H. Qed.

Lemma reff674_not1112 : ~ @Equation1112 Fin5 reff674_inst.
Proof. unfold Equation1112. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff674_inst, reff674_op in H. discriminate H. Qed.

Lemma reff674_not1119 : ~ @Equation1119 Fin5 reff674_inst.
Proof. unfold Equation1119. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff674_inst, reff674_op in H. discriminate H. Qed.

Lemma reff674_not1122 : ~ @Equation1122 Fin5 reff674_inst.
Proof. unfold Equation1122. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff674_inst, reff674_op in H. discriminate H. Qed.

Lemma reff674_not1224 : ~ @Equation1224 Fin5 reff674_inst.
Proof. unfold Equation1224. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff674_inst, reff674_op in H. discriminate H. Qed.

Lemma reff674_not1225 : ~ @Equation1225 Fin5 reff674_inst.
Proof. unfold Equation1225. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff674_inst, reff674_op in H. discriminate H. Qed.

Lemma reff674_not1226 : ~ @Equation1226 Fin5 reff674_inst.
Proof. unfold Equation1226. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff674_inst, reff674_op in H. discriminate H. Qed.

Lemma reff674_not1228 : ~ @Equation1228 Fin5 reff674_inst.
Proof. unfold Equation1228. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff674_inst, reff674_op in H. discriminate H. Qed.

Lemma reff674_not1231 : ~ @Equation1231 Fin5 reff674_inst.
Proof. unfold Equation1231. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff674_inst, reff674_op in H. discriminate H. Qed.

Lemma reff674_not1232 : ~ @Equation1232 Fin5 reff674_inst.
Proof. unfold Equation1232. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff674_inst, reff674_op in H. discriminate H. Qed.

Lemma reff674_not1238 : ~ @Equation1238 Fin5 reff674_inst.
Proof. unfold Equation1238. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff674_inst, reff674_op in H. discriminate H. Qed.

Lemma reff674_not1241 : ~ @Equation1241 Fin5 reff674_inst.
Proof. unfold Equation1241. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff674_inst, reff674_op in H. discriminate H. Qed.

Lemma reff674_not1242 : ~ @Equation1242 Fin5 reff674_inst.
Proof. unfold Equation1242. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff674_inst, reff674_op in H. discriminate H. Qed.

Lemma reff674_not1248 : ~ @Equation1248 Fin5 reff674_inst.
Proof. unfold Equation1248. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff674_inst, reff674_op in H. discriminate H. Qed.

Lemma reff674_not1249 : ~ @Equation1249 Fin5 reff674_inst.
Proof. unfold Equation1249. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff674_inst, reff674_op in H. discriminate H. Qed.

Lemma reff674_not1251 : ~ @Equation1251 Fin5 reff674_inst.
Proof. unfold Equation1251. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff674_inst, reff674_op in H. discriminate H. Qed.

Lemma reff674_not1252 : ~ @Equation1252 Fin5 reff674_inst.
Proof. unfold Equation1252. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff674_inst, reff674_op in H. discriminate H. Qed.

Lemma reff674_not1275 : ~ @Equation1275 Fin5 reff674_inst.
Proof. unfold Equation1275. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff674_inst, reff674_op in H. discriminate H. Qed.

Lemma reff674_not1276 : ~ @Equation1276 Fin5 reff674_inst.
Proof. unfold Equation1276. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff674_inst, reff674_op in H. discriminate H. Qed.

Lemma reff674_not1279 : ~ @Equation1279 Fin5 reff674_inst.
Proof. unfold Equation1279. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff674_inst, reff674_op in H. discriminate H. Qed.

Lemma reff674_not1285 : ~ @Equation1285 Fin5 reff674_inst.
Proof. unfold Equation1285. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff674_inst, reff674_op in H. discriminate H. Qed.

Lemma reff674_not1286 : ~ @Equation1286 Fin5 reff674_inst.
Proof. unfold Equation1286. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff674_inst, reff674_op in H. discriminate H. Qed.

Lemma reff674_not1288 : ~ @Equation1288 Fin5 reff674_inst.
Proof. unfold Equation1288. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff674_inst, reff674_op in H. discriminate H. Qed.

Lemma reff674_not1312 : ~ @Equation1312 Fin5 reff674_inst.
Proof. unfold Equation1312. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff674_inst, reff674_op in H. discriminate H. Qed.

Lemma reff674_not1313 : ~ @Equation1313 Fin5 reff674_inst.
Proof. unfold Equation1313. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff674_inst, reff674_op in H. discriminate H. Qed.

Lemma reff674_not1315 : ~ @Equation1315 Fin5 reff674_inst.
Proof. unfold Equation1315. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff674_inst, reff674_op in H. discriminate H. Qed.

Lemma reff674_not1323 : ~ @Equation1323 Fin5 reff674_inst.
Proof. unfold Equation1323. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff674_inst, reff674_op in H. discriminate H. Qed.

Lemma reff674_not1325 : ~ @Equation1325 Fin5 reff674_inst.
Proof. unfold Equation1325. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff674_inst, reff674_op in H. discriminate H. Qed.

Lemma reff674_not1427 : ~ @Equation1427 Fin5 reff674_inst.
Proof. unfold Equation1427. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff674_inst, reff674_op in H. discriminate H. Qed.

Lemma reff674_not1428 : ~ @Equation1428 Fin5 reff674_inst.
Proof. unfold Equation1428. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff674_inst, reff674_op in H. discriminate H. Qed.

Lemma reff674_not1429 : ~ @Equation1429 Fin5 reff674_inst.
Proof. unfold Equation1429. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff674_inst, reff674_op in H. discriminate H. Qed.

Lemma reff674_not1431 : ~ @Equation1431 Fin5 reff674_inst.
Proof. unfold Equation1431. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff674_inst, reff674_op in H. discriminate H. Qed.

Lemma reff674_not1432 : ~ @Equation1432 Fin5 reff674_inst.
Proof. unfold Equation1432. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff674_inst, reff674_op in H. discriminate H. Qed.

Lemma reff674_not1434 : ~ @Equation1434 Fin5 reff674_inst.
Proof. unfold Equation1434. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff674_inst, reff674_op in H. discriminate H. Qed.

Lemma reff674_not1435 : ~ @Equation1435 Fin5 reff674_inst.
Proof. unfold Equation1435. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff674_inst, reff674_op in H. discriminate H. Qed.

Lemma reff674_not1441 : ~ @Equation1441 Fin5 reff674_inst.
Proof. unfold Equation1441. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff674_inst, reff674_op in H. discriminate H. Qed.

Lemma reff674_not1442 : ~ @Equation1442 Fin5 reff674_inst.
Proof. unfold Equation1442. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff674_inst, reff674_op in H. discriminate H. Qed.

Lemma reff674_not1444 : ~ @Equation1444 Fin5 reff674_inst.
Proof. unfold Equation1444. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff674_inst, reff674_op in H. discriminate H. Qed.

Lemma reff674_not1445 : ~ @Equation1445 Fin5 reff674_inst.
Proof. unfold Equation1445. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff674_inst, reff674_op in H. discriminate H. Qed.

Lemma reff674_not1451 : ~ @Equation1451 Fin5 reff674_inst.
Proof. unfold Equation1451. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff674_inst, reff674_op in H. discriminate H. Qed.

Lemma reff674_not1455 : ~ @Equation1455 Fin5 reff674_inst.
Proof. unfold Equation1455. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff674_inst, reff674_op in H. discriminate H. Qed.

Lemma reff674_not1478 : ~ @Equation1478 Fin5 reff674_inst.
Proof. unfold Equation1478. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff674_inst, reff674_op in H. discriminate H. Qed.

Lemma reff674_not1479 : ~ @Equation1479 Fin5 reff674_inst.
Proof. unfold Equation1479. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff674_inst, reff674_op in H. discriminate H. Qed.

Lemma reff674_not1481 : ~ @Equation1481 Fin5 reff674_inst.
Proof. unfold Equation1481. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff674_inst, reff674_op in H. discriminate H. Qed.

Lemma reff674_not1482 : ~ @Equation1482 Fin5 reff674_inst.
Proof. unfold Equation1482. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff674_inst, reff674_op in H. discriminate H. Qed.

Lemma reff674_not1488 : ~ @Equation1488 Fin5 reff674_inst.
Proof. unfold Equation1488. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff674_inst, reff674_op in H. discriminate H. Qed.

Lemma reff674_not1492 : ~ @Equation1492 Fin5 reff674_inst.
Proof. unfold Equation1492. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff674_inst, reff674_op in H. discriminate H. Qed.

Lemma reff674_not1515 : ~ @Equation1515 Fin5 reff674_inst.
Proof. unfold Equation1515. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff674_inst, reff674_op in H. discriminate H. Qed.

Lemma reff674_not1519 : ~ @Equation1519 Fin5 reff674_inst.
Proof. unfold Equation1519. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff674_inst, reff674_op in H. discriminate H. Qed.

Lemma reff674_not1525 : ~ @Equation1525 Fin5 reff674_inst.
Proof. unfold Equation1525. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff674_inst, reff674_op in H. discriminate H. Qed.

Lemma reff674_not1526 : ~ @Equation1526 Fin5 reff674_inst.
Proof. unfold Equation1526. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff674_inst, reff674_op in H. discriminate H. Qed.

Lemma reff674_not1528 : ~ @Equation1528 Fin5 reff674_inst.
Proof. unfold Equation1528. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff674_inst, reff674_op in H. discriminate H. Qed.

Lemma reff674_not1630 : ~ @Equation1630 Fin5 reff674_inst.
Proof. unfold Equation1630. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff674_inst, reff674_op in H. discriminate H. Qed.

Lemma reff674_not1631 : ~ @Equation1631 Fin5 reff674_inst.
Proof. unfold Equation1631. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff674_inst, reff674_op in H. discriminate H. Qed.

Lemma reff674_not1632 : ~ @Equation1632 Fin5 reff674_inst.
Proof. unfold Equation1632. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff674_inst, reff674_op in H. discriminate H. Qed.

Lemma reff674_not1634 : ~ @Equation1634 Fin5 reff674_inst.
Proof. unfold Equation1634. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff674_inst, reff674_op in H. discriminate H. Qed.

Lemma reff674_not1635 : ~ @Equation1635 Fin5 reff674_inst.
Proof. unfold Equation1635. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff674_inst, reff674_op in H. discriminate H. Qed.

Lemma reff674_not1637 : ~ @Equation1637 Fin5 reff674_inst.
Proof. unfold Equation1637. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff674_inst, reff674_op in H. discriminate H. Qed.

Lemma reff674_not1638 : ~ @Equation1638 Fin5 reff674_inst.
Proof. unfold Equation1638. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff674_inst, reff674_op in H. discriminate H. Qed.

Lemma reff674_not1644 : ~ @Equation1644 Fin5 reff674_inst.
Proof. unfold Equation1644. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff674_inst, reff674_op in H. discriminate H. Qed.

Lemma reff674_not1645 : ~ @Equation1645 Fin5 reff674_inst.
Proof. unfold Equation1645. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff674_inst, reff674_op in H. discriminate H. Qed.

Lemma reff674_not1647 : ~ @Equation1647 Fin5 reff674_inst.
Proof. unfold Equation1647. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff674_inst, reff674_op in H. discriminate H. Qed.

Lemma reff674_not1654 : ~ @Equation1654 Fin5 reff674_inst.
Proof. unfold Equation1654. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff674_inst, reff674_op in H. discriminate H. Qed.

Lemma reff674_not1657 : ~ @Equation1657 Fin5 reff674_inst.
Proof. unfold Equation1657. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff674_inst, reff674_op in H. discriminate H. Qed.

Lemma reff674_not1658 : ~ @Equation1658 Fin5 reff674_inst.
Proof. unfold Equation1658. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff674_inst, reff674_op in H. discriminate H. Qed.

Lemma reff674_not1681 : ~ @Equation1681 Fin5 reff674_inst.
Proof. unfold Equation1681. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff674_inst, reff674_op in H. discriminate H. Qed.

Lemma reff674_not1682 : ~ @Equation1682 Fin5 reff674_inst.
Proof. unfold Equation1682. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff674_inst, reff674_op in H. discriminate H. Qed.

Lemma reff674_not1684 : ~ @Equation1684 Fin5 reff674_inst.
Proof. unfold Equation1684. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff674_inst, reff674_op in H. discriminate H. Qed.

Lemma reff674_not1691 : ~ @Equation1691 Fin5 reff674_inst.
Proof. unfold Equation1691. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff674_inst, reff674_op in H. discriminate H. Qed.

Lemma reff674_not1694 : ~ @Equation1694 Fin5 reff674_inst.
Proof. unfold Equation1694. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff674_inst, reff674_op in H. discriminate H. Qed.

Lemma reff674_not1695 : ~ @Equation1695 Fin5 reff674_inst.
Proof. unfold Equation1695. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff674_inst, reff674_op in H. discriminate H. Qed.

Lemma reff674_not1718 : ~ @Equation1718 Fin5 reff674_inst.
Proof. unfold Equation1718. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff674_inst, reff674_op in H. discriminate H. Qed.

Lemma reff674_not1719 : ~ @Equation1719 Fin5 reff674_inst.
Proof. unfold Equation1719. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff674_inst, reff674_op in H. discriminate H. Qed.

Lemma reff674_not1722 : ~ @Equation1722 Fin5 reff674_inst.
Proof. unfold Equation1722. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff674_inst, reff674_op in H. discriminate H. Qed.

Lemma reff674_not1729 : ~ @Equation1729 Fin5 reff674_inst.
Proof. unfold Equation1729. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff674_inst, reff674_op in H. discriminate H. Qed.

Lemma reff674_not1731 : ~ @Equation1731 Fin5 reff674_inst.
Proof. unfold Equation1731. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff674_inst, reff674_op in H. discriminate H. Qed.

Lemma reff674_not1833 : ~ @Equation1833 Fin5 reff674_inst.
Proof. unfold Equation1833. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff674_inst, reff674_op in H. discriminate H. Qed.

Lemma reff674_not1834 : ~ @Equation1834 Fin5 reff674_inst.
Proof. unfold Equation1834. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff674_inst, reff674_op in H. discriminate H. Qed.

Lemma reff674_not1835 : ~ @Equation1835 Fin5 reff674_inst.
Proof. unfold Equation1835. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff674_inst, reff674_op in H. discriminate H. Qed.

Lemma reff674_not1837 : ~ @Equation1837 Fin5 reff674_inst.
Proof. unfold Equation1837. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff674_inst, reff674_op in H. discriminate H. Qed.

Lemma reff674_not1838 : ~ @Equation1838 Fin5 reff674_inst.
Proof. unfold Equation1838. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff674_inst, reff674_op in H. discriminate H. Qed.

Lemma reff674_not1840 : ~ @Equation1840 Fin5 reff674_inst.
Proof. unfold Equation1840. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff674_inst, reff674_op in H. discriminate H. Qed.

Lemma reff674_not1847 : ~ @Equation1847 Fin5 reff674_inst.
Proof. unfold Equation1847. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff674_inst, reff674_op in H. discriminate H. Qed.

Lemma reff674_not1848 : ~ @Equation1848 Fin5 reff674_inst.
Proof. unfold Equation1848. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff674_inst, reff674_op in H. discriminate H. Qed.

Lemma reff674_not1850 : ~ @Equation1850 Fin5 reff674_inst.
Proof. unfold Equation1850. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff674_inst, reff674_op in H. discriminate H. Qed.

Lemma reff674_not1857 : ~ @Equation1857 Fin5 reff674_inst.
Proof. unfold Equation1857. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff674_inst, reff674_op in H. discriminate H. Qed.

Lemma reff674_not1858 : ~ @Equation1858 Fin5 reff674_inst.
Proof. unfold Equation1858. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff674_inst, reff674_op in H. discriminate H. Qed.

Lemma reff674_not1860 : ~ @Equation1860 Fin5 reff674_inst.
Proof. unfold Equation1860. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff674_inst, reff674_op in H. discriminate H. Qed.

Lemma reff674_not1861 : ~ @Equation1861 Fin5 reff674_inst.
Proof. unfold Equation1861. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff674_inst, reff674_op in H. discriminate H. Qed.

Lemma reff674_not1884 : ~ @Equation1884 Fin5 reff674_inst.
Proof. unfold Equation1884. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff674_inst, reff674_op in H. discriminate H. Qed.

Lemma reff674_not1885 : ~ @Equation1885 Fin5 reff674_inst.
Proof. unfold Equation1885. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff674_inst, reff674_op in H. discriminate H. Qed.

Lemma reff674_not1887 : ~ @Equation1887 Fin5 reff674_inst.
Proof. unfold Equation1887. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff674_inst, reff674_op in H. discriminate H. Qed.

Lemma reff674_not1888 : ~ @Equation1888 Fin5 reff674_inst.
Proof. unfold Equation1888. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff674_inst, reff674_op in H. discriminate H. Qed.

Lemma reff674_not1894 : ~ @Equation1894 Fin5 reff674_inst.
Proof. unfold Equation1894. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff674_inst, reff674_op in H. discriminate H. Qed.

Lemma reff674_not1898 : ~ @Equation1898 Fin5 reff674_inst.
Proof. unfold Equation1898. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff674_inst, reff674_op in H. discriminate H. Qed.

Lemma reff674_not1921 : ~ @Equation1921 Fin5 reff674_inst.
Proof. unfold Equation1921. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff674_inst, reff674_op in H. discriminate H. Qed.

Lemma reff674_not1925 : ~ @Equation1925 Fin5 reff674_inst.
Proof. unfold Equation1925. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff674_inst, reff674_op in H. discriminate H. Qed.

Lemma reff674_not1931 : ~ @Equation1931 Fin5 reff674_inst.
Proof. unfold Equation1931. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff674_inst, reff674_op in H. discriminate H. Qed.

Lemma reff674_not1932 : ~ @Equation1932 Fin5 reff674_inst.
Proof. unfold Equation1932. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff674_inst, reff674_op in H. discriminate H. Qed.

Lemma reff674_not1934 : ~ @Equation1934 Fin5 reff674_inst.
Proof. unfold Equation1934. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff674_inst, reff674_op in H. discriminate H. Qed.

Lemma reff674_not2036 : ~ @Equation2036 Fin5 reff674_inst.
Proof. unfold Equation2036. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff674_inst, reff674_op in H. discriminate H. Qed.

Lemma reff674_not2037 : ~ @Equation2037 Fin5 reff674_inst.
Proof. unfold Equation2037. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff674_inst, reff674_op in H. discriminate H. Qed.

Lemma reff674_not2038 : ~ @Equation2038 Fin5 reff674_inst.
Proof. unfold Equation2038. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff674_inst, reff674_op in H. discriminate H. Qed.

Lemma reff674_not2040 : ~ @Equation2040 Fin5 reff674_inst.
Proof. unfold Equation2040. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff674_inst, reff674_op in H. discriminate H. Qed.

Lemma reff674_not2041 : ~ @Equation2041 Fin5 reff674_inst.
Proof. unfold Equation2041. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff674_inst, reff674_op in H. discriminate H. Qed.

Lemma reff674_not2043 : ~ @Equation2043 Fin5 reff674_inst.
Proof. unfold Equation2043. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff674_inst, reff674_op in H. discriminate H. Qed.

Lemma reff674_not2044 : ~ @Equation2044 Fin5 reff674_inst.
Proof. unfold Equation2044. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff674_inst, reff674_op in H. discriminate H. Qed.

Lemma reff674_not2050 : ~ @Equation2050 Fin5 reff674_inst.
Proof. unfold Equation2050. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff674_inst, reff674_op in H. discriminate H. Qed.

Lemma reff674_not2051 : ~ @Equation2051 Fin5 reff674_inst.
Proof. unfold Equation2051. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff674_inst, reff674_op in H. discriminate H. Qed.

Lemma reff674_not2053 : ~ @Equation2053 Fin5 reff674_inst.
Proof. unfold Equation2053. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff674_inst, reff674_op in H. discriminate H. Qed.

Lemma reff674_not2060 : ~ @Equation2060 Fin5 reff674_inst.
Proof. unfold Equation2060. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff674_inst, reff674_op in H. discriminate H. Qed.

Lemma reff674_not2064 : ~ @Equation2064 Fin5 reff674_inst.
Proof. unfold Equation2064. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff674_inst, reff674_op in H. discriminate H. Qed.

Lemma reff674_not2087 : ~ @Equation2087 Fin5 reff674_inst.
Proof. unfold Equation2087. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff674_inst, reff674_op in H. discriminate H. Qed.

Lemma reff674_not2088 : ~ @Equation2088 Fin5 reff674_inst.
Proof. unfold Equation2088. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff674_inst, reff674_op in H. discriminate H. Qed.

Lemma reff674_not2090 : ~ @Equation2090 Fin5 reff674_inst.
Proof. unfold Equation2090. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff674_inst, reff674_op in H. discriminate H. Qed.

Lemma reff674_not2097 : ~ @Equation2097 Fin5 reff674_inst.
Proof. unfold Equation2097. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff674_inst, reff674_op in H. discriminate H. Qed.

Lemma reff674_not2101 : ~ @Equation2101 Fin5 reff674_inst.
Proof. unfold Equation2101. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff674_inst, reff674_op in H. discriminate H. Qed.

Lemma reff674_not2124 : ~ @Equation2124 Fin5 reff674_inst.
Proof. unfold Equation2124. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff674_inst, reff674_op in H. discriminate H. Qed.

Lemma reff674_not2125 : ~ @Equation2125 Fin5 reff674_inst.
Proof. unfold Equation2125. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff674_inst, reff674_op in H. discriminate H. Qed.

Lemma reff674_not2127 : ~ @Equation2127 Fin5 reff674_inst.
Proof. unfold Equation2127. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff674_inst, reff674_op in H. discriminate H. Qed.

Lemma reff674_not2128 : ~ @Equation2128 Fin5 reff674_inst.
Proof. unfold Equation2128. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff674_inst, reff674_op in H. discriminate H. Qed.

Lemma reff674_not2134 : ~ @Equation2134 Fin5 reff674_inst.
Proof. unfold Equation2134. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff674_inst, reff674_op in H. discriminate H. Qed.

Lemma reff674_not2135 : ~ @Equation2135 Fin5 reff674_inst.
Proof. unfold Equation2135. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff674_inst, reff674_op in H. discriminate H. Qed.

Lemma reff674_not2137 : ~ @Equation2137 Fin5 reff674_inst.
Proof. unfold Equation2137. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff674_inst, reff674_op in H. discriminate H. Qed.

Lemma reff674_not2239 : ~ @Equation2239 Fin5 reff674_inst.
Proof. unfold Equation2239. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff674_inst, reff674_op in H. discriminate H. Qed.

Lemma reff674_not2240 : ~ @Equation2240 Fin5 reff674_inst.
Proof. unfold Equation2240. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff674_inst, reff674_op in H. discriminate H. Qed.

Lemma reff674_not2241 : ~ @Equation2241 Fin5 reff674_inst.
Proof. unfold Equation2241. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff674_inst, reff674_op in H. discriminate H. Qed.

Lemma reff674_not2243 : ~ @Equation2243 Fin5 reff674_inst.
Proof. unfold Equation2243. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff674_inst, reff674_op in H. discriminate H. Qed.

Lemma reff674_not2244 : ~ @Equation2244 Fin5 reff674_inst.
Proof. unfold Equation2244. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff674_inst, reff674_op in H. discriminate H. Qed.

Lemma reff674_not2246 : ~ @Equation2246 Fin5 reff674_inst.
Proof. unfold Equation2246. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff674_inst, reff674_op in H. discriminate H. Qed.

Lemma reff674_not2253 : ~ @Equation2253 Fin5 reff674_inst.
Proof. unfold Equation2253. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff674_inst, reff674_op in H. discriminate H. Qed.

Lemma reff674_not2256 : ~ @Equation2256 Fin5 reff674_inst.
Proof. unfold Equation2256. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff674_inst, reff674_op in H. discriminate H. Qed.

Lemma reff674_not2257 : ~ @Equation2257 Fin5 reff674_inst.
Proof. unfold Equation2257. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff674_inst, reff674_op in H. discriminate H. Qed.

Lemma reff674_not2263 : ~ @Equation2263 Fin5 reff674_inst.
Proof. unfold Equation2263. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff674_inst, reff674_op in H. discriminate H. Qed.

Lemma reff674_not2264 : ~ @Equation2264 Fin5 reff674_inst.
Proof. unfold Equation2264. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff674_inst, reff674_op in H. discriminate H. Qed.

Lemma reff674_not2266 : ~ @Equation2266 Fin5 reff674_inst.
Proof. unfold Equation2266. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff674_inst, reff674_op in H. discriminate H. Qed.

Lemma reff674_not2267 : ~ @Equation2267 Fin5 reff674_inst.
Proof. unfold Equation2267. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff674_inst, reff674_op in H. discriminate H. Qed.

Lemma reff674_not2290 : ~ @Equation2290 Fin5 reff674_inst.
Proof. unfold Equation2290. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff674_inst, reff674_op in H. discriminate H. Qed.

Lemma reff674_not2291 : ~ @Equation2291 Fin5 reff674_inst.
Proof. unfold Equation2291. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff674_inst, reff674_op in H. discriminate H. Qed.

Lemma reff674_not2294 : ~ @Equation2294 Fin5 reff674_inst.
Proof. unfold Equation2294. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff674_inst, reff674_op in H. discriminate H. Qed.

Lemma reff674_not2301 : ~ @Equation2301 Fin5 reff674_inst.
Proof. unfold Equation2301. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff674_inst, reff674_op in H. discriminate H. Qed.

Lemma reff674_not2303 : ~ @Equation2303 Fin5 reff674_inst.
Proof. unfold Equation2303. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff674_inst, reff674_op in H. discriminate H. Qed.

Lemma reff674_not2304 : ~ @Equation2304 Fin5 reff674_inst.
Proof. unfold Equation2304. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff674_inst, reff674_op in H. discriminate H. Qed.

Lemma reff674_not2327 : ~ @Equation2327 Fin5 reff674_inst.
Proof. unfold Equation2327. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff674_inst, reff674_op in H. discriminate H. Qed.

Lemma reff674_not2328 : ~ @Equation2328 Fin5 reff674_inst.
Proof. unfold Equation2328. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff674_inst, reff674_op in H. discriminate H. Qed.

Lemma reff674_not2330 : ~ @Equation2330 Fin5 reff674_inst.
Proof. unfold Equation2330. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff674_inst, reff674_op in H. discriminate H. Qed.

Lemma reff674_not2337 : ~ @Equation2337 Fin5 reff674_inst.
Proof. unfold Equation2337. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff674_inst, reff674_op in H. discriminate H. Qed.

Lemma reff674_not2340 : ~ @Equation2340 Fin5 reff674_inst.
Proof. unfold Equation2340. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff674_inst, reff674_op in H. discriminate H. Qed.

Lemma reff674_not2442 : ~ @Equation2442 Fin5 reff674_inst.
Proof. unfold Equation2442. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff674_inst, reff674_op in H. discriminate H. Qed.

Lemma reff674_not2443 : ~ @Equation2443 Fin5 reff674_inst.
Proof. unfold Equation2443. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff674_inst, reff674_op in H. discriminate H. Qed.

Lemma reff674_not2446 : ~ @Equation2446 Fin5 reff674_inst.
Proof. unfold Equation2446. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff674_inst, reff674_op in H. discriminate H. Qed.

Lemma reff674_not2447 : ~ @Equation2447 Fin5 reff674_inst.
Proof. unfold Equation2447. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff674_inst, reff674_op in H. discriminate H. Qed.

Lemma reff674_not2449 : ~ @Equation2449 Fin5 reff674_inst.
Proof. unfold Equation2449. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff674_inst, reff674_op in H. discriminate H. Qed.

Lemma reff674_not2450 : ~ @Equation2450 Fin5 reff674_inst.
Proof. unfold Equation2450. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff674_inst, reff674_op in H. discriminate H. Qed.

Lemma reff674_not2456 : ~ @Equation2456 Fin5 reff674_inst.
Proof. unfold Equation2456. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff674_inst, reff674_op in H. discriminate H. Qed.

Lemma reff674_not2457 : ~ @Equation2457 Fin5 reff674_inst.
Proof. unfold Equation2457. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff674_inst, reff674_op in H. discriminate H. Qed.

Lemma reff674_not2459 : ~ @Equation2459 Fin5 reff674_inst.
Proof. unfold Equation2459. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff674_inst, reff674_op in H. discriminate H. Qed.

Lemma reff674_not2460 : ~ @Equation2460 Fin5 reff674_inst.
Proof. unfold Equation2460. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff674_inst, reff674_op in H. discriminate H. Qed.

Lemma reff674_not2466 : ~ @Equation2466 Fin5 reff674_inst.
Proof. unfold Equation2466. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff674_inst, reff674_op in H. discriminate H. Qed.

Lemma reff674_not2469 : ~ @Equation2469 Fin5 reff674_inst.
Proof. unfold Equation2469. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff674_inst, reff674_op in H. discriminate H. Qed.

Lemma reff674_not2470 : ~ @Equation2470 Fin5 reff674_inst.
Proof. unfold Equation2470. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff674_inst, reff674_op in H. discriminate H. Qed.

Lemma reff674_not2493 : ~ @Equation2493 Fin5 reff674_inst.
Proof. unfold Equation2493. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff674_inst, reff674_op in H. discriminate H. Qed.

Lemma reff674_not2494 : ~ @Equation2494 Fin5 reff674_inst.
Proof. unfold Equation2494. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff674_inst, reff674_op in H. discriminate H. Qed.

Lemma reff674_not2496 : ~ @Equation2496 Fin5 reff674_inst.
Proof. unfold Equation2496. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff674_inst, reff674_op in H. discriminate H. Qed.

Lemma reff674_not2497 : ~ @Equation2497 Fin5 reff674_inst.
Proof. unfold Equation2497. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff674_inst, reff674_op in H. discriminate H. Qed.

Lemma reff674_not2504 : ~ @Equation2504 Fin5 reff674_inst.
Proof. unfold Equation2504. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff674_inst, reff674_op in H. discriminate H. Qed.

Lemma reff674_not2506 : ~ @Equation2506 Fin5 reff674_inst.
Proof. unfold Equation2506. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff674_inst, reff674_op in H. discriminate H. Qed.

Lemma reff674_not2531 : ~ @Equation2531 Fin5 reff674_inst.
Proof. unfold Equation2531. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff674_inst, reff674_op in H. discriminate H. Qed.

Lemma reff674_not2533 : ~ @Equation2533 Fin5 reff674_inst.
Proof. unfold Equation2533. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff674_inst, reff674_op in H. discriminate H. Qed.

Lemma reff674_not2540 : ~ @Equation2540 Fin5 reff674_inst.
Proof. unfold Equation2540. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff674_inst, reff674_op in H. discriminate H. Qed.

Lemma reff674_not2541 : ~ @Equation2541 Fin5 reff674_inst.
Proof. unfold Equation2541. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff674_inst, reff674_op in H. discriminate H. Qed.

Lemma reff674_not2543 : ~ @Equation2543 Fin5 reff674_inst.
Proof. unfold Equation2543. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff674_inst, reff674_op in H. discriminate H. Qed.

Lemma reff674_not2645 : ~ @Equation2645 Fin5 reff674_inst.
Proof. unfold Equation2645. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff674_inst, reff674_op in H. discriminate H. Qed.

Lemma reff674_not2646 : ~ @Equation2646 Fin5 reff674_inst.
Proof. unfold Equation2646. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff674_inst, reff674_op in H. discriminate H. Qed.

Lemma reff674_not2649 : ~ @Equation2649 Fin5 reff674_inst.
Proof. unfold Equation2649. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff674_inst, reff674_op in H. discriminate H. Qed.

Lemma reff674_not2652 : ~ @Equation2652 Fin5 reff674_inst.
Proof. unfold Equation2652. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff674_inst, reff674_op in H. discriminate H. Qed.

Lemma reff674_not2653 : ~ @Equation2653 Fin5 reff674_inst.
Proof. unfold Equation2653. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff674_inst, reff674_op in H. discriminate H. Qed.

Lemma reff674_not2659 : ~ @Equation2659 Fin5 reff674_inst.
Proof. unfold Equation2659. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff674_inst, reff674_op in H. discriminate H. Qed.

Lemma reff674_not2662 : ~ @Equation2662 Fin5 reff674_inst.
Proof. unfold Equation2662. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff674_inst, reff674_op in H. discriminate H. Qed.

Lemma reff674_not2663 : ~ @Equation2663 Fin5 reff674_inst.
Proof. unfold Equation2663. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff674_inst, reff674_op in H. discriminate H. Qed.

Lemma reff674_not2669 : ~ @Equation2669 Fin5 reff674_inst.
Proof. unfold Equation2669. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff674_inst, reff674_op in H. discriminate H. Qed.

Lemma reff674_not2670 : ~ @Equation2670 Fin5 reff674_inst.
Proof. unfold Equation2670. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff674_inst, reff674_op in H. discriminate H. Qed.

Lemma reff674_not2672 : ~ @Equation2672 Fin5 reff674_inst.
Proof. unfold Equation2672. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff674_inst, reff674_op in H. discriminate H. Qed.

Lemma reff674_not2673 : ~ @Equation2673 Fin5 reff674_inst.
Proof. unfold Equation2673. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff674_inst, reff674_op in H. discriminate H. Qed.

Lemma reff674_not2696 : ~ @Equation2696 Fin5 reff674_inst.
Proof. unfold Equation2696. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff674_inst, reff674_op in H. discriminate H. Qed.

Lemma reff674_not2699 : ~ @Equation2699 Fin5 reff674_inst.
Proof. unfold Equation2699. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff674_inst, reff674_op in H. discriminate H. Qed.

Lemma reff674_not2700 : ~ @Equation2700 Fin5 reff674_inst.
Proof. unfold Equation2700. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff674_inst, reff674_op in H. discriminate H. Qed.

Lemma reff674_not2706 : ~ @Equation2706 Fin5 reff674_inst.
Proof. unfold Equation2706. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff674_inst, reff674_op in H. discriminate H. Qed.

Lemma reff674_not2707 : ~ @Equation2707 Fin5 reff674_inst.
Proof. unfold Equation2707. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff674_inst, reff674_op in H. discriminate H. Qed.

Lemma reff674_not2709 : ~ @Equation2709 Fin5 reff674_inst.
Proof. unfold Equation2709. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff674_inst, reff674_op in H. discriminate H. Qed.

Lemma reff674_not2710 : ~ @Equation2710 Fin5 reff674_inst.
Proof. unfold Equation2710. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff674_inst, reff674_op in H. discriminate H. Qed.

Lemma reff674_not2733 : ~ @Equation2733 Fin5 reff674_inst.
Proof. unfold Equation2733. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff674_inst, reff674_op in H. discriminate H. Qed.

Lemma reff674_not2734 : ~ @Equation2734 Fin5 reff674_inst.
Proof. unfold Equation2734. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff674_inst, reff674_op in H. discriminate H. Qed.

Lemma reff674_not2736 : ~ @Equation2736 Fin5 reff674_inst.
Proof. unfold Equation2736. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff674_inst, reff674_op in H. discriminate H. Qed.

Lemma reff674_not2737 : ~ @Equation2737 Fin5 reff674_inst.
Proof. unfold Equation2737. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff674_inst, reff674_op in H. discriminate H. Qed.

Lemma reff674_not2743 : ~ @Equation2743 Fin5 reff674_inst.
Proof. unfold Equation2743. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff674_inst, reff674_op in H. discriminate H. Qed.

Lemma reff674_not2744 : ~ @Equation2744 Fin5 reff674_inst.
Proof. unfold Equation2744. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff674_inst, reff674_op in H. discriminate H. Qed.

Lemma reff674_not2746 : ~ @Equation2746 Fin5 reff674_inst.
Proof. unfold Equation2746. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff674_inst, reff674_op in H. discriminate H. Qed.

Lemma reff674_not2848 : ~ @Equation2848 Fin5 reff674_inst.
Proof. unfold Equation2848. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff674_inst, reff674_op in H. discriminate H. Qed.

Lemma reff674_not2849 : ~ @Equation2849 Fin5 reff674_inst.
Proof. unfold Equation2849. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff674_inst, reff674_op in H. discriminate H. Qed.

Lemma reff674_not2850 : ~ @Equation2850 Fin5 reff674_inst.
Proof. unfold Equation2850. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff674_inst, reff674_op in H. discriminate H. Qed.

Lemma reff674_not2852 : ~ @Equation2852 Fin5 reff674_inst.
Proof. unfold Equation2852. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff674_inst, reff674_op in H. discriminate H. Qed.

Lemma reff674_not2853 : ~ @Equation2853 Fin5 reff674_inst.
Proof. unfold Equation2853. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff674_inst, reff674_op in H. discriminate H. Qed.

Lemma reff674_not2856 : ~ @Equation2856 Fin5 reff674_inst.
Proof. unfold Equation2856. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff674_inst, reff674_op in H. discriminate H. Qed.

Lemma reff674_not2862 : ~ @Equation2862 Fin5 reff674_inst.
Proof. unfold Equation2862. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff674_inst, reff674_op in H. discriminate H. Qed.

Lemma reff674_not2863 : ~ @Equation2863 Fin5 reff674_inst.
Proof. unfold Equation2863. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff674_inst, reff674_op in H. discriminate H. Qed.

Lemma reff674_not2866 : ~ @Equation2866 Fin5 reff674_inst.
Proof. unfold Equation2866. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff674_inst, reff674_op in H. discriminate H. Qed.

Lemma reff674_not2872 : ~ @Equation2872 Fin5 reff674_inst.
Proof. unfold Equation2872. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff674_inst, reff674_op in H. discriminate H. Qed.

Lemma reff674_not2875 : ~ @Equation2875 Fin5 reff674_inst.
Proof. unfold Equation2875. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff674_inst, reff674_op in H. discriminate H. Qed.

Lemma reff674_not2876 : ~ @Equation2876 Fin5 reff674_inst.
Proof. unfold Equation2876. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff674_inst, reff674_op in H. discriminate H. Qed.

Lemma reff674_not2899 : ~ @Equation2899 Fin5 reff674_inst.
Proof. unfold Equation2899. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff674_inst, reff674_op in H. discriminate H. Qed.

Lemma reff674_not2902 : ~ @Equation2902 Fin5 reff674_inst.
Proof. unfold Equation2902. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff674_inst, reff674_op in H. discriminate H. Qed.

Lemma reff674_not2903 : ~ @Equation2903 Fin5 reff674_inst.
Proof. unfold Equation2903. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff674_inst, reff674_op in H. discriminate H. Qed.

Lemma reff674_not2909 : ~ @Equation2909 Fin5 reff674_inst.
Proof. unfold Equation2909. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff674_inst, reff674_op in H. discriminate H. Qed.

Lemma reff674_not2910 : ~ @Equation2910 Fin5 reff674_inst.
Proof. unfold Equation2910. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff674_inst, reff674_op in H. discriminate H. Qed.

Lemma reff674_not2912 : ~ @Equation2912 Fin5 reff674_inst.
Proof. unfold Equation2912. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff674_inst, reff674_op in H. discriminate H. Qed.

Lemma reff674_not2936 : ~ @Equation2936 Fin5 reff674_inst.
Proof. unfold Equation2936. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff674_inst, reff674_op in H. discriminate H. Qed.

Lemma reff674_not2937 : ~ @Equation2937 Fin5 reff674_inst.
Proof. unfold Equation2937. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff674_inst, reff674_op in H. discriminate H. Qed.

Lemma reff674_not2939 : ~ @Equation2939 Fin5 reff674_inst.
Proof. unfold Equation2939. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff674_inst, reff674_op in H. discriminate H. Qed.

Lemma reff674_not2946 : ~ @Equation2946 Fin5 reff674_inst.
Proof. unfold Equation2946. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff674_inst, reff674_op in H. discriminate H. Qed.

Lemma reff674_not2947 : ~ @Equation2947 Fin5 reff674_inst.
Proof. unfold Equation2947. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff674_inst, reff674_op in H. discriminate H. Qed.

Lemma reff674_not2949 : ~ @Equation2949 Fin5 reff674_inst.
Proof. unfold Equation2949. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff674_inst, reff674_op in H. discriminate H. Qed.

Lemma reff674_not3051 : ~ @Equation3051 Fin5 reff674_inst.
Proof. unfold Equation3051. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff674_inst, reff674_op in H. discriminate H. Qed.

Lemma reff674_not3052 : ~ @Equation3052 Fin5 reff674_inst.
Proof. unfold Equation3052. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff674_inst, reff674_op in H. discriminate H. Qed.

Lemma reff674_not3053 : ~ @Equation3053 Fin5 reff674_inst.
Proof. unfold Equation3053. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff674_inst, reff674_op in H. discriminate H. Qed.

Lemma reff674_not3055 : ~ @Equation3055 Fin5 reff674_inst.
Proof. unfold Equation3055. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff674_inst, reff674_op in H. discriminate H. Qed.

Lemma reff674_not3058 : ~ @Equation3058 Fin5 reff674_inst.
Proof. unfold Equation3058. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff674_inst, reff674_op in H. discriminate H. Qed.

Lemma reff674_not3059 : ~ @Equation3059 Fin5 reff674_inst.
Proof. unfold Equation3059. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff674_inst, reff674_op in H. discriminate H. Qed.

Lemma reff674_not3065 : ~ @Equation3065 Fin5 reff674_inst.
Proof. unfold Equation3065. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff674_inst, reff674_op in H. discriminate H. Qed.

Lemma reff674_not3066 : ~ @Equation3066 Fin5 reff674_inst.
Proof. unfold Equation3066. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff674_inst, reff674_op in H. discriminate H. Qed.

Lemma reff674_not3069 : ~ @Equation3069 Fin5 reff674_inst.
Proof. unfold Equation3069. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff674_inst, reff674_op in H. discriminate H. Qed.

Lemma reff674_not3075 : ~ @Equation3075 Fin5 reff674_inst.
Proof. unfold Equation3075. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff674_inst, reff674_op in H. discriminate H. Qed.

Lemma reff674_not3076 : ~ @Equation3076 Fin5 reff674_inst.
Proof. unfold Equation3076. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff674_inst, reff674_op in H. discriminate H. Qed.

Lemma reff674_not3078 : ~ @Equation3078 Fin5 reff674_inst.
Proof. unfold Equation3078. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff674_inst, reff674_op in H. discriminate H. Qed.

Lemma reff674_not3102 : ~ @Equation3102 Fin5 reff674_inst.
Proof. unfold Equation3102. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff674_inst, reff674_op in H. discriminate H. Qed.

Lemma reff674_not3103 : ~ @Equation3103 Fin5 reff674_inst.
Proof. unfold Equation3103. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff674_inst, reff674_op in H. discriminate H. Qed.

Lemma reff674_not3106 : ~ @Equation3106 Fin5 reff674_inst.
Proof. unfold Equation3106. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff674_inst, reff674_op in H. discriminate H. Qed.

Lemma reff674_not3112 : ~ @Equation3112 Fin5 reff674_inst.
Proof. unfold Equation3112. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff674_inst, reff674_op in H. discriminate H. Qed.

Lemma reff674_not3113 : ~ @Equation3113 Fin5 reff674_inst.
Proof. unfold Equation3113. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff674_inst, reff674_op in H. discriminate H. Qed.

Lemma reff674_not3115 : ~ @Equation3115 Fin5 reff674_inst.
Proof. unfold Equation3115. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff674_inst, reff674_op in H. discriminate H. Qed.

Lemma reff674_not3139 : ~ @Equation3139 Fin5 reff674_inst.
Proof. unfold Equation3139. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff674_inst, reff674_op in H. discriminate H. Qed.

Lemma reff674_not3142 : ~ @Equation3142 Fin5 reff674_inst.
Proof. unfold Equation3142. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff674_inst, reff674_op in H. discriminate H. Qed.

Lemma reff674_not3143 : ~ @Equation3143 Fin5 reff674_inst.
Proof. unfold Equation3143. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff674_inst, reff674_op in H. discriminate H. Qed.

Lemma reff674_not3149 : ~ @Equation3149 Fin5 reff674_inst.
Proof. unfold Equation3149. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff674_inst, reff674_op in H. discriminate H. Qed.

Lemma reff674_not3150 : ~ @Equation3150 Fin5 reff674_inst.
Proof. unfold Equation3150. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff674_inst, reff674_op in H. discriminate H. Qed.

Lemma reff674_not3152 : ~ @Equation3152 Fin5 reff674_inst.
Proof. unfold Equation3152. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff674_inst, reff674_op in H. discriminate H. Qed.

Lemma reff674_not3254 : ~ @Equation3254 Fin5 reff674_inst.
Proof. unfold Equation3254. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff674_inst, reff674_op in H. discriminate H. Qed.

Lemma reff674_not3255 : ~ @Equation3255 Fin5 reff674_inst.
Proof. unfold Equation3255. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff674_inst, reff674_op in H. discriminate H. Qed.

Lemma reff674_not3256 : ~ @Equation3256 Fin5 reff674_inst.
Proof. unfold Equation3256. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff674_inst, reff674_op in H. discriminate H. Qed.

Lemma reff674_not3258 : ~ @Equation3258 Fin5 reff674_inst.
Proof. unfold Equation3258. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff674_inst, reff674_op in H. discriminate H. Qed.

Lemma reff674_not3259 : ~ @Equation3259 Fin5 reff674_inst.
Proof. unfold Equation3259. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff674_inst, reff674_op in H. discriminate H. Qed.

Lemma reff674_not3261 : ~ @Equation3261 Fin5 reff674_inst.
Proof. unfold Equation3261. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff674_inst, reff674_op in H. discriminate H. Qed.

Lemma reff674_not3262 : ~ @Equation3262 Fin5 reff674_inst.
Proof. unfold Equation3262. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff674_inst, reff674_op in H. discriminate H. Qed.

Lemma reff674_not3268 : ~ @Equation3268 Fin5 reff674_inst.
Proof. unfold Equation3268. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff674_inst, reff674_op in H. discriminate H. Qed.

Lemma reff674_not3272 : ~ @Equation3272 Fin5 reff674_inst.
Proof. unfold Equation3272. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff674_inst, reff674_op in H. discriminate H. Qed.

Lemma reff674_not3278 : ~ @Equation3278 Fin5 reff674_inst.
Proof. unfold Equation3278. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff674_inst, reff674_op in H. discriminate H. Qed.

Lemma reff674_not3279 : ~ @Equation3279 Fin5 reff674_inst.
Proof. unfold Equation3279. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff674_inst, reff674_op in H. discriminate H. Qed.

Lemma reff674_not3281 : ~ @Equation3281 Fin5 reff674_inst.
Proof. unfold Equation3281. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff674_inst, reff674_op in H. discriminate H. Qed.

Lemma reff674_not3306 : ~ @Equation3306 Fin5 reff674_inst.
Proof. unfold Equation3306. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff674_inst, reff674_op in H. discriminate H. Qed.

Lemma reff674_not3308 : ~ @Equation3308 Fin5 reff674_inst.
Proof. unfold Equation3308. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff674_inst, reff674_op in H. discriminate H. Qed.

Lemma reff674_not3309 : ~ @Equation3309 Fin5 reff674_inst.
Proof. unfold Equation3309. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff674_inst, reff674_op in H. discriminate H. Qed.

Lemma reff674_not3315 : ~ @Equation3315 Fin5 reff674_inst.
Proof. unfold Equation3315. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff674_inst, reff674_op in H. discriminate H. Qed.

Lemma reff674_not3316 : ~ @Equation3316 Fin5 reff674_inst.
Proof. unfold Equation3316. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff674_inst, reff674_op in H. discriminate H. Qed.

Lemma reff674_not3318 : ~ @Equation3318 Fin5 reff674_inst.
Proof. unfold Equation3318. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff674_inst, reff674_op in H. discriminate H. Qed.

Lemma reff674_not3343 : ~ @Equation3343 Fin5 reff674_inst.
Proof. unfold Equation3343. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff674_inst, reff674_op in H. discriminate H. Qed.

Lemma reff674_not3345 : ~ @Equation3345 Fin5 reff674_inst.
Proof. unfold Equation3345. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff674_inst, reff674_op in H. discriminate H. Qed.

Lemma reff674_not3346 : ~ @Equation3346 Fin5 reff674_inst.
Proof. unfold Equation3346. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff674_inst, reff674_op in H. discriminate H. Qed.

Lemma reff674_not3352 : ~ @Equation3352 Fin5 reff674_inst.
Proof. unfold Equation3352. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff674_inst, reff674_op in H. discriminate H. Qed.

Lemma reff674_not3353 : ~ @Equation3353 Fin5 reff674_inst.
Proof. unfold Equation3353. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff674_inst, reff674_op in H. discriminate H. Qed.

Lemma reff674_not3355 : ~ @Equation3355 Fin5 reff674_inst.
Proof. unfold Equation3355. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff674_inst, reff674_op in H. discriminate H. Qed.

Lemma reff674_not3457 : ~ @Equation3457 Fin5 reff674_inst.
Proof. unfold Equation3457. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff674_inst, reff674_op in H. discriminate H. Qed.

Lemma reff674_not3458 : ~ @Equation3458 Fin5 reff674_inst.
Proof. unfold Equation3458. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff674_inst, reff674_op in H. discriminate H. Qed.

Lemma reff674_not3459 : ~ @Equation3459 Fin5 reff674_inst.
Proof. unfold Equation3459. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff674_inst, reff674_op in H. discriminate H. Qed.

Lemma reff674_not3461 : ~ @Equation3461 Fin5 reff674_inst.
Proof. unfold Equation3461. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff674_inst, reff674_op in H. discriminate H. Qed.

Lemma reff674_not3462 : ~ @Equation3462 Fin5 reff674_inst.
Proof. unfold Equation3462. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff674_inst, reff674_op in H. discriminate H. Qed.

Lemma reff674_not3464 : ~ @Equation3464 Fin5 reff674_inst.
Proof. unfold Equation3464. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff674_inst, reff674_op in H. discriminate H. Qed.

Lemma reff674_not3465 : ~ @Equation3465 Fin5 reff674_inst.
Proof. unfold Equation3465. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff674_inst, reff674_op in H. discriminate H. Qed.

Lemma reff674_not3472 : ~ @Equation3472 Fin5 reff674_inst.
Proof. unfold Equation3472. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff674_inst, reff674_op in H. discriminate H. Qed.

Lemma reff674_not3475 : ~ @Equation3475 Fin5 reff674_inst.
Proof. unfold Equation3475. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff674_inst, reff674_op in H. discriminate H. Qed.

Lemma reff674_not3482 : ~ @Equation3482 Fin5 reff674_inst.
Proof. unfold Equation3482. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff674_inst, reff674_op in H. discriminate H. Qed.

Lemma reff674_not3484 : ~ @Equation3484 Fin5 reff674_inst.
Proof. unfold Equation3484. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff674_inst, reff674_op in H. discriminate H. Qed.

Lemma reff674_not3509 : ~ @Equation3509 Fin5 reff674_inst.
Proof. unfold Equation3509. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff674_inst, reff674_op in H. discriminate H. Qed.

Lemma reff674_not3511 : ~ @Equation3511 Fin5 reff674_inst.
Proof. unfold Equation3511. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff674_inst, reff674_op in H. discriminate H. Qed.

Lemma reff674_not3512 : ~ @Equation3512 Fin5 reff674_inst.
Proof. unfold Equation3512. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff674_inst, reff674_op in H. discriminate H. Qed.

Lemma reff674_not3518 : ~ @Equation3518 Fin5 reff674_inst.
Proof. unfold Equation3518. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff674_inst, reff674_op in H. discriminate H. Qed.

Lemma reff674_not3519 : ~ @Equation3519 Fin5 reff674_inst.
Proof. unfold Equation3519. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff674_inst, reff674_op in H. discriminate H. Qed.

Lemma reff674_not3521 : ~ @Equation3521 Fin5 reff674_inst.
Proof. unfold Equation3521. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff674_inst, reff674_op in H. discriminate H. Qed.

Lemma reff674_not3546 : ~ @Equation3546 Fin5 reff674_inst.
Proof. unfold Equation3546. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff674_inst, reff674_op in H. discriminate H. Qed.

Lemma reff674_not3548 : ~ @Equation3548 Fin5 reff674_inst.
Proof. unfold Equation3548. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff674_inst, reff674_op in H. discriminate H. Qed.

Lemma reff674_not3549 : ~ @Equation3549 Fin5 reff674_inst.
Proof. unfold Equation3549. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff674_inst, reff674_op in H. discriminate H. Qed.

Lemma reff674_not3555 : ~ @Equation3555 Fin5 reff674_inst.
Proof. unfold Equation3555. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff674_inst, reff674_op in H. discriminate H. Qed.

Lemma reff674_not3556 : ~ @Equation3556 Fin5 reff674_inst.
Proof. unfold Equation3556. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff674_inst, reff674_op in H. discriminate H. Qed.

Lemma reff674_not3558 : ~ @Equation3558 Fin5 reff674_inst.
Proof. unfold Equation3558. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff674_inst, reff674_op in H. discriminate H. Qed.

Lemma reff674_not3660 : ~ @Equation3660 Fin5 reff674_inst.
Proof. unfold Equation3660. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff674_inst, reff674_op in H. discriminate H. Qed.

Lemma reff674_not3661 : ~ @Equation3661 Fin5 reff674_inst.
Proof. unfold Equation3661. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff674_inst, reff674_op in H. discriminate H. Qed.

Lemma reff674_not3662 : ~ @Equation3662 Fin5 reff674_inst.
Proof. unfold Equation3662. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff674_inst, reff674_op in H. discriminate H. Qed.

Lemma reff674_not3664 : ~ @Equation3664 Fin5 reff674_inst.
Proof. unfold Equation3664. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff674_inst, reff674_op in H. discriminate H. Qed.

Lemma reff674_not3665 : ~ @Equation3665 Fin5 reff674_inst.
Proof. unfold Equation3665. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff674_inst, reff674_op in H. discriminate H. Qed.

Lemma reff674_not3667 : ~ @Equation3667 Fin5 reff674_inst.
Proof. unfold Equation3667. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff674_inst, reff674_op in H. discriminate H. Qed.

Lemma reff674_not3668 : ~ @Equation3668 Fin5 reff674_inst.
Proof. unfold Equation3668. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff674_inst, reff674_op in H. discriminate H. Qed.

Lemma reff674_not3674 : ~ @Equation3674 Fin5 reff674_inst.
Proof. unfold Equation3674. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff674_inst, reff674_op in H. discriminate H. Qed.

Lemma reff674_not3675 : ~ @Equation3675 Fin5 reff674_inst.
Proof. unfold Equation3675. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff674_inst, reff674_op in H. discriminate H. Qed.

Lemma reff674_not3677 : ~ @Equation3677 Fin5 reff674_inst.
Proof. unfold Equation3677. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff674_inst, reff674_op in H. discriminate H. Qed.

Lemma reff674_not3678 : ~ @Equation3678 Fin5 reff674_inst.
Proof. unfold Equation3678. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff674_inst, reff674_op in H. discriminate H. Qed.

Lemma reff674_not3684 : ~ @Equation3684 Fin5 reff674_inst.
Proof. unfold Equation3684. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff674_inst, reff674_op in H. discriminate H. Qed.

Lemma reff674_not3685 : ~ @Equation3685 Fin5 reff674_inst.
Proof. unfold Equation3685. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff674_inst, reff674_op in H. discriminate H. Qed.

Lemma reff674_not3687 : ~ @Equation3687 Fin5 reff674_inst.
Proof. unfold Equation3687. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff674_inst, reff674_op in H. discriminate H. Qed.

Lemma reff674_not3712 : ~ @Equation3712 Fin5 reff674_inst.
Proof. unfold Equation3712. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff674_inst, reff674_op in H. discriminate H. Qed.

Lemma reff674_not3714 : ~ @Equation3714 Fin5 reff674_inst.
Proof. unfold Equation3714. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff674_inst, reff674_op in H. discriminate H. Qed.

Lemma reff674_not3721 : ~ @Equation3721 Fin5 reff674_inst.
Proof. unfold Equation3721. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff674_inst, reff674_op in H. discriminate H. Qed.

Lemma reff674_not3725 : ~ @Equation3725 Fin5 reff674_inst.
Proof. unfold Equation3725. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff674_inst, reff674_op in H. discriminate H. Qed.

Lemma reff674_not3748 : ~ @Equation3748 Fin5 reff674_inst.
Proof. unfold Equation3748. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff674_inst, reff674_op in H. discriminate H. Qed.

Lemma reff674_not3752 : ~ @Equation3752 Fin5 reff674_inst.
Proof. unfold Equation3752. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff674_inst, reff674_op in H. discriminate H. Qed.

Lemma reff674_not3759 : ~ @Equation3759 Fin5 reff674_inst.
Proof. unfold Equation3759. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff674_inst, reff674_op in H. discriminate H. Qed.

Lemma reff674_not3761 : ~ @Equation3761 Fin5 reff674_inst.
Proof. unfold Equation3761. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff674_inst, reff674_op in H. discriminate H. Qed.

Lemma reff674_not3864 : ~ @Equation3864 Fin5 reff674_inst.
Proof. unfold Equation3864. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff674_inst, reff674_op in H. discriminate H. Qed.

Lemma reff674_not3867 : ~ @Equation3867 Fin5 reff674_inst.
Proof. unfold Equation3867. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff674_inst, reff674_op in H. discriminate H. Qed.

Lemma reff674_not3870 : ~ @Equation3870 Fin5 reff674_inst.
Proof. unfold Equation3870. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff674_inst, reff674_op in H. discriminate H. Qed.

Lemma reff674_not3871 : ~ @Equation3871 Fin5 reff674_inst.
Proof. unfold Equation3871. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff674_inst, reff674_op in H. discriminate H. Qed.

Lemma reff674_not3877 : ~ @Equation3877 Fin5 reff674_inst.
Proof. unfold Equation3877. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff674_inst, reff674_op in H. discriminate H. Qed.

Lemma reff674_not3878 : ~ @Equation3878 Fin5 reff674_inst.
Proof. unfold Equation3878. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff674_inst, reff674_op in H. discriminate H. Qed.

Lemma reff674_not3880 : ~ @Equation3880 Fin5 reff674_inst.
Proof. unfold Equation3880. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff674_inst, reff674_op in H. discriminate H. Qed.

Lemma reff674_not3881 : ~ @Equation3881 Fin5 reff674_inst.
Proof. unfold Equation3881. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff674_inst, reff674_op in H. discriminate H. Qed.

Lemma reff674_not3887 : ~ @Equation3887 Fin5 reff674_inst.
Proof. unfold Equation3887. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff674_inst, reff674_op in H. discriminate H. Qed.

Lemma reff674_not3888 : ~ @Equation3888 Fin5 reff674_inst.
Proof. unfold Equation3888. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff674_inst, reff674_op in H. discriminate H. Qed.

Lemma reff674_not3890 : ~ @Equation3890 Fin5 reff674_inst.
Proof. unfold Equation3890. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff674_inst, reff674_op in H. discriminate H. Qed.

Lemma reff674_not3917 : ~ @Equation3917 Fin5 reff674_inst.
Proof. unfold Equation3917. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff674_inst, reff674_op in H. discriminate H. Qed.

Lemma reff674_not3918 : ~ @Equation3918 Fin5 reff674_inst.
Proof. unfold Equation3918. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff674_inst, reff674_op in H. discriminate H. Qed.

Lemma reff674_not3924 : ~ @Equation3924 Fin5 reff674_inst.
Proof. unfold Equation3924. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff674_inst, reff674_op in H. discriminate H. Qed.

Lemma reff674_not3925 : ~ @Equation3925 Fin5 reff674_inst.
Proof. unfold Equation3925. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff674_inst, reff674_op in H. discriminate H. Qed.

Lemma reff674_not3927 : ~ @Equation3927 Fin5 reff674_inst.
Proof. unfold Equation3927. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff674_inst, reff674_op in H. discriminate H. Qed.

Lemma reff674_not3928 : ~ @Equation3928 Fin5 reff674_inst.
Proof. unfold Equation3928. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff674_inst, reff674_op in H. discriminate H. Qed.

Lemma reff674_not3951 : ~ @Equation3951 Fin5 reff674_inst.
Proof. unfold Equation3951. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff674_inst, reff674_op in H. discriminate H. Qed.

Lemma reff674_not3952 : ~ @Equation3952 Fin5 reff674_inst.
Proof. unfold Equation3952. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff674_inst, reff674_op in H. discriminate H. Qed.

Lemma reff674_not3954 : ~ @Equation3954 Fin5 reff674_inst.
Proof. unfold Equation3954. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff674_inst, reff674_op in H. discriminate H. Qed.

Lemma reff674_not3955 : ~ @Equation3955 Fin5 reff674_inst.
Proof. unfold Equation3955. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff674_inst, reff674_op in H. discriminate H. Qed.

Lemma reff674_not3961 : ~ @Equation3961 Fin5 reff674_inst.
Proof. unfold Equation3961. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff674_inst, reff674_op in H. discriminate H. Qed.

Lemma reff674_not3962 : ~ @Equation3962 Fin5 reff674_inst.
Proof. unfold Equation3962. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff674_inst, reff674_op in H. discriminate H. Qed.

Lemma reff674_not4066 : ~ @Equation4066 Fin5 reff674_inst.
Proof. unfold Equation4066. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff674_inst, reff674_op in H. discriminate H. Qed.

Lemma reff674_not4067 : ~ @Equation4067 Fin5 reff674_inst.
Proof. unfold Equation4067. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff674_inst, reff674_op in H. discriminate H. Qed.

Lemma reff674_not4068 : ~ @Equation4068 Fin5 reff674_inst.
Proof. unfold Equation4068. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff674_inst, reff674_op in H. discriminate H. Qed.

Lemma reff674_not4070 : ~ @Equation4070 Fin5 reff674_inst.
Proof. unfold Equation4070. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff674_inst, reff674_op in H. discriminate H. Qed.

Lemma reff674_not4073 : ~ @Equation4073 Fin5 reff674_inst.
Proof. unfold Equation4073. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff674_inst, reff674_op in H. discriminate H. Qed.

Lemma reff674_not4074 : ~ @Equation4074 Fin5 reff674_inst.
Proof. unfold Equation4074. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff674_inst, reff674_op in H. discriminate H. Qed.

Lemma reff674_not4080 : ~ @Equation4080 Fin5 reff674_inst.
Proof. unfold Equation4080. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff674_inst, reff674_op in H. discriminate H. Qed.

Lemma reff674_not4083 : ~ @Equation4083 Fin5 reff674_inst.
Proof. unfold Equation4083. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff674_inst, reff674_op in H. discriminate H. Qed.

Lemma reff674_not4084 : ~ @Equation4084 Fin5 reff674_inst.
Proof. unfold Equation4084. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff674_inst, reff674_op in H. discriminate H. Qed.

Lemma reff674_not4090 : ~ @Equation4090 Fin5 reff674_inst.
Proof. unfold Equation4090. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff674_inst, reff674_op in H. discriminate H. Qed.

Lemma reff674_not4091 : ~ @Equation4091 Fin5 reff674_inst.
Proof. unfold Equation4091. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff674_inst, reff674_op in H. discriminate H. Qed.

Lemma reff674_not4093 : ~ @Equation4093 Fin5 reff674_inst.
Proof. unfold Equation4093. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff674_inst, reff674_op in H. discriminate H. Qed.

Lemma reff674_not4120 : ~ @Equation4120 Fin5 reff674_inst.
Proof. unfold Equation4120. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff674_inst, reff674_op in H. discriminate H. Qed.

Lemma reff674_not4121 : ~ @Equation4121 Fin5 reff674_inst.
Proof. unfold Equation4121. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff674_inst, reff674_op in H. discriminate H. Qed.

Lemma reff674_not4127 : ~ @Equation4127 Fin5 reff674_inst.
Proof. unfold Equation4127. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff674_inst, reff674_op in H. discriminate H. Qed.

Lemma reff674_not4128 : ~ @Equation4128 Fin5 reff674_inst.
Proof. unfold Equation4128. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff674_inst, reff674_op in H. discriminate H. Qed.

Lemma reff674_not4130 : ~ @Equation4130 Fin5 reff674_inst.
Proof. unfold Equation4130. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff674_inst, reff674_op in H. discriminate H. Qed.

Lemma reff674_not4131 : ~ @Equation4131 Fin5 reff674_inst.
Proof. unfold Equation4131. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff674_inst, reff674_op in H. discriminate H. Qed.

Lemma reff674_not4154 : ~ @Equation4154 Fin5 reff674_inst.
Proof. unfold Equation4154. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff674_inst, reff674_op in H. discriminate H. Qed.

Lemma reff674_not4155 : ~ @Equation4155 Fin5 reff674_inst.
Proof. unfold Equation4155. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff674_inst, reff674_op in H. discriminate H. Qed.

Lemma reff674_not4157 : ~ @Equation4157 Fin5 reff674_inst.
Proof. unfold Equation4157. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff674_inst, reff674_op in H. discriminate H. Qed.

Lemma reff674_not4158 : ~ @Equation4158 Fin5 reff674_inst.
Proof. unfold Equation4158. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff674_inst, reff674_op in H. discriminate H. Qed.

Lemma reff674_not4164 : ~ @Equation4164 Fin5 reff674_inst.
Proof. unfold Equation4164. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff674_inst, reff674_op in H. discriminate H. Qed.

Lemma reff674_not4165 : ~ @Equation4165 Fin5 reff674_inst.
Proof. unfold Equation4165. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff674_inst, reff674_op in H. discriminate H. Qed.

Lemma reff674_not4268 : ~ @Equation4268 Fin5 reff674_inst.
Proof. unfold Equation4268. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff674_inst, reff674_op in H. discriminate H. Qed.

Lemma reff674_not4269 : ~ @Equation4269 Fin5 reff674_inst.
Proof. unfold Equation4269. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff674_inst, reff674_op in H. discriminate H. Qed.

Lemma reff674_not4270 : ~ @Equation4270 Fin5 reff674_inst.
Proof. unfold Equation4270. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff674_inst, reff674_op in H. discriminate H. Qed.

Lemma reff674_not4272 : ~ @Equation4272 Fin5 reff674_inst.
Proof. unfold Equation4272. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff674_inst, reff674_op in H. discriminate H. Qed.

Lemma reff674_not4273 : ~ @Equation4273 Fin5 reff674_inst.
Proof. unfold Equation4273. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff674_inst, reff674_op in H. discriminate H. Qed.

Lemma reff674_not4275 : ~ @Equation4275 Fin5 reff674_inst.
Proof. unfold Equation4275. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff674_inst, reff674_op in H. discriminate H. Qed.

Lemma reff674_not4276 : ~ @Equation4276 Fin5 reff674_inst.
Proof. unfold Equation4276. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff674_inst, reff674_op in H. discriminate H. Qed.

Lemma reff674_not4284 : ~ @Equation4284 Fin5 reff674_inst.
Proof. unfold Equation4284. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff674_inst, reff674_op in H. discriminate H. Qed.

Lemma reff674_not4290 : ~ @Equation4290 Fin5 reff674_inst.
Proof. unfold Equation4290. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff674_inst, reff674_op in H. discriminate H. Qed.

Lemma reff674_not4291 : ~ @Equation4291 Fin5 reff674_inst.
Proof. unfold Equation4291. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff674_inst, reff674_op in H. discriminate H. Qed.

Lemma reff674_not4293 : ~ @Equation4293 Fin5 reff674_inst.
Proof. unfold Equation4293. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff674_inst, reff674_op in H. discriminate H. Qed.

Lemma reff674_not4314 : ~ @Equation4314 Fin5 reff674_inst.
Proof. unfold Equation4314. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff674_inst, reff674_op in H. discriminate H. Qed.

Lemma reff674_not4320 : ~ @Equation4320 Fin5 reff674_inst.
Proof. unfold Equation4320. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff674_inst, reff674_op in H. discriminate H. Qed.

Lemma reff674_not4321 : ~ @Equation4321 Fin5 reff674_inst.
Proof. unfold Equation4321. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff674_inst, reff674_op in H. discriminate H. Qed.

Lemma reff674_not4396 : ~ @Equation4396 Fin5 reff674_inst.
Proof. unfold Equation4396. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff674_inst, reff674_op in H. discriminate H. Qed.

Lemma reff674_not4399 : ~ @Equation4399 Fin5 reff674_inst.
Proof. unfold Equation4399. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff674_inst, reff674_op in H. discriminate H. Qed.

Lemma reff674_not4406 : ~ @Equation4406 Fin5 reff674_inst.
Proof. unfold Equation4406. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff674_inst, reff674_op in H. discriminate H. Qed.

Lemma reff674_not4408 : ~ @Equation4408 Fin5 reff674_inst.
Proof. unfold Equation4408. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff674_inst, reff674_op in H. discriminate H. Qed.

Lemma reff674_not4433 : ~ @Equation4433 Fin5 reff674_inst.
Proof. unfold Equation4433. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff674_inst, reff674_op in H. discriminate H. Qed.

Lemma reff674_not4436 : ~ @Equation4436 Fin5 reff674_inst.
Proof. unfold Equation4436. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff674_inst, reff674_op in H. discriminate H. Qed.

Lemma reff674_not4443 : ~ @Equation4443 Fin5 reff674_inst.
Proof. unfold Equation4443. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff674_inst, reff674_op in H. discriminate H. Qed.

Lemma reff674_not4445 : ~ @Equation4445 Fin5 reff674_inst.
Proof. unfold Equation4445. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff674_inst, reff674_op in H. discriminate H. Qed.

Lemma reff674_not4472 : ~ @Equation4472 Fin5 reff674_inst.
Proof. unfold Equation4472. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff674_inst, reff674_op in H. discriminate H. Qed.

Lemma reff674_not4473 : ~ @Equation4473 Fin5 reff674_inst.
Proof. unfold Equation4473. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff674_inst, reff674_op in H. discriminate H. Qed.

Lemma reff674_not4479 : ~ @Equation4479 Fin5 reff674_inst.
Proof. unfold Equation4479. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff674_inst, reff674_op in H. discriminate H. Qed.

Lemma reff674_not4480 : ~ @Equation4480 Fin5 reff674_inst.
Proof. unfold Equation4480. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff674_inst, reff674_op in H. discriminate H. Qed.

Lemma reff674_not4583 : ~ @Equation4583 Fin5 reff674_inst.
Proof. unfold Equation4583. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff674_inst, reff674_op in H. discriminate H. Qed.

Lemma reff674_not4584 : ~ @Equation4584 Fin5 reff674_inst.
Proof. unfold Equation4584. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff674_inst, reff674_op in H. discriminate H. Qed.

Lemma reff674_not4585 : ~ @Equation4585 Fin5 reff674_inst.
Proof. unfold Equation4585. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff674_inst, reff674_op in H. discriminate H. Qed.

Lemma reff674_not4587 : ~ @Equation4587 Fin5 reff674_inst.
Proof. unfold Equation4587. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff674_inst, reff674_op in H. discriminate H. Qed.

Lemma reff674_not4588 : ~ @Equation4588 Fin5 reff674_inst.
Proof. unfold Equation4588. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff674_inst, reff674_op in H. discriminate H. Qed.

Lemma reff674_not4590 : ~ @Equation4590 Fin5 reff674_inst.
Proof. unfold Equation4590. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff674_inst, reff674_op in H. discriminate H. Qed.

Lemma reff674_not4591 : ~ @Equation4591 Fin5 reff674_inst.
Proof. unfold Equation4591. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff674_inst, reff674_op in H. discriminate H. Qed.

Lemma reff674_not4598 : ~ @Equation4598 Fin5 reff674_inst.
Proof. unfold Equation4598. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff674_inst, reff674_op in H. discriminate H. Qed.

Lemma reff674_not4599 : ~ @Equation4599 Fin5 reff674_inst.
Proof. unfold Equation4599. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff674_inst, reff674_op in H. discriminate H. Qed.

Lemma reff674_not4605 : ~ @Equation4605 Fin5 reff674_inst.
Proof. unfold Equation4605. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff674_inst, reff674_op in H. discriminate H. Qed.

Lemma reff674_not4606 : ~ @Equation4606 Fin5 reff674_inst.
Proof. unfold Equation4606. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff674_inst, reff674_op in H. discriminate H. Qed.

Lemma reff674_not4629 : ~ @Equation4629 Fin5 reff674_inst.
Proof. unfold Equation4629. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff674_inst, reff674_op in H. discriminate H. Qed.

Lemma reff674_not4636 : ~ @Equation4636 Fin5 reff674_inst.
Proof. unfold Equation4636. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff674_inst, reff674_op in H. discriminate H. Qed.

Lemma reff674_not4658 : ~ @Equation4658 Fin5 reff674_inst.
Proof. unfold Equation4658. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff674_inst, reff674_op in H. discriminate H. Qed.

(** ---- reff676 (Fin5) ---- *)

Definition reff676_op (x y : Fin5) : Fin5 :=
  match x, y with
  | F5_0, F5_0 => F5_0 | F5_0, F5_1 => F5_2 | F5_0, F5_2 => F5_4 | F5_0, F5_3 => F5_1 | F5_0, F5_4 => F5_3
  | F5_1, F5_0 => F5_4 | F5_1, F5_1 => F5_1 | F5_1, F5_2 => F5_3 | F5_1, F5_3 => F5_0 | F5_1, F5_4 => F5_2
  | F5_2, F5_0 => F5_3 | F5_2, F5_1 => F5_0 | F5_2, F5_2 => F5_2 | F5_2, F5_3 => F5_4 | F5_2, F5_4 => F5_1
  | F5_3, F5_0 => F5_2 | F5_3, F5_1 => F5_4 | F5_3, F5_2 => F5_1 | F5_3, F5_3 => F5_3 | F5_3, F5_4 => F5_0
  | F5_4, F5_0 => F5_1 | F5_4, F5_1 => F5_3 | F5_4, F5_2 => F5_0 | F5_4, F5_3 => F5_2 | F5_4, F5_4 => F5_4
  end.

#[local] Instance reff676_inst : Magma Fin5 := {| magma_op := reff676_op |}.

Lemma reff676_sat65 : @Equation65 Fin5 reff676_inst.
Proof. unfold Equation65, magma_op, reff676_inst, reff676_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff676_sat73 : @Equation73 Fin5 reff676_inst.
Proof. unfold Equation73, magma_op, reff676_inst, reff676_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff676_sat102 : @Equation102 Fin5 reff676_inst.
Proof. unfold Equation102, magma_op, reff676_inst, reff676_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff676_sat117 : @Equation117 Fin5 reff676_inst.
Proof. unfold Equation117, magma_op, reff676_inst, reff676_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff676_sat125 : @Equation125 Fin5 reff676_inst.
Proof. unfold Equation125, magma_op, reff676_inst, reff676_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff676_sat160 : @Equation160 Fin5 reff676_inst.
Proof. unfold Equation160, magma_op, reff676_inst, reff676_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff676_sat167 : @Equation167 Fin5 reff676_inst.
Proof. unfold Equation167, magma_op, reff676_inst, reff676_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff676_sat212 : @Equation212 Fin5 reff676_inst.
Proof. unfold Equation212, magma_op, reff676_inst, reff676_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff676_sat229 : @Equation229 Fin5 reff676_inst.
Proof. unfold Equation229, magma_op, reff676_inst, reff676_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff676_sat258 : @Equation258 Fin5 reff676_inst.
Proof. unfold Equation258, magma_op, reff676_inst, reff676_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff676_sat263 : @Equation263 Fin5 reff676_inst.
Proof. unfold Equation263, magma_op, reff676_inst, reff676_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff676_sat335 : @Equation335 Fin5 reff676_inst.
Proof. unfold Equation335, magma_op, reff676_inst, reff676_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff676_sat362 : @Equation362 Fin5 reff676_inst.
Proof. unfold Equation362, magma_op, reff676_inst, reff676_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff676_sat437 : @Equation437 Fin5 reff676_inst.
Proof. unfold Equation437, magma_op, reff676_inst, reff676_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff676_sat546 : @Equation546 Fin5 reff676_inst.
Proof. unfold Equation546, magma_op, reff676_inst, reff676_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff676_sat562 : @Equation562 Fin5 reff676_inst.
Proof. unfold Equation562, magma_op, reff676_inst, reff676_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff676_sat617 : @Equation617 Fin5 reff676_inst.
Proof. unfold Equation617, magma_op, reff676_inst, reff676_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff676_sat632 : @Equation632 Fin5 reff676_inst.
Proof. unfold Equation632, magma_op, reff676_inst, reff676_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff676_sat640 : @Equation640 Fin5 reff676_inst.
Proof. unfold Equation640, magma_op, reff676_inst, reff676_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff676_sat679 : @Equation679 Fin5 reff676_inst.
Proof. unfold Equation679, magma_op, reff676_inst, reff676_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff676_sat704 : @Equation704 Fin5 reff676_inst.
Proof. unfold Equation704, magma_op, reff676_inst, reff676_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff676_sat826 : @Equation826 Fin5 reff676_inst.
Proof. unfold Equation826, magma_op, reff676_inst, reff676_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff676_sat949 : @Equation949 Fin5 reff676_inst.
Proof. unfold Equation949, magma_op, reff676_inst, reff676_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff676_sat962 : @Equation962 Fin5 reff676_inst.
Proof. unfold Equation962, magma_op, reff676_inst, reff676_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff676_sat1029 : @Equation1029 Fin5 reff676_inst.
Proof. unfold Equation1029, magma_op, reff676_inst, reff676_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff676_sat1046 : @Equation1046 Fin5 reff676_inst.
Proof. unfold Equation1046, magma_op, reff676_inst, reff676_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff676_sat1076 : @Equation1076 Fin5 reff676_inst.
Proof. unfold Equation1076, magma_op, reff676_inst, reff676_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff676_sat1085 : @Equation1085 Fin5 reff676_inst.
Proof. unfold Equation1085, magma_op, reff676_inst, reff676_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff676_sat1110 : @Equation1110 Fin5 reff676_inst.
Proof. unfold Equation1110, magma_op, reff676_inst, reff676_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff676_sat1119 : @Equation1119 Fin5 reff676_inst.
Proof. unfold Equation1119, magma_op, reff676_inst, reff676_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff676_sat1226 : @Equation1226 Fin5 reff676_inst.
Proof. unfold Equation1226, magma_op, reff676_inst, reff676_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff676_sat1231 : @Equation1231 Fin5 reff676_inst.
Proof. unfold Equation1231, magma_op, reff676_inst, reff676_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff676_sat1278 : @Equation1278 Fin5 reff676_inst.
Proof. unfold Equation1278, magma_op, reff676_inst, reff676_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff676_sat1323 : @Equation1323 Fin5 reff676_inst.
Proof. unfold Equation1323, magma_op, reff676_inst, reff676_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff676_sat1455 : @Equation1455 Fin5 reff676_inst.
Proof. unfold Equation1455, magma_op, reff676_inst, reff676_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff676_sat1482 : @Equation1482 Fin5 reff676_inst.
Proof. unfold Equation1482, magma_op, reff676_inst, reff676_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff676_sat1491 : @Equation1491 Fin5 reff676_inst.
Proof. unfold Equation1491, magma_op, reff676_inst, reff676_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff676_sat1518 : @Equation1518 Fin5 reff676_inst.
Proof. unfold Equation1518, magma_op, reff676_inst, reff676_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff676_sat1526 : @Equation1526 Fin5 reff676_inst.
Proof. unfold Equation1526, magma_op, reff676_inst, reff676_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff676_sat1721 : @Equation1721 Fin5 reff676_inst.
Proof. unfold Equation1721, magma_op, reff676_inst, reff676_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff676_sat1790 : @Equation1790 Fin5 reff676_inst.
Proof. unfold Equation1790, magma_op, reff676_inst, reff676_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff676_sat1897 : @Equation1897 Fin5 reff676_inst.
Proof. unfold Equation1897, magma_op, reff676_inst, reff676_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff676_sat1967 : @Equation1967 Fin5 reff676_inst.
Proof. unfold Equation1967, magma_op, reff676_inst, reff676_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff676_sat2044 : @Equation2044 Fin5 reff676_inst.
Proof. unfold Equation2044, magma_op, reff676_inst, reff676_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff676_sat2053 : @Equation2053 Fin5 reff676_inst.
Proof. unfold Equation2053, magma_op, reff676_inst, reff676_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff676_sat2060 : @Equation2060 Fin5 reff676_inst.
Proof. unfold Equation2060, magma_op, reff676_inst, reff676_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff676_sat2100 : @Equation2100 Fin5 reff676_inst.
Proof. unfold Equation2100, magma_op, reff676_inst, reff676_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff676_sat2125 : @Equation2125 Fin5 reff676_inst.
Proof. unfold Equation2125, magma_op, reff676_inst, reff676_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff676_sat2267 : @Equation2267 Fin5 reff676_inst.
Proof. unfold Equation2267, magma_op, reff676_inst, reff676_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff676_sat2294 : @Equation2294 Fin5 reff676_inst.
Proof. unfold Equation2294, magma_op, reff676_inst, reff676_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff676_sat2300 : @Equation2300 Fin5 reff676_inst.
Proof. unfold Equation2300, magma_op, reff676_inst, reff676_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff676_sat2328 : @Equation2328 Fin5 reff676_inst.
Proof. unfold Equation2328, magma_op, reff676_inst, reff676_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff676_sat2330 : @Equation2330 Fin5 reff676_inst.
Proof. unfold Equation2330, magma_op, reff676_inst, reff676_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff676_sat2533 : @Equation2533 Fin5 reff676_inst.
Proof. unfold Equation2533, magma_op, reff676_inst, reff676_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff676_sat2586 : @Equation2586 Fin5 reff676_inst.
Proof. unfold Equation2586, magma_op, reff676_inst, reff676_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff676_sat2653 : @Equation2653 Fin5 reff676_inst.
Proof. unfold Equation2653, magma_op, reff676_inst, reff676_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff676_sat2663 : @Equation2663 Fin5 reff676_inst.
Proof. unfold Equation2663, magma_op, reff676_inst, reff676_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff676_sat2672 : @Equation2672 Fin5 reff676_inst.
Proof. unfold Equation2672, magma_op, reff676_inst, reff676_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff676_sat2699 : @Equation2699 Fin5 reff676_inst.
Proof. unfold Equation2699, magma_op, reff676_inst, reff676_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff676_sat2744 : @Equation2744 Fin5 reff676_inst.
Proof. unfold Equation2744, magma_op, reff676_inst, reff676_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff676_sat2850 : @Equation2850 Fin5 reff676_inst.
Proof. unfold Equation2850, magma_op, reff676_inst, reff676_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff676_sat2863 : @Equation2863 Fin5 reff676_inst.
Proof. unfold Equation2863, magma_op, reff676_inst, reff676_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff676_sat2875 : @Equation2875 Fin5 reff676_inst.
Proof. unfold Equation2875, magma_op, reff676_inst, reff676_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff676_sat2910 : @Equation2910 Fin5 reff676_inst.
Proof. unfold Equation2910, magma_op, reff676_inst, reff676_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff676_sat2939 : @Equation2939 Fin5 reff676_inst.
Proof. unfold Equation2939, magma_op, reff676_inst, reff676_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff676_sat3113 : @Equation3113 Fin5 reff676_inst.
Proof. unfold Equation3113, magma_op, reff676_inst, reff676_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff676_sat3271 : @Equation3271 Fin5 reff676_inst.
Proof. unfold Equation3271, magma_op, reff676_inst, reff676_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff676_sat3279 : @Equation3279 Fin5 reff676_inst.
Proof. unfold Equation3279, magma_op, reff676_inst, reff676_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff676_sat3352 : @Equation3352 Fin5 reff676_inst.
Proof. unfold Equation3352, magma_op, reff676_inst, reff676_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff676_sat3482 : @Equation3482 Fin5 reff676_inst.
Proof. unfold Equation3482, magma_op, reff676_inst, reff676_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff676_sat3607 : @Equation3607 Fin5 reff676_inst.
Proof. unfold Equation3607, magma_op, reff676_inst, reff676_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff676_sat3668 : @Equation3668 Fin5 reff676_inst.
Proof. unfold Equation3668, magma_op, reff676_inst, reff676_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff676_sat3675 : @Equation3675 Fin5 reff676_inst.
Proof. unfold Equation3675, magma_op, reff676_inst, reff676_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff676_sat3761 : @Equation3761 Fin5 reff676_inst.
Proof. unfold Equation3761, magma_op, reff676_inst, reff676_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff676_sat3871 : @Equation3871 Fin5 reff676_inst.
Proof. unfold Equation3871, magma_op, reff676_inst, reff676_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff676_sat3888 : @Equation3888 Fin5 reff676_inst.
Proof. unfold Equation3888, magma_op, reff676_inst, reff676_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff676_sat3924 : @Equation3924 Fin5 reff676_inst.
Proof. unfold Equation3924, magma_op, reff676_inst, reff676_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff676_sat3954 : @Equation3954 Fin5 reff676_inst.
Proof. unfold Equation3954, magma_op, reff676_inst, reff676_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff676_sat4157 : @Equation4157 Fin5 reff676_inst.
Proof. unfold Equation4157, magma_op, reff676_inst, reff676_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff676_sat4321 : @Equation4321 Fin5 reff676_inst.
Proof. unfold Equation4321, magma_op, reff676_inst, reff676_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff676_sat4369 : @Equation4369 Fin5 reff676_inst.
Proof. unfold Equation4369, magma_op, reff676_inst, reff676_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff676_sat4383 : @Equation4383 Fin5 reff676_inst.
Proof. unfold Equation4383, magma_op, reff676_inst, reff676_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff676_sat4408 : @Equation4408 Fin5 reff676_inst.
Proof. unfold Equation4408, magma_op, reff676_inst, reff676_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff676_sat4443 : @Equation4443 Fin5 reff676_inst.
Proof. unfold Equation4443, magma_op, reff676_inst, reff676_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff676_sat4636 : @Equation4636 Fin5 reff676_inst.
Proof. unfold Equation4636, magma_op, reff676_inst, reff676_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff676_not50 : ~ @Equation50 Fin5 reff676_inst.
Proof. unfold Equation50. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff676_inst, reff676_op in H. discriminate H. Qed.

Lemma reff676_not53 : ~ @Equation53 Fin5 reff676_inst.
Proof. unfold Equation53. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff676_inst, reff676_op in H. discriminate H. Qed.

Lemma reff676_not55 : ~ @Equation55 Fin5 reff676_inst.
Proof. unfold Equation55. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff676_inst, reff676_op in H. discriminate H. Qed.

Lemma reff676_not56 : ~ @Equation56 Fin5 reff676_inst.
Proof. unfold Equation56. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff676_inst, reff676_op in H. discriminate H. Qed.

Lemma reff676_not63 : ~ @Equation63 Fin5 reff676_inst.
Proof. unfold Equation63. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff676_inst, reff676_op in H. discriminate H. Qed.

Lemma reff676_not66 : ~ @Equation66 Fin5 reff676_inst.
Proof. unfold Equation66. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff676_inst, reff676_op in H. discriminate H. Qed.

Lemma reff676_not72 : ~ @Equation72 Fin5 reff676_inst.
Proof. unfold Equation72. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff676_inst, reff676_op in H. discriminate H. Qed.

Lemma reff676_not75 : ~ @Equation75 Fin5 reff676_inst.
Proof. unfold Equation75. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff676_inst, reff676_op in H. discriminate H. Qed.

Lemma reff676_not105 : ~ @Equation105 Fin5 reff676_inst.
Proof. unfold Equation105. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff676_inst, reff676_op in H. discriminate H. Qed.

Lemma reff676_not107 : ~ @Equation107 Fin5 reff676_inst.
Proof. unfold Equation107. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff676_inst, reff676_op in H. discriminate H. Qed.

Lemma reff676_not108 : ~ @Equation108 Fin5 reff676_inst.
Proof. unfold Equation108. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff676_inst, reff676_op in H. discriminate H. Qed.

Lemma reff676_not115 : ~ @Equation115 Fin5 reff676_inst.
Proof. unfold Equation115. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff676_inst, reff676_op in H. discriminate H. Qed.

Lemma reff676_not118 : ~ @Equation118 Fin5 reff676_inst.
Proof. unfold Equation118. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff676_inst, reff676_op in H. discriminate H. Qed.

Lemma reff676_not124 : ~ @Equation124 Fin5 reff676_inst.
Proof. unfold Equation124. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff676_inst, reff676_op in H. discriminate H. Qed.

Lemma reff676_not127 : ~ @Equation127 Fin5 reff676_inst.
Proof. unfold Equation127. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff676_inst, reff676_op in H. discriminate H. Qed.

Lemma reff676_not154 : ~ @Equation154 Fin5 reff676_inst.
Proof. unfold Equation154. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff676_inst, reff676_op in H. discriminate H. Qed.

Lemma reff676_not157 : ~ @Equation157 Fin5 reff676_inst.
Proof. unfold Equation157. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff676_inst, reff676_op in H. discriminate H. Qed.

Lemma reff676_not159 : ~ @Equation159 Fin5 reff676_inst.
Proof. unfold Equation159. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff676_inst, reff676_op in H. discriminate H. Qed.

Lemma reff676_not169 : ~ @Equation169 Fin5 reff676_inst.
Proof. unfold Equation169. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff676_inst, reff676_op in H. discriminate H. Qed.

Lemma reff676_not170 : ~ @Equation170 Fin5 reff676_inst.
Proof. unfold Equation170. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff676_inst, reff676_op in H. discriminate H. Qed.

Lemma reff676_not176 : ~ @Equation176 Fin5 reff676_inst.
Proof. unfold Equation176. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff676_inst, reff676_op in H. discriminate H. Qed.

Lemma reff676_not177 : ~ @Equation177 Fin5 reff676_inst.
Proof. unfold Equation177. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff676_inst, reff676_op in H. discriminate H. Qed.

Lemma reff676_not179 : ~ @Equation179 Fin5 reff676_inst.
Proof. unfold Equation179. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff676_inst, reff676_op in H. discriminate H. Qed.

Lemma reff676_not206 : ~ @Equation206 Fin5 reff676_inst.
Proof. unfold Equation206. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff676_inst, reff676_op in H. discriminate H. Qed.

Lemma reff676_not209 : ~ @Equation209 Fin5 reff676_inst.
Proof. unfold Equation209. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff676_inst, reff676_op in H. discriminate H. Qed.

Lemma reff676_not211 : ~ @Equation211 Fin5 reff676_inst.
Proof. unfold Equation211. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff676_inst, reff676_op in H. discriminate H. Qed.

Lemma reff676_not219 : ~ @Equation219 Fin5 reff676_inst.
Proof. unfold Equation219. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff676_inst, reff676_op in H. discriminate H. Qed.

Lemma reff676_not221 : ~ @Equation221 Fin5 reff676_inst.
Proof. unfold Equation221. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff676_inst, reff676_op in H. discriminate H. Qed.

Lemma reff676_not222 : ~ @Equation222 Fin5 reff676_inst.
Proof. unfold Equation222. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff676_inst, reff676_op in H. discriminate H. Qed.

Lemma reff676_not228 : ~ @Equation228 Fin5 reff676_inst.
Proof. unfold Equation228. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff676_inst, reff676_op in H. discriminate H. Qed.

Lemma reff676_not231 : ~ @Equation231 Fin5 reff676_inst.
Proof. unfold Equation231. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff676_inst, reff676_op in H. discriminate H. Qed.

Lemma reff676_not261 : ~ @Equation261 Fin5 reff676_inst.
Proof. unfold Equation261. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff676_inst, reff676_op in H. discriminate H. Qed.

Lemma reff676_not264 : ~ @Equation264 Fin5 reff676_inst.
Proof. unfold Equation264. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff676_inst, reff676_op in H. discriminate H. Qed.

Lemma reff676_not271 : ~ @Equation271 Fin5 reff676_inst.
Proof. unfold Equation271. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff676_inst, reff676_op in H. discriminate H. Qed.

Lemma reff676_not273 : ~ @Equation273 Fin5 reff676_inst.
Proof. unfold Equation273. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff676_inst, reff676_op in H. discriminate H. Qed.

Lemma reff676_not274 : ~ @Equation274 Fin5 reff676_inst.
Proof. unfold Equation274. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff676_inst, reff676_op in H. discriminate H. Qed.

Lemma reff676_not280 : ~ @Equation280 Fin5 reff676_inst.
Proof. unfold Equation280. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff676_inst, reff676_op in H. discriminate H. Qed.

Lemma reff676_not281 : ~ @Equation281 Fin5 reff676_inst.
Proof. unfold Equation281. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff676_inst, reff676_op in H. discriminate H. Qed.

Lemma reff676_not283 : ~ @Equation283 Fin5 reff676_inst.
Proof. unfold Equation283. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff676_inst, reff676_op in H. discriminate H. Qed.

Lemma reff676_not377 : ~ @Equation377 Fin5 reff676_inst.
Proof. unfold Equation377. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff676_inst, reff676_op in H. discriminate H. Qed.

Lemma reff676_not378 : ~ @Equation378 Fin5 reff676_inst.
Proof. unfold Equation378. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff676_inst, reff676_op in H. discriminate H. Qed.

Lemma reff676_not412 : ~ @Equation412 Fin5 reff676_inst.
Proof. unfold Equation412. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff676_inst, reff676_op in H. discriminate H. Qed.

Lemma reff676_not413 : ~ @Equation413 Fin5 reff676_inst.
Proof. unfold Equation413. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff676_inst, reff676_op in H. discriminate H. Qed.

Lemma reff676_not414 : ~ @Equation414 Fin5 reff676_inst.
Proof. unfold Equation414. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff676_inst, reff676_op in H. discriminate H. Qed.

Lemma reff676_not416 : ~ @Equation416 Fin5 reff676_inst.
Proof. unfold Equation416. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff676_inst, reff676_op in H. discriminate H. Qed.

Lemma reff676_not417 : ~ @Equation417 Fin5 reff676_inst.
Proof. unfold Equation417. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff676_inst, reff676_op in H. discriminate H. Qed.

Lemma reff676_not419 : ~ @Equation419 Fin5 reff676_inst.
Proof. unfold Equation419. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff676_inst, reff676_op in H. discriminate H. Qed.

Lemma reff676_not420 : ~ @Equation420 Fin5 reff676_inst.
Proof. unfold Equation420. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff676_inst, reff676_op in H. discriminate H. Qed.

Lemma reff676_not426 : ~ @Equation426 Fin5 reff676_inst.
Proof. unfold Equation426. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff676_inst, reff676_op in H. discriminate H. Qed.

Lemma reff676_not427 : ~ @Equation427 Fin5 reff676_inst.
Proof. unfold Equation427. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff676_inst, reff676_op in H. discriminate H. Qed.

Lemma reff676_not430 : ~ @Equation430 Fin5 reff676_inst.
Proof. unfold Equation430. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff676_inst, reff676_op in H. discriminate H. Qed.

Lemma reff676_not436 : ~ @Equation436 Fin5 reff676_inst.
Proof. unfold Equation436. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff676_inst, reff676_op in H. discriminate H. Qed.

Lemma reff676_not439 : ~ @Equation439 Fin5 reff676_inst.
Proof. unfold Equation439. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff676_inst, reff676_op in H. discriminate H. Qed.

Lemma reff676_not440 : ~ @Equation440 Fin5 reff676_inst.
Proof. unfold Equation440. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff676_inst, reff676_op in H. discriminate H. Qed.

Lemma reff676_not463 : ~ @Equation463 Fin5 reff676_inst.
Proof. unfold Equation463. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff676_inst, reff676_op in H. discriminate H. Qed.

Lemma reff676_not466 : ~ @Equation466 Fin5 reff676_inst.
Proof. unfold Equation466. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff676_inst, reff676_op in H. discriminate H. Qed.

Lemma reff676_not467 : ~ @Equation467 Fin5 reff676_inst.
Proof. unfold Equation467. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff676_inst, reff676_op in H. discriminate H. Qed.

Lemma reff676_not474 : ~ @Equation474 Fin5 reff676_inst.
Proof. unfold Equation474. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff676_inst, reff676_op in H. discriminate H. Qed.

Lemma reff676_not476 : ~ @Equation476 Fin5 reff676_inst.
Proof. unfold Equation476. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff676_inst, reff676_op in H. discriminate H. Qed.

Lemma reff676_not477 : ~ @Equation477 Fin5 reff676_inst.
Proof. unfold Equation477. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff676_inst, reff676_op in H. discriminate H. Qed.

Lemma reff676_not500 : ~ @Equation500 Fin5 reff676_inst.
Proof. unfold Equation500. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff676_inst, reff676_op in H. discriminate H. Qed.

Lemma reff676_not501 : ~ @Equation501 Fin5 reff676_inst.
Proof. unfold Equation501. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff676_inst, reff676_op in H. discriminate H. Qed.

Lemma reff676_not503 : ~ @Equation503 Fin5 reff676_inst.
Proof. unfold Equation503. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff676_inst, reff676_op in H. discriminate H. Qed.

Lemma reff676_not510 : ~ @Equation510 Fin5 reff676_inst.
Proof. unfold Equation510. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff676_inst, reff676_op in H. discriminate H. Qed.

Lemma reff676_not511 : ~ @Equation511 Fin5 reff676_inst.
Proof. unfold Equation511. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff676_inst, reff676_op in H. discriminate H. Qed.

Lemma reff676_not615 : ~ @Equation615 Fin5 reff676_inst.
Proof. unfold Equation615. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff676_inst, reff676_op in H. discriminate H. Qed.

Lemma reff676_not616 : ~ @Equation616 Fin5 reff676_inst.
Proof. unfold Equation616. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff676_inst, reff676_op in H. discriminate H. Qed.

Lemma reff676_not619 : ~ @Equation619 Fin5 reff676_inst.
Proof. unfold Equation619. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff676_inst, reff676_op in H. discriminate H. Qed.

Lemma reff676_not620 : ~ @Equation620 Fin5 reff676_inst.
Proof. unfold Equation620. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff676_inst, reff676_op in H. discriminate H. Qed.

Lemma reff676_not622 : ~ @Equation622 Fin5 reff676_inst.
Proof. unfold Equation622. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff676_inst, reff676_op in H. discriminate H. Qed.

Lemma reff676_not623 : ~ @Equation623 Fin5 reff676_inst.
Proof. unfold Equation623. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff676_inst, reff676_op in H. discriminate H. Qed.

Lemma reff676_not629 : ~ @Equation629 Fin5 reff676_inst.
Proof. unfold Equation629. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff676_inst, reff676_op in H. discriminate H. Qed.

Lemma reff676_not630 : ~ @Equation630 Fin5 reff676_inst.
Proof. unfold Equation630. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff676_inst, reff676_op in H. discriminate H. Qed.

Lemma reff676_not633 : ~ @Equation633 Fin5 reff676_inst.
Proof. unfold Equation633. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff676_inst, reff676_op in H. discriminate H. Qed.

Lemma reff676_not639 : ~ @Equation639 Fin5 reff676_inst.
Proof. unfold Equation639. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff676_inst, reff676_op in H. discriminate H. Qed.

Lemma reff676_not642 : ~ @Equation642 Fin5 reff676_inst.
Proof. unfold Equation642. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff676_inst, reff676_op in H. discriminate H. Qed.

Lemma reff676_not643 : ~ @Equation643 Fin5 reff676_inst.
Proof. unfold Equation643. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff676_inst, reff676_op in H. discriminate H. Qed.

Lemma reff676_not666 : ~ @Equation666 Fin5 reff676_inst.
Proof. unfold Equation666. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff676_inst, reff676_op in H. discriminate H. Qed.

Lemma reff676_not667 : ~ @Equation667 Fin5 reff676_inst.
Proof. unfold Equation667. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff676_inst, reff676_op in H. discriminate H. Qed.

Lemma reff676_not669 : ~ @Equation669 Fin5 reff676_inst.
Proof. unfold Equation669. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff676_inst, reff676_op in H. discriminate H. Qed.

Lemma reff676_not670 : ~ @Equation670 Fin5 reff676_inst.
Proof. unfold Equation670. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff676_inst, reff676_op in H. discriminate H. Qed.

Lemma reff676_not676 : ~ @Equation676 Fin5 reff676_inst.
Proof. unfold Equation676. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff676_inst, reff676_op in H. discriminate H. Qed.

Lemma reff676_not677 : ~ @Equation677 Fin5 reff676_inst.
Proof. unfold Equation677. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff676_inst, reff676_op in H. discriminate H. Qed.

Lemma reff676_not680 : ~ @Equation680 Fin5 reff676_inst.
Proof. unfold Equation680. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff676_inst, reff676_op in H. discriminate H. Qed.

Lemma reff676_not703 : ~ @Equation703 Fin5 reff676_inst.
Proof. unfold Equation703. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff676_inst, reff676_op in H. discriminate H. Qed.

Lemma reff676_not706 : ~ @Equation706 Fin5 reff676_inst.
Proof. unfold Equation706. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff676_inst, reff676_op in H. discriminate H. Qed.

Lemma reff676_not707 : ~ @Equation707 Fin5 reff676_inst.
Proof. unfold Equation707. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff676_inst, reff676_op in H. discriminate H. Qed.

Lemma reff676_not713 : ~ @Equation713 Fin5 reff676_inst.
Proof. unfold Equation713. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff676_inst, reff676_op in H. discriminate H. Qed.

Lemma reff676_not714 : ~ @Equation714 Fin5 reff676_inst.
Proof. unfold Equation714. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff676_inst, reff676_op in H. discriminate H. Qed.

Lemma reff676_not716 : ~ @Equation716 Fin5 reff676_inst.
Proof. unfold Equation716. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff676_inst, reff676_op in H. discriminate H. Qed.

Lemma reff676_not818 : ~ @Equation818 Fin5 reff676_inst.
Proof. unfold Equation818. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff676_inst, reff676_op in H. discriminate H. Qed.

Lemma reff676_not819 : ~ @Equation819 Fin5 reff676_inst.
Proof. unfold Equation819. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff676_inst, reff676_op in H. discriminate H. Qed.

Lemma reff676_not820 : ~ @Equation820 Fin5 reff676_inst.
Proof. unfold Equation820. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff676_inst, reff676_op in H. discriminate H. Qed.

Lemma reff676_not822 : ~ @Equation822 Fin5 reff676_inst.
Proof. unfold Equation822. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff676_inst, reff676_op in H. discriminate H. Qed.

Lemma reff676_not823 : ~ @Equation823 Fin5 reff676_inst.
Proof. unfold Equation823. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff676_inst, reff676_op in H. discriminate H. Qed.

Lemma reff676_not825 : ~ @Equation825 Fin5 reff676_inst.
Proof. unfold Equation825. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff676_inst, reff676_op in H. discriminate H. Qed.

Lemma reff676_not832 : ~ @Equation832 Fin5 reff676_inst.
Proof. unfold Equation832. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff676_inst, reff676_op in H. discriminate H. Qed.

Lemma reff676_not835 : ~ @Equation835 Fin5 reff676_inst.
Proof. unfold Equation835. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff676_inst, reff676_op in H. discriminate H. Qed.

Lemma reff676_not836 : ~ @Equation836 Fin5 reff676_inst.
Proof. unfold Equation836. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff676_inst, reff676_op in H. discriminate H. Qed.

Lemma reff676_not842 : ~ @Equation842 Fin5 reff676_inst.
Proof. unfold Equation842. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff676_inst, reff676_op in H. discriminate H. Qed.

Lemma reff676_not843 : ~ @Equation843 Fin5 reff676_inst.
Proof. unfold Equation843. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff676_inst, reff676_op in H. discriminate H. Qed.

Lemma reff676_not845 : ~ @Equation845 Fin5 reff676_inst.
Proof. unfold Equation845. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff676_inst, reff676_op in H. discriminate H. Qed.

Lemma reff676_not846 : ~ @Equation846 Fin5 reff676_inst.
Proof. unfold Equation846. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff676_inst, reff676_op in H. discriminate H. Qed.

Lemma reff676_not869 : ~ @Equation869 Fin5 reff676_inst.
Proof. unfold Equation869. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff676_inst, reff676_op in H. discriminate H. Qed.

Lemma reff676_not870 : ~ @Equation870 Fin5 reff676_inst.
Proof. unfold Equation870. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff676_inst, reff676_op in H. discriminate H. Qed.

Lemma reff676_not873 : ~ @Equation873 Fin5 reff676_inst.
Proof. unfold Equation873. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff676_inst, reff676_op in H. discriminate H. Qed.

Lemma reff676_not880 : ~ @Equation880 Fin5 reff676_inst.
Proof. unfold Equation880. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff676_inst, reff676_op in H. discriminate H. Qed.

Lemma reff676_not882 : ~ @Equation882 Fin5 reff676_inst.
Proof. unfold Equation882. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff676_inst, reff676_op in H. discriminate H. Qed.

Lemma reff676_not883 : ~ @Equation883 Fin5 reff676_inst.
Proof. unfold Equation883. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff676_inst, reff676_op in H. discriminate H. Qed.

Lemma reff676_not906 : ~ @Equation906 Fin5 reff676_inst.
Proof. unfold Equation906. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff676_inst, reff676_op in H. discriminate H. Qed.

Lemma reff676_not907 : ~ @Equation907 Fin5 reff676_inst.
Proof. unfold Equation907. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff676_inst, reff676_op in H. discriminate H. Qed.

Lemma reff676_not909 : ~ @Equation909 Fin5 reff676_inst.
Proof. unfold Equation909. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff676_inst, reff676_op in H. discriminate H. Qed.

Lemma reff676_not916 : ~ @Equation916 Fin5 reff676_inst.
Proof. unfold Equation916. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff676_inst, reff676_op in H. discriminate H. Qed.

Lemma reff676_not919 : ~ @Equation919 Fin5 reff676_inst.
Proof. unfold Equation919. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff676_inst, reff676_op in H. discriminate H. Qed.

Lemma reff676_not1021 : ~ @Equation1021 Fin5 reff676_inst.
Proof. unfold Equation1021. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff676_inst, reff676_op in H. discriminate H. Qed.

Lemma reff676_not1022 : ~ @Equation1022 Fin5 reff676_inst.
Proof. unfold Equation1022. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff676_inst, reff676_op in H. discriminate H. Qed.

Lemma reff676_not1023 : ~ @Equation1023 Fin5 reff676_inst.
Proof. unfold Equation1023. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff676_inst, reff676_op in H. discriminate H. Qed.

Lemma reff676_not1025 : ~ @Equation1025 Fin5 reff676_inst.
Proof. unfold Equation1025. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff676_inst, reff676_op in H. discriminate H. Qed.

Lemma reff676_not1026 : ~ @Equation1026 Fin5 reff676_inst.
Proof. unfold Equation1026. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff676_inst, reff676_op in H. discriminate H. Qed.

Lemma reff676_not1028 : ~ @Equation1028 Fin5 reff676_inst.
Proof. unfold Equation1028. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff676_inst, reff676_op in H. discriminate H. Qed.

Lemma reff676_not1035 : ~ @Equation1035 Fin5 reff676_inst.
Proof. unfold Equation1035. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff676_inst, reff676_op in H. discriminate H. Qed.

Lemma reff676_not1036 : ~ @Equation1036 Fin5 reff676_inst.
Proof. unfold Equation1036. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff676_inst, reff676_op in H. discriminate H. Qed.

Lemma reff676_not1038 : ~ @Equation1038 Fin5 reff676_inst.
Proof. unfold Equation1038. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff676_inst, reff676_op in H. discriminate H. Qed.

Lemma reff676_not1039 : ~ @Equation1039 Fin5 reff676_inst.
Proof. unfold Equation1039. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff676_inst, reff676_op in H. discriminate H. Qed.

Lemma reff676_not1045 : ~ @Equation1045 Fin5 reff676_inst.
Proof. unfold Equation1045. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff676_inst, reff676_op in H. discriminate H. Qed.

Lemma reff676_not1048 : ~ @Equation1048 Fin5 reff676_inst.
Proof. unfold Equation1048. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff676_inst, reff676_op in H. discriminate H. Qed.

Lemma reff676_not1049 : ~ @Equation1049 Fin5 reff676_inst.
Proof. unfold Equation1049. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff676_inst, reff676_op in H. discriminate H. Qed.

Lemma reff676_not1072 : ~ @Equation1072 Fin5 reff676_inst.
Proof. unfold Equation1072. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff676_inst, reff676_op in H. discriminate H. Qed.

Lemma reff676_not1073 : ~ @Equation1073 Fin5 reff676_inst.
Proof. unfold Equation1073. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff676_inst, reff676_op in H. discriminate H. Qed.

Lemma reff676_not1075 : ~ @Equation1075 Fin5 reff676_inst.
Proof. unfold Equation1075. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff676_inst, reff676_op in H. discriminate H. Qed.

Lemma reff676_not1082 : ~ @Equation1082 Fin5 reff676_inst.
Proof. unfold Equation1082. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff676_inst, reff676_op in H. discriminate H. Qed.

Lemma reff676_not1083 : ~ @Equation1083 Fin5 reff676_inst.
Proof. unfold Equation1083. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff676_inst, reff676_op in H. discriminate H. Qed.

Lemma reff676_not1086 : ~ @Equation1086 Fin5 reff676_inst.
Proof. unfold Equation1086. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff676_inst, reff676_op in H. discriminate H. Qed.

Lemma reff676_not1109 : ~ @Equation1109 Fin5 reff676_inst.
Proof. unfold Equation1109. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff676_inst, reff676_op in H. discriminate H. Qed.

Lemma reff676_not1112 : ~ @Equation1112 Fin5 reff676_inst.
Proof. unfold Equation1112. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff676_inst, reff676_op in H. discriminate H. Qed.

Lemma reff676_not1113 : ~ @Equation1113 Fin5 reff676_inst.
Proof. unfold Equation1113. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff676_inst, reff676_op in H. discriminate H. Qed.

Lemma reff676_not1120 : ~ @Equation1120 Fin5 reff676_inst.
Proof. unfold Equation1120. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff676_inst, reff676_op in H. discriminate H. Qed.

Lemma reff676_not1122 : ~ @Equation1122 Fin5 reff676_inst.
Proof. unfold Equation1122. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff676_inst, reff676_op in H. discriminate H. Qed.

Lemma reff676_not1224 : ~ @Equation1224 Fin5 reff676_inst.
Proof. unfold Equation1224. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff676_inst, reff676_op in H. discriminate H. Qed.

Lemma reff676_not1225 : ~ @Equation1225 Fin5 reff676_inst.
Proof. unfold Equation1225. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff676_inst, reff676_op in H. discriminate H. Qed.

Lemma reff676_not1228 : ~ @Equation1228 Fin5 reff676_inst.
Proof. unfold Equation1228. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff676_inst, reff676_op in H. discriminate H. Qed.

Lemma reff676_not1229 : ~ @Equation1229 Fin5 reff676_inst.
Proof. unfold Equation1229. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff676_inst, reff676_op in H. discriminate H. Qed.

Lemma reff676_not1232 : ~ @Equation1232 Fin5 reff676_inst.
Proof. unfold Equation1232. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff676_inst, reff676_op in H. discriminate H. Qed.

Lemma reff676_not1238 : ~ @Equation1238 Fin5 reff676_inst.
Proof. unfold Equation1238. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff676_inst, reff676_op in H. discriminate H. Qed.

Lemma reff676_not1239 : ~ @Equation1239 Fin5 reff676_inst.
Proof. unfold Equation1239. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff676_inst, reff676_op in H. discriminate H. Qed.

Lemma reff676_not1241 : ~ @Equation1241 Fin5 reff676_inst.
Proof. unfold Equation1241. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff676_inst, reff676_op in H. discriminate H. Qed.

Lemma reff676_not1242 : ~ @Equation1242 Fin5 reff676_inst.
Proof. unfold Equation1242. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff676_inst, reff676_op in H. discriminate H. Qed.

Lemma reff676_not1248 : ~ @Equation1248 Fin5 reff676_inst.
Proof. unfold Equation1248. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff676_inst, reff676_op in H. discriminate H. Qed.

Lemma reff676_not1249 : ~ @Equation1249 Fin5 reff676_inst.
Proof. unfold Equation1249. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff676_inst, reff676_op in H. discriminate H. Qed.

Lemma reff676_not1251 : ~ @Equation1251 Fin5 reff676_inst.
Proof. unfold Equation1251. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff676_inst, reff676_op in H. discriminate H. Qed.

Lemma reff676_not1252 : ~ @Equation1252 Fin5 reff676_inst.
Proof. unfold Equation1252. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff676_inst, reff676_op in H. discriminate H. Qed.

Lemma reff676_not1275 : ~ @Equation1275 Fin5 reff676_inst.
Proof. unfold Equation1275. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff676_inst, reff676_op in H. discriminate H. Qed.

Lemma reff676_not1276 : ~ @Equation1276 Fin5 reff676_inst.
Proof. unfold Equation1276. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff676_inst, reff676_op in H. discriminate H. Qed.

Lemma reff676_not1279 : ~ @Equation1279 Fin5 reff676_inst.
Proof. unfold Equation1279. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff676_inst, reff676_op in H. discriminate H. Qed.

Lemma reff676_not1285 : ~ @Equation1285 Fin5 reff676_inst.
Proof. unfold Equation1285. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff676_inst, reff676_op in H. discriminate H. Qed.

Lemma reff676_not1286 : ~ @Equation1286 Fin5 reff676_inst.
Proof. unfold Equation1286. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff676_inst, reff676_op in H. discriminate H. Qed.

Lemma reff676_not1288 : ~ @Equation1288 Fin5 reff676_inst.
Proof. unfold Equation1288. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff676_inst, reff676_op in H. discriminate H. Qed.

Lemma reff676_not1289 : ~ @Equation1289 Fin5 reff676_inst.
Proof. unfold Equation1289. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff676_inst, reff676_op in H. discriminate H. Qed.

Lemma reff676_not1312 : ~ @Equation1312 Fin5 reff676_inst.
Proof. unfold Equation1312. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff676_inst, reff676_op in H. discriminate H. Qed.

Lemma reff676_not1313 : ~ @Equation1313 Fin5 reff676_inst.
Proof. unfold Equation1313. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff676_inst, reff676_op in H. discriminate H. Qed.

Lemma reff676_not1315 : ~ @Equation1315 Fin5 reff676_inst.
Proof. unfold Equation1315. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff676_inst, reff676_op in H. discriminate H. Qed.

Lemma reff676_not1316 : ~ @Equation1316 Fin5 reff676_inst.
Proof. unfold Equation1316. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff676_inst, reff676_op in H. discriminate H. Qed.

Lemma reff676_not1322 : ~ @Equation1322 Fin5 reff676_inst.
Proof. unfold Equation1322. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff676_inst, reff676_op in H. discriminate H. Qed.

Lemma reff676_not1325 : ~ @Equation1325 Fin5 reff676_inst.
Proof. unfold Equation1325. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff676_inst, reff676_op in H. discriminate H. Qed.

Lemma reff676_not1427 : ~ @Equation1427 Fin5 reff676_inst.
Proof. unfold Equation1427. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff676_inst, reff676_op in H. discriminate H. Qed.

Lemma reff676_not1428 : ~ @Equation1428 Fin5 reff676_inst.
Proof. unfold Equation1428. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff676_inst, reff676_op in H. discriminate H. Qed.

Lemma reff676_not1429 : ~ @Equation1429 Fin5 reff676_inst.
Proof. unfold Equation1429. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff676_inst, reff676_op in H. discriminate H. Qed.

Lemma reff676_not1431 : ~ @Equation1431 Fin5 reff676_inst.
Proof. unfold Equation1431. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff676_inst, reff676_op in H. discriminate H. Qed.

Lemma reff676_not1432 : ~ @Equation1432 Fin5 reff676_inst.
Proof. unfold Equation1432. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff676_inst, reff676_op in H. discriminate H. Qed.

Lemma reff676_not1434 : ~ @Equation1434 Fin5 reff676_inst.
Proof. unfold Equation1434. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff676_inst, reff676_op in H. discriminate H. Qed.

Lemma reff676_not1435 : ~ @Equation1435 Fin5 reff676_inst.
Proof. unfold Equation1435. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff676_inst, reff676_op in H. discriminate H. Qed.

Lemma reff676_not1441 : ~ @Equation1441 Fin5 reff676_inst.
Proof. unfold Equation1441. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff676_inst, reff676_op in H. discriminate H. Qed.

Lemma reff676_not1442 : ~ @Equation1442 Fin5 reff676_inst.
Proof. unfold Equation1442. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff676_inst, reff676_op in H. discriminate H. Qed.

Lemma reff676_not1444 : ~ @Equation1444 Fin5 reff676_inst.
Proof. unfold Equation1444. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff676_inst, reff676_op in H. discriminate H. Qed.

Lemma reff676_not1445 : ~ @Equation1445 Fin5 reff676_inst.
Proof. unfold Equation1445. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff676_inst, reff676_op in H. discriminate H. Qed.

Lemma reff676_not1451 : ~ @Equation1451 Fin5 reff676_inst.
Proof. unfold Equation1451. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff676_inst, reff676_op in H. discriminate H. Qed.

Lemma reff676_not1452 : ~ @Equation1452 Fin5 reff676_inst.
Proof. unfold Equation1452. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff676_inst, reff676_op in H. discriminate H. Qed.

Lemma reff676_not1454 : ~ @Equation1454 Fin5 reff676_inst.
Proof. unfold Equation1454. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff676_inst, reff676_op in H. discriminate H. Qed.

Lemma reff676_not1478 : ~ @Equation1478 Fin5 reff676_inst.
Proof. unfold Equation1478. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff676_inst, reff676_op in H. discriminate H. Qed.

Lemma reff676_not1479 : ~ @Equation1479 Fin5 reff676_inst.
Proof. unfold Equation1479. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff676_inst, reff676_op in H. discriminate H. Qed.

Lemma reff676_not1481 : ~ @Equation1481 Fin5 reff676_inst.
Proof. unfold Equation1481. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff676_inst, reff676_op in H. discriminate H. Qed.

Lemma reff676_not1488 : ~ @Equation1488 Fin5 reff676_inst.
Proof. unfold Equation1488. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff676_inst, reff676_op in H. discriminate H. Qed.

Lemma reff676_not1489 : ~ @Equation1489 Fin5 reff676_inst.
Proof. unfold Equation1489. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff676_inst, reff676_op in H. discriminate H. Qed.

Lemma reff676_not1492 : ~ @Equation1492 Fin5 reff676_inst.
Proof. unfold Equation1492. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff676_inst, reff676_op in H. discriminate H. Qed.

Lemma reff676_not1515 : ~ @Equation1515 Fin5 reff676_inst.
Proof. unfold Equation1515. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff676_inst, reff676_op in H. discriminate H. Qed.

Lemma reff676_not1516 : ~ @Equation1516 Fin5 reff676_inst.
Proof. unfold Equation1516. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff676_inst, reff676_op in H. discriminate H. Qed.

Lemma reff676_not1519 : ~ @Equation1519 Fin5 reff676_inst.
Proof. unfold Equation1519. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff676_inst, reff676_op in H. discriminate H. Qed.

Lemma reff676_not1525 : ~ @Equation1525 Fin5 reff676_inst.
Proof. unfold Equation1525. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff676_inst, reff676_op in H. discriminate H. Qed.

Lemma reff676_not1528 : ~ @Equation1528 Fin5 reff676_inst.
Proof. unfold Equation1528. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff676_inst, reff676_op in H. discriminate H. Qed.

Lemma reff676_not1630 : ~ @Equation1630 Fin5 reff676_inst.
Proof. unfold Equation1630. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff676_inst, reff676_op in H. discriminate H. Qed.

Lemma reff676_not1631 : ~ @Equation1631 Fin5 reff676_inst.
Proof. unfold Equation1631. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff676_inst, reff676_op in H. discriminate H. Qed.

Lemma reff676_not1634 : ~ @Equation1634 Fin5 reff676_inst.
Proof. unfold Equation1634. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff676_inst, reff676_op in H. discriminate H. Qed.

Lemma reff676_not1635 : ~ @Equation1635 Fin5 reff676_inst.
Proof. unfold Equation1635. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff676_inst, reff676_op in H. discriminate H. Qed.

Lemma reff676_not1637 : ~ @Equation1637 Fin5 reff676_inst.
Proof. unfold Equation1637. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff676_inst, reff676_op in H. discriminate H. Qed.

Lemma reff676_not1638 : ~ @Equation1638 Fin5 reff676_inst.
Proof. unfold Equation1638. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff676_inst, reff676_op in H. discriminate H. Qed.

Lemma reff676_not1644 : ~ @Equation1644 Fin5 reff676_inst.
Proof. unfold Equation1644. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff676_inst, reff676_op in H. discriminate H. Qed.

Lemma reff676_not1645 : ~ @Equation1645 Fin5 reff676_inst.
Proof. unfold Equation1645. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff676_inst, reff676_op in H. discriminate H. Qed.

Lemma reff676_not1647 : ~ @Equation1647 Fin5 reff676_inst.
Proof. unfold Equation1647. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff676_inst, reff676_op in H. discriminate H. Qed.

Lemma reff676_not1648 : ~ @Equation1648 Fin5 reff676_inst.
Proof. unfold Equation1648. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff676_inst, reff676_op in H. discriminate H. Qed.

Lemma reff676_not1655 : ~ @Equation1655 Fin5 reff676_inst.
Proof. unfold Equation1655. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff676_inst, reff676_op in H. discriminate H. Qed.

Lemma reff676_not1657 : ~ @Equation1657 Fin5 reff676_inst.
Proof. unfold Equation1657. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff676_inst, reff676_op in H. discriminate H. Qed.

Lemma reff676_not1681 : ~ @Equation1681 Fin5 reff676_inst.
Proof. unfold Equation1681. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff676_inst, reff676_op in H. discriminate H. Qed.

Lemma reff676_not1684 : ~ @Equation1684 Fin5 reff676_inst.
Proof. unfold Equation1684. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff676_inst, reff676_op in H. discriminate H. Qed.

Lemma reff676_not1685 : ~ @Equation1685 Fin5 reff676_inst.
Proof. unfold Equation1685. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff676_inst, reff676_op in H. discriminate H. Qed.

Lemma reff676_not1691 : ~ @Equation1691 Fin5 reff676_inst.
Proof. unfold Equation1691. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff676_inst, reff676_op in H. discriminate H. Qed.

Lemma reff676_not1692 : ~ @Equation1692 Fin5 reff676_inst.
Proof. unfold Equation1692. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff676_inst, reff676_op in H. discriminate H. Qed.

Lemma reff676_not1694 : ~ @Equation1694 Fin5 reff676_inst.
Proof. unfold Equation1694. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff676_inst, reff676_op in H. discriminate H. Qed.

Lemma reff676_not1695 : ~ @Equation1695 Fin5 reff676_inst.
Proof. unfold Equation1695. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff676_inst, reff676_op in H. discriminate H. Qed.

Lemma reff676_not1718 : ~ @Equation1718 Fin5 reff676_inst.
Proof. unfold Equation1718. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff676_inst, reff676_op in H. discriminate H. Qed.

Lemma reff676_not1719 : ~ @Equation1719 Fin5 reff676_inst.
Proof. unfold Equation1719. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff676_inst, reff676_op in H. discriminate H. Qed.

Lemma reff676_not1722 : ~ @Equation1722 Fin5 reff676_inst.
Proof. unfold Equation1722. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff676_inst, reff676_op in H. discriminate H. Qed.

Lemma reff676_not1728 : ~ @Equation1728 Fin5 reff676_inst.
Proof. unfold Equation1728. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff676_inst, reff676_op in H. discriminate H. Qed.

Lemma reff676_not1731 : ~ @Equation1731 Fin5 reff676_inst.
Proof. unfold Equation1731. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff676_inst, reff676_op in H. discriminate H. Qed.

Lemma reff676_not1833 : ~ @Equation1833 Fin5 reff676_inst.
Proof. unfold Equation1833. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff676_inst, reff676_op in H. discriminate H. Qed.

Lemma reff676_not1834 : ~ @Equation1834 Fin5 reff676_inst.
Proof. unfold Equation1834. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff676_inst, reff676_op in H. discriminate H. Qed.

Lemma reff676_not1835 : ~ @Equation1835 Fin5 reff676_inst.
Proof. unfold Equation1835. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff676_inst, reff676_op in H. discriminate H. Qed.

Lemma reff676_not1837 : ~ @Equation1837 Fin5 reff676_inst.
Proof. unfold Equation1837. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff676_inst, reff676_op in H. discriminate H. Qed.

Lemma reff676_not1840 : ~ @Equation1840 Fin5 reff676_inst.
Proof. unfold Equation1840. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff676_inst, reff676_op in H. discriminate H. Qed.

Lemma reff676_not1841 : ~ @Equation1841 Fin5 reff676_inst.
Proof. unfold Equation1841. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff676_inst, reff676_op in H. discriminate H. Qed.

Lemma reff676_not1847 : ~ @Equation1847 Fin5 reff676_inst.
Proof. unfold Equation1847. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff676_inst, reff676_op in H. discriminate H. Qed.

Lemma reff676_not1848 : ~ @Equation1848 Fin5 reff676_inst.
Proof. unfold Equation1848. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff676_inst, reff676_op in H. discriminate H. Qed.

Lemma reff676_not1851 : ~ @Equation1851 Fin5 reff676_inst.
Proof. unfold Equation1851. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff676_inst, reff676_op in H. discriminate H. Qed.

Lemma reff676_not1857 : ~ @Equation1857 Fin5 reff676_inst.
Proof. unfold Equation1857. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff676_inst, reff676_op in H. discriminate H. Qed.

Lemma reff676_not1858 : ~ @Equation1858 Fin5 reff676_inst.
Proof. unfold Equation1858. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff676_inst, reff676_op in H. discriminate H. Qed.

Lemma reff676_not1860 : ~ @Equation1860 Fin5 reff676_inst.
Proof. unfold Equation1860. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff676_inst, reff676_op in H. discriminate H. Qed.

Lemma reff676_not1884 : ~ @Equation1884 Fin5 reff676_inst.
Proof. unfold Equation1884. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff676_inst, reff676_op in H. discriminate H. Qed.

Lemma reff676_not1887 : ~ @Equation1887 Fin5 reff676_inst.
Proof. unfold Equation1887. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff676_inst, reff676_op in H. discriminate H. Qed.

Lemma reff676_not1888 : ~ @Equation1888 Fin5 reff676_inst.
Proof. unfold Equation1888. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff676_inst, reff676_op in H. discriminate H. Qed.

Lemma reff676_not1894 : ~ @Equation1894 Fin5 reff676_inst.
Proof. unfold Equation1894. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff676_inst, reff676_op in H. discriminate H. Qed.

Lemma reff676_not1895 : ~ @Equation1895 Fin5 reff676_inst.
Proof. unfold Equation1895. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff676_inst, reff676_op in H. discriminate H. Qed.

Lemma reff676_not1898 : ~ @Equation1898 Fin5 reff676_inst.
Proof. unfold Equation1898. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff676_inst, reff676_op in H. discriminate H. Qed.

Lemma reff676_not1921 : ~ @Equation1921 Fin5 reff676_inst.
Proof. unfold Equation1921. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff676_inst, reff676_op in H. discriminate H. Qed.

Lemma reff676_not1922 : ~ @Equation1922 Fin5 reff676_inst.
Proof. unfold Equation1922. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff676_inst, reff676_op in H. discriminate H. Qed.

Lemma reff676_not1924 : ~ @Equation1924 Fin5 reff676_inst.
Proof. unfold Equation1924. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff676_inst, reff676_op in H. discriminate H. Qed.

Lemma reff676_not1931 : ~ @Equation1931 Fin5 reff676_inst.
Proof. unfold Equation1931. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff676_inst, reff676_op in H. discriminate H. Qed.

Lemma reff676_not1932 : ~ @Equation1932 Fin5 reff676_inst.
Proof. unfold Equation1932. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff676_inst, reff676_op in H. discriminate H. Qed.

Lemma reff676_not1934 : ~ @Equation1934 Fin5 reff676_inst.
Proof. unfold Equation1934. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff676_inst, reff676_op in H. discriminate H. Qed.

Lemma reff676_not2036 : ~ @Equation2036 Fin5 reff676_inst.
Proof. unfold Equation2036. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff676_inst, reff676_op in H. discriminate H. Qed.

Lemma reff676_not2037 : ~ @Equation2037 Fin5 reff676_inst.
Proof. unfold Equation2037. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff676_inst, reff676_op in H. discriminate H. Qed.

Lemma reff676_not2038 : ~ @Equation2038 Fin5 reff676_inst.
Proof. unfold Equation2038. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff676_inst, reff676_op in H. discriminate H. Qed.

Lemma reff676_not2040 : ~ @Equation2040 Fin5 reff676_inst.
Proof. unfold Equation2040. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff676_inst, reff676_op in H. discriminate H. Qed.

Lemma reff676_not2041 : ~ @Equation2041 Fin5 reff676_inst.
Proof. unfold Equation2041. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff676_inst, reff676_op in H. discriminate H. Qed.

Lemma reff676_not2043 : ~ @Equation2043 Fin5 reff676_inst.
Proof. unfold Equation2043. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff676_inst, reff676_op in H. discriminate H. Qed.

Lemma reff676_not2050 : ~ @Equation2050 Fin5 reff676_inst.
Proof. unfold Equation2050. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff676_inst, reff676_op in H. discriminate H. Qed.

Lemma reff676_not2051 : ~ @Equation2051 Fin5 reff676_inst.
Proof. unfold Equation2051. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff676_inst, reff676_op in H. discriminate H. Qed.

Lemma reff676_not2054 : ~ @Equation2054 Fin5 reff676_inst.
Proof. unfold Equation2054. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff676_inst, reff676_op in H. discriminate H. Qed.

Lemma reff676_not2061 : ~ @Equation2061 Fin5 reff676_inst.
Proof. unfold Equation2061. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff676_inst, reff676_op in H. discriminate H. Qed.

Lemma reff676_not2063 : ~ @Equation2063 Fin5 reff676_inst.
Proof. unfold Equation2063. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff676_inst, reff676_op in H. discriminate H. Qed.

Lemma reff676_not2064 : ~ @Equation2064 Fin5 reff676_inst.
Proof. unfold Equation2064. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff676_inst, reff676_op in H. discriminate H. Qed.

Lemma reff676_not2087 : ~ @Equation2087 Fin5 reff676_inst.
Proof. unfold Equation2087. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff676_inst, reff676_op in H. discriminate H. Qed.

Lemma reff676_not2088 : ~ @Equation2088 Fin5 reff676_inst.
Proof. unfold Equation2088. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff676_inst, reff676_op in H. discriminate H. Qed.

Lemma reff676_not2090 : ~ @Equation2090 Fin5 reff676_inst.
Proof. unfold Equation2090. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff676_inst, reff676_op in H. discriminate H. Qed.

Lemma reff676_not2091 : ~ @Equation2091 Fin5 reff676_inst.
Proof. unfold Equation2091. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff676_inst, reff676_op in H. discriminate H. Qed.

Lemma reff676_not2097 : ~ @Equation2097 Fin5 reff676_inst.
Proof. unfold Equation2097. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff676_inst, reff676_op in H. discriminate H. Qed.

Lemma reff676_not2098 : ~ @Equation2098 Fin5 reff676_inst.
Proof. unfold Equation2098. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff676_inst, reff676_op in H. discriminate H. Qed.

Lemma reff676_not2101 : ~ @Equation2101 Fin5 reff676_inst.
Proof. unfold Equation2101. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff676_inst, reff676_op in H. discriminate H. Qed.

Lemma reff676_not2124 : ~ @Equation2124 Fin5 reff676_inst.
Proof. unfold Equation2124. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff676_inst, reff676_op in H. discriminate H. Qed.

Lemma reff676_not2127 : ~ @Equation2127 Fin5 reff676_inst.
Proof. unfold Equation2127. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff676_inst, reff676_op in H. discriminate H. Qed.

Lemma reff676_not2128 : ~ @Equation2128 Fin5 reff676_inst.
Proof. unfold Equation2128. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff676_inst, reff676_op in H. discriminate H. Qed.

Lemma reff676_not2134 : ~ @Equation2134 Fin5 reff676_inst.
Proof. unfold Equation2134. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff676_inst, reff676_op in H. discriminate H. Qed.

Lemma reff676_not2135 : ~ @Equation2135 Fin5 reff676_inst.
Proof. unfold Equation2135. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff676_inst, reff676_op in H. discriminate H. Qed.

Lemma reff676_not2137 : ~ @Equation2137 Fin5 reff676_inst.
Proof. unfold Equation2137. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff676_inst, reff676_op in H. discriminate H. Qed.

Lemma reff676_not2239 : ~ @Equation2239 Fin5 reff676_inst.
Proof. unfold Equation2239. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff676_inst, reff676_op in H. discriminate H. Qed.

Lemma reff676_not2240 : ~ @Equation2240 Fin5 reff676_inst.
Proof. unfold Equation2240. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff676_inst, reff676_op in H. discriminate H. Qed.

Lemma reff676_not2241 : ~ @Equation2241 Fin5 reff676_inst.
Proof. unfold Equation2241. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff676_inst, reff676_op in H. discriminate H. Qed.

Lemma reff676_not2243 : ~ @Equation2243 Fin5 reff676_inst.
Proof. unfold Equation2243. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff676_inst, reff676_op in H. discriminate H. Qed.

Lemma reff676_not2244 : ~ @Equation2244 Fin5 reff676_inst.
Proof. unfold Equation2244. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff676_inst, reff676_op in H. discriminate H. Qed.

Lemma reff676_not2246 : ~ @Equation2246 Fin5 reff676_inst.
Proof. unfold Equation2246. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff676_inst, reff676_op in H. discriminate H. Qed.

Lemma reff676_not2247 : ~ @Equation2247 Fin5 reff676_inst.
Proof. unfold Equation2247. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff676_inst, reff676_op in H. discriminate H. Qed.

Lemma reff676_not2253 : ~ @Equation2253 Fin5 reff676_inst.
Proof. unfold Equation2253. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff676_inst, reff676_op in H. discriminate H. Qed.

Lemma reff676_not2254 : ~ @Equation2254 Fin5 reff676_inst.
Proof. unfold Equation2254. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff676_inst, reff676_op in H. discriminate H. Qed.

Lemma reff676_not2256 : ~ @Equation2256 Fin5 reff676_inst.
Proof. unfold Equation2256. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff676_inst, reff676_op in H. discriminate H. Qed.

Lemma reff676_not2257 : ~ @Equation2257 Fin5 reff676_inst.
Proof. unfold Equation2257. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff676_inst, reff676_op in H. discriminate H. Qed.

Lemma reff676_not2263 : ~ @Equation2263 Fin5 reff676_inst.
Proof. unfold Equation2263. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff676_inst, reff676_op in H. discriminate H. Qed.

Lemma reff676_not2264 : ~ @Equation2264 Fin5 reff676_inst.
Proof. unfold Equation2264. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff676_inst, reff676_op in H. discriminate H. Qed.

Lemma reff676_not2266 : ~ @Equation2266 Fin5 reff676_inst.
Proof. unfold Equation2266. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff676_inst, reff676_op in H. discriminate H. Qed.

Lemma reff676_not2290 : ~ @Equation2290 Fin5 reff676_inst.
Proof. unfold Equation2290. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff676_inst, reff676_op in H. discriminate H. Qed.

Lemma reff676_not2291 : ~ @Equation2291 Fin5 reff676_inst.
Proof. unfold Equation2291. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff676_inst, reff676_op in H. discriminate H. Qed.

Lemma reff676_not2293 : ~ @Equation2293 Fin5 reff676_inst.
Proof. unfold Equation2293. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff676_inst, reff676_op in H. discriminate H. Qed.

Lemma reff676_not2301 : ~ @Equation2301 Fin5 reff676_inst.
Proof. unfold Equation2301. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff676_inst, reff676_op in H. discriminate H. Qed.

Lemma reff676_not2303 : ~ @Equation2303 Fin5 reff676_inst.
Proof. unfold Equation2303. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff676_inst, reff676_op in H. discriminate H. Qed.

Lemma reff676_not2304 : ~ @Equation2304 Fin5 reff676_inst.
Proof. unfold Equation2304. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff676_inst, reff676_op in H. discriminate H. Qed.

Lemma reff676_not2327 : ~ @Equation2327 Fin5 reff676_inst.
Proof. unfold Equation2327. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff676_inst, reff676_op in H. discriminate H. Qed.

Lemma reff676_not2331 : ~ @Equation2331 Fin5 reff676_inst.
Proof. unfold Equation2331. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff676_inst, reff676_op in H. discriminate H. Qed.

Lemma reff676_not2337 : ~ @Equation2337 Fin5 reff676_inst.
Proof. unfold Equation2337. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff676_inst, reff676_op in H. discriminate H. Qed.

Lemma reff676_not2338 : ~ @Equation2338 Fin5 reff676_inst.
Proof. unfold Equation2338. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff676_inst, reff676_op in H. discriminate H. Qed.

Lemma reff676_not2340 : ~ @Equation2340 Fin5 reff676_inst.
Proof. unfold Equation2340. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff676_inst, reff676_op in H. discriminate H. Qed.

Lemma reff676_not2442 : ~ @Equation2442 Fin5 reff676_inst.
Proof. unfold Equation2442. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff676_inst, reff676_op in H. discriminate H. Qed.

Lemma reff676_not2443 : ~ @Equation2443 Fin5 reff676_inst.
Proof. unfold Equation2443. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff676_inst, reff676_op in H. discriminate H. Qed.

Lemma reff676_not2444 : ~ @Equation2444 Fin5 reff676_inst.
Proof. unfold Equation2444. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff676_inst, reff676_op in H. discriminate H. Qed.

Lemma reff676_not2446 : ~ @Equation2446 Fin5 reff676_inst.
Proof. unfold Equation2446. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff676_inst, reff676_op in H. discriminate H. Qed.

Lemma reff676_not2447 : ~ @Equation2447 Fin5 reff676_inst.
Proof. unfold Equation2447. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff676_inst, reff676_op in H. discriminate H. Qed.

Lemma reff676_not2450 : ~ @Equation2450 Fin5 reff676_inst.
Proof. unfold Equation2450. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff676_inst, reff676_op in H. discriminate H. Qed.

Lemma reff676_not2456 : ~ @Equation2456 Fin5 reff676_inst.
Proof. unfold Equation2456. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff676_inst, reff676_op in H. discriminate H. Qed.

Lemma reff676_not2459 : ~ @Equation2459 Fin5 reff676_inst.
Proof. unfold Equation2459. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff676_inst, reff676_op in H. discriminate H. Qed.

Lemma reff676_not2460 : ~ @Equation2460 Fin5 reff676_inst.
Proof. unfold Equation2460. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff676_inst, reff676_op in H. discriminate H. Qed.

Lemma reff676_not2466 : ~ @Equation2466 Fin5 reff676_inst.
Proof. unfold Equation2466. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff676_inst, reff676_op in H. discriminate H. Qed.

Lemma reff676_not2467 : ~ @Equation2467 Fin5 reff676_inst.
Proof. unfold Equation2467. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff676_inst, reff676_op in H. discriminate H. Qed.

Lemma reff676_not2469 : ~ @Equation2469 Fin5 reff676_inst.
Proof. unfold Equation2469. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff676_inst, reff676_op in H. discriminate H. Qed.

Lemma reff676_not2493 : ~ @Equation2493 Fin5 reff676_inst.
Proof. unfold Equation2493. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff676_inst, reff676_op in H. discriminate H. Qed.

Lemma reff676_not2494 : ~ @Equation2494 Fin5 reff676_inst.
Proof. unfold Equation2494. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff676_inst, reff676_op in H. discriminate H. Qed.

Lemma reff676_not2496 : ~ @Equation2496 Fin5 reff676_inst.
Proof. unfold Equation2496. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff676_inst, reff676_op in H. discriminate H. Qed.

Lemma reff676_not2497 : ~ @Equation2497 Fin5 reff676_inst.
Proof. unfold Equation2497. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff676_inst, reff676_op in H. discriminate H. Qed.

Lemma reff676_not2504 : ~ @Equation2504 Fin5 reff676_inst.
Proof. unfold Equation2504. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff676_inst, reff676_op in H. discriminate H. Qed.

Lemma reff676_not2506 : ~ @Equation2506 Fin5 reff676_inst.
Proof. unfold Equation2506. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff676_inst, reff676_op in H. discriminate H. Qed.

Lemma reff676_not2507 : ~ @Equation2507 Fin5 reff676_inst.
Proof. unfold Equation2507. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff676_inst, reff676_op in H. discriminate H. Qed.

Lemma reff676_not2530 : ~ @Equation2530 Fin5 reff676_inst.
Proof. unfold Equation2530. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff676_inst, reff676_op in H. discriminate H. Qed.

Lemma reff676_not2531 : ~ @Equation2531 Fin5 reff676_inst.
Proof. unfold Equation2531. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff676_inst, reff676_op in H. discriminate H. Qed.

Lemma reff676_not2534 : ~ @Equation2534 Fin5 reff676_inst.
Proof. unfold Equation2534. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff676_inst, reff676_op in H. discriminate H. Qed.

Lemma reff676_not2540 : ~ @Equation2540 Fin5 reff676_inst.
Proof. unfold Equation2540. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff676_inst, reff676_op in H. discriminate H. Qed.

Lemma reff676_not2543 : ~ @Equation2543 Fin5 reff676_inst.
Proof. unfold Equation2543. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff676_inst, reff676_op in H. discriminate H. Qed.

Lemma reff676_not2645 : ~ @Equation2645 Fin5 reff676_inst.
Proof. unfold Equation2645. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff676_inst, reff676_op in H. discriminate H. Qed.

Lemma reff676_not2646 : ~ @Equation2646 Fin5 reff676_inst.
Proof. unfold Equation2646. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff676_inst, reff676_op in H. discriminate H. Qed.

Lemma reff676_not2647 : ~ @Equation2647 Fin5 reff676_inst.
Proof. unfold Equation2647. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff676_inst, reff676_op in H. discriminate H. Qed.

Lemma reff676_not2649 : ~ @Equation2649 Fin5 reff676_inst.
Proof. unfold Equation2649. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff676_inst, reff676_op in H. discriminate H. Qed.

Lemma reff676_not2650 : ~ @Equation2650 Fin5 reff676_inst.
Proof. unfold Equation2650. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff676_inst, reff676_op in H. discriminate H. Qed.

Lemma reff676_not2652 : ~ @Equation2652 Fin5 reff676_inst.
Proof. unfold Equation2652. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff676_inst, reff676_op in H. discriminate H. Qed.

Lemma reff676_not2659 : ~ @Equation2659 Fin5 reff676_inst.
Proof. unfold Equation2659. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff676_inst, reff676_op in H. discriminate H. Qed.

Lemma reff676_not2660 : ~ @Equation2660 Fin5 reff676_inst.
Proof. unfold Equation2660. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff676_inst, reff676_op in H. discriminate H. Qed.

Lemma reff676_not2662 : ~ @Equation2662 Fin5 reff676_inst.
Proof. unfold Equation2662. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff676_inst, reff676_op in H. discriminate H. Qed.

Lemma reff676_not2669 : ~ @Equation2669 Fin5 reff676_inst.
Proof. unfold Equation2669. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff676_inst, reff676_op in H. discriminate H. Qed.

Lemma reff676_not2670 : ~ @Equation2670 Fin5 reff676_inst.
Proof. unfold Equation2670. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff676_inst, reff676_op in H. discriminate H. Qed.

Lemma reff676_not2673 : ~ @Equation2673 Fin5 reff676_inst.
Proof. unfold Equation2673. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff676_inst, reff676_op in H. discriminate H. Qed.

Lemma reff676_not2696 : ~ @Equation2696 Fin5 reff676_inst.
Proof. unfold Equation2696. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff676_inst, reff676_op in H. discriminate H. Qed.

Lemma reff676_not2697 : ~ @Equation2697 Fin5 reff676_inst.
Proof. unfold Equation2697. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff676_inst, reff676_op in H. discriminate H. Qed.

Lemma reff676_not2700 : ~ @Equation2700 Fin5 reff676_inst.
Proof. unfold Equation2700. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff676_inst, reff676_op in H. discriminate H. Qed.

Lemma reff676_not2706 : ~ @Equation2706 Fin5 reff676_inst.
Proof. unfold Equation2706. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff676_inst, reff676_op in H. discriminate H. Qed.

Lemma reff676_not2707 : ~ @Equation2707 Fin5 reff676_inst.
Proof. unfold Equation2707. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff676_inst, reff676_op in H. discriminate H. Qed.

Lemma reff676_not2709 : ~ @Equation2709 Fin5 reff676_inst.
Proof. unfold Equation2709. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff676_inst, reff676_op in H. discriminate H. Qed.

Lemma reff676_not2710 : ~ @Equation2710 Fin5 reff676_inst.
Proof. unfold Equation2710. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff676_inst, reff676_op in H. discriminate H. Qed.

Lemma reff676_not2733 : ~ @Equation2733 Fin5 reff676_inst.
Proof. unfold Equation2733. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff676_inst, reff676_op in H. discriminate H. Qed.

Lemma reff676_not2734 : ~ @Equation2734 Fin5 reff676_inst.
Proof. unfold Equation2734. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff676_inst, reff676_op in H. discriminate H. Qed.

Lemma reff676_not2736 : ~ @Equation2736 Fin5 reff676_inst.
Proof. unfold Equation2736. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff676_inst, reff676_op in H. discriminate H. Qed.

Lemma reff676_not2737 : ~ @Equation2737 Fin5 reff676_inst.
Proof. unfold Equation2737. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff676_inst, reff676_op in H. discriminate H. Qed.

Lemma reff676_not2743 : ~ @Equation2743 Fin5 reff676_inst.
Proof. unfold Equation2743. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff676_inst, reff676_op in H. discriminate H. Qed.

Lemma reff676_not2746 : ~ @Equation2746 Fin5 reff676_inst.
Proof. unfold Equation2746. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff676_inst, reff676_op in H. discriminate H. Qed.

Lemma reff676_not2848 : ~ @Equation2848 Fin5 reff676_inst.
Proof. unfold Equation2848. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff676_inst, reff676_op in H. discriminate H. Qed.

Lemma reff676_not2849 : ~ @Equation2849 Fin5 reff676_inst.
Proof. unfold Equation2849. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff676_inst, reff676_op in H. discriminate H. Qed.

Lemma reff676_not2852 : ~ @Equation2852 Fin5 reff676_inst.
Proof. unfold Equation2852. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff676_inst, reff676_op in H. discriminate H. Qed.

Lemma reff676_not2853 : ~ @Equation2853 Fin5 reff676_inst.
Proof. unfold Equation2853. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff676_inst, reff676_op in H. discriminate H. Qed.

Lemma reff676_not2855 : ~ @Equation2855 Fin5 reff676_inst.
Proof. unfold Equation2855. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff676_inst, reff676_op in H. discriminate H. Qed.

Lemma reff676_not2856 : ~ @Equation2856 Fin5 reff676_inst.
Proof. unfold Equation2856. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff676_inst, reff676_op in H. discriminate H. Qed.

Lemma reff676_not2862 : ~ @Equation2862 Fin5 reff676_inst.
Proof. unfold Equation2862. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff676_inst, reff676_op in H. discriminate H. Qed.

Lemma reff676_not2865 : ~ @Equation2865 Fin5 reff676_inst.
Proof. unfold Equation2865. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff676_inst, reff676_op in H. discriminate H. Qed.

Lemma reff676_not2866 : ~ @Equation2866 Fin5 reff676_inst.
Proof. unfold Equation2866. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff676_inst, reff676_op in H. discriminate H. Qed.

Lemma reff676_not2872 : ~ @Equation2872 Fin5 reff676_inst.
Proof. unfold Equation2872. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff676_inst, reff676_op in H. discriminate H. Qed.

Lemma reff676_not2873 : ~ @Equation2873 Fin5 reff676_inst.
Proof. unfold Equation2873. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff676_inst, reff676_op in H. discriminate H. Qed.

Lemma reff676_not2876 : ~ @Equation2876 Fin5 reff676_inst.
Proof. unfold Equation2876. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff676_inst, reff676_op in H. discriminate H. Qed.

Lemma reff676_not2899 : ~ @Equation2899 Fin5 reff676_inst.
Proof. unfold Equation2899. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff676_inst, reff676_op in H. discriminate H. Qed.

Lemma reff676_not2900 : ~ @Equation2900 Fin5 reff676_inst.
Proof. unfold Equation2900. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff676_inst, reff676_op in H. discriminate H. Qed.

Lemma reff676_not2902 : ~ @Equation2902 Fin5 reff676_inst.
Proof. unfold Equation2902. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff676_inst, reff676_op in H. discriminate H. Qed.

Lemma reff676_not2903 : ~ @Equation2903 Fin5 reff676_inst.
Proof. unfold Equation2903. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff676_inst, reff676_op in H. discriminate H. Qed.

Lemma reff676_not2909 : ~ @Equation2909 Fin5 reff676_inst.
Proof. unfold Equation2909. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff676_inst, reff676_op in H. discriminate H. Qed.

Lemma reff676_not2912 : ~ @Equation2912 Fin5 reff676_inst.
Proof. unfold Equation2912. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff676_inst, reff676_op in H. discriminate H. Qed.

Lemma reff676_not2913 : ~ @Equation2913 Fin5 reff676_inst.
Proof. unfold Equation2913. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff676_inst, reff676_op in H. discriminate H. Qed.

Lemma reff676_not2936 : ~ @Equation2936 Fin5 reff676_inst.
Proof. unfold Equation2936. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff676_inst, reff676_op in H. discriminate H. Qed.

Lemma reff676_not2937 : ~ @Equation2937 Fin5 reff676_inst.
Proof. unfold Equation2937. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff676_inst, reff676_op in H. discriminate H. Qed.

Lemma reff676_not2940 : ~ @Equation2940 Fin5 reff676_inst.
Proof. unfold Equation2940. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff676_inst, reff676_op in H. discriminate H. Qed.

Lemma reff676_not2946 : ~ @Equation2946 Fin5 reff676_inst.
Proof. unfold Equation2946. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff676_inst, reff676_op in H. discriminate H. Qed.

Lemma reff676_not2947 : ~ @Equation2947 Fin5 reff676_inst.
Proof. unfold Equation2947. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff676_inst, reff676_op in H. discriminate H. Qed.

Lemma reff676_not2949 : ~ @Equation2949 Fin5 reff676_inst.
Proof. unfold Equation2949. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff676_inst, reff676_op in H. discriminate H. Qed.

Lemma reff676_not3051 : ~ @Equation3051 Fin5 reff676_inst.
Proof. unfold Equation3051. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff676_inst, reff676_op in H. discriminate H. Qed.

Lemma reff676_not3052 : ~ @Equation3052 Fin5 reff676_inst.
Proof. unfold Equation3052. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff676_inst, reff676_op in H. discriminate H. Qed.

Lemma reff676_not3055 : ~ @Equation3055 Fin5 reff676_inst.
Proof. unfold Equation3055. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff676_inst, reff676_op in H. discriminate H. Qed.

Lemma reff676_not3056 : ~ @Equation3056 Fin5 reff676_inst.
Proof. unfold Equation3056. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff676_inst, reff676_op in H. discriminate H. Qed.

Lemma reff676_not3059 : ~ @Equation3059 Fin5 reff676_inst.
Proof. unfold Equation3059. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff676_inst, reff676_op in H. discriminate H. Qed.

Lemma reff676_not3065 : ~ @Equation3065 Fin5 reff676_inst.
Proof. unfold Equation3065. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff676_inst, reff676_op in H. discriminate H. Qed.

Lemma reff676_not3068 : ~ @Equation3068 Fin5 reff676_inst.
Proof. unfold Equation3068. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff676_inst, reff676_op in H. discriminate H. Qed.

Lemma reff676_not3069 : ~ @Equation3069 Fin5 reff676_inst.
Proof. unfold Equation3069. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff676_inst, reff676_op in H. discriminate H. Qed.

Lemma reff676_not3076 : ~ @Equation3076 Fin5 reff676_inst.
Proof. unfold Equation3076. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff676_inst, reff676_op in H. discriminate H. Qed.

Lemma reff676_not3078 : ~ @Equation3078 Fin5 reff676_inst.
Proof. unfold Equation3078. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff676_inst, reff676_op in H. discriminate H. Qed.

Lemma reff676_not3102 : ~ @Equation3102 Fin5 reff676_inst.
Proof. unfold Equation3102. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff676_inst, reff676_op in H. discriminate H. Qed.

Lemma reff676_not3103 : ~ @Equation3103 Fin5 reff676_inst.
Proof. unfold Equation3103. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff676_inst, reff676_op in H. discriminate H. Qed.

Lemma reff676_not3105 : ~ @Equation3105 Fin5 reff676_inst.
Proof. unfold Equation3105. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff676_inst, reff676_op in H. discriminate H. Qed.

Lemma reff676_not3106 : ~ @Equation3106 Fin5 reff676_inst.
Proof. unfold Equation3106. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff676_inst, reff676_op in H. discriminate H. Qed.

Lemma reff676_not3112 : ~ @Equation3112 Fin5 reff676_inst.
Proof. unfold Equation3112. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff676_inst, reff676_op in H. discriminate H. Qed.

Lemma reff676_not3115 : ~ @Equation3115 Fin5 reff676_inst.
Proof. unfold Equation3115. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff676_inst, reff676_op in H. discriminate H. Qed.

Lemma reff676_not3116 : ~ @Equation3116 Fin5 reff676_inst.
Proof. unfold Equation3116. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff676_inst, reff676_op in H. discriminate H. Qed.

Lemma reff676_not3139 : ~ @Equation3139 Fin5 reff676_inst.
Proof. unfold Equation3139. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff676_inst, reff676_op in H. discriminate H. Qed.

Lemma reff676_not3140 : ~ @Equation3140 Fin5 reff676_inst.
Proof. unfold Equation3140. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff676_inst, reff676_op in H. discriminate H. Qed.

Lemma reff676_not3142 : ~ @Equation3142 Fin5 reff676_inst.
Proof. unfold Equation3142. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff676_inst, reff676_op in H. discriminate H. Qed.

Lemma reff676_not3143 : ~ @Equation3143 Fin5 reff676_inst.
Proof. unfold Equation3143. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff676_inst, reff676_op in H. discriminate H. Qed.

Lemma reff676_not3149 : ~ @Equation3149 Fin5 reff676_inst.
Proof. unfold Equation3149. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff676_inst, reff676_op in H. discriminate H. Qed.

Lemma reff676_not3150 : ~ @Equation3150 Fin5 reff676_inst.
Proof. unfold Equation3150. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff676_inst, reff676_op in H. discriminate H. Qed.

Lemma reff676_not3152 : ~ @Equation3152 Fin5 reff676_inst.
Proof. unfold Equation3152. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff676_inst, reff676_op in H. discriminate H. Qed.

Lemma reff676_not3254 : ~ @Equation3254 Fin5 reff676_inst.
Proof. unfold Equation3254. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff676_inst, reff676_op in H. discriminate H. Qed.

Lemma reff676_not3255 : ~ @Equation3255 Fin5 reff676_inst.
Proof. unfold Equation3255. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff676_inst, reff676_op in H. discriminate H. Qed.

Lemma reff676_not3256 : ~ @Equation3256 Fin5 reff676_inst.
Proof. unfold Equation3256. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff676_inst, reff676_op in H. discriminate H. Qed.

Lemma reff676_not3258 : ~ @Equation3258 Fin5 reff676_inst.
Proof. unfold Equation3258. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff676_inst, reff676_op in H. discriminate H. Qed.

Lemma reff676_not3259 : ~ @Equation3259 Fin5 reff676_inst.
Proof. unfold Equation3259. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff676_inst, reff676_op in H. discriminate H. Qed.

Lemma reff676_not3261 : ~ @Equation3261 Fin5 reff676_inst.
Proof. unfold Equation3261. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff676_inst, reff676_op in H. discriminate H. Qed.

Lemma reff676_not3262 : ~ @Equation3262 Fin5 reff676_inst.
Proof. unfold Equation3262. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff676_inst, reff676_op in H. discriminate H. Qed.

Lemma reff676_not3268 : ~ @Equation3268 Fin5 reff676_inst.
Proof. unfold Equation3268. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff676_inst, reff676_op in H. discriminate H. Qed.

Lemma reff676_not3269 : ~ @Equation3269 Fin5 reff676_inst.
Proof. unfold Equation3269. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff676_inst, reff676_op in H. discriminate H. Qed.

Lemma reff676_not3272 : ~ @Equation3272 Fin5 reff676_inst.
Proof. unfold Equation3272. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff676_inst, reff676_op in H. discriminate H. Qed.

Lemma reff676_not3278 : ~ @Equation3278 Fin5 reff676_inst.
Proof. unfold Equation3278. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff676_inst, reff676_op in H. discriminate H. Qed.

Lemma reff676_not3281 : ~ @Equation3281 Fin5 reff676_inst.
Proof. unfold Equation3281. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff676_inst, reff676_op in H. discriminate H. Qed.

Lemma reff676_not3306 : ~ @Equation3306 Fin5 reff676_inst.
Proof. unfold Equation3306. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff676_inst, reff676_op in H. discriminate H. Qed.

Lemma reff676_not3308 : ~ @Equation3308 Fin5 reff676_inst.
Proof. unfold Equation3308. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff676_inst, reff676_op in H. discriminate H. Qed.

Lemma reff676_not3309 : ~ @Equation3309 Fin5 reff676_inst.
Proof. unfold Equation3309. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff676_inst, reff676_op in H. discriminate H. Qed.

Lemma reff676_not3315 : ~ @Equation3315 Fin5 reff676_inst.
Proof. unfold Equation3315. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff676_inst, reff676_op in H. discriminate H. Qed.

Lemma reff676_not3316 : ~ @Equation3316 Fin5 reff676_inst.
Proof. unfold Equation3316. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff676_inst, reff676_op in H. discriminate H. Qed.

Lemma reff676_not3318 : ~ @Equation3318 Fin5 reff676_inst.
Proof. unfold Equation3318. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff676_inst, reff676_op in H. discriminate H. Qed.

Lemma reff676_not3342 : ~ @Equation3342 Fin5 reff676_inst.
Proof. unfold Equation3342. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff676_inst, reff676_op in H. discriminate H. Qed.

Lemma reff676_not3345 : ~ @Equation3345 Fin5 reff676_inst.
Proof. unfold Equation3345. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff676_inst, reff676_op in H. discriminate H. Qed.

Lemma reff676_not3346 : ~ @Equation3346 Fin5 reff676_inst.
Proof. unfold Equation3346. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff676_inst, reff676_op in H. discriminate H. Qed.

Lemma reff676_not3353 : ~ @Equation3353 Fin5 reff676_inst.
Proof. unfold Equation3353. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff676_inst, reff676_op in H. discriminate H. Qed.

Lemma reff676_not3355 : ~ @Equation3355 Fin5 reff676_inst.
Proof. unfold Equation3355. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff676_inst, reff676_op in H. discriminate H. Qed.

Lemma reff676_not3457 : ~ @Equation3457 Fin5 reff676_inst.
Proof. unfold Equation3457. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff676_inst, reff676_op in H. discriminate H. Qed.

Lemma reff676_not3458 : ~ @Equation3458 Fin5 reff676_inst.
Proof. unfold Equation3458. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff676_inst, reff676_op in H. discriminate H. Qed.

Lemma reff676_not3461 : ~ @Equation3461 Fin5 reff676_inst.
Proof. unfold Equation3461. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff676_inst, reff676_op in H. discriminate H. Qed.

Lemma reff676_not3462 : ~ @Equation3462 Fin5 reff676_inst.
Proof. unfold Equation3462. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff676_inst, reff676_op in H. discriminate H. Qed.

Lemma reff676_not3464 : ~ @Equation3464 Fin5 reff676_inst.
Proof. unfold Equation3464. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff676_inst, reff676_op in H. discriminate H. Qed.

Lemma reff676_not3465 : ~ @Equation3465 Fin5 reff676_inst.
Proof. unfold Equation3465. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff676_inst, reff676_op in H. discriminate H. Qed.

Lemma reff676_not3472 : ~ @Equation3472 Fin5 reff676_inst.
Proof. unfold Equation3472. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff676_inst, reff676_op in H. discriminate H. Qed.

Lemma reff676_not3475 : ~ @Equation3475 Fin5 reff676_inst.
Proof. unfold Equation3475. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff676_inst, reff676_op in H. discriminate H. Qed.

Lemma reff676_not3481 : ~ @Equation3481 Fin5 reff676_inst.
Proof. unfold Equation3481. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff676_inst, reff676_op in H. discriminate H. Qed.

Lemma reff676_not3484 : ~ @Equation3484 Fin5 reff676_inst.
Proof. unfold Equation3484. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff676_inst, reff676_op in H. discriminate H. Qed.

Lemma reff676_not3509 : ~ @Equation3509 Fin5 reff676_inst.
Proof. unfold Equation3509. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff676_inst, reff676_op in H. discriminate H. Qed.

Lemma reff676_not3511 : ~ @Equation3511 Fin5 reff676_inst.
Proof. unfold Equation3511. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff676_inst, reff676_op in H. discriminate H. Qed.

Lemma reff676_not3512 : ~ @Equation3512 Fin5 reff676_inst.
Proof. unfold Equation3512. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff676_inst, reff676_op in H. discriminate H. Qed.

Lemma reff676_not3519 : ~ @Equation3519 Fin5 reff676_inst.
Proof. unfold Equation3519. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff676_inst, reff676_op in H. discriminate H. Qed.

Lemma reff676_not3521 : ~ @Equation3521 Fin5 reff676_inst.
Proof. unfold Equation3521. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff676_inst, reff676_op in H. discriminate H. Qed.

Lemma reff676_not3545 : ~ @Equation3545 Fin5 reff676_inst.
Proof. unfold Equation3545. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff676_inst, reff676_op in H. discriminate H. Qed.

Lemma reff676_not3546 : ~ @Equation3546 Fin5 reff676_inst.
Proof. unfold Equation3546. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff676_inst, reff676_op in H. discriminate H. Qed.

Lemma reff676_not3548 : ~ @Equation3548 Fin5 reff676_inst.
Proof. unfold Equation3548. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff676_inst, reff676_op in H. discriminate H. Qed.

Lemma reff676_not3549 : ~ @Equation3549 Fin5 reff676_inst.
Proof. unfold Equation3549. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff676_inst, reff676_op in H. discriminate H. Qed.

Lemma reff676_not3555 : ~ @Equation3555 Fin5 reff676_inst.
Proof. unfold Equation3555. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff676_inst, reff676_op in H. discriminate H. Qed.

Lemma reff676_not3556 : ~ @Equation3556 Fin5 reff676_inst.
Proof. unfold Equation3556. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff676_inst, reff676_op in H. discriminate H. Qed.

Lemma reff676_not3660 : ~ @Equation3660 Fin5 reff676_inst.
Proof. unfold Equation3660. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff676_inst, reff676_op in H. discriminate H. Qed.

Lemma reff676_not3661 : ~ @Equation3661 Fin5 reff676_inst.
Proof. unfold Equation3661. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff676_inst, reff676_op in H. discriminate H. Qed.

Lemma reff676_not3662 : ~ @Equation3662 Fin5 reff676_inst.
Proof. unfold Equation3662. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff676_inst, reff676_op in H. discriminate H. Qed.

Lemma reff676_not3664 : ~ @Equation3664 Fin5 reff676_inst.
Proof. unfold Equation3664. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff676_inst, reff676_op in H. discriminate H. Qed.

Lemma reff676_not3665 : ~ @Equation3665 Fin5 reff676_inst.
Proof. unfold Equation3665. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff676_inst, reff676_op in H. discriminate H. Qed.

Lemma reff676_not3667 : ~ @Equation3667 Fin5 reff676_inst.
Proof. unfold Equation3667. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff676_inst, reff676_op in H. discriminate H. Qed.

Lemma reff676_not3674 : ~ @Equation3674 Fin5 reff676_inst.
Proof. unfold Equation3674. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff676_inst, reff676_op in H. discriminate H. Qed.

Lemma reff676_not3677 : ~ @Equation3677 Fin5 reff676_inst.
Proof. unfold Equation3677. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff676_inst, reff676_op in H. discriminate H. Qed.

Lemma reff676_not3678 : ~ @Equation3678 Fin5 reff676_inst.
Proof. unfold Equation3678. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff676_inst, reff676_op in H. discriminate H. Qed.

Lemma reff676_not3684 : ~ @Equation3684 Fin5 reff676_inst.
Proof. unfold Equation3684. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff676_inst, reff676_op in H. discriminate H. Qed.

Lemma reff676_not3685 : ~ @Equation3685 Fin5 reff676_inst.
Proof. unfold Equation3685. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff676_inst, reff676_op in H. discriminate H. Qed.

Lemma reff676_not3687 : ~ @Equation3687 Fin5 reff676_inst.
Proof. unfold Equation3687. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff676_inst, reff676_op in H. discriminate H. Qed.

Lemma reff676_not3712 : ~ @Equation3712 Fin5 reff676_inst.
Proof. unfold Equation3712. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff676_inst, reff676_op in H. discriminate H. Qed.

Lemma reff676_not3714 : ~ @Equation3714 Fin5 reff676_inst.
Proof. unfold Equation3714. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff676_inst, reff676_op in H. discriminate H. Qed.

Lemma reff676_not3721 : ~ @Equation3721 Fin5 reff676_inst.
Proof. unfold Equation3721. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff676_inst, reff676_op in H. discriminate H. Qed.

Lemma reff676_not3724 : ~ @Equation3724 Fin5 reff676_inst.
Proof. unfold Equation3724. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff676_inst, reff676_op in H. discriminate H. Qed.

Lemma reff676_not3725 : ~ @Equation3725 Fin5 reff676_inst.
Proof. unfold Equation3725. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff676_inst, reff676_op in H. discriminate H. Qed.

Lemma reff676_not3748 : ~ @Equation3748 Fin5 reff676_inst.
Proof. unfold Equation3748. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff676_inst, reff676_op in H. discriminate H. Qed.

Lemma reff676_not3749 : ~ @Equation3749 Fin5 reff676_inst.
Proof. unfold Equation3749. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff676_inst, reff676_op in H. discriminate H. Qed.

Lemma reff676_not3751 : ~ @Equation3751 Fin5 reff676_inst.
Proof. unfold Equation3751. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff676_inst, reff676_op in H. discriminate H. Qed.

Lemma reff676_not3752 : ~ @Equation3752 Fin5 reff676_inst.
Proof. unfold Equation3752. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff676_inst, reff676_op in H. discriminate H. Qed.

Lemma reff676_not3758 : ~ @Equation3758 Fin5 reff676_inst.
Proof. unfold Equation3758. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff676_inst, reff676_op in H. discriminate H. Qed.

Lemma reff676_not3759 : ~ @Equation3759 Fin5 reff676_inst.
Proof. unfold Equation3759. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff676_inst, reff676_op in H. discriminate H. Qed.

Lemma reff676_not3864 : ~ @Equation3864 Fin5 reff676_inst.
Proof. unfold Equation3864. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff676_inst, reff676_op in H. discriminate H. Qed.

Lemma reff676_not3865 : ~ @Equation3865 Fin5 reff676_inst.
Proof. unfold Equation3865. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff676_inst, reff676_op in H. discriminate H. Qed.

Lemma reff676_not3867 : ~ @Equation3867 Fin5 reff676_inst.
Proof. unfold Equation3867. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff676_inst, reff676_op in H. discriminate H. Qed.

Lemma reff676_not3868 : ~ @Equation3868 Fin5 reff676_inst.
Proof. unfold Equation3868. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff676_inst, reff676_op in H. discriminate H. Qed.

Lemma reff676_not3870 : ~ @Equation3870 Fin5 reff676_inst.
Proof. unfold Equation3870. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff676_inst, reff676_op in H. discriminate H. Qed.

Lemma reff676_not3877 : ~ @Equation3877 Fin5 reff676_inst.
Proof. unfold Equation3877. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff676_inst, reff676_op in H. discriminate H. Qed.

Lemma reff676_not3878 : ~ @Equation3878 Fin5 reff676_inst.
Proof. unfold Equation3878. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff676_inst, reff676_op in H. discriminate H. Qed.

Lemma reff676_not3880 : ~ @Equation3880 Fin5 reff676_inst.
Proof. unfold Equation3880. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff676_inst, reff676_op in H. discriminate H. Qed.

Lemma reff676_not3881 : ~ @Equation3881 Fin5 reff676_inst.
Proof. unfold Equation3881. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff676_inst, reff676_op in H. discriminate H. Qed.

Lemma reff676_not3887 : ~ @Equation3887 Fin5 reff676_inst.
Proof. unfold Equation3887. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff676_inst, reff676_op in H. discriminate H. Qed.

Lemma reff676_not3890 : ~ @Equation3890 Fin5 reff676_inst.
Proof. unfold Equation3890. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff676_inst, reff676_op in H. discriminate H. Qed.

Lemma reff676_not3917 : ~ @Equation3917 Fin5 reff676_inst.
Proof. unfold Equation3917. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff676_inst, reff676_op in H. discriminate H. Qed.

Lemma reff676_not3918 : ~ @Equation3918 Fin5 reff676_inst.
Proof. unfold Equation3918. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff676_inst, reff676_op in H. discriminate H. Qed.

Lemma reff676_not3925 : ~ @Equation3925 Fin5 reff676_inst.
Proof. unfold Equation3925. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff676_inst, reff676_op in H. discriminate H. Qed.

Lemma reff676_not3927 : ~ @Equation3927 Fin5 reff676_inst.
Proof. unfold Equation3927. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff676_inst, reff676_op in H. discriminate H. Qed.

Lemma reff676_not3928 : ~ @Equation3928 Fin5 reff676_inst.
Proof. unfold Equation3928. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff676_inst, reff676_op in H. discriminate H. Qed.

Lemma reff676_not3951 : ~ @Equation3951 Fin5 reff676_inst.
Proof. unfold Equation3951. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff676_inst, reff676_op in H. discriminate H. Qed.

Lemma reff676_not3952 : ~ @Equation3952 Fin5 reff676_inst.
Proof. unfold Equation3952. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff676_inst, reff676_op in H. discriminate H. Qed.

Lemma reff676_not3955 : ~ @Equation3955 Fin5 reff676_inst.
Proof. unfold Equation3955. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff676_inst, reff676_op in H. discriminate H. Qed.

Lemma reff676_not3961 : ~ @Equation3961 Fin5 reff676_inst.
Proof. unfold Equation3961. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff676_inst, reff676_op in H. discriminate H. Qed.

Lemma reff676_not3962 : ~ @Equation3962 Fin5 reff676_inst.
Proof. unfold Equation3962. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff676_inst, reff676_op in H. discriminate H. Qed.

Lemma reff676_not3964 : ~ @Equation3964 Fin5 reff676_inst.
Proof. unfold Equation3964. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff676_inst, reff676_op in H. discriminate H. Qed.

Lemma reff676_not4066 : ~ @Equation4066 Fin5 reff676_inst.
Proof. unfold Equation4066. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff676_inst, reff676_op in H. discriminate H. Qed.

Lemma reff676_not4067 : ~ @Equation4067 Fin5 reff676_inst.
Proof. unfold Equation4067. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff676_inst, reff676_op in H. discriminate H. Qed.

Lemma reff676_not4070 : ~ @Equation4070 Fin5 reff676_inst.
Proof. unfold Equation4070. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff676_inst, reff676_op in H. discriminate H. Qed.

Lemma reff676_not4071 : ~ @Equation4071 Fin5 reff676_inst.
Proof. unfold Equation4071. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff676_inst, reff676_op in H. discriminate H. Qed.

Lemma reff676_not4074 : ~ @Equation4074 Fin5 reff676_inst.
Proof. unfold Equation4074. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff676_inst, reff676_op in H. discriminate H. Qed.

Lemma reff676_not4080 : ~ @Equation4080 Fin5 reff676_inst.
Proof. unfold Equation4080. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff676_inst, reff676_op in H. discriminate H. Qed.

Lemma reff676_not4081 : ~ @Equation4081 Fin5 reff676_inst.
Proof. unfold Equation4081. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff676_inst, reff676_op in H. discriminate H. Qed.

Lemma reff676_not4083 : ~ @Equation4083 Fin5 reff676_inst.
Proof. unfold Equation4083. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff676_inst, reff676_op in H. discriminate H. Qed.

Lemma reff676_not4084 : ~ @Equation4084 Fin5 reff676_inst.
Proof. unfold Equation4084. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff676_inst, reff676_op in H. discriminate H. Qed.

Lemma reff676_not4090 : ~ @Equation4090 Fin5 reff676_inst.
Proof. unfold Equation4090. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff676_inst, reff676_op in H. discriminate H. Qed.

Lemma reff676_not4091 : ~ @Equation4091 Fin5 reff676_inst.
Proof. unfold Equation4091. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff676_inst, reff676_op in H. discriminate H. Qed.

Lemma reff676_not4093 : ~ @Equation4093 Fin5 reff676_inst.
Proof. unfold Equation4093. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff676_inst, reff676_op in H. discriminate H. Qed.

Lemma reff676_not4120 : ~ @Equation4120 Fin5 reff676_inst.
Proof. unfold Equation4120. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff676_inst, reff676_op in H. discriminate H. Qed.

Lemma reff676_not4121 : ~ @Equation4121 Fin5 reff676_inst.
Proof. unfold Equation4121. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff676_inst, reff676_op in H. discriminate H. Qed.

Lemma reff676_not4128 : ~ @Equation4128 Fin5 reff676_inst.
Proof. unfold Equation4128. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff676_inst, reff676_op in H. discriminate H. Qed.

Lemma reff676_not4130 : ~ @Equation4130 Fin5 reff676_inst.
Proof. unfold Equation4130. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff676_inst, reff676_op in H. discriminate H. Qed.

Lemma reff676_not4154 : ~ @Equation4154 Fin5 reff676_inst.
Proof. unfold Equation4154. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff676_inst, reff676_op in H. discriminate H. Qed.

Lemma reff676_not4155 : ~ @Equation4155 Fin5 reff676_inst.
Proof. unfold Equation4155. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff676_inst, reff676_op in H. discriminate H. Qed.

Lemma reff676_not4158 : ~ @Equation4158 Fin5 reff676_inst.
Proof. unfold Equation4158. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff676_inst, reff676_op in H. discriminate H. Qed.

Lemma reff676_not4164 : ~ @Equation4164 Fin5 reff676_inst.
Proof. unfold Equation4164. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff676_inst, reff676_op in H. discriminate H. Qed.

Lemma reff676_not4165 : ~ @Equation4165 Fin5 reff676_inst.
Proof. unfold Equation4165. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff676_inst, reff676_op in H. discriminate H. Qed.

Lemma reff676_not4167 : ~ @Equation4167 Fin5 reff676_inst.
Proof. unfold Equation4167. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff676_inst, reff676_op in H. discriminate H. Qed.

Lemma reff676_not4268 : ~ @Equation4268 Fin5 reff676_inst.
Proof. unfold Equation4268. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff676_inst, reff676_op in H. discriminate H. Qed.

Lemma reff676_not4269 : ~ @Equation4269 Fin5 reff676_inst.
Proof. unfold Equation4269. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff676_inst, reff676_op in H. discriminate H. Qed.

Lemma reff676_not4270 : ~ @Equation4270 Fin5 reff676_inst.
Proof. unfold Equation4270. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff676_inst, reff676_op in H. discriminate H. Qed.

Lemma reff676_not4272 : ~ @Equation4272 Fin5 reff676_inst.
Proof. unfold Equation4272. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff676_inst, reff676_op in H. discriminate H. Qed.

Lemma reff676_not4273 : ~ @Equation4273 Fin5 reff676_inst.
Proof. unfold Equation4273. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff676_inst, reff676_op in H. discriminate H. Qed.

Lemma reff676_not4275 : ~ @Equation4275 Fin5 reff676_inst.
Proof. unfold Equation4275. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff676_inst, reff676_op in H. discriminate H. Qed.

Lemma reff676_not4276 : ~ @Equation4276 Fin5 reff676_inst.
Proof. unfold Equation4276. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff676_inst, reff676_op in H. discriminate H. Qed.

Lemma reff676_not4283 : ~ @Equation4283 Fin5 reff676_inst.
Proof. unfold Equation4283. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff676_inst, reff676_op in H. discriminate H. Qed.

Lemma reff676_not4284 : ~ @Equation4284 Fin5 reff676_inst.
Proof. unfold Equation4284. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff676_inst, reff676_op in H. discriminate H. Qed.

Lemma reff676_not4291 : ~ @Equation4291 Fin5 reff676_inst.
Proof. unfold Equation4291. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff676_inst, reff676_op in H. discriminate H. Qed.

Lemma reff676_not4293 : ~ @Equation4293 Fin5 reff676_inst.
Proof. unfold Equation4293. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff676_inst, reff676_op in H. discriminate H. Qed.

Lemma reff676_not4314 : ~ @Equation4314 Fin5 reff676_inst.
Proof. unfold Equation4314. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff676_inst, reff676_op in H. discriminate H. Qed.

Lemma reff676_not4320 : ~ @Equation4320 Fin5 reff676_inst.
Proof. unfold Equation4320. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff676_inst, reff676_op in H. discriminate H. Qed.

Lemma reff676_not4343 : ~ @Equation4343 Fin5 reff676_inst.
Proof. unfold Equation4343. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff676_inst, reff676_op in H. discriminate H. Qed.

Lemma reff676_not4396 : ~ @Equation4396 Fin5 reff676_inst.
Proof. unfold Equation4396. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff676_inst, reff676_op in H. discriminate H. Qed.

Lemma reff676_not4398 : ~ @Equation4398 Fin5 reff676_inst.
Proof. unfold Equation4398. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff676_inst, reff676_op in H. discriminate H. Qed.

Lemma reff676_not4399 : ~ @Equation4399 Fin5 reff676_inst.
Proof. unfold Equation4399. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff676_inst, reff676_op in H. discriminate H. Qed.

Lemma reff676_not4405 : ~ @Equation4405 Fin5 reff676_inst.
Proof. unfold Equation4405. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff676_inst, reff676_op in H. discriminate H. Qed.

Lemma reff676_not4406 : ~ @Equation4406 Fin5 reff676_inst.
Proof. unfold Equation4406. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff676_inst, reff676_op in H. discriminate H. Qed.

Lemma reff676_not4433 : ~ @Equation4433 Fin5 reff676_inst.
Proof. unfold Equation4433. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff676_inst, reff676_op in H. discriminate H. Qed.

Lemma reff676_not4436 : ~ @Equation4436 Fin5 reff676_inst.
Proof. unfold Equation4436. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff676_inst, reff676_op in H. discriminate H. Qed.

Lemma reff676_not4442 : ~ @Equation4442 Fin5 reff676_inst.
Proof. unfold Equation4442. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff676_inst, reff676_op in H. discriminate H. Qed.

Lemma reff676_not4445 : ~ @Equation4445 Fin5 reff676_inst.
Proof. unfold Equation4445. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff676_inst, reff676_op in H. discriminate H. Qed.

Lemma reff676_not4472 : ~ @Equation4472 Fin5 reff676_inst.
Proof. unfold Equation4472. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff676_inst, reff676_op in H. discriminate H. Qed.

Lemma reff676_not4473 : ~ @Equation4473 Fin5 reff676_inst.
Proof. unfold Equation4473. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff676_inst, reff676_op in H. discriminate H. Qed.

Lemma reff676_not4479 : ~ @Equation4479 Fin5 reff676_inst.
Proof. unfold Equation4479. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff676_inst, reff676_op in H. discriminate H. Qed.

Lemma reff676_not4480 : ~ @Equation4480 Fin5 reff676_inst.
Proof. unfold Equation4480. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff676_inst, reff676_op in H. discriminate H. Qed.

Lemma reff676_not4482 : ~ @Equation4482 Fin5 reff676_inst.
Proof. unfold Equation4482. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff676_inst, reff676_op in H. discriminate H. Qed.

Lemma reff676_not4583 : ~ @Equation4583 Fin5 reff676_inst.
Proof. unfold Equation4583. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff676_inst, reff676_op in H. discriminate H. Qed.

Lemma reff676_not4584 : ~ @Equation4584 Fin5 reff676_inst.
Proof. unfold Equation4584. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff676_inst, reff676_op in H. discriminate H. Qed.

Lemma reff676_not4587 : ~ @Equation4587 Fin5 reff676_inst.
Proof. unfold Equation4587. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff676_inst, reff676_op in H. discriminate H. Qed.

Lemma reff676_not4588 : ~ @Equation4588 Fin5 reff676_inst.
Proof. unfold Equation4588. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff676_inst, reff676_op in H. discriminate H. Qed.

Lemma reff676_not4590 : ~ @Equation4590 Fin5 reff676_inst.
Proof. unfold Equation4590. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff676_inst, reff676_op in H. discriminate H. Qed.

Lemma reff676_not4591 : ~ @Equation4591 Fin5 reff676_inst.
Proof. unfold Equation4591. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff676_inst, reff676_op in H. discriminate H. Qed.

Lemma reff676_not4598 : ~ @Equation4598 Fin5 reff676_inst.
Proof. unfold Equation4598. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff676_inst, reff676_op in H. discriminate H. Qed.

Lemma reff676_not4599 : ~ @Equation4599 Fin5 reff676_inst.
Proof. unfold Equation4599. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff676_inst, reff676_op in H. discriminate H. Qed.

Lemma reff676_not4605 : ~ @Equation4605 Fin5 reff676_inst.
Proof. unfold Equation4605. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff676_inst, reff676_op in H. discriminate H. Qed.

Lemma reff676_not4606 : ~ @Equation4606 Fin5 reff676_inst.
Proof. unfold Equation4606. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff676_inst, reff676_op in H. discriminate H. Qed.

Lemma reff676_not4608 : ~ @Equation4608 Fin5 reff676_inst.
Proof. unfold Equation4608. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff676_inst, reff676_op in H. discriminate H. Qed.

Lemma reff676_not4629 : ~ @Equation4629 Fin5 reff676_inst.
Proof. unfold Equation4629. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff676_inst, reff676_op in H. discriminate H. Qed.

Lemma reff676_not4635 : ~ @Equation4635 Fin5 reff676_inst.
Proof. unfold Equation4635. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff676_inst, reff676_op in H. discriminate H. Qed.

Lemma reff676_not4658 : ~ @Equation4658 Fin5 reff676_inst.
Proof. unfold Equation4658. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff676_inst, reff676_op in H. discriminate H. Qed.

(** ---- reff68 (Fin3) ---- *)

Definition reff68_op (x y : Fin3) : Fin3 :=
  match x, y with
  | F3_0, F3_0 => F3_0 | F3_0, F3_1 => F3_0 | F3_0, F3_2 => F3_1
  | F3_1, F3_0 => F3_2 | F3_1, F3_1 => F3_1 | F3_1, F3_2 => F3_1
  | F3_2, F3_0 => F3_0 | F3_2, F3_1 => F3_1 | F3_2, F3_2 => F3_0
  end.

#[local] Instance reff68_inst : Magma Fin3 := {| magma_op := reff68_op |}.

Lemma reff68_sat307 : @Equation307 Fin3 reff68_inst.
Proof. unfold Equation307, magma_op, reff68_inst, reff68_op. intros x. destruct x; reflexivity. Qed.

Lemma reff68_sat2050 : @Equation2050 Fin3 reff68_inst.
Proof. unfold Equation2050, magma_op, reff68_inst, reff68_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff68_sat3660 : @Equation3660 Fin3 reff68_inst.
Proof. unfold Equation3660, magma_op, reff68_inst, reff68_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff68_not47 : ~ @Equation47 Fin3 reff68_inst.
Proof. unfold Equation47. intro H. specialize (H F3_2). unfold magma_op, reff68_inst, reff68_op in H. discriminate H. Qed.

Lemma reff68_not99 : ~ @Equation99 Fin3 reff68_inst.
Proof. unfold Equation99. intro H. specialize (H F3_2). unfold magma_op, reff68_inst, reff68_op in H. discriminate H. Qed.

Lemma reff68_not151 : ~ @Equation151 Fin3 reff68_inst.
Proof. unfold Equation151. intro H. specialize (H F3_2). unfold magma_op, reff68_inst, reff68_op in H. discriminate H. Qed.

Lemma reff68_not203 : ~ @Equation203 Fin3 reff68_inst.
Proof. unfold Equation203. intro H. specialize (H F3_2). unfold magma_op, reff68_inst, reff68_op in H. discriminate H. Qed.

Lemma reff68_not255 : ~ @Equation255 Fin3 reff68_inst.
Proof. unfold Equation255. intro H. specialize (H F3_2). unfold magma_op, reff68_inst, reff68_op in H. discriminate H. Qed.

Lemma reff68_not411 : ~ @Equation411 Fin3 reff68_inst.
Proof. unfold Equation411. intro H. specialize (H F3_2). unfold magma_op, reff68_inst, reff68_op in H. discriminate H. Qed.

Lemma reff68_not614 : ~ @Equation614 Fin3 reff68_inst.
Proof. unfold Equation614. intro H. specialize (H F3_2). unfold magma_op, reff68_inst, reff68_op in H. discriminate H. Qed.

Lemma reff68_not817 : ~ @Equation817 Fin3 reff68_inst.
Proof. unfold Equation817. intro H. specialize (H F3_2). unfold magma_op, reff68_inst, reff68_op in H. discriminate H. Qed.

Lemma reff68_not1020 : ~ @Equation1020 Fin3 reff68_inst.
Proof. unfold Equation1020. intro H. specialize (H F3_2). unfold magma_op, reff68_inst, reff68_op in H. discriminate H. Qed.

Lemma reff68_not1223 : ~ @Equation1223 Fin3 reff68_inst.
Proof. unfold Equation1223. intro H. specialize (H F3_2). unfold magma_op, reff68_inst, reff68_op in H. discriminate H. Qed.

Lemma reff68_not1426 : ~ @Equation1426 Fin3 reff68_inst.
Proof. unfold Equation1426. intro H. specialize (H F3_2). unfold magma_op, reff68_inst, reff68_op in H. discriminate H. Qed.

Lemma reff68_not1629 : ~ @Equation1629 Fin3 reff68_inst.
Proof. unfold Equation1629. intro H. specialize (H F3_2). unfold magma_op, reff68_inst, reff68_op in H. discriminate H. Qed.

Lemma reff68_not1832 : ~ @Equation1832 Fin3 reff68_inst.
Proof. unfold Equation1832. intro H. specialize (H F3_2). unfold magma_op, reff68_inst, reff68_op in H. discriminate H. Qed.

Lemma reff68_not2036 : ~ @Equation2036 Fin3 reff68_inst.
Proof. unfold Equation2036. intro H. specialize (H F3_2 F3_1). unfold magma_op, reff68_inst, reff68_op in H. discriminate H. Qed.

Lemma reff68_not2037 : ~ @Equation2037 Fin3 reff68_inst.
Proof. unfold Equation2037. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff68_inst, reff68_op in H. discriminate H. Qed.

Lemma reff68_not2038 : ~ @Equation2038 Fin3 reff68_inst.
Proof. unfold Equation2038. intro H. specialize (H F3_1 F3_0). unfold magma_op, reff68_inst, reff68_op in H. discriminate H. Qed.

Lemma reff68_not2040 : ~ @Equation2040 Fin3 reff68_inst.
Proof. unfold Equation2040. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff68_inst, reff68_op in H. discriminate H. Qed.

Lemma reff68_not2041 : ~ @Equation2041 Fin3 reff68_inst.
Proof. unfold Equation2041. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff68_inst, reff68_op in H. discriminate H. Qed.

Lemma reff68_not2043 : ~ @Equation2043 Fin3 reff68_inst.
Proof. unfold Equation2043. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff68_inst, reff68_op in H. discriminate H. Qed.

Lemma reff68_not2044 : ~ @Equation2044 Fin3 reff68_inst.
Proof. unfold Equation2044. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff68_inst, reff68_op in H. discriminate H. Qed.

Lemma reff68_not2051 : ~ @Equation2051 Fin3 reff68_inst.
Proof. unfold Equation2051. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff68_inst, reff68_op in H. discriminate H. Qed.

Lemma reff68_not2053 : ~ @Equation2053 Fin3 reff68_inst.
Proof. unfold Equation2053. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff68_inst, reff68_op in H. discriminate H. Qed.

Lemma reff68_not2054 : ~ @Equation2054 Fin3 reff68_inst.
Proof. unfold Equation2054. intro H. specialize (H F3_1 F3_0). unfold magma_op, reff68_inst, reff68_op in H. discriminate H. Qed.

Lemma reff68_not2060 : ~ @Equation2060 Fin3 reff68_inst.
Proof. unfold Equation2060. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff68_inst, reff68_op in H. discriminate H. Qed.

Lemma reff68_not2061 : ~ @Equation2061 Fin3 reff68_inst.
Proof. unfold Equation2061. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff68_inst, reff68_op in H. discriminate H. Qed.

Lemma reff68_not2063 : ~ @Equation2063 Fin3 reff68_inst.
Proof. unfold Equation2063. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff68_inst, reff68_op in H. discriminate H. Qed.

Lemma reff68_not2064 : ~ @Equation2064 Fin3 reff68_inst.
Proof. unfold Equation2064. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff68_inst, reff68_op in H. discriminate H. Qed.

Lemma reff68_not2087 : ~ @Equation2087 Fin3 reff68_inst.
Proof. unfold Equation2087. intro H. specialize (H F3_1 F3_0). unfold magma_op, reff68_inst, reff68_op in H. discriminate H. Qed.

Lemma reff68_not2088 : ~ @Equation2088 Fin3 reff68_inst.
Proof. unfold Equation2088. intro H. specialize (H F3_2 F3_1). unfold magma_op, reff68_inst, reff68_op in H. discriminate H. Qed.

Lemma reff68_not2090 : ~ @Equation2090 Fin3 reff68_inst.
Proof. unfold Equation2090. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff68_inst, reff68_op in H. discriminate H. Qed.

Lemma reff68_not2091 : ~ @Equation2091 Fin3 reff68_inst.
Proof. unfold Equation2091. intro H. specialize (H F3_1 F3_0). unfold magma_op, reff68_inst, reff68_op in H. discriminate H. Qed.

Lemma reff68_not2097 : ~ @Equation2097 Fin3 reff68_inst.
Proof. unfold Equation2097. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff68_inst, reff68_op in H. discriminate H. Qed.

Lemma reff68_not2098 : ~ @Equation2098 Fin3 reff68_inst.
Proof. unfold Equation2098. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff68_inst, reff68_op in H. discriminate H. Qed.

Lemma reff68_not2100 : ~ @Equation2100 Fin3 reff68_inst.
Proof. unfold Equation2100. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff68_inst, reff68_op in H. discriminate H. Qed.

Lemma reff68_not2101 : ~ @Equation2101 Fin3 reff68_inst.
Proof. unfold Equation2101. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff68_inst, reff68_op in H. discriminate H. Qed.

Lemma reff68_not2124 : ~ @Equation2124 Fin3 reff68_inst.
Proof. unfold Equation2124. intro H. specialize (H F3_1 F3_0). unfold magma_op, reff68_inst, reff68_op in H. discriminate H. Qed.

Lemma reff68_not2125 : ~ @Equation2125 Fin3 reff68_inst.
Proof. unfold Equation2125. intro H. specialize (H F3_1 F3_2). unfold magma_op, reff68_inst, reff68_op in H. discriminate H. Qed.

Lemma reff68_not2127 : ~ @Equation2127 Fin3 reff68_inst.
Proof. unfold Equation2127. intro H. specialize (H F3_1 F3_0). unfold magma_op, reff68_inst, reff68_op in H. discriminate H. Qed.

Lemma reff68_not2128 : ~ @Equation2128 Fin3 reff68_inst.
Proof. unfold Equation2128. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff68_inst, reff68_op in H. discriminate H. Qed.

Lemma reff68_not2134 : ~ @Equation2134 Fin3 reff68_inst.
Proof. unfold Equation2134. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff68_inst, reff68_op in H. discriminate H. Qed.

Lemma reff68_not2135 : ~ @Equation2135 Fin3 reff68_inst.
Proof. unfold Equation2135. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff68_inst, reff68_op in H. discriminate H. Qed.

Lemma reff68_not2137 : ~ @Equation2137 Fin3 reff68_inst.
Proof. unfold Equation2137. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff68_inst, reff68_op in H. discriminate H. Qed.

Lemma reff68_not2238 : ~ @Equation2238 Fin3 reff68_inst.
Proof. unfold Equation2238. intro H. specialize (H F3_2). unfold magma_op, reff68_inst, reff68_op in H. discriminate H. Qed.

Lemma reff68_not2441 : ~ @Equation2441 Fin3 reff68_inst.
Proof. unfold Equation2441. intro H. specialize (H F3_2). unfold magma_op, reff68_inst, reff68_op in H. discriminate H. Qed.

Lemma reff68_not2644 : ~ @Equation2644 Fin3 reff68_inst.
Proof. unfold Equation2644. intro H. specialize (H F3_2). unfold magma_op, reff68_inst, reff68_op in H. discriminate H. Qed.

Lemma reff68_not2847 : ~ @Equation2847 Fin3 reff68_inst.
Proof. unfold Equation2847. intro H. specialize (H F3_2). unfold magma_op, reff68_inst, reff68_op in H. discriminate H. Qed.

Lemma reff68_not3050 : ~ @Equation3050 Fin3 reff68_inst.
Proof. unfold Equation3050. intro H. specialize (H F3_2). unfold magma_op, reff68_inst, reff68_op in H. discriminate H. Qed.

Lemma reff68_not3254 : ~ @Equation3254 Fin3 reff68_inst.
Proof. unfold Equation3254. intro H. specialize (H F3_2 F3_1). unfold magma_op, reff68_inst, reff68_op in H. discriminate H. Qed.

Lemma reff68_not3255 : ~ @Equation3255 Fin3 reff68_inst.
Proof. unfold Equation3255. intro H. specialize (H F3_2 F3_0). unfold magma_op, reff68_inst, reff68_op in H. discriminate H. Qed.

Lemma reff68_not3256 : ~ @Equation3256 Fin3 reff68_inst.
Proof. unfold Equation3256. intro H. specialize (H F3_2 F3_1). unfold magma_op, reff68_inst, reff68_op in H. discriminate H. Qed.

Lemma reff68_not3258 : ~ @Equation3258 Fin3 reff68_inst.
Proof. unfold Equation3258. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff68_inst, reff68_op in H. discriminate H. Qed.

Lemma reff68_not3259 : ~ @Equation3259 Fin3 reff68_inst.
Proof. unfold Equation3259. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff68_inst, reff68_op in H. discriminate H. Qed.

Lemma reff68_not3261 : ~ @Equation3261 Fin3 reff68_inst.
Proof. unfold Equation3261. intro H. specialize (H F3_1 F3_0). unfold magma_op, reff68_inst, reff68_op in H. discriminate H. Qed.

Lemma reff68_not3262 : ~ @Equation3262 Fin3 reff68_inst.
Proof. unfold Equation3262. intro H. specialize (H F3_1 F3_0). unfold magma_op, reff68_inst, reff68_op in H. discriminate H. Qed.

Lemma reff68_not3268 : ~ @Equation3268 Fin3 reff68_inst.
Proof. unfold Equation3268. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff68_inst, reff68_op in H. discriminate H. Qed.

Lemma reff68_not3269 : ~ @Equation3269 Fin3 reff68_inst.
Proof. unfold Equation3269. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff68_inst, reff68_op in H. discriminate H. Qed.

Lemma reff68_not3271 : ~ @Equation3271 Fin3 reff68_inst.
Proof. unfold Equation3271. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff68_inst, reff68_op in H. discriminate H. Qed.

Lemma reff68_not3272 : ~ @Equation3272 Fin3 reff68_inst.
Proof. unfold Equation3272. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff68_inst, reff68_op in H. discriminate H. Qed.

Lemma reff68_not3278 : ~ @Equation3278 Fin3 reff68_inst.
Proof. unfold Equation3278. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff68_inst, reff68_op in H. discriminate H. Qed.

Lemma reff68_not3279 : ~ @Equation3279 Fin3 reff68_inst.
Proof. unfold Equation3279. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff68_inst, reff68_op in H. discriminate H. Qed.

Lemma reff68_not3281 : ~ @Equation3281 Fin3 reff68_inst.
Proof. unfold Equation3281. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff68_inst, reff68_op in H. discriminate H. Qed.

Lemma reff68_not3306 : ~ @Equation3306 Fin3 reff68_inst.
Proof. unfold Equation3306. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff68_inst, reff68_op in H. discriminate H. Qed.

Lemma reff68_not3308 : ~ @Equation3308 Fin3 reff68_inst.
Proof. unfold Equation3308. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff68_inst, reff68_op in H. discriminate H. Qed.

Lemma reff68_not3309 : ~ @Equation3309 Fin3 reff68_inst.
Proof. unfold Equation3309. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff68_inst, reff68_op in H. discriminate H. Qed.

Lemma reff68_not3315 : ~ @Equation3315 Fin3 reff68_inst.
Proof. unfold Equation3315. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff68_inst, reff68_op in H. discriminate H. Qed.

Lemma reff68_not3316 : ~ @Equation3316 Fin3 reff68_inst.
Proof. unfold Equation3316. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff68_inst, reff68_op in H. discriminate H. Qed.

Lemma reff68_not3318 : ~ @Equation3318 Fin3 reff68_inst.
Proof. unfold Equation3318. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff68_inst, reff68_op in H. discriminate H. Qed.

Lemma reff68_not3319 : ~ @Equation3319 Fin3 reff68_inst.
Proof. unfold Equation3319. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff68_inst, reff68_op in H. discriminate H. Qed.

Lemma reff68_not3342 : ~ @Equation3342 Fin3 reff68_inst.
Proof. unfold Equation3342. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff68_inst, reff68_op in H. discriminate H. Qed.

Lemma reff68_not3343 : ~ @Equation3343 Fin3 reff68_inst.
Proof. unfold Equation3343. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff68_inst, reff68_op in H. discriminate H. Qed.

Lemma reff68_not3345 : ~ @Equation3345 Fin3 reff68_inst.
Proof. unfold Equation3345. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff68_inst, reff68_op in H. discriminate H. Qed.

Lemma reff68_not3346 : ~ @Equation3346 Fin3 reff68_inst.
Proof. unfold Equation3346. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff68_inst, reff68_op in H. discriminate H. Qed.

Lemma reff68_not3352 : ~ @Equation3352 Fin3 reff68_inst.
Proof. unfold Equation3352. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff68_inst, reff68_op in H. discriminate H. Qed.

Lemma reff68_not3353 : ~ @Equation3353 Fin3 reff68_inst.
Proof. unfold Equation3353. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff68_inst, reff68_op in H. discriminate H. Qed.

Lemma reff68_not3456 : ~ @Equation3456 Fin3 reff68_inst.
Proof. unfold Equation3456. intro H. specialize (H F3_2). unfold magma_op, reff68_inst, reff68_op in H. discriminate H. Qed.

Lemma reff68_not3661 : ~ @Equation3661 Fin3 reff68_inst.
Proof. unfold Equation3661. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff68_inst, reff68_op in H. discriminate H. Qed.

Lemma reff68_not3662 : ~ @Equation3662 Fin3 reff68_inst.
Proof. unfold Equation3662. intro H. specialize (H F3_1 F3_0). unfold magma_op, reff68_inst, reff68_op in H. discriminate H. Qed.

Lemma reff68_not3664 : ~ @Equation3664 Fin3 reff68_inst.
Proof. unfold Equation3664. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff68_inst, reff68_op in H. discriminate H. Qed.

Lemma reff68_not3665 : ~ @Equation3665 Fin3 reff68_inst.
Proof. unfold Equation3665. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff68_inst, reff68_op in H. discriminate H. Qed.

Lemma reff68_not3667 : ~ @Equation3667 Fin3 reff68_inst.
Proof. unfold Equation3667. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff68_inst, reff68_op in H. discriminate H. Qed.

Lemma reff68_not3668 : ~ @Equation3668 Fin3 reff68_inst.
Proof. unfold Equation3668. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff68_inst, reff68_op in H. discriminate H. Qed.

Lemma reff68_not3674 : ~ @Equation3674 Fin3 reff68_inst.
Proof. unfold Equation3674. intro H. specialize (H F3_1 F3_0). unfold magma_op, reff68_inst, reff68_op in H. discriminate H. Qed.

Lemma reff68_not3675 : ~ @Equation3675 Fin3 reff68_inst.
Proof. unfold Equation3675. intro H. specialize (H F3_2 F3_0). unfold magma_op, reff68_inst, reff68_op in H. discriminate H. Qed.

Lemma reff68_not3677 : ~ @Equation3677 Fin3 reff68_inst.
Proof. unfold Equation3677. intro H. specialize (H F3_1 F3_0). unfold magma_op, reff68_inst, reff68_op in H. discriminate H. Qed.

Lemma reff68_not3678 : ~ @Equation3678 Fin3 reff68_inst.
Proof. unfold Equation3678. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff68_inst, reff68_op in H. discriminate H. Qed.

Lemma reff68_not3684 : ~ @Equation3684 Fin3 reff68_inst.
Proof. unfold Equation3684. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff68_inst, reff68_op in H. discriminate H. Qed.

Lemma reff68_not3685 : ~ @Equation3685 Fin3 reff68_inst.
Proof. unfold Equation3685. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff68_inst, reff68_op in H. discriminate H. Qed.

Lemma reff68_not3687 : ~ @Equation3687 Fin3 reff68_inst.
Proof. unfold Equation3687. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff68_inst, reff68_op in H. discriminate H. Qed.

Lemma reff68_not3712 : ~ @Equation3712 Fin3 reff68_inst.
Proof. unfold Equation3712. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff68_inst, reff68_op in H. discriminate H. Qed.

Lemma reff68_not3714 : ~ @Equation3714 Fin3 reff68_inst.
Proof. unfold Equation3714. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff68_inst, reff68_op in H. discriminate H. Qed.

Lemma reff68_not3721 : ~ @Equation3721 Fin3 reff68_inst.
Proof. unfold Equation3721. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff68_inst, reff68_op in H. discriminate H. Qed.

Lemma reff68_not3722 : ~ @Equation3722 Fin3 reff68_inst.
Proof. unfold Equation3722. intro H. specialize (H F3_1 F3_0). unfold magma_op, reff68_inst, reff68_op in H. discriminate H. Qed.

Lemma reff68_not3724 : ~ @Equation3724 Fin3 reff68_inst.
Proof. unfold Equation3724. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff68_inst, reff68_op in H. discriminate H. Qed.

Lemma reff68_not3725 : ~ @Equation3725 Fin3 reff68_inst.
Proof. unfold Equation3725. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff68_inst, reff68_op in H. discriminate H. Qed.

Lemma reff68_not3748 : ~ @Equation3748 Fin3 reff68_inst.
Proof. unfold Equation3748. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff68_inst, reff68_op in H. discriminate H. Qed.

Lemma reff68_not3749 : ~ @Equation3749 Fin3 reff68_inst.
Proof. unfold Equation3749. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff68_inst, reff68_op in H. discriminate H. Qed.

Lemma reff68_not3751 : ~ @Equation3751 Fin3 reff68_inst.
Proof. unfold Equation3751. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff68_inst, reff68_op in H. discriminate H. Qed.

Lemma reff68_not3752 : ~ @Equation3752 Fin3 reff68_inst.
Proof. unfold Equation3752. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff68_inst, reff68_op in H. discriminate H. Qed.

Lemma reff68_not3759 : ~ @Equation3759 Fin3 reff68_inst.
Proof. unfold Equation3759. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff68_inst, reff68_op in H. discriminate H. Qed.

Lemma reff68_not3761 : ~ @Equation3761 Fin3 reff68_inst.
Proof. unfold Equation3761. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff68_inst, reff68_op in H. discriminate H. Qed.

Lemma reff68_not3862 : ~ @Equation3862 Fin3 reff68_inst.
Proof. unfold Equation3862. intro H. specialize (H F3_2). unfold magma_op, reff68_inst, reff68_op in H. discriminate H. Qed.

Lemma reff68_not4065 : ~ @Equation4065 Fin3 reff68_inst.
Proof. unfold Equation4065. intro H. specialize (H F3_2). unfold magma_op, reff68_inst, reff68_op in H. discriminate H. Qed.

Lemma reff68_not4268 : ~ @Equation4268 Fin3 reff68_inst.
Proof. unfold Equation4268. intro H. specialize (H F3_2 F3_1). unfold magma_op, reff68_inst, reff68_op in H. discriminate H. Qed.

Lemma reff68_not4269 : ~ @Equation4269 Fin3 reff68_inst.
Proof. unfold Equation4269. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff68_inst, reff68_op in H. discriminate H. Qed.

Lemma reff68_not4270 : ~ @Equation4270 Fin3 reff68_inst.
Proof. unfold Equation4270. intro H. specialize (H F3_1 F3_0). unfold magma_op, reff68_inst, reff68_op in H. discriminate H. Qed.

Lemma reff68_not4272 : ~ @Equation4272 Fin3 reff68_inst.
Proof. unfold Equation4272. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff68_inst, reff68_op in H. discriminate H. Qed.

Lemma reff68_not4273 : ~ @Equation4273 Fin3 reff68_inst.
Proof. unfold Equation4273. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff68_inst, reff68_op in H. discriminate H. Qed.

Lemma reff68_not4275 : ~ @Equation4275 Fin3 reff68_inst.
Proof. unfold Equation4275. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff68_inst, reff68_op in H. discriminate H. Qed.

Lemma reff68_not4276 : ~ @Equation4276 Fin3 reff68_inst.
Proof. unfold Equation4276. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff68_inst, reff68_op in H. discriminate H. Qed.

Lemma reff68_not4283 : ~ @Equation4283 Fin3 reff68_inst.
Proof. unfold Equation4283. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff68_inst, reff68_op in H. discriminate H. Qed.

Lemma reff68_not4284 : ~ @Equation4284 Fin3 reff68_inst.
Proof. unfold Equation4284. intro H. specialize (H F3_1 F3_0). unfold magma_op, reff68_inst, reff68_op in H. discriminate H. Qed.

Lemma reff68_not4290 : ~ @Equation4290 Fin3 reff68_inst.
Proof. unfold Equation4290. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff68_inst, reff68_op in H. discriminate H. Qed.

Lemma reff68_not4291 : ~ @Equation4291 Fin3 reff68_inst.
Proof. unfold Equation4291. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff68_inst, reff68_op in H. discriminate H. Qed.

Lemma reff68_not4293 : ~ @Equation4293 Fin3 reff68_inst.
Proof. unfold Equation4293. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff68_inst, reff68_op in H. discriminate H. Qed.

Lemma reff68_not4314 : ~ @Equation4314 Fin3 reff68_inst.
Proof. unfold Equation4314. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff68_inst, reff68_op in H. discriminate H. Qed.

Lemma reff68_not4320 : ~ @Equation4320 Fin3 reff68_inst.
Proof. unfold Equation4320. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff68_inst, reff68_op in H. discriminate H. Qed.

Lemma reff68_not4321 : ~ @Equation4321 Fin3 reff68_inst.
Proof. unfold Equation4321. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff68_inst, reff68_op in H. discriminate H. Qed.

Lemma reff68_not4343 : ~ @Equation4343 Fin3 reff68_inst.
Proof. unfold Equation4343. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff68_inst, reff68_op in H. discriminate H. Qed.

Lemma reff68_not4380 : ~ @Equation4380 Fin3 reff68_inst.
Proof. unfold Equation4380. intro H. specialize (H F3_2). unfold magma_op, reff68_inst, reff68_op in H. discriminate H. Qed.

Lemma reff68_not4583 : ~ @Equation4583 Fin3 reff68_inst.
Proof. unfold Equation4583. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff68_inst, reff68_op in H. discriminate H. Qed.

Lemma reff68_not4584 : ~ @Equation4584 Fin3 reff68_inst.
Proof. unfold Equation4584. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff68_inst, reff68_op in H. discriminate H. Qed.

Lemma reff68_not4585 : ~ @Equation4585 Fin3 reff68_inst.
Proof. unfold Equation4585. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff68_inst, reff68_op in H. discriminate H. Qed.

Lemma reff68_not4587 : ~ @Equation4587 Fin3 reff68_inst.
Proof. unfold Equation4587. intro H. specialize (H F3_1 F3_0). unfold magma_op, reff68_inst, reff68_op in H. discriminate H. Qed.

Lemma reff68_not4588 : ~ @Equation4588 Fin3 reff68_inst.
Proof. unfold Equation4588. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff68_inst, reff68_op in H. discriminate H. Qed.

Lemma reff68_not4590 : ~ @Equation4590 Fin3 reff68_inst.
Proof. unfold Equation4590. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff68_inst, reff68_op in H. discriminate H. Qed.

Lemma reff68_not4591 : ~ @Equation4591 Fin3 reff68_inst.
Proof. unfold Equation4591. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff68_inst, reff68_op in H. discriminate H. Qed.

Lemma reff68_not4598 : ~ @Equation4598 Fin3 reff68_inst.
Proof. unfold Equation4598. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff68_inst, reff68_op in H. discriminate H. Qed.

Lemma reff68_not4599 : ~ @Equation4599 Fin3 reff68_inst.
Proof. unfold Equation4599. intro H. specialize (H F3_1 F3_0). unfold magma_op, reff68_inst, reff68_op in H. discriminate H. Qed.

Lemma reff68_not4605 : ~ @Equation4605 Fin3 reff68_inst.
Proof. unfold Equation4605. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff68_inst, reff68_op in H. discriminate H. Qed.

Lemma reff68_not4606 : ~ @Equation4606 Fin3 reff68_inst.
Proof. unfold Equation4606. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff68_inst, reff68_op in H. discriminate H. Qed.

Lemma reff68_not4608 : ~ @Equation4608 Fin3 reff68_inst.
Proof. unfold Equation4608. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff68_inst, reff68_op in H. discriminate H. Qed.

Lemma reff68_not4629 : ~ @Equation4629 Fin3 reff68_inst.
Proof. unfold Equation4629. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff68_inst, reff68_op in H. discriminate H. Qed.

Lemma reff68_not4635 : ~ @Equation4635 Fin3 reff68_inst.
Proof. unfold Equation4635. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff68_inst, reff68_op in H. discriminate H. Qed.

Lemma reff68_not4636 : ~ @Equation4636 Fin3 reff68_inst.
Proof. unfold Equation4636. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff68_inst, reff68_op in H. discriminate H. Qed.

Lemma reff68_not4658 : ~ @Equation4658 Fin3 reff68_inst.
Proof. unfold Equation4658. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff68_inst, reff68_op in H. discriminate H. Qed.

(** ---- reff682 (Fin5) ---- *)

Definition reff682_op (x y : Fin5) : Fin5 :=
  match x, y with
  | F5_0, F5_0 => F5_0 | F5_0, F5_1 => F5_3 | F5_0, F5_2 => F5_1 | F5_0, F5_3 => F5_4 | F5_0, F5_4 => F5_2
  | F5_1, F5_0 => F5_4 | F5_1, F5_1 => F5_2 | F5_1, F5_2 => F5_0 | F5_1, F5_3 => F5_3 | F5_1, F5_4 => F5_1
  | F5_2, F5_0 => F5_3 | F5_2, F5_1 => F5_1 | F5_2, F5_2 => F5_4 | F5_2, F5_3 => F5_2 | F5_2, F5_4 => F5_0
  | F5_3, F5_0 => F5_2 | F5_3, F5_1 => F5_0 | F5_3, F5_2 => F5_3 | F5_3, F5_3 => F5_1 | F5_3, F5_4 => F5_4
  | F5_4, F5_0 => F5_1 | F5_4, F5_1 => F5_4 | F5_4, F5_2 => F5_2 | F5_4, F5_3 => F5_0 | F5_4, F5_4 => F5_3
  end.

#[local] Instance reff682_inst : Magma Fin5 := {| magma_op := reff682_op |}.

Lemma reff682_sat420 : @Equation420 Fin5 reff682_inst.
Proof. unfold Equation420, magma_op, reff682_inst, reff682_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff682_sat546 : @Equation546 Fin5 reff682_inst.
Proof. unfold Equation546, magma_op, reff682_inst, reff682_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff682_sat845 : @Equation845 Fin5 reff682_inst.
Proof. unfold Equation845, magma_op, reff682_inst, reff682_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff682_sat949 : @Equation949 Fin5 reff682_inst.
Proof. unfold Equation949, magma_op, reff682_inst, reff682_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff682_sat962 : @Equation962 Fin5 reff682_inst.
Proof. unfold Equation962, magma_op, reff682_inst, reff682_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff682_sat1694 : @Equation1694 Fin5 reff682_inst.
Proof. unfold Equation1694, magma_op, reff682_inst, reff682_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff682_sat1790 : @Equation1790 Fin5 reff682_inst.
Proof. unfold Equation1790, magma_op, reff682_inst, reff682_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff682_sat1931 : @Equation1931 Fin5 reff682_inst.
Proof. unfold Equation1931, magma_op, reff682_inst, reff682_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff682_sat1967 : @Equation1967 Fin5 reff682_inst.
Proof. unfold Equation1967, magma_op, reff682_inst, reff682_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff682_sat2497 : @Equation2497 Fin5 reff682_inst.
Proof. unfold Equation2497, magma_op, reff682_inst, reff682_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff682_sat2586 : @Equation2586 Fin5 reff682_inst.
Proof. unfold Equation2586, magma_op, reff682_inst, reff682_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff682_sat3142 : @Equation3142 Fin5 reff682_inst.
Proof. unfold Equation3142, magma_op, reff682_inst, reff682_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff682_sat3546 : @Equation3546 Fin5 reff682_inst.
Proof. unfold Equation3546, magma_op, reff682_inst, reff682_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff682_sat3607 : @Equation3607 Fin5 reff682_inst.
Proof. unfold Equation3607, magma_op, reff682_inst, reff682_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff682_sat4091 : @Equation4091 Fin5 reff682_inst.
Proof. unfold Equation4091, magma_op, reff682_inst, reff682_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff682_sat4276 : @Equation4276 Fin5 reff682_inst.
Proof. unfold Equation4276, magma_op, reff682_inst, reff682_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff682_sat4608 : @Equation4608 Fin5 reff682_inst.
Proof. unfold Equation4608, magma_op, reff682_inst, reff682_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff682_not47 : ~ @Equation47 Fin5 reff682_inst.
Proof. unfold Equation47. intro H. specialize (H F5_1). unfold magma_op, reff682_inst, reff682_op in H. discriminate H. Qed.

Lemma reff682_not99 : ~ @Equation99 Fin5 reff682_inst.
Proof. unfold Equation99. intro H. specialize (H F5_1). unfold magma_op, reff682_inst, reff682_op in H. discriminate H. Qed.

Lemma reff682_not151 : ~ @Equation151 Fin5 reff682_inst.
Proof. unfold Equation151. intro H. specialize (H F5_1). unfold magma_op, reff682_inst, reff682_op in H. discriminate H. Qed.

Lemma reff682_not203 : ~ @Equation203 Fin5 reff682_inst.
Proof. unfold Equation203. intro H. specialize (H F5_1). unfold magma_op, reff682_inst, reff682_op in H. discriminate H. Qed.

Lemma reff682_not255 : ~ @Equation255 Fin5 reff682_inst.
Proof. unfold Equation255. intro H. specialize (H F5_1). unfold magma_op, reff682_inst, reff682_op in H. discriminate H. Qed.

Lemma reff682_not359 : ~ @Equation359 Fin5 reff682_inst.
Proof. unfold Equation359. intro H. specialize (H F5_1). unfold magma_op, reff682_inst, reff682_op in H. discriminate H. Qed.

Lemma reff682_not412 : ~ @Equation412 Fin5 reff682_inst.
Proof. unfold Equation412. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff682_inst, reff682_op in H. discriminate H. Qed.

Lemma reff682_not413 : ~ @Equation413 Fin5 reff682_inst.
Proof. unfold Equation413. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff682_inst, reff682_op in H. discriminate H. Qed.

Lemma reff682_not414 : ~ @Equation414 Fin5 reff682_inst.
Proof. unfold Equation414. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff682_inst, reff682_op in H. discriminate H. Qed.

Lemma reff682_not416 : ~ @Equation416 Fin5 reff682_inst.
Proof. unfold Equation416. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff682_inst, reff682_op in H. discriminate H. Qed.

Lemma reff682_not417 : ~ @Equation417 Fin5 reff682_inst.
Proof. unfold Equation417. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff682_inst, reff682_op in H. discriminate H. Qed.

Lemma reff682_not419 : ~ @Equation419 Fin5 reff682_inst.
Proof. unfold Equation419. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff682_inst, reff682_op in H. discriminate H. Qed.

Lemma reff682_not426 : ~ @Equation426 Fin5 reff682_inst.
Proof. unfold Equation426. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff682_inst, reff682_op in H. discriminate H. Qed.

Lemma reff682_not427 : ~ @Equation427 Fin5 reff682_inst.
Proof. unfold Equation427. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff682_inst, reff682_op in H. discriminate H. Qed.

Lemma reff682_not430 : ~ @Equation430 Fin5 reff682_inst.
Proof. unfold Equation430. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff682_inst, reff682_op in H. discriminate H. Qed.

Lemma reff682_not436 : ~ @Equation436 Fin5 reff682_inst.
Proof. unfold Equation436. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff682_inst, reff682_op in H. discriminate H. Qed.

Lemma reff682_not437 : ~ @Equation437 Fin5 reff682_inst.
Proof. unfold Equation437. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff682_inst, reff682_op in H. discriminate H. Qed.

Lemma reff682_not439 : ~ @Equation439 Fin5 reff682_inst.
Proof. unfold Equation439. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff682_inst, reff682_op in H. discriminate H. Qed.

Lemma reff682_not440 : ~ @Equation440 Fin5 reff682_inst.
Proof. unfold Equation440. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff682_inst, reff682_op in H. discriminate H. Qed.

Lemma reff682_not463 : ~ @Equation463 Fin5 reff682_inst.
Proof. unfold Equation463. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff682_inst, reff682_op in H. discriminate H. Qed.

Lemma reff682_not466 : ~ @Equation466 Fin5 reff682_inst.
Proof. unfold Equation466. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff682_inst, reff682_op in H. discriminate H. Qed.

Lemma reff682_not467 : ~ @Equation467 Fin5 reff682_inst.
Proof. unfold Equation467. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff682_inst, reff682_op in H. discriminate H. Qed.

Lemma reff682_not474 : ~ @Equation474 Fin5 reff682_inst.
Proof. unfold Equation474. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff682_inst, reff682_op in H. discriminate H. Qed.

Lemma reff682_not476 : ~ @Equation476 Fin5 reff682_inst.
Proof. unfold Equation476. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff682_inst, reff682_op in H. discriminate H. Qed.

Lemma reff682_not477 : ~ @Equation477 Fin5 reff682_inst.
Proof. unfold Equation477. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff682_inst, reff682_op in H. discriminate H. Qed.

Lemma reff682_not500 : ~ @Equation500 Fin5 reff682_inst.
Proof. unfold Equation500. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff682_inst, reff682_op in H. discriminate H. Qed.

Lemma reff682_not501 : ~ @Equation501 Fin5 reff682_inst.
Proof. unfold Equation501. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff682_inst, reff682_op in H. discriminate H. Qed.

Lemma reff682_not503 : ~ @Equation503 Fin5 reff682_inst.
Proof. unfold Equation503. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff682_inst, reff682_op in H. discriminate H. Qed.

Lemma reff682_not510 : ~ @Equation510 Fin5 reff682_inst.
Proof. unfold Equation510. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff682_inst, reff682_op in H. discriminate H. Qed.

Lemma reff682_not511 : ~ @Equation511 Fin5 reff682_inst.
Proof. unfold Equation511. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff682_inst, reff682_op in H. discriminate H. Qed.

Lemma reff682_not614 : ~ @Equation614 Fin5 reff682_inst.
Proof. unfold Equation614. intro H. specialize (H F5_1). unfold magma_op, reff682_inst, reff682_op in H. discriminate H. Qed.

Lemma reff682_not818 : ~ @Equation818 Fin5 reff682_inst.
Proof. unfold Equation818. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff682_inst, reff682_op in H. discriminate H. Qed.

Lemma reff682_not819 : ~ @Equation819 Fin5 reff682_inst.
Proof. unfold Equation819. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff682_inst, reff682_op in H. discriminate H. Qed.

Lemma reff682_not820 : ~ @Equation820 Fin5 reff682_inst.
Proof. unfold Equation820. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff682_inst, reff682_op in H. discriminate H. Qed.

Lemma reff682_not822 : ~ @Equation822 Fin5 reff682_inst.
Proof. unfold Equation822. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff682_inst, reff682_op in H. discriminate H. Qed.

Lemma reff682_not823 : ~ @Equation823 Fin5 reff682_inst.
Proof. unfold Equation823. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff682_inst, reff682_op in H. discriminate H. Qed.

Lemma reff682_not825 : ~ @Equation825 Fin5 reff682_inst.
Proof. unfold Equation825. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff682_inst, reff682_op in H. discriminate H. Qed.

Lemma reff682_not826 : ~ @Equation826 Fin5 reff682_inst.
Proof. unfold Equation826. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff682_inst, reff682_op in H. discriminate H. Qed.

Lemma reff682_not832 : ~ @Equation832 Fin5 reff682_inst.
Proof. unfold Equation832. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff682_inst, reff682_op in H. discriminate H. Qed.

Lemma reff682_not835 : ~ @Equation835 Fin5 reff682_inst.
Proof. unfold Equation835. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff682_inst, reff682_op in H. discriminate H. Qed.

Lemma reff682_not836 : ~ @Equation836 Fin5 reff682_inst.
Proof. unfold Equation836. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff682_inst, reff682_op in H. discriminate H. Qed.

Lemma reff682_not842 : ~ @Equation842 Fin5 reff682_inst.
Proof. unfold Equation842. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff682_inst, reff682_op in H. discriminate H. Qed.

Lemma reff682_not843 : ~ @Equation843 Fin5 reff682_inst.
Proof. unfold Equation843. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff682_inst, reff682_op in H. discriminate H. Qed.

Lemma reff682_not846 : ~ @Equation846 Fin5 reff682_inst.
Proof. unfold Equation846. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff682_inst, reff682_op in H. discriminate H. Qed.

Lemma reff682_not869 : ~ @Equation869 Fin5 reff682_inst.
Proof. unfold Equation869. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff682_inst, reff682_op in H. discriminate H. Qed.

Lemma reff682_not870 : ~ @Equation870 Fin5 reff682_inst.
Proof. unfold Equation870. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff682_inst, reff682_op in H. discriminate H. Qed.

Lemma reff682_not873 : ~ @Equation873 Fin5 reff682_inst.
Proof. unfold Equation873. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff682_inst, reff682_op in H. discriminate H. Qed.

Lemma reff682_not880 : ~ @Equation880 Fin5 reff682_inst.
Proof. unfold Equation880. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff682_inst, reff682_op in H. discriminate H. Qed.

Lemma reff682_not882 : ~ @Equation882 Fin5 reff682_inst.
Proof. unfold Equation882. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff682_inst, reff682_op in H. discriminate H. Qed.

Lemma reff682_not883 : ~ @Equation883 Fin5 reff682_inst.
Proof. unfold Equation883. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff682_inst, reff682_op in H. discriminate H. Qed.

Lemma reff682_not906 : ~ @Equation906 Fin5 reff682_inst.
Proof. unfold Equation906. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff682_inst, reff682_op in H. discriminate H. Qed.

Lemma reff682_not907 : ~ @Equation907 Fin5 reff682_inst.
Proof. unfold Equation907. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff682_inst, reff682_op in H. discriminate H. Qed.

Lemma reff682_not909 : ~ @Equation909 Fin5 reff682_inst.
Proof. unfold Equation909. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff682_inst, reff682_op in H. discriminate H. Qed.

Lemma reff682_not916 : ~ @Equation916 Fin5 reff682_inst.
Proof. unfold Equation916. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff682_inst, reff682_op in H. discriminate H. Qed.

Lemma reff682_not919 : ~ @Equation919 Fin5 reff682_inst.
Proof. unfold Equation919. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff682_inst, reff682_op in H. discriminate H. Qed.

Lemma reff682_not1020 : ~ @Equation1020 Fin5 reff682_inst.
Proof. unfold Equation1020. intro H. specialize (H F5_1). unfold magma_op, reff682_inst, reff682_op in H. discriminate H. Qed.

Lemma reff682_not1223 : ~ @Equation1223 Fin5 reff682_inst.
Proof. unfold Equation1223. intro H. specialize (H F5_1). unfold magma_op, reff682_inst, reff682_op in H. discriminate H. Qed.

Lemma reff682_not1426 : ~ @Equation1426 Fin5 reff682_inst.
Proof. unfold Equation1426. intro H. specialize (H F5_1). unfold magma_op, reff682_inst, reff682_op in H. discriminate H. Qed.

Lemma reff682_not1630 : ~ @Equation1630 Fin5 reff682_inst.
Proof. unfold Equation1630. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff682_inst, reff682_op in H. discriminate H. Qed.

Lemma reff682_not1631 : ~ @Equation1631 Fin5 reff682_inst.
Proof. unfold Equation1631. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff682_inst, reff682_op in H. discriminate H. Qed.

Lemma reff682_not1634 : ~ @Equation1634 Fin5 reff682_inst.
Proof. unfold Equation1634. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff682_inst, reff682_op in H. discriminate H. Qed.

Lemma reff682_not1635 : ~ @Equation1635 Fin5 reff682_inst.
Proof. unfold Equation1635. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff682_inst, reff682_op in H. discriminate H. Qed.

Lemma reff682_not1637 : ~ @Equation1637 Fin5 reff682_inst.
Proof. unfold Equation1637. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff682_inst, reff682_op in H. discriminate H. Qed.

Lemma reff682_not1638 : ~ @Equation1638 Fin5 reff682_inst.
Proof. unfold Equation1638. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff682_inst, reff682_op in H. discriminate H. Qed.

Lemma reff682_not1644 : ~ @Equation1644 Fin5 reff682_inst.
Proof. unfold Equation1644. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff682_inst, reff682_op in H. discriminate H. Qed.

Lemma reff682_not1645 : ~ @Equation1645 Fin5 reff682_inst.
Proof. unfold Equation1645. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff682_inst, reff682_op in H. discriminate H. Qed.

Lemma reff682_not1647 : ~ @Equation1647 Fin5 reff682_inst.
Proof. unfold Equation1647. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff682_inst, reff682_op in H. discriminate H. Qed.

Lemma reff682_not1648 : ~ @Equation1648 Fin5 reff682_inst.
Proof. unfold Equation1648. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff682_inst, reff682_op in H. discriminate H. Qed.

Lemma reff682_not1655 : ~ @Equation1655 Fin5 reff682_inst.
Proof. unfold Equation1655. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff682_inst, reff682_op in H. discriminate H. Qed.

Lemma reff682_not1657 : ~ @Equation1657 Fin5 reff682_inst.
Proof. unfold Equation1657. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff682_inst, reff682_op in H. discriminate H. Qed.

Lemma reff682_not1681 : ~ @Equation1681 Fin5 reff682_inst.
Proof. unfold Equation1681. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff682_inst, reff682_op in H. discriminate H. Qed.

Lemma reff682_not1684 : ~ @Equation1684 Fin5 reff682_inst.
Proof. unfold Equation1684. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff682_inst, reff682_op in H. discriminate H. Qed.

Lemma reff682_not1685 : ~ @Equation1685 Fin5 reff682_inst.
Proof. unfold Equation1685. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff682_inst, reff682_op in H. discriminate H. Qed.

Lemma reff682_not1691 : ~ @Equation1691 Fin5 reff682_inst.
Proof. unfold Equation1691. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff682_inst, reff682_op in H. discriminate H. Qed.

Lemma reff682_not1692 : ~ @Equation1692 Fin5 reff682_inst.
Proof. unfold Equation1692. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff682_inst, reff682_op in H. discriminate H. Qed.

Lemma reff682_not1695 : ~ @Equation1695 Fin5 reff682_inst.
Proof. unfold Equation1695. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff682_inst, reff682_op in H. discriminate H. Qed.

Lemma reff682_not1718 : ~ @Equation1718 Fin5 reff682_inst.
Proof. unfold Equation1718. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff682_inst, reff682_op in H. discriminate H. Qed.

Lemma reff682_not1719 : ~ @Equation1719 Fin5 reff682_inst.
Proof. unfold Equation1719. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff682_inst, reff682_op in H. discriminate H. Qed.

Lemma reff682_not1721 : ~ @Equation1721 Fin5 reff682_inst.
Proof. unfold Equation1721. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff682_inst, reff682_op in H. discriminate H. Qed.

Lemma reff682_not1722 : ~ @Equation1722 Fin5 reff682_inst.
Proof. unfold Equation1722. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff682_inst, reff682_op in H. discriminate H. Qed.

Lemma reff682_not1728 : ~ @Equation1728 Fin5 reff682_inst.
Proof. unfold Equation1728. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff682_inst, reff682_op in H. discriminate H. Qed.

Lemma reff682_not1731 : ~ @Equation1731 Fin5 reff682_inst.
Proof. unfold Equation1731. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff682_inst, reff682_op in H. discriminate H. Qed.

Lemma reff682_not1833 : ~ @Equation1833 Fin5 reff682_inst.
Proof. unfold Equation1833. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff682_inst, reff682_op in H. discriminate H. Qed.

Lemma reff682_not1834 : ~ @Equation1834 Fin5 reff682_inst.
Proof. unfold Equation1834. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff682_inst, reff682_op in H. discriminate H. Qed.

Lemma reff682_not1835 : ~ @Equation1835 Fin5 reff682_inst.
Proof. unfold Equation1835. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff682_inst, reff682_op in H. discriminate H. Qed.

Lemma reff682_not1837 : ~ @Equation1837 Fin5 reff682_inst.
Proof. unfold Equation1837. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff682_inst, reff682_op in H. discriminate H. Qed.

Lemma reff682_not1840 : ~ @Equation1840 Fin5 reff682_inst.
Proof. unfold Equation1840. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff682_inst, reff682_op in H. discriminate H. Qed.

Lemma reff682_not1841 : ~ @Equation1841 Fin5 reff682_inst.
Proof. unfold Equation1841. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff682_inst, reff682_op in H. discriminate H. Qed.

Lemma reff682_not1847 : ~ @Equation1847 Fin5 reff682_inst.
Proof. unfold Equation1847. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff682_inst, reff682_op in H. discriminate H. Qed.

Lemma reff682_not1848 : ~ @Equation1848 Fin5 reff682_inst.
Proof. unfold Equation1848. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff682_inst, reff682_op in H. discriminate H. Qed.

Lemma reff682_not1851 : ~ @Equation1851 Fin5 reff682_inst.
Proof. unfold Equation1851. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff682_inst, reff682_op in H. discriminate H. Qed.

Lemma reff682_not1857 : ~ @Equation1857 Fin5 reff682_inst.
Proof. unfold Equation1857. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff682_inst, reff682_op in H. discriminate H. Qed.

Lemma reff682_not1858 : ~ @Equation1858 Fin5 reff682_inst.
Proof. unfold Equation1858. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff682_inst, reff682_op in H. discriminate H. Qed.

Lemma reff682_not1860 : ~ @Equation1860 Fin5 reff682_inst.
Proof. unfold Equation1860. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff682_inst, reff682_op in H. discriminate H. Qed.

Lemma reff682_not1884 : ~ @Equation1884 Fin5 reff682_inst.
Proof. unfold Equation1884. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff682_inst, reff682_op in H. discriminate H. Qed.

Lemma reff682_not1887 : ~ @Equation1887 Fin5 reff682_inst.
Proof. unfold Equation1887. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff682_inst, reff682_op in H. discriminate H. Qed.

Lemma reff682_not1888 : ~ @Equation1888 Fin5 reff682_inst.
Proof. unfold Equation1888. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff682_inst, reff682_op in H. discriminate H. Qed.

Lemma reff682_not1894 : ~ @Equation1894 Fin5 reff682_inst.
Proof. unfold Equation1894. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff682_inst, reff682_op in H. discriminate H. Qed.

Lemma reff682_not1895 : ~ @Equation1895 Fin5 reff682_inst.
Proof. unfold Equation1895. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff682_inst, reff682_op in H. discriminate H. Qed.

Lemma reff682_not1897 : ~ @Equation1897 Fin5 reff682_inst.
Proof. unfold Equation1897. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff682_inst, reff682_op in H. discriminate H. Qed.

Lemma reff682_not1898 : ~ @Equation1898 Fin5 reff682_inst.
Proof. unfold Equation1898. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff682_inst, reff682_op in H. discriminate H. Qed.

Lemma reff682_not1921 : ~ @Equation1921 Fin5 reff682_inst.
Proof. unfold Equation1921. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff682_inst, reff682_op in H. discriminate H. Qed.

Lemma reff682_not1922 : ~ @Equation1922 Fin5 reff682_inst.
Proof. unfold Equation1922. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff682_inst, reff682_op in H. discriminate H. Qed.

Lemma reff682_not1924 : ~ @Equation1924 Fin5 reff682_inst.
Proof. unfold Equation1924. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff682_inst, reff682_op in H. discriminate H. Qed.

Lemma reff682_not1932 : ~ @Equation1932 Fin5 reff682_inst.
Proof. unfold Equation1932. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff682_inst, reff682_op in H. discriminate H. Qed.

Lemma reff682_not1934 : ~ @Equation1934 Fin5 reff682_inst.
Proof. unfold Equation1934. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff682_inst, reff682_op in H. discriminate H. Qed.

Lemma reff682_not2035 : ~ @Equation2035 Fin5 reff682_inst.
Proof. unfold Equation2035. intro H. specialize (H F5_1). unfold magma_op, reff682_inst, reff682_op in H. discriminate H. Qed.

Lemma reff682_not2238 : ~ @Equation2238 Fin5 reff682_inst.
Proof. unfold Equation2238. intro H. specialize (H F5_1). unfold magma_op, reff682_inst, reff682_op in H. discriminate H. Qed.

Lemma reff682_not2442 : ~ @Equation2442 Fin5 reff682_inst.
Proof. unfold Equation2442. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff682_inst, reff682_op in H. discriminate H. Qed.

Lemma reff682_not2443 : ~ @Equation2443 Fin5 reff682_inst.
Proof. unfold Equation2443. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff682_inst, reff682_op in H. discriminate H. Qed.

Lemma reff682_not2444 : ~ @Equation2444 Fin5 reff682_inst.
Proof. unfold Equation2444. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff682_inst, reff682_op in H. discriminate H. Qed.

Lemma reff682_not2446 : ~ @Equation2446 Fin5 reff682_inst.
Proof. unfold Equation2446. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff682_inst, reff682_op in H. discriminate H. Qed.

Lemma reff682_not2447 : ~ @Equation2447 Fin5 reff682_inst.
Proof. unfold Equation2447. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff682_inst, reff682_op in H. discriminate H. Qed.

Lemma reff682_not2450 : ~ @Equation2450 Fin5 reff682_inst.
Proof. unfold Equation2450. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff682_inst, reff682_op in H. discriminate H. Qed.

Lemma reff682_not2456 : ~ @Equation2456 Fin5 reff682_inst.
Proof. unfold Equation2456. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff682_inst, reff682_op in H. discriminate H. Qed.

Lemma reff682_not2459 : ~ @Equation2459 Fin5 reff682_inst.
Proof. unfold Equation2459. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff682_inst, reff682_op in H. discriminate H. Qed.

Lemma reff682_not2460 : ~ @Equation2460 Fin5 reff682_inst.
Proof. unfold Equation2460. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff682_inst, reff682_op in H. discriminate H. Qed.

Lemma reff682_not2466 : ~ @Equation2466 Fin5 reff682_inst.
Proof. unfold Equation2466. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff682_inst, reff682_op in H. discriminate H. Qed.

Lemma reff682_not2467 : ~ @Equation2467 Fin5 reff682_inst.
Proof. unfold Equation2467. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff682_inst, reff682_op in H. discriminate H. Qed.

Lemma reff682_not2469 : ~ @Equation2469 Fin5 reff682_inst.
Proof. unfold Equation2469. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff682_inst, reff682_op in H. discriminate H. Qed.

Lemma reff682_not2493 : ~ @Equation2493 Fin5 reff682_inst.
Proof. unfold Equation2493. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff682_inst, reff682_op in H. discriminate H. Qed.

Lemma reff682_not2494 : ~ @Equation2494 Fin5 reff682_inst.
Proof. unfold Equation2494. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff682_inst, reff682_op in H. discriminate H. Qed.

Lemma reff682_not2496 : ~ @Equation2496 Fin5 reff682_inst.
Proof. unfold Equation2496. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff682_inst, reff682_op in H. discriminate H. Qed.

Lemma reff682_not2504 : ~ @Equation2504 Fin5 reff682_inst.
Proof. unfold Equation2504. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff682_inst, reff682_op in H. discriminate H. Qed.

Lemma reff682_not2506 : ~ @Equation2506 Fin5 reff682_inst.
Proof. unfold Equation2506. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff682_inst, reff682_op in H. discriminate H. Qed.

Lemma reff682_not2507 : ~ @Equation2507 Fin5 reff682_inst.
Proof. unfold Equation2507. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff682_inst, reff682_op in H. discriminate H. Qed.

Lemma reff682_not2530 : ~ @Equation2530 Fin5 reff682_inst.
Proof. unfold Equation2530. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff682_inst, reff682_op in H. discriminate H. Qed.

Lemma reff682_not2531 : ~ @Equation2531 Fin5 reff682_inst.
Proof. unfold Equation2531. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff682_inst, reff682_op in H. discriminate H. Qed.

Lemma reff682_not2533 : ~ @Equation2533 Fin5 reff682_inst.
Proof. unfold Equation2533. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff682_inst, reff682_op in H. discriminate H. Qed.

Lemma reff682_not2534 : ~ @Equation2534 Fin5 reff682_inst.
Proof. unfold Equation2534. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff682_inst, reff682_op in H. discriminate H. Qed.

Lemma reff682_not2540 : ~ @Equation2540 Fin5 reff682_inst.
Proof. unfold Equation2540. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff682_inst, reff682_op in H. discriminate H. Qed.

Lemma reff682_not2543 : ~ @Equation2543 Fin5 reff682_inst.
Proof. unfold Equation2543. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff682_inst, reff682_op in H. discriminate H. Qed.

Lemma reff682_not2644 : ~ @Equation2644 Fin5 reff682_inst.
Proof. unfold Equation2644. intro H. specialize (H F5_1). unfold magma_op, reff682_inst, reff682_op in H. discriminate H. Qed.

Lemma reff682_not2847 : ~ @Equation2847 Fin5 reff682_inst.
Proof. unfold Equation2847. intro H. specialize (H F5_1). unfold magma_op, reff682_inst, reff682_op in H. discriminate H. Qed.

Lemma reff682_not3051 : ~ @Equation3051 Fin5 reff682_inst.
Proof. unfold Equation3051. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff682_inst, reff682_op in H. discriminate H. Qed.

Lemma reff682_not3052 : ~ @Equation3052 Fin5 reff682_inst.
Proof. unfold Equation3052. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff682_inst, reff682_op in H. discriminate H. Qed.

Lemma reff682_not3055 : ~ @Equation3055 Fin5 reff682_inst.
Proof. unfold Equation3055. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff682_inst, reff682_op in H. discriminate H. Qed.

Lemma reff682_not3056 : ~ @Equation3056 Fin5 reff682_inst.
Proof. unfold Equation3056. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff682_inst, reff682_op in H. discriminate H. Qed.

Lemma reff682_not3059 : ~ @Equation3059 Fin5 reff682_inst.
Proof. unfold Equation3059. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff682_inst, reff682_op in H. discriminate H. Qed.

Lemma reff682_not3065 : ~ @Equation3065 Fin5 reff682_inst.
Proof. unfold Equation3065. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff682_inst, reff682_op in H. discriminate H. Qed.

Lemma reff682_not3068 : ~ @Equation3068 Fin5 reff682_inst.
Proof. unfold Equation3068. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff682_inst, reff682_op in H. discriminate H. Qed.

Lemma reff682_not3069 : ~ @Equation3069 Fin5 reff682_inst.
Proof. unfold Equation3069. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff682_inst, reff682_op in H. discriminate H. Qed.

Lemma reff682_not3076 : ~ @Equation3076 Fin5 reff682_inst.
Proof. unfold Equation3076. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff682_inst, reff682_op in H. discriminate H. Qed.

Lemma reff682_not3078 : ~ @Equation3078 Fin5 reff682_inst.
Proof. unfold Equation3078. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff682_inst, reff682_op in H. discriminate H. Qed.

Lemma reff682_not3102 : ~ @Equation3102 Fin5 reff682_inst.
Proof. unfold Equation3102. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff682_inst, reff682_op in H. discriminate H. Qed.

Lemma reff682_not3103 : ~ @Equation3103 Fin5 reff682_inst.
Proof. unfold Equation3103. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff682_inst, reff682_op in H. discriminate H. Qed.

Lemma reff682_not3105 : ~ @Equation3105 Fin5 reff682_inst.
Proof. unfold Equation3105. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff682_inst, reff682_op in H. discriminate H. Qed.

Lemma reff682_not3106 : ~ @Equation3106 Fin5 reff682_inst.
Proof. unfold Equation3106. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff682_inst, reff682_op in H. discriminate H. Qed.

Lemma reff682_not3112 : ~ @Equation3112 Fin5 reff682_inst.
Proof. unfold Equation3112. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff682_inst, reff682_op in H. discriminate H. Qed.

Lemma reff682_not3113 : ~ @Equation3113 Fin5 reff682_inst.
Proof. unfold Equation3113. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff682_inst, reff682_op in H. discriminate H. Qed.

Lemma reff682_not3115 : ~ @Equation3115 Fin5 reff682_inst.
Proof. unfold Equation3115. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff682_inst, reff682_op in H. discriminate H. Qed.

Lemma reff682_not3116 : ~ @Equation3116 Fin5 reff682_inst.
Proof. unfold Equation3116. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff682_inst, reff682_op in H. discriminate H. Qed.

Lemma reff682_not3139 : ~ @Equation3139 Fin5 reff682_inst.
Proof. unfold Equation3139. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff682_inst, reff682_op in H. discriminate H. Qed.

Lemma reff682_not3140 : ~ @Equation3140 Fin5 reff682_inst.
Proof. unfold Equation3140. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff682_inst, reff682_op in H. discriminate H. Qed.

Lemma reff682_not3143 : ~ @Equation3143 Fin5 reff682_inst.
Proof. unfold Equation3143. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff682_inst, reff682_op in H. discriminate H. Qed.

Lemma reff682_not3149 : ~ @Equation3149 Fin5 reff682_inst.
Proof. unfold Equation3149. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff682_inst, reff682_op in H. discriminate H. Qed.

Lemma reff682_not3150 : ~ @Equation3150 Fin5 reff682_inst.
Proof. unfold Equation3150. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff682_inst, reff682_op in H. discriminate H. Qed.

Lemma reff682_not3152 : ~ @Equation3152 Fin5 reff682_inst.
Proof. unfold Equation3152. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff682_inst, reff682_op in H. discriminate H. Qed.

Lemma reff682_not3253 : ~ @Equation3253 Fin5 reff682_inst.
Proof. unfold Equation3253. intro H. specialize (H F5_1). unfold magma_op, reff682_inst, reff682_op in H. discriminate H. Qed.

Lemma reff682_not3457 : ~ @Equation3457 Fin5 reff682_inst.
Proof. unfold Equation3457. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff682_inst, reff682_op in H. discriminate H. Qed.

Lemma reff682_not3458 : ~ @Equation3458 Fin5 reff682_inst.
Proof. unfold Equation3458. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff682_inst, reff682_op in H. discriminate H. Qed.

Lemma reff682_not3461 : ~ @Equation3461 Fin5 reff682_inst.
Proof. unfold Equation3461. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff682_inst, reff682_op in H. discriminate H. Qed.

Lemma reff682_not3462 : ~ @Equation3462 Fin5 reff682_inst.
Proof. unfold Equation3462. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff682_inst, reff682_op in H. discriminate H. Qed.

Lemma reff682_not3464 : ~ @Equation3464 Fin5 reff682_inst.
Proof. unfold Equation3464. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff682_inst, reff682_op in H. discriminate H. Qed.

Lemma reff682_not3465 : ~ @Equation3465 Fin5 reff682_inst.
Proof. unfold Equation3465. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff682_inst, reff682_op in H. discriminate H. Qed.

Lemma reff682_not3472 : ~ @Equation3472 Fin5 reff682_inst.
Proof. unfold Equation3472. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff682_inst, reff682_op in H. discriminate H. Qed.

Lemma reff682_not3475 : ~ @Equation3475 Fin5 reff682_inst.
Proof. unfold Equation3475. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff682_inst, reff682_op in H. discriminate H. Qed.

Lemma reff682_not3481 : ~ @Equation3481 Fin5 reff682_inst.
Proof. unfold Equation3481. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff682_inst, reff682_op in H. discriminate H. Qed.

Lemma reff682_not3482 : ~ @Equation3482 Fin5 reff682_inst.
Proof. unfold Equation3482. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff682_inst, reff682_op in H. discriminate H. Qed.

Lemma reff682_not3484 : ~ @Equation3484 Fin5 reff682_inst.
Proof. unfold Equation3484. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff682_inst, reff682_op in H. discriminate H. Qed.

Lemma reff682_not3509 : ~ @Equation3509 Fin5 reff682_inst.
Proof. unfold Equation3509. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff682_inst, reff682_op in H. discriminate H. Qed.

Lemma reff682_not3511 : ~ @Equation3511 Fin5 reff682_inst.
Proof. unfold Equation3511. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff682_inst, reff682_op in H. discriminate H. Qed.

Lemma reff682_not3512 : ~ @Equation3512 Fin5 reff682_inst.
Proof. unfold Equation3512. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff682_inst, reff682_op in H. discriminate H. Qed.

Lemma reff682_not3519 : ~ @Equation3519 Fin5 reff682_inst.
Proof. unfold Equation3519. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff682_inst, reff682_op in H. discriminate H. Qed.

Lemma reff682_not3521 : ~ @Equation3521 Fin5 reff682_inst.
Proof. unfold Equation3521. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff682_inst, reff682_op in H. discriminate H. Qed.

Lemma reff682_not3545 : ~ @Equation3545 Fin5 reff682_inst.
Proof. unfold Equation3545. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff682_inst, reff682_op in H. discriminate H. Qed.

Lemma reff682_not3548 : ~ @Equation3548 Fin5 reff682_inst.
Proof. unfold Equation3548. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff682_inst, reff682_op in H. discriminate H. Qed.

Lemma reff682_not3549 : ~ @Equation3549 Fin5 reff682_inst.
Proof. unfold Equation3549. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff682_inst, reff682_op in H. discriminate H. Qed.

Lemma reff682_not3555 : ~ @Equation3555 Fin5 reff682_inst.
Proof. unfold Equation3555. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff682_inst, reff682_op in H. discriminate H. Qed.

Lemma reff682_not3556 : ~ @Equation3556 Fin5 reff682_inst.
Proof. unfold Equation3556. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff682_inst, reff682_op in H. discriminate H. Qed.

Lemma reff682_not3659 : ~ @Equation3659 Fin5 reff682_inst.
Proof. unfold Equation3659. intro H. specialize (H F5_1). unfold magma_op, reff682_inst, reff682_op in H. discriminate H. Qed.

Lemma reff682_not3862 : ~ @Equation3862 Fin5 reff682_inst.
Proof. unfold Equation3862. intro H. specialize (H F5_1). unfold magma_op, reff682_inst, reff682_op in H. discriminate H. Qed.

Lemma reff682_not4066 : ~ @Equation4066 Fin5 reff682_inst.
Proof. unfold Equation4066. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff682_inst, reff682_op in H. discriminate H. Qed.

Lemma reff682_not4067 : ~ @Equation4067 Fin5 reff682_inst.
Proof. unfold Equation4067. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff682_inst, reff682_op in H. discriminate H. Qed.

Lemma reff682_not4070 : ~ @Equation4070 Fin5 reff682_inst.
Proof. unfold Equation4070. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff682_inst, reff682_op in H. discriminate H. Qed.

Lemma reff682_not4071 : ~ @Equation4071 Fin5 reff682_inst.
Proof. unfold Equation4071. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff682_inst, reff682_op in H. discriminate H. Qed.

Lemma reff682_not4074 : ~ @Equation4074 Fin5 reff682_inst.
Proof. unfold Equation4074. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff682_inst, reff682_op in H. discriminate H. Qed.

Lemma reff682_not4080 : ~ @Equation4080 Fin5 reff682_inst.
Proof. unfold Equation4080. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff682_inst, reff682_op in H. discriminate H. Qed.

Lemma reff682_not4083 : ~ @Equation4083 Fin5 reff682_inst.
Proof. unfold Equation4083. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff682_inst, reff682_op in H. discriminate H. Qed.

Lemma reff682_not4084 : ~ @Equation4084 Fin5 reff682_inst.
Proof. unfold Equation4084. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff682_inst, reff682_op in H. discriminate H. Qed.

Lemma reff682_not4090 : ~ @Equation4090 Fin5 reff682_inst.
Proof. unfold Equation4090. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff682_inst, reff682_op in H. discriminate H. Qed.

Lemma reff682_not4093 : ~ @Equation4093 Fin5 reff682_inst.
Proof. unfold Equation4093. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff682_inst, reff682_op in H. discriminate H. Qed.

Lemma reff682_not4120 : ~ @Equation4120 Fin5 reff682_inst.
Proof. unfold Equation4120. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff682_inst, reff682_op in H. discriminate H. Qed.

Lemma reff682_not4121 : ~ @Equation4121 Fin5 reff682_inst.
Proof. unfold Equation4121. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff682_inst, reff682_op in H. discriminate H. Qed.

Lemma reff682_not4128 : ~ @Equation4128 Fin5 reff682_inst.
Proof. unfold Equation4128. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff682_inst, reff682_op in H. discriminate H. Qed.

Lemma reff682_not4130 : ~ @Equation4130 Fin5 reff682_inst.
Proof. unfold Equation4130. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff682_inst, reff682_op in H. discriminate H. Qed.

Lemma reff682_not4155 : ~ @Equation4155 Fin5 reff682_inst.
Proof. unfold Equation4155. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff682_inst, reff682_op in H. discriminate H. Qed.

Lemma reff682_not4157 : ~ @Equation4157 Fin5 reff682_inst.
Proof. unfold Equation4157. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff682_inst, reff682_op in H. discriminate H. Qed.

Lemma reff682_not4158 : ~ @Equation4158 Fin5 reff682_inst.
Proof. unfold Equation4158. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff682_inst, reff682_op in H. discriminate H. Qed.

Lemma reff682_not4164 : ~ @Equation4164 Fin5 reff682_inst.
Proof. unfold Equation4164. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff682_inst, reff682_op in H. discriminate H. Qed.

Lemma reff682_not4165 : ~ @Equation4165 Fin5 reff682_inst.
Proof. unfold Equation4165. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff682_inst, reff682_op in H. discriminate H. Qed.

Lemma reff682_not4167 : ~ @Equation4167 Fin5 reff682_inst.
Proof. unfold Equation4167. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff682_inst, reff682_op in H. discriminate H. Qed.

Lemma reff682_not4268 : ~ @Equation4268 Fin5 reff682_inst.
Proof. unfold Equation4268. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff682_inst, reff682_op in H. discriminate H. Qed.

Lemma reff682_not4269 : ~ @Equation4269 Fin5 reff682_inst.
Proof. unfold Equation4269. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff682_inst, reff682_op in H. discriminate H. Qed.

Lemma reff682_not4270 : ~ @Equation4270 Fin5 reff682_inst.
Proof. unfold Equation4270. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff682_inst, reff682_op in H. discriminate H. Qed.

Lemma reff682_not4272 : ~ @Equation4272 Fin5 reff682_inst.
Proof. unfold Equation4272. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff682_inst, reff682_op in H. discriminate H. Qed.

Lemma reff682_not4273 : ~ @Equation4273 Fin5 reff682_inst.
Proof. unfold Equation4273. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff682_inst, reff682_op in H. discriminate H. Qed.

Lemma reff682_not4275 : ~ @Equation4275 Fin5 reff682_inst.
Proof. unfold Equation4275. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff682_inst, reff682_op in H. discriminate H. Qed.

Lemma reff682_not4283 : ~ @Equation4283 Fin5 reff682_inst.
Proof. unfold Equation4283. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff682_inst, reff682_op in H. discriminate H. Qed.

Lemma reff682_not4284 : ~ @Equation4284 Fin5 reff682_inst.
Proof. unfold Equation4284. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff682_inst, reff682_op in H. discriminate H. Qed.

Lemma reff682_not4291 : ~ @Equation4291 Fin5 reff682_inst.
Proof. unfold Equation4291. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff682_inst, reff682_op in H. discriminate H. Qed.

Lemma reff682_not4293 : ~ @Equation4293 Fin5 reff682_inst.
Proof. unfold Equation4293. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff682_inst, reff682_op in H. discriminate H. Qed.

Lemma reff682_not4314 : ~ @Equation4314 Fin5 reff682_inst.
Proof. unfold Equation4314. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff682_inst, reff682_op in H. discriminate H. Qed.

Lemma reff682_not4320 : ~ @Equation4320 Fin5 reff682_inst.
Proof. unfold Equation4320. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff682_inst, reff682_op in H. discriminate H. Qed.

Lemma reff682_not4321 : ~ @Equation4321 Fin5 reff682_inst.
Proof. unfold Equation4321. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff682_inst, reff682_op in H. discriminate H. Qed.

Lemma reff682_not4343 : ~ @Equation4343 Fin5 reff682_inst.
Proof. unfold Equation4343. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff682_inst, reff682_op in H. discriminate H. Qed.

Lemma reff682_not4380 : ~ @Equation4380 Fin5 reff682_inst.
Proof. unfold Equation4380. intro H. specialize (H F5_1). unfold magma_op, reff682_inst, reff682_op in H. discriminate H. Qed.

Lemma reff682_not4583 : ~ @Equation4583 Fin5 reff682_inst.
Proof. unfold Equation4583. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff682_inst, reff682_op in H. discriminate H. Qed.

Lemma reff682_not4584 : ~ @Equation4584 Fin5 reff682_inst.
Proof. unfold Equation4584. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff682_inst, reff682_op in H. discriminate H. Qed.

Lemma reff682_not4587 : ~ @Equation4587 Fin5 reff682_inst.
Proof. unfold Equation4587. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff682_inst, reff682_op in H. discriminate H. Qed.

Lemma reff682_not4588 : ~ @Equation4588 Fin5 reff682_inst.
Proof. unfold Equation4588. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff682_inst, reff682_op in H. discriminate H. Qed.

Lemma reff682_not4590 : ~ @Equation4590 Fin5 reff682_inst.
Proof. unfold Equation4590. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff682_inst, reff682_op in H. discriminate H. Qed.

Lemma reff682_not4591 : ~ @Equation4591 Fin5 reff682_inst.
Proof. unfold Equation4591. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff682_inst, reff682_op in H. discriminate H. Qed.

Lemma reff682_not4598 : ~ @Equation4598 Fin5 reff682_inst.
Proof. unfold Equation4598. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff682_inst, reff682_op in H. discriminate H. Qed.

Lemma reff682_not4599 : ~ @Equation4599 Fin5 reff682_inst.
Proof. unfold Equation4599. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff682_inst, reff682_op in H. discriminate H. Qed.

Lemma reff682_not4605 : ~ @Equation4605 Fin5 reff682_inst.
Proof. unfold Equation4605. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff682_inst, reff682_op in H. discriminate H. Qed.

Lemma reff682_not4606 : ~ @Equation4606 Fin5 reff682_inst.
Proof. unfold Equation4606. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff682_inst, reff682_op in H. discriminate H. Qed.

Lemma reff682_not4629 : ~ @Equation4629 Fin5 reff682_inst.
Proof. unfold Equation4629. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff682_inst, reff682_op in H. discriminate H. Qed.

Lemma reff682_not4635 : ~ @Equation4635 Fin5 reff682_inst.
Proof. unfold Equation4635. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff682_inst, reff682_op in H. discriminate H. Qed.

Lemma reff682_not4636 : ~ @Equation4636 Fin5 reff682_inst.
Proof. unfold Equation4636. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff682_inst, reff682_op in H. discriminate H. Qed.

Lemma reff682_not4658 : ~ @Equation4658 Fin5 reff682_inst.
Proof. unfold Equation4658. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff682_inst, reff682_op in H. discriminate H. Qed.
