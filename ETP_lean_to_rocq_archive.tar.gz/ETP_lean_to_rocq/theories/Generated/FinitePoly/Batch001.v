(** * FinitePoly counterexamples — batch 1
    Auto-generated from Lean4 FinitePoly files. *)

From Stdlib Require Import Utf8.

From ETP Require Import Magma.
From ETP Require Import FinMagma.
From ETP.Equations Require Import All.

Open Scope magma_scope.

(** ---- reff108 (Fin2) ---- *)

Definition reff108_op (x y : Fin2) : Fin2 :=
  match x, y with
  | F2_0, F2_0 => F2_0 | F2_0, F2_1 => F2_1
  | F2_1, F2_0 => F2_1 | F2_1, F2_1 => F2_0
  end.

#[local] Instance reff108_inst : Magma Fin2 := {| magma_op := reff108_op |}.

Lemma reff108_sat11 : @Equation11 Fin2 reff108_inst.
Proof. unfold Equation11, magma_op, reff108_inst, reff108_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff108_sat14 : @Equation14 Fin2 reff108_inst.
Proof. unfold Equation14, magma_op, reff108_inst, reff108_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff108_sat26 : @Equation26 Fin2 reff108_inst.
Proof. unfold Equation26, magma_op, reff108_inst, reff108_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff108_sat452 : @Equation452 Fin2 reff108_inst.
Proof. unfold Equation452, magma_op, reff108_inst, reff108_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff108_sat455 : @Equation455 Fin2 reff108_inst.
Proof. unfold Equation455, magma_op, reff108_inst, reff108_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff108_sat481 : @Equation481 Fin2 reff108_inst.
Proof. unfold Equation481, magma_op, reff108_inst, reff108_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff108_sat492 : @Equation492 Fin2 reff108_inst.
Proof. unfold Equation492, magma_op, reff108_inst, reff108_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff108_sat508 : @Equation508 Fin2 reff108_inst.
Proof. unfold Equation508, magma_op, reff108_inst, reff108_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff108_sat522 : @Equation522 Fin2 reff108_inst.
Proof. unfold Equation522, magma_op, reff108_inst, reff108_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff108_sat543 : @Equation543 Fin2 reff108_inst.
Proof. unfold Equation543, magma_op, reff108_inst, reff108_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff108_sat546 : @Equation546 Fin2 reff108_inst.
Proof. unfold Equation546, magma_op, reff108_inst, reff108_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff108_sat556 : @Equation556 Fin2 reff108_inst.
Proof. unfold Equation556, magma_op, reff108_inst, reff108_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff108_sat572 : @Equation572 Fin2 reff108_inst.
Proof. unfold Equation572, magma_op, reff108_inst, reff108_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff108_sat647 : @Equation647 Fin2 reff108_inst.
Proof. unfold Equation647, magma_op, reff108_inst, reff108_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff108_sat655 : @Equation655 Fin2 reff108_inst.
Proof. unfold Equation655, magma_op, reff108_inst, reff108_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff108_sat658 : @Equation658 Fin2 reff108_inst.
Proof. unfold Equation658, magma_op, reff108_inst, reff108_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff108_sat684 : @Equation684 Fin2 reff108_inst.
Proof. unfold Equation684, magma_op, reff108_inst, reff108_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff108_sat692 : @Equation692 Fin2 reff108_inst.
Proof. unfold Equation692, magma_op, reff108_inst, reff108_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff108_sat695 : @Equation695 Fin2 reff108_inst.
Proof. unfold Equation695, magma_op, reff108_inst, reff108_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff108_sat711 : @Equation711 Fin2 reff108_inst.
Proof. unfold Equation711, magma_op, reff108_inst, reff108_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff108_sat725 : @Equation725 Fin2 reff108_inst.
Proof. unfold Equation725, magma_op, reff108_inst, reff108_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff108_sat749 : @Equation749 Fin2 reff108_inst.
Proof. unfold Equation749, magma_op, reff108_inst, reff108_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff108_sat759 : @Equation759 Fin2 reff108_inst.
Proof. unfold Equation759, magma_op, reff108_inst, reff108_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff108_sat775 : @Equation775 Fin2 reff108_inst.
Proof. unfold Equation775, magma_op, reff108_inst, reff108_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff108_sat861 : @Equation861 Fin2 reff108_inst.
Proof. unfold Equation861, magma_op, reff108_inst, reff108_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff108_sat887 : @Equation887 Fin2 reff108_inst.
Proof. unfold Equation887, magma_op, reff108_inst, reff108_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff108_sat895 : @Equation895 Fin2 reff108_inst.
Proof. unfold Equation895, magma_op, reff108_inst, reff108_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff108_sat898 : @Equation898 Fin2 reff108_inst.
Proof. unfold Equation898, magma_op, reff108_inst, reff108_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff108_sat914 : @Equation914 Fin2 reff108_inst.
Proof. unfold Equation914, magma_op, reff108_inst, reff108_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff108_sat928 : @Equation928 Fin2 reff108_inst.
Proof. unfold Equation928, magma_op, reff108_inst, reff108_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff108_sat949 : @Equation949 Fin2 reff108_inst.
Proof. unfold Equation949, magma_op, reff108_inst, reff108_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff108_sat952 : @Equation952 Fin2 reff108_inst.
Proof. unfold Equation952, magma_op, reff108_inst, reff108_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff108_sat962 : @Equation962 Fin2 reff108_inst.
Proof. unfold Equation962, magma_op, reff108_inst, reff108_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff108_sat978 : @Equation978 Fin2 reff108_inst.
Proof. unfold Equation978, magma_op, reff108_inst, reff108_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff108_sat1053 : @Equation1053 Fin2 reff108_inst.
Proof. unfold Equation1053, magma_op, reff108_inst, reff108_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff108_sat1061 : @Equation1061 Fin2 reff108_inst.
Proof. unfold Equation1061, magma_op, reff108_inst, reff108_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff108_sat1090 : @Equation1090 Fin2 reff108_inst.
Proof. unfold Equation1090, magma_op, reff108_inst, reff108_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff108_sat1098 : @Equation1098 Fin2 reff108_inst.
Proof. unfold Equation1098, magma_op, reff108_inst, reff108_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff108_sat1101 : @Equation1101 Fin2 reff108_inst.
Proof. unfold Equation1101, magma_op, reff108_inst, reff108_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff108_sat1117 : @Equation1117 Fin2 reff108_inst.
Proof. unfold Equation1117, magma_op, reff108_inst, reff108_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff108_sat1131 : @Equation1131 Fin2 reff108_inst.
Proof. unfold Equation1131, magma_op, reff108_inst, reff108_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff108_sat1152 : @Equation1152 Fin2 reff108_inst.
Proof. unfold Equation1152, magma_op, reff108_inst, reff108_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff108_sat1165 : @Equation1165 Fin2 reff108_inst.
Proof. unfold Equation1165, magma_op, reff108_inst, reff108_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff108_sat1181 : @Equation1181 Fin2 reff108_inst.
Proof. unfold Equation1181, magma_op, reff108_inst, reff108_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff108_sat1256 : @Equation1256 Fin2 reff108_inst.
Proof. unfold Equation1256, magma_op, reff108_inst, reff108_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff108_sat1264 : @Equation1264 Fin2 reff108_inst.
Proof. unfold Equation1264, magma_op, reff108_inst, reff108_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff108_sat1267 : @Equation1267 Fin2 reff108_inst.
Proof. unfold Equation1267, magma_op, reff108_inst, reff108_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff108_sat1293 : @Equation1293 Fin2 reff108_inst.
Proof. unfold Equation1293, magma_op, reff108_inst, reff108_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff108_sat1301 : @Equation1301 Fin2 reff108_inst.
Proof. unfold Equation1301, magma_op, reff108_inst, reff108_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff108_sat1304 : @Equation1304 Fin2 reff108_inst.
Proof. unfold Equation1304, magma_op, reff108_inst, reff108_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff108_sat1320 : @Equation1320 Fin2 reff108_inst.
Proof. unfold Equation1320, magma_op, reff108_inst, reff108_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff108_sat1334 : @Equation1334 Fin2 reff108_inst.
Proof. unfold Equation1334, magma_op, reff108_inst, reff108_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff108_sat1355 : @Equation1355 Fin2 reff108_inst.
Proof. unfold Equation1355, magma_op, reff108_inst, reff108_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff108_sat1358 : @Equation1358 Fin2 reff108_inst.
Proof. unfold Equation1358, magma_op, reff108_inst, reff108_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff108_sat1368 : @Equation1368 Fin2 reff108_inst.
Proof. unfold Equation1368, magma_op, reff108_inst, reff108_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff108_sat1384 : @Equation1384 Fin2 reff108_inst.
Proof. unfold Equation1384, magma_op, reff108_inst, reff108_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff108_sat1459 : @Equation1459 Fin2 reff108_inst.
Proof. unfold Equation1459, magma_op, reff108_inst, reff108_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff108_sat1467 : @Equation1467 Fin2 reff108_inst.
Proof. unfold Equation1467, magma_op, reff108_inst, reff108_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff108_sat1470 : @Equation1470 Fin2 reff108_inst.
Proof. unfold Equation1470, magma_op, reff108_inst, reff108_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff108_sat1496 : @Equation1496 Fin2 reff108_inst.
Proof. unfold Equation1496, magma_op, reff108_inst, reff108_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff108_sat1504 : @Equation1504 Fin2 reff108_inst.
Proof. unfold Equation1504, magma_op, reff108_inst, reff108_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff108_sat1507 : @Equation1507 Fin2 reff108_inst.
Proof. unfold Equation1507, magma_op, reff108_inst, reff108_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff108_sat1523 : @Equation1523 Fin2 reff108_inst.
Proof. unfold Equation1523, magma_op, reff108_inst, reff108_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff108_sat1537 : @Equation1537 Fin2 reff108_inst.
Proof. unfold Equation1537, magma_op, reff108_inst, reff108_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff108_sat1561 : @Equation1561 Fin2 reff108_inst.
Proof. unfold Equation1561, magma_op, reff108_inst, reff108_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff108_sat1571 : @Equation1571 Fin2 reff108_inst.
Proof. unfold Equation1571, magma_op, reff108_inst, reff108_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff108_sat1587 : @Equation1587 Fin2 reff108_inst.
Proof. unfold Equation1587, magma_op, reff108_inst, reff108_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff108_sat1670 : @Equation1670 Fin2 reff108_inst.
Proof. unfold Equation1670, magma_op, reff108_inst, reff108_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff108_sat1673 : @Equation1673 Fin2 reff108_inst.
Proof. unfold Equation1673, magma_op, reff108_inst, reff108_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff108_sat1699 : @Equation1699 Fin2 reff108_inst.
Proof. unfold Equation1699, magma_op, reff108_inst, reff108_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff108_sat1710 : @Equation1710 Fin2 reff108_inst.
Proof. unfold Equation1710, magma_op, reff108_inst, reff108_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff108_sat1726 : @Equation1726 Fin2 reff108_inst.
Proof. unfold Equation1726, magma_op, reff108_inst, reff108_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff108_sat1740 : @Equation1740 Fin2 reff108_inst.
Proof. unfold Equation1740, magma_op, reff108_inst, reff108_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff108_sat1761 : @Equation1761 Fin2 reff108_inst.
Proof. unfold Equation1761, magma_op, reff108_inst, reff108_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff108_sat1764 : @Equation1764 Fin2 reff108_inst.
Proof. unfold Equation1764, magma_op, reff108_inst, reff108_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff108_sat1774 : @Equation1774 Fin2 reff108_inst.
Proof. unfold Equation1774, magma_op, reff108_inst, reff108_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff108_sat1790 : @Equation1790 Fin2 reff108_inst.
Proof. unfold Equation1790, magma_op, reff108_inst, reff108_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff108_sat1876 : @Equation1876 Fin2 reff108_inst.
Proof. unfold Equation1876, magma_op, reff108_inst, reff108_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff108_sat1902 : @Equation1902 Fin2 reff108_inst.
Proof. unfold Equation1902, magma_op, reff108_inst, reff108_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff108_sat1910 : @Equation1910 Fin2 reff108_inst.
Proof. unfold Equation1910, magma_op, reff108_inst, reff108_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff108_sat1913 : @Equation1913 Fin2 reff108_inst.
Proof. unfold Equation1913, magma_op, reff108_inst, reff108_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff108_sat1929 : @Equation1929 Fin2 reff108_inst.
Proof. unfold Equation1929, magma_op, reff108_inst, reff108_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff108_sat1943 : @Equation1943 Fin2 reff108_inst.
Proof. unfold Equation1943, magma_op, reff108_inst, reff108_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff108_sat1964 : @Equation1964 Fin2 reff108_inst.
Proof. unfold Equation1964, magma_op, reff108_inst, reff108_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff108_sat1967 : @Equation1967 Fin2 reff108_inst.
Proof. unfold Equation1967, magma_op, reff108_inst, reff108_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff108_sat1993 : @Equation1993 Fin2 reff108_inst.
Proof. unfold Equation1993, magma_op, reff108_inst, reff108_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff108_sat2068 : @Equation2068 Fin2 reff108_inst.
Proof. unfold Equation2068, magma_op, reff108_inst, reff108_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff108_sat2076 : @Equation2076 Fin2 reff108_inst.
Proof. unfold Equation2076, magma_op, reff108_inst, reff108_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff108_sat2079 : @Equation2079 Fin2 reff108_inst.
Proof. unfold Equation2079, magma_op, reff108_inst, reff108_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff108_sat2105 : @Equation2105 Fin2 reff108_inst.
Proof. unfold Equation2105, magma_op, reff108_inst, reff108_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff108_sat2113 : @Equation2113 Fin2 reff108_inst.
Proof. unfold Equation2113, magma_op, reff108_inst, reff108_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff108_sat2116 : @Equation2116 Fin2 reff108_inst.
Proof. unfold Equation2116, magma_op, reff108_inst, reff108_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff108_sat2132 : @Equation2132 Fin2 reff108_inst.
Proof. unfold Equation2132, magma_op, reff108_inst, reff108_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff108_sat2146 : @Equation2146 Fin2 reff108_inst.
Proof. unfold Equation2146, magma_op, reff108_inst, reff108_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff108_sat2170 : @Equation2170 Fin2 reff108_inst.
Proof. unfold Equation2170, magma_op, reff108_inst, reff108_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff108_sat2180 : @Equation2180 Fin2 reff108_inst.
Proof. unfold Equation2180, magma_op, reff108_inst, reff108_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff108_sat2196 : @Equation2196 Fin2 reff108_inst.
Proof. unfold Equation2196, magma_op, reff108_inst, reff108_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff108_sat2271 : @Equation2271 Fin2 reff108_inst.
Proof. unfold Equation2271, magma_op, reff108_inst, reff108_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff108_sat2279 : @Equation2279 Fin2 reff108_inst.
Proof. unfold Equation2279, magma_op, reff108_inst, reff108_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff108_sat2282 : @Equation2282 Fin2 reff108_inst.
Proof. unfold Equation2282, magma_op, reff108_inst, reff108_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff108_sat2308 : @Equation2308 Fin2 reff108_inst.
Proof. unfold Equation2308, magma_op, reff108_inst, reff108_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff108_sat2316 : @Equation2316 Fin2 reff108_inst.
Proof. unfold Equation2316, magma_op, reff108_inst, reff108_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff108_sat2319 : @Equation2319 Fin2 reff108_inst.
Proof. unfold Equation2319, magma_op, reff108_inst, reff108_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff108_sat2335 : @Equation2335 Fin2 reff108_inst.
Proof. unfold Equation2335, magma_op, reff108_inst, reff108_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff108_sat2349 : @Equation2349 Fin2 reff108_inst.
Proof. unfold Equation2349, magma_op, reff108_inst, reff108_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff108_sat2370 : @Equation2370 Fin2 reff108_inst.
Proof. unfold Equation2370, magma_op, reff108_inst, reff108_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff108_sat2373 : @Equation2373 Fin2 reff108_inst.
Proof. unfold Equation2373, magma_op, reff108_inst, reff108_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff108_sat2383 : @Equation2383 Fin2 reff108_inst.
Proof. unfold Equation2383, magma_op, reff108_inst, reff108_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff108_sat2399 : @Equation2399 Fin2 reff108_inst.
Proof. unfold Equation2399, magma_op, reff108_inst, reff108_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff108_sat2474 : @Equation2474 Fin2 reff108_inst.
Proof. unfold Equation2474, magma_op, reff108_inst, reff108_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff108_sat2482 : @Equation2482 Fin2 reff108_inst.
Proof. unfold Equation2482, magma_op, reff108_inst, reff108_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff108_sat2511 : @Equation2511 Fin2 reff108_inst.
Proof. unfold Equation2511, magma_op, reff108_inst, reff108_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff108_sat2519 : @Equation2519 Fin2 reff108_inst.
Proof. unfold Equation2519, magma_op, reff108_inst, reff108_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff108_sat2522 : @Equation2522 Fin2 reff108_inst.
Proof. unfold Equation2522, magma_op, reff108_inst, reff108_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff108_sat2538 : @Equation2538 Fin2 reff108_inst.
Proof. unfold Equation2538, magma_op, reff108_inst, reff108_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff108_sat2552 : @Equation2552 Fin2 reff108_inst.
Proof. unfold Equation2552, magma_op, reff108_inst, reff108_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff108_sat2573 : @Equation2573 Fin2 reff108_inst.
Proof. unfold Equation2573, magma_op, reff108_inst, reff108_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff108_sat2586 : @Equation2586 Fin2 reff108_inst.
Proof. unfold Equation2586, magma_op, reff108_inst, reff108_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff108_sat2602 : @Equation2602 Fin2 reff108_inst.
Proof. unfold Equation2602, magma_op, reff108_inst, reff108_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff108_sat2677 : @Equation2677 Fin2 reff108_inst.
Proof. unfold Equation2677, magma_op, reff108_inst, reff108_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff108_sat2685 : @Equation2685 Fin2 reff108_inst.
Proof. unfold Equation2685, magma_op, reff108_inst, reff108_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff108_sat2688 : @Equation2688 Fin2 reff108_inst.
Proof. unfold Equation2688, magma_op, reff108_inst, reff108_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff108_sat2714 : @Equation2714 Fin2 reff108_inst.
Proof. unfold Equation2714, magma_op, reff108_inst, reff108_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff108_sat2722 : @Equation2722 Fin2 reff108_inst.
Proof. unfold Equation2722, magma_op, reff108_inst, reff108_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff108_sat2725 : @Equation2725 Fin2 reff108_inst.
Proof. unfold Equation2725, magma_op, reff108_inst, reff108_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff108_sat2741 : @Equation2741 Fin2 reff108_inst.
Proof. unfold Equation2741, magma_op, reff108_inst, reff108_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff108_sat2755 : @Equation2755 Fin2 reff108_inst.
Proof. unfold Equation2755, magma_op, reff108_inst, reff108_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff108_sat2776 : @Equation2776 Fin2 reff108_inst.
Proof. unfold Equation2776, magma_op, reff108_inst, reff108_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff108_sat2779 : @Equation2779 Fin2 reff108_inst.
Proof. unfold Equation2779, magma_op, reff108_inst, reff108_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff108_sat2789 : @Equation2789 Fin2 reff108_inst.
Proof. unfold Equation2789, magma_op, reff108_inst, reff108_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff108_sat2805 : @Equation2805 Fin2 reff108_inst.
Proof. unfold Equation2805, magma_op, reff108_inst, reff108_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff108_sat2880 : @Equation2880 Fin2 reff108_inst.
Proof. unfold Equation2880, magma_op, reff108_inst, reff108_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff108_sat2888 : @Equation2888 Fin2 reff108_inst.
Proof. unfold Equation2888, magma_op, reff108_inst, reff108_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff108_sat2891 : @Equation2891 Fin2 reff108_inst.
Proof. unfold Equation2891, magma_op, reff108_inst, reff108_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff108_sat2917 : @Equation2917 Fin2 reff108_inst.
Proof. unfold Equation2917, magma_op, reff108_inst, reff108_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff108_sat2925 : @Equation2925 Fin2 reff108_inst.
Proof. unfold Equation2925, magma_op, reff108_inst, reff108_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff108_sat2928 : @Equation2928 Fin2 reff108_inst.
Proof. unfold Equation2928, magma_op, reff108_inst, reff108_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff108_sat2944 : @Equation2944 Fin2 reff108_inst.
Proof. unfold Equation2944, magma_op, reff108_inst, reff108_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff108_sat2958 : @Equation2958 Fin2 reff108_inst.
Proof. unfold Equation2958, magma_op, reff108_inst, reff108_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff108_sat2982 : @Equation2982 Fin2 reff108_inst.
Proof. unfold Equation2982, magma_op, reff108_inst, reff108_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff108_sat2992 : @Equation2992 Fin2 reff108_inst.
Proof. unfold Equation2992, magma_op, reff108_inst, reff108_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff108_sat3008 : @Equation3008 Fin2 reff108_inst.
Proof. unfold Equation3008, magma_op, reff108_inst, reff108_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff108_sat3091 : @Equation3091 Fin2 reff108_inst.
Proof. unfold Equation3091, magma_op, reff108_inst, reff108_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff108_sat3120 : @Equation3120 Fin2 reff108_inst.
Proof. unfold Equation3120, magma_op, reff108_inst, reff108_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff108_sat3128 : @Equation3128 Fin2 reff108_inst.
Proof. unfold Equation3128, magma_op, reff108_inst, reff108_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff108_sat3131 : @Equation3131 Fin2 reff108_inst.
Proof. unfold Equation3131, magma_op, reff108_inst, reff108_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff108_sat3147 : @Equation3147 Fin2 reff108_inst.
Proof. unfold Equation3147, magma_op, reff108_inst, reff108_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff108_sat3161 : @Equation3161 Fin2 reff108_inst.
Proof. unfold Equation3161, magma_op, reff108_inst, reff108_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff108_sat3182 : @Equation3182 Fin2 reff108_inst.
Proof. unfold Equation3182, magma_op, reff108_inst, reff108_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff108_sat3185 : @Equation3185 Fin2 reff108_inst.
Proof. unfold Equation3185, magma_op, reff108_inst, reff108_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff108_sat3211 : @Equation3211 Fin2 reff108_inst.
Proof. unfold Equation3211, magma_op, reff108_inst, reff108_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff108_sat3294 : @Equation3294 Fin2 reff108_inst.
Proof. unfold Equation3294, magma_op, reff108_inst, reff108_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff108_sat3297 : @Equation3297 Fin2 reff108_inst.
Proof. unfold Equation3297, magma_op, reff108_inst, reff108_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff108_sat3350 : @Equation3350 Fin2 reff108_inst.
Proof. unfold Equation3350, magma_op, reff108_inst, reff108_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff108_sat3364 : @Equation3364 Fin2 reff108_inst.
Proof. unfold Equation3364, magma_op, reff108_inst, reff108_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff108_sat3385 : @Equation3385 Fin2 reff108_inst.
Proof. unfold Equation3385, magma_op, reff108_inst, reff108_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff108_sat3398 : @Equation3398 Fin2 reff108_inst.
Proof. unfold Equation3398, magma_op, reff108_inst, reff108_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff108_sat3404 : @Equation3404 Fin2 reff108_inst.
Proof. unfold Equation3404, magma_op, reff108_inst, reff108_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff108_sat3417 : @Equation3417 Fin2 reff108_inst.
Proof. unfold Equation3417, magma_op, reff108_inst, reff108_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff108_sat3489 : @Equation3489 Fin2 reff108_inst.
Proof. unfold Equation3489, magma_op, reff108_inst, reff108_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff108_sat3601 : @Equation3601 Fin2 reff108_inst.
Proof. unfold Equation3601, magma_op, reff108_inst, reff108_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff108_sat3607 : @Equation3607 Fin2 reff108_inst.
Proof. unfold Equation3607, magma_op, reff108_inst, reff108_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff108_sat3620 : @Equation3620 Fin2 reff108_inst.
Proof. unfold Equation3620, magma_op, reff108_inst, reff108_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff108_sat3703 : @Equation3703 Fin2 reff108_inst.
Proof. unfold Equation3703, magma_op, reff108_inst, reff108_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff108_sat3737 : @Equation3737 Fin2 reff108_inst.
Proof. unfold Equation3737, magma_op, reff108_inst, reff108_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff108_sat3756 : @Equation3756 Fin2 reff108_inst.
Proof. unfold Equation3756, magma_op, reff108_inst, reff108_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff108_sat3776 : @Equation3776 Fin2 reff108_inst.
Proof. unfold Equation3776, magma_op, reff108_inst, reff108_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff108_sat3804 : @Equation3804 Fin2 reff108_inst.
Proof. unfold Equation3804, magma_op, reff108_inst, reff108_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff108_sat3823 : @Equation3823 Fin2 reff108_inst.
Proof. unfold Equation3823, magma_op, reff108_inst, reff108_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff108_sat3895 : @Equation3895 Fin2 reff108_inst.
Proof. unfold Equation3895, magma_op, reff108_inst, reff108_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff108_sat3940 : @Equation3940 Fin2 reff108_inst.
Proof. unfold Equation3940, magma_op, reff108_inst, reff108_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff108_sat3959 : @Equation3959 Fin2 reff108_inst.
Proof. unfold Equation3959, magma_op, reff108_inst, reff108_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff108_sat3973 : @Equation3973 Fin2 reff108_inst.
Proof. unfold Equation3973, magma_op, reff108_inst, reff108_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff108_sat4007 : @Equation4007 Fin2 reff108_inst.
Proof. unfold Equation4007, magma_op, reff108_inst, reff108_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff108_sat4106 : @Equation4106 Fin2 reff108_inst.
Proof. unfold Equation4106, magma_op, reff108_inst, reff108_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff108_sat4109 : @Equation4109 Fin2 reff108_inst.
Proof. unfold Equation4109, magma_op, reff108_inst, reff108_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff108_sat4143 : @Equation4143 Fin2 reff108_inst.
Proof. unfold Equation4143, magma_op, reff108_inst, reff108_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff108_sat4176 : @Equation4176 Fin2 reff108_inst.
Proof. unfold Equation4176, magma_op, reff108_inst, reff108_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff108_sat4197 : @Equation4197 Fin2 reff108_inst.
Proof. unfold Equation4197, magma_op, reff108_inst, reff108_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff108_sat4210 : @Equation4210 Fin2 reff108_inst.
Proof. unfold Equation4210, magma_op, reff108_inst, reff108_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff108_sat4216 : @Equation4216 Fin2 reff108_inst.
Proof. unfold Equation4216, magma_op, reff108_inst, reff108_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff108_sat4229 : @Equation4229 Fin2 reff108_inst.
Proof. unfold Equation4229, magma_op, reff108_inst, reff108_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff108_sat4297 : @Equation4297 Fin2 reff108_inst.
Proof. unfold Equation4297, magma_op, reff108_inst, reff108_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff108_sat4305 : @Equation4305 Fin2 reff108_inst.
Proof. unfold Equation4305, magma_op, reff108_inst, reff108_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff108_sat4325 : @Equation4325 Fin2 reff108_inst.
Proof. unfold Equation4325, magma_op, reff108_inst, reff108_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff108_sat4413 : @Equation4413 Fin2 reff108_inst.
Proof. unfold Equation4413, magma_op, reff108_inst, reff108_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff108_sat4421 : @Equation4421 Fin2 reff108_inst.
Proof. unfold Equation4421, magma_op, reff108_inst, reff108_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff108_sat4450 : @Equation4450 Fin2 reff108_inst.
Proof. unfold Equation4450, magma_op, reff108_inst, reff108_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff108_sat4461 : @Equation4461 Fin2 reff108_inst.
Proof. unfold Equation4461, magma_op, reff108_inst, reff108_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff108_sat4477 : @Equation4477 Fin2 reff108_inst.
Proof. unfold Equation4477, magma_op, reff108_inst, reff108_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff108_sat4491 : @Equation4491 Fin2 reff108_inst.
Proof. unfold Equation4491, magma_op, reff108_inst, reff108_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff108_sat4497 : @Equation4497 Fin2 reff108_inst.
Proof. unfold Equation4497, magma_op, reff108_inst, reff108_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff108_sat4612 : @Equation4612 Fin2 reff108_inst.
Proof. unfold Equation4612, magma_op, reff108_inst, reff108_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff108_sat4620 : @Equation4620 Fin2 reff108_inst.
Proof. unfold Equation4620, magma_op, reff108_inst, reff108_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff108_sat4640 : @Equation4640 Fin2 reff108_inst.
Proof. unfold Equation4640, magma_op, reff108_inst, reff108_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff108_not47 : ~ @Equation47 Fin2 reff108_inst.
Proof. unfold Equation47. intro H. specialize (H F2_1). unfold magma_op, reff108_inst, reff108_op in H. discriminate H. Qed.

Lemma reff108_not99 : ~ @Equation99 Fin2 reff108_inst.
Proof. unfold Equation99. intro H. specialize (H F2_1). unfold magma_op, reff108_inst, reff108_op in H. discriminate H. Qed.

Lemma reff108_not151 : ~ @Equation151 Fin2 reff108_inst.
Proof. unfold Equation151. intro H. specialize (H F2_1). unfold magma_op, reff108_inst, reff108_op in H. discriminate H. Qed.

Lemma reff108_not203 : ~ @Equation203 Fin2 reff108_inst.
Proof. unfold Equation203. intro H. specialize (H F2_1). unfold magma_op, reff108_inst, reff108_op in H. discriminate H. Qed.

Lemma reff108_not255 : ~ @Equation255 Fin2 reff108_inst.
Proof. unfold Equation255. intro H. specialize (H F2_1). unfold magma_op, reff108_inst, reff108_op in H. discriminate H. Qed.

Lemma reff108_not307 : ~ @Equation307 Fin2 reff108_inst.
Proof. unfold Equation307. intro H. specialize (H F2_1). unfold magma_op, reff108_inst, reff108_op in H. discriminate H. Qed.

Lemma reff108_not359 : ~ @Equation359 Fin2 reff108_inst.
Proof. unfold Equation359. intro H. specialize (H F2_1). unfold magma_op, reff108_inst, reff108_op in H. discriminate H. Qed.

Lemma reff108_not412 : ~ @Equation412 Fin2 reff108_inst.
Proof. unfold Equation412. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff108_inst, reff108_op in H. discriminate H. Qed.

Lemma reff108_not413 : ~ @Equation413 Fin2 reff108_inst.
Proof. unfold Equation413. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff108_inst, reff108_op in H. discriminate H. Qed.

Lemma reff108_not416 : ~ @Equation416 Fin2 reff108_inst.
Proof. unfold Equation416. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff108_inst, reff108_op in H. discriminate H. Qed.

Lemma reff108_not420 : ~ @Equation420 Fin2 reff108_inst.
Proof. unfold Equation420. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff108_inst, reff108_op in H. discriminate H. Qed.

Lemma reff108_not426 : ~ @Equation426 Fin2 reff108_inst.
Proof. unfold Equation426. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff108_inst, reff108_op in H. discriminate H. Qed.

Lemma reff108_not430 : ~ @Equation430 Fin2 reff108_inst.
Proof. unfold Equation430. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff108_inst, reff108_op in H. discriminate H. Qed.

Lemma reff108_not437 : ~ @Equation437 Fin2 reff108_inst.
Proof. unfold Equation437. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff108_inst, reff108_op in H. discriminate H. Qed.

Lemma reff108_not439 : ~ @Equation439 Fin2 reff108_inst.
Proof. unfold Equation439. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff108_inst, reff108_op in H. discriminate H. Qed.

Lemma reff108_not463 : ~ @Equation463 Fin2 reff108_inst.
Proof. unfold Equation463. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff108_inst, reff108_op in H. discriminate H. Qed.

Lemma reff108_not467 : ~ @Equation467 Fin2 reff108_inst.
Proof. unfold Equation467. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff108_inst, reff108_op in H. discriminate H. Qed.

Lemma reff108_not474 : ~ @Equation474 Fin2 reff108_inst.
Proof. unfold Equation474. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff108_inst, reff108_op in H. discriminate H. Qed.

Lemma reff108_not476 : ~ @Equation476 Fin2 reff108_inst.
Proof. unfold Equation476. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff108_inst, reff108_op in H. discriminate H. Qed.

Lemma reff108_not501 : ~ @Equation501 Fin2 reff108_inst.
Proof. unfold Equation501. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff108_inst, reff108_op in H. discriminate H. Qed.

Lemma reff108_not503 : ~ @Equation503 Fin2 reff108_inst.
Proof. unfold Equation503. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff108_inst, reff108_op in H. discriminate H. Qed.

Lemma reff108_not510 : ~ @Equation510 Fin2 reff108_inst.
Proof. unfold Equation510. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff108_inst, reff108_op in H. discriminate H. Qed.

Lemma reff108_not615 : ~ @Equation615 Fin2 reff108_inst.
Proof. unfold Equation615. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff108_inst, reff108_op in H. discriminate H. Qed.

Lemma reff108_not616 : ~ @Equation616 Fin2 reff108_inst.
Proof. unfold Equation616. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff108_inst, reff108_op in H. discriminate H. Qed.

Lemma reff108_not619 : ~ @Equation619 Fin2 reff108_inst.
Proof. unfold Equation619. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff108_inst, reff108_op in H. discriminate H. Qed.

Lemma reff108_not623 : ~ @Equation623 Fin2 reff108_inst.
Proof. unfold Equation623. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff108_inst, reff108_op in H. discriminate H. Qed.

Lemma reff108_not629 : ~ @Equation629 Fin2 reff108_inst.
Proof. unfold Equation629. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff108_inst, reff108_op in H. discriminate H. Qed.

Lemma reff108_not633 : ~ @Equation633 Fin2 reff108_inst.
Proof. unfold Equation633. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff108_inst, reff108_op in H. discriminate H. Qed.

Lemma reff108_not640 : ~ @Equation640 Fin2 reff108_inst.
Proof. unfold Equation640. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff108_inst, reff108_op in H. discriminate H. Qed.

Lemma reff108_not642 : ~ @Equation642 Fin2 reff108_inst.
Proof. unfold Equation642. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff108_inst, reff108_op in H. discriminate H. Qed.

Lemma reff108_not666 : ~ @Equation666 Fin2 reff108_inst.
Proof. unfold Equation666. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff108_inst, reff108_op in H. discriminate H. Qed.

Lemma reff108_not670 : ~ @Equation670 Fin2 reff108_inst.
Proof. unfold Equation670. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff108_inst, reff108_op in H. discriminate H. Qed.

Lemma reff108_not677 : ~ @Equation677 Fin2 reff108_inst.
Proof. unfold Equation677. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff108_inst, reff108_op in H. discriminate H. Qed.

Lemma reff108_not679 : ~ @Equation679 Fin2 reff108_inst.
Proof. unfold Equation679. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff108_inst, reff108_op in H. discriminate H. Qed.

Lemma reff108_not704 : ~ @Equation704 Fin2 reff108_inst.
Proof. unfold Equation704. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff108_inst, reff108_op in H. discriminate H. Qed.

Lemma reff108_not706 : ~ @Equation706 Fin2 reff108_inst.
Proof. unfold Equation706. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff108_inst, reff108_op in H. discriminate H. Qed.

Lemma reff108_not713 : ~ @Equation713 Fin2 reff108_inst.
Proof. unfold Equation713. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff108_inst, reff108_op in H. discriminate H. Qed.

Lemma reff108_not818 : ~ @Equation818 Fin2 reff108_inst.
Proof. unfold Equation818. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff108_inst, reff108_op in H. discriminate H. Qed.

Lemma reff108_not819 : ~ @Equation819 Fin2 reff108_inst.
Proof. unfold Equation819. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff108_inst, reff108_op in H. discriminate H. Qed.

Lemma reff108_not822 : ~ @Equation822 Fin2 reff108_inst.
Proof. unfold Equation822. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff108_inst, reff108_op in H. discriminate H. Qed.

Lemma reff108_not826 : ~ @Equation826 Fin2 reff108_inst.
Proof. unfold Equation826. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff108_inst, reff108_op in H. discriminate H. Qed.

Lemma reff108_not832 : ~ @Equation832 Fin2 reff108_inst.
Proof. unfold Equation832. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff108_inst, reff108_op in H. discriminate H. Qed.

Lemma reff108_not836 : ~ @Equation836 Fin2 reff108_inst.
Proof. unfold Equation836. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff108_inst, reff108_op in H. discriminate H. Qed.

Lemma reff108_not843 : ~ @Equation843 Fin2 reff108_inst.
Proof. unfold Equation843. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff108_inst, reff108_op in H. discriminate H. Qed.

Lemma reff108_not845 : ~ @Equation845 Fin2 reff108_inst.
Proof. unfold Equation845. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff108_inst, reff108_op in H. discriminate H. Qed.

Lemma reff108_not869 : ~ @Equation869 Fin2 reff108_inst.
Proof. unfold Equation869. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff108_inst, reff108_op in H. discriminate H. Qed.

Lemma reff108_not873 : ~ @Equation873 Fin2 reff108_inst.
Proof. unfold Equation873. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff108_inst, reff108_op in H. discriminate H. Qed.

Lemma reff108_not880 : ~ @Equation880 Fin2 reff108_inst.
Proof. unfold Equation880. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff108_inst, reff108_op in H. discriminate H. Qed.

Lemma reff108_not882 : ~ @Equation882 Fin2 reff108_inst.
Proof. unfold Equation882. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff108_inst, reff108_op in H. discriminate H. Qed.

Lemma reff108_not907 : ~ @Equation907 Fin2 reff108_inst.
Proof. unfold Equation907. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff108_inst, reff108_op in H. discriminate H. Qed.

Lemma reff108_not909 : ~ @Equation909 Fin2 reff108_inst.
Proof. unfold Equation909. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff108_inst, reff108_op in H. discriminate H. Qed.

Lemma reff108_not916 : ~ @Equation916 Fin2 reff108_inst.
Proof. unfold Equation916. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff108_inst, reff108_op in H. discriminate H. Qed.

Lemma reff108_not1021 : ~ @Equation1021 Fin2 reff108_inst.
Proof. unfold Equation1021. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff108_inst, reff108_op in H. discriminate H. Qed.

Lemma reff108_not1022 : ~ @Equation1022 Fin2 reff108_inst.
Proof. unfold Equation1022. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff108_inst, reff108_op in H. discriminate H. Qed.

Lemma reff108_not1025 : ~ @Equation1025 Fin2 reff108_inst.
Proof. unfold Equation1025. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff108_inst, reff108_op in H. discriminate H. Qed.

Lemma reff108_not1029 : ~ @Equation1029 Fin2 reff108_inst.
Proof. unfold Equation1029. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff108_inst, reff108_op in H. discriminate H. Qed.

Lemma reff108_not1035 : ~ @Equation1035 Fin2 reff108_inst.
Proof. unfold Equation1035. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff108_inst, reff108_op in H. discriminate H. Qed.

Lemma reff108_not1039 : ~ @Equation1039 Fin2 reff108_inst.
Proof. unfold Equation1039. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff108_inst, reff108_op in H. discriminate H. Qed.

Lemma reff108_not1046 : ~ @Equation1046 Fin2 reff108_inst.
Proof. unfold Equation1046. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff108_inst, reff108_op in H. discriminate H. Qed.

Lemma reff108_not1048 : ~ @Equation1048 Fin2 reff108_inst.
Proof. unfold Equation1048. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff108_inst, reff108_op in H. discriminate H. Qed.

Lemma reff108_not1072 : ~ @Equation1072 Fin2 reff108_inst.
Proof. unfold Equation1072. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff108_inst, reff108_op in H. discriminate H. Qed.

Lemma reff108_not1076 : ~ @Equation1076 Fin2 reff108_inst.
Proof. unfold Equation1076. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff108_inst, reff108_op in H. discriminate H. Qed.

Lemma reff108_not1083 : ~ @Equation1083 Fin2 reff108_inst.
Proof. unfold Equation1083. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff108_inst, reff108_op in H. discriminate H. Qed.

Lemma reff108_not1085 : ~ @Equation1085 Fin2 reff108_inst.
Proof. unfold Equation1085. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff108_inst, reff108_op in H. discriminate H. Qed.

Lemma reff108_not1110 : ~ @Equation1110 Fin2 reff108_inst.
Proof. unfold Equation1110. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff108_inst, reff108_op in H. discriminate H. Qed.

Lemma reff108_not1112 : ~ @Equation1112 Fin2 reff108_inst.
Proof. unfold Equation1112. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff108_inst, reff108_op in H. discriminate H. Qed.

Lemma reff108_not1119 : ~ @Equation1119 Fin2 reff108_inst.
Proof. unfold Equation1119. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff108_inst, reff108_op in H. discriminate H. Qed.

Lemma reff108_not1224 : ~ @Equation1224 Fin2 reff108_inst.
Proof. unfold Equation1224. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff108_inst, reff108_op in H. discriminate H. Qed.

Lemma reff108_not1225 : ~ @Equation1225 Fin2 reff108_inst.
Proof. unfold Equation1225. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff108_inst, reff108_op in H. discriminate H. Qed.

Lemma reff108_not1228 : ~ @Equation1228 Fin2 reff108_inst.
Proof. unfold Equation1228. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff108_inst, reff108_op in H. discriminate H. Qed.

Lemma reff108_not1232 : ~ @Equation1232 Fin2 reff108_inst.
Proof. unfold Equation1232. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff108_inst, reff108_op in H. discriminate H. Qed.

Lemma reff108_not1238 : ~ @Equation1238 Fin2 reff108_inst.
Proof. unfold Equation1238. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff108_inst, reff108_op in H. discriminate H. Qed.

Lemma reff108_not1242 : ~ @Equation1242 Fin2 reff108_inst.
Proof. unfold Equation1242. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff108_inst, reff108_op in H. discriminate H. Qed.

Lemma reff108_not1249 : ~ @Equation1249 Fin2 reff108_inst.
Proof. unfold Equation1249. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff108_inst, reff108_op in H. discriminate H. Qed.

Lemma reff108_not1251 : ~ @Equation1251 Fin2 reff108_inst.
Proof. unfold Equation1251. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff108_inst, reff108_op in H. discriminate H. Qed.

Lemma reff108_not1275 : ~ @Equation1275 Fin2 reff108_inst.
Proof. unfold Equation1275. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff108_inst, reff108_op in H. discriminate H. Qed.

Lemma reff108_not1279 : ~ @Equation1279 Fin2 reff108_inst.
Proof. unfold Equation1279. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff108_inst, reff108_op in H. discriminate H. Qed.

Lemma reff108_not1286 : ~ @Equation1286 Fin2 reff108_inst.
Proof. unfold Equation1286. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff108_inst, reff108_op in H. discriminate H. Qed.

Lemma reff108_not1288 : ~ @Equation1288 Fin2 reff108_inst.
Proof. unfold Equation1288. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff108_inst, reff108_op in H. discriminate H. Qed.

Lemma reff108_not1313 : ~ @Equation1313 Fin2 reff108_inst.
Proof. unfold Equation1313. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff108_inst, reff108_op in H. discriminate H. Qed.

Lemma reff108_not1315 : ~ @Equation1315 Fin2 reff108_inst.
Proof. unfold Equation1315. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff108_inst, reff108_op in H. discriminate H. Qed.

Lemma reff108_not1322 : ~ @Equation1322 Fin2 reff108_inst.
Proof. unfold Equation1322. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff108_inst, reff108_op in H. discriminate H. Qed.

Lemma reff108_not1427 : ~ @Equation1427 Fin2 reff108_inst.
Proof. unfold Equation1427. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff108_inst, reff108_op in H. discriminate H. Qed.

Lemma reff108_not1428 : ~ @Equation1428 Fin2 reff108_inst.
Proof. unfold Equation1428. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff108_inst, reff108_op in H. discriminate H. Qed.

Lemma reff108_not1431 : ~ @Equation1431 Fin2 reff108_inst.
Proof. unfold Equation1431. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff108_inst, reff108_op in H. discriminate H. Qed.

Lemma reff108_not1435 : ~ @Equation1435 Fin2 reff108_inst.
Proof. unfold Equation1435. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff108_inst, reff108_op in H. discriminate H. Qed.

Lemma reff108_not1441 : ~ @Equation1441 Fin2 reff108_inst.
Proof. unfold Equation1441. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff108_inst, reff108_op in H. discriminate H. Qed.

Lemma reff108_not1445 : ~ @Equation1445 Fin2 reff108_inst.
Proof. unfold Equation1445. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff108_inst, reff108_op in H. discriminate H. Qed.

Lemma reff108_not1452 : ~ @Equation1452 Fin2 reff108_inst.
Proof. unfold Equation1452. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff108_inst, reff108_op in H. discriminate H. Qed.

Lemma reff108_not1454 : ~ @Equation1454 Fin2 reff108_inst.
Proof. unfold Equation1454. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff108_inst, reff108_op in H. discriminate H. Qed.

Lemma reff108_not1478 : ~ @Equation1478 Fin2 reff108_inst.
Proof. unfold Equation1478. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff108_inst, reff108_op in H. discriminate H. Qed.

Lemma reff108_not1482 : ~ @Equation1482 Fin2 reff108_inst.
Proof. unfold Equation1482. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff108_inst, reff108_op in H. discriminate H. Qed.

Lemma reff108_not1489 : ~ @Equation1489 Fin2 reff108_inst.
Proof. unfold Equation1489. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff108_inst, reff108_op in H. discriminate H. Qed.

Lemma reff108_not1491 : ~ @Equation1491 Fin2 reff108_inst.
Proof. unfold Equation1491. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff108_inst, reff108_op in H. discriminate H. Qed.

Lemma reff108_not1516 : ~ @Equation1516 Fin2 reff108_inst.
Proof. unfold Equation1516. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff108_inst, reff108_op in H. discriminate H. Qed.

Lemma reff108_not1518 : ~ @Equation1518 Fin2 reff108_inst.
Proof. unfold Equation1518. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff108_inst, reff108_op in H. discriminate H. Qed.

Lemma reff108_not1525 : ~ @Equation1525 Fin2 reff108_inst.
Proof. unfold Equation1525. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff108_inst, reff108_op in H. discriminate H. Qed.

Lemma reff108_not1630 : ~ @Equation1630 Fin2 reff108_inst.
Proof. unfold Equation1630. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff108_inst, reff108_op in H. discriminate H. Qed.

Lemma reff108_not1631 : ~ @Equation1631 Fin2 reff108_inst.
Proof. unfold Equation1631. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff108_inst, reff108_op in H. discriminate H. Qed.

Lemma reff108_not1634 : ~ @Equation1634 Fin2 reff108_inst.
Proof. unfold Equation1634. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff108_inst, reff108_op in H. discriminate H. Qed.

Lemma reff108_not1638 : ~ @Equation1638 Fin2 reff108_inst.
Proof. unfold Equation1638. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff108_inst, reff108_op in H. discriminate H. Qed.

Lemma reff108_not1644 : ~ @Equation1644 Fin2 reff108_inst.
Proof. unfold Equation1644. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff108_inst, reff108_op in H. discriminate H. Qed.

Lemma reff108_not1648 : ~ @Equation1648 Fin2 reff108_inst.
Proof. unfold Equation1648. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff108_inst, reff108_op in H. discriminate H. Qed.

Lemma reff108_not1655 : ~ @Equation1655 Fin2 reff108_inst.
Proof. unfold Equation1655. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff108_inst, reff108_op in H. discriminate H. Qed.

Lemma reff108_not1657 : ~ @Equation1657 Fin2 reff108_inst.
Proof. unfold Equation1657. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff108_inst, reff108_op in H. discriminate H. Qed.

Lemma reff108_not1681 : ~ @Equation1681 Fin2 reff108_inst.
Proof. unfold Equation1681. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff108_inst, reff108_op in H. discriminate H. Qed.

Lemma reff108_not1685 : ~ @Equation1685 Fin2 reff108_inst.
Proof. unfold Equation1685. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff108_inst, reff108_op in H. discriminate H. Qed.

Lemma reff108_not1692 : ~ @Equation1692 Fin2 reff108_inst.
Proof. unfold Equation1692. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff108_inst, reff108_op in H. discriminate H. Qed.

Lemma reff108_not1694 : ~ @Equation1694 Fin2 reff108_inst.
Proof. unfold Equation1694. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff108_inst, reff108_op in H. discriminate H. Qed.

Lemma reff108_not1719 : ~ @Equation1719 Fin2 reff108_inst.
Proof. unfold Equation1719. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff108_inst, reff108_op in H. discriminate H. Qed.

Lemma reff108_not1721 : ~ @Equation1721 Fin2 reff108_inst.
Proof. unfold Equation1721. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff108_inst, reff108_op in H. discriminate H. Qed.

Lemma reff108_not1728 : ~ @Equation1728 Fin2 reff108_inst.
Proof. unfold Equation1728. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff108_inst, reff108_op in H. discriminate H. Qed.

Lemma reff108_not1833 : ~ @Equation1833 Fin2 reff108_inst.
Proof. unfold Equation1833. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff108_inst, reff108_op in H. discriminate H. Qed.

Lemma reff108_not1834 : ~ @Equation1834 Fin2 reff108_inst.
Proof. unfold Equation1834. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff108_inst, reff108_op in H. discriminate H. Qed.

Lemma reff108_not1837 : ~ @Equation1837 Fin2 reff108_inst.
Proof. unfold Equation1837. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff108_inst, reff108_op in H. discriminate H. Qed.

Lemma reff108_not1841 : ~ @Equation1841 Fin2 reff108_inst.
Proof. unfold Equation1841. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff108_inst, reff108_op in H. discriminate H. Qed.

Lemma reff108_not1847 : ~ @Equation1847 Fin2 reff108_inst.
Proof. unfold Equation1847. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff108_inst, reff108_op in H. discriminate H. Qed.

Lemma reff108_not1851 : ~ @Equation1851 Fin2 reff108_inst.
Proof. unfold Equation1851. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff108_inst, reff108_op in H. discriminate H. Qed.

Lemma reff108_not1858 : ~ @Equation1858 Fin2 reff108_inst.
Proof. unfold Equation1858. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff108_inst, reff108_op in H. discriminate H. Qed.

Lemma reff108_not1860 : ~ @Equation1860 Fin2 reff108_inst.
Proof. unfold Equation1860. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff108_inst, reff108_op in H. discriminate H. Qed.

Lemma reff108_not1884 : ~ @Equation1884 Fin2 reff108_inst.
Proof. unfold Equation1884. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff108_inst, reff108_op in H. discriminate H. Qed.

Lemma reff108_not1888 : ~ @Equation1888 Fin2 reff108_inst.
Proof. unfold Equation1888. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff108_inst, reff108_op in H. discriminate H. Qed.

Lemma reff108_not1895 : ~ @Equation1895 Fin2 reff108_inst.
Proof. unfold Equation1895. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff108_inst, reff108_op in H. discriminate H. Qed.

Lemma reff108_not1897 : ~ @Equation1897 Fin2 reff108_inst.
Proof. unfold Equation1897. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff108_inst, reff108_op in H. discriminate H. Qed.

Lemma reff108_not1922 : ~ @Equation1922 Fin2 reff108_inst.
Proof. unfold Equation1922. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff108_inst, reff108_op in H. discriminate H. Qed.

Lemma reff108_not1924 : ~ @Equation1924 Fin2 reff108_inst.
Proof. unfold Equation1924. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff108_inst, reff108_op in H. discriminate H. Qed.

Lemma reff108_not1931 : ~ @Equation1931 Fin2 reff108_inst.
Proof. unfold Equation1931. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff108_inst, reff108_op in H. discriminate H. Qed.

Lemma reff108_not2036 : ~ @Equation2036 Fin2 reff108_inst.
Proof. unfold Equation2036. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff108_inst, reff108_op in H. discriminate H. Qed.

Lemma reff108_not2037 : ~ @Equation2037 Fin2 reff108_inst.
Proof. unfold Equation2037. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff108_inst, reff108_op in H. discriminate H. Qed.

Lemma reff108_not2040 : ~ @Equation2040 Fin2 reff108_inst.
Proof. unfold Equation2040. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff108_inst, reff108_op in H. discriminate H. Qed.

Lemma reff108_not2044 : ~ @Equation2044 Fin2 reff108_inst.
Proof. unfold Equation2044. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff108_inst, reff108_op in H. discriminate H. Qed.

Lemma reff108_not2050 : ~ @Equation2050 Fin2 reff108_inst.
Proof. unfold Equation2050. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff108_inst, reff108_op in H. discriminate H. Qed.

Lemma reff108_not2054 : ~ @Equation2054 Fin2 reff108_inst.
Proof. unfold Equation2054. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff108_inst, reff108_op in H. discriminate H. Qed.

Lemma reff108_not2061 : ~ @Equation2061 Fin2 reff108_inst.
Proof. unfold Equation2061. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff108_inst, reff108_op in H. discriminate H. Qed.

Lemma reff108_not2063 : ~ @Equation2063 Fin2 reff108_inst.
Proof. unfold Equation2063. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff108_inst, reff108_op in H. discriminate H. Qed.

Lemma reff108_not2087 : ~ @Equation2087 Fin2 reff108_inst.
Proof. unfold Equation2087. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff108_inst, reff108_op in H. discriminate H. Qed.

Lemma reff108_not2091 : ~ @Equation2091 Fin2 reff108_inst.
Proof. unfold Equation2091. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff108_inst, reff108_op in H. discriminate H. Qed.

Lemma reff108_not2098 : ~ @Equation2098 Fin2 reff108_inst.
Proof. unfold Equation2098. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff108_inst, reff108_op in H. discriminate H. Qed.

Lemma reff108_not2100 : ~ @Equation2100 Fin2 reff108_inst.
Proof. unfold Equation2100. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff108_inst, reff108_op in H. discriminate H. Qed.

Lemma reff108_not2125 : ~ @Equation2125 Fin2 reff108_inst.
Proof. unfold Equation2125. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff108_inst, reff108_op in H. discriminate H. Qed.

Lemma reff108_not2127 : ~ @Equation2127 Fin2 reff108_inst.
Proof. unfold Equation2127. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff108_inst, reff108_op in H. discriminate H. Qed.

Lemma reff108_not2134 : ~ @Equation2134 Fin2 reff108_inst.
Proof. unfold Equation2134. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff108_inst, reff108_op in H. discriminate H. Qed.

Lemma reff108_not2239 : ~ @Equation2239 Fin2 reff108_inst.
Proof. unfold Equation2239. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff108_inst, reff108_op in H. discriminate H. Qed.

Lemma reff108_not2240 : ~ @Equation2240 Fin2 reff108_inst.
Proof. unfold Equation2240. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff108_inst, reff108_op in H. discriminate H. Qed.

Lemma reff108_not2243 : ~ @Equation2243 Fin2 reff108_inst.
Proof. unfold Equation2243. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff108_inst, reff108_op in H. discriminate H. Qed.

Lemma reff108_not2247 : ~ @Equation2247 Fin2 reff108_inst.
Proof. unfold Equation2247. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff108_inst, reff108_op in H. discriminate H. Qed.

Lemma reff108_not2253 : ~ @Equation2253 Fin2 reff108_inst.
Proof. unfold Equation2253. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff108_inst, reff108_op in H. discriminate H. Qed.

Lemma reff108_not2257 : ~ @Equation2257 Fin2 reff108_inst.
Proof. unfold Equation2257. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff108_inst, reff108_op in H. discriminate H. Qed.

Lemma reff108_not2264 : ~ @Equation2264 Fin2 reff108_inst.
Proof. unfold Equation2264. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff108_inst, reff108_op in H. discriminate H. Qed.

Lemma reff108_not2266 : ~ @Equation2266 Fin2 reff108_inst.
Proof. unfold Equation2266. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff108_inst, reff108_op in H. discriminate H. Qed.

Lemma reff108_not2290 : ~ @Equation2290 Fin2 reff108_inst.
Proof. unfold Equation2290. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff108_inst, reff108_op in H. discriminate H. Qed.

Lemma reff108_not2294 : ~ @Equation2294 Fin2 reff108_inst.
Proof. unfold Equation2294. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff108_inst, reff108_op in H. discriminate H. Qed.

Lemma reff108_not2301 : ~ @Equation2301 Fin2 reff108_inst.
Proof. unfold Equation2301. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff108_inst, reff108_op in H. discriminate H. Qed.

Lemma reff108_not2303 : ~ @Equation2303 Fin2 reff108_inst.
Proof. unfold Equation2303. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff108_inst, reff108_op in H. discriminate H. Qed.

Lemma reff108_not2328 : ~ @Equation2328 Fin2 reff108_inst.
Proof. unfold Equation2328. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff108_inst, reff108_op in H. discriminate H. Qed.

Lemma reff108_not2330 : ~ @Equation2330 Fin2 reff108_inst.
Proof. unfold Equation2330. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff108_inst, reff108_op in H. discriminate H. Qed.

Lemma reff108_not2337 : ~ @Equation2337 Fin2 reff108_inst.
Proof. unfold Equation2337. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff108_inst, reff108_op in H. discriminate H. Qed.

Lemma reff108_not2442 : ~ @Equation2442 Fin2 reff108_inst.
Proof. unfold Equation2442. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff108_inst, reff108_op in H. discriminate H. Qed.

Lemma reff108_not2443 : ~ @Equation2443 Fin2 reff108_inst.
Proof. unfold Equation2443. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff108_inst, reff108_op in H. discriminate H. Qed.

Lemma reff108_not2446 : ~ @Equation2446 Fin2 reff108_inst.
Proof. unfold Equation2446. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff108_inst, reff108_op in H. discriminate H. Qed.

Lemma reff108_not2450 : ~ @Equation2450 Fin2 reff108_inst.
Proof. unfold Equation2450. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff108_inst, reff108_op in H. discriminate H. Qed.

Lemma reff108_not2456 : ~ @Equation2456 Fin2 reff108_inst.
Proof. unfold Equation2456. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff108_inst, reff108_op in H. discriminate H. Qed.

Lemma reff108_not2460 : ~ @Equation2460 Fin2 reff108_inst.
Proof. unfold Equation2460. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff108_inst, reff108_op in H. discriminate H. Qed.

Lemma reff108_not2467 : ~ @Equation2467 Fin2 reff108_inst.
Proof. unfold Equation2467. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff108_inst, reff108_op in H. discriminate H. Qed.

Lemma reff108_not2469 : ~ @Equation2469 Fin2 reff108_inst.
Proof. unfold Equation2469. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff108_inst, reff108_op in H. discriminate H. Qed.

Lemma reff108_not2493 : ~ @Equation2493 Fin2 reff108_inst.
Proof. unfold Equation2493. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff108_inst, reff108_op in H. discriminate H. Qed.

Lemma reff108_not2497 : ~ @Equation2497 Fin2 reff108_inst.
Proof. unfold Equation2497. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff108_inst, reff108_op in H. discriminate H. Qed.

Lemma reff108_not2504 : ~ @Equation2504 Fin2 reff108_inst.
Proof. unfold Equation2504. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff108_inst, reff108_op in H. discriminate H. Qed.

Lemma reff108_not2506 : ~ @Equation2506 Fin2 reff108_inst.
Proof. unfold Equation2506. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff108_inst, reff108_op in H. discriminate H. Qed.

Lemma reff108_not2531 : ~ @Equation2531 Fin2 reff108_inst.
Proof. unfold Equation2531. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff108_inst, reff108_op in H. discriminate H. Qed.

Lemma reff108_not2533 : ~ @Equation2533 Fin2 reff108_inst.
Proof. unfold Equation2533. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff108_inst, reff108_op in H. discriminate H. Qed.

Lemma reff108_not2540 : ~ @Equation2540 Fin2 reff108_inst.
Proof. unfold Equation2540. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff108_inst, reff108_op in H. discriminate H. Qed.

Lemma reff108_not2645 : ~ @Equation2645 Fin2 reff108_inst.
Proof. unfold Equation2645. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff108_inst, reff108_op in H. discriminate H. Qed.

Lemma reff108_not2646 : ~ @Equation2646 Fin2 reff108_inst.
Proof. unfold Equation2646. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff108_inst, reff108_op in H. discriminate H. Qed.

Lemma reff108_not2649 : ~ @Equation2649 Fin2 reff108_inst.
Proof. unfold Equation2649. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff108_inst, reff108_op in H. discriminate H. Qed.

Lemma reff108_not2653 : ~ @Equation2653 Fin2 reff108_inst.
Proof. unfold Equation2653. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff108_inst, reff108_op in H. discriminate H. Qed.

Lemma reff108_not2659 : ~ @Equation2659 Fin2 reff108_inst.
Proof. unfold Equation2659. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff108_inst, reff108_op in H. discriminate H. Qed.

Lemma reff108_not2663 : ~ @Equation2663 Fin2 reff108_inst.
Proof. unfold Equation2663. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff108_inst, reff108_op in H. discriminate H. Qed.

Lemma reff108_not2670 : ~ @Equation2670 Fin2 reff108_inst.
Proof. unfold Equation2670. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff108_inst, reff108_op in H. discriminate H. Qed.

Lemma reff108_not2672 : ~ @Equation2672 Fin2 reff108_inst.
Proof. unfold Equation2672. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff108_inst, reff108_op in H. discriminate H. Qed.

Lemma reff108_not2696 : ~ @Equation2696 Fin2 reff108_inst.
Proof. unfold Equation2696. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff108_inst, reff108_op in H. discriminate H. Qed.

Lemma reff108_not2700 : ~ @Equation2700 Fin2 reff108_inst.
Proof. unfold Equation2700. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff108_inst, reff108_op in H. discriminate H. Qed.

Lemma reff108_not2707 : ~ @Equation2707 Fin2 reff108_inst.
Proof. unfold Equation2707. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff108_inst, reff108_op in H. discriminate H. Qed.

Lemma reff108_not2709 : ~ @Equation2709 Fin2 reff108_inst.
Proof. unfold Equation2709. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff108_inst, reff108_op in H. discriminate H. Qed.

Lemma reff108_not2734 : ~ @Equation2734 Fin2 reff108_inst.
Proof. unfold Equation2734. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff108_inst, reff108_op in H. discriminate H. Qed.

Lemma reff108_not2736 : ~ @Equation2736 Fin2 reff108_inst.
Proof. unfold Equation2736. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff108_inst, reff108_op in H. discriminate H. Qed.

Lemma reff108_not2743 : ~ @Equation2743 Fin2 reff108_inst.
Proof. unfold Equation2743. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff108_inst, reff108_op in H. discriminate H. Qed.

Lemma reff108_not2848 : ~ @Equation2848 Fin2 reff108_inst.
Proof. unfold Equation2848. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff108_inst, reff108_op in H. discriminate H. Qed.

Lemma reff108_not2849 : ~ @Equation2849 Fin2 reff108_inst.
Proof. unfold Equation2849. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff108_inst, reff108_op in H. discriminate H. Qed.

Lemma reff108_not2852 : ~ @Equation2852 Fin2 reff108_inst.
Proof. unfold Equation2852. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff108_inst, reff108_op in H. discriminate H. Qed.

Lemma reff108_not2856 : ~ @Equation2856 Fin2 reff108_inst.
Proof. unfold Equation2856. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff108_inst, reff108_op in H. discriminate H. Qed.

Lemma reff108_not2862 : ~ @Equation2862 Fin2 reff108_inst.
Proof. unfold Equation2862. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff108_inst, reff108_op in H. discriminate H. Qed.

Lemma reff108_not2866 : ~ @Equation2866 Fin2 reff108_inst.
Proof. unfold Equation2866. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff108_inst, reff108_op in H. discriminate H. Qed.

Lemma reff108_not2873 : ~ @Equation2873 Fin2 reff108_inst.
Proof. unfold Equation2873. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff108_inst, reff108_op in H. discriminate H. Qed.

Lemma reff108_not2875 : ~ @Equation2875 Fin2 reff108_inst.
Proof. unfold Equation2875. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff108_inst, reff108_op in H. discriminate H. Qed.

Lemma reff108_not2899 : ~ @Equation2899 Fin2 reff108_inst.
Proof. unfold Equation2899. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff108_inst, reff108_op in H. discriminate H. Qed.

Lemma reff108_not2903 : ~ @Equation2903 Fin2 reff108_inst.
Proof. unfold Equation2903. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff108_inst, reff108_op in H. discriminate H. Qed.

Lemma reff108_not2910 : ~ @Equation2910 Fin2 reff108_inst.
Proof. unfold Equation2910. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff108_inst, reff108_op in H. discriminate H. Qed.

Lemma reff108_not2912 : ~ @Equation2912 Fin2 reff108_inst.
Proof. unfold Equation2912. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff108_inst, reff108_op in H. discriminate H. Qed.

Lemma reff108_not2937 : ~ @Equation2937 Fin2 reff108_inst.
Proof. unfold Equation2937. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff108_inst, reff108_op in H. discriminate H. Qed.

Lemma reff108_not2939 : ~ @Equation2939 Fin2 reff108_inst.
Proof. unfold Equation2939. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff108_inst, reff108_op in H. discriminate H. Qed.

Lemma reff108_not2946 : ~ @Equation2946 Fin2 reff108_inst.
Proof. unfold Equation2946. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff108_inst, reff108_op in H. discriminate H. Qed.

Lemma reff108_not3051 : ~ @Equation3051 Fin2 reff108_inst.
Proof. unfold Equation3051. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff108_inst, reff108_op in H. discriminate H. Qed.

Lemma reff108_not3052 : ~ @Equation3052 Fin2 reff108_inst.
Proof. unfold Equation3052. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff108_inst, reff108_op in H. discriminate H. Qed.

Lemma reff108_not3055 : ~ @Equation3055 Fin2 reff108_inst.
Proof. unfold Equation3055. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff108_inst, reff108_op in H. discriminate H. Qed.

Lemma reff108_not3059 : ~ @Equation3059 Fin2 reff108_inst.
Proof. unfold Equation3059. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff108_inst, reff108_op in H. discriminate H. Qed.

Lemma reff108_not3065 : ~ @Equation3065 Fin2 reff108_inst.
Proof. unfold Equation3065. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff108_inst, reff108_op in H. discriminate H. Qed.

Lemma reff108_not3069 : ~ @Equation3069 Fin2 reff108_inst.
Proof. unfold Equation3069. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff108_inst, reff108_op in H. discriminate H. Qed.

Lemma reff108_not3076 : ~ @Equation3076 Fin2 reff108_inst.
Proof. unfold Equation3076. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff108_inst, reff108_op in H. discriminate H. Qed.

Lemma reff108_not3078 : ~ @Equation3078 Fin2 reff108_inst.
Proof. unfold Equation3078. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff108_inst, reff108_op in H. discriminate H. Qed.

Lemma reff108_not3102 : ~ @Equation3102 Fin2 reff108_inst.
Proof. unfold Equation3102. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff108_inst, reff108_op in H. discriminate H. Qed.

Lemma reff108_not3106 : ~ @Equation3106 Fin2 reff108_inst.
Proof. unfold Equation3106. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff108_inst, reff108_op in H. discriminate H. Qed.

Lemma reff108_not3113 : ~ @Equation3113 Fin2 reff108_inst.
Proof. unfold Equation3113. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff108_inst, reff108_op in H. discriminate H. Qed.

Lemma reff108_not3115 : ~ @Equation3115 Fin2 reff108_inst.
Proof. unfold Equation3115. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff108_inst, reff108_op in H. discriminate H. Qed.

Lemma reff108_not3140 : ~ @Equation3140 Fin2 reff108_inst.
Proof. unfold Equation3140. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff108_inst, reff108_op in H. discriminate H. Qed.

Lemma reff108_not3142 : ~ @Equation3142 Fin2 reff108_inst.
Proof. unfold Equation3142. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff108_inst, reff108_op in H. discriminate H. Qed.

Lemma reff108_not3149 : ~ @Equation3149 Fin2 reff108_inst.
Proof. unfold Equation3149. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff108_inst, reff108_op in H. discriminate H. Qed.

Lemma reff108_not3254 : ~ @Equation3254 Fin2 reff108_inst.
Proof. unfold Equation3254. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff108_inst, reff108_op in H. discriminate H. Qed.

Lemma reff108_not3255 : ~ @Equation3255 Fin2 reff108_inst.
Proof. unfold Equation3255. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff108_inst, reff108_op in H. discriminate H. Qed.

Lemma reff108_not3258 : ~ @Equation3258 Fin2 reff108_inst.
Proof. unfold Equation3258. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff108_inst, reff108_op in H. discriminate H. Qed.

Lemma reff108_not3262 : ~ @Equation3262 Fin2 reff108_inst.
Proof. unfold Equation3262. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff108_inst, reff108_op in H. discriminate H. Qed.

Lemma reff108_not3268 : ~ @Equation3268 Fin2 reff108_inst.
Proof. unfold Equation3268. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff108_inst, reff108_op in H. discriminate H. Qed.

Lemma reff108_not3272 : ~ @Equation3272 Fin2 reff108_inst.
Proof. unfold Equation3272. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff108_inst, reff108_op in H. discriminate H. Qed.

Lemma reff108_not3279 : ~ @Equation3279 Fin2 reff108_inst.
Proof. unfold Equation3279. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff108_inst, reff108_op in H. discriminate H. Qed.

Lemma reff108_not3281 : ~ @Equation3281 Fin2 reff108_inst.
Proof. unfold Equation3281. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff108_inst, reff108_op in H. discriminate H. Qed.

Lemma reff108_not3309 : ~ @Equation3309 Fin2 reff108_inst.
Proof. unfold Equation3309. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff108_inst, reff108_op in H. discriminate H. Qed.

Lemma reff108_not3316 : ~ @Equation3316 Fin2 reff108_inst.
Proof. unfold Equation3316. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff108_inst, reff108_op in H. discriminate H. Qed.

Lemma reff108_not3318 : ~ @Equation3318 Fin2 reff108_inst.
Proof. unfold Equation3318. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff108_inst, reff108_op in H. discriminate H. Qed.

Lemma reff108_not3343 : ~ @Equation3343 Fin2 reff108_inst.
Proof. unfold Equation3343. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff108_inst, reff108_op in H. discriminate H. Qed.

Lemma reff108_not3345 : ~ @Equation3345 Fin2 reff108_inst.
Proof. unfold Equation3345. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff108_inst, reff108_op in H. discriminate H. Qed.

Lemma reff108_not3352 : ~ @Equation3352 Fin2 reff108_inst.
Proof. unfold Equation3352. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff108_inst, reff108_op in H. discriminate H. Qed.

Lemma reff108_not3457 : ~ @Equation3457 Fin2 reff108_inst.
Proof. unfold Equation3457. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff108_inst, reff108_op in H. discriminate H. Qed.

Lemma reff108_not3458 : ~ @Equation3458 Fin2 reff108_inst.
Proof. unfold Equation3458. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff108_inst, reff108_op in H. discriminate H. Qed.

Lemma reff108_not3461 : ~ @Equation3461 Fin2 reff108_inst.
Proof. unfold Equation3461. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff108_inst, reff108_op in H. discriminate H. Qed.

Lemma reff108_not3465 : ~ @Equation3465 Fin2 reff108_inst.
Proof. unfold Equation3465. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff108_inst, reff108_op in H. discriminate H. Qed.

Lemma reff108_not3475 : ~ @Equation3475 Fin2 reff108_inst.
Proof. unfold Equation3475. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff108_inst, reff108_op in H. discriminate H. Qed.

Lemma reff108_not3482 : ~ @Equation3482 Fin2 reff108_inst.
Proof. unfold Equation3482. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff108_inst, reff108_op in H. discriminate H. Qed.

Lemma reff108_not3484 : ~ @Equation3484 Fin2 reff108_inst.
Proof. unfold Equation3484. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff108_inst, reff108_op in H. discriminate H. Qed.

Lemma reff108_not3512 : ~ @Equation3512 Fin2 reff108_inst.
Proof. unfold Equation3512. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff108_inst, reff108_op in H. discriminate H. Qed.

Lemma reff108_not3519 : ~ @Equation3519 Fin2 reff108_inst.
Proof. unfold Equation3519. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff108_inst, reff108_op in H. discriminate H. Qed.

Lemma reff108_not3521 : ~ @Equation3521 Fin2 reff108_inst.
Proof. unfold Equation3521. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff108_inst, reff108_op in H. discriminate H. Qed.

Lemma reff108_not3546 : ~ @Equation3546 Fin2 reff108_inst.
Proof. unfold Equation3546. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff108_inst, reff108_op in H. discriminate H. Qed.

Lemma reff108_not3548 : ~ @Equation3548 Fin2 reff108_inst.
Proof. unfold Equation3548. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff108_inst, reff108_op in H. discriminate H. Qed.

Lemma reff108_not3555 : ~ @Equation3555 Fin2 reff108_inst.
Proof. unfold Equation3555. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff108_inst, reff108_op in H. discriminate H. Qed.

Lemma reff108_not3660 : ~ @Equation3660 Fin2 reff108_inst.
Proof. unfold Equation3660. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff108_inst, reff108_op in H. discriminate H. Qed.

Lemma reff108_not3661 : ~ @Equation3661 Fin2 reff108_inst.
Proof. unfold Equation3661. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff108_inst, reff108_op in H. discriminate H. Qed.

Lemma reff108_not3664 : ~ @Equation3664 Fin2 reff108_inst.
Proof. unfold Equation3664. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff108_inst, reff108_op in H. discriminate H. Qed.

Lemma reff108_not3668 : ~ @Equation3668 Fin2 reff108_inst.
Proof. unfold Equation3668. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff108_inst, reff108_op in H. discriminate H. Qed.

Lemma reff108_not3674 : ~ @Equation3674 Fin2 reff108_inst.
Proof. unfold Equation3674. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff108_inst, reff108_op in H. discriminate H. Qed.

Lemma reff108_not3678 : ~ @Equation3678 Fin2 reff108_inst.
Proof. unfold Equation3678. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff108_inst, reff108_op in H. discriminate H. Qed.

Lemma reff108_not3685 : ~ @Equation3685 Fin2 reff108_inst.
Proof. unfold Equation3685. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff108_inst, reff108_op in H. discriminate H. Qed.

Lemma reff108_not3687 : ~ @Equation3687 Fin2 reff108_inst.
Proof. unfold Equation3687. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff108_inst, reff108_op in H. discriminate H. Qed.

Lemma reff108_not3722 : ~ @Equation3722 Fin2 reff108_inst.
Proof. unfold Equation3722. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff108_inst, reff108_op in H. discriminate H. Qed.

Lemma reff108_not3724 : ~ @Equation3724 Fin2 reff108_inst.
Proof. unfold Equation3724. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff108_inst, reff108_op in H. discriminate H. Qed.

Lemma reff108_not3749 : ~ @Equation3749 Fin2 reff108_inst.
Proof. unfold Equation3749. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff108_inst, reff108_op in H. discriminate H. Qed.

Lemma reff108_not3751 : ~ @Equation3751 Fin2 reff108_inst.
Proof. unfold Equation3751. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff108_inst, reff108_op in H. discriminate H. Qed.

Lemma reff108_not3864 : ~ @Equation3864 Fin2 reff108_inst.
Proof. unfold Equation3864. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff108_inst, reff108_op in H. discriminate H. Qed.

Lemma reff108_not3867 : ~ @Equation3867 Fin2 reff108_inst.
Proof. unfold Equation3867. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff108_inst, reff108_op in H. discriminate H. Qed.

Lemma reff108_not3871 : ~ @Equation3871 Fin2 reff108_inst.
Proof. unfold Equation3871. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff108_inst, reff108_op in H. discriminate H. Qed.

Lemma reff108_not3877 : ~ @Equation3877 Fin2 reff108_inst.
Proof. unfold Equation3877. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff108_inst, reff108_op in H. discriminate H. Qed.

Lemma reff108_not3881 : ~ @Equation3881 Fin2 reff108_inst.
Proof. unfold Equation3881. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff108_inst, reff108_op in H. discriminate H. Qed.

Lemma reff108_not3888 : ~ @Equation3888 Fin2 reff108_inst.
Proof. unfold Equation3888. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff108_inst, reff108_op in H. discriminate H. Qed.

Lemma reff108_not3890 : ~ @Equation3890 Fin2 reff108_inst.
Proof. unfold Equation3890. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff108_inst, reff108_op in H. discriminate H. Qed.

Lemma reff108_not3918 : ~ @Equation3918 Fin2 reff108_inst.
Proof. unfold Equation3918. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff108_inst, reff108_op in H. discriminate H. Qed.

Lemma reff108_not3925 : ~ @Equation3925 Fin2 reff108_inst.
Proof. unfold Equation3925. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff108_inst, reff108_op in H. discriminate H. Qed.

Lemma reff108_not3927 : ~ @Equation3927 Fin2 reff108_inst.
Proof. unfold Equation3927. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff108_inst, reff108_op in H. discriminate H. Qed.

Lemma reff108_not3952 : ~ @Equation3952 Fin2 reff108_inst.
Proof. unfold Equation3952. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff108_inst, reff108_op in H. discriminate H. Qed.

Lemma reff108_not3954 : ~ @Equation3954 Fin2 reff108_inst.
Proof. unfold Equation3954. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff108_inst, reff108_op in H. discriminate H. Qed.

Lemma reff108_not3961 : ~ @Equation3961 Fin2 reff108_inst.
Proof. unfold Equation3961. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff108_inst, reff108_op in H. discriminate H. Qed.

Lemma reff108_not4066 : ~ @Equation4066 Fin2 reff108_inst.
Proof. unfold Equation4066. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff108_inst, reff108_op in H. discriminate H. Qed.

Lemma reff108_not4067 : ~ @Equation4067 Fin2 reff108_inst.
Proof. unfold Equation4067. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff108_inst, reff108_op in H. discriminate H. Qed.

Lemma reff108_not4070 : ~ @Equation4070 Fin2 reff108_inst.
Proof. unfold Equation4070. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff108_inst, reff108_op in H. discriminate H. Qed.

Lemma reff108_not4074 : ~ @Equation4074 Fin2 reff108_inst.
Proof. unfold Equation4074. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff108_inst, reff108_op in H. discriminate H. Qed.

Lemma reff108_not4080 : ~ @Equation4080 Fin2 reff108_inst.
Proof. unfold Equation4080. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff108_inst, reff108_op in H. discriminate H. Qed.

Lemma reff108_not4084 : ~ @Equation4084 Fin2 reff108_inst.
Proof. unfold Equation4084. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff108_inst, reff108_op in H. discriminate H. Qed.

Lemma reff108_not4091 : ~ @Equation4091 Fin2 reff108_inst.
Proof. unfold Equation4091. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff108_inst, reff108_op in H. discriminate H. Qed.

Lemma reff108_not4093 : ~ @Equation4093 Fin2 reff108_inst.
Proof. unfold Equation4093. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff108_inst, reff108_op in H. discriminate H. Qed.

Lemma reff108_not4121 : ~ @Equation4121 Fin2 reff108_inst.
Proof. unfold Equation4121. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff108_inst, reff108_op in H. discriminate H. Qed.

Lemma reff108_not4128 : ~ @Equation4128 Fin2 reff108_inst.
Proof. unfold Equation4128. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff108_inst, reff108_op in H. discriminate H. Qed.

Lemma reff108_not4130 : ~ @Equation4130 Fin2 reff108_inst.
Proof. unfold Equation4130. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff108_inst, reff108_op in H. discriminate H. Qed.

Lemma reff108_not4155 : ~ @Equation4155 Fin2 reff108_inst.
Proof. unfold Equation4155. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff108_inst, reff108_op in H. discriminate H. Qed.

Lemma reff108_not4157 : ~ @Equation4157 Fin2 reff108_inst.
Proof. unfold Equation4157. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff108_inst, reff108_op in H. discriminate H. Qed.

Lemma reff108_not4164 : ~ @Equation4164 Fin2 reff108_inst.
Proof. unfold Equation4164. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff108_inst, reff108_op in H. discriminate H. Qed.

Lemma reff108_not4268 : ~ @Equation4268 Fin2 reff108_inst.
Proof. unfold Equation4268. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff108_inst, reff108_op in H. discriminate H. Qed.

Lemma reff108_not4269 : ~ @Equation4269 Fin2 reff108_inst.
Proof. unfold Equation4269. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff108_inst, reff108_op in H. discriminate H. Qed.

Lemma reff108_not4272 : ~ @Equation4272 Fin2 reff108_inst.
Proof. unfold Equation4272. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff108_inst, reff108_op in H. discriminate H. Qed.

Lemma reff108_not4276 : ~ @Equation4276 Fin2 reff108_inst.
Proof. unfold Equation4276. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff108_inst, reff108_op in H. discriminate H. Qed.

Lemma reff108_not4284 : ~ @Equation4284 Fin2 reff108_inst.
Proof. unfold Equation4284. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff108_inst, reff108_op in H. discriminate H. Qed.

Lemma reff108_not4291 : ~ @Equation4291 Fin2 reff108_inst.
Proof. unfold Equation4291. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff108_inst, reff108_op in H. discriminate H. Qed.

Lemma reff108_not4293 : ~ @Equation4293 Fin2 reff108_inst.
Proof. unfold Equation4293. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff108_inst, reff108_op in H. discriminate H. Qed.

Lemma reff108_not4314 : ~ @Equation4314 Fin2 reff108_inst.
Proof. unfold Equation4314. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff108_inst, reff108_op in H. discriminate H. Qed.

Lemma reff108_not4321 : ~ @Equation4321 Fin2 reff108_inst.
Proof. unfold Equation4321. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff108_inst, reff108_op in H. discriminate H. Qed.

Lemma reff108_not4343 : ~ @Equation4343 Fin2 reff108_inst.
Proof. unfold Equation4343. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff108_inst, reff108_op in H. discriminate H. Qed.

Lemma reff108_not4399 : ~ @Equation4399 Fin2 reff108_inst.
Proof. unfold Equation4399. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff108_inst, reff108_op in H. discriminate H. Qed.

Lemma reff108_not4406 : ~ @Equation4406 Fin2 reff108_inst.
Proof. unfold Equation4406. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff108_inst, reff108_op in H. discriminate H. Qed.

Lemma reff108_not4408 : ~ @Equation4408 Fin2 reff108_inst.
Proof. unfold Equation4408. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff108_inst, reff108_op in H. discriminate H. Qed.

Lemma reff108_not4436 : ~ @Equation4436 Fin2 reff108_inst.
Proof. unfold Equation4436. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff108_inst, reff108_op in H. discriminate H. Qed.

Lemma reff108_not4443 : ~ @Equation4443 Fin2 reff108_inst.
Proof. unfold Equation4443. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff108_inst, reff108_op in H. discriminate H. Qed.

Lemma reff108_not4445 : ~ @Equation4445 Fin2 reff108_inst.
Proof. unfold Equation4445. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff108_inst, reff108_op in H. discriminate H. Qed.

Lemma reff108_not4470 : ~ @Equation4470 Fin2 reff108_inst.
Proof. unfold Equation4470. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff108_inst, reff108_op in H. discriminate H. Qed.

Lemma reff108_not4472 : ~ @Equation4472 Fin2 reff108_inst.
Proof. unfold Equation4472. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff108_inst, reff108_op in H. discriminate H. Qed.

Lemma reff108_not4479 : ~ @Equation4479 Fin2 reff108_inst.
Proof. unfold Equation4479. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff108_inst, reff108_op in H. discriminate H. Qed.

Lemma reff108_not4583 : ~ @Equation4583 Fin2 reff108_inst.
Proof. unfold Equation4583. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff108_inst, reff108_op in H. discriminate H. Qed.

Lemma reff108_not4584 : ~ @Equation4584 Fin2 reff108_inst.
Proof. unfold Equation4584. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff108_inst, reff108_op in H. discriminate H. Qed.

Lemma reff108_not4587 : ~ @Equation4587 Fin2 reff108_inst.
Proof. unfold Equation4587. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff108_inst, reff108_op in H. discriminate H. Qed.

Lemma reff108_not4591 : ~ @Equation4591 Fin2 reff108_inst.
Proof. unfold Equation4591. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff108_inst, reff108_op in H. discriminate H. Qed.

Lemma reff108_not4599 : ~ @Equation4599 Fin2 reff108_inst.
Proof. unfold Equation4599. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff108_inst, reff108_op in H. discriminate H. Qed.

Lemma reff108_not4606 : ~ @Equation4606 Fin2 reff108_inst.
Proof. unfold Equation4606. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff108_inst, reff108_op in H. discriminate H. Qed.

Lemma reff108_not4608 : ~ @Equation4608 Fin2 reff108_inst.
Proof. unfold Equation4608. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff108_inst, reff108_op in H. discriminate H. Qed.

Lemma reff108_not4629 : ~ @Equation4629 Fin2 reff108_inst.
Proof. unfold Equation4629. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff108_inst, reff108_op in H. discriminate H. Qed.

Lemma reff108_not4636 : ~ @Equation4636 Fin2 reff108_inst.
Proof. unfold Equation4636. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff108_inst, reff108_op in H. discriminate H. Qed.

Lemma reff108_not4658 : ~ @Equation4658 Fin2 reff108_inst.
Proof. unfold Equation4658. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff108_inst, reff108_op in H. discriminate H. Qed.

(** ---- reff112 (Fin4) ---- *)

Definition reff112_op (x y : Fin4) : Fin4 :=
  match x, y with
  | F4_0, F4_0 => F4_0 | F4_0, F4_1 => F4_0 | F4_0, F4_2 => F4_0 | F4_0, F4_3 => F4_0
  | F4_1, F4_0 => F4_3 | F4_1, F4_1 => F4_3 | F4_1, F4_2 => F4_3 | F4_1, F4_3 => F4_3
  | F4_2, F4_0 => F4_2 | F4_2, F4_1 => F4_2 | F4_2, F4_2 => F4_2 | F4_2, F4_3 => F4_2
  | F4_3, F4_0 => F4_1 | F4_3, F4_1 => F4_1 | F4_3, F4_2 => F4_1 | F4_3, F4_3 => F4_1
  end.

#[local] Instance reff112_inst : Magma Fin4 := {| magma_op := reff112_op |}.

Lemma reff112_sat24 : @Equation24 Fin4 reff112_inst.
Proof. unfold Equation24, magma_op, reff112_inst, reff112_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff112_sat4117 : @Equation4117 Fin4 reff112_inst.
Proof. unfold Equation4117, magma_op, reff112_inst, reff112_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff112_not47 : ~ @Equation47 Fin4 reff112_inst.
Proof. unfold Equation47. intro H. specialize (H F4_1). unfold magma_op, reff112_inst, reff112_op in H. discriminate H. Qed.

Lemma reff112_not99 : ~ @Equation99 Fin4 reff112_inst.
Proof. unfold Equation99. intro H. specialize (H F4_1). unfold magma_op, reff112_inst, reff112_op in H. discriminate H. Qed.

Lemma reff112_not167 : ~ @Equation167 Fin4 reff112_inst.
Proof. unfold Equation167. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff112_inst, reff112_op in H. discriminate H. Qed.

Lemma reff112_not169 : ~ @Equation169 Fin4 reff112_inst.
Proof. unfold Equation169. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff112_inst, reff112_op in H. discriminate H. Qed.

Lemma reff112_not170 : ~ @Equation170 Fin4 reff112_inst.
Proof. unfold Equation170. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff112_inst, reff112_op in H. discriminate H. Qed.

Lemma reff112_not176 : ~ @Equation176 Fin4 reff112_inst.
Proof. unfold Equation176. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff112_inst, reff112_op in H. discriminate H. Qed.

Lemma reff112_not177 : ~ @Equation177 Fin4 reff112_inst.
Proof. unfold Equation177. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff112_inst, reff112_op in H. discriminate H. Qed.

Lemma reff112_not179 : ~ @Equation179 Fin4 reff112_inst.
Proof. unfold Equation179. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff112_inst, reff112_op in H. discriminate H. Qed.

Lemma reff112_not219 : ~ @Equation219 Fin4 reff112_inst.
Proof. unfold Equation219. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff112_inst, reff112_op in H. discriminate H. Qed.

Lemma reff112_not221 : ~ @Equation221 Fin4 reff112_inst.
Proof. unfold Equation221. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff112_inst, reff112_op in H. discriminate H. Qed.

Lemma reff112_not222 : ~ @Equation222 Fin4 reff112_inst.
Proof. unfold Equation222. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff112_inst, reff112_op in H. discriminate H. Qed.

Lemma reff112_not228 : ~ @Equation228 Fin4 reff112_inst.
Proof. unfold Equation228. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff112_inst, reff112_op in H. discriminate H. Qed.

Lemma reff112_not229 : ~ @Equation229 Fin4 reff112_inst.
Proof. unfold Equation229. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff112_inst, reff112_op in H. discriminate H. Qed.

Lemma reff112_not231 : ~ @Equation231 Fin4 reff112_inst.
Proof. unfold Equation231. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff112_inst, reff112_op in H. discriminate H. Qed.

Lemma reff112_not255 : ~ @Equation255 Fin4 reff112_inst.
Proof. unfold Equation255. intro H. specialize (H F4_1). unfold magma_op, reff112_inst, reff112_op in H. discriminate H. Qed.

Lemma reff112_not359 : ~ @Equation359 Fin4 reff112_inst.
Proof. unfold Equation359. intro H. specialize (H F4_1). unfold magma_op, reff112_inst, reff112_op in H. discriminate H. Qed.

Lemma reff112_not411 : ~ @Equation411 Fin4 reff112_inst.
Proof. unfold Equation411. intro H. specialize (H F4_1). unfold magma_op, reff112_inst, reff112_op in H. discriminate H. Qed.

Lemma reff112_not614 : ~ @Equation614 Fin4 reff112_inst.
Proof. unfold Equation614. intro H. specialize (H F4_1). unfold magma_op, reff112_inst, reff112_op in H. discriminate H. Qed.

Lemma reff112_not817 : ~ @Equation817 Fin4 reff112_inst.
Proof. unfold Equation817. intro H. specialize (H F4_1). unfold magma_op, reff112_inst, reff112_op in H. discriminate H. Qed.

Lemma reff112_not1020 : ~ @Equation1020 Fin4 reff112_inst.
Proof. unfold Equation1020. intro H. specialize (H F4_1). unfold magma_op, reff112_inst, reff112_op in H. discriminate H. Qed.

Lemma reff112_not1223 : ~ @Equation1223 Fin4 reff112_inst.
Proof. unfold Equation1223. intro H. specialize (H F4_1). unfold magma_op, reff112_inst, reff112_op in H. discriminate H. Qed.

Lemma reff112_not1478 : ~ @Equation1478 Fin4 reff112_inst.
Proof. unfold Equation1478. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff112_inst, reff112_op in H. discriminate H. Qed.

Lemma reff112_not1479 : ~ @Equation1479 Fin4 reff112_inst.
Proof. unfold Equation1479. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff112_inst, reff112_op in H. discriminate H. Qed.

Lemma reff112_not1481 : ~ @Equation1481 Fin4 reff112_inst.
Proof. unfold Equation1481. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff112_inst, reff112_op in H. discriminate H. Qed.

Lemma reff112_not1482 : ~ @Equation1482 Fin4 reff112_inst.
Proof. unfold Equation1482. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff112_inst, reff112_op in H. discriminate H. Qed.

Lemma reff112_not1488 : ~ @Equation1488 Fin4 reff112_inst.
Proof. unfold Equation1488. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff112_inst, reff112_op in H. discriminate H. Qed.

Lemma reff112_not1489 : ~ @Equation1489 Fin4 reff112_inst.
Proof. unfold Equation1489. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff112_inst, reff112_op in H. discriminate H. Qed.

Lemma reff112_not1491 : ~ @Equation1491 Fin4 reff112_inst.
Proof. unfold Equation1491. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff112_inst, reff112_op in H. discriminate H. Qed.

Lemma reff112_not1492 : ~ @Equation1492 Fin4 reff112_inst.
Proof. unfold Equation1492. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff112_inst, reff112_op in H. discriminate H. Qed.

Lemma reff112_not1515 : ~ @Equation1515 Fin4 reff112_inst.
Proof. unfold Equation1515. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff112_inst, reff112_op in H. discriminate H. Qed.

Lemma reff112_not1516 : ~ @Equation1516 Fin4 reff112_inst.
Proof. unfold Equation1516. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff112_inst, reff112_op in H. discriminate H. Qed.

Lemma reff112_not1518 : ~ @Equation1518 Fin4 reff112_inst.
Proof. unfold Equation1518. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff112_inst, reff112_op in H. discriminate H. Qed.

Lemma reff112_not1519 : ~ @Equation1519 Fin4 reff112_inst.
Proof. unfold Equation1519. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff112_inst, reff112_op in H. discriminate H. Qed.

Lemma reff112_not1525 : ~ @Equation1525 Fin4 reff112_inst.
Proof. unfold Equation1525. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff112_inst, reff112_op in H. discriminate H. Qed.

Lemma reff112_not1526 : ~ @Equation1526 Fin4 reff112_inst.
Proof. unfold Equation1526. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff112_inst, reff112_op in H. discriminate H. Qed.

Lemma reff112_not1528 : ~ @Equation1528 Fin4 reff112_inst.
Proof. unfold Equation1528. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff112_inst, reff112_op in H. discriminate H. Qed.

Lemma reff112_not1681 : ~ @Equation1681 Fin4 reff112_inst.
Proof. unfold Equation1681. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff112_inst, reff112_op in H. discriminate H. Qed.

Lemma reff112_not1682 : ~ @Equation1682 Fin4 reff112_inst.
Proof. unfold Equation1682. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff112_inst, reff112_op in H. discriminate H. Qed.

Lemma reff112_not1684 : ~ @Equation1684 Fin4 reff112_inst.
Proof. unfold Equation1684. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff112_inst, reff112_op in H. discriminate H. Qed.

Lemma reff112_not1685 : ~ @Equation1685 Fin4 reff112_inst.
Proof. unfold Equation1685. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff112_inst, reff112_op in H. discriminate H. Qed.

Lemma reff112_not1691 : ~ @Equation1691 Fin4 reff112_inst.
Proof. unfold Equation1691. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff112_inst, reff112_op in H. discriminate H. Qed.

Lemma reff112_not1692 : ~ @Equation1692 Fin4 reff112_inst.
Proof. unfold Equation1692. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff112_inst, reff112_op in H. discriminate H. Qed.

Lemma reff112_not1694 : ~ @Equation1694 Fin4 reff112_inst.
Proof. unfold Equation1694. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff112_inst, reff112_op in H. discriminate H. Qed.

Lemma reff112_not1695 : ~ @Equation1695 Fin4 reff112_inst.
Proof. unfold Equation1695. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff112_inst, reff112_op in H. discriminate H. Qed.

Lemma reff112_not1718 : ~ @Equation1718 Fin4 reff112_inst.
Proof. unfold Equation1718. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff112_inst, reff112_op in H. discriminate H. Qed.

Lemma reff112_not1719 : ~ @Equation1719 Fin4 reff112_inst.
Proof. unfold Equation1719. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff112_inst, reff112_op in H. discriminate H. Qed.

Lemma reff112_not1721 : ~ @Equation1721 Fin4 reff112_inst.
Proof. unfold Equation1721. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff112_inst, reff112_op in H. discriminate H. Qed.

Lemma reff112_not1722 : ~ @Equation1722 Fin4 reff112_inst.
Proof. unfold Equation1722. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff112_inst, reff112_op in H. discriminate H. Qed.

Lemma reff112_not1728 : ~ @Equation1728 Fin4 reff112_inst.
Proof. unfold Equation1728. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff112_inst, reff112_op in H. discriminate H. Qed.

Lemma reff112_not1729 : ~ @Equation1729 Fin4 reff112_inst.
Proof. unfold Equation1729. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff112_inst, reff112_op in H. discriminate H. Qed.

Lemma reff112_not1731 : ~ @Equation1731 Fin4 reff112_inst.
Proof. unfold Equation1731. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff112_inst, reff112_op in H. discriminate H. Qed.

Lemma reff112_not1884 : ~ @Equation1884 Fin4 reff112_inst.
Proof. unfold Equation1884. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff112_inst, reff112_op in H. discriminate H. Qed.

Lemma reff112_not1885 : ~ @Equation1885 Fin4 reff112_inst.
Proof. unfold Equation1885. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff112_inst, reff112_op in H. discriminate H. Qed.

Lemma reff112_not1887 : ~ @Equation1887 Fin4 reff112_inst.
Proof. unfold Equation1887. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff112_inst, reff112_op in H. discriminate H. Qed.

Lemma reff112_not1888 : ~ @Equation1888 Fin4 reff112_inst.
Proof. unfold Equation1888. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff112_inst, reff112_op in H. discriminate H. Qed.

Lemma reff112_not1894 : ~ @Equation1894 Fin4 reff112_inst.
Proof. unfold Equation1894. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff112_inst, reff112_op in H. discriminate H. Qed.

Lemma reff112_not1895 : ~ @Equation1895 Fin4 reff112_inst.
Proof. unfold Equation1895. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff112_inst, reff112_op in H. discriminate H. Qed.

Lemma reff112_not1897 : ~ @Equation1897 Fin4 reff112_inst.
Proof. unfold Equation1897. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff112_inst, reff112_op in H. discriminate H. Qed.

Lemma reff112_not1898 : ~ @Equation1898 Fin4 reff112_inst.
Proof. unfold Equation1898. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff112_inst, reff112_op in H. discriminate H. Qed.

Lemma reff112_not1921 : ~ @Equation1921 Fin4 reff112_inst.
Proof. unfold Equation1921. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff112_inst, reff112_op in H. discriminate H. Qed.

Lemma reff112_not1922 : ~ @Equation1922 Fin4 reff112_inst.
Proof. unfold Equation1922. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff112_inst, reff112_op in H. discriminate H. Qed.

Lemma reff112_not1924 : ~ @Equation1924 Fin4 reff112_inst.
Proof. unfold Equation1924. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff112_inst, reff112_op in H. discriminate H. Qed.

Lemma reff112_not1925 : ~ @Equation1925 Fin4 reff112_inst.
Proof. unfold Equation1925. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff112_inst, reff112_op in H. discriminate H. Qed.

Lemma reff112_not1931 : ~ @Equation1931 Fin4 reff112_inst.
Proof. unfold Equation1931. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff112_inst, reff112_op in H. discriminate H. Qed.

Lemma reff112_not1932 : ~ @Equation1932 Fin4 reff112_inst.
Proof. unfold Equation1932. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff112_inst, reff112_op in H. discriminate H. Qed.

Lemma reff112_not1934 : ~ @Equation1934 Fin4 reff112_inst.
Proof. unfold Equation1934. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff112_inst, reff112_op in H. discriminate H. Qed.

Lemma reff112_not2035 : ~ @Equation2035 Fin4 reff112_inst.
Proof. unfold Equation2035. intro H. specialize (H F4_1). unfold magma_op, reff112_inst, reff112_op in H. discriminate H. Qed.

Lemma reff112_not2290 : ~ @Equation2290 Fin4 reff112_inst.
Proof. unfold Equation2290. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff112_inst, reff112_op in H. discriminate H. Qed.

Lemma reff112_not2291 : ~ @Equation2291 Fin4 reff112_inst.
Proof. unfold Equation2291. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff112_inst, reff112_op in H. discriminate H. Qed.

Lemma reff112_not2293 : ~ @Equation2293 Fin4 reff112_inst.
Proof. unfold Equation2293. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff112_inst, reff112_op in H. discriminate H. Qed.

Lemma reff112_not2294 : ~ @Equation2294 Fin4 reff112_inst.
Proof. unfold Equation2294. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff112_inst, reff112_op in H. discriminate H. Qed.

Lemma reff112_not2300 : ~ @Equation2300 Fin4 reff112_inst.
Proof. unfold Equation2300. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff112_inst, reff112_op in H. discriminate H. Qed.

Lemma reff112_not2301 : ~ @Equation2301 Fin4 reff112_inst.
Proof. unfold Equation2301. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff112_inst, reff112_op in H. discriminate H. Qed.

Lemma reff112_not2303 : ~ @Equation2303 Fin4 reff112_inst.
Proof. unfold Equation2303. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff112_inst, reff112_op in H. discriminate H. Qed.

Lemma reff112_not2304 : ~ @Equation2304 Fin4 reff112_inst.
Proof. unfold Equation2304. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff112_inst, reff112_op in H. discriminate H. Qed.

Lemma reff112_not2327 : ~ @Equation2327 Fin4 reff112_inst.
Proof. unfold Equation2327. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff112_inst, reff112_op in H. discriminate H. Qed.

Lemma reff112_not2328 : ~ @Equation2328 Fin4 reff112_inst.
Proof. unfold Equation2328. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff112_inst, reff112_op in H. discriminate H. Qed.

Lemma reff112_not2330 : ~ @Equation2330 Fin4 reff112_inst.
Proof. unfold Equation2330. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff112_inst, reff112_op in H. discriminate H. Qed.

Lemma reff112_not2331 : ~ @Equation2331 Fin4 reff112_inst.
Proof. unfold Equation2331. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff112_inst, reff112_op in H. discriminate H. Qed.

Lemma reff112_not2337 : ~ @Equation2337 Fin4 reff112_inst.
Proof. unfold Equation2337. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff112_inst, reff112_op in H. discriminate H. Qed.

Lemma reff112_not2338 : ~ @Equation2338 Fin4 reff112_inst.
Proof. unfold Equation2338. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff112_inst, reff112_op in H. discriminate H. Qed.

Lemma reff112_not2340 : ~ @Equation2340 Fin4 reff112_inst.
Proof. unfold Equation2340. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff112_inst, reff112_op in H. discriminate H. Qed.

Lemma reff112_not2493 : ~ @Equation2493 Fin4 reff112_inst.
Proof. unfold Equation2493. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff112_inst, reff112_op in H. discriminate H. Qed.

Lemma reff112_not2494 : ~ @Equation2494 Fin4 reff112_inst.
Proof. unfold Equation2494. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff112_inst, reff112_op in H. discriminate H. Qed.

Lemma reff112_not2496 : ~ @Equation2496 Fin4 reff112_inst.
Proof. unfold Equation2496. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff112_inst, reff112_op in H. discriminate H. Qed.

Lemma reff112_not2497 : ~ @Equation2497 Fin4 reff112_inst.
Proof. unfold Equation2497. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff112_inst, reff112_op in H. discriminate H. Qed.

Lemma reff112_not2503 : ~ @Equation2503 Fin4 reff112_inst.
Proof. unfold Equation2503. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff112_inst, reff112_op in H. discriminate H. Qed.

Lemma reff112_not2504 : ~ @Equation2504 Fin4 reff112_inst.
Proof. unfold Equation2504. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff112_inst, reff112_op in H. discriminate H. Qed.

Lemma reff112_not2506 : ~ @Equation2506 Fin4 reff112_inst.
Proof. unfold Equation2506. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff112_inst, reff112_op in H. discriminate H. Qed.

Lemma reff112_not2507 : ~ @Equation2507 Fin4 reff112_inst.
Proof. unfold Equation2507. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff112_inst, reff112_op in H. discriminate H. Qed.

Lemma reff112_not2530 : ~ @Equation2530 Fin4 reff112_inst.
Proof. unfold Equation2530. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff112_inst, reff112_op in H. discriminate H. Qed.

Lemma reff112_not2531 : ~ @Equation2531 Fin4 reff112_inst.
Proof. unfold Equation2531. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff112_inst, reff112_op in H. discriminate H. Qed.

Lemma reff112_not2533 : ~ @Equation2533 Fin4 reff112_inst.
Proof. unfold Equation2533. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff112_inst, reff112_op in H. discriminate H. Qed.

Lemma reff112_not2534 : ~ @Equation2534 Fin4 reff112_inst.
Proof. unfold Equation2534. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff112_inst, reff112_op in H. discriminate H. Qed.

Lemma reff112_not2540 : ~ @Equation2540 Fin4 reff112_inst.
Proof. unfold Equation2540. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff112_inst, reff112_op in H. discriminate H. Qed.

Lemma reff112_not2541 : ~ @Equation2541 Fin4 reff112_inst.
Proof. unfold Equation2541. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff112_inst, reff112_op in H. discriminate H. Qed.

Lemma reff112_not2543 : ~ @Equation2543 Fin4 reff112_inst.
Proof. unfold Equation2543. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff112_inst, reff112_op in H. discriminate H. Qed.

Lemma reff112_not2644 : ~ @Equation2644 Fin4 reff112_inst.
Proof. unfold Equation2644. intro H. specialize (H F4_1). unfold magma_op, reff112_inst, reff112_op in H. discriminate H. Qed.

Lemma reff112_not2847 : ~ @Equation2847 Fin4 reff112_inst.
Proof. unfold Equation2847. intro H. specialize (H F4_1). unfold magma_op, reff112_inst, reff112_op in H. discriminate H. Qed.

Lemma reff112_not3102 : ~ @Equation3102 Fin4 reff112_inst.
Proof. unfold Equation3102. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff112_inst, reff112_op in H. discriminate H. Qed.

Lemma reff112_not3103 : ~ @Equation3103 Fin4 reff112_inst.
Proof. unfold Equation3103. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff112_inst, reff112_op in H. discriminate H. Qed.

Lemma reff112_not3105 : ~ @Equation3105 Fin4 reff112_inst.
Proof. unfold Equation3105. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff112_inst, reff112_op in H. discriminate H. Qed.

Lemma reff112_not3106 : ~ @Equation3106 Fin4 reff112_inst.
Proof. unfold Equation3106. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff112_inst, reff112_op in H. discriminate H. Qed.

Lemma reff112_not3112 : ~ @Equation3112 Fin4 reff112_inst.
Proof. unfold Equation3112. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff112_inst, reff112_op in H. discriminate H. Qed.

Lemma reff112_not3113 : ~ @Equation3113 Fin4 reff112_inst.
Proof. unfold Equation3113. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff112_inst, reff112_op in H. discriminate H. Qed.

Lemma reff112_not3115 : ~ @Equation3115 Fin4 reff112_inst.
Proof. unfold Equation3115. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff112_inst, reff112_op in H. discriminate H. Qed.

Lemma reff112_not3116 : ~ @Equation3116 Fin4 reff112_inst.
Proof. unfold Equation3116. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff112_inst, reff112_op in H. discriminate H. Qed.

Lemma reff112_not3139 : ~ @Equation3139 Fin4 reff112_inst.
Proof. unfold Equation3139. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff112_inst, reff112_op in H. discriminate H. Qed.

Lemma reff112_not3140 : ~ @Equation3140 Fin4 reff112_inst.
Proof. unfold Equation3140. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff112_inst, reff112_op in H. discriminate H. Qed.

Lemma reff112_not3142 : ~ @Equation3142 Fin4 reff112_inst.
Proof. unfold Equation3142. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff112_inst, reff112_op in H. discriminate H. Qed.

Lemma reff112_not3143 : ~ @Equation3143 Fin4 reff112_inst.
Proof. unfold Equation3143. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff112_inst, reff112_op in H. discriminate H. Qed.

Lemma reff112_not3149 : ~ @Equation3149 Fin4 reff112_inst.
Proof. unfold Equation3149. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff112_inst, reff112_op in H. discriminate H. Qed.

Lemma reff112_not3150 : ~ @Equation3150 Fin4 reff112_inst.
Proof. unfold Equation3150. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff112_inst, reff112_op in H. discriminate H. Qed.

Lemma reff112_not3152 : ~ @Equation3152 Fin4 reff112_inst.
Proof. unfold Equation3152. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff112_inst, reff112_op in H. discriminate H. Qed.

Lemma reff112_not3268 : ~ @Equation3268 Fin4 reff112_inst.
Proof. unfold Equation3268. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff112_inst, reff112_op in H. discriminate H. Qed.

Lemma reff112_not3271 : ~ @Equation3271 Fin4 reff112_inst.
Proof. unfold Equation3271. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff112_inst, reff112_op in H. discriminate H. Qed.

Lemma reff112_not3272 : ~ @Equation3272 Fin4 reff112_inst.
Proof. unfold Equation3272. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff112_inst, reff112_op in H. discriminate H. Qed.

Lemma reff112_not3278 : ~ @Equation3278 Fin4 reff112_inst.
Proof. unfold Equation3278. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff112_inst, reff112_op in H. discriminate H. Qed.

Lemma reff112_not3279 : ~ @Equation3279 Fin4 reff112_inst.
Proof. unfold Equation3279. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff112_inst, reff112_op in H. discriminate H. Qed.

Lemma reff112_not3281 : ~ @Equation3281 Fin4 reff112_inst.
Proof. unfold Equation3281. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff112_inst, reff112_op in H. discriminate H. Qed.

Lemma reff112_not3342 : ~ @Equation3342 Fin4 reff112_inst.
Proof. unfold Equation3342. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff112_inst, reff112_op in H. discriminate H. Qed.

Lemma reff112_not3343 : ~ @Equation3343 Fin4 reff112_inst.
Proof. unfold Equation3343. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff112_inst, reff112_op in H. discriminate H. Qed.

Lemma reff112_not3345 : ~ @Equation3345 Fin4 reff112_inst.
Proof. unfold Equation3345. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff112_inst, reff112_op in H. discriminate H. Qed.

Lemma reff112_not3346 : ~ @Equation3346 Fin4 reff112_inst.
Proof. unfold Equation3346. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff112_inst, reff112_op in H. discriminate H. Qed.

Lemma reff112_not3352 : ~ @Equation3352 Fin4 reff112_inst.
Proof. unfold Equation3352. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff112_inst, reff112_op in H. discriminate H. Qed.

Lemma reff112_not3353 : ~ @Equation3353 Fin4 reff112_inst.
Proof. unfold Equation3353. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff112_inst, reff112_op in H. discriminate H. Qed.

Lemma reff112_not3472 : ~ @Equation3472 Fin4 reff112_inst.
Proof. unfold Equation3472. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff112_inst, reff112_op in H. discriminate H. Qed.

Lemma reff112_not3474 : ~ @Equation3474 Fin4 reff112_inst.
Proof. unfold Equation3474. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff112_inst, reff112_op in H. discriminate H. Qed.

Lemma reff112_not3475 : ~ @Equation3475 Fin4 reff112_inst.
Proof. unfold Equation3475. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff112_inst, reff112_op in H. discriminate H. Qed.

Lemma reff112_not3481 : ~ @Equation3481 Fin4 reff112_inst.
Proof. unfold Equation3481. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff112_inst, reff112_op in H. discriminate H. Qed.

Lemma reff112_not3482 : ~ @Equation3482 Fin4 reff112_inst.
Proof. unfold Equation3482. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff112_inst, reff112_op in H. discriminate H. Qed.

Lemma reff112_not3484 : ~ @Equation3484 Fin4 reff112_inst.
Proof. unfold Equation3484. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff112_inst, reff112_op in H. discriminate H. Qed.

Lemma reff112_not3545 : ~ @Equation3545 Fin4 reff112_inst.
Proof. unfold Equation3545. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff112_inst, reff112_op in H. discriminate H. Qed.

Lemma reff112_not3546 : ~ @Equation3546 Fin4 reff112_inst.
Proof. unfold Equation3546. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff112_inst, reff112_op in H. discriminate H. Qed.

Lemma reff112_not3548 : ~ @Equation3548 Fin4 reff112_inst.
Proof. unfold Equation3548. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff112_inst, reff112_op in H. discriminate H. Qed.

Lemma reff112_not3549 : ~ @Equation3549 Fin4 reff112_inst.
Proof. unfold Equation3549. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff112_inst, reff112_op in H. discriminate H. Qed.

Lemma reff112_not3555 : ~ @Equation3555 Fin4 reff112_inst.
Proof. unfold Equation3555. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff112_inst, reff112_op in H. discriminate H. Qed.

Lemma reff112_not3556 : ~ @Equation3556 Fin4 reff112_inst.
Proof. unfold Equation3556. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff112_inst, reff112_op in H. discriminate H. Qed.

Lemma reff112_not3558 : ~ @Equation3558 Fin4 reff112_inst.
Proof. unfold Equation3558. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff112_inst, reff112_op in H. discriminate H. Qed.

Lemma reff112_not3659 : ~ @Equation3659 Fin4 reff112_inst.
Proof. unfold Equation3659. intro H. specialize (H F4_1). unfold magma_op, reff112_inst, reff112_op in H. discriminate H. Qed.

Lemma reff112_not3862 : ~ @Equation3862 Fin4 reff112_inst.
Proof. unfold Equation3862. intro H. specialize (H F4_1). unfold magma_op, reff112_inst, reff112_op in H. discriminate H. Qed.

Lemma reff112_not4080 : ~ @Equation4080 Fin4 reff112_inst.
Proof. unfold Equation4080. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff112_inst, reff112_op in H. discriminate H. Qed.

Lemma reff112_not4083 : ~ @Equation4083 Fin4 reff112_inst.
Proof. unfold Equation4083. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff112_inst, reff112_op in H. discriminate H. Qed.

Lemma reff112_not4084 : ~ @Equation4084 Fin4 reff112_inst.
Proof. unfold Equation4084. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff112_inst, reff112_op in H. discriminate H. Qed.

Lemma reff112_not4090 : ~ @Equation4090 Fin4 reff112_inst.
Proof. unfold Equation4090. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff112_inst, reff112_op in H. discriminate H. Qed.

Lemma reff112_not4091 : ~ @Equation4091 Fin4 reff112_inst.
Proof. unfold Equation4091. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff112_inst, reff112_op in H. discriminate H. Qed.

Lemma reff112_not4093 : ~ @Equation4093 Fin4 reff112_inst.
Proof. unfold Equation4093. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff112_inst, reff112_op in H. discriminate H. Qed.

Lemma reff112_not4155 : ~ @Equation4155 Fin4 reff112_inst.
Proof. unfold Equation4155. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff112_inst, reff112_op in H. discriminate H. Qed.

Lemma reff112_not4157 : ~ @Equation4157 Fin4 reff112_inst.
Proof. unfold Equation4157. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff112_inst, reff112_op in H. discriminate H. Qed.

Lemma reff112_not4158 : ~ @Equation4158 Fin4 reff112_inst.
Proof. unfold Equation4158. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff112_inst, reff112_op in H. discriminate H. Qed.

Lemma reff112_not4164 : ~ @Equation4164 Fin4 reff112_inst.
Proof. unfold Equation4164. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff112_inst, reff112_op in H. discriminate H. Qed.

Lemma reff112_not4165 : ~ @Equation4165 Fin4 reff112_inst.
Proof. unfold Equation4165. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff112_inst, reff112_op in H. discriminate H. Qed.

Lemma reff112_not4167 : ~ @Equation4167 Fin4 reff112_inst.
Proof. unfold Equation4167. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff112_inst, reff112_op in H. discriminate H. Qed.

Lemma reff112_not4272 : ~ @Equation4272 Fin4 reff112_inst.
Proof. unfold Equation4272. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff112_inst, reff112_op in H. discriminate H. Qed.

Lemma reff112_not4273 : ~ @Equation4273 Fin4 reff112_inst.
Proof. unfold Equation4273. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff112_inst, reff112_op in H. discriminate H. Qed.

Lemma reff112_not4275 : ~ @Equation4275 Fin4 reff112_inst.
Proof. unfold Equation4275. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff112_inst, reff112_op in H. discriminate H. Qed.

Lemma reff112_not4276 : ~ @Equation4276 Fin4 reff112_inst.
Proof. unfold Equation4276. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff112_inst, reff112_op in H. discriminate H. Qed.

Lemma reff112_not4290 : ~ @Equation4290 Fin4 reff112_inst.
Proof. unfold Equation4290. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff112_inst, reff112_op in H. discriminate H. Qed.

Lemma reff112_not4291 : ~ @Equation4291 Fin4 reff112_inst.
Proof. unfold Equation4291. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff112_inst, reff112_op in H. discriminate H. Qed.

Lemma reff112_not4293 : ~ @Equation4293 Fin4 reff112_inst.
Proof. unfold Equation4293. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff112_inst, reff112_op in H. discriminate H. Qed.

Lemma reff112_not4320 : ~ @Equation4320 Fin4 reff112_inst.
Proof. unfold Equation4320. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff112_inst, reff112_op in H. discriminate H. Qed.

Lemma reff112_not4321 : ~ @Equation4321 Fin4 reff112_inst.
Proof. unfold Equation4321. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff112_inst, reff112_op in H. discriminate H. Qed.

Lemma reff112_not4343 : ~ @Equation4343 Fin4 reff112_inst.
Proof. unfold Equation4343. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff112_inst, reff112_op in H. discriminate H. Qed.

Lemma reff112_not4380 : ~ @Equation4380 Fin4 reff112_inst.
Proof. unfold Equation4380. intro H. specialize (H F4_1). unfold magma_op, reff112_inst, reff112_op in H. discriminate H. Qed.

Lemma reff112_not4587 : ~ @Equation4587 Fin4 reff112_inst.
Proof. unfold Equation4587. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff112_inst, reff112_op in H. discriminate H. Qed.

Lemma reff112_not4588 : ~ @Equation4588 Fin4 reff112_inst.
Proof. unfold Equation4588. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff112_inst, reff112_op in H. discriminate H. Qed.

Lemma reff112_not4590 : ~ @Equation4590 Fin4 reff112_inst.
Proof. unfold Equation4590. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff112_inst, reff112_op in H. discriminate H. Qed.

Lemma reff112_not4591 : ~ @Equation4591 Fin4 reff112_inst.
Proof. unfold Equation4591. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff112_inst, reff112_op in H. discriminate H. Qed.

Lemma reff112_not4605 : ~ @Equation4605 Fin4 reff112_inst.
Proof. unfold Equation4605. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff112_inst, reff112_op in H. discriminate H. Qed.

Lemma reff112_not4606 : ~ @Equation4606 Fin4 reff112_inst.
Proof. unfold Equation4606. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff112_inst, reff112_op in H. discriminate H. Qed.

Lemma reff112_not4608 : ~ @Equation4608 Fin4 reff112_inst.
Proof. unfold Equation4608. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff112_inst, reff112_op in H. discriminate H. Qed.

Lemma reff112_not4635 : ~ @Equation4635 Fin4 reff112_inst.
Proof. unfold Equation4635. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff112_inst, reff112_op in H. discriminate H. Qed.

Lemma reff112_not4636 : ~ @Equation4636 Fin4 reff112_inst.
Proof. unfold Equation4636. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff112_inst, reff112_op in H. discriminate H. Qed.

Lemma reff112_not4658 : ~ @Equation4658 Fin4 reff112_inst.
Proof. unfold Equation4658. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff112_inst, reff112_op in H. discriminate H. Qed.

(** ---- reff114 (Fin4) ---- *)

Definition reff114_op (x y : Fin4) : Fin4 :=
  match x, y with
  | F4_0, F4_0 => F4_0 | F4_0, F4_1 => F4_1 | F4_0, F4_2 => F4_2 | F4_0, F4_3 => F4_3
  | F4_1, F4_0 => F4_0 | F4_1, F4_1 => F4_0 | F4_1, F4_2 => F4_0 | F4_1, F4_3 => F4_0
  | F4_2, F4_0 => F4_2 | F4_2, F4_1 => F4_1 | F4_2, F4_2 => F4_0 | F4_2, F4_3 => F4_3
  | F4_3, F4_0 => F4_2 | F4_3, F4_1 => F4_0 | F4_3, F4_2 => F4_2 | F4_3, F4_3 => F4_0
  end.

#[local] Instance reff114_inst : Magma Fin4 := {| magma_op := reff114_op |}.

Lemma reff114_sat31 : @Equation31 Fin4 reff114_inst.
Proof. unfold Equation31, magma_op, reff114_inst, reff114_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff114_sat2246 : @Equation2246 Fin4 reff114_inst.
Proof. unfold Equation2246, magma_op, reff114_inst, reff114_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff114_sat2293 : @Equation2293 Fin4 reff114_inst.
Proof. unfold Equation2293, magma_op, reff114_inst, reff114_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff114_sat3485 : @Equation3485 Fin4 reff114_inst.
Proof. unfold Equation3485, magma_op, reff114_inst, reff114_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff114_sat4094 : @Equation4094 Fin4 reff114_inst.
Proof. unfold Equation4094, magma_op, reff114_inst, reff114_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff114_not47 : ~ @Equation47 Fin4 reff114_inst.
Proof. unfold Equation47. intro H. specialize (H F4_1). unfold magma_op, reff114_inst, reff114_op in H. discriminate H. Qed.

Lemma reff114_not99 : ~ @Equation99 Fin4 reff114_inst.
Proof. unfold Equation99. intro H. specialize (H F4_1). unfold magma_op, reff114_inst, reff114_op in H. discriminate H. Qed.

Lemma reff114_not151 : ~ @Equation151 Fin4 reff114_inst.
Proof. unfold Equation151. intro H. specialize (H F4_1). unfold magma_op, reff114_inst, reff114_op in H. discriminate H. Qed.

Lemma reff114_not203 : ~ @Equation203 Fin4 reff114_inst.
Proof. unfold Equation203. intro H. specialize (H F4_2). unfold magma_op, reff114_inst, reff114_op in H. discriminate H. Qed.

Lemma reff114_not255 : ~ @Equation255 Fin4 reff114_inst.
Proof. unfold Equation255. intro H. specialize (H F4_1). unfold magma_op, reff114_inst, reff114_op in H. discriminate H. Qed.

Lemma reff114_not359 : ~ @Equation359 Fin4 reff114_inst.
Proof. unfold Equation359. intro H. specialize (H F4_1). unfold magma_op, reff114_inst, reff114_op in H. discriminate H. Qed.

Lemma reff114_not411 : ~ @Equation411 Fin4 reff114_inst.
Proof. unfold Equation411. intro H. specialize (H F4_1). unfold magma_op, reff114_inst, reff114_op in H. discriminate H. Qed.

Lemma reff114_not614 : ~ @Equation614 Fin4 reff114_inst.
Proof. unfold Equation614. intro H. specialize (H F4_1). unfold magma_op, reff114_inst, reff114_op in H. discriminate H. Qed.

Lemma reff114_not817 : ~ @Equation817 Fin4 reff114_inst.
Proof. unfold Equation817. intro H. specialize (H F4_1). unfold magma_op, reff114_inst, reff114_op in H. discriminate H. Qed.

Lemma reff114_not1020 : ~ @Equation1020 Fin4 reff114_inst.
Proof. unfold Equation1020. intro H. specialize (H F4_1). unfold magma_op, reff114_inst, reff114_op in H. discriminate H. Qed.

Lemma reff114_not1223 : ~ @Equation1223 Fin4 reff114_inst.
Proof. unfold Equation1223. intro H. specialize (H F4_1). unfold magma_op, reff114_inst, reff114_op in H. discriminate H. Qed.

Lemma reff114_not1426 : ~ @Equation1426 Fin4 reff114_inst.
Proof. unfold Equation1426. intro H. specialize (H F4_1). unfold magma_op, reff114_inst, reff114_op in H. discriminate H. Qed.

Lemma reff114_not1630 : ~ @Equation1630 Fin4 reff114_inst.
Proof. unfold Equation1630. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff114_inst, reff114_op in H. discriminate H. Qed.

Lemma reff114_not1631 : ~ @Equation1631 Fin4 reff114_inst.
Proof. unfold Equation1631. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff114_inst, reff114_op in H. discriminate H. Qed.

Lemma reff114_not1632 : ~ @Equation1632 Fin4 reff114_inst.
Proof. unfold Equation1632. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff114_inst, reff114_op in H. discriminate H. Qed.

Lemma reff114_not1634 : ~ @Equation1634 Fin4 reff114_inst.
Proof. unfold Equation1634. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff114_inst, reff114_op in H. discriminate H. Qed.

Lemma reff114_not1635 : ~ @Equation1635 Fin4 reff114_inst.
Proof. unfold Equation1635. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff114_inst, reff114_op in H. discriminate H. Qed.

Lemma reff114_not1638 : ~ @Equation1638 Fin4 reff114_inst.
Proof. unfold Equation1638. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff114_inst, reff114_op in H. discriminate H. Qed.

Lemma reff114_not1644 : ~ @Equation1644 Fin4 reff114_inst.
Proof. unfold Equation1644. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff114_inst, reff114_op in H. discriminate H. Qed.

Lemma reff114_not1645 : ~ @Equation1645 Fin4 reff114_inst.
Proof. unfold Equation1645. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff114_inst, reff114_op in H. discriminate H. Qed.

Lemma reff114_not1647 : ~ @Equation1647 Fin4 reff114_inst.
Proof. unfold Equation1647. intro H. specialize (H F4_0 F4_3). unfold magma_op, reff114_inst, reff114_op in H. discriminate H. Qed.

Lemma reff114_not1648 : ~ @Equation1648 Fin4 reff114_inst.
Proof. unfold Equation1648. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff114_inst, reff114_op in H. discriminate H. Qed.

Lemma reff114_not1654 : ~ @Equation1654 Fin4 reff114_inst.
Proof. unfold Equation1654. intro H. specialize (H F4_0 F4_3). unfold magma_op, reff114_inst, reff114_op in H. discriminate H. Qed.

Lemma reff114_not1655 : ~ @Equation1655 Fin4 reff114_inst.
Proof. unfold Equation1655. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff114_inst, reff114_op in H. discriminate H. Qed.

Lemma reff114_not1657 : ~ @Equation1657 Fin4 reff114_inst.
Proof. unfold Equation1657. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff114_inst, reff114_op in H. discriminate H. Qed.

Lemma reff114_not1658 : ~ @Equation1658 Fin4 reff114_inst.
Proof. unfold Equation1658. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff114_inst, reff114_op in H. discriminate H. Qed.

Lemma reff114_not1681 : ~ @Equation1681 Fin4 reff114_inst.
Proof. unfold Equation1681. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff114_inst, reff114_op in H. discriminate H. Qed.

Lemma reff114_not1682 : ~ @Equation1682 Fin4 reff114_inst.
Proof. unfold Equation1682. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff114_inst, reff114_op in H. discriminate H. Qed.

Lemma reff114_not1684 : ~ @Equation1684 Fin4 reff114_inst.
Proof. unfold Equation1684. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff114_inst, reff114_op in H. discriminate H. Qed.

Lemma reff114_not1685 : ~ @Equation1685 Fin4 reff114_inst.
Proof. unfold Equation1685. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff114_inst, reff114_op in H. discriminate H. Qed.

Lemma reff114_not1691 : ~ @Equation1691 Fin4 reff114_inst.
Proof. unfold Equation1691. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff114_inst, reff114_op in H. discriminate H. Qed.

Lemma reff114_not1692 : ~ @Equation1692 Fin4 reff114_inst.
Proof. unfold Equation1692. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff114_inst, reff114_op in H. discriminate H. Qed.

Lemma reff114_not1694 : ~ @Equation1694 Fin4 reff114_inst.
Proof. unfold Equation1694. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff114_inst, reff114_op in H. discriminate H. Qed.

Lemma reff114_not1695 : ~ @Equation1695 Fin4 reff114_inst.
Proof. unfold Equation1695. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff114_inst, reff114_op in H. discriminate H. Qed.

Lemma reff114_not1719 : ~ @Equation1719 Fin4 reff114_inst.
Proof. unfold Equation1719. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff114_inst, reff114_op in H. discriminate H. Qed.

Lemma reff114_not1721 : ~ @Equation1721 Fin4 reff114_inst.
Proof. unfold Equation1721. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff114_inst, reff114_op in H. discriminate H. Qed.

Lemma reff114_not1722 : ~ @Equation1722 Fin4 reff114_inst.
Proof. unfold Equation1722. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff114_inst, reff114_op in H. discriminate H. Qed.

Lemma reff114_not1728 : ~ @Equation1728 Fin4 reff114_inst.
Proof. unfold Equation1728. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff114_inst, reff114_op in H. discriminate H. Qed.

Lemma reff114_not1729 : ~ @Equation1729 Fin4 reff114_inst.
Proof. unfold Equation1729. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff114_inst, reff114_op in H. discriminate H. Qed.

Lemma reff114_not1832 : ~ @Equation1832 Fin4 reff114_inst.
Proof. unfold Equation1832. intro H. specialize (H F4_1). unfold magma_op, reff114_inst, reff114_op in H. discriminate H. Qed.

Lemma reff114_not2035 : ~ @Equation2035 Fin4 reff114_inst.
Proof. unfold Equation2035. intro H. specialize (H F4_1). unfold magma_op, reff114_inst, reff114_op in H. discriminate H. Qed.

Lemma reff114_not2239 : ~ @Equation2239 Fin4 reff114_inst.
Proof. unfold Equation2239. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff114_inst, reff114_op in H. discriminate H. Qed.

Lemma reff114_not2240 : ~ @Equation2240 Fin4 reff114_inst.
Proof. unfold Equation2240. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff114_inst, reff114_op in H. discriminate H. Qed.

Lemma reff114_not2241 : ~ @Equation2241 Fin4 reff114_inst.
Proof. unfold Equation2241. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff114_inst, reff114_op in H. discriminate H. Qed.

Lemma reff114_not2243 : ~ @Equation2243 Fin4 reff114_inst.
Proof. unfold Equation2243. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff114_inst, reff114_op in H. discriminate H. Qed.

Lemma reff114_not2244 : ~ @Equation2244 Fin4 reff114_inst.
Proof. unfold Equation2244. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff114_inst, reff114_op in H. discriminate H. Qed.

Lemma reff114_not2247 : ~ @Equation2247 Fin4 reff114_inst.
Proof. unfold Equation2247. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff114_inst, reff114_op in H. discriminate H. Qed.

Lemma reff114_not2253 : ~ @Equation2253 Fin4 reff114_inst.
Proof. unfold Equation2253. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff114_inst, reff114_op in H. discriminate H. Qed.

Lemma reff114_not2254 : ~ @Equation2254 Fin4 reff114_inst.
Proof. unfold Equation2254. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff114_inst, reff114_op in H. discriminate H. Qed.

Lemma reff114_not2256 : ~ @Equation2256 Fin4 reff114_inst.
Proof. unfold Equation2256. intro H. specialize (H F4_2 F4_1). unfold magma_op, reff114_inst, reff114_op in H. discriminate H. Qed.

Lemma reff114_not2257 : ~ @Equation2257 Fin4 reff114_inst.
Proof. unfold Equation2257. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff114_inst, reff114_op in H. discriminate H. Qed.

Lemma reff114_not2263 : ~ @Equation2263 Fin4 reff114_inst.
Proof. unfold Equation2263. intro H. specialize (H F4_0 F4_3). unfold magma_op, reff114_inst, reff114_op in H. discriminate H. Qed.

Lemma reff114_not2264 : ~ @Equation2264 Fin4 reff114_inst.
Proof. unfold Equation2264. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff114_inst, reff114_op in H. discriminate H. Qed.

Lemma reff114_not2266 : ~ @Equation2266 Fin4 reff114_inst.
Proof. unfold Equation2266. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff114_inst, reff114_op in H. discriminate H. Qed.

Lemma reff114_not2267 : ~ @Equation2267 Fin4 reff114_inst.
Proof. unfold Equation2267. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff114_inst, reff114_op in H. discriminate H. Qed.

Lemma reff114_not2290 : ~ @Equation2290 Fin4 reff114_inst.
Proof. unfold Equation2290. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff114_inst, reff114_op in H. discriminate H. Qed.

Lemma reff114_not2291 : ~ @Equation2291 Fin4 reff114_inst.
Proof. unfold Equation2291. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff114_inst, reff114_op in H. discriminate H. Qed.

Lemma reff114_not2294 : ~ @Equation2294 Fin4 reff114_inst.
Proof. unfold Equation2294. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff114_inst, reff114_op in H. discriminate H. Qed.

Lemma reff114_not2300 : ~ @Equation2300 Fin4 reff114_inst.
Proof. unfold Equation2300. intro H. specialize (H F4_0 F4_3). unfold magma_op, reff114_inst, reff114_op in H. discriminate H. Qed.

Lemma reff114_not2301 : ~ @Equation2301 Fin4 reff114_inst.
Proof. unfold Equation2301. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff114_inst, reff114_op in H. discriminate H. Qed.

Lemma reff114_not2303 : ~ @Equation2303 Fin4 reff114_inst.
Proof. unfold Equation2303. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff114_inst, reff114_op in H. discriminate H. Qed.

Lemma reff114_not2304 : ~ @Equation2304 Fin4 reff114_inst.
Proof. unfold Equation2304. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff114_inst, reff114_op in H. discriminate H. Qed.

Lemma reff114_not2327 : ~ @Equation2327 Fin4 reff114_inst.
Proof. unfold Equation2327. intro H. specialize (H F4_0 F4_3). unfold magma_op, reff114_inst, reff114_op in H. discriminate H. Qed.

Lemma reff114_not2328 : ~ @Equation2328 Fin4 reff114_inst.
Proof. unfold Equation2328. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff114_inst, reff114_op in H. discriminate H. Qed.

Lemma reff114_not2330 : ~ @Equation2330 Fin4 reff114_inst.
Proof. unfold Equation2330. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff114_inst, reff114_op in H. discriminate H. Qed.

Lemma reff114_not2331 : ~ @Equation2331 Fin4 reff114_inst.
Proof. unfold Equation2331. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff114_inst, reff114_op in H. discriminate H. Qed.

Lemma reff114_not2337 : ~ @Equation2337 Fin4 reff114_inst.
Proof. unfold Equation2337. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff114_inst, reff114_op in H. discriminate H. Qed.

Lemma reff114_not2338 : ~ @Equation2338 Fin4 reff114_inst.
Proof. unfold Equation2338. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff114_inst, reff114_op in H. discriminate H. Qed.

Lemma reff114_not2340 : ~ @Equation2340 Fin4 reff114_inst.
Proof. unfold Equation2340. intro H. specialize (H F4_0 F4_3). unfold magma_op, reff114_inst, reff114_op in H. discriminate H. Qed.

Lemma reff114_not2442 : ~ @Equation2442 Fin4 reff114_inst.
Proof. unfold Equation2442. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff114_inst, reff114_op in H. discriminate H. Qed.

Lemma reff114_not2443 : ~ @Equation2443 Fin4 reff114_inst.
Proof. unfold Equation2443. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff114_inst, reff114_op in H. discriminate H. Qed.

Lemma reff114_not2444 : ~ @Equation2444 Fin4 reff114_inst.
Proof. unfold Equation2444. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff114_inst, reff114_op in H. discriminate H. Qed.

Lemma reff114_not2446 : ~ @Equation2446 Fin4 reff114_inst.
Proof. unfold Equation2446. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff114_inst, reff114_op in H. discriminate H. Qed.

Lemma reff114_not2447 : ~ @Equation2447 Fin4 reff114_inst.
Proof. unfold Equation2447. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff114_inst, reff114_op in H. discriminate H. Qed.

Lemma reff114_not2449 : ~ @Equation2449 Fin4 reff114_inst.
Proof. unfold Equation2449. intro H. specialize (H F4_2 F4_1). unfold magma_op, reff114_inst, reff114_op in H. discriminate H. Qed.

Lemma reff114_not2450 : ~ @Equation2450 Fin4 reff114_inst.
Proof. unfold Equation2450. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff114_inst, reff114_op in H. discriminate H. Qed.

Lemma reff114_not2456 : ~ @Equation2456 Fin4 reff114_inst.
Proof. unfold Equation2456. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff114_inst, reff114_op in H. discriminate H. Qed.

Lemma reff114_not2457 : ~ @Equation2457 Fin4 reff114_inst.
Proof. unfold Equation2457. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff114_inst, reff114_op in H. discriminate H. Qed.

Lemma reff114_not2459 : ~ @Equation2459 Fin4 reff114_inst.
Proof. unfold Equation2459. intro H. specialize (H F4_0 F4_3). unfold magma_op, reff114_inst, reff114_op in H. discriminate H. Qed.

Lemma reff114_not2460 : ~ @Equation2460 Fin4 reff114_inst.
Proof. unfold Equation2460. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff114_inst, reff114_op in H. discriminate H. Qed.

Lemma reff114_not2467 : ~ @Equation2467 Fin4 reff114_inst.
Proof. unfold Equation2467. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff114_inst, reff114_op in H. discriminate H. Qed.

Lemma reff114_not2469 : ~ @Equation2469 Fin4 reff114_inst.
Proof. unfold Equation2469. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff114_inst, reff114_op in H. discriminate H. Qed.

Lemma reff114_not2470 : ~ @Equation2470 Fin4 reff114_inst.
Proof. unfold Equation2470. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff114_inst, reff114_op in H. discriminate H. Qed.

Lemma reff114_not2493 : ~ @Equation2493 Fin4 reff114_inst.
Proof. unfold Equation2493. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff114_inst, reff114_op in H. discriminate H. Qed.

Lemma reff114_not2494 : ~ @Equation2494 Fin4 reff114_inst.
Proof. unfold Equation2494. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff114_inst, reff114_op in H. discriminate H. Qed.

Lemma reff114_not2497 : ~ @Equation2497 Fin4 reff114_inst.
Proof. unfold Equation2497. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff114_inst, reff114_op in H. discriminate H. Qed.

Lemma reff114_not2503 : ~ @Equation2503 Fin4 reff114_inst.
Proof. unfold Equation2503. intro H. specialize (H F4_0 F4_3). unfold magma_op, reff114_inst, reff114_op in H. discriminate H. Qed.

Lemma reff114_not2504 : ~ @Equation2504 Fin4 reff114_inst.
Proof. unfold Equation2504. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff114_inst, reff114_op in H. discriminate H. Qed.

Lemma reff114_not2506 : ~ @Equation2506 Fin4 reff114_inst.
Proof. unfold Equation2506. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff114_inst, reff114_op in H. discriminate H. Qed.

Lemma reff114_not2507 : ~ @Equation2507 Fin4 reff114_inst.
Proof. unfold Equation2507. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff114_inst, reff114_op in H. discriminate H. Qed.

Lemma reff114_not2530 : ~ @Equation2530 Fin4 reff114_inst.
Proof. unfold Equation2530. intro H. specialize (H F4_0 F4_3). unfold magma_op, reff114_inst, reff114_op in H. discriminate H. Qed.

Lemma reff114_not2531 : ~ @Equation2531 Fin4 reff114_inst.
Proof. unfold Equation2531. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff114_inst, reff114_op in H. discriminate H. Qed.

Lemma reff114_not2533 : ~ @Equation2533 Fin4 reff114_inst.
Proof. unfold Equation2533. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff114_inst, reff114_op in H. discriminate H. Qed.

Lemma reff114_not2534 : ~ @Equation2534 Fin4 reff114_inst.
Proof. unfold Equation2534. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff114_inst, reff114_op in H. discriminate H. Qed.

Lemma reff114_not2540 : ~ @Equation2540 Fin4 reff114_inst.
Proof. unfold Equation2540. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff114_inst, reff114_op in H. discriminate H. Qed.

Lemma reff114_not2541 : ~ @Equation2541 Fin4 reff114_inst.
Proof. unfold Equation2541. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff114_inst, reff114_op in H. discriminate H. Qed.

Lemma reff114_not2645 : ~ @Equation2645 Fin4 reff114_inst.
Proof. unfold Equation2645. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff114_inst, reff114_op in H. discriminate H. Qed.

Lemma reff114_not2646 : ~ @Equation2646 Fin4 reff114_inst.
Proof. unfold Equation2646. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff114_inst, reff114_op in H. discriminate H. Qed.

Lemma reff114_not2647 : ~ @Equation2647 Fin4 reff114_inst.
Proof. unfold Equation2647. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff114_inst, reff114_op in H. discriminate H. Qed.

Lemma reff114_not2649 : ~ @Equation2649 Fin4 reff114_inst.
Proof. unfold Equation2649. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff114_inst, reff114_op in H. discriminate H. Qed.

Lemma reff114_not2650 : ~ @Equation2650 Fin4 reff114_inst.
Proof. unfold Equation2650. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff114_inst, reff114_op in H. discriminate H. Qed.

Lemma reff114_not2653 : ~ @Equation2653 Fin4 reff114_inst.
Proof. unfold Equation2653. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff114_inst, reff114_op in H. discriminate H. Qed.

Lemma reff114_not2659 : ~ @Equation2659 Fin4 reff114_inst.
Proof. unfold Equation2659. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff114_inst, reff114_op in H. discriminate H. Qed.

Lemma reff114_not2660 : ~ @Equation2660 Fin4 reff114_inst.
Proof. unfold Equation2660. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff114_inst, reff114_op in H. discriminate H. Qed.

Lemma reff114_not2663 : ~ @Equation2663 Fin4 reff114_inst.
Proof. unfold Equation2663. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff114_inst, reff114_op in H. discriminate H. Qed.

Lemma reff114_not2669 : ~ @Equation2669 Fin4 reff114_inst.
Proof. unfold Equation2669. intro H. specialize (H F4_0 F4_3). unfold magma_op, reff114_inst, reff114_op in H. discriminate H. Qed.

Lemma reff114_not2670 : ~ @Equation2670 Fin4 reff114_inst.
Proof. unfold Equation2670. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff114_inst, reff114_op in H. discriminate H. Qed.

Lemma reff114_not2672 : ~ @Equation2672 Fin4 reff114_inst.
Proof. unfold Equation2672. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff114_inst, reff114_op in H. discriminate H. Qed.

Lemma reff114_not2673 : ~ @Equation2673 Fin4 reff114_inst.
Proof. unfold Equation2673. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff114_inst, reff114_op in H. discriminate H. Qed.

Lemma reff114_not2696 : ~ @Equation2696 Fin4 reff114_inst.
Proof. unfold Equation2696. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff114_inst, reff114_op in H. discriminate H. Qed.

Lemma reff114_not2697 : ~ @Equation2697 Fin4 reff114_inst.
Proof. unfold Equation2697. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff114_inst, reff114_op in H. discriminate H. Qed.

Lemma reff114_not2699 : ~ @Equation2699 Fin4 reff114_inst.
Proof. unfold Equation2699. intro H. specialize (H F4_0 F4_3). unfold magma_op, reff114_inst, reff114_op in H. discriminate H. Qed.

Lemma reff114_not2700 : ~ @Equation2700 Fin4 reff114_inst.
Proof. unfold Equation2700. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff114_inst, reff114_op in H. discriminate H. Qed.

Lemma reff114_not2707 : ~ @Equation2707 Fin4 reff114_inst.
Proof. unfold Equation2707. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff114_inst, reff114_op in H. discriminate H. Qed.

Lemma reff114_not2709 : ~ @Equation2709 Fin4 reff114_inst.
Proof. unfold Equation2709. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff114_inst, reff114_op in H. discriminate H. Qed.

Lemma reff114_not2710 : ~ @Equation2710 Fin4 reff114_inst.
Proof. unfold Equation2710. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff114_inst, reff114_op in H. discriminate H. Qed.

Lemma reff114_not2734 : ~ @Equation2734 Fin4 reff114_inst.
Proof. unfold Equation2734. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff114_inst, reff114_op in H. discriminate H. Qed.

Lemma reff114_not2736 : ~ @Equation2736 Fin4 reff114_inst.
Proof. unfold Equation2736. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff114_inst, reff114_op in H. discriminate H. Qed.

Lemma reff114_not2737 : ~ @Equation2737 Fin4 reff114_inst.
Proof. unfold Equation2737. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff114_inst, reff114_op in H. discriminate H. Qed.

Lemma reff114_not2743 : ~ @Equation2743 Fin4 reff114_inst.
Proof. unfold Equation2743. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff114_inst, reff114_op in H. discriminate H. Qed.

Lemma reff114_not2744 : ~ @Equation2744 Fin4 reff114_inst.
Proof. unfold Equation2744. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff114_inst, reff114_op in H. discriminate H. Qed.

Lemma reff114_not2847 : ~ @Equation2847 Fin4 reff114_inst.
Proof. unfold Equation2847. intro H. specialize (H F4_1). unfold magma_op, reff114_inst, reff114_op in H. discriminate H. Qed.

Lemma reff114_not3051 : ~ @Equation3051 Fin4 reff114_inst.
Proof. unfold Equation3051. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff114_inst, reff114_op in H. discriminate H. Qed.

Lemma reff114_not3052 : ~ @Equation3052 Fin4 reff114_inst.
Proof. unfold Equation3052. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff114_inst, reff114_op in H. discriminate H. Qed.

Lemma reff114_not3053 : ~ @Equation3053 Fin4 reff114_inst.
Proof. unfold Equation3053. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff114_inst, reff114_op in H. discriminate H. Qed.

Lemma reff114_not3055 : ~ @Equation3055 Fin4 reff114_inst.
Proof. unfold Equation3055. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff114_inst, reff114_op in H. discriminate H. Qed.

Lemma reff114_not3056 : ~ @Equation3056 Fin4 reff114_inst.
Proof. unfold Equation3056. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff114_inst, reff114_op in H. discriminate H. Qed.

Lemma reff114_not3059 : ~ @Equation3059 Fin4 reff114_inst.
Proof. unfold Equation3059. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff114_inst, reff114_op in H. discriminate H. Qed.

Lemma reff114_not3065 : ~ @Equation3065 Fin4 reff114_inst.
Proof. unfold Equation3065. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff114_inst, reff114_op in H. discriminate H. Qed.

Lemma reff114_not3066 : ~ @Equation3066 Fin4 reff114_inst.
Proof. unfold Equation3066. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff114_inst, reff114_op in H. discriminate H. Qed.

Lemma reff114_not3068 : ~ @Equation3068 Fin4 reff114_inst.
Proof. unfold Equation3068. intro H. specialize (H F4_0 F4_3). unfold magma_op, reff114_inst, reff114_op in H. discriminate H. Qed.

Lemma reff114_not3069 : ~ @Equation3069 Fin4 reff114_inst.
Proof. unfold Equation3069. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff114_inst, reff114_op in H. discriminate H. Qed.

Lemma reff114_not3075 : ~ @Equation3075 Fin4 reff114_inst.
Proof. unfold Equation3075. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff114_inst, reff114_op in H. discriminate H. Qed.

Lemma reff114_not3076 : ~ @Equation3076 Fin4 reff114_inst.
Proof. unfold Equation3076. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff114_inst, reff114_op in H. discriminate H. Qed.

Lemma reff114_not3078 : ~ @Equation3078 Fin4 reff114_inst.
Proof. unfold Equation3078. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff114_inst, reff114_op in H. discriminate H. Qed.

Lemma reff114_not3079 : ~ @Equation3079 Fin4 reff114_inst.
Proof. unfold Equation3079. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff114_inst, reff114_op in H. discriminate H. Qed.

Lemma reff114_not3102 : ~ @Equation3102 Fin4 reff114_inst.
Proof. unfold Equation3102. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff114_inst, reff114_op in H. discriminate H. Qed.

Lemma reff114_not3103 : ~ @Equation3103 Fin4 reff114_inst.
Proof. unfold Equation3103. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff114_inst, reff114_op in H. discriminate H. Qed.

Lemma reff114_not3105 : ~ @Equation3105 Fin4 reff114_inst.
Proof. unfold Equation3105. intro H. specialize (H F4_0 F4_3). unfold magma_op, reff114_inst, reff114_op in H. discriminate H. Qed.

Lemma reff114_not3106 : ~ @Equation3106 Fin4 reff114_inst.
Proof. unfold Equation3106. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff114_inst, reff114_op in H. discriminate H. Qed.

Lemma reff114_not3112 : ~ @Equation3112 Fin4 reff114_inst.
Proof. unfold Equation3112. intro H. specialize (H F4_0 F4_3). unfold magma_op, reff114_inst, reff114_op in H. discriminate H. Qed.

Lemma reff114_not3113 : ~ @Equation3113 Fin4 reff114_inst.
Proof. unfold Equation3113. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff114_inst, reff114_op in H. discriminate H. Qed.

Lemma reff114_not3115 : ~ @Equation3115 Fin4 reff114_inst.
Proof. unfold Equation3115. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff114_inst, reff114_op in H. discriminate H. Qed.

Lemma reff114_not3116 : ~ @Equation3116 Fin4 reff114_inst.
Proof. unfold Equation3116. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff114_inst, reff114_op in H. discriminate H. Qed.

Lemma reff114_not3140 : ~ @Equation3140 Fin4 reff114_inst.
Proof. unfold Equation3140. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff114_inst, reff114_op in H. discriminate H. Qed.

Lemma reff114_not3142 : ~ @Equation3142 Fin4 reff114_inst.
Proof. unfold Equation3142. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff114_inst, reff114_op in H. discriminate H. Qed.

Lemma reff114_not3143 : ~ @Equation3143 Fin4 reff114_inst.
Proof. unfold Equation3143. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff114_inst, reff114_op in H. discriminate H. Qed.

Lemma reff114_not3149 : ~ @Equation3149 Fin4 reff114_inst.
Proof. unfold Equation3149. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff114_inst, reff114_op in H. discriminate H. Qed.

Lemma reff114_not3150 : ~ @Equation3150 Fin4 reff114_inst.
Proof. unfold Equation3150. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff114_inst, reff114_op in H. discriminate H. Qed.

Lemma reff114_not3253 : ~ @Equation3253 Fin4 reff114_inst.
Proof. unfold Equation3253. intro H. specialize (H F4_3). unfold magma_op, reff114_inst, reff114_op in H. discriminate H. Qed.

Lemma reff114_not3457 : ~ @Equation3457 Fin4 reff114_inst.
Proof. unfold Equation3457. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff114_inst, reff114_op in H. discriminate H. Qed.

Lemma reff114_not3458 : ~ @Equation3458 Fin4 reff114_inst.
Proof. unfold Equation3458. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff114_inst, reff114_op in H. discriminate H. Qed.

Lemma reff114_not3459 : ~ @Equation3459 Fin4 reff114_inst.
Proof. unfold Equation3459. intro H. specialize (H F4_2 F4_1). unfold magma_op, reff114_inst, reff114_op in H. discriminate H. Qed.

Lemma reff114_not3461 : ~ @Equation3461 Fin4 reff114_inst.
Proof. unfold Equation3461. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff114_inst, reff114_op in H. discriminate H. Qed.

Lemma reff114_not3462 : ~ @Equation3462 Fin4 reff114_inst.
Proof. unfold Equation3462. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff114_inst, reff114_op in H. discriminate H. Qed.

Lemma reff114_not3465 : ~ @Equation3465 Fin4 reff114_inst.
Proof. unfold Equation3465. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff114_inst, reff114_op in H. discriminate H. Qed.

Lemma reff114_not3474 : ~ @Equation3474 Fin4 reff114_inst.
Proof. unfold Equation3474. intro H. specialize (H F4_0 F4_3). unfold magma_op, reff114_inst, reff114_op in H. discriminate H. Qed.

Lemma reff114_not3475 : ~ @Equation3475 Fin4 reff114_inst.
Proof. unfold Equation3475. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff114_inst, reff114_op in H. discriminate H. Qed.

Lemma reff114_not3481 : ~ @Equation3481 Fin4 reff114_inst.
Proof. unfold Equation3481. intro H. specialize (H F4_0 F4_3). unfold magma_op, reff114_inst, reff114_op in H. discriminate H. Qed.

Lemma reff114_not3482 : ~ @Equation3482 Fin4 reff114_inst.
Proof. unfold Equation3482. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff114_inst, reff114_op in H. discriminate H. Qed.

Lemma reff114_not3484 : ~ @Equation3484 Fin4 reff114_inst.
Proof. unfold Equation3484. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff114_inst, reff114_op in H. discriminate H. Qed.

Lemma reff114_not3511 : ~ @Equation3511 Fin4 reff114_inst.
Proof. unfold Equation3511. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff114_inst, reff114_op in H. discriminate H. Qed.

Lemma reff114_not3512 : ~ @Equation3512 Fin4 reff114_inst.
Proof. unfold Equation3512. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff114_inst, reff114_op in H. discriminate H. Qed.

Lemma reff114_not3518 : ~ @Equation3518 Fin4 reff114_inst.
Proof. unfold Equation3518. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff114_inst, reff114_op in H. discriminate H. Qed.

Lemma reff114_not3519 : ~ @Equation3519 Fin4 reff114_inst.
Proof. unfold Equation3519. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff114_inst, reff114_op in H. discriminate H. Qed.

Lemma reff114_not3521 : ~ @Equation3521 Fin4 reff114_inst.
Proof. unfold Equation3521. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff114_inst, reff114_op in H. discriminate H. Qed.

Lemma reff114_not3545 : ~ @Equation3545 Fin4 reff114_inst.
Proof. unfold Equation3545. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff114_inst, reff114_op in H. discriminate H. Qed.

Lemma reff114_not3546 : ~ @Equation3546 Fin4 reff114_inst.
Proof. unfold Equation3546. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff114_inst, reff114_op in H. discriminate H. Qed.

Lemma reff114_not3548 : ~ @Equation3548 Fin4 reff114_inst.
Proof. unfold Equation3548. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff114_inst, reff114_op in H. discriminate H. Qed.

Lemma reff114_not3549 : ~ @Equation3549 Fin4 reff114_inst.
Proof. unfold Equation3549. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff114_inst, reff114_op in H. discriminate H. Qed.

Lemma reff114_not3555 : ~ @Equation3555 Fin4 reff114_inst.
Proof. unfold Equation3555. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff114_inst, reff114_op in H. discriminate H. Qed.

Lemma reff114_not3556 : ~ @Equation3556 Fin4 reff114_inst.
Proof. unfold Equation3556. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff114_inst, reff114_op in H. discriminate H. Qed.

Lemma reff114_not3558 : ~ @Equation3558 Fin4 reff114_inst.
Proof. unfold Equation3558. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff114_inst, reff114_op in H. discriminate H. Qed.

Lemma reff114_not3660 : ~ @Equation3660 Fin4 reff114_inst.
Proof. unfold Equation3660. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff114_inst, reff114_op in H. discriminate H. Qed.

Lemma reff114_not3661 : ~ @Equation3661 Fin4 reff114_inst.
Proof. unfold Equation3661. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff114_inst, reff114_op in H. discriminate H. Qed.

Lemma reff114_not3664 : ~ @Equation3664 Fin4 reff114_inst.
Proof. unfold Equation3664. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff114_inst, reff114_op in H. discriminate H. Qed.

Lemma reff114_not3667 : ~ @Equation3667 Fin4 reff114_inst.
Proof. unfold Equation3667. intro H. specialize (H F4_0 F4_3). unfold magma_op, reff114_inst, reff114_op in H. discriminate H. Qed.

Lemma reff114_not3668 : ~ @Equation3668 Fin4 reff114_inst.
Proof. unfold Equation3668. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff114_inst, reff114_op in H. discriminate H. Qed.

Lemma reff114_not3674 : ~ @Equation3674 Fin4 reff114_inst.
Proof. unfold Equation3674. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff114_inst, reff114_op in H. discriminate H. Qed.

Lemma reff114_not3675 : ~ @Equation3675 Fin4 reff114_inst.
Proof. unfold Equation3675. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff114_inst, reff114_op in H. discriminate H. Qed.

Lemma reff114_not3678 : ~ @Equation3678 Fin4 reff114_inst.
Proof. unfold Equation3678. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff114_inst, reff114_op in H. discriminate H. Qed.

Lemma reff114_not3685 : ~ @Equation3685 Fin4 reff114_inst.
Proof. unfold Equation3685. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff114_inst, reff114_op in H. discriminate H. Qed.

Lemma reff114_not3687 : ~ @Equation3687 Fin4 reff114_inst.
Proof. unfold Equation3687. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff114_inst, reff114_op in H. discriminate H. Qed.

Lemma reff114_not3714 : ~ @Equation3714 Fin4 reff114_inst.
Proof. unfold Equation3714. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff114_inst, reff114_op in H. discriminate H. Qed.

Lemma reff114_not3721 : ~ @Equation3721 Fin4 reff114_inst.
Proof. unfold Equation3721. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff114_inst, reff114_op in H. discriminate H. Qed.

Lemma reff114_not3722 : ~ @Equation3722 Fin4 reff114_inst.
Proof. unfold Equation3722. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff114_inst, reff114_op in H. discriminate H. Qed.

Lemma reff114_not3724 : ~ @Equation3724 Fin4 reff114_inst.
Proof. unfold Equation3724. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff114_inst, reff114_op in H. discriminate H. Qed.

Lemma reff114_not3725 : ~ @Equation3725 Fin4 reff114_inst.
Proof. unfold Equation3725. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff114_inst, reff114_op in H. discriminate H. Qed.

Lemma reff114_not3748 : ~ @Equation3748 Fin4 reff114_inst.
Proof. unfold Equation3748. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff114_inst, reff114_op in H. discriminate H. Qed.

Lemma reff114_not3749 : ~ @Equation3749 Fin4 reff114_inst.
Proof. unfold Equation3749. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff114_inst, reff114_op in H. discriminate H. Qed.

Lemma reff114_not3751 : ~ @Equation3751 Fin4 reff114_inst.
Proof. unfold Equation3751. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff114_inst, reff114_op in H. discriminate H. Qed.

Lemma reff114_not3752 : ~ @Equation3752 Fin4 reff114_inst.
Proof. unfold Equation3752. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff114_inst, reff114_op in H. discriminate H. Qed.

Lemma reff114_not3761 : ~ @Equation3761 Fin4 reff114_inst.
Proof. unfold Equation3761. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff114_inst, reff114_op in H. discriminate H. Qed.

Lemma reff114_not3862 : ~ @Equation3862 Fin4 reff114_inst.
Proof. unfold Equation3862. intro H. specialize (H F4_1). unfold magma_op, reff114_inst, reff114_op in H. discriminate H. Qed.

Lemma reff114_not4066 : ~ @Equation4066 Fin4 reff114_inst.
Proof. unfold Equation4066. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff114_inst, reff114_op in H. discriminate H. Qed.

Lemma reff114_not4067 : ~ @Equation4067 Fin4 reff114_inst.
Proof. unfold Equation4067. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff114_inst, reff114_op in H. discriminate H. Qed.

Lemma reff114_not4070 : ~ @Equation4070 Fin4 reff114_inst.
Proof. unfold Equation4070. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff114_inst, reff114_op in H. discriminate H. Qed.

Lemma reff114_not4071 : ~ @Equation4071 Fin4 reff114_inst.
Proof. unfold Equation4071. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff114_inst, reff114_op in H. discriminate H. Qed.

Lemma reff114_not4073 : ~ @Equation4073 Fin4 reff114_inst.
Proof. unfold Equation4073. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff114_inst, reff114_op in H. discriminate H. Qed.

Lemma reff114_not4074 : ~ @Equation4074 Fin4 reff114_inst.
Proof. unfold Equation4074. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff114_inst, reff114_op in H. discriminate H. Qed.

Lemma reff114_not4080 : ~ @Equation4080 Fin4 reff114_inst.
Proof. unfold Equation4080. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff114_inst, reff114_op in H. discriminate H. Qed.

Lemma reff114_not4081 : ~ @Equation4081 Fin4 reff114_inst.
Proof. unfold Equation4081. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff114_inst, reff114_op in H. discriminate H. Qed.

Lemma reff114_not4083 : ~ @Equation4083 Fin4 reff114_inst.
Proof. unfold Equation4083. intro H. specialize (H F4_0 F4_3). unfold magma_op, reff114_inst, reff114_op in H. discriminate H. Qed.

Lemma reff114_not4084 : ~ @Equation4084 Fin4 reff114_inst.
Proof. unfold Equation4084. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff114_inst, reff114_op in H. discriminate H. Qed.

Lemma reff114_not4091 : ~ @Equation4091 Fin4 reff114_inst.
Proof. unfold Equation4091. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff114_inst, reff114_op in H. discriminate H. Qed.

Lemma reff114_not4093 : ~ @Equation4093 Fin4 reff114_inst.
Proof. unfold Equation4093. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff114_inst, reff114_op in H. discriminate H. Qed.

Lemma reff114_not4120 : ~ @Equation4120 Fin4 reff114_inst.
Proof. unfold Equation4120. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff114_inst, reff114_op in H. discriminate H. Qed.

Lemma reff114_not4121 : ~ @Equation4121 Fin4 reff114_inst.
Proof. unfold Equation4121. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff114_inst, reff114_op in H. discriminate H. Qed.

Lemma reff114_not4127 : ~ @Equation4127 Fin4 reff114_inst.
Proof. unfold Equation4127. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff114_inst, reff114_op in H. discriminate H. Qed.

Lemma reff114_not4128 : ~ @Equation4128 Fin4 reff114_inst.
Proof. unfold Equation4128. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff114_inst, reff114_op in H. discriminate H. Qed.

Lemma reff114_not4130 : ~ @Equation4130 Fin4 reff114_inst.
Proof. unfold Equation4130. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff114_inst, reff114_op in H. discriminate H. Qed.

Lemma reff114_not4155 : ~ @Equation4155 Fin4 reff114_inst.
Proof. unfold Equation4155. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff114_inst, reff114_op in H. discriminate H. Qed.

Lemma reff114_not4157 : ~ @Equation4157 Fin4 reff114_inst.
Proof. unfold Equation4157. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff114_inst, reff114_op in H. discriminate H. Qed.

Lemma reff114_not4158 : ~ @Equation4158 Fin4 reff114_inst.
Proof. unfold Equation4158. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff114_inst, reff114_op in H. discriminate H. Qed.

Lemma reff114_not4164 : ~ @Equation4164 Fin4 reff114_inst.
Proof. unfold Equation4164. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff114_inst, reff114_op in H. discriminate H. Qed.

Lemma reff114_not4167 : ~ @Equation4167 Fin4 reff114_inst.
Proof. unfold Equation4167. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff114_inst, reff114_op in H. discriminate H. Qed.

Lemma reff114_not4268 : ~ @Equation4268 Fin4 reff114_inst.
Proof. unfold Equation4268. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff114_inst, reff114_op in H. discriminate H. Qed.

Lemma reff114_not4269 : ~ @Equation4269 Fin4 reff114_inst.
Proof. unfold Equation4269. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff114_inst, reff114_op in H. discriminate H. Qed.

Lemma reff114_not4272 : ~ @Equation4272 Fin4 reff114_inst.
Proof. unfold Equation4272. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff114_inst, reff114_op in H. discriminate H. Qed.

Lemma reff114_not4273 : ~ @Equation4273 Fin4 reff114_inst.
Proof. unfold Equation4273. intro H. specialize (H F4_1 F4_2). unfold magma_op, reff114_inst, reff114_op in H. discriminate H. Qed.

Lemma reff114_not4275 : ~ @Equation4275 Fin4 reff114_inst.
Proof. unfold Equation4275. intro H. specialize (H F4_0 F4_3). unfold magma_op, reff114_inst, reff114_op in H. discriminate H. Qed.

Lemma reff114_not4276 : ~ @Equation4276 Fin4 reff114_inst.
Proof. unfold Equation4276. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff114_inst, reff114_op in H. discriminate H. Qed.

Lemma reff114_not4283 : ~ @Equation4283 Fin4 reff114_inst.
Proof. unfold Equation4283. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff114_inst, reff114_op in H. discriminate H. Qed.

Lemma reff114_not4284 : ~ @Equation4284 Fin4 reff114_inst.
Proof. unfold Equation4284. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff114_inst, reff114_op in H. discriminate H. Qed.

Lemma reff114_not4290 : ~ @Equation4290 Fin4 reff114_inst.
Proof. unfold Equation4290. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff114_inst, reff114_op in H. discriminate H. Qed.

Lemma reff114_not4291 : ~ @Equation4291 Fin4 reff114_inst.
Proof. unfold Equation4291. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff114_inst, reff114_op in H. discriminate H. Qed.

Lemma reff114_not4293 : ~ @Equation4293 Fin4 reff114_inst.
Proof. unfold Equation4293. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff114_inst, reff114_op in H. discriminate H. Qed.

Lemma reff114_not4314 : ~ @Equation4314 Fin4 reff114_inst.
Proof. unfold Equation4314. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff114_inst, reff114_op in H. discriminate H. Qed.

Lemma reff114_not4320 : ~ @Equation4320 Fin4 reff114_inst.
Proof. unfold Equation4320. intro H. specialize (H F4_1 F4_2). unfold magma_op, reff114_inst, reff114_op in H. discriminate H. Qed.

Lemma reff114_not4321 : ~ @Equation4321 Fin4 reff114_inst.
Proof. unfold Equation4321. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff114_inst, reff114_op in H. discriminate H. Qed.

Lemma reff114_not4343 : ~ @Equation4343 Fin4 reff114_inst.
Proof. unfold Equation4343. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff114_inst, reff114_op in H. discriminate H. Qed.

Lemma reff114_not4380 : ~ @Equation4380 Fin4 reff114_inst.
Proof. unfold Equation4380. intro H. specialize (H F4_1). unfold magma_op, reff114_inst, reff114_op in H. discriminate H. Qed.

Lemma reff114_not4583 : ~ @Equation4583 Fin4 reff114_inst.
Proof. unfold Equation4583. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff114_inst, reff114_op in H. discriminate H. Qed.

Lemma reff114_not4584 : ~ @Equation4584 Fin4 reff114_inst.
Proof. unfold Equation4584. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff114_inst, reff114_op in H. discriminate H. Qed.

Lemma reff114_not4585 : ~ @Equation4585 Fin4 reff114_inst.
Proof. unfold Equation4585. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff114_inst, reff114_op in H. discriminate H. Qed.

Lemma reff114_not4587 : ~ @Equation4587 Fin4 reff114_inst.
Proof. unfold Equation4587. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff114_inst, reff114_op in H. discriminate H. Qed.

Lemma reff114_not4588 : ~ @Equation4588 Fin4 reff114_inst.
Proof. unfold Equation4588. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff114_inst, reff114_op in H. discriminate H. Qed.

Lemma reff114_not4591 : ~ @Equation4591 Fin4 reff114_inst.
Proof. unfold Equation4591. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff114_inst, reff114_op in H. discriminate H. Qed.

Lemma reff114_not4598 : ~ @Equation4598 Fin4 reff114_inst.
Proof. unfold Equation4598. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff114_inst, reff114_op in H. discriminate H. Qed.

Lemma reff114_not4599 : ~ @Equation4599 Fin4 reff114_inst.
Proof. unfold Equation4599. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff114_inst, reff114_op in H. discriminate H. Qed.

Lemma reff114_not4605 : ~ @Equation4605 Fin4 reff114_inst.
Proof. unfold Equation4605. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff114_inst, reff114_op in H. discriminate H. Qed.

Lemma reff114_not4606 : ~ @Equation4606 Fin4 reff114_inst.
Proof. unfold Equation4606. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff114_inst, reff114_op in H. discriminate H. Qed.

Lemma reff114_not4608 : ~ @Equation4608 Fin4 reff114_inst.
Proof. unfold Equation4608. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff114_inst, reff114_op in H. discriminate H. Qed.

Lemma reff114_not4629 : ~ @Equation4629 Fin4 reff114_inst.
Proof. unfold Equation4629. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff114_inst, reff114_op in H. discriminate H. Qed.

Lemma reff114_not4635 : ~ @Equation4635 Fin4 reff114_inst.
Proof. unfold Equation4635. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff114_inst, reff114_op in H. discriminate H. Qed.

Lemma reff114_not4636 : ~ @Equation4636 Fin4 reff114_inst.
Proof. unfold Equation4636. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff114_inst, reff114_op in H. discriminate H. Qed.

Lemma reff114_not4658 : ~ @Equation4658 Fin4 reff114_inst.
Proof. unfold Equation4658. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff114_inst, reff114_op in H. discriminate H. Qed.

(** ---- reff116 (Fin3) ---- *)

Definition reff116_op (x y : Fin3) : Fin3 :=
  match x, y with
  | F3_0, F3_0 => F3_0 | F3_0, F3_1 => F3_2 | F3_0, F3_2 => F3_0
  | F3_1, F3_0 => F3_2 | F3_1, F3_1 => F3_2 | F3_1, F3_2 => F3_1
  | F3_2, F3_0 => F3_2 | F3_2, F3_1 => F3_0 | F3_2, F3_2 => F3_0
  end.

#[local] Instance reff116_inst : Magma Fin3 := {| magma_op := reff116_op |}.

Lemma reff116_sat8 : @Equation8 Fin3 reff116_inst.
Proof. unfold Equation8, magma_op, reff116_inst, reff116_op. intros x. destruct x; reflexivity. Qed.

Lemma reff116_sat1035 : @Equation1035 Fin3 reff116_inst.
Proof. unfold Equation1035, magma_op, reff116_inst, reff116_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff116_sat1038 : @Equation1038 Fin3 reff116_inst.
Proof. unfold Equation1038, magma_op, reff116_inst, reff116_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff116_sat1251 : @Equation1251 Fin3 reff116_inst.
Proof. unfold Equation1251, magma_op, reff116_inst, reff116_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff116_sat3318 : @Equation3318 Fin3 reff116_inst.
Proof. unfold Equation3318, magma_op, reff116_inst, reff116_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff116_sat4093 : @Equation4093 Fin3 reff116_inst.
Proof. unfold Equation4093, magma_op, reff116_inst, reff116_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff116_sat4131 : @Equation4131 Fin3 reff116_inst.
Proof. unfold Equation4131, magma_op, reff116_inst, reff116_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff116_sat4591 : @Equation4591 Fin3 reff116_inst.
Proof. unfold Equation4591, magma_op, reff116_inst, reff116_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff116_not47 : ~ @Equation47 Fin3 reff116_inst.
Proof. unfold Equation47. intro H. specialize (H F3_1). unfold magma_op, reff116_inst, reff116_op in H. discriminate H. Qed.

Lemma reff116_not99 : ~ @Equation99 Fin3 reff116_inst.
Proof. unfold Equation99. intro H. specialize (H F3_1). unfold magma_op, reff116_inst, reff116_op in H. discriminate H. Qed.

Lemma reff116_not151 : ~ @Equation151 Fin3 reff116_inst.
Proof. unfold Equation151. intro H. specialize (H F3_1). unfold magma_op, reff116_inst, reff116_op in H. discriminate H. Qed.

Lemma reff116_not203 : ~ @Equation203 Fin3 reff116_inst.
Proof. unfold Equation203. intro H. specialize (H F3_1). unfold magma_op, reff116_inst, reff116_op in H. discriminate H. Qed.

Lemma reff116_not255 : ~ @Equation255 Fin3 reff116_inst.
Proof. unfold Equation255. intro H. specialize (H F3_1). unfold magma_op, reff116_inst, reff116_op in H. discriminate H. Qed.

Lemma reff116_not307 : ~ @Equation307 Fin3 reff116_inst.
Proof. unfold Equation307. intro H. specialize (H F3_1). unfold magma_op, reff116_inst, reff116_op in H. discriminate H. Qed.

Lemma reff116_not359 : ~ @Equation359 Fin3 reff116_inst.
Proof. unfold Equation359. intro H. specialize (H F3_1). unfold magma_op, reff116_inst, reff116_op in H. discriminate H. Qed.

Lemma reff116_not412 : ~ @Equation412 Fin3 reff116_inst.
Proof. unfold Equation412. intro H. specialize (H F3_1 F3_2). unfold magma_op, reff116_inst, reff116_op in H. discriminate H. Qed.

Lemma reff116_not413 : ~ @Equation413 Fin3 reff116_inst.
Proof. unfold Equation413. intro H. specialize (H F3_1 F3_2). unfold magma_op, reff116_inst, reff116_op in H. discriminate H. Qed.

Lemma reff116_not414 : ~ @Equation414 Fin3 reff116_inst.
Proof. unfold Equation414. intro H. specialize (H F3_1 F3_0). unfold magma_op, reff116_inst, reff116_op in H. discriminate H. Qed.

Lemma reff116_not416 : ~ @Equation416 Fin3 reff116_inst.
Proof. unfold Equation416. intro H. specialize (H F3_2 F3_0). unfold magma_op, reff116_inst, reff116_op in H. discriminate H. Qed.

Lemma reff116_not417 : ~ @Equation417 Fin3 reff116_inst.
Proof. unfold Equation417. intro H. specialize (H F3_2 F3_0). unfold magma_op, reff116_inst, reff116_op in H. discriminate H. Qed.

Lemma reff116_not419 : ~ @Equation419 Fin3 reff116_inst.
Proof. unfold Equation419. intro H. specialize (H F3_1 F3_2). unfold magma_op, reff116_inst, reff116_op in H. discriminate H. Qed.

Lemma reff116_not420 : ~ @Equation420 Fin3 reff116_inst.
Proof. unfold Equation420. intro H. specialize (H F3_1 F3_2). unfold magma_op, reff116_inst, reff116_op in H. discriminate H. Qed.

Lemma reff116_not426 : ~ @Equation426 Fin3 reff116_inst.
Proof. unfold Equation426. intro H. specialize (H F3_1 F3_2). unfold magma_op, reff116_inst, reff116_op in H. discriminate H. Qed.

Lemma reff116_not427 : ~ @Equation427 Fin3 reff116_inst.
Proof. unfold Equation427. intro H. specialize (H F3_1 F3_2). unfold magma_op, reff116_inst, reff116_op in H. discriminate H. Qed.

Lemma reff116_not429 : ~ @Equation429 Fin3 reff116_inst.
Proof. unfold Equation429. intro H. specialize (H F3_1 F3_2). unfold magma_op, reff116_inst, reff116_op in H. discriminate H. Qed.

Lemma reff116_not430 : ~ @Equation430 Fin3 reff116_inst.
Proof. unfold Equation430. intro H. specialize (H F3_1 F3_0). unfold magma_op, reff116_inst, reff116_op in H. discriminate H. Qed.

Lemma reff116_not436 : ~ @Equation436 Fin3 reff116_inst.
Proof. unfold Equation436. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff116_inst, reff116_op in H. discriminate H. Qed.

Lemma reff116_not437 : ~ @Equation437 Fin3 reff116_inst.
Proof. unfold Equation437. intro H. specialize (H F3_1 F3_0). unfold magma_op, reff116_inst, reff116_op in H. discriminate H. Qed.

Lemma reff116_not439 : ~ @Equation439 Fin3 reff116_inst.
Proof. unfold Equation439. intro H. specialize (H F3_1 F3_0). unfold magma_op, reff116_inst, reff116_op in H. discriminate H. Qed.

Lemma reff116_not440 : ~ @Equation440 Fin3 reff116_inst.
Proof. unfold Equation440. intro H. specialize (H F3_1 F3_0). unfold magma_op, reff116_inst, reff116_op in H. discriminate H. Qed.

Lemma reff116_not463 : ~ @Equation463 Fin3 reff116_inst.
Proof. unfold Equation463. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff116_inst, reff116_op in H. discriminate H. Qed.

Lemma reff116_not464 : ~ @Equation464 Fin3 reff116_inst.
Proof. unfold Equation464. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff116_inst, reff116_op in H. discriminate H. Qed.

Lemma reff116_not466 : ~ @Equation466 Fin3 reff116_inst.
Proof. unfold Equation466. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff116_inst, reff116_op in H. discriminate H. Qed.

Lemma reff116_not467 : ~ @Equation467 Fin3 reff116_inst.
Proof. unfold Equation467. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff116_inst, reff116_op in H. discriminate H. Qed.

Lemma reff116_not473 : ~ @Equation473 Fin3 reff116_inst.
Proof. unfold Equation473. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff116_inst, reff116_op in H. discriminate H. Qed.

Lemma reff116_not474 : ~ @Equation474 Fin3 reff116_inst.
Proof. unfold Equation474. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff116_inst, reff116_op in H. discriminate H. Qed.

Lemma reff116_not476 : ~ @Equation476 Fin3 reff116_inst.
Proof. unfold Equation476. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff116_inst, reff116_op in H. discriminate H. Qed.

Lemma reff116_not477 : ~ @Equation477 Fin3 reff116_inst.
Proof. unfold Equation477. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff116_inst, reff116_op in H. discriminate H. Qed.

Lemma reff116_not500 : ~ @Equation500 Fin3 reff116_inst.
Proof. unfold Equation500. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff116_inst, reff116_op in H. discriminate H. Qed.

Lemma reff116_not501 : ~ @Equation501 Fin3 reff116_inst.
Proof. unfold Equation501. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff116_inst, reff116_op in H. discriminate H. Qed.

Lemma reff116_not503 : ~ @Equation503 Fin3 reff116_inst.
Proof. unfold Equation503. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff116_inst, reff116_op in H. discriminate H. Qed.

Lemma reff116_not504 : ~ @Equation504 Fin3 reff116_inst.
Proof. unfold Equation504. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff116_inst, reff116_op in H. discriminate H. Qed.

Lemma reff116_not510 : ~ @Equation510 Fin3 reff116_inst.
Proof. unfold Equation510. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff116_inst, reff116_op in H. discriminate H. Qed.

Lemma reff116_not511 : ~ @Equation511 Fin3 reff116_inst.
Proof. unfold Equation511. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff116_inst, reff116_op in H. discriminate H. Qed.

Lemma reff116_not513 : ~ @Equation513 Fin3 reff116_inst.
Proof. unfold Equation513. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff116_inst, reff116_op in H. discriminate H. Qed.

Lemma reff116_not614 : ~ @Equation614 Fin3 reff116_inst.
Proof. unfold Equation614. intro H. specialize (H F3_2). unfold magma_op, reff116_inst, reff116_op in H. discriminate H. Qed.

Lemma reff116_not817 : ~ @Equation817 Fin3 reff116_inst.
Proof. unfold Equation817. intro H. specialize (H F3_1). unfold magma_op, reff116_inst, reff116_op in H. discriminate H. Qed.

Lemma reff116_not1021 : ~ @Equation1021 Fin3 reff116_inst.
Proof. unfold Equation1021. intro H. specialize (H F3_1 F3_2). unfold magma_op, reff116_inst, reff116_op in H. discriminate H. Qed.

Lemma reff116_not1022 : ~ @Equation1022 Fin3 reff116_inst.
Proof. unfold Equation1022. intro H. specialize (H F3_1 F3_2). unfold magma_op, reff116_inst, reff116_op in H. discriminate H. Qed.

Lemma reff116_not1023 : ~ @Equation1023 Fin3 reff116_inst.
Proof. unfold Equation1023. intro H. specialize (H F3_1 F3_2). unfold magma_op, reff116_inst, reff116_op in H. discriminate H. Qed.

Lemma reff116_not1025 : ~ @Equation1025 Fin3 reff116_inst.
Proof. unfold Equation1025. intro H. specialize (H F3_1 F3_2). unfold magma_op, reff116_inst, reff116_op in H. discriminate H. Qed.

Lemma reff116_not1026 : ~ @Equation1026 Fin3 reff116_inst.
Proof. unfold Equation1026. intro H. specialize (H F3_1 F3_2). unfold magma_op, reff116_inst, reff116_op in H. discriminate H. Qed.

Lemma reff116_not1028 : ~ @Equation1028 Fin3 reff116_inst.
Proof. unfold Equation1028. intro H. specialize (H F3_1 F3_0). unfold magma_op, reff116_inst, reff116_op in H. discriminate H. Qed.

Lemma reff116_not1029 : ~ @Equation1029 Fin3 reff116_inst.
Proof. unfold Equation1029. intro H. specialize (H F3_1 F3_2). unfold magma_op, reff116_inst, reff116_op in H. discriminate H. Qed.

Lemma reff116_not1036 : ~ @Equation1036 Fin3 reff116_inst.
Proof. unfold Equation1036. intro H. specialize (H F3_1 F3_0). unfold magma_op, reff116_inst, reff116_op in H. discriminate H. Qed.

Lemma reff116_not1039 : ~ @Equation1039 Fin3 reff116_inst.
Proof. unfold Equation1039. intro H. specialize (H F3_1 F3_0). unfold magma_op, reff116_inst, reff116_op in H. discriminate H. Qed.

Lemma reff116_not1045 : ~ @Equation1045 Fin3 reff116_inst.
Proof. unfold Equation1045. intro H. specialize (H F3_1 F3_2). unfold magma_op, reff116_inst, reff116_op in H. discriminate H. Qed.

Lemma reff116_not1046 : ~ @Equation1046 Fin3 reff116_inst.
Proof. unfold Equation1046. intro H. specialize (H F3_1 F3_0). unfold magma_op, reff116_inst, reff116_op in H. discriminate H. Qed.

Lemma reff116_not1048 : ~ @Equation1048 Fin3 reff116_inst.
Proof. unfold Equation1048. intro H. specialize (H F3_1 F3_2). unfold magma_op, reff116_inst, reff116_op in H. discriminate H. Qed.

Lemma reff116_not1049 : ~ @Equation1049 Fin3 reff116_inst.
Proof. unfold Equation1049. intro H. specialize (H F3_1 F3_0). unfold magma_op, reff116_inst, reff116_op in H. discriminate H. Qed.

Lemma reff116_not1072 : ~ @Equation1072 Fin3 reff116_inst.
Proof. unfold Equation1072. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff116_inst, reff116_op in H. discriminate H. Qed.

Lemma reff116_not1073 : ~ @Equation1073 Fin3 reff116_inst.
Proof. unfold Equation1073. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff116_inst, reff116_op in H. discriminate H. Qed.

Lemma reff116_not1075 : ~ @Equation1075 Fin3 reff116_inst.
Proof. unfold Equation1075. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff116_inst, reff116_op in H. discriminate H. Qed.

Lemma reff116_not1076 : ~ @Equation1076 Fin3 reff116_inst.
Proof. unfold Equation1076. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff116_inst, reff116_op in H. discriminate H. Qed.

Lemma reff116_not1082 : ~ @Equation1082 Fin3 reff116_inst.
Proof. unfold Equation1082. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff116_inst, reff116_op in H. discriminate H. Qed.

Lemma reff116_not1083 : ~ @Equation1083 Fin3 reff116_inst.
Proof. unfold Equation1083. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff116_inst, reff116_op in H. discriminate H. Qed.

Lemma reff116_not1085 : ~ @Equation1085 Fin3 reff116_inst.
Proof. unfold Equation1085. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff116_inst, reff116_op in H. discriminate H. Qed.

Lemma reff116_not1086 : ~ @Equation1086 Fin3 reff116_inst.
Proof. unfold Equation1086. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff116_inst, reff116_op in H. discriminate H. Qed.

Lemma reff116_not1109 : ~ @Equation1109 Fin3 reff116_inst.
Proof. unfold Equation1109. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff116_inst, reff116_op in H. discriminate H. Qed.

Lemma reff116_not1110 : ~ @Equation1110 Fin3 reff116_inst.
Proof. unfold Equation1110. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff116_inst, reff116_op in H. discriminate H. Qed.

Lemma reff116_not1112 : ~ @Equation1112 Fin3 reff116_inst.
Proof. unfold Equation1112. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff116_inst, reff116_op in H. discriminate H. Qed.

Lemma reff116_not1113 : ~ @Equation1113 Fin3 reff116_inst.
Proof. unfold Equation1113. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff116_inst, reff116_op in H. discriminate H. Qed.

Lemma reff116_not1119 : ~ @Equation1119 Fin3 reff116_inst.
Proof. unfold Equation1119. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff116_inst, reff116_op in H. discriminate H. Qed.

Lemma reff116_not1120 : ~ @Equation1120 Fin3 reff116_inst.
Proof. unfold Equation1120. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff116_inst, reff116_op in H. discriminate H. Qed.

Lemma reff116_not1122 : ~ @Equation1122 Fin3 reff116_inst.
Proof. unfold Equation1122. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff116_inst, reff116_op in H. discriminate H. Qed.

Lemma reff116_not1224 : ~ @Equation1224 Fin3 reff116_inst.
Proof. unfold Equation1224. intro H. specialize (H F3_1 F3_0). unfold magma_op, reff116_inst, reff116_op in H. discriminate H. Qed.

Lemma reff116_not1225 : ~ @Equation1225 Fin3 reff116_inst.
Proof. unfold Equation1225. intro H. specialize (H F3_1 F3_0). unfold magma_op, reff116_inst, reff116_op in H. discriminate H. Qed.

Lemma reff116_not1226 : ~ @Equation1226 Fin3 reff116_inst.
Proof. unfold Equation1226. intro H. specialize (H F3_1 F3_2). unfold magma_op, reff116_inst, reff116_op in H. discriminate H. Qed.

Lemma reff116_not1228 : ~ @Equation1228 Fin3 reff116_inst.
Proof. unfold Equation1228. intro H. specialize (H F3_1 F3_2). unfold magma_op, reff116_inst, reff116_op in H. discriminate H. Qed.

Lemma reff116_not1229 : ~ @Equation1229 Fin3 reff116_inst.
Proof. unfold Equation1229. intro H. specialize (H F3_1 F3_0). unfold magma_op, reff116_inst, reff116_op in H. discriminate H. Qed.

Lemma reff116_not1231 : ~ @Equation1231 Fin3 reff116_inst.
Proof. unfold Equation1231. intro H. specialize (H F3_1 F3_0). unfold magma_op, reff116_inst, reff116_op in H. discriminate H. Qed.

Lemma reff116_not1232 : ~ @Equation1232 Fin3 reff116_inst.
Proof. unfold Equation1232. intro H. specialize (H F3_1 F3_2). unfold magma_op, reff116_inst, reff116_op in H. discriminate H. Qed.

Lemma reff116_not1238 : ~ @Equation1238 Fin3 reff116_inst.
Proof. unfold Equation1238. intro H. specialize (H F3_1 F3_2). unfold magma_op, reff116_inst, reff116_op in H. discriminate H. Qed.

Lemma reff116_not1239 : ~ @Equation1239 Fin3 reff116_inst.
Proof. unfold Equation1239. intro H. specialize (H F3_1 F3_0). unfold magma_op, reff116_inst, reff116_op in H. discriminate H. Qed.

Lemma reff116_not1241 : ~ @Equation1241 Fin3 reff116_inst.
Proof. unfold Equation1241. intro H. specialize (H F3_1 F3_0). unfold magma_op, reff116_inst, reff116_op in H. discriminate H. Qed.

Lemma reff116_not1242 : ~ @Equation1242 Fin3 reff116_inst.
Proof. unfold Equation1242. intro H. specialize (H F3_1 F3_2). unfold magma_op, reff116_inst, reff116_op in H. discriminate H. Qed.

Lemma reff116_not1248 : ~ @Equation1248 Fin3 reff116_inst.
Proof. unfold Equation1248. intro H. specialize (H F3_1 F3_0). unfold magma_op, reff116_inst, reff116_op in H. discriminate H. Qed.

Lemma reff116_not1249 : ~ @Equation1249 Fin3 reff116_inst.
Proof. unfold Equation1249. intro H. specialize (H F3_1 F3_2). unfold magma_op, reff116_inst, reff116_op in H. discriminate H. Qed.

Lemma reff116_not1252 : ~ @Equation1252 Fin3 reff116_inst.
Proof. unfold Equation1252. intro H. specialize (H F3_1 F3_0). unfold magma_op, reff116_inst, reff116_op in H. discriminate H. Qed.

Lemma reff116_not1275 : ~ @Equation1275 Fin3 reff116_inst.
Proof. unfold Equation1275. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff116_inst, reff116_op in H. discriminate H. Qed.

Lemma reff116_not1276 : ~ @Equation1276 Fin3 reff116_inst.
Proof. unfold Equation1276. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff116_inst, reff116_op in H. discriminate H. Qed.

Lemma reff116_not1278 : ~ @Equation1278 Fin3 reff116_inst.
Proof. unfold Equation1278. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff116_inst, reff116_op in H. discriminate H. Qed.

Lemma reff116_not1279 : ~ @Equation1279 Fin3 reff116_inst.
Proof. unfold Equation1279. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff116_inst, reff116_op in H. discriminate H. Qed.

Lemma reff116_not1285 : ~ @Equation1285 Fin3 reff116_inst.
Proof. unfold Equation1285. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff116_inst, reff116_op in H. discriminate H. Qed.

Lemma reff116_not1286 : ~ @Equation1286 Fin3 reff116_inst.
Proof. unfold Equation1286. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff116_inst, reff116_op in H. discriminate H. Qed.

Lemma reff116_not1288 : ~ @Equation1288 Fin3 reff116_inst.
Proof. unfold Equation1288. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff116_inst, reff116_op in H. discriminate H. Qed.

Lemma reff116_not1289 : ~ @Equation1289 Fin3 reff116_inst.
Proof. unfold Equation1289. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff116_inst, reff116_op in H. discriminate H. Qed.

Lemma reff116_not1312 : ~ @Equation1312 Fin3 reff116_inst.
Proof. unfold Equation1312. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff116_inst, reff116_op in H. discriminate H. Qed.

Lemma reff116_not1313 : ~ @Equation1313 Fin3 reff116_inst.
Proof. unfold Equation1313. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff116_inst, reff116_op in H. discriminate H. Qed.

Lemma reff116_not1315 : ~ @Equation1315 Fin3 reff116_inst.
Proof. unfold Equation1315. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff116_inst, reff116_op in H. discriminate H. Qed.

Lemma reff116_not1316 : ~ @Equation1316 Fin3 reff116_inst.
Proof. unfold Equation1316. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff116_inst, reff116_op in H. discriminate H. Qed.

Lemma reff116_not1322 : ~ @Equation1322 Fin3 reff116_inst.
Proof. unfold Equation1322. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff116_inst, reff116_op in H. discriminate H. Qed.

Lemma reff116_not1323 : ~ @Equation1323 Fin3 reff116_inst.
Proof. unfold Equation1323. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff116_inst, reff116_op in H. discriminate H. Qed.

Lemma reff116_not1325 : ~ @Equation1325 Fin3 reff116_inst.
Proof. unfold Equation1325. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff116_inst, reff116_op in H. discriminate H. Qed.

Lemma reff116_not1426 : ~ @Equation1426 Fin3 reff116_inst.
Proof. unfold Equation1426. intro H. specialize (H F3_1). unfold magma_op, reff116_inst, reff116_op in H. discriminate H. Qed.

Lemma reff116_not1629 : ~ @Equation1629 Fin3 reff116_inst.
Proof. unfold Equation1629. intro H. specialize (H F3_1). unfold magma_op, reff116_inst, reff116_op in H. discriminate H. Qed.

Lemma reff116_not1833 : ~ @Equation1833 Fin3 reff116_inst.
Proof. unfold Equation1833. intro H. specialize (H F3_1 F3_2). unfold magma_op, reff116_inst, reff116_op in H. discriminate H. Qed.

Lemma reff116_not1834 : ~ @Equation1834 Fin3 reff116_inst.
Proof. unfold Equation1834. intro H. specialize (H F3_1 F3_2). unfold magma_op, reff116_inst, reff116_op in H. discriminate H. Qed.

Lemma reff116_not1835 : ~ @Equation1835 Fin3 reff116_inst.
Proof. unfold Equation1835. intro H. specialize (H F3_1 F3_0). unfold magma_op, reff116_inst, reff116_op in H. discriminate H. Qed.

Lemma reff116_not1837 : ~ @Equation1837 Fin3 reff116_inst.
Proof. unfold Equation1837. intro H. specialize (H F3_1 F3_2). unfold magma_op, reff116_inst, reff116_op in H. discriminate H. Qed.

Lemma reff116_not1838 : ~ @Equation1838 Fin3 reff116_inst.
Proof. unfold Equation1838. intro H. specialize (H F3_1 F3_2). unfold magma_op, reff116_inst, reff116_op in H. discriminate H. Qed.

Lemma reff116_not1840 : ~ @Equation1840 Fin3 reff116_inst.
Proof. unfold Equation1840. intro H. specialize (H F3_1 F3_2). unfold magma_op, reff116_inst, reff116_op in H. discriminate H. Qed.

Lemma reff116_not1841 : ~ @Equation1841 Fin3 reff116_inst.
Proof. unfold Equation1841. intro H. specialize (H F3_1 F3_0). unfold magma_op, reff116_inst, reff116_op in H. discriminate H. Qed.

Lemma reff116_not1847 : ~ @Equation1847 Fin3 reff116_inst.
Proof. unfold Equation1847. intro H. specialize (H F3_1 F3_2). unfold magma_op, reff116_inst, reff116_op in H. discriminate H. Qed.

Lemma reff116_not1848 : ~ @Equation1848 Fin3 reff116_inst.
Proof. unfold Equation1848. intro H. specialize (H F3_1 F3_2). unfold magma_op, reff116_inst, reff116_op in H. discriminate H. Qed.

Lemma reff116_not1850 : ~ @Equation1850 Fin3 reff116_inst.
Proof. unfold Equation1850. intro H. specialize (H F3_1 F3_2). unfold magma_op, reff116_inst, reff116_op in H. discriminate H. Qed.

Lemma reff116_not1851 : ~ @Equation1851 Fin3 reff116_inst.
Proof. unfold Equation1851. intro H. specialize (H F3_1 F3_0). unfold magma_op, reff116_inst, reff116_op in H. discriminate H. Qed.

Lemma reff116_not1857 : ~ @Equation1857 Fin3 reff116_inst.
Proof. unfold Equation1857. intro H. specialize (H F3_1 F3_0). unfold magma_op, reff116_inst, reff116_op in H. discriminate H. Qed.

Lemma reff116_not1858 : ~ @Equation1858 Fin3 reff116_inst.
Proof. unfold Equation1858. intro H. specialize (H F3_1 F3_0). unfold magma_op, reff116_inst, reff116_op in H. discriminate H. Qed.

Lemma reff116_not1860 : ~ @Equation1860 Fin3 reff116_inst.
Proof. unfold Equation1860. intro H. specialize (H F3_1 F3_0). unfold magma_op, reff116_inst, reff116_op in H. discriminate H. Qed.

Lemma reff116_not1861 : ~ @Equation1861 Fin3 reff116_inst.
Proof. unfold Equation1861. intro H. specialize (H F3_1 F3_0). unfold magma_op, reff116_inst, reff116_op in H. discriminate H. Qed.

Lemma reff116_not1884 : ~ @Equation1884 Fin3 reff116_inst.
Proof. unfold Equation1884. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff116_inst, reff116_op in H. discriminate H. Qed.

Lemma reff116_not1885 : ~ @Equation1885 Fin3 reff116_inst.
Proof. unfold Equation1885. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff116_inst, reff116_op in H. discriminate H. Qed.

Lemma reff116_not1887 : ~ @Equation1887 Fin3 reff116_inst.
Proof. unfold Equation1887. intro H. specialize (H F3_1 F3_0). unfold magma_op, reff116_inst, reff116_op in H. discriminate H. Qed.

Lemma reff116_not1888 : ~ @Equation1888 Fin3 reff116_inst.
Proof. unfold Equation1888. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff116_inst, reff116_op in H. discriminate H. Qed.

Lemma reff116_not1894 : ~ @Equation1894 Fin3 reff116_inst.
Proof. unfold Equation1894. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff116_inst, reff116_op in H. discriminate H. Qed.

Lemma reff116_not1895 : ~ @Equation1895 Fin3 reff116_inst.
Proof. unfold Equation1895. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff116_inst, reff116_op in H. discriminate H. Qed.

Lemma reff116_not1897 : ~ @Equation1897 Fin3 reff116_inst.
Proof. unfold Equation1897. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff116_inst, reff116_op in H. discriminate H. Qed.

Lemma reff116_not1898 : ~ @Equation1898 Fin3 reff116_inst.
Proof. unfold Equation1898. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff116_inst, reff116_op in H. discriminate H. Qed.

Lemma reff116_not1921 : ~ @Equation1921 Fin3 reff116_inst.
Proof. unfold Equation1921. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff116_inst, reff116_op in H. discriminate H. Qed.

Lemma reff116_not1922 : ~ @Equation1922 Fin3 reff116_inst.
Proof. unfold Equation1922. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff116_inst, reff116_op in H. discriminate H. Qed.

Lemma reff116_not1924 : ~ @Equation1924 Fin3 reff116_inst.
Proof. unfold Equation1924. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff116_inst, reff116_op in H. discriminate H. Qed.

Lemma reff116_not1925 : ~ @Equation1925 Fin3 reff116_inst.
Proof. unfold Equation1925. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff116_inst, reff116_op in H. discriminate H. Qed.

Lemma reff116_not1931 : ~ @Equation1931 Fin3 reff116_inst.
Proof. unfold Equation1931. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff116_inst, reff116_op in H. discriminate H. Qed.

Lemma reff116_not1932 : ~ @Equation1932 Fin3 reff116_inst.
Proof. unfold Equation1932. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff116_inst, reff116_op in H. discriminate H. Qed.

Lemma reff116_not1934 : ~ @Equation1934 Fin3 reff116_inst.
Proof. unfold Equation1934. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff116_inst, reff116_op in H. discriminate H. Qed.

Lemma reff116_not2035 : ~ @Equation2035 Fin3 reff116_inst.
Proof. unfold Equation2035. intro H. specialize (H F3_1). unfold magma_op, reff116_inst, reff116_op in H. discriminate H. Qed.

Lemma reff116_not2238 : ~ @Equation2238 Fin3 reff116_inst.
Proof. unfold Equation2238. intro H. specialize (H F3_1). unfold magma_op, reff116_inst, reff116_op in H. discriminate H. Qed.

Lemma reff116_not2441 : ~ @Equation2441 Fin3 reff116_inst.
Proof. unfold Equation2441. intro H. specialize (H F3_1). unfold magma_op, reff116_inst, reff116_op in H. discriminate H. Qed.

Lemma reff116_not2644 : ~ @Equation2644 Fin3 reff116_inst.
Proof. unfold Equation2644. intro H. specialize (H F3_1). unfold magma_op, reff116_inst, reff116_op in H. discriminate H. Qed.

Lemma reff116_not2847 : ~ @Equation2847 Fin3 reff116_inst.
Proof. unfold Equation2847. intro H. specialize (H F3_1). unfold magma_op, reff116_inst, reff116_op in H. discriminate H. Qed.

Lemma reff116_not3050 : ~ @Equation3050 Fin3 reff116_inst.
Proof. unfold Equation3050. intro H. specialize (H F3_1). unfold magma_op, reff116_inst, reff116_op in H. discriminate H. Qed.

Lemma reff116_not3254 : ~ @Equation3254 Fin3 reff116_inst.
Proof. unfold Equation3254. intro H. specialize (H F3_1 F3_2). unfold magma_op, reff116_inst, reff116_op in H. discriminate H. Qed.

Lemma reff116_not3255 : ~ @Equation3255 Fin3 reff116_inst.
Proof. unfold Equation3255. intro H. specialize (H F3_1 F3_2). unfold magma_op, reff116_inst, reff116_op in H. discriminate H. Qed.

Lemma reff116_not3256 : ~ @Equation3256 Fin3 reff116_inst.
Proof. unfold Equation3256. intro H. specialize (H F3_1 F3_0). unfold magma_op, reff116_inst, reff116_op in H. discriminate H. Qed.

Lemma reff116_not3258 : ~ @Equation3258 Fin3 reff116_inst.
Proof. unfold Equation3258. intro H. specialize (H F3_2 F3_0). unfold magma_op, reff116_inst, reff116_op in H. discriminate H. Qed.

Lemma reff116_not3259 : ~ @Equation3259 Fin3 reff116_inst.
Proof. unfold Equation3259. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff116_inst, reff116_op in H. discriminate H. Qed.

Lemma reff116_not3261 : ~ @Equation3261 Fin3 reff116_inst.
Proof. unfold Equation3261. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff116_inst, reff116_op in H. discriminate H. Qed.

Lemma reff116_not3262 : ~ @Equation3262 Fin3 reff116_inst.
Proof. unfold Equation3262. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff116_inst, reff116_op in H. discriminate H. Qed.

Lemma reff116_not3268 : ~ @Equation3268 Fin3 reff116_inst.
Proof. unfold Equation3268. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff116_inst, reff116_op in H. discriminate H. Qed.

Lemma reff116_not3271 : ~ @Equation3271 Fin3 reff116_inst.
Proof. unfold Equation3271. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff116_inst, reff116_op in H. discriminate H. Qed.

Lemma reff116_not3272 : ~ @Equation3272 Fin3 reff116_inst.
Proof. unfold Equation3272. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff116_inst, reff116_op in H. discriminate H. Qed.

Lemma reff116_not3278 : ~ @Equation3278 Fin3 reff116_inst.
Proof. unfold Equation3278. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff116_inst, reff116_op in H. discriminate H. Qed.

Lemma reff116_not3279 : ~ @Equation3279 Fin3 reff116_inst.
Proof. unfold Equation3279. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff116_inst, reff116_op in H. discriminate H. Qed.

Lemma reff116_not3281 : ~ @Equation3281 Fin3 reff116_inst.
Proof. unfold Equation3281. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff116_inst, reff116_op in H. discriminate H. Qed.

Lemma reff116_not3306 : ~ @Equation3306 Fin3 reff116_inst.
Proof. unfold Equation3306. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff116_inst, reff116_op in H. discriminate H. Qed.

Lemma reff116_not3308 : ~ @Equation3308 Fin3 reff116_inst.
Proof. unfold Equation3308. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff116_inst, reff116_op in H. discriminate H. Qed.

Lemma reff116_not3309 : ~ @Equation3309 Fin3 reff116_inst.
Proof. unfold Equation3309. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff116_inst, reff116_op in H. discriminate H. Qed.

Lemma reff116_not3315 : ~ @Equation3315 Fin3 reff116_inst.
Proof. unfold Equation3315. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff116_inst, reff116_op in H. discriminate H. Qed.

Lemma reff116_not3316 : ~ @Equation3316 Fin3 reff116_inst.
Proof. unfold Equation3316. intro H. specialize (H F3_1 F3_2). unfold magma_op, reff116_inst, reff116_op in H. discriminate H. Qed.

Lemma reff116_not3342 : ~ @Equation3342 Fin3 reff116_inst.
Proof. unfold Equation3342. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff116_inst, reff116_op in H. discriminate H. Qed.

Lemma reff116_not3343 : ~ @Equation3343 Fin3 reff116_inst.
Proof. unfold Equation3343. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff116_inst, reff116_op in H. discriminate H. Qed.

Lemma reff116_not3345 : ~ @Equation3345 Fin3 reff116_inst.
Proof. unfold Equation3345. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff116_inst, reff116_op in H. discriminate H. Qed.

Lemma reff116_not3346 : ~ @Equation3346 Fin3 reff116_inst.
Proof. unfold Equation3346. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff116_inst, reff116_op in H. discriminate H. Qed.

Lemma reff116_not3352 : ~ @Equation3352 Fin3 reff116_inst.
Proof. unfold Equation3352. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff116_inst, reff116_op in H. discriminate H. Qed.

Lemma reff116_not3353 : ~ @Equation3353 Fin3 reff116_inst.
Proof. unfold Equation3353. intro H. specialize (H F3_1 F3_0). unfold magma_op, reff116_inst, reff116_op in H. discriminate H. Qed.

Lemma reff116_not3456 : ~ @Equation3456 Fin3 reff116_inst.
Proof. unfold Equation3456. intro H. specialize (H F3_2). unfold magma_op, reff116_inst, reff116_op in H. discriminate H. Qed.

Lemma reff116_not3659 : ~ @Equation3659 Fin3 reff116_inst.
Proof. unfold Equation3659. intro H. specialize (H F3_1). unfold magma_op, reff116_inst, reff116_op in H. discriminate H. Qed.

Lemma reff116_not3864 : ~ @Equation3864 Fin3 reff116_inst.
Proof. unfold Equation3864. intro H. specialize (H F3_1 F3_2). unfold magma_op, reff116_inst, reff116_op in H. discriminate H. Qed.

Lemma reff116_not3865 : ~ @Equation3865 Fin3 reff116_inst.
Proof. unfold Equation3865. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff116_inst, reff116_op in H. discriminate H. Qed.

Lemma reff116_not3867 : ~ @Equation3867 Fin3 reff116_inst.
Proof. unfold Equation3867. intro H. specialize (H F3_1 F3_2). unfold magma_op, reff116_inst, reff116_op in H. discriminate H. Qed.

Lemma reff116_not3868 : ~ @Equation3868 Fin3 reff116_inst.
Proof. unfold Equation3868. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff116_inst, reff116_op in H. discriminate H. Qed.

Lemma reff116_not3870 : ~ @Equation3870 Fin3 reff116_inst.
Proof. unfold Equation3870. intro H. specialize (H F3_1 F3_0). unfold magma_op, reff116_inst, reff116_op in H. discriminate H. Qed.

Lemma reff116_not3871 : ~ @Equation3871 Fin3 reff116_inst.
Proof. unfold Equation3871. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff116_inst, reff116_op in H. discriminate H. Qed.

Lemma reff116_not3877 : ~ @Equation3877 Fin3 reff116_inst.
Proof. unfold Equation3877. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff116_inst, reff116_op in H. discriminate H. Qed.

Lemma reff116_not3878 : ~ @Equation3878 Fin3 reff116_inst.
Proof. unfold Equation3878. intro H. specialize (H F3_1 F3_0). unfold magma_op, reff116_inst, reff116_op in H. discriminate H. Qed.

Lemma reff116_not3880 : ~ @Equation3880 Fin3 reff116_inst.
Proof. unfold Equation3880. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff116_inst, reff116_op in H. discriminate H. Qed.

Lemma reff116_not3881 : ~ @Equation3881 Fin3 reff116_inst.
Proof. unfold Equation3881. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff116_inst, reff116_op in H. discriminate H. Qed.

Lemma reff116_not3887 : ~ @Equation3887 Fin3 reff116_inst.
Proof. unfold Equation3887. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff116_inst, reff116_op in H. discriminate H. Qed.

Lemma reff116_not3888 : ~ @Equation3888 Fin3 reff116_inst.
Proof. unfold Equation3888. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff116_inst, reff116_op in H. discriminate H. Qed.

Lemma reff116_not3890 : ~ @Equation3890 Fin3 reff116_inst.
Proof. unfold Equation3890. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff116_inst, reff116_op in H. discriminate H. Qed.

Lemma reff116_not3917 : ~ @Equation3917 Fin3 reff116_inst.
Proof. unfold Equation3917. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff116_inst, reff116_op in H. discriminate H. Qed.

Lemma reff116_not3918 : ~ @Equation3918 Fin3 reff116_inst.
Proof. unfold Equation3918. intro H. specialize (H F3_1 F3_2). unfold magma_op, reff116_inst, reff116_op in H. discriminate H. Qed.

Lemma reff116_not3924 : ~ @Equation3924 Fin3 reff116_inst.
Proof. unfold Equation3924. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff116_inst, reff116_op in H. discriminate H. Qed.

Lemma reff116_not3925 : ~ @Equation3925 Fin3 reff116_inst.
Proof. unfold Equation3925. intro H. specialize (H F3_1 F3_2). unfold magma_op, reff116_inst, reff116_op in H. discriminate H. Qed.

Lemma reff116_not3927 : ~ @Equation3927 Fin3 reff116_inst.
Proof. unfold Equation3927. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff116_inst, reff116_op in H. discriminate H. Qed.

Lemma reff116_not3928 : ~ @Equation3928 Fin3 reff116_inst.
Proof. unfold Equation3928. intro H. specialize (H F3_1 F3_2). unfold magma_op, reff116_inst, reff116_op in H. discriminate H. Qed.

Lemma reff116_not3951 : ~ @Equation3951 Fin3 reff116_inst.
Proof. unfold Equation3951. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff116_inst, reff116_op in H. discriminate H. Qed.

Lemma reff116_not3952 : ~ @Equation3952 Fin3 reff116_inst.
Proof. unfold Equation3952. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff116_inst, reff116_op in H. discriminate H. Qed.

Lemma reff116_not3954 : ~ @Equation3954 Fin3 reff116_inst.
Proof. unfold Equation3954. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff116_inst, reff116_op in H. discriminate H. Qed.

Lemma reff116_not3955 : ~ @Equation3955 Fin3 reff116_inst.
Proof. unfold Equation3955. intro H. specialize (H F3_1 F3_0). unfold magma_op, reff116_inst, reff116_op in H. discriminate H. Qed.

Lemma reff116_not3961 : ~ @Equation3961 Fin3 reff116_inst.
Proof. unfold Equation3961. intro H. specialize (H F3_1 F3_2). unfold magma_op, reff116_inst, reff116_op in H. discriminate H. Qed.

Lemma reff116_not3962 : ~ @Equation3962 Fin3 reff116_inst.
Proof. unfold Equation3962. intro H. specialize (H F3_1 F3_0). unfold magma_op, reff116_inst, reff116_op in H. discriminate H. Qed.

Lemma reff116_not3964 : ~ @Equation3964 Fin3 reff116_inst.
Proof. unfold Equation3964. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff116_inst, reff116_op in H. discriminate H. Qed.

Lemma reff116_not4066 : ~ @Equation4066 Fin3 reff116_inst.
Proof. unfold Equation4066. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff116_inst, reff116_op in H. discriminate H. Qed.

Lemma reff116_not4067 : ~ @Equation4067 Fin3 reff116_inst.
Proof. unfold Equation4067. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff116_inst, reff116_op in H. discriminate H. Qed.

Lemma reff116_not4068 : ~ @Equation4068 Fin3 reff116_inst.
Proof. unfold Equation4068. intro H. specialize (H F3_1 F3_2). unfold magma_op, reff116_inst, reff116_op in H. discriminate H. Qed.

Lemma reff116_not4070 : ~ @Equation4070 Fin3 reff116_inst.
Proof. unfold Equation4070. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff116_inst, reff116_op in H. discriminate H. Qed.

Lemma reff116_not4071 : ~ @Equation4071 Fin3 reff116_inst.
Proof. unfold Equation4071. intro H. specialize (H F3_1 F3_0). unfold magma_op, reff116_inst, reff116_op in H. discriminate H. Qed.

Lemma reff116_not4073 : ~ @Equation4073 Fin3 reff116_inst.
Proof. unfold Equation4073. intro H. specialize (H F3_1 F3_0). unfold magma_op, reff116_inst, reff116_op in H. discriminate H. Qed.

Lemma reff116_not4074 : ~ @Equation4074 Fin3 reff116_inst.
Proof. unfold Equation4074. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff116_inst, reff116_op in H. discriminate H. Qed.

Lemma reff116_not4080 : ~ @Equation4080 Fin3 reff116_inst.
Proof. unfold Equation4080. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff116_inst, reff116_op in H. discriminate H. Qed.

Lemma reff116_not4083 : ~ @Equation4083 Fin3 reff116_inst.
Proof. unfold Equation4083. intro H. specialize (H F3_1 F3_0). unfold magma_op, reff116_inst, reff116_op in H. discriminate H. Qed.

Lemma reff116_not4084 : ~ @Equation4084 Fin3 reff116_inst.
Proof. unfold Equation4084. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff116_inst, reff116_op in H. discriminate H. Qed.

Lemma reff116_not4090 : ~ @Equation4090 Fin3 reff116_inst.
Proof. unfold Equation4090. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff116_inst, reff116_op in H. discriminate H. Qed.

Lemma reff116_not4091 : ~ @Equation4091 Fin3 reff116_inst.
Proof. unfold Equation4091. intro H. specialize (H F3_1 F3_2). unfold magma_op, reff116_inst, reff116_op in H. discriminate H. Qed.

Lemma reff116_not4118 : ~ @Equation4118 Fin3 reff116_inst.
Proof. unfold Equation4118. intro H. specialize (H F3_1 F3_0). unfold magma_op, reff116_inst, reff116_op in H. discriminate H. Qed.

Lemma reff116_not4120 : ~ @Equation4120 Fin3 reff116_inst.
Proof. unfold Equation4120. intro H. specialize (H F3_1 F3_0). unfold magma_op, reff116_inst, reff116_op in H. discriminate H. Qed.

Lemma reff116_not4121 : ~ @Equation4121 Fin3 reff116_inst.
Proof. unfold Equation4121. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff116_inst, reff116_op in H. discriminate H. Qed.

Lemma reff116_not4127 : ~ @Equation4127 Fin3 reff116_inst.
Proof. unfold Equation4127. intro H. specialize (H F3_1 F3_2). unfold magma_op, reff116_inst, reff116_op in H. discriminate H. Qed.

Lemma reff116_not4128 : ~ @Equation4128 Fin3 reff116_inst.
Proof. unfold Equation4128. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff116_inst, reff116_op in H. discriminate H. Qed.

Lemma reff116_not4130 : ~ @Equation4130 Fin3 reff116_inst.
Proof. unfold Equation4130. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff116_inst, reff116_op in H. discriminate H. Qed.

Lemma reff116_not4155 : ~ @Equation4155 Fin3 reff116_inst.
Proof. unfold Equation4155. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff116_inst, reff116_op in H. discriminate H. Qed.

Lemma reff116_not4157 : ~ @Equation4157 Fin3 reff116_inst.
Proof. unfold Equation4157. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff116_inst, reff116_op in H. discriminate H. Qed.

Lemma reff116_not4158 : ~ @Equation4158 Fin3 reff116_inst.
Proof. unfold Equation4158. intro H. specialize (H F3_1 F3_2). unfold magma_op, reff116_inst, reff116_op in H. discriminate H. Qed.

Lemma reff116_not4164 : ~ @Equation4164 Fin3 reff116_inst.
Proof. unfold Equation4164. intro H. specialize (H F3_1 F3_0). unfold magma_op, reff116_inst, reff116_op in H. discriminate H. Qed.

Lemma reff116_not4165 : ~ @Equation4165 Fin3 reff116_inst.
Proof. unfold Equation4165. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff116_inst, reff116_op in H. discriminate H. Qed.

Lemma reff116_not4167 : ~ @Equation4167 Fin3 reff116_inst.
Proof. unfold Equation4167. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff116_inst, reff116_op in H. discriminate H. Qed.

Lemma reff116_not4268 : ~ @Equation4268 Fin3 reff116_inst.
Proof. unfold Equation4268. intro H. specialize (H F3_1 F3_2). unfold magma_op, reff116_inst, reff116_op in H. discriminate H. Qed.

Lemma reff116_not4269 : ~ @Equation4269 Fin3 reff116_inst.
Proof. unfold Equation4269. intro H. specialize (H F3_1 F3_2). unfold magma_op, reff116_inst, reff116_op in H. discriminate H. Qed.

Lemma reff116_not4270 : ~ @Equation4270 Fin3 reff116_inst.
Proof. unfold Equation4270. intro H. specialize (H F3_1 F3_0). unfold magma_op, reff116_inst, reff116_op in H. discriminate H. Qed.

Lemma reff116_not4272 : ~ @Equation4272 Fin3 reff116_inst.
Proof. unfold Equation4272. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff116_inst, reff116_op in H. discriminate H. Qed.

Lemma reff116_not4273 : ~ @Equation4273 Fin3 reff116_inst.
Proof. unfold Equation4273. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff116_inst, reff116_op in H. discriminate H. Qed.

Lemma reff116_not4275 : ~ @Equation4275 Fin3 reff116_inst.
Proof. unfold Equation4275. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff116_inst, reff116_op in H. discriminate H. Qed.

Lemma reff116_not4276 : ~ @Equation4276 Fin3 reff116_inst.
Proof. unfold Equation4276. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff116_inst, reff116_op in H. discriminate H. Qed.

Lemma reff116_not4283 : ~ @Equation4283 Fin3 reff116_inst.
Proof. unfold Equation4283. intro H. specialize (H F3_2 F3_0). unfold magma_op, reff116_inst, reff116_op in H. discriminate H. Qed.

Lemma reff116_not4284 : ~ @Equation4284 Fin3 reff116_inst.
Proof. unfold Equation4284. intro H. specialize (H F3_1 F3_0). unfold magma_op, reff116_inst, reff116_op in H. discriminate H. Qed.

Lemma reff116_not4290 : ~ @Equation4290 Fin3 reff116_inst.
Proof. unfold Equation4290. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff116_inst, reff116_op in H. discriminate H. Qed.

Lemma reff116_not4291 : ~ @Equation4291 Fin3 reff116_inst.
Proof. unfold Equation4291. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff116_inst, reff116_op in H. discriminate H. Qed.

Lemma reff116_not4293 : ~ @Equation4293 Fin3 reff116_inst.
Proof. unfold Equation4293. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff116_inst, reff116_op in H. discriminate H. Qed.

Lemma reff116_not4314 : ~ @Equation4314 Fin3 reff116_inst.
Proof. unfold Equation4314. intro H. specialize (H F3_1 F3_0). unfold magma_op, reff116_inst, reff116_op in H. discriminate H. Qed.

Lemma reff116_not4320 : ~ @Equation4320 Fin3 reff116_inst.
Proof. unfold Equation4320. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff116_inst, reff116_op in H. discriminate H. Qed.

Lemma reff116_not4321 : ~ @Equation4321 Fin3 reff116_inst.
Proof. unfold Equation4321. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff116_inst, reff116_op in H. discriminate H. Qed.

Lemma reff116_not4343 : ~ @Equation4343 Fin3 reff116_inst.
Proof. unfold Equation4343. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff116_inst, reff116_op in H. discriminate H. Qed.

Lemma reff116_not4380 : ~ @Equation4380 Fin3 reff116_inst.
Proof. unfold Equation4380. intro H. specialize (H F3_1). unfold magma_op, reff116_inst, reff116_op in H. discriminate H. Qed.

Lemma reff116_not4583 : ~ @Equation4583 Fin3 reff116_inst.
Proof. unfold Equation4583. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff116_inst, reff116_op in H. discriminate H. Qed.

Lemma reff116_not4584 : ~ @Equation4584 Fin3 reff116_inst.
Proof. unfold Equation4584. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff116_inst, reff116_op in H. discriminate H. Qed.

Lemma reff116_not4585 : ~ @Equation4585 Fin3 reff116_inst.
Proof. unfold Equation4585. intro H. specialize (H F3_1 F3_0). unfold magma_op, reff116_inst, reff116_op in H. discriminate H. Qed.

Lemma reff116_not4587 : ~ @Equation4587 Fin3 reff116_inst.
Proof. unfold Equation4587. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff116_inst, reff116_op in H. discriminate H. Qed.

Lemma reff116_not4588 : ~ @Equation4588 Fin3 reff116_inst.
Proof. unfold Equation4588. intro H. specialize (H F3_1 F3_0). unfold magma_op, reff116_inst, reff116_op in H. discriminate H. Qed.

Lemma reff116_not4590 : ~ @Equation4590 Fin3 reff116_inst.
Proof. unfold Equation4590. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff116_inst, reff116_op in H. discriminate H. Qed.

Lemma reff116_not4598 : ~ @Equation4598 Fin3 reff116_inst.
Proof. unfold Equation4598. intro H. specialize (H F3_1 F3_0). unfold magma_op, reff116_inst, reff116_op in H. discriminate H. Qed.

Lemma reff116_not4599 : ~ @Equation4599 Fin3 reff116_inst.
Proof. unfold Equation4599. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff116_inst, reff116_op in H. discriminate H. Qed.

Lemma reff116_not4605 : ~ @Equation4605 Fin3 reff116_inst.
Proof. unfold Equation4605. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff116_inst, reff116_op in H. discriminate H. Qed.

Lemma reff116_not4606 : ~ @Equation4606 Fin3 reff116_inst.
Proof. unfold Equation4606. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff116_inst, reff116_op in H. discriminate H. Qed.

Lemma reff116_not4608 : ~ @Equation4608 Fin3 reff116_inst.
Proof. unfold Equation4608. intro H. specialize (H F3_1 F3_2). unfold magma_op, reff116_inst, reff116_op in H. discriminate H. Qed.

Lemma reff116_not4629 : ~ @Equation4629 Fin3 reff116_inst.
Proof. unfold Equation4629. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff116_inst, reff116_op in H. discriminate H. Qed.

Lemma reff116_not4635 : ~ @Equation4635 Fin3 reff116_inst.
Proof. unfold Equation4635. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff116_inst, reff116_op in H. discriminate H. Qed.

Lemma reff116_not4636 : ~ @Equation4636 Fin3 reff116_inst.
Proof. unfold Equation4636. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff116_inst, reff116_op in H. discriminate H. Qed.

Lemma reff116_not4658 : ~ @Equation4658 Fin3 reff116_inst.
Proof. unfold Equation4658. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff116_inst, reff116_op in H. discriminate H. Qed.

(** ---- reff120 (Fin3) ---- *)

Definition reff120_op (x y : Fin3) : Fin3 :=
  match x, y with
  | F3_0, F3_0 => F3_0 | F3_0, F3_1 => F3_1 | F3_0, F3_2 => F3_0
  | F3_1, F3_0 => F3_1 | F3_1, F3_1 => F3_2 | F3_1, F3_2 => F3_1
  | F3_2, F3_0 => F3_2 | F3_2, F3_1 => F3_0 | F3_2, F3_2 => F3_2
  end.

#[local] Instance reff120_inst : Magma Fin3 := {| magma_op := reff120_op |}.

Lemma reff120_sat11 : @Equation11 Fin3 reff120_inst.
Proof. unfold Equation11, magma_op, reff120_inst, reff120_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff120_sat108 : @Equation108 Fin3 reff120_inst.
Proof. unfold Equation108, magma_op, reff120_inst, reff120_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff120_sat264 : @Equation264 Fin3 reff120_inst.
Proof. unfold Equation264, magma_op, reff120_inst, reff120_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff120_sat1053 : @Equation1053 Fin3 reff120_inst.
Proof. unfold Equation1053, magma_op, reff120_inst, reff120_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff120_not47 : ~ @Equation47 Fin3 reff120_inst.
Proof. unfold Equation47. intro H. specialize (H F3_1). unfold magma_op, reff120_inst, reff120_op in H. discriminate H. Qed.

Lemma reff120_not102 : ~ @Equation102 Fin3 reff120_inst.
Proof. unfold Equation102. intro H. specialize (H F3_1 F3_0). unfold magma_op, reff120_inst, reff120_op in H. discriminate H. Qed.

Lemma reff120_not105 : ~ @Equation105 Fin3 reff120_inst.
Proof. unfold Equation105. intro H. specialize (H F3_1 F3_0). unfold magma_op, reff120_inst, reff120_op in H. discriminate H. Qed.

Lemma reff120_not107 : ~ @Equation107 Fin3 reff120_inst.
Proof. unfold Equation107. intro H. specialize (H F3_1 F3_0). unfold magma_op, reff120_inst, reff120_op in H. discriminate H. Qed.

Lemma reff120_not115 : ~ @Equation115 Fin3 reff120_inst.
Proof. unfold Equation115. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff120_inst, reff120_op in H. discriminate H. Qed.

Lemma reff120_not117 : ~ @Equation117 Fin3 reff120_inst.
Proof. unfold Equation117. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff120_inst, reff120_op in H. discriminate H. Qed.

Lemma reff120_not118 : ~ @Equation118 Fin3 reff120_inst.
Proof. unfold Equation118. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff120_inst, reff120_op in H. discriminate H. Qed.

Lemma reff120_not124 : ~ @Equation124 Fin3 reff120_inst.
Proof. unfold Equation124. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff120_inst, reff120_op in H. discriminate H. Qed.

Lemma reff120_not125 : ~ @Equation125 Fin3 reff120_inst.
Proof. unfold Equation125. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff120_inst, reff120_op in H. discriminate H. Qed.

Lemma reff120_not127 : ~ @Equation127 Fin3 reff120_inst.
Proof. unfold Equation127. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff120_inst, reff120_op in H. discriminate H. Qed.

Lemma reff120_not151 : ~ @Equation151 Fin3 reff120_inst.
Proof. unfold Equation151. intro H. specialize (H F3_1). unfold magma_op, reff120_inst, reff120_op in H. discriminate H. Qed.

Lemma reff120_not203 : ~ @Equation203 Fin3 reff120_inst.
Proof. unfold Equation203. intro H. specialize (H F3_1). unfold magma_op, reff120_inst, reff120_op in H. discriminate H. Qed.

Lemma reff120_not258 : ~ @Equation258 Fin3 reff120_inst.
Proof. unfold Equation258. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff120_inst, reff120_op in H. discriminate H. Qed.

Lemma reff120_not261 : ~ @Equation261 Fin3 reff120_inst.
Proof. unfold Equation261. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff120_inst, reff120_op in H. discriminate H. Qed.

Lemma reff120_not263 : ~ @Equation263 Fin3 reff120_inst.
Proof. unfold Equation263. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff120_inst, reff120_op in H. discriminate H. Qed.

Lemma reff120_not271 : ~ @Equation271 Fin3 reff120_inst.
Proof. unfold Equation271. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff120_inst, reff120_op in H. discriminate H. Qed.

Lemma reff120_not273 : ~ @Equation273 Fin3 reff120_inst.
Proof. unfold Equation273. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff120_inst, reff120_op in H. discriminate H. Qed.

Lemma reff120_not274 : ~ @Equation274 Fin3 reff120_inst.
Proof. unfold Equation274. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff120_inst, reff120_op in H. discriminate H. Qed.

Lemma reff120_not280 : ~ @Equation280 Fin3 reff120_inst.
Proof. unfold Equation280. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff120_inst, reff120_op in H. discriminate H. Qed.

Lemma reff120_not281 : ~ @Equation281 Fin3 reff120_inst.
Proof. unfold Equation281. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff120_inst, reff120_op in H. discriminate H. Qed.

Lemma reff120_not283 : ~ @Equation283 Fin3 reff120_inst.
Proof. unfold Equation283. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff120_inst, reff120_op in H. discriminate H. Qed.

Lemma reff120_not307 : ~ @Equation307 Fin3 reff120_inst.
Proof. unfold Equation307. intro H. specialize (H F3_1). unfold magma_op, reff120_inst, reff120_op in H. discriminate H. Qed.

Lemma reff120_not412 : ~ @Equation412 Fin3 reff120_inst.
Proof. unfold Equation412. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff120_inst, reff120_op in H. discriminate H. Qed.

Lemma reff120_not413 : ~ @Equation413 Fin3 reff120_inst.
Proof. unfold Equation413. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff120_inst, reff120_op in H. discriminate H. Qed.

Lemma reff120_not416 : ~ @Equation416 Fin3 reff120_inst.
Proof. unfold Equation416. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff120_inst, reff120_op in H. discriminate H. Qed.

Lemma reff120_not417 : ~ @Equation417 Fin3 reff120_inst.
Proof. unfold Equation417. intro H. specialize (H F3_1 F3_2). unfold magma_op, reff120_inst, reff120_op in H. discriminate H. Qed.

Lemma reff120_not419 : ~ @Equation419 Fin3 reff120_inst.
Proof. unfold Equation419. intro H. specialize (H F3_1 F3_2). unfold magma_op, reff120_inst, reff120_op in H. discriminate H. Qed.

Lemma reff120_not420 : ~ @Equation420 Fin3 reff120_inst.
Proof. unfold Equation420. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff120_inst, reff120_op in H. discriminate H. Qed.

Lemma reff120_not426 : ~ @Equation426 Fin3 reff120_inst.
Proof. unfold Equation426. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff120_inst, reff120_op in H. discriminate H. Qed.

Lemma reff120_not427 : ~ @Equation427 Fin3 reff120_inst.
Proof. unfold Equation427. intro H. specialize (H F3_2 F3_1). unfold magma_op, reff120_inst, reff120_op in H. discriminate H. Qed.

Lemma reff120_not429 : ~ @Equation429 Fin3 reff120_inst.
Proof. unfold Equation429. intro H. specialize (H F3_2 F3_1). unfold magma_op, reff120_inst, reff120_op in H. discriminate H. Qed.

Lemma reff120_not430 : ~ @Equation430 Fin3 reff120_inst.
Proof. unfold Equation430. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff120_inst, reff120_op in H. discriminate H. Qed.

Lemma reff120_not437 : ~ @Equation437 Fin3 reff120_inst.
Proof. unfold Equation437. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff120_inst, reff120_op in H. discriminate H. Qed.

Lemma reff120_not439 : ~ @Equation439 Fin3 reff120_inst.
Proof. unfold Equation439. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff120_inst, reff120_op in H. discriminate H. Qed.

Lemma reff120_not463 : ~ @Equation463 Fin3 reff120_inst.
Proof. unfold Equation463. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff120_inst, reff120_op in H. discriminate H. Qed.

Lemma reff120_not464 : ~ @Equation464 Fin3 reff120_inst.
Proof. unfold Equation464. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff120_inst, reff120_op in H. discriminate H. Qed.

Lemma reff120_not466 : ~ @Equation466 Fin3 reff120_inst.
Proof. unfold Equation466. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff120_inst, reff120_op in H. discriminate H. Qed.

Lemma reff120_not467 : ~ @Equation467 Fin3 reff120_inst.
Proof. unfold Equation467. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff120_inst, reff120_op in H. discriminate H. Qed.

Lemma reff120_not473 : ~ @Equation473 Fin3 reff120_inst.
Proof. unfold Equation473. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff120_inst, reff120_op in H. discriminate H. Qed.

Lemma reff120_not474 : ~ @Equation474 Fin3 reff120_inst.
Proof. unfold Equation474. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff120_inst, reff120_op in H. discriminate H. Qed.

Lemma reff120_not476 : ~ @Equation476 Fin3 reff120_inst.
Proof. unfold Equation476. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff120_inst, reff120_op in H. discriminate H. Qed.

Lemma reff120_not477 : ~ @Equation477 Fin3 reff120_inst.
Proof. unfold Equation477. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff120_inst, reff120_op in H. discriminate H. Qed.

Lemma reff120_not500 : ~ @Equation500 Fin3 reff120_inst.
Proof. unfold Equation500. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff120_inst, reff120_op in H. discriminate H. Qed.

Lemma reff120_not501 : ~ @Equation501 Fin3 reff120_inst.
Proof. unfold Equation501. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff120_inst, reff120_op in H. discriminate H. Qed.

Lemma reff120_not503 : ~ @Equation503 Fin3 reff120_inst.
Proof. unfold Equation503. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff120_inst, reff120_op in H. discriminate H. Qed.

Lemma reff120_not504 : ~ @Equation504 Fin3 reff120_inst.
Proof. unfold Equation504. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff120_inst, reff120_op in H. discriminate H. Qed.

Lemma reff120_not510 : ~ @Equation510 Fin3 reff120_inst.
Proof. unfold Equation510. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff120_inst, reff120_op in H. discriminate H. Qed.

Lemma reff120_not511 : ~ @Equation511 Fin3 reff120_inst.
Proof. unfold Equation511. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff120_inst, reff120_op in H. discriminate H. Qed.

Lemma reff120_not513 : ~ @Equation513 Fin3 reff120_inst.
Proof. unfold Equation513. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff120_inst, reff120_op in H. discriminate H. Qed.

Lemma reff120_not614 : ~ @Equation614 Fin3 reff120_inst.
Proof. unfold Equation614. intro H. specialize (H F3_1). unfold magma_op, reff120_inst, reff120_op in H. discriminate H. Qed.

Lemma reff120_not818 : ~ @Equation818 Fin3 reff120_inst.
Proof. unfold Equation818. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff120_inst, reff120_op in H. discriminate H. Qed.

Lemma reff120_not819 : ~ @Equation819 Fin3 reff120_inst.
Proof. unfold Equation819. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff120_inst, reff120_op in H. discriminate H. Qed.

Lemma reff120_not822 : ~ @Equation822 Fin3 reff120_inst.
Proof. unfold Equation822. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff120_inst, reff120_op in H. discriminate H. Qed.

Lemma reff120_not825 : ~ @Equation825 Fin3 reff120_inst.
Proof. unfold Equation825. intro H. specialize (H F3_1 F3_2). unfold magma_op, reff120_inst, reff120_op in H. discriminate H. Qed.

Lemma reff120_not826 : ~ @Equation826 Fin3 reff120_inst.
Proof. unfold Equation826. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff120_inst, reff120_op in H. discriminate H. Qed.

Lemma reff120_not832 : ~ @Equation832 Fin3 reff120_inst.
Proof. unfold Equation832. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff120_inst, reff120_op in H. discriminate H. Qed.

Lemma reff120_not833 : ~ @Equation833 Fin3 reff120_inst.
Proof. unfold Equation833. intro H. specialize (H F3_1 F3_2). unfold magma_op, reff120_inst, reff120_op in H. discriminate H. Qed.

Lemma reff120_not836 : ~ @Equation836 Fin3 reff120_inst.
Proof. unfold Equation836. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff120_inst, reff120_op in H. discriminate H. Qed.

Lemma reff120_not843 : ~ @Equation843 Fin3 reff120_inst.
Proof. unfold Equation843. intro H. specialize (H F3_1 F3_0). unfold magma_op, reff120_inst, reff120_op in H. discriminate H. Qed.

Lemma reff120_not845 : ~ @Equation845 Fin3 reff120_inst.
Proof. unfold Equation845. intro H. specialize (H F3_1 F3_0). unfold magma_op, reff120_inst, reff120_op in H. discriminate H. Qed.

Lemma reff120_not869 : ~ @Equation869 Fin3 reff120_inst.
Proof. unfold Equation869. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff120_inst, reff120_op in H. discriminate H. Qed.

Lemma reff120_not870 : ~ @Equation870 Fin3 reff120_inst.
Proof. unfold Equation870. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff120_inst, reff120_op in H. discriminate H. Qed.

Lemma reff120_not872 : ~ @Equation872 Fin3 reff120_inst.
Proof. unfold Equation872. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff120_inst, reff120_op in H. discriminate H. Qed.

Lemma reff120_not873 : ~ @Equation873 Fin3 reff120_inst.
Proof. unfold Equation873. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff120_inst, reff120_op in H. discriminate H. Qed.

Lemma reff120_not879 : ~ @Equation879 Fin3 reff120_inst.
Proof. unfold Equation879. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff120_inst, reff120_op in H. discriminate H. Qed.

Lemma reff120_not880 : ~ @Equation880 Fin3 reff120_inst.
Proof. unfold Equation880. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff120_inst, reff120_op in H. discriminate H. Qed.

Lemma reff120_not882 : ~ @Equation882 Fin3 reff120_inst.
Proof. unfold Equation882. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff120_inst, reff120_op in H. discriminate H. Qed.

Lemma reff120_not883 : ~ @Equation883 Fin3 reff120_inst.
Proof. unfold Equation883. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff120_inst, reff120_op in H. discriminate H. Qed.

Lemma reff120_not906 : ~ @Equation906 Fin3 reff120_inst.
Proof. unfold Equation906. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff120_inst, reff120_op in H. discriminate H. Qed.

Lemma reff120_not907 : ~ @Equation907 Fin3 reff120_inst.
Proof. unfold Equation907. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff120_inst, reff120_op in H. discriminate H. Qed.

Lemma reff120_not909 : ~ @Equation909 Fin3 reff120_inst.
Proof. unfold Equation909. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff120_inst, reff120_op in H. discriminate H. Qed.

Lemma reff120_not910 : ~ @Equation910 Fin3 reff120_inst.
Proof. unfold Equation910. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff120_inst, reff120_op in H. discriminate H. Qed.

Lemma reff120_not916 : ~ @Equation916 Fin3 reff120_inst.
Proof. unfold Equation916. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff120_inst, reff120_op in H. discriminate H. Qed.

Lemma reff120_not917 : ~ @Equation917 Fin3 reff120_inst.
Proof. unfold Equation917. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff120_inst, reff120_op in H. discriminate H. Qed.

Lemma reff120_not919 : ~ @Equation919 Fin3 reff120_inst.
Proof. unfold Equation919. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff120_inst, reff120_op in H. discriminate H. Qed.

Lemma reff120_not1021 : ~ @Equation1021 Fin3 reff120_inst.
Proof. unfold Equation1021. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff120_inst, reff120_op in H. discriminate H. Qed.

Lemma reff120_not1022 : ~ @Equation1022 Fin3 reff120_inst.
Proof. unfold Equation1022. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff120_inst, reff120_op in H. discriminate H. Qed.

Lemma reff120_not1025 : ~ @Equation1025 Fin3 reff120_inst.
Proof. unfold Equation1025. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff120_inst, reff120_op in H. discriminate H. Qed.

Lemma reff120_not1026 : ~ @Equation1026 Fin3 reff120_inst.
Proof. unfold Equation1026. intro H. specialize (H F3_1 F3_2). unfold magma_op, reff120_inst, reff120_op in H. discriminate H. Qed.

Lemma reff120_not1029 : ~ @Equation1029 Fin3 reff120_inst.
Proof. unfold Equation1029. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff120_inst, reff120_op in H. discriminate H. Qed.

Lemma reff120_not1035 : ~ @Equation1035 Fin3 reff120_inst.
Proof. unfold Equation1035. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff120_inst, reff120_op in H. discriminate H. Qed.

Lemma reff120_not1038 : ~ @Equation1038 Fin3 reff120_inst.
Proof. unfold Equation1038. intro H. specialize (H F3_1 F3_2). unfold magma_op, reff120_inst, reff120_op in H. discriminate H. Qed.

Lemma reff120_not1039 : ~ @Equation1039 Fin3 reff120_inst.
Proof. unfold Equation1039. intro H. specialize (H F3_1 F3_0). unfold magma_op, reff120_inst, reff120_op in H. discriminate H. Qed.

Lemma reff120_not1046 : ~ @Equation1046 Fin3 reff120_inst.
Proof. unfold Equation1046. intro H. specialize (H F3_1 F3_0). unfold magma_op, reff120_inst, reff120_op in H. discriminate H. Qed.

Lemma reff120_not1048 : ~ @Equation1048 Fin3 reff120_inst.
Proof. unfold Equation1048. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff120_inst, reff120_op in H. discriminate H. Qed.

Lemma reff120_not1072 : ~ @Equation1072 Fin3 reff120_inst.
Proof. unfold Equation1072. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff120_inst, reff120_op in H. discriminate H. Qed.

Lemma reff120_not1073 : ~ @Equation1073 Fin3 reff120_inst.
Proof. unfold Equation1073. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff120_inst, reff120_op in H. discriminate H. Qed.

Lemma reff120_not1075 : ~ @Equation1075 Fin3 reff120_inst.
Proof. unfold Equation1075. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff120_inst, reff120_op in H. discriminate H. Qed.

Lemma reff120_not1076 : ~ @Equation1076 Fin3 reff120_inst.
Proof. unfold Equation1076. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff120_inst, reff120_op in H. discriminate H. Qed.

Lemma reff120_not1082 : ~ @Equation1082 Fin3 reff120_inst.
Proof. unfold Equation1082. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff120_inst, reff120_op in H. discriminate H. Qed.

Lemma reff120_not1083 : ~ @Equation1083 Fin3 reff120_inst.
Proof. unfold Equation1083. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff120_inst, reff120_op in H. discriminate H. Qed.

Lemma reff120_not1085 : ~ @Equation1085 Fin3 reff120_inst.
Proof. unfold Equation1085. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff120_inst, reff120_op in H. discriminate H. Qed.

Lemma reff120_not1086 : ~ @Equation1086 Fin3 reff120_inst.
Proof. unfold Equation1086. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff120_inst, reff120_op in H. discriminate H. Qed.

Lemma reff120_not1109 : ~ @Equation1109 Fin3 reff120_inst.
Proof. unfold Equation1109. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff120_inst, reff120_op in H. discriminate H. Qed.

Lemma reff120_not1110 : ~ @Equation1110 Fin3 reff120_inst.
Proof. unfold Equation1110. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff120_inst, reff120_op in H. discriminate H. Qed.

Lemma reff120_not1112 : ~ @Equation1112 Fin3 reff120_inst.
Proof. unfold Equation1112. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff120_inst, reff120_op in H. discriminate H. Qed.

Lemma reff120_not1113 : ~ @Equation1113 Fin3 reff120_inst.
Proof. unfold Equation1113. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff120_inst, reff120_op in H. discriminate H. Qed.

Lemma reff120_not1119 : ~ @Equation1119 Fin3 reff120_inst.
Proof. unfold Equation1119. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff120_inst, reff120_op in H. discriminate H. Qed.

Lemma reff120_not1120 : ~ @Equation1120 Fin3 reff120_inst.
Proof. unfold Equation1120. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff120_inst, reff120_op in H. discriminate H. Qed.

Lemma reff120_not1122 : ~ @Equation1122 Fin3 reff120_inst.
Proof. unfold Equation1122. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff120_inst, reff120_op in H. discriminate H. Qed.

Lemma reff120_not1223 : ~ @Equation1223 Fin3 reff120_inst.
Proof. unfold Equation1223. intro H. specialize (H F3_1). unfold magma_op, reff120_inst, reff120_op in H. discriminate H. Qed.

Lemma reff120_not1426 : ~ @Equation1426 Fin3 reff120_inst.
Proof. unfold Equation1426. intro H. specialize (H F3_1). unfold magma_op, reff120_inst, reff120_op in H. discriminate H. Qed.

Lemma reff120_not1629 : ~ @Equation1629 Fin3 reff120_inst.
Proof. unfold Equation1629. intro H. specialize (H F3_1). unfold magma_op, reff120_inst, reff120_op in H. discriminate H. Qed.

Lemma reff120_not1833 : ~ @Equation1833 Fin3 reff120_inst.
Proof. unfold Equation1833. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff120_inst, reff120_op in H. discriminate H. Qed.

Lemma reff120_not1834 : ~ @Equation1834 Fin3 reff120_inst.
Proof. unfold Equation1834. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff120_inst, reff120_op in H. discriminate H. Qed.

Lemma reff120_not1837 : ~ @Equation1837 Fin3 reff120_inst.
Proof. unfold Equation1837. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff120_inst, reff120_op in H. discriminate H. Qed.

Lemma reff120_not1838 : ~ @Equation1838 Fin3 reff120_inst.
Proof. unfold Equation1838. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff120_inst, reff120_op in H. discriminate H. Qed.

Lemma reff120_not1840 : ~ @Equation1840 Fin3 reff120_inst.
Proof. unfold Equation1840. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff120_inst, reff120_op in H. discriminate H. Qed.

Lemma reff120_not1841 : ~ @Equation1841 Fin3 reff120_inst.
Proof. unfold Equation1841. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff120_inst, reff120_op in H. discriminate H. Qed.

Lemma reff120_not1847 : ~ @Equation1847 Fin3 reff120_inst.
Proof. unfold Equation1847. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff120_inst, reff120_op in H. discriminate H. Qed.

Lemma reff120_not1848 : ~ @Equation1848 Fin3 reff120_inst.
Proof. unfold Equation1848. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff120_inst, reff120_op in H. discriminate H. Qed.

Lemma reff120_not1850 : ~ @Equation1850 Fin3 reff120_inst.
Proof. unfold Equation1850. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff120_inst, reff120_op in H. discriminate H. Qed.

Lemma reff120_not1851 : ~ @Equation1851 Fin3 reff120_inst.
Proof. unfold Equation1851. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff120_inst, reff120_op in H. discriminate H. Qed.

Lemma reff120_not1858 : ~ @Equation1858 Fin3 reff120_inst.
Proof. unfold Equation1858. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff120_inst, reff120_op in H. discriminate H. Qed.

Lemma reff120_not1860 : ~ @Equation1860 Fin3 reff120_inst.
Proof. unfold Equation1860. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff120_inst, reff120_op in H. discriminate H. Qed.

Lemma reff120_not1884 : ~ @Equation1884 Fin3 reff120_inst.
Proof. unfold Equation1884. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff120_inst, reff120_op in H. discriminate H. Qed.

Lemma reff120_not1885 : ~ @Equation1885 Fin3 reff120_inst.
Proof. unfold Equation1885. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff120_inst, reff120_op in H. discriminate H. Qed.

Lemma reff120_not1887 : ~ @Equation1887 Fin3 reff120_inst.
Proof. unfold Equation1887. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff120_inst, reff120_op in H. discriminate H. Qed.

Lemma reff120_not1888 : ~ @Equation1888 Fin3 reff120_inst.
Proof. unfold Equation1888. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff120_inst, reff120_op in H. discriminate H. Qed.

Lemma reff120_not1894 : ~ @Equation1894 Fin3 reff120_inst.
Proof. unfold Equation1894. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff120_inst, reff120_op in H. discriminate H. Qed.

Lemma reff120_not1895 : ~ @Equation1895 Fin3 reff120_inst.
Proof. unfold Equation1895. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff120_inst, reff120_op in H. discriminate H. Qed.

Lemma reff120_not1897 : ~ @Equation1897 Fin3 reff120_inst.
Proof. unfold Equation1897. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff120_inst, reff120_op in H. discriminate H. Qed.

Lemma reff120_not1898 : ~ @Equation1898 Fin3 reff120_inst.
Proof. unfold Equation1898. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff120_inst, reff120_op in H. discriminate H. Qed.

Lemma reff120_not1921 : ~ @Equation1921 Fin3 reff120_inst.
Proof. unfold Equation1921. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff120_inst, reff120_op in H. discriminate H. Qed.

Lemma reff120_not1922 : ~ @Equation1922 Fin3 reff120_inst.
Proof. unfold Equation1922. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff120_inst, reff120_op in H. discriminate H. Qed.

Lemma reff120_not1924 : ~ @Equation1924 Fin3 reff120_inst.
Proof. unfold Equation1924. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff120_inst, reff120_op in H. discriminate H. Qed.

Lemma reff120_not1925 : ~ @Equation1925 Fin3 reff120_inst.
Proof. unfold Equation1925. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff120_inst, reff120_op in H. discriminate H. Qed.

Lemma reff120_not1931 : ~ @Equation1931 Fin3 reff120_inst.
Proof. unfold Equation1931. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff120_inst, reff120_op in H. discriminate H. Qed.

Lemma reff120_not1932 : ~ @Equation1932 Fin3 reff120_inst.
Proof. unfold Equation1932. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff120_inst, reff120_op in H. discriminate H. Qed.

Lemma reff120_not1934 : ~ @Equation1934 Fin3 reff120_inst.
Proof. unfold Equation1934. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff120_inst, reff120_op in H. discriminate H. Qed.

Lemma reff120_not2035 : ~ @Equation2035 Fin3 reff120_inst.
Proof. unfold Equation2035. intro H. specialize (H F3_1). unfold magma_op, reff120_inst, reff120_op in H. discriminate H. Qed.

Lemma reff120_not2238 : ~ @Equation2238 Fin3 reff120_inst.
Proof. unfold Equation2238. intro H. specialize (H F3_1). unfold magma_op, reff120_inst, reff120_op in H. discriminate H. Qed.

Lemma reff120_not2441 : ~ @Equation2441 Fin3 reff120_inst.
Proof. unfold Equation2441. intro H. specialize (H F3_1). unfold magma_op, reff120_inst, reff120_op in H. discriminate H. Qed.

Lemma reff120_not2644 : ~ @Equation2644 Fin3 reff120_inst.
Proof. unfold Equation2644. intro H. specialize (H F3_1). unfold magma_op, reff120_inst, reff120_op in H. discriminate H. Qed.

Lemma reff120_not2847 : ~ @Equation2847 Fin3 reff120_inst.
Proof. unfold Equation2847. intro H. specialize (H F3_1). unfold magma_op, reff120_inst, reff120_op in H. discriminate H. Qed.

Lemma reff120_not3050 : ~ @Equation3050 Fin3 reff120_inst.
Proof. unfold Equation3050. intro H. specialize (H F3_1). unfold magma_op, reff120_inst, reff120_op in H. discriminate H. Qed.

Lemma reff120_not3254 : ~ @Equation3254 Fin3 reff120_inst.
Proof. unfold Equation3254. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff120_inst, reff120_op in H. discriminate H. Qed.

Lemma reff120_not3255 : ~ @Equation3255 Fin3 reff120_inst.
Proof. unfold Equation3255. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff120_inst, reff120_op in H. discriminate H. Qed.

Lemma reff120_not3258 : ~ @Equation3258 Fin3 reff120_inst.
Proof. unfold Equation3258. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff120_inst, reff120_op in H. discriminate H. Qed.

Lemma reff120_not3259 : ~ @Equation3259 Fin3 reff120_inst.
Proof. unfold Equation3259. intro H. specialize (H F3_1 F3_2). unfold magma_op, reff120_inst, reff120_op in H. discriminate H. Qed.

Lemma reff120_not3261 : ~ @Equation3261 Fin3 reff120_inst.
Proof. unfold Equation3261. intro H. specialize (H F3_1 F3_2). unfold magma_op, reff120_inst, reff120_op in H. discriminate H. Qed.

Lemma reff120_not3262 : ~ @Equation3262 Fin3 reff120_inst.
Proof. unfold Equation3262. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff120_inst, reff120_op in H. discriminate H. Qed.

Lemma reff120_not3268 : ~ @Equation3268 Fin3 reff120_inst.
Proof. unfold Equation3268. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff120_inst, reff120_op in H. discriminate H. Qed.

Lemma reff120_not3269 : ~ @Equation3269 Fin3 reff120_inst.
Proof. unfold Equation3269. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff120_inst, reff120_op in H. discriminate H. Qed.

Lemma reff120_not3271 : ~ @Equation3271 Fin3 reff120_inst.
Proof. unfold Equation3271. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff120_inst, reff120_op in H. discriminate H. Qed.

Lemma reff120_not3272 : ~ @Equation3272 Fin3 reff120_inst.
Proof. unfold Equation3272. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff120_inst, reff120_op in H. discriminate H. Qed.

Lemma reff120_not3278 : ~ @Equation3278 Fin3 reff120_inst.
Proof. unfold Equation3278. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff120_inst, reff120_op in H. discriminate H. Qed.

Lemma reff120_not3279 : ~ @Equation3279 Fin3 reff120_inst.
Proof. unfold Equation3279. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff120_inst, reff120_op in H. discriminate H. Qed.

Lemma reff120_not3281 : ~ @Equation3281 Fin3 reff120_inst.
Proof. unfold Equation3281. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff120_inst, reff120_op in H. discriminate H. Qed.

Lemma reff120_not3306 : ~ @Equation3306 Fin3 reff120_inst.
Proof. unfold Equation3306. intro H. specialize (H F3_2 F3_1). unfold magma_op, reff120_inst, reff120_op in H. discriminate H. Qed.

Lemma reff120_not3308 : ~ @Equation3308 Fin3 reff120_inst.
Proof. unfold Equation3308. intro H. specialize (H F3_1 F3_2). unfold magma_op, reff120_inst, reff120_op in H. discriminate H. Qed.

Lemma reff120_not3309 : ~ @Equation3309 Fin3 reff120_inst.
Proof. unfold Equation3309. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff120_inst, reff120_op in H. discriminate H. Qed.

Lemma reff120_not3316 : ~ @Equation3316 Fin3 reff120_inst.
Proof. unfold Equation3316. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff120_inst, reff120_op in H. discriminate H. Qed.

Lemma reff120_not3318 : ~ @Equation3318 Fin3 reff120_inst.
Proof. unfold Equation3318. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff120_inst, reff120_op in H. discriminate H. Qed.

Lemma reff120_not3342 : ~ @Equation3342 Fin3 reff120_inst.
Proof. unfold Equation3342. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff120_inst, reff120_op in H. discriminate H. Qed.

Lemma reff120_not3343 : ~ @Equation3343 Fin3 reff120_inst.
Proof. unfold Equation3343. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff120_inst, reff120_op in H. discriminate H. Qed.

Lemma reff120_not3345 : ~ @Equation3345 Fin3 reff120_inst.
Proof. unfold Equation3345. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff120_inst, reff120_op in H. discriminate H. Qed.

Lemma reff120_not3346 : ~ @Equation3346 Fin3 reff120_inst.
Proof. unfold Equation3346. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff120_inst, reff120_op in H. discriminate H. Qed.

Lemma reff120_not3352 : ~ @Equation3352 Fin3 reff120_inst.
Proof. unfold Equation3352. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff120_inst, reff120_op in H. discriminate H. Qed.

Lemma reff120_not3353 : ~ @Equation3353 Fin3 reff120_inst.
Proof. unfold Equation3353. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff120_inst, reff120_op in H. discriminate H. Qed.

Lemma reff120_not3456 : ~ @Equation3456 Fin3 reff120_inst.
Proof. unfold Equation3456. intro H. specialize (H F3_1). unfold magma_op, reff120_inst, reff120_op in H. discriminate H. Qed.

Lemma reff120_not3660 : ~ @Equation3660 Fin3 reff120_inst.
Proof. unfold Equation3660. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff120_inst, reff120_op in H. discriminate H. Qed.

Lemma reff120_not3661 : ~ @Equation3661 Fin3 reff120_inst.
Proof. unfold Equation3661. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff120_inst, reff120_op in H. discriminate H. Qed.

Lemma reff120_not3664 : ~ @Equation3664 Fin3 reff120_inst.
Proof. unfold Equation3664. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff120_inst, reff120_op in H. discriminate H. Qed.

Lemma reff120_not3665 : ~ @Equation3665 Fin3 reff120_inst.
Proof. unfold Equation3665. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff120_inst, reff120_op in H. discriminate H. Qed.

Lemma reff120_not3667 : ~ @Equation3667 Fin3 reff120_inst.
Proof. unfold Equation3667. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff120_inst, reff120_op in H. discriminate H. Qed.

Lemma reff120_not3668 : ~ @Equation3668 Fin3 reff120_inst.
Proof. unfold Equation3668. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff120_inst, reff120_op in H. discriminate H. Qed.

Lemma reff120_not3674 : ~ @Equation3674 Fin3 reff120_inst.
Proof. unfold Equation3674. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff120_inst, reff120_op in H. discriminate H. Qed.

Lemma reff120_not3675 : ~ @Equation3675 Fin3 reff120_inst.
Proof. unfold Equation3675. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff120_inst, reff120_op in H. discriminate H. Qed.

Lemma reff120_not3677 : ~ @Equation3677 Fin3 reff120_inst.
Proof. unfold Equation3677. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff120_inst, reff120_op in H. discriminate H. Qed.

Lemma reff120_not3678 : ~ @Equation3678 Fin3 reff120_inst.
Proof. unfold Equation3678. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff120_inst, reff120_op in H. discriminate H. Qed.

Lemma reff120_not3684 : ~ @Equation3684 Fin3 reff120_inst.
Proof. unfold Equation3684. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff120_inst, reff120_op in H. discriminate H. Qed.

Lemma reff120_not3685 : ~ @Equation3685 Fin3 reff120_inst.
Proof. unfold Equation3685. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff120_inst, reff120_op in H. discriminate H. Qed.

Lemma reff120_not3687 : ~ @Equation3687 Fin3 reff120_inst.
Proof. unfold Equation3687. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff120_inst, reff120_op in H. discriminate H. Qed.

Lemma reff120_not3712 : ~ @Equation3712 Fin3 reff120_inst.
Proof. unfold Equation3712. intro H. specialize (H F3_1 F3_0). unfold magma_op, reff120_inst, reff120_op in H. discriminate H. Qed.

Lemma reff120_not3714 : ~ @Equation3714 Fin3 reff120_inst.
Proof. unfold Equation3714. intro H. specialize (H F3_1 F3_0). unfold magma_op, reff120_inst, reff120_op in H. discriminate H. Qed.

Lemma reff120_not3722 : ~ @Equation3722 Fin3 reff120_inst.
Proof. unfold Equation3722. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff120_inst, reff120_op in H. discriminate H. Qed.

Lemma reff120_not3724 : ~ @Equation3724 Fin3 reff120_inst.
Proof. unfold Equation3724. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff120_inst, reff120_op in H. discriminate H. Qed.

Lemma reff120_not3748 : ~ @Equation3748 Fin3 reff120_inst.
Proof. unfold Equation3748. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff120_inst, reff120_op in H. discriminate H. Qed.

Lemma reff120_not3749 : ~ @Equation3749 Fin3 reff120_inst.
Proof. unfold Equation3749. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff120_inst, reff120_op in H. discriminate H. Qed.

Lemma reff120_not3751 : ~ @Equation3751 Fin3 reff120_inst.
Proof. unfold Equation3751. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff120_inst, reff120_op in H. discriminate H. Qed.

Lemma reff120_not3752 : ~ @Equation3752 Fin3 reff120_inst.
Proof. unfold Equation3752. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff120_inst, reff120_op in H. discriminate H. Qed.

Lemma reff120_not3759 : ~ @Equation3759 Fin3 reff120_inst.
Proof. unfold Equation3759. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff120_inst, reff120_op in H. discriminate H. Qed.

Lemma reff120_not3761 : ~ @Equation3761 Fin3 reff120_inst.
Proof. unfold Equation3761. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff120_inst, reff120_op in H. discriminate H. Qed.

Lemma reff120_not3864 : ~ @Equation3864 Fin3 reff120_inst.
Proof. unfold Equation3864. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff120_inst, reff120_op in H. discriminate H. Qed.

Lemma reff120_not3865 : ~ @Equation3865 Fin3 reff120_inst.
Proof. unfold Equation3865. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff120_inst, reff120_op in H. discriminate H. Qed.

Lemma reff120_not3867 : ~ @Equation3867 Fin3 reff120_inst.
Proof. unfold Equation3867. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff120_inst, reff120_op in H. discriminate H. Qed.

Lemma reff120_not3868 : ~ @Equation3868 Fin3 reff120_inst.
Proof. unfold Equation3868. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff120_inst, reff120_op in H. discriminate H. Qed.

Lemma reff120_not3871 : ~ @Equation3871 Fin3 reff120_inst.
Proof. unfold Equation3871. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff120_inst, reff120_op in H. discriminate H. Qed.

Lemma reff120_not3877 : ~ @Equation3877 Fin3 reff120_inst.
Proof. unfold Equation3877. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff120_inst, reff120_op in H. discriminate H. Qed.

Lemma reff120_not3878 : ~ @Equation3878 Fin3 reff120_inst.
Proof. unfold Equation3878. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff120_inst, reff120_op in H. discriminate H. Qed.

Lemma reff120_not3880 : ~ @Equation3880 Fin3 reff120_inst.
Proof. unfold Equation3880. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff120_inst, reff120_op in H. discriminate H. Qed.

Lemma reff120_not3881 : ~ @Equation3881 Fin3 reff120_inst.
Proof. unfold Equation3881. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff120_inst, reff120_op in H. discriminate H. Qed.

Lemma reff120_not3887 : ~ @Equation3887 Fin3 reff120_inst.
Proof. unfold Equation3887. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff120_inst, reff120_op in H. discriminate H. Qed.

Lemma reff120_not3888 : ~ @Equation3888 Fin3 reff120_inst.
Proof. unfold Equation3888. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff120_inst, reff120_op in H. discriminate H. Qed.

Lemma reff120_not3890 : ~ @Equation3890 Fin3 reff120_inst.
Proof. unfold Equation3890. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff120_inst, reff120_op in H. discriminate H. Qed.

Lemma reff120_not3917 : ~ @Equation3917 Fin3 reff120_inst.
Proof. unfold Equation3917. intro H. specialize (H F3_1 F3_0). unfold magma_op, reff120_inst, reff120_op in H. discriminate H. Qed.

Lemma reff120_not3918 : ~ @Equation3918 Fin3 reff120_inst.
Proof. unfold Equation3918. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff120_inst, reff120_op in H. discriminate H. Qed.

Lemma reff120_not3924 : ~ @Equation3924 Fin3 reff120_inst.
Proof. unfold Equation3924. intro H. specialize (H F3_1 F3_0). unfold magma_op, reff120_inst, reff120_op in H. discriminate H. Qed.

Lemma reff120_not3925 : ~ @Equation3925 Fin3 reff120_inst.
Proof. unfold Equation3925. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff120_inst, reff120_op in H. discriminate H. Qed.

Lemma reff120_not3927 : ~ @Equation3927 Fin3 reff120_inst.
Proof. unfold Equation3927. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff120_inst, reff120_op in H. discriminate H. Qed.

Lemma reff120_not3951 : ~ @Equation3951 Fin3 reff120_inst.
Proof. unfold Equation3951. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff120_inst, reff120_op in H. discriminate H. Qed.

Lemma reff120_not3952 : ~ @Equation3952 Fin3 reff120_inst.
Proof. unfold Equation3952. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff120_inst, reff120_op in H. discriminate H. Qed.

Lemma reff120_not3954 : ~ @Equation3954 Fin3 reff120_inst.
Proof. unfold Equation3954. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff120_inst, reff120_op in H. discriminate H. Qed.

Lemma reff120_not3955 : ~ @Equation3955 Fin3 reff120_inst.
Proof. unfold Equation3955. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff120_inst, reff120_op in H. discriminate H. Qed.

Lemma reff120_not3961 : ~ @Equation3961 Fin3 reff120_inst.
Proof. unfold Equation3961. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff120_inst, reff120_op in H. discriminate H. Qed.

Lemma reff120_not3962 : ~ @Equation3962 Fin3 reff120_inst.
Proof. unfold Equation3962. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff120_inst, reff120_op in H. discriminate H. Qed.

Lemma reff120_not3964 : ~ @Equation3964 Fin3 reff120_inst.
Proof. unfold Equation3964. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff120_inst, reff120_op in H. discriminate H. Qed.

Lemma reff120_not4065 : ~ @Equation4065 Fin3 reff120_inst.
Proof. unfold Equation4065. intro H. specialize (H F3_1). unfold magma_op, reff120_inst, reff120_op in H. discriminate H. Qed.

Lemma reff120_not4268 : ~ @Equation4268 Fin3 reff120_inst.
Proof. unfold Equation4268. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff120_inst, reff120_op in H. discriminate H. Qed.

Lemma reff120_not4269 : ~ @Equation4269 Fin3 reff120_inst.
Proof. unfold Equation4269. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff120_inst, reff120_op in H. discriminate H. Qed.

Lemma reff120_not4272 : ~ @Equation4272 Fin3 reff120_inst.
Proof. unfold Equation4272. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff120_inst, reff120_op in H. discriminate H. Qed.

Lemma reff120_not4273 : ~ @Equation4273 Fin3 reff120_inst.
Proof. unfold Equation4273. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff120_inst, reff120_op in H. discriminate H. Qed.

Lemma reff120_not4275 : ~ @Equation4275 Fin3 reff120_inst.
Proof. unfold Equation4275. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff120_inst, reff120_op in H. discriminate H. Qed.

Lemma reff120_not4276 : ~ @Equation4276 Fin3 reff120_inst.
Proof. unfold Equation4276. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff120_inst, reff120_op in H. discriminate H. Qed.

Lemma reff120_not4283 : ~ @Equation4283 Fin3 reff120_inst.
Proof. unfold Equation4283. intro H. specialize (H F3_1 F3_2). unfold magma_op, reff120_inst, reff120_op in H. discriminate H. Qed.

Lemma reff120_not4284 : ~ @Equation4284 Fin3 reff120_inst.
Proof. unfold Equation4284. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff120_inst, reff120_op in H. discriminate H. Qed.

Lemma reff120_not4290 : ~ @Equation4290 Fin3 reff120_inst.
Proof. unfold Equation4290. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff120_inst, reff120_op in H. discriminate H. Qed.

Lemma reff120_not4291 : ~ @Equation4291 Fin3 reff120_inst.
Proof. unfold Equation4291. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff120_inst, reff120_op in H. discriminate H. Qed.

Lemma reff120_not4293 : ~ @Equation4293 Fin3 reff120_inst.
Proof. unfold Equation4293. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff120_inst, reff120_op in H. discriminate H. Qed.

Lemma reff120_not4314 : ~ @Equation4314 Fin3 reff120_inst.
Proof. unfold Equation4314. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff120_inst, reff120_op in H. discriminate H. Qed.

Lemma reff120_not4320 : ~ @Equation4320 Fin3 reff120_inst.
Proof. unfold Equation4320. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff120_inst, reff120_op in H. discriminate H. Qed.

Lemma reff120_not4321 : ~ @Equation4321 Fin3 reff120_inst.
Proof. unfold Equation4321. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff120_inst, reff120_op in H. discriminate H. Qed.

Lemma reff120_not4343 : ~ @Equation4343 Fin3 reff120_inst.
Proof. unfold Equation4343. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff120_inst, reff120_op in H. discriminate H. Qed.

Lemma reff120_not4380 : ~ @Equation4380 Fin3 reff120_inst.
Proof. unfold Equation4380. intro H. specialize (H F3_1). unfold magma_op, reff120_inst, reff120_op in H. discriminate H. Qed.

Lemma reff120_not4583 : ~ @Equation4583 Fin3 reff120_inst.
Proof. unfold Equation4583. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff120_inst, reff120_op in H. discriminate H. Qed.

Lemma reff120_not4584 : ~ @Equation4584 Fin3 reff120_inst.
Proof. unfold Equation4584. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff120_inst, reff120_op in H. discriminate H. Qed.

Lemma reff120_not4585 : ~ @Equation4585 Fin3 reff120_inst.
Proof. unfold Equation4585. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff120_inst, reff120_op in H. discriminate H. Qed.

Lemma reff120_not4587 : ~ @Equation4587 Fin3 reff120_inst.
Proof. unfold Equation4587. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff120_inst, reff120_op in H. discriminate H. Qed.

Lemma reff120_not4588 : ~ @Equation4588 Fin3 reff120_inst.
Proof. unfold Equation4588. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff120_inst, reff120_op in H. discriminate H. Qed.

Lemma reff120_not4590 : ~ @Equation4590 Fin3 reff120_inst.
Proof. unfold Equation4590. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff120_inst, reff120_op in H. discriminate H. Qed.

Lemma reff120_not4591 : ~ @Equation4591 Fin3 reff120_inst.
Proof. unfold Equation4591. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff120_inst, reff120_op in H. discriminate H. Qed.

Lemma reff120_not4599 : ~ @Equation4599 Fin3 reff120_inst.
Proof. unfold Equation4599. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff120_inst, reff120_op in H. discriminate H. Qed.

Lemma reff120_not4605 : ~ @Equation4605 Fin3 reff120_inst.
Proof. unfold Equation4605. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff120_inst, reff120_op in H. discriminate H. Qed.

Lemma reff120_not4606 : ~ @Equation4606 Fin3 reff120_inst.
Proof. unfold Equation4606. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff120_inst, reff120_op in H. discriminate H. Qed.

Lemma reff120_not4608 : ~ @Equation4608 Fin3 reff120_inst.
Proof. unfold Equation4608. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff120_inst, reff120_op in H. discriminate H. Qed.

Lemma reff120_not4629 : ~ @Equation4629 Fin3 reff120_inst.
Proof. unfold Equation4629. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff120_inst, reff120_op in H. discriminate H. Qed.

Lemma reff120_not4635 : ~ @Equation4635 Fin3 reff120_inst.
Proof. unfold Equation4635. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff120_inst, reff120_op in H. discriminate H. Qed.

Lemma reff120_not4636 : ~ @Equation4636 Fin3 reff120_inst.
Proof. unfold Equation4636. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff120_inst, reff120_op in H. discriminate H. Qed.

Lemma reff120_not4658 : ~ @Equation4658 Fin3 reff120_inst.
Proof. unfold Equation4658. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff120_inst, reff120_op in H. discriminate H. Qed.

(** ---- reff126 (Fin3) ---- *)

Definition reff126_op (x y : Fin3) : Fin3 :=
  match x, y with
  | F3_0, F3_0 => F3_0 | F3_0, F3_1 => F3_2 | F3_0, F3_2 => F3_1
  | F3_1, F3_0 => F3_2 | F3_1, F3_1 => F3_1 | F3_1, F3_2 => F3_0
  | F3_2, F3_0 => F3_0 | F3_2, F3_1 => F3_2 | F3_2, F3_2 => F3_1
  end.

#[local] Instance reff126_inst : Magma Fin3 := {| magma_op := reff126_op |}.

Lemma reff126_sat16 : @Equation16 Fin3 reff126_inst.
Proof. unfold Equation16, magma_op, reff126_inst, reff126_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff126_sat817 : @Equation817 Fin3 reff126_inst.
Proof. unfold Equation817, magma_op, reff126_inst, reff126_op. intros x. destruct x; reflexivity. Qed.

Lemma reff126_sat1325 : @Equation1325 Fin3 reff126_inst.
Proof. unfold Equation1325, magma_op, reff126_inst, reff126_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff126_sat2137 : @Equation2137 Fin3 reff126_inst.
Proof. unfold Equation2137, magma_op, reff126_inst, reff126_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff126_sat3659 : @Equation3659 Fin3 reff126_inst.
Proof. unfold Equation3659, magma_op, reff126_inst, reff126_op. intros x. destruct x; reflexivity. Qed.

Lemma reff126_sat4118 : @Equation4118 Fin3 reff126_inst.
Proof. unfold Equation4118, magma_op, reff126_inst, reff126_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff126_not47 : ~ @Equation47 Fin3 reff126_inst.
Proof. unfold Equation47. intro H. specialize (H F3_2). unfold magma_op, reff126_inst, reff126_op in H. discriminate H. Qed.

Lemma reff126_not99 : ~ @Equation99 Fin3 reff126_inst.
Proof. unfold Equation99. intro H. specialize (H F3_2). unfold magma_op, reff126_inst, reff126_op in H. discriminate H. Qed.

Lemma reff126_not151 : ~ @Equation151 Fin3 reff126_inst.
Proof. unfold Equation151. intro H. specialize (H F3_2). unfold magma_op, reff126_inst, reff126_op in H. discriminate H. Qed.

Lemma reff126_not203 : ~ @Equation203 Fin3 reff126_inst.
Proof. unfold Equation203. intro H. specialize (H F3_2). unfold magma_op, reff126_inst, reff126_op in H. discriminate H. Qed.

Lemma reff126_not255 : ~ @Equation255 Fin3 reff126_inst.
Proof. unfold Equation255. intro H. specialize (H F3_2). unfold magma_op, reff126_inst, reff126_op in H. discriminate H. Qed.

Lemma reff126_not307 : ~ @Equation307 Fin3 reff126_inst.
Proof. unfold Equation307. intro H. specialize (H F3_2). unfold magma_op, reff126_inst, reff126_op in H. discriminate H. Qed.

Lemma reff126_not359 : ~ @Equation359 Fin3 reff126_inst.
Proof. unfold Equation359. intro H. specialize (H F3_2). unfold magma_op, reff126_inst, reff126_op in H. discriminate H. Qed.

Lemma reff126_not412 : ~ @Equation412 Fin3 reff126_inst.
Proof. unfold Equation412. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff126_inst, reff126_op in H. discriminate H. Qed.

Lemma reff126_not413 : ~ @Equation413 Fin3 reff126_inst.
Proof. unfold Equation413. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff126_inst, reff126_op in H. discriminate H. Qed.

Lemma reff126_not414 : ~ @Equation414 Fin3 reff126_inst.
Proof. unfold Equation414. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff126_inst, reff126_op in H. discriminate H. Qed.

Lemma reff126_not416 : ~ @Equation416 Fin3 reff126_inst.
Proof. unfold Equation416. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff126_inst, reff126_op in H. discriminate H. Qed.

Lemma reff126_not417 : ~ @Equation417 Fin3 reff126_inst.
Proof. unfold Equation417. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff126_inst, reff126_op in H. discriminate H. Qed.

Lemma reff126_not420 : ~ @Equation420 Fin3 reff126_inst.
Proof. unfold Equation420. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff126_inst, reff126_op in H. discriminate H. Qed.

Lemma reff126_not426 : ~ @Equation426 Fin3 reff126_inst.
Proof. unfold Equation426. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff126_inst, reff126_op in H. discriminate H. Qed.

Lemma reff126_not427 : ~ @Equation427 Fin3 reff126_inst.
Proof. unfold Equation427. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff126_inst, reff126_op in H. discriminate H. Qed.

Lemma reff126_not429 : ~ @Equation429 Fin3 reff126_inst.
Proof. unfold Equation429. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff126_inst, reff126_op in H. discriminate H. Qed.

Lemma reff126_not430 : ~ @Equation430 Fin3 reff126_inst.
Proof. unfold Equation430. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff126_inst, reff126_op in H. discriminate H. Qed.

Lemma reff126_not437 : ~ @Equation437 Fin3 reff126_inst.
Proof. unfold Equation437. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff126_inst, reff126_op in H. discriminate H. Qed.

Lemma reff126_not439 : ~ @Equation439 Fin3 reff126_inst.
Proof. unfold Equation439. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff126_inst, reff126_op in H. discriminate H. Qed.

Lemma reff126_not440 : ~ @Equation440 Fin3 reff126_inst.
Proof. unfold Equation440. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff126_inst, reff126_op in H. discriminate H. Qed.

Lemma reff126_not463 : ~ @Equation463 Fin3 reff126_inst.
Proof. unfold Equation463. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff126_inst, reff126_op in H. discriminate H. Qed.

Lemma reff126_not464 : ~ @Equation464 Fin3 reff126_inst.
Proof. unfold Equation464. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff126_inst, reff126_op in H. discriminate H. Qed.

Lemma reff126_not467 : ~ @Equation467 Fin3 reff126_inst.
Proof. unfold Equation467. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff126_inst, reff126_op in H. discriminate H. Qed.

Lemma reff126_not473 : ~ @Equation473 Fin3 reff126_inst.
Proof. unfold Equation473. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff126_inst, reff126_op in H. discriminate H. Qed.

Lemma reff126_not474 : ~ @Equation474 Fin3 reff126_inst.
Proof. unfold Equation474. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff126_inst, reff126_op in H. discriminate H. Qed.

Lemma reff126_not476 : ~ @Equation476 Fin3 reff126_inst.
Proof. unfold Equation476. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff126_inst, reff126_op in H. discriminate H. Qed.

Lemma reff126_not477 : ~ @Equation477 Fin3 reff126_inst.
Proof. unfold Equation477. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff126_inst, reff126_op in H. discriminate H. Qed.

Lemma reff126_not501 : ~ @Equation501 Fin3 reff126_inst.
Proof. unfold Equation501. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff126_inst, reff126_op in H. discriminate H. Qed.

Lemma reff126_not503 : ~ @Equation503 Fin3 reff126_inst.
Proof. unfold Equation503. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff126_inst, reff126_op in H. discriminate H. Qed.

Lemma reff126_not504 : ~ @Equation504 Fin3 reff126_inst.
Proof. unfold Equation504. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff126_inst, reff126_op in H. discriminate H. Qed.

Lemma reff126_not510 : ~ @Equation510 Fin3 reff126_inst.
Proof. unfold Equation510. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff126_inst, reff126_op in H. discriminate H. Qed.

Lemma reff126_not511 : ~ @Equation511 Fin3 reff126_inst.
Proof. unfold Equation511. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff126_inst, reff126_op in H. discriminate H. Qed.

Lemma reff126_not614 : ~ @Equation614 Fin3 reff126_inst.
Proof. unfold Equation614. intro H. specialize (H F3_2). unfold magma_op, reff126_inst, reff126_op in H. discriminate H. Qed.

Lemma reff126_not818 : ~ @Equation818 Fin3 reff126_inst.
Proof. unfold Equation818. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff126_inst, reff126_op in H. discriminate H. Qed.

Lemma reff126_not819 : ~ @Equation819 Fin3 reff126_inst.
Proof. unfold Equation819. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff126_inst, reff126_op in H. discriminate H. Qed.

Lemma reff126_not820 : ~ @Equation820 Fin3 reff126_inst.
Proof. unfold Equation820. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff126_inst, reff126_op in H. discriminate H. Qed.

Lemma reff126_not822 : ~ @Equation822 Fin3 reff126_inst.
Proof. unfold Equation822. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff126_inst, reff126_op in H. discriminate H. Qed.

Lemma reff126_not823 : ~ @Equation823 Fin3 reff126_inst.
Proof. unfold Equation823. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff126_inst, reff126_op in H. discriminate H. Qed.

Lemma reff126_not825 : ~ @Equation825 Fin3 reff126_inst.
Proof. unfold Equation825. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff126_inst, reff126_op in H. discriminate H. Qed.

Lemma reff126_not826 : ~ @Equation826 Fin3 reff126_inst.
Proof. unfold Equation826. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff126_inst, reff126_op in H. discriminate H. Qed.

Lemma reff126_not832 : ~ @Equation832 Fin3 reff126_inst.
Proof. unfold Equation832. intro H. specialize (H F3_1 F3_0). unfold magma_op, reff126_inst, reff126_op in H. discriminate H. Qed.

Lemma reff126_not833 : ~ @Equation833 Fin3 reff126_inst.
Proof. unfold Equation833. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff126_inst, reff126_op in H. discriminate H. Qed.

Lemma reff126_not835 : ~ @Equation835 Fin3 reff126_inst.
Proof. unfold Equation835. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff126_inst, reff126_op in H. discriminate H. Qed.

Lemma reff126_not836 : ~ @Equation836 Fin3 reff126_inst.
Proof. unfold Equation836. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff126_inst, reff126_op in H. discriminate H. Qed.

Lemma reff126_not842 : ~ @Equation842 Fin3 reff126_inst.
Proof. unfold Equation842. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff126_inst, reff126_op in H. discriminate H. Qed.

Lemma reff126_not843 : ~ @Equation843 Fin3 reff126_inst.
Proof. unfold Equation843. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff126_inst, reff126_op in H. discriminate H. Qed.

Lemma reff126_not845 : ~ @Equation845 Fin3 reff126_inst.
Proof. unfold Equation845. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff126_inst, reff126_op in H. discriminate H. Qed.

Lemma reff126_not846 : ~ @Equation846 Fin3 reff126_inst.
Proof. unfold Equation846. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff126_inst, reff126_op in H. discriminate H. Qed.

Lemma reff126_not869 : ~ @Equation869 Fin3 reff126_inst.
Proof. unfold Equation869. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff126_inst, reff126_op in H. discriminate H. Qed.

Lemma reff126_not870 : ~ @Equation870 Fin3 reff126_inst.
Proof. unfold Equation870. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff126_inst, reff126_op in H. discriminate H. Qed.

Lemma reff126_not872 : ~ @Equation872 Fin3 reff126_inst.
Proof. unfold Equation872. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff126_inst, reff126_op in H. discriminate H. Qed.

Lemma reff126_not873 : ~ @Equation873 Fin3 reff126_inst.
Proof. unfold Equation873. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff126_inst, reff126_op in H. discriminate H. Qed.

Lemma reff126_not879 : ~ @Equation879 Fin3 reff126_inst.
Proof. unfold Equation879. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff126_inst, reff126_op in H. discriminate H. Qed.

Lemma reff126_not880 : ~ @Equation880 Fin3 reff126_inst.
Proof. unfold Equation880. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff126_inst, reff126_op in H. discriminate H. Qed.

Lemma reff126_not882 : ~ @Equation882 Fin3 reff126_inst.
Proof. unfold Equation882. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff126_inst, reff126_op in H. discriminate H. Qed.

Lemma reff126_not883 : ~ @Equation883 Fin3 reff126_inst.
Proof. unfold Equation883. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff126_inst, reff126_op in H. discriminate H. Qed.

Lemma reff126_not906 : ~ @Equation906 Fin3 reff126_inst.
Proof. unfold Equation906. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff126_inst, reff126_op in H. discriminate H. Qed.

Lemma reff126_not907 : ~ @Equation907 Fin3 reff126_inst.
Proof. unfold Equation907. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff126_inst, reff126_op in H. discriminate H. Qed.

Lemma reff126_not909 : ~ @Equation909 Fin3 reff126_inst.
Proof. unfold Equation909. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff126_inst, reff126_op in H. discriminate H. Qed.

Lemma reff126_not910 : ~ @Equation910 Fin3 reff126_inst.
Proof. unfold Equation910. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff126_inst, reff126_op in H. discriminate H. Qed.

Lemma reff126_not916 : ~ @Equation916 Fin3 reff126_inst.
Proof. unfold Equation916. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff126_inst, reff126_op in H. discriminate H. Qed.

Lemma reff126_not917 : ~ @Equation917 Fin3 reff126_inst.
Proof. unfold Equation917. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff126_inst, reff126_op in H. discriminate H. Qed.

Lemma reff126_not919 : ~ @Equation919 Fin3 reff126_inst.
Proof. unfold Equation919. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff126_inst, reff126_op in H. discriminate H. Qed.

Lemma reff126_not1021 : ~ @Equation1021 Fin3 reff126_inst.
Proof. unfold Equation1021. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff126_inst, reff126_op in H. discriminate H. Qed.

Lemma reff126_not1022 : ~ @Equation1022 Fin3 reff126_inst.
Proof. unfold Equation1022. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff126_inst, reff126_op in H. discriminate H. Qed.

Lemma reff126_not1023 : ~ @Equation1023 Fin3 reff126_inst.
Proof. unfold Equation1023. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff126_inst, reff126_op in H. discriminate H. Qed.

Lemma reff126_not1025 : ~ @Equation1025 Fin3 reff126_inst.
Proof. unfold Equation1025. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff126_inst, reff126_op in H. discriminate H. Qed.

Lemma reff126_not1026 : ~ @Equation1026 Fin3 reff126_inst.
Proof. unfold Equation1026. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff126_inst, reff126_op in H. discriminate H. Qed.

Lemma reff126_not1028 : ~ @Equation1028 Fin3 reff126_inst.
Proof. unfold Equation1028. intro H. specialize (H F3_1 F3_0). unfold magma_op, reff126_inst, reff126_op in H. discriminate H. Qed.

Lemma reff126_not1029 : ~ @Equation1029 Fin3 reff126_inst.
Proof. unfold Equation1029. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff126_inst, reff126_op in H. discriminate H. Qed.

Lemma reff126_not1035 : ~ @Equation1035 Fin3 reff126_inst.
Proof. unfold Equation1035. intro H. specialize (H F3_1 F3_0). unfold magma_op, reff126_inst, reff126_op in H. discriminate H. Qed.

Lemma reff126_not1036 : ~ @Equation1036 Fin3 reff126_inst.
Proof. unfold Equation1036. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff126_inst, reff126_op in H. discriminate H. Qed.

Lemma reff126_not1038 : ~ @Equation1038 Fin3 reff126_inst.
Proof. unfold Equation1038. intro H. specialize (H F3_1 F3_2). unfold magma_op, reff126_inst, reff126_op in H. discriminate H. Qed.

Lemma reff126_not1039 : ~ @Equation1039 Fin3 reff126_inst.
Proof. unfold Equation1039. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff126_inst, reff126_op in H. discriminate H. Qed.

Lemma reff126_not1046 : ~ @Equation1046 Fin3 reff126_inst.
Proof. unfold Equation1046. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff126_inst, reff126_op in H. discriminate H. Qed.

Lemma reff126_not1048 : ~ @Equation1048 Fin3 reff126_inst.
Proof. unfold Equation1048. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff126_inst, reff126_op in H. discriminate H. Qed.

Lemma reff126_not1049 : ~ @Equation1049 Fin3 reff126_inst.
Proof. unfold Equation1049. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff126_inst, reff126_op in H. discriminate H. Qed.

Lemma reff126_not1072 : ~ @Equation1072 Fin3 reff126_inst.
Proof. unfold Equation1072. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff126_inst, reff126_op in H. discriminate H. Qed.

Lemma reff126_not1073 : ~ @Equation1073 Fin3 reff126_inst.
Proof. unfold Equation1073. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff126_inst, reff126_op in H. discriminate H. Qed.

Lemma reff126_not1076 : ~ @Equation1076 Fin3 reff126_inst.
Proof. unfold Equation1076. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff126_inst, reff126_op in H. discriminate H. Qed.

Lemma reff126_not1082 : ~ @Equation1082 Fin3 reff126_inst.
Proof. unfold Equation1082. intro H. specialize (H F3_2 F3_1). unfold magma_op, reff126_inst, reff126_op in H. discriminate H. Qed.

Lemma reff126_not1083 : ~ @Equation1083 Fin3 reff126_inst.
Proof. unfold Equation1083. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff126_inst, reff126_op in H. discriminate H. Qed.

Lemma reff126_not1085 : ~ @Equation1085 Fin3 reff126_inst.
Proof. unfold Equation1085. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff126_inst, reff126_op in H. discriminate H. Qed.

Lemma reff126_not1086 : ~ @Equation1086 Fin3 reff126_inst.
Proof. unfold Equation1086. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff126_inst, reff126_op in H. discriminate H. Qed.

Lemma reff126_not1109 : ~ @Equation1109 Fin3 reff126_inst.
Proof. unfold Equation1109. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff126_inst, reff126_op in H. discriminate H. Qed.

Lemma reff126_not1110 : ~ @Equation1110 Fin3 reff126_inst.
Proof. unfold Equation1110. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff126_inst, reff126_op in H. discriminate H. Qed.

Lemma reff126_not1112 : ~ @Equation1112 Fin3 reff126_inst.
Proof. unfold Equation1112. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff126_inst, reff126_op in H. discriminate H. Qed.

Lemma reff126_not1113 : ~ @Equation1113 Fin3 reff126_inst.
Proof. unfold Equation1113. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff126_inst, reff126_op in H. discriminate H. Qed.

Lemma reff126_not1119 : ~ @Equation1119 Fin3 reff126_inst.
Proof. unfold Equation1119. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff126_inst, reff126_op in H. discriminate H. Qed.

Lemma reff126_not1120 : ~ @Equation1120 Fin3 reff126_inst.
Proof. unfold Equation1120. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff126_inst, reff126_op in H. discriminate H. Qed.

Lemma reff126_not1224 : ~ @Equation1224 Fin3 reff126_inst.
Proof. unfold Equation1224. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff126_inst, reff126_op in H. discriminate H. Qed.

Lemma reff126_not1225 : ~ @Equation1225 Fin3 reff126_inst.
Proof. unfold Equation1225. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff126_inst, reff126_op in H. discriminate H. Qed.

Lemma reff126_not1226 : ~ @Equation1226 Fin3 reff126_inst.
Proof. unfold Equation1226. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff126_inst, reff126_op in H. discriminate H. Qed.

Lemma reff126_not1228 : ~ @Equation1228 Fin3 reff126_inst.
Proof. unfold Equation1228. intro H. specialize (H F3_1 F3_0). unfold magma_op, reff126_inst, reff126_op in H. discriminate H. Qed.

Lemma reff126_not1229 : ~ @Equation1229 Fin3 reff126_inst.
Proof. unfold Equation1229. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff126_inst, reff126_op in H. discriminate H. Qed.

Lemma reff126_not1231 : ~ @Equation1231 Fin3 reff126_inst.
Proof. unfold Equation1231. intro H. specialize (H F3_1 F3_0). unfold magma_op, reff126_inst, reff126_op in H. discriminate H. Qed.

Lemma reff126_not1232 : ~ @Equation1232 Fin3 reff126_inst.
Proof. unfold Equation1232. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff126_inst, reff126_op in H. discriminate H. Qed.

Lemma reff126_not1238 : ~ @Equation1238 Fin3 reff126_inst.
Proof. unfold Equation1238. intro H. specialize (H F3_1 F3_0). unfold magma_op, reff126_inst, reff126_op in H. discriminate H. Qed.

Lemma reff126_not1239 : ~ @Equation1239 Fin3 reff126_inst.
Proof. unfold Equation1239. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff126_inst, reff126_op in H. discriminate H. Qed.

Lemma reff126_not1241 : ~ @Equation1241 Fin3 reff126_inst.
Proof. unfold Equation1241. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff126_inst, reff126_op in H. discriminate H. Qed.

Lemma reff126_not1242 : ~ @Equation1242 Fin3 reff126_inst.
Proof. unfold Equation1242. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff126_inst, reff126_op in H. discriminate H. Qed.

Lemma reff126_not1248 : ~ @Equation1248 Fin3 reff126_inst.
Proof. unfold Equation1248. intro H. specialize (H F3_1 F3_0). unfold magma_op, reff126_inst, reff126_op in H. discriminate H. Qed.

Lemma reff126_not1249 : ~ @Equation1249 Fin3 reff126_inst.
Proof. unfold Equation1249. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff126_inst, reff126_op in H. discriminate H. Qed.

Lemma reff126_not1251 : ~ @Equation1251 Fin3 reff126_inst.
Proof. unfold Equation1251. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff126_inst, reff126_op in H. discriminate H. Qed.

Lemma reff126_not1252 : ~ @Equation1252 Fin3 reff126_inst.
Proof. unfold Equation1252. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff126_inst, reff126_op in H. discriminate H. Qed.

Lemma reff126_not1275 : ~ @Equation1275 Fin3 reff126_inst.
Proof. unfold Equation1275. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff126_inst, reff126_op in H. discriminate H. Qed.

Lemma reff126_not1276 : ~ @Equation1276 Fin3 reff126_inst.
Proof. unfold Equation1276. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff126_inst, reff126_op in H. discriminate H. Qed.

Lemma reff126_not1278 : ~ @Equation1278 Fin3 reff126_inst.
Proof. unfold Equation1278. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff126_inst, reff126_op in H. discriminate H. Qed.

Lemma reff126_not1279 : ~ @Equation1279 Fin3 reff126_inst.
Proof. unfold Equation1279. intro H. specialize (H F3_1 F3_0). unfold magma_op, reff126_inst, reff126_op in H. discriminate H. Qed.

Lemma reff126_not1285 : ~ @Equation1285 Fin3 reff126_inst.
Proof. unfold Equation1285. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff126_inst, reff126_op in H. discriminate H. Qed.

Lemma reff126_not1286 : ~ @Equation1286 Fin3 reff126_inst.
Proof. unfold Equation1286. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff126_inst, reff126_op in H. discriminate H. Qed.

Lemma reff126_not1288 : ~ @Equation1288 Fin3 reff126_inst.
Proof. unfold Equation1288. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff126_inst, reff126_op in H. discriminate H. Qed.

Lemma reff126_not1289 : ~ @Equation1289 Fin3 reff126_inst.
Proof. unfold Equation1289. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff126_inst, reff126_op in H. discriminate H. Qed.

Lemma reff126_not1312 : ~ @Equation1312 Fin3 reff126_inst.
Proof. unfold Equation1312. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff126_inst, reff126_op in H. discriminate H. Qed.

Lemma reff126_not1313 : ~ @Equation1313 Fin3 reff126_inst.
Proof. unfold Equation1313. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff126_inst, reff126_op in H. discriminate H. Qed.

Lemma reff126_not1315 : ~ @Equation1315 Fin3 reff126_inst.
Proof. unfold Equation1315. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff126_inst, reff126_op in H. discriminate H. Qed.

Lemma reff126_not1316 : ~ @Equation1316 Fin3 reff126_inst.
Proof. unfold Equation1316. intro H. specialize (H F3_1 F3_0). unfold magma_op, reff126_inst, reff126_op in H. discriminate H. Qed.

Lemma reff126_not1322 : ~ @Equation1322 Fin3 reff126_inst.
Proof. unfold Equation1322. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff126_inst, reff126_op in H. discriminate H. Qed.

Lemma reff126_not1323 : ~ @Equation1323 Fin3 reff126_inst.
Proof. unfold Equation1323. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff126_inst, reff126_op in H. discriminate H. Qed.

Lemma reff126_not1426 : ~ @Equation1426 Fin3 reff126_inst.
Proof. unfold Equation1426. intro H. specialize (H F3_2). unfold magma_op, reff126_inst, reff126_op in H. discriminate H. Qed.

Lemma reff126_not1630 : ~ @Equation1630 Fin3 reff126_inst.
Proof. unfold Equation1630. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff126_inst, reff126_op in H. discriminate H. Qed.

Lemma reff126_not1631 : ~ @Equation1631 Fin3 reff126_inst.
Proof. unfold Equation1631. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff126_inst, reff126_op in H. discriminate H. Qed.

Lemma reff126_not1632 : ~ @Equation1632 Fin3 reff126_inst.
Proof. unfold Equation1632. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff126_inst, reff126_op in H. discriminate H. Qed.

Lemma reff126_not1634 : ~ @Equation1634 Fin3 reff126_inst.
Proof. unfold Equation1634. intro H. specialize (H F3_1 F3_0). unfold magma_op, reff126_inst, reff126_op in H. discriminate H. Qed.

Lemma reff126_not1635 : ~ @Equation1635 Fin3 reff126_inst.
Proof. unfold Equation1635. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff126_inst, reff126_op in H. discriminate H. Qed.

Lemma reff126_not1637 : ~ @Equation1637 Fin3 reff126_inst.
Proof. unfold Equation1637. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff126_inst, reff126_op in H. discriminate H. Qed.

Lemma reff126_not1638 : ~ @Equation1638 Fin3 reff126_inst.
Proof. unfold Equation1638. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff126_inst, reff126_op in H. discriminate H. Qed.

Lemma reff126_not1644 : ~ @Equation1644 Fin3 reff126_inst.
Proof. unfold Equation1644. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff126_inst, reff126_op in H. discriminate H. Qed.

Lemma reff126_not1645 : ~ @Equation1645 Fin3 reff126_inst.
Proof. unfold Equation1645. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff126_inst, reff126_op in H. discriminate H. Qed.

Lemma reff126_not1648 : ~ @Equation1648 Fin3 reff126_inst.
Proof. unfold Equation1648. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff126_inst, reff126_op in H. discriminate H. Qed.

Lemma reff126_not1654 : ~ @Equation1654 Fin3 reff126_inst.
Proof. unfold Equation1654. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff126_inst, reff126_op in H. discriminate H. Qed.

Lemma reff126_not1655 : ~ @Equation1655 Fin3 reff126_inst.
Proof. unfold Equation1655. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff126_inst, reff126_op in H. discriminate H. Qed.

Lemma reff126_not1657 : ~ @Equation1657 Fin3 reff126_inst.
Proof. unfold Equation1657. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff126_inst, reff126_op in H. discriminate H. Qed.

Lemma reff126_not1658 : ~ @Equation1658 Fin3 reff126_inst.
Proof. unfold Equation1658. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff126_inst, reff126_op in H. discriminate H. Qed.

Lemma reff126_not1681 : ~ @Equation1681 Fin3 reff126_inst.
Proof. unfold Equation1681. intro H. specialize (H F3_1 F3_0). unfold magma_op, reff126_inst, reff126_op in H. discriminate H. Qed.

Lemma reff126_not1682 : ~ @Equation1682 Fin3 reff126_inst.
Proof. unfold Equation1682. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff126_inst, reff126_op in H. discriminate H. Qed.

Lemma reff126_not1684 : ~ @Equation1684 Fin3 reff126_inst.
Proof. unfold Equation1684. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff126_inst, reff126_op in H. discriminate H. Qed.

Lemma reff126_not1685 : ~ @Equation1685 Fin3 reff126_inst.
Proof. unfold Equation1685. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff126_inst, reff126_op in H. discriminate H. Qed.

Lemma reff126_not1692 : ~ @Equation1692 Fin3 reff126_inst.
Proof. unfold Equation1692. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff126_inst, reff126_op in H. discriminate H. Qed.

Lemma reff126_not1694 : ~ @Equation1694 Fin3 reff126_inst.
Proof. unfold Equation1694. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff126_inst, reff126_op in H. discriminate H. Qed.

Lemma reff126_not1695 : ~ @Equation1695 Fin3 reff126_inst.
Proof. unfold Equation1695. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff126_inst, reff126_op in H. discriminate H. Qed.

Lemma reff126_not1718 : ~ @Equation1718 Fin3 reff126_inst.
Proof. unfold Equation1718. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff126_inst, reff126_op in H. discriminate H. Qed.

Lemma reff126_not1719 : ~ @Equation1719 Fin3 reff126_inst.
Proof. unfold Equation1719. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff126_inst, reff126_op in H. discriminate H. Qed.

Lemma reff126_not1721 : ~ @Equation1721 Fin3 reff126_inst.
Proof. unfold Equation1721. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff126_inst, reff126_op in H. discriminate H. Qed.

Lemma reff126_not1722 : ~ @Equation1722 Fin3 reff126_inst.
Proof. unfold Equation1722. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff126_inst, reff126_op in H. discriminate H. Qed.

Lemma reff126_not1728 : ~ @Equation1728 Fin3 reff126_inst.
Proof. unfold Equation1728. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff126_inst, reff126_op in H. discriminate H. Qed.

Lemma reff126_not1729 : ~ @Equation1729 Fin3 reff126_inst.
Proof. unfold Equation1729. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff126_inst, reff126_op in H. discriminate H. Qed.

Lemma reff126_not1833 : ~ @Equation1833 Fin3 reff126_inst.
Proof. unfold Equation1833. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff126_inst, reff126_op in H. discriminate H. Qed.

Lemma reff126_not1834 : ~ @Equation1834 Fin3 reff126_inst.
Proof. unfold Equation1834. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff126_inst, reff126_op in H. discriminate H. Qed.

Lemma reff126_not1835 : ~ @Equation1835 Fin3 reff126_inst.
Proof. unfold Equation1835. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff126_inst, reff126_op in H. discriminate H. Qed.

Lemma reff126_not1837 : ~ @Equation1837 Fin3 reff126_inst.
Proof. unfold Equation1837. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff126_inst, reff126_op in H. discriminate H. Qed.

Lemma reff126_not1838 : ~ @Equation1838 Fin3 reff126_inst.
Proof. unfold Equation1838. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff126_inst, reff126_op in H. discriminate H. Qed.

Lemma reff126_not1841 : ~ @Equation1841 Fin3 reff126_inst.
Proof. unfold Equation1841. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff126_inst, reff126_op in H. discriminate H. Qed.

Lemma reff126_not1847 : ~ @Equation1847 Fin3 reff126_inst.
Proof. unfold Equation1847. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff126_inst, reff126_op in H. discriminate H. Qed.

Lemma reff126_not1848 : ~ @Equation1848 Fin3 reff126_inst.
Proof. unfold Equation1848. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff126_inst, reff126_op in H. discriminate H. Qed.

Lemma reff126_not1850 : ~ @Equation1850 Fin3 reff126_inst.
Proof. unfold Equation1850. intro H. specialize (H F3_2 F3_1). unfold magma_op, reff126_inst, reff126_op in H. discriminate H. Qed.

Lemma reff126_not1851 : ~ @Equation1851 Fin3 reff126_inst.
Proof. unfold Equation1851. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff126_inst, reff126_op in H. discriminate H. Qed.

Lemma reff126_not1857 : ~ @Equation1857 Fin3 reff126_inst.
Proof. unfold Equation1857. intro H. specialize (H F3_1 F3_0). unfold magma_op, reff126_inst, reff126_op in H. discriminate H. Qed.

Lemma reff126_not1858 : ~ @Equation1858 Fin3 reff126_inst.
Proof. unfold Equation1858. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff126_inst, reff126_op in H. discriminate H. Qed.

Lemma reff126_not1860 : ~ @Equation1860 Fin3 reff126_inst.
Proof. unfold Equation1860. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff126_inst, reff126_op in H. discriminate H. Qed.

Lemma reff126_not1861 : ~ @Equation1861 Fin3 reff126_inst.
Proof. unfold Equation1861. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff126_inst, reff126_op in H. discriminate H. Qed.

Lemma reff126_not1884 : ~ @Equation1884 Fin3 reff126_inst.
Proof. unfold Equation1884. intro H. specialize (H F3_1 F3_0). unfold magma_op, reff126_inst, reff126_op in H. discriminate H. Qed.

Lemma reff126_not1885 : ~ @Equation1885 Fin3 reff126_inst.
Proof. unfold Equation1885. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff126_inst, reff126_op in H. discriminate H. Qed.

Lemma reff126_not1887 : ~ @Equation1887 Fin3 reff126_inst.
Proof. unfold Equation1887. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff126_inst, reff126_op in H. discriminate H. Qed.

Lemma reff126_not1888 : ~ @Equation1888 Fin3 reff126_inst.
Proof. unfold Equation1888. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff126_inst, reff126_op in H. discriminate H. Qed.

Lemma reff126_not1894 : ~ @Equation1894 Fin3 reff126_inst.
Proof. unfold Equation1894. intro H. specialize (H F3_1 F3_2). unfold magma_op, reff126_inst, reff126_op in H. discriminate H. Qed.

Lemma reff126_not1895 : ~ @Equation1895 Fin3 reff126_inst.
Proof. unfold Equation1895. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff126_inst, reff126_op in H. discriminate H. Qed.

Lemma reff126_not1897 : ~ @Equation1897 Fin3 reff126_inst.
Proof. unfold Equation1897. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff126_inst, reff126_op in H. discriminate H. Qed.

Lemma reff126_not1898 : ~ @Equation1898 Fin3 reff126_inst.
Proof. unfold Equation1898. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff126_inst, reff126_op in H. discriminate H. Qed.

Lemma reff126_not1922 : ~ @Equation1922 Fin3 reff126_inst.
Proof. unfold Equation1922. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff126_inst, reff126_op in H. discriminate H. Qed.

Lemma reff126_not1924 : ~ @Equation1924 Fin3 reff126_inst.
Proof. unfold Equation1924. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff126_inst, reff126_op in H. discriminate H. Qed.

Lemma reff126_not1925 : ~ @Equation1925 Fin3 reff126_inst.
Proof. unfold Equation1925. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff126_inst, reff126_op in H. discriminate H. Qed.

Lemma reff126_not1931 : ~ @Equation1931 Fin3 reff126_inst.
Proof. unfold Equation1931. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff126_inst, reff126_op in H. discriminate H. Qed.

Lemma reff126_not1932 : ~ @Equation1932 Fin3 reff126_inst.
Proof. unfold Equation1932. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff126_inst, reff126_op in H. discriminate H. Qed.

Lemma reff126_not2036 : ~ @Equation2036 Fin3 reff126_inst.
Proof. unfold Equation2036. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff126_inst, reff126_op in H. discriminate H. Qed.

Lemma reff126_not2037 : ~ @Equation2037 Fin3 reff126_inst.
Proof. unfold Equation2037. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff126_inst, reff126_op in H. discriminate H. Qed.

Lemma reff126_not2038 : ~ @Equation2038 Fin3 reff126_inst.
Proof. unfold Equation2038. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff126_inst, reff126_op in H. discriminate H. Qed.

Lemma reff126_not2040 : ~ @Equation2040 Fin3 reff126_inst.
Proof. unfold Equation2040. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff126_inst, reff126_op in H. discriminate H. Qed.

Lemma reff126_not2041 : ~ @Equation2041 Fin3 reff126_inst.
Proof. unfold Equation2041. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff126_inst, reff126_op in H. discriminate H. Qed.

Lemma reff126_not2043 : ~ @Equation2043 Fin3 reff126_inst.
Proof. unfold Equation2043. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff126_inst, reff126_op in H. discriminate H. Qed.

Lemma reff126_not2044 : ~ @Equation2044 Fin3 reff126_inst.
Proof. unfold Equation2044. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff126_inst, reff126_op in H. discriminate H. Qed.

Lemma reff126_not2050 : ~ @Equation2050 Fin3 reff126_inst.
Proof. unfold Equation2050. intro H. specialize (H F3_1 F3_0). unfold magma_op, reff126_inst, reff126_op in H. discriminate H. Qed.

Lemma reff126_not2051 : ~ @Equation2051 Fin3 reff126_inst.
Proof. unfold Equation2051. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff126_inst, reff126_op in H. discriminate H. Qed.

Lemma reff126_not2053 : ~ @Equation2053 Fin3 reff126_inst.
Proof. unfold Equation2053. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff126_inst, reff126_op in H. discriminate H. Qed.

Lemma reff126_not2054 : ~ @Equation2054 Fin3 reff126_inst.
Proof. unfold Equation2054. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff126_inst, reff126_op in H. discriminate H. Qed.

Lemma reff126_not2060 : ~ @Equation2060 Fin3 reff126_inst.
Proof. unfold Equation2060. intro H. specialize (H F3_1 F3_0). unfold magma_op, reff126_inst, reff126_op in H. discriminate H. Qed.

Lemma reff126_not2061 : ~ @Equation2061 Fin3 reff126_inst.
Proof. unfold Equation2061. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff126_inst, reff126_op in H. discriminate H. Qed.

Lemma reff126_not2063 : ~ @Equation2063 Fin3 reff126_inst.
Proof. unfold Equation2063. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff126_inst, reff126_op in H. discriminate H. Qed.

Lemma reff126_not2064 : ~ @Equation2064 Fin3 reff126_inst.
Proof. unfold Equation2064. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff126_inst, reff126_op in H. discriminate H. Qed.

Lemma reff126_not2087 : ~ @Equation2087 Fin3 reff126_inst.
Proof. unfold Equation2087. intro H. specialize (H F3_1 F3_0). unfold magma_op, reff126_inst, reff126_op in H. discriminate H. Qed.

Lemma reff126_not2088 : ~ @Equation2088 Fin3 reff126_inst.
Proof. unfold Equation2088. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff126_inst, reff126_op in H. discriminate H. Qed.

Lemma reff126_not2090 : ~ @Equation2090 Fin3 reff126_inst.
Proof. unfold Equation2090. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff126_inst, reff126_op in H. discriminate H. Qed.

Lemma reff126_not2091 : ~ @Equation2091 Fin3 reff126_inst.
Proof. unfold Equation2091. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff126_inst, reff126_op in H. discriminate H. Qed.

Lemma reff126_not2097 : ~ @Equation2097 Fin3 reff126_inst.
Proof. unfold Equation2097. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff126_inst, reff126_op in H. discriminate H. Qed.

Lemma reff126_not2098 : ~ @Equation2098 Fin3 reff126_inst.
Proof. unfold Equation2098. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff126_inst, reff126_op in H. discriminate H. Qed.

Lemma reff126_not2100 : ~ @Equation2100 Fin3 reff126_inst.
Proof. unfold Equation2100. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff126_inst, reff126_op in H. discriminate H. Qed.

Lemma reff126_not2101 : ~ @Equation2101 Fin3 reff126_inst.
Proof. unfold Equation2101. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff126_inst, reff126_op in H. discriminate H. Qed.

Lemma reff126_not2124 : ~ @Equation2124 Fin3 reff126_inst.
Proof. unfold Equation2124. intro H. specialize (H F3_1 F3_0). unfold magma_op, reff126_inst, reff126_op in H. discriminate H. Qed.

Lemma reff126_not2125 : ~ @Equation2125 Fin3 reff126_inst.
Proof. unfold Equation2125. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff126_inst, reff126_op in H. discriminate H. Qed.

Lemma reff126_not2127 : ~ @Equation2127 Fin3 reff126_inst.
Proof. unfold Equation2127. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff126_inst, reff126_op in H. discriminate H. Qed.

Lemma reff126_not2128 : ~ @Equation2128 Fin3 reff126_inst.
Proof. unfold Equation2128. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff126_inst, reff126_op in H. discriminate H. Qed.

Lemma reff126_not2134 : ~ @Equation2134 Fin3 reff126_inst.
Proof. unfold Equation2134. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff126_inst, reff126_op in H. discriminate H. Qed.

Lemma reff126_not2135 : ~ @Equation2135 Fin3 reff126_inst.
Proof. unfold Equation2135. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff126_inst, reff126_op in H. discriminate H. Qed.

Lemma reff126_not2238 : ~ @Equation2238 Fin3 reff126_inst.
Proof. unfold Equation2238. intro H. specialize (H F3_2). unfold magma_op, reff126_inst, reff126_op in H. discriminate H. Qed.

Lemma reff126_not2441 : ~ @Equation2441 Fin3 reff126_inst.
Proof. unfold Equation2441. intro H. specialize (H F3_2). unfold magma_op, reff126_inst, reff126_op in H. discriminate H. Qed.

Lemma reff126_not2644 : ~ @Equation2644 Fin3 reff126_inst.
Proof. unfold Equation2644. intro H. specialize (H F3_2). unfold magma_op, reff126_inst, reff126_op in H. discriminate H. Qed.

Lemma reff126_not2847 : ~ @Equation2847 Fin3 reff126_inst.
Proof. unfold Equation2847. intro H. specialize (H F3_2). unfold magma_op, reff126_inst, reff126_op in H. discriminate H. Qed.

Lemma reff126_not3050 : ~ @Equation3050 Fin3 reff126_inst.
Proof. unfold Equation3050. intro H. specialize (H F3_2). unfold magma_op, reff126_inst, reff126_op in H. discriminate H. Qed.

Lemma reff126_not3254 : ~ @Equation3254 Fin3 reff126_inst.
Proof. unfold Equation3254. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff126_inst, reff126_op in H. discriminate H. Qed.

Lemma reff126_not3255 : ~ @Equation3255 Fin3 reff126_inst.
Proof. unfold Equation3255. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff126_inst, reff126_op in H. discriminate H. Qed.

Lemma reff126_not3256 : ~ @Equation3256 Fin3 reff126_inst.
Proof. unfold Equation3256. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff126_inst, reff126_op in H. discriminate H. Qed.

Lemma reff126_not3258 : ~ @Equation3258 Fin3 reff126_inst.
Proof. unfold Equation3258. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff126_inst, reff126_op in H. discriminate H. Qed.

Lemma reff126_not3259 : ~ @Equation3259 Fin3 reff126_inst.
Proof. unfold Equation3259. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff126_inst, reff126_op in H. discriminate H. Qed.

Lemma reff126_not3262 : ~ @Equation3262 Fin3 reff126_inst.
Proof. unfold Equation3262. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff126_inst, reff126_op in H. discriminate H. Qed.

Lemma reff126_not3268 : ~ @Equation3268 Fin3 reff126_inst.
Proof. unfold Equation3268. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff126_inst, reff126_op in H. discriminate H. Qed.

Lemma reff126_not3269 : ~ @Equation3269 Fin3 reff126_inst.
Proof. unfold Equation3269. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff126_inst, reff126_op in H. discriminate H. Qed.

Lemma reff126_not3271 : ~ @Equation3271 Fin3 reff126_inst.
Proof. unfold Equation3271. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff126_inst, reff126_op in H. discriminate H. Qed.

Lemma reff126_not3272 : ~ @Equation3272 Fin3 reff126_inst.
Proof. unfold Equation3272. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff126_inst, reff126_op in H. discriminate H. Qed.

Lemma reff126_not3279 : ~ @Equation3279 Fin3 reff126_inst.
Proof. unfold Equation3279. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff126_inst, reff126_op in H. discriminate H. Qed.

Lemma reff126_not3281 : ~ @Equation3281 Fin3 reff126_inst.
Proof. unfold Equation3281. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff126_inst, reff126_op in H. discriminate H. Qed.

Lemma reff126_not3308 : ~ @Equation3308 Fin3 reff126_inst.
Proof. unfold Equation3308. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff126_inst, reff126_op in H. discriminate H. Qed.

Lemma reff126_not3309 : ~ @Equation3309 Fin3 reff126_inst.
Proof. unfold Equation3309. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff126_inst, reff126_op in H. discriminate H. Qed.

Lemma reff126_not3315 : ~ @Equation3315 Fin3 reff126_inst.
Proof. unfold Equation3315. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff126_inst, reff126_op in H. discriminate H. Qed.

Lemma reff126_not3316 : ~ @Equation3316 Fin3 reff126_inst.
Proof. unfold Equation3316. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff126_inst, reff126_op in H. discriminate H. Qed.

Lemma reff126_not3318 : ~ @Equation3318 Fin3 reff126_inst.
Proof. unfold Equation3318. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff126_inst, reff126_op in H. discriminate H. Qed.

Lemma reff126_not3342 : ~ @Equation3342 Fin3 reff126_inst.
Proof. unfold Equation3342. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff126_inst, reff126_op in H. discriminate H. Qed.

Lemma reff126_not3343 : ~ @Equation3343 Fin3 reff126_inst.
Proof. unfold Equation3343. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff126_inst, reff126_op in H. discriminate H. Qed.

Lemma reff126_not3345 : ~ @Equation3345 Fin3 reff126_inst.
Proof. unfold Equation3345. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff126_inst, reff126_op in H. discriminate H. Qed.

Lemma reff126_not3346 : ~ @Equation3346 Fin3 reff126_inst.
Proof. unfold Equation3346. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff126_inst, reff126_op in H. discriminate H. Qed.

Lemma reff126_not3352 : ~ @Equation3352 Fin3 reff126_inst.
Proof. unfold Equation3352. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff126_inst, reff126_op in H. discriminate H. Qed.

Lemma reff126_not3456 : ~ @Equation3456 Fin3 reff126_inst.
Proof. unfold Equation3456. intro H. specialize (H F3_2). unfold magma_op, reff126_inst, reff126_op in H. discriminate H. Qed.

Lemma reff126_not3660 : ~ @Equation3660 Fin3 reff126_inst.
Proof. unfold Equation3660. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff126_inst, reff126_op in H. discriminate H. Qed.

Lemma reff126_not3661 : ~ @Equation3661 Fin3 reff126_inst.
Proof. unfold Equation3661. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff126_inst, reff126_op in H. discriminate H. Qed.

Lemma reff126_not3662 : ~ @Equation3662 Fin3 reff126_inst.
Proof. unfold Equation3662. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff126_inst, reff126_op in H. discriminate H. Qed.

Lemma reff126_not3664 : ~ @Equation3664 Fin3 reff126_inst.
Proof. unfold Equation3664. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff126_inst, reff126_op in H. discriminate H. Qed.

Lemma reff126_not3665 : ~ @Equation3665 Fin3 reff126_inst.
Proof. unfold Equation3665. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff126_inst, reff126_op in H. discriminate H. Qed.

Lemma reff126_not3667 : ~ @Equation3667 Fin3 reff126_inst.
Proof. unfold Equation3667. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff126_inst, reff126_op in H. discriminate H. Qed.

Lemma reff126_not3668 : ~ @Equation3668 Fin3 reff126_inst.
Proof. unfold Equation3668. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff126_inst, reff126_op in H. discriminate H. Qed.

Lemma reff126_not3674 : ~ @Equation3674 Fin3 reff126_inst.
Proof. unfold Equation3674. intro H. specialize (H F3_1 F3_0). unfold magma_op, reff126_inst, reff126_op in H. discriminate H. Qed.

Lemma reff126_not3675 : ~ @Equation3675 Fin3 reff126_inst.
Proof. unfold Equation3675. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff126_inst, reff126_op in H. discriminate H. Qed.

Lemma reff126_not3677 : ~ @Equation3677 Fin3 reff126_inst.
Proof. unfold Equation3677. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff126_inst, reff126_op in H. discriminate H. Qed.

Lemma reff126_not3678 : ~ @Equation3678 Fin3 reff126_inst.
Proof. unfold Equation3678. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff126_inst, reff126_op in H. discriminate H. Qed.

Lemma reff126_not3684 : ~ @Equation3684 Fin3 reff126_inst.
Proof. unfold Equation3684. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff126_inst, reff126_op in H. discriminate H. Qed.

Lemma reff126_not3685 : ~ @Equation3685 Fin3 reff126_inst.
Proof. unfold Equation3685. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff126_inst, reff126_op in H. discriminate H. Qed.

Lemma reff126_not3687 : ~ @Equation3687 Fin3 reff126_inst.
Proof. unfold Equation3687. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff126_inst, reff126_op in H. discriminate H. Qed.

Lemma reff126_not3712 : ~ @Equation3712 Fin3 reff126_inst.
Proof. unfold Equation3712. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff126_inst, reff126_op in H. discriminate H. Qed.

Lemma reff126_not3714 : ~ @Equation3714 Fin3 reff126_inst.
Proof. unfold Equation3714. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff126_inst, reff126_op in H. discriminate H. Qed.

Lemma reff126_not3721 : ~ @Equation3721 Fin3 reff126_inst.
Proof. unfold Equation3721. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff126_inst, reff126_op in H. discriminate H. Qed.

Lemma reff126_not3722 : ~ @Equation3722 Fin3 reff126_inst.
Proof. unfold Equation3722. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff126_inst, reff126_op in H. discriminate H. Qed.

Lemma reff126_not3724 : ~ @Equation3724 Fin3 reff126_inst.
Proof. unfold Equation3724. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff126_inst, reff126_op in H. discriminate H. Qed.

Lemma reff126_not3725 : ~ @Equation3725 Fin3 reff126_inst.
Proof. unfold Equation3725. intro H. specialize (H F3_1 F3_0). unfold magma_op, reff126_inst, reff126_op in H. discriminate H. Qed.

Lemma reff126_not3748 : ~ @Equation3748 Fin3 reff126_inst.
Proof. unfold Equation3748. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff126_inst, reff126_op in H. discriminate H. Qed.

Lemma reff126_not3749 : ~ @Equation3749 Fin3 reff126_inst.
Proof. unfold Equation3749. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff126_inst, reff126_op in H. discriminate H. Qed.

Lemma reff126_not3751 : ~ @Equation3751 Fin3 reff126_inst.
Proof. unfold Equation3751. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff126_inst, reff126_op in H. discriminate H. Qed.

Lemma reff126_not3752 : ~ @Equation3752 Fin3 reff126_inst.
Proof. unfold Equation3752. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff126_inst, reff126_op in H. discriminate H. Qed.

Lemma reff126_not3759 : ~ @Equation3759 Fin3 reff126_inst.
Proof. unfold Equation3759. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff126_inst, reff126_op in H. discriminate H. Qed.

Lemma reff126_not3761 : ~ @Equation3761 Fin3 reff126_inst.
Proof. unfold Equation3761. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff126_inst, reff126_op in H. discriminate H. Qed.

Lemma reff126_not3864 : ~ @Equation3864 Fin3 reff126_inst.
Proof. unfold Equation3864. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff126_inst, reff126_op in H. discriminate H. Qed.

Lemma reff126_not3865 : ~ @Equation3865 Fin3 reff126_inst.
Proof. unfold Equation3865. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff126_inst, reff126_op in H. discriminate H. Qed.

Lemma reff126_not3867 : ~ @Equation3867 Fin3 reff126_inst.
Proof. unfold Equation3867. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff126_inst, reff126_op in H. discriminate H. Qed.

Lemma reff126_not3868 : ~ @Equation3868 Fin3 reff126_inst.
Proof. unfold Equation3868. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff126_inst, reff126_op in H. discriminate H. Qed.

Lemma reff126_not3870 : ~ @Equation3870 Fin3 reff126_inst.
Proof. unfold Equation3870. intro H. specialize (H F3_1 F3_0). unfold magma_op, reff126_inst, reff126_op in H. discriminate H. Qed.

Lemma reff126_not3871 : ~ @Equation3871 Fin3 reff126_inst.
Proof. unfold Equation3871. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff126_inst, reff126_op in H. discriminate H. Qed.

Lemma reff126_not3877 : ~ @Equation3877 Fin3 reff126_inst.
Proof. unfold Equation3877. intro H. specialize (H F3_1 F3_0). unfold magma_op, reff126_inst, reff126_op in H. discriminate H. Qed.

Lemma reff126_not3878 : ~ @Equation3878 Fin3 reff126_inst.
Proof. unfold Equation3878. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff126_inst, reff126_op in H. discriminate H. Qed.

Lemma reff126_not3880 : ~ @Equation3880 Fin3 reff126_inst.
Proof. unfold Equation3880. intro H. specialize (H F3_1 F3_2). unfold magma_op, reff126_inst, reff126_op in H. discriminate H. Qed.

Lemma reff126_not3881 : ~ @Equation3881 Fin3 reff126_inst.
Proof. unfold Equation3881. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff126_inst, reff126_op in H. discriminate H. Qed.

Lemma reff126_not3888 : ~ @Equation3888 Fin3 reff126_inst.
Proof. unfold Equation3888. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff126_inst, reff126_op in H. discriminate H. Qed.

Lemma reff126_not3890 : ~ @Equation3890 Fin3 reff126_inst.
Proof. unfold Equation3890. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff126_inst, reff126_op in H. discriminate H. Qed.

Lemma reff126_not3917 : ~ @Equation3917 Fin3 reff126_inst.
Proof. unfold Equation3917. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff126_inst, reff126_op in H. discriminate H. Qed.

Lemma reff126_not3918 : ~ @Equation3918 Fin3 reff126_inst.
Proof. unfold Equation3918. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff126_inst, reff126_op in H. discriminate H. Qed.

Lemma reff126_not3924 : ~ @Equation3924 Fin3 reff126_inst.
Proof. unfold Equation3924. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff126_inst, reff126_op in H. discriminate H. Qed.

Lemma reff126_not3925 : ~ @Equation3925 Fin3 reff126_inst.
Proof. unfold Equation3925. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff126_inst, reff126_op in H. discriminate H. Qed.

Lemma reff126_not3927 : ~ @Equation3927 Fin3 reff126_inst.
Proof. unfold Equation3927. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff126_inst, reff126_op in H. discriminate H. Qed.

Lemma reff126_not3928 : ~ @Equation3928 Fin3 reff126_inst.
Proof. unfold Equation3928. intro H. specialize (H F3_1 F3_0). unfold magma_op, reff126_inst, reff126_op in H. discriminate H. Qed.

Lemma reff126_not3951 : ~ @Equation3951 Fin3 reff126_inst.
Proof. unfold Equation3951. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff126_inst, reff126_op in H. discriminate H. Qed.

Lemma reff126_not3952 : ~ @Equation3952 Fin3 reff126_inst.
Proof. unfold Equation3952. intro H. specialize (H F3_1 F3_0). unfold magma_op, reff126_inst, reff126_op in H. discriminate H. Qed.

Lemma reff126_not3954 : ~ @Equation3954 Fin3 reff126_inst.
Proof. unfold Equation3954. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff126_inst, reff126_op in H. discriminate H. Qed.

Lemma reff126_not3955 : ~ @Equation3955 Fin3 reff126_inst.
Proof. unfold Equation3955. intro H. specialize (H F3_1 F3_2). unfold magma_op, reff126_inst, reff126_op in H. discriminate H. Qed.

Lemma reff126_not3961 : ~ @Equation3961 Fin3 reff126_inst.
Proof. unfold Equation3961. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff126_inst, reff126_op in H. discriminate H. Qed.

Lemma reff126_not3964 : ~ @Equation3964 Fin3 reff126_inst.
Proof. unfold Equation3964. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff126_inst, reff126_op in H. discriminate H. Qed.

Lemma reff126_not4066 : ~ @Equation4066 Fin3 reff126_inst.
Proof. unfold Equation4066. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff126_inst, reff126_op in H. discriminate H. Qed.

Lemma reff126_not4067 : ~ @Equation4067 Fin3 reff126_inst.
Proof. unfold Equation4067. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff126_inst, reff126_op in H. discriminate H. Qed.

Lemma reff126_not4068 : ~ @Equation4068 Fin3 reff126_inst.
Proof. unfold Equation4068. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff126_inst, reff126_op in H. discriminate H. Qed.

Lemma reff126_not4070 : ~ @Equation4070 Fin3 reff126_inst.
Proof. unfold Equation4070. intro H. specialize (H F3_1 F3_0). unfold magma_op, reff126_inst, reff126_op in H. discriminate H. Qed.

Lemma reff126_not4071 : ~ @Equation4071 Fin3 reff126_inst.
Proof. unfold Equation4071. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff126_inst, reff126_op in H. discriminate H. Qed.

Lemma reff126_not4073 : ~ @Equation4073 Fin3 reff126_inst.
Proof. unfold Equation4073. intro H. specialize (H F3_1 F3_0). unfold magma_op, reff126_inst, reff126_op in H. discriminate H. Qed.

Lemma reff126_not4074 : ~ @Equation4074 Fin3 reff126_inst.
Proof. unfold Equation4074. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff126_inst, reff126_op in H. discriminate H. Qed.

Lemma reff126_not4080 : ~ @Equation4080 Fin3 reff126_inst.
Proof. unfold Equation4080. intro H. specialize (H F3_1 F3_0). unfold magma_op, reff126_inst, reff126_op in H. discriminate H. Qed.

Lemma reff126_not4081 : ~ @Equation4081 Fin3 reff126_inst.
Proof. unfold Equation4081. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff126_inst, reff126_op in H. discriminate H. Qed.

Lemma reff126_not4083 : ~ @Equation4083 Fin3 reff126_inst.
Proof. unfold Equation4083. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff126_inst, reff126_op in H. discriminate H. Qed.

Lemma reff126_not4084 : ~ @Equation4084 Fin3 reff126_inst.
Proof. unfold Equation4084. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff126_inst, reff126_op in H. discriminate H. Qed.

Lemma reff126_not4090 : ~ @Equation4090 Fin3 reff126_inst.
Proof. unfold Equation4090. intro H. specialize (H F3_1 F3_0). unfold magma_op, reff126_inst, reff126_op in H. discriminate H. Qed.

Lemma reff126_not4091 : ~ @Equation4091 Fin3 reff126_inst.
Proof. unfold Equation4091. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff126_inst, reff126_op in H. discriminate H. Qed.

Lemma reff126_not4093 : ~ @Equation4093 Fin3 reff126_inst.
Proof. unfold Equation4093. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff126_inst, reff126_op in H. discriminate H. Qed.

Lemma reff126_not4120 : ~ @Equation4120 Fin3 reff126_inst.
Proof. unfold Equation4120. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff126_inst, reff126_op in H. discriminate H. Qed.

Lemma reff126_not4121 : ~ @Equation4121 Fin3 reff126_inst.
Proof. unfold Equation4121. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff126_inst, reff126_op in H. discriminate H. Qed.

Lemma reff126_not4127 : ~ @Equation4127 Fin3 reff126_inst.
Proof. unfold Equation4127. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff126_inst, reff126_op in H. discriminate H. Qed.

Lemma reff126_not4128 : ~ @Equation4128 Fin3 reff126_inst.
Proof. unfold Equation4128. intro H. specialize (H F3_1 F3_0). unfold magma_op, reff126_inst, reff126_op in H. discriminate H. Qed.

Lemma reff126_not4130 : ~ @Equation4130 Fin3 reff126_inst.
Proof. unfold Equation4130. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff126_inst, reff126_op in H. discriminate H. Qed.

Lemma reff126_not4131 : ~ @Equation4131 Fin3 reff126_inst.
Proof. unfold Equation4131. intro H. specialize (H F3_1 F3_0). unfold magma_op, reff126_inst, reff126_op in H. discriminate H. Qed.

Lemma reff126_not4155 : ~ @Equation4155 Fin3 reff126_inst.
Proof. unfold Equation4155. intro H. specialize (H F3_1 F3_0). unfold magma_op, reff126_inst, reff126_op in H. discriminate H. Qed.

Lemma reff126_not4157 : ~ @Equation4157 Fin3 reff126_inst.
Proof. unfold Equation4157. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff126_inst, reff126_op in H. discriminate H. Qed.

Lemma reff126_not4158 : ~ @Equation4158 Fin3 reff126_inst.
Proof. unfold Equation4158. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff126_inst, reff126_op in H. discriminate H. Qed.

Lemma reff126_not4164 : ~ @Equation4164 Fin3 reff126_inst.
Proof. unfold Equation4164. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff126_inst, reff126_op in H. discriminate H. Qed.

Lemma reff126_not4165 : ~ @Equation4165 Fin3 reff126_inst.
Proof. unfold Equation4165. intro H. specialize (H F3_1 F3_0). unfold magma_op, reff126_inst, reff126_op in H. discriminate H. Qed.

Lemma reff126_not4167 : ~ @Equation4167 Fin3 reff126_inst.
Proof. unfold Equation4167. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff126_inst, reff126_op in H. discriminate H. Qed.

Lemma reff126_not4268 : ~ @Equation4268 Fin3 reff126_inst.
Proof. unfold Equation4268. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff126_inst, reff126_op in H. discriminate H. Qed.

Lemma reff126_not4269 : ~ @Equation4269 Fin3 reff126_inst.
Proof. unfold Equation4269. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff126_inst, reff126_op in H. discriminate H. Qed.

Lemma reff126_not4270 : ~ @Equation4270 Fin3 reff126_inst.
Proof. unfold Equation4270. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff126_inst, reff126_op in H. discriminate H. Qed.

Lemma reff126_not4272 : ~ @Equation4272 Fin3 reff126_inst.
Proof. unfold Equation4272. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff126_inst, reff126_op in H. discriminate H. Qed.

Lemma reff126_not4273 : ~ @Equation4273 Fin3 reff126_inst.
Proof. unfold Equation4273. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff126_inst, reff126_op in H. discriminate H. Qed.

Lemma reff126_not4276 : ~ @Equation4276 Fin3 reff126_inst.
Proof. unfold Equation4276. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff126_inst, reff126_op in H. discriminate H. Qed.

Lemma reff126_not4283 : ~ @Equation4283 Fin3 reff126_inst.
Proof. unfold Equation4283. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff126_inst, reff126_op in H. discriminate H. Qed.

Lemma reff126_not4284 : ~ @Equation4284 Fin3 reff126_inst.
Proof. unfold Equation4284. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff126_inst, reff126_op in H. discriminate H. Qed.

Lemma reff126_not4290 : ~ @Equation4290 Fin3 reff126_inst.
Proof. unfold Equation4290. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff126_inst, reff126_op in H. discriminate H. Qed.

Lemma reff126_not4291 : ~ @Equation4291 Fin3 reff126_inst.
Proof. unfold Equation4291. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff126_inst, reff126_op in H. discriminate H. Qed.

Lemma reff126_not4293 : ~ @Equation4293 Fin3 reff126_inst.
Proof. unfold Equation4293. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff126_inst, reff126_op in H. discriminate H. Qed.

Lemma reff126_not4314 : ~ @Equation4314 Fin3 reff126_inst.
Proof. unfold Equation4314. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff126_inst, reff126_op in H. discriminate H. Qed.

Lemma reff126_not4320 : ~ @Equation4320 Fin3 reff126_inst.
Proof. unfold Equation4320. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff126_inst, reff126_op in H. discriminate H. Qed.

Lemma reff126_not4321 : ~ @Equation4321 Fin3 reff126_inst.
Proof. unfold Equation4321. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff126_inst, reff126_op in H. discriminate H. Qed.

Lemma reff126_not4343 : ~ @Equation4343 Fin3 reff126_inst.
Proof. unfold Equation4343. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff126_inst, reff126_op in H. discriminate H. Qed.

Lemma reff126_not4380 : ~ @Equation4380 Fin3 reff126_inst.
Proof. unfold Equation4380. intro H. specialize (H F3_2). unfold magma_op, reff126_inst, reff126_op in H. discriminate H. Qed.

Lemma reff126_not4583 : ~ @Equation4583 Fin3 reff126_inst.
Proof. unfold Equation4583. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff126_inst, reff126_op in H. discriminate H. Qed.

Lemma reff126_not4584 : ~ @Equation4584 Fin3 reff126_inst.
Proof. unfold Equation4584. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff126_inst, reff126_op in H. discriminate H. Qed.

Lemma reff126_not4585 : ~ @Equation4585 Fin3 reff126_inst.
Proof. unfold Equation4585. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff126_inst, reff126_op in H. discriminate H. Qed.

Lemma reff126_not4587 : ~ @Equation4587 Fin3 reff126_inst.
Proof. unfold Equation4587. intro H. specialize (H F3_1 F3_0). unfold magma_op, reff126_inst, reff126_op in H. discriminate H. Qed.

Lemma reff126_not4588 : ~ @Equation4588 Fin3 reff126_inst.
Proof. unfold Equation4588. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff126_inst, reff126_op in H. discriminate H. Qed.

Lemma reff126_not4590 : ~ @Equation4590 Fin3 reff126_inst.
Proof. unfold Equation4590. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff126_inst, reff126_op in H. discriminate H. Qed.

Lemma reff126_not4591 : ~ @Equation4591 Fin3 reff126_inst.
Proof. unfold Equation4591. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff126_inst, reff126_op in H. discriminate H. Qed.

Lemma reff126_not4598 : ~ @Equation4598 Fin3 reff126_inst.
Proof. unfold Equation4598. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff126_inst, reff126_op in H. discriminate H. Qed.

Lemma reff126_not4599 : ~ @Equation4599 Fin3 reff126_inst.
Proof. unfold Equation4599. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff126_inst, reff126_op in H. discriminate H. Qed.

Lemma reff126_not4605 : ~ @Equation4605 Fin3 reff126_inst.
Proof. unfold Equation4605. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff126_inst, reff126_op in H. discriminate H. Qed.

Lemma reff126_not4606 : ~ @Equation4606 Fin3 reff126_inst.
Proof. unfold Equation4606. intro H. specialize (H F3_1 F3_0). unfold magma_op, reff126_inst, reff126_op in H. discriminate H. Qed.

Lemma reff126_not4608 : ~ @Equation4608 Fin3 reff126_inst.
Proof. unfold Equation4608. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff126_inst, reff126_op in H. discriminate H. Qed.

Lemma reff126_not4629 : ~ @Equation4629 Fin3 reff126_inst.
Proof. unfold Equation4629. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff126_inst, reff126_op in H. discriminate H. Qed.

Lemma reff126_not4635 : ~ @Equation4635 Fin3 reff126_inst.
Proof. unfold Equation4635. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff126_inst, reff126_op in H. discriminate H. Qed.

Lemma reff126_not4636 : ~ @Equation4636 Fin3 reff126_inst.
Proof. unfold Equation4636. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff126_inst, reff126_op in H. discriminate H. Qed.

Lemma reff126_not4658 : ~ @Equation4658 Fin3 reff126_inst.
Proof. unfold Equation4658. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff126_inst, reff126_op in H. discriminate H. Qed.

(** ---- reff128 (Fin4) ---- *)

Definition reff128_op (x y : Fin4) : Fin4 :=
  match x, y with
  | F4_0, F4_0 => F4_0 | F4_0, F4_1 => F4_2 | F4_0, F4_2 => F4_0 | F4_0, F4_3 => F4_2
  | F4_1, F4_0 => F4_3 | F4_1, F4_1 => F4_2 | F4_1, F4_2 => F4_1 | F4_1, F4_3 => F4_0
  | F4_2, F4_0 => F4_2 | F4_2, F4_1 => F4_2 | F4_2, F4_2 => F4_2 | F4_2, F4_3 => F4_2
  | F4_3, F4_0 => F4_1 | F4_3, F4_1 => F4_2 | F4_3, F4_2 => F4_3 | F4_3, F4_3 => F4_0
  end.

#[local] Instance reff128_inst : Magma Fin4 := {| magma_op := reff128_op |}.

Lemma reff128_sat105 : @Equation105 Fin4 reff128_inst.
Proof. unfold Equation105, magma_op, reff128_inst, reff128_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff128_sat107 : @Equation107 Fin4 reff128_inst.
Proof. unfold Equation107, magma_op, reff128_inst, reff128_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff128_sat411 : @Equation411 Fin4 reff128_inst.
Proof. unfold Equation411, magma_op, reff128_inst, reff128_op. intros x. destruct x; reflexivity. Qed.

Lemma reff128_sat1243 : @Equation1243 Fin4 reff128_inst.
Proof. unfold Equation1243, magma_op, reff128_inst, reff128_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff128_sat1245 : @Equation1245 Fin4 reff128_inst.
Proof. unfold Equation1245, magma_op, reff128_inst, reff128_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff128_sat1250 : @Equation1250 Fin4 reff128_inst.
Proof. unfold Equation1250, magma_op, reff128_inst, reff128_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff128_sat1254 : @Equation1254 Fin4 reff128_inst.
Proof. unfold Equation1254, magma_op, reff128_inst, reff128_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff128_sat1259 : @Equation1259 Fin4 reff128_inst.
Proof. unfold Equation1259, magma_op, reff128_inst, reff128_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff128_sat1262 : @Equation1262 Fin4 reff128_inst.
Proof. unfold Equation1262, magma_op, reff128_inst, reff128_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff128_sat1861 : @Equation1861 Fin4 reff128_inst.
Proof. unfold Equation1861, magma_op, reff128_inst, reff128_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff128_sat3662 : @Equation3662 Fin4 reff128_inst.
Proof. unfold Equation3662, magma_op, reff128_inst, reff128_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff128_sat3724 : @Equation3724 Fin4 reff128_inst.
Proof. unfold Equation3724, magma_op, reff128_inst, reff128_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff128_sat3870 : @Equation3870 Fin4 reff128_inst.
Proof. unfold Equation3870, magma_op, reff128_inst, reff128_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff128_sat3925 : @Equation3925 Fin4 reff128_inst.
Proof. unfold Equation3925, magma_op, reff128_inst, reff128_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff128_not47 : ~ @Equation47 Fin4 reff128_inst.
Proof. unfold Equation47. intro H. specialize (H F4_1). unfold magma_op, reff128_inst, reff128_op in H. discriminate H. Qed.

Lemma reff128_not102 : ~ @Equation102 Fin4 reff128_inst.
Proof. unfold Equation102. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff128_inst, reff128_op in H. discriminate H. Qed.

Lemma reff128_not108 : ~ @Equation108 Fin4 reff128_inst.
Proof. unfold Equation108. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff128_inst, reff128_op in H. discriminate H. Qed.

Lemma reff128_not115 : ~ @Equation115 Fin4 reff128_inst.
Proof. unfold Equation115. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff128_inst, reff128_op in H. discriminate H. Qed.

Lemma reff128_not117 : ~ @Equation117 Fin4 reff128_inst.
Proof. unfold Equation117. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff128_inst, reff128_op in H. discriminate H. Qed.

Lemma reff128_not118 : ~ @Equation118 Fin4 reff128_inst.
Proof. unfold Equation118. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff128_inst, reff128_op in H. discriminate H. Qed.

Lemma reff128_not124 : ~ @Equation124 Fin4 reff128_inst.
Proof. unfold Equation124. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff128_inst, reff128_op in H. discriminate H. Qed.

Lemma reff128_not125 : ~ @Equation125 Fin4 reff128_inst.
Proof. unfold Equation125. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff128_inst, reff128_op in H. discriminate H. Qed.

Lemma reff128_not127 : ~ @Equation127 Fin4 reff128_inst.
Proof. unfold Equation127. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff128_inst, reff128_op in H. discriminate H. Qed.

Lemma reff128_not151 : ~ @Equation151 Fin4 reff128_inst.
Proof. unfold Equation151. intro H. specialize (H F4_1). unfold magma_op, reff128_inst, reff128_op in H. discriminate H. Qed.

Lemma reff128_not203 : ~ @Equation203 Fin4 reff128_inst.
Proof. unfold Equation203. intro H. specialize (H F4_1). unfold magma_op, reff128_inst, reff128_op in H. discriminate H. Qed.

Lemma reff128_not255 : ~ @Equation255 Fin4 reff128_inst.
Proof. unfold Equation255. intro H. specialize (H F4_1). unfold magma_op, reff128_inst, reff128_op in H. discriminate H. Qed.

Lemma reff128_not412 : ~ @Equation412 Fin4 reff128_inst.
Proof. unfold Equation412. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff128_inst, reff128_op in H. discriminate H. Qed.

Lemma reff128_not413 : ~ @Equation413 Fin4 reff128_inst.
Proof. unfold Equation413. intro H. specialize (H F4_3 F4_0). unfold magma_op, reff128_inst, reff128_op in H. discriminate H. Qed.

Lemma reff128_not414 : ~ @Equation414 Fin4 reff128_inst.
Proof. unfold Equation414. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff128_inst, reff128_op in H. discriminate H. Qed.

Lemma reff128_not416 : ~ @Equation416 Fin4 reff128_inst.
Proof. unfold Equation416. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff128_inst, reff128_op in H. discriminate H. Qed.

Lemma reff128_not417 : ~ @Equation417 Fin4 reff128_inst.
Proof. unfold Equation417. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff128_inst, reff128_op in H. discriminate H. Qed.

Lemma reff128_not419 : ~ @Equation419 Fin4 reff128_inst.
Proof. unfold Equation419. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff128_inst, reff128_op in H. discriminate H. Qed.

Lemma reff128_not420 : ~ @Equation420 Fin4 reff128_inst.
Proof. unfold Equation420. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff128_inst, reff128_op in H. discriminate H. Qed.

Lemma reff128_not426 : ~ @Equation426 Fin4 reff128_inst.
Proof. unfold Equation426. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff128_inst, reff128_op in H. discriminate H. Qed.

Lemma reff128_not427 : ~ @Equation427 Fin4 reff128_inst.
Proof. unfold Equation427. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff128_inst, reff128_op in H. discriminate H. Qed.

Lemma reff128_not429 : ~ @Equation429 Fin4 reff128_inst.
Proof. unfold Equation429. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff128_inst, reff128_op in H. discriminate H. Qed.

Lemma reff128_not430 : ~ @Equation430 Fin4 reff128_inst.
Proof. unfold Equation430. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff128_inst, reff128_op in H. discriminate H. Qed.

Lemma reff128_not436 : ~ @Equation436 Fin4 reff128_inst.
Proof. unfold Equation436. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff128_inst, reff128_op in H. discriminate H. Qed.

Lemma reff128_not437 : ~ @Equation437 Fin4 reff128_inst.
Proof. unfold Equation437. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff128_inst, reff128_op in H. discriminate H. Qed.

Lemma reff128_not439 : ~ @Equation439 Fin4 reff128_inst.
Proof. unfold Equation439. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff128_inst, reff128_op in H. discriminate H. Qed.

Lemma reff128_not440 : ~ @Equation440 Fin4 reff128_inst.
Proof. unfold Equation440. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff128_inst, reff128_op in H. discriminate H. Qed.

Lemma reff128_not463 : ~ @Equation463 Fin4 reff128_inst.
Proof. unfold Equation463. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff128_inst, reff128_op in H. discriminate H. Qed.

Lemma reff128_not464 : ~ @Equation464 Fin4 reff128_inst.
Proof. unfold Equation464. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff128_inst, reff128_op in H. discriminate H. Qed.

Lemma reff128_not466 : ~ @Equation466 Fin4 reff128_inst.
Proof. unfold Equation466. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff128_inst, reff128_op in H. discriminate H. Qed.

Lemma reff128_not467 : ~ @Equation467 Fin4 reff128_inst.
Proof. unfold Equation467. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff128_inst, reff128_op in H. discriminate H. Qed.

Lemma reff128_not473 : ~ @Equation473 Fin4 reff128_inst.
Proof. unfold Equation473. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff128_inst, reff128_op in H. discriminate H. Qed.

Lemma reff128_not474 : ~ @Equation474 Fin4 reff128_inst.
Proof. unfold Equation474. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff128_inst, reff128_op in H. discriminate H. Qed.

Lemma reff128_not476 : ~ @Equation476 Fin4 reff128_inst.
Proof. unfold Equation476. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff128_inst, reff128_op in H. discriminate H. Qed.

Lemma reff128_not477 : ~ @Equation477 Fin4 reff128_inst.
Proof. unfold Equation477. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff128_inst, reff128_op in H. discriminate H. Qed.

Lemma reff128_not500 : ~ @Equation500 Fin4 reff128_inst.
Proof. unfold Equation500. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff128_inst, reff128_op in H. discriminate H. Qed.

Lemma reff128_not501 : ~ @Equation501 Fin4 reff128_inst.
Proof. unfold Equation501. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff128_inst, reff128_op in H. discriminate H. Qed.

Lemma reff128_not503 : ~ @Equation503 Fin4 reff128_inst.
Proof. unfold Equation503. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff128_inst, reff128_op in H. discriminate H. Qed.

Lemma reff128_not504 : ~ @Equation504 Fin4 reff128_inst.
Proof. unfold Equation504. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff128_inst, reff128_op in H. discriminate H. Qed.

Lemma reff128_not510 : ~ @Equation510 Fin4 reff128_inst.
Proof. unfold Equation510. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff128_inst, reff128_op in H. discriminate H. Qed.

Lemma reff128_not511 : ~ @Equation511 Fin4 reff128_inst.
Proof. unfold Equation511. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff128_inst, reff128_op in H. discriminate H. Qed.

Lemma reff128_not513 : ~ @Equation513 Fin4 reff128_inst.
Proof. unfold Equation513. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff128_inst, reff128_op in H. discriminate H. Qed.

Lemma reff128_not614 : ~ @Equation614 Fin4 reff128_inst.
Proof. unfold Equation614. intro H. specialize (H F4_1). unfold magma_op, reff128_inst, reff128_op in H. discriminate H. Qed.

Lemma reff128_not817 : ~ @Equation817 Fin4 reff128_inst.
Proof. unfold Equation817. intro H. specialize (H F4_3). unfold magma_op, reff128_inst, reff128_op in H. discriminate H. Qed.

Lemma reff128_not1020 : ~ @Equation1020 Fin4 reff128_inst.
Proof. unfold Equation1020. intro H. specialize (H F4_3). unfold magma_op, reff128_inst, reff128_op in H. discriminate H. Qed.

Lemma reff128_not1226 : ~ @Equation1226 Fin4 reff128_inst.
Proof. unfold Equation1226. intro H. specialize (H F4_3 F4_0). unfold magma_op, reff128_inst, reff128_op in H. discriminate H. Qed.

Lemma reff128_not1229 : ~ @Equation1229 Fin4 reff128_inst.
Proof. unfold Equation1229. intro H. specialize (H F4_3 F4_0). unfold magma_op, reff128_inst, reff128_op in H. discriminate H. Qed.

Lemma reff128_not1231 : ~ @Equation1231 Fin4 reff128_inst.
Proof. unfold Equation1231. intro H. specialize (H F4_3 F4_0). unfold magma_op, reff128_inst, reff128_op in H. discriminate H. Qed.

Lemma reff128_not1232 : ~ @Equation1232 Fin4 reff128_inst.
Proof. unfold Equation1232. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff128_inst, reff128_op in H. discriminate H. Qed.

Lemma reff128_not1238 : ~ @Equation1238 Fin4 reff128_inst.
Proof. unfold Equation1238. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff128_inst, reff128_op in H. discriminate H. Qed.

Lemma reff128_not1252 : ~ @Equation1252 Fin4 reff128_inst.
Proof. unfold Equation1252. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff128_inst, reff128_op in H. discriminate H. Qed.

Lemma reff128_not1275 : ~ @Equation1275 Fin4 reff128_inst.
Proof. unfold Equation1275. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff128_inst, reff128_op in H. discriminate H. Qed.

Lemma reff128_not1276 : ~ @Equation1276 Fin4 reff128_inst.
Proof. unfold Equation1276. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff128_inst, reff128_op in H. discriminate H. Qed.

Lemma reff128_not1278 : ~ @Equation1278 Fin4 reff128_inst.
Proof. unfold Equation1278. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff128_inst, reff128_op in H. discriminate H. Qed.

Lemma reff128_not1279 : ~ @Equation1279 Fin4 reff128_inst.
Proof. unfold Equation1279. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff128_inst, reff128_op in H. discriminate H. Qed.

Lemma reff128_not1285 : ~ @Equation1285 Fin4 reff128_inst.
Proof. unfold Equation1285. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff128_inst, reff128_op in H. discriminate H. Qed.

Lemma reff128_not1286 : ~ @Equation1286 Fin4 reff128_inst.
Proof. unfold Equation1286. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff128_inst, reff128_op in H. discriminate H. Qed.

Lemma reff128_not1288 : ~ @Equation1288 Fin4 reff128_inst.
Proof. unfold Equation1288. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff128_inst, reff128_op in H. discriminate H. Qed.

Lemma reff128_not1289 : ~ @Equation1289 Fin4 reff128_inst.
Proof. unfold Equation1289. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff128_inst, reff128_op in H. discriminate H. Qed.

Lemma reff128_not1312 : ~ @Equation1312 Fin4 reff128_inst.
Proof. unfold Equation1312. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff128_inst, reff128_op in H. discriminate H. Qed.

Lemma reff128_not1313 : ~ @Equation1313 Fin4 reff128_inst.
Proof. unfold Equation1313. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff128_inst, reff128_op in H. discriminate H. Qed.

Lemma reff128_not1315 : ~ @Equation1315 Fin4 reff128_inst.
Proof. unfold Equation1315. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff128_inst, reff128_op in H. discriminate H. Qed.

Lemma reff128_not1316 : ~ @Equation1316 Fin4 reff128_inst.
Proof. unfold Equation1316. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff128_inst, reff128_op in H. discriminate H. Qed.

Lemma reff128_not1322 : ~ @Equation1322 Fin4 reff128_inst.
Proof. unfold Equation1322. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff128_inst, reff128_op in H. discriminate H. Qed.

Lemma reff128_not1323 : ~ @Equation1323 Fin4 reff128_inst.
Proof. unfold Equation1323. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff128_inst, reff128_op in H. discriminate H. Qed.

Lemma reff128_not1325 : ~ @Equation1325 Fin4 reff128_inst.
Proof. unfold Equation1325. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff128_inst, reff128_op in H. discriminate H. Qed.

Lemma reff128_not1426 : ~ @Equation1426 Fin4 reff128_inst.
Proof. unfold Equation1426. intro H. specialize (H F4_1). unfold magma_op, reff128_inst, reff128_op in H. discriminate H. Qed.

Lemma reff128_not1629 : ~ @Equation1629 Fin4 reff128_inst.
Proof. unfold Equation1629. intro H. specialize (H F4_1). unfold magma_op, reff128_inst, reff128_op in H. discriminate H. Qed.

Lemma reff128_not1833 : ~ @Equation1833 Fin4 reff128_inst.
Proof. unfold Equation1833. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff128_inst, reff128_op in H. discriminate H. Qed.

Lemma reff128_not1834 : ~ @Equation1834 Fin4 reff128_inst.
Proof. unfold Equation1834. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff128_inst, reff128_op in H. discriminate H. Qed.

Lemma reff128_not1835 : ~ @Equation1835 Fin4 reff128_inst.
Proof. unfold Equation1835. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff128_inst, reff128_op in H. discriminate H. Qed.

Lemma reff128_not1837 : ~ @Equation1837 Fin4 reff128_inst.
Proof. unfold Equation1837. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff128_inst, reff128_op in H. discriminate H. Qed.

Lemma reff128_not1838 : ~ @Equation1838 Fin4 reff128_inst.
Proof. unfold Equation1838. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff128_inst, reff128_op in H. discriminate H. Qed.

Lemma reff128_not1840 : ~ @Equation1840 Fin4 reff128_inst.
Proof. unfold Equation1840. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff128_inst, reff128_op in H. discriminate H. Qed.

Lemma reff128_not1841 : ~ @Equation1841 Fin4 reff128_inst.
Proof. unfold Equation1841. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff128_inst, reff128_op in H. discriminate H. Qed.

Lemma reff128_not1847 : ~ @Equation1847 Fin4 reff128_inst.
Proof. unfold Equation1847. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff128_inst, reff128_op in H. discriminate H. Qed.

Lemma reff128_not1848 : ~ @Equation1848 Fin4 reff128_inst.
Proof. unfold Equation1848. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff128_inst, reff128_op in H. discriminate H. Qed.

Lemma reff128_not1850 : ~ @Equation1850 Fin4 reff128_inst.
Proof. unfold Equation1850. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff128_inst, reff128_op in H. discriminate H. Qed.

Lemma reff128_not1851 : ~ @Equation1851 Fin4 reff128_inst.
Proof. unfold Equation1851. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff128_inst, reff128_op in H. discriminate H. Qed.

Lemma reff128_not1857 : ~ @Equation1857 Fin4 reff128_inst.
Proof. unfold Equation1857. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff128_inst, reff128_op in H. discriminate H. Qed.

Lemma reff128_not1858 : ~ @Equation1858 Fin4 reff128_inst.
Proof. unfold Equation1858. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff128_inst, reff128_op in H. discriminate H. Qed.

Lemma reff128_not1860 : ~ @Equation1860 Fin4 reff128_inst.
Proof. unfold Equation1860. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff128_inst, reff128_op in H. discriminate H. Qed.

Lemma reff128_not1884 : ~ @Equation1884 Fin4 reff128_inst.
Proof. unfold Equation1884. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff128_inst, reff128_op in H. discriminate H. Qed.

Lemma reff128_not1885 : ~ @Equation1885 Fin4 reff128_inst.
Proof. unfold Equation1885. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff128_inst, reff128_op in H. discriminate H. Qed.

Lemma reff128_not1887 : ~ @Equation1887 Fin4 reff128_inst.
Proof. unfold Equation1887. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff128_inst, reff128_op in H. discriminate H. Qed.

Lemma reff128_not1888 : ~ @Equation1888 Fin4 reff128_inst.
Proof. unfold Equation1888. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff128_inst, reff128_op in H. discriminate H. Qed.

Lemma reff128_not1894 : ~ @Equation1894 Fin4 reff128_inst.
Proof. unfold Equation1894. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff128_inst, reff128_op in H. discriminate H. Qed.

Lemma reff128_not1895 : ~ @Equation1895 Fin4 reff128_inst.
Proof. unfold Equation1895. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff128_inst, reff128_op in H. discriminate H. Qed.

Lemma reff128_not1897 : ~ @Equation1897 Fin4 reff128_inst.
Proof. unfold Equation1897. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff128_inst, reff128_op in H. discriminate H. Qed.

Lemma reff128_not1898 : ~ @Equation1898 Fin4 reff128_inst.
Proof. unfold Equation1898. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff128_inst, reff128_op in H. discriminate H. Qed.

Lemma reff128_not1921 : ~ @Equation1921 Fin4 reff128_inst.
Proof. unfold Equation1921. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff128_inst, reff128_op in H. discriminate H. Qed.

Lemma reff128_not1922 : ~ @Equation1922 Fin4 reff128_inst.
Proof. unfold Equation1922. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff128_inst, reff128_op in H. discriminate H. Qed.

Lemma reff128_not1924 : ~ @Equation1924 Fin4 reff128_inst.
Proof. unfold Equation1924. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff128_inst, reff128_op in H. discriminate H. Qed.

Lemma reff128_not1925 : ~ @Equation1925 Fin4 reff128_inst.
Proof. unfold Equation1925. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff128_inst, reff128_op in H. discriminate H. Qed.

Lemma reff128_not1931 : ~ @Equation1931 Fin4 reff128_inst.
Proof. unfold Equation1931. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff128_inst, reff128_op in H. discriminate H. Qed.

Lemma reff128_not1932 : ~ @Equation1932 Fin4 reff128_inst.
Proof. unfold Equation1932. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff128_inst, reff128_op in H. discriminate H. Qed.

Lemma reff128_not1934 : ~ @Equation1934 Fin4 reff128_inst.
Proof. unfold Equation1934. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff128_inst, reff128_op in H. discriminate H. Qed.

Lemma reff128_not2035 : ~ @Equation2035 Fin4 reff128_inst.
Proof. unfold Equation2035. intro H. specialize (H F4_1). unfold magma_op, reff128_inst, reff128_op in H. discriminate H. Qed.

Lemma reff128_not2238 : ~ @Equation2238 Fin4 reff128_inst.
Proof. unfold Equation2238. intro H. specialize (H F4_1). unfold magma_op, reff128_inst, reff128_op in H. discriminate H. Qed.

Lemma reff128_not2441 : ~ @Equation2441 Fin4 reff128_inst.
Proof. unfold Equation2441. intro H. specialize (H F4_1). unfold magma_op, reff128_inst, reff128_op in H. discriminate H. Qed.

Lemma reff128_not2644 : ~ @Equation2644 Fin4 reff128_inst.
Proof. unfold Equation2644. intro H. specialize (H F4_1). unfold magma_op, reff128_inst, reff128_op in H. discriminate H. Qed.

Lemma reff128_not2847 : ~ @Equation2847 Fin4 reff128_inst.
Proof. unfold Equation2847. intro H. specialize (H F4_1). unfold magma_op, reff128_inst, reff128_op in H. discriminate H. Qed.

Lemma reff128_not3050 : ~ @Equation3050 Fin4 reff128_inst.
Proof. unfold Equation3050. intro H. specialize (H F4_1). unfold magma_op, reff128_inst, reff128_op in H. discriminate H. Qed.

Lemma reff128_not3253 : ~ @Equation3253 Fin4 reff128_inst.
Proof. unfold Equation3253. intro H. specialize (H F4_3). unfold magma_op, reff128_inst, reff128_op in H. discriminate H. Qed.

Lemma reff128_not3456 : ~ @Equation3456 Fin4 reff128_inst.
Proof. unfold Equation3456. intro H. specialize (H F4_1). unfold magma_op, reff128_inst, reff128_op in H. discriminate H. Qed.

Lemma reff128_not3660 : ~ @Equation3660 Fin4 reff128_inst.
Proof. unfold Equation3660. intro H. specialize (H F4_3 F4_0). unfold magma_op, reff128_inst, reff128_op in H. discriminate H. Qed.

Lemma reff128_not3661 : ~ @Equation3661 Fin4 reff128_inst.
Proof. unfold Equation3661. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff128_inst, reff128_op in H. discriminate H. Qed.

Lemma reff128_not3664 : ~ @Equation3664 Fin4 reff128_inst.
Proof. unfold Equation3664. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff128_inst, reff128_op in H. discriminate H. Qed.

Lemma reff128_not3665 : ~ @Equation3665 Fin4 reff128_inst.
Proof. unfold Equation3665. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff128_inst, reff128_op in H. discriminate H. Qed.

Lemma reff128_not3667 : ~ @Equation3667 Fin4 reff128_inst.
Proof. unfold Equation3667. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff128_inst, reff128_op in H. discriminate H. Qed.

Lemma reff128_not3668 : ~ @Equation3668 Fin4 reff128_inst.
Proof. unfold Equation3668. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff128_inst, reff128_op in H. discriminate H. Qed.

Lemma reff128_not3674 : ~ @Equation3674 Fin4 reff128_inst.
Proof. unfold Equation3674. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff128_inst, reff128_op in H. discriminate H. Qed.

Lemma reff128_not3675 : ~ @Equation3675 Fin4 reff128_inst.
Proof. unfold Equation3675. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff128_inst, reff128_op in H. discriminate H. Qed.

Lemma reff128_not3677 : ~ @Equation3677 Fin4 reff128_inst.
Proof. unfold Equation3677. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff128_inst, reff128_op in H. discriminate H. Qed.

Lemma reff128_not3678 : ~ @Equation3678 Fin4 reff128_inst.
Proof. unfold Equation3678. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff128_inst, reff128_op in H. discriminate H. Qed.

Lemma reff128_not3684 : ~ @Equation3684 Fin4 reff128_inst.
Proof. unfold Equation3684. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff128_inst, reff128_op in H. discriminate H. Qed.

Lemma reff128_not3685 : ~ @Equation3685 Fin4 reff128_inst.
Proof. unfold Equation3685. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff128_inst, reff128_op in H. discriminate H. Qed.

Lemma reff128_not3687 : ~ @Equation3687 Fin4 reff128_inst.
Proof. unfold Equation3687. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff128_inst, reff128_op in H. discriminate H. Qed.

Lemma reff128_not3712 : ~ @Equation3712 Fin4 reff128_inst.
Proof. unfold Equation3712. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff128_inst, reff128_op in H. discriminate H. Qed.

Lemma reff128_not3714 : ~ @Equation3714 Fin4 reff128_inst.
Proof. unfold Equation3714. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff128_inst, reff128_op in H. discriminate H. Qed.

Lemma reff128_not3721 : ~ @Equation3721 Fin4 reff128_inst.
Proof. unfold Equation3721. intro H. specialize (H F4_3 F4_0). unfold magma_op, reff128_inst, reff128_op in H. discriminate H. Qed.

Lemma reff128_not3722 : ~ @Equation3722 Fin4 reff128_inst.
Proof. unfold Equation3722. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff128_inst, reff128_op in H. discriminate H. Qed.

Lemma reff128_not3725 : ~ @Equation3725 Fin4 reff128_inst.
Proof. unfold Equation3725. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff128_inst, reff128_op in H. discriminate H. Qed.

Lemma reff128_not3748 : ~ @Equation3748 Fin4 reff128_inst.
Proof. unfold Equation3748. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff128_inst, reff128_op in H. discriminate H. Qed.

Lemma reff128_not3749 : ~ @Equation3749 Fin4 reff128_inst.
Proof. unfold Equation3749. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff128_inst, reff128_op in H. discriminate H. Qed.

Lemma reff128_not3751 : ~ @Equation3751 Fin4 reff128_inst.
Proof. unfold Equation3751. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff128_inst, reff128_op in H. discriminate H. Qed.

Lemma reff128_not3752 : ~ @Equation3752 Fin4 reff128_inst.
Proof. unfold Equation3752. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff128_inst, reff128_op in H. discriminate H. Qed.

Lemma reff128_not3759 : ~ @Equation3759 Fin4 reff128_inst.
Proof. unfold Equation3759. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff128_inst, reff128_op in H. discriminate H. Qed.

Lemma reff128_not3761 : ~ @Equation3761 Fin4 reff128_inst.
Proof. unfold Equation3761. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff128_inst, reff128_op in H. discriminate H. Qed.

Lemma reff128_not3864 : ~ @Equation3864 Fin4 reff128_inst.
Proof. unfold Equation3864. intro H. specialize (H F4_3 F4_0). unfold magma_op, reff128_inst, reff128_op in H. discriminate H. Qed.

Lemma reff128_not3865 : ~ @Equation3865 Fin4 reff128_inst.
Proof. unfold Equation3865. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff128_inst, reff128_op in H. discriminate H. Qed.

Lemma reff128_not3867 : ~ @Equation3867 Fin4 reff128_inst.
Proof. unfold Equation3867. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff128_inst, reff128_op in H. discriminate H. Qed.

Lemma reff128_not3868 : ~ @Equation3868 Fin4 reff128_inst.
Proof. unfold Equation3868. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff128_inst, reff128_op in H. discriminate H. Qed.

Lemma reff128_not3871 : ~ @Equation3871 Fin4 reff128_inst.
Proof. unfold Equation3871. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff128_inst, reff128_op in H. discriminate H. Qed.

Lemma reff128_not3877 : ~ @Equation3877 Fin4 reff128_inst.
Proof. unfold Equation3877. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff128_inst, reff128_op in H. discriminate H. Qed.

Lemma reff128_not3878 : ~ @Equation3878 Fin4 reff128_inst.
Proof. unfold Equation3878. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff128_inst, reff128_op in H. discriminate H. Qed.

Lemma reff128_not3880 : ~ @Equation3880 Fin4 reff128_inst.
Proof. unfold Equation3880. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff128_inst, reff128_op in H. discriminate H. Qed.

Lemma reff128_not3881 : ~ @Equation3881 Fin4 reff128_inst.
Proof. unfold Equation3881. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff128_inst, reff128_op in H. discriminate H. Qed.

Lemma reff128_not3887 : ~ @Equation3887 Fin4 reff128_inst.
Proof. unfold Equation3887. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff128_inst, reff128_op in H. discriminate H. Qed.

Lemma reff128_not3888 : ~ @Equation3888 Fin4 reff128_inst.
Proof. unfold Equation3888. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff128_inst, reff128_op in H. discriminate H. Qed.

Lemma reff128_not3890 : ~ @Equation3890 Fin4 reff128_inst.
Proof. unfold Equation3890. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff128_inst, reff128_op in H. discriminate H. Qed.

Lemma reff128_not3915 : ~ @Equation3915 Fin4 reff128_inst.
Proof. unfold Equation3915. intro H. specialize (H F4_3 F4_0). unfold magma_op, reff128_inst, reff128_op in H. discriminate H. Qed.

Lemma reff128_not3917 : ~ @Equation3917 Fin4 reff128_inst.
Proof. unfold Equation3917. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff128_inst, reff128_op in H. discriminate H. Qed.

Lemma reff128_not3918 : ~ @Equation3918 Fin4 reff128_inst.
Proof. unfold Equation3918. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff128_inst, reff128_op in H. discriminate H. Qed.

Lemma reff128_not3927 : ~ @Equation3927 Fin4 reff128_inst.
Proof. unfold Equation3927. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff128_inst, reff128_op in H. discriminate H. Qed.

Lemma reff128_not3928 : ~ @Equation3928 Fin4 reff128_inst.
Proof. unfold Equation3928. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff128_inst, reff128_op in H. discriminate H. Qed.

Lemma reff128_not3951 : ~ @Equation3951 Fin4 reff128_inst.
Proof. unfold Equation3951. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff128_inst, reff128_op in H. discriminate H. Qed.

Lemma reff128_not3952 : ~ @Equation3952 Fin4 reff128_inst.
Proof. unfold Equation3952. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff128_inst, reff128_op in H. discriminate H. Qed.

Lemma reff128_not3954 : ~ @Equation3954 Fin4 reff128_inst.
Proof. unfold Equation3954. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff128_inst, reff128_op in H. discriminate H. Qed.

Lemma reff128_not3955 : ~ @Equation3955 Fin4 reff128_inst.
Proof. unfold Equation3955. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff128_inst, reff128_op in H. discriminate H. Qed.

Lemma reff128_not3961 : ~ @Equation3961 Fin4 reff128_inst.
Proof. unfold Equation3961. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff128_inst, reff128_op in H. discriminate H. Qed.

Lemma reff128_not3962 : ~ @Equation3962 Fin4 reff128_inst.
Proof. unfold Equation3962. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff128_inst, reff128_op in H. discriminate H. Qed.

Lemma reff128_not3964 : ~ @Equation3964 Fin4 reff128_inst.
Proof. unfold Equation3964. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff128_inst, reff128_op in H. discriminate H. Qed.

Lemma reff128_not4065 : ~ @Equation4065 Fin4 reff128_inst.
Proof. unfold Equation4065. intro H. specialize (H F4_3). unfold magma_op, reff128_inst, reff128_op in H. discriminate H. Qed.

Lemma reff128_not4268 : ~ @Equation4268 Fin4 reff128_inst.
Proof. unfold Equation4268. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff128_inst, reff128_op in H. discriminate H. Qed.

Lemma reff128_not4269 : ~ @Equation4269 Fin4 reff128_inst.
Proof. unfold Equation4269. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff128_inst, reff128_op in H. discriminate H. Qed.

Lemma reff128_not4270 : ~ @Equation4270 Fin4 reff128_inst.
Proof. unfold Equation4270. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff128_inst, reff128_op in H. discriminate H. Qed.

Lemma reff128_not4272 : ~ @Equation4272 Fin4 reff128_inst.
Proof. unfold Equation4272. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff128_inst, reff128_op in H. discriminate H. Qed.

Lemma reff128_not4273 : ~ @Equation4273 Fin4 reff128_inst.
Proof. unfold Equation4273. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff128_inst, reff128_op in H. discriminate H. Qed.

Lemma reff128_not4275 : ~ @Equation4275 Fin4 reff128_inst.
Proof. unfold Equation4275. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff128_inst, reff128_op in H. discriminate H. Qed.

Lemma reff128_not4276 : ~ @Equation4276 Fin4 reff128_inst.
Proof. unfold Equation4276. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff128_inst, reff128_op in H. discriminate H. Qed.

Lemma reff128_not4283 : ~ @Equation4283 Fin4 reff128_inst.
Proof. unfold Equation4283. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff128_inst, reff128_op in H. discriminate H. Qed.

Lemma reff128_not4284 : ~ @Equation4284 Fin4 reff128_inst.
Proof. unfold Equation4284. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff128_inst, reff128_op in H. discriminate H. Qed.

Lemma reff128_not4290 : ~ @Equation4290 Fin4 reff128_inst.
Proof. unfold Equation4290. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff128_inst, reff128_op in H. discriminate H. Qed.

Lemma reff128_not4291 : ~ @Equation4291 Fin4 reff128_inst.
Proof. unfold Equation4291. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff128_inst, reff128_op in H. discriminate H. Qed.

Lemma reff128_not4293 : ~ @Equation4293 Fin4 reff128_inst.
Proof. unfold Equation4293. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff128_inst, reff128_op in H. discriminate H. Qed.

Lemma reff128_not4314 : ~ @Equation4314 Fin4 reff128_inst.
Proof. unfold Equation4314. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff128_inst, reff128_op in H. discriminate H. Qed.

Lemma reff128_not4320 : ~ @Equation4320 Fin4 reff128_inst.
Proof. unfold Equation4320. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff128_inst, reff128_op in H. discriminate H. Qed.

Lemma reff128_not4321 : ~ @Equation4321 Fin4 reff128_inst.
Proof. unfold Equation4321. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff128_inst, reff128_op in H. discriminate H. Qed.

Lemma reff128_not4343 : ~ @Equation4343 Fin4 reff128_inst.
Proof. unfold Equation4343. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff128_inst, reff128_op in H. discriminate H. Qed.

Lemma reff128_not4380 : ~ @Equation4380 Fin4 reff128_inst.
Proof. unfold Equation4380. intro H. specialize (H F4_1). unfold magma_op, reff128_inst, reff128_op in H. discriminate H. Qed.

Lemma reff128_not4583 : ~ @Equation4583 Fin4 reff128_inst.
Proof. unfold Equation4583. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff128_inst, reff128_op in H. discriminate H. Qed.

Lemma reff128_not4584 : ~ @Equation4584 Fin4 reff128_inst.
Proof. unfold Equation4584. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff128_inst, reff128_op in H. discriminate H. Qed.

Lemma reff128_not4585 : ~ @Equation4585 Fin4 reff128_inst.
Proof. unfold Equation4585. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff128_inst, reff128_op in H. discriminate H. Qed.

Lemma reff128_not4587 : ~ @Equation4587 Fin4 reff128_inst.
Proof. unfold Equation4587. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff128_inst, reff128_op in H. discriminate H. Qed.

Lemma reff128_not4588 : ~ @Equation4588 Fin4 reff128_inst.
Proof. unfold Equation4588. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff128_inst, reff128_op in H. discriminate H. Qed.

Lemma reff128_not4590 : ~ @Equation4590 Fin4 reff128_inst.
Proof. unfold Equation4590. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff128_inst, reff128_op in H. discriminate H. Qed.

Lemma reff128_not4591 : ~ @Equation4591 Fin4 reff128_inst.
Proof. unfold Equation4591. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff128_inst, reff128_op in H. discriminate H. Qed.

Lemma reff128_not4599 : ~ @Equation4599 Fin4 reff128_inst.
Proof. unfold Equation4599. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff128_inst, reff128_op in H. discriminate H. Qed.

Lemma reff128_not4605 : ~ @Equation4605 Fin4 reff128_inst.
Proof. unfold Equation4605. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff128_inst, reff128_op in H. discriminate H. Qed.

Lemma reff128_not4606 : ~ @Equation4606 Fin4 reff128_inst.
Proof. unfold Equation4606. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff128_inst, reff128_op in H. discriminate H. Qed.

Lemma reff128_not4608 : ~ @Equation4608 Fin4 reff128_inst.
Proof. unfold Equation4608. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff128_inst, reff128_op in H. discriminate H. Qed.

Lemma reff128_not4629 : ~ @Equation4629 Fin4 reff128_inst.
Proof. unfold Equation4629. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff128_inst, reff128_op in H. discriminate H. Qed.

Lemma reff128_not4635 : ~ @Equation4635 Fin4 reff128_inst.
Proof. unfold Equation4635. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff128_inst, reff128_op in H. discriminate H. Qed.

Lemma reff128_not4636 : ~ @Equation4636 Fin4 reff128_inst.
Proof. unfold Equation4636. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff128_inst, reff128_op in H. discriminate H. Qed.

Lemma reff128_not4658 : ~ @Equation4658 Fin4 reff128_inst.
Proof. unfold Equation4658. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff128_inst, reff128_op in H. discriminate H. Qed.

(** ---- reff132 (Fin3) ---- *)

Definition reff132_op (x y : Fin3) : Fin3 :=
  match x, y with
  | F3_0, F3_0 => F3_0 | F3_0, F3_1 => F3_2 | F3_0, F3_2 => F3_1
  | F3_1, F3_0 => F3_0 | F3_1, F3_1 => F3_0 | F3_1, F3_2 => F3_0
  | F3_2, F3_0 => F3_0 | F3_2, F3_1 => F3_1 | F3_2, F3_2 => F3_2
  end.

#[local] Instance reff132_inst : Magma Fin3 := {| magma_op := reff132_op |}.

Lemma reff132_sat255 : @Equation255 Fin3 reff132_inst.
Proof. unfold Equation255, magma_op, reff132_inst, reff132_op. intros x. destruct x; reflexivity. Qed.

Lemma reff132_sat307 : @Equation307 Fin3 reff132_inst.
Proof. unfold Equation307, magma_op, reff132_inst, reff132_op. intros x. destruct x; reflexivity. Qed.

Lemma reff132_sat1731 : @Equation1731 Fin3 reff132_inst.
Proof. unfold Equation1731, magma_op, reff132_inst, reff132_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff132_sat2847 : @Equation2847 Fin3 reff132_inst.
Proof. unfold Equation2847, magma_op, reff132_inst, reff132_op. intros x. destruct x; reflexivity. Qed.

Lemma reff132_sat3306 : @Equation3306 Fin3 reff132_inst.
Proof. unfold Equation3306, magma_op, reff132_inst, reff132_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff132_sat3456 : @Equation3456 Fin3 reff132_inst.
Proof. unfold Equation3456, magma_op, reff132_inst, reff132_op. intros x. destruct x; reflexivity. Qed.

Lemma reff132_sat3659 : @Equation3659 Fin3 reff132_inst.
Proof. unfold Equation3659, magma_op, reff132_inst, reff132_op. intros x. destruct x; reflexivity. Qed.

Lemma reff132_sat4362 : @Equation4362 Fin3 reff132_inst.
Proof. unfold Equation4362, magma_op, reff132_inst, reff132_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff132_not47 : ~ @Equation47 Fin3 reff132_inst.
Proof. unfold Equation47. intro H. specialize (H F3_1). unfold magma_op, reff132_inst, reff132_op in H. discriminate H. Qed.

Lemma reff132_not99 : ~ @Equation99 Fin3 reff132_inst.
Proof. unfold Equation99. intro H. specialize (H F3_1). unfold magma_op, reff132_inst, reff132_op in H. discriminate H. Qed.

Lemma reff132_not151 : ~ @Equation151 Fin3 reff132_inst.
Proof. unfold Equation151. intro H. specialize (H F3_1). unfold magma_op, reff132_inst, reff132_op in H. discriminate H. Qed.

Lemma reff132_not203 : ~ @Equation203 Fin3 reff132_inst.
Proof. unfold Equation203. intro H. specialize (H F3_1). unfold magma_op, reff132_inst, reff132_op in H. discriminate H. Qed.

Lemma reff132_not258 : ~ @Equation258 Fin3 reff132_inst.
Proof. unfold Equation258. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff132_inst, reff132_op in H. discriminate H. Qed.

Lemma reff132_not261 : ~ @Equation261 Fin3 reff132_inst.
Proof. unfold Equation261. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff132_inst, reff132_op in H. discriminate H. Qed.

Lemma reff132_not263 : ~ @Equation263 Fin3 reff132_inst.
Proof. unfold Equation263. intro H. specialize (H F3_1 F3_0). unfold magma_op, reff132_inst, reff132_op in H. discriminate H. Qed.

Lemma reff132_not264 : ~ @Equation264 Fin3 reff132_inst.
Proof. unfold Equation264. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff132_inst, reff132_op in H. discriminate H. Qed.

Lemma reff132_not271 : ~ @Equation271 Fin3 reff132_inst.
Proof. unfold Equation271. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff132_inst, reff132_op in H. discriminate H. Qed.

Lemma reff132_not273 : ~ @Equation273 Fin3 reff132_inst.
Proof. unfold Equation273. intro H. specialize (H F3_1 F3_0). unfold magma_op, reff132_inst, reff132_op in H. discriminate H. Qed.

Lemma reff132_not274 : ~ @Equation274 Fin3 reff132_inst.
Proof. unfold Equation274. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff132_inst, reff132_op in H. discriminate H. Qed.

Lemma reff132_not280 : ~ @Equation280 Fin3 reff132_inst.
Proof. unfold Equation280. intro H. specialize (H F3_1 F3_2). unfold magma_op, reff132_inst, reff132_op in H. discriminate H. Qed.

Lemma reff132_not281 : ~ @Equation281 Fin3 reff132_inst.
Proof. unfold Equation281. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff132_inst, reff132_op in H. discriminate H. Qed.

Lemma reff132_not283 : ~ @Equation283 Fin3 reff132_inst.
Proof. unfold Equation283. intro H. specialize (H F3_1 F3_0). unfold magma_op, reff132_inst, reff132_op in H. discriminate H. Qed.

Lemma reff132_not323 : ~ @Equation323 Fin3 reff132_inst.
Proof. unfold Equation323. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff132_inst, reff132_op in H. discriminate H. Qed.

Lemma reff132_not411 : ~ @Equation411 Fin3 reff132_inst.
Proof. unfold Equation411. intro H. specialize (H F3_1). unfold magma_op, reff132_inst, reff132_op in H. discriminate H. Qed.

Lemma reff132_not614 : ~ @Equation614 Fin3 reff132_inst.
Proof. unfold Equation614. intro H. specialize (H F3_1). unfold magma_op, reff132_inst, reff132_op in H. discriminate H. Qed.

Lemma reff132_not817 : ~ @Equation817 Fin3 reff132_inst.
Proof. unfold Equation817. intro H. specialize (H F3_1). unfold magma_op, reff132_inst, reff132_op in H. discriminate H. Qed.

Lemma reff132_not1020 : ~ @Equation1020 Fin3 reff132_inst.
Proof. unfold Equation1020. intro H. specialize (H F3_1). unfold magma_op, reff132_inst, reff132_op in H. discriminate H. Qed.

Lemma reff132_not1223 : ~ @Equation1223 Fin3 reff132_inst.
Proof. unfold Equation1223. intro H. specialize (H F3_1). unfold magma_op, reff132_inst, reff132_op in H. discriminate H. Qed.

Lemma reff132_not1426 : ~ @Equation1426 Fin3 reff132_inst.
Proof. unfold Equation1426. intro H. specialize (H F3_1). unfold magma_op, reff132_inst, reff132_op in H. discriminate H. Qed.

Lemma reff132_not1630 : ~ @Equation1630 Fin3 reff132_inst.
Proof. unfold Equation1630. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff132_inst, reff132_op in H. discriminate H. Qed.

Lemma reff132_not1631 : ~ @Equation1631 Fin3 reff132_inst.
Proof. unfold Equation1631. intro H. specialize (H F3_2 F3_0). unfold magma_op, reff132_inst, reff132_op in H. discriminate H. Qed.

Lemma reff132_not1632 : ~ @Equation1632 Fin3 reff132_inst.
Proof. unfold Equation1632. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff132_inst, reff132_op in H. discriminate H. Qed.

Lemma reff132_not1634 : ~ @Equation1634 Fin3 reff132_inst.
Proof. unfold Equation1634. intro H. specialize (H F3_1 F3_0). unfold magma_op, reff132_inst, reff132_op in H. discriminate H. Qed.

Lemma reff132_not1635 : ~ @Equation1635 Fin3 reff132_inst.
Proof. unfold Equation1635. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff132_inst, reff132_op in H. discriminate H. Qed.

Lemma reff132_not1637 : ~ @Equation1637 Fin3 reff132_inst.
Proof. unfold Equation1637. intro H. specialize (H F3_1 F3_2). unfold magma_op, reff132_inst, reff132_op in H. discriminate H. Qed.

Lemma reff132_not1638 : ~ @Equation1638 Fin3 reff132_inst.
Proof. unfold Equation1638. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff132_inst, reff132_op in H. discriminate H. Qed.

Lemma reff132_not1644 : ~ @Equation1644 Fin3 reff132_inst.
Proof. unfold Equation1644. intro H. specialize (H F3_2 F3_0). unfold magma_op, reff132_inst, reff132_op in H. discriminate H. Qed.

Lemma reff132_not1645 : ~ @Equation1645 Fin3 reff132_inst.
Proof. unfold Equation1645. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff132_inst, reff132_op in H. discriminate H. Qed.

Lemma reff132_not1647 : ~ @Equation1647 Fin3 reff132_inst.
Proof. unfold Equation1647. intro H. specialize (H F3_2 F3_1). unfold magma_op, reff132_inst, reff132_op in H. discriminate H. Qed.

Lemma reff132_not1648 : ~ @Equation1648 Fin3 reff132_inst.
Proof. unfold Equation1648. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff132_inst, reff132_op in H. discriminate H. Qed.

Lemma reff132_not1654 : ~ @Equation1654 Fin3 reff132_inst.
Proof. unfold Equation1654. intro H. specialize (H F3_1 F3_0). unfold magma_op, reff132_inst, reff132_op in H. discriminate H. Qed.

Lemma reff132_not1655 : ~ @Equation1655 Fin3 reff132_inst.
Proof. unfold Equation1655. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff132_inst, reff132_op in H. discriminate H. Qed.

Lemma reff132_not1657 : ~ @Equation1657 Fin3 reff132_inst.
Proof. unfold Equation1657. intro H. specialize (H F3_1 F3_2). unfold magma_op, reff132_inst, reff132_op in H. discriminate H. Qed.

Lemma reff132_not1658 : ~ @Equation1658 Fin3 reff132_inst.
Proof. unfold Equation1658. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff132_inst, reff132_op in H. discriminate H. Qed.

Lemma reff132_not1681 : ~ @Equation1681 Fin3 reff132_inst.
Proof. unfold Equation1681. intro H. specialize (H F3_1 F3_0). unfold magma_op, reff132_inst, reff132_op in H. discriminate H. Qed.

Lemma reff132_not1682 : ~ @Equation1682 Fin3 reff132_inst.
Proof. unfold Equation1682. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff132_inst, reff132_op in H. discriminate H. Qed.

Lemma reff132_not1684 : ~ @Equation1684 Fin3 reff132_inst.
Proof. unfold Equation1684. intro H. specialize (H F3_1 F3_0). unfold magma_op, reff132_inst, reff132_op in H. discriminate H. Qed.

Lemma reff132_not1685 : ~ @Equation1685 Fin3 reff132_inst.
Proof. unfold Equation1685. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff132_inst, reff132_op in H. discriminate H. Qed.

Lemma reff132_not1691 : ~ @Equation1691 Fin3 reff132_inst.
Proof. unfold Equation1691. intro H. specialize (H F3_1 F3_2). unfold magma_op, reff132_inst, reff132_op in H. discriminate H. Qed.

Lemma reff132_not1692 : ~ @Equation1692 Fin3 reff132_inst.
Proof. unfold Equation1692. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff132_inst, reff132_op in H. discriminate H. Qed.

Lemma reff132_not1694 : ~ @Equation1694 Fin3 reff132_inst.
Proof. unfold Equation1694. intro H. specialize (H F3_1 F3_0). unfold magma_op, reff132_inst, reff132_op in H. discriminate H. Qed.

Lemma reff132_not1695 : ~ @Equation1695 Fin3 reff132_inst.
Proof. unfold Equation1695. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff132_inst, reff132_op in H. discriminate H. Qed.

Lemma reff132_not1718 : ~ @Equation1718 Fin3 reff132_inst.
Proof. unfold Equation1718. intro H. specialize (H F3_1 F3_2). unfold magma_op, reff132_inst, reff132_op in H. discriminate H. Qed.

Lemma reff132_not1719 : ~ @Equation1719 Fin3 reff132_inst.
Proof. unfold Equation1719. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff132_inst, reff132_op in H. discriminate H. Qed.

Lemma reff132_not1721 : ~ @Equation1721 Fin3 reff132_inst.
Proof. unfold Equation1721. intro H. specialize (H F3_1 F3_2). unfold magma_op, reff132_inst, reff132_op in H. discriminate H. Qed.

Lemma reff132_not1722 : ~ @Equation1722 Fin3 reff132_inst.
Proof. unfold Equation1722. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff132_inst, reff132_op in H. discriminate H. Qed.

Lemma reff132_not1728 : ~ @Equation1728 Fin3 reff132_inst.
Proof. unfold Equation1728. intro H. specialize (H F3_1 F3_0). unfold magma_op, reff132_inst, reff132_op in H. discriminate H. Qed.

Lemma reff132_not1729 : ~ @Equation1729 Fin3 reff132_inst.
Proof. unfold Equation1729. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff132_inst, reff132_op in H. discriminate H. Qed.

Lemma reff132_not1832 : ~ @Equation1832 Fin3 reff132_inst.
Proof. unfold Equation1832. intro H. specialize (H F3_1). unfold magma_op, reff132_inst, reff132_op in H. discriminate H. Qed.

Lemma reff132_not2035 : ~ @Equation2035 Fin3 reff132_inst.
Proof. unfold Equation2035. intro H. specialize (H F3_1). unfold magma_op, reff132_inst, reff132_op in H. discriminate H. Qed.

Lemma reff132_not2238 : ~ @Equation2238 Fin3 reff132_inst.
Proof. unfold Equation2238. intro H. specialize (H F3_1). unfold magma_op, reff132_inst, reff132_op in H. discriminate H. Qed.

Lemma reff132_not2441 : ~ @Equation2441 Fin3 reff132_inst.
Proof. unfold Equation2441. intro H. specialize (H F3_1). unfold magma_op, reff132_inst, reff132_op in H. discriminate H. Qed.

Lemma reff132_not2644 : ~ @Equation2644 Fin3 reff132_inst.
Proof. unfold Equation2644. intro H. specialize (H F3_1). unfold magma_op, reff132_inst, reff132_op in H. discriminate H. Qed.

Lemma reff132_not2848 : ~ @Equation2848 Fin3 reff132_inst.
Proof. unfold Equation2848. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff132_inst, reff132_op in H. discriminate H. Qed.

Lemma reff132_not2849 : ~ @Equation2849 Fin3 reff132_inst.
Proof. unfold Equation2849. intro H. specialize (H F3_1 F3_0). unfold magma_op, reff132_inst, reff132_op in H. discriminate H. Qed.

Lemma reff132_not2850 : ~ @Equation2850 Fin3 reff132_inst.
Proof. unfold Equation2850. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff132_inst, reff132_op in H. discriminate H. Qed.

Lemma reff132_not2852 : ~ @Equation2852 Fin3 reff132_inst.
Proof. unfold Equation2852. intro H. specialize (H F3_2 F3_0). unfold magma_op, reff132_inst, reff132_op in H. discriminate H. Qed.

Lemma reff132_not2853 : ~ @Equation2853 Fin3 reff132_inst.
Proof. unfold Equation2853. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff132_inst, reff132_op in H. discriminate H. Qed.

Lemma reff132_not2855 : ~ @Equation2855 Fin3 reff132_inst.
Proof. unfold Equation2855. intro H. specialize (H F3_1 F3_0). unfold magma_op, reff132_inst, reff132_op in H. discriminate H. Qed.

Lemma reff132_not2856 : ~ @Equation2856 Fin3 reff132_inst.
Proof. unfold Equation2856. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff132_inst, reff132_op in H. discriminate H. Qed.

Lemma reff132_not2862 : ~ @Equation2862 Fin3 reff132_inst.
Proof. unfold Equation2862. intro H. specialize (H F3_2 F3_0). unfold magma_op, reff132_inst, reff132_op in H. discriminate H. Qed.

Lemma reff132_not2863 : ~ @Equation2863 Fin3 reff132_inst.
Proof. unfold Equation2863. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff132_inst, reff132_op in H. discriminate H. Qed.

Lemma reff132_not2865 : ~ @Equation2865 Fin3 reff132_inst.
Proof. unfold Equation2865. intro H. specialize (H F3_1 F3_0). unfold magma_op, reff132_inst, reff132_op in H. discriminate H. Qed.

Lemma reff132_not2866 : ~ @Equation2866 Fin3 reff132_inst.
Proof. unfold Equation2866. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff132_inst, reff132_op in H. discriminate H. Qed.

Lemma reff132_not2872 : ~ @Equation2872 Fin3 reff132_inst.
Proof. unfold Equation2872. intro H. specialize (H F3_2 F3_0). unfold magma_op, reff132_inst, reff132_op in H. discriminate H. Qed.

Lemma reff132_not2873 : ~ @Equation2873 Fin3 reff132_inst.
Proof. unfold Equation2873. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff132_inst, reff132_op in H. discriminate H. Qed.

Lemma reff132_not2875 : ~ @Equation2875 Fin3 reff132_inst.
Proof. unfold Equation2875. intro H. specialize (H F3_1 F3_0). unfold magma_op, reff132_inst, reff132_op in H. discriminate H. Qed.

Lemma reff132_not2876 : ~ @Equation2876 Fin3 reff132_inst.
Proof. unfold Equation2876. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff132_inst, reff132_op in H. discriminate H. Qed.

Lemma reff132_not2899 : ~ @Equation2899 Fin3 reff132_inst.
Proof. unfold Equation2899. intro H. specialize (H F3_2 F3_0). unfold magma_op, reff132_inst, reff132_op in H. discriminate H. Qed.

Lemma reff132_not2900 : ~ @Equation2900 Fin3 reff132_inst.
Proof. unfold Equation2900. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff132_inst, reff132_op in H. discriminate H. Qed.

Lemma reff132_not2902 : ~ @Equation2902 Fin3 reff132_inst.
Proof. unfold Equation2902. intro H. specialize (H F3_1 F3_0). unfold magma_op, reff132_inst, reff132_op in H. discriminate H. Qed.

Lemma reff132_not2903 : ~ @Equation2903 Fin3 reff132_inst.
Proof. unfold Equation2903. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff132_inst, reff132_op in H. discriminate H. Qed.

Lemma reff132_not2909 : ~ @Equation2909 Fin3 reff132_inst.
Proof. unfold Equation2909. intro H. specialize (H F3_2 F3_0). unfold magma_op, reff132_inst, reff132_op in H. discriminate H. Qed.

Lemma reff132_not2910 : ~ @Equation2910 Fin3 reff132_inst.
Proof. unfold Equation2910. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff132_inst, reff132_op in H. discriminate H. Qed.

Lemma reff132_not2912 : ~ @Equation2912 Fin3 reff132_inst.
Proof. unfold Equation2912. intro H. specialize (H F3_1 F3_0). unfold magma_op, reff132_inst, reff132_op in H. discriminate H. Qed.

Lemma reff132_not2913 : ~ @Equation2913 Fin3 reff132_inst.
Proof. unfold Equation2913. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff132_inst, reff132_op in H. discriminate H. Qed.

Lemma reff132_not2936 : ~ @Equation2936 Fin3 reff132_inst.
Proof. unfold Equation2936. intro H. specialize (H F3_1 F3_0). unfold magma_op, reff132_inst, reff132_op in H. discriminate H. Qed.

Lemma reff132_not2937 : ~ @Equation2937 Fin3 reff132_inst.
Proof. unfold Equation2937. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff132_inst, reff132_op in H. discriminate H. Qed.

Lemma reff132_not2939 : ~ @Equation2939 Fin3 reff132_inst.
Proof. unfold Equation2939. intro H. specialize (H F3_1 F3_0). unfold magma_op, reff132_inst, reff132_op in H. discriminate H. Qed.

Lemma reff132_not2940 : ~ @Equation2940 Fin3 reff132_inst.
Proof. unfold Equation2940. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff132_inst, reff132_op in H. discriminate H. Qed.

Lemma reff132_not2946 : ~ @Equation2946 Fin3 reff132_inst.
Proof. unfold Equation2946. intro H. specialize (H F3_1 F3_2). unfold magma_op, reff132_inst, reff132_op in H. discriminate H. Qed.

Lemma reff132_not2947 : ~ @Equation2947 Fin3 reff132_inst.
Proof. unfold Equation2947. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff132_inst, reff132_op in H. discriminate H. Qed.

Lemma reff132_not2949 : ~ @Equation2949 Fin3 reff132_inst.
Proof. unfold Equation2949. intro H. specialize (H F3_1 F3_0). unfold magma_op, reff132_inst, reff132_op in H. discriminate H. Qed.

Lemma reff132_not3050 : ~ @Equation3050 Fin3 reff132_inst.
Proof. unfold Equation3050. intro H. specialize (H F3_1). unfold magma_op, reff132_inst, reff132_op in H. discriminate H. Qed.

Lemma reff132_not3254 : ~ @Equation3254 Fin3 reff132_inst.
Proof. unfold Equation3254. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff132_inst, reff132_op in H. discriminate H. Qed.

Lemma reff132_not3255 : ~ @Equation3255 Fin3 reff132_inst.
Proof. unfold Equation3255. intro H. specialize (H F3_2 F3_0). unfold magma_op, reff132_inst, reff132_op in H. discriminate H. Qed.

Lemma reff132_not3256 : ~ @Equation3256 Fin3 reff132_inst.
Proof. unfold Equation3256. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff132_inst, reff132_op in H. discriminate H. Qed.

Lemma reff132_not3258 : ~ @Equation3258 Fin3 reff132_inst.
Proof. unfold Equation3258. intro H. specialize (H F3_2 F3_0). unfold magma_op, reff132_inst, reff132_op in H. discriminate H. Qed.

Lemma reff132_not3259 : ~ @Equation3259 Fin3 reff132_inst.
Proof. unfold Equation3259. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff132_inst, reff132_op in H. discriminate H. Qed.

Lemma reff132_not3261 : ~ @Equation3261 Fin3 reff132_inst.
Proof. unfold Equation3261. intro H. specialize (H F3_2 F3_1). unfold magma_op, reff132_inst, reff132_op in H. discriminate H. Qed.

Lemma reff132_not3262 : ~ @Equation3262 Fin3 reff132_inst.
Proof. unfold Equation3262. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff132_inst, reff132_op in H. discriminate H. Qed.

Lemma reff132_not3268 : ~ @Equation3268 Fin3 reff132_inst.
Proof. unfold Equation3268. intro H. specialize (H F3_2 F3_0). unfold magma_op, reff132_inst, reff132_op in H. discriminate H. Qed.

Lemma reff132_not3269 : ~ @Equation3269 Fin3 reff132_inst.
Proof. unfold Equation3269. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff132_inst, reff132_op in H. discriminate H. Qed.

Lemma reff132_not3271 : ~ @Equation3271 Fin3 reff132_inst.
Proof. unfold Equation3271. intro H. specialize (H F3_2 F3_1). unfold magma_op, reff132_inst, reff132_op in H. discriminate H. Qed.

Lemma reff132_not3272 : ~ @Equation3272 Fin3 reff132_inst.
Proof. unfold Equation3272. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff132_inst, reff132_op in H. discriminate H. Qed.

Lemma reff132_not3278 : ~ @Equation3278 Fin3 reff132_inst.
Proof. unfold Equation3278. intro H. specialize (H F3_2 F3_1). unfold magma_op, reff132_inst, reff132_op in H. discriminate H. Qed.

Lemma reff132_not3279 : ~ @Equation3279 Fin3 reff132_inst.
Proof. unfold Equation3279. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff132_inst, reff132_op in H. discriminate H. Qed.

Lemma reff132_not3281 : ~ @Equation3281 Fin3 reff132_inst.
Proof. unfold Equation3281. intro H. specialize (H F3_1 F3_0). unfold magma_op, reff132_inst, reff132_op in H. discriminate H. Qed.

Lemma reff132_not3308 : ~ @Equation3308 Fin3 reff132_inst.
Proof. unfold Equation3308. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff132_inst, reff132_op in H. discriminate H. Qed.

Lemma reff132_not3309 : ~ @Equation3309 Fin3 reff132_inst.
Proof. unfold Equation3309. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff132_inst, reff132_op in H. discriminate H. Qed.

Lemma reff132_not3315 : ~ @Equation3315 Fin3 reff132_inst.
Proof. unfold Equation3315. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff132_inst, reff132_op in H. discriminate H. Qed.

Lemma reff132_not3316 : ~ @Equation3316 Fin3 reff132_inst.
Proof. unfold Equation3316. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff132_inst, reff132_op in H. discriminate H. Qed.

Lemma reff132_not3318 : ~ @Equation3318 Fin3 reff132_inst.
Proof. unfold Equation3318. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff132_inst, reff132_op in H. discriminate H. Qed.

Lemma reff132_not3319 : ~ @Equation3319 Fin3 reff132_inst.
Proof. unfold Equation3319. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff132_inst, reff132_op in H. discriminate H. Qed.

Lemma reff132_not3342 : ~ @Equation3342 Fin3 reff132_inst.
Proof. unfold Equation3342. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff132_inst, reff132_op in H. discriminate H. Qed.

Lemma reff132_not3343 : ~ @Equation3343 Fin3 reff132_inst.
Proof. unfold Equation3343. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff132_inst, reff132_op in H. discriminate H. Qed.

Lemma reff132_not3345 : ~ @Equation3345 Fin3 reff132_inst.
Proof. unfold Equation3345. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff132_inst, reff132_op in H. discriminate H. Qed.

Lemma reff132_not3346 : ~ @Equation3346 Fin3 reff132_inst.
Proof. unfold Equation3346. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff132_inst, reff132_op in H. discriminate H. Qed.

Lemma reff132_not3352 : ~ @Equation3352 Fin3 reff132_inst.
Proof. unfold Equation3352. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff132_inst, reff132_op in H. discriminate H. Qed.

Lemma reff132_not3353 : ~ @Equation3353 Fin3 reff132_inst.
Proof. unfold Equation3353. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff132_inst, reff132_op in H. discriminate H. Qed.

Lemma reff132_not3457 : ~ @Equation3457 Fin3 reff132_inst.
Proof. unfold Equation3457. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff132_inst, reff132_op in H. discriminate H. Qed.

Lemma reff132_not3458 : ~ @Equation3458 Fin3 reff132_inst.
Proof. unfold Equation3458. intro H. specialize (H F3_2 F3_0). unfold magma_op, reff132_inst, reff132_op in H. discriminate H. Qed.

Lemma reff132_not3459 : ~ @Equation3459 Fin3 reff132_inst.
Proof. unfold Equation3459. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff132_inst, reff132_op in H. discriminate H. Qed.

Lemma reff132_not3461 : ~ @Equation3461 Fin3 reff132_inst.
Proof. unfold Equation3461. intro H. specialize (H F3_2 F3_0). unfold magma_op, reff132_inst, reff132_op in H. discriminate H. Qed.

Lemma reff132_not3462 : ~ @Equation3462 Fin3 reff132_inst.
Proof. unfold Equation3462. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff132_inst, reff132_op in H. discriminate H. Qed.

Lemma reff132_not3464 : ~ @Equation3464 Fin3 reff132_inst.
Proof. unfold Equation3464. intro H. specialize (H F3_2 F3_0). unfold magma_op, reff132_inst, reff132_op in H. discriminate H. Qed.

Lemma reff132_not3465 : ~ @Equation3465 Fin3 reff132_inst.
Proof. unfold Equation3465. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff132_inst, reff132_op in H. discriminate H. Qed.

Lemma reff132_not3472 : ~ @Equation3472 Fin3 reff132_inst.
Proof. unfold Equation3472. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff132_inst, reff132_op in H. discriminate H. Qed.

Lemma reff132_not3474 : ~ @Equation3474 Fin3 reff132_inst.
Proof. unfold Equation3474. intro H. specialize (H F3_1 F3_0). unfold magma_op, reff132_inst, reff132_op in H. discriminate H. Qed.

Lemma reff132_not3475 : ~ @Equation3475 Fin3 reff132_inst.
Proof. unfold Equation3475. intro H. specialize (H F3_1 F3_2). unfold magma_op, reff132_inst, reff132_op in H. discriminate H. Qed.

Lemma reff132_not3481 : ~ @Equation3481 Fin3 reff132_inst.
Proof. unfold Equation3481. intro H. specialize (H F3_1 F3_0). unfold magma_op, reff132_inst, reff132_op in H. discriminate H. Qed.

Lemma reff132_not3482 : ~ @Equation3482 Fin3 reff132_inst.
Proof. unfold Equation3482. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff132_inst, reff132_op in H. discriminate H. Qed.

Lemma reff132_not3484 : ~ @Equation3484 Fin3 reff132_inst.
Proof. unfold Equation3484. intro H. specialize (H F3_1 F3_0). unfold magma_op, reff132_inst, reff132_op in H. discriminate H. Qed.

Lemma reff132_not3509 : ~ @Equation3509 Fin3 reff132_inst.
Proof. unfold Equation3509. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff132_inst, reff132_op in H. discriminate H. Qed.

Lemma reff132_not3511 : ~ @Equation3511 Fin3 reff132_inst.
Proof. unfold Equation3511. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff132_inst, reff132_op in H. discriminate H. Qed.

Lemma reff132_not3512 : ~ @Equation3512 Fin3 reff132_inst.
Proof. unfold Equation3512. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff132_inst, reff132_op in H. discriminate H. Qed.

Lemma reff132_not3518 : ~ @Equation3518 Fin3 reff132_inst.
Proof. unfold Equation3518. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff132_inst, reff132_op in H. discriminate H. Qed.

Lemma reff132_not3519 : ~ @Equation3519 Fin3 reff132_inst.
Proof. unfold Equation3519. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff132_inst, reff132_op in H. discriminate H. Qed.

Lemma reff132_not3521 : ~ @Equation3521 Fin3 reff132_inst.
Proof. unfold Equation3521. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff132_inst, reff132_op in H. discriminate H. Qed.

Lemma reff132_not3522 : ~ @Equation3522 Fin3 reff132_inst.
Proof. unfold Equation3522. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff132_inst, reff132_op in H. discriminate H. Qed.

Lemma reff132_not3545 : ~ @Equation3545 Fin3 reff132_inst.
Proof. unfold Equation3545. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff132_inst, reff132_op in H. discriminate H. Qed.

Lemma reff132_not3546 : ~ @Equation3546 Fin3 reff132_inst.
Proof. unfold Equation3546. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff132_inst, reff132_op in H. discriminate H. Qed.

Lemma reff132_not3548 : ~ @Equation3548 Fin3 reff132_inst.
Proof. unfold Equation3548. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff132_inst, reff132_op in H. discriminate H. Qed.

Lemma reff132_not3549 : ~ @Equation3549 Fin3 reff132_inst.
Proof. unfold Equation3549. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff132_inst, reff132_op in H. discriminate H. Qed.

Lemma reff132_not3555 : ~ @Equation3555 Fin3 reff132_inst.
Proof. unfold Equation3555. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff132_inst, reff132_op in H. discriminate H. Qed.

Lemma reff132_not3558 : ~ @Equation3558 Fin3 reff132_inst.
Proof. unfold Equation3558. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff132_inst, reff132_op in H. discriminate H. Qed.

Lemma reff132_not3660 : ~ @Equation3660 Fin3 reff132_inst.
Proof. unfold Equation3660. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff132_inst, reff132_op in H. discriminate H. Qed.

Lemma reff132_not3661 : ~ @Equation3661 Fin3 reff132_inst.
Proof. unfold Equation3661. intro H. specialize (H F3_1 F3_0). unfold magma_op, reff132_inst, reff132_op in H. discriminate H. Qed.

Lemma reff132_not3662 : ~ @Equation3662 Fin3 reff132_inst.
Proof. unfold Equation3662. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff132_inst, reff132_op in H. discriminate H. Qed.

Lemma reff132_not3664 : ~ @Equation3664 Fin3 reff132_inst.
Proof. unfold Equation3664. intro H. specialize (H F3_2 F3_0). unfold magma_op, reff132_inst, reff132_op in H. discriminate H. Qed.

Lemma reff132_not3665 : ~ @Equation3665 Fin3 reff132_inst.
Proof. unfold Equation3665. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff132_inst, reff132_op in H. discriminate H. Qed.

Lemma reff132_not3667 : ~ @Equation3667 Fin3 reff132_inst.
Proof. unfold Equation3667. intro H. specialize (H F3_1 F3_0). unfold magma_op, reff132_inst, reff132_op in H. discriminate H. Qed.

Lemma reff132_not3668 : ~ @Equation3668 Fin3 reff132_inst.
Proof. unfold Equation3668. intro H. specialize (H F3_1 F3_2). unfold magma_op, reff132_inst, reff132_op in H. discriminate H. Qed.

Lemma reff132_not3674 : ~ @Equation3674 Fin3 reff132_inst.
Proof. unfold Equation3674. intro H. specialize (H F3_2 F3_0). unfold magma_op, reff132_inst, reff132_op in H. discriminate H. Qed.

Lemma reff132_not3675 : ~ @Equation3675 Fin3 reff132_inst.
Proof. unfold Equation3675. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff132_inst, reff132_op in H. discriminate H. Qed.

Lemma reff132_not3677 : ~ @Equation3677 Fin3 reff132_inst.
Proof. unfold Equation3677. intro H. specialize (H F3_1 F3_0). unfold magma_op, reff132_inst, reff132_op in H. discriminate H. Qed.

Lemma reff132_not3678 : ~ @Equation3678 Fin3 reff132_inst.
Proof. unfold Equation3678. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff132_inst, reff132_op in H. discriminate H. Qed.

Lemma reff132_not3684 : ~ @Equation3684 Fin3 reff132_inst.
Proof. unfold Equation3684. intro H. specialize (H F3_2 F3_0). unfold magma_op, reff132_inst, reff132_op in H. discriminate H. Qed.

Lemma reff132_not3685 : ~ @Equation3685 Fin3 reff132_inst.
Proof. unfold Equation3685. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff132_inst, reff132_op in H. discriminate H. Qed.

Lemma reff132_not3687 : ~ @Equation3687 Fin3 reff132_inst.
Proof. unfold Equation3687. intro H. specialize (H F3_1 F3_0). unfold magma_op, reff132_inst, reff132_op in H. discriminate H. Qed.

Lemma reff132_not3712 : ~ @Equation3712 Fin3 reff132_inst.
Proof. unfold Equation3712. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff132_inst, reff132_op in H. discriminate H. Qed.

Lemma reff132_not3714 : ~ @Equation3714 Fin3 reff132_inst.
Proof. unfold Equation3714. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff132_inst, reff132_op in H. discriminate H. Qed.

Lemma reff132_not3721 : ~ @Equation3721 Fin3 reff132_inst.
Proof. unfold Equation3721. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff132_inst, reff132_op in H. discriminate H. Qed.

Lemma reff132_not3722 : ~ @Equation3722 Fin3 reff132_inst.
Proof. unfold Equation3722. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff132_inst, reff132_op in H. discriminate H. Qed.

Lemma reff132_not3724 : ~ @Equation3724 Fin3 reff132_inst.
Proof. unfold Equation3724. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff132_inst, reff132_op in H. discriminate H. Qed.

Lemma reff132_not3725 : ~ @Equation3725 Fin3 reff132_inst.
Proof. unfold Equation3725. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff132_inst, reff132_op in H. discriminate H. Qed.

Lemma reff132_not3748 : ~ @Equation3748 Fin3 reff132_inst.
Proof. unfold Equation3748. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff132_inst, reff132_op in H. discriminate H. Qed.

Lemma reff132_not3749 : ~ @Equation3749 Fin3 reff132_inst.
Proof. unfold Equation3749. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff132_inst, reff132_op in H. discriminate H. Qed.

Lemma reff132_not3751 : ~ @Equation3751 Fin3 reff132_inst.
Proof. unfold Equation3751. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff132_inst, reff132_op in H. discriminate H. Qed.

Lemma reff132_not3752 : ~ @Equation3752 Fin3 reff132_inst.
Proof. unfold Equation3752. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff132_inst, reff132_op in H. discriminate H. Qed.

Lemma reff132_not3759 : ~ @Equation3759 Fin3 reff132_inst.
Proof. unfold Equation3759. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff132_inst, reff132_op in H. discriminate H. Qed.

Lemma reff132_not3761 : ~ @Equation3761 Fin3 reff132_inst.
Proof. unfold Equation3761. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff132_inst, reff132_op in H. discriminate H. Qed.

Lemma reff132_not3862 : ~ @Equation3862 Fin3 reff132_inst.
Proof. unfold Equation3862. intro H. specialize (H F3_1). unfold magma_op, reff132_inst, reff132_op in H. discriminate H. Qed.

Lemma reff132_not4065 : ~ @Equation4065 Fin3 reff132_inst.
Proof. unfold Equation4065. intro H. specialize (H F3_1). unfold magma_op, reff132_inst, reff132_op in H. discriminate H. Qed.

Lemma reff132_not4268 : ~ @Equation4268 Fin3 reff132_inst.
Proof. unfold Equation4268. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff132_inst, reff132_op in H. discriminate H. Qed.

Lemma reff132_not4269 : ~ @Equation4269 Fin3 reff132_inst.
Proof. unfold Equation4269. intro H. specialize (H F3_2 F3_0). unfold magma_op, reff132_inst, reff132_op in H. discriminate H. Qed.

Lemma reff132_not4270 : ~ @Equation4270 Fin3 reff132_inst.
Proof. unfold Equation4270. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff132_inst, reff132_op in H. discriminate H. Qed.

Lemma reff132_not4272 : ~ @Equation4272 Fin3 reff132_inst.
Proof. unfold Equation4272. intro H. specialize (H F3_2 F3_0). unfold magma_op, reff132_inst, reff132_op in H. discriminate H. Qed.

Lemma reff132_not4273 : ~ @Equation4273 Fin3 reff132_inst.
Proof. unfold Equation4273. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff132_inst, reff132_op in H. discriminate H. Qed.

Lemma reff132_not4275 : ~ @Equation4275 Fin3 reff132_inst.
Proof. unfold Equation4275. intro H. specialize (H F3_1 F3_0). unfold magma_op, reff132_inst, reff132_op in H. discriminate H. Qed.

Lemma reff132_not4276 : ~ @Equation4276 Fin3 reff132_inst.
Proof. unfold Equation4276. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff132_inst, reff132_op in H. discriminate H. Qed.

Lemma reff132_not4283 : ~ @Equation4283 Fin3 reff132_inst.
Proof. unfold Equation4283. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff132_inst, reff132_op in H. discriminate H. Qed.

Lemma reff132_not4284 : ~ @Equation4284 Fin3 reff132_inst.
Proof. unfold Equation4284. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff132_inst, reff132_op in H. discriminate H. Qed.

Lemma reff132_not4290 : ~ @Equation4290 Fin3 reff132_inst.
Proof. unfold Equation4290. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff132_inst, reff132_op in H. discriminate H. Qed.

Lemma reff132_not4291 : ~ @Equation4291 Fin3 reff132_inst.
Proof. unfold Equation4291. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff132_inst, reff132_op in H. discriminate H. Qed.

Lemma reff132_not4293 : ~ @Equation4293 Fin3 reff132_inst.
Proof. unfold Equation4293. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff132_inst, reff132_op in H. discriminate H. Qed.

Lemma reff132_not4314 : ~ @Equation4314 Fin3 reff132_inst.
Proof. unfold Equation4314. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff132_inst, reff132_op in H. discriminate H. Qed.

Lemma reff132_not4321 : ~ @Equation4321 Fin3 reff132_inst.
Proof. unfold Equation4321. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff132_inst, reff132_op in H. discriminate H. Qed.

Lemma reff132_not4343 : ~ @Equation4343 Fin3 reff132_inst.
Proof. unfold Equation4343. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff132_inst, reff132_op in H. discriminate H. Qed.

Lemma reff132_not4380 : ~ @Equation4380 Fin3 reff132_inst.
Proof. unfold Equation4380. intro H. specialize (H F3_1). unfold magma_op, reff132_inst, reff132_op in H. discriminate H. Qed.

Lemma reff132_not4583 : ~ @Equation4583 Fin3 reff132_inst.
Proof. unfold Equation4583. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff132_inst, reff132_op in H. discriminate H. Qed.

Lemma reff132_not4584 : ~ @Equation4584 Fin3 reff132_inst.
Proof. unfold Equation4584. intro H. specialize (H F3_2 F3_0). unfold magma_op, reff132_inst, reff132_op in H. discriminate H. Qed.

Lemma reff132_not4585 : ~ @Equation4585 Fin3 reff132_inst.
Proof. unfold Equation4585. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff132_inst, reff132_op in H. discriminate H. Qed.

Lemma reff132_not4587 : ~ @Equation4587 Fin3 reff132_inst.
Proof. unfold Equation4587. intro H. specialize (H F3_1 F3_0). unfold magma_op, reff132_inst, reff132_op in H. discriminate H. Qed.

Lemma reff132_not4588 : ~ @Equation4588 Fin3 reff132_inst.
Proof. unfold Equation4588. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff132_inst, reff132_op in H. discriminate H. Qed.

Lemma reff132_not4590 : ~ @Equation4590 Fin3 reff132_inst.
Proof. unfold Equation4590. intro H. specialize (H F3_1 F3_2). unfold magma_op, reff132_inst, reff132_op in H. discriminate H. Qed.

Lemma reff132_not4591 : ~ @Equation4591 Fin3 reff132_inst.
Proof. unfold Equation4591. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff132_inst, reff132_op in H. discriminate H. Qed.

Lemma reff132_not4598 : ~ @Equation4598 Fin3 reff132_inst.
Proof. unfold Equation4598. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff132_inst, reff132_op in H. discriminate H. Qed.

Lemma reff132_not4599 : ~ @Equation4599 Fin3 reff132_inst.
Proof. unfold Equation4599. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff132_inst, reff132_op in H. discriminate H. Qed.

Lemma reff132_not4605 : ~ @Equation4605 Fin3 reff132_inst.
Proof. unfold Equation4605. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff132_inst, reff132_op in H. discriminate H. Qed.

Lemma reff132_not4606 : ~ @Equation4606 Fin3 reff132_inst.
Proof. unfold Equation4606. intro H. specialize (H F3_1 F3_2). unfold magma_op, reff132_inst, reff132_op in H. discriminate H. Qed.

Lemma reff132_not4608 : ~ @Equation4608 Fin3 reff132_inst.
Proof. unfold Equation4608. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff132_inst, reff132_op in H. discriminate H. Qed.

Lemma reff132_not4629 : ~ @Equation4629 Fin3 reff132_inst.
Proof. unfold Equation4629. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff132_inst, reff132_op in H. discriminate H. Qed.

Lemma reff132_not4635 : ~ @Equation4635 Fin3 reff132_inst.
Proof. unfold Equation4635. intro H. specialize (H F3_1 F3_0). unfold magma_op, reff132_inst, reff132_op in H. discriminate H. Qed.

Lemma reff132_not4636 : ~ @Equation4636 Fin3 reff132_inst.
Proof. unfold Equation4636. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff132_inst, reff132_op in H. discriminate H. Qed.

Lemma reff132_not4658 : ~ @Equation4658 Fin3 reff132_inst.
Proof. unfold Equation4658. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff132_inst, reff132_op in H. discriminate H. Qed.

(** ---- reff138 (Fin3) ---- *)

Definition reff138_op (x y : Fin3) : Fin3 :=
  match x, y with
  | F3_0, F3_0 => F3_0 | F3_0, F3_1 => F3_2 | F3_0, F3_2 => F3_2
  | F3_1, F3_0 => F3_0 | F3_1, F3_1 => F3_0 | F3_1, F3_2 => F3_1
  | F3_2, F3_0 => F3_1 | F3_2, F3_1 => F3_2 | F3_2, F3_2 => F3_1
  end.

#[local] Instance reff138_inst : Magma Fin3 := {| magma_op := reff138_op |}.

Lemma reff138_sat104 : @Equation104 Fin3 reff138_inst.
Proof. unfold Equation104, magma_op, reff138_inst, reff138_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff138_sat1038 : @Equation1038 Fin3 reff138_inst.
Proof. unfold Equation1038, magma_op, reff138_inst, reff138_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff138_sat3316 : @Equation3316 Fin3 reff138_inst.
Proof. unfold Equation3316, magma_op, reff138_inst, reff138_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff138_sat4587 : @Equation4587 Fin3 reff138_inst.
Proof. unfold Equation4587, magma_op, reff138_inst, reff138_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff138_not47 : ~ @Equation47 Fin3 reff138_inst.
Proof. unfold Equation47. intro H. specialize (H F3_1). unfold magma_op, reff138_inst, reff138_op in H. discriminate H. Qed.

Lemma reff138_not102 : ~ @Equation102 Fin3 reff138_inst.
Proof. unfold Equation102. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff138_inst, reff138_op in H. discriminate H. Qed.

Lemma reff138_not105 : ~ @Equation105 Fin3 reff138_inst.
Proof. unfold Equation105. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff138_inst, reff138_op in H. discriminate H. Qed.

Lemma reff138_not107 : ~ @Equation107 Fin3 reff138_inst.
Proof. unfold Equation107. intro H. specialize (H F3_1 F3_2). unfold magma_op, reff138_inst, reff138_op in H. discriminate H. Qed.

Lemma reff138_not108 : ~ @Equation108 Fin3 reff138_inst.
Proof. unfold Equation108. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff138_inst, reff138_op in H. discriminate H. Qed.

Lemma reff138_not115 : ~ @Equation115 Fin3 reff138_inst.
Proof. unfold Equation115. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff138_inst, reff138_op in H. discriminate H. Qed.

Lemma reff138_not117 : ~ @Equation117 Fin3 reff138_inst.
Proof. unfold Equation117. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff138_inst, reff138_op in H. discriminate H. Qed.

Lemma reff138_not118 : ~ @Equation118 Fin3 reff138_inst.
Proof. unfold Equation118. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff138_inst, reff138_op in H. discriminate H. Qed.

Lemma reff138_not124 : ~ @Equation124 Fin3 reff138_inst.
Proof. unfold Equation124. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff138_inst, reff138_op in H. discriminate H. Qed.

Lemma reff138_not125 : ~ @Equation125 Fin3 reff138_inst.
Proof. unfold Equation125. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff138_inst, reff138_op in H. discriminate H. Qed.

Lemma reff138_not127 : ~ @Equation127 Fin3 reff138_inst.
Proof. unfold Equation127. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff138_inst, reff138_op in H. discriminate H. Qed.

Lemma reff138_not151 : ~ @Equation151 Fin3 reff138_inst.
Proof. unfold Equation151. intro H. specialize (H F3_1). unfold magma_op, reff138_inst, reff138_op in H. discriminate H. Qed.

Lemma reff138_not203 : ~ @Equation203 Fin3 reff138_inst.
Proof. unfold Equation203. intro H. specialize (H F3_1). unfold magma_op, reff138_inst, reff138_op in H. discriminate H. Qed.

Lemma reff138_not255 : ~ @Equation255 Fin3 reff138_inst.
Proof. unfold Equation255. intro H. specialize (H F3_1). unfold magma_op, reff138_inst, reff138_op in H. discriminate H. Qed.

Lemma reff138_not307 : ~ @Equation307 Fin3 reff138_inst.
Proof. unfold Equation307. intro H. specialize (H F3_2). unfold magma_op, reff138_inst, reff138_op in H. discriminate H. Qed.

Lemma reff138_not411 : ~ @Equation411 Fin3 reff138_inst.
Proof. unfold Equation411. intro H. specialize (H F3_1). unfold magma_op, reff138_inst, reff138_op in H. discriminate H. Qed.

Lemma reff138_not614 : ~ @Equation614 Fin3 reff138_inst.
Proof. unfold Equation614. intro H. specialize (H F3_1). unfold magma_op, reff138_inst, reff138_op in H. discriminate H. Qed.

Lemma reff138_not817 : ~ @Equation817 Fin3 reff138_inst.
Proof. unfold Equation817. intro H. specialize (H F3_1). unfold magma_op, reff138_inst, reff138_op in H. discriminate H. Qed.

Lemma reff138_not1021 : ~ @Equation1021 Fin3 reff138_inst.
Proof. unfold Equation1021. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff138_inst, reff138_op in H. discriminate H. Qed.

Lemma reff138_not1022 : ~ @Equation1022 Fin3 reff138_inst.
Proof. unfold Equation1022. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff138_inst, reff138_op in H. discriminate H. Qed.

Lemma reff138_not1023 : ~ @Equation1023 Fin3 reff138_inst.
Proof. unfold Equation1023. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff138_inst, reff138_op in H. discriminate H. Qed.

Lemma reff138_not1025 : ~ @Equation1025 Fin3 reff138_inst.
Proof. unfold Equation1025. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff138_inst, reff138_op in H. discriminate H. Qed.

Lemma reff138_not1026 : ~ @Equation1026 Fin3 reff138_inst.
Proof. unfold Equation1026. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff138_inst, reff138_op in H. discriminate H. Qed.

Lemma reff138_not1028 : ~ @Equation1028 Fin3 reff138_inst.
Proof. unfold Equation1028. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff138_inst, reff138_op in H. discriminate H. Qed.

Lemma reff138_not1029 : ~ @Equation1029 Fin3 reff138_inst.
Proof. unfold Equation1029. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff138_inst, reff138_op in H. discriminate H. Qed.

Lemma reff138_not1035 : ~ @Equation1035 Fin3 reff138_inst.
Proof. unfold Equation1035. intro H. specialize (H F3_1 F3_2). unfold magma_op, reff138_inst, reff138_op in H. discriminate H. Qed.

Lemma reff138_not1036 : ~ @Equation1036 Fin3 reff138_inst.
Proof. unfold Equation1036. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff138_inst, reff138_op in H. discriminate H. Qed.

Lemma reff138_not1039 : ~ @Equation1039 Fin3 reff138_inst.
Proof. unfold Equation1039. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff138_inst, reff138_op in H. discriminate H. Qed.

Lemma reff138_not1045 : ~ @Equation1045 Fin3 reff138_inst.
Proof. unfold Equation1045. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff138_inst, reff138_op in H. discriminate H. Qed.

Lemma reff138_not1046 : ~ @Equation1046 Fin3 reff138_inst.
Proof. unfold Equation1046. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff138_inst, reff138_op in H. discriminate H. Qed.

Lemma reff138_not1048 : ~ @Equation1048 Fin3 reff138_inst.
Proof. unfold Equation1048. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff138_inst, reff138_op in H. discriminate H. Qed.

Lemma reff138_not1049 : ~ @Equation1049 Fin3 reff138_inst.
Proof. unfold Equation1049. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff138_inst, reff138_op in H. discriminate H. Qed.

Lemma reff138_not1072 : ~ @Equation1072 Fin3 reff138_inst.
Proof. unfold Equation1072. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff138_inst, reff138_op in H. discriminate H. Qed.

Lemma reff138_not1073 : ~ @Equation1073 Fin3 reff138_inst.
Proof. unfold Equation1073. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff138_inst, reff138_op in H. discriminate H. Qed.

Lemma reff138_not1075 : ~ @Equation1075 Fin3 reff138_inst.
Proof. unfold Equation1075. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff138_inst, reff138_op in H. discriminate H. Qed.

Lemma reff138_not1076 : ~ @Equation1076 Fin3 reff138_inst.
Proof. unfold Equation1076. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff138_inst, reff138_op in H. discriminate H. Qed.

Lemma reff138_not1082 : ~ @Equation1082 Fin3 reff138_inst.
Proof. unfold Equation1082. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff138_inst, reff138_op in H. discriminate H. Qed.

Lemma reff138_not1083 : ~ @Equation1083 Fin3 reff138_inst.
Proof. unfold Equation1083. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff138_inst, reff138_op in H. discriminate H. Qed.

Lemma reff138_not1085 : ~ @Equation1085 Fin3 reff138_inst.
Proof. unfold Equation1085. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff138_inst, reff138_op in H. discriminate H. Qed.

Lemma reff138_not1086 : ~ @Equation1086 Fin3 reff138_inst.
Proof. unfold Equation1086. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff138_inst, reff138_op in H. discriminate H. Qed.

Lemma reff138_not1109 : ~ @Equation1109 Fin3 reff138_inst.
Proof. unfold Equation1109. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff138_inst, reff138_op in H. discriminate H. Qed.

Lemma reff138_not1110 : ~ @Equation1110 Fin3 reff138_inst.
Proof. unfold Equation1110. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff138_inst, reff138_op in H. discriminate H. Qed.

Lemma reff138_not1112 : ~ @Equation1112 Fin3 reff138_inst.
Proof. unfold Equation1112. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff138_inst, reff138_op in H. discriminate H. Qed.

Lemma reff138_not1113 : ~ @Equation1113 Fin3 reff138_inst.
Proof. unfold Equation1113. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff138_inst, reff138_op in H. discriminate H. Qed.

Lemma reff138_not1119 : ~ @Equation1119 Fin3 reff138_inst.
Proof. unfold Equation1119. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff138_inst, reff138_op in H. discriminate H. Qed.

Lemma reff138_not1120 : ~ @Equation1120 Fin3 reff138_inst.
Proof. unfold Equation1120. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff138_inst, reff138_op in H. discriminate H. Qed.

Lemma reff138_not1122 : ~ @Equation1122 Fin3 reff138_inst.
Proof. unfold Equation1122. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff138_inst, reff138_op in H. discriminate H. Qed.

Lemma reff138_not1224 : ~ @Equation1224 Fin3 reff138_inst.
Proof. unfold Equation1224. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff138_inst, reff138_op in H. discriminate H. Qed.

Lemma reff138_not1225 : ~ @Equation1225 Fin3 reff138_inst.
Proof. unfold Equation1225. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff138_inst, reff138_op in H. discriminate H. Qed.

Lemma reff138_not1226 : ~ @Equation1226 Fin3 reff138_inst.
Proof. unfold Equation1226. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff138_inst, reff138_op in H. discriminate H. Qed.

Lemma reff138_not1229 : ~ @Equation1229 Fin3 reff138_inst.
Proof. unfold Equation1229. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff138_inst, reff138_op in H. discriminate H. Qed.

Lemma reff138_not1231 : ~ @Equation1231 Fin3 reff138_inst.
Proof. unfold Equation1231. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff138_inst, reff138_op in H. discriminate H. Qed.

Lemma reff138_not1232 : ~ @Equation1232 Fin3 reff138_inst.
Proof. unfold Equation1232. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff138_inst, reff138_op in H. discriminate H. Qed.

Lemma reff138_not1239 : ~ @Equation1239 Fin3 reff138_inst.
Proof. unfold Equation1239. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff138_inst, reff138_op in H. discriminate H. Qed.

Lemma reff138_not1241 : ~ @Equation1241 Fin3 reff138_inst.
Proof. unfold Equation1241. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff138_inst, reff138_op in H. discriminate H. Qed.

Lemma reff138_not1242 : ~ @Equation1242 Fin3 reff138_inst.
Proof. unfold Equation1242. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff138_inst, reff138_op in H. discriminate H. Qed.

Lemma reff138_not1249 : ~ @Equation1249 Fin3 reff138_inst.
Proof. unfold Equation1249. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff138_inst, reff138_op in H. discriminate H. Qed.

Lemma reff138_not1251 : ~ @Equation1251 Fin3 reff138_inst.
Proof. unfold Equation1251. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff138_inst, reff138_op in H. discriminate H. Qed.

Lemma reff138_not1252 : ~ @Equation1252 Fin3 reff138_inst.
Proof. unfold Equation1252. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff138_inst, reff138_op in H. discriminate H. Qed.

Lemma reff138_not1275 : ~ @Equation1275 Fin3 reff138_inst.
Proof. unfold Equation1275. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff138_inst, reff138_op in H. discriminate H. Qed.

Lemma reff138_not1276 : ~ @Equation1276 Fin3 reff138_inst.
Proof. unfold Equation1276. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff138_inst, reff138_op in H. discriminate H. Qed.

Lemma reff138_not1278 : ~ @Equation1278 Fin3 reff138_inst.
Proof. unfold Equation1278. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff138_inst, reff138_op in H. discriminate H. Qed.

Lemma reff138_not1279 : ~ @Equation1279 Fin3 reff138_inst.
Proof. unfold Equation1279. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff138_inst, reff138_op in H. discriminate H. Qed.

Lemma reff138_not1285 : ~ @Equation1285 Fin3 reff138_inst.
Proof. unfold Equation1285. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff138_inst, reff138_op in H. discriminate H. Qed.

Lemma reff138_not1286 : ~ @Equation1286 Fin3 reff138_inst.
Proof. unfold Equation1286. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff138_inst, reff138_op in H. discriminate H. Qed.

Lemma reff138_not1288 : ~ @Equation1288 Fin3 reff138_inst.
Proof. unfold Equation1288. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff138_inst, reff138_op in H. discriminate H. Qed.

Lemma reff138_not1289 : ~ @Equation1289 Fin3 reff138_inst.
Proof. unfold Equation1289. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff138_inst, reff138_op in H. discriminate H. Qed.

Lemma reff138_not1312 : ~ @Equation1312 Fin3 reff138_inst.
Proof. unfold Equation1312. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff138_inst, reff138_op in H. discriminate H. Qed.

Lemma reff138_not1313 : ~ @Equation1313 Fin3 reff138_inst.
Proof. unfold Equation1313. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff138_inst, reff138_op in H. discriminate H. Qed.

Lemma reff138_not1315 : ~ @Equation1315 Fin3 reff138_inst.
Proof. unfold Equation1315. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff138_inst, reff138_op in H. discriminate H. Qed.

Lemma reff138_not1316 : ~ @Equation1316 Fin3 reff138_inst.
Proof. unfold Equation1316. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff138_inst, reff138_op in H. discriminate H. Qed.

Lemma reff138_not1322 : ~ @Equation1322 Fin3 reff138_inst.
Proof. unfold Equation1322. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff138_inst, reff138_op in H. discriminate H. Qed.

Lemma reff138_not1323 : ~ @Equation1323 Fin3 reff138_inst.
Proof. unfold Equation1323. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff138_inst, reff138_op in H. discriminate H. Qed.

Lemma reff138_not1325 : ~ @Equation1325 Fin3 reff138_inst.
Proof. unfold Equation1325. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff138_inst, reff138_op in H. discriminate H. Qed.

Lemma reff138_not1426 : ~ @Equation1426 Fin3 reff138_inst.
Proof. unfold Equation1426. intro H. specialize (H F3_1). unfold magma_op, reff138_inst, reff138_op in H. discriminate H. Qed.

Lemma reff138_not1629 : ~ @Equation1629 Fin3 reff138_inst.
Proof. unfold Equation1629. intro H. specialize (H F3_1). unfold magma_op, reff138_inst, reff138_op in H. discriminate H. Qed.

Lemma reff138_not1832 : ~ @Equation1832 Fin3 reff138_inst.
Proof. unfold Equation1832. intro H. specialize (H F3_1). unfold magma_op, reff138_inst, reff138_op in H. discriminate H. Qed.

Lemma reff138_not2035 : ~ @Equation2035 Fin3 reff138_inst.
Proof. unfold Equation2035. intro H. specialize (H F3_2). unfold magma_op, reff138_inst, reff138_op in H. discriminate H. Qed.

Lemma reff138_not2238 : ~ @Equation2238 Fin3 reff138_inst.
Proof. unfold Equation2238. intro H. specialize (H F3_1). unfold magma_op, reff138_inst, reff138_op in H. discriminate H. Qed.

Lemma reff138_not2441 : ~ @Equation2441 Fin3 reff138_inst.
Proof. unfold Equation2441. intro H. specialize (H F3_1). unfold magma_op, reff138_inst, reff138_op in H. discriminate H. Qed.

Lemma reff138_not2644 : ~ @Equation2644 Fin3 reff138_inst.
Proof. unfold Equation2644. intro H. specialize (H F3_1). unfold magma_op, reff138_inst, reff138_op in H. discriminate H. Qed.

Lemma reff138_not2847 : ~ @Equation2847 Fin3 reff138_inst.
Proof. unfold Equation2847. intro H. specialize (H F3_1). unfold magma_op, reff138_inst, reff138_op in H. discriminate H. Qed.

Lemma reff138_not3050 : ~ @Equation3050 Fin3 reff138_inst.
Proof. unfold Equation3050. intro H. specialize (H F3_1). unfold magma_op, reff138_inst, reff138_op in H. discriminate H. Qed.

Lemma reff138_not3254 : ~ @Equation3254 Fin3 reff138_inst.
Proof. unfold Equation3254. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff138_inst, reff138_op in H. discriminate H. Qed.

Lemma reff138_not3255 : ~ @Equation3255 Fin3 reff138_inst.
Proof. unfold Equation3255. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff138_inst, reff138_op in H. discriminate H. Qed.

Lemma reff138_not3256 : ~ @Equation3256 Fin3 reff138_inst.
Proof. unfold Equation3256. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff138_inst, reff138_op in H. discriminate H. Qed.

Lemma reff138_not3258 : ~ @Equation3258 Fin3 reff138_inst.
Proof. unfold Equation3258. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff138_inst, reff138_op in H. discriminate H. Qed.

Lemma reff138_not3259 : ~ @Equation3259 Fin3 reff138_inst.
Proof. unfold Equation3259. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff138_inst, reff138_op in H. discriminate H. Qed.

Lemma reff138_not3261 : ~ @Equation3261 Fin3 reff138_inst.
Proof. unfold Equation3261. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff138_inst, reff138_op in H. discriminate H. Qed.

Lemma reff138_not3262 : ~ @Equation3262 Fin3 reff138_inst.
Proof. unfold Equation3262. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff138_inst, reff138_op in H. discriminate H. Qed.

Lemma reff138_not3268 : ~ @Equation3268 Fin3 reff138_inst.
Proof. unfold Equation3268. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff138_inst, reff138_op in H. discriminate H. Qed.

Lemma reff138_not3271 : ~ @Equation3271 Fin3 reff138_inst.
Proof. unfold Equation3271. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff138_inst, reff138_op in H. discriminate H. Qed.

Lemma reff138_not3272 : ~ @Equation3272 Fin3 reff138_inst.
Proof. unfold Equation3272. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff138_inst, reff138_op in H. discriminate H. Qed.

Lemma reff138_not3278 : ~ @Equation3278 Fin3 reff138_inst.
Proof. unfold Equation3278. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff138_inst, reff138_op in H. discriminate H. Qed.

Lemma reff138_not3279 : ~ @Equation3279 Fin3 reff138_inst.
Proof. unfold Equation3279. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff138_inst, reff138_op in H. discriminate H. Qed.

Lemma reff138_not3281 : ~ @Equation3281 Fin3 reff138_inst.
Proof. unfold Equation3281. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff138_inst, reff138_op in H. discriminate H. Qed.

Lemma reff138_not3306 : ~ @Equation3306 Fin3 reff138_inst.
Proof. unfold Equation3306. intro H. specialize (H F3_1 F3_2). unfold magma_op, reff138_inst, reff138_op in H. discriminate H. Qed.

Lemma reff138_not3308 : ~ @Equation3308 Fin3 reff138_inst.
Proof. unfold Equation3308. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff138_inst, reff138_op in H. discriminate H. Qed.

Lemma reff138_not3309 : ~ @Equation3309 Fin3 reff138_inst.
Proof. unfold Equation3309. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff138_inst, reff138_op in H. discriminate H. Qed.

Lemma reff138_not3315 : ~ @Equation3315 Fin3 reff138_inst.
Proof. unfold Equation3315. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff138_inst, reff138_op in H. discriminate H. Qed.

Lemma reff138_not3318 : ~ @Equation3318 Fin3 reff138_inst.
Proof. unfold Equation3318. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff138_inst, reff138_op in H. discriminate H. Qed.

Lemma reff138_not3319 : ~ @Equation3319 Fin3 reff138_inst.
Proof. unfold Equation3319. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff138_inst, reff138_op in H. discriminate H. Qed.

Lemma reff138_not3342 : ~ @Equation3342 Fin3 reff138_inst.
Proof. unfold Equation3342. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff138_inst, reff138_op in H. discriminate H. Qed.

Lemma reff138_not3343 : ~ @Equation3343 Fin3 reff138_inst.
Proof. unfold Equation3343. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff138_inst, reff138_op in H. discriminate H. Qed.

Lemma reff138_not3345 : ~ @Equation3345 Fin3 reff138_inst.
Proof. unfold Equation3345. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff138_inst, reff138_op in H. discriminate H. Qed.

Lemma reff138_not3346 : ~ @Equation3346 Fin3 reff138_inst.
Proof. unfold Equation3346. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff138_inst, reff138_op in H. discriminate H. Qed.

Lemma reff138_not3352 : ~ @Equation3352 Fin3 reff138_inst.
Proof. unfold Equation3352. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff138_inst, reff138_op in H. discriminate H. Qed.

Lemma reff138_not3353 : ~ @Equation3353 Fin3 reff138_inst.
Proof. unfold Equation3353. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff138_inst, reff138_op in H. discriminate H. Qed.

Lemma reff138_not3456 : ~ @Equation3456 Fin3 reff138_inst.
Proof. unfold Equation3456. intro H. specialize (H F3_1). unfold magma_op, reff138_inst, reff138_op in H. discriminate H. Qed.

Lemma reff138_not3659 : ~ @Equation3659 Fin3 reff138_inst.
Proof. unfold Equation3659. intro H. specialize (H F3_2). unfold magma_op, reff138_inst, reff138_op in H. discriminate H. Qed.

Lemma reff138_not3862 : ~ @Equation3862 Fin3 reff138_inst.
Proof. unfold Equation3862. intro H. specialize (H F3_1). unfold magma_op, reff138_inst, reff138_op in H. discriminate H. Qed.

Lemma reff138_not4065 : ~ @Equation4065 Fin3 reff138_inst.
Proof. unfold Equation4065. intro H. specialize (H F3_1). unfold magma_op, reff138_inst, reff138_op in H. discriminate H. Qed.

Lemma reff138_not4268 : ~ @Equation4268 Fin3 reff138_inst.
Proof. unfold Equation4268. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff138_inst, reff138_op in H. discriminate H. Qed.

Lemma reff138_not4269 : ~ @Equation4269 Fin3 reff138_inst.
Proof. unfold Equation4269. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff138_inst, reff138_op in H. discriminate H. Qed.

Lemma reff138_not4270 : ~ @Equation4270 Fin3 reff138_inst.
Proof. unfold Equation4270. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff138_inst, reff138_op in H. discriminate H. Qed.

Lemma reff138_not4272 : ~ @Equation4272 Fin3 reff138_inst.
Proof. unfold Equation4272. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff138_inst, reff138_op in H. discriminate H. Qed.

Lemma reff138_not4273 : ~ @Equation4273 Fin3 reff138_inst.
Proof. unfold Equation4273. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff138_inst, reff138_op in H. discriminate H. Qed.

Lemma reff138_not4275 : ~ @Equation4275 Fin3 reff138_inst.
Proof. unfold Equation4275. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff138_inst, reff138_op in H. discriminate H. Qed.

Lemma reff138_not4276 : ~ @Equation4276 Fin3 reff138_inst.
Proof. unfold Equation4276. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff138_inst, reff138_op in H. discriminate H. Qed.

Lemma reff138_not4283 : ~ @Equation4283 Fin3 reff138_inst.
Proof. unfold Equation4283. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff138_inst, reff138_op in H. discriminate H. Qed.

Lemma reff138_not4284 : ~ @Equation4284 Fin3 reff138_inst.
Proof. unfold Equation4284. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff138_inst, reff138_op in H. discriminate H. Qed.

Lemma reff138_not4290 : ~ @Equation4290 Fin3 reff138_inst.
Proof. unfold Equation4290. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff138_inst, reff138_op in H. discriminate H. Qed.

Lemma reff138_not4291 : ~ @Equation4291 Fin3 reff138_inst.
Proof. unfold Equation4291. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff138_inst, reff138_op in H. discriminate H. Qed.

Lemma reff138_not4293 : ~ @Equation4293 Fin3 reff138_inst.
Proof. unfold Equation4293. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff138_inst, reff138_op in H. discriminate H. Qed.

Lemma reff138_not4314 : ~ @Equation4314 Fin3 reff138_inst.
Proof. unfold Equation4314. intro H. specialize (H F3_1 F3_0). unfold magma_op, reff138_inst, reff138_op in H. discriminate H. Qed.

Lemma reff138_not4320 : ~ @Equation4320 Fin3 reff138_inst.
Proof. unfold Equation4320. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff138_inst, reff138_op in H. discriminate H. Qed.

Lemma reff138_not4321 : ~ @Equation4321 Fin3 reff138_inst.
Proof. unfold Equation4321. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff138_inst, reff138_op in H. discriminate H. Qed.

Lemma reff138_not4343 : ~ @Equation4343 Fin3 reff138_inst.
Proof. unfold Equation4343. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff138_inst, reff138_op in H. discriminate H. Qed.

Lemma reff138_not4380 : ~ @Equation4380 Fin3 reff138_inst.
Proof. unfold Equation4380. intro H. specialize (H F3_1). unfold magma_op, reff138_inst, reff138_op in H. discriminate H. Qed.

Lemma reff138_not4583 : ~ @Equation4583 Fin3 reff138_inst.
Proof. unfold Equation4583. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff138_inst, reff138_op in H. discriminate H. Qed.

Lemma reff138_not4584 : ~ @Equation4584 Fin3 reff138_inst.
Proof. unfold Equation4584. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff138_inst, reff138_op in H. discriminate H. Qed.

Lemma reff138_not4585 : ~ @Equation4585 Fin3 reff138_inst.
Proof. unfold Equation4585. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff138_inst, reff138_op in H. discriminate H. Qed.

Lemma reff138_not4588 : ~ @Equation4588 Fin3 reff138_inst.
Proof. unfold Equation4588. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff138_inst, reff138_op in H. discriminate H. Qed.

Lemma reff138_not4590 : ~ @Equation4590 Fin3 reff138_inst.
Proof. unfold Equation4590. intro H. specialize (H F3_1 F3_2). unfold magma_op, reff138_inst, reff138_op in H. discriminate H. Qed.

Lemma reff138_not4591 : ~ @Equation4591 Fin3 reff138_inst.
Proof. unfold Equation4591. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff138_inst, reff138_op in H. discriminate H. Qed.

Lemma reff138_not4598 : ~ @Equation4598 Fin3 reff138_inst.
Proof. unfold Equation4598. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff138_inst, reff138_op in H. discriminate H. Qed.

Lemma reff138_not4599 : ~ @Equation4599 Fin3 reff138_inst.
Proof. unfold Equation4599. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff138_inst, reff138_op in H. discriminate H. Qed.

Lemma reff138_not4605 : ~ @Equation4605 Fin3 reff138_inst.
Proof. unfold Equation4605. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff138_inst, reff138_op in H. discriminate H. Qed.

Lemma reff138_not4606 : ~ @Equation4606 Fin3 reff138_inst.
Proof. unfold Equation4606. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff138_inst, reff138_op in H. discriminate H. Qed.

Lemma reff138_not4608 : ~ @Equation4608 Fin3 reff138_inst.
Proof. unfold Equation4608. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff138_inst, reff138_op in H. discriminate H. Qed.

Lemma reff138_not4629 : ~ @Equation4629 Fin3 reff138_inst.
Proof. unfold Equation4629. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff138_inst, reff138_op in H. discriminate H. Qed.

Lemma reff138_not4635 : ~ @Equation4635 Fin3 reff138_inst.
Proof. unfold Equation4635. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff138_inst, reff138_op in H. discriminate H. Qed.

Lemma reff138_not4636 : ~ @Equation4636 Fin3 reff138_inst.
Proof. unfold Equation4636. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff138_inst, reff138_op in H. discriminate H. Qed.

Lemma reff138_not4658 : ~ @Equation4658 Fin3 reff138_inst.
Proof. unfold Equation4658. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff138_inst, reff138_op in H. discriminate H. Qed.

(** ---- reff14 (Fin4) ---- *)

Definition reff14_op (x y : Fin4) : Fin4 :=
  match x, y with
  | F4_0, F4_0 => F4_0 | F4_0, F4_1 => F4_2 | F4_0, F4_2 => F4_0 | F4_0, F4_3 => F4_2
  | F4_1, F4_0 => F4_1 | F4_1, F4_1 => F4_3 | F4_1, F4_2 => F4_1 | F4_1, F4_3 => F4_3
  | F4_2, F4_0 => F4_2 | F4_2, F4_1 => F4_0 | F4_2, F4_2 => F4_2 | F4_2, F4_3 => F4_0
  | F4_3, F4_0 => F4_3 | F4_3, F4_1 => F4_1 | F4_3, F4_2 => F4_3 | F4_3, F4_3 => F4_1
  end.

#[local] Instance reff14_inst : Magma Fin4 := {| magma_op := reff14_op |}.

Lemma reff14_sat26 : @Equation26 Fin4 reff14_inst.
Proof. unfold Equation26, magma_op, reff14_inst, reff14_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff14_sat161 : @Equation161 Fin4 reff14_inst.
Proof. unfold Equation161, magma_op, reff14_inst, reff14_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff14_sat215 : @Equation215 Fin4 reff14_inst.
Proof. unfold Equation215, magma_op, reff14_inst, reff14_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff14_sat327 : @Equation327 Fin4 reff14_inst.
Proof. unfold Equation327, magma_op, reff14_inst, reff14_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff14_sat1663 : @Equation1663 Fin4 reff14_inst.
Proof. unfold Equation1663, magma_op, reff14_inst, reff14_op. intros x y z w. destruct x, y, z, w; reflexivity. Qed.

Lemma reff14_sat1874 : @Equation1874 Fin4 reff14_inst.
Proof. unfold Equation1874, magma_op, reff14_inst, reff14_op. intros x y z w. destruct x, y, z, w; reflexivity. Qed.

Lemma reff14_sat2489 : @Equation2489 Fin4 reff14_inst.
Proof. unfold Equation2489, magma_op, reff14_inst, reff14_op. intros x y z w. destruct x, y, z, w; reflexivity. Qed.

Lemma reff14_sat3091 : @Equation3091 Fin4 reff14_inst.
Proof. unfold Equation3091, magma_op, reff14_inst, reff14_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff14_sat4143 : @Equation4143 Fin4 reff14_inst.
Proof. unfold Equation4143, magma_op, reff14_inst, reff14_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff14_sat4673 : @Equation4673 Fin4 reff14_inst.
Proof. unfold Equation4673, magma_op, reff14_inst, reff14_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff14_not47 : ~ @Equation47 Fin4 reff14_inst.
Proof. unfold Equation47. intro H. specialize (H F4_1). unfold magma_op, reff14_inst, reff14_op in H. discriminate H. Qed.

Lemma reff14_not99 : ~ @Equation99 Fin4 reff14_inst.
Proof. unfold Equation99. intro H. specialize (H F4_1). unfold magma_op, reff14_inst, reff14_op in H. discriminate H. Qed.

Lemma reff14_not154 : ~ @Equation154 Fin4 reff14_inst.
Proof. unfold Equation154. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff14_inst, reff14_op in H. discriminate H. Qed.

Lemma reff14_not157 : ~ @Equation157 Fin4 reff14_inst.
Proof. unfold Equation157. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff14_inst, reff14_op in H. discriminate H. Qed.

Lemma reff14_not167 : ~ @Equation167 Fin4 reff14_inst.
Proof. unfold Equation167. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff14_inst, reff14_op in H. discriminate H. Qed.

Lemma reff14_not169 : ~ @Equation169 Fin4 reff14_inst.
Proof. unfold Equation169. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff14_inst, reff14_op in H. discriminate H. Qed.

Lemma reff14_not170 : ~ @Equation170 Fin4 reff14_inst.
Proof. unfold Equation170. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff14_inst, reff14_op in H. discriminate H. Qed.

Lemma reff14_not176 : ~ @Equation176 Fin4 reff14_inst.
Proof. unfold Equation176. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff14_inst, reff14_op in H. discriminate H. Qed.

Lemma reff14_not177 : ~ @Equation177 Fin4 reff14_inst.
Proof. unfold Equation177. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff14_inst, reff14_op in H. discriminate H. Qed.

Lemma reff14_not179 : ~ @Equation179 Fin4 reff14_inst.
Proof. unfold Equation179. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff14_inst, reff14_op in H. discriminate H. Qed.

Lemma reff14_not206 : ~ @Equation206 Fin4 reff14_inst.
Proof. unfold Equation206. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff14_inst, reff14_op in H. discriminate H. Qed.

Lemma reff14_not211 : ~ @Equation211 Fin4 reff14_inst.
Proof. unfold Equation211. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff14_inst, reff14_op in H. discriminate H. Qed.

Lemma reff14_not219 : ~ @Equation219 Fin4 reff14_inst.
Proof. unfold Equation219. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff14_inst, reff14_op in H. discriminate H. Qed.

Lemma reff14_not221 : ~ @Equation221 Fin4 reff14_inst.
Proof. unfold Equation221. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff14_inst, reff14_op in H. discriminate H. Qed.

Lemma reff14_not222 : ~ @Equation222 Fin4 reff14_inst.
Proof. unfold Equation222. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff14_inst, reff14_op in H. discriminate H. Qed.

Lemma reff14_not228 : ~ @Equation228 Fin4 reff14_inst.
Proof. unfold Equation228. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff14_inst, reff14_op in H. discriminate H. Qed.

Lemma reff14_not229 : ~ @Equation229 Fin4 reff14_inst.
Proof. unfold Equation229. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff14_inst, reff14_op in H. discriminate H. Qed.

Lemma reff14_not231 : ~ @Equation231 Fin4 reff14_inst.
Proof. unfold Equation231. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff14_inst, reff14_op in H. discriminate H. Qed.

Lemma reff14_not255 : ~ @Equation255 Fin4 reff14_inst.
Proof. unfold Equation255. intro H. specialize (H F4_1). unfold magma_op, reff14_inst, reff14_op in H. discriminate H. Qed.

Lemma reff14_not359 : ~ @Equation359 Fin4 reff14_inst.
Proof. unfold Equation359. intro H. specialize (H F4_1). unfold magma_op, reff14_inst, reff14_op in H. discriminate H. Qed.

Lemma reff14_not411 : ~ @Equation411 Fin4 reff14_inst.
Proof. unfold Equation411. intro H. specialize (H F4_1). unfold magma_op, reff14_inst, reff14_op in H. discriminate H. Qed.

Lemma reff14_not614 : ~ @Equation614 Fin4 reff14_inst.
Proof. unfold Equation614. intro H. specialize (H F4_1). unfold magma_op, reff14_inst, reff14_op in H. discriminate H. Qed.

Lemma reff14_not817 : ~ @Equation817 Fin4 reff14_inst.
Proof. unfold Equation817. intro H. specialize (H F4_1). unfold magma_op, reff14_inst, reff14_op in H. discriminate H. Qed.

Lemma reff14_not1020 : ~ @Equation1020 Fin4 reff14_inst.
Proof. unfold Equation1020. intro H. specialize (H F4_1). unfold magma_op, reff14_inst, reff14_op in H. discriminate H. Qed.

Lemma reff14_not1223 : ~ @Equation1223 Fin4 reff14_inst.
Proof. unfold Equation1223. intro H. specialize (H F4_1). unfold magma_op, reff14_inst, reff14_op in H. discriminate H. Qed.

Lemma reff14_not1431 : ~ @Equation1431 Fin4 reff14_inst.
Proof. unfold Equation1431. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff14_inst, reff14_op in H. discriminate H. Qed.

Lemma reff14_not1432 : ~ @Equation1432 Fin4 reff14_inst.
Proof. unfold Equation1432. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff14_inst, reff14_op in H. discriminate H. Qed.

Lemma reff14_not1434 : ~ @Equation1434 Fin4 reff14_inst.
Proof. unfold Equation1434. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff14_inst, reff14_op in H. discriminate H. Qed.

Lemma reff14_not1435 : ~ @Equation1435 Fin4 reff14_inst.
Proof. unfold Equation1435. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff14_inst, reff14_op in H. discriminate H. Qed.

Lemma reff14_not1441 : ~ @Equation1441 Fin4 reff14_inst.
Proof. unfold Equation1441. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff14_inst, reff14_op in H. discriminate H. Qed.

Lemma reff14_not1442 : ~ @Equation1442 Fin4 reff14_inst.
Proof. unfold Equation1442. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff14_inst, reff14_op in H. discriminate H. Qed.

Lemma reff14_not1444 : ~ @Equation1444 Fin4 reff14_inst.
Proof. unfold Equation1444. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff14_inst, reff14_op in H. discriminate H. Qed.

Lemma reff14_not1445 : ~ @Equation1445 Fin4 reff14_inst.
Proof. unfold Equation1445. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff14_inst, reff14_op in H. discriminate H. Qed.

Lemma reff14_not1478 : ~ @Equation1478 Fin4 reff14_inst.
Proof. unfold Equation1478. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff14_inst, reff14_op in H. discriminate H. Qed.

Lemma reff14_not1479 : ~ @Equation1479 Fin4 reff14_inst.
Proof. unfold Equation1479. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff14_inst, reff14_op in H. discriminate H. Qed.

Lemma reff14_not1481 : ~ @Equation1481 Fin4 reff14_inst.
Proof. unfold Equation1481. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff14_inst, reff14_op in H. discriminate H. Qed.

Lemma reff14_not1482 : ~ @Equation1482 Fin4 reff14_inst.
Proof. unfold Equation1482. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff14_inst, reff14_op in H. discriminate H. Qed.

Lemma reff14_not1488 : ~ @Equation1488 Fin4 reff14_inst.
Proof. unfold Equation1488. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff14_inst, reff14_op in H. discriminate H. Qed.

Lemma reff14_not1489 : ~ @Equation1489 Fin4 reff14_inst.
Proof. unfold Equation1489. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff14_inst, reff14_op in H. discriminate H. Qed.

Lemma reff14_not1491 : ~ @Equation1491 Fin4 reff14_inst.
Proof. unfold Equation1491. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff14_inst, reff14_op in H. discriminate H. Qed.

Lemma reff14_not1492 : ~ @Equation1492 Fin4 reff14_inst.
Proof. unfold Equation1492. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff14_inst, reff14_op in H. discriminate H. Qed.

Lemma reff14_not1515 : ~ @Equation1515 Fin4 reff14_inst.
Proof. unfold Equation1515. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff14_inst, reff14_op in H. discriminate H. Qed.

Lemma reff14_not1516 : ~ @Equation1516 Fin4 reff14_inst.
Proof. unfold Equation1516. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff14_inst, reff14_op in H. discriminate H. Qed.

Lemma reff14_not1518 : ~ @Equation1518 Fin4 reff14_inst.
Proof. unfold Equation1518. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff14_inst, reff14_op in H. discriminate H. Qed.

Lemma reff14_not1519 : ~ @Equation1519 Fin4 reff14_inst.
Proof. unfold Equation1519. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff14_inst, reff14_op in H. discriminate H. Qed.

Lemma reff14_not1525 : ~ @Equation1525 Fin4 reff14_inst.
Proof. unfold Equation1525. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff14_inst, reff14_op in H. discriminate H. Qed.

Lemma reff14_not1526 : ~ @Equation1526 Fin4 reff14_inst.
Proof. unfold Equation1526. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff14_inst, reff14_op in H. discriminate H. Qed.

Lemma reff14_not1528 : ~ @Equation1528 Fin4 reff14_inst.
Proof. unfold Equation1528. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff14_inst, reff14_op in H. discriminate H. Qed.

Lemma reff14_not1634 : ~ @Equation1634 Fin4 reff14_inst.
Proof. unfold Equation1634. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff14_inst, reff14_op in H. discriminate H. Qed.

Lemma reff14_not1635 : ~ @Equation1635 Fin4 reff14_inst.
Proof. unfold Equation1635. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff14_inst, reff14_op in H. discriminate H. Qed.

Lemma reff14_not1637 : ~ @Equation1637 Fin4 reff14_inst.
Proof. unfold Equation1637. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff14_inst, reff14_op in H. discriminate H. Qed.

Lemma reff14_not1638 : ~ @Equation1638 Fin4 reff14_inst.
Proof. unfold Equation1638. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff14_inst, reff14_op in H. discriminate H. Qed.

Lemma reff14_not1644 : ~ @Equation1644 Fin4 reff14_inst.
Proof. unfold Equation1644. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff14_inst, reff14_op in H. discriminate H. Qed.

Lemma reff14_not1645 : ~ @Equation1645 Fin4 reff14_inst.
Proof. unfold Equation1645. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff14_inst, reff14_op in H. discriminate H. Qed.

Lemma reff14_not1647 : ~ @Equation1647 Fin4 reff14_inst.
Proof. unfold Equation1647. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff14_inst, reff14_op in H. discriminate H. Qed.

Lemma reff14_not1648 : ~ @Equation1648 Fin4 reff14_inst.
Proof. unfold Equation1648. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff14_inst, reff14_op in H. discriminate H. Qed.

Lemma reff14_not1681 : ~ @Equation1681 Fin4 reff14_inst.
Proof. unfold Equation1681. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff14_inst, reff14_op in H. discriminate H. Qed.

Lemma reff14_not1682 : ~ @Equation1682 Fin4 reff14_inst.
Proof. unfold Equation1682. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff14_inst, reff14_op in H. discriminate H. Qed.

Lemma reff14_not1684 : ~ @Equation1684 Fin4 reff14_inst.
Proof. unfold Equation1684. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff14_inst, reff14_op in H. discriminate H. Qed.

Lemma reff14_not1685 : ~ @Equation1685 Fin4 reff14_inst.
Proof. unfold Equation1685. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff14_inst, reff14_op in H. discriminate H. Qed.

Lemma reff14_not1691 : ~ @Equation1691 Fin4 reff14_inst.
Proof. unfold Equation1691. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff14_inst, reff14_op in H. discriminate H. Qed.

Lemma reff14_not1692 : ~ @Equation1692 Fin4 reff14_inst.
Proof. unfold Equation1692. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff14_inst, reff14_op in H. discriminate H. Qed.

Lemma reff14_not1694 : ~ @Equation1694 Fin4 reff14_inst.
Proof. unfold Equation1694. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff14_inst, reff14_op in H. discriminate H. Qed.

Lemma reff14_not1695 : ~ @Equation1695 Fin4 reff14_inst.
Proof. unfold Equation1695. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff14_inst, reff14_op in H. discriminate H. Qed.

Lemma reff14_not1718 : ~ @Equation1718 Fin4 reff14_inst.
Proof. unfold Equation1718. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff14_inst, reff14_op in H. discriminate H. Qed.

Lemma reff14_not1719 : ~ @Equation1719 Fin4 reff14_inst.
Proof. unfold Equation1719. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff14_inst, reff14_op in H. discriminate H. Qed.

Lemma reff14_not1721 : ~ @Equation1721 Fin4 reff14_inst.
Proof. unfold Equation1721. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff14_inst, reff14_op in H. discriminate H. Qed.

Lemma reff14_not1722 : ~ @Equation1722 Fin4 reff14_inst.
Proof. unfold Equation1722. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff14_inst, reff14_op in H. discriminate H. Qed.

Lemma reff14_not1728 : ~ @Equation1728 Fin4 reff14_inst.
Proof. unfold Equation1728. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff14_inst, reff14_op in H. discriminate H. Qed.

Lemma reff14_not1729 : ~ @Equation1729 Fin4 reff14_inst.
Proof. unfold Equation1729. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff14_inst, reff14_op in H. discriminate H. Qed.

Lemma reff14_not1731 : ~ @Equation1731 Fin4 reff14_inst.
Proof. unfold Equation1731. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff14_inst, reff14_op in H. discriminate H. Qed.

Lemma reff14_not1834 : ~ @Equation1834 Fin4 reff14_inst.
Proof. unfold Equation1834. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff14_inst, reff14_op in H. discriminate H. Qed.

Lemma reff14_not1835 : ~ @Equation1835 Fin4 reff14_inst.
Proof. unfold Equation1835. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff14_inst, reff14_op in H. discriminate H. Qed.

Lemma reff14_not1840 : ~ @Equation1840 Fin4 reff14_inst.
Proof. unfold Equation1840. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff14_inst, reff14_op in H. discriminate H. Qed.

Lemma reff14_not1841 : ~ @Equation1841 Fin4 reff14_inst.
Proof. unfold Equation1841. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff14_inst, reff14_op in H. discriminate H. Qed.

Lemma reff14_not1847 : ~ @Equation1847 Fin4 reff14_inst.
Proof. unfold Equation1847. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff14_inst, reff14_op in H. discriminate H. Qed.

Lemma reff14_not1848 : ~ @Equation1848 Fin4 reff14_inst.
Proof. unfold Equation1848. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff14_inst, reff14_op in H. discriminate H. Qed.

Lemma reff14_not1857 : ~ @Equation1857 Fin4 reff14_inst.
Proof. unfold Equation1857. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff14_inst, reff14_op in H. discriminate H. Qed.

Lemma reff14_not1858 : ~ @Equation1858 Fin4 reff14_inst.
Proof. unfold Equation1858. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff14_inst, reff14_op in H. discriminate H. Qed.

Lemma reff14_not1884 : ~ @Equation1884 Fin4 reff14_inst.
Proof. unfold Equation1884. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff14_inst, reff14_op in H. discriminate H. Qed.

Lemma reff14_not1885 : ~ @Equation1885 Fin4 reff14_inst.
Proof. unfold Equation1885. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff14_inst, reff14_op in H. discriminate H. Qed.

Lemma reff14_not1887 : ~ @Equation1887 Fin4 reff14_inst.
Proof. unfold Equation1887. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff14_inst, reff14_op in H. discriminate H. Qed.

Lemma reff14_not1888 : ~ @Equation1888 Fin4 reff14_inst.
Proof. unfold Equation1888. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff14_inst, reff14_op in H. discriminate H. Qed.

Lemma reff14_not1894 : ~ @Equation1894 Fin4 reff14_inst.
Proof. unfold Equation1894. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff14_inst, reff14_op in H. discriminate H. Qed.

Lemma reff14_not1895 : ~ @Equation1895 Fin4 reff14_inst.
Proof. unfold Equation1895. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff14_inst, reff14_op in H. discriminate H. Qed.

Lemma reff14_not1897 : ~ @Equation1897 Fin4 reff14_inst.
Proof. unfold Equation1897. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff14_inst, reff14_op in H. discriminate H. Qed.

Lemma reff14_not1898 : ~ @Equation1898 Fin4 reff14_inst.
Proof. unfold Equation1898. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff14_inst, reff14_op in H. discriminate H. Qed.

Lemma reff14_not1921 : ~ @Equation1921 Fin4 reff14_inst.
Proof. unfold Equation1921. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff14_inst, reff14_op in H. discriminate H. Qed.

Lemma reff14_not1922 : ~ @Equation1922 Fin4 reff14_inst.
Proof. unfold Equation1922. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff14_inst, reff14_op in H. discriminate H. Qed.

Lemma reff14_not1924 : ~ @Equation1924 Fin4 reff14_inst.
Proof. unfold Equation1924. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff14_inst, reff14_op in H. discriminate H. Qed.

Lemma reff14_not1925 : ~ @Equation1925 Fin4 reff14_inst.
Proof. unfold Equation1925. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff14_inst, reff14_op in H. discriminate H. Qed.

Lemma reff14_not1931 : ~ @Equation1931 Fin4 reff14_inst.
Proof. unfold Equation1931. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff14_inst, reff14_op in H. discriminate H. Qed.

Lemma reff14_not1932 : ~ @Equation1932 Fin4 reff14_inst.
Proof. unfold Equation1932. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff14_inst, reff14_op in H. discriminate H. Qed.

Lemma reff14_not1934 : ~ @Equation1934 Fin4 reff14_inst.
Proof. unfold Equation1934. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff14_inst, reff14_op in H. discriminate H. Qed.

Lemma reff14_not2035 : ~ @Equation2035 Fin4 reff14_inst.
Proof. unfold Equation2035. intro H. specialize (H F4_1). unfold magma_op, reff14_inst, reff14_op in H. discriminate H. Qed.

Lemma reff14_not2239 : ~ @Equation2239 Fin4 reff14_inst.
Proof. unfold Equation2239. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff14_inst, reff14_op in H. discriminate H. Qed.

Lemma reff14_not2241 : ~ @Equation2241 Fin4 reff14_inst.
Proof. unfold Equation2241. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff14_inst, reff14_op in H. discriminate H. Qed.

Lemma reff14_not2244 : ~ @Equation2244 Fin4 reff14_inst.
Proof. unfold Equation2244. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff14_inst, reff14_op in H. discriminate H. Qed.

Lemma reff14_not2247 : ~ @Equation2247 Fin4 reff14_inst.
Proof. unfold Equation2247. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff14_inst, reff14_op in H. discriminate H. Qed.

Lemma reff14_not2253 : ~ @Equation2253 Fin4 reff14_inst.
Proof. unfold Equation2253. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff14_inst, reff14_op in H. discriminate H. Qed.

Lemma reff14_not2256 : ~ @Equation2256 Fin4 reff14_inst.
Proof. unfold Equation2256. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff14_inst, reff14_op in H. discriminate H. Qed.

Lemma reff14_not2263 : ~ @Equation2263 Fin4 reff14_inst.
Proof. unfold Equation2263. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff14_inst, reff14_op in H. discriminate H. Qed.

Lemma reff14_not2266 : ~ @Equation2266 Fin4 reff14_inst.
Proof. unfold Equation2266. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff14_inst, reff14_op in H. discriminate H. Qed.

Lemma reff14_not2290 : ~ @Equation2290 Fin4 reff14_inst.
Proof. unfold Equation2290. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff14_inst, reff14_op in H. discriminate H. Qed.

Lemma reff14_not2291 : ~ @Equation2291 Fin4 reff14_inst.
Proof. unfold Equation2291. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff14_inst, reff14_op in H. discriminate H. Qed.

Lemma reff14_not2293 : ~ @Equation2293 Fin4 reff14_inst.
Proof. unfold Equation2293. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff14_inst, reff14_op in H. discriminate H. Qed.

Lemma reff14_not2294 : ~ @Equation2294 Fin4 reff14_inst.
Proof. unfold Equation2294. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff14_inst, reff14_op in H. discriminate H. Qed.

Lemma reff14_not2300 : ~ @Equation2300 Fin4 reff14_inst.
Proof. unfold Equation2300. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff14_inst, reff14_op in H. discriminate H. Qed.

Lemma reff14_not2301 : ~ @Equation2301 Fin4 reff14_inst.
Proof. unfold Equation2301. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff14_inst, reff14_op in H. discriminate H. Qed.

Lemma reff14_not2303 : ~ @Equation2303 Fin4 reff14_inst.
Proof. unfold Equation2303. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff14_inst, reff14_op in H. discriminate H. Qed.

Lemma reff14_not2304 : ~ @Equation2304 Fin4 reff14_inst.
Proof. unfold Equation2304. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff14_inst, reff14_op in H. discriminate H. Qed.

Lemma reff14_not2327 : ~ @Equation2327 Fin4 reff14_inst.
Proof. unfold Equation2327. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff14_inst, reff14_op in H. discriminate H. Qed.

Lemma reff14_not2328 : ~ @Equation2328 Fin4 reff14_inst.
Proof. unfold Equation2328. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff14_inst, reff14_op in H. discriminate H. Qed.

Lemma reff14_not2330 : ~ @Equation2330 Fin4 reff14_inst.
Proof. unfold Equation2330. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff14_inst, reff14_op in H. discriminate H. Qed.

Lemma reff14_not2331 : ~ @Equation2331 Fin4 reff14_inst.
Proof. unfold Equation2331. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff14_inst, reff14_op in H. discriminate H. Qed.

Lemma reff14_not2337 : ~ @Equation2337 Fin4 reff14_inst.
Proof. unfold Equation2337. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff14_inst, reff14_op in H. discriminate H. Qed.

Lemma reff14_not2338 : ~ @Equation2338 Fin4 reff14_inst.
Proof. unfold Equation2338. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff14_inst, reff14_op in H. discriminate H. Qed.

Lemma reff14_not2340 : ~ @Equation2340 Fin4 reff14_inst.
Proof. unfold Equation2340. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff14_inst, reff14_op in H. discriminate H. Qed.

Lemma reff14_not2442 : ~ @Equation2442 Fin4 reff14_inst.
Proof. unfold Equation2442. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff14_inst, reff14_op in H. discriminate H. Qed.

Lemma reff14_not2444 : ~ @Equation2444 Fin4 reff14_inst.
Proof. unfold Equation2444. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff14_inst, reff14_op in H. discriminate H. Qed.

Lemma reff14_not2447 : ~ @Equation2447 Fin4 reff14_inst.
Proof. unfold Equation2447. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff14_inst, reff14_op in H. discriminate H. Qed.

Lemma reff14_not2450 : ~ @Equation2450 Fin4 reff14_inst.
Proof. unfold Equation2450. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff14_inst, reff14_op in H. discriminate H. Qed.

Lemma reff14_not2456 : ~ @Equation2456 Fin4 reff14_inst.
Proof. unfold Equation2456. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff14_inst, reff14_op in H. discriminate H. Qed.

Lemma reff14_not2459 : ~ @Equation2459 Fin4 reff14_inst.
Proof. unfold Equation2459. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff14_inst, reff14_op in H. discriminate H. Qed.

Lemma reff14_not2466 : ~ @Equation2466 Fin4 reff14_inst.
Proof. unfold Equation2466. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff14_inst, reff14_op in H. discriminate H. Qed.

Lemma reff14_not2469 : ~ @Equation2469 Fin4 reff14_inst.
Proof. unfold Equation2469. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff14_inst, reff14_op in H. discriminate H. Qed.

Lemma reff14_not2493 : ~ @Equation2493 Fin4 reff14_inst.
Proof. unfold Equation2493. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff14_inst, reff14_op in H. discriminate H. Qed.

Lemma reff14_not2494 : ~ @Equation2494 Fin4 reff14_inst.
Proof. unfold Equation2494. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff14_inst, reff14_op in H. discriminate H. Qed.

Lemma reff14_not2496 : ~ @Equation2496 Fin4 reff14_inst.
Proof. unfold Equation2496. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff14_inst, reff14_op in H. discriminate H. Qed.

Lemma reff14_not2497 : ~ @Equation2497 Fin4 reff14_inst.
Proof. unfold Equation2497. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff14_inst, reff14_op in H. discriminate H. Qed.

Lemma reff14_not2503 : ~ @Equation2503 Fin4 reff14_inst.
Proof. unfold Equation2503. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff14_inst, reff14_op in H. discriminate H. Qed.

Lemma reff14_not2504 : ~ @Equation2504 Fin4 reff14_inst.
Proof. unfold Equation2504. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff14_inst, reff14_op in H. discriminate H. Qed.

Lemma reff14_not2506 : ~ @Equation2506 Fin4 reff14_inst.
Proof. unfold Equation2506. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff14_inst, reff14_op in H. discriminate H. Qed.

Lemma reff14_not2507 : ~ @Equation2507 Fin4 reff14_inst.
Proof. unfold Equation2507. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff14_inst, reff14_op in H. discriminate H. Qed.

Lemma reff14_not2530 : ~ @Equation2530 Fin4 reff14_inst.
Proof. unfold Equation2530. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff14_inst, reff14_op in H. discriminate H. Qed.

Lemma reff14_not2531 : ~ @Equation2531 Fin4 reff14_inst.
Proof. unfold Equation2531. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff14_inst, reff14_op in H. discriminate H. Qed.

Lemma reff14_not2533 : ~ @Equation2533 Fin4 reff14_inst.
Proof. unfold Equation2533. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff14_inst, reff14_op in H. discriminate H. Qed.

Lemma reff14_not2534 : ~ @Equation2534 Fin4 reff14_inst.
Proof. unfold Equation2534. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff14_inst, reff14_op in H. discriminate H. Qed.

Lemma reff14_not2540 : ~ @Equation2540 Fin4 reff14_inst.
Proof. unfold Equation2540. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff14_inst, reff14_op in H. discriminate H. Qed.

Lemma reff14_not2541 : ~ @Equation2541 Fin4 reff14_inst.
Proof. unfold Equation2541. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff14_inst, reff14_op in H. discriminate H. Qed.

Lemma reff14_not2543 : ~ @Equation2543 Fin4 reff14_inst.
Proof. unfold Equation2543. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff14_inst, reff14_op in H. discriminate H. Qed.

Lemma reff14_not2644 : ~ @Equation2644 Fin4 reff14_inst.
Proof. unfold Equation2644. intro H. specialize (H F4_1). unfold magma_op, reff14_inst, reff14_op in H. discriminate H. Qed.

Lemma reff14_not2847 : ~ @Equation2847 Fin4 reff14_inst.
Proof. unfold Equation2847. intro H. specialize (H F4_1). unfold magma_op, reff14_inst, reff14_op in H. discriminate H. Qed.

Lemma reff14_not3051 : ~ @Equation3051 Fin4 reff14_inst.
Proof. unfold Equation3051. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff14_inst, reff14_op in H. discriminate H. Qed.

Lemma reff14_not3052 : ~ @Equation3052 Fin4 reff14_inst.
Proof. unfold Equation3052. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff14_inst, reff14_op in H. discriminate H. Qed.

Lemma reff14_not3055 : ~ @Equation3055 Fin4 reff14_inst.
Proof. unfold Equation3055. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff14_inst, reff14_op in H. discriminate H. Qed.

Lemma reff14_not3059 : ~ @Equation3059 Fin4 reff14_inst.
Proof. unfold Equation3059. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff14_inst, reff14_op in H. discriminate H. Qed.

Lemma reff14_not3065 : ~ @Equation3065 Fin4 reff14_inst.
Proof. unfold Equation3065. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff14_inst, reff14_op in H. discriminate H. Qed.

Lemma reff14_not3069 : ~ @Equation3069 Fin4 reff14_inst.
Proof. unfold Equation3069. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff14_inst, reff14_op in H. discriminate H. Qed.

Lemma reff14_not3076 : ~ @Equation3076 Fin4 reff14_inst.
Proof. unfold Equation3076. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff14_inst, reff14_op in H. discriminate H. Qed.

Lemma reff14_not3078 : ~ @Equation3078 Fin4 reff14_inst.
Proof. unfold Equation3078. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff14_inst, reff14_op in H. discriminate H. Qed.

Lemma reff14_not3102 : ~ @Equation3102 Fin4 reff14_inst.
Proof. unfold Equation3102. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff14_inst, reff14_op in H. discriminate H. Qed.

Lemma reff14_not3103 : ~ @Equation3103 Fin4 reff14_inst.
Proof. unfold Equation3103. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff14_inst, reff14_op in H. discriminate H. Qed.

Lemma reff14_not3105 : ~ @Equation3105 Fin4 reff14_inst.
Proof. unfold Equation3105. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff14_inst, reff14_op in H. discriminate H. Qed.

Lemma reff14_not3106 : ~ @Equation3106 Fin4 reff14_inst.
Proof. unfold Equation3106. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff14_inst, reff14_op in H. discriminate H. Qed.

Lemma reff14_not3112 : ~ @Equation3112 Fin4 reff14_inst.
Proof. unfold Equation3112. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff14_inst, reff14_op in H. discriminate H. Qed.

Lemma reff14_not3113 : ~ @Equation3113 Fin4 reff14_inst.
Proof. unfold Equation3113. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff14_inst, reff14_op in H. discriminate H. Qed.

Lemma reff14_not3115 : ~ @Equation3115 Fin4 reff14_inst.
Proof. unfold Equation3115. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff14_inst, reff14_op in H. discriminate H. Qed.

Lemma reff14_not3116 : ~ @Equation3116 Fin4 reff14_inst.
Proof. unfold Equation3116. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff14_inst, reff14_op in H. discriminate H. Qed.

Lemma reff14_not3139 : ~ @Equation3139 Fin4 reff14_inst.
Proof. unfold Equation3139. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff14_inst, reff14_op in H. discriminate H. Qed.

Lemma reff14_not3140 : ~ @Equation3140 Fin4 reff14_inst.
Proof. unfold Equation3140. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff14_inst, reff14_op in H. discriminate H. Qed.

Lemma reff14_not3142 : ~ @Equation3142 Fin4 reff14_inst.
Proof. unfold Equation3142. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff14_inst, reff14_op in H. discriminate H. Qed.

Lemma reff14_not3143 : ~ @Equation3143 Fin4 reff14_inst.
Proof. unfold Equation3143. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff14_inst, reff14_op in H. discriminate H. Qed.

Lemma reff14_not3149 : ~ @Equation3149 Fin4 reff14_inst.
Proof. unfold Equation3149. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff14_inst, reff14_op in H. discriminate H. Qed.

Lemma reff14_not3150 : ~ @Equation3150 Fin4 reff14_inst.
Proof. unfold Equation3150. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff14_inst, reff14_op in H. discriminate H. Qed.

Lemma reff14_not3152 : ~ @Equation3152 Fin4 reff14_inst.
Proof. unfold Equation3152. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff14_inst, reff14_op in H. discriminate H. Qed.

Lemma reff14_not3258 : ~ @Equation3258 Fin4 reff14_inst.
Proof. unfold Equation3258. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff14_inst, reff14_op in H. discriminate H. Qed.

Lemma reff14_not3259 : ~ @Equation3259 Fin4 reff14_inst.
Proof. unfold Equation3259. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff14_inst, reff14_op in H. discriminate H. Qed.

Lemma reff14_not3261 : ~ @Equation3261 Fin4 reff14_inst.
Proof. unfold Equation3261. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff14_inst, reff14_op in H. discriminate H. Qed.

Lemma reff14_not3262 : ~ @Equation3262 Fin4 reff14_inst.
Proof. unfold Equation3262. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff14_inst, reff14_op in H. discriminate H. Qed.

Lemma reff14_not3268 : ~ @Equation3268 Fin4 reff14_inst.
Proof. unfold Equation3268. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff14_inst, reff14_op in H. discriminate H. Qed.

Lemma reff14_not3271 : ~ @Equation3271 Fin4 reff14_inst.
Proof. unfold Equation3271. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff14_inst, reff14_op in H. discriminate H. Qed.

Lemma reff14_not3272 : ~ @Equation3272 Fin4 reff14_inst.
Proof. unfold Equation3272. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff14_inst, reff14_op in H. discriminate H. Qed.

Lemma reff14_not3278 : ~ @Equation3278 Fin4 reff14_inst.
Proof. unfold Equation3278. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff14_inst, reff14_op in H. discriminate H. Qed.

Lemma reff14_not3279 : ~ @Equation3279 Fin4 reff14_inst.
Proof. unfold Equation3279. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff14_inst, reff14_op in H. discriminate H. Qed.

Lemma reff14_not3281 : ~ @Equation3281 Fin4 reff14_inst.
Proof. unfold Equation3281. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff14_inst, reff14_op in H. discriminate H. Qed.

Lemma reff14_not3306 : ~ @Equation3306 Fin4 reff14_inst.
Proof. unfold Equation3306. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff14_inst, reff14_op in H. discriminate H. Qed.

Lemma reff14_not3308 : ~ @Equation3308 Fin4 reff14_inst.
Proof. unfold Equation3308. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff14_inst, reff14_op in H. discriminate H. Qed.

Lemma reff14_not3309 : ~ @Equation3309 Fin4 reff14_inst.
Proof. unfold Equation3309. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff14_inst, reff14_op in H. discriminate H. Qed.

Lemma reff14_not3342 : ~ @Equation3342 Fin4 reff14_inst.
Proof. unfold Equation3342. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff14_inst, reff14_op in H. discriminate H. Qed.

Lemma reff14_not3343 : ~ @Equation3343 Fin4 reff14_inst.
Proof. unfold Equation3343. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff14_inst, reff14_op in H. discriminate H. Qed.

Lemma reff14_not3345 : ~ @Equation3345 Fin4 reff14_inst.
Proof. unfold Equation3345. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff14_inst, reff14_op in H. discriminate H. Qed.

Lemma reff14_not3346 : ~ @Equation3346 Fin4 reff14_inst.
Proof. unfold Equation3346. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff14_inst, reff14_op in H. discriminate H. Qed.

Lemma reff14_not3352 : ~ @Equation3352 Fin4 reff14_inst.
Proof. unfold Equation3352. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff14_inst, reff14_op in H. discriminate H. Qed.

Lemma reff14_not3353 : ~ @Equation3353 Fin4 reff14_inst.
Proof. unfold Equation3353. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff14_inst, reff14_op in H. discriminate H. Qed.

Lemma reff14_not3461 : ~ @Equation3461 Fin4 reff14_inst.
Proof. unfold Equation3461. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff14_inst, reff14_op in H. discriminate H. Qed.

Lemma reff14_not3462 : ~ @Equation3462 Fin4 reff14_inst.
Proof. unfold Equation3462. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff14_inst, reff14_op in H. discriminate H. Qed.

Lemma reff14_not3464 : ~ @Equation3464 Fin4 reff14_inst.
Proof. unfold Equation3464. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff14_inst, reff14_op in H. discriminate H. Qed.

Lemma reff14_not3465 : ~ @Equation3465 Fin4 reff14_inst.
Proof. unfold Equation3465. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff14_inst, reff14_op in H. discriminate H. Qed.

Lemma reff14_not3472 : ~ @Equation3472 Fin4 reff14_inst.
Proof. unfold Equation3472. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff14_inst, reff14_op in H. discriminate H. Qed.

Lemma reff14_not3474 : ~ @Equation3474 Fin4 reff14_inst.
Proof. unfold Equation3474. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff14_inst, reff14_op in H. discriminate H. Qed.

Lemma reff14_not3475 : ~ @Equation3475 Fin4 reff14_inst.
Proof. unfold Equation3475. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff14_inst, reff14_op in H. discriminate H. Qed.

Lemma reff14_not3481 : ~ @Equation3481 Fin4 reff14_inst.
Proof. unfold Equation3481. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff14_inst, reff14_op in H. discriminate H. Qed.

Lemma reff14_not3482 : ~ @Equation3482 Fin4 reff14_inst.
Proof. unfold Equation3482. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff14_inst, reff14_op in H. discriminate H. Qed.

Lemma reff14_not3484 : ~ @Equation3484 Fin4 reff14_inst.
Proof. unfold Equation3484. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff14_inst, reff14_op in H. discriminate H. Qed.

Lemma reff14_not3509 : ~ @Equation3509 Fin4 reff14_inst.
Proof. unfold Equation3509. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff14_inst, reff14_op in H. discriminate H. Qed.

Lemma reff14_not3511 : ~ @Equation3511 Fin4 reff14_inst.
Proof. unfold Equation3511. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff14_inst, reff14_op in H. discriminate H. Qed.

Lemma reff14_not3512 : ~ @Equation3512 Fin4 reff14_inst.
Proof. unfold Equation3512. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff14_inst, reff14_op in H. discriminate H. Qed.

Lemma reff14_not3545 : ~ @Equation3545 Fin4 reff14_inst.
Proof. unfold Equation3545. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff14_inst, reff14_op in H. discriminate H. Qed.

Lemma reff14_not3546 : ~ @Equation3546 Fin4 reff14_inst.
Proof. unfold Equation3546. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff14_inst, reff14_op in H. discriminate H. Qed.

Lemma reff14_not3548 : ~ @Equation3548 Fin4 reff14_inst.
Proof. unfold Equation3548. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff14_inst, reff14_op in H. discriminate H. Qed.

Lemma reff14_not3549 : ~ @Equation3549 Fin4 reff14_inst.
Proof. unfold Equation3549. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff14_inst, reff14_op in H. discriminate H. Qed.

Lemma reff14_not3555 : ~ @Equation3555 Fin4 reff14_inst.
Proof. unfold Equation3555. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff14_inst, reff14_op in H. discriminate H. Qed.

Lemma reff14_not3556 : ~ @Equation3556 Fin4 reff14_inst.
Proof. unfold Equation3556. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff14_inst, reff14_op in H. discriminate H. Qed.

Lemma reff14_not3558 : ~ @Equation3558 Fin4 reff14_inst.
Proof. unfold Equation3558. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff14_inst, reff14_op in H. discriminate H. Qed.

Lemma reff14_not3659 : ~ @Equation3659 Fin4 reff14_inst.
Proof. unfold Equation3659. intro H. specialize (H F4_1). unfold magma_op, reff14_inst, reff14_op in H. discriminate H. Qed.

Lemma reff14_not3862 : ~ @Equation3862 Fin4 reff14_inst.
Proof. unfold Equation3862. intro H. specialize (H F4_1). unfold magma_op, reff14_inst, reff14_op in H. discriminate H. Qed.

Lemma reff14_not4066 : ~ @Equation4066 Fin4 reff14_inst.
Proof. unfold Equation4066. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff14_inst, reff14_op in H. discriminate H. Qed.

Lemma reff14_not4067 : ~ @Equation4067 Fin4 reff14_inst.
Proof. unfold Equation4067. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff14_inst, reff14_op in H. discriminate H. Qed.

Lemma reff14_not4070 : ~ @Equation4070 Fin4 reff14_inst.
Proof. unfold Equation4070. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff14_inst, reff14_op in H. discriminate H. Qed.

Lemma reff14_not4074 : ~ @Equation4074 Fin4 reff14_inst.
Proof. unfold Equation4074. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff14_inst, reff14_op in H. discriminate H. Qed.

Lemma reff14_not4080 : ~ @Equation4080 Fin4 reff14_inst.
Proof. unfold Equation4080. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff14_inst, reff14_op in H. discriminate H. Qed.

Lemma reff14_not4083 : ~ @Equation4083 Fin4 reff14_inst.
Proof. unfold Equation4083. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff14_inst, reff14_op in H. discriminate H. Qed.

Lemma reff14_not4084 : ~ @Equation4084 Fin4 reff14_inst.
Proof. unfold Equation4084. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff14_inst, reff14_op in H. discriminate H. Qed.

Lemma reff14_not4090 : ~ @Equation4090 Fin4 reff14_inst.
Proof. unfold Equation4090. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff14_inst, reff14_op in H. discriminate H. Qed.

Lemma reff14_not4091 : ~ @Equation4091 Fin4 reff14_inst.
Proof. unfold Equation4091. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff14_inst, reff14_op in H. discriminate H. Qed.

Lemma reff14_not4093 : ~ @Equation4093 Fin4 reff14_inst.
Proof. unfold Equation4093. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff14_inst, reff14_op in H. discriminate H. Qed.

Lemma reff14_not4121 : ~ @Equation4121 Fin4 reff14_inst.
Proof. unfold Equation4121. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff14_inst, reff14_op in H. discriminate H. Qed.

Lemma reff14_not4128 : ~ @Equation4128 Fin4 reff14_inst.
Proof. unfold Equation4128. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff14_inst, reff14_op in H. discriminate H. Qed.

Lemma reff14_not4130 : ~ @Equation4130 Fin4 reff14_inst.
Proof. unfold Equation4130. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff14_inst, reff14_op in H. discriminate H. Qed.

Lemma reff14_not4155 : ~ @Equation4155 Fin4 reff14_inst.
Proof. unfold Equation4155. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff14_inst, reff14_op in H. discriminate H. Qed.

Lemma reff14_not4157 : ~ @Equation4157 Fin4 reff14_inst.
Proof. unfold Equation4157. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff14_inst, reff14_op in H. discriminate H. Qed.

Lemma reff14_not4158 : ~ @Equation4158 Fin4 reff14_inst.
Proof. unfold Equation4158. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff14_inst, reff14_op in H. discriminate H. Qed.

Lemma reff14_not4164 : ~ @Equation4164 Fin4 reff14_inst.
Proof. unfold Equation4164. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff14_inst, reff14_op in H. discriminate H. Qed.

Lemma reff14_not4165 : ~ @Equation4165 Fin4 reff14_inst.
Proof. unfold Equation4165. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff14_inst, reff14_op in H. discriminate H. Qed.

Lemma reff14_not4167 : ~ @Equation4167 Fin4 reff14_inst.
Proof. unfold Equation4167. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff14_inst, reff14_op in H. discriminate H. Qed.

Lemma reff14_not4269 : ~ @Equation4269 Fin4 reff14_inst.
Proof. unfold Equation4269. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff14_inst, reff14_op in H. discriminate H. Qed.

Lemma reff14_not4270 : ~ @Equation4270 Fin4 reff14_inst.
Proof. unfold Equation4270. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff14_inst, reff14_op in H. discriminate H. Qed.

Lemma reff14_not4272 : ~ @Equation4272 Fin4 reff14_inst.
Proof. unfold Equation4272. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff14_inst, reff14_op in H. discriminate H. Qed.

Lemma reff14_not4273 : ~ @Equation4273 Fin4 reff14_inst.
Proof. unfold Equation4273. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff14_inst, reff14_op in H. discriminate H. Qed.

Lemma reff14_not4275 : ~ @Equation4275 Fin4 reff14_inst.
Proof. unfold Equation4275. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff14_inst, reff14_op in H. discriminate H. Qed.

Lemma reff14_not4276 : ~ @Equation4276 Fin4 reff14_inst.
Proof. unfold Equation4276. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff14_inst, reff14_op in H. discriminate H. Qed.

Lemma reff14_not4283 : ~ @Equation4283 Fin4 reff14_inst.
Proof. unfold Equation4283. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff14_inst, reff14_op in H. discriminate H. Qed.

Lemma reff14_not4284 : ~ @Equation4284 Fin4 reff14_inst.
Proof. unfold Equation4284. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff14_inst, reff14_op in H. discriminate H. Qed.

Lemma reff14_not4290 : ~ @Equation4290 Fin4 reff14_inst.
Proof. unfold Equation4290. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff14_inst, reff14_op in H. discriminate H. Qed.

Lemma reff14_not4291 : ~ @Equation4291 Fin4 reff14_inst.
Proof. unfold Equation4291. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff14_inst, reff14_op in H. discriminate H. Qed.

Lemma reff14_not4293 : ~ @Equation4293 Fin4 reff14_inst.
Proof. unfold Equation4293. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff14_inst, reff14_op in H. discriminate H. Qed.

Lemma reff14_not4320 : ~ @Equation4320 Fin4 reff14_inst.
Proof. unfold Equation4320. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff14_inst, reff14_op in H. discriminate H. Qed.

Lemma reff14_not4321 : ~ @Equation4321 Fin4 reff14_inst.
Proof. unfold Equation4321. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff14_inst, reff14_op in H. discriminate H. Qed.

Lemma reff14_not4343 : ~ @Equation4343 Fin4 reff14_inst.
Proof. unfold Equation4343. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff14_inst, reff14_op in H. discriminate H. Qed.

Lemma reff14_not4380 : ~ @Equation4380 Fin4 reff14_inst.
Proof. unfold Equation4380. intro H. specialize (H F4_1). unfold magma_op, reff14_inst, reff14_op in H. discriminate H. Qed.

Lemma reff14_not4583 : ~ @Equation4583 Fin4 reff14_inst.
Proof. unfold Equation4583. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff14_inst, reff14_op in H. discriminate H. Qed.

Lemma reff14_not4584 : ~ @Equation4584 Fin4 reff14_inst.
Proof. unfold Equation4584. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff14_inst, reff14_op in H. discriminate H. Qed.

Lemma reff14_not4587 : ~ @Equation4587 Fin4 reff14_inst.
Proof. unfold Equation4587. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff14_inst, reff14_op in H. discriminate H. Qed.

Lemma reff14_not4588 : ~ @Equation4588 Fin4 reff14_inst.
Proof. unfold Equation4588. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff14_inst, reff14_op in H. discriminate H. Qed.

Lemma reff14_not4590 : ~ @Equation4590 Fin4 reff14_inst.
Proof. unfold Equation4590. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff14_inst, reff14_op in H. discriminate H. Qed.

Lemma reff14_not4591 : ~ @Equation4591 Fin4 reff14_inst.
Proof. unfold Equation4591. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff14_inst, reff14_op in H. discriminate H. Qed.

Lemma reff14_not4599 : ~ @Equation4599 Fin4 reff14_inst.
Proof. unfold Equation4599. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff14_inst, reff14_op in H. discriminate H. Qed.

Lemma reff14_not4605 : ~ @Equation4605 Fin4 reff14_inst.
Proof. unfold Equation4605. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff14_inst, reff14_op in H. discriminate H. Qed.

Lemma reff14_not4606 : ~ @Equation4606 Fin4 reff14_inst.
Proof. unfold Equation4606. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff14_inst, reff14_op in H. discriminate H. Qed.

Lemma reff14_not4608 : ~ @Equation4608 Fin4 reff14_inst.
Proof. unfold Equation4608. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff14_inst, reff14_op in H. discriminate H. Qed.

Lemma reff14_not4629 : ~ @Equation4629 Fin4 reff14_inst.
Proof. unfold Equation4629. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff14_inst, reff14_op in H. discriminate H. Qed.

Lemma reff14_not4635 : ~ @Equation4635 Fin4 reff14_inst.
Proof. unfold Equation4635. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff14_inst, reff14_op in H. discriminate H. Qed.

Lemma reff14_not4636 : ~ @Equation4636 Fin4 reff14_inst.
Proof. unfold Equation4636. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff14_inst, reff14_op in H. discriminate H. Qed.

Lemma reff14_not4658 : ~ @Equation4658 Fin4 reff14_inst.
Proof. unfold Equation4658. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff14_inst, reff14_op in H. discriminate H. Qed.
