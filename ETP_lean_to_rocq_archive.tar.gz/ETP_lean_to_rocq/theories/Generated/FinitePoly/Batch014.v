(** * FinitePoly counterexamples — batch 14
    Auto-generated from Lean4 FinitePoly files. *)

From Stdlib Require Import Utf8.

From ETP Require Import Magma.
From ETP Require Import FinMagma.
From ETP.Equations Require Import All.

Open Scope magma_scope.

(** ---- reff94 (Fin4) ---- *)

Definition reff94_op (x y : Fin4) : Fin4 :=
  match x, y with
  | F4_0, F4_0 => F4_0 | F4_0, F4_1 => F4_0 | F4_0, F4_2 => F4_0 | F4_0, F4_3 => F4_0
  | F4_1, F4_0 => F4_0 | F4_1, F4_1 => F4_3 | F4_1, F4_2 => F4_2 | F4_1, F4_3 => F4_1
  | F4_2, F4_0 => F4_0 | F4_2, F4_1 => F4_2 | F4_2, F4_2 => F4_0 | F4_2, F4_3 => F4_2
  | F4_3, F4_0 => F4_0 | F4_3, F4_1 => F4_1 | F4_3, F4_2 => F4_2 | F4_3, F4_3 => F4_3
  end.

#[local] Instance reff94_inst : Magma Fin4 := {| magma_op := reff94_op |}.

Lemma reff94_sat43 : @Equation43 Fin4 reff94_inst.
Proof. unfold Equation43, magma_op, reff94_inst, reff94_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff94_sat3253 : @Equation3253 Fin4 reff94_inst.
Proof. unfold Equation3253, magma_op, reff94_inst, reff94_op. intros x. destruct x; reflexivity. Qed.

Lemma reff94_sat3456 : @Equation3456 Fin4 reff94_inst.
Proof. unfold Equation3456, magma_op, reff94_inst, reff94_op. intros x. destruct x; reflexivity. Qed.

Lemma reff94_sat3659 : @Equation3659 Fin4 reff94_inst.
Proof. unfold Equation3659, magma_op, reff94_inst, reff94_op. intros x. destruct x; reflexivity. Qed.

Lemma reff94_sat3862 : @Equation3862 Fin4 reff94_inst.
Proof. unfold Equation3862, magma_op, reff94_inst, reff94_op. intros x. destruct x; reflexivity. Qed.

Lemma reff94_sat4065 : @Equation4065 Fin4 reff94_inst.
Proof. unfold Equation4065, magma_op, reff94_inst, reff94_op. intros x. destruct x; reflexivity. Qed.

Lemma reff94_sat4362 : @Equation4362 Fin4 reff94_inst.
Proof. unfold Equation4362, magma_op, reff94_inst, reff94_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff94_sat4364 : @Equation4364 Fin4 reff94_inst.
Proof. unfold Equation4364, magma_op, reff94_inst, reff94_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff94_sat4369 : @Equation4369 Fin4 reff94_inst.
Proof. unfold Equation4369, magma_op, reff94_inst, reff94_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff94_sat4512 : @Equation4512 Fin4 reff94_inst.
Proof. unfold Equation4512, magma_op, reff94_inst, reff94_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff94_sat4515 : @Equation4515 Fin4 reff94_inst.
Proof. unfold Equation4515, magma_op, reff94_inst, reff94_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff94_sat4525 : @Equation4525 Fin4 reff94_inst.
Proof. unfold Equation4525, magma_op, reff94_inst, reff94_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff94_sat4541 : @Equation4541 Fin4 reff94_inst.
Proof. unfold Equation4541, magma_op, reff94_inst, reff94_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff94_sat4673 : @Equation4673 Fin4 reff94_inst.
Proof. unfold Equation4673, magma_op, reff94_inst, reff94_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff94_sat4679 : @Equation4679 Fin4 reff94_inst.
Proof. unfold Equation4679, magma_op, reff94_inst, reff94_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff94_sat4684 : @Equation4684 Fin4 reff94_inst.
Proof. unfold Equation4684, magma_op, reff94_inst, reff94_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff94_not47 : ~ @Equation47 Fin4 reff94_inst.
Proof. unfold Equation47. intro H. specialize (H F4_1). unfold magma_op, reff94_inst, reff94_op in H. discriminate H. Qed.

Lemma reff94_not99 : ~ @Equation99 Fin4 reff94_inst.
Proof. unfold Equation99. intro H. specialize (H F4_1). unfold magma_op, reff94_inst, reff94_op in H. discriminate H. Qed.

Lemma reff94_not151 : ~ @Equation151 Fin4 reff94_inst.
Proof. unfold Equation151. intro H. specialize (H F4_1). unfold magma_op, reff94_inst, reff94_op in H. discriminate H. Qed.

Lemma reff94_not203 : ~ @Equation203 Fin4 reff94_inst.
Proof. unfold Equation203. intro H. specialize (H F4_1). unfold magma_op, reff94_inst, reff94_op in H. discriminate H. Qed.

Lemma reff94_not255 : ~ @Equation255 Fin4 reff94_inst.
Proof. unfold Equation255. intro H. specialize (H F4_1). unfold magma_op, reff94_inst, reff94_op in H. discriminate H. Qed.

Lemma reff94_not307 : ~ @Equation307 Fin4 reff94_inst.
Proof. unfold Equation307. intro H. specialize (H F4_1). unfold magma_op, reff94_inst, reff94_op in H. discriminate H. Qed.

Lemma reff94_not359 : ~ @Equation359 Fin4 reff94_inst.
Proof. unfold Equation359. intro H. specialize (H F4_1). unfold magma_op, reff94_inst, reff94_op in H. discriminate H. Qed.

Lemma reff94_not411 : ~ @Equation411 Fin4 reff94_inst.
Proof. unfold Equation411. intro H. specialize (H F4_2). unfold magma_op, reff94_inst, reff94_op in H. discriminate H. Qed.

Lemma reff94_not614 : ~ @Equation614 Fin4 reff94_inst.
Proof. unfold Equation614. intro H. specialize (H F4_2). unfold magma_op, reff94_inst, reff94_op in H. discriminate H. Qed.

Lemma reff94_not817 : ~ @Equation817 Fin4 reff94_inst.
Proof. unfold Equation817. intro H. specialize (H F4_2). unfold magma_op, reff94_inst, reff94_op in H. discriminate H. Qed.

Lemma reff94_not1020 : ~ @Equation1020 Fin4 reff94_inst.
Proof. unfold Equation1020. intro H. specialize (H F4_2). unfold magma_op, reff94_inst, reff94_op in H. discriminate H. Qed.

Lemma reff94_not1223 : ~ @Equation1223 Fin4 reff94_inst.
Proof. unfold Equation1223. intro H. specialize (H F4_2). unfold magma_op, reff94_inst, reff94_op in H. discriminate H. Qed.

Lemma reff94_not1426 : ~ @Equation1426 Fin4 reff94_inst.
Proof. unfold Equation1426. intro H. specialize (H F4_2). unfold magma_op, reff94_inst, reff94_op in H. discriminate H. Qed.

Lemma reff94_not1629 : ~ @Equation1629 Fin4 reff94_inst.
Proof. unfold Equation1629. intro H. specialize (H F4_2). unfold magma_op, reff94_inst, reff94_op in H. discriminate H. Qed.

Lemma reff94_not1832 : ~ @Equation1832 Fin4 reff94_inst.
Proof. unfold Equation1832. intro H. specialize (H F4_2). unfold magma_op, reff94_inst, reff94_op in H. discriminate H. Qed.

Lemma reff94_not2035 : ~ @Equation2035 Fin4 reff94_inst.
Proof. unfold Equation2035. intro H. specialize (H F4_2). unfold magma_op, reff94_inst, reff94_op in H. discriminate H. Qed.

Lemma reff94_not2238 : ~ @Equation2238 Fin4 reff94_inst.
Proof. unfold Equation2238. intro H. specialize (H F4_2). unfold magma_op, reff94_inst, reff94_op in H. discriminate H. Qed.

Lemma reff94_not2441 : ~ @Equation2441 Fin4 reff94_inst.
Proof. unfold Equation2441. intro H. specialize (H F4_2). unfold magma_op, reff94_inst, reff94_op in H. discriminate H. Qed.

Lemma reff94_not2644 : ~ @Equation2644 Fin4 reff94_inst.
Proof. unfold Equation2644. intro H. specialize (H F4_2). unfold magma_op, reff94_inst, reff94_op in H. discriminate H. Qed.

Lemma reff94_not2847 : ~ @Equation2847 Fin4 reff94_inst.
Proof. unfold Equation2847. intro H. specialize (H F4_2). unfold magma_op, reff94_inst, reff94_op in H. discriminate H. Qed.

Lemma reff94_not3050 : ~ @Equation3050 Fin4 reff94_inst.
Proof. unfold Equation3050. intro H. specialize (H F4_2). unfold magma_op, reff94_inst, reff94_op in H. discriminate H. Qed.

Lemma reff94_not3254 : ~ @Equation3254 Fin4 reff94_inst.
Proof. unfold Equation3254. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff94_inst, reff94_op in H. discriminate H. Qed.

Lemma reff94_not3255 : ~ @Equation3255 Fin4 reff94_inst.
Proof. unfold Equation3255. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff94_inst, reff94_op in H. discriminate H. Qed.

Lemma reff94_not3256 : ~ @Equation3256 Fin4 reff94_inst.
Proof. unfold Equation3256. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff94_inst, reff94_op in H. discriminate H. Qed.

Lemma reff94_not3258 : ~ @Equation3258 Fin4 reff94_inst.
Proof. unfold Equation3258. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff94_inst, reff94_op in H. discriminate H. Qed.

Lemma reff94_not3259 : ~ @Equation3259 Fin4 reff94_inst.
Proof. unfold Equation3259. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff94_inst, reff94_op in H. discriminate H. Qed.

Lemma reff94_not3261 : ~ @Equation3261 Fin4 reff94_inst.
Proof. unfold Equation3261. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff94_inst, reff94_op in H. discriminate H. Qed.

Lemma reff94_not3262 : ~ @Equation3262 Fin4 reff94_inst.
Proof. unfold Equation3262. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff94_inst, reff94_op in H. discriminate H. Qed.

Lemma reff94_not3268 : ~ @Equation3268 Fin4 reff94_inst.
Proof. unfold Equation3268. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff94_inst, reff94_op in H. discriminate H. Qed.

Lemma reff94_not3269 : ~ @Equation3269 Fin4 reff94_inst.
Proof. unfold Equation3269. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff94_inst, reff94_op in H. discriminate H. Qed.

Lemma reff94_not3271 : ~ @Equation3271 Fin4 reff94_inst.
Proof. unfold Equation3271. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff94_inst, reff94_op in H. discriminate H. Qed.

Lemma reff94_not3272 : ~ @Equation3272 Fin4 reff94_inst.
Proof. unfold Equation3272. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff94_inst, reff94_op in H. discriminate H. Qed.

Lemma reff94_not3278 : ~ @Equation3278 Fin4 reff94_inst.
Proof. unfold Equation3278. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff94_inst, reff94_op in H. discriminate H. Qed.

Lemma reff94_not3279 : ~ @Equation3279 Fin4 reff94_inst.
Proof. unfold Equation3279. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff94_inst, reff94_op in H. discriminate H. Qed.

Lemma reff94_not3281 : ~ @Equation3281 Fin4 reff94_inst.
Proof. unfold Equation3281. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff94_inst, reff94_op in H. discriminate H. Qed.

Lemma reff94_not3306 : ~ @Equation3306 Fin4 reff94_inst.
Proof. unfold Equation3306. intro H. specialize (H F4_2 F4_1). unfold magma_op, reff94_inst, reff94_op in H. discriminate H. Qed.

Lemma reff94_not3308 : ~ @Equation3308 Fin4 reff94_inst.
Proof. unfold Equation3308. intro H. specialize (H F4_2 F4_1). unfold magma_op, reff94_inst, reff94_op in H. discriminate H. Qed.

Lemma reff94_not3309 : ~ @Equation3309 Fin4 reff94_inst.
Proof. unfold Equation3309. intro H. specialize (H F4_1 F4_2). unfold magma_op, reff94_inst, reff94_op in H. discriminate H. Qed.

Lemma reff94_not3315 : ~ @Equation3315 Fin4 reff94_inst.
Proof. unfold Equation3315. intro H. specialize (H F4_2 F4_1). unfold magma_op, reff94_inst, reff94_op in H. discriminate H. Qed.

Lemma reff94_not3316 : ~ @Equation3316 Fin4 reff94_inst.
Proof. unfold Equation3316. intro H. specialize (H F4_1 F4_2). unfold magma_op, reff94_inst, reff94_op in H. discriminate H. Qed.

Lemma reff94_not3318 : ~ @Equation3318 Fin4 reff94_inst.
Proof. unfold Equation3318. intro H. specialize (H F4_1 F4_2). unfold magma_op, reff94_inst, reff94_op in H. discriminate H. Qed.

Lemma reff94_not3319 : ~ @Equation3319 Fin4 reff94_inst.
Proof. unfold Equation3319. intro H. specialize (H F4_1 F4_2). unfold magma_op, reff94_inst, reff94_op in H. discriminate H. Qed.

Lemma reff94_not3342 : ~ @Equation3342 Fin4 reff94_inst.
Proof. unfold Equation3342. intro H. specialize (H F4_2 F4_1). unfold magma_op, reff94_inst, reff94_op in H. discriminate H. Qed.

Lemma reff94_not3343 : ~ @Equation3343 Fin4 reff94_inst.
Proof. unfold Equation3343. intro H. specialize (H F4_1 F4_2). unfold magma_op, reff94_inst, reff94_op in H. discriminate H. Qed.

Lemma reff94_not3345 : ~ @Equation3345 Fin4 reff94_inst.
Proof. unfold Equation3345. intro H. specialize (H F4_1 F4_2). unfold magma_op, reff94_inst, reff94_op in H. discriminate H. Qed.

Lemma reff94_not3346 : ~ @Equation3346 Fin4 reff94_inst.
Proof. unfold Equation3346. intro H. specialize (H F4_1 F4_2). unfold magma_op, reff94_inst, reff94_op in H. discriminate H. Qed.

Lemma reff94_not3352 : ~ @Equation3352 Fin4 reff94_inst.
Proof. unfold Equation3352. intro H. specialize (H F4_1 F4_2). unfold magma_op, reff94_inst, reff94_op in H. discriminate H. Qed.

Lemma reff94_not3353 : ~ @Equation3353 Fin4 reff94_inst.
Proof. unfold Equation3353. intro H. specialize (H F4_1 F4_2). unfold magma_op, reff94_inst, reff94_op in H. discriminate H. Qed.

Lemma reff94_not3355 : ~ @Equation3355 Fin4 reff94_inst.
Proof. unfold Equation3355. intro H. specialize (H F4_1 F4_2). unfold magma_op, reff94_inst, reff94_op in H. discriminate H. Qed.

Lemma reff94_not3457 : ~ @Equation3457 Fin4 reff94_inst.
Proof. unfold Equation3457. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff94_inst, reff94_op in H. discriminate H. Qed.

Lemma reff94_not3458 : ~ @Equation3458 Fin4 reff94_inst.
Proof. unfold Equation3458. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff94_inst, reff94_op in H. discriminate H. Qed.

Lemma reff94_not3459 : ~ @Equation3459 Fin4 reff94_inst.
Proof. unfold Equation3459. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff94_inst, reff94_op in H. discriminate H. Qed.

Lemma reff94_not3461 : ~ @Equation3461 Fin4 reff94_inst.
Proof. unfold Equation3461. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff94_inst, reff94_op in H. discriminate H. Qed.

Lemma reff94_not3462 : ~ @Equation3462 Fin4 reff94_inst.
Proof. unfold Equation3462. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff94_inst, reff94_op in H. discriminate H. Qed.

Lemma reff94_not3464 : ~ @Equation3464 Fin4 reff94_inst.
Proof. unfold Equation3464. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff94_inst, reff94_op in H. discriminate H. Qed.

Lemma reff94_not3465 : ~ @Equation3465 Fin4 reff94_inst.
Proof. unfold Equation3465. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff94_inst, reff94_op in H. discriminate H. Qed.

Lemma reff94_not3472 : ~ @Equation3472 Fin4 reff94_inst.
Proof. unfold Equation3472. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff94_inst, reff94_op in H. discriminate H. Qed.

Lemma reff94_not3474 : ~ @Equation3474 Fin4 reff94_inst.
Proof. unfold Equation3474. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff94_inst, reff94_op in H. discriminate H. Qed.

Lemma reff94_not3475 : ~ @Equation3475 Fin4 reff94_inst.
Proof. unfold Equation3475. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff94_inst, reff94_op in H. discriminate H. Qed.

Lemma reff94_not3481 : ~ @Equation3481 Fin4 reff94_inst.
Proof. unfold Equation3481. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff94_inst, reff94_op in H. discriminate H. Qed.

Lemma reff94_not3482 : ~ @Equation3482 Fin4 reff94_inst.
Proof. unfold Equation3482. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff94_inst, reff94_op in H. discriminate H. Qed.

Lemma reff94_not3484 : ~ @Equation3484 Fin4 reff94_inst.
Proof. unfold Equation3484. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff94_inst, reff94_op in H. discriminate H. Qed.

Lemma reff94_not3509 : ~ @Equation3509 Fin4 reff94_inst.
Proof. unfold Equation3509. intro H. specialize (H F4_2 F4_1). unfold magma_op, reff94_inst, reff94_op in H. discriminate H. Qed.

Lemma reff94_not3511 : ~ @Equation3511 Fin4 reff94_inst.
Proof. unfold Equation3511. intro H. specialize (H F4_2 F4_1). unfold magma_op, reff94_inst, reff94_op in H. discriminate H. Qed.

Lemma reff94_not3512 : ~ @Equation3512 Fin4 reff94_inst.
Proof. unfold Equation3512. intro H. specialize (H F4_1 F4_2). unfold magma_op, reff94_inst, reff94_op in H. discriminate H. Qed.

Lemma reff94_not3518 : ~ @Equation3518 Fin4 reff94_inst.
Proof. unfold Equation3518. intro H. specialize (H F4_2 F4_1). unfold magma_op, reff94_inst, reff94_op in H. discriminate H. Qed.

Lemma reff94_not3519 : ~ @Equation3519 Fin4 reff94_inst.
Proof. unfold Equation3519. intro H. specialize (H F4_1 F4_2). unfold magma_op, reff94_inst, reff94_op in H. discriminate H. Qed.

Lemma reff94_not3521 : ~ @Equation3521 Fin4 reff94_inst.
Proof. unfold Equation3521. intro H. specialize (H F4_1 F4_2). unfold magma_op, reff94_inst, reff94_op in H. discriminate H. Qed.

Lemma reff94_not3522 : ~ @Equation3522 Fin4 reff94_inst.
Proof. unfold Equation3522. intro H. specialize (H F4_1 F4_2). unfold magma_op, reff94_inst, reff94_op in H. discriminate H. Qed.

Lemma reff94_not3545 : ~ @Equation3545 Fin4 reff94_inst.
Proof. unfold Equation3545. intro H. specialize (H F4_2 F4_1). unfold magma_op, reff94_inst, reff94_op in H. discriminate H. Qed.

Lemma reff94_not3546 : ~ @Equation3546 Fin4 reff94_inst.
Proof. unfold Equation3546. intro H. specialize (H F4_1 F4_2). unfold magma_op, reff94_inst, reff94_op in H. discriminate H. Qed.

Lemma reff94_not3548 : ~ @Equation3548 Fin4 reff94_inst.
Proof. unfold Equation3548. intro H. specialize (H F4_1 F4_2). unfold magma_op, reff94_inst, reff94_op in H. discriminate H. Qed.

Lemma reff94_not3549 : ~ @Equation3549 Fin4 reff94_inst.
Proof. unfold Equation3549. intro H. specialize (H F4_1 F4_2). unfold magma_op, reff94_inst, reff94_op in H. discriminate H. Qed.

Lemma reff94_not3555 : ~ @Equation3555 Fin4 reff94_inst.
Proof. unfold Equation3555. intro H. specialize (H F4_1 F4_2). unfold magma_op, reff94_inst, reff94_op in H. discriminate H. Qed.

Lemma reff94_not3556 : ~ @Equation3556 Fin4 reff94_inst.
Proof. unfold Equation3556. intro H. specialize (H F4_1 F4_2). unfold magma_op, reff94_inst, reff94_op in H. discriminate H. Qed.

Lemma reff94_not3558 : ~ @Equation3558 Fin4 reff94_inst.
Proof. unfold Equation3558. intro H. specialize (H F4_1 F4_2). unfold magma_op, reff94_inst, reff94_op in H. discriminate H. Qed.

Lemma reff94_not3660 : ~ @Equation3660 Fin4 reff94_inst.
Proof. unfold Equation3660. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff94_inst, reff94_op in H. discriminate H. Qed.

Lemma reff94_not3661 : ~ @Equation3661 Fin4 reff94_inst.
Proof. unfold Equation3661. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff94_inst, reff94_op in H. discriminate H. Qed.

Lemma reff94_not3662 : ~ @Equation3662 Fin4 reff94_inst.
Proof. unfold Equation3662. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff94_inst, reff94_op in H. discriminate H. Qed.

Lemma reff94_not3664 : ~ @Equation3664 Fin4 reff94_inst.
Proof. unfold Equation3664. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff94_inst, reff94_op in H. discriminate H. Qed.

Lemma reff94_not3665 : ~ @Equation3665 Fin4 reff94_inst.
Proof. unfold Equation3665. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff94_inst, reff94_op in H. discriminate H. Qed.

Lemma reff94_not3667 : ~ @Equation3667 Fin4 reff94_inst.
Proof. unfold Equation3667. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff94_inst, reff94_op in H. discriminate H. Qed.

Lemma reff94_not3668 : ~ @Equation3668 Fin4 reff94_inst.
Proof. unfold Equation3668. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff94_inst, reff94_op in H. discriminate H. Qed.

Lemma reff94_not3674 : ~ @Equation3674 Fin4 reff94_inst.
Proof. unfold Equation3674. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff94_inst, reff94_op in H. discriminate H. Qed.

Lemma reff94_not3675 : ~ @Equation3675 Fin4 reff94_inst.
Proof. unfold Equation3675. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff94_inst, reff94_op in H. discriminate H. Qed.

Lemma reff94_not3677 : ~ @Equation3677 Fin4 reff94_inst.
Proof. unfold Equation3677. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff94_inst, reff94_op in H. discriminate H. Qed.

Lemma reff94_not3678 : ~ @Equation3678 Fin4 reff94_inst.
Proof. unfold Equation3678. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff94_inst, reff94_op in H. discriminate H. Qed.

Lemma reff94_not3684 : ~ @Equation3684 Fin4 reff94_inst.
Proof. unfold Equation3684. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff94_inst, reff94_op in H. discriminate H. Qed.

Lemma reff94_not3685 : ~ @Equation3685 Fin4 reff94_inst.
Proof. unfold Equation3685. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff94_inst, reff94_op in H. discriminate H. Qed.

Lemma reff94_not3687 : ~ @Equation3687 Fin4 reff94_inst.
Proof. unfold Equation3687. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff94_inst, reff94_op in H. discriminate H. Qed.

Lemma reff94_not3712 : ~ @Equation3712 Fin4 reff94_inst.
Proof. unfold Equation3712. intro H. specialize (H F4_2 F4_1). unfold magma_op, reff94_inst, reff94_op in H. discriminate H. Qed.

Lemma reff94_not3714 : ~ @Equation3714 Fin4 reff94_inst.
Proof. unfold Equation3714. intro H. specialize (H F4_2 F4_1). unfold magma_op, reff94_inst, reff94_op in H. discriminate H. Qed.

Lemma reff94_not3721 : ~ @Equation3721 Fin4 reff94_inst.
Proof. unfold Equation3721. intro H. specialize (H F4_2 F4_1). unfold magma_op, reff94_inst, reff94_op in H. discriminate H. Qed.

Lemma reff94_not3722 : ~ @Equation3722 Fin4 reff94_inst.
Proof. unfold Equation3722. intro H. specialize (H F4_1 F4_2). unfold magma_op, reff94_inst, reff94_op in H. discriminate H. Qed.

Lemma reff94_not3724 : ~ @Equation3724 Fin4 reff94_inst.
Proof. unfold Equation3724. intro H. specialize (H F4_1 F4_2). unfold magma_op, reff94_inst, reff94_op in H. discriminate H. Qed.

Lemma reff94_not3725 : ~ @Equation3725 Fin4 reff94_inst.
Proof. unfold Equation3725. intro H. specialize (H F4_1 F4_2). unfold magma_op, reff94_inst, reff94_op in H. discriminate H. Qed.

Lemma reff94_not3748 : ~ @Equation3748 Fin4 reff94_inst.
Proof. unfold Equation3748. intro H. specialize (H F4_2 F4_1). unfold magma_op, reff94_inst, reff94_op in H. discriminate H. Qed.

Lemma reff94_not3749 : ~ @Equation3749 Fin4 reff94_inst.
Proof. unfold Equation3749. intro H. specialize (H F4_1 F4_2). unfold magma_op, reff94_inst, reff94_op in H. discriminate H. Qed.

Lemma reff94_not3751 : ~ @Equation3751 Fin4 reff94_inst.
Proof. unfold Equation3751. intro H. specialize (H F4_1 F4_2). unfold magma_op, reff94_inst, reff94_op in H. discriminate H. Qed.

Lemma reff94_not3752 : ~ @Equation3752 Fin4 reff94_inst.
Proof. unfold Equation3752. intro H. specialize (H F4_1 F4_2). unfold magma_op, reff94_inst, reff94_op in H. discriminate H. Qed.

Lemma reff94_not3759 : ~ @Equation3759 Fin4 reff94_inst.
Proof. unfold Equation3759. intro H. specialize (H F4_1 F4_2). unfold magma_op, reff94_inst, reff94_op in H. discriminate H. Qed.

Lemma reff94_not3761 : ~ @Equation3761 Fin4 reff94_inst.
Proof. unfold Equation3761. intro H. specialize (H F4_1 F4_2). unfold magma_op, reff94_inst, reff94_op in H. discriminate H. Qed.

Lemma reff94_not3864 : ~ @Equation3864 Fin4 reff94_inst.
Proof. unfold Equation3864. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff94_inst, reff94_op in H. discriminate H. Qed.

Lemma reff94_not3865 : ~ @Equation3865 Fin4 reff94_inst.
Proof. unfold Equation3865. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff94_inst, reff94_op in H. discriminate H. Qed.

Lemma reff94_not3867 : ~ @Equation3867 Fin4 reff94_inst.
Proof. unfold Equation3867. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff94_inst, reff94_op in H. discriminate H. Qed.

Lemma reff94_not3868 : ~ @Equation3868 Fin4 reff94_inst.
Proof. unfold Equation3868. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff94_inst, reff94_op in H. discriminate H. Qed.

Lemma reff94_not3870 : ~ @Equation3870 Fin4 reff94_inst.
Proof. unfold Equation3870. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff94_inst, reff94_op in H. discriminate H. Qed.

Lemma reff94_not3871 : ~ @Equation3871 Fin4 reff94_inst.
Proof. unfold Equation3871. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff94_inst, reff94_op in H. discriminate H. Qed.

Lemma reff94_not3877 : ~ @Equation3877 Fin4 reff94_inst.
Proof. unfold Equation3877. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff94_inst, reff94_op in H. discriminate H. Qed.

Lemma reff94_not3878 : ~ @Equation3878 Fin4 reff94_inst.
Proof. unfold Equation3878. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff94_inst, reff94_op in H. discriminate H. Qed.

Lemma reff94_not3880 : ~ @Equation3880 Fin4 reff94_inst.
Proof. unfold Equation3880. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff94_inst, reff94_op in H. discriminate H. Qed.

Lemma reff94_not3881 : ~ @Equation3881 Fin4 reff94_inst.
Proof. unfold Equation3881. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff94_inst, reff94_op in H. discriminate H. Qed.

Lemma reff94_not3887 : ~ @Equation3887 Fin4 reff94_inst.
Proof. unfold Equation3887. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff94_inst, reff94_op in H. discriminate H. Qed.

Lemma reff94_not3888 : ~ @Equation3888 Fin4 reff94_inst.
Proof. unfold Equation3888. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff94_inst, reff94_op in H. discriminate H. Qed.

Lemma reff94_not3890 : ~ @Equation3890 Fin4 reff94_inst.
Proof. unfold Equation3890. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff94_inst, reff94_op in H. discriminate H. Qed.

Lemma reff94_not3915 : ~ @Equation3915 Fin4 reff94_inst.
Proof. unfold Equation3915. intro H. specialize (H F4_2 F4_1). unfold magma_op, reff94_inst, reff94_op in H. discriminate H. Qed.

Lemma reff94_not3917 : ~ @Equation3917 Fin4 reff94_inst.
Proof. unfold Equation3917. intro H. specialize (H F4_2 F4_1). unfold magma_op, reff94_inst, reff94_op in H. discriminate H. Qed.

Lemma reff94_not3918 : ~ @Equation3918 Fin4 reff94_inst.
Proof. unfold Equation3918. intro H. specialize (H F4_1 F4_2). unfold magma_op, reff94_inst, reff94_op in H. discriminate H. Qed.

Lemma reff94_not3924 : ~ @Equation3924 Fin4 reff94_inst.
Proof. unfold Equation3924. intro H. specialize (H F4_2 F4_1). unfold magma_op, reff94_inst, reff94_op in H. discriminate H. Qed.

Lemma reff94_not3925 : ~ @Equation3925 Fin4 reff94_inst.
Proof. unfold Equation3925. intro H. specialize (H F4_1 F4_2). unfold magma_op, reff94_inst, reff94_op in H. discriminate H. Qed.

Lemma reff94_not3927 : ~ @Equation3927 Fin4 reff94_inst.
Proof. unfold Equation3927. intro H. specialize (H F4_1 F4_2). unfold magma_op, reff94_inst, reff94_op in H. discriminate H. Qed.

Lemma reff94_not3928 : ~ @Equation3928 Fin4 reff94_inst.
Proof. unfold Equation3928. intro H. specialize (H F4_1 F4_2). unfold magma_op, reff94_inst, reff94_op in H. discriminate H. Qed.

Lemma reff94_not3951 : ~ @Equation3951 Fin4 reff94_inst.
Proof. unfold Equation3951. intro H. specialize (H F4_2 F4_1). unfold magma_op, reff94_inst, reff94_op in H. discriminate H. Qed.

Lemma reff94_not3952 : ~ @Equation3952 Fin4 reff94_inst.
Proof. unfold Equation3952. intro H. specialize (H F4_1 F4_2). unfold magma_op, reff94_inst, reff94_op in H. discriminate H. Qed.

Lemma reff94_not3954 : ~ @Equation3954 Fin4 reff94_inst.
Proof. unfold Equation3954. intro H. specialize (H F4_1 F4_2). unfold magma_op, reff94_inst, reff94_op in H. discriminate H. Qed.

Lemma reff94_not3955 : ~ @Equation3955 Fin4 reff94_inst.
Proof. unfold Equation3955. intro H. specialize (H F4_1 F4_2). unfold magma_op, reff94_inst, reff94_op in H. discriminate H. Qed.

Lemma reff94_not3961 : ~ @Equation3961 Fin4 reff94_inst.
Proof. unfold Equation3961. intro H. specialize (H F4_1 F4_2). unfold magma_op, reff94_inst, reff94_op in H. discriminate H. Qed.

Lemma reff94_not3962 : ~ @Equation3962 Fin4 reff94_inst.
Proof. unfold Equation3962. intro H. specialize (H F4_1 F4_2). unfold magma_op, reff94_inst, reff94_op in H. discriminate H. Qed.

Lemma reff94_not3964 : ~ @Equation3964 Fin4 reff94_inst.
Proof. unfold Equation3964. intro H. specialize (H F4_1 F4_2). unfold magma_op, reff94_inst, reff94_op in H. discriminate H. Qed.

Lemma reff94_not4066 : ~ @Equation4066 Fin4 reff94_inst.
Proof. unfold Equation4066. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff94_inst, reff94_op in H. discriminate H. Qed.

Lemma reff94_not4067 : ~ @Equation4067 Fin4 reff94_inst.
Proof. unfold Equation4067. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff94_inst, reff94_op in H. discriminate H. Qed.

Lemma reff94_not4068 : ~ @Equation4068 Fin4 reff94_inst.
Proof. unfold Equation4068. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff94_inst, reff94_op in H. discriminate H. Qed.

Lemma reff94_not4070 : ~ @Equation4070 Fin4 reff94_inst.
Proof. unfold Equation4070. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff94_inst, reff94_op in H. discriminate H. Qed.

Lemma reff94_not4071 : ~ @Equation4071 Fin4 reff94_inst.
Proof. unfold Equation4071. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff94_inst, reff94_op in H. discriminate H. Qed.

Lemma reff94_not4073 : ~ @Equation4073 Fin4 reff94_inst.
Proof. unfold Equation4073. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff94_inst, reff94_op in H. discriminate H. Qed.

Lemma reff94_not4074 : ~ @Equation4074 Fin4 reff94_inst.
Proof. unfold Equation4074. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff94_inst, reff94_op in H. discriminate H. Qed.

Lemma reff94_not4080 : ~ @Equation4080 Fin4 reff94_inst.
Proof. unfold Equation4080. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff94_inst, reff94_op in H. discriminate H. Qed.

Lemma reff94_not4081 : ~ @Equation4081 Fin4 reff94_inst.
Proof. unfold Equation4081. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff94_inst, reff94_op in H. discriminate H. Qed.

Lemma reff94_not4083 : ~ @Equation4083 Fin4 reff94_inst.
Proof. unfold Equation4083. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff94_inst, reff94_op in H. discriminate H. Qed.

Lemma reff94_not4084 : ~ @Equation4084 Fin4 reff94_inst.
Proof. unfold Equation4084. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff94_inst, reff94_op in H. discriminate H. Qed.

Lemma reff94_not4090 : ~ @Equation4090 Fin4 reff94_inst.
Proof. unfold Equation4090. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff94_inst, reff94_op in H. discriminate H. Qed.

Lemma reff94_not4091 : ~ @Equation4091 Fin4 reff94_inst.
Proof. unfold Equation4091. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff94_inst, reff94_op in H. discriminate H. Qed.

Lemma reff94_not4093 : ~ @Equation4093 Fin4 reff94_inst.
Proof. unfold Equation4093. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff94_inst, reff94_op in H. discriminate H. Qed.

Lemma reff94_not4118 : ~ @Equation4118 Fin4 reff94_inst.
Proof. unfold Equation4118. intro H. specialize (H F4_2 F4_1). unfold magma_op, reff94_inst, reff94_op in H. discriminate H. Qed.

Lemma reff94_not4120 : ~ @Equation4120 Fin4 reff94_inst.
Proof. unfold Equation4120. intro H. specialize (H F4_2 F4_1). unfold magma_op, reff94_inst, reff94_op in H. discriminate H. Qed.

Lemma reff94_not4121 : ~ @Equation4121 Fin4 reff94_inst.
Proof. unfold Equation4121. intro H. specialize (H F4_1 F4_2). unfold magma_op, reff94_inst, reff94_op in H. discriminate H. Qed.

Lemma reff94_not4127 : ~ @Equation4127 Fin4 reff94_inst.
Proof. unfold Equation4127. intro H. specialize (H F4_2 F4_1). unfold magma_op, reff94_inst, reff94_op in H. discriminate H. Qed.

Lemma reff94_not4128 : ~ @Equation4128 Fin4 reff94_inst.
Proof. unfold Equation4128. intro H. specialize (H F4_1 F4_2). unfold magma_op, reff94_inst, reff94_op in H. discriminate H. Qed.

Lemma reff94_not4130 : ~ @Equation4130 Fin4 reff94_inst.
Proof. unfold Equation4130. intro H. specialize (H F4_1 F4_2). unfold magma_op, reff94_inst, reff94_op in H. discriminate H. Qed.

Lemma reff94_not4131 : ~ @Equation4131 Fin4 reff94_inst.
Proof. unfold Equation4131. intro H. specialize (H F4_1 F4_2). unfold magma_op, reff94_inst, reff94_op in H. discriminate H. Qed.

Lemma reff94_not4154 : ~ @Equation4154 Fin4 reff94_inst.
Proof. unfold Equation4154. intro H. specialize (H F4_2 F4_1). unfold magma_op, reff94_inst, reff94_op in H. discriminate H. Qed.

Lemma reff94_not4155 : ~ @Equation4155 Fin4 reff94_inst.
Proof. unfold Equation4155. intro H. specialize (H F4_1 F4_2). unfold magma_op, reff94_inst, reff94_op in H. discriminate H. Qed.

Lemma reff94_not4157 : ~ @Equation4157 Fin4 reff94_inst.
Proof. unfold Equation4157. intro H. specialize (H F4_1 F4_2). unfold magma_op, reff94_inst, reff94_op in H. discriminate H. Qed.

Lemma reff94_not4158 : ~ @Equation4158 Fin4 reff94_inst.
Proof. unfold Equation4158. intro H. specialize (H F4_1 F4_2). unfold magma_op, reff94_inst, reff94_op in H. discriminate H. Qed.

Lemma reff94_not4164 : ~ @Equation4164 Fin4 reff94_inst.
Proof. unfold Equation4164. intro H. specialize (H F4_1 F4_2). unfold magma_op, reff94_inst, reff94_op in H. discriminate H. Qed.

Lemma reff94_not4165 : ~ @Equation4165 Fin4 reff94_inst.
Proof. unfold Equation4165. intro H. specialize (H F4_1 F4_2). unfold magma_op, reff94_inst, reff94_op in H. discriminate H. Qed.

Lemma reff94_not4167 : ~ @Equation4167 Fin4 reff94_inst.
Proof. unfold Equation4167. intro H. specialize (H F4_1 F4_2). unfold magma_op, reff94_inst, reff94_op in H. discriminate H. Qed.

Lemma reff94_not4268 : ~ @Equation4268 Fin4 reff94_inst.
Proof. unfold Equation4268. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff94_inst, reff94_op in H. discriminate H. Qed.

Lemma reff94_not4269 : ~ @Equation4269 Fin4 reff94_inst.
Proof. unfold Equation4269. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff94_inst, reff94_op in H. discriminate H. Qed.

Lemma reff94_not4270 : ~ @Equation4270 Fin4 reff94_inst.
Proof. unfold Equation4270. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff94_inst, reff94_op in H. discriminate H. Qed.

Lemma reff94_not4272 : ~ @Equation4272 Fin4 reff94_inst.
Proof. unfold Equation4272. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff94_inst, reff94_op in H. discriminate H. Qed.

Lemma reff94_not4273 : ~ @Equation4273 Fin4 reff94_inst.
Proof. unfold Equation4273. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff94_inst, reff94_op in H. discriminate H. Qed.

Lemma reff94_not4275 : ~ @Equation4275 Fin4 reff94_inst.
Proof. unfold Equation4275. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff94_inst, reff94_op in H. discriminate H. Qed.

Lemma reff94_not4276 : ~ @Equation4276 Fin4 reff94_inst.
Proof. unfold Equation4276. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff94_inst, reff94_op in H. discriminate H. Qed.

Lemma reff94_not4284 : ~ @Equation4284 Fin4 reff94_inst.
Proof. unfold Equation4284. intro H. specialize (H F4_1 F4_2). unfold magma_op, reff94_inst, reff94_op in H. discriminate H. Qed.

Lemma reff94_not4291 : ~ @Equation4291 Fin4 reff94_inst.
Proof. unfold Equation4291. intro H. specialize (H F4_1 F4_2). unfold magma_op, reff94_inst, reff94_op in H. discriminate H. Qed.

Lemma reff94_not4293 : ~ @Equation4293 Fin4 reff94_inst.
Proof. unfold Equation4293. intro H. specialize (H F4_1 F4_2). unfold magma_op, reff94_inst, reff94_op in H. discriminate H. Qed.

Lemma reff94_not4314 : ~ @Equation4314 Fin4 reff94_inst.
Proof. unfold Equation4314. intro H. specialize (H F4_1 F4_2). unfold magma_op, reff94_inst, reff94_op in H. discriminate H. Qed.

Lemma reff94_not4321 : ~ @Equation4321 Fin4 reff94_inst.
Proof. unfold Equation4321. intro H. specialize (H F4_1 F4_2). unfold magma_op, reff94_inst, reff94_op in H. discriminate H. Qed.

Lemma reff94_not4343 : ~ @Equation4343 Fin4 reff94_inst.
Proof. unfold Equation4343. intro H. specialize (H F4_1 F4_2). unfold magma_op, reff94_inst, reff94_op in H. discriminate H. Qed.

Lemma reff94_not4399 : ~ @Equation4399 Fin4 reff94_inst.
Proof. unfold Equation4399. intro H. specialize (H F4_1 F4_2). unfold magma_op, reff94_inst, reff94_op in H. discriminate H. Qed.

Lemma reff94_not4406 : ~ @Equation4406 Fin4 reff94_inst.
Proof. unfold Equation4406. intro H. specialize (H F4_1 F4_2). unfold magma_op, reff94_inst, reff94_op in H. discriminate H. Qed.

Lemma reff94_not4408 : ~ @Equation4408 Fin4 reff94_inst.
Proof. unfold Equation4408. intro H. specialize (H F4_1 F4_2). unfold magma_op, reff94_inst, reff94_op in H. discriminate H. Qed.

Lemma reff94_not4436 : ~ @Equation4436 Fin4 reff94_inst.
Proof. unfold Equation4436. intro H. specialize (H F4_1 F4_2). unfold magma_op, reff94_inst, reff94_op in H. discriminate H. Qed.

Lemma reff94_not4443 : ~ @Equation4443 Fin4 reff94_inst.
Proof. unfold Equation4443. intro H. specialize (H F4_1 F4_2). unfold magma_op, reff94_inst, reff94_op in H. discriminate H. Qed.

Lemma reff94_not4445 : ~ @Equation4445 Fin4 reff94_inst.
Proof. unfold Equation4445. intro H. specialize (H F4_1 F4_2). unfold magma_op, reff94_inst, reff94_op in H. discriminate H. Qed.

Lemma reff94_not4470 : ~ @Equation4470 Fin4 reff94_inst.
Proof. unfold Equation4470. intro H. specialize (H F4_1 F4_2). unfold magma_op, reff94_inst, reff94_op in H. discriminate H. Qed.

Lemma reff94_not4472 : ~ @Equation4472 Fin4 reff94_inst.
Proof. unfold Equation4472. intro H. specialize (H F4_1 F4_2). unfold magma_op, reff94_inst, reff94_op in H. discriminate H. Qed.

Lemma reff94_not4479 : ~ @Equation4479 Fin4 reff94_inst.
Proof. unfold Equation4479. intro H. specialize (H F4_1 F4_2). unfold magma_op, reff94_inst, reff94_op in H. discriminate H. Qed.

Lemma reff94_not4583 : ~ @Equation4583 Fin4 reff94_inst.
Proof. unfold Equation4583. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff94_inst, reff94_op in H. discriminate H. Qed.

Lemma reff94_not4584 : ~ @Equation4584 Fin4 reff94_inst.
Proof. unfold Equation4584. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff94_inst, reff94_op in H. discriminate H. Qed.

Lemma reff94_not4585 : ~ @Equation4585 Fin4 reff94_inst.
Proof. unfold Equation4585. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff94_inst, reff94_op in H. discriminate H. Qed.

Lemma reff94_not4587 : ~ @Equation4587 Fin4 reff94_inst.
Proof. unfold Equation4587. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff94_inst, reff94_op in H. discriminate H. Qed.

Lemma reff94_not4588 : ~ @Equation4588 Fin4 reff94_inst.
Proof. unfold Equation4588. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff94_inst, reff94_op in H. discriminate H. Qed.

Lemma reff94_not4590 : ~ @Equation4590 Fin4 reff94_inst.
Proof. unfold Equation4590. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff94_inst, reff94_op in H. discriminate H. Qed.

Lemma reff94_not4591 : ~ @Equation4591 Fin4 reff94_inst.
Proof. unfold Equation4591. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff94_inst, reff94_op in H. discriminate H. Qed.

Lemma reff94_not4599 : ~ @Equation4599 Fin4 reff94_inst.
Proof. unfold Equation4599. intro H. specialize (H F4_1 F4_2). unfold magma_op, reff94_inst, reff94_op in H. discriminate H. Qed.

Lemma reff94_not4606 : ~ @Equation4606 Fin4 reff94_inst.
Proof. unfold Equation4606. intro H. specialize (H F4_1 F4_2). unfold magma_op, reff94_inst, reff94_op in H. discriminate H. Qed.

Lemma reff94_not4608 : ~ @Equation4608 Fin4 reff94_inst.
Proof. unfold Equation4608. intro H. specialize (H F4_1 F4_2). unfold magma_op, reff94_inst, reff94_op in H. discriminate H. Qed.

Lemma reff94_not4629 : ~ @Equation4629 Fin4 reff94_inst.
Proof. unfold Equation4629. intro H. specialize (H F4_1 F4_2). unfold magma_op, reff94_inst, reff94_op in H. discriminate H. Qed.

Lemma reff94_not4636 : ~ @Equation4636 Fin4 reff94_inst.
Proof. unfold Equation4636. intro H. specialize (H F4_1 F4_2). unfold magma_op, reff94_inst, reff94_op in H. discriminate H. Qed.

Lemma reff94_not4658 : ~ @Equation4658 Fin4 reff94_inst.
Proof. unfold Equation4658. intro H. specialize (H F4_1 F4_2). unfold magma_op, reff94_inst, reff94_op in H. discriminate H. Qed.

(** ---- reff96 (Fin2) ---- *)

Definition reff96_op (x y : Fin2) : Fin2 :=
  match x, y with
  | F2_0, F2_0 => F2_0 | F2_0, F2_1 => F2_0
  | F2_1, F2_0 => F2_0 | F2_1, F2_1 => F2_1
  end.

#[local] Instance reff96_inst : Magma Fin2 := {| magma_op := reff96_op |}.

Lemma reff96_sat323 : @Equation323 Fin2 reff96_inst.
Proof. unfold Equation323, magma_op, reff96_inst, reff96_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff96_sat325 : @Equation325 Fin2 reff96_inst.
Proof. unfold Equation325, magma_op, reff96_inst, reff96_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff96_sat332 : @Equation332 Fin2 reff96_inst.
Proof. unfold Equation332, magma_op, reff96_inst, reff96_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff96_sat333 : @Equation333 Fin2 reff96_inst.
Proof. unfold Equation333, magma_op, reff96_inst, reff96_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff96_sat335 : @Equation335 Fin2 reff96_inst.
Proof. unfold Equation335, magma_op, reff96_inst, reff96_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff96_sat377 : @Equation377 Fin2 reff96_inst.
Proof. unfold Equation377, magma_op, reff96_inst, reff96_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff96_sat384 : @Equation384 Fin2 reff96_inst.
Proof. unfold Equation384, magma_op, reff96_inst, reff96_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff96_sat385 : @Equation385 Fin2 reff96_inst.
Proof. unfold Equation385, magma_op, reff96_inst, reff96_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff96_sat3308 : @Equation3308 Fin2 reff96_inst.
Proof. unfold Equation3308, magma_op, reff96_inst, reff96_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff96_sat3309 : @Equation3309 Fin2 reff96_inst.
Proof. unfold Equation3309, magma_op, reff96_inst, reff96_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff96_sat3315 : @Equation3315 Fin2 reff96_inst.
Proof. unfold Equation3315, magma_op, reff96_inst, reff96_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff96_sat3318 : @Equation3318 Fin2 reff96_inst.
Proof. unfold Equation3318, magma_op, reff96_inst, reff96_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff96_sat3345 : @Equation3345 Fin2 reff96_inst.
Proof. unfold Equation3345, magma_op, reff96_inst, reff96_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff96_sat3346 : @Equation3346 Fin2 reff96_inst.
Proof. unfold Equation3346, magma_op, reff96_inst, reff96_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff96_sat3352 : @Equation3352 Fin2 reff96_inst.
Proof. unfold Equation3352, magma_op, reff96_inst, reff96_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff96_sat3355 : @Equation3355 Fin2 reff96_inst.
Proof. unfold Equation3355, magma_op, reff96_inst, reff96_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff96_sat3509 : @Equation3509 Fin2 reff96_inst.
Proof. unfold Equation3509, magma_op, reff96_inst, reff96_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff96_sat3511 : @Equation3511 Fin2 reff96_inst.
Proof. unfold Equation3511, magma_op, reff96_inst, reff96_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff96_sat3512 : @Equation3512 Fin2 reff96_inst.
Proof. unfold Equation3512, magma_op, reff96_inst, reff96_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff96_sat3519 : @Equation3519 Fin2 reff96_inst.
Proof. unfold Equation3519, magma_op, reff96_inst, reff96_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff96_sat3521 : @Equation3521 Fin2 reff96_inst.
Proof. unfold Equation3521, magma_op, reff96_inst, reff96_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff96_sat3546 : @Equation3546 Fin2 reff96_inst.
Proof. unfold Equation3546, magma_op, reff96_inst, reff96_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff96_sat3548 : @Equation3548 Fin2 reff96_inst.
Proof. unfold Equation3548, magma_op, reff96_inst, reff96_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff96_sat3549 : @Equation3549 Fin2 reff96_inst.
Proof. unfold Equation3549, magma_op, reff96_inst, reff96_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff96_sat3555 : @Equation3555 Fin2 reff96_inst.
Proof. unfold Equation3555, magma_op, reff96_inst, reff96_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff96_sat3556 : @Equation3556 Fin2 reff96_inst.
Proof. unfold Equation3556, magma_op, reff96_inst, reff96_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff96_sat3558 : @Equation3558 Fin2 reff96_inst.
Proof. unfold Equation3558, magma_op, reff96_inst, reff96_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff96_sat3712 : @Equation3712 Fin2 reff96_inst.
Proof. unfold Equation3712, magma_op, reff96_inst, reff96_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff96_sat3714 : @Equation3714 Fin2 reff96_inst.
Proof. unfold Equation3714, magma_op, reff96_inst, reff96_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff96_sat3721 : @Equation3721 Fin2 reff96_inst.
Proof. unfold Equation3721, magma_op, reff96_inst, reff96_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff96_sat3724 : @Equation3724 Fin2 reff96_inst.
Proof. unfold Equation3724, magma_op, reff96_inst, reff96_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff96_sat3748 : @Equation3748 Fin2 reff96_inst.
Proof. unfold Equation3748, magma_op, reff96_inst, reff96_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff96_sat3749 : @Equation3749 Fin2 reff96_inst.
Proof. unfold Equation3749, magma_op, reff96_inst, reff96_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff96_sat3751 : @Equation3751 Fin2 reff96_inst.
Proof. unfold Equation3751, magma_op, reff96_inst, reff96_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff96_sat3752 : @Equation3752 Fin2 reff96_inst.
Proof. unfold Equation3752, magma_op, reff96_inst, reff96_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff96_sat3759 : @Equation3759 Fin2 reff96_inst.
Proof. unfold Equation3759, magma_op, reff96_inst, reff96_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff96_sat3761 : @Equation3761 Fin2 reff96_inst.
Proof. unfold Equation3761, magma_op, reff96_inst, reff96_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff96_sat3917 : @Equation3917 Fin2 reff96_inst.
Proof. unfold Equation3917, magma_op, reff96_inst, reff96_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff96_sat3918 : @Equation3918 Fin2 reff96_inst.
Proof. unfold Equation3918, magma_op, reff96_inst, reff96_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff96_sat3924 : @Equation3924 Fin2 reff96_inst.
Proof. unfold Equation3924, magma_op, reff96_inst, reff96_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff96_sat3925 : @Equation3925 Fin2 reff96_inst.
Proof. unfold Equation3925, magma_op, reff96_inst, reff96_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff96_sat3927 : @Equation3927 Fin2 reff96_inst.
Proof. unfold Equation3927, magma_op, reff96_inst, reff96_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff96_sat3951 : @Equation3951 Fin2 reff96_inst.
Proof. unfold Equation3951, magma_op, reff96_inst, reff96_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff96_sat3952 : @Equation3952 Fin2 reff96_inst.
Proof. unfold Equation3952, magma_op, reff96_inst, reff96_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff96_sat3954 : @Equation3954 Fin2 reff96_inst.
Proof. unfold Equation3954, magma_op, reff96_inst, reff96_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff96_sat3955 : @Equation3955 Fin2 reff96_inst.
Proof. unfold Equation3955, magma_op, reff96_inst, reff96_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff96_sat3961 : @Equation3961 Fin2 reff96_inst.
Proof. unfold Equation3961, magma_op, reff96_inst, reff96_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff96_sat4120 : @Equation4120 Fin2 reff96_inst.
Proof. unfold Equation4120, magma_op, reff96_inst, reff96_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff96_sat4154 : @Equation4154 Fin2 reff96_inst.
Proof. unfold Equation4154, magma_op, reff96_inst, reff96_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff96_sat4155 : @Equation4155 Fin2 reff96_inst.
Proof. unfold Equation4155, magma_op, reff96_inst, reff96_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff96_sat4157 : @Equation4157 Fin2 reff96_inst.
Proof. unfold Equation4157, magma_op, reff96_inst, reff96_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff96_sat4158 : @Equation4158 Fin2 reff96_inst.
Proof. unfold Equation4158, magma_op, reff96_inst, reff96_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff96_sat4164 : @Equation4164 Fin2 reff96_inst.
Proof. unfold Equation4164, magma_op, reff96_inst, reff96_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff96_sat4165 : @Equation4165 Fin2 reff96_inst.
Proof. unfold Equation4165, magma_op, reff96_inst, reff96_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff96_sat4284 : @Equation4284 Fin2 reff96_inst.
Proof. unfold Equation4284, magma_op, reff96_inst, reff96_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff96_sat4291 : @Equation4291 Fin2 reff96_inst.
Proof. unfold Equation4291, magma_op, reff96_inst, reff96_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff96_sat4293 : @Equation4293 Fin2 reff96_inst.
Proof. unfold Equation4293, magma_op, reff96_inst, reff96_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff96_sat4314 : @Equation4314 Fin2 reff96_inst.
Proof. unfold Equation4314, magma_op, reff96_inst, reff96_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff96_sat4321 : @Equation4321 Fin2 reff96_inst.
Proof. unfold Equation4321, magma_op, reff96_inst, reff96_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff96_sat4362 : @Equation4362 Fin2 reff96_inst.
Proof. unfold Equation4362, magma_op, reff96_inst, reff96_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff96_sat4364 : @Equation4364 Fin2 reff96_inst.
Proof. unfold Equation4364, magma_op, reff96_inst, reff96_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff96_sat4369 : @Equation4369 Fin2 reff96_inst.
Proof. unfold Equation4369, magma_op, reff96_inst, reff96_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff96_sat4399 : @Equation4399 Fin2 reff96_inst.
Proof. unfold Equation4399, magma_op, reff96_inst, reff96_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff96_sat4406 : @Equation4406 Fin2 reff96_inst.
Proof. unfold Equation4406, magma_op, reff96_inst, reff96_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff96_sat4408 : @Equation4408 Fin2 reff96_inst.
Proof. unfold Equation4408, magma_op, reff96_inst, reff96_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff96_sat4436 : @Equation4436 Fin2 reff96_inst.
Proof. unfold Equation4436, magma_op, reff96_inst, reff96_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff96_sat4443 : @Equation4443 Fin2 reff96_inst.
Proof. unfold Equation4443, magma_op, reff96_inst, reff96_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff96_sat4445 : @Equation4445 Fin2 reff96_inst.
Proof. unfold Equation4445, magma_op, reff96_inst, reff96_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff96_sat4472 : @Equation4472 Fin2 reff96_inst.
Proof. unfold Equation4472, magma_op, reff96_inst, reff96_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff96_sat4479 : @Equation4479 Fin2 reff96_inst.
Proof. unfold Equation4479, magma_op, reff96_inst, reff96_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff96_sat4512 : @Equation4512 Fin2 reff96_inst.
Proof. unfold Equation4512, magma_op, reff96_inst, reff96_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff96_sat4515 : @Equation4515 Fin2 reff96_inst.
Proof. unfold Equation4515, magma_op, reff96_inst, reff96_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff96_sat4525 : @Equation4525 Fin2 reff96_inst.
Proof. unfold Equation4525, magma_op, reff96_inst, reff96_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff96_sat4541 : @Equation4541 Fin2 reff96_inst.
Proof. unfold Equation4541, magma_op, reff96_inst, reff96_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff96_sat4606 : @Equation4606 Fin2 reff96_inst.
Proof. unfold Equation4606, magma_op, reff96_inst, reff96_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff96_sat4629 : @Equation4629 Fin2 reff96_inst.
Proof. unfold Equation4629, magma_op, reff96_inst, reff96_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff96_sat4636 : @Equation4636 Fin2 reff96_inst.
Proof. unfold Equation4636, magma_op, reff96_inst, reff96_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff96_sat4658 : @Equation4658 Fin2 reff96_inst.
Proof. unfold Equation4658, magma_op, reff96_inst, reff96_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff96_sat4673 : @Equation4673 Fin2 reff96_inst.
Proof. unfold Equation4673, magma_op, reff96_inst, reff96_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff96_sat4679 : @Equation4679 Fin2 reff96_inst.
Proof. unfold Equation4679, magma_op, reff96_inst, reff96_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff96_sat4684 : @Equation4684 Fin2 reff96_inst.
Proof. unfold Equation4684, magma_op, reff96_inst, reff96_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff96_not50 : ~ @Equation50 Fin2 reff96_inst.
Proof. unfold Equation50. intro H. specialize (H F2_1 F2_0). unfold magma_op, reff96_inst, reff96_op in H. discriminate H. Qed.

Lemma reff96_not53 : ~ @Equation53 Fin2 reff96_inst.
Proof. unfold Equation53. intro H. specialize (H F2_1 F2_0). unfold magma_op, reff96_inst, reff96_op in H. discriminate H. Qed.

Lemma reff96_not55 : ~ @Equation55 Fin2 reff96_inst.
Proof. unfold Equation55. intro H. specialize (H F2_1 F2_0). unfold magma_op, reff96_inst, reff96_op in H. discriminate H. Qed.

Lemma reff96_not56 : ~ @Equation56 Fin2 reff96_inst.
Proof. unfold Equation56. intro H. specialize (H F2_1 F2_0). unfold magma_op, reff96_inst, reff96_op in H. discriminate H. Qed.

Lemma reff96_not63 : ~ @Equation63 Fin2 reff96_inst.
Proof. unfold Equation63. intro H. specialize (H F2_1 F2_0). unfold magma_op, reff96_inst, reff96_op in H. discriminate H. Qed.

Lemma reff96_not65 : ~ @Equation65 Fin2 reff96_inst.
Proof. unfold Equation65. intro H. specialize (H F2_1 F2_0). unfold magma_op, reff96_inst, reff96_op in H. discriminate H. Qed.

Lemma reff96_not66 : ~ @Equation66 Fin2 reff96_inst.
Proof. unfold Equation66. intro H. specialize (H F2_1 F2_0). unfold magma_op, reff96_inst, reff96_op in H. discriminate H. Qed.

Lemma reff96_not72 : ~ @Equation72 Fin2 reff96_inst.
Proof. unfold Equation72. intro H. specialize (H F2_1 F2_0). unfold magma_op, reff96_inst, reff96_op in H. discriminate H. Qed.

Lemma reff96_not73 : ~ @Equation73 Fin2 reff96_inst.
Proof. unfold Equation73. intro H. specialize (H F2_1 F2_0). unfold magma_op, reff96_inst, reff96_op in H. discriminate H. Qed.

Lemma reff96_not75 : ~ @Equation75 Fin2 reff96_inst.
Proof. unfold Equation75. intro H. specialize (H F2_1 F2_0). unfold magma_op, reff96_inst, reff96_op in H. discriminate H. Qed.

Lemma reff96_not102 : ~ @Equation102 Fin2 reff96_inst.
Proof. unfold Equation102. intro H. specialize (H F2_1 F2_0). unfold magma_op, reff96_inst, reff96_op in H. discriminate H. Qed.

Lemma reff96_not105 : ~ @Equation105 Fin2 reff96_inst.
Proof. unfold Equation105. intro H. specialize (H F2_1 F2_0). unfold magma_op, reff96_inst, reff96_op in H. discriminate H. Qed.

Lemma reff96_not107 : ~ @Equation107 Fin2 reff96_inst.
Proof. unfold Equation107. intro H. specialize (H F2_1 F2_0). unfold magma_op, reff96_inst, reff96_op in H. discriminate H. Qed.

Lemma reff96_not108 : ~ @Equation108 Fin2 reff96_inst.
Proof. unfold Equation108. intro H. specialize (H F2_1 F2_0). unfold magma_op, reff96_inst, reff96_op in H. discriminate H. Qed.

Lemma reff96_not115 : ~ @Equation115 Fin2 reff96_inst.
Proof. unfold Equation115. intro H. specialize (H F2_1 F2_0). unfold magma_op, reff96_inst, reff96_op in H. discriminate H. Qed.

Lemma reff96_not117 : ~ @Equation117 Fin2 reff96_inst.
Proof. unfold Equation117. intro H. specialize (H F2_1 F2_0). unfold magma_op, reff96_inst, reff96_op in H. discriminate H. Qed.

Lemma reff96_not118 : ~ @Equation118 Fin2 reff96_inst.
Proof. unfold Equation118. intro H. specialize (H F2_1 F2_0). unfold magma_op, reff96_inst, reff96_op in H. discriminate H. Qed.

Lemma reff96_not124 : ~ @Equation124 Fin2 reff96_inst.
Proof. unfold Equation124. intro H. specialize (H F2_1 F2_0). unfold magma_op, reff96_inst, reff96_op in H. discriminate H. Qed.

Lemma reff96_not125 : ~ @Equation125 Fin2 reff96_inst.
Proof. unfold Equation125. intro H. specialize (H F2_1 F2_0). unfold magma_op, reff96_inst, reff96_op in H. discriminate H. Qed.

Lemma reff96_not127 : ~ @Equation127 Fin2 reff96_inst.
Proof. unfold Equation127. intro H. specialize (H F2_1 F2_0). unfold magma_op, reff96_inst, reff96_op in H. discriminate H. Qed.

Lemma reff96_not154 : ~ @Equation154 Fin2 reff96_inst.
Proof. unfold Equation154. intro H. specialize (H F2_1 F2_0). unfold magma_op, reff96_inst, reff96_op in H. discriminate H. Qed.

Lemma reff96_not157 : ~ @Equation157 Fin2 reff96_inst.
Proof. unfold Equation157. intro H. specialize (H F2_1 F2_0). unfold magma_op, reff96_inst, reff96_op in H. discriminate H. Qed.

Lemma reff96_not159 : ~ @Equation159 Fin2 reff96_inst.
Proof. unfold Equation159. intro H. specialize (H F2_1 F2_0). unfold magma_op, reff96_inst, reff96_op in H. discriminate H. Qed.

Lemma reff96_not160 : ~ @Equation160 Fin2 reff96_inst.
Proof. unfold Equation160. intro H. specialize (H F2_1 F2_0). unfold magma_op, reff96_inst, reff96_op in H. discriminate H. Qed.

Lemma reff96_not167 : ~ @Equation167 Fin2 reff96_inst.
Proof. unfold Equation167. intro H. specialize (H F2_1 F2_0). unfold magma_op, reff96_inst, reff96_op in H. discriminate H. Qed.

Lemma reff96_not169 : ~ @Equation169 Fin2 reff96_inst.
Proof. unfold Equation169. intro H. specialize (H F2_1 F2_0). unfold magma_op, reff96_inst, reff96_op in H. discriminate H. Qed.

Lemma reff96_not170 : ~ @Equation170 Fin2 reff96_inst.
Proof. unfold Equation170. intro H. specialize (H F2_1 F2_0). unfold magma_op, reff96_inst, reff96_op in H. discriminate H. Qed.

Lemma reff96_not176 : ~ @Equation176 Fin2 reff96_inst.
Proof. unfold Equation176. intro H. specialize (H F2_1 F2_0). unfold magma_op, reff96_inst, reff96_op in H. discriminate H. Qed.

Lemma reff96_not177 : ~ @Equation177 Fin2 reff96_inst.
Proof. unfold Equation177. intro H. specialize (H F2_1 F2_0). unfold magma_op, reff96_inst, reff96_op in H. discriminate H. Qed.

Lemma reff96_not179 : ~ @Equation179 Fin2 reff96_inst.
Proof. unfold Equation179. intro H. specialize (H F2_1 F2_0). unfold magma_op, reff96_inst, reff96_op in H. discriminate H. Qed.

Lemma reff96_not206 : ~ @Equation206 Fin2 reff96_inst.
Proof. unfold Equation206. intro H. specialize (H F2_1 F2_0). unfold magma_op, reff96_inst, reff96_op in H. discriminate H. Qed.

Lemma reff96_not209 : ~ @Equation209 Fin2 reff96_inst.
Proof. unfold Equation209. intro H. specialize (H F2_1 F2_0). unfold magma_op, reff96_inst, reff96_op in H. discriminate H. Qed.

Lemma reff96_not211 : ~ @Equation211 Fin2 reff96_inst.
Proof. unfold Equation211. intro H. specialize (H F2_1 F2_0). unfold magma_op, reff96_inst, reff96_op in H. discriminate H. Qed.

Lemma reff96_not212 : ~ @Equation212 Fin2 reff96_inst.
Proof. unfold Equation212. intro H. specialize (H F2_1 F2_0). unfold magma_op, reff96_inst, reff96_op in H. discriminate H. Qed.

Lemma reff96_not219 : ~ @Equation219 Fin2 reff96_inst.
Proof. unfold Equation219. intro H. specialize (H F2_1 F2_0). unfold magma_op, reff96_inst, reff96_op in H. discriminate H. Qed.

Lemma reff96_not221 : ~ @Equation221 Fin2 reff96_inst.
Proof. unfold Equation221. intro H. specialize (H F2_1 F2_0). unfold magma_op, reff96_inst, reff96_op in H. discriminate H. Qed.

Lemma reff96_not222 : ~ @Equation222 Fin2 reff96_inst.
Proof. unfold Equation222. intro H. specialize (H F2_1 F2_0). unfold magma_op, reff96_inst, reff96_op in H. discriminate H. Qed.

Lemma reff96_not228 : ~ @Equation228 Fin2 reff96_inst.
Proof. unfold Equation228. intro H. specialize (H F2_1 F2_0). unfold magma_op, reff96_inst, reff96_op in H. discriminate H. Qed.

Lemma reff96_not229 : ~ @Equation229 Fin2 reff96_inst.
Proof. unfold Equation229. intro H. specialize (H F2_1 F2_0). unfold magma_op, reff96_inst, reff96_op in H. discriminate H. Qed.

Lemma reff96_not231 : ~ @Equation231 Fin2 reff96_inst.
Proof. unfold Equation231. intro H. specialize (H F2_1 F2_0). unfold magma_op, reff96_inst, reff96_op in H. discriminate H. Qed.

Lemma reff96_not258 : ~ @Equation258 Fin2 reff96_inst.
Proof. unfold Equation258. intro H. specialize (H F2_1 F2_0). unfold magma_op, reff96_inst, reff96_op in H. discriminate H. Qed.

Lemma reff96_not261 : ~ @Equation261 Fin2 reff96_inst.
Proof. unfold Equation261. intro H. specialize (H F2_1 F2_0). unfold magma_op, reff96_inst, reff96_op in H. discriminate H. Qed.

Lemma reff96_not263 : ~ @Equation263 Fin2 reff96_inst.
Proof. unfold Equation263. intro H. specialize (H F2_1 F2_0). unfold magma_op, reff96_inst, reff96_op in H. discriminate H. Qed.

Lemma reff96_not264 : ~ @Equation264 Fin2 reff96_inst.
Proof. unfold Equation264. intro H. specialize (H F2_1 F2_0). unfold magma_op, reff96_inst, reff96_op in H. discriminate H. Qed.

Lemma reff96_not271 : ~ @Equation271 Fin2 reff96_inst.
Proof. unfold Equation271. intro H. specialize (H F2_1 F2_0). unfold magma_op, reff96_inst, reff96_op in H. discriminate H. Qed.

Lemma reff96_not273 : ~ @Equation273 Fin2 reff96_inst.
Proof. unfold Equation273. intro H. specialize (H F2_1 F2_0). unfold magma_op, reff96_inst, reff96_op in H. discriminate H. Qed.

Lemma reff96_not274 : ~ @Equation274 Fin2 reff96_inst.
Proof. unfold Equation274. intro H. specialize (H F2_1 F2_0). unfold magma_op, reff96_inst, reff96_op in H. discriminate H. Qed.

Lemma reff96_not280 : ~ @Equation280 Fin2 reff96_inst.
Proof. unfold Equation280. intro H. specialize (H F2_1 F2_0). unfold magma_op, reff96_inst, reff96_op in H. discriminate H. Qed.

Lemma reff96_not281 : ~ @Equation281 Fin2 reff96_inst.
Proof. unfold Equation281. intro H. specialize (H F2_1 F2_0). unfold magma_op, reff96_inst, reff96_op in H. discriminate H. Qed.

Lemma reff96_not283 : ~ @Equation283 Fin2 reff96_inst.
Proof. unfold Equation283. intro H. specialize (H F2_1 F2_0). unfold magma_op, reff96_inst, reff96_op in H. discriminate H. Qed.

Lemma reff96_not412 : ~ @Equation412 Fin2 reff96_inst.
Proof. unfold Equation412. intro H. specialize (H F2_1 F2_0). unfold magma_op, reff96_inst, reff96_op in H. discriminate H. Qed.

Lemma reff96_not413 : ~ @Equation413 Fin2 reff96_inst.
Proof. unfold Equation413. intro H. specialize (H F2_1 F2_0). unfold magma_op, reff96_inst, reff96_op in H. discriminate H. Qed.

Lemma reff96_not414 : ~ @Equation414 Fin2 reff96_inst.
Proof. unfold Equation414. intro H. specialize (H F2_1 F2_0). unfold magma_op, reff96_inst, reff96_op in H. discriminate H. Qed.

Lemma reff96_not416 : ~ @Equation416 Fin2 reff96_inst.
Proof. unfold Equation416. intro H. specialize (H F2_1 F2_0). unfold magma_op, reff96_inst, reff96_op in H. discriminate H. Qed.

Lemma reff96_not417 : ~ @Equation417 Fin2 reff96_inst.
Proof. unfold Equation417. intro H. specialize (H F2_1 F2_0). unfold magma_op, reff96_inst, reff96_op in H. discriminate H. Qed.

Lemma reff96_not419 : ~ @Equation419 Fin2 reff96_inst.
Proof. unfold Equation419. intro H. specialize (H F2_1 F2_0). unfold magma_op, reff96_inst, reff96_op in H. discriminate H. Qed.

Lemma reff96_not420 : ~ @Equation420 Fin2 reff96_inst.
Proof. unfold Equation420. intro H. specialize (H F2_1 F2_0). unfold magma_op, reff96_inst, reff96_op in H. discriminate H. Qed.

Lemma reff96_not426 : ~ @Equation426 Fin2 reff96_inst.
Proof. unfold Equation426. intro H. specialize (H F2_1 F2_0). unfold magma_op, reff96_inst, reff96_op in H. discriminate H. Qed.

Lemma reff96_not427 : ~ @Equation427 Fin2 reff96_inst.
Proof. unfold Equation427. intro H. specialize (H F2_1 F2_0). unfold magma_op, reff96_inst, reff96_op in H. discriminate H. Qed.

Lemma reff96_not429 : ~ @Equation429 Fin2 reff96_inst.
Proof. unfold Equation429. intro H. specialize (H F2_1 F2_0). unfold magma_op, reff96_inst, reff96_op in H. discriminate H. Qed.

Lemma reff96_not430 : ~ @Equation430 Fin2 reff96_inst.
Proof. unfold Equation430. intro H. specialize (H F2_1 F2_0). unfold magma_op, reff96_inst, reff96_op in H. discriminate H. Qed.

Lemma reff96_not436 : ~ @Equation436 Fin2 reff96_inst.
Proof. unfold Equation436. intro H. specialize (H F2_1 F2_0). unfold magma_op, reff96_inst, reff96_op in H. discriminate H. Qed.

Lemma reff96_not437 : ~ @Equation437 Fin2 reff96_inst.
Proof. unfold Equation437. intro H. specialize (H F2_1 F2_0). unfold magma_op, reff96_inst, reff96_op in H. discriminate H. Qed.

Lemma reff96_not439 : ~ @Equation439 Fin2 reff96_inst.
Proof. unfold Equation439. intro H. specialize (H F2_1 F2_0). unfold magma_op, reff96_inst, reff96_op in H. discriminate H. Qed.

Lemma reff96_not440 : ~ @Equation440 Fin2 reff96_inst.
Proof. unfold Equation440. intro H. specialize (H F2_1 F2_0). unfold magma_op, reff96_inst, reff96_op in H. discriminate H. Qed.

Lemma reff96_not463 : ~ @Equation463 Fin2 reff96_inst.
Proof. unfold Equation463. intro H. specialize (H F2_1 F2_0). unfold magma_op, reff96_inst, reff96_op in H. discriminate H. Qed.

Lemma reff96_not464 : ~ @Equation464 Fin2 reff96_inst.
Proof. unfold Equation464. intro H. specialize (H F2_1 F2_0). unfold magma_op, reff96_inst, reff96_op in H. discriminate H. Qed.

Lemma reff96_not466 : ~ @Equation466 Fin2 reff96_inst.
Proof. unfold Equation466. intro H. specialize (H F2_1 F2_0). unfold magma_op, reff96_inst, reff96_op in H. discriminate H. Qed.

Lemma reff96_not467 : ~ @Equation467 Fin2 reff96_inst.
Proof. unfold Equation467. intro H. specialize (H F2_1 F2_0). unfold magma_op, reff96_inst, reff96_op in H. discriminate H. Qed.

Lemma reff96_not473 : ~ @Equation473 Fin2 reff96_inst.
Proof. unfold Equation473. intro H. specialize (H F2_1 F2_0). unfold magma_op, reff96_inst, reff96_op in H. discriminate H. Qed.

Lemma reff96_not474 : ~ @Equation474 Fin2 reff96_inst.
Proof. unfold Equation474. intro H. specialize (H F2_1 F2_0). unfold magma_op, reff96_inst, reff96_op in H. discriminate H. Qed.

Lemma reff96_not476 : ~ @Equation476 Fin2 reff96_inst.
Proof. unfold Equation476. intro H. specialize (H F2_1 F2_0). unfold magma_op, reff96_inst, reff96_op in H. discriminate H. Qed.

Lemma reff96_not477 : ~ @Equation477 Fin2 reff96_inst.
Proof. unfold Equation477. intro H. specialize (H F2_1 F2_0). unfold magma_op, reff96_inst, reff96_op in H. discriminate H. Qed.

Lemma reff96_not500 : ~ @Equation500 Fin2 reff96_inst.
Proof. unfold Equation500. intro H. specialize (H F2_1 F2_0). unfold magma_op, reff96_inst, reff96_op in H. discriminate H. Qed.

Lemma reff96_not501 : ~ @Equation501 Fin2 reff96_inst.
Proof. unfold Equation501. intro H. specialize (H F2_1 F2_0). unfold magma_op, reff96_inst, reff96_op in H. discriminate H. Qed.

Lemma reff96_not503 : ~ @Equation503 Fin2 reff96_inst.
Proof. unfold Equation503. intro H. specialize (H F2_1 F2_0). unfold magma_op, reff96_inst, reff96_op in H. discriminate H. Qed.

Lemma reff96_not504 : ~ @Equation504 Fin2 reff96_inst.
Proof. unfold Equation504. intro H. specialize (H F2_1 F2_0). unfold magma_op, reff96_inst, reff96_op in H. discriminate H. Qed.

Lemma reff96_not510 : ~ @Equation510 Fin2 reff96_inst.
Proof. unfold Equation510. intro H. specialize (H F2_1 F2_0). unfold magma_op, reff96_inst, reff96_op in H. discriminate H. Qed.

Lemma reff96_not511 : ~ @Equation511 Fin2 reff96_inst.
Proof. unfold Equation511. intro H. specialize (H F2_1 F2_0). unfold magma_op, reff96_inst, reff96_op in H. discriminate H. Qed.

Lemma reff96_not513 : ~ @Equation513 Fin2 reff96_inst.
Proof. unfold Equation513. intro H. specialize (H F2_1 F2_0). unfold magma_op, reff96_inst, reff96_op in H. discriminate H. Qed.

Lemma reff96_not615 : ~ @Equation615 Fin2 reff96_inst.
Proof. unfold Equation615. intro H. specialize (H F2_1 F2_0). unfold magma_op, reff96_inst, reff96_op in H. discriminate H. Qed.

Lemma reff96_not616 : ~ @Equation616 Fin2 reff96_inst.
Proof. unfold Equation616. intro H. specialize (H F2_1 F2_0). unfold magma_op, reff96_inst, reff96_op in H. discriminate H. Qed.

Lemma reff96_not617 : ~ @Equation617 Fin2 reff96_inst.
Proof. unfold Equation617. intro H. specialize (H F2_1 F2_0). unfold magma_op, reff96_inst, reff96_op in H. discriminate H. Qed.

Lemma reff96_not619 : ~ @Equation619 Fin2 reff96_inst.
Proof. unfold Equation619. intro H. specialize (H F2_1 F2_0). unfold magma_op, reff96_inst, reff96_op in H. discriminate H. Qed.

Lemma reff96_not620 : ~ @Equation620 Fin2 reff96_inst.
Proof. unfold Equation620. intro H. specialize (H F2_1 F2_0). unfold magma_op, reff96_inst, reff96_op in H. discriminate H. Qed.

Lemma reff96_not622 : ~ @Equation622 Fin2 reff96_inst.
Proof. unfold Equation622. intro H. specialize (H F2_1 F2_0). unfold magma_op, reff96_inst, reff96_op in H. discriminate H. Qed.

Lemma reff96_not623 : ~ @Equation623 Fin2 reff96_inst.
Proof. unfold Equation623. intro H. specialize (H F2_1 F2_0). unfold magma_op, reff96_inst, reff96_op in H. discriminate H. Qed.

Lemma reff96_not629 : ~ @Equation629 Fin2 reff96_inst.
Proof. unfold Equation629. intro H. specialize (H F2_1 F2_0). unfold magma_op, reff96_inst, reff96_op in H. discriminate H. Qed.

Lemma reff96_not630 : ~ @Equation630 Fin2 reff96_inst.
Proof. unfold Equation630. intro H. specialize (H F2_1 F2_0). unfold magma_op, reff96_inst, reff96_op in H. discriminate H. Qed.

Lemma reff96_not632 : ~ @Equation632 Fin2 reff96_inst.
Proof. unfold Equation632. intro H. specialize (H F2_1 F2_0). unfold magma_op, reff96_inst, reff96_op in H. discriminate H. Qed.

Lemma reff96_not633 : ~ @Equation633 Fin2 reff96_inst.
Proof. unfold Equation633. intro H. specialize (H F2_1 F2_0). unfold magma_op, reff96_inst, reff96_op in H. discriminate H. Qed.

Lemma reff96_not639 : ~ @Equation639 Fin2 reff96_inst.
Proof. unfold Equation639. intro H. specialize (H F2_1 F2_0). unfold magma_op, reff96_inst, reff96_op in H. discriminate H. Qed.

Lemma reff96_not640 : ~ @Equation640 Fin2 reff96_inst.
Proof. unfold Equation640. intro H. specialize (H F2_1 F2_0). unfold magma_op, reff96_inst, reff96_op in H. discriminate H. Qed.

Lemma reff96_not642 : ~ @Equation642 Fin2 reff96_inst.
Proof. unfold Equation642. intro H. specialize (H F2_1 F2_0). unfold magma_op, reff96_inst, reff96_op in H. discriminate H. Qed.

Lemma reff96_not643 : ~ @Equation643 Fin2 reff96_inst.
Proof. unfold Equation643. intro H. specialize (H F2_1 F2_0). unfold magma_op, reff96_inst, reff96_op in H. discriminate H. Qed.

Lemma reff96_not666 : ~ @Equation666 Fin2 reff96_inst.
Proof. unfold Equation666. intro H. specialize (H F2_1 F2_0). unfold magma_op, reff96_inst, reff96_op in H. discriminate H. Qed.

Lemma reff96_not667 : ~ @Equation667 Fin2 reff96_inst.
Proof. unfold Equation667. intro H. specialize (H F2_1 F2_0). unfold magma_op, reff96_inst, reff96_op in H. discriminate H. Qed.

Lemma reff96_not669 : ~ @Equation669 Fin2 reff96_inst.
Proof. unfold Equation669. intro H. specialize (H F2_1 F2_0). unfold magma_op, reff96_inst, reff96_op in H. discriminate H. Qed.

Lemma reff96_not670 : ~ @Equation670 Fin2 reff96_inst.
Proof. unfold Equation670. intro H. specialize (H F2_1 F2_0). unfold magma_op, reff96_inst, reff96_op in H. discriminate H. Qed.

Lemma reff96_not676 : ~ @Equation676 Fin2 reff96_inst.
Proof. unfold Equation676. intro H. specialize (H F2_1 F2_0). unfold magma_op, reff96_inst, reff96_op in H. discriminate H. Qed.

Lemma reff96_not677 : ~ @Equation677 Fin2 reff96_inst.
Proof. unfold Equation677. intro H. specialize (H F2_1 F2_0). unfold magma_op, reff96_inst, reff96_op in H. discriminate H. Qed.

Lemma reff96_not679 : ~ @Equation679 Fin2 reff96_inst.
Proof. unfold Equation679. intro H. specialize (H F2_1 F2_0). unfold magma_op, reff96_inst, reff96_op in H. discriminate H. Qed.

Lemma reff96_not680 : ~ @Equation680 Fin2 reff96_inst.
Proof. unfold Equation680. intro H. specialize (H F2_1 F2_0). unfold magma_op, reff96_inst, reff96_op in H. discriminate H. Qed.

Lemma reff96_not703 : ~ @Equation703 Fin2 reff96_inst.
Proof. unfold Equation703. intro H. specialize (H F2_1 F2_0). unfold magma_op, reff96_inst, reff96_op in H. discriminate H. Qed.

Lemma reff96_not704 : ~ @Equation704 Fin2 reff96_inst.
Proof. unfold Equation704. intro H. specialize (H F2_1 F2_0). unfold magma_op, reff96_inst, reff96_op in H. discriminate H. Qed.

Lemma reff96_not706 : ~ @Equation706 Fin2 reff96_inst.
Proof. unfold Equation706. intro H. specialize (H F2_1 F2_0). unfold magma_op, reff96_inst, reff96_op in H. discriminate H. Qed.

Lemma reff96_not707 : ~ @Equation707 Fin2 reff96_inst.
Proof. unfold Equation707. intro H. specialize (H F2_1 F2_0). unfold magma_op, reff96_inst, reff96_op in H. discriminate H. Qed.

Lemma reff96_not713 : ~ @Equation713 Fin2 reff96_inst.
Proof. unfold Equation713. intro H. specialize (H F2_1 F2_0). unfold magma_op, reff96_inst, reff96_op in H. discriminate H. Qed.

Lemma reff96_not714 : ~ @Equation714 Fin2 reff96_inst.
Proof. unfold Equation714. intro H. specialize (H F2_1 F2_0). unfold magma_op, reff96_inst, reff96_op in H. discriminate H. Qed.

Lemma reff96_not716 : ~ @Equation716 Fin2 reff96_inst.
Proof. unfold Equation716. intro H. specialize (H F2_1 F2_0). unfold magma_op, reff96_inst, reff96_op in H. discriminate H. Qed.

Lemma reff96_not818 : ~ @Equation818 Fin2 reff96_inst.
Proof. unfold Equation818. intro H. specialize (H F2_1 F2_0). unfold magma_op, reff96_inst, reff96_op in H. discriminate H. Qed.

Lemma reff96_not819 : ~ @Equation819 Fin2 reff96_inst.
Proof. unfold Equation819. intro H. specialize (H F2_1 F2_0). unfold magma_op, reff96_inst, reff96_op in H. discriminate H. Qed.

Lemma reff96_not820 : ~ @Equation820 Fin2 reff96_inst.
Proof. unfold Equation820. intro H. specialize (H F2_1 F2_0). unfold magma_op, reff96_inst, reff96_op in H. discriminate H. Qed.

Lemma reff96_not822 : ~ @Equation822 Fin2 reff96_inst.
Proof. unfold Equation822. intro H. specialize (H F2_1 F2_0). unfold magma_op, reff96_inst, reff96_op in H. discriminate H. Qed.

Lemma reff96_not823 : ~ @Equation823 Fin2 reff96_inst.
Proof. unfold Equation823. intro H. specialize (H F2_1 F2_0). unfold magma_op, reff96_inst, reff96_op in H. discriminate H. Qed.

Lemma reff96_not825 : ~ @Equation825 Fin2 reff96_inst.
Proof. unfold Equation825. intro H. specialize (H F2_1 F2_0). unfold magma_op, reff96_inst, reff96_op in H. discriminate H. Qed.

Lemma reff96_not826 : ~ @Equation826 Fin2 reff96_inst.
Proof. unfold Equation826. intro H. specialize (H F2_1 F2_0). unfold magma_op, reff96_inst, reff96_op in H. discriminate H. Qed.

Lemma reff96_not832 : ~ @Equation832 Fin2 reff96_inst.
Proof. unfold Equation832. intro H. specialize (H F2_1 F2_0). unfold magma_op, reff96_inst, reff96_op in H. discriminate H. Qed.

Lemma reff96_not833 : ~ @Equation833 Fin2 reff96_inst.
Proof. unfold Equation833. intro H. specialize (H F2_1 F2_0). unfold magma_op, reff96_inst, reff96_op in H. discriminate H. Qed.

Lemma reff96_not835 : ~ @Equation835 Fin2 reff96_inst.
Proof. unfold Equation835. intro H. specialize (H F2_1 F2_0). unfold magma_op, reff96_inst, reff96_op in H. discriminate H. Qed.

Lemma reff96_not836 : ~ @Equation836 Fin2 reff96_inst.
Proof. unfold Equation836. intro H. specialize (H F2_1 F2_0). unfold magma_op, reff96_inst, reff96_op in H. discriminate H. Qed.

Lemma reff96_not842 : ~ @Equation842 Fin2 reff96_inst.
Proof. unfold Equation842. intro H. specialize (H F2_1 F2_0). unfold magma_op, reff96_inst, reff96_op in H. discriminate H. Qed.

Lemma reff96_not843 : ~ @Equation843 Fin2 reff96_inst.
Proof. unfold Equation843. intro H. specialize (H F2_1 F2_0). unfold magma_op, reff96_inst, reff96_op in H. discriminate H. Qed.

Lemma reff96_not845 : ~ @Equation845 Fin2 reff96_inst.
Proof. unfold Equation845. intro H. specialize (H F2_1 F2_0). unfold magma_op, reff96_inst, reff96_op in H. discriminate H. Qed.

Lemma reff96_not846 : ~ @Equation846 Fin2 reff96_inst.
Proof. unfold Equation846. intro H. specialize (H F2_1 F2_0). unfold magma_op, reff96_inst, reff96_op in H. discriminate H. Qed.

Lemma reff96_not869 : ~ @Equation869 Fin2 reff96_inst.
Proof. unfold Equation869. intro H. specialize (H F2_1 F2_0). unfold magma_op, reff96_inst, reff96_op in H. discriminate H. Qed.

Lemma reff96_not870 : ~ @Equation870 Fin2 reff96_inst.
Proof. unfold Equation870. intro H. specialize (H F2_1 F2_0). unfold magma_op, reff96_inst, reff96_op in H. discriminate H. Qed.

Lemma reff96_not872 : ~ @Equation872 Fin2 reff96_inst.
Proof. unfold Equation872. intro H. specialize (H F2_1 F2_0). unfold magma_op, reff96_inst, reff96_op in H. discriminate H. Qed.

Lemma reff96_not873 : ~ @Equation873 Fin2 reff96_inst.
Proof. unfold Equation873. intro H. specialize (H F2_1 F2_0). unfold magma_op, reff96_inst, reff96_op in H. discriminate H. Qed.

Lemma reff96_not879 : ~ @Equation879 Fin2 reff96_inst.
Proof. unfold Equation879. intro H. specialize (H F2_1 F2_0). unfold magma_op, reff96_inst, reff96_op in H. discriminate H. Qed.

Lemma reff96_not880 : ~ @Equation880 Fin2 reff96_inst.
Proof. unfold Equation880. intro H. specialize (H F2_1 F2_0). unfold magma_op, reff96_inst, reff96_op in H. discriminate H. Qed.

Lemma reff96_not882 : ~ @Equation882 Fin2 reff96_inst.
Proof. unfold Equation882. intro H. specialize (H F2_1 F2_0). unfold magma_op, reff96_inst, reff96_op in H. discriminate H. Qed.

Lemma reff96_not883 : ~ @Equation883 Fin2 reff96_inst.
Proof. unfold Equation883. intro H. specialize (H F2_1 F2_0). unfold magma_op, reff96_inst, reff96_op in H. discriminate H. Qed.

Lemma reff96_not906 : ~ @Equation906 Fin2 reff96_inst.
Proof. unfold Equation906. intro H. specialize (H F2_1 F2_0). unfold magma_op, reff96_inst, reff96_op in H. discriminate H. Qed.

Lemma reff96_not907 : ~ @Equation907 Fin2 reff96_inst.
Proof. unfold Equation907. intro H. specialize (H F2_1 F2_0). unfold magma_op, reff96_inst, reff96_op in H. discriminate H. Qed.

Lemma reff96_not909 : ~ @Equation909 Fin2 reff96_inst.
Proof. unfold Equation909. intro H. specialize (H F2_1 F2_0). unfold magma_op, reff96_inst, reff96_op in H. discriminate H. Qed.

Lemma reff96_not910 : ~ @Equation910 Fin2 reff96_inst.
Proof. unfold Equation910. intro H. specialize (H F2_1 F2_0). unfold magma_op, reff96_inst, reff96_op in H. discriminate H. Qed.

Lemma reff96_not916 : ~ @Equation916 Fin2 reff96_inst.
Proof. unfold Equation916. intro H. specialize (H F2_1 F2_0). unfold magma_op, reff96_inst, reff96_op in H. discriminate H. Qed.

Lemma reff96_not917 : ~ @Equation917 Fin2 reff96_inst.
Proof. unfold Equation917. intro H. specialize (H F2_1 F2_0). unfold magma_op, reff96_inst, reff96_op in H. discriminate H. Qed.

Lemma reff96_not919 : ~ @Equation919 Fin2 reff96_inst.
Proof. unfold Equation919. intro H. specialize (H F2_1 F2_0). unfold magma_op, reff96_inst, reff96_op in H. discriminate H. Qed.

Lemma reff96_not1021 : ~ @Equation1021 Fin2 reff96_inst.
Proof. unfold Equation1021. intro H. specialize (H F2_1 F2_0). unfold magma_op, reff96_inst, reff96_op in H. discriminate H. Qed.

Lemma reff96_not1022 : ~ @Equation1022 Fin2 reff96_inst.
Proof. unfold Equation1022. intro H. specialize (H F2_1 F2_0). unfold magma_op, reff96_inst, reff96_op in H. discriminate H. Qed.

Lemma reff96_not1023 : ~ @Equation1023 Fin2 reff96_inst.
Proof. unfold Equation1023. intro H. specialize (H F2_1 F2_0). unfold magma_op, reff96_inst, reff96_op in H. discriminate H. Qed.

Lemma reff96_not1025 : ~ @Equation1025 Fin2 reff96_inst.
Proof. unfold Equation1025. intro H. specialize (H F2_1 F2_0). unfold magma_op, reff96_inst, reff96_op in H. discriminate H. Qed.

Lemma reff96_not1026 : ~ @Equation1026 Fin2 reff96_inst.
Proof. unfold Equation1026. intro H. specialize (H F2_1 F2_0). unfold magma_op, reff96_inst, reff96_op in H. discriminate H. Qed.

Lemma reff96_not1028 : ~ @Equation1028 Fin2 reff96_inst.
Proof. unfold Equation1028. intro H. specialize (H F2_1 F2_0). unfold magma_op, reff96_inst, reff96_op in H. discriminate H. Qed.

Lemma reff96_not1029 : ~ @Equation1029 Fin2 reff96_inst.
Proof. unfold Equation1029. intro H. specialize (H F2_1 F2_0). unfold magma_op, reff96_inst, reff96_op in H. discriminate H. Qed.

Lemma reff96_not1035 : ~ @Equation1035 Fin2 reff96_inst.
Proof. unfold Equation1035. intro H. specialize (H F2_1 F2_0). unfold magma_op, reff96_inst, reff96_op in H. discriminate H. Qed.

Lemma reff96_not1036 : ~ @Equation1036 Fin2 reff96_inst.
Proof. unfold Equation1036. intro H. specialize (H F2_1 F2_0). unfold magma_op, reff96_inst, reff96_op in H. discriminate H. Qed.

Lemma reff96_not1038 : ~ @Equation1038 Fin2 reff96_inst.
Proof. unfold Equation1038. intro H. specialize (H F2_1 F2_0). unfold magma_op, reff96_inst, reff96_op in H. discriminate H. Qed.

Lemma reff96_not1039 : ~ @Equation1039 Fin2 reff96_inst.
Proof. unfold Equation1039. intro H. specialize (H F2_1 F2_0). unfold magma_op, reff96_inst, reff96_op in H. discriminate H. Qed.

Lemma reff96_not1045 : ~ @Equation1045 Fin2 reff96_inst.
Proof. unfold Equation1045. intro H. specialize (H F2_1 F2_0). unfold magma_op, reff96_inst, reff96_op in H. discriminate H. Qed.

Lemma reff96_not1046 : ~ @Equation1046 Fin2 reff96_inst.
Proof. unfold Equation1046. intro H. specialize (H F2_1 F2_0). unfold magma_op, reff96_inst, reff96_op in H. discriminate H. Qed.

Lemma reff96_not1048 : ~ @Equation1048 Fin2 reff96_inst.
Proof. unfold Equation1048. intro H. specialize (H F2_1 F2_0). unfold magma_op, reff96_inst, reff96_op in H. discriminate H. Qed.

Lemma reff96_not1049 : ~ @Equation1049 Fin2 reff96_inst.
Proof. unfold Equation1049. intro H. specialize (H F2_1 F2_0). unfold magma_op, reff96_inst, reff96_op in H. discriminate H. Qed.

Lemma reff96_not1072 : ~ @Equation1072 Fin2 reff96_inst.
Proof. unfold Equation1072. intro H. specialize (H F2_1 F2_0). unfold magma_op, reff96_inst, reff96_op in H. discriminate H. Qed.

Lemma reff96_not1073 : ~ @Equation1073 Fin2 reff96_inst.
Proof. unfold Equation1073. intro H. specialize (H F2_1 F2_0). unfold magma_op, reff96_inst, reff96_op in H. discriminate H. Qed.

Lemma reff96_not1075 : ~ @Equation1075 Fin2 reff96_inst.
Proof. unfold Equation1075. intro H. specialize (H F2_1 F2_0). unfold magma_op, reff96_inst, reff96_op in H. discriminate H. Qed.

Lemma reff96_not1076 : ~ @Equation1076 Fin2 reff96_inst.
Proof. unfold Equation1076. intro H. specialize (H F2_1 F2_0). unfold magma_op, reff96_inst, reff96_op in H. discriminate H. Qed.

Lemma reff96_not1082 : ~ @Equation1082 Fin2 reff96_inst.
Proof. unfold Equation1082. intro H. specialize (H F2_1 F2_0). unfold magma_op, reff96_inst, reff96_op in H. discriminate H. Qed.

Lemma reff96_not1083 : ~ @Equation1083 Fin2 reff96_inst.
Proof. unfold Equation1083. intro H. specialize (H F2_1 F2_0). unfold magma_op, reff96_inst, reff96_op in H. discriminate H. Qed.

Lemma reff96_not1085 : ~ @Equation1085 Fin2 reff96_inst.
Proof. unfold Equation1085. intro H. specialize (H F2_1 F2_0). unfold magma_op, reff96_inst, reff96_op in H. discriminate H. Qed.

Lemma reff96_not1086 : ~ @Equation1086 Fin2 reff96_inst.
Proof. unfold Equation1086. intro H. specialize (H F2_1 F2_0). unfold magma_op, reff96_inst, reff96_op in H. discriminate H. Qed.

Lemma reff96_not1109 : ~ @Equation1109 Fin2 reff96_inst.
Proof. unfold Equation1109. intro H. specialize (H F2_1 F2_0). unfold magma_op, reff96_inst, reff96_op in H. discriminate H. Qed.

Lemma reff96_not1110 : ~ @Equation1110 Fin2 reff96_inst.
Proof. unfold Equation1110. intro H. specialize (H F2_1 F2_0). unfold magma_op, reff96_inst, reff96_op in H. discriminate H. Qed.

Lemma reff96_not1112 : ~ @Equation1112 Fin2 reff96_inst.
Proof. unfold Equation1112. intro H. specialize (H F2_1 F2_0). unfold magma_op, reff96_inst, reff96_op in H. discriminate H. Qed.

Lemma reff96_not1113 : ~ @Equation1113 Fin2 reff96_inst.
Proof. unfold Equation1113. intro H. specialize (H F2_1 F2_0). unfold magma_op, reff96_inst, reff96_op in H. discriminate H. Qed.

Lemma reff96_not1119 : ~ @Equation1119 Fin2 reff96_inst.
Proof. unfold Equation1119. intro H. specialize (H F2_1 F2_0). unfold magma_op, reff96_inst, reff96_op in H. discriminate H. Qed.

Lemma reff96_not1120 : ~ @Equation1120 Fin2 reff96_inst.
Proof. unfold Equation1120. intro H. specialize (H F2_1 F2_0). unfold magma_op, reff96_inst, reff96_op in H. discriminate H. Qed.

Lemma reff96_not1122 : ~ @Equation1122 Fin2 reff96_inst.
Proof. unfold Equation1122. intro H. specialize (H F2_1 F2_0). unfold magma_op, reff96_inst, reff96_op in H. discriminate H. Qed.

Lemma reff96_not1224 : ~ @Equation1224 Fin2 reff96_inst.
Proof. unfold Equation1224. intro H. specialize (H F2_1 F2_0). unfold magma_op, reff96_inst, reff96_op in H. discriminate H. Qed.

Lemma reff96_not1225 : ~ @Equation1225 Fin2 reff96_inst.
Proof. unfold Equation1225. intro H. specialize (H F2_1 F2_0). unfold magma_op, reff96_inst, reff96_op in H. discriminate H. Qed.

Lemma reff96_not1226 : ~ @Equation1226 Fin2 reff96_inst.
Proof. unfold Equation1226. intro H. specialize (H F2_1 F2_0). unfold magma_op, reff96_inst, reff96_op in H. discriminate H. Qed.

Lemma reff96_not1228 : ~ @Equation1228 Fin2 reff96_inst.
Proof. unfold Equation1228. intro H. specialize (H F2_1 F2_0). unfold magma_op, reff96_inst, reff96_op in H. discriminate H. Qed.

Lemma reff96_not1229 : ~ @Equation1229 Fin2 reff96_inst.
Proof. unfold Equation1229. intro H. specialize (H F2_1 F2_0). unfold magma_op, reff96_inst, reff96_op in H. discriminate H. Qed.

Lemma reff96_not1231 : ~ @Equation1231 Fin2 reff96_inst.
Proof. unfold Equation1231. intro H. specialize (H F2_1 F2_0). unfold magma_op, reff96_inst, reff96_op in H. discriminate H. Qed.

Lemma reff96_not1232 : ~ @Equation1232 Fin2 reff96_inst.
Proof. unfold Equation1232. intro H. specialize (H F2_1 F2_0). unfold magma_op, reff96_inst, reff96_op in H. discriminate H. Qed.

Lemma reff96_not1238 : ~ @Equation1238 Fin2 reff96_inst.
Proof. unfold Equation1238. intro H. specialize (H F2_1 F2_0). unfold magma_op, reff96_inst, reff96_op in H. discriminate H. Qed.

Lemma reff96_not1239 : ~ @Equation1239 Fin2 reff96_inst.
Proof. unfold Equation1239. intro H. specialize (H F2_1 F2_0). unfold magma_op, reff96_inst, reff96_op in H. discriminate H. Qed.

Lemma reff96_not1241 : ~ @Equation1241 Fin2 reff96_inst.
Proof. unfold Equation1241. intro H. specialize (H F2_1 F2_0). unfold magma_op, reff96_inst, reff96_op in H. discriminate H. Qed.

Lemma reff96_not1242 : ~ @Equation1242 Fin2 reff96_inst.
Proof. unfold Equation1242. intro H. specialize (H F2_1 F2_0). unfold magma_op, reff96_inst, reff96_op in H. discriminate H. Qed.

Lemma reff96_not1248 : ~ @Equation1248 Fin2 reff96_inst.
Proof. unfold Equation1248. intro H. specialize (H F2_1 F2_0). unfold magma_op, reff96_inst, reff96_op in H. discriminate H. Qed.

Lemma reff96_not1249 : ~ @Equation1249 Fin2 reff96_inst.
Proof. unfold Equation1249. intro H. specialize (H F2_1 F2_0). unfold magma_op, reff96_inst, reff96_op in H. discriminate H. Qed.

Lemma reff96_not1251 : ~ @Equation1251 Fin2 reff96_inst.
Proof. unfold Equation1251. intro H. specialize (H F2_1 F2_0). unfold magma_op, reff96_inst, reff96_op in H. discriminate H. Qed.

Lemma reff96_not1252 : ~ @Equation1252 Fin2 reff96_inst.
Proof. unfold Equation1252. intro H. specialize (H F2_1 F2_0). unfold magma_op, reff96_inst, reff96_op in H. discriminate H. Qed.

Lemma reff96_not1275 : ~ @Equation1275 Fin2 reff96_inst.
Proof. unfold Equation1275. intro H. specialize (H F2_1 F2_0). unfold magma_op, reff96_inst, reff96_op in H. discriminate H. Qed.

Lemma reff96_not1276 : ~ @Equation1276 Fin2 reff96_inst.
Proof. unfold Equation1276. intro H. specialize (H F2_1 F2_0). unfold magma_op, reff96_inst, reff96_op in H. discriminate H. Qed.

Lemma reff96_not1278 : ~ @Equation1278 Fin2 reff96_inst.
Proof. unfold Equation1278. intro H. specialize (H F2_1 F2_0). unfold magma_op, reff96_inst, reff96_op in H. discriminate H. Qed.

Lemma reff96_not1279 : ~ @Equation1279 Fin2 reff96_inst.
Proof. unfold Equation1279. intro H. specialize (H F2_1 F2_0). unfold magma_op, reff96_inst, reff96_op in H. discriminate H. Qed.

Lemma reff96_not1285 : ~ @Equation1285 Fin2 reff96_inst.
Proof. unfold Equation1285. intro H. specialize (H F2_1 F2_0). unfold magma_op, reff96_inst, reff96_op in H. discriminate H. Qed.

Lemma reff96_not1286 : ~ @Equation1286 Fin2 reff96_inst.
Proof. unfold Equation1286. intro H. specialize (H F2_1 F2_0). unfold magma_op, reff96_inst, reff96_op in H. discriminate H. Qed.

Lemma reff96_not1288 : ~ @Equation1288 Fin2 reff96_inst.
Proof. unfold Equation1288. intro H. specialize (H F2_1 F2_0). unfold magma_op, reff96_inst, reff96_op in H. discriminate H. Qed.

Lemma reff96_not1289 : ~ @Equation1289 Fin2 reff96_inst.
Proof. unfold Equation1289. intro H. specialize (H F2_1 F2_0). unfold magma_op, reff96_inst, reff96_op in H. discriminate H. Qed.

Lemma reff96_not1312 : ~ @Equation1312 Fin2 reff96_inst.
Proof. unfold Equation1312. intro H. specialize (H F2_1 F2_0). unfold magma_op, reff96_inst, reff96_op in H. discriminate H. Qed.

Lemma reff96_not1313 : ~ @Equation1313 Fin2 reff96_inst.
Proof. unfold Equation1313. intro H. specialize (H F2_1 F2_0). unfold magma_op, reff96_inst, reff96_op in H. discriminate H. Qed.

Lemma reff96_not1315 : ~ @Equation1315 Fin2 reff96_inst.
Proof. unfold Equation1315. intro H. specialize (H F2_1 F2_0). unfold magma_op, reff96_inst, reff96_op in H. discriminate H. Qed.

Lemma reff96_not1316 : ~ @Equation1316 Fin2 reff96_inst.
Proof. unfold Equation1316. intro H. specialize (H F2_1 F2_0). unfold magma_op, reff96_inst, reff96_op in H. discriminate H. Qed.

Lemma reff96_not1322 : ~ @Equation1322 Fin2 reff96_inst.
Proof. unfold Equation1322. intro H. specialize (H F2_1 F2_0). unfold magma_op, reff96_inst, reff96_op in H. discriminate H. Qed.

Lemma reff96_not1323 : ~ @Equation1323 Fin2 reff96_inst.
Proof. unfold Equation1323. intro H. specialize (H F2_1 F2_0). unfold magma_op, reff96_inst, reff96_op in H. discriminate H. Qed.

Lemma reff96_not1325 : ~ @Equation1325 Fin2 reff96_inst.
Proof. unfold Equation1325. intro H. specialize (H F2_1 F2_0). unfold magma_op, reff96_inst, reff96_op in H. discriminate H. Qed.

Lemma reff96_not1427 : ~ @Equation1427 Fin2 reff96_inst.
Proof. unfold Equation1427. intro H. specialize (H F2_1 F2_0). unfold magma_op, reff96_inst, reff96_op in H. discriminate H. Qed.

Lemma reff96_not1428 : ~ @Equation1428 Fin2 reff96_inst.
Proof. unfold Equation1428. intro H. specialize (H F2_1 F2_0). unfold magma_op, reff96_inst, reff96_op in H. discriminate H. Qed.

Lemma reff96_not1429 : ~ @Equation1429 Fin2 reff96_inst.
Proof. unfold Equation1429. intro H. specialize (H F2_1 F2_0). unfold magma_op, reff96_inst, reff96_op in H. discriminate H. Qed.

Lemma reff96_not1431 : ~ @Equation1431 Fin2 reff96_inst.
Proof. unfold Equation1431. intro H. specialize (H F2_1 F2_0). unfold magma_op, reff96_inst, reff96_op in H. discriminate H. Qed.

Lemma reff96_not1432 : ~ @Equation1432 Fin2 reff96_inst.
Proof. unfold Equation1432. intro H. specialize (H F2_1 F2_0). unfold magma_op, reff96_inst, reff96_op in H. discriminate H. Qed.

Lemma reff96_not1434 : ~ @Equation1434 Fin2 reff96_inst.
Proof. unfold Equation1434. intro H. specialize (H F2_1 F2_0). unfold magma_op, reff96_inst, reff96_op in H. discriminate H. Qed.

Lemma reff96_not1435 : ~ @Equation1435 Fin2 reff96_inst.
Proof. unfold Equation1435. intro H. specialize (H F2_1 F2_0). unfold magma_op, reff96_inst, reff96_op in H. discriminate H. Qed.

Lemma reff96_not1441 : ~ @Equation1441 Fin2 reff96_inst.
Proof. unfold Equation1441. intro H. specialize (H F2_1 F2_0). unfold magma_op, reff96_inst, reff96_op in H. discriminate H. Qed.

Lemma reff96_not1442 : ~ @Equation1442 Fin2 reff96_inst.
Proof. unfold Equation1442. intro H. specialize (H F2_1 F2_0). unfold magma_op, reff96_inst, reff96_op in H. discriminate H. Qed.

Lemma reff96_not1444 : ~ @Equation1444 Fin2 reff96_inst.
Proof. unfold Equation1444. intro H. specialize (H F2_1 F2_0). unfold magma_op, reff96_inst, reff96_op in H. discriminate H. Qed.

Lemma reff96_not1445 : ~ @Equation1445 Fin2 reff96_inst.
Proof. unfold Equation1445. intro H. specialize (H F2_1 F2_0). unfold magma_op, reff96_inst, reff96_op in H. discriminate H. Qed.

Lemma reff96_not1451 : ~ @Equation1451 Fin2 reff96_inst.
Proof. unfold Equation1451. intro H. specialize (H F2_1 F2_0). unfold magma_op, reff96_inst, reff96_op in H. discriminate H. Qed.

Lemma reff96_not1452 : ~ @Equation1452 Fin2 reff96_inst.
Proof. unfold Equation1452. intro H. specialize (H F2_1 F2_0). unfold magma_op, reff96_inst, reff96_op in H. discriminate H. Qed.

Lemma reff96_not1454 : ~ @Equation1454 Fin2 reff96_inst.
Proof. unfold Equation1454. intro H. specialize (H F2_1 F2_0). unfold magma_op, reff96_inst, reff96_op in H. discriminate H. Qed.

Lemma reff96_not1455 : ~ @Equation1455 Fin2 reff96_inst.
Proof. unfold Equation1455. intro H. specialize (H F2_1 F2_0). unfold magma_op, reff96_inst, reff96_op in H. discriminate H. Qed.

Lemma reff96_not1478 : ~ @Equation1478 Fin2 reff96_inst.
Proof. unfold Equation1478. intro H. specialize (H F2_1 F2_0). unfold magma_op, reff96_inst, reff96_op in H. discriminate H. Qed.

Lemma reff96_not1479 : ~ @Equation1479 Fin2 reff96_inst.
Proof. unfold Equation1479. intro H. specialize (H F2_1 F2_0). unfold magma_op, reff96_inst, reff96_op in H. discriminate H. Qed.

Lemma reff96_not1481 : ~ @Equation1481 Fin2 reff96_inst.
Proof. unfold Equation1481. intro H. specialize (H F2_1 F2_0). unfold magma_op, reff96_inst, reff96_op in H. discriminate H. Qed.

Lemma reff96_not1482 : ~ @Equation1482 Fin2 reff96_inst.
Proof. unfold Equation1482. intro H. specialize (H F2_1 F2_0). unfold magma_op, reff96_inst, reff96_op in H. discriminate H. Qed.

Lemma reff96_not1488 : ~ @Equation1488 Fin2 reff96_inst.
Proof. unfold Equation1488. intro H. specialize (H F2_1 F2_0). unfold magma_op, reff96_inst, reff96_op in H. discriminate H. Qed.

Lemma reff96_not1489 : ~ @Equation1489 Fin2 reff96_inst.
Proof. unfold Equation1489. intro H. specialize (H F2_1 F2_0). unfold magma_op, reff96_inst, reff96_op in H. discriminate H. Qed.

Lemma reff96_not1491 : ~ @Equation1491 Fin2 reff96_inst.
Proof. unfold Equation1491. intro H. specialize (H F2_1 F2_0). unfold magma_op, reff96_inst, reff96_op in H. discriminate H. Qed.

Lemma reff96_not1492 : ~ @Equation1492 Fin2 reff96_inst.
Proof. unfold Equation1492. intro H. specialize (H F2_1 F2_0). unfold magma_op, reff96_inst, reff96_op in H. discriminate H. Qed.

Lemma reff96_not1515 : ~ @Equation1515 Fin2 reff96_inst.
Proof. unfold Equation1515. intro H. specialize (H F2_1 F2_0). unfold magma_op, reff96_inst, reff96_op in H. discriminate H. Qed.

Lemma reff96_not1516 : ~ @Equation1516 Fin2 reff96_inst.
Proof. unfold Equation1516. intro H. specialize (H F2_1 F2_0). unfold magma_op, reff96_inst, reff96_op in H. discriminate H. Qed.

Lemma reff96_not1518 : ~ @Equation1518 Fin2 reff96_inst.
Proof. unfold Equation1518. intro H. specialize (H F2_1 F2_0). unfold magma_op, reff96_inst, reff96_op in H. discriminate H. Qed.

Lemma reff96_not1519 : ~ @Equation1519 Fin2 reff96_inst.
Proof. unfold Equation1519. intro H. specialize (H F2_1 F2_0). unfold magma_op, reff96_inst, reff96_op in H. discriminate H. Qed.

Lemma reff96_not1525 : ~ @Equation1525 Fin2 reff96_inst.
Proof. unfold Equation1525. intro H. specialize (H F2_1 F2_0). unfold magma_op, reff96_inst, reff96_op in H. discriminate H. Qed.

Lemma reff96_not1526 : ~ @Equation1526 Fin2 reff96_inst.
Proof. unfold Equation1526. intro H. specialize (H F2_1 F2_0). unfold magma_op, reff96_inst, reff96_op in H. discriminate H. Qed.

Lemma reff96_not1528 : ~ @Equation1528 Fin2 reff96_inst.
Proof. unfold Equation1528. intro H. specialize (H F2_1 F2_0). unfold magma_op, reff96_inst, reff96_op in H. discriminate H. Qed.

Lemma reff96_not1630 : ~ @Equation1630 Fin2 reff96_inst.
Proof. unfold Equation1630. intro H. specialize (H F2_1 F2_0). unfold magma_op, reff96_inst, reff96_op in H. discriminate H. Qed.

Lemma reff96_not1631 : ~ @Equation1631 Fin2 reff96_inst.
Proof. unfold Equation1631. intro H. specialize (H F2_1 F2_0). unfold magma_op, reff96_inst, reff96_op in H. discriminate H. Qed.

Lemma reff96_not1632 : ~ @Equation1632 Fin2 reff96_inst.
Proof. unfold Equation1632. intro H. specialize (H F2_1 F2_0). unfold magma_op, reff96_inst, reff96_op in H. discriminate H. Qed.

Lemma reff96_not1634 : ~ @Equation1634 Fin2 reff96_inst.
Proof. unfold Equation1634. intro H. specialize (H F2_1 F2_0). unfold magma_op, reff96_inst, reff96_op in H. discriminate H. Qed.

Lemma reff96_not1635 : ~ @Equation1635 Fin2 reff96_inst.
Proof. unfold Equation1635. intro H. specialize (H F2_1 F2_0). unfold magma_op, reff96_inst, reff96_op in H. discriminate H. Qed.

Lemma reff96_not1637 : ~ @Equation1637 Fin2 reff96_inst.
Proof. unfold Equation1637. intro H. specialize (H F2_1 F2_0). unfold magma_op, reff96_inst, reff96_op in H. discriminate H. Qed.

Lemma reff96_not1638 : ~ @Equation1638 Fin2 reff96_inst.
Proof. unfold Equation1638. intro H. specialize (H F2_1 F2_0). unfold magma_op, reff96_inst, reff96_op in H. discriminate H. Qed.

Lemma reff96_not1644 : ~ @Equation1644 Fin2 reff96_inst.
Proof. unfold Equation1644. intro H. specialize (H F2_1 F2_0). unfold magma_op, reff96_inst, reff96_op in H. discriminate H. Qed.

Lemma reff96_not1645 : ~ @Equation1645 Fin2 reff96_inst.
Proof. unfold Equation1645. intro H. specialize (H F2_1 F2_0). unfold magma_op, reff96_inst, reff96_op in H. discriminate H. Qed.

Lemma reff96_not1647 : ~ @Equation1647 Fin2 reff96_inst.
Proof. unfold Equation1647. intro H. specialize (H F2_1 F2_0). unfold magma_op, reff96_inst, reff96_op in H. discriminate H. Qed.

Lemma reff96_not1648 : ~ @Equation1648 Fin2 reff96_inst.
Proof. unfold Equation1648. intro H. specialize (H F2_1 F2_0). unfold magma_op, reff96_inst, reff96_op in H. discriminate H. Qed.

Lemma reff96_not1654 : ~ @Equation1654 Fin2 reff96_inst.
Proof. unfold Equation1654. intro H. specialize (H F2_1 F2_0). unfold magma_op, reff96_inst, reff96_op in H. discriminate H. Qed.

Lemma reff96_not1655 : ~ @Equation1655 Fin2 reff96_inst.
Proof. unfold Equation1655. intro H. specialize (H F2_1 F2_0). unfold magma_op, reff96_inst, reff96_op in H. discriminate H. Qed.

Lemma reff96_not1657 : ~ @Equation1657 Fin2 reff96_inst.
Proof. unfold Equation1657. intro H. specialize (H F2_1 F2_0). unfold magma_op, reff96_inst, reff96_op in H. discriminate H. Qed.

Lemma reff96_not1658 : ~ @Equation1658 Fin2 reff96_inst.
Proof. unfold Equation1658. intro H. specialize (H F2_1 F2_0). unfold magma_op, reff96_inst, reff96_op in H. discriminate H. Qed.

Lemma reff96_not1681 : ~ @Equation1681 Fin2 reff96_inst.
Proof. unfold Equation1681. intro H. specialize (H F2_1 F2_0). unfold magma_op, reff96_inst, reff96_op in H. discriminate H. Qed.

Lemma reff96_not1682 : ~ @Equation1682 Fin2 reff96_inst.
Proof. unfold Equation1682. intro H. specialize (H F2_1 F2_0). unfold magma_op, reff96_inst, reff96_op in H. discriminate H. Qed.

Lemma reff96_not1684 : ~ @Equation1684 Fin2 reff96_inst.
Proof. unfold Equation1684. intro H. specialize (H F2_1 F2_0). unfold magma_op, reff96_inst, reff96_op in H. discriminate H. Qed.

Lemma reff96_not1685 : ~ @Equation1685 Fin2 reff96_inst.
Proof. unfold Equation1685. intro H. specialize (H F2_1 F2_0). unfold magma_op, reff96_inst, reff96_op in H. discriminate H. Qed.

Lemma reff96_not1691 : ~ @Equation1691 Fin2 reff96_inst.
Proof. unfold Equation1691. intro H. specialize (H F2_1 F2_0). unfold magma_op, reff96_inst, reff96_op in H. discriminate H. Qed.

Lemma reff96_not1692 : ~ @Equation1692 Fin2 reff96_inst.
Proof. unfold Equation1692. intro H. specialize (H F2_1 F2_0). unfold magma_op, reff96_inst, reff96_op in H. discriminate H. Qed.

Lemma reff96_not1694 : ~ @Equation1694 Fin2 reff96_inst.
Proof. unfold Equation1694. intro H. specialize (H F2_1 F2_0). unfold magma_op, reff96_inst, reff96_op in H. discriminate H. Qed.

Lemma reff96_not1695 : ~ @Equation1695 Fin2 reff96_inst.
Proof. unfold Equation1695. intro H. specialize (H F2_1 F2_0). unfold magma_op, reff96_inst, reff96_op in H. discriminate H. Qed.

Lemma reff96_not1718 : ~ @Equation1718 Fin2 reff96_inst.
Proof. unfold Equation1718. intro H. specialize (H F2_1 F2_0). unfold magma_op, reff96_inst, reff96_op in H. discriminate H. Qed.

Lemma reff96_not1719 : ~ @Equation1719 Fin2 reff96_inst.
Proof. unfold Equation1719. intro H. specialize (H F2_1 F2_0). unfold magma_op, reff96_inst, reff96_op in H. discriminate H. Qed.

Lemma reff96_not1721 : ~ @Equation1721 Fin2 reff96_inst.
Proof. unfold Equation1721. intro H. specialize (H F2_1 F2_0). unfold magma_op, reff96_inst, reff96_op in H. discriminate H. Qed.

Lemma reff96_not1722 : ~ @Equation1722 Fin2 reff96_inst.
Proof. unfold Equation1722. intro H. specialize (H F2_1 F2_0). unfold magma_op, reff96_inst, reff96_op in H. discriminate H. Qed.

Lemma reff96_not1728 : ~ @Equation1728 Fin2 reff96_inst.
Proof. unfold Equation1728. intro H. specialize (H F2_1 F2_0). unfold magma_op, reff96_inst, reff96_op in H. discriminate H. Qed.

Lemma reff96_not1729 : ~ @Equation1729 Fin2 reff96_inst.
Proof. unfold Equation1729. intro H. specialize (H F2_1 F2_0). unfold magma_op, reff96_inst, reff96_op in H. discriminate H. Qed.

Lemma reff96_not1731 : ~ @Equation1731 Fin2 reff96_inst.
Proof. unfold Equation1731. intro H. specialize (H F2_1 F2_0). unfold magma_op, reff96_inst, reff96_op in H. discriminate H. Qed.

Lemma reff96_not1833 : ~ @Equation1833 Fin2 reff96_inst.
Proof. unfold Equation1833. intro H. specialize (H F2_1 F2_0). unfold magma_op, reff96_inst, reff96_op in H. discriminate H. Qed.

Lemma reff96_not1834 : ~ @Equation1834 Fin2 reff96_inst.
Proof. unfold Equation1834. intro H. specialize (H F2_1 F2_0). unfold magma_op, reff96_inst, reff96_op in H. discriminate H. Qed.

Lemma reff96_not1835 : ~ @Equation1835 Fin2 reff96_inst.
Proof. unfold Equation1835. intro H. specialize (H F2_1 F2_0). unfold magma_op, reff96_inst, reff96_op in H. discriminate H. Qed.

Lemma reff96_not1837 : ~ @Equation1837 Fin2 reff96_inst.
Proof. unfold Equation1837. intro H. specialize (H F2_1 F2_0). unfold magma_op, reff96_inst, reff96_op in H. discriminate H. Qed.

Lemma reff96_not1838 : ~ @Equation1838 Fin2 reff96_inst.
Proof. unfold Equation1838. intro H. specialize (H F2_1 F2_0). unfold magma_op, reff96_inst, reff96_op in H. discriminate H. Qed.

Lemma reff96_not1840 : ~ @Equation1840 Fin2 reff96_inst.
Proof. unfold Equation1840. intro H. specialize (H F2_1 F2_0). unfold magma_op, reff96_inst, reff96_op in H. discriminate H. Qed.

Lemma reff96_not1841 : ~ @Equation1841 Fin2 reff96_inst.
Proof. unfold Equation1841. intro H. specialize (H F2_1 F2_0). unfold magma_op, reff96_inst, reff96_op in H. discriminate H. Qed.

Lemma reff96_not1847 : ~ @Equation1847 Fin2 reff96_inst.
Proof. unfold Equation1847. intro H. specialize (H F2_1 F2_0). unfold magma_op, reff96_inst, reff96_op in H. discriminate H. Qed.

Lemma reff96_not1848 : ~ @Equation1848 Fin2 reff96_inst.
Proof. unfold Equation1848. intro H. specialize (H F2_1 F2_0). unfold magma_op, reff96_inst, reff96_op in H. discriminate H. Qed.

Lemma reff96_not1850 : ~ @Equation1850 Fin2 reff96_inst.
Proof. unfold Equation1850. intro H. specialize (H F2_1 F2_0). unfold magma_op, reff96_inst, reff96_op in H. discriminate H. Qed.

Lemma reff96_not1851 : ~ @Equation1851 Fin2 reff96_inst.
Proof. unfold Equation1851. intro H. specialize (H F2_1 F2_0). unfold magma_op, reff96_inst, reff96_op in H. discriminate H. Qed.

Lemma reff96_not1857 : ~ @Equation1857 Fin2 reff96_inst.
Proof. unfold Equation1857. intro H. specialize (H F2_1 F2_0). unfold magma_op, reff96_inst, reff96_op in H. discriminate H. Qed.

Lemma reff96_not1858 : ~ @Equation1858 Fin2 reff96_inst.
Proof. unfold Equation1858. intro H. specialize (H F2_1 F2_0). unfold magma_op, reff96_inst, reff96_op in H. discriminate H. Qed.

Lemma reff96_not1860 : ~ @Equation1860 Fin2 reff96_inst.
Proof. unfold Equation1860. intro H. specialize (H F2_1 F2_0). unfold magma_op, reff96_inst, reff96_op in H. discriminate H. Qed.

Lemma reff96_not1861 : ~ @Equation1861 Fin2 reff96_inst.
Proof. unfold Equation1861. intro H. specialize (H F2_1 F2_0). unfold magma_op, reff96_inst, reff96_op in H. discriminate H. Qed.

Lemma reff96_not1884 : ~ @Equation1884 Fin2 reff96_inst.
Proof. unfold Equation1884. intro H. specialize (H F2_1 F2_0). unfold magma_op, reff96_inst, reff96_op in H. discriminate H. Qed.

Lemma reff96_not1885 : ~ @Equation1885 Fin2 reff96_inst.
Proof. unfold Equation1885. intro H. specialize (H F2_1 F2_0). unfold magma_op, reff96_inst, reff96_op in H. discriminate H. Qed.

Lemma reff96_not1887 : ~ @Equation1887 Fin2 reff96_inst.
Proof. unfold Equation1887. intro H. specialize (H F2_1 F2_0). unfold magma_op, reff96_inst, reff96_op in H. discriminate H. Qed.

Lemma reff96_not1888 : ~ @Equation1888 Fin2 reff96_inst.
Proof. unfold Equation1888. intro H. specialize (H F2_1 F2_0). unfold magma_op, reff96_inst, reff96_op in H. discriminate H. Qed.

Lemma reff96_not1894 : ~ @Equation1894 Fin2 reff96_inst.
Proof. unfold Equation1894. intro H. specialize (H F2_1 F2_0). unfold magma_op, reff96_inst, reff96_op in H. discriminate H. Qed.

Lemma reff96_not1895 : ~ @Equation1895 Fin2 reff96_inst.
Proof. unfold Equation1895. intro H. specialize (H F2_1 F2_0). unfold magma_op, reff96_inst, reff96_op in H. discriminate H. Qed.

Lemma reff96_not1897 : ~ @Equation1897 Fin2 reff96_inst.
Proof. unfold Equation1897. intro H. specialize (H F2_1 F2_0). unfold magma_op, reff96_inst, reff96_op in H. discriminate H. Qed.

Lemma reff96_not1898 : ~ @Equation1898 Fin2 reff96_inst.
Proof. unfold Equation1898. intro H. specialize (H F2_1 F2_0). unfold magma_op, reff96_inst, reff96_op in H. discriminate H. Qed.

Lemma reff96_not1921 : ~ @Equation1921 Fin2 reff96_inst.
Proof. unfold Equation1921. intro H. specialize (H F2_1 F2_0). unfold magma_op, reff96_inst, reff96_op in H. discriminate H. Qed.

Lemma reff96_not1922 : ~ @Equation1922 Fin2 reff96_inst.
Proof. unfold Equation1922. intro H. specialize (H F2_1 F2_0). unfold magma_op, reff96_inst, reff96_op in H. discriminate H. Qed.

Lemma reff96_not1924 : ~ @Equation1924 Fin2 reff96_inst.
Proof. unfold Equation1924. intro H. specialize (H F2_1 F2_0). unfold magma_op, reff96_inst, reff96_op in H. discriminate H. Qed.

Lemma reff96_not1925 : ~ @Equation1925 Fin2 reff96_inst.
Proof. unfold Equation1925. intro H. specialize (H F2_1 F2_0). unfold magma_op, reff96_inst, reff96_op in H. discriminate H. Qed.

Lemma reff96_not1931 : ~ @Equation1931 Fin2 reff96_inst.
Proof. unfold Equation1931. intro H. specialize (H F2_1 F2_0). unfold magma_op, reff96_inst, reff96_op in H. discriminate H. Qed.

Lemma reff96_not1932 : ~ @Equation1932 Fin2 reff96_inst.
Proof. unfold Equation1932. intro H. specialize (H F2_1 F2_0). unfold magma_op, reff96_inst, reff96_op in H. discriminate H. Qed.

Lemma reff96_not1934 : ~ @Equation1934 Fin2 reff96_inst.
Proof. unfold Equation1934. intro H. specialize (H F2_1 F2_0). unfold magma_op, reff96_inst, reff96_op in H. discriminate H. Qed.

Lemma reff96_not2036 : ~ @Equation2036 Fin2 reff96_inst.
Proof. unfold Equation2036. intro H. specialize (H F2_1 F2_0). unfold magma_op, reff96_inst, reff96_op in H. discriminate H. Qed.

Lemma reff96_not2037 : ~ @Equation2037 Fin2 reff96_inst.
Proof. unfold Equation2037. intro H. specialize (H F2_1 F2_0). unfold magma_op, reff96_inst, reff96_op in H. discriminate H. Qed.

Lemma reff96_not2038 : ~ @Equation2038 Fin2 reff96_inst.
Proof. unfold Equation2038. intro H. specialize (H F2_1 F2_0). unfold magma_op, reff96_inst, reff96_op in H. discriminate H. Qed.

Lemma reff96_not2040 : ~ @Equation2040 Fin2 reff96_inst.
Proof. unfold Equation2040. intro H. specialize (H F2_1 F2_0). unfold magma_op, reff96_inst, reff96_op in H. discriminate H. Qed.

Lemma reff96_not2041 : ~ @Equation2041 Fin2 reff96_inst.
Proof. unfold Equation2041. intro H. specialize (H F2_1 F2_0). unfold magma_op, reff96_inst, reff96_op in H. discriminate H. Qed.

Lemma reff96_not2043 : ~ @Equation2043 Fin2 reff96_inst.
Proof. unfold Equation2043. intro H. specialize (H F2_1 F2_0). unfold magma_op, reff96_inst, reff96_op in H. discriminate H. Qed.

Lemma reff96_not2044 : ~ @Equation2044 Fin2 reff96_inst.
Proof. unfold Equation2044. intro H. specialize (H F2_1 F2_0). unfold magma_op, reff96_inst, reff96_op in H. discriminate H. Qed.

Lemma reff96_not2050 : ~ @Equation2050 Fin2 reff96_inst.
Proof. unfold Equation2050. intro H. specialize (H F2_1 F2_0). unfold magma_op, reff96_inst, reff96_op in H. discriminate H. Qed.

Lemma reff96_not2051 : ~ @Equation2051 Fin2 reff96_inst.
Proof. unfold Equation2051. intro H. specialize (H F2_1 F2_0). unfold magma_op, reff96_inst, reff96_op in H. discriminate H. Qed.

Lemma reff96_not2053 : ~ @Equation2053 Fin2 reff96_inst.
Proof. unfold Equation2053. intro H. specialize (H F2_1 F2_0). unfold magma_op, reff96_inst, reff96_op in H. discriminate H. Qed.

Lemma reff96_not2054 : ~ @Equation2054 Fin2 reff96_inst.
Proof. unfold Equation2054. intro H. specialize (H F2_1 F2_0). unfold magma_op, reff96_inst, reff96_op in H. discriminate H. Qed.

Lemma reff96_not2060 : ~ @Equation2060 Fin2 reff96_inst.
Proof. unfold Equation2060. intro H. specialize (H F2_1 F2_0). unfold magma_op, reff96_inst, reff96_op in H. discriminate H. Qed.

Lemma reff96_not2061 : ~ @Equation2061 Fin2 reff96_inst.
Proof. unfold Equation2061. intro H. specialize (H F2_1 F2_0). unfold magma_op, reff96_inst, reff96_op in H. discriminate H. Qed.

Lemma reff96_not2063 : ~ @Equation2063 Fin2 reff96_inst.
Proof. unfold Equation2063. intro H. specialize (H F2_1 F2_0). unfold magma_op, reff96_inst, reff96_op in H. discriminate H. Qed.

Lemma reff96_not2064 : ~ @Equation2064 Fin2 reff96_inst.
Proof. unfold Equation2064. intro H. specialize (H F2_1 F2_0). unfold magma_op, reff96_inst, reff96_op in H. discriminate H. Qed.

Lemma reff96_not2087 : ~ @Equation2087 Fin2 reff96_inst.
Proof. unfold Equation2087. intro H. specialize (H F2_1 F2_0). unfold magma_op, reff96_inst, reff96_op in H. discriminate H. Qed.

Lemma reff96_not2088 : ~ @Equation2088 Fin2 reff96_inst.
Proof. unfold Equation2088. intro H. specialize (H F2_1 F2_0). unfold magma_op, reff96_inst, reff96_op in H. discriminate H. Qed.

Lemma reff96_not2090 : ~ @Equation2090 Fin2 reff96_inst.
Proof. unfold Equation2090. intro H. specialize (H F2_1 F2_0). unfold magma_op, reff96_inst, reff96_op in H. discriminate H. Qed.

Lemma reff96_not2091 : ~ @Equation2091 Fin2 reff96_inst.
Proof. unfold Equation2091. intro H. specialize (H F2_1 F2_0). unfold magma_op, reff96_inst, reff96_op in H. discriminate H. Qed.

Lemma reff96_not2097 : ~ @Equation2097 Fin2 reff96_inst.
Proof. unfold Equation2097. intro H. specialize (H F2_1 F2_0). unfold magma_op, reff96_inst, reff96_op in H. discriminate H. Qed.

Lemma reff96_not2098 : ~ @Equation2098 Fin2 reff96_inst.
Proof. unfold Equation2098. intro H. specialize (H F2_1 F2_0). unfold magma_op, reff96_inst, reff96_op in H. discriminate H. Qed.

Lemma reff96_not2100 : ~ @Equation2100 Fin2 reff96_inst.
Proof. unfold Equation2100. intro H. specialize (H F2_1 F2_0). unfold magma_op, reff96_inst, reff96_op in H. discriminate H. Qed.

Lemma reff96_not2101 : ~ @Equation2101 Fin2 reff96_inst.
Proof. unfold Equation2101. intro H. specialize (H F2_1 F2_0). unfold magma_op, reff96_inst, reff96_op in H. discriminate H. Qed.

Lemma reff96_not2124 : ~ @Equation2124 Fin2 reff96_inst.
Proof. unfold Equation2124. intro H. specialize (H F2_1 F2_0). unfold magma_op, reff96_inst, reff96_op in H. discriminate H. Qed.

Lemma reff96_not2125 : ~ @Equation2125 Fin2 reff96_inst.
Proof. unfold Equation2125. intro H. specialize (H F2_1 F2_0). unfold magma_op, reff96_inst, reff96_op in H. discriminate H. Qed.

Lemma reff96_not2127 : ~ @Equation2127 Fin2 reff96_inst.
Proof. unfold Equation2127. intro H. specialize (H F2_1 F2_0). unfold magma_op, reff96_inst, reff96_op in H. discriminate H. Qed.

Lemma reff96_not2128 : ~ @Equation2128 Fin2 reff96_inst.
Proof. unfold Equation2128. intro H. specialize (H F2_1 F2_0). unfold magma_op, reff96_inst, reff96_op in H. discriminate H. Qed.

Lemma reff96_not2134 : ~ @Equation2134 Fin2 reff96_inst.
Proof. unfold Equation2134. intro H. specialize (H F2_1 F2_0). unfold magma_op, reff96_inst, reff96_op in H. discriminate H. Qed.

Lemma reff96_not2135 : ~ @Equation2135 Fin2 reff96_inst.
Proof. unfold Equation2135. intro H. specialize (H F2_1 F2_0). unfold magma_op, reff96_inst, reff96_op in H. discriminate H. Qed.

Lemma reff96_not2137 : ~ @Equation2137 Fin2 reff96_inst.
Proof. unfold Equation2137. intro H. specialize (H F2_1 F2_0). unfold magma_op, reff96_inst, reff96_op in H. discriminate H. Qed.

Lemma reff96_not2239 : ~ @Equation2239 Fin2 reff96_inst.
Proof. unfold Equation2239. intro H. specialize (H F2_1 F2_0). unfold magma_op, reff96_inst, reff96_op in H. discriminate H. Qed.

Lemma reff96_not2240 : ~ @Equation2240 Fin2 reff96_inst.
Proof. unfold Equation2240. intro H. specialize (H F2_1 F2_0). unfold magma_op, reff96_inst, reff96_op in H. discriminate H. Qed.

Lemma reff96_not2241 : ~ @Equation2241 Fin2 reff96_inst.
Proof. unfold Equation2241. intro H. specialize (H F2_1 F2_0). unfold magma_op, reff96_inst, reff96_op in H. discriminate H. Qed.

Lemma reff96_not2243 : ~ @Equation2243 Fin2 reff96_inst.
Proof. unfold Equation2243. intro H. specialize (H F2_1 F2_0). unfold magma_op, reff96_inst, reff96_op in H. discriminate H. Qed.

Lemma reff96_not2244 : ~ @Equation2244 Fin2 reff96_inst.
Proof. unfold Equation2244. intro H. specialize (H F2_1 F2_0). unfold magma_op, reff96_inst, reff96_op in H. discriminate H. Qed.

Lemma reff96_not2246 : ~ @Equation2246 Fin2 reff96_inst.
Proof. unfold Equation2246. intro H. specialize (H F2_1 F2_0). unfold magma_op, reff96_inst, reff96_op in H. discriminate H. Qed.

Lemma reff96_not2247 : ~ @Equation2247 Fin2 reff96_inst.
Proof. unfold Equation2247. intro H. specialize (H F2_1 F2_0). unfold magma_op, reff96_inst, reff96_op in H. discriminate H. Qed.

Lemma reff96_not2253 : ~ @Equation2253 Fin2 reff96_inst.
Proof. unfold Equation2253. intro H. specialize (H F2_1 F2_0). unfold magma_op, reff96_inst, reff96_op in H. discriminate H. Qed.

Lemma reff96_not2254 : ~ @Equation2254 Fin2 reff96_inst.
Proof. unfold Equation2254. intro H. specialize (H F2_1 F2_0). unfold magma_op, reff96_inst, reff96_op in H. discriminate H. Qed.

Lemma reff96_not2256 : ~ @Equation2256 Fin2 reff96_inst.
Proof. unfold Equation2256. intro H. specialize (H F2_1 F2_0). unfold magma_op, reff96_inst, reff96_op in H. discriminate H. Qed.

Lemma reff96_not2257 : ~ @Equation2257 Fin2 reff96_inst.
Proof. unfold Equation2257. intro H. specialize (H F2_1 F2_0). unfold magma_op, reff96_inst, reff96_op in H. discriminate H. Qed.

Lemma reff96_not2263 : ~ @Equation2263 Fin2 reff96_inst.
Proof. unfold Equation2263. intro H. specialize (H F2_1 F2_0). unfold magma_op, reff96_inst, reff96_op in H. discriminate H. Qed.

Lemma reff96_not2264 : ~ @Equation2264 Fin2 reff96_inst.
Proof. unfold Equation2264. intro H. specialize (H F2_1 F2_0). unfold magma_op, reff96_inst, reff96_op in H. discriminate H. Qed.

Lemma reff96_not2266 : ~ @Equation2266 Fin2 reff96_inst.
Proof. unfold Equation2266. intro H. specialize (H F2_1 F2_0). unfold magma_op, reff96_inst, reff96_op in H. discriminate H. Qed.

Lemma reff96_not2267 : ~ @Equation2267 Fin2 reff96_inst.
Proof. unfold Equation2267. intro H. specialize (H F2_1 F2_0). unfold magma_op, reff96_inst, reff96_op in H. discriminate H. Qed.

Lemma reff96_not2290 : ~ @Equation2290 Fin2 reff96_inst.
Proof. unfold Equation2290. intro H. specialize (H F2_1 F2_0). unfold magma_op, reff96_inst, reff96_op in H. discriminate H. Qed.

Lemma reff96_not2291 : ~ @Equation2291 Fin2 reff96_inst.
Proof. unfold Equation2291. intro H. specialize (H F2_1 F2_0). unfold magma_op, reff96_inst, reff96_op in H. discriminate H. Qed.

Lemma reff96_not2293 : ~ @Equation2293 Fin2 reff96_inst.
Proof. unfold Equation2293. intro H. specialize (H F2_1 F2_0). unfold magma_op, reff96_inst, reff96_op in H. discriminate H. Qed.

Lemma reff96_not2294 : ~ @Equation2294 Fin2 reff96_inst.
Proof. unfold Equation2294. intro H. specialize (H F2_1 F2_0). unfold magma_op, reff96_inst, reff96_op in H. discriminate H. Qed.

Lemma reff96_not2300 : ~ @Equation2300 Fin2 reff96_inst.
Proof. unfold Equation2300. intro H. specialize (H F2_1 F2_0). unfold magma_op, reff96_inst, reff96_op in H. discriminate H. Qed.

Lemma reff96_not2301 : ~ @Equation2301 Fin2 reff96_inst.
Proof. unfold Equation2301. intro H. specialize (H F2_1 F2_0). unfold magma_op, reff96_inst, reff96_op in H. discriminate H. Qed.

Lemma reff96_not2303 : ~ @Equation2303 Fin2 reff96_inst.
Proof. unfold Equation2303. intro H. specialize (H F2_1 F2_0). unfold magma_op, reff96_inst, reff96_op in H. discriminate H. Qed.

Lemma reff96_not2304 : ~ @Equation2304 Fin2 reff96_inst.
Proof. unfold Equation2304. intro H. specialize (H F2_1 F2_0). unfold magma_op, reff96_inst, reff96_op in H. discriminate H. Qed.

Lemma reff96_not2327 : ~ @Equation2327 Fin2 reff96_inst.
Proof. unfold Equation2327. intro H. specialize (H F2_1 F2_0). unfold magma_op, reff96_inst, reff96_op in H. discriminate H. Qed.

Lemma reff96_not2328 : ~ @Equation2328 Fin2 reff96_inst.
Proof. unfold Equation2328. intro H. specialize (H F2_1 F2_0). unfold magma_op, reff96_inst, reff96_op in H. discriminate H. Qed.

Lemma reff96_not2330 : ~ @Equation2330 Fin2 reff96_inst.
Proof. unfold Equation2330. intro H. specialize (H F2_1 F2_0). unfold magma_op, reff96_inst, reff96_op in H. discriminate H. Qed.

Lemma reff96_not2331 : ~ @Equation2331 Fin2 reff96_inst.
Proof. unfold Equation2331. intro H. specialize (H F2_1 F2_0). unfold magma_op, reff96_inst, reff96_op in H. discriminate H. Qed.

Lemma reff96_not2337 : ~ @Equation2337 Fin2 reff96_inst.
Proof. unfold Equation2337. intro H. specialize (H F2_1 F2_0). unfold magma_op, reff96_inst, reff96_op in H. discriminate H. Qed.

Lemma reff96_not2338 : ~ @Equation2338 Fin2 reff96_inst.
Proof. unfold Equation2338. intro H. specialize (H F2_1 F2_0). unfold magma_op, reff96_inst, reff96_op in H. discriminate H. Qed.

Lemma reff96_not2340 : ~ @Equation2340 Fin2 reff96_inst.
Proof. unfold Equation2340. intro H. specialize (H F2_1 F2_0). unfold magma_op, reff96_inst, reff96_op in H. discriminate H. Qed.

Lemma reff96_not2442 : ~ @Equation2442 Fin2 reff96_inst.
Proof. unfold Equation2442. intro H. specialize (H F2_1 F2_0). unfold magma_op, reff96_inst, reff96_op in H. discriminate H. Qed.

Lemma reff96_not2443 : ~ @Equation2443 Fin2 reff96_inst.
Proof. unfold Equation2443. intro H. specialize (H F2_1 F2_0). unfold magma_op, reff96_inst, reff96_op in H. discriminate H. Qed.

Lemma reff96_not2444 : ~ @Equation2444 Fin2 reff96_inst.
Proof. unfold Equation2444. intro H. specialize (H F2_1 F2_0). unfold magma_op, reff96_inst, reff96_op in H. discriminate H. Qed.

Lemma reff96_not2446 : ~ @Equation2446 Fin2 reff96_inst.
Proof. unfold Equation2446. intro H. specialize (H F2_1 F2_0). unfold magma_op, reff96_inst, reff96_op in H. discriminate H. Qed.

Lemma reff96_not2447 : ~ @Equation2447 Fin2 reff96_inst.
Proof. unfold Equation2447. intro H. specialize (H F2_1 F2_0). unfold magma_op, reff96_inst, reff96_op in H. discriminate H. Qed.

Lemma reff96_not2449 : ~ @Equation2449 Fin2 reff96_inst.
Proof. unfold Equation2449. intro H. specialize (H F2_1 F2_0). unfold magma_op, reff96_inst, reff96_op in H. discriminate H. Qed.

Lemma reff96_not2450 : ~ @Equation2450 Fin2 reff96_inst.
Proof. unfold Equation2450. intro H. specialize (H F2_1 F2_0). unfold magma_op, reff96_inst, reff96_op in H. discriminate H. Qed.

Lemma reff96_not2456 : ~ @Equation2456 Fin2 reff96_inst.
Proof. unfold Equation2456. intro H. specialize (H F2_1 F2_0). unfold magma_op, reff96_inst, reff96_op in H. discriminate H. Qed.

Lemma reff96_not2457 : ~ @Equation2457 Fin2 reff96_inst.
Proof. unfold Equation2457. intro H. specialize (H F2_1 F2_0). unfold magma_op, reff96_inst, reff96_op in H. discriminate H. Qed.

Lemma reff96_not2459 : ~ @Equation2459 Fin2 reff96_inst.
Proof. unfold Equation2459. intro H. specialize (H F2_1 F2_0). unfold magma_op, reff96_inst, reff96_op in H. discriminate H. Qed.

Lemma reff96_not2460 : ~ @Equation2460 Fin2 reff96_inst.
Proof. unfold Equation2460. intro H. specialize (H F2_1 F2_0). unfold magma_op, reff96_inst, reff96_op in H. discriminate H. Qed.

Lemma reff96_not2466 : ~ @Equation2466 Fin2 reff96_inst.
Proof. unfold Equation2466. intro H. specialize (H F2_1 F2_0). unfold magma_op, reff96_inst, reff96_op in H. discriminate H. Qed.

Lemma reff96_not2467 : ~ @Equation2467 Fin2 reff96_inst.
Proof. unfold Equation2467. intro H. specialize (H F2_1 F2_0). unfold magma_op, reff96_inst, reff96_op in H. discriminate H. Qed.

Lemma reff96_not2469 : ~ @Equation2469 Fin2 reff96_inst.
Proof. unfold Equation2469. intro H. specialize (H F2_1 F2_0). unfold magma_op, reff96_inst, reff96_op in H. discriminate H. Qed.

Lemma reff96_not2470 : ~ @Equation2470 Fin2 reff96_inst.
Proof. unfold Equation2470. intro H. specialize (H F2_1 F2_0). unfold magma_op, reff96_inst, reff96_op in H. discriminate H. Qed.

Lemma reff96_not2493 : ~ @Equation2493 Fin2 reff96_inst.
Proof. unfold Equation2493. intro H. specialize (H F2_1 F2_0). unfold magma_op, reff96_inst, reff96_op in H. discriminate H. Qed.

Lemma reff96_not2494 : ~ @Equation2494 Fin2 reff96_inst.
Proof. unfold Equation2494. intro H. specialize (H F2_1 F2_0). unfold magma_op, reff96_inst, reff96_op in H. discriminate H. Qed.

Lemma reff96_not2496 : ~ @Equation2496 Fin2 reff96_inst.
Proof. unfold Equation2496. intro H. specialize (H F2_1 F2_0). unfold magma_op, reff96_inst, reff96_op in H. discriminate H. Qed.

Lemma reff96_not2497 : ~ @Equation2497 Fin2 reff96_inst.
Proof. unfold Equation2497. intro H. specialize (H F2_1 F2_0). unfold magma_op, reff96_inst, reff96_op in H. discriminate H. Qed.

Lemma reff96_not2503 : ~ @Equation2503 Fin2 reff96_inst.
Proof. unfold Equation2503. intro H. specialize (H F2_1 F2_0). unfold magma_op, reff96_inst, reff96_op in H. discriminate H. Qed.

Lemma reff96_not2504 : ~ @Equation2504 Fin2 reff96_inst.
Proof. unfold Equation2504. intro H. specialize (H F2_1 F2_0). unfold magma_op, reff96_inst, reff96_op in H. discriminate H. Qed.

Lemma reff96_not2506 : ~ @Equation2506 Fin2 reff96_inst.
Proof. unfold Equation2506. intro H. specialize (H F2_1 F2_0). unfold magma_op, reff96_inst, reff96_op in H. discriminate H. Qed.

Lemma reff96_not2507 : ~ @Equation2507 Fin2 reff96_inst.
Proof. unfold Equation2507. intro H. specialize (H F2_1 F2_0). unfold magma_op, reff96_inst, reff96_op in H. discriminate H. Qed.

Lemma reff96_not2530 : ~ @Equation2530 Fin2 reff96_inst.
Proof. unfold Equation2530. intro H. specialize (H F2_1 F2_0). unfold magma_op, reff96_inst, reff96_op in H. discriminate H. Qed.

Lemma reff96_not2531 : ~ @Equation2531 Fin2 reff96_inst.
Proof. unfold Equation2531. intro H. specialize (H F2_1 F2_0). unfold magma_op, reff96_inst, reff96_op in H. discriminate H. Qed.

Lemma reff96_not2533 : ~ @Equation2533 Fin2 reff96_inst.
Proof. unfold Equation2533. intro H. specialize (H F2_1 F2_0). unfold magma_op, reff96_inst, reff96_op in H. discriminate H. Qed.

Lemma reff96_not2534 : ~ @Equation2534 Fin2 reff96_inst.
Proof. unfold Equation2534. intro H. specialize (H F2_1 F2_0). unfold magma_op, reff96_inst, reff96_op in H. discriminate H. Qed.

Lemma reff96_not2540 : ~ @Equation2540 Fin2 reff96_inst.
Proof. unfold Equation2540. intro H. specialize (H F2_1 F2_0). unfold magma_op, reff96_inst, reff96_op in H. discriminate H. Qed.

Lemma reff96_not2541 : ~ @Equation2541 Fin2 reff96_inst.
Proof. unfold Equation2541. intro H. specialize (H F2_1 F2_0). unfold magma_op, reff96_inst, reff96_op in H. discriminate H. Qed.

Lemma reff96_not2543 : ~ @Equation2543 Fin2 reff96_inst.
Proof. unfold Equation2543. intro H. specialize (H F2_1 F2_0). unfold magma_op, reff96_inst, reff96_op in H. discriminate H. Qed.

Lemma reff96_not2645 : ~ @Equation2645 Fin2 reff96_inst.
Proof. unfold Equation2645. intro H. specialize (H F2_1 F2_0). unfold magma_op, reff96_inst, reff96_op in H. discriminate H. Qed.

Lemma reff96_not2646 : ~ @Equation2646 Fin2 reff96_inst.
Proof. unfold Equation2646. intro H. specialize (H F2_1 F2_0). unfold magma_op, reff96_inst, reff96_op in H. discriminate H. Qed.

Lemma reff96_not2647 : ~ @Equation2647 Fin2 reff96_inst.
Proof. unfold Equation2647. intro H. specialize (H F2_1 F2_0). unfold magma_op, reff96_inst, reff96_op in H. discriminate H. Qed.

Lemma reff96_not2649 : ~ @Equation2649 Fin2 reff96_inst.
Proof. unfold Equation2649. intro H. specialize (H F2_1 F2_0). unfold magma_op, reff96_inst, reff96_op in H. discriminate H. Qed.

Lemma reff96_not2650 : ~ @Equation2650 Fin2 reff96_inst.
Proof. unfold Equation2650. intro H. specialize (H F2_1 F2_0). unfold magma_op, reff96_inst, reff96_op in H. discriminate H. Qed.

Lemma reff96_not2652 : ~ @Equation2652 Fin2 reff96_inst.
Proof. unfold Equation2652. intro H. specialize (H F2_1 F2_0). unfold magma_op, reff96_inst, reff96_op in H. discriminate H. Qed.

Lemma reff96_not2653 : ~ @Equation2653 Fin2 reff96_inst.
Proof. unfold Equation2653. intro H. specialize (H F2_1 F2_0). unfold magma_op, reff96_inst, reff96_op in H. discriminate H. Qed.

Lemma reff96_not2659 : ~ @Equation2659 Fin2 reff96_inst.
Proof. unfold Equation2659. intro H. specialize (H F2_1 F2_0). unfold magma_op, reff96_inst, reff96_op in H. discriminate H. Qed.

Lemma reff96_not2660 : ~ @Equation2660 Fin2 reff96_inst.
Proof. unfold Equation2660. intro H. specialize (H F2_1 F2_0). unfold magma_op, reff96_inst, reff96_op in H. discriminate H. Qed.

Lemma reff96_not2662 : ~ @Equation2662 Fin2 reff96_inst.
Proof. unfold Equation2662. intro H. specialize (H F2_1 F2_0). unfold magma_op, reff96_inst, reff96_op in H. discriminate H. Qed.

Lemma reff96_not2663 : ~ @Equation2663 Fin2 reff96_inst.
Proof. unfold Equation2663. intro H. specialize (H F2_1 F2_0). unfold magma_op, reff96_inst, reff96_op in H. discriminate H. Qed.

Lemma reff96_not2669 : ~ @Equation2669 Fin2 reff96_inst.
Proof. unfold Equation2669. intro H. specialize (H F2_1 F2_0). unfold magma_op, reff96_inst, reff96_op in H. discriminate H. Qed.

Lemma reff96_not2670 : ~ @Equation2670 Fin2 reff96_inst.
Proof. unfold Equation2670. intro H. specialize (H F2_1 F2_0). unfold magma_op, reff96_inst, reff96_op in H. discriminate H. Qed.

Lemma reff96_not2672 : ~ @Equation2672 Fin2 reff96_inst.
Proof. unfold Equation2672. intro H. specialize (H F2_1 F2_0). unfold magma_op, reff96_inst, reff96_op in H. discriminate H. Qed.

Lemma reff96_not2673 : ~ @Equation2673 Fin2 reff96_inst.
Proof. unfold Equation2673. intro H. specialize (H F2_1 F2_0). unfold magma_op, reff96_inst, reff96_op in H. discriminate H. Qed.

Lemma reff96_not2696 : ~ @Equation2696 Fin2 reff96_inst.
Proof. unfold Equation2696. intro H. specialize (H F2_1 F2_0). unfold magma_op, reff96_inst, reff96_op in H. discriminate H. Qed.

Lemma reff96_not2697 : ~ @Equation2697 Fin2 reff96_inst.
Proof. unfold Equation2697. intro H. specialize (H F2_1 F2_0). unfold magma_op, reff96_inst, reff96_op in H. discriminate H. Qed.

Lemma reff96_not2699 : ~ @Equation2699 Fin2 reff96_inst.
Proof. unfold Equation2699. intro H. specialize (H F2_1 F2_0). unfold magma_op, reff96_inst, reff96_op in H. discriminate H. Qed.

Lemma reff96_not2700 : ~ @Equation2700 Fin2 reff96_inst.
Proof. unfold Equation2700. intro H. specialize (H F2_1 F2_0). unfold magma_op, reff96_inst, reff96_op in H. discriminate H. Qed.

Lemma reff96_not2706 : ~ @Equation2706 Fin2 reff96_inst.
Proof. unfold Equation2706. intro H. specialize (H F2_1 F2_0). unfold magma_op, reff96_inst, reff96_op in H. discriminate H. Qed.

Lemma reff96_not2707 : ~ @Equation2707 Fin2 reff96_inst.
Proof. unfold Equation2707. intro H. specialize (H F2_1 F2_0). unfold magma_op, reff96_inst, reff96_op in H. discriminate H. Qed.

Lemma reff96_not2709 : ~ @Equation2709 Fin2 reff96_inst.
Proof. unfold Equation2709. intro H. specialize (H F2_1 F2_0). unfold magma_op, reff96_inst, reff96_op in H. discriminate H. Qed.

Lemma reff96_not2710 : ~ @Equation2710 Fin2 reff96_inst.
Proof. unfold Equation2710. intro H. specialize (H F2_1 F2_0). unfold magma_op, reff96_inst, reff96_op in H. discriminate H. Qed.

Lemma reff96_not2733 : ~ @Equation2733 Fin2 reff96_inst.
Proof. unfold Equation2733. intro H. specialize (H F2_1 F2_0). unfold magma_op, reff96_inst, reff96_op in H. discriminate H. Qed.

Lemma reff96_not2734 : ~ @Equation2734 Fin2 reff96_inst.
Proof. unfold Equation2734. intro H. specialize (H F2_1 F2_0). unfold magma_op, reff96_inst, reff96_op in H. discriminate H. Qed.

Lemma reff96_not2736 : ~ @Equation2736 Fin2 reff96_inst.
Proof. unfold Equation2736. intro H. specialize (H F2_1 F2_0). unfold magma_op, reff96_inst, reff96_op in H. discriminate H. Qed.

Lemma reff96_not2737 : ~ @Equation2737 Fin2 reff96_inst.
Proof. unfold Equation2737. intro H. specialize (H F2_1 F2_0). unfold magma_op, reff96_inst, reff96_op in H. discriminate H. Qed.

Lemma reff96_not2743 : ~ @Equation2743 Fin2 reff96_inst.
Proof. unfold Equation2743. intro H. specialize (H F2_1 F2_0). unfold magma_op, reff96_inst, reff96_op in H. discriminate H. Qed.

Lemma reff96_not2744 : ~ @Equation2744 Fin2 reff96_inst.
Proof. unfold Equation2744. intro H. specialize (H F2_1 F2_0). unfold magma_op, reff96_inst, reff96_op in H. discriminate H. Qed.

Lemma reff96_not2746 : ~ @Equation2746 Fin2 reff96_inst.
Proof. unfold Equation2746. intro H. specialize (H F2_1 F2_0). unfold magma_op, reff96_inst, reff96_op in H. discriminate H. Qed.

Lemma reff96_not2848 : ~ @Equation2848 Fin2 reff96_inst.
Proof. unfold Equation2848. intro H. specialize (H F2_1 F2_0). unfold magma_op, reff96_inst, reff96_op in H. discriminate H. Qed.

Lemma reff96_not2849 : ~ @Equation2849 Fin2 reff96_inst.
Proof. unfold Equation2849. intro H. specialize (H F2_1 F2_0). unfold magma_op, reff96_inst, reff96_op in H. discriminate H. Qed.

Lemma reff96_not2850 : ~ @Equation2850 Fin2 reff96_inst.
Proof. unfold Equation2850. intro H. specialize (H F2_1 F2_0). unfold magma_op, reff96_inst, reff96_op in H. discriminate H. Qed.

Lemma reff96_not2852 : ~ @Equation2852 Fin2 reff96_inst.
Proof. unfold Equation2852. intro H. specialize (H F2_1 F2_0). unfold magma_op, reff96_inst, reff96_op in H. discriminate H. Qed.

Lemma reff96_not2853 : ~ @Equation2853 Fin2 reff96_inst.
Proof. unfold Equation2853. intro H. specialize (H F2_1 F2_0). unfold magma_op, reff96_inst, reff96_op in H. discriminate H. Qed.

Lemma reff96_not2855 : ~ @Equation2855 Fin2 reff96_inst.
Proof. unfold Equation2855. intro H. specialize (H F2_1 F2_0). unfold magma_op, reff96_inst, reff96_op in H. discriminate H. Qed.

Lemma reff96_not2856 : ~ @Equation2856 Fin2 reff96_inst.
Proof. unfold Equation2856. intro H. specialize (H F2_1 F2_0). unfold magma_op, reff96_inst, reff96_op in H. discriminate H. Qed.

Lemma reff96_not2862 : ~ @Equation2862 Fin2 reff96_inst.
Proof. unfold Equation2862. intro H. specialize (H F2_1 F2_0). unfold magma_op, reff96_inst, reff96_op in H. discriminate H. Qed.

Lemma reff96_not2863 : ~ @Equation2863 Fin2 reff96_inst.
Proof. unfold Equation2863. intro H. specialize (H F2_1 F2_0). unfold magma_op, reff96_inst, reff96_op in H. discriminate H. Qed.

Lemma reff96_not2865 : ~ @Equation2865 Fin2 reff96_inst.
Proof. unfold Equation2865. intro H. specialize (H F2_1 F2_0). unfold magma_op, reff96_inst, reff96_op in H. discriminate H. Qed.

Lemma reff96_not2866 : ~ @Equation2866 Fin2 reff96_inst.
Proof. unfold Equation2866. intro H. specialize (H F2_1 F2_0). unfold magma_op, reff96_inst, reff96_op in H. discriminate H. Qed.

Lemma reff96_not2872 : ~ @Equation2872 Fin2 reff96_inst.
Proof. unfold Equation2872. intro H. specialize (H F2_1 F2_0). unfold magma_op, reff96_inst, reff96_op in H. discriminate H. Qed.

Lemma reff96_not2873 : ~ @Equation2873 Fin2 reff96_inst.
Proof. unfold Equation2873. intro H. specialize (H F2_1 F2_0). unfold magma_op, reff96_inst, reff96_op in H. discriminate H. Qed.

Lemma reff96_not2875 : ~ @Equation2875 Fin2 reff96_inst.
Proof. unfold Equation2875. intro H. specialize (H F2_1 F2_0). unfold magma_op, reff96_inst, reff96_op in H. discriminate H. Qed.

Lemma reff96_not2876 : ~ @Equation2876 Fin2 reff96_inst.
Proof. unfold Equation2876. intro H. specialize (H F2_1 F2_0). unfold magma_op, reff96_inst, reff96_op in H. discriminate H. Qed.

Lemma reff96_not2899 : ~ @Equation2899 Fin2 reff96_inst.
Proof. unfold Equation2899. intro H. specialize (H F2_1 F2_0). unfold magma_op, reff96_inst, reff96_op in H. discriminate H. Qed.

Lemma reff96_not2900 : ~ @Equation2900 Fin2 reff96_inst.
Proof. unfold Equation2900. intro H. specialize (H F2_1 F2_0). unfold magma_op, reff96_inst, reff96_op in H. discriminate H. Qed.

Lemma reff96_not2902 : ~ @Equation2902 Fin2 reff96_inst.
Proof. unfold Equation2902. intro H. specialize (H F2_1 F2_0). unfold magma_op, reff96_inst, reff96_op in H. discriminate H. Qed.

Lemma reff96_not2903 : ~ @Equation2903 Fin2 reff96_inst.
Proof. unfold Equation2903. intro H. specialize (H F2_1 F2_0). unfold magma_op, reff96_inst, reff96_op in H. discriminate H. Qed.

Lemma reff96_not2909 : ~ @Equation2909 Fin2 reff96_inst.
Proof. unfold Equation2909. intro H. specialize (H F2_1 F2_0). unfold magma_op, reff96_inst, reff96_op in H. discriminate H. Qed.

Lemma reff96_not2910 : ~ @Equation2910 Fin2 reff96_inst.
Proof. unfold Equation2910. intro H. specialize (H F2_1 F2_0). unfold magma_op, reff96_inst, reff96_op in H. discriminate H. Qed.

Lemma reff96_not2912 : ~ @Equation2912 Fin2 reff96_inst.
Proof. unfold Equation2912. intro H. specialize (H F2_1 F2_0). unfold magma_op, reff96_inst, reff96_op in H. discriminate H. Qed.

Lemma reff96_not2913 : ~ @Equation2913 Fin2 reff96_inst.
Proof. unfold Equation2913. intro H. specialize (H F2_1 F2_0). unfold magma_op, reff96_inst, reff96_op in H. discriminate H. Qed.

Lemma reff96_not2936 : ~ @Equation2936 Fin2 reff96_inst.
Proof. unfold Equation2936. intro H. specialize (H F2_1 F2_0). unfold magma_op, reff96_inst, reff96_op in H. discriminate H. Qed.

Lemma reff96_not2937 : ~ @Equation2937 Fin2 reff96_inst.
Proof. unfold Equation2937. intro H. specialize (H F2_1 F2_0). unfold magma_op, reff96_inst, reff96_op in H. discriminate H. Qed.

Lemma reff96_not2939 : ~ @Equation2939 Fin2 reff96_inst.
Proof. unfold Equation2939. intro H. specialize (H F2_1 F2_0). unfold magma_op, reff96_inst, reff96_op in H. discriminate H. Qed.

Lemma reff96_not2940 : ~ @Equation2940 Fin2 reff96_inst.
Proof. unfold Equation2940. intro H. specialize (H F2_1 F2_0). unfold magma_op, reff96_inst, reff96_op in H. discriminate H. Qed.

Lemma reff96_not2946 : ~ @Equation2946 Fin2 reff96_inst.
Proof. unfold Equation2946. intro H. specialize (H F2_1 F2_0). unfold magma_op, reff96_inst, reff96_op in H. discriminate H. Qed.

Lemma reff96_not2947 : ~ @Equation2947 Fin2 reff96_inst.
Proof. unfold Equation2947. intro H. specialize (H F2_1 F2_0). unfold magma_op, reff96_inst, reff96_op in H. discriminate H. Qed.

Lemma reff96_not2949 : ~ @Equation2949 Fin2 reff96_inst.
Proof. unfold Equation2949. intro H. specialize (H F2_1 F2_0). unfold magma_op, reff96_inst, reff96_op in H. discriminate H. Qed.

Lemma reff96_not3051 : ~ @Equation3051 Fin2 reff96_inst.
Proof. unfold Equation3051. intro H. specialize (H F2_1 F2_0). unfold magma_op, reff96_inst, reff96_op in H. discriminate H. Qed.

Lemma reff96_not3052 : ~ @Equation3052 Fin2 reff96_inst.
Proof. unfold Equation3052. intro H. specialize (H F2_1 F2_0). unfold magma_op, reff96_inst, reff96_op in H. discriminate H. Qed.

Lemma reff96_not3053 : ~ @Equation3053 Fin2 reff96_inst.
Proof. unfold Equation3053. intro H. specialize (H F2_1 F2_0). unfold magma_op, reff96_inst, reff96_op in H. discriminate H. Qed.

Lemma reff96_not3055 : ~ @Equation3055 Fin2 reff96_inst.
Proof. unfold Equation3055. intro H. specialize (H F2_1 F2_0). unfold magma_op, reff96_inst, reff96_op in H. discriminate H. Qed.

Lemma reff96_not3056 : ~ @Equation3056 Fin2 reff96_inst.
Proof. unfold Equation3056. intro H. specialize (H F2_1 F2_0). unfold magma_op, reff96_inst, reff96_op in H. discriminate H. Qed.

Lemma reff96_not3058 : ~ @Equation3058 Fin2 reff96_inst.
Proof. unfold Equation3058. intro H. specialize (H F2_1 F2_0). unfold magma_op, reff96_inst, reff96_op in H. discriminate H. Qed.

Lemma reff96_not3059 : ~ @Equation3059 Fin2 reff96_inst.
Proof. unfold Equation3059. intro H. specialize (H F2_1 F2_0). unfold magma_op, reff96_inst, reff96_op in H. discriminate H. Qed.

Lemma reff96_not3065 : ~ @Equation3065 Fin2 reff96_inst.
Proof. unfold Equation3065. intro H. specialize (H F2_1 F2_0). unfold magma_op, reff96_inst, reff96_op in H. discriminate H. Qed.

Lemma reff96_not3066 : ~ @Equation3066 Fin2 reff96_inst.
Proof. unfold Equation3066. intro H. specialize (H F2_1 F2_0). unfold magma_op, reff96_inst, reff96_op in H. discriminate H. Qed.

Lemma reff96_not3068 : ~ @Equation3068 Fin2 reff96_inst.
Proof. unfold Equation3068. intro H. specialize (H F2_1 F2_0). unfold magma_op, reff96_inst, reff96_op in H. discriminate H. Qed.

Lemma reff96_not3069 : ~ @Equation3069 Fin2 reff96_inst.
Proof. unfold Equation3069. intro H. specialize (H F2_1 F2_0). unfold magma_op, reff96_inst, reff96_op in H. discriminate H. Qed.

Lemma reff96_not3075 : ~ @Equation3075 Fin2 reff96_inst.
Proof. unfold Equation3075. intro H. specialize (H F2_1 F2_0). unfold magma_op, reff96_inst, reff96_op in H. discriminate H. Qed.

Lemma reff96_not3076 : ~ @Equation3076 Fin2 reff96_inst.
Proof. unfold Equation3076. intro H. specialize (H F2_1 F2_0). unfold magma_op, reff96_inst, reff96_op in H. discriminate H. Qed.

Lemma reff96_not3078 : ~ @Equation3078 Fin2 reff96_inst.
Proof. unfold Equation3078. intro H. specialize (H F2_1 F2_0). unfold magma_op, reff96_inst, reff96_op in H. discriminate H. Qed.

Lemma reff96_not3079 : ~ @Equation3079 Fin2 reff96_inst.
Proof. unfold Equation3079. intro H. specialize (H F2_1 F2_0). unfold magma_op, reff96_inst, reff96_op in H. discriminate H. Qed.

Lemma reff96_not3102 : ~ @Equation3102 Fin2 reff96_inst.
Proof. unfold Equation3102. intro H. specialize (H F2_1 F2_0). unfold magma_op, reff96_inst, reff96_op in H. discriminate H. Qed.

Lemma reff96_not3103 : ~ @Equation3103 Fin2 reff96_inst.
Proof. unfold Equation3103. intro H. specialize (H F2_1 F2_0). unfold magma_op, reff96_inst, reff96_op in H. discriminate H. Qed.

Lemma reff96_not3105 : ~ @Equation3105 Fin2 reff96_inst.
Proof. unfold Equation3105. intro H. specialize (H F2_1 F2_0). unfold magma_op, reff96_inst, reff96_op in H. discriminate H. Qed.

Lemma reff96_not3106 : ~ @Equation3106 Fin2 reff96_inst.
Proof. unfold Equation3106. intro H. specialize (H F2_1 F2_0). unfold magma_op, reff96_inst, reff96_op in H. discriminate H. Qed.

Lemma reff96_not3112 : ~ @Equation3112 Fin2 reff96_inst.
Proof. unfold Equation3112. intro H. specialize (H F2_1 F2_0). unfold magma_op, reff96_inst, reff96_op in H. discriminate H. Qed.

Lemma reff96_not3113 : ~ @Equation3113 Fin2 reff96_inst.
Proof. unfold Equation3113. intro H. specialize (H F2_1 F2_0). unfold magma_op, reff96_inst, reff96_op in H. discriminate H. Qed.

Lemma reff96_not3115 : ~ @Equation3115 Fin2 reff96_inst.
Proof. unfold Equation3115. intro H. specialize (H F2_1 F2_0). unfold magma_op, reff96_inst, reff96_op in H. discriminate H. Qed.

Lemma reff96_not3116 : ~ @Equation3116 Fin2 reff96_inst.
Proof. unfold Equation3116. intro H. specialize (H F2_1 F2_0). unfold magma_op, reff96_inst, reff96_op in H. discriminate H. Qed.

Lemma reff96_not3139 : ~ @Equation3139 Fin2 reff96_inst.
Proof. unfold Equation3139. intro H. specialize (H F2_1 F2_0). unfold magma_op, reff96_inst, reff96_op in H. discriminate H. Qed.

Lemma reff96_not3140 : ~ @Equation3140 Fin2 reff96_inst.
Proof. unfold Equation3140. intro H. specialize (H F2_1 F2_0). unfold magma_op, reff96_inst, reff96_op in H. discriminate H. Qed.

Lemma reff96_not3142 : ~ @Equation3142 Fin2 reff96_inst.
Proof. unfold Equation3142. intro H. specialize (H F2_1 F2_0). unfold magma_op, reff96_inst, reff96_op in H. discriminate H. Qed.

Lemma reff96_not3143 : ~ @Equation3143 Fin2 reff96_inst.
Proof. unfold Equation3143. intro H. specialize (H F2_1 F2_0). unfold magma_op, reff96_inst, reff96_op in H. discriminate H. Qed.

Lemma reff96_not3149 : ~ @Equation3149 Fin2 reff96_inst.
Proof. unfold Equation3149. intro H. specialize (H F2_1 F2_0). unfold magma_op, reff96_inst, reff96_op in H. discriminate H. Qed.

Lemma reff96_not3150 : ~ @Equation3150 Fin2 reff96_inst.
Proof. unfold Equation3150. intro H. specialize (H F2_1 F2_0). unfold magma_op, reff96_inst, reff96_op in H. discriminate H. Qed.

Lemma reff96_not3152 : ~ @Equation3152 Fin2 reff96_inst.
Proof. unfold Equation3152. intro H. specialize (H F2_1 F2_0). unfold magma_op, reff96_inst, reff96_op in H. discriminate H. Qed.

Lemma reff96_not3254 : ~ @Equation3254 Fin2 reff96_inst.
Proof. unfold Equation3254. intro H. specialize (H F2_1 F2_0). unfold magma_op, reff96_inst, reff96_op in H. discriminate H. Qed.

Lemma reff96_not3255 : ~ @Equation3255 Fin2 reff96_inst.
Proof. unfold Equation3255. intro H. specialize (H F2_1 F2_0). unfold magma_op, reff96_inst, reff96_op in H. discriminate H. Qed.

Lemma reff96_not3256 : ~ @Equation3256 Fin2 reff96_inst.
Proof. unfold Equation3256. intro H. specialize (H F2_1 F2_0). unfold magma_op, reff96_inst, reff96_op in H. discriminate H. Qed.

Lemma reff96_not3258 : ~ @Equation3258 Fin2 reff96_inst.
Proof. unfold Equation3258. intro H. specialize (H F2_1 F2_0). unfold magma_op, reff96_inst, reff96_op in H. discriminate H. Qed.

Lemma reff96_not3259 : ~ @Equation3259 Fin2 reff96_inst.
Proof. unfold Equation3259. intro H. specialize (H F2_1 F2_0). unfold magma_op, reff96_inst, reff96_op in H. discriminate H. Qed.

Lemma reff96_not3261 : ~ @Equation3261 Fin2 reff96_inst.
Proof. unfold Equation3261. intro H. specialize (H F2_1 F2_0). unfold magma_op, reff96_inst, reff96_op in H. discriminate H. Qed.

Lemma reff96_not3262 : ~ @Equation3262 Fin2 reff96_inst.
Proof. unfold Equation3262. intro H. specialize (H F2_1 F2_0). unfold magma_op, reff96_inst, reff96_op in H. discriminate H. Qed.

Lemma reff96_not3268 : ~ @Equation3268 Fin2 reff96_inst.
Proof. unfold Equation3268. intro H. specialize (H F2_1 F2_0). unfold magma_op, reff96_inst, reff96_op in H. discriminate H. Qed.

Lemma reff96_not3269 : ~ @Equation3269 Fin2 reff96_inst.
Proof. unfold Equation3269. intro H. specialize (H F2_1 F2_0). unfold magma_op, reff96_inst, reff96_op in H. discriminate H. Qed.

Lemma reff96_not3271 : ~ @Equation3271 Fin2 reff96_inst.
Proof. unfold Equation3271. intro H. specialize (H F2_1 F2_0). unfold magma_op, reff96_inst, reff96_op in H. discriminate H. Qed.

Lemma reff96_not3272 : ~ @Equation3272 Fin2 reff96_inst.
Proof. unfold Equation3272. intro H. specialize (H F2_1 F2_0). unfold magma_op, reff96_inst, reff96_op in H. discriminate H. Qed.

Lemma reff96_not3278 : ~ @Equation3278 Fin2 reff96_inst.
Proof. unfold Equation3278. intro H. specialize (H F2_1 F2_0). unfold magma_op, reff96_inst, reff96_op in H. discriminate H. Qed.

Lemma reff96_not3279 : ~ @Equation3279 Fin2 reff96_inst.
Proof. unfold Equation3279. intro H. specialize (H F2_1 F2_0). unfold magma_op, reff96_inst, reff96_op in H. discriminate H. Qed.

Lemma reff96_not3281 : ~ @Equation3281 Fin2 reff96_inst.
Proof. unfold Equation3281. intro H. specialize (H F2_1 F2_0). unfold magma_op, reff96_inst, reff96_op in H. discriminate H. Qed.

Lemma reff96_not3457 : ~ @Equation3457 Fin2 reff96_inst.
Proof. unfold Equation3457. intro H. specialize (H F2_1 F2_0). unfold magma_op, reff96_inst, reff96_op in H. discriminate H. Qed.

Lemma reff96_not3458 : ~ @Equation3458 Fin2 reff96_inst.
Proof. unfold Equation3458. intro H. specialize (H F2_1 F2_0). unfold magma_op, reff96_inst, reff96_op in H. discriminate H. Qed.

Lemma reff96_not3459 : ~ @Equation3459 Fin2 reff96_inst.
Proof. unfold Equation3459. intro H. specialize (H F2_1 F2_0). unfold magma_op, reff96_inst, reff96_op in H. discriminate H. Qed.

Lemma reff96_not3461 : ~ @Equation3461 Fin2 reff96_inst.
Proof. unfold Equation3461. intro H. specialize (H F2_1 F2_0). unfold magma_op, reff96_inst, reff96_op in H. discriminate H. Qed.

Lemma reff96_not3462 : ~ @Equation3462 Fin2 reff96_inst.
Proof. unfold Equation3462. intro H. specialize (H F2_1 F2_0). unfold magma_op, reff96_inst, reff96_op in H. discriminate H. Qed.

Lemma reff96_not3464 : ~ @Equation3464 Fin2 reff96_inst.
Proof. unfold Equation3464. intro H. specialize (H F2_1 F2_0). unfold magma_op, reff96_inst, reff96_op in H. discriminate H. Qed.

Lemma reff96_not3465 : ~ @Equation3465 Fin2 reff96_inst.
Proof. unfold Equation3465. intro H. specialize (H F2_1 F2_0). unfold magma_op, reff96_inst, reff96_op in H. discriminate H. Qed.

Lemma reff96_not3472 : ~ @Equation3472 Fin2 reff96_inst.
Proof. unfold Equation3472. intro H. specialize (H F2_1 F2_0). unfold magma_op, reff96_inst, reff96_op in H. discriminate H. Qed.

Lemma reff96_not3474 : ~ @Equation3474 Fin2 reff96_inst.
Proof. unfold Equation3474. intro H. specialize (H F2_1 F2_0). unfold magma_op, reff96_inst, reff96_op in H. discriminate H. Qed.

Lemma reff96_not3475 : ~ @Equation3475 Fin2 reff96_inst.
Proof. unfold Equation3475. intro H. specialize (H F2_1 F2_0). unfold magma_op, reff96_inst, reff96_op in H. discriminate H. Qed.

Lemma reff96_not3481 : ~ @Equation3481 Fin2 reff96_inst.
Proof. unfold Equation3481. intro H. specialize (H F2_1 F2_0). unfold magma_op, reff96_inst, reff96_op in H. discriminate H. Qed.

Lemma reff96_not3482 : ~ @Equation3482 Fin2 reff96_inst.
Proof. unfold Equation3482. intro H. specialize (H F2_1 F2_0). unfold magma_op, reff96_inst, reff96_op in H. discriminate H. Qed.

Lemma reff96_not3484 : ~ @Equation3484 Fin2 reff96_inst.
Proof. unfold Equation3484. intro H. specialize (H F2_1 F2_0). unfold magma_op, reff96_inst, reff96_op in H. discriminate H. Qed.

Lemma reff96_not3660 : ~ @Equation3660 Fin2 reff96_inst.
Proof. unfold Equation3660. intro H. specialize (H F2_1 F2_0). unfold magma_op, reff96_inst, reff96_op in H. discriminate H. Qed.

Lemma reff96_not3661 : ~ @Equation3661 Fin2 reff96_inst.
Proof. unfold Equation3661. intro H. specialize (H F2_1 F2_0). unfold magma_op, reff96_inst, reff96_op in H. discriminate H. Qed.

Lemma reff96_not3662 : ~ @Equation3662 Fin2 reff96_inst.
Proof. unfold Equation3662. intro H. specialize (H F2_1 F2_0). unfold magma_op, reff96_inst, reff96_op in H. discriminate H. Qed.

Lemma reff96_not3664 : ~ @Equation3664 Fin2 reff96_inst.
Proof. unfold Equation3664. intro H. specialize (H F2_1 F2_0). unfold magma_op, reff96_inst, reff96_op in H. discriminate H. Qed.

Lemma reff96_not3665 : ~ @Equation3665 Fin2 reff96_inst.
Proof. unfold Equation3665. intro H. specialize (H F2_1 F2_0). unfold magma_op, reff96_inst, reff96_op in H. discriminate H. Qed.

Lemma reff96_not3667 : ~ @Equation3667 Fin2 reff96_inst.
Proof. unfold Equation3667. intro H. specialize (H F2_1 F2_0). unfold magma_op, reff96_inst, reff96_op in H. discriminate H. Qed.

Lemma reff96_not3668 : ~ @Equation3668 Fin2 reff96_inst.
Proof. unfold Equation3668. intro H. specialize (H F2_1 F2_0). unfold magma_op, reff96_inst, reff96_op in H. discriminate H. Qed.

Lemma reff96_not3674 : ~ @Equation3674 Fin2 reff96_inst.
Proof. unfold Equation3674. intro H. specialize (H F2_1 F2_0). unfold magma_op, reff96_inst, reff96_op in H. discriminate H. Qed.

Lemma reff96_not3675 : ~ @Equation3675 Fin2 reff96_inst.
Proof. unfold Equation3675. intro H. specialize (H F2_1 F2_0). unfold magma_op, reff96_inst, reff96_op in H. discriminate H. Qed.

Lemma reff96_not3677 : ~ @Equation3677 Fin2 reff96_inst.
Proof. unfold Equation3677. intro H. specialize (H F2_1 F2_0). unfold magma_op, reff96_inst, reff96_op in H. discriminate H. Qed.

Lemma reff96_not3678 : ~ @Equation3678 Fin2 reff96_inst.
Proof. unfold Equation3678. intro H. specialize (H F2_1 F2_0). unfold magma_op, reff96_inst, reff96_op in H. discriminate H. Qed.

Lemma reff96_not3684 : ~ @Equation3684 Fin2 reff96_inst.
Proof. unfold Equation3684. intro H. specialize (H F2_1 F2_0). unfold magma_op, reff96_inst, reff96_op in H. discriminate H. Qed.

Lemma reff96_not3685 : ~ @Equation3685 Fin2 reff96_inst.
Proof. unfold Equation3685. intro H. specialize (H F2_1 F2_0). unfold magma_op, reff96_inst, reff96_op in H. discriminate H. Qed.

Lemma reff96_not3687 : ~ @Equation3687 Fin2 reff96_inst.
Proof. unfold Equation3687. intro H. specialize (H F2_1 F2_0). unfold magma_op, reff96_inst, reff96_op in H. discriminate H. Qed.

Lemma reff96_not3864 : ~ @Equation3864 Fin2 reff96_inst.
Proof. unfold Equation3864. intro H. specialize (H F2_1 F2_0). unfold magma_op, reff96_inst, reff96_op in H. discriminate H. Qed.

Lemma reff96_not3865 : ~ @Equation3865 Fin2 reff96_inst.
Proof. unfold Equation3865. intro H. specialize (H F2_1 F2_0). unfold magma_op, reff96_inst, reff96_op in H. discriminate H. Qed.

Lemma reff96_not3867 : ~ @Equation3867 Fin2 reff96_inst.
Proof. unfold Equation3867. intro H. specialize (H F2_1 F2_0). unfold magma_op, reff96_inst, reff96_op in H. discriminate H. Qed.

Lemma reff96_not3868 : ~ @Equation3868 Fin2 reff96_inst.
Proof. unfold Equation3868. intro H. specialize (H F2_1 F2_0). unfold magma_op, reff96_inst, reff96_op in H. discriminate H. Qed.

Lemma reff96_not3870 : ~ @Equation3870 Fin2 reff96_inst.
Proof. unfold Equation3870. intro H. specialize (H F2_1 F2_0). unfold magma_op, reff96_inst, reff96_op in H. discriminate H. Qed.

Lemma reff96_not3871 : ~ @Equation3871 Fin2 reff96_inst.
Proof. unfold Equation3871. intro H. specialize (H F2_1 F2_0). unfold magma_op, reff96_inst, reff96_op in H. discriminate H. Qed.

Lemma reff96_not3877 : ~ @Equation3877 Fin2 reff96_inst.
Proof. unfold Equation3877. intro H. specialize (H F2_1 F2_0). unfold magma_op, reff96_inst, reff96_op in H. discriminate H. Qed.

Lemma reff96_not3878 : ~ @Equation3878 Fin2 reff96_inst.
Proof. unfold Equation3878. intro H. specialize (H F2_1 F2_0). unfold magma_op, reff96_inst, reff96_op in H. discriminate H. Qed.

Lemma reff96_not3880 : ~ @Equation3880 Fin2 reff96_inst.
Proof. unfold Equation3880. intro H. specialize (H F2_1 F2_0). unfold magma_op, reff96_inst, reff96_op in H. discriminate H. Qed.

Lemma reff96_not3881 : ~ @Equation3881 Fin2 reff96_inst.
Proof. unfold Equation3881. intro H. specialize (H F2_1 F2_0). unfold magma_op, reff96_inst, reff96_op in H. discriminate H. Qed.

Lemma reff96_not3887 : ~ @Equation3887 Fin2 reff96_inst.
Proof. unfold Equation3887. intro H. specialize (H F2_1 F2_0). unfold magma_op, reff96_inst, reff96_op in H. discriminate H. Qed.

Lemma reff96_not3888 : ~ @Equation3888 Fin2 reff96_inst.
Proof. unfold Equation3888. intro H. specialize (H F2_1 F2_0). unfold magma_op, reff96_inst, reff96_op in H. discriminate H. Qed.

Lemma reff96_not3890 : ~ @Equation3890 Fin2 reff96_inst.
Proof. unfold Equation3890. intro H. specialize (H F2_1 F2_0). unfold magma_op, reff96_inst, reff96_op in H. discriminate H. Qed.

Lemma reff96_not4066 : ~ @Equation4066 Fin2 reff96_inst.
Proof. unfold Equation4066. intro H. specialize (H F2_1 F2_0). unfold magma_op, reff96_inst, reff96_op in H. discriminate H. Qed.

Lemma reff96_not4067 : ~ @Equation4067 Fin2 reff96_inst.
Proof. unfold Equation4067. intro H. specialize (H F2_1 F2_0). unfold magma_op, reff96_inst, reff96_op in H. discriminate H. Qed.

Lemma reff96_not4068 : ~ @Equation4068 Fin2 reff96_inst.
Proof. unfold Equation4068. intro H. specialize (H F2_1 F2_0). unfold magma_op, reff96_inst, reff96_op in H. discriminate H. Qed.

Lemma reff96_not4070 : ~ @Equation4070 Fin2 reff96_inst.
Proof. unfold Equation4070. intro H. specialize (H F2_1 F2_0). unfold magma_op, reff96_inst, reff96_op in H. discriminate H. Qed.

Lemma reff96_not4071 : ~ @Equation4071 Fin2 reff96_inst.
Proof. unfold Equation4071. intro H. specialize (H F2_1 F2_0). unfold magma_op, reff96_inst, reff96_op in H. discriminate H. Qed.

Lemma reff96_not4073 : ~ @Equation4073 Fin2 reff96_inst.
Proof. unfold Equation4073. intro H. specialize (H F2_1 F2_0). unfold magma_op, reff96_inst, reff96_op in H. discriminate H. Qed.

Lemma reff96_not4074 : ~ @Equation4074 Fin2 reff96_inst.
Proof. unfold Equation4074. intro H. specialize (H F2_1 F2_0). unfold magma_op, reff96_inst, reff96_op in H. discriminate H. Qed.

Lemma reff96_not4080 : ~ @Equation4080 Fin2 reff96_inst.
Proof. unfold Equation4080. intro H. specialize (H F2_1 F2_0). unfold magma_op, reff96_inst, reff96_op in H. discriminate H. Qed.

Lemma reff96_not4081 : ~ @Equation4081 Fin2 reff96_inst.
Proof. unfold Equation4081. intro H. specialize (H F2_1 F2_0). unfold magma_op, reff96_inst, reff96_op in H. discriminate H. Qed.

Lemma reff96_not4083 : ~ @Equation4083 Fin2 reff96_inst.
Proof. unfold Equation4083. intro H. specialize (H F2_1 F2_0). unfold magma_op, reff96_inst, reff96_op in H. discriminate H. Qed.

Lemma reff96_not4084 : ~ @Equation4084 Fin2 reff96_inst.
Proof. unfold Equation4084. intro H. specialize (H F2_1 F2_0). unfold magma_op, reff96_inst, reff96_op in H. discriminate H. Qed.

Lemma reff96_not4090 : ~ @Equation4090 Fin2 reff96_inst.
Proof. unfold Equation4090. intro H. specialize (H F2_1 F2_0). unfold magma_op, reff96_inst, reff96_op in H. discriminate H. Qed.

Lemma reff96_not4091 : ~ @Equation4091 Fin2 reff96_inst.
Proof. unfold Equation4091. intro H. specialize (H F2_1 F2_0). unfold magma_op, reff96_inst, reff96_op in H. discriminate H. Qed.

Lemma reff96_not4093 : ~ @Equation4093 Fin2 reff96_inst.
Proof. unfold Equation4093. intro H. specialize (H F2_1 F2_0). unfold magma_op, reff96_inst, reff96_op in H. discriminate H. Qed.

Lemma reff96_not4268 : ~ @Equation4268 Fin2 reff96_inst.
Proof. unfold Equation4268. intro H. specialize (H F2_1 F2_0). unfold magma_op, reff96_inst, reff96_op in H. discriminate H. Qed.

Lemma reff96_not4269 : ~ @Equation4269 Fin2 reff96_inst.
Proof. unfold Equation4269. intro H. specialize (H F2_1 F2_0). unfold magma_op, reff96_inst, reff96_op in H. discriminate H. Qed.

Lemma reff96_not4270 : ~ @Equation4270 Fin2 reff96_inst.
Proof. unfold Equation4270. intro H. specialize (H F2_1 F2_0). unfold magma_op, reff96_inst, reff96_op in H. discriminate H. Qed.

Lemma reff96_not4272 : ~ @Equation4272 Fin2 reff96_inst.
Proof. unfold Equation4272. intro H. specialize (H F2_1 F2_0). unfold magma_op, reff96_inst, reff96_op in H. discriminate H. Qed.

Lemma reff96_not4273 : ~ @Equation4273 Fin2 reff96_inst.
Proof. unfold Equation4273. intro H. specialize (H F2_1 F2_0). unfold magma_op, reff96_inst, reff96_op in H. discriminate H. Qed.

Lemma reff96_not4275 : ~ @Equation4275 Fin2 reff96_inst.
Proof. unfold Equation4275. intro H. specialize (H F2_1 F2_0). unfold magma_op, reff96_inst, reff96_op in H. discriminate H. Qed.

Lemma reff96_not4276 : ~ @Equation4276 Fin2 reff96_inst.
Proof. unfold Equation4276. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff96_inst, reff96_op in H. discriminate H. Qed.

Lemma reff96_not4583 : ~ @Equation4583 Fin2 reff96_inst.
Proof. unfold Equation4583. intro H. specialize (H F2_1 F2_0). unfold magma_op, reff96_inst, reff96_op in H. discriminate H. Qed.

Lemma reff96_not4584 : ~ @Equation4584 Fin2 reff96_inst.
Proof. unfold Equation4584. intro H. specialize (H F2_1 F2_0). unfold magma_op, reff96_inst, reff96_op in H. discriminate H. Qed.

Lemma reff96_not4585 : ~ @Equation4585 Fin2 reff96_inst.
Proof. unfold Equation4585. intro H. specialize (H F2_1 F2_0). unfold magma_op, reff96_inst, reff96_op in H. discriminate H. Qed.

Lemma reff96_not4587 : ~ @Equation4587 Fin2 reff96_inst.
Proof. unfold Equation4587. intro H. specialize (H F2_1 F2_0). unfold magma_op, reff96_inst, reff96_op in H. discriminate H. Qed.

Lemma reff96_not4588 : ~ @Equation4588 Fin2 reff96_inst.
Proof. unfold Equation4588. intro H. specialize (H F2_1 F2_0). unfold magma_op, reff96_inst, reff96_op in H. discriminate H. Qed.

Lemma reff96_not4590 : ~ @Equation4590 Fin2 reff96_inst.
Proof. unfold Equation4590. intro H. specialize (H F2_1 F2_0). unfold magma_op, reff96_inst, reff96_op in H. discriminate H. Qed.

Lemma reff96_not4591 : ~ @Equation4591 Fin2 reff96_inst.
Proof. unfold Equation4591. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff96_inst, reff96_op in H. discriminate H. Qed.
