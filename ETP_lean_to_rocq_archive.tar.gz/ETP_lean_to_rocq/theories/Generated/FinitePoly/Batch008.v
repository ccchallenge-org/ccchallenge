(** * FinitePoly counterexamples — batch 8
    Auto-generated from Lean4 FinitePoly files. *)

From Stdlib Require Import Utf8.

From ETP Require Import Magma.
From ETP Require Import FinMagma.
From ETP.Equations Require Import All.

Open Scope magma_scope.

(** ---- reff366 (Fin4) ---- *)

Definition reff366_op (x y : Fin4) : Fin4 :=
  match x, y with
  | F4_0, F4_0 => F4_0 | F4_0, F4_1 => F4_0 | F4_0, F4_2 => F4_2 | F4_0, F4_3 => F4_2
  | F4_1, F4_0 => F4_2 | F4_1, F4_1 => F4_2 | F4_1, F4_2 => F4_0 | F4_1, F4_3 => F4_0
  | F4_2, F4_0 => F4_0 | F4_2, F4_1 => F4_0 | F4_2, F4_2 => F4_2 | F4_2, F4_3 => F4_2
  | F4_3, F4_0 => F4_2 | F4_3, F4_1 => F4_2 | F4_3, F4_2 => F4_0 | F4_3, F4_3 => F4_0
  end.

#[local] Instance reff366_inst : Magma Fin4 := {| magma_op := reff366_op |}.

Lemma reff366_sat3388 : @Equation3388 Fin4 reff366_inst.
Proof. unfold Equation3388, magma_op, reff366_inst, reff366_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff366_sat3541 : @Equation3541 Fin4 reff366_inst.
Proof. unfold Equation3541, magma_op, reff366_inst, reff366_op. intros x y z w. destruct x, y, z, w; reflexivity. Qed.

Lemma reff366_sat3837 : @Equation3837 Fin4 reff366_inst.
Proof. unfold Equation3837, magma_op, reff366_inst, reff366_op. intros x y z w. destruct x, y, z, w; reflexivity. Qed.

Lemma reff366_sat4428 : @Equation4428 Fin4 reff366_inst.
Proof. unfold Equation4428, magma_op, reff366_inst, reff366_op. intros x y z w. destruct x, y, z, w; reflexivity. Qed.

Lemma reff366_not47 : ~ @Equation47 Fin4 reff366_inst.
Proof. unfold Equation47. intro H. specialize (H F4_1). unfold magma_op, reff366_inst, reff366_op in H. discriminate H. Qed.

Lemma reff366_not99 : ~ @Equation99 Fin4 reff366_inst.
Proof. unfold Equation99. intro H. specialize (H F4_1). unfold magma_op, reff366_inst, reff366_op in H. discriminate H. Qed.

Lemma reff366_not151 : ~ @Equation151 Fin4 reff366_inst.
Proof. unfold Equation151. intro H. specialize (H F4_1). unfold magma_op, reff366_inst, reff366_op in H. discriminate H. Qed.

Lemma reff366_not203 : ~ @Equation203 Fin4 reff366_inst.
Proof. unfold Equation203. intro H. specialize (H F4_1). unfold magma_op, reff366_inst, reff366_op in H. discriminate H. Qed.

Lemma reff366_not255 : ~ @Equation255 Fin4 reff366_inst.
Proof. unfold Equation255. intro H. specialize (H F4_1). unfold magma_op, reff366_inst, reff366_op in H. discriminate H. Qed.

Lemma reff366_not307 : ~ @Equation307 Fin4 reff366_inst.
Proof. unfold Equation307. intro H. specialize (H F4_1). unfold magma_op, reff366_inst, reff366_op in H. discriminate H. Qed.

Lemma reff366_not411 : ~ @Equation411 Fin4 reff366_inst.
Proof. unfold Equation411. intro H. specialize (H F4_1). unfold magma_op, reff366_inst, reff366_op in H. discriminate H. Qed.

Lemma reff366_not614 : ~ @Equation614 Fin4 reff366_inst.
Proof. unfold Equation614. intro H. specialize (H F4_1). unfold magma_op, reff366_inst, reff366_op in H. discriminate H. Qed.

Lemma reff366_not817 : ~ @Equation817 Fin4 reff366_inst.
Proof. unfold Equation817. intro H. specialize (H F4_1). unfold magma_op, reff366_inst, reff366_op in H. discriminate H. Qed.

Lemma reff366_not1020 : ~ @Equation1020 Fin4 reff366_inst.
Proof. unfold Equation1020. intro H. specialize (H F4_1). unfold magma_op, reff366_inst, reff366_op in H. discriminate H. Qed.

Lemma reff366_not1223 : ~ @Equation1223 Fin4 reff366_inst.
Proof. unfold Equation1223. intro H. specialize (H F4_1). unfold magma_op, reff366_inst, reff366_op in H. discriminate H. Qed.

Lemma reff366_not1426 : ~ @Equation1426 Fin4 reff366_inst.
Proof. unfold Equation1426. intro H. specialize (H F4_1). unfold magma_op, reff366_inst, reff366_op in H. discriminate H. Qed.

Lemma reff366_not1629 : ~ @Equation1629 Fin4 reff366_inst.
Proof. unfold Equation1629. intro H. specialize (H F4_1). unfold magma_op, reff366_inst, reff366_op in H. discriminate H. Qed.

Lemma reff366_not1832 : ~ @Equation1832 Fin4 reff366_inst.
Proof. unfold Equation1832. intro H. specialize (H F4_1). unfold magma_op, reff366_inst, reff366_op in H. discriminate H. Qed.

Lemma reff366_not2035 : ~ @Equation2035 Fin4 reff366_inst.
Proof. unfold Equation2035. intro H. specialize (H F4_1). unfold magma_op, reff366_inst, reff366_op in H. discriminate H. Qed.

Lemma reff366_not2238 : ~ @Equation2238 Fin4 reff366_inst.
Proof. unfold Equation2238. intro H. specialize (H F4_1). unfold magma_op, reff366_inst, reff366_op in H. discriminate H. Qed.

Lemma reff366_not2441 : ~ @Equation2441 Fin4 reff366_inst.
Proof. unfold Equation2441. intro H. specialize (H F4_1). unfold magma_op, reff366_inst, reff366_op in H. discriminate H. Qed.

Lemma reff366_not2644 : ~ @Equation2644 Fin4 reff366_inst.
Proof. unfold Equation2644. intro H. specialize (H F4_1). unfold magma_op, reff366_inst, reff366_op in H. discriminate H. Qed.

Lemma reff366_not2847 : ~ @Equation2847 Fin4 reff366_inst.
Proof. unfold Equation2847. intro H. specialize (H F4_1). unfold magma_op, reff366_inst, reff366_op in H. discriminate H. Qed.

Lemma reff366_not3050 : ~ @Equation3050 Fin4 reff366_inst.
Proof. unfold Equation3050. intro H. specialize (H F4_1). unfold magma_op, reff366_inst, reff366_op in H. discriminate H. Qed.

Lemma reff366_not3254 : ~ @Equation3254 Fin4 reff366_inst.
Proof. unfold Equation3254. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff366_inst, reff366_op in H. discriminate H. Qed.

Lemma reff366_not3255 : ~ @Equation3255 Fin4 reff366_inst.
Proof. unfold Equation3255. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff366_inst, reff366_op in H. discriminate H. Qed.

Lemma reff366_not3256 : ~ @Equation3256 Fin4 reff366_inst.
Proof. unfold Equation3256. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff366_inst, reff366_op in H. discriminate H. Qed.

Lemma reff366_not3258 : ~ @Equation3258 Fin4 reff366_inst.
Proof. unfold Equation3258. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff366_inst, reff366_op in H. discriminate H. Qed.

Lemma reff366_not3259 : ~ @Equation3259 Fin4 reff366_inst.
Proof. unfold Equation3259. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff366_inst, reff366_op in H. discriminate H. Qed.

Lemma reff366_not3262 : ~ @Equation3262 Fin4 reff366_inst.
Proof. unfold Equation3262. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff366_inst, reff366_op in H. discriminate H. Qed.

Lemma reff366_not3268 : ~ @Equation3268 Fin4 reff366_inst.
Proof. unfold Equation3268. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff366_inst, reff366_op in H. discriminate H. Qed.

Lemma reff366_not3269 : ~ @Equation3269 Fin4 reff366_inst.
Proof. unfold Equation3269. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff366_inst, reff366_op in H. discriminate H. Qed.

Lemma reff366_not3272 : ~ @Equation3272 Fin4 reff366_inst.
Proof. unfold Equation3272. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff366_inst, reff366_op in H. discriminate H. Qed.

Lemma reff366_not3279 : ~ @Equation3279 Fin4 reff366_inst.
Proof. unfold Equation3279. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff366_inst, reff366_op in H. discriminate H. Qed.

Lemma reff366_not3281 : ~ @Equation3281 Fin4 reff366_inst.
Proof. unfold Equation3281. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff366_inst, reff366_op in H. discriminate H. Qed.

Lemma reff366_not3308 : ~ @Equation3308 Fin4 reff366_inst.
Proof. unfold Equation3308. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff366_inst, reff366_op in H. discriminate H. Qed.

Lemma reff366_not3309 : ~ @Equation3309 Fin4 reff366_inst.
Proof. unfold Equation3309. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff366_inst, reff366_op in H. discriminate H. Qed.

Lemma reff366_not3315 : ~ @Equation3315 Fin4 reff366_inst.
Proof. unfold Equation3315. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff366_inst, reff366_op in H. discriminate H. Qed.

Lemma reff366_not3316 : ~ @Equation3316 Fin4 reff366_inst.
Proof. unfold Equation3316. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff366_inst, reff366_op in H. discriminate H. Qed.

Lemma reff366_not3318 : ~ @Equation3318 Fin4 reff366_inst.
Proof. unfold Equation3318. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff366_inst, reff366_op in H. discriminate H. Qed.

Lemma reff366_not3342 : ~ @Equation3342 Fin4 reff366_inst.
Proof. unfold Equation3342. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff366_inst, reff366_op in H. discriminate H. Qed.

Lemma reff366_not3343 : ~ @Equation3343 Fin4 reff366_inst.
Proof. unfold Equation3343. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff366_inst, reff366_op in H. discriminate H. Qed.

Lemma reff366_not3345 : ~ @Equation3345 Fin4 reff366_inst.
Proof. unfold Equation3345. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff366_inst, reff366_op in H. discriminate H. Qed.

Lemma reff366_not3352 : ~ @Equation3352 Fin4 reff366_inst.
Proof. unfold Equation3352. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff366_inst, reff366_op in H. discriminate H. Qed.

Lemma reff366_not3457 : ~ @Equation3457 Fin4 reff366_inst.
Proof. unfold Equation3457. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff366_inst, reff366_op in H. discriminate H. Qed.

Lemma reff366_not3459 : ~ @Equation3459 Fin4 reff366_inst.
Proof. unfold Equation3459. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff366_inst, reff366_op in H. discriminate H. Qed.

Lemma reff366_not3462 : ~ @Equation3462 Fin4 reff366_inst.
Proof. unfold Equation3462. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff366_inst, reff366_op in H. discriminate H. Qed.

Lemma reff366_not3465 : ~ @Equation3465 Fin4 reff366_inst.
Proof. unfold Equation3465. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff366_inst, reff366_op in H. discriminate H. Qed.

Lemma reff366_not3472 : ~ @Equation3472 Fin4 reff366_inst.
Proof. unfold Equation3472. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff366_inst, reff366_op in H. discriminate H. Qed.

Lemma reff366_not3474 : ~ @Equation3474 Fin4 reff366_inst.
Proof. unfold Equation3474. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff366_inst, reff366_op in H. discriminate H. Qed.

Lemma reff366_not3475 : ~ @Equation3475 Fin4 reff366_inst.
Proof. unfold Equation3475. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff366_inst, reff366_op in H. discriminate H. Qed.

Lemma reff366_not3481 : ~ @Equation3481 Fin4 reff366_inst.
Proof. unfold Equation3481. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff366_inst, reff366_op in H. discriminate H. Qed.

Lemma reff366_not3482 : ~ @Equation3482 Fin4 reff366_inst.
Proof. unfold Equation3482. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff366_inst, reff366_op in H. discriminate H. Qed.

Lemma reff366_not3484 : ~ @Equation3484 Fin4 reff366_inst.
Proof. unfold Equation3484. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff366_inst, reff366_op in H. discriminate H. Qed.

Lemma reff366_not3511 : ~ @Equation3511 Fin4 reff366_inst.
Proof. unfold Equation3511. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff366_inst, reff366_op in H. discriminate H. Qed.

Lemma reff366_not3518 : ~ @Equation3518 Fin4 reff366_inst.
Proof. unfold Equation3518. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff366_inst, reff366_op in H. discriminate H. Qed.

Lemma reff366_not3521 : ~ @Equation3521 Fin4 reff366_inst.
Proof. unfold Equation3521. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff366_inst, reff366_op in H. discriminate H. Qed.

Lemma reff366_not3545 : ~ @Equation3545 Fin4 reff366_inst.
Proof. unfold Equation3545. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff366_inst, reff366_op in H. discriminate H. Qed.

Lemma reff366_not3546 : ~ @Equation3546 Fin4 reff366_inst.
Proof. unfold Equation3546. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff366_inst, reff366_op in H. discriminate H. Qed.

Lemma reff366_not3548 : ~ @Equation3548 Fin4 reff366_inst.
Proof. unfold Equation3548. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff366_inst, reff366_op in H. discriminate H. Qed.

Lemma reff366_not3549 : ~ @Equation3549 Fin4 reff366_inst.
Proof. unfold Equation3549. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff366_inst, reff366_op in H. discriminate H. Qed.

Lemma reff366_not3555 : ~ @Equation3555 Fin4 reff366_inst.
Proof. unfold Equation3555. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff366_inst, reff366_op in H. discriminate H. Qed.

Lemma reff366_not3558 : ~ @Equation3558 Fin4 reff366_inst.
Proof. unfold Equation3558. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff366_inst, reff366_op in H. discriminate H. Qed.

Lemma reff366_not3660 : ~ @Equation3660 Fin4 reff366_inst.
Proof. unfold Equation3660. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff366_inst, reff366_op in H. discriminate H. Qed.

Lemma reff366_not3661 : ~ @Equation3661 Fin4 reff366_inst.
Proof. unfold Equation3661. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff366_inst, reff366_op in H. discriminate H. Qed.

Lemma reff366_not3662 : ~ @Equation3662 Fin4 reff366_inst.
Proof. unfold Equation3662. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff366_inst, reff366_op in H. discriminate H. Qed.

Lemma reff366_not3665 : ~ @Equation3665 Fin4 reff366_inst.
Proof. unfold Equation3665. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff366_inst, reff366_op in H. discriminate H. Qed.

Lemma reff366_not3667 : ~ @Equation3667 Fin4 reff366_inst.
Proof. unfold Equation3667. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff366_inst, reff366_op in H. discriminate H. Qed.

Lemma reff366_not3668 : ~ @Equation3668 Fin4 reff366_inst.
Proof. unfold Equation3668. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff366_inst, reff366_op in H. discriminate H. Qed.

Lemma reff366_not3675 : ~ @Equation3675 Fin4 reff366_inst.
Proof. unfold Equation3675. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff366_inst, reff366_op in H. discriminate H. Qed.

Lemma reff366_not3677 : ~ @Equation3677 Fin4 reff366_inst.
Proof. unfold Equation3677. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff366_inst, reff366_op in H. discriminate H. Qed.

Lemma reff366_not3678 : ~ @Equation3678 Fin4 reff366_inst.
Proof. unfold Equation3678. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff366_inst, reff366_op in H. discriminate H. Qed.

Lemma reff366_not3685 : ~ @Equation3685 Fin4 reff366_inst.
Proof. unfold Equation3685. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff366_inst, reff366_op in H. discriminate H. Qed.

Lemma reff366_not3687 : ~ @Equation3687 Fin4 reff366_inst.
Proof. unfold Equation3687. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff366_inst, reff366_op in H. discriminate H. Qed.

Lemma reff366_not3714 : ~ @Equation3714 Fin4 reff366_inst.
Proof. unfold Equation3714. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff366_inst, reff366_op in H. discriminate H. Qed.

Lemma reff366_not3721 : ~ @Equation3721 Fin4 reff366_inst.
Proof. unfold Equation3721. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff366_inst, reff366_op in H. discriminate H. Qed.

Lemma reff366_not3724 : ~ @Equation3724 Fin4 reff366_inst.
Proof. unfold Equation3724. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff366_inst, reff366_op in H. discriminate H. Qed.

Lemma reff366_not3725 : ~ @Equation3725 Fin4 reff366_inst.
Proof. unfold Equation3725. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff366_inst, reff366_op in H. discriminate H. Qed.

Lemma reff366_not3748 : ~ @Equation3748 Fin4 reff366_inst.
Proof. unfold Equation3748. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff366_inst, reff366_op in H. discriminate H. Qed.

Lemma reff366_not3751 : ~ @Equation3751 Fin4 reff366_inst.
Proof. unfold Equation3751. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff366_inst, reff366_op in H. discriminate H. Qed.

Lemma reff366_not3752 : ~ @Equation3752 Fin4 reff366_inst.
Proof. unfold Equation3752. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff366_inst, reff366_op in H. discriminate H. Qed.

Lemma reff366_not3761 : ~ @Equation3761 Fin4 reff366_inst.
Proof. unfold Equation3761. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff366_inst, reff366_op in H. discriminate H. Qed.

Lemma reff366_not3862 : ~ @Equation3862 Fin4 reff366_inst.
Proof. unfold Equation3862. intro H. specialize (H F4_1). unfold magma_op, reff366_inst, reff366_op in H. discriminate H. Qed.

Lemma reff366_not4065 : ~ @Equation4065 Fin4 reff366_inst.
Proof. unfold Equation4065. intro H. specialize (H F4_1). unfold magma_op, reff366_inst, reff366_op in H. discriminate H. Qed.

Lemma reff366_not4268 : ~ @Equation4268 Fin4 reff366_inst.
Proof. unfold Equation4268. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff366_inst, reff366_op in H. discriminate H. Qed.

Lemma reff366_not4269 : ~ @Equation4269 Fin4 reff366_inst.
Proof. unfold Equation4269. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff366_inst, reff366_op in H. discriminate H. Qed.

Lemma reff366_not4270 : ~ @Equation4270 Fin4 reff366_inst.
Proof. unfold Equation4270. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff366_inst, reff366_op in H. discriminate H. Qed.

Lemma reff366_not4272 : ~ @Equation4272 Fin4 reff366_inst.
Proof. unfold Equation4272. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff366_inst, reff366_op in H. discriminate H. Qed.

Lemma reff366_not4273 : ~ @Equation4273 Fin4 reff366_inst.
Proof. unfold Equation4273. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff366_inst, reff366_op in H. discriminate H. Qed.

Lemma reff366_not4276 : ~ @Equation4276 Fin4 reff366_inst.
Proof. unfold Equation4276. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff366_inst, reff366_op in H. discriminate H. Qed.

Lemma reff366_not4283 : ~ @Equation4283 Fin4 reff366_inst.
Proof. unfold Equation4283. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff366_inst, reff366_op in H. discriminate H. Qed.

Lemma reff366_not4284 : ~ @Equation4284 Fin4 reff366_inst.
Proof. unfold Equation4284. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff366_inst, reff366_op in H. discriminate H. Qed.

Lemma reff366_not4290 : ~ @Equation4290 Fin4 reff366_inst.
Proof. unfold Equation4290. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff366_inst, reff366_op in H. discriminate H. Qed.

Lemma reff366_not4291 : ~ @Equation4291 Fin4 reff366_inst.
Proof. unfold Equation4291. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff366_inst, reff366_op in H. discriminate H. Qed.

Lemma reff366_not4293 : ~ @Equation4293 Fin4 reff366_inst.
Proof. unfold Equation4293. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff366_inst, reff366_op in H. discriminate H. Qed.

Lemma reff366_not4314 : ~ @Equation4314 Fin4 reff366_inst.
Proof. unfold Equation4314. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff366_inst, reff366_op in H. discriminate H. Qed.

Lemma reff366_not4321 : ~ @Equation4321 Fin4 reff366_inst.
Proof. unfold Equation4321. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff366_inst, reff366_op in H. discriminate H. Qed.

Lemma reff366_not4343 : ~ @Equation4343 Fin4 reff366_inst.
Proof. unfold Equation4343. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff366_inst, reff366_op in H. discriminate H. Qed.

Lemma reff366_not4398 : ~ @Equation4398 Fin4 reff366_inst.
Proof. unfold Equation4398. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff366_inst, reff366_op in H. discriminate H. Qed.

Lemma reff366_not4405 : ~ @Equation4405 Fin4 reff366_inst.
Proof. unfold Equation4405. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff366_inst, reff366_op in H. discriminate H. Qed.

Lemma reff366_not4408 : ~ @Equation4408 Fin4 reff366_inst.
Proof. unfold Equation4408. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff366_inst, reff366_op in H. discriminate H. Qed.

Lemma reff366_not4433 : ~ @Equation4433 Fin4 reff366_inst.
Proof. unfold Equation4433. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff366_inst, reff366_op in H. discriminate H. Qed.

Lemma reff366_not4435 : ~ @Equation4435 Fin4 reff366_inst.
Proof. unfold Equation4435. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff366_inst, reff366_op in H. discriminate H. Qed.

Lemma reff366_not4436 : ~ @Equation4436 Fin4 reff366_inst.
Proof. unfold Equation4436. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff366_inst, reff366_op in H. discriminate H. Qed.

Lemma reff366_not4442 : ~ @Equation4442 Fin4 reff366_inst.
Proof. unfold Equation4442. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff366_inst, reff366_op in H. discriminate H. Qed.

Lemma reff366_not4443 : ~ @Equation4443 Fin4 reff366_inst.
Proof. unfold Equation4443. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff366_inst, reff366_op in H. discriminate H. Qed.

Lemma reff366_not4445 : ~ @Equation4445 Fin4 reff366_inst.
Proof. unfold Equation4445. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff366_inst, reff366_op in H. discriminate H. Qed.

Lemma reff366_not4470 : ~ @Equation4470 Fin4 reff366_inst.
Proof. unfold Equation4470. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff366_inst, reff366_op in H. discriminate H. Qed.

Lemma reff366_not4472 : ~ @Equation4472 Fin4 reff366_inst.
Proof. unfold Equation4472. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff366_inst, reff366_op in H. discriminate H. Qed.

Lemma reff366_not4473 : ~ @Equation4473 Fin4 reff366_inst.
Proof. unfold Equation4473. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff366_inst, reff366_op in H. discriminate H. Qed.

Lemma reff366_not4479 : ~ @Equation4479 Fin4 reff366_inst.
Proof. unfold Equation4479. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff366_inst, reff366_op in H. discriminate H. Qed.

Lemma reff366_not4480 : ~ @Equation4480 Fin4 reff366_inst.
Proof. unfold Equation4480. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff366_inst, reff366_op in H. discriminate H. Qed.

Lemma reff366_not4482 : ~ @Equation4482 Fin4 reff366_inst.
Proof. unfold Equation4482. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff366_inst, reff366_op in H. discriminate H. Qed.

Lemma reff366_not4583 : ~ @Equation4583 Fin4 reff366_inst.
Proof. unfold Equation4583. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff366_inst, reff366_op in H. discriminate H. Qed.

Lemma reff366_not4585 : ~ @Equation4585 Fin4 reff366_inst.
Proof. unfold Equation4585. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff366_inst, reff366_op in H. discriminate H. Qed.

Lemma reff366_not4588 : ~ @Equation4588 Fin4 reff366_inst.
Proof. unfold Equation4588. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff366_inst, reff366_op in H. discriminate H. Qed.

Lemma reff366_not4591 : ~ @Equation4591 Fin4 reff366_inst.
Proof. unfold Equation4591. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff366_inst, reff366_op in H. discriminate H. Qed.

Lemma reff366_not4598 : ~ @Equation4598 Fin4 reff366_inst.
Proof. unfold Equation4598. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff366_inst, reff366_op in H. discriminate H. Qed.

Lemma reff366_not4605 : ~ @Equation4605 Fin4 reff366_inst.
Proof. unfold Equation4605. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff366_inst, reff366_op in H. discriminate H. Qed.

Lemma reff366_not4608 : ~ @Equation4608 Fin4 reff366_inst.
Proof. unfold Equation4608. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff366_inst, reff366_op in H. discriminate H. Qed.

Lemma reff366_not4629 : ~ @Equation4629 Fin4 reff366_inst.
Proof. unfold Equation4629. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff366_inst, reff366_op in H. discriminate H. Qed.

Lemma reff366_not4636 : ~ @Equation4636 Fin4 reff366_inst.
Proof. unfold Equation4636. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff366_inst, reff366_op in H. discriminate H. Qed.

Lemma reff366_not4658 : ~ @Equation4658 Fin4 reff366_inst.
Proof. unfold Equation4658. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff366_inst, reff366_op in H. discriminate H. Qed.

(** ---- reff370 (Fin4) ---- *)

Definition reff370_op (x y : Fin4) : Fin4 :=
  match x, y with
  | F4_0, F4_0 => F4_0 | F4_0, F4_1 => F4_1 | F4_0, F4_2 => F4_2 | F4_0, F4_3 => F4_3
  | F4_1, F4_0 => F4_1 | F4_1, F4_1 => F4_2 | F4_1, F4_2 => F4_3 | F4_1, F4_3 => F4_0
  | F4_2, F4_0 => F4_0 | F4_2, F4_1 => F4_1 | F4_2, F4_2 => F4_2 | F4_2, F4_3 => F4_3
  | F4_3, F4_0 => F4_1 | F4_3, F4_1 => F4_2 | F4_3, F4_2 => F4_3 | F4_3, F4_3 => F4_0
  end.

#[local] Instance reff370_inst : Magma Fin4 := {| magma_op := reff370_op |}.

Lemma reff370_sat31 : @Equation31 Fin4 reff370_inst.
Proof. unfold Equation31, magma_op, reff370_inst, reff370_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff370_sat513 : @Equation513 Fin4 reff370_inst.
Proof. unfold Equation513, magma_op, reff370_inst, reff370_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff370_sat2355 : @Equation2355 Fin4 reff370_inst.
Proof. unfold Equation2355, magma_op, reff370_inst, reff370_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff370_sat2389 : @Equation2389 Fin4 reff370_inst.
Proof. unfold Equation2389, magma_op, reff370_inst, reff370_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff370_sat2402 : @Equation2402 Fin4 reff370_inst.
Proof. unfold Equation2402, magma_op, reff370_inst, reff370_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff370_sat2558 : @Equation2558 Fin4 reff370_inst.
Proof. unfold Equation2558, magma_op, reff370_inst, reff370_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff370_sat2592 : @Equation2592 Fin4 reff370_inst.
Proof. unfold Equation2592, magma_op, reff370_inst, reff370_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff370_sat2808 : @Equation2808 Fin4 reff370_inst.
Proof. unfold Equation2808, magma_op, reff370_inst, reff370_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff370_sat2964 : @Equation2964 Fin4 reff370_inst.
Proof. unfold Equation2964, magma_op, reff370_inst, reff370_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff370_sat2998 : @Equation2998 Fin4 reff370_inst.
Proof. unfold Equation2998, magma_op, reff370_inst, reff370_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff370_sat3011 : @Equation3011 Fin4 reff370_inst.
Proof. unfold Equation3011, magma_op, reff370_inst, reff370_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff370_sat3201 : @Equation3201 Fin4 reff370_inst.
Proof. unfold Equation3201, magma_op, reff370_inst, reff370_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff370_sat3214 : @Equation3214 Fin4 reff370_inst.
Proof. unfold Equation3214, magma_op, reff370_inst, reff370_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff370_sat3943 : @Equation3943 Fin4 reff370_inst.
Proof. unfold Equation3943, magma_op, reff370_inst, reff370_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff370_sat4023 : @Equation4023 Fin4 reff370_inst.
Proof. unfold Equation4023, magma_op, reff370_inst, reff370_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff370_sat4146 : @Equation4146 Fin4 reff370_inst.
Proof. unfold Equation4146, magma_op, reff370_inst, reff370_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff370_sat4200 : @Equation4200 Fin4 reff370_inst.
Proof. unfold Equation4200, magma_op, reff370_inst, reff370_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff370_sat4677 : @Equation4677 Fin4 reff370_inst.
Proof. unfold Equation4677, magma_op, reff370_inst, reff370_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff370_not47 : ~ @Equation47 Fin4 reff370_inst.
Proof. unfold Equation47. intro H. specialize (H F4_1). unfold magma_op, reff370_inst, reff370_op in H. discriminate H. Qed.

Lemma reff370_not99 : ~ @Equation99 Fin4 reff370_inst.
Proof. unfold Equation99. intro H. specialize (H F4_1). unfold magma_op, reff370_inst, reff370_op in H. discriminate H. Qed.

Lemma reff370_not151 : ~ @Equation151 Fin4 reff370_inst.
Proof. unfold Equation151. intro H. specialize (H F4_1). unfold magma_op, reff370_inst, reff370_op in H. discriminate H. Qed.

Lemma reff370_not203 : ~ @Equation203 Fin4 reff370_inst.
Proof. unfold Equation203. intro H. specialize (H F4_1). unfold magma_op, reff370_inst, reff370_op in H. discriminate H. Qed.

Lemma reff370_not255 : ~ @Equation255 Fin4 reff370_inst.
Proof. unfold Equation255. intro H. specialize (H F4_1). unfold magma_op, reff370_inst, reff370_op in H. discriminate H. Qed.

Lemma reff370_not359 : ~ @Equation359 Fin4 reff370_inst.
Proof. unfold Equation359. intro H. specialize (H F4_1). unfold magma_op, reff370_inst, reff370_op in H. discriminate H. Qed.

Lemma reff370_not412 : ~ @Equation412 Fin4 reff370_inst.
Proof. unfold Equation412. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff370_inst, reff370_op in H. discriminate H. Qed.

Lemma reff370_not413 : ~ @Equation413 Fin4 reff370_inst.
Proof. unfold Equation413. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff370_inst, reff370_op in H. discriminate H. Qed.

Lemma reff370_not414 : ~ @Equation414 Fin4 reff370_inst.
Proof. unfold Equation414. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff370_inst, reff370_op in H. discriminate H. Qed.

Lemma reff370_not416 : ~ @Equation416 Fin4 reff370_inst.
Proof. unfold Equation416. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff370_inst, reff370_op in H. discriminate H. Qed.

Lemma reff370_not417 : ~ @Equation417 Fin4 reff370_inst.
Proof. unfold Equation417. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff370_inst, reff370_op in H. discriminate H. Qed.

Lemma reff370_not419 : ~ @Equation419 Fin4 reff370_inst.
Proof. unfold Equation419. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff370_inst, reff370_op in H. discriminate H. Qed.

Lemma reff370_not420 : ~ @Equation420 Fin4 reff370_inst.
Proof. unfold Equation420. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff370_inst, reff370_op in H. discriminate H. Qed.

Lemma reff370_not426 : ~ @Equation426 Fin4 reff370_inst.
Proof. unfold Equation426. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff370_inst, reff370_op in H. discriminate H. Qed.

Lemma reff370_not427 : ~ @Equation427 Fin4 reff370_inst.
Proof. unfold Equation427. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff370_inst, reff370_op in H. discriminate H. Qed.

Lemma reff370_not429 : ~ @Equation429 Fin4 reff370_inst.
Proof. unfold Equation429. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff370_inst, reff370_op in H. discriminate H. Qed.

Lemma reff370_not430 : ~ @Equation430 Fin4 reff370_inst.
Proof. unfold Equation430. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff370_inst, reff370_op in H. discriminate H. Qed.

Lemma reff370_not436 : ~ @Equation436 Fin4 reff370_inst.
Proof. unfold Equation436. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff370_inst, reff370_op in H. discriminate H. Qed.

Lemma reff370_not437 : ~ @Equation437 Fin4 reff370_inst.
Proof. unfold Equation437. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff370_inst, reff370_op in H. discriminate H. Qed.

Lemma reff370_not439 : ~ @Equation439 Fin4 reff370_inst.
Proof. unfold Equation439. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff370_inst, reff370_op in H. discriminate H. Qed.

Lemma reff370_not440 : ~ @Equation440 Fin4 reff370_inst.
Proof. unfold Equation440. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff370_inst, reff370_op in H. discriminate H. Qed.

Lemma reff370_not463 : ~ @Equation463 Fin4 reff370_inst.
Proof. unfold Equation463. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff370_inst, reff370_op in H. discriminate H. Qed.

Lemma reff370_not464 : ~ @Equation464 Fin4 reff370_inst.
Proof. unfold Equation464. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff370_inst, reff370_op in H. discriminate H. Qed.

Lemma reff370_not466 : ~ @Equation466 Fin4 reff370_inst.
Proof. unfold Equation466. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff370_inst, reff370_op in H. discriminate H. Qed.

Lemma reff370_not467 : ~ @Equation467 Fin4 reff370_inst.
Proof. unfold Equation467. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff370_inst, reff370_op in H. discriminate H. Qed.

Lemma reff370_not473 : ~ @Equation473 Fin4 reff370_inst.
Proof. unfold Equation473. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff370_inst, reff370_op in H. discriminate H. Qed.

Lemma reff370_not474 : ~ @Equation474 Fin4 reff370_inst.
Proof. unfold Equation474. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff370_inst, reff370_op in H. discriminate H. Qed.

Lemma reff370_not476 : ~ @Equation476 Fin4 reff370_inst.
Proof. unfold Equation476. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff370_inst, reff370_op in H. discriminate H. Qed.

Lemma reff370_not477 : ~ @Equation477 Fin4 reff370_inst.
Proof. unfold Equation477. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff370_inst, reff370_op in H. discriminate H. Qed.

Lemma reff370_not500 : ~ @Equation500 Fin4 reff370_inst.
Proof. unfold Equation500. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff370_inst, reff370_op in H. discriminate H. Qed.

Lemma reff370_not501 : ~ @Equation501 Fin4 reff370_inst.
Proof. unfold Equation501. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff370_inst, reff370_op in H. discriminate H. Qed.

Lemma reff370_not503 : ~ @Equation503 Fin4 reff370_inst.
Proof. unfold Equation503. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff370_inst, reff370_op in H. discriminate H. Qed.

Lemma reff370_not504 : ~ @Equation504 Fin4 reff370_inst.
Proof. unfold Equation504. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff370_inst, reff370_op in H. discriminate H. Qed.

Lemma reff370_not510 : ~ @Equation510 Fin4 reff370_inst.
Proof. unfold Equation510. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff370_inst, reff370_op in H. discriminate H. Qed.

Lemma reff370_not511 : ~ @Equation511 Fin4 reff370_inst.
Proof. unfold Equation511. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff370_inst, reff370_op in H. discriminate H. Qed.

Lemma reff370_not614 : ~ @Equation614 Fin4 reff370_inst.
Proof. unfold Equation614. intro H. specialize (H F4_1). unfold magma_op, reff370_inst, reff370_op in H. discriminate H. Qed.

Lemma reff370_not817 : ~ @Equation817 Fin4 reff370_inst.
Proof. unfold Equation817. intro H. specialize (H F4_1). unfold magma_op, reff370_inst, reff370_op in H. discriminate H. Qed.

Lemma reff370_not1020 : ~ @Equation1020 Fin4 reff370_inst.
Proof. unfold Equation1020. intro H. specialize (H F4_1). unfold magma_op, reff370_inst, reff370_op in H. discriminate H. Qed.

Lemma reff370_not1223 : ~ @Equation1223 Fin4 reff370_inst.
Proof. unfold Equation1223. intro H. specialize (H F4_1). unfold magma_op, reff370_inst, reff370_op in H. discriminate H. Qed.

Lemma reff370_not1426 : ~ @Equation1426 Fin4 reff370_inst.
Proof. unfold Equation1426. intro H. specialize (H F4_1). unfold magma_op, reff370_inst, reff370_op in H. discriminate H. Qed.

Lemma reff370_not1630 : ~ @Equation1630 Fin4 reff370_inst.
Proof. unfold Equation1630. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff370_inst, reff370_op in H. discriminate H. Qed.

Lemma reff370_not1631 : ~ @Equation1631 Fin4 reff370_inst.
Proof. unfold Equation1631. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff370_inst, reff370_op in H. discriminate H. Qed.

Lemma reff370_not1632 : ~ @Equation1632 Fin4 reff370_inst.
Proof. unfold Equation1632. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff370_inst, reff370_op in H. discriminate H. Qed.

Lemma reff370_not1634 : ~ @Equation1634 Fin4 reff370_inst.
Proof. unfold Equation1634. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff370_inst, reff370_op in H. discriminate H. Qed.

Lemma reff370_not1635 : ~ @Equation1635 Fin4 reff370_inst.
Proof. unfold Equation1635. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff370_inst, reff370_op in H. discriminate H. Qed.

Lemma reff370_not1638 : ~ @Equation1638 Fin4 reff370_inst.
Proof. unfold Equation1638. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff370_inst, reff370_op in H. discriminate H. Qed.

Lemma reff370_not1644 : ~ @Equation1644 Fin4 reff370_inst.
Proof. unfold Equation1644. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff370_inst, reff370_op in H. discriminate H. Qed.

Lemma reff370_not1645 : ~ @Equation1645 Fin4 reff370_inst.
Proof. unfold Equation1645. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff370_inst, reff370_op in H. discriminate H. Qed.

Lemma reff370_not1647 : ~ @Equation1647 Fin4 reff370_inst.
Proof. unfold Equation1647. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff370_inst, reff370_op in H. discriminate H. Qed.

Lemma reff370_not1648 : ~ @Equation1648 Fin4 reff370_inst.
Proof. unfold Equation1648. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff370_inst, reff370_op in H. discriminate H. Qed.

Lemma reff370_not1654 : ~ @Equation1654 Fin4 reff370_inst.
Proof. unfold Equation1654. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff370_inst, reff370_op in H. discriminate H. Qed.

Lemma reff370_not1655 : ~ @Equation1655 Fin4 reff370_inst.
Proof. unfold Equation1655. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff370_inst, reff370_op in H. discriminate H. Qed.

Lemma reff370_not1657 : ~ @Equation1657 Fin4 reff370_inst.
Proof. unfold Equation1657. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff370_inst, reff370_op in H. discriminate H. Qed.

Lemma reff370_not1658 : ~ @Equation1658 Fin4 reff370_inst.
Proof. unfold Equation1658. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff370_inst, reff370_op in H. discriminate H. Qed.

Lemma reff370_not1681 : ~ @Equation1681 Fin4 reff370_inst.
Proof. unfold Equation1681. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff370_inst, reff370_op in H. discriminate H. Qed.

Lemma reff370_not1682 : ~ @Equation1682 Fin4 reff370_inst.
Proof. unfold Equation1682. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff370_inst, reff370_op in H. discriminate H. Qed.

Lemma reff370_not1684 : ~ @Equation1684 Fin4 reff370_inst.
Proof. unfold Equation1684. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff370_inst, reff370_op in H. discriminate H. Qed.

Lemma reff370_not1685 : ~ @Equation1685 Fin4 reff370_inst.
Proof. unfold Equation1685. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff370_inst, reff370_op in H. discriminate H. Qed.

Lemma reff370_not1691 : ~ @Equation1691 Fin4 reff370_inst.
Proof. unfold Equation1691. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff370_inst, reff370_op in H. discriminate H. Qed.

Lemma reff370_not1692 : ~ @Equation1692 Fin4 reff370_inst.
Proof. unfold Equation1692. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff370_inst, reff370_op in H. discriminate H. Qed.

Lemma reff370_not1694 : ~ @Equation1694 Fin4 reff370_inst.
Proof. unfold Equation1694. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff370_inst, reff370_op in H. discriminate H. Qed.

Lemma reff370_not1695 : ~ @Equation1695 Fin4 reff370_inst.
Proof. unfold Equation1695. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff370_inst, reff370_op in H. discriminate H. Qed.

Lemma reff370_not1719 : ~ @Equation1719 Fin4 reff370_inst.
Proof. unfold Equation1719. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff370_inst, reff370_op in H. discriminate H. Qed.

Lemma reff370_not1721 : ~ @Equation1721 Fin4 reff370_inst.
Proof. unfold Equation1721. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff370_inst, reff370_op in H. discriminate H. Qed.

Lemma reff370_not1722 : ~ @Equation1722 Fin4 reff370_inst.
Proof. unfold Equation1722. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff370_inst, reff370_op in H. discriminate H. Qed.

Lemma reff370_not1728 : ~ @Equation1728 Fin4 reff370_inst.
Proof. unfold Equation1728. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff370_inst, reff370_op in H. discriminate H. Qed.

Lemma reff370_not1729 : ~ @Equation1729 Fin4 reff370_inst.
Proof. unfold Equation1729. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff370_inst, reff370_op in H. discriminate H. Qed.

Lemma reff370_not1832 : ~ @Equation1832 Fin4 reff370_inst.
Proof. unfold Equation1832. intro H. specialize (H F4_1). unfold magma_op, reff370_inst, reff370_op in H. discriminate H. Qed.

Lemma reff370_not2035 : ~ @Equation2035 Fin4 reff370_inst.
Proof. unfold Equation2035. intro H. specialize (H F4_1). unfold magma_op, reff370_inst, reff370_op in H. discriminate H. Qed.

Lemma reff370_not2239 : ~ @Equation2239 Fin4 reff370_inst.
Proof. unfold Equation2239. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff370_inst, reff370_op in H. discriminate H. Qed.

Lemma reff370_not2240 : ~ @Equation2240 Fin4 reff370_inst.
Proof. unfold Equation2240. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff370_inst, reff370_op in H. discriminate H. Qed.

Lemma reff370_not2241 : ~ @Equation2241 Fin4 reff370_inst.
Proof. unfold Equation2241. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff370_inst, reff370_op in H. discriminate H. Qed.

Lemma reff370_not2243 : ~ @Equation2243 Fin4 reff370_inst.
Proof. unfold Equation2243. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff370_inst, reff370_op in H. discriminate H. Qed.

Lemma reff370_not2244 : ~ @Equation2244 Fin4 reff370_inst.
Proof. unfold Equation2244. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff370_inst, reff370_op in H. discriminate H. Qed.

Lemma reff370_not2247 : ~ @Equation2247 Fin4 reff370_inst.
Proof. unfold Equation2247. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff370_inst, reff370_op in H. discriminate H. Qed.

Lemma reff370_not2253 : ~ @Equation2253 Fin4 reff370_inst.
Proof. unfold Equation2253. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff370_inst, reff370_op in H. discriminate H. Qed.

Lemma reff370_not2254 : ~ @Equation2254 Fin4 reff370_inst.
Proof. unfold Equation2254. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff370_inst, reff370_op in H. discriminate H. Qed.

Lemma reff370_not2257 : ~ @Equation2257 Fin4 reff370_inst.
Proof. unfold Equation2257. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff370_inst, reff370_op in H. discriminate H. Qed.

Lemma reff370_not2264 : ~ @Equation2264 Fin4 reff370_inst.
Proof. unfold Equation2264. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff370_inst, reff370_op in H. discriminate H. Qed.

Lemma reff370_not2266 : ~ @Equation2266 Fin4 reff370_inst.
Proof. unfold Equation2266. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff370_inst, reff370_op in H. discriminate H. Qed.

Lemma reff370_not2267 : ~ @Equation2267 Fin4 reff370_inst.
Proof. unfold Equation2267. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff370_inst, reff370_op in H. discriminate H. Qed.

Lemma reff370_not2290 : ~ @Equation2290 Fin4 reff370_inst.
Proof. unfold Equation2290. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff370_inst, reff370_op in H. discriminate H. Qed.

Lemma reff370_not2291 : ~ @Equation2291 Fin4 reff370_inst.
Proof. unfold Equation2291. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff370_inst, reff370_op in H. discriminate H. Qed.

Lemma reff370_not2294 : ~ @Equation2294 Fin4 reff370_inst.
Proof. unfold Equation2294. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff370_inst, reff370_op in H. discriminate H. Qed.

Lemma reff370_not2301 : ~ @Equation2301 Fin4 reff370_inst.
Proof. unfold Equation2301. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff370_inst, reff370_op in H. discriminate H. Qed.

Lemma reff370_not2303 : ~ @Equation2303 Fin4 reff370_inst.
Proof. unfold Equation2303. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff370_inst, reff370_op in H. discriminate H. Qed.

Lemma reff370_not2304 : ~ @Equation2304 Fin4 reff370_inst.
Proof. unfold Equation2304. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff370_inst, reff370_op in H. discriminate H. Qed.

Lemma reff370_not2328 : ~ @Equation2328 Fin4 reff370_inst.
Proof. unfold Equation2328. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff370_inst, reff370_op in H. discriminate H. Qed.

Lemma reff370_not2330 : ~ @Equation2330 Fin4 reff370_inst.
Proof. unfold Equation2330. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff370_inst, reff370_op in H. discriminate H. Qed.

Lemma reff370_not2331 : ~ @Equation2331 Fin4 reff370_inst.
Proof. unfold Equation2331. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff370_inst, reff370_op in H. discriminate H. Qed.

Lemma reff370_not2337 : ~ @Equation2337 Fin4 reff370_inst.
Proof. unfold Equation2337. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff370_inst, reff370_op in H. discriminate H. Qed.

Lemma reff370_not2338 : ~ @Equation2338 Fin4 reff370_inst.
Proof. unfold Equation2338. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff370_inst, reff370_op in H. discriminate H. Qed.

Lemma reff370_not2442 : ~ @Equation2442 Fin4 reff370_inst.
Proof. unfold Equation2442. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff370_inst, reff370_op in H. discriminate H. Qed.

Lemma reff370_not2443 : ~ @Equation2443 Fin4 reff370_inst.
Proof. unfold Equation2443. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff370_inst, reff370_op in H. discriminate H. Qed.

Lemma reff370_not2444 : ~ @Equation2444 Fin4 reff370_inst.
Proof. unfold Equation2444. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff370_inst, reff370_op in H. discriminate H. Qed.

Lemma reff370_not2446 : ~ @Equation2446 Fin4 reff370_inst.
Proof. unfold Equation2446. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff370_inst, reff370_op in H. discriminate H. Qed.

Lemma reff370_not2447 : ~ @Equation2447 Fin4 reff370_inst.
Proof. unfold Equation2447. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff370_inst, reff370_op in H. discriminate H. Qed.

Lemma reff370_not2450 : ~ @Equation2450 Fin4 reff370_inst.
Proof. unfold Equation2450. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff370_inst, reff370_op in H. discriminate H. Qed.

Lemma reff370_not2456 : ~ @Equation2456 Fin4 reff370_inst.
Proof. unfold Equation2456. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff370_inst, reff370_op in H. discriminate H. Qed.

Lemma reff370_not2457 : ~ @Equation2457 Fin4 reff370_inst.
Proof. unfold Equation2457. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff370_inst, reff370_op in H. discriminate H. Qed.

Lemma reff370_not2460 : ~ @Equation2460 Fin4 reff370_inst.
Proof. unfold Equation2460. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff370_inst, reff370_op in H. discriminate H. Qed.

Lemma reff370_not2467 : ~ @Equation2467 Fin4 reff370_inst.
Proof. unfold Equation2467. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff370_inst, reff370_op in H. discriminate H. Qed.

Lemma reff370_not2469 : ~ @Equation2469 Fin4 reff370_inst.
Proof. unfold Equation2469. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff370_inst, reff370_op in H. discriminate H. Qed.

Lemma reff370_not2470 : ~ @Equation2470 Fin4 reff370_inst.
Proof. unfold Equation2470. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff370_inst, reff370_op in H. discriminate H. Qed.

Lemma reff370_not2493 : ~ @Equation2493 Fin4 reff370_inst.
Proof. unfold Equation2493. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff370_inst, reff370_op in H. discriminate H. Qed.

Lemma reff370_not2494 : ~ @Equation2494 Fin4 reff370_inst.
Proof. unfold Equation2494. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff370_inst, reff370_op in H. discriminate H. Qed.

Lemma reff370_not2497 : ~ @Equation2497 Fin4 reff370_inst.
Proof. unfold Equation2497. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff370_inst, reff370_op in H. discriminate H. Qed.

Lemma reff370_not2504 : ~ @Equation2504 Fin4 reff370_inst.
Proof. unfold Equation2504. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff370_inst, reff370_op in H. discriminate H. Qed.

Lemma reff370_not2506 : ~ @Equation2506 Fin4 reff370_inst.
Proof. unfold Equation2506. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff370_inst, reff370_op in H. discriminate H. Qed.

Lemma reff370_not2507 : ~ @Equation2507 Fin4 reff370_inst.
Proof. unfold Equation2507. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff370_inst, reff370_op in H. discriminate H. Qed.

Lemma reff370_not2531 : ~ @Equation2531 Fin4 reff370_inst.
Proof. unfold Equation2531. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff370_inst, reff370_op in H. discriminate H. Qed.

Lemma reff370_not2533 : ~ @Equation2533 Fin4 reff370_inst.
Proof. unfold Equation2533. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff370_inst, reff370_op in H. discriminate H. Qed.

Lemma reff370_not2534 : ~ @Equation2534 Fin4 reff370_inst.
Proof. unfold Equation2534. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff370_inst, reff370_op in H. discriminate H. Qed.

Lemma reff370_not2540 : ~ @Equation2540 Fin4 reff370_inst.
Proof. unfold Equation2540. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff370_inst, reff370_op in H. discriminate H. Qed.

Lemma reff370_not2541 : ~ @Equation2541 Fin4 reff370_inst.
Proof. unfold Equation2541. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff370_inst, reff370_op in H. discriminate H. Qed.

Lemma reff370_not2645 : ~ @Equation2645 Fin4 reff370_inst.
Proof. unfold Equation2645. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff370_inst, reff370_op in H. discriminate H. Qed.

Lemma reff370_not2646 : ~ @Equation2646 Fin4 reff370_inst.
Proof. unfold Equation2646. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff370_inst, reff370_op in H. discriminate H. Qed.

Lemma reff370_not2647 : ~ @Equation2647 Fin4 reff370_inst.
Proof. unfold Equation2647. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff370_inst, reff370_op in H. discriminate H. Qed.

Lemma reff370_not2649 : ~ @Equation2649 Fin4 reff370_inst.
Proof. unfold Equation2649. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff370_inst, reff370_op in H. discriminate H. Qed.

Lemma reff370_not2650 : ~ @Equation2650 Fin4 reff370_inst.
Proof. unfold Equation2650. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff370_inst, reff370_op in H. discriminate H. Qed.

Lemma reff370_not2653 : ~ @Equation2653 Fin4 reff370_inst.
Proof. unfold Equation2653. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff370_inst, reff370_op in H. discriminate H. Qed.

Lemma reff370_not2659 : ~ @Equation2659 Fin4 reff370_inst.
Proof. unfold Equation2659. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff370_inst, reff370_op in H. discriminate H. Qed.

Lemma reff370_not2660 : ~ @Equation2660 Fin4 reff370_inst.
Proof. unfold Equation2660. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff370_inst, reff370_op in H. discriminate H. Qed.

Lemma reff370_not2663 : ~ @Equation2663 Fin4 reff370_inst.
Proof. unfold Equation2663. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff370_inst, reff370_op in H. discriminate H. Qed.

Lemma reff370_not2670 : ~ @Equation2670 Fin4 reff370_inst.
Proof. unfold Equation2670. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff370_inst, reff370_op in H. discriminate H. Qed.

Lemma reff370_not2672 : ~ @Equation2672 Fin4 reff370_inst.
Proof. unfold Equation2672. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff370_inst, reff370_op in H. discriminate H. Qed.

Lemma reff370_not2673 : ~ @Equation2673 Fin4 reff370_inst.
Proof. unfold Equation2673. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff370_inst, reff370_op in H. discriminate H. Qed.

Lemma reff370_not2696 : ~ @Equation2696 Fin4 reff370_inst.
Proof. unfold Equation2696. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff370_inst, reff370_op in H. discriminate H. Qed.

Lemma reff370_not2697 : ~ @Equation2697 Fin4 reff370_inst.
Proof. unfold Equation2697. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff370_inst, reff370_op in H. discriminate H. Qed.

Lemma reff370_not2700 : ~ @Equation2700 Fin4 reff370_inst.
Proof. unfold Equation2700. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff370_inst, reff370_op in H. discriminate H. Qed.

Lemma reff370_not2707 : ~ @Equation2707 Fin4 reff370_inst.
Proof. unfold Equation2707. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff370_inst, reff370_op in H. discriminate H. Qed.

Lemma reff370_not2709 : ~ @Equation2709 Fin4 reff370_inst.
Proof. unfold Equation2709. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff370_inst, reff370_op in H. discriminate H. Qed.

Lemma reff370_not2710 : ~ @Equation2710 Fin4 reff370_inst.
Proof. unfold Equation2710. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff370_inst, reff370_op in H. discriminate H. Qed.

Lemma reff370_not2734 : ~ @Equation2734 Fin4 reff370_inst.
Proof. unfold Equation2734. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff370_inst, reff370_op in H. discriminate H. Qed.

Lemma reff370_not2736 : ~ @Equation2736 Fin4 reff370_inst.
Proof. unfold Equation2736. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff370_inst, reff370_op in H. discriminate H. Qed.

Lemma reff370_not2737 : ~ @Equation2737 Fin4 reff370_inst.
Proof. unfold Equation2737. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff370_inst, reff370_op in H. discriminate H. Qed.

Lemma reff370_not2743 : ~ @Equation2743 Fin4 reff370_inst.
Proof. unfold Equation2743. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff370_inst, reff370_op in H. discriminate H. Qed.

Lemma reff370_not2744 : ~ @Equation2744 Fin4 reff370_inst.
Proof. unfold Equation2744. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff370_inst, reff370_op in H. discriminate H. Qed.

Lemma reff370_not2848 : ~ @Equation2848 Fin4 reff370_inst.
Proof. unfold Equation2848. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff370_inst, reff370_op in H. discriminate H. Qed.

Lemma reff370_not2849 : ~ @Equation2849 Fin4 reff370_inst.
Proof. unfold Equation2849. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff370_inst, reff370_op in H. discriminate H. Qed.

Lemma reff370_not2850 : ~ @Equation2850 Fin4 reff370_inst.
Proof. unfold Equation2850. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff370_inst, reff370_op in H. discriminate H. Qed.

Lemma reff370_not2852 : ~ @Equation2852 Fin4 reff370_inst.
Proof. unfold Equation2852. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff370_inst, reff370_op in H. discriminate H. Qed.

Lemma reff370_not2853 : ~ @Equation2853 Fin4 reff370_inst.
Proof. unfold Equation2853. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff370_inst, reff370_op in H. discriminate H. Qed.

Lemma reff370_not2856 : ~ @Equation2856 Fin4 reff370_inst.
Proof. unfold Equation2856. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff370_inst, reff370_op in H. discriminate H. Qed.

Lemma reff370_not2862 : ~ @Equation2862 Fin4 reff370_inst.
Proof. unfold Equation2862. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff370_inst, reff370_op in H. discriminate H. Qed.

Lemma reff370_not2863 : ~ @Equation2863 Fin4 reff370_inst.
Proof. unfold Equation2863. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff370_inst, reff370_op in H. discriminate H. Qed.

Lemma reff370_not2866 : ~ @Equation2866 Fin4 reff370_inst.
Proof. unfold Equation2866. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff370_inst, reff370_op in H. discriminate H. Qed.

Lemma reff370_not2873 : ~ @Equation2873 Fin4 reff370_inst.
Proof. unfold Equation2873. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff370_inst, reff370_op in H. discriminate H. Qed.

Lemma reff370_not2875 : ~ @Equation2875 Fin4 reff370_inst.
Proof. unfold Equation2875. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff370_inst, reff370_op in H. discriminate H. Qed.

Lemma reff370_not2876 : ~ @Equation2876 Fin4 reff370_inst.
Proof. unfold Equation2876. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff370_inst, reff370_op in H. discriminate H. Qed.

Lemma reff370_not2899 : ~ @Equation2899 Fin4 reff370_inst.
Proof. unfold Equation2899. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff370_inst, reff370_op in H. discriminate H. Qed.

Lemma reff370_not2900 : ~ @Equation2900 Fin4 reff370_inst.
Proof. unfold Equation2900. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff370_inst, reff370_op in H. discriminate H. Qed.

Lemma reff370_not2903 : ~ @Equation2903 Fin4 reff370_inst.
Proof. unfold Equation2903. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff370_inst, reff370_op in H. discriminate H. Qed.

Lemma reff370_not2910 : ~ @Equation2910 Fin4 reff370_inst.
Proof. unfold Equation2910. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff370_inst, reff370_op in H. discriminate H. Qed.

Lemma reff370_not2912 : ~ @Equation2912 Fin4 reff370_inst.
Proof. unfold Equation2912. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff370_inst, reff370_op in H. discriminate H. Qed.

Lemma reff370_not2913 : ~ @Equation2913 Fin4 reff370_inst.
Proof. unfold Equation2913. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff370_inst, reff370_op in H. discriminate H. Qed.

Lemma reff370_not2937 : ~ @Equation2937 Fin4 reff370_inst.
Proof. unfold Equation2937. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff370_inst, reff370_op in H. discriminate H. Qed.

Lemma reff370_not2939 : ~ @Equation2939 Fin4 reff370_inst.
Proof. unfold Equation2939. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff370_inst, reff370_op in H. discriminate H. Qed.

Lemma reff370_not2940 : ~ @Equation2940 Fin4 reff370_inst.
Proof. unfold Equation2940. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff370_inst, reff370_op in H. discriminate H. Qed.

Lemma reff370_not2946 : ~ @Equation2946 Fin4 reff370_inst.
Proof. unfold Equation2946. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff370_inst, reff370_op in H. discriminate H. Qed.

Lemma reff370_not2947 : ~ @Equation2947 Fin4 reff370_inst.
Proof. unfold Equation2947. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff370_inst, reff370_op in H. discriminate H. Qed.

Lemma reff370_not3051 : ~ @Equation3051 Fin4 reff370_inst.
Proof. unfold Equation3051. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff370_inst, reff370_op in H. discriminate H. Qed.

Lemma reff370_not3052 : ~ @Equation3052 Fin4 reff370_inst.
Proof. unfold Equation3052. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff370_inst, reff370_op in H. discriminate H. Qed.

Lemma reff370_not3053 : ~ @Equation3053 Fin4 reff370_inst.
Proof. unfold Equation3053. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff370_inst, reff370_op in H. discriminate H. Qed.

Lemma reff370_not3055 : ~ @Equation3055 Fin4 reff370_inst.
Proof. unfold Equation3055. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff370_inst, reff370_op in H. discriminate H. Qed.

Lemma reff370_not3056 : ~ @Equation3056 Fin4 reff370_inst.
Proof. unfold Equation3056. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff370_inst, reff370_op in H. discriminate H. Qed.

Lemma reff370_not3059 : ~ @Equation3059 Fin4 reff370_inst.
Proof. unfold Equation3059. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff370_inst, reff370_op in H. discriminate H. Qed.

Lemma reff370_not3065 : ~ @Equation3065 Fin4 reff370_inst.
Proof. unfold Equation3065. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff370_inst, reff370_op in H. discriminate H. Qed.

Lemma reff370_not3066 : ~ @Equation3066 Fin4 reff370_inst.
Proof. unfold Equation3066. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff370_inst, reff370_op in H. discriminate H. Qed.

Lemma reff370_not3069 : ~ @Equation3069 Fin4 reff370_inst.
Proof. unfold Equation3069. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff370_inst, reff370_op in H. discriminate H. Qed.

Lemma reff370_not3076 : ~ @Equation3076 Fin4 reff370_inst.
Proof. unfold Equation3076. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff370_inst, reff370_op in H. discriminate H. Qed.

Lemma reff370_not3078 : ~ @Equation3078 Fin4 reff370_inst.
Proof. unfold Equation3078. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff370_inst, reff370_op in H. discriminate H. Qed.

Lemma reff370_not3079 : ~ @Equation3079 Fin4 reff370_inst.
Proof. unfold Equation3079. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff370_inst, reff370_op in H. discriminate H. Qed.

Lemma reff370_not3102 : ~ @Equation3102 Fin4 reff370_inst.
Proof. unfold Equation3102. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff370_inst, reff370_op in H. discriminate H. Qed.

Lemma reff370_not3103 : ~ @Equation3103 Fin4 reff370_inst.
Proof. unfold Equation3103. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff370_inst, reff370_op in H. discriminate H. Qed.

Lemma reff370_not3106 : ~ @Equation3106 Fin4 reff370_inst.
Proof. unfold Equation3106. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff370_inst, reff370_op in H. discriminate H. Qed.

Lemma reff370_not3113 : ~ @Equation3113 Fin4 reff370_inst.
Proof. unfold Equation3113. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff370_inst, reff370_op in H. discriminate H. Qed.

Lemma reff370_not3115 : ~ @Equation3115 Fin4 reff370_inst.
Proof. unfold Equation3115. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff370_inst, reff370_op in H. discriminate H. Qed.

Lemma reff370_not3116 : ~ @Equation3116 Fin4 reff370_inst.
Proof. unfold Equation3116. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff370_inst, reff370_op in H. discriminate H. Qed.

Lemma reff370_not3140 : ~ @Equation3140 Fin4 reff370_inst.
Proof. unfold Equation3140. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff370_inst, reff370_op in H. discriminate H. Qed.

Lemma reff370_not3142 : ~ @Equation3142 Fin4 reff370_inst.
Proof. unfold Equation3142. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff370_inst, reff370_op in H. discriminate H. Qed.

Lemma reff370_not3143 : ~ @Equation3143 Fin4 reff370_inst.
Proof. unfold Equation3143. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff370_inst, reff370_op in H. discriminate H. Qed.

Lemma reff370_not3149 : ~ @Equation3149 Fin4 reff370_inst.
Proof. unfold Equation3149. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff370_inst, reff370_op in H. discriminate H. Qed.

Lemma reff370_not3150 : ~ @Equation3150 Fin4 reff370_inst.
Proof. unfold Equation3150. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff370_inst, reff370_op in H. discriminate H. Qed.

Lemma reff370_not3253 : ~ @Equation3253 Fin4 reff370_inst.
Proof. unfold Equation3253. intro H. specialize (H F4_1). unfold magma_op, reff370_inst, reff370_op in H. discriminate H. Qed.

Lemma reff370_not3457 : ~ @Equation3457 Fin4 reff370_inst.
Proof. unfold Equation3457. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff370_inst, reff370_op in H. discriminate H. Qed.

Lemma reff370_not3458 : ~ @Equation3458 Fin4 reff370_inst.
Proof. unfold Equation3458. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff370_inst, reff370_op in H. discriminate H. Qed.

Lemma reff370_not3459 : ~ @Equation3459 Fin4 reff370_inst.
Proof. unfold Equation3459. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff370_inst, reff370_op in H. discriminate H. Qed.

Lemma reff370_not3461 : ~ @Equation3461 Fin4 reff370_inst.
Proof. unfold Equation3461. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff370_inst, reff370_op in H. discriminate H. Qed.

Lemma reff370_not3462 : ~ @Equation3462 Fin4 reff370_inst.
Proof. unfold Equation3462. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff370_inst, reff370_op in H. discriminate H. Qed.

Lemma reff370_not3465 : ~ @Equation3465 Fin4 reff370_inst.
Proof. unfold Equation3465. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff370_inst, reff370_op in H. discriminate H. Qed.

Lemma reff370_not3472 : ~ @Equation3472 Fin4 reff370_inst.
Proof. unfold Equation3472. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff370_inst, reff370_op in H. discriminate H. Qed.

Lemma reff370_not3474 : ~ @Equation3474 Fin4 reff370_inst.
Proof. unfold Equation3474. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff370_inst, reff370_op in H. discriminate H. Qed.

Lemma reff370_not3475 : ~ @Equation3475 Fin4 reff370_inst.
Proof. unfold Equation3475. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff370_inst, reff370_op in H. discriminate H. Qed.

Lemma reff370_not3481 : ~ @Equation3481 Fin4 reff370_inst.
Proof. unfold Equation3481. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff370_inst, reff370_op in H. discriminate H. Qed.

Lemma reff370_not3482 : ~ @Equation3482 Fin4 reff370_inst.
Proof. unfold Equation3482. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff370_inst, reff370_op in H. discriminate H. Qed.

Lemma reff370_not3484 : ~ @Equation3484 Fin4 reff370_inst.
Proof. unfold Equation3484. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff370_inst, reff370_op in H. discriminate H. Qed.

Lemma reff370_not3511 : ~ @Equation3511 Fin4 reff370_inst.
Proof. unfold Equation3511. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff370_inst, reff370_op in H. discriminate H. Qed.

Lemma reff370_not3512 : ~ @Equation3512 Fin4 reff370_inst.
Proof. unfold Equation3512. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff370_inst, reff370_op in H. discriminate H. Qed.

Lemma reff370_not3518 : ~ @Equation3518 Fin4 reff370_inst.
Proof. unfold Equation3518. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff370_inst, reff370_op in H. discriminate H. Qed.

Lemma reff370_not3519 : ~ @Equation3519 Fin4 reff370_inst.
Proof. unfold Equation3519. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff370_inst, reff370_op in H. discriminate H. Qed.

Lemma reff370_not3521 : ~ @Equation3521 Fin4 reff370_inst.
Proof. unfold Equation3521. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff370_inst, reff370_op in H. discriminate H. Qed.

Lemma reff370_not3545 : ~ @Equation3545 Fin4 reff370_inst.
Proof. unfold Equation3545. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff370_inst, reff370_op in H. discriminate H. Qed.

Lemma reff370_not3546 : ~ @Equation3546 Fin4 reff370_inst.
Proof. unfold Equation3546. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff370_inst, reff370_op in H. discriminate H. Qed.

Lemma reff370_not3548 : ~ @Equation3548 Fin4 reff370_inst.
Proof. unfold Equation3548. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff370_inst, reff370_op in H. discriminate H. Qed.

Lemma reff370_not3549 : ~ @Equation3549 Fin4 reff370_inst.
Proof. unfold Equation3549. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff370_inst, reff370_op in H. discriminate H. Qed.

Lemma reff370_not3555 : ~ @Equation3555 Fin4 reff370_inst.
Proof. unfold Equation3555. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff370_inst, reff370_op in H. discriminate H. Qed.

Lemma reff370_not3556 : ~ @Equation3556 Fin4 reff370_inst.
Proof. unfold Equation3556. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff370_inst, reff370_op in H. discriminate H. Qed.

Lemma reff370_not3558 : ~ @Equation3558 Fin4 reff370_inst.
Proof. unfold Equation3558. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff370_inst, reff370_op in H. discriminate H. Qed.

Lemma reff370_not3660 : ~ @Equation3660 Fin4 reff370_inst.
Proof. unfold Equation3660. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff370_inst, reff370_op in H. discriminate H. Qed.

Lemma reff370_not3661 : ~ @Equation3661 Fin4 reff370_inst.
Proof. unfold Equation3661. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff370_inst, reff370_op in H. discriminate H. Qed.

Lemma reff370_not3662 : ~ @Equation3662 Fin4 reff370_inst.
Proof. unfold Equation3662. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff370_inst, reff370_op in H. discriminate H. Qed.

Lemma reff370_not3664 : ~ @Equation3664 Fin4 reff370_inst.
Proof. unfold Equation3664. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff370_inst, reff370_op in H. discriminate H. Qed.

Lemma reff370_not3665 : ~ @Equation3665 Fin4 reff370_inst.
Proof. unfold Equation3665. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff370_inst, reff370_op in H. discriminate H. Qed.

Lemma reff370_not3667 : ~ @Equation3667 Fin4 reff370_inst.
Proof. unfold Equation3667. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff370_inst, reff370_op in H. discriminate H. Qed.

Lemma reff370_not3668 : ~ @Equation3668 Fin4 reff370_inst.
Proof. unfold Equation3668. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff370_inst, reff370_op in H. discriminate H. Qed.

Lemma reff370_not3674 : ~ @Equation3674 Fin4 reff370_inst.
Proof. unfold Equation3674. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff370_inst, reff370_op in H. discriminate H. Qed.

Lemma reff370_not3675 : ~ @Equation3675 Fin4 reff370_inst.
Proof. unfold Equation3675. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff370_inst, reff370_op in H. discriminate H. Qed.

Lemma reff370_not3677 : ~ @Equation3677 Fin4 reff370_inst.
Proof. unfold Equation3677. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff370_inst, reff370_op in H. discriminate H. Qed.

Lemma reff370_not3678 : ~ @Equation3678 Fin4 reff370_inst.
Proof. unfold Equation3678. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff370_inst, reff370_op in H. discriminate H. Qed.

Lemma reff370_not3685 : ~ @Equation3685 Fin4 reff370_inst.
Proof. unfold Equation3685. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff370_inst, reff370_op in H. discriminate H. Qed.

Lemma reff370_not3687 : ~ @Equation3687 Fin4 reff370_inst.
Proof. unfold Equation3687. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff370_inst, reff370_op in H. discriminate H. Qed.

Lemma reff370_not3714 : ~ @Equation3714 Fin4 reff370_inst.
Proof. unfold Equation3714. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff370_inst, reff370_op in H. discriminate H. Qed.

Lemma reff370_not3721 : ~ @Equation3721 Fin4 reff370_inst.
Proof. unfold Equation3721. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff370_inst, reff370_op in H. discriminate H. Qed.

Lemma reff370_not3722 : ~ @Equation3722 Fin4 reff370_inst.
Proof. unfold Equation3722. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff370_inst, reff370_op in H. discriminate H. Qed.

Lemma reff370_not3724 : ~ @Equation3724 Fin4 reff370_inst.
Proof. unfold Equation3724. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff370_inst, reff370_op in H. discriminate H. Qed.

Lemma reff370_not3725 : ~ @Equation3725 Fin4 reff370_inst.
Proof. unfold Equation3725. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff370_inst, reff370_op in H. discriminate H. Qed.

Lemma reff370_not3748 : ~ @Equation3748 Fin4 reff370_inst.
Proof. unfold Equation3748. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff370_inst, reff370_op in H. discriminate H. Qed.

Lemma reff370_not3749 : ~ @Equation3749 Fin4 reff370_inst.
Proof. unfold Equation3749. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff370_inst, reff370_op in H. discriminate H. Qed.

Lemma reff370_not3751 : ~ @Equation3751 Fin4 reff370_inst.
Proof. unfold Equation3751. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff370_inst, reff370_op in H. discriminate H. Qed.

Lemma reff370_not3752 : ~ @Equation3752 Fin4 reff370_inst.
Proof. unfold Equation3752. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff370_inst, reff370_op in H. discriminate H. Qed.

Lemma reff370_not3761 : ~ @Equation3761 Fin4 reff370_inst.
Proof. unfold Equation3761. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff370_inst, reff370_op in H. discriminate H. Qed.

Lemma reff370_not3864 : ~ @Equation3864 Fin4 reff370_inst.
Proof. unfold Equation3864. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff370_inst, reff370_op in H. discriminate H. Qed.

Lemma reff370_not3865 : ~ @Equation3865 Fin4 reff370_inst.
Proof. unfold Equation3865. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff370_inst, reff370_op in H. discriminate H. Qed.

Lemma reff370_not3867 : ~ @Equation3867 Fin4 reff370_inst.
Proof. unfold Equation3867. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff370_inst, reff370_op in H. discriminate H. Qed.

Lemma reff370_not3868 : ~ @Equation3868 Fin4 reff370_inst.
Proof. unfold Equation3868. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff370_inst, reff370_op in H. discriminate H. Qed.

Lemma reff370_not3871 : ~ @Equation3871 Fin4 reff370_inst.
Proof. unfold Equation3871. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff370_inst, reff370_op in H. discriminate H. Qed.

Lemma reff370_not3877 : ~ @Equation3877 Fin4 reff370_inst.
Proof. unfold Equation3877. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff370_inst, reff370_op in H. discriminate H. Qed.

Lemma reff370_not3878 : ~ @Equation3878 Fin4 reff370_inst.
Proof. unfold Equation3878. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff370_inst, reff370_op in H. discriminate H. Qed.

Lemma reff370_not3881 : ~ @Equation3881 Fin4 reff370_inst.
Proof. unfold Equation3881. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff370_inst, reff370_op in H. discriminate H. Qed.

Lemma reff370_not3888 : ~ @Equation3888 Fin4 reff370_inst.
Proof. unfold Equation3888. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff370_inst, reff370_op in H. discriminate H. Qed.

Lemma reff370_not3890 : ~ @Equation3890 Fin4 reff370_inst.
Proof. unfold Equation3890. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff370_inst, reff370_op in H. discriminate H. Qed.

Lemma reff370_not3917 : ~ @Equation3917 Fin4 reff370_inst.
Proof. unfold Equation3917. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff370_inst, reff370_op in H. discriminate H. Qed.

Lemma reff370_not3918 : ~ @Equation3918 Fin4 reff370_inst.
Proof. unfold Equation3918. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff370_inst, reff370_op in H. discriminate H. Qed.

Lemma reff370_not3925 : ~ @Equation3925 Fin4 reff370_inst.
Proof. unfold Equation3925. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff370_inst, reff370_op in H. discriminate H. Qed.

Lemma reff370_not3927 : ~ @Equation3927 Fin4 reff370_inst.
Proof. unfold Equation3927. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff370_inst, reff370_op in H. discriminate H. Qed.

Lemma reff370_not3951 : ~ @Equation3951 Fin4 reff370_inst.
Proof. unfold Equation3951. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff370_inst, reff370_op in H. discriminate H. Qed.

Lemma reff370_not3952 : ~ @Equation3952 Fin4 reff370_inst.
Proof. unfold Equation3952. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff370_inst, reff370_op in H. discriminate H. Qed.

Lemma reff370_not3954 : ~ @Equation3954 Fin4 reff370_inst.
Proof. unfold Equation3954. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff370_inst, reff370_op in H. discriminate H. Qed.

Lemma reff370_not3961 : ~ @Equation3961 Fin4 reff370_inst.
Proof. unfold Equation3961. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff370_inst, reff370_op in H. discriminate H. Qed.

Lemma reff370_not3964 : ~ @Equation3964 Fin4 reff370_inst.
Proof. unfold Equation3964. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff370_inst, reff370_op in H. discriminate H. Qed.

Lemma reff370_not4066 : ~ @Equation4066 Fin4 reff370_inst.
Proof. unfold Equation4066. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff370_inst, reff370_op in H. discriminate H. Qed.

Lemma reff370_not4067 : ~ @Equation4067 Fin4 reff370_inst.
Proof. unfold Equation4067. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff370_inst, reff370_op in H. discriminate H. Qed.

Lemma reff370_not4068 : ~ @Equation4068 Fin4 reff370_inst.
Proof. unfold Equation4068. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff370_inst, reff370_op in H. discriminate H. Qed.

Lemma reff370_not4070 : ~ @Equation4070 Fin4 reff370_inst.
Proof. unfold Equation4070. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff370_inst, reff370_op in H. discriminate H. Qed.

Lemma reff370_not4071 : ~ @Equation4071 Fin4 reff370_inst.
Proof. unfold Equation4071. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff370_inst, reff370_op in H. discriminate H. Qed.

Lemma reff370_not4074 : ~ @Equation4074 Fin4 reff370_inst.
Proof. unfold Equation4074. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff370_inst, reff370_op in H. discriminate H. Qed.

Lemma reff370_not4080 : ~ @Equation4080 Fin4 reff370_inst.
Proof. unfold Equation4080. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff370_inst, reff370_op in H. discriminate H. Qed.

Lemma reff370_not4081 : ~ @Equation4081 Fin4 reff370_inst.
Proof. unfold Equation4081. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff370_inst, reff370_op in H. discriminate H. Qed.

Lemma reff370_not4084 : ~ @Equation4084 Fin4 reff370_inst.
Proof. unfold Equation4084. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff370_inst, reff370_op in H. discriminate H. Qed.

Lemma reff370_not4091 : ~ @Equation4091 Fin4 reff370_inst.
Proof. unfold Equation4091. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff370_inst, reff370_op in H. discriminate H. Qed.

Lemma reff370_not4093 : ~ @Equation4093 Fin4 reff370_inst.
Proof. unfold Equation4093. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff370_inst, reff370_op in H. discriminate H. Qed.

Lemma reff370_not4120 : ~ @Equation4120 Fin4 reff370_inst.
Proof. unfold Equation4120. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff370_inst, reff370_op in H. discriminate H. Qed.

Lemma reff370_not4121 : ~ @Equation4121 Fin4 reff370_inst.
Proof. unfold Equation4121. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff370_inst, reff370_op in H. discriminate H. Qed.

Lemma reff370_not4127 : ~ @Equation4127 Fin4 reff370_inst.
Proof. unfold Equation4127. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff370_inst, reff370_op in H. discriminate H. Qed.

Lemma reff370_not4128 : ~ @Equation4128 Fin4 reff370_inst.
Proof. unfold Equation4128. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff370_inst, reff370_op in H. discriminate H. Qed.

Lemma reff370_not4130 : ~ @Equation4130 Fin4 reff370_inst.
Proof. unfold Equation4130. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff370_inst, reff370_op in H. discriminate H. Qed.

Lemma reff370_not4155 : ~ @Equation4155 Fin4 reff370_inst.
Proof. unfold Equation4155. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff370_inst, reff370_op in H. discriminate H. Qed.

Lemma reff370_not4157 : ~ @Equation4157 Fin4 reff370_inst.
Proof. unfold Equation4157. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff370_inst, reff370_op in H. discriminate H. Qed.

Lemma reff370_not4164 : ~ @Equation4164 Fin4 reff370_inst.
Proof. unfold Equation4164. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff370_inst, reff370_op in H. discriminate H. Qed.

Lemma reff370_not4167 : ~ @Equation4167 Fin4 reff370_inst.
Proof. unfold Equation4167. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff370_inst, reff370_op in H. discriminate H. Qed.

Lemma reff370_not4268 : ~ @Equation4268 Fin4 reff370_inst.
Proof. unfold Equation4268. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff370_inst, reff370_op in H. discriminate H. Qed.

Lemma reff370_not4269 : ~ @Equation4269 Fin4 reff370_inst.
Proof. unfold Equation4269. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff370_inst, reff370_op in H. discriminate H. Qed.

Lemma reff370_not4270 : ~ @Equation4270 Fin4 reff370_inst.
Proof. unfold Equation4270. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff370_inst, reff370_op in H. discriminate H. Qed.

Lemma reff370_not4272 : ~ @Equation4272 Fin4 reff370_inst.
Proof. unfold Equation4272. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff370_inst, reff370_op in H. discriminate H. Qed.

Lemma reff370_not4273 : ~ @Equation4273 Fin4 reff370_inst.
Proof. unfold Equation4273. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff370_inst, reff370_op in H. discriminate H. Qed.

Lemma reff370_not4275 : ~ @Equation4275 Fin4 reff370_inst.
Proof. unfold Equation4275. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff370_inst, reff370_op in H. discriminate H. Qed.

Lemma reff370_not4276 : ~ @Equation4276 Fin4 reff370_inst.
Proof. unfold Equation4276. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff370_inst, reff370_op in H. discriminate H. Qed.

Lemma reff370_not4283 : ~ @Equation4283 Fin4 reff370_inst.
Proof. unfold Equation4283. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff370_inst, reff370_op in H. discriminate H. Qed.

Lemma reff370_not4284 : ~ @Equation4284 Fin4 reff370_inst.
Proof. unfold Equation4284. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff370_inst, reff370_op in H. discriminate H. Qed.

Lemma reff370_not4290 : ~ @Equation4290 Fin4 reff370_inst.
Proof. unfold Equation4290. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff370_inst, reff370_op in H. discriminate H. Qed.

Lemma reff370_not4291 : ~ @Equation4291 Fin4 reff370_inst.
Proof. unfold Equation4291. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff370_inst, reff370_op in H. discriminate H. Qed.

Lemma reff370_not4293 : ~ @Equation4293 Fin4 reff370_inst.
Proof. unfold Equation4293. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff370_inst, reff370_op in H. discriminate H. Qed.

Lemma reff370_not4314 : ~ @Equation4314 Fin4 reff370_inst.
Proof. unfold Equation4314. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff370_inst, reff370_op in H. discriminate H. Qed.

Lemma reff370_not4321 : ~ @Equation4321 Fin4 reff370_inst.
Proof. unfold Equation4321. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff370_inst, reff370_op in H. discriminate H. Qed.

Lemma reff370_not4343 : ~ @Equation4343 Fin4 reff370_inst.
Proof. unfold Equation4343. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff370_inst, reff370_op in H. discriminate H. Qed.

Lemma reff370_not4380 : ~ @Equation4380 Fin4 reff370_inst.
Proof. unfold Equation4380. intro H. specialize (H F4_1). unfold magma_op, reff370_inst, reff370_op in H. discriminate H. Qed.

Lemma reff370_not4583 : ~ @Equation4583 Fin4 reff370_inst.
Proof. unfold Equation4583. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff370_inst, reff370_op in H. discriminate H. Qed.

Lemma reff370_not4584 : ~ @Equation4584 Fin4 reff370_inst.
Proof. unfold Equation4584. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff370_inst, reff370_op in H. discriminate H. Qed.

Lemma reff370_not4585 : ~ @Equation4585 Fin4 reff370_inst.
Proof. unfold Equation4585. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff370_inst, reff370_op in H. discriminate H. Qed.

Lemma reff370_not4587 : ~ @Equation4587 Fin4 reff370_inst.
Proof. unfold Equation4587. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff370_inst, reff370_op in H. discriminate H. Qed.

Lemma reff370_not4588 : ~ @Equation4588 Fin4 reff370_inst.
Proof. unfold Equation4588. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff370_inst, reff370_op in H. discriminate H. Qed.

Lemma reff370_not4591 : ~ @Equation4591 Fin4 reff370_inst.
Proof. unfold Equation4591. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff370_inst, reff370_op in H. discriminate H. Qed.

Lemma reff370_not4598 : ~ @Equation4598 Fin4 reff370_inst.
Proof. unfold Equation4598. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff370_inst, reff370_op in H. discriminate H. Qed.

Lemma reff370_not4599 : ~ @Equation4599 Fin4 reff370_inst.
Proof. unfold Equation4599. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff370_inst, reff370_op in H. discriminate H. Qed.

Lemma reff370_not4605 : ~ @Equation4605 Fin4 reff370_inst.
Proof. unfold Equation4605. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff370_inst, reff370_op in H. discriminate H. Qed.

Lemma reff370_not4606 : ~ @Equation4606 Fin4 reff370_inst.
Proof. unfold Equation4606. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff370_inst, reff370_op in H. discriminate H. Qed.

Lemma reff370_not4608 : ~ @Equation4608 Fin4 reff370_inst.
Proof. unfold Equation4608. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff370_inst, reff370_op in H. discriminate H. Qed.

Lemma reff370_not4629 : ~ @Equation4629 Fin4 reff370_inst.
Proof. unfold Equation4629. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff370_inst, reff370_op in H. discriminate H. Qed.

Lemma reff370_not4636 : ~ @Equation4636 Fin4 reff370_inst.
Proof. unfold Equation4636. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff370_inst, reff370_op in H. discriminate H. Qed.

Lemma reff370_not4658 : ~ @Equation4658 Fin4 reff370_inst.
Proof. unfold Equation4658. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff370_inst, reff370_op in H. discriminate H. Qed.

(** ---- reff374 (Fin4) ---- *)

Definition reff374_op (x y : Fin4) : Fin4 :=
  match x, y with
  | F4_0, F4_0 => F4_0 | F4_0, F4_1 => F4_0 | F4_0, F4_2 => F4_2 | F4_0, F4_3 => F4_2
  | F4_1, F4_0 => F4_0 | F4_1, F4_1 => F4_2 | F4_1, F4_2 => F4_2 | F4_1, F4_3 => F4_0
  | F4_2, F4_0 => F4_2 | F4_2, F4_1 => F4_2 | F4_2, F4_2 => F4_0 | F4_2, F4_3 => F4_0
  | F4_3, F4_0 => F4_2 | F4_3, F4_1 => F4_0 | F4_3, F4_2 => F4_0 | F4_3, F4_3 => F4_2
  end.

#[local] Instance reff374_inst : Magma Fin4 := {| magma_op := reff374_op |}.

Lemma reff374_sat3414 : @Equation3414 Fin4 reff374_inst.
Proof. unfold Equation3414, magma_op, reff374_inst, reff374_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff374_sat3417 : @Equation3417 Fin4 reff374_inst.
Proof. unfold Equation3417, magma_op, reff374_inst, reff374_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff374_sat3601 : @Equation3601 Fin4 reff374_inst.
Proof. unfold Equation3601, magma_op, reff374_inst, reff374_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff374_sat4007 : @Equation4007 Fin4 reff374_inst.
Proof. unfold Equation4007, magma_op, reff374_inst, reff374_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff374_sat4135 : @Equation4135 Fin4 reff374_inst.
Proof. unfold Equation4135, magma_op, reff374_inst, reff374_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff374_not47 : ~ @Equation47 Fin4 reff374_inst.
Proof. unfold Equation47. intro H. specialize (H F4_1). unfold magma_op, reff374_inst, reff374_op in H. discriminate H. Qed.

Lemma reff374_not99 : ~ @Equation99 Fin4 reff374_inst.
Proof. unfold Equation99. intro H. specialize (H F4_1). unfold magma_op, reff374_inst, reff374_op in H. discriminate H. Qed.

Lemma reff374_not151 : ~ @Equation151 Fin4 reff374_inst.
Proof. unfold Equation151. intro H. specialize (H F4_1). unfold magma_op, reff374_inst, reff374_op in H. discriminate H. Qed.

Lemma reff374_not203 : ~ @Equation203 Fin4 reff374_inst.
Proof. unfold Equation203. intro H. specialize (H F4_1). unfold magma_op, reff374_inst, reff374_op in H. discriminate H. Qed.

Lemma reff374_not255 : ~ @Equation255 Fin4 reff374_inst.
Proof. unfold Equation255. intro H. specialize (H F4_1). unfold magma_op, reff374_inst, reff374_op in H. discriminate H. Qed.

Lemma reff374_not307 : ~ @Equation307 Fin4 reff374_inst.
Proof. unfold Equation307. intro H. specialize (H F4_2). unfold magma_op, reff374_inst, reff374_op in H. discriminate H. Qed.

Lemma reff374_not359 : ~ @Equation359 Fin4 reff374_inst.
Proof. unfold Equation359. intro H. specialize (H F4_2). unfold magma_op, reff374_inst, reff374_op in H. discriminate H. Qed.

Lemma reff374_not411 : ~ @Equation411 Fin4 reff374_inst.
Proof. unfold Equation411. intro H. specialize (H F4_1). unfold magma_op, reff374_inst, reff374_op in H. discriminate H. Qed.

Lemma reff374_not614 : ~ @Equation614 Fin4 reff374_inst.
Proof. unfold Equation614. intro H. specialize (H F4_1). unfold magma_op, reff374_inst, reff374_op in H. discriminate H. Qed.

Lemma reff374_not817 : ~ @Equation817 Fin4 reff374_inst.
Proof. unfold Equation817. intro H. specialize (H F4_1). unfold magma_op, reff374_inst, reff374_op in H. discriminate H. Qed.

Lemma reff374_not1020 : ~ @Equation1020 Fin4 reff374_inst.
Proof. unfold Equation1020. intro H. specialize (H F4_1). unfold magma_op, reff374_inst, reff374_op in H. discriminate H. Qed.

Lemma reff374_not1223 : ~ @Equation1223 Fin4 reff374_inst.
Proof. unfold Equation1223. intro H. specialize (H F4_1). unfold magma_op, reff374_inst, reff374_op in H. discriminate H. Qed.

Lemma reff374_not1426 : ~ @Equation1426 Fin4 reff374_inst.
Proof. unfold Equation1426. intro H. specialize (H F4_1). unfold magma_op, reff374_inst, reff374_op in H. discriminate H. Qed.

Lemma reff374_not1629 : ~ @Equation1629 Fin4 reff374_inst.
Proof. unfold Equation1629. intro H. specialize (H F4_1). unfold magma_op, reff374_inst, reff374_op in H. discriminate H. Qed.

Lemma reff374_not1832 : ~ @Equation1832 Fin4 reff374_inst.
Proof. unfold Equation1832. intro H. specialize (H F4_1). unfold magma_op, reff374_inst, reff374_op in H. discriminate H. Qed.

Lemma reff374_not2035 : ~ @Equation2035 Fin4 reff374_inst.
Proof. unfold Equation2035. intro H. specialize (H F4_1). unfold magma_op, reff374_inst, reff374_op in H. discriminate H. Qed.

Lemma reff374_not2238 : ~ @Equation2238 Fin4 reff374_inst.
Proof. unfold Equation2238. intro H. specialize (H F4_1). unfold magma_op, reff374_inst, reff374_op in H. discriminate H. Qed.

Lemma reff374_not2441 : ~ @Equation2441 Fin4 reff374_inst.
Proof. unfold Equation2441. intro H. specialize (H F4_1). unfold magma_op, reff374_inst, reff374_op in H. discriminate H. Qed.

Lemma reff374_not2644 : ~ @Equation2644 Fin4 reff374_inst.
Proof. unfold Equation2644. intro H. specialize (H F4_1). unfold magma_op, reff374_inst, reff374_op in H. discriminate H. Qed.

Lemma reff374_not2847 : ~ @Equation2847 Fin4 reff374_inst.
Proof. unfold Equation2847. intro H. specialize (H F4_1). unfold magma_op, reff374_inst, reff374_op in H. discriminate H. Qed.

Lemma reff374_not3050 : ~ @Equation3050 Fin4 reff374_inst.
Proof. unfold Equation3050. intro H. specialize (H F4_1). unfold magma_op, reff374_inst, reff374_op in H. discriminate H. Qed.

Lemma reff374_not3254 : ~ @Equation3254 Fin4 reff374_inst.
Proof. unfold Equation3254. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff374_inst, reff374_op in H. discriminate H. Qed.

Lemma reff374_not3255 : ~ @Equation3255 Fin4 reff374_inst.
Proof. unfold Equation3255. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff374_inst, reff374_op in H. discriminate H. Qed.

Lemma reff374_not3256 : ~ @Equation3256 Fin4 reff374_inst.
Proof. unfold Equation3256. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff374_inst, reff374_op in H. discriminate H. Qed.

Lemma reff374_not3258 : ~ @Equation3258 Fin4 reff374_inst.
Proof. unfold Equation3258. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff374_inst, reff374_op in H. discriminate H. Qed.

Lemma reff374_not3259 : ~ @Equation3259 Fin4 reff374_inst.
Proof. unfold Equation3259. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff374_inst, reff374_op in H. discriminate H. Qed.

Lemma reff374_not3261 : ~ @Equation3261 Fin4 reff374_inst.
Proof. unfold Equation3261. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff374_inst, reff374_op in H. discriminate H. Qed.

Lemma reff374_not3262 : ~ @Equation3262 Fin4 reff374_inst.
Proof. unfold Equation3262. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff374_inst, reff374_op in H. discriminate H. Qed.

Lemma reff374_not3268 : ~ @Equation3268 Fin4 reff374_inst.
Proof. unfold Equation3268. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff374_inst, reff374_op in H. discriminate H. Qed.

Lemma reff374_not3271 : ~ @Equation3271 Fin4 reff374_inst.
Proof. unfold Equation3271. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff374_inst, reff374_op in H. discriminate H. Qed.

Lemma reff374_not3272 : ~ @Equation3272 Fin4 reff374_inst.
Proof. unfold Equation3272. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff374_inst, reff374_op in H. discriminate H. Qed.

Lemma reff374_not3279 : ~ @Equation3279 Fin4 reff374_inst.
Proof. unfold Equation3279. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff374_inst, reff374_op in H. discriminate H. Qed.

Lemma reff374_not3281 : ~ @Equation3281 Fin4 reff374_inst.
Proof. unfold Equation3281. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff374_inst, reff374_op in H. discriminate H. Qed.

Lemma reff374_not3309 : ~ @Equation3309 Fin4 reff374_inst.
Proof. unfold Equation3309. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff374_inst, reff374_op in H. discriminate H. Qed.

Lemma reff374_not3315 : ~ @Equation3315 Fin4 reff374_inst.
Proof. unfold Equation3315. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff374_inst, reff374_op in H. discriminate H. Qed.

Lemma reff374_not3316 : ~ @Equation3316 Fin4 reff374_inst.
Proof. unfold Equation3316. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff374_inst, reff374_op in H. discriminate H. Qed.

Lemma reff374_not3318 : ~ @Equation3318 Fin4 reff374_inst.
Proof. unfold Equation3318. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff374_inst, reff374_op in H. discriminate H. Qed.

Lemma reff374_not3319 : ~ @Equation3319 Fin4 reff374_inst.
Proof. unfold Equation3319. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff374_inst, reff374_op in H. discriminate H. Qed.

Lemma reff374_not3342 : ~ @Equation3342 Fin4 reff374_inst.
Proof. unfold Equation3342. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff374_inst, reff374_op in H. discriminate H. Qed.

Lemma reff374_not3343 : ~ @Equation3343 Fin4 reff374_inst.
Proof. unfold Equation3343. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff374_inst, reff374_op in H. discriminate H. Qed.

Lemma reff374_not3345 : ~ @Equation3345 Fin4 reff374_inst.
Proof. unfold Equation3345. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff374_inst, reff374_op in H. discriminate H. Qed.

Lemma reff374_not3346 : ~ @Equation3346 Fin4 reff374_inst.
Proof. unfold Equation3346. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff374_inst, reff374_op in H. discriminate H. Qed.

Lemma reff374_not3352 : ~ @Equation3352 Fin4 reff374_inst.
Proof. unfold Equation3352. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff374_inst, reff374_op in H. discriminate H. Qed.

Lemma reff374_not3457 : ~ @Equation3457 Fin4 reff374_inst.
Proof. unfold Equation3457. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff374_inst, reff374_op in H. discriminate H. Qed.

Lemma reff374_not3458 : ~ @Equation3458 Fin4 reff374_inst.
Proof. unfold Equation3458. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff374_inst, reff374_op in H. discriminate H. Qed.

Lemma reff374_not3459 : ~ @Equation3459 Fin4 reff374_inst.
Proof. unfold Equation3459. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff374_inst, reff374_op in H. discriminate H. Qed.

Lemma reff374_not3461 : ~ @Equation3461 Fin4 reff374_inst.
Proof. unfold Equation3461. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff374_inst, reff374_op in H. discriminate H. Qed.

Lemma reff374_not3462 : ~ @Equation3462 Fin4 reff374_inst.
Proof. unfold Equation3462. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff374_inst, reff374_op in H. discriminate H. Qed.

Lemma reff374_not3464 : ~ @Equation3464 Fin4 reff374_inst.
Proof. unfold Equation3464. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff374_inst, reff374_op in H. discriminate H. Qed.

Lemma reff374_not3465 : ~ @Equation3465 Fin4 reff374_inst.
Proof. unfold Equation3465. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff374_inst, reff374_op in H. discriminate H. Qed.

Lemma reff374_not3474 : ~ @Equation3474 Fin4 reff374_inst.
Proof. unfold Equation3474. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff374_inst, reff374_op in H. discriminate H. Qed.

Lemma reff374_not3475 : ~ @Equation3475 Fin4 reff374_inst.
Proof. unfold Equation3475. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff374_inst, reff374_op in H. discriminate H. Qed.

Lemma reff374_not3481 : ~ @Equation3481 Fin4 reff374_inst.
Proof. unfold Equation3481. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff374_inst, reff374_op in H. discriminate H. Qed.

Lemma reff374_not3482 : ~ @Equation3482 Fin4 reff374_inst.
Proof. unfold Equation3482. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff374_inst, reff374_op in H. discriminate H. Qed.

Lemma reff374_not3484 : ~ @Equation3484 Fin4 reff374_inst.
Proof. unfold Equation3484. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff374_inst, reff374_op in H. discriminate H. Qed.

Lemma reff374_not3509 : ~ @Equation3509 Fin4 reff374_inst.
Proof. unfold Equation3509. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff374_inst, reff374_op in H. discriminate H. Qed.

Lemma reff374_not3512 : ~ @Equation3512 Fin4 reff374_inst.
Proof. unfold Equation3512. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff374_inst, reff374_op in H. discriminate H. Qed.

Lemma reff374_not3519 : ~ @Equation3519 Fin4 reff374_inst.
Proof. unfold Equation3519. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff374_inst, reff374_op in H. discriminate H. Qed.

Lemma reff374_not3521 : ~ @Equation3521 Fin4 reff374_inst.
Proof. unfold Equation3521. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff374_inst, reff374_op in H. discriminate H. Qed.

Lemma reff374_not3522 : ~ @Equation3522 Fin4 reff374_inst.
Proof. unfold Equation3522. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff374_inst, reff374_op in H. discriminate H. Qed.

Lemma reff374_not3545 : ~ @Equation3545 Fin4 reff374_inst.
Proof. unfold Equation3545. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff374_inst, reff374_op in H. discriminate H. Qed.

Lemma reff374_not3546 : ~ @Equation3546 Fin4 reff374_inst.
Proof. unfold Equation3546. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff374_inst, reff374_op in H. discriminate H. Qed.

Lemma reff374_not3548 : ~ @Equation3548 Fin4 reff374_inst.
Proof. unfold Equation3548. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff374_inst, reff374_op in H. discriminate H. Qed.

Lemma reff374_not3555 : ~ @Equation3555 Fin4 reff374_inst.
Proof. unfold Equation3555. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff374_inst, reff374_op in H. discriminate H. Qed.

Lemma reff374_not3558 : ~ @Equation3558 Fin4 reff374_inst.
Proof. unfold Equation3558. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff374_inst, reff374_op in H. discriminate H. Qed.

Lemma reff374_not3659 : ~ @Equation3659 Fin4 reff374_inst.
Proof. unfold Equation3659. intro H. specialize (H F4_1). unfold magma_op, reff374_inst, reff374_op in H. discriminate H. Qed.

Lemma reff374_not3864 : ~ @Equation3864 Fin4 reff374_inst.
Proof. unfold Equation3864. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff374_inst, reff374_op in H. discriminate H. Qed.

Lemma reff374_not3865 : ~ @Equation3865 Fin4 reff374_inst.
Proof. unfold Equation3865. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff374_inst, reff374_op in H. discriminate H. Qed.

Lemma reff374_not3867 : ~ @Equation3867 Fin4 reff374_inst.
Proof. unfold Equation3867. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff374_inst, reff374_op in H. discriminate H. Qed.

Lemma reff374_not3868 : ~ @Equation3868 Fin4 reff374_inst.
Proof. unfold Equation3868. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff374_inst, reff374_op in H. discriminate H. Qed.

Lemma reff374_not3870 : ~ @Equation3870 Fin4 reff374_inst.
Proof. unfold Equation3870. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff374_inst, reff374_op in H. discriminate H. Qed.

Lemma reff374_not3871 : ~ @Equation3871 Fin4 reff374_inst.
Proof. unfold Equation3871. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff374_inst, reff374_op in H. discriminate H. Qed.

Lemma reff374_not3877 : ~ @Equation3877 Fin4 reff374_inst.
Proof. unfold Equation3877. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff374_inst, reff374_op in H. discriminate H. Qed.

Lemma reff374_not3880 : ~ @Equation3880 Fin4 reff374_inst.
Proof. unfold Equation3880. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff374_inst, reff374_op in H. discriminate H. Qed.

Lemma reff374_not3881 : ~ @Equation3881 Fin4 reff374_inst.
Proof. unfold Equation3881. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff374_inst, reff374_op in H. discriminate H. Qed.

Lemma reff374_not3887 : ~ @Equation3887 Fin4 reff374_inst.
Proof. unfold Equation3887. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff374_inst, reff374_op in H. discriminate H. Qed.

Lemma reff374_not3888 : ~ @Equation3888 Fin4 reff374_inst.
Proof. unfold Equation3888. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff374_inst, reff374_op in H. discriminate H. Qed.

Lemma reff374_not3890 : ~ @Equation3890 Fin4 reff374_inst.
Proof. unfold Equation3890. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff374_inst, reff374_op in H. discriminate H. Qed.

Lemma reff374_not3915 : ~ @Equation3915 Fin4 reff374_inst.
Proof. unfold Equation3915. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff374_inst, reff374_op in H. discriminate H. Qed.

Lemma reff374_not3918 : ~ @Equation3918 Fin4 reff374_inst.
Proof. unfold Equation3918. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff374_inst, reff374_op in H. discriminate H. Qed.

Lemma reff374_not3925 : ~ @Equation3925 Fin4 reff374_inst.
Proof. unfold Equation3925. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff374_inst, reff374_op in H. discriminate H. Qed.

Lemma reff374_not3927 : ~ @Equation3927 Fin4 reff374_inst.
Proof. unfold Equation3927. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff374_inst, reff374_op in H. discriminate H. Qed.

Lemma reff374_not3928 : ~ @Equation3928 Fin4 reff374_inst.
Proof. unfold Equation3928. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff374_inst, reff374_op in H. discriminate H. Qed.

Lemma reff374_not3951 : ~ @Equation3951 Fin4 reff374_inst.
Proof. unfold Equation3951. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff374_inst, reff374_op in H. discriminate H. Qed.

Lemma reff374_not3952 : ~ @Equation3952 Fin4 reff374_inst.
Proof. unfold Equation3952. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff374_inst, reff374_op in H. discriminate H. Qed.

Lemma reff374_not3954 : ~ @Equation3954 Fin4 reff374_inst.
Proof. unfold Equation3954. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff374_inst, reff374_op in H. discriminate H. Qed.

Lemma reff374_not3961 : ~ @Equation3961 Fin4 reff374_inst.
Proof. unfold Equation3961. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff374_inst, reff374_op in H. discriminate H. Qed.

Lemma reff374_not3964 : ~ @Equation3964 Fin4 reff374_inst.
Proof. unfold Equation3964. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff374_inst, reff374_op in H. discriminate H. Qed.

Lemma reff374_not4066 : ~ @Equation4066 Fin4 reff374_inst.
Proof. unfold Equation4066. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff374_inst, reff374_op in H. discriminate H. Qed.

Lemma reff374_not4067 : ~ @Equation4067 Fin4 reff374_inst.
Proof. unfold Equation4067. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff374_inst, reff374_op in H. discriminate H. Qed.

Lemma reff374_not4070 : ~ @Equation4070 Fin4 reff374_inst.
Proof. unfold Equation4070. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff374_inst, reff374_op in H. discriminate H. Qed.

Lemma reff374_not4071 : ~ @Equation4071 Fin4 reff374_inst.
Proof. unfold Equation4071. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff374_inst, reff374_op in H. discriminate H. Qed.

Lemma reff374_not4073 : ~ @Equation4073 Fin4 reff374_inst.
Proof. unfold Equation4073. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff374_inst, reff374_op in H. discriminate H. Qed.

Lemma reff374_not4074 : ~ @Equation4074 Fin4 reff374_inst.
Proof. unfold Equation4074. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff374_inst, reff374_op in H. discriminate H. Qed.

Lemma reff374_not4080 : ~ @Equation4080 Fin4 reff374_inst.
Proof. unfold Equation4080. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff374_inst, reff374_op in H. discriminate H. Qed.

Lemma reff374_not4083 : ~ @Equation4083 Fin4 reff374_inst.
Proof. unfold Equation4083. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff374_inst, reff374_op in H. discriminate H. Qed.

Lemma reff374_not4084 : ~ @Equation4084 Fin4 reff374_inst.
Proof. unfold Equation4084. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff374_inst, reff374_op in H. discriminate H. Qed.

Lemma reff374_not4090 : ~ @Equation4090 Fin4 reff374_inst.
Proof. unfold Equation4090. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff374_inst, reff374_op in H. discriminate H. Qed.

Lemma reff374_not4091 : ~ @Equation4091 Fin4 reff374_inst.
Proof. unfold Equation4091. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff374_inst, reff374_op in H. discriminate H. Qed.

Lemma reff374_not4093 : ~ @Equation4093 Fin4 reff374_inst.
Proof. unfold Equation4093. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff374_inst, reff374_op in H. discriminate H. Qed.

Lemma reff374_not4118 : ~ @Equation4118 Fin4 reff374_inst.
Proof. unfold Equation4118. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff374_inst, reff374_op in H. discriminate H. Qed.

Lemma reff374_not4120 : ~ @Equation4120 Fin4 reff374_inst.
Proof. unfold Equation4120. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff374_inst, reff374_op in H. discriminate H. Qed.

Lemma reff374_not4121 : ~ @Equation4121 Fin4 reff374_inst.
Proof. unfold Equation4121. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff374_inst, reff374_op in H. discriminate H. Qed.

Lemma reff374_not4128 : ~ @Equation4128 Fin4 reff374_inst.
Proof. unfold Equation4128. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff374_inst, reff374_op in H. discriminate H. Qed.

Lemma reff374_not4130 : ~ @Equation4130 Fin4 reff374_inst.
Proof. unfold Equation4130. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff374_inst, reff374_op in H. discriminate H. Qed.

Lemma reff374_not4155 : ~ @Equation4155 Fin4 reff374_inst.
Proof. unfold Equation4155. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff374_inst, reff374_op in H. discriminate H. Qed.

Lemma reff374_not4157 : ~ @Equation4157 Fin4 reff374_inst.
Proof. unfold Equation4157. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff374_inst, reff374_op in H. discriminate H. Qed.

Lemma reff374_not4164 : ~ @Equation4164 Fin4 reff374_inst.
Proof. unfold Equation4164. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff374_inst, reff374_op in H. discriminate H. Qed.

Lemma reff374_not4165 : ~ @Equation4165 Fin4 reff374_inst.
Proof. unfold Equation4165. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff374_inst, reff374_op in H. discriminate H. Qed.

Lemma reff374_not4167 : ~ @Equation4167 Fin4 reff374_inst.
Proof. unfold Equation4167. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff374_inst, reff374_op in H. discriminate H. Qed.

Lemma reff374_not4268 : ~ @Equation4268 Fin4 reff374_inst.
Proof. unfold Equation4268. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff374_inst, reff374_op in H. discriminate H. Qed.

Lemma reff374_not4269 : ~ @Equation4269 Fin4 reff374_inst.
Proof. unfold Equation4269. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff374_inst, reff374_op in H. discriminate H. Qed.

Lemma reff374_not4270 : ~ @Equation4270 Fin4 reff374_inst.
Proof. unfold Equation4270. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff374_inst, reff374_op in H. discriminate H. Qed.

Lemma reff374_not4272 : ~ @Equation4272 Fin4 reff374_inst.
Proof. unfold Equation4272. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff374_inst, reff374_op in H. discriminate H. Qed.

Lemma reff374_not4273 : ~ @Equation4273 Fin4 reff374_inst.
Proof. unfold Equation4273. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff374_inst, reff374_op in H. discriminate H. Qed.

Lemma reff374_not4275 : ~ @Equation4275 Fin4 reff374_inst.
Proof. unfold Equation4275. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff374_inst, reff374_op in H. discriminate H. Qed.

Lemma reff374_not4276 : ~ @Equation4276 Fin4 reff374_inst.
Proof. unfold Equation4276. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff374_inst, reff374_op in H. discriminate H. Qed.

Lemma reff374_not4284 : ~ @Equation4284 Fin4 reff374_inst.
Proof. unfold Equation4284. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff374_inst, reff374_op in H. discriminate H. Qed.

Lemma reff374_not4290 : ~ @Equation4290 Fin4 reff374_inst.
Proof. unfold Equation4290. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff374_inst, reff374_op in H. discriminate H. Qed.

Lemma reff374_not4291 : ~ @Equation4291 Fin4 reff374_inst.
Proof. unfold Equation4291. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff374_inst, reff374_op in H. discriminate H. Qed.

Lemma reff374_not4293 : ~ @Equation4293 Fin4 reff374_inst.
Proof. unfold Equation4293. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff374_inst, reff374_op in H. discriminate H. Qed.

Lemma reff374_not4314 : ~ @Equation4314 Fin4 reff374_inst.
Proof. unfold Equation4314. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff374_inst, reff374_op in H. discriminate H. Qed.

Lemma reff374_not4320 : ~ @Equation4320 Fin4 reff374_inst.
Proof. unfold Equation4320. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff374_inst, reff374_op in H. discriminate H. Qed.

Lemma reff374_not4321 : ~ @Equation4321 Fin4 reff374_inst.
Proof. unfold Equation4321. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff374_inst, reff374_op in H. discriminate H. Qed.

Lemma reff374_not4343 : ~ @Equation4343 Fin4 reff374_inst.
Proof. unfold Equation4343. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff374_inst, reff374_op in H. discriminate H. Qed.

Lemma reff374_not4396 : ~ @Equation4396 Fin4 reff374_inst.
Proof. unfold Equation4396. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff374_inst, reff374_op in H. discriminate H. Qed.

Lemma reff374_not4399 : ~ @Equation4399 Fin4 reff374_inst.
Proof. unfold Equation4399. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff374_inst, reff374_op in H. discriminate H. Qed.

Lemma reff374_not4406 : ~ @Equation4406 Fin4 reff374_inst.
Proof. unfold Equation4406. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff374_inst, reff374_op in H. discriminate H. Qed.

Lemma reff374_not4408 : ~ @Equation4408 Fin4 reff374_inst.
Proof. unfold Equation4408. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff374_inst, reff374_op in H. discriminate H. Qed.

Lemma reff374_not4433 : ~ @Equation4433 Fin4 reff374_inst.
Proof. unfold Equation4433. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff374_inst, reff374_op in H. discriminate H. Qed.

Lemma reff374_not4436 : ~ @Equation4436 Fin4 reff374_inst.
Proof. unfold Equation4436. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff374_inst, reff374_op in H. discriminate H. Qed.

Lemma reff374_not4443 : ~ @Equation4443 Fin4 reff374_inst.
Proof. unfold Equation4443. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff374_inst, reff374_op in H. discriminate H. Qed.

Lemma reff374_not4445 : ~ @Equation4445 Fin4 reff374_inst.
Proof. unfold Equation4445. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff374_inst, reff374_op in H. discriminate H. Qed.

Lemma reff374_not4470 : ~ @Equation4470 Fin4 reff374_inst.
Proof. unfold Equation4470. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff374_inst, reff374_op in H. discriminate H. Qed.

Lemma reff374_not4472 : ~ @Equation4472 Fin4 reff374_inst.
Proof. unfold Equation4472. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff374_inst, reff374_op in H. discriminate H. Qed.

Lemma reff374_not4473 : ~ @Equation4473 Fin4 reff374_inst.
Proof. unfold Equation4473. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff374_inst, reff374_op in H. discriminate H. Qed.

Lemma reff374_not4479 : ~ @Equation4479 Fin4 reff374_inst.
Proof. unfold Equation4479. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff374_inst, reff374_op in H. discriminate H. Qed.

Lemma reff374_not4480 : ~ @Equation4480 Fin4 reff374_inst.
Proof. unfold Equation4480. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff374_inst, reff374_op in H. discriminate H. Qed.

Lemma reff374_not4583 : ~ @Equation4583 Fin4 reff374_inst.
Proof. unfold Equation4583. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff374_inst, reff374_op in H. discriminate H. Qed.

Lemma reff374_not4584 : ~ @Equation4584 Fin4 reff374_inst.
Proof. unfold Equation4584. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff374_inst, reff374_op in H. discriminate H. Qed.

Lemma reff374_not4585 : ~ @Equation4585 Fin4 reff374_inst.
Proof. unfold Equation4585. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff374_inst, reff374_op in H. discriminate H. Qed.

Lemma reff374_not4587 : ~ @Equation4587 Fin4 reff374_inst.
Proof. unfold Equation4587. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff374_inst, reff374_op in H. discriminate H. Qed.

Lemma reff374_not4588 : ~ @Equation4588 Fin4 reff374_inst.
Proof. unfold Equation4588. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff374_inst, reff374_op in H. discriminate H. Qed.

Lemma reff374_not4590 : ~ @Equation4590 Fin4 reff374_inst.
Proof. unfold Equation4590. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff374_inst, reff374_op in H. discriminate H. Qed.

Lemma reff374_not4591 : ~ @Equation4591 Fin4 reff374_inst.
Proof. unfold Equation4591. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff374_inst, reff374_op in H. discriminate H. Qed.

Lemma reff374_not4598 : ~ @Equation4598 Fin4 reff374_inst.
Proof. unfold Equation4598. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff374_inst, reff374_op in H. discriminate H. Qed.

Lemma reff374_not4599 : ~ @Equation4599 Fin4 reff374_inst.
Proof. unfold Equation4599. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff374_inst, reff374_op in H. discriminate H. Qed.

Lemma reff374_not4605 : ~ @Equation4605 Fin4 reff374_inst.
Proof. unfold Equation4605. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff374_inst, reff374_op in H. discriminate H. Qed.

Lemma reff374_not4606 : ~ @Equation4606 Fin4 reff374_inst.
Proof. unfold Equation4606. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff374_inst, reff374_op in H. discriminate H. Qed.

Lemma reff374_not4608 : ~ @Equation4608 Fin4 reff374_inst.
Proof. unfold Equation4608. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff374_inst, reff374_op in H. discriminate H. Qed.

Lemma reff374_not4629 : ~ @Equation4629 Fin4 reff374_inst.
Proof. unfold Equation4629. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff374_inst, reff374_op in H. discriminate H. Qed.

Lemma reff374_not4636 : ~ @Equation4636 Fin4 reff374_inst.
Proof. unfold Equation4636. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff374_inst, reff374_op in H. discriminate H. Qed.

Lemma reff374_not4658 : ~ @Equation4658 Fin4 reff374_inst.
Proof. unfold Equation4658. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff374_inst, reff374_op in H. discriminate H. Qed.

(** ---- reff380 (Fin3) ---- *)

Definition reff380_op (x y : Fin3) : Fin3 :=
  match x, y with
  | F3_0, F3_0 => F3_0 | F3_0, F3_1 => F3_2 | F3_0, F3_2 => F3_0
  | F3_1, F3_0 => F3_2 | F3_1, F3_1 => F3_2 | F3_1, F3_2 => F3_1
  | F3_2, F3_0 => F3_0 | F3_2, F3_1 => F3_1 | F3_2, F3_2 => F3_1
  end.

#[local] Instance reff380_inst : Magma Fin3 := {| magma_op := reff380_op |}.

Lemma reff380_sat43 : @Equation43 Fin3 reff380_inst.
Proof. unfold Equation43, magma_op, reff380_inst, reff380_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff380_sat152 : @Equation152 Fin3 reff380_inst.
Proof. unfold Equation152, magma_op, reff380_inst, reff380_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff380_sat153 : @Equation153 Fin3 reff380_inst.
Proof. unfold Equation153, magma_op, reff380_inst, reff380_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff380_sat156 : @Equation156 Fin3 reff380_inst.
Proof. unfold Equation156, magma_op, reff380_inst, reff380_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff380_sat166 : @Equation166 Fin3 reff380_inst.
Proof. unfold Equation166, magma_op, reff380_inst, reff380_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff380_sat3258 : @Equation3258 Fin3 reff380_inst.
Proof. unfold Equation3258, magma_op, reff380_inst, reff380_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff380_sat3457 : @Equation3457 Fin3 reff380_inst.
Proof. unfold Equation3457, magma_op, reff380_inst, reff380_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff380_sat3877 : @Equation3877 Fin3 reff380_inst.
Proof. unfold Equation3877, magma_op, reff380_inst, reff380_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff380_sat4067 : @Equation4067 Fin3 reff380_inst.
Proof. unfold Equation4067, magma_op, reff380_inst, reff380_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff380_not47 : ~ @Equation47 Fin3 reff380_inst.
Proof. unfold Equation47. intro H. specialize (H F3_1). unfold magma_op, reff380_inst, reff380_op in H. discriminate H. Qed.

Lemma reff380_not99 : ~ @Equation99 Fin3 reff380_inst.
Proof. unfold Equation99. intro H. specialize (H F3_1). unfold magma_op, reff380_inst, reff380_op in H. discriminate H. Qed.

Lemma reff380_not154 : ~ @Equation154 Fin3 reff380_inst.
Proof. unfold Equation154. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff380_inst, reff380_op in H. discriminate H. Qed.

Lemma reff380_not157 : ~ @Equation157 Fin3 reff380_inst.
Proof. unfold Equation157. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff380_inst, reff380_op in H. discriminate H. Qed.

Lemma reff380_not159 : ~ @Equation159 Fin3 reff380_inst.
Proof. unfold Equation159. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff380_inst, reff380_op in H. discriminate H. Qed.

Lemma reff380_not160 : ~ @Equation160 Fin3 reff380_inst.
Proof. unfold Equation160. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff380_inst, reff380_op in H. discriminate H. Qed.

Lemma reff380_not167 : ~ @Equation167 Fin3 reff380_inst.
Proof. unfold Equation167. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff380_inst, reff380_op in H. discriminate H. Qed.

Lemma reff380_not169 : ~ @Equation169 Fin3 reff380_inst.
Proof. unfold Equation169. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff380_inst, reff380_op in H. discriminate H. Qed.

Lemma reff380_not170 : ~ @Equation170 Fin3 reff380_inst.
Proof. unfold Equation170. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff380_inst, reff380_op in H. discriminate H. Qed.

Lemma reff380_not176 : ~ @Equation176 Fin3 reff380_inst.
Proof. unfold Equation176. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff380_inst, reff380_op in H. discriminate H. Qed.

Lemma reff380_not177 : ~ @Equation177 Fin3 reff380_inst.
Proof. unfold Equation177. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff380_inst, reff380_op in H. discriminate H. Qed.

Lemma reff380_not179 : ~ @Equation179 Fin3 reff380_inst.
Proof. unfold Equation179. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff380_inst, reff380_op in H. discriminate H. Qed.

Lemma reff380_not203 : ~ @Equation203 Fin3 reff380_inst.
Proof. unfold Equation203. intro H. specialize (H F3_1). unfold magma_op, reff380_inst, reff380_op in H. discriminate H. Qed.

Lemma reff380_not255 : ~ @Equation255 Fin3 reff380_inst.
Proof. unfold Equation255. intro H. specialize (H F3_1). unfold magma_op, reff380_inst, reff380_op in H. discriminate H. Qed.

Lemma reff380_not307 : ~ @Equation307 Fin3 reff380_inst.
Proof. unfold Equation307. intro H. specialize (H F3_1). unfold magma_op, reff380_inst, reff380_op in H. discriminate H. Qed.

Lemma reff380_not359 : ~ @Equation359 Fin3 reff380_inst.
Proof. unfold Equation359. intro H. specialize (H F3_1). unfold magma_op, reff380_inst, reff380_op in H. discriminate H. Qed.

Lemma reff380_not411 : ~ @Equation411 Fin3 reff380_inst.
Proof. unfold Equation411. intro H. specialize (H F3_2). unfold magma_op, reff380_inst, reff380_op in H. discriminate H. Qed.

Lemma reff380_not614 : ~ @Equation614 Fin3 reff380_inst.
Proof. unfold Equation614. intro H. specialize (H F3_2). unfold magma_op, reff380_inst, reff380_op in H. discriminate H. Qed.

Lemma reff380_not817 : ~ @Equation817 Fin3 reff380_inst.
Proof. unfold Equation817. intro H. specialize (H F3_1). unfold magma_op, reff380_inst, reff380_op in H. discriminate H. Qed.

Lemma reff380_not1020 : ~ @Equation1020 Fin3 reff380_inst.
Proof. unfold Equation1020. intro H. specialize (H F3_2). unfold magma_op, reff380_inst, reff380_op in H. discriminate H. Qed.

Lemma reff380_not1223 : ~ @Equation1223 Fin3 reff380_inst.
Proof. unfold Equation1223. intro H. specialize (H F3_2). unfold magma_op, reff380_inst, reff380_op in H. discriminate H. Qed.

Lemma reff380_not1431 : ~ @Equation1431 Fin3 reff380_inst.
Proof. unfold Equation1431. intro H. specialize (H F3_1 F3_0). unfold magma_op, reff380_inst, reff380_op in H. discriminate H. Qed.

Lemma reff380_not1432 : ~ @Equation1432 Fin3 reff380_inst.
Proof. unfold Equation1432. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff380_inst, reff380_op in H. discriminate H. Qed.

Lemma reff380_not1434 : ~ @Equation1434 Fin3 reff380_inst.
Proof. unfold Equation1434. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff380_inst, reff380_op in H. discriminate H. Qed.

Lemma reff380_not1435 : ~ @Equation1435 Fin3 reff380_inst.
Proof. unfold Equation1435. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff380_inst, reff380_op in H. discriminate H. Qed.

Lemma reff380_not1441 : ~ @Equation1441 Fin3 reff380_inst.
Proof. unfold Equation1441. intro H. specialize (H F3_1 F3_2). unfold magma_op, reff380_inst, reff380_op in H. discriminate H. Qed.

Lemma reff380_not1442 : ~ @Equation1442 Fin3 reff380_inst.
Proof. unfold Equation1442. intro H. specialize (H F3_2 F3_0). unfold magma_op, reff380_inst, reff380_op in H. discriminate H. Qed.

Lemma reff380_not1444 : ~ @Equation1444 Fin3 reff380_inst.
Proof. unfold Equation1444. intro H. specialize (H F3_2 F3_0). unfold magma_op, reff380_inst, reff380_op in H. discriminate H. Qed.

Lemma reff380_not1445 : ~ @Equation1445 Fin3 reff380_inst.
Proof. unfold Equation1445. intro H. specialize (H F3_2 F3_0). unfold magma_op, reff380_inst, reff380_op in H. discriminate H. Qed.

Lemma reff380_not1451 : ~ @Equation1451 Fin3 reff380_inst.
Proof. unfold Equation1451. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff380_inst, reff380_op in H. discriminate H. Qed.

Lemma reff380_not1452 : ~ @Equation1452 Fin3 reff380_inst.
Proof. unfold Equation1452. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff380_inst, reff380_op in H. discriminate H. Qed.

Lemma reff380_not1454 : ~ @Equation1454 Fin3 reff380_inst.
Proof. unfold Equation1454. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff380_inst, reff380_op in H. discriminate H. Qed.

Lemma reff380_not1455 : ~ @Equation1455 Fin3 reff380_inst.
Proof. unfold Equation1455. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff380_inst, reff380_op in H. discriminate H. Qed.

Lemma reff380_not1478 : ~ @Equation1478 Fin3 reff380_inst.
Proof. unfold Equation1478. intro H. specialize (H F3_1 F3_2). unfold magma_op, reff380_inst, reff380_op in H. discriminate H. Qed.

Lemma reff380_not1479 : ~ @Equation1479 Fin3 reff380_inst.
Proof. unfold Equation1479. intro H. specialize (H F3_2 F3_0). unfold magma_op, reff380_inst, reff380_op in H. discriminate H. Qed.

Lemma reff380_not1481 : ~ @Equation1481 Fin3 reff380_inst.
Proof. unfold Equation1481. intro H. specialize (H F3_2 F3_0). unfold magma_op, reff380_inst, reff380_op in H. discriminate H. Qed.

Lemma reff380_not1482 : ~ @Equation1482 Fin3 reff380_inst.
Proof. unfold Equation1482. intro H. specialize (H F3_2 F3_0). unfold magma_op, reff380_inst, reff380_op in H. discriminate H. Qed.

Lemma reff380_not1488 : ~ @Equation1488 Fin3 reff380_inst.
Proof. unfold Equation1488. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff380_inst, reff380_op in H. discriminate H. Qed.

Lemma reff380_not1489 : ~ @Equation1489 Fin3 reff380_inst.
Proof. unfold Equation1489. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff380_inst, reff380_op in H. discriminate H. Qed.

Lemma reff380_not1491 : ~ @Equation1491 Fin3 reff380_inst.
Proof. unfold Equation1491. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff380_inst, reff380_op in H. discriminate H. Qed.

Lemma reff380_not1492 : ~ @Equation1492 Fin3 reff380_inst.
Proof. unfold Equation1492. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff380_inst, reff380_op in H. discriminate H. Qed.

Lemma reff380_not1515 : ~ @Equation1515 Fin3 reff380_inst.
Proof. unfold Equation1515. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff380_inst, reff380_op in H. discriminate H. Qed.

Lemma reff380_not1516 : ~ @Equation1516 Fin3 reff380_inst.
Proof. unfold Equation1516. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff380_inst, reff380_op in H. discriminate H. Qed.

Lemma reff380_not1518 : ~ @Equation1518 Fin3 reff380_inst.
Proof. unfold Equation1518. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff380_inst, reff380_op in H. discriminate H. Qed.

Lemma reff380_not1519 : ~ @Equation1519 Fin3 reff380_inst.
Proof. unfold Equation1519. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff380_inst, reff380_op in H. discriminate H. Qed.

Lemma reff380_not1525 : ~ @Equation1525 Fin3 reff380_inst.
Proof. unfold Equation1525. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff380_inst, reff380_op in H. discriminate H. Qed.

Lemma reff380_not1526 : ~ @Equation1526 Fin3 reff380_inst.
Proof. unfold Equation1526. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff380_inst, reff380_op in H. discriminate H. Qed.

Lemma reff380_not1528 : ~ @Equation1528 Fin3 reff380_inst.
Proof. unfold Equation1528. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff380_inst, reff380_op in H. discriminate H. Qed.

Lemma reff380_not1630 : ~ @Equation1630 Fin3 reff380_inst.
Proof. unfold Equation1630. intro H. specialize (H F3_1 F3_0). unfold magma_op, reff380_inst, reff380_op in H. discriminate H. Qed.

Lemma reff380_not1632 : ~ @Equation1632 Fin3 reff380_inst.
Proof. unfold Equation1632. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff380_inst, reff380_op in H. discriminate H. Qed.

Lemma reff380_not1635 : ~ @Equation1635 Fin3 reff380_inst.
Proof. unfold Equation1635. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff380_inst, reff380_op in H. discriminate H. Qed.

Lemma reff380_not1638 : ~ @Equation1638 Fin3 reff380_inst.
Proof. unfold Equation1638. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff380_inst, reff380_op in H. discriminate H. Qed.

Lemma reff380_not1644 : ~ @Equation1644 Fin3 reff380_inst.
Proof. unfold Equation1644. intro H. specialize (H F3_1 F3_2). unfold magma_op, reff380_inst, reff380_op in H. discriminate H. Qed.

Lemma reff380_not1645 : ~ @Equation1645 Fin3 reff380_inst.
Proof. unfold Equation1645. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff380_inst, reff380_op in H. discriminate H. Qed.

Lemma reff380_not1647 : ~ @Equation1647 Fin3 reff380_inst.
Proof. unfold Equation1647. intro H. specialize (H F3_2 F3_0). unfold magma_op, reff380_inst, reff380_op in H. discriminate H. Qed.

Lemma reff380_not1648 : ~ @Equation1648 Fin3 reff380_inst.
Proof. unfold Equation1648. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff380_inst, reff380_op in H. discriminate H. Qed.

Lemma reff380_not1654 : ~ @Equation1654 Fin3 reff380_inst.
Proof. unfold Equation1654. intro H. specialize (H F3_2 F3_0). unfold magma_op, reff380_inst, reff380_op in H. discriminate H. Qed.

Lemma reff380_not1655 : ~ @Equation1655 Fin3 reff380_inst.
Proof. unfold Equation1655. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff380_inst, reff380_op in H. discriminate H. Qed.

Lemma reff380_not1657 : ~ @Equation1657 Fin3 reff380_inst.
Proof. unfold Equation1657. intro H. specialize (H F3_2 F3_0). unfold magma_op, reff380_inst, reff380_op in H. discriminate H. Qed.

Lemma reff380_not1658 : ~ @Equation1658 Fin3 reff380_inst.
Proof. unfold Equation1658. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff380_inst, reff380_op in H. discriminate H. Qed.

Lemma reff380_not1681 : ~ @Equation1681 Fin3 reff380_inst.
Proof. unfold Equation1681. intro H. specialize (H F3_1 F3_2). unfold magma_op, reff380_inst, reff380_op in H. discriminate H. Qed.

Lemma reff380_not1682 : ~ @Equation1682 Fin3 reff380_inst.
Proof. unfold Equation1682. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff380_inst, reff380_op in H. discriminate H. Qed.

Lemma reff380_not1684 : ~ @Equation1684 Fin3 reff380_inst.
Proof. unfold Equation1684. intro H. specialize (H F3_2 F3_0). unfold magma_op, reff380_inst, reff380_op in H. discriminate H. Qed.

Lemma reff380_not1685 : ~ @Equation1685 Fin3 reff380_inst.
Proof. unfold Equation1685. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff380_inst, reff380_op in H. discriminate H. Qed.

Lemma reff380_not1691 : ~ @Equation1691 Fin3 reff380_inst.
Proof. unfold Equation1691. intro H. specialize (H F3_2 F3_0). unfold magma_op, reff380_inst, reff380_op in H. discriminate H. Qed.

Lemma reff380_not1692 : ~ @Equation1692 Fin3 reff380_inst.
Proof. unfold Equation1692. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff380_inst, reff380_op in H. discriminate H. Qed.

Lemma reff380_not1694 : ~ @Equation1694 Fin3 reff380_inst.
Proof. unfold Equation1694. intro H. specialize (H F3_2 F3_0). unfold magma_op, reff380_inst, reff380_op in H. discriminate H. Qed.

Lemma reff380_not1695 : ~ @Equation1695 Fin3 reff380_inst.
Proof. unfold Equation1695. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff380_inst, reff380_op in H. discriminate H. Qed.

Lemma reff380_not1718 : ~ @Equation1718 Fin3 reff380_inst.
Proof. unfold Equation1718. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff380_inst, reff380_op in H. discriminate H. Qed.

Lemma reff380_not1719 : ~ @Equation1719 Fin3 reff380_inst.
Proof. unfold Equation1719. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff380_inst, reff380_op in H. discriminate H. Qed.

Lemma reff380_not1721 : ~ @Equation1721 Fin3 reff380_inst.
Proof. unfold Equation1721. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff380_inst, reff380_op in H. discriminate H. Qed.

Lemma reff380_not1722 : ~ @Equation1722 Fin3 reff380_inst.
Proof. unfold Equation1722. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff380_inst, reff380_op in H. discriminate H. Qed.

Lemma reff380_not1728 : ~ @Equation1728 Fin3 reff380_inst.
Proof. unfold Equation1728. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff380_inst, reff380_op in H. discriminate H. Qed.

Lemma reff380_not1729 : ~ @Equation1729 Fin3 reff380_inst.
Proof. unfold Equation1729. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff380_inst, reff380_op in H. discriminate H. Qed.

Lemma reff380_not1731 : ~ @Equation1731 Fin3 reff380_inst.
Proof. unfold Equation1731. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff380_inst, reff380_op in H. discriminate H. Qed.

Lemma reff380_not1833 : ~ @Equation1833 Fin3 reff380_inst.
Proof. unfold Equation1833. intro H. specialize (H F3_1 F3_2). unfold magma_op, reff380_inst, reff380_op in H. discriminate H. Qed.

Lemma reff380_not1834 : ~ @Equation1834 Fin3 reff380_inst.
Proof. unfold Equation1834. intro H. specialize (H F3_1 F3_2). unfold magma_op, reff380_inst, reff380_op in H. discriminate H. Qed.

Lemma reff380_not1835 : ~ @Equation1835 Fin3 reff380_inst.
Proof. unfold Equation1835. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff380_inst, reff380_op in H. discriminate H. Qed.

Lemma reff380_not1838 : ~ @Equation1838 Fin3 reff380_inst.
Proof. unfold Equation1838. intro H. specialize (H F3_2 F3_0). unfold magma_op, reff380_inst, reff380_op in H. discriminate H. Qed.

Lemma reff380_not1840 : ~ @Equation1840 Fin3 reff380_inst.
Proof. unfold Equation1840. intro H. specialize (H F3_2 F3_0). unfold magma_op, reff380_inst, reff380_op in H. discriminate H. Qed.

Lemma reff380_not1841 : ~ @Equation1841 Fin3 reff380_inst.
Proof. unfold Equation1841. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff380_inst, reff380_op in H. discriminate H. Qed.

Lemma reff380_not1848 : ~ @Equation1848 Fin3 reff380_inst.
Proof. unfold Equation1848. intro H. specialize (H F3_2 F3_0). unfold magma_op, reff380_inst, reff380_op in H. discriminate H. Qed.

Lemma reff380_not1850 : ~ @Equation1850 Fin3 reff380_inst.
Proof. unfold Equation1850. intro H. specialize (H F3_2 F3_0). unfold magma_op, reff380_inst, reff380_op in H. discriminate H. Qed.

Lemma reff380_not1851 : ~ @Equation1851 Fin3 reff380_inst.
Proof. unfold Equation1851. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff380_inst, reff380_op in H. discriminate H. Qed.

Lemma reff380_not1858 : ~ @Equation1858 Fin3 reff380_inst.
Proof. unfold Equation1858. intro H. specialize (H F3_2 F3_0). unfold magma_op, reff380_inst, reff380_op in H. discriminate H. Qed.

Lemma reff380_not1860 : ~ @Equation1860 Fin3 reff380_inst.
Proof. unfold Equation1860. intro H. specialize (H F3_2 F3_0). unfold magma_op, reff380_inst, reff380_op in H. discriminate H. Qed.

Lemma reff380_not1861 : ~ @Equation1861 Fin3 reff380_inst.
Proof. unfold Equation1861. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff380_inst, reff380_op in H. discriminate H. Qed.

Lemma reff380_not1884 : ~ @Equation1884 Fin3 reff380_inst.
Proof. unfold Equation1884. intro H. specialize (H F3_1 F3_0). unfold magma_op, reff380_inst, reff380_op in H. discriminate H. Qed.

Lemma reff380_not1885 : ~ @Equation1885 Fin3 reff380_inst.
Proof. unfold Equation1885. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff380_inst, reff380_op in H. discriminate H. Qed.

Lemma reff380_not1887 : ~ @Equation1887 Fin3 reff380_inst.
Proof. unfold Equation1887. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff380_inst, reff380_op in H. discriminate H. Qed.

Lemma reff380_not1888 : ~ @Equation1888 Fin3 reff380_inst.
Proof. unfold Equation1888. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff380_inst, reff380_op in H. discriminate H. Qed.

Lemma reff380_not1894 : ~ @Equation1894 Fin3 reff380_inst.
Proof. unfold Equation1894. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff380_inst, reff380_op in H. discriminate H. Qed.

Lemma reff380_not1895 : ~ @Equation1895 Fin3 reff380_inst.
Proof. unfold Equation1895. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff380_inst, reff380_op in H. discriminate H. Qed.

Lemma reff380_not1897 : ~ @Equation1897 Fin3 reff380_inst.
Proof. unfold Equation1897. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff380_inst, reff380_op in H. discriminate H. Qed.

Lemma reff380_not1898 : ~ @Equation1898 Fin3 reff380_inst.
Proof. unfold Equation1898. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff380_inst, reff380_op in H. discriminate H. Qed.

Lemma reff380_not1921 : ~ @Equation1921 Fin3 reff380_inst.
Proof. unfold Equation1921. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff380_inst, reff380_op in H. discriminate H. Qed.

Lemma reff380_not1922 : ~ @Equation1922 Fin3 reff380_inst.
Proof. unfold Equation1922. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff380_inst, reff380_op in H. discriminate H. Qed.

Lemma reff380_not1924 : ~ @Equation1924 Fin3 reff380_inst.
Proof. unfold Equation1924. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff380_inst, reff380_op in H. discriminate H. Qed.

Lemma reff380_not1925 : ~ @Equation1925 Fin3 reff380_inst.
Proof. unfold Equation1925. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff380_inst, reff380_op in H. discriminate H. Qed.

Lemma reff380_not1931 : ~ @Equation1931 Fin3 reff380_inst.
Proof. unfold Equation1931. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff380_inst, reff380_op in H. discriminate H. Qed.

Lemma reff380_not1932 : ~ @Equation1932 Fin3 reff380_inst.
Proof. unfold Equation1932. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff380_inst, reff380_op in H. discriminate H. Qed.

Lemma reff380_not1934 : ~ @Equation1934 Fin3 reff380_inst.
Proof. unfold Equation1934. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff380_inst, reff380_op in H. discriminate H. Qed.

Lemma reff380_not2036 : ~ @Equation2036 Fin3 reff380_inst.
Proof. unfold Equation2036. intro H. specialize (H F3_1 F3_2). unfold magma_op, reff380_inst, reff380_op in H. discriminate H. Qed.

Lemma reff380_not2037 : ~ @Equation2037 Fin3 reff380_inst.
Proof. unfold Equation2037. intro H. specialize (H F3_1 F3_2). unfold magma_op, reff380_inst, reff380_op in H. discriminate H. Qed.

Lemma reff380_not2038 : ~ @Equation2038 Fin3 reff380_inst.
Proof. unfold Equation2038. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff380_inst, reff380_op in H. discriminate H. Qed.

Lemma reff380_not2040 : ~ @Equation2040 Fin3 reff380_inst.
Proof. unfold Equation2040. intro H. specialize (H F3_1 F3_0). unfold magma_op, reff380_inst, reff380_op in H. discriminate H. Qed.

Lemma reff380_not2041 : ~ @Equation2041 Fin3 reff380_inst.
Proof. unfold Equation2041. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff380_inst, reff380_op in H. discriminate H. Qed.

Lemma reff380_not2043 : ~ @Equation2043 Fin3 reff380_inst.
Proof. unfold Equation2043. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff380_inst, reff380_op in H. discriminate H. Qed.

Lemma reff380_not2044 : ~ @Equation2044 Fin3 reff380_inst.
Proof. unfold Equation2044. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff380_inst, reff380_op in H. discriminate H. Qed.

Lemma reff380_not2051 : ~ @Equation2051 Fin3 reff380_inst.
Proof. unfold Equation2051. intro H. specialize (H F3_2 F3_0). unfold magma_op, reff380_inst, reff380_op in H. discriminate H. Qed.

Lemma reff380_not2053 : ~ @Equation2053 Fin3 reff380_inst.
Proof. unfold Equation2053. intro H. specialize (H F3_2 F3_0). unfold magma_op, reff380_inst, reff380_op in H. discriminate H. Qed.

Lemma reff380_not2054 : ~ @Equation2054 Fin3 reff380_inst.
Proof. unfold Equation2054. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff380_inst, reff380_op in H. discriminate H. Qed.

Lemma reff380_not2060 : ~ @Equation2060 Fin3 reff380_inst.
Proof. unfold Equation2060. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff380_inst, reff380_op in H. discriminate H. Qed.

Lemma reff380_not2061 : ~ @Equation2061 Fin3 reff380_inst.
Proof. unfold Equation2061. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff380_inst, reff380_op in H. discriminate H. Qed.

Lemma reff380_not2063 : ~ @Equation2063 Fin3 reff380_inst.
Proof. unfold Equation2063. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff380_inst, reff380_op in H. discriminate H. Qed.

Lemma reff380_not2064 : ~ @Equation2064 Fin3 reff380_inst.
Proof. unfold Equation2064. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff380_inst, reff380_op in H. discriminate H. Qed.

Lemma reff380_not2088 : ~ @Equation2088 Fin3 reff380_inst.
Proof. unfold Equation2088. intro H. specialize (H F3_2 F3_0). unfold magma_op, reff380_inst, reff380_op in H. discriminate H. Qed.

Lemma reff380_not2090 : ~ @Equation2090 Fin3 reff380_inst.
Proof. unfold Equation2090. intro H. specialize (H F3_2 F3_0). unfold magma_op, reff380_inst, reff380_op in H. discriminate H. Qed.

Lemma reff380_not2091 : ~ @Equation2091 Fin3 reff380_inst.
Proof. unfold Equation2091. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff380_inst, reff380_op in H. discriminate H. Qed.

Lemma reff380_not2097 : ~ @Equation2097 Fin3 reff380_inst.
Proof. unfold Equation2097. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff380_inst, reff380_op in H. discriminate H. Qed.

Lemma reff380_not2098 : ~ @Equation2098 Fin3 reff380_inst.
Proof. unfold Equation2098. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff380_inst, reff380_op in H. discriminate H. Qed.

Lemma reff380_not2100 : ~ @Equation2100 Fin3 reff380_inst.
Proof. unfold Equation2100. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff380_inst, reff380_op in H. discriminate H. Qed.

Lemma reff380_not2101 : ~ @Equation2101 Fin3 reff380_inst.
Proof. unfold Equation2101. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff380_inst, reff380_op in H. discriminate H. Qed.

Lemma reff380_not2125 : ~ @Equation2125 Fin3 reff380_inst.
Proof. unfold Equation2125. intro H. specialize (H F3_2 F3_0). unfold magma_op, reff380_inst, reff380_op in H. discriminate H. Qed.

Lemma reff380_not2127 : ~ @Equation2127 Fin3 reff380_inst.
Proof. unfold Equation2127. intro H. specialize (H F3_2 F3_0). unfold magma_op, reff380_inst, reff380_op in H. discriminate H. Qed.

Lemma reff380_not2128 : ~ @Equation2128 Fin3 reff380_inst.
Proof. unfold Equation2128. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff380_inst, reff380_op in H. discriminate H. Qed.

Lemma reff380_not2134 : ~ @Equation2134 Fin3 reff380_inst.
Proof. unfold Equation2134. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff380_inst, reff380_op in H. discriminate H. Qed.

Lemma reff380_not2135 : ~ @Equation2135 Fin3 reff380_inst.
Proof. unfold Equation2135. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff380_inst, reff380_op in H. discriminate H. Qed.

Lemma reff380_not2137 : ~ @Equation2137 Fin3 reff380_inst.
Proof. unfold Equation2137. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff380_inst, reff380_op in H. discriminate H. Qed.

Lemma reff380_not2238 : ~ @Equation2238 Fin3 reff380_inst.
Proof. unfold Equation2238. intro H. specialize (H F3_2). unfold magma_op, reff380_inst, reff380_op in H. discriminate H. Qed.

Lemma reff380_not2441 : ~ @Equation2441 Fin3 reff380_inst.
Proof. unfold Equation2441. intro H. specialize (H F3_2). unfold magma_op, reff380_inst, reff380_op in H. discriminate H. Qed.

Lemma reff380_not2644 : ~ @Equation2644 Fin3 reff380_inst.
Proof. unfold Equation2644. intro H. specialize (H F3_1). unfold magma_op, reff380_inst, reff380_op in H. discriminate H. Qed.

Lemma reff380_not2847 : ~ @Equation2847 Fin3 reff380_inst.
Proof. unfold Equation2847. intro H. specialize (H F3_2). unfold magma_op, reff380_inst, reff380_op in H. discriminate H. Qed.

Lemma reff380_not3050 : ~ @Equation3050 Fin3 reff380_inst.
Proof. unfold Equation3050. intro H. specialize (H F3_2). unfold magma_op, reff380_inst, reff380_op in H. discriminate H. Qed.

Lemma reff380_not3254 : ~ @Equation3254 Fin3 reff380_inst.
Proof. unfold Equation3254. intro H. specialize (H F3_1 F3_2). unfold magma_op, reff380_inst, reff380_op in H. discriminate H. Qed.

Lemma reff380_not3255 : ~ @Equation3255 Fin3 reff380_inst.
Proof. unfold Equation3255. intro H. specialize (H F3_1 F3_2). unfold magma_op, reff380_inst, reff380_op in H. discriminate H. Qed.

Lemma reff380_not3256 : ~ @Equation3256 Fin3 reff380_inst.
Proof. unfold Equation3256. intro H. specialize (H F3_1 F3_0). unfold magma_op, reff380_inst, reff380_op in H. discriminate H. Qed.

Lemma reff380_not3259 : ~ @Equation3259 Fin3 reff380_inst.
Proof. unfold Equation3259. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff380_inst, reff380_op in H. discriminate H. Qed.

Lemma reff380_not3261 : ~ @Equation3261 Fin3 reff380_inst.
Proof. unfold Equation3261. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff380_inst, reff380_op in H. discriminate H. Qed.

Lemma reff380_not3262 : ~ @Equation3262 Fin3 reff380_inst.
Proof. unfold Equation3262. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff380_inst, reff380_op in H. discriminate H. Qed.

Lemma reff380_not3268 : ~ @Equation3268 Fin3 reff380_inst.
Proof. unfold Equation3268. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff380_inst, reff380_op in H. discriminate H. Qed.

Lemma reff380_not3271 : ~ @Equation3271 Fin3 reff380_inst.
Proof. unfold Equation3271. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff380_inst, reff380_op in H. discriminate H. Qed.

Lemma reff380_not3272 : ~ @Equation3272 Fin3 reff380_inst.
Proof. unfold Equation3272. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff380_inst, reff380_op in H. discriminate H. Qed.

Lemma reff380_not3278 : ~ @Equation3278 Fin3 reff380_inst.
Proof. unfold Equation3278. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff380_inst, reff380_op in H. discriminate H. Qed.

Lemma reff380_not3279 : ~ @Equation3279 Fin3 reff380_inst.
Proof. unfold Equation3279. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff380_inst, reff380_op in H. discriminate H. Qed.

Lemma reff380_not3281 : ~ @Equation3281 Fin3 reff380_inst.
Proof. unfold Equation3281. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff380_inst, reff380_op in H. discriminate H. Qed.

Lemma reff380_not3306 : ~ @Equation3306 Fin3 reff380_inst.
Proof. unfold Equation3306. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff380_inst, reff380_op in H. discriminate H. Qed.

Lemma reff380_not3308 : ~ @Equation3308 Fin3 reff380_inst.
Proof. unfold Equation3308. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff380_inst, reff380_op in H. discriminate H. Qed.

Lemma reff380_not3309 : ~ @Equation3309 Fin3 reff380_inst.
Proof. unfold Equation3309. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff380_inst, reff380_op in H. discriminate H. Qed.

Lemma reff380_not3315 : ~ @Equation3315 Fin3 reff380_inst.
Proof. unfold Equation3315. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff380_inst, reff380_op in H. discriminate H. Qed.

Lemma reff380_not3316 : ~ @Equation3316 Fin3 reff380_inst.
Proof. unfold Equation3316. intro H. specialize (H F3_1 F3_2). unfold magma_op, reff380_inst, reff380_op in H. discriminate H. Qed.

Lemma reff380_not3318 : ~ @Equation3318 Fin3 reff380_inst.
Proof. unfold Equation3318. intro H. specialize (H F3_1 F3_2). unfold magma_op, reff380_inst, reff380_op in H. discriminate H. Qed.

Lemma reff380_not3319 : ~ @Equation3319 Fin3 reff380_inst.
Proof. unfold Equation3319. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff380_inst, reff380_op in H. discriminate H. Qed.

Lemma reff380_not3342 : ~ @Equation3342 Fin3 reff380_inst.
Proof. unfold Equation3342. intro H. specialize (H F3_2 F3_0). unfold magma_op, reff380_inst, reff380_op in H. discriminate H. Qed.

Lemma reff380_not3343 : ~ @Equation3343 Fin3 reff380_inst.
Proof. unfold Equation3343. intro H. specialize (H F3_2 F3_1). unfold magma_op, reff380_inst, reff380_op in H. discriminate H. Qed.

Lemma reff380_not3345 : ~ @Equation3345 Fin3 reff380_inst.
Proof. unfold Equation3345. intro H. specialize (H F3_2 F3_1). unfold magma_op, reff380_inst, reff380_op in H. discriminate H. Qed.

Lemma reff380_not3346 : ~ @Equation3346 Fin3 reff380_inst.
Proof. unfold Equation3346. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff380_inst, reff380_op in H. discriminate H. Qed.

Lemma reff380_not3352 : ~ @Equation3352 Fin3 reff380_inst.
Proof. unfold Equation3352. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff380_inst, reff380_op in H. discriminate H. Qed.

Lemma reff380_not3353 : ~ @Equation3353 Fin3 reff380_inst.
Proof. unfold Equation3353. intro H. specialize (H F3_1 F3_0). unfold magma_op, reff380_inst, reff380_op in H. discriminate H. Qed.

Lemma reff380_not3355 : ~ @Equation3355 Fin3 reff380_inst.
Proof. unfold Equation3355. intro H. specialize (H F3_1 F3_0). unfold magma_op, reff380_inst, reff380_op in H. discriminate H. Qed.

Lemma reff380_not3458 : ~ @Equation3458 Fin3 reff380_inst.
Proof. unfold Equation3458. intro H. specialize (H F3_1 F3_2). unfold magma_op, reff380_inst, reff380_op in H. discriminate H. Qed.

Lemma reff380_not3459 : ~ @Equation3459 Fin3 reff380_inst.
Proof. unfold Equation3459. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff380_inst, reff380_op in H. discriminate H. Qed.

Lemma reff380_not3461 : ~ @Equation3461 Fin3 reff380_inst.
Proof. unfold Equation3461. intro H. specialize (H F3_1 F3_2). unfold magma_op, reff380_inst, reff380_op in H. discriminate H. Qed.

Lemma reff380_not3462 : ~ @Equation3462 Fin3 reff380_inst.
Proof. unfold Equation3462. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff380_inst, reff380_op in H. discriminate H. Qed.

Lemma reff380_not3464 : ~ @Equation3464 Fin3 reff380_inst.
Proof. unfold Equation3464. intro H. specialize (H F3_1 F3_0). unfold magma_op, reff380_inst, reff380_op in H. discriminate H. Qed.

Lemma reff380_not3465 : ~ @Equation3465 Fin3 reff380_inst.
Proof. unfold Equation3465. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff380_inst, reff380_op in H. discriminate H. Qed.

Lemma reff380_not3472 : ~ @Equation3472 Fin3 reff380_inst.
Proof. unfold Equation3472. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff380_inst, reff380_op in H. discriminate H. Qed.

Lemma reff380_not3474 : ~ @Equation3474 Fin3 reff380_inst.
Proof. unfold Equation3474. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff380_inst, reff380_op in H. discriminate H. Qed.

Lemma reff380_not3475 : ~ @Equation3475 Fin3 reff380_inst.
Proof. unfold Equation3475. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff380_inst, reff380_op in H. discriminate H. Qed.

Lemma reff380_not3481 : ~ @Equation3481 Fin3 reff380_inst.
Proof. unfold Equation3481. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff380_inst, reff380_op in H. discriminate H. Qed.

Lemma reff380_not3482 : ~ @Equation3482 Fin3 reff380_inst.
Proof. unfold Equation3482. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff380_inst, reff380_op in H. discriminate H. Qed.

Lemma reff380_not3484 : ~ @Equation3484 Fin3 reff380_inst.
Proof. unfold Equation3484. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff380_inst, reff380_op in H. discriminate H. Qed.

Lemma reff380_not3509 : ~ @Equation3509 Fin3 reff380_inst.
Proof. unfold Equation3509. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff380_inst, reff380_op in H. discriminate H. Qed.

Lemma reff380_not3511 : ~ @Equation3511 Fin3 reff380_inst.
Proof. unfold Equation3511. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff380_inst, reff380_op in H. discriminate H. Qed.

Lemma reff380_not3512 : ~ @Equation3512 Fin3 reff380_inst.
Proof. unfold Equation3512. intro H. specialize (H F3_1 F3_2). unfold magma_op, reff380_inst, reff380_op in H. discriminate H. Qed.

Lemma reff380_not3518 : ~ @Equation3518 Fin3 reff380_inst.
Proof. unfold Equation3518. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff380_inst, reff380_op in H. discriminate H. Qed.

Lemma reff380_not3519 : ~ @Equation3519 Fin3 reff380_inst.
Proof. unfold Equation3519. intro H. specialize (H F3_1 F3_2). unfold magma_op, reff380_inst, reff380_op in H. discriminate H. Qed.

Lemma reff380_not3521 : ~ @Equation3521 Fin3 reff380_inst.
Proof. unfold Equation3521. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff380_inst, reff380_op in H. discriminate H. Qed.

Lemma reff380_not3522 : ~ @Equation3522 Fin3 reff380_inst.
Proof. unfold Equation3522. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff380_inst, reff380_op in H. discriminate H. Qed.

Lemma reff380_not3545 : ~ @Equation3545 Fin3 reff380_inst.
Proof. unfold Equation3545. intro H. specialize (H F3_2 F3_0). unfold magma_op, reff380_inst, reff380_op in H. discriminate H. Qed.

Lemma reff380_not3546 : ~ @Equation3546 Fin3 reff380_inst.
Proof. unfold Equation3546. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff380_inst, reff380_op in H. discriminate H. Qed.

Lemma reff380_not3548 : ~ @Equation3548 Fin3 reff380_inst.
Proof. unfold Equation3548. intro H. specialize (H F3_2 F3_1). unfold magma_op, reff380_inst, reff380_op in H. discriminate H. Qed.

Lemma reff380_not3549 : ~ @Equation3549 Fin3 reff380_inst.
Proof. unfold Equation3549. intro H. specialize (H F3_1 F3_0). unfold magma_op, reff380_inst, reff380_op in H. discriminate H. Qed.

Lemma reff380_not3555 : ~ @Equation3555 Fin3 reff380_inst.
Proof. unfold Equation3555. intro H. specialize (H F3_2 F3_1). unfold magma_op, reff380_inst, reff380_op in H. discriminate H. Qed.

Lemma reff380_not3556 : ~ @Equation3556 Fin3 reff380_inst.
Proof. unfold Equation3556. intro H. specialize (H F3_1 F3_0). unfold magma_op, reff380_inst, reff380_op in H. discriminate H. Qed.

Lemma reff380_not3558 : ~ @Equation3558 Fin3 reff380_inst.
Proof. unfold Equation3558. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff380_inst, reff380_op in H. discriminate H. Qed.

Lemma reff380_not3659 : ~ @Equation3659 Fin3 reff380_inst.
Proof. unfold Equation3659. intro H. specialize (H F3_1). unfold magma_op, reff380_inst, reff380_op in H. discriminate H. Qed.

Lemma reff380_not3864 : ~ @Equation3864 Fin3 reff380_inst.
Proof. unfold Equation3864. intro H. specialize (H F3_1 F3_2). unfold magma_op, reff380_inst, reff380_op in H. discriminate H. Qed.

Lemma reff380_not3865 : ~ @Equation3865 Fin3 reff380_inst.
Proof. unfold Equation3865. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff380_inst, reff380_op in H. discriminate H. Qed.

Lemma reff380_not3867 : ~ @Equation3867 Fin3 reff380_inst.
Proof. unfold Equation3867. intro H. specialize (H F3_1 F3_2). unfold magma_op, reff380_inst, reff380_op in H. discriminate H. Qed.

Lemma reff380_not3868 : ~ @Equation3868 Fin3 reff380_inst.
Proof. unfold Equation3868. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff380_inst, reff380_op in H. discriminate H. Qed.

Lemma reff380_not3870 : ~ @Equation3870 Fin3 reff380_inst.
Proof. unfold Equation3870. intro H. specialize (H F3_1 F3_0). unfold magma_op, reff380_inst, reff380_op in H. discriminate H. Qed.

Lemma reff380_not3871 : ~ @Equation3871 Fin3 reff380_inst.
Proof. unfold Equation3871. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff380_inst, reff380_op in H. discriminate H. Qed.

Lemma reff380_not3878 : ~ @Equation3878 Fin3 reff380_inst.
Proof. unfold Equation3878. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff380_inst, reff380_op in H. discriminate H. Qed.

Lemma reff380_not3880 : ~ @Equation3880 Fin3 reff380_inst.
Proof. unfold Equation3880. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff380_inst, reff380_op in H. discriminate H. Qed.

Lemma reff380_not3881 : ~ @Equation3881 Fin3 reff380_inst.
Proof. unfold Equation3881. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff380_inst, reff380_op in H. discriminate H. Qed.

Lemma reff380_not3887 : ~ @Equation3887 Fin3 reff380_inst.
Proof. unfold Equation3887. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff380_inst, reff380_op in H. discriminate H. Qed.

Lemma reff380_not3888 : ~ @Equation3888 Fin3 reff380_inst.
Proof. unfold Equation3888. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff380_inst, reff380_op in H. discriminate H. Qed.

Lemma reff380_not3890 : ~ @Equation3890 Fin3 reff380_inst.
Proof. unfold Equation3890. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff380_inst, reff380_op in H. discriminate H. Qed.

Lemma reff380_not3915 : ~ @Equation3915 Fin3 reff380_inst.
Proof. unfold Equation3915. intro H. specialize (H F3_2 F3_0). unfold magma_op, reff380_inst, reff380_op in H. discriminate H. Qed.

Lemma reff380_not3917 : ~ @Equation3917 Fin3 reff380_inst.
Proof. unfold Equation3917. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff380_inst, reff380_op in H. discriminate H. Qed.

Lemma reff380_not3918 : ~ @Equation3918 Fin3 reff380_inst.
Proof. unfold Equation3918. intro H. specialize (H F3_2 F3_1). unfold magma_op, reff380_inst, reff380_op in H. discriminate H. Qed.

Lemma reff380_not3924 : ~ @Equation3924 Fin3 reff380_inst.
Proof. unfold Equation3924. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff380_inst, reff380_op in H. discriminate H. Qed.

Lemma reff380_not3925 : ~ @Equation3925 Fin3 reff380_inst.
Proof. unfold Equation3925. intro H. specialize (H F3_2 F3_1). unfold magma_op, reff380_inst, reff380_op in H. discriminate H. Qed.

Lemma reff380_not3927 : ~ @Equation3927 Fin3 reff380_inst.
Proof. unfold Equation3927. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff380_inst, reff380_op in H. discriminate H. Qed.

Lemma reff380_not3928 : ~ @Equation3928 Fin3 reff380_inst.
Proof. unfold Equation3928. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff380_inst, reff380_op in H. discriminate H. Qed.

Lemma reff380_not3951 : ~ @Equation3951 Fin3 reff380_inst.
Proof. unfold Equation3951. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff380_inst, reff380_op in H. discriminate H. Qed.

Lemma reff380_not3952 : ~ @Equation3952 Fin3 reff380_inst.
Proof. unfold Equation3952. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff380_inst, reff380_op in H. discriminate H. Qed.

Lemma reff380_not3954 : ~ @Equation3954 Fin3 reff380_inst.
Proof. unfold Equation3954. intro H. specialize (H F3_1 F3_2). unfold magma_op, reff380_inst, reff380_op in H. discriminate H. Qed.

Lemma reff380_not3955 : ~ @Equation3955 Fin3 reff380_inst.
Proof. unfold Equation3955. intro H. specialize (H F3_1 F3_0). unfold magma_op, reff380_inst, reff380_op in H. discriminate H. Qed.

Lemma reff380_not3961 : ~ @Equation3961 Fin3 reff380_inst.
Proof. unfold Equation3961. intro H. specialize (H F3_1 F3_2). unfold magma_op, reff380_inst, reff380_op in H. discriminate H. Qed.

Lemma reff380_not3962 : ~ @Equation3962 Fin3 reff380_inst.
Proof. unfold Equation3962. intro H. specialize (H F3_1 F3_0). unfold magma_op, reff380_inst, reff380_op in H. discriminate H. Qed.

Lemma reff380_not3964 : ~ @Equation3964 Fin3 reff380_inst.
Proof. unfold Equation3964. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff380_inst, reff380_op in H. discriminate H. Qed.

Lemma reff380_not4066 : ~ @Equation4066 Fin3 reff380_inst.
Proof. unfold Equation4066. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff380_inst, reff380_op in H. discriminate H. Qed.

Lemma reff380_not4068 : ~ @Equation4068 Fin3 reff380_inst.
Proof. unfold Equation4068. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff380_inst, reff380_op in H. discriminate H. Qed.

Lemma reff380_not4070 : ~ @Equation4070 Fin3 reff380_inst.
Proof. unfold Equation4070. intro H. specialize (H F3_1 F3_2). unfold magma_op, reff380_inst, reff380_op in H. discriminate H. Qed.

Lemma reff380_not4071 : ~ @Equation4071 Fin3 reff380_inst.
Proof. unfold Equation4071. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff380_inst, reff380_op in H. discriminate H. Qed.

Lemma reff380_not4073 : ~ @Equation4073 Fin3 reff380_inst.
Proof. unfold Equation4073. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff380_inst, reff380_op in H. discriminate H. Qed.

Lemma reff380_not4074 : ~ @Equation4074 Fin3 reff380_inst.
Proof. unfold Equation4074. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff380_inst, reff380_op in H. discriminate H. Qed.

Lemma reff380_not4080 : ~ @Equation4080 Fin3 reff380_inst.
Proof. unfold Equation4080. intro H. specialize (H F3_1 F3_2). unfold magma_op, reff380_inst, reff380_op in H. discriminate H. Qed.

Lemma reff380_not4083 : ~ @Equation4083 Fin3 reff380_inst.
Proof. unfold Equation4083. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff380_inst, reff380_op in H. discriminate H. Qed.

Lemma reff380_not4084 : ~ @Equation4084 Fin3 reff380_inst.
Proof. unfold Equation4084. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff380_inst, reff380_op in H. discriminate H. Qed.

Lemma reff380_not4090 : ~ @Equation4090 Fin3 reff380_inst.
Proof. unfold Equation4090. intro H. specialize (H F3_1 F3_0). unfold magma_op, reff380_inst, reff380_op in H. discriminate H. Qed.

Lemma reff380_not4091 : ~ @Equation4091 Fin3 reff380_inst.
Proof. unfold Equation4091. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff380_inst, reff380_op in H. discriminate H. Qed.

Lemma reff380_not4093 : ~ @Equation4093 Fin3 reff380_inst.
Proof. unfold Equation4093. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff380_inst, reff380_op in H. discriminate H. Qed.

Lemma reff380_not4118 : ~ @Equation4118 Fin3 reff380_inst.
Proof. unfold Equation4118. intro H. specialize (H F3_2 F3_0). unfold magma_op, reff380_inst, reff380_op in H. discriminate H. Qed.

Lemma reff380_not4120 : ~ @Equation4120 Fin3 reff380_inst.
Proof. unfold Equation4120. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff380_inst, reff380_op in H. discriminate H. Qed.

Lemma reff380_not4121 : ~ @Equation4121 Fin3 reff380_inst.
Proof. unfold Equation4121. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff380_inst, reff380_op in H. discriminate H. Qed.

Lemma reff380_not4127 : ~ @Equation4127 Fin3 reff380_inst.
Proof. unfold Equation4127. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff380_inst, reff380_op in H. discriminate H. Qed.

Lemma reff380_not4128 : ~ @Equation4128 Fin3 reff380_inst.
Proof. unfold Equation4128. intro H. specialize (H F3_2 F3_1). unfold magma_op, reff380_inst, reff380_op in H. discriminate H. Qed.

Lemma reff380_not4130 : ~ @Equation4130 Fin3 reff380_inst.
Proof. unfold Equation4130. intro H. specialize (H F3_1 F3_2). unfold magma_op, reff380_inst, reff380_op in H. discriminate H. Qed.

Lemma reff380_not4131 : ~ @Equation4131 Fin3 reff380_inst.
Proof. unfold Equation4131. intro H. specialize (H F3_1 F3_0). unfold magma_op, reff380_inst, reff380_op in H. discriminate H. Qed.

Lemma reff380_not4154 : ~ @Equation4154 Fin3 reff380_inst.
Proof. unfold Equation4154. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff380_inst, reff380_op in H. discriminate H. Qed.

Lemma reff380_not4155 : ~ @Equation4155 Fin3 reff380_inst.
Proof. unfold Equation4155. intro H. specialize (H F3_2 F3_1). unfold magma_op, reff380_inst, reff380_op in H. discriminate H. Qed.

Lemma reff380_not4157 : ~ @Equation4157 Fin3 reff380_inst.
Proof. unfold Equation4157. intro H. specialize (H F3_1 F3_2). unfold magma_op, reff380_inst, reff380_op in H. discriminate H. Qed.

Lemma reff380_not4158 : ~ @Equation4158 Fin3 reff380_inst.
Proof. unfold Equation4158. intro H. specialize (H F3_1 F3_0). unfold magma_op, reff380_inst, reff380_op in H. discriminate H. Qed.

Lemma reff380_not4164 : ~ @Equation4164 Fin3 reff380_inst.
Proof. unfold Equation4164. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff380_inst, reff380_op in H. discriminate H. Qed.

Lemma reff380_not4165 : ~ @Equation4165 Fin3 reff380_inst.
Proof. unfold Equation4165. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff380_inst, reff380_op in H. discriminate H. Qed.

Lemma reff380_not4167 : ~ @Equation4167 Fin3 reff380_inst.
Proof. unfold Equation4167. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff380_inst, reff380_op in H. discriminate H. Qed.

Lemma reff380_not4268 : ~ @Equation4268 Fin3 reff380_inst.
Proof. unfold Equation4268. intro H. specialize (H F3_1 F3_2). unfold magma_op, reff380_inst, reff380_op in H. discriminate H. Qed.

Lemma reff380_not4269 : ~ @Equation4269 Fin3 reff380_inst.
Proof. unfold Equation4269. intro H. specialize (H F3_1 F3_2). unfold magma_op, reff380_inst, reff380_op in H. discriminate H. Qed.

Lemma reff380_not4270 : ~ @Equation4270 Fin3 reff380_inst.
Proof. unfold Equation4270. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff380_inst, reff380_op in H. discriminate H. Qed.

Lemma reff380_not4272 : ~ @Equation4272 Fin3 reff380_inst.
Proof. unfold Equation4272. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff380_inst, reff380_op in H. discriminate H. Qed.

Lemma reff380_not4273 : ~ @Equation4273 Fin3 reff380_inst.
Proof. unfold Equation4273. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff380_inst, reff380_op in H. discriminate H. Qed.

Lemma reff380_not4275 : ~ @Equation4275 Fin3 reff380_inst.
Proof. unfold Equation4275. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff380_inst, reff380_op in H. discriminate H. Qed.

Lemma reff380_not4276 : ~ @Equation4276 Fin3 reff380_inst.
Proof. unfold Equation4276. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff380_inst, reff380_op in H. discriminate H. Qed.

Lemma reff380_not4284 : ~ @Equation4284 Fin3 reff380_inst.
Proof. unfold Equation4284. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff380_inst, reff380_op in H. discriminate H. Qed.

Lemma reff380_not4290 : ~ @Equation4290 Fin3 reff380_inst.
Proof. unfold Equation4290. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff380_inst, reff380_op in H. discriminate H. Qed.

Lemma reff380_not4291 : ~ @Equation4291 Fin3 reff380_inst.
Proof. unfold Equation4291. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff380_inst, reff380_op in H. discriminate H. Qed.

Lemma reff380_not4293 : ~ @Equation4293 Fin3 reff380_inst.
Proof. unfold Equation4293. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff380_inst, reff380_op in H. discriminate H. Qed.

Lemma reff380_not4314 : ~ @Equation4314 Fin3 reff380_inst.
Proof. unfold Equation4314. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff380_inst, reff380_op in H. discriminate H. Qed.

Lemma reff380_not4320 : ~ @Equation4320 Fin3 reff380_inst.
Proof. unfold Equation4320. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff380_inst, reff380_op in H. discriminate H. Qed.

Lemma reff380_not4321 : ~ @Equation4321 Fin3 reff380_inst.
Proof. unfold Equation4321. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff380_inst, reff380_op in H. discriminate H. Qed.

Lemma reff380_not4343 : ~ @Equation4343 Fin3 reff380_inst.
Proof. unfold Equation4343. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff380_inst, reff380_op in H. discriminate H. Qed.

Lemma reff380_not4396 : ~ @Equation4396 Fin3 reff380_inst.
Proof. unfold Equation4396. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff380_inst, reff380_op in H. discriminate H. Qed.

Lemma reff380_not4399 : ~ @Equation4399 Fin3 reff380_inst.
Proof. unfold Equation4399. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff380_inst, reff380_op in H. discriminate H. Qed.

Lemma reff380_not4406 : ~ @Equation4406 Fin3 reff380_inst.
Proof. unfold Equation4406. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff380_inst, reff380_op in H. discriminate H. Qed.

Lemma reff380_not4408 : ~ @Equation4408 Fin3 reff380_inst.
Proof. unfold Equation4408. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff380_inst, reff380_op in H. discriminate H. Qed.

Lemma reff380_not4433 : ~ @Equation4433 Fin3 reff380_inst.
Proof. unfold Equation4433. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff380_inst, reff380_op in H. discriminate H. Qed.

Lemma reff380_not4436 : ~ @Equation4436 Fin3 reff380_inst.
Proof. unfold Equation4436. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff380_inst, reff380_op in H. discriminate H. Qed.

Lemma reff380_not4443 : ~ @Equation4443 Fin3 reff380_inst.
Proof. unfold Equation4443. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff380_inst, reff380_op in H. discriminate H. Qed.

Lemma reff380_not4445 : ~ @Equation4445 Fin3 reff380_inst.
Proof. unfold Equation4445. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff380_inst, reff380_op in H. discriminate H. Qed.

Lemma reff380_not4470 : ~ @Equation4470 Fin3 reff380_inst.
Proof. unfold Equation4470. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff380_inst, reff380_op in H. discriminate H. Qed.

Lemma reff380_not4472 : ~ @Equation4472 Fin3 reff380_inst.
Proof. unfold Equation4472. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff380_inst, reff380_op in H. discriminate H. Qed.

Lemma reff380_not4473 : ~ @Equation4473 Fin3 reff380_inst.
Proof. unfold Equation4473. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff380_inst, reff380_op in H. discriminate H. Qed.

Lemma reff380_not4479 : ~ @Equation4479 Fin3 reff380_inst.
Proof. unfold Equation4479. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff380_inst, reff380_op in H. discriminate H. Qed.

Lemma reff380_not4480 : ~ @Equation4480 Fin3 reff380_inst.
Proof. unfold Equation4480. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff380_inst, reff380_op in H. discriminate H. Qed.

Lemma reff380_not4583 : ~ @Equation4583 Fin3 reff380_inst.
Proof. unfold Equation4583. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff380_inst, reff380_op in H. discriminate H. Qed.

Lemma reff380_not4584 : ~ @Equation4584 Fin3 reff380_inst.
Proof. unfold Equation4584. intro H. specialize (H F3_1 F3_2). unfold magma_op, reff380_inst, reff380_op in H. discriminate H. Qed.

Lemma reff380_not4585 : ~ @Equation4585 Fin3 reff380_inst.
Proof. unfold Equation4585. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff380_inst, reff380_op in H. discriminate H. Qed.

Lemma reff380_not4587 : ~ @Equation4587 Fin3 reff380_inst.
Proof. unfold Equation4587. intro H. specialize (H F3_1 F3_2). unfold magma_op, reff380_inst, reff380_op in H. discriminate H. Qed.

Lemma reff380_not4588 : ~ @Equation4588 Fin3 reff380_inst.
Proof. unfold Equation4588. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff380_inst, reff380_op in H. discriminate H. Qed.

Lemma reff380_not4590 : ~ @Equation4590 Fin3 reff380_inst.
Proof. unfold Equation4590. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff380_inst, reff380_op in H. discriminate H. Qed.

Lemma reff380_not4591 : ~ @Equation4591 Fin3 reff380_inst.
Proof. unfold Equation4591. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff380_inst, reff380_op in H. discriminate H. Qed.

Lemma reff380_not4598 : ~ @Equation4598 Fin3 reff380_inst.
Proof. unfold Equation4598. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff380_inst, reff380_op in H. discriminate H. Qed.

Lemma reff380_not4599 : ~ @Equation4599 Fin3 reff380_inst.
Proof. unfold Equation4599. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff380_inst, reff380_op in H. discriminate H. Qed.

Lemma reff380_not4605 : ~ @Equation4605 Fin3 reff380_inst.
Proof. unfold Equation4605. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff380_inst, reff380_op in H. discriminate H. Qed.

Lemma reff380_not4606 : ~ @Equation4606 Fin3 reff380_inst.
Proof. unfold Equation4606. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff380_inst, reff380_op in H. discriminate H. Qed.

Lemma reff380_not4608 : ~ @Equation4608 Fin3 reff380_inst.
Proof. unfold Equation4608. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff380_inst, reff380_op in H. discriminate H. Qed.

Lemma reff380_not4629 : ~ @Equation4629 Fin3 reff380_inst.
Proof. unfold Equation4629. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff380_inst, reff380_op in H. discriminate H. Qed.

Lemma reff380_not4636 : ~ @Equation4636 Fin3 reff380_inst.
Proof. unfold Equation4636. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff380_inst, reff380_op in H. discriminate H. Qed.

Lemma reff380_not4658 : ~ @Equation4658 Fin3 reff380_inst.
Proof. unfold Equation4658. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff380_inst, reff380_op in H. discriminate H. Qed.

(** ---- reff386 (Fin4) ---- *)

Definition reff386_op (x y : Fin4) : Fin4 :=
  match x, y with
  | F4_0, F4_0 => F4_0 | F4_0, F4_1 => F4_2 | F4_0, F4_2 => F4_0 | F4_0, F4_3 => F4_2
  | F4_1, F4_0 => F4_2 | F4_1, F4_1 => F4_2 | F4_1, F4_2 => F4_2 | F4_1, F4_3 => F4_2
  | F4_2, F4_0 => F4_2 | F4_2, F4_1 => F4_0 | F4_2, F4_2 => F4_2 | F4_2, F4_3 => F4_0
  | F4_3, F4_0 => F4_0 | F4_3, F4_1 => F4_0 | F4_3, F4_2 => F4_0 | F4_3, F4_3 => F4_0
  end.

#[local] Instance reff386_inst : Magma Fin4 := {| magma_op := reff386_op |}.

Lemma reff386_sat311 : @Equation311 Fin4 reff386_inst.
Proof. unfold Equation311, magma_op, reff386_inst, reff386_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff386_sat3730 : @Equation3730 Fin4 reff386_inst.
Proof. unfold Equation3730, magma_op, reff386_inst, reff386_op. intros x y z w. destruct x, y, z, w; reflexivity. Qed.

Lemma reff386_sat4135 : @Equation4135 Fin4 reff386_inst.
Proof. unfold Equation4135, magma_op, reff386_inst, reff386_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff386_not47 : ~ @Equation47 Fin4 reff386_inst.
Proof. unfold Equation47. intro H. specialize (H F4_1). unfold magma_op, reff386_inst, reff386_op in H. discriminate H. Qed.

Lemma reff386_not99 : ~ @Equation99 Fin4 reff386_inst.
Proof. unfold Equation99. intro H. specialize (H F4_1). unfold magma_op, reff386_inst, reff386_op in H. discriminate H. Qed.

Lemma reff386_not151 : ~ @Equation151 Fin4 reff386_inst.
Proof. unfold Equation151. intro H. specialize (H F4_1). unfold magma_op, reff386_inst, reff386_op in H. discriminate H. Qed.

Lemma reff386_not203 : ~ @Equation203 Fin4 reff386_inst.
Proof. unfold Equation203. intro H. specialize (H F4_1). unfold magma_op, reff386_inst, reff386_op in H. discriminate H. Qed.

Lemma reff386_not255 : ~ @Equation255 Fin4 reff386_inst.
Proof. unfold Equation255. intro H. specialize (H F4_1). unfold magma_op, reff386_inst, reff386_op in H. discriminate H. Qed.

Lemma reff386_not359 : ~ @Equation359 Fin4 reff386_inst.
Proof. unfold Equation359. intro H. specialize (H F4_1). unfold magma_op, reff386_inst, reff386_op in H. discriminate H. Qed.

Lemma reff386_not411 : ~ @Equation411 Fin4 reff386_inst.
Proof. unfold Equation411. intro H. specialize (H F4_1). unfold magma_op, reff386_inst, reff386_op in H. discriminate H. Qed.

Lemma reff386_not614 : ~ @Equation614 Fin4 reff386_inst.
Proof. unfold Equation614. intro H. specialize (H F4_1). unfold magma_op, reff386_inst, reff386_op in H. discriminate H. Qed.

Lemma reff386_not817 : ~ @Equation817 Fin4 reff386_inst.
Proof. unfold Equation817. intro H. specialize (H F4_1). unfold magma_op, reff386_inst, reff386_op in H. discriminate H. Qed.

Lemma reff386_not1020 : ~ @Equation1020 Fin4 reff386_inst.
Proof. unfold Equation1020. intro H. specialize (H F4_1). unfold magma_op, reff386_inst, reff386_op in H. discriminate H. Qed.

Lemma reff386_not1223 : ~ @Equation1223 Fin4 reff386_inst.
Proof. unfold Equation1223. intro H. specialize (H F4_1). unfold magma_op, reff386_inst, reff386_op in H. discriminate H. Qed.

Lemma reff386_not1426 : ~ @Equation1426 Fin4 reff386_inst.
Proof. unfold Equation1426. intro H. specialize (H F4_1). unfold magma_op, reff386_inst, reff386_op in H. discriminate H. Qed.

Lemma reff386_not1629 : ~ @Equation1629 Fin4 reff386_inst.
Proof. unfold Equation1629. intro H. specialize (H F4_1). unfold magma_op, reff386_inst, reff386_op in H. discriminate H. Qed.

Lemma reff386_not1832 : ~ @Equation1832 Fin4 reff386_inst.
Proof. unfold Equation1832. intro H. specialize (H F4_1). unfold magma_op, reff386_inst, reff386_op in H. discriminate H. Qed.

Lemma reff386_not2035 : ~ @Equation2035 Fin4 reff386_inst.
Proof. unfold Equation2035. intro H. specialize (H F4_1). unfold magma_op, reff386_inst, reff386_op in H. discriminate H. Qed.

Lemma reff386_not2238 : ~ @Equation2238 Fin4 reff386_inst.
Proof. unfold Equation2238. intro H. specialize (H F4_1). unfold magma_op, reff386_inst, reff386_op in H. discriminate H. Qed.

Lemma reff386_not2441 : ~ @Equation2441 Fin4 reff386_inst.
Proof. unfold Equation2441. intro H. specialize (H F4_1). unfold magma_op, reff386_inst, reff386_op in H. discriminate H. Qed.

Lemma reff386_not2644 : ~ @Equation2644 Fin4 reff386_inst.
Proof. unfold Equation2644. intro H. specialize (H F4_1). unfold magma_op, reff386_inst, reff386_op in H. discriminate H. Qed.

Lemma reff386_not2847 : ~ @Equation2847 Fin4 reff386_inst.
Proof. unfold Equation2847. intro H. specialize (H F4_1). unfold magma_op, reff386_inst, reff386_op in H. discriminate H. Qed.

Lemma reff386_not3050 : ~ @Equation3050 Fin4 reff386_inst.
Proof. unfold Equation3050. intro H. specialize (H F4_1). unfold magma_op, reff386_inst, reff386_op in H. discriminate H. Qed.

Lemma reff386_not3268 : ~ @Equation3268 Fin4 reff386_inst.
Proof. unfold Equation3268. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff386_inst, reff386_op in H. discriminate H. Qed.

Lemma reff386_not3269 : ~ @Equation3269 Fin4 reff386_inst.
Proof. unfold Equation3269. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff386_inst, reff386_op in H. discriminate H. Qed.

Lemma reff386_not3271 : ~ @Equation3271 Fin4 reff386_inst.
Proof. unfold Equation3271. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff386_inst, reff386_op in H. discriminate H. Qed.

Lemma reff386_not3272 : ~ @Equation3272 Fin4 reff386_inst.
Proof. unfold Equation3272. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff386_inst, reff386_op in H. discriminate H. Qed.

Lemma reff386_not3278 : ~ @Equation3278 Fin4 reff386_inst.
Proof. unfold Equation3278. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff386_inst, reff386_op in H. discriminate H. Qed.

Lemma reff386_not3279 : ~ @Equation3279 Fin4 reff386_inst.
Proof. unfold Equation3279. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff386_inst, reff386_op in H. discriminate H. Qed.

Lemma reff386_not3281 : ~ @Equation3281 Fin4 reff386_inst.
Proof. unfold Equation3281. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff386_inst, reff386_op in H. discriminate H. Qed.

Lemma reff386_not3306 : ~ @Equation3306 Fin4 reff386_inst.
Proof. unfold Equation3306. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff386_inst, reff386_op in H. discriminate H. Qed.

Lemma reff386_not3308 : ~ @Equation3308 Fin4 reff386_inst.
Proof. unfold Equation3308. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff386_inst, reff386_op in H. discriminate H. Qed.

Lemma reff386_not3309 : ~ @Equation3309 Fin4 reff386_inst.
Proof. unfold Equation3309. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff386_inst, reff386_op in H. discriminate H. Qed.

Lemma reff386_not3315 : ~ @Equation3315 Fin4 reff386_inst.
Proof. unfold Equation3315. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff386_inst, reff386_op in H. discriminate H. Qed.

Lemma reff386_not3316 : ~ @Equation3316 Fin4 reff386_inst.
Proof. unfold Equation3316. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff386_inst, reff386_op in H. discriminate H. Qed.

Lemma reff386_not3318 : ~ @Equation3318 Fin4 reff386_inst.
Proof. unfold Equation3318. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff386_inst, reff386_op in H. discriminate H. Qed.

Lemma reff386_not3319 : ~ @Equation3319 Fin4 reff386_inst.
Proof. unfold Equation3319. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff386_inst, reff386_op in H. discriminate H. Qed.

Lemma reff386_not3342 : ~ @Equation3342 Fin4 reff386_inst.
Proof. unfold Equation3342. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff386_inst, reff386_op in H. discriminate H. Qed.

Lemma reff386_not3343 : ~ @Equation3343 Fin4 reff386_inst.
Proof. unfold Equation3343. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff386_inst, reff386_op in H. discriminate H. Qed.

Lemma reff386_not3345 : ~ @Equation3345 Fin4 reff386_inst.
Proof. unfold Equation3345. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff386_inst, reff386_op in H. discriminate H. Qed.

Lemma reff386_not3346 : ~ @Equation3346 Fin4 reff386_inst.
Proof. unfold Equation3346. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff386_inst, reff386_op in H. discriminate H. Qed.

Lemma reff386_not3352 : ~ @Equation3352 Fin4 reff386_inst.
Proof. unfold Equation3352. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff386_inst, reff386_op in H. discriminate H. Qed.

Lemma reff386_not3353 : ~ @Equation3353 Fin4 reff386_inst.
Proof. unfold Equation3353. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff386_inst, reff386_op in H. discriminate H. Qed.

Lemma reff386_not3472 : ~ @Equation3472 Fin4 reff386_inst.
Proof. unfold Equation3472. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff386_inst, reff386_op in H. discriminate H. Qed.

Lemma reff386_not3474 : ~ @Equation3474 Fin4 reff386_inst.
Proof. unfold Equation3474. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff386_inst, reff386_op in H. discriminate H. Qed.

Lemma reff386_not3475 : ~ @Equation3475 Fin4 reff386_inst.
Proof. unfold Equation3475. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff386_inst, reff386_op in H. discriminate H. Qed.

Lemma reff386_not3481 : ~ @Equation3481 Fin4 reff386_inst.
Proof. unfold Equation3481. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff386_inst, reff386_op in H. discriminate H. Qed.

Lemma reff386_not3482 : ~ @Equation3482 Fin4 reff386_inst.
Proof. unfold Equation3482. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff386_inst, reff386_op in H. discriminate H. Qed.

Lemma reff386_not3484 : ~ @Equation3484 Fin4 reff386_inst.
Proof. unfold Equation3484. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff386_inst, reff386_op in H. discriminate H. Qed.

Lemma reff386_not3509 : ~ @Equation3509 Fin4 reff386_inst.
Proof. unfold Equation3509. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff386_inst, reff386_op in H. discriminate H. Qed.

Lemma reff386_not3511 : ~ @Equation3511 Fin4 reff386_inst.
Proof. unfold Equation3511. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff386_inst, reff386_op in H. discriminate H. Qed.

Lemma reff386_not3512 : ~ @Equation3512 Fin4 reff386_inst.
Proof. unfold Equation3512. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff386_inst, reff386_op in H. discriminate H. Qed.

Lemma reff386_not3518 : ~ @Equation3518 Fin4 reff386_inst.
Proof. unfold Equation3518. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff386_inst, reff386_op in H. discriminate H. Qed.

Lemma reff386_not3519 : ~ @Equation3519 Fin4 reff386_inst.
Proof. unfold Equation3519. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff386_inst, reff386_op in H. discriminate H. Qed.

Lemma reff386_not3521 : ~ @Equation3521 Fin4 reff386_inst.
Proof. unfold Equation3521. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff386_inst, reff386_op in H. discriminate H. Qed.

Lemma reff386_not3522 : ~ @Equation3522 Fin4 reff386_inst.
Proof. unfold Equation3522. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff386_inst, reff386_op in H. discriminate H. Qed.

Lemma reff386_not3545 : ~ @Equation3545 Fin4 reff386_inst.
Proof. unfold Equation3545. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff386_inst, reff386_op in H. discriminate H. Qed.

Lemma reff386_not3546 : ~ @Equation3546 Fin4 reff386_inst.
Proof. unfold Equation3546. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff386_inst, reff386_op in H. discriminate H. Qed.

Lemma reff386_not3548 : ~ @Equation3548 Fin4 reff386_inst.
Proof. unfold Equation3548. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff386_inst, reff386_op in H. discriminate H. Qed.

Lemma reff386_not3549 : ~ @Equation3549 Fin4 reff386_inst.
Proof. unfold Equation3549. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff386_inst, reff386_op in H. discriminate H. Qed.

Lemma reff386_not3555 : ~ @Equation3555 Fin4 reff386_inst.
Proof. unfold Equation3555. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff386_inst, reff386_op in H. discriminate H. Qed.

Lemma reff386_not3556 : ~ @Equation3556 Fin4 reff386_inst.
Proof. unfold Equation3556. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff386_inst, reff386_op in H. discriminate H. Qed.

Lemma reff386_not3558 : ~ @Equation3558 Fin4 reff386_inst.
Proof. unfold Equation3558. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff386_inst, reff386_op in H. discriminate H. Qed.

Lemma reff386_not3664 : ~ @Equation3664 Fin4 reff386_inst.
Proof. unfold Equation3664. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff386_inst, reff386_op in H. discriminate H. Qed.

Lemma reff386_not3665 : ~ @Equation3665 Fin4 reff386_inst.
Proof. unfold Equation3665. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff386_inst, reff386_op in H. discriminate H. Qed.

Lemma reff386_not3667 : ~ @Equation3667 Fin4 reff386_inst.
Proof. unfold Equation3667. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff386_inst, reff386_op in H. discriminate H. Qed.

Lemma reff386_not3668 : ~ @Equation3668 Fin4 reff386_inst.
Proof. unfold Equation3668. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff386_inst, reff386_op in H. discriminate H. Qed.

Lemma reff386_not3674 : ~ @Equation3674 Fin4 reff386_inst.
Proof. unfold Equation3674. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff386_inst, reff386_op in H. discriminate H. Qed.

Lemma reff386_not3675 : ~ @Equation3675 Fin4 reff386_inst.
Proof. unfold Equation3675. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff386_inst, reff386_op in H. discriminate H. Qed.

Lemma reff386_not3677 : ~ @Equation3677 Fin4 reff386_inst.
Proof. unfold Equation3677. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff386_inst, reff386_op in H. discriminate H. Qed.

Lemma reff386_not3678 : ~ @Equation3678 Fin4 reff386_inst.
Proof. unfold Equation3678. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff386_inst, reff386_op in H. discriminate H. Qed.

Lemma reff386_not3684 : ~ @Equation3684 Fin4 reff386_inst.
Proof. unfold Equation3684. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff386_inst, reff386_op in H. discriminate H. Qed.

Lemma reff386_not3685 : ~ @Equation3685 Fin4 reff386_inst.
Proof. unfold Equation3685. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff386_inst, reff386_op in H. discriminate H. Qed.

Lemma reff386_not3687 : ~ @Equation3687 Fin4 reff386_inst.
Proof. unfold Equation3687. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff386_inst, reff386_op in H. discriminate H. Qed.

Lemma reff386_not3712 : ~ @Equation3712 Fin4 reff386_inst.
Proof. unfold Equation3712. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff386_inst, reff386_op in H. discriminate H. Qed.

Lemma reff386_not3714 : ~ @Equation3714 Fin4 reff386_inst.
Proof. unfold Equation3714. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff386_inst, reff386_op in H. discriminate H. Qed.

Lemma reff386_not3748 : ~ @Equation3748 Fin4 reff386_inst.
Proof. unfold Equation3748. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff386_inst, reff386_op in H. discriminate H. Qed.

Lemma reff386_not3749 : ~ @Equation3749 Fin4 reff386_inst.
Proof. unfold Equation3749. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff386_inst, reff386_op in H. discriminate H. Qed.

Lemma reff386_not3751 : ~ @Equation3751 Fin4 reff386_inst.
Proof. unfold Equation3751. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff386_inst, reff386_op in H. discriminate H. Qed.

Lemma reff386_not3752 : ~ @Equation3752 Fin4 reff386_inst.
Proof. unfold Equation3752. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff386_inst, reff386_op in H. discriminate H. Qed.

Lemma reff386_not3759 : ~ @Equation3759 Fin4 reff386_inst.
Proof. unfold Equation3759. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff386_inst, reff386_op in H. discriminate H. Qed.

Lemma reff386_not3761 : ~ @Equation3761 Fin4 reff386_inst.
Proof. unfold Equation3761. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff386_inst, reff386_op in H. discriminate H. Qed.

Lemma reff386_not3862 : ~ @Equation3862 Fin4 reff386_inst.
Proof. unfold Equation3862. intro H. specialize (H F4_1). unfold magma_op, reff386_inst, reff386_op in H. discriminate H. Qed.

Lemma reff386_not4066 : ~ @Equation4066 Fin4 reff386_inst.
Proof. unfold Equation4066. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff386_inst, reff386_op in H. discriminate H. Qed.

Lemma reff386_not4067 : ~ @Equation4067 Fin4 reff386_inst.
Proof. unfold Equation4067. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff386_inst, reff386_op in H. discriminate H. Qed.

Lemma reff386_not4070 : ~ @Equation4070 Fin4 reff386_inst.
Proof. unfold Equation4070. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff386_inst, reff386_op in H. discriminate H. Qed.

Lemma reff386_not4071 : ~ @Equation4071 Fin4 reff386_inst.
Proof. unfold Equation4071. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff386_inst, reff386_op in H. discriminate H. Qed.

Lemma reff386_not4073 : ~ @Equation4073 Fin4 reff386_inst.
Proof. unfold Equation4073. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff386_inst, reff386_op in H. discriminate H. Qed.

Lemma reff386_not4074 : ~ @Equation4074 Fin4 reff386_inst.
Proof. unfold Equation4074. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff386_inst, reff386_op in H. discriminate H. Qed.

Lemma reff386_not4080 : ~ @Equation4080 Fin4 reff386_inst.
Proof. unfold Equation4080. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff386_inst, reff386_op in H. discriminate H. Qed.

Lemma reff386_not4081 : ~ @Equation4081 Fin4 reff386_inst.
Proof. unfold Equation4081. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff386_inst, reff386_op in H. discriminate H. Qed.

Lemma reff386_not4083 : ~ @Equation4083 Fin4 reff386_inst.
Proof. unfold Equation4083. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff386_inst, reff386_op in H. discriminate H. Qed.

Lemma reff386_not4084 : ~ @Equation4084 Fin4 reff386_inst.
Proof. unfold Equation4084. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff386_inst, reff386_op in H. discriminate H. Qed.

Lemma reff386_not4090 : ~ @Equation4090 Fin4 reff386_inst.
Proof. unfold Equation4090. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff386_inst, reff386_op in H. discriminate H. Qed.

Lemma reff386_not4091 : ~ @Equation4091 Fin4 reff386_inst.
Proof. unfold Equation4091. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff386_inst, reff386_op in H. discriminate H. Qed.

Lemma reff386_not4093 : ~ @Equation4093 Fin4 reff386_inst.
Proof. unfold Equation4093. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff386_inst, reff386_op in H. discriminate H. Qed.

Lemma reff386_not4118 : ~ @Equation4118 Fin4 reff386_inst.
Proof. unfold Equation4118. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff386_inst, reff386_op in H. discriminate H. Qed.

Lemma reff386_not4120 : ~ @Equation4120 Fin4 reff386_inst.
Proof. unfold Equation4120. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff386_inst, reff386_op in H. discriminate H. Qed.

Lemma reff386_not4121 : ~ @Equation4121 Fin4 reff386_inst.
Proof. unfold Equation4121. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff386_inst, reff386_op in H. discriminate H. Qed.

Lemma reff386_not4128 : ~ @Equation4128 Fin4 reff386_inst.
Proof. unfold Equation4128. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff386_inst, reff386_op in H. discriminate H. Qed.

Lemma reff386_not4130 : ~ @Equation4130 Fin4 reff386_inst.
Proof. unfold Equation4130. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff386_inst, reff386_op in H. discriminate H. Qed.

Lemma reff386_not4155 : ~ @Equation4155 Fin4 reff386_inst.
Proof. unfold Equation4155. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff386_inst, reff386_op in H. discriminate H. Qed.

Lemma reff386_not4157 : ~ @Equation4157 Fin4 reff386_inst.
Proof. unfold Equation4157. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff386_inst, reff386_op in H. discriminate H. Qed.

Lemma reff386_not4158 : ~ @Equation4158 Fin4 reff386_inst.
Proof. unfold Equation4158. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff386_inst, reff386_op in H. discriminate H. Qed.

Lemma reff386_not4164 : ~ @Equation4164 Fin4 reff386_inst.
Proof. unfold Equation4164. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff386_inst, reff386_op in H. discriminate H. Qed.

Lemma reff386_not4165 : ~ @Equation4165 Fin4 reff386_inst.
Proof. unfold Equation4165. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff386_inst, reff386_op in H. discriminate H. Qed.

Lemma reff386_not4167 : ~ @Equation4167 Fin4 reff386_inst.
Proof. unfold Equation4167. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff386_inst, reff386_op in H. discriminate H. Qed.

Lemma reff386_not4272 : ~ @Equation4272 Fin4 reff386_inst.
Proof. unfold Equation4272. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff386_inst, reff386_op in H. discriminate H. Qed.

Lemma reff386_not4273 : ~ @Equation4273 Fin4 reff386_inst.
Proof. unfold Equation4273. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff386_inst, reff386_op in H. discriminate H. Qed.

Lemma reff386_not4275 : ~ @Equation4275 Fin4 reff386_inst.
Proof. unfold Equation4275. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff386_inst, reff386_op in H. discriminate H. Qed.

Lemma reff386_not4276 : ~ @Equation4276 Fin4 reff386_inst.
Proof. unfold Equation4276. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff386_inst, reff386_op in H. discriminate H. Qed.

Lemma reff386_not4290 : ~ @Equation4290 Fin4 reff386_inst.
Proof. unfold Equation4290. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff386_inst, reff386_op in H. discriminate H. Qed.

Lemma reff386_not4291 : ~ @Equation4291 Fin4 reff386_inst.
Proof. unfold Equation4291. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff386_inst, reff386_op in H. discriminate H. Qed.

Lemma reff386_not4293 : ~ @Equation4293 Fin4 reff386_inst.
Proof. unfold Equation4293. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff386_inst, reff386_op in H. discriminate H. Qed.

Lemma reff386_not4320 : ~ @Equation4320 Fin4 reff386_inst.
Proof. unfold Equation4320. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff386_inst, reff386_op in H. discriminate H. Qed.

Lemma reff386_not4321 : ~ @Equation4321 Fin4 reff386_inst.
Proof. unfold Equation4321. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff386_inst, reff386_op in H. discriminate H. Qed.

Lemma reff386_not4343 : ~ @Equation4343 Fin4 reff386_inst.
Proof. unfold Equation4343. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff386_inst, reff386_op in H. discriminate H. Qed.

Lemma reff386_not4380 : ~ @Equation4380 Fin4 reff386_inst.
Proof. unfold Equation4380. intro H. specialize (H F4_1). unfold magma_op, reff386_inst, reff386_op in H. discriminate H. Qed.

Lemma reff386_not4583 : ~ @Equation4583 Fin4 reff386_inst.
Proof. unfold Equation4583. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff386_inst, reff386_op in H. discriminate H. Qed.

Lemma reff386_not4584 : ~ @Equation4584 Fin4 reff386_inst.
Proof. unfold Equation4584. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff386_inst, reff386_op in H. discriminate H. Qed.

Lemma reff386_not4585 : ~ @Equation4585 Fin4 reff386_inst.
Proof. unfold Equation4585. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff386_inst, reff386_op in H. discriminate H. Qed.

Lemma reff386_not4587 : ~ @Equation4587 Fin4 reff386_inst.
Proof. unfold Equation4587. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff386_inst, reff386_op in H. discriminate H. Qed.

Lemma reff386_not4588 : ~ @Equation4588 Fin4 reff386_inst.
Proof. unfold Equation4588. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff386_inst, reff386_op in H. discriminate H. Qed.

Lemma reff386_not4590 : ~ @Equation4590 Fin4 reff386_inst.
Proof. unfold Equation4590. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff386_inst, reff386_op in H. discriminate H. Qed.

Lemma reff386_not4591 : ~ @Equation4591 Fin4 reff386_inst.
Proof. unfold Equation4591. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff386_inst, reff386_op in H. discriminate H. Qed.

Lemma reff386_not4598 : ~ @Equation4598 Fin4 reff386_inst.
Proof. unfold Equation4598. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff386_inst, reff386_op in H. discriminate H. Qed.

Lemma reff386_not4599 : ~ @Equation4599 Fin4 reff386_inst.
Proof. unfold Equation4599. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff386_inst, reff386_op in H. discriminate H. Qed.

Lemma reff386_not4605 : ~ @Equation4605 Fin4 reff386_inst.
Proof. unfold Equation4605. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff386_inst, reff386_op in H. discriminate H. Qed.

Lemma reff386_not4606 : ~ @Equation4606 Fin4 reff386_inst.
Proof. unfold Equation4606. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff386_inst, reff386_op in H. discriminate H. Qed.

Lemma reff386_not4608 : ~ @Equation4608 Fin4 reff386_inst.
Proof. unfold Equation4608. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff386_inst, reff386_op in H. discriminate H. Qed.

Lemma reff386_not4629 : ~ @Equation4629 Fin4 reff386_inst.
Proof. unfold Equation4629. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff386_inst, reff386_op in H. discriminate H. Qed.

Lemma reff386_not4635 : ~ @Equation4635 Fin4 reff386_inst.
Proof. unfold Equation4635. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff386_inst, reff386_op in H. discriminate H. Qed.

Lemma reff386_not4636 : ~ @Equation4636 Fin4 reff386_inst.
Proof. unfold Equation4636. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff386_inst, reff386_op in H. discriminate H. Qed.

Lemma reff386_not4658 : ~ @Equation4658 Fin4 reff386_inst.
Proof. unfold Equation4658. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff386_inst, reff386_op in H. discriminate H. Qed.

(** ---- reff388 (Fin4) ---- *)

Definition reff388_op (x y : Fin4) : Fin4 :=
  match x, y with
  | F4_0, F4_0 => F4_0 | F4_0, F4_1 => F4_1 | F4_0, F4_2 => F4_2 | F4_0, F4_3 => F4_3
  | F4_1, F4_0 => F4_1 | F4_1, F4_1 => F4_2 | F4_1, F4_2 => F4_3 | F4_1, F4_3 => F4_0
  | F4_2, F4_0 => F4_2 | F4_2, F4_1 => F4_3 | F4_2, F4_2 => F4_0 | F4_2, F4_3 => F4_1
  | F4_3, F4_0 => F4_3 | F4_3, F4_1 => F4_0 | F4_3, F4_2 => F4_1 | F4_3, F4_3 => F4_2
  end.

#[local] Instance reff388_inst : Magma Fin4 := {| magma_op := reff388_op |}.

Lemma reff388_sat43 : @Equation43 Fin4 reff388_inst.
Proof. unfold Equation43, magma_op, reff388_inst, reff388_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff388_sat440 : @Equation440 Fin4 reff388_inst.
Proof. unfold Equation440, magma_op, reff388_inst, reff388_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff388_sat477 : @Equation477 Fin4 reff388_inst.
Proof. unfold Equation477, magma_op, reff388_inst, reff388_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff388_sat504 : @Equation504 Fin4 reff388_inst.
Proof. unfold Equation504, magma_op, reff388_inst, reff388_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff388_sat511 : @Equation511 Fin4 reff388_inst.
Proof. unfold Equation511, magma_op, reff388_inst, reff388_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff388_sat513 : @Equation513 Fin4 reff388_inst.
Proof. unfold Equation513, magma_op, reff388_inst, reff388_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff388_sat643 : @Equation643 Fin4 reff388_inst.
Proof. unfold Equation643, magma_op, reff388_inst, reff388_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff388_sat680 : @Equation680 Fin4 reff388_inst.
Proof. unfold Equation680, magma_op, reff388_inst, reff388_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff388_sat707 : @Equation707 Fin4 reff388_inst.
Proof. unfold Equation707, magma_op, reff388_inst, reff388_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff388_sat714 : @Equation714 Fin4 reff388_inst.
Proof. unfold Equation714, magma_op, reff388_inst, reff388_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff388_sat716 : @Equation716 Fin4 reff388_inst.
Proof. unfold Equation716, magma_op, reff388_inst, reff388_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff388_sat846 : @Equation846 Fin4 reff388_inst.
Proof. unfold Equation846, magma_op, reff388_inst, reff388_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff388_sat883 : @Equation883 Fin4 reff388_inst.
Proof. unfold Equation883, magma_op, reff388_inst, reff388_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff388_sat910 : @Equation910 Fin4 reff388_inst.
Proof. unfold Equation910, magma_op, reff388_inst, reff388_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff388_sat917 : @Equation917 Fin4 reff388_inst.
Proof. unfold Equation917, magma_op, reff388_inst, reff388_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff388_sat919 : @Equation919 Fin4 reff388_inst.
Proof. unfold Equation919, magma_op, reff388_inst, reff388_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff388_sat1049 : @Equation1049 Fin4 reff388_inst.
Proof. unfold Equation1049, magma_op, reff388_inst, reff388_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff388_sat1086 : @Equation1086 Fin4 reff388_inst.
Proof. unfold Equation1086, magma_op, reff388_inst, reff388_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff388_sat1113 : @Equation1113 Fin4 reff388_inst.
Proof. unfold Equation1113, magma_op, reff388_inst, reff388_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff388_sat1120 : @Equation1120 Fin4 reff388_inst.
Proof. unfold Equation1120, magma_op, reff388_inst, reff388_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff388_sat1122 : @Equation1122 Fin4 reff388_inst.
Proof. unfold Equation1122, magma_op, reff388_inst, reff388_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff388_sat1252 : @Equation1252 Fin4 reff388_inst.
Proof. unfold Equation1252, magma_op, reff388_inst, reff388_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff388_sat1289 : @Equation1289 Fin4 reff388_inst.
Proof. unfold Equation1289, magma_op, reff388_inst, reff388_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff388_sat1316 : @Equation1316 Fin4 reff388_inst.
Proof. unfold Equation1316, magma_op, reff388_inst, reff388_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff388_sat1323 : @Equation1323 Fin4 reff388_inst.
Proof. unfold Equation1323, magma_op, reff388_inst, reff388_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff388_sat1325 : @Equation1325 Fin4 reff388_inst.
Proof. unfold Equation1325, magma_op, reff388_inst, reff388_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff388_sat1455 : @Equation1455 Fin4 reff388_inst.
Proof. unfold Equation1455, magma_op, reff388_inst, reff388_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff388_sat1492 : @Equation1492 Fin4 reff388_inst.
Proof. unfold Equation1492, magma_op, reff388_inst, reff388_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff388_sat1519 : @Equation1519 Fin4 reff388_inst.
Proof. unfold Equation1519, magma_op, reff388_inst, reff388_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff388_sat1526 : @Equation1526 Fin4 reff388_inst.
Proof. unfold Equation1526, magma_op, reff388_inst, reff388_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff388_sat1528 : @Equation1528 Fin4 reff388_inst.
Proof. unfold Equation1528, magma_op, reff388_inst, reff388_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff388_sat1658 : @Equation1658 Fin4 reff388_inst.
Proof. unfold Equation1658, magma_op, reff388_inst, reff388_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff388_sat1695 : @Equation1695 Fin4 reff388_inst.
Proof. unfold Equation1695, magma_op, reff388_inst, reff388_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff388_sat1722 : @Equation1722 Fin4 reff388_inst.
Proof. unfold Equation1722, magma_op, reff388_inst, reff388_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff388_sat1729 : @Equation1729 Fin4 reff388_inst.
Proof. unfold Equation1729, magma_op, reff388_inst, reff388_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff388_sat1731 : @Equation1731 Fin4 reff388_inst.
Proof. unfold Equation1731, magma_op, reff388_inst, reff388_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff388_sat1861 : @Equation1861 Fin4 reff388_inst.
Proof. unfold Equation1861, magma_op, reff388_inst, reff388_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff388_sat1898 : @Equation1898 Fin4 reff388_inst.
Proof. unfold Equation1898, magma_op, reff388_inst, reff388_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff388_sat1925 : @Equation1925 Fin4 reff388_inst.
Proof. unfold Equation1925, magma_op, reff388_inst, reff388_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff388_sat1932 : @Equation1932 Fin4 reff388_inst.
Proof. unfold Equation1932, magma_op, reff388_inst, reff388_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff388_sat1934 : @Equation1934 Fin4 reff388_inst.
Proof. unfold Equation1934, magma_op, reff388_inst, reff388_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff388_sat2064 : @Equation2064 Fin4 reff388_inst.
Proof. unfold Equation2064, magma_op, reff388_inst, reff388_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff388_sat2101 : @Equation2101 Fin4 reff388_inst.
Proof. unfold Equation2101, magma_op, reff388_inst, reff388_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff388_sat2128 : @Equation2128 Fin4 reff388_inst.
Proof. unfold Equation2128, magma_op, reff388_inst, reff388_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff388_sat2135 : @Equation2135 Fin4 reff388_inst.
Proof. unfold Equation2135, magma_op, reff388_inst, reff388_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff388_sat2137 : @Equation2137 Fin4 reff388_inst.
Proof. unfold Equation2137, magma_op, reff388_inst, reff388_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff388_sat2267 : @Equation2267 Fin4 reff388_inst.
Proof. unfold Equation2267, magma_op, reff388_inst, reff388_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff388_sat2304 : @Equation2304 Fin4 reff388_inst.
Proof. unfold Equation2304, magma_op, reff388_inst, reff388_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff388_sat2331 : @Equation2331 Fin4 reff388_inst.
Proof. unfold Equation2331, magma_op, reff388_inst, reff388_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff388_sat2338 : @Equation2338 Fin4 reff388_inst.
Proof. unfold Equation2338, magma_op, reff388_inst, reff388_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff388_sat2340 : @Equation2340 Fin4 reff388_inst.
Proof. unfold Equation2340, magma_op, reff388_inst, reff388_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff388_sat2470 : @Equation2470 Fin4 reff388_inst.
Proof. unfold Equation2470, magma_op, reff388_inst, reff388_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff388_sat2507 : @Equation2507 Fin4 reff388_inst.
Proof. unfold Equation2507, magma_op, reff388_inst, reff388_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff388_sat2534 : @Equation2534 Fin4 reff388_inst.
Proof. unfold Equation2534, magma_op, reff388_inst, reff388_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff388_sat2541 : @Equation2541 Fin4 reff388_inst.
Proof. unfold Equation2541, magma_op, reff388_inst, reff388_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff388_sat2543 : @Equation2543 Fin4 reff388_inst.
Proof. unfold Equation2543, magma_op, reff388_inst, reff388_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff388_sat2673 : @Equation2673 Fin4 reff388_inst.
Proof. unfold Equation2673, magma_op, reff388_inst, reff388_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff388_sat2710 : @Equation2710 Fin4 reff388_inst.
Proof. unfold Equation2710, magma_op, reff388_inst, reff388_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff388_sat2737 : @Equation2737 Fin4 reff388_inst.
Proof. unfold Equation2737, magma_op, reff388_inst, reff388_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff388_sat2744 : @Equation2744 Fin4 reff388_inst.
Proof. unfold Equation2744, magma_op, reff388_inst, reff388_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff388_sat2746 : @Equation2746 Fin4 reff388_inst.
Proof. unfold Equation2746, magma_op, reff388_inst, reff388_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff388_sat2876 : @Equation2876 Fin4 reff388_inst.
Proof. unfold Equation2876, magma_op, reff388_inst, reff388_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff388_sat2913 : @Equation2913 Fin4 reff388_inst.
Proof. unfold Equation2913, magma_op, reff388_inst, reff388_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff388_sat2940 : @Equation2940 Fin4 reff388_inst.
Proof. unfold Equation2940, magma_op, reff388_inst, reff388_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff388_sat2947 : @Equation2947 Fin4 reff388_inst.
Proof. unfold Equation2947, magma_op, reff388_inst, reff388_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff388_sat2949 : @Equation2949 Fin4 reff388_inst.
Proof. unfold Equation2949, magma_op, reff388_inst, reff388_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff388_sat3079 : @Equation3079 Fin4 reff388_inst.
Proof. unfold Equation3079, magma_op, reff388_inst, reff388_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff388_sat3116 : @Equation3116 Fin4 reff388_inst.
Proof. unfold Equation3116, magma_op, reff388_inst, reff388_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff388_sat3143 : @Equation3143 Fin4 reff388_inst.
Proof. unfold Equation3143, magma_op, reff388_inst, reff388_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff388_sat3150 : @Equation3150 Fin4 reff388_inst.
Proof. unfold Equation3150, magma_op, reff388_inst, reff388_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff388_sat3152 : @Equation3152 Fin4 reff388_inst.
Proof. unfold Equation3152, magma_op, reff388_inst, reff388_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff388_sat4364 : @Equation4364 Fin4 reff388_inst.
Proof. unfold Equation4364, magma_op, reff388_inst, reff388_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff388_sat4369 : @Equation4369 Fin4 reff388_inst.
Proof. unfold Equation4369, magma_op, reff388_inst, reff388_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff388_sat4512 : @Equation4512 Fin4 reff388_inst.
Proof. unfold Equation4512, magma_op, reff388_inst, reff388_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff388_sat4515 : @Equation4515 Fin4 reff388_inst.
Proof. unfold Equation4515, magma_op, reff388_inst, reff388_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff388_sat4525 : @Equation4525 Fin4 reff388_inst.
Proof. unfold Equation4525, magma_op, reff388_inst, reff388_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff388_sat4541 : @Equation4541 Fin4 reff388_inst.
Proof. unfold Equation4541, magma_op, reff388_inst, reff388_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff388_sat4679 : @Equation4679 Fin4 reff388_inst.
Proof. unfold Equation4679, magma_op, reff388_inst, reff388_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff388_sat4684 : @Equation4684 Fin4 reff388_inst.
Proof. unfold Equation4684, magma_op, reff388_inst, reff388_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff388_not47 : ~ @Equation47 Fin4 reff388_inst.
Proof. unfold Equation47. intro H. specialize (H F4_1). unfold magma_op, reff388_inst, reff388_op in H. discriminate H. Qed.

Lemma reff388_not99 : ~ @Equation99 Fin4 reff388_inst.
Proof. unfold Equation99. intro H. specialize (H F4_1). unfold magma_op, reff388_inst, reff388_op in H. discriminate H. Qed.

Lemma reff388_not151 : ~ @Equation151 Fin4 reff388_inst.
Proof. unfold Equation151. intro H. specialize (H F4_1). unfold magma_op, reff388_inst, reff388_op in H. discriminate H. Qed.

Lemma reff388_not203 : ~ @Equation203 Fin4 reff388_inst.
Proof. unfold Equation203. intro H. specialize (H F4_1). unfold magma_op, reff388_inst, reff388_op in H. discriminate H. Qed.

Lemma reff388_not255 : ~ @Equation255 Fin4 reff388_inst.
Proof. unfold Equation255. intro H. specialize (H F4_1). unfold magma_op, reff388_inst, reff388_op in H. discriminate H. Qed.

Lemma reff388_not412 : ~ @Equation412 Fin4 reff388_inst.
Proof. unfold Equation412. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff388_inst, reff388_op in H. discriminate H. Qed.

Lemma reff388_not413 : ~ @Equation413 Fin4 reff388_inst.
Proof. unfold Equation413. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff388_inst, reff388_op in H. discriminate H. Qed.

Lemma reff388_not414 : ~ @Equation414 Fin4 reff388_inst.
Proof. unfold Equation414. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff388_inst, reff388_op in H. discriminate H. Qed.

Lemma reff388_not416 : ~ @Equation416 Fin4 reff388_inst.
Proof. unfold Equation416. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff388_inst, reff388_op in H. discriminate H. Qed.

Lemma reff388_not417 : ~ @Equation417 Fin4 reff388_inst.
Proof. unfold Equation417. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff388_inst, reff388_op in H. discriminate H. Qed.

Lemma reff388_not419 : ~ @Equation419 Fin4 reff388_inst.
Proof. unfold Equation419. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff388_inst, reff388_op in H. discriminate H. Qed.

Lemma reff388_not420 : ~ @Equation420 Fin4 reff388_inst.
Proof. unfold Equation420. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff388_inst, reff388_op in H. discriminate H. Qed.

Lemma reff388_not426 : ~ @Equation426 Fin4 reff388_inst.
Proof. unfold Equation426. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff388_inst, reff388_op in H. discriminate H. Qed.

Lemma reff388_not427 : ~ @Equation427 Fin4 reff388_inst.
Proof. unfold Equation427. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff388_inst, reff388_op in H. discriminate H. Qed.

Lemma reff388_not429 : ~ @Equation429 Fin4 reff388_inst.
Proof. unfold Equation429. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff388_inst, reff388_op in H. discriminate H. Qed.

Lemma reff388_not430 : ~ @Equation430 Fin4 reff388_inst.
Proof. unfold Equation430. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff388_inst, reff388_op in H. discriminate H. Qed.

Lemma reff388_not436 : ~ @Equation436 Fin4 reff388_inst.
Proof. unfold Equation436. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff388_inst, reff388_op in H. discriminate H. Qed.

Lemma reff388_not437 : ~ @Equation437 Fin4 reff388_inst.
Proof. unfold Equation437. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff388_inst, reff388_op in H. discriminate H. Qed.

Lemma reff388_not439 : ~ @Equation439 Fin4 reff388_inst.
Proof. unfold Equation439. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff388_inst, reff388_op in H. discriminate H. Qed.

Lemma reff388_not463 : ~ @Equation463 Fin4 reff388_inst.
Proof. unfold Equation463. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff388_inst, reff388_op in H. discriminate H. Qed.

Lemma reff388_not464 : ~ @Equation464 Fin4 reff388_inst.
Proof. unfold Equation464. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff388_inst, reff388_op in H. discriminate H. Qed.

Lemma reff388_not466 : ~ @Equation466 Fin4 reff388_inst.
Proof. unfold Equation466. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff388_inst, reff388_op in H. discriminate H. Qed.

Lemma reff388_not467 : ~ @Equation467 Fin4 reff388_inst.
Proof. unfold Equation467. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff388_inst, reff388_op in H. discriminate H. Qed.

Lemma reff388_not473 : ~ @Equation473 Fin4 reff388_inst.
Proof. unfold Equation473. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff388_inst, reff388_op in H. discriminate H. Qed.

Lemma reff388_not474 : ~ @Equation474 Fin4 reff388_inst.
Proof. unfold Equation474. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff388_inst, reff388_op in H. discriminate H. Qed.

Lemma reff388_not476 : ~ @Equation476 Fin4 reff388_inst.
Proof. unfold Equation476. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff388_inst, reff388_op in H. discriminate H. Qed.

Lemma reff388_not500 : ~ @Equation500 Fin4 reff388_inst.
Proof. unfold Equation500. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff388_inst, reff388_op in H. discriminate H. Qed.

Lemma reff388_not501 : ~ @Equation501 Fin4 reff388_inst.
Proof. unfold Equation501. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff388_inst, reff388_op in H. discriminate H. Qed.

Lemma reff388_not503 : ~ @Equation503 Fin4 reff388_inst.
Proof. unfold Equation503. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff388_inst, reff388_op in H. discriminate H. Qed.

Lemma reff388_not510 : ~ @Equation510 Fin4 reff388_inst.
Proof. unfold Equation510. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff388_inst, reff388_op in H. discriminate H. Qed.

Lemma reff388_not615 : ~ @Equation615 Fin4 reff388_inst.
Proof. unfold Equation615. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff388_inst, reff388_op in H. discriminate H. Qed.

Lemma reff388_not616 : ~ @Equation616 Fin4 reff388_inst.
Proof. unfold Equation616. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff388_inst, reff388_op in H. discriminate H. Qed.

Lemma reff388_not617 : ~ @Equation617 Fin4 reff388_inst.
Proof. unfold Equation617. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff388_inst, reff388_op in H. discriminate H. Qed.

Lemma reff388_not619 : ~ @Equation619 Fin4 reff388_inst.
Proof. unfold Equation619. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff388_inst, reff388_op in H. discriminate H. Qed.

Lemma reff388_not620 : ~ @Equation620 Fin4 reff388_inst.
Proof. unfold Equation620. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff388_inst, reff388_op in H. discriminate H. Qed.

Lemma reff388_not622 : ~ @Equation622 Fin4 reff388_inst.
Proof. unfold Equation622. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff388_inst, reff388_op in H. discriminate H. Qed.

Lemma reff388_not623 : ~ @Equation623 Fin4 reff388_inst.
Proof. unfold Equation623. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff388_inst, reff388_op in H. discriminate H. Qed.

Lemma reff388_not629 : ~ @Equation629 Fin4 reff388_inst.
Proof. unfold Equation629. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff388_inst, reff388_op in H. discriminate H. Qed.

Lemma reff388_not630 : ~ @Equation630 Fin4 reff388_inst.
Proof. unfold Equation630. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff388_inst, reff388_op in H. discriminate H. Qed.

Lemma reff388_not632 : ~ @Equation632 Fin4 reff388_inst.
Proof. unfold Equation632. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff388_inst, reff388_op in H. discriminate H. Qed.

Lemma reff388_not633 : ~ @Equation633 Fin4 reff388_inst.
Proof. unfold Equation633. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff388_inst, reff388_op in H. discriminate H. Qed.

Lemma reff388_not639 : ~ @Equation639 Fin4 reff388_inst.
Proof. unfold Equation639. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff388_inst, reff388_op in H. discriminate H. Qed.

Lemma reff388_not640 : ~ @Equation640 Fin4 reff388_inst.
Proof. unfold Equation640. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff388_inst, reff388_op in H. discriminate H. Qed.

Lemma reff388_not642 : ~ @Equation642 Fin4 reff388_inst.
Proof. unfold Equation642. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff388_inst, reff388_op in H. discriminate H. Qed.

Lemma reff388_not666 : ~ @Equation666 Fin4 reff388_inst.
Proof. unfold Equation666. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff388_inst, reff388_op in H. discriminate H. Qed.

Lemma reff388_not667 : ~ @Equation667 Fin4 reff388_inst.
Proof. unfold Equation667. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff388_inst, reff388_op in H. discriminate H. Qed.

Lemma reff388_not669 : ~ @Equation669 Fin4 reff388_inst.
Proof. unfold Equation669. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff388_inst, reff388_op in H. discriminate H. Qed.

Lemma reff388_not670 : ~ @Equation670 Fin4 reff388_inst.
Proof. unfold Equation670. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff388_inst, reff388_op in H. discriminate H. Qed.

Lemma reff388_not676 : ~ @Equation676 Fin4 reff388_inst.
Proof. unfold Equation676. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff388_inst, reff388_op in H. discriminate H. Qed.

Lemma reff388_not677 : ~ @Equation677 Fin4 reff388_inst.
Proof. unfold Equation677. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff388_inst, reff388_op in H. discriminate H. Qed.

Lemma reff388_not679 : ~ @Equation679 Fin4 reff388_inst.
Proof. unfold Equation679. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff388_inst, reff388_op in H. discriminate H. Qed.

Lemma reff388_not703 : ~ @Equation703 Fin4 reff388_inst.
Proof. unfold Equation703. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff388_inst, reff388_op in H. discriminate H. Qed.

Lemma reff388_not704 : ~ @Equation704 Fin4 reff388_inst.
Proof. unfold Equation704. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff388_inst, reff388_op in H. discriminate H. Qed.

Lemma reff388_not706 : ~ @Equation706 Fin4 reff388_inst.
Proof. unfold Equation706. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff388_inst, reff388_op in H. discriminate H. Qed.

Lemma reff388_not713 : ~ @Equation713 Fin4 reff388_inst.
Proof. unfold Equation713. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff388_inst, reff388_op in H. discriminate H. Qed.

Lemma reff388_not818 : ~ @Equation818 Fin4 reff388_inst.
Proof. unfold Equation818. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff388_inst, reff388_op in H. discriminate H. Qed.

Lemma reff388_not819 : ~ @Equation819 Fin4 reff388_inst.
Proof. unfold Equation819. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff388_inst, reff388_op in H. discriminate H. Qed.

Lemma reff388_not820 : ~ @Equation820 Fin4 reff388_inst.
Proof. unfold Equation820. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff388_inst, reff388_op in H. discriminate H. Qed.

Lemma reff388_not822 : ~ @Equation822 Fin4 reff388_inst.
Proof. unfold Equation822. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff388_inst, reff388_op in H. discriminate H. Qed.

Lemma reff388_not823 : ~ @Equation823 Fin4 reff388_inst.
Proof. unfold Equation823. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff388_inst, reff388_op in H. discriminate H. Qed.

Lemma reff388_not825 : ~ @Equation825 Fin4 reff388_inst.
Proof. unfold Equation825. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff388_inst, reff388_op in H. discriminate H. Qed.

Lemma reff388_not826 : ~ @Equation826 Fin4 reff388_inst.
Proof. unfold Equation826. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff388_inst, reff388_op in H. discriminate H. Qed.

Lemma reff388_not832 : ~ @Equation832 Fin4 reff388_inst.
Proof. unfold Equation832. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff388_inst, reff388_op in H. discriminate H. Qed.

Lemma reff388_not833 : ~ @Equation833 Fin4 reff388_inst.
Proof. unfold Equation833. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff388_inst, reff388_op in H. discriminate H. Qed.

Lemma reff388_not835 : ~ @Equation835 Fin4 reff388_inst.
Proof. unfold Equation835. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff388_inst, reff388_op in H. discriminate H. Qed.

Lemma reff388_not836 : ~ @Equation836 Fin4 reff388_inst.
Proof. unfold Equation836. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff388_inst, reff388_op in H. discriminate H. Qed.

Lemma reff388_not842 : ~ @Equation842 Fin4 reff388_inst.
Proof. unfold Equation842. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff388_inst, reff388_op in H. discriminate H. Qed.

Lemma reff388_not843 : ~ @Equation843 Fin4 reff388_inst.
Proof. unfold Equation843. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff388_inst, reff388_op in H. discriminate H. Qed.

Lemma reff388_not845 : ~ @Equation845 Fin4 reff388_inst.
Proof. unfold Equation845. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff388_inst, reff388_op in H. discriminate H. Qed.

Lemma reff388_not869 : ~ @Equation869 Fin4 reff388_inst.
Proof. unfold Equation869. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff388_inst, reff388_op in H. discriminate H. Qed.

Lemma reff388_not870 : ~ @Equation870 Fin4 reff388_inst.
Proof. unfold Equation870. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff388_inst, reff388_op in H. discriminate H. Qed.

Lemma reff388_not872 : ~ @Equation872 Fin4 reff388_inst.
Proof. unfold Equation872. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff388_inst, reff388_op in H. discriminate H. Qed.

Lemma reff388_not873 : ~ @Equation873 Fin4 reff388_inst.
Proof. unfold Equation873. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff388_inst, reff388_op in H. discriminate H. Qed.

Lemma reff388_not879 : ~ @Equation879 Fin4 reff388_inst.
Proof. unfold Equation879. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff388_inst, reff388_op in H. discriminate H. Qed.

Lemma reff388_not880 : ~ @Equation880 Fin4 reff388_inst.
Proof. unfold Equation880. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff388_inst, reff388_op in H. discriminate H. Qed.

Lemma reff388_not882 : ~ @Equation882 Fin4 reff388_inst.
Proof. unfold Equation882. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff388_inst, reff388_op in H. discriminate H. Qed.

Lemma reff388_not906 : ~ @Equation906 Fin4 reff388_inst.
Proof. unfold Equation906. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff388_inst, reff388_op in H. discriminate H. Qed.

Lemma reff388_not907 : ~ @Equation907 Fin4 reff388_inst.
Proof. unfold Equation907. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff388_inst, reff388_op in H. discriminate H. Qed.

Lemma reff388_not909 : ~ @Equation909 Fin4 reff388_inst.
Proof. unfold Equation909. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff388_inst, reff388_op in H. discriminate H. Qed.

Lemma reff388_not916 : ~ @Equation916 Fin4 reff388_inst.
Proof. unfold Equation916. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff388_inst, reff388_op in H. discriminate H. Qed.

Lemma reff388_not1021 : ~ @Equation1021 Fin4 reff388_inst.
Proof. unfold Equation1021. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff388_inst, reff388_op in H. discriminate H. Qed.

Lemma reff388_not1022 : ~ @Equation1022 Fin4 reff388_inst.
Proof. unfold Equation1022. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff388_inst, reff388_op in H. discriminate H. Qed.

Lemma reff388_not1023 : ~ @Equation1023 Fin4 reff388_inst.
Proof. unfold Equation1023. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff388_inst, reff388_op in H. discriminate H. Qed.

Lemma reff388_not1025 : ~ @Equation1025 Fin4 reff388_inst.
Proof. unfold Equation1025. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff388_inst, reff388_op in H. discriminate H. Qed.

Lemma reff388_not1026 : ~ @Equation1026 Fin4 reff388_inst.
Proof. unfold Equation1026. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff388_inst, reff388_op in H. discriminate H. Qed.

Lemma reff388_not1028 : ~ @Equation1028 Fin4 reff388_inst.
Proof. unfold Equation1028. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff388_inst, reff388_op in H. discriminate H. Qed.

Lemma reff388_not1029 : ~ @Equation1029 Fin4 reff388_inst.
Proof. unfold Equation1029. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff388_inst, reff388_op in H. discriminate H. Qed.

Lemma reff388_not1035 : ~ @Equation1035 Fin4 reff388_inst.
Proof. unfold Equation1035. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff388_inst, reff388_op in H. discriminate H. Qed.

Lemma reff388_not1036 : ~ @Equation1036 Fin4 reff388_inst.
Proof. unfold Equation1036. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff388_inst, reff388_op in H. discriminate H. Qed.

Lemma reff388_not1038 : ~ @Equation1038 Fin4 reff388_inst.
Proof. unfold Equation1038. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff388_inst, reff388_op in H. discriminate H. Qed.

Lemma reff388_not1039 : ~ @Equation1039 Fin4 reff388_inst.
Proof. unfold Equation1039. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff388_inst, reff388_op in H. discriminate H. Qed.

Lemma reff388_not1045 : ~ @Equation1045 Fin4 reff388_inst.
Proof. unfold Equation1045. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff388_inst, reff388_op in H. discriminate H. Qed.

Lemma reff388_not1046 : ~ @Equation1046 Fin4 reff388_inst.
Proof. unfold Equation1046. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff388_inst, reff388_op in H. discriminate H. Qed.

Lemma reff388_not1048 : ~ @Equation1048 Fin4 reff388_inst.
Proof. unfold Equation1048. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff388_inst, reff388_op in H. discriminate H. Qed.

Lemma reff388_not1072 : ~ @Equation1072 Fin4 reff388_inst.
Proof. unfold Equation1072. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff388_inst, reff388_op in H. discriminate H. Qed.

Lemma reff388_not1073 : ~ @Equation1073 Fin4 reff388_inst.
Proof. unfold Equation1073. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff388_inst, reff388_op in H. discriminate H. Qed.

Lemma reff388_not1075 : ~ @Equation1075 Fin4 reff388_inst.
Proof. unfold Equation1075. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff388_inst, reff388_op in H. discriminate H. Qed.

Lemma reff388_not1076 : ~ @Equation1076 Fin4 reff388_inst.
Proof. unfold Equation1076. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff388_inst, reff388_op in H. discriminate H. Qed.

Lemma reff388_not1082 : ~ @Equation1082 Fin4 reff388_inst.
Proof. unfold Equation1082. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff388_inst, reff388_op in H. discriminate H. Qed.

Lemma reff388_not1083 : ~ @Equation1083 Fin4 reff388_inst.
Proof. unfold Equation1083. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff388_inst, reff388_op in H. discriminate H. Qed.

Lemma reff388_not1085 : ~ @Equation1085 Fin4 reff388_inst.
Proof. unfold Equation1085. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff388_inst, reff388_op in H. discriminate H. Qed.

Lemma reff388_not1109 : ~ @Equation1109 Fin4 reff388_inst.
Proof. unfold Equation1109. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff388_inst, reff388_op in H. discriminate H. Qed.

Lemma reff388_not1110 : ~ @Equation1110 Fin4 reff388_inst.
Proof. unfold Equation1110. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff388_inst, reff388_op in H. discriminate H. Qed.

Lemma reff388_not1112 : ~ @Equation1112 Fin4 reff388_inst.
Proof. unfold Equation1112. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff388_inst, reff388_op in H. discriminate H. Qed.

Lemma reff388_not1119 : ~ @Equation1119 Fin4 reff388_inst.
Proof. unfold Equation1119. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff388_inst, reff388_op in H. discriminate H. Qed.

Lemma reff388_not1224 : ~ @Equation1224 Fin4 reff388_inst.
Proof. unfold Equation1224. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff388_inst, reff388_op in H. discriminate H. Qed.

Lemma reff388_not1225 : ~ @Equation1225 Fin4 reff388_inst.
Proof. unfold Equation1225. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff388_inst, reff388_op in H. discriminate H. Qed.

Lemma reff388_not1226 : ~ @Equation1226 Fin4 reff388_inst.
Proof. unfold Equation1226. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff388_inst, reff388_op in H. discriminate H. Qed.

Lemma reff388_not1228 : ~ @Equation1228 Fin4 reff388_inst.
Proof. unfold Equation1228. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff388_inst, reff388_op in H. discriminate H. Qed.

Lemma reff388_not1229 : ~ @Equation1229 Fin4 reff388_inst.
Proof. unfold Equation1229. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff388_inst, reff388_op in H. discriminate H. Qed.

Lemma reff388_not1231 : ~ @Equation1231 Fin4 reff388_inst.
Proof. unfold Equation1231. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff388_inst, reff388_op in H. discriminate H. Qed.

Lemma reff388_not1232 : ~ @Equation1232 Fin4 reff388_inst.
Proof. unfold Equation1232. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff388_inst, reff388_op in H. discriminate H. Qed.

Lemma reff388_not1238 : ~ @Equation1238 Fin4 reff388_inst.
Proof. unfold Equation1238. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff388_inst, reff388_op in H. discriminate H. Qed.

Lemma reff388_not1239 : ~ @Equation1239 Fin4 reff388_inst.
Proof. unfold Equation1239. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff388_inst, reff388_op in H. discriminate H. Qed.

Lemma reff388_not1241 : ~ @Equation1241 Fin4 reff388_inst.
Proof. unfold Equation1241. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff388_inst, reff388_op in H. discriminate H. Qed.

Lemma reff388_not1242 : ~ @Equation1242 Fin4 reff388_inst.
Proof. unfold Equation1242. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff388_inst, reff388_op in H. discriminate H. Qed.

Lemma reff388_not1248 : ~ @Equation1248 Fin4 reff388_inst.
Proof. unfold Equation1248. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff388_inst, reff388_op in H. discriminate H. Qed.

Lemma reff388_not1249 : ~ @Equation1249 Fin4 reff388_inst.
Proof. unfold Equation1249. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff388_inst, reff388_op in H. discriminate H. Qed.

Lemma reff388_not1251 : ~ @Equation1251 Fin4 reff388_inst.
Proof. unfold Equation1251. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff388_inst, reff388_op in H. discriminate H. Qed.

Lemma reff388_not1275 : ~ @Equation1275 Fin4 reff388_inst.
Proof. unfold Equation1275. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff388_inst, reff388_op in H. discriminate H. Qed.

Lemma reff388_not1276 : ~ @Equation1276 Fin4 reff388_inst.
Proof. unfold Equation1276. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff388_inst, reff388_op in H. discriminate H. Qed.

Lemma reff388_not1278 : ~ @Equation1278 Fin4 reff388_inst.
Proof. unfold Equation1278. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff388_inst, reff388_op in H. discriminate H. Qed.

Lemma reff388_not1279 : ~ @Equation1279 Fin4 reff388_inst.
Proof. unfold Equation1279. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff388_inst, reff388_op in H. discriminate H. Qed.

Lemma reff388_not1285 : ~ @Equation1285 Fin4 reff388_inst.
Proof. unfold Equation1285. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff388_inst, reff388_op in H. discriminate H. Qed.

Lemma reff388_not1286 : ~ @Equation1286 Fin4 reff388_inst.
Proof. unfold Equation1286. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff388_inst, reff388_op in H. discriminate H. Qed.

Lemma reff388_not1288 : ~ @Equation1288 Fin4 reff388_inst.
Proof. unfold Equation1288. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff388_inst, reff388_op in H. discriminate H. Qed.

Lemma reff388_not1312 : ~ @Equation1312 Fin4 reff388_inst.
Proof. unfold Equation1312. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff388_inst, reff388_op in H. discriminate H. Qed.

Lemma reff388_not1313 : ~ @Equation1313 Fin4 reff388_inst.
Proof. unfold Equation1313. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff388_inst, reff388_op in H. discriminate H. Qed.

Lemma reff388_not1315 : ~ @Equation1315 Fin4 reff388_inst.
Proof. unfold Equation1315. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff388_inst, reff388_op in H. discriminate H. Qed.

Lemma reff388_not1322 : ~ @Equation1322 Fin4 reff388_inst.
Proof. unfold Equation1322. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff388_inst, reff388_op in H. discriminate H. Qed.

Lemma reff388_not1427 : ~ @Equation1427 Fin4 reff388_inst.
Proof. unfold Equation1427. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff388_inst, reff388_op in H. discriminate H. Qed.

Lemma reff388_not1428 : ~ @Equation1428 Fin4 reff388_inst.
Proof. unfold Equation1428. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff388_inst, reff388_op in H. discriminate H. Qed.

Lemma reff388_not1429 : ~ @Equation1429 Fin4 reff388_inst.
Proof. unfold Equation1429. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff388_inst, reff388_op in H. discriminate H. Qed.

Lemma reff388_not1431 : ~ @Equation1431 Fin4 reff388_inst.
Proof. unfold Equation1431. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff388_inst, reff388_op in H. discriminate H. Qed.

Lemma reff388_not1432 : ~ @Equation1432 Fin4 reff388_inst.
Proof. unfold Equation1432. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff388_inst, reff388_op in H. discriminate H. Qed.

Lemma reff388_not1434 : ~ @Equation1434 Fin4 reff388_inst.
Proof. unfold Equation1434. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff388_inst, reff388_op in H. discriminate H. Qed.

Lemma reff388_not1435 : ~ @Equation1435 Fin4 reff388_inst.
Proof. unfold Equation1435. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff388_inst, reff388_op in H. discriminate H. Qed.

Lemma reff388_not1441 : ~ @Equation1441 Fin4 reff388_inst.
Proof. unfold Equation1441. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff388_inst, reff388_op in H. discriminate H. Qed.

Lemma reff388_not1442 : ~ @Equation1442 Fin4 reff388_inst.
Proof. unfold Equation1442. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff388_inst, reff388_op in H. discriminate H. Qed.

Lemma reff388_not1444 : ~ @Equation1444 Fin4 reff388_inst.
Proof. unfold Equation1444. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff388_inst, reff388_op in H. discriminate H. Qed.

Lemma reff388_not1445 : ~ @Equation1445 Fin4 reff388_inst.
Proof. unfold Equation1445. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff388_inst, reff388_op in H. discriminate H. Qed.

Lemma reff388_not1451 : ~ @Equation1451 Fin4 reff388_inst.
Proof. unfold Equation1451. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff388_inst, reff388_op in H. discriminate H. Qed.

Lemma reff388_not1452 : ~ @Equation1452 Fin4 reff388_inst.
Proof. unfold Equation1452. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff388_inst, reff388_op in H. discriminate H. Qed.

Lemma reff388_not1454 : ~ @Equation1454 Fin4 reff388_inst.
Proof. unfold Equation1454. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff388_inst, reff388_op in H. discriminate H. Qed.

Lemma reff388_not1478 : ~ @Equation1478 Fin4 reff388_inst.
Proof. unfold Equation1478. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff388_inst, reff388_op in H. discriminate H. Qed.

Lemma reff388_not1479 : ~ @Equation1479 Fin4 reff388_inst.
Proof. unfold Equation1479. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff388_inst, reff388_op in H. discriminate H. Qed.

Lemma reff388_not1481 : ~ @Equation1481 Fin4 reff388_inst.
Proof. unfold Equation1481. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff388_inst, reff388_op in H. discriminate H. Qed.

Lemma reff388_not1482 : ~ @Equation1482 Fin4 reff388_inst.
Proof. unfold Equation1482. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff388_inst, reff388_op in H. discriminate H. Qed.

Lemma reff388_not1488 : ~ @Equation1488 Fin4 reff388_inst.
Proof. unfold Equation1488. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff388_inst, reff388_op in H. discriminate H. Qed.

Lemma reff388_not1489 : ~ @Equation1489 Fin4 reff388_inst.
Proof. unfold Equation1489. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff388_inst, reff388_op in H. discriminate H. Qed.

Lemma reff388_not1491 : ~ @Equation1491 Fin4 reff388_inst.
Proof. unfold Equation1491. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff388_inst, reff388_op in H. discriminate H. Qed.

Lemma reff388_not1515 : ~ @Equation1515 Fin4 reff388_inst.
Proof. unfold Equation1515. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff388_inst, reff388_op in H. discriminate H. Qed.

Lemma reff388_not1516 : ~ @Equation1516 Fin4 reff388_inst.
Proof. unfold Equation1516. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff388_inst, reff388_op in H. discriminate H. Qed.

Lemma reff388_not1518 : ~ @Equation1518 Fin4 reff388_inst.
Proof. unfold Equation1518. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff388_inst, reff388_op in H. discriminate H. Qed.

Lemma reff388_not1525 : ~ @Equation1525 Fin4 reff388_inst.
Proof. unfold Equation1525. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff388_inst, reff388_op in H. discriminate H. Qed.

Lemma reff388_not1630 : ~ @Equation1630 Fin4 reff388_inst.
Proof. unfold Equation1630. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff388_inst, reff388_op in H. discriminate H. Qed.

Lemma reff388_not1631 : ~ @Equation1631 Fin4 reff388_inst.
Proof. unfold Equation1631. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff388_inst, reff388_op in H. discriminate H. Qed.

Lemma reff388_not1632 : ~ @Equation1632 Fin4 reff388_inst.
Proof. unfold Equation1632. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff388_inst, reff388_op in H. discriminate H. Qed.

Lemma reff388_not1634 : ~ @Equation1634 Fin4 reff388_inst.
Proof. unfold Equation1634. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff388_inst, reff388_op in H. discriminate H. Qed.

Lemma reff388_not1635 : ~ @Equation1635 Fin4 reff388_inst.
Proof. unfold Equation1635. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff388_inst, reff388_op in H. discriminate H. Qed.

Lemma reff388_not1637 : ~ @Equation1637 Fin4 reff388_inst.
Proof. unfold Equation1637. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff388_inst, reff388_op in H. discriminate H. Qed.

Lemma reff388_not1638 : ~ @Equation1638 Fin4 reff388_inst.
Proof. unfold Equation1638. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff388_inst, reff388_op in H. discriminate H. Qed.

Lemma reff388_not1644 : ~ @Equation1644 Fin4 reff388_inst.
Proof. unfold Equation1644. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff388_inst, reff388_op in H. discriminate H. Qed.

Lemma reff388_not1645 : ~ @Equation1645 Fin4 reff388_inst.
Proof. unfold Equation1645. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff388_inst, reff388_op in H. discriminate H. Qed.

Lemma reff388_not1647 : ~ @Equation1647 Fin4 reff388_inst.
Proof. unfold Equation1647. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff388_inst, reff388_op in H. discriminate H. Qed.

Lemma reff388_not1648 : ~ @Equation1648 Fin4 reff388_inst.
Proof. unfold Equation1648. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff388_inst, reff388_op in H. discriminate H. Qed.

Lemma reff388_not1654 : ~ @Equation1654 Fin4 reff388_inst.
Proof. unfold Equation1654. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff388_inst, reff388_op in H. discriminate H. Qed.

Lemma reff388_not1655 : ~ @Equation1655 Fin4 reff388_inst.
Proof. unfold Equation1655. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff388_inst, reff388_op in H. discriminate H. Qed.

Lemma reff388_not1657 : ~ @Equation1657 Fin4 reff388_inst.
Proof. unfold Equation1657. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff388_inst, reff388_op in H. discriminate H. Qed.

Lemma reff388_not1681 : ~ @Equation1681 Fin4 reff388_inst.
Proof. unfold Equation1681. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff388_inst, reff388_op in H. discriminate H. Qed.

Lemma reff388_not1682 : ~ @Equation1682 Fin4 reff388_inst.
Proof. unfold Equation1682. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff388_inst, reff388_op in H. discriminate H. Qed.

Lemma reff388_not1684 : ~ @Equation1684 Fin4 reff388_inst.
Proof. unfold Equation1684. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff388_inst, reff388_op in H. discriminate H. Qed.

Lemma reff388_not1685 : ~ @Equation1685 Fin4 reff388_inst.
Proof. unfold Equation1685. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff388_inst, reff388_op in H. discriminate H. Qed.

Lemma reff388_not1691 : ~ @Equation1691 Fin4 reff388_inst.
Proof. unfold Equation1691. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff388_inst, reff388_op in H. discriminate H. Qed.

Lemma reff388_not1692 : ~ @Equation1692 Fin4 reff388_inst.
Proof. unfold Equation1692. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff388_inst, reff388_op in H. discriminate H. Qed.

Lemma reff388_not1694 : ~ @Equation1694 Fin4 reff388_inst.
Proof. unfold Equation1694. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff388_inst, reff388_op in H. discriminate H. Qed.

Lemma reff388_not1718 : ~ @Equation1718 Fin4 reff388_inst.
Proof. unfold Equation1718. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff388_inst, reff388_op in H. discriminate H. Qed.

Lemma reff388_not1719 : ~ @Equation1719 Fin4 reff388_inst.
Proof. unfold Equation1719. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff388_inst, reff388_op in H. discriminate H. Qed.

Lemma reff388_not1721 : ~ @Equation1721 Fin4 reff388_inst.
Proof. unfold Equation1721. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff388_inst, reff388_op in H. discriminate H. Qed.

Lemma reff388_not1728 : ~ @Equation1728 Fin4 reff388_inst.
Proof. unfold Equation1728. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff388_inst, reff388_op in H. discriminate H. Qed.

Lemma reff388_not1833 : ~ @Equation1833 Fin4 reff388_inst.
Proof. unfold Equation1833. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff388_inst, reff388_op in H. discriminate H. Qed.

Lemma reff388_not1834 : ~ @Equation1834 Fin4 reff388_inst.
Proof. unfold Equation1834. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff388_inst, reff388_op in H. discriminate H. Qed.

Lemma reff388_not1835 : ~ @Equation1835 Fin4 reff388_inst.
Proof. unfold Equation1835. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff388_inst, reff388_op in H. discriminate H. Qed.

Lemma reff388_not1837 : ~ @Equation1837 Fin4 reff388_inst.
Proof. unfold Equation1837. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff388_inst, reff388_op in H. discriminate H. Qed.

Lemma reff388_not1838 : ~ @Equation1838 Fin4 reff388_inst.
Proof. unfold Equation1838. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff388_inst, reff388_op in H. discriminate H. Qed.

Lemma reff388_not1840 : ~ @Equation1840 Fin4 reff388_inst.
Proof. unfold Equation1840. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff388_inst, reff388_op in H. discriminate H. Qed.

Lemma reff388_not1841 : ~ @Equation1841 Fin4 reff388_inst.
Proof. unfold Equation1841. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff388_inst, reff388_op in H. discriminate H. Qed.

Lemma reff388_not1847 : ~ @Equation1847 Fin4 reff388_inst.
Proof. unfold Equation1847. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff388_inst, reff388_op in H. discriminate H. Qed.

Lemma reff388_not1848 : ~ @Equation1848 Fin4 reff388_inst.
Proof. unfold Equation1848. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff388_inst, reff388_op in H. discriminate H. Qed.

Lemma reff388_not1850 : ~ @Equation1850 Fin4 reff388_inst.
Proof. unfold Equation1850. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff388_inst, reff388_op in H. discriminate H. Qed.

Lemma reff388_not1851 : ~ @Equation1851 Fin4 reff388_inst.
Proof. unfold Equation1851. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff388_inst, reff388_op in H. discriminate H. Qed.

Lemma reff388_not1857 : ~ @Equation1857 Fin4 reff388_inst.
Proof. unfold Equation1857. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff388_inst, reff388_op in H. discriminate H. Qed.

Lemma reff388_not1858 : ~ @Equation1858 Fin4 reff388_inst.
Proof. unfold Equation1858. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff388_inst, reff388_op in H. discriminate H. Qed.

Lemma reff388_not1860 : ~ @Equation1860 Fin4 reff388_inst.
Proof. unfold Equation1860. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff388_inst, reff388_op in H. discriminate H. Qed.

Lemma reff388_not1884 : ~ @Equation1884 Fin4 reff388_inst.
Proof. unfold Equation1884. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff388_inst, reff388_op in H. discriminate H. Qed.

Lemma reff388_not1885 : ~ @Equation1885 Fin4 reff388_inst.
Proof. unfold Equation1885. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff388_inst, reff388_op in H. discriminate H. Qed.

Lemma reff388_not1887 : ~ @Equation1887 Fin4 reff388_inst.
Proof. unfold Equation1887. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff388_inst, reff388_op in H. discriminate H. Qed.

Lemma reff388_not1888 : ~ @Equation1888 Fin4 reff388_inst.
Proof. unfold Equation1888. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff388_inst, reff388_op in H. discriminate H. Qed.

Lemma reff388_not1894 : ~ @Equation1894 Fin4 reff388_inst.
Proof. unfold Equation1894. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff388_inst, reff388_op in H. discriminate H. Qed.

Lemma reff388_not1895 : ~ @Equation1895 Fin4 reff388_inst.
Proof. unfold Equation1895. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff388_inst, reff388_op in H. discriminate H. Qed.

Lemma reff388_not1897 : ~ @Equation1897 Fin4 reff388_inst.
Proof. unfold Equation1897. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff388_inst, reff388_op in H. discriminate H. Qed.

Lemma reff388_not1921 : ~ @Equation1921 Fin4 reff388_inst.
Proof. unfold Equation1921. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff388_inst, reff388_op in H. discriminate H. Qed.

Lemma reff388_not1922 : ~ @Equation1922 Fin4 reff388_inst.
Proof. unfold Equation1922. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff388_inst, reff388_op in H. discriminate H. Qed.

Lemma reff388_not1924 : ~ @Equation1924 Fin4 reff388_inst.
Proof. unfold Equation1924. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff388_inst, reff388_op in H. discriminate H. Qed.

Lemma reff388_not1931 : ~ @Equation1931 Fin4 reff388_inst.
Proof. unfold Equation1931. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff388_inst, reff388_op in H. discriminate H. Qed.

Lemma reff388_not2036 : ~ @Equation2036 Fin4 reff388_inst.
Proof. unfold Equation2036. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff388_inst, reff388_op in H. discriminate H. Qed.

Lemma reff388_not2037 : ~ @Equation2037 Fin4 reff388_inst.
Proof. unfold Equation2037. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff388_inst, reff388_op in H. discriminate H. Qed.

Lemma reff388_not2038 : ~ @Equation2038 Fin4 reff388_inst.
Proof. unfold Equation2038. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff388_inst, reff388_op in H. discriminate H. Qed.

Lemma reff388_not2040 : ~ @Equation2040 Fin4 reff388_inst.
Proof. unfold Equation2040. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff388_inst, reff388_op in H. discriminate H. Qed.

Lemma reff388_not2041 : ~ @Equation2041 Fin4 reff388_inst.
Proof. unfold Equation2041. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff388_inst, reff388_op in H. discriminate H. Qed.

Lemma reff388_not2043 : ~ @Equation2043 Fin4 reff388_inst.
Proof. unfold Equation2043. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff388_inst, reff388_op in H. discriminate H. Qed.

Lemma reff388_not2044 : ~ @Equation2044 Fin4 reff388_inst.
Proof. unfold Equation2044. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff388_inst, reff388_op in H. discriminate H. Qed.

Lemma reff388_not2050 : ~ @Equation2050 Fin4 reff388_inst.
Proof. unfold Equation2050. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff388_inst, reff388_op in H. discriminate H. Qed.

Lemma reff388_not2051 : ~ @Equation2051 Fin4 reff388_inst.
Proof. unfold Equation2051. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff388_inst, reff388_op in H. discriminate H. Qed.

Lemma reff388_not2053 : ~ @Equation2053 Fin4 reff388_inst.
Proof. unfold Equation2053. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff388_inst, reff388_op in H. discriminate H. Qed.

Lemma reff388_not2054 : ~ @Equation2054 Fin4 reff388_inst.
Proof. unfold Equation2054. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff388_inst, reff388_op in H. discriminate H. Qed.

Lemma reff388_not2060 : ~ @Equation2060 Fin4 reff388_inst.
Proof. unfold Equation2060. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff388_inst, reff388_op in H. discriminate H. Qed.

Lemma reff388_not2061 : ~ @Equation2061 Fin4 reff388_inst.
Proof. unfold Equation2061. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff388_inst, reff388_op in H. discriminate H. Qed.

Lemma reff388_not2063 : ~ @Equation2063 Fin4 reff388_inst.
Proof. unfold Equation2063. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff388_inst, reff388_op in H. discriminate H. Qed.

Lemma reff388_not2087 : ~ @Equation2087 Fin4 reff388_inst.
Proof. unfold Equation2087. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff388_inst, reff388_op in H. discriminate H. Qed.

Lemma reff388_not2088 : ~ @Equation2088 Fin4 reff388_inst.
Proof. unfold Equation2088. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff388_inst, reff388_op in H. discriminate H. Qed.

Lemma reff388_not2090 : ~ @Equation2090 Fin4 reff388_inst.
Proof. unfold Equation2090. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff388_inst, reff388_op in H. discriminate H. Qed.

Lemma reff388_not2091 : ~ @Equation2091 Fin4 reff388_inst.
Proof. unfold Equation2091. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff388_inst, reff388_op in H. discriminate H. Qed.

Lemma reff388_not2097 : ~ @Equation2097 Fin4 reff388_inst.
Proof. unfold Equation2097. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff388_inst, reff388_op in H. discriminate H. Qed.

Lemma reff388_not2098 : ~ @Equation2098 Fin4 reff388_inst.
Proof. unfold Equation2098. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff388_inst, reff388_op in H. discriminate H. Qed.

Lemma reff388_not2100 : ~ @Equation2100 Fin4 reff388_inst.
Proof. unfold Equation2100. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff388_inst, reff388_op in H. discriminate H. Qed.

Lemma reff388_not2124 : ~ @Equation2124 Fin4 reff388_inst.
Proof. unfold Equation2124. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff388_inst, reff388_op in H. discriminate H. Qed.

Lemma reff388_not2125 : ~ @Equation2125 Fin4 reff388_inst.
Proof. unfold Equation2125. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff388_inst, reff388_op in H. discriminate H. Qed.

Lemma reff388_not2127 : ~ @Equation2127 Fin4 reff388_inst.
Proof. unfold Equation2127. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff388_inst, reff388_op in H. discriminate H. Qed.

Lemma reff388_not2134 : ~ @Equation2134 Fin4 reff388_inst.
Proof. unfold Equation2134. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff388_inst, reff388_op in H. discriminate H. Qed.

Lemma reff388_not2239 : ~ @Equation2239 Fin4 reff388_inst.
Proof. unfold Equation2239. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff388_inst, reff388_op in H. discriminate H. Qed.

Lemma reff388_not2240 : ~ @Equation2240 Fin4 reff388_inst.
Proof. unfold Equation2240. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff388_inst, reff388_op in H. discriminate H. Qed.

Lemma reff388_not2241 : ~ @Equation2241 Fin4 reff388_inst.
Proof. unfold Equation2241. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff388_inst, reff388_op in H. discriminate H. Qed.

Lemma reff388_not2243 : ~ @Equation2243 Fin4 reff388_inst.
Proof. unfold Equation2243. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff388_inst, reff388_op in H. discriminate H. Qed.

Lemma reff388_not2244 : ~ @Equation2244 Fin4 reff388_inst.
Proof. unfold Equation2244. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff388_inst, reff388_op in H. discriminate H. Qed.

Lemma reff388_not2246 : ~ @Equation2246 Fin4 reff388_inst.
Proof. unfold Equation2246. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff388_inst, reff388_op in H. discriminate H. Qed.

Lemma reff388_not2247 : ~ @Equation2247 Fin4 reff388_inst.
Proof. unfold Equation2247. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff388_inst, reff388_op in H. discriminate H. Qed.

Lemma reff388_not2253 : ~ @Equation2253 Fin4 reff388_inst.
Proof. unfold Equation2253. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff388_inst, reff388_op in H. discriminate H. Qed.

Lemma reff388_not2254 : ~ @Equation2254 Fin4 reff388_inst.
Proof. unfold Equation2254. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff388_inst, reff388_op in H. discriminate H. Qed.

Lemma reff388_not2256 : ~ @Equation2256 Fin4 reff388_inst.
Proof. unfold Equation2256. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff388_inst, reff388_op in H. discriminate H. Qed.

Lemma reff388_not2257 : ~ @Equation2257 Fin4 reff388_inst.
Proof. unfold Equation2257. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff388_inst, reff388_op in H. discriminate H. Qed.

Lemma reff388_not2263 : ~ @Equation2263 Fin4 reff388_inst.
Proof. unfold Equation2263. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff388_inst, reff388_op in H. discriminate H. Qed.

Lemma reff388_not2264 : ~ @Equation2264 Fin4 reff388_inst.
Proof. unfold Equation2264. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff388_inst, reff388_op in H. discriminate H. Qed.

Lemma reff388_not2266 : ~ @Equation2266 Fin4 reff388_inst.
Proof. unfold Equation2266. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff388_inst, reff388_op in H. discriminate H. Qed.

Lemma reff388_not2290 : ~ @Equation2290 Fin4 reff388_inst.
Proof. unfold Equation2290. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff388_inst, reff388_op in H. discriminate H. Qed.

Lemma reff388_not2291 : ~ @Equation2291 Fin4 reff388_inst.
Proof. unfold Equation2291. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff388_inst, reff388_op in H. discriminate H. Qed.

Lemma reff388_not2293 : ~ @Equation2293 Fin4 reff388_inst.
Proof. unfold Equation2293. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff388_inst, reff388_op in H. discriminate H. Qed.

Lemma reff388_not2294 : ~ @Equation2294 Fin4 reff388_inst.
Proof. unfold Equation2294. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff388_inst, reff388_op in H. discriminate H. Qed.

Lemma reff388_not2300 : ~ @Equation2300 Fin4 reff388_inst.
Proof. unfold Equation2300. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff388_inst, reff388_op in H. discriminate H. Qed.

Lemma reff388_not2301 : ~ @Equation2301 Fin4 reff388_inst.
Proof. unfold Equation2301. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff388_inst, reff388_op in H. discriminate H. Qed.

Lemma reff388_not2303 : ~ @Equation2303 Fin4 reff388_inst.
Proof. unfold Equation2303. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff388_inst, reff388_op in H. discriminate H. Qed.

Lemma reff388_not2327 : ~ @Equation2327 Fin4 reff388_inst.
Proof. unfold Equation2327. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff388_inst, reff388_op in H. discriminate H. Qed.

Lemma reff388_not2328 : ~ @Equation2328 Fin4 reff388_inst.
Proof. unfold Equation2328. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff388_inst, reff388_op in H. discriminate H. Qed.

Lemma reff388_not2330 : ~ @Equation2330 Fin4 reff388_inst.
Proof. unfold Equation2330. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff388_inst, reff388_op in H. discriminate H. Qed.

Lemma reff388_not2337 : ~ @Equation2337 Fin4 reff388_inst.
Proof. unfold Equation2337. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff388_inst, reff388_op in H. discriminate H. Qed.

Lemma reff388_not2442 : ~ @Equation2442 Fin4 reff388_inst.
Proof. unfold Equation2442. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff388_inst, reff388_op in H. discriminate H. Qed.

Lemma reff388_not2443 : ~ @Equation2443 Fin4 reff388_inst.
Proof. unfold Equation2443. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff388_inst, reff388_op in H. discriminate H. Qed.

Lemma reff388_not2444 : ~ @Equation2444 Fin4 reff388_inst.
Proof. unfold Equation2444. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff388_inst, reff388_op in H. discriminate H. Qed.

Lemma reff388_not2446 : ~ @Equation2446 Fin4 reff388_inst.
Proof. unfold Equation2446. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff388_inst, reff388_op in H. discriminate H. Qed.

Lemma reff388_not2447 : ~ @Equation2447 Fin4 reff388_inst.
Proof. unfold Equation2447. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff388_inst, reff388_op in H. discriminate H. Qed.

Lemma reff388_not2449 : ~ @Equation2449 Fin4 reff388_inst.
Proof. unfold Equation2449. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff388_inst, reff388_op in H. discriminate H. Qed.

Lemma reff388_not2450 : ~ @Equation2450 Fin4 reff388_inst.
Proof. unfold Equation2450. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff388_inst, reff388_op in H. discriminate H. Qed.

Lemma reff388_not2456 : ~ @Equation2456 Fin4 reff388_inst.
Proof. unfold Equation2456. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff388_inst, reff388_op in H. discriminate H. Qed.

Lemma reff388_not2457 : ~ @Equation2457 Fin4 reff388_inst.
Proof. unfold Equation2457. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff388_inst, reff388_op in H. discriminate H. Qed.

Lemma reff388_not2459 : ~ @Equation2459 Fin4 reff388_inst.
Proof. unfold Equation2459. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff388_inst, reff388_op in H. discriminate H. Qed.

Lemma reff388_not2460 : ~ @Equation2460 Fin4 reff388_inst.
Proof. unfold Equation2460. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff388_inst, reff388_op in H. discriminate H. Qed.

Lemma reff388_not2466 : ~ @Equation2466 Fin4 reff388_inst.
Proof. unfold Equation2466. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff388_inst, reff388_op in H. discriminate H. Qed.

Lemma reff388_not2467 : ~ @Equation2467 Fin4 reff388_inst.
Proof. unfold Equation2467. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff388_inst, reff388_op in H. discriminate H. Qed.

Lemma reff388_not2469 : ~ @Equation2469 Fin4 reff388_inst.
Proof. unfold Equation2469. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff388_inst, reff388_op in H. discriminate H. Qed.

Lemma reff388_not2493 : ~ @Equation2493 Fin4 reff388_inst.
Proof. unfold Equation2493. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff388_inst, reff388_op in H. discriminate H. Qed.

Lemma reff388_not2494 : ~ @Equation2494 Fin4 reff388_inst.
Proof. unfold Equation2494. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff388_inst, reff388_op in H. discriminate H. Qed.

Lemma reff388_not2496 : ~ @Equation2496 Fin4 reff388_inst.
Proof. unfold Equation2496. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff388_inst, reff388_op in H. discriminate H. Qed.

Lemma reff388_not2497 : ~ @Equation2497 Fin4 reff388_inst.
Proof. unfold Equation2497. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff388_inst, reff388_op in H. discriminate H. Qed.

Lemma reff388_not2503 : ~ @Equation2503 Fin4 reff388_inst.
Proof. unfold Equation2503. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff388_inst, reff388_op in H. discriminate H. Qed.

Lemma reff388_not2504 : ~ @Equation2504 Fin4 reff388_inst.
Proof. unfold Equation2504. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff388_inst, reff388_op in H. discriminate H. Qed.

Lemma reff388_not2506 : ~ @Equation2506 Fin4 reff388_inst.
Proof. unfold Equation2506. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff388_inst, reff388_op in H. discriminate H. Qed.

Lemma reff388_not2530 : ~ @Equation2530 Fin4 reff388_inst.
Proof. unfold Equation2530. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff388_inst, reff388_op in H. discriminate H. Qed.

Lemma reff388_not2531 : ~ @Equation2531 Fin4 reff388_inst.
Proof. unfold Equation2531. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff388_inst, reff388_op in H. discriminate H. Qed.

Lemma reff388_not2533 : ~ @Equation2533 Fin4 reff388_inst.
Proof. unfold Equation2533. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff388_inst, reff388_op in H. discriminate H. Qed.

Lemma reff388_not2540 : ~ @Equation2540 Fin4 reff388_inst.
Proof. unfold Equation2540. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff388_inst, reff388_op in H. discriminate H. Qed.

Lemma reff388_not2645 : ~ @Equation2645 Fin4 reff388_inst.
Proof. unfold Equation2645. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff388_inst, reff388_op in H. discriminate H. Qed.

Lemma reff388_not2646 : ~ @Equation2646 Fin4 reff388_inst.
Proof. unfold Equation2646. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff388_inst, reff388_op in H. discriminate H. Qed.

Lemma reff388_not2647 : ~ @Equation2647 Fin4 reff388_inst.
Proof. unfold Equation2647. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff388_inst, reff388_op in H. discriminate H. Qed.

Lemma reff388_not2649 : ~ @Equation2649 Fin4 reff388_inst.
Proof. unfold Equation2649. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff388_inst, reff388_op in H. discriminate H. Qed.

Lemma reff388_not2650 : ~ @Equation2650 Fin4 reff388_inst.
Proof. unfold Equation2650. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff388_inst, reff388_op in H. discriminate H. Qed.

Lemma reff388_not2652 : ~ @Equation2652 Fin4 reff388_inst.
Proof. unfold Equation2652. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff388_inst, reff388_op in H. discriminate H. Qed.

Lemma reff388_not2653 : ~ @Equation2653 Fin4 reff388_inst.
Proof. unfold Equation2653. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff388_inst, reff388_op in H. discriminate H. Qed.

Lemma reff388_not2659 : ~ @Equation2659 Fin4 reff388_inst.
Proof. unfold Equation2659. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff388_inst, reff388_op in H. discriminate H. Qed.

Lemma reff388_not2660 : ~ @Equation2660 Fin4 reff388_inst.
Proof. unfold Equation2660. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff388_inst, reff388_op in H. discriminate H. Qed.

Lemma reff388_not2662 : ~ @Equation2662 Fin4 reff388_inst.
Proof. unfold Equation2662. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff388_inst, reff388_op in H. discriminate H. Qed.

Lemma reff388_not2663 : ~ @Equation2663 Fin4 reff388_inst.
Proof. unfold Equation2663. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff388_inst, reff388_op in H. discriminate H. Qed.

Lemma reff388_not2669 : ~ @Equation2669 Fin4 reff388_inst.
Proof. unfold Equation2669. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff388_inst, reff388_op in H. discriminate H. Qed.

Lemma reff388_not2670 : ~ @Equation2670 Fin4 reff388_inst.
Proof. unfold Equation2670. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff388_inst, reff388_op in H. discriminate H. Qed.

Lemma reff388_not2672 : ~ @Equation2672 Fin4 reff388_inst.
Proof. unfold Equation2672. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff388_inst, reff388_op in H. discriminate H. Qed.

Lemma reff388_not2696 : ~ @Equation2696 Fin4 reff388_inst.
Proof. unfold Equation2696. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff388_inst, reff388_op in H. discriminate H. Qed.

Lemma reff388_not2697 : ~ @Equation2697 Fin4 reff388_inst.
Proof. unfold Equation2697. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff388_inst, reff388_op in H. discriminate H. Qed.

Lemma reff388_not2699 : ~ @Equation2699 Fin4 reff388_inst.
Proof. unfold Equation2699. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff388_inst, reff388_op in H. discriminate H. Qed.

Lemma reff388_not2700 : ~ @Equation2700 Fin4 reff388_inst.
Proof. unfold Equation2700. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff388_inst, reff388_op in H. discriminate H. Qed.

Lemma reff388_not2706 : ~ @Equation2706 Fin4 reff388_inst.
Proof. unfold Equation2706. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff388_inst, reff388_op in H. discriminate H. Qed.

Lemma reff388_not2707 : ~ @Equation2707 Fin4 reff388_inst.
Proof. unfold Equation2707. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff388_inst, reff388_op in H. discriminate H. Qed.

Lemma reff388_not2709 : ~ @Equation2709 Fin4 reff388_inst.
Proof. unfold Equation2709. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff388_inst, reff388_op in H. discriminate H. Qed.

Lemma reff388_not2733 : ~ @Equation2733 Fin4 reff388_inst.
Proof. unfold Equation2733. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff388_inst, reff388_op in H. discriminate H. Qed.

Lemma reff388_not2734 : ~ @Equation2734 Fin4 reff388_inst.
Proof. unfold Equation2734. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff388_inst, reff388_op in H. discriminate H. Qed.

Lemma reff388_not2736 : ~ @Equation2736 Fin4 reff388_inst.
Proof. unfold Equation2736. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff388_inst, reff388_op in H. discriminate H. Qed.

Lemma reff388_not2743 : ~ @Equation2743 Fin4 reff388_inst.
Proof. unfold Equation2743. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff388_inst, reff388_op in H. discriminate H. Qed.

Lemma reff388_not2848 : ~ @Equation2848 Fin4 reff388_inst.
Proof. unfold Equation2848. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff388_inst, reff388_op in H. discriminate H. Qed.

Lemma reff388_not2849 : ~ @Equation2849 Fin4 reff388_inst.
Proof. unfold Equation2849. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff388_inst, reff388_op in H. discriminate H. Qed.

Lemma reff388_not2850 : ~ @Equation2850 Fin4 reff388_inst.
Proof. unfold Equation2850. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff388_inst, reff388_op in H. discriminate H. Qed.

Lemma reff388_not2852 : ~ @Equation2852 Fin4 reff388_inst.
Proof. unfold Equation2852. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff388_inst, reff388_op in H. discriminate H. Qed.

Lemma reff388_not2853 : ~ @Equation2853 Fin4 reff388_inst.
Proof. unfold Equation2853. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff388_inst, reff388_op in H. discriminate H. Qed.

Lemma reff388_not2855 : ~ @Equation2855 Fin4 reff388_inst.
Proof. unfold Equation2855. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff388_inst, reff388_op in H. discriminate H. Qed.

Lemma reff388_not2856 : ~ @Equation2856 Fin4 reff388_inst.
Proof. unfold Equation2856. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff388_inst, reff388_op in H. discriminate H. Qed.

Lemma reff388_not2862 : ~ @Equation2862 Fin4 reff388_inst.
Proof. unfold Equation2862. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff388_inst, reff388_op in H. discriminate H. Qed.

Lemma reff388_not2863 : ~ @Equation2863 Fin4 reff388_inst.
Proof. unfold Equation2863. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff388_inst, reff388_op in H. discriminate H. Qed.

Lemma reff388_not2865 : ~ @Equation2865 Fin4 reff388_inst.
Proof. unfold Equation2865. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff388_inst, reff388_op in H. discriminate H. Qed.

Lemma reff388_not2866 : ~ @Equation2866 Fin4 reff388_inst.
Proof. unfold Equation2866. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff388_inst, reff388_op in H. discriminate H. Qed.

Lemma reff388_not2872 : ~ @Equation2872 Fin4 reff388_inst.
Proof. unfold Equation2872. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff388_inst, reff388_op in H. discriminate H. Qed.

Lemma reff388_not2873 : ~ @Equation2873 Fin4 reff388_inst.
Proof. unfold Equation2873. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff388_inst, reff388_op in H. discriminate H. Qed.

Lemma reff388_not2875 : ~ @Equation2875 Fin4 reff388_inst.
Proof. unfold Equation2875. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff388_inst, reff388_op in H. discriminate H. Qed.

Lemma reff388_not2899 : ~ @Equation2899 Fin4 reff388_inst.
Proof. unfold Equation2899. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff388_inst, reff388_op in H. discriminate H. Qed.

Lemma reff388_not2900 : ~ @Equation2900 Fin4 reff388_inst.
Proof. unfold Equation2900. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff388_inst, reff388_op in H. discriminate H. Qed.

Lemma reff388_not2902 : ~ @Equation2902 Fin4 reff388_inst.
Proof. unfold Equation2902. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff388_inst, reff388_op in H. discriminate H. Qed.

Lemma reff388_not2903 : ~ @Equation2903 Fin4 reff388_inst.
Proof. unfold Equation2903. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff388_inst, reff388_op in H. discriminate H. Qed.

Lemma reff388_not2909 : ~ @Equation2909 Fin4 reff388_inst.
Proof. unfold Equation2909. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff388_inst, reff388_op in H. discriminate H. Qed.

Lemma reff388_not2910 : ~ @Equation2910 Fin4 reff388_inst.
Proof. unfold Equation2910. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff388_inst, reff388_op in H. discriminate H. Qed.

Lemma reff388_not2912 : ~ @Equation2912 Fin4 reff388_inst.
Proof. unfold Equation2912. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff388_inst, reff388_op in H. discriminate H. Qed.

Lemma reff388_not2936 : ~ @Equation2936 Fin4 reff388_inst.
Proof. unfold Equation2936. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff388_inst, reff388_op in H. discriminate H. Qed.

Lemma reff388_not2937 : ~ @Equation2937 Fin4 reff388_inst.
Proof. unfold Equation2937. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff388_inst, reff388_op in H. discriminate H. Qed.

Lemma reff388_not2939 : ~ @Equation2939 Fin4 reff388_inst.
Proof. unfold Equation2939. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff388_inst, reff388_op in H. discriminate H. Qed.

Lemma reff388_not2946 : ~ @Equation2946 Fin4 reff388_inst.
Proof. unfold Equation2946. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff388_inst, reff388_op in H. discriminate H. Qed.

Lemma reff388_not3051 : ~ @Equation3051 Fin4 reff388_inst.
Proof. unfold Equation3051. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff388_inst, reff388_op in H. discriminate H. Qed.

Lemma reff388_not3052 : ~ @Equation3052 Fin4 reff388_inst.
Proof. unfold Equation3052. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff388_inst, reff388_op in H. discriminate H. Qed.

Lemma reff388_not3053 : ~ @Equation3053 Fin4 reff388_inst.
Proof. unfold Equation3053. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff388_inst, reff388_op in H. discriminate H. Qed.

Lemma reff388_not3055 : ~ @Equation3055 Fin4 reff388_inst.
Proof. unfold Equation3055. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff388_inst, reff388_op in H. discriminate H. Qed.

Lemma reff388_not3056 : ~ @Equation3056 Fin4 reff388_inst.
Proof. unfold Equation3056. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff388_inst, reff388_op in H. discriminate H. Qed.

Lemma reff388_not3058 : ~ @Equation3058 Fin4 reff388_inst.
Proof. unfold Equation3058. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff388_inst, reff388_op in H. discriminate H. Qed.

Lemma reff388_not3059 : ~ @Equation3059 Fin4 reff388_inst.
Proof. unfold Equation3059. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff388_inst, reff388_op in H. discriminate H. Qed.

Lemma reff388_not3065 : ~ @Equation3065 Fin4 reff388_inst.
Proof. unfold Equation3065. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff388_inst, reff388_op in H. discriminate H. Qed.

Lemma reff388_not3066 : ~ @Equation3066 Fin4 reff388_inst.
Proof. unfold Equation3066. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff388_inst, reff388_op in H. discriminate H. Qed.

Lemma reff388_not3068 : ~ @Equation3068 Fin4 reff388_inst.
Proof. unfold Equation3068. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff388_inst, reff388_op in H. discriminate H. Qed.

Lemma reff388_not3069 : ~ @Equation3069 Fin4 reff388_inst.
Proof. unfold Equation3069. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff388_inst, reff388_op in H. discriminate H. Qed.

Lemma reff388_not3075 : ~ @Equation3075 Fin4 reff388_inst.
Proof. unfold Equation3075. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff388_inst, reff388_op in H. discriminate H. Qed.

Lemma reff388_not3076 : ~ @Equation3076 Fin4 reff388_inst.
Proof. unfold Equation3076. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff388_inst, reff388_op in H. discriminate H. Qed.

Lemma reff388_not3078 : ~ @Equation3078 Fin4 reff388_inst.
Proof. unfold Equation3078. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff388_inst, reff388_op in H. discriminate H. Qed.

Lemma reff388_not3102 : ~ @Equation3102 Fin4 reff388_inst.
Proof. unfold Equation3102. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff388_inst, reff388_op in H. discriminate H. Qed.

Lemma reff388_not3103 : ~ @Equation3103 Fin4 reff388_inst.
Proof. unfold Equation3103. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff388_inst, reff388_op in H. discriminate H. Qed.

Lemma reff388_not3105 : ~ @Equation3105 Fin4 reff388_inst.
Proof. unfold Equation3105. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff388_inst, reff388_op in H. discriminate H. Qed.

Lemma reff388_not3106 : ~ @Equation3106 Fin4 reff388_inst.
Proof. unfold Equation3106. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff388_inst, reff388_op in H. discriminate H. Qed.

Lemma reff388_not3112 : ~ @Equation3112 Fin4 reff388_inst.
Proof. unfold Equation3112. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff388_inst, reff388_op in H. discriminate H. Qed.

Lemma reff388_not3113 : ~ @Equation3113 Fin4 reff388_inst.
Proof. unfold Equation3113. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff388_inst, reff388_op in H. discriminate H. Qed.

Lemma reff388_not3115 : ~ @Equation3115 Fin4 reff388_inst.
Proof. unfold Equation3115. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff388_inst, reff388_op in H. discriminate H. Qed.

Lemma reff388_not3139 : ~ @Equation3139 Fin4 reff388_inst.
Proof. unfold Equation3139. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff388_inst, reff388_op in H. discriminate H. Qed.

Lemma reff388_not3140 : ~ @Equation3140 Fin4 reff388_inst.
Proof. unfold Equation3140. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff388_inst, reff388_op in H. discriminate H. Qed.

Lemma reff388_not3142 : ~ @Equation3142 Fin4 reff388_inst.
Proof. unfold Equation3142. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff388_inst, reff388_op in H. discriminate H. Qed.

Lemma reff388_not3149 : ~ @Equation3149 Fin4 reff388_inst.
Proof. unfold Equation3149. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff388_inst, reff388_op in H. discriminate H. Qed.

Lemma reff388_not3253 : ~ @Equation3253 Fin4 reff388_inst.
Proof. unfold Equation3253. intro H. specialize (H F4_1). unfold magma_op, reff388_inst, reff388_op in H. discriminate H. Qed.

Lemma reff388_not3456 : ~ @Equation3456 Fin4 reff388_inst.
Proof. unfold Equation3456. intro H. specialize (H F4_1). unfold magma_op, reff388_inst, reff388_op in H. discriminate H. Qed.

Lemma reff388_not3659 : ~ @Equation3659 Fin4 reff388_inst.
Proof. unfold Equation3659. intro H. specialize (H F4_1). unfold magma_op, reff388_inst, reff388_op in H. discriminate H. Qed.

Lemma reff388_not3862 : ~ @Equation3862 Fin4 reff388_inst.
Proof. unfold Equation3862. intro H. specialize (H F4_1). unfold magma_op, reff388_inst, reff388_op in H. discriminate H. Qed.

Lemma reff388_not4065 : ~ @Equation4065 Fin4 reff388_inst.
Proof. unfold Equation4065. intro H. specialize (H F4_1). unfold magma_op, reff388_inst, reff388_op in H. discriminate H. Qed.

Lemma reff388_not4268 : ~ @Equation4268 Fin4 reff388_inst.
Proof. unfold Equation4268. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff388_inst, reff388_op in H. discriminate H. Qed.

Lemma reff388_not4269 : ~ @Equation4269 Fin4 reff388_inst.
Proof. unfold Equation4269. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff388_inst, reff388_op in H. discriminate H. Qed.

Lemma reff388_not4270 : ~ @Equation4270 Fin4 reff388_inst.
Proof. unfold Equation4270. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff388_inst, reff388_op in H. discriminate H. Qed.

Lemma reff388_not4272 : ~ @Equation4272 Fin4 reff388_inst.
Proof. unfold Equation4272. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff388_inst, reff388_op in H. discriminate H. Qed.

Lemma reff388_not4273 : ~ @Equation4273 Fin4 reff388_inst.
Proof. unfold Equation4273. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff388_inst, reff388_op in H. discriminate H. Qed.

Lemma reff388_not4275 : ~ @Equation4275 Fin4 reff388_inst.
Proof. unfold Equation4275. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff388_inst, reff388_op in H. discriminate H. Qed.

Lemma reff388_not4276 : ~ @Equation4276 Fin4 reff388_inst.
Proof. unfold Equation4276. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff388_inst, reff388_op in H. discriminate H. Qed.

Lemma reff388_not4284 : ~ @Equation4284 Fin4 reff388_inst.
Proof. unfold Equation4284. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff388_inst, reff388_op in H. discriminate H. Qed.

Lemma reff388_not4291 : ~ @Equation4291 Fin4 reff388_inst.
Proof. unfold Equation4291. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff388_inst, reff388_op in H. discriminate H. Qed.

Lemma reff388_not4293 : ~ @Equation4293 Fin4 reff388_inst.
Proof. unfold Equation4293. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff388_inst, reff388_op in H. discriminate H. Qed.

Lemma reff388_not4314 : ~ @Equation4314 Fin4 reff388_inst.
Proof. unfold Equation4314. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff388_inst, reff388_op in H. discriminate H. Qed.

Lemma reff388_not4321 : ~ @Equation4321 Fin4 reff388_inst.
Proof. unfold Equation4321. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff388_inst, reff388_op in H. discriminate H. Qed.

Lemma reff388_not4343 : ~ @Equation4343 Fin4 reff388_inst.
Proof. unfold Equation4343. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff388_inst, reff388_op in H. discriminate H. Qed.

Lemma reff388_not4399 : ~ @Equation4399 Fin4 reff388_inst.
Proof. unfold Equation4399. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff388_inst, reff388_op in H. discriminate H. Qed.

Lemma reff388_not4406 : ~ @Equation4406 Fin4 reff388_inst.
Proof. unfold Equation4406. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff388_inst, reff388_op in H. discriminate H. Qed.

Lemma reff388_not4408 : ~ @Equation4408 Fin4 reff388_inst.
Proof. unfold Equation4408. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff388_inst, reff388_op in H. discriminate H. Qed.

Lemma reff388_not4436 : ~ @Equation4436 Fin4 reff388_inst.
Proof. unfold Equation4436. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff388_inst, reff388_op in H. discriminate H. Qed.

Lemma reff388_not4443 : ~ @Equation4443 Fin4 reff388_inst.
Proof. unfold Equation4443. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff388_inst, reff388_op in H. discriminate H. Qed.

Lemma reff388_not4445 : ~ @Equation4445 Fin4 reff388_inst.
Proof. unfold Equation4445. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff388_inst, reff388_op in H. discriminate H. Qed.

Lemma reff388_not4470 : ~ @Equation4470 Fin4 reff388_inst.
Proof. unfold Equation4470. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff388_inst, reff388_op in H. discriminate H. Qed.

Lemma reff388_not4472 : ~ @Equation4472 Fin4 reff388_inst.
Proof. unfold Equation4472. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff388_inst, reff388_op in H. discriminate H. Qed.

Lemma reff388_not4479 : ~ @Equation4479 Fin4 reff388_inst.
Proof. unfold Equation4479. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff388_inst, reff388_op in H. discriminate H. Qed.

Lemma reff388_not4583 : ~ @Equation4583 Fin4 reff388_inst.
Proof. unfold Equation4583. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff388_inst, reff388_op in H. discriminate H. Qed.

Lemma reff388_not4584 : ~ @Equation4584 Fin4 reff388_inst.
Proof. unfold Equation4584. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff388_inst, reff388_op in H. discriminate H. Qed.

Lemma reff388_not4585 : ~ @Equation4585 Fin4 reff388_inst.
Proof. unfold Equation4585. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff388_inst, reff388_op in H. discriminate H. Qed.

Lemma reff388_not4587 : ~ @Equation4587 Fin4 reff388_inst.
Proof. unfold Equation4587. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff388_inst, reff388_op in H. discriminate H. Qed.

Lemma reff388_not4588 : ~ @Equation4588 Fin4 reff388_inst.
Proof. unfold Equation4588. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff388_inst, reff388_op in H. discriminate H. Qed.

Lemma reff388_not4590 : ~ @Equation4590 Fin4 reff388_inst.
Proof. unfold Equation4590. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff388_inst, reff388_op in H. discriminate H. Qed.

Lemma reff388_not4591 : ~ @Equation4591 Fin4 reff388_inst.
Proof. unfold Equation4591. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff388_inst, reff388_op in H. discriminate H. Qed.

Lemma reff388_not4599 : ~ @Equation4599 Fin4 reff388_inst.
Proof. unfold Equation4599. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff388_inst, reff388_op in H. discriminate H. Qed.

Lemma reff388_not4606 : ~ @Equation4606 Fin4 reff388_inst.
Proof. unfold Equation4606. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff388_inst, reff388_op in H. discriminate H. Qed.

Lemma reff388_not4608 : ~ @Equation4608 Fin4 reff388_inst.
Proof. unfold Equation4608. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff388_inst, reff388_op in H. discriminate H. Qed.

Lemma reff388_not4629 : ~ @Equation4629 Fin4 reff388_inst.
Proof. unfold Equation4629. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff388_inst, reff388_op in H. discriminate H. Qed.

Lemma reff388_not4636 : ~ @Equation4636 Fin4 reff388_inst.
Proof. unfold Equation4636. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff388_inst, reff388_op in H. discriminate H. Qed.

Lemma reff388_not4658 : ~ @Equation4658 Fin4 reff388_inst.
Proof. unfold Equation4658. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff388_inst, reff388_op in H. discriminate H. Qed.

(** ---- reff390 (Fin4) ---- *)

Definition reff390_op (x y : Fin4) : Fin4 :=
  match x, y with
  | F4_0, F4_0 => F4_0 | F4_0, F4_1 => F4_0 | F4_0, F4_2 => F4_0 | F4_0, F4_3 => F4_0
  | F4_1, F4_0 => F4_3 | F4_1, F4_1 => F4_1 | F4_1, F4_2 => F4_3 | F4_1, F4_3 => F4_1
  | F4_2, F4_0 => F4_2 | F4_2, F4_1 => F4_2 | F4_2, F4_2 => F4_2 | F4_2, F4_3 => F4_2
  | F4_3, F4_0 => F4_1 | F4_3, F4_1 => F4_3 | F4_3, F4_2 => F4_1 | F4_3, F4_3 => F4_3
  end.

#[local] Instance reff390_inst : Magma Fin4 := {| magma_op := reff390_op |}.

Lemma reff390_sat9 : @Equation9 Fin4 reff390_inst.
Proof. unfold Equation9, magma_op, reff390_inst, reff390_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff390_sat26 : @Equation26 Fin4 reff390_inst.
Proof. unfold Equation26, magma_op, reff390_inst, reff390_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff390_sat103 : @Equation103 Fin4 reff390_inst.
Proof. unfold Equation103, magma_op, reff390_inst, reff390_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff390_sat161 : @Equation161 Fin4 reff390_inst.
Proof. unfold Equation161, magma_op, reff390_inst, reff390_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff390_sat215 : @Equation215 Fin4 reff390_inst.
Proof. unfold Equation215, magma_op, reff390_inst, reff390_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff390_sat258 : @Equation258 Fin4 reff390_inst.
Proof. unfold Equation258, magma_op, reff390_inst, reff390_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff390_sat261 : @Equation261 Fin4 reff390_inst.
Proof. unfold Equation261, magma_op, reff390_inst, reff390_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff390_sat263 : @Equation263 Fin4 reff390_inst.
Proof. unfold Equation263, magma_op, reff390_inst, reff390_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff390_sat327 : @Equation327 Fin4 reff390_inst.
Proof. unfold Equation327, magma_op, reff390_inst, reff390_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff390_sat362 : @Equation362 Fin4 reff390_inst.
Proof. unfold Equation362, magma_op, reff390_inst, reff390_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff390_sat377 : @Equation377 Fin4 reff390_inst.
Proof. unfold Equation377, magma_op, reff390_inst, reff390_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff390_sat1237 : @Equation1237 Fin4 reff390_inst.
Proof. unfold Equation1237, magma_op, reff390_inst, reff390_op. intros x y z w. destruct x, y, z, w; reflexivity. Qed.

Lemma reff390_sat1663 : @Equation1663 Fin4 reff390_inst.
Proof. unfold Equation1663, magma_op, reff390_inst, reff390_op. intros x y z w. destruct x, y, z, w; reflexivity. Qed.

Lemma reff390_sat1874 : @Equation1874 Fin4 reff390_inst.
Proof. unfold Equation1874, magma_op, reff390_inst, reff390_op. intros x y z w. destruct x, y, z, w; reflexivity. Qed.

Lemma reff390_sat2045 : @Equation2045 Fin4 reff390_inst.
Proof. unfold Equation2045, magma_op, reff390_inst, reff390_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff390_sat2055 : @Equation2055 Fin4 reff390_inst.
Proof. unfold Equation2055, magma_op, reff390_inst, reff390_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff390_sat2062 : @Equation2062 Fin4 reff390_inst.
Proof. unfold Equation2062, magma_op, reff390_inst, reff390_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff390_sat2489 : @Equation2489 Fin4 reff390_inst.
Proof. unfold Equation2489, magma_op, reff390_inst, reff390_op. intros x y z w. destruct x, y, z, w; reflexivity. Qed.

Lemma reff390_sat2656 : @Equation2656 Fin4 reff390_inst.
Proof. unfold Equation2656, magma_op, reff390_inst, reff390_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff390_sat2666 : @Equation2666 Fin4 reff390_inst.
Proof. unfold Equation2666, magma_op, reff390_inst, reff390_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff390_sat2675 : @Equation2675 Fin4 reff390_inst.
Proof. unfold Equation2675, magma_op, reff390_inst, reff390_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff390_sat2860 : @Equation2860 Fin4 reff390_inst.
Proof. unfold Equation2860, magma_op, reff390_inst, reff390_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff390_sat2883 : @Equation2883 Fin4 reff390_inst.
Proof. unfold Equation2883, magma_op, reff390_inst, reff390_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff390_sat2886 : @Equation2886 Fin4 reff390_inst.
Proof. unfold Equation2886, magma_op, reff390_inst, reff390_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff390_sat3091 : @Equation3091 Fin4 reff390_inst.
Proof. unfold Equation3091, magma_op, reff390_inst, reff390_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff390_sat3669 : @Equation3669 Fin4 reff390_inst.
Proof. unfold Equation3669, magma_op, reff390_inst, reff390_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff390_sat3716 : @Equation3716 Fin4 reff390_inst.
Proof. unfold Equation3716, magma_op, reff390_inst, reff390_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff390_sat3723 : @Equation3723 Fin4 reff390_inst.
Proof. unfold Equation3723, magma_op, reff390_inst, reff390_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff390_sat3874 : @Equation3874 Fin4 reff390_inst.
Proof. unfold Equation3874, magma_op, reff390_inst, reff390_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff390_sat3930 : @Equation3930 Fin4 reff390_inst.
Proof. unfold Equation3930, magma_op, reff390_inst, reff390_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff390_sat4143 : @Equation4143 Fin4 reff390_inst.
Proof. unfold Equation4143, magma_op, reff390_inst, reff390_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff390_sat4403 : @Equation4403 Fin4 reff390_inst.
Proof. unfold Equation4403, magma_op, reff390_inst, reff390_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff390_sat4507 : @Equation4507 Fin4 reff390_inst.
Proof. unfold Equation4507, magma_op, reff390_inst, reff390_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff390_sat4510 : @Equation4510 Fin4 reff390_inst.
Proof. unfold Equation4510, magma_op, reff390_inst, reff390_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff390_sat4673 : @Equation4673 Fin4 reff390_inst.
Proof. unfold Equation4673, magma_op, reff390_inst, reff390_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff390_not53 : ~ @Equation53 Fin4 reff390_inst.
Proof. unfold Equation53. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff390_inst, reff390_op in H. discriminate H. Qed.

Lemma reff390_not55 : ~ @Equation55 Fin4 reff390_inst.
Proof. unfold Equation55. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff390_inst, reff390_op in H. discriminate H. Qed.

Lemma reff390_not56 : ~ @Equation56 Fin4 reff390_inst.
Proof. unfold Equation56. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff390_inst, reff390_op in H. discriminate H. Qed.

Lemma reff390_not63 : ~ @Equation63 Fin4 reff390_inst.
Proof. unfold Equation63. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff390_inst, reff390_op in H. discriminate H. Qed.

Lemma reff390_not65 : ~ @Equation65 Fin4 reff390_inst.
Proof. unfold Equation65. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff390_inst, reff390_op in H. discriminate H. Qed.

Lemma reff390_not66 : ~ @Equation66 Fin4 reff390_inst.
Proof. unfold Equation66. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff390_inst, reff390_op in H. discriminate H. Qed.

Lemma reff390_not72 : ~ @Equation72 Fin4 reff390_inst.
Proof. unfold Equation72. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff390_inst, reff390_op in H. discriminate H. Qed.

Lemma reff390_not73 : ~ @Equation73 Fin4 reff390_inst.
Proof. unfold Equation73. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff390_inst, reff390_op in H. discriminate H. Qed.

Lemma reff390_not75 : ~ @Equation75 Fin4 reff390_inst.
Proof. unfold Equation75. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff390_inst, reff390_op in H. discriminate H. Qed.

Lemma reff390_not105 : ~ @Equation105 Fin4 reff390_inst.
Proof. unfold Equation105. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff390_inst, reff390_op in H. discriminate H. Qed.

Lemma reff390_not107 : ~ @Equation107 Fin4 reff390_inst.
Proof. unfold Equation107. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff390_inst, reff390_op in H. discriminate H. Qed.

Lemma reff390_not108 : ~ @Equation108 Fin4 reff390_inst.
Proof. unfold Equation108. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff390_inst, reff390_op in H. discriminate H. Qed.

Lemma reff390_not115 : ~ @Equation115 Fin4 reff390_inst.
Proof. unfold Equation115. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff390_inst, reff390_op in H. discriminate H. Qed.

Lemma reff390_not117 : ~ @Equation117 Fin4 reff390_inst.
Proof. unfold Equation117. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff390_inst, reff390_op in H. discriminate H. Qed.

Lemma reff390_not118 : ~ @Equation118 Fin4 reff390_inst.
Proof. unfold Equation118. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff390_inst, reff390_op in H. discriminate H. Qed.

Lemma reff390_not124 : ~ @Equation124 Fin4 reff390_inst.
Proof. unfold Equation124. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff390_inst, reff390_op in H. discriminate H. Qed.

Lemma reff390_not125 : ~ @Equation125 Fin4 reff390_inst.
Proof. unfold Equation125. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff390_inst, reff390_op in H. discriminate H. Qed.

Lemma reff390_not127 : ~ @Equation127 Fin4 reff390_inst.
Proof. unfold Equation127. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff390_inst, reff390_op in H. discriminate H. Qed.

Lemma reff390_not154 : ~ @Equation154 Fin4 reff390_inst.
Proof. unfold Equation154. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff390_inst, reff390_op in H. discriminate H. Qed.

Lemma reff390_not157 : ~ @Equation157 Fin4 reff390_inst.
Proof. unfold Equation157. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff390_inst, reff390_op in H. discriminate H. Qed.

Lemma reff390_not167 : ~ @Equation167 Fin4 reff390_inst.
Proof. unfold Equation167. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff390_inst, reff390_op in H. discriminate H. Qed.

Lemma reff390_not169 : ~ @Equation169 Fin4 reff390_inst.
Proof. unfold Equation169. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff390_inst, reff390_op in H. discriminate H. Qed.

Lemma reff390_not170 : ~ @Equation170 Fin4 reff390_inst.
Proof. unfold Equation170. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff390_inst, reff390_op in H. discriminate H. Qed.

Lemma reff390_not176 : ~ @Equation176 Fin4 reff390_inst.
Proof. unfold Equation176. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff390_inst, reff390_op in H. discriminate H. Qed.

Lemma reff390_not177 : ~ @Equation177 Fin4 reff390_inst.
Proof. unfold Equation177. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff390_inst, reff390_op in H. discriminate H. Qed.

Lemma reff390_not179 : ~ @Equation179 Fin4 reff390_inst.
Proof. unfold Equation179. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff390_inst, reff390_op in H. discriminate H. Qed.

Lemma reff390_not206 : ~ @Equation206 Fin4 reff390_inst.
Proof. unfold Equation206. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff390_inst, reff390_op in H. discriminate H. Qed.

Lemma reff390_not211 : ~ @Equation211 Fin4 reff390_inst.
Proof. unfold Equation211. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff390_inst, reff390_op in H. discriminate H. Qed.

Lemma reff390_not219 : ~ @Equation219 Fin4 reff390_inst.
Proof. unfold Equation219. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff390_inst, reff390_op in H. discriminate H. Qed.

Lemma reff390_not221 : ~ @Equation221 Fin4 reff390_inst.
Proof. unfold Equation221. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff390_inst, reff390_op in H. discriminate H. Qed.

Lemma reff390_not222 : ~ @Equation222 Fin4 reff390_inst.
Proof. unfold Equation222. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff390_inst, reff390_op in H. discriminate H. Qed.

Lemma reff390_not228 : ~ @Equation228 Fin4 reff390_inst.
Proof. unfold Equation228. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff390_inst, reff390_op in H. discriminate H. Qed.

Lemma reff390_not229 : ~ @Equation229 Fin4 reff390_inst.
Proof. unfold Equation229. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff390_inst, reff390_op in H. discriminate H. Qed.

Lemma reff390_not231 : ~ @Equation231 Fin4 reff390_inst.
Proof. unfold Equation231. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff390_inst, reff390_op in H. discriminate H. Qed.

Lemma reff390_not264 : ~ @Equation264 Fin4 reff390_inst.
Proof. unfold Equation264. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff390_inst, reff390_op in H. discriminate H. Qed.

Lemma reff390_not271 : ~ @Equation271 Fin4 reff390_inst.
Proof. unfold Equation271. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff390_inst, reff390_op in H. discriminate H. Qed.

Lemma reff390_not273 : ~ @Equation273 Fin4 reff390_inst.
Proof. unfold Equation273. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff390_inst, reff390_op in H. discriminate H. Qed.

Lemma reff390_not274 : ~ @Equation274 Fin4 reff390_inst.
Proof. unfold Equation274. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff390_inst, reff390_op in H. discriminate H. Qed.

Lemma reff390_not280 : ~ @Equation280 Fin4 reff390_inst.
Proof. unfold Equation280. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff390_inst, reff390_op in H. discriminate H. Qed.

Lemma reff390_not281 : ~ @Equation281 Fin4 reff390_inst.
Proof. unfold Equation281. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff390_inst, reff390_op in H. discriminate H. Qed.

Lemma reff390_not283 : ~ @Equation283 Fin4 reff390_inst.
Proof. unfold Equation283. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff390_inst, reff390_op in H. discriminate H. Qed.

Lemma reff390_not378 : ~ @Equation378 Fin4 reff390_inst.
Proof. unfold Equation378. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff390_inst, reff390_op in H. discriminate H. Qed.

Lemma reff390_not426 : ~ @Equation426 Fin4 reff390_inst.
Proof. unfold Equation426. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff390_inst, reff390_op in H. discriminate H. Qed.

Lemma reff390_not427 : ~ @Equation427 Fin4 reff390_inst.
Proof. unfold Equation427. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff390_inst, reff390_op in H. discriminate H. Qed.

Lemma reff390_not429 : ~ @Equation429 Fin4 reff390_inst.
Proof. unfold Equation429. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff390_inst, reff390_op in H. discriminate H. Qed.

Lemma reff390_not430 : ~ @Equation430 Fin4 reff390_inst.
Proof. unfold Equation430. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff390_inst, reff390_op in H. discriminate H. Qed.

Lemma reff390_not436 : ~ @Equation436 Fin4 reff390_inst.
Proof. unfold Equation436. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff390_inst, reff390_op in H. discriminate H. Qed.

Lemma reff390_not437 : ~ @Equation437 Fin4 reff390_inst.
Proof. unfold Equation437. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff390_inst, reff390_op in H. discriminate H. Qed.

Lemma reff390_not439 : ~ @Equation439 Fin4 reff390_inst.
Proof. unfold Equation439. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff390_inst, reff390_op in H. discriminate H. Qed.

Lemma reff390_not440 : ~ @Equation440 Fin4 reff390_inst.
Proof. unfold Equation440. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff390_inst, reff390_op in H. discriminate H. Qed.

Lemma reff390_not463 : ~ @Equation463 Fin4 reff390_inst.
Proof. unfold Equation463. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff390_inst, reff390_op in H. discriminate H. Qed.

Lemma reff390_not464 : ~ @Equation464 Fin4 reff390_inst.
Proof. unfold Equation464. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff390_inst, reff390_op in H. discriminate H. Qed.

Lemma reff390_not466 : ~ @Equation466 Fin4 reff390_inst.
Proof. unfold Equation466. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff390_inst, reff390_op in H. discriminate H. Qed.

Lemma reff390_not467 : ~ @Equation467 Fin4 reff390_inst.
Proof. unfold Equation467. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff390_inst, reff390_op in H. discriminate H. Qed.

Lemma reff390_not473 : ~ @Equation473 Fin4 reff390_inst.
Proof. unfold Equation473. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff390_inst, reff390_op in H. discriminate H. Qed.

Lemma reff390_not474 : ~ @Equation474 Fin4 reff390_inst.
Proof. unfold Equation474. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff390_inst, reff390_op in H. discriminate H. Qed.

Lemma reff390_not476 : ~ @Equation476 Fin4 reff390_inst.
Proof. unfold Equation476. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff390_inst, reff390_op in H. discriminate H. Qed.

Lemma reff390_not477 : ~ @Equation477 Fin4 reff390_inst.
Proof. unfold Equation477. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff390_inst, reff390_op in H. discriminate H. Qed.

Lemma reff390_not500 : ~ @Equation500 Fin4 reff390_inst.
Proof. unfold Equation500. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff390_inst, reff390_op in H. discriminate H. Qed.

Lemma reff390_not501 : ~ @Equation501 Fin4 reff390_inst.
Proof. unfold Equation501. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff390_inst, reff390_op in H. discriminate H. Qed.

Lemma reff390_not503 : ~ @Equation503 Fin4 reff390_inst.
Proof. unfold Equation503. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff390_inst, reff390_op in H. discriminate H. Qed.

Lemma reff390_not504 : ~ @Equation504 Fin4 reff390_inst.
Proof. unfold Equation504. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff390_inst, reff390_op in H. discriminate H. Qed.

Lemma reff390_not510 : ~ @Equation510 Fin4 reff390_inst.
Proof. unfold Equation510. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff390_inst, reff390_op in H. discriminate H. Qed.

Lemma reff390_not511 : ~ @Equation511 Fin4 reff390_inst.
Proof. unfold Equation511. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff390_inst, reff390_op in H. discriminate H. Qed.

Lemma reff390_not513 : ~ @Equation513 Fin4 reff390_inst.
Proof. unfold Equation513. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff390_inst, reff390_op in H. discriminate H. Qed.

Lemma reff390_not629 : ~ @Equation629 Fin4 reff390_inst.
Proof. unfold Equation629. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff390_inst, reff390_op in H. discriminate H. Qed.

Lemma reff390_not630 : ~ @Equation630 Fin4 reff390_inst.
Proof. unfold Equation630. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff390_inst, reff390_op in H. discriminate H. Qed.

Lemma reff390_not632 : ~ @Equation632 Fin4 reff390_inst.
Proof. unfold Equation632. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff390_inst, reff390_op in H. discriminate H. Qed.

Lemma reff390_not633 : ~ @Equation633 Fin4 reff390_inst.
Proof. unfold Equation633. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff390_inst, reff390_op in H. discriminate H. Qed.

Lemma reff390_not639 : ~ @Equation639 Fin4 reff390_inst.
Proof. unfold Equation639. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff390_inst, reff390_op in H. discriminate H. Qed.

Lemma reff390_not640 : ~ @Equation640 Fin4 reff390_inst.
Proof. unfold Equation640. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff390_inst, reff390_op in H. discriminate H. Qed.

Lemma reff390_not642 : ~ @Equation642 Fin4 reff390_inst.
Proof. unfold Equation642. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff390_inst, reff390_op in H. discriminate H. Qed.

Lemma reff390_not643 : ~ @Equation643 Fin4 reff390_inst.
Proof. unfold Equation643. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff390_inst, reff390_op in H. discriminate H. Qed.

Lemma reff390_not666 : ~ @Equation666 Fin4 reff390_inst.
Proof. unfold Equation666. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff390_inst, reff390_op in H. discriminate H. Qed.

Lemma reff390_not667 : ~ @Equation667 Fin4 reff390_inst.
Proof. unfold Equation667. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff390_inst, reff390_op in H. discriminate H. Qed.

Lemma reff390_not669 : ~ @Equation669 Fin4 reff390_inst.
Proof. unfold Equation669. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff390_inst, reff390_op in H. discriminate H. Qed.

Lemma reff390_not670 : ~ @Equation670 Fin4 reff390_inst.
Proof. unfold Equation670. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff390_inst, reff390_op in H. discriminate H. Qed.

Lemma reff390_not676 : ~ @Equation676 Fin4 reff390_inst.
Proof. unfold Equation676. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff390_inst, reff390_op in H. discriminate H. Qed.

Lemma reff390_not677 : ~ @Equation677 Fin4 reff390_inst.
Proof. unfold Equation677. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff390_inst, reff390_op in H. discriminate H. Qed.

Lemma reff390_not679 : ~ @Equation679 Fin4 reff390_inst.
Proof. unfold Equation679. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff390_inst, reff390_op in H. discriminate H. Qed.

Lemma reff390_not680 : ~ @Equation680 Fin4 reff390_inst.
Proof. unfold Equation680. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff390_inst, reff390_op in H. discriminate H. Qed.

Lemma reff390_not703 : ~ @Equation703 Fin4 reff390_inst.
Proof. unfold Equation703. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff390_inst, reff390_op in H. discriminate H. Qed.

Lemma reff390_not704 : ~ @Equation704 Fin4 reff390_inst.
Proof. unfold Equation704. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff390_inst, reff390_op in H. discriminate H. Qed.

Lemma reff390_not706 : ~ @Equation706 Fin4 reff390_inst.
Proof. unfold Equation706. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff390_inst, reff390_op in H. discriminate H. Qed.

Lemma reff390_not707 : ~ @Equation707 Fin4 reff390_inst.
Proof. unfold Equation707. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff390_inst, reff390_op in H. discriminate H. Qed.

Lemma reff390_not713 : ~ @Equation713 Fin4 reff390_inst.
Proof. unfold Equation713. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff390_inst, reff390_op in H. discriminate H. Qed.

Lemma reff390_not714 : ~ @Equation714 Fin4 reff390_inst.
Proof. unfold Equation714. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff390_inst, reff390_op in H. discriminate H. Qed.

Lemma reff390_not716 : ~ @Equation716 Fin4 reff390_inst.
Proof. unfold Equation716. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff390_inst, reff390_op in H. discriminate H. Qed.

Lemma reff390_not832 : ~ @Equation832 Fin4 reff390_inst.
Proof. unfold Equation832. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff390_inst, reff390_op in H. discriminate H. Qed.

Lemma reff390_not833 : ~ @Equation833 Fin4 reff390_inst.
Proof. unfold Equation833. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff390_inst, reff390_op in H. discriminate H. Qed.

Lemma reff390_not835 : ~ @Equation835 Fin4 reff390_inst.
Proof. unfold Equation835. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff390_inst, reff390_op in H. discriminate H. Qed.

Lemma reff390_not836 : ~ @Equation836 Fin4 reff390_inst.
Proof. unfold Equation836. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff390_inst, reff390_op in H. discriminate H. Qed.

Lemma reff390_not842 : ~ @Equation842 Fin4 reff390_inst.
Proof. unfold Equation842. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff390_inst, reff390_op in H. discriminate H. Qed.

Lemma reff390_not843 : ~ @Equation843 Fin4 reff390_inst.
Proof. unfold Equation843. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff390_inst, reff390_op in H. discriminate H. Qed.

Lemma reff390_not845 : ~ @Equation845 Fin4 reff390_inst.
Proof. unfold Equation845. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff390_inst, reff390_op in H. discriminate H. Qed.

Lemma reff390_not846 : ~ @Equation846 Fin4 reff390_inst.
Proof. unfold Equation846. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff390_inst, reff390_op in H. discriminate H. Qed.

Lemma reff390_not869 : ~ @Equation869 Fin4 reff390_inst.
Proof. unfold Equation869. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff390_inst, reff390_op in H. discriminate H. Qed.

Lemma reff390_not870 : ~ @Equation870 Fin4 reff390_inst.
Proof. unfold Equation870. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff390_inst, reff390_op in H. discriminate H. Qed.

Lemma reff390_not872 : ~ @Equation872 Fin4 reff390_inst.
Proof. unfold Equation872. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff390_inst, reff390_op in H. discriminate H. Qed.

Lemma reff390_not873 : ~ @Equation873 Fin4 reff390_inst.
Proof. unfold Equation873. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff390_inst, reff390_op in H. discriminate H. Qed.

Lemma reff390_not879 : ~ @Equation879 Fin4 reff390_inst.
Proof. unfold Equation879. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff390_inst, reff390_op in H. discriminate H. Qed.

Lemma reff390_not880 : ~ @Equation880 Fin4 reff390_inst.
Proof. unfold Equation880. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff390_inst, reff390_op in H. discriminate H. Qed.

Lemma reff390_not882 : ~ @Equation882 Fin4 reff390_inst.
Proof. unfold Equation882. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff390_inst, reff390_op in H. discriminate H. Qed.

Lemma reff390_not883 : ~ @Equation883 Fin4 reff390_inst.
Proof. unfold Equation883. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff390_inst, reff390_op in H. discriminate H. Qed.

Lemma reff390_not906 : ~ @Equation906 Fin4 reff390_inst.
Proof. unfold Equation906. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff390_inst, reff390_op in H. discriminate H. Qed.

Lemma reff390_not907 : ~ @Equation907 Fin4 reff390_inst.
Proof. unfold Equation907. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff390_inst, reff390_op in H. discriminate H. Qed.

Lemma reff390_not909 : ~ @Equation909 Fin4 reff390_inst.
Proof. unfold Equation909. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff390_inst, reff390_op in H. discriminate H. Qed.

Lemma reff390_not910 : ~ @Equation910 Fin4 reff390_inst.
Proof. unfold Equation910. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff390_inst, reff390_op in H. discriminate H. Qed.

Lemma reff390_not916 : ~ @Equation916 Fin4 reff390_inst.
Proof. unfold Equation916. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff390_inst, reff390_op in H. discriminate H. Qed.

Lemma reff390_not917 : ~ @Equation917 Fin4 reff390_inst.
Proof. unfold Equation917. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff390_inst, reff390_op in H. discriminate H. Qed.

Lemma reff390_not919 : ~ @Equation919 Fin4 reff390_inst.
Proof. unfold Equation919. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff390_inst, reff390_op in H. discriminate H. Qed.

Lemma reff390_not1035 : ~ @Equation1035 Fin4 reff390_inst.
Proof. unfold Equation1035. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff390_inst, reff390_op in H. discriminate H. Qed.

Lemma reff390_not1036 : ~ @Equation1036 Fin4 reff390_inst.
Proof. unfold Equation1036. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff390_inst, reff390_op in H. discriminate H. Qed.

Lemma reff390_not1038 : ~ @Equation1038 Fin4 reff390_inst.
Proof. unfold Equation1038. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff390_inst, reff390_op in H. discriminate H. Qed.

Lemma reff390_not1039 : ~ @Equation1039 Fin4 reff390_inst.
Proof. unfold Equation1039. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff390_inst, reff390_op in H. discriminate H. Qed.

Lemma reff390_not1045 : ~ @Equation1045 Fin4 reff390_inst.
Proof. unfold Equation1045. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff390_inst, reff390_op in H. discriminate H. Qed.

Lemma reff390_not1046 : ~ @Equation1046 Fin4 reff390_inst.
Proof. unfold Equation1046. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff390_inst, reff390_op in H. discriminate H. Qed.

Lemma reff390_not1048 : ~ @Equation1048 Fin4 reff390_inst.
Proof. unfold Equation1048. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff390_inst, reff390_op in H. discriminate H. Qed.

Lemma reff390_not1049 : ~ @Equation1049 Fin4 reff390_inst.
Proof. unfold Equation1049. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff390_inst, reff390_op in H. discriminate H. Qed.

Lemma reff390_not1072 : ~ @Equation1072 Fin4 reff390_inst.
Proof. unfold Equation1072. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff390_inst, reff390_op in H. discriminate H. Qed.

Lemma reff390_not1073 : ~ @Equation1073 Fin4 reff390_inst.
Proof. unfold Equation1073. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff390_inst, reff390_op in H. discriminate H. Qed.

Lemma reff390_not1075 : ~ @Equation1075 Fin4 reff390_inst.
Proof. unfold Equation1075. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff390_inst, reff390_op in H. discriminate H. Qed.

Lemma reff390_not1076 : ~ @Equation1076 Fin4 reff390_inst.
Proof. unfold Equation1076. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff390_inst, reff390_op in H. discriminate H. Qed.

Lemma reff390_not1082 : ~ @Equation1082 Fin4 reff390_inst.
Proof. unfold Equation1082. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff390_inst, reff390_op in H. discriminate H. Qed.

Lemma reff390_not1083 : ~ @Equation1083 Fin4 reff390_inst.
Proof. unfold Equation1083. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff390_inst, reff390_op in H. discriminate H. Qed.

Lemma reff390_not1085 : ~ @Equation1085 Fin4 reff390_inst.
Proof. unfold Equation1085. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff390_inst, reff390_op in H. discriminate H. Qed.

Lemma reff390_not1086 : ~ @Equation1086 Fin4 reff390_inst.
Proof. unfold Equation1086. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff390_inst, reff390_op in H. discriminate H. Qed.

Lemma reff390_not1109 : ~ @Equation1109 Fin4 reff390_inst.
Proof. unfold Equation1109. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff390_inst, reff390_op in H. discriminate H. Qed.

Lemma reff390_not1110 : ~ @Equation1110 Fin4 reff390_inst.
Proof. unfold Equation1110. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff390_inst, reff390_op in H. discriminate H. Qed.

Lemma reff390_not1112 : ~ @Equation1112 Fin4 reff390_inst.
Proof. unfold Equation1112. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff390_inst, reff390_op in H. discriminate H. Qed.

Lemma reff390_not1113 : ~ @Equation1113 Fin4 reff390_inst.
Proof. unfold Equation1113. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff390_inst, reff390_op in H. discriminate H. Qed.

Lemma reff390_not1119 : ~ @Equation1119 Fin4 reff390_inst.
Proof. unfold Equation1119. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff390_inst, reff390_op in H. discriminate H. Qed.

Lemma reff390_not1120 : ~ @Equation1120 Fin4 reff390_inst.
Proof. unfold Equation1120. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff390_inst, reff390_op in H. discriminate H. Qed.

Lemma reff390_not1122 : ~ @Equation1122 Fin4 reff390_inst.
Proof. unfold Equation1122. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff390_inst, reff390_op in H. discriminate H. Qed.

Lemma reff390_not1238 : ~ @Equation1238 Fin4 reff390_inst.
Proof. unfold Equation1238. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff390_inst, reff390_op in H. discriminate H. Qed.

Lemma reff390_not1239 : ~ @Equation1239 Fin4 reff390_inst.
Proof. unfold Equation1239. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff390_inst, reff390_op in H. discriminate H. Qed.

Lemma reff390_not1241 : ~ @Equation1241 Fin4 reff390_inst.
Proof. unfold Equation1241. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff390_inst, reff390_op in H. discriminate H. Qed.

Lemma reff390_not1242 : ~ @Equation1242 Fin4 reff390_inst.
Proof. unfold Equation1242. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff390_inst, reff390_op in H. discriminate H. Qed.

Lemma reff390_not1248 : ~ @Equation1248 Fin4 reff390_inst.
Proof. unfold Equation1248. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff390_inst, reff390_op in H. discriminate H. Qed.

Lemma reff390_not1249 : ~ @Equation1249 Fin4 reff390_inst.
Proof. unfold Equation1249. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff390_inst, reff390_op in H. discriminate H. Qed.

Lemma reff390_not1251 : ~ @Equation1251 Fin4 reff390_inst.
Proof. unfold Equation1251. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff390_inst, reff390_op in H. discriminate H. Qed.

Lemma reff390_not1252 : ~ @Equation1252 Fin4 reff390_inst.
Proof. unfold Equation1252. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff390_inst, reff390_op in H. discriminate H. Qed.

Lemma reff390_not1275 : ~ @Equation1275 Fin4 reff390_inst.
Proof. unfold Equation1275. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff390_inst, reff390_op in H. discriminate H. Qed.

Lemma reff390_not1276 : ~ @Equation1276 Fin4 reff390_inst.
Proof. unfold Equation1276. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff390_inst, reff390_op in H. discriminate H. Qed.

Lemma reff390_not1278 : ~ @Equation1278 Fin4 reff390_inst.
Proof. unfold Equation1278. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff390_inst, reff390_op in H. discriminate H. Qed.

Lemma reff390_not1279 : ~ @Equation1279 Fin4 reff390_inst.
Proof. unfold Equation1279. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff390_inst, reff390_op in H. discriminate H. Qed.

Lemma reff390_not1285 : ~ @Equation1285 Fin4 reff390_inst.
Proof. unfold Equation1285. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff390_inst, reff390_op in H. discriminate H. Qed.

Lemma reff390_not1286 : ~ @Equation1286 Fin4 reff390_inst.
Proof. unfold Equation1286. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff390_inst, reff390_op in H. discriminate H. Qed.

Lemma reff390_not1288 : ~ @Equation1288 Fin4 reff390_inst.
Proof. unfold Equation1288. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff390_inst, reff390_op in H. discriminate H. Qed.

Lemma reff390_not1289 : ~ @Equation1289 Fin4 reff390_inst.
Proof. unfold Equation1289. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff390_inst, reff390_op in H. discriminate H. Qed.

Lemma reff390_not1312 : ~ @Equation1312 Fin4 reff390_inst.
Proof. unfold Equation1312. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff390_inst, reff390_op in H. discriminate H. Qed.

Lemma reff390_not1313 : ~ @Equation1313 Fin4 reff390_inst.
Proof. unfold Equation1313. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff390_inst, reff390_op in H. discriminate H. Qed.

Lemma reff390_not1315 : ~ @Equation1315 Fin4 reff390_inst.
Proof. unfold Equation1315. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff390_inst, reff390_op in H. discriminate H. Qed.

Lemma reff390_not1316 : ~ @Equation1316 Fin4 reff390_inst.
Proof. unfold Equation1316. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff390_inst, reff390_op in H. discriminate H. Qed.

Lemma reff390_not1322 : ~ @Equation1322 Fin4 reff390_inst.
Proof. unfold Equation1322. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff390_inst, reff390_op in H. discriminate H. Qed.

Lemma reff390_not1323 : ~ @Equation1323 Fin4 reff390_inst.
Proof. unfold Equation1323. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff390_inst, reff390_op in H. discriminate H. Qed.

Lemma reff390_not1325 : ~ @Equation1325 Fin4 reff390_inst.
Proof. unfold Equation1325. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff390_inst, reff390_op in H. discriminate H. Qed.

Lemma reff390_not1431 : ~ @Equation1431 Fin4 reff390_inst.
Proof. unfold Equation1431. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff390_inst, reff390_op in H. discriminate H. Qed.

Lemma reff390_not1432 : ~ @Equation1432 Fin4 reff390_inst.
Proof. unfold Equation1432. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff390_inst, reff390_op in H. discriminate H. Qed.

Lemma reff390_not1434 : ~ @Equation1434 Fin4 reff390_inst.
Proof. unfold Equation1434. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff390_inst, reff390_op in H. discriminate H. Qed.

Lemma reff390_not1435 : ~ @Equation1435 Fin4 reff390_inst.
Proof. unfold Equation1435. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff390_inst, reff390_op in H. discriminate H. Qed.

Lemma reff390_not1441 : ~ @Equation1441 Fin4 reff390_inst.
Proof. unfold Equation1441. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff390_inst, reff390_op in H. discriminate H. Qed.

Lemma reff390_not1442 : ~ @Equation1442 Fin4 reff390_inst.
Proof. unfold Equation1442. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff390_inst, reff390_op in H. discriminate H. Qed.

Lemma reff390_not1444 : ~ @Equation1444 Fin4 reff390_inst.
Proof. unfold Equation1444. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff390_inst, reff390_op in H. discriminate H. Qed.

Lemma reff390_not1445 : ~ @Equation1445 Fin4 reff390_inst.
Proof. unfold Equation1445. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff390_inst, reff390_op in H. discriminate H. Qed.

Lemma reff390_not1478 : ~ @Equation1478 Fin4 reff390_inst.
Proof. unfold Equation1478. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff390_inst, reff390_op in H. discriminate H. Qed.

Lemma reff390_not1479 : ~ @Equation1479 Fin4 reff390_inst.
Proof. unfold Equation1479. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff390_inst, reff390_op in H. discriminate H. Qed.

Lemma reff390_not1481 : ~ @Equation1481 Fin4 reff390_inst.
Proof. unfold Equation1481. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff390_inst, reff390_op in H. discriminate H. Qed.

Lemma reff390_not1482 : ~ @Equation1482 Fin4 reff390_inst.
Proof. unfold Equation1482. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff390_inst, reff390_op in H. discriminate H. Qed.

Lemma reff390_not1488 : ~ @Equation1488 Fin4 reff390_inst.
Proof. unfold Equation1488. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff390_inst, reff390_op in H. discriminate H. Qed.

Lemma reff390_not1489 : ~ @Equation1489 Fin4 reff390_inst.
Proof. unfold Equation1489. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff390_inst, reff390_op in H. discriminate H. Qed.

Lemma reff390_not1491 : ~ @Equation1491 Fin4 reff390_inst.
Proof. unfold Equation1491. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff390_inst, reff390_op in H. discriminate H. Qed.

Lemma reff390_not1492 : ~ @Equation1492 Fin4 reff390_inst.
Proof. unfold Equation1492. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff390_inst, reff390_op in H. discriminate H. Qed.

Lemma reff390_not1515 : ~ @Equation1515 Fin4 reff390_inst.
Proof. unfold Equation1515. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff390_inst, reff390_op in H. discriminate H. Qed.

Lemma reff390_not1516 : ~ @Equation1516 Fin4 reff390_inst.
Proof. unfold Equation1516. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff390_inst, reff390_op in H. discriminate H. Qed.

Lemma reff390_not1518 : ~ @Equation1518 Fin4 reff390_inst.
Proof. unfold Equation1518. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff390_inst, reff390_op in H. discriminate H. Qed.

Lemma reff390_not1519 : ~ @Equation1519 Fin4 reff390_inst.
Proof. unfold Equation1519. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff390_inst, reff390_op in H. discriminate H. Qed.

Lemma reff390_not1525 : ~ @Equation1525 Fin4 reff390_inst.
Proof. unfold Equation1525. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff390_inst, reff390_op in H. discriminate H. Qed.

Lemma reff390_not1526 : ~ @Equation1526 Fin4 reff390_inst.
Proof. unfold Equation1526. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff390_inst, reff390_op in H. discriminate H. Qed.

Lemma reff390_not1528 : ~ @Equation1528 Fin4 reff390_inst.
Proof. unfold Equation1528. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff390_inst, reff390_op in H. discriminate H. Qed.

Lemma reff390_not1634 : ~ @Equation1634 Fin4 reff390_inst.
Proof. unfold Equation1634. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff390_inst, reff390_op in H. discriminate H. Qed.

Lemma reff390_not1635 : ~ @Equation1635 Fin4 reff390_inst.
Proof. unfold Equation1635. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff390_inst, reff390_op in H. discriminate H. Qed.

Lemma reff390_not1637 : ~ @Equation1637 Fin4 reff390_inst.
Proof. unfold Equation1637. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff390_inst, reff390_op in H. discriminate H. Qed.

Lemma reff390_not1638 : ~ @Equation1638 Fin4 reff390_inst.
Proof. unfold Equation1638. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff390_inst, reff390_op in H. discriminate H. Qed.

Lemma reff390_not1644 : ~ @Equation1644 Fin4 reff390_inst.
Proof. unfold Equation1644. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff390_inst, reff390_op in H. discriminate H. Qed.

Lemma reff390_not1645 : ~ @Equation1645 Fin4 reff390_inst.
Proof. unfold Equation1645. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff390_inst, reff390_op in H. discriminate H. Qed.

Lemma reff390_not1647 : ~ @Equation1647 Fin4 reff390_inst.
Proof. unfold Equation1647. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff390_inst, reff390_op in H. discriminate H. Qed.

Lemma reff390_not1648 : ~ @Equation1648 Fin4 reff390_inst.
Proof. unfold Equation1648. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff390_inst, reff390_op in H. discriminate H. Qed.

Lemma reff390_not1681 : ~ @Equation1681 Fin4 reff390_inst.
Proof. unfold Equation1681. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff390_inst, reff390_op in H. discriminate H. Qed.

Lemma reff390_not1682 : ~ @Equation1682 Fin4 reff390_inst.
Proof. unfold Equation1682. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff390_inst, reff390_op in H. discriminate H. Qed.

Lemma reff390_not1684 : ~ @Equation1684 Fin4 reff390_inst.
Proof. unfold Equation1684. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff390_inst, reff390_op in H. discriminate H. Qed.

Lemma reff390_not1685 : ~ @Equation1685 Fin4 reff390_inst.
Proof. unfold Equation1685. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff390_inst, reff390_op in H. discriminate H. Qed.

Lemma reff390_not1691 : ~ @Equation1691 Fin4 reff390_inst.
Proof. unfold Equation1691. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff390_inst, reff390_op in H. discriminate H. Qed.

Lemma reff390_not1692 : ~ @Equation1692 Fin4 reff390_inst.
Proof. unfold Equation1692. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff390_inst, reff390_op in H. discriminate H. Qed.

Lemma reff390_not1694 : ~ @Equation1694 Fin4 reff390_inst.
Proof. unfold Equation1694. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff390_inst, reff390_op in H. discriminate H. Qed.

Lemma reff390_not1695 : ~ @Equation1695 Fin4 reff390_inst.
Proof. unfold Equation1695. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff390_inst, reff390_op in H. discriminate H. Qed.

Lemma reff390_not1718 : ~ @Equation1718 Fin4 reff390_inst.
Proof. unfold Equation1718. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff390_inst, reff390_op in H. discriminate H. Qed.

Lemma reff390_not1719 : ~ @Equation1719 Fin4 reff390_inst.
Proof. unfold Equation1719. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff390_inst, reff390_op in H. discriminate H. Qed.

Lemma reff390_not1721 : ~ @Equation1721 Fin4 reff390_inst.
Proof. unfold Equation1721. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff390_inst, reff390_op in H. discriminate H. Qed.

Lemma reff390_not1722 : ~ @Equation1722 Fin4 reff390_inst.
Proof. unfold Equation1722. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff390_inst, reff390_op in H. discriminate H. Qed.

Lemma reff390_not1728 : ~ @Equation1728 Fin4 reff390_inst.
Proof. unfold Equation1728. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff390_inst, reff390_op in H. discriminate H. Qed.

Lemma reff390_not1729 : ~ @Equation1729 Fin4 reff390_inst.
Proof. unfold Equation1729. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff390_inst, reff390_op in H. discriminate H. Qed.

Lemma reff390_not1731 : ~ @Equation1731 Fin4 reff390_inst.
Proof. unfold Equation1731. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff390_inst, reff390_op in H. discriminate H. Qed.

Lemma reff390_not1834 : ~ @Equation1834 Fin4 reff390_inst.
Proof. unfold Equation1834. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff390_inst, reff390_op in H. discriminate H. Qed.

Lemma reff390_not1835 : ~ @Equation1835 Fin4 reff390_inst.
Proof. unfold Equation1835. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff390_inst, reff390_op in H. discriminate H. Qed.

Lemma reff390_not1840 : ~ @Equation1840 Fin4 reff390_inst.
Proof. unfold Equation1840. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff390_inst, reff390_op in H. discriminate H. Qed.

Lemma reff390_not1841 : ~ @Equation1841 Fin4 reff390_inst.
Proof. unfold Equation1841. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff390_inst, reff390_op in H. discriminate H. Qed.

Lemma reff390_not1847 : ~ @Equation1847 Fin4 reff390_inst.
Proof. unfold Equation1847. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff390_inst, reff390_op in H. discriminate H. Qed.

Lemma reff390_not1848 : ~ @Equation1848 Fin4 reff390_inst.
Proof. unfold Equation1848. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff390_inst, reff390_op in H. discriminate H. Qed.

Lemma reff390_not1857 : ~ @Equation1857 Fin4 reff390_inst.
Proof. unfold Equation1857. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff390_inst, reff390_op in H. discriminate H. Qed.

Lemma reff390_not1858 : ~ @Equation1858 Fin4 reff390_inst.
Proof. unfold Equation1858. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff390_inst, reff390_op in H. discriminate H. Qed.

Lemma reff390_not1884 : ~ @Equation1884 Fin4 reff390_inst.
Proof. unfold Equation1884. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff390_inst, reff390_op in H. discriminate H. Qed.

Lemma reff390_not1885 : ~ @Equation1885 Fin4 reff390_inst.
Proof. unfold Equation1885. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff390_inst, reff390_op in H. discriminate H. Qed.

Lemma reff390_not1887 : ~ @Equation1887 Fin4 reff390_inst.
Proof. unfold Equation1887. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff390_inst, reff390_op in H. discriminate H. Qed.

Lemma reff390_not1888 : ~ @Equation1888 Fin4 reff390_inst.
Proof. unfold Equation1888. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff390_inst, reff390_op in H. discriminate H. Qed.

Lemma reff390_not1894 : ~ @Equation1894 Fin4 reff390_inst.
Proof. unfold Equation1894. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff390_inst, reff390_op in H. discriminate H. Qed.

Lemma reff390_not1895 : ~ @Equation1895 Fin4 reff390_inst.
Proof. unfold Equation1895. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff390_inst, reff390_op in H. discriminate H. Qed.

Lemma reff390_not1897 : ~ @Equation1897 Fin4 reff390_inst.
Proof. unfold Equation1897. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff390_inst, reff390_op in H. discriminate H. Qed.

Lemma reff390_not1898 : ~ @Equation1898 Fin4 reff390_inst.
Proof. unfold Equation1898. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff390_inst, reff390_op in H. discriminate H. Qed.

Lemma reff390_not1921 : ~ @Equation1921 Fin4 reff390_inst.
Proof. unfold Equation1921. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff390_inst, reff390_op in H. discriminate H. Qed.

Lemma reff390_not1922 : ~ @Equation1922 Fin4 reff390_inst.
Proof. unfold Equation1922. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff390_inst, reff390_op in H. discriminate H. Qed.

Lemma reff390_not1924 : ~ @Equation1924 Fin4 reff390_inst.
Proof. unfold Equation1924. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff390_inst, reff390_op in H. discriminate H. Qed.

Lemma reff390_not1925 : ~ @Equation1925 Fin4 reff390_inst.
Proof. unfold Equation1925. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff390_inst, reff390_op in H. discriminate H. Qed.

Lemma reff390_not1931 : ~ @Equation1931 Fin4 reff390_inst.
Proof. unfold Equation1931. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff390_inst, reff390_op in H. discriminate H. Qed.

Lemma reff390_not1932 : ~ @Equation1932 Fin4 reff390_inst.
Proof. unfold Equation1932. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff390_inst, reff390_op in H. discriminate H. Qed.

Lemma reff390_not1934 : ~ @Equation1934 Fin4 reff390_inst.
Proof. unfold Equation1934. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff390_inst, reff390_op in H. discriminate H. Qed.

Lemma reff390_not2037 : ~ @Equation2037 Fin4 reff390_inst.
Proof. unfold Equation2037. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff390_inst, reff390_op in H. discriminate H. Qed.

Lemma reff390_not2038 : ~ @Equation2038 Fin4 reff390_inst.
Proof. unfold Equation2038. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff390_inst, reff390_op in H. discriminate H. Qed.

Lemma reff390_not2040 : ~ @Equation2040 Fin4 reff390_inst.
Proof. unfold Equation2040. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff390_inst, reff390_op in H. discriminate H. Qed.

Lemma reff390_not2041 : ~ @Equation2041 Fin4 reff390_inst.
Proof. unfold Equation2041. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff390_inst, reff390_op in H. discriminate H. Qed.

Lemma reff390_not2050 : ~ @Equation2050 Fin4 reff390_inst.
Proof. unfold Equation2050. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff390_inst, reff390_op in H. discriminate H. Qed.

Lemma reff390_not2051 : ~ @Equation2051 Fin4 reff390_inst.
Proof. unfold Equation2051. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff390_inst, reff390_op in H. discriminate H. Qed.

Lemma reff390_not2063 : ~ @Equation2063 Fin4 reff390_inst.
Proof. unfold Equation2063. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff390_inst, reff390_op in H. discriminate H. Qed.

Lemma reff390_not2064 : ~ @Equation2064 Fin4 reff390_inst.
Proof. unfold Equation2064. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff390_inst, reff390_op in H. discriminate H. Qed.

Lemma reff390_not2087 : ~ @Equation2087 Fin4 reff390_inst.
Proof. unfold Equation2087. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff390_inst, reff390_op in H. discriminate H. Qed.

Lemma reff390_not2088 : ~ @Equation2088 Fin4 reff390_inst.
Proof. unfold Equation2088. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff390_inst, reff390_op in H. discriminate H. Qed.

Lemma reff390_not2090 : ~ @Equation2090 Fin4 reff390_inst.
Proof. unfold Equation2090. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff390_inst, reff390_op in H. discriminate H. Qed.

Lemma reff390_not2091 : ~ @Equation2091 Fin4 reff390_inst.
Proof. unfold Equation2091. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff390_inst, reff390_op in H. discriminate H. Qed.

Lemma reff390_not2097 : ~ @Equation2097 Fin4 reff390_inst.
Proof. unfold Equation2097. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff390_inst, reff390_op in H. discriminate H. Qed.

Lemma reff390_not2098 : ~ @Equation2098 Fin4 reff390_inst.
Proof. unfold Equation2098. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff390_inst, reff390_op in H. discriminate H. Qed.

Lemma reff390_not2100 : ~ @Equation2100 Fin4 reff390_inst.
Proof. unfold Equation2100. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff390_inst, reff390_op in H. discriminate H. Qed.

Lemma reff390_not2101 : ~ @Equation2101 Fin4 reff390_inst.
Proof. unfold Equation2101. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff390_inst, reff390_op in H. discriminate H. Qed.

Lemma reff390_not2124 : ~ @Equation2124 Fin4 reff390_inst.
Proof. unfold Equation2124. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff390_inst, reff390_op in H. discriminate H. Qed.

Lemma reff390_not2125 : ~ @Equation2125 Fin4 reff390_inst.
Proof. unfold Equation2125. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff390_inst, reff390_op in H. discriminate H. Qed.

Lemma reff390_not2127 : ~ @Equation2127 Fin4 reff390_inst.
Proof. unfold Equation2127. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff390_inst, reff390_op in H. discriminate H. Qed.

Lemma reff390_not2128 : ~ @Equation2128 Fin4 reff390_inst.
Proof. unfold Equation2128. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff390_inst, reff390_op in H. discriminate H. Qed.

Lemma reff390_not2134 : ~ @Equation2134 Fin4 reff390_inst.
Proof. unfold Equation2134. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff390_inst, reff390_op in H. discriminate H. Qed.

Lemma reff390_not2135 : ~ @Equation2135 Fin4 reff390_inst.
Proof. unfold Equation2135. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff390_inst, reff390_op in H. discriminate H. Qed.

Lemma reff390_not2137 : ~ @Equation2137 Fin4 reff390_inst.
Proof. unfold Equation2137. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff390_inst, reff390_op in H. discriminate H. Qed.

Lemma reff390_not2239 : ~ @Equation2239 Fin4 reff390_inst.
Proof. unfold Equation2239. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff390_inst, reff390_op in H. discriminate H. Qed.

Lemma reff390_not2241 : ~ @Equation2241 Fin4 reff390_inst.
Proof. unfold Equation2241. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff390_inst, reff390_op in H. discriminate H. Qed.

Lemma reff390_not2244 : ~ @Equation2244 Fin4 reff390_inst.
Proof. unfold Equation2244. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff390_inst, reff390_op in H. discriminate H. Qed.

Lemma reff390_not2247 : ~ @Equation2247 Fin4 reff390_inst.
Proof. unfold Equation2247. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff390_inst, reff390_op in H. discriminate H. Qed.

Lemma reff390_not2253 : ~ @Equation2253 Fin4 reff390_inst.
Proof. unfold Equation2253. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff390_inst, reff390_op in H. discriminate H. Qed.

Lemma reff390_not2256 : ~ @Equation2256 Fin4 reff390_inst.
Proof. unfold Equation2256. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff390_inst, reff390_op in H. discriminate H. Qed.

Lemma reff390_not2263 : ~ @Equation2263 Fin4 reff390_inst.
Proof. unfold Equation2263. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff390_inst, reff390_op in H. discriminate H. Qed.

Lemma reff390_not2266 : ~ @Equation2266 Fin4 reff390_inst.
Proof. unfold Equation2266. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff390_inst, reff390_op in H. discriminate H. Qed.

Lemma reff390_not2290 : ~ @Equation2290 Fin4 reff390_inst.
Proof. unfold Equation2290. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff390_inst, reff390_op in H. discriminate H. Qed.

Lemma reff390_not2291 : ~ @Equation2291 Fin4 reff390_inst.
Proof. unfold Equation2291. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff390_inst, reff390_op in H. discriminate H. Qed.

Lemma reff390_not2293 : ~ @Equation2293 Fin4 reff390_inst.
Proof. unfold Equation2293. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff390_inst, reff390_op in H. discriminate H. Qed.

Lemma reff390_not2294 : ~ @Equation2294 Fin4 reff390_inst.
Proof. unfold Equation2294. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff390_inst, reff390_op in H. discriminate H. Qed.

Lemma reff390_not2300 : ~ @Equation2300 Fin4 reff390_inst.
Proof. unfold Equation2300. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff390_inst, reff390_op in H. discriminate H. Qed.

Lemma reff390_not2301 : ~ @Equation2301 Fin4 reff390_inst.
Proof. unfold Equation2301. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff390_inst, reff390_op in H. discriminate H. Qed.

Lemma reff390_not2303 : ~ @Equation2303 Fin4 reff390_inst.
Proof. unfold Equation2303. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff390_inst, reff390_op in H. discriminate H. Qed.

Lemma reff390_not2304 : ~ @Equation2304 Fin4 reff390_inst.
Proof. unfold Equation2304. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff390_inst, reff390_op in H. discriminate H. Qed.

Lemma reff390_not2327 : ~ @Equation2327 Fin4 reff390_inst.
Proof. unfold Equation2327. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff390_inst, reff390_op in H. discriminate H. Qed.

Lemma reff390_not2328 : ~ @Equation2328 Fin4 reff390_inst.
Proof. unfold Equation2328. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff390_inst, reff390_op in H. discriminate H. Qed.

Lemma reff390_not2330 : ~ @Equation2330 Fin4 reff390_inst.
Proof. unfold Equation2330. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff390_inst, reff390_op in H. discriminate H. Qed.

Lemma reff390_not2331 : ~ @Equation2331 Fin4 reff390_inst.
Proof. unfold Equation2331. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff390_inst, reff390_op in H. discriminate H. Qed.

Lemma reff390_not2337 : ~ @Equation2337 Fin4 reff390_inst.
Proof. unfold Equation2337. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff390_inst, reff390_op in H. discriminate H. Qed.

Lemma reff390_not2338 : ~ @Equation2338 Fin4 reff390_inst.
Proof. unfold Equation2338. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff390_inst, reff390_op in H. discriminate H. Qed.

Lemma reff390_not2340 : ~ @Equation2340 Fin4 reff390_inst.
Proof. unfold Equation2340. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff390_inst, reff390_op in H. discriminate H. Qed.

Lemma reff390_not2442 : ~ @Equation2442 Fin4 reff390_inst.
Proof. unfold Equation2442. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff390_inst, reff390_op in H. discriminate H. Qed.

Lemma reff390_not2444 : ~ @Equation2444 Fin4 reff390_inst.
Proof. unfold Equation2444. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff390_inst, reff390_op in H. discriminate H. Qed.

Lemma reff390_not2447 : ~ @Equation2447 Fin4 reff390_inst.
Proof. unfold Equation2447. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff390_inst, reff390_op in H. discriminate H. Qed.

Lemma reff390_not2450 : ~ @Equation2450 Fin4 reff390_inst.
Proof. unfold Equation2450. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff390_inst, reff390_op in H. discriminate H. Qed.

Lemma reff390_not2456 : ~ @Equation2456 Fin4 reff390_inst.
Proof. unfold Equation2456. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff390_inst, reff390_op in H. discriminate H. Qed.

Lemma reff390_not2459 : ~ @Equation2459 Fin4 reff390_inst.
Proof. unfold Equation2459. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff390_inst, reff390_op in H. discriminate H. Qed.

Lemma reff390_not2466 : ~ @Equation2466 Fin4 reff390_inst.
Proof. unfold Equation2466. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff390_inst, reff390_op in H. discriminate H. Qed.

Lemma reff390_not2469 : ~ @Equation2469 Fin4 reff390_inst.
Proof. unfold Equation2469. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff390_inst, reff390_op in H. discriminate H. Qed.

Lemma reff390_not2493 : ~ @Equation2493 Fin4 reff390_inst.
Proof. unfold Equation2493. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff390_inst, reff390_op in H. discriminate H. Qed.

Lemma reff390_not2494 : ~ @Equation2494 Fin4 reff390_inst.
Proof. unfold Equation2494. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff390_inst, reff390_op in H. discriminate H. Qed.

Lemma reff390_not2496 : ~ @Equation2496 Fin4 reff390_inst.
Proof. unfold Equation2496. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff390_inst, reff390_op in H. discriminate H. Qed.

Lemma reff390_not2497 : ~ @Equation2497 Fin4 reff390_inst.
Proof. unfold Equation2497. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff390_inst, reff390_op in H. discriminate H. Qed.

Lemma reff390_not2503 : ~ @Equation2503 Fin4 reff390_inst.
Proof. unfold Equation2503. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff390_inst, reff390_op in H. discriminate H. Qed.

Lemma reff390_not2504 : ~ @Equation2504 Fin4 reff390_inst.
Proof. unfold Equation2504. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff390_inst, reff390_op in H. discriminate H. Qed.

Lemma reff390_not2506 : ~ @Equation2506 Fin4 reff390_inst.
Proof. unfold Equation2506. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff390_inst, reff390_op in H. discriminate H. Qed.

Lemma reff390_not2507 : ~ @Equation2507 Fin4 reff390_inst.
Proof. unfold Equation2507. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff390_inst, reff390_op in H. discriminate H. Qed.

Lemma reff390_not2530 : ~ @Equation2530 Fin4 reff390_inst.
Proof. unfold Equation2530. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff390_inst, reff390_op in H. discriminate H. Qed.

Lemma reff390_not2531 : ~ @Equation2531 Fin4 reff390_inst.
Proof. unfold Equation2531. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff390_inst, reff390_op in H. discriminate H. Qed.

Lemma reff390_not2533 : ~ @Equation2533 Fin4 reff390_inst.
Proof. unfold Equation2533. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff390_inst, reff390_op in H. discriminate H. Qed.

Lemma reff390_not2534 : ~ @Equation2534 Fin4 reff390_inst.
Proof. unfold Equation2534. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff390_inst, reff390_op in H. discriminate H. Qed.

Lemma reff390_not2540 : ~ @Equation2540 Fin4 reff390_inst.
Proof. unfold Equation2540. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff390_inst, reff390_op in H. discriminate H. Qed.

Lemma reff390_not2541 : ~ @Equation2541 Fin4 reff390_inst.
Proof. unfold Equation2541. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff390_inst, reff390_op in H. discriminate H. Qed.

Lemma reff390_not2543 : ~ @Equation2543 Fin4 reff390_inst.
Proof. unfold Equation2543. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff390_inst, reff390_op in H. discriminate H. Qed.

Lemma reff390_not2645 : ~ @Equation2645 Fin4 reff390_inst.
Proof. unfold Equation2645. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff390_inst, reff390_op in H. discriminate H. Qed.

Lemma reff390_not2647 : ~ @Equation2647 Fin4 reff390_inst.
Proof. unfold Equation2647. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff390_inst, reff390_op in H. discriminate H. Qed.

Lemma reff390_not2649 : ~ @Equation2649 Fin4 reff390_inst.
Proof. unfold Equation2649. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff390_inst, reff390_op in H. discriminate H. Qed.

Lemma reff390_not2652 : ~ @Equation2652 Fin4 reff390_inst.
Proof. unfold Equation2652. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff390_inst, reff390_op in H. discriminate H. Qed.

Lemma reff390_not2659 : ~ @Equation2659 Fin4 reff390_inst.
Proof. unfold Equation2659. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff390_inst, reff390_op in H. discriminate H. Qed.

Lemma reff390_not2662 : ~ @Equation2662 Fin4 reff390_inst.
Proof. unfold Equation2662. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff390_inst, reff390_op in H. discriminate H. Qed.

Lemma reff390_not2670 : ~ @Equation2670 Fin4 reff390_inst.
Proof. unfold Equation2670. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff390_inst, reff390_op in H. discriminate H. Qed.

Lemma reff390_not2673 : ~ @Equation2673 Fin4 reff390_inst.
Proof. unfold Equation2673. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff390_inst, reff390_op in H. discriminate H. Qed.

Lemma reff390_not2696 : ~ @Equation2696 Fin4 reff390_inst.
Proof. unfold Equation2696. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff390_inst, reff390_op in H. discriminate H. Qed.

Lemma reff390_not2697 : ~ @Equation2697 Fin4 reff390_inst.
Proof. unfold Equation2697. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff390_inst, reff390_op in H. discriminate H. Qed.

Lemma reff390_not2699 : ~ @Equation2699 Fin4 reff390_inst.
Proof. unfold Equation2699. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff390_inst, reff390_op in H. discriminate H. Qed.

Lemma reff390_not2700 : ~ @Equation2700 Fin4 reff390_inst.
Proof. unfold Equation2700. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff390_inst, reff390_op in H. discriminate H. Qed.

Lemma reff390_not2706 : ~ @Equation2706 Fin4 reff390_inst.
Proof. unfold Equation2706. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff390_inst, reff390_op in H. discriminate H. Qed.

Lemma reff390_not2707 : ~ @Equation2707 Fin4 reff390_inst.
Proof. unfold Equation2707. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff390_inst, reff390_op in H. discriminate H. Qed.

Lemma reff390_not2709 : ~ @Equation2709 Fin4 reff390_inst.
Proof. unfold Equation2709. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff390_inst, reff390_op in H. discriminate H. Qed.

Lemma reff390_not2710 : ~ @Equation2710 Fin4 reff390_inst.
Proof. unfold Equation2710. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff390_inst, reff390_op in H. discriminate H. Qed.

Lemma reff390_not2733 : ~ @Equation2733 Fin4 reff390_inst.
Proof. unfold Equation2733. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff390_inst, reff390_op in H. discriminate H. Qed.

Lemma reff390_not2734 : ~ @Equation2734 Fin4 reff390_inst.
Proof. unfold Equation2734. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff390_inst, reff390_op in H. discriminate H. Qed.

Lemma reff390_not2736 : ~ @Equation2736 Fin4 reff390_inst.
Proof. unfold Equation2736. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff390_inst, reff390_op in H. discriminate H. Qed.

Lemma reff390_not2737 : ~ @Equation2737 Fin4 reff390_inst.
Proof. unfold Equation2737. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff390_inst, reff390_op in H. discriminate H. Qed.

Lemma reff390_not2743 : ~ @Equation2743 Fin4 reff390_inst.
Proof. unfold Equation2743. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff390_inst, reff390_op in H. discriminate H. Qed.

Lemma reff390_not2744 : ~ @Equation2744 Fin4 reff390_inst.
Proof. unfold Equation2744. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff390_inst, reff390_op in H. discriminate H. Qed.

Lemma reff390_not2746 : ~ @Equation2746 Fin4 reff390_inst.
Proof. unfold Equation2746. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff390_inst, reff390_op in H. discriminate H. Qed.

Lemma reff390_not2848 : ~ @Equation2848 Fin4 reff390_inst.
Proof. unfold Equation2848. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff390_inst, reff390_op in H. discriminate H. Qed.

Lemma reff390_not2849 : ~ @Equation2849 Fin4 reff390_inst.
Proof. unfold Equation2849. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff390_inst, reff390_op in H. discriminate H. Qed.

Lemma reff390_not2853 : ~ @Equation2853 Fin4 reff390_inst.
Proof. unfold Equation2853. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff390_inst, reff390_op in H. discriminate H. Qed.

Lemma reff390_not2855 : ~ @Equation2855 Fin4 reff390_inst.
Proof. unfold Equation2855. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff390_inst, reff390_op in H. discriminate H. Qed.

Lemma reff390_not2862 : ~ @Equation2862 Fin4 reff390_inst.
Proof. unfold Equation2862. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff390_inst, reff390_op in H. discriminate H. Qed.

Lemma reff390_not2866 : ~ @Equation2866 Fin4 reff390_inst.
Proof. unfold Equation2866. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff390_inst, reff390_op in H. discriminate H. Qed.

Lemma reff390_not2872 : ~ @Equation2872 Fin4 reff390_inst.
Proof. unfold Equation2872. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff390_inst, reff390_op in H. discriminate H. Qed.

Lemma reff390_not2876 : ~ @Equation2876 Fin4 reff390_inst.
Proof. unfold Equation2876. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff390_inst, reff390_op in H. discriminate H. Qed.

Lemma reff390_not2899 : ~ @Equation2899 Fin4 reff390_inst.
Proof. unfold Equation2899. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff390_inst, reff390_op in H. discriminate H. Qed.

Lemma reff390_not2900 : ~ @Equation2900 Fin4 reff390_inst.
Proof. unfold Equation2900. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff390_inst, reff390_op in H. discriminate H. Qed.

Lemma reff390_not2902 : ~ @Equation2902 Fin4 reff390_inst.
Proof. unfold Equation2902. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff390_inst, reff390_op in H. discriminate H. Qed.

Lemma reff390_not2903 : ~ @Equation2903 Fin4 reff390_inst.
Proof. unfold Equation2903. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff390_inst, reff390_op in H. discriminate H. Qed.

Lemma reff390_not2909 : ~ @Equation2909 Fin4 reff390_inst.
Proof. unfold Equation2909. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff390_inst, reff390_op in H. discriminate H. Qed.

Lemma reff390_not2910 : ~ @Equation2910 Fin4 reff390_inst.
Proof. unfold Equation2910. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff390_inst, reff390_op in H. discriminate H. Qed.

Lemma reff390_not2912 : ~ @Equation2912 Fin4 reff390_inst.
Proof. unfold Equation2912. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff390_inst, reff390_op in H. discriminate H. Qed.

Lemma reff390_not2913 : ~ @Equation2913 Fin4 reff390_inst.
Proof. unfold Equation2913. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff390_inst, reff390_op in H. discriminate H. Qed.

Lemma reff390_not2936 : ~ @Equation2936 Fin4 reff390_inst.
Proof. unfold Equation2936. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff390_inst, reff390_op in H. discriminate H. Qed.

Lemma reff390_not2937 : ~ @Equation2937 Fin4 reff390_inst.
Proof. unfold Equation2937. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff390_inst, reff390_op in H. discriminate H. Qed.

Lemma reff390_not2939 : ~ @Equation2939 Fin4 reff390_inst.
Proof. unfold Equation2939. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff390_inst, reff390_op in H. discriminate H. Qed.

Lemma reff390_not2940 : ~ @Equation2940 Fin4 reff390_inst.
Proof. unfold Equation2940. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff390_inst, reff390_op in H. discriminate H. Qed.

Lemma reff390_not2946 : ~ @Equation2946 Fin4 reff390_inst.
Proof. unfold Equation2946. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff390_inst, reff390_op in H. discriminate H. Qed.

Lemma reff390_not2947 : ~ @Equation2947 Fin4 reff390_inst.
Proof. unfold Equation2947. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff390_inst, reff390_op in H. discriminate H. Qed.

Lemma reff390_not2949 : ~ @Equation2949 Fin4 reff390_inst.
Proof. unfold Equation2949. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff390_inst, reff390_op in H. discriminate H. Qed.

Lemma reff390_not3051 : ~ @Equation3051 Fin4 reff390_inst.
Proof. unfold Equation3051. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff390_inst, reff390_op in H. discriminate H. Qed.

Lemma reff390_not3052 : ~ @Equation3052 Fin4 reff390_inst.
Proof. unfold Equation3052. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff390_inst, reff390_op in H. discriminate H. Qed.

Lemma reff390_not3055 : ~ @Equation3055 Fin4 reff390_inst.
Proof. unfold Equation3055. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff390_inst, reff390_op in H. discriminate H. Qed.

Lemma reff390_not3059 : ~ @Equation3059 Fin4 reff390_inst.
Proof. unfold Equation3059. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff390_inst, reff390_op in H. discriminate H. Qed.

Lemma reff390_not3065 : ~ @Equation3065 Fin4 reff390_inst.
Proof. unfold Equation3065. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff390_inst, reff390_op in H. discriminate H. Qed.

Lemma reff390_not3069 : ~ @Equation3069 Fin4 reff390_inst.
Proof. unfold Equation3069. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff390_inst, reff390_op in H. discriminate H. Qed.

Lemma reff390_not3076 : ~ @Equation3076 Fin4 reff390_inst.
Proof. unfold Equation3076. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff390_inst, reff390_op in H. discriminate H. Qed.

Lemma reff390_not3078 : ~ @Equation3078 Fin4 reff390_inst.
Proof. unfold Equation3078. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff390_inst, reff390_op in H. discriminate H. Qed.

Lemma reff390_not3102 : ~ @Equation3102 Fin4 reff390_inst.
Proof. unfold Equation3102. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff390_inst, reff390_op in H. discriminate H. Qed.

Lemma reff390_not3103 : ~ @Equation3103 Fin4 reff390_inst.
Proof. unfold Equation3103. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff390_inst, reff390_op in H. discriminate H. Qed.

Lemma reff390_not3105 : ~ @Equation3105 Fin4 reff390_inst.
Proof. unfold Equation3105. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff390_inst, reff390_op in H. discriminate H. Qed.

Lemma reff390_not3106 : ~ @Equation3106 Fin4 reff390_inst.
Proof. unfold Equation3106. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff390_inst, reff390_op in H. discriminate H. Qed.

Lemma reff390_not3112 : ~ @Equation3112 Fin4 reff390_inst.
Proof. unfold Equation3112. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff390_inst, reff390_op in H. discriminate H. Qed.

Lemma reff390_not3113 : ~ @Equation3113 Fin4 reff390_inst.
Proof. unfold Equation3113. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff390_inst, reff390_op in H. discriminate H. Qed.

Lemma reff390_not3115 : ~ @Equation3115 Fin4 reff390_inst.
Proof. unfold Equation3115. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff390_inst, reff390_op in H. discriminate H. Qed.

Lemma reff390_not3116 : ~ @Equation3116 Fin4 reff390_inst.
Proof. unfold Equation3116. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff390_inst, reff390_op in H. discriminate H. Qed.

Lemma reff390_not3139 : ~ @Equation3139 Fin4 reff390_inst.
Proof. unfold Equation3139. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff390_inst, reff390_op in H. discriminate H. Qed.

Lemma reff390_not3140 : ~ @Equation3140 Fin4 reff390_inst.
Proof. unfold Equation3140. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff390_inst, reff390_op in H. discriminate H. Qed.

Lemma reff390_not3142 : ~ @Equation3142 Fin4 reff390_inst.
Proof. unfold Equation3142. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff390_inst, reff390_op in H. discriminate H. Qed.

Lemma reff390_not3143 : ~ @Equation3143 Fin4 reff390_inst.
Proof. unfold Equation3143. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff390_inst, reff390_op in H. discriminate H. Qed.

Lemma reff390_not3149 : ~ @Equation3149 Fin4 reff390_inst.
Proof. unfold Equation3149. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff390_inst, reff390_op in H. discriminate H. Qed.

Lemma reff390_not3150 : ~ @Equation3150 Fin4 reff390_inst.
Proof. unfold Equation3150. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff390_inst, reff390_op in H. discriminate H. Qed.

Lemma reff390_not3152 : ~ @Equation3152 Fin4 reff390_inst.
Proof. unfold Equation3152. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff390_inst, reff390_op in H. discriminate H. Qed.

Lemma reff390_not3258 : ~ @Equation3258 Fin4 reff390_inst.
Proof. unfold Equation3258. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff390_inst, reff390_op in H. discriminate H. Qed.

Lemma reff390_not3259 : ~ @Equation3259 Fin4 reff390_inst.
Proof. unfold Equation3259. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff390_inst, reff390_op in H. discriminate H. Qed.

Lemma reff390_not3261 : ~ @Equation3261 Fin4 reff390_inst.
Proof. unfold Equation3261. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff390_inst, reff390_op in H. discriminate H. Qed.

Lemma reff390_not3262 : ~ @Equation3262 Fin4 reff390_inst.
Proof. unfold Equation3262. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff390_inst, reff390_op in H. discriminate H. Qed.

Lemma reff390_not3268 : ~ @Equation3268 Fin4 reff390_inst.
Proof. unfold Equation3268. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff390_inst, reff390_op in H. discriminate H. Qed.

Lemma reff390_not3269 : ~ @Equation3269 Fin4 reff390_inst.
Proof. unfold Equation3269. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff390_inst, reff390_op in H. discriminate H. Qed.

Lemma reff390_not3271 : ~ @Equation3271 Fin4 reff390_inst.
Proof. unfold Equation3271. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff390_inst, reff390_op in H. discriminate H. Qed.

Lemma reff390_not3272 : ~ @Equation3272 Fin4 reff390_inst.
Proof. unfold Equation3272. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff390_inst, reff390_op in H. discriminate H. Qed.

Lemma reff390_not3278 : ~ @Equation3278 Fin4 reff390_inst.
Proof. unfold Equation3278. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff390_inst, reff390_op in H. discriminate H. Qed.

Lemma reff390_not3279 : ~ @Equation3279 Fin4 reff390_inst.
Proof. unfold Equation3279. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff390_inst, reff390_op in H. discriminate H. Qed.

Lemma reff390_not3281 : ~ @Equation3281 Fin4 reff390_inst.
Proof. unfold Equation3281. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff390_inst, reff390_op in H. discriminate H. Qed.

Lemma reff390_not3306 : ~ @Equation3306 Fin4 reff390_inst.
Proof. unfold Equation3306. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff390_inst, reff390_op in H. discriminate H. Qed.

Lemma reff390_not3308 : ~ @Equation3308 Fin4 reff390_inst.
Proof. unfold Equation3308. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff390_inst, reff390_op in H. discriminate H. Qed.

Lemma reff390_not3309 : ~ @Equation3309 Fin4 reff390_inst.
Proof. unfold Equation3309. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff390_inst, reff390_op in H. discriminate H. Qed.

Lemma reff390_not3342 : ~ @Equation3342 Fin4 reff390_inst.
Proof. unfold Equation3342. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff390_inst, reff390_op in H. discriminate H. Qed.

Lemma reff390_not3343 : ~ @Equation3343 Fin4 reff390_inst.
Proof. unfold Equation3343. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff390_inst, reff390_op in H. discriminate H. Qed.

Lemma reff390_not3345 : ~ @Equation3345 Fin4 reff390_inst.
Proof. unfold Equation3345. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff390_inst, reff390_op in H. discriminate H. Qed.

Lemma reff390_not3346 : ~ @Equation3346 Fin4 reff390_inst.
Proof. unfold Equation3346. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff390_inst, reff390_op in H. discriminate H. Qed.

Lemma reff390_not3352 : ~ @Equation3352 Fin4 reff390_inst.
Proof. unfold Equation3352. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff390_inst, reff390_op in H. discriminate H. Qed.

Lemma reff390_not3353 : ~ @Equation3353 Fin4 reff390_inst.
Proof. unfold Equation3353. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff390_inst, reff390_op in H. discriminate H. Qed.

Lemma reff390_not3355 : ~ @Equation3355 Fin4 reff390_inst.
Proof. unfold Equation3355. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff390_inst, reff390_op in H. discriminate H. Qed.

Lemma reff390_not3461 : ~ @Equation3461 Fin4 reff390_inst.
Proof. unfold Equation3461. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff390_inst, reff390_op in H. discriminate H. Qed.

Lemma reff390_not3462 : ~ @Equation3462 Fin4 reff390_inst.
Proof. unfold Equation3462. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff390_inst, reff390_op in H. discriminate H. Qed.

Lemma reff390_not3464 : ~ @Equation3464 Fin4 reff390_inst.
Proof. unfold Equation3464. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff390_inst, reff390_op in H. discriminate H. Qed.

Lemma reff390_not3465 : ~ @Equation3465 Fin4 reff390_inst.
Proof. unfold Equation3465. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff390_inst, reff390_op in H. discriminate H. Qed.

Lemma reff390_not3472 : ~ @Equation3472 Fin4 reff390_inst.
Proof. unfold Equation3472. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff390_inst, reff390_op in H. discriminate H. Qed.

Lemma reff390_not3474 : ~ @Equation3474 Fin4 reff390_inst.
Proof. unfold Equation3474. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff390_inst, reff390_op in H. discriminate H. Qed.

Lemma reff390_not3475 : ~ @Equation3475 Fin4 reff390_inst.
Proof. unfold Equation3475. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff390_inst, reff390_op in H. discriminate H. Qed.

Lemma reff390_not3481 : ~ @Equation3481 Fin4 reff390_inst.
Proof. unfold Equation3481. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff390_inst, reff390_op in H. discriminate H. Qed.

Lemma reff390_not3482 : ~ @Equation3482 Fin4 reff390_inst.
Proof. unfold Equation3482. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff390_inst, reff390_op in H. discriminate H. Qed.

Lemma reff390_not3484 : ~ @Equation3484 Fin4 reff390_inst.
Proof. unfold Equation3484. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff390_inst, reff390_op in H. discriminate H. Qed.

Lemma reff390_not3509 : ~ @Equation3509 Fin4 reff390_inst.
Proof. unfold Equation3509. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff390_inst, reff390_op in H. discriminate H. Qed.

Lemma reff390_not3511 : ~ @Equation3511 Fin4 reff390_inst.
Proof. unfold Equation3511. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff390_inst, reff390_op in H. discriminate H. Qed.

Lemma reff390_not3512 : ~ @Equation3512 Fin4 reff390_inst.
Proof. unfold Equation3512. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff390_inst, reff390_op in H. discriminate H. Qed.

Lemma reff390_not3545 : ~ @Equation3545 Fin4 reff390_inst.
Proof. unfold Equation3545. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff390_inst, reff390_op in H. discriminate H. Qed.

Lemma reff390_not3546 : ~ @Equation3546 Fin4 reff390_inst.
Proof. unfold Equation3546. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff390_inst, reff390_op in H. discriminate H. Qed.

Lemma reff390_not3548 : ~ @Equation3548 Fin4 reff390_inst.
Proof. unfold Equation3548. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff390_inst, reff390_op in H. discriminate H. Qed.

Lemma reff390_not3549 : ~ @Equation3549 Fin4 reff390_inst.
Proof. unfold Equation3549. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff390_inst, reff390_op in H. discriminate H. Qed.

Lemma reff390_not3555 : ~ @Equation3555 Fin4 reff390_inst.
Proof. unfold Equation3555. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff390_inst, reff390_op in H. discriminate H. Qed.

Lemma reff390_not3556 : ~ @Equation3556 Fin4 reff390_inst.
Proof. unfold Equation3556. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff390_inst, reff390_op in H. discriminate H. Qed.

Lemma reff390_not3558 : ~ @Equation3558 Fin4 reff390_inst.
Proof. unfold Equation3558. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff390_inst, reff390_op in H. discriminate H. Qed.

Lemma reff390_not3661 : ~ @Equation3661 Fin4 reff390_inst.
Proof. unfold Equation3661. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff390_inst, reff390_op in H. discriminate H. Qed.

Lemma reff390_not3662 : ~ @Equation3662 Fin4 reff390_inst.
Proof. unfold Equation3662. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff390_inst, reff390_op in H. discriminate H. Qed.

Lemma reff390_not3664 : ~ @Equation3664 Fin4 reff390_inst.
Proof. unfold Equation3664. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff390_inst, reff390_op in H. discriminate H. Qed.

Lemma reff390_not3665 : ~ @Equation3665 Fin4 reff390_inst.
Proof. unfold Equation3665. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff390_inst, reff390_op in H. discriminate H. Qed.

Lemma reff390_not3674 : ~ @Equation3674 Fin4 reff390_inst.
Proof. unfold Equation3674. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff390_inst, reff390_op in H. discriminate H. Qed.

Lemma reff390_not3675 : ~ @Equation3675 Fin4 reff390_inst.
Proof. unfold Equation3675. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff390_inst, reff390_op in H. discriminate H. Qed.

Lemma reff390_not3677 : ~ @Equation3677 Fin4 reff390_inst.
Proof. unfold Equation3677. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff390_inst, reff390_op in H. discriminate H. Qed.

Lemma reff390_not3678 : ~ @Equation3678 Fin4 reff390_inst.
Proof. unfold Equation3678. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff390_inst, reff390_op in H. discriminate H. Qed.

Lemma reff390_not3684 : ~ @Equation3684 Fin4 reff390_inst.
Proof. unfold Equation3684. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff390_inst, reff390_op in H. discriminate H. Qed.

Lemma reff390_not3685 : ~ @Equation3685 Fin4 reff390_inst.
Proof. unfold Equation3685. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff390_inst, reff390_op in H. discriminate H. Qed.

Lemma reff390_not3687 : ~ @Equation3687 Fin4 reff390_inst.
Proof. unfold Equation3687. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff390_inst, reff390_op in H. discriminate H. Qed.

Lemma reff390_not3712 : ~ @Equation3712 Fin4 reff390_inst.
Proof. unfold Equation3712. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff390_inst, reff390_op in H. discriminate H. Qed.

Lemma reff390_not3724 : ~ @Equation3724 Fin4 reff390_inst.
Proof. unfold Equation3724. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff390_inst, reff390_op in H. discriminate H. Qed.

Lemma reff390_not3725 : ~ @Equation3725 Fin4 reff390_inst.
Proof. unfold Equation3725. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff390_inst, reff390_op in H. discriminate H. Qed.

Lemma reff390_not3748 : ~ @Equation3748 Fin4 reff390_inst.
Proof. unfold Equation3748. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff390_inst, reff390_op in H. discriminate H. Qed.

Lemma reff390_not3749 : ~ @Equation3749 Fin4 reff390_inst.
Proof. unfold Equation3749. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff390_inst, reff390_op in H. discriminate H. Qed.

Lemma reff390_not3751 : ~ @Equation3751 Fin4 reff390_inst.
Proof. unfold Equation3751. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff390_inst, reff390_op in H. discriminate H. Qed.

Lemma reff390_not3752 : ~ @Equation3752 Fin4 reff390_inst.
Proof. unfold Equation3752. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff390_inst, reff390_op in H. discriminate H. Qed.

Lemma reff390_not3758 : ~ @Equation3758 Fin4 reff390_inst.
Proof. unfold Equation3758. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff390_inst, reff390_op in H. discriminate H. Qed.

Lemma reff390_not3759 : ~ @Equation3759 Fin4 reff390_inst.
Proof. unfold Equation3759. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff390_inst, reff390_op in H. discriminate H. Qed.

Lemma reff390_not3761 : ~ @Equation3761 Fin4 reff390_inst.
Proof. unfold Equation3761. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff390_inst, reff390_op in H. discriminate H. Qed.

Lemma reff390_not3865 : ~ @Equation3865 Fin4 reff390_inst.
Proof. unfold Equation3865. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff390_inst, reff390_op in H. discriminate H. Qed.

Lemma reff390_not3867 : ~ @Equation3867 Fin4 reff390_inst.
Proof. unfold Equation3867. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff390_inst, reff390_op in H. discriminate H. Qed.

Lemma reff390_not3870 : ~ @Equation3870 Fin4 reff390_inst.
Proof. unfold Equation3870. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff390_inst, reff390_op in H. discriminate H. Qed.

Lemma reff390_not3877 : ~ @Equation3877 Fin4 reff390_inst.
Proof. unfold Equation3877. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff390_inst, reff390_op in H. discriminate H. Qed.

Lemma reff390_not3878 : ~ @Equation3878 Fin4 reff390_inst.
Proof. unfold Equation3878. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff390_inst, reff390_op in H. discriminate H. Qed.

Lemma reff390_not3880 : ~ @Equation3880 Fin4 reff390_inst.
Proof. unfold Equation3880. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff390_inst, reff390_op in H. discriminate H. Qed.

Lemma reff390_not3881 : ~ @Equation3881 Fin4 reff390_inst.
Proof. unfold Equation3881. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff390_inst, reff390_op in H. discriminate H. Qed.

Lemma reff390_not3887 : ~ @Equation3887 Fin4 reff390_inst.
Proof. unfold Equation3887. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff390_inst, reff390_op in H. discriminate H. Qed.

Lemma reff390_not3888 : ~ @Equation3888 Fin4 reff390_inst.
Proof. unfold Equation3888. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff390_inst, reff390_op in H. discriminate H. Qed.

Lemma reff390_not3890 : ~ @Equation3890 Fin4 reff390_inst.
Proof. unfold Equation3890. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff390_inst, reff390_op in H. discriminate H. Qed.

Lemma reff390_not3917 : ~ @Equation3917 Fin4 reff390_inst.
Proof. unfold Equation3917. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff390_inst, reff390_op in H. discriminate H. Qed.

Lemma reff390_not3925 : ~ @Equation3925 Fin4 reff390_inst.
Proof. unfold Equation3925. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff390_inst, reff390_op in H. discriminate H. Qed.

Lemma reff390_not3928 : ~ @Equation3928 Fin4 reff390_inst.
Proof. unfold Equation3928. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff390_inst, reff390_op in H. discriminate H. Qed.

Lemma reff390_not3951 : ~ @Equation3951 Fin4 reff390_inst.
Proof. unfold Equation3951. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff390_inst, reff390_op in H. discriminate H. Qed.

Lemma reff390_not3952 : ~ @Equation3952 Fin4 reff390_inst.
Proof. unfold Equation3952. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff390_inst, reff390_op in H. discriminate H. Qed.

Lemma reff390_not3954 : ~ @Equation3954 Fin4 reff390_inst.
Proof. unfold Equation3954. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff390_inst, reff390_op in H. discriminate H. Qed.

Lemma reff390_not3955 : ~ @Equation3955 Fin4 reff390_inst.
Proof. unfold Equation3955. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff390_inst, reff390_op in H. discriminate H. Qed.

Lemma reff390_not3961 : ~ @Equation3961 Fin4 reff390_inst.
Proof. unfold Equation3961. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff390_inst, reff390_op in H. discriminate H. Qed.

Lemma reff390_not3962 : ~ @Equation3962 Fin4 reff390_inst.
Proof. unfold Equation3962. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff390_inst, reff390_op in H. discriminate H. Qed.

Lemma reff390_not3964 : ~ @Equation3964 Fin4 reff390_inst.
Proof. unfold Equation3964. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff390_inst, reff390_op in H. discriminate H. Qed.

Lemma reff390_not4066 : ~ @Equation4066 Fin4 reff390_inst.
Proof. unfold Equation4066. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff390_inst, reff390_op in H. discriminate H. Qed.

Lemma reff390_not4067 : ~ @Equation4067 Fin4 reff390_inst.
Proof. unfold Equation4067. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff390_inst, reff390_op in H. discriminate H. Qed.

Lemma reff390_not4070 : ~ @Equation4070 Fin4 reff390_inst.
Proof. unfold Equation4070. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff390_inst, reff390_op in H. discriminate H. Qed.

Lemma reff390_not4074 : ~ @Equation4074 Fin4 reff390_inst.
Proof. unfold Equation4074. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff390_inst, reff390_op in H. discriminate H. Qed.

Lemma reff390_not4080 : ~ @Equation4080 Fin4 reff390_inst.
Proof. unfold Equation4080. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff390_inst, reff390_op in H. discriminate H. Qed.

Lemma reff390_not4081 : ~ @Equation4081 Fin4 reff390_inst.
Proof. unfold Equation4081. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff390_inst, reff390_op in H. discriminate H. Qed.

Lemma reff390_not4083 : ~ @Equation4083 Fin4 reff390_inst.
Proof. unfold Equation4083. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff390_inst, reff390_op in H. discriminate H. Qed.

Lemma reff390_not4084 : ~ @Equation4084 Fin4 reff390_inst.
Proof. unfold Equation4084. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff390_inst, reff390_op in H. discriminate H. Qed.

Lemma reff390_not4090 : ~ @Equation4090 Fin4 reff390_inst.
Proof. unfold Equation4090. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff390_inst, reff390_op in H. discriminate H. Qed.

Lemma reff390_not4091 : ~ @Equation4091 Fin4 reff390_inst.
Proof. unfold Equation4091. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff390_inst, reff390_op in H. discriminate H. Qed.

Lemma reff390_not4093 : ~ @Equation4093 Fin4 reff390_inst.
Proof. unfold Equation4093. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff390_inst, reff390_op in H. discriminate H. Qed.

Lemma reff390_not4121 : ~ @Equation4121 Fin4 reff390_inst.
Proof. unfold Equation4121. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff390_inst, reff390_op in H. discriminate H. Qed.

Lemma reff390_not4128 : ~ @Equation4128 Fin4 reff390_inst.
Proof. unfold Equation4128. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff390_inst, reff390_op in H. discriminate H. Qed.

Lemma reff390_not4130 : ~ @Equation4130 Fin4 reff390_inst.
Proof. unfold Equation4130. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff390_inst, reff390_op in H. discriminate H. Qed.

Lemma reff390_not4154 : ~ @Equation4154 Fin4 reff390_inst.
Proof. unfold Equation4154. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff390_inst, reff390_op in H. discriminate H. Qed.

Lemma reff390_not4155 : ~ @Equation4155 Fin4 reff390_inst.
Proof. unfold Equation4155. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff390_inst, reff390_op in H. discriminate H. Qed.

Lemma reff390_not4157 : ~ @Equation4157 Fin4 reff390_inst.
Proof. unfold Equation4157. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff390_inst, reff390_op in H. discriminate H. Qed.

Lemma reff390_not4158 : ~ @Equation4158 Fin4 reff390_inst.
Proof. unfold Equation4158. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff390_inst, reff390_op in H. discriminate H. Qed.

Lemma reff390_not4164 : ~ @Equation4164 Fin4 reff390_inst.
Proof. unfold Equation4164. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff390_inst, reff390_op in H. discriminate H. Qed.

Lemma reff390_not4165 : ~ @Equation4165 Fin4 reff390_inst.
Proof. unfold Equation4165. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff390_inst, reff390_op in H. discriminate H. Qed.

Lemma reff390_not4167 : ~ @Equation4167 Fin4 reff390_inst.
Proof. unfold Equation4167. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff390_inst, reff390_op in H. discriminate H. Qed.

Lemma reff390_not4269 : ~ @Equation4269 Fin4 reff390_inst.
Proof. unfold Equation4269. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff390_inst, reff390_op in H. discriminate H. Qed.

Lemma reff390_not4270 : ~ @Equation4270 Fin4 reff390_inst.
Proof. unfold Equation4270. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff390_inst, reff390_op in H. discriminate H. Qed.

Lemma reff390_not4272 : ~ @Equation4272 Fin4 reff390_inst.
Proof. unfold Equation4272. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff390_inst, reff390_op in H. discriminate H. Qed.

Lemma reff390_not4273 : ~ @Equation4273 Fin4 reff390_inst.
Proof. unfold Equation4273. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff390_inst, reff390_op in H. discriminate H. Qed.

Lemma reff390_not4275 : ~ @Equation4275 Fin4 reff390_inst.
Proof. unfold Equation4275. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff390_inst, reff390_op in H. discriminate H. Qed.

Lemma reff390_not4276 : ~ @Equation4276 Fin4 reff390_inst.
Proof. unfold Equation4276. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff390_inst, reff390_op in H. discriminate H. Qed.

Lemma reff390_not4283 : ~ @Equation4283 Fin4 reff390_inst.
Proof. unfold Equation4283. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff390_inst, reff390_op in H. discriminate H. Qed.

Lemma reff390_not4284 : ~ @Equation4284 Fin4 reff390_inst.
Proof. unfold Equation4284. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff390_inst, reff390_op in H. discriminate H. Qed.

Lemma reff390_not4290 : ~ @Equation4290 Fin4 reff390_inst.
Proof. unfold Equation4290. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff390_inst, reff390_op in H. discriminate H. Qed.

Lemma reff390_not4291 : ~ @Equation4291 Fin4 reff390_inst.
Proof. unfold Equation4291. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff390_inst, reff390_op in H. discriminate H. Qed.

Lemma reff390_not4293 : ~ @Equation4293 Fin4 reff390_inst.
Proof. unfold Equation4293. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff390_inst, reff390_op in H. discriminate H. Qed.

Lemma reff390_not4320 : ~ @Equation4320 Fin4 reff390_inst.
Proof. unfold Equation4320. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff390_inst, reff390_op in H. discriminate H. Qed.

Lemma reff390_not4321 : ~ @Equation4321 Fin4 reff390_inst.
Proof. unfold Equation4321. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff390_inst, reff390_op in H. discriminate H. Qed.

Lemma reff390_not4343 : ~ @Equation4343 Fin4 reff390_inst.
Proof. unfold Equation4343. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff390_inst, reff390_op in H. discriminate H. Qed.

Lemma reff390_not4396 : ~ @Equation4396 Fin4 reff390_inst.
Proof. unfold Equation4396. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff390_inst, reff390_op in H. discriminate H. Qed.

Lemma reff390_not4398 : ~ @Equation4398 Fin4 reff390_inst.
Proof. unfold Equation4398. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff390_inst, reff390_op in H. discriminate H. Qed.

Lemma reff390_not4405 : ~ @Equation4405 Fin4 reff390_inst.
Proof. unfold Equation4405. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff390_inst, reff390_op in H. discriminate H. Qed.

Lemma reff390_not4406 : ~ @Equation4406 Fin4 reff390_inst.
Proof. unfold Equation4406. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff390_inst, reff390_op in H. discriminate H. Qed.

Lemma reff390_not4408 : ~ @Equation4408 Fin4 reff390_inst.
Proof. unfold Equation4408. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff390_inst, reff390_op in H. discriminate H. Qed.

Lemma reff390_not4436 : ~ @Equation4436 Fin4 reff390_inst.
Proof. unfold Equation4436. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff390_inst, reff390_op in H. discriminate H. Qed.

Lemma reff390_not4442 : ~ @Equation4442 Fin4 reff390_inst.
Proof. unfold Equation4442. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff390_inst, reff390_op in H. discriminate H. Qed.

Lemma reff390_not4443 : ~ @Equation4443 Fin4 reff390_inst.
Proof. unfold Equation4443. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff390_inst, reff390_op in H. discriminate H. Qed.

Lemma reff390_not4445 : ~ @Equation4445 Fin4 reff390_inst.
Proof. unfold Equation4445. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff390_inst, reff390_op in H. discriminate H. Qed.

Lemma reff390_not4473 : ~ @Equation4473 Fin4 reff390_inst.
Proof. unfold Equation4473. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff390_inst, reff390_op in H. discriminate H. Qed.

Lemma reff390_not4479 : ~ @Equation4479 Fin4 reff390_inst.
Proof. unfold Equation4479. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff390_inst, reff390_op in H. discriminate H. Qed.

Lemma reff390_not4480 : ~ @Equation4480 Fin4 reff390_inst.
Proof. unfold Equation4480. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff390_inst, reff390_op in H. discriminate H. Qed.

Lemma reff390_not4482 : ~ @Equation4482 Fin4 reff390_inst.
Proof. unfold Equation4482. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff390_inst, reff390_op in H. discriminate H. Qed.

Lemma reff390_not4583 : ~ @Equation4583 Fin4 reff390_inst.
Proof. unfold Equation4583. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff390_inst, reff390_op in H. discriminate H. Qed.

Lemma reff390_not4584 : ~ @Equation4584 Fin4 reff390_inst.
Proof. unfold Equation4584. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff390_inst, reff390_op in H. discriminate H. Qed.

Lemma reff390_not4587 : ~ @Equation4587 Fin4 reff390_inst.
Proof. unfold Equation4587. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff390_inst, reff390_op in H. discriminate H. Qed.

Lemma reff390_not4588 : ~ @Equation4588 Fin4 reff390_inst.
Proof. unfold Equation4588. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff390_inst, reff390_op in H. discriminate H. Qed.

Lemma reff390_not4590 : ~ @Equation4590 Fin4 reff390_inst.
Proof. unfold Equation4590. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff390_inst, reff390_op in H. discriminate H. Qed.

Lemma reff390_not4591 : ~ @Equation4591 Fin4 reff390_inst.
Proof. unfold Equation4591. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff390_inst, reff390_op in H. discriminate H. Qed.

Lemma reff390_not4599 : ~ @Equation4599 Fin4 reff390_inst.
Proof. unfold Equation4599. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff390_inst, reff390_op in H. discriminate H. Qed.

Lemma reff390_not4605 : ~ @Equation4605 Fin4 reff390_inst.
Proof. unfold Equation4605. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff390_inst, reff390_op in H. discriminate H. Qed.

Lemma reff390_not4606 : ~ @Equation4606 Fin4 reff390_inst.
Proof. unfold Equation4606. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff390_inst, reff390_op in H. discriminate H. Qed.

Lemma reff390_not4608 : ~ @Equation4608 Fin4 reff390_inst.
Proof. unfold Equation4608. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff390_inst, reff390_op in H. discriminate H. Qed.

Lemma reff390_not4629 : ~ @Equation4629 Fin4 reff390_inst.
Proof. unfold Equation4629. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff390_inst, reff390_op in H. discriminate H. Qed.

Lemma reff390_not4635 : ~ @Equation4635 Fin4 reff390_inst.
Proof. unfold Equation4635. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff390_inst, reff390_op in H. discriminate H. Qed.

Lemma reff390_not4636 : ~ @Equation4636 Fin4 reff390_inst.
Proof. unfold Equation4636. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff390_inst, reff390_op in H. discriminate H. Qed.

Lemma reff390_not4658 : ~ @Equation4658 Fin4 reff390_inst.
Proof. unfold Equation4658. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff390_inst, reff390_op in H. discriminate H. Qed.

(** ---- reff394 (Fin4) ---- *)

Definition reff394_op (x y : Fin4) : Fin4 :=
  match x, y with
  | F4_0, F4_0 => F4_0 | F4_0, F4_1 => F4_0 | F4_0, F4_2 => F4_0 | F4_0, F4_3 => F4_0
  | F4_1, F4_0 => F4_0 | F4_1, F4_1 => F4_2 | F4_1, F4_2 => F4_0 | F4_1, F4_3 => F4_2
  | F4_2, F4_0 => F4_0 | F4_2, F4_1 => F4_0 | F4_2, F4_2 => F4_0 | F4_2, F4_3 => F4_0
  | F4_3, F4_0 => F4_0 | F4_3, F4_1 => F4_2 | F4_3, F4_2 => F4_0 | F4_3, F4_3 => F4_2
  end.

#[local] Instance reff394_inst : Magma Fin4 := {| magma_op := reff394_op |}.

Lemma reff394_sat4534 : @Equation4534 Fin4 reff394_inst.
Proof. unfold Equation4534, magma_op, reff394_inst, reff394_op. intros x y z w. destruct x, y, z, w; reflexivity. Qed.

Lemma reff394_not47 : ~ @Equation47 Fin4 reff394_inst.
Proof. unfold Equation47. intro H. specialize (H F4_1). unfold magma_op, reff394_inst, reff394_op in H. discriminate H. Qed.

Lemma reff394_not99 : ~ @Equation99 Fin4 reff394_inst.
Proof. unfold Equation99. intro H. specialize (H F4_1). unfold magma_op, reff394_inst, reff394_op in H. discriminate H. Qed.

Lemma reff394_not151 : ~ @Equation151 Fin4 reff394_inst.
Proof. unfold Equation151. intro H. specialize (H F4_1). unfold magma_op, reff394_inst, reff394_op in H. discriminate H. Qed.

Lemma reff394_not203 : ~ @Equation203 Fin4 reff394_inst.
Proof. unfold Equation203. intro H. specialize (H F4_1). unfold magma_op, reff394_inst, reff394_op in H. discriminate H. Qed.

Lemma reff394_not255 : ~ @Equation255 Fin4 reff394_inst.
Proof. unfold Equation255. intro H. specialize (H F4_1). unfold magma_op, reff394_inst, reff394_op in H. discriminate H. Qed.

Lemma reff394_not411 : ~ @Equation411 Fin4 reff394_inst.
Proof. unfold Equation411. intro H. specialize (H F4_1). unfold magma_op, reff394_inst, reff394_op in H. discriminate H. Qed.

Lemma reff394_not614 : ~ @Equation614 Fin4 reff394_inst.
Proof. unfold Equation614. intro H. specialize (H F4_1). unfold magma_op, reff394_inst, reff394_op in H. discriminate H. Qed.

Lemma reff394_not817 : ~ @Equation817 Fin4 reff394_inst.
Proof. unfold Equation817. intro H. specialize (H F4_1). unfold magma_op, reff394_inst, reff394_op in H. discriminate H. Qed.

Lemma reff394_not1020 : ~ @Equation1020 Fin4 reff394_inst.
Proof. unfold Equation1020. intro H. specialize (H F4_1). unfold magma_op, reff394_inst, reff394_op in H. discriminate H. Qed.

Lemma reff394_not1223 : ~ @Equation1223 Fin4 reff394_inst.
Proof. unfold Equation1223. intro H. specialize (H F4_1). unfold magma_op, reff394_inst, reff394_op in H. discriminate H. Qed.

Lemma reff394_not1426 : ~ @Equation1426 Fin4 reff394_inst.
Proof. unfold Equation1426. intro H. specialize (H F4_1). unfold magma_op, reff394_inst, reff394_op in H. discriminate H. Qed.

Lemma reff394_not1629 : ~ @Equation1629 Fin4 reff394_inst.
Proof. unfold Equation1629. intro H. specialize (H F4_1). unfold magma_op, reff394_inst, reff394_op in H. discriminate H. Qed.

Lemma reff394_not1832 : ~ @Equation1832 Fin4 reff394_inst.
Proof. unfold Equation1832. intro H. specialize (H F4_1). unfold magma_op, reff394_inst, reff394_op in H. discriminate H. Qed.

Lemma reff394_not2035 : ~ @Equation2035 Fin4 reff394_inst.
Proof. unfold Equation2035. intro H. specialize (H F4_1). unfold magma_op, reff394_inst, reff394_op in H. discriminate H. Qed.

Lemma reff394_not2238 : ~ @Equation2238 Fin4 reff394_inst.
Proof. unfold Equation2238. intro H. specialize (H F4_1). unfold magma_op, reff394_inst, reff394_op in H. discriminate H. Qed.

Lemma reff394_not2441 : ~ @Equation2441 Fin4 reff394_inst.
Proof. unfold Equation2441. intro H. specialize (H F4_1). unfold magma_op, reff394_inst, reff394_op in H. discriminate H. Qed.

Lemma reff394_not2644 : ~ @Equation2644 Fin4 reff394_inst.
Proof. unfold Equation2644. intro H. specialize (H F4_1). unfold magma_op, reff394_inst, reff394_op in H. discriminate H. Qed.

Lemma reff394_not2847 : ~ @Equation2847 Fin4 reff394_inst.
Proof. unfold Equation2847. intro H. specialize (H F4_1). unfold magma_op, reff394_inst, reff394_op in H. discriminate H. Qed.

Lemma reff394_not3050 : ~ @Equation3050 Fin4 reff394_inst.
Proof. unfold Equation3050. intro H. specialize (H F4_1). unfold magma_op, reff394_inst, reff394_op in H. discriminate H. Qed.

Lemma reff394_not3253 : ~ @Equation3253 Fin4 reff394_inst.
Proof. unfold Equation3253. intro H. specialize (H F4_1). unfold magma_op, reff394_inst, reff394_op in H. discriminate H. Qed.

Lemma reff394_not3456 : ~ @Equation3456 Fin4 reff394_inst.
Proof. unfold Equation3456. intro H. specialize (H F4_1). unfold magma_op, reff394_inst, reff394_op in H. discriminate H. Qed.

Lemma reff394_not3659 : ~ @Equation3659 Fin4 reff394_inst.
Proof. unfold Equation3659. intro H. specialize (H F4_1). unfold magma_op, reff394_inst, reff394_op in H. discriminate H. Qed.

Lemma reff394_not3862 : ~ @Equation3862 Fin4 reff394_inst.
Proof. unfold Equation3862. intro H. specialize (H F4_1). unfold magma_op, reff394_inst, reff394_op in H. discriminate H. Qed.

Lemma reff394_not4065 : ~ @Equation4065 Fin4 reff394_inst.
Proof. unfold Equation4065. intro H. specialize (H F4_1). unfold magma_op, reff394_inst, reff394_op in H. discriminate H. Qed.

(** ---- reff40 (Fin4) ---- *)

Definition reff40_op (x y : Fin4) : Fin4 :=
  match x, y with
  | F4_0, F4_0 => F4_0 | F4_0, F4_1 => F4_0 | F4_0, F4_2 => F4_0 | F4_0, F4_3 => F4_0
  | F4_1, F4_0 => F4_2 | F4_1, F4_1 => F4_2 | F4_1, F4_2 => F4_2 | F4_1, F4_3 => F4_2
  | F4_2, F4_0 => F4_2 | F4_2, F4_1 => F4_2 | F4_2, F4_2 => F4_2 | F4_2, F4_3 => F4_2
  | F4_3, F4_0 => F4_0 | F4_3, F4_1 => F4_0 | F4_3, F4_2 => F4_0 | F4_3, F4_3 => F4_0
  end.

#[local] Instance reff40_inst : Magma Fin4 := {| magma_op := reff40_op |}.

Lemma reff40_sat374 : @Equation374 Fin4 reff40_inst.
Proof. unfold Equation374, magma_op, reff40_inst, reff40_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff40_not47 : ~ @Equation47 Fin4 reff40_inst.
Proof. unfold Equation47. intro H. specialize (H F4_1). unfold magma_op, reff40_inst, reff40_op in H. discriminate H. Qed.

Lemma reff40_not99 : ~ @Equation99 Fin4 reff40_inst.
Proof. unfold Equation99. intro H. specialize (H F4_1). unfold magma_op, reff40_inst, reff40_op in H. discriminate H. Qed.

Lemma reff40_not151 : ~ @Equation151 Fin4 reff40_inst.
Proof. unfold Equation151. intro H. specialize (H F4_1). unfold magma_op, reff40_inst, reff40_op in H. discriminate H. Qed.

Lemma reff40_not203 : ~ @Equation203 Fin4 reff40_inst.
Proof. unfold Equation203. intro H. specialize (H F4_1). unfold magma_op, reff40_inst, reff40_op in H. discriminate H. Qed.

Lemma reff40_not255 : ~ @Equation255 Fin4 reff40_inst.
Proof. unfold Equation255. intro H. specialize (H F4_1). unfold magma_op, reff40_inst, reff40_op in H. discriminate H. Qed.

Lemma reff40_not384 : ~ @Equation384 Fin4 reff40_inst.
Proof. unfold Equation384. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff40_inst, reff40_op in H. discriminate H. Qed.

Lemma reff40_not411 : ~ @Equation411 Fin4 reff40_inst.
Proof. unfold Equation411. intro H. specialize (H F4_1). unfold magma_op, reff40_inst, reff40_op in H. discriminate H. Qed.

Lemma reff40_not614 : ~ @Equation614 Fin4 reff40_inst.
Proof. unfold Equation614. intro H. specialize (H F4_1). unfold magma_op, reff40_inst, reff40_op in H. discriminate H. Qed.

Lemma reff40_not817 : ~ @Equation817 Fin4 reff40_inst.
Proof. unfold Equation817. intro H. specialize (H F4_1). unfold magma_op, reff40_inst, reff40_op in H. discriminate H. Qed.

Lemma reff40_not1020 : ~ @Equation1020 Fin4 reff40_inst.
Proof. unfold Equation1020. intro H. specialize (H F4_1). unfold magma_op, reff40_inst, reff40_op in H. discriminate H. Qed.

Lemma reff40_not1223 : ~ @Equation1223 Fin4 reff40_inst.
Proof. unfold Equation1223. intro H. specialize (H F4_1). unfold magma_op, reff40_inst, reff40_op in H. discriminate H. Qed.

Lemma reff40_not1426 : ~ @Equation1426 Fin4 reff40_inst.
Proof. unfold Equation1426. intro H. specialize (H F4_1). unfold magma_op, reff40_inst, reff40_op in H. discriminate H. Qed.

Lemma reff40_not1629 : ~ @Equation1629 Fin4 reff40_inst.
Proof. unfold Equation1629. intro H. specialize (H F4_1). unfold magma_op, reff40_inst, reff40_op in H. discriminate H. Qed.

Lemma reff40_not1832 : ~ @Equation1832 Fin4 reff40_inst.
Proof. unfold Equation1832. intro H. specialize (H F4_1). unfold magma_op, reff40_inst, reff40_op in H. discriminate H. Qed.

Lemma reff40_not2035 : ~ @Equation2035 Fin4 reff40_inst.
Proof. unfold Equation2035. intro H. specialize (H F4_1). unfold magma_op, reff40_inst, reff40_op in H. discriminate H. Qed.

Lemma reff40_not2238 : ~ @Equation2238 Fin4 reff40_inst.
Proof. unfold Equation2238. intro H. specialize (H F4_1). unfold magma_op, reff40_inst, reff40_op in H. discriminate H. Qed.

Lemma reff40_not2441 : ~ @Equation2441 Fin4 reff40_inst.
Proof. unfold Equation2441. intro H. specialize (H F4_1). unfold magma_op, reff40_inst, reff40_op in H. discriminate H. Qed.

Lemma reff40_not2644 : ~ @Equation2644 Fin4 reff40_inst.
Proof. unfold Equation2644. intro H. specialize (H F4_1). unfold magma_op, reff40_inst, reff40_op in H. discriminate H. Qed.

Lemma reff40_not2847 : ~ @Equation2847 Fin4 reff40_inst.
Proof. unfold Equation2847. intro H. specialize (H F4_1). unfold magma_op, reff40_inst, reff40_op in H. discriminate H. Qed.

Lemma reff40_not3050 : ~ @Equation3050 Fin4 reff40_inst.
Proof. unfold Equation3050. intro H. specialize (H F4_1). unfold magma_op, reff40_inst, reff40_op in H. discriminate H. Qed.

Lemma reff40_not3268 : ~ @Equation3268 Fin4 reff40_inst.
Proof. unfold Equation3268. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff40_inst, reff40_op in H. discriminate H. Qed.

Lemma reff40_not3269 : ~ @Equation3269 Fin4 reff40_inst.
Proof. unfold Equation3269. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff40_inst, reff40_op in H. discriminate H. Qed.

Lemma reff40_not3271 : ~ @Equation3271 Fin4 reff40_inst.
Proof. unfold Equation3271. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff40_inst, reff40_op in H. discriminate H. Qed.

Lemma reff40_not3272 : ~ @Equation3272 Fin4 reff40_inst.
Proof. unfold Equation3272. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff40_inst, reff40_op in H. discriminate H. Qed.

Lemma reff40_not3278 : ~ @Equation3278 Fin4 reff40_inst.
Proof. unfold Equation3278. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff40_inst, reff40_op in H. discriminate H. Qed.

Lemma reff40_not3279 : ~ @Equation3279 Fin4 reff40_inst.
Proof. unfold Equation3279. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff40_inst, reff40_op in H. discriminate H. Qed.

Lemma reff40_not3281 : ~ @Equation3281 Fin4 reff40_inst.
Proof. unfold Equation3281. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff40_inst, reff40_op in H. discriminate H. Qed.

Lemma reff40_not3342 : ~ @Equation3342 Fin4 reff40_inst.
Proof. unfold Equation3342. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff40_inst, reff40_op in H. discriminate H. Qed.

Lemma reff40_not3343 : ~ @Equation3343 Fin4 reff40_inst.
Proof. unfold Equation3343. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff40_inst, reff40_op in H. discriminate H. Qed.

Lemma reff40_not3345 : ~ @Equation3345 Fin4 reff40_inst.
Proof. unfold Equation3345. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff40_inst, reff40_op in H. discriminate H. Qed.

Lemma reff40_not3346 : ~ @Equation3346 Fin4 reff40_inst.
Proof. unfold Equation3346. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff40_inst, reff40_op in H. discriminate H. Qed.

Lemma reff40_not3352 : ~ @Equation3352 Fin4 reff40_inst.
Proof. unfold Equation3352. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff40_inst, reff40_op in H. discriminate H. Qed.

Lemma reff40_not3353 : ~ @Equation3353 Fin4 reff40_inst.
Proof. unfold Equation3353. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff40_inst, reff40_op in H. discriminate H. Qed.

Lemma reff40_not3355 : ~ @Equation3355 Fin4 reff40_inst.
Proof. unfold Equation3355. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff40_inst, reff40_op in H. discriminate H. Qed.

Lemma reff40_not3472 : ~ @Equation3472 Fin4 reff40_inst.
Proof. unfold Equation3472. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff40_inst, reff40_op in H. discriminate H. Qed.

Lemma reff40_not3474 : ~ @Equation3474 Fin4 reff40_inst.
Proof. unfold Equation3474. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff40_inst, reff40_op in H. discriminate H. Qed.

Lemma reff40_not3475 : ~ @Equation3475 Fin4 reff40_inst.
Proof. unfold Equation3475. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff40_inst, reff40_op in H. discriminate H. Qed.

Lemma reff40_not3481 : ~ @Equation3481 Fin4 reff40_inst.
Proof. unfold Equation3481. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff40_inst, reff40_op in H. discriminate H. Qed.

Lemma reff40_not3482 : ~ @Equation3482 Fin4 reff40_inst.
Proof. unfold Equation3482. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff40_inst, reff40_op in H. discriminate H. Qed.

Lemma reff40_not3484 : ~ @Equation3484 Fin4 reff40_inst.
Proof. unfold Equation3484. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff40_inst, reff40_op in H. discriminate H. Qed.

Lemma reff40_not3545 : ~ @Equation3545 Fin4 reff40_inst.
Proof. unfold Equation3545. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff40_inst, reff40_op in H. discriminate H. Qed.

Lemma reff40_not3546 : ~ @Equation3546 Fin4 reff40_inst.
Proof. unfold Equation3546. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff40_inst, reff40_op in H. discriminate H. Qed.

Lemma reff40_not3548 : ~ @Equation3548 Fin4 reff40_inst.
Proof. unfold Equation3548. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff40_inst, reff40_op in H. discriminate H. Qed.

Lemma reff40_not3549 : ~ @Equation3549 Fin4 reff40_inst.
Proof. unfold Equation3549. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff40_inst, reff40_op in H. discriminate H. Qed.

Lemma reff40_not3555 : ~ @Equation3555 Fin4 reff40_inst.
Proof. unfold Equation3555. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff40_inst, reff40_op in H. discriminate H. Qed.

Lemma reff40_not3556 : ~ @Equation3556 Fin4 reff40_inst.
Proof. unfold Equation3556. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff40_inst, reff40_op in H. discriminate H. Qed.

Lemma reff40_not3558 : ~ @Equation3558 Fin4 reff40_inst.
Proof. unfold Equation3558. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff40_inst, reff40_op in H. discriminate H. Qed.

Lemma reff40_not3674 : ~ @Equation3674 Fin4 reff40_inst.
Proof. unfold Equation3674. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff40_inst, reff40_op in H. discriminate H. Qed.

Lemma reff40_not3675 : ~ @Equation3675 Fin4 reff40_inst.
Proof. unfold Equation3675. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff40_inst, reff40_op in H. discriminate H. Qed.

Lemma reff40_not3677 : ~ @Equation3677 Fin4 reff40_inst.
Proof. unfold Equation3677. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff40_inst, reff40_op in H. discriminate H. Qed.

Lemma reff40_not3678 : ~ @Equation3678 Fin4 reff40_inst.
Proof. unfold Equation3678. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff40_inst, reff40_op in H. discriminate H. Qed.

Lemma reff40_not3684 : ~ @Equation3684 Fin4 reff40_inst.
Proof. unfold Equation3684. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff40_inst, reff40_op in H. discriminate H. Qed.

Lemma reff40_not3685 : ~ @Equation3685 Fin4 reff40_inst.
Proof. unfold Equation3685. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff40_inst, reff40_op in H. discriminate H. Qed.

Lemma reff40_not3687 : ~ @Equation3687 Fin4 reff40_inst.
Proof. unfold Equation3687. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff40_inst, reff40_op in H. discriminate H. Qed.

Lemma reff40_not3748 : ~ @Equation3748 Fin4 reff40_inst.
Proof. unfold Equation3748. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff40_inst, reff40_op in H. discriminate H. Qed.

Lemma reff40_not3749 : ~ @Equation3749 Fin4 reff40_inst.
Proof. unfold Equation3749. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff40_inst, reff40_op in H. discriminate H. Qed.

Lemma reff40_not3751 : ~ @Equation3751 Fin4 reff40_inst.
Proof. unfold Equation3751. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff40_inst, reff40_op in H. discriminate H. Qed.

Lemma reff40_not3752 : ~ @Equation3752 Fin4 reff40_inst.
Proof. unfold Equation3752. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff40_inst, reff40_op in H. discriminate H. Qed.

Lemma reff40_not3758 : ~ @Equation3758 Fin4 reff40_inst.
Proof. unfold Equation3758. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff40_inst, reff40_op in H. discriminate H. Qed.

Lemma reff40_not3759 : ~ @Equation3759 Fin4 reff40_inst.
Proof. unfold Equation3759. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff40_inst, reff40_op in H. discriminate H. Qed.

Lemma reff40_not3761 : ~ @Equation3761 Fin4 reff40_inst.
Proof. unfold Equation3761. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff40_inst, reff40_op in H. discriminate H. Qed.

Lemma reff40_not3877 : ~ @Equation3877 Fin4 reff40_inst.
Proof. unfold Equation3877. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff40_inst, reff40_op in H. discriminate H. Qed.

Lemma reff40_not3878 : ~ @Equation3878 Fin4 reff40_inst.
Proof. unfold Equation3878. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff40_inst, reff40_op in H. discriminate H. Qed.

Lemma reff40_not3880 : ~ @Equation3880 Fin4 reff40_inst.
Proof. unfold Equation3880. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff40_inst, reff40_op in H. discriminate H. Qed.

Lemma reff40_not3881 : ~ @Equation3881 Fin4 reff40_inst.
Proof. unfold Equation3881. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff40_inst, reff40_op in H. discriminate H. Qed.

Lemma reff40_not3887 : ~ @Equation3887 Fin4 reff40_inst.
Proof. unfold Equation3887. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff40_inst, reff40_op in H. discriminate H. Qed.

Lemma reff40_not3888 : ~ @Equation3888 Fin4 reff40_inst.
Proof. unfold Equation3888. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff40_inst, reff40_op in H. discriminate H. Qed.

Lemma reff40_not3890 : ~ @Equation3890 Fin4 reff40_inst.
Proof. unfold Equation3890. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff40_inst, reff40_op in H. discriminate H. Qed.

Lemma reff40_not3951 : ~ @Equation3951 Fin4 reff40_inst.
Proof. unfold Equation3951. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff40_inst, reff40_op in H. discriminate H. Qed.

Lemma reff40_not3952 : ~ @Equation3952 Fin4 reff40_inst.
Proof. unfold Equation3952. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff40_inst, reff40_op in H. discriminate H. Qed.

Lemma reff40_not3954 : ~ @Equation3954 Fin4 reff40_inst.
Proof. unfold Equation3954. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff40_inst, reff40_op in H. discriminate H. Qed.

Lemma reff40_not3955 : ~ @Equation3955 Fin4 reff40_inst.
Proof. unfold Equation3955. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff40_inst, reff40_op in H. discriminate H. Qed.

Lemma reff40_not3961 : ~ @Equation3961 Fin4 reff40_inst.
Proof. unfold Equation3961. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff40_inst, reff40_op in H. discriminate H. Qed.

Lemma reff40_not3962 : ~ @Equation3962 Fin4 reff40_inst.
Proof. unfold Equation3962. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff40_inst, reff40_op in H. discriminate H. Qed.

Lemma reff40_not3964 : ~ @Equation3964 Fin4 reff40_inst.
Proof. unfold Equation3964. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff40_inst, reff40_op in H. discriminate H. Qed.

Lemma reff40_not4080 : ~ @Equation4080 Fin4 reff40_inst.
Proof. unfold Equation4080. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff40_inst, reff40_op in H. discriminate H. Qed.

Lemma reff40_not4081 : ~ @Equation4081 Fin4 reff40_inst.
Proof. unfold Equation4081. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff40_inst, reff40_op in H. discriminate H. Qed.

Lemma reff40_not4083 : ~ @Equation4083 Fin4 reff40_inst.
Proof. unfold Equation4083. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff40_inst, reff40_op in H. discriminate H. Qed.

Lemma reff40_not4084 : ~ @Equation4084 Fin4 reff40_inst.
Proof. unfold Equation4084. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff40_inst, reff40_op in H. discriminate H. Qed.

Lemma reff40_not4090 : ~ @Equation4090 Fin4 reff40_inst.
Proof. unfold Equation4090. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff40_inst, reff40_op in H. discriminate H. Qed.

Lemma reff40_not4091 : ~ @Equation4091 Fin4 reff40_inst.
Proof. unfold Equation4091. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff40_inst, reff40_op in H. discriminate H. Qed.

Lemma reff40_not4093 : ~ @Equation4093 Fin4 reff40_inst.
Proof. unfold Equation4093. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff40_inst, reff40_op in H. discriminate H. Qed.

Lemma reff40_not4154 : ~ @Equation4154 Fin4 reff40_inst.
Proof. unfold Equation4154. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff40_inst, reff40_op in H. discriminate H. Qed.

Lemma reff40_not4155 : ~ @Equation4155 Fin4 reff40_inst.
Proof. unfold Equation4155. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff40_inst, reff40_op in H. discriminate H. Qed.

Lemma reff40_not4157 : ~ @Equation4157 Fin4 reff40_inst.
Proof. unfold Equation4157. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff40_inst, reff40_op in H. discriminate H. Qed.

Lemma reff40_not4158 : ~ @Equation4158 Fin4 reff40_inst.
Proof. unfold Equation4158. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff40_inst, reff40_op in H. discriminate H. Qed.

Lemma reff40_not4164 : ~ @Equation4164 Fin4 reff40_inst.
Proof. unfold Equation4164. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff40_inst, reff40_op in H. discriminate H. Qed.

Lemma reff40_not4165 : ~ @Equation4165 Fin4 reff40_inst.
Proof. unfold Equation4165. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff40_inst, reff40_op in H. discriminate H. Qed.

Lemma reff40_not4167 : ~ @Equation4167 Fin4 reff40_inst.
Proof. unfold Equation4167. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff40_inst, reff40_op in H. discriminate H. Qed.

Lemma reff40_not4272 : ~ @Equation4272 Fin4 reff40_inst.
Proof. unfold Equation4272. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff40_inst, reff40_op in H. discriminate H. Qed.

Lemma reff40_not4273 : ~ @Equation4273 Fin4 reff40_inst.
Proof. unfold Equation4273. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff40_inst, reff40_op in H. discriminate H. Qed.

Lemma reff40_not4275 : ~ @Equation4275 Fin4 reff40_inst.
Proof. unfold Equation4275. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff40_inst, reff40_op in H. discriminate H. Qed.

Lemma reff40_not4276 : ~ @Equation4276 Fin4 reff40_inst.
Proof. unfold Equation4276. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff40_inst, reff40_op in H. discriminate H. Qed.

Lemma reff40_not4290 : ~ @Equation4290 Fin4 reff40_inst.
Proof. unfold Equation4290. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff40_inst, reff40_op in H. discriminate H. Qed.

Lemma reff40_not4291 : ~ @Equation4291 Fin4 reff40_inst.
Proof. unfold Equation4291. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff40_inst, reff40_op in H. discriminate H. Qed.

Lemma reff40_not4293 : ~ @Equation4293 Fin4 reff40_inst.
Proof. unfold Equation4293. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff40_inst, reff40_op in H. discriminate H. Qed.

Lemma reff40_not4320 : ~ @Equation4320 Fin4 reff40_inst.
Proof. unfold Equation4320. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff40_inst, reff40_op in H. discriminate H. Qed.

Lemma reff40_not4321 : ~ @Equation4321 Fin4 reff40_inst.
Proof. unfold Equation4321. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff40_inst, reff40_op in H. discriminate H. Qed.

Lemma reff40_not4343 : ~ @Equation4343 Fin4 reff40_inst.
Proof. unfold Equation4343. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff40_inst, reff40_op in H. discriminate H. Qed.

Lemma reff40_not4405 : ~ @Equation4405 Fin4 reff40_inst.
Proof. unfold Equation4405. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff40_inst, reff40_op in H. discriminate H. Qed.

Lemma reff40_not4406 : ~ @Equation4406 Fin4 reff40_inst.
Proof. unfold Equation4406. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff40_inst, reff40_op in H. discriminate H. Qed.

Lemma reff40_not4408 : ~ @Equation4408 Fin4 reff40_inst.
Proof. unfold Equation4408. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff40_inst, reff40_op in H. discriminate H. Qed.

Lemma reff40_not4442 : ~ @Equation4442 Fin4 reff40_inst.
Proof. unfold Equation4442. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff40_inst, reff40_op in H. discriminate H. Qed.

Lemma reff40_not4443 : ~ @Equation4443 Fin4 reff40_inst.
Proof. unfold Equation4443. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff40_inst, reff40_op in H. discriminate H. Qed.

Lemma reff40_not4445 : ~ @Equation4445 Fin4 reff40_inst.
Proof. unfold Equation4445. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff40_inst, reff40_op in H. discriminate H. Qed.

Lemma reff40_not4479 : ~ @Equation4479 Fin4 reff40_inst.
Proof. unfold Equation4479. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff40_inst, reff40_op in H. discriminate H. Qed.

Lemma reff40_not4480 : ~ @Equation4480 Fin4 reff40_inst.
Proof. unfold Equation4480. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff40_inst, reff40_op in H. discriminate H. Qed.

Lemma reff40_not4482 : ~ @Equation4482 Fin4 reff40_inst.
Proof. unfold Equation4482. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff40_inst, reff40_op in H. discriminate H. Qed.

Lemma reff40_not4587 : ~ @Equation4587 Fin4 reff40_inst.
Proof. unfold Equation4587. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff40_inst, reff40_op in H. discriminate H. Qed.

Lemma reff40_not4588 : ~ @Equation4588 Fin4 reff40_inst.
Proof. unfold Equation4588. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff40_inst, reff40_op in H. discriminate H. Qed.

Lemma reff40_not4590 : ~ @Equation4590 Fin4 reff40_inst.
Proof. unfold Equation4590. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff40_inst, reff40_op in H. discriminate H. Qed.

Lemma reff40_not4591 : ~ @Equation4591 Fin4 reff40_inst.
Proof. unfold Equation4591. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff40_inst, reff40_op in H. discriminate H. Qed.

Lemma reff40_not4605 : ~ @Equation4605 Fin4 reff40_inst.
Proof. unfold Equation4605. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff40_inst, reff40_op in H. discriminate H. Qed.

Lemma reff40_not4606 : ~ @Equation4606 Fin4 reff40_inst.
Proof. unfold Equation4606. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff40_inst, reff40_op in H. discriminate H. Qed.

Lemma reff40_not4608 : ~ @Equation4608 Fin4 reff40_inst.
Proof. unfold Equation4608. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff40_inst, reff40_op in H. discriminate H. Qed.

Lemma reff40_not4635 : ~ @Equation4635 Fin4 reff40_inst.
Proof. unfold Equation4635. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff40_inst, reff40_op in H. discriminate H. Qed.

Lemma reff40_not4636 : ~ @Equation4636 Fin4 reff40_inst.
Proof. unfold Equation4636. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff40_inst, reff40_op in H. discriminate H. Qed.

Lemma reff40_not4658 : ~ @Equation4658 Fin4 reff40_inst.
Proof. unfold Equation4658. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff40_inst, reff40_op in H. discriminate H. Qed.

(** ---- reff400 (Fin4) ---- *)

Definition reff400_op (x y : Fin4) : Fin4 :=
  match x, y with
  | F4_0, F4_0 => F4_0 | F4_0, F4_1 => F4_2 | F4_0, F4_2 => F4_0 | F4_0, F4_3 => F4_2
  | F4_1, F4_0 => F4_2 | F4_1, F4_1 => F4_2 | F4_1, F4_2 => F4_2 | F4_1, F4_3 => F4_2
  | F4_2, F4_0 => F4_0 | F4_2, F4_1 => F4_2 | F4_2, F4_2 => F4_0 | F4_2, F4_3 => F4_2
  | F4_3, F4_0 => F4_2 | F4_3, F4_1 => F4_2 | F4_3, F4_2 => F4_2 | F4_3, F4_3 => F4_2
  end.

#[local] Instance reff400_inst : Magma Fin4 := {| magma_op := reff400_op |}.

Lemma reff400_sat311 : @Equation311 Fin4 reff400_inst.
Proof. unfold Equation311, magma_op, reff400_inst, reff400_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff400_sat370 : @Equation370 Fin4 reff400_inst.
Proof. unfold Equation370, magma_op, reff400_inst, reff400_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff400_sat4577 : @Equation4577 Fin4 reff400_inst.
Proof. unfold Equation4577, magma_op, reff400_inst, reff400_op. intros x y z w u. destruct x, y, z, w, u; reflexivity. Qed.

Lemma reff400_not47 : ~ @Equation47 Fin4 reff400_inst.
Proof. unfold Equation47. intro H. specialize (H F4_1). unfold magma_op, reff400_inst, reff400_op in H. discriminate H. Qed.

Lemma reff400_not99 : ~ @Equation99 Fin4 reff400_inst.
Proof. unfold Equation99. intro H. specialize (H F4_1). unfold magma_op, reff400_inst, reff400_op in H. discriminate H. Qed.

Lemma reff400_not151 : ~ @Equation151 Fin4 reff400_inst.
Proof. unfold Equation151. intro H. specialize (H F4_1). unfold magma_op, reff400_inst, reff400_op in H. discriminate H. Qed.

Lemma reff400_not203 : ~ @Equation203 Fin4 reff400_inst.
Proof. unfold Equation203. intro H. specialize (H F4_1). unfold magma_op, reff400_inst, reff400_op in H. discriminate H. Qed.

Lemma reff400_not255 : ~ @Equation255 Fin4 reff400_inst.
Proof. unfold Equation255. intro H. specialize (H F4_1). unfold magma_op, reff400_inst, reff400_op in H. discriminate H. Qed.

Lemma reff400_not411 : ~ @Equation411 Fin4 reff400_inst.
Proof. unfold Equation411. intro H. specialize (H F4_1). unfold magma_op, reff400_inst, reff400_op in H. discriminate H. Qed.

Lemma reff400_not614 : ~ @Equation614 Fin4 reff400_inst.
Proof. unfold Equation614. intro H. specialize (H F4_1). unfold magma_op, reff400_inst, reff400_op in H. discriminate H. Qed.

Lemma reff400_not817 : ~ @Equation817 Fin4 reff400_inst.
Proof. unfold Equation817. intro H. specialize (H F4_1). unfold magma_op, reff400_inst, reff400_op in H. discriminate H. Qed.

Lemma reff400_not1020 : ~ @Equation1020 Fin4 reff400_inst.
Proof. unfold Equation1020. intro H. specialize (H F4_1). unfold magma_op, reff400_inst, reff400_op in H. discriminate H. Qed.

Lemma reff400_not1223 : ~ @Equation1223 Fin4 reff400_inst.
Proof. unfold Equation1223. intro H. specialize (H F4_1). unfold magma_op, reff400_inst, reff400_op in H. discriminate H. Qed.

Lemma reff400_not1426 : ~ @Equation1426 Fin4 reff400_inst.
Proof. unfold Equation1426. intro H. specialize (H F4_1). unfold magma_op, reff400_inst, reff400_op in H. discriminate H. Qed.

Lemma reff400_not1629 : ~ @Equation1629 Fin4 reff400_inst.
Proof. unfold Equation1629. intro H. specialize (H F4_1). unfold magma_op, reff400_inst, reff400_op in H. discriminate H. Qed.

Lemma reff400_not1832 : ~ @Equation1832 Fin4 reff400_inst.
Proof. unfold Equation1832. intro H. specialize (H F4_1). unfold magma_op, reff400_inst, reff400_op in H. discriminate H. Qed.

Lemma reff400_not2035 : ~ @Equation2035 Fin4 reff400_inst.
Proof. unfold Equation2035. intro H. specialize (H F4_1). unfold magma_op, reff400_inst, reff400_op in H. discriminate H. Qed.

Lemma reff400_not2238 : ~ @Equation2238 Fin4 reff400_inst.
Proof. unfold Equation2238. intro H. specialize (H F4_1). unfold magma_op, reff400_inst, reff400_op in H. discriminate H. Qed.

Lemma reff400_not2441 : ~ @Equation2441 Fin4 reff400_inst.
Proof. unfold Equation2441. intro H. specialize (H F4_1). unfold magma_op, reff400_inst, reff400_op in H. discriminate H. Qed.

Lemma reff400_not2644 : ~ @Equation2644 Fin4 reff400_inst.
Proof. unfold Equation2644. intro H. specialize (H F4_1). unfold magma_op, reff400_inst, reff400_op in H. discriminate H. Qed.

Lemma reff400_not2847 : ~ @Equation2847 Fin4 reff400_inst.
Proof. unfold Equation2847. intro H. specialize (H F4_1). unfold magma_op, reff400_inst, reff400_op in H. discriminate H. Qed.

Lemma reff400_not3050 : ~ @Equation3050 Fin4 reff400_inst.
Proof. unfold Equation3050. intro H. specialize (H F4_1). unfold magma_op, reff400_inst, reff400_op in H. discriminate H. Qed.

Lemma reff400_not3268 : ~ @Equation3268 Fin4 reff400_inst.
Proof. unfold Equation3268. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff400_inst, reff400_op in H. discriminate H. Qed.

Lemma reff400_not3271 : ~ @Equation3271 Fin4 reff400_inst.
Proof. unfold Equation3271. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff400_inst, reff400_op in H. discriminate H. Qed.

Lemma reff400_not3272 : ~ @Equation3272 Fin4 reff400_inst.
Proof. unfold Equation3272. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff400_inst, reff400_op in H. discriminate H. Qed.

Lemma reff400_not3278 : ~ @Equation3278 Fin4 reff400_inst.
Proof. unfold Equation3278. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff400_inst, reff400_op in H. discriminate H. Qed.

Lemma reff400_not3279 : ~ @Equation3279 Fin4 reff400_inst.
Proof. unfold Equation3279. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff400_inst, reff400_op in H. discriminate H. Qed.

Lemma reff400_not3281 : ~ @Equation3281 Fin4 reff400_inst.
Proof. unfold Equation3281. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff400_inst, reff400_op in H. discriminate H. Qed.

Lemma reff400_not3306 : ~ @Equation3306 Fin4 reff400_inst.
Proof. unfold Equation3306. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff400_inst, reff400_op in H. discriminate H. Qed.

Lemma reff400_not3308 : ~ @Equation3308 Fin4 reff400_inst.
Proof. unfold Equation3308. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff400_inst, reff400_op in H. discriminate H. Qed.

Lemma reff400_not3309 : ~ @Equation3309 Fin4 reff400_inst.
Proof. unfold Equation3309. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff400_inst, reff400_op in H. discriminate H. Qed.

Lemma reff400_not3315 : ~ @Equation3315 Fin4 reff400_inst.
Proof. unfold Equation3315. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff400_inst, reff400_op in H. discriminate H. Qed.

Lemma reff400_not3316 : ~ @Equation3316 Fin4 reff400_inst.
Proof. unfold Equation3316. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff400_inst, reff400_op in H. discriminate H. Qed.

Lemma reff400_not3318 : ~ @Equation3318 Fin4 reff400_inst.
Proof. unfold Equation3318. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff400_inst, reff400_op in H. discriminate H. Qed.

Lemma reff400_not3319 : ~ @Equation3319 Fin4 reff400_inst.
Proof. unfold Equation3319. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff400_inst, reff400_op in H. discriminate H. Qed.

Lemma reff400_not3342 : ~ @Equation3342 Fin4 reff400_inst.
Proof. unfold Equation3342. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff400_inst, reff400_op in H. discriminate H. Qed.

Lemma reff400_not3343 : ~ @Equation3343 Fin4 reff400_inst.
Proof. unfold Equation3343. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff400_inst, reff400_op in H. discriminate H. Qed.

Lemma reff400_not3345 : ~ @Equation3345 Fin4 reff400_inst.
Proof. unfold Equation3345. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff400_inst, reff400_op in H. discriminate H. Qed.

Lemma reff400_not3346 : ~ @Equation3346 Fin4 reff400_inst.
Proof. unfold Equation3346. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff400_inst, reff400_op in H. discriminate H. Qed.

Lemma reff400_not3352 : ~ @Equation3352 Fin4 reff400_inst.
Proof. unfold Equation3352. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff400_inst, reff400_op in H. discriminate H. Qed.

Lemma reff400_not3353 : ~ @Equation3353 Fin4 reff400_inst.
Proof. unfold Equation3353. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff400_inst, reff400_op in H. discriminate H. Qed.

Lemma reff400_not3355 : ~ @Equation3355 Fin4 reff400_inst.
Proof. unfold Equation3355. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff400_inst, reff400_op in H. discriminate H. Qed.

Lemma reff400_not3472 : ~ @Equation3472 Fin4 reff400_inst.
Proof. unfold Equation3472. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff400_inst, reff400_op in H. discriminate H. Qed.

Lemma reff400_not3474 : ~ @Equation3474 Fin4 reff400_inst.
Proof. unfold Equation3474. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff400_inst, reff400_op in H. discriminate H. Qed.

Lemma reff400_not3475 : ~ @Equation3475 Fin4 reff400_inst.
Proof. unfold Equation3475. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff400_inst, reff400_op in H. discriminate H. Qed.

Lemma reff400_not3481 : ~ @Equation3481 Fin4 reff400_inst.
Proof. unfold Equation3481. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff400_inst, reff400_op in H. discriminate H. Qed.

Lemma reff400_not3482 : ~ @Equation3482 Fin4 reff400_inst.
Proof. unfold Equation3482. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff400_inst, reff400_op in H. discriminate H. Qed.

Lemma reff400_not3484 : ~ @Equation3484 Fin4 reff400_inst.
Proof. unfold Equation3484. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff400_inst, reff400_op in H. discriminate H. Qed.

Lemma reff400_not3509 : ~ @Equation3509 Fin4 reff400_inst.
Proof. unfold Equation3509. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff400_inst, reff400_op in H. discriminate H. Qed.

Lemma reff400_not3511 : ~ @Equation3511 Fin4 reff400_inst.
Proof. unfold Equation3511. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff400_inst, reff400_op in H. discriminate H. Qed.

Lemma reff400_not3512 : ~ @Equation3512 Fin4 reff400_inst.
Proof. unfold Equation3512. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff400_inst, reff400_op in H. discriminate H. Qed.

Lemma reff400_not3518 : ~ @Equation3518 Fin4 reff400_inst.
Proof. unfold Equation3518. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff400_inst, reff400_op in H. discriminate H. Qed.

Lemma reff400_not3519 : ~ @Equation3519 Fin4 reff400_inst.
Proof. unfold Equation3519. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff400_inst, reff400_op in H. discriminate H. Qed.

Lemma reff400_not3521 : ~ @Equation3521 Fin4 reff400_inst.
Proof. unfold Equation3521. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff400_inst, reff400_op in H. discriminate H. Qed.

Lemma reff400_not3522 : ~ @Equation3522 Fin4 reff400_inst.
Proof. unfold Equation3522. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff400_inst, reff400_op in H. discriminate H. Qed.

Lemma reff400_not3545 : ~ @Equation3545 Fin4 reff400_inst.
Proof. unfold Equation3545. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff400_inst, reff400_op in H. discriminate H. Qed.

Lemma reff400_not3546 : ~ @Equation3546 Fin4 reff400_inst.
Proof. unfold Equation3546. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff400_inst, reff400_op in H. discriminate H. Qed.

Lemma reff400_not3548 : ~ @Equation3548 Fin4 reff400_inst.
Proof. unfold Equation3548. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff400_inst, reff400_op in H. discriminate H. Qed.

Lemma reff400_not3549 : ~ @Equation3549 Fin4 reff400_inst.
Proof. unfold Equation3549. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff400_inst, reff400_op in H. discriminate H. Qed.

Lemma reff400_not3555 : ~ @Equation3555 Fin4 reff400_inst.
Proof. unfold Equation3555. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff400_inst, reff400_op in H. discriminate H. Qed.

Lemma reff400_not3556 : ~ @Equation3556 Fin4 reff400_inst.
Proof. unfold Equation3556. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff400_inst, reff400_op in H. discriminate H. Qed.

Lemma reff400_not3558 : ~ @Equation3558 Fin4 reff400_inst.
Proof. unfold Equation3558. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff400_inst, reff400_op in H. discriminate H. Qed.

Lemma reff400_not3659 : ~ @Equation3659 Fin4 reff400_inst.
Proof. unfold Equation3659. intro H. specialize (H F4_1). unfold magma_op, reff400_inst, reff400_op in H. discriminate H. Qed.

Lemma reff400_not3865 : ~ @Equation3865 Fin4 reff400_inst.
Proof. unfold Equation3865. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff400_inst, reff400_op in H. discriminate H. Qed.

Lemma reff400_not3868 : ~ @Equation3868 Fin4 reff400_inst.
Proof. unfold Equation3868. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff400_inst, reff400_op in H. discriminate H. Qed.

Lemma reff400_not3871 : ~ @Equation3871 Fin4 reff400_inst.
Proof. unfold Equation3871. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff400_inst, reff400_op in H. discriminate H. Qed.

Lemma reff400_not3878 : ~ @Equation3878 Fin4 reff400_inst.
Proof. unfold Equation3878. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff400_inst, reff400_op in H. discriminate H. Qed.

Lemma reff400_not3881 : ~ @Equation3881 Fin4 reff400_inst.
Proof. unfold Equation3881. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff400_inst, reff400_op in H. discriminate H. Qed.

Lemma reff400_not3888 : ~ @Equation3888 Fin4 reff400_inst.
Proof. unfold Equation3888. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff400_inst, reff400_op in H. discriminate H. Qed.

Lemma reff400_not3915 : ~ @Equation3915 Fin4 reff400_inst.
Proof. unfold Equation3915. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff400_inst, reff400_op in H. discriminate H. Qed.

Lemma reff400_not3917 : ~ @Equation3917 Fin4 reff400_inst.
Proof. unfold Equation3917. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff400_inst, reff400_op in H. discriminate H. Qed.

Lemma reff400_not3918 : ~ @Equation3918 Fin4 reff400_inst.
Proof. unfold Equation3918. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff400_inst, reff400_op in H. discriminate H. Qed.

Lemma reff400_not3924 : ~ @Equation3924 Fin4 reff400_inst.
Proof. unfold Equation3924. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff400_inst, reff400_op in H. discriminate H. Qed.

Lemma reff400_not3925 : ~ @Equation3925 Fin4 reff400_inst.
Proof. unfold Equation3925. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff400_inst, reff400_op in H. discriminate H. Qed.

Lemma reff400_not3927 : ~ @Equation3927 Fin4 reff400_inst.
Proof. unfold Equation3927. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff400_inst, reff400_op in H. discriminate H. Qed.

Lemma reff400_not3928 : ~ @Equation3928 Fin4 reff400_inst.
Proof. unfold Equation3928. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff400_inst, reff400_op in H. discriminate H. Qed.

Lemma reff400_not3951 : ~ @Equation3951 Fin4 reff400_inst.
Proof. unfold Equation3951. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff400_inst, reff400_op in H. discriminate H. Qed.

Lemma reff400_not3952 : ~ @Equation3952 Fin4 reff400_inst.
Proof. unfold Equation3952. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff400_inst, reff400_op in H. discriminate H. Qed.

Lemma reff400_not3954 : ~ @Equation3954 Fin4 reff400_inst.
Proof. unfold Equation3954. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff400_inst, reff400_op in H. discriminate H. Qed.

Lemma reff400_not3955 : ~ @Equation3955 Fin4 reff400_inst.
Proof. unfold Equation3955. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff400_inst, reff400_op in H. discriminate H. Qed.

Lemma reff400_not3961 : ~ @Equation3961 Fin4 reff400_inst.
Proof. unfold Equation3961. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff400_inst, reff400_op in H. discriminate H. Qed.

Lemma reff400_not3962 : ~ @Equation3962 Fin4 reff400_inst.
Proof. unfold Equation3962. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff400_inst, reff400_op in H. discriminate H. Qed.

Lemma reff400_not3964 : ~ @Equation3964 Fin4 reff400_inst.
Proof. unfold Equation3964. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff400_inst, reff400_op in H. discriminate H. Qed.

Lemma reff400_not4066 : ~ @Equation4066 Fin4 reff400_inst.
Proof. unfold Equation4066. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff400_inst, reff400_op in H. discriminate H. Qed.

Lemma reff400_not4068 : ~ @Equation4068 Fin4 reff400_inst.
Proof. unfold Equation4068. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff400_inst, reff400_op in H. discriminate H. Qed.

Lemma reff400_not4071 : ~ @Equation4071 Fin4 reff400_inst.
Proof. unfold Equation4071. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff400_inst, reff400_op in H. discriminate H. Qed.

Lemma reff400_not4074 : ~ @Equation4074 Fin4 reff400_inst.
Proof. unfold Equation4074. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff400_inst, reff400_op in H. discriminate H. Qed.

Lemma reff400_not4084 : ~ @Equation4084 Fin4 reff400_inst.
Proof. unfold Equation4084. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff400_inst, reff400_op in H. discriminate H. Qed.

Lemma reff400_not4091 : ~ @Equation4091 Fin4 reff400_inst.
Proof. unfold Equation4091. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff400_inst, reff400_op in H. discriminate H. Qed.

Lemma reff400_not4118 : ~ @Equation4118 Fin4 reff400_inst.
Proof. unfold Equation4118. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff400_inst, reff400_op in H. discriminate H. Qed.

Lemma reff400_not4120 : ~ @Equation4120 Fin4 reff400_inst.
Proof. unfold Equation4120. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff400_inst, reff400_op in H. discriminate H. Qed.

Lemma reff400_not4121 : ~ @Equation4121 Fin4 reff400_inst.
Proof. unfold Equation4121. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff400_inst, reff400_op in H. discriminate H. Qed.

Lemma reff400_not4127 : ~ @Equation4127 Fin4 reff400_inst.
Proof. unfold Equation4127. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff400_inst, reff400_op in H. discriminate H. Qed.

Lemma reff400_not4128 : ~ @Equation4128 Fin4 reff400_inst.
Proof. unfold Equation4128. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff400_inst, reff400_op in H. discriminate H. Qed.

Lemma reff400_not4130 : ~ @Equation4130 Fin4 reff400_inst.
Proof. unfold Equation4130. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff400_inst, reff400_op in H. discriminate H. Qed.

Lemma reff400_not4131 : ~ @Equation4131 Fin4 reff400_inst.
Proof. unfold Equation4131. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff400_inst, reff400_op in H. discriminate H. Qed.

Lemma reff400_not4154 : ~ @Equation4154 Fin4 reff400_inst.
Proof. unfold Equation4154. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff400_inst, reff400_op in H. discriminate H. Qed.

Lemma reff400_not4155 : ~ @Equation4155 Fin4 reff400_inst.
Proof. unfold Equation4155. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff400_inst, reff400_op in H. discriminate H. Qed.

Lemma reff400_not4157 : ~ @Equation4157 Fin4 reff400_inst.
Proof. unfold Equation4157. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff400_inst, reff400_op in H. discriminate H. Qed.

Lemma reff400_not4158 : ~ @Equation4158 Fin4 reff400_inst.
Proof. unfold Equation4158. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff400_inst, reff400_op in H. discriminate H. Qed.

Lemma reff400_not4164 : ~ @Equation4164 Fin4 reff400_inst.
Proof. unfold Equation4164. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff400_inst, reff400_op in H. discriminate H. Qed.

Lemma reff400_not4165 : ~ @Equation4165 Fin4 reff400_inst.
Proof. unfold Equation4165. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff400_inst, reff400_op in H. discriminate H. Qed.

Lemma reff400_not4167 : ~ @Equation4167 Fin4 reff400_inst.
Proof. unfold Equation4167. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff400_inst, reff400_op in H. discriminate H. Qed.

Lemma reff400_not4272 : ~ @Equation4272 Fin4 reff400_inst.
Proof. unfold Equation4272. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff400_inst, reff400_op in H. discriminate H. Qed.

Lemma reff400_not4273 : ~ @Equation4273 Fin4 reff400_inst.
Proof. unfold Equation4273. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff400_inst, reff400_op in H. discriminate H. Qed.

Lemma reff400_not4275 : ~ @Equation4275 Fin4 reff400_inst.
Proof. unfold Equation4275. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff400_inst, reff400_op in H. discriminate H. Qed.

Lemma reff400_not4276 : ~ @Equation4276 Fin4 reff400_inst.
Proof. unfold Equation4276. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff400_inst, reff400_op in H. discriminate H. Qed.

Lemma reff400_not4290 : ~ @Equation4290 Fin4 reff400_inst.
Proof. unfold Equation4290. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff400_inst, reff400_op in H. discriminate H. Qed.

Lemma reff400_not4291 : ~ @Equation4291 Fin4 reff400_inst.
Proof. unfold Equation4291. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff400_inst, reff400_op in H. discriminate H. Qed.

Lemma reff400_not4293 : ~ @Equation4293 Fin4 reff400_inst.
Proof. unfold Equation4293. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff400_inst, reff400_op in H. discriminate H. Qed.

Lemma reff400_not4320 : ~ @Equation4320 Fin4 reff400_inst.
Proof. unfold Equation4320. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff400_inst, reff400_op in H. discriminate H. Qed.

Lemma reff400_not4321 : ~ @Equation4321 Fin4 reff400_inst.
Proof. unfold Equation4321. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff400_inst, reff400_op in H. discriminate H. Qed.

Lemma reff400_not4343 : ~ @Equation4343 Fin4 reff400_inst.
Proof. unfold Equation4343. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff400_inst, reff400_op in H. discriminate H. Qed.

Lemma reff400_not4396 : ~ @Equation4396 Fin4 reff400_inst.
Proof. unfold Equation4396. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff400_inst, reff400_op in H. discriminate H. Qed.

Lemma reff400_not4399 : ~ @Equation4399 Fin4 reff400_inst.
Proof. unfold Equation4399. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff400_inst, reff400_op in H. discriminate H. Qed.

Lemma reff400_not4406 : ~ @Equation4406 Fin4 reff400_inst.
Proof. unfold Equation4406. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff400_inst, reff400_op in H. discriminate H. Qed.

Lemma reff400_not4433 : ~ @Equation4433 Fin4 reff400_inst.
Proof. unfold Equation4433. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff400_inst, reff400_op in H. discriminate H. Qed.

Lemma reff400_not4436 : ~ @Equation4436 Fin4 reff400_inst.
Proof. unfold Equation4436. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff400_inst, reff400_op in H. discriminate H. Qed.

Lemma reff400_not4443 : ~ @Equation4443 Fin4 reff400_inst.
Proof. unfold Equation4443. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff400_inst, reff400_op in H. discriminate H. Qed.

Lemma reff400_not4470 : ~ @Equation4470 Fin4 reff400_inst.
Proof. unfold Equation4470. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff400_inst, reff400_op in H. discriminate H. Qed.

Lemma reff400_not4473 : ~ @Equation4473 Fin4 reff400_inst.
Proof. unfold Equation4473. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff400_inst, reff400_op in H. discriminate H. Qed.

Lemma reff400_not4480 : ~ @Equation4480 Fin4 reff400_inst.
Proof. unfold Equation4480. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff400_inst, reff400_op in H. discriminate H. Qed.

Lemma reff400_not4583 : ~ @Equation4583 Fin4 reff400_inst.
Proof. unfold Equation4583. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff400_inst, reff400_op in H. discriminate H. Qed.

Lemma reff400_not4585 : ~ @Equation4585 Fin4 reff400_inst.
Proof. unfold Equation4585. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff400_inst, reff400_op in H. discriminate H. Qed.

Lemma reff400_not4588 : ~ @Equation4588 Fin4 reff400_inst.
Proof. unfold Equation4588. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff400_inst, reff400_op in H. discriminate H. Qed.

Lemma reff400_not4591 : ~ @Equation4591 Fin4 reff400_inst.
Proof. unfold Equation4591. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff400_inst, reff400_op in H. discriminate H. Qed.

Lemma reff400_not4598 : ~ @Equation4598 Fin4 reff400_inst.
Proof. unfold Equation4598. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff400_inst, reff400_op in H. discriminate H. Qed.

Lemma reff400_not4605 : ~ @Equation4605 Fin4 reff400_inst.
Proof. unfold Equation4605. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff400_inst, reff400_op in H. discriminate H. Qed.

Lemma reff400_not4608 : ~ @Equation4608 Fin4 reff400_inst.
Proof. unfold Equation4608. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff400_inst, reff400_op in H. discriminate H. Qed.

Lemma reff400_not4629 : ~ @Equation4629 Fin4 reff400_inst.
Proof. unfold Equation4629. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff400_inst, reff400_op in H. discriminate H. Qed.

Lemma reff400_not4636 : ~ @Equation4636 Fin4 reff400_inst.
Proof. unfold Equation4636. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff400_inst, reff400_op in H. discriminate H. Qed.

Lemma reff400_not4658 : ~ @Equation4658 Fin4 reff400_inst.
Proof. unfold Equation4658. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff400_inst, reff400_op in H. discriminate H. Qed.
