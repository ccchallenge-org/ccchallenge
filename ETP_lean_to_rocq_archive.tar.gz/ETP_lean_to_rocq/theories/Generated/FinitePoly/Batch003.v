(** * FinitePoly counterexamples — batch 3
    Auto-generated from Lean4 FinitePoly files. *)

From Stdlib Require Import Utf8.

From ETP Require Import Magma.
From ETP Require Import FinMagma.
From ETP.Equations Require Import All.

Open Scope magma_scope.

(** ---- reff184 (Fin4) ---- *)

Definition reff184_op (x y : Fin4) : Fin4 :=
  match x, y with
  | F4_0, F4_0 => F4_0 | F4_0, F4_1 => F4_3 | F4_0, F4_2 => F4_2 | F4_0, F4_3 => F4_1
  | F4_1, F4_0 => F4_3 | F4_1, F4_1 => F4_2 | F4_1, F4_2 => F4_1 | F4_1, F4_3 => F4_0
  | F4_2, F4_0 => F4_2 | F4_2, F4_1 => F4_1 | F4_2, F4_2 => F4_0 | F4_2, F4_3 => F4_3
  | F4_3, F4_0 => F4_1 | F4_3, F4_1 => F4_0 | F4_3, F4_2 => F4_3 | F4_3, F4_3 => F4_2
  end.

#[local] Instance reff184_inst : Magma Fin4 := {| magma_op := reff184_op |}.

Lemma reff184_sat14 : @Equation14 Fin4 reff184_inst.
Proof. unfold Equation14, magma_op, reff184_inst, reff184_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff184_sat16 : @Equation16 Fin4 reff184_inst.
Proof. unfold Equation16, magma_op, reff184_inst, reff184_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff184_sat26 : @Equation26 Fin4 reff184_inst.
Proof. unfold Equation26, magma_op, reff184_inst, reff184_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff184_sat43 : @Equation43 Fin4 reff184_inst.
Proof. unfold Equation43, magma_op, reff184_inst, reff184_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff184_sat492 : @Equation492 Fin4 reff184_inst.
Proof. unfold Equation492, magma_op, reff184_inst, reff184_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff184_sat522 : @Equation522 Fin4 reff184_inst.
Proof. unfold Equation522, magma_op, reff184_inst, reff184_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff184_sat572 : @Equation572 Fin4 reff184_inst.
Proof. unfold Equation572, magma_op, reff184_inst, reff184_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff184_sat684 : @Equation684 Fin4 reff184_inst.
Proof. unfold Equation684, magma_op, reff184_inst, reff184_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff184_sat692 : @Equation692 Fin4 reff184_inst.
Proof. unfold Equation692, magma_op, reff184_inst, reff184_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff184_sat711 : @Equation711 Fin4 reff184_inst.
Proof. unfold Equation711, magma_op, reff184_inst, reff184_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff184_sat725 : @Equation725 Fin4 reff184_inst.
Proof. unfold Equation725, magma_op, reff184_inst, reff184_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff184_sat759 : @Equation759 Fin4 reff184_inst.
Proof. unfold Equation759, magma_op, reff184_inst, reff184_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff184_sat1152 : @Equation1152 Fin4 reff184_inst.
Proof. unfold Equation1152, magma_op, reff184_inst, reff184_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff184_sat1165 : @Equation1165 Fin4 reff184_inst.
Proof. unfold Equation1165, magma_op, reff184_inst, reff184_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff184_sat1171 : @Equation1171 Fin4 reff184_inst.
Proof. unfold Equation1171, magma_op, reff184_inst, reff184_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff184_sat1181 : @Equation1181 Fin4 reff184_inst.
Proof. unfold Equation1181, magma_op, reff184_inst, reff184_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff184_sat1293 : @Equation1293 Fin4 reff184_inst.
Proof. unfold Equation1293, magma_op, reff184_inst, reff184_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff184_sat1304 : @Equation1304 Fin4 reff184_inst.
Proof. unfold Equation1304, magma_op, reff184_inst, reff184_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff184_sat1320 : @Equation1320 Fin4 reff184_inst.
Proof. unfold Equation1320, magma_op, reff184_inst, reff184_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff184_sat1340 : @Equation1340 Fin4 reff184_inst.
Proof. unfold Equation1340, magma_op, reff184_inst, reff184_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff184_sat1358 : @Equation1358 Fin4 reff184_inst.
Proof. unfold Equation1358, magma_op, reff184_inst, reff184_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff184_sat1374 : @Equation1374 Fin4 reff184_inst.
Proof. unfold Equation1374, magma_op, reff184_inst, reff184_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff184_sat1467 : @Equation1467 Fin4 reff184_inst.
Proof. unfold Equation1467, magma_op, reff184_inst, reff184_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff184_sat1470 : @Equation1470 Fin4 reff184_inst.
Proof. unfold Equation1470, magma_op, reff184_inst, reff184_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff184_sat1504 : @Equation1504 Fin4 reff184_inst.
Proof. unfold Equation1504, magma_op, reff184_inst, reff184_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff184_sat1507 : @Equation1507 Fin4 reff184_inst.
Proof. unfold Equation1507, magma_op, reff184_inst, reff184_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff184_sat1561 : @Equation1561 Fin4 reff184_inst.
Proof. unfold Equation1561, magma_op, reff184_inst, reff184_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff184_sat1670 : @Equation1670 Fin4 reff184_inst.
Proof. unfold Equation1670, magma_op, reff184_inst, reff184_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff184_sat1699 : @Equation1699 Fin4 reff184_inst.
Proof. unfold Equation1699, magma_op, reff184_inst, reff184_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff184_sat1793 : @Equation1793 Fin4 reff184_inst.
Proof. unfold Equation1793, magma_op, reff184_inst, reff184_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff184_sat1876 : @Equation1876 Fin4 reff184_inst.
Proof. unfold Equation1876, magma_op, reff184_inst, reff184_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff184_sat1943 : @Equation1943 Fin4 reff184_inst.
Proof. unfold Equation1943, magma_op, reff184_inst, reff184_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff184_sat1983 : @Equation1983 Fin4 reff184_inst.
Proof. unfold Equation1983, magma_op, reff184_inst, reff184_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff184_sat2170 : @Equation2170 Fin4 reff184_inst.
Proof. unfold Equation2170, magma_op, reff184_inst, reff184_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff184_sat2180 : @Equation2180 Fin4 reff184_inst.
Proof. unfold Equation2180, magma_op, reff184_inst, reff184_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff184_sat2186 : @Equation2186 Fin4 reff184_inst.
Proof. unfold Equation2186, magma_op, reff184_inst, reff184_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff184_sat2196 : @Equation2196 Fin4 reff184_inst.
Proof. unfold Equation2196, magma_op, reff184_inst, reff184_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff184_sat2199 : @Equation2199 Fin4 reff184_inst.
Proof. unfold Equation2199, magma_op, reff184_inst, reff184_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff184_sat2271 : @Equation2271 Fin4 reff184_inst.
Proof. unfold Equation2271, magma_op, reff184_inst, reff184_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff184_sat2279 : @Equation2279 Fin4 reff184_inst.
Proof. unfold Equation2279, magma_op, reff184_inst, reff184_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff184_sat2335 : @Equation2335 Fin4 reff184_inst.
Proof. unfold Equation2335, magma_op, reff184_inst, reff184_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff184_sat2349 : @Equation2349 Fin4 reff184_inst.
Proof. unfold Equation2349, magma_op, reff184_inst, reff184_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff184_sat2373 : @Equation2373 Fin4 reff184_inst.
Proof. unfold Equation2373, magma_op, reff184_inst, reff184_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff184_sat2399 : @Equation2399 Fin4 reff184_inst.
Proof. unfold Equation2399, magma_op, reff184_inst, reff184_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff184_sat2482 : @Equation2482 Fin4 reff184_inst.
Proof. unfold Equation2482, magma_op, reff184_inst, reff184_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff184_sat2519 : @Equation2519 Fin4 reff184_inst.
Proof. unfold Equation2519, magma_op, reff184_inst, reff184_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff184_sat2522 : @Equation2522 Fin4 reff184_inst.
Proof. unfold Equation2522, magma_op, reff184_inst, reff184_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff184_sat2573 : @Equation2573 Fin4 reff184_inst.
Proof. unfold Equation2573, magma_op, reff184_inst, reff184_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff184_sat2917 : @Equation2917 Fin4 reff184_inst.
Proof. unfold Equation2917, magma_op, reff184_inst, reff184_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff184_sat2925 : @Equation2925 Fin4 reff184_inst.
Proof. unfold Equation2925, magma_op, reff184_inst, reff184_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff184_sat2944 : @Equation2944 Fin4 reff184_inst.
Proof. unfold Equation2944, magma_op, reff184_inst, reff184_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff184_sat2958 : @Equation2958 Fin4 reff184_inst.
Proof. unfold Equation2958, magma_op, reff184_inst, reff184_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff184_sat2992 : @Equation2992 Fin4 reff184_inst.
Proof. unfold Equation2992, magma_op, reff184_inst, reff184_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff184_sat3120 : @Equation3120 Fin4 reff184_inst.
Proof. unfold Equation3120, magma_op, reff184_inst, reff184_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff184_sat3131 : @Equation3131 Fin4 reff184_inst.
Proof. unfold Equation3131, magma_op, reff184_inst, reff184_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff184_sat3211 : @Equation3211 Fin4 reff184_inst.
Proof. unfold Equation3211, magma_op, reff184_inst, reff184_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff184_sat3364 : @Equation3364 Fin4 reff184_inst.
Proof. unfold Equation3364, magma_op, reff184_inst, reff184_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff184_sat3417 : @Equation3417 Fin4 reff184_inst.
Proof. unfold Equation3417, magma_op, reff184_inst, reff184_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff184_sat3601 : @Equation3601 Fin4 reff184_inst.
Proof. unfold Equation3601, magma_op, reff184_inst, reff184_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff184_sat4007 : @Equation4007 Fin4 reff184_inst.
Proof. unfold Equation4007, magma_op, reff184_inst, reff184_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff184_sat4216 : @Equation4216 Fin4 reff184_inst.
Proof. unfold Equation4216, magma_op, reff184_inst, reff184_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff184_sat4305 : @Equation4305 Fin4 reff184_inst.
Proof. unfold Equation4305, magma_op, reff184_inst, reff184_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff184_sat4413 : @Equation4413 Fin4 reff184_inst.
Proof. unfold Equation4413, magma_op, reff184_inst, reff184_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff184_sat4421 : @Equation4421 Fin4 reff184_inst.
Proof. unfold Equation4421, magma_op, reff184_inst, reff184_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff184_sat4450 : @Equation4450 Fin4 reff184_inst.
Proof. unfold Equation4450, magma_op, reff184_inst, reff184_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff184_sat4640 : @Equation4640 Fin4 reff184_inst.
Proof. unfold Equation4640, magma_op, reff184_inst, reff184_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff184_not412 : ~ @Equation412 Fin4 reff184_inst.
Proof. unfold Equation412. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff184_inst, reff184_op in H. discriminate H. Qed.

Lemma reff184_not413 : ~ @Equation413 Fin4 reff184_inst.
Proof. unfold Equation413. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff184_inst, reff184_op in H. discriminate H. Qed.

Lemma reff184_not414 : ~ @Equation414 Fin4 reff184_inst.
Proof. unfold Equation414. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff184_inst, reff184_op in H. discriminate H. Qed.

Lemma reff184_not416 : ~ @Equation416 Fin4 reff184_inst.
Proof. unfold Equation416. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff184_inst, reff184_op in H. discriminate H. Qed.

Lemma reff184_not420 : ~ @Equation420 Fin4 reff184_inst.
Proof. unfold Equation420. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff184_inst, reff184_op in H. discriminate H. Qed.

Lemma reff184_not426 : ~ @Equation426 Fin4 reff184_inst.
Proof. unfold Equation426. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff184_inst, reff184_op in H. discriminate H. Qed.

Lemma reff184_not427 : ~ @Equation427 Fin4 reff184_inst.
Proof. unfold Equation427. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff184_inst, reff184_op in H. discriminate H. Qed.

Lemma reff184_not429 : ~ @Equation429 Fin4 reff184_inst.
Proof. unfold Equation429. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff184_inst, reff184_op in H. discriminate H. Qed.

Lemma reff184_not430 : ~ @Equation430 Fin4 reff184_inst.
Proof. unfold Equation430. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff184_inst, reff184_op in H. discriminate H. Qed.

Lemma reff184_not437 : ~ @Equation437 Fin4 reff184_inst.
Proof. unfold Equation437. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff184_inst, reff184_op in H. discriminate H. Qed.

Lemma reff184_not439 : ~ @Equation439 Fin4 reff184_inst.
Proof. unfold Equation439. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff184_inst, reff184_op in H. discriminate H. Qed.

Lemma reff184_not440 : ~ @Equation440 Fin4 reff184_inst.
Proof. unfold Equation440. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff184_inst, reff184_op in H. discriminate H. Qed.

Lemma reff184_not463 : ~ @Equation463 Fin4 reff184_inst.
Proof. unfold Equation463. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff184_inst, reff184_op in H. discriminate H. Qed.

Lemma reff184_not467 : ~ @Equation467 Fin4 reff184_inst.
Proof. unfold Equation467. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff184_inst, reff184_op in H. discriminate H. Qed.

Lemma reff184_not473 : ~ @Equation473 Fin4 reff184_inst.
Proof. unfold Equation473. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff184_inst, reff184_op in H. discriminate H. Qed.

Lemma reff184_not474 : ~ @Equation474 Fin4 reff184_inst.
Proof. unfold Equation474. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff184_inst, reff184_op in H. discriminate H. Qed.

Lemma reff184_not476 : ~ @Equation476 Fin4 reff184_inst.
Proof. unfold Equation476. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff184_inst, reff184_op in H. discriminate H. Qed.

Lemma reff184_not501 : ~ @Equation501 Fin4 reff184_inst.
Proof. unfold Equation501. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff184_inst, reff184_op in H. discriminate H. Qed.

Lemma reff184_not503 : ~ @Equation503 Fin4 reff184_inst.
Proof. unfold Equation503. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff184_inst, reff184_op in H. discriminate H. Qed.

Lemma reff184_not504 : ~ @Equation504 Fin4 reff184_inst.
Proof. unfold Equation504. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff184_inst, reff184_op in H. discriminate H. Qed.

Lemma reff184_not510 : ~ @Equation510 Fin4 reff184_inst.
Proof. unfold Equation510. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff184_inst, reff184_op in H. discriminate H. Qed.

Lemma reff184_not615 : ~ @Equation615 Fin4 reff184_inst.
Proof. unfold Equation615. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff184_inst, reff184_op in H. discriminate H. Qed.

Lemma reff184_not616 : ~ @Equation616 Fin4 reff184_inst.
Proof. unfold Equation616. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff184_inst, reff184_op in H. discriminate H. Qed.

Lemma reff184_not619 : ~ @Equation619 Fin4 reff184_inst.
Proof. unfold Equation619. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff184_inst, reff184_op in H. discriminate H. Qed.

Lemma reff184_not622 : ~ @Equation622 Fin4 reff184_inst.
Proof. unfold Equation622. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff184_inst, reff184_op in H. discriminate H. Qed.

Lemma reff184_not623 : ~ @Equation623 Fin4 reff184_inst.
Proof. unfold Equation623. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff184_inst, reff184_op in H. discriminate H. Qed.

Lemma reff184_not629 : ~ @Equation629 Fin4 reff184_inst.
Proof. unfold Equation629. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff184_inst, reff184_op in H. discriminate H. Qed.

Lemma reff184_not632 : ~ @Equation632 Fin4 reff184_inst.
Proof. unfold Equation632. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff184_inst, reff184_op in H. discriminate H. Qed.

Lemma reff184_not633 : ~ @Equation633 Fin4 reff184_inst.
Proof. unfold Equation633. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff184_inst, reff184_op in H. discriminate H. Qed.

Lemma reff184_not639 : ~ @Equation639 Fin4 reff184_inst.
Proof. unfold Equation639. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff184_inst, reff184_op in H. discriminate H. Qed.

Lemma reff184_not640 : ~ @Equation640 Fin4 reff184_inst.
Proof. unfold Equation640. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff184_inst, reff184_op in H. discriminate H. Qed.

Lemma reff184_not642 : ~ @Equation642 Fin4 reff184_inst.
Proof. unfold Equation642. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff184_inst, reff184_op in H. discriminate H. Qed.

Lemma reff184_not643 : ~ @Equation643 Fin4 reff184_inst.
Proof. unfold Equation643. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff184_inst, reff184_op in H. discriminate H. Qed.

Lemma reff184_not666 : ~ @Equation666 Fin4 reff184_inst.
Proof. unfold Equation666. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff184_inst, reff184_op in H. discriminate H. Qed.

Lemma reff184_not667 : ~ @Equation667 Fin4 reff184_inst.
Proof. unfold Equation667. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff184_inst, reff184_op in H. discriminate H. Qed.

Lemma reff184_not670 : ~ @Equation670 Fin4 reff184_inst.
Proof. unfold Equation670. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff184_inst, reff184_op in H. discriminate H. Qed.

Lemma reff184_not677 : ~ @Equation677 Fin4 reff184_inst.
Proof. unfold Equation677. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff184_inst, reff184_op in H. discriminate H. Qed.

Lemma reff184_not679 : ~ @Equation679 Fin4 reff184_inst.
Proof. unfold Equation679. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff184_inst, reff184_op in H. discriminate H. Qed.

Lemma reff184_not704 : ~ @Equation704 Fin4 reff184_inst.
Proof. unfold Equation704. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff184_inst, reff184_op in H. discriminate H. Qed.

Lemma reff184_not706 : ~ @Equation706 Fin4 reff184_inst.
Proof. unfold Equation706. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff184_inst, reff184_op in H. discriminate H. Qed.

Lemma reff184_not713 : ~ @Equation713 Fin4 reff184_inst.
Proof. unfold Equation713. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff184_inst, reff184_op in H. discriminate H. Qed.

Lemma reff184_not716 : ~ @Equation716 Fin4 reff184_inst.
Proof. unfold Equation716. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff184_inst, reff184_op in H. discriminate H. Qed.

Lemma reff184_not817 : ~ @Equation817 Fin4 reff184_inst.
Proof. unfold Equation817. intro H. specialize (H F4_1). unfold magma_op, reff184_inst, reff184_op in H. discriminate H. Qed.

Lemma reff184_not1021 : ~ @Equation1021 Fin4 reff184_inst.
Proof. unfold Equation1021. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff184_inst, reff184_op in H. discriminate H. Qed.

Lemma reff184_not1022 : ~ @Equation1022 Fin4 reff184_inst.
Proof. unfold Equation1022. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff184_inst, reff184_op in H. discriminate H. Qed.

Lemma reff184_not1023 : ~ @Equation1023 Fin4 reff184_inst.
Proof. unfold Equation1023. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff184_inst, reff184_op in H. discriminate H. Qed.

Lemma reff184_not1025 : ~ @Equation1025 Fin4 reff184_inst.
Proof. unfold Equation1025. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff184_inst, reff184_op in H. discriminate H. Qed.

Lemma reff184_not1026 : ~ @Equation1026 Fin4 reff184_inst.
Proof. unfold Equation1026. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff184_inst, reff184_op in H. discriminate H. Qed.

Lemma reff184_not1028 : ~ @Equation1028 Fin4 reff184_inst.
Proof. unfold Equation1028. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff184_inst, reff184_op in H. discriminate H. Qed.

Lemma reff184_not1029 : ~ @Equation1029 Fin4 reff184_inst.
Proof. unfold Equation1029. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff184_inst, reff184_op in H. discriminate H. Qed.

Lemma reff184_not1035 : ~ @Equation1035 Fin4 reff184_inst.
Proof. unfold Equation1035. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff184_inst, reff184_op in H. discriminate H. Qed.

Lemma reff184_not1039 : ~ @Equation1039 Fin4 reff184_inst.
Proof. unfold Equation1039. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff184_inst, reff184_op in H. discriminate H. Qed.

Lemma reff184_not1046 : ~ @Equation1046 Fin4 reff184_inst.
Proof. unfold Equation1046. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff184_inst, reff184_op in H. discriminate H. Qed.

Lemma reff184_not1048 : ~ @Equation1048 Fin4 reff184_inst.
Proof. unfold Equation1048. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff184_inst, reff184_op in H. discriminate H. Qed.

Lemma reff184_not1049 : ~ @Equation1049 Fin4 reff184_inst.
Proof. unfold Equation1049. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff184_inst, reff184_op in H. discriminate H. Qed.

Lemma reff184_not1072 : ~ @Equation1072 Fin4 reff184_inst.
Proof. unfold Equation1072. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff184_inst, reff184_op in H. discriminate H. Qed.

Lemma reff184_not1076 : ~ @Equation1076 Fin4 reff184_inst.
Proof. unfold Equation1076. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff184_inst, reff184_op in H. discriminate H. Qed.

Lemma reff184_not1083 : ~ @Equation1083 Fin4 reff184_inst.
Proof. unfold Equation1083. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff184_inst, reff184_op in H. discriminate H. Qed.

Lemma reff184_not1085 : ~ @Equation1085 Fin4 reff184_inst.
Proof. unfold Equation1085. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff184_inst, reff184_op in H. discriminate H. Qed.

Lemma reff184_not1086 : ~ @Equation1086 Fin4 reff184_inst.
Proof. unfold Equation1086. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff184_inst, reff184_op in H. discriminate H. Qed.

Lemma reff184_not1109 : ~ @Equation1109 Fin4 reff184_inst.
Proof. unfold Equation1109. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff184_inst, reff184_op in H. discriminate H. Qed.

Lemma reff184_not1110 : ~ @Equation1110 Fin4 reff184_inst.
Proof. unfold Equation1110. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff184_inst, reff184_op in H. discriminate H. Qed.

Lemma reff184_not1112 : ~ @Equation1112 Fin4 reff184_inst.
Proof. unfold Equation1112. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff184_inst, reff184_op in H. discriminate H. Qed.

Lemma reff184_not1119 : ~ @Equation1119 Fin4 reff184_inst.
Proof. unfold Equation1119. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff184_inst, reff184_op in H. discriminate H. Qed.

Lemma reff184_not1224 : ~ @Equation1224 Fin4 reff184_inst.
Proof. unfold Equation1224. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff184_inst, reff184_op in H. discriminate H. Qed.

Lemma reff184_not1225 : ~ @Equation1225 Fin4 reff184_inst.
Proof. unfold Equation1225. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff184_inst, reff184_op in H. discriminate H. Qed.

Lemma reff184_not1228 : ~ @Equation1228 Fin4 reff184_inst.
Proof. unfold Equation1228. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff184_inst, reff184_op in H. discriminate H. Qed.

Lemma reff184_not1229 : ~ @Equation1229 Fin4 reff184_inst.
Proof. unfold Equation1229. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff184_inst, reff184_op in H. discriminate H. Qed.

Lemma reff184_not1232 : ~ @Equation1232 Fin4 reff184_inst.
Proof. unfold Equation1232. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff184_inst, reff184_op in H. discriminate H. Qed.

Lemma reff184_not1238 : ~ @Equation1238 Fin4 reff184_inst.
Proof. unfold Equation1238. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff184_inst, reff184_op in H. discriminate H. Qed.

Lemma reff184_not1239 : ~ @Equation1239 Fin4 reff184_inst.
Proof. unfold Equation1239. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff184_inst, reff184_op in H. discriminate H. Qed.

Lemma reff184_not1242 : ~ @Equation1242 Fin4 reff184_inst.
Proof. unfold Equation1242. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff184_inst, reff184_op in H. discriminate H. Qed.

Lemma reff184_not1248 : ~ @Equation1248 Fin4 reff184_inst.
Proof. unfold Equation1248. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff184_inst, reff184_op in H. discriminate H. Qed.

Lemma reff184_not1249 : ~ @Equation1249 Fin4 reff184_inst.
Proof. unfold Equation1249. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff184_inst, reff184_op in H. discriminate H. Qed.

Lemma reff184_not1251 : ~ @Equation1251 Fin4 reff184_inst.
Proof. unfold Equation1251. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff184_inst, reff184_op in H. discriminate H. Qed.

Lemma reff184_not1252 : ~ @Equation1252 Fin4 reff184_inst.
Proof. unfold Equation1252. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff184_inst, reff184_op in H. discriminate H. Qed.

Lemma reff184_not1275 : ~ @Equation1275 Fin4 reff184_inst.
Proof. unfold Equation1275. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff184_inst, reff184_op in H. discriminate H. Qed.

Lemma reff184_not1278 : ~ @Equation1278 Fin4 reff184_inst.
Proof. unfold Equation1278. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff184_inst, reff184_op in H. discriminate H. Qed.

Lemma reff184_not1279 : ~ @Equation1279 Fin4 reff184_inst.
Proof. unfold Equation1279. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff184_inst, reff184_op in H. discriminate H. Qed.

Lemma reff184_not1286 : ~ @Equation1286 Fin4 reff184_inst.
Proof. unfold Equation1286. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff184_inst, reff184_op in H. discriminate H. Qed.

Lemma reff184_not1288 : ~ @Equation1288 Fin4 reff184_inst.
Proof. unfold Equation1288. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff184_inst, reff184_op in H. discriminate H. Qed.

Lemma reff184_not1313 : ~ @Equation1313 Fin4 reff184_inst.
Proof. unfold Equation1313. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff184_inst, reff184_op in H. discriminate H. Qed.

Lemma reff184_not1315 : ~ @Equation1315 Fin4 reff184_inst.
Proof. unfold Equation1315. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff184_inst, reff184_op in H. discriminate H. Qed.

Lemma reff184_not1322 : ~ @Equation1322 Fin4 reff184_inst.
Proof. unfold Equation1322. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff184_inst, reff184_op in H. discriminate H. Qed.

Lemma reff184_not1323 : ~ @Equation1323 Fin4 reff184_inst.
Proof. unfold Equation1323. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff184_inst, reff184_op in H. discriminate H. Qed.

Lemma reff184_not1427 : ~ @Equation1427 Fin4 reff184_inst.
Proof. unfold Equation1427. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff184_inst, reff184_op in H. discriminate H. Qed.

Lemma reff184_not1428 : ~ @Equation1428 Fin4 reff184_inst.
Proof. unfold Equation1428. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff184_inst, reff184_op in H. discriminate H. Qed.

Lemma reff184_not1429 : ~ @Equation1429 Fin4 reff184_inst.
Proof. unfold Equation1429. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff184_inst, reff184_op in H. discriminate H. Qed.

Lemma reff184_not1431 : ~ @Equation1431 Fin4 reff184_inst.
Proof. unfold Equation1431. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff184_inst, reff184_op in H. discriminate H. Qed.

Lemma reff184_not1435 : ~ @Equation1435 Fin4 reff184_inst.
Proof. unfold Equation1435. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff184_inst, reff184_op in H. discriminate H. Qed.

Lemma reff184_not1441 : ~ @Equation1441 Fin4 reff184_inst.
Proof. unfold Equation1441. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff184_inst, reff184_op in H. discriminate H. Qed.

Lemma reff184_not1445 : ~ @Equation1445 Fin4 reff184_inst.
Proof. unfold Equation1445. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff184_inst, reff184_op in H. discriminate H. Qed.

Lemma reff184_not1451 : ~ @Equation1451 Fin4 reff184_inst.
Proof. unfold Equation1451. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff184_inst, reff184_op in H. discriminate H. Qed.

Lemma reff184_not1452 : ~ @Equation1452 Fin4 reff184_inst.
Proof. unfold Equation1452. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff184_inst, reff184_op in H. discriminate H. Qed.

Lemma reff184_not1454 : ~ @Equation1454 Fin4 reff184_inst.
Proof. unfold Equation1454. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff184_inst, reff184_op in H. discriminate H. Qed.

Lemma reff184_not1478 : ~ @Equation1478 Fin4 reff184_inst.
Proof. unfold Equation1478. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff184_inst, reff184_op in H. discriminate H. Qed.

Lemma reff184_not1482 : ~ @Equation1482 Fin4 reff184_inst.
Proof. unfold Equation1482. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff184_inst, reff184_op in H. discriminate H. Qed.

Lemma reff184_not1488 : ~ @Equation1488 Fin4 reff184_inst.
Proof. unfold Equation1488. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff184_inst, reff184_op in H. discriminate H. Qed.

Lemma reff184_not1489 : ~ @Equation1489 Fin4 reff184_inst.
Proof. unfold Equation1489. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff184_inst, reff184_op in H. discriminate H. Qed.

Lemma reff184_not1491 : ~ @Equation1491 Fin4 reff184_inst.
Proof. unfold Equation1491. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff184_inst, reff184_op in H. discriminate H. Qed.

Lemma reff184_not1515 : ~ @Equation1515 Fin4 reff184_inst.
Proof. unfold Equation1515. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff184_inst, reff184_op in H. discriminate H. Qed.

Lemma reff184_not1516 : ~ @Equation1516 Fin4 reff184_inst.
Proof. unfold Equation1516. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff184_inst, reff184_op in H. discriminate H. Qed.

Lemma reff184_not1518 : ~ @Equation1518 Fin4 reff184_inst.
Proof. unfold Equation1518. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff184_inst, reff184_op in H. discriminate H. Qed.

Lemma reff184_not1525 : ~ @Equation1525 Fin4 reff184_inst.
Proof. unfold Equation1525. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff184_inst, reff184_op in H. discriminate H. Qed.

Lemma reff184_not1526 : ~ @Equation1526 Fin4 reff184_inst.
Proof. unfold Equation1526. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff184_inst, reff184_op in H. discriminate H. Qed.

Lemma reff184_not1528 : ~ @Equation1528 Fin4 reff184_inst.
Proof. unfold Equation1528. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff184_inst, reff184_op in H. discriminate H. Qed.

Lemma reff184_not1630 : ~ @Equation1630 Fin4 reff184_inst.
Proof. unfold Equation1630. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff184_inst, reff184_op in H. discriminate H. Qed.

Lemma reff184_not1631 : ~ @Equation1631 Fin4 reff184_inst.
Proof. unfold Equation1631. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff184_inst, reff184_op in H. discriminate H. Qed.

Lemma reff184_not1634 : ~ @Equation1634 Fin4 reff184_inst.
Proof. unfold Equation1634. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff184_inst, reff184_op in H. discriminate H. Qed.

Lemma reff184_not1637 : ~ @Equation1637 Fin4 reff184_inst.
Proof. unfold Equation1637. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff184_inst, reff184_op in H. discriminate H. Qed.

Lemma reff184_not1638 : ~ @Equation1638 Fin4 reff184_inst.
Proof. unfold Equation1638. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff184_inst, reff184_op in H. discriminate H. Qed.

Lemma reff184_not1644 : ~ @Equation1644 Fin4 reff184_inst.
Proof. unfold Equation1644. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff184_inst, reff184_op in H. discriminate H. Qed.

Lemma reff184_not1645 : ~ @Equation1645 Fin4 reff184_inst.
Proof. unfold Equation1645. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff184_inst, reff184_op in H. discriminate H. Qed.

Lemma reff184_not1648 : ~ @Equation1648 Fin4 reff184_inst.
Proof. unfold Equation1648. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff184_inst, reff184_op in H. discriminate H. Qed.

Lemma reff184_not1655 : ~ @Equation1655 Fin4 reff184_inst.
Proof. unfold Equation1655. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff184_inst, reff184_op in H. discriminate H. Qed.

Lemma reff184_not1657 : ~ @Equation1657 Fin4 reff184_inst.
Proof. unfold Equation1657. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff184_inst, reff184_op in H. discriminate H. Qed.

Lemma reff184_not1681 : ~ @Equation1681 Fin4 reff184_inst.
Proof. unfold Equation1681. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff184_inst, reff184_op in H. discriminate H. Qed.

Lemma reff184_not1682 : ~ @Equation1682 Fin4 reff184_inst.
Proof. unfold Equation1682. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff184_inst, reff184_op in H. discriminate H. Qed.

Lemma reff184_not1685 : ~ @Equation1685 Fin4 reff184_inst.
Proof. unfold Equation1685. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff184_inst, reff184_op in H. discriminate H. Qed.

Lemma reff184_not1692 : ~ @Equation1692 Fin4 reff184_inst.
Proof. unfold Equation1692. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff184_inst, reff184_op in H. discriminate H. Qed.

Lemma reff184_not1694 : ~ @Equation1694 Fin4 reff184_inst.
Proof. unfold Equation1694. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff184_inst, reff184_op in H. discriminate H. Qed.

Lemma reff184_not1718 : ~ @Equation1718 Fin4 reff184_inst.
Proof. unfold Equation1718. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff184_inst, reff184_op in H. discriminate H. Qed.

Lemma reff184_not1719 : ~ @Equation1719 Fin4 reff184_inst.
Proof. unfold Equation1719. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff184_inst, reff184_op in H. discriminate H. Qed.

Lemma reff184_not1721 : ~ @Equation1721 Fin4 reff184_inst.
Proof. unfold Equation1721. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff184_inst, reff184_op in H. discriminate H. Qed.

Lemma reff184_not1722 : ~ @Equation1722 Fin4 reff184_inst.
Proof. unfold Equation1722. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff184_inst, reff184_op in H. discriminate H. Qed.

Lemma reff184_not1728 : ~ @Equation1728 Fin4 reff184_inst.
Proof. unfold Equation1728. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff184_inst, reff184_op in H. discriminate H. Qed.

Lemma reff184_not1729 : ~ @Equation1729 Fin4 reff184_inst.
Proof. unfold Equation1729. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff184_inst, reff184_op in H. discriminate H. Qed.

Lemma reff184_not1833 : ~ @Equation1833 Fin4 reff184_inst.
Proof. unfold Equation1833. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff184_inst, reff184_op in H. discriminate H. Qed.

Lemma reff184_not1834 : ~ @Equation1834 Fin4 reff184_inst.
Proof. unfold Equation1834. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff184_inst, reff184_op in H. discriminate H. Qed.

Lemma reff184_not1835 : ~ @Equation1835 Fin4 reff184_inst.
Proof. unfold Equation1835. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff184_inst, reff184_op in H. discriminate H. Qed.

Lemma reff184_not1837 : ~ @Equation1837 Fin4 reff184_inst.
Proof. unfold Equation1837. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff184_inst, reff184_op in H. discriminate H. Qed.

Lemma reff184_not1841 : ~ @Equation1841 Fin4 reff184_inst.
Proof. unfold Equation1841. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff184_inst, reff184_op in H. discriminate H. Qed.

Lemma reff184_not1847 : ~ @Equation1847 Fin4 reff184_inst.
Proof. unfold Equation1847. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff184_inst, reff184_op in H. discriminate H. Qed.

Lemma reff184_not1851 : ~ @Equation1851 Fin4 reff184_inst.
Proof. unfold Equation1851. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff184_inst, reff184_op in H. discriminate H. Qed.

Lemma reff184_not1857 : ~ @Equation1857 Fin4 reff184_inst.
Proof. unfold Equation1857. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff184_inst, reff184_op in H. discriminate H. Qed.

Lemma reff184_not1858 : ~ @Equation1858 Fin4 reff184_inst.
Proof. unfold Equation1858. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff184_inst, reff184_op in H. discriminate H. Qed.

Lemma reff184_not1860 : ~ @Equation1860 Fin4 reff184_inst.
Proof. unfold Equation1860. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff184_inst, reff184_op in H. discriminate H. Qed.

Lemma reff184_not1884 : ~ @Equation1884 Fin4 reff184_inst.
Proof. unfold Equation1884. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff184_inst, reff184_op in H. discriminate H. Qed.

Lemma reff184_not1885 : ~ @Equation1885 Fin4 reff184_inst.
Proof. unfold Equation1885. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff184_inst, reff184_op in H. discriminate H. Qed.

Lemma reff184_not1887 : ~ @Equation1887 Fin4 reff184_inst.
Proof. unfold Equation1887. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff184_inst, reff184_op in H. discriminate H. Qed.

Lemma reff184_not1888 : ~ @Equation1888 Fin4 reff184_inst.
Proof. unfold Equation1888. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff184_inst, reff184_op in H. discriminate H. Qed.

Lemma reff184_not1895 : ~ @Equation1895 Fin4 reff184_inst.
Proof. unfold Equation1895. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff184_inst, reff184_op in H. discriminate H. Qed.

Lemma reff184_not1897 : ~ @Equation1897 Fin4 reff184_inst.
Proof. unfold Equation1897. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff184_inst, reff184_op in H. discriminate H. Qed.

Lemma reff184_not1898 : ~ @Equation1898 Fin4 reff184_inst.
Proof. unfold Equation1898. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff184_inst, reff184_op in H. discriminate H. Qed.

Lemma reff184_not1922 : ~ @Equation1922 Fin4 reff184_inst.
Proof. unfold Equation1922. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff184_inst, reff184_op in H. discriminate H. Qed.

Lemma reff184_not1924 : ~ @Equation1924 Fin4 reff184_inst.
Proof. unfold Equation1924. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff184_inst, reff184_op in H. discriminate H. Qed.

Lemma reff184_not1925 : ~ @Equation1925 Fin4 reff184_inst.
Proof. unfold Equation1925. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff184_inst, reff184_op in H. discriminate H. Qed.

Lemma reff184_not1931 : ~ @Equation1931 Fin4 reff184_inst.
Proof. unfold Equation1931. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff184_inst, reff184_op in H. discriminate H. Qed.

Lemma reff184_not2036 : ~ @Equation2036 Fin4 reff184_inst.
Proof. unfold Equation2036. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff184_inst, reff184_op in H. discriminate H. Qed.

Lemma reff184_not2037 : ~ @Equation2037 Fin4 reff184_inst.
Proof. unfold Equation2037. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff184_inst, reff184_op in H. discriminate H. Qed.

Lemma reff184_not2038 : ~ @Equation2038 Fin4 reff184_inst.
Proof. unfold Equation2038. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff184_inst, reff184_op in H. discriminate H. Qed.

Lemma reff184_not2040 : ~ @Equation2040 Fin4 reff184_inst.
Proof. unfold Equation2040. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff184_inst, reff184_op in H. discriminate H. Qed.

Lemma reff184_not2041 : ~ @Equation2041 Fin4 reff184_inst.
Proof. unfold Equation2041. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff184_inst, reff184_op in H. discriminate H. Qed.

Lemma reff184_not2043 : ~ @Equation2043 Fin4 reff184_inst.
Proof. unfold Equation2043. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff184_inst, reff184_op in H. discriminate H. Qed.

Lemma reff184_not2044 : ~ @Equation2044 Fin4 reff184_inst.
Proof. unfold Equation2044. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff184_inst, reff184_op in H. discriminate H. Qed.

Lemma reff184_not2050 : ~ @Equation2050 Fin4 reff184_inst.
Proof. unfold Equation2050. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff184_inst, reff184_op in H. discriminate H. Qed.

Lemma reff184_not2054 : ~ @Equation2054 Fin4 reff184_inst.
Proof. unfold Equation2054. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff184_inst, reff184_op in H. discriminate H. Qed.

Lemma reff184_not2061 : ~ @Equation2061 Fin4 reff184_inst.
Proof. unfold Equation2061. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff184_inst, reff184_op in H. discriminate H. Qed.

Lemma reff184_not2063 : ~ @Equation2063 Fin4 reff184_inst.
Proof. unfold Equation2063. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff184_inst, reff184_op in H. discriminate H. Qed.

Lemma reff184_not2064 : ~ @Equation2064 Fin4 reff184_inst.
Proof. unfold Equation2064. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff184_inst, reff184_op in H. discriminate H. Qed.

Lemma reff184_not2087 : ~ @Equation2087 Fin4 reff184_inst.
Proof. unfold Equation2087. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff184_inst, reff184_op in H. discriminate H. Qed.

Lemma reff184_not2091 : ~ @Equation2091 Fin4 reff184_inst.
Proof. unfold Equation2091. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff184_inst, reff184_op in H. discriminate H. Qed.

Lemma reff184_not2098 : ~ @Equation2098 Fin4 reff184_inst.
Proof. unfold Equation2098. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff184_inst, reff184_op in H. discriminate H. Qed.

Lemma reff184_not2100 : ~ @Equation2100 Fin4 reff184_inst.
Proof. unfold Equation2100. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff184_inst, reff184_op in H. discriminate H. Qed.

Lemma reff184_not2101 : ~ @Equation2101 Fin4 reff184_inst.
Proof. unfold Equation2101. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff184_inst, reff184_op in H. discriminate H. Qed.

Lemma reff184_not2124 : ~ @Equation2124 Fin4 reff184_inst.
Proof. unfold Equation2124. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff184_inst, reff184_op in H. discriminate H. Qed.

Lemma reff184_not2125 : ~ @Equation2125 Fin4 reff184_inst.
Proof. unfold Equation2125. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff184_inst, reff184_op in H. discriminate H. Qed.

Lemma reff184_not2127 : ~ @Equation2127 Fin4 reff184_inst.
Proof. unfold Equation2127. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff184_inst, reff184_op in H. discriminate H. Qed.

Lemma reff184_not2134 : ~ @Equation2134 Fin4 reff184_inst.
Proof. unfold Equation2134. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff184_inst, reff184_op in H. discriminate H. Qed.

Lemma reff184_not2239 : ~ @Equation2239 Fin4 reff184_inst.
Proof. unfold Equation2239. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff184_inst, reff184_op in H. discriminate H. Qed.

Lemma reff184_not2240 : ~ @Equation2240 Fin4 reff184_inst.
Proof. unfold Equation2240. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff184_inst, reff184_op in H. discriminate H. Qed.

Lemma reff184_not2243 : ~ @Equation2243 Fin4 reff184_inst.
Proof. unfold Equation2243. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff184_inst, reff184_op in H. discriminate H. Qed.

Lemma reff184_not2246 : ~ @Equation2246 Fin4 reff184_inst.
Proof. unfold Equation2246. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff184_inst, reff184_op in H. discriminate H. Qed.

Lemma reff184_not2247 : ~ @Equation2247 Fin4 reff184_inst.
Proof. unfold Equation2247. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff184_inst, reff184_op in H. discriminate H. Qed.

Lemma reff184_not2253 : ~ @Equation2253 Fin4 reff184_inst.
Proof. unfold Equation2253. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff184_inst, reff184_op in H. discriminate H. Qed.

Lemma reff184_not2254 : ~ @Equation2254 Fin4 reff184_inst.
Proof. unfold Equation2254. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff184_inst, reff184_op in H. discriminate H. Qed.

Lemma reff184_not2257 : ~ @Equation2257 Fin4 reff184_inst.
Proof. unfold Equation2257. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff184_inst, reff184_op in H. discriminate H. Qed.

Lemma reff184_not2264 : ~ @Equation2264 Fin4 reff184_inst.
Proof. unfold Equation2264. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff184_inst, reff184_op in H. discriminate H. Qed.

Lemma reff184_not2266 : ~ @Equation2266 Fin4 reff184_inst.
Proof. unfold Equation2266. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff184_inst, reff184_op in H. discriminate H. Qed.

Lemma reff184_not2290 : ~ @Equation2290 Fin4 reff184_inst.
Proof. unfold Equation2290. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff184_inst, reff184_op in H. discriminate H. Qed.

Lemma reff184_not2293 : ~ @Equation2293 Fin4 reff184_inst.
Proof. unfold Equation2293. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff184_inst, reff184_op in H. discriminate H. Qed.

Lemma reff184_not2294 : ~ @Equation2294 Fin4 reff184_inst.
Proof. unfold Equation2294. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff184_inst, reff184_op in H. discriminate H. Qed.

Lemma reff184_not2300 : ~ @Equation2300 Fin4 reff184_inst.
Proof. unfold Equation2300. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff184_inst, reff184_op in H. discriminate H. Qed.

Lemma reff184_not2301 : ~ @Equation2301 Fin4 reff184_inst.
Proof. unfold Equation2301. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff184_inst, reff184_op in H. discriminate H. Qed.

Lemma reff184_not2303 : ~ @Equation2303 Fin4 reff184_inst.
Proof. unfold Equation2303. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff184_inst, reff184_op in H. discriminate H. Qed.

Lemma reff184_not2304 : ~ @Equation2304 Fin4 reff184_inst.
Proof. unfold Equation2304. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff184_inst, reff184_op in H. discriminate H. Qed.

Lemma reff184_not2328 : ~ @Equation2328 Fin4 reff184_inst.
Proof. unfold Equation2328. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff184_inst, reff184_op in H. discriminate H. Qed.

Lemma reff184_not2330 : ~ @Equation2330 Fin4 reff184_inst.
Proof. unfold Equation2330. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff184_inst, reff184_op in H. discriminate H. Qed.

Lemma reff184_not2337 : ~ @Equation2337 Fin4 reff184_inst.
Proof. unfold Equation2337. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff184_inst, reff184_op in H. discriminate H. Qed.

Lemma reff184_not2340 : ~ @Equation2340 Fin4 reff184_inst.
Proof. unfold Equation2340. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff184_inst, reff184_op in H. discriminate H. Qed.

Lemma reff184_not2442 : ~ @Equation2442 Fin4 reff184_inst.
Proof. unfold Equation2442. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff184_inst, reff184_op in H. discriminate H. Qed.

Lemma reff184_not2443 : ~ @Equation2443 Fin4 reff184_inst.
Proof. unfold Equation2443. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff184_inst, reff184_op in H. discriminate H. Qed.

Lemma reff184_not2444 : ~ @Equation2444 Fin4 reff184_inst.
Proof. unfold Equation2444. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff184_inst, reff184_op in H. discriminate H. Qed.

Lemma reff184_not2446 : ~ @Equation2446 Fin4 reff184_inst.
Proof. unfold Equation2446. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff184_inst, reff184_op in H. discriminate H. Qed.

Lemma reff184_not2450 : ~ @Equation2450 Fin4 reff184_inst.
Proof. unfold Equation2450. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff184_inst, reff184_op in H. discriminate H. Qed.

Lemma reff184_not2456 : ~ @Equation2456 Fin4 reff184_inst.
Proof. unfold Equation2456. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff184_inst, reff184_op in H. discriminate H. Qed.

Lemma reff184_not2460 : ~ @Equation2460 Fin4 reff184_inst.
Proof. unfold Equation2460. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff184_inst, reff184_op in H. discriminate H. Qed.

Lemma reff184_not2466 : ~ @Equation2466 Fin4 reff184_inst.
Proof. unfold Equation2466. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff184_inst, reff184_op in H. discriminate H. Qed.

Lemma reff184_not2467 : ~ @Equation2467 Fin4 reff184_inst.
Proof. unfold Equation2467. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff184_inst, reff184_op in H. discriminate H. Qed.

Lemma reff184_not2469 : ~ @Equation2469 Fin4 reff184_inst.
Proof. unfold Equation2469. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff184_inst, reff184_op in H. discriminate H. Qed.

Lemma reff184_not2493 : ~ @Equation2493 Fin4 reff184_inst.
Proof. unfold Equation2493. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff184_inst, reff184_op in H. discriminate H. Qed.

Lemma reff184_not2497 : ~ @Equation2497 Fin4 reff184_inst.
Proof. unfold Equation2497. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff184_inst, reff184_op in H. discriminate H. Qed.

Lemma reff184_not2503 : ~ @Equation2503 Fin4 reff184_inst.
Proof. unfold Equation2503. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff184_inst, reff184_op in H. discriminate H. Qed.

Lemma reff184_not2504 : ~ @Equation2504 Fin4 reff184_inst.
Proof. unfold Equation2504. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff184_inst, reff184_op in H. discriminate H. Qed.

Lemma reff184_not2506 : ~ @Equation2506 Fin4 reff184_inst.
Proof. unfold Equation2506. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff184_inst, reff184_op in H. discriminate H. Qed.

Lemma reff184_not2530 : ~ @Equation2530 Fin4 reff184_inst.
Proof. unfold Equation2530. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff184_inst, reff184_op in H. discriminate H. Qed.

Lemma reff184_not2531 : ~ @Equation2531 Fin4 reff184_inst.
Proof. unfold Equation2531. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff184_inst, reff184_op in H. discriminate H. Qed.

Lemma reff184_not2533 : ~ @Equation2533 Fin4 reff184_inst.
Proof. unfold Equation2533. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff184_inst, reff184_op in H. discriminate H. Qed.

Lemma reff184_not2540 : ~ @Equation2540 Fin4 reff184_inst.
Proof. unfold Equation2540. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff184_inst, reff184_op in H. discriminate H. Qed.

Lemma reff184_not2541 : ~ @Equation2541 Fin4 reff184_inst.
Proof. unfold Equation2541. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff184_inst, reff184_op in H. discriminate H. Qed.

Lemma reff184_not2543 : ~ @Equation2543 Fin4 reff184_inst.
Proof. unfold Equation2543. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff184_inst, reff184_op in H. discriminate H. Qed.

Lemma reff184_not2644 : ~ @Equation2644 Fin4 reff184_inst.
Proof. unfold Equation2644. intro H. specialize (H F4_1). unfold magma_op, reff184_inst, reff184_op in H. discriminate H. Qed.

Lemma reff184_not2848 : ~ @Equation2848 Fin4 reff184_inst.
Proof. unfold Equation2848. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff184_inst, reff184_op in H. discriminate H. Qed.

Lemma reff184_not2849 : ~ @Equation2849 Fin4 reff184_inst.
Proof. unfold Equation2849. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff184_inst, reff184_op in H. discriminate H. Qed.

Lemma reff184_not2852 : ~ @Equation2852 Fin4 reff184_inst.
Proof. unfold Equation2852. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff184_inst, reff184_op in H. discriminate H. Qed.

Lemma reff184_not2855 : ~ @Equation2855 Fin4 reff184_inst.
Proof. unfold Equation2855. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff184_inst, reff184_op in H. discriminate H. Qed.

Lemma reff184_not2856 : ~ @Equation2856 Fin4 reff184_inst.
Proof. unfold Equation2856. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff184_inst, reff184_op in H. discriminate H. Qed.

Lemma reff184_not2862 : ~ @Equation2862 Fin4 reff184_inst.
Proof. unfold Equation2862. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff184_inst, reff184_op in H. discriminate H. Qed.

Lemma reff184_not2865 : ~ @Equation2865 Fin4 reff184_inst.
Proof. unfold Equation2865. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff184_inst, reff184_op in H. discriminate H. Qed.

Lemma reff184_not2866 : ~ @Equation2866 Fin4 reff184_inst.
Proof. unfold Equation2866. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff184_inst, reff184_op in H. discriminate H. Qed.

Lemma reff184_not2872 : ~ @Equation2872 Fin4 reff184_inst.
Proof. unfold Equation2872. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff184_inst, reff184_op in H. discriminate H. Qed.

Lemma reff184_not2873 : ~ @Equation2873 Fin4 reff184_inst.
Proof. unfold Equation2873. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff184_inst, reff184_op in H. discriminate H. Qed.

Lemma reff184_not2875 : ~ @Equation2875 Fin4 reff184_inst.
Proof. unfold Equation2875. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff184_inst, reff184_op in H. discriminate H. Qed.

Lemma reff184_not2876 : ~ @Equation2876 Fin4 reff184_inst.
Proof. unfold Equation2876. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff184_inst, reff184_op in H. discriminate H. Qed.

Lemma reff184_not2899 : ~ @Equation2899 Fin4 reff184_inst.
Proof. unfold Equation2899. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff184_inst, reff184_op in H. discriminate H. Qed.

Lemma reff184_not2900 : ~ @Equation2900 Fin4 reff184_inst.
Proof. unfold Equation2900. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff184_inst, reff184_op in H. discriminate H. Qed.

Lemma reff184_not2903 : ~ @Equation2903 Fin4 reff184_inst.
Proof. unfold Equation2903. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff184_inst, reff184_op in H. discriminate H. Qed.

Lemma reff184_not2910 : ~ @Equation2910 Fin4 reff184_inst.
Proof. unfold Equation2910. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff184_inst, reff184_op in H. discriminate H. Qed.

Lemma reff184_not2912 : ~ @Equation2912 Fin4 reff184_inst.
Proof. unfold Equation2912. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff184_inst, reff184_op in H. discriminate H. Qed.

Lemma reff184_not2937 : ~ @Equation2937 Fin4 reff184_inst.
Proof. unfold Equation2937. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff184_inst, reff184_op in H. discriminate H. Qed.

Lemma reff184_not2939 : ~ @Equation2939 Fin4 reff184_inst.
Proof. unfold Equation2939. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff184_inst, reff184_op in H. discriminate H. Qed.

Lemma reff184_not2946 : ~ @Equation2946 Fin4 reff184_inst.
Proof. unfold Equation2946. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff184_inst, reff184_op in H. discriminate H. Qed.

Lemma reff184_not2949 : ~ @Equation2949 Fin4 reff184_inst.
Proof. unfold Equation2949. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff184_inst, reff184_op in H. discriminate H. Qed.

Lemma reff184_not3051 : ~ @Equation3051 Fin4 reff184_inst.
Proof. unfold Equation3051. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff184_inst, reff184_op in H. discriminate H. Qed.

Lemma reff184_not3052 : ~ @Equation3052 Fin4 reff184_inst.
Proof. unfold Equation3052. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff184_inst, reff184_op in H. discriminate H. Qed.

Lemma reff184_not3055 : ~ @Equation3055 Fin4 reff184_inst.
Proof. unfold Equation3055. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff184_inst, reff184_op in H. discriminate H. Qed.

Lemma reff184_not3056 : ~ @Equation3056 Fin4 reff184_inst.
Proof. unfold Equation3056. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff184_inst, reff184_op in H. discriminate H. Qed.

Lemma reff184_not3059 : ~ @Equation3059 Fin4 reff184_inst.
Proof. unfold Equation3059. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff184_inst, reff184_op in H. discriminate H. Qed.

Lemma reff184_not3065 : ~ @Equation3065 Fin4 reff184_inst.
Proof. unfold Equation3065. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff184_inst, reff184_op in H. discriminate H. Qed.

Lemma reff184_not3068 : ~ @Equation3068 Fin4 reff184_inst.
Proof. unfold Equation3068. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff184_inst, reff184_op in H. discriminate H. Qed.

Lemma reff184_not3069 : ~ @Equation3069 Fin4 reff184_inst.
Proof. unfold Equation3069. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff184_inst, reff184_op in H. discriminate H. Qed.

Lemma reff184_not3076 : ~ @Equation3076 Fin4 reff184_inst.
Proof. unfold Equation3076. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff184_inst, reff184_op in H. discriminate H. Qed.

Lemma reff184_not3078 : ~ @Equation3078 Fin4 reff184_inst.
Proof. unfold Equation3078. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff184_inst, reff184_op in H. discriminate H. Qed.

Lemma reff184_not3102 : ~ @Equation3102 Fin4 reff184_inst.
Proof. unfold Equation3102. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff184_inst, reff184_op in H. discriminate H. Qed.

Lemma reff184_not3105 : ~ @Equation3105 Fin4 reff184_inst.
Proof. unfold Equation3105. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff184_inst, reff184_op in H. discriminate H. Qed.

Lemma reff184_not3106 : ~ @Equation3106 Fin4 reff184_inst.
Proof. unfold Equation3106. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff184_inst, reff184_op in H. discriminate H. Qed.

Lemma reff184_not3113 : ~ @Equation3113 Fin4 reff184_inst.
Proof. unfold Equation3113. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff184_inst, reff184_op in H. discriminate H. Qed.

Lemma reff184_not3115 : ~ @Equation3115 Fin4 reff184_inst.
Proof. unfold Equation3115. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff184_inst, reff184_op in H. discriminate H. Qed.

Lemma reff184_not3139 : ~ @Equation3139 Fin4 reff184_inst.
Proof. unfold Equation3139. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff184_inst, reff184_op in H. discriminate H. Qed.

Lemma reff184_not3140 : ~ @Equation3140 Fin4 reff184_inst.
Proof. unfold Equation3140. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff184_inst, reff184_op in H. discriminate H. Qed.

Lemma reff184_not3142 : ~ @Equation3142 Fin4 reff184_inst.
Proof. unfold Equation3142. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff184_inst, reff184_op in H. discriminate H. Qed.

Lemma reff184_not3143 : ~ @Equation3143 Fin4 reff184_inst.
Proof. unfold Equation3143. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff184_inst, reff184_op in H. discriminate H. Qed.

Lemma reff184_not3149 : ~ @Equation3149 Fin4 reff184_inst.
Proof. unfold Equation3149. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff184_inst, reff184_op in H. discriminate H. Qed.

Lemma reff184_not3152 : ~ @Equation3152 Fin4 reff184_inst.
Proof. unfold Equation3152. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff184_inst, reff184_op in H. discriminate H. Qed.

Lemma reff184_not3256 : ~ @Equation3256 Fin4 reff184_inst.
Proof. unfold Equation3256. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff184_inst, reff184_op in H. discriminate H. Qed.

Lemma reff184_not3271 : ~ @Equation3271 Fin4 reff184_inst.
Proof. unfold Equation3271. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff184_inst, reff184_op in H. discriminate H. Qed.

Lemma reff184_not3315 : ~ @Equation3315 Fin4 reff184_inst.
Proof. unfold Equation3315. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff184_inst, reff184_op in H. discriminate H. Qed.

Lemma reff184_not3346 : ~ @Equation3346 Fin4 reff184_inst.
Proof. unfold Equation3346. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff184_inst, reff184_op in H. discriminate H. Qed.

Lemma reff184_not3464 : ~ @Equation3464 Fin4 reff184_inst.
Proof. unfold Equation3464. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff184_inst, reff184_op in H. discriminate H. Qed.

Lemma reff184_not3474 : ~ @Equation3474 Fin4 reff184_inst.
Proof. unfold Equation3474. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff184_inst, reff184_op in H. discriminate H. Qed.

Lemma reff184_not3481 : ~ @Equation3481 Fin4 reff184_inst.
Proof. unfold Equation3481. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff184_inst, reff184_op in H. discriminate H. Qed.

Lemma reff184_not3509 : ~ @Equation3509 Fin4 reff184_inst.
Proof. unfold Equation3509. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff184_inst, reff184_op in H. discriminate H. Qed.

Lemma reff184_not3558 : ~ @Equation3558 Fin4 reff184_inst.
Proof. unfold Equation3558. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff184_inst, reff184_op in H. discriminate H. Qed.

Lemma reff184_not3659 : ~ @Equation3659 Fin4 reff184_inst.
Proof. unfold Equation3659. intro H. specialize (H F4_1). unfold magma_op, reff184_inst, reff184_op in H. discriminate H. Qed.

Lemma reff184_not3865 : ~ @Equation3865 Fin4 reff184_inst.
Proof. unfold Equation3865. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff184_inst, reff184_op in H. discriminate H. Qed.

Lemma reff184_not3868 : ~ @Equation3868 Fin4 reff184_inst.
Proof. unfold Equation3868. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff184_inst, reff184_op in H. discriminate H. Qed.

Lemma reff184_not3870 : ~ @Equation3870 Fin4 reff184_inst.
Proof. unfold Equation3870. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff184_inst, reff184_op in H. discriminate H. Qed.

Lemma reff184_not3928 : ~ @Equation3928 Fin4 reff184_inst.
Proof. unfold Equation3928. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff184_inst, reff184_op in H. discriminate H. Qed.

Lemma reff184_not3951 : ~ @Equation3951 Fin4 reff184_inst.
Proof. unfold Equation3951. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff184_inst, reff184_op in H. discriminate H. Qed.

Lemma reff184_not4071 : ~ @Equation4071 Fin4 reff184_inst.
Proof. unfold Equation4071. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff184_inst, reff184_op in H. discriminate H. Qed.

Lemma reff184_not4090 : ~ @Equation4090 Fin4 reff184_inst.
Proof. unfold Equation4090. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff184_inst, reff184_op in H. discriminate H. Qed.

Lemma reff184_not4120 : ~ @Equation4120 Fin4 reff184_inst.
Proof. unfold Equation4120. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff184_inst, reff184_op in H. discriminate H. Qed.

Lemma reff184_not4165 : ~ @Equation4165 Fin4 reff184_inst.
Proof. unfold Equation4165. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff184_inst, reff184_op in H. discriminate H. Qed.

Lemma reff184_not4270 : ~ @Equation4270 Fin4 reff184_inst.
Proof. unfold Equation4270. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff184_inst, reff184_op in H. discriminate H. Qed.

Lemma reff184_not4290 : ~ @Equation4290 Fin4 reff184_inst.
Proof. unfold Equation4290. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff184_inst, reff184_op in H. discriminate H. Qed.

Lemma reff184_not4320 : ~ @Equation4320 Fin4 reff184_inst.
Proof. unfold Equation4320. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff184_inst, reff184_op in H. discriminate H. Qed.

Lemma reff184_not4396 : ~ @Equation4396 Fin4 reff184_inst.
Proof. unfold Equation4396. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff184_inst, reff184_op in H. discriminate H. Qed.

Lemma reff184_not4433 : ~ @Equation4433 Fin4 reff184_inst.
Proof. unfold Equation4433. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff184_inst, reff184_op in H. discriminate H. Qed.

Lemma reff184_not4473 : ~ @Equation4473 Fin4 reff184_inst.
Proof. unfold Equation4473. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff184_inst, reff184_op in H. discriminate H. Qed.

Lemma reff184_not4480 : ~ @Equation4480 Fin4 reff184_inst.
Proof. unfold Equation4480. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff184_inst, reff184_op in H. discriminate H. Qed.

Lemma reff184_not4590 : ~ @Equation4590 Fin4 reff184_inst.
Proof. unfold Equation4590. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff184_inst, reff184_op in H. discriminate H. Qed.

Lemma reff184_not4598 : ~ @Equation4598 Fin4 reff184_inst.
Proof. unfold Equation4598. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff184_inst, reff184_op in H. discriminate H. Qed.

Lemma reff184_not4605 : ~ @Equation4605 Fin4 reff184_inst.
Proof. unfold Equation4605. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff184_inst, reff184_op in H. discriminate H. Qed.

(** ---- reff190 (Fin3) ---- *)

Definition reff190_op (x y : Fin3) : Fin3 :=
  match x, y with
  | F3_0, F3_0 => F3_0 | F3_0, F3_1 => F3_1 | F3_0, F3_2 => F3_0
  | F3_1, F3_0 => F3_0 | F3_1, F3_1 => F3_1 | F3_1, F3_2 => F3_0
  | F3_2, F3_0 => F3_1 | F3_2, F3_1 => F3_2 | F3_2, F3_2 => F3_1
  end.

#[local] Instance reff190_inst : Magma Fin3 := {| magma_op := reff190_op |}.

Lemma reff190_sat8 : @Equation8 Fin3 reff190_inst.
Proof. unfold Equation8, magma_op, reff190_inst, reff190_op. intros x. destruct x; reflexivity. Qed.

Lemma reff190_sat419 : @Equation419 Fin3 reff190_inst.
Proof. unfold Equation419, magma_op, reff190_inst, reff190_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff190_sat429 : @Equation429 Fin3 reff190_inst.
Proof. unfold Equation429, magma_op, reff190_inst, reff190_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff190_sat436 : @Equation436 Fin3 reff190_inst.
Proof. unfold Equation436, magma_op, reff190_inst, reff190_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff190_sat622 : @Equation622 Fin3 reff190_inst.
Proof. unfold Equation622, magma_op, reff190_inst, reff190_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff190_sat842 : @Equation842 Fin3 reff190_inst.
Proof. unfold Equation842, magma_op, reff190_inst, reff190_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff190_sat3334 : @Equation3334 Fin3 reff190_inst.
Proof. unfold Equation3334, magma_op, reff190_inst, reff190_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff190_sat3537 : @Equation3537 Fin3 reff190_inst.
Proof. unfold Equation3537, magma_op, reff190_inst, reff190_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff190_sat3684 : @Equation3684 Fin3 reff190_inst.
Proof. unfold Equation3684, magma_op, reff190_inst, reff190_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff190_sat4590 : @Equation4590 Fin3 reff190_inst.
Proof. unfold Equation4590, magma_op, reff190_inst, reff190_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff190_not47 : ~ @Equation47 Fin3 reff190_inst.
Proof. unfold Equation47. intro H. specialize (H F3_2). unfold magma_op, reff190_inst, reff190_op in H. discriminate H. Qed.

Lemma reff190_not99 : ~ @Equation99 Fin3 reff190_inst.
Proof. unfold Equation99. intro H. specialize (H F3_2). unfold magma_op, reff190_inst, reff190_op in H. discriminate H. Qed.

Lemma reff190_not151 : ~ @Equation151 Fin3 reff190_inst.
Proof. unfold Equation151. intro H. specialize (H F3_2). unfold magma_op, reff190_inst, reff190_op in H. discriminate H. Qed.

Lemma reff190_not203 : ~ @Equation203 Fin3 reff190_inst.
Proof. unfold Equation203. intro H. specialize (H F3_2). unfold magma_op, reff190_inst, reff190_op in H. discriminate H. Qed.

Lemma reff190_not255 : ~ @Equation255 Fin3 reff190_inst.
Proof. unfold Equation255. intro H. specialize (H F3_2). unfold magma_op, reff190_inst, reff190_op in H. discriminate H. Qed.

Lemma reff190_not307 : ~ @Equation307 Fin3 reff190_inst.
Proof. unfold Equation307. intro H. specialize (H F3_2). unfold magma_op, reff190_inst, reff190_op in H. discriminate H. Qed.

Lemma reff190_not412 : ~ @Equation412 Fin3 reff190_inst.
Proof. unfold Equation412. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff190_inst, reff190_op in H. discriminate H. Qed.

Lemma reff190_not413 : ~ @Equation413 Fin3 reff190_inst.
Proof. unfold Equation413. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff190_inst, reff190_op in H. discriminate H. Qed.

Lemma reff190_not414 : ~ @Equation414 Fin3 reff190_inst.
Proof. unfold Equation414. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff190_inst, reff190_op in H. discriminate H. Qed.

Lemma reff190_not416 : ~ @Equation416 Fin3 reff190_inst.
Proof. unfold Equation416. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff190_inst, reff190_op in H. discriminate H. Qed.

Lemma reff190_not417 : ~ @Equation417 Fin3 reff190_inst.
Proof. unfold Equation417. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff190_inst, reff190_op in H. discriminate H. Qed.

Lemma reff190_not420 : ~ @Equation420 Fin3 reff190_inst.
Proof. unfold Equation420. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff190_inst, reff190_op in H. discriminate H. Qed.

Lemma reff190_not426 : ~ @Equation426 Fin3 reff190_inst.
Proof. unfold Equation426. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff190_inst, reff190_op in H. discriminate H. Qed.

Lemma reff190_not427 : ~ @Equation427 Fin3 reff190_inst.
Proof. unfold Equation427. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff190_inst, reff190_op in H. discriminate H. Qed.

Lemma reff190_not430 : ~ @Equation430 Fin3 reff190_inst.
Proof. unfold Equation430. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff190_inst, reff190_op in H. discriminate H. Qed.

Lemma reff190_not437 : ~ @Equation437 Fin3 reff190_inst.
Proof. unfold Equation437. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff190_inst, reff190_op in H. discriminate H. Qed.

Lemma reff190_not439 : ~ @Equation439 Fin3 reff190_inst.
Proof. unfold Equation439. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff190_inst, reff190_op in H. discriminate H. Qed.

Lemma reff190_not440 : ~ @Equation440 Fin3 reff190_inst.
Proof. unfold Equation440. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff190_inst, reff190_op in H. discriminate H. Qed.

Lemma reff190_not463 : ~ @Equation463 Fin3 reff190_inst.
Proof. unfold Equation463. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff190_inst, reff190_op in H. discriminate H. Qed.

Lemma reff190_not464 : ~ @Equation464 Fin3 reff190_inst.
Proof. unfold Equation464. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff190_inst, reff190_op in H. discriminate H. Qed.

Lemma reff190_not466 : ~ @Equation466 Fin3 reff190_inst.
Proof. unfold Equation466. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff190_inst, reff190_op in H. discriminate H. Qed.

Lemma reff190_not467 : ~ @Equation467 Fin3 reff190_inst.
Proof. unfold Equation467. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff190_inst, reff190_op in H. discriminate H. Qed.

Lemma reff190_not473 : ~ @Equation473 Fin3 reff190_inst.
Proof. unfold Equation473. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff190_inst, reff190_op in H. discriminate H. Qed.

Lemma reff190_not474 : ~ @Equation474 Fin3 reff190_inst.
Proof. unfold Equation474. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff190_inst, reff190_op in H. discriminate H. Qed.

Lemma reff190_not476 : ~ @Equation476 Fin3 reff190_inst.
Proof. unfold Equation476. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff190_inst, reff190_op in H. discriminate H. Qed.

Lemma reff190_not477 : ~ @Equation477 Fin3 reff190_inst.
Proof. unfold Equation477. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff190_inst, reff190_op in H. discriminate H. Qed.

Lemma reff190_not500 : ~ @Equation500 Fin3 reff190_inst.
Proof. unfold Equation500. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff190_inst, reff190_op in H. discriminate H. Qed.

Lemma reff190_not501 : ~ @Equation501 Fin3 reff190_inst.
Proof. unfold Equation501. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff190_inst, reff190_op in H. discriminate H. Qed.

Lemma reff190_not503 : ~ @Equation503 Fin3 reff190_inst.
Proof. unfold Equation503. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff190_inst, reff190_op in H. discriminate H. Qed.

Lemma reff190_not504 : ~ @Equation504 Fin3 reff190_inst.
Proof. unfold Equation504. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff190_inst, reff190_op in H. discriminate H. Qed.

Lemma reff190_not510 : ~ @Equation510 Fin3 reff190_inst.
Proof. unfold Equation510. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff190_inst, reff190_op in H. discriminate H. Qed.

Lemma reff190_not511 : ~ @Equation511 Fin3 reff190_inst.
Proof. unfold Equation511. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff190_inst, reff190_op in H. discriminate H. Qed.

Lemma reff190_not513 : ~ @Equation513 Fin3 reff190_inst.
Proof. unfold Equation513. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff190_inst, reff190_op in H. discriminate H. Qed.

Lemma reff190_not615 : ~ @Equation615 Fin3 reff190_inst.
Proof. unfold Equation615. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff190_inst, reff190_op in H. discriminate H. Qed.

Lemma reff190_not616 : ~ @Equation616 Fin3 reff190_inst.
Proof. unfold Equation616. intro H. specialize (H F3_2 F3_1). unfold magma_op, reff190_inst, reff190_op in H. discriminate H. Qed.

Lemma reff190_not617 : ~ @Equation617 Fin3 reff190_inst.
Proof. unfold Equation617. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff190_inst, reff190_op in H. discriminate H. Qed.

Lemma reff190_not619 : ~ @Equation619 Fin3 reff190_inst.
Proof. unfold Equation619. intro H. specialize (H F3_1 F3_2). unfold magma_op, reff190_inst, reff190_op in H. discriminate H. Qed.

Lemma reff190_not620 : ~ @Equation620 Fin3 reff190_inst.
Proof. unfold Equation620. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff190_inst, reff190_op in H. discriminate H. Qed.

Lemma reff190_not623 : ~ @Equation623 Fin3 reff190_inst.
Proof. unfold Equation623. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff190_inst, reff190_op in H. discriminate H. Qed.

Lemma reff190_not629 : ~ @Equation629 Fin3 reff190_inst.
Proof. unfold Equation629. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff190_inst, reff190_op in H. discriminate H. Qed.

Lemma reff190_not630 : ~ @Equation630 Fin3 reff190_inst.
Proof. unfold Equation630. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff190_inst, reff190_op in H. discriminate H. Qed.

Lemma reff190_not632 : ~ @Equation632 Fin3 reff190_inst.
Proof. unfold Equation632. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff190_inst, reff190_op in H. discriminate H. Qed.

Lemma reff190_not633 : ~ @Equation633 Fin3 reff190_inst.
Proof. unfold Equation633. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff190_inst, reff190_op in H. discriminate H. Qed.

Lemma reff190_not639 : ~ @Equation639 Fin3 reff190_inst.
Proof. unfold Equation639. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff190_inst, reff190_op in H. discriminate H. Qed.

Lemma reff190_not640 : ~ @Equation640 Fin3 reff190_inst.
Proof. unfold Equation640. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff190_inst, reff190_op in H. discriminate H. Qed.

Lemma reff190_not642 : ~ @Equation642 Fin3 reff190_inst.
Proof. unfold Equation642. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff190_inst, reff190_op in H. discriminate H. Qed.

Lemma reff190_not643 : ~ @Equation643 Fin3 reff190_inst.
Proof. unfold Equation643. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff190_inst, reff190_op in H. discriminate H. Qed.

Lemma reff190_not666 : ~ @Equation666 Fin3 reff190_inst.
Proof. unfold Equation666. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff190_inst, reff190_op in H. discriminate H. Qed.

Lemma reff190_not667 : ~ @Equation667 Fin3 reff190_inst.
Proof. unfold Equation667. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff190_inst, reff190_op in H. discriminate H. Qed.

Lemma reff190_not669 : ~ @Equation669 Fin3 reff190_inst.
Proof. unfold Equation669. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff190_inst, reff190_op in H. discriminate H. Qed.

Lemma reff190_not670 : ~ @Equation670 Fin3 reff190_inst.
Proof. unfold Equation670. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff190_inst, reff190_op in H. discriminate H. Qed.

Lemma reff190_not676 : ~ @Equation676 Fin3 reff190_inst.
Proof. unfold Equation676. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff190_inst, reff190_op in H. discriminate H. Qed.

Lemma reff190_not677 : ~ @Equation677 Fin3 reff190_inst.
Proof. unfold Equation677. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff190_inst, reff190_op in H. discriminate H. Qed.

Lemma reff190_not679 : ~ @Equation679 Fin3 reff190_inst.
Proof. unfold Equation679. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff190_inst, reff190_op in H. discriminate H. Qed.

Lemma reff190_not680 : ~ @Equation680 Fin3 reff190_inst.
Proof. unfold Equation680. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff190_inst, reff190_op in H. discriminate H. Qed.

Lemma reff190_not703 : ~ @Equation703 Fin3 reff190_inst.
Proof. unfold Equation703. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff190_inst, reff190_op in H. discriminate H. Qed.

Lemma reff190_not704 : ~ @Equation704 Fin3 reff190_inst.
Proof. unfold Equation704. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff190_inst, reff190_op in H. discriminate H. Qed.

Lemma reff190_not706 : ~ @Equation706 Fin3 reff190_inst.
Proof. unfold Equation706. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff190_inst, reff190_op in H. discriminate H. Qed.

Lemma reff190_not707 : ~ @Equation707 Fin3 reff190_inst.
Proof. unfold Equation707. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff190_inst, reff190_op in H. discriminate H. Qed.

Lemma reff190_not713 : ~ @Equation713 Fin3 reff190_inst.
Proof. unfold Equation713. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff190_inst, reff190_op in H. discriminate H. Qed.

Lemma reff190_not714 : ~ @Equation714 Fin3 reff190_inst.
Proof. unfold Equation714. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff190_inst, reff190_op in H. discriminate H. Qed.

Lemma reff190_not716 : ~ @Equation716 Fin3 reff190_inst.
Proof. unfold Equation716. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff190_inst, reff190_op in H. discriminate H. Qed.

Lemma reff190_not818 : ~ @Equation818 Fin3 reff190_inst.
Proof. unfold Equation818. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff190_inst, reff190_op in H. discriminate H. Qed.

Lemma reff190_not819 : ~ @Equation819 Fin3 reff190_inst.
Proof. unfold Equation819. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff190_inst, reff190_op in H. discriminate H. Qed.

Lemma reff190_not820 : ~ @Equation820 Fin3 reff190_inst.
Proof. unfold Equation820. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff190_inst, reff190_op in H. discriminate H. Qed.

Lemma reff190_not822 : ~ @Equation822 Fin3 reff190_inst.
Proof. unfold Equation822. intro H. specialize (H F3_2 F3_1). unfold magma_op, reff190_inst, reff190_op in H. discriminate H. Qed.

Lemma reff190_not823 : ~ @Equation823 Fin3 reff190_inst.
Proof. unfold Equation823. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff190_inst, reff190_op in H. discriminate H. Qed.

Lemma reff190_not825 : ~ @Equation825 Fin3 reff190_inst.
Proof. unfold Equation825. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff190_inst, reff190_op in H. discriminate H. Qed.

Lemma reff190_not826 : ~ @Equation826 Fin3 reff190_inst.
Proof. unfold Equation826. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff190_inst, reff190_op in H. discriminate H. Qed.

Lemma reff190_not832 : ~ @Equation832 Fin3 reff190_inst.
Proof. unfold Equation832. intro H. specialize (H F3_1 F3_2). unfold magma_op, reff190_inst, reff190_op in H. discriminate H. Qed.

Lemma reff190_not833 : ~ @Equation833 Fin3 reff190_inst.
Proof. unfold Equation833. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff190_inst, reff190_op in H. discriminate H. Qed.

Lemma reff190_not835 : ~ @Equation835 Fin3 reff190_inst.
Proof. unfold Equation835. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff190_inst, reff190_op in H. discriminate H. Qed.

Lemma reff190_not836 : ~ @Equation836 Fin3 reff190_inst.
Proof. unfold Equation836. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff190_inst, reff190_op in H. discriminate H. Qed.

Lemma reff190_not843 : ~ @Equation843 Fin3 reff190_inst.
Proof. unfold Equation843. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff190_inst, reff190_op in H. discriminate H. Qed.

Lemma reff190_not845 : ~ @Equation845 Fin3 reff190_inst.
Proof. unfold Equation845. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff190_inst, reff190_op in H. discriminate H. Qed.

Lemma reff190_not846 : ~ @Equation846 Fin3 reff190_inst.
Proof. unfold Equation846. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff190_inst, reff190_op in H. discriminate H. Qed.

Lemma reff190_not869 : ~ @Equation869 Fin3 reff190_inst.
Proof. unfold Equation869. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff190_inst, reff190_op in H. discriminate H. Qed.

Lemma reff190_not870 : ~ @Equation870 Fin3 reff190_inst.
Proof. unfold Equation870. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff190_inst, reff190_op in H. discriminate H. Qed.

Lemma reff190_not872 : ~ @Equation872 Fin3 reff190_inst.
Proof. unfold Equation872. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff190_inst, reff190_op in H. discriminate H. Qed.

Lemma reff190_not873 : ~ @Equation873 Fin3 reff190_inst.
Proof. unfold Equation873. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff190_inst, reff190_op in H. discriminate H. Qed.

Lemma reff190_not879 : ~ @Equation879 Fin3 reff190_inst.
Proof. unfold Equation879. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff190_inst, reff190_op in H. discriminate H. Qed.

Lemma reff190_not880 : ~ @Equation880 Fin3 reff190_inst.
Proof. unfold Equation880. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff190_inst, reff190_op in H. discriminate H. Qed.

Lemma reff190_not882 : ~ @Equation882 Fin3 reff190_inst.
Proof. unfold Equation882. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff190_inst, reff190_op in H. discriminate H. Qed.

Lemma reff190_not883 : ~ @Equation883 Fin3 reff190_inst.
Proof. unfold Equation883. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff190_inst, reff190_op in H. discriminate H. Qed.

Lemma reff190_not906 : ~ @Equation906 Fin3 reff190_inst.
Proof. unfold Equation906. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff190_inst, reff190_op in H. discriminate H. Qed.

Lemma reff190_not907 : ~ @Equation907 Fin3 reff190_inst.
Proof. unfold Equation907. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff190_inst, reff190_op in H. discriminate H. Qed.

Lemma reff190_not909 : ~ @Equation909 Fin3 reff190_inst.
Proof. unfold Equation909. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff190_inst, reff190_op in H. discriminate H. Qed.

Lemma reff190_not910 : ~ @Equation910 Fin3 reff190_inst.
Proof. unfold Equation910. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff190_inst, reff190_op in H. discriminate H. Qed.

Lemma reff190_not916 : ~ @Equation916 Fin3 reff190_inst.
Proof. unfold Equation916. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff190_inst, reff190_op in H. discriminate H. Qed.

Lemma reff190_not917 : ~ @Equation917 Fin3 reff190_inst.
Proof. unfold Equation917. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff190_inst, reff190_op in H. discriminate H. Qed.

Lemma reff190_not919 : ~ @Equation919 Fin3 reff190_inst.
Proof. unfold Equation919. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff190_inst, reff190_op in H. discriminate H. Qed.

Lemma reff190_not1021 : ~ @Equation1021 Fin3 reff190_inst.
Proof. unfold Equation1021. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff190_inst, reff190_op in H. discriminate H. Qed.

Lemma reff190_not1022 : ~ @Equation1022 Fin3 reff190_inst.
Proof. unfold Equation1022. intro H. specialize (H F3_2 F3_1). unfold magma_op, reff190_inst, reff190_op in H. discriminate H. Qed.

Lemma reff190_not1023 : ~ @Equation1023 Fin3 reff190_inst.
Proof. unfold Equation1023. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff190_inst, reff190_op in H. discriminate H. Qed.

Lemma reff190_not1025 : ~ @Equation1025 Fin3 reff190_inst.
Proof. unfold Equation1025. intro H. specialize (H F3_2 F3_0). unfold magma_op, reff190_inst, reff190_op in H. discriminate H. Qed.

Lemma reff190_not1026 : ~ @Equation1026 Fin3 reff190_inst.
Proof. unfold Equation1026. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff190_inst, reff190_op in H. discriminate H. Qed.

Lemma reff190_not1028 : ~ @Equation1028 Fin3 reff190_inst.
Proof. unfold Equation1028. intro H. specialize (H F3_2 F3_0). unfold magma_op, reff190_inst, reff190_op in H. discriminate H. Qed.

Lemma reff190_not1029 : ~ @Equation1029 Fin3 reff190_inst.
Proof. unfold Equation1029. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff190_inst, reff190_op in H. discriminate H. Qed.

Lemma reff190_not1035 : ~ @Equation1035 Fin3 reff190_inst.
Proof. unfold Equation1035. intro H. specialize (H F3_1 F3_2). unfold magma_op, reff190_inst, reff190_op in H. discriminate H. Qed.

Lemma reff190_not1036 : ~ @Equation1036 Fin3 reff190_inst.
Proof. unfold Equation1036. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff190_inst, reff190_op in H. discriminate H. Qed.

Lemma reff190_not1038 : ~ @Equation1038 Fin3 reff190_inst.
Proof. unfold Equation1038. intro H. specialize (H F3_2 F3_0). unfold magma_op, reff190_inst, reff190_op in H. discriminate H. Qed.

Lemma reff190_not1039 : ~ @Equation1039 Fin3 reff190_inst.
Proof. unfold Equation1039. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff190_inst, reff190_op in H. discriminate H. Qed.

Lemma reff190_not1045 : ~ @Equation1045 Fin3 reff190_inst.
Proof. unfold Equation1045. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff190_inst, reff190_op in H. discriminate H. Qed.

Lemma reff190_not1046 : ~ @Equation1046 Fin3 reff190_inst.
Proof. unfold Equation1046. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff190_inst, reff190_op in H. discriminate H. Qed.

Lemma reff190_not1048 : ~ @Equation1048 Fin3 reff190_inst.
Proof. unfold Equation1048. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff190_inst, reff190_op in H. discriminate H. Qed.

Lemma reff190_not1049 : ~ @Equation1049 Fin3 reff190_inst.
Proof. unfold Equation1049. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff190_inst, reff190_op in H. discriminate H. Qed.

Lemma reff190_not1072 : ~ @Equation1072 Fin3 reff190_inst.
Proof. unfold Equation1072. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff190_inst, reff190_op in H. discriminate H. Qed.

Lemma reff190_not1073 : ~ @Equation1073 Fin3 reff190_inst.
Proof. unfold Equation1073. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff190_inst, reff190_op in H. discriminate H. Qed.

Lemma reff190_not1075 : ~ @Equation1075 Fin3 reff190_inst.
Proof. unfold Equation1075. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff190_inst, reff190_op in H. discriminate H. Qed.

Lemma reff190_not1076 : ~ @Equation1076 Fin3 reff190_inst.
Proof. unfold Equation1076. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff190_inst, reff190_op in H. discriminate H. Qed.

Lemma reff190_not1082 : ~ @Equation1082 Fin3 reff190_inst.
Proof. unfold Equation1082. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff190_inst, reff190_op in H. discriminate H. Qed.

Lemma reff190_not1083 : ~ @Equation1083 Fin3 reff190_inst.
Proof. unfold Equation1083. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff190_inst, reff190_op in H. discriminate H. Qed.

Lemma reff190_not1085 : ~ @Equation1085 Fin3 reff190_inst.
Proof. unfold Equation1085. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff190_inst, reff190_op in H. discriminate H. Qed.

Lemma reff190_not1086 : ~ @Equation1086 Fin3 reff190_inst.
Proof. unfold Equation1086. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff190_inst, reff190_op in H. discriminate H. Qed.

Lemma reff190_not1109 : ~ @Equation1109 Fin3 reff190_inst.
Proof. unfold Equation1109. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff190_inst, reff190_op in H. discriminate H. Qed.

Lemma reff190_not1110 : ~ @Equation1110 Fin3 reff190_inst.
Proof. unfold Equation1110. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff190_inst, reff190_op in H. discriminate H. Qed.

Lemma reff190_not1112 : ~ @Equation1112 Fin3 reff190_inst.
Proof. unfold Equation1112. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff190_inst, reff190_op in H. discriminate H. Qed.

Lemma reff190_not1113 : ~ @Equation1113 Fin3 reff190_inst.
Proof. unfold Equation1113. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff190_inst, reff190_op in H. discriminate H. Qed.

Lemma reff190_not1119 : ~ @Equation1119 Fin3 reff190_inst.
Proof. unfold Equation1119. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff190_inst, reff190_op in H. discriminate H. Qed.

Lemma reff190_not1120 : ~ @Equation1120 Fin3 reff190_inst.
Proof. unfold Equation1120. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff190_inst, reff190_op in H. discriminate H. Qed.

Lemma reff190_not1122 : ~ @Equation1122 Fin3 reff190_inst.
Proof. unfold Equation1122. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff190_inst, reff190_op in H. discriminate H. Qed.

Lemma reff190_not1223 : ~ @Equation1223 Fin3 reff190_inst.
Proof. unfold Equation1223. intro H. specialize (H F3_2). unfold magma_op, reff190_inst, reff190_op in H. discriminate H. Qed.

Lemma reff190_not1426 : ~ @Equation1426 Fin3 reff190_inst.
Proof. unfold Equation1426. intro H. specialize (H F3_2). unfold magma_op, reff190_inst, reff190_op in H. discriminate H. Qed.

Lemma reff190_not1629 : ~ @Equation1629 Fin3 reff190_inst.
Proof. unfold Equation1629. intro H. specialize (H F3_2). unfold magma_op, reff190_inst, reff190_op in H. discriminate H. Qed.

Lemma reff190_not1833 : ~ @Equation1833 Fin3 reff190_inst.
Proof. unfold Equation1833. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff190_inst, reff190_op in H. discriminate H. Qed.

Lemma reff190_not1834 : ~ @Equation1834 Fin3 reff190_inst.
Proof. unfold Equation1834. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff190_inst, reff190_op in H. discriminate H. Qed.

Lemma reff190_not1835 : ~ @Equation1835 Fin3 reff190_inst.
Proof. unfold Equation1835. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff190_inst, reff190_op in H. discriminate H. Qed.

Lemma reff190_not1837 : ~ @Equation1837 Fin3 reff190_inst.
Proof. unfold Equation1837. intro H. specialize (H F3_2 F3_1). unfold magma_op, reff190_inst, reff190_op in H. discriminate H. Qed.

Lemma reff190_not1838 : ~ @Equation1838 Fin3 reff190_inst.
Proof. unfold Equation1838. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff190_inst, reff190_op in H. discriminate H. Qed.

Lemma reff190_not1840 : ~ @Equation1840 Fin3 reff190_inst.
Proof. unfold Equation1840. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff190_inst, reff190_op in H. discriminate H. Qed.

Lemma reff190_not1841 : ~ @Equation1841 Fin3 reff190_inst.
Proof. unfold Equation1841. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff190_inst, reff190_op in H. discriminate H. Qed.

Lemma reff190_not1847 : ~ @Equation1847 Fin3 reff190_inst.
Proof. unfold Equation1847. intro H. specialize (H F3_2 F3_0). unfold magma_op, reff190_inst, reff190_op in H. discriminate H. Qed.

Lemma reff190_not1848 : ~ @Equation1848 Fin3 reff190_inst.
Proof. unfold Equation1848. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff190_inst, reff190_op in H. discriminate H. Qed.

Lemma reff190_not1850 : ~ @Equation1850 Fin3 reff190_inst.
Proof. unfold Equation1850. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff190_inst, reff190_op in H. discriminate H. Qed.

Lemma reff190_not1851 : ~ @Equation1851 Fin3 reff190_inst.
Proof. unfold Equation1851. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff190_inst, reff190_op in H. discriminate H. Qed.

Lemma reff190_not1857 : ~ @Equation1857 Fin3 reff190_inst.
Proof. unfold Equation1857. intro H. specialize (H F3_2 F3_0). unfold magma_op, reff190_inst, reff190_op in H. discriminate H. Qed.

Lemma reff190_not1858 : ~ @Equation1858 Fin3 reff190_inst.
Proof. unfold Equation1858. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff190_inst, reff190_op in H. discriminate H. Qed.

Lemma reff190_not1860 : ~ @Equation1860 Fin3 reff190_inst.
Proof. unfold Equation1860. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff190_inst, reff190_op in H. discriminate H. Qed.

Lemma reff190_not1861 : ~ @Equation1861 Fin3 reff190_inst.
Proof. unfold Equation1861. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff190_inst, reff190_op in H. discriminate H. Qed.

Lemma reff190_not1884 : ~ @Equation1884 Fin3 reff190_inst.
Proof. unfold Equation1884. intro H. specialize (H F3_1 F3_2). unfold magma_op, reff190_inst, reff190_op in H. discriminate H. Qed.

Lemma reff190_not1885 : ~ @Equation1885 Fin3 reff190_inst.
Proof. unfold Equation1885. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff190_inst, reff190_op in H. discriminate H. Qed.

Lemma reff190_not1887 : ~ @Equation1887 Fin3 reff190_inst.
Proof. unfold Equation1887. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff190_inst, reff190_op in H. discriminate H. Qed.

Lemma reff190_not1888 : ~ @Equation1888 Fin3 reff190_inst.
Proof. unfold Equation1888. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff190_inst, reff190_op in H. discriminate H. Qed.

Lemma reff190_not1894 : ~ @Equation1894 Fin3 reff190_inst.
Proof. unfold Equation1894. intro H. specialize (H F3_2 F3_0). unfold magma_op, reff190_inst, reff190_op in H. discriminate H. Qed.

Lemma reff190_not1895 : ~ @Equation1895 Fin3 reff190_inst.
Proof. unfold Equation1895. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff190_inst, reff190_op in H. discriminate H. Qed.

Lemma reff190_not1897 : ~ @Equation1897 Fin3 reff190_inst.
Proof. unfold Equation1897. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff190_inst, reff190_op in H. discriminate H. Qed.

Lemma reff190_not1898 : ~ @Equation1898 Fin3 reff190_inst.
Proof. unfold Equation1898. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff190_inst, reff190_op in H. discriminate H. Qed.

Lemma reff190_not1921 : ~ @Equation1921 Fin3 reff190_inst.
Proof. unfold Equation1921. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff190_inst, reff190_op in H. discriminate H. Qed.

Lemma reff190_not1922 : ~ @Equation1922 Fin3 reff190_inst.
Proof. unfold Equation1922. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff190_inst, reff190_op in H. discriminate H. Qed.

Lemma reff190_not1924 : ~ @Equation1924 Fin3 reff190_inst.
Proof. unfold Equation1924. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff190_inst, reff190_op in H. discriminate H. Qed.

Lemma reff190_not1925 : ~ @Equation1925 Fin3 reff190_inst.
Proof. unfold Equation1925. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff190_inst, reff190_op in H. discriminate H. Qed.

Lemma reff190_not1931 : ~ @Equation1931 Fin3 reff190_inst.
Proof. unfold Equation1931. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff190_inst, reff190_op in H. discriminate H. Qed.

Lemma reff190_not1932 : ~ @Equation1932 Fin3 reff190_inst.
Proof. unfold Equation1932. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff190_inst, reff190_op in H. discriminate H. Qed.

Lemma reff190_not1934 : ~ @Equation1934 Fin3 reff190_inst.
Proof. unfold Equation1934. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff190_inst, reff190_op in H. discriminate H. Qed.

Lemma reff190_not2035 : ~ @Equation2035 Fin3 reff190_inst.
Proof. unfold Equation2035. intro H. specialize (H F3_2). unfold magma_op, reff190_inst, reff190_op in H. discriminate H. Qed.

Lemma reff190_not2238 : ~ @Equation2238 Fin3 reff190_inst.
Proof. unfold Equation2238. intro H. specialize (H F3_2). unfold magma_op, reff190_inst, reff190_op in H. discriminate H. Qed.

Lemma reff190_not2441 : ~ @Equation2441 Fin3 reff190_inst.
Proof. unfold Equation2441. intro H. specialize (H F3_2). unfold magma_op, reff190_inst, reff190_op in H. discriminate H. Qed.

Lemma reff190_not2644 : ~ @Equation2644 Fin3 reff190_inst.
Proof. unfold Equation2644. intro H. specialize (H F3_2). unfold magma_op, reff190_inst, reff190_op in H. discriminate H. Qed.

Lemma reff190_not2847 : ~ @Equation2847 Fin3 reff190_inst.
Proof. unfold Equation2847. intro H. specialize (H F3_2). unfold magma_op, reff190_inst, reff190_op in H. discriminate H. Qed.

Lemma reff190_not3050 : ~ @Equation3050 Fin3 reff190_inst.
Proof. unfold Equation3050. intro H. specialize (H F3_2). unfold magma_op, reff190_inst, reff190_op in H. discriminate H. Qed.

Lemma reff190_not3254 : ~ @Equation3254 Fin3 reff190_inst.
Proof. unfold Equation3254. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff190_inst, reff190_op in H. discriminate H. Qed.

Lemma reff190_not3255 : ~ @Equation3255 Fin3 reff190_inst.
Proof. unfold Equation3255. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff190_inst, reff190_op in H. discriminate H. Qed.

Lemma reff190_not3256 : ~ @Equation3256 Fin3 reff190_inst.
Proof. unfold Equation3256. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff190_inst, reff190_op in H. discriminate H. Qed.

Lemma reff190_not3258 : ~ @Equation3258 Fin3 reff190_inst.
Proof. unfold Equation3258. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff190_inst, reff190_op in H. discriminate H. Qed.

Lemma reff190_not3259 : ~ @Equation3259 Fin3 reff190_inst.
Proof. unfold Equation3259. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff190_inst, reff190_op in H. discriminate H. Qed.

Lemma reff190_not3262 : ~ @Equation3262 Fin3 reff190_inst.
Proof. unfold Equation3262. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff190_inst, reff190_op in H. discriminate H. Qed.

Lemma reff190_not3268 : ~ @Equation3268 Fin3 reff190_inst.
Proof. unfold Equation3268. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff190_inst, reff190_op in H. discriminate H. Qed.

Lemma reff190_not3269 : ~ @Equation3269 Fin3 reff190_inst.
Proof. unfold Equation3269. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff190_inst, reff190_op in H. discriminate H. Qed.

Lemma reff190_not3271 : ~ @Equation3271 Fin3 reff190_inst.
Proof. unfold Equation3271. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff190_inst, reff190_op in H. discriminate H. Qed.

Lemma reff190_not3272 : ~ @Equation3272 Fin3 reff190_inst.
Proof. unfold Equation3272. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff190_inst, reff190_op in H. discriminate H. Qed.

Lemma reff190_not3278 : ~ @Equation3278 Fin3 reff190_inst.
Proof. unfold Equation3278. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff190_inst, reff190_op in H. discriminate H. Qed.

Lemma reff190_not3279 : ~ @Equation3279 Fin3 reff190_inst.
Proof. unfold Equation3279. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff190_inst, reff190_op in H. discriminate H. Qed.

Lemma reff190_not3281 : ~ @Equation3281 Fin3 reff190_inst.
Proof. unfold Equation3281. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff190_inst, reff190_op in H. discriminate H. Qed.

Lemma reff190_not3308 : ~ @Equation3308 Fin3 reff190_inst.
Proof. unfold Equation3308. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff190_inst, reff190_op in H. discriminate H. Qed.

Lemma reff190_not3309 : ~ @Equation3309 Fin3 reff190_inst.
Proof. unfold Equation3309. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff190_inst, reff190_op in H. discriminate H. Qed.

Lemma reff190_not3315 : ~ @Equation3315 Fin3 reff190_inst.
Proof. unfold Equation3315. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff190_inst, reff190_op in H. discriminate H. Qed.

Lemma reff190_not3316 : ~ @Equation3316 Fin3 reff190_inst.
Proof. unfold Equation3316. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff190_inst, reff190_op in H. discriminate H. Qed.

Lemma reff190_not3318 : ~ @Equation3318 Fin3 reff190_inst.
Proof. unfold Equation3318. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff190_inst, reff190_op in H. discriminate H. Qed.

Lemma reff190_not3342 : ~ @Equation3342 Fin3 reff190_inst.
Proof. unfold Equation3342. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff190_inst, reff190_op in H. discriminate H. Qed.

Lemma reff190_not3343 : ~ @Equation3343 Fin3 reff190_inst.
Proof. unfold Equation3343. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff190_inst, reff190_op in H. discriminate H. Qed.

Lemma reff190_not3345 : ~ @Equation3345 Fin3 reff190_inst.
Proof. unfold Equation3345. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff190_inst, reff190_op in H. discriminate H. Qed.

Lemma reff190_not3346 : ~ @Equation3346 Fin3 reff190_inst.
Proof. unfold Equation3346. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff190_inst, reff190_op in H. discriminate H. Qed.

Lemma reff190_not3352 : ~ @Equation3352 Fin3 reff190_inst.
Proof. unfold Equation3352. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff190_inst, reff190_op in H. discriminate H. Qed.

Lemma reff190_not3353 : ~ @Equation3353 Fin3 reff190_inst.
Proof. unfold Equation3353. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff190_inst, reff190_op in H. discriminate H. Qed.

Lemma reff190_not3457 : ~ @Equation3457 Fin3 reff190_inst.
Proof. unfold Equation3457. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff190_inst, reff190_op in H. discriminate H. Qed.

Lemma reff190_not3458 : ~ @Equation3458 Fin3 reff190_inst.
Proof. unfold Equation3458. intro H. specialize (H F3_2 F3_1). unfold magma_op, reff190_inst, reff190_op in H. discriminate H. Qed.

Lemma reff190_not3459 : ~ @Equation3459 Fin3 reff190_inst.
Proof. unfold Equation3459. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff190_inst, reff190_op in H. discriminate H. Qed.

Lemma reff190_not3461 : ~ @Equation3461 Fin3 reff190_inst.
Proof. unfold Equation3461. intro H. specialize (H F3_1 F3_2). unfold magma_op, reff190_inst, reff190_op in H. discriminate H. Qed.

Lemma reff190_not3462 : ~ @Equation3462 Fin3 reff190_inst.
Proof. unfold Equation3462. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff190_inst, reff190_op in H. discriminate H. Qed.

Lemma reff190_not3465 : ~ @Equation3465 Fin3 reff190_inst.
Proof. unfold Equation3465. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff190_inst, reff190_op in H. discriminate H. Qed.

Lemma reff190_not3472 : ~ @Equation3472 Fin3 reff190_inst.
Proof. unfold Equation3472. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff190_inst, reff190_op in H. discriminate H. Qed.

Lemma reff190_not3474 : ~ @Equation3474 Fin3 reff190_inst.
Proof. unfold Equation3474. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff190_inst, reff190_op in H. discriminate H. Qed.

Lemma reff190_not3475 : ~ @Equation3475 Fin3 reff190_inst.
Proof. unfold Equation3475. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff190_inst, reff190_op in H. discriminate H. Qed.

Lemma reff190_not3481 : ~ @Equation3481 Fin3 reff190_inst.
Proof. unfold Equation3481. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff190_inst, reff190_op in H. discriminate H. Qed.

Lemma reff190_not3482 : ~ @Equation3482 Fin3 reff190_inst.
Proof. unfold Equation3482. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff190_inst, reff190_op in H. discriminate H. Qed.

Lemma reff190_not3484 : ~ @Equation3484 Fin3 reff190_inst.
Proof. unfold Equation3484. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff190_inst, reff190_op in H. discriminate H. Qed.

Lemma reff190_not3511 : ~ @Equation3511 Fin3 reff190_inst.
Proof. unfold Equation3511. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff190_inst, reff190_op in H. discriminate H. Qed.

Lemma reff190_not3512 : ~ @Equation3512 Fin3 reff190_inst.
Proof. unfold Equation3512. intro H. specialize (H F3_2 F3_1). unfold magma_op, reff190_inst, reff190_op in H. discriminate H. Qed.

Lemma reff190_not3518 : ~ @Equation3518 Fin3 reff190_inst.
Proof. unfold Equation3518. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff190_inst, reff190_op in H. discriminate H. Qed.

Lemma reff190_not3519 : ~ @Equation3519 Fin3 reff190_inst.
Proof. unfold Equation3519. intro H. specialize (H F3_1 F3_2). unfold magma_op, reff190_inst, reff190_op in H. discriminate H. Qed.

Lemma reff190_not3521 : ~ @Equation3521 Fin3 reff190_inst.
Proof. unfold Equation3521. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff190_inst, reff190_op in H. discriminate H. Qed.

Lemma reff190_not3545 : ~ @Equation3545 Fin3 reff190_inst.
Proof. unfold Equation3545. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff190_inst, reff190_op in H. discriminate H. Qed.

Lemma reff190_not3546 : ~ @Equation3546 Fin3 reff190_inst.
Proof. unfold Equation3546. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff190_inst, reff190_op in H. discriminate H. Qed.

Lemma reff190_not3548 : ~ @Equation3548 Fin3 reff190_inst.
Proof. unfold Equation3548. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff190_inst, reff190_op in H. discriminate H. Qed.

Lemma reff190_not3549 : ~ @Equation3549 Fin3 reff190_inst.
Proof. unfold Equation3549. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff190_inst, reff190_op in H. discriminate H. Qed.

Lemma reff190_not3555 : ~ @Equation3555 Fin3 reff190_inst.
Proof. unfold Equation3555. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff190_inst, reff190_op in H. discriminate H. Qed.

Lemma reff190_not3558 : ~ @Equation3558 Fin3 reff190_inst.
Proof. unfold Equation3558. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff190_inst, reff190_op in H. discriminate H. Qed.

Lemma reff190_not3660 : ~ @Equation3660 Fin3 reff190_inst.
Proof. unfold Equation3660. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff190_inst, reff190_op in H. discriminate H. Qed.

Lemma reff190_not3661 : ~ @Equation3661 Fin3 reff190_inst.
Proof. unfold Equation3661. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff190_inst, reff190_op in H. discriminate H. Qed.

Lemma reff190_not3662 : ~ @Equation3662 Fin3 reff190_inst.
Proof. unfold Equation3662. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff190_inst, reff190_op in H. discriminate H. Qed.

Lemma reff190_not3664 : ~ @Equation3664 Fin3 reff190_inst.
Proof. unfold Equation3664. intro H. specialize (H F3_2 F3_1). unfold magma_op, reff190_inst, reff190_op in H. discriminate H. Qed.

Lemma reff190_not3665 : ~ @Equation3665 Fin3 reff190_inst.
Proof. unfold Equation3665. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff190_inst, reff190_op in H. discriminate H. Qed.

Lemma reff190_not3667 : ~ @Equation3667 Fin3 reff190_inst.
Proof. unfold Equation3667. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff190_inst, reff190_op in H. discriminate H. Qed.

Lemma reff190_not3668 : ~ @Equation3668 Fin3 reff190_inst.
Proof. unfold Equation3668. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff190_inst, reff190_op in H. discriminate H. Qed.

Lemma reff190_not3674 : ~ @Equation3674 Fin3 reff190_inst.
Proof. unfold Equation3674. intro H. specialize (H F3_1 F3_2). unfold magma_op, reff190_inst, reff190_op in H. discriminate H. Qed.

Lemma reff190_not3675 : ~ @Equation3675 Fin3 reff190_inst.
Proof. unfold Equation3675. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff190_inst, reff190_op in H. discriminate H. Qed.

Lemma reff190_not3677 : ~ @Equation3677 Fin3 reff190_inst.
Proof. unfold Equation3677. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff190_inst, reff190_op in H. discriminate H. Qed.

Lemma reff190_not3678 : ~ @Equation3678 Fin3 reff190_inst.
Proof. unfold Equation3678. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff190_inst, reff190_op in H. discriminate H. Qed.

Lemma reff190_not3685 : ~ @Equation3685 Fin3 reff190_inst.
Proof. unfold Equation3685. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff190_inst, reff190_op in H. discriminate H. Qed.

Lemma reff190_not3687 : ~ @Equation3687 Fin3 reff190_inst.
Proof. unfold Equation3687. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff190_inst, reff190_op in H. discriminate H. Qed.

Lemma reff190_not3712 : ~ @Equation3712 Fin3 reff190_inst.
Proof. unfold Equation3712. intro H. specialize (H F3_2 F3_1). unfold magma_op, reff190_inst, reff190_op in H. discriminate H. Qed.

Lemma reff190_not3714 : ~ @Equation3714 Fin3 reff190_inst.
Proof. unfold Equation3714. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff190_inst, reff190_op in H. discriminate H. Qed.

Lemma reff190_not3721 : ~ @Equation3721 Fin3 reff190_inst.
Proof. unfold Equation3721. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff190_inst, reff190_op in H. discriminate H. Qed.

Lemma reff190_not3722 : ~ @Equation3722 Fin3 reff190_inst.
Proof. unfold Equation3722. intro H. specialize (H F3_2 F3_1). unfold magma_op, reff190_inst, reff190_op in H. discriminate H. Qed.

Lemma reff190_not3724 : ~ @Equation3724 Fin3 reff190_inst.
Proof. unfold Equation3724. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff190_inst, reff190_op in H. discriminate H. Qed.

Lemma reff190_not3725 : ~ @Equation3725 Fin3 reff190_inst.
Proof. unfold Equation3725. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff190_inst, reff190_op in H. discriminate H. Qed.

Lemma reff190_not3748 : ~ @Equation3748 Fin3 reff190_inst.
Proof. unfold Equation3748. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff190_inst, reff190_op in H. discriminate H. Qed.

Lemma reff190_not3749 : ~ @Equation3749 Fin3 reff190_inst.
Proof. unfold Equation3749. intro H. specialize (H F3_1 F3_2). unfold magma_op, reff190_inst, reff190_op in H. discriminate H. Qed.

Lemma reff190_not3751 : ~ @Equation3751 Fin3 reff190_inst.
Proof. unfold Equation3751. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff190_inst, reff190_op in H. discriminate H. Qed.

Lemma reff190_not3752 : ~ @Equation3752 Fin3 reff190_inst.
Proof. unfold Equation3752. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff190_inst, reff190_op in H. discriminate H. Qed.

Lemma reff190_not3759 : ~ @Equation3759 Fin3 reff190_inst.
Proof. unfold Equation3759. intro H. specialize (H F3_2 F3_1). unfold magma_op, reff190_inst, reff190_op in H. discriminate H. Qed.

Lemma reff190_not3761 : ~ @Equation3761 Fin3 reff190_inst.
Proof. unfold Equation3761. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff190_inst, reff190_op in H. discriminate H. Qed.

Lemma reff190_not3864 : ~ @Equation3864 Fin3 reff190_inst.
Proof. unfold Equation3864. intro H. specialize (H F3_2 F3_1). unfold magma_op, reff190_inst, reff190_op in H. discriminate H. Qed.

Lemma reff190_not3865 : ~ @Equation3865 Fin3 reff190_inst.
Proof. unfold Equation3865. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff190_inst, reff190_op in H. discriminate H. Qed.

Lemma reff190_not3867 : ~ @Equation3867 Fin3 reff190_inst.
Proof. unfold Equation3867. intro H. specialize (H F3_2 F3_0). unfold magma_op, reff190_inst, reff190_op in H. discriminate H. Qed.

Lemma reff190_not3868 : ~ @Equation3868 Fin3 reff190_inst.
Proof. unfold Equation3868. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff190_inst, reff190_op in H. discriminate H. Qed.

Lemma reff190_not3870 : ~ @Equation3870 Fin3 reff190_inst.
Proof. unfold Equation3870. intro H. specialize (H F3_2 F3_0). unfold magma_op, reff190_inst, reff190_op in H. discriminate H. Qed.

Lemma reff190_not3871 : ~ @Equation3871 Fin3 reff190_inst.
Proof. unfold Equation3871. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff190_inst, reff190_op in H. discriminate H. Qed.

Lemma reff190_not3877 : ~ @Equation3877 Fin3 reff190_inst.
Proof. unfold Equation3877. intro H. specialize (H F3_1 F3_2). unfold magma_op, reff190_inst, reff190_op in H. discriminate H. Qed.

Lemma reff190_not3878 : ~ @Equation3878 Fin3 reff190_inst.
Proof. unfold Equation3878. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff190_inst, reff190_op in H. discriminate H. Qed.

Lemma reff190_not3880 : ~ @Equation3880 Fin3 reff190_inst.
Proof. unfold Equation3880. intro H. specialize (H F3_2 F3_0). unfold magma_op, reff190_inst, reff190_op in H. discriminate H. Qed.

Lemma reff190_not3881 : ~ @Equation3881 Fin3 reff190_inst.
Proof. unfold Equation3881. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff190_inst, reff190_op in H. discriminate H. Qed.

Lemma reff190_not3887 : ~ @Equation3887 Fin3 reff190_inst.
Proof. unfold Equation3887. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff190_inst, reff190_op in H. discriminate H. Qed.

Lemma reff190_not3888 : ~ @Equation3888 Fin3 reff190_inst.
Proof. unfold Equation3888. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff190_inst, reff190_op in H. discriminate H. Qed.

Lemma reff190_not3890 : ~ @Equation3890 Fin3 reff190_inst.
Proof. unfold Equation3890. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff190_inst, reff190_op in H. discriminate H. Qed.

Lemma reff190_not3917 : ~ @Equation3917 Fin3 reff190_inst.
Proof. unfold Equation3917. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff190_inst, reff190_op in H. discriminate H. Qed.

Lemma reff190_not3918 : ~ @Equation3918 Fin3 reff190_inst.
Proof. unfold Equation3918. intro H. specialize (H F3_2 F3_1). unfold magma_op, reff190_inst, reff190_op in H. discriminate H. Qed.

Lemma reff190_not3924 : ~ @Equation3924 Fin3 reff190_inst.
Proof. unfold Equation3924. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff190_inst, reff190_op in H. discriminate H. Qed.

Lemma reff190_not3925 : ~ @Equation3925 Fin3 reff190_inst.
Proof. unfold Equation3925. intro H. specialize (H F3_2 F3_0). unfold magma_op, reff190_inst, reff190_op in H. discriminate H. Qed.

Lemma reff190_not3927 : ~ @Equation3927 Fin3 reff190_inst.
Proof. unfold Equation3927. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff190_inst, reff190_op in H. discriminate H. Qed.

Lemma reff190_not3928 : ~ @Equation3928 Fin3 reff190_inst.
Proof. unfold Equation3928. intro H. specialize (H F3_2 F3_0). unfold magma_op, reff190_inst, reff190_op in H. discriminate H. Qed.

Lemma reff190_not3951 : ~ @Equation3951 Fin3 reff190_inst.
Proof. unfold Equation3951. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff190_inst, reff190_op in H. discriminate H. Qed.

Lemma reff190_not3952 : ~ @Equation3952 Fin3 reff190_inst.
Proof. unfold Equation3952. intro H. specialize (H F3_1 F3_2). unfold magma_op, reff190_inst, reff190_op in H. discriminate H. Qed.

Lemma reff190_not3954 : ~ @Equation3954 Fin3 reff190_inst.
Proof. unfold Equation3954. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff190_inst, reff190_op in H. discriminate H. Qed.

Lemma reff190_not3955 : ~ @Equation3955 Fin3 reff190_inst.
Proof. unfold Equation3955. intro H. specialize (H F3_2 F3_0). unfold magma_op, reff190_inst, reff190_op in H. discriminate H. Qed.

Lemma reff190_not3961 : ~ @Equation3961 Fin3 reff190_inst.
Proof. unfold Equation3961. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff190_inst, reff190_op in H. discriminate H. Qed.

Lemma reff190_not3962 : ~ @Equation3962 Fin3 reff190_inst.
Proof. unfold Equation3962. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff190_inst, reff190_op in H. discriminate H. Qed.

Lemma reff190_not3964 : ~ @Equation3964 Fin3 reff190_inst.
Proof. unfold Equation3964. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff190_inst, reff190_op in H. discriminate H. Qed.

Lemma reff190_not4065 : ~ @Equation4065 Fin3 reff190_inst.
Proof. unfold Equation4065. intro H. specialize (H F3_2). unfold magma_op, reff190_inst, reff190_op in H. discriminate H. Qed.

Lemma reff190_not4268 : ~ @Equation4268 Fin3 reff190_inst.
Proof. unfold Equation4268. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff190_inst, reff190_op in H. discriminate H. Qed.

Lemma reff190_not4269 : ~ @Equation4269 Fin3 reff190_inst.
Proof. unfold Equation4269. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff190_inst, reff190_op in H. discriminate H. Qed.

Lemma reff190_not4270 : ~ @Equation4270 Fin3 reff190_inst.
Proof. unfold Equation4270. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff190_inst, reff190_op in H. discriminate H. Qed.

Lemma reff190_not4272 : ~ @Equation4272 Fin3 reff190_inst.
Proof. unfold Equation4272. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff190_inst, reff190_op in H. discriminate H. Qed.

Lemma reff190_not4273 : ~ @Equation4273 Fin3 reff190_inst.
Proof. unfold Equation4273. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff190_inst, reff190_op in H. discriminate H. Qed.

Lemma reff190_not4275 : ~ @Equation4275 Fin3 reff190_inst.
Proof. unfold Equation4275. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff190_inst, reff190_op in H. discriminate H. Qed.

Lemma reff190_not4276 : ~ @Equation4276 Fin3 reff190_inst.
Proof. unfold Equation4276. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff190_inst, reff190_op in H. discriminate H. Qed.

Lemma reff190_not4283 : ~ @Equation4283 Fin3 reff190_inst.
Proof. unfold Equation4283. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff190_inst, reff190_op in H. discriminate H. Qed.

Lemma reff190_not4284 : ~ @Equation4284 Fin3 reff190_inst.
Proof. unfold Equation4284. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff190_inst, reff190_op in H. discriminate H. Qed.

Lemma reff190_not4290 : ~ @Equation4290 Fin3 reff190_inst.
Proof. unfold Equation4290. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff190_inst, reff190_op in H. discriminate H. Qed.

Lemma reff190_not4291 : ~ @Equation4291 Fin3 reff190_inst.
Proof. unfold Equation4291. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff190_inst, reff190_op in H. discriminate H. Qed.

Lemma reff190_not4293 : ~ @Equation4293 Fin3 reff190_inst.
Proof. unfold Equation4293. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff190_inst, reff190_op in H. discriminate H. Qed.

Lemma reff190_not4314 : ~ @Equation4314 Fin3 reff190_inst.
Proof. unfold Equation4314. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff190_inst, reff190_op in H. discriminate H. Qed.

Lemma reff190_not4320 : ~ @Equation4320 Fin3 reff190_inst.
Proof. unfold Equation4320. intro H. specialize (H F3_1 F3_2). unfold magma_op, reff190_inst, reff190_op in H. discriminate H. Qed.

Lemma reff190_not4321 : ~ @Equation4321 Fin3 reff190_inst.
Proof. unfold Equation4321. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff190_inst, reff190_op in H. discriminate H. Qed.

Lemma reff190_not4343 : ~ @Equation4343 Fin3 reff190_inst.
Proof. unfold Equation4343. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff190_inst, reff190_op in H. discriminate H. Qed.

Lemma reff190_not4380 : ~ @Equation4380 Fin3 reff190_inst.
Proof. unfold Equation4380. intro H. specialize (H F3_2). unfold magma_op, reff190_inst, reff190_op in H. discriminate H. Qed.

Lemma reff190_not4583 : ~ @Equation4583 Fin3 reff190_inst.
Proof. unfold Equation4583. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff190_inst, reff190_op in H. discriminate H. Qed.

Lemma reff190_not4584 : ~ @Equation4584 Fin3 reff190_inst.
Proof. unfold Equation4584. intro H. specialize (H F3_2 F3_1). unfold magma_op, reff190_inst, reff190_op in H. discriminate H. Qed.

Lemma reff190_not4585 : ~ @Equation4585 Fin3 reff190_inst.
Proof. unfold Equation4585. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff190_inst, reff190_op in H. discriminate H. Qed.

Lemma reff190_not4587 : ~ @Equation4587 Fin3 reff190_inst.
Proof. unfold Equation4587. intro H. specialize (H F3_1 F3_2). unfold magma_op, reff190_inst, reff190_op in H. discriminate H. Qed.

Lemma reff190_not4588 : ~ @Equation4588 Fin3 reff190_inst.
Proof. unfold Equation4588. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff190_inst, reff190_op in H. discriminate H. Qed.

Lemma reff190_not4591 : ~ @Equation4591 Fin3 reff190_inst.
Proof. unfold Equation4591. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff190_inst, reff190_op in H. discriminate H. Qed.

Lemma reff190_not4598 : ~ @Equation4598 Fin3 reff190_inst.
Proof. unfold Equation4598. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff190_inst, reff190_op in H. discriminate H. Qed.

Lemma reff190_not4599 : ~ @Equation4599 Fin3 reff190_inst.
Proof. unfold Equation4599. intro H. specialize (H F3_2 F3_1). unfold magma_op, reff190_inst, reff190_op in H. discriminate H. Qed.

Lemma reff190_not4605 : ~ @Equation4605 Fin3 reff190_inst.
Proof. unfold Equation4605. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff190_inst, reff190_op in H. discriminate H. Qed.

Lemma reff190_not4606 : ~ @Equation4606 Fin3 reff190_inst.
Proof. unfold Equation4606. intro H. specialize (H F3_1 F3_2). unfold magma_op, reff190_inst, reff190_op in H. discriminate H. Qed.

Lemma reff190_not4608 : ~ @Equation4608 Fin3 reff190_inst.
Proof. unfold Equation4608. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff190_inst, reff190_op in H. discriminate H. Qed.

Lemma reff190_not4629 : ~ @Equation4629 Fin3 reff190_inst.
Proof. unfold Equation4629. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff190_inst, reff190_op in H. discriminate H. Qed.

Lemma reff190_not4635 : ~ @Equation4635 Fin3 reff190_inst.
Proof. unfold Equation4635. intro H. specialize (H F3_1 F3_2). unfold magma_op, reff190_inst, reff190_op in H. discriminate H. Qed.

Lemma reff190_not4636 : ~ @Equation4636 Fin3 reff190_inst.
Proof. unfold Equation4636. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff190_inst, reff190_op in H. discriminate H. Qed.

Lemma reff190_not4658 : ~ @Equation4658 Fin3 reff190_inst.
Proof. unfold Equation4658. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff190_inst, reff190_op in H. discriminate H. Qed.

(** ---- reff194 (Fin4) ---- *)

Definition reff194_op (x y : Fin4) : Fin4 :=
  match x, y with
  | F4_0, F4_0 => F4_0 | F4_0, F4_1 => F4_0 | F4_0, F4_2 => F4_0 | F4_0, F4_3 => F4_0
  | F4_1, F4_0 => F4_3 | F4_1, F4_1 => F4_0 | F4_1, F4_2 => F4_1 | F4_1, F4_3 => F4_2
  | F4_2, F4_0 => F4_0 | F4_2, F4_1 => F4_2 | F4_2, F4_2 => F4_0 | F4_2, F4_3 => F4_2
  | F4_3, F4_0 => F4_3 | F4_3, F4_1 => F4_2 | F4_3, F4_2 => F4_1 | F4_3, F4_3 => F4_0
  end.

#[local] Instance reff194_inst : Magma Fin4 := {| magma_op := reff194_op |}.

Lemma reff194_sat368 : @Equation368 Fin4 reff194_inst.
Proof. unfold Equation368, magma_op, reff194_inst, reff194_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff194_sat378 : @Equation378 Fin4 reff194_inst.
Proof. unfold Equation378, magma_op, reff194_inst, reff194_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff194_not47 : ~ @Equation47 Fin4 reff194_inst.
Proof. unfold Equation47. intro H. specialize (H F4_1). unfold magma_op, reff194_inst, reff194_op in H. discriminate H. Qed.

Lemma reff194_not99 : ~ @Equation99 Fin4 reff194_inst.
Proof. unfold Equation99. intro H. specialize (H F4_1). unfold magma_op, reff194_inst, reff194_op in H. discriminate H. Qed.

Lemma reff194_not151 : ~ @Equation151 Fin4 reff194_inst.
Proof. unfold Equation151. intro H. specialize (H F4_1). unfold magma_op, reff194_inst, reff194_op in H. discriminate H. Qed.

Lemma reff194_not203 : ~ @Equation203 Fin4 reff194_inst.
Proof. unfold Equation203. intro H. specialize (H F4_1). unfold magma_op, reff194_inst, reff194_op in H. discriminate H. Qed.

Lemma reff194_not255 : ~ @Equation255 Fin4 reff194_inst.
Proof. unfold Equation255. intro H. specialize (H F4_1). unfold magma_op, reff194_inst, reff194_op in H. discriminate H. Qed.

Lemma reff194_not411 : ~ @Equation411 Fin4 reff194_inst.
Proof. unfold Equation411. intro H. specialize (H F4_2). unfold magma_op, reff194_inst, reff194_op in H. discriminate H. Qed.

Lemma reff194_not614 : ~ @Equation614 Fin4 reff194_inst.
Proof. unfold Equation614. intro H. specialize (H F4_1). unfold magma_op, reff194_inst, reff194_op in H. discriminate H. Qed.

Lemma reff194_not817 : ~ @Equation817 Fin4 reff194_inst.
Proof. unfold Equation817. intro H. specialize (H F4_1). unfold magma_op, reff194_inst, reff194_op in H. discriminate H. Qed.

Lemma reff194_not1020 : ~ @Equation1020 Fin4 reff194_inst.
Proof. unfold Equation1020. intro H. specialize (H F4_2). unfold magma_op, reff194_inst, reff194_op in H. discriminate H. Qed.

Lemma reff194_not1223 : ~ @Equation1223 Fin4 reff194_inst.
Proof. unfold Equation1223. intro H. specialize (H F4_1). unfold magma_op, reff194_inst, reff194_op in H. discriminate H. Qed.

Lemma reff194_not1426 : ~ @Equation1426 Fin4 reff194_inst.
Proof. unfold Equation1426. intro H. specialize (H F4_1). unfold magma_op, reff194_inst, reff194_op in H. discriminate H. Qed.

Lemma reff194_not1629 : ~ @Equation1629 Fin4 reff194_inst.
Proof. unfold Equation1629. intro H. specialize (H F4_1). unfold magma_op, reff194_inst, reff194_op in H. discriminate H. Qed.

Lemma reff194_not1832 : ~ @Equation1832 Fin4 reff194_inst.
Proof. unfold Equation1832. intro H. specialize (H F4_1). unfold magma_op, reff194_inst, reff194_op in H. discriminate H. Qed.

Lemma reff194_not2035 : ~ @Equation2035 Fin4 reff194_inst.
Proof. unfold Equation2035. intro H. specialize (H F4_1). unfold magma_op, reff194_inst, reff194_op in H. discriminate H. Qed.

Lemma reff194_not2238 : ~ @Equation2238 Fin4 reff194_inst.
Proof. unfold Equation2238. intro H. specialize (H F4_1). unfold magma_op, reff194_inst, reff194_op in H. discriminate H. Qed.

Lemma reff194_not2441 : ~ @Equation2441 Fin4 reff194_inst.
Proof. unfold Equation2441. intro H. specialize (H F4_1). unfold magma_op, reff194_inst, reff194_op in H. discriminate H. Qed.

Lemma reff194_not2644 : ~ @Equation2644 Fin4 reff194_inst.
Proof. unfold Equation2644. intro H. specialize (H F4_1). unfold magma_op, reff194_inst, reff194_op in H. discriminate H. Qed.

Lemma reff194_not2847 : ~ @Equation2847 Fin4 reff194_inst.
Proof. unfold Equation2847. intro H. specialize (H F4_1). unfold magma_op, reff194_inst, reff194_op in H. discriminate H. Qed.

Lemma reff194_not3050 : ~ @Equation3050 Fin4 reff194_inst.
Proof. unfold Equation3050. intro H. specialize (H F4_1). unfold magma_op, reff194_inst, reff194_op in H. discriminate H. Qed.

Lemma reff194_not3253 : ~ @Equation3253 Fin4 reff194_inst.
Proof. unfold Equation3253. intro H. specialize (H F4_1). unfold magma_op, reff194_inst, reff194_op in H. discriminate H. Qed.

Lemma reff194_not3456 : ~ @Equation3456 Fin4 reff194_inst.
Proof. unfold Equation3456. intro H. specialize (H F4_1). unfold magma_op, reff194_inst, reff194_op in H. discriminate H. Qed.

Lemma reff194_not3664 : ~ @Equation3664 Fin4 reff194_inst.
Proof. unfold Equation3664. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff194_inst, reff194_op in H. discriminate H. Qed.

Lemma reff194_not3667 : ~ @Equation3667 Fin4 reff194_inst.
Proof. unfold Equation3667. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff194_inst, reff194_op in H. discriminate H. Qed.

Lemma reff194_not3668 : ~ @Equation3668 Fin4 reff194_inst.
Proof. unfold Equation3668. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff194_inst, reff194_op in H. discriminate H. Qed.

Lemma reff194_not3674 : ~ @Equation3674 Fin4 reff194_inst.
Proof. unfold Equation3674. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff194_inst, reff194_op in H. discriminate H. Qed.

Lemma reff194_not3675 : ~ @Equation3675 Fin4 reff194_inst.
Proof. unfold Equation3675. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff194_inst, reff194_op in H. discriminate H. Qed.

Lemma reff194_not3678 : ~ @Equation3678 Fin4 reff194_inst.
Proof. unfold Equation3678. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff194_inst, reff194_op in H. discriminate H. Qed.

Lemma reff194_not3712 : ~ @Equation3712 Fin4 reff194_inst.
Proof. unfold Equation3712. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff194_inst, reff194_op in H. discriminate H. Qed.

Lemma reff194_not3714 : ~ @Equation3714 Fin4 reff194_inst.
Proof. unfold Equation3714. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff194_inst, reff194_op in H. discriminate H. Qed.

Lemma reff194_not3721 : ~ @Equation3721 Fin4 reff194_inst.
Proof. unfold Equation3721. intro H. specialize (H F4_1 F4_2). unfold magma_op, reff194_inst, reff194_op in H. discriminate H. Qed.

Lemma reff194_not3722 : ~ @Equation3722 Fin4 reff194_inst.
Proof. unfold Equation3722. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff194_inst, reff194_op in H. discriminate H. Qed.

Lemma reff194_not3724 : ~ @Equation3724 Fin4 reff194_inst.
Proof. unfold Equation3724. intro H. specialize (H F4_1 F4_3). unfold magma_op, reff194_inst, reff194_op in H. discriminate H. Qed.

Lemma reff194_not3725 : ~ @Equation3725 Fin4 reff194_inst.
Proof. unfold Equation3725. intro H. specialize (H F4_1 F4_2). unfold magma_op, reff194_inst, reff194_op in H. discriminate H. Qed.

Lemma reff194_not3748 : ~ @Equation3748 Fin4 reff194_inst.
Proof. unfold Equation3748. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff194_inst, reff194_op in H. discriminate H. Qed.

Lemma reff194_not3749 : ~ @Equation3749 Fin4 reff194_inst.
Proof. unfold Equation3749. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff194_inst, reff194_op in H. discriminate H. Qed.

Lemma reff194_not3751 : ~ @Equation3751 Fin4 reff194_inst.
Proof. unfold Equation3751. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff194_inst, reff194_op in H. discriminate H. Qed.

Lemma reff194_not3752 : ~ @Equation3752 Fin4 reff194_inst.
Proof. unfold Equation3752. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff194_inst, reff194_op in H. discriminate H. Qed.

Lemma reff194_not3759 : ~ @Equation3759 Fin4 reff194_inst.
Proof. unfold Equation3759. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff194_inst, reff194_op in H. discriminate H. Qed.

Lemma reff194_not3761 : ~ @Equation3761 Fin4 reff194_inst.
Proof. unfold Equation3761. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff194_inst, reff194_op in H. discriminate H. Qed.

Lemma reff194_not3862 : ~ @Equation3862 Fin4 reff194_inst.
Proof. unfold Equation3862. intro H. specialize (H F4_1). unfold magma_op, reff194_inst, reff194_op in H. discriminate H. Qed.

Lemma reff194_not4070 : ~ @Equation4070 Fin4 reff194_inst.
Proof. unfold Equation4070. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff194_inst, reff194_op in H. discriminate H. Qed.

Lemma reff194_not4071 : ~ @Equation4071 Fin4 reff194_inst.
Proof. unfold Equation4071. intro H. specialize (H F4_1 F4_3). unfold magma_op, reff194_inst, reff194_op in H. discriminate H. Qed.

Lemma reff194_not4073 : ~ @Equation4073 Fin4 reff194_inst.
Proof. unfold Equation4073. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff194_inst, reff194_op in H. discriminate H. Qed.

Lemma reff194_not4074 : ~ @Equation4074 Fin4 reff194_inst.
Proof. unfold Equation4074. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff194_inst, reff194_op in H. discriminate H. Qed.

Lemma reff194_not4080 : ~ @Equation4080 Fin4 reff194_inst.
Proof. unfold Equation4080. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff194_inst, reff194_op in H. discriminate H. Qed.

Lemma reff194_not4081 : ~ @Equation4081 Fin4 reff194_inst.
Proof. unfold Equation4081. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff194_inst, reff194_op in H. discriminate H. Qed.

Lemma reff194_not4083 : ~ @Equation4083 Fin4 reff194_inst.
Proof. unfold Equation4083. intro H. specialize (H F4_1 F4_3). unfold magma_op, reff194_inst, reff194_op in H. discriminate H. Qed.

Lemma reff194_not4084 : ~ @Equation4084 Fin4 reff194_inst.
Proof. unfold Equation4084. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff194_inst, reff194_op in H. discriminate H. Qed.

Lemma reff194_not4118 : ~ @Equation4118 Fin4 reff194_inst.
Proof. unfold Equation4118. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff194_inst, reff194_op in H. discriminate H. Qed.

Lemma reff194_not4120 : ~ @Equation4120 Fin4 reff194_inst.
Proof. unfold Equation4120. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff194_inst, reff194_op in H. discriminate H. Qed.

Lemma reff194_not4121 : ~ @Equation4121 Fin4 reff194_inst.
Proof. unfold Equation4121. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff194_inst, reff194_op in H. discriminate H. Qed.

Lemma reff194_not4127 : ~ @Equation4127 Fin4 reff194_inst.
Proof. unfold Equation4127. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff194_inst, reff194_op in H. discriminate H. Qed.

Lemma reff194_not4128 : ~ @Equation4128 Fin4 reff194_inst.
Proof. unfold Equation4128. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff194_inst, reff194_op in H. discriminate H. Qed.

Lemma reff194_not4130 : ~ @Equation4130 Fin4 reff194_inst.
Proof. unfold Equation4130. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff194_inst, reff194_op in H. discriminate H. Qed.

Lemma reff194_not4155 : ~ @Equation4155 Fin4 reff194_inst.
Proof. unfold Equation4155. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff194_inst, reff194_op in H. discriminate H. Qed.

Lemma reff194_not4157 : ~ @Equation4157 Fin4 reff194_inst.
Proof. unfold Equation4157. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff194_inst, reff194_op in H. discriminate H. Qed.

Lemma reff194_not4158 : ~ @Equation4158 Fin4 reff194_inst.
Proof. unfold Equation4158. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff194_inst, reff194_op in H. discriminate H. Qed.

Lemma reff194_not4164 : ~ @Equation4164 Fin4 reff194_inst.
Proof. unfold Equation4164. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff194_inst, reff194_op in H. discriminate H. Qed.

Lemma reff194_not4165 : ~ @Equation4165 Fin4 reff194_inst.
Proof. unfold Equation4165. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff194_inst, reff194_op in H. discriminate H. Qed.

Lemma reff194_not4167 : ~ @Equation4167 Fin4 reff194_inst.
Proof. unfold Equation4167. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff194_inst, reff194_op in H. discriminate H. Qed.

Lemma reff194_not4268 : ~ @Equation4268 Fin4 reff194_inst.
Proof. unfold Equation4268. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff194_inst, reff194_op in H. discriminate H. Qed.

Lemma reff194_not4269 : ~ @Equation4269 Fin4 reff194_inst.
Proof. unfold Equation4269. intro H. specialize (H F4_1 F4_2). unfold magma_op, reff194_inst, reff194_op in H. discriminate H. Qed.

Lemma reff194_not4272 : ~ @Equation4272 Fin4 reff194_inst.
Proof. unfold Equation4272. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff194_inst, reff194_op in H. discriminate H. Qed.

Lemma reff194_not4273 : ~ @Equation4273 Fin4 reff194_inst.
Proof. unfold Equation4273. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff194_inst, reff194_op in H. discriminate H. Qed.

Lemma reff194_not4275 : ~ @Equation4275 Fin4 reff194_inst.
Proof. unfold Equation4275. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff194_inst, reff194_op in H. discriminate H. Qed.

Lemma reff194_not4276 : ~ @Equation4276 Fin4 reff194_inst.
Proof. unfold Equation4276. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff194_inst, reff194_op in H. discriminate H. Qed.

Lemma reff194_not4283 : ~ @Equation4283 Fin4 reff194_inst.
Proof. unfold Equation4283. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff194_inst, reff194_op in H. discriminate H. Qed.

Lemma reff194_not4284 : ~ @Equation4284 Fin4 reff194_inst.
Proof. unfold Equation4284. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff194_inst, reff194_op in H. discriminate H. Qed.

Lemma reff194_not4290 : ~ @Equation4290 Fin4 reff194_inst.
Proof. unfold Equation4290. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff194_inst, reff194_op in H. discriminate H. Qed.

Lemma reff194_not4291 : ~ @Equation4291 Fin4 reff194_inst.
Proof. unfold Equation4291. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff194_inst, reff194_op in H. discriminate H. Qed.

Lemma reff194_not4293 : ~ @Equation4293 Fin4 reff194_inst.
Proof. unfold Equation4293. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff194_inst, reff194_op in H. discriminate H. Qed.

Lemma reff194_not4314 : ~ @Equation4314 Fin4 reff194_inst.
Proof. unfold Equation4314. intro H. specialize (H F4_1 F4_2). unfold magma_op, reff194_inst, reff194_op in H. discriminate H. Qed.

Lemma reff194_not4320 : ~ @Equation4320 Fin4 reff194_inst.
Proof. unfold Equation4320. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff194_inst, reff194_op in H. discriminate H. Qed.

Lemma reff194_not4321 : ~ @Equation4321 Fin4 reff194_inst.
Proof. unfold Equation4321. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff194_inst, reff194_op in H. discriminate H. Qed.

Lemma reff194_not4343 : ~ @Equation4343 Fin4 reff194_inst.
Proof. unfold Equation4343. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff194_inst, reff194_op in H. discriminate H. Qed.

Lemma reff194_not4380 : ~ @Equation4380 Fin4 reff194_inst.
Proof. unfold Equation4380. intro H. specialize (H F4_1). unfold magma_op, reff194_inst, reff194_op in H. discriminate H. Qed.

Lemma reff194_not4584 : ~ @Equation4584 Fin4 reff194_inst.
Proof. unfold Equation4584. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff194_inst, reff194_op in H. discriminate H. Qed.

Lemma reff194_not4585 : ~ @Equation4585 Fin4 reff194_inst.
Proof. unfold Equation4585. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff194_inst, reff194_op in H. discriminate H. Qed.

Lemma reff194_not4587 : ~ @Equation4587 Fin4 reff194_inst.
Proof. unfold Equation4587. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff194_inst, reff194_op in H. discriminate H. Qed.

Lemma reff194_not4588 : ~ @Equation4588 Fin4 reff194_inst.
Proof. unfold Equation4588. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff194_inst, reff194_op in H. discriminate H. Qed.

Lemma reff194_not4598 : ~ @Equation4598 Fin4 reff194_inst.
Proof. unfold Equation4598. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff194_inst, reff194_op in H. discriminate H. Qed.

Lemma reff194_not4599 : ~ @Equation4599 Fin4 reff194_inst.
Proof. unfold Equation4599. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff194_inst, reff194_op in H. discriminate H. Qed.

Lemma reff194_not4605 : ~ @Equation4605 Fin4 reff194_inst.
Proof. unfold Equation4605. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff194_inst, reff194_op in H. discriminate H. Qed.

Lemma reff194_not4606 : ~ @Equation4606 Fin4 reff194_inst.
Proof. unfold Equation4606. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff194_inst, reff194_op in H. discriminate H. Qed.

Lemma reff194_not4629 : ~ @Equation4629 Fin4 reff194_inst.
Proof. unfold Equation4629. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff194_inst, reff194_op in H. discriminate H. Qed.

Lemma reff194_not4635 : ~ @Equation4635 Fin4 reff194_inst.
Proof. unfold Equation4635. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff194_inst, reff194_op in H. discriminate H. Qed.

Lemma reff194_not4636 : ~ @Equation4636 Fin4 reff194_inst.
Proof. unfold Equation4636. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff194_inst, reff194_op in H. discriminate H. Qed.

Lemma reff194_not4658 : ~ @Equation4658 Fin4 reff194_inst.
Proof. unfold Equation4658. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff194_inst, reff194_op in H. discriminate H. Qed.

(** ---- reff196 (Fin5) ---- *)

Definition reff196_op (x y : Fin5) : Fin5 :=
  match x, y with
  | F5_0, F5_0 => F5_0 | F5_0, F5_1 => F5_2 | F5_0, F5_2 => F5_1 | F5_0, F5_3 => F5_2 | F5_0, F5_4 => F5_0
  | F5_1, F5_0 => F5_4 | F5_1, F5_1 => F5_4 | F5_1, F5_2 => F5_1 | F5_1, F5_3 => F5_0 | F5_1, F5_4 => F5_1
  | F5_2, F5_0 => F5_3 | F5_2, F5_1 => F5_1 | F5_2, F5_2 => F5_1 | F5_2, F5_3 => F5_3 | F5_2, F5_4 => F5_2
  | F5_3, F5_0 => F5_2 | F5_3, F5_1 => F5_3 | F5_3, F5_2 => F5_1 | F5_3, F5_3 => F5_1 | F5_3, F5_4 => F5_3
  | F5_4, F5_0 => F5_1 | F5_4, F5_1 => F5_0 | F5_4, F5_2 => F5_1 | F5_4, F5_3 => F5_4 | F5_4, F5_4 => F5_4
  end.

#[local] Instance reff196_inst : Magma Fin5 := {| magma_op := reff196_op |}.

Lemma reff196_sat817 : @Equation817 Fin5 reff196_inst.
Proof. unfold Equation817, magma_op, reff196_inst, reff196_op. intros x. destruct x; reflexivity. Qed.

Lemma reff196_sat3253 : @Equation3253 Fin5 reff196_inst.
Proof. unfold Equation3253, magma_op, reff196_inst, reff196_op. intros x. destruct x; reflexivity. Qed.

Lemma reff196_sat3862 : @Equation3862 Fin5 reff196_inst.
Proof. unfold Equation3862, magma_op, reff196_inst, reff196_op. intros x. destruct x; reflexivity. Qed.

Lemma reff196_not411 : ~ @Equation411 Fin5 reff196_inst.
Proof. unfold Equation411. intro H. specialize (H F5_2). unfold magma_op, reff196_inst, reff196_op in H. discriminate H. Qed.

Lemma reff196_not818 : ~ @Equation818 Fin5 reff196_inst.
Proof. unfold Equation818. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff196_inst, reff196_op in H. discriminate H. Qed.

Lemma reff196_not819 : ~ @Equation819 Fin5 reff196_inst.
Proof. unfold Equation819. intro H. specialize (H F5_0 F5_2). unfold magma_op, reff196_inst, reff196_op in H. discriminate H. Qed.

Lemma reff196_not820 : ~ @Equation820 Fin5 reff196_inst.
Proof. unfold Equation820. intro H. specialize (H F5_0 F5_2). unfold magma_op, reff196_inst, reff196_op in H. discriminate H. Qed.

Lemma reff196_not822 : ~ @Equation822 Fin5 reff196_inst.
Proof. unfold Equation822. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff196_inst, reff196_op in H. discriminate H. Qed.

Lemma reff196_not823 : ~ @Equation823 Fin5 reff196_inst.
Proof. unfold Equation823. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff196_inst, reff196_op in H. discriminate H. Qed.

Lemma reff196_not825 : ~ @Equation825 Fin5 reff196_inst.
Proof. unfold Equation825. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff196_inst, reff196_op in H. discriminate H. Qed.

Lemma reff196_not826 : ~ @Equation826 Fin5 reff196_inst.
Proof. unfold Equation826. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff196_inst, reff196_op in H. discriminate H. Qed.

Lemma reff196_not832 : ~ @Equation832 Fin5 reff196_inst.
Proof. unfold Equation832. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff196_inst, reff196_op in H. discriminate H. Qed.

Lemma reff196_not833 : ~ @Equation833 Fin5 reff196_inst.
Proof. unfold Equation833. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff196_inst, reff196_op in H. discriminate H. Qed.

Lemma reff196_not835 : ~ @Equation835 Fin5 reff196_inst.
Proof. unfold Equation835. intro H. specialize (H F5_0 F5_2). unfold magma_op, reff196_inst, reff196_op in H. discriminate H. Qed.

Lemma reff196_not836 : ~ @Equation836 Fin5 reff196_inst.
Proof. unfold Equation836. intro H. specialize (H F5_0 F5_2). unfold magma_op, reff196_inst, reff196_op in H. discriminate H. Qed.

Lemma reff196_not842 : ~ @Equation842 Fin5 reff196_inst.
Proof. unfold Equation842. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff196_inst, reff196_op in H. discriminate H. Qed.

Lemma reff196_not843 : ~ @Equation843 Fin5 reff196_inst.
Proof. unfold Equation843. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff196_inst, reff196_op in H. discriminate H. Qed.

Lemma reff196_not845 : ~ @Equation845 Fin5 reff196_inst.
Proof. unfold Equation845. intro H. specialize (H F5_0 F5_3). unfold magma_op, reff196_inst, reff196_op in H. discriminate H. Qed.

Lemma reff196_not846 : ~ @Equation846 Fin5 reff196_inst.
Proof. unfold Equation846. intro H. specialize (H F5_1 F5_0). unfold magma_op, reff196_inst, reff196_op in H. discriminate H. Qed.

Lemma reff196_not869 : ~ @Equation869 Fin5 reff196_inst.
Proof. unfold Equation869. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff196_inst, reff196_op in H. discriminate H. Qed.

Lemma reff196_not870 : ~ @Equation870 Fin5 reff196_inst.
Proof. unfold Equation870. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff196_inst, reff196_op in H. discriminate H. Qed.

Lemma reff196_not872 : ~ @Equation872 Fin5 reff196_inst.
Proof. unfold Equation872. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff196_inst, reff196_op in H. discriminate H. Qed.

Lemma reff196_not873 : ~ @Equation873 Fin5 reff196_inst.
Proof. unfold Equation873. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff196_inst, reff196_op in H. discriminate H. Qed.

Lemma reff196_not879 : ~ @Equation879 Fin5 reff196_inst.
Proof. unfold Equation879. intro H. specialize (H F5_0 F5_2). unfold magma_op, reff196_inst, reff196_op in H. discriminate H. Qed.

Lemma reff196_not880 : ~ @Equation880 Fin5 reff196_inst.
Proof. unfold Equation880. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff196_inst, reff196_op in H. discriminate H. Qed.

Lemma reff196_not882 : ~ @Equation882 Fin5 reff196_inst.
Proof. unfold Equation882. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff196_inst, reff196_op in H. discriminate H. Qed.

Lemma reff196_not883 : ~ @Equation883 Fin5 reff196_inst.
Proof. unfold Equation883. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff196_inst, reff196_op in H. discriminate H. Qed.

Lemma reff196_not906 : ~ @Equation906 Fin5 reff196_inst.
Proof. unfold Equation906. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff196_inst, reff196_op in H. discriminate H. Qed.

Lemma reff196_not907 : ~ @Equation907 Fin5 reff196_inst.
Proof. unfold Equation907. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff196_inst, reff196_op in H. discriminate H. Qed.

Lemma reff196_not909 : ~ @Equation909 Fin5 reff196_inst.
Proof. unfold Equation909. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff196_inst, reff196_op in H. discriminate H. Qed.

Lemma reff196_not910 : ~ @Equation910 Fin5 reff196_inst.
Proof. unfold Equation910. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff196_inst, reff196_op in H. discriminate H. Qed.

Lemma reff196_not916 : ~ @Equation916 Fin5 reff196_inst.
Proof. unfold Equation916. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff196_inst, reff196_op in H. discriminate H. Qed.

Lemma reff196_not917 : ~ @Equation917 Fin5 reff196_inst.
Proof. unfold Equation917. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff196_inst, reff196_op in H. discriminate H. Qed.

Lemma reff196_not919 : ~ @Equation919 Fin5 reff196_inst.
Proof. unfold Equation919. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff196_inst, reff196_op in H. discriminate H. Qed.

Lemma reff196_not1020 : ~ @Equation1020 Fin5 reff196_inst.
Proof. unfold Equation1020. intro H. specialize (H F5_2). unfold magma_op, reff196_inst, reff196_op in H. discriminate H. Qed.

Lemma reff196_not1223 : ~ @Equation1223 Fin5 reff196_inst.
Proof. unfold Equation1223. intro H. specialize (H F5_2). unfold magma_op, reff196_inst, reff196_op in H. discriminate H. Qed.

Lemma reff196_not1629 : ~ @Equation1629 Fin5 reff196_inst.
Proof. unfold Equation1629. intro H. specialize (H F5_2). unfold magma_op, reff196_inst, reff196_op in H. discriminate H. Qed.

Lemma reff196_not1832 : ~ @Equation1832 Fin5 reff196_inst.
Proof. unfold Equation1832. intro H. specialize (H F5_2). unfold magma_op, reff196_inst, reff196_op in H. discriminate H. Qed.

Lemma reff196_not2035 : ~ @Equation2035 Fin5 reff196_inst.
Proof. unfold Equation2035. intro H. specialize (H F5_1). unfold magma_op, reff196_inst, reff196_op in H. discriminate H. Qed.

Lemma reff196_not3261 : ~ @Equation3261 Fin5 reff196_inst.
Proof. unfold Equation3261. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff196_inst, reff196_op in H. discriminate H. Qed.

Lemma reff196_not3278 : ~ @Equation3278 Fin5 reff196_inst.
Proof. unfold Equation3278. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff196_inst, reff196_op in H. discriminate H. Qed.

Lemma reff196_not3306 : ~ @Equation3306 Fin5 reff196_inst.
Proof. unfold Equation3306. intro H. specialize (H F5_1 F5_3). unfold magma_op, reff196_inst, reff196_op in H. discriminate H. Qed.

Lemma reff196_not3319 : ~ @Equation3319 Fin5 reff196_inst.
Proof. unfold Equation3319. intro H. specialize (H F5_0 F5_2). unfold magma_op, reff196_inst, reff196_op in H. discriminate H. Qed.

Lemma reff196_not3353 : ~ @Equation3353 Fin5 reff196_inst.
Proof. unfold Equation3353. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff196_inst, reff196_op in H. discriminate H. Qed.

Lemma reff196_not3456 : ~ @Equation3456 Fin5 reff196_inst.
Proof. unfold Equation3456. intro H. specialize (H F5_3). unfold magma_op, reff196_inst, reff196_op in H. discriminate H. Qed.

Lemma reff196_not3659 : ~ @Equation3659 Fin5 reff196_inst.
Proof. unfold Equation3659. intro H. specialize (H F5_2). unfold magma_op, reff196_inst, reff196_op in H. discriminate H. Qed.

Lemma reff196_not3887 : ~ @Equation3887 Fin5 reff196_inst.
Proof. unfold Equation3887. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff196_inst, reff196_op in H. discriminate H. Qed.

Lemma reff196_not3915 : ~ @Equation3915 Fin5 reff196_inst.
Proof. unfold Equation3915. intro H. specialize (H F5_2 F5_0). unfold magma_op, reff196_inst, reff196_op in H. discriminate H. Qed.

Lemma reff196_not3962 : ~ @Equation3962 Fin5 reff196_inst.
Proof. unfold Equation3962. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff196_inst, reff196_op in H. discriminate H. Qed.

Lemma reff196_not4065 : ~ @Equation4065 Fin5 reff196_inst.
Proof. unfold Equation4065. intro H. specialize (H F5_1). unfold magma_op, reff196_inst, reff196_op in H. discriminate H. Qed.

Lemma reff196_not4275 : ~ @Equation4275 Fin5 reff196_inst.
Proof. unfold Equation4275. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff196_inst, reff196_op in H. discriminate H. Qed.

Lemma reff196_not4283 : ~ @Equation4283 Fin5 reff196_inst.
Proof. unfold Equation4283. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff196_inst, reff196_op in H. discriminate H. Qed.

Lemma reff196_not4290 : ~ @Equation4290 Fin5 reff196_inst.
Proof. unfold Equation4290. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff196_inst, reff196_op in H. discriminate H. Qed.

Lemma reff196_not4320 : ~ @Equation4320 Fin5 reff196_inst.
Proof. unfold Equation4320. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff196_inst, reff196_op in H. discriminate H. Qed.

Lemma reff196_not4380 : ~ @Equation4380 Fin5 reff196_inst.
Proof. unfold Equation4380. intro H. specialize (H F5_1). unfold magma_op, reff196_inst, reff196_op in H. discriminate H. Qed.

Lemma reff196_not4598 : ~ @Equation4598 Fin5 reff196_inst.
Proof. unfold Equation4598. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff196_inst, reff196_op in H. discriminate H. Qed.

Lemma reff196_not4605 : ~ @Equation4605 Fin5 reff196_inst.
Proof. unfold Equation4605. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff196_inst, reff196_op in H. discriminate H. Qed.

Lemma reff196_not4635 : ~ @Equation4635 Fin5 reff196_inst.
Proof. unfold Equation4635. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff196_inst, reff196_op in H. discriminate H. Qed.

(** ---- reff198 (Fin3) ---- *)

Definition reff198_op (x y : Fin3) : Fin3 :=
  match x, y with
  | F3_0, F3_0 => F3_0 | F3_0, F3_1 => F3_0 | F3_0, F3_2 => F3_0
  | F3_1, F3_0 => F3_1 | F3_1, F3_1 => F3_2 | F3_1, F3_2 => F3_0
  | F3_2, F3_0 => F3_1 | F3_2, F3_1 => F3_0 | F3_2, F3_2 => F3_2
  end.

#[local] Instance reff198_inst : Magma Fin3 := {| magma_op := reff198_op |}.

Lemma reff198_sat47 : @Equation47 Fin3 reff198_inst.
Proof. unfold Equation47, magma_op, reff198_inst, reff198_op. intros x. destruct x; reflexivity. Qed.

Lemma reff198_sat99 : @Equation99 Fin3 reff198_inst.
Proof. unfold Equation99, magma_op, reff198_inst, reff198_op. intros x. destruct x; reflexivity. Qed.

Lemma reff198_sat1020 : @Equation1020 Fin3 reff198_inst.
Proof. unfold Equation1020, magma_op, reff198_inst, reff198_op. intros x. destruct x; reflexivity. Qed.

Lemma reff198_sat1223 : @Equation1223 Fin3 reff198_inst.
Proof. unfold Equation1223, magma_op, reff198_inst, reff198_op. intros x. destruct x; reflexivity. Qed.

Lemma reff198_sat1426 : @Equation1426 Fin3 reff198_inst.
Proof. unfold Equation1426, magma_op, reff198_inst, reff198_op. intros x. destruct x; reflexivity. Qed.

Lemma reff198_sat1629 : @Equation1629 Fin3 reff198_inst.
Proof. unfold Equation1629, magma_op, reff198_inst, reff198_op. intros x. destruct x; reflexivity. Qed.

Lemma reff198_sat3724 : @Equation3724 Fin3 reff198_inst.
Proof. unfold Equation3724, magma_op, reff198_inst, reff198_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff198_sat3725 : @Equation3725 Fin3 reff198_inst.
Proof. unfold Equation3725, magma_op, reff198_inst, reff198_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff198_sat4380 : @Equation4380 Fin3 reff198_inst.
Proof. unfold Equation4380, magma_op, reff198_inst, reff198_op. intros x. destruct x; reflexivity. Qed.

Lemma reff198_not50 : ~ @Equation50 Fin3 reff198_inst.
Proof. unfold Equation50. intro H. specialize (H F3_1 F3_0). unfold magma_op, reff198_inst, reff198_op in H. discriminate H. Qed.

Lemma reff198_not53 : ~ @Equation53 Fin3 reff198_inst.
Proof. unfold Equation53. intro H. specialize (H F3_1 F3_2). unfold magma_op, reff198_inst, reff198_op in H. discriminate H. Qed.

Lemma reff198_not55 : ~ @Equation55 Fin3 reff198_inst.
Proof. unfold Equation55. intro H. specialize (H F3_1 F3_2). unfold magma_op, reff198_inst, reff198_op in H. discriminate H. Qed.

Lemma reff198_not56 : ~ @Equation56 Fin3 reff198_inst.
Proof. unfold Equation56. intro H. specialize (H F3_1 F3_2). unfold magma_op, reff198_inst, reff198_op in H. discriminate H. Qed.

Lemma reff198_not63 : ~ @Equation63 Fin3 reff198_inst.
Proof. unfold Equation63. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff198_inst, reff198_op in H. discriminate H. Qed.

Lemma reff198_not65 : ~ @Equation65 Fin3 reff198_inst.
Proof. unfold Equation65. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff198_inst, reff198_op in H. discriminate H. Qed.

Lemma reff198_not66 : ~ @Equation66 Fin3 reff198_inst.
Proof. unfold Equation66. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff198_inst, reff198_op in H. discriminate H. Qed.

Lemma reff198_not72 : ~ @Equation72 Fin3 reff198_inst.
Proof. unfold Equation72. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff198_inst, reff198_op in H. discriminate H. Qed.

Lemma reff198_not73 : ~ @Equation73 Fin3 reff198_inst.
Proof. unfold Equation73. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff198_inst, reff198_op in H. discriminate H. Qed.

Lemma reff198_not75 : ~ @Equation75 Fin3 reff198_inst.
Proof. unfold Equation75. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff198_inst, reff198_op in H. discriminate H. Qed.

Lemma reff198_not102 : ~ @Equation102 Fin3 reff198_inst.
Proof. unfold Equation102. intro H. specialize (H F3_1 F3_0). unfold magma_op, reff198_inst, reff198_op in H. discriminate H. Qed.

Lemma reff198_not105 : ~ @Equation105 Fin3 reff198_inst.
Proof. unfold Equation105. intro H. specialize (H F3_2 F3_0). unfold magma_op, reff198_inst, reff198_op in H. discriminate H. Qed.

Lemma reff198_not107 : ~ @Equation107 Fin3 reff198_inst.
Proof. unfold Equation107. intro H. specialize (H F3_2 F3_0). unfold magma_op, reff198_inst, reff198_op in H. discriminate H. Qed.

Lemma reff198_not108 : ~ @Equation108 Fin3 reff198_inst.
Proof. unfold Equation108. intro H. specialize (H F3_1 F3_2). unfold magma_op, reff198_inst, reff198_op in H. discriminate H. Qed.

Lemma reff198_not115 : ~ @Equation115 Fin3 reff198_inst.
Proof. unfold Equation115. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff198_inst, reff198_op in H. discriminate H. Qed.

Lemma reff198_not117 : ~ @Equation117 Fin3 reff198_inst.
Proof. unfold Equation117. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff198_inst, reff198_op in H. discriminate H. Qed.

Lemma reff198_not118 : ~ @Equation118 Fin3 reff198_inst.
Proof. unfold Equation118. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff198_inst, reff198_op in H. discriminate H. Qed.

Lemma reff198_not124 : ~ @Equation124 Fin3 reff198_inst.
Proof. unfold Equation124. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff198_inst, reff198_op in H. discriminate H. Qed.

Lemma reff198_not125 : ~ @Equation125 Fin3 reff198_inst.
Proof. unfold Equation125. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff198_inst, reff198_op in H. discriminate H. Qed.

Lemma reff198_not127 : ~ @Equation127 Fin3 reff198_inst.
Proof. unfold Equation127. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff198_inst, reff198_op in H. discriminate H. Qed.

Lemma reff198_not151 : ~ @Equation151 Fin3 reff198_inst.
Proof. unfold Equation151. intro H. specialize (H F3_1). unfold magma_op, reff198_inst, reff198_op in H. discriminate H. Qed.

Lemma reff198_not203 : ~ @Equation203 Fin3 reff198_inst.
Proof. unfold Equation203. intro H. specialize (H F3_1). unfold magma_op, reff198_inst, reff198_op in H. discriminate H. Qed.

Lemma reff198_not255 : ~ @Equation255 Fin3 reff198_inst.
Proof. unfold Equation255. intro H. specialize (H F3_1). unfold magma_op, reff198_inst, reff198_op in H. discriminate H. Qed.

Lemma reff198_not411 : ~ @Equation411 Fin3 reff198_inst.
Proof. unfold Equation411. intro H. specialize (H F3_1). unfold magma_op, reff198_inst, reff198_op in H. discriminate H. Qed.

Lemma reff198_not614 : ~ @Equation614 Fin3 reff198_inst.
Proof. unfold Equation614. intro H. specialize (H F3_1). unfold magma_op, reff198_inst, reff198_op in H. discriminate H. Qed.

Lemma reff198_not817 : ~ @Equation817 Fin3 reff198_inst.
Proof. unfold Equation817. intro H. specialize (H F3_1). unfold magma_op, reff198_inst, reff198_op in H. discriminate H. Qed.

Lemma reff198_not1021 : ~ @Equation1021 Fin3 reff198_inst.
Proof. unfold Equation1021. intro H. specialize (H F3_2 F3_0). unfold magma_op, reff198_inst, reff198_op in H. discriminate H. Qed.

Lemma reff198_not1022 : ~ @Equation1022 Fin3 reff198_inst.
Proof. unfold Equation1022. intro H. specialize (H F3_1 F3_2). unfold magma_op, reff198_inst, reff198_op in H. discriminate H. Qed.

Lemma reff198_not1023 : ~ @Equation1023 Fin3 reff198_inst.
Proof. unfold Equation1023. intro H. specialize (H F3_1 F3_0). unfold magma_op, reff198_inst, reff198_op in H. discriminate H. Qed.

Lemma reff198_not1025 : ~ @Equation1025 Fin3 reff198_inst.
Proof. unfold Equation1025. intro H. specialize (H F3_1 F3_0). unfold magma_op, reff198_inst, reff198_op in H. discriminate H. Qed.

Lemma reff198_not1026 : ~ @Equation1026 Fin3 reff198_inst.
Proof. unfold Equation1026. intro H. specialize (H F3_1 F3_0). unfold magma_op, reff198_inst, reff198_op in H. discriminate H. Qed.

Lemma reff198_not1028 : ~ @Equation1028 Fin3 reff198_inst.
Proof. unfold Equation1028. intro H. specialize (H F3_1 F3_0). unfold magma_op, reff198_inst, reff198_op in H. discriminate H. Qed.

Lemma reff198_not1029 : ~ @Equation1029 Fin3 reff198_inst.
Proof. unfold Equation1029. intro H. specialize (H F3_1 F3_0). unfold magma_op, reff198_inst, reff198_op in H. discriminate H. Qed.

Lemma reff198_not1035 : ~ @Equation1035 Fin3 reff198_inst.
Proof. unfold Equation1035. intro H. specialize (H F3_2 F3_0). unfold magma_op, reff198_inst, reff198_op in H. discriminate H. Qed.

Lemma reff198_not1036 : ~ @Equation1036 Fin3 reff198_inst.
Proof. unfold Equation1036. intro H. specialize (H F3_1 F3_2). unfold magma_op, reff198_inst, reff198_op in H. discriminate H. Qed.

Lemma reff198_not1038 : ~ @Equation1038 Fin3 reff198_inst.
Proof. unfold Equation1038. intro H. specialize (H F3_1 F3_2). unfold magma_op, reff198_inst, reff198_op in H. discriminate H. Qed.

Lemma reff198_not1039 : ~ @Equation1039 Fin3 reff198_inst.
Proof. unfold Equation1039. intro H. specialize (H F3_2 F3_0). unfold magma_op, reff198_inst, reff198_op in H. discriminate H. Qed.

Lemma reff198_not1045 : ~ @Equation1045 Fin3 reff198_inst.
Proof. unfold Equation1045. intro H. specialize (H F3_1 F3_2). unfold magma_op, reff198_inst, reff198_op in H. discriminate H. Qed.

Lemma reff198_not1046 : ~ @Equation1046 Fin3 reff198_inst.
Proof. unfold Equation1046. intro H. specialize (H F3_2 F3_0). unfold magma_op, reff198_inst, reff198_op in H. discriminate H. Qed.

Lemma reff198_not1048 : ~ @Equation1048 Fin3 reff198_inst.
Proof. unfold Equation1048. intro H. specialize (H F3_2 F3_0). unfold magma_op, reff198_inst, reff198_op in H. discriminate H. Qed.

Lemma reff198_not1049 : ~ @Equation1049 Fin3 reff198_inst.
Proof. unfold Equation1049. intro H. specialize (H F3_1 F3_2). unfold magma_op, reff198_inst, reff198_op in H. discriminate H. Qed.

Lemma reff198_not1072 : ~ @Equation1072 Fin3 reff198_inst.
Proof. unfold Equation1072. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff198_inst, reff198_op in H. discriminate H. Qed.

Lemma reff198_not1073 : ~ @Equation1073 Fin3 reff198_inst.
Proof. unfold Equation1073. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff198_inst, reff198_op in H. discriminate H. Qed.

Lemma reff198_not1075 : ~ @Equation1075 Fin3 reff198_inst.
Proof. unfold Equation1075. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff198_inst, reff198_op in H. discriminate H. Qed.

Lemma reff198_not1076 : ~ @Equation1076 Fin3 reff198_inst.
Proof. unfold Equation1076. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff198_inst, reff198_op in H. discriminate H. Qed.

Lemma reff198_not1082 : ~ @Equation1082 Fin3 reff198_inst.
Proof. unfold Equation1082. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff198_inst, reff198_op in H. discriminate H. Qed.

Lemma reff198_not1083 : ~ @Equation1083 Fin3 reff198_inst.
Proof. unfold Equation1083. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff198_inst, reff198_op in H. discriminate H. Qed.

Lemma reff198_not1085 : ~ @Equation1085 Fin3 reff198_inst.
Proof. unfold Equation1085. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff198_inst, reff198_op in H. discriminate H. Qed.

Lemma reff198_not1086 : ~ @Equation1086 Fin3 reff198_inst.
Proof. unfold Equation1086. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff198_inst, reff198_op in H. discriminate H. Qed.

Lemma reff198_not1109 : ~ @Equation1109 Fin3 reff198_inst.
Proof. unfold Equation1109. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff198_inst, reff198_op in H. discriminate H. Qed.

Lemma reff198_not1110 : ~ @Equation1110 Fin3 reff198_inst.
Proof. unfold Equation1110. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff198_inst, reff198_op in H. discriminate H. Qed.

Lemma reff198_not1112 : ~ @Equation1112 Fin3 reff198_inst.
Proof. unfold Equation1112. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff198_inst, reff198_op in H. discriminate H. Qed.

Lemma reff198_not1113 : ~ @Equation1113 Fin3 reff198_inst.
Proof. unfold Equation1113. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff198_inst, reff198_op in H. discriminate H. Qed.

Lemma reff198_not1119 : ~ @Equation1119 Fin3 reff198_inst.
Proof. unfold Equation1119. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff198_inst, reff198_op in H. discriminate H. Qed.

Lemma reff198_not1120 : ~ @Equation1120 Fin3 reff198_inst.
Proof. unfold Equation1120. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff198_inst, reff198_op in H. discriminate H. Qed.

Lemma reff198_not1122 : ~ @Equation1122 Fin3 reff198_inst.
Proof. unfold Equation1122. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff198_inst, reff198_op in H. discriminate H. Qed.

Lemma reff198_not1224 : ~ @Equation1224 Fin3 reff198_inst.
Proof. unfold Equation1224. intro H. specialize (H F3_2 F3_0). unfold magma_op, reff198_inst, reff198_op in H. discriminate H. Qed.

Lemma reff198_not1225 : ~ @Equation1225 Fin3 reff198_inst.
Proof. unfold Equation1225. intro H. specialize (H F3_1 F3_0). unfold magma_op, reff198_inst, reff198_op in H. discriminate H. Qed.

Lemma reff198_not1226 : ~ @Equation1226 Fin3 reff198_inst.
Proof. unfold Equation1226. intro H. specialize (H F3_1 F3_0). unfold magma_op, reff198_inst, reff198_op in H. discriminate H. Qed.

Lemma reff198_not1228 : ~ @Equation1228 Fin3 reff198_inst.
Proof. unfold Equation1228. intro H. specialize (H F3_2 F3_0). unfold magma_op, reff198_inst, reff198_op in H. discriminate H. Qed.

Lemma reff198_not1229 : ~ @Equation1229 Fin3 reff198_inst.
Proof. unfold Equation1229. intro H. specialize (H F3_1 F3_0). unfold magma_op, reff198_inst, reff198_op in H. discriminate H. Qed.

Lemma reff198_not1231 : ~ @Equation1231 Fin3 reff198_inst.
Proof. unfold Equation1231. intro H. specialize (H F3_1 F3_0). unfold magma_op, reff198_inst, reff198_op in H. discriminate H. Qed.

Lemma reff198_not1232 : ~ @Equation1232 Fin3 reff198_inst.
Proof. unfold Equation1232. intro H. specialize (H F3_1 F3_0). unfold magma_op, reff198_inst, reff198_op in H. discriminate H. Qed.

Lemma reff198_not1238 : ~ @Equation1238 Fin3 reff198_inst.
Proof. unfold Equation1238. intro H. specialize (H F3_2 F3_0). unfold magma_op, reff198_inst, reff198_op in H. discriminate H. Qed.

Lemma reff198_not1239 : ~ @Equation1239 Fin3 reff198_inst.
Proof. unfold Equation1239. intro H. specialize (H F3_2 F3_0). unfold magma_op, reff198_inst, reff198_op in H. discriminate H. Qed.

Lemma reff198_not1241 : ~ @Equation1241 Fin3 reff198_inst.
Proof. unfold Equation1241. intro H. specialize (H F3_2 F3_0). unfold magma_op, reff198_inst, reff198_op in H. discriminate H. Qed.

Lemma reff198_not1242 : ~ @Equation1242 Fin3 reff198_inst.
Proof. unfold Equation1242. intro H. specialize (H F3_2 F3_0). unfold magma_op, reff198_inst, reff198_op in H. discriminate H. Qed.

Lemma reff198_not1248 : ~ @Equation1248 Fin3 reff198_inst.
Proof. unfold Equation1248. intro H. specialize (H F3_2 F3_0). unfold magma_op, reff198_inst, reff198_op in H. discriminate H. Qed.

Lemma reff198_not1249 : ~ @Equation1249 Fin3 reff198_inst.
Proof. unfold Equation1249. intro H. specialize (H F3_2 F3_0). unfold magma_op, reff198_inst, reff198_op in H. discriminate H. Qed.

Lemma reff198_not1251 : ~ @Equation1251 Fin3 reff198_inst.
Proof. unfold Equation1251. intro H. specialize (H F3_2 F3_0). unfold magma_op, reff198_inst, reff198_op in H. discriminate H. Qed.

Lemma reff198_not1252 : ~ @Equation1252 Fin3 reff198_inst.
Proof. unfold Equation1252. intro H. specialize (H F3_1 F3_2). unfold magma_op, reff198_inst, reff198_op in H. discriminate H. Qed.

Lemma reff198_not1275 : ~ @Equation1275 Fin3 reff198_inst.
Proof. unfold Equation1275. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff198_inst, reff198_op in H. discriminate H. Qed.

Lemma reff198_not1276 : ~ @Equation1276 Fin3 reff198_inst.
Proof. unfold Equation1276. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff198_inst, reff198_op in H. discriminate H. Qed.

Lemma reff198_not1278 : ~ @Equation1278 Fin3 reff198_inst.
Proof. unfold Equation1278. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff198_inst, reff198_op in H. discriminate H. Qed.

Lemma reff198_not1279 : ~ @Equation1279 Fin3 reff198_inst.
Proof. unfold Equation1279. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff198_inst, reff198_op in H. discriminate H. Qed.

Lemma reff198_not1285 : ~ @Equation1285 Fin3 reff198_inst.
Proof. unfold Equation1285. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff198_inst, reff198_op in H. discriminate H. Qed.

Lemma reff198_not1286 : ~ @Equation1286 Fin3 reff198_inst.
Proof. unfold Equation1286. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff198_inst, reff198_op in H. discriminate H. Qed.

Lemma reff198_not1288 : ~ @Equation1288 Fin3 reff198_inst.
Proof. unfold Equation1288. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff198_inst, reff198_op in H. discriminate H. Qed.

Lemma reff198_not1289 : ~ @Equation1289 Fin3 reff198_inst.
Proof. unfold Equation1289. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff198_inst, reff198_op in H. discriminate H. Qed.

Lemma reff198_not1312 : ~ @Equation1312 Fin3 reff198_inst.
Proof. unfold Equation1312. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff198_inst, reff198_op in H. discriminate H. Qed.

Lemma reff198_not1313 : ~ @Equation1313 Fin3 reff198_inst.
Proof. unfold Equation1313. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff198_inst, reff198_op in H. discriminate H. Qed.

Lemma reff198_not1315 : ~ @Equation1315 Fin3 reff198_inst.
Proof. unfold Equation1315. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff198_inst, reff198_op in H. discriminate H. Qed.

Lemma reff198_not1316 : ~ @Equation1316 Fin3 reff198_inst.
Proof. unfold Equation1316. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff198_inst, reff198_op in H. discriminate H. Qed.

Lemma reff198_not1322 : ~ @Equation1322 Fin3 reff198_inst.
Proof. unfold Equation1322. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff198_inst, reff198_op in H. discriminate H. Qed.

Lemma reff198_not1323 : ~ @Equation1323 Fin3 reff198_inst.
Proof. unfold Equation1323. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff198_inst, reff198_op in H. discriminate H. Qed.

Lemma reff198_not1325 : ~ @Equation1325 Fin3 reff198_inst.
Proof. unfold Equation1325. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff198_inst, reff198_op in H. discriminate H. Qed.

Lemma reff198_not1427 : ~ @Equation1427 Fin3 reff198_inst.
Proof. unfold Equation1427. intro H. specialize (H F3_1 F3_0). unfold magma_op, reff198_inst, reff198_op in H. discriminate H. Qed.

Lemma reff198_not1428 : ~ @Equation1428 Fin3 reff198_inst.
Proof. unfold Equation1428. intro H. specialize (H F3_1 F3_0). unfold magma_op, reff198_inst, reff198_op in H. discriminate H. Qed.

Lemma reff198_not1429 : ~ @Equation1429 Fin3 reff198_inst.
Proof. unfold Equation1429. intro H. specialize (H F3_1 F3_0). unfold magma_op, reff198_inst, reff198_op in H. discriminate H. Qed.

Lemma reff198_not1431 : ~ @Equation1431 Fin3 reff198_inst.
Proof. unfold Equation1431. intro H. specialize (H F3_1 F3_2). unfold magma_op, reff198_inst, reff198_op in H. discriminate H. Qed.

Lemma reff198_not1432 : ~ @Equation1432 Fin3 reff198_inst.
Proof. unfold Equation1432. intro H. specialize (H F3_1 F3_2). unfold magma_op, reff198_inst, reff198_op in H. discriminate H. Qed.

Lemma reff198_not1434 : ~ @Equation1434 Fin3 reff198_inst.
Proof. unfold Equation1434. intro H. specialize (H F3_1 F3_2). unfold magma_op, reff198_inst, reff198_op in H. discriminate H. Qed.

Lemma reff198_not1435 : ~ @Equation1435 Fin3 reff198_inst.
Proof. unfold Equation1435. intro H. specialize (H F3_1 F3_2). unfold magma_op, reff198_inst, reff198_op in H. discriminate H. Qed.

Lemma reff198_not1441 : ~ @Equation1441 Fin3 reff198_inst.
Proof. unfold Equation1441. intro H. specialize (H F3_1 F3_2). unfold magma_op, reff198_inst, reff198_op in H. discriminate H. Qed.

Lemma reff198_not1442 : ~ @Equation1442 Fin3 reff198_inst.
Proof. unfold Equation1442. intro H. specialize (H F3_1 F3_0). unfold magma_op, reff198_inst, reff198_op in H. discriminate H. Qed.

Lemma reff198_not1444 : ~ @Equation1444 Fin3 reff198_inst.
Proof. unfold Equation1444. intro H. specialize (H F3_1 F3_0). unfold magma_op, reff198_inst, reff198_op in H. discriminate H. Qed.

Lemma reff198_not1445 : ~ @Equation1445 Fin3 reff198_inst.
Proof. unfold Equation1445. intro H. specialize (H F3_1 F3_0). unfold magma_op, reff198_inst, reff198_op in H. discriminate H. Qed.

Lemma reff198_not1451 : ~ @Equation1451 Fin3 reff198_inst.
Proof. unfold Equation1451. intro H. specialize (H F3_1 F3_2). unfold magma_op, reff198_inst, reff198_op in H. discriminate H. Qed.

Lemma reff198_not1452 : ~ @Equation1452 Fin3 reff198_inst.
Proof. unfold Equation1452. intro H. specialize (H F3_1 F3_2). unfold magma_op, reff198_inst, reff198_op in H. discriminate H. Qed.

Lemma reff198_not1454 : ~ @Equation1454 Fin3 reff198_inst.
Proof. unfold Equation1454. intro H. specialize (H F3_1 F3_2). unfold magma_op, reff198_inst, reff198_op in H. discriminate H. Qed.

Lemma reff198_not1455 : ~ @Equation1455 Fin3 reff198_inst.
Proof. unfold Equation1455. intro H. specialize (H F3_1 F3_2). unfold magma_op, reff198_inst, reff198_op in H. discriminate H. Qed.

Lemma reff198_not1478 : ~ @Equation1478 Fin3 reff198_inst.
Proof. unfold Equation1478. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff198_inst, reff198_op in H. discriminate H. Qed.

Lemma reff198_not1479 : ~ @Equation1479 Fin3 reff198_inst.
Proof. unfold Equation1479. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff198_inst, reff198_op in H. discriminate H. Qed.

Lemma reff198_not1481 : ~ @Equation1481 Fin3 reff198_inst.
Proof. unfold Equation1481. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff198_inst, reff198_op in H. discriminate H. Qed.

Lemma reff198_not1482 : ~ @Equation1482 Fin3 reff198_inst.
Proof. unfold Equation1482. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff198_inst, reff198_op in H. discriminate H. Qed.

Lemma reff198_not1488 : ~ @Equation1488 Fin3 reff198_inst.
Proof. unfold Equation1488. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff198_inst, reff198_op in H. discriminate H. Qed.

Lemma reff198_not1489 : ~ @Equation1489 Fin3 reff198_inst.
Proof. unfold Equation1489. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff198_inst, reff198_op in H. discriminate H. Qed.

Lemma reff198_not1491 : ~ @Equation1491 Fin3 reff198_inst.
Proof. unfold Equation1491. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff198_inst, reff198_op in H. discriminate H. Qed.

Lemma reff198_not1492 : ~ @Equation1492 Fin3 reff198_inst.
Proof. unfold Equation1492. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff198_inst, reff198_op in H. discriminate H. Qed.

Lemma reff198_not1515 : ~ @Equation1515 Fin3 reff198_inst.
Proof. unfold Equation1515. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff198_inst, reff198_op in H. discriminate H. Qed.

Lemma reff198_not1516 : ~ @Equation1516 Fin3 reff198_inst.
Proof. unfold Equation1516. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff198_inst, reff198_op in H. discriminate H. Qed.

Lemma reff198_not1518 : ~ @Equation1518 Fin3 reff198_inst.
Proof. unfold Equation1518. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff198_inst, reff198_op in H. discriminate H. Qed.

Lemma reff198_not1519 : ~ @Equation1519 Fin3 reff198_inst.
Proof. unfold Equation1519. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff198_inst, reff198_op in H. discriminate H. Qed.

Lemma reff198_not1525 : ~ @Equation1525 Fin3 reff198_inst.
Proof. unfold Equation1525. intro H. specialize (H F3_1 F3_0). unfold magma_op, reff198_inst, reff198_op in H. discriminate H. Qed.

Lemma reff198_not1526 : ~ @Equation1526 Fin3 reff198_inst.
Proof. unfold Equation1526. intro H. specialize (H F3_1 F3_0). unfold magma_op, reff198_inst, reff198_op in H. discriminate H. Qed.

Lemma reff198_not1528 : ~ @Equation1528 Fin3 reff198_inst.
Proof. unfold Equation1528. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff198_inst, reff198_op in H. discriminate H. Qed.

Lemma reff198_not1630 : ~ @Equation1630 Fin3 reff198_inst.
Proof. unfold Equation1630. intro H. specialize (H F3_1 F3_0). unfold magma_op, reff198_inst, reff198_op in H. discriminate H. Qed.

Lemma reff198_not1631 : ~ @Equation1631 Fin3 reff198_inst.
Proof. unfold Equation1631. intro H. specialize (H F3_1 F3_0). unfold magma_op, reff198_inst, reff198_op in H. discriminate H. Qed.

Lemma reff198_not1632 : ~ @Equation1632 Fin3 reff198_inst.
Proof. unfold Equation1632. intro H. specialize (H F3_1 F3_0). unfold magma_op, reff198_inst, reff198_op in H. discriminate H. Qed.

Lemma reff198_not1634 : ~ @Equation1634 Fin3 reff198_inst.
Proof. unfold Equation1634. intro H. specialize (H F3_2 F3_0). unfold magma_op, reff198_inst, reff198_op in H. discriminate H. Qed.

Lemma reff198_not1635 : ~ @Equation1635 Fin3 reff198_inst.
Proof. unfold Equation1635. intro H. specialize (H F3_2 F3_0). unfold magma_op, reff198_inst, reff198_op in H. discriminate H. Qed.

Lemma reff198_not1637 : ~ @Equation1637 Fin3 reff198_inst.
Proof. unfold Equation1637. intro H. specialize (H F3_2 F3_0). unfold magma_op, reff198_inst, reff198_op in H. discriminate H. Qed.

Lemma reff198_not1638 : ~ @Equation1638 Fin3 reff198_inst.
Proof. unfold Equation1638. intro H. specialize (H F3_1 F3_2). unfold magma_op, reff198_inst, reff198_op in H. discriminate H. Qed.

Lemma reff198_not1644 : ~ @Equation1644 Fin3 reff198_inst.
Proof. unfold Equation1644. intro H. specialize (H F3_1 F3_2). unfold magma_op, reff198_inst, reff198_op in H. discriminate H. Qed.

Lemma reff198_not1645 : ~ @Equation1645 Fin3 reff198_inst.
Proof. unfold Equation1645. intro H. specialize (H F3_1 F3_0). unfold magma_op, reff198_inst, reff198_op in H. discriminate H. Qed.

Lemma reff198_not1647 : ~ @Equation1647 Fin3 reff198_inst.
Proof. unfold Equation1647. intro H. specialize (H F3_1 F3_0). unfold magma_op, reff198_inst, reff198_op in H. discriminate H. Qed.

Lemma reff198_not1648 : ~ @Equation1648 Fin3 reff198_inst.
Proof. unfold Equation1648. intro H. specialize (H F3_1 F3_0). unfold magma_op, reff198_inst, reff198_op in H. discriminate H. Qed.

Lemma reff198_not1654 : ~ @Equation1654 Fin3 reff198_inst.
Proof. unfold Equation1654. intro H. specialize (H F3_1 F3_2). unfold magma_op, reff198_inst, reff198_op in H. discriminate H. Qed.

Lemma reff198_not1655 : ~ @Equation1655 Fin3 reff198_inst.
Proof. unfold Equation1655. intro H. specialize (H F3_1 F3_2). unfold magma_op, reff198_inst, reff198_op in H. discriminate H. Qed.

Lemma reff198_not1657 : ~ @Equation1657 Fin3 reff198_inst.
Proof. unfold Equation1657. intro H. specialize (H F3_1 F3_2). unfold magma_op, reff198_inst, reff198_op in H. discriminate H. Qed.

Lemma reff198_not1658 : ~ @Equation1658 Fin3 reff198_inst.
Proof. unfold Equation1658. intro H. specialize (H F3_1 F3_2). unfold magma_op, reff198_inst, reff198_op in H. discriminate H. Qed.

Lemma reff198_not1681 : ~ @Equation1681 Fin3 reff198_inst.
Proof. unfold Equation1681. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff198_inst, reff198_op in H. discriminate H. Qed.

Lemma reff198_not1682 : ~ @Equation1682 Fin3 reff198_inst.
Proof. unfold Equation1682. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff198_inst, reff198_op in H. discriminate H. Qed.

Lemma reff198_not1684 : ~ @Equation1684 Fin3 reff198_inst.
Proof. unfold Equation1684. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff198_inst, reff198_op in H. discriminate H. Qed.

Lemma reff198_not1685 : ~ @Equation1685 Fin3 reff198_inst.
Proof. unfold Equation1685. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff198_inst, reff198_op in H. discriminate H. Qed.

Lemma reff198_not1691 : ~ @Equation1691 Fin3 reff198_inst.
Proof. unfold Equation1691. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff198_inst, reff198_op in H. discriminate H. Qed.

Lemma reff198_not1692 : ~ @Equation1692 Fin3 reff198_inst.
Proof. unfold Equation1692. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff198_inst, reff198_op in H. discriminate H. Qed.

Lemma reff198_not1694 : ~ @Equation1694 Fin3 reff198_inst.
Proof. unfold Equation1694. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff198_inst, reff198_op in H. discriminate H. Qed.

Lemma reff198_not1695 : ~ @Equation1695 Fin3 reff198_inst.
Proof. unfold Equation1695. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff198_inst, reff198_op in H. discriminate H. Qed.

Lemma reff198_not1718 : ~ @Equation1718 Fin3 reff198_inst.
Proof. unfold Equation1718. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff198_inst, reff198_op in H. discriminate H. Qed.

Lemma reff198_not1719 : ~ @Equation1719 Fin3 reff198_inst.
Proof. unfold Equation1719. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff198_inst, reff198_op in H. discriminate H. Qed.

Lemma reff198_not1721 : ~ @Equation1721 Fin3 reff198_inst.
Proof. unfold Equation1721. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff198_inst, reff198_op in H. discriminate H. Qed.

Lemma reff198_not1722 : ~ @Equation1722 Fin3 reff198_inst.
Proof. unfold Equation1722. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff198_inst, reff198_op in H. discriminate H. Qed.

Lemma reff198_not1728 : ~ @Equation1728 Fin3 reff198_inst.
Proof. unfold Equation1728. intro H. specialize (H F3_1 F3_0). unfold magma_op, reff198_inst, reff198_op in H. discriminate H. Qed.

Lemma reff198_not1729 : ~ @Equation1729 Fin3 reff198_inst.
Proof. unfold Equation1729. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff198_inst, reff198_op in H. discriminate H. Qed.

Lemma reff198_not1731 : ~ @Equation1731 Fin3 reff198_inst.
Proof. unfold Equation1731. intro H. specialize (H F3_1 F3_0). unfold magma_op, reff198_inst, reff198_op in H. discriminate H. Qed.

Lemma reff198_not1832 : ~ @Equation1832 Fin3 reff198_inst.
Proof. unfold Equation1832. intro H. specialize (H F3_1). unfold magma_op, reff198_inst, reff198_op in H. discriminate H. Qed.

Lemma reff198_not2035 : ~ @Equation2035 Fin3 reff198_inst.
Proof. unfold Equation2035. intro H. specialize (H F3_1). unfold magma_op, reff198_inst, reff198_op in H. discriminate H. Qed.

Lemma reff198_not2238 : ~ @Equation2238 Fin3 reff198_inst.
Proof. unfold Equation2238. intro H. specialize (H F3_1). unfold magma_op, reff198_inst, reff198_op in H. discriminate H. Qed.

Lemma reff198_not2441 : ~ @Equation2441 Fin3 reff198_inst.
Proof. unfold Equation2441. intro H. specialize (H F3_1). unfold magma_op, reff198_inst, reff198_op in H. discriminate H. Qed.

Lemma reff198_not2644 : ~ @Equation2644 Fin3 reff198_inst.
Proof. unfold Equation2644. intro H. specialize (H F3_1). unfold magma_op, reff198_inst, reff198_op in H. discriminate H. Qed.

Lemma reff198_not2847 : ~ @Equation2847 Fin3 reff198_inst.
Proof. unfold Equation2847. intro H. specialize (H F3_1). unfold magma_op, reff198_inst, reff198_op in H. discriminate H. Qed.

Lemma reff198_not3050 : ~ @Equation3050 Fin3 reff198_inst.
Proof. unfold Equation3050. intro H. specialize (H F3_1). unfold magma_op, reff198_inst, reff198_op in H. discriminate H. Qed.

Lemma reff198_not3253 : ~ @Equation3253 Fin3 reff198_inst.
Proof. unfold Equation3253. intro H. specialize (H F3_1). unfold magma_op, reff198_inst, reff198_op in H. discriminate H. Qed.

Lemma reff198_not3456 : ~ @Equation3456 Fin3 reff198_inst.
Proof. unfold Equation3456. intro H. specialize (H F3_1). unfold magma_op, reff198_inst, reff198_op in H. discriminate H. Qed.

Lemma reff198_not3660 : ~ @Equation3660 Fin3 reff198_inst.
Proof. unfold Equation3660. intro H. specialize (H F3_1 F3_0). unfold magma_op, reff198_inst, reff198_op in H. discriminate H. Qed.

Lemma reff198_not3661 : ~ @Equation3661 Fin3 reff198_inst.
Proof. unfold Equation3661. intro H. specialize (H F3_1 F3_0). unfold magma_op, reff198_inst, reff198_op in H. discriminate H. Qed.

Lemma reff198_not3662 : ~ @Equation3662 Fin3 reff198_inst.
Proof. unfold Equation3662. intro H. specialize (H F3_1 F3_0). unfold magma_op, reff198_inst, reff198_op in H. discriminate H. Qed.

Lemma reff198_not3664 : ~ @Equation3664 Fin3 reff198_inst.
Proof. unfold Equation3664. intro H. specialize (H F3_1 F3_0). unfold magma_op, reff198_inst, reff198_op in H. discriminate H. Qed.

Lemma reff198_not3665 : ~ @Equation3665 Fin3 reff198_inst.
Proof. unfold Equation3665. intro H. specialize (H F3_1 F3_2). unfold magma_op, reff198_inst, reff198_op in H. discriminate H. Qed.

Lemma reff198_not3667 : ~ @Equation3667 Fin3 reff198_inst.
Proof. unfold Equation3667. intro H. specialize (H F3_1 F3_0). unfold magma_op, reff198_inst, reff198_op in H. discriminate H. Qed.

Lemma reff198_not3668 : ~ @Equation3668 Fin3 reff198_inst.
Proof. unfold Equation3668. intro H. specialize (H F3_1 F3_0). unfold magma_op, reff198_inst, reff198_op in H. discriminate H. Qed.

Lemma reff198_not3674 : ~ @Equation3674 Fin3 reff198_inst.
Proof. unfold Equation3674. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff198_inst, reff198_op in H. discriminate H. Qed.

Lemma reff198_not3675 : ~ @Equation3675 Fin3 reff198_inst.
Proof. unfold Equation3675. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff198_inst, reff198_op in H. discriminate H. Qed.

Lemma reff198_not3677 : ~ @Equation3677 Fin3 reff198_inst.
Proof. unfold Equation3677. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff198_inst, reff198_op in H. discriminate H. Qed.

Lemma reff198_not3678 : ~ @Equation3678 Fin3 reff198_inst.
Proof. unfold Equation3678. intro H. specialize (H F3_1 F3_0). unfold magma_op, reff198_inst, reff198_op in H. discriminate H. Qed.

Lemma reff198_not3684 : ~ @Equation3684 Fin3 reff198_inst.
Proof. unfold Equation3684. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff198_inst, reff198_op in H. discriminate H. Qed.

Lemma reff198_not3685 : ~ @Equation3685 Fin3 reff198_inst.
Proof. unfold Equation3685. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff198_inst, reff198_op in H. discriminate H. Qed.

Lemma reff198_not3687 : ~ @Equation3687 Fin3 reff198_inst.
Proof. unfold Equation3687. intro H. specialize (H F3_1 F3_0). unfold magma_op, reff198_inst, reff198_op in H. discriminate H. Qed.

Lemma reff198_not3712 : ~ @Equation3712 Fin3 reff198_inst.
Proof. unfold Equation3712. intro H. specialize (H F3_1 F3_0). unfold magma_op, reff198_inst, reff198_op in H. discriminate H. Qed.

Lemma reff198_not3714 : ~ @Equation3714 Fin3 reff198_inst.
Proof. unfold Equation3714. intro H. specialize (H F3_1 F3_2). unfold magma_op, reff198_inst, reff198_op in H. discriminate H. Qed.

Lemma reff198_not3721 : ~ @Equation3721 Fin3 reff198_inst.
Proof. unfold Equation3721. intro H. specialize (H F3_1 F3_0). unfold magma_op, reff198_inst, reff198_op in H. discriminate H. Qed.

Lemma reff198_not3722 : ~ @Equation3722 Fin3 reff198_inst.
Proof. unfold Equation3722. intro H. specialize (H F3_1 F3_0). unfold magma_op, reff198_inst, reff198_op in H. discriminate H. Qed.

Lemma reff198_not3748 : ~ @Equation3748 Fin3 reff198_inst.
Proof. unfold Equation3748. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff198_inst, reff198_op in H. discriminate H. Qed.

Lemma reff198_not3749 : ~ @Equation3749 Fin3 reff198_inst.
Proof. unfold Equation3749. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff198_inst, reff198_op in H. discriminate H. Qed.

Lemma reff198_not3751 : ~ @Equation3751 Fin3 reff198_inst.
Proof. unfold Equation3751. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff198_inst, reff198_op in H. discriminate H. Qed.

Lemma reff198_not3752 : ~ @Equation3752 Fin3 reff198_inst.
Proof. unfold Equation3752. intro H. specialize (H F3_1 F3_0). unfold magma_op, reff198_inst, reff198_op in H. discriminate H. Qed.

Lemma reff198_not3759 : ~ @Equation3759 Fin3 reff198_inst.
Proof. unfold Equation3759. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff198_inst, reff198_op in H. discriminate H. Qed.

Lemma reff198_not3761 : ~ @Equation3761 Fin3 reff198_inst.
Proof. unfold Equation3761. intro H. specialize (H F3_1 F3_0). unfold magma_op, reff198_inst, reff198_op in H. discriminate H. Qed.

Lemma reff198_not3862 : ~ @Equation3862 Fin3 reff198_inst.
Proof. unfold Equation3862. intro H. specialize (H F3_1). unfold magma_op, reff198_inst, reff198_op in H. discriminate H. Qed.

Lemma reff198_not4065 : ~ @Equation4065 Fin3 reff198_inst.
Proof. unfold Equation4065. intro H. specialize (H F3_1). unfold magma_op, reff198_inst, reff198_op in H. discriminate H. Qed.

Lemma reff198_not4268 : ~ @Equation4268 Fin3 reff198_inst.
Proof. unfold Equation4268. intro H. specialize (H F3_1 F3_0). unfold magma_op, reff198_inst, reff198_op in H. discriminate H. Qed.

Lemma reff198_not4269 : ~ @Equation4269 Fin3 reff198_inst.
Proof. unfold Equation4269. intro H. specialize (H F3_1 F3_0). unfold magma_op, reff198_inst, reff198_op in H. discriminate H. Qed.

Lemma reff198_not4270 : ~ @Equation4270 Fin3 reff198_inst.
Proof. unfold Equation4270. intro H. specialize (H F3_1 F3_0). unfold magma_op, reff198_inst, reff198_op in H. discriminate H. Qed.

Lemma reff198_not4272 : ~ @Equation4272 Fin3 reff198_inst.
Proof. unfold Equation4272. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff198_inst, reff198_op in H. discriminate H. Qed.

Lemma reff198_not4273 : ~ @Equation4273 Fin3 reff198_inst.
Proof. unfold Equation4273. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff198_inst, reff198_op in H. discriminate H. Qed.

Lemma reff198_not4275 : ~ @Equation4275 Fin3 reff198_inst.
Proof. unfold Equation4275. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff198_inst, reff198_op in H. discriminate H. Qed.

Lemma reff198_not4276 : ~ @Equation4276 Fin3 reff198_inst.
Proof. unfold Equation4276. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff198_inst, reff198_op in H. discriminate H. Qed.

Lemma reff198_not4283 : ~ @Equation4283 Fin3 reff198_inst.
Proof. unfold Equation4283. intro H. specialize (H F3_1 F3_0). unfold magma_op, reff198_inst, reff198_op in H. discriminate H. Qed.

Lemma reff198_not4284 : ~ @Equation4284 Fin3 reff198_inst.
Proof. unfold Equation4284. intro H. specialize (H F3_1 F3_0). unfold magma_op, reff198_inst, reff198_op in H. discriminate H. Qed.

Lemma reff198_not4290 : ~ @Equation4290 Fin3 reff198_inst.
Proof. unfold Equation4290. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff198_inst, reff198_op in H. discriminate H. Qed.

Lemma reff198_not4291 : ~ @Equation4291 Fin3 reff198_inst.
Proof. unfold Equation4291. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff198_inst, reff198_op in H. discriminate H. Qed.

Lemma reff198_not4293 : ~ @Equation4293 Fin3 reff198_inst.
Proof. unfold Equation4293. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff198_inst, reff198_op in H. discriminate H. Qed.

Lemma reff198_not4314 : ~ @Equation4314 Fin3 reff198_inst.
Proof. unfold Equation4314. intro H. specialize (H F3_1 F3_2). unfold magma_op, reff198_inst, reff198_op in H. discriminate H. Qed.

Lemma reff198_not4320 : ~ @Equation4320 Fin3 reff198_inst.
Proof. unfold Equation4320. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff198_inst, reff198_op in H. discriminate H. Qed.

Lemma reff198_not4321 : ~ @Equation4321 Fin3 reff198_inst.
Proof. unfold Equation4321. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff198_inst, reff198_op in H. discriminate H. Qed.

Lemma reff198_not4343 : ~ @Equation4343 Fin3 reff198_inst.
Proof. unfold Equation4343. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff198_inst, reff198_op in H. discriminate H. Qed.

Lemma reff198_not4396 : ~ @Equation4396 Fin3 reff198_inst.
Proof. unfold Equation4396. intro H. specialize (H F3_1 F3_0). unfold magma_op, reff198_inst, reff198_op in H. discriminate H. Qed.

Lemma reff198_not4398 : ~ @Equation4398 Fin3 reff198_inst.
Proof. unfold Equation4398. intro H. specialize (H F3_1 F3_2). unfold magma_op, reff198_inst, reff198_op in H. discriminate H. Qed.

Lemma reff198_not4399 : ~ @Equation4399 Fin3 reff198_inst.
Proof. unfold Equation4399. intro H. specialize (H F3_1 F3_0). unfold magma_op, reff198_inst, reff198_op in H. discriminate H. Qed.

Lemma reff198_not4405 : ~ @Equation4405 Fin3 reff198_inst.
Proof. unfold Equation4405. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff198_inst, reff198_op in H. discriminate H. Qed.

Lemma reff198_not4406 : ~ @Equation4406 Fin3 reff198_inst.
Proof. unfold Equation4406. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff198_inst, reff198_op in H. discriminate H. Qed.

Lemma reff198_not4408 : ~ @Equation4408 Fin3 reff198_inst.
Proof. unfold Equation4408. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff198_inst, reff198_op in H. discriminate H. Qed.

Lemma reff198_not4433 : ~ @Equation4433 Fin3 reff198_inst.
Proof. unfold Equation4433. intro H. specialize (H F3_1 F3_2). unfold magma_op, reff198_inst, reff198_op in H. discriminate H. Qed.

Lemma reff198_not4435 : ~ @Equation4435 Fin3 reff198_inst.
Proof. unfold Equation4435. intro H. specialize (H F3_1 F3_0). unfold magma_op, reff198_inst, reff198_op in H. discriminate H. Qed.

Lemma reff198_not4436 : ~ @Equation4436 Fin3 reff198_inst.
Proof. unfold Equation4436. intro H. specialize (H F3_1 F3_2). unfold magma_op, reff198_inst, reff198_op in H. discriminate H. Qed.

Lemma reff198_not4442 : ~ @Equation4442 Fin3 reff198_inst.
Proof. unfold Equation4442. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff198_inst, reff198_op in H. discriminate H. Qed.

Lemma reff198_not4443 : ~ @Equation4443 Fin3 reff198_inst.
Proof. unfold Equation4443. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff198_inst, reff198_op in H. discriminate H. Qed.

Lemma reff198_not4445 : ~ @Equation4445 Fin3 reff198_inst.
Proof. unfold Equation4445. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff198_inst, reff198_op in H. discriminate H. Qed.

Lemma reff198_not4470 : ~ @Equation4470 Fin3 reff198_inst.
Proof. unfold Equation4470. intro H. specialize (H F3_1 F3_2). unfold magma_op, reff198_inst, reff198_op in H. discriminate H. Qed.

Lemma reff198_not4472 : ~ @Equation4472 Fin3 reff198_inst.
Proof. unfold Equation4472. intro H. specialize (H F3_1 F3_0). unfold magma_op, reff198_inst, reff198_op in H. discriminate H. Qed.

Lemma reff198_not4473 : ~ @Equation4473 Fin3 reff198_inst.
Proof. unfold Equation4473. intro H. specialize (H F3_2 F3_1). unfold magma_op, reff198_inst, reff198_op in H. discriminate H. Qed.

Lemma reff198_not4479 : ~ @Equation4479 Fin3 reff198_inst.
Proof. unfold Equation4479. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff198_inst, reff198_op in H. discriminate H. Qed.

Lemma reff198_not4480 : ~ @Equation4480 Fin3 reff198_inst.
Proof. unfold Equation4480. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff198_inst, reff198_op in H. discriminate H. Qed.

Lemma reff198_not4482 : ~ @Equation4482 Fin3 reff198_inst.
Proof. unfold Equation4482. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff198_inst, reff198_op in H. discriminate H. Qed.

Lemma reff198_not4583 : ~ @Equation4583 Fin3 reff198_inst.
Proof. unfold Equation4583. intro H. specialize (H F3_1 F3_0). unfold magma_op, reff198_inst, reff198_op in H. discriminate H. Qed.

Lemma reff198_not4584 : ~ @Equation4584 Fin3 reff198_inst.
Proof. unfold Equation4584. intro H. specialize (H F3_1 F3_0). unfold magma_op, reff198_inst, reff198_op in H. discriminate H. Qed.

Lemma reff198_not4585 : ~ @Equation4585 Fin3 reff198_inst.
Proof. unfold Equation4585. intro H. specialize (H F3_1 F3_0). unfold magma_op, reff198_inst, reff198_op in H. discriminate H. Qed.

Lemma reff198_not4587 : ~ @Equation4587 Fin3 reff198_inst.
Proof. unfold Equation4587. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff198_inst, reff198_op in H. discriminate H. Qed.

Lemma reff198_not4588 : ~ @Equation4588 Fin3 reff198_inst.
Proof. unfold Equation4588. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff198_inst, reff198_op in H. discriminate H. Qed.

Lemma reff198_not4590 : ~ @Equation4590 Fin3 reff198_inst.
Proof. unfold Equation4590. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff198_inst, reff198_op in H. discriminate H. Qed.

Lemma reff198_not4591 : ~ @Equation4591 Fin3 reff198_inst.
Proof. unfold Equation4591. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff198_inst, reff198_op in H. discriminate H. Qed.

Lemma reff198_not4598 : ~ @Equation4598 Fin3 reff198_inst.
Proof. unfold Equation4598. intro H. specialize (H F3_1 F3_0). unfold magma_op, reff198_inst, reff198_op in H. discriminate H. Qed.

Lemma reff198_not4599 : ~ @Equation4599 Fin3 reff198_inst.
Proof. unfold Equation4599. intro H. specialize (H F3_1 F3_2). unfold magma_op, reff198_inst, reff198_op in H. discriminate H. Qed.

Lemma reff198_not4605 : ~ @Equation4605 Fin3 reff198_inst.
Proof. unfold Equation4605. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff198_inst, reff198_op in H. discriminate H. Qed.

Lemma reff198_not4606 : ~ @Equation4606 Fin3 reff198_inst.
Proof. unfold Equation4606. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff198_inst, reff198_op in H. discriminate H. Qed.

Lemma reff198_not4608 : ~ @Equation4608 Fin3 reff198_inst.
Proof. unfold Equation4608. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff198_inst, reff198_op in H. discriminate H. Qed.

Lemma reff198_not4629 : ~ @Equation4629 Fin3 reff198_inst.
Proof. unfold Equation4629. intro H. specialize (H F3_1 F3_0). unfold magma_op, reff198_inst, reff198_op in H. discriminate H. Qed.

Lemma reff198_not4635 : ~ @Equation4635 Fin3 reff198_inst.
Proof. unfold Equation4635. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff198_inst, reff198_op in H. discriminate H. Qed.

Lemma reff198_not4636 : ~ @Equation4636 Fin3 reff198_inst.
Proof. unfold Equation4636. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff198_inst, reff198_op in H. discriminate H. Qed.

Lemma reff198_not4658 : ~ @Equation4658 Fin3 reff198_inst.
Proof. unfold Equation4658. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff198_inst, reff198_op in H. discriminate H. Qed.

(** ---- reff20 (Fin4) ---- *)

Definition reff20_op (x y : Fin4) : Fin4 :=
  match x, y with
  | F4_0, F4_0 => F4_0 | F4_0, F4_1 => F4_2 | F4_0, F4_2 => F4_0 | F4_0, F4_3 => F4_2
  | F4_1, F4_0 => F4_0 | F4_1, F4_1 => F4_1 | F4_1, F4_2 => F4_2 | F4_1, F4_3 => F4_3
  | F4_2, F4_0 => F4_2 | F4_2, F4_1 => F4_2 | F4_2, F4_2 => F4_2 | F4_2, F4_3 => F4_2
  | F4_3, F4_0 => F4_2 | F4_3, F4_1 => F4_1 | F4_3, F4_2 => F4_0 | F4_3, F4_3 => F4_3
  end.

#[local] Instance reff20_inst : Magma Fin4 := {| magma_op := reff20_op |}.

Lemma reff20_sat3 : @Equation3 Fin4 reff20_inst.
Proof. unfold Equation3, magma_op, reff20_inst, reff20_op. intros x. destruct x; reflexivity. Qed.

Lemma reff20_sat378 : @Equation378 Fin4 reff20_inst.
Proof. unfold Equation378, magma_op, reff20_inst, reff20_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff20_sat3725 : @Equation3725 Fin4 reff20_inst.
Proof. unfold Equation3725, magma_op, reff20_inst, reff20_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff20_sat3928 : @Equation3928 Fin4 reff20_inst.
Proof. unfold Equation3928, magma_op, reff20_inst, reff20_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff20_sat4121 : @Equation4121 Fin4 reff20_inst.
Proof. unfold Equation4121, magma_op, reff20_inst, reff20_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff20_sat4473 : @Equation4473 Fin4 reff20_inst.
Proof. unfold Equation4473, magma_op, reff20_inst, reff20_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff20_sat4599 : @Equation4599 Fin4 reff20_inst.
Proof. unfold Equation4599, magma_op, reff20_inst, reff20_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff20_not50 : ~ @Equation50 Fin4 reff20_inst.
Proof. unfold Equation50. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff20_inst, reff20_op in H. discriminate H. Qed.

Lemma reff20_not53 : ~ @Equation53 Fin4 reff20_inst.
Proof. unfold Equation53. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff20_inst, reff20_op in H. discriminate H. Qed.

Lemma reff20_not55 : ~ @Equation55 Fin4 reff20_inst.
Proof. unfold Equation55. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff20_inst, reff20_op in H. discriminate H. Qed.

Lemma reff20_not56 : ~ @Equation56 Fin4 reff20_inst.
Proof. unfold Equation56. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff20_inst, reff20_op in H. discriminate H. Qed.

Lemma reff20_not63 : ~ @Equation63 Fin4 reff20_inst.
Proof. unfold Equation63. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff20_inst, reff20_op in H. discriminate H. Qed.

Lemma reff20_not65 : ~ @Equation65 Fin4 reff20_inst.
Proof. unfold Equation65. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff20_inst, reff20_op in H. discriminate H. Qed.

Lemma reff20_not66 : ~ @Equation66 Fin4 reff20_inst.
Proof. unfold Equation66. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff20_inst, reff20_op in H. discriminate H. Qed.

Lemma reff20_not72 : ~ @Equation72 Fin4 reff20_inst.
Proof. unfold Equation72. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff20_inst, reff20_op in H. discriminate H. Qed.

Lemma reff20_not73 : ~ @Equation73 Fin4 reff20_inst.
Proof. unfold Equation73. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff20_inst, reff20_op in H. discriminate H. Qed.

Lemma reff20_not75 : ~ @Equation75 Fin4 reff20_inst.
Proof. unfold Equation75. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff20_inst, reff20_op in H. discriminate H. Qed.

Lemma reff20_not102 : ~ @Equation102 Fin4 reff20_inst.
Proof. unfold Equation102. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff20_inst, reff20_op in H. discriminate H. Qed.

Lemma reff20_not105 : ~ @Equation105 Fin4 reff20_inst.
Proof. unfold Equation105. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff20_inst, reff20_op in H. discriminate H. Qed.

Lemma reff20_not107 : ~ @Equation107 Fin4 reff20_inst.
Proof. unfold Equation107. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff20_inst, reff20_op in H. discriminate H. Qed.

Lemma reff20_not108 : ~ @Equation108 Fin4 reff20_inst.
Proof. unfold Equation108. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff20_inst, reff20_op in H. discriminate H. Qed.

Lemma reff20_not115 : ~ @Equation115 Fin4 reff20_inst.
Proof. unfold Equation115. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff20_inst, reff20_op in H. discriminate H. Qed.

Lemma reff20_not117 : ~ @Equation117 Fin4 reff20_inst.
Proof. unfold Equation117. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff20_inst, reff20_op in H. discriminate H. Qed.

Lemma reff20_not118 : ~ @Equation118 Fin4 reff20_inst.
Proof. unfold Equation118. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff20_inst, reff20_op in H. discriminate H. Qed.

Lemma reff20_not124 : ~ @Equation124 Fin4 reff20_inst.
Proof. unfold Equation124. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff20_inst, reff20_op in H. discriminate H. Qed.

Lemma reff20_not125 : ~ @Equation125 Fin4 reff20_inst.
Proof. unfold Equation125. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff20_inst, reff20_op in H. discriminate H. Qed.

Lemma reff20_not127 : ~ @Equation127 Fin4 reff20_inst.
Proof. unfold Equation127. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff20_inst, reff20_op in H. discriminate H. Qed.

Lemma reff20_not154 : ~ @Equation154 Fin4 reff20_inst.
Proof. unfold Equation154. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff20_inst, reff20_op in H. discriminate H. Qed.

Lemma reff20_not157 : ~ @Equation157 Fin4 reff20_inst.
Proof. unfold Equation157. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff20_inst, reff20_op in H. discriminate H. Qed.

Lemma reff20_not159 : ~ @Equation159 Fin4 reff20_inst.
Proof. unfold Equation159. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff20_inst, reff20_op in H. discriminate H. Qed.

Lemma reff20_not160 : ~ @Equation160 Fin4 reff20_inst.
Proof. unfold Equation160. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff20_inst, reff20_op in H. discriminate H. Qed.

Lemma reff20_not167 : ~ @Equation167 Fin4 reff20_inst.
Proof. unfold Equation167. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff20_inst, reff20_op in H. discriminate H. Qed.

Lemma reff20_not169 : ~ @Equation169 Fin4 reff20_inst.
Proof. unfold Equation169. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff20_inst, reff20_op in H. discriminate H. Qed.

Lemma reff20_not170 : ~ @Equation170 Fin4 reff20_inst.
Proof. unfold Equation170. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff20_inst, reff20_op in H. discriminate H. Qed.

Lemma reff20_not176 : ~ @Equation176 Fin4 reff20_inst.
Proof. unfold Equation176. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff20_inst, reff20_op in H. discriminate H. Qed.

Lemma reff20_not177 : ~ @Equation177 Fin4 reff20_inst.
Proof. unfold Equation177. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff20_inst, reff20_op in H. discriminate H. Qed.

Lemma reff20_not179 : ~ @Equation179 Fin4 reff20_inst.
Proof. unfold Equation179. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff20_inst, reff20_op in H. discriminate H. Qed.

Lemma reff20_not206 : ~ @Equation206 Fin4 reff20_inst.
Proof. unfold Equation206. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff20_inst, reff20_op in H. discriminate H. Qed.

Lemma reff20_not209 : ~ @Equation209 Fin4 reff20_inst.
Proof. unfold Equation209. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff20_inst, reff20_op in H. discriminate H. Qed.

Lemma reff20_not211 : ~ @Equation211 Fin4 reff20_inst.
Proof. unfold Equation211. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff20_inst, reff20_op in H. discriminate H. Qed.

Lemma reff20_not212 : ~ @Equation212 Fin4 reff20_inst.
Proof. unfold Equation212. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff20_inst, reff20_op in H. discriminate H. Qed.

Lemma reff20_not219 : ~ @Equation219 Fin4 reff20_inst.
Proof. unfold Equation219. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff20_inst, reff20_op in H. discriminate H. Qed.

Lemma reff20_not221 : ~ @Equation221 Fin4 reff20_inst.
Proof. unfold Equation221. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff20_inst, reff20_op in H. discriminate H. Qed.

Lemma reff20_not222 : ~ @Equation222 Fin4 reff20_inst.
Proof. unfold Equation222. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff20_inst, reff20_op in H. discriminate H. Qed.

Lemma reff20_not228 : ~ @Equation228 Fin4 reff20_inst.
Proof. unfold Equation228. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff20_inst, reff20_op in H. discriminate H. Qed.

Lemma reff20_not229 : ~ @Equation229 Fin4 reff20_inst.
Proof. unfold Equation229. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff20_inst, reff20_op in H. discriminate H. Qed.

Lemma reff20_not231 : ~ @Equation231 Fin4 reff20_inst.
Proof. unfold Equation231. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff20_inst, reff20_op in H. discriminate H. Qed.

Lemma reff20_not258 : ~ @Equation258 Fin4 reff20_inst.
Proof. unfold Equation258. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff20_inst, reff20_op in H. discriminate H. Qed.

Lemma reff20_not261 : ~ @Equation261 Fin4 reff20_inst.
Proof. unfold Equation261. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff20_inst, reff20_op in H. discriminate H. Qed.

Lemma reff20_not263 : ~ @Equation263 Fin4 reff20_inst.
Proof. unfold Equation263. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff20_inst, reff20_op in H. discriminate H. Qed.

Lemma reff20_not264 : ~ @Equation264 Fin4 reff20_inst.
Proof. unfold Equation264. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff20_inst, reff20_op in H. discriminate H. Qed.

Lemma reff20_not271 : ~ @Equation271 Fin4 reff20_inst.
Proof. unfold Equation271. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff20_inst, reff20_op in H. discriminate H. Qed.

Lemma reff20_not273 : ~ @Equation273 Fin4 reff20_inst.
Proof. unfold Equation273. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff20_inst, reff20_op in H. discriminate H. Qed.

Lemma reff20_not274 : ~ @Equation274 Fin4 reff20_inst.
Proof. unfold Equation274. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff20_inst, reff20_op in H. discriminate H. Qed.

Lemma reff20_not280 : ~ @Equation280 Fin4 reff20_inst.
Proof. unfold Equation280. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff20_inst, reff20_op in H. discriminate H. Qed.

Lemma reff20_not281 : ~ @Equation281 Fin4 reff20_inst.
Proof. unfold Equation281. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff20_inst, reff20_op in H. discriminate H. Qed.

Lemma reff20_not283 : ~ @Equation283 Fin4 reff20_inst.
Proof. unfold Equation283. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff20_inst, reff20_op in H. discriminate H. Qed.

Lemma reff20_not412 : ~ @Equation412 Fin4 reff20_inst.
Proof. unfold Equation412. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff20_inst, reff20_op in H. discriminate H. Qed.

Lemma reff20_not413 : ~ @Equation413 Fin4 reff20_inst.
Proof. unfold Equation413. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff20_inst, reff20_op in H. discriminate H. Qed.

Lemma reff20_not414 : ~ @Equation414 Fin4 reff20_inst.
Proof. unfold Equation414. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff20_inst, reff20_op in H. discriminate H. Qed.

Lemma reff20_not416 : ~ @Equation416 Fin4 reff20_inst.
Proof. unfold Equation416. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff20_inst, reff20_op in H. discriminate H. Qed.

Lemma reff20_not417 : ~ @Equation417 Fin4 reff20_inst.
Proof. unfold Equation417. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff20_inst, reff20_op in H. discriminate H. Qed.

Lemma reff20_not419 : ~ @Equation419 Fin4 reff20_inst.
Proof. unfold Equation419. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff20_inst, reff20_op in H. discriminate H. Qed.

Lemma reff20_not420 : ~ @Equation420 Fin4 reff20_inst.
Proof. unfold Equation420. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff20_inst, reff20_op in H. discriminate H. Qed.

Lemma reff20_not426 : ~ @Equation426 Fin4 reff20_inst.
Proof. unfold Equation426. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff20_inst, reff20_op in H. discriminate H. Qed.

Lemma reff20_not427 : ~ @Equation427 Fin4 reff20_inst.
Proof. unfold Equation427. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff20_inst, reff20_op in H. discriminate H. Qed.

Lemma reff20_not429 : ~ @Equation429 Fin4 reff20_inst.
Proof. unfold Equation429. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff20_inst, reff20_op in H. discriminate H. Qed.

Lemma reff20_not430 : ~ @Equation430 Fin4 reff20_inst.
Proof. unfold Equation430. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff20_inst, reff20_op in H. discriminate H. Qed.

Lemma reff20_not436 : ~ @Equation436 Fin4 reff20_inst.
Proof. unfold Equation436. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff20_inst, reff20_op in H. discriminate H. Qed.

Lemma reff20_not437 : ~ @Equation437 Fin4 reff20_inst.
Proof. unfold Equation437. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff20_inst, reff20_op in H. discriminate H. Qed.

Lemma reff20_not439 : ~ @Equation439 Fin4 reff20_inst.
Proof. unfold Equation439. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff20_inst, reff20_op in H. discriminate H. Qed.

Lemma reff20_not440 : ~ @Equation440 Fin4 reff20_inst.
Proof. unfold Equation440. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff20_inst, reff20_op in H. discriminate H. Qed.

Lemma reff20_not463 : ~ @Equation463 Fin4 reff20_inst.
Proof. unfold Equation463. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff20_inst, reff20_op in H. discriminate H. Qed.

Lemma reff20_not464 : ~ @Equation464 Fin4 reff20_inst.
Proof. unfold Equation464. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff20_inst, reff20_op in H. discriminate H. Qed.

Lemma reff20_not466 : ~ @Equation466 Fin4 reff20_inst.
Proof. unfold Equation466. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff20_inst, reff20_op in H. discriminate H. Qed.

Lemma reff20_not467 : ~ @Equation467 Fin4 reff20_inst.
Proof. unfold Equation467. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff20_inst, reff20_op in H. discriminate H. Qed.

Lemma reff20_not473 : ~ @Equation473 Fin4 reff20_inst.
Proof. unfold Equation473. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff20_inst, reff20_op in H. discriminate H. Qed.

Lemma reff20_not474 : ~ @Equation474 Fin4 reff20_inst.
Proof. unfold Equation474. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff20_inst, reff20_op in H. discriminate H. Qed.

Lemma reff20_not476 : ~ @Equation476 Fin4 reff20_inst.
Proof. unfold Equation476. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff20_inst, reff20_op in H. discriminate H. Qed.

Lemma reff20_not477 : ~ @Equation477 Fin4 reff20_inst.
Proof. unfold Equation477. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff20_inst, reff20_op in H. discriminate H. Qed.

Lemma reff20_not500 : ~ @Equation500 Fin4 reff20_inst.
Proof. unfold Equation500. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff20_inst, reff20_op in H. discriminate H. Qed.

Lemma reff20_not501 : ~ @Equation501 Fin4 reff20_inst.
Proof. unfold Equation501. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff20_inst, reff20_op in H. discriminate H. Qed.

Lemma reff20_not503 : ~ @Equation503 Fin4 reff20_inst.
Proof. unfold Equation503. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff20_inst, reff20_op in H. discriminate H. Qed.

Lemma reff20_not504 : ~ @Equation504 Fin4 reff20_inst.
Proof. unfold Equation504. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff20_inst, reff20_op in H. discriminate H. Qed.

Lemma reff20_not510 : ~ @Equation510 Fin4 reff20_inst.
Proof. unfold Equation510. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff20_inst, reff20_op in H. discriminate H. Qed.

Lemma reff20_not511 : ~ @Equation511 Fin4 reff20_inst.
Proof. unfold Equation511. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff20_inst, reff20_op in H. discriminate H. Qed.

Lemma reff20_not513 : ~ @Equation513 Fin4 reff20_inst.
Proof. unfold Equation513. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff20_inst, reff20_op in H. discriminate H. Qed.

Lemma reff20_not615 : ~ @Equation615 Fin4 reff20_inst.
Proof. unfold Equation615. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff20_inst, reff20_op in H. discriminate H. Qed.

Lemma reff20_not616 : ~ @Equation616 Fin4 reff20_inst.
Proof. unfold Equation616. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff20_inst, reff20_op in H. discriminate H. Qed.

Lemma reff20_not617 : ~ @Equation617 Fin4 reff20_inst.
Proof. unfold Equation617. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff20_inst, reff20_op in H. discriminate H. Qed.

Lemma reff20_not619 : ~ @Equation619 Fin4 reff20_inst.
Proof. unfold Equation619. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff20_inst, reff20_op in H. discriminate H. Qed.

Lemma reff20_not620 : ~ @Equation620 Fin4 reff20_inst.
Proof. unfold Equation620. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff20_inst, reff20_op in H. discriminate H. Qed.

Lemma reff20_not622 : ~ @Equation622 Fin4 reff20_inst.
Proof. unfold Equation622. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff20_inst, reff20_op in H. discriminate H. Qed.

Lemma reff20_not623 : ~ @Equation623 Fin4 reff20_inst.
Proof. unfold Equation623. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff20_inst, reff20_op in H. discriminate H. Qed.

Lemma reff20_not629 : ~ @Equation629 Fin4 reff20_inst.
Proof. unfold Equation629. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff20_inst, reff20_op in H. discriminate H. Qed.

Lemma reff20_not630 : ~ @Equation630 Fin4 reff20_inst.
Proof. unfold Equation630. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff20_inst, reff20_op in H. discriminate H. Qed.

Lemma reff20_not632 : ~ @Equation632 Fin4 reff20_inst.
Proof. unfold Equation632. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff20_inst, reff20_op in H. discriminate H. Qed.

Lemma reff20_not633 : ~ @Equation633 Fin4 reff20_inst.
Proof. unfold Equation633. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff20_inst, reff20_op in H. discriminate H. Qed.

Lemma reff20_not639 : ~ @Equation639 Fin4 reff20_inst.
Proof. unfold Equation639. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff20_inst, reff20_op in H. discriminate H. Qed.

Lemma reff20_not640 : ~ @Equation640 Fin4 reff20_inst.
Proof. unfold Equation640. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff20_inst, reff20_op in H. discriminate H. Qed.

Lemma reff20_not642 : ~ @Equation642 Fin4 reff20_inst.
Proof. unfold Equation642. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff20_inst, reff20_op in H. discriminate H. Qed.

Lemma reff20_not643 : ~ @Equation643 Fin4 reff20_inst.
Proof. unfold Equation643. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff20_inst, reff20_op in H. discriminate H. Qed.

Lemma reff20_not666 : ~ @Equation666 Fin4 reff20_inst.
Proof. unfold Equation666. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff20_inst, reff20_op in H. discriminate H. Qed.

Lemma reff20_not667 : ~ @Equation667 Fin4 reff20_inst.
Proof. unfold Equation667. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff20_inst, reff20_op in H. discriminate H. Qed.

Lemma reff20_not669 : ~ @Equation669 Fin4 reff20_inst.
Proof. unfold Equation669. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff20_inst, reff20_op in H. discriminate H. Qed.

Lemma reff20_not670 : ~ @Equation670 Fin4 reff20_inst.
Proof. unfold Equation670. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff20_inst, reff20_op in H. discriminate H. Qed.

Lemma reff20_not676 : ~ @Equation676 Fin4 reff20_inst.
Proof. unfold Equation676. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff20_inst, reff20_op in H. discriminate H. Qed.

Lemma reff20_not677 : ~ @Equation677 Fin4 reff20_inst.
Proof. unfold Equation677. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff20_inst, reff20_op in H. discriminate H. Qed.

Lemma reff20_not679 : ~ @Equation679 Fin4 reff20_inst.
Proof. unfold Equation679. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff20_inst, reff20_op in H. discriminate H. Qed.

Lemma reff20_not680 : ~ @Equation680 Fin4 reff20_inst.
Proof. unfold Equation680. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff20_inst, reff20_op in H. discriminate H. Qed.

Lemma reff20_not703 : ~ @Equation703 Fin4 reff20_inst.
Proof. unfold Equation703. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff20_inst, reff20_op in H. discriminate H. Qed.

Lemma reff20_not704 : ~ @Equation704 Fin4 reff20_inst.
Proof. unfold Equation704. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff20_inst, reff20_op in H. discriminate H. Qed.

Lemma reff20_not706 : ~ @Equation706 Fin4 reff20_inst.
Proof. unfold Equation706. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff20_inst, reff20_op in H. discriminate H. Qed.

Lemma reff20_not707 : ~ @Equation707 Fin4 reff20_inst.
Proof. unfold Equation707. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff20_inst, reff20_op in H. discriminate H. Qed.

Lemma reff20_not713 : ~ @Equation713 Fin4 reff20_inst.
Proof. unfold Equation713. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff20_inst, reff20_op in H. discriminate H. Qed.

Lemma reff20_not714 : ~ @Equation714 Fin4 reff20_inst.
Proof. unfold Equation714. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff20_inst, reff20_op in H. discriminate H. Qed.

Lemma reff20_not716 : ~ @Equation716 Fin4 reff20_inst.
Proof. unfold Equation716. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff20_inst, reff20_op in H. discriminate H. Qed.

Lemma reff20_not818 : ~ @Equation818 Fin4 reff20_inst.
Proof. unfold Equation818. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff20_inst, reff20_op in H. discriminate H. Qed.

Lemma reff20_not819 : ~ @Equation819 Fin4 reff20_inst.
Proof. unfold Equation819. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff20_inst, reff20_op in H. discriminate H. Qed.

Lemma reff20_not820 : ~ @Equation820 Fin4 reff20_inst.
Proof. unfold Equation820. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff20_inst, reff20_op in H. discriminate H. Qed.

Lemma reff20_not822 : ~ @Equation822 Fin4 reff20_inst.
Proof. unfold Equation822. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff20_inst, reff20_op in H. discriminate H. Qed.

Lemma reff20_not823 : ~ @Equation823 Fin4 reff20_inst.
Proof. unfold Equation823. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff20_inst, reff20_op in H. discriminate H. Qed.

Lemma reff20_not825 : ~ @Equation825 Fin4 reff20_inst.
Proof. unfold Equation825. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff20_inst, reff20_op in H. discriminate H. Qed.

Lemma reff20_not826 : ~ @Equation826 Fin4 reff20_inst.
Proof. unfold Equation826. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff20_inst, reff20_op in H. discriminate H. Qed.

Lemma reff20_not832 : ~ @Equation832 Fin4 reff20_inst.
Proof. unfold Equation832. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff20_inst, reff20_op in H. discriminate H. Qed.

Lemma reff20_not833 : ~ @Equation833 Fin4 reff20_inst.
Proof. unfold Equation833. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff20_inst, reff20_op in H. discriminate H. Qed.

Lemma reff20_not835 : ~ @Equation835 Fin4 reff20_inst.
Proof. unfold Equation835. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff20_inst, reff20_op in H. discriminate H. Qed.

Lemma reff20_not836 : ~ @Equation836 Fin4 reff20_inst.
Proof. unfold Equation836. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff20_inst, reff20_op in H. discriminate H. Qed.

Lemma reff20_not842 : ~ @Equation842 Fin4 reff20_inst.
Proof. unfold Equation842. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff20_inst, reff20_op in H. discriminate H. Qed.

Lemma reff20_not843 : ~ @Equation843 Fin4 reff20_inst.
Proof. unfold Equation843. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff20_inst, reff20_op in H. discriminate H. Qed.

Lemma reff20_not845 : ~ @Equation845 Fin4 reff20_inst.
Proof. unfold Equation845. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff20_inst, reff20_op in H. discriminate H. Qed.

Lemma reff20_not846 : ~ @Equation846 Fin4 reff20_inst.
Proof. unfold Equation846. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff20_inst, reff20_op in H. discriminate H. Qed.

Lemma reff20_not869 : ~ @Equation869 Fin4 reff20_inst.
Proof. unfold Equation869. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff20_inst, reff20_op in H. discriminate H. Qed.

Lemma reff20_not870 : ~ @Equation870 Fin4 reff20_inst.
Proof. unfold Equation870. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff20_inst, reff20_op in H. discriminate H. Qed.

Lemma reff20_not872 : ~ @Equation872 Fin4 reff20_inst.
Proof. unfold Equation872. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff20_inst, reff20_op in H. discriminate H. Qed.

Lemma reff20_not873 : ~ @Equation873 Fin4 reff20_inst.
Proof. unfold Equation873. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff20_inst, reff20_op in H. discriminate H. Qed.

Lemma reff20_not879 : ~ @Equation879 Fin4 reff20_inst.
Proof. unfold Equation879. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff20_inst, reff20_op in H. discriminate H. Qed.

Lemma reff20_not880 : ~ @Equation880 Fin4 reff20_inst.
Proof. unfold Equation880. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff20_inst, reff20_op in H. discriminate H. Qed.

Lemma reff20_not882 : ~ @Equation882 Fin4 reff20_inst.
Proof. unfold Equation882. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff20_inst, reff20_op in H. discriminate H. Qed.

Lemma reff20_not883 : ~ @Equation883 Fin4 reff20_inst.
Proof. unfold Equation883. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff20_inst, reff20_op in H. discriminate H. Qed.

Lemma reff20_not906 : ~ @Equation906 Fin4 reff20_inst.
Proof. unfold Equation906. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff20_inst, reff20_op in H. discriminate H. Qed.

Lemma reff20_not907 : ~ @Equation907 Fin4 reff20_inst.
Proof. unfold Equation907. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff20_inst, reff20_op in H. discriminate H. Qed.

Lemma reff20_not909 : ~ @Equation909 Fin4 reff20_inst.
Proof. unfold Equation909. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff20_inst, reff20_op in H. discriminate H. Qed.

Lemma reff20_not910 : ~ @Equation910 Fin4 reff20_inst.
Proof. unfold Equation910. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff20_inst, reff20_op in H. discriminate H. Qed.

Lemma reff20_not916 : ~ @Equation916 Fin4 reff20_inst.
Proof. unfold Equation916. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff20_inst, reff20_op in H. discriminate H. Qed.

Lemma reff20_not917 : ~ @Equation917 Fin4 reff20_inst.
Proof. unfold Equation917. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff20_inst, reff20_op in H. discriminate H. Qed.

Lemma reff20_not919 : ~ @Equation919 Fin4 reff20_inst.
Proof. unfold Equation919. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff20_inst, reff20_op in H. discriminate H. Qed.

Lemma reff20_not1021 : ~ @Equation1021 Fin4 reff20_inst.
Proof. unfold Equation1021. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff20_inst, reff20_op in H. discriminate H. Qed.

Lemma reff20_not1022 : ~ @Equation1022 Fin4 reff20_inst.
Proof. unfold Equation1022. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff20_inst, reff20_op in H. discriminate H. Qed.

Lemma reff20_not1023 : ~ @Equation1023 Fin4 reff20_inst.
Proof. unfold Equation1023. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff20_inst, reff20_op in H. discriminate H. Qed.

Lemma reff20_not1025 : ~ @Equation1025 Fin4 reff20_inst.
Proof. unfold Equation1025. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff20_inst, reff20_op in H. discriminate H. Qed.

Lemma reff20_not1026 : ~ @Equation1026 Fin4 reff20_inst.
Proof. unfold Equation1026. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff20_inst, reff20_op in H. discriminate H. Qed.

Lemma reff20_not1028 : ~ @Equation1028 Fin4 reff20_inst.
Proof. unfold Equation1028. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff20_inst, reff20_op in H. discriminate H. Qed.

Lemma reff20_not1029 : ~ @Equation1029 Fin4 reff20_inst.
Proof. unfold Equation1029. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff20_inst, reff20_op in H. discriminate H. Qed.

Lemma reff20_not1035 : ~ @Equation1035 Fin4 reff20_inst.
Proof. unfold Equation1035. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff20_inst, reff20_op in H. discriminate H. Qed.

Lemma reff20_not1036 : ~ @Equation1036 Fin4 reff20_inst.
Proof. unfold Equation1036. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff20_inst, reff20_op in H. discriminate H. Qed.

Lemma reff20_not1038 : ~ @Equation1038 Fin4 reff20_inst.
Proof. unfold Equation1038. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff20_inst, reff20_op in H. discriminate H. Qed.

Lemma reff20_not1039 : ~ @Equation1039 Fin4 reff20_inst.
Proof. unfold Equation1039. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff20_inst, reff20_op in H. discriminate H. Qed.

Lemma reff20_not1045 : ~ @Equation1045 Fin4 reff20_inst.
Proof. unfold Equation1045. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff20_inst, reff20_op in H. discriminate H. Qed.

Lemma reff20_not1046 : ~ @Equation1046 Fin4 reff20_inst.
Proof. unfold Equation1046. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff20_inst, reff20_op in H. discriminate H. Qed.

Lemma reff20_not1048 : ~ @Equation1048 Fin4 reff20_inst.
Proof. unfold Equation1048. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff20_inst, reff20_op in H. discriminate H. Qed.

Lemma reff20_not1049 : ~ @Equation1049 Fin4 reff20_inst.
Proof. unfold Equation1049. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff20_inst, reff20_op in H. discriminate H. Qed.

Lemma reff20_not1072 : ~ @Equation1072 Fin4 reff20_inst.
Proof. unfold Equation1072. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff20_inst, reff20_op in H. discriminate H. Qed.

Lemma reff20_not1073 : ~ @Equation1073 Fin4 reff20_inst.
Proof. unfold Equation1073. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff20_inst, reff20_op in H. discriminate H. Qed.

Lemma reff20_not1075 : ~ @Equation1075 Fin4 reff20_inst.
Proof. unfold Equation1075. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff20_inst, reff20_op in H. discriminate H. Qed.

Lemma reff20_not1076 : ~ @Equation1076 Fin4 reff20_inst.
Proof. unfold Equation1076. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff20_inst, reff20_op in H. discriminate H. Qed.

Lemma reff20_not1082 : ~ @Equation1082 Fin4 reff20_inst.
Proof. unfold Equation1082. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff20_inst, reff20_op in H. discriminate H. Qed.

Lemma reff20_not1083 : ~ @Equation1083 Fin4 reff20_inst.
Proof. unfold Equation1083. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff20_inst, reff20_op in H. discriminate H. Qed.

Lemma reff20_not1085 : ~ @Equation1085 Fin4 reff20_inst.
Proof. unfold Equation1085. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff20_inst, reff20_op in H. discriminate H. Qed.

Lemma reff20_not1086 : ~ @Equation1086 Fin4 reff20_inst.
Proof. unfold Equation1086. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff20_inst, reff20_op in H. discriminate H. Qed.

Lemma reff20_not1109 : ~ @Equation1109 Fin4 reff20_inst.
Proof. unfold Equation1109. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff20_inst, reff20_op in H. discriminate H. Qed.

Lemma reff20_not1110 : ~ @Equation1110 Fin4 reff20_inst.
Proof. unfold Equation1110. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff20_inst, reff20_op in H. discriminate H. Qed.

Lemma reff20_not1112 : ~ @Equation1112 Fin4 reff20_inst.
Proof. unfold Equation1112. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff20_inst, reff20_op in H. discriminate H. Qed.

Lemma reff20_not1113 : ~ @Equation1113 Fin4 reff20_inst.
Proof. unfold Equation1113. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff20_inst, reff20_op in H. discriminate H. Qed.

Lemma reff20_not1119 : ~ @Equation1119 Fin4 reff20_inst.
Proof. unfold Equation1119. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff20_inst, reff20_op in H. discriminate H. Qed.

Lemma reff20_not1120 : ~ @Equation1120 Fin4 reff20_inst.
Proof. unfold Equation1120. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff20_inst, reff20_op in H. discriminate H. Qed.

Lemma reff20_not1122 : ~ @Equation1122 Fin4 reff20_inst.
Proof. unfold Equation1122. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff20_inst, reff20_op in H. discriminate H. Qed.

Lemma reff20_not1224 : ~ @Equation1224 Fin4 reff20_inst.
Proof. unfold Equation1224. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff20_inst, reff20_op in H. discriminate H. Qed.

Lemma reff20_not1225 : ~ @Equation1225 Fin4 reff20_inst.
Proof. unfold Equation1225. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff20_inst, reff20_op in H. discriminate H. Qed.

Lemma reff20_not1226 : ~ @Equation1226 Fin4 reff20_inst.
Proof. unfold Equation1226. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff20_inst, reff20_op in H. discriminate H. Qed.

Lemma reff20_not1228 : ~ @Equation1228 Fin4 reff20_inst.
Proof. unfold Equation1228. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff20_inst, reff20_op in H. discriminate H. Qed.

Lemma reff20_not1229 : ~ @Equation1229 Fin4 reff20_inst.
Proof. unfold Equation1229. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff20_inst, reff20_op in H. discriminate H. Qed.

Lemma reff20_not1231 : ~ @Equation1231 Fin4 reff20_inst.
Proof. unfold Equation1231. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff20_inst, reff20_op in H. discriminate H. Qed.

Lemma reff20_not1232 : ~ @Equation1232 Fin4 reff20_inst.
Proof. unfold Equation1232. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff20_inst, reff20_op in H. discriminate H. Qed.

Lemma reff20_not1238 : ~ @Equation1238 Fin4 reff20_inst.
Proof. unfold Equation1238. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff20_inst, reff20_op in H. discriminate H. Qed.

Lemma reff20_not1239 : ~ @Equation1239 Fin4 reff20_inst.
Proof. unfold Equation1239. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff20_inst, reff20_op in H. discriminate H. Qed.

Lemma reff20_not1241 : ~ @Equation1241 Fin4 reff20_inst.
Proof. unfold Equation1241. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff20_inst, reff20_op in H. discriminate H. Qed.

Lemma reff20_not1242 : ~ @Equation1242 Fin4 reff20_inst.
Proof. unfold Equation1242. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff20_inst, reff20_op in H. discriminate H. Qed.

Lemma reff20_not1248 : ~ @Equation1248 Fin4 reff20_inst.
Proof. unfold Equation1248. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff20_inst, reff20_op in H. discriminate H. Qed.

Lemma reff20_not1249 : ~ @Equation1249 Fin4 reff20_inst.
Proof. unfold Equation1249. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff20_inst, reff20_op in H. discriminate H. Qed.

Lemma reff20_not1251 : ~ @Equation1251 Fin4 reff20_inst.
Proof. unfold Equation1251. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff20_inst, reff20_op in H. discriminate H. Qed.

Lemma reff20_not1252 : ~ @Equation1252 Fin4 reff20_inst.
Proof. unfold Equation1252. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff20_inst, reff20_op in H. discriminate H. Qed.

Lemma reff20_not1275 : ~ @Equation1275 Fin4 reff20_inst.
Proof. unfold Equation1275. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff20_inst, reff20_op in H. discriminate H. Qed.

Lemma reff20_not1276 : ~ @Equation1276 Fin4 reff20_inst.
Proof. unfold Equation1276. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff20_inst, reff20_op in H. discriminate H. Qed.

Lemma reff20_not1278 : ~ @Equation1278 Fin4 reff20_inst.
Proof. unfold Equation1278. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff20_inst, reff20_op in H. discriminate H. Qed.

Lemma reff20_not1279 : ~ @Equation1279 Fin4 reff20_inst.
Proof. unfold Equation1279. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff20_inst, reff20_op in H. discriminate H. Qed.

Lemma reff20_not1285 : ~ @Equation1285 Fin4 reff20_inst.
Proof. unfold Equation1285. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff20_inst, reff20_op in H. discriminate H. Qed.

Lemma reff20_not1286 : ~ @Equation1286 Fin4 reff20_inst.
Proof. unfold Equation1286. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff20_inst, reff20_op in H. discriminate H. Qed.

Lemma reff20_not1288 : ~ @Equation1288 Fin4 reff20_inst.
Proof. unfold Equation1288. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff20_inst, reff20_op in H. discriminate H. Qed.

Lemma reff20_not1289 : ~ @Equation1289 Fin4 reff20_inst.
Proof. unfold Equation1289. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff20_inst, reff20_op in H. discriminate H. Qed.

Lemma reff20_not1312 : ~ @Equation1312 Fin4 reff20_inst.
Proof. unfold Equation1312. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff20_inst, reff20_op in H. discriminate H. Qed.

Lemma reff20_not1313 : ~ @Equation1313 Fin4 reff20_inst.
Proof. unfold Equation1313. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff20_inst, reff20_op in H. discriminate H. Qed.

Lemma reff20_not1315 : ~ @Equation1315 Fin4 reff20_inst.
Proof. unfold Equation1315. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff20_inst, reff20_op in H. discriminate H. Qed.

Lemma reff20_not1316 : ~ @Equation1316 Fin4 reff20_inst.
Proof. unfold Equation1316. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff20_inst, reff20_op in H. discriminate H. Qed.

Lemma reff20_not1322 : ~ @Equation1322 Fin4 reff20_inst.
Proof. unfold Equation1322. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff20_inst, reff20_op in H. discriminate H. Qed.

Lemma reff20_not1323 : ~ @Equation1323 Fin4 reff20_inst.
Proof. unfold Equation1323. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff20_inst, reff20_op in H. discriminate H. Qed.

Lemma reff20_not1325 : ~ @Equation1325 Fin4 reff20_inst.
Proof. unfold Equation1325. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff20_inst, reff20_op in H. discriminate H. Qed.

Lemma reff20_not1427 : ~ @Equation1427 Fin4 reff20_inst.
Proof. unfold Equation1427. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff20_inst, reff20_op in H. discriminate H. Qed.

Lemma reff20_not1428 : ~ @Equation1428 Fin4 reff20_inst.
Proof. unfold Equation1428. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff20_inst, reff20_op in H. discriminate H. Qed.

Lemma reff20_not1429 : ~ @Equation1429 Fin4 reff20_inst.
Proof. unfold Equation1429. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff20_inst, reff20_op in H. discriminate H. Qed.

Lemma reff20_not1431 : ~ @Equation1431 Fin4 reff20_inst.
Proof. unfold Equation1431. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff20_inst, reff20_op in H. discriminate H. Qed.

Lemma reff20_not1432 : ~ @Equation1432 Fin4 reff20_inst.
Proof. unfold Equation1432. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff20_inst, reff20_op in H. discriminate H. Qed.

Lemma reff20_not1434 : ~ @Equation1434 Fin4 reff20_inst.
Proof. unfold Equation1434. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff20_inst, reff20_op in H. discriminate H. Qed.

Lemma reff20_not1435 : ~ @Equation1435 Fin4 reff20_inst.
Proof. unfold Equation1435. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff20_inst, reff20_op in H. discriminate H. Qed.

Lemma reff20_not1441 : ~ @Equation1441 Fin4 reff20_inst.
Proof. unfold Equation1441. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff20_inst, reff20_op in H. discriminate H. Qed.

Lemma reff20_not1442 : ~ @Equation1442 Fin4 reff20_inst.
Proof. unfold Equation1442. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff20_inst, reff20_op in H. discriminate H. Qed.

Lemma reff20_not1444 : ~ @Equation1444 Fin4 reff20_inst.
Proof. unfold Equation1444. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff20_inst, reff20_op in H. discriminate H. Qed.

Lemma reff20_not1445 : ~ @Equation1445 Fin4 reff20_inst.
Proof. unfold Equation1445. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff20_inst, reff20_op in H. discriminate H. Qed.

Lemma reff20_not1451 : ~ @Equation1451 Fin4 reff20_inst.
Proof. unfold Equation1451. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff20_inst, reff20_op in H. discriminate H. Qed.

Lemma reff20_not1452 : ~ @Equation1452 Fin4 reff20_inst.
Proof. unfold Equation1452. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff20_inst, reff20_op in H. discriminate H. Qed.

Lemma reff20_not1454 : ~ @Equation1454 Fin4 reff20_inst.
Proof. unfold Equation1454. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff20_inst, reff20_op in H. discriminate H. Qed.

Lemma reff20_not1455 : ~ @Equation1455 Fin4 reff20_inst.
Proof. unfold Equation1455. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff20_inst, reff20_op in H. discriminate H. Qed.

Lemma reff20_not1478 : ~ @Equation1478 Fin4 reff20_inst.
Proof. unfold Equation1478. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff20_inst, reff20_op in H. discriminate H. Qed.

Lemma reff20_not1479 : ~ @Equation1479 Fin4 reff20_inst.
Proof. unfold Equation1479. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff20_inst, reff20_op in H. discriminate H. Qed.

Lemma reff20_not1481 : ~ @Equation1481 Fin4 reff20_inst.
Proof. unfold Equation1481. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff20_inst, reff20_op in H. discriminate H. Qed.

Lemma reff20_not1482 : ~ @Equation1482 Fin4 reff20_inst.
Proof. unfold Equation1482. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff20_inst, reff20_op in H. discriminate H. Qed.

Lemma reff20_not1488 : ~ @Equation1488 Fin4 reff20_inst.
Proof. unfold Equation1488. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff20_inst, reff20_op in H. discriminate H. Qed.

Lemma reff20_not1489 : ~ @Equation1489 Fin4 reff20_inst.
Proof. unfold Equation1489. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff20_inst, reff20_op in H. discriminate H. Qed.

Lemma reff20_not1491 : ~ @Equation1491 Fin4 reff20_inst.
Proof. unfold Equation1491. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff20_inst, reff20_op in H. discriminate H. Qed.

Lemma reff20_not1492 : ~ @Equation1492 Fin4 reff20_inst.
Proof. unfold Equation1492. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff20_inst, reff20_op in H. discriminate H. Qed.

Lemma reff20_not1515 : ~ @Equation1515 Fin4 reff20_inst.
Proof. unfold Equation1515. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff20_inst, reff20_op in H. discriminate H. Qed.

Lemma reff20_not1516 : ~ @Equation1516 Fin4 reff20_inst.
Proof. unfold Equation1516. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff20_inst, reff20_op in H. discriminate H. Qed.

Lemma reff20_not1518 : ~ @Equation1518 Fin4 reff20_inst.
Proof. unfold Equation1518. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff20_inst, reff20_op in H. discriminate H. Qed.

Lemma reff20_not1519 : ~ @Equation1519 Fin4 reff20_inst.
Proof. unfold Equation1519. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff20_inst, reff20_op in H. discriminate H. Qed.

Lemma reff20_not1525 : ~ @Equation1525 Fin4 reff20_inst.
Proof. unfold Equation1525. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff20_inst, reff20_op in H. discriminate H. Qed.

Lemma reff20_not1526 : ~ @Equation1526 Fin4 reff20_inst.
Proof. unfold Equation1526. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff20_inst, reff20_op in H. discriminate H. Qed.

Lemma reff20_not1528 : ~ @Equation1528 Fin4 reff20_inst.
Proof. unfold Equation1528. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff20_inst, reff20_op in H. discriminate H. Qed.

Lemma reff20_not1630 : ~ @Equation1630 Fin4 reff20_inst.
Proof. unfold Equation1630. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff20_inst, reff20_op in H. discriminate H. Qed.

Lemma reff20_not1631 : ~ @Equation1631 Fin4 reff20_inst.
Proof. unfold Equation1631. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff20_inst, reff20_op in H. discriminate H. Qed.

Lemma reff20_not1632 : ~ @Equation1632 Fin4 reff20_inst.
Proof. unfold Equation1632. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff20_inst, reff20_op in H. discriminate H. Qed.

Lemma reff20_not1634 : ~ @Equation1634 Fin4 reff20_inst.
Proof. unfold Equation1634. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff20_inst, reff20_op in H. discriminate H. Qed.

Lemma reff20_not1635 : ~ @Equation1635 Fin4 reff20_inst.
Proof. unfold Equation1635. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff20_inst, reff20_op in H. discriminate H. Qed.

Lemma reff20_not1637 : ~ @Equation1637 Fin4 reff20_inst.
Proof. unfold Equation1637. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff20_inst, reff20_op in H. discriminate H. Qed.

Lemma reff20_not1638 : ~ @Equation1638 Fin4 reff20_inst.
Proof. unfold Equation1638. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff20_inst, reff20_op in H. discriminate H. Qed.

Lemma reff20_not1644 : ~ @Equation1644 Fin4 reff20_inst.
Proof. unfold Equation1644. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff20_inst, reff20_op in H. discriminate H. Qed.

Lemma reff20_not1645 : ~ @Equation1645 Fin4 reff20_inst.
Proof. unfold Equation1645. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff20_inst, reff20_op in H. discriminate H. Qed.

Lemma reff20_not1647 : ~ @Equation1647 Fin4 reff20_inst.
Proof. unfold Equation1647. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff20_inst, reff20_op in H. discriminate H. Qed.

Lemma reff20_not1648 : ~ @Equation1648 Fin4 reff20_inst.
Proof. unfold Equation1648. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff20_inst, reff20_op in H. discriminate H. Qed.

Lemma reff20_not1654 : ~ @Equation1654 Fin4 reff20_inst.
Proof. unfold Equation1654. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff20_inst, reff20_op in H. discriminate H. Qed.

Lemma reff20_not1655 : ~ @Equation1655 Fin4 reff20_inst.
Proof. unfold Equation1655. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff20_inst, reff20_op in H. discriminate H. Qed.

Lemma reff20_not1657 : ~ @Equation1657 Fin4 reff20_inst.
Proof. unfold Equation1657. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff20_inst, reff20_op in H. discriminate H. Qed.

Lemma reff20_not1658 : ~ @Equation1658 Fin4 reff20_inst.
Proof. unfold Equation1658. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff20_inst, reff20_op in H. discriminate H. Qed.

Lemma reff20_not1681 : ~ @Equation1681 Fin4 reff20_inst.
Proof. unfold Equation1681. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff20_inst, reff20_op in H. discriminate H. Qed.

Lemma reff20_not1682 : ~ @Equation1682 Fin4 reff20_inst.
Proof. unfold Equation1682. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff20_inst, reff20_op in H. discriminate H. Qed.

Lemma reff20_not1684 : ~ @Equation1684 Fin4 reff20_inst.
Proof. unfold Equation1684. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff20_inst, reff20_op in H. discriminate H. Qed.

Lemma reff20_not1685 : ~ @Equation1685 Fin4 reff20_inst.
Proof. unfold Equation1685. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff20_inst, reff20_op in H. discriminate H. Qed.

Lemma reff20_not1691 : ~ @Equation1691 Fin4 reff20_inst.
Proof. unfold Equation1691. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff20_inst, reff20_op in H. discriminate H. Qed.

Lemma reff20_not1692 : ~ @Equation1692 Fin4 reff20_inst.
Proof. unfold Equation1692. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff20_inst, reff20_op in H. discriminate H. Qed.

Lemma reff20_not1694 : ~ @Equation1694 Fin4 reff20_inst.
Proof. unfold Equation1694. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff20_inst, reff20_op in H. discriminate H. Qed.

Lemma reff20_not1695 : ~ @Equation1695 Fin4 reff20_inst.
Proof. unfold Equation1695. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff20_inst, reff20_op in H. discriminate H. Qed.

Lemma reff20_not1718 : ~ @Equation1718 Fin4 reff20_inst.
Proof. unfold Equation1718. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff20_inst, reff20_op in H. discriminate H. Qed.

Lemma reff20_not1719 : ~ @Equation1719 Fin4 reff20_inst.
Proof. unfold Equation1719. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff20_inst, reff20_op in H. discriminate H. Qed.

Lemma reff20_not1721 : ~ @Equation1721 Fin4 reff20_inst.
Proof. unfold Equation1721. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff20_inst, reff20_op in H. discriminate H. Qed.

Lemma reff20_not1722 : ~ @Equation1722 Fin4 reff20_inst.
Proof. unfold Equation1722. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff20_inst, reff20_op in H. discriminate H. Qed.

Lemma reff20_not1728 : ~ @Equation1728 Fin4 reff20_inst.
Proof. unfold Equation1728. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff20_inst, reff20_op in H. discriminate H. Qed.

Lemma reff20_not1729 : ~ @Equation1729 Fin4 reff20_inst.
Proof. unfold Equation1729. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff20_inst, reff20_op in H. discriminate H. Qed.

Lemma reff20_not1731 : ~ @Equation1731 Fin4 reff20_inst.
Proof. unfold Equation1731. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff20_inst, reff20_op in H. discriminate H. Qed.

Lemma reff20_not1833 : ~ @Equation1833 Fin4 reff20_inst.
Proof. unfold Equation1833. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff20_inst, reff20_op in H. discriminate H. Qed.

Lemma reff20_not1834 : ~ @Equation1834 Fin4 reff20_inst.
Proof. unfold Equation1834. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff20_inst, reff20_op in H. discriminate H. Qed.

Lemma reff20_not1835 : ~ @Equation1835 Fin4 reff20_inst.
Proof. unfold Equation1835. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff20_inst, reff20_op in H. discriminate H. Qed.

Lemma reff20_not1837 : ~ @Equation1837 Fin4 reff20_inst.
Proof. unfold Equation1837. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff20_inst, reff20_op in H. discriminate H. Qed.

Lemma reff20_not1838 : ~ @Equation1838 Fin4 reff20_inst.
Proof. unfold Equation1838. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff20_inst, reff20_op in H. discriminate H. Qed.

Lemma reff20_not1840 : ~ @Equation1840 Fin4 reff20_inst.
Proof. unfold Equation1840. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff20_inst, reff20_op in H. discriminate H. Qed.

Lemma reff20_not1841 : ~ @Equation1841 Fin4 reff20_inst.
Proof. unfold Equation1841. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff20_inst, reff20_op in H. discriminate H. Qed.

Lemma reff20_not1847 : ~ @Equation1847 Fin4 reff20_inst.
Proof. unfold Equation1847. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff20_inst, reff20_op in H. discriminate H. Qed.

Lemma reff20_not1848 : ~ @Equation1848 Fin4 reff20_inst.
Proof. unfold Equation1848. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff20_inst, reff20_op in H. discriminate H. Qed.

Lemma reff20_not1850 : ~ @Equation1850 Fin4 reff20_inst.
Proof. unfold Equation1850. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff20_inst, reff20_op in H. discriminate H. Qed.

Lemma reff20_not1851 : ~ @Equation1851 Fin4 reff20_inst.
Proof. unfold Equation1851. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff20_inst, reff20_op in H. discriminate H. Qed.

Lemma reff20_not1857 : ~ @Equation1857 Fin4 reff20_inst.
Proof. unfold Equation1857. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff20_inst, reff20_op in H. discriminate H. Qed.

Lemma reff20_not1858 : ~ @Equation1858 Fin4 reff20_inst.
Proof. unfold Equation1858. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff20_inst, reff20_op in H. discriminate H. Qed.

Lemma reff20_not1860 : ~ @Equation1860 Fin4 reff20_inst.
Proof. unfold Equation1860. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff20_inst, reff20_op in H. discriminate H. Qed.

Lemma reff20_not1861 : ~ @Equation1861 Fin4 reff20_inst.
Proof. unfold Equation1861. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff20_inst, reff20_op in H. discriminate H. Qed.

Lemma reff20_not1884 : ~ @Equation1884 Fin4 reff20_inst.
Proof. unfold Equation1884. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff20_inst, reff20_op in H. discriminate H. Qed.

Lemma reff20_not1885 : ~ @Equation1885 Fin4 reff20_inst.
Proof. unfold Equation1885. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff20_inst, reff20_op in H. discriminate H. Qed.

Lemma reff20_not1887 : ~ @Equation1887 Fin4 reff20_inst.
Proof. unfold Equation1887. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff20_inst, reff20_op in H. discriminate H. Qed.

Lemma reff20_not1888 : ~ @Equation1888 Fin4 reff20_inst.
Proof. unfold Equation1888. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff20_inst, reff20_op in H. discriminate H. Qed.

Lemma reff20_not1894 : ~ @Equation1894 Fin4 reff20_inst.
Proof. unfold Equation1894. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff20_inst, reff20_op in H. discriminate H. Qed.

Lemma reff20_not1895 : ~ @Equation1895 Fin4 reff20_inst.
Proof. unfold Equation1895. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff20_inst, reff20_op in H. discriminate H. Qed.

Lemma reff20_not1897 : ~ @Equation1897 Fin4 reff20_inst.
Proof. unfold Equation1897. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff20_inst, reff20_op in H. discriminate H. Qed.

Lemma reff20_not1898 : ~ @Equation1898 Fin4 reff20_inst.
Proof. unfold Equation1898. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff20_inst, reff20_op in H. discriminate H. Qed.

Lemma reff20_not1921 : ~ @Equation1921 Fin4 reff20_inst.
Proof. unfold Equation1921. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff20_inst, reff20_op in H. discriminate H. Qed.

Lemma reff20_not1922 : ~ @Equation1922 Fin4 reff20_inst.
Proof. unfold Equation1922. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff20_inst, reff20_op in H. discriminate H. Qed.

Lemma reff20_not1924 : ~ @Equation1924 Fin4 reff20_inst.
Proof. unfold Equation1924. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff20_inst, reff20_op in H. discriminate H. Qed.

Lemma reff20_not1925 : ~ @Equation1925 Fin4 reff20_inst.
Proof. unfold Equation1925. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff20_inst, reff20_op in H. discriminate H. Qed.

Lemma reff20_not1931 : ~ @Equation1931 Fin4 reff20_inst.
Proof. unfold Equation1931. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff20_inst, reff20_op in H. discriminate H. Qed.

Lemma reff20_not1932 : ~ @Equation1932 Fin4 reff20_inst.
Proof. unfold Equation1932. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff20_inst, reff20_op in H. discriminate H. Qed.

Lemma reff20_not1934 : ~ @Equation1934 Fin4 reff20_inst.
Proof. unfold Equation1934. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff20_inst, reff20_op in H. discriminate H. Qed.

Lemma reff20_not2036 : ~ @Equation2036 Fin4 reff20_inst.
Proof. unfold Equation2036. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff20_inst, reff20_op in H. discriminate H. Qed.

Lemma reff20_not2037 : ~ @Equation2037 Fin4 reff20_inst.
Proof. unfold Equation2037. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff20_inst, reff20_op in H. discriminate H. Qed.

Lemma reff20_not2038 : ~ @Equation2038 Fin4 reff20_inst.
Proof. unfold Equation2038. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff20_inst, reff20_op in H. discriminate H. Qed.

Lemma reff20_not2040 : ~ @Equation2040 Fin4 reff20_inst.
Proof. unfold Equation2040. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff20_inst, reff20_op in H. discriminate H. Qed.

Lemma reff20_not2041 : ~ @Equation2041 Fin4 reff20_inst.
Proof. unfold Equation2041. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff20_inst, reff20_op in H. discriminate H. Qed.

Lemma reff20_not2043 : ~ @Equation2043 Fin4 reff20_inst.
Proof. unfold Equation2043. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff20_inst, reff20_op in H. discriminate H. Qed.

Lemma reff20_not2044 : ~ @Equation2044 Fin4 reff20_inst.
Proof. unfold Equation2044. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff20_inst, reff20_op in H. discriminate H. Qed.

Lemma reff20_not2050 : ~ @Equation2050 Fin4 reff20_inst.
Proof. unfold Equation2050. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff20_inst, reff20_op in H. discriminate H. Qed.

Lemma reff20_not2051 : ~ @Equation2051 Fin4 reff20_inst.
Proof. unfold Equation2051. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff20_inst, reff20_op in H. discriminate H. Qed.

Lemma reff20_not2053 : ~ @Equation2053 Fin4 reff20_inst.
Proof. unfold Equation2053. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff20_inst, reff20_op in H. discriminate H. Qed.

Lemma reff20_not2054 : ~ @Equation2054 Fin4 reff20_inst.
Proof. unfold Equation2054. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff20_inst, reff20_op in H. discriminate H. Qed.

Lemma reff20_not2060 : ~ @Equation2060 Fin4 reff20_inst.
Proof. unfold Equation2060. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff20_inst, reff20_op in H. discriminate H. Qed.

Lemma reff20_not2061 : ~ @Equation2061 Fin4 reff20_inst.
Proof. unfold Equation2061. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff20_inst, reff20_op in H. discriminate H. Qed.

Lemma reff20_not2063 : ~ @Equation2063 Fin4 reff20_inst.
Proof. unfold Equation2063. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff20_inst, reff20_op in H. discriminate H. Qed.

Lemma reff20_not2064 : ~ @Equation2064 Fin4 reff20_inst.
Proof. unfold Equation2064. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff20_inst, reff20_op in H. discriminate H. Qed.

Lemma reff20_not2087 : ~ @Equation2087 Fin4 reff20_inst.
Proof. unfold Equation2087. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff20_inst, reff20_op in H. discriminate H. Qed.

Lemma reff20_not2088 : ~ @Equation2088 Fin4 reff20_inst.
Proof. unfold Equation2088. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff20_inst, reff20_op in H. discriminate H. Qed.

Lemma reff20_not2090 : ~ @Equation2090 Fin4 reff20_inst.
Proof. unfold Equation2090. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff20_inst, reff20_op in H. discriminate H. Qed.

Lemma reff20_not2091 : ~ @Equation2091 Fin4 reff20_inst.
Proof. unfold Equation2091. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff20_inst, reff20_op in H. discriminate H. Qed.

Lemma reff20_not2097 : ~ @Equation2097 Fin4 reff20_inst.
Proof. unfold Equation2097. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff20_inst, reff20_op in H. discriminate H. Qed.

Lemma reff20_not2098 : ~ @Equation2098 Fin4 reff20_inst.
Proof. unfold Equation2098. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff20_inst, reff20_op in H. discriminate H. Qed.

Lemma reff20_not2100 : ~ @Equation2100 Fin4 reff20_inst.
Proof. unfold Equation2100. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff20_inst, reff20_op in H. discriminate H. Qed.

Lemma reff20_not2101 : ~ @Equation2101 Fin4 reff20_inst.
Proof. unfold Equation2101. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff20_inst, reff20_op in H. discriminate H. Qed.

Lemma reff20_not2124 : ~ @Equation2124 Fin4 reff20_inst.
Proof. unfold Equation2124. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff20_inst, reff20_op in H. discriminate H. Qed.

Lemma reff20_not2125 : ~ @Equation2125 Fin4 reff20_inst.
Proof. unfold Equation2125. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff20_inst, reff20_op in H. discriminate H. Qed.

Lemma reff20_not2127 : ~ @Equation2127 Fin4 reff20_inst.
Proof. unfold Equation2127. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff20_inst, reff20_op in H. discriminate H. Qed.

Lemma reff20_not2128 : ~ @Equation2128 Fin4 reff20_inst.
Proof. unfold Equation2128. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff20_inst, reff20_op in H. discriminate H. Qed.

Lemma reff20_not2134 : ~ @Equation2134 Fin4 reff20_inst.
Proof. unfold Equation2134. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff20_inst, reff20_op in H. discriminate H. Qed.

Lemma reff20_not2135 : ~ @Equation2135 Fin4 reff20_inst.
Proof. unfold Equation2135. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff20_inst, reff20_op in H. discriminate H. Qed.

Lemma reff20_not2137 : ~ @Equation2137 Fin4 reff20_inst.
Proof. unfold Equation2137. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff20_inst, reff20_op in H. discriminate H. Qed.

Lemma reff20_not2239 : ~ @Equation2239 Fin4 reff20_inst.
Proof. unfold Equation2239. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff20_inst, reff20_op in H. discriminate H. Qed.

Lemma reff20_not2240 : ~ @Equation2240 Fin4 reff20_inst.
Proof. unfold Equation2240. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff20_inst, reff20_op in H. discriminate H. Qed.

Lemma reff20_not2241 : ~ @Equation2241 Fin4 reff20_inst.
Proof. unfold Equation2241. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff20_inst, reff20_op in H. discriminate H. Qed.

Lemma reff20_not2243 : ~ @Equation2243 Fin4 reff20_inst.
Proof. unfold Equation2243. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff20_inst, reff20_op in H. discriminate H. Qed.

Lemma reff20_not2244 : ~ @Equation2244 Fin4 reff20_inst.
Proof. unfold Equation2244. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff20_inst, reff20_op in H. discriminate H. Qed.

Lemma reff20_not2246 : ~ @Equation2246 Fin4 reff20_inst.
Proof. unfold Equation2246. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff20_inst, reff20_op in H. discriminate H. Qed.

Lemma reff20_not2247 : ~ @Equation2247 Fin4 reff20_inst.
Proof. unfold Equation2247. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff20_inst, reff20_op in H. discriminate H. Qed.

Lemma reff20_not2253 : ~ @Equation2253 Fin4 reff20_inst.
Proof. unfold Equation2253. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff20_inst, reff20_op in H. discriminate H. Qed.

Lemma reff20_not2254 : ~ @Equation2254 Fin4 reff20_inst.
Proof. unfold Equation2254. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff20_inst, reff20_op in H. discriminate H. Qed.

Lemma reff20_not2256 : ~ @Equation2256 Fin4 reff20_inst.
Proof. unfold Equation2256. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff20_inst, reff20_op in H. discriminate H. Qed.

Lemma reff20_not2257 : ~ @Equation2257 Fin4 reff20_inst.
Proof. unfold Equation2257. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff20_inst, reff20_op in H. discriminate H. Qed.

Lemma reff20_not2263 : ~ @Equation2263 Fin4 reff20_inst.
Proof. unfold Equation2263. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff20_inst, reff20_op in H. discriminate H. Qed.

Lemma reff20_not2264 : ~ @Equation2264 Fin4 reff20_inst.
Proof. unfold Equation2264. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff20_inst, reff20_op in H. discriminate H. Qed.

Lemma reff20_not2266 : ~ @Equation2266 Fin4 reff20_inst.
Proof. unfold Equation2266. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff20_inst, reff20_op in H. discriminate H. Qed.

Lemma reff20_not2267 : ~ @Equation2267 Fin4 reff20_inst.
Proof. unfold Equation2267. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff20_inst, reff20_op in H. discriminate H. Qed.

Lemma reff20_not2290 : ~ @Equation2290 Fin4 reff20_inst.
Proof. unfold Equation2290. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff20_inst, reff20_op in H. discriminate H. Qed.

Lemma reff20_not2291 : ~ @Equation2291 Fin4 reff20_inst.
Proof. unfold Equation2291. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff20_inst, reff20_op in H. discriminate H. Qed.

Lemma reff20_not2293 : ~ @Equation2293 Fin4 reff20_inst.
Proof. unfold Equation2293. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff20_inst, reff20_op in H. discriminate H. Qed.

Lemma reff20_not2294 : ~ @Equation2294 Fin4 reff20_inst.
Proof. unfold Equation2294. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff20_inst, reff20_op in H. discriminate H. Qed.

Lemma reff20_not2300 : ~ @Equation2300 Fin4 reff20_inst.
Proof. unfold Equation2300. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff20_inst, reff20_op in H. discriminate H. Qed.

Lemma reff20_not2301 : ~ @Equation2301 Fin4 reff20_inst.
Proof. unfold Equation2301. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff20_inst, reff20_op in H. discriminate H. Qed.

Lemma reff20_not2303 : ~ @Equation2303 Fin4 reff20_inst.
Proof. unfold Equation2303. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff20_inst, reff20_op in H. discriminate H. Qed.

Lemma reff20_not2304 : ~ @Equation2304 Fin4 reff20_inst.
Proof. unfold Equation2304. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff20_inst, reff20_op in H. discriminate H. Qed.

Lemma reff20_not2327 : ~ @Equation2327 Fin4 reff20_inst.
Proof. unfold Equation2327. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff20_inst, reff20_op in H. discriminate H. Qed.

Lemma reff20_not2328 : ~ @Equation2328 Fin4 reff20_inst.
Proof. unfold Equation2328. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff20_inst, reff20_op in H. discriminate H. Qed.

Lemma reff20_not2330 : ~ @Equation2330 Fin4 reff20_inst.
Proof. unfold Equation2330. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff20_inst, reff20_op in H. discriminate H. Qed.

Lemma reff20_not2331 : ~ @Equation2331 Fin4 reff20_inst.
Proof. unfold Equation2331. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff20_inst, reff20_op in H. discriminate H. Qed.

Lemma reff20_not2337 : ~ @Equation2337 Fin4 reff20_inst.
Proof. unfold Equation2337. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff20_inst, reff20_op in H. discriminate H. Qed.

Lemma reff20_not2338 : ~ @Equation2338 Fin4 reff20_inst.
Proof. unfold Equation2338. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff20_inst, reff20_op in H. discriminate H. Qed.

Lemma reff20_not2340 : ~ @Equation2340 Fin4 reff20_inst.
Proof. unfold Equation2340. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff20_inst, reff20_op in H. discriminate H. Qed.

Lemma reff20_not2442 : ~ @Equation2442 Fin4 reff20_inst.
Proof. unfold Equation2442. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff20_inst, reff20_op in H. discriminate H. Qed.

Lemma reff20_not2443 : ~ @Equation2443 Fin4 reff20_inst.
Proof. unfold Equation2443. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff20_inst, reff20_op in H. discriminate H. Qed.

Lemma reff20_not2444 : ~ @Equation2444 Fin4 reff20_inst.
Proof. unfold Equation2444. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff20_inst, reff20_op in H. discriminate H. Qed.

Lemma reff20_not2446 : ~ @Equation2446 Fin4 reff20_inst.
Proof. unfold Equation2446. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff20_inst, reff20_op in H. discriminate H. Qed.

Lemma reff20_not2447 : ~ @Equation2447 Fin4 reff20_inst.
Proof. unfold Equation2447. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff20_inst, reff20_op in H. discriminate H. Qed.

Lemma reff20_not2449 : ~ @Equation2449 Fin4 reff20_inst.
Proof. unfold Equation2449. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff20_inst, reff20_op in H. discriminate H. Qed.

Lemma reff20_not2450 : ~ @Equation2450 Fin4 reff20_inst.
Proof. unfold Equation2450. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff20_inst, reff20_op in H. discriminate H. Qed.

Lemma reff20_not2456 : ~ @Equation2456 Fin4 reff20_inst.
Proof. unfold Equation2456. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff20_inst, reff20_op in H. discriminate H. Qed.

Lemma reff20_not2457 : ~ @Equation2457 Fin4 reff20_inst.
Proof. unfold Equation2457. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff20_inst, reff20_op in H. discriminate H. Qed.

Lemma reff20_not2459 : ~ @Equation2459 Fin4 reff20_inst.
Proof. unfold Equation2459. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff20_inst, reff20_op in H. discriminate H. Qed.

Lemma reff20_not2460 : ~ @Equation2460 Fin4 reff20_inst.
Proof. unfold Equation2460. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff20_inst, reff20_op in H. discriminate H. Qed.

Lemma reff20_not2466 : ~ @Equation2466 Fin4 reff20_inst.
Proof. unfold Equation2466. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff20_inst, reff20_op in H. discriminate H. Qed.

Lemma reff20_not2467 : ~ @Equation2467 Fin4 reff20_inst.
Proof. unfold Equation2467. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff20_inst, reff20_op in H. discriminate H. Qed.

Lemma reff20_not2469 : ~ @Equation2469 Fin4 reff20_inst.
Proof. unfold Equation2469. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff20_inst, reff20_op in H. discriminate H. Qed.

Lemma reff20_not2470 : ~ @Equation2470 Fin4 reff20_inst.
Proof. unfold Equation2470. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff20_inst, reff20_op in H. discriminate H. Qed.

Lemma reff20_not2493 : ~ @Equation2493 Fin4 reff20_inst.
Proof. unfold Equation2493. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff20_inst, reff20_op in H. discriminate H. Qed.

Lemma reff20_not2494 : ~ @Equation2494 Fin4 reff20_inst.
Proof. unfold Equation2494. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff20_inst, reff20_op in H. discriminate H. Qed.

Lemma reff20_not2496 : ~ @Equation2496 Fin4 reff20_inst.
Proof. unfold Equation2496. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff20_inst, reff20_op in H. discriminate H. Qed.

Lemma reff20_not2497 : ~ @Equation2497 Fin4 reff20_inst.
Proof. unfold Equation2497. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff20_inst, reff20_op in H. discriminate H. Qed.

Lemma reff20_not2503 : ~ @Equation2503 Fin4 reff20_inst.
Proof. unfold Equation2503. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff20_inst, reff20_op in H. discriminate H. Qed.

Lemma reff20_not2504 : ~ @Equation2504 Fin4 reff20_inst.
Proof. unfold Equation2504. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff20_inst, reff20_op in H. discriminate H. Qed.

Lemma reff20_not2506 : ~ @Equation2506 Fin4 reff20_inst.
Proof. unfold Equation2506. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff20_inst, reff20_op in H. discriminate H. Qed.

Lemma reff20_not2507 : ~ @Equation2507 Fin4 reff20_inst.
Proof. unfold Equation2507. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff20_inst, reff20_op in H. discriminate H. Qed.

Lemma reff20_not2530 : ~ @Equation2530 Fin4 reff20_inst.
Proof. unfold Equation2530. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff20_inst, reff20_op in H. discriminate H. Qed.

Lemma reff20_not2531 : ~ @Equation2531 Fin4 reff20_inst.
Proof. unfold Equation2531. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff20_inst, reff20_op in H. discriminate H. Qed.

Lemma reff20_not2533 : ~ @Equation2533 Fin4 reff20_inst.
Proof. unfold Equation2533. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff20_inst, reff20_op in H. discriminate H. Qed.

Lemma reff20_not2534 : ~ @Equation2534 Fin4 reff20_inst.
Proof. unfold Equation2534. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff20_inst, reff20_op in H. discriminate H. Qed.

Lemma reff20_not2540 : ~ @Equation2540 Fin4 reff20_inst.
Proof. unfold Equation2540. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff20_inst, reff20_op in H. discriminate H. Qed.

Lemma reff20_not2541 : ~ @Equation2541 Fin4 reff20_inst.
Proof. unfold Equation2541. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff20_inst, reff20_op in H. discriminate H. Qed.

Lemma reff20_not2543 : ~ @Equation2543 Fin4 reff20_inst.
Proof. unfold Equation2543. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff20_inst, reff20_op in H. discriminate H. Qed.

Lemma reff20_not2645 : ~ @Equation2645 Fin4 reff20_inst.
Proof. unfold Equation2645. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff20_inst, reff20_op in H. discriminate H. Qed.

Lemma reff20_not2646 : ~ @Equation2646 Fin4 reff20_inst.
Proof. unfold Equation2646. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff20_inst, reff20_op in H. discriminate H. Qed.

Lemma reff20_not2647 : ~ @Equation2647 Fin4 reff20_inst.
Proof. unfold Equation2647. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff20_inst, reff20_op in H. discriminate H. Qed.

Lemma reff20_not2649 : ~ @Equation2649 Fin4 reff20_inst.
Proof. unfold Equation2649. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff20_inst, reff20_op in H. discriminate H. Qed.

Lemma reff20_not2650 : ~ @Equation2650 Fin4 reff20_inst.
Proof. unfold Equation2650. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff20_inst, reff20_op in H. discriminate H. Qed.

Lemma reff20_not2652 : ~ @Equation2652 Fin4 reff20_inst.
Proof. unfold Equation2652. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff20_inst, reff20_op in H. discriminate H. Qed.

Lemma reff20_not2653 : ~ @Equation2653 Fin4 reff20_inst.
Proof. unfold Equation2653. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff20_inst, reff20_op in H. discriminate H. Qed.

Lemma reff20_not2659 : ~ @Equation2659 Fin4 reff20_inst.
Proof. unfold Equation2659. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff20_inst, reff20_op in H. discriminate H. Qed.

Lemma reff20_not2660 : ~ @Equation2660 Fin4 reff20_inst.
Proof. unfold Equation2660. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff20_inst, reff20_op in H. discriminate H. Qed.

Lemma reff20_not2662 : ~ @Equation2662 Fin4 reff20_inst.
Proof. unfold Equation2662. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff20_inst, reff20_op in H. discriminate H. Qed.

Lemma reff20_not2663 : ~ @Equation2663 Fin4 reff20_inst.
Proof. unfold Equation2663. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff20_inst, reff20_op in H. discriminate H. Qed.

Lemma reff20_not2669 : ~ @Equation2669 Fin4 reff20_inst.
Proof. unfold Equation2669. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff20_inst, reff20_op in H. discriminate H. Qed.

Lemma reff20_not2670 : ~ @Equation2670 Fin4 reff20_inst.
Proof. unfold Equation2670. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff20_inst, reff20_op in H. discriminate H. Qed.

Lemma reff20_not2672 : ~ @Equation2672 Fin4 reff20_inst.
Proof. unfold Equation2672. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff20_inst, reff20_op in H. discriminate H. Qed.

Lemma reff20_not2673 : ~ @Equation2673 Fin4 reff20_inst.
Proof. unfold Equation2673. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff20_inst, reff20_op in H. discriminate H. Qed.

Lemma reff20_not2696 : ~ @Equation2696 Fin4 reff20_inst.
Proof. unfold Equation2696. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff20_inst, reff20_op in H. discriminate H. Qed.

Lemma reff20_not2697 : ~ @Equation2697 Fin4 reff20_inst.
Proof. unfold Equation2697. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff20_inst, reff20_op in H. discriminate H. Qed.

Lemma reff20_not2699 : ~ @Equation2699 Fin4 reff20_inst.
Proof. unfold Equation2699. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff20_inst, reff20_op in H. discriminate H. Qed.

Lemma reff20_not2700 : ~ @Equation2700 Fin4 reff20_inst.
Proof. unfold Equation2700. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff20_inst, reff20_op in H. discriminate H. Qed.

Lemma reff20_not2706 : ~ @Equation2706 Fin4 reff20_inst.
Proof. unfold Equation2706. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff20_inst, reff20_op in H. discriminate H. Qed.

Lemma reff20_not2707 : ~ @Equation2707 Fin4 reff20_inst.
Proof. unfold Equation2707. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff20_inst, reff20_op in H. discriminate H. Qed.

Lemma reff20_not2709 : ~ @Equation2709 Fin4 reff20_inst.
Proof. unfold Equation2709. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff20_inst, reff20_op in H. discriminate H. Qed.

Lemma reff20_not2710 : ~ @Equation2710 Fin4 reff20_inst.
Proof. unfold Equation2710. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff20_inst, reff20_op in H. discriminate H. Qed.

Lemma reff20_not2733 : ~ @Equation2733 Fin4 reff20_inst.
Proof. unfold Equation2733. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff20_inst, reff20_op in H. discriminate H. Qed.

Lemma reff20_not2734 : ~ @Equation2734 Fin4 reff20_inst.
Proof. unfold Equation2734. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff20_inst, reff20_op in H. discriminate H. Qed.

Lemma reff20_not2736 : ~ @Equation2736 Fin4 reff20_inst.
Proof. unfold Equation2736. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff20_inst, reff20_op in H. discriminate H. Qed.

Lemma reff20_not2737 : ~ @Equation2737 Fin4 reff20_inst.
Proof. unfold Equation2737. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff20_inst, reff20_op in H. discriminate H. Qed.

Lemma reff20_not2743 : ~ @Equation2743 Fin4 reff20_inst.
Proof. unfold Equation2743. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff20_inst, reff20_op in H. discriminate H. Qed.

Lemma reff20_not2744 : ~ @Equation2744 Fin4 reff20_inst.
Proof. unfold Equation2744. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff20_inst, reff20_op in H. discriminate H. Qed.

Lemma reff20_not2746 : ~ @Equation2746 Fin4 reff20_inst.
Proof. unfold Equation2746. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff20_inst, reff20_op in H. discriminate H. Qed.

Lemma reff20_not2848 : ~ @Equation2848 Fin4 reff20_inst.
Proof. unfold Equation2848. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff20_inst, reff20_op in H. discriminate H. Qed.

Lemma reff20_not2849 : ~ @Equation2849 Fin4 reff20_inst.
Proof. unfold Equation2849. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff20_inst, reff20_op in H. discriminate H. Qed.

Lemma reff20_not2850 : ~ @Equation2850 Fin4 reff20_inst.
Proof. unfold Equation2850. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff20_inst, reff20_op in H. discriminate H. Qed.

Lemma reff20_not2852 : ~ @Equation2852 Fin4 reff20_inst.
Proof. unfold Equation2852. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff20_inst, reff20_op in H. discriminate H. Qed.

Lemma reff20_not2853 : ~ @Equation2853 Fin4 reff20_inst.
Proof. unfold Equation2853. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff20_inst, reff20_op in H. discriminate H. Qed.

Lemma reff20_not2855 : ~ @Equation2855 Fin4 reff20_inst.
Proof. unfold Equation2855. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff20_inst, reff20_op in H. discriminate H. Qed.

Lemma reff20_not2856 : ~ @Equation2856 Fin4 reff20_inst.
Proof. unfold Equation2856. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff20_inst, reff20_op in H. discriminate H. Qed.

Lemma reff20_not2862 : ~ @Equation2862 Fin4 reff20_inst.
Proof. unfold Equation2862. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff20_inst, reff20_op in H. discriminate H. Qed.

Lemma reff20_not2863 : ~ @Equation2863 Fin4 reff20_inst.
Proof. unfold Equation2863. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff20_inst, reff20_op in H. discriminate H. Qed.

Lemma reff20_not2865 : ~ @Equation2865 Fin4 reff20_inst.
Proof. unfold Equation2865. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff20_inst, reff20_op in H. discriminate H. Qed.

Lemma reff20_not2866 : ~ @Equation2866 Fin4 reff20_inst.
Proof. unfold Equation2866. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff20_inst, reff20_op in H. discriminate H. Qed.

Lemma reff20_not2872 : ~ @Equation2872 Fin4 reff20_inst.
Proof. unfold Equation2872. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff20_inst, reff20_op in H. discriminate H. Qed.

Lemma reff20_not2873 : ~ @Equation2873 Fin4 reff20_inst.
Proof. unfold Equation2873. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff20_inst, reff20_op in H. discriminate H. Qed.

Lemma reff20_not2875 : ~ @Equation2875 Fin4 reff20_inst.
Proof. unfold Equation2875. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff20_inst, reff20_op in H. discriminate H. Qed.

Lemma reff20_not2876 : ~ @Equation2876 Fin4 reff20_inst.
Proof. unfold Equation2876. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff20_inst, reff20_op in H. discriminate H. Qed.

Lemma reff20_not2899 : ~ @Equation2899 Fin4 reff20_inst.
Proof. unfold Equation2899. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff20_inst, reff20_op in H. discriminate H. Qed.

Lemma reff20_not2900 : ~ @Equation2900 Fin4 reff20_inst.
Proof. unfold Equation2900. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff20_inst, reff20_op in H. discriminate H. Qed.

Lemma reff20_not2902 : ~ @Equation2902 Fin4 reff20_inst.
Proof. unfold Equation2902. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff20_inst, reff20_op in H. discriminate H. Qed.

Lemma reff20_not2903 : ~ @Equation2903 Fin4 reff20_inst.
Proof. unfold Equation2903. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff20_inst, reff20_op in H. discriminate H. Qed.

Lemma reff20_not2909 : ~ @Equation2909 Fin4 reff20_inst.
Proof. unfold Equation2909. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff20_inst, reff20_op in H. discriminate H. Qed.

Lemma reff20_not2910 : ~ @Equation2910 Fin4 reff20_inst.
Proof. unfold Equation2910. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff20_inst, reff20_op in H. discriminate H. Qed.

Lemma reff20_not2912 : ~ @Equation2912 Fin4 reff20_inst.
Proof. unfold Equation2912. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff20_inst, reff20_op in H. discriminate H. Qed.

Lemma reff20_not2913 : ~ @Equation2913 Fin4 reff20_inst.
Proof. unfold Equation2913. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff20_inst, reff20_op in H. discriminate H. Qed.

Lemma reff20_not2936 : ~ @Equation2936 Fin4 reff20_inst.
Proof. unfold Equation2936. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff20_inst, reff20_op in H. discriminate H. Qed.

Lemma reff20_not2937 : ~ @Equation2937 Fin4 reff20_inst.
Proof. unfold Equation2937. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff20_inst, reff20_op in H. discriminate H. Qed.

Lemma reff20_not2939 : ~ @Equation2939 Fin4 reff20_inst.
Proof. unfold Equation2939. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff20_inst, reff20_op in H. discriminate H. Qed.

Lemma reff20_not2940 : ~ @Equation2940 Fin4 reff20_inst.
Proof. unfold Equation2940. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff20_inst, reff20_op in H. discriminate H. Qed.

Lemma reff20_not2946 : ~ @Equation2946 Fin4 reff20_inst.
Proof. unfold Equation2946. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff20_inst, reff20_op in H. discriminate H. Qed.

Lemma reff20_not2947 : ~ @Equation2947 Fin4 reff20_inst.
Proof. unfold Equation2947. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff20_inst, reff20_op in H. discriminate H. Qed.

Lemma reff20_not2949 : ~ @Equation2949 Fin4 reff20_inst.
Proof. unfold Equation2949. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff20_inst, reff20_op in H. discriminate H. Qed.

Lemma reff20_not3051 : ~ @Equation3051 Fin4 reff20_inst.
Proof. unfold Equation3051. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff20_inst, reff20_op in H. discriminate H. Qed.

Lemma reff20_not3052 : ~ @Equation3052 Fin4 reff20_inst.
Proof. unfold Equation3052. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff20_inst, reff20_op in H. discriminate H. Qed.

Lemma reff20_not3053 : ~ @Equation3053 Fin4 reff20_inst.
Proof. unfold Equation3053. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff20_inst, reff20_op in H. discriminate H. Qed.

Lemma reff20_not3055 : ~ @Equation3055 Fin4 reff20_inst.
Proof. unfold Equation3055. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff20_inst, reff20_op in H. discriminate H. Qed.

Lemma reff20_not3056 : ~ @Equation3056 Fin4 reff20_inst.
Proof. unfold Equation3056. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff20_inst, reff20_op in H. discriminate H. Qed.

Lemma reff20_not3058 : ~ @Equation3058 Fin4 reff20_inst.
Proof. unfold Equation3058. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff20_inst, reff20_op in H. discriminate H. Qed.

Lemma reff20_not3059 : ~ @Equation3059 Fin4 reff20_inst.
Proof. unfold Equation3059. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff20_inst, reff20_op in H. discriminate H. Qed.

Lemma reff20_not3065 : ~ @Equation3065 Fin4 reff20_inst.
Proof. unfold Equation3065. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff20_inst, reff20_op in H. discriminate H. Qed.

Lemma reff20_not3066 : ~ @Equation3066 Fin4 reff20_inst.
Proof. unfold Equation3066. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff20_inst, reff20_op in H. discriminate H. Qed.

Lemma reff20_not3068 : ~ @Equation3068 Fin4 reff20_inst.
Proof. unfold Equation3068. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff20_inst, reff20_op in H. discriminate H. Qed.

Lemma reff20_not3069 : ~ @Equation3069 Fin4 reff20_inst.
Proof. unfold Equation3069. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff20_inst, reff20_op in H. discriminate H. Qed.

Lemma reff20_not3075 : ~ @Equation3075 Fin4 reff20_inst.
Proof. unfold Equation3075. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff20_inst, reff20_op in H. discriminate H. Qed.

Lemma reff20_not3076 : ~ @Equation3076 Fin4 reff20_inst.
Proof. unfold Equation3076. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff20_inst, reff20_op in H. discriminate H. Qed.

Lemma reff20_not3078 : ~ @Equation3078 Fin4 reff20_inst.
Proof. unfold Equation3078. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff20_inst, reff20_op in H. discriminate H. Qed.

Lemma reff20_not3079 : ~ @Equation3079 Fin4 reff20_inst.
Proof. unfold Equation3079. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff20_inst, reff20_op in H. discriminate H. Qed.

Lemma reff20_not3102 : ~ @Equation3102 Fin4 reff20_inst.
Proof. unfold Equation3102. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff20_inst, reff20_op in H. discriminate H. Qed.

Lemma reff20_not3103 : ~ @Equation3103 Fin4 reff20_inst.
Proof. unfold Equation3103. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff20_inst, reff20_op in H. discriminate H. Qed.

Lemma reff20_not3105 : ~ @Equation3105 Fin4 reff20_inst.
Proof. unfold Equation3105. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff20_inst, reff20_op in H. discriminate H. Qed.

Lemma reff20_not3106 : ~ @Equation3106 Fin4 reff20_inst.
Proof. unfold Equation3106. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff20_inst, reff20_op in H. discriminate H. Qed.

Lemma reff20_not3112 : ~ @Equation3112 Fin4 reff20_inst.
Proof. unfold Equation3112. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff20_inst, reff20_op in H. discriminate H. Qed.

Lemma reff20_not3113 : ~ @Equation3113 Fin4 reff20_inst.
Proof. unfold Equation3113. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff20_inst, reff20_op in H. discriminate H. Qed.

Lemma reff20_not3115 : ~ @Equation3115 Fin4 reff20_inst.
Proof. unfold Equation3115. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff20_inst, reff20_op in H. discriminate H. Qed.

Lemma reff20_not3116 : ~ @Equation3116 Fin4 reff20_inst.
Proof. unfold Equation3116. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff20_inst, reff20_op in H. discriminate H. Qed.

Lemma reff20_not3139 : ~ @Equation3139 Fin4 reff20_inst.
Proof. unfold Equation3139. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff20_inst, reff20_op in H. discriminate H. Qed.

Lemma reff20_not3140 : ~ @Equation3140 Fin4 reff20_inst.
Proof. unfold Equation3140. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff20_inst, reff20_op in H. discriminate H. Qed.

Lemma reff20_not3142 : ~ @Equation3142 Fin4 reff20_inst.
Proof. unfold Equation3142. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff20_inst, reff20_op in H. discriminate H. Qed.

Lemma reff20_not3143 : ~ @Equation3143 Fin4 reff20_inst.
Proof. unfold Equation3143. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff20_inst, reff20_op in H. discriminate H. Qed.

Lemma reff20_not3149 : ~ @Equation3149 Fin4 reff20_inst.
Proof. unfold Equation3149. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff20_inst, reff20_op in H. discriminate H. Qed.

Lemma reff20_not3150 : ~ @Equation3150 Fin4 reff20_inst.
Proof. unfold Equation3150. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff20_inst, reff20_op in H. discriminate H. Qed.

Lemma reff20_not3152 : ~ @Equation3152 Fin4 reff20_inst.
Proof. unfold Equation3152. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff20_inst, reff20_op in H. discriminate H. Qed.

Lemma reff20_not3254 : ~ @Equation3254 Fin4 reff20_inst.
Proof. unfold Equation3254. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff20_inst, reff20_op in H. discriminate H. Qed.

Lemma reff20_not3255 : ~ @Equation3255 Fin4 reff20_inst.
Proof. unfold Equation3255. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff20_inst, reff20_op in H. discriminate H. Qed.

Lemma reff20_not3256 : ~ @Equation3256 Fin4 reff20_inst.
Proof. unfold Equation3256. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff20_inst, reff20_op in H. discriminate H. Qed.

Lemma reff20_not3258 : ~ @Equation3258 Fin4 reff20_inst.
Proof. unfold Equation3258. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff20_inst, reff20_op in H. discriminate H. Qed.

Lemma reff20_not3259 : ~ @Equation3259 Fin4 reff20_inst.
Proof. unfold Equation3259. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff20_inst, reff20_op in H. discriminate H. Qed.

Lemma reff20_not3261 : ~ @Equation3261 Fin4 reff20_inst.
Proof. unfold Equation3261. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff20_inst, reff20_op in H. discriminate H. Qed.

Lemma reff20_not3262 : ~ @Equation3262 Fin4 reff20_inst.
Proof. unfold Equation3262. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff20_inst, reff20_op in H. discriminate H. Qed.

Lemma reff20_not3268 : ~ @Equation3268 Fin4 reff20_inst.
Proof. unfold Equation3268. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff20_inst, reff20_op in H. discriminate H. Qed.

Lemma reff20_not3269 : ~ @Equation3269 Fin4 reff20_inst.
Proof. unfold Equation3269. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff20_inst, reff20_op in H. discriminate H. Qed.

Lemma reff20_not3271 : ~ @Equation3271 Fin4 reff20_inst.
Proof. unfold Equation3271. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff20_inst, reff20_op in H. discriminate H. Qed.

Lemma reff20_not3272 : ~ @Equation3272 Fin4 reff20_inst.
Proof. unfold Equation3272. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff20_inst, reff20_op in H. discriminate H. Qed.

Lemma reff20_not3278 : ~ @Equation3278 Fin4 reff20_inst.
Proof. unfold Equation3278. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff20_inst, reff20_op in H. discriminate H. Qed.

Lemma reff20_not3279 : ~ @Equation3279 Fin4 reff20_inst.
Proof. unfold Equation3279. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff20_inst, reff20_op in H. discriminate H. Qed.

Lemma reff20_not3281 : ~ @Equation3281 Fin4 reff20_inst.
Proof. unfold Equation3281. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff20_inst, reff20_op in H. discriminate H. Qed.

Lemma reff20_not3306 : ~ @Equation3306 Fin4 reff20_inst.
Proof. unfold Equation3306. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff20_inst, reff20_op in H. discriminate H. Qed.

Lemma reff20_not3308 : ~ @Equation3308 Fin4 reff20_inst.
Proof. unfold Equation3308. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff20_inst, reff20_op in H. discriminate H. Qed.

Lemma reff20_not3309 : ~ @Equation3309 Fin4 reff20_inst.
Proof. unfold Equation3309. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff20_inst, reff20_op in H. discriminate H. Qed.

Lemma reff20_not3315 : ~ @Equation3315 Fin4 reff20_inst.
Proof. unfold Equation3315. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff20_inst, reff20_op in H. discriminate H. Qed.

Lemma reff20_not3316 : ~ @Equation3316 Fin4 reff20_inst.
Proof. unfold Equation3316. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff20_inst, reff20_op in H. discriminate H. Qed.

Lemma reff20_not3318 : ~ @Equation3318 Fin4 reff20_inst.
Proof. unfold Equation3318. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff20_inst, reff20_op in H. discriminate H. Qed.

Lemma reff20_not3342 : ~ @Equation3342 Fin4 reff20_inst.
Proof. unfold Equation3342. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff20_inst, reff20_op in H. discriminate H. Qed.

Lemma reff20_not3343 : ~ @Equation3343 Fin4 reff20_inst.
Proof. unfold Equation3343. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff20_inst, reff20_op in H. discriminate H. Qed.

Lemma reff20_not3345 : ~ @Equation3345 Fin4 reff20_inst.
Proof. unfold Equation3345. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff20_inst, reff20_op in H. discriminate H. Qed.

Lemma reff20_not3346 : ~ @Equation3346 Fin4 reff20_inst.
Proof. unfold Equation3346. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff20_inst, reff20_op in H. discriminate H. Qed.

Lemma reff20_not3352 : ~ @Equation3352 Fin4 reff20_inst.
Proof. unfold Equation3352. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff20_inst, reff20_op in H. discriminate H. Qed.

Lemma reff20_not3353 : ~ @Equation3353 Fin4 reff20_inst.
Proof. unfold Equation3353. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff20_inst, reff20_op in H. discriminate H. Qed.

Lemma reff20_not3457 : ~ @Equation3457 Fin4 reff20_inst.
Proof. unfold Equation3457. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff20_inst, reff20_op in H. discriminate H. Qed.

Lemma reff20_not3458 : ~ @Equation3458 Fin4 reff20_inst.
Proof. unfold Equation3458. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff20_inst, reff20_op in H. discriminate H. Qed.

Lemma reff20_not3459 : ~ @Equation3459 Fin4 reff20_inst.
Proof. unfold Equation3459. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff20_inst, reff20_op in H. discriminate H. Qed.

Lemma reff20_not3461 : ~ @Equation3461 Fin4 reff20_inst.
Proof. unfold Equation3461. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff20_inst, reff20_op in H. discriminate H. Qed.

Lemma reff20_not3462 : ~ @Equation3462 Fin4 reff20_inst.
Proof. unfold Equation3462. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff20_inst, reff20_op in H. discriminate H. Qed.

Lemma reff20_not3464 : ~ @Equation3464 Fin4 reff20_inst.
Proof. unfold Equation3464. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff20_inst, reff20_op in H. discriminate H. Qed.

Lemma reff20_not3465 : ~ @Equation3465 Fin4 reff20_inst.
Proof. unfold Equation3465. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff20_inst, reff20_op in H. discriminate H. Qed.

Lemma reff20_not3472 : ~ @Equation3472 Fin4 reff20_inst.
Proof. unfold Equation3472. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff20_inst, reff20_op in H. discriminate H. Qed.

Lemma reff20_not3474 : ~ @Equation3474 Fin4 reff20_inst.
Proof. unfold Equation3474. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff20_inst, reff20_op in H. discriminate H. Qed.

Lemma reff20_not3475 : ~ @Equation3475 Fin4 reff20_inst.
Proof. unfold Equation3475. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff20_inst, reff20_op in H. discriminate H. Qed.

Lemma reff20_not3481 : ~ @Equation3481 Fin4 reff20_inst.
Proof. unfold Equation3481. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff20_inst, reff20_op in H. discriminate H. Qed.

Lemma reff20_not3482 : ~ @Equation3482 Fin4 reff20_inst.
Proof. unfold Equation3482. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff20_inst, reff20_op in H. discriminate H. Qed.

Lemma reff20_not3484 : ~ @Equation3484 Fin4 reff20_inst.
Proof. unfold Equation3484. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff20_inst, reff20_op in H. discriminate H. Qed.

Lemma reff20_not3509 : ~ @Equation3509 Fin4 reff20_inst.
Proof. unfold Equation3509. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff20_inst, reff20_op in H. discriminate H. Qed.

Lemma reff20_not3511 : ~ @Equation3511 Fin4 reff20_inst.
Proof. unfold Equation3511. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff20_inst, reff20_op in H. discriminate H. Qed.

Lemma reff20_not3512 : ~ @Equation3512 Fin4 reff20_inst.
Proof. unfold Equation3512. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff20_inst, reff20_op in H. discriminate H. Qed.

Lemma reff20_not3518 : ~ @Equation3518 Fin4 reff20_inst.
Proof. unfold Equation3518. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff20_inst, reff20_op in H. discriminate H. Qed.

Lemma reff20_not3519 : ~ @Equation3519 Fin4 reff20_inst.
Proof. unfold Equation3519. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff20_inst, reff20_op in H. discriminate H. Qed.

Lemma reff20_not3521 : ~ @Equation3521 Fin4 reff20_inst.
Proof. unfold Equation3521. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff20_inst, reff20_op in H. discriminate H. Qed.

Lemma reff20_not3545 : ~ @Equation3545 Fin4 reff20_inst.
Proof. unfold Equation3545. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff20_inst, reff20_op in H. discriminate H. Qed.

Lemma reff20_not3546 : ~ @Equation3546 Fin4 reff20_inst.
Proof. unfold Equation3546. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff20_inst, reff20_op in H. discriminate H. Qed.

Lemma reff20_not3548 : ~ @Equation3548 Fin4 reff20_inst.
Proof. unfold Equation3548. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff20_inst, reff20_op in H. discriminate H. Qed.

Lemma reff20_not3549 : ~ @Equation3549 Fin4 reff20_inst.
Proof. unfold Equation3549. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff20_inst, reff20_op in H. discriminate H. Qed.

Lemma reff20_not3555 : ~ @Equation3555 Fin4 reff20_inst.
Proof. unfold Equation3555. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff20_inst, reff20_op in H. discriminate H. Qed.

Lemma reff20_not3556 : ~ @Equation3556 Fin4 reff20_inst.
Proof. unfold Equation3556. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff20_inst, reff20_op in H. discriminate H. Qed.

Lemma reff20_not3558 : ~ @Equation3558 Fin4 reff20_inst.
Proof. unfold Equation3558. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff20_inst, reff20_op in H. discriminate H. Qed.

Lemma reff20_not3660 : ~ @Equation3660 Fin4 reff20_inst.
Proof. unfold Equation3660. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff20_inst, reff20_op in H. discriminate H. Qed.

Lemma reff20_not3661 : ~ @Equation3661 Fin4 reff20_inst.
Proof. unfold Equation3661. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff20_inst, reff20_op in H. discriminate H. Qed.

Lemma reff20_not3662 : ~ @Equation3662 Fin4 reff20_inst.
Proof. unfold Equation3662. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff20_inst, reff20_op in H. discriminate H. Qed.

Lemma reff20_not3664 : ~ @Equation3664 Fin4 reff20_inst.
Proof. unfold Equation3664. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff20_inst, reff20_op in H. discriminate H. Qed.

Lemma reff20_not3665 : ~ @Equation3665 Fin4 reff20_inst.
Proof. unfold Equation3665. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff20_inst, reff20_op in H. discriminate H. Qed.

Lemma reff20_not3667 : ~ @Equation3667 Fin4 reff20_inst.
Proof. unfold Equation3667. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff20_inst, reff20_op in H. discriminate H. Qed.

Lemma reff20_not3668 : ~ @Equation3668 Fin4 reff20_inst.
Proof. unfold Equation3668. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff20_inst, reff20_op in H. discriminate H. Qed.

Lemma reff20_not3674 : ~ @Equation3674 Fin4 reff20_inst.
Proof. unfold Equation3674. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff20_inst, reff20_op in H. discriminate H. Qed.

Lemma reff20_not3675 : ~ @Equation3675 Fin4 reff20_inst.
Proof. unfold Equation3675. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff20_inst, reff20_op in H. discriminate H. Qed.

Lemma reff20_not3677 : ~ @Equation3677 Fin4 reff20_inst.
Proof. unfold Equation3677. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff20_inst, reff20_op in H. discriminate H. Qed.

Lemma reff20_not3678 : ~ @Equation3678 Fin4 reff20_inst.
Proof. unfold Equation3678. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff20_inst, reff20_op in H. discriminate H. Qed.

Lemma reff20_not3684 : ~ @Equation3684 Fin4 reff20_inst.
Proof. unfold Equation3684. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff20_inst, reff20_op in H. discriminate H. Qed.

Lemma reff20_not3685 : ~ @Equation3685 Fin4 reff20_inst.
Proof. unfold Equation3685. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff20_inst, reff20_op in H. discriminate H. Qed.

Lemma reff20_not3687 : ~ @Equation3687 Fin4 reff20_inst.
Proof. unfold Equation3687. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff20_inst, reff20_op in H. discriminate H. Qed.

Lemma reff20_not3712 : ~ @Equation3712 Fin4 reff20_inst.
Proof. unfold Equation3712. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff20_inst, reff20_op in H. discriminate H. Qed.

Lemma reff20_not3714 : ~ @Equation3714 Fin4 reff20_inst.
Proof. unfold Equation3714. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff20_inst, reff20_op in H. discriminate H. Qed.

Lemma reff20_not3721 : ~ @Equation3721 Fin4 reff20_inst.
Proof. unfold Equation3721. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff20_inst, reff20_op in H. discriminate H. Qed.

Lemma reff20_not3724 : ~ @Equation3724 Fin4 reff20_inst.
Proof. unfold Equation3724. intro H. specialize (H F4_1 F4_3). unfold magma_op, reff20_inst, reff20_op in H. discriminate H. Qed.

Lemma reff20_not3748 : ~ @Equation3748 Fin4 reff20_inst.
Proof. unfold Equation3748. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff20_inst, reff20_op in H. discriminate H. Qed.

Lemma reff20_not3749 : ~ @Equation3749 Fin4 reff20_inst.
Proof. unfold Equation3749. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff20_inst, reff20_op in H. discriminate H. Qed.

Lemma reff20_not3751 : ~ @Equation3751 Fin4 reff20_inst.
Proof. unfold Equation3751. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff20_inst, reff20_op in H. discriminate H. Qed.

Lemma reff20_not3752 : ~ @Equation3752 Fin4 reff20_inst.
Proof. unfold Equation3752. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff20_inst, reff20_op in H. discriminate H. Qed.

Lemma reff20_not3758 : ~ @Equation3758 Fin4 reff20_inst.
Proof. unfold Equation3758. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff20_inst, reff20_op in H. discriminate H. Qed.

Lemma reff20_not3759 : ~ @Equation3759 Fin4 reff20_inst.
Proof. unfold Equation3759. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff20_inst, reff20_op in H. discriminate H. Qed.

Lemma reff20_not3761 : ~ @Equation3761 Fin4 reff20_inst.
Proof. unfold Equation3761. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff20_inst, reff20_op in H. discriminate H. Qed.

Lemma reff20_not3864 : ~ @Equation3864 Fin4 reff20_inst.
Proof. unfold Equation3864. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff20_inst, reff20_op in H. discriminate H. Qed.

Lemma reff20_not3865 : ~ @Equation3865 Fin4 reff20_inst.
Proof. unfold Equation3865. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff20_inst, reff20_op in H. discriminate H. Qed.

Lemma reff20_not3867 : ~ @Equation3867 Fin4 reff20_inst.
Proof. unfold Equation3867. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff20_inst, reff20_op in H. discriminate H. Qed.

Lemma reff20_not3868 : ~ @Equation3868 Fin4 reff20_inst.
Proof. unfold Equation3868. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff20_inst, reff20_op in H. discriminate H. Qed.

Lemma reff20_not3870 : ~ @Equation3870 Fin4 reff20_inst.
Proof. unfold Equation3870. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff20_inst, reff20_op in H. discriminate H. Qed.

Lemma reff20_not3871 : ~ @Equation3871 Fin4 reff20_inst.
Proof. unfold Equation3871. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff20_inst, reff20_op in H. discriminate H. Qed.

Lemma reff20_not3877 : ~ @Equation3877 Fin4 reff20_inst.
Proof. unfold Equation3877. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff20_inst, reff20_op in H. discriminate H. Qed.

Lemma reff20_not3878 : ~ @Equation3878 Fin4 reff20_inst.
Proof. unfold Equation3878. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff20_inst, reff20_op in H. discriminate H. Qed.

Lemma reff20_not3880 : ~ @Equation3880 Fin4 reff20_inst.
Proof. unfold Equation3880. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff20_inst, reff20_op in H. discriminate H. Qed.

Lemma reff20_not3881 : ~ @Equation3881 Fin4 reff20_inst.
Proof. unfold Equation3881. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff20_inst, reff20_op in H. discriminate H. Qed.

Lemma reff20_not3887 : ~ @Equation3887 Fin4 reff20_inst.
Proof. unfold Equation3887. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff20_inst, reff20_op in H. discriminate H. Qed.

Lemma reff20_not3888 : ~ @Equation3888 Fin4 reff20_inst.
Proof. unfold Equation3888. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff20_inst, reff20_op in H. discriminate H. Qed.

Lemma reff20_not3890 : ~ @Equation3890 Fin4 reff20_inst.
Proof. unfold Equation3890. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff20_inst, reff20_op in H. discriminate H. Qed.

Lemma reff20_not3917 : ~ @Equation3917 Fin4 reff20_inst.
Proof. unfold Equation3917. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff20_inst, reff20_op in H. discriminate H. Qed.

Lemma reff20_not3918 : ~ @Equation3918 Fin4 reff20_inst.
Proof. unfold Equation3918. intro H. specialize (H F4_3 F4_0). unfold magma_op, reff20_inst, reff20_op in H. discriminate H. Qed.

Lemma reff20_not3924 : ~ @Equation3924 Fin4 reff20_inst.
Proof. unfold Equation3924. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff20_inst, reff20_op in H. discriminate H. Qed.

Lemma reff20_not3925 : ~ @Equation3925 Fin4 reff20_inst.
Proof. unfold Equation3925. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff20_inst, reff20_op in H. discriminate H. Qed.

Lemma reff20_not3927 : ~ @Equation3927 Fin4 reff20_inst.
Proof. unfold Equation3927. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff20_inst, reff20_op in H. discriminate H. Qed.

Lemma reff20_not3951 : ~ @Equation3951 Fin4 reff20_inst.
Proof. unfold Equation3951. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff20_inst, reff20_op in H. discriminate H. Qed.

Lemma reff20_not3952 : ~ @Equation3952 Fin4 reff20_inst.
Proof. unfold Equation3952. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff20_inst, reff20_op in H. discriminate H. Qed.

Lemma reff20_not3954 : ~ @Equation3954 Fin4 reff20_inst.
Proof. unfold Equation3954. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff20_inst, reff20_op in H. discriminate H. Qed.

Lemma reff20_not3955 : ~ @Equation3955 Fin4 reff20_inst.
Proof. unfold Equation3955. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff20_inst, reff20_op in H. discriminate H. Qed.

Lemma reff20_not3961 : ~ @Equation3961 Fin4 reff20_inst.
Proof. unfold Equation3961. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff20_inst, reff20_op in H. discriminate H. Qed.

Lemma reff20_not3962 : ~ @Equation3962 Fin4 reff20_inst.
Proof. unfold Equation3962. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff20_inst, reff20_op in H. discriminate H. Qed.

Lemma reff20_not3964 : ~ @Equation3964 Fin4 reff20_inst.
Proof. unfold Equation3964. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff20_inst, reff20_op in H. discriminate H. Qed.

Lemma reff20_not4066 : ~ @Equation4066 Fin4 reff20_inst.
Proof. unfold Equation4066. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff20_inst, reff20_op in H. discriminate H. Qed.

Lemma reff20_not4067 : ~ @Equation4067 Fin4 reff20_inst.
Proof. unfold Equation4067. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff20_inst, reff20_op in H. discriminate H. Qed.

Lemma reff20_not4068 : ~ @Equation4068 Fin4 reff20_inst.
Proof. unfold Equation4068. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff20_inst, reff20_op in H. discriminate H. Qed.

Lemma reff20_not4070 : ~ @Equation4070 Fin4 reff20_inst.
Proof. unfold Equation4070. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff20_inst, reff20_op in H. discriminate H. Qed.

Lemma reff20_not4071 : ~ @Equation4071 Fin4 reff20_inst.
Proof. unfold Equation4071. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff20_inst, reff20_op in H. discriminate H. Qed.

Lemma reff20_not4073 : ~ @Equation4073 Fin4 reff20_inst.
Proof. unfold Equation4073. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff20_inst, reff20_op in H. discriminate H. Qed.

Lemma reff20_not4074 : ~ @Equation4074 Fin4 reff20_inst.
Proof. unfold Equation4074. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff20_inst, reff20_op in H. discriminate H. Qed.

Lemma reff20_not4080 : ~ @Equation4080 Fin4 reff20_inst.
Proof. unfold Equation4080. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff20_inst, reff20_op in H. discriminate H. Qed.

Lemma reff20_not4081 : ~ @Equation4081 Fin4 reff20_inst.
Proof. unfold Equation4081. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff20_inst, reff20_op in H. discriminate H. Qed.

Lemma reff20_not4083 : ~ @Equation4083 Fin4 reff20_inst.
Proof. unfold Equation4083. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff20_inst, reff20_op in H. discriminate H. Qed.

Lemma reff20_not4084 : ~ @Equation4084 Fin4 reff20_inst.
Proof. unfold Equation4084. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff20_inst, reff20_op in H. discriminate H. Qed.

Lemma reff20_not4090 : ~ @Equation4090 Fin4 reff20_inst.
Proof. unfold Equation4090. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff20_inst, reff20_op in H. discriminate H. Qed.

Lemma reff20_not4091 : ~ @Equation4091 Fin4 reff20_inst.
Proof. unfold Equation4091. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff20_inst, reff20_op in H. discriminate H. Qed.

Lemma reff20_not4093 : ~ @Equation4093 Fin4 reff20_inst.
Proof. unfold Equation4093. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff20_inst, reff20_op in H. discriminate H. Qed.

Lemma reff20_not4120 : ~ @Equation4120 Fin4 reff20_inst.
Proof. unfold Equation4120. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff20_inst, reff20_op in H. discriminate H. Qed.

Lemma reff20_not4127 : ~ @Equation4127 Fin4 reff20_inst.
Proof. unfold Equation4127. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff20_inst, reff20_op in H. discriminate H. Qed.

Lemma reff20_not4128 : ~ @Equation4128 Fin4 reff20_inst.
Proof. unfold Equation4128. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff20_inst, reff20_op in H. discriminate H. Qed.

Lemma reff20_not4130 : ~ @Equation4130 Fin4 reff20_inst.
Proof. unfold Equation4130. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff20_inst, reff20_op in H. discriminate H. Qed.

Lemma reff20_not4155 : ~ @Equation4155 Fin4 reff20_inst.
Proof. unfold Equation4155. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff20_inst, reff20_op in H. discriminate H. Qed.

Lemma reff20_not4157 : ~ @Equation4157 Fin4 reff20_inst.
Proof. unfold Equation4157. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff20_inst, reff20_op in H. discriminate H. Qed.

Lemma reff20_not4158 : ~ @Equation4158 Fin4 reff20_inst.
Proof. unfold Equation4158. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff20_inst, reff20_op in H. discriminate H. Qed.

Lemma reff20_not4164 : ~ @Equation4164 Fin4 reff20_inst.
Proof. unfold Equation4164. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff20_inst, reff20_op in H. discriminate H. Qed.

Lemma reff20_not4165 : ~ @Equation4165 Fin4 reff20_inst.
Proof. unfold Equation4165. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff20_inst, reff20_op in H. discriminate H. Qed.

Lemma reff20_not4167 : ~ @Equation4167 Fin4 reff20_inst.
Proof. unfold Equation4167. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff20_inst, reff20_op in H. discriminate H. Qed.

Lemma reff20_not4268 : ~ @Equation4268 Fin4 reff20_inst.
Proof. unfold Equation4268. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff20_inst, reff20_op in H. discriminate H. Qed.

Lemma reff20_not4269 : ~ @Equation4269 Fin4 reff20_inst.
Proof. unfold Equation4269. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff20_inst, reff20_op in H. discriminate H. Qed.

Lemma reff20_not4270 : ~ @Equation4270 Fin4 reff20_inst.
Proof. unfold Equation4270. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff20_inst, reff20_op in H. discriminate H. Qed.

Lemma reff20_not4272 : ~ @Equation4272 Fin4 reff20_inst.
Proof. unfold Equation4272. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff20_inst, reff20_op in H. discriminate H. Qed.

Lemma reff20_not4273 : ~ @Equation4273 Fin4 reff20_inst.
Proof. unfold Equation4273. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff20_inst, reff20_op in H. discriminate H. Qed.

Lemma reff20_not4275 : ~ @Equation4275 Fin4 reff20_inst.
Proof. unfold Equation4275. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff20_inst, reff20_op in H. discriminate H. Qed.

Lemma reff20_not4276 : ~ @Equation4276 Fin4 reff20_inst.
Proof. unfold Equation4276. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff20_inst, reff20_op in H. discriminate H. Qed.

Lemma reff20_not4283 : ~ @Equation4283 Fin4 reff20_inst.
Proof. unfold Equation4283. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff20_inst, reff20_op in H. discriminate H. Qed.

Lemma reff20_not4284 : ~ @Equation4284 Fin4 reff20_inst.
Proof. unfold Equation4284. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff20_inst, reff20_op in H. discriminate H. Qed.

Lemma reff20_not4290 : ~ @Equation4290 Fin4 reff20_inst.
Proof. unfold Equation4290. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff20_inst, reff20_op in H. discriminate H. Qed.

Lemma reff20_not4291 : ~ @Equation4291 Fin4 reff20_inst.
Proof. unfold Equation4291. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff20_inst, reff20_op in H. discriminate H. Qed.

Lemma reff20_not4293 : ~ @Equation4293 Fin4 reff20_inst.
Proof. unfold Equation4293. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff20_inst, reff20_op in H. discriminate H. Qed.

Lemma reff20_not4314 : ~ @Equation4314 Fin4 reff20_inst.
Proof. unfold Equation4314. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff20_inst, reff20_op in H. discriminate H. Qed.

Lemma reff20_not4320 : ~ @Equation4320 Fin4 reff20_inst.
Proof. unfold Equation4320. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff20_inst, reff20_op in H. discriminate H. Qed.

Lemma reff20_not4321 : ~ @Equation4321 Fin4 reff20_inst.
Proof. unfold Equation4321. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff20_inst, reff20_op in H. discriminate H. Qed.

Lemma reff20_not4343 : ~ @Equation4343 Fin4 reff20_inst.
Proof. unfold Equation4343. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff20_inst, reff20_op in H. discriminate H. Qed.

Lemma reff20_not4396 : ~ @Equation4396 Fin4 reff20_inst.
Proof. unfold Equation4396. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff20_inst, reff20_op in H. discriminate H. Qed.

Lemma reff20_not4398 : ~ @Equation4398 Fin4 reff20_inst.
Proof. unfold Equation4398. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff20_inst, reff20_op in H. discriminate H. Qed.

Lemma reff20_not4399 : ~ @Equation4399 Fin4 reff20_inst.
Proof. unfold Equation4399. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff20_inst, reff20_op in H. discriminate H. Qed.

Lemma reff20_not4405 : ~ @Equation4405 Fin4 reff20_inst.
Proof. unfold Equation4405. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff20_inst, reff20_op in H. discriminate H. Qed.

Lemma reff20_not4406 : ~ @Equation4406 Fin4 reff20_inst.
Proof. unfold Equation4406. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff20_inst, reff20_op in H. discriminate H. Qed.

Lemma reff20_not4408 : ~ @Equation4408 Fin4 reff20_inst.
Proof. unfold Equation4408. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff20_inst, reff20_op in H. discriminate H. Qed.

Lemma reff20_not4433 : ~ @Equation4433 Fin4 reff20_inst.
Proof. unfold Equation4433. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff20_inst, reff20_op in H. discriminate H. Qed.

Lemma reff20_not4435 : ~ @Equation4435 Fin4 reff20_inst.
Proof. unfold Equation4435. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff20_inst, reff20_op in H. discriminate H. Qed.

Lemma reff20_not4436 : ~ @Equation4436 Fin4 reff20_inst.
Proof. unfold Equation4436. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff20_inst, reff20_op in H. discriminate H. Qed.

Lemma reff20_not4442 : ~ @Equation4442 Fin4 reff20_inst.
Proof. unfold Equation4442. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff20_inst, reff20_op in H. discriminate H. Qed.

Lemma reff20_not4443 : ~ @Equation4443 Fin4 reff20_inst.
Proof. unfold Equation4443. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff20_inst, reff20_op in H. discriminate H. Qed.

Lemma reff20_not4445 : ~ @Equation4445 Fin4 reff20_inst.
Proof. unfold Equation4445. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff20_inst, reff20_op in H. discriminate H. Qed.

Lemma reff20_not4472 : ~ @Equation4472 Fin4 reff20_inst.
Proof. unfold Equation4472. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff20_inst, reff20_op in H. discriminate H. Qed.

Lemma reff20_not4479 : ~ @Equation4479 Fin4 reff20_inst.
Proof. unfold Equation4479. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff20_inst, reff20_op in H. discriminate H. Qed.

Lemma reff20_not4480 : ~ @Equation4480 Fin4 reff20_inst.
Proof. unfold Equation4480. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff20_inst, reff20_op in H. discriminate H. Qed.

Lemma reff20_not4482 : ~ @Equation4482 Fin4 reff20_inst.
Proof. unfold Equation4482. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff20_inst, reff20_op in H. discriminate H. Qed.

Lemma reff20_not4583 : ~ @Equation4583 Fin4 reff20_inst.
Proof. unfold Equation4583. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff20_inst, reff20_op in H. discriminate H. Qed.

Lemma reff20_not4584 : ~ @Equation4584 Fin4 reff20_inst.
Proof. unfold Equation4584. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff20_inst, reff20_op in H. discriminate H. Qed.

Lemma reff20_not4585 : ~ @Equation4585 Fin4 reff20_inst.
Proof. unfold Equation4585. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff20_inst, reff20_op in H. discriminate H. Qed.

Lemma reff20_not4587 : ~ @Equation4587 Fin4 reff20_inst.
Proof. unfold Equation4587. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff20_inst, reff20_op in H. discriminate H. Qed.

Lemma reff20_not4588 : ~ @Equation4588 Fin4 reff20_inst.
Proof. unfold Equation4588. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff20_inst, reff20_op in H. discriminate H. Qed.

Lemma reff20_not4590 : ~ @Equation4590 Fin4 reff20_inst.
Proof. unfold Equation4590. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff20_inst, reff20_op in H. discriminate H. Qed.

Lemma reff20_not4591 : ~ @Equation4591 Fin4 reff20_inst.
Proof. unfold Equation4591. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff20_inst, reff20_op in H. discriminate H. Qed.

Lemma reff20_not4598 : ~ @Equation4598 Fin4 reff20_inst.
Proof. unfold Equation4598. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff20_inst, reff20_op in H. discriminate H. Qed.

Lemma reff20_not4605 : ~ @Equation4605 Fin4 reff20_inst.
Proof. unfold Equation4605. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff20_inst, reff20_op in H. discriminate H. Qed.

Lemma reff20_not4606 : ~ @Equation4606 Fin4 reff20_inst.
Proof. unfold Equation4606. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff20_inst, reff20_op in H. discriminate H. Qed.

Lemma reff20_not4608 : ~ @Equation4608 Fin4 reff20_inst.
Proof. unfold Equation4608. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff20_inst, reff20_op in H. discriminate H. Qed.

Lemma reff20_not4629 : ~ @Equation4629 Fin4 reff20_inst.
Proof. unfold Equation4629. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff20_inst, reff20_op in H. discriminate H. Qed.

Lemma reff20_not4635 : ~ @Equation4635 Fin4 reff20_inst.
Proof. unfold Equation4635. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff20_inst, reff20_op in H. discriminate H. Qed.

Lemma reff20_not4636 : ~ @Equation4636 Fin4 reff20_inst.
Proof. unfold Equation4636. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff20_inst, reff20_op in H. discriminate H. Qed.

Lemma reff20_not4658 : ~ @Equation4658 Fin4 reff20_inst.
Proof. unfold Equation4658. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff20_inst, reff20_op in H. discriminate H. Qed.

(** ---- reff200 (Fin4) ---- *)

Definition reff200_op (x y : Fin4) : Fin4 :=
  match x, y with
  | F4_0, F4_0 => F4_0 | F4_0, F4_1 => F4_1 | F4_0, F4_2 => F4_2 | F4_0, F4_3 => F4_3
  | F4_1, F4_0 => F4_3 | F4_1, F4_1 => F4_3 | F4_1, F4_2 => F4_3 | F4_1, F4_3 => F4_3
  | F4_2, F4_0 => F4_2 | F4_2, F4_1 => F4_1 | F4_2, F4_2 => F4_0 | F4_2, F4_3 => F4_3
  | F4_3, F4_0 => F4_1 | F4_3, F4_1 => F4_3 | F4_3, F4_2 => F4_1 | F4_3, F4_3 => F4_3
  end.

#[local] Instance reff200_inst : Magma Fin4 := {| magma_op := reff200_op |}.

Lemma reff200_sat3253 : @Equation3253 Fin4 reff200_inst.
Proof. unfold Equation3253, magma_op, reff200_inst, reff200_op. intros x. destruct x; reflexivity. Qed.

Lemma reff200_sat3456 : @Equation3456 Fin4 reff200_inst.
Proof. unfold Equation3456, magma_op, reff200_inst, reff200_op. intros x. destruct x; reflexivity. Qed.

Lemma reff200_sat3862 : @Equation3862 Fin4 reff200_inst.
Proof. unfold Equation3862, magma_op, reff200_inst, reff200_op. intros x. destruct x; reflexivity. Qed.

Lemma reff200_sat4065 : @Equation4065 Fin4 reff200_inst.
Proof. unfold Equation4065, magma_op, reff200_inst, reff200_op. intros x. destruct x; reflexivity. Qed.

Lemma reff200_sat4362 : @Equation4362 Fin4 reff200_inst.
Proof. unfold Equation4362, magma_op, reff200_inst, reff200_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff200_sat4405 : @Equation4405 Fin4 reff200_inst.
Proof. unfold Equation4405, magma_op, reff200_inst, reff200_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff200_sat4435 : @Equation4435 Fin4 reff200_inst.
Proof. unfold Equation4435, magma_op, reff200_inst, reff200_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff200_sat4480 : @Equation4480 Fin4 reff200_inst.
Proof. unfold Equation4480, magma_op, reff200_inst, reff200_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff200_not47 : ~ @Equation47 Fin4 reff200_inst.
Proof. unfold Equation47. intro H. specialize (H F4_1). unfold magma_op, reff200_inst, reff200_op in H. discriminate H. Qed.

Lemma reff200_not99 : ~ @Equation99 Fin4 reff200_inst.
Proof. unfold Equation99. intro H. specialize (H F4_1). unfold magma_op, reff200_inst, reff200_op in H. discriminate H. Qed.

Lemma reff200_not151 : ~ @Equation151 Fin4 reff200_inst.
Proof. unfold Equation151. intro H. specialize (H F4_1). unfold magma_op, reff200_inst, reff200_op in H. discriminate H. Qed.

Lemma reff200_not203 : ~ @Equation203 Fin4 reff200_inst.
Proof. unfold Equation203. intro H. specialize (H F4_1). unfold magma_op, reff200_inst, reff200_op in H. discriminate H. Qed.

Lemma reff200_not255 : ~ @Equation255 Fin4 reff200_inst.
Proof. unfold Equation255. intro H. specialize (H F4_1). unfold magma_op, reff200_inst, reff200_op in H. discriminate H. Qed.

Lemma reff200_not307 : ~ @Equation307 Fin4 reff200_inst.
Proof. unfold Equation307. intro H. specialize (H F4_2). unfold magma_op, reff200_inst, reff200_op in H. discriminate H. Qed.

Lemma reff200_not359 : ~ @Equation359 Fin4 reff200_inst.
Proof. unfold Equation359. intro H. specialize (H F4_2). unfold magma_op, reff200_inst, reff200_op in H. discriminate H. Qed.

Lemma reff200_not411 : ~ @Equation411 Fin4 reff200_inst.
Proof. unfold Equation411. intro H. specialize (H F4_1). unfold magma_op, reff200_inst, reff200_op in H. discriminate H. Qed.

Lemma reff200_not614 : ~ @Equation614 Fin4 reff200_inst.
Proof. unfold Equation614. intro H. specialize (H F4_1). unfold magma_op, reff200_inst, reff200_op in H. discriminate H. Qed.

Lemma reff200_not817 : ~ @Equation817 Fin4 reff200_inst.
Proof. unfold Equation817. intro H. specialize (H F4_1). unfold magma_op, reff200_inst, reff200_op in H. discriminate H. Qed.

Lemma reff200_not1020 : ~ @Equation1020 Fin4 reff200_inst.
Proof. unfold Equation1020. intro H. specialize (H F4_1). unfold magma_op, reff200_inst, reff200_op in H. discriminate H. Qed.

Lemma reff200_not1223 : ~ @Equation1223 Fin4 reff200_inst.
Proof. unfold Equation1223. intro H. specialize (H F4_1). unfold magma_op, reff200_inst, reff200_op in H. discriminate H. Qed.

Lemma reff200_not1426 : ~ @Equation1426 Fin4 reff200_inst.
Proof. unfold Equation1426. intro H. specialize (H F4_1). unfold magma_op, reff200_inst, reff200_op in H. discriminate H. Qed.

Lemma reff200_not1629 : ~ @Equation1629 Fin4 reff200_inst.
Proof. unfold Equation1629. intro H. specialize (H F4_1). unfold magma_op, reff200_inst, reff200_op in H. discriminate H. Qed.

Lemma reff200_not1832 : ~ @Equation1832 Fin4 reff200_inst.
Proof. unfold Equation1832. intro H. specialize (H F4_1). unfold magma_op, reff200_inst, reff200_op in H. discriminate H. Qed.

Lemma reff200_not2035 : ~ @Equation2035 Fin4 reff200_inst.
Proof. unfold Equation2035. intro H. specialize (H F4_1). unfold magma_op, reff200_inst, reff200_op in H. discriminate H. Qed.

Lemma reff200_not2238 : ~ @Equation2238 Fin4 reff200_inst.
Proof. unfold Equation2238. intro H. specialize (H F4_1). unfold magma_op, reff200_inst, reff200_op in H. discriminate H. Qed.

Lemma reff200_not2441 : ~ @Equation2441 Fin4 reff200_inst.
Proof. unfold Equation2441. intro H. specialize (H F4_1). unfold magma_op, reff200_inst, reff200_op in H. discriminate H. Qed.

Lemma reff200_not2644 : ~ @Equation2644 Fin4 reff200_inst.
Proof. unfold Equation2644. intro H. specialize (H F4_1). unfold magma_op, reff200_inst, reff200_op in H. discriminate H. Qed.

Lemma reff200_not2847 : ~ @Equation2847 Fin4 reff200_inst.
Proof. unfold Equation2847. intro H. specialize (H F4_1). unfold magma_op, reff200_inst, reff200_op in H. discriminate H. Qed.

Lemma reff200_not3050 : ~ @Equation3050 Fin4 reff200_inst.
Proof. unfold Equation3050. intro H. specialize (H F4_1). unfold magma_op, reff200_inst, reff200_op in H. discriminate H. Qed.

Lemma reff200_not3254 : ~ @Equation3254 Fin4 reff200_inst.
Proof. unfold Equation3254. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff200_inst, reff200_op in H. discriminate H. Qed.

Lemma reff200_not3255 : ~ @Equation3255 Fin4 reff200_inst.
Proof. unfold Equation3255. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff200_inst, reff200_op in H. discriminate H. Qed.

Lemma reff200_not3256 : ~ @Equation3256 Fin4 reff200_inst.
Proof. unfold Equation3256. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff200_inst, reff200_op in H. discriminate H. Qed.

Lemma reff200_not3258 : ~ @Equation3258 Fin4 reff200_inst.
Proof. unfold Equation3258. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff200_inst, reff200_op in H. discriminate H. Qed.

Lemma reff200_not3259 : ~ @Equation3259 Fin4 reff200_inst.
Proof. unfold Equation3259. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff200_inst, reff200_op in H. discriminate H. Qed.

Lemma reff200_not3261 : ~ @Equation3261 Fin4 reff200_inst.
Proof. unfold Equation3261. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff200_inst, reff200_op in H. discriminate H. Qed.

Lemma reff200_not3262 : ~ @Equation3262 Fin4 reff200_inst.
Proof. unfold Equation3262. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff200_inst, reff200_op in H. discriminate H. Qed.

Lemma reff200_not3268 : ~ @Equation3268 Fin4 reff200_inst.
Proof. unfold Equation3268. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff200_inst, reff200_op in H. discriminate H. Qed.

Lemma reff200_not3269 : ~ @Equation3269 Fin4 reff200_inst.
Proof. unfold Equation3269. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff200_inst, reff200_op in H. discriminate H. Qed.

Lemma reff200_not3271 : ~ @Equation3271 Fin4 reff200_inst.
Proof. unfold Equation3271. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff200_inst, reff200_op in H. discriminate H. Qed.

Lemma reff200_not3272 : ~ @Equation3272 Fin4 reff200_inst.
Proof. unfold Equation3272. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff200_inst, reff200_op in H. discriminate H. Qed.

Lemma reff200_not3278 : ~ @Equation3278 Fin4 reff200_inst.
Proof. unfold Equation3278. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff200_inst, reff200_op in H. discriminate H. Qed.

Lemma reff200_not3279 : ~ @Equation3279 Fin4 reff200_inst.
Proof. unfold Equation3279. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff200_inst, reff200_op in H. discriminate H. Qed.

Lemma reff200_not3281 : ~ @Equation3281 Fin4 reff200_inst.
Proof. unfold Equation3281. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff200_inst, reff200_op in H. discriminate H. Qed.

Lemma reff200_not3306 : ~ @Equation3306 Fin4 reff200_inst.
Proof. unfold Equation3306. intro H. specialize (H F4_3 F4_0). unfold magma_op, reff200_inst, reff200_op in H. discriminate H. Qed.

Lemma reff200_not3308 : ~ @Equation3308 Fin4 reff200_inst.
Proof. unfold Equation3308. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff200_inst, reff200_op in H. discriminate H. Qed.

Lemma reff200_not3309 : ~ @Equation3309 Fin4 reff200_inst.
Proof. unfold Equation3309. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff200_inst, reff200_op in H. discriminate H. Qed.

Lemma reff200_not3315 : ~ @Equation3315 Fin4 reff200_inst.
Proof. unfold Equation3315. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff200_inst, reff200_op in H. discriminate H. Qed.

Lemma reff200_not3316 : ~ @Equation3316 Fin4 reff200_inst.
Proof. unfold Equation3316. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff200_inst, reff200_op in H. discriminate H. Qed.

Lemma reff200_not3318 : ~ @Equation3318 Fin4 reff200_inst.
Proof. unfold Equation3318. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff200_inst, reff200_op in H. discriminate H. Qed.

Lemma reff200_not3319 : ~ @Equation3319 Fin4 reff200_inst.
Proof. unfold Equation3319. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff200_inst, reff200_op in H. discriminate H. Qed.

Lemma reff200_not3342 : ~ @Equation3342 Fin4 reff200_inst.
Proof. unfold Equation3342. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff200_inst, reff200_op in H. discriminate H. Qed.

Lemma reff200_not3343 : ~ @Equation3343 Fin4 reff200_inst.
Proof. unfold Equation3343. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff200_inst, reff200_op in H. discriminate H. Qed.

Lemma reff200_not3345 : ~ @Equation3345 Fin4 reff200_inst.
Proof. unfold Equation3345. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff200_inst, reff200_op in H. discriminate H. Qed.

Lemma reff200_not3346 : ~ @Equation3346 Fin4 reff200_inst.
Proof. unfold Equation3346. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff200_inst, reff200_op in H. discriminate H. Qed.

Lemma reff200_not3352 : ~ @Equation3352 Fin4 reff200_inst.
Proof. unfold Equation3352. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff200_inst, reff200_op in H. discriminate H. Qed.

Lemma reff200_not3353 : ~ @Equation3353 Fin4 reff200_inst.
Proof. unfold Equation3353. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff200_inst, reff200_op in H. discriminate H. Qed.

Lemma reff200_not3355 : ~ @Equation3355 Fin4 reff200_inst.
Proof. unfold Equation3355. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff200_inst, reff200_op in H. discriminate H. Qed.

Lemma reff200_not3457 : ~ @Equation3457 Fin4 reff200_inst.
Proof. unfold Equation3457. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff200_inst, reff200_op in H. discriminate H. Qed.

Lemma reff200_not3458 : ~ @Equation3458 Fin4 reff200_inst.
Proof. unfold Equation3458. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff200_inst, reff200_op in H. discriminate H. Qed.

Lemma reff200_not3459 : ~ @Equation3459 Fin4 reff200_inst.
Proof. unfold Equation3459. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff200_inst, reff200_op in H. discriminate H. Qed.

Lemma reff200_not3461 : ~ @Equation3461 Fin4 reff200_inst.
Proof. unfold Equation3461. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff200_inst, reff200_op in H. discriminate H. Qed.

Lemma reff200_not3462 : ~ @Equation3462 Fin4 reff200_inst.
Proof. unfold Equation3462. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff200_inst, reff200_op in H. discriminate H. Qed.

Lemma reff200_not3464 : ~ @Equation3464 Fin4 reff200_inst.
Proof. unfold Equation3464. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff200_inst, reff200_op in H. discriminate H. Qed.

Lemma reff200_not3465 : ~ @Equation3465 Fin4 reff200_inst.
Proof. unfold Equation3465. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff200_inst, reff200_op in H. discriminate H. Qed.

Lemma reff200_not3472 : ~ @Equation3472 Fin4 reff200_inst.
Proof. unfold Equation3472. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff200_inst, reff200_op in H. discriminate H. Qed.

Lemma reff200_not3474 : ~ @Equation3474 Fin4 reff200_inst.
Proof. unfold Equation3474. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff200_inst, reff200_op in H. discriminate H. Qed.

Lemma reff200_not3475 : ~ @Equation3475 Fin4 reff200_inst.
Proof. unfold Equation3475. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff200_inst, reff200_op in H. discriminate H. Qed.

Lemma reff200_not3481 : ~ @Equation3481 Fin4 reff200_inst.
Proof. unfold Equation3481. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff200_inst, reff200_op in H. discriminate H. Qed.

Lemma reff200_not3482 : ~ @Equation3482 Fin4 reff200_inst.
Proof. unfold Equation3482. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff200_inst, reff200_op in H. discriminate H. Qed.

Lemma reff200_not3484 : ~ @Equation3484 Fin4 reff200_inst.
Proof. unfold Equation3484. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff200_inst, reff200_op in H. discriminate H. Qed.

Lemma reff200_not3509 : ~ @Equation3509 Fin4 reff200_inst.
Proof. unfold Equation3509. intro H. specialize (H F4_3 F4_0). unfold magma_op, reff200_inst, reff200_op in H. discriminate H. Qed.

Lemma reff200_not3511 : ~ @Equation3511 Fin4 reff200_inst.
Proof. unfold Equation3511. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff200_inst, reff200_op in H. discriminate H. Qed.

Lemma reff200_not3512 : ~ @Equation3512 Fin4 reff200_inst.
Proof. unfold Equation3512. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff200_inst, reff200_op in H. discriminate H. Qed.

Lemma reff200_not3518 : ~ @Equation3518 Fin4 reff200_inst.
Proof. unfold Equation3518. intro H. specialize (H F4_3 F4_0). unfold magma_op, reff200_inst, reff200_op in H. discriminate H. Qed.

Lemma reff200_not3519 : ~ @Equation3519 Fin4 reff200_inst.
Proof. unfold Equation3519. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff200_inst, reff200_op in H. discriminate H. Qed.

Lemma reff200_not3521 : ~ @Equation3521 Fin4 reff200_inst.
Proof. unfold Equation3521. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff200_inst, reff200_op in H. discriminate H. Qed.

Lemma reff200_not3522 : ~ @Equation3522 Fin4 reff200_inst.
Proof. unfold Equation3522. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff200_inst, reff200_op in H. discriminate H. Qed.

Lemma reff200_not3545 : ~ @Equation3545 Fin4 reff200_inst.
Proof. unfold Equation3545. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff200_inst, reff200_op in H. discriminate H. Qed.

Lemma reff200_not3546 : ~ @Equation3546 Fin4 reff200_inst.
Proof. unfold Equation3546. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff200_inst, reff200_op in H. discriminate H. Qed.

Lemma reff200_not3548 : ~ @Equation3548 Fin4 reff200_inst.
Proof. unfold Equation3548. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff200_inst, reff200_op in H. discriminate H. Qed.

Lemma reff200_not3549 : ~ @Equation3549 Fin4 reff200_inst.
Proof. unfold Equation3549. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff200_inst, reff200_op in H. discriminate H. Qed.

Lemma reff200_not3555 : ~ @Equation3555 Fin4 reff200_inst.
Proof. unfold Equation3555. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff200_inst, reff200_op in H. discriminate H. Qed.

Lemma reff200_not3556 : ~ @Equation3556 Fin4 reff200_inst.
Proof. unfold Equation3556. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff200_inst, reff200_op in H. discriminate H. Qed.

Lemma reff200_not3558 : ~ @Equation3558 Fin4 reff200_inst.
Proof. unfold Equation3558. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff200_inst, reff200_op in H. discriminate H. Qed.

Lemma reff200_not3660 : ~ @Equation3660 Fin4 reff200_inst.
Proof. unfold Equation3660. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff200_inst, reff200_op in H. discriminate H. Qed.

Lemma reff200_not3661 : ~ @Equation3661 Fin4 reff200_inst.
Proof. unfold Equation3661. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff200_inst, reff200_op in H. discriminate H. Qed.

Lemma reff200_not3662 : ~ @Equation3662 Fin4 reff200_inst.
Proof. unfold Equation3662. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff200_inst, reff200_op in H. discriminate H. Qed.

Lemma reff200_not3664 : ~ @Equation3664 Fin4 reff200_inst.
Proof. unfold Equation3664. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff200_inst, reff200_op in H. discriminate H. Qed.

Lemma reff200_not3665 : ~ @Equation3665 Fin4 reff200_inst.
Proof. unfold Equation3665. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff200_inst, reff200_op in H. discriminate H. Qed.

Lemma reff200_not3667 : ~ @Equation3667 Fin4 reff200_inst.
Proof. unfold Equation3667. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff200_inst, reff200_op in H. discriminate H. Qed.

Lemma reff200_not3668 : ~ @Equation3668 Fin4 reff200_inst.
Proof. unfold Equation3668. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff200_inst, reff200_op in H. discriminate H. Qed.

Lemma reff200_not3674 : ~ @Equation3674 Fin4 reff200_inst.
Proof. unfold Equation3674. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff200_inst, reff200_op in H. discriminate H. Qed.

Lemma reff200_not3675 : ~ @Equation3675 Fin4 reff200_inst.
Proof. unfold Equation3675. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff200_inst, reff200_op in H. discriminate H. Qed.

Lemma reff200_not3677 : ~ @Equation3677 Fin4 reff200_inst.
Proof. unfold Equation3677. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff200_inst, reff200_op in H. discriminate H. Qed.

Lemma reff200_not3678 : ~ @Equation3678 Fin4 reff200_inst.
Proof. unfold Equation3678. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff200_inst, reff200_op in H. discriminate H. Qed.

Lemma reff200_not3684 : ~ @Equation3684 Fin4 reff200_inst.
Proof. unfold Equation3684. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff200_inst, reff200_op in H. discriminate H. Qed.

Lemma reff200_not3685 : ~ @Equation3685 Fin4 reff200_inst.
Proof. unfold Equation3685. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff200_inst, reff200_op in H. discriminate H. Qed.

Lemma reff200_not3687 : ~ @Equation3687 Fin4 reff200_inst.
Proof. unfold Equation3687. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff200_inst, reff200_op in H. discriminate H. Qed.

Lemma reff200_not3712 : ~ @Equation3712 Fin4 reff200_inst.
Proof. unfold Equation3712. intro H. specialize (H F4_3 F4_0). unfold magma_op, reff200_inst, reff200_op in H. discriminate H. Qed.

Lemma reff200_not3714 : ~ @Equation3714 Fin4 reff200_inst.
Proof. unfold Equation3714. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff200_inst, reff200_op in H. discriminate H. Qed.

Lemma reff200_not3721 : ~ @Equation3721 Fin4 reff200_inst.
Proof. unfold Equation3721. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff200_inst, reff200_op in H. discriminate H. Qed.

Lemma reff200_not3722 : ~ @Equation3722 Fin4 reff200_inst.
Proof. unfold Equation3722. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff200_inst, reff200_op in H. discriminate H. Qed.

Lemma reff200_not3724 : ~ @Equation3724 Fin4 reff200_inst.
Proof. unfold Equation3724. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff200_inst, reff200_op in H. discriminate H. Qed.

Lemma reff200_not3725 : ~ @Equation3725 Fin4 reff200_inst.
Proof. unfold Equation3725. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff200_inst, reff200_op in H. discriminate H. Qed.

Lemma reff200_not3748 : ~ @Equation3748 Fin4 reff200_inst.
Proof. unfold Equation3748. intro H. specialize (H F4_3 F4_0). unfold magma_op, reff200_inst, reff200_op in H. discriminate H. Qed.

Lemma reff200_not3749 : ~ @Equation3749 Fin4 reff200_inst.
Proof. unfold Equation3749. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff200_inst, reff200_op in H. discriminate H. Qed.

Lemma reff200_not3751 : ~ @Equation3751 Fin4 reff200_inst.
Proof. unfold Equation3751. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff200_inst, reff200_op in H. discriminate H. Qed.

Lemma reff200_not3752 : ~ @Equation3752 Fin4 reff200_inst.
Proof. unfold Equation3752. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff200_inst, reff200_op in H. discriminate H. Qed.

Lemma reff200_not3759 : ~ @Equation3759 Fin4 reff200_inst.
Proof. unfold Equation3759. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff200_inst, reff200_op in H. discriminate H. Qed.

Lemma reff200_not3761 : ~ @Equation3761 Fin4 reff200_inst.
Proof. unfold Equation3761. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff200_inst, reff200_op in H. discriminate H. Qed.

Lemma reff200_not3864 : ~ @Equation3864 Fin4 reff200_inst.
Proof. unfold Equation3864. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff200_inst, reff200_op in H. discriminate H. Qed.

Lemma reff200_not3865 : ~ @Equation3865 Fin4 reff200_inst.
Proof. unfold Equation3865. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff200_inst, reff200_op in H. discriminate H. Qed.

Lemma reff200_not3867 : ~ @Equation3867 Fin4 reff200_inst.
Proof. unfold Equation3867. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff200_inst, reff200_op in H. discriminate H. Qed.

Lemma reff200_not3868 : ~ @Equation3868 Fin4 reff200_inst.
Proof. unfold Equation3868. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff200_inst, reff200_op in H. discriminate H. Qed.

Lemma reff200_not3870 : ~ @Equation3870 Fin4 reff200_inst.
Proof. unfold Equation3870. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff200_inst, reff200_op in H. discriminate H. Qed.

Lemma reff200_not3871 : ~ @Equation3871 Fin4 reff200_inst.
Proof. unfold Equation3871. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff200_inst, reff200_op in H. discriminate H. Qed.

Lemma reff200_not3877 : ~ @Equation3877 Fin4 reff200_inst.
Proof. unfold Equation3877. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff200_inst, reff200_op in H. discriminate H. Qed.

Lemma reff200_not3878 : ~ @Equation3878 Fin4 reff200_inst.
Proof. unfold Equation3878. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff200_inst, reff200_op in H. discriminate H. Qed.

Lemma reff200_not3880 : ~ @Equation3880 Fin4 reff200_inst.
Proof. unfold Equation3880. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff200_inst, reff200_op in H. discriminate H. Qed.

Lemma reff200_not3881 : ~ @Equation3881 Fin4 reff200_inst.
Proof. unfold Equation3881. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff200_inst, reff200_op in H. discriminate H. Qed.

Lemma reff200_not3887 : ~ @Equation3887 Fin4 reff200_inst.
Proof. unfold Equation3887. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff200_inst, reff200_op in H. discriminate H. Qed.

Lemma reff200_not3888 : ~ @Equation3888 Fin4 reff200_inst.
Proof. unfold Equation3888. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff200_inst, reff200_op in H. discriminate H. Qed.

Lemma reff200_not3890 : ~ @Equation3890 Fin4 reff200_inst.
Proof. unfold Equation3890. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff200_inst, reff200_op in H. discriminate H. Qed.

Lemma reff200_not3915 : ~ @Equation3915 Fin4 reff200_inst.
Proof. unfold Equation3915. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff200_inst, reff200_op in H. discriminate H. Qed.

Lemma reff200_not3917 : ~ @Equation3917 Fin4 reff200_inst.
Proof. unfold Equation3917. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff200_inst, reff200_op in H. discriminate H. Qed.

Lemma reff200_not3918 : ~ @Equation3918 Fin4 reff200_inst.
Proof. unfold Equation3918. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff200_inst, reff200_op in H. discriminate H. Qed.

Lemma reff200_not3924 : ~ @Equation3924 Fin4 reff200_inst.
Proof. unfold Equation3924. intro H. specialize (H F4_3 F4_0). unfold magma_op, reff200_inst, reff200_op in H. discriminate H. Qed.

Lemma reff200_not3925 : ~ @Equation3925 Fin4 reff200_inst.
Proof. unfold Equation3925. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff200_inst, reff200_op in H. discriminate H. Qed.

Lemma reff200_not3927 : ~ @Equation3927 Fin4 reff200_inst.
Proof. unfold Equation3927. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff200_inst, reff200_op in H. discriminate H. Qed.

Lemma reff200_not3928 : ~ @Equation3928 Fin4 reff200_inst.
Proof. unfold Equation3928. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff200_inst, reff200_op in H. discriminate H. Qed.

Lemma reff200_not3951 : ~ @Equation3951 Fin4 reff200_inst.
Proof. unfold Equation3951. intro H. specialize (H F4_3 F4_0). unfold magma_op, reff200_inst, reff200_op in H. discriminate H. Qed.

Lemma reff200_not3952 : ~ @Equation3952 Fin4 reff200_inst.
Proof. unfold Equation3952. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff200_inst, reff200_op in H. discriminate H. Qed.

Lemma reff200_not3954 : ~ @Equation3954 Fin4 reff200_inst.
Proof. unfold Equation3954. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff200_inst, reff200_op in H. discriminate H. Qed.

Lemma reff200_not3955 : ~ @Equation3955 Fin4 reff200_inst.
Proof. unfold Equation3955. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff200_inst, reff200_op in H. discriminate H. Qed.

Lemma reff200_not3961 : ~ @Equation3961 Fin4 reff200_inst.
Proof. unfold Equation3961. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff200_inst, reff200_op in H. discriminate H. Qed.

Lemma reff200_not3962 : ~ @Equation3962 Fin4 reff200_inst.
Proof. unfold Equation3962. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff200_inst, reff200_op in H. discriminate H. Qed.

Lemma reff200_not3964 : ~ @Equation3964 Fin4 reff200_inst.
Proof. unfold Equation3964. intro H. specialize (H F4_0 F4_3). unfold magma_op, reff200_inst, reff200_op in H. discriminate H. Qed.

Lemma reff200_not4066 : ~ @Equation4066 Fin4 reff200_inst.
Proof. unfold Equation4066. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff200_inst, reff200_op in H. discriminate H. Qed.

Lemma reff200_not4067 : ~ @Equation4067 Fin4 reff200_inst.
Proof. unfold Equation4067. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff200_inst, reff200_op in H. discriminate H. Qed.

Lemma reff200_not4068 : ~ @Equation4068 Fin4 reff200_inst.
Proof. unfold Equation4068. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff200_inst, reff200_op in H. discriminate H. Qed.

Lemma reff200_not4070 : ~ @Equation4070 Fin4 reff200_inst.
Proof. unfold Equation4070. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff200_inst, reff200_op in H. discriminate H. Qed.

Lemma reff200_not4071 : ~ @Equation4071 Fin4 reff200_inst.
Proof. unfold Equation4071. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff200_inst, reff200_op in H. discriminate H. Qed.

Lemma reff200_not4073 : ~ @Equation4073 Fin4 reff200_inst.
Proof. unfold Equation4073. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff200_inst, reff200_op in H. discriminate H. Qed.

Lemma reff200_not4074 : ~ @Equation4074 Fin4 reff200_inst.
Proof. unfold Equation4074. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff200_inst, reff200_op in H. discriminate H. Qed.

Lemma reff200_not4080 : ~ @Equation4080 Fin4 reff200_inst.
Proof. unfold Equation4080. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff200_inst, reff200_op in H. discriminate H. Qed.

Lemma reff200_not4081 : ~ @Equation4081 Fin4 reff200_inst.
Proof. unfold Equation4081. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff200_inst, reff200_op in H. discriminate H. Qed.

Lemma reff200_not4083 : ~ @Equation4083 Fin4 reff200_inst.
Proof. unfold Equation4083. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff200_inst, reff200_op in H. discriminate H. Qed.

Lemma reff200_not4084 : ~ @Equation4084 Fin4 reff200_inst.
Proof. unfold Equation4084. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff200_inst, reff200_op in H. discriminate H. Qed.

Lemma reff200_not4090 : ~ @Equation4090 Fin4 reff200_inst.
Proof. unfold Equation4090. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff200_inst, reff200_op in H. discriminate H. Qed.

Lemma reff200_not4091 : ~ @Equation4091 Fin4 reff200_inst.
Proof. unfold Equation4091. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff200_inst, reff200_op in H. discriminate H. Qed.

Lemma reff200_not4093 : ~ @Equation4093 Fin4 reff200_inst.
Proof. unfold Equation4093. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff200_inst, reff200_op in H. discriminate H. Qed.

Lemma reff200_not4118 : ~ @Equation4118 Fin4 reff200_inst.
Proof. unfold Equation4118. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff200_inst, reff200_op in H. discriminate H. Qed.

Lemma reff200_not4120 : ~ @Equation4120 Fin4 reff200_inst.
Proof. unfold Equation4120. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff200_inst, reff200_op in H. discriminate H. Qed.

Lemma reff200_not4121 : ~ @Equation4121 Fin4 reff200_inst.
Proof. unfold Equation4121. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff200_inst, reff200_op in H. discriminate H. Qed.

Lemma reff200_not4127 : ~ @Equation4127 Fin4 reff200_inst.
Proof. unfold Equation4127. intro H. specialize (H F4_3 F4_0). unfold magma_op, reff200_inst, reff200_op in H. discriminate H. Qed.

Lemma reff200_not4128 : ~ @Equation4128 Fin4 reff200_inst.
Proof. unfold Equation4128. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff200_inst, reff200_op in H. discriminate H. Qed.

Lemma reff200_not4130 : ~ @Equation4130 Fin4 reff200_inst.
Proof. unfold Equation4130. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff200_inst, reff200_op in H. discriminate H. Qed.

Lemma reff200_not4131 : ~ @Equation4131 Fin4 reff200_inst.
Proof. unfold Equation4131. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff200_inst, reff200_op in H. discriminate H. Qed.

Lemma reff200_not4154 : ~ @Equation4154 Fin4 reff200_inst.
Proof. unfold Equation4154. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff200_inst, reff200_op in H. discriminate H. Qed.

Lemma reff200_not4155 : ~ @Equation4155 Fin4 reff200_inst.
Proof. unfold Equation4155. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff200_inst, reff200_op in H. discriminate H. Qed.

Lemma reff200_not4157 : ~ @Equation4157 Fin4 reff200_inst.
Proof. unfold Equation4157. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff200_inst, reff200_op in H. discriminate H. Qed.

Lemma reff200_not4158 : ~ @Equation4158 Fin4 reff200_inst.
Proof. unfold Equation4158. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff200_inst, reff200_op in H. discriminate H. Qed.

Lemma reff200_not4164 : ~ @Equation4164 Fin4 reff200_inst.
Proof. unfold Equation4164. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff200_inst, reff200_op in H. discriminate H. Qed.

Lemma reff200_not4165 : ~ @Equation4165 Fin4 reff200_inst.
Proof. unfold Equation4165. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff200_inst, reff200_op in H. discriminate H. Qed.

Lemma reff200_not4167 : ~ @Equation4167 Fin4 reff200_inst.
Proof. unfold Equation4167. intro H. specialize (H F4_0 F4_3). unfold magma_op, reff200_inst, reff200_op in H. discriminate H. Qed.

Lemma reff200_not4268 : ~ @Equation4268 Fin4 reff200_inst.
Proof. unfold Equation4268. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff200_inst, reff200_op in H. discriminate H. Qed.

Lemma reff200_not4269 : ~ @Equation4269 Fin4 reff200_inst.
Proof. unfold Equation4269. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff200_inst, reff200_op in H. discriminate H. Qed.

Lemma reff200_not4270 : ~ @Equation4270 Fin4 reff200_inst.
Proof. unfold Equation4270. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff200_inst, reff200_op in H. discriminate H. Qed.

Lemma reff200_not4272 : ~ @Equation4272 Fin4 reff200_inst.
Proof. unfold Equation4272. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff200_inst, reff200_op in H. discriminate H. Qed.

Lemma reff200_not4273 : ~ @Equation4273 Fin4 reff200_inst.
Proof. unfold Equation4273. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff200_inst, reff200_op in H. discriminate H. Qed.

Lemma reff200_not4275 : ~ @Equation4275 Fin4 reff200_inst.
Proof. unfold Equation4275. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff200_inst, reff200_op in H. discriminate H. Qed.

Lemma reff200_not4276 : ~ @Equation4276 Fin4 reff200_inst.
Proof. unfold Equation4276. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff200_inst, reff200_op in H. discriminate H. Qed.

Lemma reff200_not4283 : ~ @Equation4283 Fin4 reff200_inst.
Proof. unfold Equation4283. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff200_inst, reff200_op in H. discriminate H. Qed.

Lemma reff200_not4284 : ~ @Equation4284 Fin4 reff200_inst.
Proof. unfold Equation4284. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff200_inst, reff200_op in H. discriminate H. Qed.

Lemma reff200_not4290 : ~ @Equation4290 Fin4 reff200_inst.
Proof. unfold Equation4290. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff200_inst, reff200_op in H. discriminate H. Qed.

Lemma reff200_not4291 : ~ @Equation4291 Fin4 reff200_inst.
Proof. unfold Equation4291. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff200_inst, reff200_op in H. discriminate H. Qed.

Lemma reff200_not4293 : ~ @Equation4293 Fin4 reff200_inst.
Proof. unfold Equation4293. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff200_inst, reff200_op in H. discriminate H. Qed.

Lemma reff200_not4314 : ~ @Equation4314 Fin4 reff200_inst.
Proof. unfold Equation4314. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff200_inst, reff200_op in H. discriminate H. Qed.

Lemma reff200_not4321 : ~ @Equation4321 Fin4 reff200_inst.
Proof. unfold Equation4321. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff200_inst, reff200_op in H. discriminate H. Qed.

Lemma reff200_not4343 : ~ @Equation4343 Fin4 reff200_inst.
Proof. unfold Equation4343. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff200_inst, reff200_op in H. discriminate H. Qed.

Lemma reff200_not4396 : ~ @Equation4396 Fin4 reff200_inst.
Proof. unfold Equation4396. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff200_inst, reff200_op in H. discriminate H. Qed.

Lemma reff200_not4398 : ~ @Equation4398 Fin4 reff200_inst.
Proof. unfold Equation4398. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff200_inst, reff200_op in H. discriminate H. Qed.

Lemma reff200_not4399 : ~ @Equation4399 Fin4 reff200_inst.
Proof. unfold Equation4399. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff200_inst, reff200_op in H. discriminate H. Qed.

Lemma reff200_not4406 : ~ @Equation4406 Fin4 reff200_inst.
Proof. unfold Equation4406. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff200_inst, reff200_op in H. discriminate H. Qed.

Lemma reff200_not4408 : ~ @Equation4408 Fin4 reff200_inst.
Proof. unfold Equation4408. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff200_inst, reff200_op in H. discriminate H. Qed.

Lemma reff200_not4433 : ~ @Equation4433 Fin4 reff200_inst.
Proof. unfold Equation4433. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff200_inst, reff200_op in H. discriminate H. Qed.

Lemma reff200_not4436 : ~ @Equation4436 Fin4 reff200_inst.
Proof. unfold Equation4436. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff200_inst, reff200_op in H. discriminate H. Qed.

Lemma reff200_not4442 : ~ @Equation4442 Fin4 reff200_inst.
Proof. unfold Equation4442. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff200_inst, reff200_op in H. discriminate H. Qed.

Lemma reff200_not4443 : ~ @Equation4443 Fin4 reff200_inst.
Proof. unfold Equation4443. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff200_inst, reff200_op in H. discriminate H. Qed.

Lemma reff200_not4445 : ~ @Equation4445 Fin4 reff200_inst.
Proof. unfold Equation4445. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff200_inst, reff200_op in H. discriminate H. Qed.

Lemma reff200_not4470 : ~ @Equation4470 Fin4 reff200_inst.
Proof. unfold Equation4470. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff200_inst, reff200_op in H. discriminate H. Qed.

Lemma reff200_not4472 : ~ @Equation4472 Fin4 reff200_inst.
Proof. unfold Equation4472. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff200_inst, reff200_op in H. discriminate H. Qed.

Lemma reff200_not4473 : ~ @Equation4473 Fin4 reff200_inst.
Proof. unfold Equation4473. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff200_inst, reff200_op in H. discriminate H. Qed.

Lemma reff200_not4479 : ~ @Equation4479 Fin4 reff200_inst.
Proof. unfold Equation4479. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff200_inst, reff200_op in H. discriminate H. Qed.

Lemma reff200_not4482 : ~ @Equation4482 Fin4 reff200_inst.
Proof. unfold Equation4482. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff200_inst, reff200_op in H. discriminate H. Qed.

Lemma reff200_not4583 : ~ @Equation4583 Fin4 reff200_inst.
Proof. unfold Equation4583. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff200_inst, reff200_op in H. discriminate H. Qed.

Lemma reff200_not4584 : ~ @Equation4584 Fin4 reff200_inst.
Proof. unfold Equation4584. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff200_inst, reff200_op in H. discriminate H. Qed.

Lemma reff200_not4585 : ~ @Equation4585 Fin4 reff200_inst.
Proof. unfold Equation4585. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff200_inst, reff200_op in H. discriminate H. Qed.

Lemma reff200_not4587 : ~ @Equation4587 Fin4 reff200_inst.
Proof. unfold Equation4587. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff200_inst, reff200_op in H. discriminate H. Qed.

Lemma reff200_not4588 : ~ @Equation4588 Fin4 reff200_inst.
Proof. unfold Equation4588. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff200_inst, reff200_op in H. discriminate H. Qed.

Lemma reff200_not4590 : ~ @Equation4590 Fin4 reff200_inst.
Proof. unfold Equation4590. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff200_inst, reff200_op in H. discriminate H. Qed.

Lemma reff200_not4591 : ~ @Equation4591 Fin4 reff200_inst.
Proof. unfold Equation4591. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff200_inst, reff200_op in H. discriminate H. Qed.

Lemma reff200_not4598 : ~ @Equation4598 Fin4 reff200_inst.
Proof. unfold Equation4598. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff200_inst, reff200_op in H. discriminate H. Qed.

Lemma reff200_not4599 : ~ @Equation4599 Fin4 reff200_inst.
Proof. unfold Equation4599. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff200_inst, reff200_op in H. discriminate H. Qed.

Lemma reff200_not4605 : ~ @Equation4605 Fin4 reff200_inst.
Proof. unfold Equation4605. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff200_inst, reff200_op in H. discriminate H. Qed.

Lemma reff200_not4606 : ~ @Equation4606 Fin4 reff200_inst.
Proof. unfold Equation4606. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff200_inst, reff200_op in H. discriminate H. Qed.

Lemma reff200_not4608 : ~ @Equation4608 Fin4 reff200_inst.
Proof. unfold Equation4608. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff200_inst, reff200_op in H. discriminate H. Qed.

Lemma reff200_not4629 : ~ @Equation4629 Fin4 reff200_inst.
Proof. unfold Equation4629. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff200_inst, reff200_op in H. discriminate H. Qed.

Lemma reff200_not4635 : ~ @Equation4635 Fin4 reff200_inst.
Proof. unfold Equation4635. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff200_inst, reff200_op in H. discriminate H. Qed.

Lemma reff200_not4636 : ~ @Equation4636 Fin4 reff200_inst.
Proof. unfold Equation4636. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff200_inst, reff200_op in H. discriminate H. Qed.

Lemma reff200_not4658 : ~ @Equation4658 Fin4 reff200_inst.
Proof. unfold Equation4658. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff200_inst, reff200_op in H. discriminate H. Qed.

(** ---- reff206 (Fin4) ---- *)

Definition reff206_op (x y : Fin4) : Fin4 :=
  match x, y with
  | F4_0, F4_0 => F4_0 | F4_0, F4_1 => F4_1 | F4_0, F4_2 => F4_2 | F4_0, F4_3 => F4_3
  | F4_1, F4_0 => F4_2 | F4_1, F4_1 => F4_3 | F4_1, F4_2 => F4_0 | F4_1, F4_3 => F4_1
  | F4_2, F4_0 => F4_0 | F4_2, F4_1 => F4_1 | F4_2, F4_2 => F4_2 | F4_2, F4_3 => F4_3
  | F4_3, F4_0 => F4_2 | F4_3, F4_1 => F4_3 | F4_3, F4_2 => F4_0 | F4_3, F4_3 => F4_1
  end.

#[local] Instance reff206_inst : Magma Fin4 := {| magma_op := reff206_op |}.

Lemma reff206_sat16 : @Equation16 Fin4 reff206_inst.
Proof. unfold Equation16, magma_op, reff206_inst, reff206_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff206_sat138 : @Equation138 Fin4 reff206_inst.
Proof. unfold Equation138, magma_op, reff206_inst, reff206_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff206_sat194 : @Equation194 Fin4 reff206_inst.
Proof. unfold Equation194, magma_op, reff206_inst, reff206_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff206_sat395 : @Equation395 Fin4 reff206_inst.
Proof. unfold Equation395, magma_op, reff206_inst, reff206_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff206_sat562 : @Equation562 Fin4 reff206_inst.
Proof. unfold Equation562, magma_op, reff206_inst, reff206_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff206_sat1202 : @Equation1202 Fin4 reff206_inst.
Proof. unfold Equation1202, magma_op, reff206_inst, reff206_op. intros x y z w. destruct x, y, z, w; reflexivity. Qed.

Lemma reff206_sat1816 : @Equation1816 Fin4 reff206_inst.
Proof. unfold Equation1816, magma_op, reff206_inst, reff206_op. intros x y z w. destruct x, y, z, w; reflexivity. Qed.

Lemma reff206_sat2024 : @Equation2024 Fin4 reff206_inst.
Proof. unfold Equation2024, magma_op, reff206_inst, reff206_op. intros x y z w. destruct x, y, z, w; reflexivity. Qed.

Lemma reff206_sat3388 : @Equation3388 Fin4 reff206_inst.
Proof. unfold Equation3388, magma_op, reff206_inst, reff206_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff206_sat4362 : @Equation4362 Fin4 reff206_inst.
Proof. unfold Equation4362, magma_op, reff206_inst, reff206_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff206_not47 : ~ @Equation47 Fin4 reff206_inst.
Proof. unfold Equation47. intro H. specialize (H F4_1). unfold magma_op, reff206_inst, reff206_op in H. discriminate H. Qed.

Lemma reff206_not102 : ~ @Equation102 Fin4 reff206_inst.
Proof. unfold Equation102. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff206_inst, reff206_op in H. discriminate H. Qed.

Lemma reff206_not105 : ~ @Equation105 Fin4 reff206_inst.
Proof. unfold Equation105. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff206_inst, reff206_op in H. discriminate H. Qed.

Lemma reff206_not107 : ~ @Equation107 Fin4 reff206_inst.
Proof. unfold Equation107. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff206_inst, reff206_op in H. discriminate H. Qed.

Lemma reff206_not108 : ~ @Equation108 Fin4 reff206_inst.
Proof. unfold Equation108. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff206_inst, reff206_op in H. discriminate H. Qed.

Lemma reff206_not115 : ~ @Equation115 Fin4 reff206_inst.
Proof. unfold Equation115. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff206_inst, reff206_op in H. discriminate H. Qed.

Lemma reff206_not118 : ~ @Equation118 Fin4 reff206_inst.
Proof. unfold Equation118. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff206_inst, reff206_op in H. discriminate H. Qed.

Lemma reff206_not124 : ~ @Equation124 Fin4 reff206_inst.
Proof. unfold Equation124. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff206_inst, reff206_op in H. discriminate H. Qed.

Lemma reff206_not125 : ~ @Equation125 Fin4 reff206_inst.
Proof. unfold Equation125. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff206_inst, reff206_op in H. discriminate H. Qed.

Lemma reff206_not154 : ~ @Equation154 Fin4 reff206_inst.
Proof. unfold Equation154. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff206_inst, reff206_op in H. discriminate H. Qed.

Lemma reff206_not157 : ~ @Equation157 Fin4 reff206_inst.
Proof. unfold Equation157. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff206_inst, reff206_op in H. discriminate H. Qed.

Lemma reff206_not160 : ~ @Equation160 Fin4 reff206_inst.
Proof. unfold Equation160. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff206_inst, reff206_op in H. discriminate H. Qed.

Lemma reff206_not167 : ~ @Equation167 Fin4 reff206_inst.
Proof. unfold Equation167. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff206_inst, reff206_op in H. discriminate H. Qed.

Lemma reff206_not169 : ~ @Equation169 Fin4 reff206_inst.
Proof. unfold Equation169. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff206_inst, reff206_op in H. discriminate H. Qed.

Lemma reff206_not170 : ~ @Equation170 Fin4 reff206_inst.
Proof. unfold Equation170. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff206_inst, reff206_op in H. discriminate H. Qed.

Lemma reff206_not176 : ~ @Equation176 Fin4 reff206_inst.
Proof. unfold Equation176. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff206_inst, reff206_op in H. discriminate H. Qed.

Lemma reff206_not177 : ~ @Equation177 Fin4 reff206_inst.
Proof. unfold Equation177. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff206_inst, reff206_op in H. discriminate H. Qed.

Lemma reff206_not203 : ~ @Equation203 Fin4 reff206_inst.
Proof. unfold Equation203. intro H. specialize (H F4_1). unfold magma_op, reff206_inst, reff206_op in H. discriminate H. Qed.

Lemma reff206_not255 : ~ @Equation255 Fin4 reff206_inst.
Proof. unfold Equation255. intro H. specialize (H F4_1). unfold magma_op, reff206_inst, reff206_op in H. discriminate H. Qed.

Lemma reff206_not307 : ~ @Equation307 Fin4 reff206_inst.
Proof. unfold Equation307. intro H. specialize (H F4_1). unfold magma_op, reff206_inst, reff206_op in H. discriminate H. Qed.

Lemma reff206_not412 : ~ @Equation412 Fin4 reff206_inst.
Proof. unfold Equation412. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff206_inst, reff206_op in H. discriminate H. Qed.

Lemma reff206_not413 : ~ @Equation413 Fin4 reff206_inst.
Proof. unfold Equation413. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff206_inst, reff206_op in H. discriminate H. Qed.

Lemma reff206_not414 : ~ @Equation414 Fin4 reff206_inst.
Proof. unfold Equation414. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff206_inst, reff206_op in H. discriminate H. Qed.

Lemma reff206_not416 : ~ @Equation416 Fin4 reff206_inst.
Proof. unfold Equation416. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff206_inst, reff206_op in H. discriminate H. Qed.

Lemma reff206_not417 : ~ @Equation417 Fin4 reff206_inst.
Proof. unfold Equation417. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff206_inst, reff206_op in H. discriminate H. Qed.

Lemma reff206_not420 : ~ @Equation420 Fin4 reff206_inst.
Proof. unfold Equation420. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff206_inst, reff206_op in H. discriminate H. Qed.

Lemma reff206_not426 : ~ @Equation426 Fin4 reff206_inst.
Proof. unfold Equation426. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff206_inst, reff206_op in H. discriminate H. Qed.

Lemma reff206_not427 : ~ @Equation427 Fin4 reff206_inst.
Proof. unfold Equation427. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff206_inst, reff206_op in H. discriminate H. Qed.

Lemma reff206_not430 : ~ @Equation430 Fin4 reff206_inst.
Proof. unfold Equation430. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff206_inst, reff206_op in H. discriminate H. Qed.

Lemma reff206_not437 : ~ @Equation437 Fin4 reff206_inst.
Proof. unfold Equation437. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff206_inst, reff206_op in H. discriminate H. Qed.

Lemma reff206_not439 : ~ @Equation439 Fin4 reff206_inst.
Proof. unfold Equation439. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff206_inst, reff206_op in H. discriminate H. Qed.

Lemma reff206_not440 : ~ @Equation440 Fin4 reff206_inst.
Proof. unfold Equation440. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff206_inst, reff206_op in H. discriminate H. Qed.

Lemma reff206_not463 : ~ @Equation463 Fin4 reff206_inst.
Proof. unfold Equation463. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff206_inst, reff206_op in H. discriminate H. Qed.

Lemma reff206_not464 : ~ @Equation464 Fin4 reff206_inst.
Proof. unfold Equation464. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff206_inst, reff206_op in H. discriminate H. Qed.

Lemma reff206_not467 : ~ @Equation467 Fin4 reff206_inst.
Proof. unfold Equation467. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff206_inst, reff206_op in H. discriminate H. Qed.

Lemma reff206_not474 : ~ @Equation474 Fin4 reff206_inst.
Proof. unfold Equation474. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff206_inst, reff206_op in H. discriminate H. Qed.

Lemma reff206_not476 : ~ @Equation476 Fin4 reff206_inst.
Proof. unfold Equation476. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff206_inst, reff206_op in H. discriminate H. Qed.

Lemma reff206_not477 : ~ @Equation477 Fin4 reff206_inst.
Proof. unfold Equation477. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff206_inst, reff206_op in H. discriminate H. Qed.

Lemma reff206_not501 : ~ @Equation501 Fin4 reff206_inst.
Proof. unfold Equation501. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff206_inst, reff206_op in H. discriminate H. Qed.

Lemma reff206_not503 : ~ @Equation503 Fin4 reff206_inst.
Proof. unfold Equation503. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff206_inst, reff206_op in H. discriminate H. Qed.

Lemma reff206_not504 : ~ @Equation504 Fin4 reff206_inst.
Proof. unfold Equation504. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff206_inst, reff206_op in H. discriminate H. Qed.

Lemma reff206_not510 : ~ @Equation510 Fin4 reff206_inst.
Proof. unfold Equation510. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff206_inst, reff206_op in H. discriminate H. Qed.

Lemma reff206_not511 : ~ @Equation511 Fin4 reff206_inst.
Proof. unfold Equation511. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff206_inst, reff206_op in H. discriminate H. Qed.

Lemma reff206_not614 : ~ @Equation614 Fin4 reff206_inst.
Proof. unfold Equation614. intro H. specialize (H F4_1). unfold magma_op, reff206_inst, reff206_op in H. discriminate H. Qed.

Lemma reff206_not817 : ~ @Equation817 Fin4 reff206_inst.
Proof. unfold Equation817. intro H. specialize (H F4_1). unfold magma_op, reff206_inst, reff206_op in H. discriminate H. Qed.

Lemma reff206_not1021 : ~ @Equation1021 Fin4 reff206_inst.
Proof. unfold Equation1021. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff206_inst, reff206_op in H. discriminate H. Qed.

Lemma reff206_not1022 : ~ @Equation1022 Fin4 reff206_inst.
Proof. unfold Equation1022. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff206_inst, reff206_op in H. discriminate H. Qed.

Lemma reff206_not1023 : ~ @Equation1023 Fin4 reff206_inst.
Proof. unfold Equation1023. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff206_inst, reff206_op in H. discriminate H. Qed.

Lemma reff206_not1026 : ~ @Equation1026 Fin4 reff206_inst.
Proof. unfold Equation1026. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff206_inst, reff206_op in H. discriminate H. Qed.

Lemma reff206_not1028 : ~ @Equation1028 Fin4 reff206_inst.
Proof. unfold Equation1028. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff206_inst, reff206_op in H. discriminate H. Qed.

Lemma reff206_not1029 : ~ @Equation1029 Fin4 reff206_inst.
Proof. unfold Equation1029. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff206_inst, reff206_op in H. discriminate H. Qed.

Lemma reff206_not1036 : ~ @Equation1036 Fin4 reff206_inst.
Proof. unfold Equation1036. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff206_inst, reff206_op in H. discriminate H. Qed.

Lemma reff206_not1038 : ~ @Equation1038 Fin4 reff206_inst.
Proof. unfold Equation1038. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff206_inst, reff206_op in H. discriminate H. Qed.

Lemma reff206_not1039 : ~ @Equation1039 Fin4 reff206_inst.
Proof. unfold Equation1039. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff206_inst, reff206_op in H. discriminate H. Qed.

Lemma reff206_not1046 : ~ @Equation1046 Fin4 reff206_inst.
Proof. unfold Equation1046. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff206_inst, reff206_op in H. discriminate H. Qed.

Lemma reff206_not1048 : ~ @Equation1048 Fin4 reff206_inst.
Proof. unfold Equation1048. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff206_inst, reff206_op in H. discriminate H. Qed.

Lemma reff206_not1049 : ~ @Equation1049 Fin4 reff206_inst.
Proof. unfold Equation1049. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff206_inst, reff206_op in H. discriminate H. Qed.

Lemma reff206_not1072 : ~ @Equation1072 Fin4 reff206_inst.
Proof. unfold Equation1072. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff206_inst, reff206_op in H. discriminate H. Qed.

Lemma reff206_not1073 : ~ @Equation1073 Fin4 reff206_inst.
Proof. unfold Equation1073. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff206_inst, reff206_op in H. discriminate H. Qed.

Lemma reff206_not1076 : ~ @Equation1076 Fin4 reff206_inst.
Proof. unfold Equation1076. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff206_inst, reff206_op in H. discriminate H. Qed.

Lemma reff206_not1082 : ~ @Equation1082 Fin4 reff206_inst.
Proof. unfold Equation1082. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff206_inst, reff206_op in H. discriminate H. Qed.

Lemma reff206_not1083 : ~ @Equation1083 Fin4 reff206_inst.
Proof. unfold Equation1083. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff206_inst, reff206_op in H. discriminate H. Qed.

Lemma reff206_not1086 : ~ @Equation1086 Fin4 reff206_inst.
Proof. unfold Equation1086. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff206_inst, reff206_op in H. discriminate H. Qed.

Lemma reff206_not1109 : ~ @Equation1109 Fin4 reff206_inst.
Proof. unfold Equation1109. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff206_inst, reff206_op in H. discriminate H. Qed.

Lemma reff206_not1110 : ~ @Equation1110 Fin4 reff206_inst.
Proof. unfold Equation1110. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff206_inst, reff206_op in H. discriminate H. Qed.

Lemma reff206_not1113 : ~ @Equation1113 Fin4 reff206_inst.
Proof. unfold Equation1113. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff206_inst, reff206_op in H. discriminate H. Qed.

Lemma reff206_not1119 : ~ @Equation1119 Fin4 reff206_inst.
Proof. unfold Equation1119. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff206_inst, reff206_op in H. discriminate H. Qed.

Lemma reff206_not1120 : ~ @Equation1120 Fin4 reff206_inst.
Proof. unfold Equation1120. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff206_inst, reff206_op in H. discriminate H. Qed.

Lemma reff206_not1224 : ~ @Equation1224 Fin4 reff206_inst.
Proof. unfold Equation1224. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff206_inst, reff206_op in H. discriminate H. Qed.

Lemma reff206_not1225 : ~ @Equation1225 Fin4 reff206_inst.
Proof. unfold Equation1225. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff206_inst, reff206_op in H. discriminate H. Qed.

Lemma reff206_not1226 : ~ @Equation1226 Fin4 reff206_inst.
Proof. unfold Equation1226. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff206_inst, reff206_op in H. discriminate H. Qed.

Lemma reff206_not1229 : ~ @Equation1229 Fin4 reff206_inst.
Proof. unfold Equation1229. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff206_inst, reff206_op in H. discriminate H. Qed.

Lemma reff206_not1231 : ~ @Equation1231 Fin4 reff206_inst.
Proof. unfold Equation1231. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff206_inst, reff206_op in H. discriminate H. Qed.

Lemma reff206_not1232 : ~ @Equation1232 Fin4 reff206_inst.
Proof. unfold Equation1232. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff206_inst, reff206_op in H. discriminate H. Qed.

Lemma reff206_not1239 : ~ @Equation1239 Fin4 reff206_inst.
Proof. unfold Equation1239. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff206_inst, reff206_op in H. discriminate H. Qed.

Lemma reff206_not1241 : ~ @Equation1241 Fin4 reff206_inst.
Proof. unfold Equation1241. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff206_inst, reff206_op in H. discriminate H. Qed.

Lemma reff206_not1242 : ~ @Equation1242 Fin4 reff206_inst.
Proof. unfold Equation1242. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff206_inst, reff206_op in H. discriminate H. Qed.

Lemma reff206_not1249 : ~ @Equation1249 Fin4 reff206_inst.
Proof. unfold Equation1249. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff206_inst, reff206_op in H. discriminate H. Qed.

Lemma reff206_not1251 : ~ @Equation1251 Fin4 reff206_inst.
Proof. unfold Equation1251. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff206_inst, reff206_op in H. discriminate H. Qed.

Lemma reff206_not1252 : ~ @Equation1252 Fin4 reff206_inst.
Proof. unfold Equation1252. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff206_inst, reff206_op in H. discriminate H. Qed.

Lemma reff206_not1275 : ~ @Equation1275 Fin4 reff206_inst.
Proof. unfold Equation1275. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff206_inst, reff206_op in H. discriminate H. Qed.

Lemma reff206_not1276 : ~ @Equation1276 Fin4 reff206_inst.
Proof. unfold Equation1276. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff206_inst, reff206_op in H. discriminate H. Qed.

Lemma reff206_not1279 : ~ @Equation1279 Fin4 reff206_inst.
Proof. unfold Equation1279. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff206_inst, reff206_op in H. discriminate H. Qed.

Lemma reff206_not1285 : ~ @Equation1285 Fin4 reff206_inst.
Proof. unfold Equation1285. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff206_inst, reff206_op in H. discriminate H. Qed.

Lemma reff206_not1286 : ~ @Equation1286 Fin4 reff206_inst.
Proof. unfold Equation1286. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff206_inst, reff206_op in H. discriminate H. Qed.

Lemma reff206_not1289 : ~ @Equation1289 Fin4 reff206_inst.
Proof. unfold Equation1289. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff206_inst, reff206_op in H. discriminate H. Qed.

Lemma reff206_not1312 : ~ @Equation1312 Fin4 reff206_inst.
Proof. unfold Equation1312. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff206_inst, reff206_op in H. discriminate H. Qed.

Lemma reff206_not1313 : ~ @Equation1313 Fin4 reff206_inst.
Proof. unfold Equation1313. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff206_inst, reff206_op in H. discriminate H. Qed.

Lemma reff206_not1316 : ~ @Equation1316 Fin4 reff206_inst.
Proof. unfold Equation1316. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff206_inst, reff206_op in H. discriminate H. Qed.

Lemma reff206_not1322 : ~ @Equation1322 Fin4 reff206_inst.
Proof. unfold Equation1322. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff206_inst, reff206_op in H. discriminate H. Qed.

Lemma reff206_not1323 : ~ @Equation1323 Fin4 reff206_inst.
Proof. unfold Equation1323. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff206_inst, reff206_op in H. discriminate H. Qed.

Lemma reff206_not1426 : ~ @Equation1426 Fin4 reff206_inst.
Proof. unfold Equation1426. intro H. specialize (H F4_1). unfold magma_op, reff206_inst, reff206_op in H. discriminate H. Qed.

Lemma reff206_not1630 : ~ @Equation1630 Fin4 reff206_inst.
Proof. unfold Equation1630. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff206_inst, reff206_op in H. discriminate H. Qed.

Lemma reff206_not1631 : ~ @Equation1631 Fin4 reff206_inst.
Proof. unfold Equation1631. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff206_inst, reff206_op in H. discriminate H. Qed.

Lemma reff206_not1632 : ~ @Equation1632 Fin4 reff206_inst.
Proof. unfold Equation1632. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff206_inst, reff206_op in H. discriminate H. Qed.

Lemma reff206_not1635 : ~ @Equation1635 Fin4 reff206_inst.
Proof. unfold Equation1635. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff206_inst, reff206_op in H. discriminate H. Qed.

Lemma reff206_not1637 : ~ @Equation1637 Fin4 reff206_inst.
Proof. unfold Equation1637. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff206_inst, reff206_op in H. discriminate H. Qed.

Lemma reff206_not1638 : ~ @Equation1638 Fin4 reff206_inst.
Proof. unfold Equation1638. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff206_inst, reff206_op in H. discriminate H. Qed.

Lemma reff206_not1644 : ~ @Equation1644 Fin4 reff206_inst.
Proof. unfold Equation1644. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff206_inst, reff206_op in H. discriminate H. Qed.

Lemma reff206_not1645 : ~ @Equation1645 Fin4 reff206_inst.
Proof. unfold Equation1645. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff206_inst, reff206_op in H. discriminate H. Qed.

Lemma reff206_not1648 : ~ @Equation1648 Fin4 reff206_inst.
Proof. unfold Equation1648. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff206_inst, reff206_op in H. discriminate H. Qed.

Lemma reff206_not1654 : ~ @Equation1654 Fin4 reff206_inst.
Proof. unfold Equation1654. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff206_inst, reff206_op in H. discriminate H. Qed.

Lemma reff206_not1655 : ~ @Equation1655 Fin4 reff206_inst.
Proof. unfold Equation1655. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff206_inst, reff206_op in H. discriminate H. Qed.

Lemma reff206_not1658 : ~ @Equation1658 Fin4 reff206_inst.
Proof. unfold Equation1658. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff206_inst, reff206_op in H. discriminate H. Qed.

Lemma reff206_not1682 : ~ @Equation1682 Fin4 reff206_inst.
Proof. unfold Equation1682. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff206_inst, reff206_op in H. discriminate H. Qed.

Lemma reff206_not1684 : ~ @Equation1684 Fin4 reff206_inst.
Proof. unfold Equation1684. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff206_inst, reff206_op in H. discriminate H. Qed.

Lemma reff206_not1685 : ~ @Equation1685 Fin4 reff206_inst.
Proof. unfold Equation1685. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff206_inst, reff206_op in H. discriminate H. Qed.

Lemma reff206_not1692 : ~ @Equation1692 Fin4 reff206_inst.
Proof. unfold Equation1692. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff206_inst, reff206_op in H. discriminate H. Qed.

Lemma reff206_not1694 : ~ @Equation1694 Fin4 reff206_inst.
Proof. unfold Equation1694. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff206_inst, reff206_op in H. discriminate H. Qed.

Lemma reff206_not1695 : ~ @Equation1695 Fin4 reff206_inst.
Proof. unfold Equation1695. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff206_inst, reff206_op in H. discriminate H. Qed.

Lemma reff206_not1718 : ~ @Equation1718 Fin4 reff206_inst.
Proof. unfold Equation1718. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff206_inst, reff206_op in H. discriminate H. Qed.

Lemma reff206_not1719 : ~ @Equation1719 Fin4 reff206_inst.
Proof. unfold Equation1719. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff206_inst, reff206_op in H. discriminate H. Qed.

Lemma reff206_not1722 : ~ @Equation1722 Fin4 reff206_inst.
Proof. unfold Equation1722. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff206_inst, reff206_op in H. discriminate H. Qed.

Lemma reff206_not1728 : ~ @Equation1728 Fin4 reff206_inst.
Proof. unfold Equation1728. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff206_inst, reff206_op in H. discriminate H. Qed.

Lemma reff206_not1729 : ~ @Equation1729 Fin4 reff206_inst.
Proof. unfold Equation1729. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff206_inst, reff206_op in H. discriminate H. Qed.

Lemma reff206_not1833 : ~ @Equation1833 Fin4 reff206_inst.
Proof. unfold Equation1833. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff206_inst, reff206_op in H. discriminate H. Qed.

Lemma reff206_not1834 : ~ @Equation1834 Fin4 reff206_inst.
Proof. unfold Equation1834. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff206_inst, reff206_op in H. discriminate H. Qed.

Lemma reff206_not1835 : ~ @Equation1835 Fin4 reff206_inst.
Proof. unfold Equation1835. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff206_inst, reff206_op in H. discriminate H. Qed.

Lemma reff206_not1837 : ~ @Equation1837 Fin4 reff206_inst.
Proof. unfold Equation1837. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff206_inst, reff206_op in H. discriminate H. Qed.

Lemma reff206_not1838 : ~ @Equation1838 Fin4 reff206_inst.
Proof. unfold Equation1838. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff206_inst, reff206_op in H. discriminate H. Qed.

Lemma reff206_not1841 : ~ @Equation1841 Fin4 reff206_inst.
Proof. unfold Equation1841. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff206_inst, reff206_op in H. discriminate H. Qed.

Lemma reff206_not1848 : ~ @Equation1848 Fin4 reff206_inst.
Proof. unfold Equation1848. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff206_inst, reff206_op in H. discriminate H. Qed.

Lemma reff206_not1850 : ~ @Equation1850 Fin4 reff206_inst.
Proof. unfold Equation1850. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff206_inst, reff206_op in H. discriminate H. Qed.

Lemma reff206_not1851 : ~ @Equation1851 Fin4 reff206_inst.
Proof. unfold Equation1851. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff206_inst, reff206_op in H. discriminate H. Qed.

Lemma reff206_not1857 : ~ @Equation1857 Fin4 reff206_inst.
Proof. unfold Equation1857. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff206_inst, reff206_op in H. discriminate H. Qed.

Lemma reff206_not1858 : ~ @Equation1858 Fin4 reff206_inst.
Proof. unfold Equation1858. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff206_inst, reff206_op in H. discriminate H. Qed.

Lemma reff206_not1861 : ~ @Equation1861 Fin4 reff206_inst.
Proof. unfold Equation1861. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff206_inst, reff206_op in H. discriminate H. Qed.

Lemma reff206_not1885 : ~ @Equation1885 Fin4 reff206_inst.
Proof. unfold Equation1885. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff206_inst, reff206_op in H. discriminate H. Qed.

Lemma reff206_not1887 : ~ @Equation1887 Fin4 reff206_inst.
Proof. unfold Equation1887. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff206_inst, reff206_op in H. discriminate H. Qed.

Lemma reff206_not1888 : ~ @Equation1888 Fin4 reff206_inst.
Proof. unfold Equation1888. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff206_inst, reff206_op in H. discriminate H. Qed.

Lemma reff206_not1894 : ~ @Equation1894 Fin4 reff206_inst.
Proof. unfold Equation1894. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff206_inst, reff206_op in H. discriminate H. Qed.

Lemma reff206_not1895 : ~ @Equation1895 Fin4 reff206_inst.
Proof. unfold Equation1895. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff206_inst, reff206_op in H. discriminate H. Qed.

Lemma reff206_not1898 : ~ @Equation1898 Fin4 reff206_inst.
Proof. unfold Equation1898. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff206_inst, reff206_op in H. discriminate H. Qed.

Lemma reff206_not1922 : ~ @Equation1922 Fin4 reff206_inst.
Proof. unfold Equation1922. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff206_inst, reff206_op in H. discriminate H. Qed.

Lemma reff206_not1924 : ~ @Equation1924 Fin4 reff206_inst.
Proof. unfold Equation1924. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff206_inst, reff206_op in H. discriminate H. Qed.

Lemma reff206_not1925 : ~ @Equation1925 Fin4 reff206_inst.
Proof. unfold Equation1925. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff206_inst, reff206_op in H. discriminate H. Qed.

Lemma reff206_not1931 : ~ @Equation1931 Fin4 reff206_inst.
Proof. unfold Equation1931. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff206_inst, reff206_op in H. discriminate H. Qed.

Lemma reff206_not1932 : ~ @Equation1932 Fin4 reff206_inst.
Proof. unfold Equation1932. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff206_inst, reff206_op in H. discriminate H. Qed.

Lemma reff206_not2036 : ~ @Equation2036 Fin4 reff206_inst.
Proof. unfold Equation2036. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff206_inst, reff206_op in H. discriminate H. Qed.

Lemma reff206_not2037 : ~ @Equation2037 Fin4 reff206_inst.
Proof. unfold Equation2037. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff206_inst, reff206_op in H. discriminate H. Qed.

Lemma reff206_not2038 : ~ @Equation2038 Fin4 reff206_inst.
Proof. unfold Equation2038. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff206_inst, reff206_op in H. discriminate H. Qed.

Lemma reff206_not2040 : ~ @Equation2040 Fin4 reff206_inst.
Proof. unfold Equation2040. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff206_inst, reff206_op in H. discriminate H. Qed.

Lemma reff206_not2041 : ~ @Equation2041 Fin4 reff206_inst.
Proof. unfold Equation2041. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff206_inst, reff206_op in H. discriminate H. Qed.

Lemma reff206_not2044 : ~ @Equation2044 Fin4 reff206_inst.
Proof. unfold Equation2044. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff206_inst, reff206_op in H. discriminate H. Qed.

Lemma reff206_not2051 : ~ @Equation2051 Fin4 reff206_inst.
Proof. unfold Equation2051. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff206_inst, reff206_op in H. discriminate H. Qed.

Lemma reff206_not2053 : ~ @Equation2053 Fin4 reff206_inst.
Proof. unfold Equation2053. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff206_inst, reff206_op in H. discriminate H. Qed.

Lemma reff206_not2054 : ~ @Equation2054 Fin4 reff206_inst.
Proof. unfold Equation2054. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff206_inst, reff206_op in H. discriminate H. Qed.

Lemma reff206_not2060 : ~ @Equation2060 Fin4 reff206_inst.
Proof. unfold Equation2060. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff206_inst, reff206_op in H. discriminate H. Qed.

Lemma reff206_not2061 : ~ @Equation2061 Fin4 reff206_inst.
Proof. unfold Equation2061. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff206_inst, reff206_op in H. discriminate H. Qed.

Lemma reff206_not2064 : ~ @Equation2064 Fin4 reff206_inst.
Proof. unfold Equation2064. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff206_inst, reff206_op in H. discriminate H. Qed.

Lemma reff206_not2088 : ~ @Equation2088 Fin4 reff206_inst.
Proof. unfold Equation2088. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff206_inst, reff206_op in H. discriminate H. Qed.

Lemma reff206_not2090 : ~ @Equation2090 Fin4 reff206_inst.
Proof. unfold Equation2090. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff206_inst, reff206_op in H. discriminate H. Qed.

Lemma reff206_not2091 : ~ @Equation2091 Fin4 reff206_inst.
Proof. unfold Equation2091. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff206_inst, reff206_op in H. discriminate H. Qed.

Lemma reff206_not2097 : ~ @Equation2097 Fin4 reff206_inst.
Proof. unfold Equation2097. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff206_inst, reff206_op in H. discriminate H. Qed.

Lemma reff206_not2098 : ~ @Equation2098 Fin4 reff206_inst.
Proof. unfold Equation2098. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff206_inst, reff206_op in H. discriminate H. Qed.

Lemma reff206_not2101 : ~ @Equation2101 Fin4 reff206_inst.
Proof. unfold Equation2101. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff206_inst, reff206_op in H. discriminate H. Qed.

Lemma reff206_not2125 : ~ @Equation2125 Fin4 reff206_inst.
Proof. unfold Equation2125. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff206_inst, reff206_op in H. discriminate H. Qed.

Lemma reff206_not2127 : ~ @Equation2127 Fin4 reff206_inst.
Proof. unfold Equation2127. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff206_inst, reff206_op in H. discriminate H. Qed.

Lemma reff206_not2128 : ~ @Equation2128 Fin4 reff206_inst.
Proof. unfold Equation2128. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff206_inst, reff206_op in H. discriminate H. Qed.

Lemma reff206_not2134 : ~ @Equation2134 Fin4 reff206_inst.
Proof. unfold Equation2134. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff206_inst, reff206_op in H. discriminate H. Qed.

Lemma reff206_not2135 : ~ @Equation2135 Fin4 reff206_inst.
Proof. unfold Equation2135. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff206_inst, reff206_op in H. discriminate H. Qed.

Lemma reff206_not2238 : ~ @Equation2238 Fin4 reff206_inst.
Proof. unfold Equation2238. intro H. specialize (H F4_1). unfold magma_op, reff206_inst, reff206_op in H. discriminate H. Qed.

Lemma reff206_not2441 : ~ @Equation2441 Fin4 reff206_inst.
Proof. unfold Equation2441. intro H. specialize (H F4_1). unfold magma_op, reff206_inst, reff206_op in H. discriminate H. Qed.

Lemma reff206_not2644 : ~ @Equation2644 Fin4 reff206_inst.
Proof. unfold Equation2644. intro H. specialize (H F4_1). unfold magma_op, reff206_inst, reff206_op in H. discriminate H. Qed.

Lemma reff206_not2847 : ~ @Equation2847 Fin4 reff206_inst.
Proof. unfold Equation2847. intro H. specialize (H F4_1). unfold magma_op, reff206_inst, reff206_op in H. discriminate H. Qed.

Lemma reff206_not3050 : ~ @Equation3050 Fin4 reff206_inst.
Proof. unfold Equation3050. intro H. specialize (H F4_1). unfold magma_op, reff206_inst, reff206_op in H. discriminate H. Qed.

Lemma reff206_not3254 : ~ @Equation3254 Fin4 reff206_inst.
Proof. unfold Equation3254. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff206_inst, reff206_op in H. discriminate H. Qed.

Lemma reff206_not3255 : ~ @Equation3255 Fin4 reff206_inst.
Proof. unfold Equation3255. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff206_inst, reff206_op in H. discriminate H. Qed.

Lemma reff206_not3256 : ~ @Equation3256 Fin4 reff206_inst.
Proof. unfold Equation3256. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff206_inst, reff206_op in H. discriminate H. Qed.

Lemma reff206_not3258 : ~ @Equation3258 Fin4 reff206_inst.
Proof. unfold Equation3258. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff206_inst, reff206_op in H. discriminate H. Qed.

Lemma reff206_not3259 : ~ @Equation3259 Fin4 reff206_inst.
Proof. unfold Equation3259. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff206_inst, reff206_op in H. discriminate H. Qed.

Lemma reff206_not3262 : ~ @Equation3262 Fin4 reff206_inst.
Proof. unfold Equation3262. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff206_inst, reff206_op in H. discriminate H. Qed.

Lemma reff206_not3268 : ~ @Equation3268 Fin4 reff206_inst.
Proof. unfold Equation3268. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff206_inst, reff206_op in H. discriminate H. Qed.

Lemma reff206_not3272 : ~ @Equation3272 Fin4 reff206_inst.
Proof. unfold Equation3272. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff206_inst, reff206_op in H. discriminate H. Qed.

Lemma reff206_not3279 : ~ @Equation3279 Fin4 reff206_inst.
Proof. unfold Equation3279. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff206_inst, reff206_op in H. discriminate H. Qed.

Lemma reff206_not3281 : ~ @Equation3281 Fin4 reff206_inst.
Proof. unfold Equation3281. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff206_inst, reff206_op in H. discriminate H. Qed.

Lemma reff206_not3308 : ~ @Equation3308 Fin4 reff206_inst.
Proof. unfold Equation3308. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff206_inst, reff206_op in H. discriminate H. Qed.

Lemma reff206_not3309 : ~ @Equation3309 Fin4 reff206_inst.
Proof. unfold Equation3309. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff206_inst, reff206_op in H. discriminate H. Qed.

Lemma reff206_not3315 : ~ @Equation3315 Fin4 reff206_inst.
Proof. unfold Equation3315. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff206_inst, reff206_op in H. discriminate H. Qed.

Lemma reff206_not3316 : ~ @Equation3316 Fin4 reff206_inst.
Proof. unfold Equation3316. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff206_inst, reff206_op in H. discriminate H. Qed.

Lemma reff206_not3318 : ~ @Equation3318 Fin4 reff206_inst.
Proof. unfold Equation3318. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff206_inst, reff206_op in H. discriminate H. Qed.

Lemma reff206_not3342 : ~ @Equation3342 Fin4 reff206_inst.
Proof. unfold Equation3342. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff206_inst, reff206_op in H. discriminate H. Qed.

Lemma reff206_not3343 : ~ @Equation3343 Fin4 reff206_inst.
Proof. unfold Equation3343. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff206_inst, reff206_op in H. discriminate H. Qed.

Lemma reff206_not3345 : ~ @Equation3345 Fin4 reff206_inst.
Proof. unfold Equation3345. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff206_inst, reff206_op in H. discriminate H. Qed.

Lemma reff206_not3352 : ~ @Equation3352 Fin4 reff206_inst.
Proof. unfold Equation3352. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff206_inst, reff206_op in H. discriminate H. Qed.

Lemma reff206_not3456 : ~ @Equation3456 Fin4 reff206_inst.
Proof. unfold Equation3456. intro H. specialize (H F4_1). unfold magma_op, reff206_inst, reff206_op in H. discriminate H. Qed.

Lemma reff206_not3659 : ~ @Equation3659 Fin4 reff206_inst.
Proof. unfold Equation3659. intro H. specialize (H F4_1). unfold magma_op, reff206_inst, reff206_op in H. discriminate H. Qed.

Lemma reff206_not3864 : ~ @Equation3864 Fin4 reff206_inst.
Proof. unfold Equation3864. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff206_inst, reff206_op in H. discriminate H. Qed.

Lemma reff206_not3865 : ~ @Equation3865 Fin4 reff206_inst.
Proof. unfold Equation3865. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff206_inst, reff206_op in H. discriminate H. Qed.

Lemma reff206_not3868 : ~ @Equation3868 Fin4 reff206_inst.
Proof. unfold Equation3868. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff206_inst, reff206_op in H. discriminate H. Qed.

Lemma reff206_not3870 : ~ @Equation3870 Fin4 reff206_inst.
Proof. unfold Equation3870. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff206_inst, reff206_op in H. discriminate H. Qed.

Lemma reff206_not3871 : ~ @Equation3871 Fin4 reff206_inst.
Proof. unfold Equation3871. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff206_inst, reff206_op in H. discriminate H. Qed.

Lemma reff206_not3878 : ~ @Equation3878 Fin4 reff206_inst.
Proof. unfold Equation3878. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff206_inst, reff206_op in H. discriminate H. Qed.

Lemma reff206_not3880 : ~ @Equation3880 Fin4 reff206_inst.
Proof. unfold Equation3880. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff206_inst, reff206_op in H. discriminate H. Qed.

Lemma reff206_not3881 : ~ @Equation3881 Fin4 reff206_inst.
Proof. unfold Equation3881. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff206_inst, reff206_op in H. discriminate H. Qed.

Lemma reff206_not3888 : ~ @Equation3888 Fin4 reff206_inst.
Proof. unfold Equation3888. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff206_inst, reff206_op in H. discriminate H. Qed.

Lemma reff206_not3890 : ~ @Equation3890 Fin4 reff206_inst.
Proof. unfold Equation3890. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff206_inst, reff206_op in H. discriminate H. Qed.

Lemma reff206_not3917 : ~ @Equation3917 Fin4 reff206_inst.
Proof. unfold Equation3917. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff206_inst, reff206_op in H. discriminate H. Qed.

Lemma reff206_not3918 : ~ @Equation3918 Fin4 reff206_inst.
Proof. unfold Equation3918. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff206_inst, reff206_op in H. discriminate H. Qed.

Lemma reff206_not3924 : ~ @Equation3924 Fin4 reff206_inst.
Proof. unfold Equation3924. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff206_inst, reff206_op in H. discriminate H. Qed.

Lemma reff206_not3927 : ~ @Equation3927 Fin4 reff206_inst.
Proof. unfold Equation3927. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff206_inst, reff206_op in H. discriminate H. Qed.

Lemma reff206_not3928 : ~ @Equation3928 Fin4 reff206_inst.
Proof. unfold Equation3928. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff206_inst, reff206_op in H. discriminate H. Qed.

Lemma reff206_not3951 : ~ @Equation3951 Fin4 reff206_inst.
Proof. unfold Equation3951. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff206_inst, reff206_op in H. discriminate H. Qed.

Lemma reff206_not3954 : ~ @Equation3954 Fin4 reff206_inst.
Proof. unfold Equation3954. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff206_inst, reff206_op in H. discriminate H. Qed.

Lemma reff206_not3955 : ~ @Equation3955 Fin4 reff206_inst.
Proof. unfold Equation3955. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff206_inst, reff206_op in H. discriminate H. Qed.

Lemma reff206_not3961 : ~ @Equation3961 Fin4 reff206_inst.
Proof. unfold Equation3961. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff206_inst, reff206_op in H. discriminate H. Qed.

Lemma reff206_not3964 : ~ @Equation3964 Fin4 reff206_inst.
Proof. unfold Equation3964. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff206_inst, reff206_op in H. discriminate H. Qed.

Lemma reff206_not4066 : ~ @Equation4066 Fin4 reff206_inst.
Proof. unfold Equation4066. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff206_inst, reff206_op in H. discriminate H. Qed.

Lemma reff206_not4067 : ~ @Equation4067 Fin4 reff206_inst.
Proof. unfold Equation4067. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff206_inst, reff206_op in H. discriminate H. Qed.

Lemma reff206_not4068 : ~ @Equation4068 Fin4 reff206_inst.
Proof. unfold Equation4068. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff206_inst, reff206_op in H. discriminate H. Qed.

Lemma reff206_not4071 : ~ @Equation4071 Fin4 reff206_inst.
Proof. unfold Equation4071. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff206_inst, reff206_op in H. discriminate H. Qed.

Lemma reff206_not4073 : ~ @Equation4073 Fin4 reff206_inst.
Proof. unfold Equation4073. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff206_inst, reff206_op in H. discriminate H. Qed.

Lemma reff206_not4074 : ~ @Equation4074 Fin4 reff206_inst.
Proof. unfold Equation4074. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff206_inst, reff206_op in H. discriminate H. Qed.

Lemma reff206_not4083 : ~ @Equation4083 Fin4 reff206_inst.
Proof. unfold Equation4083. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff206_inst, reff206_op in H. discriminate H. Qed.

Lemma reff206_not4084 : ~ @Equation4084 Fin4 reff206_inst.
Proof. unfold Equation4084. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff206_inst, reff206_op in H. discriminate H. Qed.

Lemma reff206_not4091 : ~ @Equation4091 Fin4 reff206_inst.
Proof. unfold Equation4091. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff206_inst, reff206_op in H. discriminate H. Qed.

Lemma reff206_not4093 : ~ @Equation4093 Fin4 reff206_inst.
Proof. unfold Equation4093. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff206_inst, reff206_op in H. discriminate H. Qed.

Lemma reff206_not4120 : ~ @Equation4120 Fin4 reff206_inst.
Proof. unfold Equation4120. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff206_inst, reff206_op in H. discriminate H. Qed.

Lemma reff206_not4121 : ~ @Equation4121 Fin4 reff206_inst.
Proof. unfold Equation4121. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff206_inst, reff206_op in H. discriminate H. Qed.

Lemma reff206_not4127 : ~ @Equation4127 Fin4 reff206_inst.
Proof. unfold Equation4127. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff206_inst, reff206_op in H. discriminate H. Qed.

Lemma reff206_not4130 : ~ @Equation4130 Fin4 reff206_inst.
Proof. unfold Equation4130. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff206_inst, reff206_op in H. discriminate H. Qed.

Lemma reff206_not4131 : ~ @Equation4131 Fin4 reff206_inst.
Proof. unfold Equation4131. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff206_inst, reff206_op in H. discriminate H. Qed.

Lemma reff206_not4157 : ~ @Equation4157 Fin4 reff206_inst.
Proof. unfold Equation4157. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff206_inst, reff206_op in H. discriminate H. Qed.

Lemma reff206_not4158 : ~ @Equation4158 Fin4 reff206_inst.
Proof. unfold Equation4158. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff206_inst, reff206_op in H. discriminate H. Qed.

Lemma reff206_not4164 : ~ @Equation4164 Fin4 reff206_inst.
Proof. unfold Equation4164. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff206_inst, reff206_op in H. discriminate H. Qed.

Lemma reff206_not4167 : ~ @Equation4167 Fin4 reff206_inst.
Proof. unfold Equation4167. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff206_inst, reff206_op in H. discriminate H. Qed.

Lemma reff206_not4268 : ~ @Equation4268 Fin4 reff206_inst.
Proof. unfold Equation4268. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff206_inst, reff206_op in H. discriminate H. Qed.

Lemma reff206_not4269 : ~ @Equation4269 Fin4 reff206_inst.
Proof. unfold Equation4269. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff206_inst, reff206_op in H. discriminate H. Qed.

Lemma reff206_not4270 : ~ @Equation4270 Fin4 reff206_inst.
Proof. unfold Equation4270. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff206_inst, reff206_op in H. discriminate H. Qed.

Lemma reff206_not4272 : ~ @Equation4272 Fin4 reff206_inst.
Proof. unfold Equation4272. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff206_inst, reff206_op in H. discriminate H. Qed.

Lemma reff206_not4273 : ~ @Equation4273 Fin4 reff206_inst.
Proof. unfold Equation4273. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff206_inst, reff206_op in H. discriminate H. Qed.

Lemma reff206_not4276 : ~ @Equation4276 Fin4 reff206_inst.
Proof. unfold Equation4276. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff206_inst, reff206_op in H. discriminate H. Qed.

Lemma reff206_not4283 : ~ @Equation4283 Fin4 reff206_inst.
Proof. unfold Equation4283. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff206_inst, reff206_op in H. discriminate H. Qed.

Lemma reff206_not4284 : ~ @Equation4284 Fin4 reff206_inst.
Proof. unfold Equation4284. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff206_inst, reff206_op in H. discriminate H. Qed.

Lemma reff206_not4290 : ~ @Equation4290 Fin4 reff206_inst.
Proof. unfold Equation4290. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff206_inst, reff206_op in H. discriminate H. Qed.

Lemma reff206_not4291 : ~ @Equation4291 Fin4 reff206_inst.
Proof. unfold Equation4291. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff206_inst, reff206_op in H. discriminate H. Qed.

Lemma reff206_not4293 : ~ @Equation4293 Fin4 reff206_inst.
Proof. unfold Equation4293. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff206_inst, reff206_op in H. discriminate H. Qed.

Lemma reff206_not4314 : ~ @Equation4314 Fin4 reff206_inst.
Proof. unfold Equation4314. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff206_inst, reff206_op in H. discriminate H. Qed.

Lemma reff206_not4321 : ~ @Equation4321 Fin4 reff206_inst.
Proof. unfold Equation4321. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff206_inst, reff206_op in H. discriminate H. Qed.

Lemma reff206_not4343 : ~ @Equation4343 Fin4 reff206_inst.
Proof. unfold Equation4343. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff206_inst, reff206_op in H. discriminate H. Qed.

Lemma reff206_not4380 : ~ @Equation4380 Fin4 reff206_inst.
Proof. unfold Equation4380. intro H. specialize (H F4_1). unfold magma_op, reff206_inst, reff206_op in H. discriminate H. Qed.

Lemma reff206_not4583 : ~ @Equation4583 Fin4 reff206_inst.
Proof. unfold Equation4583. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff206_inst, reff206_op in H. discriminate H. Qed.

Lemma reff206_not4584 : ~ @Equation4584 Fin4 reff206_inst.
Proof. unfold Equation4584. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff206_inst, reff206_op in H. discriminate H. Qed.

Lemma reff206_not4585 : ~ @Equation4585 Fin4 reff206_inst.
Proof. unfold Equation4585. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff206_inst, reff206_op in H. discriminate H. Qed.

Lemma reff206_not4588 : ~ @Equation4588 Fin4 reff206_inst.
Proof. unfold Equation4588. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff206_inst, reff206_op in H. discriminate H. Qed.

Lemma reff206_not4590 : ~ @Equation4590 Fin4 reff206_inst.
Proof. unfold Equation4590. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff206_inst, reff206_op in H. discriminate H. Qed.

Lemma reff206_not4591 : ~ @Equation4591 Fin4 reff206_inst.
Proof. unfold Equation4591. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff206_inst, reff206_op in H. discriminate H. Qed.

Lemma reff206_not4598 : ~ @Equation4598 Fin4 reff206_inst.
Proof. unfold Equation4598. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff206_inst, reff206_op in H. discriminate H. Qed.

Lemma reff206_not4599 : ~ @Equation4599 Fin4 reff206_inst.
Proof. unfold Equation4599. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff206_inst, reff206_op in H. discriminate H. Qed.

Lemma reff206_not4605 : ~ @Equation4605 Fin4 reff206_inst.
Proof. unfold Equation4605. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff206_inst, reff206_op in H. discriminate H. Qed.

Lemma reff206_not4608 : ~ @Equation4608 Fin4 reff206_inst.
Proof. unfold Equation4608. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff206_inst, reff206_op in H. discriminate H. Qed.

Lemma reff206_not4629 : ~ @Equation4629 Fin4 reff206_inst.
Proof. unfold Equation4629. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff206_inst, reff206_op in H. discriminate H. Qed.

Lemma reff206_not4635 : ~ @Equation4635 Fin4 reff206_inst.
Proof. unfold Equation4635. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff206_inst, reff206_op in H. discriminate H. Qed.

Lemma reff206_not4636 : ~ @Equation4636 Fin4 reff206_inst.
Proof. unfold Equation4636. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff206_inst, reff206_op in H. discriminate H. Qed.

Lemma reff206_not4658 : ~ @Equation4658 Fin4 reff206_inst.
Proof. unfold Equation4658. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff206_inst, reff206_op in H. discriminate H. Qed.

(** ---- reff208 (Fin3) ---- *)

Definition reff208_op (x y : Fin3) : Fin3 :=
  match x, y with
  | F3_0, F3_0 => F3_0 | F3_0, F3_1 => F3_1 | F3_0, F3_2 => F3_2
  | F3_1, F3_0 => F3_0 | F3_1, F3_1 => F3_1 | F3_1, F3_2 => F3_2
  | F3_2, F3_0 => F3_2 | F3_2, F3_1 => F3_0 | F3_2, F3_2 => F3_1
  end.

#[local] Instance reff208_inst : Magma Fin3 := {| magma_op := reff208_op |}.

Lemma reff208_sat31 : @Equation31 Fin3 reff208_inst.
Proof. unfold Equation31, magma_op, reff208_inst, reff208_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff208_sat75 : @Equation75 Fin3 reff208_inst.
Proof. unfold Equation75, magma_op, reff208_inst, reff208_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff208_sat231 : @Equation231 Fin3 reff208_inst.
Proof. unfold Equation231, magma_op, reff208_inst, reff208_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff208_sat2558 : @Equation2558 Fin3 reff208_inst.
Proof. unfold Equation2558, magma_op, reff208_inst, reff208_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff208_not50 : ~ @Equation50 Fin3 reff208_inst.
Proof. unfold Equation50. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff208_inst, reff208_op in H. discriminate H. Qed.

Lemma reff208_not53 : ~ @Equation53 Fin3 reff208_inst.
Proof. unfold Equation53. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff208_inst, reff208_op in H. discriminate H. Qed.

Lemma reff208_not55 : ~ @Equation55 Fin3 reff208_inst.
Proof. unfold Equation55. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff208_inst, reff208_op in H. discriminate H. Qed.

Lemma reff208_not56 : ~ @Equation56 Fin3 reff208_inst.
Proof. unfold Equation56. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff208_inst, reff208_op in H. discriminate H. Qed.

Lemma reff208_not63 : ~ @Equation63 Fin3 reff208_inst.
Proof. unfold Equation63. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff208_inst, reff208_op in H. discriminate H. Qed.

Lemma reff208_not65 : ~ @Equation65 Fin3 reff208_inst.
Proof. unfold Equation65. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff208_inst, reff208_op in H. discriminate H. Qed.

Lemma reff208_not66 : ~ @Equation66 Fin3 reff208_inst.
Proof. unfold Equation66. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff208_inst, reff208_op in H. discriminate H. Qed.

Lemma reff208_not72 : ~ @Equation72 Fin3 reff208_inst.
Proof. unfold Equation72. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff208_inst, reff208_op in H. discriminate H. Qed.

Lemma reff208_not73 : ~ @Equation73 Fin3 reff208_inst.
Proof. unfold Equation73. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff208_inst, reff208_op in H. discriminate H. Qed.

Lemma reff208_not99 : ~ @Equation99 Fin3 reff208_inst.
Proof. unfold Equation99. intro H. specialize (H F3_2). unfold magma_op, reff208_inst, reff208_op in H. discriminate H. Qed.

Lemma reff208_not151 : ~ @Equation151 Fin3 reff208_inst.
Proof. unfold Equation151. intro H. specialize (H F3_2). unfold magma_op, reff208_inst, reff208_op in H. discriminate H. Qed.

Lemma reff208_not206 : ~ @Equation206 Fin3 reff208_inst.
Proof. unfold Equation206. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff208_inst, reff208_op in H. discriminate H. Qed.

Lemma reff208_not209 : ~ @Equation209 Fin3 reff208_inst.
Proof. unfold Equation209. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff208_inst, reff208_op in H. discriminate H. Qed.

Lemma reff208_not211 : ~ @Equation211 Fin3 reff208_inst.
Proof. unfold Equation211. intro H. specialize (H F3_2 F3_0). unfold magma_op, reff208_inst, reff208_op in H. discriminate H. Qed.

Lemma reff208_not212 : ~ @Equation212 Fin3 reff208_inst.
Proof. unfold Equation212. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff208_inst, reff208_op in H. discriminate H. Qed.

Lemma reff208_not219 : ~ @Equation219 Fin3 reff208_inst.
Proof. unfold Equation219. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff208_inst, reff208_op in H. discriminate H. Qed.

Lemma reff208_not221 : ~ @Equation221 Fin3 reff208_inst.
Proof. unfold Equation221. intro H. specialize (H F3_2 F3_0). unfold magma_op, reff208_inst, reff208_op in H. discriminate H. Qed.

Lemma reff208_not222 : ~ @Equation222 Fin3 reff208_inst.
Proof. unfold Equation222. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff208_inst, reff208_op in H. discriminate H. Qed.

Lemma reff208_not228 : ~ @Equation228 Fin3 reff208_inst.
Proof. unfold Equation228. intro H. specialize (H F3_1 F3_2). unfold magma_op, reff208_inst, reff208_op in H. discriminate H. Qed.

Lemma reff208_not229 : ~ @Equation229 Fin3 reff208_inst.
Proof. unfold Equation229. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff208_inst, reff208_op in H. discriminate H. Qed.

Lemma reff208_not255 : ~ @Equation255 Fin3 reff208_inst.
Proof. unfold Equation255. intro H. specialize (H F3_2). unfold magma_op, reff208_inst, reff208_op in H. discriminate H. Qed.

Lemma reff208_not359 : ~ @Equation359 Fin3 reff208_inst.
Proof. unfold Equation359. intro H. specialize (H F3_2). unfold magma_op, reff208_inst, reff208_op in H. discriminate H. Qed.

Lemma reff208_not411 : ~ @Equation411 Fin3 reff208_inst.
Proof. unfold Equation411. intro H. specialize (H F3_2). unfold magma_op, reff208_inst, reff208_op in H. discriminate H. Qed.

Lemma reff208_not614 : ~ @Equation614 Fin3 reff208_inst.
Proof. unfold Equation614. intro H. specialize (H F3_2). unfold magma_op, reff208_inst, reff208_op in H. discriminate H. Qed.

Lemma reff208_not817 : ~ @Equation817 Fin3 reff208_inst.
Proof. unfold Equation817. intro H. specialize (H F3_2). unfold magma_op, reff208_inst, reff208_op in H. discriminate H. Qed.

Lemma reff208_not1020 : ~ @Equation1020 Fin3 reff208_inst.
Proof. unfold Equation1020. intro H. specialize (H F3_2). unfold magma_op, reff208_inst, reff208_op in H. discriminate H. Qed.

Lemma reff208_not1223 : ~ @Equation1223 Fin3 reff208_inst.
Proof. unfold Equation1223. intro H. specialize (H F3_2). unfold magma_op, reff208_inst, reff208_op in H. discriminate H. Qed.

Lemma reff208_not1426 : ~ @Equation1426 Fin3 reff208_inst.
Proof. unfold Equation1426. intro H. specialize (H F3_2). unfold magma_op, reff208_inst, reff208_op in H. discriminate H. Qed.

Lemma reff208_not1630 : ~ @Equation1630 Fin3 reff208_inst.
Proof. unfold Equation1630. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff208_inst, reff208_op in H. discriminate H. Qed.

Lemma reff208_not1631 : ~ @Equation1631 Fin3 reff208_inst.
Proof. unfold Equation1631. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff208_inst, reff208_op in H. discriminate H. Qed.

Lemma reff208_not1632 : ~ @Equation1632 Fin3 reff208_inst.
Proof. unfold Equation1632. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff208_inst, reff208_op in H. discriminate H. Qed.

Lemma reff208_not1634 : ~ @Equation1634 Fin3 reff208_inst.
Proof. unfold Equation1634. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff208_inst, reff208_op in H. discriminate H. Qed.

Lemma reff208_not1635 : ~ @Equation1635 Fin3 reff208_inst.
Proof. unfold Equation1635. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff208_inst, reff208_op in H. discriminate H. Qed.

Lemma reff208_not1638 : ~ @Equation1638 Fin3 reff208_inst.
Proof. unfold Equation1638. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff208_inst, reff208_op in H. discriminate H. Qed.

Lemma reff208_not1644 : ~ @Equation1644 Fin3 reff208_inst.
Proof. unfold Equation1644. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff208_inst, reff208_op in H. discriminate H. Qed.

Lemma reff208_not1645 : ~ @Equation1645 Fin3 reff208_inst.
Proof. unfold Equation1645. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff208_inst, reff208_op in H. discriminate H. Qed.

Lemma reff208_not1647 : ~ @Equation1647 Fin3 reff208_inst.
Proof. unfold Equation1647. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff208_inst, reff208_op in H. discriminate H. Qed.

Lemma reff208_not1648 : ~ @Equation1648 Fin3 reff208_inst.
Proof. unfold Equation1648. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff208_inst, reff208_op in H. discriminate H. Qed.

Lemma reff208_not1654 : ~ @Equation1654 Fin3 reff208_inst.
Proof. unfold Equation1654. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff208_inst, reff208_op in H. discriminate H. Qed.

Lemma reff208_not1655 : ~ @Equation1655 Fin3 reff208_inst.
Proof. unfold Equation1655. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff208_inst, reff208_op in H. discriminate H. Qed.

Lemma reff208_not1657 : ~ @Equation1657 Fin3 reff208_inst.
Proof. unfold Equation1657. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff208_inst, reff208_op in H. discriminate H. Qed.

Lemma reff208_not1658 : ~ @Equation1658 Fin3 reff208_inst.
Proof. unfold Equation1658. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff208_inst, reff208_op in H. discriminate H. Qed.

Lemma reff208_not1681 : ~ @Equation1681 Fin3 reff208_inst.
Proof. unfold Equation1681. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff208_inst, reff208_op in H. discriminate H. Qed.

Lemma reff208_not1682 : ~ @Equation1682 Fin3 reff208_inst.
Proof. unfold Equation1682. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff208_inst, reff208_op in H. discriminate H. Qed.

Lemma reff208_not1684 : ~ @Equation1684 Fin3 reff208_inst.
Proof. unfold Equation1684. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff208_inst, reff208_op in H. discriminate H. Qed.

Lemma reff208_not1685 : ~ @Equation1685 Fin3 reff208_inst.
Proof. unfold Equation1685. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff208_inst, reff208_op in H. discriminate H. Qed.

Lemma reff208_not1691 : ~ @Equation1691 Fin3 reff208_inst.
Proof. unfold Equation1691. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff208_inst, reff208_op in H. discriminate H. Qed.

Lemma reff208_not1692 : ~ @Equation1692 Fin3 reff208_inst.
Proof. unfold Equation1692. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff208_inst, reff208_op in H. discriminate H. Qed.

Lemma reff208_not1694 : ~ @Equation1694 Fin3 reff208_inst.
Proof. unfold Equation1694. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff208_inst, reff208_op in H. discriminate H. Qed.

Lemma reff208_not1695 : ~ @Equation1695 Fin3 reff208_inst.
Proof. unfold Equation1695. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff208_inst, reff208_op in H. discriminate H. Qed.

Lemma reff208_not1719 : ~ @Equation1719 Fin3 reff208_inst.
Proof. unfold Equation1719. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff208_inst, reff208_op in H. discriminate H. Qed.

Lemma reff208_not1721 : ~ @Equation1721 Fin3 reff208_inst.
Proof. unfold Equation1721. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff208_inst, reff208_op in H. discriminate H. Qed.

Lemma reff208_not1722 : ~ @Equation1722 Fin3 reff208_inst.
Proof. unfold Equation1722. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff208_inst, reff208_op in H. discriminate H. Qed.

Lemma reff208_not1728 : ~ @Equation1728 Fin3 reff208_inst.
Proof. unfold Equation1728. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff208_inst, reff208_op in H. discriminate H. Qed.

Lemma reff208_not1729 : ~ @Equation1729 Fin3 reff208_inst.
Proof. unfold Equation1729. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff208_inst, reff208_op in H. discriminate H. Qed.

Lemma reff208_not1832 : ~ @Equation1832 Fin3 reff208_inst.
Proof. unfold Equation1832. intro H. specialize (H F3_2). unfold magma_op, reff208_inst, reff208_op in H. discriminate H. Qed.

Lemma reff208_not2035 : ~ @Equation2035 Fin3 reff208_inst.
Proof. unfold Equation2035. intro H. specialize (H F3_2). unfold magma_op, reff208_inst, reff208_op in H. discriminate H. Qed.

Lemma reff208_not2238 : ~ @Equation2238 Fin3 reff208_inst.
Proof. unfold Equation2238. intro H. specialize (H F3_2). unfold magma_op, reff208_inst, reff208_op in H. discriminate H. Qed.

Lemma reff208_not2442 : ~ @Equation2442 Fin3 reff208_inst.
Proof. unfold Equation2442. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff208_inst, reff208_op in H. discriminate H. Qed.

Lemma reff208_not2443 : ~ @Equation2443 Fin3 reff208_inst.
Proof. unfold Equation2443. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff208_inst, reff208_op in H. discriminate H. Qed.

Lemma reff208_not2444 : ~ @Equation2444 Fin3 reff208_inst.
Proof. unfold Equation2444. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff208_inst, reff208_op in H. discriminate H. Qed.

Lemma reff208_not2446 : ~ @Equation2446 Fin3 reff208_inst.
Proof. unfold Equation2446. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff208_inst, reff208_op in H. discriminate H. Qed.

Lemma reff208_not2447 : ~ @Equation2447 Fin3 reff208_inst.
Proof. unfold Equation2447. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff208_inst, reff208_op in H. discriminate H. Qed.

Lemma reff208_not2450 : ~ @Equation2450 Fin3 reff208_inst.
Proof. unfold Equation2450. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff208_inst, reff208_op in H. discriminate H. Qed.

Lemma reff208_not2456 : ~ @Equation2456 Fin3 reff208_inst.
Proof. unfold Equation2456. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff208_inst, reff208_op in H. discriminate H. Qed.

Lemma reff208_not2457 : ~ @Equation2457 Fin3 reff208_inst.
Proof. unfold Equation2457. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff208_inst, reff208_op in H. discriminate H. Qed.

Lemma reff208_not2459 : ~ @Equation2459 Fin3 reff208_inst.
Proof. unfold Equation2459. intro H. specialize (H F3_1 F3_2). unfold magma_op, reff208_inst, reff208_op in H. discriminate H. Qed.

Lemma reff208_not2460 : ~ @Equation2460 Fin3 reff208_inst.
Proof. unfold Equation2460. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff208_inst, reff208_op in H. discriminate H. Qed.

Lemma reff208_not2467 : ~ @Equation2467 Fin3 reff208_inst.
Proof. unfold Equation2467. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff208_inst, reff208_op in H. discriminate H. Qed.

Lemma reff208_not2469 : ~ @Equation2469 Fin3 reff208_inst.
Proof. unfold Equation2469. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff208_inst, reff208_op in H. discriminate H. Qed.

Lemma reff208_not2470 : ~ @Equation2470 Fin3 reff208_inst.
Proof. unfold Equation2470. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff208_inst, reff208_op in H. discriminate H. Qed.

Lemma reff208_not2493 : ~ @Equation2493 Fin3 reff208_inst.
Proof. unfold Equation2493. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff208_inst, reff208_op in H. discriminate H. Qed.

Lemma reff208_not2494 : ~ @Equation2494 Fin3 reff208_inst.
Proof. unfold Equation2494. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff208_inst, reff208_op in H. discriminate H. Qed.

Lemma reff208_not2497 : ~ @Equation2497 Fin3 reff208_inst.
Proof. unfold Equation2497. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff208_inst, reff208_op in H. discriminate H. Qed.

Lemma reff208_not2503 : ~ @Equation2503 Fin3 reff208_inst.
Proof. unfold Equation2503. intro H. specialize (H F3_1 F3_2). unfold magma_op, reff208_inst, reff208_op in H. discriminate H. Qed.

Lemma reff208_not2504 : ~ @Equation2504 Fin3 reff208_inst.
Proof. unfold Equation2504. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff208_inst, reff208_op in H. discriminate H. Qed.

Lemma reff208_not2506 : ~ @Equation2506 Fin3 reff208_inst.
Proof. unfold Equation2506. intro H. specialize (H F3_2 F3_0). unfold magma_op, reff208_inst, reff208_op in H. discriminate H. Qed.

Lemma reff208_not2507 : ~ @Equation2507 Fin3 reff208_inst.
Proof. unfold Equation2507. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff208_inst, reff208_op in H. discriminate H. Qed.

Lemma reff208_not2531 : ~ @Equation2531 Fin3 reff208_inst.
Proof. unfold Equation2531. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff208_inst, reff208_op in H. discriminate H. Qed.

Lemma reff208_not2533 : ~ @Equation2533 Fin3 reff208_inst.
Proof. unfold Equation2533. intro H. specialize (H F3_2 F3_0). unfold magma_op, reff208_inst, reff208_op in H. discriminate H. Qed.

Lemma reff208_not2534 : ~ @Equation2534 Fin3 reff208_inst.
Proof. unfold Equation2534. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff208_inst, reff208_op in H. discriminate H. Qed.

Lemma reff208_not2540 : ~ @Equation2540 Fin3 reff208_inst.
Proof. unfold Equation2540. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff208_inst, reff208_op in H. discriminate H. Qed.

Lemma reff208_not2541 : ~ @Equation2541 Fin3 reff208_inst.
Proof. unfold Equation2541. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff208_inst, reff208_op in H. discriminate H. Qed.

Lemma reff208_not2645 : ~ @Equation2645 Fin3 reff208_inst.
Proof. unfold Equation2645. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff208_inst, reff208_op in H. discriminate H. Qed.

Lemma reff208_not2646 : ~ @Equation2646 Fin3 reff208_inst.
Proof. unfold Equation2646. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff208_inst, reff208_op in H. discriminate H. Qed.

Lemma reff208_not2647 : ~ @Equation2647 Fin3 reff208_inst.
Proof. unfold Equation2647. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff208_inst, reff208_op in H. discriminate H. Qed.

Lemma reff208_not2649 : ~ @Equation2649 Fin3 reff208_inst.
Proof. unfold Equation2649. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff208_inst, reff208_op in H. discriminate H. Qed.

Lemma reff208_not2650 : ~ @Equation2650 Fin3 reff208_inst.
Proof. unfold Equation2650. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff208_inst, reff208_op in H. discriminate H. Qed.

Lemma reff208_not2653 : ~ @Equation2653 Fin3 reff208_inst.
Proof. unfold Equation2653. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff208_inst, reff208_op in H. discriminate H. Qed.

Lemma reff208_not2659 : ~ @Equation2659 Fin3 reff208_inst.
Proof. unfold Equation2659. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff208_inst, reff208_op in H. discriminate H. Qed.

Lemma reff208_not2660 : ~ @Equation2660 Fin3 reff208_inst.
Proof. unfold Equation2660. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff208_inst, reff208_op in H. discriminate H. Qed.

Lemma reff208_not2663 : ~ @Equation2663 Fin3 reff208_inst.
Proof. unfold Equation2663. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff208_inst, reff208_op in H. discriminate H. Qed.

Lemma reff208_not2669 : ~ @Equation2669 Fin3 reff208_inst.
Proof. unfold Equation2669. intro H. specialize (H F3_1 F3_2). unfold magma_op, reff208_inst, reff208_op in H. discriminate H. Qed.

Lemma reff208_not2670 : ~ @Equation2670 Fin3 reff208_inst.
Proof. unfold Equation2670. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff208_inst, reff208_op in H. discriminate H. Qed.

Lemma reff208_not2672 : ~ @Equation2672 Fin3 reff208_inst.
Proof. unfold Equation2672. intro H. specialize (H F3_2 F3_0). unfold magma_op, reff208_inst, reff208_op in H. discriminate H. Qed.

Lemma reff208_not2673 : ~ @Equation2673 Fin3 reff208_inst.
Proof. unfold Equation2673. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff208_inst, reff208_op in H. discriminate H. Qed.

Lemma reff208_not2696 : ~ @Equation2696 Fin3 reff208_inst.
Proof. unfold Equation2696. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff208_inst, reff208_op in H. discriminate H. Qed.

Lemma reff208_not2697 : ~ @Equation2697 Fin3 reff208_inst.
Proof. unfold Equation2697. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff208_inst, reff208_op in H. discriminate H. Qed.

Lemma reff208_not2699 : ~ @Equation2699 Fin3 reff208_inst.
Proof. unfold Equation2699. intro H. specialize (H F3_1 F3_2). unfold magma_op, reff208_inst, reff208_op in H. discriminate H. Qed.

Lemma reff208_not2700 : ~ @Equation2700 Fin3 reff208_inst.
Proof. unfold Equation2700. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff208_inst, reff208_op in H. discriminate H. Qed.

Lemma reff208_not2707 : ~ @Equation2707 Fin3 reff208_inst.
Proof. unfold Equation2707. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff208_inst, reff208_op in H. discriminate H. Qed.

Lemma reff208_not2709 : ~ @Equation2709 Fin3 reff208_inst.
Proof. unfold Equation2709. intro H. specialize (H F3_2 F3_0). unfold magma_op, reff208_inst, reff208_op in H. discriminate H. Qed.

Lemma reff208_not2710 : ~ @Equation2710 Fin3 reff208_inst.
Proof. unfold Equation2710. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff208_inst, reff208_op in H. discriminate H. Qed.

Lemma reff208_not2734 : ~ @Equation2734 Fin3 reff208_inst.
Proof. unfold Equation2734. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff208_inst, reff208_op in H. discriminate H. Qed.

Lemma reff208_not2736 : ~ @Equation2736 Fin3 reff208_inst.
Proof. unfold Equation2736. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff208_inst, reff208_op in H. discriminate H. Qed.

Lemma reff208_not2737 : ~ @Equation2737 Fin3 reff208_inst.
Proof. unfold Equation2737. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff208_inst, reff208_op in H. discriminate H. Qed.

Lemma reff208_not2743 : ~ @Equation2743 Fin3 reff208_inst.
Proof. unfold Equation2743. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff208_inst, reff208_op in H. discriminate H. Qed.

Lemma reff208_not2744 : ~ @Equation2744 Fin3 reff208_inst.
Proof. unfold Equation2744. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff208_inst, reff208_op in H. discriminate H. Qed.

Lemma reff208_not2847 : ~ @Equation2847 Fin3 reff208_inst.
Proof. unfold Equation2847. intro H. specialize (H F3_2). unfold magma_op, reff208_inst, reff208_op in H. discriminate H. Qed.

Lemma reff208_not3051 : ~ @Equation3051 Fin3 reff208_inst.
Proof. unfold Equation3051. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff208_inst, reff208_op in H. discriminate H. Qed.

Lemma reff208_not3052 : ~ @Equation3052 Fin3 reff208_inst.
Proof. unfold Equation3052. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff208_inst, reff208_op in H. discriminate H. Qed.

Lemma reff208_not3053 : ~ @Equation3053 Fin3 reff208_inst.
Proof. unfold Equation3053. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff208_inst, reff208_op in H. discriminate H. Qed.

Lemma reff208_not3055 : ~ @Equation3055 Fin3 reff208_inst.
Proof. unfold Equation3055. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff208_inst, reff208_op in H. discriminate H. Qed.

Lemma reff208_not3056 : ~ @Equation3056 Fin3 reff208_inst.
Proof. unfold Equation3056. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff208_inst, reff208_op in H. discriminate H. Qed.

Lemma reff208_not3059 : ~ @Equation3059 Fin3 reff208_inst.
Proof. unfold Equation3059. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff208_inst, reff208_op in H. discriminate H. Qed.

Lemma reff208_not3065 : ~ @Equation3065 Fin3 reff208_inst.
Proof. unfold Equation3065. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff208_inst, reff208_op in H. discriminate H. Qed.

Lemma reff208_not3066 : ~ @Equation3066 Fin3 reff208_inst.
Proof. unfold Equation3066. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff208_inst, reff208_op in H. discriminate H. Qed.

Lemma reff208_not3068 : ~ @Equation3068 Fin3 reff208_inst.
Proof. unfold Equation3068. intro H. specialize (H F3_1 F3_2). unfold magma_op, reff208_inst, reff208_op in H. discriminate H. Qed.

Lemma reff208_not3069 : ~ @Equation3069 Fin3 reff208_inst.
Proof. unfold Equation3069. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff208_inst, reff208_op in H. discriminate H. Qed.

Lemma reff208_not3075 : ~ @Equation3075 Fin3 reff208_inst.
Proof. unfold Equation3075. intro H. specialize (H F3_2 F3_1). unfold magma_op, reff208_inst, reff208_op in H. discriminate H. Qed.

Lemma reff208_not3076 : ~ @Equation3076 Fin3 reff208_inst.
Proof. unfold Equation3076. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff208_inst, reff208_op in H. discriminate H. Qed.

Lemma reff208_not3078 : ~ @Equation3078 Fin3 reff208_inst.
Proof. unfold Equation3078. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff208_inst, reff208_op in H. discriminate H. Qed.

Lemma reff208_not3079 : ~ @Equation3079 Fin3 reff208_inst.
Proof. unfold Equation3079. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff208_inst, reff208_op in H. discriminate H. Qed.

Lemma reff208_not3102 : ~ @Equation3102 Fin3 reff208_inst.
Proof. unfold Equation3102. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff208_inst, reff208_op in H. discriminate H. Qed.

Lemma reff208_not3103 : ~ @Equation3103 Fin3 reff208_inst.
Proof. unfold Equation3103. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff208_inst, reff208_op in H. discriminate H. Qed.

Lemma reff208_not3105 : ~ @Equation3105 Fin3 reff208_inst.
Proof. unfold Equation3105. intro H. specialize (H F3_1 F3_2). unfold magma_op, reff208_inst, reff208_op in H. discriminate H. Qed.

Lemma reff208_not3106 : ~ @Equation3106 Fin3 reff208_inst.
Proof. unfold Equation3106. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff208_inst, reff208_op in H. discriminate H. Qed.

Lemma reff208_not3112 : ~ @Equation3112 Fin3 reff208_inst.
Proof. unfold Equation3112. intro H. specialize (H F3_2 F3_1). unfold magma_op, reff208_inst, reff208_op in H. discriminate H. Qed.

Lemma reff208_not3113 : ~ @Equation3113 Fin3 reff208_inst.
Proof. unfold Equation3113. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff208_inst, reff208_op in H. discriminate H. Qed.

Lemma reff208_not3115 : ~ @Equation3115 Fin3 reff208_inst.
Proof. unfold Equation3115. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff208_inst, reff208_op in H. discriminate H. Qed.

Lemma reff208_not3116 : ~ @Equation3116 Fin3 reff208_inst.
Proof. unfold Equation3116. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff208_inst, reff208_op in H. discriminate H. Qed.

Lemma reff208_not3140 : ~ @Equation3140 Fin3 reff208_inst.
Proof. unfold Equation3140. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff208_inst, reff208_op in H. discriminate H. Qed.

Lemma reff208_not3142 : ~ @Equation3142 Fin3 reff208_inst.
Proof. unfold Equation3142. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff208_inst, reff208_op in H. discriminate H. Qed.

Lemma reff208_not3143 : ~ @Equation3143 Fin3 reff208_inst.
Proof. unfold Equation3143. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff208_inst, reff208_op in H. discriminate H. Qed.

Lemma reff208_not3149 : ~ @Equation3149 Fin3 reff208_inst.
Proof. unfold Equation3149. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff208_inst, reff208_op in H. discriminate H. Qed.

Lemma reff208_not3150 : ~ @Equation3150 Fin3 reff208_inst.
Proof. unfold Equation3150. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff208_inst, reff208_op in H. discriminate H. Qed.

Lemma reff208_not3253 : ~ @Equation3253 Fin3 reff208_inst.
Proof. unfold Equation3253. intro H. specialize (H F3_2). unfold magma_op, reff208_inst, reff208_op in H. discriminate H. Qed.

Lemma reff208_not3457 : ~ @Equation3457 Fin3 reff208_inst.
Proof. unfold Equation3457. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff208_inst, reff208_op in H. discriminate H. Qed.

Lemma reff208_not3458 : ~ @Equation3458 Fin3 reff208_inst.
Proof. unfold Equation3458. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff208_inst, reff208_op in H. discriminate H. Qed.

Lemma reff208_not3459 : ~ @Equation3459 Fin3 reff208_inst.
Proof. unfold Equation3459. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff208_inst, reff208_op in H. discriminate H. Qed.

Lemma reff208_not3461 : ~ @Equation3461 Fin3 reff208_inst.
Proof. unfold Equation3461. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff208_inst, reff208_op in H. discriminate H. Qed.

Lemma reff208_not3462 : ~ @Equation3462 Fin3 reff208_inst.
Proof. unfold Equation3462. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff208_inst, reff208_op in H. discriminate H. Qed.

Lemma reff208_not3465 : ~ @Equation3465 Fin3 reff208_inst.
Proof. unfold Equation3465. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff208_inst, reff208_op in H. discriminate H. Qed.

Lemma reff208_not3472 : ~ @Equation3472 Fin3 reff208_inst.
Proof. unfold Equation3472. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff208_inst, reff208_op in H. discriminate H. Qed.

Lemma reff208_not3474 : ~ @Equation3474 Fin3 reff208_inst.
Proof. unfold Equation3474. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff208_inst, reff208_op in H. discriminate H. Qed.

Lemma reff208_not3475 : ~ @Equation3475 Fin3 reff208_inst.
Proof. unfold Equation3475. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff208_inst, reff208_op in H. discriminate H. Qed.

Lemma reff208_not3481 : ~ @Equation3481 Fin3 reff208_inst.
Proof. unfold Equation3481. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff208_inst, reff208_op in H. discriminate H. Qed.

Lemma reff208_not3482 : ~ @Equation3482 Fin3 reff208_inst.
Proof. unfold Equation3482. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff208_inst, reff208_op in H. discriminate H. Qed.

Lemma reff208_not3484 : ~ @Equation3484 Fin3 reff208_inst.
Proof. unfold Equation3484. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff208_inst, reff208_op in H. discriminate H. Qed.

Lemma reff208_not3511 : ~ @Equation3511 Fin3 reff208_inst.
Proof. unfold Equation3511. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff208_inst, reff208_op in H. discriminate H. Qed.

Lemma reff208_not3512 : ~ @Equation3512 Fin3 reff208_inst.
Proof. unfold Equation3512. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff208_inst, reff208_op in H. discriminate H. Qed.

Lemma reff208_not3518 : ~ @Equation3518 Fin3 reff208_inst.
Proof. unfold Equation3518. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff208_inst, reff208_op in H. discriminate H. Qed.

Lemma reff208_not3519 : ~ @Equation3519 Fin3 reff208_inst.
Proof. unfold Equation3519. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff208_inst, reff208_op in H. discriminate H. Qed.

Lemma reff208_not3521 : ~ @Equation3521 Fin3 reff208_inst.
Proof. unfold Equation3521. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff208_inst, reff208_op in H. discriminate H. Qed.

Lemma reff208_not3545 : ~ @Equation3545 Fin3 reff208_inst.
Proof. unfold Equation3545. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff208_inst, reff208_op in H. discriminate H. Qed.

Lemma reff208_not3546 : ~ @Equation3546 Fin3 reff208_inst.
Proof. unfold Equation3546. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff208_inst, reff208_op in H. discriminate H. Qed.

Lemma reff208_not3548 : ~ @Equation3548 Fin3 reff208_inst.
Proof. unfold Equation3548. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff208_inst, reff208_op in H. discriminate H. Qed.

Lemma reff208_not3549 : ~ @Equation3549 Fin3 reff208_inst.
Proof. unfold Equation3549. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff208_inst, reff208_op in H. discriminate H. Qed.

Lemma reff208_not3555 : ~ @Equation3555 Fin3 reff208_inst.
Proof. unfold Equation3555. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff208_inst, reff208_op in H. discriminate H. Qed.

Lemma reff208_not3556 : ~ @Equation3556 Fin3 reff208_inst.
Proof. unfold Equation3556. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff208_inst, reff208_op in H. discriminate H. Qed.

Lemma reff208_not3558 : ~ @Equation3558 Fin3 reff208_inst.
Proof. unfold Equation3558. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff208_inst, reff208_op in H. discriminate H. Qed.

Lemma reff208_not3660 : ~ @Equation3660 Fin3 reff208_inst.
Proof. unfold Equation3660. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff208_inst, reff208_op in H. discriminate H. Qed.

Lemma reff208_not3661 : ~ @Equation3661 Fin3 reff208_inst.
Proof. unfold Equation3661. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff208_inst, reff208_op in H. discriminate H. Qed.

Lemma reff208_not3662 : ~ @Equation3662 Fin3 reff208_inst.
Proof. unfold Equation3662. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff208_inst, reff208_op in H. discriminate H. Qed.

Lemma reff208_not3664 : ~ @Equation3664 Fin3 reff208_inst.
Proof. unfold Equation3664. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff208_inst, reff208_op in H. discriminate H. Qed.

Lemma reff208_not3665 : ~ @Equation3665 Fin3 reff208_inst.
Proof. unfold Equation3665. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff208_inst, reff208_op in H. discriminate H. Qed.

Lemma reff208_not3667 : ~ @Equation3667 Fin3 reff208_inst.
Proof. unfold Equation3667. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff208_inst, reff208_op in H. discriminate H. Qed.

Lemma reff208_not3668 : ~ @Equation3668 Fin3 reff208_inst.
Proof. unfold Equation3668. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff208_inst, reff208_op in H. discriminate H. Qed.

Lemma reff208_not3674 : ~ @Equation3674 Fin3 reff208_inst.
Proof. unfold Equation3674. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff208_inst, reff208_op in H. discriminate H. Qed.

Lemma reff208_not3675 : ~ @Equation3675 Fin3 reff208_inst.
Proof. unfold Equation3675. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff208_inst, reff208_op in H. discriminate H. Qed.

Lemma reff208_not3677 : ~ @Equation3677 Fin3 reff208_inst.
Proof. unfold Equation3677. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff208_inst, reff208_op in H. discriminate H. Qed.

Lemma reff208_not3678 : ~ @Equation3678 Fin3 reff208_inst.
Proof. unfold Equation3678. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff208_inst, reff208_op in H. discriminate H. Qed.

Lemma reff208_not3685 : ~ @Equation3685 Fin3 reff208_inst.
Proof. unfold Equation3685. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff208_inst, reff208_op in H. discriminate H. Qed.

Lemma reff208_not3687 : ~ @Equation3687 Fin3 reff208_inst.
Proof. unfold Equation3687. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff208_inst, reff208_op in H. discriminate H. Qed.

Lemma reff208_not3714 : ~ @Equation3714 Fin3 reff208_inst.
Proof. unfold Equation3714. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff208_inst, reff208_op in H. discriminate H. Qed.

Lemma reff208_not3721 : ~ @Equation3721 Fin3 reff208_inst.
Proof. unfold Equation3721. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff208_inst, reff208_op in H. discriminate H. Qed.

Lemma reff208_not3722 : ~ @Equation3722 Fin3 reff208_inst.
Proof. unfold Equation3722. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff208_inst, reff208_op in H. discriminate H. Qed.

Lemma reff208_not3724 : ~ @Equation3724 Fin3 reff208_inst.
Proof. unfold Equation3724. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff208_inst, reff208_op in H. discriminate H. Qed.

Lemma reff208_not3725 : ~ @Equation3725 Fin3 reff208_inst.
Proof. unfold Equation3725. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff208_inst, reff208_op in H. discriminate H. Qed.

Lemma reff208_not3748 : ~ @Equation3748 Fin3 reff208_inst.
Proof. unfold Equation3748. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff208_inst, reff208_op in H. discriminate H. Qed.

Lemma reff208_not3749 : ~ @Equation3749 Fin3 reff208_inst.
Proof. unfold Equation3749. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff208_inst, reff208_op in H. discriminate H. Qed.

Lemma reff208_not3751 : ~ @Equation3751 Fin3 reff208_inst.
Proof. unfold Equation3751. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff208_inst, reff208_op in H. discriminate H. Qed.

Lemma reff208_not3752 : ~ @Equation3752 Fin3 reff208_inst.
Proof. unfold Equation3752. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff208_inst, reff208_op in H. discriminate H. Qed.

Lemma reff208_not3761 : ~ @Equation3761 Fin3 reff208_inst.
Proof. unfold Equation3761. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff208_inst, reff208_op in H. discriminate H. Qed.

Lemma reff208_not3862 : ~ @Equation3862 Fin3 reff208_inst.
Proof. unfold Equation3862. intro H. specialize (H F3_2). unfold magma_op, reff208_inst, reff208_op in H. discriminate H. Qed.

Lemma reff208_not4066 : ~ @Equation4066 Fin3 reff208_inst.
Proof. unfold Equation4066. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff208_inst, reff208_op in H. discriminate H. Qed.

Lemma reff208_not4067 : ~ @Equation4067 Fin3 reff208_inst.
Proof. unfold Equation4067. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff208_inst, reff208_op in H. discriminate H. Qed.

Lemma reff208_not4068 : ~ @Equation4068 Fin3 reff208_inst.
Proof. unfold Equation4068. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff208_inst, reff208_op in H. discriminate H. Qed.

Lemma reff208_not4070 : ~ @Equation4070 Fin3 reff208_inst.
Proof. unfold Equation4070. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff208_inst, reff208_op in H. discriminate H. Qed.

Lemma reff208_not4071 : ~ @Equation4071 Fin3 reff208_inst.
Proof. unfold Equation4071. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff208_inst, reff208_op in H. discriminate H. Qed.

Lemma reff208_not4073 : ~ @Equation4073 Fin3 reff208_inst.
Proof. unfold Equation4073. intro H. specialize (H F3_2 F3_1). unfold magma_op, reff208_inst, reff208_op in H. discriminate H. Qed.

Lemma reff208_not4074 : ~ @Equation4074 Fin3 reff208_inst.
Proof. unfold Equation4074. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff208_inst, reff208_op in H. discriminate H. Qed.

Lemma reff208_not4080 : ~ @Equation4080 Fin3 reff208_inst.
Proof. unfold Equation4080. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff208_inst, reff208_op in H. discriminate H. Qed.

Lemma reff208_not4081 : ~ @Equation4081 Fin3 reff208_inst.
Proof. unfold Equation4081. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff208_inst, reff208_op in H. discriminate H. Qed.

Lemma reff208_not4083 : ~ @Equation4083 Fin3 reff208_inst.
Proof. unfold Equation4083. intro H. specialize (H F3_1 F3_2). unfold magma_op, reff208_inst, reff208_op in H. discriminate H. Qed.

Lemma reff208_not4084 : ~ @Equation4084 Fin3 reff208_inst.
Proof. unfold Equation4084. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff208_inst, reff208_op in H. discriminate H. Qed.

Lemma reff208_not4091 : ~ @Equation4091 Fin3 reff208_inst.
Proof. unfold Equation4091. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff208_inst, reff208_op in H. discriminate H. Qed.

Lemma reff208_not4093 : ~ @Equation4093 Fin3 reff208_inst.
Proof. unfold Equation4093. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff208_inst, reff208_op in H. discriminate H. Qed.

Lemma reff208_not4120 : ~ @Equation4120 Fin3 reff208_inst.
Proof. unfold Equation4120. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff208_inst, reff208_op in H. discriminate H. Qed.

Lemma reff208_not4121 : ~ @Equation4121 Fin3 reff208_inst.
Proof. unfold Equation4121. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff208_inst, reff208_op in H. discriminate H. Qed.

Lemma reff208_not4127 : ~ @Equation4127 Fin3 reff208_inst.
Proof. unfold Equation4127. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff208_inst, reff208_op in H. discriminate H. Qed.

Lemma reff208_not4128 : ~ @Equation4128 Fin3 reff208_inst.
Proof. unfold Equation4128. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff208_inst, reff208_op in H. discriminate H. Qed.

Lemma reff208_not4130 : ~ @Equation4130 Fin3 reff208_inst.
Proof. unfold Equation4130. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff208_inst, reff208_op in H. discriminate H. Qed.

Lemma reff208_not4131 : ~ @Equation4131 Fin3 reff208_inst.
Proof. unfold Equation4131. intro H. specialize (H F3_2 F3_1). unfold magma_op, reff208_inst, reff208_op in H. discriminate H. Qed.

Lemma reff208_not4155 : ~ @Equation4155 Fin3 reff208_inst.
Proof. unfold Equation4155. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff208_inst, reff208_op in H. discriminate H. Qed.

Lemma reff208_not4157 : ~ @Equation4157 Fin3 reff208_inst.
Proof. unfold Equation4157. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff208_inst, reff208_op in H. discriminate H. Qed.

Lemma reff208_not4158 : ~ @Equation4158 Fin3 reff208_inst.
Proof. unfold Equation4158. intro H. specialize (H F3_1 F3_2). unfold magma_op, reff208_inst, reff208_op in H. discriminate H. Qed.

Lemma reff208_not4164 : ~ @Equation4164 Fin3 reff208_inst.
Proof. unfold Equation4164. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff208_inst, reff208_op in H. discriminate H. Qed.

Lemma reff208_not4167 : ~ @Equation4167 Fin3 reff208_inst.
Proof. unfold Equation4167. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff208_inst, reff208_op in H. discriminate H. Qed.

Lemma reff208_not4268 : ~ @Equation4268 Fin3 reff208_inst.
Proof. unfold Equation4268. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff208_inst, reff208_op in H. discriminate H. Qed.

Lemma reff208_not4269 : ~ @Equation4269 Fin3 reff208_inst.
Proof. unfold Equation4269. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff208_inst, reff208_op in H. discriminate H. Qed.

Lemma reff208_not4270 : ~ @Equation4270 Fin3 reff208_inst.
Proof. unfold Equation4270. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff208_inst, reff208_op in H. discriminate H. Qed.

Lemma reff208_not4272 : ~ @Equation4272 Fin3 reff208_inst.
Proof. unfold Equation4272. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff208_inst, reff208_op in H. discriminate H. Qed.

Lemma reff208_not4273 : ~ @Equation4273 Fin3 reff208_inst.
Proof. unfold Equation4273. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff208_inst, reff208_op in H. discriminate H. Qed.

Lemma reff208_not4275 : ~ @Equation4275 Fin3 reff208_inst.
Proof. unfold Equation4275. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff208_inst, reff208_op in H. discriminate H. Qed.

Lemma reff208_not4276 : ~ @Equation4276 Fin3 reff208_inst.
Proof. unfold Equation4276. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff208_inst, reff208_op in H. discriminate H. Qed.

Lemma reff208_not4283 : ~ @Equation4283 Fin3 reff208_inst.
Proof. unfold Equation4283. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff208_inst, reff208_op in H. discriminate H. Qed.

Lemma reff208_not4284 : ~ @Equation4284 Fin3 reff208_inst.
Proof. unfold Equation4284. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff208_inst, reff208_op in H. discriminate H. Qed.

Lemma reff208_not4290 : ~ @Equation4290 Fin3 reff208_inst.
Proof. unfold Equation4290. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff208_inst, reff208_op in H. discriminate H. Qed.

Lemma reff208_not4291 : ~ @Equation4291 Fin3 reff208_inst.
Proof. unfold Equation4291. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff208_inst, reff208_op in H. discriminate H. Qed.

Lemma reff208_not4293 : ~ @Equation4293 Fin3 reff208_inst.
Proof. unfold Equation4293. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff208_inst, reff208_op in H. discriminate H. Qed.

Lemma reff208_not4314 : ~ @Equation4314 Fin3 reff208_inst.
Proof. unfold Equation4314. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff208_inst, reff208_op in H. discriminate H. Qed.

Lemma reff208_not4321 : ~ @Equation4321 Fin3 reff208_inst.
Proof. unfold Equation4321. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff208_inst, reff208_op in H. discriminate H. Qed.

Lemma reff208_not4343 : ~ @Equation4343 Fin3 reff208_inst.
Proof. unfold Equation4343. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff208_inst, reff208_op in H. discriminate H. Qed.

Lemma reff208_not4380 : ~ @Equation4380 Fin3 reff208_inst.
Proof. unfold Equation4380. intro H. specialize (H F3_2). unfold magma_op, reff208_inst, reff208_op in H. discriminate H. Qed.

Lemma reff208_not4583 : ~ @Equation4583 Fin3 reff208_inst.
Proof. unfold Equation4583. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff208_inst, reff208_op in H. discriminate H. Qed.

Lemma reff208_not4584 : ~ @Equation4584 Fin3 reff208_inst.
Proof. unfold Equation4584. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff208_inst, reff208_op in H. discriminate H. Qed.

Lemma reff208_not4585 : ~ @Equation4585 Fin3 reff208_inst.
Proof. unfold Equation4585. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff208_inst, reff208_op in H. discriminate H. Qed.

Lemma reff208_not4587 : ~ @Equation4587 Fin3 reff208_inst.
Proof. unfold Equation4587. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff208_inst, reff208_op in H. discriminate H. Qed.

Lemma reff208_not4588 : ~ @Equation4588 Fin3 reff208_inst.
Proof. unfold Equation4588. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff208_inst, reff208_op in H. discriminate H. Qed.

Lemma reff208_not4591 : ~ @Equation4591 Fin3 reff208_inst.
Proof. unfold Equation4591. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff208_inst, reff208_op in H. discriminate H. Qed.

Lemma reff208_not4598 : ~ @Equation4598 Fin3 reff208_inst.
Proof. unfold Equation4598. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff208_inst, reff208_op in H. discriminate H. Qed.

Lemma reff208_not4599 : ~ @Equation4599 Fin3 reff208_inst.
Proof. unfold Equation4599. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff208_inst, reff208_op in H. discriminate H. Qed.

Lemma reff208_not4605 : ~ @Equation4605 Fin3 reff208_inst.
Proof. unfold Equation4605. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff208_inst, reff208_op in H. discriminate H. Qed.

Lemma reff208_not4606 : ~ @Equation4606 Fin3 reff208_inst.
Proof. unfold Equation4606. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff208_inst, reff208_op in H. discriminate H. Qed.

Lemma reff208_not4608 : ~ @Equation4608 Fin3 reff208_inst.
Proof. unfold Equation4608. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff208_inst, reff208_op in H. discriminate H. Qed.

Lemma reff208_not4629 : ~ @Equation4629 Fin3 reff208_inst.
Proof. unfold Equation4629. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff208_inst, reff208_op in H. discriminate H. Qed.

Lemma reff208_not4635 : ~ @Equation4635 Fin3 reff208_inst.
Proof. unfold Equation4635. intro H. specialize (H F3_1 F3_2). unfold magma_op, reff208_inst, reff208_op in H. discriminate H. Qed.

Lemma reff208_not4636 : ~ @Equation4636 Fin3 reff208_inst.
Proof. unfold Equation4636. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff208_inst, reff208_op in H. discriminate H. Qed.

Lemma reff208_not4658 : ~ @Equation4658 Fin3 reff208_inst.
Proof. unfold Equation4658. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff208_inst, reff208_op in H. discriminate H. Qed.

(** ---- reff212 (Fin4) ---- *)

Definition reff212_op (x y : Fin4) : Fin4 :=
  match x, y with
  | F4_0, F4_0 => F4_0 | F4_0, F4_1 => F4_1 | F4_0, F4_2 => F4_0 | F4_0, F4_3 => F4_1
  | F4_1, F4_0 => F4_3 | F4_1, F4_1 => F4_1 | F4_1, F4_2 => F4_1 | F4_1, F4_3 => F4_3
  | F4_2, F4_0 => F4_2 | F4_2, F4_1 => F4_1 | F4_2, F4_2 => F4_2 | F4_2, F4_3 => F4_1
  | F4_3, F4_0 => F4_1 | F4_3, F4_1 => F4_1 | F4_3, F4_2 => F4_3 | F4_3, F4_3 => F4_3
  end.

#[local] Instance reff212_inst : Magma Fin4 := {| magma_op := reff212_op |}.

Lemma reff212_sat323 : @Equation323 Fin4 reff212_inst.
Proof. unfold Equation323, magma_op, reff212_inst, reff212_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff212_sat3309 : @Equation3309 Fin4 reff212_inst.
Proof. unfold Equation3309, magma_op, reff212_inst, reff212_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff212_sat3509 : @Equation3509 Fin4 reff212_inst.
Proof. unfold Equation3509, magma_op, reff212_inst, reff212_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff212_sat3712 : @Equation3712 Fin4 reff212_inst.
Proof. unfold Equation3712, magma_op, reff212_inst, reff212_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff212_sat4284 : @Equation4284 Fin4 reff212_inst.
Proof. unfold Equation4284, magma_op, reff212_inst, reff212_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff212_sat4396 : @Equation4396 Fin4 reff212_inst.
Proof. unfold Equation4396, magma_op, reff212_inst, reff212_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff212_not50 : ~ @Equation50 Fin4 reff212_inst.
Proof. unfold Equation50. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff212_inst, reff212_op in H. discriminate H. Qed.

Lemma reff212_not53 : ~ @Equation53 Fin4 reff212_inst.
Proof. unfold Equation53. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff212_inst, reff212_op in H. discriminate H. Qed.

Lemma reff212_not55 : ~ @Equation55 Fin4 reff212_inst.
Proof. unfold Equation55. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff212_inst, reff212_op in H. discriminate H. Qed.

Lemma reff212_not56 : ~ @Equation56 Fin4 reff212_inst.
Proof. unfold Equation56. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff212_inst, reff212_op in H. discriminate H. Qed.

Lemma reff212_not63 : ~ @Equation63 Fin4 reff212_inst.
Proof. unfold Equation63. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff212_inst, reff212_op in H. discriminate H. Qed.

Lemma reff212_not65 : ~ @Equation65 Fin4 reff212_inst.
Proof. unfold Equation65. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff212_inst, reff212_op in H. discriminate H. Qed.

Lemma reff212_not66 : ~ @Equation66 Fin4 reff212_inst.
Proof. unfold Equation66. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff212_inst, reff212_op in H. discriminate H. Qed.

Lemma reff212_not72 : ~ @Equation72 Fin4 reff212_inst.
Proof. unfold Equation72. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff212_inst, reff212_op in H. discriminate H. Qed.

Lemma reff212_not73 : ~ @Equation73 Fin4 reff212_inst.
Proof. unfold Equation73. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff212_inst, reff212_op in H. discriminate H. Qed.

Lemma reff212_not75 : ~ @Equation75 Fin4 reff212_inst.
Proof. unfold Equation75. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff212_inst, reff212_op in H. discriminate H. Qed.

Lemma reff212_not102 : ~ @Equation102 Fin4 reff212_inst.
Proof. unfold Equation102. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff212_inst, reff212_op in H. discriminate H. Qed.

Lemma reff212_not105 : ~ @Equation105 Fin4 reff212_inst.
Proof. unfold Equation105. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff212_inst, reff212_op in H. discriminate H. Qed.

Lemma reff212_not107 : ~ @Equation107 Fin4 reff212_inst.
Proof. unfold Equation107. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff212_inst, reff212_op in H. discriminate H. Qed.

Lemma reff212_not108 : ~ @Equation108 Fin4 reff212_inst.
Proof. unfold Equation108. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff212_inst, reff212_op in H. discriminate H. Qed.

Lemma reff212_not115 : ~ @Equation115 Fin4 reff212_inst.
Proof. unfold Equation115. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff212_inst, reff212_op in H. discriminate H. Qed.

Lemma reff212_not117 : ~ @Equation117 Fin4 reff212_inst.
Proof. unfold Equation117. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff212_inst, reff212_op in H. discriminate H. Qed.

Lemma reff212_not118 : ~ @Equation118 Fin4 reff212_inst.
Proof. unfold Equation118. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff212_inst, reff212_op in H. discriminate H. Qed.

Lemma reff212_not124 : ~ @Equation124 Fin4 reff212_inst.
Proof. unfold Equation124. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff212_inst, reff212_op in H. discriminate H. Qed.

Lemma reff212_not125 : ~ @Equation125 Fin4 reff212_inst.
Proof. unfold Equation125. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff212_inst, reff212_op in H. discriminate H. Qed.

Lemma reff212_not127 : ~ @Equation127 Fin4 reff212_inst.
Proof. unfold Equation127. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff212_inst, reff212_op in H. discriminate H. Qed.

Lemma reff212_not154 : ~ @Equation154 Fin4 reff212_inst.
Proof. unfold Equation154. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff212_inst, reff212_op in H. discriminate H. Qed.

Lemma reff212_not157 : ~ @Equation157 Fin4 reff212_inst.
Proof. unfold Equation157. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff212_inst, reff212_op in H. discriminate H. Qed.

Lemma reff212_not159 : ~ @Equation159 Fin4 reff212_inst.
Proof. unfold Equation159. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff212_inst, reff212_op in H. discriminate H. Qed.

Lemma reff212_not160 : ~ @Equation160 Fin4 reff212_inst.
Proof. unfold Equation160. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff212_inst, reff212_op in H. discriminate H. Qed.

Lemma reff212_not167 : ~ @Equation167 Fin4 reff212_inst.
Proof. unfold Equation167. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff212_inst, reff212_op in H. discriminate H. Qed.

Lemma reff212_not169 : ~ @Equation169 Fin4 reff212_inst.
Proof. unfold Equation169. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff212_inst, reff212_op in H. discriminate H. Qed.

Lemma reff212_not170 : ~ @Equation170 Fin4 reff212_inst.
Proof. unfold Equation170. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff212_inst, reff212_op in H. discriminate H. Qed.

Lemma reff212_not176 : ~ @Equation176 Fin4 reff212_inst.
Proof. unfold Equation176. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff212_inst, reff212_op in H. discriminate H. Qed.

Lemma reff212_not177 : ~ @Equation177 Fin4 reff212_inst.
Proof. unfold Equation177. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff212_inst, reff212_op in H. discriminate H. Qed.

Lemma reff212_not179 : ~ @Equation179 Fin4 reff212_inst.
Proof. unfold Equation179. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff212_inst, reff212_op in H. discriminate H. Qed.

Lemma reff212_not206 : ~ @Equation206 Fin4 reff212_inst.
Proof. unfold Equation206. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff212_inst, reff212_op in H. discriminate H. Qed.

Lemma reff212_not209 : ~ @Equation209 Fin4 reff212_inst.
Proof. unfold Equation209. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff212_inst, reff212_op in H. discriminate H. Qed.

Lemma reff212_not211 : ~ @Equation211 Fin4 reff212_inst.
Proof. unfold Equation211. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff212_inst, reff212_op in H. discriminate H. Qed.

Lemma reff212_not212 : ~ @Equation212 Fin4 reff212_inst.
Proof. unfold Equation212. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff212_inst, reff212_op in H. discriminate H. Qed.

Lemma reff212_not219 : ~ @Equation219 Fin4 reff212_inst.
Proof. unfold Equation219. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff212_inst, reff212_op in H. discriminate H. Qed.

Lemma reff212_not221 : ~ @Equation221 Fin4 reff212_inst.
Proof. unfold Equation221. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff212_inst, reff212_op in H. discriminate H. Qed.

Lemma reff212_not222 : ~ @Equation222 Fin4 reff212_inst.
Proof. unfold Equation222. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff212_inst, reff212_op in H. discriminate H. Qed.

Lemma reff212_not228 : ~ @Equation228 Fin4 reff212_inst.
Proof. unfold Equation228. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff212_inst, reff212_op in H. discriminate H. Qed.

Lemma reff212_not229 : ~ @Equation229 Fin4 reff212_inst.
Proof. unfold Equation229. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff212_inst, reff212_op in H. discriminate H. Qed.

Lemma reff212_not231 : ~ @Equation231 Fin4 reff212_inst.
Proof. unfold Equation231. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff212_inst, reff212_op in H. discriminate H. Qed.

Lemma reff212_not258 : ~ @Equation258 Fin4 reff212_inst.
Proof. unfold Equation258. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff212_inst, reff212_op in H. discriminate H. Qed.

Lemma reff212_not261 : ~ @Equation261 Fin4 reff212_inst.
Proof. unfold Equation261. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff212_inst, reff212_op in H. discriminate H. Qed.

Lemma reff212_not263 : ~ @Equation263 Fin4 reff212_inst.
Proof. unfold Equation263. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff212_inst, reff212_op in H. discriminate H. Qed.

Lemma reff212_not264 : ~ @Equation264 Fin4 reff212_inst.
Proof. unfold Equation264. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff212_inst, reff212_op in H. discriminate H. Qed.

Lemma reff212_not271 : ~ @Equation271 Fin4 reff212_inst.
Proof. unfold Equation271. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff212_inst, reff212_op in H. discriminate H. Qed.

Lemma reff212_not273 : ~ @Equation273 Fin4 reff212_inst.
Proof. unfold Equation273. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff212_inst, reff212_op in H. discriminate H. Qed.

Lemma reff212_not274 : ~ @Equation274 Fin4 reff212_inst.
Proof. unfold Equation274. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff212_inst, reff212_op in H. discriminate H. Qed.

Lemma reff212_not280 : ~ @Equation280 Fin4 reff212_inst.
Proof. unfold Equation280. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff212_inst, reff212_op in H. discriminate H. Qed.

Lemma reff212_not281 : ~ @Equation281 Fin4 reff212_inst.
Proof. unfold Equation281. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff212_inst, reff212_op in H. discriminate H. Qed.

Lemma reff212_not283 : ~ @Equation283 Fin4 reff212_inst.
Proof. unfold Equation283. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff212_inst, reff212_op in H. discriminate H. Qed.

Lemma reff212_not412 : ~ @Equation412 Fin4 reff212_inst.
Proof. unfold Equation412. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff212_inst, reff212_op in H. discriminate H. Qed.

Lemma reff212_not413 : ~ @Equation413 Fin4 reff212_inst.
Proof. unfold Equation413. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff212_inst, reff212_op in H. discriminate H. Qed.

Lemma reff212_not414 : ~ @Equation414 Fin4 reff212_inst.
Proof. unfold Equation414. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff212_inst, reff212_op in H. discriminate H. Qed.

Lemma reff212_not416 : ~ @Equation416 Fin4 reff212_inst.
Proof. unfold Equation416. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff212_inst, reff212_op in H. discriminate H. Qed.

Lemma reff212_not417 : ~ @Equation417 Fin4 reff212_inst.
Proof. unfold Equation417. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff212_inst, reff212_op in H. discriminate H. Qed.

Lemma reff212_not419 : ~ @Equation419 Fin4 reff212_inst.
Proof. unfold Equation419. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff212_inst, reff212_op in H. discriminate H. Qed.

Lemma reff212_not420 : ~ @Equation420 Fin4 reff212_inst.
Proof. unfold Equation420. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff212_inst, reff212_op in H. discriminate H. Qed.

Lemma reff212_not426 : ~ @Equation426 Fin4 reff212_inst.
Proof. unfold Equation426. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff212_inst, reff212_op in H. discriminate H. Qed.

Lemma reff212_not427 : ~ @Equation427 Fin4 reff212_inst.
Proof. unfold Equation427. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff212_inst, reff212_op in H. discriminate H. Qed.

Lemma reff212_not429 : ~ @Equation429 Fin4 reff212_inst.
Proof. unfold Equation429. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff212_inst, reff212_op in H. discriminate H. Qed.

Lemma reff212_not430 : ~ @Equation430 Fin4 reff212_inst.
Proof. unfold Equation430. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff212_inst, reff212_op in H. discriminate H. Qed.

Lemma reff212_not436 : ~ @Equation436 Fin4 reff212_inst.
Proof. unfold Equation436. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff212_inst, reff212_op in H. discriminate H. Qed.

Lemma reff212_not437 : ~ @Equation437 Fin4 reff212_inst.
Proof. unfold Equation437. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff212_inst, reff212_op in H. discriminate H. Qed.

Lemma reff212_not439 : ~ @Equation439 Fin4 reff212_inst.
Proof. unfold Equation439. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff212_inst, reff212_op in H. discriminate H. Qed.

Lemma reff212_not440 : ~ @Equation440 Fin4 reff212_inst.
Proof. unfold Equation440. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff212_inst, reff212_op in H. discriminate H. Qed.

Lemma reff212_not463 : ~ @Equation463 Fin4 reff212_inst.
Proof. unfold Equation463. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff212_inst, reff212_op in H. discriminate H. Qed.

Lemma reff212_not464 : ~ @Equation464 Fin4 reff212_inst.
Proof. unfold Equation464. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff212_inst, reff212_op in H. discriminate H. Qed.

Lemma reff212_not466 : ~ @Equation466 Fin4 reff212_inst.
Proof. unfold Equation466. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff212_inst, reff212_op in H. discriminate H. Qed.

Lemma reff212_not467 : ~ @Equation467 Fin4 reff212_inst.
Proof. unfold Equation467. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff212_inst, reff212_op in H. discriminate H. Qed.

Lemma reff212_not473 : ~ @Equation473 Fin4 reff212_inst.
Proof. unfold Equation473. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff212_inst, reff212_op in H. discriminate H. Qed.

Lemma reff212_not474 : ~ @Equation474 Fin4 reff212_inst.
Proof. unfold Equation474. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff212_inst, reff212_op in H. discriminate H. Qed.

Lemma reff212_not476 : ~ @Equation476 Fin4 reff212_inst.
Proof. unfold Equation476. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff212_inst, reff212_op in H. discriminate H. Qed.

Lemma reff212_not477 : ~ @Equation477 Fin4 reff212_inst.
Proof. unfold Equation477. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff212_inst, reff212_op in H. discriminate H. Qed.

Lemma reff212_not500 : ~ @Equation500 Fin4 reff212_inst.
Proof. unfold Equation500. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff212_inst, reff212_op in H. discriminate H. Qed.

Lemma reff212_not501 : ~ @Equation501 Fin4 reff212_inst.
Proof. unfold Equation501. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff212_inst, reff212_op in H. discriminate H. Qed.

Lemma reff212_not503 : ~ @Equation503 Fin4 reff212_inst.
Proof. unfold Equation503. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff212_inst, reff212_op in H. discriminate H. Qed.

Lemma reff212_not504 : ~ @Equation504 Fin4 reff212_inst.
Proof. unfold Equation504. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff212_inst, reff212_op in H. discriminate H. Qed.

Lemma reff212_not510 : ~ @Equation510 Fin4 reff212_inst.
Proof. unfold Equation510. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff212_inst, reff212_op in H. discriminate H. Qed.

Lemma reff212_not511 : ~ @Equation511 Fin4 reff212_inst.
Proof. unfold Equation511. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff212_inst, reff212_op in H. discriminate H. Qed.

Lemma reff212_not513 : ~ @Equation513 Fin4 reff212_inst.
Proof. unfold Equation513. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff212_inst, reff212_op in H. discriminate H. Qed.

Lemma reff212_not615 : ~ @Equation615 Fin4 reff212_inst.
Proof. unfold Equation615. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff212_inst, reff212_op in H. discriminate H. Qed.

Lemma reff212_not616 : ~ @Equation616 Fin4 reff212_inst.
Proof. unfold Equation616. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff212_inst, reff212_op in H. discriminate H. Qed.

Lemma reff212_not617 : ~ @Equation617 Fin4 reff212_inst.
Proof. unfold Equation617. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff212_inst, reff212_op in H. discriminate H. Qed.

Lemma reff212_not619 : ~ @Equation619 Fin4 reff212_inst.
Proof. unfold Equation619. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff212_inst, reff212_op in H. discriminate H. Qed.

Lemma reff212_not620 : ~ @Equation620 Fin4 reff212_inst.
Proof. unfold Equation620. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff212_inst, reff212_op in H. discriminate H. Qed.

Lemma reff212_not622 : ~ @Equation622 Fin4 reff212_inst.
Proof. unfold Equation622. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff212_inst, reff212_op in H. discriminate H. Qed.

Lemma reff212_not623 : ~ @Equation623 Fin4 reff212_inst.
Proof. unfold Equation623. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff212_inst, reff212_op in H. discriminate H. Qed.

Lemma reff212_not629 : ~ @Equation629 Fin4 reff212_inst.
Proof. unfold Equation629. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff212_inst, reff212_op in H. discriminate H. Qed.

Lemma reff212_not630 : ~ @Equation630 Fin4 reff212_inst.
Proof. unfold Equation630. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff212_inst, reff212_op in H. discriminate H. Qed.

Lemma reff212_not632 : ~ @Equation632 Fin4 reff212_inst.
Proof. unfold Equation632. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff212_inst, reff212_op in H. discriminate H. Qed.

Lemma reff212_not633 : ~ @Equation633 Fin4 reff212_inst.
Proof. unfold Equation633. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff212_inst, reff212_op in H. discriminate H. Qed.

Lemma reff212_not639 : ~ @Equation639 Fin4 reff212_inst.
Proof. unfold Equation639. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff212_inst, reff212_op in H. discriminate H. Qed.

Lemma reff212_not640 : ~ @Equation640 Fin4 reff212_inst.
Proof. unfold Equation640. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff212_inst, reff212_op in H. discriminate H. Qed.

Lemma reff212_not642 : ~ @Equation642 Fin4 reff212_inst.
Proof. unfold Equation642. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff212_inst, reff212_op in H. discriminate H. Qed.

Lemma reff212_not643 : ~ @Equation643 Fin4 reff212_inst.
Proof. unfold Equation643. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff212_inst, reff212_op in H. discriminate H. Qed.

Lemma reff212_not666 : ~ @Equation666 Fin4 reff212_inst.
Proof. unfold Equation666. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff212_inst, reff212_op in H. discriminate H. Qed.

Lemma reff212_not667 : ~ @Equation667 Fin4 reff212_inst.
Proof. unfold Equation667. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff212_inst, reff212_op in H. discriminate H. Qed.

Lemma reff212_not669 : ~ @Equation669 Fin4 reff212_inst.
Proof. unfold Equation669. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff212_inst, reff212_op in H. discriminate H. Qed.

Lemma reff212_not670 : ~ @Equation670 Fin4 reff212_inst.
Proof. unfold Equation670. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff212_inst, reff212_op in H. discriminate H. Qed.

Lemma reff212_not676 : ~ @Equation676 Fin4 reff212_inst.
Proof. unfold Equation676. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff212_inst, reff212_op in H. discriminate H. Qed.

Lemma reff212_not677 : ~ @Equation677 Fin4 reff212_inst.
Proof. unfold Equation677. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff212_inst, reff212_op in H. discriminate H. Qed.

Lemma reff212_not679 : ~ @Equation679 Fin4 reff212_inst.
Proof. unfold Equation679. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff212_inst, reff212_op in H. discriminate H. Qed.

Lemma reff212_not680 : ~ @Equation680 Fin4 reff212_inst.
Proof. unfold Equation680. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff212_inst, reff212_op in H. discriminate H. Qed.

Lemma reff212_not703 : ~ @Equation703 Fin4 reff212_inst.
Proof. unfold Equation703. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff212_inst, reff212_op in H. discriminate H. Qed.

Lemma reff212_not704 : ~ @Equation704 Fin4 reff212_inst.
Proof. unfold Equation704. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff212_inst, reff212_op in H. discriminate H. Qed.

Lemma reff212_not706 : ~ @Equation706 Fin4 reff212_inst.
Proof. unfold Equation706. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff212_inst, reff212_op in H. discriminate H. Qed.

Lemma reff212_not707 : ~ @Equation707 Fin4 reff212_inst.
Proof. unfold Equation707. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff212_inst, reff212_op in H. discriminate H. Qed.

Lemma reff212_not713 : ~ @Equation713 Fin4 reff212_inst.
Proof. unfold Equation713. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff212_inst, reff212_op in H. discriminate H. Qed.

Lemma reff212_not714 : ~ @Equation714 Fin4 reff212_inst.
Proof. unfold Equation714. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff212_inst, reff212_op in H. discriminate H. Qed.

Lemma reff212_not716 : ~ @Equation716 Fin4 reff212_inst.
Proof. unfold Equation716. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff212_inst, reff212_op in H. discriminate H. Qed.

Lemma reff212_not818 : ~ @Equation818 Fin4 reff212_inst.
Proof. unfold Equation818. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff212_inst, reff212_op in H. discriminate H. Qed.

Lemma reff212_not819 : ~ @Equation819 Fin4 reff212_inst.
Proof. unfold Equation819. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff212_inst, reff212_op in H. discriminate H. Qed.

Lemma reff212_not820 : ~ @Equation820 Fin4 reff212_inst.
Proof. unfold Equation820. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff212_inst, reff212_op in H. discriminate H. Qed.

Lemma reff212_not822 : ~ @Equation822 Fin4 reff212_inst.
Proof. unfold Equation822. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff212_inst, reff212_op in H. discriminate H. Qed.

Lemma reff212_not823 : ~ @Equation823 Fin4 reff212_inst.
Proof. unfold Equation823. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff212_inst, reff212_op in H. discriminate H. Qed.

Lemma reff212_not825 : ~ @Equation825 Fin4 reff212_inst.
Proof. unfold Equation825. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff212_inst, reff212_op in H. discriminate H. Qed.

Lemma reff212_not826 : ~ @Equation826 Fin4 reff212_inst.
Proof. unfold Equation826. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff212_inst, reff212_op in H. discriminate H. Qed.

Lemma reff212_not832 : ~ @Equation832 Fin4 reff212_inst.
Proof. unfold Equation832. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff212_inst, reff212_op in H. discriminate H. Qed.

Lemma reff212_not833 : ~ @Equation833 Fin4 reff212_inst.
Proof. unfold Equation833. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff212_inst, reff212_op in H. discriminate H. Qed.

Lemma reff212_not835 : ~ @Equation835 Fin4 reff212_inst.
Proof. unfold Equation835. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff212_inst, reff212_op in H. discriminate H. Qed.

Lemma reff212_not836 : ~ @Equation836 Fin4 reff212_inst.
Proof. unfold Equation836. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff212_inst, reff212_op in H. discriminate H. Qed.

Lemma reff212_not842 : ~ @Equation842 Fin4 reff212_inst.
Proof. unfold Equation842. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff212_inst, reff212_op in H. discriminate H. Qed.

Lemma reff212_not843 : ~ @Equation843 Fin4 reff212_inst.
Proof. unfold Equation843. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff212_inst, reff212_op in H. discriminate H. Qed.

Lemma reff212_not845 : ~ @Equation845 Fin4 reff212_inst.
Proof. unfold Equation845. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff212_inst, reff212_op in H. discriminate H. Qed.

Lemma reff212_not846 : ~ @Equation846 Fin4 reff212_inst.
Proof. unfold Equation846. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff212_inst, reff212_op in H. discriminate H. Qed.

Lemma reff212_not869 : ~ @Equation869 Fin4 reff212_inst.
Proof. unfold Equation869. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff212_inst, reff212_op in H. discriminate H. Qed.

Lemma reff212_not870 : ~ @Equation870 Fin4 reff212_inst.
Proof. unfold Equation870. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff212_inst, reff212_op in H. discriminate H. Qed.

Lemma reff212_not872 : ~ @Equation872 Fin4 reff212_inst.
Proof. unfold Equation872. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff212_inst, reff212_op in H. discriminate H. Qed.

Lemma reff212_not873 : ~ @Equation873 Fin4 reff212_inst.
Proof. unfold Equation873. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff212_inst, reff212_op in H. discriminate H. Qed.

Lemma reff212_not879 : ~ @Equation879 Fin4 reff212_inst.
Proof. unfold Equation879. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff212_inst, reff212_op in H. discriminate H. Qed.

Lemma reff212_not880 : ~ @Equation880 Fin4 reff212_inst.
Proof. unfold Equation880. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff212_inst, reff212_op in H. discriminate H. Qed.

Lemma reff212_not882 : ~ @Equation882 Fin4 reff212_inst.
Proof. unfold Equation882. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff212_inst, reff212_op in H. discriminate H. Qed.

Lemma reff212_not883 : ~ @Equation883 Fin4 reff212_inst.
Proof. unfold Equation883. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff212_inst, reff212_op in H. discriminate H. Qed.

Lemma reff212_not906 : ~ @Equation906 Fin4 reff212_inst.
Proof. unfold Equation906. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff212_inst, reff212_op in H. discriminate H. Qed.

Lemma reff212_not907 : ~ @Equation907 Fin4 reff212_inst.
Proof. unfold Equation907. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff212_inst, reff212_op in H. discriminate H. Qed.

Lemma reff212_not909 : ~ @Equation909 Fin4 reff212_inst.
Proof. unfold Equation909. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff212_inst, reff212_op in H. discriminate H. Qed.

Lemma reff212_not910 : ~ @Equation910 Fin4 reff212_inst.
Proof. unfold Equation910. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff212_inst, reff212_op in H. discriminate H. Qed.

Lemma reff212_not916 : ~ @Equation916 Fin4 reff212_inst.
Proof. unfold Equation916. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff212_inst, reff212_op in H. discriminate H. Qed.

Lemma reff212_not917 : ~ @Equation917 Fin4 reff212_inst.
Proof. unfold Equation917. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff212_inst, reff212_op in H. discriminate H. Qed.

Lemma reff212_not919 : ~ @Equation919 Fin4 reff212_inst.
Proof. unfold Equation919. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff212_inst, reff212_op in H. discriminate H. Qed.

Lemma reff212_not1021 : ~ @Equation1021 Fin4 reff212_inst.
Proof. unfold Equation1021. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff212_inst, reff212_op in H. discriminate H. Qed.

Lemma reff212_not1022 : ~ @Equation1022 Fin4 reff212_inst.
Proof. unfold Equation1022. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff212_inst, reff212_op in H. discriminate H. Qed.

Lemma reff212_not1023 : ~ @Equation1023 Fin4 reff212_inst.
Proof. unfold Equation1023. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff212_inst, reff212_op in H. discriminate H. Qed.

Lemma reff212_not1025 : ~ @Equation1025 Fin4 reff212_inst.
Proof. unfold Equation1025. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff212_inst, reff212_op in H. discriminate H. Qed.

Lemma reff212_not1026 : ~ @Equation1026 Fin4 reff212_inst.
Proof. unfold Equation1026. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff212_inst, reff212_op in H. discriminate H. Qed.

Lemma reff212_not1028 : ~ @Equation1028 Fin4 reff212_inst.
Proof. unfold Equation1028. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff212_inst, reff212_op in H. discriminate H. Qed.

Lemma reff212_not1029 : ~ @Equation1029 Fin4 reff212_inst.
Proof. unfold Equation1029. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff212_inst, reff212_op in H. discriminate H. Qed.

Lemma reff212_not1035 : ~ @Equation1035 Fin4 reff212_inst.
Proof. unfold Equation1035. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff212_inst, reff212_op in H. discriminate H. Qed.

Lemma reff212_not1036 : ~ @Equation1036 Fin4 reff212_inst.
Proof. unfold Equation1036. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff212_inst, reff212_op in H. discriminate H. Qed.

Lemma reff212_not1038 : ~ @Equation1038 Fin4 reff212_inst.
Proof. unfold Equation1038. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff212_inst, reff212_op in H. discriminate H. Qed.

Lemma reff212_not1039 : ~ @Equation1039 Fin4 reff212_inst.
Proof. unfold Equation1039. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff212_inst, reff212_op in H. discriminate H. Qed.

Lemma reff212_not1045 : ~ @Equation1045 Fin4 reff212_inst.
Proof. unfold Equation1045. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff212_inst, reff212_op in H. discriminate H. Qed.

Lemma reff212_not1046 : ~ @Equation1046 Fin4 reff212_inst.
Proof. unfold Equation1046. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff212_inst, reff212_op in H. discriminate H. Qed.

Lemma reff212_not1048 : ~ @Equation1048 Fin4 reff212_inst.
Proof. unfold Equation1048. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff212_inst, reff212_op in H. discriminate H. Qed.

Lemma reff212_not1049 : ~ @Equation1049 Fin4 reff212_inst.
Proof. unfold Equation1049. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff212_inst, reff212_op in H. discriminate H. Qed.

Lemma reff212_not1072 : ~ @Equation1072 Fin4 reff212_inst.
Proof. unfold Equation1072. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff212_inst, reff212_op in H. discriminate H. Qed.

Lemma reff212_not1073 : ~ @Equation1073 Fin4 reff212_inst.
Proof. unfold Equation1073. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff212_inst, reff212_op in H. discriminate H. Qed.

Lemma reff212_not1075 : ~ @Equation1075 Fin4 reff212_inst.
Proof. unfold Equation1075. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff212_inst, reff212_op in H. discriminate H. Qed.

Lemma reff212_not1076 : ~ @Equation1076 Fin4 reff212_inst.
Proof. unfold Equation1076. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff212_inst, reff212_op in H. discriminate H. Qed.

Lemma reff212_not1082 : ~ @Equation1082 Fin4 reff212_inst.
Proof. unfold Equation1082. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff212_inst, reff212_op in H. discriminate H. Qed.

Lemma reff212_not1083 : ~ @Equation1083 Fin4 reff212_inst.
Proof. unfold Equation1083. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff212_inst, reff212_op in H. discriminate H. Qed.

Lemma reff212_not1085 : ~ @Equation1085 Fin4 reff212_inst.
Proof. unfold Equation1085. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff212_inst, reff212_op in H. discriminate H. Qed.

Lemma reff212_not1086 : ~ @Equation1086 Fin4 reff212_inst.
Proof. unfold Equation1086. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff212_inst, reff212_op in H. discriminate H. Qed.

Lemma reff212_not1109 : ~ @Equation1109 Fin4 reff212_inst.
Proof. unfold Equation1109. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff212_inst, reff212_op in H. discriminate H. Qed.

Lemma reff212_not1110 : ~ @Equation1110 Fin4 reff212_inst.
Proof. unfold Equation1110. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff212_inst, reff212_op in H. discriminate H. Qed.

Lemma reff212_not1112 : ~ @Equation1112 Fin4 reff212_inst.
Proof. unfold Equation1112. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff212_inst, reff212_op in H. discriminate H. Qed.

Lemma reff212_not1113 : ~ @Equation1113 Fin4 reff212_inst.
Proof. unfold Equation1113. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff212_inst, reff212_op in H. discriminate H. Qed.

Lemma reff212_not1119 : ~ @Equation1119 Fin4 reff212_inst.
Proof. unfold Equation1119. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff212_inst, reff212_op in H. discriminate H. Qed.

Lemma reff212_not1120 : ~ @Equation1120 Fin4 reff212_inst.
Proof. unfold Equation1120. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff212_inst, reff212_op in H. discriminate H. Qed.

Lemma reff212_not1122 : ~ @Equation1122 Fin4 reff212_inst.
Proof. unfold Equation1122. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff212_inst, reff212_op in H. discriminate H. Qed.

Lemma reff212_not1224 : ~ @Equation1224 Fin4 reff212_inst.
Proof. unfold Equation1224. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff212_inst, reff212_op in H. discriminate H. Qed.

Lemma reff212_not1225 : ~ @Equation1225 Fin4 reff212_inst.
Proof. unfold Equation1225. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff212_inst, reff212_op in H. discriminate H. Qed.

Lemma reff212_not1226 : ~ @Equation1226 Fin4 reff212_inst.
Proof. unfold Equation1226. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff212_inst, reff212_op in H. discriminate H. Qed.

Lemma reff212_not1228 : ~ @Equation1228 Fin4 reff212_inst.
Proof. unfold Equation1228. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff212_inst, reff212_op in H. discriminate H. Qed.

Lemma reff212_not1229 : ~ @Equation1229 Fin4 reff212_inst.
Proof. unfold Equation1229. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff212_inst, reff212_op in H. discriminate H. Qed.

Lemma reff212_not1231 : ~ @Equation1231 Fin4 reff212_inst.
Proof. unfold Equation1231. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff212_inst, reff212_op in H. discriminate H. Qed.

Lemma reff212_not1232 : ~ @Equation1232 Fin4 reff212_inst.
Proof. unfold Equation1232. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff212_inst, reff212_op in H. discriminate H. Qed.

Lemma reff212_not1238 : ~ @Equation1238 Fin4 reff212_inst.
Proof. unfold Equation1238. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff212_inst, reff212_op in H. discriminate H. Qed.

Lemma reff212_not1239 : ~ @Equation1239 Fin4 reff212_inst.
Proof. unfold Equation1239. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff212_inst, reff212_op in H. discriminate H. Qed.

Lemma reff212_not1241 : ~ @Equation1241 Fin4 reff212_inst.
Proof. unfold Equation1241. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff212_inst, reff212_op in H. discriminate H. Qed.

Lemma reff212_not1242 : ~ @Equation1242 Fin4 reff212_inst.
Proof. unfold Equation1242. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff212_inst, reff212_op in H. discriminate H. Qed.

Lemma reff212_not1248 : ~ @Equation1248 Fin4 reff212_inst.
Proof. unfold Equation1248. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff212_inst, reff212_op in H. discriminate H. Qed.

Lemma reff212_not1249 : ~ @Equation1249 Fin4 reff212_inst.
Proof. unfold Equation1249. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff212_inst, reff212_op in H. discriminate H. Qed.

Lemma reff212_not1251 : ~ @Equation1251 Fin4 reff212_inst.
Proof. unfold Equation1251. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff212_inst, reff212_op in H. discriminate H. Qed.

Lemma reff212_not1252 : ~ @Equation1252 Fin4 reff212_inst.
Proof. unfold Equation1252. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff212_inst, reff212_op in H. discriminate H. Qed.

Lemma reff212_not1275 : ~ @Equation1275 Fin4 reff212_inst.
Proof. unfold Equation1275. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff212_inst, reff212_op in H. discriminate H. Qed.

Lemma reff212_not1276 : ~ @Equation1276 Fin4 reff212_inst.
Proof. unfold Equation1276. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff212_inst, reff212_op in H. discriminate H. Qed.

Lemma reff212_not1278 : ~ @Equation1278 Fin4 reff212_inst.
Proof. unfold Equation1278. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff212_inst, reff212_op in H. discriminate H. Qed.

Lemma reff212_not1279 : ~ @Equation1279 Fin4 reff212_inst.
Proof. unfold Equation1279. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff212_inst, reff212_op in H. discriminate H. Qed.

Lemma reff212_not1285 : ~ @Equation1285 Fin4 reff212_inst.
Proof. unfold Equation1285. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff212_inst, reff212_op in H. discriminate H. Qed.

Lemma reff212_not1286 : ~ @Equation1286 Fin4 reff212_inst.
Proof. unfold Equation1286. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff212_inst, reff212_op in H. discriminate H. Qed.

Lemma reff212_not1288 : ~ @Equation1288 Fin4 reff212_inst.
Proof. unfold Equation1288. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff212_inst, reff212_op in H. discriminate H. Qed.

Lemma reff212_not1289 : ~ @Equation1289 Fin4 reff212_inst.
Proof. unfold Equation1289. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff212_inst, reff212_op in H. discriminate H. Qed.

Lemma reff212_not1312 : ~ @Equation1312 Fin4 reff212_inst.
Proof. unfold Equation1312. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff212_inst, reff212_op in H. discriminate H. Qed.

Lemma reff212_not1313 : ~ @Equation1313 Fin4 reff212_inst.
Proof. unfold Equation1313. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff212_inst, reff212_op in H. discriminate H. Qed.

Lemma reff212_not1315 : ~ @Equation1315 Fin4 reff212_inst.
Proof. unfold Equation1315. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff212_inst, reff212_op in H. discriminate H. Qed.

Lemma reff212_not1316 : ~ @Equation1316 Fin4 reff212_inst.
Proof. unfold Equation1316. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff212_inst, reff212_op in H. discriminate H. Qed.

Lemma reff212_not1322 : ~ @Equation1322 Fin4 reff212_inst.
Proof. unfold Equation1322. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff212_inst, reff212_op in H. discriminate H. Qed.

Lemma reff212_not1323 : ~ @Equation1323 Fin4 reff212_inst.
Proof. unfold Equation1323. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff212_inst, reff212_op in H. discriminate H. Qed.

Lemma reff212_not1325 : ~ @Equation1325 Fin4 reff212_inst.
Proof. unfold Equation1325. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff212_inst, reff212_op in H. discriminate H. Qed.

Lemma reff212_not1427 : ~ @Equation1427 Fin4 reff212_inst.
Proof. unfold Equation1427. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff212_inst, reff212_op in H. discriminate H. Qed.

Lemma reff212_not1428 : ~ @Equation1428 Fin4 reff212_inst.
Proof. unfold Equation1428. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff212_inst, reff212_op in H. discriminate H. Qed.

Lemma reff212_not1429 : ~ @Equation1429 Fin4 reff212_inst.
Proof. unfold Equation1429. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff212_inst, reff212_op in H. discriminate H. Qed.

Lemma reff212_not1431 : ~ @Equation1431 Fin4 reff212_inst.
Proof. unfold Equation1431. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff212_inst, reff212_op in H. discriminate H. Qed.

Lemma reff212_not1432 : ~ @Equation1432 Fin4 reff212_inst.
Proof. unfold Equation1432. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff212_inst, reff212_op in H. discriminate H. Qed.

Lemma reff212_not1434 : ~ @Equation1434 Fin4 reff212_inst.
Proof. unfold Equation1434. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff212_inst, reff212_op in H. discriminate H. Qed.

Lemma reff212_not1435 : ~ @Equation1435 Fin4 reff212_inst.
Proof. unfold Equation1435. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff212_inst, reff212_op in H. discriminate H. Qed.

Lemma reff212_not1441 : ~ @Equation1441 Fin4 reff212_inst.
Proof. unfold Equation1441. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff212_inst, reff212_op in H. discriminate H. Qed.

Lemma reff212_not1442 : ~ @Equation1442 Fin4 reff212_inst.
Proof. unfold Equation1442. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff212_inst, reff212_op in H. discriminate H. Qed.

Lemma reff212_not1444 : ~ @Equation1444 Fin4 reff212_inst.
Proof. unfold Equation1444. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff212_inst, reff212_op in H. discriminate H. Qed.

Lemma reff212_not1445 : ~ @Equation1445 Fin4 reff212_inst.
Proof. unfold Equation1445. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff212_inst, reff212_op in H. discriminate H. Qed.

Lemma reff212_not1451 : ~ @Equation1451 Fin4 reff212_inst.
Proof. unfold Equation1451. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff212_inst, reff212_op in H. discriminate H. Qed.

Lemma reff212_not1452 : ~ @Equation1452 Fin4 reff212_inst.
Proof. unfold Equation1452. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff212_inst, reff212_op in H. discriminate H. Qed.

Lemma reff212_not1454 : ~ @Equation1454 Fin4 reff212_inst.
Proof. unfold Equation1454. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff212_inst, reff212_op in H. discriminate H. Qed.

Lemma reff212_not1455 : ~ @Equation1455 Fin4 reff212_inst.
Proof. unfold Equation1455. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff212_inst, reff212_op in H. discriminate H. Qed.

Lemma reff212_not1478 : ~ @Equation1478 Fin4 reff212_inst.
Proof. unfold Equation1478. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff212_inst, reff212_op in H. discriminate H. Qed.

Lemma reff212_not1479 : ~ @Equation1479 Fin4 reff212_inst.
Proof. unfold Equation1479. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff212_inst, reff212_op in H. discriminate H. Qed.

Lemma reff212_not1481 : ~ @Equation1481 Fin4 reff212_inst.
Proof. unfold Equation1481. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff212_inst, reff212_op in H. discriminate H. Qed.

Lemma reff212_not1482 : ~ @Equation1482 Fin4 reff212_inst.
Proof. unfold Equation1482. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff212_inst, reff212_op in H. discriminate H. Qed.

Lemma reff212_not1488 : ~ @Equation1488 Fin4 reff212_inst.
Proof. unfold Equation1488. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff212_inst, reff212_op in H. discriminate H. Qed.

Lemma reff212_not1489 : ~ @Equation1489 Fin4 reff212_inst.
Proof. unfold Equation1489. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff212_inst, reff212_op in H. discriminate H. Qed.

Lemma reff212_not1491 : ~ @Equation1491 Fin4 reff212_inst.
Proof. unfold Equation1491. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff212_inst, reff212_op in H. discriminate H. Qed.

Lemma reff212_not1492 : ~ @Equation1492 Fin4 reff212_inst.
Proof. unfold Equation1492. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff212_inst, reff212_op in H. discriminate H. Qed.

Lemma reff212_not1515 : ~ @Equation1515 Fin4 reff212_inst.
Proof. unfold Equation1515. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff212_inst, reff212_op in H. discriminate H. Qed.

Lemma reff212_not1516 : ~ @Equation1516 Fin4 reff212_inst.
Proof. unfold Equation1516. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff212_inst, reff212_op in H. discriminate H. Qed.

Lemma reff212_not1518 : ~ @Equation1518 Fin4 reff212_inst.
Proof. unfold Equation1518. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff212_inst, reff212_op in H. discriminate H. Qed.

Lemma reff212_not1519 : ~ @Equation1519 Fin4 reff212_inst.
Proof. unfold Equation1519. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff212_inst, reff212_op in H. discriminate H. Qed.

Lemma reff212_not1525 : ~ @Equation1525 Fin4 reff212_inst.
Proof. unfold Equation1525. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff212_inst, reff212_op in H. discriminate H. Qed.

Lemma reff212_not1526 : ~ @Equation1526 Fin4 reff212_inst.
Proof. unfold Equation1526. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff212_inst, reff212_op in H. discriminate H. Qed.

Lemma reff212_not1528 : ~ @Equation1528 Fin4 reff212_inst.
Proof. unfold Equation1528. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff212_inst, reff212_op in H. discriminate H. Qed.

Lemma reff212_not1630 : ~ @Equation1630 Fin4 reff212_inst.
Proof. unfold Equation1630. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff212_inst, reff212_op in H. discriminate H. Qed.

Lemma reff212_not1631 : ~ @Equation1631 Fin4 reff212_inst.
Proof. unfold Equation1631. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff212_inst, reff212_op in H. discriminate H. Qed.

Lemma reff212_not1632 : ~ @Equation1632 Fin4 reff212_inst.
Proof. unfold Equation1632. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff212_inst, reff212_op in H. discriminate H. Qed.

Lemma reff212_not1634 : ~ @Equation1634 Fin4 reff212_inst.
Proof. unfold Equation1634. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff212_inst, reff212_op in H. discriminate H. Qed.

Lemma reff212_not1635 : ~ @Equation1635 Fin4 reff212_inst.
Proof. unfold Equation1635. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff212_inst, reff212_op in H. discriminate H. Qed.

Lemma reff212_not1637 : ~ @Equation1637 Fin4 reff212_inst.
Proof. unfold Equation1637. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff212_inst, reff212_op in H. discriminate H. Qed.

Lemma reff212_not1638 : ~ @Equation1638 Fin4 reff212_inst.
Proof. unfold Equation1638. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff212_inst, reff212_op in H. discriminate H. Qed.

Lemma reff212_not1644 : ~ @Equation1644 Fin4 reff212_inst.
Proof. unfold Equation1644. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff212_inst, reff212_op in H. discriminate H. Qed.

Lemma reff212_not1645 : ~ @Equation1645 Fin4 reff212_inst.
Proof. unfold Equation1645. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff212_inst, reff212_op in H. discriminate H. Qed.

Lemma reff212_not1647 : ~ @Equation1647 Fin4 reff212_inst.
Proof. unfold Equation1647. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff212_inst, reff212_op in H. discriminate H. Qed.

Lemma reff212_not1648 : ~ @Equation1648 Fin4 reff212_inst.
Proof. unfold Equation1648. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff212_inst, reff212_op in H. discriminate H. Qed.

Lemma reff212_not1654 : ~ @Equation1654 Fin4 reff212_inst.
Proof. unfold Equation1654. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff212_inst, reff212_op in H. discriminate H. Qed.

Lemma reff212_not1655 : ~ @Equation1655 Fin4 reff212_inst.
Proof. unfold Equation1655. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff212_inst, reff212_op in H. discriminate H. Qed.

Lemma reff212_not1657 : ~ @Equation1657 Fin4 reff212_inst.
Proof. unfold Equation1657. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff212_inst, reff212_op in H. discriminate H. Qed.

Lemma reff212_not1658 : ~ @Equation1658 Fin4 reff212_inst.
Proof. unfold Equation1658. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff212_inst, reff212_op in H. discriminate H. Qed.

Lemma reff212_not1681 : ~ @Equation1681 Fin4 reff212_inst.
Proof. unfold Equation1681. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff212_inst, reff212_op in H. discriminate H. Qed.

Lemma reff212_not1682 : ~ @Equation1682 Fin4 reff212_inst.
Proof. unfold Equation1682. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff212_inst, reff212_op in H. discriminate H. Qed.

Lemma reff212_not1684 : ~ @Equation1684 Fin4 reff212_inst.
Proof. unfold Equation1684. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff212_inst, reff212_op in H. discriminate H. Qed.

Lemma reff212_not1685 : ~ @Equation1685 Fin4 reff212_inst.
Proof. unfold Equation1685. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff212_inst, reff212_op in H. discriminate H. Qed.

Lemma reff212_not1691 : ~ @Equation1691 Fin4 reff212_inst.
Proof. unfold Equation1691. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff212_inst, reff212_op in H. discriminate H. Qed.

Lemma reff212_not1692 : ~ @Equation1692 Fin4 reff212_inst.
Proof. unfold Equation1692. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff212_inst, reff212_op in H. discriminate H. Qed.

Lemma reff212_not1694 : ~ @Equation1694 Fin4 reff212_inst.
Proof. unfold Equation1694. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff212_inst, reff212_op in H. discriminate H. Qed.

Lemma reff212_not1695 : ~ @Equation1695 Fin4 reff212_inst.
Proof. unfold Equation1695. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff212_inst, reff212_op in H. discriminate H. Qed.

Lemma reff212_not1718 : ~ @Equation1718 Fin4 reff212_inst.
Proof. unfold Equation1718. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff212_inst, reff212_op in H. discriminate H. Qed.

Lemma reff212_not1719 : ~ @Equation1719 Fin4 reff212_inst.
Proof. unfold Equation1719. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff212_inst, reff212_op in H. discriminate H. Qed.

Lemma reff212_not1721 : ~ @Equation1721 Fin4 reff212_inst.
Proof. unfold Equation1721. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff212_inst, reff212_op in H. discriminate H. Qed.

Lemma reff212_not1722 : ~ @Equation1722 Fin4 reff212_inst.
Proof. unfold Equation1722. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff212_inst, reff212_op in H. discriminate H. Qed.

Lemma reff212_not1728 : ~ @Equation1728 Fin4 reff212_inst.
Proof. unfold Equation1728. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff212_inst, reff212_op in H. discriminate H. Qed.

Lemma reff212_not1729 : ~ @Equation1729 Fin4 reff212_inst.
Proof. unfold Equation1729. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff212_inst, reff212_op in H. discriminate H. Qed.

Lemma reff212_not1731 : ~ @Equation1731 Fin4 reff212_inst.
Proof. unfold Equation1731. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff212_inst, reff212_op in H. discriminate H. Qed.

Lemma reff212_not1833 : ~ @Equation1833 Fin4 reff212_inst.
Proof. unfold Equation1833. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff212_inst, reff212_op in H. discriminate H. Qed.

Lemma reff212_not1834 : ~ @Equation1834 Fin4 reff212_inst.
Proof. unfold Equation1834. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff212_inst, reff212_op in H. discriminate H. Qed.

Lemma reff212_not1835 : ~ @Equation1835 Fin4 reff212_inst.
Proof. unfold Equation1835. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff212_inst, reff212_op in H. discriminate H. Qed.

Lemma reff212_not1837 : ~ @Equation1837 Fin4 reff212_inst.
Proof. unfold Equation1837. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff212_inst, reff212_op in H. discriminate H. Qed.

Lemma reff212_not1838 : ~ @Equation1838 Fin4 reff212_inst.
Proof. unfold Equation1838. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff212_inst, reff212_op in H. discriminate H. Qed.

Lemma reff212_not1840 : ~ @Equation1840 Fin4 reff212_inst.
Proof. unfold Equation1840. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff212_inst, reff212_op in H. discriminate H. Qed.

Lemma reff212_not1841 : ~ @Equation1841 Fin4 reff212_inst.
Proof. unfold Equation1841. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff212_inst, reff212_op in H. discriminate H. Qed.

Lemma reff212_not1847 : ~ @Equation1847 Fin4 reff212_inst.
Proof. unfold Equation1847. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff212_inst, reff212_op in H. discriminate H. Qed.

Lemma reff212_not1848 : ~ @Equation1848 Fin4 reff212_inst.
Proof. unfold Equation1848. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff212_inst, reff212_op in H. discriminate H. Qed.

Lemma reff212_not1850 : ~ @Equation1850 Fin4 reff212_inst.
Proof. unfold Equation1850. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff212_inst, reff212_op in H. discriminate H. Qed.

Lemma reff212_not1851 : ~ @Equation1851 Fin4 reff212_inst.
Proof. unfold Equation1851. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff212_inst, reff212_op in H. discriminate H. Qed.

Lemma reff212_not1857 : ~ @Equation1857 Fin4 reff212_inst.
Proof. unfold Equation1857. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff212_inst, reff212_op in H. discriminate H. Qed.

Lemma reff212_not1858 : ~ @Equation1858 Fin4 reff212_inst.
Proof. unfold Equation1858. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff212_inst, reff212_op in H. discriminate H. Qed.

Lemma reff212_not1860 : ~ @Equation1860 Fin4 reff212_inst.
Proof. unfold Equation1860. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff212_inst, reff212_op in H. discriminate H. Qed.

Lemma reff212_not1861 : ~ @Equation1861 Fin4 reff212_inst.
Proof. unfold Equation1861. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff212_inst, reff212_op in H. discriminate H. Qed.

Lemma reff212_not1884 : ~ @Equation1884 Fin4 reff212_inst.
Proof. unfold Equation1884. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff212_inst, reff212_op in H. discriminate H. Qed.

Lemma reff212_not1885 : ~ @Equation1885 Fin4 reff212_inst.
Proof. unfold Equation1885. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff212_inst, reff212_op in H. discriminate H. Qed.

Lemma reff212_not1887 : ~ @Equation1887 Fin4 reff212_inst.
Proof. unfold Equation1887. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff212_inst, reff212_op in H. discriminate H. Qed.

Lemma reff212_not1888 : ~ @Equation1888 Fin4 reff212_inst.
Proof. unfold Equation1888. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff212_inst, reff212_op in H. discriminate H. Qed.

Lemma reff212_not1894 : ~ @Equation1894 Fin4 reff212_inst.
Proof. unfold Equation1894. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff212_inst, reff212_op in H. discriminate H. Qed.

Lemma reff212_not1895 : ~ @Equation1895 Fin4 reff212_inst.
Proof. unfold Equation1895. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff212_inst, reff212_op in H. discriminate H. Qed.

Lemma reff212_not1897 : ~ @Equation1897 Fin4 reff212_inst.
Proof. unfold Equation1897. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff212_inst, reff212_op in H. discriminate H. Qed.

Lemma reff212_not1898 : ~ @Equation1898 Fin4 reff212_inst.
Proof. unfold Equation1898. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff212_inst, reff212_op in H. discriminate H. Qed.

Lemma reff212_not1921 : ~ @Equation1921 Fin4 reff212_inst.
Proof. unfold Equation1921. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff212_inst, reff212_op in H. discriminate H. Qed.

Lemma reff212_not1922 : ~ @Equation1922 Fin4 reff212_inst.
Proof. unfold Equation1922. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff212_inst, reff212_op in H. discriminate H. Qed.

Lemma reff212_not1924 : ~ @Equation1924 Fin4 reff212_inst.
Proof. unfold Equation1924. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff212_inst, reff212_op in H. discriminate H. Qed.

Lemma reff212_not1925 : ~ @Equation1925 Fin4 reff212_inst.
Proof. unfold Equation1925. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff212_inst, reff212_op in H. discriminate H. Qed.

Lemma reff212_not1931 : ~ @Equation1931 Fin4 reff212_inst.
Proof. unfold Equation1931. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff212_inst, reff212_op in H. discriminate H. Qed.

Lemma reff212_not1932 : ~ @Equation1932 Fin4 reff212_inst.
Proof. unfold Equation1932. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff212_inst, reff212_op in H. discriminate H. Qed.

Lemma reff212_not1934 : ~ @Equation1934 Fin4 reff212_inst.
Proof. unfold Equation1934. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff212_inst, reff212_op in H. discriminate H. Qed.

Lemma reff212_not2036 : ~ @Equation2036 Fin4 reff212_inst.
Proof. unfold Equation2036. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff212_inst, reff212_op in H. discriminate H. Qed.

Lemma reff212_not2037 : ~ @Equation2037 Fin4 reff212_inst.
Proof. unfold Equation2037. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff212_inst, reff212_op in H. discriminate H. Qed.

Lemma reff212_not2038 : ~ @Equation2038 Fin4 reff212_inst.
Proof. unfold Equation2038. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff212_inst, reff212_op in H. discriminate H. Qed.

Lemma reff212_not2040 : ~ @Equation2040 Fin4 reff212_inst.
Proof. unfold Equation2040. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff212_inst, reff212_op in H. discriminate H. Qed.

Lemma reff212_not2041 : ~ @Equation2041 Fin4 reff212_inst.
Proof. unfold Equation2041. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff212_inst, reff212_op in H. discriminate H. Qed.

Lemma reff212_not2043 : ~ @Equation2043 Fin4 reff212_inst.
Proof. unfold Equation2043. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff212_inst, reff212_op in H. discriminate H. Qed.

Lemma reff212_not2044 : ~ @Equation2044 Fin4 reff212_inst.
Proof. unfold Equation2044. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff212_inst, reff212_op in H. discriminate H. Qed.

Lemma reff212_not2050 : ~ @Equation2050 Fin4 reff212_inst.
Proof. unfold Equation2050. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff212_inst, reff212_op in H. discriminate H. Qed.

Lemma reff212_not2051 : ~ @Equation2051 Fin4 reff212_inst.
Proof. unfold Equation2051. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff212_inst, reff212_op in H. discriminate H. Qed.

Lemma reff212_not2053 : ~ @Equation2053 Fin4 reff212_inst.
Proof. unfold Equation2053. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff212_inst, reff212_op in H. discriminate H. Qed.

Lemma reff212_not2054 : ~ @Equation2054 Fin4 reff212_inst.
Proof. unfold Equation2054. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff212_inst, reff212_op in H. discriminate H. Qed.

Lemma reff212_not2060 : ~ @Equation2060 Fin4 reff212_inst.
Proof. unfold Equation2060. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff212_inst, reff212_op in H. discriminate H. Qed.

Lemma reff212_not2061 : ~ @Equation2061 Fin4 reff212_inst.
Proof. unfold Equation2061. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff212_inst, reff212_op in H. discriminate H. Qed.

Lemma reff212_not2063 : ~ @Equation2063 Fin4 reff212_inst.
Proof. unfold Equation2063. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff212_inst, reff212_op in H. discriminate H. Qed.

Lemma reff212_not2064 : ~ @Equation2064 Fin4 reff212_inst.
Proof. unfold Equation2064. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff212_inst, reff212_op in H. discriminate H. Qed.

Lemma reff212_not2087 : ~ @Equation2087 Fin4 reff212_inst.
Proof. unfold Equation2087. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff212_inst, reff212_op in H. discriminate H. Qed.

Lemma reff212_not2088 : ~ @Equation2088 Fin4 reff212_inst.
Proof. unfold Equation2088. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff212_inst, reff212_op in H. discriminate H. Qed.

Lemma reff212_not2090 : ~ @Equation2090 Fin4 reff212_inst.
Proof. unfold Equation2090. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff212_inst, reff212_op in H. discriminate H. Qed.

Lemma reff212_not2091 : ~ @Equation2091 Fin4 reff212_inst.
Proof. unfold Equation2091. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff212_inst, reff212_op in H. discriminate H. Qed.

Lemma reff212_not2097 : ~ @Equation2097 Fin4 reff212_inst.
Proof. unfold Equation2097. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff212_inst, reff212_op in H. discriminate H. Qed.

Lemma reff212_not2098 : ~ @Equation2098 Fin4 reff212_inst.
Proof. unfold Equation2098. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff212_inst, reff212_op in H. discriminate H. Qed.

Lemma reff212_not2100 : ~ @Equation2100 Fin4 reff212_inst.
Proof. unfold Equation2100. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff212_inst, reff212_op in H. discriminate H. Qed.

Lemma reff212_not2101 : ~ @Equation2101 Fin4 reff212_inst.
Proof. unfold Equation2101. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff212_inst, reff212_op in H. discriminate H. Qed.

Lemma reff212_not2124 : ~ @Equation2124 Fin4 reff212_inst.
Proof. unfold Equation2124. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff212_inst, reff212_op in H. discriminate H. Qed.

Lemma reff212_not2125 : ~ @Equation2125 Fin4 reff212_inst.
Proof. unfold Equation2125. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff212_inst, reff212_op in H. discriminate H. Qed.

Lemma reff212_not2127 : ~ @Equation2127 Fin4 reff212_inst.
Proof. unfold Equation2127. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff212_inst, reff212_op in H. discriminate H. Qed.

Lemma reff212_not2128 : ~ @Equation2128 Fin4 reff212_inst.
Proof. unfold Equation2128. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff212_inst, reff212_op in H. discriminate H. Qed.

Lemma reff212_not2134 : ~ @Equation2134 Fin4 reff212_inst.
Proof. unfold Equation2134. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff212_inst, reff212_op in H. discriminate H. Qed.

Lemma reff212_not2135 : ~ @Equation2135 Fin4 reff212_inst.
Proof. unfold Equation2135. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff212_inst, reff212_op in H. discriminate H. Qed.

Lemma reff212_not2137 : ~ @Equation2137 Fin4 reff212_inst.
Proof. unfold Equation2137. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff212_inst, reff212_op in H. discriminate H. Qed.

Lemma reff212_not2239 : ~ @Equation2239 Fin4 reff212_inst.
Proof. unfold Equation2239. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff212_inst, reff212_op in H. discriminate H. Qed.

Lemma reff212_not2240 : ~ @Equation2240 Fin4 reff212_inst.
Proof. unfold Equation2240. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff212_inst, reff212_op in H. discriminate H. Qed.

Lemma reff212_not2241 : ~ @Equation2241 Fin4 reff212_inst.
Proof. unfold Equation2241. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff212_inst, reff212_op in H. discriminate H. Qed.

Lemma reff212_not2243 : ~ @Equation2243 Fin4 reff212_inst.
Proof. unfold Equation2243. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff212_inst, reff212_op in H. discriminate H. Qed.

Lemma reff212_not2244 : ~ @Equation2244 Fin4 reff212_inst.
Proof. unfold Equation2244. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff212_inst, reff212_op in H. discriminate H. Qed.

Lemma reff212_not2246 : ~ @Equation2246 Fin4 reff212_inst.
Proof. unfold Equation2246. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff212_inst, reff212_op in H. discriminate H. Qed.

Lemma reff212_not2247 : ~ @Equation2247 Fin4 reff212_inst.
Proof. unfold Equation2247. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff212_inst, reff212_op in H. discriminate H. Qed.

Lemma reff212_not2253 : ~ @Equation2253 Fin4 reff212_inst.
Proof. unfold Equation2253. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff212_inst, reff212_op in H. discriminate H. Qed.

Lemma reff212_not2254 : ~ @Equation2254 Fin4 reff212_inst.
Proof. unfold Equation2254. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff212_inst, reff212_op in H. discriminate H. Qed.

Lemma reff212_not2256 : ~ @Equation2256 Fin4 reff212_inst.
Proof. unfold Equation2256. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff212_inst, reff212_op in H. discriminate H. Qed.

Lemma reff212_not2257 : ~ @Equation2257 Fin4 reff212_inst.
Proof. unfold Equation2257. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff212_inst, reff212_op in H. discriminate H. Qed.

Lemma reff212_not2263 : ~ @Equation2263 Fin4 reff212_inst.
Proof. unfold Equation2263. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff212_inst, reff212_op in H. discriminate H. Qed.

Lemma reff212_not2264 : ~ @Equation2264 Fin4 reff212_inst.
Proof. unfold Equation2264. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff212_inst, reff212_op in H. discriminate H. Qed.

Lemma reff212_not2266 : ~ @Equation2266 Fin4 reff212_inst.
Proof. unfold Equation2266. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff212_inst, reff212_op in H. discriminate H. Qed.

Lemma reff212_not2267 : ~ @Equation2267 Fin4 reff212_inst.
Proof. unfold Equation2267. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff212_inst, reff212_op in H. discriminate H. Qed.

Lemma reff212_not2290 : ~ @Equation2290 Fin4 reff212_inst.
Proof. unfold Equation2290. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff212_inst, reff212_op in H. discriminate H. Qed.

Lemma reff212_not2291 : ~ @Equation2291 Fin4 reff212_inst.
Proof. unfold Equation2291. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff212_inst, reff212_op in H. discriminate H. Qed.

Lemma reff212_not2293 : ~ @Equation2293 Fin4 reff212_inst.
Proof. unfold Equation2293. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff212_inst, reff212_op in H. discriminate H. Qed.

Lemma reff212_not2294 : ~ @Equation2294 Fin4 reff212_inst.
Proof. unfold Equation2294. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff212_inst, reff212_op in H. discriminate H. Qed.

Lemma reff212_not2300 : ~ @Equation2300 Fin4 reff212_inst.
Proof. unfold Equation2300. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff212_inst, reff212_op in H. discriminate H. Qed.

Lemma reff212_not2301 : ~ @Equation2301 Fin4 reff212_inst.
Proof. unfold Equation2301. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff212_inst, reff212_op in H. discriminate H. Qed.

Lemma reff212_not2303 : ~ @Equation2303 Fin4 reff212_inst.
Proof. unfold Equation2303. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff212_inst, reff212_op in H. discriminate H. Qed.

Lemma reff212_not2304 : ~ @Equation2304 Fin4 reff212_inst.
Proof. unfold Equation2304. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff212_inst, reff212_op in H. discriminate H. Qed.

Lemma reff212_not2327 : ~ @Equation2327 Fin4 reff212_inst.
Proof. unfold Equation2327. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff212_inst, reff212_op in H. discriminate H. Qed.

Lemma reff212_not2328 : ~ @Equation2328 Fin4 reff212_inst.
Proof. unfold Equation2328. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff212_inst, reff212_op in H. discriminate H. Qed.

Lemma reff212_not2330 : ~ @Equation2330 Fin4 reff212_inst.
Proof. unfold Equation2330. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff212_inst, reff212_op in H. discriminate H. Qed.

Lemma reff212_not2331 : ~ @Equation2331 Fin4 reff212_inst.
Proof. unfold Equation2331. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff212_inst, reff212_op in H. discriminate H. Qed.

Lemma reff212_not2337 : ~ @Equation2337 Fin4 reff212_inst.
Proof. unfold Equation2337. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff212_inst, reff212_op in H. discriminate H. Qed.

Lemma reff212_not2338 : ~ @Equation2338 Fin4 reff212_inst.
Proof. unfold Equation2338. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff212_inst, reff212_op in H. discriminate H. Qed.

Lemma reff212_not2340 : ~ @Equation2340 Fin4 reff212_inst.
Proof. unfold Equation2340. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff212_inst, reff212_op in H. discriminate H. Qed.

Lemma reff212_not2442 : ~ @Equation2442 Fin4 reff212_inst.
Proof. unfold Equation2442. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff212_inst, reff212_op in H. discriminate H. Qed.

Lemma reff212_not2443 : ~ @Equation2443 Fin4 reff212_inst.
Proof. unfold Equation2443. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff212_inst, reff212_op in H. discriminate H. Qed.

Lemma reff212_not2444 : ~ @Equation2444 Fin4 reff212_inst.
Proof. unfold Equation2444. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff212_inst, reff212_op in H. discriminate H. Qed.

Lemma reff212_not2446 : ~ @Equation2446 Fin4 reff212_inst.
Proof. unfold Equation2446. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff212_inst, reff212_op in H. discriminate H. Qed.

Lemma reff212_not2447 : ~ @Equation2447 Fin4 reff212_inst.
Proof. unfold Equation2447. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff212_inst, reff212_op in H. discriminate H. Qed.

Lemma reff212_not2449 : ~ @Equation2449 Fin4 reff212_inst.
Proof. unfold Equation2449. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff212_inst, reff212_op in H. discriminate H. Qed.

Lemma reff212_not2450 : ~ @Equation2450 Fin4 reff212_inst.
Proof. unfold Equation2450. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff212_inst, reff212_op in H. discriminate H. Qed.

Lemma reff212_not2456 : ~ @Equation2456 Fin4 reff212_inst.
Proof. unfold Equation2456. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff212_inst, reff212_op in H. discriminate H. Qed.

Lemma reff212_not2457 : ~ @Equation2457 Fin4 reff212_inst.
Proof. unfold Equation2457. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff212_inst, reff212_op in H. discriminate H. Qed.

Lemma reff212_not2459 : ~ @Equation2459 Fin4 reff212_inst.
Proof. unfold Equation2459. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff212_inst, reff212_op in H. discriminate H. Qed.

Lemma reff212_not2460 : ~ @Equation2460 Fin4 reff212_inst.
Proof. unfold Equation2460. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff212_inst, reff212_op in H. discriminate H. Qed.

Lemma reff212_not2466 : ~ @Equation2466 Fin4 reff212_inst.
Proof. unfold Equation2466. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff212_inst, reff212_op in H. discriminate H. Qed.

Lemma reff212_not2467 : ~ @Equation2467 Fin4 reff212_inst.
Proof. unfold Equation2467. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff212_inst, reff212_op in H. discriminate H. Qed.

Lemma reff212_not2469 : ~ @Equation2469 Fin4 reff212_inst.
Proof. unfold Equation2469. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff212_inst, reff212_op in H. discriminate H. Qed.

Lemma reff212_not2470 : ~ @Equation2470 Fin4 reff212_inst.
Proof. unfold Equation2470. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff212_inst, reff212_op in H. discriminate H. Qed.

Lemma reff212_not2493 : ~ @Equation2493 Fin4 reff212_inst.
Proof. unfold Equation2493. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff212_inst, reff212_op in H. discriminate H. Qed.

Lemma reff212_not2494 : ~ @Equation2494 Fin4 reff212_inst.
Proof. unfold Equation2494. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff212_inst, reff212_op in H. discriminate H. Qed.

Lemma reff212_not2496 : ~ @Equation2496 Fin4 reff212_inst.
Proof. unfold Equation2496. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff212_inst, reff212_op in H. discriminate H. Qed.

Lemma reff212_not2497 : ~ @Equation2497 Fin4 reff212_inst.
Proof. unfold Equation2497. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff212_inst, reff212_op in H. discriminate H. Qed.

Lemma reff212_not2503 : ~ @Equation2503 Fin4 reff212_inst.
Proof. unfold Equation2503. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff212_inst, reff212_op in H. discriminate H. Qed.

Lemma reff212_not2504 : ~ @Equation2504 Fin4 reff212_inst.
Proof. unfold Equation2504. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff212_inst, reff212_op in H. discriminate H. Qed.

Lemma reff212_not2506 : ~ @Equation2506 Fin4 reff212_inst.
Proof. unfold Equation2506. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff212_inst, reff212_op in H. discriminate H. Qed.

Lemma reff212_not2507 : ~ @Equation2507 Fin4 reff212_inst.
Proof. unfold Equation2507. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff212_inst, reff212_op in H. discriminate H. Qed.

Lemma reff212_not2530 : ~ @Equation2530 Fin4 reff212_inst.
Proof. unfold Equation2530. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff212_inst, reff212_op in H. discriminate H. Qed.

Lemma reff212_not2531 : ~ @Equation2531 Fin4 reff212_inst.
Proof. unfold Equation2531. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff212_inst, reff212_op in H. discriminate H. Qed.

Lemma reff212_not2533 : ~ @Equation2533 Fin4 reff212_inst.
Proof. unfold Equation2533. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff212_inst, reff212_op in H. discriminate H. Qed.

Lemma reff212_not2534 : ~ @Equation2534 Fin4 reff212_inst.
Proof. unfold Equation2534. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff212_inst, reff212_op in H. discriminate H. Qed.

Lemma reff212_not2540 : ~ @Equation2540 Fin4 reff212_inst.
Proof. unfold Equation2540. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff212_inst, reff212_op in H. discriminate H. Qed.

Lemma reff212_not2541 : ~ @Equation2541 Fin4 reff212_inst.
Proof. unfold Equation2541. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff212_inst, reff212_op in H. discriminate H. Qed.

Lemma reff212_not2543 : ~ @Equation2543 Fin4 reff212_inst.
Proof. unfold Equation2543. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff212_inst, reff212_op in H. discriminate H. Qed.

Lemma reff212_not2645 : ~ @Equation2645 Fin4 reff212_inst.
Proof. unfold Equation2645. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff212_inst, reff212_op in H. discriminate H. Qed.

Lemma reff212_not2646 : ~ @Equation2646 Fin4 reff212_inst.
Proof. unfold Equation2646. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff212_inst, reff212_op in H. discriminate H. Qed.

Lemma reff212_not2647 : ~ @Equation2647 Fin4 reff212_inst.
Proof. unfold Equation2647. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff212_inst, reff212_op in H. discriminate H. Qed.

Lemma reff212_not2649 : ~ @Equation2649 Fin4 reff212_inst.
Proof. unfold Equation2649. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff212_inst, reff212_op in H. discriminate H. Qed.

Lemma reff212_not2650 : ~ @Equation2650 Fin4 reff212_inst.
Proof. unfold Equation2650. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff212_inst, reff212_op in H. discriminate H. Qed.

Lemma reff212_not2652 : ~ @Equation2652 Fin4 reff212_inst.
Proof. unfold Equation2652. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff212_inst, reff212_op in H. discriminate H. Qed.

Lemma reff212_not2653 : ~ @Equation2653 Fin4 reff212_inst.
Proof. unfold Equation2653. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff212_inst, reff212_op in H. discriminate H. Qed.

Lemma reff212_not2659 : ~ @Equation2659 Fin4 reff212_inst.
Proof. unfold Equation2659. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff212_inst, reff212_op in H. discriminate H. Qed.

Lemma reff212_not2660 : ~ @Equation2660 Fin4 reff212_inst.
Proof. unfold Equation2660. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff212_inst, reff212_op in H. discriminate H. Qed.

Lemma reff212_not2662 : ~ @Equation2662 Fin4 reff212_inst.
Proof. unfold Equation2662. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff212_inst, reff212_op in H. discriminate H. Qed.

Lemma reff212_not2663 : ~ @Equation2663 Fin4 reff212_inst.
Proof. unfold Equation2663. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff212_inst, reff212_op in H. discriminate H. Qed.

Lemma reff212_not2669 : ~ @Equation2669 Fin4 reff212_inst.
Proof. unfold Equation2669. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff212_inst, reff212_op in H. discriminate H. Qed.

Lemma reff212_not2670 : ~ @Equation2670 Fin4 reff212_inst.
Proof. unfold Equation2670. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff212_inst, reff212_op in H. discriminate H. Qed.

Lemma reff212_not2672 : ~ @Equation2672 Fin4 reff212_inst.
Proof. unfold Equation2672. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff212_inst, reff212_op in H. discriminate H. Qed.

Lemma reff212_not2673 : ~ @Equation2673 Fin4 reff212_inst.
Proof. unfold Equation2673. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff212_inst, reff212_op in H. discriminate H. Qed.

Lemma reff212_not2696 : ~ @Equation2696 Fin4 reff212_inst.
Proof. unfold Equation2696. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff212_inst, reff212_op in H. discriminate H. Qed.

Lemma reff212_not2697 : ~ @Equation2697 Fin4 reff212_inst.
Proof. unfold Equation2697. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff212_inst, reff212_op in H. discriminate H. Qed.

Lemma reff212_not2699 : ~ @Equation2699 Fin4 reff212_inst.
Proof. unfold Equation2699. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff212_inst, reff212_op in H. discriminate H. Qed.

Lemma reff212_not2700 : ~ @Equation2700 Fin4 reff212_inst.
Proof. unfold Equation2700. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff212_inst, reff212_op in H. discriminate H. Qed.

Lemma reff212_not2706 : ~ @Equation2706 Fin4 reff212_inst.
Proof. unfold Equation2706. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff212_inst, reff212_op in H. discriminate H. Qed.

Lemma reff212_not2707 : ~ @Equation2707 Fin4 reff212_inst.
Proof. unfold Equation2707. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff212_inst, reff212_op in H. discriminate H. Qed.

Lemma reff212_not2709 : ~ @Equation2709 Fin4 reff212_inst.
Proof. unfold Equation2709. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff212_inst, reff212_op in H. discriminate H. Qed.

Lemma reff212_not2710 : ~ @Equation2710 Fin4 reff212_inst.
Proof. unfold Equation2710. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff212_inst, reff212_op in H. discriminate H. Qed.

Lemma reff212_not2733 : ~ @Equation2733 Fin4 reff212_inst.
Proof. unfold Equation2733. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff212_inst, reff212_op in H. discriminate H. Qed.

Lemma reff212_not2734 : ~ @Equation2734 Fin4 reff212_inst.
Proof. unfold Equation2734. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff212_inst, reff212_op in H. discriminate H. Qed.

Lemma reff212_not2736 : ~ @Equation2736 Fin4 reff212_inst.
Proof. unfold Equation2736. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff212_inst, reff212_op in H. discriminate H. Qed.

Lemma reff212_not2737 : ~ @Equation2737 Fin4 reff212_inst.
Proof. unfold Equation2737. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff212_inst, reff212_op in H. discriminate H. Qed.

Lemma reff212_not2743 : ~ @Equation2743 Fin4 reff212_inst.
Proof. unfold Equation2743. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff212_inst, reff212_op in H. discriminate H. Qed.

Lemma reff212_not2744 : ~ @Equation2744 Fin4 reff212_inst.
Proof. unfold Equation2744. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff212_inst, reff212_op in H. discriminate H. Qed.

Lemma reff212_not2746 : ~ @Equation2746 Fin4 reff212_inst.
Proof. unfold Equation2746. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff212_inst, reff212_op in H. discriminate H. Qed.

Lemma reff212_not2848 : ~ @Equation2848 Fin4 reff212_inst.
Proof. unfold Equation2848. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff212_inst, reff212_op in H. discriminate H. Qed.

Lemma reff212_not2849 : ~ @Equation2849 Fin4 reff212_inst.
Proof. unfold Equation2849. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff212_inst, reff212_op in H. discriminate H. Qed.

Lemma reff212_not2850 : ~ @Equation2850 Fin4 reff212_inst.
Proof. unfold Equation2850. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff212_inst, reff212_op in H. discriminate H. Qed.

Lemma reff212_not2852 : ~ @Equation2852 Fin4 reff212_inst.
Proof. unfold Equation2852. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff212_inst, reff212_op in H. discriminate H. Qed.

Lemma reff212_not2853 : ~ @Equation2853 Fin4 reff212_inst.
Proof. unfold Equation2853. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff212_inst, reff212_op in H. discriminate H. Qed.

Lemma reff212_not2855 : ~ @Equation2855 Fin4 reff212_inst.
Proof. unfold Equation2855. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff212_inst, reff212_op in H. discriminate H. Qed.

Lemma reff212_not2856 : ~ @Equation2856 Fin4 reff212_inst.
Proof. unfold Equation2856. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff212_inst, reff212_op in H. discriminate H. Qed.

Lemma reff212_not2862 : ~ @Equation2862 Fin4 reff212_inst.
Proof. unfold Equation2862. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff212_inst, reff212_op in H. discriminate H. Qed.

Lemma reff212_not2863 : ~ @Equation2863 Fin4 reff212_inst.
Proof. unfold Equation2863. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff212_inst, reff212_op in H. discriminate H. Qed.

Lemma reff212_not2865 : ~ @Equation2865 Fin4 reff212_inst.
Proof. unfold Equation2865. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff212_inst, reff212_op in H. discriminate H. Qed.

Lemma reff212_not2866 : ~ @Equation2866 Fin4 reff212_inst.
Proof. unfold Equation2866. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff212_inst, reff212_op in H. discriminate H. Qed.

Lemma reff212_not2872 : ~ @Equation2872 Fin4 reff212_inst.
Proof. unfold Equation2872. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff212_inst, reff212_op in H. discriminate H. Qed.

Lemma reff212_not2873 : ~ @Equation2873 Fin4 reff212_inst.
Proof. unfold Equation2873. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff212_inst, reff212_op in H. discriminate H. Qed.

Lemma reff212_not2875 : ~ @Equation2875 Fin4 reff212_inst.
Proof. unfold Equation2875. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff212_inst, reff212_op in H. discriminate H. Qed.

Lemma reff212_not2876 : ~ @Equation2876 Fin4 reff212_inst.
Proof. unfold Equation2876. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff212_inst, reff212_op in H. discriminate H. Qed.

Lemma reff212_not2899 : ~ @Equation2899 Fin4 reff212_inst.
Proof. unfold Equation2899. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff212_inst, reff212_op in H. discriminate H. Qed.

Lemma reff212_not2900 : ~ @Equation2900 Fin4 reff212_inst.
Proof. unfold Equation2900. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff212_inst, reff212_op in H. discriminate H. Qed.

Lemma reff212_not2902 : ~ @Equation2902 Fin4 reff212_inst.
Proof. unfold Equation2902. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff212_inst, reff212_op in H. discriminate H. Qed.

Lemma reff212_not2903 : ~ @Equation2903 Fin4 reff212_inst.
Proof. unfold Equation2903. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff212_inst, reff212_op in H. discriminate H. Qed.

Lemma reff212_not2909 : ~ @Equation2909 Fin4 reff212_inst.
Proof. unfold Equation2909. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff212_inst, reff212_op in H. discriminate H. Qed.

Lemma reff212_not2910 : ~ @Equation2910 Fin4 reff212_inst.
Proof. unfold Equation2910. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff212_inst, reff212_op in H. discriminate H. Qed.

Lemma reff212_not2912 : ~ @Equation2912 Fin4 reff212_inst.
Proof. unfold Equation2912. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff212_inst, reff212_op in H. discriminate H. Qed.

Lemma reff212_not2913 : ~ @Equation2913 Fin4 reff212_inst.
Proof. unfold Equation2913. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff212_inst, reff212_op in H. discriminate H. Qed.

Lemma reff212_not2936 : ~ @Equation2936 Fin4 reff212_inst.
Proof. unfold Equation2936. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff212_inst, reff212_op in H. discriminate H. Qed.

Lemma reff212_not2937 : ~ @Equation2937 Fin4 reff212_inst.
Proof. unfold Equation2937. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff212_inst, reff212_op in H. discriminate H. Qed.

Lemma reff212_not2939 : ~ @Equation2939 Fin4 reff212_inst.
Proof. unfold Equation2939. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff212_inst, reff212_op in H. discriminate H. Qed.

Lemma reff212_not2940 : ~ @Equation2940 Fin4 reff212_inst.
Proof. unfold Equation2940. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff212_inst, reff212_op in H. discriminate H. Qed.

Lemma reff212_not2946 : ~ @Equation2946 Fin4 reff212_inst.
Proof. unfold Equation2946. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff212_inst, reff212_op in H. discriminate H. Qed.

Lemma reff212_not2947 : ~ @Equation2947 Fin4 reff212_inst.
Proof. unfold Equation2947. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff212_inst, reff212_op in H. discriminate H. Qed.

Lemma reff212_not2949 : ~ @Equation2949 Fin4 reff212_inst.
Proof. unfold Equation2949. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff212_inst, reff212_op in H. discriminate H. Qed.

Lemma reff212_not3051 : ~ @Equation3051 Fin4 reff212_inst.
Proof. unfold Equation3051. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff212_inst, reff212_op in H. discriminate H. Qed.

Lemma reff212_not3052 : ~ @Equation3052 Fin4 reff212_inst.
Proof. unfold Equation3052. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff212_inst, reff212_op in H. discriminate H. Qed.

Lemma reff212_not3053 : ~ @Equation3053 Fin4 reff212_inst.
Proof. unfold Equation3053. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff212_inst, reff212_op in H. discriminate H. Qed.

Lemma reff212_not3055 : ~ @Equation3055 Fin4 reff212_inst.
Proof. unfold Equation3055. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff212_inst, reff212_op in H. discriminate H. Qed.

Lemma reff212_not3056 : ~ @Equation3056 Fin4 reff212_inst.
Proof. unfold Equation3056. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff212_inst, reff212_op in H. discriminate H. Qed.

Lemma reff212_not3058 : ~ @Equation3058 Fin4 reff212_inst.
Proof. unfold Equation3058. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff212_inst, reff212_op in H. discriminate H. Qed.

Lemma reff212_not3059 : ~ @Equation3059 Fin4 reff212_inst.
Proof. unfold Equation3059. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff212_inst, reff212_op in H. discriminate H. Qed.

Lemma reff212_not3065 : ~ @Equation3065 Fin4 reff212_inst.
Proof. unfold Equation3065. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff212_inst, reff212_op in H. discriminate H. Qed.

Lemma reff212_not3066 : ~ @Equation3066 Fin4 reff212_inst.
Proof. unfold Equation3066. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff212_inst, reff212_op in H. discriminate H. Qed.

Lemma reff212_not3068 : ~ @Equation3068 Fin4 reff212_inst.
Proof. unfold Equation3068. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff212_inst, reff212_op in H. discriminate H. Qed.

Lemma reff212_not3069 : ~ @Equation3069 Fin4 reff212_inst.
Proof. unfold Equation3069. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff212_inst, reff212_op in H. discriminate H. Qed.

Lemma reff212_not3075 : ~ @Equation3075 Fin4 reff212_inst.
Proof. unfold Equation3075. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff212_inst, reff212_op in H. discriminate H. Qed.

Lemma reff212_not3076 : ~ @Equation3076 Fin4 reff212_inst.
Proof. unfold Equation3076. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff212_inst, reff212_op in H. discriminate H. Qed.

Lemma reff212_not3078 : ~ @Equation3078 Fin4 reff212_inst.
Proof. unfold Equation3078. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff212_inst, reff212_op in H. discriminate H. Qed.

Lemma reff212_not3079 : ~ @Equation3079 Fin4 reff212_inst.
Proof. unfold Equation3079. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff212_inst, reff212_op in H. discriminate H. Qed.

Lemma reff212_not3102 : ~ @Equation3102 Fin4 reff212_inst.
Proof. unfold Equation3102. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff212_inst, reff212_op in H. discriminate H. Qed.

Lemma reff212_not3103 : ~ @Equation3103 Fin4 reff212_inst.
Proof. unfold Equation3103. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff212_inst, reff212_op in H. discriminate H. Qed.

Lemma reff212_not3105 : ~ @Equation3105 Fin4 reff212_inst.
Proof. unfold Equation3105. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff212_inst, reff212_op in H. discriminate H. Qed.

Lemma reff212_not3106 : ~ @Equation3106 Fin4 reff212_inst.
Proof. unfold Equation3106. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff212_inst, reff212_op in H. discriminate H. Qed.

Lemma reff212_not3112 : ~ @Equation3112 Fin4 reff212_inst.
Proof. unfold Equation3112. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff212_inst, reff212_op in H. discriminate H. Qed.

Lemma reff212_not3113 : ~ @Equation3113 Fin4 reff212_inst.
Proof. unfold Equation3113. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff212_inst, reff212_op in H. discriminate H. Qed.

Lemma reff212_not3115 : ~ @Equation3115 Fin4 reff212_inst.
Proof. unfold Equation3115. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff212_inst, reff212_op in H. discriminate H. Qed.

Lemma reff212_not3116 : ~ @Equation3116 Fin4 reff212_inst.
Proof. unfold Equation3116. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff212_inst, reff212_op in H. discriminate H. Qed.

Lemma reff212_not3139 : ~ @Equation3139 Fin4 reff212_inst.
Proof. unfold Equation3139. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff212_inst, reff212_op in H. discriminate H. Qed.

Lemma reff212_not3140 : ~ @Equation3140 Fin4 reff212_inst.
Proof. unfold Equation3140. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff212_inst, reff212_op in H. discriminate H. Qed.

Lemma reff212_not3142 : ~ @Equation3142 Fin4 reff212_inst.
Proof. unfold Equation3142. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff212_inst, reff212_op in H. discriminate H. Qed.

Lemma reff212_not3143 : ~ @Equation3143 Fin4 reff212_inst.
Proof. unfold Equation3143. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff212_inst, reff212_op in H. discriminate H. Qed.

Lemma reff212_not3149 : ~ @Equation3149 Fin4 reff212_inst.
Proof. unfold Equation3149. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff212_inst, reff212_op in H. discriminate H. Qed.

Lemma reff212_not3150 : ~ @Equation3150 Fin4 reff212_inst.
Proof. unfold Equation3150. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff212_inst, reff212_op in H. discriminate H. Qed.

Lemma reff212_not3152 : ~ @Equation3152 Fin4 reff212_inst.
Proof. unfold Equation3152. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff212_inst, reff212_op in H. discriminate H. Qed.

Lemma reff212_not3254 : ~ @Equation3254 Fin4 reff212_inst.
Proof. unfold Equation3254. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff212_inst, reff212_op in H. discriminate H. Qed.

Lemma reff212_not3255 : ~ @Equation3255 Fin4 reff212_inst.
Proof. unfold Equation3255. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff212_inst, reff212_op in H. discriminate H. Qed.

Lemma reff212_not3256 : ~ @Equation3256 Fin4 reff212_inst.
Proof. unfold Equation3256. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff212_inst, reff212_op in H. discriminate H. Qed.

Lemma reff212_not3258 : ~ @Equation3258 Fin4 reff212_inst.
Proof. unfold Equation3258. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff212_inst, reff212_op in H. discriminate H. Qed.

Lemma reff212_not3259 : ~ @Equation3259 Fin4 reff212_inst.
Proof. unfold Equation3259. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff212_inst, reff212_op in H. discriminate H. Qed.

Lemma reff212_not3261 : ~ @Equation3261 Fin4 reff212_inst.
Proof. unfold Equation3261. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff212_inst, reff212_op in H. discriminate H. Qed.

Lemma reff212_not3262 : ~ @Equation3262 Fin4 reff212_inst.
Proof. unfold Equation3262. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff212_inst, reff212_op in H. discriminate H. Qed.

Lemma reff212_not3268 : ~ @Equation3268 Fin4 reff212_inst.
Proof. unfold Equation3268. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff212_inst, reff212_op in H. discriminate H. Qed.

Lemma reff212_not3269 : ~ @Equation3269 Fin4 reff212_inst.
Proof. unfold Equation3269. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff212_inst, reff212_op in H. discriminate H. Qed.

Lemma reff212_not3271 : ~ @Equation3271 Fin4 reff212_inst.
Proof. unfold Equation3271. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff212_inst, reff212_op in H. discriminate H. Qed.

Lemma reff212_not3272 : ~ @Equation3272 Fin4 reff212_inst.
Proof. unfold Equation3272. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff212_inst, reff212_op in H. discriminate H. Qed.

Lemma reff212_not3278 : ~ @Equation3278 Fin4 reff212_inst.
Proof. unfold Equation3278. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff212_inst, reff212_op in H. discriminate H. Qed.

Lemma reff212_not3279 : ~ @Equation3279 Fin4 reff212_inst.
Proof. unfold Equation3279. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff212_inst, reff212_op in H. discriminate H. Qed.

Lemma reff212_not3281 : ~ @Equation3281 Fin4 reff212_inst.
Proof. unfold Equation3281. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff212_inst, reff212_op in H. discriminate H. Qed.

Lemma reff212_not3308 : ~ @Equation3308 Fin4 reff212_inst.
Proof. unfold Equation3308. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff212_inst, reff212_op in H. discriminate H. Qed.

Lemma reff212_not3315 : ~ @Equation3315 Fin4 reff212_inst.
Proof. unfold Equation3315. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff212_inst, reff212_op in H. discriminate H. Qed.

Lemma reff212_not3316 : ~ @Equation3316 Fin4 reff212_inst.
Proof. unfold Equation3316. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff212_inst, reff212_op in H. discriminate H. Qed.

Lemma reff212_not3318 : ~ @Equation3318 Fin4 reff212_inst.
Proof. unfold Equation3318. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff212_inst, reff212_op in H. discriminate H. Qed.

Lemma reff212_not3342 : ~ @Equation3342 Fin4 reff212_inst.
Proof. unfold Equation3342. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff212_inst, reff212_op in H. discriminate H. Qed.

Lemma reff212_not3343 : ~ @Equation3343 Fin4 reff212_inst.
Proof. unfold Equation3343. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff212_inst, reff212_op in H. discriminate H. Qed.

Lemma reff212_not3345 : ~ @Equation3345 Fin4 reff212_inst.
Proof. unfold Equation3345. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff212_inst, reff212_op in H. discriminate H. Qed.

Lemma reff212_not3346 : ~ @Equation3346 Fin4 reff212_inst.
Proof. unfold Equation3346. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff212_inst, reff212_op in H. discriminate H. Qed.

Lemma reff212_not3352 : ~ @Equation3352 Fin4 reff212_inst.
Proof. unfold Equation3352. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff212_inst, reff212_op in H. discriminate H. Qed.

Lemma reff212_not3353 : ~ @Equation3353 Fin4 reff212_inst.
Proof. unfold Equation3353. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff212_inst, reff212_op in H. discriminate H. Qed.

Lemma reff212_not3457 : ~ @Equation3457 Fin4 reff212_inst.
Proof. unfold Equation3457. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff212_inst, reff212_op in H. discriminate H. Qed.

Lemma reff212_not3458 : ~ @Equation3458 Fin4 reff212_inst.
Proof. unfold Equation3458. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff212_inst, reff212_op in H. discriminate H. Qed.

Lemma reff212_not3459 : ~ @Equation3459 Fin4 reff212_inst.
Proof. unfold Equation3459. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff212_inst, reff212_op in H. discriminate H. Qed.

Lemma reff212_not3461 : ~ @Equation3461 Fin4 reff212_inst.
Proof. unfold Equation3461. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff212_inst, reff212_op in H. discriminate H. Qed.

Lemma reff212_not3462 : ~ @Equation3462 Fin4 reff212_inst.
Proof. unfold Equation3462. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff212_inst, reff212_op in H. discriminate H. Qed.

Lemma reff212_not3464 : ~ @Equation3464 Fin4 reff212_inst.
Proof. unfold Equation3464. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff212_inst, reff212_op in H. discriminate H. Qed.

Lemma reff212_not3465 : ~ @Equation3465 Fin4 reff212_inst.
Proof. unfold Equation3465. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff212_inst, reff212_op in H. discriminate H. Qed.

Lemma reff212_not3472 : ~ @Equation3472 Fin4 reff212_inst.
Proof. unfold Equation3472. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff212_inst, reff212_op in H. discriminate H. Qed.

Lemma reff212_not3474 : ~ @Equation3474 Fin4 reff212_inst.
Proof. unfold Equation3474. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff212_inst, reff212_op in H. discriminate H. Qed.

Lemma reff212_not3475 : ~ @Equation3475 Fin4 reff212_inst.
Proof. unfold Equation3475. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff212_inst, reff212_op in H. discriminate H. Qed.

Lemma reff212_not3481 : ~ @Equation3481 Fin4 reff212_inst.
Proof. unfold Equation3481. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff212_inst, reff212_op in H. discriminate H. Qed.

Lemma reff212_not3482 : ~ @Equation3482 Fin4 reff212_inst.
Proof. unfold Equation3482. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff212_inst, reff212_op in H. discriminate H. Qed.

Lemma reff212_not3484 : ~ @Equation3484 Fin4 reff212_inst.
Proof. unfold Equation3484. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff212_inst, reff212_op in H. discriminate H. Qed.

Lemma reff212_not3511 : ~ @Equation3511 Fin4 reff212_inst.
Proof. unfold Equation3511. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff212_inst, reff212_op in H. discriminate H. Qed.

Lemma reff212_not3512 : ~ @Equation3512 Fin4 reff212_inst.
Proof. unfold Equation3512. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff212_inst, reff212_op in H. discriminate H. Qed.

Lemma reff212_not3518 : ~ @Equation3518 Fin4 reff212_inst.
Proof. unfold Equation3518. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff212_inst, reff212_op in H. discriminate H. Qed.

Lemma reff212_not3519 : ~ @Equation3519 Fin4 reff212_inst.
Proof. unfold Equation3519. intro H. specialize (H F4_3 F4_0). unfold magma_op, reff212_inst, reff212_op in H. discriminate H. Qed.

Lemma reff212_not3521 : ~ @Equation3521 Fin4 reff212_inst.
Proof. unfold Equation3521. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff212_inst, reff212_op in H. discriminate H. Qed.

Lemma reff212_not3545 : ~ @Equation3545 Fin4 reff212_inst.
Proof. unfold Equation3545. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff212_inst, reff212_op in H. discriminate H. Qed.

Lemma reff212_not3546 : ~ @Equation3546 Fin4 reff212_inst.
Proof. unfold Equation3546. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff212_inst, reff212_op in H. discriminate H. Qed.

Lemma reff212_not3548 : ~ @Equation3548 Fin4 reff212_inst.
Proof. unfold Equation3548. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff212_inst, reff212_op in H. discriminate H. Qed.

Lemma reff212_not3549 : ~ @Equation3549 Fin4 reff212_inst.
Proof. unfold Equation3549. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff212_inst, reff212_op in H. discriminate H. Qed.

Lemma reff212_not3555 : ~ @Equation3555 Fin4 reff212_inst.
Proof. unfold Equation3555. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff212_inst, reff212_op in H. discriminate H. Qed.

Lemma reff212_not3556 : ~ @Equation3556 Fin4 reff212_inst.
Proof. unfold Equation3556. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff212_inst, reff212_op in H. discriminate H. Qed.

Lemma reff212_not3558 : ~ @Equation3558 Fin4 reff212_inst.
Proof. unfold Equation3558. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff212_inst, reff212_op in H. discriminate H. Qed.

Lemma reff212_not3660 : ~ @Equation3660 Fin4 reff212_inst.
Proof. unfold Equation3660. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff212_inst, reff212_op in H. discriminate H. Qed.

Lemma reff212_not3661 : ~ @Equation3661 Fin4 reff212_inst.
Proof. unfold Equation3661. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff212_inst, reff212_op in H. discriminate H. Qed.

Lemma reff212_not3662 : ~ @Equation3662 Fin4 reff212_inst.
Proof. unfold Equation3662. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff212_inst, reff212_op in H. discriminate H. Qed.

Lemma reff212_not3664 : ~ @Equation3664 Fin4 reff212_inst.
Proof. unfold Equation3664. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff212_inst, reff212_op in H. discriminate H. Qed.

Lemma reff212_not3665 : ~ @Equation3665 Fin4 reff212_inst.
Proof. unfold Equation3665. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff212_inst, reff212_op in H. discriminate H. Qed.

Lemma reff212_not3667 : ~ @Equation3667 Fin4 reff212_inst.
Proof. unfold Equation3667. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff212_inst, reff212_op in H. discriminate H. Qed.

Lemma reff212_not3668 : ~ @Equation3668 Fin4 reff212_inst.
Proof. unfold Equation3668. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff212_inst, reff212_op in H. discriminate H. Qed.

Lemma reff212_not3674 : ~ @Equation3674 Fin4 reff212_inst.
Proof. unfold Equation3674. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff212_inst, reff212_op in H. discriminate H. Qed.

Lemma reff212_not3675 : ~ @Equation3675 Fin4 reff212_inst.
Proof. unfold Equation3675. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff212_inst, reff212_op in H. discriminate H. Qed.

Lemma reff212_not3677 : ~ @Equation3677 Fin4 reff212_inst.
Proof. unfold Equation3677. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff212_inst, reff212_op in H. discriminate H. Qed.

Lemma reff212_not3678 : ~ @Equation3678 Fin4 reff212_inst.
Proof. unfold Equation3678. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff212_inst, reff212_op in H. discriminate H. Qed.

Lemma reff212_not3684 : ~ @Equation3684 Fin4 reff212_inst.
Proof. unfold Equation3684. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff212_inst, reff212_op in H. discriminate H. Qed.

Lemma reff212_not3685 : ~ @Equation3685 Fin4 reff212_inst.
Proof. unfold Equation3685. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff212_inst, reff212_op in H. discriminate H. Qed.

Lemma reff212_not3687 : ~ @Equation3687 Fin4 reff212_inst.
Proof. unfold Equation3687. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff212_inst, reff212_op in H. discriminate H. Qed.

Lemma reff212_not3714 : ~ @Equation3714 Fin4 reff212_inst.
Proof. unfold Equation3714. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff212_inst, reff212_op in H. discriminate H. Qed.

Lemma reff212_not3721 : ~ @Equation3721 Fin4 reff212_inst.
Proof. unfold Equation3721. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff212_inst, reff212_op in H. discriminate H. Qed.

Lemma reff212_not3724 : ~ @Equation3724 Fin4 reff212_inst.
Proof. unfold Equation3724. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff212_inst, reff212_op in H. discriminate H. Qed.

Lemma reff212_not3725 : ~ @Equation3725 Fin4 reff212_inst.
Proof. unfold Equation3725. intro H. specialize (H F4_0 F4_3). unfold magma_op, reff212_inst, reff212_op in H. discriminate H. Qed.

Lemma reff212_not3748 : ~ @Equation3748 Fin4 reff212_inst.
Proof. unfold Equation3748. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff212_inst, reff212_op in H. discriminate H. Qed.

Lemma reff212_not3749 : ~ @Equation3749 Fin4 reff212_inst.
Proof. unfold Equation3749. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff212_inst, reff212_op in H. discriminate H. Qed.

Lemma reff212_not3751 : ~ @Equation3751 Fin4 reff212_inst.
Proof. unfold Equation3751. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff212_inst, reff212_op in H. discriminate H. Qed.

Lemma reff212_not3752 : ~ @Equation3752 Fin4 reff212_inst.
Proof. unfold Equation3752. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff212_inst, reff212_op in H. discriminate H. Qed.

Lemma reff212_not3758 : ~ @Equation3758 Fin4 reff212_inst.
Proof. unfold Equation3758. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff212_inst, reff212_op in H. discriminate H. Qed.

Lemma reff212_not3759 : ~ @Equation3759 Fin4 reff212_inst.
Proof. unfold Equation3759. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff212_inst, reff212_op in H. discriminate H. Qed.

Lemma reff212_not3761 : ~ @Equation3761 Fin4 reff212_inst.
Proof. unfold Equation3761. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff212_inst, reff212_op in H. discriminate H. Qed.

Lemma reff212_not3864 : ~ @Equation3864 Fin4 reff212_inst.
Proof. unfold Equation3864. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff212_inst, reff212_op in H. discriminate H. Qed.

Lemma reff212_not3865 : ~ @Equation3865 Fin4 reff212_inst.
Proof. unfold Equation3865. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff212_inst, reff212_op in H. discriminate H. Qed.

Lemma reff212_not3867 : ~ @Equation3867 Fin4 reff212_inst.
Proof. unfold Equation3867. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff212_inst, reff212_op in H. discriminate H. Qed.

Lemma reff212_not3868 : ~ @Equation3868 Fin4 reff212_inst.
Proof. unfold Equation3868. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff212_inst, reff212_op in H. discriminate H. Qed.

Lemma reff212_not3870 : ~ @Equation3870 Fin4 reff212_inst.
Proof. unfold Equation3870. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff212_inst, reff212_op in H. discriminate H. Qed.

Lemma reff212_not3871 : ~ @Equation3871 Fin4 reff212_inst.
Proof. unfold Equation3871. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff212_inst, reff212_op in H. discriminate H. Qed.

Lemma reff212_not3877 : ~ @Equation3877 Fin4 reff212_inst.
Proof. unfold Equation3877. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff212_inst, reff212_op in H. discriminate H. Qed.

Lemma reff212_not3878 : ~ @Equation3878 Fin4 reff212_inst.
Proof. unfold Equation3878. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff212_inst, reff212_op in H. discriminate H. Qed.

Lemma reff212_not3880 : ~ @Equation3880 Fin4 reff212_inst.
Proof. unfold Equation3880. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff212_inst, reff212_op in H. discriminate H. Qed.

Lemma reff212_not3881 : ~ @Equation3881 Fin4 reff212_inst.
Proof. unfold Equation3881. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff212_inst, reff212_op in H. discriminate H. Qed.

Lemma reff212_not3887 : ~ @Equation3887 Fin4 reff212_inst.
Proof. unfold Equation3887. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff212_inst, reff212_op in H. discriminate H. Qed.

Lemma reff212_not3888 : ~ @Equation3888 Fin4 reff212_inst.
Proof. unfold Equation3888. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff212_inst, reff212_op in H. discriminate H. Qed.

Lemma reff212_not3890 : ~ @Equation3890 Fin4 reff212_inst.
Proof. unfold Equation3890. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff212_inst, reff212_op in H. discriminate H. Qed.

Lemma reff212_not3917 : ~ @Equation3917 Fin4 reff212_inst.
Proof. unfold Equation3917. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff212_inst, reff212_op in H. discriminate H. Qed.

Lemma reff212_not3918 : ~ @Equation3918 Fin4 reff212_inst.
Proof. unfold Equation3918. intro H. specialize (H F4_0 F4_3). unfold magma_op, reff212_inst, reff212_op in H. discriminate H. Qed.

Lemma reff212_not3924 : ~ @Equation3924 Fin4 reff212_inst.
Proof. unfold Equation3924. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff212_inst, reff212_op in H. discriminate H. Qed.

Lemma reff212_not3925 : ~ @Equation3925 Fin4 reff212_inst.
Proof. unfold Equation3925. intro H. specialize (H F4_0 F4_3). unfold magma_op, reff212_inst, reff212_op in H. discriminate H. Qed.

Lemma reff212_not3927 : ~ @Equation3927 Fin4 reff212_inst.
Proof. unfold Equation3927. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff212_inst, reff212_op in H. discriminate H. Qed.

Lemma reff212_not3928 : ~ @Equation3928 Fin4 reff212_inst.
Proof. unfold Equation3928. intro H. specialize (H F4_0 F4_3). unfold magma_op, reff212_inst, reff212_op in H. discriminate H. Qed.

Lemma reff212_not3951 : ~ @Equation3951 Fin4 reff212_inst.
Proof. unfold Equation3951. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff212_inst, reff212_op in H. discriminate H. Qed.

Lemma reff212_not3952 : ~ @Equation3952 Fin4 reff212_inst.
Proof. unfold Equation3952. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff212_inst, reff212_op in H. discriminate H. Qed.

Lemma reff212_not3954 : ~ @Equation3954 Fin4 reff212_inst.
Proof. unfold Equation3954. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff212_inst, reff212_op in H. discriminate H. Qed.

Lemma reff212_not3955 : ~ @Equation3955 Fin4 reff212_inst.
Proof. unfold Equation3955. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff212_inst, reff212_op in H. discriminate H. Qed.

Lemma reff212_not3961 : ~ @Equation3961 Fin4 reff212_inst.
Proof. unfold Equation3961. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff212_inst, reff212_op in H. discriminate H. Qed.

Lemma reff212_not3962 : ~ @Equation3962 Fin4 reff212_inst.
Proof. unfold Equation3962. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff212_inst, reff212_op in H. discriminate H. Qed.

Lemma reff212_not3964 : ~ @Equation3964 Fin4 reff212_inst.
Proof. unfold Equation3964. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff212_inst, reff212_op in H. discriminate H. Qed.

Lemma reff212_not4066 : ~ @Equation4066 Fin4 reff212_inst.
Proof. unfold Equation4066. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff212_inst, reff212_op in H. discriminate H. Qed.

Lemma reff212_not4067 : ~ @Equation4067 Fin4 reff212_inst.
Proof. unfold Equation4067. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff212_inst, reff212_op in H. discriminate H. Qed.

Lemma reff212_not4068 : ~ @Equation4068 Fin4 reff212_inst.
Proof. unfold Equation4068. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff212_inst, reff212_op in H. discriminate H. Qed.

Lemma reff212_not4070 : ~ @Equation4070 Fin4 reff212_inst.
Proof. unfold Equation4070. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff212_inst, reff212_op in H. discriminate H. Qed.

Lemma reff212_not4071 : ~ @Equation4071 Fin4 reff212_inst.
Proof. unfold Equation4071. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff212_inst, reff212_op in H. discriminate H. Qed.

Lemma reff212_not4073 : ~ @Equation4073 Fin4 reff212_inst.
Proof. unfold Equation4073. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff212_inst, reff212_op in H. discriminate H. Qed.

Lemma reff212_not4074 : ~ @Equation4074 Fin4 reff212_inst.
Proof. unfold Equation4074. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff212_inst, reff212_op in H. discriminate H. Qed.

Lemma reff212_not4080 : ~ @Equation4080 Fin4 reff212_inst.
Proof. unfold Equation4080. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff212_inst, reff212_op in H. discriminate H. Qed.

Lemma reff212_not4081 : ~ @Equation4081 Fin4 reff212_inst.
Proof. unfold Equation4081. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff212_inst, reff212_op in H. discriminate H. Qed.

Lemma reff212_not4083 : ~ @Equation4083 Fin4 reff212_inst.
Proof. unfold Equation4083. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff212_inst, reff212_op in H. discriminate H. Qed.

Lemma reff212_not4084 : ~ @Equation4084 Fin4 reff212_inst.
Proof. unfold Equation4084. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff212_inst, reff212_op in H. discriminate H. Qed.

Lemma reff212_not4090 : ~ @Equation4090 Fin4 reff212_inst.
Proof. unfold Equation4090. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff212_inst, reff212_op in H. discriminate H. Qed.

Lemma reff212_not4091 : ~ @Equation4091 Fin4 reff212_inst.
Proof. unfold Equation4091. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff212_inst, reff212_op in H. discriminate H. Qed.

Lemma reff212_not4093 : ~ @Equation4093 Fin4 reff212_inst.
Proof. unfold Equation4093. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff212_inst, reff212_op in H. discriminate H. Qed.

Lemma reff212_not4120 : ~ @Equation4120 Fin4 reff212_inst.
Proof. unfold Equation4120. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff212_inst, reff212_op in H. discriminate H. Qed.

Lemma reff212_not4121 : ~ @Equation4121 Fin4 reff212_inst.
Proof. unfold Equation4121. intro H. specialize (H F4_0 F4_3). unfold magma_op, reff212_inst, reff212_op in H. discriminate H. Qed.

Lemma reff212_not4127 : ~ @Equation4127 Fin4 reff212_inst.
Proof. unfold Equation4127. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff212_inst, reff212_op in H. discriminate H. Qed.

Lemma reff212_not4128 : ~ @Equation4128 Fin4 reff212_inst.
Proof. unfold Equation4128. intro H. specialize (H F4_0 F4_3). unfold magma_op, reff212_inst, reff212_op in H. discriminate H. Qed.

Lemma reff212_not4130 : ~ @Equation4130 Fin4 reff212_inst.
Proof. unfold Equation4130. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff212_inst, reff212_op in H. discriminate H. Qed.

Lemma reff212_not4131 : ~ @Equation4131 Fin4 reff212_inst.
Proof. unfold Equation4131. intro H. specialize (H F4_0 F4_3). unfold magma_op, reff212_inst, reff212_op in H. discriminate H. Qed.

Lemma reff212_not4155 : ~ @Equation4155 Fin4 reff212_inst.
Proof. unfold Equation4155. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff212_inst, reff212_op in H. discriminate H. Qed.

Lemma reff212_not4157 : ~ @Equation4157 Fin4 reff212_inst.
Proof. unfold Equation4157. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff212_inst, reff212_op in H. discriminate H. Qed.

Lemma reff212_not4158 : ~ @Equation4158 Fin4 reff212_inst.
Proof. unfold Equation4158. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff212_inst, reff212_op in H. discriminate H. Qed.

Lemma reff212_not4164 : ~ @Equation4164 Fin4 reff212_inst.
Proof. unfold Equation4164. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff212_inst, reff212_op in H. discriminate H. Qed.

Lemma reff212_not4165 : ~ @Equation4165 Fin4 reff212_inst.
Proof. unfold Equation4165. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff212_inst, reff212_op in H. discriminate H. Qed.

Lemma reff212_not4167 : ~ @Equation4167 Fin4 reff212_inst.
Proof. unfold Equation4167. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff212_inst, reff212_op in H. discriminate H. Qed.

Lemma reff212_not4268 : ~ @Equation4268 Fin4 reff212_inst.
Proof. unfold Equation4268. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff212_inst, reff212_op in H. discriminate H. Qed.

Lemma reff212_not4269 : ~ @Equation4269 Fin4 reff212_inst.
Proof. unfold Equation4269. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff212_inst, reff212_op in H. discriminate H. Qed.

Lemma reff212_not4270 : ~ @Equation4270 Fin4 reff212_inst.
Proof. unfold Equation4270. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff212_inst, reff212_op in H. discriminate H. Qed.

Lemma reff212_not4272 : ~ @Equation4272 Fin4 reff212_inst.
Proof. unfold Equation4272. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff212_inst, reff212_op in H. discriminate H. Qed.

Lemma reff212_not4273 : ~ @Equation4273 Fin4 reff212_inst.
Proof. unfold Equation4273. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff212_inst, reff212_op in H. discriminate H. Qed.

Lemma reff212_not4275 : ~ @Equation4275 Fin4 reff212_inst.
Proof. unfold Equation4275. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff212_inst, reff212_op in H. discriminate H. Qed.

Lemma reff212_not4276 : ~ @Equation4276 Fin4 reff212_inst.
Proof. unfold Equation4276. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff212_inst, reff212_op in H. discriminate H. Qed.

Lemma reff212_not4283 : ~ @Equation4283 Fin4 reff212_inst.
Proof. unfold Equation4283. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff212_inst, reff212_op in H. discriminate H. Qed.

Lemma reff212_not4290 : ~ @Equation4290 Fin4 reff212_inst.
Proof. unfold Equation4290. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff212_inst, reff212_op in H. discriminate H. Qed.

Lemma reff212_not4291 : ~ @Equation4291 Fin4 reff212_inst.
Proof. unfold Equation4291. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff212_inst, reff212_op in H. discriminate H. Qed.

Lemma reff212_not4293 : ~ @Equation4293 Fin4 reff212_inst.
Proof. unfold Equation4293. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff212_inst, reff212_op in H. discriminate H. Qed.

Lemma reff212_not4314 : ~ @Equation4314 Fin4 reff212_inst.
Proof. unfold Equation4314. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff212_inst, reff212_op in H. discriminate H. Qed.

Lemma reff212_not4320 : ~ @Equation4320 Fin4 reff212_inst.
Proof. unfold Equation4320. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff212_inst, reff212_op in H. discriminate H. Qed.

Lemma reff212_not4321 : ~ @Equation4321 Fin4 reff212_inst.
Proof. unfold Equation4321. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff212_inst, reff212_op in H. discriminate H. Qed.

Lemma reff212_not4343 : ~ @Equation4343 Fin4 reff212_inst.
Proof. unfold Equation4343. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff212_inst, reff212_op in H. discriminate H. Qed.

Lemma reff212_not4398 : ~ @Equation4398 Fin4 reff212_inst.
Proof. unfold Equation4398. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff212_inst, reff212_op in H. discriminate H. Qed.

Lemma reff212_not4399 : ~ @Equation4399 Fin4 reff212_inst.
Proof. unfold Equation4399. intro H. specialize (H F4_0 F4_3). unfold magma_op, reff212_inst, reff212_op in H. discriminate H. Qed.

Lemma reff212_not4405 : ~ @Equation4405 Fin4 reff212_inst.
Proof. unfold Equation4405. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff212_inst, reff212_op in H. discriminate H. Qed.

Lemma reff212_not4406 : ~ @Equation4406 Fin4 reff212_inst.
Proof. unfold Equation4406. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff212_inst, reff212_op in H. discriminate H. Qed.

Lemma reff212_not4408 : ~ @Equation4408 Fin4 reff212_inst.
Proof. unfold Equation4408. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff212_inst, reff212_op in H. discriminate H. Qed.

Lemma reff212_not4433 : ~ @Equation4433 Fin4 reff212_inst.
Proof. unfold Equation4433. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff212_inst, reff212_op in H. discriminate H. Qed.

Lemma reff212_not4435 : ~ @Equation4435 Fin4 reff212_inst.
Proof. unfold Equation4435. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff212_inst, reff212_op in H. discriminate H. Qed.

Lemma reff212_not4436 : ~ @Equation4436 Fin4 reff212_inst.
Proof. unfold Equation4436. intro H. specialize (H F4_0 F4_3). unfold magma_op, reff212_inst, reff212_op in H. discriminate H. Qed.

Lemma reff212_not4442 : ~ @Equation4442 Fin4 reff212_inst.
Proof. unfold Equation4442. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff212_inst, reff212_op in H. discriminate H. Qed.

Lemma reff212_not4443 : ~ @Equation4443 Fin4 reff212_inst.
Proof. unfold Equation4443. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff212_inst, reff212_op in H. discriminate H. Qed.

Lemma reff212_not4445 : ~ @Equation4445 Fin4 reff212_inst.
Proof. unfold Equation4445. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff212_inst, reff212_op in H. discriminate H. Qed.

Lemma reff212_not4472 : ~ @Equation4472 Fin4 reff212_inst.
Proof. unfold Equation4472. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff212_inst, reff212_op in H. discriminate H. Qed.

Lemma reff212_not4473 : ~ @Equation4473 Fin4 reff212_inst.
Proof. unfold Equation4473. intro H. specialize (H F4_0 F4_3). unfold magma_op, reff212_inst, reff212_op in H. discriminate H. Qed.

Lemma reff212_not4479 : ~ @Equation4479 Fin4 reff212_inst.
Proof. unfold Equation4479. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff212_inst, reff212_op in H. discriminate H. Qed.

Lemma reff212_not4480 : ~ @Equation4480 Fin4 reff212_inst.
Proof. unfold Equation4480. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff212_inst, reff212_op in H. discriminate H. Qed.

Lemma reff212_not4482 : ~ @Equation4482 Fin4 reff212_inst.
Proof. unfold Equation4482. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff212_inst, reff212_op in H. discriminate H. Qed.

Lemma reff212_not4583 : ~ @Equation4583 Fin4 reff212_inst.
Proof. unfold Equation4583. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff212_inst, reff212_op in H. discriminate H. Qed.

Lemma reff212_not4584 : ~ @Equation4584 Fin4 reff212_inst.
Proof. unfold Equation4584. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff212_inst, reff212_op in H. discriminate H. Qed.

Lemma reff212_not4585 : ~ @Equation4585 Fin4 reff212_inst.
Proof. unfold Equation4585. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff212_inst, reff212_op in H. discriminate H. Qed.

Lemma reff212_not4587 : ~ @Equation4587 Fin4 reff212_inst.
Proof. unfold Equation4587. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff212_inst, reff212_op in H. discriminate H. Qed.

Lemma reff212_not4588 : ~ @Equation4588 Fin4 reff212_inst.
Proof. unfold Equation4588. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff212_inst, reff212_op in H. discriminate H. Qed.

Lemma reff212_not4590 : ~ @Equation4590 Fin4 reff212_inst.
Proof. unfold Equation4590. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff212_inst, reff212_op in H. discriminate H. Qed.

Lemma reff212_not4591 : ~ @Equation4591 Fin4 reff212_inst.
Proof. unfold Equation4591. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff212_inst, reff212_op in H. discriminate H. Qed.

Lemma reff212_not4598 : ~ @Equation4598 Fin4 reff212_inst.
Proof. unfold Equation4598. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff212_inst, reff212_op in H. discriminate H. Qed.

Lemma reff212_not4599 : ~ @Equation4599 Fin4 reff212_inst.
Proof. unfold Equation4599. intro H. specialize (H F4_0 F4_3). unfold magma_op, reff212_inst, reff212_op in H. discriminate H. Qed.

Lemma reff212_not4605 : ~ @Equation4605 Fin4 reff212_inst.
Proof. unfold Equation4605. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff212_inst, reff212_op in H. discriminate H. Qed.

Lemma reff212_not4606 : ~ @Equation4606 Fin4 reff212_inst.
Proof. unfold Equation4606. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff212_inst, reff212_op in H. discriminate H. Qed.

Lemma reff212_not4608 : ~ @Equation4608 Fin4 reff212_inst.
Proof. unfold Equation4608. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff212_inst, reff212_op in H. discriminate H. Qed.

Lemma reff212_not4629 : ~ @Equation4629 Fin4 reff212_inst.
Proof. unfold Equation4629. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff212_inst, reff212_op in H. discriminate H. Qed.

Lemma reff212_not4635 : ~ @Equation4635 Fin4 reff212_inst.
Proof. unfold Equation4635. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff212_inst, reff212_op in H. discriminate H. Qed.

Lemma reff212_not4636 : ~ @Equation4636 Fin4 reff212_inst.
Proof. unfold Equation4636. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff212_inst, reff212_op in H. discriminate H. Qed.

Lemma reff212_not4658 : ~ @Equation4658 Fin4 reff212_inst.
Proof. unfold Equation4658. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff212_inst, reff212_op in H. discriminate H. Qed.
