(** * FinitePoly counterexamples — batch 5
    Auto-generated from Lean4 FinitePoly files. *)

From Stdlib Require Import Utf8.

From ETP Require Import Magma.
From ETP Require Import FinMagma.
From ETP.Equations Require Import All.

Open Scope magma_scope.

(** ---- reff246 (Fin3) ---- *)

Definition reff246_op (x y : Fin3) : Fin3 :=
  match x, y with
  | F3_0, F3_0 => F3_0 | F3_0, F3_1 => F3_1 | F3_0, F3_2 => F3_2
  | F3_1, F3_0 => F3_0 | F3_1, F3_1 => F3_2 | F3_1, F3_2 => F3_1
  | F3_2, F3_0 => F3_0 | F3_2, F3_1 => F3_0 | F3_2, F3_2 => F3_0
  end.

#[local] Instance reff246_inst : Magma Fin3 := {| magma_op := reff246_op |}.

Lemma reff246_sat2443 : @Equation2443 Fin3 reff246_inst.
Proof. unfold Equation2443, magma_op, reff246_inst, reff246_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff246_sat2543 : @Equation2543 Fin3 reff246_inst.
Proof. unfold Equation2543, magma_op, reff246_inst, reff246_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff246_sat2646 : @Equation2646 Fin3 reff246_inst.
Proof. unfold Equation2646, magma_op, reff246_inst, reff246_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff246_sat2746 : @Equation2746 Fin3 reff246_inst.
Proof. unfold Equation2746, magma_op, reff246_inst, reff246_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff246_sat3306 : @Equation3306 Fin3 reff246_inst.
Proof. unfold Equation3306, magma_op, reff246_inst, reff246_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff246_not47 : ~ @Equation47 Fin3 reff246_inst.
Proof. unfold Equation47. intro H. specialize (H F3_1). unfold magma_op, reff246_inst, reff246_op in H. discriminate H. Qed.

Lemma reff246_not99 : ~ @Equation99 Fin3 reff246_inst.
Proof. unfold Equation99. intro H. specialize (H F3_1). unfold magma_op, reff246_inst, reff246_op in H. discriminate H. Qed.

Lemma reff246_not151 : ~ @Equation151 Fin3 reff246_inst.
Proof. unfold Equation151. intro H. specialize (H F3_1). unfold magma_op, reff246_inst, reff246_op in H. discriminate H. Qed.

Lemma reff246_not203 : ~ @Equation203 Fin3 reff246_inst.
Proof. unfold Equation203. intro H. specialize (H F3_1). unfold magma_op, reff246_inst, reff246_op in H. discriminate H. Qed.

Lemma reff246_not255 : ~ @Equation255 Fin3 reff246_inst.
Proof. unfold Equation255. intro H. specialize (H F3_2). unfold magma_op, reff246_inst, reff246_op in H. discriminate H. Qed.

Lemma reff246_not307 : ~ @Equation307 Fin3 reff246_inst.
Proof. unfold Equation307. intro H. specialize (H F3_1). unfold magma_op, reff246_inst, reff246_op in H. discriminate H. Qed.

Lemma reff246_not411 : ~ @Equation411 Fin3 reff246_inst.
Proof. unfold Equation411. intro H. specialize (H F3_2). unfold magma_op, reff246_inst, reff246_op in H. discriminate H. Qed.

Lemma reff246_not614 : ~ @Equation614 Fin3 reff246_inst.
Proof. unfold Equation614. intro H. specialize (H F3_1). unfold magma_op, reff246_inst, reff246_op in H. discriminate H. Qed.

Lemma reff246_not817 : ~ @Equation817 Fin3 reff246_inst.
Proof. unfold Equation817. intro H. specialize (H F3_1). unfold magma_op, reff246_inst, reff246_op in H. discriminate H. Qed.

Lemma reff246_not1020 : ~ @Equation1020 Fin3 reff246_inst.
Proof. unfold Equation1020. intro H. specialize (H F3_2). unfold magma_op, reff246_inst, reff246_op in H. discriminate H. Qed.

Lemma reff246_not1223 : ~ @Equation1223 Fin3 reff246_inst.
Proof. unfold Equation1223. intro H. specialize (H F3_1). unfold magma_op, reff246_inst, reff246_op in H. discriminate H. Qed.

Lemma reff246_not1426 : ~ @Equation1426 Fin3 reff246_inst.
Proof. unfold Equation1426. intro H. specialize (H F3_1). unfold magma_op, reff246_inst, reff246_op in H. discriminate H. Qed.

Lemma reff246_not1629 : ~ @Equation1629 Fin3 reff246_inst.
Proof. unfold Equation1629. intro H. specialize (H F3_1). unfold magma_op, reff246_inst, reff246_op in H. discriminate H. Qed.

Lemma reff246_not1832 : ~ @Equation1832 Fin3 reff246_inst.
Proof. unfold Equation1832. intro H. specialize (H F3_2). unfold magma_op, reff246_inst, reff246_op in H. discriminate H. Qed.

Lemma reff246_not2035 : ~ @Equation2035 Fin3 reff246_inst.
Proof. unfold Equation2035. intro H. specialize (H F3_1). unfold magma_op, reff246_inst, reff246_op in H. discriminate H. Qed.

Lemma reff246_not2238 : ~ @Equation2238 Fin3 reff246_inst.
Proof. unfold Equation2238. intro H. specialize (H F3_1). unfold magma_op, reff246_inst, reff246_op in H. discriminate H. Qed.

Lemma reff246_not2442 : ~ @Equation2442 Fin3 reff246_inst.
Proof. unfold Equation2442. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff246_inst, reff246_op in H. discriminate H. Qed.

Lemma reff246_not2444 : ~ @Equation2444 Fin3 reff246_inst.
Proof. unfold Equation2444. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff246_inst, reff246_op in H. discriminate H. Qed.

Lemma reff246_not2446 : ~ @Equation2446 Fin3 reff246_inst.
Proof. unfold Equation2446. intro H. specialize (H F3_1 F3_0). unfold magma_op, reff246_inst, reff246_op in H. discriminate H. Qed.

Lemma reff246_not2447 : ~ @Equation2447 Fin3 reff246_inst.
Proof. unfold Equation2447. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff246_inst, reff246_op in H. discriminate H. Qed.

Lemma reff246_not2449 : ~ @Equation2449 Fin3 reff246_inst.
Proof. unfold Equation2449. intro H. specialize (H F3_1 F3_2). unfold magma_op, reff246_inst, reff246_op in H. discriminate H. Qed.

Lemma reff246_not2450 : ~ @Equation2450 Fin3 reff246_inst.
Proof. unfold Equation2450. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff246_inst, reff246_op in H. discriminate H. Qed.

Lemma reff246_not2456 : ~ @Equation2456 Fin3 reff246_inst.
Proof. unfold Equation2456. intro H. specialize (H F3_1 F3_0). unfold magma_op, reff246_inst, reff246_op in H. discriminate H. Qed.

Lemma reff246_not2457 : ~ @Equation2457 Fin3 reff246_inst.
Proof. unfold Equation2457. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff246_inst, reff246_op in H. discriminate H. Qed.

Lemma reff246_not2459 : ~ @Equation2459 Fin3 reff246_inst.
Proof. unfold Equation2459. intro H. specialize (H F3_1 F3_2). unfold magma_op, reff246_inst, reff246_op in H. discriminate H. Qed.

Lemma reff246_not2460 : ~ @Equation2460 Fin3 reff246_inst.
Proof. unfold Equation2460. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff246_inst, reff246_op in H. discriminate H. Qed.

Lemma reff246_not2466 : ~ @Equation2466 Fin3 reff246_inst.
Proof. unfold Equation2466. intro H. specialize (H F3_1 F3_0). unfold magma_op, reff246_inst, reff246_op in H. discriminate H. Qed.

Lemma reff246_not2467 : ~ @Equation2467 Fin3 reff246_inst.
Proof. unfold Equation2467. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff246_inst, reff246_op in H. discriminate H. Qed.

Lemma reff246_not2469 : ~ @Equation2469 Fin3 reff246_inst.
Proof. unfold Equation2469. intro H. specialize (H F3_1 F3_2). unfold magma_op, reff246_inst, reff246_op in H. discriminate H. Qed.

Lemma reff246_not2470 : ~ @Equation2470 Fin3 reff246_inst.
Proof. unfold Equation2470. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff246_inst, reff246_op in H. discriminate H. Qed.

Lemma reff246_not2493 : ~ @Equation2493 Fin3 reff246_inst.
Proof. unfold Equation2493. intro H. specialize (H F3_2 F3_0). unfold magma_op, reff246_inst, reff246_op in H. discriminate H. Qed.

Lemma reff246_not2494 : ~ @Equation2494 Fin3 reff246_inst.
Proof. unfold Equation2494. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff246_inst, reff246_op in H. discriminate H. Qed.

Lemma reff246_not2496 : ~ @Equation2496 Fin3 reff246_inst.
Proof. unfold Equation2496. intro H. specialize (H F3_2 F3_1). unfold magma_op, reff246_inst, reff246_op in H. discriminate H. Qed.

Lemma reff246_not2497 : ~ @Equation2497 Fin3 reff246_inst.
Proof. unfold Equation2497. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff246_inst, reff246_op in H. discriminate H. Qed.

Lemma reff246_not2503 : ~ @Equation2503 Fin3 reff246_inst.
Proof. unfold Equation2503. intro H. specialize (H F3_1 F3_0). unfold magma_op, reff246_inst, reff246_op in H. discriminate H. Qed.

Lemma reff246_not2504 : ~ @Equation2504 Fin3 reff246_inst.
Proof. unfold Equation2504. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff246_inst, reff246_op in H. discriminate H. Qed.

Lemma reff246_not2506 : ~ @Equation2506 Fin3 reff246_inst.
Proof. unfold Equation2506. intro H. specialize (H F3_2 F3_1). unfold magma_op, reff246_inst, reff246_op in H. discriminate H. Qed.

Lemma reff246_not2507 : ~ @Equation2507 Fin3 reff246_inst.
Proof. unfold Equation2507. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff246_inst, reff246_op in H. discriminate H. Qed.

Lemma reff246_not2530 : ~ @Equation2530 Fin3 reff246_inst.
Proof. unfold Equation2530. intro H. specialize (H F3_1 F3_0). unfold magma_op, reff246_inst, reff246_op in H. discriminate H. Qed.

Lemma reff246_not2531 : ~ @Equation2531 Fin3 reff246_inst.
Proof. unfold Equation2531. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff246_inst, reff246_op in H. discriminate H. Qed.

Lemma reff246_not2533 : ~ @Equation2533 Fin3 reff246_inst.
Proof. unfold Equation2533. intro H. specialize (H F3_2 F3_1). unfold magma_op, reff246_inst, reff246_op in H. discriminate H. Qed.

Lemma reff246_not2534 : ~ @Equation2534 Fin3 reff246_inst.
Proof. unfold Equation2534. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff246_inst, reff246_op in H. discriminate H. Qed.

Lemma reff246_not2540 : ~ @Equation2540 Fin3 reff246_inst.
Proof. unfold Equation2540. intro H. specialize (H F3_1 F3_0). unfold magma_op, reff246_inst, reff246_op in H. discriminate H. Qed.

Lemma reff246_not2541 : ~ @Equation2541 Fin3 reff246_inst.
Proof. unfold Equation2541. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff246_inst, reff246_op in H. discriminate H. Qed.

Lemma reff246_not2645 : ~ @Equation2645 Fin3 reff246_inst.
Proof. unfold Equation2645. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff246_inst, reff246_op in H. discriminate H. Qed.

Lemma reff246_not2647 : ~ @Equation2647 Fin3 reff246_inst.
Proof. unfold Equation2647. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff246_inst, reff246_op in H. discriminate H. Qed.

Lemma reff246_not2649 : ~ @Equation2649 Fin3 reff246_inst.
Proof. unfold Equation2649. intro H. specialize (H F3_2 F3_0). unfold magma_op, reff246_inst, reff246_op in H. discriminate H. Qed.

Lemma reff246_not2650 : ~ @Equation2650 Fin3 reff246_inst.
Proof. unfold Equation2650. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff246_inst, reff246_op in H. discriminate H. Qed.

Lemma reff246_not2652 : ~ @Equation2652 Fin3 reff246_inst.
Proof. unfold Equation2652. intro H. specialize (H F3_2 F3_1). unfold magma_op, reff246_inst, reff246_op in H. discriminate H. Qed.

Lemma reff246_not2653 : ~ @Equation2653 Fin3 reff246_inst.
Proof. unfold Equation2653. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff246_inst, reff246_op in H. discriminate H. Qed.

Lemma reff246_not2659 : ~ @Equation2659 Fin3 reff246_inst.
Proof. unfold Equation2659. intro H. specialize (H F3_1 F3_0). unfold magma_op, reff246_inst, reff246_op in H. discriminate H. Qed.

Lemma reff246_not2660 : ~ @Equation2660 Fin3 reff246_inst.
Proof. unfold Equation2660. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff246_inst, reff246_op in H. discriminate H. Qed.

Lemma reff246_not2662 : ~ @Equation2662 Fin3 reff246_inst.
Proof. unfold Equation2662. intro H. specialize (H F3_1 F3_2). unfold magma_op, reff246_inst, reff246_op in H. discriminate H. Qed.

Lemma reff246_not2663 : ~ @Equation2663 Fin3 reff246_inst.
Proof. unfold Equation2663. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff246_inst, reff246_op in H. discriminate H. Qed.

Lemma reff246_not2669 : ~ @Equation2669 Fin3 reff246_inst.
Proof. unfold Equation2669. intro H. specialize (H F3_1 F3_0). unfold magma_op, reff246_inst, reff246_op in H. discriminate H. Qed.

Lemma reff246_not2670 : ~ @Equation2670 Fin3 reff246_inst.
Proof. unfold Equation2670. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff246_inst, reff246_op in H. discriminate H. Qed.

Lemma reff246_not2672 : ~ @Equation2672 Fin3 reff246_inst.
Proof. unfold Equation2672. intro H. specialize (H F3_2 F3_1). unfold magma_op, reff246_inst, reff246_op in H. discriminate H. Qed.

Lemma reff246_not2673 : ~ @Equation2673 Fin3 reff246_inst.
Proof. unfold Equation2673. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff246_inst, reff246_op in H. discriminate H. Qed.

Lemma reff246_not2696 : ~ @Equation2696 Fin3 reff246_inst.
Proof. unfold Equation2696. intro H. specialize (H F3_1 F3_0). unfold magma_op, reff246_inst, reff246_op in H. discriminate H. Qed.

Lemma reff246_not2697 : ~ @Equation2697 Fin3 reff246_inst.
Proof. unfold Equation2697. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff246_inst, reff246_op in H. discriminate H. Qed.

Lemma reff246_not2699 : ~ @Equation2699 Fin3 reff246_inst.
Proof. unfold Equation2699. intro H. specialize (H F3_1 F3_2). unfold magma_op, reff246_inst, reff246_op in H. discriminate H. Qed.

Lemma reff246_not2700 : ~ @Equation2700 Fin3 reff246_inst.
Proof. unfold Equation2700. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff246_inst, reff246_op in H. discriminate H. Qed.

Lemma reff246_not2706 : ~ @Equation2706 Fin3 reff246_inst.
Proof. unfold Equation2706. intro H. specialize (H F3_1 F3_0). unfold magma_op, reff246_inst, reff246_op in H. discriminate H. Qed.

Lemma reff246_not2707 : ~ @Equation2707 Fin3 reff246_inst.
Proof. unfold Equation2707. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff246_inst, reff246_op in H. discriminate H. Qed.

Lemma reff246_not2709 : ~ @Equation2709 Fin3 reff246_inst.
Proof. unfold Equation2709. intro H. specialize (H F3_2 F3_1). unfold magma_op, reff246_inst, reff246_op in H. discriminate H. Qed.

Lemma reff246_not2710 : ~ @Equation2710 Fin3 reff246_inst.
Proof. unfold Equation2710. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff246_inst, reff246_op in H. discriminate H. Qed.

Lemma reff246_not2733 : ~ @Equation2733 Fin3 reff246_inst.
Proof. unfold Equation2733. intro H. specialize (H F3_1 F3_0). unfold magma_op, reff246_inst, reff246_op in H. discriminate H. Qed.

Lemma reff246_not2734 : ~ @Equation2734 Fin3 reff246_inst.
Proof. unfold Equation2734. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff246_inst, reff246_op in H. discriminate H. Qed.

Lemma reff246_not2736 : ~ @Equation2736 Fin3 reff246_inst.
Proof. unfold Equation2736. intro H. specialize (H F3_1 F3_2). unfold magma_op, reff246_inst, reff246_op in H. discriminate H. Qed.

Lemma reff246_not2737 : ~ @Equation2737 Fin3 reff246_inst.
Proof. unfold Equation2737. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff246_inst, reff246_op in H. discriminate H. Qed.

Lemma reff246_not2743 : ~ @Equation2743 Fin3 reff246_inst.
Proof. unfold Equation2743. intro H. specialize (H F3_1 F3_0). unfold magma_op, reff246_inst, reff246_op in H. discriminate H. Qed.

Lemma reff246_not2744 : ~ @Equation2744 Fin3 reff246_inst.
Proof. unfold Equation2744. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff246_inst, reff246_op in H. discriminate H. Qed.

Lemma reff246_not2847 : ~ @Equation2847 Fin3 reff246_inst.
Proof. unfold Equation2847. intro H. specialize (H F3_1). unfold magma_op, reff246_inst, reff246_op in H. discriminate H. Qed.

Lemma reff246_not3050 : ~ @Equation3050 Fin3 reff246_inst.
Proof. unfold Equation3050. intro H. specialize (H F3_1). unfold magma_op, reff246_inst, reff246_op in H. discriminate H. Qed.

Lemma reff246_not3254 : ~ @Equation3254 Fin3 reff246_inst.
Proof. unfold Equation3254. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff246_inst, reff246_op in H. discriminate H. Qed.

Lemma reff246_not3255 : ~ @Equation3255 Fin3 reff246_inst.
Proof. unfold Equation3255. intro H. specialize (H F3_1 F3_0). unfold magma_op, reff246_inst, reff246_op in H. discriminate H. Qed.

Lemma reff246_not3256 : ~ @Equation3256 Fin3 reff246_inst.
Proof. unfold Equation3256. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff246_inst, reff246_op in H. discriminate H. Qed.

Lemma reff246_not3258 : ~ @Equation3258 Fin3 reff246_inst.
Proof. unfold Equation3258. intro H. specialize (H F3_1 F3_0). unfold magma_op, reff246_inst, reff246_op in H. discriminate H. Qed.

Lemma reff246_not3259 : ~ @Equation3259 Fin3 reff246_inst.
Proof. unfold Equation3259. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff246_inst, reff246_op in H. discriminate H. Qed.

Lemma reff246_not3261 : ~ @Equation3261 Fin3 reff246_inst.
Proof. unfold Equation3261. intro H. specialize (H F3_1 F3_2). unfold magma_op, reff246_inst, reff246_op in H. discriminate H. Qed.

Lemma reff246_not3262 : ~ @Equation3262 Fin3 reff246_inst.
Proof. unfold Equation3262. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff246_inst, reff246_op in H. discriminate H. Qed.

Lemma reff246_not3268 : ~ @Equation3268 Fin3 reff246_inst.
Proof. unfold Equation3268. intro H. specialize (H F3_1 F3_0). unfold magma_op, reff246_inst, reff246_op in H. discriminate H. Qed.

Lemma reff246_not3271 : ~ @Equation3271 Fin3 reff246_inst.
Proof. unfold Equation3271. intro H. specialize (H F3_1 F3_2). unfold magma_op, reff246_inst, reff246_op in H. discriminate H. Qed.

Lemma reff246_not3272 : ~ @Equation3272 Fin3 reff246_inst.
Proof. unfold Equation3272. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff246_inst, reff246_op in H. discriminate H. Qed.

Lemma reff246_not3278 : ~ @Equation3278 Fin3 reff246_inst.
Proof. unfold Equation3278. intro H. specialize (H F3_1 F3_2). unfold magma_op, reff246_inst, reff246_op in H. discriminate H. Qed.

Lemma reff246_not3279 : ~ @Equation3279 Fin3 reff246_inst.
Proof. unfold Equation3279. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff246_inst, reff246_op in H. discriminate H. Qed.

Lemma reff246_not3281 : ~ @Equation3281 Fin3 reff246_inst.
Proof. unfold Equation3281. intro H. specialize (H F3_1 F3_0). unfold magma_op, reff246_inst, reff246_op in H. discriminate H. Qed.

Lemma reff246_not3308 : ~ @Equation3308 Fin3 reff246_inst.
Proof. unfold Equation3308. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff246_inst, reff246_op in H. discriminate H. Qed.

Lemma reff246_not3309 : ~ @Equation3309 Fin3 reff246_inst.
Proof. unfold Equation3309. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff246_inst, reff246_op in H. discriminate H. Qed.

Lemma reff246_not3315 : ~ @Equation3315 Fin3 reff246_inst.
Proof. unfold Equation3315. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff246_inst, reff246_op in H. discriminate H. Qed.

Lemma reff246_not3316 : ~ @Equation3316 Fin3 reff246_inst.
Proof. unfold Equation3316. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff246_inst, reff246_op in H. discriminate H. Qed.

Lemma reff246_not3318 : ~ @Equation3318 Fin3 reff246_inst.
Proof. unfold Equation3318. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff246_inst, reff246_op in H. discriminate H. Qed.

Lemma reff246_not3319 : ~ @Equation3319 Fin3 reff246_inst.
Proof. unfold Equation3319. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff246_inst, reff246_op in H. discriminate H. Qed.

Lemma reff246_not3342 : ~ @Equation3342 Fin3 reff246_inst.
Proof. unfold Equation3342. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff246_inst, reff246_op in H. discriminate H. Qed.

Lemma reff246_not3343 : ~ @Equation3343 Fin3 reff246_inst.
Proof. unfold Equation3343. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff246_inst, reff246_op in H. discriminate H. Qed.

Lemma reff246_not3345 : ~ @Equation3345 Fin3 reff246_inst.
Proof. unfold Equation3345. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff246_inst, reff246_op in H. discriminate H. Qed.

Lemma reff246_not3346 : ~ @Equation3346 Fin3 reff246_inst.
Proof. unfold Equation3346. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff246_inst, reff246_op in H. discriminate H. Qed.

Lemma reff246_not3352 : ~ @Equation3352 Fin3 reff246_inst.
Proof. unfold Equation3352. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff246_inst, reff246_op in H. discriminate H. Qed.

Lemma reff246_not3353 : ~ @Equation3353 Fin3 reff246_inst.
Proof. unfold Equation3353. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff246_inst, reff246_op in H. discriminate H. Qed.

Lemma reff246_not3456 : ~ @Equation3456 Fin3 reff246_inst.
Proof. unfold Equation3456. intro H. specialize (H F3_1). unfold magma_op, reff246_inst, reff246_op in H. discriminate H. Qed.

Lemma reff246_not3659 : ~ @Equation3659 Fin3 reff246_inst.
Proof. unfold Equation3659. intro H. specialize (H F3_1). unfold magma_op, reff246_inst, reff246_op in H. discriminate H. Qed.

Lemma reff246_not3862 : ~ @Equation3862 Fin3 reff246_inst.
Proof. unfold Equation3862. intro H. specialize (H F3_2). unfold magma_op, reff246_inst, reff246_op in H. discriminate H. Qed.

Lemma reff246_not4065 : ~ @Equation4065 Fin3 reff246_inst.
Proof. unfold Equation4065. intro H. specialize (H F3_1). unfold magma_op, reff246_inst, reff246_op in H. discriminate H. Qed.

Lemma reff246_not4268 : ~ @Equation4268 Fin3 reff246_inst.
Proof. unfold Equation4268. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff246_inst, reff246_op in H. discriminate H. Qed.

Lemma reff246_not4269 : ~ @Equation4269 Fin3 reff246_inst.
Proof. unfold Equation4269. intro H. specialize (H F3_1 F3_0). unfold magma_op, reff246_inst, reff246_op in H. discriminate H. Qed.

Lemma reff246_not4270 : ~ @Equation4270 Fin3 reff246_inst.
Proof. unfold Equation4270. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff246_inst, reff246_op in H. discriminate H. Qed.

Lemma reff246_not4272 : ~ @Equation4272 Fin3 reff246_inst.
Proof. unfold Equation4272. intro H. specialize (H F3_1 F3_0). unfold magma_op, reff246_inst, reff246_op in H. discriminate H. Qed.

Lemma reff246_not4273 : ~ @Equation4273 Fin3 reff246_inst.
Proof. unfold Equation4273. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff246_inst, reff246_op in H. discriminate H. Qed.

Lemma reff246_not4275 : ~ @Equation4275 Fin3 reff246_inst.
Proof. unfold Equation4275. intro H. specialize (H F3_1 F3_2). unfold magma_op, reff246_inst, reff246_op in H. discriminate H. Qed.

Lemma reff246_not4276 : ~ @Equation4276 Fin3 reff246_inst.
Proof. unfold Equation4276. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff246_inst, reff246_op in H. discriminate H. Qed.

Lemma reff246_not4283 : ~ @Equation4283 Fin3 reff246_inst.
Proof. unfold Equation4283. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff246_inst, reff246_op in H. discriminate H. Qed.

Lemma reff246_not4284 : ~ @Equation4284 Fin3 reff246_inst.
Proof. unfold Equation4284. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff246_inst, reff246_op in H. discriminate H. Qed.

Lemma reff246_not4290 : ~ @Equation4290 Fin3 reff246_inst.
Proof. unfold Equation4290. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff246_inst, reff246_op in H. discriminate H. Qed.

Lemma reff246_not4291 : ~ @Equation4291 Fin3 reff246_inst.
Proof. unfold Equation4291. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff246_inst, reff246_op in H. discriminate H. Qed.

Lemma reff246_not4293 : ~ @Equation4293 Fin3 reff246_inst.
Proof. unfold Equation4293. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff246_inst, reff246_op in H. discriminate H. Qed.

Lemma reff246_not4314 : ~ @Equation4314 Fin3 reff246_inst.
Proof. unfold Equation4314. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff246_inst, reff246_op in H. discriminate H. Qed.

Lemma reff246_not4321 : ~ @Equation4321 Fin3 reff246_inst.
Proof. unfold Equation4321. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff246_inst, reff246_op in H. discriminate H. Qed.

Lemma reff246_not4343 : ~ @Equation4343 Fin3 reff246_inst.
Proof. unfold Equation4343. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff246_inst, reff246_op in H. discriminate H. Qed.

Lemma reff246_not4380 : ~ @Equation4380 Fin3 reff246_inst.
Proof. unfold Equation4380. intro H. specialize (H F3_1). unfold magma_op, reff246_inst, reff246_op in H. discriminate H. Qed.

Lemma reff246_not4583 : ~ @Equation4583 Fin3 reff246_inst.
Proof. unfold Equation4583. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff246_inst, reff246_op in H. discriminate H. Qed.

Lemma reff246_not4584 : ~ @Equation4584 Fin3 reff246_inst.
Proof. unfold Equation4584. intro H. specialize (H F3_1 F3_0). unfold magma_op, reff246_inst, reff246_op in H. discriminate H. Qed.

Lemma reff246_not4585 : ~ @Equation4585 Fin3 reff246_inst.
Proof. unfold Equation4585. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff246_inst, reff246_op in H. discriminate H. Qed.

Lemma reff246_not4587 : ~ @Equation4587 Fin3 reff246_inst.
Proof. unfold Equation4587. intro H. specialize (H F3_1 F3_0). unfold magma_op, reff246_inst, reff246_op in H. discriminate H. Qed.

Lemma reff246_not4588 : ~ @Equation4588 Fin3 reff246_inst.
Proof. unfold Equation4588. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff246_inst, reff246_op in H. discriminate H. Qed.

Lemma reff246_not4590 : ~ @Equation4590 Fin3 reff246_inst.
Proof. unfold Equation4590. intro H. specialize (H F3_1 F3_0). unfold magma_op, reff246_inst, reff246_op in H. discriminate H. Qed.

Lemma reff246_not4591 : ~ @Equation4591 Fin3 reff246_inst.
Proof. unfold Equation4591. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff246_inst, reff246_op in H. discriminate H. Qed.

Lemma reff246_not4598 : ~ @Equation4598 Fin3 reff246_inst.
Proof. unfold Equation4598. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff246_inst, reff246_op in H. discriminate H. Qed.

Lemma reff246_not4599 : ~ @Equation4599 Fin3 reff246_inst.
Proof. unfold Equation4599. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff246_inst, reff246_op in H. discriminate H. Qed.

Lemma reff246_not4605 : ~ @Equation4605 Fin3 reff246_inst.
Proof. unfold Equation4605. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff246_inst, reff246_op in H. discriminate H. Qed.

Lemma reff246_not4606 : ~ @Equation4606 Fin3 reff246_inst.
Proof. unfold Equation4606. intro H. specialize (H F3_1 F3_2). unfold magma_op, reff246_inst, reff246_op in H. discriminate H. Qed.

Lemma reff246_not4608 : ~ @Equation4608 Fin3 reff246_inst.
Proof. unfold Equation4608. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff246_inst, reff246_op in H. discriminate H. Qed.

Lemma reff246_not4629 : ~ @Equation4629 Fin3 reff246_inst.
Proof. unfold Equation4629. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff246_inst, reff246_op in H. discriminate H. Qed.

Lemma reff246_not4635 : ~ @Equation4635 Fin3 reff246_inst.
Proof. unfold Equation4635. intro H. specialize (H F3_1 F3_0). unfold magma_op, reff246_inst, reff246_op in H. discriminate H. Qed.

Lemma reff246_not4636 : ~ @Equation4636 Fin3 reff246_inst.
Proof. unfold Equation4636. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff246_inst, reff246_op in H. discriminate H. Qed.

Lemma reff246_not4658 : ~ @Equation4658 Fin3 reff246_inst.
Proof. unfold Equation4658. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff246_inst, reff246_op in H. discriminate H. Qed.

(** ---- reff250 (Fin3) ---- *)

Definition reff250_op (x y : Fin3) : Fin3 :=
  match x, y with
  | F3_0, F3_0 => F3_0 | F3_0, F3_1 => F3_1 | F3_0, F3_2 => F3_2
  | F3_1, F3_0 => F3_0 | F3_1, F3_1 => F3_2 | F3_1, F3_2 => F3_1
  | F3_2, F3_0 => F3_1 | F3_2, F3_1 => F3_1 | F3_2, F3_2 => F3_1
  end.

#[local] Instance reff250_inst : Magma Fin3 := {| magma_op := reff250_op |}.

Lemma reff250_sat151 : @Equation151 Fin3 reff250_inst.
Proof. unfold Equation151, magma_op, reff250_inst, reff250_op. intros x. destruct x; reflexivity. Qed.

Lemma reff250_sat1426 : @Equation1426 Fin3 reff250_inst.
Proof. unfold Equation1426, magma_op, reff250_inst, reff250_op. intros x. destruct x; reflexivity. Qed.

Lemma reff250_sat1634 : @Equation1634 Fin3 reff250_inst.
Proof. unfold Equation1634, magma_op, reff250_inst, reff250_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff250_sat1847 : @Equation1847 Fin3 reff250_inst.
Proof. unfold Equation1847, magma_op, reff250_inst, reff250_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff250_sat2050 : @Equation2050 Fin3 reff250_inst.
Proof. unfold Equation2050, magma_op, reff250_inst, reff250_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff250_sat2087 : @Equation2087 Fin3 reff250_inst.
Proof. unfold Equation2087, magma_op, reff250_inst, reff250_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff250_sat3306 : @Equation3306 Fin3 reff250_inst.
Proof. unfold Equation3306, magma_op, reff250_inst, reff250_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff250_sat3456 : @Equation3456 Fin3 reff250_inst.
Proof. unfold Equation3456, magma_op, reff250_inst, reff250_op. intros x. destruct x; reflexivity. Qed.

Lemma reff250_sat3887 : @Equation3887 Fin3 reff250_inst.
Proof. unfold Equation3887, magma_op, reff250_inst, reff250_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff250_sat4065 : @Equation4065 Fin3 reff250_inst.
Proof. unfold Equation4065, magma_op, reff250_inst, reff250_op. intros x. destruct x; reflexivity. Qed.

Lemma reff250_sat4380 : @Equation4380 Fin3 reff250_inst.
Proof. unfold Equation4380, magma_op, reff250_inst, reff250_op. intros x. destruct x; reflexivity. Qed.

Lemma reff250_not47 : ~ @Equation47 Fin3 reff250_inst.
Proof. unfold Equation47. intro H. specialize (H F3_1). unfold magma_op, reff250_inst, reff250_op in H. discriminate H. Qed.

Lemma reff250_not99 : ~ @Equation99 Fin3 reff250_inst.
Proof. unfold Equation99. intro H. specialize (H F3_1). unfold magma_op, reff250_inst, reff250_op in H. discriminate H. Qed.

Lemma reff250_not154 : ~ @Equation154 Fin3 reff250_inst.
Proof. unfold Equation154. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff250_inst, reff250_op in H. discriminate H. Qed.

Lemma reff250_not157 : ~ @Equation157 Fin3 reff250_inst.
Proof. unfold Equation157. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff250_inst, reff250_op in H. discriminate H. Qed.

Lemma reff250_not159 : ~ @Equation159 Fin3 reff250_inst.
Proof. unfold Equation159. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff250_inst, reff250_op in H. discriminate H. Qed.

Lemma reff250_not160 : ~ @Equation160 Fin3 reff250_inst.
Proof. unfold Equation160. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff250_inst, reff250_op in H. discriminate H. Qed.

Lemma reff250_not167 : ~ @Equation167 Fin3 reff250_inst.
Proof. unfold Equation167. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff250_inst, reff250_op in H. discriminate H. Qed.

Lemma reff250_not169 : ~ @Equation169 Fin3 reff250_inst.
Proof. unfold Equation169. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff250_inst, reff250_op in H. discriminate H. Qed.

Lemma reff250_not170 : ~ @Equation170 Fin3 reff250_inst.
Proof. unfold Equation170. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff250_inst, reff250_op in H. discriminate H. Qed.

Lemma reff250_not176 : ~ @Equation176 Fin3 reff250_inst.
Proof. unfold Equation176. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff250_inst, reff250_op in H. discriminate H. Qed.

Lemma reff250_not177 : ~ @Equation177 Fin3 reff250_inst.
Proof. unfold Equation177. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff250_inst, reff250_op in H. discriminate H. Qed.

Lemma reff250_not179 : ~ @Equation179 Fin3 reff250_inst.
Proof. unfold Equation179. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff250_inst, reff250_op in H. discriminate H. Qed.

Lemma reff250_not203 : ~ @Equation203 Fin3 reff250_inst.
Proof. unfold Equation203. intro H. specialize (H F3_1). unfold magma_op, reff250_inst, reff250_op in H. discriminate H. Qed.

Lemma reff250_not255 : ~ @Equation255 Fin3 reff250_inst.
Proof. unfold Equation255. intro H. specialize (H F3_1). unfold magma_op, reff250_inst, reff250_op in H. discriminate H. Qed.

Lemma reff250_not307 : ~ @Equation307 Fin3 reff250_inst.
Proof. unfold Equation307. intro H. specialize (H F3_1). unfold magma_op, reff250_inst, reff250_op in H. discriminate H. Qed.

Lemma reff250_not359 : ~ @Equation359 Fin3 reff250_inst.
Proof. unfold Equation359. intro H. specialize (H F3_1). unfold magma_op, reff250_inst, reff250_op in H. discriminate H. Qed.

Lemma reff250_not411 : ~ @Equation411 Fin3 reff250_inst.
Proof. unfold Equation411. intro H. specialize (H F3_2). unfold magma_op, reff250_inst, reff250_op in H. discriminate H. Qed.

Lemma reff250_not614 : ~ @Equation614 Fin3 reff250_inst.
Proof. unfold Equation614. intro H. specialize (H F3_2). unfold magma_op, reff250_inst, reff250_op in H. discriminate H. Qed.

Lemma reff250_not817 : ~ @Equation817 Fin3 reff250_inst.
Proof. unfold Equation817. intro H. specialize (H F3_1). unfold magma_op, reff250_inst, reff250_op in H. discriminate H. Qed.

Lemma reff250_not1020 : ~ @Equation1020 Fin3 reff250_inst.
Proof. unfold Equation1020. intro H. specialize (H F3_2). unfold magma_op, reff250_inst, reff250_op in H. discriminate H. Qed.

Lemma reff250_not1223 : ~ @Equation1223 Fin3 reff250_inst.
Proof. unfold Equation1223. intro H. specialize (H F3_2). unfold magma_op, reff250_inst, reff250_op in H. discriminate H. Qed.

Lemma reff250_not1427 : ~ @Equation1427 Fin3 reff250_inst.
Proof. unfold Equation1427. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff250_inst, reff250_op in H. discriminate H. Qed.

Lemma reff250_not1428 : ~ @Equation1428 Fin3 reff250_inst.
Proof. unfold Equation1428. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff250_inst, reff250_op in H. discriminate H. Qed.

Lemma reff250_not1429 : ~ @Equation1429 Fin3 reff250_inst.
Proof. unfold Equation1429. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff250_inst, reff250_op in H. discriminate H. Qed.

Lemma reff250_not1431 : ~ @Equation1431 Fin3 reff250_inst.
Proof. unfold Equation1431. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff250_inst, reff250_op in H. discriminate H. Qed.

Lemma reff250_not1432 : ~ @Equation1432 Fin3 reff250_inst.
Proof. unfold Equation1432. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff250_inst, reff250_op in H. discriminate H. Qed.

Lemma reff250_not1434 : ~ @Equation1434 Fin3 reff250_inst.
Proof. unfold Equation1434. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff250_inst, reff250_op in H. discriminate H. Qed.

Lemma reff250_not1435 : ~ @Equation1435 Fin3 reff250_inst.
Proof. unfold Equation1435. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff250_inst, reff250_op in H. discriminate H. Qed.

Lemma reff250_not1441 : ~ @Equation1441 Fin3 reff250_inst.
Proof. unfold Equation1441. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff250_inst, reff250_op in H. discriminate H. Qed.

Lemma reff250_not1442 : ~ @Equation1442 Fin3 reff250_inst.
Proof. unfold Equation1442. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff250_inst, reff250_op in H. discriminate H. Qed.

Lemma reff250_not1444 : ~ @Equation1444 Fin3 reff250_inst.
Proof. unfold Equation1444. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff250_inst, reff250_op in H. discriminate H. Qed.

Lemma reff250_not1445 : ~ @Equation1445 Fin3 reff250_inst.
Proof. unfold Equation1445. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff250_inst, reff250_op in H. discriminate H. Qed.

Lemma reff250_not1451 : ~ @Equation1451 Fin3 reff250_inst.
Proof. unfold Equation1451. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff250_inst, reff250_op in H. discriminate H. Qed.

Lemma reff250_not1452 : ~ @Equation1452 Fin3 reff250_inst.
Proof. unfold Equation1452. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff250_inst, reff250_op in H. discriminate H. Qed.

Lemma reff250_not1454 : ~ @Equation1454 Fin3 reff250_inst.
Proof. unfold Equation1454. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff250_inst, reff250_op in H. discriminate H. Qed.

Lemma reff250_not1455 : ~ @Equation1455 Fin3 reff250_inst.
Proof. unfold Equation1455. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff250_inst, reff250_op in H. discriminate H. Qed.

Lemma reff250_not1478 : ~ @Equation1478 Fin3 reff250_inst.
Proof. unfold Equation1478. intro H. specialize (H F3_1 F3_0). unfold magma_op, reff250_inst, reff250_op in H. discriminate H. Qed.

Lemma reff250_not1479 : ~ @Equation1479 Fin3 reff250_inst.
Proof. unfold Equation1479. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff250_inst, reff250_op in H. discriminate H. Qed.

Lemma reff250_not1481 : ~ @Equation1481 Fin3 reff250_inst.
Proof. unfold Equation1481. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff250_inst, reff250_op in H. discriminate H. Qed.

Lemma reff250_not1482 : ~ @Equation1482 Fin3 reff250_inst.
Proof. unfold Equation1482. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff250_inst, reff250_op in H. discriminate H. Qed.

Lemma reff250_not1488 : ~ @Equation1488 Fin3 reff250_inst.
Proof. unfold Equation1488. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff250_inst, reff250_op in H. discriminate H. Qed.

Lemma reff250_not1489 : ~ @Equation1489 Fin3 reff250_inst.
Proof. unfold Equation1489. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff250_inst, reff250_op in H. discriminate H. Qed.

Lemma reff250_not1491 : ~ @Equation1491 Fin3 reff250_inst.
Proof. unfold Equation1491. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff250_inst, reff250_op in H. discriminate H. Qed.

Lemma reff250_not1492 : ~ @Equation1492 Fin3 reff250_inst.
Proof. unfold Equation1492. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff250_inst, reff250_op in H. discriminate H. Qed.

Lemma reff250_not1515 : ~ @Equation1515 Fin3 reff250_inst.
Proof. unfold Equation1515. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff250_inst, reff250_op in H. discriminate H. Qed.

Lemma reff250_not1516 : ~ @Equation1516 Fin3 reff250_inst.
Proof. unfold Equation1516. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff250_inst, reff250_op in H. discriminate H. Qed.

Lemma reff250_not1518 : ~ @Equation1518 Fin3 reff250_inst.
Proof. unfold Equation1518. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff250_inst, reff250_op in H. discriminate H. Qed.

Lemma reff250_not1519 : ~ @Equation1519 Fin3 reff250_inst.
Proof. unfold Equation1519. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff250_inst, reff250_op in H. discriminate H. Qed.

Lemma reff250_not1525 : ~ @Equation1525 Fin3 reff250_inst.
Proof. unfold Equation1525. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff250_inst, reff250_op in H. discriminate H. Qed.

Lemma reff250_not1526 : ~ @Equation1526 Fin3 reff250_inst.
Proof. unfold Equation1526. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff250_inst, reff250_op in H. discriminate H. Qed.

Lemma reff250_not1528 : ~ @Equation1528 Fin3 reff250_inst.
Proof. unfold Equation1528. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff250_inst, reff250_op in H. discriminate H. Qed.

Lemma reff250_not1630 : ~ @Equation1630 Fin3 reff250_inst.
Proof. unfold Equation1630. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff250_inst, reff250_op in H. discriminate H. Qed.

Lemma reff250_not1631 : ~ @Equation1631 Fin3 reff250_inst.
Proof. unfold Equation1631. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff250_inst, reff250_op in H. discriminate H. Qed.

Lemma reff250_not1632 : ~ @Equation1632 Fin3 reff250_inst.
Proof. unfold Equation1632. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff250_inst, reff250_op in H. discriminate H. Qed.

Lemma reff250_not1635 : ~ @Equation1635 Fin3 reff250_inst.
Proof. unfold Equation1635. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff250_inst, reff250_op in H. discriminate H. Qed.

Lemma reff250_not1637 : ~ @Equation1637 Fin3 reff250_inst.
Proof. unfold Equation1637. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff250_inst, reff250_op in H. discriminate H. Qed.

Lemma reff250_not1638 : ~ @Equation1638 Fin3 reff250_inst.
Proof. unfold Equation1638. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff250_inst, reff250_op in H. discriminate H. Qed.

Lemma reff250_not1644 : ~ @Equation1644 Fin3 reff250_inst.
Proof. unfold Equation1644. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff250_inst, reff250_op in H. discriminate H. Qed.

Lemma reff250_not1645 : ~ @Equation1645 Fin3 reff250_inst.
Proof. unfold Equation1645. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff250_inst, reff250_op in H. discriminate H. Qed.

Lemma reff250_not1647 : ~ @Equation1647 Fin3 reff250_inst.
Proof. unfold Equation1647. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff250_inst, reff250_op in H. discriminate H. Qed.

Lemma reff250_not1648 : ~ @Equation1648 Fin3 reff250_inst.
Proof. unfold Equation1648. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff250_inst, reff250_op in H. discriminate H. Qed.

Lemma reff250_not1654 : ~ @Equation1654 Fin3 reff250_inst.
Proof. unfold Equation1654. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff250_inst, reff250_op in H. discriminate H. Qed.

Lemma reff250_not1655 : ~ @Equation1655 Fin3 reff250_inst.
Proof. unfold Equation1655. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff250_inst, reff250_op in H. discriminate H. Qed.

Lemma reff250_not1657 : ~ @Equation1657 Fin3 reff250_inst.
Proof. unfold Equation1657. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff250_inst, reff250_op in H. discriminate H. Qed.

Lemma reff250_not1658 : ~ @Equation1658 Fin3 reff250_inst.
Proof. unfold Equation1658. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff250_inst, reff250_op in H. discriminate H. Qed.

Lemma reff250_not1681 : ~ @Equation1681 Fin3 reff250_inst.
Proof. unfold Equation1681. intro H. specialize (H F3_1 F3_0). unfold magma_op, reff250_inst, reff250_op in H. discriminate H. Qed.

Lemma reff250_not1682 : ~ @Equation1682 Fin3 reff250_inst.
Proof. unfold Equation1682. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff250_inst, reff250_op in H. discriminate H. Qed.

Lemma reff250_not1684 : ~ @Equation1684 Fin3 reff250_inst.
Proof. unfold Equation1684. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff250_inst, reff250_op in H. discriminate H. Qed.

Lemma reff250_not1685 : ~ @Equation1685 Fin3 reff250_inst.
Proof. unfold Equation1685. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff250_inst, reff250_op in H. discriminate H. Qed.

Lemma reff250_not1691 : ~ @Equation1691 Fin3 reff250_inst.
Proof. unfold Equation1691. intro H. specialize (H F3_2 F3_0). unfold magma_op, reff250_inst, reff250_op in H. discriminate H. Qed.

Lemma reff250_not1692 : ~ @Equation1692 Fin3 reff250_inst.
Proof. unfold Equation1692. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff250_inst, reff250_op in H. discriminate H. Qed.

Lemma reff250_not1694 : ~ @Equation1694 Fin3 reff250_inst.
Proof. unfold Equation1694. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff250_inst, reff250_op in H. discriminate H. Qed.

Lemma reff250_not1695 : ~ @Equation1695 Fin3 reff250_inst.
Proof. unfold Equation1695. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff250_inst, reff250_op in H. discriminate H. Qed.

Lemma reff250_not1718 : ~ @Equation1718 Fin3 reff250_inst.
Proof. unfold Equation1718. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff250_inst, reff250_op in H. discriminate H. Qed.

Lemma reff250_not1719 : ~ @Equation1719 Fin3 reff250_inst.
Proof. unfold Equation1719. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff250_inst, reff250_op in H. discriminate H. Qed.

Lemma reff250_not1721 : ~ @Equation1721 Fin3 reff250_inst.
Proof. unfold Equation1721. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff250_inst, reff250_op in H. discriminate H. Qed.

Lemma reff250_not1722 : ~ @Equation1722 Fin3 reff250_inst.
Proof. unfold Equation1722. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff250_inst, reff250_op in H. discriminate H. Qed.

Lemma reff250_not1728 : ~ @Equation1728 Fin3 reff250_inst.
Proof. unfold Equation1728. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff250_inst, reff250_op in H. discriminate H. Qed.

Lemma reff250_not1729 : ~ @Equation1729 Fin3 reff250_inst.
Proof. unfold Equation1729. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff250_inst, reff250_op in H. discriminate H. Qed.

Lemma reff250_not1731 : ~ @Equation1731 Fin3 reff250_inst.
Proof. unfold Equation1731. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff250_inst, reff250_op in H. discriminate H. Qed.

Lemma reff250_not1833 : ~ @Equation1833 Fin3 reff250_inst.
Proof. unfold Equation1833. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff250_inst, reff250_op in H. discriminate H. Qed.

Lemma reff250_not1834 : ~ @Equation1834 Fin3 reff250_inst.
Proof. unfold Equation1834. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff250_inst, reff250_op in H. discriminate H. Qed.

Lemma reff250_not1835 : ~ @Equation1835 Fin3 reff250_inst.
Proof. unfold Equation1835. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff250_inst, reff250_op in H. discriminate H. Qed.

Lemma reff250_not1837 : ~ @Equation1837 Fin3 reff250_inst.
Proof. unfold Equation1837. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff250_inst, reff250_op in H. discriminate H. Qed.

Lemma reff250_not1838 : ~ @Equation1838 Fin3 reff250_inst.
Proof. unfold Equation1838. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff250_inst, reff250_op in H. discriminate H. Qed.

Lemma reff250_not1840 : ~ @Equation1840 Fin3 reff250_inst.
Proof. unfold Equation1840. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff250_inst, reff250_op in H. discriminate H. Qed.

Lemma reff250_not1841 : ~ @Equation1841 Fin3 reff250_inst.
Proof. unfold Equation1841. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff250_inst, reff250_op in H. discriminate H. Qed.

Lemma reff250_not1848 : ~ @Equation1848 Fin3 reff250_inst.
Proof. unfold Equation1848. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff250_inst, reff250_op in H. discriminate H. Qed.

Lemma reff250_not1850 : ~ @Equation1850 Fin3 reff250_inst.
Proof. unfold Equation1850. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff250_inst, reff250_op in H. discriminate H. Qed.

Lemma reff250_not1851 : ~ @Equation1851 Fin3 reff250_inst.
Proof. unfold Equation1851. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff250_inst, reff250_op in H. discriminate H. Qed.

Lemma reff250_not1857 : ~ @Equation1857 Fin3 reff250_inst.
Proof. unfold Equation1857. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff250_inst, reff250_op in H. discriminate H. Qed.

Lemma reff250_not1858 : ~ @Equation1858 Fin3 reff250_inst.
Proof. unfold Equation1858. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff250_inst, reff250_op in H. discriminate H. Qed.

Lemma reff250_not1860 : ~ @Equation1860 Fin3 reff250_inst.
Proof. unfold Equation1860. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff250_inst, reff250_op in H. discriminate H. Qed.

Lemma reff250_not1861 : ~ @Equation1861 Fin3 reff250_inst.
Proof. unfold Equation1861. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff250_inst, reff250_op in H. discriminate H. Qed.

Lemma reff250_not1884 : ~ @Equation1884 Fin3 reff250_inst.
Proof. unfold Equation1884. intro H. specialize (H F3_2 F3_1). unfold magma_op, reff250_inst, reff250_op in H. discriminate H. Qed.

Lemma reff250_not1885 : ~ @Equation1885 Fin3 reff250_inst.
Proof. unfold Equation1885. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff250_inst, reff250_op in H. discriminate H. Qed.

Lemma reff250_not1887 : ~ @Equation1887 Fin3 reff250_inst.
Proof. unfold Equation1887. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff250_inst, reff250_op in H. discriminate H. Qed.

Lemma reff250_not1888 : ~ @Equation1888 Fin3 reff250_inst.
Proof. unfold Equation1888. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff250_inst, reff250_op in H. discriminate H. Qed.

Lemma reff250_not1894 : ~ @Equation1894 Fin3 reff250_inst.
Proof. unfold Equation1894. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff250_inst, reff250_op in H. discriminate H. Qed.

Lemma reff250_not1895 : ~ @Equation1895 Fin3 reff250_inst.
Proof. unfold Equation1895. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff250_inst, reff250_op in H. discriminate H. Qed.

Lemma reff250_not1897 : ~ @Equation1897 Fin3 reff250_inst.
Proof. unfold Equation1897. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff250_inst, reff250_op in H. discriminate H. Qed.

Lemma reff250_not1898 : ~ @Equation1898 Fin3 reff250_inst.
Proof. unfold Equation1898. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff250_inst, reff250_op in H. discriminate H. Qed.

Lemma reff250_not1921 : ~ @Equation1921 Fin3 reff250_inst.
Proof. unfold Equation1921. intro H. specialize (H F3_2 F3_0). unfold magma_op, reff250_inst, reff250_op in H. discriminate H. Qed.

Lemma reff250_not1922 : ~ @Equation1922 Fin3 reff250_inst.
Proof. unfold Equation1922. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff250_inst, reff250_op in H. discriminate H. Qed.

Lemma reff250_not1924 : ~ @Equation1924 Fin3 reff250_inst.
Proof. unfold Equation1924. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff250_inst, reff250_op in H. discriminate H. Qed.

Lemma reff250_not1925 : ~ @Equation1925 Fin3 reff250_inst.
Proof. unfold Equation1925. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff250_inst, reff250_op in H. discriminate H. Qed.

Lemma reff250_not1931 : ~ @Equation1931 Fin3 reff250_inst.
Proof. unfold Equation1931. intro H. specialize (H F3_1 F3_0). unfold magma_op, reff250_inst, reff250_op in H. discriminate H. Qed.

Lemma reff250_not1932 : ~ @Equation1932 Fin3 reff250_inst.
Proof. unfold Equation1932. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff250_inst, reff250_op in H. discriminate H. Qed.

Lemma reff250_not1934 : ~ @Equation1934 Fin3 reff250_inst.
Proof. unfold Equation1934. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff250_inst, reff250_op in H. discriminate H. Qed.

Lemma reff250_not2036 : ~ @Equation2036 Fin3 reff250_inst.
Proof. unfold Equation2036. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff250_inst, reff250_op in H. discriminate H. Qed.

Lemma reff250_not2037 : ~ @Equation2037 Fin3 reff250_inst.
Proof. unfold Equation2037. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff250_inst, reff250_op in H. discriminate H. Qed.

Lemma reff250_not2038 : ~ @Equation2038 Fin3 reff250_inst.
Proof. unfold Equation2038. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff250_inst, reff250_op in H. discriminate H. Qed.

Lemma reff250_not2040 : ~ @Equation2040 Fin3 reff250_inst.
Proof. unfold Equation2040. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff250_inst, reff250_op in H. discriminate H. Qed.

Lemma reff250_not2041 : ~ @Equation2041 Fin3 reff250_inst.
Proof. unfold Equation2041. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff250_inst, reff250_op in H. discriminate H. Qed.

Lemma reff250_not2043 : ~ @Equation2043 Fin3 reff250_inst.
Proof. unfold Equation2043. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff250_inst, reff250_op in H. discriminate H. Qed.

Lemma reff250_not2044 : ~ @Equation2044 Fin3 reff250_inst.
Proof. unfold Equation2044. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff250_inst, reff250_op in H. discriminate H. Qed.

Lemma reff250_not2051 : ~ @Equation2051 Fin3 reff250_inst.
Proof. unfold Equation2051. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff250_inst, reff250_op in H. discriminate H. Qed.

Lemma reff250_not2053 : ~ @Equation2053 Fin3 reff250_inst.
Proof. unfold Equation2053. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff250_inst, reff250_op in H. discriminate H. Qed.

Lemma reff250_not2054 : ~ @Equation2054 Fin3 reff250_inst.
Proof. unfold Equation2054. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff250_inst, reff250_op in H. discriminate H. Qed.

Lemma reff250_not2060 : ~ @Equation2060 Fin3 reff250_inst.
Proof. unfold Equation2060. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff250_inst, reff250_op in H. discriminate H. Qed.

Lemma reff250_not2061 : ~ @Equation2061 Fin3 reff250_inst.
Proof. unfold Equation2061. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff250_inst, reff250_op in H. discriminate H. Qed.

Lemma reff250_not2063 : ~ @Equation2063 Fin3 reff250_inst.
Proof. unfold Equation2063. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff250_inst, reff250_op in H. discriminate H. Qed.

Lemma reff250_not2064 : ~ @Equation2064 Fin3 reff250_inst.
Proof. unfold Equation2064. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff250_inst, reff250_op in H. discriminate H. Qed.

Lemma reff250_not2088 : ~ @Equation2088 Fin3 reff250_inst.
Proof. unfold Equation2088. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff250_inst, reff250_op in H. discriminate H. Qed.

Lemma reff250_not2090 : ~ @Equation2090 Fin3 reff250_inst.
Proof. unfold Equation2090. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff250_inst, reff250_op in H. discriminate H. Qed.

Lemma reff250_not2091 : ~ @Equation2091 Fin3 reff250_inst.
Proof. unfold Equation2091. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff250_inst, reff250_op in H. discriminate H. Qed.

Lemma reff250_not2097 : ~ @Equation2097 Fin3 reff250_inst.
Proof. unfold Equation2097. intro H. specialize (H F3_1 F3_0). unfold magma_op, reff250_inst, reff250_op in H. discriminate H. Qed.

Lemma reff250_not2098 : ~ @Equation2098 Fin3 reff250_inst.
Proof. unfold Equation2098. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff250_inst, reff250_op in H. discriminate H. Qed.

Lemma reff250_not2100 : ~ @Equation2100 Fin3 reff250_inst.
Proof. unfold Equation2100. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff250_inst, reff250_op in H. discriminate H. Qed.

Lemma reff250_not2101 : ~ @Equation2101 Fin3 reff250_inst.
Proof. unfold Equation2101. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff250_inst, reff250_op in H. discriminate H. Qed.

Lemma reff250_not2124 : ~ @Equation2124 Fin3 reff250_inst.
Proof. unfold Equation2124. intro H. specialize (H F3_2 F3_0). unfold magma_op, reff250_inst, reff250_op in H. discriminate H. Qed.

Lemma reff250_not2125 : ~ @Equation2125 Fin3 reff250_inst.
Proof. unfold Equation2125. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff250_inst, reff250_op in H. discriminate H. Qed.

Lemma reff250_not2127 : ~ @Equation2127 Fin3 reff250_inst.
Proof. unfold Equation2127. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff250_inst, reff250_op in H. discriminate H. Qed.

Lemma reff250_not2128 : ~ @Equation2128 Fin3 reff250_inst.
Proof. unfold Equation2128. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff250_inst, reff250_op in H. discriminate H. Qed.

Lemma reff250_not2134 : ~ @Equation2134 Fin3 reff250_inst.
Proof. unfold Equation2134. intro H. specialize (H F3_1 F3_0). unfold magma_op, reff250_inst, reff250_op in H. discriminate H. Qed.

Lemma reff250_not2135 : ~ @Equation2135 Fin3 reff250_inst.
Proof. unfold Equation2135. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff250_inst, reff250_op in H. discriminate H. Qed.

Lemma reff250_not2137 : ~ @Equation2137 Fin3 reff250_inst.
Proof. unfold Equation2137. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff250_inst, reff250_op in H. discriminate H. Qed.

Lemma reff250_not2238 : ~ @Equation2238 Fin3 reff250_inst.
Proof. unfold Equation2238. intro H. specialize (H F3_2). unfold magma_op, reff250_inst, reff250_op in H. discriminate H. Qed.

Lemma reff250_not2441 : ~ @Equation2441 Fin3 reff250_inst.
Proof. unfold Equation2441. intro H. specialize (H F3_2). unfold magma_op, reff250_inst, reff250_op in H. discriminate H. Qed.

Lemma reff250_not2644 : ~ @Equation2644 Fin3 reff250_inst.
Proof. unfold Equation2644. intro H. specialize (H F3_1). unfold magma_op, reff250_inst, reff250_op in H. discriminate H. Qed.

Lemma reff250_not2847 : ~ @Equation2847 Fin3 reff250_inst.
Proof. unfold Equation2847. intro H. specialize (H F3_2). unfold magma_op, reff250_inst, reff250_op in H. discriminate H. Qed.

Lemma reff250_not3050 : ~ @Equation3050 Fin3 reff250_inst.
Proof. unfold Equation3050. intro H. specialize (H F3_2). unfold magma_op, reff250_inst, reff250_op in H. discriminate H. Qed.

Lemma reff250_not3254 : ~ @Equation3254 Fin3 reff250_inst.
Proof. unfold Equation3254. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff250_inst, reff250_op in H. discriminate H. Qed.

Lemma reff250_not3255 : ~ @Equation3255 Fin3 reff250_inst.
Proof. unfold Equation3255. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff250_inst, reff250_op in H. discriminate H. Qed.

Lemma reff250_not3256 : ~ @Equation3256 Fin3 reff250_inst.
Proof. unfold Equation3256. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff250_inst, reff250_op in H. discriminate H. Qed.

Lemma reff250_not3258 : ~ @Equation3258 Fin3 reff250_inst.
Proof. unfold Equation3258. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff250_inst, reff250_op in H. discriminate H. Qed.

Lemma reff250_not3259 : ~ @Equation3259 Fin3 reff250_inst.
Proof. unfold Equation3259. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff250_inst, reff250_op in H. discriminate H. Qed.

Lemma reff250_not3261 : ~ @Equation3261 Fin3 reff250_inst.
Proof. unfold Equation3261. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff250_inst, reff250_op in H. discriminate H. Qed.

Lemma reff250_not3262 : ~ @Equation3262 Fin3 reff250_inst.
Proof. unfold Equation3262. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff250_inst, reff250_op in H. discriminate H. Qed.

Lemma reff250_not3268 : ~ @Equation3268 Fin3 reff250_inst.
Proof. unfold Equation3268. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff250_inst, reff250_op in H. discriminate H. Qed.

Lemma reff250_not3271 : ~ @Equation3271 Fin3 reff250_inst.
Proof. unfold Equation3271. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff250_inst, reff250_op in H. discriminate H. Qed.

Lemma reff250_not3272 : ~ @Equation3272 Fin3 reff250_inst.
Proof. unfold Equation3272. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff250_inst, reff250_op in H. discriminate H. Qed.

Lemma reff250_not3278 : ~ @Equation3278 Fin3 reff250_inst.
Proof. unfold Equation3278. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff250_inst, reff250_op in H. discriminate H. Qed.

Lemma reff250_not3279 : ~ @Equation3279 Fin3 reff250_inst.
Proof. unfold Equation3279. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff250_inst, reff250_op in H. discriminate H. Qed.

Lemma reff250_not3281 : ~ @Equation3281 Fin3 reff250_inst.
Proof. unfold Equation3281. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff250_inst, reff250_op in H. discriminate H. Qed.

Lemma reff250_not3308 : ~ @Equation3308 Fin3 reff250_inst.
Proof. unfold Equation3308. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff250_inst, reff250_op in H. discriminate H. Qed.

Lemma reff250_not3309 : ~ @Equation3309 Fin3 reff250_inst.
Proof. unfold Equation3309. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff250_inst, reff250_op in H. discriminate H. Qed.

Lemma reff250_not3315 : ~ @Equation3315 Fin3 reff250_inst.
Proof. unfold Equation3315. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff250_inst, reff250_op in H. discriminate H. Qed.

Lemma reff250_not3316 : ~ @Equation3316 Fin3 reff250_inst.
Proof. unfold Equation3316. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff250_inst, reff250_op in H. discriminate H. Qed.

Lemma reff250_not3318 : ~ @Equation3318 Fin3 reff250_inst.
Proof. unfold Equation3318. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff250_inst, reff250_op in H. discriminate H. Qed.

Lemma reff250_not3319 : ~ @Equation3319 Fin3 reff250_inst.
Proof. unfold Equation3319. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff250_inst, reff250_op in H. discriminate H. Qed.

Lemma reff250_not3342 : ~ @Equation3342 Fin3 reff250_inst.
Proof. unfold Equation3342. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff250_inst, reff250_op in H. discriminate H. Qed.

Lemma reff250_not3343 : ~ @Equation3343 Fin3 reff250_inst.
Proof. unfold Equation3343. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff250_inst, reff250_op in H. discriminate H. Qed.

Lemma reff250_not3345 : ~ @Equation3345 Fin3 reff250_inst.
Proof. unfold Equation3345. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff250_inst, reff250_op in H. discriminate H. Qed.

Lemma reff250_not3346 : ~ @Equation3346 Fin3 reff250_inst.
Proof. unfold Equation3346. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff250_inst, reff250_op in H. discriminate H. Qed.

Lemma reff250_not3352 : ~ @Equation3352 Fin3 reff250_inst.
Proof. unfold Equation3352. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff250_inst, reff250_op in H. discriminate H. Qed.

Lemma reff250_not3353 : ~ @Equation3353 Fin3 reff250_inst.
Proof. unfold Equation3353. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff250_inst, reff250_op in H. discriminate H. Qed.

Lemma reff250_not3457 : ~ @Equation3457 Fin3 reff250_inst.
Proof. unfold Equation3457. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff250_inst, reff250_op in H. discriminate H. Qed.

Lemma reff250_not3458 : ~ @Equation3458 Fin3 reff250_inst.
Proof. unfold Equation3458. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff250_inst, reff250_op in H. discriminate H. Qed.

Lemma reff250_not3459 : ~ @Equation3459 Fin3 reff250_inst.
Proof. unfold Equation3459. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff250_inst, reff250_op in H. discriminate H. Qed.

Lemma reff250_not3461 : ~ @Equation3461 Fin3 reff250_inst.
Proof. unfold Equation3461. intro H. specialize (H F3_1 F3_0). unfold magma_op, reff250_inst, reff250_op in H. discriminate H. Qed.

Lemma reff250_not3462 : ~ @Equation3462 Fin3 reff250_inst.
Proof. unfold Equation3462. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff250_inst, reff250_op in H. discriminate H. Qed.

Lemma reff250_not3464 : ~ @Equation3464 Fin3 reff250_inst.
Proof. unfold Equation3464. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff250_inst, reff250_op in H. discriminate H. Qed.

Lemma reff250_not3465 : ~ @Equation3465 Fin3 reff250_inst.
Proof. unfold Equation3465. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff250_inst, reff250_op in H. discriminate H. Qed.

Lemma reff250_not3472 : ~ @Equation3472 Fin3 reff250_inst.
Proof. unfold Equation3472. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff250_inst, reff250_op in H. discriminate H. Qed.

Lemma reff250_not3474 : ~ @Equation3474 Fin3 reff250_inst.
Proof. unfold Equation3474. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff250_inst, reff250_op in H. discriminate H. Qed.

Lemma reff250_not3475 : ~ @Equation3475 Fin3 reff250_inst.
Proof. unfold Equation3475. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff250_inst, reff250_op in H. discriminate H. Qed.

Lemma reff250_not3481 : ~ @Equation3481 Fin3 reff250_inst.
Proof. unfold Equation3481. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff250_inst, reff250_op in H. discriminate H. Qed.

Lemma reff250_not3482 : ~ @Equation3482 Fin3 reff250_inst.
Proof. unfold Equation3482. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff250_inst, reff250_op in H. discriminate H. Qed.

Lemma reff250_not3484 : ~ @Equation3484 Fin3 reff250_inst.
Proof. unfold Equation3484. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff250_inst, reff250_op in H. discriminate H. Qed.

Lemma reff250_not3509 : ~ @Equation3509 Fin3 reff250_inst.
Proof. unfold Equation3509. intro H. specialize (H F3_1 F3_0). unfold magma_op, reff250_inst, reff250_op in H. discriminate H. Qed.

Lemma reff250_not3511 : ~ @Equation3511 Fin3 reff250_inst.
Proof. unfold Equation3511. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff250_inst, reff250_op in H. discriminate H. Qed.

Lemma reff250_not3512 : ~ @Equation3512 Fin3 reff250_inst.
Proof. unfold Equation3512. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff250_inst, reff250_op in H. discriminate H. Qed.

Lemma reff250_not3518 : ~ @Equation3518 Fin3 reff250_inst.
Proof. unfold Equation3518. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff250_inst, reff250_op in H. discriminate H. Qed.

Lemma reff250_not3519 : ~ @Equation3519 Fin3 reff250_inst.
Proof. unfold Equation3519. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff250_inst, reff250_op in H. discriminate H. Qed.

Lemma reff250_not3521 : ~ @Equation3521 Fin3 reff250_inst.
Proof. unfold Equation3521. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff250_inst, reff250_op in H. discriminate H. Qed.

Lemma reff250_not3522 : ~ @Equation3522 Fin3 reff250_inst.
Proof. unfold Equation3522. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff250_inst, reff250_op in H. discriminate H. Qed.

Lemma reff250_not3545 : ~ @Equation3545 Fin3 reff250_inst.
Proof. unfold Equation3545. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff250_inst, reff250_op in H. discriminate H. Qed.

Lemma reff250_not3546 : ~ @Equation3546 Fin3 reff250_inst.
Proof. unfold Equation3546. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff250_inst, reff250_op in H. discriminate H. Qed.

Lemma reff250_not3548 : ~ @Equation3548 Fin3 reff250_inst.
Proof. unfold Equation3548. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff250_inst, reff250_op in H. discriminate H. Qed.

Lemma reff250_not3549 : ~ @Equation3549 Fin3 reff250_inst.
Proof. unfold Equation3549. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff250_inst, reff250_op in H. discriminate H. Qed.

Lemma reff250_not3555 : ~ @Equation3555 Fin3 reff250_inst.
Proof. unfold Equation3555. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff250_inst, reff250_op in H. discriminate H. Qed.

Lemma reff250_not3556 : ~ @Equation3556 Fin3 reff250_inst.
Proof. unfold Equation3556. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff250_inst, reff250_op in H. discriminate H. Qed.

Lemma reff250_not3558 : ~ @Equation3558 Fin3 reff250_inst.
Proof. unfold Equation3558. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff250_inst, reff250_op in H. discriminate H. Qed.

Lemma reff250_not3659 : ~ @Equation3659 Fin3 reff250_inst.
Proof. unfold Equation3659. intro H. specialize (H F3_1). unfold magma_op, reff250_inst, reff250_op in H. discriminate H. Qed.

Lemma reff250_not3864 : ~ @Equation3864 Fin3 reff250_inst.
Proof. unfold Equation3864. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff250_inst, reff250_op in H. discriminate H. Qed.

Lemma reff250_not3865 : ~ @Equation3865 Fin3 reff250_inst.
Proof. unfold Equation3865. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff250_inst, reff250_op in H. discriminate H. Qed.

Lemma reff250_not3867 : ~ @Equation3867 Fin3 reff250_inst.
Proof. unfold Equation3867. intro H. specialize (H F3_1 F3_0). unfold magma_op, reff250_inst, reff250_op in H. discriminate H. Qed.

Lemma reff250_not3868 : ~ @Equation3868 Fin3 reff250_inst.
Proof. unfold Equation3868. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff250_inst, reff250_op in H. discriminate H. Qed.

Lemma reff250_not3870 : ~ @Equation3870 Fin3 reff250_inst.
Proof. unfold Equation3870. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff250_inst, reff250_op in H. discriminate H. Qed.

Lemma reff250_not3871 : ~ @Equation3871 Fin3 reff250_inst.
Proof. unfold Equation3871. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff250_inst, reff250_op in H. discriminate H. Qed.

Lemma reff250_not3877 : ~ @Equation3877 Fin3 reff250_inst.
Proof. unfold Equation3877. intro H. specialize (H F3_1 F3_0). unfold magma_op, reff250_inst, reff250_op in H. discriminate H. Qed.

Lemma reff250_not3878 : ~ @Equation3878 Fin3 reff250_inst.
Proof. unfold Equation3878. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff250_inst, reff250_op in H. discriminate H. Qed.

Lemma reff250_not3880 : ~ @Equation3880 Fin3 reff250_inst.
Proof. unfold Equation3880. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff250_inst, reff250_op in H. discriminate H. Qed.

Lemma reff250_not3881 : ~ @Equation3881 Fin3 reff250_inst.
Proof. unfold Equation3881. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff250_inst, reff250_op in H. discriminate H. Qed.

Lemma reff250_not3888 : ~ @Equation3888 Fin3 reff250_inst.
Proof. unfold Equation3888. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff250_inst, reff250_op in H. discriminate H. Qed.

Lemma reff250_not3890 : ~ @Equation3890 Fin3 reff250_inst.
Proof. unfold Equation3890. intro H. specialize (H F3_1 F3_0). unfold magma_op, reff250_inst, reff250_op in H. discriminate H. Qed.

Lemma reff250_not3915 : ~ @Equation3915 Fin3 reff250_inst.
Proof. unfold Equation3915. intro H. specialize (H F3_2 F3_0). unfold magma_op, reff250_inst, reff250_op in H. discriminate H. Qed.

Lemma reff250_not3917 : ~ @Equation3917 Fin3 reff250_inst.
Proof. unfold Equation3917. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff250_inst, reff250_op in H. discriminate H. Qed.

Lemma reff250_not3918 : ~ @Equation3918 Fin3 reff250_inst.
Proof. unfold Equation3918. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff250_inst, reff250_op in H. discriminate H. Qed.

Lemma reff250_not3924 : ~ @Equation3924 Fin3 reff250_inst.
Proof. unfold Equation3924. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff250_inst, reff250_op in H. discriminate H. Qed.

Lemma reff250_not3925 : ~ @Equation3925 Fin3 reff250_inst.
Proof. unfold Equation3925. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff250_inst, reff250_op in H. discriminate H. Qed.

Lemma reff250_not3927 : ~ @Equation3927 Fin3 reff250_inst.
Proof. unfold Equation3927. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff250_inst, reff250_op in H. discriminate H. Qed.

Lemma reff250_not3928 : ~ @Equation3928 Fin3 reff250_inst.
Proof. unfold Equation3928. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff250_inst, reff250_op in H. discriminate H. Qed.

Lemma reff250_not3951 : ~ @Equation3951 Fin3 reff250_inst.
Proof. unfold Equation3951. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff250_inst, reff250_op in H. discriminate H. Qed.

Lemma reff250_not3952 : ~ @Equation3952 Fin3 reff250_inst.
Proof. unfold Equation3952. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff250_inst, reff250_op in H. discriminate H. Qed.

Lemma reff250_not3954 : ~ @Equation3954 Fin3 reff250_inst.
Proof. unfold Equation3954. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff250_inst, reff250_op in H. discriminate H. Qed.

Lemma reff250_not3955 : ~ @Equation3955 Fin3 reff250_inst.
Proof. unfold Equation3955. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff250_inst, reff250_op in H. discriminate H. Qed.

Lemma reff250_not3961 : ~ @Equation3961 Fin3 reff250_inst.
Proof. unfold Equation3961. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff250_inst, reff250_op in H. discriminate H. Qed.

Lemma reff250_not3962 : ~ @Equation3962 Fin3 reff250_inst.
Proof. unfold Equation3962. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff250_inst, reff250_op in H. discriminate H. Qed.

Lemma reff250_not3964 : ~ @Equation3964 Fin3 reff250_inst.
Proof. unfold Equation3964. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff250_inst, reff250_op in H. discriminate H. Qed.

Lemma reff250_not4066 : ~ @Equation4066 Fin3 reff250_inst.
Proof. unfold Equation4066. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff250_inst, reff250_op in H. discriminate H. Qed.

Lemma reff250_not4067 : ~ @Equation4067 Fin3 reff250_inst.
Proof. unfold Equation4067. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff250_inst, reff250_op in H. discriminate H. Qed.

Lemma reff250_not4068 : ~ @Equation4068 Fin3 reff250_inst.
Proof. unfold Equation4068. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff250_inst, reff250_op in H. discriminate H. Qed.

Lemma reff250_not4070 : ~ @Equation4070 Fin3 reff250_inst.
Proof. unfold Equation4070. intro H. specialize (H F3_1 F3_2). unfold magma_op, reff250_inst, reff250_op in H. discriminate H. Qed.

Lemma reff250_not4071 : ~ @Equation4071 Fin3 reff250_inst.
Proof. unfold Equation4071. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff250_inst, reff250_op in H. discriminate H. Qed.

Lemma reff250_not4073 : ~ @Equation4073 Fin3 reff250_inst.
Proof. unfold Equation4073. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff250_inst, reff250_op in H. discriminate H. Qed.

Lemma reff250_not4074 : ~ @Equation4074 Fin3 reff250_inst.
Proof. unfold Equation4074. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff250_inst, reff250_op in H. discriminate H. Qed.

Lemma reff250_not4080 : ~ @Equation4080 Fin3 reff250_inst.
Proof. unfold Equation4080. intro H. specialize (H F3_1 F3_0). unfold magma_op, reff250_inst, reff250_op in H. discriminate H. Qed.

Lemma reff250_not4083 : ~ @Equation4083 Fin3 reff250_inst.
Proof. unfold Equation4083. intro H. specialize (H F3_1 F3_0). unfold magma_op, reff250_inst, reff250_op in H. discriminate H. Qed.

Lemma reff250_not4084 : ~ @Equation4084 Fin3 reff250_inst.
Proof. unfold Equation4084. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff250_inst, reff250_op in H. discriminate H. Qed.

Lemma reff250_not4090 : ~ @Equation4090 Fin3 reff250_inst.
Proof. unfold Equation4090. intro H. specialize (H F3_1 F3_2). unfold magma_op, reff250_inst, reff250_op in H. discriminate H. Qed.

Lemma reff250_not4091 : ~ @Equation4091 Fin3 reff250_inst.
Proof. unfold Equation4091. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff250_inst, reff250_op in H. discriminate H. Qed.

Lemma reff250_not4093 : ~ @Equation4093 Fin3 reff250_inst.
Proof. unfold Equation4093. intro H. specialize (H F3_1 F3_0). unfold magma_op, reff250_inst, reff250_op in H. discriminate H. Qed.

Lemma reff250_not4118 : ~ @Equation4118 Fin3 reff250_inst.
Proof. unfold Equation4118. intro H. specialize (H F3_2 F3_0). unfold magma_op, reff250_inst, reff250_op in H. discriminate H. Qed.

Lemma reff250_not4120 : ~ @Equation4120 Fin3 reff250_inst.
Proof. unfold Equation4120. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff250_inst, reff250_op in H. discriminate H. Qed.

Lemma reff250_not4121 : ~ @Equation4121 Fin3 reff250_inst.
Proof. unfold Equation4121. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff250_inst, reff250_op in H. discriminate H. Qed.

Lemma reff250_not4127 : ~ @Equation4127 Fin3 reff250_inst.
Proof. unfold Equation4127. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff250_inst, reff250_op in H. discriminate H. Qed.

Lemma reff250_not4128 : ~ @Equation4128 Fin3 reff250_inst.
Proof. unfold Equation4128. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff250_inst, reff250_op in H. discriminate H. Qed.

Lemma reff250_not4130 : ~ @Equation4130 Fin3 reff250_inst.
Proof. unfold Equation4130. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff250_inst, reff250_op in H. discriminate H. Qed.

Lemma reff250_not4131 : ~ @Equation4131 Fin3 reff250_inst.
Proof. unfold Equation4131. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff250_inst, reff250_op in H. discriminate H. Qed.

Lemma reff250_not4155 : ~ @Equation4155 Fin3 reff250_inst.
Proof. unfold Equation4155. intro H. specialize (H F3_1 F3_0). unfold magma_op, reff250_inst, reff250_op in H. discriminate H. Qed.

Lemma reff250_not4157 : ~ @Equation4157 Fin3 reff250_inst.
Proof. unfold Equation4157. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff250_inst, reff250_op in H. discriminate H. Qed.

Lemma reff250_not4158 : ~ @Equation4158 Fin3 reff250_inst.
Proof. unfold Equation4158. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff250_inst, reff250_op in H. discriminate H. Qed.

Lemma reff250_not4164 : ~ @Equation4164 Fin3 reff250_inst.
Proof. unfold Equation4164. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff250_inst, reff250_op in H. discriminate H. Qed.

Lemma reff250_not4165 : ~ @Equation4165 Fin3 reff250_inst.
Proof. unfold Equation4165. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff250_inst, reff250_op in H. discriminate H. Qed.

Lemma reff250_not4167 : ~ @Equation4167 Fin3 reff250_inst.
Proof. unfold Equation4167. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff250_inst, reff250_op in H. discriminate H. Qed.

Lemma reff250_not4268 : ~ @Equation4268 Fin3 reff250_inst.
Proof. unfold Equation4268. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff250_inst, reff250_op in H. discriminate H. Qed.

Lemma reff250_not4269 : ~ @Equation4269 Fin3 reff250_inst.
Proof. unfold Equation4269. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff250_inst, reff250_op in H. discriminate H. Qed.

Lemma reff250_not4270 : ~ @Equation4270 Fin3 reff250_inst.
Proof. unfold Equation4270. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff250_inst, reff250_op in H. discriminate H. Qed.

Lemma reff250_not4272 : ~ @Equation4272 Fin3 reff250_inst.
Proof. unfold Equation4272. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff250_inst, reff250_op in H. discriminate H. Qed.

Lemma reff250_not4273 : ~ @Equation4273 Fin3 reff250_inst.
Proof. unfold Equation4273. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff250_inst, reff250_op in H. discriminate H. Qed.

Lemma reff250_not4275 : ~ @Equation4275 Fin3 reff250_inst.
Proof. unfold Equation4275. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff250_inst, reff250_op in H. discriminate H. Qed.

Lemma reff250_not4276 : ~ @Equation4276 Fin3 reff250_inst.
Proof. unfold Equation4276. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff250_inst, reff250_op in H. discriminate H. Qed.

Lemma reff250_not4283 : ~ @Equation4283 Fin3 reff250_inst.
Proof. unfold Equation4283. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff250_inst, reff250_op in H. discriminate H. Qed.

Lemma reff250_not4284 : ~ @Equation4284 Fin3 reff250_inst.
Proof. unfold Equation4284. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff250_inst, reff250_op in H. discriminate H. Qed.

Lemma reff250_not4290 : ~ @Equation4290 Fin3 reff250_inst.
Proof. unfold Equation4290. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff250_inst, reff250_op in H. discriminate H. Qed.

Lemma reff250_not4291 : ~ @Equation4291 Fin3 reff250_inst.
Proof. unfold Equation4291. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff250_inst, reff250_op in H. discriminate H. Qed.

Lemma reff250_not4293 : ~ @Equation4293 Fin3 reff250_inst.
Proof. unfold Equation4293. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff250_inst, reff250_op in H. discriminate H. Qed.

Lemma reff250_not4314 : ~ @Equation4314 Fin3 reff250_inst.
Proof. unfold Equation4314. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff250_inst, reff250_op in H. discriminate H. Qed.

Lemma reff250_not4320 : ~ @Equation4320 Fin3 reff250_inst.
Proof. unfold Equation4320. intro H. specialize (H F3_1 F3_2). unfold magma_op, reff250_inst, reff250_op in H. discriminate H. Qed.

Lemma reff250_not4321 : ~ @Equation4321 Fin3 reff250_inst.
Proof. unfold Equation4321. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff250_inst, reff250_op in H. discriminate H. Qed.

Lemma reff250_not4343 : ~ @Equation4343 Fin3 reff250_inst.
Proof. unfold Equation4343. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff250_inst, reff250_op in H. discriminate H. Qed.

Lemma reff250_not4396 : ~ @Equation4396 Fin3 reff250_inst.
Proof. unfold Equation4396. intro H. specialize (H F3_1 F3_0). unfold magma_op, reff250_inst, reff250_op in H. discriminate H. Qed.

Lemma reff250_not4398 : ~ @Equation4398 Fin3 reff250_inst.
Proof. unfold Equation4398. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff250_inst, reff250_op in H. discriminate H. Qed.

Lemma reff250_not4399 : ~ @Equation4399 Fin3 reff250_inst.
Proof. unfold Equation4399. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff250_inst, reff250_op in H. discriminate H. Qed.

Lemma reff250_not4405 : ~ @Equation4405 Fin3 reff250_inst.
Proof. unfold Equation4405. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff250_inst, reff250_op in H. discriminate H. Qed.

Lemma reff250_not4406 : ~ @Equation4406 Fin3 reff250_inst.
Proof. unfold Equation4406. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff250_inst, reff250_op in H. discriminate H. Qed.

Lemma reff250_not4408 : ~ @Equation4408 Fin3 reff250_inst.
Proof. unfold Equation4408. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff250_inst, reff250_op in H. discriminate H. Qed.

Lemma reff250_not4433 : ~ @Equation4433 Fin3 reff250_inst.
Proof. unfold Equation4433. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff250_inst, reff250_op in H. discriminate H. Qed.

Lemma reff250_not4435 : ~ @Equation4435 Fin3 reff250_inst.
Proof. unfold Equation4435. intro H. specialize (H F3_1 F3_0). unfold magma_op, reff250_inst, reff250_op in H. discriminate H. Qed.

Lemma reff250_not4436 : ~ @Equation4436 Fin3 reff250_inst.
Proof. unfold Equation4436. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff250_inst, reff250_op in H. discriminate H. Qed.

Lemma reff250_not4442 : ~ @Equation4442 Fin3 reff250_inst.
Proof. unfold Equation4442. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff250_inst, reff250_op in H. discriminate H. Qed.

Lemma reff250_not4443 : ~ @Equation4443 Fin3 reff250_inst.
Proof. unfold Equation4443. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff250_inst, reff250_op in H. discriminate H. Qed.

Lemma reff250_not4445 : ~ @Equation4445 Fin3 reff250_inst.
Proof. unfold Equation4445. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff250_inst, reff250_op in H. discriminate H. Qed.

Lemma reff250_not4470 : ~ @Equation4470 Fin3 reff250_inst.
Proof. unfold Equation4470. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff250_inst, reff250_op in H. discriminate H. Qed.

Lemma reff250_not4472 : ~ @Equation4472 Fin3 reff250_inst.
Proof. unfold Equation4472. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff250_inst, reff250_op in H. discriminate H. Qed.

Lemma reff250_not4473 : ~ @Equation4473 Fin3 reff250_inst.
Proof. unfold Equation4473. intro H. specialize (H F3_1 F3_2). unfold magma_op, reff250_inst, reff250_op in H. discriminate H. Qed.

Lemma reff250_not4479 : ~ @Equation4479 Fin3 reff250_inst.
Proof. unfold Equation4479. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff250_inst, reff250_op in H. discriminate H. Qed.

Lemma reff250_not4480 : ~ @Equation4480 Fin3 reff250_inst.
Proof. unfold Equation4480. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff250_inst, reff250_op in H. discriminate H. Qed.

Lemma reff250_not4482 : ~ @Equation4482 Fin3 reff250_inst.
Proof. unfold Equation4482. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff250_inst, reff250_op in H. discriminate H. Qed.

Lemma reff250_not4583 : ~ @Equation4583 Fin3 reff250_inst.
Proof. unfold Equation4583. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff250_inst, reff250_op in H. discriminate H. Qed.

Lemma reff250_not4584 : ~ @Equation4584 Fin3 reff250_inst.
Proof. unfold Equation4584. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff250_inst, reff250_op in H. discriminate H. Qed.

Lemma reff250_not4585 : ~ @Equation4585 Fin3 reff250_inst.
Proof. unfold Equation4585. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff250_inst, reff250_op in H. discriminate H. Qed.

Lemma reff250_not4587 : ~ @Equation4587 Fin3 reff250_inst.
Proof. unfold Equation4587. intro H. specialize (H F3_1 F3_0). unfold magma_op, reff250_inst, reff250_op in H. discriminate H. Qed.

Lemma reff250_not4588 : ~ @Equation4588 Fin3 reff250_inst.
Proof. unfold Equation4588. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff250_inst, reff250_op in H. discriminate H. Qed.

Lemma reff250_not4590 : ~ @Equation4590 Fin3 reff250_inst.
Proof. unfold Equation4590. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff250_inst, reff250_op in H. discriminate H. Qed.

Lemma reff250_not4591 : ~ @Equation4591 Fin3 reff250_inst.
Proof. unfold Equation4591. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff250_inst, reff250_op in H. discriminate H. Qed.

Lemma reff250_not4598 : ~ @Equation4598 Fin3 reff250_inst.
Proof. unfold Equation4598. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff250_inst, reff250_op in H. discriminate H. Qed.

Lemma reff250_not4599 : ~ @Equation4599 Fin3 reff250_inst.
Proof. unfold Equation4599. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff250_inst, reff250_op in H. discriminate H. Qed.

Lemma reff250_not4605 : ~ @Equation4605 Fin3 reff250_inst.
Proof. unfold Equation4605. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff250_inst, reff250_op in H. discriminate H. Qed.

Lemma reff250_not4606 : ~ @Equation4606 Fin3 reff250_inst.
Proof. unfold Equation4606. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff250_inst, reff250_op in H. discriminate H. Qed.

Lemma reff250_not4608 : ~ @Equation4608 Fin3 reff250_inst.
Proof. unfold Equation4608. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff250_inst, reff250_op in H. discriminate H. Qed.

Lemma reff250_not4629 : ~ @Equation4629 Fin3 reff250_inst.
Proof. unfold Equation4629. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff250_inst, reff250_op in H. discriminate H. Qed.

Lemma reff250_not4635 : ~ @Equation4635 Fin3 reff250_inst.
Proof. unfold Equation4635. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff250_inst, reff250_op in H. discriminate H. Qed.

Lemma reff250_not4636 : ~ @Equation4636 Fin3 reff250_inst.
Proof. unfold Equation4636. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff250_inst, reff250_op in H. discriminate H. Qed.

Lemma reff250_not4658 : ~ @Equation4658 Fin3 reff250_inst.
Proof. unfold Equation4658. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff250_inst, reff250_op in H. discriminate H. Qed.

(** ---- reff26 (Fin5) ---- *)

Definition reff26_op (x y : Fin5) : Fin5 :=
  match x, y with
  | F5_0, F5_0 => F5_0 | F5_0, F5_1 => F5_3 | F5_0, F5_2 => F5_4 | F5_0, F5_3 => F5_3 | F5_0, F5_4 => F5_0
  | F5_1, F5_0 => F5_4 | F5_1, F5_1 => F5_4 | F5_1, F5_2 => F5_2 | F5_1, F5_3 => F5_3 | F5_1, F5_4 => F5_2
  | F5_2, F5_0 => F5_1 | F5_2, F5_1 => F5_3 | F5_2, F5_2 => F5_3 | F5_2, F5_3 => F5_1 | F5_2, F5_4 => F5_2
  | F5_3, F5_0 => F5_1 | F5_3, F5_1 => F5_0 | F5_3, F5_2 => F5_2 | F5_3, F5_3 => F5_2 | F5_3, F5_4 => F5_0
  | F5_4, F5_0 => F5_4 | F5_4, F5_1 => F5_0 | F5_4, F5_2 => F5_4 | F5_4, F5_3 => F5_1 | F5_4, F5_4 => F5_1
  end.

#[local] Instance reff26_inst : Magma Fin5 := {| magma_op := reff26_op |}.

Lemma reff26_sat159 : @Equation159 Fin5 reff26_inst.
Proof. unfold Equation159, magma_op, reff26_inst, reff26_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff26_not47 : ~ @Equation47 Fin5 reff26_inst.
Proof. unfold Equation47. intro H. specialize (H F5_1). unfold magma_op, reff26_inst, reff26_op in H. discriminate H. Qed.

Lemma reff26_not99 : ~ @Equation99 Fin5 reff26_inst.
Proof. unfold Equation99. intro H. specialize (H F5_1). unfold magma_op, reff26_inst, reff26_op in H. discriminate H. Qed.

Lemma reff26_not154 : ~ @Equation154 Fin5 reff26_inst.
Proof. unfold Equation154. intro H. specialize (H F5_0 F5_2). unfold magma_op, reff26_inst, reff26_op in H. discriminate H. Qed.

Lemma reff26_not157 : ~ @Equation157 Fin5 reff26_inst.
Proof. unfold Equation157. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff26_inst, reff26_op in H. discriminate H. Qed.

Lemma reff26_not160 : ~ @Equation160 Fin5 reff26_inst.
Proof. unfold Equation160. intro H. specialize (H F5_0 F5_2). unfold magma_op, reff26_inst, reff26_op in H. discriminate H. Qed.

Lemma reff26_not167 : ~ @Equation167 Fin5 reff26_inst.
Proof. unfold Equation167. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff26_inst, reff26_op in H. discriminate H. Qed.

Lemma reff26_not169 : ~ @Equation169 Fin5 reff26_inst.
Proof. unfold Equation169. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff26_inst, reff26_op in H. discriminate H. Qed.

Lemma reff26_not170 : ~ @Equation170 Fin5 reff26_inst.
Proof. unfold Equation170. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff26_inst, reff26_op in H. discriminate H. Qed.

Lemma reff26_not176 : ~ @Equation176 Fin5 reff26_inst.
Proof. unfold Equation176. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff26_inst, reff26_op in H. discriminate H. Qed.

Lemma reff26_not177 : ~ @Equation177 Fin5 reff26_inst.
Proof. unfold Equation177. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff26_inst, reff26_op in H. discriminate H. Qed.

Lemma reff26_not179 : ~ @Equation179 Fin5 reff26_inst.
Proof. unfold Equation179. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff26_inst, reff26_op in H. discriminate H. Qed.

Lemma reff26_not203 : ~ @Equation203 Fin5 reff26_inst.
Proof. unfold Equation203. intro H. specialize (H F5_1). unfold magma_op, reff26_inst, reff26_op in H. discriminate H. Qed.

Lemma reff26_not255 : ~ @Equation255 Fin5 reff26_inst.
Proof. unfold Equation255. intro H. specialize (H F5_1). unfold magma_op, reff26_inst, reff26_op in H. discriminate H. Qed.

Lemma reff26_not411 : ~ @Equation411 Fin5 reff26_inst.
Proof. unfold Equation411. intro H. specialize (H F5_1). unfold magma_op, reff26_inst, reff26_op in H. discriminate H. Qed.

Lemma reff26_not614 : ~ @Equation614 Fin5 reff26_inst.
Proof. unfold Equation614. intro H. specialize (H F5_1). unfold magma_op, reff26_inst, reff26_op in H. discriminate H. Qed.

Lemma reff26_not817 : ~ @Equation817 Fin5 reff26_inst.
Proof. unfold Equation817. intro H. specialize (H F5_1). unfold magma_op, reff26_inst, reff26_op in H. discriminate H. Qed.

Lemma reff26_not1020 : ~ @Equation1020 Fin5 reff26_inst.
Proof. unfold Equation1020. intro H. specialize (H F5_1). unfold magma_op, reff26_inst, reff26_op in H. discriminate H. Qed.

Lemma reff26_not1223 : ~ @Equation1223 Fin5 reff26_inst.
Proof. unfold Equation1223. intro H. specialize (H F5_1). unfold magma_op, reff26_inst, reff26_op in H. discriminate H. Qed.

Lemma reff26_not1426 : ~ @Equation1426 Fin5 reff26_inst.
Proof. unfold Equation1426. intro H. specialize (H F5_1). unfold magma_op, reff26_inst, reff26_op in H. discriminate H. Qed.

Lemma reff26_not1629 : ~ @Equation1629 Fin5 reff26_inst.
Proof. unfold Equation1629. intro H. specialize (H F5_1). unfold magma_op, reff26_inst, reff26_op in H. discriminate H. Qed.

Lemma reff26_not1832 : ~ @Equation1832 Fin5 reff26_inst.
Proof. unfold Equation1832. intro H. specialize (H F5_1). unfold magma_op, reff26_inst, reff26_op in H. discriminate H. Qed.

Lemma reff26_not2035 : ~ @Equation2035 Fin5 reff26_inst.
Proof. unfold Equation2035. intro H. specialize (H F5_1). unfold magma_op, reff26_inst, reff26_op in H. discriminate H. Qed.

Lemma reff26_not2238 : ~ @Equation2238 Fin5 reff26_inst.
Proof. unfold Equation2238. intro H. specialize (H F5_1). unfold magma_op, reff26_inst, reff26_op in H. discriminate H. Qed.

Lemma reff26_not2441 : ~ @Equation2441 Fin5 reff26_inst.
Proof. unfold Equation2441. intro H. specialize (H F5_1). unfold magma_op, reff26_inst, reff26_op in H. discriminate H. Qed.

Lemma reff26_not2644 : ~ @Equation2644 Fin5 reff26_inst.
Proof. unfold Equation2644. intro H. specialize (H F5_1). unfold magma_op, reff26_inst, reff26_op in H. discriminate H. Qed.

Lemma reff26_not2847 : ~ @Equation2847 Fin5 reff26_inst.
Proof. unfold Equation2847. intro H. specialize (H F5_1). unfold magma_op, reff26_inst, reff26_op in H. discriminate H. Qed.

Lemma reff26_not3050 : ~ @Equation3050 Fin5 reff26_inst.
Proof. unfold Equation3050. intro H. specialize (H F5_1). unfold magma_op, reff26_inst, reff26_op in H. discriminate H. Qed.

Lemma reff26_not3253 : ~ @Equation3253 Fin5 reff26_inst.
Proof. unfold Equation3253. intro H. specialize (H F5_1). unfold magma_op, reff26_inst, reff26_op in H. discriminate H. Qed.

Lemma reff26_not3456 : ~ @Equation3456 Fin5 reff26_inst.
Proof. unfold Equation3456. intro H. specialize (H F5_3). unfold magma_op, reff26_inst, reff26_op in H. discriminate H. Qed.

Lemma reff26_not3659 : ~ @Equation3659 Fin5 reff26_inst.
Proof. unfold Equation3659. intro H. specialize (H F5_1). unfold magma_op, reff26_inst, reff26_op in H. discriminate H. Qed.

Lemma reff26_not3862 : ~ @Equation3862 Fin5 reff26_inst.
Proof. unfold Equation3862. intro H. specialize (H F5_1). unfold magma_op, reff26_inst, reff26_op in H. discriminate H. Qed.

Lemma reff26_not4065 : ~ @Equation4065 Fin5 reff26_inst.
Proof. unfold Equation4065. intro H. specialize (H F5_1). unfold magma_op, reff26_inst, reff26_op in H. discriminate H. Qed.

Lemma reff26_not4268 : ~ @Equation4268 Fin5 reff26_inst.
Proof. unfold Equation4268. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff26_inst, reff26_op in H. discriminate H. Qed.

Lemma reff26_not4269 : ~ @Equation4269 Fin5 reff26_inst.
Proof. unfold Equation4269. intro H. specialize (H F5_0 F5_2). unfold magma_op, reff26_inst, reff26_op in H. discriminate H. Qed.

Lemma reff26_not4270 : ~ @Equation4270 Fin5 reff26_inst.
Proof. unfold Equation4270. intro H. specialize (H F5_0 F5_2). unfold magma_op, reff26_inst, reff26_op in H. discriminate H. Qed.

Lemma reff26_not4272 : ~ @Equation4272 Fin5 reff26_inst.
Proof. unfold Equation4272. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff26_inst, reff26_op in H. discriminate H. Qed.

Lemma reff26_not4273 : ~ @Equation4273 Fin5 reff26_inst.
Proof. unfold Equation4273. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff26_inst, reff26_op in H. discriminate H. Qed.

Lemma reff26_not4275 : ~ @Equation4275 Fin5 reff26_inst.
Proof. unfold Equation4275. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff26_inst, reff26_op in H. discriminate H. Qed.

Lemma reff26_not4276 : ~ @Equation4276 Fin5 reff26_inst.
Proof. unfold Equation4276. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff26_inst, reff26_op in H. discriminate H. Qed.

Lemma reff26_not4283 : ~ @Equation4283 Fin5 reff26_inst.
Proof. unfold Equation4283. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff26_inst, reff26_op in H. discriminate H. Qed.

Lemma reff26_not4284 : ~ @Equation4284 Fin5 reff26_inst.
Proof. unfold Equation4284. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff26_inst, reff26_op in H. discriminate H. Qed.

Lemma reff26_not4290 : ~ @Equation4290 Fin5 reff26_inst.
Proof. unfold Equation4290. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff26_inst, reff26_op in H. discriminate H. Qed.

Lemma reff26_not4291 : ~ @Equation4291 Fin5 reff26_inst.
Proof. unfold Equation4291. intro H. specialize (H F5_0 F5_2). unfold magma_op, reff26_inst, reff26_op in H. discriminate H. Qed.

Lemma reff26_not4293 : ~ @Equation4293 Fin5 reff26_inst.
Proof. unfold Equation4293. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff26_inst, reff26_op in H. discriminate H. Qed.

Lemma reff26_not4314 : ~ @Equation4314 Fin5 reff26_inst.
Proof. unfold Equation4314. intro H. specialize (H F5_0 F5_3). unfold magma_op, reff26_inst, reff26_op in H. discriminate H. Qed.

Lemma reff26_not4320 : ~ @Equation4320 Fin5 reff26_inst.
Proof. unfold Equation4320. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff26_inst, reff26_op in H. discriminate H. Qed.

Lemma reff26_not4321 : ~ @Equation4321 Fin5 reff26_inst.
Proof. unfold Equation4321. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff26_inst, reff26_op in H. discriminate H. Qed.

Lemma reff26_not4343 : ~ @Equation4343 Fin5 reff26_inst.
Proof. unfold Equation4343. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff26_inst, reff26_op in H. discriminate H. Qed.

Lemma reff26_not4380 : ~ @Equation4380 Fin5 reff26_inst.
Proof. unfold Equation4380. intro H. specialize (H F5_1). unfold magma_op, reff26_inst, reff26_op in H. discriminate H. Qed.

Lemma reff26_not4583 : ~ @Equation4583 Fin5 reff26_inst.
Proof. unfold Equation4583. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff26_inst, reff26_op in H. discriminate H. Qed.

Lemma reff26_not4584 : ~ @Equation4584 Fin5 reff26_inst.
Proof. unfold Equation4584. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff26_inst, reff26_op in H. discriminate H. Qed.

Lemma reff26_not4585 : ~ @Equation4585 Fin5 reff26_inst.
Proof. unfold Equation4585. intro H. specialize (H F5_0 F5_2). unfold magma_op, reff26_inst, reff26_op in H. discriminate H. Qed.

Lemma reff26_not4587 : ~ @Equation4587 Fin5 reff26_inst.
Proof. unfold Equation4587. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff26_inst, reff26_op in H. discriminate H. Qed.

Lemma reff26_not4588 : ~ @Equation4588 Fin5 reff26_inst.
Proof. unfold Equation4588. intro H. specialize (H F5_0 F5_2). unfold magma_op, reff26_inst, reff26_op in H. discriminate H. Qed.

Lemma reff26_not4590 : ~ @Equation4590 Fin5 reff26_inst.
Proof. unfold Equation4590. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff26_inst, reff26_op in H. discriminate H. Qed.

Lemma reff26_not4591 : ~ @Equation4591 Fin5 reff26_inst.
Proof. unfold Equation4591. intro H. specialize (H F5_0 F5_2). unfold magma_op, reff26_inst, reff26_op in H. discriminate H. Qed.

Lemma reff26_not4598 : ~ @Equation4598 Fin5 reff26_inst.
Proof. unfold Equation4598. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff26_inst, reff26_op in H. discriminate H. Qed.

Lemma reff26_not4599 : ~ @Equation4599 Fin5 reff26_inst.
Proof. unfold Equation4599. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff26_inst, reff26_op in H. discriminate H. Qed.

Lemma reff26_not4605 : ~ @Equation4605 Fin5 reff26_inst.
Proof. unfold Equation4605. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff26_inst, reff26_op in H. discriminate H. Qed.

Lemma reff26_not4606 : ~ @Equation4606 Fin5 reff26_inst.
Proof. unfold Equation4606. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff26_inst, reff26_op in H. discriminate H. Qed.

Lemma reff26_not4608 : ~ @Equation4608 Fin5 reff26_inst.
Proof. unfold Equation4608. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff26_inst, reff26_op in H. discriminate H. Qed.

Lemma reff26_not4629 : ~ @Equation4629 Fin5 reff26_inst.
Proof. unfold Equation4629. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff26_inst, reff26_op in H. discriminate H. Qed.

Lemma reff26_not4635 : ~ @Equation4635 Fin5 reff26_inst.
Proof. unfold Equation4635. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff26_inst, reff26_op in H. discriminate H. Qed.

Lemma reff26_not4636 : ~ @Equation4636 Fin5 reff26_inst.
Proof. unfold Equation4636. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff26_inst, reff26_op in H. discriminate H. Qed.

Lemma reff26_not4658 : ~ @Equation4658 Fin5 reff26_inst.
Proof. unfold Equation4658. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff26_inst, reff26_op in H. discriminate H. Qed.

(** ---- reff262 (Fin3) ---- *)

Definition reff262_op (x y : Fin3) : Fin3 :=
  match x, y with
  | F3_0, F3_0 => F3_0 | F3_0, F3_1 => F3_2 | F3_0, F3_2 => F3_1
  | F3_1, F3_0 => F3_0 | F3_1, F3_1 => F3_2 | F3_1, F3_2 => F3_1
  | F3_2, F3_0 => F3_0 | F3_2, F3_1 => F3_2 | F3_2, F3_2 => F3_1
  end.

#[local] Instance reff262_inst : Magma Fin3 := {| magma_op := reff262_op |}.

Lemma reff262_sat13 : @Equation13 Fin3 reff262_inst.
Proof. unfold Equation13, magma_op, reff262_inst, reff262_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff262_sat3356 : @Equation3356 Fin3 reff262_inst.
Proof. unfold Equation3356, magma_op, reff262_inst, reff262_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff262_not47 : ~ @Equation47 Fin3 reff262_inst.
Proof. unfold Equation47. intro H. specialize (H F3_1). unfold magma_op, reff262_inst, reff262_op in H. discriminate H. Qed.

Lemma reff262_not102 : ~ @Equation102 Fin3 reff262_inst.
Proof. unfold Equation102. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff262_inst, reff262_op in H. discriminate H. Qed.

Lemma reff262_not105 : ~ @Equation105 Fin3 reff262_inst.
Proof. unfold Equation105. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff262_inst, reff262_op in H. discriminate H. Qed.

Lemma reff262_not108 : ~ @Equation108 Fin3 reff262_inst.
Proof. unfold Equation108. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff262_inst, reff262_op in H. discriminate H. Qed.

Lemma reff262_not115 : ~ @Equation115 Fin3 reff262_inst.
Proof. unfold Equation115. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff262_inst, reff262_op in H. discriminate H. Qed.

Lemma reff262_not118 : ~ @Equation118 Fin3 reff262_inst.
Proof. unfold Equation118. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff262_inst, reff262_op in H. discriminate H. Qed.

Lemma reff262_not125 : ~ @Equation125 Fin3 reff262_inst.
Proof. unfold Equation125. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff262_inst, reff262_op in H. discriminate H. Qed.

Lemma reff262_not154 : ~ @Equation154 Fin3 reff262_inst.
Proof. unfold Equation154. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff262_inst, reff262_op in H. discriminate H. Qed.

Lemma reff262_not157 : ~ @Equation157 Fin3 reff262_inst.
Proof. unfold Equation157. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff262_inst, reff262_op in H. discriminate H. Qed.

Lemma reff262_not160 : ~ @Equation160 Fin3 reff262_inst.
Proof. unfold Equation160. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff262_inst, reff262_op in H. discriminate H. Qed.

Lemma reff262_not167 : ~ @Equation167 Fin3 reff262_inst.
Proof. unfold Equation167. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff262_inst, reff262_op in H. discriminate H. Qed.

Lemma reff262_not170 : ~ @Equation170 Fin3 reff262_inst.
Proof. unfold Equation170. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff262_inst, reff262_op in H. discriminate H. Qed.

Lemma reff262_not177 : ~ @Equation177 Fin3 reff262_inst.
Proof. unfold Equation177. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff262_inst, reff262_op in H. discriminate H. Qed.

Lemma reff262_not203 : ~ @Equation203 Fin3 reff262_inst.
Proof. unfold Equation203. intro H. specialize (H F3_1). unfold magma_op, reff262_inst, reff262_op in H. discriminate H. Qed.

Lemma reff262_not255 : ~ @Equation255 Fin3 reff262_inst.
Proof. unfold Equation255. intro H. specialize (H F3_1). unfold magma_op, reff262_inst, reff262_op in H. discriminate H. Qed.

Lemma reff262_not307 : ~ @Equation307 Fin3 reff262_inst.
Proof. unfold Equation307. intro H. specialize (H F3_1). unfold magma_op, reff262_inst, reff262_op in H. discriminate H. Qed.

Lemma reff262_not412 : ~ @Equation412 Fin3 reff262_inst.
Proof. unfold Equation412. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff262_inst, reff262_op in H. discriminate H. Qed.

Lemma reff262_not414 : ~ @Equation414 Fin3 reff262_inst.
Proof. unfold Equation414. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff262_inst, reff262_op in H. discriminate H. Qed.

Lemma reff262_not417 : ~ @Equation417 Fin3 reff262_inst.
Proof. unfold Equation417. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff262_inst, reff262_op in H. discriminate H. Qed.

Lemma reff262_not420 : ~ @Equation420 Fin3 reff262_inst.
Proof. unfold Equation420. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff262_inst, reff262_op in H. discriminate H. Qed.

Lemma reff262_not427 : ~ @Equation427 Fin3 reff262_inst.
Proof. unfold Equation427. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff262_inst, reff262_op in H. discriminate H. Qed.

Lemma reff262_not430 : ~ @Equation430 Fin3 reff262_inst.
Proof. unfold Equation430. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff262_inst, reff262_op in H. discriminate H. Qed.

Lemma reff262_not437 : ~ @Equation437 Fin3 reff262_inst.
Proof. unfold Equation437. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff262_inst, reff262_op in H. discriminate H. Qed.

Lemma reff262_not440 : ~ @Equation440 Fin3 reff262_inst.
Proof. unfold Equation440. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff262_inst, reff262_op in H. discriminate H. Qed.

Lemma reff262_not464 : ~ @Equation464 Fin3 reff262_inst.
Proof. unfold Equation464. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff262_inst, reff262_op in H. discriminate H. Qed.

Lemma reff262_not467 : ~ @Equation467 Fin3 reff262_inst.
Proof. unfold Equation467. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff262_inst, reff262_op in H. discriminate H. Qed.

Lemma reff262_not474 : ~ @Equation474 Fin3 reff262_inst.
Proof. unfold Equation474. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff262_inst, reff262_op in H. discriminate H. Qed.

Lemma reff262_not477 : ~ @Equation477 Fin3 reff262_inst.
Proof. unfold Equation477. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff262_inst, reff262_op in H. discriminate H. Qed.

Lemma reff262_not501 : ~ @Equation501 Fin3 reff262_inst.
Proof. unfold Equation501. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff262_inst, reff262_op in H. discriminate H. Qed.

Lemma reff262_not504 : ~ @Equation504 Fin3 reff262_inst.
Proof. unfold Equation504. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff262_inst, reff262_op in H. discriminate H. Qed.

Lemma reff262_not511 : ~ @Equation511 Fin3 reff262_inst.
Proof. unfold Equation511. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff262_inst, reff262_op in H. discriminate H. Qed.

Lemma reff262_not614 : ~ @Equation614 Fin3 reff262_inst.
Proof. unfold Equation614. intro H. specialize (H F3_1). unfold magma_op, reff262_inst, reff262_op in H. discriminate H. Qed.

Lemma reff262_not817 : ~ @Equation817 Fin3 reff262_inst.
Proof. unfold Equation817. intro H. specialize (H F3_1). unfold magma_op, reff262_inst, reff262_op in H. discriminate H. Qed.

Lemma reff262_not1021 : ~ @Equation1021 Fin3 reff262_inst.
Proof. unfold Equation1021. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff262_inst, reff262_op in H. discriminate H. Qed.

Lemma reff262_not1023 : ~ @Equation1023 Fin3 reff262_inst.
Proof. unfold Equation1023. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff262_inst, reff262_op in H. discriminate H. Qed.

Lemma reff262_not1026 : ~ @Equation1026 Fin3 reff262_inst.
Proof. unfold Equation1026. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff262_inst, reff262_op in H. discriminate H. Qed.

Lemma reff262_not1029 : ~ @Equation1029 Fin3 reff262_inst.
Proof. unfold Equation1029. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff262_inst, reff262_op in H. discriminate H. Qed.

Lemma reff262_not1036 : ~ @Equation1036 Fin3 reff262_inst.
Proof. unfold Equation1036. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff262_inst, reff262_op in H. discriminate H. Qed.

Lemma reff262_not1039 : ~ @Equation1039 Fin3 reff262_inst.
Proof. unfold Equation1039. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff262_inst, reff262_op in H. discriminate H. Qed.

Lemma reff262_not1046 : ~ @Equation1046 Fin3 reff262_inst.
Proof. unfold Equation1046. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff262_inst, reff262_op in H. discriminate H. Qed.

Lemma reff262_not1049 : ~ @Equation1049 Fin3 reff262_inst.
Proof. unfold Equation1049. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff262_inst, reff262_op in H. discriminate H. Qed.

Lemma reff262_not1073 : ~ @Equation1073 Fin3 reff262_inst.
Proof. unfold Equation1073. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff262_inst, reff262_op in H. discriminate H. Qed.

Lemma reff262_not1076 : ~ @Equation1076 Fin3 reff262_inst.
Proof. unfold Equation1076. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff262_inst, reff262_op in H. discriminate H. Qed.

Lemma reff262_not1083 : ~ @Equation1083 Fin3 reff262_inst.
Proof. unfold Equation1083. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff262_inst, reff262_op in H. discriminate H. Qed.

Lemma reff262_not1086 : ~ @Equation1086 Fin3 reff262_inst.
Proof. unfold Equation1086. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff262_inst, reff262_op in H. discriminate H. Qed.

Lemma reff262_not1110 : ~ @Equation1110 Fin3 reff262_inst.
Proof. unfold Equation1110. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff262_inst, reff262_op in H. discriminate H. Qed.

Lemma reff262_not1113 : ~ @Equation1113 Fin3 reff262_inst.
Proof. unfold Equation1113. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff262_inst, reff262_op in H. discriminate H. Qed.

Lemma reff262_not1120 : ~ @Equation1120 Fin3 reff262_inst.
Proof. unfold Equation1120. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff262_inst, reff262_op in H. discriminate H. Qed.

Lemma reff262_not1224 : ~ @Equation1224 Fin3 reff262_inst.
Proof. unfold Equation1224. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff262_inst, reff262_op in H. discriminate H. Qed.

Lemma reff262_not1226 : ~ @Equation1226 Fin3 reff262_inst.
Proof. unfold Equation1226. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff262_inst, reff262_op in H. discriminate H. Qed.

Lemma reff262_not1229 : ~ @Equation1229 Fin3 reff262_inst.
Proof. unfold Equation1229. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff262_inst, reff262_op in H. discriminate H. Qed.

Lemma reff262_not1232 : ~ @Equation1232 Fin3 reff262_inst.
Proof. unfold Equation1232. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff262_inst, reff262_op in H. discriminate H. Qed.

Lemma reff262_not1239 : ~ @Equation1239 Fin3 reff262_inst.
Proof. unfold Equation1239. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff262_inst, reff262_op in H. discriminate H. Qed.

Lemma reff262_not1242 : ~ @Equation1242 Fin3 reff262_inst.
Proof. unfold Equation1242. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff262_inst, reff262_op in H. discriminate H. Qed.

Lemma reff262_not1249 : ~ @Equation1249 Fin3 reff262_inst.
Proof. unfold Equation1249. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff262_inst, reff262_op in H. discriminate H. Qed.

Lemma reff262_not1252 : ~ @Equation1252 Fin3 reff262_inst.
Proof. unfold Equation1252. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff262_inst, reff262_op in H. discriminate H. Qed.

Lemma reff262_not1276 : ~ @Equation1276 Fin3 reff262_inst.
Proof. unfold Equation1276. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff262_inst, reff262_op in H. discriminate H. Qed.

Lemma reff262_not1279 : ~ @Equation1279 Fin3 reff262_inst.
Proof. unfold Equation1279. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff262_inst, reff262_op in H. discriminate H. Qed.

Lemma reff262_not1286 : ~ @Equation1286 Fin3 reff262_inst.
Proof. unfold Equation1286. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff262_inst, reff262_op in H. discriminate H. Qed.

Lemma reff262_not1289 : ~ @Equation1289 Fin3 reff262_inst.
Proof. unfold Equation1289. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff262_inst, reff262_op in H. discriminate H. Qed.

Lemma reff262_not1313 : ~ @Equation1313 Fin3 reff262_inst.
Proof. unfold Equation1313. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff262_inst, reff262_op in H. discriminate H. Qed.

Lemma reff262_not1316 : ~ @Equation1316 Fin3 reff262_inst.
Proof. unfold Equation1316. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff262_inst, reff262_op in H. discriminate H. Qed.

Lemma reff262_not1323 : ~ @Equation1323 Fin3 reff262_inst.
Proof. unfold Equation1323. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff262_inst, reff262_op in H. discriminate H. Qed.

Lemma reff262_not1426 : ~ @Equation1426 Fin3 reff262_inst.
Proof. unfold Equation1426. intro H. specialize (H F3_1). unfold magma_op, reff262_inst, reff262_op in H. discriminate H. Qed.

Lemma reff262_not1630 : ~ @Equation1630 Fin3 reff262_inst.
Proof. unfold Equation1630. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff262_inst, reff262_op in H. discriminate H. Qed.

Lemma reff262_not1632 : ~ @Equation1632 Fin3 reff262_inst.
Proof. unfold Equation1632. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff262_inst, reff262_op in H. discriminate H. Qed.

Lemma reff262_not1635 : ~ @Equation1635 Fin3 reff262_inst.
Proof. unfold Equation1635. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff262_inst, reff262_op in H. discriminate H. Qed.

Lemma reff262_not1638 : ~ @Equation1638 Fin3 reff262_inst.
Proof. unfold Equation1638. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff262_inst, reff262_op in H. discriminate H. Qed.

Lemma reff262_not1645 : ~ @Equation1645 Fin3 reff262_inst.
Proof. unfold Equation1645. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff262_inst, reff262_op in H. discriminate H. Qed.

Lemma reff262_not1648 : ~ @Equation1648 Fin3 reff262_inst.
Proof. unfold Equation1648. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff262_inst, reff262_op in H. discriminate H. Qed.

Lemma reff262_not1655 : ~ @Equation1655 Fin3 reff262_inst.
Proof. unfold Equation1655. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff262_inst, reff262_op in H. discriminate H. Qed.

Lemma reff262_not1658 : ~ @Equation1658 Fin3 reff262_inst.
Proof. unfold Equation1658. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff262_inst, reff262_op in H. discriminate H. Qed.

Lemma reff262_not1682 : ~ @Equation1682 Fin3 reff262_inst.
Proof. unfold Equation1682. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff262_inst, reff262_op in H. discriminate H. Qed.

Lemma reff262_not1685 : ~ @Equation1685 Fin3 reff262_inst.
Proof. unfold Equation1685. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff262_inst, reff262_op in H. discriminate H. Qed.

Lemma reff262_not1692 : ~ @Equation1692 Fin3 reff262_inst.
Proof. unfold Equation1692. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff262_inst, reff262_op in H. discriminate H. Qed.

Lemma reff262_not1695 : ~ @Equation1695 Fin3 reff262_inst.
Proof. unfold Equation1695. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff262_inst, reff262_op in H. discriminate H. Qed.

Lemma reff262_not1719 : ~ @Equation1719 Fin3 reff262_inst.
Proof. unfold Equation1719. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff262_inst, reff262_op in H. discriminate H. Qed.

Lemma reff262_not1722 : ~ @Equation1722 Fin3 reff262_inst.
Proof. unfold Equation1722. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff262_inst, reff262_op in H. discriminate H. Qed.

Lemma reff262_not1729 : ~ @Equation1729 Fin3 reff262_inst.
Proof. unfold Equation1729. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff262_inst, reff262_op in H. discriminate H. Qed.

Lemma reff262_not1833 : ~ @Equation1833 Fin3 reff262_inst.
Proof. unfold Equation1833. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff262_inst, reff262_op in H. discriminate H. Qed.

Lemma reff262_not1835 : ~ @Equation1835 Fin3 reff262_inst.
Proof. unfold Equation1835. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff262_inst, reff262_op in H. discriminate H. Qed.

Lemma reff262_not1838 : ~ @Equation1838 Fin3 reff262_inst.
Proof. unfold Equation1838. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff262_inst, reff262_op in H. discriminate H. Qed.

Lemma reff262_not1841 : ~ @Equation1841 Fin3 reff262_inst.
Proof. unfold Equation1841. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff262_inst, reff262_op in H. discriminate H. Qed.

Lemma reff262_not1848 : ~ @Equation1848 Fin3 reff262_inst.
Proof. unfold Equation1848. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff262_inst, reff262_op in H. discriminate H. Qed.

Lemma reff262_not1851 : ~ @Equation1851 Fin3 reff262_inst.
Proof. unfold Equation1851. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff262_inst, reff262_op in H. discriminate H. Qed.

Lemma reff262_not1858 : ~ @Equation1858 Fin3 reff262_inst.
Proof. unfold Equation1858. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff262_inst, reff262_op in H. discriminate H. Qed.

Lemma reff262_not1861 : ~ @Equation1861 Fin3 reff262_inst.
Proof. unfold Equation1861. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff262_inst, reff262_op in H. discriminate H. Qed.

Lemma reff262_not1885 : ~ @Equation1885 Fin3 reff262_inst.
Proof. unfold Equation1885. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff262_inst, reff262_op in H. discriminate H. Qed.

Lemma reff262_not1888 : ~ @Equation1888 Fin3 reff262_inst.
Proof. unfold Equation1888. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff262_inst, reff262_op in H. discriminate H. Qed.

Lemma reff262_not1895 : ~ @Equation1895 Fin3 reff262_inst.
Proof. unfold Equation1895. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff262_inst, reff262_op in H. discriminate H. Qed.

Lemma reff262_not1898 : ~ @Equation1898 Fin3 reff262_inst.
Proof. unfold Equation1898. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff262_inst, reff262_op in H. discriminate H. Qed.

Lemma reff262_not1922 : ~ @Equation1922 Fin3 reff262_inst.
Proof. unfold Equation1922. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff262_inst, reff262_op in H. discriminate H. Qed.

Lemma reff262_not1925 : ~ @Equation1925 Fin3 reff262_inst.
Proof. unfold Equation1925. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff262_inst, reff262_op in H. discriminate H. Qed.

Lemma reff262_not1932 : ~ @Equation1932 Fin3 reff262_inst.
Proof. unfold Equation1932. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff262_inst, reff262_op in H. discriminate H. Qed.

Lemma reff262_not2036 : ~ @Equation2036 Fin3 reff262_inst.
Proof. unfold Equation2036. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff262_inst, reff262_op in H. discriminate H. Qed.

Lemma reff262_not2038 : ~ @Equation2038 Fin3 reff262_inst.
Proof. unfold Equation2038. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff262_inst, reff262_op in H. discriminate H. Qed.

Lemma reff262_not2041 : ~ @Equation2041 Fin3 reff262_inst.
Proof. unfold Equation2041. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff262_inst, reff262_op in H. discriminate H. Qed.

Lemma reff262_not2044 : ~ @Equation2044 Fin3 reff262_inst.
Proof. unfold Equation2044. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff262_inst, reff262_op in H. discriminate H. Qed.

Lemma reff262_not2051 : ~ @Equation2051 Fin3 reff262_inst.
Proof. unfold Equation2051. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff262_inst, reff262_op in H. discriminate H. Qed.

Lemma reff262_not2054 : ~ @Equation2054 Fin3 reff262_inst.
Proof. unfold Equation2054. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff262_inst, reff262_op in H. discriminate H. Qed.

Lemma reff262_not2061 : ~ @Equation2061 Fin3 reff262_inst.
Proof. unfold Equation2061. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff262_inst, reff262_op in H. discriminate H. Qed.

Lemma reff262_not2064 : ~ @Equation2064 Fin3 reff262_inst.
Proof. unfold Equation2064. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff262_inst, reff262_op in H. discriminate H. Qed.

Lemma reff262_not2088 : ~ @Equation2088 Fin3 reff262_inst.
Proof. unfold Equation2088. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff262_inst, reff262_op in H. discriminate H. Qed.

Lemma reff262_not2091 : ~ @Equation2091 Fin3 reff262_inst.
Proof. unfold Equation2091. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff262_inst, reff262_op in H. discriminate H. Qed.

Lemma reff262_not2098 : ~ @Equation2098 Fin3 reff262_inst.
Proof. unfold Equation2098. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff262_inst, reff262_op in H. discriminate H. Qed.

Lemma reff262_not2101 : ~ @Equation2101 Fin3 reff262_inst.
Proof. unfold Equation2101. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff262_inst, reff262_op in H. discriminate H. Qed.

Lemma reff262_not2125 : ~ @Equation2125 Fin3 reff262_inst.
Proof. unfold Equation2125. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff262_inst, reff262_op in H. discriminate H. Qed.

Lemma reff262_not2128 : ~ @Equation2128 Fin3 reff262_inst.
Proof. unfold Equation2128. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff262_inst, reff262_op in H. discriminate H. Qed.

Lemma reff262_not2135 : ~ @Equation2135 Fin3 reff262_inst.
Proof. unfold Equation2135. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff262_inst, reff262_op in H. discriminate H. Qed.

Lemma reff262_not2238 : ~ @Equation2238 Fin3 reff262_inst.
Proof. unfold Equation2238. intro H. specialize (H F3_1). unfold magma_op, reff262_inst, reff262_op in H. discriminate H. Qed.

Lemma reff262_not2441 : ~ @Equation2441 Fin3 reff262_inst.
Proof. unfold Equation2441. intro H. specialize (H F3_1). unfold magma_op, reff262_inst, reff262_op in H. discriminate H. Qed.

Lemma reff262_not2644 : ~ @Equation2644 Fin3 reff262_inst.
Proof. unfold Equation2644. intro H. specialize (H F3_1). unfold magma_op, reff262_inst, reff262_op in H. discriminate H. Qed.

Lemma reff262_not2847 : ~ @Equation2847 Fin3 reff262_inst.
Proof. unfold Equation2847. intro H. specialize (H F3_1). unfold magma_op, reff262_inst, reff262_op in H. discriminate H. Qed.

Lemma reff262_not3050 : ~ @Equation3050 Fin3 reff262_inst.
Proof. unfold Equation3050. intro H. specialize (H F3_1). unfold magma_op, reff262_inst, reff262_op in H. discriminate H. Qed.

Lemma reff262_not3254 : ~ @Equation3254 Fin3 reff262_inst.
Proof. unfold Equation3254. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff262_inst, reff262_op in H. discriminate H. Qed.

Lemma reff262_not3256 : ~ @Equation3256 Fin3 reff262_inst.
Proof. unfold Equation3256. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff262_inst, reff262_op in H. discriminate H. Qed.

Lemma reff262_not3259 : ~ @Equation3259 Fin3 reff262_inst.
Proof. unfold Equation3259. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff262_inst, reff262_op in H. discriminate H. Qed.

Lemma reff262_not3262 : ~ @Equation3262 Fin3 reff262_inst.
Proof. unfold Equation3262. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff262_inst, reff262_op in H. discriminate H. Qed.

Lemma reff262_not3272 : ~ @Equation3272 Fin3 reff262_inst.
Proof. unfold Equation3272. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff262_inst, reff262_op in H. discriminate H. Qed.

Lemma reff262_not3279 : ~ @Equation3279 Fin3 reff262_inst.
Proof. unfold Equation3279. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff262_inst, reff262_op in H. discriminate H. Qed.

Lemma reff262_not3308 : ~ @Equation3308 Fin3 reff262_inst.
Proof. unfold Equation3308. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff262_inst, reff262_op in H. discriminate H. Qed.

Lemma reff262_not3315 : ~ @Equation3315 Fin3 reff262_inst.
Proof. unfold Equation3315. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff262_inst, reff262_op in H. discriminate H. Qed.

Lemma reff262_not3318 : ~ @Equation3318 Fin3 reff262_inst.
Proof. unfold Equation3318. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff262_inst, reff262_op in H. discriminate H. Qed.

Lemma reff262_not3342 : ~ @Equation3342 Fin3 reff262_inst.
Proof. unfold Equation3342. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff262_inst, reff262_op in H. discriminate H. Qed.

Lemma reff262_not3345 : ~ @Equation3345 Fin3 reff262_inst.
Proof. unfold Equation3345. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff262_inst, reff262_op in H. discriminate H. Qed.

Lemma reff262_not3352 : ~ @Equation3352 Fin3 reff262_inst.
Proof. unfold Equation3352. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff262_inst, reff262_op in H. discriminate H. Qed.

Lemma reff262_not3456 : ~ @Equation3456 Fin3 reff262_inst.
Proof. unfold Equation3456. intro H. specialize (H F3_1). unfold magma_op, reff262_inst, reff262_op in H. discriminate H. Qed.

Lemma reff262_not3659 : ~ @Equation3659 Fin3 reff262_inst.
Proof. unfold Equation3659. intro H. specialize (H F3_1). unfold magma_op, reff262_inst, reff262_op in H. discriminate H. Qed.

Lemma reff262_not3865 : ~ @Equation3865 Fin3 reff262_inst.
Proof. unfold Equation3865. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff262_inst, reff262_op in H. discriminate H. Qed.

Lemma reff262_not3868 : ~ @Equation3868 Fin3 reff262_inst.
Proof. unfold Equation3868. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff262_inst, reff262_op in H. discriminate H. Qed.

Lemma reff262_not3871 : ~ @Equation3871 Fin3 reff262_inst.
Proof. unfold Equation3871. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff262_inst, reff262_op in H. discriminate H. Qed.

Lemma reff262_not3878 : ~ @Equation3878 Fin3 reff262_inst.
Proof. unfold Equation3878. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff262_inst, reff262_op in H. discriminate H. Qed.

Lemma reff262_not3881 : ~ @Equation3881 Fin3 reff262_inst.
Proof. unfold Equation3881. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff262_inst, reff262_op in H. discriminate H. Qed.

Lemma reff262_not3888 : ~ @Equation3888 Fin3 reff262_inst.
Proof. unfold Equation3888. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff262_inst, reff262_op in H. discriminate H. Qed.

Lemma reff262_not3917 : ~ @Equation3917 Fin3 reff262_inst.
Proof. unfold Equation3917. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff262_inst, reff262_op in H. discriminate H. Qed.

Lemma reff262_not3924 : ~ @Equation3924 Fin3 reff262_inst.
Proof. unfold Equation3924. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff262_inst, reff262_op in H. discriminate H. Qed.

Lemma reff262_not3927 : ~ @Equation3927 Fin3 reff262_inst.
Proof. unfold Equation3927. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff262_inst, reff262_op in H. discriminate H. Qed.

Lemma reff262_not3951 : ~ @Equation3951 Fin3 reff262_inst.
Proof. unfold Equation3951. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff262_inst, reff262_op in H. discriminate H. Qed.

Lemma reff262_not3954 : ~ @Equation3954 Fin3 reff262_inst.
Proof. unfold Equation3954. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff262_inst, reff262_op in H. discriminate H. Qed.

Lemma reff262_not3961 : ~ @Equation3961 Fin3 reff262_inst.
Proof. unfold Equation3961. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff262_inst, reff262_op in H. discriminate H. Qed.

Lemma reff262_not3964 : ~ @Equation3964 Fin3 reff262_inst.
Proof. unfold Equation3964. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff262_inst, reff262_op in H. discriminate H. Qed.

Lemma reff262_not4066 : ~ @Equation4066 Fin3 reff262_inst.
Proof. unfold Equation4066. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff262_inst, reff262_op in H. discriminate H. Qed.

Lemma reff262_not4068 : ~ @Equation4068 Fin3 reff262_inst.
Proof. unfold Equation4068. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff262_inst, reff262_op in H. discriminate H. Qed.

Lemma reff262_not4071 : ~ @Equation4071 Fin3 reff262_inst.
Proof. unfold Equation4071. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff262_inst, reff262_op in H. discriminate H. Qed.

Lemma reff262_not4074 : ~ @Equation4074 Fin3 reff262_inst.
Proof. unfold Equation4074. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff262_inst, reff262_op in H. discriminate H. Qed.

Lemma reff262_not4084 : ~ @Equation4084 Fin3 reff262_inst.
Proof. unfold Equation4084. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff262_inst, reff262_op in H. discriminate H. Qed.

Lemma reff262_not4091 : ~ @Equation4091 Fin3 reff262_inst.
Proof. unfold Equation4091. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff262_inst, reff262_op in H. discriminate H. Qed.

Lemma reff262_not4120 : ~ @Equation4120 Fin3 reff262_inst.
Proof. unfold Equation4120. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff262_inst, reff262_op in H. discriminate H. Qed.

Lemma reff262_not4127 : ~ @Equation4127 Fin3 reff262_inst.
Proof. unfold Equation4127. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff262_inst, reff262_op in H. discriminate H. Qed.

Lemma reff262_not4130 : ~ @Equation4130 Fin3 reff262_inst.
Proof. unfold Equation4130. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff262_inst, reff262_op in H. discriminate H. Qed.

Lemma reff262_not4157 : ~ @Equation4157 Fin3 reff262_inst.
Proof. unfold Equation4157. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff262_inst, reff262_op in H. discriminate H. Qed.

Lemma reff262_not4164 : ~ @Equation4164 Fin3 reff262_inst.
Proof. unfold Equation4164. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff262_inst, reff262_op in H. discriminate H. Qed.

Lemma reff262_not4167 : ~ @Equation4167 Fin3 reff262_inst.
Proof. unfold Equation4167. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff262_inst, reff262_op in H. discriminate H. Qed.

Lemma reff262_not4268 : ~ @Equation4268 Fin3 reff262_inst.
Proof. unfold Equation4268. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff262_inst, reff262_op in H. discriminate H. Qed.

Lemma reff262_not4270 : ~ @Equation4270 Fin3 reff262_inst.
Proof. unfold Equation4270. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff262_inst, reff262_op in H. discriminate H. Qed.

Lemma reff262_not4273 : ~ @Equation4273 Fin3 reff262_inst.
Proof. unfold Equation4273. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff262_inst, reff262_op in H. discriminate H. Qed.

Lemma reff262_not4276 : ~ @Equation4276 Fin3 reff262_inst.
Proof. unfold Equation4276. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff262_inst, reff262_op in H. discriminate H. Qed.

Lemma reff262_not4283 : ~ @Equation4283 Fin3 reff262_inst.
Proof. unfold Equation4283. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff262_inst, reff262_op in H. discriminate H. Qed.

Lemma reff262_not4290 : ~ @Equation4290 Fin3 reff262_inst.
Proof. unfold Equation4290. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff262_inst, reff262_op in H. discriminate H. Qed.

Lemma reff262_not4293 : ~ @Equation4293 Fin3 reff262_inst.
Proof. unfold Equation4293. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff262_inst, reff262_op in H. discriminate H. Qed.

Lemma reff262_not4314 : ~ @Equation4314 Fin3 reff262_inst.
Proof. unfold Equation4314. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff262_inst, reff262_op in H. discriminate H. Qed.

Lemma reff262_not4321 : ~ @Equation4321 Fin3 reff262_inst.
Proof. unfold Equation4321. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff262_inst, reff262_op in H. discriminate H. Qed.

Lemma reff262_not4343 : ~ @Equation4343 Fin3 reff262_inst.
Proof. unfold Equation4343. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff262_inst, reff262_op in H. discriminate H. Qed.

Lemma reff262_not4380 : ~ @Equation4380 Fin3 reff262_inst.
Proof. unfold Equation4380. intro H. specialize (H F3_1). unfold magma_op, reff262_inst, reff262_op in H. discriminate H. Qed.

Lemma reff262_not4583 : ~ @Equation4583 Fin3 reff262_inst.
Proof. unfold Equation4583. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff262_inst, reff262_op in H. discriminate H. Qed.

Lemma reff262_not4585 : ~ @Equation4585 Fin3 reff262_inst.
Proof. unfold Equation4585. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff262_inst, reff262_op in H. discriminate H. Qed.

Lemma reff262_not4588 : ~ @Equation4588 Fin3 reff262_inst.
Proof. unfold Equation4588. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff262_inst, reff262_op in H. discriminate H. Qed.

Lemma reff262_not4591 : ~ @Equation4591 Fin3 reff262_inst.
Proof. unfold Equation4591. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff262_inst, reff262_op in H. discriminate H. Qed.

Lemma reff262_not4598 : ~ @Equation4598 Fin3 reff262_inst.
Proof. unfold Equation4598. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff262_inst, reff262_op in H. discriminate H. Qed.

Lemma reff262_not4605 : ~ @Equation4605 Fin3 reff262_inst.
Proof. unfold Equation4605. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff262_inst, reff262_op in H. discriminate H. Qed.

Lemma reff262_not4608 : ~ @Equation4608 Fin3 reff262_inst.
Proof. unfold Equation4608. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff262_inst, reff262_op in H. discriminate H. Qed.

Lemma reff262_not4629 : ~ @Equation4629 Fin3 reff262_inst.
Proof. unfold Equation4629. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff262_inst, reff262_op in H. discriminate H. Qed.

Lemma reff262_not4636 : ~ @Equation4636 Fin3 reff262_inst.
Proof. unfold Equation4636. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff262_inst, reff262_op in H. discriminate H. Qed.

Lemma reff262_not4658 : ~ @Equation4658 Fin3 reff262_inst.
Proof. unfold Equation4658. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff262_inst, reff262_op in H. discriminate H. Qed.

(** ---- reff264 (Fin3) ---- *)

Definition reff264_op (x y : Fin3) : Fin3 :=
  match x, y with
  | F3_0, F3_0 => F3_0 | F3_0, F3_1 => F3_0 | F3_0, F3_2 => F3_0
  | F3_1, F3_0 => F3_1 | F3_1, F3_1 => F3_0 | F3_1, F3_2 => F3_2
  | F3_2, F3_0 => F3_2 | F3_2, F3_1 => F3_0 | F3_2, F3_2 => F3_1
  end.

#[local] Instance reff264_inst : Magma Fin3 := {| magma_op := reff264_op |}.

Lemma reff264_sat832 : @Equation832 Fin3 reff264_inst.
Proof. unfold Equation832, magma_op, reff264_inst, reff264_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff264_sat846 : @Equation846 Fin3 reff264_inst.
Proof. unfold Equation846, magma_op, reff264_inst, reff264_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff264_sat1035 : @Equation1035 Fin3 reff264_inst.
Proof. unfold Equation1035, magma_op, reff264_inst, reff264_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff264_sat1049 : @Equation1049 Fin3 reff264_inst.
Proof. unfold Equation1049, magma_op, reff264_inst, reff264_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff264_not47 : ~ @Equation47 Fin3 reff264_inst.
Proof. unfold Equation47. intro H. specialize (H F3_1). unfold magma_op, reff264_inst, reff264_op in H. discriminate H. Qed.

Lemma reff264_not99 : ~ @Equation99 Fin3 reff264_inst.
Proof. unfold Equation99. intro H. specialize (H F3_2). unfold magma_op, reff264_inst, reff264_op in H. discriminate H. Qed.

Lemma reff264_not151 : ~ @Equation151 Fin3 reff264_inst.
Proof. unfold Equation151. intro H. specialize (H F3_1). unfold magma_op, reff264_inst, reff264_op in H. discriminate H. Qed.

Lemma reff264_not203 : ~ @Equation203 Fin3 reff264_inst.
Proof. unfold Equation203. intro H. specialize (H F3_1). unfold magma_op, reff264_inst, reff264_op in H. discriminate H. Qed.

Lemma reff264_not255 : ~ @Equation255 Fin3 reff264_inst.
Proof. unfold Equation255. intro H. specialize (H F3_1). unfold magma_op, reff264_inst, reff264_op in H. discriminate H. Qed.

Lemma reff264_not359 : ~ @Equation359 Fin3 reff264_inst.
Proof. unfold Equation359. intro H. specialize (H F3_2). unfold magma_op, reff264_inst, reff264_op in H. discriminate H. Qed.

Lemma reff264_not411 : ~ @Equation411 Fin3 reff264_inst.
Proof. unfold Equation411. intro H. specialize (H F3_2). unfold magma_op, reff264_inst, reff264_op in H. discriminate H. Qed.

Lemma reff264_not614 : ~ @Equation614 Fin3 reff264_inst.
Proof. unfold Equation614. intro H. specialize (H F3_1). unfold magma_op, reff264_inst, reff264_op in H. discriminate H. Qed.

Lemma reff264_not822 : ~ @Equation822 Fin3 reff264_inst.
Proof. unfold Equation822. intro H. specialize (H F3_1 F3_0). unfold magma_op, reff264_inst, reff264_op in H. discriminate H. Qed.

Lemma reff264_not1022 : ~ @Equation1022 Fin3 reff264_inst.
Proof. unfold Equation1022. intro H. specialize (H F3_2 F3_0). unfold magma_op, reff264_inst, reff264_op in H. discriminate H. Qed.

Lemma reff264_not1025 : ~ @Equation1025 Fin3 reff264_inst.
Proof. unfold Equation1025. intro H. specialize (H F3_2 F3_0). unfold magma_op, reff264_inst, reff264_op in H. discriminate H. Qed.

Lemma reff264_not1028 : ~ @Equation1028 Fin3 reff264_inst.
Proof. unfold Equation1028. intro H. specialize (H F3_2 F3_0). unfold magma_op, reff264_inst, reff264_op in H. discriminate H. Qed.

Lemma reff264_not1223 : ~ @Equation1223 Fin3 reff264_inst.
Proof. unfold Equation1223. intro H. specialize (H F3_2). unfold magma_op, reff264_inst, reff264_op in H. discriminate H. Qed.

Lemma reff264_not1426 : ~ @Equation1426 Fin3 reff264_inst.
Proof. unfold Equation1426. intro H. specialize (H F3_1). unfold magma_op, reff264_inst, reff264_op in H. discriminate H. Qed.

Lemma reff264_not1629 : ~ @Equation1629 Fin3 reff264_inst.
Proof. unfold Equation1629. intro H. specialize (H F3_1). unfold magma_op, reff264_inst, reff264_op in H. discriminate H. Qed.

Lemma reff264_not1832 : ~ @Equation1832 Fin3 reff264_inst.
Proof. unfold Equation1832. intro H. specialize (H F3_2). unfold magma_op, reff264_inst, reff264_op in H. discriminate H. Qed.

Lemma reff264_not2035 : ~ @Equation2035 Fin3 reff264_inst.
Proof. unfold Equation2035. intro H. specialize (H F3_1). unfold magma_op, reff264_inst, reff264_op in H. discriminate H. Qed.

Lemma reff264_not2238 : ~ @Equation2238 Fin3 reff264_inst.
Proof. unfold Equation2238. intro H. specialize (H F3_1). unfold magma_op, reff264_inst, reff264_op in H. discriminate H. Qed.

Lemma reff264_not2441 : ~ @Equation2441 Fin3 reff264_inst.
Proof. unfold Equation2441. intro H. specialize (H F3_1). unfold magma_op, reff264_inst, reff264_op in H. discriminate H. Qed.

Lemma reff264_not2644 : ~ @Equation2644 Fin3 reff264_inst.
Proof. unfold Equation2644. intro H. specialize (H F3_1). unfold magma_op, reff264_inst, reff264_op in H. discriminate H. Qed.

Lemma reff264_not2847 : ~ @Equation2847 Fin3 reff264_inst.
Proof. unfold Equation2847. intro H. specialize (H F3_1). unfold magma_op, reff264_inst, reff264_op in H. discriminate H. Qed.

Lemma reff264_not3050 : ~ @Equation3050 Fin3 reff264_inst.
Proof. unfold Equation3050. intro H. specialize (H F3_1). unfold magma_op, reff264_inst, reff264_op in H. discriminate H. Qed.

Lemma reff264_not3253 : ~ @Equation3253 Fin3 reff264_inst.
Proof. unfold Equation3253. intro H. specialize (H F3_2). unfold magma_op, reff264_inst, reff264_op in H. discriminate H. Qed.

Lemma reff264_not3456 : ~ @Equation3456 Fin3 reff264_inst.
Proof. unfold Equation3456. intro H. specialize (H F3_1). unfold magma_op, reff264_inst, reff264_op in H. discriminate H. Qed.

Lemma reff264_not3659 : ~ @Equation3659 Fin3 reff264_inst.
Proof. unfold Equation3659. intro H. specialize (H F3_2). unfold magma_op, reff264_inst, reff264_op in H. discriminate H. Qed.

Lemma reff264_not3862 : ~ @Equation3862 Fin3 reff264_inst.
Proof. unfold Equation3862. intro H. specialize (H F3_2). unfold magma_op, reff264_inst, reff264_op in H. discriminate H. Qed.

Lemma reff264_not4066 : ~ @Equation4066 Fin3 reff264_inst.
Proof. unfold Equation4066. intro H. specialize (H F3_2 F3_0). unfold magma_op, reff264_inst, reff264_op in H. discriminate H. Qed.

Lemma reff264_not4067 : ~ @Equation4067 Fin3 reff264_inst.
Proof. unfold Equation4067. intro H. specialize (H F3_2 F3_0). unfold magma_op, reff264_inst, reff264_op in H. discriminate H. Qed.

Lemma reff264_not4068 : ~ @Equation4068 Fin3 reff264_inst.
Proof. unfold Equation4068. intro H. specialize (H F3_2 F3_1). unfold magma_op, reff264_inst, reff264_op in H. discriminate H. Qed.

Lemma reff264_not4070 : ~ @Equation4070 Fin3 reff264_inst.
Proof. unfold Equation4070. intro H. specialize (H F3_2 F3_0). unfold magma_op, reff264_inst, reff264_op in H. discriminate H. Qed.

Lemma reff264_not4071 : ~ @Equation4071 Fin3 reff264_inst.
Proof. unfold Equation4071. intro H. specialize (H F3_2 F3_1). unfold magma_op, reff264_inst, reff264_op in H. discriminate H. Qed.

Lemma reff264_not4073 : ~ @Equation4073 Fin3 reff264_inst.
Proof. unfold Equation4073. intro H. specialize (H F3_2 F3_1). unfold magma_op, reff264_inst, reff264_op in H. discriminate H. Qed.

Lemma reff264_not4074 : ~ @Equation4074 Fin3 reff264_inst.
Proof. unfold Equation4074. intro H. specialize (H F3_1 F3_0). unfold magma_op, reff264_inst, reff264_op in H. discriminate H. Qed.

Lemma reff264_not4080 : ~ @Equation4080 Fin3 reff264_inst.
Proof. unfold Equation4080. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff264_inst, reff264_op in H. discriminate H. Qed.

Lemma reff264_not4083 : ~ @Equation4083 Fin3 reff264_inst.
Proof. unfold Equation4083. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff264_inst, reff264_op in H. discriminate H. Qed.

Lemma reff264_not4084 : ~ @Equation4084 Fin3 reff264_inst.
Proof. unfold Equation4084. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff264_inst, reff264_op in H. discriminate H. Qed.

Lemma reff264_not4090 : ~ @Equation4090 Fin3 reff264_inst.
Proof. unfold Equation4090. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff264_inst, reff264_op in H. discriminate H. Qed.

Lemma reff264_not4091 : ~ @Equation4091 Fin3 reff264_inst.
Proof. unfold Equation4091. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff264_inst, reff264_op in H. discriminate H. Qed.

Lemma reff264_not4093 : ~ @Equation4093 Fin3 reff264_inst.
Proof. unfold Equation4093. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff264_inst, reff264_op in H. discriminate H. Qed.

Lemma reff264_not4118 : ~ @Equation4118 Fin3 reff264_inst.
Proof. unfold Equation4118. intro H. specialize (H F3_1 F3_0). unfold magma_op, reff264_inst, reff264_op in H. discriminate H. Qed.

Lemma reff264_not4120 : ~ @Equation4120 Fin3 reff264_inst.
Proof. unfold Equation4120. intro H. specialize (H F3_1 F3_0). unfold magma_op, reff264_inst, reff264_op in H. discriminate H. Qed.

Lemma reff264_not4121 : ~ @Equation4121 Fin3 reff264_inst.
Proof. unfold Equation4121. intro H. specialize (H F3_1 F3_0). unfold magma_op, reff264_inst, reff264_op in H. discriminate H. Qed.

Lemma reff264_not4127 : ~ @Equation4127 Fin3 reff264_inst.
Proof. unfold Equation4127. intro H. specialize (H F3_1 F3_0). unfold magma_op, reff264_inst, reff264_op in H. discriminate H. Qed.

Lemma reff264_not4128 : ~ @Equation4128 Fin3 reff264_inst.
Proof. unfold Equation4128. intro H. specialize (H F3_1 F3_0). unfold magma_op, reff264_inst, reff264_op in H. discriminate H. Qed.

Lemma reff264_not4130 : ~ @Equation4130 Fin3 reff264_inst.
Proof. unfold Equation4130. intro H. specialize (H F3_1 F3_0). unfold magma_op, reff264_inst, reff264_op in H. discriminate H. Qed.

Lemma reff264_not4155 : ~ @Equation4155 Fin3 reff264_inst.
Proof. unfold Equation4155. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff264_inst, reff264_op in H. discriminate H. Qed.

Lemma reff264_not4157 : ~ @Equation4157 Fin3 reff264_inst.
Proof. unfold Equation4157. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff264_inst, reff264_op in H. discriminate H. Qed.

Lemma reff264_not4158 : ~ @Equation4158 Fin3 reff264_inst.
Proof. unfold Equation4158. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff264_inst, reff264_op in H. discriminate H. Qed.

Lemma reff264_not4164 : ~ @Equation4164 Fin3 reff264_inst.
Proof. unfold Equation4164. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff264_inst, reff264_op in H. discriminate H. Qed.

Lemma reff264_not4165 : ~ @Equation4165 Fin3 reff264_inst.
Proof. unfold Equation4165. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff264_inst, reff264_op in H. discriminate H. Qed.

Lemma reff264_not4167 : ~ @Equation4167 Fin3 reff264_inst.
Proof. unfold Equation4167. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff264_inst, reff264_op in H. discriminate H. Qed.

Lemma reff264_not4380 : ~ @Equation4380 Fin3 reff264_inst.
Proof. unfold Equation4380. intro H. specialize (H F3_1). unfold magma_op, reff264_inst, reff264_op in H. discriminate H. Qed.

(** ---- reff268 (Fin4) ---- *)

Definition reff268_op (x y : Fin4) : Fin4 :=
  match x, y with
  | F4_0, F4_0 => F4_0 | F4_0, F4_1 => F4_2 | F4_0, F4_2 => F4_2 | F4_0, F4_3 => F4_0
  | F4_1, F4_0 => F4_1 | F4_1, F4_1 => F4_1 | F4_1, F4_2 => F4_3 | F4_1, F4_3 => F4_3
  | F4_2, F4_0 => F4_2 | F4_2, F4_1 => F4_0 | F4_2, F4_2 => F4_0 | F4_2, F4_3 => F4_2
  | F4_3, F4_0 => F4_3 | F4_3, F4_1 => F4_3 | F4_3, F4_2 => F4_1 | F4_3, F4_3 => F4_1
  end.

#[local] Instance reff268_inst : Magma Fin4 := {| magma_op := reff268_op |}.

Lemma reff268_sat8 : @Equation8 Fin4 reff268_inst.
Proof. unfold Equation8, magma_op, reff268_inst, reff268_op. intros x. destruct x; reflexivity. Qed.

Lemma reff268_sat26 : @Equation26 Fin4 reff268_inst.
Proof. unfold Equation26, magma_op, reff268_inst, reff268_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff268_sat429 : @Equation429 Fin4 reff268_inst.
Proof. unfold Equation429, magma_op, reff268_inst, reff268_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff268_sat617 : @Equation617 Fin4 reff268_inst.
Proof. unfold Equation617, magma_op, reff268_inst, reff268_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff268_sat823 : @Equation823 Fin4 reff268_inst.
Proof. unfold Equation823, magma_op, reff268_inst, reff268_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff268_sat833 : @Equation833 Fin4 reff268_inst.
Proof. unfold Equation833, magma_op, reff268_inst, reff268_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff268_sat1023 : @Equation1023 Fin4 reff268_inst.
Proof. unfold Equation1023, magma_op, reff268_inst, reff268_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff268_sat1038 : @Equation1038 Fin4 reff268_inst.
Proof. unfold Equation1038, magma_op, reff268_inst, reff268_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff268_sat1226 : @Equation1226 Fin4 reff268_inst.
Proof. unfold Equation1226, magma_op, reff268_inst, reff268_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff268_sat1229 : @Equation1229 Fin4 reff268_inst.
Proof. unfold Equation1229, magma_op, reff268_inst, reff268_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff268_sat1231 : @Equation1231 Fin4 reff268_inst.
Proof. unfold Equation1231, magma_op, reff268_inst, reff268_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff268_sat1442 : @Equation1442 Fin4 reff268_inst.
Proof. unfold Equation1442, magma_op, reff268_inst, reff268_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff268_sat1455 : @Equation1455 Fin4 reff268_inst.
Proof. unfold Equation1455, magma_op, reff268_inst, reff268_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff268_sat1645 : @Equation1645 Fin4 reff268_inst.
Proof. unfold Equation1645, magma_op, reff268_inst, reff268_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff268_sat1647 : @Equation1647 Fin4 reff268_inst.
Proof. unfold Equation1647, magma_op, reff268_inst, reff268_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff268_sat2041 : @Equation2041 Fin4 reff268_inst.
Proof. unfold Equation2041, magma_op, reff268_inst, reff268_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff268_sat2051 : @Equation2051 Fin4 reff268_inst.
Proof. unfold Equation2051, magma_op, reff268_inst, reff268_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff268_sat2060 : @Equation2060 Fin4 reff268_inst.
Proof. unfold Equation2060, magma_op, reff268_inst, reff268_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff268_sat2241 : @Equation2241 Fin4 reff268_inst.
Proof. unfold Equation2241, magma_op, reff268_inst, reff268_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff268_sat2267 : @Equation2267 Fin4 reff268_inst.
Proof. unfold Equation2267, magma_op, reff268_inst, reff268_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff268_sat2444 : @Equation2444 Fin4 reff268_inst.
Proof. unfold Equation2444, magma_op, reff268_inst, reff268_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff268_sat2447 : @Equation2447 Fin4 reff268_inst.
Proof. unfold Equation2447, magma_op, reff268_inst, reff268_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff268_sat2647 : @Equation2647 Fin4 reff268_inst.
Proof. unfold Equation2647, magma_op, reff268_inst, reff268_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff268_sat2660 : @Equation2660 Fin4 reff268_inst.
Proof. unfold Equation2660, magma_op, reff268_inst, reff268_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff268_sat2662 : @Equation2662 Fin4 reff268_inst.
Proof. unfold Equation2662, magma_op, reff268_inst, reff268_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff268_sat2850 : @Equation2850 Fin4 reff268_inst.
Proof. unfold Equation2850, magma_op, reff268_inst, reff268_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff268_sat2853 : @Equation2853 Fin4 reff268_inst.
Proof. unfold Equation2853, magma_op, reff268_inst, reff268_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff268_sat2855 : @Equation2855 Fin4 reff268_inst.
Proof. unfold Equation2855, magma_op, reff268_inst, reff268_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff268_sat3091 : @Equation3091 Fin4 reff268_inst.
Proof. unfold Equation3091, magma_op, reff268_inst, reff268_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff268_sat3306 : @Equation3306 Fin4 reff268_inst.
Proof. unfold Equation3306, magma_op, reff268_inst, reff268_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff268_sat3509 : @Equation3509 Fin4 reff268_inst.
Proof. unfold Equation3509, magma_op, reff268_inst, reff268_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff268_sat3511 : @Equation3511 Fin4 reff268_inst.
Proof. unfold Equation3511, magma_op, reff268_inst, reff268_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff268_sat3665 : @Equation3665 Fin4 reff268_inst.
Proof. unfold Equation3665, magma_op, reff268_inst, reff268_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff268_sat3712 : @Equation3712 Fin4 reff268_inst.
Proof. unfold Equation3712, magma_op, reff268_inst, reff268_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff268_sat3721 : @Equation3721 Fin4 reff268_inst.
Proof. unfold Equation3721, magma_op, reff268_inst, reff268_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff268_sat3865 : @Equation3865 Fin4 reff268_inst.
Proof. unfold Equation3865, magma_op, reff268_inst, reff268_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff268_sat3917 : @Equation3917 Fin4 reff268_inst.
Proof. unfold Equation3917, magma_op, reff268_inst, reff268_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff268_sat4143 : @Equation4143 Fin4 reff268_inst.
Proof. unfold Equation4143, magma_op, reff268_inst, reff268_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff268_sat4383 : @Equation4383 Fin4 reff268_inst.
Proof. unfold Equation4383, magma_op, reff268_inst, reff268_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff268_sat4396 : @Equation4396 Fin4 reff268_inst.
Proof. unfold Equation4396, magma_op, reff268_inst, reff268_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff268_sat4398 : @Equation4398 Fin4 reff268_inst.
Proof. unfold Equation4398, magma_op, reff268_inst, reff268_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff268_sat4673 : @Equation4673 Fin4 reff268_inst.
Proof. unfold Equation4673, magma_op, reff268_inst, reff268_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff268_not47 : ~ @Equation47 Fin4 reff268_inst.
Proof. unfold Equation47. intro H. specialize (H F4_2). unfold magma_op, reff268_inst, reff268_op in H. discriminate H. Qed.

Lemma reff268_not99 : ~ @Equation99 Fin4 reff268_inst.
Proof. unfold Equation99. intro H. specialize (H F4_2). unfold magma_op, reff268_inst, reff268_op in H. discriminate H. Qed.

Lemma reff268_not151 : ~ @Equation151 Fin4 reff268_inst.
Proof. unfold Equation151. intro H. specialize (H F4_2). unfold magma_op, reff268_inst, reff268_op in H. discriminate H. Qed.

Lemma reff268_not203 : ~ @Equation203 Fin4 reff268_inst.
Proof. unfold Equation203. intro H. specialize (H F4_2). unfold magma_op, reff268_inst, reff268_op in H. discriminate H. Qed.

Lemma reff268_not255 : ~ @Equation255 Fin4 reff268_inst.
Proof. unfold Equation255. intro H. specialize (H F4_2). unfold magma_op, reff268_inst, reff268_op in H. discriminate H. Qed.

Lemma reff268_not307 : ~ @Equation307 Fin4 reff268_inst.
Proof. unfold Equation307. intro H. specialize (H F4_2). unfold magma_op, reff268_inst, reff268_op in H. discriminate H. Qed.

Lemma reff268_not359 : ~ @Equation359 Fin4 reff268_inst.
Proof. unfold Equation359. intro H. specialize (H F4_2). unfold magma_op, reff268_inst, reff268_op in H. discriminate H. Qed.

Lemma reff268_not412 : ~ @Equation412 Fin4 reff268_inst.
Proof. unfold Equation412. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff268_inst, reff268_op in H. discriminate H. Qed.

Lemma reff268_not413 : ~ @Equation413 Fin4 reff268_inst.
Proof. unfold Equation413. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff268_inst, reff268_op in H. discriminate H. Qed.

Lemma reff268_not414 : ~ @Equation414 Fin4 reff268_inst.
Proof. unfold Equation414. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff268_inst, reff268_op in H. discriminate H. Qed.

Lemma reff268_not416 : ~ @Equation416 Fin4 reff268_inst.
Proof. unfold Equation416. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff268_inst, reff268_op in H. discriminate H. Qed.

Lemma reff268_not417 : ~ @Equation417 Fin4 reff268_inst.
Proof. unfold Equation417. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff268_inst, reff268_op in H. discriminate H. Qed.

Lemma reff268_not419 : ~ @Equation419 Fin4 reff268_inst.
Proof. unfold Equation419. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff268_inst, reff268_op in H. discriminate H. Qed.

Lemma reff268_not420 : ~ @Equation420 Fin4 reff268_inst.
Proof. unfold Equation420. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff268_inst, reff268_op in H. discriminate H. Qed.

Lemma reff268_not426 : ~ @Equation426 Fin4 reff268_inst.
Proof. unfold Equation426. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff268_inst, reff268_op in H. discriminate H. Qed.

Lemma reff268_not427 : ~ @Equation427 Fin4 reff268_inst.
Proof. unfold Equation427. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff268_inst, reff268_op in H. discriminate H. Qed.

Lemma reff268_not430 : ~ @Equation430 Fin4 reff268_inst.
Proof. unfold Equation430. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff268_inst, reff268_op in H. discriminate H. Qed.

Lemma reff268_not436 : ~ @Equation436 Fin4 reff268_inst.
Proof. unfold Equation436. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff268_inst, reff268_op in H. discriminate H. Qed.

Lemma reff268_not437 : ~ @Equation437 Fin4 reff268_inst.
Proof. unfold Equation437. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff268_inst, reff268_op in H. discriminate H. Qed.

Lemma reff268_not439 : ~ @Equation439 Fin4 reff268_inst.
Proof. unfold Equation439. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff268_inst, reff268_op in H. discriminate H. Qed.

Lemma reff268_not440 : ~ @Equation440 Fin4 reff268_inst.
Proof. unfold Equation440. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff268_inst, reff268_op in H. discriminate H. Qed.

Lemma reff268_not463 : ~ @Equation463 Fin4 reff268_inst.
Proof. unfold Equation463. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff268_inst, reff268_op in H. discriminate H. Qed.

Lemma reff268_not464 : ~ @Equation464 Fin4 reff268_inst.
Proof. unfold Equation464. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff268_inst, reff268_op in H. discriminate H. Qed.

Lemma reff268_not466 : ~ @Equation466 Fin4 reff268_inst.
Proof. unfold Equation466. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff268_inst, reff268_op in H. discriminate H. Qed.

Lemma reff268_not467 : ~ @Equation467 Fin4 reff268_inst.
Proof. unfold Equation467. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff268_inst, reff268_op in H. discriminate H. Qed.

Lemma reff268_not473 : ~ @Equation473 Fin4 reff268_inst.
Proof. unfold Equation473. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff268_inst, reff268_op in H. discriminate H. Qed.

Lemma reff268_not474 : ~ @Equation474 Fin4 reff268_inst.
Proof. unfold Equation474. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff268_inst, reff268_op in H. discriminate H. Qed.

Lemma reff268_not476 : ~ @Equation476 Fin4 reff268_inst.
Proof. unfold Equation476. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff268_inst, reff268_op in H. discriminate H. Qed.

Lemma reff268_not477 : ~ @Equation477 Fin4 reff268_inst.
Proof. unfold Equation477. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff268_inst, reff268_op in H. discriminate H. Qed.

Lemma reff268_not500 : ~ @Equation500 Fin4 reff268_inst.
Proof. unfold Equation500. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff268_inst, reff268_op in H. discriminate H. Qed.

Lemma reff268_not501 : ~ @Equation501 Fin4 reff268_inst.
Proof. unfold Equation501. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff268_inst, reff268_op in H. discriminate H. Qed.

Lemma reff268_not503 : ~ @Equation503 Fin4 reff268_inst.
Proof. unfold Equation503. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff268_inst, reff268_op in H. discriminate H. Qed.

Lemma reff268_not504 : ~ @Equation504 Fin4 reff268_inst.
Proof. unfold Equation504. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff268_inst, reff268_op in H. discriminate H. Qed.

Lemma reff268_not510 : ~ @Equation510 Fin4 reff268_inst.
Proof. unfold Equation510. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff268_inst, reff268_op in H. discriminate H. Qed.

Lemma reff268_not511 : ~ @Equation511 Fin4 reff268_inst.
Proof. unfold Equation511. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff268_inst, reff268_op in H. discriminate H. Qed.

Lemma reff268_not513 : ~ @Equation513 Fin4 reff268_inst.
Proof. unfold Equation513. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff268_inst, reff268_op in H. discriminate H. Qed.

Lemma reff268_not615 : ~ @Equation615 Fin4 reff268_inst.
Proof. unfold Equation615. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff268_inst, reff268_op in H. discriminate H. Qed.

Lemma reff268_not616 : ~ @Equation616 Fin4 reff268_inst.
Proof. unfold Equation616. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff268_inst, reff268_op in H. discriminate H. Qed.

Lemma reff268_not619 : ~ @Equation619 Fin4 reff268_inst.
Proof. unfold Equation619. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff268_inst, reff268_op in H. discriminate H. Qed.

Lemma reff268_not620 : ~ @Equation620 Fin4 reff268_inst.
Proof. unfold Equation620. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff268_inst, reff268_op in H. discriminate H. Qed.

Lemma reff268_not622 : ~ @Equation622 Fin4 reff268_inst.
Proof. unfold Equation622. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff268_inst, reff268_op in H. discriminate H. Qed.

Lemma reff268_not623 : ~ @Equation623 Fin4 reff268_inst.
Proof. unfold Equation623. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff268_inst, reff268_op in H. discriminate H. Qed.

Lemma reff268_not629 : ~ @Equation629 Fin4 reff268_inst.
Proof. unfold Equation629. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff268_inst, reff268_op in H. discriminate H. Qed.

Lemma reff268_not630 : ~ @Equation630 Fin4 reff268_inst.
Proof. unfold Equation630. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff268_inst, reff268_op in H. discriminate H. Qed.

Lemma reff268_not632 : ~ @Equation632 Fin4 reff268_inst.
Proof. unfold Equation632. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff268_inst, reff268_op in H. discriminate H. Qed.

Lemma reff268_not633 : ~ @Equation633 Fin4 reff268_inst.
Proof. unfold Equation633. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff268_inst, reff268_op in H. discriminate H. Qed.

Lemma reff268_not639 : ~ @Equation639 Fin4 reff268_inst.
Proof. unfold Equation639. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff268_inst, reff268_op in H. discriminate H. Qed.

Lemma reff268_not640 : ~ @Equation640 Fin4 reff268_inst.
Proof. unfold Equation640. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff268_inst, reff268_op in H. discriminate H. Qed.

Lemma reff268_not642 : ~ @Equation642 Fin4 reff268_inst.
Proof. unfold Equation642. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff268_inst, reff268_op in H. discriminate H. Qed.

Lemma reff268_not643 : ~ @Equation643 Fin4 reff268_inst.
Proof. unfold Equation643. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff268_inst, reff268_op in H. discriminate H. Qed.

Lemma reff268_not666 : ~ @Equation666 Fin4 reff268_inst.
Proof. unfold Equation666. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff268_inst, reff268_op in H. discriminate H. Qed.

Lemma reff268_not667 : ~ @Equation667 Fin4 reff268_inst.
Proof. unfold Equation667. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff268_inst, reff268_op in H. discriminate H. Qed.

Lemma reff268_not669 : ~ @Equation669 Fin4 reff268_inst.
Proof. unfold Equation669. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff268_inst, reff268_op in H. discriminate H. Qed.

Lemma reff268_not670 : ~ @Equation670 Fin4 reff268_inst.
Proof. unfold Equation670. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff268_inst, reff268_op in H. discriminate H. Qed.

Lemma reff268_not676 : ~ @Equation676 Fin4 reff268_inst.
Proof. unfold Equation676. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff268_inst, reff268_op in H. discriminate H. Qed.

Lemma reff268_not677 : ~ @Equation677 Fin4 reff268_inst.
Proof. unfold Equation677. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff268_inst, reff268_op in H. discriminate H. Qed.

Lemma reff268_not679 : ~ @Equation679 Fin4 reff268_inst.
Proof. unfold Equation679. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff268_inst, reff268_op in H. discriminate H. Qed.

Lemma reff268_not680 : ~ @Equation680 Fin4 reff268_inst.
Proof. unfold Equation680. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff268_inst, reff268_op in H. discriminate H. Qed.

Lemma reff268_not703 : ~ @Equation703 Fin4 reff268_inst.
Proof. unfold Equation703. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff268_inst, reff268_op in H. discriminate H. Qed.

Lemma reff268_not704 : ~ @Equation704 Fin4 reff268_inst.
Proof. unfold Equation704. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff268_inst, reff268_op in H. discriminate H. Qed.

Lemma reff268_not706 : ~ @Equation706 Fin4 reff268_inst.
Proof. unfold Equation706. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff268_inst, reff268_op in H. discriminate H. Qed.

Lemma reff268_not707 : ~ @Equation707 Fin4 reff268_inst.
Proof. unfold Equation707. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff268_inst, reff268_op in H. discriminate H. Qed.

Lemma reff268_not713 : ~ @Equation713 Fin4 reff268_inst.
Proof. unfold Equation713. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff268_inst, reff268_op in H. discriminate H. Qed.

Lemma reff268_not714 : ~ @Equation714 Fin4 reff268_inst.
Proof. unfold Equation714. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff268_inst, reff268_op in H. discriminate H. Qed.

Lemma reff268_not716 : ~ @Equation716 Fin4 reff268_inst.
Proof. unfold Equation716. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff268_inst, reff268_op in H. discriminate H. Qed.

Lemma reff268_not818 : ~ @Equation818 Fin4 reff268_inst.
Proof. unfold Equation818. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff268_inst, reff268_op in H. discriminate H. Qed.

Lemma reff268_not819 : ~ @Equation819 Fin4 reff268_inst.
Proof. unfold Equation819. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff268_inst, reff268_op in H. discriminate H. Qed.

Lemma reff268_not820 : ~ @Equation820 Fin4 reff268_inst.
Proof. unfold Equation820. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff268_inst, reff268_op in H. discriminate H. Qed.

Lemma reff268_not822 : ~ @Equation822 Fin4 reff268_inst.
Proof. unfold Equation822. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff268_inst, reff268_op in H. discriminate H. Qed.

Lemma reff268_not825 : ~ @Equation825 Fin4 reff268_inst.
Proof. unfold Equation825. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff268_inst, reff268_op in H. discriminate H. Qed.

Lemma reff268_not826 : ~ @Equation826 Fin4 reff268_inst.
Proof. unfold Equation826. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff268_inst, reff268_op in H. discriminate H. Qed.

Lemma reff268_not832 : ~ @Equation832 Fin4 reff268_inst.
Proof. unfold Equation832. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff268_inst, reff268_op in H. discriminate H. Qed.

Lemma reff268_not835 : ~ @Equation835 Fin4 reff268_inst.
Proof. unfold Equation835. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff268_inst, reff268_op in H. discriminate H. Qed.

Lemma reff268_not836 : ~ @Equation836 Fin4 reff268_inst.
Proof. unfold Equation836. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff268_inst, reff268_op in H. discriminate H. Qed.

Lemma reff268_not842 : ~ @Equation842 Fin4 reff268_inst.
Proof. unfold Equation842. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff268_inst, reff268_op in H. discriminate H. Qed.

Lemma reff268_not843 : ~ @Equation843 Fin4 reff268_inst.
Proof. unfold Equation843. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff268_inst, reff268_op in H. discriminate H. Qed.

Lemma reff268_not845 : ~ @Equation845 Fin4 reff268_inst.
Proof. unfold Equation845. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff268_inst, reff268_op in H. discriminate H. Qed.

Lemma reff268_not846 : ~ @Equation846 Fin4 reff268_inst.
Proof. unfold Equation846. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff268_inst, reff268_op in H. discriminate H. Qed.

Lemma reff268_not869 : ~ @Equation869 Fin4 reff268_inst.
Proof. unfold Equation869. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff268_inst, reff268_op in H. discriminate H. Qed.

Lemma reff268_not870 : ~ @Equation870 Fin4 reff268_inst.
Proof. unfold Equation870. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff268_inst, reff268_op in H. discriminate H. Qed.

Lemma reff268_not872 : ~ @Equation872 Fin4 reff268_inst.
Proof. unfold Equation872. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff268_inst, reff268_op in H. discriminate H. Qed.

Lemma reff268_not873 : ~ @Equation873 Fin4 reff268_inst.
Proof. unfold Equation873. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff268_inst, reff268_op in H. discriminate H. Qed.

Lemma reff268_not879 : ~ @Equation879 Fin4 reff268_inst.
Proof. unfold Equation879. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff268_inst, reff268_op in H. discriminate H. Qed.

Lemma reff268_not880 : ~ @Equation880 Fin4 reff268_inst.
Proof. unfold Equation880. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff268_inst, reff268_op in H. discriminate H. Qed.

Lemma reff268_not882 : ~ @Equation882 Fin4 reff268_inst.
Proof. unfold Equation882. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff268_inst, reff268_op in H. discriminate H. Qed.

Lemma reff268_not883 : ~ @Equation883 Fin4 reff268_inst.
Proof. unfold Equation883. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff268_inst, reff268_op in H. discriminate H. Qed.

Lemma reff268_not906 : ~ @Equation906 Fin4 reff268_inst.
Proof. unfold Equation906. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff268_inst, reff268_op in H. discriminate H. Qed.

Lemma reff268_not907 : ~ @Equation907 Fin4 reff268_inst.
Proof. unfold Equation907. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff268_inst, reff268_op in H. discriminate H. Qed.

Lemma reff268_not909 : ~ @Equation909 Fin4 reff268_inst.
Proof. unfold Equation909. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff268_inst, reff268_op in H. discriminate H. Qed.

Lemma reff268_not910 : ~ @Equation910 Fin4 reff268_inst.
Proof. unfold Equation910. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff268_inst, reff268_op in H. discriminate H. Qed.

Lemma reff268_not916 : ~ @Equation916 Fin4 reff268_inst.
Proof. unfold Equation916. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff268_inst, reff268_op in H. discriminate H. Qed.

Lemma reff268_not917 : ~ @Equation917 Fin4 reff268_inst.
Proof. unfold Equation917. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff268_inst, reff268_op in H. discriminate H. Qed.

Lemma reff268_not919 : ~ @Equation919 Fin4 reff268_inst.
Proof. unfold Equation919. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff268_inst, reff268_op in H. discriminate H. Qed.

Lemma reff268_not1021 : ~ @Equation1021 Fin4 reff268_inst.
Proof. unfold Equation1021. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff268_inst, reff268_op in H. discriminate H. Qed.

Lemma reff268_not1022 : ~ @Equation1022 Fin4 reff268_inst.
Proof. unfold Equation1022. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff268_inst, reff268_op in H. discriminate H. Qed.

Lemma reff268_not1025 : ~ @Equation1025 Fin4 reff268_inst.
Proof. unfold Equation1025. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff268_inst, reff268_op in H. discriminate H. Qed.

Lemma reff268_not1026 : ~ @Equation1026 Fin4 reff268_inst.
Proof. unfold Equation1026. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff268_inst, reff268_op in H. discriminate H. Qed.

Lemma reff268_not1028 : ~ @Equation1028 Fin4 reff268_inst.
Proof. unfold Equation1028. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff268_inst, reff268_op in H. discriminate H. Qed.

Lemma reff268_not1029 : ~ @Equation1029 Fin4 reff268_inst.
Proof. unfold Equation1029. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff268_inst, reff268_op in H. discriminate H. Qed.

Lemma reff268_not1035 : ~ @Equation1035 Fin4 reff268_inst.
Proof. unfold Equation1035. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff268_inst, reff268_op in H. discriminate H. Qed.

Lemma reff268_not1036 : ~ @Equation1036 Fin4 reff268_inst.
Proof. unfold Equation1036. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff268_inst, reff268_op in H. discriminate H. Qed.

Lemma reff268_not1039 : ~ @Equation1039 Fin4 reff268_inst.
Proof. unfold Equation1039. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff268_inst, reff268_op in H. discriminate H. Qed.

Lemma reff268_not1045 : ~ @Equation1045 Fin4 reff268_inst.
Proof. unfold Equation1045. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff268_inst, reff268_op in H. discriminate H. Qed.

Lemma reff268_not1046 : ~ @Equation1046 Fin4 reff268_inst.
Proof. unfold Equation1046. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff268_inst, reff268_op in H. discriminate H. Qed.

Lemma reff268_not1048 : ~ @Equation1048 Fin4 reff268_inst.
Proof. unfold Equation1048. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff268_inst, reff268_op in H. discriminate H. Qed.

Lemma reff268_not1049 : ~ @Equation1049 Fin4 reff268_inst.
Proof. unfold Equation1049. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff268_inst, reff268_op in H. discriminate H. Qed.

Lemma reff268_not1072 : ~ @Equation1072 Fin4 reff268_inst.
Proof. unfold Equation1072. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff268_inst, reff268_op in H. discriminate H. Qed.

Lemma reff268_not1073 : ~ @Equation1073 Fin4 reff268_inst.
Proof. unfold Equation1073. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff268_inst, reff268_op in H. discriminate H. Qed.

Lemma reff268_not1075 : ~ @Equation1075 Fin4 reff268_inst.
Proof. unfold Equation1075. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff268_inst, reff268_op in H. discriminate H. Qed.

Lemma reff268_not1076 : ~ @Equation1076 Fin4 reff268_inst.
Proof. unfold Equation1076. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff268_inst, reff268_op in H. discriminate H. Qed.

Lemma reff268_not1082 : ~ @Equation1082 Fin4 reff268_inst.
Proof. unfold Equation1082. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff268_inst, reff268_op in H. discriminate H. Qed.

Lemma reff268_not1083 : ~ @Equation1083 Fin4 reff268_inst.
Proof. unfold Equation1083. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff268_inst, reff268_op in H. discriminate H. Qed.

Lemma reff268_not1085 : ~ @Equation1085 Fin4 reff268_inst.
Proof. unfold Equation1085. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff268_inst, reff268_op in H. discriminate H. Qed.

Lemma reff268_not1086 : ~ @Equation1086 Fin4 reff268_inst.
Proof. unfold Equation1086. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff268_inst, reff268_op in H. discriminate H. Qed.

Lemma reff268_not1109 : ~ @Equation1109 Fin4 reff268_inst.
Proof. unfold Equation1109. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff268_inst, reff268_op in H. discriminate H. Qed.

Lemma reff268_not1110 : ~ @Equation1110 Fin4 reff268_inst.
Proof. unfold Equation1110. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff268_inst, reff268_op in H. discriminate H. Qed.

Lemma reff268_not1112 : ~ @Equation1112 Fin4 reff268_inst.
Proof. unfold Equation1112. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff268_inst, reff268_op in H. discriminate H. Qed.

Lemma reff268_not1113 : ~ @Equation1113 Fin4 reff268_inst.
Proof. unfold Equation1113. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff268_inst, reff268_op in H. discriminate H. Qed.

Lemma reff268_not1119 : ~ @Equation1119 Fin4 reff268_inst.
Proof. unfold Equation1119. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff268_inst, reff268_op in H. discriminate H. Qed.

Lemma reff268_not1120 : ~ @Equation1120 Fin4 reff268_inst.
Proof. unfold Equation1120. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff268_inst, reff268_op in H. discriminate H. Qed.

Lemma reff268_not1122 : ~ @Equation1122 Fin4 reff268_inst.
Proof. unfold Equation1122. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff268_inst, reff268_op in H. discriminate H. Qed.

Lemma reff268_not1224 : ~ @Equation1224 Fin4 reff268_inst.
Proof. unfold Equation1224. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff268_inst, reff268_op in H. discriminate H. Qed.

Lemma reff268_not1225 : ~ @Equation1225 Fin4 reff268_inst.
Proof. unfold Equation1225. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff268_inst, reff268_op in H. discriminate H. Qed.

Lemma reff268_not1228 : ~ @Equation1228 Fin4 reff268_inst.
Proof. unfold Equation1228. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff268_inst, reff268_op in H. discriminate H. Qed.

Lemma reff268_not1232 : ~ @Equation1232 Fin4 reff268_inst.
Proof. unfold Equation1232. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff268_inst, reff268_op in H. discriminate H. Qed.

Lemma reff268_not1238 : ~ @Equation1238 Fin4 reff268_inst.
Proof. unfold Equation1238. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff268_inst, reff268_op in H. discriminate H. Qed.

Lemma reff268_not1239 : ~ @Equation1239 Fin4 reff268_inst.
Proof. unfold Equation1239. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff268_inst, reff268_op in H. discriminate H. Qed.

Lemma reff268_not1241 : ~ @Equation1241 Fin4 reff268_inst.
Proof. unfold Equation1241. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff268_inst, reff268_op in H. discriminate H. Qed.

Lemma reff268_not1242 : ~ @Equation1242 Fin4 reff268_inst.
Proof. unfold Equation1242. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff268_inst, reff268_op in H. discriminate H. Qed.

Lemma reff268_not1248 : ~ @Equation1248 Fin4 reff268_inst.
Proof. unfold Equation1248. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff268_inst, reff268_op in H. discriminate H. Qed.

Lemma reff268_not1249 : ~ @Equation1249 Fin4 reff268_inst.
Proof. unfold Equation1249. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff268_inst, reff268_op in H. discriminate H. Qed.

Lemma reff268_not1251 : ~ @Equation1251 Fin4 reff268_inst.
Proof. unfold Equation1251. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff268_inst, reff268_op in H. discriminate H. Qed.

Lemma reff268_not1252 : ~ @Equation1252 Fin4 reff268_inst.
Proof. unfold Equation1252. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff268_inst, reff268_op in H. discriminate H. Qed.

Lemma reff268_not1275 : ~ @Equation1275 Fin4 reff268_inst.
Proof. unfold Equation1275. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff268_inst, reff268_op in H. discriminate H. Qed.

Lemma reff268_not1276 : ~ @Equation1276 Fin4 reff268_inst.
Proof. unfold Equation1276. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff268_inst, reff268_op in H. discriminate H. Qed.

Lemma reff268_not1278 : ~ @Equation1278 Fin4 reff268_inst.
Proof. unfold Equation1278. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff268_inst, reff268_op in H. discriminate H. Qed.

Lemma reff268_not1279 : ~ @Equation1279 Fin4 reff268_inst.
Proof. unfold Equation1279. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff268_inst, reff268_op in H. discriminate H. Qed.

Lemma reff268_not1285 : ~ @Equation1285 Fin4 reff268_inst.
Proof. unfold Equation1285. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff268_inst, reff268_op in H. discriminate H. Qed.

Lemma reff268_not1286 : ~ @Equation1286 Fin4 reff268_inst.
Proof. unfold Equation1286. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff268_inst, reff268_op in H. discriminate H. Qed.

Lemma reff268_not1288 : ~ @Equation1288 Fin4 reff268_inst.
Proof. unfold Equation1288. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff268_inst, reff268_op in H. discriminate H. Qed.

Lemma reff268_not1289 : ~ @Equation1289 Fin4 reff268_inst.
Proof. unfold Equation1289. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff268_inst, reff268_op in H. discriminate H. Qed.

Lemma reff268_not1312 : ~ @Equation1312 Fin4 reff268_inst.
Proof. unfold Equation1312. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff268_inst, reff268_op in H. discriminate H. Qed.

Lemma reff268_not1313 : ~ @Equation1313 Fin4 reff268_inst.
Proof. unfold Equation1313. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff268_inst, reff268_op in H. discriminate H. Qed.

Lemma reff268_not1315 : ~ @Equation1315 Fin4 reff268_inst.
Proof. unfold Equation1315. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff268_inst, reff268_op in H. discriminate H. Qed.

Lemma reff268_not1316 : ~ @Equation1316 Fin4 reff268_inst.
Proof. unfold Equation1316. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff268_inst, reff268_op in H. discriminate H. Qed.

Lemma reff268_not1322 : ~ @Equation1322 Fin4 reff268_inst.
Proof. unfold Equation1322. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff268_inst, reff268_op in H. discriminate H. Qed.

Lemma reff268_not1323 : ~ @Equation1323 Fin4 reff268_inst.
Proof. unfold Equation1323. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff268_inst, reff268_op in H. discriminate H. Qed.

Lemma reff268_not1325 : ~ @Equation1325 Fin4 reff268_inst.
Proof. unfold Equation1325. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff268_inst, reff268_op in H. discriminate H. Qed.

Lemma reff268_not1427 : ~ @Equation1427 Fin4 reff268_inst.
Proof. unfold Equation1427. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff268_inst, reff268_op in H. discriminate H. Qed.

Lemma reff268_not1428 : ~ @Equation1428 Fin4 reff268_inst.
Proof. unfold Equation1428. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff268_inst, reff268_op in H. discriminate H. Qed.

Lemma reff268_not1429 : ~ @Equation1429 Fin4 reff268_inst.
Proof. unfold Equation1429. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff268_inst, reff268_op in H. discriminate H. Qed.

Lemma reff268_not1431 : ~ @Equation1431 Fin4 reff268_inst.
Proof. unfold Equation1431. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff268_inst, reff268_op in H. discriminate H. Qed.

Lemma reff268_not1432 : ~ @Equation1432 Fin4 reff268_inst.
Proof. unfold Equation1432. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff268_inst, reff268_op in H. discriminate H. Qed.

Lemma reff268_not1434 : ~ @Equation1434 Fin4 reff268_inst.
Proof. unfold Equation1434. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff268_inst, reff268_op in H. discriminate H. Qed.

Lemma reff268_not1435 : ~ @Equation1435 Fin4 reff268_inst.
Proof. unfold Equation1435. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff268_inst, reff268_op in H. discriminate H. Qed.

Lemma reff268_not1441 : ~ @Equation1441 Fin4 reff268_inst.
Proof. unfold Equation1441. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff268_inst, reff268_op in H. discriminate H. Qed.

Lemma reff268_not1444 : ~ @Equation1444 Fin4 reff268_inst.
Proof. unfold Equation1444. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff268_inst, reff268_op in H. discriminate H. Qed.

Lemma reff268_not1445 : ~ @Equation1445 Fin4 reff268_inst.
Proof. unfold Equation1445. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff268_inst, reff268_op in H. discriminate H. Qed.

Lemma reff268_not1451 : ~ @Equation1451 Fin4 reff268_inst.
Proof. unfold Equation1451. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff268_inst, reff268_op in H. discriminate H. Qed.

Lemma reff268_not1452 : ~ @Equation1452 Fin4 reff268_inst.
Proof. unfold Equation1452. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff268_inst, reff268_op in H. discriminate H. Qed.

Lemma reff268_not1454 : ~ @Equation1454 Fin4 reff268_inst.
Proof. unfold Equation1454. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff268_inst, reff268_op in H. discriminate H. Qed.

Lemma reff268_not1478 : ~ @Equation1478 Fin4 reff268_inst.
Proof. unfold Equation1478. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff268_inst, reff268_op in H. discriminate H. Qed.

Lemma reff268_not1479 : ~ @Equation1479 Fin4 reff268_inst.
Proof. unfold Equation1479. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff268_inst, reff268_op in H. discriminate H. Qed.

Lemma reff268_not1481 : ~ @Equation1481 Fin4 reff268_inst.
Proof. unfold Equation1481. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff268_inst, reff268_op in H. discriminate H. Qed.

Lemma reff268_not1482 : ~ @Equation1482 Fin4 reff268_inst.
Proof. unfold Equation1482. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff268_inst, reff268_op in H. discriminate H. Qed.

Lemma reff268_not1488 : ~ @Equation1488 Fin4 reff268_inst.
Proof. unfold Equation1488. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff268_inst, reff268_op in H. discriminate H. Qed.

Lemma reff268_not1489 : ~ @Equation1489 Fin4 reff268_inst.
Proof. unfold Equation1489. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff268_inst, reff268_op in H. discriminate H. Qed.

Lemma reff268_not1491 : ~ @Equation1491 Fin4 reff268_inst.
Proof. unfold Equation1491. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff268_inst, reff268_op in H. discriminate H. Qed.

Lemma reff268_not1492 : ~ @Equation1492 Fin4 reff268_inst.
Proof. unfold Equation1492. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff268_inst, reff268_op in H. discriminate H. Qed.

Lemma reff268_not1515 : ~ @Equation1515 Fin4 reff268_inst.
Proof. unfold Equation1515. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff268_inst, reff268_op in H. discriminate H. Qed.

Lemma reff268_not1516 : ~ @Equation1516 Fin4 reff268_inst.
Proof. unfold Equation1516. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff268_inst, reff268_op in H. discriminate H. Qed.

Lemma reff268_not1518 : ~ @Equation1518 Fin4 reff268_inst.
Proof. unfold Equation1518. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff268_inst, reff268_op in H. discriminate H. Qed.

Lemma reff268_not1519 : ~ @Equation1519 Fin4 reff268_inst.
Proof. unfold Equation1519. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff268_inst, reff268_op in H. discriminate H. Qed.

Lemma reff268_not1525 : ~ @Equation1525 Fin4 reff268_inst.
Proof. unfold Equation1525. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff268_inst, reff268_op in H. discriminate H. Qed.

Lemma reff268_not1526 : ~ @Equation1526 Fin4 reff268_inst.
Proof. unfold Equation1526. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff268_inst, reff268_op in H. discriminate H. Qed.

Lemma reff268_not1528 : ~ @Equation1528 Fin4 reff268_inst.
Proof. unfold Equation1528. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff268_inst, reff268_op in H. discriminate H. Qed.

Lemma reff268_not1630 : ~ @Equation1630 Fin4 reff268_inst.
Proof. unfold Equation1630. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff268_inst, reff268_op in H. discriminate H. Qed.

Lemma reff268_not1631 : ~ @Equation1631 Fin4 reff268_inst.
Proof. unfold Equation1631. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff268_inst, reff268_op in H. discriminate H. Qed.

Lemma reff268_not1634 : ~ @Equation1634 Fin4 reff268_inst.
Proof. unfold Equation1634. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff268_inst, reff268_op in H. discriminate H. Qed.

Lemma reff268_not1635 : ~ @Equation1635 Fin4 reff268_inst.
Proof. unfold Equation1635. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff268_inst, reff268_op in H. discriminate H. Qed.

Lemma reff268_not1637 : ~ @Equation1637 Fin4 reff268_inst.
Proof. unfold Equation1637. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff268_inst, reff268_op in H. discriminate H. Qed.

Lemma reff268_not1638 : ~ @Equation1638 Fin4 reff268_inst.
Proof. unfold Equation1638. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff268_inst, reff268_op in H. discriminate H. Qed.

Lemma reff268_not1644 : ~ @Equation1644 Fin4 reff268_inst.
Proof. unfold Equation1644. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff268_inst, reff268_op in H. discriminate H. Qed.

Lemma reff268_not1648 : ~ @Equation1648 Fin4 reff268_inst.
Proof. unfold Equation1648. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff268_inst, reff268_op in H. discriminate H. Qed.

Lemma reff268_not1655 : ~ @Equation1655 Fin4 reff268_inst.
Proof. unfold Equation1655. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff268_inst, reff268_op in H. discriminate H. Qed.

Lemma reff268_not1657 : ~ @Equation1657 Fin4 reff268_inst.
Proof. unfold Equation1657. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff268_inst, reff268_op in H. discriminate H. Qed.

Lemma reff268_not1681 : ~ @Equation1681 Fin4 reff268_inst.
Proof. unfold Equation1681. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff268_inst, reff268_op in H. discriminate H. Qed.

Lemma reff268_not1682 : ~ @Equation1682 Fin4 reff268_inst.
Proof. unfold Equation1682. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff268_inst, reff268_op in H. discriminate H. Qed.

Lemma reff268_not1684 : ~ @Equation1684 Fin4 reff268_inst.
Proof. unfold Equation1684. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff268_inst, reff268_op in H. discriminate H. Qed.

Lemma reff268_not1685 : ~ @Equation1685 Fin4 reff268_inst.
Proof. unfold Equation1685. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff268_inst, reff268_op in H. discriminate H. Qed.

Lemma reff268_not1691 : ~ @Equation1691 Fin4 reff268_inst.
Proof. unfold Equation1691. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff268_inst, reff268_op in H. discriminate H. Qed.

Lemma reff268_not1692 : ~ @Equation1692 Fin4 reff268_inst.
Proof. unfold Equation1692. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff268_inst, reff268_op in H. discriminate H. Qed.

Lemma reff268_not1694 : ~ @Equation1694 Fin4 reff268_inst.
Proof. unfold Equation1694. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff268_inst, reff268_op in H. discriminate H. Qed.

Lemma reff268_not1695 : ~ @Equation1695 Fin4 reff268_inst.
Proof. unfold Equation1695. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff268_inst, reff268_op in H. discriminate H. Qed.

Lemma reff268_not1718 : ~ @Equation1718 Fin4 reff268_inst.
Proof. unfold Equation1718. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff268_inst, reff268_op in H. discriminate H. Qed.

Lemma reff268_not1719 : ~ @Equation1719 Fin4 reff268_inst.
Proof. unfold Equation1719. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff268_inst, reff268_op in H. discriminate H. Qed.

Lemma reff268_not1721 : ~ @Equation1721 Fin4 reff268_inst.
Proof. unfold Equation1721. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff268_inst, reff268_op in H. discriminate H. Qed.

Lemma reff268_not1722 : ~ @Equation1722 Fin4 reff268_inst.
Proof. unfold Equation1722. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff268_inst, reff268_op in H. discriminate H. Qed.

Lemma reff268_not1728 : ~ @Equation1728 Fin4 reff268_inst.
Proof. unfold Equation1728. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff268_inst, reff268_op in H. discriminate H. Qed.

Lemma reff268_not1729 : ~ @Equation1729 Fin4 reff268_inst.
Proof. unfold Equation1729. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff268_inst, reff268_op in H. discriminate H. Qed.

Lemma reff268_not1731 : ~ @Equation1731 Fin4 reff268_inst.
Proof. unfold Equation1731. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff268_inst, reff268_op in H. discriminate H. Qed.

Lemma reff268_not1833 : ~ @Equation1833 Fin4 reff268_inst.
Proof. unfold Equation1833. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff268_inst, reff268_op in H. discriminate H. Qed.

Lemma reff268_not1834 : ~ @Equation1834 Fin4 reff268_inst.
Proof. unfold Equation1834. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff268_inst, reff268_op in H. discriminate H. Qed.

Lemma reff268_not1835 : ~ @Equation1835 Fin4 reff268_inst.
Proof. unfold Equation1835. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff268_inst, reff268_op in H. discriminate H. Qed.

Lemma reff268_not1837 : ~ @Equation1837 Fin4 reff268_inst.
Proof. unfold Equation1837. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff268_inst, reff268_op in H. discriminate H. Qed.

Lemma reff268_not1840 : ~ @Equation1840 Fin4 reff268_inst.
Proof. unfold Equation1840. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff268_inst, reff268_op in H. discriminate H. Qed.

Lemma reff268_not1841 : ~ @Equation1841 Fin4 reff268_inst.
Proof. unfold Equation1841. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff268_inst, reff268_op in H. discriminate H. Qed.

Lemma reff268_not1847 : ~ @Equation1847 Fin4 reff268_inst.
Proof. unfold Equation1847. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff268_inst, reff268_op in H. discriminate H. Qed.

Lemma reff268_not1848 : ~ @Equation1848 Fin4 reff268_inst.
Proof. unfold Equation1848. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff268_inst, reff268_op in H. discriminate H. Qed.

Lemma reff268_not1851 : ~ @Equation1851 Fin4 reff268_inst.
Proof. unfold Equation1851. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff268_inst, reff268_op in H. discriminate H. Qed.

Lemma reff268_not1857 : ~ @Equation1857 Fin4 reff268_inst.
Proof. unfold Equation1857. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff268_inst, reff268_op in H. discriminate H. Qed.

Lemma reff268_not1858 : ~ @Equation1858 Fin4 reff268_inst.
Proof. unfold Equation1858. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff268_inst, reff268_op in H. discriminate H. Qed.

Lemma reff268_not1860 : ~ @Equation1860 Fin4 reff268_inst.
Proof. unfold Equation1860. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff268_inst, reff268_op in H. discriminate H. Qed.

Lemma reff268_not1884 : ~ @Equation1884 Fin4 reff268_inst.
Proof. unfold Equation1884. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff268_inst, reff268_op in H. discriminate H. Qed.

Lemma reff268_not1885 : ~ @Equation1885 Fin4 reff268_inst.
Proof. unfold Equation1885. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff268_inst, reff268_op in H. discriminate H. Qed.

Lemma reff268_not1887 : ~ @Equation1887 Fin4 reff268_inst.
Proof. unfold Equation1887. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff268_inst, reff268_op in H. discriminate H. Qed.

Lemma reff268_not1888 : ~ @Equation1888 Fin4 reff268_inst.
Proof. unfold Equation1888. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff268_inst, reff268_op in H. discriminate H. Qed.

Lemma reff268_not1894 : ~ @Equation1894 Fin4 reff268_inst.
Proof. unfold Equation1894. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff268_inst, reff268_op in H. discriminate H. Qed.

Lemma reff268_not1895 : ~ @Equation1895 Fin4 reff268_inst.
Proof. unfold Equation1895. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff268_inst, reff268_op in H. discriminate H. Qed.

Lemma reff268_not1897 : ~ @Equation1897 Fin4 reff268_inst.
Proof. unfold Equation1897. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff268_inst, reff268_op in H. discriminate H. Qed.

Lemma reff268_not1898 : ~ @Equation1898 Fin4 reff268_inst.
Proof. unfold Equation1898. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff268_inst, reff268_op in H. discriminate H. Qed.

Lemma reff268_not1921 : ~ @Equation1921 Fin4 reff268_inst.
Proof. unfold Equation1921. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff268_inst, reff268_op in H. discriminate H. Qed.

Lemma reff268_not1922 : ~ @Equation1922 Fin4 reff268_inst.
Proof. unfold Equation1922. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff268_inst, reff268_op in H. discriminate H. Qed.

Lemma reff268_not1924 : ~ @Equation1924 Fin4 reff268_inst.
Proof. unfold Equation1924. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff268_inst, reff268_op in H. discriminate H. Qed.

Lemma reff268_not1925 : ~ @Equation1925 Fin4 reff268_inst.
Proof. unfold Equation1925. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff268_inst, reff268_op in H. discriminate H. Qed.

Lemma reff268_not1931 : ~ @Equation1931 Fin4 reff268_inst.
Proof. unfold Equation1931. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff268_inst, reff268_op in H. discriminate H. Qed.

Lemma reff268_not1932 : ~ @Equation1932 Fin4 reff268_inst.
Proof. unfold Equation1932. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff268_inst, reff268_op in H. discriminate H. Qed.

Lemma reff268_not1934 : ~ @Equation1934 Fin4 reff268_inst.
Proof. unfold Equation1934. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff268_inst, reff268_op in H. discriminate H. Qed.

Lemma reff268_not2036 : ~ @Equation2036 Fin4 reff268_inst.
Proof. unfold Equation2036. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff268_inst, reff268_op in H. discriminate H. Qed.

Lemma reff268_not2037 : ~ @Equation2037 Fin4 reff268_inst.
Proof. unfold Equation2037. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff268_inst, reff268_op in H. discriminate H. Qed.

Lemma reff268_not2038 : ~ @Equation2038 Fin4 reff268_inst.
Proof. unfold Equation2038. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff268_inst, reff268_op in H. discriminate H. Qed.

Lemma reff268_not2040 : ~ @Equation2040 Fin4 reff268_inst.
Proof. unfold Equation2040. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff268_inst, reff268_op in H. discriminate H. Qed.

Lemma reff268_not2043 : ~ @Equation2043 Fin4 reff268_inst.
Proof. unfold Equation2043. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff268_inst, reff268_op in H. discriminate H. Qed.

Lemma reff268_not2044 : ~ @Equation2044 Fin4 reff268_inst.
Proof. unfold Equation2044. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff268_inst, reff268_op in H. discriminate H. Qed.

Lemma reff268_not2050 : ~ @Equation2050 Fin4 reff268_inst.
Proof. unfold Equation2050. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff268_inst, reff268_op in H. discriminate H. Qed.

Lemma reff268_not2053 : ~ @Equation2053 Fin4 reff268_inst.
Proof. unfold Equation2053. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff268_inst, reff268_op in H. discriminate H. Qed.

Lemma reff268_not2054 : ~ @Equation2054 Fin4 reff268_inst.
Proof. unfold Equation2054. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff268_inst, reff268_op in H. discriminate H. Qed.

Lemma reff268_not2061 : ~ @Equation2061 Fin4 reff268_inst.
Proof. unfold Equation2061. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff268_inst, reff268_op in H. discriminate H. Qed.

Lemma reff268_not2063 : ~ @Equation2063 Fin4 reff268_inst.
Proof. unfold Equation2063. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff268_inst, reff268_op in H. discriminate H. Qed.

Lemma reff268_not2064 : ~ @Equation2064 Fin4 reff268_inst.
Proof. unfold Equation2064. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff268_inst, reff268_op in H. discriminate H. Qed.

Lemma reff268_not2087 : ~ @Equation2087 Fin4 reff268_inst.
Proof. unfold Equation2087. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff268_inst, reff268_op in H. discriminate H. Qed.

Lemma reff268_not2088 : ~ @Equation2088 Fin4 reff268_inst.
Proof. unfold Equation2088. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff268_inst, reff268_op in H. discriminate H. Qed.

Lemma reff268_not2090 : ~ @Equation2090 Fin4 reff268_inst.
Proof. unfold Equation2090. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff268_inst, reff268_op in H. discriminate H. Qed.

Lemma reff268_not2091 : ~ @Equation2091 Fin4 reff268_inst.
Proof. unfold Equation2091. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff268_inst, reff268_op in H. discriminate H. Qed.

Lemma reff268_not2097 : ~ @Equation2097 Fin4 reff268_inst.
Proof. unfold Equation2097. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff268_inst, reff268_op in H. discriminate H. Qed.

Lemma reff268_not2098 : ~ @Equation2098 Fin4 reff268_inst.
Proof. unfold Equation2098. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff268_inst, reff268_op in H. discriminate H. Qed.

Lemma reff268_not2100 : ~ @Equation2100 Fin4 reff268_inst.
Proof. unfold Equation2100. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff268_inst, reff268_op in H. discriminate H. Qed.

Lemma reff268_not2101 : ~ @Equation2101 Fin4 reff268_inst.
Proof. unfold Equation2101. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff268_inst, reff268_op in H. discriminate H. Qed.

Lemma reff268_not2124 : ~ @Equation2124 Fin4 reff268_inst.
Proof. unfold Equation2124. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff268_inst, reff268_op in H. discriminate H. Qed.

Lemma reff268_not2125 : ~ @Equation2125 Fin4 reff268_inst.
Proof. unfold Equation2125. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff268_inst, reff268_op in H. discriminate H. Qed.

Lemma reff268_not2127 : ~ @Equation2127 Fin4 reff268_inst.
Proof. unfold Equation2127. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff268_inst, reff268_op in H. discriminate H. Qed.

Lemma reff268_not2128 : ~ @Equation2128 Fin4 reff268_inst.
Proof. unfold Equation2128. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff268_inst, reff268_op in H. discriminate H. Qed.

Lemma reff268_not2134 : ~ @Equation2134 Fin4 reff268_inst.
Proof. unfold Equation2134. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff268_inst, reff268_op in H. discriminate H. Qed.

Lemma reff268_not2135 : ~ @Equation2135 Fin4 reff268_inst.
Proof. unfold Equation2135. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff268_inst, reff268_op in H. discriminate H. Qed.

Lemma reff268_not2137 : ~ @Equation2137 Fin4 reff268_inst.
Proof. unfold Equation2137. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff268_inst, reff268_op in H. discriminate H. Qed.

Lemma reff268_not2239 : ~ @Equation2239 Fin4 reff268_inst.
Proof. unfold Equation2239. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff268_inst, reff268_op in H. discriminate H. Qed.

Lemma reff268_not2240 : ~ @Equation2240 Fin4 reff268_inst.
Proof. unfold Equation2240. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff268_inst, reff268_op in H. discriminate H. Qed.

Lemma reff268_not2243 : ~ @Equation2243 Fin4 reff268_inst.
Proof. unfold Equation2243. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff268_inst, reff268_op in H. discriminate H. Qed.

Lemma reff268_not2244 : ~ @Equation2244 Fin4 reff268_inst.
Proof. unfold Equation2244. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff268_inst, reff268_op in H. discriminate H. Qed.

Lemma reff268_not2246 : ~ @Equation2246 Fin4 reff268_inst.
Proof. unfold Equation2246. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff268_inst, reff268_op in H. discriminate H. Qed.

Lemma reff268_not2247 : ~ @Equation2247 Fin4 reff268_inst.
Proof. unfold Equation2247. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff268_inst, reff268_op in H. discriminate H. Qed.

Lemma reff268_not2253 : ~ @Equation2253 Fin4 reff268_inst.
Proof. unfold Equation2253. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff268_inst, reff268_op in H. discriminate H. Qed.

Lemma reff268_not2254 : ~ @Equation2254 Fin4 reff268_inst.
Proof. unfold Equation2254. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff268_inst, reff268_op in H. discriminate H. Qed.

Lemma reff268_not2256 : ~ @Equation2256 Fin4 reff268_inst.
Proof. unfold Equation2256. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff268_inst, reff268_op in H. discriminate H. Qed.

Lemma reff268_not2257 : ~ @Equation2257 Fin4 reff268_inst.
Proof. unfold Equation2257. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff268_inst, reff268_op in H. discriminate H. Qed.

Lemma reff268_not2263 : ~ @Equation2263 Fin4 reff268_inst.
Proof. unfold Equation2263. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff268_inst, reff268_op in H. discriminate H. Qed.

Lemma reff268_not2264 : ~ @Equation2264 Fin4 reff268_inst.
Proof. unfold Equation2264. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff268_inst, reff268_op in H. discriminate H. Qed.

Lemma reff268_not2266 : ~ @Equation2266 Fin4 reff268_inst.
Proof. unfold Equation2266. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff268_inst, reff268_op in H. discriminate H. Qed.

Lemma reff268_not2290 : ~ @Equation2290 Fin4 reff268_inst.
Proof. unfold Equation2290. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff268_inst, reff268_op in H. discriminate H. Qed.

Lemma reff268_not2291 : ~ @Equation2291 Fin4 reff268_inst.
Proof. unfold Equation2291. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff268_inst, reff268_op in H. discriminate H. Qed.

Lemma reff268_not2293 : ~ @Equation2293 Fin4 reff268_inst.
Proof. unfold Equation2293. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff268_inst, reff268_op in H. discriminate H. Qed.

Lemma reff268_not2294 : ~ @Equation2294 Fin4 reff268_inst.
Proof. unfold Equation2294. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff268_inst, reff268_op in H. discriminate H. Qed.

Lemma reff268_not2300 : ~ @Equation2300 Fin4 reff268_inst.
Proof. unfold Equation2300. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff268_inst, reff268_op in H. discriminate H. Qed.

Lemma reff268_not2301 : ~ @Equation2301 Fin4 reff268_inst.
Proof. unfold Equation2301. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff268_inst, reff268_op in H. discriminate H. Qed.

Lemma reff268_not2303 : ~ @Equation2303 Fin4 reff268_inst.
Proof. unfold Equation2303. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff268_inst, reff268_op in H. discriminate H. Qed.

Lemma reff268_not2304 : ~ @Equation2304 Fin4 reff268_inst.
Proof. unfold Equation2304. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff268_inst, reff268_op in H. discriminate H. Qed.

Lemma reff268_not2327 : ~ @Equation2327 Fin4 reff268_inst.
Proof. unfold Equation2327. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff268_inst, reff268_op in H. discriminate H. Qed.

Lemma reff268_not2328 : ~ @Equation2328 Fin4 reff268_inst.
Proof. unfold Equation2328. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff268_inst, reff268_op in H. discriminate H. Qed.

Lemma reff268_not2330 : ~ @Equation2330 Fin4 reff268_inst.
Proof. unfold Equation2330. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff268_inst, reff268_op in H. discriminate H. Qed.

Lemma reff268_not2331 : ~ @Equation2331 Fin4 reff268_inst.
Proof. unfold Equation2331. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff268_inst, reff268_op in H. discriminate H. Qed.

Lemma reff268_not2337 : ~ @Equation2337 Fin4 reff268_inst.
Proof. unfold Equation2337. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff268_inst, reff268_op in H. discriminate H. Qed.

Lemma reff268_not2338 : ~ @Equation2338 Fin4 reff268_inst.
Proof. unfold Equation2338. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff268_inst, reff268_op in H. discriminate H. Qed.

Lemma reff268_not2340 : ~ @Equation2340 Fin4 reff268_inst.
Proof. unfold Equation2340. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff268_inst, reff268_op in H. discriminate H. Qed.

Lemma reff268_not2442 : ~ @Equation2442 Fin4 reff268_inst.
Proof. unfold Equation2442. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff268_inst, reff268_op in H. discriminate H. Qed.

Lemma reff268_not2443 : ~ @Equation2443 Fin4 reff268_inst.
Proof. unfold Equation2443. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff268_inst, reff268_op in H. discriminate H. Qed.

Lemma reff268_not2446 : ~ @Equation2446 Fin4 reff268_inst.
Proof. unfold Equation2446. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff268_inst, reff268_op in H. discriminate H. Qed.

Lemma reff268_not2450 : ~ @Equation2450 Fin4 reff268_inst.
Proof. unfold Equation2450. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff268_inst, reff268_op in H. discriminate H. Qed.

Lemma reff268_not2456 : ~ @Equation2456 Fin4 reff268_inst.
Proof. unfold Equation2456. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff268_inst, reff268_op in H. discriminate H. Qed.

Lemma reff268_not2459 : ~ @Equation2459 Fin4 reff268_inst.
Proof. unfold Equation2459. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff268_inst, reff268_op in H. discriminate H. Qed.

Lemma reff268_not2460 : ~ @Equation2460 Fin4 reff268_inst.
Proof. unfold Equation2460. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff268_inst, reff268_op in H. discriminate H. Qed.

Lemma reff268_not2466 : ~ @Equation2466 Fin4 reff268_inst.
Proof. unfold Equation2466. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff268_inst, reff268_op in H. discriminate H. Qed.

Lemma reff268_not2467 : ~ @Equation2467 Fin4 reff268_inst.
Proof. unfold Equation2467. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff268_inst, reff268_op in H. discriminate H. Qed.

Lemma reff268_not2469 : ~ @Equation2469 Fin4 reff268_inst.
Proof. unfold Equation2469. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff268_inst, reff268_op in H. discriminate H. Qed.

Lemma reff268_not2493 : ~ @Equation2493 Fin4 reff268_inst.
Proof. unfold Equation2493. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff268_inst, reff268_op in H. discriminate H. Qed.

Lemma reff268_not2494 : ~ @Equation2494 Fin4 reff268_inst.
Proof. unfold Equation2494. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff268_inst, reff268_op in H. discriminate H. Qed.

Lemma reff268_not2496 : ~ @Equation2496 Fin4 reff268_inst.
Proof. unfold Equation2496. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff268_inst, reff268_op in H. discriminate H. Qed.

Lemma reff268_not2497 : ~ @Equation2497 Fin4 reff268_inst.
Proof. unfold Equation2497. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff268_inst, reff268_op in H. discriminate H. Qed.

Lemma reff268_not2503 : ~ @Equation2503 Fin4 reff268_inst.
Proof. unfold Equation2503. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff268_inst, reff268_op in H. discriminate H. Qed.

Lemma reff268_not2504 : ~ @Equation2504 Fin4 reff268_inst.
Proof. unfold Equation2504. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff268_inst, reff268_op in H. discriminate H. Qed.

Lemma reff268_not2506 : ~ @Equation2506 Fin4 reff268_inst.
Proof. unfold Equation2506. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff268_inst, reff268_op in H. discriminate H. Qed.

Lemma reff268_not2507 : ~ @Equation2507 Fin4 reff268_inst.
Proof. unfold Equation2507. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff268_inst, reff268_op in H. discriminate H. Qed.

Lemma reff268_not2530 : ~ @Equation2530 Fin4 reff268_inst.
Proof. unfold Equation2530. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff268_inst, reff268_op in H. discriminate H. Qed.

Lemma reff268_not2531 : ~ @Equation2531 Fin4 reff268_inst.
Proof. unfold Equation2531. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff268_inst, reff268_op in H. discriminate H. Qed.

Lemma reff268_not2533 : ~ @Equation2533 Fin4 reff268_inst.
Proof. unfold Equation2533. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff268_inst, reff268_op in H. discriminate H. Qed.

Lemma reff268_not2534 : ~ @Equation2534 Fin4 reff268_inst.
Proof. unfold Equation2534. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff268_inst, reff268_op in H. discriminate H. Qed.

Lemma reff268_not2540 : ~ @Equation2540 Fin4 reff268_inst.
Proof. unfold Equation2540. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff268_inst, reff268_op in H. discriminate H. Qed.

Lemma reff268_not2541 : ~ @Equation2541 Fin4 reff268_inst.
Proof. unfold Equation2541. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff268_inst, reff268_op in H. discriminate H. Qed.

Lemma reff268_not2543 : ~ @Equation2543 Fin4 reff268_inst.
Proof. unfold Equation2543. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff268_inst, reff268_op in H. discriminate H. Qed.

Lemma reff268_not2645 : ~ @Equation2645 Fin4 reff268_inst.
Proof. unfold Equation2645. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff268_inst, reff268_op in H. discriminate H. Qed.

Lemma reff268_not2646 : ~ @Equation2646 Fin4 reff268_inst.
Proof. unfold Equation2646. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff268_inst, reff268_op in H. discriminate H. Qed.

Lemma reff268_not2649 : ~ @Equation2649 Fin4 reff268_inst.
Proof. unfold Equation2649. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff268_inst, reff268_op in H. discriminate H. Qed.

Lemma reff268_not2650 : ~ @Equation2650 Fin4 reff268_inst.
Proof. unfold Equation2650. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff268_inst, reff268_op in H. discriminate H. Qed.

Lemma reff268_not2652 : ~ @Equation2652 Fin4 reff268_inst.
Proof. unfold Equation2652. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff268_inst, reff268_op in H. discriminate H. Qed.

Lemma reff268_not2653 : ~ @Equation2653 Fin4 reff268_inst.
Proof. unfold Equation2653. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff268_inst, reff268_op in H. discriminate H. Qed.

Lemma reff268_not2659 : ~ @Equation2659 Fin4 reff268_inst.
Proof. unfold Equation2659. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff268_inst, reff268_op in H. discriminate H. Qed.

Lemma reff268_not2663 : ~ @Equation2663 Fin4 reff268_inst.
Proof. unfold Equation2663. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff268_inst, reff268_op in H. discriminate H. Qed.

Lemma reff268_not2669 : ~ @Equation2669 Fin4 reff268_inst.
Proof. unfold Equation2669. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff268_inst, reff268_op in H. discriminate H. Qed.

Lemma reff268_not2670 : ~ @Equation2670 Fin4 reff268_inst.
Proof. unfold Equation2670. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff268_inst, reff268_op in H. discriminate H. Qed.

Lemma reff268_not2672 : ~ @Equation2672 Fin4 reff268_inst.
Proof. unfold Equation2672. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff268_inst, reff268_op in H. discriminate H. Qed.

Lemma reff268_not2673 : ~ @Equation2673 Fin4 reff268_inst.
Proof. unfold Equation2673. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff268_inst, reff268_op in H. discriminate H. Qed.

Lemma reff268_not2696 : ~ @Equation2696 Fin4 reff268_inst.
Proof. unfold Equation2696. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff268_inst, reff268_op in H. discriminate H. Qed.

Lemma reff268_not2697 : ~ @Equation2697 Fin4 reff268_inst.
Proof. unfold Equation2697. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff268_inst, reff268_op in H. discriminate H. Qed.

Lemma reff268_not2699 : ~ @Equation2699 Fin4 reff268_inst.
Proof. unfold Equation2699. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff268_inst, reff268_op in H. discriminate H. Qed.

Lemma reff268_not2700 : ~ @Equation2700 Fin4 reff268_inst.
Proof. unfold Equation2700. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff268_inst, reff268_op in H. discriminate H. Qed.

Lemma reff268_not2706 : ~ @Equation2706 Fin4 reff268_inst.
Proof. unfold Equation2706. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff268_inst, reff268_op in H. discriminate H. Qed.

Lemma reff268_not2707 : ~ @Equation2707 Fin4 reff268_inst.
Proof. unfold Equation2707. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff268_inst, reff268_op in H. discriminate H. Qed.

Lemma reff268_not2709 : ~ @Equation2709 Fin4 reff268_inst.
Proof. unfold Equation2709. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff268_inst, reff268_op in H. discriminate H. Qed.

Lemma reff268_not2710 : ~ @Equation2710 Fin4 reff268_inst.
Proof. unfold Equation2710. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff268_inst, reff268_op in H. discriminate H. Qed.

Lemma reff268_not2733 : ~ @Equation2733 Fin4 reff268_inst.
Proof. unfold Equation2733. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff268_inst, reff268_op in H. discriminate H. Qed.

Lemma reff268_not2734 : ~ @Equation2734 Fin4 reff268_inst.
Proof. unfold Equation2734. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff268_inst, reff268_op in H. discriminate H. Qed.

Lemma reff268_not2736 : ~ @Equation2736 Fin4 reff268_inst.
Proof. unfold Equation2736. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff268_inst, reff268_op in H. discriminate H. Qed.

Lemma reff268_not2737 : ~ @Equation2737 Fin4 reff268_inst.
Proof. unfold Equation2737. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff268_inst, reff268_op in H. discriminate H. Qed.

Lemma reff268_not2743 : ~ @Equation2743 Fin4 reff268_inst.
Proof. unfold Equation2743. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff268_inst, reff268_op in H. discriminate H. Qed.

Lemma reff268_not2744 : ~ @Equation2744 Fin4 reff268_inst.
Proof. unfold Equation2744. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff268_inst, reff268_op in H. discriminate H. Qed.

Lemma reff268_not2746 : ~ @Equation2746 Fin4 reff268_inst.
Proof. unfold Equation2746. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff268_inst, reff268_op in H. discriminate H. Qed.

Lemma reff268_not2848 : ~ @Equation2848 Fin4 reff268_inst.
Proof. unfold Equation2848. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff268_inst, reff268_op in H. discriminate H. Qed.

Lemma reff268_not2849 : ~ @Equation2849 Fin4 reff268_inst.
Proof. unfold Equation2849. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff268_inst, reff268_op in H. discriminate H. Qed.

Lemma reff268_not2852 : ~ @Equation2852 Fin4 reff268_inst.
Proof. unfold Equation2852. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff268_inst, reff268_op in H. discriminate H. Qed.

Lemma reff268_not2856 : ~ @Equation2856 Fin4 reff268_inst.
Proof. unfold Equation2856. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff268_inst, reff268_op in H. discriminate H. Qed.

Lemma reff268_not2862 : ~ @Equation2862 Fin4 reff268_inst.
Proof. unfold Equation2862. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff268_inst, reff268_op in H. discriminate H. Qed.

Lemma reff268_not2863 : ~ @Equation2863 Fin4 reff268_inst.
Proof. unfold Equation2863. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff268_inst, reff268_op in H. discriminate H. Qed.

Lemma reff268_not2865 : ~ @Equation2865 Fin4 reff268_inst.
Proof. unfold Equation2865. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff268_inst, reff268_op in H. discriminate H. Qed.

Lemma reff268_not2866 : ~ @Equation2866 Fin4 reff268_inst.
Proof. unfold Equation2866. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff268_inst, reff268_op in H. discriminate H. Qed.

Lemma reff268_not2872 : ~ @Equation2872 Fin4 reff268_inst.
Proof. unfold Equation2872. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff268_inst, reff268_op in H. discriminate H. Qed.

Lemma reff268_not2873 : ~ @Equation2873 Fin4 reff268_inst.
Proof. unfold Equation2873. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff268_inst, reff268_op in H. discriminate H. Qed.

Lemma reff268_not2875 : ~ @Equation2875 Fin4 reff268_inst.
Proof. unfold Equation2875. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff268_inst, reff268_op in H. discriminate H. Qed.

Lemma reff268_not2876 : ~ @Equation2876 Fin4 reff268_inst.
Proof. unfold Equation2876. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff268_inst, reff268_op in H. discriminate H. Qed.

Lemma reff268_not2899 : ~ @Equation2899 Fin4 reff268_inst.
Proof. unfold Equation2899. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff268_inst, reff268_op in H. discriminate H. Qed.

Lemma reff268_not2900 : ~ @Equation2900 Fin4 reff268_inst.
Proof. unfold Equation2900. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff268_inst, reff268_op in H. discriminate H. Qed.

Lemma reff268_not2902 : ~ @Equation2902 Fin4 reff268_inst.
Proof. unfold Equation2902. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff268_inst, reff268_op in H. discriminate H. Qed.

Lemma reff268_not2903 : ~ @Equation2903 Fin4 reff268_inst.
Proof. unfold Equation2903. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff268_inst, reff268_op in H. discriminate H. Qed.

Lemma reff268_not2909 : ~ @Equation2909 Fin4 reff268_inst.
Proof. unfold Equation2909. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff268_inst, reff268_op in H. discriminate H. Qed.

Lemma reff268_not2910 : ~ @Equation2910 Fin4 reff268_inst.
Proof. unfold Equation2910. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff268_inst, reff268_op in H. discriminate H. Qed.

Lemma reff268_not2912 : ~ @Equation2912 Fin4 reff268_inst.
Proof. unfold Equation2912. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff268_inst, reff268_op in H. discriminate H. Qed.

Lemma reff268_not2913 : ~ @Equation2913 Fin4 reff268_inst.
Proof. unfold Equation2913. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff268_inst, reff268_op in H. discriminate H. Qed.

Lemma reff268_not2936 : ~ @Equation2936 Fin4 reff268_inst.
Proof. unfold Equation2936. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff268_inst, reff268_op in H. discriminate H. Qed.

Lemma reff268_not2937 : ~ @Equation2937 Fin4 reff268_inst.
Proof. unfold Equation2937. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff268_inst, reff268_op in H. discriminate H. Qed.

Lemma reff268_not2939 : ~ @Equation2939 Fin4 reff268_inst.
Proof. unfold Equation2939. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff268_inst, reff268_op in H. discriminate H. Qed.

Lemma reff268_not2940 : ~ @Equation2940 Fin4 reff268_inst.
Proof. unfold Equation2940. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff268_inst, reff268_op in H. discriminate H. Qed.

Lemma reff268_not2946 : ~ @Equation2946 Fin4 reff268_inst.
Proof. unfold Equation2946. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff268_inst, reff268_op in H. discriminate H. Qed.

Lemma reff268_not2947 : ~ @Equation2947 Fin4 reff268_inst.
Proof. unfold Equation2947. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff268_inst, reff268_op in H. discriminate H. Qed.

Lemma reff268_not2949 : ~ @Equation2949 Fin4 reff268_inst.
Proof. unfold Equation2949. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff268_inst, reff268_op in H. discriminate H. Qed.

Lemma reff268_not3051 : ~ @Equation3051 Fin4 reff268_inst.
Proof. unfold Equation3051. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff268_inst, reff268_op in H. discriminate H. Qed.

Lemma reff268_not3052 : ~ @Equation3052 Fin4 reff268_inst.
Proof. unfold Equation3052. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff268_inst, reff268_op in H. discriminate H. Qed.

Lemma reff268_not3055 : ~ @Equation3055 Fin4 reff268_inst.
Proof. unfold Equation3055. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff268_inst, reff268_op in H. discriminate H. Qed.

Lemma reff268_not3059 : ~ @Equation3059 Fin4 reff268_inst.
Proof. unfold Equation3059. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff268_inst, reff268_op in H. discriminate H. Qed.

Lemma reff268_not3065 : ~ @Equation3065 Fin4 reff268_inst.
Proof. unfold Equation3065. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff268_inst, reff268_op in H. discriminate H. Qed.

Lemma reff268_not3069 : ~ @Equation3069 Fin4 reff268_inst.
Proof. unfold Equation3069. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff268_inst, reff268_op in H. discriminate H. Qed.

Lemma reff268_not3076 : ~ @Equation3076 Fin4 reff268_inst.
Proof. unfold Equation3076. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff268_inst, reff268_op in H. discriminate H. Qed.

Lemma reff268_not3078 : ~ @Equation3078 Fin4 reff268_inst.
Proof. unfold Equation3078. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff268_inst, reff268_op in H. discriminate H. Qed.

Lemma reff268_not3102 : ~ @Equation3102 Fin4 reff268_inst.
Proof. unfold Equation3102. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff268_inst, reff268_op in H. discriminate H. Qed.

Lemma reff268_not3103 : ~ @Equation3103 Fin4 reff268_inst.
Proof. unfold Equation3103. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff268_inst, reff268_op in H. discriminate H. Qed.

Lemma reff268_not3105 : ~ @Equation3105 Fin4 reff268_inst.
Proof. unfold Equation3105. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff268_inst, reff268_op in H. discriminate H. Qed.

Lemma reff268_not3106 : ~ @Equation3106 Fin4 reff268_inst.
Proof. unfold Equation3106. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff268_inst, reff268_op in H. discriminate H. Qed.

Lemma reff268_not3112 : ~ @Equation3112 Fin4 reff268_inst.
Proof. unfold Equation3112. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff268_inst, reff268_op in H. discriminate H. Qed.

Lemma reff268_not3113 : ~ @Equation3113 Fin4 reff268_inst.
Proof. unfold Equation3113. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff268_inst, reff268_op in H. discriminate H. Qed.

Lemma reff268_not3115 : ~ @Equation3115 Fin4 reff268_inst.
Proof. unfold Equation3115. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff268_inst, reff268_op in H. discriminate H. Qed.

Lemma reff268_not3116 : ~ @Equation3116 Fin4 reff268_inst.
Proof. unfold Equation3116. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff268_inst, reff268_op in H. discriminate H. Qed.

Lemma reff268_not3139 : ~ @Equation3139 Fin4 reff268_inst.
Proof. unfold Equation3139. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff268_inst, reff268_op in H. discriminate H. Qed.

Lemma reff268_not3140 : ~ @Equation3140 Fin4 reff268_inst.
Proof. unfold Equation3140. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff268_inst, reff268_op in H. discriminate H. Qed.

Lemma reff268_not3142 : ~ @Equation3142 Fin4 reff268_inst.
Proof. unfold Equation3142. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff268_inst, reff268_op in H. discriminate H. Qed.

Lemma reff268_not3143 : ~ @Equation3143 Fin4 reff268_inst.
Proof. unfold Equation3143. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff268_inst, reff268_op in H. discriminate H. Qed.

Lemma reff268_not3149 : ~ @Equation3149 Fin4 reff268_inst.
Proof. unfold Equation3149. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff268_inst, reff268_op in H. discriminate H. Qed.

Lemma reff268_not3150 : ~ @Equation3150 Fin4 reff268_inst.
Proof. unfold Equation3150. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff268_inst, reff268_op in H. discriminate H. Qed.

Lemma reff268_not3152 : ~ @Equation3152 Fin4 reff268_inst.
Proof. unfold Equation3152. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff268_inst, reff268_op in H. discriminate H. Qed.

Lemma reff268_not3254 : ~ @Equation3254 Fin4 reff268_inst.
Proof. unfold Equation3254. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff268_inst, reff268_op in H. discriminate H. Qed.

Lemma reff268_not3255 : ~ @Equation3255 Fin4 reff268_inst.
Proof. unfold Equation3255. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff268_inst, reff268_op in H. discriminate H. Qed.

Lemma reff268_not3256 : ~ @Equation3256 Fin4 reff268_inst.
Proof. unfold Equation3256. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff268_inst, reff268_op in H. discriminate H. Qed.

Lemma reff268_not3258 : ~ @Equation3258 Fin4 reff268_inst.
Proof. unfold Equation3258. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff268_inst, reff268_op in H. discriminate H. Qed.

Lemma reff268_not3259 : ~ @Equation3259 Fin4 reff268_inst.
Proof. unfold Equation3259. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff268_inst, reff268_op in H. discriminate H. Qed.

Lemma reff268_not3261 : ~ @Equation3261 Fin4 reff268_inst.
Proof. unfold Equation3261. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff268_inst, reff268_op in H. discriminate H. Qed.

Lemma reff268_not3262 : ~ @Equation3262 Fin4 reff268_inst.
Proof. unfold Equation3262. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff268_inst, reff268_op in H. discriminate H. Qed.

Lemma reff268_not3268 : ~ @Equation3268 Fin4 reff268_inst.
Proof. unfold Equation3268. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff268_inst, reff268_op in H. discriminate H. Qed.

Lemma reff268_not3269 : ~ @Equation3269 Fin4 reff268_inst.
Proof. unfold Equation3269. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff268_inst, reff268_op in H. discriminate H. Qed.

Lemma reff268_not3271 : ~ @Equation3271 Fin4 reff268_inst.
Proof. unfold Equation3271. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff268_inst, reff268_op in H. discriminate H. Qed.

Lemma reff268_not3272 : ~ @Equation3272 Fin4 reff268_inst.
Proof. unfold Equation3272. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff268_inst, reff268_op in H. discriminate H. Qed.

Lemma reff268_not3278 : ~ @Equation3278 Fin4 reff268_inst.
Proof. unfold Equation3278. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff268_inst, reff268_op in H. discriminate H. Qed.

Lemma reff268_not3279 : ~ @Equation3279 Fin4 reff268_inst.
Proof. unfold Equation3279. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff268_inst, reff268_op in H. discriminate H. Qed.

Lemma reff268_not3281 : ~ @Equation3281 Fin4 reff268_inst.
Proof. unfold Equation3281. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff268_inst, reff268_op in H. discriminate H. Qed.

Lemma reff268_not3308 : ~ @Equation3308 Fin4 reff268_inst.
Proof. unfold Equation3308. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff268_inst, reff268_op in H. discriminate H. Qed.

Lemma reff268_not3309 : ~ @Equation3309 Fin4 reff268_inst.
Proof. unfold Equation3309. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff268_inst, reff268_op in H. discriminate H. Qed.

Lemma reff268_not3315 : ~ @Equation3315 Fin4 reff268_inst.
Proof. unfold Equation3315. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff268_inst, reff268_op in H. discriminate H. Qed.

Lemma reff268_not3316 : ~ @Equation3316 Fin4 reff268_inst.
Proof. unfold Equation3316. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff268_inst, reff268_op in H. discriminate H. Qed.

Lemma reff268_not3318 : ~ @Equation3318 Fin4 reff268_inst.
Proof. unfold Equation3318. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff268_inst, reff268_op in H. discriminate H. Qed.

Lemma reff268_not3342 : ~ @Equation3342 Fin4 reff268_inst.
Proof. unfold Equation3342. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff268_inst, reff268_op in H. discriminate H. Qed.

Lemma reff268_not3343 : ~ @Equation3343 Fin4 reff268_inst.
Proof. unfold Equation3343. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff268_inst, reff268_op in H. discriminate H. Qed.

Lemma reff268_not3345 : ~ @Equation3345 Fin4 reff268_inst.
Proof. unfold Equation3345. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff268_inst, reff268_op in H. discriminate H. Qed.

Lemma reff268_not3346 : ~ @Equation3346 Fin4 reff268_inst.
Proof. unfold Equation3346. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff268_inst, reff268_op in H. discriminate H. Qed.

Lemma reff268_not3352 : ~ @Equation3352 Fin4 reff268_inst.
Proof. unfold Equation3352. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff268_inst, reff268_op in H. discriminate H. Qed.

Lemma reff268_not3353 : ~ @Equation3353 Fin4 reff268_inst.
Proof. unfold Equation3353. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff268_inst, reff268_op in H. discriminate H. Qed.

Lemma reff268_not3457 : ~ @Equation3457 Fin4 reff268_inst.
Proof. unfold Equation3457. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff268_inst, reff268_op in H. discriminate H. Qed.

Lemma reff268_not3458 : ~ @Equation3458 Fin4 reff268_inst.
Proof. unfold Equation3458. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff268_inst, reff268_op in H. discriminate H. Qed.

Lemma reff268_not3461 : ~ @Equation3461 Fin4 reff268_inst.
Proof. unfold Equation3461. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff268_inst, reff268_op in H. discriminate H. Qed.

Lemma reff268_not3462 : ~ @Equation3462 Fin4 reff268_inst.
Proof. unfold Equation3462. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff268_inst, reff268_op in H. discriminate H. Qed.

Lemma reff268_not3464 : ~ @Equation3464 Fin4 reff268_inst.
Proof. unfold Equation3464. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff268_inst, reff268_op in H. discriminate H. Qed.

Lemma reff268_not3465 : ~ @Equation3465 Fin4 reff268_inst.
Proof. unfold Equation3465. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff268_inst, reff268_op in H. discriminate H. Qed.

Lemma reff268_not3472 : ~ @Equation3472 Fin4 reff268_inst.
Proof. unfold Equation3472. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff268_inst, reff268_op in H. discriminate H. Qed.

Lemma reff268_not3474 : ~ @Equation3474 Fin4 reff268_inst.
Proof. unfold Equation3474. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff268_inst, reff268_op in H. discriminate H. Qed.

Lemma reff268_not3475 : ~ @Equation3475 Fin4 reff268_inst.
Proof. unfold Equation3475. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff268_inst, reff268_op in H. discriminate H. Qed.

Lemma reff268_not3481 : ~ @Equation3481 Fin4 reff268_inst.
Proof. unfold Equation3481. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff268_inst, reff268_op in H. discriminate H. Qed.

Lemma reff268_not3482 : ~ @Equation3482 Fin4 reff268_inst.
Proof. unfold Equation3482. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff268_inst, reff268_op in H. discriminate H. Qed.

Lemma reff268_not3484 : ~ @Equation3484 Fin4 reff268_inst.
Proof. unfold Equation3484. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff268_inst, reff268_op in H. discriminate H. Qed.

Lemma reff268_not3512 : ~ @Equation3512 Fin4 reff268_inst.
Proof. unfold Equation3512. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff268_inst, reff268_op in H. discriminate H. Qed.

Lemma reff268_not3519 : ~ @Equation3519 Fin4 reff268_inst.
Proof. unfold Equation3519. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff268_inst, reff268_op in H. discriminate H. Qed.

Lemma reff268_not3521 : ~ @Equation3521 Fin4 reff268_inst.
Proof. unfold Equation3521. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff268_inst, reff268_op in H. discriminate H. Qed.

Lemma reff268_not3545 : ~ @Equation3545 Fin4 reff268_inst.
Proof. unfold Equation3545. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff268_inst, reff268_op in H. discriminate H. Qed.

Lemma reff268_not3546 : ~ @Equation3546 Fin4 reff268_inst.
Proof. unfold Equation3546. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff268_inst, reff268_op in H. discriminate H. Qed.

Lemma reff268_not3548 : ~ @Equation3548 Fin4 reff268_inst.
Proof. unfold Equation3548. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff268_inst, reff268_op in H. discriminate H. Qed.

Lemma reff268_not3549 : ~ @Equation3549 Fin4 reff268_inst.
Proof. unfold Equation3549. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff268_inst, reff268_op in H. discriminate H. Qed.

Lemma reff268_not3555 : ~ @Equation3555 Fin4 reff268_inst.
Proof. unfold Equation3555. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff268_inst, reff268_op in H. discriminate H. Qed.

Lemma reff268_not3556 : ~ @Equation3556 Fin4 reff268_inst.
Proof. unfold Equation3556. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff268_inst, reff268_op in H. discriminate H. Qed.

Lemma reff268_not3558 : ~ @Equation3558 Fin4 reff268_inst.
Proof. unfold Equation3558. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff268_inst, reff268_op in H. discriminate H. Qed.

Lemma reff268_not3660 : ~ @Equation3660 Fin4 reff268_inst.
Proof. unfold Equation3660. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff268_inst, reff268_op in H. discriminate H. Qed.

Lemma reff268_not3661 : ~ @Equation3661 Fin4 reff268_inst.
Proof. unfold Equation3661. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff268_inst, reff268_op in H. discriminate H. Qed.

Lemma reff268_not3662 : ~ @Equation3662 Fin4 reff268_inst.
Proof. unfold Equation3662. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff268_inst, reff268_op in H. discriminate H. Qed.

Lemma reff268_not3664 : ~ @Equation3664 Fin4 reff268_inst.
Proof. unfold Equation3664. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff268_inst, reff268_op in H. discriminate H. Qed.

Lemma reff268_not3667 : ~ @Equation3667 Fin4 reff268_inst.
Proof. unfold Equation3667. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff268_inst, reff268_op in H. discriminate H. Qed.

Lemma reff268_not3668 : ~ @Equation3668 Fin4 reff268_inst.
Proof. unfold Equation3668. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff268_inst, reff268_op in H. discriminate H. Qed.

Lemma reff268_not3674 : ~ @Equation3674 Fin4 reff268_inst.
Proof. unfold Equation3674. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff268_inst, reff268_op in H. discriminate H. Qed.

Lemma reff268_not3675 : ~ @Equation3675 Fin4 reff268_inst.
Proof. unfold Equation3675. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff268_inst, reff268_op in H. discriminate H. Qed.

Lemma reff268_not3677 : ~ @Equation3677 Fin4 reff268_inst.
Proof. unfold Equation3677. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff268_inst, reff268_op in H. discriminate H. Qed.

Lemma reff268_not3678 : ~ @Equation3678 Fin4 reff268_inst.
Proof. unfold Equation3678. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff268_inst, reff268_op in H. discriminate H. Qed.

Lemma reff268_not3684 : ~ @Equation3684 Fin4 reff268_inst.
Proof. unfold Equation3684. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff268_inst, reff268_op in H. discriminate H. Qed.

Lemma reff268_not3685 : ~ @Equation3685 Fin4 reff268_inst.
Proof. unfold Equation3685. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff268_inst, reff268_op in H. discriminate H. Qed.

Lemma reff268_not3687 : ~ @Equation3687 Fin4 reff268_inst.
Proof. unfold Equation3687. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff268_inst, reff268_op in H. discriminate H. Qed.

Lemma reff268_not3714 : ~ @Equation3714 Fin4 reff268_inst.
Proof. unfold Equation3714. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff268_inst, reff268_op in H. discriminate H. Qed.

Lemma reff268_not3722 : ~ @Equation3722 Fin4 reff268_inst.
Proof. unfold Equation3722. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff268_inst, reff268_op in H. discriminate H. Qed.

Lemma reff268_not3724 : ~ @Equation3724 Fin4 reff268_inst.
Proof. unfold Equation3724. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff268_inst, reff268_op in H. discriminate H. Qed.

Lemma reff268_not3725 : ~ @Equation3725 Fin4 reff268_inst.
Proof. unfold Equation3725. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff268_inst, reff268_op in H. discriminate H. Qed.

Lemma reff268_not3748 : ~ @Equation3748 Fin4 reff268_inst.
Proof. unfold Equation3748. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff268_inst, reff268_op in H. discriminate H. Qed.

Lemma reff268_not3749 : ~ @Equation3749 Fin4 reff268_inst.
Proof. unfold Equation3749. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff268_inst, reff268_op in H. discriminate H. Qed.

Lemma reff268_not3751 : ~ @Equation3751 Fin4 reff268_inst.
Proof. unfold Equation3751. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff268_inst, reff268_op in H. discriminate H. Qed.

Lemma reff268_not3752 : ~ @Equation3752 Fin4 reff268_inst.
Proof. unfold Equation3752. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff268_inst, reff268_op in H. discriminate H. Qed.

Lemma reff268_not3759 : ~ @Equation3759 Fin4 reff268_inst.
Proof. unfold Equation3759. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff268_inst, reff268_op in H. discriminate H. Qed.

Lemma reff268_not3761 : ~ @Equation3761 Fin4 reff268_inst.
Proof. unfold Equation3761. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff268_inst, reff268_op in H. discriminate H. Qed.

Lemma reff268_not3864 : ~ @Equation3864 Fin4 reff268_inst.
Proof. unfold Equation3864. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff268_inst, reff268_op in H. discriminate H. Qed.

Lemma reff268_not3867 : ~ @Equation3867 Fin4 reff268_inst.
Proof. unfold Equation3867. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff268_inst, reff268_op in H. discriminate H. Qed.

Lemma reff268_not3868 : ~ @Equation3868 Fin4 reff268_inst.
Proof. unfold Equation3868. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff268_inst, reff268_op in H. discriminate H. Qed.

Lemma reff268_not3870 : ~ @Equation3870 Fin4 reff268_inst.
Proof. unfold Equation3870. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff268_inst, reff268_op in H. discriminate H. Qed.

Lemma reff268_not3871 : ~ @Equation3871 Fin4 reff268_inst.
Proof. unfold Equation3871. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff268_inst, reff268_op in H. discriminate H. Qed.

Lemma reff268_not3877 : ~ @Equation3877 Fin4 reff268_inst.
Proof. unfold Equation3877. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff268_inst, reff268_op in H. discriminate H. Qed.

Lemma reff268_not3878 : ~ @Equation3878 Fin4 reff268_inst.
Proof. unfold Equation3878. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff268_inst, reff268_op in H. discriminate H. Qed.

Lemma reff268_not3880 : ~ @Equation3880 Fin4 reff268_inst.
Proof. unfold Equation3880. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff268_inst, reff268_op in H. discriminate H. Qed.

Lemma reff268_not3881 : ~ @Equation3881 Fin4 reff268_inst.
Proof. unfold Equation3881. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff268_inst, reff268_op in H. discriminate H. Qed.

Lemma reff268_not3887 : ~ @Equation3887 Fin4 reff268_inst.
Proof. unfold Equation3887. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff268_inst, reff268_op in H. discriminate H. Qed.

Lemma reff268_not3888 : ~ @Equation3888 Fin4 reff268_inst.
Proof. unfold Equation3888. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff268_inst, reff268_op in H. discriminate H. Qed.

Lemma reff268_not3890 : ~ @Equation3890 Fin4 reff268_inst.
Proof. unfold Equation3890. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff268_inst, reff268_op in H. discriminate H. Qed.

Lemma reff268_not3918 : ~ @Equation3918 Fin4 reff268_inst.
Proof. unfold Equation3918. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff268_inst, reff268_op in H. discriminate H. Qed.

Lemma reff268_not3924 : ~ @Equation3924 Fin4 reff268_inst.
Proof. unfold Equation3924. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff268_inst, reff268_op in H. discriminate H. Qed.

Lemma reff268_not3925 : ~ @Equation3925 Fin4 reff268_inst.
Proof. unfold Equation3925. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff268_inst, reff268_op in H. discriminate H. Qed.

Lemma reff268_not3927 : ~ @Equation3927 Fin4 reff268_inst.
Proof. unfold Equation3927. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff268_inst, reff268_op in H. discriminate H. Qed.

Lemma reff268_not3928 : ~ @Equation3928 Fin4 reff268_inst.
Proof. unfold Equation3928. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff268_inst, reff268_op in H. discriminate H. Qed.

Lemma reff268_not3951 : ~ @Equation3951 Fin4 reff268_inst.
Proof. unfold Equation3951. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff268_inst, reff268_op in H. discriminate H. Qed.

Lemma reff268_not3952 : ~ @Equation3952 Fin4 reff268_inst.
Proof. unfold Equation3952. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff268_inst, reff268_op in H. discriminate H. Qed.

Lemma reff268_not3954 : ~ @Equation3954 Fin4 reff268_inst.
Proof. unfold Equation3954. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff268_inst, reff268_op in H. discriminate H. Qed.

Lemma reff268_not3955 : ~ @Equation3955 Fin4 reff268_inst.
Proof. unfold Equation3955. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff268_inst, reff268_op in H. discriminate H. Qed.

Lemma reff268_not3961 : ~ @Equation3961 Fin4 reff268_inst.
Proof. unfold Equation3961. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff268_inst, reff268_op in H. discriminate H. Qed.

Lemma reff268_not3962 : ~ @Equation3962 Fin4 reff268_inst.
Proof. unfold Equation3962. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff268_inst, reff268_op in H. discriminate H. Qed.

Lemma reff268_not3964 : ~ @Equation3964 Fin4 reff268_inst.
Proof. unfold Equation3964. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff268_inst, reff268_op in H. discriminate H. Qed.

Lemma reff268_not4066 : ~ @Equation4066 Fin4 reff268_inst.
Proof. unfold Equation4066. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff268_inst, reff268_op in H. discriminate H. Qed.

Lemma reff268_not4067 : ~ @Equation4067 Fin4 reff268_inst.
Proof. unfold Equation4067. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff268_inst, reff268_op in H. discriminate H. Qed.

Lemma reff268_not4070 : ~ @Equation4070 Fin4 reff268_inst.
Proof. unfold Equation4070. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff268_inst, reff268_op in H. discriminate H. Qed.

Lemma reff268_not4074 : ~ @Equation4074 Fin4 reff268_inst.
Proof. unfold Equation4074. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff268_inst, reff268_op in H. discriminate H. Qed.

Lemma reff268_not4080 : ~ @Equation4080 Fin4 reff268_inst.
Proof. unfold Equation4080. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff268_inst, reff268_op in H. discriminate H. Qed.

Lemma reff268_not4081 : ~ @Equation4081 Fin4 reff268_inst.
Proof. unfold Equation4081. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff268_inst, reff268_op in H. discriminate H. Qed.

Lemma reff268_not4083 : ~ @Equation4083 Fin4 reff268_inst.
Proof. unfold Equation4083. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff268_inst, reff268_op in H. discriminate H. Qed.

Lemma reff268_not4084 : ~ @Equation4084 Fin4 reff268_inst.
Proof. unfold Equation4084. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff268_inst, reff268_op in H. discriminate H. Qed.

Lemma reff268_not4090 : ~ @Equation4090 Fin4 reff268_inst.
Proof. unfold Equation4090. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff268_inst, reff268_op in H. discriminate H. Qed.

Lemma reff268_not4091 : ~ @Equation4091 Fin4 reff268_inst.
Proof. unfold Equation4091. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff268_inst, reff268_op in H. discriminate H. Qed.

Lemma reff268_not4093 : ~ @Equation4093 Fin4 reff268_inst.
Proof. unfold Equation4093. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff268_inst, reff268_op in H. discriminate H. Qed.

Lemma reff268_not4121 : ~ @Equation4121 Fin4 reff268_inst.
Proof. unfold Equation4121. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff268_inst, reff268_op in H. discriminate H. Qed.

Lemma reff268_not4128 : ~ @Equation4128 Fin4 reff268_inst.
Proof. unfold Equation4128. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff268_inst, reff268_op in H. discriminate H. Qed.

Lemma reff268_not4130 : ~ @Equation4130 Fin4 reff268_inst.
Proof. unfold Equation4130. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff268_inst, reff268_op in H. discriminate H. Qed.

Lemma reff268_not4155 : ~ @Equation4155 Fin4 reff268_inst.
Proof. unfold Equation4155. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff268_inst, reff268_op in H. discriminate H. Qed.

Lemma reff268_not4157 : ~ @Equation4157 Fin4 reff268_inst.
Proof. unfold Equation4157. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff268_inst, reff268_op in H. discriminate H. Qed.

Lemma reff268_not4158 : ~ @Equation4158 Fin4 reff268_inst.
Proof. unfold Equation4158. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff268_inst, reff268_op in H. discriminate H. Qed.

Lemma reff268_not4164 : ~ @Equation4164 Fin4 reff268_inst.
Proof. unfold Equation4164. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff268_inst, reff268_op in H. discriminate H. Qed.

Lemma reff268_not4165 : ~ @Equation4165 Fin4 reff268_inst.
Proof. unfold Equation4165. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff268_inst, reff268_op in H. discriminate H. Qed.

Lemma reff268_not4167 : ~ @Equation4167 Fin4 reff268_inst.
Proof. unfold Equation4167. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff268_inst, reff268_op in H. discriminate H. Qed.

Lemma reff268_not4268 : ~ @Equation4268 Fin4 reff268_inst.
Proof. unfold Equation4268. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff268_inst, reff268_op in H. discriminate H. Qed.

Lemma reff268_not4269 : ~ @Equation4269 Fin4 reff268_inst.
Proof. unfold Equation4269. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff268_inst, reff268_op in H. discriminate H. Qed.

Lemma reff268_not4270 : ~ @Equation4270 Fin4 reff268_inst.
Proof. unfold Equation4270. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff268_inst, reff268_op in H. discriminate H. Qed.

Lemma reff268_not4272 : ~ @Equation4272 Fin4 reff268_inst.
Proof. unfold Equation4272. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff268_inst, reff268_op in H. discriminate H. Qed.

Lemma reff268_not4273 : ~ @Equation4273 Fin4 reff268_inst.
Proof. unfold Equation4273. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff268_inst, reff268_op in H. discriminate H. Qed.

Lemma reff268_not4275 : ~ @Equation4275 Fin4 reff268_inst.
Proof. unfold Equation4275. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff268_inst, reff268_op in H. discriminate H. Qed.

Lemma reff268_not4276 : ~ @Equation4276 Fin4 reff268_inst.
Proof. unfold Equation4276. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff268_inst, reff268_op in H. discriminate H. Qed.

Lemma reff268_not4283 : ~ @Equation4283 Fin4 reff268_inst.
Proof. unfold Equation4283. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff268_inst, reff268_op in H. discriminate H. Qed.

Lemma reff268_not4284 : ~ @Equation4284 Fin4 reff268_inst.
Proof. unfold Equation4284. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff268_inst, reff268_op in H. discriminate H. Qed.

Lemma reff268_not4290 : ~ @Equation4290 Fin4 reff268_inst.
Proof. unfold Equation4290. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff268_inst, reff268_op in H. discriminate H. Qed.

Lemma reff268_not4291 : ~ @Equation4291 Fin4 reff268_inst.
Proof. unfold Equation4291. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff268_inst, reff268_op in H. discriminate H. Qed.

Lemma reff268_not4293 : ~ @Equation4293 Fin4 reff268_inst.
Proof. unfold Equation4293. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff268_inst, reff268_op in H. discriminate H. Qed.

Lemma reff268_not4314 : ~ @Equation4314 Fin4 reff268_inst.
Proof. unfold Equation4314. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff268_inst, reff268_op in H. discriminate H. Qed.

Lemma reff268_not4320 : ~ @Equation4320 Fin4 reff268_inst.
Proof. unfold Equation4320. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff268_inst, reff268_op in H. discriminate H. Qed.

Lemma reff268_not4321 : ~ @Equation4321 Fin4 reff268_inst.
Proof. unfold Equation4321. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff268_inst, reff268_op in H. discriminate H. Qed.

Lemma reff268_not4343 : ~ @Equation4343 Fin4 reff268_inst.
Proof. unfold Equation4343. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff268_inst, reff268_op in H. discriminate H. Qed.

Lemma reff268_not4399 : ~ @Equation4399 Fin4 reff268_inst.
Proof. unfold Equation4399. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff268_inst, reff268_op in H. discriminate H. Qed.

Lemma reff268_not4405 : ~ @Equation4405 Fin4 reff268_inst.
Proof. unfold Equation4405. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff268_inst, reff268_op in H. discriminate H. Qed.

Lemma reff268_not4406 : ~ @Equation4406 Fin4 reff268_inst.
Proof. unfold Equation4406. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff268_inst, reff268_op in H. discriminate H. Qed.

Lemma reff268_not4408 : ~ @Equation4408 Fin4 reff268_inst.
Proof. unfold Equation4408. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff268_inst, reff268_op in H. discriminate H. Qed.

Lemma reff268_not4433 : ~ @Equation4433 Fin4 reff268_inst.
Proof. unfold Equation4433. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff268_inst, reff268_op in H. discriminate H. Qed.

Lemma reff268_not4435 : ~ @Equation4435 Fin4 reff268_inst.
Proof. unfold Equation4435. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff268_inst, reff268_op in H. discriminate H. Qed.

Lemma reff268_not4436 : ~ @Equation4436 Fin4 reff268_inst.
Proof. unfold Equation4436. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff268_inst, reff268_op in H. discriminate H. Qed.

Lemma reff268_not4442 : ~ @Equation4442 Fin4 reff268_inst.
Proof. unfold Equation4442. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff268_inst, reff268_op in H. discriminate H. Qed.

Lemma reff268_not4443 : ~ @Equation4443 Fin4 reff268_inst.
Proof. unfold Equation4443. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff268_inst, reff268_op in H. discriminate H. Qed.

Lemma reff268_not4445 : ~ @Equation4445 Fin4 reff268_inst.
Proof. unfold Equation4445. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff268_inst, reff268_op in H. discriminate H. Qed.

Lemma reff268_not4470 : ~ @Equation4470 Fin4 reff268_inst.
Proof. unfold Equation4470. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff268_inst, reff268_op in H. discriminate H. Qed.

Lemma reff268_not4472 : ~ @Equation4472 Fin4 reff268_inst.
Proof. unfold Equation4472. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff268_inst, reff268_op in H. discriminate H. Qed.

Lemma reff268_not4473 : ~ @Equation4473 Fin4 reff268_inst.
Proof. unfold Equation4473. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff268_inst, reff268_op in H. discriminate H. Qed.

Lemma reff268_not4479 : ~ @Equation4479 Fin4 reff268_inst.
Proof. unfold Equation4479. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff268_inst, reff268_op in H. discriminate H. Qed.

Lemma reff268_not4480 : ~ @Equation4480 Fin4 reff268_inst.
Proof. unfold Equation4480. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff268_inst, reff268_op in H. discriminate H. Qed.

Lemma reff268_not4482 : ~ @Equation4482 Fin4 reff268_inst.
Proof. unfold Equation4482. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff268_inst, reff268_op in H. discriminate H. Qed.

Lemma reff268_not4583 : ~ @Equation4583 Fin4 reff268_inst.
Proof. unfold Equation4583. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff268_inst, reff268_op in H. discriminate H. Qed.

Lemma reff268_not4584 : ~ @Equation4584 Fin4 reff268_inst.
Proof. unfold Equation4584. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff268_inst, reff268_op in H. discriminate H. Qed.

Lemma reff268_not4587 : ~ @Equation4587 Fin4 reff268_inst.
Proof. unfold Equation4587. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff268_inst, reff268_op in H. discriminate H. Qed.

Lemma reff268_not4588 : ~ @Equation4588 Fin4 reff268_inst.
Proof. unfold Equation4588. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff268_inst, reff268_op in H. discriminate H. Qed.

Lemma reff268_not4590 : ~ @Equation4590 Fin4 reff268_inst.
Proof. unfold Equation4590. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff268_inst, reff268_op in H. discriminate H. Qed.

Lemma reff268_not4591 : ~ @Equation4591 Fin4 reff268_inst.
Proof. unfold Equation4591. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff268_inst, reff268_op in H. discriminate H. Qed.

Lemma reff268_not4599 : ~ @Equation4599 Fin4 reff268_inst.
Proof. unfold Equation4599. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff268_inst, reff268_op in H. discriminate H. Qed.

Lemma reff268_not4605 : ~ @Equation4605 Fin4 reff268_inst.
Proof. unfold Equation4605. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff268_inst, reff268_op in H. discriminate H. Qed.

Lemma reff268_not4606 : ~ @Equation4606 Fin4 reff268_inst.
Proof. unfold Equation4606. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff268_inst, reff268_op in H. discriminate H. Qed.

Lemma reff268_not4608 : ~ @Equation4608 Fin4 reff268_inst.
Proof. unfold Equation4608. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff268_inst, reff268_op in H. discriminate H. Qed.

Lemma reff268_not4629 : ~ @Equation4629 Fin4 reff268_inst.
Proof. unfold Equation4629. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff268_inst, reff268_op in H. discriminate H. Qed.

Lemma reff268_not4635 : ~ @Equation4635 Fin4 reff268_inst.
Proof. unfold Equation4635. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff268_inst, reff268_op in H. discriminate H. Qed.

Lemma reff268_not4636 : ~ @Equation4636 Fin4 reff268_inst.
Proof. unfold Equation4636. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff268_inst, reff268_op in H. discriminate H. Qed.

Lemma reff268_not4658 : ~ @Equation4658 Fin4 reff268_inst.
Proof. unfold Equation4658. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff268_inst, reff268_op in H. discriminate H. Qed.

(** ---- reff270 (Fin5) ---- *)

Definition reff270_op (x y : Fin5) : Fin5 :=
  match x, y with
  | F5_0, F5_0 => F5_0 | F5_0, F5_1 => F5_4 | F5_0, F5_2 => F5_2 | F5_0, F5_3 => F5_4 | F5_0, F5_4 => F5_0
  | F5_1, F5_0 => F5_3 | F5_1, F5_1 => F5_1 | F5_1, F5_2 => F5_3 | F5_1, F5_3 => F5_4 | F5_1, F5_4 => F5_4
  | F5_2, F5_0 => F5_0 | F5_2, F5_1 => F5_2 | F5_2, F5_2 => F5_3 | F5_2, F5_3 => F5_3 | F5_2, F5_4 => F5_2
  | F5_3, F5_0 => F5_1 | F5_3, F5_1 => F5_2 | F5_3, F5_2 => F5_2 | F5_3, F5_3 => F5_1 | F5_3, F5_4 => F5_4
  | F5_4, F5_0 => F5_1 | F5_4, F5_1 => F5_1 | F5_4, F5_2 => F5_0 | F5_4, F5_3 => F5_3 | F5_4, F5_4 => F5_0
  end.

#[local] Instance reff270_inst : Magma Fin5 := {| magma_op := reff270_op |}.

Lemma reff270_sat205 : @Equation205 Fin5 reff270_inst.
Proof. unfold Equation205, magma_op, reff270_inst, reff270_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff270_sat2459 : @Equation2459 Fin5 reff270_inst.
Proof. unfold Equation2459, magma_op, reff270_inst, reff270_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff270_not4065 : ~ @Equation4065 Fin5 reff270_inst.
Proof. unfold Equation4065. intro H. specialize (H F5_3). unfold magma_op, reff270_inst, reff270_op in H. discriminate H. Qed.

(** ---- reff272 (Fin4) ---- *)

Definition reff272_op (x y : Fin4) : Fin4 :=
  match x, y with
  | F4_0, F4_0 => F4_0 | F4_0, F4_1 => F4_2 | F4_0, F4_2 => F4_2 | F4_0, F4_3 => F4_0
  | F4_1, F4_0 => F4_3 | F4_1, F4_1 => F4_0 | F4_1, F4_2 => F4_3 | F4_1, F4_3 => F4_0
  | F4_2, F4_0 => F4_2 | F4_2, F4_1 => F4_2 | F4_2, F4_2 => F4_0 | F4_2, F4_3 => F4_0
  | F4_3, F4_0 => F4_1 | F4_3, F4_1 => F4_0 | F4_3, F4_2 => F4_1 | F4_3, F4_3 => F4_0
  end.

#[local] Instance reff272_inst : Magma Fin4 := {| magma_op := reff272_op |}.

Lemma reff272_sat1865 : @Equation1865 Fin4 reff272_inst.
Proof. unfold Equation1865, magma_op, reff272_inst, reff272_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff272_sat3282 : @Equation3282 Fin4 reff272_inst.
Proof. unfold Equation3282, magma_op, reff272_inst, reff272_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff272_sat3891 : @Equation3891 Fin4 reff272_inst.
Proof. unfold Equation3891, magma_op, reff272_inst, reff272_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff272_not47 : ~ @Equation47 Fin4 reff272_inst.
Proof. unfold Equation47. intro H. specialize (H F4_1). unfold magma_op, reff272_inst, reff272_op in H. discriminate H. Qed.

Lemma reff272_not99 : ~ @Equation99 Fin4 reff272_inst.
Proof. unfold Equation99. intro H. specialize (H F4_1). unfold magma_op, reff272_inst, reff272_op in H. discriminate H. Qed.

Lemma reff272_not151 : ~ @Equation151 Fin4 reff272_inst.
Proof. unfold Equation151. intro H. specialize (H F4_1). unfold magma_op, reff272_inst, reff272_op in H. discriminate H. Qed.

Lemma reff272_not203 : ~ @Equation203 Fin4 reff272_inst.
Proof. unfold Equation203. intro H. specialize (H F4_1). unfold magma_op, reff272_inst, reff272_op in H. discriminate H. Qed.

Lemma reff272_not255 : ~ @Equation255 Fin4 reff272_inst.
Proof. unfold Equation255. intro H. specialize (H F4_1). unfold magma_op, reff272_inst, reff272_op in H. discriminate H. Qed.

Lemma reff272_not307 : ~ @Equation307 Fin4 reff272_inst.
Proof. unfold Equation307. intro H. specialize (H F4_1). unfold magma_op, reff272_inst, reff272_op in H. discriminate H. Qed.

Lemma reff272_not411 : ~ @Equation411 Fin4 reff272_inst.
Proof. unfold Equation411. intro H. specialize (H F4_1). unfold magma_op, reff272_inst, reff272_op in H. discriminate H. Qed.

Lemma reff272_not614 : ~ @Equation614 Fin4 reff272_inst.
Proof. unfold Equation614. intro H. specialize (H F4_1). unfold magma_op, reff272_inst, reff272_op in H. discriminate H. Qed.

Lemma reff272_not817 : ~ @Equation817 Fin4 reff272_inst.
Proof. unfold Equation817. intro H. specialize (H F4_1). unfold magma_op, reff272_inst, reff272_op in H. discriminate H. Qed.

Lemma reff272_not1020 : ~ @Equation1020 Fin4 reff272_inst.
Proof. unfold Equation1020. intro H. specialize (H F4_1). unfold magma_op, reff272_inst, reff272_op in H. discriminate H. Qed.

Lemma reff272_not1223 : ~ @Equation1223 Fin4 reff272_inst.
Proof. unfold Equation1223. intro H. specialize (H F4_1). unfold magma_op, reff272_inst, reff272_op in H. discriminate H. Qed.

Lemma reff272_not1426 : ~ @Equation1426 Fin4 reff272_inst.
Proof. unfold Equation1426. intro H. specialize (H F4_1). unfold magma_op, reff272_inst, reff272_op in H. discriminate H. Qed.

Lemma reff272_not1629 : ~ @Equation1629 Fin4 reff272_inst.
Proof. unfold Equation1629. intro H. specialize (H F4_1). unfold magma_op, reff272_inst, reff272_op in H. discriminate H. Qed.

Lemma reff272_not1833 : ~ @Equation1833 Fin4 reff272_inst.
Proof. unfold Equation1833. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff272_inst, reff272_op in H. discriminate H. Qed.

Lemma reff272_not1834 : ~ @Equation1834 Fin4 reff272_inst.
Proof. unfold Equation1834. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff272_inst, reff272_op in H. discriminate H. Qed.

Lemma reff272_not1837 : ~ @Equation1837 Fin4 reff272_inst.
Proof. unfold Equation1837. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff272_inst, reff272_op in H. discriminate H. Qed.

Lemma reff272_not1838 : ~ @Equation1838 Fin4 reff272_inst.
Proof. unfold Equation1838. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff272_inst, reff272_op in H. discriminate H. Qed.

Lemma reff272_not1840 : ~ @Equation1840 Fin4 reff272_inst.
Proof. unfold Equation1840. intro H. specialize (H F4_0 F4_3). unfold magma_op, reff272_inst, reff272_op in H. discriminate H. Qed.

Lemma reff272_not1841 : ~ @Equation1841 Fin4 reff272_inst.
Proof. unfold Equation1841. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff272_inst, reff272_op in H. discriminate H. Qed.

Lemma reff272_not1847 : ~ @Equation1847 Fin4 reff272_inst.
Proof. unfold Equation1847. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff272_inst, reff272_op in H. discriminate H. Qed.

Lemma reff272_not1848 : ~ @Equation1848 Fin4 reff272_inst.
Proof. unfold Equation1848. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff272_inst, reff272_op in H. discriminate H. Qed.

Lemma reff272_not1850 : ~ @Equation1850 Fin4 reff272_inst.
Proof. unfold Equation1850. intro H. specialize (H F4_0 F4_3). unfold magma_op, reff272_inst, reff272_op in H. discriminate H. Qed.

Lemma reff272_not1851 : ~ @Equation1851 Fin4 reff272_inst.
Proof. unfold Equation1851. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff272_inst, reff272_op in H. discriminate H. Qed.

Lemma reff272_not1858 : ~ @Equation1858 Fin4 reff272_inst.
Proof. unfold Equation1858. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff272_inst, reff272_op in H. discriminate H. Qed.

Lemma reff272_not1860 : ~ @Equation1860 Fin4 reff272_inst.
Proof. unfold Equation1860. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff272_inst, reff272_op in H. discriminate H. Qed.

Lemma reff272_not1884 : ~ @Equation1884 Fin4 reff272_inst.
Proof. unfold Equation1884. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff272_inst, reff272_op in H. discriminate H. Qed.

Lemma reff272_not1885 : ~ @Equation1885 Fin4 reff272_inst.
Proof. unfold Equation1885. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff272_inst, reff272_op in H. discriminate H. Qed.

Lemma reff272_not1887 : ~ @Equation1887 Fin4 reff272_inst.
Proof. unfold Equation1887. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff272_inst, reff272_op in H. discriminate H. Qed.

Lemma reff272_not1888 : ~ @Equation1888 Fin4 reff272_inst.
Proof. unfold Equation1888. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff272_inst, reff272_op in H. discriminate H. Qed.

Lemma reff272_not1894 : ~ @Equation1894 Fin4 reff272_inst.
Proof. unfold Equation1894. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff272_inst, reff272_op in H. discriminate H. Qed.

Lemma reff272_not1895 : ~ @Equation1895 Fin4 reff272_inst.
Proof. unfold Equation1895. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff272_inst, reff272_op in H. discriminate H. Qed.

Lemma reff272_not1897 : ~ @Equation1897 Fin4 reff272_inst.
Proof. unfold Equation1897. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff272_inst, reff272_op in H. discriminate H. Qed.

Lemma reff272_not1898 : ~ @Equation1898 Fin4 reff272_inst.
Proof. unfold Equation1898. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff272_inst, reff272_op in H. discriminate H. Qed.

Lemma reff272_not1921 : ~ @Equation1921 Fin4 reff272_inst.
Proof. unfold Equation1921. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff272_inst, reff272_op in H. discriminate H. Qed.

Lemma reff272_not1922 : ~ @Equation1922 Fin4 reff272_inst.
Proof. unfold Equation1922. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff272_inst, reff272_op in H. discriminate H. Qed.

Lemma reff272_not1924 : ~ @Equation1924 Fin4 reff272_inst.
Proof. unfold Equation1924. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff272_inst, reff272_op in H. discriminate H. Qed.

Lemma reff272_not1925 : ~ @Equation1925 Fin4 reff272_inst.
Proof. unfold Equation1925. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff272_inst, reff272_op in H. discriminate H. Qed.

Lemma reff272_not1931 : ~ @Equation1931 Fin4 reff272_inst.
Proof. unfold Equation1931. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff272_inst, reff272_op in H. discriminate H. Qed.

Lemma reff272_not1932 : ~ @Equation1932 Fin4 reff272_inst.
Proof. unfold Equation1932. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff272_inst, reff272_op in H. discriminate H. Qed.

Lemma reff272_not1934 : ~ @Equation1934 Fin4 reff272_inst.
Proof. unfold Equation1934. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff272_inst, reff272_op in H. discriminate H. Qed.

Lemma reff272_not2035 : ~ @Equation2035 Fin4 reff272_inst.
Proof. unfold Equation2035. intro H. specialize (H F4_1). unfold magma_op, reff272_inst, reff272_op in H. discriminate H. Qed.

Lemma reff272_not2238 : ~ @Equation2238 Fin4 reff272_inst.
Proof. unfold Equation2238. intro H. specialize (H F4_1). unfold magma_op, reff272_inst, reff272_op in H. discriminate H. Qed.

Lemma reff272_not2441 : ~ @Equation2441 Fin4 reff272_inst.
Proof. unfold Equation2441. intro H. specialize (H F4_1). unfold magma_op, reff272_inst, reff272_op in H. discriminate H. Qed.

Lemma reff272_not2644 : ~ @Equation2644 Fin4 reff272_inst.
Proof. unfold Equation2644. intro H. specialize (H F4_1). unfold magma_op, reff272_inst, reff272_op in H. discriminate H. Qed.

Lemma reff272_not2847 : ~ @Equation2847 Fin4 reff272_inst.
Proof. unfold Equation2847. intro H. specialize (H F4_1). unfold magma_op, reff272_inst, reff272_op in H. discriminate H. Qed.

Lemma reff272_not3050 : ~ @Equation3050 Fin4 reff272_inst.
Proof. unfold Equation3050. intro H. specialize (H F4_1). unfold magma_op, reff272_inst, reff272_op in H. discriminate H. Qed.

Lemma reff272_not3254 : ~ @Equation3254 Fin4 reff272_inst.
Proof. unfold Equation3254. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff272_inst, reff272_op in H. discriminate H. Qed.

Lemma reff272_not3255 : ~ @Equation3255 Fin4 reff272_inst.
Proof. unfold Equation3255. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff272_inst, reff272_op in H. discriminate H. Qed.

Lemma reff272_not3258 : ~ @Equation3258 Fin4 reff272_inst.
Proof. unfold Equation3258. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff272_inst, reff272_op in H. discriminate H. Qed.

Lemma reff272_not3259 : ~ @Equation3259 Fin4 reff272_inst.
Proof. unfold Equation3259. intro H. specialize (H F4_0 F4_3). unfold magma_op, reff272_inst, reff272_op in H. discriminate H. Qed.

Lemma reff272_not3261 : ~ @Equation3261 Fin4 reff272_inst.
Proof. unfold Equation3261. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff272_inst, reff272_op in H. discriminate H. Qed.

Lemma reff272_not3262 : ~ @Equation3262 Fin4 reff272_inst.
Proof. unfold Equation3262. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff272_inst, reff272_op in H. discriminate H. Qed.

Lemma reff272_not3268 : ~ @Equation3268 Fin4 reff272_inst.
Proof. unfold Equation3268. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff272_inst, reff272_op in H. discriminate H. Qed.

Lemma reff272_not3269 : ~ @Equation3269 Fin4 reff272_inst.
Proof. unfold Equation3269. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff272_inst, reff272_op in H. discriminate H. Qed.

Lemma reff272_not3271 : ~ @Equation3271 Fin4 reff272_inst.
Proof. unfold Equation3271. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff272_inst, reff272_op in H. discriminate H. Qed.

Lemma reff272_not3272 : ~ @Equation3272 Fin4 reff272_inst.
Proof. unfold Equation3272. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff272_inst, reff272_op in H. discriminate H. Qed.

Lemma reff272_not3279 : ~ @Equation3279 Fin4 reff272_inst.
Proof. unfold Equation3279. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff272_inst, reff272_op in H. discriminate H. Qed.

Lemma reff272_not3281 : ~ @Equation3281 Fin4 reff272_inst.
Proof. unfold Equation3281. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff272_inst, reff272_op in H. discriminate H. Qed.

Lemma reff272_not3308 : ~ @Equation3308 Fin4 reff272_inst.
Proof. unfold Equation3308. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff272_inst, reff272_op in H. discriminate H. Qed.

Lemma reff272_not3309 : ~ @Equation3309 Fin4 reff272_inst.
Proof. unfold Equation3309. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff272_inst, reff272_op in H. discriminate H. Qed.

Lemma reff272_not3315 : ~ @Equation3315 Fin4 reff272_inst.
Proof. unfold Equation3315. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff272_inst, reff272_op in H. discriminate H. Qed.

Lemma reff272_not3316 : ~ @Equation3316 Fin4 reff272_inst.
Proof. unfold Equation3316. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff272_inst, reff272_op in H. discriminate H. Qed.

Lemma reff272_not3318 : ~ @Equation3318 Fin4 reff272_inst.
Proof. unfold Equation3318. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff272_inst, reff272_op in H. discriminate H. Qed.

Lemma reff272_not3319 : ~ @Equation3319 Fin4 reff272_inst.
Proof. unfold Equation3319. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff272_inst, reff272_op in H. discriminate H. Qed.

Lemma reff272_not3342 : ~ @Equation3342 Fin4 reff272_inst.
Proof. unfold Equation3342. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff272_inst, reff272_op in H. discriminate H. Qed.

Lemma reff272_not3343 : ~ @Equation3343 Fin4 reff272_inst.
Proof. unfold Equation3343. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff272_inst, reff272_op in H. discriminate H. Qed.

Lemma reff272_not3345 : ~ @Equation3345 Fin4 reff272_inst.
Proof. unfold Equation3345. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff272_inst, reff272_op in H. discriminate H. Qed.

Lemma reff272_not3346 : ~ @Equation3346 Fin4 reff272_inst.
Proof. unfold Equation3346. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff272_inst, reff272_op in H. discriminate H. Qed.

Lemma reff272_not3352 : ~ @Equation3352 Fin4 reff272_inst.
Proof. unfold Equation3352. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff272_inst, reff272_op in H. discriminate H. Qed.

Lemma reff272_not3353 : ~ @Equation3353 Fin4 reff272_inst.
Proof. unfold Equation3353. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff272_inst, reff272_op in H. discriminate H. Qed.

Lemma reff272_not3456 : ~ @Equation3456 Fin4 reff272_inst.
Proof. unfold Equation3456. intro H. specialize (H F4_1). unfold magma_op, reff272_inst, reff272_op in H. discriminate H. Qed.

Lemma reff272_not3660 : ~ @Equation3660 Fin4 reff272_inst.
Proof. unfold Equation3660. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff272_inst, reff272_op in H. discriminate H. Qed.

Lemma reff272_not3661 : ~ @Equation3661 Fin4 reff272_inst.
Proof. unfold Equation3661. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff272_inst, reff272_op in H. discriminate H. Qed.

Lemma reff272_not3664 : ~ @Equation3664 Fin4 reff272_inst.
Proof. unfold Equation3664. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff272_inst, reff272_op in H. discriminate H. Qed.

Lemma reff272_not3667 : ~ @Equation3667 Fin4 reff272_inst.
Proof. unfold Equation3667. intro H. specialize (H F4_0 F4_3). unfold magma_op, reff272_inst, reff272_op in H. discriminate H. Qed.

Lemma reff272_not3668 : ~ @Equation3668 Fin4 reff272_inst.
Proof. unfold Equation3668. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff272_inst, reff272_op in H. discriminate H. Qed.

Lemma reff272_not3674 : ~ @Equation3674 Fin4 reff272_inst.
Proof. unfold Equation3674. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff272_inst, reff272_op in H. discriminate H. Qed.

Lemma reff272_not3675 : ~ @Equation3675 Fin4 reff272_inst.
Proof. unfold Equation3675. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff272_inst, reff272_op in H. discriminate H. Qed.

Lemma reff272_not3678 : ~ @Equation3678 Fin4 reff272_inst.
Proof. unfold Equation3678. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff272_inst, reff272_op in H. discriminate H. Qed.

Lemma reff272_not3685 : ~ @Equation3685 Fin4 reff272_inst.
Proof. unfold Equation3685. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff272_inst, reff272_op in H. discriminate H. Qed.

Lemma reff272_not3687 : ~ @Equation3687 Fin4 reff272_inst.
Proof. unfold Equation3687. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff272_inst, reff272_op in H. discriminate H. Qed.

Lemma reff272_not3712 : ~ @Equation3712 Fin4 reff272_inst.
Proof. unfold Equation3712. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff272_inst, reff272_op in H. discriminate H. Qed.

Lemma reff272_not3714 : ~ @Equation3714 Fin4 reff272_inst.
Proof. unfold Equation3714. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff272_inst, reff272_op in H. discriminate H. Qed.

Lemma reff272_not3721 : ~ @Equation3721 Fin4 reff272_inst.
Proof. unfold Equation3721. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff272_inst, reff272_op in H. discriminate H. Qed.

Lemma reff272_not3722 : ~ @Equation3722 Fin4 reff272_inst.
Proof. unfold Equation3722. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff272_inst, reff272_op in H. discriminate H. Qed.

Lemma reff272_not3724 : ~ @Equation3724 Fin4 reff272_inst.
Proof. unfold Equation3724. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff272_inst, reff272_op in H. discriminate H. Qed.

Lemma reff272_not3725 : ~ @Equation3725 Fin4 reff272_inst.
Proof. unfold Equation3725. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff272_inst, reff272_op in H. discriminate H. Qed.

Lemma reff272_not3748 : ~ @Equation3748 Fin4 reff272_inst.
Proof. unfold Equation3748. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff272_inst, reff272_op in H. discriminate H. Qed.

Lemma reff272_not3749 : ~ @Equation3749 Fin4 reff272_inst.
Proof. unfold Equation3749. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff272_inst, reff272_op in H. discriminate H. Qed.

Lemma reff272_not3751 : ~ @Equation3751 Fin4 reff272_inst.
Proof. unfold Equation3751. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff272_inst, reff272_op in H. discriminate H. Qed.

Lemma reff272_not3752 : ~ @Equation3752 Fin4 reff272_inst.
Proof. unfold Equation3752. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff272_inst, reff272_op in H. discriminate H. Qed.

Lemma reff272_not3759 : ~ @Equation3759 Fin4 reff272_inst.
Proof. unfold Equation3759. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff272_inst, reff272_op in H. discriminate H. Qed.

Lemma reff272_not3761 : ~ @Equation3761 Fin4 reff272_inst.
Proof. unfold Equation3761. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff272_inst, reff272_op in H. discriminate H. Qed.

Lemma reff272_not3864 : ~ @Equation3864 Fin4 reff272_inst.
Proof. unfold Equation3864. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff272_inst, reff272_op in H. discriminate H. Qed.

Lemma reff272_not3865 : ~ @Equation3865 Fin4 reff272_inst.
Proof. unfold Equation3865. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff272_inst, reff272_op in H. discriminate H. Qed.

Lemma reff272_not3867 : ~ @Equation3867 Fin4 reff272_inst.
Proof. unfold Equation3867. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff272_inst, reff272_op in H. discriminate H. Qed.

Lemma reff272_not3868 : ~ @Equation3868 Fin4 reff272_inst.
Proof. unfold Equation3868. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff272_inst, reff272_op in H. discriminate H. Qed.

Lemma reff272_not3871 : ~ @Equation3871 Fin4 reff272_inst.
Proof. unfold Equation3871. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff272_inst, reff272_op in H. discriminate H. Qed.

Lemma reff272_not3877 : ~ @Equation3877 Fin4 reff272_inst.
Proof. unfold Equation3877. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff272_inst, reff272_op in H. discriminate H. Qed.

Lemma reff272_not3880 : ~ @Equation3880 Fin4 reff272_inst.
Proof. unfold Equation3880. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff272_inst, reff272_op in H. discriminate H. Qed.

Lemma reff272_not3881 : ~ @Equation3881 Fin4 reff272_inst.
Proof. unfold Equation3881. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff272_inst, reff272_op in H. discriminate H. Qed.

Lemma reff272_not3887 : ~ @Equation3887 Fin4 reff272_inst.
Proof. unfold Equation3887. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff272_inst, reff272_op in H. discriminate H. Qed.

Lemma reff272_not3888 : ~ @Equation3888 Fin4 reff272_inst.
Proof. unfold Equation3888. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff272_inst, reff272_op in H. discriminate H. Qed.

Lemma reff272_not3890 : ~ @Equation3890 Fin4 reff272_inst.
Proof. unfold Equation3890. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff272_inst, reff272_op in H. discriminate H. Qed.

Lemma reff272_not3915 : ~ @Equation3915 Fin4 reff272_inst.
Proof. unfold Equation3915. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff272_inst, reff272_op in H. discriminate H. Qed.

Lemma reff272_not3917 : ~ @Equation3917 Fin4 reff272_inst.
Proof. unfold Equation3917. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff272_inst, reff272_op in H. discriminate H. Qed.

Lemma reff272_not3918 : ~ @Equation3918 Fin4 reff272_inst.
Proof. unfold Equation3918. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff272_inst, reff272_op in H. discriminate H. Qed.

Lemma reff272_not3924 : ~ @Equation3924 Fin4 reff272_inst.
Proof. unfold Equation3924. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff272_inst, reff272_op in H. discriminate H. Qed.

Lemma reff272_not3925 : ~ @Equation3925 Fin4 reff272_inst.
Proof. unfold Equation3925. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff272_inst, reff272_op in H. discriminate H. Qed.

Lemma reff272_not3927 : ~ @Equation3927 Fin4 reff272_inst.
Proof. unfold Equation3927. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff272_inst, reff272_op in H. discriminate H. Qed.

Lemma reff272_not3928 : ~ @Equation3928 Fin4 reff272_inst.
Proof. unfold Equation3928. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff272_inst, reff272_op in H. discriminate H. Qed.

Lemma reff272_not3951 : ~ @Equation3951 Fin4 reff272_inst.
Proof. unfold Equation3951. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff272_inst, reff272_op in H. discriminate H. Qed.

Lemma reff272_not3952 : ~ @Equation3952 Fin4 reff272_inst.
Proof. unfold Equation3952. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff272_inst, reff272_op in H. discriminate H. Qed.

Lemma reff272_not3954 : ~ @Equation3954 Fin4 reff272_inst.
Proof. unfold Equation3954. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff272_inst, reff272_op in H. discriminate H. Qed.

Lemma reff272_not3955 : ~ @Equation3955 Fin4 reff272_inst.
Proof. unfold Equation3955. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff272_inst, reff272_op in H. discriminate H. Qed.

Lemma reff272_not3961 : ~ @Equation3961 Fin4 reff272_inst.
Proof. unfold Equation3961. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff272_inst, reff272_op in H. discriminate H. Qed.

Lemma reff272_not3962 : ~ @Equation3962 Fin4 reff272_inst.
Proof. unfold Equation3962. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff272_inst, reff272_op in H. discriminate H. Qed.

Lemma reff272_not3964 : ~ @Equation3964 Fin4 reff272_inst.
Proof. unfold Equation3964. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff272_inst, reff272_op in H. discriminate H. Qed.

Lemma reff272_not4065 : ~ @Equation4065 Fin4 reff272_inst.
Proof. unfold Equation4065. intro H. specialize (H F4_1). unfold magma_op, reff272_inst, reff272_op in H. discriminate H. Qed.

Lemma reff272_not4268 : ~ @Equation4268 Fin4 reff272_inst.
Proof. unfold Equation4268. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff272_inst, reff272_op in H. discriminate H. Qed.

Lemma reff272_not4269 : ~ @Equation4269 Fin4 reff272_inst.
Proof. unfold Equation4269. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff272_inst, reff272_op in H. discriminate H. Qed.

Lemma reff272_not4272 : ~ @Equation4272 Fin4 reff272_inst.
Proof. unfold Equation4272. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff272_inst, reff272_op in H. discriminate H. Qed.

Lemma reff272_not4273 : ~ @Equation4273 Fin4 reff272_inst.
Proof. unfold Equation4273. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff272_inst, reff272_op in H. discriminate H. Qed.

Lemma reff272_not4275 : ~ @Equation4275 Fin4 reff272_inst.
Proof. unfold Equation4275. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff272_inst, reff272_op in H. discriminate H. Qed.

Lemma reff272_not4276 : ~ @Equation4276 Fin4 reff272_inst.
Proof. unfold Equation4276. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff272_inst, reff272_op in H. discriminate H. Qed.

Lemma reff272_not4283 : ~ @Equation4283 Fin4 reff272_inst.
Proof. unfold Equation4283. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff272_inst, reff272_op in H. discriminate H. Qed.

Lemma reff272_not4284 : ~ @Equation4284 Fin4 reff272_inst.
Proof. unfold Equation4284. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff272_inst, reff272_op in H. discriminate H. Qed.

Lemma reff272_not4290 : ~ @Equation4290 Fin4 reff272_inst.
Proof. unfold Equation4290. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff272_inst, reff272_op in H. discriminate H. Qed.

Lemma reff272_not4291 : ~ @Equation4291 Fin4 reff272_inst.
Proof. unfold Equation4291. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff272_inst, reff272_op in H. discriminate H. Qed.

Lemma reff272_not4293 : ~ @Equation4293 Fin4 reff272_inst.
Proof. unfold Equation4293. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff272_inst, reff272_op in H. discriminate H. Qed.

Lemma reff272_not4314 : ~ @Equation4314 Fin4 reff272_inst.
Proof. unfold Equation4314. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff272_inst, reff272_op in H. discriminate H. Qed.

Lemma reff272_not4320 : ~ @Equation4320 Fin4 reff272_inst.
Proof. unfold Equation4320. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff272_inst, reff272_op in H. discriminate H. Qed.

Lemma reff272_not4321 : ~ @Equation4321 Fin4 reff272_inst.
Proof. unfold Equation4321. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff272_inst, reff272_op in H. discriminate H. Qed.

Lemma reff272_not4343 : ~ @Equation4343 Fin4 reff272_inst.
Proof. unfold Equation4343. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff272_inst, reff272_op in H. discriminate H. Qed.

Lemma reff272_not4380 : ~ @Equation4380 Fin4 reff272_inst.
Proof. unfold Equation4380. intro H. specialize (H F4_1). unfold magma_op, reff272_inst, reff272_op in H. discriminate H. Qed.

Lemma reff272_not4583 : ~ @Equation4583 Fin4 reff272_inst.
Proof. unfold Equation4583. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff272_inst, reff272_op in H. discriminate H. Qed.

Lemma reff272_not4584 : ~ @Equation4584 Fin4 reff272_inst.
Proof. unfold Equation4584. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff272_inst, reff272_op in H. discriminate H. Qed.

Lemma reff272_not4585 : ~ @Equation4585 Fin4 reff272_inst.
Proof. unfold Equation4585. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff272_inst, reff272_op in H. discriminate H. Qed.

Lemma reff272_not4587 : ~ @Equation4587 Fin4 reff272_inst.
Proof. unfold Equation4587. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff272_inst, reff272_op in H. discriminate H. Qed.

Lemma reff272_not4588 : ~ @Equation4588 Fin4 reff272_inst.
Proof. unfold Equation4588. intro H. specialize (H F4_1 F4_2). unfold magma_op, reff272_inst, reff272_op in H. discriminate H. Qed.

Lemma reff272_not4591 : ~ @Equation4591 Fin4 reff272_inst.
Proof. unfold Equation4591. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff272_inst, reff272_op in H. discriminate H. Qed.

Lemma reff272_not4598 : ~ @Equation4598 Fin4 reff272_inst.
Proof. unfold Equation4598. intro H. specialize (H F4_1 F4_2). unfold magma_op, reff272_inst, reff272_op in H. discriminate H. Qed.

Lemma reff272_not4599 : ~ @Equation4599 Fin4 reff272_inst.
Proof. unfold Equation4599. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff272_inst, reff272_op in H. discriminate H. Qed.

Lemma reff272_not4605 : ~ @Equation4605 Fin4 reff272_inst.
Proof. unfold Equation4605. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff272_inst, reff272_op in H. discriminate H. Qed.

Lemma reff272_not4606 : ~ @Equation4606 Fin4 reff272_inst.
Proof. unfold Equation4606. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff272_inst, reff272_op in H. discriminate H. Qed.

Lemma reff272_not4608 : ~ @Equation4608 Fin4 reff272_inst.
Proof. unfold Equation4608. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff272_inst, reff272_op in H. discriminate H. Qed.

Lemma reff272_not4629 : ~ @Equation4629 Fin4 reff272_inst.
Proof. unfold Equation4629. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff272_inst, reff272_op in H. discriminate H. Qed.

Lemma reff272_not4635 : ~ @Equation4635 Fin4 reff272_inst.
Proof. unfold Equation4635. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff272_inst, reff272_op in H. discriminate H. Qed.

Lemma reff272_not4636 : ~ @Equation4636 Fin4 reff272_inst.
Proof. unfold Equation4636. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff272_inst, reff272_op in H. discriminate H. Qed.

Lemma reff272_not4658 : ~ @Equation4658 Fin4 reff272_inst.
Proof. unfold Equation4658. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff272_inst, reff272_op in H. discriminate H. Qed.

(** ---- reff280 (Fin4) ---- *)

Definition reff280_op (x y : Fin4) : Fin4 :=
  match x, y with
  | F4_0, F4_0 => F4_0 | F4_0, F4_1 => F4_0 | F4_0, F4_2 => F4_2 | F4_0, F4_3 => F4_2
  | F4_1, F4_0 => F4_3 | F4_1, F4_1 => F4_1 | F4_1, F4_2 => F4_1 | F4_1, F4_3 => F4_3
  | F4_2, F4_0 => F4_0 | F4_2, F4_1 => F4_0 | F4_2, F4_2 => F4_2 | F4_2, F4_3 => F4_2
  | F4_3, F4_0 => F4_3 | F4_3, F4_1 => F4_1 | F4_3, F4_2 => F4_1 | F4_3, F4_3 => F4_3
  end.

#[local] Instance reff280_inst : Magma Fin4 := {| magma_op := reff280_op |}.

Lemma reff280_sat25 : @Equation25 Fin4 reff280_inst.
Proof. unfold Equation25, magma_op, reff280_inst, reff280_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff280_sat101 : @Equation101 Fin4 reff280_inst.
Proof. unfold Equation101, magma_op, reff280_inst, reff280_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff280_sat156 : @Equation156 Fin4 reff280_inst.
Proof. unfold Equation156, magma_op, reff280_inst, reff280_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff280_sat266 : @Equation266 Fin4 reff280_inst.
Proof. unfold Equation266, magma_op, reff280_inst, reff280_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff280_sat381 : @Equation381 Fin4 reff280_inst.
Proof. unfold Equation381, magma_op, reff280_inst, reff280_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff280_sat429 : @Equation429 Fin4 reff280_inst.
Proof. unfold Equation429, magma_op, reff280_inst, reff280_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff280_sat616 : @Equation616 Fin4 reff280_inst.
Proof. unfold Equation616, magma_op, reff280_inst, reff280_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff280_sat822 : @Equation822 Fin4 reff280_inst.
Proof. unfold Equation822, magma_op, reff280_inst, reff280_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff280_sat1234 : @Equation1234 Fin4 reff280_inst.
Proof. unfold Equation1234, magma_op, reff280_inst, reff280_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff280_sat1441 : @Equation1441 Fin4 reff280_inst.
Proof. unfold Equation1441, magma_op, reff280_inst, reff280_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff280_sat2070 : @Equation2070 Fin4 reff280_inst.
Proof. unfold Equation2070, magma_op, reff280_inst, reff280_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff280_sat3097 : @Equation3097 Fin4 reff280_inst.
Proof. unfold Equation3097, magma_op, reff280_inst, reff280_op. intros x y z w. destruct x, y, z, w; reflexivity. Qed.

Lemma reff280_sat3515 : @Equation3515 Fin4 reff280_inst.
Proof. unfold Equation3515, magma_op, reff280_inst, reff280_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff280_sat3732 : @Equation3732 Fin4 reff280_inst.
Proof. unfold Equation3732, magma_op, reff280_inst, reff280_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff280_sat3736 : @Equation3736 Fin4 reff280_inst.
Proof. unfold Equation3736, magma_op, reff280_inst, reff280_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff280_sat4402 : @Equation4402 Fin4 reff280_inst.
Proof. unfold Equation4402, magma_op, reff280_inst, reff280_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff280_sat4476 : @Equation4476 Fin4 reff280_inst.
Proof. unfold Equation4476, magma_op, reff280_inst, reff280_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff280_not50 : ~ @Equation50 Fin4 reff280_inst.
Proof. unfold Equation50. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff280_inst, reff280_op in H. discriminate H. Qed.

Lemma reff280_not53 : ~ @Equation53 Fin4 reff280_inst.
Proof. unfold Equation53. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff280_inst, reff280_op in H. discriminate H. Qed.

Lemma reff280_not55 : ~ @Equation55 Fin4 reff280_inst.
Proof. unfold Equation55. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff280_inst, reff280_op in H. discriminate H. Qed.

Lemma reff280_not56 : ~ @Equation56 Fin4 reff280_inst.
Proof. unfold Equation56. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff280_inst, reff280_op in H. discriminate H. Qed.

Lemma reff280_not63 : ~ @Equation63 Fin4 reff280_inst.
Proof. unfold Equation63. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff280_inst, reff280_op in H. discriminate H. Qed.

Lemma reff280_not65 : ~ @Equation65 Fin4 reff280_inst.
Proof. unfold Equation65. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff280_inst, reff280_op in H. discriminate H. Qed.

Lemma reff280_not66 : ~ @Equation66 Fin4 reff280_inst.
Proof. unfold Equation66. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff280_inst, reff280_op in H. discriminate H. Qed.

Lemma reff280_not72 : ~ @Equation72 Fin4 reff280_inst.
Proof. unfold Equation72. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff280_inst, reff280_op in H. discriminate H. Qed.

Lemma reff280_not73 : ~ @Equation73 Fin4 reff280_inst.
Proof. unfold Equation73. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff280_inst, reff280_op in H. discriminate H. Qed.

Lemma reff280_not75 : ~ @Equation75 Fin4 reff280_inst.
Proof. unfold Equation75. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff280_inst, reff280_op in H. discriminate H. Qed.

Lemma reff280_not102 : ~ @Equation102 Fin4 reff280_inst.
Proof. unfold Equation102. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff280_inst, reff280_op in H. discriminate H. Qed.

Lemma reff280_not105 : ~ @Equation105 Fin4 reff280_inst.
Proof. unfold Equation105. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff280_inst, reff280_op in H. discriminate H. Qed.

Lemma reff280_not107 : ~ @Equation107 Fin4 reff280_inst.
Proof. unfold Equation107. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff280_inst, reff280_op in H. discriminate H. Qed.

Lemma reff280_not108 : ~ @Equation108 Fin4 reff280_inst.
Proof. unfold Equation108. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff280_inst, reff280_op in H. discriminate H. Qed.

Lemma reff280_not115 : ~ @Equation115 Fin4 reff280_inst.
Proof. unfold Equation115. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff280_inst, reff280_op in H. discriminate H. Qed.

Lemma reff280_not117 : ~ @Equation117 Fin4 reff280_inst.
Proof. unfold Equation117. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff280_inst, reff280_op in H. discriminate H. Qed.

Lemma reff280_not118 : ~ @Equation118 Fin4 reff280_inst.
Proof. unfold Equation118. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff280_inst, reff280_op in H. discriminate H. Qed.

Lemma reff280_not124 : ~ @Equation124 Fin4 reff280_inst.
Proof. unfold Equation124. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff280_inst, reff280_op in H. discriminate H. Qed.

Lemma reff280_not125 : ~ @Equation125 Fin4 reff280_inst.
Proof. unfold Equation125. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff280_inst, reff280_op in H. discriminate H. Qed.

Lemma reff280_not127 : ~ @Equation127 Fin4 reff280_inst.
Proof. unfold Equation127. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff280_inst, reff280_op in H. discriminate H. Qed.

Lemma reff280_not154 : ~ @Equation154 Fin4 reff280_inst.
Proof. unfold Equation154. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff280_inst, reff280_op in H. discriminate H. Qed.

Lemma reff280_not157 : ~ @Equation157 Fin4 reff280_inst.
Proof. unfold Equation157. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff280_inst, reff280_op in H. discriminate H. Qed.

Lemma reff280_not159 : ~ @Equation159 Fin4 reff280_inst.
Proof. unfold Equation159. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff280_inst, reff280_op in H. discriminate H. Qed.

Lemma reff280_not160 : ~ @Equation160 Fin4 reff280_inst.
Proof. unfold Equation160. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff280_inst, reff280_op in H. discriminate H. Qed.

Lemma reff280_not167 : ~ @Equation167 Fin4 reff280_inst.
Proof. unfold Equation167. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff280_inst, reff280_op in H. discriminate H. Qed.

Lemma reff280_not169 : ~ @Equation169 Fin4 reff280_inst.
Proof. unfold Equation169. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff280_inst, reff280_op in H. discriminate H. Qed.

Lemma reff280_not170 : ~ @Equation170 Fin4 reff280_inst.
Proof. unfold Equation170. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff280_inst, reff280_op in H. discriminate H. Qed.

Lemma reff280_not176 : ~ @Equation176 Fin4 reff280_inst.
Proof. unfold Equation176. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff280_inst, reff280_op in H. discriminate H. Qed.

Lemma reff280_not177 : ~ @Equation177 Fin4 reff280_inst.
Proof. unfold Equation177. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff280_inst, reff280_op in H. discriminate H. Qed.

Lemma reff280_not179 : ~ @Equation179 Fin4 reff280_inst.
Proof. unfold Equation179. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff280_inst, reff280_op in H. discriminate H. Qed.

Lemma reff280_not206 : ~ @Equation206 Fin4 reff280_inst.
Proof. unfold Equation206. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff280_inst, reff280_op in H. discriminate H. Qed.

Lemma reff280_not209 : ~ @Equation209 Fin4 reff280_inst.
Proof. unfold Equation209. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff280_inst, reff280_op in H. discriminate H. Qed.

Lemma reff280_not212 : ~ @Equation212 Fin4 reff280_inst.
Proof. unfold Equation212. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff280_inst, reff280_op in H. discriminate H. Qed.

Lemma reff280_not219 : ~ @Equation219 Fin4 reff280_inst.
Proof. unfold Equation219. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff280_inst, reff280_op in H. discriminate H. Qed.

Lemma reff280_not221 : ~ @Equation221 Fin4 reff280_inst.
Proof. unfold Equation221. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff280_inst, reff280_op in H. discriminate H. Qed.

Lemma reff280_not222 : ~ @Equation222 Fin4 reff280_inst.
Proof. unfold Equation222. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff280_inst, reff280_op in H. discriminate H. Qed.

Lemma reff280_not228 : ~ @Equation228 Fin4 reff280_inst.
Proof. unfold Equation228. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff280_inst, reff280_op in H. discriminate H. Qed.

Lemma reff280_not229 : ~ @Equation229 Fin4 reff280_inst.
Proof. unfold Equation229. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff280_inst, reff280_op in H. discriminate H. Qed.

Lemma reff280_not231 : ~ @Equation231 Fin4 reff280_inst.
Proof. unfold Equation231. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff280_inst, reff280_op in H. discriminate H. Qed.

Lemma reff280_not258 : ~ @Equation258 Fin4 reff280_inst.
Proof. unfold Equation258. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff280_inst, reff280_op in H. discriminate H. Qed.

Lemma reff280_not261 : ~ @Equation261 Fin4 reff280_inst.
Proof. unfold Equation261. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff280_inst, reff280_op in H. discriminate H. Qed.

Lemma reff280_not264 : ~ @Equation264 Fin4 reff280_inst.
Proof. unfold Equation264. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff280_inst, reff280_op in H. discriminate H. Qed.

Lemma reff280_not271 : ~ @Equation271 Fin4 reff280_inst.
Proof. unfold Equation271. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff280_inst, reff280_op in H. discriminate H. Qed.

Lemma reff280_not273 : ~ @Equation273 Fin4 reff280_inst.
Proof. unfold Equation273. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff280_inst, reff280_op in H. discriminate H. Qed.

Lemma reff280_not274 : ~ @Equation274 Fin4 reff280_inst.
Proof. unfold Equation274. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff280_inst, reff280_op in H. discriminate H. Qed.

Lemma reff280_not280 : ~ @Equation280 Fin4 reff280_inst.
Proof. unfold Equation280. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff280_inst, reff280_op in H. discriminate H. Qed.

Lemma reff280_not281 : ~ @Equation281 Fin4 reff280_inst.
Proof. unfold Equation281. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff280_inst, reff280_op in H. discriminate H. Qed.

Lemma reff280_not283 : ~ @Equation283 Fin4 reff280_inst.
Proof. unfold Equation283. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff280_inst, reff280_op in H. discriminate H. Qed.

Lemma reff280_not412 : ~ @Equation412 Fin4 reff280_inst.
Proof. unfold Equation412. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff280_inst, reff280_op in H. discriminate H. Qed.

Lemma reff280_not413 : ~ @Equation413 Fin4 reff280_inst.
Proof. unfold Equation413. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff280_inst, reff280_op in H. discriminate H. Qed.

Lemma reff280_not414 : ~ @Equation414 Fin4 reff280_inst.
Proof. unfold Equation414. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff280_inst, reff280_op in H. discriminate H. Qed.

Lemma reff280_not416 : ~ @Equation416 Fin4 reff280_inst.
Proof. unfold Equation416. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff280_inst, reff280_op in H. discriminate H. Qed.

Lemma reff280_not417 : ~ @Equation417 Fin4 reff280_inst.
Proof. unfold Equation417. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff280_inst, reff280_op in H. discriminate H. Qed.

Lemma reff280_not419 : ~ @Equation419 Fin4 reff280_inst.
Proof. unfold Equation419. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff280_inst, reff280_op in H. discriminate H. Qed.

Lemma reff280_not420 : ~ @Equation420 Fin4 reff280_inst.
Proof. unfold Equation420. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff280_inst, reff280_op in H. discriminate H. Qed.

Lemma reff280_not426 : ~ @Equation426 Fin4 reff280_inst.
Proof. unfold Equation426. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff280_inst, reff280_op in H. discriminate H. Qed.

Lemma reff280_not427 : ~ @Equation427 Fin4 reff280_inst.
Proof. unfold Equation427. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff280_inst, reff280_op in H. discriminate H. Qed.

Lemma reff280_not430 : ~ @Equation430 Fin4 reff280_inst.
Proof. unfold Equation430. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff280_inst, reff280_op in H. discriminate H. Qed.

Lemma reff280_not436 : ~ @Equation436 Fin4 reff280_inst.
Proof. unfold Equation436. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff280_inst, reff280_op in H. discriminate H. Qed.

Lemma reff280_not437 : ~ @Equation437 Fin4 reff280_inst.
Proof. unfold Equation437. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff280_inst, reff280_op in H. discriminate H. Qed.

Lemma reff280_not439 : ~ @Equation439 Fin4 reff280_inst.
Proof. unfold Equation439. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff280_inst, reff280_op in H. discriminate H. Qed.

Lemma reff280_not440 : ~ @Equation440 Fin4 reff280_inst.
Proof. unfold Equation440. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff280_inst, reff280_op in H. discriminate H. Qed.

Lemma reff280_not463 : ~ @Equation463 Fin4 reff280_inst.
Proof. unfold Equation463. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff280_inst, reff280_op in H. discriminate H. Qed.

Lemma reff280_not464 : ~ @Equation464 Fin4 reff280_inst.
Proof. unfold Equation464. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff280_inst, reff280_op in H. discriminate H. Qed.

Lemma reff280_not466 : ~ @Equation466 Fin4 reff280_inst.
Proof. unfold Equation466. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff280_inst, reff280_op in H. discriminate H. Qed.

Lemma reff280_not467 : ~ @Equation467 Fin4 reff280_inst.
Proof. unfold Equation467. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff280_inst, reff280_op in H. discriminate H. Qed.

Lemma reff280_not473 : ~ @Equation473 Fin4 reff280_inst.
Proof. unfold Equation473. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff280_inst, reff280_op in H. discriminate H. Qed.

Lemma reff280_not474 : ~ @Equation474 Fin4 reff280_inst.
Proof. unfold Equation474. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff280_inst, reff280_op in H. discriminate H. Qed.

Lemma reff280_not476 : ~ @Equation476 Fin4 reff280_inst.
Proof. unfold Equation476. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff280_inst, reff280_op in H. discriminate H. Qed.

Lemma reff280_not477 : ~ @Equation477 Fin4 reff280_inst.
Proof. unfold Equation477. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff280_inst, reff280_op in H. discriminate H. Qed.

Lemma reff280_not500 : ~ @Equation500 Fin4 reff280_inst.
Proof. unfold Equation500. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff280_inst, reff280_op in H. discriminate H. Qed.

Lemma reff280_not501 : ~ @Equation501 Fin4 reff280_inst.
Proof. unfold Equation501. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff280_inst, reff280_op in H. discriminate H. Qed.

Lemma reff280_not503 : ~ @Equation503 Fin4 reff280_inst.
Proof. unfold Equation503. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff280_inst, reff280_op in H. discriminate H. Qed.

Lemma reff280_not504 : ~ @Equation504 Fin4 reff280_inst.
Proof. unfold Equation504. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff280_inst, reff280_op in H. discriminate H. Qed.

Lemma reff280_not510 : ~ @Equation510 Fin4 reff280_inst.
Proof. unfold Equation510. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff280_inst, reff280_op in H. discriminate H. Qed.

Lemma reff280_not511 : ~ @Equation511 Fin4 reff280_inst.
Proof. unfold Equation511. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff280_inst, reff280_op in H. discriminate H. Qed.

Lemma reff280_not513 : ~ @Equation513 Fin4 reff280_inst.
Proof. unfold Equation513. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff280_inst, reff280_op in H. discriminate H. Qed.

Lemma reff280_not615 : ~ @Equation615 Fin4 reff280_inst.
Proof. unfold Equation615. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff280_inst, reff280_op in H. discriminate H. Qed.

Lemma reff280_not617 : ~ @Equation617 Fin4 reff280_inst.
Proof. unfold Equation617. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff280_inst, reff280_op in H. discriminate H. Qed.

Lemma reff280_not619 : ~ @Equation619 Fin4 reff280_inst.
Proof. unfold Equation619. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff280_inst, reff280_op in H. discriminate H. Qed.

Lemma reff280_not620 : ~ @Equation620 Fin4 reff280_inst.
Proof. unfold Equation620. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff280_inst, reff280_op in H. discriminate H. Qed.

Lemma reff280_not622 : ~ @Equation622 Fin4 reff280_inst.
Proof. unfold Equation622. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff280_inst, reff280_op in H. discriminate H. Qed.

Lemma reff280_not623 : ~ @Equation623 Fin4 reff280_inst.
Proof. unfold Equation623. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff280_inst, reff280_op in H. discriminate H. Qed.

Lemma reff280_not629 : ~ @Equation629 Fin4 reff280_inst.
Proof. unfold Equation629. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff280_inst, reff280_op in H. discriminate H. Qed.

Lemma reff280_not630 : ~ @Equation630 Fin4 reff280_inst.
Proof. unfold Equation630. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff280_inst, reff280_op in H. discriminate H. Qed.

Lemma reff280_not632 : ~ @Equation632 Fin4 reff280_inst.
Proof. unfold Equation632. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff280_inst, reff280_op in H. discriminate H. Qed.

Lemma reff280_not633 : ~ @Equation633 Fin4 reff280_inst.
Proof. unfold Equation633. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff280_inst, reff280_op in H. discriminate H. Qed.

Lemma reff280_not639 : ~ @Equation639 Fin4 reff280_inst.
Proof. unfold Equation639. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff280_inst, reff280_op in H. discriminate H. Qed.

Lemma reff280_not640 : ~ @Equation640 Fin4 reff280_inst.
Proof. unfold Equation640. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff280_inst, reff280_op in H. discriminate H. Qed.

Lemma reff280_not642 : ~ @Equation642 Fin4 reff280_inst.
Proof. unfold Equation642. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff280_inst, reff280_op in H. discriminate H. Qed.

Lemma reff280_not643 : ~ @Equation643 Fin4 reff280_inst.
Proof. unfold Equation643. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff280_inst, reff280_op in H. discriminate H. Qed.

Lemma reff280_not666 : ~ @Equation666 Fin4 reff280_inst.
Proof. unfold Equation666. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff280_inst, reff280_op in H. discriminate H. Qed.

Lemma reff280_not667 : ~ @Equation667 Fin4 reff280_inst.
Proof. unfold Equation667. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff280_inst, reff280_op in H. discriminate H. Qed.

Lemma reff280_not669 : ~ @Equation669 Fin4 reff280_inst.
Proof. unfold Equation669. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff280_inst, reff280_op in H. discriminate H. Qed.

Lemma reff280_not670 : ~ @Equation670 Fin4 reff280_inst.
Proof. unfold Equation670. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff280_inst, reff280_op in H. discriminate H. Qed.

Lemma reff280_not676 : ~ @Equation676 Fin4 reff280_inst.
Proof. unfold Equation676. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff280_inst, reff280_op in H. discriminate H. Qed.

Lemma reff280_not677 : ~ @Equation677 Fin4 reff280_inst.
Proof. unfold Equation677. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff280_inst, reff280_op in H. discriminate H. Qed.

Lemma reff280_not679 : ~ @Equation679 Fin4 reff280_inst.
Proof. unfold Equation679. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff280_inst, reff280_op in H. discriminate H. Qed.

Lemma reff280_not680 : ~ @Equation680 Fin4 reff280_inst.
Proof. unfold Equation680. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff280_inst, reff280_op in H. discriminate H. Qed.

Lemma reff280_not703 : ~ @Equation703 Fin4 reff280_inst.
Proof. unfold Equation703. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff280_inst, reff280_op in H. discriminate H. Qed.

Lemma reff280_not704 : ~ @Equation704 Fin4 reff280_inst.
Proof. unfold Equation704. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff280_inst, reff280_op in H. discriminate H. Qed.

Lemma reff280_not706 : ~ @Equation706 Fin4 reff280_inst.
Proof. unfold Equation706. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff280_inst, reff280_op in H. discriminate H. Qed.

Lemma reff280_not707 : ~ @Equation707 Fin4 reff280_inst.
Proof. unfold Equation707. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff280_inst, reff280_op in H. discriminate H. Qed.

Lemma reff280_not713 : ~ @Equation713 Fin4 reff280_inst.
Proof. unfold Equation713. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff280_inst, reff280_op in H. discriminate H. Qed.

Lemma reff280_not714 : ~ @Equation714 Fin4 reff280_inst.
Proof. unfold Equation714. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff280_inst, reff280_op in H. discriminate H. Qed.

Lemma reff280_not716 : ~ @Equation716 Fin4 reff280_inst.
Proof. unfold Equation716. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff280_inst, reff280_op in H. discriminate H. Qed.

Lemma reff280_not818 : ~ @Equation818 Fin4 reff280_inst.
Proof. unfold Equation818. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff280_inst, reff280_op in H. discriminate H. Qed.

Lemma reff280_not819 : ~ @Equation819 Fin4 reff280_inst.
Proof. unfold Equation819. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff280_inst, reff280_op in H. discriminate H. Qed.

Lemma reff280_not820 : ~ @Equation820 Fin4 reff280_inst.
Proof. unfold Equation820. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff280_inst, reff280_op in H. discriminate H. Qed.

Lemma reff280_not823 : ~ @Equation823 Fin4 reff280_inst.
Proof. unfold Equation823. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff280_inst, reff280_op in H. discriminate H. Qed.

Lemma reff280_not825 : ~ @Equation825 Fin4 reff280_inst.
Proof. unfold Equation825. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff280_inst, reff280_op in H. discriminate H. Qed.

Lemma reff280_not826 : ~ @Equation826 Fin4 reff280_inst.
Proof. unfold Equation826. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff280_inst, reff280_op in H. discriminate H. Qed.

Lemma reff280_not832 : ~ @Equation832 Fin4 reff280_inst.
Proof. unfold Equation832. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff280_inst, reff280_op in H. discriminate H. Qed.

Lemma reff280_not833 : ~ @Equation833 Fin4 reff280_inst.
Proof. unfold Equation833. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff280_inst, reff280_op in H. discriminate H. Qed.

Lemma reff280_not835 : ~ @Equation835 Fin4 reff280_inst.
Proof. unfold Equation835. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff280_inst, reff280_op in H. discriminate H. Qed.

Lemma reff280_not836 : ~ @Equation836 Fin4 reff280_inst.
Proof. unfold Equation836. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff280_inst, reff280_op in H. discriminate H. Qed.

Lemma reff280_not842 : ~ @Equation842 Fin4 reff280_inst.
Proof. unfold Equation842. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff280_inst, reff280_op in H. discriminate H. Qed.

Lemma reff280_not843 : ~ @Equation843 Fin4 reff280_inst.
Proof. unfold Equation843. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff280_inst, reff280_op in H. discriminate H. Qed.

Lemma reff280_not845 : ~ @Equation845 Fin4 reff280_inst.
Proof. unfold Equation845. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff280_inst, reff280_op in H. discriminate H. Qed.

Lemma reff280_not846 : ~ @Equation846 Fin4 reff280_inst.
Proof. unfold Equation846. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff280_inst, reff280_op in H. discriminate H. Qed.

Lemma reff280_not869 : ~ @Equation869 Fin4 reff280_inst.
Proof. unfold Equation869. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff280_inst, reff280_op in H. discriminate H. Qed.

Lemma reff280_not870 : ~ @Equation870 Fin4 reff280_inst.
Proof. unfold Equation870. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff280_inst, reff280_op in H. discriminate H. Qed.

Lemma reff280_not872 : ~ @Equation872 Fin4 reff280_inst.
Proof. unfold Equation872. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff280_inst, reff280_op in H. discriminate H. Qed.

Lemma reff280_not873 : ~ @Equation873 Fin4 reff280_inst.
Proof. unfold Equation873. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff280_inst, reff280_op in H. discriminate H. Qed.

Lemma reff280_not879 : ~ @Equation879 Fin4 reff280_inst.
Proof. unfold Equation879. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff280_inst, reff280_op in H. discriminate H. Qed.

Lemma reff280_not880 : ~ @Equation880 Fin4 reff280_inst.
Proof. unfold Equation880. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff280_inst, reff280_op in H. discriminate H. Qed.

Lemma reff280_not882 : ~ @Equation882 Fin4 reff280_inst.
Proof. unfold Equation882. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff280_inst, reff280_op in H. discriminate H. Qed.

Lemma reff280_not883 : ~ @Equation883 Fin4 reff280_inst.
Proof. unfold Equation883. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff280_inst, reff280_op in H. discriminate H. Qed.

Lemma reff280_not906 : ~ @Equation906 Fin4 reff280_inst.
Proof. unfold Equation906. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff280_inst, reff280_op in H. discriminate H. Qed.

Lemma reff280_not907 : ~ @Equation907 Fin4 reff280_inst.
Proof. unfold Equation907. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff280_inst, reff280_op in H. discriminate H. Qed.

Lemma reff280_not909 : ~ @Equation909 Fin4 reff280_inst.
Proof. unfold Equation909. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff280_inst, reff280_op in H. discriminate H. Qed.

Lemma reff280_not910 : ~ @Equation910 Fin4 reff280_inst.
Proof. unfold Equation910. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff280_inst, reff280_op in H. discriminate H. Qed.

Lemma reff280_not916 : ~ @Equation916 Fin4 reff280_inst.
Proof. unfold Equation916. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff280_inst, reff280_op in H. discriminate H. Qed.

Lemma reff280_not917 : ~ @Equation917 Fin4 reff280_inst.
Proof. unfold Equation917. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff280_inst, reff280_op in H. discriminate H. Qed.

Lemma reff280_not919 : ~ @Equation919 Fin4 reff280_inst.
Proof. unfold Equation919. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff280_inst, reff280_op in H. discriminate H. Qed.

Lemma reff280_not1021 : ~ @Equation1021 Fin4 reff280_inst.
Proof. unfold Equation1021. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff280_inst, reff280_op in H. discriminate H. Qed.

Lemma reff280_not1023 : ~ @Equation1023 Fin4 reff280_inst.
Proof. unfold Equation1023. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff280_inst, reff280_op in H. discriminate H. Qed.

Lemma reff280_not1026 : ~ @Equation1026 Fin4 reff280_inst.
Proof. unfold Equation1026. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff280_inst, reff280_op in H. discriminate H. Qed.

Lemma reff280_not1029 : ~ @Equation1029 Fin4 reff280_inst.
Proof. unfold Equation1029. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff280_inst, reff280_op in H. discriminate H. Qed.

Lemma reff280_not1035 : ~ @Equation1035 Fin4 reff280_inst.
Proof. unfold Equation1035. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff280_inst, reff280_op in H. discriminate H. Qed.

Lemma reff280_not1036 : ~ @Equation1036 Fin4 reff280_inst.
Proof. unfold Equation1036. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff280_inst, reff280_op in H. discriminate H. Qed.

Lemma reff280_not1038 : ~ @Equation1038 Fin4 reff280_inst.
Proof. unfold Equation1038. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff280_inst, reff280_op in H. discriminate H. Qed.

Lemma reff280_not1039 : ~ @Equation1039 Fin4 reff280_inst.
Proof. unfold Equation1039. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff280_inst, reff280_op in H. discriminate H. Qed.

Lemma reff280_not1045 : ~ @Equation1045 Fin4 reff280_inst.
Proof. unfold Equation1045. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff280_inst, reff280_op in H. discriminate H. Qed.

Lemma reff280_not1046 : ~ @Equation1046 Fin4 reff280_inst.
Proof. unfold Equation1046. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff280_inst, reff280_op in H. discriminate H. Qed.

Lemma reff280_not1048 : ~ @Equation1048 Fin4 reff280_inst.
Proof. unfold Equation1048. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff280_inst, reff280_op in H. discriminate H. Qed.

Lemma reff280_not1049 : ~ @Equation1049 Fin4 reff280_inst.
Proof. unfold Equation1049. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff280_inst, reff280_op in H. discriminate H. Qed.

Lemma reff280_not1072 : ~ @Equation1072 Fin4 reff280_inst.
Proof. unfold Equation1072. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff280_inst, reff280_op in H. discriminate H. Qed.

Lemma reff280_not1073 : ~ @Equation1073 Fin4 reff280_inst.
Proof. unfold Equation1073. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff280_inst, reff280_op in H. discriminate H. Qed.

Lemma reff280_not1075 : ~ @Equation1075 Fin4 reff280_inst.
Proof. unfold Equation1075. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff280_inst, reff280_op in H. discriminate H. Qed.

Lemma reff280_not1076 : ~ @Equation1076 Fin4 reff280_inst.
Proof. unfold Equation1076. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff280_inst, reff280_op in H. discriminate H. Qed.

Lemma reff280_not1082 : ~ @Equation1082 Fin4 reff280_inst.
Proof. unfold Equation1082. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff280_inst, reff280_op in H. discriminate H. Qed.

Lemma reff280_not1083 : ~ @Equation1083 Fin4 reff280_inst.
Proof. unfold Equation1083. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff280_inst, reff280_op in H. discriminate H. Qed.

Lemma reff280_not1085 : ~ @Equation1085 Fin4 reff280_inst.
Proof. unfold Equation1085. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff280_inst, reff280_op in H. discriminate H. Qed.

Lemma reff280_not1086 : ~ @Equation1086 Fin4 reff280_inst.
Proof. unfold Equation1086. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff280_inst, reff280_op in H. discriminate H. Qed.

Lemma reff280_not1109 : ~ @Equation1109 Fin4 reff280_inst.
Proof. unfold Equation1109. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff280_inst, reff280_op in H. discriminate H. Qed.

Lemma reff280_not1110 : ~ @Equation1110 Fin4 reff280_inst.
Proof. unfold Equation1110. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff280_inst, reff280_op in H. discriminate H. Qed.

Lemma reff280_not1112 : ~ @Equation1112 Fin4 reff280_inst.
Proof. unfold Equation1112. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff280_inst, reff280_op in H. discriminate H. Qed.

Lemma reff280_not1113 : ~ @Equation1113 Fin4 reff280_inst.
Proof. unfold Equation1113. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff280_inst, reff280_op in H. discriminate H. Qed.

Lemma reff280_not1119 : ~ @Equation1119 Fin4 reff280_inst.
Proof. unfold Equation1119. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff280_inst, reff280_op in H. discriminate H. Qed.

Lemma reff280_not1120 : ~ @Equation1120 Fin4 reff280_inst.
Proof. unfold Equation1120. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff280_inst, reff280_op in H. discriminate H. Qed.

Lemma reff280_not1122 : ~ @Equation1122 Fin4 reff280_inst.
Proof. unfold Equation1122. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff280_inst, reff280_op in H. discriminate H. Qed.

Lemma reff280_not1224 : ~ @Equation1224 Fin4 reff280_inst.
Proof. unfold Equation1224. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff280_inst, reff280_op in H. discriminate H. Qed.

Lemma reff280_not1226 : ~ @Equation1226 Fin4 reff280_inst.
Proof. unfold Equation1226. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff280_inst, reff280_op in H. discriminate H. Qed.

Lemma reff280_not1229 : ~ @Equation1229 Fin4 reff280_inst.
Proof. unfold Equation1229. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff280_inst, reff280_op in H. discriminate H. Qed.

Lemma reff280_not1232 : ~ @Equation1232 Fin4 reff280_inst.
Proof. unfold Equation1232. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff280_inst, reff280_op in H. discriminate H. Qed.

Lemma reff280_not1238 : ~ @Equation1238 Fin4 reff280_inst.
Proof. unfold Equation1238. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff280_inst, reff280_op in H. discriminate H. Qed.

Lemma reff280_not1239 : ~ @Equation1239 Fin4 reff280_inst.
Proof. unfold Equation1239. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff280_inst, reff280_op in H. discriminate H. Qed.

Lemma reff280_not1241 : ~ @Equation1241 Fin4 reff280_inst.
Proof. unfold Equation1241. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff280_inst, reff280_op in H. discriminate H. Qed.

Lemma reff280_not1242 : ~ @Equation1242 Fin4 reff280_inst.
Proof. unfold Equation1242. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff280_inst, reff280_op in H. discriminate H. Qed.

Lemma reff280_not1248 : ~ @Equation1248 Fin4 reff280_inst.
Proof. unfold Equation1248. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff280_inst, reff280_op in H. discriminate H. Qed.

Lemma reff280_not1249 : ~ @Equation1249 Fin4 reff280_inst.
Proof. unfold Equation1249. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff280_inst, reff280_op in H. discriminate H. Qed.

Lemma reff280_not1251 : ~ @Equation1251 Fin4 reff280_inst.
Proof. unfold Equation1251. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff280_inst, reff280_op in H. discriminate H. Qed.

Lemma reff280_not1252 : ~ @Equation1252 Fin4 reff280_inst.
Proof. unfold Equation1252. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff280_inst, reff280_op in H. discriminate H. Qed.

Lemma reff280_not1275 : ~ @Equation1275 Fin4 reff280_inst.
Proof. unfold Equation1275. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff280_inst, reff280_op in H. discriminate H. Qed.

Lemma reff280_not1276 : ~ @Equation1276 Fin4 reff280_inst.
Proof. unfold Equation1276. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff280_inst, reff280_op in H. discriminate H. Qed.

Lemma reff280_not1278 : ~ @Equation1278 Fin4 reff280_inst.
Proof. unfold Equation1278. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff280_inst, reff280_op in H. discriminate H. Qed.

Lemma reff280_not1279 : ~ @Equation1279 Fin4 reff280_inst.
Proof. unfold Equation1279. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff280_inst, reff280_op in H. discriminate H. Qed.

Lemma reff280_not1285 : ~ @Equation1285 Fin4 reff280_inst.
Proof. unfold Equation1285. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff280_inst, reff280_op in H. discriminate H. Qed.

Lemma reff280_not1286 : ~ @Equation1286 Fin4 reff280_inst.
Proof. unfold Equation1286. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff280_inst, reff280_op in H. discriminate H. Qed.

Lemma reff280_not1288 : ~ @Equation1288 Fin4 reff280_inst.
Proof. unfold Equation1288. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff280_inst, reff280_op in H. discriminate H. Qed.

Lemma reff280_not1289 : ~ @Equation1289 Fin4 reff280_inst.
Proof. unfold Equation1289. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff280_inst, reff280_op in H. discriminate H. Qed.

Lemma reff280_not1312 : ~ @Equation1312 Fin4 reff280_inst.
Proof. unfold Equation1312. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff280_inst, reff280_op in H. discriminate H. Qed.

Lemma reff280_not1313 : ~ @Equation1313 Fin4 reff280_inst.
Proof. unfold Equation1313. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff280_inst, reff280_op in H. discriminate H. Qed.

Lemma reff280_not1315 : ~ @Equation1315 Fin4 reff280_inst.
Proof. unfold Equation1315. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff280_inst, reff280_op in H. discriminate H. Qed.

Lemma reff280_not1316 : ~ @Equation1316 Fin4 reff280_inst.
Proof. unfold Equation1316. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff280_inst, reff280_op in H. discriminate H. Qed.

Lemma reff280_not1322 : ~ @Equation1322 Fin4 reff280_inst.
Proof. unfold Equation1322. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff280_inst, reff280_op in H. discriminate H. Qed.

Lemma reff280_not1323 : ~ @Equation1323 Fin4 reff280_inst.
Proof. unfold Equation1323. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff280_inst, reff280_op in H. discriminate H. Qed.

Lemma reff280_not1325 : ~ @Equation1325 Fin4 reff280_inst.
Proof. unfold Equation1325. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff280_inst, reff280_op in H. discriminate H. Qed.

Lemma reff280_not1427 : ~ @Equation1427 Fin4 reff280_inst.
Proof. unfold Equation1427. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff280_inst, reff280_op in H. discriminate H. Qed.

Lemma reff280_not1428 : ~ @Equation1428 Fin4 reff280_inst.
Proof. unfold Equation1428. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff280_inst, reff280_op in H. discriminate H. Qed.

Lemma reff280_not1429 : ~ @Equation1429 Fin4 reff280_inst.
Proof. unfold Equation1429. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff280_inst, reff280_op in H. discriminate H. Qed.

Lemma reff280_not1431 : ~ @Equation1431 Fin4 reff280_inst.
Proof. unfold Equation1431. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff280_inst, reff280_op in H. discriminate H. Qed.

Lemma reff280_not1432 : ~ @Equation1432 Fin4 reff280_inst.
Proof. unfold Equation1432. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff280_inst, reff280_op in H. discriminate H. Qed.

Lemma reff280_not1434 : ~ @Equation1434 Fin4 reff280_inst.
Proof. unfold Equation1434. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff280_inst, reff280_op in H. discriminate H. Qed.

Lemma reff280_not1435 : ~ @Equation1435 Fin4 reff280_inst.
Proof. unfold Equation1435. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff280_inst, reff280_op in H. discriminate H. Qed.

Lemma reff280_not1442 : ~ @Equation1442 Fin4 reff280_inst.
Proof. unfold Equation1442. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff280_inst, reff280_op in H. discriminate H. Qed.

Lemma reff280_not1444 : ~ @Equation1444 Fin4 reff280_inst.
Proof. unfold Equation1444. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff280_inst, reff280_op in H. discriminate H. Qed.

Lemma reff280_not1445 : ~ @Equation1445 Fin4 reff280_inst.
Proof. unfold Equation1445. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff280_inst, reff280_op in H. discriminate H. Qed.

Lemma reff280_not1451 : ~ @Equation1451 Fin4 reff280_inst.
Proof. unfold Equation1451. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff280_inst, reff280_op in H. discriminate H. Qed.

Lemma reff280_not1452 : ~ @Equation1452 Fin4 reff280_inst.
Proof. unfold Equation1452. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff280_inst, reff280_op in H. discriminate H. Qed.

Lemma reff280_not1454 : ~ @Equation1454 Fin4 reff280_inst.
Proof. unfold Equation1454. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff280_inst, reff280_op in H. discriminate H. Qed.

Lemma reff280_not1455 : ~ @Equation1455 Fin4 reff280_inst.
Proof. unfold Equation1455. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff280_inst, reff280_op in H. discriminate H. Qed.

Lemma reff280_not1478 : ~ @Equation1478 Fin4 reff280_inst.
Proof. unfold Equation1478. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff280_inst, reff280_op in H. discriminate H. Qed.

Lemma reff280_not1479 : ~ @Equation1479 Fin4 reff280_inst.
Proof. unfold Equation1479. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff280_inst, reff280_op in H. discriminate H. Qed.

Lemma reff280_not1481 : ~ @Equation1481 Fin4 reff280_inst.
Proof. unfold Equation1481. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff280_inst, reff280_op in H. discriminate H. Qed.

Lemma reff280_not1482 : ~ @Equation1482 Fin4 reff280_inst.
Proof. unfold Equation1482. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff280_inst, reff280_op in H. discriminate H. Qed.

Lemma reff280_not1488 : ~ @Equation1488 Fin4 reff280_inst.
Proof. unfold Equation1488. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff280_inst, reff280_op in H. discriminate H. Qed.

Lemma reff280_not1489 : ~ @Equation1489 Fin4 reff280_inst.
Proof. unfold Equation1489. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff280_inst, reff280_op in H. discriminate H. Qed.

Lemma reff280_not1491 : ~ @Equation1491 Fin4 reff280_inst.
Proof. unfold Equation1491. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff280_inst, reff280_op in H. discriminate H. Qed.

Lemma reff280_not1492 : ~ @Equation1492 Fin4 reff280_inst.
Proof. unfold Equation1492. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff280_inst, reff280_op in H. discriminate H. Qed.

Lemma reff280_not1515 : ~ @Equation1515 Fin4 reff280_inst.
Proof. unfold Equation1515. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff280_inst, reff280_op in H. discriminate H. Qed.

Lemma reff280_not1516 : ~ @Equation1516 Fin4 reff280_inst.
Proof. unfold Equation1516. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff280_inst, reff280_op in H. discriminate H. Qed.

Lemma reff280_not1518 : ~ @Equation1518 Fin4 reff280_inst.
Proof. unfold Equation1518. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff280_inst, reff280_op in H. discriminate H. Qed.

Lemma reff280_not1519 : ~ @Equation1519 Fin4 reff280_inst.
Proof. unfold Equation1519. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff280_inst, reff280_op in H. discriminate H. Qed.

Lemma reff280_not1525 : ~ @Equation1525 Fin4 reff280_inst.
Proof. unfold Equation1525. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff280_inst, reff280_op in H. discriminate H. Qed.

Lemma reff280_not1526 : ~ @Equation1526 Fin4 reff280_inst.
Proof. unfold Equation1526. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff280_inst, reff280_op in H. discriminate H. Qed.

Lemma reff280_not1528 : ~ @Equation1528 Fin4 reff280_inst.
Proof. unfold Equation1528. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff280_inst, reff280_op in H. discriminate H. Qed.

Lemma reff280_not1630 : ~ @Equation1630 Fin4 reff280_inst.
Proof. unfold Equation1630. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff280_inst, reff280_op in H. discriminate H. Qed.

Lemma reff280_not1632 : ~ @Equation1632 Fin4 reff280_inst.
Proof. unfold Equation1632. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff280_inst, reff280_op in H. discriminate H. Qed.

Lemma reff280_not1634 : ~ @Equation1634 Fin4 reff280_inst.
Proof. unfold Equation1634. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff280_inst, reff280_op in H. discriminate H. Qed.

Lemma reff280_not1635 : ~ @Equation1635 Fin4 reff280_inst.
Proof. unfold Equation1635. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff280_inst, reff280_op in H. discriminate H. Qed.

Lemma reff280_not1637 : ~ @Equation1637 Fin4 reff280_inst.
Proof. unfold Equation1637. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff280_inst, reff280_op in H. discriminate H. Qed.

Lemma reff280_not1638 : ~ @Equation1638 Fin4 reff280_inst.
Proof. unfold Equation1638. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff280_inst, reff280_op in H. discriminate H. Qed.

Lemma reff280_not1645 : ~ @Equation1645 Fin4 reff280_inst.
Proof. unfold Equation1645. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff280_inst, reff280_op in H. discriminate H. Qed.

Lemma reff280_not1648 : ~ @Equation1648 Fin4 reff280_inst.
Proof. unfold Equation1648. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff280_inst, reff280_op in H. discriminate H. Qed.

Lemma reff280_not1654 : ~ @Equation1654 Fin4 reff280_inst.
Proof. unfold Equation1654. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff280_inst, reff280_op in H. discriminate H. Qed.

Lemma reff280_not1655 : ~ @Equation1655 Fin4 reff280_inst.
Proof. unfold Equation1655. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff280_inst, reff280_op in H. discriminate H. Qed.

Lemma reff280_not1657 : ~ @Equation1657 Fin4 reff280_inst.
Proof. unfold Equation1657. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff280_inst, reff280_op in H. discriminate H. Qed.

Lemma reff280_not1658 : ~ @Equation1658 Fin4 reff280_inst.
Proof. unfold Equation1658. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff280_inst, reff280_op in H. discriminate H. Qed.

Lemma reff280_not1681 : ~ @Equation1681 Fin4 reff280_inst.
Proof. unfold Equation1681. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff280_inst, reff280_op in H. discriminate H. Qed.

Lemma reff280_not1682 : ~ @Equation1682 Fin4 reff280_inst.
Proof. unfold Equation1682. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff280_inst, reff280_op in H. discriminate H. Qed.

Lemma reff280_not1684 : ~ @Equation1684 Fin4 reff280_inst.
Proof. unfold Equation1684. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff280_inst, reff280_op in H. discriminate H. Qed.

Lemma reff280_not1685 : ~ @Equation1685 Fin4 reff280_inst.
Proof. unfold Equation1685. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff280_inst, reff280_op in H. discriminate H. Qed.

Lemma reff280_not1691 : ~ @Equation1691 Fin4 reff280_inst.
Proof. unfold Equation1691. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff280_inst, reff280_op in H. discriminate H. Qed.

Lemma reff280_not1692 : ~ @Equation1692 Fin4 reff280_inst.
Proof. unfold Equation1692. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff280_inst, reff280_op in H. discriminate H. Qed.

Lemma reff280_not1694 : ~ @Equation1694 Fin4 reff280_inst.
Proof. unfold Equation1694. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff280_inst, reff280_op in H. discriminate H. Qed.

Lemma reff280_not1695 : ~ @Equation1695 Fin4 reff280_inst.
Proof. unfold Equation1695. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff280_inst, reff280_op in H. discriminate H. Qed.

Lemma reff280_not1718 : ~ @Equation1718 Fin4 reff280_inst.
Proof. unfold Equation1718. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff280_inst, reff280_op in H. discriminate H. Qed.

Lemma reff280_not1719 : ~ @Equation1719 Fin4 reff280_inst.
Proof. unfold Equation1719. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff280_inst, reff280_op in H. discriminate H. Qed.

Lemma reff280_not1721 : ~ @Equation1721 Fin4 reff280_inst.
Proof. unfold Equation1721. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff280_inst, reff280_op in H. discriminate H. Qed.

Lemma reff280_not1722 : ~ @Equation1722 Fin4 reff280_inst.
Proof. unfold Equation1722. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff280_inst, reff280_op in H. discriminate H. Qed.

Lemma reff280_not1728 : ~ @Equation1728 Fin4 reff280_inst.
Proof. unfold Equation1728. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff280_inst, reff280_op in H. discriminate H. Qed.

Lemma reff280_not1729 : ~ @Equation1729 Fin4 reff280_inst.
Proof. unfold Equation1729. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff280_inst, reff280_op in H. discriminate H. Qed.

Lemma reff280_not1731 : ~ @Equation1731 Fin4 reff280_inst.
Proof. unfold Equation1731. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff280_inst, reff280_op in H. discriminate H. Qed.

Lemma reff280_not1833 : ~ @Equation1833 Fin4 reff280_inst.
Proof. unfold Equation1833. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff280_inst, reff280_op in H. discriminate H. Qed.

Lemma reff280_not1834 : ~ @Equation1834 Fin4 reff280_inst.
Proof. unfold Equation1834. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff280_inst, reff280_op in H. discriminate H. Qed.

Lemma reff280_not1835 : ~ @Equation1835 Fin4 reff280_inst.
Proof. unfold Equation1835. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff280_inst, reff280_op in H. discriminate H. Qed.

Lemma reff280_not1838 : ~ @Equation1838 Fin4 reff280_inst.
Proof. unfold Equation1838. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff280_inst, reff280_op in H. discriminate H. Qed.

Lemma reff280_not1840 : ~ @Equation1840 Fin4 reff280_inst.
Proof. unfold Equation1840. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff280_inst, reff280_op in H. discriminate H. Qed.

Lemma reff280_not1841 : ~ @Equation1841 Fin4 reff280_inst.
Proof. unfold Equation1841. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff280_inst, reff280_op in H. discriminate H. Qed.

Lemma reff280_not1848 : ~ @Equation1848 Fin4 reff280_inst.
Proof. unfold Equation1848. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff280_inst, reff280_op in H. discriminate H. Qed.

Lemma reff280_not1850 : ~ @Equation1850 Fin4 reff280_inst.
Proof. unfold Equation1850. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff280_inst, reff280_op in H. discriminate H. Qed.

Lemma reff280_not1851 : ~ @Equation1851 Fin4 reff280_inst.
Proof. unfold Equation1851. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff280_inst, reff280_op in H. discriminate H. Qed.

Lemma reff280_not1858 : ~ @Equation1858 Fin4 reff280_inst.
Proof. unfold Equation1858. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff280_inst, reff280_op in H. discriminate H. Qed.

Lemma reff280_not1860 : ~ @Equation1860 Fin4 reff280_inst.
Proof. unfold Equation1860. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff280_inst, reff280_op in H. discriminate H. Qed.

Lemma reff280_not1861 : ~ @Equation1861 Fin4 reff280_inst.
Proof. unfold Equation1861. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff280_inst, reff280_op in H. discriminate H. Qed.

Lemma reff280_not1884 : ~ @Equation1884 Fin4 reff280_inst.
Proof. unfold Equation1884. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff280_inst, reff280_op in H. discriminate H. Qed.

Lemma reff280_not1885 : ~ @Equation1885 Fin4 reff280_inst.
Proof. unfold Equation1885. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff280_inst, reff280_op in H. discriminate H. Qed.

Lemma reff280_not1887 : ~ @Equation1887 Fin4 reff280_inst.
Proof. unfold Equation1887. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff280_inst, reff280_op in H. discriminate H. Qed.

Lemma reff280_not1888 : ~ @Equation1888 Fin4 reff280_inst.
Proof. unfold Equation1888. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff280_inst, reff280_op in H. discriminate H. Qed.

Lemma reff280_not1894 : ~ @Equation1894 Fin4 reff280_inst.
Proof. unfold Equation1894. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff280_inst, reff280_op in H. discriminate H. Qed.

Lemma reff280_not1895 : ~ @Equation1895 Fin4 reff280_inst.
Proof. unfold Equation1895. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff280_inst, reff280_op in H. discriminate H. Qed.

Lemma reff280_not1897 : ~ @Equation1897 Fin4 reff280_inst.
Proof. unfold Equation1897. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff280_inst, reff280_op in H. discriminate H. Qed.

Lemma reff280_not1898 : ~ @Equation1898 Fin4 reff280_inst.
Proof. unfold Equation1898. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff280_inst, reff280_op in H. discriminate H. Qed.

Lemma reff280_not1921 : ~ @Equation1921 Fin4 reff280_inst.
Proof. unfold Equation1921. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff280_inst, reff280_op in H. discriminate H. Qed.

Lemma reff280_not1922 : ~ @Equation1922 Fin4 reff280_inst.
Proof. unfold Equation1922. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff280_inst, reff280_op in H. discriminate H. Qed.

Lemma reff280_not1924 : ~ @Equation1924 Fin4 reff280_inst.
Proof. unfold Equation1924. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff280_inst, reff280_op in H. discriminate H. Qed.

Lemma reff280_not1925 : ~ @Equation1925 Fin4 reff280_inst.
Proof. unfold Equation1925. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff280_inst, reff280_op in H. discriminate H. Qed.

Lemma reff280_not1931 : ~ @Equation1931 Fin4 reff280_inst.
Proof. unfold Equation1931. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff280_inst, reff280_op in H. discriminate H. Qed.

Lemma reff280_not1932 : ~ @Equation1932 Fin4 reff280_inst.
Proof. unfold Equation1932. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff280_inst, reff280_op in H. discriminate H. Qed.

Lemma reff280_not1934 : ~ @Equation1934 Fin4 reff280_inst.
Proof. unfold Equation1934. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff280_inst, reff280_op in H. discriminate H. Qed.

Lemma reff280_not2036 : ~ @Equation2036 Fin4 reff280_inst.
Proof. unfold Equation2036. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff280_inst, reff280_op in H. discriminate H. Qed.

Lemma reff280_not2037 : ~ @Equation2037 Fin4 reff280_inst.
Proof. unfold Equation2037. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff280_inst, reff280_op in H. discriminate H. Qed.

Lemma reff280_not2038 : ~ @Equation2038 Fin4 reff280_inst.
Proof. unfold Equation2038. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff280_inst, reff280_op in H. discriminate H. Qed.

Lemma reff280_not2041 : ~ @Equation2041 Fin4 reff280_inst.
Proof. unfold Equation2041. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff280_inst, reff280_op in H. discriminate H. Qed.

Lemma reff280_not2043 : ~ @Equation2043 Fin4 reff280_inst.
Proof. unfold Equation2043. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff280_inst, reff280_op in H. discriminate H. Qed.

Lemma reff280_not2044 : ~ @Equation2044 Fin4 reff280_inst.
Proof. unfold Equation2044. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff280_inst, reff280_op in H. discriminate H. Qed.

Lemma reff280_not2051 : ~ @Equation2051 Fin4 reff280_inst.
Proof. unfold Equation2051. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff280_inst, reff280_op in H. discriminate H. Qed.

Lemma reff280_not2053 : ~ @Equation2053 Fin4 reff280_inst.
Proof. unfold Equation2053. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff280_inst, reff280_op in H. discriminate H. Qed.

Lemma reff280_not2054 : ~ @Equation2054 Fin4 reff280_inst.
Proof. unfold Equation2054. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff280_inst, reff280_op in H. discriminate H. Qed.

Lemma reff280_not2061 : ~ @Equation2061 Fin4 reff280_inst.
Proof. unfold Equation2061. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff280_inst, reff280_op in H. discriminate H. Qed.

Lemma reff280_not2063 : ~ @Equation2063 Fin4 reff280_inst.
Proof. unfold Equation2063. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff280_inst, reff280_op in H. discriminate H. Qed.

Lemma reff280_not2064 : ~ @Equation2064 Fin4 reff280_inst.
Proof. unfold Equation2064. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff280_inst, reff280_op in H. discriminate H. Qed.

Lemma reff280_not2087 : ~ @Equation2087 Fin4 reff280_inst.
Proof. unfold Equation2087. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff280_inst, reff280_op in H. discriminate H. Qed.

Lemma reff280_not2088 : ~ @Equation2088 Fin4 reff280_inst.
Proof. unfold Equation2088. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff280_inst, reff280_op in H. discriminate H. Qed.

Lemma reff280_not2090 : ~ @Equation2090 Fin4 reff280_inst.
Proof. unfold Equation2090. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff280_inst, reff280_op in H. discriminate H. Qed.

Lemma reff280_not2091 : ~ @Equation2091 Fin4 reff280_inst.
Proof. unfold Equation2091. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff280_inst, reff280_op in H. discriminate H. Qed.

Lemma reff280_not2097 : ~ @Equation2097 Fin4 reff280_inst.
Proof. unfold Equation2097. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff280_inst, reff280_op in H. discriminate H. Qed.

Lemma reff280_not2098 : ~ @Equation2098 Fin4 reff280_inst.
Proof. unfold Equation2098. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff280_inst, reff280_op in H. discriminate H. Qed.

Lemma reff280_not2100 : ~ @Equation2100 Fin4 reff280_inst.
Proof. unfold Equation2100. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff280_inst, reff280_op in H. discriminate H. Qed.

Lemma reff280_not2101 : ~ @Equation2101 Fin4 reff280_inst.
Proof. unfold Equation2101. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff280_inst, reff280_op in H. discriminate H. Qed.

Lemma reff280_not2124 : ~ @Equation2124 Fin4 reff280_inst.
Proof. unfold Equation2124. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff280_inst, reff280_op in H. discriminate H. Qed.

Lemma reff280_not2125 : ~ @Equation2125 Fin4 reff280_inst.
Proof. unfold Equation2125. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff280_inst, reff280_op in H. discriminate H. Qed.

Lemma reff280_not2127 : ~ @Equation2127 Fin4 reff280_inst.
Proof. unfold Equation2127. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff280_inst, reff280_op in H. discriminate H. Qed.

Lemma reff280_not2128 : ~ @Equation2128 Fin4 reff280_inst.
Proof. unfold Equation2128. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff280_inst, reff280_op in H. discriminate H. Qed.

Lemma reff280_not2134 : ~ @Equation2134 Fin4 reff280_inst.
Proof. unfold Equation2134. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff280_inst, reff280_op in H. discriminate H. Qed.

Lemma reff280_not2135 : ~ @Equation2135 Fin4 reff280_inst.
Proof. unfold Equation2135. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff280_inst, reff280_op in H. discriminate H. Qed.

Lemma reff280_not2137 : ~ @Equation2137 Fin4 reff280_inst.
Proof. unfold Equation2137. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff280_inst, reff280_op in H. discriminate H. Qed.

Lemma reff280_not2239 : ~ @Equation2239 Fin4 reff280_inst.
Proof. unfold Equation2239. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff280_inst, reff280_op in H. discriminate H. Qed.

Lemma reff280_not2241 : ~ @Equation2241 Fin4 reff280_inst.
Proof. unfold Equation2241. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff280_inst, reff280_op in H. discriminate H. Qed.

Lemma reff280_not2244 : ~ @Equation2244 Fin4 reff280_inst.
Proof. unfold Equation2244. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff280_inst, reff280_op in H. discriminate H. Qed.

Lemma reff280_not2247 : ~ @Equation2247 Fin4 reff280_inst.
Proof. unfold Equation2247. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff280_inst, reff280_op in H. discriminate H. Qed.

Lemma reff280_not2254 : ~ @Equation2254 Fin4 reff280_inst.
Proof. unfold Equation2254. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff280_inst, reff280_op in H. discriminate H. Qed.

Lemma reff280_not2257 : ~ @Equation2257 Fin4 reff280_inst.
Proof. unfold Equation2257. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff280_inst, reff280_op in H. discriminate H. Qed.

Lemma reff280_not2264 : ~ @Equation2264 Fin4 reff280_inst.
Proof. unfold Equation2264. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff280_inst, reff280_op in H. discriminate H. Qed.

Lemma reff280_not2267 : ~ @Equation2267 Fin4 reff280_inst.
Proof. unfold Equation2267. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff280_inst, reff280_op in H. discriminate H. Qed.

Lemma reff280_not2290 : ~ @Equation2290 Fin4 reff280_inst.
Proof. unfold Equation2290. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff280_inst, reff280_op in H. discriminate H. Qed.

Lemma reff280_not2291 : ~ @Equation2291 Fin4 reff280_inst.
Proof. unfold Equation2291. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff280_inst, reff280_op in H. discriminate H. Qed.

Lemma reff280_not2293 : ~ @Equation2293 Fin4 reff280_inst.
Proof. unfold Equation2293. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff280_inst, reff280_op in H. discriminate H. Qed.

Lemma reff280_not2294 : ~ @Equation2294 Fin4 reff280_inst.
Proof. unfold Equation2294. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff280_inst, reff280_op in H. discriminate H. Qed.

Lemma reff280_not2300 : ~ @Equation2300 Fin4 reff280_inst.
Proof. unfold Equation2300. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff280_inst, reff280_op in H. discriminate H. Qed.

Lemma reff280_not2301 : ~ @Equation2301 Fin4 reff280_inst.
Proof. unfold Equation2301. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff280_inst, reff280_op in H. discriminate H. Qed.

Lemma reff280_not2303 : ~ @Equation2303 Fin4 reff280_inst.
Proof. unfold Equation2303. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff280_inst, reff280_op in H. discriminate H. Qed.

Lemma reff280_not2304 : ~ @Equation2304 Fin4 reff280_inst.
Proof. unfold Equation2304. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff280_inst, reff280_op in H. discriminate H. Qed.

Lemma reff280_not2327 : ~ @Equation2327 Fin4 reff280_inst.
Proof. unfold Equation2327. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff280_inst, reff280_op in H. discriminate H. Qed.

Lemma reff280_not2328 : ~ @Equation2328 Fin4 reff280_inst.
Proof. unfold Equation2328. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff280_inst, reff280_op in H. discriminate H. Qed.

Lemma reff280_not2330 : ~ @Equation2330 Fin4 reff280_inst.
Proof. unfold Equation2330. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff280_inst, reff280_op in H. discriminate H. Qed.

Lemma reff280_not2331 : ~ @Equation2331 Fin4 reff280_inst.
Proof. unfold Equation2331. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff280_inst, reff280_op in H. discriminate H. Qed.

Lemma reff280_not2337 : ~ @Equation2337 Fin4 reff280_inst.
Proof. unfold Equation2337. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff280_inst, reff280_op in H. discriminate H. Qed.

Lemma reff280_not2338 : ~ @Equation2338 Fin4 reff280_inst.
Proof. unfold Equation2338. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff280_inst, reff280_op in H. discriminate H. Qed.

Lemma reff280_not2340 : ~ @Equation2340 Fin4 reff280_inst.
Proof. unfold Equation2340. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff280_inst, reff280_op in H. discriminate H. Qed.

Lemma reff280_not2442 : ~ @Equation2442 Fin4 reff280_inst.
Proof. unfold Equation2442. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff280_inst, reff280_op in H. discriminate H. Qed.

Lemma reff280_not2444 : ~ @Equation2444 Fin4 reff280_inst.
Proof. unfold Equation2444. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff280_inst, reff280_op in H. discriminate H. Qed.

Lemma reff280_not2447 : ~ @Equation2447 Fin4 reff280_inst.
Proof. unfold Equation2447. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff280_inst, reff280_op in H. discriminate H. Qed.

Lemma reff280_not2450 : ~ @Equation2450 Fin4 reff280_inst.
Proof. unfold Equation2450. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff280_inst, reff280_op in H. discriminate H. Qed.

Lemma reff280_not2457 : ~ @Equation2457 Fin4 reff280_inst.
Proof. unfold Equation2457. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff280_inst, reff280_op in H. discriminate H. Qed.

Lemma reff280_not2460 : ~ @Equation2460 Fin4 reff280_inst.
Proof. unfold Equation2460. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff280_inst, reff280_op in H. discriminate H. Qed.

Lemma reff280_not2467 : ~ @Equation2467 Fin4 reff280_inst.
Proof. unfold Equation2467. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff280_inst, reff280_op in H. discriminate H. Qed.

Lemma reff280_not2470 : ~ @Equation2470 Fin4 reff280_inst.
Proof. unfold Equation2470. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff280_inst, reff280_op in H. discriminate H. Qed.

Lemma reff280_not2493 : ~ @Equation2493 Fin4 reff280_inst.
Proof. unfold Equation2493. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff280_inst, reff280_op in H. discriminate H. Qed.

Lemma reff280_not2494 : ~ @Equation2494 Fin4 reff280_inst.
Proof. unfold Equation2494. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff280_inst, reff280_op in H. discriminate H. Qed.

Lemma reff280_not2496 : ~ @Equation2496 Fin4 reff280_inst.
Proof. unfold Equation2496. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff280_inst, reff280_op in H. discriminate H. Qed.

Lemma reff280_not2497 : ~ @Equation2497 Fin4 reff280_inst.
Proof. unfold Equation2497. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff280_inst, reff280_op in H. discriminate H. Qed.

Lemma reff280_not2503 : ~ @Equation2503 Fin4 reff280_inst.
Proof. unfold Equation2503. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff280_inst, reff280_op in H. discriminate H. Qed.

Lemma reff280_not2504 : ~ @Equation2504 Fin4 reff280_inst.
Proof. unfold Equation2504. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff280_inst, reff280_op in H. discriminate H. Qed.

Lemma reff280_not2506 : ~ @Equation2506 Fin4 reff280_inst.
Proof. unfold Equation2506. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff280_inst, reff280_op in H. discriminate H. Qed.

Lemma reff280_not2507 : ~ @Equation2507 Fin4 reff280_inst.
Proof. unfold Equation2507. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff280_inst, reff280_op in H. discriminate H. Qed.

Lemma reff280_not2530 : ~ @Equation2530 Fin4 reff280_inst.
Proof. unfold Equation2530. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff280_inst, reff280_op in H. discriminate H. Qed.

Lemma reff280_not2531 : ~ @Equation2531 Fin4 reff280_inst.
Proof. unfold Equation2531. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff280_inst, reff280_op in H. discriminate H. Qed.

Lemma reff280_not2533 : ~ @Equation2533 Fin4 reff280_inst.
Proof. unfold Equation2533. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff280_inst, reff280_op in H. discriminate H. Qed.

Lemma reff280_not2534 : ~ @Equation2534 Fin4 reff280_inst.
Proof. unfold Equation2534. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff280_inst, reff280_op in H. discriminate H. Qed.

Lemma reff280_not2540 : ~ @Equation2540 Fin4 reff280_inst.
Proof. unfold Equation2540. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff280_inst, reff280_op in H. discriminate H. Qed.

Lemma reff280_not2541 : ~ @Equation2541 Fin4 reff280_inst.
Proof. unfold Equation2541. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff280_inst, reff280_op in H. discriminate H. Qed.

Lemma reff280_not2543 : ~ @Equation2543 Fin4 reff280_inst.
Proof. unfold Equation2543. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff280_inst, reff280_op in H. discriminate H. Qed.

Lemma reff280_not2645 : ~ @Equation2645 Fin4 reff280_inst.
Proof. unfold Equation2645. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff280_inst, reff280_op in H. discriminate H. Qed.

Lemma reff280_not2647 : ~ @Equation2647 Fin4 reff280_inst.
Proof. unfold Equation2647. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff280_inst, reff280_op in H. discriminate H. Qed.

Lemma reff280_not2650 : ~ @Equation2650 Fin4 reff280_inst.
Proof. unfold Equation2650. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff280_inst, reff280_op in H. discriminate H. Qed.

Lemma reff280_not2653 : ~ @Equation2653 Fin4 reff280_inst.
Proof. unfold Equation2653. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff280_inst, reff280_op in H. discriminate H. Qed.

Lemma reff280_not2660 : ~ @Equation2660 Fin4 reff280_inst.
Proof. unfold Equation2660. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff280_inst, reff280_op in H. discriminate H. Qed.

Lemma reff280_not2663 : ~ @Equation2663 Fin4 reff280_inst.
Proof. unfold Equation2663. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff280_inst, reff280_op in H. discriminate H. Qed.

Lemma reff280_not2670 : ~ @Equation2670 Fin4 reff280_inst.
Proof. unfold Equation2670. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff280_inst, reff280_op in H. discriminate H. Qed.

Lemma reff280_not2673 : ~ @Equation2673 Fin4 reff280_inst.
Proof. unfold Equation2673. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff280_inst, reff280_op in H. discriminate H. Qed.

Lemma reff280_not2696 : ~ @Equation2696 Fin4 reff280_inst.
Proof. unfold Equation2696. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff280_inst, reff280_op in H. discriminate H. Qed.

Lemma reff280_not2697 : ~ @Equation2697 Fin4 reff280_inst.
Proof. unfold Equation2697. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff280_inst, reff280_op in H. discriminate H. Qed.

Lemma reff280_not2699 : ~ @Equation2699 Fin4 reff280_inst.
Proof. unfold Equation2699. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff280_inst, reff280_op in H. discriminate H. Qed.

Lemma reff280_not2700 : ~ @Equation2700 Fin4 reff280_inst.
Proof. unfold Equation2700. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff280_inst, reff280_op in H. discriminate H. Qed.

Lemma reff280_not2706 : ~ @Equation2706 Fin4 reff280_inst.
Proof. unfold Equation2706. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff280_inst, reff280_op in H. discriminate H. Qed.

Lemma reff280_not2707 : ~ @Equation2707 Fin4 reff280_inst.
Proof. unfold Equation2707. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff280_inst, reff280_op in H. discriminate H. Qed.

Lemma reff280_not2709 : ~ @Equation2709 Fin4 reff280_inst.
Proof. unfold Equation2709. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff280_inst, reff280_op in H. discriminate H. Qed.

Lemma reff280_not2710 : ~ @Equation2710 Fin4 reff280_inst.
Proof. unfold Equation2710. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff280_inst, reff280_op in H. discriminate H. Qed.

Lemma reff280_not2733 : ~ @Equation2733 Fin4 reff280_inst.
Proof. unfold Equation2733. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff280_inst, reff280_op in H. discriminate H. Qed.

Lemma reff280_not2734 : ~ @Equation2734 Fin4 reff280_inst.
Proof. unfold Equation2734. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff280_inst, reff280_op in H. discriminate H. Qed.

Lemma reff280_not2736 : ~ @Equation2736 Fin4 reff280_inst.
Proof. unfold Equation2736. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff280_inst, reff280_op in H. discriminate H. Qed.

Lemma reff280_not2737 : ~ @Equation2737 Fin4 reff280_inst.
Proof. unfold Equation2737. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff280_inst, reff280_op in H. discriminate H. Qed.

Lemma reff280_not2743 : ~ @Equation2743 Fin4 reff280_inst.
Proof. unfold Equation2743. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff280_inst, reff280_op in H. discriminate H. Qed.

Lemma reff280_not2744 : ~ @Equation2744 Fin4 reff280_inst.
Proof. unfold Equation2744. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff280_inst, reff280_op in H. discriminate H. Qed.

Lemma reff280_not2746 : ~ @Equation2746 Fin4 reff280_inst.
Proof. unfold Equation2746. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff280_inst, reff280_op in H. discriminate H. Qed.

Lemma reff280_not2848 : ~ @Equation2848 Fin4 reff280_inst.
Proof. unfold Equation2848. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff280_inst, reff280_op in H. discriminate H. Qed.

Lemma reff280_not2850 : ~ @Equation2850 Fin4 reff280_inst.
Proof. unfold Equation2850. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff280_inst, reff280_op in H. discriminate H. Qed.

Lemma reff280_not2853 : ~ @Equation2853 Fin4 reff280_inst.
Proof. unfold Equation2853. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff280_inst, reff280_op in H. discriminate H. Qed.

Lemma reff280_not2856 : ~ @Equation2856 Fin4 reff280_inst.
Proof. unfold Equation2856. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff280_inst, reff280_op in H. discriminate H. Qed.

Lemma reff280_not2863 : ~ @Equation2863 Fin4 reff280_inst.
Proof. unfold Equation2863. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff280_inst, reff280_op in H. discriminate H. Qed.

Lemma reff280_not2866 : ~ @Equation2866 Fin4 reff280_inst.
Proof. unfold Equation2866. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff280_inst, reff280_op in H. discriminate H. Qed.

Lemma reff280_not2873 : ~ @Equation2873 Fin4 reff280_inst.
Proof. unfold Equation2873. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff280_inst, reff280_op in H. discriminate H. Qed.

Lemma reff280_not2876 : ~ @Equation2876 Fin4 reff280_inst.
Proof. unfold Equation2876. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff280_inst, reff280_op in H. discriminate H. Qed.

Lemma reff280_not2899 : ~ @Equation2899 Fin4 reff280_inst.
Proof. unfold Equation2899. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff280_inst, reff280_op in H. discriminate H. Qed.

Lemma reff280_not2900 : ~ @Equation2900 Fin4 reff280_inst.
Proof. unfold Equation2900. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff280_inst, reff280_op in H. discriminate H. Qed.

Lemma reff280_not2902 : ~ @Equation2902 Fin4 reff280_inst.
Proof. unfold Equation2902. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff280_inst, reff280_op in H. discriminate H. Qed.

Lemma reff280_not2903 : ~ @Equation2903 Fin4 reff280_inst.
Proof. unfold Equation2903. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff280_inst, reff280_op in H. discriminate H. Qed.

Lemma reff280_not2909 : ~ @Equation2909 Fin4 reff280_inst.
Proof. unfold Equation2909. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff280_inst, reff280_op in H. discriminate H. Qed.

Lemma reff280_not2910 : ~ @Equation2910 Fin4 reff280_inst.
Proof. unfold Equation2910. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff280_inst, reff280_op in H. discriminate H. Qed.

Lemma reff280_not2912 : ~ @Equation2912 Fin4 reff280_inst.
Proof. unfold Equation2912. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff280_inst, reff280_op in H. discriminate H. Qed.

Lemma reff280_not2913 : ~ @Equation2913 Fin4 reff280_inst.
Proof. unfold Equation2913. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff280_inst, reff280_op in H. discriminate H. Qed.

Lemma reff280_not2936 : ~ @Equation2936 Fin4 reff280_inst.
Proof. unfold Equation2936. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff280_inst, reff280_op in H. discriminate H. Qed.

Lemma reff280_not2937 : ~ @Equation2937 Fin4 reff280_inst.
Proof. unfold Equation2937. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff280_inst, reff280_op in H. discriminate H. Qed.

Lemma reff280_not2939 : ~ @Equation2939 Fin4 reff280_inst.
Proof. unfold Equation2939. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff280_inst, reff280_op in H. discriminate H. Qed.

Lemma reff280_not2940 : ~ @Equation2940 Fin4 reff280_inst.
Proof. unfold Equation2940. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff280_inst, reff280_op in H. discriminate H. Qed.

Lemma reff280_not2946 : ~ @Equation2946 Fin4 reff280_inst.
Proof. unfold Equation2946. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff280_inst, reff280_op in H. discriminate H. Qed.

Lemma reff280_not2947 : ~ @Equation2947 Fin4 reff280_inst.
Proof. unfold Equation2947. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff280_inst, reff280_op in H. discriminate H. Qed.

Lemma reff280_not2949 : ~ @Equation2949 Fin4 reff280_inst.
Proof. unfold Equation2949. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff280_inst, reff280_op in H. discriminate H. Qed.

Lemma reff280_not3051 : ~ @Equation3051 Fin4 reff280_inst.
Proof. unfold Equation3051. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff280_inst, reff280_op in H. discriminate H. Qed.

Lemma reff280_not3053 : ~ @Equation3053 Fin4 reff280_inst.
Proof. unfold Equation3053. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff280_inst, reff280_op in H. discriminate H. Qed.

Lemma reff280_not3056 : ~ @Equation3056 Fin4 reff280_inst.
Proof. unfold Equation3056. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff280_inst, reff280_op in H. discriminate H. Qed.

Lemma reff280_not3059 : ~ @Equation3059 Fin4 reff280_inst.
Proof. unfold Equation3059. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff280_inst, reff280_op in H. discriminate H. Qed.

Lemma reff280_not3066 : ~ @Equation3066 Fin4 reff280_inst.
Proof. unfold Equation3066. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff280_inst, reff280_op in H. discriminate H. Qed.

Lemma reff280_not3069 : ~ @Equation3069 Fin4 reff280_inst.
Proof. unfold Equation3069. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff280_inst, reff280_op in H. discriminate H. Qed.

Lemma reff280_not3076 : ~ @Equation3076 Fin4 reff280_inst.
Proof. unfold Equation3076. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff280_inst, reff280_op in H. discriminate H. Qed.

Lemma reff280_not3079 : ~ @Equation3079 Fin4 reff280_inst.
Proof. unfold Equation3079. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff280_inst, reff280_op in H. discriminate H. Qed.

Lemma reff280_not3102 : ~ @Equation3102 Fin4 reff280_inst.
Proof. unfold Equation3102. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff280_inst, reff280_op in H. discriminate H. Qed.

Lemma reff280_not3103 : ~ @Equation3103 Fin4 reff280_inst.
Proof. unfold Equation3103. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff280_inst, reff280_op in H. discriminate H. Qed.

Lemma reff280_not3105 : ~ @Equation3105 Fin4 reff280_inst.
Proof. unfold Equation3105. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff280_inst, reff280_op in H. discriminate H. Qed.

Lemma reff280_not3106 : ~ @Equation3106 Fin4 reff280_inst.
Proof. unfold Equation3106. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff280_inst, reff280_op in H. discriminate H. Qed.

Lemma reff280_not3112 : ~ @Equation3112 Fin4 reff280_inst.
Proof. unfold Equation3112. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff280_inst, reff280_op in H. discriminate H. Qed.

Lemma reff280_not3113 : ~ @Equation3113 Fin4 reff280_inst.
Proof. unfold Equation3113. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff280_inst, reff280_op in H. discriminate H. Qed.

Lemma reff280_not3115 : ~ @Equation3115 Fin4 reff280_inst.
Proof. unfold Equation3115. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff280_inst, reff280_op in H. discriminate H. Qed.

Lemma reff280_not3116 : ~ @Equation3116 Fin4 reff280_inst.
Proof. unfold Equation3116. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff280_inst, reff280_op in H. discriminate H. Qed.

Lemma reff280_not3139 : ~ @Equation3139 Fin4 reff280_inst.
Proof. unfold Equation3139. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff280_inst, reff280_op in H. discriminate H. Qed.

Lemma reff280_not3140 : ~ @Equation3140 Fin4 reff280_inst.
Proof. unfold Equation3140. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff280_inst, reff280_op in H. discriminate H. Qed.

Lemma reff280_not3142 : ~ @Equation3142 Fin4 reff280_inst.
Proof. unfold Equation3142. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff280_inst, reff280_op in H. discriminate H. Qed.

Lemma reff280_not3143 : ~ @Equation3143 Fin4 reff280_inst.
Proof. unfold Equation3143. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff280_inst, reff280_op in H. discriminate H. Qed.

Lemma reff280_not3149 : ~ @Equation3149 Fin4 reff280_inst.
Proof. unfold Equation3149. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff280_inst, reff280_op in H. discriminate H. Qed.

Lemma reff280_not3150 : ~ @Equation3150 Fin4 reff280_inst.
Proof. unfold Equation3150. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff280_inst, reff280_op in H. discriminate H. Qed.

Lemma reff280_not3152 : ~ @Equation3152 Fin4 reff280_inst.
Proof. unfold Equation3152. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff280_inst, reff280_op in H. discriminate H. Qed.

Lemma reff280_not3254 : ~ @Equation3254 Fin4 reff280_inst.
Proof. unfold Equation3254. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff280_inst, reff280_op in H. discriminate H. Qed.

Lemma reff280_not3255 : ~ @Equation3255 Fin4 reff280_inst.
Proof. unfold Equation3255. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff280_inst, reff280_op in H. discriminate H. Qed.

Lemma reff280_not3256 : ~ @Equation3256 Fin4 reff280_inst.
Proof. unfold Equation3256. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff280_inst, reff280_op in H. discriminate H. Qed.

Lemma reff280_not3258 : ~ @Equation3258 Fin4 reff280_inst.
Proof. unfold Equation3258. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff280_inst, reff280_op in H. discriminate H. Qed.

Lemma reff280_not3259 : ~ @Equation3259 Fin4 reff280_inst.
Proof. unfold Equation3259. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff280_inst, reff280_op in H. discriminate H. Qed.

Lemma reff280_not3261 : ~ @Equation3261 Fin4 reff280_inst.
Proof. unfold Equation3261. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff280_inst, reff280_op in H. discriminate H. Qed.

Lemma reff280_not3262 : ~ @Equation3262 Fin4 reff280_inst.
Proof. unfold Equation3262. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff280_inst, reff280_op in H. discriminate H. Qed.

Lemma reff280_not3268 : ~ @Equation3268 Fin4 reff280_inst.
Proof. unfold Equation3268. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff280_inst, reff280_op in H. discriminate H. Qed.

Lemma reff280_not3269 : ~ @Equation3269 Fin4 reff280_inst.
Proof. unfold Equation3269. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff280_inst, reff280_op in H. discriminate H. Qed.

Lemma reff280_not3271 : ~ @Equation3271 Fin4 reff280_inst.
Proof. unfold Equation3271. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff280_inst, reff280_op in H. discriminate H. Qed.

Lemma reff280_not3272 : ~ @Equation3272 Fin4 reff280_inst.
Proof. unfold Equation3272. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff280_inst, reff280_op in H. discriminate H. Qed.

Lemma reff280_not3278 : ~ @Equation3278 Fin4 reff280_inst.
Proof. unfold Equation3278. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff280_inst, reff280_op in H. discriminate H. Qed.

Lemma reff280_not3279 : ~ @Equation3279 Fin4 reff280_inst.
Proof. unfold Equation3279. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff280_inst, reff280_op in H. discriminate H. Qed.

Lemma reff280_not3281 : ~ @Equation3281 Fin4 reff280_inst.
Proof. unfold Equation3281. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff280_inst, reff280_op in H. discriminate H. Qed.

Lemma reff280_not3308 : ~ @Equation3308 Fin4 reff280_inst.
Proof. unfold Equation3308. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff280_inst, reff280_op in H. discriminate H. Qed.

Lemma reff280_not3315 : ~ @Equation3315 Fin4 reff280_inst.
Proof. unfold Equation3315. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff280_inst, reff280_op in H. discriminate H. Qed.

Lemma reff280_not3316 : ~ @Equation3316 Fin4 reff280_inst.
Proof. unfold Equation3316. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff280_inst, reff280_op in H. discriminate H. Qed.

Lemma reff280_not3318 : ~ @Equation3318 Fin4 reff280_inst.
Proof. unfold Equation3318. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff280_inst, reff280_op in H. discriminate H. Qed.

Lemma reff280_not3342 : ~ @Equation3342 Fin4 reff280_inst.
Proof. unfold Equation3342. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff280_inst, reff280_op in H. discriminate H. Qed.

Lemma reff280_not3343 : ~ @Equation3343 Fin4 reff280_inst.
Proof. unfold Equation3343. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff280_inst, reff280_op in H. discriminate H. Qed.

Lemma reff280_not3345 : ~ @Equation3345 Fin4 reff280_inst.
Proof. unfold Equation3345. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff280_inst, reff280_op in H. discriminate H. Qed.

Lemma reff280_not3346 : ~ @Equation3346 Fin4 reff280_inst.
Proof. unfold Equation3346. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff280_inst, reff280_op in H. discriminate H. Qed.

Lemma reff280_not3352 : ~ @Equation3352 Fin4 reff280_inst.
Proof. unfold Equation3352. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff280_inst, reff280_op in H. discriminate H. Qed.

Lemma reff280_not3353 : ~ @Equation3353 Fin4 reff280_inst.
Proof. unfold Equation3353. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff280_inst, reff280_op in H. discriminate H. Qed.

Lemma reff280_not3457 : ~ @Equation3457 Fin4 reff280_inst.
Proof. unfold Equation3457. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff280_inst, reff280_op in H. discriminate H. Qed.

Lemma reff280_not3459 : ~ @Equation3459 Fin4 reff280_inst.
Proof. unfold Equation3459. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff280_inst, reff280_op in H. discriminate H. Qed.

Lemma reff280_not3461 : ~ @Equation3461 Fin4 reff280_inst.
Proof. unfold Equation3461. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff280_inst, reff280_op in H. discriminate H. Qed.

Lemma reff280_not3462 : ~ @Equation3462 Fin4 reff280_inst.
Proof. unfold Equation3462. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff280_inst, reff280_op in H. discriminate H. Qed.

Lemma reff280_not3464 : ~ @Equation3464 Fin4 reff280_inst.
Proof. unfold Equation3464. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff280_inst, reff280_op in H. discriminate H. Qed.

Lemma reff280_not3465 : ~ @Equation3465 Fin4 reff280_inst.
Proof. unfold Equation3465. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff280_inst, reff280_op in H. discriminate H. Qed.

Lemma reff280_not3472 : ~ @Equation3472 Fin4 reff280_inst.
Proof. unfold Equation3472. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff280_inst, reff280_op in H. discriminate H. Qed.

Lemma reff280_not3474 : ~ @Equation3474 Fin4 reff280_inst.
Proof. unfold Equation3474. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff280_inst, reff280_op in H. discriminate H. Qed.

Lemma reff280_not3475 : ~ @Equation3475 Fin4 reff280_inst.
Proof. unfold Equation3475. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff280_inst, reff280_op in H. discriminate H. Qed.

Lemma reff280_not3481 : ~ @Equation3481 Fin4 reff280_inst.
Proof. unfold Equation3481. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff280_inst, reff280_op in H. discriminate H. Qed.

Lemma reff280_not3482 : ~ @Equation3482 Fin4 reff280_inst.
Proof. unfold Equation3482. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff280_inst, reff280_op in H. discriminate H. Qed.

Lemma reff280_not3484 : ~ @Equation3484 Fin4 reff280_inst.
Proof. unfold Equation3484. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff280_inst, reff280_op in H. discriminate H. Qed.

Lemma reff280_not3511 : ~ @Equation3511 Fin4 reff280_inst.
Proof. unfold Equation3511. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff280_inst, reff280_op in H. discriminate H. Qed.

Lemma reff280_not3518 : ~ @Equation3518 Fin4 reff280_inst.
Proof. unfold Equation3518. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff280_inst, reff280_op in H. discriminate H. Qed.

Lemma reff280_not3521 : ~ @Equation3521 Fin4 reff280_inst.
Proof. unfold Equation3521. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff280_inst, reff280_op in H. discriminate H. Qed.

Lemma reff280_not3545 : ~ @Equation3545 Fin4 reff280_inst.
Proof. unfold Equation3545. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff280_inst, reff280_op in H. discriminate H. Qed.

Lemma reff280_not3546 : ~ @Equation3546 Fin4 reff280_inst.
Proof. unfold Equation3546. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff280_inst, reff280_op in H. discriminate H. Qed.

Lemma reff280_not3548 : ~ @Equation3548 Fin4 reff280_inst.
Proof. unfold Equation3548. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff280_inst, reff280_op in H. discriminate H. Qed.

Lemma reff280_not3549 : ~ @Equation3549 Fin4 reff280_inst.
Proof. unfold Equation3549. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff280_inst, reff280_op in H. discriminate H. Qed.

Lemma reff280_not3555 : ~ @Equation3555 Fin4 reff280_inst.
Proof. unfold Equation3555. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff280_inst, reff280_op in H. discriminate H. Qed.

Lemma reff280_not3556 : ~ @Equation3556 Fin4 reff280_inst.
Proof. unfold Equation3556. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff280_inst, reff280_op in H. discriminate H. Qed.

Lemma reff280_not3558 : ~ @Equation3558 Fin4 reff280_inst.
Proof. unfold Equation3558. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff280_inst, reff280_op in H. discriminate H. Qed.

Lemma reff280_not3660 : ~ @Equation3660 Fin4 reff280_inst.
Proof. unfold Equation3660. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff280_inst, reff280_op in H. discriminate H. Qed.

Lemma reff280_not3661 : ~ @Equation3661 Fin4 reff280_inst.
Proof. unfold Equation3661. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff280_inst, reff280_op in H. discriminate H. Qed.

Lemma reff280_not3662 : ~ @Equation3662 Fin4 reff280_inst.
Proof. unfold Equation3662. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff280_inst, reff280_op in H. discriminate H. Qed.

Lemma reff280_not3665 : ~ @Equation3665 Fin4 reff280_inst.
Proof. unfold Equation3665. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff280_inst, reff280_op in H. discriminate H. Qed.

Lemma reff280_not3667 : ~ @Equation3667 Fin4 reff280_inst.
Proof. unfold Equation3667. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff280_inst, reff280_op in H. discriminate H. Qed.

Lemma reff280_not3668 : ~ @Equation3668 Fin4 reff280_inst.
Proof. unfold Equation3668. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff280_inst, reff280_op in H. discriminate H. Qed.

Lemma reff280_not3674 : ~ @Equation3674 Fin4 reff280_inst.
Proof. unfold Equation3674. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff280_inst, reff280_op in H. discriminate H. Qed.

Lemma reff280_not3675 : ~ @Equation3675 Fin4 reff280_inst.
Proof. unfold Equation3675. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff280_inst, reff280_op in H. discriminate H. Qed.

Lemma reff280_not3677 : ~ @Equation3677 Fin4 reff280_inst.
Proof. unfold Equation3677. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff280_inst, reff280_op in H. discriminate H. Qed.

Lemma reff280_not3678 : ~ @Equation3678 Fin4 reff280_inst.
Proof. unfold Equation3678. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff280_inst, reff280_op in H. discriminate H. Qed.

Lemma reff280_not3684 : ~ @Equation3684 Fin4 reff280_inst.
Proof. unfold Equation3684. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff280_inst, reff280_op in H. discriminate H. Qed.

Lemma reff280_not3685 : ~ @Equation3685 Fin4 reff280_inst.
Proof. unfold Equation3685. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff280_inst, reff280_op in H. discriminate H. Qed.

Lemma reff280_not3687 : ~ @Equation3687 Fin4 reff280_inst.
Proof. unfold Equation3687. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff280_inst, reff280_op in H. discriminate H. Qed.

Lemma reff280_not3714 : ~ @Equation3714 Fin4 reff280_inst.
Proof. unfold Equation3714. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff280_inst, reff280_op in H. discriminate H. Qed.

Lemma reff280_not3721 : ~ @Equation3721 Fin4 reff280_inst.
Proof. unfold Equation3721. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff280_inst, reff280_op in H. discriminate H. Qed.

Lemma reff280_not3724 : ~ @Equation3724 Fin4 reff280_inst.
Proof. unfold Equation3724. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff280_inst, reff280_op in H. discriminate H. Qed.

Lemma reff280_not3748 : ~ @Equation3748 Fin4 reff280_inst.
Proof. unfold Equation3748. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff280_inst, reff280_op in H. discriminate H. Qed.

Lemma reff280_not3749 : ~ @Equation3749 Fin4 reff280_inst.
Proof. unfold Equation3749. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff280_inst, reff280_op in H. discriminate H. Qed.

Lemma reff280_not3751 : ~ @Equation3751 Fin4 reff280_inst.
Proof. unfold Equation3751. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff280_inst, reff280_op in H. discriminate H. Qed.

Lemma reff280_not3752 : ~ @Equation3752 Fin4 reff280_inst.
Proof. unfold Equation3752. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff280_inst, reff280_op in H. discriminate H. Qed.

Lemma reff280_not3758 : ~ @Equation3758 Fin4 reff280_inst.
Proof. unfold Equation3758. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff280_inst, reff280_op in H. discriminate H. Qed.

Lemma reff280_not3759 : ~ @Equation3759 Fin4 reff280_inst.
Proof. unfold Equation3759. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff280_inst, reff280_op in H. discriminate H. Qed.

Lemma reff280_not3761 : ~ @Equation3761 Fin4 reff280_inst.
Proof. unfold Equation3761. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff280_inst, reff280_op in H. discriminate H. Qed.

Lemma reff280_not3865 : ~ @Equation3865 Fin4 reff280_inst.
Proof. unfold Equation3865. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff280_inst, reff280_op in H. discriminate H. Qed.

Lemma reff280_not3868 : ~ @Equation3868 Fin4 reff280_inst.
Proof. unfold Equation3868. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff280_inst, reff280_op in H. discriminate H. Qed.

Lemma reff280_not3871 : ~ @Equation3871 Fin4 reff280_inst.
Proof. unfold Equation3871. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff280_inst, reff280_op in H. discriminate H. Qed.

Lemma reff280_not3877 : ~ @Equation3877 Fin4 reff280_inst.
Proof. unfold Equation3877. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff280_inst, reff280_op in H. discriminate H. Qed.

Lemma reff280_not3878 : ~ @Equation3878 Fin4 reff280_inst.
Proof. unfold Equation3878. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff280_inst, reff280_op in H. discriminate H. Qed.

Lemma reff280_not3880 : ~ @Equation3880 Fin4 reff280_inst.
Proof. unfold Equation3880. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff280_inst, reff280_op in H. discriminate H. Qed.

Lemma reff280_not3881 : ~ @Equation3881 Fin4 reff280_inst.
Proof. unfold Equation3881. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff280_inst, reff280_op in H. discriminate H. Qed.

Lemma reff280_not3887 : ~ @Equation3887 Fin4 reff280_inst.
Proof. unfold Equation3887. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff280_inst, reff280_op in H. discriminate H. Qed.

Lemma reff280_not3888 : ~ @Equation3888 Fin4 reff280_inst.
Proof. unfold Equation3888. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff280_inst, reff280_op in H. discriminate H. Qed.

Lemma reff280_not3890 : ~ @Equation3890 Fin4 reff280_inst.
Proof. unfold Equation3890. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff280_inst, reff280_op in H. discriminate H. Qed.

Lemma reff280_not3917 : ~ @Equation3917 Fin4 reff280_inst.
Proof. unfold Equation3917. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff280_inst, reff280_op in H. discriminate H. Qed.

Lemma reff280_not3924 : ~ @Equation3924 Fin4 reff280_inst.
Proof. unfold Equation3924. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff280_inst, reff280_op in H. discriminate H. Qed.

Lemma reff280_not3927 : ~ @Equation3927 Fin4 reff280_inst.
Proof. unfold Equation3927. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff280_inst, reff280_op in H. discriminate H. Qed.

Lemma reff280_not3951 : ~ @Equation3951 Fin4 reff280_inst.
Proof. unfold Equation3951. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff280_inst, reff280_op in H. discriminate H. Qed.

Lemma reff280_not3952 : ~ @Equation3952 Fin4 reff280_inst.
Proof. unfold Equation3952. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff280_inst, reff280_op in H. discriminate H. Qed.

Lemma reff280_not3954 : ~ @Equation3954 Fin4 reff280_inst.
Proof. unfold Equation3954. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff280_inst, reff280_op in H. discriminate H. Qed.

Lemma reff280_not3955 : ~ @Equation3955 Fin4 reff280_inst.
Proof. unfold Equation3955. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff280_inst, reff280_op in H. discriminate H. Qed.

Lemma reff280_not3961 : ~ @Equation3961 Fin4 reff280_inst.
Proof. unfold Equation3961. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff280_inst, reff280_op in H. discriminate H. Qed.

Lemma reff280_not3962 : ~ @Equation3962 Fin4 reff280_inst.
Proof. unfold Equation3962. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff280_inst, reff280_op in H. discriminate H. Qed.

Lemma reff280_not3964 : ~ @Equation3964 Fin4 reff280_inst.
Proof. unfold Equation3964. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff280_inst, reff280_op in H. discriminate H. Qed.

Lemma reff280_not4066 : ~ @Equation4066 Fin4 reff280_inst.
Proof. unfold Equation4066. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff280_inst, reff280_op in H. discriminate H. Qed.

Lemma reff280_not4068 : ~ @Equation4068 Fin4 reff280_inst.
Proof. unfold Equation4068. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff280_inst, reff280_op in H. discriminate H. Qed.

Lemma reff280_not4071 : ~ @Equation4071 Fin4 reff280_inst.
Proof. unfold Equation4071. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff280_inst, reff280_op in H. discriminate H. Qed.

Lemma reff280_not4074 : ~ @Equation4074 Fin4 reff280_inst.
Proof. unfold Equation4074. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff280_inst, reff280_op in H. discriminate H. Qed.

Lemma reff280_not4080 : ~ @Equation4080 Fin4 reff280_inst.
Proof. unfold Equation4080. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff280_inst, reff280_op in H. discriminate H. Qed.

Lemma reff280_not4081 : ~ @Equation4081 Fin4 reff280_inst.
Proof. unfold Equation4081. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff280_inst, reff280_op in H. discriminate H. Qed.

Lemma reff280_not4083 : ~ @Equation4083 Fin4 reff280_inst.
Proof. unfold Equation4083. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff280_inst, reff280_op in H. discriminate H. Qed.

Lemma reff280_not4084 : ~ @Equation4084 Fin4 reff280_inst.
Proof. unfold Equation4084. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff280_inst, reff280_op in H. discriminate H. Qed.

Lemma reff280_not4090 : ~ @Equation4090 Fin4 reff280_inst.
Proof. unfold Equation4090. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff280_inst, reff280_op in H. discriminate H. Qed.

Lemma reff280_not4091 : ~ @Equation4091 Fin4 reff280_inst.
Proof. unfold Equation4091. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff280_inst, reff280_op in H. discriminate H. Qed.

Lemma reff280_not4093 : ~ @Equation4093 Fin4 reff280_inst.
Proof. unfold Equation4093. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff280_inst, reff280_op in H. discriminate H. Qed.

Lemma reff280_not4120 : ~ @Equation4120 Fin4 reff280_inst.
Proof. unfold Equation4120. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff280_inst, reff280_op in H. discriminate H. Qed.

Lemma reff280_not4127 : ~ @Equation4127 Fin4 reff280_inst.
Proof. unfold Equation4127. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff280_inst, reff280_op in H. discriminate H. Qed.

Lemma reff280_not4130 : ~ @Equation4130 Fin4 reff280_inst.
Proof. unfold Equation4130. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff280_inst, reff280_op in H. discriminate H. Qed.

Lemma reff280_not4155 : ~ @Equation4155 Fin4 reff280_inst.
Proof. unfold Equation4155. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff280_inst, reff280_op in H. discriminate H. Qed.

Lemma reff280_not4157 : ~ @Equation4157 Fin4 reff280_inst.
Proof. unfold Equation4157. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff280_inst, reff280_op in H. discriminate H. Qed.

Lemma reff280_not4158 : ~ @Equation4158 Fin4 reff280_inst.
Proof. unfold Equation4158. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff280_inst, reff280_op in H. discriminate H. Qed.

Lemma reff280_not4164 : ~ @Equation4164 Fin4 reff280_inst.
Proof. unfold Equation4164. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff280_inst, reff280_op in H. discriminate H. Qed.

Lemma reff280_not4165 : ~ @Equation4165 Fin4 reff280_inst.
Proof. unfold Equation4165. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff280_inst, reff280_op in H. discriminate H. Qed.

Lemma reff280_not4167 : ~ @Equation4167 Fin4 reff280_inst.
Proof. unfold Equation4167. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff280_inst, reff280_op in H. discriminate H. Qed.

Lemma reff280_not4268 : ~ @Equation4268 Fin4 reff280_inst.
Proof. unfold Equation4268. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff280_inst, reff280_op in H. discriminate H. Qed.

Lemma reff280_not4269 : ~ @Equation4269 Fin4 reff280_inst.
Proof. unfold Equation4269. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff280_inst, reff280_op in H. discriminate H. Qed.

Lemma reff280_not4270 : ~ @Equation4270 Fin4 reff280_inst.
Proof. unfold Equation4270. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff280_inst, reff280_op in H. discriminate H. Qed.

Lemma reff280_not4272 : ~ @Equation4272 Fin4 reff280_inst.
Proof. unfold Equation4272. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff280_inst, reff280_op in H. discriminate H. Qed.

Lemma reff280_not4273 : ~ @Equation4273 Fin4 reff280_inst.
Proof. unfold Equation4273. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff280_inst, reff280_op in H. discriminate H. Qed.

Lemma reff280_not4275 : ~ @Equation4275 Fin4 reff280_inst.
Proof. unfold Equation4275. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff280_inst, reff280_op in H. discriminate H. Qed.

Lemma reff280_not4276 : ~ @Equation4276 Fin4 reff280_inst.
Proof. unfold Equation4276. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff280_inst, reff280_op in H. discriminate H. Qed.

Lemma reff280_not4283 : ~ @Equation4283 Fin4 reff280_inst.
Proof. unfold Equation4283. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff280_inst, reff280_op in H. discriminate H. Qed.

Lemma reff280_not4290 : ~ @Equation4290 Fin4 reff280_inst.
Proof. unfold Equation4290. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff280_inst, reff280_op in H. discriminate H. Qed.

Lemma reff280_not4291 : ~ @Equation4291 Fin4 reff280_inst.
Proof. unfold Equation4291. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff280_inst, reff280_op in H. discriminate H. Qed.

Lemma reff280_not4293 : ~ @Equation4293 Fin4 reff280_inst.
Proof. unfold Equation4293. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff280_inst, reff280_op in H. discriminate H. Qed.

Lemma reff280_not4314 : ~ @Equation4314 Fin4 reff280_inst.
Proof. unfold Equation4314. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff280_inst, reff280_op in H. discriminate H. Qed.

Lemma reff280_not4320 : ~ @Equation4320 Fin4 reff280_inst.
Proof. unfold Equation4320. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff280_inst, reff280_op in H. discriminate H. Qed.

Lemma reff280_not4321 : ~ @Equation4321 Fin4 reff280_inst.
Proof. unfold Equation4321. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff280_inst, reff280_op in H. discriminate H. Qed.

Lemma reff280_not4343 : ~ @Equation4343 Fin4 reff280_inst.
Proof. unfold Equation4343. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff280_inst, reff280_op in H. discriminate H. Qed.

Lemma reff280_not4398 : ~ @Equation4398 Fin4 reff280_inst.
Proof. unfold Equation4398. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff280_inst, reff280_op in H. discriminate H. Qed.

Lemma reff280_not4405 : ~ @Equation4405 Fin4 reff280_inst.
Proof. unfold Equation4405. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff280_inst, reff280_op in H. discriminate H. Qed.

Lemma reff280_not4406 : ~ @Equation4406 Fin4 reff280_inst.
Proof. unfold Equation4406. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff280_inst, reff280_op in H. discriminate H. Qed.

Lemma reff280_not4408 : ~ @Equation4408 Fin4 reff280_inst.
Proof. unfold Equation4408. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff280_inst, reff280_op in H. discriminate H. Qed.

Lemma reff280_not4433 : ~ @Equation4433 Fin4 reff280_inst.
Proof. unfold Equation4433. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff280_inst, reff280_op in H. discriminate H. Qed.

Lemma reff280_not4435 : ~ @Equation4435 Fin4 reff280_inst.
Proof. unfold Equation4435. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff280_inst, reff280_op in H. discriminate H. Qed.

Lemma reff280_not4436 : ~ @Equation4436 Fin4 reff280_inst.
Proof. unfold Equation4436. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff280_inst, reff280_op in H. discriminate H. Qed.

Lemma reff280_not4442 : ~ @Equation4442 Fin4 reff280_inst.
Proof. unfold Equation4442. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff280_inst, reff280_op in H. discriminate H. Qed.

Lemma reff280_not4443 : ~ @Equation4443 Fin4 reff280_inst.
Proof. unfold Equation4443. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff280_inst, reff280_op in H. discriminate H. Qed.

Lemma reff280_not4445 : ~ @Equation4445 Fin4 reff280_inst.
Proof. unfold Equation4445. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff280_inst, reff280_op in H. discriminate H. Qed.

Lemma reff280_not4472 : ~ @Equation4472 Fin4 reff280_inst.
Proof. unfold Equation4472. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff280_inst, reff280_op in H. discriminate H. Qed.

Lemma reff280_not4479 : ~ @Equation4479 Fin4 reff280_inst.
Proof. unfold Equation4479. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff280_inst, reff280_op in H. discriminate H. Qed.

Lemma reff280_not4480 : ~ @Equation4480 Fin4 reff280_inst.
Proof. unfold Equation4480. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff280_inst, reff280_op in H. discriminate H. Qed.

Lemma reff280_not4482 : ~ @Equation4482 Fin4 reff280_inst.
Proof. unfold Equation4482. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff280_inst, reff280_op in H. discriminate H. Qed.

Lemma reff280_not4583 : ~ @Equation4583 Fin4 reff280_inst.
Proof. unfold Equation4583. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff280_inst, reff280_op in H. discriminate H. Qed.

Lemma reff280_not4585 : ~ @Equation4585 Fin4 reff280_inst.
Proof. unfold Equation4585. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff280_inst, reff280_op in H. discriminate H. Qed.

Lemma reff280_not4587 : ~ @Equation4587 Fin4 reff280_inst.
Proof. unfold Equation4587. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff280_inst, reff280_op in H. discriminate H. Qed.

Lemma reff280_not4588 : ~ @Equation4588 Fin4 reff280_inst.
Proof. unfold Equation4588. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff280_inst, reff280_op in H. discriminate H. Qed.

Lemma reff280_not4590 : ~ @Equation4590 Fin4 reff280_inst.
Proof. unfold Equation4590. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff280_inst, reff280_op in H. discriminate H. Qed.

Lemma reff280_not4591 : ~ @Equation4591 Fin4 reff280_inst.
Proof. unfold Equation4591. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff280_inst, reff280_op in H. discriminate H. Qed.

Lemma reff280_not4598 : ~ @Equation4598 Fin4 reff280_inst.
Proof. unfold Equation4598. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff280_inst, reff280_op in H. discriminate H. Qed.

Lemma reff280_not4605 : ~ @Equation4605 Fin4 reff280_inst.
Proof. unfold Equation4605. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff280_inst, reff280_op in H. discriminate H. Qed.

Lemma reff280_not4606 : ~ @Equation4606 Fin4 reff280_inst.
Proof. unfold Equation4606. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff280_inst, reff280_op in H. discriminate H. Qed.

Lemma reff280_not4608 : ~ @Equation4608 Fin4 reff280_inst.
Proof. unfold Equation4608. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff280_inst, reff280_op in H. discriminate H. Qed.

Lemma reff280_not4629 : ~ @Equation4629 Fin4 reff280_inst.
Proof. unfold Equation4629. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff280_inst, reff280_op in H. discriminate H. Qed.

Lemma reff280_not4635 : ~ @Equation4635 Fin4 reff280_inst.
Proof. unfold Equation4635. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff280_inst, reff280_op in H. discriminate H. Qed.

Lemma reff280_not4636 : ~ @Equation4636 Fin4 reff280_inst.
Proof. unfold Equation4636. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff280_inst, reff280_op in H. discriminate H. Qed.

Lemma reff280_not4658 : ~ @Equation4658 Fin4 reff280_inst.
Proof. unfold Equation4658. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff280_inst, reff280_op in H. discriminate H. Qed.

(** ---- reff284 (Fin3) ---- *)

Definition reff284_op (x y : Fin3) : Fin3 :=
  match x, y with
  | F3_0, F3_0 => F3_0 | F3_0, F3_1 => F3_2 | F3_0, F3_2 => F3_0
  | F3_1, F3_0 => F3_0 | F3_1, F3_1 => F3_2 | F3_1, F3_2 => F3_0
  | F3_2, F3_0 => F3_1 | F3_2, F3_1 => F3_0 | F3_2, F3_2 => F3_1
  end.

#[local] Instance reff284_inst : Magma Fin3 := {| magma_op := reff284_op |}.

Lemma reff284_sat151 : @Equation151 Fin3 reff284_inst.
Proof. unfold Equation151, magma_op, reff284_inst, reff284_op. intros x. destruct x; reflexivity. Qed.

Lemma reff284_sat4389 : @Equation4389 Fin3 reff284_inst.
Proof. unfold Equation4389, magma_op, reff284_inst, reff284_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff284_not47 : ~ @Equation47 Fin3 reff284_inst.
Proof. unfold Equation47. intro H. specialize (H F3_1). unfold magma_op, reff284_inst, reff284_op in H. discriminate H. Qed.

Lemma reff284_not99 : ~ @Equation99 Fin3 reff284_inst.
Proof. unfold Equation99. intro H. specialize (H F3_1). unfold magma_op, reff284_inst, reff284_op in H. discriminate H. Qed.

Lemma reff284_not154 : ~ @Equation154 Fin3 reff284_inst.
Proof. unfold Equation154. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff284_inst, reff284_op in H. discriminate H. Qed.

Lemma reff284_not157 : ~ @Equation157 Fin3 reff284_inst.
Proof. unfold Equation157. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff284_inst, reff284_op in H. discriminate H. Qed.

Lemma reff284_not159 : ~ @Equation159 Fin3 reff284_inst.
Proof. unfold Equation159. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff284_inst, reff284_op in H. discriminate H. Qed.

Lemma reff284_not160 : ~ @Equation160 Fin3 reff284_inst.
Proof. unfold Equation160. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff284_inst, reff284_op in H. discriminate H. Qed.

Lemma reff284_not167 : ~ @Equation167 Fin3 reff284_inst.
Proof. unfold Equation167. intro H. specialize (H F3_1 F3_2). unfold magma_op, reff284_inst, reff284_op in H. discriminate H. Qed.

Lemma reff284_not169 : ~ @Equation169 Fin3 reff284_inst.
Proof. unfold Equation169. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff284_inst, reff284_op in H. discriminate H. Qed.

Lemma reff284_not170 : ~ @Equation170 Fin3 reff284_inst.
Proof. unfold Equation170. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff284_inst, reff284_op in H. discriminate H. Qed.

Lemma reff284_not176 : ~ @Equation176 Fin3 reff284_inst.
Proof. unfold Equation176. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff284_inst, reff284_op in H. discriminate H. Qed.

Lemma reff284_not177 : ~ @Equation177 Fin3 reff284_inst.
Proof. unfold Equation177. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff284_inst, reff284_op in H. discriminate H. Qed.

Lemma reff284_not179 : ~ @Equation179 Fin3 reff284_inst.
Proof. unfold Equation179. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff284_inst, reff284_op in H. discriminate H. Qed.

Lemma reff284_not203 : ~ @Equation203 Fin3 reff284_inst.
Proof. unfold Equation203. intro H. specialize (H F3_1). unfold magma_op, reff284_inst, reff284_op in H. discriminate H. Qed.

Lemma reff284_not255 : ~ @Equation255 Fin3 reff284_inst.
Proof. unfold Equation255. intro H. specialize (H F3_1). unfold magma_op, reff284_inst, reff284_op in H. discriminate H. Qed.

Lemma reff284_not411 : ~ @Equation411 Fin3 reff284_inst.
Proof. unfold Equation411. intro H. specialize (H F3_1). unfold magma_op, reff284_inst, reff284_op in H. discriminate H. Qed.

Lemma reff284_not614 : ~ @Equation614 Fin3 reff284_inst.
Proof. unfold Equation614. intro H. specialize (H F3_1). unfold magma_op, reff284_inst, reff284_op in H. discriminate H. Qed.

Lemma reff284_not817 : ~ @Equation817 Fin3 reff284_inst.
Proof. unfold Equation817. intro H. specialize (H F3_1). unfold magma_op, reff284_inst, reff284_op in H. discriminate H. Qed.

Lemma reff284_not1020 : ~ @Equation1020 Fin3 reff284_inst.
Proof. unfold Equation1020. intro H. specialize (H F3_1). unfold magma_op, reff284_inst, reff284_op in H. discriminate H. Qed.

Lemma reff284_not1223 : ~ @Equation1223 Fin3 reff284_inst.
Proof. unfold Equation1223. intro H. specialize (H F3_1). unfold magma_op, reff284_inst, reff284_op in H. discriminate H. Qed.

Lemma reff284_not1426 : ~ @Equation1426 Fin3 reff284_inst.
Proof. unfold Equation1426. intro H. specialize (H F3_2). unfold magma_op, reff284_inst, reff284_op in H. discriminate H. Qed.

Lemma reff284_not1629 : ~ @Equation1629 Fin3 reff284_inst.
Proof. unfold Equation1629. intro H. specialize (H F3_2). unfold magma_op, reff284_inst, reff284_op in H. discriminate H. Qed.

Lemma reff284_not1832 : ~ @Equation1832 Fin3 reff284_inst.
Proof. unfold Equation1832. intro H. specialize (H F3_1). unfold magma_op, reff284_inst, reff284_op in H. discriminate H. Qed.

Lemma reff284_not2035 : ~ @Equation2035 Fin3 reff284_inst.
Proof. unfold Equation2035. intro H. specialize (H F3_1). unfold magma_op, reff284_inst, reff284_op in H. discriminate H. Qed.

Lemma reff284_not2238 : ~ @Equation2238 Fin3 reff284_inst.
Proof. unfold Equation2238. intro H. specialize (H F3_1). unfold magma_op, reff284_inst, reff284_op in H. discriminate H. Qed.

Lemma reff284_not2441 : ~ @Equation2441 Fin3 reff284_inst.
Proof. unfold Equation2441. intro H. specialize (H F3_1). unfold magma_op, reff284_inst, reff284_op in H. discriminate H. Qed.

Lemma reff284_not2644 : ~ @Equation2644 Fin3 reff284_inst.
Proof. unfold Equation2644. intro H. specialize (H F3_1). unfold magma_op, reff284_inst, reff284_op in H. discriminate H. Qed.

Lemma reff284_not2847 : ~ @Equation2847 Fin3 reff284_inst.
Proof. unfold Equation2847. intro H. specialize (H F3_1). unfold magma_op, reff284_inst, reff284_op in H. discriminate H. Qed.

Lemma reff284_not3050 : ~ @Equation3050 Fin3 reff284_inst.
Proof. unfold Equation3050. intro H. specialize (H F3_1). unfold magma_op, reff284_inst, reff284_op in H. discriminate H. Qed.

Lemma reff284_not3253 : ~ @Equation3253 Fin3 reff284_inst.
Proof. unfold Equation3253. intro H. specialize (H F3_1). unfold magma_op, reff284_inst, reff284_op in H. discriminate H. Qed.

Lemma reff284_not3456 : ~ @Equation3456 Fin3 reff284_inst.
Proof. unfold Equation3456. intro H. specialize (H F3_1). unfold magma_op, reff284_inst, reff284_op in H. discriminate H. Qed.

Lemma reff284_not3659 : ~ @Equation3659 Fin3 reff284_inst.
Proof. unfold Equation3659. intro H. specialize (H F3_1). unfold magma_op, reff284_inst, reff284_op in H. discriminate H. Qed.

Lemma reff284_not3862 : ~ @Equation3862 Fin3 reff284_inst.
Proof. unfold Equation3862. intro H. specialize (H F3_2). unfold magma_op, reff284_inst, reff284_op in H. discriminate H. Qed.

Lemma reff284_not4065 : ~ @Equation4065 Fin3 reff284_inst.
Proof. unfold Equation4065. intro H. specialize (H F3_2). unfold magma_op, reff284_inst, reff284_op in H. discriminate H. Qed.

Lemma reff284_not4268 : ~ @Equation4268 Fin3 reff284_inst.
Proof. unfold Equation4268. intro H. specialize (H F3_2 F3_1). unfold magma_op, reff284_inst, reff284_op in H. discriminate H. Qed.

Lemma reff284_not4269 : ~ @Equation4269 Fin3 reff284_inst.
Proof. unfold Equation4269. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff284_inst, reff284_op in H. discriminate H. Qed.

Lemma reff284_not4270 : ~ @Equation4270 Fin3 reff284_inst.
Proof. unfold Equation4270. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff284_inst, reff284_op in H. discriminate H. Qed.

Lemma reff284_not4272 : ~ @Equation4272 Fin3 reff284_inst.
Proof. unfold Equation4272. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff284_inst, reff284_op in H. discriminate H. Qed.

Lemma reff284_not4273 : ~ @Equation4273 Fin3 reff284_inst.
Proof. unfold Equation4273. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff284_inst, reff284_op in H. discriminate H. Qed.

Lemma reff284_not4275 : ~ @Equation4275 Fin3 reff284_inst.
Proof. unfold Equation4275. intro H. specialize (H F3_1 F3_2). unfold magma_op, reff284_inst, reff284_op in H. discriminate H. Qed.

Lemma reff284_not4283 : ~ @Equation4283 Fin3 reff284_inst.
Proof. unfold Equation4283. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff284_inst, reff284_op in H. discriminate H. Qed.

Lemma reff284_not4284 : ~ @Equation4284 Fin3 reff284_inst.
Proof. unfold Equation4284. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff284_inst, reff284_op in H. discriminate H. Qed.

Lemma reff284_not4290 : ~ @Equation4290 Fin3 reff284_inst.
Proof. unfold Equation4290. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff284_inst, reff284_op in H. discriminate H. Qed.

Lemma reff284_not4291 : ~ @Equation4291 Fin3 reff284_inst.
Proof. unfold Equation4291. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff284_inst, reff284_op in H. discriminate H. Qed.

Lemma reff284_not4293 : ~ @Equation4293 Fin3 reff284_inst.
Proof. unfold Equation4293. intro H. specialize (H F3_1 F3_2). unfold magma_op, reff284_inst, reff284_op in H. discriminate H. Qed.

Lemma reff284_not4314 : ~ @Equation4314 Fin3 reff284_inst.
Proof. unfold Equation4314. intro H. specialize (H F3_1 F3_2). unfold magma_op, reff284_inst, reff284_op in H. discriminate H. Qed.

Lemma reff284_not4320 : ~ @Equation4320 Fin3 reff284_inst.
Proof. unfold Equation4320. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff284_inst, reff284_op in H. discriminate H. Qed.

Lemma reff284_not4321 : ~ @Equation4321 Fin3 reff284_inst.
Proof. unfold Equation4321. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff284_inst, reff284_op in H. discriminate H. Qed.

Lemma reff284_not4343 : ~ @Equation4343 Fin3 reff284_inst.
Proof. unfold Equation4343. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff284_inst, reff284_op in H. discriminate H. Qed.

Lemma reff284_not4396 : ~ @Equation4396 Fin3 reff284_inst.
Proof. unfold Equation4396. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff284_inst, reff284_op in H. discriminate H. Qed.

Lemma reff284_not4398 : ~ @Equation4398 Fin3 reff284_inst.
Proof. unfold Equation4398. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff284_inst, reff284_op in H. discriminate H. Qed.

Lemma reff284_not4399 : ~ @Equation4399 Fin3 reff284_inst.
Proof. unfold Equation4399. intro H. specialize (H F3_2 F3_1). unfold magma_op, reff284_inst, reff284_op in H. discriminate H. Qed.

Lemma reff284_not4405 : ~ @Equation4405 Fin3 reff284_inst.
Proof. unfold Equation4405. intro H. specialize (H F3_1 F3_2). unfold magma_op, reff284_inst, reff284_op in H. discriminate H. Qed.

Lemma reff284_not4406 : ~ @Equation4406 Fin3 reff284_inst.
Proof. unfold Equation4406. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff284_inst, reff284_op in H. discriminate H. Qed.

Lemma reff284_not4408 : ~ @Equation4408 Fin3 reff284_inst.
Proof. unfold Equation4408. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff284_inst, reff284_op in H. discriminate H. Qed.

Lemma reff284_not4433 : ~ @Equation4433 Fin3 reff284_inst.
Proof. unfold Equation4433. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff284_inst, reff284_op in H. discriminate H. Qed.

Lemma reff284_not4435 : ~ @Equation4435 Fin3 reff284_inst.
Proof. unfold Equation4435. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff284_inst, reff284_op in H. discriminate H. Qed.

Lemma reff284_not4436 : ~ @Equation4436 Fin3 reff284_inst.
Proof. unfold Equation4436. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff284_inst, reff284_op in H. discriminate H. Qed.

Lemma reff284_not4442 : ~ @Equation4442 Fin3 reff284_inst.
Proof. unfold Equation4442. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff284_inst, reff284_op in H. discriminate H. Qed.

Lemma reff284_not4443 : ~ @Equation4443 Fin3 reff284_inst.
Proof. unfold Equation4443. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff284_inst, reff284_op in H. discriminate H. Qed.

Lemma reff284_not4445 : ~ @Equation4445 Fin3 reff284_inst.
Proof. unfold Equation4445. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff284_inst, reff284_op in H. discriminate H. Qed.

Lemma reff284_not4470 : ~ @Equation4470 Fin3 reff284_inst.
Proof. unfold Equation4470. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff284_inst, reff284_op in H. discriminate H. Qed.

Lemma reff284_not4472 : ~ @Equation4472 Fin3 reff284_inst.
Proof. unfold Equation4472. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff284_inst, reff284_op in H. discriminate H. Qed.

Lemma reff284_not4473 : ~ @Equation4473 Fin3 reff284_inst.
Proof. unfold Equation4473. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff284_inst, reff284_op in H. discriminate H. Qed.

Lemma reff284_not4479 : ~ @Equation4479 Fin3 reff284_inst.
Proof. unfold Equation4479. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff284_inst, reff284_op in H. discriminate H. Qed.

Lemma reff284_not4480 : ~ @Equation4480 Fin3 reff284_inst.
Proof. unfold Equation4480. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff284_inst, reff284_op in H. discriminate H. Qed.

Lemma reff284_not4482 : ~ @Equation4482 Fin3 reff284_inst.
Proof. unfold Equation4482. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff284_inst, reff284_op in H. discriminate H. Qed.

Lemma reff284_not4583 : ~ @Equation4583 Fin3 reff284_inst.
Proof. unfold Equation4583. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff284_inst, reff284_op in H. discriminate H. Qed.

Lemma reff284_not4584 : ~ @Equation4584 Fin3 reff284_inst.
Proof. unfold Equation4584. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff284_inst, reff284_op in H. discriminate H. Qed.

Lemma reff284_not4585 : ~ @Equation4585 Fin3 reff284_inst.
Proof. unfold Equation4585. intro H. specialize (H F3_2 F3_1). unfold magma_op, reff284_inst, reff284_op in H. discriminate H. Qed.

Lemma reff284_not4587 : ~ @Equation4587 Fin3 reff284_inst.
Proof. unfold Equation4587. intro H. specialize (H F3_1 F3_2). unfold magma_op, reff284_inst, reff284_op in H. discriminate H. Qed.

Lemma reff284_not4588 : ~ @Equation4588 Fin3 reff284_inst.
Proof. unfold Equation4588. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff284_inst, reff284_op in H. discriminate H. Qed.

Lemma reff284_not4590 : ~ @Equation4590 Fin3 reff284_inst.
Proof. unfold Equation4590. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff284_inst, reff284_op in H. discriminate H. Qed.

Lemma reff284_not4598 : ~ @Equation4598 Fin3 reff284_inst.
Proof. unfold Equation4598. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff284_inst, reff284_op in H. discriminate H. Qed.

Lemma reff284_not4599 : ~ @Equation4599 Fin3 reff284_inst.
Proof. unfold Equation4599. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff284_inst, reff284_op in H. discriminate H. Qed.

Lemma reff284_not4605 : ~ @Equation4605 Fin3 reff284_inst.
Proof. unfold Equation4605. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff284_inst, reff284_op in H. discriminate H. Qed.

Lemma reff284_not4606 : ~ @Equation4606 Fin3 reff284_inst.
Proof. unfold Equation4606. intro H. specialize (H F3_1 F3_2). unfold magma_op, reff284_inst, reff284_op in H. discriminate H. Qed.

Lemma reff284_not4608 : ~ @Equation4608 Fin3 reff284_inst.
Proof. unfold Equation4608. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff284_inst, reff284_op in H. discriminate H. Qed.

Lemma reff284_not4629 : ~ @Equation4629 Fin3 reff284_inst.
Proof. unfold Equation4629. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff284_inst, reff284_op in H. discriminate H. Qed.

Lemma reff284_not4635 : ~ @Equation4635 Fin3 reff284_inst.
Proof. unfold Equation4635. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff284_inst, reff284_op in H. discriminate H. Qed.

Lemma reff284_not4636 : ~ @Equation4636 Fin3 reff284_inst.
Proof. unfold Equation4636. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff284_inst, reff284_op in H. discriminate H. Qed.

Lemma reff284_not4658 : ~ @Equation4658 Fin3 reff284_inst.
Proof. unfold Equation4658. intro H. specialize (H F3_1 F3_2). unfold magma_op, reff284_inst, reff284_op in H. discriminate H. Qed.
