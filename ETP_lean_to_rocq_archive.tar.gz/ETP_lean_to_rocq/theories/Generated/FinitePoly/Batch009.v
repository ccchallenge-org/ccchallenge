(** * FinitePoly counterexamples — batch 9
    Auto-generated from Lean4 FinitePoly files. *)

From Stdlib Require Import Utf8.

From ETP Require Import Magma.
From ETP Require Import FinMagma.
From ETP.Equations Require Import All.

Open Scope magma_scope.

(** ---- reff402 (Fin4) ---- *)

Definition reff402_op (x y : Fin4) : Fin4 :=
  match x, y with
  | F4_0, F4_0 => F4_0 | F4_0, F4_1 => F4_3 | F4_0, F4_2 => F4_2 | F4_0, F4_3 => F4_1
  | F4_1, F4_0 => F4_1 | F4_1, F4_1 => F4_0 | F4_1, F4_2 => F4_3 | F4_1, F4_3 => F4_2
  | F4_2, F4_0 => F4_2 | F4_2, F4_1 => F4_1 | F4_2, F4_2 => F4_0 | F4_2, F4_3 => F4_3
  | F4_3, F4_0 => F4_3 | F4_3, F4_1 => F4_2 | F4_3, F4_2 => F4_1 | F4_3, F4_3 => F4_0
  end.

#[local] Instance reff402_inst : Magma Fin4 := {| magma_op := reff402_op |}.

Lemma reff402_sat11 : @Equation11 Fin4 reff402_inst.
Proof. unfold Equation11, magma_op, reff402_inst, reff402_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff402_sat455 : @Equation455 Fin4 reff402_inst.
Proof. unfold Equation455, magma_op, reff402_inst, reff402_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff402_sat508 : @Equation508 Fin4 reff402_inst.
Proof. unfold Equation508, magma_op, reff402_inst, reff402_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff402_sat543 : @Equation543 Fin4 reff402_inst.
Proof. unfold Equation543, magma_op, reff402_inst, reff402_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff402_sat914 : @Equation914 Fin4 reff402_inst.
Proof. unfold Equation914, magma_op, reff402_inst, reff402_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff402_sat928 : @Equation928 Fin4 reff402_inst.
Proof. unfold Equation928, magma_op, reff402_inst, reff402_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff402_sat952 : @Equation952 Fin4 reff402_inst.
Proof. unfold Equation952, magma_op, reff402_inst, reff402_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff402_sat978 : @Equation978 Fin4 reff402_inst.
Proof. unfold Equation978, magma_op, reff402_inst, reff402_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff402_sat1053 : @Equation1053 Fin4 reff402_inst.
Proof. unfold Equation1053, magma_op, reff402_inst, reff402_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff402_sat1117 : @Equation1117 Fin4 reff402_inst.
Proof. unfold Equation1117, magma_op, reff402_inst, reff402_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff402_sat1137 : @Equation1137 Fin4 reff402_inst.
Proof. unfold Equation1137, magma_op, reff402_inst, reff402_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff402_sat1152 : @Equation1152 Fin4 reff402_inst.
Proof. unfold Equation1152, magma_op, reff402_inst, reff402_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff402_sat1670 : @Equation1670 Fin4 reff402_inst.
Proof. unfold Equation1670, magma_op, reff402_inst, reff402_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff402_sat1673 : @Equation1673 Fin4 reff402_inst.
Proof. unfold Equation1673, magma_op, reff402_inst, reff402_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff402_sat1740 : @Equation1740 Fin4 reff402_inst.
Proof. unfold Equation1740, magma_op, reff402_inst, reff402_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff402_sat1746 : @Equation1746 Fin4 reff402_inst.
Proof. unfold Equation1746, magma_op, reff402_inst, reff402_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff402_sat1774 : @Equation1774 Fin4 reff402_inst.
Proof. unfold Equation1774, magma_op, reff402_inst, reff402_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff402_sat1876 : @Equation1876 Fin4 reff402_inst.
Proof. unfold Equation1876, magma_op, reff402_inst, reff402_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff402_sat1929 : @Equation1929 Fin4 reff402_inst.
Proof. unfold Equation1929, magma_op, reff402_inst, reff402_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff402_sat1964 : @Equation1964 Fin4 reff402_inst.
Proof. unfold Equation1964, magma_op, reff402_inst, reff402_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff402_sat1996 : @Equation1996 Fin4 reff402_inst.
Proof. unfold Equation1996, magma_op, reff402_inst, reff402_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff402_sat2474 : @Equation2474 Fin4 reff402_inst.
Proof. unfold Equation2474, magma_op, reff402_inst, reff402_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff402_sat2482 : @Equation2482 Fin4 reff402_inst.
Proof. unfold Equation2482, magma_op, reff402_inst, reff402_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff402_sat2538 : @Equation2538 Fin4 reff402_inst.
Proof. unfold Equation2538, magma_op, reff402_inst, reff402_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff402_sat2552 : @Equation2552 Fin4 reff402_inst.
Proof. unfold Equation2552, magma_op, reff402_inst, reff402_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff402_sat2576 : @Equation2576 Fin4 reff402_inst.
Proof. unfold Equation2576, magma_op, reff402_inst, reff402_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff402_sat2602 : @Equation2602 Fin4 reff402_inst.
Proof. unfold Equation2602, magma_op, reff402_inst, reff402_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff402_sat3079 : @Equation3079 Fin4 reff402_inst.
Proof. unfold Equation3079, magma_op, reff402_inst, reff402_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff402_sat3103 : @Equation3103 Fin4 reff402_inst.
Proof. unfold Equation3103, magma_op, reff402_inst, reff402_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff402_sat3105 : @Equation3105 Fin4 reff402_inst.
Proof. unfold Equation3105, magma_op, reff402_inst, reff402_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff402_sat3112 : @Equation3112 Fin4 reff402_inst.
Proof. unfold Equation3112, magma_op, reff402_inst, reff402_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff402_sat3139 : @Equation3139 Fin4 reff402_inst.
Proof. unfold Equation3139, magma_op, reff402_inst, reff402_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff402_sat3297 : @Equation3297 Fin4 reff402_inst.
Proof. unfold Equation3297, magma_op, reff402_inst, reff402_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff402_sat3398 : @Equation3398 Fin4 reff402_inst.
Proof. unfold Equation3398, magma_op, reff402_inst, reff402_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff402_sat3737 : @Equation3737 Fin4 reff402_inst.
Proof. unfold Equation3737, magma_op, reff402_inst, reff402_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff402_sat3823 : @Equation3823 Fin4 reff402_inst.
Proof. unfold Equation3823, magma_op, reff402_inst, reff402_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff402_sat3895 : @Equation3895 Fin4 reff402_inst.
Proof. unfold Equation3895, magma_op, reff402_inst, reff402_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff402_sat4007 : @Equation4007 Fin4 reff402_inst.
Proof. unfold Equation4007, magma_op, reff402_inst, reff402_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff402_sat4297 : @Equation4297 Fin4 reff402_inst.
Proof. unfold Equation4297, magma_op, reff402_inst, reff402_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff402_sat4620 : @Equation4620 Fin4 reff402_inst.
Proof. unfold Equation4620, magma_op, reff402_inst, reff402_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff402_not47 : ~ @Equation47 Fin4 reff402_inst.
Proof. unfold Equation47. intro H. specialize (H F4_1). unfold magma_op, reff402_inst, reff402_op in H. discriminate H. Qed.

Lemma reff402_not99 : ~ @Equation99 Fin4 reff402_inst.
Proof. unfold Equation99. intro H. specialize (H F4_1). unfold magma_op, reff402_inst, reff402_op in H. discriminate H. Qed.

Lemma reff402_not151 : ~ @Equation151 Fin4 reff402_inst.
Proof. unfold Equation151. intro H. specialize (H F4_1). unfold magma_op, reff402_inst, reff402_op in H. discriminate H. Qed.

Lemma reff402_not203 : ~ @Equation203 Fin4 reff402_inst.
Proof. unfold Equation203. intro H. specialize (H F4_1). unfold magma_op, reff402_inst, reff402_op in H. discriminate H. Qed.

Lemma reff402_not255 : ~ @Equation255 Fin4 reff402_inst.
Proof. unfold Equation255. intro H. specialize (H F4_1). unfold magma_op, reff402_inst, reff402_op in H. discriminate H. Qed.

Lemma reff402_not307 : ~ @Equation307 Fin4 reff402_inst.
Proof. unfold Equation307. intro H. specialize (H F4_1). unfold magma_op, reff402_inst, reff402_op in H. discriminate H. Qed.

Lemma reff402_not412 : ~ @Equation412 Fin4 reff402_inst.
Proof. unfold Equation412. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff402_inst, reff402_op in H. discriminate H. Qed.

Lemma reff402_not413 : ~ @Equation413 Fin4 reff402_inst.
Proof. unfold Equation413. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff402_inst, reff402_op in H. discriminate H. Qed.

Lemma reff402_not416 : ~ @Equation416 Fin4 reff402_inst.
Proof. unfold Equation416. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff402_inst, reff402_op in H. discriminate H. Qed.

Lemma reff402_not417 : ~ @Equation417 Fin4 reff402_inst.
Proof. unfold Equation417. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff402_inst, reff402_op in H. discriminate H. Qed.

Lemma reff402_not420 : ~ @Equation420 Fin4 reff402_inst.
Proof. unfold Equation420. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff402_inst, reff402_op in H. discriminate H. Qed.

Lemma reff402_not426 : ~ @Equation426 Fin4 reff402_inst.
Proof. unfold Equation426. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff402_inst, reff402_op in H. discriminate H. Qed.

Lemma reff402_not429 : ~ @Equation429 Fin4 reff402_inst.
Proof. unfold Equation429. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff402_inst, reff402_op in H. discriminate H. Qed.

Lemma reff402_not430 : ~ @Equation430 Fin4 reff402_inst.
Proof. unfold Equation430. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff402_inst, reff402_op in H. discriminate H. Qed.

Lemma reff402_not437 : ~ @Equation437 Fin4 reff402_inst.
Proof. unfold Equation437. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff402_inst, reff402_op in H. discriminate H. Qed.

Lemma reff402_not439 : ~ @Equation439 Fin4 reff402_inst.
Proof. unfold Equation439. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff402_inst, reff402_op in H. discriminate H. Qed.

Lemma reff402_not463 : ~ @Equation463 Fin4 reff402_inst.
Proof. unfold Equation463. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff402_inst, reff402_op in H. discriminate H. Qed.

Lemma reff402_not464 : ~ @Equation464 Fin4 reff402_inst.
Proof. unfold Equation464. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff402_inst, reff402_op in H. discriminate H. Qed.

Lemma reff402_not467 : ~ @Equation467 Fin4 reff402_inst.
Proof. unfold Equation467. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff402_inst, reff402_op in H. discriminate H. Qed.

Lemma reff402_not473 : ~ @Equation473 Fin4 reff402_inst.
Proof. unfold Equation473. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff402_inst, reff402_op in H. discriminate H. Qed.

Lemma reff402_not474 : ~ @Equation474 Fin4 reff402_inst.
Proof. unfold Equation474. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff402_inst, reff402_op in H. discriminate H. Qed.

Lemma reff402_not476 : ~ @Equation476 Fin4 reff402_inst.
Proof. unfold Equation476. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff402_inst, reff402_op in H. discriminate H. Qed.

Lemma reff402_not477 : ~ @Equation477 Fin4 reff402_inst.
Proof. unfold Equation477. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff402_inst, reff402_op in H. discriminate H. Qed.

Lemma reff402_not501 : ~ @Equation501 Fin4 reff402_inst.
Proof. unfold Equation501. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff402_inst, reff402_op in H. discriminate H. Qed.

Lemma reff402_not503 : ~ @Equation503 Fin4 reff402_inst.
Proof. unfold Equation503. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff402_inst, reff402_op in H. discriminate H. Qed.

Lemma reff402_not510 : ~ @Equation510 Fin4 reff402_inst.
Proof. unfold Equation510. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff402_inst, reff402_op in H. discriminate H. Qed.

Lemma reff402_not511 : ~ @Equation511 Fin4 reff402_inst.
Proof. unfold Equation511. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff402_inst, reff402_op in H. discriminate H. Qed.

Lemma reff402_not614 : ~ @Equation614 Fin4 reff402_inst.
Proof. unfold Equation614. intro H. specialize (H F4_1). unfold magma_op, reff402_inst, reff402_op in H. discriminate H. Qed.

Lemma reff402_not818 : ~ @Equation818 Fin4 reff402_inst.
Proof. unfold Equation818. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff402_inst, reff402_op in H. discriminate H. Qed.

Lemma reff402_not819 : ~ @Equation819 Fin4 reff402_inst.
Proof. unfold Equation819. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff402_inst, reff402_op in H. discriminate H. Qed.

Lemma reff402_not822 : ~ @Equation822 Fin4 reff402_inst.
Proof. unfold Equation822. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff402_inst, reff402_op in H. discriminate H. Qed.

Lemma reff402_not825 : ~ @Equation825 Fin4 reff402_inst.
Proof. unfold Equation825. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff402_inst, reff402_op in H. discriminate H. Qed.

Lemma reff402_not826 : ~ @Equation826 Fin4 reff402_inst.
Proof. unfold Equation826. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff402_inst, reff402_op in H. discriminate H. Qed.

Lemma reff402_not832 : ~ @Equation832 Fin4 reff402_inst.
Proof. unfold Equation832. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff402_inst, reff402_op in H. discriminate H. Qed.

Lemma reff402_not833 : ~ @Equation833 Fin4 reff402_inst.
Proof. unfold Equation833. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff402_inst, reff402_op in H. discriminate H. Qed.

Lemma reff402_not836 : ~ @Equation836 Fin4 reff402_inst.
Proof. unfold Equation836. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff402_inst, reff402_op in H. discriminate H. Qed.

Lemma reff402_not843 : ~ @Equation843 Fin4 reff402_inst.
Proof. unfold Equation843. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff402_inst, reff402_op in H. discriminate H. Qed.

Lemma reff402_not845 : ~ @Equation845 Fin4 reff402_inst.
Proof. unfold Equation845. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff402_inst, reff402_op in H. discriminate H. Qed.

Lemma reff402_not869 : ~ @Equation869 Fin4 reff402_inst.
Proof. unfold Equation869. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff402_inst, reff402_op in H. discriminate H. Qed.

Lemma reff402_not872 : ~ @Equation872 Fin4 reff402_inst.
Proof. unfold Equation872. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff402_inst, reff402_op in H. discriminate H. Qed.

Lemma reff402_not873 : ~ @Equation873 Fin4 reff402_inst.
Proof. unfold Equation873. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff402_inst, reff402_op in H. discriminate H. Qed.

Lemma reff402_not879 : ~ @Equation879 Fin4 reff402_inst.
Proof. unfold Equation879. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff402_inst, reff402_op in H. discriminate H. Qed.

Lemma reff402_not880 : ~ @Equation880 Fin4 reff402_inst.
Proof. unfold Equation880. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff402_inst, reff402_op in H. discriminate H. Qed.

Lemma reff402_not882 : ~ @Equation882 Fin4 reff402_inst.
Proof. unfold Equation882. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff402_inst, reff402_op in H. discriminate H. Qed.

Lemma reff402_not883 : ~ @Equation883 Fin4 reff402_inst.
Proof. unfold Equation883. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff402_inst, reff402_op in H. discriminate H. Qed.

Lemma reff402_not907 : ~ @Equation907 Fin4 reff402_inst.
Proof. unfold Equation907. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff402_inst, reff402_op in H. discriminate H. Qed.

Lemma reff402_not909 : ~ @Equation909 Fin4 reff402_inst.
Proof. unfold Equation909. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff402_inst, reff402_op in H. discriminate H. Qed.

Lemma reff402_not916 : ~ @Equation916 Fin4 reff402_inst.
Proof. unfold Equation916. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff402_inst, reff402_op in H. discriminate H. Qed.

Lemma reff402_not919 : ~ @Equation919 Fin4 reff402_inst.
Proof. unfold Equation919. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff402_inst, reff402_op in H. discriminate H. Qed.

Lemma reff402_not1021 : ~ @Equation1021 Fin4 reff402_inst.
Proof. unfold Equation1021. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff402_inst, reff402_op in H. discriminate H. Qed.

Lemma reff402_not1022 : ~ @Equation1022 Fin4 reff402_inst.
Proof. unfold Equation1022. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff402_inst, reff402_op in H. discriminate H. Qed.

Lemma reff402_not1025 : ~ @Equation1025 Fin4 reff402_inst.
Proof. unfold Equation1025. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff402_inst, reff402_op in H. discriminate H. Qed.

Lemma reff402_not1026 : ~ @Equation1026 Fin4 reff402_inst.
Proof. unfold Equation1026. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff402_inst, reff402_op in H. discriminate H. Qed.

Lemma reff402_not1029 : ~ @Equation1029 Fin4 reff402_inst.
Proof. unfold Equation1029. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff402_inst, reff402_op in H. discriminate H. Qed.

Lemma reff402_not1035 : ~ @Equation1035 Fin4 reff402_inst.
Proof. unfold Equation1035. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff402_inst, reff402_op in H. discriminate H. Qed.

Lemma reff402_not1038 : ~ @Equation1038 Fin4 reff402_inst.
Proof. unfold Equation1038. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff402_inst, reff402_op in H. discriminate H. Qed.

Lemma reff402_not1039 : ~ @Equation1039 Fin4 reff402_inst.
Proof. unfold Equation1039. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff402_inst, reff402_op in H. discriminate H. Qed.

Lemma reff402_not1046 : ~ @Equation1046 Fin4 reff402_inst.
Proof. unfold Equation1046. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff402_inst, reff402_op in H. discriminate H. Qed.

Lemma reff402_not1048 : ~ @Equation1048 Fin4 reff402_inst.
Proof. unfold Equation1048. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff402_inst, reff402_op in H. discriminate H. Qed.

Lemma reff402_not1072 : ~ @Equation1072 Fin4 reff402_inst.
Proof. unfold Equation1072. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff402_inst, reff402_op in H. discriminate H. Qed.

Lemma reff402_not1073 : ~ @Equation1073 Fin4 reff402_inst.
Proof. unfold Equation1073. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff402_inst, reff402_op in H. discriminate H. Qed.

Lemma reff402_not1076 : ~ @Equation1076 Fin4 reff402_inst.
Proof. unfold Equation1076. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff402_inst, reff402_op in H. discriminate H. Qed.

Lemma reff402_not1082 : ~ @Equation1082 Fin4 reff402_inst.
Proof. unfold Equation1082. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff402_inst, reff402_op in H. discriminate H. Qed.

Lemma reff402_not1083 : ~ @Equation1083 Fin4 reff402_inst.
Proof. unfold Equation1083. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff402_inst, reff402_op in H. discriminate H. Qed.

Lemma reff402_not1085 : ~ @Equation1085 Fin4 reff402_inst.
Proof. unfold Equation1085. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff402_inst, reff402_op in H. discriminate H. Qed.

Lemma reff402_not1086 : ~ @Equation1086 Fin4 reff402_inst.
Proof. unfold Equation1086. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff402_inst, reff402_op in H. discriminate H. Qed.

Lemma reff402_not1110 : ~ @Equation1110 Fin4 reff402_inst.
Proof. unfold Equation1110. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff402_inst, reff402_op in H. discriminate H. Qed.

Lemma reff402_not1112 : ~ @Equation1112 Fin4 reff402_inst.
Proof. unfold Equation1112. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff402_inst, reff402_op in H. discriminate H. Qed.

Lemma reff402_not1119 : ~ @Equation1119 Fin4 reff402_inst.
Proof. unfold Equation1119. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff402_inst, reff402_op in H. discriminate H. Qed.

Lemma reff402_not1120 : ~ @Equation1120 Fin4 reff402_inst.
Proof. unfold Equation1120. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff402_inst, reff402_op in H. discriminate H. Qed.

Lemma reff402_not1223 : ~ @Equation1223 Fin4 reff402_inst.
Proof. unfold Equation1223. intro H. specialize (H F4_1). unfold magma_op, reff402_inst, reff402_op in H. discriminate H. Qed.

Lemma reff402_not1426 : ~ @Equation1426 Fin4 reff402_inst.
Proof. unfold Equation1426. intro H. specialize (H F4_1). unfold magma_op, reff402_inst, reff402_op in H. discriminate H. Qed.

Lemma reff402_not1630 : ~ @Equation1630 Fin4 reff402_inst.
Proof. unfold Equation1630. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff402_inst, reff402_op in H. discriminate H. Qed.

Lemma reff402_not1631 : ~ @Equation1631 Fin4 reff402_inst.
Proof. unfold Equation1631. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff402_inst, reff402_op in H. discriminate H. Qed.

Lemma reff402_not1632 : ~ @Equation1632 Fin4 reff402_inst.
Proof. unfold Equation1632. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff402_inst, reff402_op in H. discriminate H. Qed.

Lemma reff402_not1634 : ~ @Equation1634 Fin4 reff402_inst.
Proof. unfold Equation1634. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff402_inst, reff402_op in H. discriminate H. Qed.

Lemma reff402_not1638 : ~ @Equation1638 Fin4 reff402_inst.
Proof. unfold Equation1638. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff402_inst, reff402_op in H. discriminate H. Qed.

Lemma reff402_not1644 : ~ @Equation1644 Fin4 reff402_inst.
Proof. unfold Equation1644. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff402_inst, reff402_op in H. discriminate H. Qed.

Lemma reff402_not1648 : ~ @Equation1648 Fin4 reff402_inst.
Proof. unfold Equation1648. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff402_inst, reff402_op in H. discriminate H. Qed.

Lemma reff402_not1654 : ~ @Equation1654 Fin4 reff402_inst.
Proof. unfold Equation1654. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff402_inst, reff402_op in H. discriminate H. Qed.

Lemma reff402_not1655 : ~ @Equation1655 Fin4 reff402_inst.
Proof. unfold Equation1655. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff402_inst, reff402_op in H. discriminate H. Qed.

Lemma reff402_not1657 : ~ @Equation1657 Fin4 reff402_inst.
Proof. unfold Equation1657. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff402_inst, reff402_op in H. discriminate H. Qed.

Lemma reff402_not1681 : ~ @Equation1681 Fin4 reff402_inst.
Proof. unfold Equation1681. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff402_inst, reff402_op in H. discriminate H. Qed.

Lemma reff402_not1682 : ~ @Equation1682 Fin4 reff402_inst.
Proof. unfold Equation1682. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff402_inst, reff402_op in H. discriminate H. Qed.

Lemma reff402_not1684 : ~ @Equation1684 Fin4 reff402_inst.
Proof. unfold Equation1684. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff402_inst, reff402_op in H. discriminate H. Qed.

Lemma reff402_not1685 : ~ @Equation1685 Fin4 reff402_inst.
Proof. unfold Equation1685. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff402_inst, reff402_op in H. discriminate H. Qed.

Lemma reff402_not1692 : ~ @Equation1692 Fin4 reff402_inst.
Proof. unfold Equation1692. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff402_inst, reff402_op in H. discriminate H. Qed.

Lemma reff402_not1694 : ~ @Equation1694 Fin4 reff402_inst.
Proof. unfold Equation1694. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff402_inst, reff402_op in H. discriminate H. Qed.

Lemma reff402_not1695 : ~ @Equation1695 Fin4 reff402_inst.
Proof. unfold Equation1695. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff402_inst, reff402_op in H. discriminate H. Qed.

Lemma reff402_not1719 : ~ @Equation1719 Fin4 reff402_inst.
Proof. unfold Equation1719. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff402_inst, reff402_op in H. discriminate H. Qed.

Lemma reff402_not1721 : ~ @Equation1721 Fin4 reff402_inst.
Proof. unfold Equation1721. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff402_inst, reff402_op in H. discriminate H. Qed.

Lemma reff402_not1722 : ~ @Equation1722 Fin4 reff402_inst.
Proof. unfold Equation1722. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff402_inst, reff402_op in H. discriminate H. Qed.

Lemma reff402_not1728 : ~ @Equation1728 Fin4 reff402_inst.
Proof. unfold Equation1728. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff402_inst, reff402_op in H. discriminate H. Qed.

Lemma reff402_not1833 : ~ @Equation1833 Fin4 reff402_inst.
Proof. unfold Equation1833. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff402_inst, reff402_op in H. discriminate H. Qed.

Lemma reff402_not1834 : ~ @Equation1834 Fin4 reff402_inst.
Proof. unfold Equation1834. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff402_inst, reff402_op in H. discriminate H. Qed.

Lemma reff402_not1837 : ~ @Equation1837 Fin4 reff402_inst.
Proof. unfold Equation1837. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff402_inst, reff402_op in H. discriminate H. Qed.

Lemma reff402_not1838 : ~ @Equation1838 Fin4 reff402_inst.
Proof. unfold Equation1838. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff402_inst, reff402_op in H. discriminate H. Qed.

Lemma reff402_not1841 : ~ @Equation1841 Fin4 reff402_inst.
Proof. unfold Equation1841. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff402_inst, reff402_op in H. discriminate H. Qed.

Lemma reff402_not1847 : ~ @Equation1847 Fin4 reff402_inst.
Proof. unfold Equation1847. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff402_inst, reff402_op in H. discriminate H. Qed.

Lemma reff402_not1850 : ~ @Equation1850 Fin4 reff402_inst.
Proof. unfold Equation1850. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff402_inst, reff402_op in H. discriminate H. Qed.

Lemma reff402_not1851 : ~ @Equation1851 Fin4 reff402_inst.
Proof. unfold Equation1851. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff402_inst, reff402_op in H. discriminate H. Qed.

Lemma reff402_not1858 : ~ @Equation1858 Fin4 reff402_inst.
Proof. unfold Equation1858. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff402_inst, reff402_op in H. discriminate H. Qed.

Lemma reff402_not1860 : ~ @Equation1860 Fin4 reff402_inst.
Proof. unfold Equation1860. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff402_inst, reff402_op in H. discriminate H. Qed.

Lemma reff402_not1884 : ~ @Equation1884 Fin4 reff402_inst.
Proof. unfold Equation1884. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff402_inst, reff402_op in H. discriminate H. Qed.

Lemma reff402_not1885 : ~ @Equation1885 Fin4 reff402_inst.
Proof. unfold Equation1885. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff402_inst, reff402_op in H. discriminate H. Qed.

Lemma reff402_not1888 : ~ @Equation1888 Fin4 reff402_inst.
Proof. unfold Equation1888. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff402_inst, reff402_op in H. discriminate H. Qed.

Lemma reff402_not1894 : ~ @Equation1894 Fin4 reff402_inst.
Proof. unfold Equation1894. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff402_inst, reff402_op in H. discriminate H. Qed.

Lemma reff402_not1895 : ~ @Equation1895 Fin4 reff402_inst.
Proof. unfold Equation1895. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff402_inst, reff402_op in H. discriminate H. Qed.

Lemma reff402_not1897 : ~ @Equation1897 Fin4 reff402_inst.
Proof. unfold Equation1897. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff402_inst, reff402_op in H. discriminate H. Qed.

Lemma reff402_not1898 : ~ @Equation1898 Fin4 reff402_inst.
Proof. unfold Equation1898. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff402_inst, reff402_op in H. discriminate H. Qed.

Lemma reff402_not1922 : ~ @Equation1922 Fin4 reff402_inst.
Proof. unfold Equation1922. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff402_inst, reff402_op in H. discriminate H. Qed.

Lemma reff402_not1924 : ~ @Equation1924 Fin4 reff402_inst.
Proof. unfold Equation1924. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff402_inst, reff402_op in H. discriminate H. Qed.

Lemma reff402_not1931 : ~ @Equation1931 Fin4 reff402_inst.
Proof. unfold Equation1931. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff402_inst, reff402_op in H. discriminate H. Qed.

Lemma reff402_not1932 : ~ @Equation1932 Fin4 reff402_inst.
Proof. unfold Equation1932. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff402_inst, reff402_op in H. discriminate H. Qed.

Lemma reff402_not2035 : ~ @Equation2035 Fin4 reff402_inst.
Proof. unfold Equation2035. intro H. specialize (H F4_1). unfold magma_op, reff402_inst, reff402_op in H. discriminate H. Qed.

Lemma reff402_not2238 : ~ @Equation2238 Fin4 reff402_inst.
Proof. unfold Equation2238. intro H. specialize (H F4_1). unfold magma_op, reff402_inst, reff402_op in H. discriminate H. Qed.

Lemma reff402_not2442 : ~ @Equation2442 Fin4 reff402_inst.
Proof. unfold Equation2442. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff402_inst, reff402_op in H. discriminate H. Qed.

Lemma reff402_not2443 : ~ @Equation2443 Fin4 reff402_inst.
Proof. unfold Equation2443. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff402_inst, reff402_op in H. discriminate H. Qed.

Lemma reff402_not2446 : ~ @Equation2446 Fin4 reff402_inst.
Proof. unfold Equation2446. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff402_inst, reff402_op in H. discriminate H. Qed.

Lemma reff402_not2449 : ~ @Equation2449 Fin4 reff402_inst.
Proof. unfold Equation2449. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff402_inst, reff402_op in H. discriminate H. Qed.

Lemma reff402_not2450 : ~ @Equation2450 Fin4 reff402_inst.
Proof. unfold Equation2450. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff402_inst, reff402_op in H. discriminate H. Qed.

Lemma reff402_not2456 : ~ @Equation2456 Fin4 reff402_inst.
Proof. unfold Equation2456. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff402_inst, reff402_op in H. discriminate H. Qed.

Lemma reff402_not2457 : ~ @Equation2457 Fin4 reff402_inst.
Proof. unfold Equation2457. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff402_inst, reff402_op in H. discriminate H. Qed.

Lemma reff402_not2460 : ~ @Equation2460 Fin4 reff402_inst.
Proof. unfold Equation2460. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff402_inst, reff402_op in H. discriminate H. Qed.

Lemma reff402_not2467 : ~ @Equation2467 Fin4 reff402_inst.
Proof. unfold Equation2467. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff402_inst, reff402_op in H. discriminate H. Qed.

Lemma reff402_not2469 : ~ @Equation2469 Fin4 reff402_inst.
Proof. unfold Equation2469. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff402_inst, reff402_op in H. discriminate H. Qed.

Lemma reff402_not2493 : ~ @Equation2493 Fin4 reff402_inst.
Proof. unfold Equation2493. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff402_inst, reff402_op in H. discriminate H. Qed.

Lemma reff402_not2496 : ~ @Equation2496 Fin4 reff402_inst.
Proof. unfold Equation2496. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff402_inst, reff402_op in H. discriminate H. Qed.

Lemma reff402_not2497 : ~ @Equation2497 Fin4 reff402_inst.
Proof. unfold Equation2497. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff402_inst, reff402_op in H. discriminate H. Qed.

Lemma reff402_not2503 : ~ @Equation2503 Fin4 reff402_inst.
Proof. unfold Equation2503. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff402_inst, reff402_op in H. discriminate H. Qed.

Lemma reff402_not2504 : ~ @Equation2504 Fin4 reff402_inst.
Proof. unfold Equation2504. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff402_inst, reff402_op in H. discriminate H. Qed.

Lemma reff402_not2506 : ~ @Equation2506 Fin4 reff402_inst.
Proof. unfold Equation2506. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff402_inst, reff402_op in H. discriminate H. Qed.

Lemma reff402_not2507 : ~ @Equation2507 Fin4 reff402_inst.
Proof. unfold Equation2507. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff402_inst, reff402_op in H. discriminate H. Qed.

Lemma reff402_not2531 : ~ @Equation2531 Fin4 reff402_inst.
Proof. unfold Equation2531. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff402_inst, reff402_op in H. discriminate H. Qed.

Lemma reff402_not2533 : ~ @Equation2533 Fin4 reff402_inst.
Proof. unfold Equation2533. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff402_inst, reff402_op in H. discriminate H. Qed.

Lemma reff402_not2540 : ~ @Equation2540 Fin4 reff402_inst.
Proof. unfold Equation2540. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff402_inst, reff402_op in H. discriminate H. Qed.

Lemma reff402_not2543 : ~ @Equation2543 Fin4 reff402_inst.
Proof. unfold Equation2543. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff402_inst, reff402_op in H. discriminate H. Qed.

Lemma reff402_not2644 : ~ @Equation2644 Fin4 reff402_inst.
Proof. unfold Equation2644. intro H. specialize (H F4_1). unfold magma_op, reff402_inst, reff402_op in H. discriminate H. Qed.

Lemma reff402_not2847 : ~ @Equation2847 Fin4 reff402_inst.
Proof. unfold Equation2847. intro H. specialize (H F4_1). unfold magma_op, reff402_inst, reff402_op in H. discriminate H. Qed.

Lemma reff402_not3051 : ~ @Equation3051 Fin4 reff402_inst.
Proof. unfold Equation3051. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff402_inst, reff402_op in H. discriminate H. Qed.

Lemma reff402_not3052 : ~ @Equation3052 Fin4 reff402_inst.
Proof. unfold Equation3052. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff402_inst, reff402_op in H. discriminate H. Qed.

Lemma reff402_not3053 : ~ @Equation3053 Fin4 reff402_inst.
Proof. unfold Equation3053. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff402_inst, reff402_op in H. discriminate H. Qed.

Lemma reff402_not3055 : ~ @Equation3055 Fin4 reff402_inst.
Proof. unfold Equation3055. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff402_inst, reff402_op in H. discriminate H. Qed.

Lemma reff402_not3056 : ~ @Equation3056 Fin4 reff402_inst.
Proof. unfold Equation3056. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff402_inst, reff402_op in H. discriminate H. Qed.

Lemma reff402_not3058 : ~ @Equation3058 Fin4 reff402_inst.
Proof. unfold Equation3058. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff402_inst, reff402_op in H. discriminate H. Qed.

Lemma reff402_not3059 : ~ @Equation3059 Fin4 reff402_inst.
Proof. unfold Equation3059. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff402_inst, reff402_op in H. discriminate H. Qed.

Lemma reff402_not3065 : ~ @Equation3065 Fin4 reff402_inst.
Proof. unfold Equation3065. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff402_inst, reff402_op in H. discriminate H. Qed.

Lemma reff402_not3066 : ~ @Equation3066 Fin4 reff402_inst.
Proof. unfold Equation3066. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff402_inst, reff402_op in H. discriminate H. Qed.

Lemma reff402_not3068 : ~ @Equation3068 Fin4 reff402_inst.
Proof. unfold Equation3068. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff402_inst, reff402_op in H. discriminate H. Qed.

Lemma reff402_not3069 : ~ @Equation3069 Fin4 reff402_inst.
Proof. unfold Equation3069. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff402_inst, reff402_op in H. discriminate H. Qed.

Lemma reff402_not3075 : ~ @Equation3075 Fin4 reff402_inst.
Proof. unfold Equation3075. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff402_inst, reff402_op in H. discriminate H. Qed.

Lemma reff402_not3076 : ~ @Equation3076 Fin4 reff402_inst.
Proof. unfold Equation3076. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff402_inst, reff402_op in H. discriminate H. Qed.

Lemma reff402_not3078 : ~ @Equation3078 Fin4 reff402_inst.
Proof. unfold Equation3078. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff402_inst, reff402_op in H. discriminate H. Qed.

Lemma reff402_not3102 : ~ @Equation3102 Fin4 reff402_inst.
Proof. unfold Equation3102. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff402_inst, reff402_op in H. discriminate H. Qed.

Lemma reff402_not3106 : ~ @Equation3106 Fin4 reff402_inst.
Proof. unfold Equation3106. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff402_inst, reff402_op in H. discriminate H. Qed.

Lemma reff402_not3113 : ~ @Equation3113 Fin4 reff402_inst.
Proof. unfold Equation3113. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff402_inst, reff402_op in H. discriminate H. Qed.

Lemma reff402_not3115 : ~ @Equation3115 Fin4 reff402_inst.
Proof. unfold Equation3115. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff402_inst, reff402_op in H. discriminate H. Qed.

Lemma reff402_not3116 : ~ @Equation3116 Fin4 reff402_inst.
Proof. unfold Equation3116. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff402_inst, reff402_op in H. discriminate H. Qed.

Lemma reff402_not3140 : ~ @Equation3140 Fin4 reff402_inst.
Proof. unfold Equation3140. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff402_inst, reff402_op in H. discriminate H. Qed.

Lemma reff402_not3142 : ~ @Equation3142 Fin4 reff402_inst.
Proof. unfold Equation3142. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff402_inst, reff402_op in H. discriminate H. Qed.

Lemma reff402_not3143 : ~ @Equation3143 Fin4 reff402_inst.
Proof. unfold Equation3143. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff402_inst, reff402_op in H. discriminate H. Qed.

Lemma reff402_not3149 : ~ @Equation3149 Fin4 reff402_inst.
Proof. unfold Equation3149. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff402_inst, reff402_op in H. discriminate H. Qed.

Lemma reff402_not3150 : ~ @Equation3150 Fin4 reff402_inst.
Proof. unfold Equation3150. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff402_inst, reff402_op in H. discriminate H. Qed.

Lemma reff402_not3152 : ~ @Equation3152 Fin4 reff402_inst.
Proof. unfold Equation3152. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff402_inst, reff402_op in H. discriminate H. Qed.

Lemma reff402_not3254 : ~ @Equation3254 Fin4 reff402_inst.
Proof. unfold Equation3254. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff402_inst, reff402_op in H. discriminate H. Qed.

Lemma reff402_not3255 : ~ @Equation3255 Fin4 reff402_inst.
Proof. unfold Equation3255. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff402_inst, reff402_op in H. discriminate H. Qed.

Lemma reff402_not3258 : ~ @Equation3258 Fin4 reff402_inst.
Proof. unfold Equation3258. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff402_inst, reff402_op in H. discriminate H. Qed.

Lemma reff402_not3259 : ~ @Equation3259 Fin4 reff402_inst.
Proof. unfold Equation3259. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff402_inst, reff402_op in H. discriminate H. Qed.

Lemma reff402_not3262 : ~ @Equation3262 Fin4 reff402_inst.
Proof. unfold Equation3262. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff402_inst, reff402_op in H. discriminate H. Qed.

Lemma reff402_not3268 : ~ @Equation3268 Fin4 reff402_inst.
Proof. unfold Equation3268. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff402_inst, reff402_op in H. discriminate H. Qed.

Lemma reff402_not3271 : ~ @Equation3271 Fin4 reff402_inst.
Proof. unfold Equation3271. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff402_inst, reff402_op in H. discriminate H. Qed.

Lemma reff402_not3272 : ~ @Equation3272 Fin4 reff402_inst.
Proof. unfold Equation3272. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff402_inst, reff402_op in H. discriminate H. Qed.

Lemma reff402_not3279 : ~ @Equation3279 Fin4 reff402_inst.
Proof. unfold Equation3279. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff402_inst, reff402_op in H. discriminate H. Qed.

Lemma reff402_not3281 : ~ @Equation3281 Fin4 reff402_inst.
Proof. unfold Equation3281. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff402_inst, reff402_op in H. discriminate H. Qed.

Lemma reff402_not3308 : ~ @Equation3308 Fin4 reff402_inst.
Proof. unfold Equation3308. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff402_inst, reff402_op in H. discriminate H. Qed.

Lemma reff402_not3309 : ~ @Equation3309 Fin4 reff402_inst.
Proof. unfold Equation3309. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff402_inst, reff402_op in H. discriminate H. Qed.

Lemma reff402_not3316 : ~ @Equation3316 Fin4 reff402_inst.
Proof. unfold Equation3316. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff402_inst, reff402_op in H. discriminate H. Qed.

Lemma reff402_not3318 : ~ @Equation3318 Fin4 reff402_inst.
Proof. unfold Equation3318. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff402_inst, reff402_op in H. discriminate H. Qed.

Lemma reff402_not3342 : ~ @Equation3342 Fin4 reff402_inst.
Proof. unfold Equation3342. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff402_inst, reff402_op in H. discriminate H. Qed.

Lemma reff402_not3343 : ~ @Equation3343 Fin4 reff402_inst.
Proof. unfold Equation3343. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff402_inst, reff402_op in H. discriminate H. Qed.

Lemma reff402_not3345 : ~ @Equation3345 Fin4 reff402_inst.
Proof. unfold Equation3345. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff402_inst, reff402_op in H. discriminate H. Qed.

Lemma reff402_not3346 : ~ @Equation3346 Fin4 reff402_inst.
Proof. unfold Equation3346. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff402_inst, reff402_op in H. discriminate H. Qed.

Lemma reff402_not3352 : ~ @Equation3352 Fin4 reff402_inst.
Proof. unfold Equation3352. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff402_inst, reff402_op in H. discriminate H. Qed.

Lemma reff402_not3456 : ~ @Equation3456 Fin4 reff402_inst.
Proof. unfold Equation3456. intro H. specialize (H F4_1). unfold magma_op, reff402_inst, reff402_op in H. discriminate H. Qed.

Lemma reff402_not3660 : ~ @Equation3660 Fin4 reff402_inst.
Proof. unfold Equation3660. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff402_inst, reff402_op in H. discriminate H. Qed.

Lemma reff402_not3661 : ~ @Equation3661 Fin4 reff402_inst.
Proof. unfold Equation3661. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff402_inst, reff402_op in H. discriminate H. Qed.

Lemma reff402_not3664 : ~ @Equation3664 Fin4 reff402_inst.
Proof. unfold Equation3664. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff402_inst, reff402_op in H. discriminate H. Qed.

Lemma reff402_not3667 : ~ @Equation3667 Fin4 reff402_inst.
Proof. unfold Equation3667. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff402_inst, reff402_op in H. discriminate H. Qed.

Lemma reff402_not3668 : ~ @Equation3668 Fin4 reff402_inst.
Proof. unfold Equation3668. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff402_inst, reff402_op in H. discriminate H. Qed.

Lemma reff402_not3674 : ~ @Equation3674 Fin4 reff402_inst.
Proof. unfold Equation3674. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff402_inst, reff402_op in H. discriminate H. Qed.

Lemma reff402_not3675 : ~ @Equation3675 Fin4 reff402_inst.
Proof. unfold Equation3675. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff402_inst, reff402_op in H. discriminate H. Qed.

Lemma reff402_not3678 : ~ @Equation3678 Fin4 reff402_inst.
Proof. unfold Equation3678. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff402_inst, reff402_op in H. discriminate H. Qed.

Lemma reff402_not3685 : ~ @Equation3685 Fin4 reff402_inst.
Proof. unfold Equation3685. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff402_inst, reff402_op in H. discriminate H. Qed.

Lemma reff402_not3687 : ~ @Equation3687 Fin4 reff402_inst.
Proof. unfold Equation3687. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff402_inst, reff402_op in H. discriminate H. Qed.

Lemma reff402_not3712 : ~ @Equation3712 Fin4 reff402_inst.
Proof. unfold Equation3712. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff402_inst, reff402_op in H. discriminate H. Qed.

Lemma reff402_not3722 : ~ @Equation3722 Fin4 reff402_inst.
Proof. unfold Equation3722. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff402_inst, reff402_op in H. discriminate H. Qed.

Lemma reff402_not3724 : ~ @Equation3724 Fin4 reff402_inst.
Proof. unfold Equation3724. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff402_inst, reff402_op in H. discriminate H. Qed.

Lemma reff402_not3748 : ~ @Equation3748 Fin4 reff402_inst.
Proof. unfold Equation3748. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff402_inst, reff402_op in H. discriminate H. Qed.

Lemma reff402_not3749 : ~ @Equation3749 Fin4 reff402_inst.
Proof. unfold Equation3749. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff402_inst, reff402_op in H. discriminate H. Qed.

Lemma reff402_not3751 : ~ @Equation3751 Fin4 reff402_inst.
Proof. unfold Equation3751. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff402_inst, reff402_op in H. discriminate H. Qed.

Lemma reff402_not3752 : ~ @Equation3752 Fin4 reff402_inst.
Proof. unfold Equation3752. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff402_inst, reff402_op in H. discriminate H. Qed.

Lemma reff402_not3759 : ~ @Equation3759 Fin4 reff402_inst.
Proof. unfold Equation3759. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff402_inst, reff402_op in H. discriminate H. Qed.

Lemma reff402_not3864 : ~ @Equation3864 Fin4 reff402_inst.
Proof. unfold Equation3864. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff402_inst, reff402_op in H. discriminate H. Qed.

Lemma reff402_not3867 : ~ @Equation3867 Fin4 reff402_inst.
Proof. unfold Equation3867. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff402_inst, reff402_op in H. discriminate H. Qed.

Lemma reff402_not3868 : ~ @Equation3868 Fin4 reff402_inst.
Proof. unfold Equation3868. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff402_inst, reff402_op in H. discriminate H. Qed.

Lemma reff402_not3871 : ~ @Equation3871 Fin4 reff402_inst.
Proof. unfold Equation3871. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff402_inst, reff402_op in H. discriminate H. Qed.

Lemma reff402_not3877 : ~ @Equation3877 Fin4 reff402_inst.
Proof. unfold Equation3877. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff402_inst, reff402_op in H. discriminate H. Qed.

Lemma reff402_not3880 : ~ @Equation3880 Fin4 reff402_inst.
Proof. unfold Equation3880. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff402_inst, reff402_op in H. discriminate H. Qed.

Lemma reff402_not3881 : ~ @Equation3881 Fin4 reff402_inst.
Proof. unfold Equation3881. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff402_inst, reff402_op in H. discriminate H. Qed.

Lemma reff402_not3888 : ~ @Equation3888 Fin4 reff402_inst.
Proof. unfold Equation3888. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff402_inst, reff402_op in H. discriminate H. Qed.

Lemma reff402_not3890 : ~ @Equation3890 Fin4 reff402_inst.
Proof. unfold Equation3890. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff402_inst, reff402_op in H. discriminate H. Qed.

Lemma reff402_not3917 : ~ @Equation3917 Fin4 reff402_inst.
Proof. unfold Equation3917. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff402_inst, reff402_op in H. discriminate H. Qed.

Lemma reff402_not3918 : ~ @Equation3918 Fin4 reff402_inst.
Proof. unfold Equation3918. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff402_inst, reff402_op in H. discriminate H. Qed.

Lemma reff402_not3925 : ~ @Equation3925 Fin4 reff402_inst.
Proof. unfold Equation3925. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff402_inst, reff402_op in H. discriminate H. Qed.

Lemma reff402_not3927 : ~ @Equation3927 Fin4 reff402_inst.
Proof. unfold Equation3927. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff402_inst, reff402_op in H. discriminate H. Qed.

Lemma reff402_not3951 : ~ @Equation3951 Fin4 reff402_inst.
Proof. unfold Equation3951. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff402_inst, reff402_op in H. discriminate H. Qed.

Lemma reff402_not3952 : ~ @Equation3952 Fin4 reff402_inst.
Proof. unfold Equation3952. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff402_inst, reff402_op in H. discriminate H. Qed.

Lemma reff402_not3954 : ~ @Equation3954 Fin4 reff402_inst.
Proof. unfold Equation3954. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff402_inst, reff402_op in H. discriminate H. Qed.

Lemma reff402_not3955 : ~ @Equation3955 Fin4 reff402_inst.
Proof. unfold Equation3955. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff402_inst, reff402_op in H. discriminate H. Qed.

Lemma reff402_not3961 : ~ @Equation3961 Fin4 reff402_inst.
Proof. unfold Equation3961. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff402_inst, reff402_op in H. discriminate H. Qed.

Lemma reff402_not3964 : ~ @Equation3964 Fin4 reff402_inst.
Proof. unfold Equation3964. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff402_inst, reff402_op in H. discriminate H. Qed.

Lemma reff402_not4065 : ~ @Equation4065 Fin4 reff402_inst.
Proof. unfold Equation4065. intro H. specialize (H F4_1). unfold magma_op, reff402_inst, reff402_op in H. discriminate H. Qed.

Lemma reff402_not4268 : ~ @Equation4268 Fin4 reff402_inst.
Proof. unfold Equation4268. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff402_inst, reff402_op in H. discriminate H. Qed.

Lemma reff402_not4269 : ~ @Equation4269 Fin4 reff402_inst.
Proof. unfold Equation4269. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff402_inst, reff402_op in H. discriminate H. Qed.

Lemma reff402_not4272 : ~ @Equation4272 Fin4 reff402_inst.
Proof. unfold Equation4272. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff402_inst, reff402_op in H. discriminate H. Qed.

Lemma reff402_not4273 : ~ @Equation4273 Fin4 reff402_inst.
Proof. unfold Equation4273. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff402_inst, reff402_op in H. discriminate H. Qed.

Lemma reff402_not4276 : ~ @Equation4276 Fin4 reff402_inst.
Proof. unfold Equation4276. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff402_inst, reff402_op in H. discriminate H. Qed.

Lemma reff402_not4283 : ~ @Equation4283 Fin4 reff402_inst.
Proof. unfold Equation4283. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff402_inst, reff402_op in H. discriminate H. Qed.

Lemma reff402_not4284 : ~ @Equation4284 Fin4 reff402_inst.
Proof. unfold Equation4284. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff402_inst, reff402_op in H. discriminate H. Qed.

Lemma reff402_not4291 : ~ @Equation4291 Fin4 reff402_inst.
Proof. unfold Equation4291. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff402_inst, reff402_op in H. discriminate H. Qed.

Lemma reff402_not4293 : ~ @Equation4293 Fin4 reff402_inst.
Proof. unfold Equation4293. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff402_inst, reff402_op in H. discriminate H. Qed.

Lemma reff402_not4314 : ~ @Equation4314 Fin4 reff402_inst.
Proof. unfold Equation4314. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff402_inst, reff402_op in H. discriminate H. Qed.

Lemma reff402_not4320 : ~ @Equation4320 Fin4 reff402_inst.
Proof. unfold Equation4320. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff402_inst, reff402_op in H. discriminate H. Qed.

Lemma reff402_not4321 : ~ @Equation4321 Fin4 reff402_inst.
Proof. unfold Equation4321. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff402_inst, reff402_op in H. discriminate H. Qed.

Lemma reff402_not4343 : ~ @Equation4343 Fin4 reff402_inst.
Proof. unfold Equation4343. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff402_inst, reff402_op in H. discriminate H. Qed.

Lemma reff402_not4380 : ~ @Equation4380 Fin4 reff402_inst.
Proof. unfold Equation4380. intro H. specialize (H F4_1). unfold magma_op, reff402_inst, reff402_op in H. discriminate H. Qed.

Lemma reff402_not4583 : ~ @Equation4583 Fin4 reff402_inst.
Proof. unfold Equation4583. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff402_inst, reff402_op in H. discriminate H. Qed.

Lemma reff402_not4584 : ~ @Equation4584 Fin4 reff402_inst.
Proof. unfold Equation4584. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff402_inst, reff402_op in H. discriminate H. Qed.

Lemma reff402_not4585 : ~ @Equation4585 Fin4 reff402_inst.
Proof. unfold Equation4585. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff402_inst, reff402_op in H. discriminate H. Qed.

Lemma reff402_not4587 : ~ @Equation4587 Fin4 reff402_inst.
Proof. unfold Equation4587. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff402_inst, reff402_op in H. discriminate H. Qed.

Lemma reff402_not4591 : ~ @Equation4591 Fin4 reff402_inst.
Proof. unfold Equation4591. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff402_inst, reff402_op in H. discriminate H. Qed.

Lemma reff402_not4599 : ~ @Equation4599 Fin4 reff402_inst.
Proof. unfold Equation4599. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff402_inst, reff402_op in H. discriminate H. Qed.

Lemma reff402_not4605 : ~ @Equation4605 Fin4 reff402_inst.
Proof. unfold Equation4605. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff402_inst, reff402_op in H. discriminate H. Qed.

Lemma reff402_not4606 : ~ @Equation4606 Fin4 reff402_inst.
Proof. unfold Equation4606. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff402_inst, reff402_op in H. discriminate H. Qed.

Lemma reff402_not4608 : ~ @Equation4608 Fin4 reff402_inst.
Proof. unfold Equation4608. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff402_inst, reff402_op in H. discriminate H. Qed.

Lemma reff402_not4629 : ~ @Equation4629 Fin4 reff402_inst.
Proof. unfold Equation4629. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff402_inst, reff402_op in H. discriminate H. Qed.

Lemma reff402_not4635 : ~ @Equation4635 Fin4 reff402_inst.
Proof. unfold Equation4635. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff402_inst, reff402_op in H. discriminate H. Qed.

Lemma reff402_not4636 : ~ @Equation4636 Fin4 reff402_inst.
Proof. unfold Equation4636. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff402_inst, reff402_op in H. discriminate H. Qed.

Lemma reff402_not4658 : ~ @Equation4658 Fin4 reff402_inst.
Proof. unfold Equation4658. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff402_inst, reff402_op in H. discriminate H. Qed.

(** ---- reff404 (Fin4) ---- *)

Definition reff404_op (x y : Fin4) : Fin4 :=
  match x, y with
  | F4_0, F4_0 => F4_0 | F4_0, F4_1 => F4_3 | F4_0, F4_2 => F4_2 | F4_0, F4_3 => F4_1
  | F4_1, F4_0 => F4_0 | F4_1, F4_1 => F4_1 | F4_1, F4_2 => F4_2 | F4_1, F4_3 => F4_3
  | F4_2, F4_0 => F4_0 | F4_2, F4_1 => F4_3 | F4_2, F4_2 => F4_2 | F4_2, F4_3 => F4_1
  | F4_3, F4_0 => F4_0 | F4_3, F4_1 => F4_1 | F4_3, F4_2 => F4_2 | F4_3, F4_3 => F4_3
  end.

#[local] Instance reff404_inst : Magma Fin4 := {| magma_op := reff404_op |}.

Lemma reff404_sat16 : @Equation16 Fin4 reff404_inst.
Proof. unfold Equation16, magma_op, reff404_inst, reff404_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff404_sat28 : @Equation28 Fin4 reff404_inst.
Proof. unfold Equation28, magma_op, reff404_inst, reff404_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff404_sat55 : @Equation55 Fin4 reff404_inst.
Proof. unfold Equation55, magma_op, reff404_inst, reff404_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff404_sat65 : @Equation65 Fin4 reff404_inst.
Proof. unfold Equation65, magma_op, reff404_inst, reff404_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff404_sat72 : @Equation72 Fin4 reff404_inst.
Proof. unfold Equation72, magma_op, reff404_inst, reff404_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff404_sat138 : @Equation138 Fin4 reff404_inst.
Proof. unfold Equation138, magma_op, reff404_inst, reff404_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff404_sat194 : @Equation194 Fin4 reff404_inst.
Proof. unfold Equation194, magma_op, reff404_inst, reff404_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff404_sat238 : @Equation238 Fin4 reff404_inst.
Proof. unfold Equation238, magma_op, reff404_inst, reff404_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff404_sat315 : @Equation315 Fin4 reff404_inst.
Proof. unfold Equation315, magma_op, reff404_inst, reff404_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff404_sat395 : @Equation395 Fin4 reff404_inst.
Proof. unfold Equation395, magma_op, reff404_inst, reff404_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff404_sat562 : @Equation562 Fin4 reff404_inst.
Proof. unfold Equation562, magma_op, reff404_inst, reff404_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff404_sat653 : @Equation653 Fin4 reff404_inst.
Proof. unfold Equation653, magma_op, reff404_inst, reff404_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff404_sat690 : @Equation690 Fin4 reff404_inst.
Proof. unfold Equation690, magma_op, reff404_inst, reff404_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff404_sat723 : @Equation723 Fin4 reff404_inst.
Proof. unfold Equation723, magma_op, reff404_inst, reff404_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff404_sat860 : @Equation860 Fin4 reff404_inst.
Proof. unfold Equation860, magma_op, reff404_inst, reff404_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff404_sat947 : @Equation947 Fin4 reff404_inst.
Proof. unfold Equation947, magma_op, reff404_inst, reff404_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff404_sat960 : @Equation960 Fin4 reff404_inst.
Proof. unfold Equation960, magma_op, reff404_inst, reff404_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff404_sat1202 : @Equation1202 Fin4 reff404_inst.
Proof. unfold Equation1202, magma_op, reff404_inst, reff404_op. intros x y z w. destruct x, y, z, w; reflexivity. Qed.

Lemma reff404_sat1506 : @Equation1506 Fin4 reff404_inst.
Proof. unfold Equation1506, magma_op, reff404_inst, reff404_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff404_sat1560 : @Equation1560 Fin4 reff404_inst.
Proof. unfold Equation1560, magma_op, reff404_inst, reff404_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff404_sat1586 : @Equation1586 Fin4 reff404_inst.
Proof. unfold Equation1586, magma_op, reff404_inst, reff404_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff404_sat1816 : @Equation1816 Fin4 reff404_inst.
Proof. unfold Equation1816, magma_op, reff404_inst, reff404_op. intros x y z w. destruct x, y, z, w; reflexivity. Qed.

Lemma reff404_sat2024 : @Equation2024 Fin4 reff404_inst.
Proof. unfold Equation2024, magma_op, reff404_inst, reff404_op. intros x y z w. destruct x, y, z, w; reflexivity. Qed.

Lemma reff404_sat2415 : @Equation2415 Fin4 reff404_inst.
Proof. unfold Equation2415, magma_op, reff404_inst, reff404_op. intros x y z w. destruct x, y, z, w; reflexivity. Qed.

Lemma reff404_sat3388 : @Equation3388 Fin4 reff404_inst.
Proof. unfold Equation3388, magma_op, reff404_inst, reff404_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff404_sat3495 : @Equation3495 Fin4 reff404_inst.
Proof. unfold Equation3495, magma_op, reff404_inst, reff404_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff404_sat3566 : @Equation3566 Fin4 reff404_inst.
Proof. unfold Equation3566, magma_op, reff404_inst, reff404_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff404_sat3702 : @Equation3702 Fin4 reff404_inst.
Proof. unfold Equation3702, magma_op, reff404_inst, reff404_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff404_sat3790 : @Equation3790 Fin4 reff404_inst.
Proof. unfold Equation3790, magma_op, reff404_inst, reff404_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff404_sat3803 : @Equation3803 Fin4 reff404_inst.
Proof. unfold Equation3803, magma_op, reff404_inst, reff404_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff404_sat4362 : @Equation4362 Fin4 reff404_inst.
Proof. unfold Equation4362, magma_op, reff404_inst, reff404_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff404_sat4420 : @Equation4420 Fin4 reff404_inst.
Proof. unfold Equation4420, magma_op, reff404_inst, reff404_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff404_sat4456 : @Equation4456 Fin4 reff404_inst.
Proof. unfold Equation4456, magma_op, reff404_inst, reff404_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff404_sat4490 : @Equation4490 Fin4 reff404_inst.
Proof. unfold Equation4490, magma_op, reff404_inst, reff404_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff404_not50 : ~ @Equation50 Fin4 reff404_inst.
Proof. unfold Equation50. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff404_inst, reff404_op in H. discriminate H. Qed.

Lemma reff404_not53 : ~ @Equation53 Fin4 reff404_inst.
Proof. unfold Equation53. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff404_inst, reff404_op in H. discriminate H. Qed.

Lemma reff404_not56 : ~ @Equation56 Fin4 reff404_inst.
Proof. unfold Equation56. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff404_inst, reff404_op in H. discriminate H. Qed.

Lemma reff404_not63 : ~ @Equation63 Fin4 reff404_inst.
Proof. unfold Equation63. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff404_inst, reff404_op in H. discriminate H. Qed.

Lemma reff404_not66 : ~ @Equation66 Fin4 reff404_inst.
Proof. unfold Equation66. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff404_inst, reff404_op in H. discriminate H. Qed.

Lemma reff404_not73 : ~ @Equation73 Fin4 reff404_inst.
Proof. unfold Equation73. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff404_inst, reff404_op in H. discriminate H. Qed.

Lemma reff404_not75 : ~ @Equation75 Fin4 reff404_inst.
Proof. unfold Equation75. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff404_inst, reff404_op in H. discriminate H. Qed.

Lemma reff404_not102 : ~ @Equation102 Fin4 reff404_inst.
Proof. unfold Equation102. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff404_inst, reff404_op in H. discriminate H. Qed.

Lemma reff404_not105 : ~ @Equation105 Fin4 reff404_inst.
Proof. unfold Equation105. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff404_inst, reff404_op in H. discriminate H. Qed.

Lemma reff404_not107 : ~ @Equation107 Fin4 reff404_inst.
Proof. unfold Equation107. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff404_inst, reff404_op in H. discriminate H. Qed.

Lemma reff404_not108 : ~ @Equation108 Fin4 reff404_inst.
Proof. unfold Equation108. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff404_inst, reff404_op in H. discriminate H. Qed.

Lemma reff404_not115 : ~ @Equation115 Fin4 reff404_inst.
Proof. unfold Equation115. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff404_inst, reff404_op in H. discriminate H. Qed.

Lemma reff404_not118 : ~ @Equation118 Fin4 reff404_inst.
Proof. unfold Equation118. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff404_inst, reff404_op in H. discriminate H. Qed.

Lemma reff404_not124 : ~ @Equation124 Fin4 reff404_inst.
Proof. unfold Equation124. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff404_inst, reff404_op in H. discriminate H. Qed.

Lemma reff404_not125 : ~ @Equation125 Fin4 reff404_inst.
Proof. unfold Equation125. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff404_inst, reff404_op in H. discriminate H. Qed.

Lemma reff404_not154 : ~ @Equation154 Fin4 reff404_inst.
Proof. unfold Equation154. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff404_inst, reff404_op in H. discriminate H. Qed.

Lemma reff404_not157 : ~ @Equation157 Fin4 reff404_inst.
Proof. unfold Equation157. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff404_inst, reff404_op in H. discriminate H. Qed.

Lemma reff404_not160 : ~ @Equation160 Fin4 reff404_inst.
Proof. unfold Equation160. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff404_inst, reff404_op in H. discriminate H. Qed.

Lemma reff404_not167 : ~ @Equation167 Fin4 reff404_inst.
Proof. unfold Equation167. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff404_inst, reff404_op in H. discriminate H. Qed.

Lemma reff404_not169 : ~ @Equation169 Fin4 reff404_inst.
Proof. unfold Equation169. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff404_inst, reff404_op in H. discriminate H. Qed.

Lemma reff404_not170 : ~ @Equation170 Fin4 reff404_inst.
Proof. unfold Equation170. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff404_inst, reff404_op in H. discriminate H. Qed.

Lemma reff404_not176 : ~ @Equation176 Fin4 reff404_inst.
Proof. unfold Equation176. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff404_inst, reff404_op in H. discriminate H. Qed.

Lemma reff404_not177 : ~ @Equation177 Fin4 reff404_inst.
Proof. unfold Equation177. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff404_inst, reff404_op in H. discriminate H. Qed.

Lemma reff404_not206 : ~ @Equation206 Fin4 reff404_inst.
Proof. unfold Equation206. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff404_inst, reff404_op in H. discriminate H. Qed.

Lemma reff404_not209 : ~ @Equation209 Fin4 reff404_inst.
Proof. unfold Equation209. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff404_inst, reff404_op in H. discriminate H. Qed.

Lemma reff404_not211 : ~ @Equation211 Fin4 reff404_inst.
Proof. unfold Equation211. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff404_inst, reff404_op in H. discriminate H. Qed.

Lemma reff404_not212 : ~ @Equation212 Fin4 reff404_inst.
Proof. unfold Equation212. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff404_inst, reff404_op in H. discriminate H. Qed.

Lemma reff404_not219 : ~ @Equation219 Fin4 reff404_inst.
Proof. unfold Equation219. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff404_inst, reff404_op in H. discriminate H. Qed.

Lemma reff404_not221 : ~ @Equation221 Fin4 reff404_inst.
Proof. unfold Equation221. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff404_inst, reff404_op in H. discriminate H. Qed.

Lemma reff404_not222 : ~ @Equation222 Fin4 reff404_inst.
Proof. unfold Equation222. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff404_inst, reff404_op in H. discriminate H. Qed.

Lemma reff404_not229 : ~ @Equation229 Fin4 reff404_inst.
Proof. unfold Equation229. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff404_inst, reff404_op in H. discriminate H. Qed.

Lemma reff404_not231 : ~ @Equation231 Fin4 reff404_inst.
Proof. unfold Equation231. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff404_inst, reff404_op in H. discriminate H. Qed.

Lemma reff404_not258 : ~ @Equation258 Fin4 reff404_inst.
Proof. unfold Equation258. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff404_inst, reff404_op in H. discriminate H. Qed.

Lemma reff404_not261 : ~ @Equation261 Fin4 reff404_inst.
Proof. unfold Equation261. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff404_inst, reff404_op in H. discriminate H. Qed.

Lemma reff404_not263 : ~ @Equation263 Fin4 reff404_inst.
Proof. unfold Equation263. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff404_inst, reff404_op in H. discriminate H. Qed.

Lemma reff404_not264 : ~ @Equation264 Fin4 reff404_inst.
Proof. unfold Equation264. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff404_inst, reff404_op in H. discriminate H. Qed.

Lemma reff404_not271 : ~ @Equation271 Fin4 reff404_inst.
Proof. unfold Equation271. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff404_inst, reff404_op in H. discriminate H. Qed.

Lemma reff404_not273 : ~ @Equation273 Fin4 reff404_inst.
Proof. unfold Equation273. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff404_inst, reff404_op in H. discriminate H. Qed.

Lemma reff404_not274 : ~ @Equation274 Fin4 reff404_inst.
Proof. unfold Equation274. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff404_inst, reff404_op in H. discriminate H. Qed.

Lemma reff404_not281 : ~ @Equation281 Fin4 reff404_inst.
Proof. unfold Equation281. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff404_inst, reff404_op in H. discriminate H. Qed.

Lemma reff404_not283 : ~ @Equation283 Fin4 reff404_inst.
Proof. unfold Equation283. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff404_inst, reff404_op in H. discriminate H. Qed.

Lemma reff404_not323 : ~ @Equation323 Fin4 reff404_inst.
Proof. unfold Equation323. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff404_inst, reff404_op in H. discriminate H. Qed.

Lemma reff404_not412 : ~ @Equation412 Fin4 reff404_inst.
Proof. unfold Equation412. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff404_inst, reff404_op in H. discriminate H. Qed.

Lemma reff404_not413 : ~ @Equation413 Fin4 reff404_inst.
Proof. unfold Equation413. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff404_inst, reff404_op in H. discriminate H. Qed.

Lemma reff404_not414 : ~ @Equation414 Fin4 reff404_inst.
Proof. unfold Equation414. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff404_inst, reff404_op in H. discriminate H. Qed.

Lemma reff404_not416 : ~ @Equation416 Fin4 reff404_inst.
Proof. unfold Equation416. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff404_inst, reff404_op in H. discriminate H. Qed.

Lemma reff404_not417 : ~ @Equation417 Fin4 reff404_inst.
Proof. unfold Equation417. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff404_inst, reff404_op in H. discriminate H. Qed.

Lemma reff404_not420 : ~ @Equation420 Fin4 reff404_inst.
Proof. unfold Equation420. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff404_inst, reff404_op in H. discriminate H. Qed.

Lemma reff404_not426 : ~ @Equation426 Fin4 reff404_inst.
Proof. unfold Equation426. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff404_inst, reff404_op in H. discriminate H. Qed.

Lemma reff404_not427 : ~ @Equation427 Fin4 reff404_inst.
Proof. unfold Equation427. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff404_inst, reff404_op in H. discriminate H. Qed.

Lemma reff404_not430 : ~ @Equation430 Fin4 reff404_inst.
Proof. unfold Equation430. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff404_inst, reff404_op in H. discriminate H. Qed.

Lemma reff404_not437 : ~ @Equation437 Fin4 reff404_inst.
Proof. unfold Equation437. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff404_inst, reff404_op in H. discriminate H. Qed.

Lemma reff404_not439 : ~ @Equation439 Fin4 reff404_inst.
Proof. unfold Equation439. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff404_inst, reff404_op in H. discriminate H. Qed.

Lemma reff404_not440 : ~ @Equation440 Fin4 reff404_inst.
Proof. unfold Equation440. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff404_inst, reff404_op in H. discriminate H. Qed.

Lemma reff404_not463 : ~ @Equation463 Fin4 reff404_inst.
Proof. unfold Equation463. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff404_inst, reff404_op in H. discriminate H. Qed.

Lemma reff404_not464 : ~ @Equation464 Fin4 reff404_inst.
Proof. unfold Equation464. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff404_inst, reff404_op in H. discriminate H. Qed.

Lemma reff404_not467 : ~ @Equation467 Fin4 reff404_inst.
Proof. unfold Equation467. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff404_inst, reff404_op in H. discriminate H. Qed.

Lemma reff404_not474 : ~ @Equation474 Fin4 reff404_inst.
Proof. unfold Equation474. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff404_inst, reff404_op in H. discriminate H. Qed.

Lemma reff404_not476 : ~ @Equation476 Fin4 reff404_inst.
Proof. unfold Equation476. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff404_inst, reff404_op in H. discriminate H. Qed.

Lemma reff404_not477 : ~ @Equation477 Fin4 reff404_inst.
Proof. unfold Equation477. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff404_inst, reff404_op in H. discriminate H. Qed.

Lemma reff404_not501 : ~ @Equation501 Fin4 reff404_inst.
Proof. unfold Equation501. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff404_inst, reff404_op in H. discriminate H. Qed.

Lemma reff404_not503 : ~ @Equation503 Fin4 reff404_inst.
Proof. unfold Equation503. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff404_inst, reff404_op in H. discriminate H. Qed.

Lemma reff404_not504 : ~ @Equation504 Fin4 reff404_inst.
Proof. unfold Equation504. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff404_inst, reff404_op in H. discriminate H. Qed.

Lemma reff404_not510 : ~ @Equation510 Fin4 reff404_inst.
Proof. unfold Equation510. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff404_inst, reff404_op in H. discriminate H. Qed.

Lemma reff404_not511 : ~ @Equation511 Fin4 reff404_inst.
Proof. unfold Equation511. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff404_inst, reff404_op in H. discriminate H. Qed.

Lemma reff404_not615 : ~ @Equation615 Fin4 reff404_inst.
Proof. unfold Equation615. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff404_inst, reff404_op in H. discriminate H. Qed.

Lemma reff404_not616 : ~ @Equation616 Fin4 reff404_inst.
Proof. unfold Equation616. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff404_inst, reff404_op in H. discriminate H. Qed.

Lemma reff404_not617 : ~ @Equation617 Fin4 reff404_inst.
Proof. unfold Equation617. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff404_inst, reff404_op in H. discriminate H. Qed.

Lemma reff404_not620 : ~ @Equation620 Fin4 reff404_inst.
Proof. unfold Equation620. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff404_inst, reff404_op in H. discriminate H. Qed.

Lemma reff404_not622 : ~ @Equation622 Fin4 reff404_inst.
Proof. unfold Equation622. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff404_inst, reff404_op in H. discriminate H. Qed.

Lemma reff404_not623 : ~ @Equation623 Fin4 reff404_inst.
Proof. unfold Equation623. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff404_inst, reff404_op in H. discriminate H. Qed.

Lemma reff404_not629 : ~ @Equation629 Fin4 reff404_inst.
Proof. unfold Equation629. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff404_inst, reff404_op in H. discriminate H. Qed.

Lemma reff404_not630 : ~ @Equation630 Fin4 reff404_inst.
Proof. unfold Equation630. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff404_inst, reff404_op in H. discriminate H. Qed.

Lemma reff404_not633 : ~ @Equation633 Fin4 reff404_inst.
Proof. unfold Equation633. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff404_inst, reff404_op in H. discriminate H. Qed.

Lemma reff404_not639 : ~ @Equation639 Fin4 reff404_inst.
Proof. unfold Equation639. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff404_inst, reff404_op in H. discriminate H. Qed.

Lemma reff404_not640 : ~ @Equation640 Fin4 reff404_inst.
Proof. unfold Equation640. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff404_inst, reff404_op in H. discriminate H. Qed.

Lemma reff404_not643 : ~ @Equation643 Fin4 reff404_inst.
Proof. unfold Equation643. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff404_inst, reff404_op in H. discriminate H. Qed.

Lemma reff404_not666 : ~ @Equation666 Fin4 reff404_inst.
Proof. unfold Equation666. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff404_inst, reff404_op in H. discriminate H. Qed.

Lemma reff404_not667 : ~ @Equation667 Fin4 reff404_inst.
Proof. unfold Equation667. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff404_inst, reff404_op in H. discriminate H. Qed.

Lemma reff404_not670 : ~ @Equation670 Fin4 reff404_inst.
Proof. unfold Equation670. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff404_inst, reff404_op in H. discriminate H. Qed.

Lemma reff404_not676 : ~ @Equation676 Fin4 reff404_inst.
Proof. unfold Equation676. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff404_inst, reff404_op in H. discriminate H. Qed.

Lemma reff404_not677 : ~ @Equation677 Fin4 reff404_inst.
Proof. unfold Equation677. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff404_inst, reff404_op in H. discriminate H. Qed.

Lemma reff404_not680 : ~ @Equation680 Fin4 reff404_inst.
Proof. unfold Equation680. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff404_inst, reff404_op in H. discriminate H. Qed.

Lemma reff404_not704 : ~ @Equation704 Fin4 reff404_inst.
Proof. unfold Equation704. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff404_inst, reff404_op in H. discriminate H. Qed.

Lemma reff404_not706 : ~ @Equation706 Fin4 reff404_inst.
Proof. unfold Equation706. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff404_inst, reff404_op in H. discriminate H. Qed.

Lemma reff404_not707 : ~ @Equation707 Fin4 reff404_inst.
Proof. unfold Equation707. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff404_inst, reff404_op in H. discriminate H. Qed.

Lemma reff404_not714 : ~ @Equation714 Fin4 reff404_inst.
Proof. unfold Equation714. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff404_inst, reff404_op in H. discriminate H. Qed.

Lemma reff404_not716 : ~ @Equation716 Fin4 reff404_inst.
Proof. unfold Equation716. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff404_inst, reff404_op in H. discriminate H. Qed.

Lemma reff404_not818 : ~ @Equation818 Fin4 reff404_inst.
Proof. unfold Equation818. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff404_inst, reff404_op in H. discriminate H. Qed.

Lemma reff404_not819 : ~ @Equation819 Fin4 reff404_inst.
Proof. unfold Equation819. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff404_inst, reff404_op in H. discriminate H. Qed.

Lemma reff404_not820 : ~ @Equation820 Fin4 reff404_inst.
Proof. unfold Equation820. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff404_inst, reff404_op in H. discriminate H. Qed.

Lemma reff404_not822 : ~ @Equation822 Fin4 reff404_inst.
Proof. unfold Equation822. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff404_inst, reff404_op in H. discriminate H. Qed.

Lemma reff404_not823 : ~ @Equation823 Fin4 reff404_inst.
Proof. unfold Equation823. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff404_inst, reff404_op in H. discriminate H. Qed.

Lemma reff404_not826 : ~ @Equation826 Fin4 reff404_inst.
Proof. unfold Equation826. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff404_inst, reff404_op in H. discriminate H. Qed.

Lemma reff404_not833 : ~ @Equation833 Fin4 reff404_inst.
Proof. unfold Equation833. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff404_inst, reff404_op in H. discriminate H. Qed.

Lemma reff404_not835 : ~ @Equation835 Fin4 reff404_inst.
Proof. unfold Equation835. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff404_inst, reff404_op in H. discriminate H. Qed.

Lemma reff404_not836 : ~ @Equation836 Fin4 reff404_inst.
Proof. unfold Equation836. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff404_inst, reff404_op in H. discriminate H. Qed.

Lemma reff404_not842 : ~ @Equation842 Fin4 reff404_inst.
Proof. unfold Equation842. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff404_inst, reff404_op in H. discriminate H. Qed.

Lemma reff404_not843 : ~ @Equation843 Fin4 reff404_inst.
Proof. unfold Equation843. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff404_inst, reff404_op in H. discriminate H. Qed.

Lemma reff404_not846 : ~ @Equation846 Fin4 reff404_inst.
Proof. unfold Equation846. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff404_inst, reff404_op in H. discriminate H. Qed.

Lemma reff404_not869 : ~ @Equation869 Fin4 reff404_inst.
Proof. unfold Equation869. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff404_inst, reff404_op in H. discriminate H. Qed.

Lemma reff404_not870 : ~ @Equation870 Fin4 reff404_inst.
Proof. unfold Equation870. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff404_inst, reff404_op in H. discriminate H. Qed.

Lemma reff404_not873 : ~ @Equation873 Fin4 reff404_inst.
Proof. unfold Equation873. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff404_inst, reff404_op in H. discriminate H. Qed.

Lemma reff404_not880 : ~ @Equation880 Fin4 reff404_inst.
Proof. unfold Equation880. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff404_inst, reff404_op in H. discriminate H. Qed.

Lemma reff404_not882 : ~ @Equation882 Fin4 reff404_inst.
Proof. unfold Equation882. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff404_inst, reff404_op in H. discriminate H. Qed.

Lemma reff404_not883 : ~ @Equation883 Fin4 reff404_inst.
Proof. unfold Equation883. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff404_inst, reff404_op in H. discriminate H. Qed.

Lemma reff404_not906 : ~ @Equation906 Fin4 reff404_inst.
Proof. unfold Equation906. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff404_inst, reff404_op in H. discriminate H. Qed.

Lemma reff404_not907 : ~ @Equation907 Fin4 reff404_inst.
Proof. unfold Equation907. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff404_inst, reff404_op in H. discriminate H. Qed.

Lemma reff404_not910 : ~ @Equation910 Fin4 reff404_inst.
Proof. unfold Equation910. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff404_inst, reff404_op in H. discriminate H. Qed.

Lemma reff404_not917 : ~ @Equation917 Fin4 reff404_inst.
Proof. unfold Equation917. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff404_inst, reff404_op in H. discriminate H. Qed.

Lemma reff404_not919 : ~ @Equation919 Fin4 reff404_inst.
Proof. unfold Equation919. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff404_inst, reff404_op in H. discriminate H. Qed.

Lemma reff404_not1021 : ~ @Equation1021 Fin4 reff404_inst.
Proof. unfold Equation1021. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff404_inst, reff404_op in H. discriminate H. Qed.

Lemma reff404_not1022 : ~ @Equation1022 Fin4 reff404_inst.
Proof. unfold Equation1022. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff404_inst, reff404_op in H. discriminate H. Qed.

Lemma reff404_not1023 : ~ @Equation1023 Fin4 reff404_inst.
Proof. unfold Equation1023. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff404_inst, reff404_op in H. discriminate H. Qed.

Lemma reff404_not1026 : ~ @Equation1026 Fin4 reff404_inst.
Proof. unfold Equation1026. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff404_inst, reff404_op in H. discriminate H. Qed.

Lemma reff404_not1028 : ~ @Equation1028 Fin4 reff404_inst.
Proof. unfold Equation1028. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff404_inst, reff404_op in H. discriminate H. Qed.

Lemma reff404_not1029 : ~ @Equation1029 Fin4 reff404_inst.
Proof. unfold Equation1029. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff404_inst, reff404_op in H. discriminate H. Qed.

Lemma reff404_not1036 : ~ @Equation1036 Fin4 reff404_inst.
Proof. unfold Equation1036. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff404_inst, reff404_op in H. discriminate H. Qed.

Lemma reff404_not1038 : ~ @Equation1038 Fin4 reff404_inst.
Proof. unfold Equation1038. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff404_inst, reff404_op in H. discriminate H. Qed.

Lemma reff404_not1039 : ~ @Equation1039 Fin4 reff404_inst.
Proof. unfold Equation1039. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff404_inst, reff404_op in H. discriminate H. Qed.

Lemma reff404_not1046 : ~ @Equation1046 Fin4 reff404_inst.
Proof. unfold Equation1046. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff404_inst, reff404_op in H. discriminate H. Qed.

Lemma reff404_not1048 : ~ @Equation1048 Fin4 reff404_inst.
Proof. unfold Equation1048. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff404_inst, reff404_op in H. discriminate H. Qed.

Lemma reff404_not1049 : ~ @Equation1049 Fin4 reff404_inst.
Proof. unfold Equation1049. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff404_inst, reff404_op in H. discriminate H. Qed.

Lemma reff404_not1072 : ~ @Equation1072 Fin4 reff404_inst.
Proof. unfold Equation1072. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff404_inst, reff404_op in H. discriminate H. Qed.

Lemma reff404_not1073 : ~ @Equation1073 Fin4 reff404_inst.
Proof. unfold Equation1073. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff404_inst, reff404_op in H. discriminate H. Qed.

Lemma reff404_not1076 : ~ @Equation1076 Fin4 reff404_inst.
Proof. unfold Equation1076. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff404_inst, reff404_op in H. discriminate H. Qed.

Lemma reff404_not1082 : ~ @Equation1082 Fin4 reff404_inst.
Proof. unfold Equation1082. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff404_inst, reff404_op in H. discriminate H. Qed.

Lemma reff404_not1083 : ~ @Equation1083 Fin4 reff404_inst.
Proof. unfold Equation1083. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff404_inst, reff404_op in H. discriminate H. Qed.

Lemma reff404_not1086 : ~ @Equation1086 Fin4 reff404_inst.
Proof. unfold Equation1086. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff404_inst, reff404_op in H. discriminate H. Qed.

Lemma reff404_not1109 : ~ @Equation1109 Fin4 reff404_inst.
Proof. unfold Equation1109. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff404_inst, reff404_op in H. discriminate H. Qed.

Lemma reff404_not1110 : ~ @Equation1110 Fin4 reff404_inst.
Proof. unfold Equation1110. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff404_inst, reff404_op in H. discriminate H. Qed.

Lemma reff404_not1113 : ~ @Equation1113 Fin4 reff404_inst.
Proof. unfold Equation1113. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff404_inst, reff404_op in H. discriminate H. Qed.

Lemma reff404_not1119 : ~ @Equation1119 Fin4 reff404_inst.
Proof. unfold Equation1119. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff404_inst, reff404_op in H. discriminate H. Qed.

Lemma reff404_not1120 : ~ @Equation1120 Fin4 reff404_inst.
Proof. unfold Equation1120. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff404_inst, reff404_op in H. discriminate H. Qed.

Lemma reff404_not1224 : ~ @Equation1224 Fin4 reff404_inst.
Proof. unfold Equation1224. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff404_inst, reff404_op in H. discriminate H. Qed.

Lemma reff404_not1225 : ~ @Equation1225 Fin4 reff404_inst.
Proof. unfold Equation1225. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff404_inst, reff404_op in H. discriminate H. Qed.

Lemma reff404_not1226 : ~ @Equation1226 Fin4 reff404_inst.
Proof. unfold Equation1226. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff404_inst, reff404_op in H. discriminate H. Qed.

Lemma reff404_not1229 : ~ @Equation1229 Fin4 reff404_inst.
Proof. unfold Equation1229. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff404_inst, reff404_op in H. discriminate H. Qed.

Lemma reff404_not1231 : ~ @Equation1231 Fin4 reff404_inst.
Proof. unfold Equation1231. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff404_inst, reff404_op in H. discriminate H. Qed.

Lemma reff404_not1232 : ~ @Equation1232 Fin4 reff404_inst.
Proof. unfold Equation1232. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff404_inst, reff404_op in H. discriminate H. Qed.

Lemma reff404_not1239 : ~ @Equation1239 Fin4 reff404_inst.
Proof. unfold Equation1239. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff404_inst, reff404_op in H. discriminate H. Qed.

Lemma reff404_not1241 : ~ @Equation1241 Fin4 reff404_inst.
Proof. unfold Equation1241. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff404_inst, reff404_op in H. discriminate H. Qed.

Lemma reff404_not1242 : ~ @Equation1242 Fin4 reff404_inst.
Proof. unfold Equation1242. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff404_inst, reff404_op in H. discriminate H. Qed.

Lemma reff404_not1249 : ~ @Equation1249 Fin4 reff404_inst.
Proof. unfold Equation1249. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff404_inst, reff404_op in H. discriminate H. Qed.

Lemma reff404_not1251 : ~ @Equation1251 Fin4 reff404_inst.
Proof. unfold Equation1251. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff404_inst, reff404_op in H. discriminate H. Qed.

Lemma reff404_not1252 : ~ @Equation1252 Fin4 reff404_inst.
Proof. unfold Equation1252. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff404_inst, reff404_op in H. discriminate H. Qed.

Lemma reff404_not1275 : ~ @Equation1275 Fin4 reff404_inst.
Proof. unfold Equation1275. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff404_inst, reff404_op in H. discriminate H. Qed.

Lemma reff404_not1276 : ~ @Equation1276 Fin4 reff404_inst.
Proof. unfold Equation1276. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff404_inst, reff404_op in H. discriminate H. Qed.

Lemma reff404_not1279 : ~ @Equation1279 Fin4 reff404_inst.
Proof. unfold Equation1279. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff404_inst, reff404_op in H. discriminate H. Qed.

Lemma reff404_not1285 : ~ @Equation1285 Fin4 reff404_inst.
Proof. unfold Equation1285. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff404_inst, reff404_op in H. discriminate H. Qed.

Lemma reff404_not1286 : ~ @Equation1286 Fin4 reff404_inst.
Proof. unfold Equation1286. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff404_inst, reff404_op in H. discriminate H. Qed.

Lemma reff404_not1289 : ~ @Equation1289 Fin4 reff404_inst.
Proof. unfold Equation1289. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff404_inst, reff404_op in H. discriminate H. Qed.

Lemma reff404_not1312 : ~ @Equation1312 Fin4 reff404_inst.
Proof. unfold Equation1312. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff404_inst, reff404_op in H. discriminate H. Qed.

Lemma reff404_not1313 : ~ @Equation1313 Fin4 reff404_inst.
Proof. unfold Equation1313. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff404_inst, reff404_op in H. discriminate H. Qed.

Lemma reff404_not1316 : ~ @Equation1316 Fin4 reff404_inst.
Proof. unfold Equation1316. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff404_inst, reff404_op in H. discriminate H. Qed.

Lemma reff404_not1322 : ~ @Equation1322 Fin4 reff404_inst.
Proof. unfold Equation1322. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff404_inst, reff404_op in H. discriminate H. Qed.

Lemma reff404_not1323 : ~ @Equation1323 Fin4 reff404_inst.
Proof. unfold Equation1323. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff404_inst, reff404_op in H. discriminate H. Qed.

Lemma reff404_not1427 : ~ @Equation1427 Fin4 reff404_inst.
Proof. unfold Equation1427. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff404_inst, reff404_op in H. discriminate H. Qed.

Lemma reff404_not1428 : ~ @Equation1428 Fin4 reff404_inst.
Proof. unfold Equation1428. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff404_inst, reff404_op in H. discriminate H. Qed.

Lemma reff404_not1429 : ~ @Equation1429 Fin4 reff404_inst.
Proof. unfold Equation1429. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff404_inst, reff404_op in H. discriminate H. Qed.

Lemma reff404_not1431 : ~ @Equation1431 Fin4 reff404_inst.
Proof. unfold Equation1431. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff404_inst, reff404_op in H. discriminate H. Qed.

Lemma reff404_not1432 : ~ @Equation1432 Fin4 reff404_inst.
Proof. unfold Equation1432. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff404_inst, reff404_op in H. discriminate H. Qed.

Lemma reff404_not1435 : ~ @Equation1435 Fin4 reff404_inst.
Proof. unfold Equation1435. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff404_inst, reff404_op in H. discriminate H. Qed.

Lemma reff404_not1441 : ~ @Equation1441 Fin4 reff404_inst.
Proof. unfold Equation1441. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff404_inst, reff404_op in H. discriminate H. Qed.

Lemma reff404_not1442 : ~ @Equation1442 Fin4 reff404_inst.
Proof. unfold Equation1442. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff404_inst, reff404_op in H. discriminate H. Qed.

Lemma reff404_not1445 : ~ @Equation1445 Fin4 reff404_inst.
Proof. unfold Equation1445. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff404_inst, reff404_op in H. discriminate H. Qed.

Lemma reff404_not1452 : ~ @Equation1452 Fin4 reff404_inst.
Proof. unfold Equation1452. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff404_inst, reff404_op in H. discriminate H. Qed.

Lemma reff404_not1454 : ~ @Equation1454 Fin4 reff404_inst.
Proof. unfold Equation1454. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff404_inst, reff404_op in H. discriminate H. Qed.

Lemma reff404_not1455 : ~ @Equation1455 Fin4 reff404_inst.
Proof. unfold Equation1455. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff404_inst, reff404_op in H. discriminate H. Qed.

Lemma reff404_not1479 : ~ @Equation1479 Fin4 reff404_inst.
Proof. unfold Equation1479. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff404_inst, reff404_op in H. discriminate H. Qed.

Lemma reff404_not1481 : ~ @Equation1481 Fin4 reff404_inst.
Proof. unfold Equation1481. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff404_inst, reff404_op in H. discriminate H. Qed.

Lemma reff404_not1482 : ~ @Equation1482 Fin4 reff404_inst.
Proof. unfold Equation1482. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff404_inst, reff404_op in H. discriminate H. Qed.

Lemma reff404_not1488 : ~ @Equation1488 Fin4 reff404_inst.
Proof. unfold Equation1488. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff404_inst, reff404_op in H. discriminate H. Qed.

Lemma reff404_not1489 : ~ @Equation1489 Fin4 reff404_inst.
Proof. unfold Equation1489. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff404_inst, reff404_op in H. discriminate H. Qed.

Lemma reff404_not1492 : ~ @Equation1492 Fin4 reff404_inst.
Proof. unfold Equation1492. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff404_inst, reff404_op in H. discriminate H. Qed.

Lemma reff404_not1515 : ~ @Equation1515 Fin4 reff404_inst.
Proof. unfold Equation1515. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff404_inst, reff404_op in H. discriminate H. Qed.

Lemma reff404_not1516 : ~ @Equation1516 Fin4 reff404_inst.
Proof. unfold Equation1516. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff404_inst, reff404_op in H. discriminate H. Qed.

Lemma reff404_not1519 : ~ @Equation1519 Fin4 reff404_inst.
Proof. unfold Equation1519. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff404_inst, reff404_op in H. discriminate H. Qed.

Lemma reff404_not1526 : ~ @Equation1526 Fin4 reff404_inst.
Proof. unfold Equation1526. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff404_inst, reff404_op in H. discriminate H. Qed.

Lemma reff404_not1528 : ~ @Equation1528 Fin4 reff404_inst.
Proof. unfold Equation1528. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff404_inst, reff404_op in H. discriminate H. Qed.

Lemma reff404_not1630 : ~ @Equation1630 Fin4 reff404_inst.
Proof. unfold Equation1630. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff404_inst, reff404_op in H. discriminate H. Qed.

Lemma reff404_not1631 : ~ @Equation1631 Fin4 reff404_inst.
Proof. unfold Equation1631. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff404_inst, reff404_op in H. discriminate H. Qed.

Lemma reff404_not1632 : ~ @Equation1632 Fin4 reff404_inst.
Proof. unfold Equation1632. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff404_inst, reff404_op in H. discriminate H. Qed.

Lemma reff404_not1635 : ~ @Equation1635 Fin4 reff404_inst.
Proof. unfold Equation1635. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff404_inst, reff404_op in H. discriminate H. Qed.

Lemma reff404_not1637 : ~ @Equation1637 Fin4 reff404_inst.
Proof. unfold Equation1637. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff404_inst, reff404_op in H. discriminate H. Qed.

Lemma reff404_not1638 : ~ @Equation1638 Fin4 reff404_inst.
Proof. unfold Equation1638. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff404_inst, reff404_op in H. discriminate H. Qed.

Lemma reff404_not1644 : ~ @Equation1644 Fin4 reff404_inst.
Proof. unfold Equation1644. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff404_inst, reff404_op in H. discriminate H. Qed.

Lemma reff404_not1645 : ~ @Equation1645 Fin4 reff404_inst.
Proof. unfold Equation1645. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff404_inst, reff404_op in H. discriminate H. Qed.

Lemma reff404_not1648 : ~ @Equation1648 Fin4 reff404_inst.
Proof. unfold Equation1648. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff404_inst, reff404_op in H. discriminate H. Qed.

Lemma reff404_not1654 : ~ @Equation1654 Fin4 reff404_inst.
Proof. unfold Equation1654. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff404_inst, reff404_op in H. discriminate H. Qed.

Lemma reff404_not1655 : ~ @Equation1655 Fin4 reff404_inst.
Proof. unfold Equation1655. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff404_inst, reff404_op in H. discriminate H. Qed.

Lemma reff404_not1658 : ~ @Equation1658 Fin4 reff404_inst.
Proof. unfold Equation1658. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff404_inst, reff404_op in H. discriminate H. Qed.

Lemma reff404_not1682 : ~ @Equation1682 Fin4 reff404_inst.
Proof. unfold Equation1682. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff404_inst, reff404_op in H. discriminate H. Qed.

Lemma reff404_not1684 : ~ @Equation1684 Fin4 reff404_inst.
Proof. unfold Equation1684. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff404_inst, reff404_op in H. discriminate H. Qed.

Lemma reff404_not1685 : ~ @Equation1685 Fin4 reff404_inst.
Proof. unfold Equation1685. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff404_inst, reff404_op in H. discriminate H. Qed.

Lemma reff404_not1692 : ~ @Equation1692 Fin4 reff404_inst.
Proof. unfold Equation1692. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff404_inst, reff404_op in H. discriminate H. Qed.

Lemma reff404_not1694 : ~ @Equation1694 Fin4 reff404_inst.
Proof. unfold Equation1694. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff404_inst, reff404_op in H. discriminate H. Qed.

Lemma reff404_not1695 : ~ @Equation1695 Fin4 reff404_inst.
Proof. unfold Equation1695. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff404_inst, reff404_op in H. discriminate H. Qed.

Lemma reff404_not1718 : ~ @Equation1718 Fin4 reff404_inst.
Proof. unfold Equation1718. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff404_inst, reff404_op in H. discriminate H. Qed.

Lemma reff404_not1719 : ~ @Equation1719 Fin4 reff404_inst.
Proof. unfold Equation1719. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff404_inst, reff404_op in H. discriminate H. Qed.

Lemma reff404_not1722 : ~ @Equation1722 Fin4 reff404_inst.
Proof. unfold Equation1722. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff404_inst, reff404_op in H. discriminate H. Qed.

Lemma reff404_not1728 : ~ @Equation1728 Fin4 reff404_inst.
Proof. unfold Equation1728. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff404_inst, reff404_op in H. discriminate H. Qed.

Lemma reff404_not1729 : ~ @Equation1729 Fin4 reff404_inst.
Proof. unfold Equation1729. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff404_inst, reff404_op in H. discriminate H. Qed.

Lemma reff404_not1833 : ~ @Equation1833 Fin4 reff404_inst.
Proof. unfold Equation1833. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff404_inst, reff404_op in H. discriminate H. Qed.

Lemma reff404_not1834 : ~ @Equation1834 Fin4 reff404_inst.
Proof. unfold Equation1834. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff404_inst, reff404_op in H. discriminate H. Qed.

Lemma reff404_not1835 : ~ @Equation1835 Fin4 reff404_inst.
Proof. unfold Equation1835. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff404_inst, reff404_op in H. discriminate H. Qed.

Lemma reff404_not1837 : ~ @Equation1837 Fin4 reff404_inst.
Proof. unfold Equation1837. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff404_inst, reff404_op in H. discriminate H. Qed.

Lemma reff404_not1838 : ~ @Equation1838 Fin4 reff404_inst.
Proof. unfold Equation1838. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff404_inst, reff404_op in H. discriminate H. Qed.

Lemma reff404_not1841 : ~ @Equation1841 Fin4 reff404_inst.
Proof. unfold Equation1841. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff404_inst, reff404_op in H. discriminate H. Qed.

Lemma reff404_not1848 : ~ @Equation1848 Fin4 reff404_inst.
Proof. unfold Equation1848. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff404_inst, reff404_op in H. discriminate H. Qed.

Lemma reff404_not1850 : ~ @Equation1850 Fin4 reff404_inst.
Proof. unfold Equation1850. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff404_inst, reff404_op in H. discriminate H. Qed.

Lemma reff404_not1851 : ~ @Equation1851 Fin4 reff404_inst.
Proof. unfold Equation1851. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff404_inst, reff404_op in H. discriminate H. Qed.

Lemma reff404_not1857 : ~ @Equation1857 Fin4 reff404_inst.
Proof. unfold Equation1857. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff404_inst, reff404_op in H. discriminate H. Qed.

Lemma reff404_not1858 : ~ @Equation1858 Fin4 reff404_inst.
Proof. unfold Equation1858. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff404_inst, reff404_op in H. discriminate H. Qed.

Lemma reff404_not1861 : ~ @Equation1861 Fin4 reff404_inst.
Proof. unfold Equation1861. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff404_inst, reff404_op in H. discriminate H. Qed.

Lemma reff404_not1885 : ~ @Equation1885 Fin4 reff404_inst.
Proof. unfold Equation1885. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff404_inst, reff404_op in H. discriminate H. Qed.

Lemma reff404_not1887 : ~ @Equation1887 Fin4 reff404_inst.
Proof. unfold Equation1887. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff404_inst, reff404_op in H. discriminate H. Qed.

Lemma reff404_not1888 : ~ @Equation1888 Fin4 reff404_inst.
Proof. unfold Equation1888. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff404_inst, reff404_op in H. discriminate H. Qed.

Lemma reff404_not1894 : ~ @Equation1894 Fin4 reff404_inst.
Proof. unfold Equation1894. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff404_inst, reff404_op in H. discriminate H. Qed.

Lemma reff404_not1895 : ~ @Equation1895 Fin4 reff404_inst.
Proof. unfold Equation1895. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff404_inst, reff404_op in H. discriminate H. Qed.

Lemma reff404_not1898 : ~ @Equation1898 Fin4 reff404_inst.
Proof. unfold Equation1898. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff404_inst, reff404_op in H. discriminate H. Qed.

Lemma reff404_not1922 : ~ @Equation1922 Fin4 reff404_inst.
Proof. unfold Equation1922. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff404_inst, reff404_op in H. discriminate H. Qed.

Lemma reff404_not1924 : ~ @Equation1924 Fin4 reff404_inst.
Proof. unfold Equation1924. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff404_inst, reff404_op in H. discriminate H. Qed.

Lemma reff404_not1925 : ~ @Equation1925 Fin4 reff404_inst.
Proof. unfold Equation1925. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff404_inst, reff404_op in H. discriminate H. Qed.

Lemma reff404_not1931 : ~ @Equation1931 Fin4 reff404_inst.
Proof. unfold Equation1931. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff404_inst, reff404_op in H. discriminate H. Qed.

Lemma reff404_not1932 : ~ @Equation1932 Fin4 reff404_inst.
Proof. unfold Equation1932. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff404_inst, reff404_op in H. discriminate H. Qed.

Lemma reff404_not2036 : ~ @Equation2036 Fin4 reff404_inst.
Proof. unfold Equation2036. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff404_inst, reff404_op in H. discriminate H. Qed.

Lemma reff404_not2037 : ~ @Equation2037 Fin4 reff404_inst.
Proof. unfold Equation2037. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff404_inst, reff404_op in H. discriminate H. Qed.

Lemma reff404_not2038 : ~ @Equation2038 Fin4 reff404_inst.
Proof. unfold Equation2038. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff404_inst, reff404_op in H. discriminate H. Qed.

Lemma reff404_not2040 : ~ @Equation2040 Fin4 reff404_inst.
Proof. unfold Equation2040. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff404_inst, reff404_op in H. discriminate H. Qed.

Lemma reff404_not2041 : ~ @Equation2041 Fin4 reff404_inst.
Proof. unfold Equation2041. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff404_inst, reff404_op in H. discriminate H. Qed.

Lemma reff404_not2044 : ~ @Equation2044 Fin4 reff404_inst.
Proof. unfold Equation2044. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff404_inst, reff404_op in H. discriminate H. Qed.

Lemma reff404_not2051 : ~ @Equation2051 Fin4 reff404_inst.
Proof. unfold Equation2051. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff404_inst, reff404_op in H. discriminate H. Qed.

Lemma reff404_not2053 : ~ @Equation2053 Fin4 reff404_inst.
Proof. unfold Equation2053. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff404_inst, reff404_op in H. discriminate H. Qed.

Lemma reff404_not2054 : ~ @Equation2054 Fin4 reff404_inst.
Proof. unfold Equation2054. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff404_inst, reff404_op in H. discriminate H. Qed.

Lemma reff404_not2060 : ~ @Equation2060 Fin4 reff404_inst.
Proof. unfold Equation2060. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff404_inst, reff404_op in H. discriminate H. Qed.

Lemma reff404_not2061 : ~ @Equation2061 Fin4 reff404_inst.
Proof. unfold Equation2061. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff404_inst, reff404_op in H. discriminate H. Qed.

Lemma reff404_not2064 : ~ @Equation2064 Fin4 reff404_inst.
Proof. unfold Equation2064. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff404_inst, reff404_op in H. discriminate H. Qed.

Lemma reff404_not2088 : ~ @Equation2088 Fin4 reff404_inst.
Proof. unfold Equation2088. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff404_inst, reff404_op in H. discriminate H. Qed.

Lemma reff404_not2090 : ~ @Equation2090 Fin4 reff404_inst.
Proof. unfold Equation2090. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff404_inst, reff404_op in H. discriminate H. Qed.

Lemma reff404_not2091 : ~ @Equation2091 Fin4 reff404_inst.
Proof. unfold Equation2091. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff404_inst, reff404_op in H. discriminate H. Qed.

Lemma reff404_not2097 : ~ @Equation2097 Fin4 reff404_inst.
Proof. unfold Equation2097. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff404_inst, reff404_op in H. discriminate H. Qed.

Lemma reff404_not2098 : ~ @Equation2098 Fin4 reff404_inst.
Proof. unfold Equation2098. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff404_inst, reff404_op in H. discriminate H. Qed.

Lemma reff404_not2101 : ~ @Equation2101 Fin4 reff404_inst.
Proof. unfold Equation2101. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff404_inst, reff404_op in H. discriminate H. Qed.

Lemma reff404_not2125 : ~ @Equation2125 Fin4 reff404_inst.
Proof. unfold Equation2125. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff404_inst, reff404_op in H. discriminate H. Qed.

Lemma reff404_not2127 : ~ @Equation2127 Fin4 reff404_inst.
Proof. unfold Equation2127. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff404_inst, reff404_op in H. discriminate H. Qed.

Lemma reff404_not2128 : ~ @Equation2128 Fin4 reff404_inst.
Proof. unfold Equation2128. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff404_inst, reff404_op in H. discriminate H. Qed.

Lemma reff404_not2134 : ~ @Equation2134 Fin4 reff404_inst.
Proof. unfold Equation2134. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff404_inst, reff404_op in H. discriminate H. Qed.

Lemma reff404_not2135 : ~ @Equation2135 Fin4 reff404_inst.
Proof. unfold Equation2135. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff404_inst, reff404_op in H. discriminate H. Qed.

Lemma reff404_not2239 : ~ @Equation2239 Fin4 reff404_inst.
Proof. unfold Equation2239. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff404_inst, reff404_op in H. discriminate H. Qed.

Lemma reff404_not2240 : ~ @Equation2240 Fin4 reff404_inst.
Proof. unfold Equation2240. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff404_inst, reff404_op in H. discriminate H. Qed.

Lemma reff404_not2241 : ~ @Equation2241 Fin4 reff404_inst.
Proof. unfold Equation2241. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff404_inst, reff404_op in H. discriminate H. Qed.

Lemma reff404_not2244 : ~ @Equation2244 Fin4 reff404_inst.
Proof. unfold Equation2244. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff404_inst, reff404_op in H. discriminate H. Qed.

Lemma reff404_not2246 : ~ @Equation2246 Fin4 reff404_inst.
Proof. unfold Equation2246. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff404_inst, reff404_op in H. discriminate H. Qed.

Lemma reff404_not2247 : ~ @Equation2247 Fin4 reff404_inst.
Proof. unfold Equation2247. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff404_inst, reff404_op in H. discriminate H. Qed.

Lemma reff404_not2254 : ~ @Equation2254 Fin4 reff404_inst.
Proof. unfold Equation2254. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff404_inst, reff404_op in H. discriminate H. Qed.

Lemma reff404_not2256 : ~ @Equation2256 Fin4 reff404_inst.
Proof. unfold Equation2256. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff404_inst, reff404_op in H. discriminate H. Qed.

Lemma reff404_not2257 : ~ @Equation2257 Fin4 reff404_inst.
Proof. unfold Equation2257. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff404_inst, reff404_op in H. discriminate H. Qed.

Lemma reff404_not2264 : ~ @Equation2264 Fin4 reff404_inst.
Proof. unfold Equation2264. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff404_inst, reff404_op in H. discriminate H. Qed.

Lemma reff404_not2266 : ~ @Equation2266 Fin4 reff404_inst.
Proof. unfold Equation2266. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff404_inst, reff404_op in H. discriminate H. Qed.

Lemma reff404_not2267 : ~ @Equation2267 Fin4 reff404_inst.
Proof. unfold Equation2267. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff404_inst, reff404_op in H. discriminate H. Qed.

Lemma reff404_not2291 : ~ @Equation2291 Fin4 reff404_inst.
Proof. unfold Equation2291. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff404_inst, reff404_op in H. discriminate H. Qed.

Lemma reff404_not2293 : ~ @Equation2293 Fin4 reff404_inst.
Proof. unfold Equation2293. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff404_inst, reff404_op in H. discriminate H. Qed.

Lemma reff404_not2294 : ~ @Equation2294 Fin4 reff404_inst.
Proof. unfold Equation2294. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff404_inst, reff404_op in H. discriminate H. Qed.

Lemma reff404_not2301 : ~ @Equation2301 Fin4 reff404_inst.
Proof. unfold Equation2301. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff404_inst, reff404_op in H. discriminate H. Qed.

Lemma reff404_not2303 : ~ @Equation2303 Fin4 reff404_inst.
Proof. unfold Equation2303. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff404_inst, reff404_op in H. discriminate H. Qed.

Lemma reff404_not2304 : ~ @Equation2304 Fin4 reff404_inst.
Proof. unfold Equation2304. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff404_inst, reff404_op in H. discriminate H. Qed.

Lemma reff404_not2328 : ~ @Equation2328 Fin4 reff404_inst.
Proof. unfold Equation2328. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff404_inst, reff404_op in H. discriminate H. Qed.

Lemma reff404_not2330 : ~ @Equation2330 Fin4 reff404_inst.
Proof. unfold Equation2330. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff404_inst, reff404_op in H. discriminate H. Qed.

Lemma reff404_not2331 : ~ @Equation2331 Fin4 reff404_inst.
Proof. unfold Equation2331. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff404_inst, reff404_op in H. discriminate H. Qed.

Lemma reff404_not2338 : ~ @Equation2338 Fin4 reff404_inst.
Proof. unfold Equation2338. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff404_inst, reff404_op in H. discriminate H. Qed.

Lemma reff404_not2340 : ~ @Equation2340 Fin4 reff404_inst.
Proof. unfold Equation2340. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff404_inst, reff404_op in H. discriminate H. Qed.

Lemma reff404_not2442 : ~ @Equation2442 Fin4 reff404_inst.
Proof. unfold Equation2442. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff404_inst, reff404_op in H. discriminate H. Qed.

Lemma reff404_not2443 : ~ @Equation2443 Fin4 reff404_inst.
Proof. unfold Equation2443. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff404_inst, reff404_op in H. discriminate H. Qed.

Lemma reff404_not2444 : ~ @Equation2444 Fin4 reff404_inst.
Proof. unfold Equation2444. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff404_inst, reff404_op in H. discriminate H. Qed.

Lemma reff404_not2447 : ~ @Equation2447 Fin4 reff404_inst.
Proof. unfold Equation2447. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff404_inst, reff404_op in H. discriminate H. Qed.

Lemma reff404_not2449 : ~ @Equation2449 Fin4 reff404_inst.
Proof. unfold Equation2449. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff404_inst, reff404_op in H. discriminate H. Qed.

Lemma reff404_not2450 : ~ @Equation2450 Fin4 reff404_inst.
Proof. unfold Equation2450. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff404_inst, reff404_op in H. discriminate H. Qed.

Lemma reff404_not2457 : ~ @Equation2457 Fin4 reff404_inst.
Proof. unfold Equation2457. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff404_inst, reff404_op in H. discriminate H. Qed.

Lemma reff404_not2459 : ~ @Equation2459 Fin4 reff404_inst.
Proof. unfold Equation2459. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff404_inst, reff404_op in H. discriminate H. Qed.

Lemma reff404_not2460 : ~ @Equation2460 Fin4 reff404_inst.
Proof. unfold Equation2460. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff404_inst, reff404_op in H. discriminate H. Qed.

Lemma reff404_not2467 : ~ @Equation2467 Fin4 reff404_inst.
Proof. unfold Equation2467. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff404_inst, reff404_op in H. discriminate H. Qed.

Lemma reff404_not2469 : ~ @Equation2469 Fin4 reff404_inst.
Proof. unfold Equation2469. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff404_inst, reff404_op in H. discriminate H. Qed.

Lemma reff404_not2470 : ~ @Equation2470 Fin4 reff404_inst.
Proof. unfold Equation2470. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff404_inst, reff404_op in H. discriminate H. Qed.

Lemma reff404_not2494 : ~ @Equation2494 Fin4 reff404_inst.
Proof. unfold Equation2494. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff404_inst, reff404_op in H. discriminate H. Qed.

Lemma reff404_not2496 : ~ @Equation2496 Fin4 reff404_inst.
Proof. unfold Equation2496. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff404_inst, reff404_op in H. discriminate H. Qed.

Lemma reff404_not2497 : ~ @Equation2497 Fin4 reff404_inst.
Proof. unfold Equation2497. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff404_inst, reff404_op in H. discriminate H. Qed.

Lemma reff404_not2504 : ~ @Equation2504 Fin4 reff404_inst.
Proof. unfold Equation2504. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff404_inst, reff404_op in H. discriminate H. Qed.

Lemma reff404_not2506 : ~ @Equation2506 Fin4 reff404_inst.
Proof. unfold Equation2506. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff404_inst, reff404_op in H. discriminate H. Qed.

Lemma reff404_not2507 : ~ @Equation2507 Fin4 reff404_inst.
Proof. unfold Equation2507. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff404_inst, reff404_op in H. discriminate H. Qed.

Lemma reff404_not2531 : ~ @Equation2531 Fin4 reff404_inst.
Proof. unfold Equation2531. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff404_inst, reff404_op in H. discriminate H. Qed.

Lemma reff404_not2533 : ~ @Equation2533 Fin4 reff404_inst.
Proof. unfold Equation2533. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff404_inst, reff404_op in H. discriminate H. Qed.

Lemma reff404_not2534 : ~ @Equation2534 Fin4 reff404_inst.
Proof. unfold Equation2534. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff404_inst, reff404_op in H. discriminate H. Qed.

Lemma reff404_not2541 : ~ @Equation2541 Fin4 reff404_inst.
Proof. unfold Equation2541. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff404_inst, reff404_op in H. discriminate H. Qed.

Lemma reff404_not2543 : ~ @Equation2543 Fin4 reff404_inst.
Proof. unfold Equation2543. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff404_inst, reff404_op in H. discriminate H. Qed.

Lemma reff404_not2645 : ~ @Equation2645 Fin4 reff404_inst.
Proof. unfold Equation2645. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff404_inst, reff404_op in H. discriminate H. Qed.

Lemma reff404_not2646 : ~ @Equation2646 Fin4 reff404_inst.
Proof. unfold Equation2646. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff404_inst, reff404_op in H. discriminate H. Qed.

Lemma reff404_not2647 : ~ @Equation2647 Fin4 reff404_inst.
Proof. unfold Equation2647. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff404_inst, reff404_op in H. discriminate H. Qed.

Lemma reff404_not2650 : ~ @Equation2650 Fin4 reff404_inst.
Proof. unfold Equation2650. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff404_inst, reff404_op in H. discriminate H. Qed.

Lemma reff404_not2652 : ~ @Equation2652 Fin4 reff404_inst.
Proof. unfold Equation2652. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff404_inst, reff404_op in H. discriminate H. Qed.

Lemma reff404_not2653 : ~ @Equation2653 Fin4 reff404_inst.
Proof. unfold Equation2653. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff404_inst, reff404_op in H. discriminate H. Qed.

Lemma reff404_not2660 : ~ @Equation2660 Fin4 reff404_inst.
Proof. unfold Equation2660. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff404_inst, reff404_op in H. discriminate H. Qed.

Lemma reff404_not2662 : ~ @Equation2662 Fin4 reff404_inst.
Proof. unfold Equation2662. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff404_inst, reff404_op in H. discriminate H. Qed.

Lemma reff404_not2663 : ~ @Equation2663 Fin4 reff404_inst.
Proof. unfold Equation2663. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff404_inst, reff404_op in H. discriminate H. Qed.

Lemma reff404_not2670 : ~ @Equation2670 Fin4 reff404_inst.
Proof. unfold Equation2670. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff404_inst, reff404_op in H. discriminate H. Qed.

Lemma reff404_not2672 : ~ @Equation2672 Fin4 reff404_inst.
Proof. unfold Equation2672. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff404_inst, reff404_op in H. discriminate H. Qed.

Lemma reff404_not2673 : ~ @Equation2673 Fin4 reff404_inst.
Proof. unfold Equation2673. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff404_inst, reff404_op in H. discriminate H. Qed.

Lemma reff404_not2697 : ~ @Equation2697 Fin4 reff404_inst.
Proof. unfold Equation2697. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff404_inst, reff404_op in H. discriminate H. Qed.

Lemma reff404_not2699 : ~ @Equation2699 Fin4 reff404_inst.
Proof. unfold Equation2699. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff404_inst, reff404_op in H. discriminate H. Qed.

Lemma reff404_not2700 : ~ @Equation2700 Fin4 reff404_inst.
Proof. unfold Equation2700. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff404_inst, reff404_op in H. discriminate H. Qed.

Lemma reff404_not2707 : ~ @Equation2707 Fin4 reff404_inst.
Proof. unfold Equation2707. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff404_inst, reff404_op in H. discriminate H. Qed.

Lemma reff404_not2709 : ~ @Equation2709 Fin4 reff404_inst.
Proof. unfold Equation2709. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff404_inst, reff404_op in H. discriminate H. Qed.

Lemma reff404_not2710 : ~ @Equation2710 Fin4 reff404_inst.
Proof. unfold Equation2710. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff404_inst, reff404_op in H. discriminate H. Qed.

Lemma reff404_not2734 : ~ @Equation2734 Fin4 reff404_inst.
Proof. unfold Equation2734. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff404_inst, reff404_op in H. discriminate H. Qed.

Lemma reff404_not2736 : ~ @Equation2736 Fin4 reff404_inst.
Proof. unfold Equation2736. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff404_inst, reff404_op in H. discriminate H. Qed.

Lemma reff404_not2737 : ~ @Equation2737 Fin4 reff404_inst.
Proof. unfold Equation2737. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff404_inst, reff404_op in H. discriminate H. Qed.

Lemma reff404_not2744 : ~ @Equation2744 Fin4 reff404_inst.
Proof. unfold Equation2744. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff404_inst, reff404_op in H. discriminate H. Qed.

Lemma reff404_not2746 : ~ @Equation2746 Fin4 reff404_inst.
Proof. unfold Equation2746. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff404_inst, reff404_op in H. discriminate H. Qed.

Lemma reff404_not2848 : ~ @Equation2848 Fin4 reff404_inst.
Proof. unfold Equation2848. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff404_inst, reff404_op in H. discriminate H. Qed.

Lemma reff404_not2849 : ~ @Equation2849 Fin4 reff404_inst.
Proof. unfold Equation2849. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff404_inst, reff404_op in H. discriminate H. Qed.

Lemma reff404_not2850 : ~ @Equation2850 Fin4 reff404_inst.
Proof. unfold Equation2850. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff404_inst, reff404_op in H. discriminate H. Qed.

Lemma reff404_not2853 : ~ @Equation2853 Fin4 reff404_inst.
Proof. unfold Equation2853. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff404_inst, reff404_op in H. discriminate H. Qed.

Lemma reff404_not2855 : ~ @Equation2855 Fin4 reff404_inst.
Proof. unfold Equation2855. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff404_inst, reff404_op in H. discriminate H. Qed.

Lemma reff404_not2856 : ~ @Equation2856 Fin4 reff404_inst.
Proof. unfold Equation2856. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff404_inst, reff404_op in H. discriminate H. Qed.

Lemma reff404_not2863 : ~ @Equation2863 Fin4 reff404_inst.
Proof. unfold Equation2863. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff404_inst, reff404_op in H. discriminate H. Qed.

Lemma reff404_not2865 : ~ @Equation2865 Fin4 reff404_inst.
Proof. unfold Equation2865. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff404_inst, reff404_op in H. discriminate H. Qed.

Lemma reff404_not2866 : ~ @Equation2866 Fin4 reff404_inst.
Proof. unfold Equation2866. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff404_inst, reff404_op in H. discriminate H. Qed.

Lemma reff404_not2873 : ~ @Equation2873 Fin4 reff404_inst.
Proof. unfold Equation2873. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff404_inst, reff404_op in H. discriminate H. Qed.

Lemma reff404_not2875 : ~ @Equation2875 Fin4 reff404_inst.
Proof. unfold Equation2875. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff404_inst, reff404_op in H. discriminate H. Qed.

Lemma reff404_not2876 : ~ @Equation2876 Fin4 reff404_inst.
Proof. unfold Equation2876. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff404_inst, reff404_op in H. discriminate H. Qed.

Lemma reff404_not2900 : ~ @Equation2900 Fin4 reff404_inst.
Proof. unfold Equation2900. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff404_inst, reff404_op in H. discriminate H. Qed.

Lemma reff404_not2902 : ~ @Equation2902 Fin4 reff404_inst.
Proof. unfold Equation2902. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff404_inst, reff404_op in H. discriminate H. Qed.

Lemma reff404_not2903 : ~ @Equation2903 Fin4 reff404_inst.
Proof. unfold Equation2903. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff404_inst, reff404_op in H. discriminate H. Qed.

Lemma reff404_not2910 : ~ @Equation2910 Fin4 reff404_inst.
Proof. unfold Equation2910. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff404_inst, reff404_op in H. discriminate H. Qed.

Lemma reff404_not2912 : ~ @Equation2912 Fin4 reff404_inst.
Proof. unfold Equation2912. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff404_inst, reff404_op in H. discriminate H. Qed.

Lemma reff404_not2913 : ~ @Equation2913 Fin4 reff404_inst.
Proof. unfold Equation2913. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff404_inst, reff404_op in H. discriminate H. Qed.

Lemma reff404_not2937 : ~ @Equation2937 Fin4 reff404_inst.
Proof. unfold Equation2937. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff404_inst, reff404_op in H. discriminate H. Qed.

Lemma reff404_not2939 : ~ @Equation2939 Fin4 reff404_inst.
Proof. unfold Equation2939. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff404_inst, reff404_op in H. discriminate H. Qed.

Lemma reff404_not2940 : ~ @Equation2940 Fin4 reff404_inst.
Proof. unfold Equation2940. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff404_inst, reff404_op in H. discriminate H. Qed.

Lemma reff404_not2947 : ~ @Equation2947 Fin4 reff404_inst.
Proof. unfold Equation2947. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff404_inst, reff404_op in H. discriminate H. Qed.

Lemma reff404_not2949 : ~ @Equation2949 Fin4 reff404_inst.
Proof. unfold Equation2949. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff404_inst, reff404_op in H. discriminate H. Qed.

Lemma reff404_not3051 : ~ @Equation3051 Fin4 reff404_inst.
Proof. unfold Equation3051. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff404_inst, reff404_op in H. discriminate H. Qed.

Lemma reff404_not3052 : ~ @Equation3052 Fin4 reff404_inst.
Proof. unfold Equation3052. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff404_inst, reff404_op in H. discriminate H. Qed.

Lemma reff404_not3053 : ~ @Equation3053 Fin4 reff404_inst.
Proof. unfold Equation3053. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff404_inst, reff404_op in H. discriminate H. Qed.

Lemma reff404_not3056 : ~ @Equation3056 Fin4 reff404_inst.
Proof. unfold Equation3056. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff404_inst, reff404_op in H. discriminate H. Qed.

Lemma reff404_not3058 : ~ @Equation3058 Fin4 reff404_inst.
Proof. unfold Equation3058. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff404_inst, reff404_op in H. discriminate H. Qed.

Lemma reff404_not3059 : ~ @Equation3059 Fin4 reff404_inst.
Proof. unfold Equation3059. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff404_inst, reff404_op in H. discriminate H. Qed.

Lemma reff404_not3066 : ~ @Equation3066 Fin4 reff404_inst.
Proof. unfold Equation3066. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff404_inst, reff404_op in H. discriminate H. Qed.

Lemma reff404_not3068 : ~ @Equation3068 Fin4 reff404_inst.
Proof. unfold Equation3068. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff404_inst, reff404_op in H. discriminate H. Qed.

Lemma reff404_not3069 : ~ @Equation3069 Fin4 reff404_inst.
Proof. unfold Equation3069. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff404_inst, reff404_op in H. discriminate H. Qed.

Lemma reff404_not3076 : ~ @Equation3076 Fin4 reff404_inst.
Proof. unfold Equation3076. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff404_inst, reff404_op in H. discriminate H. Qed.

Lemma reff404_not3078 : ~ @Equation3078 Fin4 reff404_inst.
Proof. unfold Equation3078. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff404_inst, reff404_op in H. discriminate H. Qed.

Lemma reff404_not3079 : ~ @Equation3079 Fin4 reff404_inst.
Proof. unfold Equation3079. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff404_inst, reff404_op in H. discriminate H. Qed.

Lemma reff404_not3103 : ~ @Equation3103 Fin4 reff404_inst.
Proof. unfold Equation3103. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff404_inst, reff404_op in H. discriminate H. Qed.

Lemma reff404_not3105 : ~ @Equation3105 Fin4 reff404_inst.
Proof. unfold Equation3105. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff404_inst, reff404_op in H. discriminate H. Qed.

Lemma reff404_not3106 : ~ @Equation3106 Fin4 reff404_inst.
Proof. unfold Equation3106. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff404_inst, reff404_op in H. discriminate H. Qed.

Lemma reff404_not3113 : ~ @Equation3113 Fin4 reff404_inst.
Proof. unfold Equation3113. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff404_inst, reff404_op in H. discriminate H. Qed.

Lemma reff404_not3115 : ~ @Equation3115 Fin4 reff404_inst.
Proof. unfold Equation3115. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff404_inst, reff404_op in H. discriminate H. Qed.

Lemma reff404_not3116 : ~ @Equation3116 Fin4 reff404_inst.
Proof. unfold Equation3116. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff404_inst, reff404_op in H. discriminate H. Qed.

Lemma reff404_not3140 : ~ @Equation3140 Fin4 reff404_inst.
Proof. unfold Equation3140. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff404_inst, reff404_op in H. discriminate H. Qed.

Lemma reff404_not3142 : ~ @Equation3142 Fin4 reff404_inst.
Proof. unfold Equation3142. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff404_inst, reff404_op in H. discriminate H. Qed.

Lemma reff404_not3143 : ~ @Equation3143 Fin4 reff404_inst.
Proof. unfold Equation3143. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff404_inst, reff404_op in H. discriminate H. Qed.

Lemma reff404_not3150 : ~ @Equation3150 Fin4 reff404_inst.
Proof. unfold Equation3150. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff404_inst, reff404_op in H. discriminate H. Qed.

Lemma reff404_not3152 : ~ @Equation3152 Fin4 reff404_inst.
Proof. unfold Equation3152. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff404_inst, reff404_op in H. discriminate H. Qed.

Lemma reff404_not3254 : ~ @Equation3254 Fin4 reff404_inst.
Proof. unfold Equation3254. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff404_inst, reff404_op in H. discriminate H. Qed.

Lemma reff404_not3255 : ~ @Equation3255 Fin4 reff404_inst.
Proof. unfold Equation3255. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff404_inst, reff404_op in H. discriminate H. Qed.

Lemma reff404_not3256 : ~ @Equation3256 Fin4 reff404_inst.
Proof. unfold Equation3256. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff404_inst, reff404_op in H. discriminate H. Qed.

Lemma reff404_not3258 : ~ @Equation3258 Fin4 reff404_inst.
Proof. unfold Equation3258. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff404_inst, reff404_op in H. discriminate H. Qed.

Lemma reff404_not3259 : ~ @Equation3259 Fin4 reff404_inst.
Proof. unfold Equation3259. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff404_inst, reff404_op in H. discriminate H. Qed.

Lemma reff404_not3262 : ~ @Equation3262 Fin4 reff404_inst.
Proof. unfold Equation3262. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff404_inst, reff404_op in H. discriminate H. Qed.

Lemma reff404_not3268 : ~ @Equation3268 Fin4 reff404_inst.
Proof. unfold Equation3268. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff404_inst, reff404_op in H. discriminate H. Qed.

Lemma reff404_not3269 : ~ @Equation3269 Fin4 reff404_inst.
Proof. unfold Equation3269. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff404_inst, reff404_op in H. discriminate H. Qed.

Lemma reff404_not3272 : ~ @Equation3272 Fin4 reff404_inst.
Proof. unfold Equation3272. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff404_inst, reff404_op in H. discriminate H. Qed.

Lemma reff404_not3279 : ~ @Equation3279 Fin4 reff404_inst.
Proof. unfold Equation3279. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff404_inst, reff404_op in H. discriminate H. Qed.

Lemma reff404_not3281 : ~ @Equation3281 Fin4 reff404_inst.
Proof. unfold Equation3281. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff404_inst, reff404_op in H. discriminate H. Qed.

Lemma reff404_not3308 : ~ @Equation3308 Fin4 reff404_inst.
Proof. unfold Equation3308. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff404_inst, reff404_op in H. discriminate H. Qed.

Lemma reff404_not3309 : ~ @Equation3309 Fin4 reff404_inst.
Proof. unfold Equation3309. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff404_inst, reff404_op in H. discriminate H. Qed.

Lemma reff404_not3315 : ~ @Equation3315 Fin4 reff404_inst.
Proof. unfold Equation3315. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff404_inst, reff404_op in H. discriminate H. Qed.

Lemma reff404_not3316 : ~ @Equation3316 Fin4 reff404_inst.
Proof. unfold Equation3316. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff404_inst, reff404_op in H. discriminate H. Qed.

Lemma reff404_not3318 : ~ @Equation3318 Fin4 reff404_inst.
Proof. unfold Equation3318. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff404_inst, reff404_op in H. discriminate H. Qed.

Lemma reff404_not3342 : ~ @Equation3342 Fin4 reff404_inst.
Proof. unfold Equation3342. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff404_inst, reff404_op in H. discriminate H. Qed.

Lemma reff404_not3343 : ~ @Equation3343 Fin4 reff404_inst.
Proof. unfold Equation3343. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff404_inst, reff404_op in H. discriminate H. Qed.

Lemma reff404_not3345 : ~ @Equation3345 Fin4 reff404_inst.
Proof. unfold Equation3345. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff404_inst, reff404_op in H. discriminate H. Qed.

Lemma reff404_not3352 : ~ @Equation3352 Fin4 reff404_inst.
Proof. unfold Equation3352. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff404_inst, reff404_op in H. discriminate H. Qed.

Lemma reff404_not3355 : ~ @Equation3355 Fin4 reff404_inst.
Proof. unfold Equation3355. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff404_inst, reff404_op in H. discriminate H. Qed.

Lemma reff404_not3457 : ~ @Equation3457 Fin4 reff404_inst.
Proof. unfold Equation3457. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff404_inst, reff404_op in H. discriminate H. Qed.

Lemma reff404_not3458 : ~ @Equation3458 Fin4 reff404_inst.
Proof. unfold Equation3458. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff404_inst, reff404_op in H. discriminate H. Qed.

Lemma reff404_not3459 : ~ @Equation3459 Fin4 reff404_inst.
Proof. unfold Equation3459. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff404_inst, reff404_op in H. discriminate H. Qed.

Lemma reff404_not3462 : ~ @Equation3462 Fin4 reff404_inst.
Proof. unfold Equation3462. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff404_inst, reff404_op in H. discriminate H. Qed.

Lemma reff404_not3464 : ~ @Equation3464 Fin4 reff404_inst.
Proof. unfold Equation3464. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff404_inst, reff404_op in H. discriminate H. Qed.

Lemma reff404_not3465 : ~ @Equation3465 Fin4 reff404_inst.
Proof. unfold Equation3465. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff404_inst, reff404_op in H. discriminate H. Qed.

Lemma reff404_not3472 : ~ @Equation3472 Fin4 reff404_inst.
Proof. unfold Equation3472. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff404_inst, reff404_op in H. discriminate H. Qed.

Lemma reff404_not3475 : ~ @Equation3475 Fin4 reff404_inst.
Proof. unfold Equation3475. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff404_inst, reff404_op in H. discriminate H. Qed.

Lemma reff404_not3481 : ~ @Equation3481 Fin4 reff404_inst.
Proof. unfold Equation3481. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff404_inst, reff404_op in H. discriminate H. Qed.

Lemma reff404_not3482 : ~ @Equation3482 Fin4 reff404_inst.
Proof. unfold Equation3482. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff404_inst, reff404_op in H. discriminate H. Qed.

Lemma reff404_not3509 : ~ @Equation3509 Fin4 reff404_inst.
Proof. unfold Equation3509. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff404_inst, reff404_op in H. discriminate H. Qed.

Lemma reff404_not3511 : ~ @Equation3511 Fin4 reff404_inst.
Proof. unfold Equation3511. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff404_inst, reff404_op in H. discriminate H. Qed.

Lemma reff404_not3518 : ~ @Equation3518 Fin4 reff404_inst.
Proof. unfold Equation3518. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff404_inst, reff404_op in H. discriminate H. Qed.

Lemma reff404_not3519 : ~ @Equation3519 Fin4 reff404_inst.
Proof. unfold Equation3519. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff404_inst, reff404_op in H. discriminate H. Qed.

Lemma reff404_not3521 : ~ @Equation3521 Fin4 reff404_inst.
Proof. unfold Equation3521. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff404_inst, reff404_op in H. discriminate H. Qed.

Lemma reff404_not3545 : ~ @Equation3545 Fin4 reff404_inst.
Proof. unfold Equation3545. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff404_inst, reff404_op in H. discriminate H. Qed.

Lemma reff404_not3548 : ~ @Equation3548 Fin4 reff404_inst.
Proof. unfold Equation3548. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff404_inst, reff404_op in H. discriminate H. Qed.

Lemma reff404_not3549 : ~ @Equation3549 Fin4 reff404_inst.
Proof. unfold Equation3549. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff404_inst, reff404_op in H. discriminate H. Qed.

Lemma reff404_not3555 : ~ @Equation3555 Fin4 reff404_inst.
Proof. unfold Equation3555. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff404_inst, reff404_op in H. discriminate H. Qed.

Lemma reff404_not3558 : ~ @Equation3558 Fin4 reff404_inst.
Proof. unfold Equation3558. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff404_inst, reff404_op in H. discriminate H. Qed.

Lemma reff404_not3660 : ~ @Equation3660 Fin4 reff404_inst.
Proof. unfold Equation3660. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff404_inst, reff404_op in H. discriminate H. Qed.

Lemma reff404_not3661 : ~ @Equation3661 Fin4 reff404_inst.
Proof. unfold Equation3661. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff404_inst, reff404_op in H. discriminate H. Qed.

Lemma reff404_not3662 : ~ @Equation3662 Fin4 reff404_inst.
Proof. unfold Equation3662. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff404_inst, reff404_op in H. discriminate H. Qed.

Lemma reff404_not3664 : ~ @Equation3664 Fin4 reff404_inst.
Proof. unfold Equation3664. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff404_inst, reff404_op in H. discriminate H. Qed.

Lemma reff404_not3665 : ~ @Equation3665 Fin4 reff404_inst.
Proof. unfold Equation3665. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff404_inst, reff404_op in H. discriminate H. Qed.

Lemma reff404_not3668 : ~ @Equation3668 Fin4 reff404_inst.
Proof. unfold Equation3668. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff404_inst, reff404_op in H. discriminate H. Qed.

Lemma reff404_not3675 : ~ @Equation3675 Fin4 reff404_inst.
Proof. unfold Equation3675. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff404_inst, reff404_op in H. discriminate H. Qed.

Lemma reff404_not3677 : ~ @Equation3677 Fin4 reff404_inst.
Proof. unfold Equation3677. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff404_inst, reff404_op in H. discriminate H. Qed.

Lemma reff404_not3678 : ~ @Equation3678 Fin4 reff404_inst.
Proof. unfold Equation3678. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff404_inst, reff404_op in H. discriminate H. Qed.

Lemma reff404_not3684 : ~ @Equation3684 Fin4 reff404_inst.
Proof. unfold Equation3684. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff404_inst, reff404_op in H. discriminate H. Qed.

Lemma reff404_not3685 : ~ @Equation3685 Fin4 reff404_inst.
Proof. unfold Equation3685. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff404_inst, reff404_op in H. discriminate H. Qed.

Lemma reff404_not3712 : ~ @Equation3712 Fin4 reff404_inst.
Proof. unfold Equation3712. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff404_inst, reff404_op in H. discriminate H. Qed.

Lemma reff404_not3714 : ~ @Equation3714 Fin4 reff404_inst.
Proof. unfold Equation3714. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff404_inst, reff404_op in H. discriminate H. Qed.

Lemma reff404_not3721 : ~ @Equation3721 Fin4 reff404_inst.
Proof. unfold Equation3721. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff404_inst, reff404_op in H. discriminate H. Qed.

Lemma reff404_not3724 : ~ @Equation3724 Fin4 reff404_inst.
Proof. unfold Equation3724. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff404_inst, reff404_op in H. discriminate H. Qed.

Lemma reff404_not3725 : ~ @Equation3725 Fin4 reff404_inst.
Proof. unfold Equation3725. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff404_inst, reff404_op in H. discriminate H. Qed.

Lemma reff404_not3748 : ~ @Equation3748 Fin4 reff404_inst.
Proof. unfold Equation3748. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff404_inst, reff404_op in H. discriminate H. Qed.

Lemma reff404_not3749 : ~ @Equation3749 Fin4 reff404_inst.
Proof. unfold Equation3749. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff404_inst, reff404_op in H. discriminate H. Qed.

Lemma reff404_not3751 : ~ @Equation3751 Fin4 reff404_inst.
Proof. unfold Equation3751. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff404_inst, reff404_op in H. discriminate H. Qed.

Lemma reff404_not3758 : ~ @Equation3758 Fin4 reff404_inst.
Proof. unfold Equation3758. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff404_inst, reff404_op in H. discriminate H. Qed.

Lemma reff404_not3761 : ~ @Equation3761 Fin4 reff404_inst.
Proof. unfold Equation3761. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff404_inst, reff404_op in H. discriminate H. Qed.

Lemma reff404_not3864 : ~ @Equation3864 Fin4 reff404_inst.
Proof. unfold Equation3864. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff404_inst, reff404_op in H. discriminate H. Qed.

Lemma reff404_not3865 : ~ @Equation3865 Fin4 reff404_inst.
Proof. unfold Equation3865. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff404_inst, reff404_op in H. discriminate H. Qed.

Lemma reff404_not3868 : ~ @Equation3868 Fin4 reff404_inst.
Proof. unfold Equation3868. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff404_inst, reff404_op in H. discriminate H. Qed.

Lemma reff404_not3870 : ~ @Equation3870 Fin4 reff404_inst.
Proof. unfold Equation3870. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff404_inst, reff404_op in H. discriminate H. Qed.

Lemma reff404_not3871 : ~ @Equation3871 Fin4 reff404_inst.
Proof. unfold Equation3871. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff404_inst, reff404_op in H. discriminate H. Qed.

Lemma reff404_not3878 : ~ @Equation3878 Fin4 reff404_inst.
Proof. unfold Equation3878. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff404_inst, reff404_op in H. discriminate H. Qed.

Lemma reff404_not3880 : ~ @Equation3880 Fin4 reff404_inst.
Proof. unfold Equation3880. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff404_inst, reff404_op in H. discriminate H. Qed.

Lemma reff404_not3881 : ~ @Equation3881 Fin4 reff404_inst.
Proof. unfold Equation3881. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff404_inst, reff404_op in H. discriminate H. Qed.

Lemma reff404_not3888 : ~ @Equation3888 Fin4 reff404_inst.
Proof. unfold Equation3888. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff404_inst, reff404_op in H. discriminate H. Qed.

Lemma reff404_not3890 : ~ @Equation3890 Fin4 reff404_inst.
Proof. unfold Equation3890. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff404_inst, reff404_op in H. discriminate H. Qed.

Lemma reff404_not3917 : ~ @Equation3917 Fin4 reff404_inst.
Proof. unfold Equation3917. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff404_inst, reff404_op in H. discriminate H. Qed.

Lemma reff404_not3918 : ~ @Equation3918 Fin4 reff404_inst.
Proof. unfold Equation3918. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff404_inst, reff404_op in H. discriminate H. Qed.

Lemma reff404_not3924 : ~ @Equation3924 Fin4 reff404_inst.
Proof. unfold Equation3924. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff404_inst, reff404_op in H. discriminate H. Qed.

Lemma reff404_not3927 : ~ @Equation3927 Fin4 reff404_inst.
Proof. unfold Equation3927. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff404_inst, reff404_op in H. discriminate H. Qed.

Lemma reff404_not3928 : ~ @Equation3928 Fin4 reff404_inst.
Proof. unfold Equation3928. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff404_inst, reff404_op in H. discriminate H. Qed.

Lemma reff404_not3951 : ~ @Equation3951 Fin4 reff404_inst.
Proof. unfold Equation3951. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff404_inst, reff404_op in H. discriminate H. Qed.

Lemma reff404_not3954 : ~ @Equation3954 Fin4 reff404_inst.
Proof. unfold Equation3954. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff404_inst, reff404_op in H. discriminate H. Qed.

Lemma reff404_not3955 : ~ @Equation3955 Fin4 reff404_inst.
Proof. unfold Equation3955. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff404_inst, reff404_op in H. discriminate H. Qed.

Lemma reff404_not3961 : ~ @Equation3961 Fin4 reff404_inst.
Proof. unfold Equation3961. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff404_inst, reff404_op in H. discriminate H. Qed.

Lemma reff404_not3964 : ~ @Equation3964 Fin4 reff404_inst.
Proof. unfold Equation3964. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff404_inst, reff404_op in H. discriminate H. Qed.

Lemma reff404_not4066 : ~ @Equation4066 Fin4 reff404_inst.
Proof. unfold Equation4066. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff404_inst, reff404_op in H. discriminate H. Qed.

Lemma reff404_not4067 : ~ @Equation4067 Fin4 reff404_inst.
Proof. unfold Equation4067. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff404_inst, reff404_op in H. discriminate H. Qed.

Lemma reff404_not4068 : ~ @Equation4068 Fin4 reff404_inst.
Proof. unfold Equation4068. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff404_inst, reff404_op in H. discriminate H. Qed.

Lemma reff404_not4071 : ~ @Equation4071 Fin4 reff404_inst.
Proof. unfold Equation4071. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff404_inst, reff404_op in H. discriminate H. Qed.

Lemma reff404_not4073 : ~ @Equation4073 Fin4 reff404_inst.
Proof. unfold Equation4073. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff404_inst, reff404_op in H. discriminate H. Qed.

Lemma reff404_not4074 : ~ @Equation4074 Fin4 reff404_inst.
Proof. unfold Equation4074. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff404_inst, reff404_op in H. discriminate H. Qed.

Lemma reff404_not4081 : ~ @Equation4081 Fin4 reff404_inst.
Proof. unfold Equation4081. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff404_inst, reff404_op in H. discriminate H. Qed.

Lemma reff404_not4083 : ~ @Equation4083 Fin4 reff404_inst.
Proof. unfold Equation4083. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff404_inst, reff404_op in H. discriminate H. Qed.

Lemma reff404_not4084 : ~ @Equation4084 Fin4 reff404_inst.
Proof. unfold Equation4084. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff404_inst, reff404_op in H. discriminate H. Qed.

Lemma reff404_not4091 : ~ @Equation4091 Fin4 reff404_inst.
Proof. unfold Equation4091. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff404_inst, reff404_op in H. discriminate H. Qed.

Lemma reff404_not4093 : ~ @Equation4093 Fin4 reff404_inst.
Proof. unfold Equation4093. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff404_inst, reff404_op in H. discriminate H. Qed.

Lemma reff404_not4120 : ~ @Equation4120 Fin4 reff404_inst.
Proof. unfold Equation4120. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff404_inst, reff404_op in H. discriminate H. Qed.

Lemma reff404_not4121 : ~ @Equation4121 Fin4 reff404_inst.
Proof. unfold Equation4121. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff404_inst, reff404_op in H. discriminate H. Qed.

Lemma reff404_not4127 : ~ @Equation4127 Fin4 reff404_inst.
Proof. unfold Equation4127. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff404_inst, reff404_op in H. discriminate H. Qed.

Lemma reff404_not4130 : ~ @Equation4130 Fin4 reff404_inst.
Proof. unfold Equation4130. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff404_inst, reff404_op in H. discriminate H. Qed.

Lemma reff404_not4131 : ~ @Equation4131 Fin4 reff404_inst.
Proof. unfold Equation4131. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff404_inst, reff404_op in H. discriminate H. Qed.

Lemma reff404_not4154 : ~ @Equation4154 Fin4 reff404_inst.
Proof. unfold Equation4154. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff404_inst, reff404_op in H. discriminate H. Qed.

Lemma reff404_not4157 : ~ @Equation4157 Fin4 reff404_inst.
Proof. unfold Equation4157. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff404_inst, reff404_op in H. discriminate H. Qed.

Lemma reff404_not4158 : ~ @Equation4158 Fin4 reff404_inst.
Proof. unfold Equation4158. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff404_inst, reff404_op in H. discriminate H. Qed.

Lemma reff404_not4164 : ~ @Equation4164 Fin4 reff404_inst.
Proof. unfold Equation4164. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff404_inst, reff404_op in H. discriminate H. Qed.

Lemma reff404_not4167 : ~ @Equation4167 Fin4 reff404_inst.
Proof. unfold Equation4167. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff404_inst, reff404_op in H. discriminate H. Qed.

Lemma reff404_not4268 : ~ @Equation4268 Fin4 reff404_inst.
Proof. unfold Equation4268. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff404_inst, reff404_op in H. discriminate H. Qed.

Lemma reff404_not4269 : ~ @Equation4269 Fin4 reff404_inst.
Proof. unfold Equation4269. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff404_inst, reff404_op in H. discriminate H. Qed.

Lemma reff404_not4270 : ~ @Equation4270 Fin4 reff404_inst.
Proof. unfold Equation4270. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff404_inst, reff404_op in H. discriminate H. Qed.

Lemma reff404_not4272 : ~ @Equation4272 Fin4 reff404_inst.
Proof. unfold Equation4272. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff404_inst, reff404_op in H. discriminate H. Qed.

Lemma reff404_not4273 : ~ @Equation4273 Fin4 reff404_inst.
Proof. unfold Equation4273. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff404_inst, reff404_op in H. discriminate H. Qed.

Lemma reff404_not4276 : ~ @Equation4276 Fin4 reff404_inst.
Proof. unfold Equation4276. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff404_inst, reff404_op in H. discriminate H. Qed.

Lemma reff404_not4283 : ~ @Equation4283 Fin4 reff404_inst.
Proof. unfold Equation4283. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff404_inst, reff404_op in H. discriminate H. Qed.

Lemma reff404_not4284 : ~ @Equation4284 Fin4 reff404_inst.
Proof. unfold Equation4284. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff404_inst, reff404_op in H. discriminate H. Qed.

Lemma reff404_not4290 : ~ @Equation4290 Fin4 reff404_inst.
Proof. unfold Equation4290. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff404_inst, reff404_op in H. discriminate H. Qed.

Lemma reff404_not4291 : ~ @Equation4291 Fin4 reff404_inst.
Proof. unfold Equation4291. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff404_inst, reff404_op in H. discriminate H. Qed.

Lemma reff404_not4293 : ~ @Equation4293 Fin4 reff404_inst.
Proof. unfold Equation4293. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff404_inst, reff404_op in H. discriminate H. Qed.

Lemma reff404_not4314 : ~ @Equation4314 Fin4 reff404_inst.
Proof. unfold Equation4314. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff404_inst, reff404_op in H. discriminate H. Qed.

Lemma reff404_not4321 : ~ @Equation4321 Fin4 reff404_inst.
Proof. unfold Equation4321. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff404_inst, reff404_op in H. discriminate H. Qed.

Lemma reff404_not4343 : ~ @Equation4343 Fin4 reff404_inst.
Proof. unfold Equation4343. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff404_inst, reff404_op in H. discriminate H. Qed.

Lemma reff404_not4396 : ~ @Equation4396 Fin4 reff404_inst.
Proof. unfold Equation4396. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff404_inst, reff404_op in H. discriminate H. Qed.

Lemma reff404_not4398 : ~ @Equation4398 Fin4 reff404_inst.
Proof. unfold Equation4398. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff404_inst, reff404_op in H. discriminate H. Qed.

Lemma reff404_not4405 : ~ @Equation4405 Fin4 reff404_inst.
Proof. unfold Equation4405. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff404_inst, reff404_op in H. discriminate H. Qed.

Lemma reff404_not4406 : ~ @Equation4406 Fin4 reff404_inst.
Proof. unfold Equation4406. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff404_inst, reff404_op in H. discriminate H. Qed.

Lemma reff404_not4408 : ~ @Equation4408 Fin4 reff404_inst.
Proof. unfold Equation4408. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff404_inst, reff404_op in H. discriminate H. Qed.

Lemma reff404_not4433 : ~ @Equation4433 Fin4 reff404_inst.
Proof. unfold Equation4433. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff404_inst, reff404_op in H. discriminate H. Qed.

Lemma reff404_not4436 : ~ @Equation4436 Fin4 reff404_inst.
Proof. unfold Equation4436. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff404_inst, reff404_op in H. discriminate H. Qed.

Lemma reff404_not4442 : ~ @Equation4442 Fin4 reff404_inst.
Proof. unfold Equation4442. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff404_inst, reff404_op in H. discriminate H. Qed.

Lemma reff404_not4443 : ~ @Equation4443 Fin4 reff404_inst.
Proof. unfold Equation4443. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff404_inst, reff404_op in H. discriminate H. Qed.

Lemma reff404_not4472 : ~ @Equation4472 Fin4 reff404_inst.
Proof. unfold Equation4472. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff404_inst, reff404_op in H. discriminate H. Qed.

Lemma reff404_not4473 : ~ @Equation4473 Fin4 reff404_inst.
Proof. unfold Equation4473. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff404_inst, reff404_op in H. discriminate H. Qed.

Lemma reff404_not4479 : ~ @Equation4479 Fin4 reff404_inst.
Proof. unfold Equation4479. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff404_inst, reff404_op in H. discriminate H. Qed.

Lemma reff404_not4482 : ~ @Equation4482 Fin4 reff404_inst.
Proof. unfold Equation4482. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff404_inst, reff404_op in H. discriminate H. Qed.

Lemma reff404_not4583 : ~ @Equation4583 Fin4 reff404_inst.
Proof. unfold Equation4583. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff404_inst, reff404_op in H. discriminate H. Qed.

Lemma reff404_not4584 : ~ @Equation4584 Fin4 reff404_inst.
Proof. unfold Equation4584. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff404_inst, reff404_op in H. discriminate H. Qed.

Lemma reff404_not4585 : ~ @Equation4585 Fin4 reff404_inst.
Proof. unfold Equation4585. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff404_inst, reff404_op in H. discriminate H. Qed.

Lemma reff404_not4588 : ~ @Equation4588 Fin4 reff404_inst.
Proof. unfold Equation4588. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff404_inst, reff404_op in H. discriminate H. Qed.

Lemma reff404_not4590 : ~ @Equation4590 Fin4 reff404_inst.
Proof. unfold Equation4590. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff404_inst, reff404_op in H. discriminate H. Qed.

Lemma reff404_not4591 : ~ @Equation4591 Fin4 reff404_inst.
Proof. unfold Equation4591. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff404_inst, reff404_op in H. discriminate H. Qed.

Lemma reff404_not4598 : ~ @Equation4598 Fin4 reff404_inst.
Proof. unfold Equation4598. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff404_inst, reff404_op in H. discriminate H. Qed.

Lemma reff404_not4599 : ~ @Equation4599 Fin4 reff404_inst.
Proof. unfold Equation4599. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff404_inst, reff404_op in H. discriminate H. Qed.

Lemma reff404_not4605 : ~ @Equation4605 Fin4 reff404_inst.
Proof. unfold Equation4605. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff404_inst, reff404_op in H. discriminate H. Qed.

Lemma reff404_not4608 : ~ @Equation4608 Fin4 reff404_inst.
Proof. unfold Equation4608. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff404_inst, reff404_op in H. discriminate H. Qed.

Lemma reff404_not4629 : ~ @Equation4629 Fin4 reff404_inst.
Proof. unfold Equation4629. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff404_inst, reff404_op in H. discriminate H. Qed.

Lemma reff404_not4635 : ~ @Equation4635 Fin4 reff404_inst.
Proof. unfold Equation4635. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff404_inst, reff404_op in H. discriminate H. Qed.

Lemma reff404_not4636 : ~ @Equation4636 Fin4 reff404_inst.
Proof. unfold Equation4636. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff404_inst, reff404_op in H. discriminate H. Qed.

Lemma reff404_not4658 : ~ @Equation4658 Fin4 reff404_inst.
Proof. unfold Equation4658. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff404_inst, reff404_op in H. discriminate H. Qed.

(** ---- reff406 (Fin4) ---- *)

Definition reff406_op (x y : Fin4) : Fin4 :=
  match x, y with
  | F4_0, F4_0 => F4_0 | F4_0, F4_1 => F4_3 | F4_0, F4_2 => F4_2 | F4_0, F4_3 => F4_1
  | F4_1, F4_0 => F4_3 | F4_1, F4_1 => F4_0 | F4_1, F4_2 => F4_1 | F4_1, F4_3 => F4_2
  | F4_2, F4_0 => F4_0 | F4_2, F4_1 => F4_3 | F4_2, F4_2 => F4_2 | F4_2, F4_3 => F4_1
  | F4_3, F4_0 => F4_3 | F4_3, F4_1 => F4_0 | F4_3, F4_2 => F4_1 | F4_3, F4_3 => F4_2
  end.

#[local] Instance reff406_inst : Magma Fin4 := {| magma_op := reff406_op |}.

Lemma reff406_sat562 : @Equation562 Fin4 reff406_inst.
Proof. unfold Equation562, magma_op, reff406_inst, reff406_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff406_sat622 : @Equation622 Fin4 reff406_inst.
Proof. unfold Equation622, magma_op, reff406_inst, reff406_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff406_sat669 : @Equation669 Fin4 reff406_inst.
Proof. unfold Equation669, magma_op, reff406_inst, reff406_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff406_sat676 : @Equation676 Fin4 reff406_inst.
Proof. unfold Equation676, magma_op, reff406_inst, reff406_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff406_sat1444 : @Equation1444 Fin4 reff406_inst.
Proof. unfold Equation1444, magma_op, reff406_inst, reff406_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff406_sat1481 : @Equation1481 Fin4 reff406_inst.
Proof. unfold Equation1481, magma_op, reff406_inst, reff406_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff406_sat1515 : @Equation1515 Fin4 reff406_inst.
Proof. unfold Equation1515, magma_op, reff406_inst, reff406_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff406_sat1746 : @Equation1746 Fin4 reff406_inst.
Proof. unfold Equation1746, magma_op, reff406_inst, reff406_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff406_sat3684 : @Equation3684 Fin4 reff406_inst.
Proof. unfold Equation3684, magma_op, reff406_inst, reff406_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff406_sat3725 : @Equation3725 Fin4 reff406_inst.
Proof. unfold Equation3725, magma_op, reff406_inst, reff406_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff406_sat3752 : @Equation3752 Fin4 reff406_inst.
Proof. unfold Equation3752, magma_op, reff406_inst, reff406_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff406_sat3943 : @Equation3943 Fin4 reff406_inst.
Proof. unfold Equation3943, magma_op, reff406_inst, reff406_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff406_sat4023 : @Equation4023 Fin4 reff406_inst.
Proof. unfold Equation4023, magma_op, reff406_inst, reff406_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff406_sat4146 : @Equation4146 Fin4 reff406_inst.
Proof. unfold Equation4146, magma_op, reff406_inst, reff406_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff406_sat4200 : @Equation4200 Fin4 reff406_inst.
Proof. unfold Equation4200, magma_op, reff406_inst, reff406_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff406_sat4226 : @Equation4226 Fin4 reff406_inst.
Proof. unfold Equation4226, magma_op, reff406_inst, reff406_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff406_sat4388 : @Equation4388 Fin4 reff406_inst.
Proof. unfold Equation4388, magma_op, reff406_inst, reff406_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff406_sat4473 : @Equation4473 Fin4 reff406_inst.
Proof. unfold Equation4473, magma_op, reff406_inst, reff406_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff406_sat4480 : @Equation4480 Fin4 reff406_inst.
Proof. unfold Equation4480, magma_op, reff406_inst, reff406_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff406_sat4677 : @Equation4677 Fin4 reff406_inst.
Proof. unfold Equation4677, magma_op, reff406_inst, reff406_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff406_not47 : ~ @Equation47 Fin4 reff406_inst.
Proof. unfold Equation47. intro H. specialize (H F4_1). unfold magma_op, reff406_inst, reff406_op in H. discriminate H. Qed.

Lemma reff406_not99 : ~ @Equation99 Fin4 reff406_inst.
Proof. unfold Equation99. intro H. specialize (H F4_1). unfold magma_op, reff406_inst, reff406_op in H. discriminate H. Qed.

Lemma reff406_not151 : ~ @Equation151 Fin4 reff406_inst.
Proof. unfold Equation151. intro H. specialize (H F4_1). unfold magma_op, reff406_inst, reff406_op in H. discriminate H. Qed.

Lemma reff406_not203 : ~ @Equation203 Fin4 reff406_inst.
Proof. unfold Equation203. intro H. specialize (H F4_1). unfold magma_op, reff406_inst, reff406_op in H. discriminate H. Qed.

Lemma reff406_not255 : ~ @Equation255 Fin4 reff406_inst.
Proof. unfold Equation255. intro H. specialize (H F4_1). unfold magma_op, reff406_inst, reff406_op in H. discriminate H. Qed.

Lemma reff406_not359 : ~ @Equation359 Fin4 reff406_inst.
Proof. unfold Equation359. intro H. specialize (H F4_1). unfold magma_op, reff406_inst, reff406_op in H. discriminate H. Qed.

Lemma reff406_not412 : ~ @Equation412 Fin4 reff406_inst.
Proof. unfold Equation412. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff406_inst, reff406_op in H. discriminate H. Qed.

Lemma reff406_not413 : ~ @Equation413 Fin4 reff406_inst.
Proof. unfold Equation413. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff406_inst, reff406_op in H. discriminate H. Qed.

Lemma reff406_not414 : ~ @Equation414 Fin4 reff406_inst.
Proof. unfold Equation414. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff406_inst, reff406_op in H. discriminate H. Qed.

Lemma reff406_not416 : ~ @Equation416 Fin4 reff406_inst.
Proof. unfold Equation416. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff406_inst, reff406_op in H. discriminate H. Qed.

Lemma reff406_not417 : ~ @Equation417 Fin4 reff406_inst.
Proof. unfold Equation417. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff406_inst, reff406_op in H. discriminate H. Qed.

Lemma reff406_not419 : ~ @Equation419 Fin4 reff406_inst.
Proof. unfold Equation419. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff406_inst, reff406_op in H. discriminate H. Qed.

Lemma reff406_not420 : ~ @Equation420 Fin4 reff406_inst.
Proof. unfold Equation420. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff406_inst, reff406_op in H. discriminate H. Qed.

Lemma reff406_not426 : ~ @Equation426 Fin4 reff406_inst.
Proof. unfold Equation426. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff406_inst, reff406_op in H. discriminate H. Qed.

Lemma reff406_not427 : ~ @Equation427 Fin4 reff406_inst.
Proof. unfold Equation427. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff406_inst, reff406_op in H. discriminate H. Qed.

Lemma reff406_not430 : ~ @Equation430 Fin4 reff406_inst.
Proof. unfold Equation430. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff406_inst, reff406_op in H. discriminate H. Qed.

Lemma reff406_not436 : ~ @Equation436 Fin4 reff406_inst.
Proof. unfold Equation436. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff406_inst, reff406_op in H. discriminate H. Qed.

Lemma reff406_not437 : ~ @Equation437 Fin4 reff406_inst.
Proof. unfold Equation437. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff406_inst, reff406_op in H. discriminate H. Qed.

Lemma reff406_not439 : ~ @Equation439 Fin4 reff406_inst.
Proof. unfold Equation439. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff406_inst, reff406_op in H. discriminate H. Qed.

Lemma reff406_not440 : ~ @Equation440 Fin4 reff406_inst.
Proof. unfold Equation440. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff406_inst, reff406_op in H. discriminate H. Qed.

Lemma reff406_not463 : ~ @Equation463 Fin4 reff406_inst.
Proof. unfold Equation463. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff406_inst, reff406_op in H. discriminate H. Qed.

Lemma reff406_not464 : ~ @Equation464 Fin4 reff406_inst.
Proof. unfold Equation464. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff406_inst, reff406_op in H. discriminate H. Qed.

Lemma reff406_not466 : ~ @Equation466 Fin4 reff406_inst.
Proof. unfold Equation466. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff406_inst, reff406_op in H. discriminate H. Qed.

Lemma reff406_not467 : ~ @Equation467 Fin4 reff406_inst.
Proof. unfold Equation467. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff406_inst, reff406_op in H. discriminate H. Qed.

Lemma reff406_not474 : ~ @Equation474 Fin4 reff406_inst.
Proof. unfold Equation474. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff406_inst, reff406_op in H. discriminate H. Qed.

Lemma reff406_not476 : ~ @Equation476 Fin4 reff406_inst.
Proof. unfold Equation476. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff406_inst, reff406_op in H. discriminate H. Qed.

Lemma reff406_not477 : ~ @Equation477 Fin4 reff406_inst.
Proof. unfold Equation477. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff406_inst, reff406_op in H. discriminate H. Qed.

Lemma reff406_not500 : ~ @Equation500 Fin4 reff406_inst.
Proof. unfold Equation500. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff406_inst, reff406_op in H. discriminate H. Qed.

Lemma reff406_not501 : ~ @Equation501 Fin4 reff406_inst.
Proof. unfold Equation501. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff406_inst, reff406_op in H. discriminate H. Qed.

Lemma reff406_not503 : ~ @Equation503 Fin4 reff406_inst.
Proof. unfold Equation503. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff406_inst, reff406_op in H. discriminate H. Qed.

Lemma reff406_not504 : ~ @Equation504 Fin4 reff406_inst.
Proof. unfold Equation504. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff406_inst, reff406_op in H. discriminate H. Qed.

Lemma reff406_not510 : ~ @Equation510 Fin4 reff406_inst.
Proof. unfold Equation510. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff406_inst, reff406_op in H. discriminate H. Qed.

Lemma reff406_not511 : ~ @Equation511 Fin4 reff406_inst.
Proof. unfold Equation511. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff406_inst, reff406_op in H. discriminate H. Qed.

Lemma reff406_not615 : ~ @Equation615 Fin4 reff406_inst.
Proof. unfold Equation615. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff406_inst, reff406_op in H. discriminate H. Qed.

Lemma reff406_not616 : ~ @Equation616 Fin4 reff406_inst.
Proof. unfold Equation616. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff406_inst, reff406_op in H. discriminate H. Qed.

Lemma reff406_not617 : ~ @Equation617 Fin4 reff406_inst.
Proof. unfold Equation617. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff406_inst, reff406_op in H. discriminate H. Qed.

Lemma reff406_not619 : ~ @Equation619 Fin4 reff406_inst.
Proof. unfold Equation619. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff406_inst, reff406_op in H. discriminate H. Qed.

Lemma reff406_not620 : ~ @Equation620 Fin4 reff406_inst.
Proof. unfold Equation620. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff406_inst, reff406_op in H. discriminate H. Qed.

Lemma reff406_not623 : ~ @Equation623 Fin4 reff406_inst.
Proof. unfold Equation623. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff406_inst, reff406_op in H. discriminate H. Qed.

Lemma reff406_not629 : ~ @Equation629 Fin4 reff406_inst.
Proof. unfold Equation629. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff406_inst, reff406_op in H. discriminate H. Qed.

Lemma reff406_not630 : ~ @Equation630 Fin4 reff406_inst.
Proof. unfold Equation630. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff406_inst, reff406_op in H. discriminate H. Qed.

Lemma reff406_not632 : ~ @Equation632 Fin4 reff406_inst.
Proof. unfold Equation632. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff406_inst, reff406_op in H. discriminate H. Qed.

Lemma reff406_not633 : ~ @Equation633 Fin4 reff406_inst.
Proof. unfold Equation633. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff406_inst, reff406_op in H. discriminate H. Qed.

Lemma reff406_not639 : ~ @Equation639 Fin4 reff406_inst.
Proof. unfold Equation639. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff406_inst, reff406_op in H. discriminate H. Qed.

Lemma reff406_not640 : ~ @Equation640 Fin4 reff406_inst.
Proof. unfold Equation640. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff406_inst, reff406_op in H. discriminate H. Qed.

Lemma reff406_not642 : ~ @Equation642 Fin4 reff406_inst.
Proof. unfold Equation642. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff406_inst, reff406_op in H. discriminate H. Qed.

Lemma reff406_not643 : ~ @Equation643 Fin4 reff406_inst.
Proof. unfold Equation643. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff406_inst, reff406_op in H. discriminate H. Qed.

Lemma reff406_not666 : ~ @Equation666 Fin4 reff406_inst.
Proof. unfold Equation666. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff406_inst, reff406_op in H. discriminate H. Qed.

Lemma reff406_not667 : ~ @Equation667 Fin4 reff406_inst.
Proof. unfold Equation667. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff406_inst, reff406_op in H. discriminate H. Qed.

Lemma reff406_not670 : ~ @Equation670 Fin4 reff406_inst.
Proof. unfold Equation670. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff406_inst, reff406_op in H. discriminate H. Qed.

Lemma reff406_not677 : ~ @Equation677 Fin4 reff406_inst.
Proof. unfold Equation677. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff406_inst, reff406_op in H. discriminate H. Qed.

Lemma reff406_not679 : ~ @Equation679 Fin4 reff406_inst.
Proof. unfold Equation679. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff406_inst, reff406_op in H. discriminate H. Qed.

Lemma reff406_not680 : ~ @Equation680 Fin4 reff406_inst.
Proof. unfold Equation680. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff406_inst, reff406_op in H. discriminate H. Qed.

Lemma reff406_not703 : ~ @Equation703 Fin4 reff406_inst.
Proof. unfold Equation703. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff406_inst, reff406_op in H. discriminate H. Qed.

Lemma reff406_not704 : ~ @Equation704 Fin4 reff406_inst.
Proof. unfold Equation704. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff406_inst, reff406_op in H. discriminate H. Qed.

Lemma reff406_not706 : ~ @Equation706 Fin4 reff406_inst.
Proof. unfold Equation706. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff406_inst, reff406_op in H. discriminate H. Qed.

Lemma reff406_not707 : ~ @Equation707 Fin4 reff406_inst.
Proof. unfold Equation707. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff406_inst, reff406_op in H. discriminate H. Qed.

Lemma reff406_not713 : ~ @Equation713 Fin4 reff406_inst.
Proof. unfold Equation713. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff406_inst, reff406_op in H. discriminate H. Qed.

Lemma reff406_not714 : ~ @Equation714 Fin4 reff406_inst.
Proof. unfold Equation714. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff406_inst, reff406_op in H. discriminate H. Qed.

Lemma reff406_not716 : ~ @Equation716 Fin4 reff406_inst.
Proof. unfold Equation716. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff406_inst, reff406_op in H. discriminate H. Qed.

Lemma reff406_not817 : ~ @Equation817 Fin4 reff406_inst.
Proof. unfold Equation817. intro H. specialize (H F4_1). unfold magma_op, reff406_inst, reff406_op in H. discriminate H. Qed.

Lemma reff406_not1020 : ~ @Equation1020 Fin4 reff406_inst.
Proof. unfold Equation1020. intro H. specialize (H F4_1). unfold magma_op, reff406_inst, reff406_op in H. discriminate H. Qed.

Lemma reff406_not1223 : ~ @Equation1223 Fin4 reff406_inst.
Proof. unfold Equation1223. intro H. specialize (H F4_1). unfold magma_op, reff406_inst, reff406_op in H. discriminate H. Qed.

Lemma reff406_not1427 : ~ @Equation1427 Fin4 reff406_inst.
Proof. unfold Equation1427. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff406_inst, reff406_op in H. discriminate H. Qed.

Lemma reff406_not1428 : ~ @Equation1428 Fin4 reff406_inst.
Proof. unfold Equation1428. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff406_inst, reff406_op in H. discriminate H. Qed.

Lemma reff406_not1429 : ~ @Equation1429 Fin4 reff406_inst.
Proof. unfold Equation1429. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff406_inst, reff406_op in H. discriminate H. Qed.

Lemma reff406_not1431 : ~ @Equation1431 Fin4 reff406_inst.
Proof. unfold Equation1431. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff406_inst, reff406_op in H. discriminate H. Qed.

Lemma reff406_not1432 : ~ @Equation1432 Fin4 reff406_inst.
Proof. unfold Equation1432. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff406_inst, reff406_op in H. discriminate H. Qed.

Lemma reff406_not1434 : ~ @Equation1434 Fin4 reff406_inst.
Proof. unfold Equation1434. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff406_inst, reff406_op in H. discriminate H. Qed.

Lemma reff406_not1435 : ~ @Equation1435 Fin4 reff406_inst.
Proof. unfold Equation1435. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff406_inst, reff406_op in H. discriminate H. Qed.

Lemma reff406_not1441 : ~ @Equation1441 Fin4 reff406_inst.
Proof. unfold Equation1441. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff406_inst, reff406_op in H. discriminate H. Qed.

Lemma reff406_not1442 : ~ @Equation1442 Fin4 reff406_inst.
Proof. unfold Equation1442. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff406_inst, reff406_op in H. discriminate H. Qed.

Lemma reff406_not1445 : ~ @Equation1445 Fin4 reff406_inst.
Proof. unfold Equation1445. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff406_inst, reff406_op in H. discriminate H. Qed.

Lemma reff406_not1451 : ~ @Equation1451 Fin4 reff406_inst.
Proof. unfold Equation1451. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff406_inst, reff406_op in H. discriminate H. Qed.

Lemma reff406_not1452 : ~ @Equation1452 Fin4 reff406_inst.
Proof. unfold Equation1452. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff406_inst, reff406_op in H. discriminate H. Qed.

Lemma reff406_not1454 : ~ @Equation1454 Fin4 reff406_inst.
Proof. unfold Equation1454. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff406_inst, reff406_op in H. discriminate H. Qed.

Lemma reff406_not1455 : ~ @Equation1455 Fin4 reff406_inst.
Proof. unfold Equation1455. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff406_inst, reff406_op in H. discriminate H. Qed.

Lemma reff406_not1478 : ~ @Equation1478 Fin4 reff406_inst.
Proof. unfold Equation1478. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff406_inst, reff406_op in H. discriminate H. Qed.

Lemma reff406_not1479 : ~ @Equation1479 Fin4 reff406_inst.
Proof. unfold Equation1479. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff406_inst, reff406_op in H. discriminate H. Qed.

Lemma reff406_not1482 : ~ @Equation1482 Fin4 reff406_inst.
Proof. unfold Equation1482. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff406_inst, reff406_op in H. discriminate H. Qed.

Lemma reff406_not1488 : ~ @Equation1488 Fin4 reff406_inst.
Proof. unfold Equation1488. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff406_inst, reff406_op in H. discriminate H. Qed.

Lemma reff406_not1489 : ~ @Equation1489 Fin4 reff406_inst.
Proof. unfold Equation1489. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff406_inst, reff406_op in H. discriminate H. Qed.

Lemma reff406_not1491 : ~ @Equation1491 Fin4 reff406_inst.
Proof. unfold Equation1491. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff406_inst, reff406_op in H. discriminate H. Qed.

Lemma reff406_not1492 : ~ @Equation1492 Fin4 reff406_inst.
Proof. unfold Equation1492. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff406_inst, reff406_op in H. discriminate H. Qed.

Lemma reff406_not1516 : ~ @Equation1516 Fin4 reff406_inst.
Proof. unfold Equation1516. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff406_inst, reff406_op in H. discriminate H. Qed.

Lemma reff406_not1518 : ~ @Equation1518 Fin4 reff406_inst.
Proof. unfold Equation1518. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff406_inst, reff406_op in H. discriminate H. Qed.

Lemma reff406_not1519 : ~ @Equation1519 Fin4 reff406_inst.
Proof. unfold Equation1519. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff406_inst, reff406_op in H. discriminate H. Qed.

Lemma reff406_not1525 : ~ @Equation1525 Fin4 reff406_inst.
Proof. unfold Equation1525. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff406_inst, reff406_op in H. discriminate H. Qed.

Lemma reff406_not1526 : ~ @Equation1526 Fin4 reff406_inst.
Proof. unfold Equation1526. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff406_inst, reff406_op in H. discriminate H. Qed.

Lemma reff406_not1528 : ~ @Equation1528 Fin4 reff406_inst.
Proof. unfold Equation1528. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff406_inst, reff406_op in H. discriminate H. Qed.

Lemma reff406_not1630 : ~ @Equation1630 Fin4 reff406_inst.
Proof. unfold Equation1630. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff406_inst, reff406_op in H. discriminate H. Qed.

Lemma reff406_not1631 : ~ @Equation1631 Fin4 reff406_inst.
Proof. unfold Equation1631. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff406_inst, reff406_op in H. discriminate H. Qed.

Lemma reff406_not1632 : ~ @Equation1632 Fin4 reff406_inst.
Proof. unfold Equation1632. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff406_inst, reff406_op in H. discriminate H. Qed.

Lemma reff406_not1634 : ~ @Equation1634 Fin4 reff406_inst.
Proof. unfold Equation1634. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff406_inst, reff406_op in H. discriminate H. Qed.

Lemma reff406_not1635 : ~ @Equation1635 Fin4 reff406_inst.
Proof. unfold Equation1635. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff406_inst, reff406_op in H. discriminate H. Qed.

Lemma reff406_not1638 : ~ @Equation1638 Fin4 reff406_inst.
Proof. unfold Equation1638. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff406_inst, reff406_op in H. discriminate H. Qed.

Lemma reff406_not1644 : ~ @Equation1644 Fin4 reff406_inst.
Proof. unfold Equation1644. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff406_inst, reff406_op in H. discriminate H. Qed.

Lemma reff406_not1645 : ~ @Equation1645 Fin4 reff406_inst.
Proof. unfold Equation1645. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff406_inst, reff406_op in H. discriminate H. Qed.

Lemma reff406_not1647 : ~ @Equation1647 Fin4 reff406_inst.
Proof. unfold Equation1647. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff406_inst, reff406_op in H. discriminate H. Qed.

Lemma reff406_not1648 : ~ @Equation1648 Fin4 reff406_inst.
Proof. unfold Equation1648. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff406_inst, reff406_op in H. discriminate H. Qed.

Lemma reff406_not1654 : ~ @Equation1654 Fin4 reff406_inst.
Proof. unfold Equation1654. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff406_inst, reff406_op in H. discriminate H. Qed.

Lemma reff406_not1655 : ~ @Equation1655 Fin4 reff406_inst.
Proof. unfold Equation1655. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff406_inst, reff406_op in H. discriminate H. Qed.

Lemma reff406_not1657 : ~ @Equation1657 Fin4 reff406_inst.
Proof. unfold Equation1657. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff406_inst, reff406_op in H. discriminate H. Qed.

Lemma reff406_not1658 : ~ @Equation1658 Fin4 reff406_inst.
Proof. unfold Equation1658. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff406_inst, reff406_op in H. discriminate H. Qed.

Lemma reff406_not1681 : ~ @Equation1681 Fin4 reff406_inst.
Proof. unfold Equation1681. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff406_inst, reff406_op in H. discriminate H. Qed.

Lemma reff406_not1682 : ~ @Equation1682 Fin4 reff406_inst.
Proof. unfold Equation1682. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff406_inst, reff406_op in H. discriminate H. Qed.

Lemma reff406_not1684 : ~ @Equation1684 Fin4 reff406_inst.
Proof. unfold Equation1684. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff406_inst, reff406_op in H. discriminate H. Qed.

Lemma reff406_not1685 : ~ @Equation1685 Fin4 reff406_inst.
Proof. unfold Equation1685. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff406_inst, reff406_op in H. discriminate H. Qed.

Lemma reff406_not1691 : ~ @Equation1691 Fin4 reff406_inst.
Proof. unfold Equation1691. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff406_inst, reff406_op in H. discriminate H. Qed.

Lemma reff406_not1692 : ~ @Equation1692 Fin4 reff406_inst.
Proof. unfold Equation1692. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff406_inst, reff406_op in H. discriminate H. Qed.

Lemma reff406_not1694 : ~ @Equation1694 Fin4 reff406_inst.
Proof. unfold Equation1694. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff406_inst, reff406_op in H. discriminate H. Qed.

Lemma reff406_not1695 : ~ @Equation1695 Fin4 reff406_inst.
Proof. unfold Equation1695. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff406_inst, reff406_op in H. discriminate H. Qed.

Lemma reff406_not1719 : ~ @Equation1719 Fin4 reff406_inst.
Proof. unfold Equation1719. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff406_inst, reff406_op in H. discriminate H. Qed.

Lemma reff406_not1721 : ~ @Equation1721 Fin4 reff406_inst.
Proof. unfold Equation1721. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff406_inst, reff406_op in H. discriminate H. Qed.

Lemma reff406_not1722 : ~ @Equation1722 Fin4 reff406_inst.
Proof. unfold Equation1722. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff406_inst, reff406_op in H. discriminate H. Qed.

Lemma reff406_not1728 : ~ @Equation1728 Fin4 reff406_inst.
Proof. unfold Equation1728. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff406_inst, reff406_op in H. discriminate H. Qed.

Lemma reff406_not1729 : ~ @Equation1729 Fin4 reff406_inst.
Proof. unfold Equation1729. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff406_inst, reff406_op in H. discriminate H. Qed.

Lemma reff406_not1832 : ~ @Equation1832 Fin4 reff406_inst.
Proof. unfold Equation1832. intro H. specialize (H F4_1). unfold magma_op, reff406_inst, reff406_op in H. discriminate H. Qed.

Lemma reff406_not2035 : ~ @Equation2035 Fin4 reff406_inst.
Proof. unfold Equation2035. intro H. specialize (H F4_1). unfold magma_op, reff406_inst, reff406_op in H. discriminate H. Qed.

Lemma reff406_not2238 : ~ @Equation2238 Fin4 reff406_inst.
Proof. unfold Equation2238. intro H. specialize (H F4_1). unfold magma_op, reff406_inst, reff406_op in H. discriminate H. Qed.

Lemma reff406_not2441 : ~ @Equation2441 Fin4 reff406_inst.
Proof. unfold Equation2441. intro H. specialize (H F4_1). unfold magma_op, reff406_inst, reff406_op in H. discriminate H. Qed.

Lemma reff406_not2644 : ~ @Equation2644 Fin4 reff406_inst.
Proof. unfold Equation2644. intro H. specialize (H F4_1). unfold magma_op, reff406_inst, reff406_op in H. discriminate H. Qed.

Lemma reff406_not2847 : ~ @Equation2847 Fin4 reff406_inst.
Proof. unfold Equation2847. intro H. specialize (H F4_1). unfold magma_op, reff406_inst, reff406_op in H. discriminate H. Qed.

Lemma reff406_not3050 : ~ @Equation3050 Fin4 reff406_inst.
Proof. unfold Equation3050. intro H. specialize (H F4_1). unfold magma_op, reff406_inst, reff406_op in H. discriminate H. Qed.

Lemma reff406_not3253 : ~ @Equation3253 Fin4 reff406_inst.
Proof. unfold Equation3253. intro H. specialize (H F4_1). unfold magma_op, reff406_inst, reff406_op in H. discriminate H. Qed.

Lemma reff406_not3456 : ~ @Equation3456 Fin4 reff406_inst.
Proof. unfold Equation3456. intro H. specialize (H F4_1). unfold magma_op, reff406_inst, reff406_op in H. discriminate H. Qed.

Lemma reff406_not3660 : ~ @Equation3660 Fin4 reff406_inst.
Proof. unfold Equation3660. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff406_inst, reff406_op in H. discriminate H. Qed.

Lemma reff406_not3661 : ~ @Equation3661 Fin4 reff406_inst.
Proof. unfold Equation3661. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff406_inst, reff406_op in H. discriminate H. Qed.

Lemma reff406_not3662 : ~ @Equation3662 Fin4 reff406_inst.
Proof. unfold Equation3662. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff406_inst, reff406_op in H. discriminate H. Qed.

Lemma reff406_not3664 : ~ @Equation3664 Fin4 reff406_inst.
Proof. unfold Equation3664. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff406_inst, reff406_op in H. discriminate H. Qed.

Lemma reff406_not3665 : ~ @Equation3665 Fin4 reff406_inst.
Proof. unfold Equation3665. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff406_inst, reff406_op in H. discriminate H. Qed.

Lemma reff406_not3667 : ~ @Equation3667 Fin4 reff406_inst.
Proof. unfold Equation3667. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff406_inst, reff406_op in H. discriminate H. Qed.

Lemma reff406_not3668 : ~ @Equation3668 Fin4 reff406_inst.
Proof. unfold Equation3668. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff406_inst, reff406_op in H. discriminate H. Qed.

Lemma reff406_not3674 : ~ @Equation3674 Fin4 reff406_inst.
Proof. unfold Equation3674. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff406_inst, reff406_op in H. discriminate H. Qed.

Lemma reff406_not3675 : ~ @Equation3675 Fin4 reff406_inst.
Proof. unfold Equation3675. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff406_inst, reff406_op in H. discriminate H. Qed.

Lemma reff406_not3677 : ~ @Equation3677 Fin4 reff406_inst.
Proof. unfold Equation3677. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff406_inst, reff406_op in H. discriminate H. Qed.

Lemma reff406_not3678 : ~ @Equation3678 Fin4 reff406_inst.
Proof. unfold Equation3678. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff406_inst, reff406_op in H. discriminate H. Qed.

Lemma reff406_not3685 : ~ @Equation3685 Fin4 reff406_inst.
Proof. unfold Equation3685. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff406_inst, reff406_op in H. discriminate H. Qed.

Lemma reff406_not3687 : ~ @Equation3687 Fin4 reff406_inst.
Proof. unfold Equation3687. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff406_inst, reff406_op in H. discriminate H. Qed.

Lemma reff406_not3712 : ~ @Equation3712 Fin4 reff406_inst.
Proof. unfold Equation3712. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff406_inst, reff406_op in H. discriminate H. Qed.

Lemma reff406_not3714 : ~ @Equation3714 Fin4 reff406_inst.
Proof. unfold Equation3714. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff406_inst, reff406_op in H. discriminate H. Qed.

Lemma reff406_not3721 : ~ @Equation3721 Fin4 reff406_inst.
Proof. unfold Equation3721. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff406_inst, reff406_op in H. discriminate H. Qed.

Lemma reff406_not3722 : ~ @Equation3722 Fin4 reff406_inst.
Proof. unfold Equation3722. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff406_inst, reff406_op in H. discriminate H. Qed.

Lemma reff406_not3724 : ~ @Equation3724 Fin4 reff406_inst.
Proof. unfold Equation3724. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff406_inst, reff406_op in H. discriminate H. Qed.

Lemma reff406_not3748 : ~ @Equation3748 Fin4 reff406_inst.
Proof. unfold Equation3748. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff406_inst, reff406_op in H. discriminate H. Qed.

Lemma reff406_not3749 : ~ @Equation3749 Fin4 reff406_inst.
Proof. unfold Equation3749. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff406_inst, reff406_op in H. discriminate H. Qed.

Lemma reff406_not3751 : ~ @Equation3751 Fin4 reff406_inst.
Proof. unfold Equation3751. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff406_inst, reff406_op in H. discriminate H. Qed.

Lemma reff406_not3759 : ~ @Equation3759 Fin4 reff406_inst.
Proof. unfold Equation3759. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff406_inst, reff406_op in H. discriminate H. Qed.

Lemma reff406_not3761 : ~ @Equation3761 Fin4 reff406_inst.
Proof. unfold Equation3761. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff406_inst, reff406_op in H. discriminate H. Qed.

Lemma reff406_not3864 : ~ @Equation3864 Fin4 reff406_inst.
Proof. unfold Equation3864. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff406_inst, reff406_op in H. discriminate H. Qed.

Lemma reff406_not3865 : ~ @Equation3865 Fin4 reff406_inst.
Proof. unfold Equation3865. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff406_inst, reff406_op in H. discriminate H. Qed.

Lemma reff406_not3867 : ~ @Equation3867 Fin4 reff406_inst.
Proof. unfold Equation3867. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff406_inst, reff406_op in H. discriminate H. Qed.

Lemma reff406_not3868 : ~ @Equation3868 Fin4 reff406_inst.
Proof. unfold Equation3868. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff406_inst, reff406_op in H. discriminate H. Qed.

Lemma reff406_not3871 : ~ @Equation3871 Fin4 reff406_inst.
Proof. unfold Equation3871. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff406_inst, reff406_op in H. discriminate H. Qed.

Lemma reff406_not3877 : ~ @Equation3877 Fin4 reff406_inst.
Proof. unfold Equation3877. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff406_inst, reff406_op in H. discriminate H. Qed.

Lemma reff406_not3878 : ~ @Equation3878 Fin4 reff406_inst.
Proof. unfold Equation3878. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff406_inst, reff406_op in H. discriminate H. Qed.

Lemma reff406_not3881 : ~ @Equation3881 Fin4 reff406_inst.
Proof. unfold Equation3881. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff406_inst, reff406_op in H. discriminate H. Qed.

Lemma reff406_not3888 : ~ @Equation3888 Fin4 reff406_inst.
Proof. unfold Equation3888. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff406_inst, reff406_op in H. discriminate H. Qed.

Lemma reff406_not3890 : ~ @Equation3890 Fin4 reff406_inst.
Proof. unfold Equation3890. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff406_inst, reff406_op in H. discriminate H. Qed.

Lemma reff406_not3917 : ~ @Equation3917 Fin4 reff406_inst.
Proof. unfold Equation3917. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff406_inst, reff406_op in H. discriminate H. Qed.

Lemma reff406_not3918 : ~ @Equation3918 Fin4 reff406_inst.
Proof. unfold Equation3918. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff406_inst, reff406_op in H. discriminate H. Qed.

Lemma reff406_not3925 : ~ @Equation3925 Fin4 reff406_inst.
Proof. unfold Equation3925. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff406_inst, reff406_op in H. discriminate H. Qed.

Lemma reff406_not3927 : ~ @Equation3927 Fin4 reff406_inst.
Proof. unfold Equation3927. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff406_inst, reff406_op in H. discriminate H. Qed.

Lemma reff406_not3951 : ~ @Equation3951 Fin4 reff406_inst.
Proof. unfold Equation3951. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff406_inst, reff406_op in H. discriminate H. Qed.

Lemma reff406_not3952 : ~ @Equation3952 Fin4 reff406_inst.
Proof. unfold Equation3952. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff406_inst, reff406_op in H. discriminate H. Qed.

Lemma reff406_not3954 : ~ @Equation3954 Fin4 reff406_inst.
Proof. unfold Equation3954. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff406_inst, reff406_op in H. discriminate H. Qed.

Lemma reff406_not3961 : ~ @Equation3961 Fin4 reff406_inst.
Proof. unfold Equation3961. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff406_inst, reff406_op in H. discriminate H. Qed.

Lemma reff406_not3964 : ~ @Equation3964 Fin4 reff406_inst.
Proof. unfold Equation3964. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff406_inst, reff406_op in H. discriminate H. Qed.

Lemma reff406_not4066 : ~ @Equation4066 Fin4 reff406_inst.
Proof. unfold Equation4066. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff406_inst, reff406_op in H. discriminate H. Qed.

Lemma reff406_not4067 : ~ @Equation4067 Fin4 reff406_inst.
Proof. unfold Equation4067. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff406_inst, reff406_op in H. discriminate H. Qed.

Lemma reff406_not4068 : ~ @Equation4068 Fin4 reff406_inst.
Proof. unfold Equation4068. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff406_inst, reff406_op in H. discriminate H. Qed.

Lemma reff406_not4070 : ~ @Equation4070 Fin4 reff406_inst.
Proof. unfold Equation4070. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff406_inst, reff406_op in H. discriminate H. Qed.

Lemma reff406_not4071 : ~ @Equation4071 Fin4 reff406_inst.
Proof. unfold Equation4071. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff406_inst, reff406_op in H. discriminate H. Qed.

Lemma reff406_not4074 : ~ @Equation4074 Fin4 reff406_inst.
Proof. unfold Equation4074. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff406_inst, reff406_op in H. discriminate H. Qed.

Lemma reff406_not4080 : ~ @Equation4080 Fin4 reff406_inst.
Proof. unfold Equation4080. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff406_inst, reff406_op in H. discriminate H. Qed.

Lemma reff406_not4081 : ~ @Equation4081 Fin4 reff406_inst.
Proof. unfold Equation4081. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff406_inst, reff406_op in H. discriminate H. Qed.

Lemma reff406_not4084 : ~ @Equation4084 Fin4 reff406_inst.
Proof. unfold Equation4084. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff406_inst, reff406_op in H. discriminate H. Qed.

Lemma reff406_not4091 : ~ @Equation4091 Fin4 reff406_inst.
Proof. unfold Equation4091. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff406_inst, reff406_op in H. discriminate H. Qed.

Lemma reff406_not4093 : ~ @Equation4093 Fin4 reff406_inst.
Proof. unfold Equation4093. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff406_inst, reff406_op in H. discriminate H. Qed.

Lemma reff406_not4120 : ~ @Equation4120 Fin4 reff406_inst.
Proof. unfold Equation4120. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff406_inst, reff406_op in H. discriminate H. Qed.

Lemma reff406_not4121 : ~ @Equation4121 Fin4 reff406_inst.
Proof. unfold Equation4121. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff406_inst, reff406_op in H. discriminate H. Qed.

Lemma reff406_not4127 : ~ @Equation4127 Fin4 reff406_inst.
Proof. unfold Equation4127. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff406_inst, reff406_op in H. discriminate H. Qed.

Lemma reff406_not4128 : ~ @Equation4128 Fin4 reff406_inst.
Proof. unfold Equation4128. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff406_inst, reff406_op in H. discriminate H. Qed.

Lemma reff406_not4130 : ~ @Equation4130 Fin4 reff406_inst.
Proof. unfold Equation4130. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff406_inst, reff406_op in H. discriminate H. Qed.

Lemma reff406_not4155 : ~ @Equation4155 Fin4 reff406_inst.
Proof. unfold Equation4155. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff406_inst, reff406_op in H. discriminate H. Qed.

Lemma reff406_not4157 : ~ @Equation4157 Fin4 reff406_inst.
Proof. unfold Equation4157. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff406_inst, reff406_op in H. discriminate H. Qed.

Lemma reff406_not4164 : ~ @Equation4164 Fin4 reff406_inst.
Proof. unfold Equation4164. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff406_inst, reff406_op in H. discriminate H. Qed.

Lemma reff406_not4167 : ~ @Equation4167 Fin4 reff406_inst.
Proof. unfold Equation4167. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff406_inst, reff406_op in H. discriminate H. Qed.

Lemma reff406_not4268 : ~ @Equation4268 Fin4 reff406_inst.
Proof. unfold Equation4268. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff406_inst, reff406_op in H. discriminate H. Qed.

Lemma reff406_not4269 : ~ @Equation4269 Fin4 reff406_inst.
Proof. unfold Equation4269. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff406_inst, reff406_op in H. discriminate H. Qed.

Lemma reff406_not4270 : ~ @Equation4270 Fin4 reff406_inst.
Proof. unfold Equation4270. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff406_inst, reff406_op in H. discriminate H. Qed.

Lemma reff406_not4272 : ~ @Equation4272 Fin4 reff406_inst.
Proof. unfold Equation4272. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff406_inst, reff406_op in H. discriminate H. Qed.

Lemma reff406_not4273 : ~ @Equation4273 Fin4 reff406_inst.
Proof. unfold Equation4273. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff406_inst, reff406_op in H. discriminate H. Qed.

Lemma reff406_not4275 : ~ @Equation4275 Fin4 reff406_inst.
Proof. unfold Equation4275. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff406_inst, reff406_op in H. discriminate H. Qed.

Lemma reff406_not4276 : ~ @Equation4276 Fin4 reff406_inst.
Proof. unfold Equation4276. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff406_inst, reff406_op in H. discriminate H. Qed.

Lemma reff406_not4283 : ~ @Equation4283 Fin4 reff406_inst.
Proof. unfold Equation4283. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff406_inst, reff406_op in H. discriminate H. Qed.

Lemma reff406_not4284 : ~ @Equation4284 Fin4 reff406_inst.
Proof. unfold Equation4284. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff406_inst, reff406_op in H. discriminate H. Qed.

Lemma reff406_not4290 : ~ @Equation4290 Fin4 reff406_inst.
Proof. unfold Equation4290. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff406_inst, reff406_op in H. discriminate H. Qed.

Lemma reff406_not4291 : ~ @Equation4291 Fin4 reff406_inst.
Proof. unfold Equation4291. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff406_inst, reff406_op in H. discriminate H. Qed.

Lemma reff406_not4293 : ~ @Equation4293 Fin4 reff406_inst.
Proof. unfold Equation4293. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff406_inst, reff406_op in H. discriminate H. Qed.

Lemma reff406_not4314 : ~ @Equation4314 Fin4 reff406_inst.
Proof. unfold Equation4314. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff406_inst, reff406_op in H. discriminate H. Qed.

Lemma reff406_not4320 : ~ @Equation4320 Fin4 reff406_inst.
Proof. unfold Equation4320. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff406_inst, reff406_op in H. discriminate H. Qed.

Lemma reff406_not4321 : ~ @Equation4321 Fin4 reff406_inst.
Proof. unfold Equation4321. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff406_inst, reff406_op in H. discriminate H. Qed.

Lemma reff406_not4343 : ~ @Equation4343 Fin4 reff406_inst.
Proof. unfold Equation4343. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff406_inst, reff406_op in H. discriminate H. Qed.

Lemma reff406_not4396 : ~ @Equation4396 Fin4 reff406_inst.
Proof. unfold Equation4396. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff406_inst, reff406_op in H. discriminate H. Qed.

Lemma reff406_not4398 : ~ @Equation4398 Fin4 reff406_inst.
Proof. unfold Equation4398. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff406_inst, reff406_op in H. discriminate H. Qed.

Lemma reff406_not4399 : ~ @Equation4399 Fin4 reff406_inst.
Proof. unfold Equation4399. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff406_inst, reff406_op in H. discriminate H. Qed.

Lemma reff406_not4405 : ~ @Equation4405 Fin4 reff406_inst.
Proof. unfold Equation4405. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff406_inst, reff406_op in H. discriminate H. Qed.

Lemma reff406_not4406 : ~ @Equation4406 Fin4 reff406_inst.
Proof. unfold Equation4406. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff406_inst, reff406_op in H. discriminate H. Qed.

Lemma reff406_not4408 : ~ @Equation4408 Fin4 reff406_inst.
Proof. unfold Equation4408. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff406_inst, reff406_op in H. discriminate H. Qed.

Lemma reff406_not4433 : ~ @Equation4433 Fin4 reff406_inst.
Proof. unfold Equation4433. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff406_inst, reff406_op in H. discriminate H. Qed.

Lemma reff406_not4435 : ~ @Equation4435 Fin4 reff406_inst.
Proof. unfold Equation4435. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff406_inst, reff406_op in H. discriminate H. Qed.

Lemma reff406_not4436 : ~ @Equation4436 Fin4 reff406_inst.
Proof. unfold Equation4436. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff406_inst, reff406_op in H. discriminate H. Qed.

Lemma reff406_not4442 : ~ @Equation4442 Fin4 reff406_inst.
Proof. unfold Equation4442. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff406_inst, reff406_op in H. discriminate H. Qed.

Lemma reff406_not4443 : ~ @Equation4443 Fin4 reff406_inst.
Proof. unfold Equation4443. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff406_inst, reff406_op in H. discriminate H. Qed.

Lemma reff406_not4445 : ~ @Equation4445 Fin4 reff406_inst.
Proof. unfold Equation4445. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff406_inst, reff406_op in H. discriminate H. Qed.

Lemma reff406_not4470 : ~ @Equation4470 Fin4 reff406_inst.
Proof. unfold Equation4470. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff406_inst, reff406_op in H. discriminate H. Qed.

Lemma reff406_not4472 : ~ @Equation4472 Fin4 reff406_inst.
Proof. unfold Equation4472. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff406_inst, reff406_op in H. discriminate H. Qed.

Lemma reff406_not4479 : ~ @Equation4479 Fin4 reff406_inst.
Proof. unfold Equation4479. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff406_inst, reff406_op in H. discriminate H. Qed.

Lemma reff406_not4482 : ~ @Equation4482 Fin4 reff406_inst.
Proof. unfold Equation4482. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff406_inst, reff406_op in H. discriminate H. Qed.

Lemma reff406_not4583 : ~ @Equation4583 Fin4 reff406_inst.
Proof. unfold Equation4583. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff406_inst, reff406_op in H. discriminate H. Qed.

Lemma reff406_not4584 : ~ @Equation4584 Fin4 reff406_inst.
Proof. unfold Equation4584. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff406_inst, reff406_op in H. discriminate H. Qed.

Lemma reff406_not4585 : ~ @Equation4585 Fin4 reff406_inst.
Proof. unfold Equation4585. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff406_inst, reff406_op in H. discriminate H. Qed.

Lemma reff406_not4587 : ~ @Equation4587 Fin4 reff406_inst.
Proof. unfold Equation4587. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff406_inst, reff406_op in H. discriminate H. Qed.

Lemma reff406_not4588 : ~ @Equation4588 Fin4 reff406_inst.
Proof. unfold Equation4588. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff406_inst, reff406_op in H. discriminate H. Qed.

Lemma reff406_not4591 : ~ @Equation4591 Fin4 reff406_inst.
Proof. unfold Equation4591. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff406_inst, reff406_op in H. discriminate H. Qed.

Lemma reff406_not4598 : ~ @Equation4598 Fin4 reff406_inst.
Proof. unfold Equation4598. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff406_inst, reff406_op in H. discriminate H. Qed.

Lemma reff406_not4599 : ~ @Equation4599 Fin4 reff406_inst.
Proof. unfold Equation4599. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff406_inst, reff406_op in H. discriminate H. Qed.

Lemma reff406_not4605 : ~ @Equation4605 Fin4 reff406_inst.
Proof. unfold Equation4605. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff406_inst, reff406_op in H. discriminate H. Qed.

Lemma reff406_not4606 : ~ @Equation4606 Fin4 reff406_inst.
Proof. unfold Equation4606. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff406_inst, reff406_op in H. discriminate H. Qed.

Lemma reff406_not4608 : ~ @Equation4608 Fin4 reff406_inst.
Proof. unfold Equation4608. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff406_inst, reff406_op in H. discriminate H. Qed.

Lemma reff406_not4629 : ~ @Equation4629 Fin4 reff406_inst.
Proof. unfold Equation4629. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff406_inst, reff406_op in H. discriminate H. Qed.

Lemma reff406_not4636 : ~ @Equation4636 Fin4 reff406_inst.
Proof. unfold Equation4636. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff406_inst, reff406_op in H. discriminate H. Qed.

Lemma reff406_not4658 : ~ @Equation4658 Fin4 reff406_inst.
Proof. unfold Equation4658. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff406_inst, reff406_op in H. discriminate H. Qed.

(** ---- reff408 (Fin5) ---- *)

Definition reff408_op (x y : Fin5) : Fin5 :=
  match x, y with
  | F5_0, F5_0 => F5_0 | F5_0, F5_1 => F5_3 | F5_0, F5_2 => F5_0 | F5_0, F5_3 => F5_1 | F5_0, F5_4 => F5_1
  | F5_1, F5_0 => F5_2 | F5_1, F5_1 => F5_0 | F5_1, F5_2 => F5_2 | F5_1, F5_3 => F5_3 | F5_1, F5_4 => F5_3
  | F5_2, F5_0 => F5_4 | F5_2, F5_1 => F5_2 | F5_2, F5_2 => F5_4 | F5_2, F5_3 => F5_0 | F5_2, F5_4 => F5_0
  | F5_3, F5_0 => F5_1 | F5_3, F5_1 => F5_4 | F5_3, F5_2 => F5_1 | F5_3, F5_3 => F5_2 | F5_3, F5_4 => F5_2
  | F5_4, F5_0 => F5_3 | F5_4, F5_1 => F5_1 | F5_4, F5_2 => F5_3 | F5_4, F5_3 => F5_4 | F5_4, F5_4 => F5_4
  end.

#[local] Instance reff408_inst : Magma Fin5 := {| magma_op := reff408_op |}.

Lemma reff408_sat3091 : @Equation3091 Fin5 reff408_inst.
Proof. unfold Equation3091, magma_op, reff408_inst, reff408_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff408_not1426 : ~ @Equation1426 Fin5 reff408_inst.
Proof. unfold Equation1426. intro H. specialize (H F5_1). unfold magma_op, reff408_inst, reff408_op in H. discriminate H. Qed.

Lemma reff408_not1629 : ~ @Equation1629 Fin5 reff408_inst.
Proof. unfold Equation1629. intro H. specialize (H F5_2). unfold magma_op, reff408_inst, reff408_op in H. discriminate H. Qed.

Lemma reff408_not1832 : ~ @Equation1832 Fin5 reff408_inst.
Proof. unfold Equation1832. intro H. specialize (H F5_1). unfold magma_op, reff408_inst, reff408_op in H. discriminate H. Qed.

Lemma reff408_not2238 : ~ @Equation2238 Fin5 reff408_inst.
Proof. unfold Equation2238. intro H. specialize (H F5_1). unfold magma_op, reff408_inst, reff408_op in H. discriminate H. Qed.

Lemma reff408_not2441 : ~ @Equation2441 Fin5 reff408_inst.
Proof. unfold Equation2441. intro H. specialize (H F5_1). unfold magma_op, reff408_inst, reff408_op in H. discriminate H. Qed.

Lemma reff408_not3053 : ~ @Equation3053 Fin5 reff408_inst.
Proof. unfold Equation3053. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff408_inst, reff408_op in H. discriminate H. Qed.

Lemma reff408_not3058 : ~ @Equation3058 Fin5 reff408_inst.
Proof. unfold Equation3058. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff408_inst, reff408_op in H. discriminate H. Qed.

Lemma reff408_not3066 : ~ @Equation3066 Fin5 reff408_inst.
Proof. unfold Equation3066. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff408_inst, reff408_op in H. discriminate H. Qed.

Lemma reff408_not3075 : ~ @Equation3075 Fin5 reff408_inst.
Proof. unfold Equation3075. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff408_inst, reff408_op in H. discriminate H. Qed.

Lemma reff408_not3253 : ~ @Equation3253 Fin5 reff408_inst.
Proof. unfold Equation3253. intro H. specialize (H F5_1). unfold magma_op, reff408_inst, reff408_op in H. discriminate H. Qed.

Lemma reff408_not3456 : ~ @Equation3456 Fin5 reff408_inst.
Proof. unfold Equation3456. intro H. specialize (H F5_1). unfold magma_op, reff408_inst, reff408_op in H. discriminate H. Qed.

Lemma reff408_not4065 : ~ @Equation4065 Fin5 reff408_inst.
Proof. unfold Equation4065. intro H. specialize (H F5_1). unfold magma_op, reff408_inst, reff408_op in H. discriminate H. Qed.

Lemma reff408_not4585 : ~ @Equation4585 Fin5 reff408_inst.
Proof. unfold Equation4585. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff408_inst, reff408_op in H. discriminate H. Qed.

Lemma reff408_not4598 : ~ @Equation4598 Fin5 reff408_inst.
Proof. unfold Equation4598. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff408_inst, reff408_op in H. discriminate H. Qed.

(** ---- reff410 (Fin3) ---- *)

Definition reff410_op (x y : Fin3) : Fin3 :=
  match x, y with
  | F3_0, F3_0 => F3_0 | F3_0, F3_1 => F3_2 | F3_0, F3_2 => F3_2
  | F3_1, F3_0 => F3_0 | F3_1, F3_1 => F3_1 | F3_1, F3_2 => F3_0
  | F3_2, F3_0 => F3_1 | F3_2, F3_1 => F3_1 | F3_2, F3_2 => F3_2
  end.

#[local] Instance reff410_inst : Magma Fin3 := {| magma_op := reff410_op |}.

Lemma reff410_sat28 : @Equation28 Fin3 reff410_inst.
Proof. unfold Equation28, magma_op, reff410_inst, reff410_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff410_sat228 : @Equation228 Fin3 reff410_inst.
Proof. unfold Equation228, magma_op, reff410_inst, reff410_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff410_sat323 : @Equation323 Fin3 reff410_inst.
Proof. unfold Equation323, magma_op, reff410_inst, reff410_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff410_sat619 : @Equation619 Fin3 reff410_inst.
Proof. unfold Equation619, magma_op, reff410_inst, reff410_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff410_sat1045 : @Equation1045 Fin3 reff410_inst.
Proof. unfold Equation1045, magma_op, reff410_inst, reff410_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff410_sat1481 : @Equation1481 Fin3 reff410_inst.
Proof. unfold Equation1481, magma_op, reff410_inst, reff410_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff410_sat1489 : @Equation1489 Fin3 reff410_inst.
Proof. unfold Equation1489, magma_op, reff410_inst, reff410_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff410_sat1921 : @Equation1921 Fin3 reff410_inst.
Proof. unfold Equation1921, magma_op, reff410_inst, reff410_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff410_sat2051 : @Equation2051 Fin3 reff410_inst.
Proof. unfold Equation2051, magma_op, reff410_inst, reff410_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff410_sat2327 : @Equation2327 Fin3 reff410_inst.
Proof. unfold Equation2327, magma_op, reff410_inst, reff410_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff410_sat2337 : @Equation2337 Fin3 reff410_inst.
Proof. unfold Equation2337, magma_op, reff410_inst, reff410_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff410_sat2533 : @Equation2533 Fin3 reff410_inst.
Proof. unfold Equation2533, magma_op, reff410_inst, reff410_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff410_sat2584 : @Equation2584 Fin3 reff410_inst.
Proof. unfold Equation2584, magma_op, reff410_inst, reff410_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff410_sat2669 : @Equation2669 Fin3 reff410_inst.
Proof. unfold Equation2669, magma_op, reff410_inst, reff410_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff410_sat2787 : @Equation2787 Fin3 reff410_inst.
Proof. unfold Equation2787, magma_op, reff410_inst, reff410_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff410_sat3068 : @Equation3068 Fin3 reff410_inst.
Proof. unfold Equation3068, magma_op, reff410_inst, reff410_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff410_sat3309 : @Equation3309 Fin3 reff410_inst.
Proof. unfold Equation3309, magma_op, reff410_inst, reff410_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff410_sat3509 : @Equation3509 Fin3 reff410_inst.
Proof. unfold Equation3509, magma_op, reff410_inst, reff410_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff410_sat3511 : @Equation3511 Fin3 reff410_inst.
Proof. unfold Equation3511, magma_op, reff410_inst, reff410_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff410_sat3712 : @Equation3712 Fin3 reff410_inst.
Proof. unfold Equation3712, magma_op, reff410_inst, reff410_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff410_sat3887 : @Equation3887 Fin3 reff410_inst.
Proof. unfold Equation3887, magma_op, reff410_inst, reff410_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff410_sat3925 : @Equation3925 Fin3 reff410_inst.
Proof. unfold Equation3925, magma_op, reff410_inst, reff410_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff410_sat3955 : @Equation3955 Fin3 reff410_inst.
Proof. unfold Equation3955, magma_op, reff410_inst, reff410_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff410_sat4284 : @Equation4284 Fin3 reff410_inst.
Proof. unfold Equation4284, magma_op, reff410_inst, reff410_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff410_sat4321 : @Equation4321 Fin3 reff410_inst.
Proof. unfold Equation4321, magma_op, reff410_inst, reff410_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff410_sat4396 : @Equation4396 Fin3 reff410_inst.
Proof. unfold Equation4396, magma_op, reff410_inst, reff410_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff410_not50 : ~ @Equation50 Fin3 reff410_inst.
Proof. unfold Equation50. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff410_inst, reff410_op in H. discriminate H. Qed.

Lemma reff410_not53 : ~ @Equation53 Fin3 reff410_inst.
Proof. unfold Equation53. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff410_inst, reff410_op in H. discriminate H. Qed.

Lemma reff410_not55 : ~ @Equation55 Fin3 reff410_inst.
Proof. unfold Equation55. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff410_inst, reff410_op in H. discriminate H. Qed.

Lemma reff410_not56 : ~ @Equation56 Fin3 reff410_inst.
Proof. unfold Equation56. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff410_inst, reff410_op in H. discriminate H. Qed.

Lemma reff410_not63 : ~ @Equation63 Fin3 reff410_inst.
Proof. unfold Equation63. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff410_inst, reff410_op in H. discriminate H. Qed.

Lemma reff410_not65 : ~ @Equation65 Fin3 reff410_inst.
Proof. unfold Equation65. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff410_inst, reff410_op in H. discriminate H. Qed.

Lemma reff410_not66 : ~ @Equation66 Fin3 reff410_inst.
Proof. unfold Equation66. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff410_inst, reff410_op in H. discriminate H. Qed.

Lemma reff410_not72 : ~ @Equation72 Fin3 reff410_inst.
Proof. unfold Equation72. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff410_inst, reff410_op in H. discriminate H. Qed.

Lemma reff410_not73 : ~ @Equation73 Fin3 reff410_inst.
Proof. unfold Equation73. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff410_inst, reff410_op in H. discriminate H. Qed.

Lemma reff410_not75 : ~ @Equation75 Fin3 reff410_inst.
Proof. unfold Equation75. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff410_inst, reff410_op in H. discriminate H. Qed.

Lemma reff410_not102 : ~ @Equation102 Fin3 reff410_inst.
Proof. unfold Equation102. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff410_inst, reff410_op in H. discriminate H. Qed.

Lemma reff410_not105 : ~ @Equation105 Fin3 reff410_inst.
Proof. unfold Equation105. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff410_inst, reff410_op in H. discriminate H. Qed.

Lemma reff410_not107 : ~ @Equation107 Fin3 reff410_inst.
Proof. unfold Equation107. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff410_inst, reff410_op in H. discriminate H. Qed.

Lemma reff410_not108 : ~ @Equation108 Fin3 reff410_inst.
Proof. unfold Equation108. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff410_inst, reff410_op in H. discriminate H. Qed.

Lemma reff410_not115 : ~ @Equation115 Fin3 reff410_inst.
Proof. unfold Equation115. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff410_inst, reff410_op in H. discriminate H. Qed.

Lemma reff410_not117 : ~ @Equation117 Fin3 reff410_inst.
Proof. unfold Equation117. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff410_inst, reff410_op in H. discriminate H. Qed.

Lemma reff410_not118 : ~ @Equation118 Fin3 reff410_inst.
Proof. unfold Equation118. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff410_inst, reff410_op in H. discriminate H. Qed.

Lemma reff410_not124 : ~ @Equation124 Fin3 reff410_inst.
Proof. unfold Equation124. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff410_inst, reff410_op in H. discriminate H. Qed.

Lemma reff410_not125 : ~ @Equation125 Fin3 reff410_inst.
Proof. unfold Equation125. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff410_inst, reff410_op in H. discriminate H. Qed.

Lemma reff410_not127 : ~ @Equation127 Fin3 reff410_inst.
Proof. unfold Equation127. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff410_inst, reff410_op in H. discriminate H. Qed.

Lemma reff410_not154 : ~ @Equation154 Fin3 reff410_inst.
Proof. unfold Equation154. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff410_inst, reff410_op in H. discriminate H. Qed.

Lemma reff410_not157 : ~ @Equation157 Fin3 reff410_inst.
Proof. unfold Equation157. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff410_inst, reff410_op in H. discriminate H. Qed.

Lemma reff410_not159 : ~ @Equation159 Fin3 reff410_inst.
Proof. unfold Equation159. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff410_inst, reff410_op in H. discriminate H. Qed.

Lemma reff410_not160 : ~ @Equation160 Fin3 reff410_inst.
Proof. unfold Equation160. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff410_inst, reff410_op in H. discriminate H. Qed.

Lemma reff410_not167 : ~ @Equation167 Fin3 reff410_inst.
Proof. unfold Equation167. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff410_inst, reff410_op in H. discriminate H. Qed.

Lemma reff410_not169 : ~ @Equation169 Fin3 reff410_inst.
Proof. unfold Equation169. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff410_inst, reff410_op in H. discriminate H. Qed.

Lemma reff410_not170 : ~ @Equation170 Fin3 reff410_inst.
Proof. unfold Equation170. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff410_inst, reff410_op in H. discriminate H. Qed.

Lemma reff410_not176 : ~ @Equation176 Fin3 reff410_inst.
Proof. unfold Equation176. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff410_inst, reff410_op in H. discriminate H. Qed.

Lemma reff410_not177 : ~ @Equation177 Fin3 reff410_inst.
Proof. unfold Equation177. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff410_inst, reff410_op in H. discriminate H. Qed.

Lemma reff410_not179 : ~ @Equation179 Fin3 reff410_inst.
Proof. unfold Equation179. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff410_inst, reff410_op in H. discriminate H. Qed.

Lemma reff410_not206 : ~ @Equation206 Fin3 reff410_inst.
Proof. unfold Equation206. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff410_inst, reff410_op in H. discriminate H. Qed.

Lemma reff410_not209 : ~ @Equation209 Fin3 reff410_inst.
Proof. unfold Equation209. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff410_inst, reff410_op in H. discriminate H. Qed.

Lemma reff410_not211 : ~ @Equation211 Fin3 reff410_inst.
Proof. unfold Equation211. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff410_inst, reff410_op in H. discriminate H. Qed.

Lemma reff410_not212 : ~ @Equation212 Fin3 reff410_inst.
Proof. unfold Equation212. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff410_inst, reff410_op in H. discriminate H. Qed.

Lemma reff410_not219 : ~ @Equation219 Fin3 reff410_inst.
Proof. unfold Equation219. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff410_inst, reff410_op in H. discriminate H. Qed.

Lemma reff410_not221 : ~ @Equation221 Fin3 reff410_inst.
Proof. unfold Equation221. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff410_inst, reff410_op in H. discriminate H. Qed.

Lemma reff410_not222 : ~ @Equation222 Fin3 reff410_inst.
Proof. unfold Equation222. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff410_inst, reff410_op in H. discriminate H. Qed.

Lemma reff410_not229 : ~ @Equation229 Fin3 reff410_inst.
Proof. unfold Equation229. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff410_inst, reff410_op in H. discriminate H. Qed.

Lemma reff410_not231 : ~ @Equation231 Fin3 reff410_inst.
Proof. unfold Equation231. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff410_inst, reff410_op in H. discriminate H. Qed.

Lemma reff410_not258 : ~ @Equation258 Fin3 reff410_inst.
Proof. unfold Equation258. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff410_inst, reff410_op in H. discriminate H. Qed.

Lemma reff410_not261 : ~ @Equation261 Fin3 reff410_inst.
Proof. unfold Equation261. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff410_inst, reff410_op in H. discriminate H. Qed.

Lemma reff410_not263 : ~ @Equation263 Fin3 reff410_inst.
Proof. unfold Equation263. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff410_inst, reff410_op in H. discriminate H. Qed.

Lemma reff410_not264 : ~ @Equation264 Fin3 reff410_inst.
Proof. unfold Equation264. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff410_inst, reff410_op in H. discriminate H. Qed.

Lemma reff410_not271 : ~ @Equation271 Fin3 reff410_inst.
Proof. unfold Equation271. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff410_inst, reff410_op in H. discriminate H. Qed.

Lemma reff410_not273 : ~ @Equation273 Fin3 reff410_inst.
Proof. unfold Equation273. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff410_inst, reff410_op in H. discriminate H. Qed.

Lemma reff410_not274 : ~ @Equation274 Fin3 reff410_inst.
Proof. unfold Equation274. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff410_inst, reff410_op in H. discriminate H. Qed.

Lemma reff410_not281 : ~ @Equation281 Fin3 reff410_inst.
Proof. unfold Equation281. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff410_inst, reff410_op in H. discriminate H. Qed.

Lemma reff410_not283 : ~ @Equation283 Fin3 reff410_inst.
Proof. unfold Equation283. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff410_inst, reff410_op in H. discriminate H. Qed.

Lemma reff410_not412 : ~ @Equation412 Fin3 reff410_inst.
Proof. unfold Equation412. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff410_inst, reff410_op in H. discriminate H. Qed.

Lemma reff410_not413 : ~ @Equation413 Fin3 reff410_inst.
Proof. unfold Equation413. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff410_inst, reff410_op in H. discriminate H. Qed.

Lemma reff410_not414 : ~ @Equation414 Fin3 reff410_inst.
Proof. unfold Equation414. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff410_inst, reff410_op in H. discriminate H. Qed.

Lemma reff410_not416 : ~ @Equation416 Fin3 reff410_inst.
Proof. unfold Equation416. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff410_inst, reff410_op in H. discriminate H. Qed.

Lemma reff410_not417 : ~ @Equation417 Fin3 reff410_inst.
Proof. unfold Equation417. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff410_inst, reff410_op in H. discriminate H. Qed.

Lemma reff410_not419 : ~ @Equation419 Fin3 reff410_inst.
Proof. unfold Equation419. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff410_inst, reff410_op in H. discriminate H. Qed.

Lemma reff410_not420 : ~ @Equation420 Fin3 reff410_inst.
Proof. unfold Equation420. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff410_inst, reff410_op in H. discriminate H. Qed.

Lemma reff410_not426 : ~ @Equation426 Fin3 reff410_inst.
Proof. unfold Equation426. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff410_inst, reff410_op in H. discriminate H. Qed.

Lemma reff410_not427 : ~ @Equation427 Fin3 reff410_inst.
Proof. unfold Equation427. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff410_inst, reff410_op in H. discriminate H. Qed.

Lemma reff410_not429 : ~ @Equation429 Fin3 reff410_inst.
Proof. unfold Equation429. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff410_inst, reff410_op in H. discriminate H. Qed.

Lemma reff410_not430 : ~ @Equation430 Fin3 reff410_inst.
Proof. unfold Equation430. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff410_inst, reff410_op in H. discriminate H. Qed.

Lemma reff410_not436 : ~ @Equation436 Fin3 reff410_inst.
Proof. unfold Equation436. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff410_inst, reff410_op in H. discriminate H. Qed.

Lemma reff410_not437 : ~ @Equation437 Fin3 reff410_inst.
Proof. unfold Equation437. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff410_inst, reff410_op in H. discriminate H. Qed.

Lemma reff410_not439 : ~ @Equation439 Fin3 reff410_inst.
Proof. unfold Equation439. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff410_inst, reff410_op in H. discriminate H. Qed.

Lemma reff410_not440 : ~ @Equation440 Fin3 reff410_inst.
Proof. unfold Equation440. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff410_inst, reff410_op in H. discriminate H. Qed.

Lemma reff410_not463 : ~ @Equation463 Fin3 reff410_inst.
Proof. unfold Equation463. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff410_inst, reff410_op in H. discriminate H. Qed.

Lemma reff410_not464 : ~ @Equation464 Fin3 reff410_inst.
Proof. unfold Equation464. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff410_inst, reff410_op in H. discriminate H. Qed.

Lemma reff410_not466 : ~ @Equation466 Fin3 reff410_inst.
Proof. unfold Equation466. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff410_inst, reff410_op in H. discriminate H. Qed.

Lemma reff410_not467 : ~ @Equation467 Fin3 reff410_inst.
Proof. unfold Equation467. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff410_inst, reff410_op in H. discriminate H. Qed.

Lemma reff410_not473 : ~ @Equation473 Fin3 reff410_inst.
Proof. unfold Equation473. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff410_inst, reff410_op in H. discriminate H. Qed.

Lemma reff410_not474 : ~ @Equation474 Fin3 reff410_inst.
Proof. unfold Equation474. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff410_inst, reff410_op in H. discriminate H. Qed.

Lemma reff410_not476 : ~ @Equation476 Fin3 reff410_inst.
Proof. unfold Equation476. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff410_inst, reff410_op in H. discriminate H. Qed.

Lemma reff410_not477 : ~ @Equation477 Fin3 reff410_inst.
Proof. unfold Equation477. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff410_inst, reff410_op in H. discriminate H. Qed.

Lemma reff410_not500 : ~ @Equation500 Fin3 reff410_inst.
Proof. unfold Equation500. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff410_inst, reff410_op in H. discriminate H. Qed.

Lemma reff410_not501 : ~ @Equation501 Fin3 reff410_inst.
Proof. unfold Equation501. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff410_inst, reff410_op in H. discriminate H. Qed.

Lemma reff410_not503 : ~ @Equation503 Fin3 reff410_inst.
Proof. unfold Equation503. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff410_inst, reff410_op in H. discriminate H. Qed.

Lemma reff410_not504 : ~ @Equation504 Fin3 reff410_inst.
Proof. unfold Equation504. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff410_inst, reff410_op in H. discriminate H. Qed.

Lemma reff410_not510 : ~ @Equation510 Fin3 reff410_inst.
Proof. unfold Equation510. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff410_inst, reff410_op in H. discriminate H. Qed.

Lemma reff410_not511 : ~ @Equation511 Fin3 reff410_inst.
Proof. unfold Equation511. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff410_inst, reff410_op in H. discriminate H. Qed.

Lemma reff410_not513 : ~ @Equation513 Fin3 reff410_inst.
Proof. unfold Equation513. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff410_inst, reff410_op in H. discriminate H. Qed.

Lemma reff410_not615 : ~ @Equation615 Fin3 reff410_inst.
Proof. unfold Equation615. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff410_inst, reff410_op in H. discriminate H. Qed.

Lemma reff410_not616 : ~ @Equation616 Fin3 reff410_inst.
Proof. unfold Equation616. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff410_inst, reff410_op in H. discriminate H. Qed.

Lemma reff410_not617 : ~ @Equation617 Fin3 reff410_inst.
Proof. unfold Equation617. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff410_inst, reff410_op in H. discriminate H. Qed.

Lemma reff410_not620 : ~ @Equation620 Fin3 reff410_inst.
Proof. unfold Equation620. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff410_inst, reff410_op in H. discriminate H. Qed.

Lemma reff410_not622 : ~ @Equation622 Fin3 reff410_inst.
Proof. unfold Equation622. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff410_inst, reff410_op in H. discriminate H. Qed.

Lemma reff410_not623 : ~ @Equation623 Fin3 reff410_inst.
Proof. unfold Equation623. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff410_inst, reff410_op in H. discriminate H. Qed.

Lemma reff410_not629 : ~ @Equation629 Fin3 reff410_inst.
Proof. unfold Equation629. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff410_inst, reff410_op in H. discriminate H. Qed.

Lemma reff410_not630 : ~ @Equation630 Fin3 reff410_inst.
Proof. unfold Equation630. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff410_inst, reff410_op in H. discriminate H. Qed.

Lemma reff410_not632 : ~ @Equation632 Fin3 reff410_inst.
Proof. unfold Equation632. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff410_inst, reff410_op in H. discriminate H. Qed.

Lemma reff410_not633 : ~ @Equation633 Fin3 reff410_inst.
Proof. unfold Equation633. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff410_inst, reff410_op in H. discriminate H. Qed.

Lemma reff410_not639 : ~ @Equation639 Fin3 reff410_inst.
Proof. unfold Equation639. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff410_inst, reff410_op in H. discriminate H. Qed.

Lemma reff410_not640 : ~ @Equation640 Fin3 reff410_inst.
Proof. unfold Equation640. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff410_inst, reff410_op in H. discriminate H. Qed.

Lemma reff410_not642 : ~ @Equation642 Fin3 reff410_inst.
Proof. unfold Equation642. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff410_inst, reff410_op in H. discriminate H. Qed.

Lemma reff410_not643 : ~ @Equation643 Fin3 reff410_inst.
Proof. unfold Equation643. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff410_inst, reff410_op in H. discriminate H. Qed.

Lemma reff410_not666 : ~ @Equation666 Fin3 reff410_inst.
Proof. unfold Equation666. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff410_inst, reff410_op in H. discriminate H. Qed.

Lemma reff410_not667 : ~ @Equation667 Fin3 reff410_inst.
Proof. unfold Equation667. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff410_inst, reff410_op in H. discriminate H. Qed.

Lemma reff410_not669 : ~ @Equation669 Fin3 reff410_inst.
Proof. unfold Equation669. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff410_inst, reff410_op in H. discriminate H. Qed.

Lemma reff410_not670 : ~ @Equation670 Fin3 reff410_inst.
Proof. unfold Equation670. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff410_inst, reff410_op in H. discriminate H. Qed.

Lemma reff410_not676 : ~ @Equation676 Fin3 reff410_inst.
Proof. unfold Equation676. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff410_inst, reff410_op in H. discriminate H. Qed.

Lemma reff410_not677 : ~ @Equation677 Fin3 reff410_inst.
Proof. unfold Equation677. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff410_inst, reff410_op in H. discriminate H. Qed.

Lemma reff410_not679 : ~ @Equation679 Fin3 reff410_inst.
Proof. unfold Equation679. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff410_inst, reff410_op in H. discriminate H. Qed.

Lemma reff410_not680 : ~ @Equation680 Fin3 reff410_inst.
Proof. unfold Equation680. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff410_inst, reff410_op in H. discriminate H. Qed.

Lemma reff410_not703 : ~ @Equation703 Fin3 reff410_inst.
Proof. unfold Equation703. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff410_inst, reff410_op in H. discriminate H. Qed.

Lemma reff410_not704 : ~ @Equation704 Fin3 reff410_inst.
Proof. unfold Equation704. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff410_inst, reff410_op in H. discriminate H. Qed.

Lemma reff410_not706 : ~ @Equation706 Fin3 reff410_inst.
Proof. unfold Equation706. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff410_inst, reff410_op in H. discriminate H. Qed.

Lemma reff410_not707 : ~ @Equation707 Fin3 reff410_inst.
Proof. unfold Equation707. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff410_inst, reff410_op in H. discriminate H. Qed.

Lemma reff410_not713 : ~ @Equation713 Fin3 reff410_inst.
Proof. unfold Equation713. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff410_inst, reff410_op in H. discriminate H. Qed.

Lemma reff410_not714 : ~ @Equation714 Fin3 reff410_inst.
Proof. unfold Equation714. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff410_inst, reff410_op in H. discriminate H. Qed.

Lemma reff410_not716 : ~ @Equation716 Fin3 reff410_inst.
Proof. unfold Equation716. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff410_inst, reff410_op in H. discriminate H. Qed.

Lemma reff410_not818 : ~ @Equation818 Fin3 reff410_inst.
Proof. unfold Equation818. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff410_inst, reff410_op in H. discriminate H. Qed.

Lemma reff410_not819 : ~ @Equation819 Fin3 reff410_inst.
Proof. unfold Equation819. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff410_inst, reff410_op in H. discriminate H. Qed.

Lemma reff410_not820 : ~ @Equation820 Fin3 reff410_inst.
Proof. unfold Equation820. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff410_inst, reff410_op in H. discriminate H. Qed.

Lemma reff410_not822 : ~ @Equation822 Fin3 reff410_inst.
Proof. unfold Equation822. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff410_inst, reff410_op in H. discriminate H. Qed.

Lemma reff410_not823 : ~ @Equation823 Fin3 reff410_inst.
Proof. unfold Equation823. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff410_inst, reff410_op in H. discriminate H. Qed.

Lemma reff410_not825 : ~ @Equation825 Fin3 reff410_inst.
Proof. unfold Equation825. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff410_inst, reff410_op in H. discriminate H. Qed.

Lemma reff410_not826 : ~ @Equation826 Fin3 reff410_inst.
Proof. unfold Equation826. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff410_inst, reff410_op in H. discriminate H. Qed.

Lemma reff410_not833 : ~ @Equation833 Fin3 reff410_inst.
Proof. unfold Equation833. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff410_inst, reff410_op in H. discriminate H. Qed.

Lemma reff410_not835 : ~ @Equation835 Fin3 reff410_inst.
Proof. unfold Equation835. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff410_inst, reff410_op in H. discriminate H. Qed.

Lemma reff410_not836 : ~ @Equation836 Fin3 reff410_inst.
Proof. unfold Equation836. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff410_inst, reff410_op in H. discriminate H. Qed.

Lemma reff410_not842 : ~ @Equation842 Fin3 reff410_inst.
Proof. unfold Equation842. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff410_inst, reff410_op in H. discriminate H. Qed.

Lemma reff410_not843 : ~ @Equation843 Fin3 reff410_inst.
Proof. unfold Equation843. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff410_inst, reff410_op in H. discriminate H. Qed.

Lemma reff410_not845 : ~ @Equation845 Fin3 reff410_inst.
Proof. unfold Equation845. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff410_inst, reff410_op in H. discriminate H. Qed.

Lemma reff410_not846 : ~ @Equation846 Fin3 reff410_inst.
Proof. unfold Equation846. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff410_inst, reff410_op in H. discriminate H. Qed.

Lemma reff410_not869 : ~ @Equation869 Fin3 reff410_inst.
Proof. unfold Equation869. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff410_inst, reff410_op in H. discriminate H. Qed.

Lemma reff410_not870 : ~ @Equation870 Fin3 reff410_inst.
Proof. unfold Equation870. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff410_inst, reff410_op in H. discriminate H. Qed.

Lemma reff410_not872 : ~ @Equation872 Fin3 reff410_inst.
Proof. unfold Equation872. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff410_inst, reff410_op in H. discriminate H. Qed.

Lemma reff410_not873 : ~ @Equation873 Fin3 reff410_inst.
Proof. unfold Equation873. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff410_inst, reff410_op in H. discriminate H. Qed.

Lemma reff410_not879 : ~ @Equation879 Fin3 reff410_inst.
Proof. unfold Equation879. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff410_inst, reff410_op in H. discriminate H. Qed.

Lemma reff410_not880 : ~ @Equation880 Fin3 reff410_inst.
Proof. unfold Equation880. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff410_inst, reff410_op in H. discriminate H. Qed.

Lemma reff410_not882 : ~ @Equation882 Fin3 reff410_inst.
Proof. unfold Equation882. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff410_inst, reff410_op in H. discriminate H. Qed.

Lemma reff410_not883 : ~ @Equation883 Fin3 reff410_inst.
Proof. unfold Equation883. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff410_inst, reff410_op in H. discriminate H. Qed.

Lemma reff410_not906 : ~ @Equation906 Fin3 reff410_inst.
Proof. unfold Equation906. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff410_inst, reff410_op in H. discriminate H. Qed.

Lemma reff410_not907 : ~ @Equation907 Fin3 reff410_inst.
Proof. unfold Equation907. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff410_inst, reff410_op in H. discriminate H. Qed.

Lemma reff410_not909 : ~ @Equation909 Fin3 reff410_inst.
Proof. unfold Equation909. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff410_inst, reff410_op in H. discriminate H. Qed.

Lemma reff410_not910 : ~ @Equation910 Fin3 reff410_inst.
Proof. unfold Equation910. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff410_inst, reff410_op in H. discriminate H. Qed.

Lemma reff410_not916 : ~ @Equation916 Fin3 reff410_inst.
Proof. unfold Equation916. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff410_inst, reff410_op in H. discriminate H. Qed.

Lemma reff410_not917 : ~ @Equation917 Fin3 reff410_inst.
Proof. unfold Equation917. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff410_inst, reff410_op in H. discriminate H. Qed.

Lemma reff410_not919 : ~ @Equation919 Fin3 reff410_inst.
Proof. unfold Equation919. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff410_inst, reff410_op in H. discriminate H. Qed.

Lemma reff410_not1021 : ~ @Equation1021 Fin3 reff410_inst.
Proof. unfold Equation1021. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff410_inst, reff410_op in H. discriminate H. Qed.

Lemma reff410_not1022 : ~ @Equation1022 Fin3 reff410_inst.
Proof. unfold Equation1022. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff410_inst, reff410_op in H. discriminate H. Qed.

Lemma reff410_not1023 : ~ @Equation1023 Fin3 reff410_inst.
Proof. unfold Equation1023. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff410_inst, reff410_op in H. discriminate H. Qed.

Lemma reff410_not1025 : ~ @Equation1025 Fin3 reff410_inst.
Proof. unfold Equation1025. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff410_inst, reff410_op in H. discriminate H. Qed.

Lemma reff410_not1026 : ~ @Equation1026 Fin3 reff410_inst.
Proof. unfold Equation1026. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff410_inst, reff410_op in H. discriminate H. Qed.

Lemma reff410_not1028 : ~ @Equation1028 Fin3 reff410_inst.
Proof. unfold Equation1028. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff410_inst, reff410_op in H. discriminate H. Qed.

Lemma reff410_not1029 : ~ @Equation1029 Fin3 reff410_inst.
Proof. unfold Equation1029. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff410_inst, reff410_op in H. discriminate H. Qed.

Lemma reff410_not1036 : ~ @Equation1036 Fin3 reff410_inst.
Proof. unfold Equation1036. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff410_inst, reff410_op in H. discriminate H. Qed.

Lemma reff410_not1038 : ~ @Equation1038 Fin3 reff410_inst.
Proof. unfold Equation1038. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff410_inst, reff410_op in H. discriminate H. Qed.

Lemma reff410_not1039 : ~ @Equation1039 Fin3 reff410_inst.
Proof. unfold Equation1039. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff410_inst, reff410_op in H. discriminate H. Qed.

Lemma reff410_not1046 : ~ @Equation1046 Fin3 reff410_inst.
Proof. unfold Equation1046. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff410_inst, reff410_op in H. discriminate H. Qed.

Lemma reff410_not1048 : ~ @Equation1048 Fin3 reff410_inst.
Proof. unfold Equation1048. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff410_inst, reff410_op in H. discriminate H. Qed.

Lemma reff410_not1049 : ~ @Equation1049 Fin3 reff410_inst.
Proof. unfold Equation1049. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff410_inst, reff410_op in H. discriminate H. Qed.

Lemma reff410_not1072 : ~ @Equation1072 Fin3 reff410_inst.
Proof. unfold Equation1072. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff410_inst, reff410_op in H. discriminate H. Qed.

Lemma reff410_not1073 : ~ @Equation1073 Fin3 reff410_inst.
Proof. unfold Equation1073. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff410_inst, reff410_op in H. discriminate H. Qed.

Lemma reff410_not1075 : ~ @Equation1075 Fin3 reff410_inst.
Proof. unfold Equation1075. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff410_inst, reff410_op in H. discriminate H. Qed.

Lemma reff410_not1076 : ~ @Equation1076 Fin3 reff410_inst.
Proof. unfold Equation1076. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff410_inst, reff410_op in H. discriminate H. Qed.

Lemma reff410_not1082 : ~ @Equation1082 Fin3 reff410_inst.
Proof. unfold Equation1082. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff410_inst, reff410_op in H. discriminate H. Qed.

Lemma reff410_not1083 : ~ @Equation1083 Fin3 reff410_inst.
Proof. unfold Equation1083. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff410_inst, reff410_op in H. discriminate H. Qed.

Lemma reff410_not1085 : ~ @Equation1085 Fin3 reff410_inst.
Proof. unfold Equation1085. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff410_inst, reff410_op in H. discriminate H. Qed.

Lemma reff410_not1086 : ~ @Equation1086 Fin3 reff410_inst.
Proof. unfold Equation1086. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff410_inst, reff410_op in H. discriminate H. Qed.

Lemma reff410_not1109 : ~ @Equation1109 Fin3 reff410_inst.
Proof. unfold Equation1109. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff410_inst, reff410_op in H. discriminate H. Qed.

Lemma reff410_not1110 : ~ @Equation1110 Fin3 reff410_inst.
Proof. unfold Equation1110. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff410_inst, reff410_op in H. discriminate H. Qed.

Lemma reff410_not1112 : ~ @Equation1112 Fin3 reff410_inst.
Proof. unfold Equation1112. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff410_inst, reff410_op in H. discriminate H. Qed.

Lemma reff410_not1113 : ~ @Equation1113 Fin3 reff410_inst.
Proof. unfold Equation1113. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff410_inst, reff410_op in H. discriminate H. Qed.

Lemma reff410_not1119 : ~ @Equation1119 Fin3 reff410_inst.
Proof. unfold Equation1119. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff410_inst, reff410_op in H. discriminate H. Qed.

Lemma reff410_not1120 : ~ @Equation1120 Fin3 reff410_inst.
Proof. unfold Equation1120. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff410_inst, reff410_op in H. discriminate H. Qed.

Lemma reff410_not1122 : ~ @Equation1122 Fin3 reff410_inst.
Proof. unfold Equation1122. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff410_inst, reff410_op in H. discriminate H. Qed.

Lemma reff410_not1224 : ~ @Equation1224 Fin3 reff410_inst.
Proof. unfold Equation1224. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff410_inst, reff410_op in H. discriminate H. Qed.

Lemma reff410_not1225 : ~ @Equation1225 Fin3 reff410_inst.
Proof. unfold Equation1225. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff410_inst, reff410_op in H. discriminate H. Qed.

Lemma reff410_not1226 : ~ @Equation1226 Fin3 reff410_inst.
Proof. unfold Equation1226. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff410_inst, reff410_op in H. discriminate H. Qed.

Lemma reff410_not1229 : ~ @Equation1229 Fin3 reff410_inst.
Proof. unfold Equation1229. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff410_inst, reff410_op in H. discriminate H. Qed.

Lemma reff410_not1231 : ~ @Equation1231 Fin3 reff410_inst.
Proof. unfold Equation1231. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff410_inst, reff410_op in H. discriminate H. Qed.

Lemma reff410_not1232 : ~ @Equation1232 Fin3 reff410_inst.
Proof. unfold Equation1232. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff410_inst, reff410_op in H. discriminate H. Qed.

Lemma reff410_not1239 : ~ @Equation1239 Fin3 reff410_inst.
Proof. unfold Equation1239. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff410_inst, reff410_op in H. discriminate H. Qed.

Lemma reff410_not1241 : ~ @Equation1241 Fin3 reff410_inst.
Proof. unfold Equation1241. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff410_inst, reff410_op in H. discriminate H. Qed.

Lemma reff410_not1242 : ~ @Equation1242 Fin3 reff410_inst.
Proof. unfold Equation1242. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff410_inst, reff410_op in H. discriminate H. Qed.

Lemma reff410_not1249 : ~ @Equation1249 Fin3 reff410_inst.
Proof. unfold Equation1249. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff410_inst, reff410_op in H. discriminate H. Qed.

Lemma reff410_not1251 : ~ @Equation1251 Fin3 reff410_inst.
Proof. unfold Equation1251. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff410_inst, reff410_op in H. discriminate H. Qed.

Lemma reff410_not1252 : ~ @Equation1252 Fin3 reff410_inst.
Proof. unfold Equation1252. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff410_inst, reff410_op in H. discriminate H. Qed.

Lemma reff410_not1275 : ~ @Equation1275 Fin3 reff410_inst.
Proof. unfold Equation1275. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff410_inst, reff410_op in H. discriminate H. Qed.

Lemma reff410_not1276 : ~ @Equation1276 Fin3 reff410_inst.
Proof. unfold Equation1276. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff410_inst, reff410_op in H. discriminate H. Qed.

Lemma reff410_not1278 : ~ @Equation1278 Fin3 reff410_inst.
Proof. unfold Equation1278. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff410_inst, reff410_op in H. discriminate H. Qed.

Lemma reff410_not1279 : ~ @Equation1279 Fin3 reff410_inst.
Proof. unfold Equation1279. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff410_inst, reff410_op in H. discriminate H. Qed.

Lemma reff410_not1285 : ~ @Equation1285 Fin3 reff410_inst.
Proof. unfold Equation1285. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff410_inst, reff410_op in H. discriminate H. Qed.

Lemma reff410_not1286 : ~ @Equation1286 Fin3 reff410_inst.
Proof. unfold Equation1286. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff410_inst, reff410_op in H. discriminate H. Qed.

Lemma reff410_not1288 : ~ @Equation1288 Fin3 reff410_inst.
Proof. unfold Equation1288. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff410_inst, reff410_op in H. discriminate H. Qed.

Lemma reff410_not1289 : ~ @Equation1289 Fin3 reff410_inst.
Proof. unfold Equation1289. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff410_inst, reff410_op in H. discriminate H. Qed.

Lemma reff410_not1312 : ~ @Equation1312 Fin3 reff410_inst.
Proof. unfold Equation1312. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff410_inst, reff410_op in H. discriminate H. Qed.

Lemma reff410_not1313 : ~ @Equation1313 Fin3 reff410_inst.
Proof. unfold Equation1313. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff410_inst, reff410_op in H. discriminate H. Qed.

Lemma reff410_not1315 : ~ @Equation1315 Fin3 reff410_inst.
Proof. unfold Equation1315. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff410_inst, reff410_op in H. discriminate H. Qed.

Lemma reff410_not1316 : ~ @Equation1316 Fin3 reff410_inst.
Proof. unfold Equation1316. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff410_inst, reff410_op in H. discriminate H. Qed.

Lemma reff410_not1322 : ~ @Equation1322 Fin3 reff410_inst.
Proof. unfold Equation1322. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff410_inst, reff410_op in H. discriminate H. Qed.

Lemma reff410_not1323 : ~ @Equation1323 Fin3 reff410_inst.
Proof. unfold Equation1323. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff410_inst, reff410_op in H. discriminate H. Qed.

Lemma reff410_not1325 : ~ @Equation1325 Fin3 reff410_inst.
Proof. unfold Equation1325. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff410_inst, reff410_op in H. discriminate H. Qed.

Lemma reff410_not1427 : ~ @Equation1427 Fin3 reff410_inst.
Proof. unfold Equation1427. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff410_inst, reff410_op in H. discriminate H. Qed.

Lemma reff410_not1428 : ~ @Equation1428 Fin3 reff410_inst.
Proof. unfold Equation1428. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff410_inst, reff410_op in H. discriminate H. Qed.

Lemma reff410_not1429 : ~ @Equation1429 Fin3 reff410_inst.
Proof. unfold Equation1429. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff410_inst, reff410_op in H. discriminate H. Qed.

Lemma reff410_not1431 : ~ @Equation1431 Fin3 reff410_inst.
Proof. unfold Equation1431. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff410_inst, reff410_op in H. discriminate H. Qed.

Lemma reff410_not1432 : ~ @Equation1432 Fin3 reff410_inst.
Proof. unfold Equation1432. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff410_inst, reff410_op in H. discriminate H. Qed.

Lemma reff410_not1434 : ~ @Equation1434 Fin3 reff410_inst.
Proof. unfold Equation1434. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff410_inst, reff410_op in H. discriminate H. Qed.

Lemma reff410_not1435 : ~ @Equation1435 Fin3 reff410_inst.
Proof. unfold Equation1435. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff410_inst, reff410_op in H. discriminate H. Qed.

Lemma reff410_not1441 : ~ @Equation1441 Fin3 reff410_inst.
Proof. unfold Equation1441. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff410_inst, reff410_op in H. discriminate H. Qed.

Lemma reff410_not1442 : ~ @Equation1442 Fin3 reff410_inst.
Proof. unfold Equation1442. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff410_inst, reff410_op in H. discriminate H. Qed.

Lemma reff410_not1444 : ~ @Equation1444 Fin3 reff410_inst.
Proof. unfold Equation1444. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff410_inst, reff410_op in H. discriminate H. Qed.

Lemma reff410_not1445 : ~ @Equation1445 Fin3 reff410_inst.
Proof. unfold Equation1445. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff410_inst, reff410_op in H. discriminate H. Qed.

Lemma reff410_not1451 : ~ @Equation1451 Fin3 reff410_inst.
Proof. unfold Equation1451. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff410_inst, reff410_op in H. discriminate H. Qed.

Lemma reff410_not1452 : ~ @Equation1452 Fin3 reff410_inst.
Proof. unfold Equation1452. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff410_inst, reff410_op in H. discriminate H. Qed.

Lemma reff410_not1454 : ~ @Equation1454 Fin3 reff410_inst.
Proof. unfold Equation1454. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff410_inst, reff410_op in H. discriminate H. Qed.

Lemma reff410_not1455 : ~ @Equation1455 Fin3 reff410_inst.
Proof. unfold Equation1455. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff410_inst, reff410_op in H. discriminate H. Qed.

Lemma reff410_not1479 : ~ @Equation1479 Fin3 reff410_inst.
Proof. unfold Equation1479. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff410_inst, reff410_op in H. discriminate H. Qed.

Lemma reff410_not1482 : ~ @Equation1482 Fin3 reff410_inst.
Proof. unfold Equation1482. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff410_inst, reff410_op in H. discriminate H. Qed.

Lemma reff410_not1488 : ~ @Equation1488 Fin3 reff410_inst.
Proof. unfold Equation1488. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff410_inst, reff410_op in H. discriminate H. Qed.

Lemma reff410_not1491 : ~ @Equation1491 Fin3 reff410_inst.
Proof. unfold Equation1491. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff410_inst, reff410_op in H. discriminate H. Qed.

Lemma reff410_not1492 : ~ @Equation1492 Fin3 reff410_inst.
Proof. unfold Equation1492. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff410_inst, reff410_op in H. discriminate H. Qed.

Lemma reff410_not1515 : ~ @Equation1515 Fin3 reff410_inst.
Proof. unfold Equation1515. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff410_inst, reff410_op in H. discriminate H. Qed.

Lemma reff410_not1516 : ~ @Equation1516 Fin3 reff410_inst.
Proof. unfold Equation1516. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff410_inst, reff410_op in H. discriminate H. Qed.

Lemma reff410_not1518 : ~ @Equation1518 Fin3 reff410_inst.
Proof. unfold Equation1518. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff410_inst, reff410_op in H. discriminate H. Qed.

Lemma reff410_not1519 : ~ @Equation1519 Fin3 reff410_inst.
Proof. unfold Equation1519. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff410_inst, reff410_op in H. discriminate H. Qed.

Lemma reff410_not1525 : ~ @Equation1525 Fin3 reff410_inst.
Proof. unfold Equation1525. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff410_inst, reff410_op in H. discriminate H. Qed.

Lemma reff410_not1526 : ~ @Equation1526 Fin3 reff410_inst.
Proof. unfold Equation1526. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff410_inst, reff410_op in H. discriminate H. Qed.

Lemma reff410_not1528 : ~ @Equation1528 Fin3 reff410_inst.
Proof. unfold Equation1528. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff410_inst, reff410_op in H. discriminate H. Qed.

Lemma reff410_not1630 : ~ @Equation1630 Fin3 reff410_inst.
Proof. unfold Equation1630. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff410_inst, reff410_op in H. discriminate H. Qed.

Lemma reff410_not1631 : ~ @Equation1631 Fin3 reff410_inst.
Proof. unfold Equation1631. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff410_inst, reff410_op in H. discriminate H. Qed.

Lemma reff410_not1632 : ~ @Equation1632 Fin3 reff410_inst.
Proof. unfold Equation1632. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff410_inst, reff410_op in H. discriminate H. Qed.

Lemma reff410_not1635 : ~ @Equation1635 Fin3 reff410_inst.
Proof. unfold Equation1635. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff410_inst, reff410_op in H. discriminate H. Qed.

Lemma reff410_not1637 : ~ @Equation1637 Fin3 reff410_inst.
Proof. unfold Equation1637. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff410_inst, reff410_op in H. discriminate H. Qed.

Lemma reff410_not1638 : ~ @Equation1638 Fin3 reff410_inst.
Proof. unfold Equation1638. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff410_inst, reff410_op in H. discriminate H. Qed.

Lemma reff410_not1644 : ~ @Equation1644 Fin3 reff410_inst.
Proof. unfold Equation1644. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff410_inst, reff410_op in H. discriminate H. Qed.

Lemma reff410_not1645 : ~ @Equation1645 Fin3 reff410_inst.
Proof. unfold Equation1645. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff410_inst, reff410_op in H. discriminate H. Qed.

Lemma reff410_not1647 : ~ @Equation1647 Fin3 reff410_inst.
Proof. unfold Equation1647. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff410_inst, reff410_op in H. discriminate H. Qed.

Lemma reff410_not1648 : ~ @Equation1648 Fin3 reff410_inst.
Proof. unfold Equation1648. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff410_inst, reff410_op in H. discriminate H. Qed.

Lemma reff410_not1654 : ~ @Equation1654 Fin3 reff410_inst.
Proof. unfold Equation1654. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff410_inst, reff410_op in H. discriminate H. Qed.

Lemma reff410_not1655 : ~ @Equation1655 Fin3 reff410_inst.
Proof. unfold Equation1655. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff410_inst, reff410_op in H. discriminate H. Qed.

Lemma reff410_not1657 : ~ @Equation1657 Fin3 reff410_inst.
Proof. unfold Equation1657. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff410_inst, reff410_op in H. discriminate H. Qed.

Lemma reff410_not1658 : ~ @Equation1658 Fin3 reff410_inst.
Proof. unfold Equation1658. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff410_inst, reff410_op in H. discriminate H. Qed.

Lemma reff410_not1682 : ~ @Equation1682 Fin3 reff410_inst.
Proof. unfold Equation1682. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff410_inst, reff410_op in H. discriminate H. Qed.

Lemma reff410_not1684 : ~ @Equation1684 Fin3 reff410_inst.
Proof. unfold Equation1684. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff410_inst, reff410_op in H. discriminate H. Qed.

Lemma reff410_not1685 : ~ @Equation1685 Fin3 reff410_inst.
Proof. unfold Equation1685. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff410_inst, reff410_op in H. discriminate H. Qed.

Lemma reff410_not1692 : ~ @Equation1692 Fin3 reff410_inst.
Proof. unfold Equation1692. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff410_inst, reff410_op in H. discriminate H. Qed.

Lemma reff410_not1694 : ~ @Equation1694 Fin3 reff410_inst.
Proof. unfold Equation1694. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff410_inst, reff410_op in H. discriminate H. Qed.

Lemma reff410_not1695 : ~ @Equation1695 Fin3 reff410_inst.
Proof. unfold Equation1695. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff410_inst, reff410_op in H. discriminate H. Qed.

Lemma reff410_not1718 : ~ @Equation1718 Fin3 reff410_inst.
Proof. unfold Equation1718. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff410_inst, reff410_op in H. discriminate H. Qed.

Lemma reff410_not1719 : ~ @Equation1719 Fin3 reff410_inst.
Proof. unfold Equation1719. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff410_inst, reff410_op in H. discriminate H. Qed.

Lemma reff410_not1721 : ~ @Equation1721 Fin3 reff410_inst.
Proof. unfold Equation1721. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff410_inst, reff410_op in H. discriminate H. Qed.

Lemma reff410_not1722 : ~ @Equation1722 Fin3 reff410_inst.
Proof. unfold Equation1722. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff410_inst, reff410_op in H. discriminate H. Qed.

Lemma reff410_not1728 : ~ @Equation1728 Fin3 reff410_inst.
Proof. unfold Equation1728. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff410_inst, reff410_op in H. discriminate H. Qed.

Lemma reff410_not1729 : ~ @Equation1729 Fin3 reff410_inst.
Proof. unfold Equation1729. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff410_inst, reff410_op in H. discriminate H. Qed.

Lemma reff410_not1731 : ~ @Equation1731 Fin3 reff410_inst.
Proof. unfold Equation1731. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff410_inst, reff410_op in H. discriminate H. Qed.

Lemma reff410_not1833 : ~ @Equation1833 Fin3 reff410_inst.
Proof. unfold Equation1833. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff410_inst, reff410_op in H. discriminate H. Qed.

Lemma reff410_not1834 : ~ @Equation1834 Fin3 reff410_inst.
Proof. unfold Equation1834. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff410_inst, reff410_op in H. discriminate H. Qed.

Lemma reff410_not1835 : ~ @Equation1835 Fin3 reff410_inst.
Proof. unfold Equation1835. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff410_inst, reff410_op in H. discriminate H. Qed.

Lemma reff410_not1837 : ~ @Equation1837 Fin3 reff410_inst.
Proof. unfold Equation1837. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff410_inst, reff410_op in H. discriminate H. Qed.

Lemma reff410_not1838 : ~ @Equation1838 Fin3 reff410_inst.
Proof. unfold Equation1838. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff410_inst, reff410_op in H. discriminate H. Qed.

Lemma reff410_not1840 : ~ @Equation1840 Fin3 reff410_inst.
Proof. unfold Equation1840. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff410_inst, reff410_op in H. discriminate H. Qed.

Lemma reff410_not1841 : ~ @Equation1841 Fin3 reff410_inst.
Proof. unfold Equation1841. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff410_inst, reff410_op in H. discriminate H. Qed.

Lemma reff410_not1847 : ~ @Equation1847 Fin3 reff410_inst.
Proof. unfold Equation1847. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff410_inst, reff410_op in H. discriminate H. Qed.

Lemma reff410_not1848 : ~ @Equation1848 Fin3 reff410_inst.
Proof. unfold Equation1848. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff410_inst, reff410_op in H. discriminate H. Qed.

Lemma reff410_not1850 : ~ @Equation1850 Fin3 reff410_inst.
Proof. unfold Equation1850. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff410_inst, reff410_op in H. discriminate H. Qed.

Lemma reff410_not1851 : ~ @Equation1851 Fin3 reff410_inst.
Proof. unfold Equation1851. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff410_inst, reff410_op in H. discriminate H. Qed.

Lemma reff410_not1857 : ~ @Equation1857 Fin3 reff410_inst.
Proof. unfold Equation1857. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff410_inst, reff410_op in H. discriminate H. Qed.

Lemma reff410_not1858 : ~ @Equation1858 Fin3 reff410_inst.
Proof. unfold Equation1858. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff410_inst, reff410_op in H. discriminate H. Qed.

Lemma reff410_not1860 : ~ @Equation1860 Fin3 reff410_inst.
Proof. unfold Equation1860. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff410_inst, reff410_op in H. discriminate H. Qed.

Lemma reff410_not1861 : ~ @Equation1861 Fin3 reff410_inst.
Proof. unfold Equation1861. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff410_inst, reff410_op in H. discriminate H. Qed.

Lemma reff410_not1885 : ~ @Equation1885 Fin3 reff410_inst.
Proof. unfold Equation1885. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff410_inst, reff410_op in H. discriminate H. Qed.

Lemma reff410_not1887 : ~ @Equation1887 Fin3 reff410_inst.
Proof. unfold Equation1887. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff410_inst, reff410_op in H. discriminate H. Qed.

Lemma reff410_not1888 : ~ @Equation1888 Fin3 reff410_inst.
Proof. unfold Equation1888. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff410_inst, reff410_op in H. discriminate H. Qed.

Lemma reff410_not1894 : ~ @Equation1894 Fin3 reff410_inst.
Proof. unfold Equation1894. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff410_inst, reff410_op in H. discriminate H. Qed.

Lemma reff410_not1895 : ~ @Equation1895 Fin3 reff410_inst.
Proof. unfold Equation1895. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff410_inst, reff410_op in H. discriminate H. Qed.

Lemma reff410_not1897 : ~ @Equation1897 Fin3 reff410_inst.
Proof. unfold Equation1897. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff410_inst, reff410_op in H. discriminate H. Qed.

Lemma reff410_not1898 : ~ @Equation1898 Fin3 reff410_inst.
Proof. unfold Equation1898. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff410_inst, reff410_op in H. discriminate H. Qed.

Lemma reff410_not1922 : ~ @Equation1922 Fin3 reff410_inst.
Proof. unfold Equation1922. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff410_inst, reff410_op in H. discriminate H. Qed.

Lemma reff410_not1924 : ~ @Equation1924 Fin3 reff410_inst.
Proof. unfold Equation1924. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff410_inst, reff410_op in H. discriminate H. Qed.

Lemma reff410_not1925 : ~ @Equation1925 Fin3 reff410_inst.
Proof. unfold Equation1925. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff410_inst, reff410_op in H. discriminate H. Qed.

Lemma reff410_not1931 : ~ @Equation1931 Fin3 reff410_inst.
Proof. unfold Equation1931. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff410_inst, reff410_op in H. discriminate H. Qed.

Lemma reff410_not1932 : ~ @Equation1932 Fin3 reff410_inst.
Proof. unfold Equation1932. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff410_inst, reff410_op in H. discriminate H. Qed.

Lemma reff410_not1934 : ~ @Equation1934 Fin3 reff410_inst.
Proof. unfold Equation1934. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff410_inst, reff410_op in H. discriminate H. Qed.

Lemma reff410_not2036 : ~ @Equation2036 Fin3 reff410_inst.
Proof. unfold Equation2036. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff410_inst, reff410_op in H. discriminate H. Qed.

Lemma reff410_not2037 : ~ @Equation2037 Fin3 reff410_inst.
Proof. unfold Equation2037. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff410_inst, reff410_op in H. discriminate H. Qed.

Lemma reff410_not2038 : ~ @Equation2038 Fin3 reff410_inst.
Proof. unfold Equation2038. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff410_inst, reff410_op in H. discriminate H. Qed.

Lemma reff410_not2040 : ~ @Equation2040 Fin3 reff410_inst.
Proof. unfold Equation2040. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff410_inst, reff410_op in H. discriminate H. Qed.

Lemma reff410_not2041 : ~ @Equation2041 Fin3 reff410_inst.
Proof. unfold Equation2041. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff410_inst, reff410_op in H. discriminate H. Qed.

Lemma reff410_not2043 : ~ @Equation2043 Fin3 reff410_inst.
Proof. unfold Equation2043. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff410_inst, reff410_op in H. discriminate H. Qed.

Lemma reff410_not2044 : ~ @Equation2044 Fin3 reff410_inst.
Proof. unfold Equation2044. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff410_inst, reff410_op in H. discriminate H. Qed.

Lemma reff410_not2053 : ~ @Equation2053 Fin3 reff410_inst.
Proof. unfold Equation2053. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff410_inst, reff410_op in H. discriminate H. Qed.

Lemma reff410_not2054 : ~ @Equation2054 Fin3 reff410_inst.
Proof. unfold Equation2054. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff410_inst, reff410_op in H. discriminate H. Qed.

Lemma reff410_not2060 : ~ @Equation2060 Fin3 reff410_inst.
Proof. unfold Equation2060. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff410_inst, reff410_op in H. discriminate H. Qed.

Lemma reff410_not2061 : ~ @Equation2061 Fin3 reff410_inst.
Proof. unfold Equation2061. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff410_inst, reff410_op in H. discriminate H. Qed.

Lemma reff410_not2063 : ~ @Equation2063 Fin3 reff410_inst.
Proof. unfold Equation2063. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff410_inst, reff410_op in H. discriminate H. Qed.

Lemma reff410_not2064 : ~ @Equation2064 Fin3 reff410_inst.
Proof. unfold Equation2064. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff410_inst, reff410_op in H. discriminate H. Qed.

Lemma reff410_not2088 : ~ @Equation2088 Fin3 reff410_inst.
Proof. unfold Equation2088. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff410_inst, reff410_op in H. discriminate H. Qed.

Lemma reff410_not2090 : ~ @Equation2090 Fin3 reff410_inst.
Proof. unfold Equation2090. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff410_inst, reff410_op in H. discriminate H. Qed.

Lemma reff410_not2091 : ~ @Equation2091 Fin3 reff410_inst.
Proof. unfold Equation2091. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff410_inst, reff410_op in H. discriminate H. Qed.

Lemma reff410_not2097 : ~ @Equation2097 Fin3 reff410_inst.
Proof. unfold Equation2097. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff410_inst, reff410_op in H. discriminate H. Qed.

Lemma reff410_not2098 : ~ @Equation2098 Fin3 reff410_inst.
Proof. unfold Equation2098. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff410_inst, reff410_op in H. discriminate H. Qed.

Lemma reff410_not2100 : ~ @Equation2100 Fin3 reff410_inst.
Proof. unfold Equation2100. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff410_inst, reff410_op in H. discriminate H. Qed.

Lemma reff410_not2101 : ~ @Equation2101 Fin3 reff410_inst.
Proof. unfold Equation2101. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff410_inst, reff410_op in H. discriminate H. Qed.

Lemma reff410_not2125 : ~ @Equation2125 Fin3 reff410_inst.
Proof. unfold Equation2125. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff410_inst, reff410_op in H. discriminate H. Qed.

Lemma reff410_not2127 : ~ @Equation2127 Fin3 reff410_inst.
Proof. unfold Equation2127. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff410_inst, reff410_op in H. discriminate H. Qed.

Lemma reff410_not2128 : ~ @Equation2128 Fin3 reff410_inst.
Proof. unfold Equation2128. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff410_inst, reff410_op in H. discriminate H. Qed.

Lemma reff410_not2134 : ~ @Equation2134 Fin3 reff410_inst.
Proof. unfold Equation2134. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff410_inst, reff410_op in H. discriminate H. Qed.

Lemma reff410_not2135 : ~ @Equation2135 Fin3 reff410_inst.
Proof. unfold Equation2135. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff410_inst, reff410_op in H. discriminate H. Qed.

Lemma reff410_not2137 : ~ @Equation2137 Fin3 reff410_inst.
Proof. unfold Equation2137. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff410_inst, reff410_op in H. discriminate H. Qed.

Lemma reff410_not2239 : ~ @Equation2239 Fin3 reff410_inst.
Proof. unfold Equation2239. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff410_inst, reff410_op in H. discriminate H. Qed.

Lemma reff410_not2240 : ~ @Equation2240 Fin3 reff410_inst.
Proof. unfold Equation2240. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff410_inst, reff410_op in H. discriminate H. Qed.

Lemma reff410_not2241 : ~ @Equation2241 Fin3 reff410_inst.
Proof. unfold Equation2241. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff410_inst, reff410_op in H. discriminate H. Qed.

Lemma reff410_not2243 : ~ @Equation2243 Fin3 reff410_inst.
Proof. unfold Equation2243. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff410_inst, reff410_op in H. discriminate H. Qed.

Lemma reff410_not2244 : ~ @Equation2244 Fin3 reff410_inst.
Proof. unfold Equation2244. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff410_inst, reff410_op in H. discriminate H. Qed.

Lemma reff410_not2246 : ~ @Equation2246 Fin3 reff410_inst.
Proof. unfold Equation2246. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff410_inst, reff410_op in H. discriminate H. Qed.

Lemma reff410_not2247 : ~ @Equation2247 Fin3 reff410_inst.
Proof. unfold Equation2247. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff410_inst, reff410_op in H. discriminate H. Qed.

Lemma reff410_not2253 : ~ @Equation2253 Fin3 reff410_inst.
Proof. unfold Equation2253. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff410_inst, reff410_op in H. discriminate H. Qed.

Lemma reff410_not2254 : ~ @Equation2254 Fin3 reff410_inst.
Proof. unfold Equation2254. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff410_inst, reff410_op in H. discriminate H. Qed.

Lemma reff410_not2256 : ~ @Equation2256 Fin3 reff410_inst.
Proof. unfold Equation2256. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff410_inst, reff410_op in H. discriminate H. Qed.

Lemma reff410_not2257 : ~ @Equation2257 Fin3 reff410_inst.
Proof. unfold Equation2257. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff410_inst, reff410_op in H. discriminate H. Qed.

Lemma reff410_not2263 : ~ @Equation2263 Fin3 reff410_inst.
Proof. unfold Equation2263. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff410_inst, reff410_op in H. discriminate H. Qed.

Lemma reff410_not2264 : ~ @Equation2264 Fin3 reff410_inst.
Proof. unfold Equation2264. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff410_inst, reff410_op in H. discriminate H. Qed.

Lemma reff410_not2266 : ~ @Equation2266 Fin3 reff410_inst.
Proof. unfold Equation2266. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff410_inst, reff410_op in H. discriminate H. Qed.

Lemma reff410_not2267 : ~ @Equation2267 Fin3 reff410_inst.
Proof. unfold Equation2267. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff410_inst, reff410_op in H. discriminate H. Qed.

Lemma reff410_not2291 : ~ @Equation2291 Fin3 reff410_inst.
Proof. unfold Equation2291. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff410_inst, reff410_op in H. discriminate H. Qed.

Lemma reff410_not2293 : ~ @Equation2293 Fin3 reff410_inst.
Proof. unfold Equation2293. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff410_inst, reff410_op in H. discriminate H. Qed.

Lemma reff410_not2294 : ~ @Equation2294 Fin3 reff410_inst.
Proof. unfold Equation2294. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff410_inst, reff410_op in H. discriminate H. Qed.

Lemma reff410_not2300 : ~ @Equation2300 Fin3 reff410_inst.
Proof. unfold Equation2300. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff410_inst, reff410_op in H. discriminate H. Qed.

Lemma reff410_not2301 : ~ @Equation2301 Fin3 reff410_inst.
Proof. unfold Equation2301. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff410_inst, reff410_op in H. discriminate H. Qed.

Lemma reff410_not2303 : ~ @Equation2303 Fin3 reff410_inst.
Proof. unfold Equation2303. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff410_inst, reff410_op in H. discriminate H. Qed.

Lemma reff410_not2304 : ~ @Equation2304 Fin3 reff410_inst.
Proof. unfold Equation2304. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff410_inst, reff410_op in H. discriminate H. Qed.

Lemma reff410_not2328 : ~ @Equation2328 Fin3 reff410_inst.
Proof. unfold Equation2328. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff410_inst, reff410_op in H. discriminate H. Qed.

Lemma reff410_not2330 : ~ @Equation2330 Fin3 reff410_inst.
Proof. unfold Equation2330. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff410_inst, reff410_op in H. discriminate H. Qed.

Lemma reff410_not2331 : ~ @Equation2331 Fin3 reff410_inst.
Proof. unfold Equation2331. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff410_inst, reff410_op in H. discriminate H. Qed.

Lemma reff410_not2338 : ~ @Equation2338 Fin3 reff410_inst.
Proof. unfold Equation2338. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff410_inst, reff410_op in H. discriminate H. Qed.

Lemma reff410_not2340 : ~ @Equation2340 Fin3 reff410_inst.
Proof. unfold Equation2340. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff410_inst, reff410_op in H. discriminate H. Qed.

Lemma reff410_not2442 : ~ @Equation2442 Fin3 reff410_inst.
Proof. unfold Equation2442. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff410_inst, reff410_op in H. discriminate H. Qed.

Lemma reff410_not2443 : ~ @Equation2443 Fin3 reff410_inst.
Proof. unfold Equation2443. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff410_inst, reff410_op in H. discriminate H. Qed.

Lemma reff410_not2444 : ~ @Equation2444 Fin3 reff410_inst.
Proof. unfold Equation2444. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff410_inst, reff410_op in H. discriminate H. Qed.

Lemma reff410_not2446 : ~ @Equation2446 Fin3 reff410_inst.
Proof. unfold Equation2446. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff410_inst, reff410_op in H. discriminate H. Qed.

Lemma reff410_not2447 : ~ @Equation2447 Fin3 reff410_inst.
Proof. unfold Equation2447. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff410_inst, reff410_op in H. discriminate H. Qed.

Lemma reff410_not2449 : ~ @Equation2449 Fin3 reff410_inst.
Proof. unfold Equation2449. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff410_inst, reff410_op in H. discriminate H. Qed.

Lemma reff410_not2450 : ~ @Equation2450 Fin3 reff410_inst.
Proof. unfold Equation2450. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff410_inst, reff410_op in H. discriminate H. Qed.

Lemma reff410_not2457 : ~ @Equation2457 Fin3 reff410_inst.
Proof. unfold Equation2457. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff410_inst, reff410_op in H. discriminate H. Qed.

Lemma reff410_not2459 : ~ @Equation2459 Fin3 reff410_inst.
Proof. unfold Equation2459. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff410_inst, reff410_op in H. discriminate H. Qed.

Lemma reff410_not2460 : ~ @Equation2460 Fin3 reff410_inst.
Proof. unfold Equation2460. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff410_inst, reff410_op in H. discriminate H. Qed.

Lemma reff410_not2466 : ~ @Equation2466 Fin3 reff410_inst.
Proof. unfold Equation2466. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff410_inst, reff410_op in H. discriminate H. Qed.

Lemma reff410_not2467 : ~ @Equation2467 Fin3 reff410_inst.
Proof. unfold Equation2467. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff410_inst, reff410_op in H. discriminate H. Qed.

Lemma reff410_not2469 : ~ @Equation2469 Fin3 reff410_inst.
Proof. unfold Equation2469. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff410_inst, reff410_op in H. discriminate H. Qed.

Lemma reff410_not2470 : ~ @Equation2470 Fin3 reff410_inst.
Proof. unfold Equation2470. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff410_inst, reff410_op in H. discriminate H. Qed.

Lemma reff410_not2494 : ~ @Equation2494 Fin3 reff410_inst.
Proof. unfold Equation2494. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff410_inst, reff410_op in H. discriminate H. Qed.

Lemma reff410_not2496 : ~ @Equation2496 Fin3 reff410_inst.
Proof. unfold Equation2496. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff410_inst, reff410_op in H. discriminate H. Qed.

Lemma reff410_not2497 : ~ @Equation2497 Fin3 reff410_inst.
Proof. unfold Equation2497. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff410_inst, reff410_op in H. discriminate H. Qed.

Lemma reff410_not2504 : ~ @Equation2504 Fin3 reff410_inst.
Proof. unfold Equation2504. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff410_inst, reff410_op in H. discriminate H. Qed.

Lemma reff410_not2506 : ~ @Equation2506 Fin3 reff410_inst.
Proof. unfold Equation2506. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff410_inst, reff410_op in H. discriminate H. Qed.

Lemma reff410_not2507 : ~ @Equation2507 Fin3 reff410_inst.
Proof. unfold Equation2507. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff410_inst, reff410_op in H. discriminate H. Qed.

Lemma reff410_not2531 : ~ @Equation2531 Fin3 reff410_inst.
Proof. unfold Equation2531. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff410_inst, reff410_op in H. discriminate H. Qed.

Lemma reff410_not2534 : ~ @Equation2534 Fin3 reff410_inst.
Proof. unfold Equation2534. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff410_inst, reff410_op in H. discriminate H. Qed.

Lemma reff410_not2541 : ~ @Equation2541 Fin3 reff410_inst.
Proof. unfold Equation2541. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff410_inst, reff410_op in H. discriminate H. Qed.

Lemma reff410_not2543 : ~ @Equation2543 Fin3 reff410_inst.
Proof. unfold Equation2543. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff410_inst, reff410_op in H. discriminate H. Qed.

Lemma reff410_not2645 : ~ @Equation2645 Fin3 reff410_inst.
Proof. unfold Equation2645. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff410_inst, reff410_op in H. discriminate H. Qed.

Lemma reff410_not2646 : ~ @Equation2646 Fin3 reff410_inst.
Proof. unfold Equation2646. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff410_inst, reff410_op in H. discriminate H. Qed.

Lemma reff410_not2647 : ~ @Equation2647 Fin3 reff410_inst.
Proof. unfold Equation2647. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff410_inst, reff410_op in H. discriminate H. Qed.

Lemma reff410_not2649 : ~ @Equation2649 Fin3 reff410_inst.
Proof. unfold Equation2649. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff410_inst, reff410_op in H. discriminate H. Qed.

Lemma reff410_not2650 : ~ @Equation2650 Fin3 reff410_inst.
Proof. unfold Equation2650. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff410_inst, reff410_op in H. discriminate H. Qed.

Lemma reff410_not2652 : ~ @Equation2652 Fin3 reff410_inst.
Proof. unfold Equation2652. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff410_inst, reff410_op in H. discriminate H. Qed.

Lemma reff410_not2653 : ~ @Equation2653 Fin3 reff410_inst.
Proof. unfold Equation2653. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff410_inst, reff410_op in H. discriminate H. Qed.

Lemma reff410_not2660 : ~ @Equation2660 Fin3 reff410_inst.
Proof. unfold Equation2660. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff410_inst, reff410_op in H. discriminate H. Qed.

Lemma reff410_not2662 : ~ @Equation2662 Fin3 reff410_inst.
Proof. unfold Equation2662. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff410_inst, reff410_op in H. discriminate H. Qed.

Lemma reff410_not2663 : ~ @Equation2663 Fin3 reff410_inst.
Proof. unfold Equation2663. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff410_inst, reff410_op in H. discriminate H. Qed.

Lemma reff410_not2670 : ~ @Equation2670 Fin3 reff410_inst.
Proof. unfold Equation2670. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff410_inst, reff410_op in H. discriminate H. Qed.

Lemma reff410_not2672 : ~ @Equation2672 Fin3 reff410_inst.
Proof. unfold Equation2672. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff410_inst, reff410_op in H. discriminate H. Qed.

Lemma reff410_not2673 : ~ @Equation2673 Fin3 reff410_inst.
Proof. unfold Equation2673. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff410_inst, reff410_op in H. discriminate H. Qed.

Lemma reff410_not2697 : ~ @Equation2697 Fin3 reff410_inst.
Proof. unfold Equation2697. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff410_inst, reff410_op in H. discriminate H. Qed.

Lemma reff410_not2699 : ~ @Equation2699 Fin3 reff410_inst.
Proof. unfold Equation2699. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff410_inst, reff410_op in H. discriminate H. Qed.

Lemma reff410_not2700 : ~ @Equation2700 Fin3 reff410_inst.
Proof. unfold Equation2700. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff410_inst, reff410_op in H. discriminate H. Qed.

Lemma reff410_not2707 : ~ @Equation2707 Fin3 reff410_inst.
Proof. unfold Equation2707. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff410_inst, reff410_op in H. discriminate H. Qed.

Lemma reff410_not2709 : ~ @Equation2709 Fin3 reff410_inst.
Proof. unfold Equation2709. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff410_inst, reff410_op in H. discriminate H. Qed.

Lemma reff410_not2710 : ~ @Equation2710 Fin3 reff410_inst.
Proof. unfold Equation2710. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff410_inst, reff410_op in H. discriminate H. Qed.

Lemma reff410_not2734 : ~ @Equation2734 Fin3 reff410_inst.
Proof. unfold Equation2734. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff410_inst, reff410_op in H. discriminate H. Qed.

Lemma reff410_not2736 : ~ @Equation2736 Fin3 reff410_inst.
Proof. unfold Equation2736. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff410_inst, reff410_op in H. discriminate H. Qed.

Lemma reff410_not2737 : ~ @Equation2737 Fin3 reff410_inst.
Proof. unfold Equation2737. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff410_inst, reff410_op in H. discriminate H. Qed.

Lemma reff410_not2744 : ~ @Equation2744 Fin3 reff410_inst.
Proof. unfold Equation2744. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff410_inst, reff410_op in H. discriminate H. Qed.

Lemma reff410_not2746 : ~ @Equation2746 Fin3 reff410_inst.
Proof. unfold Equation2746. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff410_inst, reff410_op in H. discriminate H. Qed.

Lemma reff410_not2804 : ~ @Equation2804 Fin3 reff410_inst.
Proof. unfold Equation2804. intro H. specialize (H F3_0 F3_1 F3_2). unfold magma_op, reff410_inst, reff410_op in H. discriminate H. Qed.

Lemma reff410_not2848 : ~ @Equation2848 Fin3 reff410_inst.
Proof. unfold Equation2848. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff410_inst, reff410_op in H. discriminate H. Qed.

Lemma reff410_not2849 : ~ @Equation2849 Fin3 reff410_inst.
Proof. unfold Equation2849. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff410_inst, reff410_op in H. discriminate H. Qed.

Lemma reff410_not2850 : ~ @Equation2850 Fin3 reff410_inst.
Proof. unfold Equation2850. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff410_inst, reff410_op in H. discriminate H. Qed.

Lemma reff410_not2853 : ~ @Equation2853 Fin3 reff410_inst.
Proof. unfold Equation2853. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff410_inst, reff410_op in H. discriminate H. Qed.

Lemma reff410_not2855 : ~ @Equation2855 Fin3 reff410_inst.
Proof. unfold Equation2855. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff410_inst, reff410_op in H. discriminate H. Qed.

Lemma reff410_not2856 : ~ @Equation2856 Fin3 reff410_inst.
Proof. unfold Equation2856. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff410_inst, reff410_op in H. discriminate H. Qed.

Lemma reff410_not2863 : ~ @Equation2863 Fin3 reff410_inst.
Proof. unfold Equation2863. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff410_inst, reff410_op in H. discriminate H. Qed.

Lemma reff410_not2865 : ~ @Equation2865 Fin3 reff410_inst.
Proof. unfold Equation2865. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff410_inst, reff410_op in H. discriminate H. Qed.

Lemma reff410_not2866 : ~ @Equation2866 Fin3 reff410_inst.
Proof. unfold Equation2866. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff410_inst, reff410_op in H. discriminate H. Qed.

Lemma reff410_not2873 : ~ @Equation2873 Fin3 reff410_inst.
Proof. unfold Equation2873. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff410_inst, reff410_op in H. discriminate H. Qed.

Lemma reff410_not2875 : ~ @Equation2875 Fin3 reff410_inst.
Proof. unfold Equation2875. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff410_inst, reff410_op in H. discriminate H. Qed.

Lemma reff410_not2876 : ~ @Equation2876 Fin3 reff410_inst.
Proof. unfold Equation2876. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff410_inst, reff410_op in H. discriminate H. Qed.

Lemma reff410_not2900 : ~ @Equation2900 Fin3 reff410_inst.
Proof. unfold Equation2900. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff410_inst, reff410_op in H. discriminate H. Qed.

Lemma reff410_not2902 : ~ @Equation2902 Fin3 reff410_inst.
Proof. unfold Equation2902. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff410_inst, reff410_op in H. discriminate H. Qed.

Lemma reff410_not2903 : ~ @Equation2903 Fin3 reff410_inst.
Proof. unfold Equation2903. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff410_inst, reff410_op in H. discriminate H. Qed.

Lemma reff410_not2910 : ~ @Equation2910 Fin3 reff410_inst.
Proof. unfold Equation2910. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff410_inst, reff410_op in H. discriminate H. Qed.

Lemma reff410_not2912 : ~ @Equation2912 Fin3 reff410_inst.
Proof. unfold Equation2912. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff410_inst, reff410_op in H. discriminate H. Qed.

Lemma reff410_not2913 : ~ @Equation2913 Fin3 reff410_inst.
Proof. unfold Equation2913. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff410_inst, reff410_op in H. discriminate H. Qed.

Lemma reff410_not2937 : ~ @Equation2937 Fin3 reff410_inst.
Proof. unfold Equation2937. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff410_inst, reff410_op in H. discriminate H. Qed.

Lemma reff410_not2939 : ~ @Equation2939 Fin3 reff410_inst.
Proof. unfold Equation2939. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff410_inst, reff410_op in H. discriminate H. Qed.

Lemma reff410_not2940 : ~ @Equation2940 Fin3 reff410_inst.
Proof. unfold Equation2940. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff410_inst, reff410_op in H. discriminate H. Qed.

Lemma reff410_not2947 : ~ @Equation2947 Fin3 reff410_inst.
Proof. unfold Equation2947. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff410_inst, reff410_op in H. discriminate H. Qed.

Lemma reff410_not2949 : ~ @Equation2949 Fin3 reff410_inst.
Proof. unfold Equation2949. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff410_inst, reff410_op in H. discriminate H. Qed.

Lemma reff410_not3051 : ~ @Equation3051 Fin3 reff410_inst.
Proof. unfold Equation3051. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff410_inst, reff410_op in H. discriminate H. Qed.

Lemma reff410_not3052 : ~ @Equation3052 Fin3 reff410_inst.
Proof. unfold Equation3052. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff410_inst, reff410_op in H. discriminate H. Qed.

Lemma reff410_not3053 : ~ @Equation3053 Fin3 reff410_inst.
Proof. unfold Equation3053. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff410_inst, reff410_op in H. discriminate H. Qed.

Lemma reff410_not3056 : ~ @Equation3056 Fin3 reff410_inst.
Proof. unfold Equation3056. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff410_inst, reff410_op in H. discriminate H. Qed.

Lemma reff410_not3058 : ~ @Equation3058 Fin3 reff410_inst.
Proof. unfold Equation3058. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff410_inst, reff410_op in H. discriminate H. Qed.

Lemma reff410_not3059 : ~ @Equation3059 Fin3 reff410_inst.
Proof. unfold Equation3059. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff410_inst, reff410_op in H. discriminate H. Qed.

Lemma reff410_not3066 : ~ @Equation3066 Fin3 reff410_inst.
Proof. unfold Equation3066. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff410_inst, reff410_op in H. discriminate H. Qed.

Lemma reff410_not3069 : ~ @Equation3069 Fin3 reff410_inst.
Proof. unfold Equation3069. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff410_inst, reff410_op in H. discriminate H. Qed.

Lemma reff410_not3076 : ~ @Equation3076 Fin3 reff410_inst.
Proof. unfold Equation3076. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff410_inst, reff410_op in H. discriminate H. Qed.

Lemma reff410_not3078 : ~ @Equation3078 Fin3 reff410_inst.
Proof. unfold Equation3078. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff410_inst, reff410_op in H. discriminate H. Qed.

Lemma reff410_not3079 : ~ @Equation3079 Fin3 reff410_inst.
Proof. unfold Equation3079. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff410_inst, reff410_op in H. discriminate H. Qed.

Lemma reff410_not3103 : ~ @Equation3103 Fin3 reff410_inst.
Proof. unfold Equation3103. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff410_inst, reff410_op in H. discriminate H. Qed.

Lemma reff410_not3105 : ~ @Equation3105 Fin3 reff410_inst.
Proof. unfold Equation3105. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff410_inst, reff410_op in H. discriminate H. Qed.

Lemma reff410_not3106 : ~ @Equation3106 Fin3 reff410_inst.
Proof. unfold Equation3106. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff410_inst, reff410_op in H. discriminate H. Qed.

Lemma reff410_not3113 : ~ @Equation3113 Fin3 reff410_inst.
Proof. unfold Equation3113. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff410_inst, reff410_op in H. discriminate H. Qed.

Lemma reff410_not3115 : ~ @Equation3115 Fin3 reff410_inst.
Proof. unfold Equation3115. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff410_inst, reff410_op in H. discriminate H. Qed.

Lemma reff410_not3116 : ~ @Equation3116 Fin3 reff410_inst.
Proof. unfold Equation3116. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff410_inst, reff410_op in H. discriminate H. Qed.

Lemma reff410_not3140 : ~ @Equation3140 Fin3 reff410_inst.
Proof. unfold Equation3140. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff410_inst, reff410_op in H. discriminate H. Qed.

Lemma reff410_not3142 : ~ @Equation3142 Fin3 reff410_inst.
Proof. unfold Equation3142. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff410_inst, reff410_op in H. discriminate H. Qed.

Lemma reff410_not3143 : ~ @Equation3143 Fin3 reff410_inst.
Proof. unfold Equation3143. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff410_inst, reff410_op in H. discriminate H. Qed.

Lemma reff410_not3150 : ~ @Equation3150 Fin3 reff410_inst.
Proof. unfold Equation3150. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff410_inst, reff410_op in H. discriminate H. Qed.

Lemma reff410_not3152 : ~ @Equation3152 Fin3 reff410_inst.
Proof. unfold Equation3152. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff410_inst, reff410_op in H. discriminate H. Qed.

Lemma reff410_not3254 : ~ @Equation3254 Fin3 reff410_inst.
Proof. unfold Equation3254. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff410_inst, reff410_op in H. discriminate H. Qed.

Lemma reff410_not3255 : ~ @Equation3255 Fin3 reff410_inst.
Proof. unfold Equation3255. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff410_inst, reff410_op in H. discriminate H. Qed.

Lemma reff410_not3256 : ~ @Equation3256 Fin3 reff410_inst.
Proof. unfold Equation3256. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff410_inst, reff410_op in H. discriminate H. Qed.

Lemma reff410_not3258 : ~ @Equation3258 Fin3 reff410_inst.
Proof. unfold Equation3258. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff410_inst, reff410_op in H. discriminate H. Qed.

Lemma reff410_not3259 : ~ @Equation3259 Fin3 reff410_inst.
Proof. unfold Equation3259. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff410_inst, reff410_op in H. discriminate H. Qed.

Lemma reff410_not3261 : ~ @Equation3261 Fin3 reff410_inst.
Proof. unfold Equation3261. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff410_inst, reff410_op in H. discriminate H. Qed.

Lemma reff410_not3262 : ~ @Equation3262 Fin3 reff410_inst.
Proof. unfold Equation3262. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff410_inst, reff410_op in H. discriminate H. Qed.

Lemma reff410_not3268 : ~ @Equation3268 Fin3 reff410_inst.
Proof. unfold Equation3268. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff410_inst, reff410_op in H. discriminate H. Qed.

Lemma reff410_not3269 : ~ @Equation3269 Fin3 reff410_inst.
Proof. unfold Equation3269. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff410_inst, reff410_op in H. discriminate H. Qed.

Lemma reff410_not3271 : ~ @Equation3271 Fin3 reff410_inst.
Proof. unfold Equation3271. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff410_inst, reff410_op in H. discriminate H. Qed.

Lemma reff410_not3272 : ~ @Equation3272 Fin3 reff410_inst.
Proof. unfold Equation3272. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff410_inst, reff410_op in H. discriminate H. Qed.

Lemma reff410_not3278 : ~ @Equation3278 Fin3 reff410_inst.
Proof. unfold Equation3278. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff410_inst, reff410_op in H. discriminate H. Qed.

Lemma reff410_not3279 : ~ @Equation3279 Fin3 reff410_inst.
Proof. unfold Equation3279. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff410_inst, reff410_op in H. discriminate H. Qed.

Lemma reff410_not3281 : ~ @Equation3281 Fin3 reff410_inst.
Proof. unfold Equation3281. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff410_inst, reff410_op in H. discriminate H. Qed.

Lemma reff410_not3308 : ~ @Equation3308 Fin3 reff410_inst.
Proof. unfold Equation3308. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff410_inst, reff410_op in H. discriminate H. Qed.

Lemma reff410_not3315 : ~ @Equation3315 Fin3 reff410_inst.
Proof. unfold Equation3315. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff410_inst, reff410_op in H. discriminate H. Qed.

Lemma reff410_not3316 : ~ @Equation3316 Fin3 reff410_inst.
Proof. unfold Equation3316. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff410_inst, reff410_op in H. discriminate H. Qed.

Lemma reff410_not3318 : ~ @Equation3318 Fin3 reff410_inst.
Proof. unfold Equation3318. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff410_inst, reff410_op in H. discriminate H. Qed.

Lemma reff410_not3342 : ~ @Equation3342 Fin3 reff410_inst.
Proof. unfold Equation3342. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff410_inst, reff410_op in H. discriminate H. Qed.

Lemma reff410_not3343 : ~ @Equation3343 Fin3 reff410_inst.
Proof. unfold Equation3343. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff410_inst, reff410_op in H. discriminate H. Qed.

Lemma reff410_not3345 : ~ @Equation3345 Fin3 reff410_inst.
Proof. unfold Equation3345. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff410_inst, reff410_op in H. discriminate H. Qed.

Lemma reff410_not3346 : ~ @Equation3346 Fin3 reff410_inst.
Proof. unfold Equation3346. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff410_inst, reff410_op in H. discriminate H. Qed.

Lemma reff410_not3352 : ~ @Equation3352 Fin3 reff410_inst.
Proof. unfold Equation3352. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff410_inst, reff410_op in H. discriminate H. Qed.

Lemma reff410_not3353 : ~ @Equation3353 Fin3 reff410_inst.
Proof. unfold Equation3353. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff410_inst, reff410_op in H. discriminate H. Qed.

Lemma reff410_not3457 : ~ @Equation3457 Fin3 reff410_inst.
Proof. unfold Equation3457. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff410_inst, reff410_op in H. discriminate H. Qed.

Lemma reff410_not3458 : ~ @Equation3458 Fin3 reff410_inst.
Proof. unfold Equation3458. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff410_inst, reff410_op in H. discriminate H. Qed.

Lemma reff410_not3459 : ~ @Equation3459 Fin3 reff410_inst.
Proof. unfold Equation3459. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff410_inst, reff410_op in H. discriminate H. Qed.

Lemma reff410_not3462 : ~ @Equation3462 Fin3 reff410_inst.
Proof. unfold Equation3462. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff410_inst, reff410_op in H. discriminate H. Qed.

Lemma reff410_not3464 : ~ @Equation3464 Fin3 reff410_inst.
Proof. unfold Equation3464. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff410_inst, reff410_op in H. discriminate H. Qed.

Lemma reff410_not3465 : ~ @Equation3465 Fin3 reff410_inst.
Proof. unfold Equation3465. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff410_inst, reff410_op in H. discriminate H. Qed.

Lemma reff410_not3472 : ~ @Equation3472 Fin3 reff410_inst.
Proof. unfold Equation3472. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff410_inst, reff410_op in H. discriminate H. Qed.

Lemma reff410_not3474 : ~ @Equation3474 Fin3 reff410_inst.
Proof. unfold Equation3474. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff410_inst, reff410_op in H. discriminate H. Qed.

Lemma reff410_not3475 : ~ @Equation3475 Fin3 reff410_inst.
Proof. unfold Equation3475. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff410_inst, reff410_op in H. discriminate H. Qed.

Lemma reff410_not3481 : ~ @Equation3481 Fin3 reff410_inst.
Proof. unfold Equation3481. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff410_inst, reff410_op in H. discriminate H. Qed.

Lemma reff410_not3482 : ~ @Equation3482 Fin3 reff410_inst.
Proof. unfold Equation3482. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff410_inst, reff410_op in H. discriminate H. Qed.

Lemma reff410_not3484 : ~ @Equation3484 Fin3 reff410_inst.
Proof. unfold Equation3484. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff410_inst, reff410_op in H. discriminate H. Qed.

Lemma reff410_not3518 : ~ @Equation3518 Fin3 reff410_inst.
Proof. unfold Equation3518. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff410_inst, reff410_op in H. discriminate H. Qed.

Lemma reff410_not3519 : ~ @Equation3519 Fin3 reff410_inst.
Proof. unfold Equation3519. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff410_inst, reff410_op in H. discriminate H. Qed.

Lemma reff410_not3521 : ~ @Equation3521 Fin3 reff410_inst.
Proof. unfold Equation3521. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff410_inst, reff410_op in H. discriminate H. Qed.

Lemma reff410_not3545 : ~ @Equation3545 Fin3 reff410_inst.
Proof. unfold Equation3545. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff410_inst, reff410_op in H. discriminate H. Qed.

Lemma reff410_not3546 : ~ @Equation3546 Fin3 reff410_inst.
Proof. unfold Equation3546. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff410_inst, reff410_op in H. discriminate H. Qed.

Lemma reff410_not3548 : ~ @Equation3548 Fin3 reff410_inst.
Proof. unfold Equation3548. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff410_inst, reff410_op in H. discriminate H. Qed.

Lemma reff410_not3549 : ~ @Equation3549 Fin3 reff410_inst.
Proof. unfold Equation3549. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff410_inst, reff410_op in H. discriminate H. Qed.

Lemma reff410_not3555 : ~ @Equation3555 Fin3 reff410_inst.
Proof. unfold Equation3555. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff410_inst, reff410_op in H. discriminate H. Qed.

Lemma reff410_not3556 : ~ @Equation3556 Fin3 reff410_inst.
Proof. unfold Equation3556. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff410_inst, reff410_op in H. discriminate H. Qed.

Lemma reff410_not3558 : ~ @Equation3558 Fin3 reff410_inst.
Proof. unfold Equation3558. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff410_inst, reff410_op in H. discriminate H. Qed.

Lemma reff410_not3660 : ~ @Equation3660 Fin3 reff410_inst.
Proof. unfold Equation3660. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff410_inst, reff410_op in H. discriminate H. Qed.

Lemma reff410_not3661 : ~ @Equation3661 Fin3 reff410_inst.
Proof. unfold Equation3661. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff410_inst, reff410_op in H. discriminate H. Qed.

Lemma reff410_not3662 : ~ @Equation3662 Fin3 reff410_inst.
Proof. unfold Equation3662. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff410_inst, reff410_op in H. discriminate H. Qed.

Lemma reff410_not3664 : ~ @Equation3664 Fin3 reff410_inst.
Proof. unfold Equation3664. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff410_inst, reff410_op in H. discriminate H. Qed.

Lemma reff410_not3665 : ~ @Equation3665 Fin3 reff410_inst.
Proof. unfold Equation3665. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff410_inst, reff410_op in H. discriminate H. Qed.

Lemma reff410_not3667 : ~ @Equation3667 Fin3 reff410_inst.
Proof. unfold Equation3667. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff410_inst, reff410_op in H. discriminate H. Qed.

Lemma reff410_not3668 : ~ @Equation3668 Fin3 reff410_inst.
Proof. unfold Equation3668. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff410_inst, reff410_op in H. discriminate H. Qed.

Lemma reff410_not3675 : ~ @Equation3675 Fin3 reff410_inst.
Proof. unfold Equation3675. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff410_inst, reff410_op in H. discriminate H. Qed.

Lemma reff410_not3677 : ~ @Equation3677 Fin3 reff410_inst.
Proof. unfold Equation3677. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff410_inst, reff410_op in H. discriminate H. Qed.

Lemma reff410_not3678 : ~ @Equation3678 Fin3 reff410_inst.
Proof. unfold Equation3678. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff410_inst, reff410_op in H. discriminate H. Qed.

Lemma reff410_not3684 : ~ @Equation3684 Fin3 reff410_inst.
Proof. unfold Equation3684. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff410_inst, reff410_op in H. discriminate H. Qed.

Lemma reff410_not3685 : ~ @Equation3685 Fin3 reff410_inst.
Proof. unfold Equation3685. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff410_inst, reff410_op in H. discriminate H. Qed.

Lemma reff410_not3687 : ~ @Equation3687 Fin3 reff410_inst.
Proof. unfold Equation3687. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff410_inst, reff410_op in H. discriminate H. Qed.

Lemma reff410_not3714 : ~ @Equation3714 Fin3 reff410_inst.
Proof. unfold Equation3714. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff410_inst, reff410_op in H. discriminate H. Qed.

Lemma reff410_not3721 : ~ @Equation3721 Fin3 reff410_inst.
Proof. unfold Equation3721. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff410_inst, reff410_op in H. discriminate H. Qed.

Lemma reff410_not3724 : ~ @Equation3724 Fin3 reff410_inst.
Proof. unfold Equation3724. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff410_inst, reff410_op in H. discriminate H. Qed.

Lemma reff410_not3725 : ~ @Equation3725 Fin3 reff410_inst.
Proof. unfold Equation3725. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff410_inst, reff410_op in H. discriminate H. Qed.

Lemma reff410_not3748 : ~ @Equation3748 Fin3 reff410_inst.
Proof. unfold Equation3748. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff410_inst, reff410_op in H. discriminate H. Qed.

Lemma reff410_not3749 : ~ @Equation3749 Fin3 reff410_inst.
Proof. unfold Equation3749. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff410_inst, reff410_op in H. discriminate H. Qed.

Lemma reff410_not3751 : ~ @Equation3751 Fin3 reff410_inst.
Proof. unfold Equation3751. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff410_inst, reff410_op in H. discriminate H. Qed.

Lemma reff410_not3752 : ~ @Equation3752 Fin3 reff410_inst.
Proof. unfold Equation3752. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff410_inst, reff410_op in H. discriminate H. Qed.

Lemma reff410_not3758 : ~ @Equation3758 Fin3 reff410_inst.
Proof. unfold Equation3758. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff410_inst, reff410_op in H. discriminate H. Qed.

Lemma reff410_not3759 : ~ @Equation3759 Fin3 reff410_inst.
Proof. unfold Equation3759. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff410_inst, reff410_op in H. discriminate H. Qed.

Lemma reff410_not3761 : ~ @Equation3761 Fin3 reff410_inst.
Proof. unfold Equation3761. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff410_inst, reff410_op in H. discriminate H. Qed.

Lemma reff410_not3864 : ~ @Equation3864 Fin3 reff410_inst.
Proof. unfold Equation3864. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff410_inst, reff410_op in H. discriminate H. Qed.

Lemma reff410_not3865 : ~ @Equation3865 Fin3 reff410_inst.
Proof. unfold Equation3865. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff410_inst, reff410_op in H. discriminate H. Qed.

Lemma reff410_not3867 : ~ @Equation3867 Fin3 reff410_inst.
Proof. unfold Equation3867. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff410_inst, reff410_op in H. discriminate H. Qed.

Lemma reff410_not3868 : ~ @Equation3868 Fin3 reff410_inst.
Proof. unfold Equation3868. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff410_inst, reff410_op in H. discriminate H. Qed.

Lemma reff410_not3870 : ~ @Equation3870 Fin3 reff410_inst.
Proof. unfold Equation3870. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff410_inst, reff410_op in H. discriminate H. Qed.

Lemma reff410_not3871 : ~ @Equation3871 Fin3 reff410_inst.
Proof. unfold Equation3871. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff410_inst, reff410_op in H. discriminate H. Qed.

Lemma reff410_not3878 : ~ @Equation3878 Fin3 reff410_inst.
Proof. unfold Equation3878. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff410_inst, reff410_op in H. discriminate H. Qed.

Lemma reff410_not3880 : ~ @Equation3880 Fin3 reff410_inst.
Proof. unfold Equation3880. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff410_inst, reff410_op in H. discriminate H. Qed.

Lemma reff410_not3881 : ~ @Equation3881 Fin3 reff410_inst.
Proof. unfold Equation3881. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff410_inst, reff410_op in H. discriminate H. Qed.

Lemma reff410_not3888 : ~ @Equation3888 Fin3 reff410_inst.
Proof. unfold Equation3888. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff410_inst, reff410_op in H. discriminate H. Qed.

Lemma reff410_not3890 : ~ @Equation3890 Fin3 reff410_inst.
Proof. unfold Equation3890. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff410_inst, reff410_op in H. discriminate H. Qed.

Lemma reff410_not3917 : ~ @Equation3917 Fin3 reff410_inst.
Proof. unfold Equation3917. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff410_inst, reff410_op in H. discriminate H. Qed.

Lemma reff410_not3918 : ~ @Equation3918 Fin3 reff410_inst.
Proof. unfold Equation3918. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff410_inst, reff410_op in H. discriminate H. Qed.

Lemma reff410_not3924 : ~ @Equation3924 Fin3 reff410_inst.
Proof. unfold Equation3924. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff410_inst, reff410_op in H. discriminate H. Qed.

Lemma reff410_not3927 : ~ @Equation3927 Fin3 reff410_inst.
Proof. unfold Equation3927. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff410_inst, reff410_op in H. discriminate H. Qed.

Lemma reff410_not3928 : ~ @Equation3928 Fin3 reff410_inst.
Proof. unfold Equation3928. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff410_inst, reff410_op in H. discriminate H. Qed.

Lemma reff410_not3951 : ~ @Equation3951 Fin3 reff410_inst.
Proof. unfold Equation3951. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff410_inst, reff410_op in H. discriminate H. Qed.

Lemma reff410_not3952 : ~ @Equation3952 Fin3 reff410_inst.
Proof. unfold Equation3952. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff410_inst, reff410_op in H. discriminate H. Qed.

Lemma reff410_not3954 : ~ @Equation3954 Fin3 reff410_inst.
Proof. unfold Equation3954. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff410_inst, reff410_op in H. discriminate H. Qed.

Lemma reff410_not3961 : ~ @Equation3961 Fin3 reff410_inst.
Proof. unfold Equation3961. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff410_inst, reff410_op in H. discriminate H. Qed.

Lemma reff410_not3962 : ~ @Equation3962 Fin3 reff410_inst.
Proof. unfold Equation3962. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff410_inst, reff410_op in H. discriminate H. Qed.

Lemma reff410_not3964 : ~ @Equation3964 Fin3 reff410_inst.
Proof. unfold Equation3964. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff410_inst, reff410_op in H. discriminate H. Qed.

Lemma reff410_not4066 : ~ @Equation4066 Fin3 reff410_inst.
Proof. unfold Equation4066. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff410_inst, reff410_op in H. discriminate H. Qed.

Lemma reff410_not4067 : ~ @Equation4067 Fin3 reff410_inst.
Proof. unfold Equation4067. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff410_inst, reff410_op in H. discriminate H. Qed.

Lemma reff410_not4068 : ~ @Equation4068 Fin3 reff410_inst.
Proof. unfold Equation4068. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff410_inst, reff410_op in H. discriminate H. Qed.

Lemma reff410_not4071 : ~ @Equation4071 Fin3 reff410_inst.
Proof. unfold Equation4071. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff410_inst, reff410_op in H. discriminate H. Qed.

Lemma reff410_not4073 : ~ @Equation4073 Fin3 reff410_inst.
Proof. unfold Equation4073. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff410_inst, reff410_op in H. discriminate H. Qed.

Lemma reff410_not4074 : ~ @Equation4074 Fin3 reff410_inst.
Proof. unfold Equation4074. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff410_inst, reff410_op in H. discriminate H. Qed.

Lemma reff410_not4081 : ~ @Equation4081 Fin3 reff410_inst.
Proof. unfold Equation4081. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff410_inst, reff410_op in H. discriminate H. Qed.

Lemma reff410_not4083 : ~ @Equation4083 Fin3 reff410_inst.
Proof. unfold Equation4083. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff410_inst, reff410_op in H. discriminate H. Qed.

Lemma reff410_not4084 : ~ @Equation4084 Fin3 reff410_inst.
Proof. unfold Equation4084. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff410_inst, reff410_op in H. discriminate H. Qed.

Lemma reff410_not4091 : ~ @Equation4091 Fin3 reff410_inst.
Proof. unfold Equation4091. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff410_inst, reff410_op in H. discriminate H. Qed.

Lemma reff410_not4093 : ~ @Equation4093 Fin3 reff410_inst.
Proof. unfold Equation4093. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff410_inst, reff410_op in H. discriminate H. Qed.

Lemma reff410_not4120 : ~ @Equation4120 Fin3 reff410_inst.
Proof. unfold Equation4120. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff410_inst, reff410_op in H. discriminate H. Qed.

Lemma reff410_not4121 : ~ @Equation4121 Fin3 reff410_inst.
Proof. unfold Equation4121. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff410_inst, reff410_op in H. discriminate H. Qed.

Lemma reff410_not4127 : ~ @Equation4127 Fin3 reff410_inst.
Proof. unfold Equation4127. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff410_inst, reff410_op in H. discriminate H. Qed.

Lemma reff410_not4128 : ~ @Equation4128 Fin3 reff410_inst.
Proof. unfold Equation4128. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff410_inst, reff410_op in H. discriminate H. Qed.

Lemma reff410_not4130 : ~ @Equation4130 Fin3 reff410_inst.
Proof. unfold Equation4130. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff410_inst, reff410_op in H. discriminate H. Qed.

Lemma reff410_not4131 : ~ @Equation4131 Fin3 reff410_inst.
Proof. unfold Equation4131. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff410_inst, reff410_op in H. discriminate H. Qed.

Lemma reff410_not4157 : ~ @Equation4157 Fin3 reff410_inst.
Proof. unfold Equation4157. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff410_inst, reff410_op in H. discriminate H. Qed.

Lemma reff410_not4158 : ~ @Equation4158 Fin3 reff410_inst.
Proof. unfold Equation4158. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff410_inst, reff410_op in H. discriminate H. Qed.

Lemma reff410_not4164 : ~ @Equation4164 Fin3 reff410_inst.
Proof. unfold Equation4164. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff410_inst, reff410_op in H. discriminate H. Qed.

Lemma reff410_not4165 : ~ @Equation4165 Fin3 reff410_inst.
Proof. unfold Equation4165. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff410_inst, reff410_op in H. discriminate H. Qed.

Lemma reff410_not4167 : ~ @Equation4167 Fin3 reff410_inst.
Proof. unfold Equation4167. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff410_inst, reff410_op in H. discriminate H. Qed.

Lemma reff410_not4268 : ~ @Equation4268 Fin3 reff410_inst.
Proof. unfold Equation4268. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff410_inst, reff410_op in H. discriminate H. Qed.

Lemma reff410_not4269 : ~ @Equation4269 Fin3 reff410_inst.
Proof. unfold Equation4269. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff410_inst, reff410_op in H. discriminate H. Qed.

Lemma reff410_not4270 : ~ @Equation4270 Fin3 reff410_inst.
Proof. unfold Equation4270. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff410_inst, reff410_op in H. discriminate H. Qed.

Lemma reff410_not4272 : ~ @Equation4272 Fin3 reff410_inst.
Proof. unfold Equation4272. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff410_inst, reff410_op in H. discriminate H. Qed.

Lemma reff410_not4273 : ~ @Equation4273 Fin3 reff410_inst.
Proof. unfold Equation4273. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff410_inst, reff410_op in H. discriminate H. Qed.

Lemma reff410_not4275 : ~ @Equation4275 Fin3 reff410_inst.
Proof. unfold Equation4275. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff410_inst, reff410_op in H. discriminate H. Qed.

Lemma reff410_not4276 : ~ @Equation4276 Fin3 reff410_inst.
Proof. unfold Equation4276. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff410_inst, reff410_op in H. discriminate H. Qed.

Lemma reff410_not4283 : ~ @Equation4283 Fin3 reff410_inst.
Proof. unfold Equation4283. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff410_inst, reff410_op in H. discriminate H. Qed.

Lemma reff410_not4290 : ~ @Equation4290 Fin3 reff410_inst.
Proof. unfold Equation4290. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff410_inst, reff410_op in H. discriminate H. Qed.

Lemma reff410_not4291 : ~ @Equation4291 Fin3 reff410_inst.
Proof. unfold Equation4291. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff410_inst, reff410_op in H. discriminate H. Qed.

Lemma reff410_not4293 : ~ @Equation4293 Fin3 reff410_inst.
Proof. unfold Equation4293. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff410_inst, reff410_op in H. discriminate H. Qed.

Lemma reff410_not4314 : ~ @Equation4314 Fin3 reff410_inst.
Proof. unfold Equation4314. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff410_inst, reff410_op in H. discriminate H. Qed.

Lemma reff410_not4320 : ~ @Equation4320 Fin3 reff410_inst.
Proof. unfold Equation4320. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff410_inst, reff410_op in H. discriminate H. Qed.

Lemma reff410_not4343 : ~ @Equation4343 Fin3 reff410_inst.
Proof. unfold Equation4343. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff410_inst, reff410_op in H. discriminate H. Qed.

Lemma reff410_not4398 : ~ @Equation4398 Fin3 reff410_inst.
Proof. unfold Equation4398. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff410_inst, reff410_op in H. discriminate H. Qed.

Lemma reff410_not4399 : ~ @Equation4399 Fin3 reff410_inst.
Proof. unfold Equation4399. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff410_inst, reff410_op in H. discriminate H. Qed.

Lemma reff410_not4405 : ~ @Equation4405 Fin3 reff410_inst.
Proof. unfold Equation4405. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff410_inst, reff410_op in H. discriminate H. Qed.

Lemma reff410_not4406 : ~ @Equation4406 Fin3 reff410_inst.
Proof. unfold Equation4406. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff410_inst, reff410_op in H. discriminate H. Qed.

Lemma reff410_not4408 : ~ @Equation4408 Fin3 reff410_inst.
Proof. unfold Equation4408. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff410_inst, reff410_op in H. discriminate H. Qed.

Lemma reff410_not4433 : ~ @Equation4433 Fin3 reff410_inst.
Proof. unfold Equation4433. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff410_inst, reff410_op in H. discriminate H. Qed.

Lemma reff410_not4435 : ~ @Equation4435 Fin3 reff410_inst.
Proof. unfold Equation4435. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff410_inst, reff410_op in H. discriminate H. Qed.

Lemma reff410_not4436 : ~ @Equation4436 Fin3 reff410_inst.
Proof. unfold Equation4436. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff410_inst, reff410_op in H. discriminate H. Qed.

Lemma reff410_not4442 : ~ @Equation4442 Fin3 reff410_inst.
Proof. unfold Equation4442. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff410_inst, reff410_op in H. discriminate H. Qed.

Lemma reff410_not4443 : ~ @Equation4443 Fin3 reff410_inst.
Proof. unfold Equation4443. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff410_inst, reff410_op in H. discriminate H. Qed.

Lemma reff410_not4445 : ~ @Equation4445 Fin3 reff410_inst.
Proof. unfold Equation4445. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff410_inst, reff410_op in H. discriminate H. Qed.

Lemma reff410_not4472 : ~ @Equation4472 Fin3 reff410_inst.
Proof. unfold Equation4472. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff410_inst, reff410_op in H. discriminate H. Qed.

Lemma reff410_not4473 : ~ @Equation4473 Fin3 reff410_inst.
Proof. unfold Equation4473. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff410_inst, reff410_op in H. discriminate H. Qed.

Lemma reff410_not4479 : ~ @Equation4479 Fin3 reff410_inst.
Proof. unfold Equation4479. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff410_inst, reff410_op in H. discriminate H. Qed.

Lemma reff410_not4480 : ~ @Equation4480 Fin3 reff410_inst.
Proof. unfold Equation4480. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff410_inst, reff410_op in H. discriminate H. Qed.

Lemma reff410_not4482 : ~ @Equation4482 Fin3 reff410_inst.
Proof. unfold Equation4482. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff410_inst, reff410_op in H. discriminate H. Qed.

Lemma reff410_not4583 : ~ @Equation4583 Fin3 reff410_inst.
Proof. unfold Equation4583. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff410_inst, reff410_op in H. discriminate H. Qed.

Lemma reff410_not4584 : ~ @Equation4584 Fin3 reff410_inst.
Proof. unfold Equation4584. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff410_inst, reff410_op in H. discriminate H. Qed.

Lemma reff410_not4585 : ~ @Equation4585 Fin3 reff410_inst.
Proof. unfold Equation4585. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff410_inst, reff410_op in H. discriminate H. Qed.

Lemma reff410_not4588 : ~ @Equation4588 Fin3 reff410_inst.
Proof. unfold Equation4588. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff410_inst, reff410_op in H. discriminate H. Qed.

Lemma reff410_not4590 : ~ @Equation4590 Fin3 reff410_inst.
Proof. unfold Equation4590. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff410_inst, reff410_op in H. discriminate H. Qed.

Lemma reff410_not4591 : ~ @Equation4591 Fin3 reff410_inst.
Proof. unfold Equation4591. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff410_inst, reff410_op in H. discriminate H. Qed.

Lemma reff410_not4598 : ~ @Equation4598 Fin3 reff410_inst.
Proof. unfold Equation4598. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff410_inst, reff410_op in H. discriminate H. Qed.

Lemma reff410_not4599 : ~ @Equation4599 Fin3 reff410_inst.
Proof. unfold Equation4599. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff410_inst, reff410_op in H. discriminate H. Qed.

Lemma reff410_not4605 : ~ @Equation4605 Fin3 reff410_inst.
Proof. unfold Equation4605. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff410_inst, reff410_op in H. discriminate H. Qed.

Lemma reff410_not4606 : ~ @Equation4606 Fin3 reff410_inst.
Proof. unfold Equation4606. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff410_inst, reff410_op in H. discriminate H. Qed.

Lemma reff410_not4608 : ~ @Equation4608 Fin3 reff410_inst.
Proof. unfold Equation4608. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff410_inst, reff410_op in H. discriminate H. Qed.

Lemma reff410_not4629 : ~ @Equation4629 Fin3 reff410_inst.
Proof. unfold Equation4629. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff410_inst, reff410_op in H. discriminate H. Qed.

Lemma reff410_not4635 : ~ @Equation4635 Fin3 reff410_inst.
Proof. unfold Equation4635. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff410_inst, reff410_op in H. discriminate H. Qed.

Lemma reff410_not4636 : ~ @Equation4636 Fin3 reff410_inst.
Proof. unfold Equation4636. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff410_inst, reff410_op in H. discriminate H. Qed.

Lemma reff410_not4658 : ~ @Equation4658 Fin3 reff410_inst.
Proof. unfold Equation4658. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff410_inst, reff410_op in H. discriminate H. Qed.

(** ---- reff418 (Fin4) ---- *)

Definition reff418_op (x y : Fin4) : Fin4 :=
  match x, y with
  | F4_0, F4_0 => F4_0 | F4_0, F4_1 => F4_3 | F4_0, F4_2 => F4_0 | F4_0, F4_3 => F4_3
  | F4_1, F4_0 => F4_1 | F4_1, F4_1 => F4_0 | F4_1, F4_2 => F4_1 | F4_1, F4_3 => F4_0
  | F4_2, F4_0 => F4_2 | F4_2, F4_1 => F4_1 | F4_2, F4_2 => F4_2 | F4_2, F4_3 => F4_1
  | F4_3, F4_0 => F4_3 | F4_3, F4_1 => F4_2 | F4_3, F4_2 => F4_3 | F4_3, F4_3 => F4_2
  end.

#[local] Instance reff418_inst : Magma Fin4 := {| magma_op := reff418_op |}.

Lemma reff418_sat11 : @Equation11 Fin4 reff418_inst.
Proof. unfold Equation11, magma_op, reff418_inst, reff418_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff418_sat452 : @Equation452 Fin4 reff418_inst.
Proof. unfold Equation452, magma_op, reff418_inst, reff418_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff418_sat455 : @Equation455 Fin4 reff418_inst.
Proof. unfold Equation455, magma_op, reff418_inst, reff418_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff418_sat647 : @Equation647 Fin4 reff418_inst.
Proof. unfold Equation647, magma_op, reff418_inst, reff418_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff418_sat655 : @Equation655 Fin4 reff418_inst.
Proof. unfold Equation655, magma_op, reff418_inst, reff418_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff418_sat658 : @Equation658 Fin4 reff418_inst.
Proof. unfold Equation658, magma_op, reff418_inst, reff418_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff418_sat861 : @Equation861 Fin4 reff418_inst.
Proof. unfold Equation861, magma_op, reff418_inst, reff418_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff418_sat1053 : @Equation1053 Fin4 reff418_inst.
Proof. unfold Equation1053, magma_op, reff418_inst, reff418_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff418_sat1061 : @Equation1061 Fin4 reff418_inst.
Proof. unfold Equation1061, magma_op, reff418_inst, reff418_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff418_sat1256 : @Equation1256 Fin4 reff418_inst.
Proof. unfold Equation1256, magma_op, reff418_inst, reff418_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff418_sat1264 : @Equation1264 Fin4 reff418_inst.
Proof. unfold Equation1264, magma_op, reff418_inst, reff418_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff418_sat1267 : @Equation1267 Fin4 reff418_inst.
Proof. unfold Equation1267, magma_op, reff418_inst, reff418_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff418_sat3079 : @Equation3079 Fin4 reff418_inst.
Proof. unfold Equation3079, magma_op, reff418_inst, reff418_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff418_sat3331 : @Equation3331 Fin4 reff418_inst.
Proof. unfold Equation3331, magma_op, reff418_inst, reff418_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff418_sat3334 : @Equation3334 Fin4 reff418_inst.
Proof. unfold Equation3334, magma_op, reff418_inst, reff418_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff418_sat3526 : @Equation3526 Fin4 reff418_inst.
Proof. unfold Equation3526, magma_op, reff418_inst, reff418_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff418_sat3537 : @Equation3537 Fin4 reff418_inst.
Proof. unfold Equation3537, magma_op, reff418_inst, reff418_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff418_sat4358 : @Equation4358 Fin4 reff418_inst.
Proof. unfold Equation4358, magma_op, reff418_inst, reff418_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff418_not47 : ~ @Equation47 Fin4 reff418_inst.
Proof. unfold Equation47. intro H. specialize (H F4_1). unfold magma_op, reff418_inst, reff418_op in H. discriminate H. Qed.

Lemma reff418_not99 : ~ @Equation99 Fin4 reff418_inst.
Proof. unfold Equation99. intro H. specialize (H F4_1). unfold magma_op, reff418_inst, reff418_op in H. discriminate H. Qed.

Lemma reff418_not151 : ~ @Equation151 Fin4 reff418_inst.
Proof. unfold Equation151. intro H. specialize (H F4_1). unfold magma_op, reff418_inst, reff418_op in H. discriminate H. Qed.

Lemma reff418_not203 : ~ @Equation203 Fin4 reff418_inst.
Proof. unfold Equation203. intro H. specialize (H F4_1). unfold magma_op, reff418_inst, reff418_op in H. discriminate H. Qed.

Lemma reff418_not255 : ~ @Equation255 Fin4 reff418_inst.
Proof. unfold Equation255. intro H. specialize (H F4_1). unfold magma_op, reff418_inst, reff418_op in H. discriminate H. Qed.

Lemma reff418_not307 : ~ @Equation307 Fin4 reff418_inst.
Proof. unfold Equation307. intro H. specialize (H F4_1). unfold magma_op, reff418_inst, reff418_op in H. discriminate H. Qed.

Lemma reff418_not412 : ~ @Equation412 Fin4 reff418_inst.
Proof. unfold Equation412. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff418_inst, reff418_op in H. discriminate H. Qed.

Lemma reff418_not413 : ~ @Equation413 Fin4 reff418_inst.
Proof. unfold Equation413. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff418_inst, reff418_op in H. discriminate H. Qed.

Lemma reff418_not416 : ~ @Equation416 Fin4 reff418_inst.
Proof. unfold Equation416. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff418_inst, reff418_op in H. discriminate H. Qed.

Lemma reff418_not420 : ~ @Equation420 Fin4 reff418_inst.
Proof. unfold Equation420. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff418_inst, reff418_op in H. discriminate H. Qed.

Lemma reff418_not426 : ~ @Equation426 Fin4 reff418_inst.
Proof. unfold Equation426. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff418_inst, reff418_op in H. discriminate H. Qed.

Lemma reff418_not430 : ~ @Equation430 Fin4 reff418_inst.
Proof. unfold Equation430. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff418_inst, reff418_op in H. discriminate H. Qed.

Lemma reff418_not437 : ~ @Equation437 Fin4 reff418_inst.
Proof. unfold Equation437. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff418_inst, reff418_op in H. discriminate H. Qed.

Lemma reff418_not439 : ~ @Equation439 Fin4 reff418_inst.
Proof. unfold Equation439. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff418_inst, reff418_op in H. discriminate H. Qed.

Lemma reff418_not463 : ~ @Equation463 Fin4 reff418_inst.
Proof. unfold Equation463. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff418_inst, reff418_op in H. discriminate H. Qed.

Lemma reff418_not464 : ~ @Equation464 Fin4 reff418_inst.
Proof. unfold Equation464. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff418_inst, reff418_op in H. discriminate H. Qed.

Lemma reff418_not466 : ~ @Equation466 Fin4 reff418_inst.
Proof. unfold Equation466. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff418_inst, reff418_op in H. discriminate H. Qed.

Lemma reff418_not467 : ~ @Equation467 Fin4 reff418_inst.
Proof. unfold Equation467. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff418_inst, reff418_op in H. discriminate H. Qed.

Lemma reff418_not473 : ~ @Equation473 Fin4 reff418_inst.
Proof. unfold Equation473. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff418_inst, reff418_op in H. discriminate H. Qed.

Lemma reff418_not474 : ~ @Equation474 Fin4 reff418_inst.
Proof. unfold Equation474. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff418_inst, reff418_op in H. discriminate H. Qed.

Lemma reff418_not476 : ~ @Equation476 Fin4 reff418_inst.
Proof. unfold Equation476. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff418_inst, reff418_op in H. discriminate H. Qed.

Lemma reff418_not477 : ~ @Equation477 Fin4 reff418_inst.
Proof. unfold Equation477. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff418_inst, reff418_op in H. discriminate H. Qed.

Lemma reff418_not500 : ~ @Equation500 Fin4 reff418_inst.
Proof. unfold Equation500. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff418_inst, reff418_op in H. discriminate H. Qed.

Lemma reff418_not501 : ~ @Equation501 Fin4 reff418_inst.
Proof. unfold Equation501. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff418_inst, reff418_op in H. discriminate H. Qed.

Lemma reff418_not503 : ~ @Equation503 Fin4 reff418_inst.
Proof. unfold Equation503. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff418_inst, reff418_op in H. discriminate H. Qed.

Lemma reff418_not504 : ~ @Equation504 Fin4 reff418_inst.
Proof. unfold Equation504. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff418_inst, reff418_op in H. discriminate H. Qed.

Lemma reff418_not510 : ~ @Equation510 Fin4 reff418_inst.
Proof. unfold Equation510. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff418_inst, reff418_op in H. discriminate H. Qed.

Lemma reff418_not511 : ~ @Equation511 Fin4 reff418_inst.
Proof. unfold Equation511. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff418_inst, reff418_op in H. discriminate H. Qed.

Lemma reff418_not513 : ~ @Equation513 Fin4 reff418_inst.
Proof. unfold Equation513. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff418_inst, reff418_op in H. discriminate H. Qed.

Lemma reff418_not615 : ~ @Equation615 Fin4 reff418_inst.
Proof. unfold Equation615. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff418_inst, reff418_op in H. discriminate H. Qed.

Lemma reff418_not616 : ~ @Equation616 Fin4 reff418_inst.
Proof. unfold Equation616. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff418_inst, reff418_op in H. discriminate H. Qed.

Lemma reff418_not619 : ~ @Equation619 Fin4 reff418_inst.
Proof. unfold Equation619. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff418_inst, reff418_op in H. discriminate H. Qed.

Lemma reff418_not623 : ~ @Equation623 Fin4 reff418_inst.
Proof. unfold Equation623. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff418_inst, reff418_op in H. discriminate H. Qed.

Lemma reff418_not629 : ~ @Equation629 Fin4 reff418_inst.
Proof. unfold Equation629. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff418_inst, reff418_op in H. discriminate H. Qed.

Lemma reff418_not633 : ~ @Equation633 Fin4 reff418_inst.
Proof. unfold Equation633. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff418_inst, reff418_op in H. discriminate H. Qed.

Lemma reff418_not640 : ~ @Equation640 Fin4 reff418_inst.
Proof. unfold Equation640. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff418_inst, reff418_op in H. discriminate H. Qed.

Lemma reff418_not642 : ~ @Equation642 Fin4 reff418_inst.
Proof. unfold Equation642. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff418_inst, reff418_op in H. discriminate H. Qed.

Lemma reff418_not666 : ~ @Equation666 Fin4 reff418_inst.
Proof. unfold Equation666. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff418_inst, reff418_op in H. discriminate H. Qed.

Lemma reff418_not667 : ~ @Equation667 Fin4 reff418_inst.
Proof. unfold Equation667. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff418_inst, reff418_op in H. discriminate H. Qed.

Lemma reff418_not669 : ~ @Equation669 Fin4 reff418_inst.
Proof. unfold Equation669. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff418_inst, reff418_op in H. discriminate H. Qed.

Lemma reff418_not670 : ~ @Equation670 Fin4 reff418_inst.
Proof. unfold Equation670. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff418_inst, reff418_op in H. discriminate H. Qed.

Lemma reff418_not676 : ~ @Equation676 Fin4 reff418_inst.
Proof. unfold Equation676. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff418_inst, reff418_op in H. discriminate H. Qed.

Lemma reff418_not677 : ~ @Equation677 Fin4 reff418_inst.
Proof. unfold Equation677. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff418_inst, reff418_op in H. discriminate H. Qed.

Lemma reff418_not679 : ~ @Equation679 Fin4 reff418_inst.
Proof. unfold Equation679. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff418_inst, reff418_op in H. discriminate H. Qed.

Lemma reff418_not680 : ~ @Equation680 Fin4 reff418_inst.
Proof. unfold Equation680. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff418_inst, reff418_op in H. discriminate H. Qed.

Lemma reff418_not703 : ~ @Equation703 Fin4 reff418_inst.
Proof. unfold Equation703. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff418_inst, reff418_op in H. discriminate H. Qed.

Lemma reff418_not704 : ~ @Equation704 Fin4 reff418_inst.
Proof. unfold Equation704. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff418_inst, reff418_op in H. discriminate H. Qed.

Lemma reff418_not706 : ~ @Equation706 Fin4 reff418_inst.
Proof. unfold Equation706. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff418_inst, reff418_op in H. discriminate H. Qed.

Lemma reff418_not707 : ~ @Equation707 Fin4 reff418_inst.
Proof. unfold Equation707. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff418_inst, reff418_op in H. discriminate H. Qed.

Lemma reff418_not713 : ~ @Equation713 Fin4 reff418_inst.
Proof. unfold Equation713. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff418_inst, reff418_op in H. discriminate H. Qed.

Lemma reff418_not714 : ~ @Equation714 Fin4 reff418_inst.
Proof. unfold Equation714. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff418_inst, reff418_op in H. discriminate H. Qed.

Lemma reff418_not716 : ~ @Equation716 Fin4 reff418_inst.
Proof. unfold Equation716. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff418_inst, reff418_op in H. discriminate H. Qed.

Lemma reff418_not818 : ~ @Equation818 Fin4 reff418_inst.
Proof. unfold Equation818. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff418_inst, reff418_op in H. discriminate H. Qed.

Lemma reff418_not819 : ~ @Equation819 Fin4 reff418_inst.
Proof. unfold Equation819. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff418_inst, reff418_op in H. discriminate H. Qed.

Lemma reff418_not822 : ~ @Equation822 Fin4 reff418_inst.
Proof. unfold Equation822. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff418_inst, reff418_op in H. discriminate H. Qed.

Lemma reff418_not826 : ~ @Equation826 Fin4 reff418_inst.
Proof. unfold Equation826. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff418_inst, reff418_op in H. discriminate H. Qed.

Lemma reff418_not832 : ~ @Equation832 Fin4 reff418_inst.
Proof. unfold Equation832. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff418_inst, reff418_op in H. discriminate H. Qed.

Lemma reff418_not836 : ~ @Equation836 Fin4 reff418_inst.
Proof. unfold Equation836. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff418_inst, reff418_op in H. discriminate H. Qed.

Lemma reff418_not843 : ~ @Equation843 Fin4 reff418_inst.
Proof. unfold Equation843. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff418_inst, reff418_op in H. discriminate H. Qed.

Lemma reff418_not845 : ~ @Equation845 Fin4 reff418_inst.
Proof. unfold Equation845. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff418_inst, reff418_op in H. discriminate H. Qed.

Lemma reff418_not869 : ~ @Equation869 Fin4 reff418_inst.
Proof. unfold Equation869. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff418_inst, reff418_op in H. discriminate H. Qed.

Lemma reff418_not870 : ~ @Equation870 Fin4 reff418_inst.
Proof. unfold Equation870. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff418_inst, reff418_op in H. discriminate H. Qed.

Lemma reff418_not872 : ~ @Equation872 Fin4 reff418_inst.
Proof. unfold Equation872. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff418_inst, reff418_op in H. discriminate H. Qed.

Lemma reff418_not873 : ~ @Equation873 Fin4 reff418_inst.
Proof. unfold Equation873. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff418_inst, reff418_op in H. discriminate H. Qed.

Lemma reff418_not879 : ~ @Equation879 Fin4 reff418_inst.
Proof. unfold Equation879. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff418_inst, reff418_op in H. discriminate H. Qed.

Lemma reff418_not880 : ~ @Equation880 Fin4 reff418_inst.
Proof. unfold Equation880. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff418_inst, reff418_op in H. discriminate H. Qed.

Lemma reff418_not882 : ~ @Equation882 Fin4 reff418_inst.
Proof. unfold Equation882. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff418_inst, reff418_op in H. discriminate H. Qed.

Lemma reff418_not883 : ~ @Equation883 Fin4 reff418_inst.
Proof. unfold Equation883. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff418_inst, reff418_op in H. discriminate H. Qed.

Lemma reff418_not906 : ~ @Equation906 Fin4 reff418_inst.
Proof. unfold Equation906. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff418_inst, reff418_op in H. discriminate H. Qed.

Lemma reff418_not907 : ~ @Equation907 Fin4 reff418_inst.
Proof. unfold Equation907. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff418_inst, reff418_op in H. discriminate H. Qed.

Lemma reff418_not909 : ~ @Equation909 Fin4 reff418_inst.
Proof. unfold Equation909. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff418_inst, reff418_op in H. discriminate H. Qed.

Lemma reff418_not910 : ~ @Equation910 Fin4 reff418_inst.
Proof. unfold Equation910. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff418_inst, reff418_op in H. discriminate H. Qed.

Lemma reff418_not916 : ~ @Equation916 Fin4 reff418_inst.
Proof. unfold Equation916. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff418_inst, reff418_op in H. discriminate H. Qed.

Lemma reff418_not917 : ~ @Equation917 Fin4 reff418_inst.
Proof. unfold Equation917. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff418_inst, reff418_op in H. discriminate H. Qed.

Lemma reff418_not919 : ~ @Equation919 Fin4 reff418_inst.
Proof. unfold Equation919. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff418_inst, reff418_op in H. discriminate H. Qed.

Lemma reff418_not1021 : ~ @Equation1021 Fin4 reff418_inst.
Proof. unfold Equation1021. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff418_inst, reff418_op in H. discriminate H. Qed.

Lemma reff418_not1022 : ~ @Equation1022 Fin4 reff418_inst.
Proof. unfold Equation1022. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff418_inst, reff418_op in H. discriminate H. Qed.

Lemma reff418_not1025 : ~ @Equation1025 Fin4 reff418_inst.
Proof. unfold Equation1025. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff418_inst, reff418_op in H. discriminate H. Qed.

Lemma reff418_not1029 : ~ @Equation1029 Fin4 reff418_inst.
Proof. unfold Equation1029. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff418_inst, reff418_op in H. discriminate H. Qed.

Lemma reff418_not1035 : ~ @Equation1035 Fin4 reff418_inst.
Proof. unfold Equation1035. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff418_inst, reff418_op in H. discriminate H. Qed.

Lemma reff418_not1039 : ~ @Equation1039 Fin4 reff418_inst.
Proof. unfold Equation1039. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff418_inst, reff418_op in H. discriminate H. Qed.

Lemma reff418_not1046 : ~ @Equation1046 Fin4 reff418_inst.
Proof. unfold Equation1046. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff418_inst, reff418_op in H. discriminate H. Qed.

Lemma reff418_not1048 : ~ @Equation1048 Fin4 reff418_inst.
Proof. unfold Equation1048. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff418_inst, reff418_op in H. discriminate H. Qed.

Lemma reff418_not1072 : ~ @Equation1072 Fin4 reff418_inst.
Proof. unfold Equation1072. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff418_inst, reff418_op in H. discriminate H. Qed.

Lemma reff418_not1073 : ~ @Equation1073 Fin4 reff418_inst.
Proof. unfold Equation1073. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff418_inst, reff418_op in H. discriminate H. Qed.

Lemma reff418_not1075 : ~ @Equation1075 Fin4 reff418_inst.
Proof. unfold Equation1075. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff418_inst, reff418_op in H. discriminate H. Qed.

Lemma reff418_not1076 : ~ @Equation1076 Fin4 reff418_inst.
Proof. unfold Equation1076. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff418_inst, reff418_op in H. discriminate H. Qed.

Lemma reff418_not1082 : ~ @Equation1082 Fin4 reff418_inst.
Proof. unfold Equation1082. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff418_inst, reff418_op in H. discriminate H. Qed.

Lemma reff418_not1083 : ~ @Equation1083 Fin4 reff418_inst.
Proof. unfold Equation1083. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff418_inst, reff418_op in H. discriminate H. Qed.

Lemma reff418_not1085 : ~ @Equation1085 Fin4 reff418_inst.
Proof. unfold Equation1085. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff418_inst, reff418_op in H. discriminate H. Qed.

Lemma reff418_not1086 : ~ @Equation1086 Fin4 reff418_inst.
Proof. unfold Equation1086. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff418_inst, reff418_op in H. discriminate H. Qed.

Lemma reff418_not1109 : ~ @Equation1109 Fin4 reff418_inst.
Proof. unfold Equation1109. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff418_inst, reff418_op in H. discriminate H. Qed.

Lemma reff418_not1110 : ~ @Equation1110 Fin4 reff418_inst.
Proof. unfold Equation1110. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff418_inst, reff418_op in H. discriminate H. Qed.

Lemma reff418_not1112 : ~ @Equation1112 Fin4 reff418_inst.
Proof. unfold Equation1112. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff418_inst, reff418_op in H. discriminate H. Qed.

Lemma reff418_not1113 : ~ @Equation1113 Fin4 reff418_inst.
Proof. unfold Equation1113. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff418_inst, reff418_op in H. discriminate H. Qed.

Lemma reff418_not1119 : ~ @Equation1119 Fin4 reff418_inst.
Proof. unfold Equation1119. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff418_inst, reff418_op in H. discriminate H. Qed.

Lemma reff418_not1120 : ~ @Equation1120 Fin4 reff418_inst.
Proof. unfold Equation1120. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff418_inst, reff418_op in H. discriminate H. Qed.

Lemma reff418_not1122 : ~ @Equation1122 Fin4 reff418_inst.
Proof. unfold Equation1122. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff418_inst, reff418_op in H. discriminate H. Qed.

Lemma reff418_not1224 : ~ @Equation1224 Fin4 reff418_inst.
Proof. unfold Equation1224. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff418_inst, reff418_op in H. discriminate H. Qed.

Lemma reff418_not1225 : ~ @Equation1225 Fin4 reff418_inst.
Proof. unfold Equation1225. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff418_inst, reff418_op in H. discriminate H. Qed.

Lemma reff418_not1228 : ~ @Equation1228 Fin4 reff418_inst.
Proof. unfold Equation1228. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff418_inst, reff418_op in H. discriminate H. Qed.

Lemma reff418_not1232 : ~ @Equation1232 Fin4 reff418_inst.
Proof. unfold Equation1232. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff418_inst, reff418_op in H. discriminate H. Qed.

Lemma reff418_not1238 : ~ @Equation1238 Fin4 reff418_inst.
Proof. unfold Equation1238. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff418_inst, reff418_op in H. discriminate H. Qed.

Lemma reff418_not1242 : ~ @Equation1242 Fin4 reff418_inst.
Proof. unfold Equation1242. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff418_inst, reff418_op in H. discriminate H. Qed.

Lemma reff418_not1249 : ~ @Equation1249 Fin4 reff418_inst.
Proof. unfold Equation1249. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff418_inst, reff418_op in H. discriminate H. Qed.

Lemma reff418_not1251 : ~ @Equation1251 Fin4 reff418_inst.
Proof. unfold Equation1251. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff418_inst, reff418_op in H. discriminate H. Qed.

Lemma reff418_not1275 : ~ @Equation1275 Fin4 reff418_inst.
Proof. unfold Equation1275. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff418_inst, reff418_op in H. discriminate H. Qed.

Lemma reff418_not1276 : ~ @Equation1276 Fin4 reff418_inst.
Proof. unfold Equation1276. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff418_inst, reff418_op in H. discriminate H. Qed.

Lemma reff418_not1278 : ~ @Equation1278 Fin4 reff418_inst.
Proof. unfold Equation1278. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff418_inst, reff418_op in H. discriminate H. Qed.

Lemma reff418_not1279 : ~ @Equation1279 Fin4 reff418_inst.
Proof. unfold Equation1279. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff418_inst, reff418_op in H. discriminate H. Qed.

Lemma reff418_not1285 : ~ @Equation1285 Fin4 reff418_inst.
Proof. unfold Equation1285. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff418_inst, reff418_op in H. discriminate H. Qed.

Lemma reff418_not1286 : ~ @Equation1286 Fin4 reff418_inst.
Proof. unfold Equation1286. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff418_inst, reff418_op in H. discriminate H. Qed.

Lemma reff418_not1288 : ~ @Equation1288 Fin4 reff418_inst.
Proof. unfold Equation1288. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff418_inst, reff418_op in H. discriminate H. Qed.

Lemma reff418_not1289 : ~ @Equation1289 Fin4 reff418_inst.
Proof. unfold Equation1289. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff418_inst, reff418_op in H. discriminate H. Qed.

Lemma reff418_not1312 : ~ @Equation1312 Fin4 reff418_inst.
Proof. unfold Equation1312. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff418_inst, reff418_op in H. discriminate H. Qed.

Lemma reff418_not1313 : ~ @Equation1313 Fin4 reff418_inst.
Proof. unfold Equation1313. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff418_inst, reff418_op in H. discriminate H. Qed.

Lemma reff418_not1315 : ~ @Equation1315 Fin4 reff418_inst.
Proof. unfold Equation1315. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff418_inst, reff418_op in H. discriminate H. Qed.

Lemma reff418_not1316 : ~ @Equation1316 Fin4 reff418_inst.
Proof. unfold Equation1316. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff418_inst, reff418_op in H. discriminate H. Qed.

Lemma reff418_not1322 : ~ @Equation1322 Fin4 reff418_inst.
Proof. unfold Equation1322. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff418_inst, reff418_op in H. discriminate H. Qed.

Lemma reff418_not1323 : ~ @Equation1323 Fin4 reff418_inst.
Proof. unfold Equation1323. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff418_inst, reff418_op in H. discriminate H. Qed.

Lemma reff418_not1325 : ~ @Equation1325 Fin4 reff418_inst.
Proof. unfold Equation1325. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff418_inst, reff418_op in H. discriminate H. Qed.

Lemma reff418_not1426 : ~ @Equation1426 Fin4 reff418_inst.
Proof. unfold Equation1426. intro H. specialize (H F4_1). unfold magma_op, reff418_inst, reff418_op in H. discriminate H. Qed.

Lemma reff418_not1629 : ~ @Equation1629 Fin4 reff418_inst.
Proof. unfold Equation1629. intro H. specialize (H F4_1). unfold magma_op, reff418_inst, reff418_op in H. discriminate H. Qed.

Lemma reff418_not1833 : ~ @Equation1833 Fin4 reff418_inst.
Proof. unfold Equation1833. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff418_inst, reff418_op in H. discriminate H. Qed.

Lemma reff418_not1834 : ~ @Equation1834 Fin4 reff418_inst.
Proof. unfold Equation1834. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff418_inst, reff418_op in H. discriminate H. Qed.

Lemma reff418_not1837 : ~ @Equation1837 Fin4 reff418_inst.
Proof. unfold Equation1837. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff418_inst, reff418_op in H. discriminate H. Qed.

Lemma reff418_not1838 : ~ @Equation1838 Fin4 reff418_inst.
Proof. unfold Equation1838. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff418_inst, reff418_op in H. discriminate H. Qed.

Lemma reff418_not1840 : ~ @Equation1840 Fin4 reff418_inst.
Proof. unfold Equation1840. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff418_inst, reff418_op in H. discriminate H. Qed.

Lemma reff418_not1841 : ~ @Equation1841 Fin4 reff418_inst.
Proof. unfold Equation1841. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff418_inst, reff418_op in H. discriminate H. Qed.

Lemma reff418_not1847 : ~ @Equation1847 Fin4 reff418_inst.
Proof. unfold Equation1847. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff418_inst, reff418_op in H. discriminate H. Qed.

Lemma reff418_not1848 : ~ @Equation1848 Fin4 reff418_inst.
Proof. unfold Equation1848. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff418_inst, reff418_op in H. discriminate H. Qed.

Lemma reff418_not1850 : ~ @Equation1850 Fin4 reff418_inst.
Proof. unfold Equation1850. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff418_inst, reff418_op in H. discriminate H. Qed.

Lemma reff418_not1851 : ~ @Equation1851 Fin4 reff418_inst.
Proof. unfold Equation1851. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff418_inst, reff418_op in H. discriminate H. Qed.

Lemma reff418_not1858 : ~ @Equation1858 Fin4 reff418_inst.
Proof. unfold Equation1858. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff418_inst, reff418_op in H. discriminate H. Qed.

Lemma reff418_not1860 : ~ @Equation1860 Fin4 reff418_inst.
Proof. unfold Equation1860. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff418_inst, reff418_op in H. discriminate H. Qed.

Lemma reff418_not1884 : ~ @Equation1884 Fin4 reff418_inst.
Proof. unfold Equation1884. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff418_inst, reff418_op in H. discriminate H. Qed.

Lemma reff418_not1885 : ~ @Equation1885 Fin4 reff418_inst.
Proof. unfold Equation1885. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff418_inst, reff418_op in H. discriminate H. Qed.

Lemma reff418_not1887 : ~ @Equation1887 Fin4 reff418_inst.
Proof. unfold Equation1887. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff418_inst, reff418_op in H. discriminate H. Qed.

Lemma reff418_not1888 : ~ @Equation1888 Fin4 reff418_inst.
Proof. unfold Equation1888. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff418_inst, reff418_op in H. discriminate H. Qed.

Lemma reff418_not1894 : ~ @Equation1894 Fin4 reff418_inst.
Proof. unfold Equation1894. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff418_inst, reff418_op in H. discriminate H. Qed.

Lemma reff418_not1895 : ~ @Equation1895 Fin4 reff418_inst.
Proof. unfold Equation1895. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff418_inst, reff418_op in H. discriminate H. Qed.

Lemma reff418_not1897 : ~ @Equation1897 Fin4 reff418_inst.
Proof. unfold Equation1897. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff418_inst, reff418_op in H. discriminate H. Qed.

Lemma reff418_not1898 : ~ @Equation1898 Fin4 reff418_inst.
Proof. unfold Equation1898. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff418_inst, reff418_op in H. discriminate H. Qed.

Lemma reff418_not1921 : ~ @Equation1921 Fin4 reff418_inst.
Proof. unfold Equation1921. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff418_inst, reff418_op in H. discriminate H. Qed.

Lemma reff418_not1922 : ~ @Equation1922 Fin4 reff418_inst.
Proof. unfold Equation1922. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff418_inst, reff418_op in H. discriminate H. Qed.

Lemma reff418_not1924 : ~ @Equation1924 Fin4 reff418_inst.
Proof. unfold Equation1924. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff418_inst, reff418_op in H. discriminate H. Qed.

Lemma reff418_not1925 : ~ @Equation1925 Fin4 reff418_inst.
Proof. unfold Equation1925. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff418_inst, reff418_op in H. discriminate H. Qed.

Lemma reff418_not1931 : ~ @Equation1931 Fin4 reff418_inst.
Proof. unfold Equation1931. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff418_inst, reff418_op in H. discriminate H. Qed.

Lemma reff418_not1932 : ~ @Equation1932 Fin4 reff418_inst.
Proof. unfold Equation1932. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff418_inst, reff418_op in H. discriminate H. Qed.

Lemma reff418_not1934 : ~ @Equation1934 Fin4 reff418_inst.
Proof. unfold Equation1934. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff418_inst, reff418_op in H. discriminate H. Qed.

Lemma reff418_not2035 : ~ @Equation2035 Fin4 reff418_inst.
Proof. unfold Equation2035. intro H. specialize (H F4_1). unfold magma_op, reff418_inst, reff418_op in H. discriminate H. Qed.

Lemma reff418_not2238 : ~ @Equation2238 Fin4 reff418_inst.
Proof. unfold Equation2238. intro H. specialize (H F4_1). unfold magma_op, reff418_inst, reff418_op in H. discriminate H. Qed.

Lemma reff418_not2441 : ~ @Equation2441 Fin4 reff418_inst.
Proof. unfold Equation2441. intro H. specialize (H F4_1). unfold magma_op, reff418_inst, reff418_op in H. discriminate H. Qed.

Lemma reff418_not2644 : ~ @Equation2644 Fin4 reff418_inst.
Proof. unfold Equation2644. intro H. specialize (H F4_1). unfold magma_op, reff418_inst, reff418_op in H. discriminate H. Qed.

Lemma reff418_not2847 : ~ @Equation2847 Fin4 reff418_inst.
Proof. unfold Equation2847. intro H. specialize (H F4_1). unfold magma_op, reff418_inst, reff418_op in H. discriminate H. Qed.

Lemma reff418_not3051 : ~ @Equation3051 Fin4 reff418_inst.
Proof. unfold Equation3051. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff418_inst, reff418_op in H. discriminate H. Qed.

Lemma reff418_not3052 : ~ @Equation3052 Fin4 reff418_inst.
Proof. unfold Equation3052. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff418_inst, reff418_op in H. discriminate H. Qed.

Lemma reff418_not3053 : ~ @Equation3053 Fin4 reff418_inst.
Proof. unfold Equation3053. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff418_inst, reff418_op in H. discriminate H. Qed.

Lemma reff418_not3055 : ~ @Equation3055 Fin4 reff418_inst.
Proof. unfold Equation3055. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff418_inst, reff418_op in H. discriminate H. Qed.

Lemma reff418_not3056 : ~ @Equation3056 Fin4 reff418_inst.
Proof. unfold Equation3056. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff418_inst, reff418_op in H. discriminate H. Qed.

Lemma reff418_not3058 : ~ @Equation3058 Fin4 reff418_inst.
Proof. unfold Equation3058. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff418_inst, reff418_op in H. discriminate H. Qed.

Lemma reff418_not3059 : ~ @Equation3059 Fin4 reff418_inst.
Proof. unfold Equation3059. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff418_inst, reff418_op in H. discriminate H. Qed.

Lemma reff418_not3065 : ~ @Equation3065 Fin4 reff418_inst.
Proof. unfold Equation3065. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff418_inst, reff418_op in H. discriminate H. Qed.

Lemma reff418_not3066 : ~ @Equation3066 Fin4 reff418_inst.
Proof. unfold Equation3066. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff418_inst, reff418_op in H. discriminate H. Qed.

Lemma reff418_not3068 : ~ @Equation3068 Fin4 reff418_inst.
Proof. unfold Equation3068. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff418_inst, reff418_op in H. discriminate H. Qed.

Lemma reff418_not3069 : ~ @Equation3069 Fin4 reff418_inst.
Proof. unfold Equation3069. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff418_inst, reff418_op in H. discriminate H. Qed.

Lemma reff418_not3075 : ~ @Equation3075 Fin4 reff418_inst.
Proof. unfold Equation3075. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff418_inst, reff418_op in H. discriminate H. Qed.

Lemma reff418_not3076 : ~ @Equation3076 Fin4 reff418_inst.
Proof. unfold Equation3076. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff418_inst, reff418_op in H. discriminate H. Qed.

Lemma reff418_not3078 : ~ @Equation3078 Fin4 reff418_inst.
Proof. unfold Equation3078. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff418_inst, reff418_op in H. discriminate H. Qed.

Lemma reff418_not3102 : ~ @Equation3102 Fin4 reff418_inst.
Proof. unfold Equation3102. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff418_inst, reff418_op in H. discriminate H. Qed.

Lemma reff418_not3103 : ~ @Equation3103 Fin4 reff418_inst.
Proof. unfold Equation3103. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff418_inst, reff418_op in H. discriminate H. Qed.

Lemma reff418_not3105 : ~ @Equation3105 Fin4 reff418_inst.
Proof. unfold Equation3105. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff418_inst, reff418_op in H. discriminate H. Qed.

Lemma reff418_not3106 : ~ @Equation3106 Fin4 reff418_inst.
Proof. unfold Equation3106. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff418_inst, reff418_op in H. discriminate H. Qed.

Lemma reff418_not3112 : ~ @Equation3112 Fin4 reff418_inst.
Proof. unfold Equation3112. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff418_inst, reff418_op in H. discriminate H. Qed.

Lemma reff418_not3113 : ~ @Equation3113 Fin4 reff418_inst.
Proof. unfold Equation3113. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff418_inst, reff418_op in H. discriminate H. Qed.

Lemma reff418_not3115 : ~ @Equation3115 Fin4 reff418_inst.
Proof. unfold Equation3115. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff418_inst, reff418_op in H. discriminate H. Qed.

Lemma reff418_not3116 : ~ @Equation3116 Fin4 reff418_inst.
Proof. unfold Equation3116. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff418_inst, reff418_op in H. discriminate H. Qed.

Lemma reff418_not3139 : ~ @Equation3139 Fin4 reff418_inst.
Proof. unfold Equation3139. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff418_inst, reff418_op in H. discriminate H. Qed.

Lemma reff418_not3140 : ~ @Equation3140 Fin4 reff418_inst.
Proof. unfold Equation3140. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff418_inst, reff418_op in H. discriminate H. Qed.

Lemma reff418_not3142 : ~ @Equation3142 Fin4 reff418_inst.
Proof. unfold Equation3142. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff418_inst, reff418_op in H. discriminate H. Qed.

Lemma reff418_not3143 : ~ @Equation3143 Fin4 reff418_inst.
Proof. unfold Equation3143. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff418_inst, reff418_op in H. discriminate H. Qed.

Lemma reff418_not3149 : ~ @Equation3149 Fin4 reff418_inst.
Proof. unfold Equation3149. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff418_inst, reff418_op in H. discriminate H. Qed.

Lemma reff418_not3150 : ~ @Equation3150 Fin4 reff418_inst.
Proof. unfold Equation3150. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff418_inst, reff418_op in H. discriminate H. Qed.

Lemma reff418_not3152 : ~ @Equation3152 Fin4 reff418_inst.
Proof. unfold Equation3152. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff418_inst, reff418_op in H. discriminate H. Qed.

Lemma reff418_not3254 : ~ @Equation3254 Fin4 reff418_inst.
Proof. unfold Equation3254. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff418_inst, reff418_op in H. discriminate H. Qed.

Lemma reff418_not3255 : ~ @Equation3255 Fin4 reff418_inst.
Proof. unfold Equation3255. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff418_inst, reff418_op in H. discriminate H. Qed.

Lemma reff418_not3258 : ~ @Equation3258 Fin4 reff418_inst.
Proof. unfold Equation3258. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff418_inst, reff418_op in H. discriminate H. Qed.

Lemma reff418_not3262 : ~ @Equation3262 Fin4 reff418_inst.
Proof. unfold Equation3262. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff418_inst, reff418_op in H. discriminate H. Qed.

Lemma reff418_not3268 : ~ @Equation3268 Fin4 reff418_inst.
Proof. unfold Equation3268. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff418_inst, reff418_op in H. discriminate H. Qed.

Lemma reff418_not3269 : ~ @Equation3269 Fin4 reff418_inst.
Proof. unfold Equation3269. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff418_inst, reff418_op in H. discriminate H. Qed.

Lemma reff418_not3271 : ~ @Equation3271 Fin4 reff418_inst.
Proof. unfold Equation3271. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff418_inst, reff418_op in H. discriminate H. Qed.

Lemma reff418_not3272 : ~ @Equation3272 Fin4 reff418_inst.
Proof. unfold Equation3272. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff418_inst, reff418_op in H. discriminate H. Qed.

Lemma reff418_not3278 : ~ @Equation3278 Fin4 reff418_inst.
Proof. unfold Equation3278. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff418_inst, reff418_op in H. discriminate H. Qed.

Lemma reff418_not3279 : ~ @Equation3279 Fin4 reff418_inst.
Proof. unfold Equation3279. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff418_inst, reff418_op in H. discriminate H. Qed.

Lemma reff418_not3281 : ~ @Equation3281 Fin4 reff418_inst.
Proof. unfold Equation3281. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff418_inst, reff418_op in H. discriminate H. Qed.

Lemma reff418_not3309 : ~ @Equation3309 Fin4 reff418_inst.
Proof. unfold Equation3309. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff418_inst, reff418_op in H. discriminate H. Qed.

Lemma reff418_not3316 : ~ @Equation3316 Fin4 reff418_inst.
Proof. unfold Equation3316. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff418_inst, reff418_op in H. discriminate H. Qed.

Lemma reff418_not3318 : ~ @Equation3318 Fin4 reff418_inst.
Proof. unfold Equation3318. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff418_inst, reff418_op in H. discriminate H. Qed.

Lemma reff418_not3342 : ~ @Equation3342 Fin4 reff418_inst.
Proof. unfold Equation3342. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff418_inst, reff418_op in H. discriminate H. Qed.

Lemma reff418_not3343 : ~ @Equation3343 Fin4 reff418_inst.
Proof. unfold Equation3343. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff418_inst, reff418_op in H. discriminate H. Qed.

Lemma reff418_not3345 : ~ @Equation3345 Fin4 reff418_inst.
Proof. unfold Equation3345. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff418_inst, reff418_op in H. discriminate H. Qed.

Lemma reff418_not3346 : ~ @Equation3346 Fin4 reff418_inst.
Proof. unfold Equation3346. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff418_inst, reff418_op in H. discriminate H. Qed.

Lemma reff418_not3352 : ~ @Equation3352 Fin4 reff418_inst.
Proof. unfold Equation3352. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff418_inst, reff418_op in H. discriminate H. Qed.

Lemma reff418_not3353 : ~ @Equation3353 Fin4 reff418_inst.
Proof. unfold Equation3353. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff418_inst, reff418_op in H. discriminate H. Qed.

Lemma reff418_not3457 : ~ @Equation3457 Fin4 reff418_inst.
Proof. unfold Equation3457. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff418_inst, reff418_op in H. discriminate H. Qed.

Lemma reff418_not3458 : ~ @Equation3458 Fin4 reff418_inst.
Proof. unfold Equation3458. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff418_inst, reff418_op in H. discriminate H. Qed.

Lemma reff418_not3461 : ~ @Equation3461 Fin4 reff418_inst.
Proof. unfold Equation3461. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff418_inst, reff418_op in H. discriminate H. Qed.

Lemma reff418_not3465 : ~ @Equation3465 Fin4 reff418_inst.
Proof. unfold Equation3465. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff418_inst, reff418_op in H. discriminate H. Qed.

Lemma reff418_not3472 : ~ @Equation3472 Fin4 reff418_inst.
Proof. unfold Equation3472. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff418_inst, reff418_op in H. discriminate H. Qed.

Lemma reff418_not3474 : ~ @Equation3474 Fin4 reff418_inst.
Proof. unfold Equation3474. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff418_inst, reff418_op in H. discriminate H. Qed.

Lemma reff418_not3475 : ~ @Equation3475 Fin4 reff418_inst.
Proof. unfold Equation3475. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff418_inst, reff418_op in H. discriminate H. Qed.

Lemma reff418_not3481 : ~ @Equation3481 Fin4 reff418_inst.
Proof. unfold Equation3481. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff418_inst, reff418_op in H. discriminate H. Qed.

Lemma reff418_not3482 : ~ @Equation3482 Fin4 reff418_inst.
Proof. unfold Equation3482. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff418_inst, reff418_op in H. discriminate H. Qed.

Lemma reff418_not3484 : ~ @Equation3484 Fin4 reff418_inst.
Proof. unfold Equation3484. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff418_inst, reff418_op in H. discriminate H. Qed.

Lemma reff418_not3512 : ~ @Equation3512 Fin4 reff418_inst.
Proof. unfold Equation3512. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff418_inst, reff418_op in H. discriminate H. Qed.

Lemma reff418_not3519 : ~ @Equation3519 Fin4 reff418_inst.
Proof. unfold Equation3519. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff418_inst, reff418_op in H. discriminate H. Qed.

Lemma reff418_not3521 : ~ @Equation3521 Fin4 reff418_inst.
Proof. unfold Equation3521. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff418_inst, reff418_op in H. discriminate H. Qed.

Lemma reff418_not3545 : ~ @Equation3545 Fin4 reff418_inst.
Proof. unfold Equation3545. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff418_inst, reff418_op in H. discriminate H. Qed.

Lemma reff418_not3546 : ~ @Equation3546 Fin4 reff418_inst.
Proof. unfold Equation3546. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff418_inst, reff418_op in H. discriminate H. Qed.

Lemma reff418_not3548 : ~ @Equation3548 Fin4 reff418_inst.
Proof. unfold Equation3548. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff418_inst, reff418_op in H. discriminate H. Qed.

Lemma reff418_not3549 : ~ @Equation3549 Fin4 reff418_inst.
Proof. unfold Equation3549. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff418_inst, reff418_op in H. discriminate H. Qed.

Lemma reff418_not3555 : ~ @Equation3555 Fin4 reff418_inst.
Proof. unfold Equation3555. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff418_inst, reff418_op in H. discriminate H. Qed.

Lemma reff418_not3558 : ~ @Equation3558 Fin4 reff418_inst.
Proof. unfold Equation3558. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff418_inst, reff418_op in H. discriminate H. Qed.

Lemma reff418_not3660 : ~ @Equation3660 Fin4 reff418_inst.
Proof. unfold Equation3660. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff418_inst, reff418_op in H. discriminate H. Qed.

Lemma reff418_not3661 : ~ @Equation3661 Fin4 reff418_inst.
Proof. unfold Equation3661. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff418_inst, reff418_op in H. discriminate H. Qed.

Lemma reff418_not3664 : ~ @Equation3664 Fin4 reff418_inst.
Proof. unfold Equation3664. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff418_inst, reff418_op in H. discriminate H. Qed.

Lemma reff418_not3665 : ~ @Equation3665 Fin4 reff418_inst.
Proof. unfold Equation3665. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff418_inst, reff418_op in H. discriminate H. Qed.

Lemma reff418_not3667 : ~ @Equation3667 Fin4 reff418_inst.
Proof. unfold Equation3667. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff418_inst, reff418_op in H. discriminate H. Qed.

Lemma reff418_not3668 : ~ @Equation3668 Fin4 reff418_inst.
Proof. unfold Equation3668. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff418_inst, reff418_op in H. discriminate H. Qed.

Lemma reff418_not3674 : ~ @Equation3674 Fin4 reff418_inst.
Proof. unfold Equation3674. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff418_inst, reff418_op in H. discriminate H. Qed.

Lemma reff418_not3675 : ~ @Equation3675 Fin4 reff418_inst.
Proof. unfold Equation3675. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff418_inst, reff418_op in H. discriminate H. Qed.

Lemma reff418_not3677 : ~ @Equation3677 Fin4 reff418_inst.
Proof. unfold Equation3677. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff418_inst, reff418_op in H. discriminate H. Qed.

Lemma reff418_not3678 : ~ @Equation3678 Fin4 reff418_inst.
Proof. unfold Equation3678. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff418_inst, reff418_op in H. discriminate H. Qed.

Lemma reff418_not3684 : ~ @Equation3684 Fin4 reff418_inst.
Proof. unfold Equation3684. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff418_inst, reff418_op in H. discriminate H. Qed.

Lemma reff418_not3685 : ~ @Equation3685 Fin4 reff418_inst.
Proof. unfold Equation3685. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff418_inst, reff418_op in H. discriminate H. Qed.

Lemma reff418_not3687 : ~ @Equation3687 Fin4 reff418_inst.
Proof. unfold Equation3687. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff418_inst, reff418_op in H. discriminate H. Qed.

Lemma reff418_not3712 : ~ @Equation3712 Fin4 reff418_inst.
Proof. unfold Equation3712. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff418_inst, reff418_op in H. discriminate H. Qed.

Lemma reff418_not3714 : ~ @Equation3714 Fin4 reff418_inst.
Proof. unfold Equation3714. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff418_inst, reff418_op in H. discriminate H. Qed.

Lemma reff418_not3722 : ~ @Equation3722 Fin4 reff418_inst.
Proof. unfold Equation3722. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff418_inst, reff418_op in H. discriminate H. Qed.

Lemma reff418_not3724 : ~ @Equation3724 Fin4 reff418_inst.
Proof. unfold Equation3724. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff418_inst, reff418_op in H. discriminate H. Qed.

Lemma reff418_not3748 : ~ @Equation3748 Fin4 reff418_inst.
Proof. unfold Equation3748. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff418_inst, reff418_op in H. discriminate H. Qed.

Lemma reff418_not3749 : ~ @Equation3749 Fin4 reff418_inst.
Proof. unfold Equation3749. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff418_inst, reff418_op in H. discriminate H. Qed.

Lemma reff418_not3751 : ~ @Equation3751 Fin4 reff418_inst.
Proof. unfold Equation3751. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff418_inst, reff418_op in H. discriminate H. Qed.

Lemma reff418_not3752 : ~ @Equation3752 Fin4 reff418_inst.
Proof. unfold Equation3752. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff418_inst, reff418_op in H. discriminate H. Qed.

Lemma reff418_not3759 : ~ @Equation3759 Fin4 reff418_inst.
Proof. unfold Equation3759. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff418_inst, reff418_op in H. discriminate H. Qed.

Lemma reff418_not3761 : ~ @Equation3761 Fin4 reff418_inst.
Proof. unfold Equation3761. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff418_inst, reff418_op in H. discriminate H. Qed.

Lemma reff418_not3864 : ~ @Equation3864 Fin4 reff418_inst.
Proof. unfold Equation3864. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff418_inst, reff418_op in H. discriminate H. Qed.

Lemma reff418_not3865 : ~ @Equation3865 Fin4 reff418_inst.
Proof. unfold Equation3865. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff418_inst, reff418_op in H. discriminate H. Qed.

Lemma reff418_not3867 : ~ @Equation3867 Fin4 reff418_inst.
Proof. unfold Equation3867. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff418_inst, reff418_op in H. discriminate H. Qed.

Lemma reff418_not3868 : ~ @Equation3868 Fin4 reff418_inst.
Proof. unfold Equation3868. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff418_inst, reff418_op in H. discriminate H. Qed.

Lemma reff418_not3871 : ~ @Equation3871 Fin4 reff418_inst.
Proof. unfold Equation3871. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff418_inst, reff418_op in H. discriminate H. Qed.

Lemma reff418_not3877 : ~ @Equation3877 Fin4 reff418_inst.
Proof. unfold Equation3877. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff418_inst, reff418_op in H. discriminate H. Qed.

Lemma reff418_not3878 : ~ @Equation3878 Fin4 reff418_inst.
Proof. unfold Equation3878. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff418_inst, reff418_op in H. discriminate H. Qed.

Lemma reff418_not3880 : ~ @Equation3880 Fin4 reff418_inst.
Proof. unfold Equation3880. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff418_inst, reff418_op in H. discriminate H. Qed.

Lemma reff418_not3881 : ~ @Equation3881 Fin4 reff418_inst.
Proof. unfold Equation3881. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff418_inst, reff418_op in H. discriminate H. Qed.

Lemma reff418_not3887 : ~ @Equation3887 Fin4 reff418_inst.
Proof. unfold Equation3887. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff418_inst, reff418_op in H. discriminate H. Qed.

Lemma reff418_not3888 : ~ @Equation3888 Fin4 reff418_inst.
Proof. unfold Equation3888. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff418_inst, reff418_op in H. discriminate H. Qed.

Lemma reff418_not3890 : ~ @Equation3890 Fin4 reff418_inst.
Proof. unfold Equation3890. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff418_inst, reff418_op in H. discriminate H. Qed.

Lemma reff418_not3917 : ~ @Equation3917 Fin4 reff418_inst.
Proof. unfold Equation3917. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff418_inst, reff418_op in H. discriminate H. Qed.

Lemma reff418_not3918 : ~ @Equation3918 Fin4 reff418_inst.
Proof. unfold Equation3918. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff418_inst, reff418_op in H. discriminate H. Qed.

Lemma reff418_not3924 : ~ @Equation3924 Fin4 reff418_inst.
Proof. unfold Equation3924. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff418_inst, reff418_op in H. discriminate H. Qed.

Lemma reff418_not3925 : ~ @Equation3925 Fin4 reff418_inst.
Proof. unfold Equation3925. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff418_inst, reff418_op in H. discriminate H. Qed.

Lemma reff418_not3927 : ~ @Equation3927 Fin4 reff418_inst.
Proof. unfold Equation3927. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff418_inst, reff418_op in H. discriminate H. Qed.

Lemma reff418_not3951 : ~ @Equation3951 Fin4 reff418_inst.
Proof. unfold Equation3951. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff418_inst, reff418_op in H. discriminate H. Qed.

Lemma reff418_not3952 : ~ @Equation3952 Fin4 reff418_inst.
Proof. unfold Equation3952. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff418_inst, reff418_op in H. discriminate H. Qed.

Lemma reff418_not3954 : ~ @Equation3954 Fin4 reff418_inst.
Proof. unfold Equation3954. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff418_inst, reff418_op in H. discriminate H. Qed.

Lemma reff418_not3955 : ~ @Equation3955 Fin4 reff418_inst.
Proof. unfold Equation3955. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff418_inst, reff418_op in H. discriminate H. Qed.

Lemma reff418_not3961 : ~ @Equation3961 Fin4 reff418_inst.
Proof. unfold Equation3961. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff418_inst, reff418_op in H. discriminate H. Qed.

Lemma reff418_not3962 : ~ @Equation3962 Fin4 reff418_inst.
Proof. unfold Equation3962. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff418_inst, reff418_op in H. discriminate H. Qed.

Lemma reff418_not3964 : ~ @Equation3964 Fin4 reff418_inst.
Proof. unfold Equation3964. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff418_inst, reff418_op in H. discriminate H. Qed.

Lemma reff418_not4065 : ~ @Equation4065 Fin4 reff418_inst.
Proof. unfold Equation4065. intro H. specialize (H F4_1). unfold magma_op, reff418_inst, reff418_op in H. discriminate H. Qed.

Lemma reff418_not4268 : ~ @Equation4268 Fin4 reff418_inst.
Proof. unfold Equation4268. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff418_inst, reff418_op in H. discriminate H. Qed.

Lemma reff418_not4269 : ~ @Equation4269 Fin4 reff418_inst.
Proof. unfold Equation4269. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff418_inst, reff418_op in H. discriminate H. Qed.

Lemma reff418_not4272 : ~ @Equation4272 Fin4 reff418_inst.
Proof. unfold Equation4272. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff418_inst, reff418_op in H. discriminate H. Qed.

Lemma reff418_not4273 : ~ @Equation4273 Fin4 reff418_inst.
Proof. unfold Equation4273. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff418_inst, reff418_op in H. discriminate H. Qed.

Lemma reff418_not4275 : ~ @Equation4275 Fin4 reff418_inst.
Proof. unfold Equation4275. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff418_inst, reff418_op in H. discriminate H. Qed.

Lemma reff418_not4276 : ~ @Equation4276 Fin4 reff418_inst.
Proof. unfold Equation4276. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff418_inst, reff418_op in H. discriminate H. Qed.

Lemma reff418_not4284 : ~ @Equation4284 Fin4 reff418_inst.
Proof. unfold Equation4284. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff418_inst, reff418_op in H. discriminate H. Qed.

Lemma reff418_not4290 : ~ @Equation4290 Fin4 reff418_inst.
Proof. unfold Equation4290. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff418_inst, reff418_op in H. discriminate H. Qed.

Lemma reff418_not4291 : ~ @Equation4291 Fin4 reff418_inst.
Proof. unfold Equation4291. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff418_inst, reff418_op in H. discriminate H. Qed.

Lemma reff418_not4293 : ~ @Equation4293 Fin4 reff418_inst.
Proof. unfold Equation4293. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff418_inst, reff418_op in H. discriminate H. Qed.

Lemma reff418_not4314 : ~ @Equation4314 Fin4 reff418_inst.
Proof. unfold Equation4314. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff418_inst, reff418_op in H. discriminate H. Qed.

Lemma reff418_not4320 : ~ @Equation4320 Fin4 reff418_inst.
Proof. unfold Equation4320. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff418_inst, reff418_op in H. discriminate H. Qed.

Lemma reff418_not4321 : ~ @Equation4321 Fin4 reff418_inst.
Proof. unfold Equation4321. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff418_inst, reff418_op in H. discriminate H. Qed.

Lemma reff418_not4343 : ~ @Equation4343 Fin4 reff418_inst.
Proof. unfold Equation4343. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff418_inst, reff418_op in H. discriminate H. Qed.

Lemma reff418_not4380 : ~ @Equation4380 Fin4 reff418_inst.
Proof. unfold Equation4380. intro H. specialize (H F4_1). unfold magma_op, reff418_inst, reff418_op in H. discriminate H. Qed.

Lemma reff418_not4583 : ~ @Equation4583 Fin4 reff418_inst.
Proof. unfold Equation4583. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff418_inst, reff418_op in H. discriminate H. Qed.

Lemma reff418_not4584 : ~ @Equation4584 Fin4 reff418_inst.
Proof. unfold Equation4584. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff418_inst, reff418_op in H. discriminate H. Qed.

Lemma reff418_not4585 : ~ @Equation4585 Fin4 reff418_inst.
Proof. unfold Equation4585. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff418_inst, reff418_op in H. discriminate H. Qed.

Lemma reff418_not4587 : ~ @Equation4587 Fin4 reff418_inst.
Proof. unfold Equation4587. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff418_inst, reff418_op in H. discriminate H. Qed.

Lemma reff418_not4588 : ~ @Equation4588 Fin4 reff418_inst.
Proof. unfold Equation4588. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff418_inst, reff418_op in H. discriminate H. Qed.

Lemma reff418_not4590 : ~ @Equation4590 Fin4 reff418_inst.
Proof. unfold Equation4590. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff418_inst, reff418_op in H. discriminate H. Qed.

Lemma reff418_not4591 : ~ @Equation4591 Fin4 reff418_inst.
Proof. unfold Equation4591. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff418_inst, reff418_op in H. discriminate H. Qed.

Lemma reff418_not4599 : ~ @Equation4599 Fin4 reff418_inst.
Proof. unfold Equation4599. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff418_inst, reff418_op in H. discriminate H. Qed.

Lemma reff418_not4605 : ~ @Equation4605 Fin4 reff418_inst.
Proof. unfold Equation4605. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff418_inst, reff418_op in H. discriminate H. Qed.

Lemma reff418_not4606 : ~ @Equation4606 Fin4 reff418_inst.
Proof. unfold Equation4606. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff418_inst, reff418_op in H. discriminate H. Qed.

Lemma reff418_not4608 : ~ @Equation4608 Fin4 reff418_inst.
Proof. unfold Equation4608. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff418_inst, reff418_op in H. discriminate H. Qed.

Lemma reff418_not4629 : ~ @Equation4629 Fin4 reff418_inst.
Proof. unfold Equation4629. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff418_inst, reff418_op in H. discriminate H. Qed.

Lemma reff418_not4635 : ~ @Equation4635 Fin4 reff418_inst.
Proof. unfold Equation4635. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff418_inst, reff418_op in H. discriminate H. Qed.

Lemma reff418_not4636 : ~ @Equation4636 Fin4 reff418_inst.
Proof. unfold Equation4636. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff418_inst, reff418_op in H. discriminate H. Qed.

Lemma reff418_not4658 : ~ @Equation4658 Fin4 reff418_inst.
Proof. unfold Equation4658. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff418_inst, reff418_op in H. discriminate H. Qed.

(** ---- reff420 (Fin5) ---- *)

Definition reff420_op (x y : Fin5) : Fin5 :=
  match x, y with
  | F5_0, F5_0 => F5_0 | F5_0, F5_1 => F5_4 | F5_0, F5_2 => F5_3 | F5_0, F5_3 => F5_2 | F5_0, F5_4 => F5_1
  | F5_1, F5_0 => F5_2 | F5_1, F5_1 => F5_1 | F5_1, F5_2 => F5_0 | F5_1, F5_3 => F5_4 | F5_1, F5_4 => F5_3
  | F5_2, F5_0 => F5_4 | F5_2, F5_1 => F5_3 | F5_2, F5_2 => F5_2 | F5_2, F5_3 => F5_1 | F5_2, F5_4 => F5_0
  | F5_3, F5_0 => F5_1 | F5_3, F5_1 => F5_0 | F5_3, F5_2 => F5_4 | F5_3, F5_3 => F5_3 | F5_3, F5_4 => F5_2
  | F5_4, F5_0 => F5_3 | F5_4, F5_1 => F5_2 | F5_4, F5_2 => F5_1 | F5_4, F5_3 => F5_0 | F5_4, F5_4 => F5_4
  end.

#[local] Instance reff420_inst : Magma Fin5 := {| magma_op := reff420_op |}.

Lemma reff420_sat3 : @Equation3 Fin5 reff420_inst.
Proof. unfold Equation3, magma_op, reff420_inst, reff420_op. intros x. destruct x; reflexivity. Qed.

Lemma reff420_sat16 : @Equation16 Fin5 reff420_inst.
Proof. unfold Equation16, magma_op, reff420_inst, reff420_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff420_sat55 : @Equation55 Fin5 reff420_inst.
Proof. unfold Equation55, magma_op, reff420_inst, reff420_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff420_sat72 : @Equation72 Fin5 reff420_inst.
Proof. unfold Equation72, magma_op, reff420_inst, reff420_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff420_sat118 : @Equation118 Fin5 reff420_inst.
Proof. unfold Equation118, magma_op, reff420_inst, reff420_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff420_sat127 : @Equation127 Fin5 reff420_inst.
Proof. unfold Equation127, magma_op, reff420_inst, reff420_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff420_sat167 : @Equation167 Fin5 reff420_inst.
Proof. unfold Equation167, magma_op, reff420_inst, reff420_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff420_sat179 : @Equation179 Fin5 reff420_inst.
Proof. unfold Equation179, magma_op, reff420_inst, reff420_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff420_sat209 : @Equation209 Fin5 reff420_inst.
Proof. unfold Equation209, magma_op, reff420_inst, reff420_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff420_sat222 : @Equation222 Fin5 reff420_inst.
Proof. unfold Equation222, magma_op, reff420_inst, reff420_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff420_sat228 : @Equation228 Fin5 reff420_inst.
Proof. unfold Equation228, magma_op, reff420_inst, reff420_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff420_sat261 : @Equation261 Fin5 reff420_inst.
Proof. unfold Equation261, magma_op, reff420_inst, reff420_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff420_sat274 : @Equation274 Fin5 reff420_inst.
Proof. unfold Equation274, magma_op, reff420_inst, reff420_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff420_sat315 : @Equation315 Fin5 reff420_inst.
Proof. unfold Equation315, magma_op, reff420_inst, reff420_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff420_sat384 : @Equation384 Fin5 reff420_inst.
Proof. unfold Equation384, magma_op, reff420_inst, reff420_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff420_sat474 : @Equation474 Fin5 reff420_inst.
Proof. unfold Equation474, magma_op, reff420_inst, reff420_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff420_sat633 : @Equation633 Fin5 reff420_inst.
Proof. unfold Equation633, magma_op, reff420_inst, reff420_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff420_sat642 : @Equation642 Fin5 reff420_inst.
Proof. unfold Equation642, magma_op, reff420_inst, reff420_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff420_sat669 : @Equation669 Fin5 reff420_inst.
Proof. unfold Equation669, magma_op, reff420_inst, reff420_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff420_sat677 : @Equation677 Fin5 reff420_inst.
Proof. unfold Equation677, magma_op, reff420_inst, reff420_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff420_sat703 : @Equation703 Fin5 reff420_inst.
Proof. unfold Equation703, magma_op, reff420_inst, reff420_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff420_sat833 : @Equation833 Fin5 reff420_inst.
Proof. unfold Equation833, magma_op, reff420_inst, reff420_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff420_sat845 : @Equation845 Fin5 reff420_inst.
Proof. unfold Equation845, magma_op, reff420_inst, reff420_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff420_sat883 : @Equation883 Fin5 reff420_inst.
Proof. unfold Equation883, magma_op, reff420_inst, reff420_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff420_sat909 : @Equation909 Fin5 reff420_inst.
Proof. unfold Equation909, magma_op, reff420_inst, reff420_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff420_sat916 : @Equation916 Fin5 reff420_inst.
Proof. unfold Equation916, magma_op, reff420_inst, reff420_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff420_sat1039 : @Equation1039 Fin5 reff420_inst.
Proof. unfold Equation1039, magma_op, reff420_inst, reff420_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff420_sat1098 : @Equation1098 Fin5 reff420_inst.
Proof. unfold Equation1098, magma_op, reff420_inst, reff420_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff420_sat1229 : @Equation1229 Fin5 reff420_inst.
Proof. unfold Equation1229, magma_op, reff420_inst, reff420_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff420_sat1242 : @Equation1242 Fin5 reff420_inst.
Proof. unfold Equation1242, magma_op, reff420_inst, reff420_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff420_sat1279 : @Equation1279 Fin5 reff420_inst.
Proof. unfold Equation1279, magma_op, reff420_inst, reff420_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff420_sat1313 : @Equation1313 Fin5 reff420_inst.
Proof. unfold Equation1313, magma_op, reff420_inst, reff420_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff420_sat1325 : @Equation1325 Fin5 reff420_inst.
Proof. unfold Equation1325, magma_op, reff420_inst, reff420_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff420_sat1434 : @Equation1434 Fin5 reff420_inst.
Proof. unfold Equation1434, magma_op, reff420_inst, reff420_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff420_sat1444 : @Equation1444 Fin5 reff420_inst.
Proof. unfold Equation1444, magma_op, reff420_inst, reff420_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff420_sat1452 : @Equation1452 Fin5 reff420_inst.
Proof. unfold Equation1452, magma_op, reff420_inst, reff420_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff420_sat1482 : @Equation1482 Fin5 reff420_inst.
Proof. unfold Equation1482, magma_op, reff420_inst, reff420_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff420_sat1525 : @Equation1525 Fin5 reff420_inst.
Proof. unfold Equation1525, magma_op, reff420_inst, reff420_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff420_sat1655 : @Equation1655 Fin5 reff420_inst.
Proof. unfold Equation1655, magma_op, reff420_inst, reff420_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff420_sat1764 : @Equation1764 Fin5 reff420_inst.
Proof. unfold Equation1764, magma_op, reff420_inst, reff420_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff420_sat1851 : @Equation1851 Fin5 reff420_inst.
Proof. unfold Equation1851, magma_op, reff420_inst, reff420_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff420_sat1913 : @Equation1913 Fin5 reff420_inst.
Proof. unfold Equation1913, magma_op, reff420_inst, reff420_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff420_sat2054 : @Equation2054 Fin5 reff420_inst.
Proof. unfold Equation2054, magma_op, reff420_inst, reff420_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff420_sat2061 : @Equation2061 Fin5 reff420_inst.
Proof. unfold Equation2061, magma_op, reff420_inst, reff420_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff420_sat2101 : @Equation2101 Fin5 reff420_inst.
Proof. unfold Equation2101, magma_op, reff420_inst, reff420_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff420_sat2125 : @Equation2125 Fin5 reff420_inst.
Proof. unfold Equation2125, magma_op, reff420_inst, reff420_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff420_sat2137 : @Equation2137 Fin5 reff420_inst.
Proof. unfold Equation2137, magma_op, reff420_inst, reff420_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff420_sat2254 : @Equation2254 Fin5 reff420_inst.
Proof. unfold Equation2254, magma_op, reff420_inst, reff420_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff420_sat2263 : @Equation2263 Fin5 reff420_inst.
Proof. unfold Equation2263, magma_op, reff420_inst, reff420_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff420_sat2304 : @Equation2304 Fin5 reff420_inst.
Proof. unfold Equation2304, magma_op, reff420_inst, reff420_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff420_sat2327 : @Equation2327 Fin5 reff420_inst.
Proof. unfold Equation2327, magma_op, reff420_inst, reff420_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff420_sat2450 : @Equation2450 Fin5 reff420_inst.
Proof. unfold Equation2450, magma_op, reff420_inst, reff420_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff420_sat2467 : @Equation2467 Fin5 reff420_inst.
Proof. unfold Equation2467, magma_op, reff420_inst, reff420_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff420_sat2497 : @Equation2497 Fin5 reff420_inst.
Proof. unfold Equation2497, magma_op, reff420_inst, reff420_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff420_sat2506 : @Equation2506 Fin5 reff420_inst.
Proof. unfold Equation2506, magma_op, reff420_inst, reff420_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff420_sat2531 : @Equation2531 Fin5 reff420_inst.
Proof. unfold Equation2531, magma_op, reff420_inst, reff420_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff420_sat2540 : @Equation2540 Fin5 reff420_inst.
Proof. unfold Equation2540, magma_op, reff420_inst, reff420_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff420_sat2722 : @Equation2722 Fin5 reff420_inst.
Proof. unfold Equation2722, magma_op, reff420_inst, reff420_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff420_sat2743 : @Equation2743 Fin5 reff420_inst.
Proof. unfold Equation2743, magma_op, reff420_inst, reff420_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff420_sat2776 : @Equation2776 Fin5 reff420_inst.
Proof. unfold Equation2776, magma_op, reff420_inst, reff420_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff420_sat2865 : @Equation2865 Fin5 reff420_inst.
Proof. unfold Equation2865, magma_op, reff420_inst, reff420_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff420_sat2873 : @Equation2873 Fin5 reff420_inst.
Proof. unfold Equation2873, magma_op, reff420_inst, reff420_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff420_sat2903 : @Equation2903 Fin5 reff420_inst.
Proof. unfold Equation2903, magma_op, reff420_inst, reff420_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff420_sat2912 : @Equation2912 Fin5 reff420_inst.
Proof. unfold Equation2912, magma_op, reff420_inst, reff420_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff420_sat2936 : @Equation2936 Fin5 reff420_inst.
Proof. unfold Equation2936, magma_op, reff420_inst, reff420_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff420_sat3091 : @Equation3091 Fin5 reff420_inst.
Proof. unfold Equation3091, magma_op, reff420_inst, reff420_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff420_sat3115 : @Equation3115 Fin5 reff420_inst.
Proof. unfold Equation3115, magma_op, reff420_inst, reff420_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff420_sat3185 : @Equation3185 Fin5 reff420_inst.
Proof. unfold Equation3185, magma_op, reff420_inst, reff420_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff420_sat3345 : @Equation3345 Fin5 reff420_inst.
Proof. unfold Equation3345, magma_op, reff420_inst, reff420_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff420_sat3475 : @Equation3475 Fin5 reff420_inst.
Proof. unfold Equation3475, magma_op, reff420_inst, reff420_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff420_sat3484 : @Equation3484 Fin5 reff420_inst.
Proof. unfold Equation3484, magma_op, reff420_inst, reff420_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff420_sat3548 : @Equation3548 Fin5 reff420_inst.
Proof. unfold Equation3548, magma_op, reff420_inst, reff420_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff420_sat3556 : @Equation3556 Fin5 reff420_inst.
Proof. unfold Equation3556, magma_op, reff420_inst, reff420_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff420_sat3675 : @Equation3675 Fin5 reff420_inst.
Proof. unfold Equation3675, magma_op, reff420_inst, reff420_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff420_sat3687 : @Equation3687 Fin5 reff420_inst.
Proof. unfold Equation3687, magma_op, reff420_inst, reff420_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff420_sat3748 : @Equation3748 Fin5 reff420_inst.
Proof. unfold Equation3748, magma_op, reff420_inst, reff420_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff420_sat3881 : @Equation3881 Fin5 reff420_inst.
Proof. unfold Equation3881, magma_op, reff420_inst, reff420_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff420_sat3973 : @Equation3973 Fin5 reff420_inst.
Proof. unfold Equation3973, magma_op, reff420_inst, reff420_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff420_sat4071 : @Equation4071 Fin5 reff420_inst.
Proof. unfold Equation4071, magma_op, reff420_inst, reff420_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff420_sat4084 : @Equation4084 Fin5 reff420_inst.
Proof. unfold Equation4084, magma_op, reff420_inst, reff420_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff420_sat4164 : @Equation4164 Fin5 reff420_inst.
Proof. unfold Equation4164, magma_op, reff420_inst, reff420_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff420_sat4321 : @Equation4321 Fin5 reff420_inst.
Proof. unfold Equation4321, magma_op, reff420_inst, reff420_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff420_sat4409 : @Equation4409 Fin5 reff420_inst.
Proof. unfold Equation4409, magma_op, reff420_inst, reff420_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff420_sat4443 : @Equation4443 Fin5 reff420_inst.
Proof. unfold Equation4443, magma_op, reff420_inst, reff420_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff420_sat4479 : @Equation4479 Fin5 reff420_inst.
Proof. unfold Equation4479, magma_op, reff420_inst, reff420_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff420_sat4636 : @Equation4636 Fin5 reff420_inst.
Proof. unfold Equation4636, magma_op, reff420_inst, reff420_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff420_sat4684 : @Equation4684 Fin5 reff420_inst.
Proof. unfold Equation4684, magma_op, reff420_inst, reff420_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff420_not50 : ~ @Equation50 Fin5 reff420_inst.
Proof. unfold Equation50. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff420_inst, reff420_op in H. discriminate H. Qed.

Lemma reff420_not53 : ~ @Equation53 Fin5 reff420_inst.
Proof. unfold Equation53. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff420_inst, reff420_op in H. discriminate H. Qed.

Lemma reff420_not56 : ~ @Equation56 Fin5 reff420_inst.
Proof. unfold Equation56. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff420_inst, reff420_op in H. discriminate H. Qed.

Lemma reff420_not63 : ~ @Equation63 Fin5 reff420_inst.
Proof. unfold Equation63. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff420_inst, reff420_op in H. discriminate H. Qed.

Lemma reff420_not65 : ~ @Equation65 Fin5 reff420_inst.
Proof. unfold Equation65. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff420_inst, reff420_op in H. discriminate H. Qed.

Lemma reff420_not66 : ~ @Equation66 Fin5 reff420_inst.
Proof. unfold Equation66. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff420_inst, reff420_op in H. discriminate H. Qed.

Lemma reff420_not73 : ~ @Equation73 Fin5 reff420_inst.
Proof. unfold Equation73. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff420_inst, reff420_op in H. discriminate H. Qed.

Lemma reff420_not75 : ~ @Equation75 Fin5 reff420_inst.
Proof. unfold Equation75. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff420_inst, reff420_op in H. discriminate H. Qed.

Lemma reff420_not102 : ~ @Equation102 Fin5 reff420_inst.
Proof. unfold Equation102. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff420_inst, reff420_op in H. discriminate H. Qed.

Lemma reff420_not105 : ~ @Equation105 Fin5 reff420_inst.
Proof. unfold Equation105. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff420_inst, reff420_op in H. discriminate H. Qed.

Lemma reff420_not107 : ~ @Equation107 Fin5 reff420_inst.
Proof. unfold Equation107. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff420_inst, reff420_op in H. discriminate H. Qed.

Lemma reff420_not108 : ~ @Equation108 Fin5 reff420_inst.
Proof. unfold Equation108. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff420_inst, reff420_op in H. discriminate H. Qed.

Lemma reff420_not115 : ~ @Equation115 Fin5 reff420_inst.
Proof. unfold Equation115. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff420_inst, reff420_op in H. discriminate H. Qed.

Lemma reff420_not117 : ~ @Equation117 Fin5 reff420_inst.
Proof. unfold Equation117. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff420_inst, reff420_op in H. discriminate H. Qed.

Lemma reff420_not124 : ~ @Equation124 Fin5 reff420_inst.
Proof. unfold Equation124. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff420_inst, reff420_op in H. discriminate H. Qed.

Lemma reff420_not125 : ~ @Equation125 Fin5 reff420_inst.
Proof. unfold Equation125. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff420_inst, reff420_op in H. discriminate H. Qed.

Lemma reff420_not154 : ~ @Equation154 Fin5 reff420_inst.
Proof. unfold Equation154. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff420_inst, reff420_op in H. discriminate H. Qed.

Lemma reff420_not157 : ~ @Equation157 Fin5 reff420_inst.
Proof. unfold Equation157. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff420_inst, reff420_op in H. discriminate H. Qed.

Lemma reff420_not159 : ~ @Equation159 Fin5 reff420_inst.
Proof. unfold Equation159. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff420_inst, reff420_op in H. discriminate H. Qed.

Lemma reff420_not160 : ~ @Equation160 Fin5 reff420_inst.
Proof. unfold Equation160. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff420_inst, reff420_op in H. discriminate H. Qed.

Lemma reff420_not169 : ~ @Equation169 Fin5 reff420_inst.
Proof. unfold Equation169. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff420_inst, reff420_op in H. discriminate H. Qed.

Lemma reff420_not170 : ~ @Equation170 Fin5 reff420_inst.
Proof. unfold Equation170. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff420_inst, reff420_op in H. discriminate H. Qed.

Lemma reff420_not176 : ~ @Equation176 Fin5 reff420_inst.
Proof. unfold Equation176. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff420_inst, reff420_op in H. discriminate H. Qed.

Lemma reff420_not177 : ~ @Equation177 Fin5 reff420_inst.
Proof. unfold Equation177. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff420_inst, reff420_op in H. discriminate H. Qed.

Lemma reff420_not206 : ~ @Equation206 Fin5 reff420_inst.
Proof. unfold Equation206. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff420_inst, reff420_op in H. discriminate H. Qed.

Lemma reff420_not211 : ~ @Equation211 Fin5 reff420_inst.
Proof. unfold Equation211. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff420_inst, reff420_op in H. discriminate H. Qed.

Lemma reff420_not212 : ~ @Equation212 Fin5 reff420_inst.
Proof. unfold Equation212. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff420_inst, reff420_op in H. discriminate H. Qed.

Lemma reff420_not219 : ~ @Equation219 Fin5 reff420_inst.
Proof. unfold Equation219. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff420_inst, reff420_op in H. discriminate H. Qed.

Lemma reff420_not221 : ~ @Equation221 Fin5 reff420_inst.
Proof. unfold Equation221. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff420_inst, reff420_op in H. discriminate H. Qed.

Lemma reff420_not229 : ~ @Equation229 Fin5 reff420_inst.
Proof. unfold Equation229. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff420_inst, reff420_op in H. discriminate H. Qed.

Lemma reff420_not231 : ~ @Equation231 Fin5 reff420_inst.
Proof. unfold Equation231. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff420_inst, reff420_op in H. discriminate H. Qed.

Lemma reff420_not258 : ~ @Equation258 Fin5 reff420_inst.
Proof. unfold Equation258. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff420_inst, reff420_op in H. discriminate H. Qed.

Lemma reff420_not263 : ~ @Equation263 Fin5 reff420_inst.
Proof. unfold Equation263. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff420_inst, reff420_op in H. discriminate H. Qed.

Lemma reff420_not264 : ~ @Equation264 Fin5 reff420_inst.
Proof. unfold Equation264. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff420_inst, reff420_op in H. discriminate H. Qed.

Lemma reff420_not271 : ~ @Equation271 Fin5 reff420_inst.
Proof. unfold Equation271. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff420_inst, reff420_op in H. discriminate H. Qed.

Lemma reff420_not273 : ~ @Equation273 Fin5 reff420_inst.
Proof. unfold Equation273. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff420_inst, reff420_op in H. discriminate H. Qed.

Lemma reff420_not280 : ~ @Equation280 Fin5 reff420_inst.
Proof. unfold Equation280. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff420_inst, reff420_op in H. discriminate H. Qed.

Lemma reff420_not281 : ~ @Equation281 Fin5 reff420_inst.
Proof. unfold Equation281. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff420_inst, reff420_op in H. discriminate H. Qed.

Lemma reff420_not283 : ~ @Equation283 Fin5 reff420_inst.
Proof. unfold Equation283. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff420_inst, reff420_op in H. discriminate H. Qed.

Lemma reff420_not323 : ~ @Equation323 Fin5 reff420_inst.
Proof. unfold Equation323. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff420_inst, reff420_op in H. discriminate H. Qed.

Lemma reff420_not333 : ~ @Equation333 Fin5 reff420_inst.
Proof. unfold Equation333. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff420_inst, reff420_op in H. discriminate H. Qed.

Lemma reff420_not412 : ~ @Equation412 Fin5 reff420_inst.
Proof. unfold Equation412. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff420_inst, reff420_op in H. discriminate H. Qed.

Lemma reff420_not413 : ~ @Equation413 Fin5 reff420_inst.
Proof. unfold Equation413. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff420_inst, reff420_op in H. discriminate H. Qed.

Lemma reff420_not414 : ~ @Equation414 Fin5 reff420_inst.
Proof. unfold Equation414. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff420_inst, reff420_op in H. discriminate H. Qed.

Lemma reff420_not416 : ~ @Equation416 Fin5 reff420_inst.
Proof. unfold Equation416. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff420_inst, reff420_op in H. discriminate H. Qed.

Lemma reff420_not417 : ~ @Equation417 Fin5 reff420_inst.
Proof. unfold Equation417. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff420_inst, reff420_op in H. discriminate H. Qed.

Lemma reff420_not420 : ~ @Equation420 Fin5 reff420_inst.
Proof. unfold Equation420. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff420_inst, reff420_op in H. discriminate H. Qed.

Lemma reff420_not426 : ~ @Equation426 Fin5 reff420_inst.
Proof. unfold Equation426. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff420_inst, reff420_op in H. discriminate H. Qed.

Lemma reff420_not427 : ~ @Equation427 Fin5 reff420_inst.
Proof. unfold Equation427. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff420_inst, reff420_op in H. discriminate H. Qed.

Lemma reff420_not429 : ~ @Equation429 Fin5 reff420_inst.
Proof. unfold Equation429. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff420_inst, reff420_op in H. discriminate H. Qed.

Lemma reff420_not430 : ~ @Equation430 Fin5 reff420_inst.
Proof. unfold Equation430. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff420_inst, reff420_op in H. discriminate H. Qed.

Lemma reff420_not437 : ~ @Equation437 Fin5 reff420_inst.
Proof. unfold Equation437. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff420_inst, reff420_op in H. discriminate H. Qed.

Lemma reff420_not439 : ~ @Equation439 Fin5 reff420_inst.
Proof. unfold Equation439. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff420_inst, reff420_op in H. discriminate H. Qed.

Lemma reff420_not440 : ~ @Equation440 Fin5 reff420_inst.
Proof. unfold Equation440. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff420_inst, reff420_op in H. discriminate H. Qed.

Lemma reff420_not463 : ~ @Equation463 Fin5 reff420_inst.
Proof. unfold Equation463. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff420_inst, reff420_op in H. discriminate H. Qed.

Lemma reff420_not464 : ~ @Equation464 Fin5 reff420_inst.
Proof. unfold Equation464. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff420_inst, reff420_op in H. discriminate H. Qed.

Lemma reff420_not467 : ~ @Equation467 Fin5 reff420_inst.
Proof. unfold Equation467. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff420_inst, reff420_op in H. discriminate H. Qed.

Lemma reff420_not473 : ~ @Equation473 Fin5 reff420_inst.
Proof. unfold Equation473. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff420_inst, reff420_op in H. discriminate H. Qed.

Lemma reff420_not476 : ~ @Equation476 Fin5 reff420_inst.
Proof. unfold Equation476. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff420_inst, reff420_op in H. discriminate H. Qed.

Lemma reff420_not477 : ~ @Equation477 Fin5 reff420_inst.
Proof. unfold Equation477. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff420_inst, reff420_op in H. discriminate H. Qed.

Lemma reff420_not501 : ~ @Equation501 Fin5 reff420_inst.
Proof. unfold Equation501. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff420_inst, reff420_op in H. discriminate H. Qed.

Lemma reff420_not503 : ~ @Equation503 Fin5 reff420_inst.
Proof. unfold Equation503. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff420_inst, reff420_op in H. discriminate H. Qed.

Lemma reff420_not504 : ~ @Equation504 Fin5 reff420_inst.
Proof. unfold Equation504. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff420_inst, reff420_op in H. discriminate H. Qed.

Lemma reff420_not510 : ~ @Equation510 Fin5 reff420_inst.
Proof. unfold Equation510. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff420_inst, reff420_op in H. discriminate H. Qed.

Lemma reff420_not511 : ~ @Equation511 Fin5 reff420_inst.
Proof. unfold Equation511. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff420_inst, reff420_op in H. discriminate H. Qed.

Lemma reff420_not615 : ~ @Equation615 Fin5 reff420_inst.
Proof. unfold Equation615. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff420_inst, reff420_op in H. discriminate H. Qed.

Lemma reff420_not616 : ~ @Equation616 Fin5 reff420_inst.
Proof. unfold Equation616. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff420_inst, reff420_op in H. discriminate H. Qed.

Lemma reff420_not617 : ~ @Equation617 Fin5 reff420_inst.
Proof. unfold Equation617. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff420_inst, reff420_op in H. discriminate H. Qed.

Lemma reff420_not619 : ~ @Equation619 Fin5 reff420_inst.
Proof. unfold Equation619. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff420_inst, reff420_op in H. discriminate H. Qed.

Lemma reff420_not620 : ~ @Equation620 Fin5 reff420_inst.
Proof. unfold Equation620. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff420_inst, reff420_op in H. discriminate H. Qed.

Lemma reff420_not622 : ~ @Equation622 Fin5 reff420_inst.
Proof. unfold Equation622. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff420_inst, reff420_op in H. discriminate H. Qed.

Lemma reff420_not623 : ~ @Equation623 Fin5 reff420_inst.
Proof. unfold Equation623. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff420_inst, reff420_op in H. discriminate H. Qed.

Lemma reff420_not629 : ~ @Equation629 Fin5 reff420_inst.
Proof. unfold Equation629. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff420_inst, reff420_op in H. discriminate H. Qed.

Lemma reff420_not630 : ~ @Equation630 Fin5 reff420_inst.
Proof. unfold Equation630. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff420_inst, reff420_op in H. discriminate H. Qed.

Lemma reff420_not632 : ~ @Equation632 Fin5 reff420_inst.
Proof. unfold Equation632. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff420_inst, reff420_op in H. discriminate H. Qed.

Lemma reff420_not639 : ~ @Equation639 Fin5 reff420_inst.
Proof. unfold Equation639. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff420_inst, reff420_op in H. discriminate H. Qed.

Lemma reff420_not640 : ~ @Equation640 Fin5 reff420_inst.
Proof. unfold Equation640. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff420_inst, reff420_op in H. discriminate H. Qed.

Lemma reff420_not643 : ~ @Equation643 Fin5 reff420_inst.
Proof. unfold Equation643. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff420_inst, reff420_op in H. discriminate H. Qed.

Lemma reff420_not666 : ~ @Equation666 Fin5 reff420_inst.
Proof. unfold Equation666. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff420_inst, reff420_op in H. discriminate H. Qed.

Lemma reff420_not667 : ~ @Equation667 Fin5 reff420_inst.
Proof. unfold Equation667. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff420_inst, reff420_op in H. discriminate H. Qed.

Lemma reff420_not670 : ~ @Equation670 Fin5 reff420_inst.
Proof. unfold Equation670. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff420_inst, reff420_op in H. discriminate H. Qed.

Lemma reff420_not676 : ~ @Equation676 Fin5 reff420_inst.
Proof. unfold Equation676. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff420_inst, reff420_op in H. discriminate H. Qed.

Lemma reff420_not679 : ~ @Equation679 Fin5 reff420_inst.
Proof. unfold Equation679. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff420_inst, reff420_op in H. discriminate H. Qed.

Lemma reff420_not680 : ~ @Equation680 Fin5 reff420_inst.
Proof. unfold Equation680. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff420_inst, reff420_op in H. discriminate H. Qed.

Lemma reff420_not704 : ~ @Equation704 Fin5 reff420_inst.
Proof. unfold Equation704. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff420_inst, reff420_op in H. discriminate H. Qed.

Lemma reff420_not706 : ~ @Equation706 Fin5 reff420_inst.
Proof. unfold Equation706. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff420_inst, reff420_op in H. discriminate H. Qed.

Lemma reff420_not707 : ~ @Equation707 Fin5 reff420_inst.
Proof. unfold Equation707. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff420_inst, reff420_op in H. discriminate H. Qed.

Lemma reff420_not713 : ~ @Equation713 Fin5 reff420_inst.
Proof. unfold Equation713. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff420_inst, reff420_op in H. discriminate H. Qed.

Lemma reff420_not714 : ~ @Equation714 Fin5 reff420_inst.
Proof. unfold Equation714. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff420_inst, reff420_op in H. discriminate H. Qed.

Lemma reff420_not716 : ~ @Equation716 Fin5 reff420_inst.
Proof. unfold Equation716. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff420_inst, reff420_op in H. discriminate H. Qed.

Lemma reff420_not818 : ~ @Equation818 Fin5 reff420_inst.
Proof. unfold Equation818. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff420_inst, reff420_op in H. discriminate H. Qed.

Lemma reff420_not819 : ~ @Equation819 Fin5 reff420_inst.
Proof. unfold Equation819. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff420_inst, reff420_op in H. discriminate H. Qed.

Lemma reff420_not820 : ~ @Equation820 Fin5 reff420_inst.
Proof. unfold Equation820. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff420_inst, reff420_op in H. discriminate H. Qed.

Lemma reff420_not822 : ~ @Equation822 Fin5 reff420_inst.
Proof. unfold Equation822. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff420_inst, reff420_op in H. discriminate H. Qed.

Lemma reff420_not823 : ~ @Equation823 Fin5 reff420_inst.
Proof. unfold Equation823. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff420_inst, reff420_op in H. discriminate H. Qed.

Lemma reff420_not825 : ~ @Equation825 Fin5 reff420_inst.
Proof. unfold Equation825. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff420_inst, reff420_op in H. discriminate H. Qed.

Lemma reff420_not826 : ~ @Equation826 Fin5 reff420_inst.
Proof. unfold Equation826. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff420_inst, reff420_op in H. discriminate H. Qed.

Lemma reff420_not832 : ~ @Equation832 Fin5 reff420_inst.
Proof. unfold Equation832. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff420_inst, reff420_op in H. discriminate H. Qed.

Lemma reff420_not835 : ~ @Equation835 Fin5 reff420_inst.
Proof. unfold Equation835. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff420_inst, reff420_op in H. discriminate H. Qed.

Lemma reff420_not836 : ~ @Equation836 Fin5 reff420_inst.
Proof. unfold Equation836. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff420_inst, reff420_op in H. discriminate H. Qed.

Lemma reff420_not842 : ~ @Equation842 Fin5 reff420_inst.
Proof. unfold Equation842. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff420_inst, reff420_op in H. discriminate H. Qed.

Lemma reff420_not843 : ~ @Equation843 Fin5 reff420_inst.
Proof. unfold Equation843. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff420_inst, reff420_op in H. discriminate H. Qed.

Lemma reff420_not846 : ~ @Equation846 Fin5 reff420_inst.
Proof. unfold Equation846. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff420_inst, reff420_op in H. discriminate H. Qed.

Lemma reff420_not869 : ~ @Equation869 Fin5 reff420_inst.
Proof. unfold Equation869. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff420_inst, reff420_op in H. discriminate H. Qed.

Lemma reff420_not870 : ~ @Equation870 Fin5 reff420_inst.
Proof. unfold Equation870. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff420_inst, reff420_op in H. discriminate H. Qed.

Lemma reff420_not872 : ~ @Equation872 Fin5 reff420_inst.
Proof. unfold Equation872. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff420_inst, reff420_op in H. discriminate H. Qed.

Lemma reff420_not873 : ~ @Equation873 Fin5 reff420_inst.
Proof. unfold Equation873. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff420_inst, reff420_op in H. discriminate H. Qed.

Lemma reff420_not879 : ~ @Equation879 Fin5 reff420_inst.
Proof. unfold Equation879. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff420_inst, reff420_op in H. discriminate H. Qed.

Lemma reff420_not880 : ~ @Equation880 Fin5 reff420_inst.
Proof. unfold Equation880. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff420_inst, reff420_op in H. discriminate H. Qed.

Lemma reff420_not882 : ~ @Equation882 Fin5 reff420_inst.
Proof. unfold Equation882. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff420_inst, reff420_op in H. discriminate H. Qed.

Lemma reff420_not906 : ~ @Equation906 Fin5 reff420_inst.
Proof. unfold Equation906. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff420_inst, reff420_op in H. discriminate H. Qed.

Lemma reff420_not907 : ~ @Equation907 Fin5 reff420_inst.
Proof. unfold Equation907. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff420_inst, reff420_op in H. discriminate H. Qed.

Lemma reff420_not910 : ~ @Equation910 Fin5 reff420_inst.
Proof. unfold Equation910. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff420_inst, reff420_op in H. discriminate H. Qed.

Lemma reff420_not917 : ~ @Equation917 Fin5 reff420_inst.
Proof. unfold Equation917. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff420_inst, reff420_op in H. discriminate H. Qed.

Lemma reff420_not919 : ~ @Equation919 Fin5 reff420_inst.
Proof. unfold Equation919. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff420_inst, reff420_op in H. discriminate H. Qed.

Lemma reff420_not1021 : ~ @Equation1021 Fin5 reff420_inst.
Proof. unfold Equation1021. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff420_inst, reff420_op in H. discriminate H. Qed.

Lemma reff420_not1022 : ~ @Equation1022 Fin5 reff420_inst.
Proof. unfold Equation1022. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff420_inst, reff420_op in H. discriminate H. Qed.

Lemma reff420_not1023 : ~ @Equation1023 Fin5 reff420_inst.
Proof. unfold Equation1023. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff420_inst, reff420_op in H. discriminate H. Qed.

Lemma reff420_not1025 : ~ @Equation1025 Fin5 reff420_inst.
Proof. unfold Equation1025. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff420_inst, reff420_op in H. discriminate H. Qed.

Lemma reff420_not1028 : ~ @Equation1028 Fin5 reff420_inst.
Proof. unfold Equation1028. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff420_inst, reff420_op in H. discriminate H. Qed.

Lemma reff420_not1029 : ~ @Equation1029 Fin5 reff420_inst.
Proof. unfold Equation1029. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff420_inst, reff420_op in H. discriminate H. Qed.

Lemma reff420_not1035 : ~ @Equation1035 Fin5 reff420_inst.
Proof. unfold Equation1035. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff420_inst, reff420_op in H. discriminate H. Qed.

Lemma reff420_not1036 : ~ @Equation1036 Fin5 reff420_inst.
Proof. unfold Equation1036. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff420_inst, reff420_op in H. discriminate H. Qed.

Lemma reff420_not1038 : ~ @Equation1038 Fin5 reff420_inst.
Proof. unfold Equation1038. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff420_inst, reff420_op in H. discriminate H. Qed.

Lemma reff420_not1046 : ~ @Equation1046 Fin5 reff420_inst.
Proof. unfold Equation1046. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff420_inst, reff420_op in H. discriminate H. Qed.

Lemma reff420_not1048 : ~ @Equation1048 Fin5 reff420_inst.
Proof. unfold Equation1048. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff420_inst, reff420_op in H. discriminate H. Qed.

Lemma reff420_not1049 : ~ @Equation1049 Fin5 reff420_inst.
Proof. unfold Equation1049. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff420_inst, reff420_op in H. discriminate H. Qed.

Lemma reff420_not1072 : ~ @Equation1072 Fin5 reff420_inst.
Proof. unfold Equation1072. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff420_inst, reff420_op in H. discriminate H. Qed.

Lemma reff420_not1073 : ~ @Equation1073 Fin5 reff420_inst.
Proof. unfold Equation1073. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff420_inst, reff420_op in H. discriminate H. Qed.

Lemma reff420_not1076 : ~ @Equation1076 Fin5 reff420_inst.
Proof. unfold Equation1076. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff420_inst, reff420_op in H. discriminate H. Qed.

Lemma reff420_not1082 : ~ @Equation1082 Fin5 reff420_inst.
Proof. unfold Equation1082. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff420_inst, reff420_op in H. discriminate H. Qed.

Lemma reff420_not1083 : ~ @Equation1083 Fin5 reff420_inst.
Proof. unfold Equation1083. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff420_inst, reff420_op in H. discriminate H. Qed.

Lemma reff420_not1085 : ~ @Equation1085 Fin5 reff420_inst.
Proof. unfold Equation1085. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff420_inst, reff420_op in H. discriminate H. Qed.

Lemma reff420_not1109 : ~ @Equation1109 Fin5 reff420_inst.
Proof. unfold Equation1109. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff420_inst, reff420_op in H. discriminate H. Qed.

Lemma reff420_not1110 : ~ @Equation1110 Fin5 reff420_inst.
Proof. unfold Equation1110. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff420_inst, reff420_op in H. discriminate H. Qed.

Lemma reff420_not1112 : ~ @Equation1112 Fin5 reff420_inst.
Proof. unfold Equation1112. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff420_inst, reff420_op in H. discriminate H. Qed.

Lemma reff420_not1113 : ~ @Equation1113 Fin5 reff420_inst.
Proof. unfold Equation1113. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff420_inst, reff420_op in H. discriminate H. Qed.

Lemma reff420_not1119 : ~ @Equation1119 Fin5 reff420_inst.
Proof. unfold Equation1119. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff420_inst, reff420_op in H. discriminate H. Qed.

Lemma reff420_not1120 : ~ @Equation1120 Fin5 reff420_inst.
Proof. unfold Equation1120. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff420_inst, reff420_op in H. discriminate H. Qed.

Lemma reff420_not1224 : ~ @Equation1224 Fin5 reff420_inst.
Proof. unfold Equation1224. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff420_inst, reff420_op in H. discriminate H. Qed.

Lemma reff420_not1225 : ~ @Equation1225 Fin5 reff420_inst.
Proof. unfold Equation1225. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff420_inst, reff420_op in H. discriminate H. Qed.

Lemma reff420_not1226 : ~ @Equation1226 Fin5 reff420_inst.
Proof. unfold Equation1226. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff420_inst, reff420_op in H. discriminate H. Qed.

Lemma reff420_not1228 : ~ @Equation1228 Fin5 reff420_inst.
Proof. unfold Equation1228. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff420_inst, reff420_op in H. discriminate H. Qed.

Lemma reff420_not1231 : ~ @Equation1231 Fin5 reff420_inst.
Proof. unfold Equation1231. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff420_inst, reff420_op in H. discriminate H. Qed.

Lemma reff420_not1232 : ~ @Equation1232 Fin5 reff420_inst.
Proof. unfold Equation1232. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff420_inst, reff420_op in H. discriminate H. Qed.

Lemma reff420_not1238 : ~ @Equation1238 Fin5 reff420_inst.
Proof. unfold Equation1238. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff420_inst, reff420_op in H. discriminate H. Qed.

Lemma reff420_not1239 : ~ @Equation1239 Fin5 reff420_inst.
Proof. unfold Equation1239. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff420_inst, reff420_op in H. discriminate H. Qed.

Lemma reff420_not1241 : ~ @Equation1241 Fin5 reff420_inst.
Proof. unfold Equation1241. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff420_inst, reff420_op in H. discriminate H. Qed.

Lemma reff420_not1248 : ~ @Equation1248 Fin5 reff420_inst.
Proof. unfold Equation1248. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff420_inst, reff420_op in H. discriminate H. Qed.

Lemma reff420_not1249 : ~ @Equation1249 Fin5 reff420_inst.
Proof. unfold Equation1249. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff420_inst, reff420_op in H. discriminate H. Qed.

Lemma reff420_not1251 : ~ @Equation1251 Fin5 reff420_inst.
Proof. unfold Equation1251. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff420_inst, reff420_op in H. discriminate H. Qed.

Lemma reff420_not1252 : ~ @Equation1252 Fin5 reff420_inst.
Proof. unfold Equation1252. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff420_inst, reff420_op in H. discriminate H. Qed.

Lemma reff420_not1275 : ~ @Equation1275 Fin5 reff420_inst.
Proof. unfold Equation1275. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff420_inst, reff420_op in H. discriminate H. Qed.

Lemma reff420_not1276 : ~ @Equation1276 Fin5 reff420_inst.
Proof. unfold Equation1276. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff420_inst, reff420_op in H. discriminate H. Qed.

Lemma reff420_not1278 : ~ @Equation1278 Fin5 reff420_inst.
Proof. unfold Equation1278. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff420_inst, reff420_op in H. discriminate H. Qed.

Lemma reff420_not1285 : ~ @Equation1285 Fin5 reff420_inst.
Proof. unfold Equation1285. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff420_inst, reff420_op in H. discriminate H. Qed.

Lemma reff420_not1286 : ~ @Equation1286 Fin5 reff420_inst.
Proof. unfold Equation1286. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff420_inst, reff420_op in H. discriminate H. Qed.

Lemma reff420_not1288 : ~ @Equation1288 Fin5 reff420_inst.
Proof. unfold Equation1288. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff420_inst, reff420_op in H. discriminate H. Qed.

Lemma reff420_not1289 : ~ @Equation1289 Fin5 reff420_inst.
Proof. unfold Equation1289. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff420_inst, reff420_op in H. discriminate H. Qed.

Lemma reff420_not1312 : ~ @Equation1312 Fin5 reff420_inst.
Proof. unfold Equation1312. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff420_inst, reff420_op in H. discriminate H. Qed.

Lemma reff420_not1315 : ~ @Equation1315 Fin5 reff420_inst.
Proof. unfold Equation1315. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff420_inst, reff420_op in H. discriminate H. Qed.

Lemma reff420_not1316 : ~ @Equation1316 Fin5 reff420_inst.
Proof. unfold Equation1316. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff420_inst, reff420_op in H. discriminate H. Qed.

Lemma reff420_not1322 : ~ @Equation1322 Fin5 reff420_inst.
Proof. unfold Equation1322. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff420_inst, reff420_op in H. discriminate H. Qed.

Lemma reff420_not1323 : ~ @Equation1323 Fin5 reff420_inst.
Proof. unfold Equation1323. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff420_inst, reff420_op in H. discriminate H. Qed.

Lemma reff420_not1427 : ~ @Equation1427 Fin5 reff420_inst.
Proof. unfold Equation1427. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff420_inst, reff420_op in H. discriminate H. Qed.

Lemma reff420_not1428 : ~ @Equation1428 Fin5 reff420_inst.
Proof. unfold Equation1428. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff420_inst, reff420_op in H. discriminate H. Qed.

Lemma reff420_not1429 : ~ @Equation1429 Fin5 reff420_inst.
Proof. unfold Equation1429. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff420_inst, reff420_op in H. discriminate H. Qed.

Lemma reff420_not1431 : ~ @Equation1431 Fin5 reff420_inst.
Proof. unfold Equation1431. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff420_inst, reff420_op in H. discriminate H. Qed.

Lemma reff420_not1432 : ~ @Equation1432 Fin5 reff420_inst.
Proof. unfold Equation1432. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff420_inst, reff420_op in H. discriminate H. Qed.

Lemma reff420_not1435 : ~ @Equation1435 Fin5 reff420_inst.
Proof. unfold Equation1435. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff420_inst, reff420_op in H. discriminate H. Qed.

Lemma reff420_not1441 : ~ @Equation1441 Fin5 reff420_inst.
Proof. unfold Equation1441. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff420_inst, reff420_op in H. discriminate H. Qed.

Lemma reff420_not1442 : ~ @Equation1442 Fin5 reff420_inst.
Proof. unfold Equation1442. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff420_inst, reff420_op in H. discriminate H. Qed.

Lemma reff420_not1445 : ~ @Equation1445 Fin5 reff420_inst.
Proof. unfold Equation1445. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff420_inst, reff420_op in H. discriminate H. Qed.

Lemma reff420_not1451 : ~ @Equation1451 Fin5 reff420_inst.
Proof. unfold Equation1451. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff420_inst, reff420_op in H. discriminate H. Qed.

Lemma reff420_not1454 : ~ @Equation1454 Fin5 reff420_inst.
Proof. unfold Equation1454. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff420_inst, reff420_op in H. discriminate H. Qed.

Lemma reff420_not1455 : ~ @Equation1455 Fin5 reff420_inst.
Proof. unfold Equation1455. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff420_inst, reff420_op in H. discriminate H. Qed.

Lemma reff420_not1478 : ~ @Equation1478 Fin5 reff420_inst.
Proof. unfold Equation1478. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff420_inst, reff420_op in H. discriminate H. Qed.

Lemma reff420_not1479 : ~ @Equation1479 Fin5 reff420_inst.
Proof. unfold Equation1479. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff420_inst, reff420_op in H. discriminate H. Qed.

Lemma reff420_not1481 : ~ @Equation1481 Fin5 reff420_inst.
Proof. unfold Equation1481. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff420_inst, reff420_op in H. discriminate H. Qed.

Lemma reff420_not1488 : ~ @Equation1488 Fin5 reff420_inst.
Proof. unfold Equation1488. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff420_inst, reff420_op in H. discriminate H. Qed.

Lemma reff420_not1489 : ~ @Equation1489 Fin5 reff420_inst.
Proof. unfold Equation1489. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff420_inst, reff420_op in H. discriminate H. Qed.

Lemma reff420_not1491 : ~ @Equation1491 Fin5 reff420_inst.
Proof. unfold Equation1491. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff420_inst, reff420_op in H. discriminate H. Qed.

Lemma reff420_not1492 : ~ @Equation1492 Fin5 reff420_inst.
Proof. unfold Equation1492. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff420_inst, reff420_op in H. discriminate H. Qed.

Lemma reff420_not1515 : ~ @Equation1515 Fin5 reff420_inst.
Proof. unfold Equation1515. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff420_inst, reff420_op in H. discriminate H. Qed.

Lemma reff420_not1516 : ~ @Equation1516 Fin5 reff420_inst.
Proof. unfold Equation1516. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff420_inst, reff420_op in H. discriminate H. Qed.

Lemma reff420_not1518 : ~ @Equation1518 Fin5 reff420_inst.
Proof. unfold Equation1518. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff420_inst, reff420_op in H. discriminate H. Qed.

Lemma reff420_not1519 : ~ @Equation1519 Fin5 reff420_inst.
Proof. unfold Equation1519. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff420_inst, reff420_op in H. discriminate H. Qed.

Lemma reff420_not1526 : ~ @Equation1526 Fin5 reff420_inst.
Proof. unfold Equation1526. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff420_inst, reff420_op in H. discriminate H. Qed.

Lemma reff420_not1528 : ~ @Equation1528 Fin5 reff420_inst.
Proof. unfold Equation1528. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff420_inst, reff420_op in H. discriminate H. Qed.

Lemma reff420_not1630 : ~ @Equation1630 Fin5 reff420_inst.
Proof. unfold Equation1630. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff420_inst, reff420_op in H. discriminate H. Qed.

Lemma reff420_not1631 : ~ @Equation1631 Fin5 reff420_inst.
Proof. unfold Equation1631. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff420_inst, reff420_op in H. discriminate H. Qed.

Lemma reff420_not1632 : ~ @Equation1632 Fin5 reff420_inst.
Proof. unfold Equation1632. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff420_inst, reff420_op in H. discriminate H. Qed.

Lemma reff420_not1634 : ~ @Equation1634 Fin5 reff420_inst.
Proof. unfold Equation1634. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff420_inst, reff420_op in H. discriminate H. Qed.

Lemma reff420_not1635 : ~ @Equation1635 Fin5 reff420_inst.
Proof. unfold Equation1635. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff420_inst, reff420_op in H. discriminate H. Qed.

Lemma reff420_not1637 : ~ @Equation1637 Fin5 reff420_inst.
Proof. unfold Equation1637. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff420_inst, reff420_op in H. discriminate H. Qed.

Lemma reff420_not1638 : ~ @Equation1638 Fin5 reff420_inst.
Proof. unfold Equation1638. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff420_inst, reff420_op in H. discriminate H. Qed.

Lemma reff420_not1644 : ~ @Equation1644 Fin5 reff420_inst.
Proof. unfold Equation1644. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff420_inst, reff420_op in H. discriminate H. Qed.

Lemma reff420_not1645 : ~ @Equation1645 Fin5 reff420_inst.
Proof. unfold Equation1645. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff420_inst, reff420_op in H. discriminate H. Qed.

Lemma reff420_not1648 : ~ @Equation1648 Fin5 reff420_inst.
Proof. unfold Equation1648. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff420_inst, reff420_op in H. discriminate H. Qed.

Lemma reff420_not1654 : ~ @Equation1654 Fin5 reff420_inst.
Proof. unfold Equation1654. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff420_inst, reff420_op in H. discriminate H. Qed.

Lemma reff420_not1657 : ~ @Equation1657 Fin5 reff420_inst.
Proof. unfold Equation1657. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff420_inst, reff420_op in H. discriminate H. Qed.

Lemma reff420_not1658 : ~ @Equation1658 Fin5 reff420_inst.
Proof. unfold Equation1658. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff420_inst, reff420_op in H. discriminate H. Qed.

Lemma reff420_not1681 : ~ @Equation1681 Fin5 reff420_inst.
Proof. unfold Equation1681. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff420_inst, reff420_op in H. discriminate H. Qed.

Lemma reff420_not1684 : ~ @Equation1684 Fin5 reff420_inst.
Proof. unfold Equation1684. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff420_inst, reff420_op in H. discriminate H. Qed.

Lemma reff420_not1685 : ~ @Equation1685 Fin5 reff420_inst.
Proof. unfold Equation1685. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff420_inst, reff420_op in H. discriminate H. Qed.

Lemma reff420_not1692 : ~ @Equation1692 Fin5 reff420_inst.
Proof. unfold Equation1692. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff420_inst, reff420_op in H. discriminate H. Qed.

Lemma reff420_not1694 : ~ @Equation1694 Fin5 reff420_inst.
Proof. unfold Equation1694. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff420_inst, reff420_op in H. discriminate H. Qed.

Lemma reff420_not1695 : ~ @Equation1695 Fin5 reff420_inst.
Proof. unfold Equation1695. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff420_inst, reff420_op in H. discriminate H. Qed.

Lemma reff420_not1718 : ~ @Equation1718 Fin5 reff420_inst.
Proof. unfold Equation1718. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff420_inst, reff420_op in H. discriminate H. Qed.

Lemma reff420_not1719 : ~ @Equation1719 Fin5 reff420_inst.
Proof. unfold Equation1719. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff420_inst, reff420_op in H. discriminate H. Qed.

Lemma reff420_not1721 : ~ @Equation1721 Fin5 reff420_inst.
Proof. unfold Equation1721. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff420_inst, reff420_op in H. discriminate H. Qed.

Lemma reff420_not1728 : ~ @Equation1728 Fin5 reff420_inst.
Proof. unfold Equation1728. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff420_inst, reff420_op in H. discriminate H. Qed.

Lemma reff420_not1729 : ~ @Equation1729 Fin5 reff420_inst.
Proof. unfold Equation1729. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff420_inst, reff420_op in H. discriminate H. Qed.

Lemma reff420_not1833 : ~ @Equation1833 Fin5 reff420_inst.
Proof. unfold Equation1833. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff420_inst, reff420_op in H. discriminate H. Qed.

Lemma reff420_not1834 : ~ @Equation1834 Fin5 reff420_inst.
Proof. unfold Equation1834. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff420_inst, reff420_op in H. discriminate H. Qed.

Lemma reff420_not1835 : ~ @Equation1835 Fin5 reff420_inst.
Proof. unfold Equation1835. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff420_inst, reff420_op in H. discriminate H. Qed.

Lemma reff420_not1837 : ~ @Equation1837 Fin5 reff420_inst.
Proof. unfold Equation1837. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff420_inst, reff420_op in H. discriminate H. Qed.

Lemma reff420_not1838 : ~ @Equation1838 Fin5 reff420_inst.
Proof. unfold Equation1838. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff420_inst, reff420_op in H. discriminate H. Qed.

Lemma reff420_not1841 : ~ @Equation1841 Fin5 reff420_inst.
Proof. unfold Equation1841. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff420_inst, reff420_op in H. discriminate H. Qed.

Lemma reff420_not1847 : ~ @Equation1847 Fin5 reff420_inst.
Proof. unfold Equation1847. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff420_inst, reff420_op in H. discriminate H. Qed.

Lemma reff420_not1848 : ~ @Equation1848 Fin5 reff420_inst.
Proof. unfold Equation1848. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff420_inst, reff420_op in H. discriminate H. Qed.

Lemma reff420_not1850 : ~ @Equation1850 Fin5 reff420_inst.
Proof. unfold Equation1850. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff420_inst, reff420_op in H. discriminate H. Qed.

Lemma reff420_not1857 : ~ @Equation1857 Fin5 reff420_inst.
Proof. unfold Equation1857. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff420_inst, reff420_op in H. discriminate H. Qed.

Lemma reff420_not1858 : ~ @Equation1858 Fin5 reff420_inst.
Proof. unfold Equation1858. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff420_inst, reff420_op in H. discriminate H. Qed.

Lemma reff420_not1860 : ~ @Equation1860 Fin5 reff420_inst.
Proof. unfold Equation1860. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff420_inst, reff420_op in H. discriminate H. Qed.

Lemma reff420_not1861 : ~ @Equation1861 Fin5 reff420_inst.
Proof. unfold Equation1861. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff420_inst, reff420_op in H. discriminate H. Qed.

Lemma reff420_not1884 : ~ @Equation1884 Fin5 reff420_inst.
Proof. unfold Equation1884. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff420_inst, reff420_op in H. discriminate H. Qed.

Lemma reff420_not1887 : ~ @Equation1887 Fin5 reff420_inst.
Proof. unfold Equation1887. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff420_inst, reff420_op in H. discriminate H. Qed.

Lemma reff420_not1888 : ~ @Equation1888 Fin5 reff420_inst.
Proof. unfold Equation1888. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff420_inst, reff420_op in H. discriminate H. Qed.

Lemma reff420_not1894 : ~ @Equation1894 Fin5 reff420_inst.
Proof. unfold Equation1894. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff420_inst, reff420_op in H. discriminate H. Qed.

Lemma reff420_not1895 : ~ @Equation1895 Fin5 reff420_inst.
Proof. unfold Equation1895. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff420_inst, reff420_op in H. discriminate H. Qed.

Lemma reff420_not1897 : ~ @Equation1897 Fin5 reff420_inst.
Proof. unfold Equation1897. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff420_inst, reff420_op in H. discriminate H. Qed.

Lemma reff420_not1922 : ~ @Equation1922 Fin5 reff420_inst.
Proof. unfold Equation1922. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff420_inst, reff420_op in H. discriminate H. Qed.

Lemma reff420_not1924 : ~ @Equation1924 Fin5 reff420_inst.
Proof. unfold Equation1924. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff420_inst, reff420_op in H. discriminate H. Qed.

Lemma reff420_not1925 : ~ @Equation1925 Fin5 reff420_inst.
Proof. unfold Equation1925. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff420_inst, reff420_op in H. discriminate H. Qed.

Lemma reff420_not1931 : ~ @Equation1931 Fin5 reff420_inst.
Proof. unfold Equation1931. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff420_inst, reff420_op in H. discriminate H. Qed.

Lemma reff420_not1932 : ~ @Equation1932 Fin5 reff420_inst.
Proof. unfold Equation1932. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff420_inst, reff420_op in H. discriminate H. Qed.

Lemma reff420_not2036 : ~ @Equation2036 Fin5 reff420_inst.
Proof. unfold Equation2036. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff420_inst, reff420_op in H. discriminate H. Qed.

Lemma reff420_not2037 : ~ @Equation2037 Fin5 reff420_inst.
Proof. unfold Equation2037. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff420_inst, reff420_op in H. discriminate H. Qed.

Lemma reff420_not2038 : ~ @Equation2038 Fin5 reff420_inst.
Proof. unfold Equation2038. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff420_inst, reff420_op in H. discriminate H. Qed.

Lemma reff420_not2040 : ~ @Equation2040 Fin5 reff420_inst.
Proof. unfold Equation2040. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff420_inst, reff420_op in H. discriminate H. Qed.

Lemma reff420_not2041 : ~ @Equation2041 Fin5 reff420_inst.
Proof. unfold Equation2041. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff420_inst, reff420_op in H. discriminate H. Qed.

Lemma reff420_not2043 : ~ @Equation2043 Fin5 reff420_inst.
Proof. unfold Equation2043. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff420_inst, reff420_op in H. discriminate H. Qed.

Lemma reff420_not2044 : ~ @Equation2044 Fin5 reff420_inst.
Proof. unfold Equation2044. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff420_inst, reff420_op in H. discriminate H. Qed.

Lemma reff420_not2050 : ~ @Equation2050 Fin5 reff420_inst.
Proof. unfold Equation2050. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff420_inst, reff420_op in H. discriminate H. Qed.

Lemma reff420_not2051 : ~ @Equation2051 Fin5 reff420_inst.
Proof. unfold Equation2051. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff420_inst, reff420_op in H. discriminate H. Qed.

Lemma reff420_not2053 : ~ @Equation2053 Fin5 reff420_inst.
Proof. unfold Equation2053. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff420_inst, reff420_op in H. discriminate H. Qed.

Lemma reff420_not2060 : ~ @Equation2060 Fin5 reff420_inst.
Proof. unfold Equation2060. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff420_inst, reff420_op in H. discriminate H. Qed.

Lemma reff420_not2063 : ~ @Equation2063 Fin5 reff420_inst.
Proof. unfold Equation2063. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff420_inst, reff420_op in H. discriminate H. Qed.

Lemma reff420_not2064 : ~ @Equation2064 Fin5 reff420_inst.
Proof. unfold Equation2064. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff420_inst, reff420_op in H. discriminate H. Qed.

Lemma reff420_not2087 : ~ @Equation2087 Fin5 reff420_inst.
Proof. unfold Equation2087. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff420_inst, reff420_op in H. discriminate H. Qed.

Lemma reff420_not2088 : ~ @Equation2088 Fin5 reff420_inst.
Proof. unfold Equation2088. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff420_inst, reff420_op in H. discriminate H. Qed.

Lemma reff420_not2090 : ~ @Equation2090 Fin5 reff420_inst.
Proof. unfold Equation2090. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff420_inst, reff420_op in H. discriminate H. Qed.

Lemma reff420_not2091 : ~ @Equation2091 Fin5 reff420_inst.
Proof. unfold Equation2091. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff420_inst, reff420_op in H. discriminate H. Qed.

Lemma reff420_not2097 : ~ @Equation2097 Fin5 reff420_inst.
Proof. unfold Equation2097. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff420_inst, reff420_op in H. discriminate H. Qed.

Lemma reff420_not2098 : ~ @Equation2098 Fin5 reff420_inst.
Proof. unfold Equation2098. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff420_inst, reff420_op in H. discriminate H. Qed.

Lemma reff420_not2100 : ~ @Equation2100 Fin5 reff420_inst.
Proof. unfold Equation2100. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff420_inst, reff420_op in H. discriminate H. Qed.

Lemma reff420_not2124 : ~ @Equation2124 Fin5 reff420_inst.
Proof. unfold Equation2124. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff420_inst, reff420_op in H. discriminate H. Qed.

Lemma reff420_not2127 : ~ @Equation2127 Fin5 reff420_inst.
Proof. unfold Equation2127. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff420_inst, reff420_op in H. discriminate H. Qed.

Lemma reff420_not2128 : ~ @Equation2128 Fin5 reff420_inst.
Proof. unfold Equation2128. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff420_inst, reff420_op in H. discriminate H. Qed.

Lemma reff420_not2134 : ~ @Equation2134 Fin5 reff420_inst.
Proof. unfold Equation2134. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff420_inst, reff420_op in H. discriminate H. Qed.

Lemma reff420_not2135 : ~ @Equation2135 Fin5 reff420_inst.
Proof. unfold Equation2135. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff420_inst, reff420_op in H. discriminate H. Qed.

Lemma reff420_not2239 : ~ @Equation2239 Fin5 reff420_inst.
Proof. unfold Equation2239. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff420_inst, reff420_op in H. discriminate H. Qed.

Lemma reff420_not2240 : ~ @Equation2240 Fin5 reff420_inst.
Proof. unfold Equation2240. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff420_inst, reff420_op in H. discriminate H. Qed.

Lemma reff420_not2241 : ~ @Equation2241 Fin5 reff420_inst.
Proof. unfold Equation2241. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff420_inst, reff420_op in H. discriminate H. Qed.

Lemma reff420_not2243 : ~ @Equation2243 Fin5 reff420_inst.
Proof. unfold Equation2243. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff420_inst, reff420_op in H. discriminate H. Qed.

Lemma reff420_not2244 : ~ @Equation2244 Fin5 reff420_inst.
Proof. unfold Equation2244. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff420_inst, reff420_op in H. discriminate H. Qed.

Lemma reff420_not2246 : ~ @Equation2246 Fin5 reff420_inst.
Proof. unfold Equation2246. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff420_inst, reff420_op in H. discriminate H. Qed.

Lemma reff420_not2247 : ~ @Equation2247 Fin5 reff420_inst.
Proof. unfold Equation2247. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff420_inst, reff420_op in H. discriminate H. Qed.

Lemma reff420_not2253 : ~ @Equation2253 Fin5 reff420_inst.
Proof. unfold Equation2253. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff420_inst, reff420_op in H. discriminate H. Qed.

Lemma reff420_not2256 : ~ @Equation2256 Fin5 reff420_inst.
Proof. unfold Equation2256. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff420_inst, reff420_op in H. discriminate H. Qed.

Lemma reff420_not2257 : ~ @Equation2257 Fin5 reff420_inst.
Proof. unfold Equation2257. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff420_inst, reff420_op in H. discriminate H. Qed.

Lemma reff420_not2264 : ~ @Equation2264 Fin5 reff420_inst.
Proof. unfold Equation2264. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff420_inst, reff420_op in H. discriminate H. Qed.

Lemma reff420_not2266 : ~ @Equation2266 Fin5 reff420_inst.
Proof. unfold Equation2266. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff420_inst, reff420_op in H. discriminate H. Qed.

Lemma reff420_not2267 : ~ @Equation2267 Fin5 reff420_inst.
Proof. unfold Equation2267. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff420_inst, reff420_op in H. discriminate H. Qed.

Lemma reff420_not2290 : ~ @Equation2290 Fin5 reff420_inst.
Proof. unfold Equation2290. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff420_inst, reff420_op in H. discriminate H. Qed.

Lemma reff420_not2291 : ~ @Equation2291 Fin5 reff420_inst.
Proof. unfold Equation2291. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff420_inst, reff420_op in H. discriminate H. Qed.

Lemma reff420_not2293 : ~ @Equation2293 Fin5 reff420_inst.
Proof. unfold Equation2293. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff420_inst, reff420_op in H. discriminate H. Qed.

Lemma reff420_not2294 : ~ @Equation2294 Fin5 reff420_inst.
Proof. unfold Equation2294. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff420_inst, reff420_op in H. discriminate H. Qed.

Lemma reff420_not2300 : ~ @Equation2300 Fin5 reff420_inst.
Proof. unfold Equation2300. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff420_inst, reff420_op in H. discriminate H. Qed.

Lemma reff420_not2301 : ~ @Equation2301 Fin5 reff420_inst.
Proof. unfold Equation2301. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff420_inst, reff420_op in H. discriminate H. Qed.

Lemma reff420_not2303 : ~ @Equation2303 Fin5 reff420_inst.
Proof. unfold Equation2303. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff420_inst, reff420_op in H. discriminate H. Qed.

Lemma reff420_not2328 : ~ @Equation2328 Fin5 reff420_inst.
Proof. unfold Equation2328. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff420_inst, reff420_op in H. discriminate H. Qed.

Lemma reff420_not2330 : ~ @Equation2330 Fin5 reff420_inst.
Proof. unfold Equation2330. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff420_inst, reff420_op in H. discriminate H. Qed.

Lemma reff420_not2331 : ~ @Equation2331 Fin5 reff420_inst.
Proof. unfold Equation2331. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff420_inst, reff420_op in H. discriminate H. Qed.

Lemma reff420_not2337 : ~ @Equation2337 Fin5 reff420_inst.
Proof. unfold Equation2337. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff420_inst, reff420_op in H. discriminate H. Qed.

Lemma reff420_not2338 : ~ @Equation2338 Fin5 reff420_inst.
Proof. unfold Equation2338. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff420_inst, reff420_op in H. discriminate H. Qed.

Lemma reff420_not2340 : ~ @Equation2340 Fin5 reff420_inst.
Proof. unfold Equation2340. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff420_inst, reff420_op in H. discriminate H. Qed.

Lemma reff420_not2442 : ~ @Equation2442 Fin5 reff420_inst.
Proof. unfold Equation2442. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff420_inst, reff420_op in H. discriminate H. Qed.

Lemma reff420_not2443 : ~ @Equation2443 Fin5 reff420_inst.
Proof. unfold Equation2443. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff420_inst, reff420_op in H. discriminate H. Qed.

Lemma reff420_not2444 : ~ @Equation2444 Fin5 reff420_inst.
Proof. unfold Equation2444. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff420_inst, reff420_op in H. discriminate H. Qed.

Lemma reff420_not2446 : ~ @Equation2446 Fin5 reff420_inst.
Proof. unfold Equation2446. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff420_inst, reff420_op in H. discriminate H. Qed.

Lemma reff420_not2447 : ~ @Equation2447 Fin5 reff420_inst.
Proof. unfold Equation2447. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff420_inst, reff420_op in H. discriminate H. Qed.

Lemma reff420_not2449 : ~ @Equation2449 Fin5 reff420_inst.
Proof. unfold Equation2449. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff420_inst, reff420_op in H. discriminate H. Qed.

Lemma reff420_not2456 : ~ @Equation2456 Fin5 reff420_inst.
Proof. unfold Equation2456. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff420_inst, reff420_op in H. discriminate H. Qed.

Lemma reff420_not2457 : ~ @Equation2457 Fin5 reff420_inst.
Proof. unfold Equation2457. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff420_inst, reff420_op in H. discriminate H. Qed.

Lemma reff420_not2459 : ~ @Equation2459 Fin5 reff420_inst.
Proof. unfold Equation2459. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff420_inst, reff420_op in H. discriminate H. Qed.

Lemma reff420_not2460 : ~ @Equation2460 Fin5 reff420_inst.
Proof. unfold Equation2460. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff420_inst, reff420_op in H. discriminate H. Qed.

Lemma reff420_not2466 : ~ @Equation2466 Fin5 reff420_inst.
Proof. unfold Equation2466. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff420_inst, reff420_op in H. discriminate H. Qed.

Lemma reff420_not2469 : ~ @Equation2469 Fin5 reff420_inst.
Proof. unfold Equation2469. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff420_inst, reff420_op in H. discriminate H. Qed.

Lemma reff420_not2470 : ~ @Equation2470 Fin5 reff420_inst.
Proof. unfold Equation2470. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff420_inst, reff420_op in H. discriminate H. Qed.

Lemma reff420_not2493 : ~ @Equation2493 Fin5 reff420_inst.
Proof. unfold Equation2493. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff420_inst, reff420_op in H. discriminate H. Qed.

Lemma reff420_not2494 : ~ @Equation2494 Fin5 reff420_inst.
Proof. unfold Equation2494. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff420_inst, reff420_op in H. discriminate H. Qed.

Lemma reff420_not2496 : ~ @Equation2496 Fin5 reff420_inst.
Proof. unfold Equation2496. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff420_inst, reff420_op in H. discriminate H. Qed.

Lemma reff420_not2503 : ~ @Equation2503 Fin5 reff420_inst.
Proof. unfold Equation2503. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff420_inst, reff420_op in H. discriminate H. Qed.

Lemma reff420_not2504 : ~ @Equation2504 Fin5 reff420_inst.
Proof. unfold Equation2504. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff420_inst, reff420_op in H. discriminate H. Qed.

Lemma reff420_not2507 : ~ @Equation2507 Fin5 reff420_inst.
Proof. unfold Equation2507. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff420_inst, reff420_op in H. discriminate H. Qed.

Lemma reff420_not2530 : ~ @Equation2530 Fin5 reff420_inst.
Proof. unfold Equation2530. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff420_inst, reff420_op in H. discriminate H. Qed.

Lemma reff420_not2533 : ~ @Equation2533 Fin5 reff420_inst.
Proof. unfold Equation2533. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff420_inst, reff420_op in H. discriminate H. Qed.

Lemma reff420_not2534 : ~ @Equation2534 Fin5 reff420_inst.
Proof. unfold Equation2534. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff420_inst, reff420_op in H. discriminate H. Qed.

Lemma reff420_not2541 : ~ @Equation2541 Fin5 reff420_inst.
Proof. unfold Equation2541. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff420_inst, reff420_op in H. discriminate H. Qed.

Lemma reff420_not2543 : ~ @Equation2543 Fin5 reff420_inst.
Proof. unfold Equation2543. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff420_inst, reff420_op in H. discriminate H. Qed.

Lemma reff420_not2645 : ~ @Equation2645 Fin5 reff420_inst.
Proof. unfold Equation2645. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff420_inst, reff420_op in H. discriminate H. Qed.

Lemma reff420_not2646 : ~ @Equation2646 Fin5 reff420_inst.
Proof. unfold Equation2646. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff420_inst, reff420_op in H. discriminate H. Qed.

Lemma reff420_not2647 : ~ @Equation2647 Fin5 reff420_inst.
Proof. unfold Equation2647. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff420_inst, reff420_op in H. discriminate H. Qed.

Lemma reff420_not2649 : ~ @Equation2649 Fin5 reff420_inst.
Proof. unfold Equation2649. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff420_inst, reff420_op in H. discriminate H. Qed.

Lemma reff420_not2652 : ~ @Equation2652 Fin5 reff420_inst.
Proof. unfold Equation2652. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff420_inst, reff420_op in H. discriminate H. Qed.

Lemma reff420_not2653 : ~ @Equation2653 Fin5 reff420_inst.
Proof. unfold Equation2653. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff420_inst, reff420_op in H. discriminate H. Qed.

Lemma reff420_not2659 : ~ @Equation2659 Fin5 reff420_inst.
Proof. unfold Equation2659. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff420_inst, reff420_op in H. discriminate H. Qed.

Lemma reff420_not2662 : ~ @Equation2662 Fin5 reff420_inst.
Proof. unfold Equation2662. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff420_inst, reff420_op in H. discriminate H. Qed.

Lemma reff420_not2663 : ~ @Equation2663 Fin5 reff420_inst.
Proof. unfold Equation2663. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff420_inst, reff420_op in H. discriminate H. Qed.

Lemma reff420_not2669 : ~ @Equation2669 Fin5 reff420_inst.
Proof. unfold Equation2669. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff420_inst, reff420_op in H. discriminate H. Qed.

Lemma reff420_not2670 : ~ @Equation2670 Fin5 reff420_inst.
Proof. unfold Equation2670. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff420_inst, reff420_op in H. discriminate H. Qed.

Lemma reff420_not2672 : ~ @Equation2672 Fin5 reff420_inst.
Proof. unfold Equation2672. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff420_inst, reff420_op in H. discriminate H. Qed.

Lemma reff420_not2673 : ~ @Equation2673 Fin5 reff420_inst.
Proof. unfold Equation2673. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff420_inst, reff420_op in H. discriminate H. Qed.

Lemma reff420_not2696 : ~ @Equation2696 Fin5 reff420_inst.
Proof. unfold Equation2696. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff420_inst, reff420_op in H. discriminate H. Qed.

Lemma reff420_not2697 : ~ @Equation2697 Fin5 reff420_inst.
Proof. unfold Equation2697. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff420_inst, reff420_op in H. discriminate H. Qed.

Lemma reff420_not2700 : ~ @Equation2700 Fin5 reff420_inst.
Proof. unfold Equation2700. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff420_inst, reff420_op in H. discriminate H. Qed.

Lemma reff420_not2706 : ~ @Equation2706 Fin5 reff420_inst.
Proof. unfold Equation2706. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff420_inst, reff420_op in H. discriminate H. Qed.

Lemma reff420_not2707 : ~ @Equation2707 Fin5 reff420_inst.
Proof. unfold Equation2707. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff420_inst, reff420_op in H. discriminate H. Qed.

Lemma reff420_not2709 : ~ @Equation2709 Fin5 reff420_inst.
Proof. unfold Equation2709. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff420_inst, reff420_op in H. discriminate H. Qed.

Lemma reff420_not2733 : ~ @Equation2733 Fin5 reff420_inst.
Proof. unfold Equation2733. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff420_inst, reff420_op in H. discriminate H. Qed.

Lemma reff420_not2734 : ~ @Equation2734 Fin5 reff420_inst.
Proof. unfold Equation2734. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff420_inst, reff420_op in H. discriminate H. Qed.

Lemma reff420_not2736 : ~ @Equation2736 Fin5 reff420_inst.
Proof. unfold Equation2736. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff420_inst, reff420_op in H. discriminate H. Qed.

Lemma reff420_not2744 : ~ @Equation2744 Fin5 reff420_inst.
Proof. unfold Equation2744. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff420_inst, reff420_op in H. discriminate H. Qed.

Lemma reff420_not2746 : ~ @Equation2746 Fin5 reff420_inst.
Proof. unfold Equation2746. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff420_inst, reff420_op in H. discriminate H. Qed.

Lemma reff420_not2848 : ~ @Equation2848 Fin5 reff420_inst.
Proof. unfold Equation2848. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff420_inst, reff420_op in H. discriminate H. Qed.

Lemma reff420_not2849 : ~ @Equation2849 Fin5 reff420_inst.
Proof. unfold Equation2849. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff420_inst, reff420_op in H. discriminate H. Qed.

Lemma reff420_not2850 : ~ @Equation2850 Fin5 reff420_inst.
Proof. unfold Equation2850. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff420_inst, reff420_op in H. discriminate H. Qed.

Lemma reff420_not2852 : ~ @Equation2852 Fin5 reff420_inst.
Proof. unfold Equation2852. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff420_inst, reff420_op in H. discriminate H. Qed.

Lemma reff420_not2853 : ~ @Equation2853 Fin5 reff420_inst.
Proof. unfold Equation2853. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff420_inst, reff420_op in H. discriminate H. Qed.

Lemma reff420_not2855 : ~ @Equation2855 Fin5 reff420_inst.
Proof. unfold Equation2855. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff420_inst, reff420_op in H. discriminate H. Qed.

Lemma reff420_not2856 : ~ @Equation2856 Fin5 reff420_inst.
Proof. unfold Equation2856. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff420_inst, reff420_op in H. discriminate H. Qed.

Lemma reff420_not2862 : ~ @Equation2862 Fin5 reff420_inst.
Proof. unfold Equation2862. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff420_inst, reff420_op in H. discriminate H. Qed.

Lemma reff420_not2863 : ~ @Equation2863 Fin5 reff420_inst.
Proof. unfold Equation2863. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff420_inst, reff420_op in H. discriminate H. Qed.

Lemma reff420_not2866 : ~ @Equation2866 Fin5 reff420_inst.
Proof. unfold Equation2866. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff420_inst, reff420_op in H. discriminate H. Qed.

Lemma reff420_not2872 : ~ @Equation2872 Fin5 reff420_inst.
Proof. unfold Equation2872. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff420_inst, reff420_op in H. discriminate H. Qed.

Lemma reff420_not2875 : ~ @Equation2875 Fin5 reff420_inst.
Proof. unfold Equation2875. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff420_inst, reff420_op in H. discriminate H. Qed.

Lemma reff420_not2876 : ~ @Equation2876 Fin5 reff420_inst.
Proof. unfold Equation2876. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff420_inst, reff420_op in H. discriminate H. Qed.

Lemma reff420_not2899 : ~ @Equation2899 Fin5 reff420_inst.
Proof. unfold Equation2899. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff420_inst, reff420_op in H. discriminate H. Qed.

Lemma reff420_not2900 : ~ @Equation2900 Fin5 reff420_inst.
Proof. unfold Equation2900. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff420_inst, reff420_op in H. discriminate H. Qed.

Lemma reff420_not2902 : ~ @Equation2902 Fin5 reff420_inst.
Proof. unfold Equation2902. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff420_inst, reff420_op in H. discriminate H. Qed.

Lemma reff420_not2909 : ~ @Equation2909 Fin5 reff420_inst.
Proof. unfold Equation2909. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff420_inst, reff420_op in H. discriminate H. Qed.

Lemma reff420_not2910 : ~ @Equation2910 Fin5 reff420_inst.
Proof. unfold Equation2910. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff420_inst, reff420_op in H. discriminate H. Qed.

Lemma reff420_not2913 : ~ @Equation2913 Fin5 reff420_inst.
Proof. unfold Equation2913. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff420_inst, reff420_op in H. discriminate H. Qed.

Lemma reff420_not2937 : ~ @Equation2937 Fin5 reff420_inst.
Proof. unfold Equation2937. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff420_inst, reff420_op in H. discriminate H. Qed.

Lemma reff420_not2939 : ~ @Equation2939 Fin5 reff420_inst.
Proof. unfold Equation2939. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff420_inst, reff420_op in H. discriminate H. Qed.

Lemma reff420_not2940 : ~ @Equation2940 Fin5 reff420_inst.
Proof. unfold Equation2940. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff420_inst, reff420_op in H. discriminate H. Qed.

Lemma reff420_not2946 : ~ @Equation2946 Fin5 reff420_inst.
Proof. unfold Equation2946. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff420_inst, reff420_op in H. discriminate H. Qed.

Lemma reff420_not2947 : ~ @Equation2947 Fin5 reff420_inst.
Proof. unfold Equation2947. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff420_inst, reff420_op in H. discriminate H. Qed.

Lemma reff420_not2949 : ~ @Equation2949 Fin5 reff420_inst.
Proof. unfold Equation2949. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff420_inst, reff420_op in H. discriminate H. Qed.

Lemma reff420_not3051 : ~ @Equation3051 Fin5 reff420_inst.
Proof. unfold Equation3051. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff420_inst, reff420_op in H. discriminate H. Qed.

Lemma reff420_not3052 : ~ @Equation3052 Fin5 reff420_inst.
Proof. unfold Equation3052. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff420_inst, reff420_op in H. discriminate H. Qed.

Lemma reff420_not3053 : ~ @Equation3053 Fin5 reff420_inst.
Proof. unfold Equation3053. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff420_inst, reff420_op in H. discriminate H. Qed.

Lemma reff420_not3055 : ~ @Equation3055 Fin5 reff420_inst.
Proof. unfold Equation3055. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff420_inst, reff420_op in H. discriminate H. Qed.

Lemma reff420_not3058 : ~ @Equation3058 Fin5 reff420_inst.
Proof. unfold Equation3058. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff420_inst, reff420_op in H. discriminate H. Qed.

Lemma reff420_not3059 : ~ @Equation3059 Fin5 reff420_inst.
Proof. unfold Equation3059. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff420_inst, reff420_op in H. discriminate H. Qed.

Lemma reff420_not3065 : ~ @Equation3065 Fin5 reff420_inst.
Proof. unfold Equation3065. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff420_inst, reff420_op in H. discriminate H. Qed.

Lemma reff420_not3066 : ~ @Equation3066 Fin5 reff420_inst.
Proof. unfold Equation3066. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff420_inst, reff420_op in H. discriminate H. Qed.

Lemma reff420_not3069 : ~ @Equation3069 Fin5 reff420_inst.
Proof. unfold Equation3069. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff420_inst, reff420_op in H. discriminate H. Qed.

Lemma reff420_not3075 : ~ @Equation3075 Fin5 reff420_inst.
Proof. unfold Equation3075. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff420_inst, reff420_op in H. discriminate H. Qed.

Lemma reff420_not3076 : ~ @Equation3076 Fin5 reff420_inst.
Proof. unfold Equation3076. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff420_inst, reff420_op in H. discriminate H. Qed.

Lemma reff420_not3078 : ~ @Equation3078 Fin5 reff420_inst.
Proof. unfold Equation3078. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff420_inst, reff420_op in H. discriminate H. Qed.

Lemma reff420_not3102 : ~ @Equation3102 Fin5 reff420_inst.
Proof. unfold Equation3102. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff420_inst, reff420_op in H. discriminate H. Qed.

Lemma reff420_not3105 : ~ @Equation3105 Fin5 reff420_inst.
Proof. unfold Equation3105. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff420_inst, reff420_op in H. discriminate H. Qed.

Lemma reff420_not3106 : ~ @Equation3106 Fin5 reff420_inst.
Proof. unfold Equation3106. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff420_inst, reff420_op in H. discriminate H. Qed.

Lemma reff420_not3112 : ~ @Equation3112 Fin5 reff420_inst.
Proof. unfold Equation3112. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff420_inst, reff420_op in H. discriminate H. Qed.

Lemma reff420_not3113 : ~ @Equation3113 Fin5 reff420_inst.
Proof. unfold Equation3113. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff420_inst, reff420_op in H. discriminate H. Qed.

Lemma reff420_not3116 : ~ @Equation3116 Fin5 reff420_inst.
Proof. unfold Equation3116. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff420_inst, reff420_op in H. discriminate H. Qed.

Lemma reff420_not3139 : ~ @Equation3139 Fin5 reff420_inst.
Proof. unfold Equation3139. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff420_inst, reff420_op in H. discriminate H. Qed.

Lemma reff420_not3140 : ~ @Equation3140 Fin5 reff420_inst.
Proof. unfold Equation3140. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff420_inst, reff420_op in H. discriminate H. Qed.

Lemma reff420_not3142 : ~ @Equation3142 Fin5 reff420_inst.
Proof. unfold Equation3142. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff420_inst, reff420_op in H. discriminate H. Qed.

Lemma reff420_not3149 : ~ @Equation3149 Fin5 reff420_inst.
Proof. unfold Equation3149. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff420_inst, reff420_op in H. discriminate H. Qed.

Lemma reff420_not3150 : ~ @Equation3150 Fin5 reff420_inst.
Proof. unfold Equation3150. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff420_inst, reff420_op in H. discriminate H. Qed.

Lemma reff420_not3152 : ~ @Equation3152 Fin5 reff420_inst.
Proof. unfold Equation3152. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff420_inst, reff420_op in H. discriminate H. Qed.

Lemma reff420_not3254 : ~ @Equation3254 Fin5 reff420_inst.
Proof. unfold Equation3254. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff420_inst, reff420_op in H. discriminate H. Qed.

Lemma reff420_not3255 : ~ @Equation3255 Fin5 reff420_inst.
Proof. unfold Equation3255. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff420_inst, reff420_op in H. discriminate H. Qed.

Lemma reff420_not3256 : ~ @Equation3256 Fin5 reff420_inst.
Proof. unfold Equation3256. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff420_inst, reff420_op in H. discriminate H. Qed.

Lemma reff420_not3258 : ~ @Equation3258 Fin5 reff420_inst.
Proof. unfold Equation3258. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff420_inst, reff420_op in H. discriminate H. Qed.

Lemma reff420_not3259 : ~ @Equation3259 Fin5 reff420_inst.
Proof. unfold Equation3259. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff420_inst, reff420_op in H. discriminate H. Qed.

Lemma reff420_not3262 : ~ @Equation3262 Fin5 reff420_inst.
Proof. unfold Equation3262. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff420_inst, reff420_op in H. discriminate H. Qed.

Lemma reff420_not3268 : ~ @Equation3268 Fin5 reff420_inst.
Proof. unfold Equation3268. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff420_inst, reff420_op in H. discriminate H. Qed.

Lemma reff420_not3269 : ~ @Equation3269 Fin5 reff420_inst.
Proof. unfold Equation3269. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff420_inst, reff420_op in H. discriminate H. Qed.

Lemma reff420_not3271 : ~ @Equation3271 Fin5 reff420_inst.
Proof. unfold Equation3271. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff420_inst, reff420_op in H. discriminate H. Qed.

Lemma reff420_not3272 : ~ @Equation3272 Fin5 reff420_inst.
Proof. unfold Equation3272. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff420_inst, reff420_op in H. discriminate H. Qed.

Lemma reff420_not3279 : ~ @Equation3279 Fin5 reff420_inst.
Proof. unfold Equation3279. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff420_inst, reff420_op in H. discriminate H. Qed.

Lemma reff420_not3281 : ~ @Equation3281 Fin5 reff420_inst.
Proof. unfold Equation3281. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff420_inst, reff420_op in H. discriminate H. Qed.

Lemma reff420_not3308 : ~ @Equation3308 Fin5 reff420_inst.
Proof. unfold Equation3308. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff420_inst, reff420_op in H. discriminate H. Qed.

Lemma reff420_not3309 : ~ @Equation3309 Fin5 reff420_inst.
Proof. unfold Equation3309. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff420_inst, reff420_op in H. discriminate H. Qed.

Lemma reff420_not3315 : ~ @Equation3315 Fin5 reff420_inst.
Proof. unfold Equation3315. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff420_inst, reff420_op in H. discriminate H. Qed.

Lemma reff420_not3316 : ~ @Equation3316 Fin5 reff420_inst.
Proof. unfold Equation3316. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff420_inst, reff420_op in H. discriminate H. Qed.

Lemma reff420_not3318 : ~ @Equation3318 Fin5 reff420_inst.
Proof. unfold Equation3318. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff420_inst, reff420_op in H. discriminate H. Qed.

Lemma reff420_not3342 : ~ @Equation3342 Fin5 reff420_inst.
Proof. unfold Equation3342. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff420_inst, reff420_op in H. discriminate H. Qed.

Lemma reff420_not3343 : ~ @Equation3343 Fin5 reff420_inst.
Proof. unfold Equation3343. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff420_inst, reff420_op in H. discriminate H. Qed.

Lemma reff420_not3346 : ~ @Equation3346 Fin5 reff420_inst.
Proof. unfold Equation3346. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff420_inst, reff420_op in H. discriminate H. Qed.

Lemma reff420_not3352 : ~ @Equation3352 Fin5 reff420_inst.
Proof. unfold Equation3352. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff420_inst, reff420_op in H. discriminate H. Qed.

Lemma reff420_not3355 : ~ @Equation3355 Fin5 reff420_inst.
Proof. unfold Equation3355. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff420_inst, reff420_op in H. discriminate H. Qed.

Lemma reff420_not3457 : ~ @Equation3457 Fin5 reff420_inst.
Proof. unfold Equation3457. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff420_inst, reff420_op in H. discriminate H. Qed.

Lemma reff420_not3458 : ~ @Equation3458 Fin5 reff420_inst.
Proof. unfold Equation3458. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff420_inst, reff420_op in H. discriminate H. Qed.

Lemma reff420_not3459 : ~ @Equation3459 Fin5 reff420_inst.
Proof. unfold Equation3459. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff420_inst, reff420_op in H. discriminate H. Qed.

Lemma reff420_not3461 : ~ @Equation3461 Fin5 reff420_inst.
Proof. unfold Equation3461. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff420_inst, reff420_op in H. discriminate H. Qed.

Lemma reff420_not3462 : ~ @Equation3462 Fin5 reff420_inst.
Proof. unfold Equation3462. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff420_inst, reff420_op in H. discriminate H. Qed.

Lemma reff420_not3464 : ~ @Equation3464 Fin5 reff420_inst.
Proof. unfold Equation3464. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff420_inst, reff420_op in H. discriminate H. Qed.

Lemma reff420_not3465 : ~ @Equation3465 Fin5 reff420_inst.
Proof. unfold Equation3465. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff420_inst, reff420_op in H. discriminate H. Qed.

Lemma reff420_not3472 : ~ @Equation3472 Fin5 reff420_inst.
Proof. unfold Equation3472. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff420_inst, reff420_op in H. discriminate H. Qed.

Lemma reff420_not3474 : ~ @Equation3474 Fin5 reff420_inst.
Proof. unfold Equation3474. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff420_inst, reff420_op in H. discriminate H. Qed.

Lemma reff420_not3481 : ~ @Equation3481 Fin5 reff420_inst.
Proof. unfold Equation3481. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff420_inst, reff420_op in H. discriminate H. Qed.

Lemma reff420_not3482 : ~ @Equation3482 Fin5 reff420_inst.
Proof. unfold Equation3482. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff420_inst, reff420_op in H. discriminate H. Qed.

Lemma reff420_not3509 : ~ @Equation3509 Fin5 reff420_inst.
Proof. unfold Equation3509. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff420_inst, reff420_op in H. discriminate H. Qed.

Lemma reff420_not3511 : ~ @Equation3511 Fin5 reff420_inst.
Proof. unfold Equation3511. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff420_inst, reff420_op in H. discriminate H. Qed.

Lemma reff420_not3512 : ~ @Equation3512 Fin5 reff420_inst.
Proof. unfold Equation3512. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff420_inst, reff420_op in H. discriminate H. Qed.

Lemma reff420_not3518 : ~ @Equation3518 Fin5 reff420_inst.
Proof. unfold Equation3518. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff420_inst, reff420_op in H. discriminate H. Qed.

Lemma reff420_not3519 : ~ @Equation3519 Fin5 reff420_inst.
Proof. unfold Equation3519. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff420_inst, reff420_op in H. discriminate H. Qed.

Lemma reff420_not3521 : ~ @Equation3521 Fin5 reff420_inst.
Proof. unfold Equation3521. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff420_inst, reff420_op in H. discriminate H. Qed.

Lemma reff420_not3545 : ~ @Equation3545 Fin5 reff420_inst.
Proof. unfold Equation3545. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff420_inst, reff420_op in H. discriminate H. Qed.

Lemma reff420_not3546 : ~ @Equation3546 Fin5 reff420_inst.
Proof. unfold Equation3546. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff420_inst, reff420_op in H. discriminate H. Qed.

Lemma reff420_not3549 : ~ @Equation3549 Fin5 reff420_inst.
Proof. unfold Equation3549. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff420_inst, reff420_op in H. discriminate H. Qed.

Lemma reff420_not3555 : ~ @Equation3555 Fin5 reff420_inst.
Proof. unfold Equation3555. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff420_inst, reff420_op in H. discriminate H. Qed.

Lemma reff420_not3558 : ~ @Equation3558 Fin5 reff420_inst.
Proof. unfold Equation3558. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff420_inst, reff420_op in H. discriminate H. Qed.

Lemma reff420_not3660 : ~ @Equation3660 Fin5 reff420_inst.
Proof. unfold Equation3660. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff420_inst, reff420_op in H. discriminate H. Qed.

Lemma reff420_not3661 : ~ @Equation3661 Fin5 reff420_inst.
Proof. unfold Equation3661. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff420_inst, reff420_op in H. discriminate H. Qed.

Lemma reff420_not3662 : ~ @Equation3662 Fin5 reff420_inst.
Proof. unfold Equation3662. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff420_inst, reff420_op in H. discriminate H. Qed.

Lemma reff420_not3664 : ~ @Equation3664 Fin5 reff420_inst.
Proof. unfold Equation3664. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff420_inst, reff420_op in H. discriminate H. Qed.

Lemma reff420_not3665 : ~ @Equation3665 Fin5 reff420_inst.
Proof. unfold Equation3665. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff420_inst, reff420_op in H. discriminate H. Qed.

Lemma reff420_not3667 : ~ @Equation3667 Fin5 reff420_inst.
Proof. unfold Equation3667. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff420_inst, reff420_op in H. discriminate H. Qed.

Lemma reff420_not3668 : ~ @Equation3668 Fin5 reff420_inst.
Proof. unfold Equation3668. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff420_inst, reff420_op in H. discriminate H. Qed.

Lemma reff420_not3674 : ~ @Equation3674 Fin5 reff420_inst.
Proof. unfold Equation3674. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff420_inst, reff420_op in H. discriminate H. Qed.

Lemma reff420_not3677 : ~ @Equation3677 Fin5 reff420_inst.
Proof. unfold Equation3677. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff420_inst, reff420_op in H. discriminate H. Qed.

Lemma reff420_not3678 : ~ @Equation3678 Fin5 reff420_inst.
Proof. unfold Equation3678. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff420_inst, reff420_op in H. discriminate H. Qed.

Lemma reff420_not3684 : ~ @Equation3684 Fin5 reff420_inst.
Proof. unfold Equation3684. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff420_inst, reff420_op in H. discriminate H. Qed.

Lemma reff420_not3685 : ~ @Equation3685 Fin5 reff420_inst.
Proof. unfold Equation3685. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff420_inst, reff420_op in H. discriminate H. Qed.

Lemma reff420_not3712 : ~ @Equation3712 Fin5 reff420_inst.
Proof. unfold Equation3712. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff420_inst, reff420_op in H. discriminate H. Qed.

Lemma reff420_not3714 : ~ @Equation3714 Fin5 reff420_inst.
Proof. unfold Equation3714. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff420_inst, reff420_op in H. discriminate H. Qed.

Lemma reff420_not3721 : ~ @Equation3721 Fin5 reff420_inst.
Proof. unfold Equation3721. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff420_inst, reff420_op in H. discriminate H. Qed.

Lemma reff420_not3724 : ~ @Equation3724 Fin5 reff420_inst.
Proof. unfold Equation3724. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff420_inst, reff420_op in H. discriminate H. Qed.

Lemma reff420_not3725 : ~ @Equation3725 Fin5 reff420_inst.
Proof. unfold Equation3725. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff420_inst, reff420_op in H. discriminate H. Qed.

Lemma reff420_not3749 : ~ @Equation3749 Fin5 reff420_inst.
Proof. unfold Equation3749. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff420_inst, reff420_op in H. discriminate H. Qed.

Lemma reff420_not3751 : ~ @Equation3751 Fin5 reff420_inst.
Proof. unfold Equation3751. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff420_inst, reff420_op in H. discriminate H. Qed.

Lemma reff420_not3752 : ~ @Equation3752 Fin5 reff420_inst.
Proof. unfold Equation3752. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff420_inst, reff420_op in H. discriminate H. Qed.

Lemma reff420_not3758 : ~ @Equation3758 Fin5 reff420_inst.
Proof. unfold Equation3758. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff420_inst, reff420_op in H. discriminate H. Qed.

Lemma reff420_not3759 : ~ @Equation3759 Fin5 reff420_inst.
Proof. unfold Equation3759. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff420_inst, reff420_op in H. discriminate H. Qed.

Lemma reff420_not3761 : ~ @Equation3761 Fin5 reff420_inst.
Proof. unfold Equation3761. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff420_inst, reff420_op in H. discriminate H. Qed.

Lemma reff420_not3864 : ~ @Equation3864 Fin5 reff420_inst.
Proof. unfold Equation3864. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff420_inst, reff420_op in H. discriminate H. Qed.

Lemma reff420_not3865 : ~ @Equation3865 Fin5 reff420_inst.
Proof. unfold Equation3865. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff420_inst, reff420_op in H. discriminate H. Qed.

Lemma reff420_not3867 : ~ @Equation3867 Fin5 reff420_inst.
Proof. unfold Equation3867. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff420_inst, reff420_op in H. discriminate H. Qed.

Lemma reff420_not3870 : ~ @Equation3870 Fin5 reff420_inst.
Proof. unfold Equation3870. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff420_inst, reff420_op in H. discriminate H. Qed.

Lemma reff420_not3871 : ~ @Equation3871 Fin5 reff420_inst.
Proof. unfold Equation3871. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff420_inst, reff420_op in H. discriminate H. Qed.

Lemma reff420_not3877 : ~ @Equation3877 Fin5 reff420_inst.
Proof. unfold Equation3877. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff420_inst, reff420_op in H. discriminate H. Qed.

Lemma reff420_not3878 : ~ @Equation3878 Fin5 reff420_inst.
Proof. unfold Equation3878. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff420_inst, reff420_op in H. discriminate H. Qed.

Lemma reff420_not3880 : ~ @Equation3880 Fin5 reff420_inst.
Proof. unfold Equation3880. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff420_inst, reff420_op in H. discriminate H. Qed.

Lemma reff420_not3888 : ~ @Equation3888 Fin5 reff420_inst.
Proof. unfold Equation3888. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff420_inst, reff420_op in H. discriminate H. Qed.

Lemma reff420_not3890 : ~ @Equation3890 Fin5 reff420_inst.
Proof. unfold Equation3890. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff420_inst, reff420_op in H. discriminate H. Qed.

Lemma reff420_not3917 : ~ @Equation3917 Fin5 reff420_inst.
Proof. unfold Equation3917. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff420_inst, reff420_op in H. discriminate H. Qed.

Lemma reff420_not3918 : ~ @Equation3918 Fin5 reff420_inst.
Proof. unfold Equation3918. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff420_inst, reff420_op in H. discriminate H. Qed.

Lemma reff420_not3924 : ~ @Equation3924 Fin5 reff420_inst.
Proof. unfold Equation3924. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff420_inst, reff420_op in H. discriminate H. Qed.

Lemma reff420_not3925 : ~ @Equation3925 Fin5 reff420_inst.
Proof. unfold Equation3925. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff420_inst, reff420_op in H. discriminate H. Qed.

Lemma reff420_not3927 : ~ @Equation3927 Fin5 reff420_inst.
Proof. unfold Equation3927. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff420_inst, reff420_op in H. discriminate H. Qed.

Lemma reff420_not3928 : ~ @Equation3928 Fin5 reff420_inst.
Proof. unfold Equation3928. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff420_inst, reff420_op in H. discriminate H. Qed.

Lemma reff420_not3952 : ~ @Equation3952 Fin5 reff420_inst.
Proof. unfold Equation3952. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff420_inst, reff420_op in H. discriminate H. Qed.

Lemma reff420_not3954 : ~ @Equation3954 Fin5 reff420_inst.
Proof. unfold Equation3954. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff420_inst, reff420_op in H. discriminate H. Qed.

Lemma reff420_not3955 : ~ @Equation3955 Fin5 reff420_inst.
Proof. unfold Equation3955. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff420_inst, reff420_op in H. discriminate H. Qed.

Lemma reff420_not3961 : ~ @Equation3961 Fin5 reff420_inst.
Proof. unfold Equation3961. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff420_inst, reff420_op in H. discriminate H. Qed.

Lemma reff420_not3964 : ~ @Equation3964 Fin5 reff420_inst.
Proof. unfold Equation3964. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff420_inst, reff420_op in H. discriminate H. Qed.

Lemma reff420_not4066 : ~ @Equation4066 Fin5 reff420_inst.
Proof. unfold Equation4066. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff420_inst, reff420_op in H. discriminate H. Qed.

Lemma reff420_not4067 : ~ @Equation4067 Fin5 reff420_inst.
Proof. unfold Equation4067. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff420_inst, reff420_op in H. discriminate H. Qed.

Lemma reff420_not4068 : ~ @Equation4068 Fin5 reff420_inst.
Proof. unfold Equation4068. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff420_inst, reff420_op in H. discriminate H. Qed.

Lemma reff420_not4070 : ~ @Equation4070 Fin5 reff420_inst.
Proof. unfold Equation4070. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff420_inst, reff420_op in H. discriminate H. Qed.

Lemma reff420_not4073 : ~ @Equation4073 Fin5 reff420_inst.
Proof. unfold Equation4073. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff420_inst, reff420_op in H. discriminate H. Qed.

Lemma reff420_not4074 : ~ @Equation4074 Fin5 reff420_inst.
Proof. unfold Equation4074. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff420_inst, reff420_op in H. discriminate H. Qed.

Lemma reff420_not4080 : ~ @Equation4080 Fin5 reff420_inst.
Proof. unfold Equation4080. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff420_inst, reff420_op in H. discriminate H. Qed.

Lemma reff420_not4081 : ~ @Equation4081 Fin5 reff420_inst.
Proof. unfold Equation4081. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff420_inst, reff420_op in H. discriminate H. Qed.

Lemma reff420_not4083 : ~ @Equation4083 Fin5 reff420_inst.
Proof. unfold Equation4083. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff420_inst, reff420_op in H. discriminate H. Qed.

Lemma reff420_not4090 : ~ @Equation4090 Fin5 reff420_inst.
Proof. unfold Equation4090. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff420_inst, reff420_op in H. discriminate H. Qed.

Lemma reff420_not4091 : ~ @Equation4091 Fin5 reff420_inst.
Proof. unfold Equation4091. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff420_inst, reff420_op in H. discriminate H. Qed.

Lemma reff420_not4093 : ~ @Equation4093 Fin5 reff420_inst.
Proof. unfold Equation4093. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff420_inst, reff420_op in H. discriminate H. Qed.

Lemma reff420_not4120 : ~ @Equation4120 Fin5 reff420_inst.
Proof. unfold Equation4120. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff420_inst, reff420_op in H. discriminate H. Qed.

Lemma reff420_not4121 : ~ @Equation4121 Fin5 reff420_inst.
Proof. unfold Equation4121. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff420_inst, reff420_op in H. discriminate H. Qed.

Lemma reff420_not4127 : ~ @Equation4127 Fin5 reff420_inst.
Proof. unfold Equation4127. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff420_inst, reff420_op in H. discriminate H. Qed.

Lemma reff420_not4128 : ~ @Equation4128 Fin5 reff420_inst.
Proof. unfold Equation4128. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff420_inst, reff420_op in H. discriminate H. Qed.

Lemma reff420_not4131 : ~ @Equation4131 Fin5 reff420_inst.
Proof. unfold Equation4131. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff420_inst, reff420_op in H. discriminate H. Qed.

Lemma reff420_not4154 : ~ @Equation4154 Fin5 reff420_inst.
Proof. unfold Equation4154. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff420_inst, reff420_op in H. discriminate H. Qed.

Lemma reff420_not4155 : ~ @Equation4155 Fin5 reff420_inst.
Proof. unfold Equation4155. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff420_inst, reff420_op in H. discriminate H. Qed.

Lemma reff420_not4157 : ~ @Equation4157 Fin5 reff420_inst.
Proof. unfold Equation4157. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff420_inst, reff420_op in H. discriminate H. Qed.

Lemma reff420_not4158 : ~ @Equation4158 Fin5 reff420_inst.
Proof. unfold Equation4158. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff420_inst, reff420_op in H. discriminate H. Qed.

Lemma reff420_not4165 : ~ @Equation4165 Fin5 reff420_inst.
Proof. unfold Equation4165. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff420_inst, reff420_op in H. discriminate H. Qed.

Lemma reff420_not4167 : ~ @Equation4167 Fin5 reff420_inst.
Proof. unfold Equation4167. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff420_inst, reff420_op in H. discriminate H. Qed.

Lemma reff420_not4268 : ~ @Equation4268 Fin5 reff420_inst.
Proof. unfold Equation4268. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff420_inst, reff420_op in H. discriminate H. Qed.

Lemma reff420_not4269 : ~ @Equation4269 Fin5 reff420_inst.
Proof. unfold Equation4269. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff420_inst, reff420_op in H. discriminate H. Qed.

Lemma reff420_not4270 : ~ @Equation4270 Fin5 reff420_inst.
Proof. unfold Equation4270. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff420_inst, reff420_op in H. discriminate H. Qed.

Lemma reff420_not4272 : ~ @Equation4272 Fin5 reff420_inst.
Proof. unfold Equation4272. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff420_inst, reff420_op in H. discriminate H. Qed.

Lemma reff420_not4273 : ~ @Equation4273 Fin5 reff420_inst.
Proof. unfold Equation4273. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff420_inst, reff420_op in H. discriminate H. Qed.

Lemma reff420_not4276 : ~ @Equation4276 Fin5 reff420_inst.
Proof. unfold Equation4276. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff420_inst, reff420_op in H. discriminate H. Qed.

Lemma reff420_not4283 : ~ @Equation4283 Fin5 reff420_inst.
Proof. unfold Equation4283. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff420_inst, reff420_op in H. discriminate H. Qed.

Lemma reff420_not4284 : ~ @Equation4284 Fin5 reff420_inst.
Proof. unfold Equation4284. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff420_inst, reff420_op in H. discriminate H. Qed.

Lemma reff420_not4290 : ~ @Equation4290 Fin5 reff420_inst.
Proof. unfold Equation4290. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff420_inst, reff420_op in H. discriminate H. Qed.

Lemma reff420_not4291 : ~ @Equation4291 Fin5 reff420_inst.
Proof. unfold Equation4291. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff420_inst, reff420_op in H. discriminate H. Qed.

Lemma reff420_not4293 : ~ @Equation4293 Fin5 reff420_inst.
Proof. unfold Equation4293. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff420_inst, reff420_op in H. discriminate H. Qed.

Lemma reff420_not4314 : ~ @Equation4314 Fin5 reff420_inst.
Proof. unfold Equation4314. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff420_inst, reff420_op in H. discriminate H. Qed.

Lemma reff420_not4320 : ~ @Equation4320 Fin5 reff420_inst.
Proof. unfold Equation4320. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff420_inst, reff420_op in H. discriminate H. Qed.

Lemma reff420_not4343 : ~ @Equation4343 Fin5 reff420_inst.
Proof. unfold Equation4343. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff420_inst, reff420_op in H. discriminate H. Qed.

Lemma reff420_not4396 : ~ @Equation4396 Fin5 reff420_inst.
Proof. unfold Equation4396. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff420_inst, reff420_op in H. discriminate H. Qed.

Lemma reff420_not4398 : ~ @Equation4398 Fin5 reff420_inst.
Proof. unfold Equation4398. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff420_inst, reff420_op in H. discriminate H. Qed.

Lemma reff420_not4399 : ~ @Equation4399 Fin5 reff420_inst.
Proof. unfold Equation4399. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff420_inst, reff420_op in H. discriminate H. Qed.

Lemma reff420_not4405 : ~ @Equation4405 Fin5 reff420_inst.
Proof. unfold Equation4405. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff420_inst, reff420_op in H. discriminate H. Qed.

Lemma reff420_not4406 : ~ @Equation4406 Fin5 reff420_inst.
Proof. unfold Equation4406. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff420_inst, reff420_op in H. discriminate H. Qed.

Lemma reff420_not4408 : ~ @Equation4408 Fin5 reff420_inst.
Proof. unfold Equation4408. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff420_inst, reff420_op in H. discriminate H. Qed.

Lemma reff420_not4433 : ~ @Equation4433 Fin5 reff420_inst.
Proof. unfold Equation4433. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff420_inst, reff420_op in H. discriminate H. Qed.

Lemma reff420_not4436 : ~ @Equation4436 Fin5 reff420_inst.
Proof. unfold Equation4436. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff420_inst, reff420_op in H. discriminate H. Qed.

Lemma reff420_not4442 : ~ @Equation4442 Fin5 reff420_inst.
Proof. unfold Equation4442. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff420_inst, reff420_op in H. discriminate H. Qed.

Lemma reff420_not4445 : ~ @Equation4445 Fin5 reff420_inst.
Proof. unfold Equation4445. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff420_inst, reff420_op in H. discriminate H. Qed.

Lemma reff420_not4472 : ~ @Equation4472 Fin5 reff420_inst.
Proof. unfold Equation4472. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff420_inst, reff420_op in H. discriminate H. Qed.

Lemma reff420_not4473 : ~ @Equation4473 Fin5 reff420_inst.
Proof. unfold Equation4473. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff420_inst, reff420_op in H. discriminate H. Qed.

Lemma reff420_not4480 : ~ @Equation4480 Fin5 reff420_inst.
Proof. unfold Equation4480. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff420_inst, reff420_op in H. discriminate H. Qed.

Lemma reff420_not4482 : ~ @Equation4482 Fin5 reff420_inst.
Proof. unfold Equation4482. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff420_inst, reff420_op in H. discriminate H. Qed.

Lemma reff420_not4583 : ~ @Equation4583 Fin5 reff420_inst.
Proof. unfold Equation4583. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff420_inst, reff420_op in H. discriminate H. Qed.

Lemma reff420_not4584 : ~ @Equation4584 Fin5 reff420_inst.
Proof. unfold Equation4584. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff420_inst, reff420_op in H. discriminate H. Qed.

Lemma reff420_not4585 : ~ @Equation4585 Fin5 reff420_inst.
Proof. unfold Equation4585. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff420_inst, reff420_op in H. discriminate H. Qed.

Lemma reff420_not4587 : ~ @Equation4587 Fin5 reff420_inst.
Proof. unfold Equation4587. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff420_inst, reff420_op in H. discriminate H. Qed.

Lemma reff420_not4588 : ~ @Equation4588 Fin5 reff420_inst.
Proof. unfold Equation4588. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff420_inst, reff420_op in H. discriminate H. Qed.

Lemma reff420_not4590 : ~ @Equation4590 Fin5 reff420_inst.
Proof. unfold Equation4590. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff420_inst, reff420_op in H. discriminate H. Qed.

Lemma reff420_not4591 : ~ @Equation4591 Fin5 reff420_inst.
Proof. unfold Equation4591. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff420_inst, reff420_op in H. discriminate H. Qed.

Lemma reff420_not4598 : ~ @Equation4598 Fin5 reff420_inst.
Proof. unfold Equation4598. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff420_inst, reff420_op in H. discriminate H. Qed.

Lemma reff420_not4599 : ~ @Equation4599 Fin5 reff420_inst.
Proof. unfold Equation4599. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff420_inst, reff420_op in H. discriminate H. Qed.

Lemma reff420_not4606 : ~ @Equation4606 Fin5 reff420_inst.
Proof. unfold Equation4606. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff420_inst, reff420_op in H. discriminate H. Qed.

Lemma reff420_not4608 : ~ @Equation4608 Fin5 reff420_inst.
Proof. unfold Equation4608. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff420_inst, reff420_op in H. discriminate H. Qed.

Lemma reff420_not4629 : ~ @Equation4629 Fin5 reff420_inst.
Proof. unfold Equation4629. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff420_inst, reff420_op in H. discriminate H. Qed.

Lemma reff420_not4635 : ~ @Equation4635 Fin5 reff420_inst.
Proof. unfold Equation4635. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff420_inst, reff420_op in H. discriminate H. Qed.

Lemma reff420_not4658 : ~ @Equation4658 Fin5 reff420_inst.
Proof. unfold Equation4658. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff420_inst, reff420_op in H. discriminate H. Qed.

(** ---- reff422 (Fin4) ---- *)

Definition reff422_op (x y : Fin4) : Fin4 :=
  match x, y with
  | F4_0, F4_0 => F4_0 | F4_0, F4_1 => F4_3 | F4_0, F4_2 => F4_2 | F4_0, F4_3 => F4_1
  | F4_1, F4_0 => F4_1 | F4_1, F4_1 => F4_2 | F4_1, F4_2 => F4_3 | F4_1, F4_3 => F4_0
  | F4_2, F4_0 => F4_2 | F4_2, F4_1 => F4_1 | F4_2, F4_2 => F4_0 | F4_2, F4_3 => F4_3
  | F4_3, F4_0 => F4_3 | F4_3, F4_1 => F4_0 | F4_3, F4_2 => F4_1 | F4_3, F4_3 => F4_2
  end.

#[local] Instance reff422_inst : Magma Fin4 := {| magma_op := reff422_op |}.

Lemma reff422_sat26 : @Equation26 Fin4 reff422_inst.
Proof. unfold Equation26, magma_op, reff422_inst, reff422_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff422_sat452 : @Equation452 Fin4 reff422_inst.
Proof. unfold Equation452, magma_op, reff422_inst, reff422_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff422_sat546 : @Equation546 Fin4 reff422_inst.
Proof. unfold Equation546, magma_op, reff422_inst, reff422_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff422_sat562 : @Equation562 Fin4 reff422_inst.
Proof. unfold Equation562, magma_op, reff422_inst, reff422_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff422_sat861 : @Equation861 Fin4 reff422_inst.
Proof. unfold Equation861, magma_op, reff422_inst, reff422_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff422_sat949 : @Equation949 Fin4 reff422_inst.
Proof. unfold Equation949, magma_op, reff422_inst, reff422_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff422_sat962 : @Equation962 Fin4 reff422_inst.
Proof. unfold Equation962, magma_op, reff422_inst, reff422_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff422_sat1061 : @Equation1061 Fin4 reff422_inst.
Proof. unfold Equation1061, magma_op, reff422_inst, reff422_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff422_sat1155 : @Equation1155 Fin4 reff422_inst.
Proof. unfold Equation1155, magma_op, reff422_inst, reff422_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff422_sat1171 : @Equation1171 Fin4 reff422_inst.
Proof. unfold Equation1171, magma_op, reff422_inst, reff422_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff422_sat1790 : @Equation1790 Fin4 reff422_inst.
Proof. unfold Equation1790, magma_op, reff422_inst, reff422_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff422_sat1793 : @Equation1793 Fin4 reff422_inst.
Proof. unfold Equation1793, magma_op, reff422_inst, reff422_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff422_sat1967 : @Equation1967 Fin4 reff422_inst.
Proof. unfold Equation1967, magma_op, reff422_inst, reff422_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff422_sat1983 : @Equation1983 Fin4 reff422_inst.
Proof. unfold Equation1983, magma_op, reff422_inst, reff422_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff422_sat2573 : @Equation2573 Fin4 reff422_inst.
Proof. unfold Equation2573, magma_op, reff422_inst, reff422_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff422_sat2586 : @Equation2586 Fin4 reff422_inst.
Proof. unfold Equation2586, magma_op, reff422_inst, reff422_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff422_sat3601 : @Equation3601 Fin4 reff422_inst.
Proof. unfold Equation3601, magma_op, reff422_inst, reff422_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff422_sat3607 : @Equation3607 Fin4 reff422_inst.
Proof. unfold Equation3607, magma_op, reff422_inst, reff422_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff422_sat4143 : @Equation4143 Fin4 reff422_inst.
Proof. unfold Equation4143, magma_op, reff422_inst, reff422_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff422_sat4273 : @Equation4273 Fin4 reff422_inst.
Proof. unfold Equation4273, magma_op, reff422_inst, reff422_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff422_not47 : ~ @Equation47 Fin4 reff422_inst.
Proof. unfold Equation47. intro H. specialize (H F4_1). unfold magma_op, reff422_inst, reff422_op in H. discriminate H. Qed.

Lemma reff422_not99 : ~ @Equation99 Fin4 reff422_inst.
Proof. unfold Equation99. intro H. specialize (H F4_1). unfold magma_op, reff422_inst, reff422_op in H. discriminate H. Qed.

Lemma reff422_not151 : ~ @Equation151 Fin4 reff422_inst.
Proof. unfold Equation151. intro H. specialize (H F4_1). unfold magma_op, reff422_inst, reff422_op in H. discriminate H. Qed.

Lemma reff422_not203 : ~ @Equation203 Fin4 reff422_inst.
Proof. unfold Equation203. intro H. specialize (H F4_1). unfold magma_op, reff422_inst, reff422_op in H. discriminate H. Qed.

Lemma reff422_not255 : ~ @Equation255 Fin4 reff422_inst.
Proof. unfold Equation255. intro H. specialize (H F4_1). unfold magma_op, reff422_inst, reff422_op in H. discriminate H. Qed.

Lemma reff422_not359 : ~ @Equation359 Fin4 reff422_inst.
Proof. unfold Equation359. intro H. specialize (H F4_1). unfold magma_op, reff422_inst, reff422_op in H. discriminate H. Qed.

Lemma reff422_not412 : ~ @Equation412 Fin4 reff422_inst.
Proof. unfold Equation412. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff422_inst, reff422_op in H. discriminate H. Qed.

Lemma reff422_not413 : ~ @Equation413 Fin4 reff422_inst.
Proof. unfold Equation413. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff422_inst, reff422_op in H. discriminate H. Qed.

Lemma reff422_not414 : ~ @Equation414 Fin4 reff422_inst.
Proof. unfold Equation414. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff422_inst, reff422_op in H. discriminate H. Qed.

Lemma reff422_not416 : ~ @Equation416 Fin4 reff422_inst.
Proof. unfold Equation416. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff422_inst, reff422_op in H. discriminate H. Qed.

Lemma reff422_not419 : ~ @Equation419 Fin4 reff422_inst.
Proof. unfold Equation419. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff422_inst, reff422_op in H. discriminate H. Qed.

Lemma reff422_not420 : ~ @Equation420 Fin4 reff422_inst.
Proof. unfold Equation420. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff422_inst, reff422_op in H. discriminate H. Qed.

Lemma reff422_not426 : ~ @Equation426 Fin4 reff422_inst.
Proof. unfold Equation426. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff422_inst, reff422_op in H. discriminate H. Qed.

Lemma reff422_not427 : ~ @Equation427 Fin4 reff422_inst.
Proof. unfold Equation427. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff422_inst, reff422_op in H. discriminate H. Qed.

Lemma reff422_not430 : ~ @Equation430 Fin4 reff422_inst.
Proof. unfold Equation430. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff422_inst, reff422_op in H. discriminate H. Qed.

Lemma reff422_not436 : ~ @Equation436 Fin4 reff422_inst.
Proof. unfold Equation436. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff422_inst, reff422_op in H. discriminate H. Qed.

Lemma reff422_not437 : ~ @Equation437 Fin4 reff422_inst.
Proof. unfold Equation437. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff422_inst, reff422_op in H. discriminate H. Qed.

Lemma reff422_not439 : ~ @Equation439 Fin4 reff422_inst.
Proof. unfold Equation439. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff422_inst, reff422_op in H. discriminate H. Qed.

Lemma reff422_not463 : ~ @Equation463 Fin4 reff422_inst.
Proof. unfold Equation463. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff422_inst, reff422_op in H. discriminate H. Qed.

Lemma reff422_not466 : ~ @Equation466 Fin4 reff422_inst.
Proof. unfold Equation466. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff422_inst, reff422_op in H. discriminate H. Qed.

Lemma reff422_not467 : ~ @Equation467 Fin4 reff422_inst.
Proof. unfold Equation467. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff422_inst, reff422_op in H. discriminate H. Qed.

Lemma reff422_not474 : ~ @Equation474 Fin4 reff422_inst.
Proof. unfold Equation474. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff422_inst, reff422_op in H. discriminate H. Qed.

Lemma reff422_not476 : ~ @Equation476 Fin4 reff422_inst.
Proof. unfold Equation476. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff422_inst, reff422_op in H. discriminate H. Qed.

Lemma reff422_not477 : ~ @Equation477 Fin4 reff422_inst.
Proof. unfold Equation477. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff422_inst, reff422_op in H. discriminate H. Qed.

Lemma reff422_not500 : ~ @Equation500 Fin4 reff422_inst.
Proof. unfold Equation500. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff422_inst, reff422_op in H. discriminate H. Qed.

Lemma reff422_not501 : ~ @Equation501 Fin4 reff422_inst.
Proof. unfold Equation501. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff422_inst, reff422_op in H. discriminate H. Qed.

Lemma reff422_not503 : ~ @Equation503 Fin4 reff422_inst.
Proof. unfold Equation503. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff422_inst, reff422_op in H. discriminate H. Qed.

Lemma reff422_not510 : ~ @Equation510 Fin4 reff422_inst.
Proof. unfold Equation510. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff422_inst, reff422_op in H. discriminate H. Qed.

Lemma reff422_not511 : ~ @Equation511 Fin4 reff422_inst.
Proof. unfold Equation511. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff422_inst, reff422_op in H. discriminate H. Qed.

Lemma reff422_not614 : ~ @Equation614 Fin4 reff422_inst.
Proof. unfold Equation614. intro H. specialize (H F4_1). unfold magma_op, reff422_inst, reff422_op in H. discriminate H. Qed.

Lemma reff422_not818 : ~ @Equation818 Fin4 reff422_inst.
Proof. unfold Equation818. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff422_inst, reff422_op in H. discriminate H. Qed.

Lemma reff422_not819 : ~ @Equation819 Fin4 reff422_inst.
Proof. unfold Equation819. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff422_inst, reff422_op in H. discriminate H. Qed.

Lemma reff422_not820 : ~ @Equation820 Fin4 reff422_inst.
Proof. unfold Equation820. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff422_inst, reff422_op in H. discriminate H. Qed.

Lemma reff422_not822 : ~ @Equation822 Fin4 reff422_inst.
Proof. unfold Equation822. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff422_inst, reff422_op in H. discriminate H. Qed.

Lemma reff422_not823 : ~ @Equation823 Fin4 reff422_inst.
Proof. unfold Equation823. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff422_inst, reff422_op in H. discriminate H. Qed.

Lemma reff422_not826 : ~ @Equation826 Fin4 reff422_inst.
Proof. unfold Equation826. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff422_inst, reff422_op in H. discriminate H. Qed.

Lemma reff422_not832 : ~ @Equation832 Fin4 reff422_inst.
Proof. unfold Equation832. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff422_inst, reff422_op in H. discriminate H. Qed.

Lemma reff422_not835 : ~ @Equation835 Fin4 reff422_inst.
Proof. unfold Equation835. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff422_inst, reff422_op in H. discriminate H. Qed.

Lemma reff422_not836 : ~ @Equation836 Fin4 reff422_inst.
Proof. unfold Equation836. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff422_inst, reff422_op in H. discriminate H. Qed.

Lemma reff422_not842 : ~ @Equation842 Fin4 reff422_inst.
Proof. unfold Equation842. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff422_inst, reff422_op in H. discriminate H. Qed.

Lemma reff422_not843 : ~ @Equation843 Fin4 reff422_inst.
Proof. unfold Equation843. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff422_inst, reff422_op in H. discriminate H. Qed.

Lemma reff422_not845 : ~ @Equation845 Fin4 reff422_inst.
Proof. unfold Equation845. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff422_inst, reff422_op in H. discriminate H. Qed.

Lemma reff422_not869 : ~ @Equation869 Fin4 reff422_inst.
Proof. unfold Equation869. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff422_inst, reff422_op in H. discriminate H. Qed.

Lemma reff422_not870 : ~ @Equation870 Fin4 reff422_inst.
Proof. unfold Equation870. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff422_inst, reff422_op in H. discriminate H. Qed.

Lemma reff422_not873 : ~ @Equation873 Fin4 reff422_inst.
Proof. unfold Equation873. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff422_inst, reff422_op in H. discriminate H. Qed.

Lemma reff422_not880 : ~ @Equation880 Fin4 reff422_inst.
Proof. unfold Equation880. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff422_inst, reff422_op in H. discriminate H. Qed.

Lemma reff422_not882 : ~ @Equation882 Fin4 reff422_inst.
Proof. unfold Equation882. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff422_inst, reff422_op in H. discriminate H. Qed.

Lemma reff422_not883 : ~ @Equation883 Fin4 reff422_inst.
Proof. unfold Equation883. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff422_inst, reff422_op in H. discriminate H. Qed.

Lemma reff422_not906 : ~ @Equation906 Fin4 reff422_inst.
Proof. unfold Equation906. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff422_inst, reff422_op in H. discriminate H. Qed.

Lemma reff422_not907 : ~ @Equation907 Fin4 reff422_inst.
Proof. unfold Equation907. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff422_inst, reff422_op in H. discriminate H. Qed.

Lemma reff422_not909 : ~ @Equation909 Fin4 reff422_inst.
Proof. unfold Equation909. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff422_inst, reff422_op in H. discriminate H. Qed.

Lemma reff422_not916 : ~ @Equation916 Fin4 reff422_inst.
Proof. unfold Equation916. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff422_inst, reff422_op in H. discriminate H. Qed.

Lemma reff422_not919 : ~ @Equation919 Fin4 reff422_inst.
Proof. unfold Equation919. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff422_inst, reff422_op in H. discriminate H. Qed.

Lemma reff422_not1021 : ~ @Equation1021 Fin4 reff422_inst.
Proof. unfold Equation1021. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff422_inst, reff422_op in H. discriminate H. Qed.

Lemma reff422_not1022 : ~ @Equation1022 Fin4 reff422_inst.
Proof. unfold Equation1022. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff422_inst, reff422_op in H. discriminate H. Qed.

Lemma reff422_not1023 : ~ @Equation1023 Fin4 reff422_inst.
Proof. unfold Equation1023. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff422_inst, reff422_op in H. discriminate H. Qed.

Lemma reff422_not1025 : ~ @Equation1025 Fin4 reff422_inst.
Proof. unfold Equation1025. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff422_inst, reff422_op in H. discriminate H. Qed.

Lemma reff422_not1028 : ~ @Equation1028 Fin4 reff422_inst.
Proof. unfold Equation1028. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff422_inst, reff422_op in H. discriminate H. Qed.

Lemma reff422_not1029 : ~ @Equation1029 Fin4 reff422_inst.
Proof. unfold Equation1029. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff422_inst, reff422_op in H. discriminate H. Qed.

Lemma reff422_not1035 : ~ @Equation1035 Fin4 reff422_inst.
Proof. unfold Equation1035. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff422_inst, reff422_op in H. discriminate H. Qed.

Lemma reff422_not1036 : ~ @Equation1036 Fin4 reff422_inst.
Proof. unfold Equation1036. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff422_inst, reff422_op in H. discriminate H. Qed.

Lemma reff422_not1039 : ~ @Equation1039 Fin4 reff422_inst.
Proof. unfold Equation1039. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff422_inst, reff422_op in H. discriminate H. Qed.

Lemma reff422_not1045 : ~ @Equation1045 Fin4 reff422_inst.
Proof. unfold Equation1045. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff422_inst, reff422_op in H. discriminate H. Qed.

Lemma reff422_not1046 : ~ @Equation1046 Fin4 reff422_inst.
Proof. unfold Equation1046. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff422_inst, reff422_op in H. discriminate H. Qed.

Lemma reff422_not1048 : ~ @Equation1048 Fin4 reff422_inst.
Proof. unfold Equation1048. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff422_inst, reff422_op in H. discriminate H. Qed.

Lemma reff422_not1072 : ~ @Equation1072 Fin4 reff422_inst.
Proof. unfold Equation1072. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff422_inst, reff422_op in H. discriminate H. Qed.

Lemma reff422_not1075 : ~ @Equation1075 Fin4 reff422_inst.
Proof. unfold Equation1075. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff422_inst, reff422_op in H. discriminate H. Qed.

Lemma reff422_not1076 : ~ @Equation1076 Fin4 reff422_inst.
Proof. unfold Equation1076. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff422_inst, reff422_op in H. discriminate H. Qed.

Lemma reff422_not1083 : ~ @Equation1083 Fin4 reff422_inst.
Proof. unfold Equation1083. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff422_inst, reff422_op in H. discriminate H. Qed.

Lemma reff422_not1085 : ~ @Equation1085 Fin4 reff422_inst.
Proof. unfold Equation1085. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff422_inst, reff422_op in H. discriminate H. Qed.

Lemma reff422_not1086 : ~ @Equation1086 Fin4 reff422_inst.
Proof. unfold Equation1086. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff422_inst, reff422_op in H. discriminate H. Qed.

Lemma reff422_not1109 : ~ @Equation1109 Fin4 reff422_inst.
Proof. unfold Equation1109. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff422_inst, reff422_op in H. discriminate H. Qed.

Lemma reff422_not1110 : ~ @Equation1110 Fin4 reff422_inst.
Proof. unfold Equation1110. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff422_inst, reff422_op in H. discriminate H. Qed.

Lemma reff422_not1112 : ~ @Equation1112 Fin4 reff422_inst.
Proof. unfold Equation1112. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff422_inst, reff422_op in H. discriminate H. Qed.

Lemma reff422_not1119 : ~ @Equation1119 Fin4 reff422_inst.
Proof. unfold Equation1119. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff422_inst, reff422_op in H. discriminate H. Qed.

Lemma reff422_not1120 : ~ @Equation1120 Fin4 reff422_inst.
Proof. unfold Equation1120. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff422_inst, reff422_op in H. discriminate H. Qed.

Lemma reff422_not1223 : ~ @Equation1223 Fin4 reff422_inst.
Proof. unfold Equation1223. intro H. specialize (H F4_1). unfold magma_op, reff422_inst, reff422_op in H. discriminate H. Qed.

Lemma reff422_not1426 : ~ @Equation1426 Fin4 reff422_inst.
Proof. unfold Equation1426. intro H. specialize (H F4_1). unfold magma_op, reff422_inst, reff422_op in H. discriminate H. Qed.

Lemma reff422_not1630 : ~ @Equation1630 Fin4 reff422_inst.
Proof. unfold Equation1630. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff422_inst, reff422_op in H. discriminate H. Qed.

Lemma reff422_not1631 : ~ @Equation1631 Fin4 reff422_inst.
Proof. unfold Equation1631. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff422_inst, reff422_op in H. discriminate H. Qed.

Lemma reff422_not1634 : ~ @Equation1634 Fin4 reff422_inst.
Proof. unfold Equation1634. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff422_inst, reff422_op in H. discriminate H. Qed.

Lemma reff422_not1635 : ~ @Equation1635 Fin4 reff422_inst.
Proof. unfold Equation1635. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff422_inst, reff422_op in H. discriminate H. Qed.

Lemma reff422_not1637 : ~ @Equation1637 Fin4 reff422_inst.
Proof. unfold Equation1637. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff422_inst, reff422_op in H. discriminate H. Qed.

Lemma reff422_not1638 : ~ @Equation1638 Fin4 reff422_inst.
Proof. unfold Equation1638. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff422_inst, reff422_op in H. discriminate H. Qed.

Lemma reff422_not1644 : ~ @Equation1644 Fin4 reff422_inst.
Proof. unfold Equation1644. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff422_inst, reff422_op in H. discriminate H. Qed.

Lemma reff422_not1645 : ~ @Equation1645 Fin4 reff422_inst.
Proof. unfold Equation1645. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff422_inst, reff422_op in H. discriminate H. Qed.

Lemma reff422_not1647 : ~ @Equation1647 Fin4 reff422_inst.
Proof. unfold Equation1647. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff422_inst, reff422_op in H. discriminate H. Qed.

Lemma reff422_not1648 : ~ @Equation1648 Fin4 reff422_inst.
Proof. unfold Equation1648. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff422_inst, reff422_op in H. discriminate H. Qed.

Lemma reff422_not1655 : ~ @Equation1655 Fin4 reff422_inst.
Proof. unfold Equation1655. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff422_inst, reff422_op in H. discriminate H. Qed.

Lemma reff422_not1657 : ~ @Equation1657 Fin4 reff422_inst.
Proof. unfold Equation1657. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff422_inst, reff422_op in H. discriminate H. Qed.

Lemma reff422_not1681 : ~ @Equation1681 Fin4 reff422_inst.
Proof. unfold Equation1681. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff422_inst, reff422_op in H. discriminate H. Qed.

Lemma reff422_not1685 : ~ @Equation1685 Fin4 reff422_inst.
Proof. unfold Equation1685. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff422_inst, reff422_op in H. discriminate H. Qed.

Lemma reff422_not1691 : ~ @Equation1691 Fin4 reff422_inst.
Proof. unfold Equation1691. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff422_inst, reff422_op in H. discriminate H. Qed.

Lemma reff422_not1692 : ~ @Equation1692 Fin4 reff422_inst.
Proof. unfold Equation1692. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff422_inst, reff422_op in H. discriminate H. Qed.

Lemma reff422_not1694 : ~ @Equation1694 Fin4 reff422_inst.
Proof. unfold Equation1694. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff422_inst, reff422_op in H. discriminate H. Qed.

Lemma reff422_not1695 : ~ @Equation1695 Fin4 reff422_inst.
Proof. unfold Equation1695. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff422_inst, reff422_op in H. discriminate H. Qed.

Lemma reff422_not1718 : ~ @Equation1718 Fin4 reff422_inst.
Proof. unfold Equation1718. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff422_inst, reff422_op in H. discriminate H. Qed.

Lemma reff422_not1719 : ~ @Equation1719 Fin4 reff422_inst.
Proof. unfold Equation1719. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff422_inst, reff422_op in H. discriminate H. Qed.

Lemma reff422_not1721 : ~ @Equation1721 Fin4 reff422_inst.
Proof. unfold Equation1721. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff422_inst, reff422_op in H. discriminate H. Qed.

Lemma reff422_not1722 : ~ @Equation1722 Fin4 reff422_inst.
Proof. unfold Equation1722. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff422_inst, reff422_op in H. discriminate H. Qed.

Lemma reff422_not1728 : ~ @Equation1728 Fin4 reff422_inst.
Proof. unfold Equation1728. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff422_inst, reff422_op in H. discriminate H. Qed.

Lemma reff422_not1833 : ~ @Equation1833 Fin4 reff422_inst.
Proof. unfold Equation1833. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff422_inst, reff422_op in H. discriminate H. Qed.

Lemma reff422_not1834 : ~ @Equation1834 Fin4 reff422_inst.
Proof. unfold Equation1834. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff422_inst, reff422_op in H. discriminate H. Qed.

Lemma reff422_not1835 : ~ @Equation1835 Fin4 reff422_inst.
Proof. unfold Equation1835. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff422_inst, reff422_op in H. discriminate H. Qed.

Lemma reff422_not1837 : ~ @Equation1837 Fin4 reff422_inst.
Proof. unfold Equation1837. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff422_inst, reff422_op in H. discriminate H. Qed.

Lemma reff422_not1840 : ~ @Equation1840 Fin4 reff422_inst.
Proof. unfold Equation1840. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff422_inst, reff422_op in H. discriminate H. Qed.

Lemma reff422_not1841 : ~ @Equation1841 Fin4 reff422_inst.
Proof. unfold Equation1841. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff422_inst, reff422_op in H. discriminate H. Qed.

Lemma reff422_not1847 : ~ @Equation1847 Fin4 reff422_inst.
Proof. unfold Equation1847. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff422_inst, reff422_op in H. discriminate H. Qed.

Lemma reff422_not1848 : ~ @Equation1848 Fin4 reff422_inst.
Proof. unfold Equation1848. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff422_inst, reff422_op in H. discriminate H. Qed.

Lemma reff422_not1851 : ~ @Equation1851 Fin4 reff422_inst.
Proof. unfold Equation1851. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff422_inst, reff422_op in H. discriminate H. Qed.

Lemma reff422_not1857 : ~ @Equation1857 Fin4 reff422_inst.
Proof. unfold Equation1857. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff422_inst, reff422_op in H. discriminate H. Qed.

Lemma reff422_not1858 : ~ @Equation1858 Fin4 reff422_inst.
Proof. unfold Equation1858. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff422_inst, reff422_op in H. discriminate H. Qed.

Lemma reff422_not1860 : ~ @Equation1860 Fin4 reff422_inst.
Proof. unfold Equation1860. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff422_inst, reff422_op in H. discriminate H. Qed.

Lemma reff422_not1884 : ~ @Equation1884 Fin4 reff422_inst.
Proof. unfold Equation1884. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff422_inst, reff422_op in H. discriminate H. Qed.

Lemma reff422_not1887 : ~ @Equation1887 Fin4 reff422_inst.
Proof. unfold Equation1887. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff422_inst, reff422_op in H. discriminate H. Qed.

Lemma reff422_not1888 : ~ @Equation1888 Fin4 reff422_inst.
Proof. unfold Equation1888. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff422_inst, reff422_op in H. discriminate H. Qed.

Lemma reff422_not1895 : ~ @Equation1895 Fin4 reff422_inst.
Proof. unfold Equation1895. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff422_inst, reff422_op in H. discriminate H. Qed.

Lemma reff422_not1897 : ~ @Equation1897 Fin4 reff422_inst.
Proof. unfold Equation1897. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff422_inst, reff422_op in H. discriminate H. Qed.

Lemma reff422_not1898 : ~ @Equation1898 Fin4 reff422_inst.
Proof. unfold Equation1898. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff422_inst, reff422_op in H. discriminate H. Qed.

Lemma reff422_not1921 : ~ @Equation1921 Fin4 reff422_inst.
Proof. unfold Equation1921. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff422_inst, reff422_op in H. discriminate H. Qed.

Lemma reff422_not1922 : ~ @Equation1922 Fin4 reff422_inst.
Proof. unfold Equation1922. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff422_inst, reff422_op in H. discriminate H. Qed.

Lemma reff422_not1924 : ~ @Equation1924 Fin4 reff422_inst.
Proof. unfold Equation1924. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff422_inst, reff422_op in H. discriminate H. Qed.

Lemma reff422_not1931 : ~ @Equation1931 Fin4 reff422_inst.
Proof. unfold Equation1931. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff422_inst, reff422_op in H. discriminate H. Qed.

Lemma reff422_not1932 : ~ @Equation1932 Fin4 reff422_inst.
Proof. unfold Equation1932. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff422_inst, reff422_op in H. discriminate H. Qed.

Lemma reff422_not2035 : ~ @Equation2035 Fin4 reff422_inst.
Proof. unfold Equation2035. intro H. specialize (H F4_1). unfold magma_op, reff422_inst, reff422_op in H. discriminate H. Qed.

Lemma reff422_not2238 : ~ @Equation2238 Fin4 reff422_inst.
Proof. unfold Equation2238. intro H. specialize (H F4_1). unfold magma_op, reff422_inst, reff422_op in H. discriminate H. Qed.

Lemma reff422_not2442 : ~ @Equation2442 Fin4 reff422_inst.
Proof. unfold Equation2442. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff422_inst, reff422_op in H. discriminate H. Qed.

Lemma reff422_not2443 : ~ @Equation2443 Fin4 reff422_inst.
Proof. unfold Equation2443. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff422_inst, reff422_op in H. discriminate H. Qed.

Lemma reff422_not2444 : ~ @Equation2444 Fin4 reff422_inst.
Proof. unfold Equation2444. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff422_inst, reff422_op in H. discriminate H. Qed.

Lemma reff422_not2446 : ~ @Equation2446 Fin4 reff422_inst.
Proof. unfold Equation2446. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff422_inst, reff422_op in H. discriminate H. Qed.

Lemma reff422_not2447 : ~ @Equation2447 Fin4 reff422_inst.
Proof. unfold Equation2447. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff422_inst, reff422_op in H. discriminate H. Qed.

Lemma reff422_not2450 : ~ @Equation2450 Fin4 reff422_inst.
Proof. unfold Equation2450. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff422_inst, reff422_op in H. discriminate H. Qed.

Lemma reff422_not2456 : ~ @Equation2456 Fin4 reff422_inst.
Proof. unfold Equation2456. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff422_inst, reff422_op in H. discriminate H. Qed.

Lemma reff422_not2459 : ~ @Equation2459 Fin4 reff422_inst.
Proof. unfold Equation2459. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff422_inst, reff422_op in H. discriminate H. Qed.

Lemma reff422_not2460 : ~ @Equation2460 Fin4 reff422_inst.
Proof. unfold Equation2460. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff422_inst, reff422_op in H. discriminate H. Qed.

Lemma reff422_not2466 : ~ @Equation2466 Fin4 reff422_inst.
Proof. unfold Equation2466. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff422_inst, reff422_op in H. discriminate H. Qed.

Lemma reff422_not2467 : ~ @Equation2467 Fin4 reff422_inst.
Proof. unfold Equation2467. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff422_inst, reff422_op in H. discriminate H. Qed.

Lemma reff422_not2469 : ~ @Equation2469 Fin4 reff422_inst.
Proof. unfold Equation2469. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff422_inst, reff422_op in H. discriminate H. Qed.

Lemma reff422_not2493 : ~ @Equation2493 Fin4 reff422_inst.
Proof. unfold Equation2493. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff422_inst, reff422_op in H. discriminate H. Qed.

Lemma reff422_not2494 : ~ @Equation2494 Fin4 reff422_inst.
Proof. unfold Equation2494. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff422_inst, reff422_op in H. discriminate H. Qed.

Lemma reff422_not2497 : ~ @Equation2497 Fin4 reff422_inst.
Proof. unfold Equation2497. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff422_inst, reff422_op in H. discriminate H. Qed.

Lemma reff422_not2504 : ~ @Equation2504 Fin4 reff422_inst.
Proof. unfold Equation2504. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff422_inst, reff422_op in H. discriminate H. Qed.

Lemma reff422_not2506 : ~ @Equation2506 Fin4 reff422_inst.
Proof. unfold Equation2506. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff422_inst, reff422_op in H. discriminate H. Qed.

Lemma reff422_not2507 : ~ @Equation2507 Fin4 reff422_inst.
Proof. unfold Equation2507. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff422_inst, reff422_op in H. discriminate H. Qed.

Lemma reff422_not2530 : ~ @Equation2530 Fin4 reff422_inst.
Proof. unfold Equation2530. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff422_inst, reff422_op in H. discriminate H. Qed.

Lemma reff422_not2531 : ~ @Equation2531 Fin4 reff422_inst.
Proof. unfold Equation2531. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff422_inst, reff422_op in H. discriminate H. Qed.

Lemma reff422_not2533 : ~ @Equation2533 Fin4 reff422_inst.
Proof. unfold Equation2533. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff422_inst, reff422_op in H. discriminate H. Qed.

Lemma reff422_not2540 : ~ @Equation2540 Fin4 reff422_inst.
Proof. unfold Equation2540. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff422_inst, reff422_op in H. discriminate H. Qed.

Lemma reff422_not2543 : ~ @Equation2543 Fin4 reff422_inst.
Proof. unfold Equation2543. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff422_inst, reff422_op in H. discriminate H. Qed.

Lemma reff422_not2644 : ~ @Equation2644 Fin4 reff422_inst.
Proof. unfold Equation2644. intro H. specialize (H F4_1). unfold magma_op, reff422_inst, reff422_op in H. discriminate H. Qed.

Lemma reff422_not2847 : ~ @Equation2847 Fin4 reff422_inst.
Proof. unfold Equation2847. intro H. specialize (H F4_1). unfold magma_op, reff422_inst, reff422_op in H. discriminate H. Qed.

Lemma reff422_not3051 : ~ @Equation3051 Fin4 reff422_inst.
Proof. unfold Equation3051. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff422_inst, reff422_op in H. discriminate H. Qed.

Lemma reff422_not3052 : ~ @Equation3052 Fin4 reff422_inst.
Proof. unfold Equation3052. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff422_inst, reff422_op in H. discriminate H. Qed.

Lemma reff422_not3055 : ~ @Equation3055 Fin4 reff422_inst.
Proof. unfold Equation3055. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff422_inst, reff422_op in H. discriminate H. Qed.

Lemma reff422_not3059 : ~ @Equation3059 Fin4 reff422_inst.
Proof. unfold Equation3059. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff422_inst, reff422_op in H. discriminate H. Qed.

Lemma reff422_not3065 : ~ @Equation3065 Fin4 reff422_inst.
Proof. unfold Equation3065. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff422_inst, reff422_op in H. discriminate H. Qed.

Lemma reff422_not3069 : ~ @Equation3069 Fin4 reff422_inst.
Proof. unfold Equation3069. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff422_inst, reff422_op in H. discriminate H. Qed.

Lemma reff422_not3076 : ~ @Equation3076 Fin4 reff422_inst.
Proof. unfold Equation3076. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff422_inst, reff422_op in H. discriminate H. Qed.

Lemma reff422_not3078 : ~ @Equation3078 Fin4 reff422_inst.
Proof. unfold Equation3078. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff422_inst, reff422_op in H. discriminate H. Qed.

Lemma reff422_not3102 : ~ @Equation3102 Fin4 reff422_inst.
Proof. unfold Equation3102. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff422_inst, reff422_op in H. discriminate H. Qed.

Lemma reff422_not3103 : ~ @Equation3103 Fin4 reff422_inst.
Proof. unfold Equation3103. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff422_inst, reff422_op in H. discriminate H. Qed.

Lemma reff422_not3105 : ~ @Equation3105 Fin4 reff422_inst.
Proof. unfold Equation3105. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff422_inst, reff422_op in H. discriminate H. Qed.

Lemma reff422_not3106 : ~ @Equation3106 Fin4 reff422_inst.
Proof. unfold Equation3106. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff422_inst, reff422_op in H. discriminate H. Qed.

Lemma reff422_not3112 : ~ @Equation3112 Fin4 reff422_inst.
Proof. unfold Equation3112. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff422_inst, reff422_op in H. discriminate H. Qed.

Lemma reff422_not3113 : ~ @Equation3113 Fin4 reff422_inst.
Proof. unfold Equation3113. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff422_inst, reff422_op in H. discriminate H. Qed.

Lemma reff422_not3115 : ~ @Equation3115 Fin4 reff422_inst.
Proof. unfold Equation3115. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff422_inst, reff422_op in H. discriminate H. Qed.

Lemma reff422_not3116 : ~ @Equation3116 Fin4 reff422_inst.
Proof. unfold Equation3116. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff422_inst, reff422_op in H. discriminate H. Qed.

Lemma reff422_not3139 : ~ @Equation3139 Fin4 reff422_inst.
Proof. unfold Equation3139. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff422_inst, reff422_op in H. discriminate H. Qed.

Lemma reff422_not3140 : ~ @Equation3140 Fin4 reff422_inst.
Proof. unfold Equation3140. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff422_inst, reff422_op in H. discriminate H. Qed.

Lemma reff422_not3142 : ~ @Equation3142 Fin4 reff422_inst.
Proof. unfold Equation3142. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff422_inst, reff422_op in H. discriminate H. Qed.

Lemma reff422_not3143 : ~ @Equation3143 Fin4 reff422_inst.
Proof. unfold Equation3143. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff422_inst, reff422_op in H. discriminate H. Qed.

Lemma reff422_not3149 : ~ @Equation3149 Fin4 reff422_inst.
Proof. unfold Equation3149. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff422_inst, reff422_op in H. discriminate H. Qed.

Lemma reff422_not3150 : ~ @Equation3150 Fin4 reff422_inst.
Proof. unfold Equation3150. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff422_inst, reff422_op in H. discriminate H. Qed.

Lemma reff422_not3152 : ~ @Equation3152 Fin4 reff422_inst.
Proof. unfold Equation3152. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff422_inst, reff422_op in H. discriminate H. Qed.

Lemma reff422_not3253 : ~ @Equation3253 Fin4 reff422_inst.
Proof. unfold Equation3253. intro H. specialize (H F4_1). unfold magma_op, reff422_inst, reff422_op in H. discriminate H. Qed.

Lemma reff422_not3457 : ~ @Equation3457 Fin4 reff422_inst.
Proof. unfold Equation3457. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff422_inst, reff422_op in H. discriminate H. Qed.

Lemma reff422_not3458 : ~ @Equation3458 Fin4 reff422_inst.
Proof. unfold Equation3458. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff422_inst, reff422_op in H. discriminate H. Qed.

Lemma reff422_not3461 : ~ @Equation3461 Fin4 reff422_inst.
Proof. unfold Equation3461. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff422_inst, reff422_op in H. discriminate H. Qed.

Lemma reff422_not3462 : ~ @Equation3462 Fin4 reff422_inst.
Proof. unfold Equation3462. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff422_inst, reff422_op in H. discriminate H. Qed.

Lemma reff422_not3464 : ~ @Equation3464 Fin4 reff422_inst.
Proof. unfold Equation3464. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff422_inst, reff422_op in H. discriminate H. Qed.

Lemma reff422_not3465 : ~ @Equation3465 Fin4 reff422_inst.
Proof. unfold Equation3465. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff422_inst, reff422_op in H. discriminate H. Qed.

Lemma reff422_not3475 : ~ @Equation3475 Fin4 reff422_inst.
Proof. unfold Equation3475. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff422_inst, reff422_op in H. discriminate H. Qed.

Lemma reff422_not3481 : ~ @Equation3481 Fin4 reff422_inst.
Proof. unfold Equation3481. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff422_inst, reff422_op in H. discriminate H. Qed.

Lemma reff422_not3482 : ~ @Equation3482 Fin4 reff422_inst.
Proof. unfold Equation3482. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff422_inst, reff422_op in H. discriminate H. Qed.

Lemma reff422_not3484 : ~ @Equation3484 Fin4 reff422_inst.
Proof. unfold Equation3484. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff422_inst, reff422_op in H. discriminate H. Qed.

Lemma reff422_not3509 : ~ @Equation3509 Fin4 reff422_inst.
Proof. unfold Equation3509. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff422_inst, reff422_op in H. discriminate H. Qed.

Lemma reff422_not3511 : ~ @Equation3511 Fin4 reff422_inst.
Proof. unfold Equation3511. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff422_inst, reff422_op in H. discriminate H. Qed.

Lemma reff422_not3512 : ~ @Equation3512 Fin4 reff422_inst.
Proof. unfold Equation3512. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff422_inst, reff422_op in H. discriminate H. Qed.

Lemma reff422_not3519 : ~ @Equation3519 Fin4 reff422_inst.
Proof. unfold Equation3519. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff422_inst, reff422_op in H. discriminate H. Qed.

Lemma reff422_not3521 : ~ @Equation3521 Fin4 reff422_inst.
Proof. unfold Equation3521. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff422_inst, reff422_op in H. discriminate H. Qed.

Lemma reff422_not3545 : ~ @Equation3545 Fin4 reff422_inst.
Proof. unfold Equation3545. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff422_inst, reff422_op in H. discriminate H. Qed.

Lemma reff422_not3546 : ~ @Equation3546 Fin4 reff422_inst.
Proof. unfold Equation3546. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff422_inst, reff422_op in H. discriminate H. Qed.

Lemma reff422_not3548 : ~ @Equation3548 Fin4 reff422_inst.
Proof. unfold Equation3548. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff422_inst, reff422_op in H. discriminate H. Qed.

Lemma reff422_not3549 : ~ @Equation3549 Fin4 reff422_inst.
Proof. unfold Equation3549. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff422_inst, reff422_op in H. discriminate H. Qed.

Lemma reff422_not3555 : ~ @Equation3555 Fin4 reff422_inst.
Proof. unfold Equation3555. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff422_inst, reff422_op in H. discriminate H. Qed.

Lemma reff422_not3659 : ~ @Equation3659 Fin4 reff422_inst.
Proof. unfold Equation3659. intro H. specialize (H F4_1). unfold magma_op, reff422_inst, reff422_op in H. discriminate H. Qed.

Lemma reff422_not3862 : ~ @Equation3862 Fin4 reff422_inst.
Proof. unfold Equation3862. intro H. specialize (H F4_1). unfold magma_op, reff422_inst, reff422_op in H. discriminate H. Qed.

Lemma reff422_not4066 : ~ @Equation4066 Fin4 reff422_inst.
Proof. unfold Equation4066. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff422_inst, reff422_op in H. discriminate H. Qed.

Lemma reff422_not4067 : ~ @Equation4067 Fin4 reff422_inst.
Proof. unfold Equation4067. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff422_inst, reff422_op in H. discriminate H. Qed.

Lemma reff422_not4070 : ~ @Equation4070 Fin4 reff422_inst.
Proof. unfold Equation4070. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff422_inst, reff422_op in H. discriminate H. Qed.

Lemma reff422_not4074 : ~ @Equation4074 Fin4 reff422_inst.
Proof. unfold Equation4074. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff422_inst, reff422_op in H. discriminate H. Qed.

Lemma reff422_not4080 : ~ @Equation4080 Fin4 reff422_inst.
Proof. unfold Equation4080. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff422_inst, reff422_op in H. discriminate H. Qed.

Lemma reff422_not4083 : ~ @Equation4083 Fin4 reff422_inst.
Proof. unfold Equation4083. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff422_inst, reff422_op in H. discriminate H. Qed.

Lemma reff422_not4084 : ~ @Equation4084 Fin4 reff422_inst.
Proof. unfold Equation4084. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff422_inst, reff422_op in H. discriminate H. Qed.

Lemma reff422_not4090 : ~ @Equation4090 Fin4 reff422_inst.
Proof. unfold Equation4090. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff422_inst, reff422_op in H. discriminate H. Qed.

Lemma reff422_not4091 : ~ @Equation4091 Fin4 reff422_inst.
Proof. unfold Equation4091. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff422_inst, reff422_op in H. discriminate H. Qed.

Lemma reff422_not4093 : ~ @Equation4093 Fin4 reff422_inst.
Proof. unfold Equation4093. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff422_inst, reff422_op in H. discriminate H. Qed.

Lemma reff422_not4121 : ~ @Equation4121 Fin4 reff422_inst.
Proof. unfold Equation4121. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff422_inst, reff422_op in H. discriminate H. Qed.

Lemma reff422_not4128 : ~ @Equation4128 Fin4 reff422_inst.
Proof. unfold Equation4128. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff422_inst, reff422_op in H. discriminate H. Qed.

Lemma reff422_not4130 : ~ @Equation4130 Fin4 reff422_inst.
Proof. unfold Equation4130. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff422_inst, reff422_op in H. discriminate H. Qed.

Lemma reff422_not4155 : ~ @Equation4155 Fin4 reff422_inst.
Proof. unfold Equation4155. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff422_inst, reff422_op in H. discriminate H. Qed.

Lemma reff422_not4157 : ~ @Equation4157 Fin4 reff422_inst.
Proof. unfold Equation4157. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff422_inst, reff422_op in H. discriminate H. Qed.

Lemma reff422_not4158 : ~ @Equation4158 Fin4 reff422_inst.
Proof. unfold Equation4158. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff422_inst, reff422_op in H. discriminate H. Qed.

Lemma reff422_not4164 : ~ @Equation4164 Fin4 reff422_inst.
Proof. unfold Equation4164. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff422_inst, reff422_op in H. discriminate H. Qed.

Lemma reff422_not4165 : ~ @Equation4165 Fin4 reff422_inst.
Proof. unfold Equation4165. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff422_inst, reff422_op in H. discriminate H. Qed.

Lemma reff422_not4167 : ~ @Equation4167 Fin4 reff422_inst.
Proof. unfold Equation4167. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff422_inst, reff422_op in H. discriminate H. Qed.

Lemma reff422_not4268 : ~ @Equation4268 Fin4 reff422_inst.
Proof. unfold Equation4268. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff422_inst, reff422_op in H. discriminate H. Qed.

Lemma reff422_not4269 : ~ @Equation4269 Fin4 reff422_inst.
Proof. unfold Equation4269. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff422_inst, reff422_op in H. discriminate H. Qed.

Lemma reff422_not4270 : ~ @Equation4270 Fin4 reff422_inst.
Proof. unfold Equation4270. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff422_inst, reff422_op in H. discriminate H. Qed.

Lemma reff422_not4272 : ~ @Equation4272 Fin4 reff422_inst.
Proof. unfold Equation4272. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff422_inst, reff422_op in H. discriminate H. Qed.

Lemma reff422_not4275 : ~ @Equation4275 Fin4 reff422_inst.
Proof. unfold Equation4275. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff422_inst, reff422_op in H. discriminate H. Qed.

Lemma reff422_not4276 : ~ @Equation4276 Fin4 reff422_inst.
Proof. unfold Equation4276. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff422_inst, reff422_op in H. discriminate H. Qed.

Lemma reff422_not4283 : ~ @Equation4283 Fin4 reff422_inst.
Proof. unfold Equation4283. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff422_inst, reff422_op in H. discriminate H. Qed.

Lemma reff422_not4284 : ~ @Equation4284 Fin4 reff422_inst.
Proof. unfold Equation4284. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff422_inst, reff422_op in H. discriminate H. Qed.

Lemma reff422_not4291 : ~ @Equation4291 Fin4 reff422_inst.
Proof. unfold Equation4291. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff422_inst, reff422_op in H. discriminate H. Qed.

Lemma reff422_not4293 : ~ @Equation4293 Fin4 reff422_inst.
Proof. unfold Equation4293. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff422_inst, reff422_op in H. discriminate H. Qed.

Lemma reff422_not4314 : ~ @Equation4314 Fin4 reff422_inst.
Proof. unfold Equation4314. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff422_inst, reff422_op in H. discriminate H. Qed.

Lemma reff422_not4320 : ~ @Equation4320 Fin4 reff422_inst.
Proof. unfold Equation4320. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff422_inst, reff422_op in H. discriminate H. Qed.

Lemma reff422_not4321 : ~ @Equation4321 Fin4 reff422_inst.
Proof. unfold Equation4321. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff422_inst, reff422_op in H. discriminate H. Qed.

Lemma reff422_not4343 : ~ @Equation4343 Fin4 reff422_inst.
Proof. unfold Equation4343. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff422_inst, reff422_op in H. discriminate H. Qed.

Lemma reff422_not4380 : ~ @Equation4380 Fin4 reff422_inst.
Proof. unfold Equation4380. intro H. specialize (H F4_1). unfold magma_op, reff422_inst, reff422_op in H. discriminate H. Qed.

Lemma reff422_not4583 : ~ @Equation4583 Fin4 reff422_inst.
Proof. unfold Equation4583. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff422_inst, reff422_op in H. discriminate H. Qed.

Lemma reff422_not4584 : ~ @Equation4584 Fin4 reff422_inst.
Proof. unfold Equation4584. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff422_inst, reff422_op in H. discriminate H. Qed.

Lemma reff422_not4587 : ~ @Equation4587 Fin4 reff422_inst.
Proof. unfold Equation4587. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff422_inst, reff422_op in H. discriminate H. Qed.

Lemma reff422_not4588 : ~ @Equation4588 Fin4 reff422_inst.
Proof. unfold Equation4588. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff422_inst, reff422_op in H. discriminate H. Qed.

Lemma reff422_not4590 : ~ @Equation4590 Fin4 reff422_inst.
Proof. unfold Equation4590. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff422_inst, reff422_op in H. discriminate H. Qed.

Lemma reff422_not4591 : ~ @Equation4591 Fin4 reff422_inst.
Proof. unfold Equation4591. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff422_inst, reff422_op in H. discriminate H. Qed.

Lemma reff422_not4599 : ~ @Equation4599 Fin4 reff422_inst.
Proof. unfold Equation4599. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff422_inst, reff422_op in H. discriminate H. Qed.

Lemma reff422_not4605 : ~ @Equation4605 Fin4 reff422_inst.
Proof. unfold Equation4605. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff422_inst, reff422_op in H. discriminate H. Qed.

Lemma reff422_not4606 : ~ @Equation4606 Fin4 reff422_inst.
Proof. unfold Equation4606. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff422_inst, reff422_op in H. discriminate H. Qed.

Lemma reff422_not4608 : ~ @Equation4608 Fin4 reff422_inst.
Proof. unfold Equation4608. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff422_inst, reff422_op in H. discriminate H. Qed.

Lemma reff422_not4629 : ~ @Equation4629 Fin4 reff422_inst.
Proof. unfold Equation4629. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff422_inst, reff422_op in H. discriminate H. Qed.

Lemma reff422_not4635 : ~ @Equation4635 Fin4 reff422_inst.
Proof. unfold Equation4635. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff422_inst, reff422_op in H. discriminate H. Qed.

Lemma reff422_not4636 : ~ @Equation4636 Fin4 reff422_inst.
Proof. unfold Equation4636. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff422_inst, reff422_op in H. discriminate H. Qed.

Lemma reff422_not4658 : ~ @Equation4658 Fin4 reff422_inst.
Proof. unfold Equation4658. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff422_inst, reff422_op in H. discriminate H. Qed.

(** ---- reff424 (Fin3) ---- *)

Definition reff424_op (x y : Fin3) : Fin3 :=
  match x, y with
  | F3_0, F3_0 => F3_0 | F3_0, F3_1 => F3_2 | F3_0, F3_2 => F3_2
  | F3_1, F3_0 => F3_2 | F3_1, F3_1 => F3_1 | F3_1, F3_2 => F3_1
  | F3_2, F3_0 => F3_2 | F3_2, F3_1 => F3_1 | F3_2, F3_2 => F3_1
  end.

#[local] Instance reff424_inst : Magma Fin3 := {| magma_op := reff424_op |}.

Lemma reff424_sat332 : @Equation332 Fin3 reff424_inst.
Proof. unfold Equation332, magma_op, reff424_inst, reff424_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff424_not47 : ~ @Equation47 Fin3 reff424_inst.
Proof. unfold Equation47. intro H. specialize (H F3_2). unfold magma_op, reff424_inst, reff424_op in H. discriminate H. Qed.

Lemma reff424_not99 : ~ @Equation99 Fin3 reff424_inst.
Proof. unfold Equation99. intro H. specialize (H F3_2). unfold magma_op, reff424_inst, reff424_op in H. discriminate H. Qed.

Lemma reff424_not151 : ~ @Equation151 Fin3 reff424_inst.
Proof. unfold Equation151. intro H. specialize (H F3_2). unfold magma_op, reff424_inst, reff424_op in H. discriminate H. Qed.

Lemma reff424_not203 : ~ @Equation203 Fin3 reff424_inst.
Proof. unfold Equation203. intro H. specialize (H F3_2). unfold magma_op, reff424_inst, reff424_op in H. discriminate H. Qed.

Lemma reff424_not255 : ~ @Equation255 Fin3 reff424_inst.
Proof. unfold Equation255. intro H. specialize (H F3_2). unfold magma_op, reff424_inst, reff424_op in H. discriminate H. Qed.

Lemma reff424_not411 : ~ @Equation411 Fin3 reff424_inst.
Proof. unfold Equation411. intro H. specialize (H F3_2). unfold magma_op, reff424_inst, reff424_op in H. discriminate H. Qed.

Lemma reff424_not614 : ~ @Equation614 Fin3 reff424_inst.
Proof. unfold Equation614. intro H. specialize (H F3_2). unfold magma_op, reff424_inst, reff424_op in H. discriminate H. Qed.

Lemma reff424_not817 : ~ @Equation817 Fin3 reff424_inst.
Proof. unfold Equation817. intro H. specialize (H F3_2). unfold magma_op, reff424_inst, reff424_op in H. discriminate H. Qed.

Lemma reff424_not1020 : ~ @Equation1020 Fin3 reff424_inst.
Proof. unfold Equation1020. intro H. specialize (H F3_2). unfold magma_op, reff424_inst, reff424_op in H. discriminate H. Qed.

Lemma reff424_not1223 : ~ @Equation1223 Fin3 reff424_inst.
Proof. unfold Equation1223. intro H. specialize (H F3_2). unfold magma_op, reff424_inst, reff424_op in H. discriminate H. Qed.

Lemma reff424_not1426 : ~ @Equation1426 Fin3 reff424_inst.
Proof. unfold Equation1426. intro H. specialize (H F3_2). unfold magma_op, reff424_inst, reff424_op in H. discriminate H. Qed.

Lemma reff424_not1629 : ~ @Equation1629 Fin3 reff424_inst.
Proof. unfold Equation1629. intro H. specialize (H F3_2). unfold magma_op, reff424_inst, reff424_op in H. discriminate H. Qed.

Lemma reff424_not1832 : ~ @Equation1832 Fin3 reff424_inst.
Proof. unfold Equation1832. intro H. specialize (H F3_2). unfold magma_op, reff424_inst, reff424_op in H. discriminate H. Qed.

Lemma reff424_not2035 : ~ @Equation2035 Fin3 reff424_inst.
Proof. unfold Equation2035. intro H. specialize (H F3_2). unfold magma_op, reff424_inst, reff424_op in H. discriminate H. Qed.

Lemma reff424_not2238 : ~ @Equation2238 Fin3 reff424_inst.
Proof. unfold Equation2238. intro H. specialize (H F3_2). unfold magma_op, reff424_inst, reff424_op in H. discriminate H. Qed.

Lemma reff424_not2441 : ~ @Equation2441 Fin3 reff424_inst.
Proof. unfold Equation2441. intro H. specialize (H F3_2). unfold magma_op, reff424_inst, reff424_op in H. discriminate H. Qed.

Lemma reff424_not2644 : ~ @Equation2644 Fin3 reff424_inst.
Proof. unfold Equation2644. intro H. specialize (H F3_2). unfold magma_op, reff424_inst, reff424_op in H. discriminate H. Qed.

Lemma reff424_not2847 : ~ @Equation2847 Fin3 reff424_inst.
Proof. unfold Equation2847. intro H. specialize (H F3_2). unfold magma_op, reff424_inst, reff424_op in H. discriminate H. Qed.

Lemma reff424_not3050 : ~ @Equation3050 Fin3 reff424_inst.
Proof. unfold Equation3050. intro H. specialize (H F3_2). unfold magma_op, reff424_inst, reff424_op in H. discriminate H. Qed.

Lemma reff424_not3306 : ~ @Equation3306 Fin3 reff424_inst.
Proof. unfold Equation3306. intro H. specialize (H F3_1 F3_0). unfold magma_op, reff424_inst, reff424_op in H. discriminate H. Qed.

Lemma reff424_not3308 : ~ @Equation3308 Fin3 reff424_inst.
Proof. unfold Equation3308. intro H. specialize (H F3_1 F3_0). unfold magma_op, reff424_inst, reff424_op in H. discriminate H. Qed.

Lemma reff424_not3309 : ~ @Equation3309 Fin3 reff424_inst.
Proof. unfold Equation3309. intro H. specialize (H F3_1 F3_0). unfold magma_op, reff424_inst, reff424_op in H. discriminate H. Qed.

Lemma reff424_not3315 : ~ @Equation3315 Fin3 reff424_inst.
Proof. unfold Equation3315. intro H. specialize (H F3_1 F3_0). unfold magma_op, reff424_inst, reff424_op in H. discriminate H. Qed.

Lemma reff424_not3316 : ~ @Equation3316 Fin3 reff424_inst.
Proof. unfold Equation3316. intro H. specialize (H F3_1 F3_0). unfold magma_op, reff424_inst, reff424_op in H. discriminate H. Qed.

Lemma reff424_not3318 : ~ @Equation3318 Fin3 reff424_inst.
Proof. unfold Equation3318. intro H. specialize (H F3_1 F3_0). unfold magma_op, reff424_inst, reff424_op in H. discriminate H. Qed.

Lemma reff424_not3343 : ~ @Equation3343 Fin3 reff424_inst.
Proof. unfold Equation3343. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff424_inst, reff424_op in H. discriminate H. Qed.

Lemma reff424_not3345 : ~ @Equation3345 Fin3 reff424_inst.
Proof. unfold Equation3345. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff424_inst, reff424_op in H. discriminate H. Qed.

Lemma reff424_not3346 : ~ @Equation3346 Fin3 reff424_inst.
Proof. unfold Equation3346. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff424_inst, reff424_op in H. discriminate H. Qed.

Lemma reff424_not3352 : ~ @Equation3352 Fin3 reff424_inst.
Proof. unfold Equation3352. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff424_inst, reff424_op in H. discriminate H. Qed.

Lemma reff424_not3353 : ~ @Equation3353 Fin3 reff424_inst.
Proof. unfold Equation3353. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff424_inst, reff424_op in H. discriminate H. Qed.

Lemma reff424_not3355 : ~ @Equation3355 Fin3 reff424_inst.
Proof. unfold Equation3355. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff424_inst, reff424_op in H. discriminate H. Qed.

Lemma reff424_not3509 : ~ @Equation3509 Fin3 reff424_inst.
Proof. unfold Equation3509. intro H. specialize (H F3_1 F3_0). unfold magma_op, reff424_inst, reff424_op in H. discriminate H. Qed.

Lemma reff424_not3511 : ~ @Equation3511 Fin3 reff424_inst.
Proof. unfold Equation3511. intro H. specialize (H F3_1 F3_0). unfold magma_op, reff424_inst, reff424_op in H. discriminate H. Qed.

Lemma reff424_not3512 : ~ @Equation3512 Fin3 reff424_inst.
Proof. unfold Equation3512. intro H. specialize (H F3_1 F3_0). unfold magma_op, reff424_inst, reff424_op in H. discriminate H. Qed.

Lemma reff424_not3518 : ~ @Equation3518 Fin3 reff424_inst.
Proof. unfold Equation3518. intro H. specialize (H F3_1 F3_0). unfold magma_op, reff424_inst, reff424_op in H. discriminate H. Qed.

Lemma reff424_not3519 : ~ @Equation3519 Fin3 reff424_inst.
Proof. unfold Equation3519. intro H. specialize (H F3_1 F3_0). unfold magma_op, reff424_inst, reff424_op in H. discriminate H. Qed.

Lemma reff424_not3521 : ~ @Equation3521 Fin3 reff424_inst.
Proof. unfold Equation3521. intro H. specialize (H F3_1 F3_0). unfold magma_op, reff424_inst, reff424_op in H. discriminate H. Qed.

Lemma reff424_not3546 : ~ @Equation3546 Fin3 reff424_inst.
Proof. unfold Equation3546. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff424_inst, reff424_op in H. discriminate H. Qed.

Lemma reff424_not3548 : ~ @Equation3548 Fin3 reff424_inst.
Proof. unfold Equation3548. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff424_inst, reff424_op in H. discriminate H. Qed.

Lemma reff424_not3549 : ~ @Equation3549 Fin3 reff424_inst.
Proof. unfold Equation3549. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff424_inst, reff424_op in H. discriminate H. Qed.

Lemma reff424_not3555 : ~ @Equation3555 Fin3 reff424_inst.
Proof. unfold Equation3555. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff424_inst, reff424_op in H. discriminate H. Qed.

Lemma reff424_not3556 : ~ @Equation3556 Fin3 reff424_inst.
Proof. unfold Equation3556. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff424_inst, reff424_op in H. discriminate H. Qed.

Lemma reff424_not3558 : ~ @Equation3558 Fin3 reff424_inst.
Proof. unfold Equation3558. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff424_inst, reff424_op in H. discriminate H. Qed.

Lemma reff424_not3712 : ~ @Equation3712 Fin3 reff424_inst.
Proof. unfold Equation3712. intro H. specialize (H F3_1 F3_0). unfold magma_op, reff424_inst, reff424_op in H. discriminate H. Qed.

Lemma reff424_not3714 : ~ @Equation3714 Fin3 reff424_inst.
Proof. unfold Equation3714. intro H. specialize (H F3_1 F3_0). unfold magma_op, reff424_inst, reff424_op in H. discriminate H. Qed.

Lemma reff424_not3721 : ~ @Equation3721 Fin3 reff424_inst.
Proof. unfold Equation3721. intro H. specialize (H F3_1 F3_0). unfold magma_op, reff424_inst, reff424_op in H. discriminate H. Qed.

Lemma reff424_not3722 : ~ @Equation3722 Fin3 reff424_inst.
Proof. unfold Equation3722. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff424_inst, reff424_op in H. discriminate H. Qed.

Lemma reff424_not3724 : ~ @Equation3724 Fin3 reff424_inst.
Proof. unfold Equation3724. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff424_inst, reff424_op in H. discriminate H. Qed.

Lemma reff424_not3725 : ~ @Equation3725 Fin3 reff424_inst.
Proof. unfold Equation3725. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff424_inst, reff424_op in H. discriminate H. Qed.

Lemma reff424_not3748 : ~ @Equation3748 Fin3 reff424_inst.
Proof. unfold Equation3748. intro H. specialize (H F3_1 F3_0). unfold magma_op, reff424_inst, reff424_op in H. discriminate H. Qed.

Lemma reff424_not3749 : ~ @Equation3749 Fin3 reff424_inst.
Proof. unfold Equation3749. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff424_inst, reff424_op in H. discriminate H. Qed.

Lemma reff424_not3751 : ~ @Equation3751 Fin3 reff424_inst.
Proof. unfold Equation3751. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff424_inst, reff424_op in H. discriminate H. Qed.

Lemma reff424_not3752 : ~ @Equation3752 Fin3 reff424_inst.
Proof. unfold Equation3752. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff424_inst, reff424_op in H. discriminate H. Qed.

Lemma reff424_not3759 : ~ @Equation3759 Fin3 reff424_inst.
Proof. unfold Equation3759. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff424_inst, reff424_op in H. discriminate H. Qed.

Lemma reff424_not3761 : ~ @Equation3761 Fin3 reff424_inst.
Proof. unfold Equation3761. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff424_inst, reff424_op in H. discriminate H. Qed.

Lemma reff424_not3917 : ~ @Equation3917 Fin3 reff424_inst.
Proof. unfold Equation3917. intro H. specialize (H F3_1 F3_0). unfold magma_op, reff424_inst, reff424_op in H. discriminate H. Qed.

Lemma reff424_not3918 : ~ @Equation3918 Fin3 reff424_inst.
Proof. unfold Equation3918. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff424_inst, reff424_op in H. discriminate H. Qed.

Lemma reff424_not3924 : ~ @Equation3924 Fin3 reff424_inst.
Proof. unfold Equation3924. intro H. specialize (H F3_1 F3_0). unfold magma_op, reff424_inst, reff424_op in H. discriminate H. Qed.

Lemma reff424_not3925 : ~ @Equation3925 Fin3 reff424_inst.
Proof. unfold Equation3925. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff424_inst, reff424_op in H. discriminate H. Qed.

Lemma reff424_not3927 : ~ @Equation3927 Fin3 reff424_inst.
Proof. unfold Equation3927. intro H. specialize (H F3_1 F3_0). unfold magma_op, reff424_inst, reff424_op in H. discriminate H. Qed.

Lemma reff424_not3928 : ~ @Equation3928 Fin3 reff424_inst.
Proof. unfold Equation3928. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff424_inst, reff424_op in H. discriminate H. Qed.

Lemma reff424_not3951 : ~ @Equation3951 Fin3 reff424_inst.
Proof. unfold Equation3951. intro H. specialize (H F3_1 F3_0). unfold magma_op, reff424_inst, reff424_op in H. discriminate H. Qed.

Lemma reff424_not3952 : ~ @Equation3952 Fin3 reff424_inst.
Proof. unfold Equation3952. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff424_inst, reff424_op in H. discriminate H. Qed.

Lemma reff424_not3954 : ~ @Equation3954 Fin3 reff424_inst.
Proof. unfold Equation3954. intro H. specialize (H F3_1 F3_0). unfold magma_op, reff424_inst, reff424_op in H. discriminate H. Qed.

Lemma reff424_not3955 : ~ @Equation3955 Fin3 reff424_inst.
Proof. unfold Equation3955. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff424_inst, reff424_op in H. discriminate H. Qed.

Lemma reff424_not3961 : ~ @Equation3961 Fin3 reff424_inst.
Proof. unfold Equation3961. intro H. specialize (H F3_1 F3_0). unfold magma_op, reff424_inst, reff424_op in H. discriminate H. Qed.

Lemma reff424_not3962 : ~ @Equation3962 Fin3 reff424_inst.
Proof. unfold Equation3962. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff424_inst, reff424_op in H. discriminate H. Qed.

Lemma reff424_not4120 : ~ @Equation4120 Fin3 reff424_inst.
Proof. unfold Equation4120. intro H. specialize (H F3_1 F3_0). unfold magma_op, reff424_inst, reff424_op in H. discriminate H. Qed.

Lemma reff424_not4121 : ~ @Equation4121 Fin3 reff424_inst.
Proof. unfold Equation4121. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff424_inst, reff424_op in H. discriminate H. Qed.

Lemma reff424_not4127 : ~ @Equation4127 Fin3 reff424_inst.
Proof. unfold Equation4127. intro H. specialize (H F3_1 F3_0). unfold magma_op, reff424_inst, reff424_op in H. discriminate H. Qed.

Lemma reff424_not4128 : ~ @Equation4128 Fin3 reff424_inst.
Proof. unfold Equation4128. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff424_inst, reff424_op in H. discriminate H. Qed.

Lemma reff424_not4130 : ~ @Equation4130 Fin3 reff424_inst.
Proof. unfold Equation4130. intro H. specialize (H F3_1 F3_0). unfold magma_op, reff424_inst, reff424_op in H. discriminate H. Qed.

Lemma reff424_not4131 : ~ @Equation4131 Fin3 reff424_inst.
Proof. unfold Equation4131. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff424_inst, reff424_op in H. discriminate H. Qed.

Lemma reff424_not4154 : ~ @Equation4154 Fin3 reff424_inst.
Proof. unfold Equation4154. intro H. specialize (H F3_1 F3_0). unfold magma_op, reff424_inst, reff424_op in H. discriminate H. Qed.

Lemma reff424_not4155 : ~ @Equation4155 Fin3 reff424_inst.
Proof. unfold Equation4155. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff424_inst, reff424_op in H. discriminate H. Qed.

Lemma reff424_not4157 : ~ @Equation4157 Fin3 reff424_inst.
Proof. unfold Equation4157. intro H. specialize (H F3_1 F3_0). unfold magma_op, reff424_inst, reff424_op in H. discriminate H. Qed.

Lemma reff424_not4158 : ~ @Equation4158 Fin3 reff424_inst.
Proof. unfold Equation4158. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff424_inst, reff424_op in H. discriminate H. Qed.

Lemma reff424_not4164 : ~ @Equation4164 Fin3 reff424_inst.
Proof. unfold Equation4164. intro H. specialize (H F3_1 F3_0). unfold magma_op, reff424_inst, reff424_op in H. discriminate H. Qed.

Lemma reff424_not4165 : ~ @Equation4165 Fin3 reff424_inst.
Proof. unfold Equation4165. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff424_inst, reff424_op in H. discriminate H. Qed.

Lemma reff424_not4284 : ~ @Equation4284 Fin3 reff424_inst.
Proof. unfold Equation4284. intro H. specialize (H F3_1 F3_0). unfold magma_op, reff424_inst, reff424_op in H. discriminate H. Qed.

Lemma reff424_not4290 : ~ @Equation4290 Fin3 reff424_inst.
Proof. unfold Equation4290. intro H. specialize (H F3_1 F3_0). unfold magma_op, reff424_inst, reff424_op in H. discriminate H. Qed.

Lemma reff424_not4291 : ~ @Equation4291 Fin3 reff424_inst.
Proof. unfold Equation4291. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff424_inst, reff424_op in H. discriminate H. Qed.

Lemma reff424_not4293 : ~ @Equation4293 Fin3 reff424_inst.
Proof. unfold Equation4293. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff424_inst, reff424_op in H. discriminate H. Qed.

Lemma reff424_not4314 : ~ @Equation4314 Fin3 reff424_inst.
Proof. unfold Equation4314. intro H. specialize (H F3_1 F3_0). unfold magma_op, reff424_inst, reff424_op in H. discriminate H. Qed.

Lemma reff424_not4320 : ~ @Equation4320 Fin3 reff424_inst.
Proof. unfold Equation4320. intro H. specialize (H F3_1 F3_0). unfold magma_op, reff424_inst, reff424_op in H. discriminate H. Qed.

Lemma reff424_not4321 : ~ @Equation4321 Fin3 reff424_inst.
Proof. unfold Equation4321. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff424_inst, reff424_op in H. discriminate H. Qed.

Lemma reff424_not4396 : ~ @Equation4396 Fin3 reff424_inst.
Proof. unfold Equation4396. intro H. specialize (H F3_1 F3_0). unfold magma_op, reff424_inst, reff424_op in H. discriminate H. Qed.

Lemma reff424_not4399 : ~ @Equation4399 Fin3 reff424_inst.
Proof. unfold Equation4399. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff424_inst, reff424_op in H. discriminate H. Qed.

Lemma reff424_not4406 : ~ @Equation4406 Fin3 reff424_inst.
Proof. unfold Equation4406. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff424_inst, reff424_op in H. discriminate H. Qed.

Lemma reff424_not4408 : ~ @Equation4408 Fin3 reff424_inst.
Proof. unfold Equation4408. intro H. specialize (H F3_1 F3_0). unfold magma_op, reff424_inst, reff424_op in H. discriminate H. Qed.

Lemma reff424_not4433 : ~ @Equation4433 Fin3 reff424_inst.
Proof. unfold Equation4433. intro H. specialize (H F3_1 F3_0). unfold magma_op, reff424_inst, reff424_op in H. discriminate H. Qed.

Lemma reff424_not4436 : ~ @Equation4436 Fin3 reff424_inst.
Proof. unfold Equation4436. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff424_inst, reff424_op in H. discriminate H. Qed.

Lemma reff424_not4443 : ~ @Equation4443 Fin3 reff424_inst.
Proof. unfold Equation4443. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff424_inst, reff424_op in H. discriminate H. Qed.

Lemma reff424_not4445 : ~ @Equation4445 Fin3 reff424_inst.
Proof. unfold Equation4445. intro H. specialize (H F3_1 F3_0). unfold magma_op, reff424_inst, reff424_op in H. discriminate H. Qed.

Lemma reff424_not4472 : ~ @Equation4472 Fin3 reff424_inst.
Proof. unfold Equation4472. intro H. specialize (H F3_1 F3_0). unfold magma_op, reff424_inst, reff424_op in H. discriminate H. Qed.

Lemma reff424_not4473 : ~ @Equation4473 Fin3 reff424_inst.
Proof. unfold Equation4473. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff424_inst, reff424_op in H. discriminate H. Qed.

Lemma reff424_not4479 : ~ @Equation4479 Fin3 reff424_inst.
Proof. unfold Equation4479. intro H. specialize (H F3_1 F3_0). unfold magma_op, reff424_inst, reff424_op in H. discriminate H. Qed.

Lemma reff424_not4480 : ~ @Equation4480 Fin3 reff424_inst.
Proof. unfold Equation4480. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff424_inst, reff424_op in H. discriminate H. Qed.

Lemma reff424_not4598 : ~ @Equation4598 Fin3 reff424_inst.
Proof. unfold Equation4598. intro H. specialize (H F3_1 F3_0). unfold magma_op, reff424_inst, reff424_op in H. discriminate H. Qed.

Lemma reff424_not4599 : ~ @Equation4599 Fin3 reff424_inst.
Proof. unfold Equation4599. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff424_inst, reff424_op in H. discriminate H. Qed.

Lemma reff424_not4605 : ~ @Equation4605 Fin3 reff424_inst.
Proof. unfold Equation4605. intro H. specialize (H F3_1 F3_0). unfold magma_op, reff424_inst, reff424_op in H. discriminate H. Qed.

Lemma reff424_not4606 : ~ @Equation4606 Fin3 reff424_inst.
Proof. unfold Equation4606. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff424_inst, reff424_op in H. discriminate H. Qed.

Lemma reff424_not4629 : ~ @Equation4629 Fin3 reff424_inst.
Proof. unfold Equation4629. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff424_inst, reff424_op in H. discriminate H. Qed.

Lemma reff424_not4636 : ~ @Equation4636 Fin3 reff424_inst.
Proof. unfold Equation4636. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff424_inst, reff424_op in H. discriminate H. Qed.

Lemma reff424_not4658 : ~ @Equation4658 Fin3 reff424_inst.
Proof. unfold Equation4658. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff424_inst, reff424_op in H. discriminate H. Qed.

(** ---- reff426 (Fin3) ---- *)

Definition reff426_op (x y : Fin3) : Fin3 :=
  match x, y with
  | F3_0, F3_0 => F3_0 | F3_0, F3_1 => F3_1 | F3_0, F3_2 => F3_2
  | F3_1, F3_0 => F3_2 | F3_1, F3_1 => F3_0 | F3_1, F3_2 => F3_1
  | F3_2, F3_0 => F3_1 | F3_2, F3_1 => F3_2 | F3_2, F3_2 => F3_0
  end.

#[local] Instance reff426_inst : Magma Fin3 := {| magma_op := reff426_op |}.

Lemma reff426_sat50 : @Equation50 Fin3 reff426_inst.
Proof. unfold Equation50, magma_op, reff426_inst, reff426_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff426_sat53 : @Equation53 Fin3 reff426_inst.
Proof. unfold Equation53, magma_op, reff426_inst, reff426_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff426_sat63 : @Equation63 Fin3 reff426_inst.
Proof. unfold Equation63, magma_op, reff426_inst, reff426_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff426_sat75 : @Equation75 Fin3 reff426_inst.
Proof. unfold Equation75, magma_op, reff426_inst, reff426_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff426_sat1046 : @Equation1046 Fin3 reff426_inst.
Proof. unfold Equation1046, magma_op, reff426_inst, reff426_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff426_sat1090 : @Equation1090 Fin3 reff426_inst.
Proof. unfold Equation1090, magma_op, reff426_inst, reff426_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff426_sat1101 : @Equation1101 Fin3 reff426_inst.
Proof. unfold Equation1101, magma_op, reff426_inst, reff426_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff426_sat1117 : @Equation1117 Fin3 reff426_inst.
Proof. unfold Equation1117, magma_op, reff426_inst, reff426_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff426_sat1137 : @Equation1137 Fin3 reff426_inst.
Proof. unfold Equation1137, magma_op, reff426_inst, reff426_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff426_sat1155 : @Equation1155 Fin3 reff426_inst.
Proof. unfold Equation1155, magma_op, reff426_inst, reff426_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff426_sat1171 : @Equation1171 Fin3 reff426_inst.
Proof. unfold Equation1171, magma_op, reff426_inst, reff426_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff426_sat1673 : @Equation1673 Fin3 reff426_inst.
Proof. unfold Equation1673, magma_op, reff426_inst, reff426_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff426_sat1692 : @Equation1692 Fin3 reff426_inst.
Proof. unfold Equation1692, magma_op, reff426_inst, reff426_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff426_sat1726 : @Equation1726 Fin3 reff426_inst.
Proof. unfold Equation1726, magma_op, reff426_inst, reff426_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff426_sat1761 : @Equation1761 Fin3 reff426_inst.
Proof. unfold Equation1761, magma_op, reff426_inst, reff426_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff426_sat1793 : @Equation1793 Fin3 reff426_inst.
Proof. unfold Equation1793, magma_op, reff426_inst, reff426_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff426_sat1865 : @Equation1865 Fin3 reff426_inst.
Proof. unfold Equation1865, magma_op, reff426_inst, reff426_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff426_sat1902 : @Equation1902 Fin3 reff426_inst.
Proof. unfold Equation1902, magma_op, reff426_inst, reff426_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff426_sat1910 : @Equation1910 Fin3 reff426_inst.
Proof. unfold Equation1910, magma_op, reff426_inst, reff426_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff426_sat1922 : @Equation1922 Fin3 reff426_inst.
Proof. unfold Equation1922, magma_op, reff426_inst, reff426_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff426_sat1983 : @Equation1983 Fin3 reff426_inst.
Proof. unfold Equation1983, magma_op, reff426_inst, reff426_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff426_sat1996 : @Equation1996 Fin3 reff426_inst.
Proof. unfold Equation1996, magma_op, reff426_inst, reff426_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff426_sat2474 : @Equation2474 Fin3 reff426_inst.
Proof. unfold Equation2474, magma_op, reff426_inst, reff426_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff426_sat2504 : @Equation2504 Fin3 reff426_inst.
Proof. unfold Equation2504, magma_op, reff426_inst, reff426_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff426_sat2538 : @Equation2538 Fin3 reff426_inst.
Proof. unfold Equation2538, magma_op, reff426_inst, reff426_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff426_sat2573 : @Equation2573 Fin3 reff426_inst.
Proof. unfold Equation2573, magma_op, reff426_inst, reff426_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff426_sat2670 : @Equation2670 Fin3 reff426_inst.
Proof. unfold Equation2670, magma_op, reff426_inst, reff426_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff426_sat2714 : @Equation2714 Fin3 reff426_inst.
Proof. unfold Equation2714, magma_op, reff426_inst, reff426_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff426_sat2725 : @Equation2725 Fin3 reff426_inst.
Proof. unfold Equation2725, magma_op, reff426_inst, reff426_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff426_sat2741 : @Equation2741 Fin3 reff426_inst.
Proof. unfold Equation2741, magma_op, reff426_inst, reff426_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff426_sat2779 : @Equation2779 Fin3 reff426_inst.
Proof. unfold Equation2779, magma_op, reff426_inst, reff426_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff426_sat3113 : @Equation3113 Fin3 reff426_inst.
Proof. unfold Equation3113, magma_op, reff426_inst, reff426_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff426_sat3147 : @Equation3147 Fin3 reff426_inst.
Proof. unfold Equation3147, magma_op, reff426_inst, reff426_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff426_sat3182 : @Equation3182 Fin3 reff426_inst.
Proof. unfold Equation3182, magma_op, reff426_inst, reff426_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff426_sat3214 : @Equation3214 Fin3 reff426_inst.
Proof. unfold Equation3214, magma_op, reff426_inst, reff426_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff426_sat3489 : @Equation3489 Fin3 reff426_inst.
Proof. unfold Equation3489, magma_op, reff426_inst, reff426_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff426_sat3548 : @Equation3548 Fin3 reff426_inst.
Proof. unfold Equation3548, magma_op, reff426_inst, reff426_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff426_sat3601 : @Equation3601 Fin3 reff426_inst.
Proof. unfold Equation3601, magma_op, reff426_inst, reff426_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff426_sat3756 : @Equation3756 Fin3 reff426_inst.
Proof. unfold Equation3756, magma_op, reff426_inst, reff426_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff426_sat3794 : @Equation3794 Fin3 reff426_inst.
Proof. unfold Equation3794, magma_op, reff426_inst, reff426_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff426_sat4109 : @Equation4109 Fin3 reff426_inst.
Proof. unfold Equation4109, magma_op, reff426_inst, reff426_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff426_sat4157 : @Equation4157 Fin3 reff426_inst.
Proof. unfold Equation4157, magma_op, reff426_inst, reff426_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff426_sat4210 : @Equation4210 Fin3 reff426_inst.
Proof. unfold Equation4210, magma_op, reff426_inst, reff426_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff426_sat4293 : @Equation4293 Fin3 reff426_inst.
Proof. unfold Equation4293, magma_op, reff426_inst, reff426_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff426_sat4325 : @Equation4325 Fin3 reff426_inst.
Proof. unfold Equation4325, magma_op, reff426_inst, reff426_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff426_sat4612 : @Equation4612 Fin3 reff426_inst.
Proof. unfold Equation4612, magma_op, reff426_inst, reff426_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff426_not55 : ~ @Equation55 Fin3 reff426_inst.
Proof. unfold Equation55. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff426_inst, reff426_op in H. discriminate H. Qed.

Lemma reff426_not56 : ~ @Equation56 Fin3 reff426_inst.
Proof. unfold Equation56. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff426_inst, reff426_op in H. discriminate H. Qed.

Lemma reff426_not65 : ~ @Equation65 Fin3 reff426_inst.
Proof. unfold Equation65. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff426_inst, reff426_op in H. discriminate H. Qed.

Lemma reff426_not66 : ~ @Equation66 Fin3 reff426_inst.
Proof. unfold Equation66. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff426_inst, reff426_op in H. discriminate H. Qed.

Lemma reff426_not72 : ~ @Equation72 Fin3 reff426_inst.
Proof. unfold Equation72. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff426_inst, reff426_op in H. discriminate H. Qed.

Lemma reff426_not73 : ~ @Equation73 Fin3 reff426_inst.
Proof. unfold Equation73. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff426_inst, reff426_op in H. discriminate H. Qed.

Lemma reff426_not99 : ~ @Equation99 Fin3 reff426_inst.
Proof. unfold Equation99. intro H. specialize (H F3_1). unfold magma_op, reff426_inst, reff426_op in H. discriminate H. Qed.

Lemma reff426_not151 : ~ @Equation151 Fin3 reff426_inst.
Proof. unfold Equation151. intro H. specialize (H F3_1). unfold magma_op, reff426_inst, reff426_op in H. discriminate H. Qed.

Lemma reff426_not203 : ~ @Equation203 Fin3 reff426_inst.
Proof. unfold Equation203. intro H. specialize (H F3_1). unfold magma_op, reff426_inst, reff426_op in H. discriminate H. Qed.

Lemma reff426_not255 : ~ @Equation255 Fin3 reff426_inst.
Proof. unfold Equation255. intro H. specialize (H F3_1). unfold magma_op, reff426_inst, reff426_op in H. discriminate H. Qed.

Lemma reff426_not359 : ~ @Equation359 Fin3 reff426_inst.
Proof. unfold Equation359. intro H. specialize (H F3_1). unfold magma_op, reff426_inst, reff426_op in H. discriminate H. Qed.

Lemma reff426_not411 : ~ @Equation411 Fin3 reff426_inst.
Proof. unfold Equation411. intro H. specialize (H F3_1). unfold magma_op, reff426_inst, reff426_op in H. discriminate H. Qed.

Lemma reff426_not614 : ~ @Equation614 Fin3 reff426_inst.
Proof. unfold Equation614. intro H. specialize (H F3_1). unfold magma_op, reff426_inst, reff426_op in H. discriminate H. Qed.

Lemma reff426_not817 : ~ @Equation817 Fin3 reff426_inst.
Proof. unfold Equation817. intro H. specialize (H F3_1). unfold magma_op, reff426_inst, reff426_op in H. discriminate H. Qed.

Lemma reff426_not1021 : ~ @Equation1021 Fin3 reff426_inst.
Proof. unfold Equation1021. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff426_inst, reff426_op in H. discriminate H. Qed.

Lemma reff426_not1022 : ~ @Equation1022 Fin3 reff426_inst.
Proof. unfold Equation1022. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff426_inst, reff426_op in H. discriminate H. Qed.

Lemma reff426_not1025 : ~ @Equation1025 Fin3 reff426_inst.
Proof. unfold Equation1025. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff426_inst, reff426_op in H. discriminate H. Qed.

Lemma reff426_not1026 : ~ @Equation1026 Fin3 reff426_inst.
Proof. unfold Equation1026. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff426_inst, reff426_op in H. discriminate H. Qed.

Lemma reff426_not1029 : ~ @Equation1029 Fin3 reff426_inst.
Proof. unfold Equation1029. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff426_inst, reff426_op in H. discriminate H. Qed.

Lemma reff426_not1035 : ~ @Equation1035 Fin3 reff426_inst.
Proof. unfold Equation1035. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff426_inst, reff426_op in H. discriminate H. Qed.

Lemma reff426_not1036 : ~ @Equation1036 Fin3 reff426_inst.
Proof. unfold Equation1036. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff426_inst, reff426_op in H. discriminate H. Qed.

Lemma reff426_not1039 : ~ @Equation1039 Fin3 reff426_inst.
Proof. unfold Equation1039. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff426_inst, reff426_op in H. discriminate H. Qed.

Lemma reff426_not1045 : ~ @Equation1045 Fin3 reff426_inst.
Proof. unfold Equation1045. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff426_inst, reff426_op in H. discriminate H. Qed.

Lemma reff426_not1048 : ~ @Equation1048 Fin3 reff426_inst.
Proof. unfold Equation1048. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff426_inst, reff426_op in H. discriminate H. Qed.

Lemma reff426_not1049 : ~ @Equation1049 Fin3 reff426_inst.
Proof. unfold Equation1049. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff426_inst, reff426_op in H. discriminate H. Qed.

Lemma reff426_not1072 : ~ @Equation1072 Fin3 reff426_inst.
Proof. unfold Equation1072. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff426_inst, reff426_op in H. discriminate H. Qed.

Lemma reff426_not1075 : ~ @Equation1075 Fin3 reff426_inst.
Proof. unfold Equation1075. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff426_inst, reff426_op in H. discriminate H. Qed.

Lemma reff426_not1076 : ~ @Equation1076 Fin3 reff426_inst.
Proof. unfold Equation1076. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff426_inst, reff426_op in H. discriminate H. Qed.

Lemma reff426_not1083 : ~ @Equation1083 Fin3 reff426_inst.
Proof. unfold Equation1083. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff426_inst, reff426_op in H. discriminate H. Qed.

Lemma reff426_not1085 : ~ @Equation1085 Fin3 reff426_inst.
Proof. unfold Equation1085. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff426_inst, reff426_op in H. discriminate H. Qed.

Lemma reff426_not1110 : ~ @Equation1110 Fin3 reff426_inst.
Proof. unfold Equation1110. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff426_inst, reff426_op in H. discriminate H. Qed.

Lemma reff426_not1112 : ~ @Equation1112 Fin3 reff426_inst.
Proof. unfold Equation1112. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff426_inst, reff426_op in H. discriminate H. Qed.

Lemma reff426_not1119 : ~ @Equation1119 Fin3 reff426_inst.
Proof. unfold Equation1119. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff426_inst, reff426_op in H. discriminate H. Qed.

Lemma reff426_not1120 : ~ @Equation1120 Fin3 reff426_inst.
Proof. unfold Equation1120. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff426_inst, reff426_op in H. discriminate H. Qed.

Lemma reff426_not1223 : ~ @Equation1223 Fin3 reff426_inst.
Proof. unfold Equation1223. intro H. specialize (H F3_1). unfold magma_op, reff426_inst, reff426_op in H. discriminate H. Qed.

Lemma reff426_not1426 : ~ @Equation1426 Fin3 reff426_inst.
Proof. unfold Equation1426. intro H. specialize (H F3_1). unfold magma_op, reff426_inst, reff426_op in H. discriminate H. Qed.

Lemma reff426_not1630 : ~ @Equation1630 Fin3 reff426_inst.
Proof. unfold Equation1630. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff426_inst, reff426_op in H. discriminate H. Qed.

Lemma reff426_not1631 : ~ @Equation1631 Fin3 reff426_inst.
Proof. unfold Equation1631. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff426_inst, reff426_op in H. discriminate H. Qed.

Lemma reff426_not1634 : ~ @Equation1634 Fin3 reff426_inst.
Proof. unfold Equation1634. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff426_inst, reff426_op in H. discriminate H. Qed.

Lemma reff426_not1635 : ~ @Equation1635 Fin3 reff426_inst.
Proof. unfold Equation1635. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff426_inst, reff426_op in H. discriminate H. Qed.

Lemma reff426_not1638 : ~ @Equation1638 Fin3 reff426_inst.
Proof. unfold Equation1638. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff426_inst, reff426_op in H. discriminate H. Qed.

Lemma reff426_not1644 : ~ @Equation1644 Fin3 reff426_inst.
Proof. unfold Equation1644. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff426_inst, reff426_op in H. discriminate H. Qed.

Lemma reff426_not1647 : ~ @Equation1647 Fin3 reff426_inst.
Proof. unfold Equation1647. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff426_inst, reff426_op in H. discriminate H. Qed.

Lemma reff426_not1648 : ~ @Equation1648 Fin3 reff426_inst.
Proof. unfold Equation1648. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff426_inst, reff426_op in H. discriminate H. Qed.

Lemma reff426_not1655 : ~ @Equation1655 Fin3 reff426_inst.
Proof. unfold Equation1655. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff426_inst, reff426_op in H. discriminate H. Qed.

Lemma reff426_not1657 : ~ @Equation1657 Fin3 reff426_inst.
Proof. unfold Equation1657. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff426_inst, reff426_op in H. discriminate H. Qed.

Lemma reff426_not1681 : ~ @Equation1681 Fin3 reff426_inst.
Proof. unfold Equation1681. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff426_inst, reff426_op in H. discriminate H. Qed.

Lemma reff426_not1682 : ~ @Equation1682 Fin3 reff426_inst.
Proof. unfold Equation1682. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff426_inst, reff426_op in H. discriminate H. Qed.

Lemma reff426_not1685 : ~ @Equation1685 Fin3 reff426_inst.
Proof. unfold Equation1685. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff426_inst, reff426_op in H. discriminate H. Qed.

Lemma reff426_not1691 : ~ @Equation1691 Fin3 reff426_inst.
Proof. unfold Equation1691. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff426_inst, reff426_op in H. discriminate H. Qed.

Lemma reff426_not1694 : ~ @Equation1694 Fin3 reff426_inst.
Proof. unfold Equation1694. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff426_inst, reff426_op in H. discriminate H. Qed.

Lemma reff426_not1695 : ~ @Equation1695 Fin3 reff426_inst.
Proof. unfold Equation1695. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff426_inst, reff426_op in H. discriminate H. Qed.

Lemma reff426_not1719 : ~ @Equation1719 Fin3 reff426_inst.
Proof. unfold Equation1719. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff426_inst, reff426_op in H. discriminate H. Qed.

Lemma reff426_not1721 : ~ @Equation1721 Fin3 reff426_inst.
Proof. unfold Equation1721. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff426_inst, reff426_op in H. discriminate H. Qed.

Lemma reff426_not1728 : ~ @Equation1728 Fin3 reff426_inst.
Proof. unfold Equation1728. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff426_inst, reff426_op in H. discriminate H. Qed.

Lemma reff426_not1729 : ~ @Equation1729 Fin3 reff426_inst.
Proof. unfold Equation1729. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff426_inst, reff426_op in H. discriminate H. Qed.

Lemma reff426_not1833 : ~ @Equation1833 Fin3 reff426_inst.
Proof. unfold Equation1833. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff426_inst, reff426_op in H. discriminate H. Qed.

Lemma reff426_not1834 : ~ @Equation1834 Fin3 reff426_inst.
Proof. unfold Equation1834. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff426_inst, reff426_op in H. discriminate H. Qed.

Lemma reff426_not1837 : ~ @Equation1837 Fin3 reff426_inst.
Proof. unfold Equation1837. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff426_inst, reff426_op in H. discriminate H. Qed.

Lemma reff426_not1840 : ~ @Equation1840 Fin3 reff426_inst.
Proof. unfold Equation1840. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff426_inst, reff426_op in H. discriminate H. Qed.

Lemma reff426_not1841 : ~ @Equation1841 Fin3 reff426_inst.
Proof. unfold Equation1841. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff426_inst, reff426_op in H. discriminate H. Qed.

Lemma reff426_not1847 : ~ @Equation1847 Fin3 reff426_inst.
Proof. unfold Equation1847. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff426_inst, reff426_op in H. discriminate H. Qed.

Lemma reff426_not1848 : ~ @Equation1848 Fin3 reff426_inst.
Proof. unfold Equation1848. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff426_inst, reff426_op in H. discriminate H. Qed.

Lemma reff426_not1851 : ~ @Equation1851 Fin3 reff426_inst.
Proof. unfold Equation1851. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff426_inst, reff426_op in H. discriminate H. Qed.

Lemma reff426_not1858 : ~ @Equation1858 Fin3 reff426_inst.
Proof. unfold Equation1858. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff426_inst, reff426_op in H. discriminate H. Qed.

Lemma reff426_not1860 : ~ @Equation1860 Fin3 reff426_inst.
Proof. unfold Equation1860. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff426_inst, reff426_op in H. discriminate H. Qed.

Lemma reff426_not1884 : ~ @Equation1884 Fin3 reff426_inst.
Proof. unfold Equation1884. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff426_inst, reff426_op in H. discriminate H. Qed.

Lemma reff426_not1885 : ~ @Equation1885 Fin3 reff426_inst.
Proof. unfold Equation1885. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff426_inst, reff426_op in H. discriminate H. Qed.

Lemma reff426_not1888 : ~ @Equation1888 Fin3 reff426_inst.
Proof. unfold Equation1888. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff426_inst, reff426_op in H. discriminate H. Qed.

Lemma reff426_not1895 : ~ @Equation1895 Fin3 reff426_inst.
Proof. unfold Equation1895. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff426_inst, reff426_op in H. discriminate H. Qed.

Lemma reff426_not1897 : ~ @Equation1897 Fin3 reff426_inst.
Proof. unfold Equation1897. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff426_inst, reff426_op in H. discriminate H. Qed.

Lemma reff426_not1921 : ~ @Equation1921 Fin3 reff426_inst.
Proof. unfold Equation1921. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff426_inst, reff426_op in H. discriminate H. Qed.

Lemma reff426_not1924 : ~ @Equation1924 Fin3 reff426_inst.
Proof. unfold Equation1924. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff426_inst, reff426_op in H. discriminate H. Qed.

Lemma reff426_not1925 : ~ @Equation1925 Fin3 reff426_inst.
Proof. unfold Equation1925. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff426_inst, reff426_op in H. discriminate H. Qed.

Lemma reff426_not1931 : ~ @Equation1931 Fin3 reff426_inst.
Proof. unfold Equation1931. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff426_inst, reff426_op in H. discriminate H. Qed.

Lemma reff426_not1932 : ~ @Equation1932 Fin3 reff426_inst.
Proof. unfold Equation1932. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff426_inst, reff426_op in H. discriminate H. Qed.

Lemma reff426_not2035 : ~ @Equation2035 Fin3 reff426_inst.
Proof. unfold Equation2035. intro H. specialize (H F3_1). unfold magma_op, reff426_inst, reff426_op in H. discriminate H. Qed.

Lemma reff426_not2238 : ~ @Equation2238 Fin3 reff426_inst.
Proof. unfold Equation2238. intro H. specialize (H F3_1). unfold magma_op, reff426_inst, reff426_op in H. discriminate H. Qed.

Lemma reff426_not2442 : ~ @Equation2442 Fin3 reff426_inst.
Proof. unfold Equation2442. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff426_inst, reff426_op in H. discriminate H. Qed.

Lemma reff426_not2443 : ~ @Equation2443 Fin3 reff426_inst.
Proof. unfold Equation2443. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff426_inst, reff426_op in H. discriminate H. Qed.

Lemma reff426_not2446 : ~ @Equation2446 Fin3 reff426_inst.
Proof. unfold Equation2446. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff426_inst, reff426_op in H. discriminate H. Qed.

Lemma reff426_not2447 : ~ @Equation2447 Fin3 reff426_inst.
Proof. unfold Equation2447. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff426_inst, reff426_op in H. discriminate H. Qed.

Lemma reff426_not2450 : ~ @Equation2450 Fin3 reff426_inst.
Proof. unfold Equation2450. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff426_inst, reff426_op in H. discriminate H. Qed.

Lemma reff426_not2456 : ~ @Equation2456 Fin3 reff426_inst.
Proof. unfold Equation2456. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff426_inst, reff426_op in H. discriminate H. Qed.

Lemma reff426_not2459 : ~ @Equation2459 Fin3 reff426_inst.
Proof. unfold Equation2459. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff426_inst, reff426_op in H. discriminate H. Qed.

Lemma reff426_not2460 : ~ @Equation2460 Fin3 reff426_inst.
Proof. unfold Equation2460. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff426_inst, reff426_op in H. discriminate H. Qed.

Lemma reff426_not2467 : ~ @Equation2467 Fin3 reff426_inst.
Proof. unfold Equation2467. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff426_inst, reff426_op in H. discriminate H. Qed.

Lemma reff426_not2469 : ~ @Equation2469 Fin3 reff426_inst.
Proof. unfold Equation2469. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff426_inst, reff426_op in H. discriminate H. Qed.

Lemma reff426_not2493 : ~ @Equation2493 Fin3 reff426_inst.
Proof. unfold Equation2493. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff426_inst, reff426_op in H. discriminate H. Qed.

Lemma reff426_not2494 : ~ @Equation2494 Fin3 reff426_inst.
Proof. unfold Equation2494. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff426_inst, reff426_op in H. discriminate H. Qed.

Lemma reff426_not2497 : ~ @Equation2497 Fin3 reff426_inst.
Proof. unfold Equation2497. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff426_inst, reff426_op in H. discriminate H. Qed.

Lemma reff426_not2503 : ~ @Equation2503 Fin3 reff426_inst.
Proof. unfold Equation2503. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff426_inst, reff426_op in H. discriminate H. Qed.

Lemma reff426_not2506 : ~ @Equation2506 Fin3 reff426_inst.
Proof. unfold Equation2506. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff426_inst, reff426_op in H. discriminate H. Qed.

Lemma reff426_not2507 : ~ @Equation2507 Fin3 reff426_inst.
Proof. unfold Equation2507. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff426_inst, reff426_op in H. discriminate H. Qed.

Lemma reff426_not2531 : ~ @Equation2531 Fin3 reff426_inst.
Proof. unfold Equation2531. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff426_inst, reff426_op in H. discriminate H. Qed.

Lemma reff426_not2533 : ~ @Equation2533 Fin3 reff426_inst.
Proof. unfold Equation2533. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff426_inst, reff426_op in H. discriminate H. Qed.

Lemma reff426_not2540 : ~ @Equation2540 Fin3 reff426_inst.
Proof. unfold Equation2540. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff426_inst, reff426_op in H. discriminate H. Qed.

Lemma reff426_not2541 : ~ @Equation2541 Fin3 reff426_inst.
Proof. unfold Equation2541. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff426_inst, reff426_op in H. discriminate H. Qed.

Lemma reff426_not2645 : ~ @Equation2645 Fin3 reff426_inst.
Proof. unfold Equation2645. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff426_inst, reff426_op in H. discriminate H. Qed.

Lemma reff426_not2646 : ~ @Equation2646 Fin3 reff426_inst.
Proof. unfold Equation2646. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff426_inst, reff426_op in H. discriminate H. Qed.

Lemma reff426_not2649 : ~ @Equation2649 Fin3 reff426_inst.
Proof. unfold Equation2649. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff426_inst, reff426_op in H. discriminate H. Qed.

Lemma reff426_not2650 : ~ @Equation2650 Fin3 reff426_inst.
Proof. unfold Equation2650. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff426_inst, reff426_op in H. discriminate H. Qed.

Lemma reff426_not2653 : ~ @Equation2653 Fin3 reff426_inst.
Proof. unfold Equation2653. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff426_inst, reff426_op in H. discriminate H. Qed.

Lemma reff426_not2659 : ~ @Equation2659 Fin3 reff426_inst.
Proof. unfold Equation2659. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff426_inst, reff426_op in H. discriminate H. Qed.

Lemma reff426_not2660 : ~ @Equation2660 Fin3 reff426_inst.
Proof. unfold Equation2660. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff426_inst, reff426_op in H. discriminate H. Qed.

Lemma reff426_not2663 : ~ @Equation2663 Fin3 reff426_inst.
Proof. unfold Equation2663. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff426_inst, reff426_op in H. discriminate H. Qed.

Lemma reff426_not2669 : ~ @Equation2669 Fin3 reff426_inst.
Proof. unfold Equation2669. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff426_inst, reff426_op in H. discriminate H. Qed.

Lemma reff426_not2672 : ~ @Equation2672 Fin3 reff426_inst.
Proof. unfold Equation2672. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff426_inst, reff426_op in H. discriminate H. Qed.

Lemma reff426_not2673 : ~ @Equation2673 Fin3 reff426_inst.
Proof. unfold Equation2673. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff426_inst, reff426_op in H. discriminate H. Qed.

Lemma reff426_not2696 : ~ @Equation2696 Fin3 reff426_inst.
Proof. unfold Equation2696. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff426_inst, reff426_op in H. discriminate H. Qed.

Lemma reff426_not2699 : ~ @Equation2699 Fin3 reff426_inst.
Proof. unfold Equation2699. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff426_inst, reff426_op in H. discriminate H. Qed.

Lemma reff426_not2700 : ~ @Equation2700 Fin3 reff426_inst.
Proof. unfold Equation2700. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff426_inst, reff426_op in H. discriminate H. Qed.

Lemma reff426_not2707 : ~ @Equation2707 Fin3 reff426_inst.
Proof. unfold Equation2707. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff426_inst, reff426_op in H. discriminate H. Qed.

Lemma reff426_not2709 : ~ @Equation2709 Fin3 reff426_inst.
Proof. unfold Equation2709. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff426_inst, reff426_op in H. discriminate H. Qed.

Lemma reff426_not2734 : ~ @Equation2734 Fin3 reff426_inst.
Proof. unfold Equation2734. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff426_inst, reff426_op in H. discriminate H. Qed.

Lemma reff426_not2736 : ~ @Equation2736 Fin3 reff426_inst.
Proof. unfold Equation2736. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff426_inst, reff426_op in H. discriminate H. Qed.

Lemma reff426_not2743 : ~ @Equation2743 Fin3 reff426_inst.
Proof. unfold Equation2743. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff426_inst, reff426_op in H. discriminate H. Qed.

Lemma reff426_not2744 : ~ @Equation2744 Fin3 reff426_inst.
Proof. unfold Equation2744. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff426_inst, reff426_op in H. discriminate H. Qed.

Lemma reff426_not2847 : ~ @Equation2847 Fin3 reff426_inst.
Proof. unfold Equation2847. intro H. specialize (H F3_1). unfold magma_op, reff426_inst, reff426_op in H. discriminate H. Qed.

Lemma reff426_not3051 : ~ @Equation3051 Fin3 reff426_inst.
Proof. unfold Equation3051. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff426_inst, reff426_op in H. discriminate H. Qed.

Lemma reff426_not3052 : ~ @Equation3052 Fin3 reff426_inst.
Proof. unfold Equation3052. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff426_inst, reff426_op in H. discriminate H. Qed.

Lemma reff426_not3055 : ~ @Equation3055 Fin3 reff426_inst.
Proof. unfold Equation3055. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff426_inst, reff426_op in H. discriminate H. Qed.

Lemma reff426_not3056 : ~ @Equation3056 Fin3 reff426_inst.
Proof. unfold Equation3056. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff426_inst, reff426_op in H. discriminate H. Qed.

Lemma reff426_not3059 : ~ @Equation3059 Fin3 reff426_inst.
Proof. unfold Equation3059. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff426_inst, reff426_op in H. discriminate H. Qed.

Lemma reff426_not3065 : ~ @Equation3065 Fin3 reff426_inst.
Proof. unfold Equation3065. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff426_inst, reff426_op in H. discriminate H. Qed.

Lemma reff426_not3068 : ~ @Equation3068 Fin3 reff426_inst.
Proof. unfold Equation3068. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff426_inst, reff426_op in H. discriminate H. Qed.

Lemma reff426_not3069 : ~ @Equation3069 Fin3 reff426_inst.
Proof. unfold Equation3069. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff426_inst, reff426_op in H. discriminate H. Qed.

Lemma reff426_not3076 : ~ @Equation3076 Fin3 reff426_inst.
Proof. unfold Equation3076. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff426_inst, reff426_op in H. discriminate H. Qed.

Lemma reff426_not3078 : ~ @Equation3078 Fin3 reff426_inst.
Proof. unfold Equation3078. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff426_inst, reff426_op in H. discriminate H. Qed.

Lemma reff426_not3102 : ~ @Equation3102 Fin3 reff426_inst.
Proof. unfold Equation3102. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff426_inst, reff426_op in H. discriminate H. Qed.

Lemma reff426_not3103 : ~ @Equation3103 Fin3 reff426_inst.
Proof. unfold Equation3103. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff426_inst, reff426_op in H. discriminate H. Qed.

Lemma reff426_not3106 : ~ @Equation3106 Fin3 reff426_inst.
Proof. unfold Equation3106. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff426_inst, reff426_op in H. discriminate H. Qed.

Lemma reff426_not3112 : ~ @Equation3112 Fin3 reff426_inst.
Proof. unfold Equation3112. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff426_inst, reff426_op in H. discriminate H. Qed.

Lemma reff426_not3115 : ~ @Equation3115 Fin3 reff426_inst.
Proof. unfold Equation3115. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff426_inst, reff426_op in H. discriminate H. Qed.

Lemma reff426_not3116 : ~ @Equation3116 Fin3 reff426_inst.
Proof. unfold Equation3116. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff426_inst, reff426_op in H. discriminate H. Qed.

Lemma reff426_not3140 : ~ @Equation3140 Fin3 reff426_inst.
Proof. unfold Equation3140. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff426_inst, reff426_op in H. discriminate H. Qed.

Lemma reff426_not3142 : ~ @Equation3142 Fin3 reff426_inst.
Proof. unfold Equation3142. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff426_inst, reff426_op in H. discriminate H. Qed.

Lemma reff426_not3149 : ~ @Equation3149 Fin3 reff426_inst.
Proof. unfold Equation3149. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff426_inst, reff426_op in H. discriminate H. Qed.

Lemma reff426_not3150 : ~ @Equation3150 Fin3 reff426_inst.
Proof. unfold Equation3150. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff426_inst, reff426_op in H. discriminate H. Qed.

Lemma reff426_not3253 : ~ @Equation3253 Fin3 reff426_inst.
Proof. unfold Equation3253. intro H. specialize (H F3_1). unfold magma_op, reff426_inst, reff426_op in H. discriminate H. Qed.

Lemma reff426_not3457 : ~ @Equation3457 Fin3 reff426_inst.
Proof. unfold Equation3457. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff426_inst, reff426_op in H. discriminate H. Qed.

Lemma reff426_not3458 : ~ @Equation3458 Fin3 reff426_inst.
Proof. unfold Equation3458. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff426_inst, reff426_op in H. discriminate H. Qed.

Lemma reff426_not3461 : ~ @Equation3461 Fin3 reff426_inst.
Proof. unfold Equation3461. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff426_inst, reff426_op in H. discriminate H. Qed.

Lemma reff426_not3462 : ~ @Equation3462 Fin3 reff426_inst.
Proof. unfold Equation3462. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff426_inst, reff426_op in H. discriminate H. Qed.

Lemma reff426_not3465 : ~ @Equation3465 Fin3 reff426_inst.
Proof. unfold Equation3465. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff426_inst, reff426_op in H. discriminate H. Qed.

Lemma reff426_not3474 : ~ @Equation3474 Fin3 reff426_inst.
Proof. unfold Equation3474. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff426_inst, reff426_op in H. discriminate H. Qed.

Lemma reff426_not3475 : ~ @Equation3475 Fin3 reff426_inst.
Proof. unfold Equation3475. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff426_inst, reff426_op in H. discriminate H. Qed.

Lemma reff426_not3482 : ~ @Equation3482 Fin3 reff426_inst.
Proof. unfold Equation3482. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff426_inst, reff426_op in H. discriminate H. Qed.

Lemma reff426_not3484 : ~ @Equation3484 Fin3 reff426_inst.
Proof. unfold Equation3484. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff426_inst, reff426_op in H. discriminate H. Qed.

Lemma reff426_not3511 : ~ @Equation3511 Fin3 reff426_inst.
Proof. unfold Equation3511. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff426_inst, reff426_op in H. discriminate H. Qed.

Lemma reff426_not3512 : ~ @Equation3512 Fin3 reff426_inst.
Proof. unfold Equation3512. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff426_inst, reff426_op in H. discriminate H. Qed.

Lemma reff426_not3519 : ~ @Equation3519 Fin3 reff426_inst.
Proof. unfold Equation3519. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff426_inst, reff426_op in H. discriminate H. Qed.

Lemma reff426_not3521 : ~ @Equation3521 Fin3 reff426_inst.
Proof. unfold Equation3521. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff426_inst, reff426_op in H. discriminate H. Qed.

Lemma reff426_not3545 : ~ @Equation3545 Fin3 reff426_inst.
Proof. unfold Equation3545. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff426_inst, reff426_op in H. discriminate H. Qed.

Lemma reff426_not3546 : ~ @Equation3546 Fin3 reff426_inst.
Proof. unfold Equation3546. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff426_inst, reff426_op in H. discriminate H. Qed.

Lemma reff426_not3549 : ~ @Equation3549 Fin3 reff426_inst.
Proof. unfold Equation3549. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff426_inst, reff426_op in H. discriminate H. Qed.

Lemma reff426_not3555 : ~ @Equation3555 Fin3 reff426_inst.
Proof. unfold Equation3555. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff426_inst, reff426_op in H. discriminate H. Qed.

Lemma reff426_not3558 : ~ @Equation3558 Fin3 reff426_inst.
Proof. unfold Equation3558. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff426_inst, reff426_op in H. discriminate H. Qed.

Lemma reff426_not3660 : ~ @Equation3660 Fin3 reff426_inst.
Proof. unfold Equation3660. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff426_inst, reff426_op in H. discriminate H. Qed.

Lemma reff426_not3661 : ~ @Equation3661 Fin3 reff426_inst.
Proof. unfold Equation3661. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff426_inst, reff426_op in H. discriminate H. Qed.

Lemma reff426_not3664 : ~ @Equation3664 Fin3 reff426_inst.
Proof. unfold Equation3664. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff426_inst, reff426_op in H. discriminate H. Qed.

Lemma reff426_not3667 : ~ @Equation3667 Fin3 reff426_inst.
Proof. unfold Equation3667. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff426_inst, reff426_op in H. discriminate H. Qed.

Lemma reff426_not3668 : ~ @Equation3668 Fin3 reff426_inst.
Proof. unfold Equation3668. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff426_inst, reff426_op in H. discriminate H. Qed.

Lemma reff426_not3674 : ~ @Equation3674 Fin3 reff426_inst.
Proof. unfold Equation3674. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff426_inst, reff426_op in H. discriminate H. Qed.

Lemma reff426_not3675 : ~ @Equation3675 Fin3 reff426_inst.
Proof. unfold Equation3675. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff426_inst, reff426_op in H. discriminate H. Qed.

Lemma reff426_not3678 : ~ @Equation3678 Fin3 reff426_inst.
Proof. unfold Equation3678. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff426_inst, reff426_op in H. discriminate H. Qed.

Lemma reff426_not3685 : ~ @Equation3685 Fin3 reff426_inst.
Proof. unfold Equation3685. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff426_inst, reff426_op in H. discriminate H. Qed.

Lemma reff426_not3687 : ~ @Equation3687 Fin3 reff426_inst.
Proof. unfold Equation3687. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff426_inst, reff426_op in H. discriminate H. Qed.

Lemma reff426_not3714 : ~ @Equation3714 Fin3 reff426_inst.
Proof. unfold Equation3714. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff426_inst, reff426_op in H. discriminate H. Qed.

Lemma reff426_not3721 : ~ @Equation3721 Fin3 reff426_inst.
Proof. unfold Equation3721. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff426_inst, reff426_op in H. discriminate H. Qed.

Lemma reff426_not3722 : ~ @Equation3722 Fin3 reff426_inst.
Proof. unfold Equation3722. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff426_inst, reff426_op in H. discriminate H. Qed.

Lemma reff426_not3725 : ~ @Equation3725 Fin3 reff426_inst.
Proof. unfold Equation3725. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff426_inst, reff426_op in H. discriminate H. Qed.

Lemma reff426_not3749 : ~ @Equation3749 Fin3 reff426_inst.
Proof. unfold Equation3749. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff426_inst, reff426_op in H. discriminate H. Qed.

Lemma reff426_not3751 : ~ @Equation3751 Fin3 reff426_inst.
Proof. unfold Equation3751. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff426_inst, reff426_op in H. discriminate H. Qed.

Lemma reff426_not3761 : ~ @Equation3761 Fin3 reff426_inst.
Proof. unfold Equation3761. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff426_inst, reff426_op in H. discriminate H. Qed.

Lemma reff426_not3862 : ~ @Equation3862 Fin3 reff426_inst.
Proof. unfold Equation3862. intro H. specialize (H F3_1). unfold magma_op, reff426_inst, reff426_op in H. discriminate H. Qed.

Lemma reff426_not4066 : ~ @Equation4066 Fin3 reff426_inst.
Proof. unfold Equation4066. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff426_inst, reff426_op in H. discriminate H. Qed.

Lemma reff426_not4067 : ~ @Equation4067 Fin3 reff426_inst.
Proof. unfold Equation4067. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff426_inst, reff426_op in H. discriminate H. Qed.

Lemma reff426_not4070 : ~ @Equation4070 Fin3 reff426_inst.
Proof. unfold Equation4070. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff426_inst, reff426_op in H. discriminate H. Qed.

Lemma reff426_not4071 : ~ @Equation4071 Fin3 reff426_inst.
Proof. unfold Equation4071. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff426_inst, reff426_op in H. discriminate H. Qed.

Lemma reff426_not4074 : ~ @Equation4074 Fin3 reff426_inst.
Proof. unfold Equation4074. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff426_inst, reff426_op in H. discriminate H. Qed.

Lemma reff426_not4080 : ~ @Equation4080 Fin3 reff426_inst.
Proof. unfold Equation4080. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff426_inst, reff426_op in H. discriminate H. Qed.

Lemma reff426_not4083 : ~ @Equation4083 Fin3 reff426_inst.
Proof. unfold Equation4083. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff426_inst, reff426_op in H. discriminate H. Qed.

Lemma reff426_not4084 : ~ @Equation4084 Fin3 reff426_inst.
Proof. unfold Equation4084. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff426_inst, reff426_op in H. discriminate H. Qed.

Lemma reff426_not4091 : ~ @Equation4091 Fin3 reff426_inst.
Proof. unfold Equation4091. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff426_inst, reff426_op in H. discriminate H. Qed.

Lemma reff426_not4093 : ~ @Equation4093 Fin3 reff426_inst.
Proof. unfold Equation4093. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff426_inst, reff426_op in H. discriminate H. Qed.

Lemma reff426_not4120 : ~ @Equation4120 Fin3 reff426_inst.
Proof. unfold Equation4120. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff426_inst, reff426_op in H. discriminate H. Qed.

Lemma reff426_not4121 : ~ @Equation4121 Fin3 reff426_inst.
Proof. unfold Equation4121. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff426_inst, reff426_op in H. discriminate H. Qed.

Lemma reff426_not4128 : ~ @Equation4128 Fin3 reff426_inst.
Proof. unfold Equation4128. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff426_inst, reff426_op in H. discriminate H. Qed.

Lemma reff426_not4130 : ~ @Equation4130 Fin3 reff426_inst.
Proof. unfold Equation4130. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff426_inst, reff426_op in H. discriminate H. Qed.

Lemma reff426_not4155 : ~ @Equation4155 Fin3 reff426_inst.
Proof. unfold Equation4155. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff426_inst, reff426_op in H. discriminate H. Qed.

Lemma reff426_not4158 : ~ @Equation4158 Fin3 reff426_inst.
Proof. unfold Equation4158. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff426_inst, reff426_op in H. discriminate H. Qed.

Lemma reff426_not4164 : ~ @Equation4164 Fin3 reff426_inst.
Proof. unfold Equation4164. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff426_inst, reff426_op in H. discriminate H. Qed.

Lemma reff426_not4167 : ~ @Equation4167 Fin3 reff426_inst.
Proof. unfold Equation4167. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff426_inst, reff426_op in H. discriminate H. Qed.

Lemma reff426_not4268 : ~ @Equation4268 Fin3 reff426_inst.
Proof. unfold Equation4268. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff426_inst, reff426_op in H. discriminate H. Qed.

Lemma reff426_not4269 : ~ @Equation4269 Fin3 reff426_inst.
Proof. unfold Equation4269. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff426_inst, reff426_op in H. discriminate H. Qed.

Lemma reff426_not4272 : ~ @Equation4272 Fin3 reff426_inst.
Proof. unfold Equation4272. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff426_inst, reff426_op in H. discriminate H. Qed.

Lemma reff426_not4275 : ~ @Equation4275 Fin3 reff426_inst.
Proof. unfold Equation4275. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff426_inst, reff426_op in H. discriminate H. Qed.

Lemma reff426_not4276 : ~ @Equation4276 Fin3 reff426_inst.
Proof. unfold Equation4276. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff426_inst, reff426_op in H. discriminate H. Qed.

Lemma reff426_not4283 : ~ @Equation4283 Fin3 reff426_inst.
Proof. unfold Equation4283. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff426_inst, reff426_op in H. discriminate H. Qed.

Lemma reff426_not4284 : ~ @Equation4284 Fin3 reff426_inst.
Proof. unfold Equation4284. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff426_inst, reff426_op in H. discriminate H. Qed.

Lemma reff426_not4290 : ~ @Equation4290 Fin3 reff426_inst.
Proof. unfold Equation4290. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff426_inst, reff426_op in H. discriminate H. Qed.

Lemma reff426_not4291 : ~ @Equation4291 Fin3 reff426_inst.
Proof. unfold Equation4291. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff426_inst, reff426_op in H. discriminate H. Qed.

Lemma reff426_not4314 : ~ @Equation4314 Fin3 reff426_inst.
Proof. unfold Equation4314. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff426_inst, reff426_op in H. discriminate H. Qed.

Lemma reff426_not4321 : ~ @Equation4321 Fin3 reff426_inst.
Proof. unfold Equation4321. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff426_inst, reff426_op in H. discriminate H. Qed.

Lemma reff426_not4343 : ~ @Equation4343 Fin3 reff426_inst.
Proof. unfold Equation4343. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff426_inst, reff426_op in H. discriminate H. Qed.

Lemma reff426_not4380 : ~ @Equation4380 Fin3 reff426_inst.
Proof. unfold Equation4380. intro H. specialize (H F3_1). unfold magma_op, reff426_inst, reff426_op in H. discriminate H. Qed.

Lemma reff426_not4583 : ~ @Equation4583 Fin3 reff426_inst.
Proof. unfold Equation4583. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff426_inst, reff426_op in H. discriminate H. Qed.

Lemma reff426_not4584 : ~ @Equation4584 Fin3 reff426_inst.
Proof. unfold Equation4584. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff426_inst, reff426_op in H. discriminate H. Qed.

Lemma reff426_not4587 : ~ @Equation4587 Fin3 reff426_inst.
Proof. unfold Equation4587. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff426_inst, reff426_op in H. discriminate H. Qed.

Lemma reff426_not4588 : ~ @Equation4588 Fin3 reff426_inst.
Proof. unfold Equation4588. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff426_inst, reff426_op in H. discriminate H. Qed.

Lemma reff426_not4591 : ~ @Equation4591 Fin3 reff426_inst.
Proof. unfold Equation4591. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff426_inst, reff426_op in H. discriminate H. Qed.

Lemma reff426_not4598 : ~ @Equation4598 Fin3 reff426_inst.
Proof. unfold Equation4598. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff426_inst, reff426_op in H. discriminate H. Qed.

Lemma reff426_not4599 : ~ @Equation4599 Fin3 reff426_inst.
Proof. unfold Equation4599. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff426_inst, reff426_op in H. discriminate H. Qed.

Lemma reff426_not4606 : ~ @Equation4606 Fin3 reff426_inst.
Proof. unfold Equation4606. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff426_inst, reff426_op in H. discriminate H. Qed.

Lemma reff426_not4608 : ~ @Equation4608 Fin3 reff426_inst.
Proof. unfold Equation4608. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff426_inst, reff426_op in H. discriminate H. Qed.

Lemma reff426_not4629 : ~ @Equation4629 Fin3 reff426_inst.
Proof. unfold Equation4629. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff426_inst, reff426_op in H. discriminate H. Qed.

Lemma reff426_not4635 : ~ @Equation4635 Fin3 reff426_inst.
Proof. unfold Equation4635. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff426_inst, reff426_op in H. discriminate H. Qed.

Lemma reff426_not4658 : ~ @Equation4658 Fin3 reff426_inst.
Proof. unfold Equation4658. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff426_inst, reff426_op in H. discriminate H. Qed.
