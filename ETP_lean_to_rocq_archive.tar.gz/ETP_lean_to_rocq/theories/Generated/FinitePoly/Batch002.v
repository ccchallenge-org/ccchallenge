(** * FinitePoly counterexamples — batch 2
    Auto-generated from Lean4 FinitePoly files. *)

From Stdlib Require Import Utf8.

From ETP Require Import Magma.
From ETP Require Import FinMagma.
From ETP.Equations Require Import All.

Open Scope magma_scope.

(** ---- reff144 (Fin3) ---- *)

Definition reff144_op (x y : Fin3) : Fin3 :=
  match x, y with
  | F3_0, F3_0 => F3_0 | F3_0, F3_1 => F3_0 | F3_0, F3_2 => F3_2
  | F3_1, F3_0 => F3_2 | F3_1, F3_1 => F3_0 | F3_1, F3_2 => F3_0
  | F3_2, F3_0 => F3_0 | F3_2, F3_1 => F3_2 | F3_2, F3_2 => F3_0
  end.

#[local] Instance reff144_inst : Magma Fin3 := {| magma_op := reff144_op |}.

Lemma reff144_sat3282 : @Equation3282 Fin3 reff144_inst.
Proof. unfold Equation3282, magma_op, reff144_inst, reff144_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff144_sat3709 : @Equation3709 Fin3 reff144_inst.
Proof. unfold Equation3709, magma_op, reff144_inst, reff144_op. intros x y z w. destruct x, y, z, w; reflexivity. Qed.

Lemma reff144_sat3749 : @Equation3749 Fin3 reff144_inst.
Proof. unfold Equation3749, magma_op, reff144_inst, reff144_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff144_sat3820 : @Equation3820 Fin3 reff144_inst.
Proof. unfold Equation3820, magma_op, reff144_inst, reff144_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff144_sat4094 : @Equation4094 Fin3 reff144_inst.
Proof. unfold Equation4094, magma_op, reff144_inst, reff144_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff144_sat4321 : @Equation4321 Fin3 reff144_inst.
Proof. unfold Equation4321, magma_op, reff144_inst, reff144_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff144_sat4658 : @Equation4658 Fin3 reff144_inst.
Proof. unfold Equation4658, magma_op, reff144_inst, reff144_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff144_not47 : ~ @Equation47 Fin3 reff144_inst.
Proof. unfold Equation47. intro H. specialize (H F3_1). unfold magma_op, reff144_inst, reff144_op in H. discriminate H. Qed.

Lemma reff144_not99 : ~ @Equation99 Fin3 reff144_inst.
Proof. unfold Equation99. intro H. specialize (H F3_1). unfold magma_op, reff144_inst, reff144_op in H. discriminate H. Qed.

Lemma reff144_not151 : ~ @Equation151 Fin3 reff144_inst.
Proof. unfold Equation151. intro H. specialize (H F3_1). unfold magma_op, reff144_inst, reff144_op in H. discriminate H. Qed.

Lemma reff144_not203 : ~ @Equation203 Fin3 reff144_inst.
Proof. unfold Equation203. intro H. specialize (H F3_1). unfold magma_op, reff144_inst, reff144_op in H. discriminate H. Qed.

Lemma reff144_not255 : ~ @Equation255 Fin3 reff144_inst.
Proof. unfold Equation255. intro H. specialize (H F3_1). unfold magma_op, reff144_inst, reff144_op in H. discriminate H. Qed.

Lemma reff144_not307 : ~ @Equation307 Fin3 reff144_inst.
Proof. unfold Equation307. intro H. specialize (H F3_1). unfold magma_op, reff144_inst, reff144_op in H. discriminate H. Qed.

Lemma reff144_not359 : ~ @Equation359 Fin3 reff144_inst.
Proof. unfold Equation359. intro H. specialize (H F3_2). unfold magma_op, reff144_inst, reff144_op in H. discriminate H. Qed.

Lemma reff144_not411 : ~ @Equation411 Fin3 reff144_inst.
Proof. unfold Equation411. intro H. specialize (H F3_1). unfold magma_op, reff144_inst, reff144_op in H. discriminate H. Qed.

Lemma reff144_not614 : ~ @Equation614 Fin3 reff144_inst.
Proof. unfold Equation614. intro H. specialize (H F3_1). unfold magma_op, reff144_inst, reff144_op in H. discriminate H. Qed.

Lemma reff144_not817 : ~ @Equation817 Fin3 reff144_inst.
Proof. unfold Equation817. intro H. specialize (H F3_1). unfold magma_op, reff144_inst, reff144_op in H. discriminate H. Qed.

Lemma reff144_not1020 : ~ @Equation1020 Fin3 reff144_inst.
Proof. unfold Equation1020. intro H. specialize (H F3_1). unfold magma_op, reff144_inst, reff144_op in H. discriminate H. Qed.

Lemma reff144_not1223 : ~ @Equation1223 Fin3 reff144_inst.
Proof. unfold Equation1223. intro H. specialize (H F3_1). unfold magma_op, reff144_inst, reff144_op in H. discriminate H. Qed.

Lemma reff144_not1426 : ~ @Equation1426 Fin3 reff144_inst.
Proof. unfold Equation1426. intro H. specialize (H F3_1). unfold magma_op, reff144_inst, reff144_op in H. discriminate H. Qed.

Lemma reff144_not1629 : ~ @Equation1629 Fin3 reff144_inst.
Proof. unfold Equation1629. intro H. specialize (H F3_1). unfold magma_op, reff144_inst, reff144_op in H. discriminate H. Qed.

Lemma reff144_not1832 : ~ @Equation1832 Fin3 reff144_inst.
Proof. unfold Equation1832. intro H. specialize (H F3_1). unfold magma_op, reff144_inst, reff144_op in H. discriminate H. Qed.

Lemma reff144_not2035 : ~ @Equation2035 Fin3 reff144_inst.
Proof. unfold Equation2035. intro H. specialize (H F3_1). unfold magma_op, reff144_inst, reff144_op in H. discriminate H. Qed.

Lemma reff144_not2238 : ~ @Equation2238 Fin3 reff144_inst.
Proof. unfold Equation2238. intro H. specialize (H F3_1). unfold magma_op, reff144_inst, reff144_op in H. discriminate H. Qed.

Lemma reff144_not2441 : ~ @Equation2441 Fin3 reff144_inst.
Proof. unfold Equation2441. intro H. specialize (H F3_1). unfold magma_op, reff144_inst, reff144_op in H. discriminate H. Qed.

Lemma reff144_not2644 : ~ @Equation2644 Fin3 reff144_inst.
Proof. unfold Equation2644. intro H. specialize (H F3_1). unfold magma_op, reff144_inst, reff144_op in H. discriminate H. Qed.

Lemma reff144_not2847 : ~ @Equation2847 Fin3 reff144_inst.
Proof. unfold Equation2847. intro H. specialize (H F3_1). unfold magma_op, reff144_inst, reff144_op in H. discriminate H. Qed.

Lemma reff144_not3050 : ~ @Equation3050 Fin3 reff144_inst.
Proof. unfold Equation3050. intro H. specialize (H F3_1). unfold magma_op, reff144_inst, reff144_op in H. discriminate H. Qed.

Lemma reff144_not3254 : ~ @Equation3254 Fin3 reff144_inst.
Proof. unfold Equation3254. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff144_inst, reff144_op in H. discriminate H. Qed.

Lemma reff144_not3255 : ~ @Equation3255 Fin3 reff144_inst.
Proof. unfold Equation3255. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff144_inst, reff144_op in H. discriminate H. Qed.

Lemma reff144_not3258 : ~ @Equation3258 Fin3 reff144_inst.
Proof. unfold Equation3258. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff144_inst, reff144_op in H. discriminate H. Qed.

Lemma reff144_not3259 : ~ @Equation3259 Fin3 reff144_inst.
Proof. unfold Equation3259. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff144_inst, reff144_op in H. discriminate H. Qed.

Lemma reff144_not3261 : ~ @Equation3261 Fin3 reff144_inst.
Proof. unfold Equation3261. intro H. specialize (H F3_1 F3_0). unfold magma_op, reff144_inst, reff144_op in H. discriminate H. Qed.

Lemma reff144_not3262 : ~ @Equation3262 Fin3 reff144_inst.
Proof. unfold Equation3262. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff144_inst, reff144_op in H. discriminate H. Qed.

Lemma reff144_not3268 : ~ @Equation3268 Fin3 reff144_inst.
Proof. unfold Equation3268. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff144_inst, reff144_op in H. discriminate H. Qed.

Lemma reff144_not3269 : ~ @Equation3269 Fin3 reff144_inst.
Proof. unfold Equation3269. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff144_inst, reff144_op in H. discriminate H. Qed.

Lemma reff144_not3271 : ~ @Equation3271 Fin3 reff144_inst.
Proof. unfold Equation3271. intro H. specialize (H F3_1 F3_0). unfold magma_op, reff144_inst, reff144_op in H. discriminate H. Qed.

Lemma reff144_not3272 : ~ @Equation3272 Fin3 reff144_inst.
Proof. unfold Equation3272. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff144_inst, reff144_op in H. discriminate H. Qed.

Lemma reff144_not3279 : ~ @Equation3279 Fin3 reff144_inst.
Proof. unfold Equation3279. intro H. specialize (H F3_1 F3_0). unfold magma_op, reff144_inst, reff144_op in H. discriminate H. Qed.

Lemma reff144_not3281 : ~ @Equation3281 Fin3 reff144_inst.
Proof. unfold Equation3281. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff144_inst, reff144_op in H. discriminate H. Qed.

Lemma reff144_not3306 : ~ @Equation3306 Fin3 reff144_inst.
Proof. unfold Equation3306. intro H. specialize (H F3_2 F3_1). unfold magma_op, reff144_inst, reff144_op in H. discriminate H. Qed.

Lemma reff144_not3308 : ~ @Equation3308 Fin3 reff144_inst.
Proof. unfold Equation3308. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff144_inst, reff144_op in H. discriminate H. Qed.

Lemma reff144_not3309 : ~ @Equation3309 Fin3 reff144_inst.
Proof. unfold Equation3309. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff144_inst, reff144_op in H. discriminate H. Qed.

Lemma reff144_not3315 : ~ @Equation3315 Fin3 reff144_inst.
Proof. unfold Equation3315. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff144_inst, reff144_op in H. discriminate H. Qed.

Lemma reff144_not3316 : ~ @Equation3316 Fin3 reff144_inst.
Proof. unfold Equation3316. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff144_inst, reff144_op in H. discriminate H. Qed.

Lemma reff144_not3318 : ~ @Equation3318 Fin3 reff144_inst.
Proof. unfold Equation3318. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff144_inst, reff144_op in H. discriminate H. Qed.

Lemma reff144_not3319 : ~ @Equation3319 Fin3 reff144_inst.
Proof. unfold Equation3319. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff144_inst, reff144_op in H. discriminate H. Qed.

Lemma reff144_not3342 : ~ @Equation3342 Fin3 reff144_inst.
Proof. unfold Equation3342. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff144_inst, reff144_op in H. discriminate H. Qed.

Lemma reff144_not3343 : ~ @Equation3343 Fin3 reff144_inst.
Proof. unfold Equation3343. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff144_inst, reff144_op in H. discriminate H. Qed.

Lemma reff144_not3345 : ~ @Equation3345 Fin3 reff144_inst.
Proof. unfold Equation3345. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff144_inst, reff144_op in H. discriminate H. Qed.

Lemma reff144_not3346 : ~ @Equation3346 Fin3 reff144_inst.
Proof. unfold Equation3346. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff144_inst, reff144_op in H. discriminate H. Qed.

Lemma reff144_not3352 : ~ @Equation3352 Fin3 reff144_inst.
Proof. unfold Equation3352. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff144_inst, reff144_op in H. discriminate H. Qed.

Lemma reff144_not3353 : ~ @Equation3353 Fin3 reff144_inst.
Proof. unfold Equation3353. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff144_inst, reff144_op in H. discriminate H. Qed.

Lemma reff144_not3456 : ~ @Equation3456 Fin3 reff144_inst.
Proof. unfold Equation3456. intro H. specialize (H F3_1). unfold magma_op, reff144_inst, reff144_op in H. discriminate H. Qed.

Lemma reff144_not3660 : ~ @Equation3660 Fin3 reff144_inst.
Proof. unfold Equation3660. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff144_inst, reff144_op in H. discriminate H. Qed.

Lemma reff144_not3661 : ~ @Equation3661 Fin3 reff144_inst.
Proof. unfold Equation3661. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff144_inst, reff144_op in H. discriminate H. Qed.

Lemma reff144_not3667 : ~ @Equation3667 Fin3 reff144_inst.
Proof. unfold Equation3667. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff144_inst, reff144_op in H. discriminate H. Qed.

Lemma reff144_not3675 : ~ @Equation3675 Fin3 reff144_inst.
Proof. unfold Equation3675. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff144_inst, reff144_op in H. discriminate H. Qed.

Lemma reff144_not3685 : ~ @Equation3685 Fin3 reff144_inst.
Proof. unfold Equation3685. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff144_inst, reff144_op in H. discriminate H. Qed.

Lemma reff144_not3687 : ~ @Equation3687 Fin3 reff144_inst.
Proof. unfold Equation3687. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff144_inst, reff144_op in H. discriminate H. Qed.

Lemma reff144_not3714 : ~ @Equation3714 Fin3 reff144_inst.
Proof. unfold Equation3714. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff144_inst, reff144_op in H. discriminate H. Qed.

Lemma reff144_not3721 : ~ @Equation3721 Fin3 reff144_inst.
Proof. unfold Equation3721. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff144_inst, reff144_op in H. discriminate H. Qed.

Lemma reff144_not3722 : ~ @Equation3722 Fin3 reff144_inst.
Proof. unfold Equation3722. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff144_inst, reff144_op in H. discriminate H. Qed.

Lemma reff144_not3724 : ~ @Equation3724 Fin3 reff144_inst.
Proof. unfold Equation3724. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff144_inst, reff144_op in H. discriminate H. Qed.

Lemma reff144_not3725 : ~ @Equation3725 Fin3 reff144_inst.
Proof. unfold Equation3725. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff144_inst, reff144_op in H. discriminate H. Qed.

Lemma reff144_not3748 : ~ @Equation3748 Fin3 reff144_inst.
Proof. unfold Equation3748. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff144_inst, reff144_op in H. discriminate H. Qed.

Lemma reff144_not3751 : ~ @Equation3751 Fin3 reff144_inst.
Proof. unfold Equation3751. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff144_inst, reff144_op in H. discriminate H. Qed.

Lemma reff144_not3752 : ~ @Equation3752 Fin3 reff144_inst.
Proof. unfold Equation3752. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff144_inst, reff144_op in H. discriminate H. Qed.

Lemma reff144_not3761 : ~ @Equation3761 Fin3 reff144_inst.
Proof. unfold Equation3761. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff144_inst, reff144_op in H. discriminate H. Qed.

Lemma reff144_not3769 : ~ @Equation3769 Fin3 reff144_inst.
Proof. unfold Equation3769. intro H. specialize (H F3_0 F3_2 F3_1). unfold magma_op, reff144_inst, reff144_op in H. discriminate H. Qed.

Lemma reff144_not3786 : ~ @Equation3786 Fin3 reff144_inst.
Proof. unfold Equation3786. intro H. specialize (H F3_0 F3_2 F3_1). unfold magma_op, reff144_inst, reff144_op in H. discriminate H. Qed.

Lemma reff144_not3862 : ~ @Equation3862 Fin3 reff144_inst.
Proof. unfold Equation3862. intro H. specialize (H F3_1). unfold magma_op, reff144_inst, reff144_op in H. discriminate H. Qed.

Lemma reff144_not4066 : ~ @Equation4066 Fin3 reff144_inst.
Proof. unfold Equation4066. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff144_inst, reff144_op in H. discriminate H. Qed.

Lemma reff144_not4067 : ~ @Equation4067 Fin3 reff144_inst.
Proof. unfold Equation4067. intro H. specialize (H F3_1 F3_2). unfold magma_op, reff144_inst, reff144_op in H. discriminate H. Qed.

Lemma reff144_not4070 : ~ @Equation4070 Fin3 reff144_inst.
Proof. unfold Equation4070. intro H. specialize (H F3_1 F3_0). unfold magma_op, reff144_inst, reff144_op in H. discriminate H. Qed.

Lemma reff144_not4071 : ~ @Equation4071 Fin3 reff144_inst.
Proof. unfold Equation4071. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff144_inst, reff144_op in H. discriminate H. Qed.

Lemma reff144_not4073 : ~ @Equation4073 Fin3 reff144_inst.
Proof. unfold Equation4073. intro H. specialize (H F3_1 F3_2). unfold magma_op, reff144_inst, reff144_op in H. discriminate H. Qed.

Lemma reff144_not4074 : ~ @Equation4074 Fin3 reff144_inst.
Proof. unfold Equation4074. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff144_inst, reff144_op in H. discriminate H. Qed.

Lemma reff144_not4080 : ~ @Equation4080 Fin3 reff144_inst.
Proof. unfold Equation4080. intro H. specialize (H F3_1 F3_2). unfold magma_op, reff144_inst, reff144_op in H. discriminate H. Qed.

Lemma reff144_not4081 : ~ @Equation4081 Fin3 reff144_inst.
Proof. unfold Equation4081. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff144_inst, reff144_op in H. discriminate H. Qed.

Lemma reff144_not4083 : ~ @Equation4083 Fin3 reff144_inst.
Proof. unfold Equation4083. intro H. specialize (H F3_2 F3_0). unfold magma_op, reff144_inst, reff144_op in H. discriminate H. Qed.

Lemma reff144_not4084 : ~ @Equation4084 Fin3 reff144_inst.
Proof. unfold Equation4084. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff144_inst, reff144_op in H. discriminate H. Qed.

Lemma reff144_not4091 : ~ @Equation4091 Fin3 reff144_inst.
Proof. unfold Equation4091. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff144_inst, reff144_op in H. discriminate H. Qed.

Lemma reff144_not4093 : ~ @Equation4093 Fin3 reff144_inst.
Proof. unfold Equation4093. intro H. specialize (H F3_1 F3_2). unfold magma_op, reff144_inst, reff144_op in H. discriminate H. Qed.

Lemma reff144_not4118 : ~ @Equation4118 Fin3 reff144_inst.
Proof. unfold Equation4118. intro H. specialize (H F3_1 F3_0). unfold magma_op, reff144_inst, reff144_op in H. discriminate H. Qed.

Lemma reff144_not4120 : ~ @Equation4120 Fin3 reff144_inst.
Proof. unfold Equation4120. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff144_inst, reff144_op in H. discriminate H. Qed.

Lemma reff144_not4121 : ~ @Equation4121 Fin3 reff144_inst.
Proof. unfold Equation4121. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff144_inst, reff144_op in H. discriminate H. Qed.

Lemma reff144_not4127 : ~ @Equation4127 Fin3 reff144_inst.
Proof. unfold Equation4127. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff144_inst, reff144_op in H. discriminate H. Qed.

Lemma reff144_not4128 : ~ @Equation4128 Fin3 reff144_inst.
Proof. unfold Equation4128. intro H. specialize (H F3_1 F3_0). unfold magma_op, reff144_inst, reff144_op in H. discriminate H. Qed.

Lemma reff144_not4130 : ~ @Equation4130 Fin3 reff144_inst.
Proof. unfold Equation4130. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff144_inst, reff144_op in H. discriminate H. Qed.

Lemma reff144_not4131 : ~ @Equation4131 Fin3 reff144_inst.
Proof. unfold Equation4131. intro H. specialize (H F3_1 F3_0). unfold magma_op, reff144_inst, reff144_op in H. discriminate H. Qed.

Lemma reff144_not4155 : ~ @Equation4155 Fin3 reff144_inst.
Proof. unfold Equation4155. intro H. specialize (H F3_1 F3_0). unfold magma_op, reff144_inst, reff144_op in H. discriminate H. Qed.

Lemma reff144_not4157 : ~ @Equation4157 Fin3 reff144_inst.
Proof. unfold Equation4157. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff144_inst, reff144_op in H. discriminate H. Qed.

Lemma reff144_not4158 : ~ @Equation4158 Fin3 reff144_inst.
Proof. unfold Equation4158. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff144_inst, reff144_op in H. discriminate H. Qed.

Lemma reff144_not4164 : ~ @Equation4164 Fin3 reff144_inst.
Proof. unfold Equation4164. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff144_inst, reff144_op in H. discriminate H. Qed.

Lemma reff144_not4165 : ~ @Equation4165 Fin3 reff144_inst.
Proof. unfold Equation4165. intro H. specialize (H F3_1 F3_0). unfold magma_op, reff144_inst, reff144_op in H. discriminate H. Qed.

Lemma reff144_not4167 : ~ @Equation4167 Fin3 reff144_inst.
Proof. unfold Equation4167. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff144_inst, reff144_op in H. discriminate H. Qed.

Lemma reff144_not4268 : ~ @Equation4268 Fin3 reff144_inst.
Proof. unfold Equation4268. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff144_inst, reff144_op in H. discriminate H. Qed.

Lemma reff144_not4269 : ~ @Equation4269 Fin3 reff144_inst.
Proof. unfold Equation4269. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff144_inst, reff144_op in H. discriminate H. Qed.

Lemma reff144_not4272 : ~ @Equation4272 Fin3 reff144_inst.
Proof. unfold Equation4272. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff144_inst, reff144_op in H. discriminate H. Qed.

Lemma reff144_not4273 : ~ @Equation4273 Fin3 reff144_inst.
Proof. unfold Equation4273. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff144_inst, reff144_op in H. discriminate H. Qed.

Lemma reff144_not4275 : ~ @Equation4275 Fin3 reff144_inst.
Proof. unfold Equation4275. intro H. specialize (H F3_1 F3_0). unfold magma_op, reff144_inst, reff144_op in H. discriminate H. Qed.

Lemma reff144_not4276 : ~ @Equation4276 Fin3 reff144_inst.
Proof. unfold Equation4276. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff144_inst, reff144_op in H. discriminate H. Qed.

Lemma reff144_not4283 : ~ @Equation4283 Fin3 reff144_inst.
Proof. unfold Equation4283. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff144_inst, reff144_op in H. discriminate H. Qed.

Lemma reff144_not4284 : ~ @Equation4284 Fin3 reff144_inst.
Proof. unfold Equation4284. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff144_inst, reff144_op in H. discriminate H. Qed.

Lemma reff144_not4290 : ~ @Equation4290 Fin3 reff144_inst.
Proof. unfold Equation4290. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff144_inst, reff144_op in H. discriminate H. Qed.

Lemma reff144_not4291 : ~ @Equation4291 Fin3 reff144_inst.
Proof. unfold Equation4291. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff144_inst, reff144_op in H. discriminate H. Qed.

Lemma reff144_not4293 : ~ @Equation4293 Fin3 reff144_inst.
Proof. unfold Equation4293. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff144_inst, reff144_op in H. discriminate H. Qed.

Lemma reff144_not4314 : ~ @Equation4314 Fin3 reff144_inst.
Proof. unfold Equation4314. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff144_inst, reff144_op in H. discriminate H. Qed.

Lemma reff144_not4320 : ~ @Equation4320 Fin3 reff144_inst.
Proof. unfold Equation4320. intro H. specialize (H F3_1 F3_0). unfold magma_op, reff144_inst, reff144_op in H. discriminate H. Qed.

Lemma reff144_not4343 : ~ @Equation4343 Fin3 reff144_inst.
Proof. unfold Equation4343. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff144_inst, reff144_op in H. discriminate H. Qed.

Lemma reff144_not4380 : ~ @Equation4380 Fin3 reff144_inst.
Proof. unfold Equation4380. intro H. specialize (H F3_1). unfold magma_op, reff144_inst, reff144_op in H. discriminate H. Qed.

Lemma reff144_not4583 : ~ @Equation4583 Fin3 reff144_inst.
Proof. unfold Equation4583. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff144_inst, reff144_op in H. discriminate H. Qed.

Lemma reff144_not4584 : ~ @Equation4584 Fin3 reff144_inst.
Proof. unfold Equation4584. intro H. specialize (H F3_1 F3_0). unfold magma_op, reff144_inst, reff144_op in H. discriminate H. Qed.

Lemma reff144_not4585 : ~ @Equation4585 Fin3 reff144_inst.
Proof. unfold Equation4585. intro H. specialize (H F3_1 F3_2). unfold magma_op, reff144_inst, reff144_op in H. discriminate H. Qed.

Lemma reff144_not4587 : ~ @Equation4587 Fin3 reff144_inst.
Proof. unfold Equation4587. intro H. specialize (H F3_1 F3_2). unfold magma_op, reff144_inst, reff144_op in H. discriminate H. Qed.

Lemma reff144_not4588 : ~ @Equation4588 Fin3 reff144_inst.
Proof. unfold Equation4588. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff144_inst, reff144_op in H. discriminate H. Qed.

Lemma reff144_not4591 : ~ @Equation4591 Fin3 reff144_inst.
Proof. unfold Equation4591. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff144_inst, reff144_op in H. discriminate H. Qed.

Lemma reff144_not4598 : ~ @Equation4598 Fin3 reff144_inst.
Proof. unfold Equation4598. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff144_inst, reff144_op in H. discriminate H. Qed.

Lemma reff144_not4599 : ~ @Equation4599 Fin3 reff144_inst.
Proof. unfold Equation4599. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff144_inst, reff144_op in H. discriminate H. Qed.

Lemma reff144_not4605 : ~ @Equation4605 Fin3 reff144_inst.
Proof. unfold Equation4605. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff144_inst, reff144_op in H. discriminate H. Qed.

Lemma reff144_not4606 : ~ @Equation4606 Fin3 reff144_inst.
Proof. unfold Equation4606. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff144_inst, reff144_op in H. discriminate H. Qed.

Lemma reff144_not4608 : ~ @Equation4608 Fin3 reff144_inst.
Proof. unfold Equation4608. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff144_inst, reff144_op in H. discriminate H. Qed.

Lemma reff144_not4629 : ~ @Equation4629 Fin3 reff144_inst.
Proof. unfold Equation4629. intro H. specialize (H F3_1 F3_0). unfold magma_op, reff144_inst, reff144_op in H. discriminate H. Qed.

Lemma reff144_not4635 : ~ @Equation4635 Fin3 reff144_inst.
Proof. unfold Equation4635. intro H. specialize (H F3_1 F3_0). unfold magma_op, reff144_inst, reff144_op in H. discriminate H. Qed.

Lemma reff144_not4636 : ~ @Equation4636 Fin3 reff144_inst.
Proof. unfold Equation4636. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff144_inst, reff144_op in H. discriminate H. Qed.

(** ---- reff146 (Fin3) ---- *)

Definition reff146_op (x y : Fin3) : Fin3 :=
  match x, y with
  | F3_0, F3_0 => F3_0 | F3_0, F3_1 => F3_2 | F3_0, F3_2 => F3_0
  | F3_1, F3_0 => F3_0 | F3_1, F3_1 => F3_0 | F3_1, F3_2 => F3_2
  | F3_2, F3_0 => F3_2 | F3_2, F3_1 => F3_0 | F3_2, F3_2 => F3_0
  end.

#[local] Instance reff146_inst : Magma Fin3 := {| magma_op := reff146_op |}.

Lemma reff146_sat3282 : @Equation3282 Fin3 reff146_inst.
Proof. unfold Equation3282, magma_op, reff146_inst, reff146_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff146_sat3693 : @Equation3693 Fin3 reff146_inst.
Proof. unfold Equation3693, magma_op, reff146_inst, reff146_op. intros x y z w. destruct x, y, z, w; reflexivity. Qed.

Lemma reff146_sat3724 : @Equation3724 Fin3 reff146_inst.
Proof. unfold Equation3724, magma_op, reff146_inst, reff146_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff146_sat3729 : @Equation3729 Fin3 reff146_inst.
Proof. unfold Equation3729, magma_op, reff146_inst, reff146_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff146_sat4094 : @Equation4094 Fin3 reff146_inst.
Proof. unfold Equation4094, magma_op, reff146_inst, reff146_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff146_sat4293 : @Equation4293 Fin3 reff146_inst.
Proof. unfold Equation4293, magma_op, reff146_inst, reff146_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff146_sat4636 : @Equation4636 Fin3 reff146_inst.
Proof. unfold Equation4636, magma_op, reff146_inst, reff146_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff146_not47 : ~ @Equation47 Fin3 reff146_inst.
Proof. unfold Equation47. intro H. specialize (H F3_1). unfold magma_op, reff146_inst, reff146_op in H. discriminate H. Qed.

Lemma reff146_not99 : ~ @Equation99 Fin3 reff146_inst.
Proof. unfold Equation99. intro H. specialize (H F3_1). unfold magma_op, reff146_inst, reff146_op in H. discriminate H. Qed.

Lemma reff146_not151 : ~ @Equation151 Fin3 reff146_inst.
Proof. unfold Equation151. intro H. specialize (H F3_1). unfold magma_op, reff146_inst, reff146_op in H. discriminate H. Qed.

Lemma reff146_not203 : ~ @Equation203 Fin3 reff146_inst.
Proof. unfold Equation203. intro H. specialize (H F3_1). unfold magma_op, reff146_inst, reff146_op in H. discriminate H. Qed.

Lemma reff146_not255 : ~ @Equation255 Fin3 reff146_inst.
Proof. unfold Equation255. intro H. specialize (H F3_1). unfold magma_op, reff146_inst, reff146_op in H. discriminate H. Qed.

Lemma reff146_not307 : ~ @Equation307 Fin3 reff146_inst.
Proof. unfold Equation307. intro H. specialize (H F3_2). unfold magma_op, reff146_inst, reff146_op in H. discriminate H. Qed.

Lemma reff146_not359 : ~ @Equation359 Fin3 reff146_inst.
Proof. unfold Equation359. intro H. specialize (H F3_1). unfold magma_op, reff146_inst, reff146_op in H. discriminate H. Qed.

Lemma reff146_not411 : ~ @Equation411 Fin3 reff146_inst.
Proof. unfold Equation411. intro H. specialize (H F3_1). unfold magma_op, reff146_inst, reff146_op in H. discriminate H. Qed.

Lemma reff146_not614 : ~ @Equation614 Fin3 reff146_inst.
Proof. unfold Equation614. intro H. specialize (H F3_1). unfold magma_op, reff146_inst, reff146_op in H. discriminate H. Qed.

Lemma reff146_not817 : ~ @Equation817 Fin3 reff146_inst.
Proof. unfold Equation817. intro H. specialize (H F3_1). unfold magma_op, reff146_inst, reff146_op in H. discriminate H. Qed.

Lemma reff146_not1020 : ~ @Equation1020 Fin3 reff146_inst.
Proof. unfold Equation1020. intro H. specialize (H F3_1). unfold magma_op, reff146_inst, reff146_op in H. discriminate H. Qed.

Lemma reff146_not1223 : ~ @Equation1223 Fin3 reff146_inst.
Proof. unfold Equation1223. intro H. specialize (H F3_1). unfold magma_op, reff146_inst, reff146_op in H. discriminate H. Qed.

Lemma reff146_not1426 : ~ @Equation1426 Fin3 reff146_inst.
Proof. unfold Equation1426. intro H. specialize (H F3_1). unfold magma_op, reff146_inst, reff146_op in H. discriminate H. Qed.

Lemma reff146_not1629 : ~ @Equation1629 Fin3 reff146_inst.
Proof. unfold Equation1629. intro H. specialize (H F3_1). unfold magma_op, reff146_inst, reff146_op in H. discriminate H. Qed.

Lemma reff146_not1832 : ~ @Equation1832 Fin3 reff146_inst.
Proof. unfold Equation1832. intro H. specialize (H F3_1). unfold magma_op, reff146_inst, reff146_op in H. discriminate H. Qed.

Lemma reff146_not2035 : ~ @Equation2035 Fin3 reff146_inst.
Proof. unfold Equation2035. intro H. specialize (H F3_1). unfold magma_op, reff146_inst, reff146_op in H. discriminate H. Qed.

Lemma reff146_not2238 : ~ @Equation2238 Fin3 reff146_inst.
Proof. unfold Equation2238. intro H. specialize (H F3_1). unfold magma_op, reff146_inst, reff146_op in H. discriminate H. Qed.

Lemma reff146_not2441 : ~ @Equation2441 Fin3 reff146_inst.
Proof. unfold Equation2441. intro H. specialize (H F3_1). unfold magma_op, reff146_inst, reff146_op in H. discriminate H. Qed.

Lemma reff146_not2644 : ~ @Equation2644 Fin3 reff146_inst.
Proof. unfold Equation2644. intro H. specialize (H F3_1). unfold magma_op, reff146_inst, reff146_op in H. discriminate H. Qed.

Lemma reff146_not2847 : ~ @Equation2847 Fin3 reff146_inst.
Proof. unfold Equation2847. intro H. specialize (H F3_1). unfold magma_op, reff146_inst, reff146_op in H. discriminate H. Qed.

Lemma reff146_not3050 : ~ @Equation3050 Fin3 reff146_inst.
Proof. unfold Equation3050. intro H. specialize (H F3_1). unfold magma_op, reff146_inst, reff146_op in H. discriminate H. Qed.

Lemma reff146_not3254 : ~ @Equation3254 Fin3 reff146_inst.
Proof. unfold Equation3254. intro H. specialize (H F3_1 F3_2). unfold magma_op, reff146_inst, reff146_op in H. discriminate H. Qed.

Lemma reff146_not3255 : ~ @Equation3255 Fin3 reff146_inst.
Proof. unfold Equation3255. intro H. specialize (H F3_1 F3_0). unfold magma_op, reff146_inst, reff146_op in H. discriminate H. Qed.

Lemma reff146_not3258 : ~ @Equation3258 Fin3 reff146_inst.
Proof. unfold Equation3258. intro H. specialize (H F3_1 F3_2). unfold magma_op, reff146_inst, reff146_op in H. discriminate H. Qed.

Lemma reff146_not3259 : ~ @Equation3259 Fin3 reff146_inst.
Proof. unfold Equation3259. intro H. specialize (H F3_2 F3_0). unfold magma_op, reff146_inst, reff146_op in H. discriminate H. Qed.

Lemma reff146_not3261 : ~ @Equation3261 Fin3 reff146_inst.
Proof. unfold Equation3261. intro H. specialize (H F3_1 F3_2). unfold magma_op, reff146_inst, reff146_op in H. discriminate H. Qed.

Lemma reff146_not3262 : ~ @Equation3262 Fin3 reff146_inst.
Proof. unfold Equation3262. intro H. specialize (H F3_1 F3_2). unfold magma_op, reff146_inst, reff146_op in H. discriminate H. Qed.

Lemma reff146_not3268 : ~ @Equation3268 Fin3 reff146_inst.
Proof. unfold Equation3268. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff146_inst, reff146_op in H. discriminate H. Qed.

Lemma reff146_not3269 : ~ @Equation3269 Fin3 reff146_inst.
Proof. unfold Equation3269. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff146_inst, reff146_op in H. discriminate H. Qed.

Lemma reff146_not3271 : ~ @Equation3271 Fin3 reff146_inst.
Proof. unfold Equation3271. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff146_inst, reff146_op in H. discriminate H. Qed.

Lemma reff146_not3272 : ~ @Equation3272 Fin3 reff146_inst.
Proof. unfold Equation3272. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff146_inst, reff146_op in H. discriminate H. Qed.

Lemma reff146_not3279 : ~ @Equation3279 Fin3 reff146_inst.
Proof. unfold Equation3279. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff146_inst, reff146_op in H. discriminate H. Qed.

Lemma reff146_not3281 : ~ @Equation3281 Fin3 reff146_inst.
Proof. unfold Equation3281. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff146_inst, reff146_op in H. discriminate H. Qed.

Lemma reff146_not3306 : ~ @Equation3306 Fin3 reff146_inst.
Proof. unfold Equation3306. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff146_inst, reff146_op in H. discriminate H. Qed.

Lemma reff146_not3308 : ~ @Equation3308 Fin3 reff146_inst.
Proof. unfold Equation3308. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff146_inst, reff146_op in H. discriminate H. Qed.

Lemma reff146_not3309 : ~ @Equation3309 Fin3 reff146_inst.
Proof. unfold Equation3309. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff146_inst, reff146_op in H. discriminate H. Qed.

Lemma reff146_not3315 : ~ @Equation3315 Fin3 reff146_inst.
Proof. unfold Equation3315. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff146_inst, reff146_op in H. discriminate H. Qed.

Lemma reff146_not3316 : ~ @Equation3316 Fin3 reff146_inst.
Proof. unfold Equation3316. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff146_inst, reff146_op in H. discriminate H. Qed.

Lemma reff146_not3318 : ~ @Equation3318 Fin3 reff146_inst.
Proof. unfold Equation3318. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff146_inst, reff146_op in H. discriminate H. Qed.

Lemma reff146_not3319 : ~ @Equation3319 Fin3 reff146_inst.
Proof. unfold Equation3319. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff146_inst, reff146_op in H. discriminate H. Qed.

Lemma reff146_not3342 : ~ @Equation3342 Fin3 reff146_inst.
Proof. unfold Equation3342. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff146_inst, reff146_op in H. discriminate H. Qed.

Lemma reff146_not3343 : ~ @Equation3343 Fin3 reff146_inst.
Proof. unfold Equation3343. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff146_inst, reff146_op in H. discriminate H. Qed.

Lemma reff146_not3345 : ~ @Equation3345 Fin3 reff146_inst.
Proof. unfold Equation3345. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff146_inst, reff146_op in H. discriminate H. Qed.

Lemma reff146_not3346 : ~ @Equation3346 Fin3 reff146_inst.
Proof. unfold Equation3346. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff146_inst, reff146_op in H. discriminate H. Qed.

Lemma reff146_not3352 : ~ @Equation3352 Fin3 reff146_inst.
Proof. unfold Equation3352. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff146_inst, reff146_op in H. discriminate H. Qed.

Lemma reff146_not3353 : ~ @Equation3353 Fin3 reff146_inst.
Proof. unfold Equation3353. intro H. specialize (H F3_2 F3_0). unfold magma_op, reff146_inst, reff146_op in H. discriminate H. Qed.

Lemma reff146_not3456 : ~ @Equation3456 Fin3 reff146_inst.
Proof. unfold Equation3456. intro H. specialize (H F3_1). unfold magma_op, reff146_inst, reff146_op in H. discriminate H. Qed.

Lemma reff146_not3664 : ~ @Equation3664 Fin3 reff146_inst.
Proof. unfold Equation3664. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff146_inst, reff146_op in H. discriminate H. Qed.

Lemma reff146_not3667 : ~ @Equation3667 Fin3 reff146_inst.
Proof. unfold Equation3667. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff146_inst, reff146_op in H. discriminate H. Qed.

Lemma reff146_not3668 : ~ @Equation3668 Fin3 reff146_inst.
Proof. unfold Equation3668. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff146_inst, reff146_op in H. discriminate H. Qed.

Lemma reff146_not3674 : ~ @Equation3674 Fin3 reff146_inst.
Proof. unfold Equation3674. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff146_inst, reff146_op in H. discriminate H. Qed.

Lemma reff146_not3675 : ~ @Equation3675 Fin3 reff146_inst.
Proof. unfold Equation3675. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff146_inst, reff146_op in H. discriminate H. Qed.

Lemma reff146_not3678 : ~ @Equation3678 Fin3 reff146_inst.
Proof. unfold Equation3678. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff146_inst, reff146_op in H. discriminate H. Qed.

Lemma reff146_not3712 : ~ @Equation3712 Fin3 reff146_inst.
Proof. unfold Equation3712. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff146_inst, reff146_op in H. discriminate H. Qed.

Lemma reff146_not3714 : ~ @Equation3714 Fin3 reff146_inst.
Proof. unfold Equation3714. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff146_inst, reff146_op in H. discriminate H. Qed.

Lemma reff146_not3722 : ~ @Equation3722 Fin3 reff146_inst.
Proof. unfold Equation3722. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff146_inst, reff146_op in H. discriminate H. Qed.

Lemma reff146_not3726 : ~ @Equation3726 Fin3 reff146_inst.
Proof. unfold Equation3726. intro H. specialize (H F3_0 F3_1 F3_2). unfold magma_op, reff146_inst, reff146_op in H. discriminate H. Qed.

Lemma reff146_not3727 : ~ @Equation3727 Fin3 reff146_inst.
Proof. unfold Equation3727. intro H. specialize (H F3_0 F3_1 F3_2). unfold magma_op, reff146_inst, reff146_op in H. discriminate H. Qed.

Lemma reff146_not3748 : ~ @Equation3748 Fin3 reff146_inst.
Proof. unfold Equation3748. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff146_inst, reff146_op in H. discriminate H. Qed.

Lemma reff146_not3749 : ~ @Equation3749 Fin3 reff146_inst.
Proof. unfold Equation3749. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff146_inst, reff146_op in H. discriminate H. Qed.

Lemma reff146_not3751 : ~ @Equation3751 Fin3 reff146_inst.
Proof. unfold Equation3751. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff146_inst, reff146_op in H. discriminate H. Qed.

Lemma reff146_not3752 : ~ @Equation3752 Fin3 reff146_inst.
Proof. unfold Equation3752. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff146_inst, reff146_op in H. discriminate H. Qed.

Lemma reff146_not3759 : ~ @Equation3759 Fin3 reff146_inst.
Proof. unfold Equation3759. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff146_inst, reff146_op in H. discriminate H. Qed.

Lemma reff146_not3761 : ~ @Equation3761 Fin3 reff146_inst.
Proof. unfold Equation3761. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff146_inst, reff146_op in H. discriminate H. Qed.

Lemma reff146_not3862 : ~ @Equation3862 Fin3 reff146_inst.
Proof. unfold Equation3862. intro H. specialize (H F3_1). unfold magma_op, reff146_inst, reff146_op in H. discriminate H. Qed.

Lemma reff146_not4066 : ~ @Equation4066 Fin3 reff146_inst.
Proof. unfold Equation4066. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff146_inst, reff146_op in H. discriminate H. Qed.

Lemma reff146_not4067 : ~ @Equation4067 Fin3 reff146_inst.
Proof. unfold Equation4067. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff146_inst, reff146_op in H. discriminate H. Qed.

Lemma reff146_not4070 : ~ @Equation4070 Fin3 reff146_inst.
Proof. unfold Equation4070. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff146_inst, reff146_op in H. discriminate H. Qed.

Lemma reff146_not4071 : ~ @Equation4071 Fin3 reff146_inst.
Proof. unfold Equation4071. intro H. specialize (H F3_1 F3_0). unfold magma_op, reff146_inst, reff146_op in H. discriminate H. Qed.

Lemma reff146_not4073 : ~ @Equation4073 Fin3 reff146_inst.
Proof. unfold Equation4073. intro H. specialize (H F3_1 F3_0). unfold magma_op, reff146_inst, reff146_op in H. discriminate H. Qed.

Lemma reff146_not4074 : ~ @Equation4074 Fin3 reff146_inst.
Proof. unfold Equation4074. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff146_inst, reff146_op in H. discriminate H. Qed.

Lemma reff146_not4080 : ~ @Equation4080 Fin3 reff146_inst.
Proof. unfold Equation4080. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff146_inst, reff146_op in H. discriminate H. Qed.

Lemma reff146_not4081 : ~ @Equation4081 Fin3 reff146_inst.
Proof. unfold Equation4081. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff146_inst, reff146_op in H. discriminate H. Qed.

Lemma reff146_not4083 : ~ @Equation4083 Fin3 reff146_inst.
Proof. unfold Equation4083. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff146_inst, reff146_op in H. discriminate H. Qed.

Lemma reff146_not4084 : ~ @Equation4084 Fin3 reff146_inst.
Proof. unfold Equation4084. intro H. specialize (H F3_1 F3_0). unfold magma_op, reff146_inst, reff146_op in H. discriminate H. Qed.

Lemma reff146_not4091 : ~ @Equation4091 Fin3 reff146_inst.
Proof. unfold Equation4091. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff146_inst, reff146_op in H. discriminate H. Qed.

Lemma reff146_not4093 : ~ @Equation4093 Fin3 reff146_inst.
Proof. unfold Equation4093. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff146_inst, reff146_op in H. discriminate H. Qed.

Lemma reff146_not4118 : ~ @Equation4118 Fin3 reff146_inst.
Proof. unfold Equation4118. intro H. specialize (H F3_1 F3_0). unfold magma_op, reff146_inst, reff146_op in H. discriminate H. Qed.

Lemma reff146_not4120 : ~ @Equation4120 Fin3 reff146_inst.
Proof. unfold Equation4120. intro H. specialize (H F3_1 F3_0). unfold magma_op, reff146_inst, reff146_op in H. discriminate H. Qed.

Lemma reff146_not4121 : ~ @Equation4121 Fin3 reff146_inst.
Proof. unfold Equation4121. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff146_inst, reff146_op in H. discriminate H. Qed.

Lemma reff146_not4127 : ~ @Equation4127 Fin3 reff146_inst.
Proof. unfold Equation4127. intro H. specialize (H F3_2 F3_0). unfold magma_op, reff146_inst, reff146_op in H. discriminate H. Qed.

Lemma reff146_not4128 : ~ @Equation4128 Fin3 reff146_inst.
Proof. unfold Equation4128. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff146_inst, reff146_op in H. discriminate H. Qed.

Lemma reff146_not4130 : ~ @Equation4130 Fin3 reff146_inst.
Proof. unfold Equation4130. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff146_inst, reff146_op in H. discriminate H. Qed.

Lemma reff146_not4131 : ~ @Equation4131 Fin3 reff146_inst.
Proof. unfold Equation4131. intro H. specialize (H F3_1 F3_2). unfold magma_op, reff146_inst, reff146_op in H. discriminate H. Qed.

Lemma reff146_not4155 : ~ @Equation4155 Fin3 reff146_inst.
Proof. unfold Equation4155. intro H. specialize (H F3_1 F3_2). unfold magma_op, reff146_inst, reff146_op in H. discriminate H. Qed.

Lemma reff146_not4157 : ~ @Equation4157 Fin3 reff146_inst.
Proof. unfold Equation4157. intro H. specialize (H F3_2 F3_0). unfold magma_op, reff146_inst, reff146_op in H. discriminate H. Qed.

Lemma reff146_not4158 : ~ @Equation4158 Fin3 reff146_inst.
Proof. unfold Equation4158. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff146_inst, reff146_op in H. discriminate H. Qed.

Lemma reff146_not4164 : ~ @Equation4164 Fin3 reff146_inst.
Proof. unfold Equation4164. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff146_inst, reff146_op in H. discriminate H. Qed.

Lemma reff146_not4165 : ~ @Equation4165 Fin3 reff146_inst.
Proof. unfold Equation4165. intro H. specialize (H F3_1 F3_0). unfold magma_op, reff146_inst, reff146_op in H. discriminate H. Qed.

Lemma reff146_not4167 : ~ @Equation4167 Fin3 reff146_inst.
Proof. unfold Equation4167. intro H. specialize (H F3_1 F3_0). unfold magma_op, reff146_inst, reff146_op in H. discriminate H. Qed.

Lemma reff146_not4268 : ~ @Equation4268 Fin3 reff146_inst.
Proof. unfold Equation4268. intro H. specialize (H F3_1 F3_2). unfold magma_op, reff146_inst, reff146_op in H. discriminate H. Qed.

Lemma reff146_not4269 : ~ @Equation4269 Fin3 reff146_inst.
Proof. unfold Equation4269. intro H. specialize (H F3_1 F3_0). unfold magma_op, reff146_inst, reff146_op in H. discriminate H. Qed.

Lemma reff146_not4272 : ~ @Equation4272 Fin3 reff146_inst.
Proof. unfold Equation4272. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff146_inst, reff146_op in H. discriminate H. Qed.

Lemma reff146_not4273 : ~ @Equation4273 Fin3 reff146_inst.
Proof. unfold Equation4273. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff146_inst, reff146_op in H. discriminate H. Qed.

Lemma reff146_not4275 : ~ @Equation4275 Fin3 reff146_inst.
Proof. unfold Equation4275. intro H. specialize (H F3_1 F3_2). unfold magma_op, reff146_inst, reff146_op in H. discriminate H. Qed.

Lemma reff146_not4276 : ~ @Equation4276 Fin3 reff146_inst.
Proof. unfold Equation4276. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff146_inst, reff146_op in H. discriminate H. Qed.

Lemma reff146_not4283 : ~ @Equation4283 Fin3 reff146_inst.
Proof. unfold Equation4283. intro H. specialize (H F3_1 F3_0). unfold magma_op, reff146_inst, reff146_op in H. discriminate H. Qed.

Lemma reff146_not4284 : ~ @Equation4284 Fin3 reff146_inst.
Proof. unfold Equation4284. intro H. specialize (H F3_1 F3_2). unfold magma_op, reff146_inst, reff146_op in H. discriminate H. Qed.

Lemma reff146_not4290 : ~ @Equation4290 Fin3 reff146_inst.
Proof. unfold Equation4290. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff146_inst, reff146_op in H. discriminate H. Qed.

Lemma reff146_not4291 : ~ @Equation4291 Fin3 reff146_inst.
Proof. unfold Equation4291. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff146_inst, reff146_op in H. discriminate H. Qed.

Lemma reff146_not4314 : ~ @Equation4314 Fin3 reff146_inst.
Proof. unfold Equation4314. intro H. specialize (H F3_1 F3_0). unfold magma_op, reff146_inst, reff146_op in H. discriminate H. Qed.

Lemma reff146_not4320 : ~ @Equation4320 Fin3 reff146_inst.
Proof. unfold Equation4320. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff146_inst, reff146_op in H. discriminate H. Qed.

Lemma reff146_not4321 : ~ @Equation4321 Fin3 reff146_inst.
Proof. unfold Equation4321. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff146_inst, reff146_op in H. discriminate H. Qed.

Lemma reff146_not4343 : ~ @Equation4343 Fin3 reff146_inst.
Proof. unfold Equation4343. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff146_inst, reff146_op in H. discriminate H. Qed.

Lemma reff146_not4380 : ~ @Equation4380 Fin3 reff146_inst.
Proof. unfold Equation4380. intro H. specialize (H F3_1). unfold magma_op, reff146_inst, reff146_op in H. discriminate H. Qed.

Lemma reff146_not4583 : ~ @Equation4583 Fin3 reff146_inst.
Proof. unfold Equation4583. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff146_inst, reff146_op in H. discriminate H. Qed.

Lemma reff146_not4584 : ~ @Equation4584 Fin3 reff146_inst.
Proof. unfold Equation4584. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff146_inst, reff146_op in H. discriminate H. Qed.

Lemma reff146_not4585 : ~ @Equation4585 Fin3 reff146_inst.
Proof. unfold Equation4585. intro H. specialize (H F3_1 F3_0). unfold magma_op, reff146_inst, reff146_op in H. discriminate H. Qed.

Lemma reff146_not4587 : ~ @Equation4587 Fin3 reff146_inst.
Proof. unfold Equation4587. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff146_inst, reff146_op in H. discriminate H. Qed.

Lemma reff146_not4588 : ~ @Equation4588 Fin3 reff146_inst.
Proof. unfold Equation4588. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff146_inst, reff146_op in H. discriminate H. Qed.

Lemma reff146_not4591 : ~ @Equation4591 Fin3 reff146_inst.
Proof. unfold Equation4591. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff146_inst, reff146_op in H. discriminate H. Qed.

Lemma reff146_not4598 : ~ @Equation4598 Fin3 reff146_inst.
Proof. unfold Equation4598. intro H. specialize (H F3_1 F3_0). unfold magma_op, reff146_inst, reff146_op in H. discriminate H. Qed.

Lemma reff146_not4599 : ~ @Equation4599 Fin3 reff146_inst.
Proof. unfold Equation4599. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff146_inst, reff146_op in H. discriminate H. Qed.

Lemma reff146_not4605 : ~ @Equation4605 Fin3 reff146_inst.
Proof. unfold Equation4605. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff146_inst, reff146_op in H. discriminate H. Qed.

Lemma reff146_not4606 : ~ @Equation4606 Fin3 reff146_inst.
Proof. unfold Equation4606. intro H. specialize (H F3_1 F3_0). unfold magma_op, reff146_inst, reff146_op in H. discriminate H. Qed.

Lemma reff146_not4608 : ~ @Equation4608 Fin3 reff146_inst.
Proof. unfold Equation4608. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff146_inst, reff146_op in H. discriminate H. Qed.

Lemma reff146_not4629 : ~ @Equation4629 Fin3 reff146_inst.
Proof. unfold Equation4629. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff146_inst, reff146_op in H. discriminate H. Qed.

Lemma reff146_not4635 : ~ @Equation4635 Fin3 reff146_inst.
Proof. unfold Equation4635. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff146_inst, reff146_op in H. discriminate H. Qed.

Lemma reff146_not4658 : ~ @Equation4658 Fin3 reff146_inst.
Proof. unfold Equation4658. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff146_inst, reff146_op in H. discriminate H. Qed.

(** ---- reff150 (Fin4) ---- *)

Definition reff150_op (x y : Fin4) : Fin4 :=
  match x, y with
  | F4_0, F4_0 => F4_0 | F4_0, F4_1 => F4_3 | F4_0, F4_2 => F4_2 | F4_0, F4_3 => F4_1
  | F4_1, F4_0 => F4_2 | F4_1, F4_1 => F4_0 | F4_1, F4_2 => F4_2 | F4_1, F4_3 => F4_0
  | F4_2, F4_0 => F4_0 | F4_2, F4_1 => F4_1 | F4_2, F4_2 => F4_2 | F4_2, F4_3 => F4_3
  | F4_3, F4_0 => F4_2 | F4_3, F4_1 => F4_2 | F4_3, F4_2 => F4_2 | F4_3, F4_3 => F4_2
  end.

#[local] Instance reff150_inst : Magma Fin4 := {| magma_op := reff150_op |}.

Lemma reff150_sat211 : @Equation211 Fin4 reff150_inst.
Proof. unfold Equation211, magma_op, reff150_inst, reff150_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff150_sat221 : @Equation221 Fin4 reff150_inst.
Proof. unfold Equation221, magma_op, reff150_inst, reff150_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff150_sat1731 : @Equation1731 Fin4 reff150_inst.
Proof. unfold Equation1731, magma_op, reff150_inst, reff150_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff150_sat2277 : @Equation2277 Fin4 reff150_inst.
Proof. unfold Equation2277, magma_op, reff150_inst, reff150_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff150_sat2281 : @Equation2281 Fin4 reff150_inst.
Proof. unfold Equation2281, magma_op, reff150_inst, reff150_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff150_sat2314 : @Equation2314 Fin4 reff150_inst.
Proof. unfold Equation2314, magma_op, reff150_inst, reff150_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff150_sat2318 : @Equation2318 Fin4 reff150_inst.
Proof. unfold Equation2318, magma_op, reff150_inst, reff150_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff150_sat2368 : @Equation2368 Fin4 reff150_inst.
Proof. unfold Equation2368, magma_op, reff150_inst, reff150_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff150_sat2372 : @Equation2372 Fin4 reff150_inst.
Proof. unfold Equation2372, magma_op, reff150_inst, reff150_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff150_sat3050 : @Equation3050 Fin4 reff150_inst.
Proof. unfold Equation3050, magma_op, reff150_inst, reff150_op. intros x. destruct x; reflexivity. Qed.

Lemma reff150_sat3464 : @Equation3464 Fin4 reff150_inst.
Proof. unfold Equation3464, magma_op, reff150_inst, reff150_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff150_sat3519 : @Equation3519 Fin4 reff150_inst.
Proof. unfold Equation3519, magma_op, reff150_inst, reff150_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff150_sat3684 : @Equation3684 Fin4 reff150_inst.
Proof. unfold Equation3684, magma_op, reff150_inst, reff150_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff150_sat3749 : @Equation3749 Fin4 reff150_inst.
Proof. unfold Equation3749, magma_op, reff150_inst, reff150_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff150_sat4362 : @Equation4362 Fin4 reff150_inst.
Proof. unfold Equation4362, magma_op, reff150_inst, reff150_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff150_not47 : ~ @Equation47 Fin4 reff150_inst.
Proof. unfold Equation47. intro H. specialize (H F4_1). unfold magma_op, reff150_inst, reff150_op in H. discriminate H. Qed.

Lemma reff150_not99 : ~ @Equation99 Fin4 reff150_inst.
Proof. unfold Equation99. intro H. specialize (H F4_1). unfold magma_op, reff150_inst, reff150_op in H. discriminate H. Qed.

Lemma reff150_not151 : ~ @Equation151 Fin4 reff150_inst.
Proof. unfold Equation151. intro H. specialize (H F4_1). unfold magma_op, reff150_inst, reff150_op in H. discriminate H. Qed.

Lemma reff150_not206 : ~ @Equation206 Fin4 reff150_inst.
Proof. unfold Equation206. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff150_inst, reff150_op in H. discriminate H. Qed.

Lemma reff150_not209 : ~ @Equation209 Fin4 reff150_inst.
Proof. unfold Equation209. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff150_inst, reff150_op in H. discriminate H. Qed.

Lemma reff150_not212 : ~ @Equation212 Fin4 reff150_inst.
Proof. unfold Equation212. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff150_inst, reff150_op in H. discriminate H. Qed.

Lemma reff150_not219 : ~ @Equation219 Fin4 reff150_inst.
Proof. unfold Equation219. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff150_inst, reff150_op in H. discriminate H. Qed.

Lemma reff150_not222 : ~ @Equation222 Fin4 reff150_inst.
Proof. unfold Equation222. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff150_inst, reff150_op in H. discriminate H. Qed.

Lemma reff150_not228 : ~ @Equation228 Fin4 reff150_inst.
Proof. unfold Equation228. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff150_inst, reff150_op in H. discriminate H. Qed.

Lemma reff150_not229 : ~ @Equation229 Fin4 reff150_inst.
Proof. unfold Equation229. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff150_inst, reff150_op in H. discriminate H. Qed.

Lemma reff150_not231 : ~ @Equation231 Fin4 reff150_inst.
Proof. unfold Equation231. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff150_inst, reff150_op in H. discriminate H. Qed.

Lemma reff150_not255 : ~ @Equation255 Fin4 reff150_inst.
Proof. unfold Equation255. intro H. specialize (H F4_1). unfold magma_op, reff150_inst, reff150_op in H. discriminate H. Qed.

Lemma reff150_not411 : ~ @Equation411 Fin4 reff150_inst.
Proof. unfold Equation411. intro H. specialize (H F4_1). unfold magma_op, reff150_inst, reff150_op in H. discriminate H. Qed.

Lemma reff150_not614 : ~ @Equation614 Fin4 reff150_inst.
Proof. unfold Equation614. intro H. specialize (H F4_1). unfold magma_op, reff150_inst, reff150_op in H. discriminate H. Qed.

Lemma reff150_not817 : ~ @Equation817 Fin4 reff150_inst.
Proof. unfold Equation817. intro H. specialize (H F4_1). unfold magma_op, reff150_inst, reff150_op in H. discriminate H. Qed.

Lemma reff150_not1020 : ~ @Equation1020 Fin4 reff150_inst.
Proof. unfold Equation1020. intro H. specialize (H F4_1). unfold magma_op, reff150_inst, reff150_op in H. discriminate H. Qed.

Lemma reff150_not1223 : ~ @Equation1223 Fin4 reff150_inst.
Proof. unfold Equation1223. intro H. specialize (H F4_1). unfold magma_op, reff150_inst, reff150_op in H. discriminate H. Qed.

Lemma reff150_not1426 : ~ @Equation1426 Fin4 reff150_inst.
Proof. unfold Equation1426. intro H. specialize (H F4_1). unfold magma_op, reff150_inst, reff150_op in H. discriminate H. Qed.

Lemma reff150_not1630 : ~ @Equation1630 Fin4 reff150_inst.
Proof. unfold Equation1630. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff150_inst, reff150_op in H. discriminate H. Qed.

Lemma reff150_not1631 : ~ @Equation1631 Fin4 reff150_inst.
Proof. unfold Equation1631. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff150_inst, reff150_op in H. discriminate H. Qed.

Lemma reff150_not1632 : ~ @Equation1632 Fin4 reff150_inst.
Proof. unfold Equation1632. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff150_inst, reff150_op in H. discriminate H. Qed.

Lemma reff150_not1634 : ~ @Equation1634 Fin4 reff150_inst.
Proof. unfold Equation1634. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff150_inst, reff150_op in H. discriminate H. Qed.

Lemma reff150_not1635 : ~ @Equation1635 Fin4 reff150_inst.
Proof. unfold Equation1635. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff150_inst, reff150_op in H. discriminate H. Qed.

Lemma reff150_not1637 : ~ @Equation1637 Fin4 reff150_inst.
Proof. unfold Equation1637. intro H. specialize (H F4_1 F4_2). unfold magma_op, reff150_inst, reff150_op in H. discriminate H. Qed.

Lemma reff150_not1638 : ~ @Equation1638 Fin4 reff150_inst.
Proof. unfold Equation1638. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff150_inst, reff150_op in H. discriminate H. Qed.

Lemma reff150_not1644 : ~ @Equation1644 Fin4 reff150_inst.
Proof. unfold Equation1644. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff150_inst, reff150_op in H. discriminate H. Qed.

Lemma reff150_not1645 : ~ @Equation1645 Fin4 reff150_inst.
Proof. unfold Equation1645. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff150_inst, reff150_op in H. discriminate H. Qed.

Lemma reff150_not1647 : ~ @Equation1647 Fin4 reff150_inst.
Proof. unfold Equation1647. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff150_inst, reff150_op in H. discriminate H. Qed.

Lemma reff150_not1648 : ~ @Equation1648 Fin4 reff150_inst.
Proof. unfold Equation1648. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff150_inst, reff150_op in H. discriminate H. Qed.

Lemma reff150_not1654 : ~ @Equation1654 Fin4 reff150_inst.
Proof. unfold Equation1654. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff150_inst, reff150_op in H. discriminate H. Qed.

Lemma reff150_not1655 : ~ @Equation1655 Fin4 reff150_inst.
Proof. unfold Equation1655. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff150_inst, reff150_op in H. discriminate H. Qed.

Lemma reff150_not1657 : ~ @Equation1657 Fin4 reff150_inst.
Proof. unfold Equation1657. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff150_inst, reff150_op in H. discriminate H. Qed.

Lemma reff150_not1658 : ~ @Equation1658 Fin4 reff150_inst.
Proof. unfold Equation1658. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff150_inst, reff150_op in H. discriminate H. Qed.

Lemma reff150_not1681 : ~ @Equation1681 Fin4 reff150_inst.
Proof. unfold Equation1681. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff150_inst, reff150_op in H. discriminate H. Qed.

Lemma reff150_not1682 : ~ @Equation1682 Fin4 reff150_inst.
Proof. unfold Equation1682. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff150_inst, reff150_op in H. discriminate H. Qed.

Lemma reff150_not1684 : ~ @Equation1684 Fin4 reff150_inst.
Proof. unfold Equation1684. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff150_inst, reff150_op in H. discriminate H. Qed.

Lemma reff150_not1685 : ~ @Equation1685 Fin4 reff150_inst.
Proof. unfold Equation1685. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff150_inst, reff150_op in H. discriminate H. Qed.

Lemma reff150_not1691 : ~ @Equation1691 Fin4 reff150_inst.
Proof. unfold Equation1691. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff150_inst, reff150_op in H. discriminate H. Qed.

Lemma reff150_not1692 : ~ @Equation1692 Fin4 reff150_inst.
Proof. unfold Equation1692. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff150_inst, reff150_op in H. discriminate H. Qed.

Lemma reff150_not1694 : ~ @Equation1694 Fin4 reff150_inst.
Proof. unfold Equation1694. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff150_inst, reff150_op in H. discriminate H. Qed.

Lemma reff150_not1695 : ~ @Equation1695 Fin4 reff150_inst.
Proof. unfold Equation1695. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff150_inst, reff150_op in H. discriminate H. Qed.

Lemma reff150_not1718 : ~ @Equation1718 Fin4 reff150_inst.
Proof. unfold Equation1718. intro H. specialize (H F4_1 F4_2). unfold magma_op, reff150_inst, reff150_op in H. discriminate H. Qed.

Lemma reff150_not1719 : ~ @Equation1719 Fin4 reff150_inst.
Proof. unfold Equation1719. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff150_inst, reff150_op in H. discriminate H. Qed.

Lemma reff150_not1721 : ~ @Equation1721 Fin4 reff150_inst.
Proof. unfold Equation1721. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff150_inst, reff150_op in H. discriminate H. Qed.

Lemma reff150_not1722 : ~ @Equation1722 Fin4 reff150_inst.
Proof. unfold Equation1722. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff150_inst, reff150_op in H. discriminate H. Qed.

Lemma reff150_not1728 : ~ @Equation1728 Fin4 reff150_inst.
Proof. unfold Equation1728. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff150_inst, reff150_op in H. discriminate H. Qed.

Lemma reff150_not1729 : ~ @Equation1729 Fin4 reff150_inst.
Proof. unfold Equation1729. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff150_inst, reff150_op in H. discriminate H. Qed.

Lemma reff150_not1832 : ~ @Equation1832 Fin4 reff150_inst.
Proof. unfold Equation1832. intro H. specialize (H F4_1). unfold magma_op, reff150_inst, reff150_op in H. discriminate H. Qed.

Lemma reff150_not2035 : ~ @Equation2035 Fin4 reff150_inst.
Proof. unfold Equation2035. intro H. specialize (H F4_1). unfold magma_op, reff150_inst, reff150_op in H. discriminate H. Qed.

Lemma reff150_not2239 : ~ @Equation2239 Fin4 reff150_inst.
Proof. unfold Equation2239. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff150_inst, reff150_op in H. discriminate H. Qed.

Lemma reff150_not2240 : ~ @Equation2240 Fin4 reff150_inst.
Proof. unfold Equation2240. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff150_inst, reff150_op in H. discriminate H. Qed.

Lemma reff150_not2241 : ~ @Equation2241 Fin4 reff150_inst.
Proof. unfold Equation2241. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff150_inst, reff150_op in H. discriminate H. Qed.

Lemma reff150_not2244 : ~ @Equation2244 Fin4 reff150_inst.
Proof. unfold Equation2244. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff150_inst, reff150_op in H. discriminate H. Qed.

Lemma reff150_not2247 : ~ @Equation2247 Fin4 reff150_inst.
Proof. unfold Equation2247. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff150_inst, reff150_op in H. discriminate H. Qed.

Lemma reff150_not2254 : ~ @Equation2254 Fin4 reff150_inst.
Proof. unfold Equation2254. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff150_inst, reff150_op in H. discriminate H. Qed.

Lemma reff150_not2257 : ~ @Equation2257 Fin4 reff150_inst.
Proof. unfold Equation2257. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff150_inst, reff150_op in H. discriminate H. Qed.

Lemma reff150_not2263 : ~ @Equation2263 Fin4 reff150_inst.
Proof. unfold Equation2263. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff150_inst, reff150_op in H. discriminate H. Qed.

Lemma reff150_not2264 : ~ @Equation2264 Fin4 reff150_inst.
Proof. unfold Equation2264. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff150_inst, reff150_op in H. discriminate H. Qed.

Lemma reff150_not2267 : ~ @Equation2267 Fin4 reff150_inst.
Proof. unfold Equation2267. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff150_inst, reff150_op in H. discriminate H. Qed.

Lemma reff150_not2291 : ~ @Equation2291 Fin4 reff150_inst.
Proof. unfold Equation2291. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff150_inst, reff150_op in H. discriminate H. Qed.

Lemma reff150_not2294 : ~ @Equation2294 Fin4 reff150_inst.
Proof. unfold Equation2294. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff150_inst, reff150_op in H. discriminate H. Qed.

Lemma reff150_not2300 : ~ @Equation2300 Fin4 reff150_inst.
Proof. unfold Equation2300. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff150_inst, reff150_op in H. discriminate H. Qed.

Lemma reff150_not2301 : ~ @Equation2301 Fin4 reff150_inst.
Proof. unfold Equation2301. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff150_inst, reff150_op in H. discriminate H. Qed.

Lemma reff150_not2304 : ~ @Equation2304 Fin4 reff150_inst.
Proof. unfold Equation2304. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff150_inst, reff150_op in H. discriminate H. Qed.

Lemma reff150_not2327 : ~ @Equation2327 Fin4 reff150_inst.
Proof. unfold Equation2327. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff150_inst, reff150_op in H. discriminate H. Qed.

Lemma reff150_not2328 : ~ @Equation2328 Fin4 reff150_inst.
Proof. unfold Equation2328. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff150_inst, reff150_op in H. discriminate H. Qed.

Lemma reff150_not2331 : ~ @Equation2331 Fin4 reff150_inst.
Proof. unfold Equation2331. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff150_inst, reff150_op in H. discriminate H. Qed.

Lemma reff150_not2337 : ~ @Equation2337 Fin4 reff150_inst.
Proof. unfold Equation2337. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff150_inst, reff150_op in H. discriminate H. Qed.

Lemma reff150_not2338 : ~ @Equation2338 Fin4 reff150_inst.
Proof. unfold Equation2338. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff150_inst, reff150_op in H. discriminate H. Qed.

Lemma reff150_not2340 : ~ @Equation2340 Fin4 reff150_inst.
Proof. unfold Equation2340. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff150_inst, reff150_op in H. discriminate H. Qed.

Lemma reff150_not2441 : ~ @Equation2441 Fin4 reff150_inst.
Proof. unfold Equation2441. intro H. specialize (H F4_1). unfold magma_op, reff150_inst, reff150_op in H. discriminate H. Qed.

Lemma reff150_not2644 : ~ @Equation2644 Fin4 reff150_inst.
Proof. unfold Equation2644. intro H. specialize (H F4_1). unfold magma_op, reff150_inst, reff150_op in H. discriminate H. Qed.

Lemma reff150_not2847 : ~ @Equation2847 Fin4 reff150_inst.
Proof. unfold Equation2847. intro H. specialize (H F4_1). unfold magma_op, reff150_inst, reff150_op in H. discriminate H. Qed.

Lemma reff150_not3051 : ~ @Equation3051 Fin4 reff150_inst.
Proof. unfold Equation3051. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff150_inst, reff150_op in H. discriminate H. Qed.

Lemma reff150_not3052 : ~ @Equation3052 Fin4 reff150_inst.
Proof. unfold Equation3052. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff150_inst, reff150_op in H. discriminate H. Qed.

Lemma reff150_not3053 : ~ @Equation3053 Fin4 reff150_inst.
Proof. unfold Equation3053. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff150_inst, reff150_op in H. discriminate H. Qed.

Lemma reff150_not3055 : ~ @Equation3055 Fin4 reff150_inst.
Proof. unfold Equation3055. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff150_inst, reff150_op in H. discriminate H. Qed.

Lemma reff150_not3056 : ~ @Equation3056 Fin4 reff150_inst.
Proof. unfold Equation3056. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff150_inst, reff150_op in H. discriminate H. Qed.

Lemma reff150_not3058 : ~ @Equation3058 Fin4 reff150_inst.
Proof. unfold Equation3058. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff150_inst, reff150_op in H. discriminate H. Qed.

Lemma reff150_not3059 : ~ @Equation3059 Fin4 reff150_inst.
Proof. unfold Equation3059. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff150_inst, reff150_op in H. discriminate H. Qed.

Lemma reff150_not3065 : ~ @Equation3065 Fin4 reff150_inst.
Proof. unfold Equation3065. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff150_inst, reff150_op in H. discriminate H. Qed.

Lemma reff150_not3066 : ~ @Equation3066 Fin4 reff150_inst.
Proof. unfold Equation3066. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff150_inst, reff150_op in H. discriminate H. Qed.

Lemma reff150_not3068 : ~ @Equation3068 Fin4 reff150_inst.
Proof. unfold Equation3068. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff150_inst, reff150_op in H. discriminate H. Qed.

Lemma reff150_not3069 : ~ @Equation3069 Fin4 reff150_inst.
Proof. unfold Equation3069. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff150_inst, reff150_op in H. discriminate H. Qed.

Lemma reff150_not3075 : ~ @Equation3075 Fin4 reff150_inst.
Proof. unfold Equation3075. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff150_inst, reff150_op in H. discriminate H. Qed.

Lemma reff150_not3076 : ~ @Equation3076 Fin4 reff150_inst.
Proof. unfold Equation3076. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff150_inst, reff150_op in H. discriminate H. Qed.

Lemma reff150_not3078 : ~ @Equation3078 Fin4 reff150_inst.
Proof. unfold Equation3078. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff150_inst, reff150_op in H. discriminate H. Qed.

Lemma reff150_not3079 : ~ @Equation3079 Fin4 reff150_inst.
Proof. unfold Equation3079. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff150_inst, reff150_op in H. discriminate H. Qed.

Lemma reff150_not3102 : ~ @Equation3102 Fin4 reff150_inst.
Proof. unfold Equation3102. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff150_inst, reff150_op in H. discriminate H. Qed.

Lemma reff150_not3103 : ~ @Equation3103 Fin4 reff150_inst.
Proof. unfold Equation3103. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff150_inst, reff150_op in H. discriminate H. Qed.

Lemma reff150_not3105 : ~ @Equation3105 Fin4 reff150_inst.
Proof. unfold Equation3105. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff150_inst, reff150_op in H. discriminate H. Qed.

Lemma reff150_not3106 : ~ @Equation3106 Fin4 reff150_inst.
Proof. unfold Equation3106. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff150_inst, reff150_op in H. discriminate H. Qed.

Lemma reff150_not3112 : ~ @Equation3112 Fin4 reff150_inst.
Proof. unfold Equation3112. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff150_inst, reff150_op in H. discriminate H. Qed.

Lemma reff150_not3113 : ~ @Equation3113 Fin4 reff150_inst.
Proof. unfold Equation3113. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff150_inst, reff150_op in H. discriminate H. Qed.

Lemma reff150_not3115 : ~ @Equation3115 Fin4 reff150_inst.
Proof. unfold Equation3115. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff150_inst, reff150_op in H. discriminate H. Qed.

Lemma reff150_not3116 : ~ @Equation3116 Fin4 reff150_inst.
Proof. unfold Equation3116. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff150_inst, reff150_op in H. discriminate H. Qed.

Lemma reff150_not3139 : ~ @Equation3139 Fin4 reff150_inst.
Proof. unfold Equation3139. intro H. specialize (H F4_1 F4_2). unfold magma_op, reff150_inst, reff150_op in H. discriminate H. Qed.

Lemma reff150_not3140 : ~ @Equation3140 Fin4 reff150_inst.
Proof. unfold Equation3140. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff150_inst, reff150_op in H. discriminate H. Qed.

Lemma reff150_not3142 : ~ @Equation3142 Fin4 reff150_inst.
Proof. unfold Equation3142. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff150_inst, reff150_op in H. discriminate H. Qed.

Lemma reff150_not3143 : ~ @Equation3143 Fin4 reff150_inst.
Proof. unfold Equation3143. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff150_inst, reff150_op in H. discriminate H. Qed.

Lemma reff150_not3149 : ~ @Equation3149 Fin4 reff150_inst.
Proof. unfold Equation3149. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff150_inst, reff150_op in H. discriminate H. Qed.

Lemma reff150_not3150 : ~ @Equation3150 Fin4 reff150_inst.
Proof. unfold Equation3150. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff150_inst, reff150_op in H. discriminate H. Qed.

Lemma reff150_not3152 : ~ @Equation3152 Fin4 reff150_inst.
Proof. unfold Equation3152. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff150_inst, reff150_op in H. discriminate H. Qed.

Lemma reff150_not3253 : ~ @Equation3253 Fin4 reff150_inst.
Proof. unfold Equation3253. intro H. specialize (H F4_1). unfold magma_op, reff150_inst, reff150_op in H. discriminate H. Qed.

Lemma reff150_not3457 : ~ @Equation3457 Fin4 reff150_inst.
Proof. unfold Equation3457. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff150_inst, reff150_op in H. discriminate H. Qed.

Lemma reff150_not3458 : ~ @Equation3458 Fin4 reff150_inst.
Proof. unfold Equation3458. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff150_inst, reff150_op in H. discriminate H. Qed.

Lemma reff150_not3459 : ~ @Equation3459 Fin4 reff150_inst.
Proof. unfold Equation3459. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff150_inst, reff150_op in H. discriminate H. Qed.

Lemma reff150_not3461 : ~ @Equation3461 Fin4 reff150_inst.
Proof. unfold Equation3461. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff150_inst, reff150_op in H. discriminate H. Qed.

Lemma reff150_not3462 : ~ @Equation3462 Fin4 reff150_inst.
Proof. unfold Equation3462. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff150_inst, reff150_op in H. discriminate H. Qed.

Lemma reff150_not3465 : ~ @Equation3465 Fin4 reff150_inst.
Proof. unfold Equation3465. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff150_inst, reff150_op in H. discriminate H. Qed.

Lemma reff150_not3472 : ~ @Equation3472 Fin4 reff150_inst.
Proof. unfold Equation3472. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff150_inst, reff150_op in H. discriminate H. Qed.

Lemma reff150_not3474 : ~ @Equation3474 Fin4 reff150_inst.
Proof. unfold Equation3474. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff150_inst, reff150_op in H. discriminate H. Qed.

Lemma reff150_not3475 : ~ @Equation3475 Fin4 reff150_inst.
Proof. unfold Equation3475. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff150_inst, reff150_op in H. discriminate H. Qed.

Lemma reff150_not3481 : ~ @Equation3481 Fin4 reff150_inst.
Proof. unfold Equation3481. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff150_inst, reff150_op in H. discriminate H. Qed.

Lemma reff150_not3482 : ~ @Equation3482 Fin4 reff150_inst.
Proof. unfold Equation3482. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff150_inst, reff150_op in H. discriminate H. Qed.

Lemma reff150_not3484 : ~ @Equation3484 Fin4 reff150_inst.
Proof. unfold Equation3484. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff150_inst, reff150_op in H. discriminate H. Qed.

Lemma reff150_not3509 : ~ @Equation3509 Fin4 reff150_inst.
Proof. unfold Equation3509. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff150_inst, reff150_op in H. discriminate H. Qed.

Lemma reff150_not3511 : ~ @Equation3511 Fin4 reff150_inst.
Proof. unfold Equation3511. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff150_inst, reff150_op in H. discriminate H. Qed.

Lemma reff150_not3512 : ~ @Equation3512 Fin4 reff150_inst.
Proof. unfold Equation3512. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff150_inst, reff150_op in H. discriminate H. Qed.

Lemma reff150_not3518 : ~ @Equation3518 Fin4 reff150_inst.
Proof. unfold Equation3518. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff150_inst, reff150_op in H. discriminate H. Qed.

Lemma reff150_not3521 : ~ @Equation3521 Fin4 reff150_inst.
Proof. unfold Equation3521. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff150_inst, reff150_op in H. discriminate H. Qed.

Lemma reff150_not3522 : ~ @Equation3522 Fin4 reff150_inst.
Proof. unfold Equation3522. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff150_inst, reff150_op in H. discriminate H. Qed.

Lemma reff150_not3545 : ~ @Equation3545 Fin4 reff150_inst.
Proof. unfold Equation3545. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff150_inst, reff150_op in H. discriminate H. Qed.

Lemma reff150_not3546 : ~ @Equation3546 Fin4 reff150_inst.
Proof. unfold Equation3546. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff150_inst, reff150_op in H. discriminate H. Qed.

Lemma reff150_not3548 : ~ @Equation3548 Fin4 reff150_inst.
Proof. unfold Equation3548. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff150_inst, reff150_op in H. discriminate H. Qed.

Lemma reff150_not3549 : ~ @Equation3549 Fin4 reff150_inst.
Proof. unfold Equation3549. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff150_inst, reff150_op in H. discriminate H. Qed.

Lemma reff150_not3555 : ~ @Equation3555 Fin4 reff150_inst.
Proof. unfold Equation3555. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff150_inst, reff150_op in H. discriminate H. Qed.

Lemma reff150_not3558 : ~ @Equation3558 Fin4 reff150_inst.
Proof. unfold Equation3558. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff150_inst, reff150_op in H. discriminate H. Qed.

Lemma reff150_not3660 : ~ @Equation3660 Fin4 reff150_inst.
Proof. unfold Equation3660. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff150_inst, reff150_op in H. discriminate H. Qed.

Lemma reff150_not3661 : ~ @Equation3661 Fin4 reff150_inst.
Proof. unfold Equation3661. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff150_inst, reff150_op in H. discriminate H. Qed.

Lemma reff150_not3662 : ~ @Equation3662 Fin4 reff150_inst.
Proof. unfold Equation3662. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff150_inst, reff150_op in H. discriminate H. Qed.

Lemma reff150_not3664 : ~ @Equation3664 Fin4 reff150_inst.
Proof. unfold Equation3664. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff150_inst, reff150_op in H. discriminate H. Qed.

Lemma reff150_not3665 : ~ @Equation3665 Fin4 reff150_inst.
Proof. unfold Equation3665. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff150_inst, reff150_op in H. discriminate H. Qed.

Lemma reff150_not3667 : ~ @Equation3667 Fin4 reff150_inst.
Proof. unfold Equation3667. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff150_inst, reff150_op in H. discriminate H. Qed.

Lemma reff150_not3668 : ~ @Equation3668 Fin4 reff150_inst.
Proof. unfold Equation3668. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff150_inst, reff150_op in H. discriminate H. Qed.

Lemma reff150_not3674 : ~ @Equation3674 Fin4 reff150_inst.
Proof. unfold Equation3674. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff150_inst, reff150_op in H. discriminate H. Qed.

Lemma reff150_not3675 : ~ @Equation3675 Fin4 reff150_inst.
Proof. unfold Equation3675. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff150_inst, reff150_op in H. discriminate H. Qed.

Lemma reff150_not3677 : ~ @Equation3677 Fin4 reff150_inst.
Proof. unfold Equation3677. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff150_inst, reff150_op in H. discriminate H. Qed.

Lemma reff150_not3678 : ~ @Equation3678 Fin4 reff150_inst.
Proof. unfold Equation3678. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff150_inst, reff150_op in H. discriminate H. Qed.

Lemma reff150_not3685 : ~ @Equation3685 Fin4 reff150_inst.
Proof. unfold Equation3685. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff150_inst, reff150_op in H. discriminate H. Qed.

Lemma reff150_not3687 : ~ @Equation3687 Fin4 reff150_inst.
Proof. unfold Equation3687. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff150_inst, reff150_op in H. discriminate H. Qed.

Lemma reff150_not3712 : ~ @Equation3712 Fin4 reff150_inst.
Proof. unfold Equation3712. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff150_inst, reff150_op in H. discriminate H. Qed.

Lemma reff150_not3714 : ~ @Equation3714 Fin4 reff150_inst.
Proof. unfold Equation3714. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff150_inst, reff150_op in H. discriminate H. Qed.

Lemma reff150_not3721 : ~ @Equation3721 Fin4 reff150_inst.
Proof. unfold Equation3721. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff150_inst, reff150_op in H. discriminate H. Qed.

Lemma reff150_not3722 : ~ @Equation3722 Fin4 reff150_inst.
Proof. unfold Equation3722. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff150_inst, reff150_op in H. discriminate H. Qed.

Lemma reff150_not3724 : ~ @Equation3724 Fin4 reff150_inst.
Proof. unfold Equation3724. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff150_inst, reff150_op in H. discriminate H. Qed.

Lemma reff150_not3725 : ~ @Equation3725 Fin4 reff150_inst.
Proof. unfold Equation3725. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff150_inst, reff150_op in H. discriminate H. Qed.

Lemma reff150_not3748 : ~ @Equation3748 Fin4 reff150_inst.
Proof. unfold Equation3748. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff150_inst, reff150_op in H. discriminate H. Qed.

Lemma reff150_not3751 : ~ @Equation3751 Fin4 reff150_inst.
Proof. unfold Equation3751. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff150_inst, reff150_op in H. discriminate H. Qed.

Lemma reff150_not3752 : ~ @Equation3752 Fin4 reff150_inst.
Proof. unfold Equation3752. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff150_inst, reff150_op in H. discriminate H. Qed.

Lemma reff150_not3759 : ~ @Equation3759 Fin4 reff150_inst.
Proof. unfold Equation3759. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff150_inst, reff150_op in H. discriminate H. Qed.

Lemma reff150_not3761 : ~ @Equation3761 Fin4 reff150_inst.
Proof. unfold Equation3761. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff150_inst, reff150_op in H. discriminate H. Qed.

Lemma reff150_not3862 : ~ @Equation3862 Fin4 reff150_inst.
Proof. unfold Equation3862. intro H. specialize (H F4_1). unfold magma_op, reff150_inst, reff150_op in H. discriminate H. Qed.

Lemma reff150_not4065 : ~ @Equation4065 Fin4 reff150_inst.
Proof. unfold Equation4065. intro H. specialize (H F4_1). unfold magma_op, reff150_inst, reff150_op in H. discriminate H. Qed.

Lemma reff150_not4268 : ~ @Equation4268 Fin4 reff150_inst.
Proof. unfold Equation4268. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff150_inst, reff150_op in H. discriminate H. Qed.

Lemma reff150_not4269 : ~ @Equation4269 Fin4 reff150_inst.
Proof. unfold Equation4269. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff150_inst, reff150_op in H. discriminate H. Qed.

Lemma reff150_not4270 : ~ @Equation4270 Fin4 reff150_inst.
Proof. unfold Equation4270. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff150_inst, reff150_op in H. discriminate H. Qed.

Lemma reff150_not4272 : ~ @Equation4272 Fin4 reff150_inst.
Proof. unfold Equation4272. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff150_inst, reff150_op in H. discriminate H. Qed.

Lemma reff150_not4273 : ~ @Equation4273 Fin4 reff150_inst.
Proof. unfold Equation4273. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff150_inst, reff150_op in H. discriminate H. Qed.

Lemma reff150_not4275 : ~ @Equation4275 Fin4 reff150_inst.
Proof. unfold Equation4275. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff150_inst, reff150_op in H. discriminate H. Qed.

Lemma reff150_not4276 : ~ @Equation4276 Fin4 reff150_inst.
Proof. unfold Equation4276. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff150_inst, reff150_op in H. discriminate H. Qed.

Lemma reff150_not4283 : ~ @Equation4283 Fin4 reff150_inst.
Proof. unfold Equation4283. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff150_inst, reff150_op in H. discriminate H. Qed.

Lemma reff150_not4284 : ~ @Equation4284 Fin4 reff150_inst.
Proof. unfold Equation4284. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff150_inst, reff150_op in H. discriminate H. Qed.

Lemma reff150_not4290 : ~ @Equation4290 Fin4 reff150_inst.
Proof. unfold Equation4290. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff150_inst, reff150_op in H. discriminate H. Qed.

Lemma reff150_not4291 : ~ @Equation4291 Fin4 reff150_inst.
Proof. unfold Equation4291. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff150_inst, reff150_op in H. discriminate H. Qed.

Lemma reff150_not4293 : ~ @Equation4293 Fin4 reff150_inst.
Proof. unfold Equation4293. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff150_inst, reff150_op in H. discriminate H. Qed.

Lemma reff150_not4314 : ~ @Equation4314 Fin4 reff150_inst.
Proof. unfold Equation4314. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff150_inst, reff150_op in H. discriminate H. Qed.

Lemma reff150_not4321 : ~ @Equation4321 Fin4 reff150_inst.
Proof. unfold Equation4321. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff150_inst, reff150_op in H. discriminate H. Qed.

Lemma reff150_not4343 : ~ @Equation4343 Fin4 reff150_inst.
Proof. unfold Equation4343. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff150_inst, reff150_op in H. discriminate H. Qed.

Lemma reff150_not4380 : ~ @Equation4380 Fin4 reff150_inst.
Proof. unfold Equation4380. intro H. specialize (H F4_1). unfold magma_op, reff150_inst, reff150_op in H. discriminate H. Qed.

Lemma reff150_not4583 : ~ @Equation4583 Fin4 reff150_inst.
Proof. unfold Equation4583. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff150_inst, reff150_op in H. discriminate H. Qed.

Lemma reff150_not4584 : ~ @Equation4584 Fin4 reff150_inst.
Proof. unfold Equation4584. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff150_inst, reff150_op in H. discriminate H. Qed.

Lemma reff150_not4585 : ~ @Equation4585 Fin4 reff150_inst.
Proof. unfold Equation4585. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff150_inst, reff150_op in H. discriminate H. Qed.

Lemma reff150_not4587 : ~ @Equation4587 Fin4 reff150_inst.
Proof. unfold Equation4587. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff150_inst, reff150_op in H. discriminate H. Qed.

Lemma reff150_not4588 : ~ @Equation4588 Fin4 reff150_inst.
Proof. unfold Equation4588. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff150_inst, reff150_op in H. discriminate H. Qed.

Lemma reff150_not4590 : ~ @Equation4590 Fin4 reff150_inst.
Proof. unfold Equation4590. intro H. specialize (H F4_1 F4_2). unfold magma_op, reff150_inst, reff150_op in H. discriminate H. Qed.

Lemma reff150_not4591 : ~ @Equation4591 Fin4 reff150_inst.
Proof. unfold Equation4591. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff150_inst, reff150_op in H. discriminate H. Qed.

Lemma reff150_not4598 : ~ @Equation4598 Fin4 reff150_inst.
Proof. unfold Equation4598. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff150_inst, reff150_op in H. discriminate H. Qed.

Lemma reff150_not4599 : ~ @Equation4599 Fin4 reff150_inst.
Proof. unfold Equation4599. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff150_inst, reff150_op in H. discriminate H. Qed.

Lemma reff150_not4605 : ~ @Equation4605 Fin4 reff150_inst.
Proof. unfold Equation4605. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff150_inst, reff150_op in H. discriminate H. Qed.

Lemma reff150_not4606 : ~ @Equation4606 Fin4 reff150_inst.
Proof. unfold Equation4606. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff150_inst, reff150_op in H. discriminate H. Qed.

Lemma reff150_not4608 : ~ @Equation4608 Fin4 reff150_inst.
Proof. unfold Equation4608. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff150_inst, reff150_op in H. discriminate H. Qed.

Lemma reff150_not4629 : ~ @Equation4629 Fin4 reff150_inst.
Proof. unfold Equation4629. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff150_inst, reff150_op in H. discriminate H. Qed.

Lemma reff150_not4635 : ~ @Equation4635 Fin4 reff150_inst.
Proof. unfold Equation4635. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff150_inst, reff150_op in H. discriminate H. Qed.

Lemma reff150_not4636 : ~ @Equation4636 Fin4 reff150_inst.
Proof. unfold Equation4636. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff150_inst, reff150_op in H. discriminate H. Qed.

Lemma reff150_not4658 : ~ @Equation4658 Fin4 reff150_inst.
Proof. unfold Equation4658. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff150_inst, reff150_op in H. discriminate H. Qed.

(** ---- reff152 (Fin3) ---- *)

Definition reff152_op (x y : Fin3) : Fin3 :=
  match x, y with
  | F3_0, F3_0 => F3_0 | F3_0, F3_1 => F3_2 | F3_0, F3_2 => F3_1
  | F3_1, F3_0 => F3_1 | F3_1, F3_1 => F3_0 | F3_1, F3_2 => F3_2
  | F3_2, F3_0 => F3_2 | F3_2, F3_1 => F3_1 | F3_2, F3_2 => F3_0
  end.

#[local] Instance reff152_inst : Magma Fin3 := {| magma_op := reff152_op |}.

Lemma reff152_sat11 : @Equation11 Fin3 reff152_inst.
Proof. unfold Equation11, magma_op, reff152_inst, reff152_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff152_sat16 : @Equation16 Fin3 reff152_inst.
Proof. unfold Equation16, magma_op, reff152_inst, reff152_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff152_sat264 : @Equation264 Fin3 reff152_inst.
Proof. unfold Equation264, magma_op, reff152_inst, reff152_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff152_sat271 : @Equation271 Fin3 reff152_inst.
Proof. unfold Equation271, magma_op, reff152_inst, reff152_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff152_sat273 : @Equation273 Fin3 reff152_inst.
Proof. unfold Equation273, magma_op, reff152_inst, reff152_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff152_sat280 : @Equation280 Fin3 reff152_inst.
Proof. unfold Equation280, magma_op, reff152_inst, reff152_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff152_sat455 : @Equation455 Fin3 reff152_inst.
Proof. unfold Equation455, magma_op, reff152_inst, reff152_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff152_sat474 : @Equation474 Fin3 reff152_inst.
Proof. unfold Equation474, magma_op, reff152_inst, reff152_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff152_sat508 : @Equation508 Fin3 reff152_inst.
Proof. unfold Equation508, magma_op, reff152_inst, reff152_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff152_sat543 : @Equation543 Fin3 reff152_inst.
Proof. unfold Equation543, magma_op, reff152_inst, reff152_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff152_sat882 : @Equation882 Fin3 reff152_inst.
Proof. unfold Equation882, magma_op, reff152_inst, reff152_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff152_sat914 : @Equation914 Fin3 reff152_inst.
Proof. unfold Equation914, magma_op, reff152_inst, reff152_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff152_sat928 : @Equation928 Fin3 reff152_inst.
Proof. unfold Equation928, magma_op, reff152_inst, reff152_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff152_sat952 : @Equation952 Fin3 reff152_inst.
Proof. unfold Equation952, magma_op, reff152_inst, reff152_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff152_sat978 : @Equation978 Fin3 reff152_inst.
Proof. unfold Equation978, magma_op, reff152_inst, reff152_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff152_sat1053 : @Equation1053 Fin3 reff152_inst.
Proof. unfold Equation1053, magma_op, reff152_inst, reff152_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff152_sat1083 : @Equation1083 Fin3 reff152_inst.
Proof. unfold Equation1083, magma_op, reff152_inst, reff152_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff152_sat1117 : @Equation1117 Fin3 reff152_inst.
Proof. unfold Equation1117, magma_op, reff152_inst, reff152_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff152_sat1137 : @Equation1137 Fin3 reff152_inst.
Proof. unfold Equation1137, magma_op, reff152_inst, reff152_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff152_sat1152 : @Equation1152 Fin3 reff152_inst.
Proof. unfold Equation1152, magma_op, reff152_inst, reff152_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff152_sat1670 : @Equation1670 Fin3 reff152_inst.
Proof. unfold Equation1670, magma_op, reff152_inst, reff152_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff152_sat1673 : @Equation1673 Fin3 reff152_inst.
Proof. unfold Equation1673, magma_op, reff152_inst, reff152_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff152_sat1685 : @Equation1685 Fin3 reff152_inst.
Proof. unfold Equation1685, magma_op, reff152_inst, reff152_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff152_sat1740 : @Equation1740 Fin3 reff152_inst.
Proof. unfold Equation1740, magma_op, reff152_inst, reff152_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff152_sat1746 : @Equation1746 Fin3 reff152_inst.
Proof. unfold Equation1746, magma_op, reff152_inst, reff152_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff152_sat1774 : @Equation1774 Fin3 reff152_inst.
Proof. unfold Equation1774, magma_op, reff152_inst, reff152_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff152_sat1876 : @Equation1876 Fin3 reff152_inst.
Proof. unfold Equation1876, magma_op, reff152_inst, reff152_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff152_sat1895 : @Equation1895 Fin3 reff152_inst.
Proof. unfold Equation1895, magma_op, reff152_inst, reff152_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff152_sat1929 : @Equation1929 Fin3 reff152_inst.
Proof. unfold Equation1929, magma_op, reff152_inst, reff152_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff152_sat1964 : @Equation1964 Fin3 reff152_inst.
Proof. unfold Equation1964, magma_op, reff152_inst, reff152_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff152_sat1996 : @Equation1996 Fin3 reff152_inst.
Proof. unfold Equation1996, magma_op, reff152_inst, reff152_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff152_sat2474 : @Equation2474 Fin3 reff152_inst.
Proof. unfold Equation2474, magma_op, reff152_inst, reff152_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff152_sat2482 : @Equation2482 Fin3 reff152_inst.
Proof. unfold Equation2482, magma_op, reff152_inst, reff152_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff152_sat2506 : @Equation2506 Fin3 reff152_inst.
Proof. unfold Equation2506, magma_op, reff152_inst, reff152_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff152_sat2538 : @Equation2538 Fin3 reff152_inst.
Proof. unfold Equation2538, magma_op, reff152_inst, reff152_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff152_sat2552 : @Equation2552 Fin3 reff152_inst.
Proof. unfold Equation2552, magma_op, reff152_inst, reff152_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff152_sat2576 : @Equation2576 Fin3 reff152_inst.
Proof. unfold Equation2576, magma_op, reff152_inst, reff152_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff152_sat2602 : @Equation2602 Fin3 reff152_inst.
Proof. unfold Equation2602, magma_op, reff152_inst, reff152_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff152_sat3297 : @Equation3297 Fin3 reff152_inst.
Proof. unfold Equation3297, magma_op, reff152_inst, reff152_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff152_sat3345 : @Equation3345 Fin3 reff152_inst.
Proof. unfold Equation3345, magma_op, reff152_inst, reff152_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff152_sat3398 : @Equation3398 Fin3 reff152_inst.
Proof. unfold Equation3398, magma_op, reff152_inst, reff152_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff152_sat3737 : @Equation3737 Fin3 reff152_inst.
Proof. unfold Equation3737, magma_op, reff152_inst, reff152_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff152_sat3749 : @Equation3749 Fin3 reff152_inst.
Proof. unfold Equation3749, magma_op, reff152_inst, reff152_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff152_sat3823 : @Equation3823 Fin3 reff152_inst.
Proof. unfold Equation3823, magma_op, reff152_inst, reff152_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff152_sat3895 : @Equation3895 Fin3 reff152_inst.
Proof. unfold Equation3895, magma_op, reff152_inst, reff152_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff152_sat3954 : @Equation3954 Fin3 reff152_inst.
Proof. unfold Equation3954, magma_op, reff152_inst, reff152_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff152_sat4007 : @Equation4007 Fin3 reff152_inst.
Proof. unfold Equation4007, magma_op, reff152_inst, reff152_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff152_sat4297 : @Equation4297 Fin3 reff152_inst.
Proof. unfold Equation4297, magma_op, reff152_inst, reff152_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff152_sat4321 : @Equation4321 Fin3 reff152_inst.
Proof. unfold Equation4321, magma_op, reff152_inst, reff152_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff152_sat4369 : @Equation4369 Fin3 reff152_inst.
Proof. unfold Equation4369, magma_op, reff152_inst, reff152_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff152_sat4620 : @Equation4620 Fin3 reff152_inst.
Proof. unfold Equation4620, magma_op, reff152_inst, reff152_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff152_sat4658 : @Equation4658 Fin3 reff152_inst.
Proof. unfold Equation4658, magma_op, reff152_inst, reff152_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff152_not47 : ~ @Equation47 Fin3 reff152_inst.
Proof. unfold Equation47. intro H. specialize (H F3_1). unfold magma_op, reff152_inst, reff152_op in H. discriminate H. Qed.

Lemma reff152_not99 : ~ @Equation99 Fin3 reff152_inst.
Proof. unfold Equation99. intro H. specialize (H F3_1). unfold magma_op, reff152_inst, reff152_op in H. discriminate H. Qed.

Lemma reff152_not151 : ~ @Equation151 Fin3 reff152_inst.
Proof. unfold Equation151. intro H. specialize (H F3_1). unfold magma_op, reff152_inst, reff152_op in H. discriminate H. Qed.

Lemma reff152_not203 : ~ @Equation203 Fin3 reff152_inst.
Proof. unfold Equation203. intro H. specialize (H F3_1). unfold magma_op, reff152_inst, reff152_op in H. discriminate H. Qed.

Lemma reff152_not258 : ~ @Equation258 Fin3 reff152_inst.
Proof. unfold Equation258. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff152_inst, reff152_op in H. discriminate H. Qed.

Lemma reff152_not261 : ~ @Equation261 Fin3 reff152_inst.
Proof. unfold Equation261. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff152_inst, reff152_op in H. discriminate H. Qed.

Lemma reff152_not263 : ~ @Equation263 Fin3 reff152_inst.
Proof. unfold Equation263. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff152_inst, reff152_op in H. discriminate H. Qed.

Lemma reff152_not274 : ~ @Equation274 Fin3 reff152_inst.
Proof. unfold Equation274. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff152_inst, reff152_op in H. discriminate H. Qed.

Lemma reff152_not281 : ~ @Equation281 Fin3 reff152_inst.
Proof. unfold Equation281. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff152_inst, reff152_op in H. discriminate H. Qed.

Lemma reff152_not283 : ~ @Equation283 Fin3 reff152_inst.
Proof. unfold Equation283. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff152_inst, reff152_op in H. discriminate H. Qed.

Lemma reff152_not307 : ~ @Equation307 Fin3 reff152_inst.
Proof. unfold Equation307. intro H. specialize (H F3_1). unfold magma_op, reff152_inst, reff152_op in H. discriminate H. Qed.

Lemma reff152_not412 : ~ @Equation412 Fin3 reff152_inst.
Proof. unfold Equation412. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff152_inst, reff152_op in H. discriminate H. Qed.

Lemma reff152_not413 : ~ @Equation413 Fin3 reff152_inst.
Proof. unfold Equation413. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff152_inst, reff152_op in H. discriminate H. Qed.

Lemma reff152_not416 : ~ @Equation416 Fin3 reff152_inst.
Proof. unfold Equation416. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff152_inst, reff152_op in H. discriminate H. Qed.

Lemma reff152_not417 : ~ @Equation417 Fin3 reff152_inst.
Proof. unfold Equation417. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff152_inst, reff152_op in H. discriminate H. Qed.

Lemma reff152_not420 : ~ @Equation420 Fin3 reff152_inst.
Proof. unfold Equation420. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff152_inst, reff152_op in H. discriminate H. Qed.

Lemma reff152_not426 : ~ @Equation426 Fin3 reff152_inst.
Proof. unfold Equation426. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff152_inst, reff152_op in H. discriminate H. Qed.

Lemma reff152_not429 : ~ @Equation429 Fin3 reff152_inst.
Proof. unfold Equation429. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff152_inst, reff152_op in H. discriminate H. Qed.

Lemma reff152_not430 : ~ @Equation430 Fin3 reff152_inst.
Proof. unfold Equation430. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff152_inst, reff152_op in H. discriminate H. Qed.

Lemma reff152_not437 : ~ @Equation437 Fin3 reff152_inst.
Proof. unfold Equation437. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff152_inst, reff152_op in H. discriminate H. Qed.

Lemma reff152_not439 : ~ @Equation439 Fin3 reff152_inst.
Proof. unfold Equation439. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff152_inst, reff152_op in H. discriminate H. Qed.

Lemma reff152_not463 : ~ @Equation463 Fin3 reff152_inst.
Proof. unfold Equation463. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff152_inst, reff152_op in H. discriminate H. Qed.

Lemma reff152_not464 : ~ @Equation464 Fin3 reff152_inst.
Proof. unfold Equation464. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff152_inst, reff152_op in H. discriminate H. Qed.

Lemma reff152_not467 : ~ @Equation467 Fin3 reff152_inst.
Proof. unfold Equation467. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff152_inst, reff152_op in H. discriminate H. Qed.

Lemma reff152_not473 : ~ @Equation473 Fin3 reff152_inst.
Proof. unfold Equation473. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff152_inst, reff152_op in H. discriminate H. Qed.

Lemma reff152_not476 : ~ @Equation476 Fin3 reff152_inst.
Proof. unfold Equation476. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff152_inst, reff152_op in H. discriminate H. Qed.

Lemma reff152_not477 : ~ @Equation477 Fin3 reff152_inst.
Proof. unfold Equation477. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff152_inst, reff152_op in H. discriminate H. Qed.

Lemma reff152_not501 : ~ @Equation501 Fin3 reff152_inst.
Proof. unfold Equation501. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff152_inst, reff152_op in H. discriminate H. Qed.

Lemma reff152_not503 : ~ @Equation503 Fin3 reff152_inst.
Proof. unfold Equation503. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff152_inst, reff152_op in H. discriminate H. Qed.

Lemma reff152_not510 : ~ @Equation510 Fin3 reff152_inst.
Proof. unfold Equation510. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff152_inst, reff152_op in H. discriminate H. Qed.

Lemma reff152_not511 : ~ @Equation511 Fin3 reff152_inst.
Proof. unfold Equation511. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff152_inst, reff152_op in H. discriminate H. Qed.

Lemma reff152_not614 : ~ @Equation614 Fin3 reff152_inst.
Proof. unfold Equation614. intro H. specialize (H F3_1). unfold magma_op, reff152_inst, reff152_op in H. discriminate H. Qed.

Lemma reff152_not818 : ~ @Equation818 Fin3 reff152_inst.
Proof. unfold Equation818. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff152_inst, reff152_op in H. discriminate H. Qed.

Lemma reff152_not819 : ~ @Equation819 Fin3 reff152_inst.
Proof. unfold Equation819. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff152_inst, reff152_op in H. discriminate H. Qed.

Lemma reff152_not822 : ~ @Equation822 Fin3 reff152_inst.
Proof. unfold Equation822. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff152_inst, reff152_op in H. discriminate H. Qed.

Lemma reff152_not825 : ~ @Equation825 Fin3 reff152_inst.
Proof. unfold Equation825. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff152_inst, reff152_op in H. discriminate H. Qed.

Lemma reff152_not826 : ~ @Equation826 Fin3 reff152_inst.
Proof. unfold Equation826. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff152_inst, reff152_op in H. discriminate H. Qed.

Lemma reff152_not832 : ~ @Equation832 Fin3 reff152_inst.
Proof. unfold Equation832. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff152_inst, reff152_op in H. discriminate H. Qed.

Lemma reff152_not833 : ~ @Equation833 Fin3 reff152_inst.
Proof. unfold Equation833. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff152_inst, reff152_op in H. discriminate H. Qed.

Lemma reff152_not836 : ~ @Equation836 Fin3 reff152_inst.
Proof. unfold Equation836. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff152_inst, reff152_op in H. discriminate H. Qed.

Lemma reff152_not843 : ~ @Equation843 Fin3 reff152_inst.
Proof. unfold Equation843. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff152_inst, reff152_op in H. discriminate H. Qed.

Lemma reff152_not845 : ~ @Equation845 Fin3 reff152_inst.
Proof. unfold Equation845. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff152_inst, reff152_op in H. discriminate H. Qed.

Lemma reff152_not869 : ~ @Equation869 Fin3 reff152_inst.
Proof. unfold Equation869. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff152_inst, reff152_op in H. discriminate H. Qed.

Lemma reff152_not872 : ~ @Equation872 Fin3 reff152_inst.
Proof. unfold Equation872. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff152_inst, reff152_op in H. discriminate H. Qed.

Lemma reff152_not873 : ~ @Equation873 Fin3 reff152_inst.
Proof. unfold Equation873. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff152_inst, reff152_op in H. discriminate H. Qed.

Lemma reff152_not879 : ~ @Equation879 Fin3 reff152_inst.
Proof. unfold Equation879. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff152_inst, reff152_op in H. discriminate H. Qed.

Lemma reff152_not880 : ~ @Equation880 Fin3 reff152_inst.
Proof. unfold Equation880. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff152_inst, reff152_op in H. discriminate H. Qed.

Lemma reff152_not883 : ~ @Equation883 Fin3 reff152_inst.
Proof. unfold Equation883. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff152_inst, reff152_op in H. discriminate H. Qed.

Lemma reff152_not907 : ~ @Equation907 Fin3 reff152_inst.
Proof. unfold Equation907. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff152_inst, reff152_op in H. discriminate H. Qed.

Lemma reff152_not909 : ~ @Equation909 Fin3 reff152_inst.
Proof. unfold Equation909. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff152_inst, reff152_op in H. discriminate H. Qed.

Lemma reff152_not916 : ~ @Equation916 Fin3 reff152_inst.
Proof. unfold Equation916. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff152_inst, reff152_op in H. discriminate H. Qed.

Lemma reff152_not919 : ~ @Equation919 Fin3 reff152_inst.
Proof. unfold Equation919. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff152_inst, reff152_op in H. discriminate H. Qed.

Lemma reff152_not1021 : ~ @Equation1021 Fin3 reff152_inst.
Proof. unfold Equation1021. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff152_inst, reff152_op in H. discriminate H. Qed.

Lemma reff152_not1022 : ~ @Equation1022 Fin3 reff152_inst.
Proof. unfold Equation1022. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff152_inst, reff152_op in H. discriminate H. Qed.

Lemma reff152_not1025 : ~ @Equation1025 Fin3 reff152_inst.
Proof. unfold Equation1025. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff152_inst, reff152_op in H. discriminate H. Qed.

Lemma reff152_not1026 : ~ @Equation1026 Fin3 reff152_inst.
Proof. unfold Equation1026. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff152_inst, reff152_op in H. discriminate H. Qed.

Lemma reff152_not1029 : ~ @Equation1029 Fin3 reff152_inst.
Proof. unfold Equation1029. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff152_inst, reff152_op in H. discriminate H. Qed.

Lemma reff152_not1035 : ~ @Equation1035 Fin3 reff152_inst.
Proof. unfold Equation1035. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff152_inst, reff152_op in H. discriminate H. Qed.

Lemma reff152_not1038 : ~ @Equation1038 Fin3 reff152_inst.
Proof. unfold Equation1038. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff152_inst, reff152_op in H. discriminate H. Qed.

Lemma reff152_not1039 : ~ @Equation1039 Fin3 reff152_inst.
Proof. unfold Equation1039. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff152_inst, reff152_op in H. discriminate H. Qed.

Lemma reff152_not1046 : ~ @Equation1046 Fin3 reff152_inst.
Proof. unfold Equation1046. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff152_inst, reff152_op in H. discriminate H. Qed.

Lemma reff152_not1048 : ~ @Equation1048 Fin3 reff152_inst.
Proof. unfold Equation1048. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff152_inst, reff152_op in H. discriminate H. Qed.

Lemma reff152_not1072 : ~ @Equation1072 Fin3 reff152_inst.
Proof. unfold Equation1072. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff152_inst, reff152_op in H. discriminate H. Qed.

Lemma reff152_not1073 : ~ @Equation1073 Fin3 reff152_inst.
Proof. unfold Equation1073. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff152_inst, reff152_op in H. discriminate H. Qed.

Lemma reff152_not1076 : ~ @Equation1076 Fin3 reff152_inst.
Proof. unfold Equation1076. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff152_inst, reff152_op in H. discriminate H. Qed.

Lemma reff152_not1082 : ~ @Equation1082 Fin3 reff152_inst.
Proof. unfold Equation1082. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff152_inst, reff152_op in H. discriminate H. Qed.

Lemma reff152_not1085 : ~ @Equation1085 Fin3 reff152_inst.
Proof. unfold Equation1085. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff152_inst, reff152_op in H. discriminate H. Qed.

Lemma reff152_not1086 : ~ @Equation1086 Fin3 reff152_inst.
Proof. unfold Equation1086. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff152_inst, reff152_op in H. discriminate H. Qed.

Lemma reff152_not1110 : ~ @Equation1110 Fin3 reff152_inst.
Proof. unfold Equation1110. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff152_inst, reff152_op in H. discriminate H. Qed.

Lemma reff152_not1112 : ~ @Equation1112 Fin3 reff152_inst.
Proof. unfold Equation1112. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff152_inst, reff152_op in H. discriminate H. Qed.

Lemma reff152_not1119 : ~ @Equation1119 Fin3 reff152_inst.
Proof. unfold Equation1119. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff152_inst, reff152_op in H. discriminate H. Qed.

Lemma reff152_not1120 : ~ @Equation1120 Fin3 reff152_inst.
Proof. unfold Equation1120. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff152_inst, reff152_op in H. discriminate H. Qed.

Lemma reff152_not1223 : ~ @Equation1223 Fin3 reff152_inst.
Proof. unfold Equation1223. intro H. specialize (H F3_1). unfold magma_op, reff152_inst, reff152_op in H. discriminate H. Qed.

Lemma reff152_not1426 : ~ @Equation1426 Fin3 reff152_inst.
Proof. unfold Equation1426. intro H. specialize (H F3_1). unfold magma_op, reff152_inst, reff152_op in H. discriminate H. Qed.

Lemma reff152_not1630 : ~ @Equation1630 Fin3 reff152_inst.
Proof. unfold Equation1630. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff152_inst, reff152_op in H. discriminate H. Qed.

Lemma reff152_not1631 : ~ @Equation1631 Fin3 reff152_inst.
Proof. unfold Equation1631. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff152_inst, reff152_op in H. discriminate H. Qed.

Lemma reff152_not1632 : ~ @Equation1632 Fin3 reff152_inst.
Proof. unfold Equation1632. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff152_inst, reff152_op in H. discriminate H. Qed.

Lemma reff152_not1634 : ~ @Equation1634 Fin3 reff152_inst.
Proof. unfold Equation1634. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff152_inst, reff152_op in H. discriminate H. Qed.

Lemma reff152_not1638 : ~ @Equation1638 Fin3 reff152_inst.
Proof. unfold Equation1638. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff152_inst, reff152_op in H. discriminate H. Qed.

Lemma reff152_not1644 : ~ @Equation1644 Fin3 reff152_inst.
Proof. unfold Equation1644. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff152_inst, reff152_op in H. discriminate H. Qed.

Lemma reff152_not1648 : ~ @Equation1648 Fin3 reff152_inst.
Proof. unfold Equation1648. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff152_inst, reff152_op in H. discriminate H. Qed.

Lemma reff152_not1654 : ~ @Equation1654 Fin3 reff152_inst.
Proof. unfold Equation1654. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff152_inst, reff152_op in H. discriminate H. Qed.

Lemma reff152_not1655 : ~ @Equation1655 Fin3 reff152_inst.
Proof. unfold Equation1655. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff152_inst, reff152_op in H. discriminate H. Qed.

Lemma reff152_not1657 : ~ @Equation1657 Fin3 reff152_inst.
Proof. unfold Equation1657. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff152_inst, reff152_op in H. discriminate H. Qed.

Lemma reff152_not1681 : ~ @Equation1681 Fin3 reff152_inst.
Proof. unfold Equation1681. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff152_inst, reff152_op in H. discriminate H. Qed.

Lemma reff152_not1682 : ~ @Equation1682 Fin3 reff152_inst.
Proof. unfold Equation1682. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff152_inst, reff152_op in H. discriminate H. Qed.

Lemma reff152_not1684 : ~ @Equation1684 Fin3 reff152_inst.
Proof. unfold Equation1684. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff152_inst, reff152_op in H. discriminate H. Qed.

Lemma reff152_not1692 : ~ @Equation1692 Fin3 reff152_inst.
Proof. unfold Equation1692. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff152_inst, reff152_op in H. discriminate H. Qed.

Lemma reff152_not1694 : ~ @Equation1694 Fin3 reff152_inst.
Proof. unfold Equation1694. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff152_inst, reff152_op in H. discriminate H. Qed.

Lemma reff152_not1695 : ~ @Equation1695 Fin3 reff152_inst.
Proof. unfold Equation1695. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff152_inst, reff152_op in H. discriminate H. Qed.

Lemma reff152_not1719 : ~ @Equation1719 Fin3 reff152_inst.
Proof. unfold Equation1719. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff152_inst, reff152_op in H. discriminate H. Qed.

Lemma reff152_not1721 : ~ @Equation1721 Fin3 reff152_inst.
Proof. unfold Equation1721. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff152_inst, reff152_op in H. discriminate H. Qed.

Lemma reff152_not1722 : ~ @Equation1722 Fin3 reff152_inst.
Proof. unfold Equation1722. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff152_inst, reff152_op in H. discriminate H. Qed.

Lemma reff152_not1728 : ~ @Equation1728 Fin3 reff152_inst.
Proof. unfold Equation1728. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff152_inst, reff152_op in H. discriminate H. Qed.

Lemma reff152_not1833 : ~ @Equation1833 Fin3 reff152_inst.
Proof. unfold Equation1833. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff152_inst, reff152_op in H. discriminate H. Qed.

Lemma reff152_not1834 : ~ @Equation1834 Fin3 reff152_inst.
Proof. unfold Equation1834. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff152_inst, reff152_op in H. discriminate H. Qed.

Lemma reff152_not1837 : ~ @Equation1837 Fin3 reff152_inst.
Proof. unfold Equation1837. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff152_inst, reff152_op in H. discriminate H. Qed.

Lemma reff152_not1838 : ~ @Equation1838 Fin3 reff152_inst.
Proof. unfold Equation1838. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff152_inst, reff152_op in H. discriminate H. Qed.

Lemma reff152_not1841 : ~ @Equation1841 Fin3 reff152_inst.
Proof. unfold Equation1841. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff152_inst, reff152_op in H. discriminate H. Qed.

Lemma reff152_not1847 : ~ @Equation1847 Fin3 reff152_inst.
Proof. unfold Equation1847. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff152_inst, reff152_op in H. discriminate H. Qed.

Lemma reff152_not1850 : ~ @Equation1850 Fin3 reff152_inst.
Proof. unfold Equation1850. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff152_inst, reff152_op in H. discriminate H. Qed.

Lemma reff152_not1851 : ~ @Equation1851 Fin3 reff152_inst.
Proof. unfold Equation1851. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff152_inst, reff152_op in H. discriminate H. Qed.

Lemma reff152_not1858 : ~ @Equation1858 Fin3 reff152_inst.
Proof. unfold Equation1858. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff152_inst, reff152_op in H. discriminate H. Qed.

Lemma reff152_not1860 : ~ @Equation1860 Fin3 reff152_inst.
Proof. unfold Equation1860. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff152_inst, reff152_op in H. discriminate H. Qed.

Lemma reff152_not1884 : ~ @Equation1884 Fin3 reff152_inst.
Proof. unfold Equation1884. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff152_inst, reff152_op in H. discriminate H. Qed.

Lemma reff152_not1885 : ~ @Equation1885 Fin3 reff152_inst.
Proof. unfold Equation1885. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff152_inst, reff152_op in H. discriminate H. Qed.

Lemma reff152_not1888 : ~ @Equation1888 Fin3 reff152_inst.
Proof. unfold Equation1888. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff152_inst, reff152_op in H. discriminate H. Qed.

Lemma reff152_not1894 : ~ @Equation1894 Fin3 reff152_inst.
Proof. unfold Equation1894. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff152_inst, reff152_op in H. discriminate H. Qed.

Lemma reff152_not1897 : ~ @Equation1897 Fin3 reff152_inst.
Proof. unfold Equation1897. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff152_inst, reff152_op in H. discriminate H. Qed.

Lemma reff152_not1898 : ~ @Equation1898 Fin3 reff152_inst.
Proof. unfold Equation1898. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff152_inst, reff152_op in H. discriminate H. Qed.

Lemma reff152_not1922 : ~ @Equation1922 Fin3 reff152_inst.
Proof. unfold Equation1922. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff152_inst, reff152_op in H. discriminate H. Qed.

Lemma reff152_not1924 : ~ @Equation1924 Fin3 reff152_inst.
Proof. unfold Equation1924. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff152_inst, reff152_op in H. discriminate H. Qed.

Lemma reff152_not1931 : ~ @Equation1931 Fin3 reff152_inst.
Proof. unfold Equation1931. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff152_inst, reff152_op in H. discriminate H. Qed.

Lemma reff152_not1932 : ~ @Equation1932 Fin3 reff152_inst.
Proof. unfold Equation1932. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff152_inst, reff152_op in H. discriminate H. Qed.

Lemma reff152_not2035 : ~ @Equation2035 Fin3 reff152_inst.
Proof. unfold Equation2035. intro H. specialize (H F3_1). unfold magma_op, reff152_inst, reff152_op in H. discriminate H. Qed.

Lemma reff152_not2238 : ~ @Equation2238 Fin3 reff152_inst.
Proof. unfold Equation2238. intro H. specialize (H F3_1). unfold magma_op, reff152_inst, reff152_op in H. discriminate H. Qed.

Lemma reff152_not2442 : ~ @Equation2442 Fin3 reff152_inst.
Proof. unfold Equation2442. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff152_inst, reff152_op in H. discriminate H. Qed.

Lemma reff152_not2443 : ~ @Equation2443 Fin3 reff152_inst.
Proof. unfold Equation2443. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff152_inst, reff152_op in H. discriminate H. Qed.

Lemma reff152_not2446 : ~ @Equation2446 Fin3 reff152_inst.
Proof. unfold Equation2446. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff152_inst, reff152_op in H. discriminate H. Qed.

Lemma reff152_not2449 : ~ @Equation2449 Fin3 reff152_inst.
Proof. unfold Equation2449. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff152_inst, reff152_op in H. discriminate H. Qed.

Lemma reff152_not2450 : ~ @Equation2450 Fin3 reff152_inst.
Proof. unfold Equation2450. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff152_inst, reff152_op in H. discriminate H. Qed.

Lemma reff152_not2456 : ~ @Equation2456 Fin3 reff152_inst.
Proof. unfold Equation2456. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff152_inst, reff152_op in H. discriminate H. Qed.

Lemma reff152_not2457 : ~ @Equation2457 Fin3 reff152_inst.
Proof. unfold Equation2457. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff152_inst, reff152_op in H. discriminate H. Qed.

Lemma reff152_not2460 : ~ @Equation2460 Fin3 reff152_inst.
Proof. unfold Equation2460. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff152_inst, reff152_op in H. discriminate H. Qed.

Lemma reff152_not2467 : ~ @Equation2467 Fin3 reff152_inst.
Proof. unfold Equation2467. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff152_inst, reff152_op in H. discriminate H. Qed.

Lemma reff152_not2469 : ~ @Equation2469 Fin3 reff152_inst.
Proof. unfold Equation2469. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff152_inst, reff152_op in H. discriminate H. Qed.

Lemma reff152_not2493 : ~ @Equation2493 Fin3 reff152_inst.
Proof. unfold Equation2493. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff152_inst, reff152_op in H. discriminate H. Qed.

Lemma reff152_not2496 : ~ @Equation2496 Fin3 reff152_inst.
Proof. unfold Equation2496. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff152_inst, reff152_op in H. discriminate H. Qed.

Lemma reff152_not2497 : ~ @Equation2497 Fin3 reff152_inst.
Proof. unfold Equation2497. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff152_inst, reff152_op in H. discriminate H. Qed.

Lemma reff152_not2503 : ~ @Equation2503 Fin3 reff152_inst.
Proof. unfold Equation2503. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff152_inst, reff152_op in H. discriminate H. Qed.

Lemma reff152_not2504 : ~ @Equation2504 Fin3 reff152_inst.
Proof. unfold Equation2504. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff152_inst, reff152_op in H. discriminate H. Qed.

Lemma reff152_not2507 : ~ @Equation2507 Fin3 reff152_inst.
Proof. unfold Equation2507. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff152_inst, reff152_op in H. discriminate H. Qed.

Lemma reff152_not2531 : ~ @Equation2531 Fin3 reff152_inst.
Proof. unfold Equation2531. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff152_inst, reff152_op in H. discriminate H. Qed.

Lemma reff152_not2533 : ~ @Equation2533 Fin3 reff152_inst.
Proof. unfold Equation2533. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff152_inst, reff152_op in H. discriminate H. Qed.

Lemma reff152_not2540 : ~ @Equation2540 Fin3 reff152_inst.
Proof. unfold Equation2540. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff152_inst, reff152_op in H. discriminate H. Qed.

Lemma reff152_not2543 : ~ @Equation2543 Fin3 reff152_inst.
Proof. unfold Equation2543. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff152_inst, reff152_op in H. discriminate H. Qed.

Lemma reff152_not2644 : ~ @Equation2644 Fin3 reff152_inst.
Proof. unfold Equation2644. intro H. specialize (H F3_1). unfold magma_op, reff152_inst, reff152_op in H. discriminate H. Qed.

Lemma reff152_not2847 : ~ @Equation2847 Fin3 reff152_inst.
Proof. unfold Equation2847. intro H. specialize (H F3_1). unfold magma_op, reff152_inst, reff152_op in H. discriminate H. Qed.

Lemma reff152_not3050 : ~ @Equation3050 Fin3 reff152_inst.
Proof. unfold Equation3050. intro H. specialize (H F3_1). unfold magma_op, reff152_inst, reff152_op in H. discriminate H. Qed.

Lemma reff152_not3254 : ~ @Equation3254 Fin3 reff152_inst.
Proof. unfold Equation3254. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff152_inst, reff152_op in H. discriminate H. Qed.

Lemma reff152_not3255 : ~ @Equation3255 Fin3 reff152_inst.
Proof. unfold Equation3255. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff152_inst, reff152_op in H. discriminate H. Qed.

Lemma reff152_not3258 : ~ @Equation3258 Fin3 reff152_inst.
Proof. unfold Equation3258. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff152_inst, reff152_op in H. discriminate H. Qed.

Lemma reff152_not3259 : ~ @Equation3259 Fin3 reff152_inst.
Proof. unfold Equation3259. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff152_inst, reff152_op in H. discriminate H. Qed.

Lemma reff152_not3262 : ~ @Equation3262 Fin3 reff152_inst.
Proof. unfold Equation3262. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff152_inst, reff152_op in H. discriminate H. Qed.

Lemma reff152_not3268 : ~ @Equation3268 Fin3 reff152_inst.
Proof. unfold Equation3268. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff152_inst, reff152_op in H. discriminate H. Qed.

Lemma reff152_not3271 : ~ @Equation3271 Fin3 reff152_inst.
Proof. unfold Equation3271. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff152_inst, reff152_op in H. discriminate H. Qed.

Lemma reff152_not3272 : ~ @Equation3272 Fin3 reff152_inst.
Proof. unfold Equation3272. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff152_inst, reff152_op in H. discriminate H. Qed.

Lemma reff152_not3279 : ~ @Equation3279 Fin3 reff152_inst.
Proof. unfold Equation3279. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff152_inst, reff152_op in H. discriminate H. Qed.

Lemma reff152_not3281 : ~ @Equation3281 Fin3 reff152_inst.
Proof. unfold Equation3281. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff152_inst, reff152_op in H. discriminate H. Qed.

Lemma reff152_not3308 : ~ @Equation3308 Fin3 reff152_inst.
Proof. unfold Equation3308. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff152_inst, reff152_op in H. discriminate H. Qed.

Lemma reff152_not3309 : ~ @Equation3309 Fin3 reff152_inst.
Proof. unfold Equation3309. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff152_inst, reff152_op in H. discriminate H. Qed.

Lemma reff152_not3316 : ~ @Equation3316 Fin3 reff152_inst.
Proof. unfold Equation3316. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff152_inst, reff152_op in H. discriminate H. Qed.

Lemma reff152_not3318 : ~ @Equation3318 Fin3 reff152_inst.
Proof. unfold Equation3318. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff152_inst, reff152_op in H. discriminate H. Qed.

Lemma reff152_not3342 : ~ @Equation3342 Fin3 reff152_inst.
Proof. unfold Equation3342. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff152_inst, reff152_op in H. discriminate H. Qed.

Lemma reff152_not3343 : ~ @Equation3343 Fin3 reff152_inst.
Proof. unfold Equation3343. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff152_inst, reff152_op in H. discriminate H. Qed.

Lemma reff152_not3346 : ~ @Equation3346 Fin3 reff152_inst.
Proof. unfold Equation3346. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff152_inst, reff152_op in H. discriminate H. Qed.

Lemma reff152_not3352 : ~ @Equation3352 Fin3 reff152_inst.
Proof. unfold Equation3352. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff152_inst, reff152_op in H. discriminate H. Qed.

Lemma reff152_not3456 : ~ @Equation3456 Fin3 reff152_inst.
Proof. unfold Equation3456. intro H. specialize (H F3_1). unfold magma_op, reff152_inst, reff152_op in H. discriminate H. Qed.

Lemma reff152_not3660 : ~ @Equation3660 Fin3 reff152_inst.
Proof. unfold Equation3660. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff152_inst, reff152_op in H. discriminate H. Qed.

Lemma reff152_not3661 : ~ @Equation3661 Fin3 reff152_inst.
Proof. unfold Equation3661. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff152_inst, reff152_op in H. discriminate H. Qed.

Lemma reff152_not3664 : ~ @Equation3664 Fin3 reff152_inst.
Proof. unfold Equation3664. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff152_inst, reff152_op in H. discriminate H. Qed.

Lemma reff152_not3667 : ~ @Equation3667 Fin3 reff152_inst.
Proof. unfold Equation3667. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff152_inst, reff152_op in H. discriminate H. Qed.

Lemma reff152_not3668 : ~ @Equation3668 Fin3 reff152_inst.
Proof. unfold Equation3668. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff152_inst, reff152_op in H. discriminate H. Qed.

Lemma reff152_not3674 : ~ @Equation3674 Fin3 reff152_inst.
Proof. unfold Equation3674. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff152_inst, reff152_op in H. discriminate H. Qed.

Lemma reff152_not3675 : ~ @Equation3675 Fin3 reff152_inst.
Proof. unfold Equation3675. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff152_inst, reff152_op in H. discriminate H. Qed.

Lemma reff152_not3678 : ~ @Equation3678 Fin3 reff152_inst.
Proof. unfold Equation3678. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff152_inst, reff152_op in H. discriminate H. Qed.

Lemma reff152_not3685 : ~ @Equation3685 Fin3 reff152_inst.
Proof. unfold Equation3685. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff152_inst, reff152_op in H. discriminate H. Qed.

Lemma reff152_not3687 : ~ @Equation3687 Fin3 reff152_inst.
Proof. unfold Equation3687. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff152_inst, reff152_op in H. discriminate H. Qed.

Lemma reff152_not3712 : ~ @Equation3712 Fin3 reff152_inst.
Proof. unfold Equation3712. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff152_inst, reff152_op in H. discriminate H. Qed.

Lemma reff152_not3722 : ~ @Equation3722 Fin3 reff152_inst.
Proof. unfold Equation3722. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff152_inst, reff152_op in H. discriminate H. Qed.

Lemma reff152_not3724 : ~ @Equation3724 Fin3 reff152_inst.
Proof. unfold Equation3724. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff152_inst, reff152_op in H. discriminate H. Qed.

Lemma reff152_not3748 : ~ @Equation3748 Fin3 reff152_inst.
Proof. unfold Equation3748. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff152_inst, reff152_op in H. discriminate H. Qed.

Lemma reff152_not3751 : ~ @Equation3751 Fin3 reff152_inst.
Proof. unfold Equation3751. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff152_inst, reff152_op in H. discriminate H. Qed.

Lemma reff152_not3752 : ~ @Equation3752 Fin3 reff152_inst.
Proof. unfold Equation3752. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff152_inst, reff152_op in H. discriminate H. Qed.

Lemma reff152_not3759 : ~ @Equation3759 Fin3 reff152_inst.
Proof. unfold Equation3759. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff152_inst, reff152_op in H. discriminate H. Qed.

Lemma reff152_not3864 : ~ @Equation3864 Fin3 reff152_inst.
Proof. unfold Equation3864. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff152_inst, reff152_op in H. discriminate H. Qed.

Lemma reff152_not3867 : ~ @Equation3867 Fin3 reff152_inst.
Proof. unfold Equation3867. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff152_inst, reff152_op in H. discriminate H. Qed.

Lemma reff152_not3868 : ~ @Equation3868 Fin3 reff152_inst.
Proof. unfold Equation3868. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff152_inst, reff152_op in H. discriminate H. Qed.

Lemma reff152_not3871 : ~ @Equation3871 Fin3 reff152_inst.
Proof. unfold Equation3871. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff152_inst, reff152_op in H. discriminate H. Qed.

Lemma reff152_not3877 : ~ @Equation3877 Fin3 reff152_inst.
Proof. unfold Equation3877. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff152_inst, reff152_op in H. discriminate H. Qed.

Lemma reff152_not3880 : ~ @Equation3880 Fin3 reff152_inst.
Proof. unfold Equation3880. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff152_inst, reff152_op in H. discriminate H. Qed.

Lemma reff152_not3881 : ~ @Equation3881 Fin3 reff152_inst.
Proof. unfold Equation3881. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff152_inst, reff152_op in H. discriminate H. Qed.

Lemma reff152_not3888 : ~ @Equation3888 Fin3 reff152_inst.
Proof. unfold Equation3888. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff152_inst, reff152_op in H. discriminate H. Qed.

Lemma reff152_not3890 : ~ @Equation3890 Fin3 reff152_inst.
Proof. unfold Equation3890. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff152_inst, reff152_op in H. discriminate H. Qed.

Lemma reff152_not3917 : ~ @Equation3917 Fin3 reff152_inst.
Proof. unfold Equation3917. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff152_inst, reff152_op in H. discriminate H. Qed.

Lemma reff152_not3918 : ~ @Equation3918 Fin3 reff152_inst.
Proof. unfold Equation3918. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff152_inst, reff152_op in H. discriminate H. Qed.

Lemma reff152_not3925 : ~ @Equation3925 Fin3 reff152_inst.
Proof. unfold Equation3925. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff152_inst, reff152_op in H. discriminate H. Qed.

Lemma reff152_not3927 : ~ @Equation3927 Fin3 reff152_inst.
Proof. unfold Equation3927. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff152_inst, reff152_op in H. discriminate H. Qed.

Lemma reff152_not3951 : ~ @Equation3951 Fin3 reff152_inst.
Proof. unfold Equation3951. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff152_inst, reff152_op in H. discriminate H. Qed.

Lemma reff152_not3952 : ~ @Equation3952 Fin3 reff152_inst.
Proof. unfold Equation3952. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff152_inst, reff152_op in H. discriminate H. Qed.

Lemma reff152_not3955 : ~ @Equation3955 Fin3 reff152_inst.
Proof. unfold Equation3955. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff152_inst, reff152_op in H. discriminate H. Qed.

Lemma reff152_not3961 : ~ @Equation3961 Fin3 reff152_inst.
Proof. unfold Equation3961. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff152_inst, reff152_op in H. discriminate H. Qed.

Lemma reff152_not3964 : ~ @Equation3964 Fin3 reff152_inst.
Proof. unfold Equation3964. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff152_inst, reff152_op in H. discriminate H. Qed.

Lemma reff152_not4065 : ~ @Equation4065 Fin3 reff152_inst.
Proof. unfold Equation4065. intro H. specialize (H F3_1). unfold magma_op, reff152_inst, reff152_op in H. discriminate H. Qed.

Lemma reff152_not4268 : ~ @Equation4268 Fin3 reff152_inst.
Proof. unfold Equation4268. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff152_inst, reff152_op in H. discriminate H. Qed.

Lemma reff152_not4269 : ~ @Equation4269 Fin3 reff152_inst.
Proof. unfold Equation4269. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff152_inst, reff152_op in H. discriminate H. Qed.

Lemma reff152_not4272 : ~ @Equation4272 Fin3 reff152_inst.
Proof. unfold Equation4272. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff152_inst, reff152_op in H. discriminate H. Qed.

Lemma reff152_not4273 : ~ @Equation4273 Fin3 reff152_inst.
Proof. unfold Equation4273. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff152_inst, reff152_op in H. discriminate H. Qed.

Lemma reff152_not4276 : ~ @Equation4276 Fin3 reff152_inst.
Proof. unfold Equation4276. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff152_inst, reff152_op in H. discriminate H. Qed.

Lemma reff152_not4283 : ~ @Equation4283 Fin3 reff152_inst.
Proof. unfold Equation4283. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff152_inst, reff152_op in H. discriminate H. Qed.

Lemma reff152_not4284 : ~ @Equation4284 Fin3 reff152_inst.
Proof. unfold Equation4284. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff152_inst, reff152_op in H. discriminate H. Qed.

Lemma reff152_not4291 : ~ @Equation4291 Fin3 reff152_inst.
Proof. unfold Equation4291. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff152_inst, reff152_op in H. discriminate H. Qed.

Lemma reff152_not4293 : ~ @Equation4293 Fin3 reff152_inst.
Proof. unfold Equation4293. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff152_inst, reff152_op in H. discriminate H. Qed.

Lemma reff152_not4314 : ~ @Equation4314 Fin3 reff152_inst.
Proof. unfold Equation4314. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff152_inst, reff152_op in H. discriminate H. Qed.

Lemma reff152_not4320 : ~ @Equation4320 Fin3 reff152_inst.
Proof. unfold Equation4320. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff152_inst, reff152_op in H. discriminate H. Qed.

Lemma reff152_not4343 : ~ @Equation4343 Fin3 reff152_inst.
Proof. unfold Equation4343. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff152_inst, reff152_op in H. discriminate H. Qed.

Lemma reff152_not4380 : ~ @Equation4380 Fin3 reff152_inst.
Proof. unfold Equation4380. intro H. specialize (H F3_1). unfold magma_op, reff152_inst, reff152_op in H. discriminate H. Qed.

Lemma reff152_not4583 : ~ @Equation4583 Fin3 reff152_inst.
Proof. unfold Equation4583. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff152_inst, reff152_op in H. discriminate H. Qed.

Lemma reff152_not4584 : ~ @Equation4584 Fin3 reff152_inst.
Proof. unfold Equation4584. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff152_inst, reff152_op in H. discriminate H. Qed.

Lemma reff152_not4585 : ~ @Equation4585 Fin3 reff152_inst.
Proof. unfold Equation4585. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff152_inst, reff152_op in H. discriminate H. Qed.

Lemma reff152_not4587 : ~ @Equation4587 Fin3 reff152_inst.
Proof. unfold Equation4587. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff152_inst, reff152_op in H. discriminate H. Qed.

Lemma reff152_not4591 : ~ @Equation4591 Fin3 reff152_inst.
Proof. unfold Equation4591. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff152_inst, reff152_op in H. discriminate H. Qed.

Lemma reff152_not4599 : ~ @Equation4599 Fin3 reff152_inst.
Proof. unfold Equation4599. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff152_inst, reff152_op in H. discriminate H. Qed.

Lemma reff152_not4605 : ~ @Equation4605 Fin3 reff152_inst.
Proof. unfold Equation4605. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff152_inst, reff152_op in H. discriminate H. Qed.

Lemma reff152_not4606 : ~ @Equation4606 Fin3 reff152_inst.
Proof. unfold Equation4606. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff152_inst, reff152_op in H. discriminate H. Qed.

Lemma reff152_not4608 : ~ @Equation4608 Fin3 reff152_inst.
Proof. unfold Equation4608. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff152_inst, reff152_op in H. discriminate H. Qed.

Lemma reff152_not4629 : ~ @Equation4629 Fin3 reff152_inst.
Proof. unfold Equation4629. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff152_inst, reff152_op in H. discriminate H. Qed.

Lemma reff152_not4635 : ~ @Equation4635 Fin3 reff152_inst.
Proof. unfold Equation4635. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff152_inst, reff152_op in H. discriminate H. Qed.

Lemma reff152_not4636 : ~ @Equation4636 Fin3 reff152_inst.
Proof. unfold Equation4636. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff152_inst, reff152_op in H. discriminate H. Qed.

(** ---- reff154 (Fin4) ---- *)

Definition reff154_op (x y : Fin4) : Fin4 :=
  match x, y with
  | F4_0, F4_0 => F4_0 | F4_0, F4_1 => F4_2 | F4_0, F4_2 => F4_0 | F4_0, F4_3 => F4_2
  | F4_1, F4_0 => F4_1 | F4_1, F4_1 => F4_1 | F4_1, F4_2 => F4_1 | F4_1, F4_3 => F4_1
  | F4_2, F4_0 => F4_0 | F4_2, F4_1 => F4_2 | F4_2, F4_2 => F4_0 | F4_2, F4_3 => F4_2
  | F4_3, F4_0 => F4_1 | F4_3, F4_1 => F4_1 | F4_3, F4_2 => F4_1 | F4_3, F4_3 => F4_1
  end.

#[local] Instance reff154_inst : Magma Fin4 := {| magma_op := reff154_op |}.

Lemma reff154_sat327 : @Equation327 Fin4 reff154_inst.
Proof. unfold Equation327, magma_op, reff154_inst, reff154_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff154_sat381 : @Equation381 Fin4 reff154_inst.
Proof. unfold Equation381, magma_op, reff154_inst, reff154_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff154_sat3738 : @Equation3738 Fin4 reff154_inst.
Proof. unfold Equation3738, magma_op, reff154_inst, reff154_op. intros x y z w. destruct x, y, z, w; reflexivity. Qed.

Lemma reff154_sat4519 : @Equation4519 Fin4 reff154_inst.
Proof. unfold Equation4519, magma_op, reff154_inst, reff154_op. intros x y z w. destruct x, y, z, w; reflexivity. Qed.

Lemma reff154_not47 : ~ @Equation47 Fin4 reff154_inst.
Proof. unfold Equation47. intro H. specialize (H F4_2). unfold magma_op, reff154_inst, reff154_op in H. discriminate H. Qed.

Lemma reff154_not99 : ~ @Equation99 Fin4 reff154_inst.
Proof. unfold Equation99. intro H. specialize (H F4_2). unfold magma_op, reff154_inst, reff154_op in H. discriminate H. Qed.

Lemma reff154_not151 : ~ @Equation151 Fin4 reff154_inst.
Proof. unfold Equation151. intro H. specialize (H F4_2). unfold magma_op, reff154_inst, reff154_op in H. discriminate H. Qed.

Lemma reff154_not203 : ~ @Equation203 Fin4 reff154_inst.
Proof. unfold Equation203. intro H. specialize (H F4_2). unfold magma_op, reff154_inst, reff154_op in H. discriminate H. Qed.

Lemma reff154_not255 : ~ @Equation255 Fin4 reff154_inst.
Proof. unfold Equation255. intro H. specialize (H F4_2). unfold magma_op, reff154_inst, reff154_op in H. discriminate H. Qed.

Lemma reff154_not411 : ~ @Equation411 Fin4 reff154_inst.
Proof. unfold Equation411. intro H. specialize (H F4_2). unfold magma_op, reff154_inst, reff154_op in H. discriminate H. Qed.

Lemma reff154_not614 : ~ @Equation614 Fin4 reff154_inst.
Proof. unfold Equation614. intro H. specialize (H F4_2). unfold magma_op, reff154_inst, reff154_op in H. discriminate H. Qed.

Lemma reff154_not817 : ~ @Equation817 Fin4 reff154_inst.
Proof. unfold Equation817. intro H. specialize (H F4_2). unfold magma_op, reff154_inst, reff154_op in H. discriminate H. Qed.

Lemma reff154_not1020 : ~ @Equation1020 Fin4 reff154_inst.
Proof. unfold Equation1020. intro H. specialize (H F4_2). unfold magma_op, reff154_inst, reff154_op in H. discriminate H. Qed.

Lemma reff154_not1223 : ~ @Equation1223 Fin4 reff154_inst.
Proof. unfold Equation1223. intro H. specialize (H F4_2). unfold magma_op, reff154_inst, reff154_op in H. discriminate H. Qed.

Lemma reff154_not1426 : ~ @Equation1426 Fin4 reff154_inst.
Proof. unfold Equation1426. intro H. specialize (H F4_2). unfold magma_op, reff154_inst, reff154_op in H. discriminate H. Qed.

Lemma reff154_not1629 : ~ @Equation1629 Fin4 reff154_inst.
Proof. unfold Equation1629. intro H. specialize (H F4_2). unfold magma_op, reff154_inst, reff154_op in H. discriminate H. Qed.

Lemma reff154_not1832 : ~ @Equation1832 Fin4 reff154_inst.
Proof. unfold Equation1832. intro H. specialize (H F4_2). unfold magma_op, reff154_inst, reff154_op in H. discriminate H. Qed.

Lemma reff154_not2035 : ~ @Equation2035 Fin4 reff154_inst.
Proof. unfold Equation2035. intro H. specialize (H F4_2). unfold magma_op, reff154_inst, reff154_op in H. discriminate H. Qed.

Lemma reff154_not2238 : ~ @Equation2238 Fin4 reff154_inst.
Proof. unfold Equation2238. intro H. specialize (H F4_2). unfold magma_op, reff154_inst, reff154_op in H. discriminate H. Qed.

Lemma reff154_not2441 : ~ @Equation2441 Fin4 reff154_inst.
Proof. unfold Equation2441. intro H. specialize (H F4_2). unfold magma_op, reff154_inst, reff154_op in H. discriminate H. Qed.

Lemma reff154_not2644 : ~ @Equation2644 Fin4 reff154_inst.
Proof. unfold Equation2644. intro H. specialize (H F4_2). unfold magma_op, reff154_inst, reff154_op in H. discriminate H. Qed.

Lemma reff154_not2847 : ~ @Equation2847 Fin4 reff154_inst.
Proof. unfold Equation2847. intro H. specialize (H F4_2). unfold magma_op, reff154_inst, reff154_op in H. discriminate H. Qed.

Lemma reff154_not3050 : ~ @Equation3050 Fin4 reff154_inst.
Proof. unfold Equation3050. intro H. specialize (H F4_2). unfold magma_op, reff154_inst, reff154_op in H. discriminate H. Qed.

Lemma reff154_not3258 : ~ @Equation3258 Fin4 reff154_inst.
Proof. unfold Equation3258. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff154_inst, reff154_op in H. discriminate H. Qed.

Lemma reff154_not3259 : ~ @Equation3259 Fin4 reff154_inst.
Proof. unfold Equation3259. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff154_inst, reff154_op in H. discriminate H. Qed.

Lemma reff154_not3261 : ~ @Equation3261 Fin4 reff154_inst.
Proof. unfold Equation3261. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff154_inst, reff154_op in H. discriminate H. Qed.

Lemma reff154_not3262 : ~ @Equation3262 Fin4 reff154_inst.
Proof. unfold Equation3262. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff154_inst, reff154_op in H. discriminate H. Qed.

Lemma reff154_not3268 : ~ @Equation3268 Fin4 reff154_inst.
Proof. unfold Equation3268. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff154_inst, reff154_op in H. discriminate H. Qed.

Lemma reff154_not3269 : ~ @Equation3269 Fin4 reff154_inst.
Proof. unfold Equation3269. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff154_inst, reff154_op in H. discriminate H. Qed.

Lemma reff154_not3271 : ~ @Equation3271 Fin4 reff154_inst.
Proof. unfold Equation3271. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff154_inst, reff154_op in H. discriminate H. Qed.

Lemma reff154_not3272 : ~ @Equation3272 Fin4 reff154_inst.
Proof. unfold Equation3272. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff154_inst, reff154_op in H. discriminate H. Qed.

Lemma reff154_not3278 : ~ @Equation3278 Fin4 reff154_inst.
Proof. unfold Equation3278. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff154_inst, reff154_op in H. discriminate H. Qed.

Lemma reff154_not3279 : ~ @Equation3279 Fin4 reff154_inst.
Proof. unfold Equation3279. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff154_inst, reff154_op in H. discriminate H. Qed.

Lemma reff154_not3281 : ~ @Equation3281 Fin4 reff154_inst.
Proof. unfold Equation3281. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff154_inst, reff154_op in H. discriminate H. Qed.

Lemma reff154_not3306 : ~ @Equation3306 Fin4 reff154_inst.
Proof. unfold Equation3306. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff154_inst, reff154_op in H. discriminate H. Qed.

Lemma reff154_not3308 : ~ @Equation3308 Fin4 reff154_inst.
Proof. unfold Equation3308. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff154_inst, reff154_op in H. discriminate H. Qed.

Lemma reff154_not3309 : ~ @Equation3309 Fin4 reff154_inst.
Proof. unfold Equation3309. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff154_inst, reff154_op in H. discriminate H. Qed.

Lemma reff154_not3342 : ~ @Equation3342 Fin4 reff154_inst.
Proof. unfold Equation3342. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff154_inst, reff154_op in H. discriminate H. Qed.

Lemma reff154_not3343 : ~ @Equation3343 Fin4 reff154_inst.
Proof. unfold Equation3343. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff154_inst, reff154_op in H. discriminate H. Qed.

Lemma reff154_not3345 : ~ @Equation3345 Fin4 reff154_inst.
Proof. unfold Equation3345. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff154_inst, reff154_op in H. discriminate H. Qed.

Lemma reff154_not3346 : ~ @Equation3346 Fin4 reff154_inst.
Proof. unfold Equation3346. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff154_inst, reff154_op in H. discriminate H. Qed.

Lemma reff154_not3352 : ~ @Equation3352 Fin4 reff154_inst.
Proof. unfold Equation3352. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff154_inst, reff154_op in H. discriminate H. Qed.

Lemma reff154_not3353 : ~ @Equation3353 Fin4 reff154_inst.
Proof. unfold Equation3353. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff154_inst, reff154_op in H. discriminate H. Qed.

Lemma reff154_not3461 : ~ @Equation3461 Fin4 reff154_inst.
Proof. unfold Equation3461. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff154_inst, reff154_op in H. discriminate H. Qed.

Lemma reff154_not3462 : ~ @Equation3462 Fin4 reff154_inst.
Proof. unfold Equation3462. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff154_inst, reff154_op in H. discriminate H. Qed.

Lemma reff154_not3464 : ~ @Equation3464 Fin4 reff154_inst.
Proof. unfold Equation3464. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff154_inst, reff154_op in H. discriminate H. Qed.

Lemma reff154_not3465 : ~ @Equation3465 Fin4 reff154_inst.
Proof. unfold Equation3465. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff154_inst, reff154_op in H. discriminate H. Qed.

Lemma reff154_not3472 : ~ @Equation3472 Fin4 reff154_inst.
Proof. unfold Equation3472. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff154_inst, reff154_op in H. discriminate H. Qed.

Lemma reff154_not3474 : ~ @Equation3474 Fin4 reff154_inst.
Proof. unfold Equation3474. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff154_inst, reff154_op in H. discriminate H. Qed.

Lemma reff154_not3475 : ~ @Equation3475 Fin4 reff154_inst.
Proof. unfold Equation3475. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff154_inst, reff154_op in H. discriminate H. Qed.

Lemma reff154_not3481 : ~ @Equation3481 Fin4 reff154_inst.
Proof. unfold Equation3481. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff154_inst, reff154_op in H. discriminate H. Qed.

Lemma reff154_not3482 : ~ @Equation3482 Fin4 reff154_inst.
Proof. unfold Equation3482. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff154_inst, reff154_op in H. discriminate H. Qed.

Lemma reff154_not3484 : ~ @Equation3484 Fin4 reff154_inst.
Proof. unfold Equation3484. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff154_inst, reff154_op in H. discriminate H. Qed.

Lemma reff154_not3509 : ~ @Equation3509 Fin4 reff154_inst.
Proof. unfold Equation3509. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff154_inst, reff154_op in H. discriminate H. Qed.

Lemma reff154_not3511 : ~ @Equation3511 Fin4 reff154_inst.
Proof. unfold Equation3511. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff154_inst, reff154_op in H. discriminate H. Qed.

Lemma reff154_not3512 : ~ @Equation3512 Fin4 reff154_inst.
Proof. unfold Equation3512. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff154_inst, reff154_op in H. discriminate H. Qed.

Lemma reff154_not3545 : ~ @Equation3545 Fin4 reff154_inst.
Proof. unfold Equation3545. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff154_inst, reff154_op in H. discriminate H. Qed.

Lemma reff154_not3546 : ~ @Equation3546 Fin4 reff154_inst.
Proof. unfold Equation3546. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff154_inst, reff154_op in H. discriminate H. Qed.

Lemma reff154_not3548 : ~ @Equation3548 Fin4 reff154_inst.
Proof. unfold Equation3548. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff154_inst, reff154_op in H. discriminate H. Qed.

Lemma reff154_not3549 : ~ @Equation3549 Fin4 reff154_inst.
Proof. unfold Equation3549. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff154_inst, reff154_op in H. discriminate H. Qed.

Lemma reff154_not3555 : ~ @Equation3555 Fin4 reff154_inst.
Proof. unfold Equation3555. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff154_inst, reff154_op in H. discriminate H. Qed.

Lemma reff154_not3556 : ~ @Equation3556 Fin4 reff154_inst.
Proof. unfold Equation3556. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff154_inst, reff154_op in H. discriminate H. Qed.

Lemma reff154_not3558 : ~ @Equation3558 Fin4 reff154_inst.
Proof. unfold Equation3558. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff154_inst, reff154_op in H. discriminate H. Qed.

Lemma reff154_not3661 : ~ @Equation3661 Fin4 reff154_inst.
Proof. unfold Equation3661. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff154_inst, reff154_op in H. discriminate H. Qed.

Lemma reff154_not3662 : ~ @Equation3662 Fin4 reff154_inst.
Proof. unfold Equation3662. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff154_inst, reff154_op in H. discriminate H. Qed.

Lemma reff154_not3667 : ~ @Equation3667 Fin4 reff154_inst.
Proof. unfold Equation3667. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff154_inst, reff154_op in H. discriminate H. Qed.

Lemma reff154_not3668 : ~ @Equation3668 Fin4 reff154_inst.
Proof. unfold Equation3668. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff154_inst, reff154_op in H. discriminate H. Qed.

Lemma reff154_not3674 : ~ @Equation3674 Fin4 reff154_inst.
Proof. unfold Equation3674. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff154_inst, reff154_op in H. discriminate H. Qed.

Lemma reff154_not3675 : ~ @Equation3675 Fin4 reff154_inst.
Proof. unfold Equation3675. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff154_inst, reff154_op in H. discriminate H. Qed.

Lemma reff154_not3677 : ~ @Equation3677 Fin4 reff154_inst.
Proof. unfold Equation3677. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff154_inst, reff154_op in H. discriminate H. Qed.

Lemma reff154_not3678 : ~ @Equation3678 Fin4 reff154_inst.
Proof. unfold Equation3678. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff154_inst, reff154_op in H. discriminate H. Qed.

Lemma reff154_not3684 : ~ @Equation3684 Fin4 reff154_inst.
Proof. unfold Equation3684. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff154_inst, reff154_op in H. discriminate H. Qed.

Lemma reff154_not3685 : ~ @Equation3685 Fin4 reff154_inst.
Proof. unfold Equation3685. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff154_inst, reff154_op in H. discriminate H. Qed.

Lemma reff154_not3687 : ~ @Equation3687 Fin4 reff154_inst.
Proof. unfold Equation3687. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff154_inst, reff154_op in H. discriminate H. Qed.

Lemma reff154_not3712 : ~ @Equation3712 Fin4 reff154_inst.
Proof. unfold Equation3712. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff154_inst, reff154_op in H. discriminate H. Qed.

Lemma reff154_not3721 : ~ @Equation3721 Fin4 reff154_inst.
Proof. unfold Equation3721. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff154_inst, reff154_op in H. discriminate H. Qed.

Lemma reff154_not3722 : ~ @Equation3722 Fin4 reff154_inst.
Proof. unfold Equation3722. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff154_inst, reff154_op in H. discriminate H. Qed.

Lemma reff154_not3748 : ~ @Equation3748 Fin4 reff154_inst.
Proof. unfold Equation3748. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff154_inst, reff154_op in H. discriminate H. Qed.

Lemma reff154_not3749 : ~ @Equation3749 Fin4 reff154_inst.
Proof. unfold Equation3749. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff154_inst, reff154_op in H. discriminate H. Qed.

Lemma reff154_not3751 : ~ @Equation3751 Fin4 reff154_inst.
Proof. unfold Equation3751. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff154_inst, reff154_op in H. discriminate H. Qed.

Lemma reff154_not3752 : ~ @Equation3752 Fin4 reff154_inst.
Proof. unfold Equation3752. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff154_inst, reff154_op in H. discriminate H. Qed.

Lemma reff154_not3758 : ~ @Equation3758 Fin4 reff154_inst.
Proof. unfold Equation3758. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff154_inst, reff154_op in H. discriminate H. Qed.

Lemma reff154_not3759 : ~ @Equation3759 Fin4 reff154_inst.
Proof. unfold Equation3759. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff154_inst, reff154_op in H. discriminate H. Qed.

Lemma reff154_not3761 : ~ @Equation3761 Fin4 reff154_inst.
Proof. unfold Equation3761. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff154_inst, reff154_op in H. discriminate H. Qed.

Lemma reff154_not3865 : ~ @Equation3865 Fin4 reff154_inst.
Proof. unfold Equation3865. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff154_inst, reff154_op in H. discriminate H. Qed.

Lemma reff154_not3868 : ~ @Equation3868 Fin4 reff154_inst.
Proof. unfold Equation3868. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff154_inst, reff154_op in H. discriminate H. Qed.

Lemma reff154_not3871 : ~ @Equation3871 Fin4 reff154_inst.
Proof. unfold Equation3871. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff154_inst, reff154_op in H. discriminate H. Qed.

Lemma reff154_not3877 : ~ @Equation3877 Fin4 reff154_inst.
Proof. unfold Equation3877. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff154_inst, reff154_op in H. discriminate H. Qed.

Lemma reff154_not3878 : ~ @Equation3878 Fin4 reff154_inst.
Proof. unfold Equation3878. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff154_inst, reff154_op in H. discriminate H. Qed.

Lemma reff154_not3880 : ~ @Equation3880 Fin4 reff154_inst.
Proof. unfold Equation3880. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff154_inst, reff154_op in H. discriminate H. Qed.

Lemma reff154_not3881 : ~ @Equation3881 Fin4 reff154_inst.
Proof. unfold Equation3881. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff154_inst, reff154_op in H. discriminate H. Qed.

Lemma reff154_not3887 : ~ @Equation3887 Fin4 reff154_inst.
Proof. unfold Equation3887. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff154_inst, reff154_op in H. discriminate H. Qed.

Lemma reff154_not3888 : ~ @Equation3888 Fin4 reff154_inst.
Proof. unfold Equation3888. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff154_inst, reff154_op in H. discriminate H. Qed.

Lemma reff154_not3890 : ~ @Equation3890 Fin4 reff154_inst.
Proof. unfold Equation3890. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff154_inst, reff154_op in H. discriminate H. Qed.

Lemma reff154_not3917 : ~ @Equation3917 Fin4 reff154_inst.
Proof. unfold Equation3917. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff154_inst, reff154_op in H. discriminate H. Qed.

Lemma reff154_not3924 : ~ @Equation3924 Fin4 reff154_inst.
Proof. unfold Equation3924. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff154_inst, reff154_op in H. discriminate H. Qed.

Lemma reff154_not3927 : ~ @Equation3927 Fin4 reff154_inst.
Proof. unfold Equation3927. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff154_inst, reff154_op in H. discriminate H. Qed.

Lemma reff154_not3951 : ~ @Equation3951 Fin4 reff154_inst.
Proof. unfold Equation3951. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff154_inst, reff154_op in H. discriminate H. Qed.

Lemma reff154_not3952 : ~ @Equation3952 Fin4 reff154_inst.
Proof. unfold Equation3952. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff154_inst, reff154_op in H. discriminate H. Qed.

Lemma reff154_not3954 : ~ @Equation3954 Fin4 reff154_inst.
Proof. unfold Equation3954. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff154_inst, reff154_op in H. discriminate H. Qed.

Lemma reff154_not3955 : ~ @Equation3955 Fin4 reff154_inst.
Proof. unfold Equation3955. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff154_inst, reff154_op in H. discriminate H. Qed.

Lemma reff154_not3961 : ~ @Equation3961 Fin4 reff154_inst.
Proof. unfold Equation3961. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff154_inst, reff154_op in H. discriminate H. Qed.

Lemma reff154_not3962 : ~ @Equation3962 Fin4 reff154_inst.
Proof. unfold Equation3962. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff154_inst, reff154_op in H. discriminate H. Qed.

Lemma reff154_not3964 : ~ @Equation3964 Fin4 reff154_inst.
Proof. unfold Equation3964. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff154_inst, reff154_op in H. discriminate H. Qed.

Lemma reff154_not4066 : ~ @Equation4066 Fin4 reff154_inst.
Proof. unfold Equation4066. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff154_inst, reff154_op in H. discriminate H. Qed.

Lemma reff154_not4068 : ~ @Equation4068 Fin4 reff154_inst.
Proof. unfold Equation4068. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff154_inst, reff154_op in H. discriminate H. Qed.

Lemma reff154_not4071 : ~ @Equation4071 Fin4 reff154_inst.
Proof. unfold Equation4071. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff154_inst, reff154_op in H. discriminate H. Qed.

Lemma reff154_not4074 : ~ @Equation4074 Fin4 reff154_inst.
Proof. unfold Equation4074. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff154_inst, reff154_op in H. discriminate H. Qed.

Lemma reff154_not4080 : ~ @Equation4080 Fin4 reff154_inst.
Proof. unfold Equation4080. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff154_inst, reff154_op in H. discriminate H. Qed.

Lemma reff154_not4081 : ~ @Equation4081 Fin4 reff154_inst.
Proof. unfold Equation4081. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff154_inst, reff154_op in H. discriminate H. Qed.

Lemma reff154_not4083 : ~ @Equation4083 Fin4 reff154_inst.
Proof. unfold Equation4083. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff154_inst, reff154_op in H. discriminate H. Qed.

Lemma reff154_not4084 : ~ @Equation4084 Fin4 reff154_inst.
Proof. unfold Equation4084. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff154_inst, reff154_op in H. discriminate H. Qed.

Lemma reff154_not4090 : ~ @Equation4090 Fin4 reff154_inst.
Proof. unfold Equation4090. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff154_inst, reff154_op in H. discriminate H. Qed.

Lemma reff154_not4091 : ~ @Equation4091 Fin4 reff154_inst.
Proof. unfold Equation4091. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff154_inst, reff154_op in H. discriminate H. Qed.

Lemma reff154_not4093 : ~ @Equation4093 Fin4 reff154_inst.
Proof. unfold Equation4093. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff154_inst, reff154_op in H. discriminate H. Qed.

Lemma reff154_not4120 : ~ @Equation4120 Fin4 reff154_inst.
Proof. unfold Equation4120. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff154_inst, reff154_op in H. discriminate H. Qed.

Lemma reff154_not4127 : ~ @Equation4127 Fin4 reff154_inst.
Proof. unfold Equation4127. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff154_inst, reff154_op in H. discriminate H. Qed.

Lemma reff154_not4130 : ~ @Equation4130 Fin4 reff154_inst.
Proof. unfold Equation4130. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff154_inst, reff154_op in H. discriminate H. Qed.

Lemma reff154_not4155 : ~ @Equation4155 Fin4 reff154_inst.
Proof. unfold Equation4155. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff154_inst, reff154_op in H. discriminate H. Qed.

Lemma reff154_not4157 : ~ @Equation4157 Fin4 reff154_inst.
Proof. unfold Equation4157. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff154_inst, reff154_op in H. discriminate H. Qed.

Lemma reff154_not4158 : ~ @Equation4158 Fin4 reff154_inst.
Proof. unfold Equation4158. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff154_inst, reff154_op in H. discriminate H. Qed.

Lemma reff154_not4164 : ~ @Equation4164 Fin4 reff154_inst.
Proof. unfold Equation4164. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff154_inst, reff154_op in H. discriminate H. Qed.

Lemma reff154_not4165 : ~ @Equation4165 Fin4 reff154_inst.
Proof. unfold Equation4165. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff154_inst, reff154_op in H. discriminate H. Qed.

Lemma reff154_not4167 : ~ @Equation4167 Fin4 reff154_inst.
Proof. unfold Equation4167. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff154_inst, reff154_op in H. discriminate H. Qed.

Lemma reff154_not4269 : ~ @Equation4269 Fin4 reff154_inst.
Proof. unfold Equation4269. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff154_inst, reff154_op in H. discriminate H. Qed.

Lemma reff154_not4270 : ~ @Equation4270 Fin4 reff154_inst.
Proof. unfold Equation4270. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff154_inst, reff154_op in H. discriminate H. Qed.

Lemma reff154_not4272 : ~ @Equation4272 Fin4 reff154_inst.
Proof. unfold Equation4272. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff154_inst, reff154_op in H. discriminate H. Qed.

Lemma reff154_not4273 : ~ @Equation4273 Fin4 reff154_inst.
Proof. unfold Equation4273. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff154_inst, reff154_op in H. discriminate H. Qed.

Lemma reff154_not4275 : ~ @Equation4275 Fin4 reff154_inst.
Proof. unfold Equation4275. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff154_inst, reff154_op in H. discriminate H. Qed.

Lemma reff154_not4276 : ~ @Equation4276 Fin4 reff154_inst.
Proof. unfold Equation4276. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff154_inst, reff154_op in H. discriminate H. Qed.

Lemma reff154_not4283 : ~ @Equation4283 Fin4 reff154_inst.
Proof. unfold Equation4283. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff154_inst, reff154_op in H. discriminate H. Qed.

Lemma reff154_not4284 : ~ @Equation4284 Fin4 reff154_inst.
Proof. unfold Equation4284. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff154_inst, reff154_op in H. discriminate H. Qed.

Lemma reff154_not4290 : ~ @Equation4290 Fin4 reff154_inst.
Proof. unfold Equation4290. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff154_inst, reff154_op in H. discriminate H. Qed.

Lemma reff154_not4291 : ~ @Equation4291 Fin4 reff154_inst.
Proof. unfold Equation4291. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff154_inst, reff154_op in H. discriminate H. Qed.

Lemma reff154_not4293 : ~ @Equation4293 Fin4 reff154_inst.
Proof. unfold Equation4293. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff154_inst, reff154_op in H. discriminate H. Qed.

Lemma reff154_not4320 : ~ @Equation4320 Fin4 reff154_inst.
Proof. unfold Equation4320. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff154_inst, reff154_op in H. discriminate H. Qed.

Lemma reff154_not4321 : ~ @Equation4321 Fin4 reff154_inst.
Proof. unfold Equation4321. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff154_inst, reff154_op in H. discriminate H. Qed.

Lemma reff154_not4343 : ~ @Equation4343 Fin4 reff154_inst.
Proof. unfold Equation4343. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff154_inst, reff154_op in H. discriminate H. Qed.

Lemma reff154_not4396 : ~ @Equation4396 Fin4 reff154_inst.
Proof. unfold Equation4396. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff154_inst, reff154_op in H. discriminate H. Qed.

Lemma reff154_not4399 : ~ @Equation4399 Fin4 reff154_inst.
Proof. unfold Equation4399. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff154_inst, reff154_op in H. discriminate H. Qed.

Lemma reff154_not4405 : ~ @Equation4405 Fin4 reff154_inst.
Proof. unfold Equation4405. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff154_inst, reff154_op in H. discriminate H. Qed.

Lemma reff154_not4406 : ~ @Equation4406 Fin4 reff154_inst.
Proof. unfold Equation4406. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff154_inst, reff154_op in H. discriminate H. Qed.

Lemma reff154_not4408 : ~ @Equation4408 Fin4 reff154_inst.
Proof. unfold Equation4408. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff154_inst, reff154_op in H. discriminate H. Qed.

Lemma reff154_not4435 : ~ @Equation4435 Fin4 reff154_inst.
Proof. unfold Equation4435. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff154_inst, reff154_op in H. discriminate H. Qed.

Lemma reff154_not4442 : ~ @Equation4442 Fin4 reff154_inst.
Proof. unfold Equation4442. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff154_inst, reff154_op in H. discriminate H. Qed.

Lemma reff154_not4443 : ~ @Equation4443 Fin4 reff154_inst.
Proof. unfold Equation4443. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff154_inst, reff154_op in H. discriminate H. Qed.

Lemma reff154_not4445 : ~ @Equation4445 Fin4 reff154_inst.
Proof. unfold Equation4445. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff154_inst, reff154_op in H. discriminate H. Qed.

Lemma reff154_not4472 : ~ @Equation4472 Fin4 reff154_inst.
Proof. unfold Equation4472. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff154_inst, reff154_op in H. discriminate H. Qed.

Lemma reff154_not4479 : ~ @Equation4479 Fin4 reff154_inst.
Proof. unfold Equation4479. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff154_inst, reff154_op in H. discriminate H. Qed.

Lemma reff154_not4480 : ~ @Equation4480 Fin4 reff154_inst.
Proof. unfold Equation4480. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff154_inst, reff154_op in H. discriminate H. Qed.

Lemma reff154_not4482 : ~ @Equation4482 Fin4 reff154_inst.
Proof. unfold Equation4482. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff154_inst, reff154_op in H. discriminate H. Qed.

Lemma reff154_not4583 : ~ @Equation4583 Fin4 reff154_inst.
Proof. unfold Equation4583. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff154_inst, reff154_op in H. discriminate H. Qed.

Lemma reff154_not4585 : ~ @Equation4585 Fin4 reff154_inst.
Proof. unfold Equation4585. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff154_inst, reff154_op in H. discriminate H. Qed.

Lemma reff154_not4587 : ~ @Equation4587 Fin4 reff154_inst.
Proof. unfold Equation4587. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff154_inst, reff154_op in H. discriminate H. Qed.

Lemma reff154_not4588 : ~ @Equation4588 Fin4 reff154_inst.
Proof. unfold Equation4588. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff154_inst, reff154_op in H. discriminate H. Qed.

Lemma reff154_not4590 : ~ @Equation4590 Fin4 reff154_inst.
Proof. unfold Equation4590. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff154_inst, reff154_op in H. discriminate H. Qed.

Lemma reff154_not4591 : ~ @Equation4591 Fin4 reff154_inst.
Proof. unfold Equation4591. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff154_inst, reff154_op in H. discriminate H. Qed.

Lemma reff154_not4598 : ~ @Equation4598 Fin4 reff154_inst.
Proof. unfold Equation4598. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff154_inst, reff154_op in H. discriminate H. Qed.

Lemma reff154_not4605 : ~ @Equation4605 Fin4 reff154_inst.
Proof. unfold Equation4605. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff154_inst, reff154_op in H. discriminate H. Qed.

Lemma reff154_not4606 : ~ @Equation4606 Fin4 reff154_inst.
Proof. unfold Equation4606. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff154_inst, reff154_op in H. discriminate H. Qed.

Lemma reff154_not4608 : ~ @Equation4608 Fin4 reff154_inst.
Proof. unfold Equation4608. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff154_inst, reff154_op in H. discriminate H. Qed.

Lemma reff154_not4629 : ~ @Equation4629 Fin4 reff154_inst.
Proof. unfold Equation4629. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff154_inst, reff154_op in H. discriminate H. Qed.

Lemma reff154_not4635 : ~ @Equation4635 Fin4 reff154_inst.
Proof. unfold Equation4635. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff154_inst, reff154_op in H. discriminate H. Qed.

Lemma reff154_not4636 : ~ @Equation4636 Fin4 reff154_inst.
Proof. unfold Equation4636. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff154_inst, reff154_op in H. discriminate H. Qed.

Lemma reff154_not4658 : ~ @Equation4658 Fin4 reff154_inst.
Proof. unfold Equation4658. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff154_inst, reff154_op in H. discriminate H. Qed.

(** ---- reff172 (Fin4) ---- *)

Definition reff172_op (x y : Fin4) : Fin4 :=
  match x, y with
  | F4_0, F4_0 => F4_0 | F4_0, F4_1 => F4_1 | F4_0, F4_2 => F4_2 | F4_0, F4_3 => F4_3
  | F4_1, F4_0 => F4_2 | F4_1, F4_1 => F4_1 | F4_1, F4_2 => F4_0 | F4_1, F4_3 => F4_3
  | F4_2, F4_0 => F4_2 | F4_2, F4_1 => F4_3 | F4_2, F4_2 => F4_0 | F4_2, F4_3 => F4_1
  | F4_3, F4_0 => F4_0 | F4_3, F4_1 => F4_3 | F4_3, F4_2 => F4_2 | F4_3, F4_3 => F4_1
  end.

#[local] Instance reff172_inst : Magma Fin4 := {| magma_op := reff172_op |}.

Lemma reff172_sat16 : @Equation16 Fin4 reff172_inst.
Proof. unfold Equation16, magma_op, reff172_inst, reff172_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff172_sat23 : @Equation23 Fin4 reff172_inst.
Proof. unfold Equation23, magma_op, reff172_inst, reff172_op. intros x. destruct x; reflexivity. Qed.

Lemma reff172_sat562 : @Equation562 Fin4 reff172_inst.
Proof. unfold Equation562, magma_op, reff172_inst, reff172_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff172_sat639 : @Equation639 Fin4 reff172_inst.
Proof. unfold Equation639, magma_op, reff172_inst, reff172_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff172_sat676 : @Equation676 Fin4 reff172_inst.
Proof. unfold Equation676, magma_op, reff172_inst, reff172_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff172_sat703 : @Equation703 Fin4 reff172_inst.
Proof. unfold Equation703, magma_op, reff172_inst, reff172_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff172_sat835 : @Equation835 Fin4 reff172_inst.
Proof. unfold Equation835, magma_op, reff172_inst, reff172_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff172_sat872 : @Equation872 Fin4 reff172_inst.
Proof. unfold Equation872, magma_op, reff172_inst, reff172_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff172_sat906 : @Equation906 Fin4 reff172_inst.
Proof. unfold Equation906, magma_op, reff172_inst, reff172_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff172_sat1082 : @Equation1082 Fin4 reff172_inst.
Proof. unfold Equation1082, magma_op, reff172_inst, reff172_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff172_sat1109 : @Equation1109 Fin4 reff172_inst.
Proof. unfold Equation1109, magma_op, reff172_inst, reff172_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff172_sat1312 : @Equation1312 Fin4 reff172_inst.
Proof. unfold Equation1312, magma_op, reff172_inst, reff172_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff172_sat1325 : @Equation1325 Fin4 reff172_inst.
Proof. unfold Equation1325, magma_op, reff172_inst, reff172_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff172_sat1434 : @Equation1434 Fin4 reff172_inst.
Proof. unfold Equation1434, magma_op, reff172_inst, reff172_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff172_sat1481 : @Equation1481 Fin4 reff172_inst.
Proof. unfold Equation1481, magma_op, reff172_inst, reff172_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff172_sat1488 : @Equation1488 Fin4 reff172_inst.
Proof. unfold Equation1488, magma_op, reff172_inst, reff172_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff172_sat1850 : @Equation1850 Fin4 reff172_inst.
Proof. unfold Equation1850, magma_op, reff172_inst, reff172_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff172_sat1887 : @Equation1887 Fin4 reff172_inst.
Proof. unfold Equation1887, magma_op, reff172_inst, reff172_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff172_sat2090 : @Equation2090 Fin4 reff172_inst.
Proof. unfold Equation2090, magma_op, reff172_inst, reff172_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff172_sat2137 : @Equation2137 Fin4 reff172_inst.
Proof. unfold Equation2137, magma_op, reff172_inst, reff172_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff172_sat2263 : @Equation2263 Fin4 reff172_inst.
Proof. unfold Equation2263, magma_op, reff172_inst, reff172_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff172_sat2300 : @Equation2300 Fin4 reff172_inst.
Proof. unfold Equation2300, magma_op, reff172_inst, reff172_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff172_sat2327 : @Equation2327 Fin4 reff172_inst.
Proof. unfold Equation2327, magma_op, reff172_inst, reff172_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff172_sat2459 : @Equation2459 Fin4 reff172_inst.
Proof. unfold Equation2459, magma_op, reff172_inst, reff172_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff172_sat2530 : @Equation2530 Fin4 reff172_inst.
Proof. unfold Equation2530, magma_op, reff172_inst, reff172_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff172_sat2699 : @Equation2699 Fin4 reff172_inst.
Proof. unfold Equation2699, magma_op, reff172_inst, reff172_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff172_sat2706 : @Equation2706 Fin4 reff172_inst.
Proof. unfold Equation2706, magma_op, reff172_inst, reff172_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff172_sat2936 : @Equation2936 Fin4 reff172_inst.
Proof. unfold Equation2936, magma_op, reff172_inst, reff172_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff172_sat3068 : @Equation3068 Fin4 reff172_inst.
Proof. unfold Equation3068, magma_op, reff172_inst, reff172_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff172_sat3388 : @Equation3388 Fin4 reff172_inst.
Proof. unfold Equation3388, magma_op, reff172_inst, reff172_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff172_sat3481 : @Equation3481 Fin4 reff172_inst.
Proof. unfold Equation3481, magma_op, reff172_inst, reff172_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff172_sat3549 : @Equation3549 Fin4 reff172_inst.
Proof. unfold Equation3549, magma_op, reff172_inst, reff172_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff172_sat3677 : @Equation3677 Fin4 reff172_inst.
Proof. unfold Equation3677, magma_op, reff172_inst, reff172_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff172_sat3725 : @Equation3725 Fin4 reff172_inst.
Proof. unfold Equation3725, magma_op, reff172_inst, reff172_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff172_sat3759 : @Equation3759 Fin4 reff172_inst.
Proof. unfold Equation3759, magma_op, reff172_inst, reff172_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff172_sat3928 : @Equation3928 Fin4 reff172_inst.
Proof. unfold Equation3928, magma_op, reff172_inst, reff172_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff172_sat3955 : @Equation3955 Fin4 reff172_inst.
Proof. unfold Equation3955, magma_op, reff172_inst, reff172_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff172_sat4362 : @Equation4362 Fin4 reff172_inst.
Proof. unfold Equation4362, magma_op, reff172_inst, reff172_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff172_sat4409 : @Equation4409 Fin4 reff172_inst.
Proof. unfold Equation4409, magma_op, reff172_inst, reff172_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff172_sat4442 : @Equation4442 Fin4 reff172_inst.
Proof. unfold Equation4442, magma_op, reff172_inst, reff172_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff172_sat4473 : @Equation4473 Fin4 reff172_inst.
Proof. unfold Equation4473, magma_op, reff172_inst, reff172_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff172_not47 : ~ @Equation47 Fin4 reff172_inst.
Proof. unfold Equation47. intro H. specialize (H F4_2). unfold magma_op, reff172_inst, reff172_op in H. discriminate H. Qed.

Lemma reff172_not99 : ~ @Equation99 Fin4 reff172_inst.
Proof. unfold Equation99. intro H. specialize (H F4_2). unfold magma_op, reff172_inst, reff172_op in H. discriminate H. Qed.

Lemma reff172_not151 : ~ @Equation151 Fin4 reff172_inst.
Proof. unfold Equation151. intro H. specialize (H F4_2). unfold magma_op, reff172_inst, reff172_op in H. discriminate H. Qed.

Lemma reff172_not203 : ~ @Equation203 Fin4 reff172_inst.
Proof. unfold Equation203. intro H. specialize (H F4_2). unfold magma_op, reff172_inst, reff172_op in H. discriminate H. Qed.

Lemma reff172_not255 : ~ @Equation255 Fin4 reff172_inst.
Proof. unfold Equation255. intro H. specialize (H F4_2). unfold magma_op, reff172_inst, reff172_op in H. discriminate H. Qed.

Lemma reff172_not307 : ~ @Equation307 Fin4 reff172_inst.
Proof. unfold Equation307. intro H. specialize (H F4_2). unfold magma_op, reff172_inst, reff172_op in H. discriminate H. Qed.

Lemma reff172_not359 : ~ @Equation359 Fin4 reff172_inst.
Proof. unfold Equation359. intro H. specialize (H F4_2). unfold magma_op, reff172_inst, reff172_op in H. discriminate H. Qed.

Lemma reff172_not412 : ~ @Equation412 Fin4 reff172_inst.
Proof. unfold Equation412. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff172_inst, reff172_op in H. discriminate H. Qed.

Lemma reff172_not413 : ~ @Equation413 Fin4 reff172_inst.
Proof. unfold Equation413. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff172_inst, reff172_op in H. discriminate H. Qed.

Lemma reff172_not414 : ~ @Equation414 Fin4 reff172_inst.
Proof. unfold Equation414. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff172_inst, reff172_op in H. discriminate H. Qed.

Lemma reff172_not416 : ~ @Equation416 Fin4 reff172_inst.
Proof. unfold Equation416. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff172_inst, reff172_op in H. discriminate H. Qed.

Lemma reff172_not417 : ~ @Equation417 Fin4 reff172_inst.
Proof. unfold Equation417. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff172_inst, reff172_op in H. discriminate H. Qed.

Lemma reff172_not420 : ~ @Equation420 Fin4 reff172_inst.
Proof. unfold Equation420. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff172_inst, reff172_op in H. discriminate H. Qed.

Lemma reff172_not426 : ~ @Equation426 Fin4 reff172_inst.
Proof. unfold Equation426. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff172_inst, reff172_op in H. discriminate H. Qed.

Lemma reff172_not427 : ~ @Equation427 Fin4 reff172_inst.
Proof. unfold Equation427. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff172_inst, reff172_op in H. discriminate H. Qed.

Lemma reff172_not430 : ~ @Equation430 Fin4 reff172_inst.
Proof. unfold Equation430. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff172_inst, reff172_op in H. discriminate H. Qed.

Lemma reff172_not437 : ~ @Equation437 Fin4 reff172_inst.
Proof. unfold Equation437. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff172_inst, reff172_op in H. discriminate H. Qed.

Lemma reff172_not439 : ~ @Equation439 Fin4 reff172_inst.
Proof. unfold Equation439. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff172_inst, reff172_op in H. discriminate H. Qed.

Lemma reff172_not440 : ~ @Equation440 Fin4 reff172_inst.
Proof. unfold Equation440. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff172_inst, reff172_op in H. discriminate H. Qed.

Lemma reff172_not463 : ~ @Equation463 Fin4 reff172_inst.
Proof. unfold Equation463. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff172_inst, reff172_op in H. discriminate H. Qed.

Lemma reff172_not464 : ~ @Equation464 Fin4 reff172_inst.
Proof. unfold Equation464. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff172_inst, reff172_op in H. discriminate H. Qed.

Lemma reff172_not467 : ~ @Equation467 Fin4 reff172_inst.
Proof. unfold Equation467. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff172_inst, reff172_op in H. discriminate H. Qed.

Lemma reff172_not474 : ~ @Equation474 Fin4 reff172_inst.
Proof. unfold Equation474. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff172_inst, reff172_op in H. discriminate H. Qed.

Lemma reff172_not476 : ~ @Equation476 Fin4 reff172_inst.
Proof. unfold Equation476. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff172_inst, reff172_op in H. discriminate H. Qed.

Lemma reff172_not477 : ~ @Equation477 Fin4 reff172_inst.
Proof. unfold Equation477. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff172_inst, reff172_op in H. discriminate H. Qed.

Lemma reff172_not501 : ~ @Equation501 Fin4 reff172_inst.
Proof. unfold Equation501. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff172_inst, reff172_op in H. discriminate H. Qed.

Lemma reff172_not503 : ~ @Equation503 Fin4 reff172_inst.
Proof. unfold Equation503. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff172_inst, reff172_op in H. discriminate H. Qed.

Lemma reff172_not504 : ~ @Equation504 Fin4 reff172_inst.
Proof. unfold Equation504. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff172_inst, reff172_op in H. discriminate H. Qed.

Lemma reff172_not510 : ~ @Equation510 Fin4 reff172_inst.
Proof. unfold Equation510. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff172_inst, reff172_op in H. discriminate H. Qed.

Lemma reff172_not511 : ~ @Equation511 Fin4 reff172_inst.
Proof. unfold Equation511. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff172_inst, reff172_op in H. discriminate H. Qed.

Lemma reff172_not615 : ~ @Equation615 Fin4 reff172_inst.
Proof. unfold Equation615. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff172_inst, reff172_op in H. discriminate H. Qed.

Lemma reff172_not616 : ~ @Equation616 Fin4 reff172_inst.
Proof. unfold Equation616. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff172_inst, reff172_op in H. discriminate H. Qed.

Lemma reff172_not617 : ~ @Equation617 Fin4 reff172_inst.
Proof. unfold Equation617. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff172_inst, reff172_op in H. discriminate H. Qed.

Lemma reff172_not619 : ~ @Equation619 Fin4 reff172_inst.
Proof. unfold Equation619. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff172_inst, reff172_op in H. discriminate H. Qed.

Lemma reff172_not620 : ~ @Equation620 Fin4 reff172_inst.
Proof. unfold Equation620. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff172_inst, reff172_op in H. discriminate H. Qed.

Lemma reff172_not622 : ~ @Equation622 Fin4 reff172_inst.
Proof. unfold Equation622. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff172_inst, reff172_op in H. discriminate H. Qed.

Lemma reff172_not623 : ~ @Equation623 Fin4 reff172_inst.
Proof. unfold Equation623. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff172_inst, reff172_op in H. discriminate H. Qed.

Lemma reff172_not629 : ~ @Equation629 Fin4 reff172_inst.
Proof. unfold Equation629. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff172_inst, reff172_op in H. discriminate H. Qed.

Lemma reff172_not630 : ~ @Equation630 Fin4 reff172_inst.
Proof. unfold Equation630. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff172_inst, reff172_op in H. discriminate H. Qed.

Lemma reff172_not632 : ~ @Equation632 Fin4 reff172_inst.
Proof. unfold Equation632. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff172_inst, reff172_op in H. discriminate H. Qed.

Lemma reff172_not633 : ~ @Equation633 Fin4 reff172_inst.
Proof. unfold Equation633. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff172_inst, reff172_op in H. discriminate H. Qed.

Lemma reff172_not640 : ~ @Equation640 Fin4 reff172_inst.
Proof. unfold Equation640. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff172_inst, reff172_op in H. discriminate H. Qed.

Lemma reff172_not642 : ~ @Equation642 Fin4 reff172_inst.
Proof. unfold Equation642. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff172_inst, reff172_op in H. discriminate H. Qed.

Lemma reff172_not643 : ~ @Equation643 Fin4 reff172_inst.
Proof. unfold Equation643. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff172_inst, reff172_op in H. discriminate H. Qed.

Lemma reff172_not666 : ~ @Equation666 Fin4 reff172_inst.
Proof. unfold Equation666. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff172_inst, reff172_op in H. discriminate H. Qed.

Lemma reff172_not667 : ~ @Equation667 Fin4 reff172_inst.
Proof. unfold Equation667. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff172_inst, reff172_op in H. discriminate H. Qed.

Lemma reff172_not669 : ~ @Equation669 Fin4 reff172_inst.
Proof. unfold Equation669. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff172_inst, reff172_op in H. discriminate H. Qed.

Lemma reff172_not670 : ~ @Equation670 Fin4 reff172_inst.
Proof. unfold Equation670. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff172_inst, reff172_op in H. discriminate H. Qed.

Lemma reff172_not677 : ~ @Equation677 Fin4 reff172_inst.
Proof. unfold Equation677. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff172_inst, reff172_op in H. discriminate H. Qed.

Lemma reff172_not679 : ~ @Equation679 Fin4 reff172_inst.
Proof. unfold Equation679. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff172_inst, reff172_op in H. discriminate H. Qed.

Lemma reff172_not680 : ~ @Equation680 Fin4 reff172_inst.
Proof. unfold Equation680. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff172_inst, reff172_op in H. discriminate H. Qed.

Lemma reff172_not704 : ~ @Equation704 Fin4 reff172_inst.
Proof. unfold Equation704. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff172_inst, reff172_op in H. discriminate H. Qed.

Lemma reff172_not706 : ~ @Equation706 Fin4 reff172_inst.
Proof. unfold Equation706. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff172_inst, reff172_op in H. discriminate H. Qed.

Lemma reff172_not707 : ~ @Equation707 Fin4 reff172_inst.
Proof. unfold Equation707. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff172_inst, reff172_op in H. discriminate H. Qed.

Lemma reff172_not713 : ~ @Equation713 Fin4 reff172_inst.
Proof. unfold Equation713. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff172_inst, reff172_op in H. discriminate H. Qed.

Lemma reff172_not714 : ~ @Equation714 Fin4 reff172_inst.
Proof. unfold Equation714. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff172_inst, reff172_op in H. discriminate H. Qed.

Lemma reff172_not716 : ~ @Equation716 Fin4 reff172_inst.
Proof. unfold Equation716. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff172_inst, reff172_op in H. discriminate H. Qed.

Lemma reff172_not818 : ~ @Equation818 Fin4 reff172_inst.
Proof. unfold Equation818. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff172_inst, reff172_op in H. discriminate H. Qed.

Lemma reff172_not819 : ~ @Equation819 Fin4 reff172_inst.
Proof. unfold Equation819. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff172_inst, reff172_op in H. discriminate H. Qed.

Lemma reff172_not820 : ~ @Equation820 Fin4 reff172_inst.
Proof. unfold Equation820. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff172_inst, reff172_op in H. discriminate H. Qed.

Lemma reff172_not822 : ~ @Equation822 Fin4 reff172_inst.
Proof. unfold Equation822. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff172_inst, reff172_op in H. discriminate H. Qed.

Lemma reff172_not823 : ~ @Equation823 Fin4 reff172_inst.
Proof. unfold Equation823. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff172_inst, reff172_op in H. discriminate H. Qed.

Lemma reff172_not825 : ~ @Equation825 Fin4 reff172_inst.
Proof. unfold Equation825. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff172_inst, reff172_op in H. discriminate H. Qed.

Lemma reff172_not826 : ~ @Equation826 Fin4 reff172_inst.
Proof. unfold Equation826. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff172_inst, reff172_op in H. discriminate H. Qed.

Lemma reff172_not832 : ~ @Equation832 Fin4 reff172_inst.
Proof. unfold Equation832. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff172_inst, reff172_op in H. discriminate H. Qed.

Lemma reff172_not833 : ~ @Equation833 Fin4 reff172_inst.
Proof. unfold Equation833. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff172_inst, reff172_op in H. discriminate H. Qed.

Lemma reff172_not836 : ~ @Equation836 Fin4 reff172_inst.
Proof. unfold Equation836. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff172_inst, reff172_op in H. discriminate H. Qed.

Lemma reff172_not842 : ~ @Equation842 Fin4 reff172_inst.
Proof. unfold Equation842. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff172_inst, reff172_op in H. discriminate H. Qed.

Lemma reff172_not843 : ~ @Equation843 Fin4 reff172_inst.
Proof. unfold Equation843. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff172_inst, reff172_op in H. discriminate H. Qed.

Lemma reff172_not845 : ~ @Equation845 Fin4 reff172_inst.
Proof. unfold Equation845. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff172_inst, reff172_op in H. discriminate H. Qed.

Lemma reff172_not846 : ~ @Equation846 Fin4 reff172_inst.
Proof. unfold Equation846. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff172_inst, reff172_op in H. discriminate H. Qed.

Lemma reff172_not869 : ~ @Equation869 Fin4 reff172_inst.
Proof. unfold Equation869. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff172_inst, reff172_op in H. discriminate H. Qed.

Lemma reff172_not870 : ~ @Equation870 Fin4 reff172_inst.
Proof. unfold Equation870. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff172_inst, reff172_op in H. discriminate H. Qed.

Lemma reff172_not873 : ~ @Equation873 Fin4 reff172_inst.
Proof. unfold Equation873. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff172_inst, reff172_op in H. discriminate H. Qed.

Lemma reff172_not879 : ~ @Equation879 Fin4 reff172_inst.
Proof. unfold Equation879. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff172_inst, reff172_op in H. discriminate H. Qed.

Lemma reff172_not880 : ~ @Equation880 Fin4 reff172_inst.
Proof. unfold Equation880. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff172_inst, reff172_op in H. discriminate H. Qed.

Lemma reff172_not882 : ~ @Equation882 Fin4 reff172_inst.
Proof. unfold Equation882. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff172_inst, reff172_op in H. discriminate H. Qed.

Lemma reff172_not883 : ~ @Equation883 Fin4 reff172_inst.
Proof. unfold Equation883. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff172_inst, reff172_op in H. discriminate H. Qed.

Lemma reff172_not907 : ~ @Equation907 Fin4 reff172_inst.
Proof. unfold Equation907. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff172_inst, reff172_op in H. discriminate H. Qed.

Lemma reff172_not909 : ~ @Equation909 Fin4 reff172_inst.
Proof. unfold Equation909. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff172_inst, reff172_op in H. discriminate H. Qed.

Lemma reff172_not910 : ~ @Equation910 Fin4 reff172_inst.
Proof. unfold Equation910. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff172_inst, reff172_op in H. discriminate H. Qed.

Lemma reff172_not916 : ~ @Equation916 Fin4 reff172_inst.
Proof. unfold Equation916. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff172_inst, reff172_op in H. discriminate H. Qed.

Lemma reff172_not917 : ~ @Equation917 Fin4 reff172_inst.
Proof. unfold Equation917. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff172_inst, reff172_op in H. discriminate H. Qed.

Lemma reff172_not919 : ~ @Equation919 Fin4 reff172_inst.
Proof. unfold Equation919. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff172_inst, reff172_op in H. discriminate H. Qed.

Lemma reff172_not1021 : ~ @Equation1021 Fin4 reff172_inst.
Proof. unfold Equation1021. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff172_inst, reff172_op in H. discriminate H. Qed.

Lemma reff172_not1022 : ~ @Equation1022 Fin4 reff172_inst.
Proof. unfold Equation1022. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff172_inst, reff172_op in H. discriminate H. Qed.

Lemma reff172_not1023 : ~ @Equation1023 Fin4 reff172_inst.
Proof. unfold Equation1023. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff172_inst, reff172_op in H. discriminate H. Qed.

Lemma reff172_not1025 : ~ @Equation1025 Fin4 reff172_inst.
Proof. unfold Equation1025. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff172_inst, reff172_op in H. discriminate H. Qed.

Lemma reff172_not1026 : ~ @Equation1026 Fin4 reff172_inst.
Proof. unfold Equation1026. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff172_inst, reff172_op in H. discriminate H. Qed.

Lemma reff172_not1028 : ~ @Equation1028 Fin4 reff172_inst.
Proof. unfold Equation1028. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff172_inst, reff172_op in H. discriminate H. Qed.

Lemma reff172_not1029 : ~ @Equation1029 Fin4 reff172_inst.
Proof. unfold Equation1029. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff172_inst, reff172_op in H. discriminate H. Qed.

Lemma reff172_not1035 : ~ @Equation1035 Fin4 reff172_inst.
Proof. unfold Equation1035. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff172_inst, reff172_op in H. discriminate H. Qed.

Lemma reff172_not1036 : ~ @Equation1036 Fin4 reff172_inst.
Proof. unfold Equation1036. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff172_inst, reff172_op in H. discriminate H. Qed.

Lemma reff172_not1038 : ~ @Equation1038 Fin4 reff172_inst.
Proof. unfold Equation1038. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff172_inst, reff172_op in H. discriminate H. Qed.

Lemma reff172_not1039 : ~ @Equation1039 Fin4 reff172_inst.
Proof. unfold Equation1039. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff172_inst, reff172_op in H. discriminate H. Qed.

Lemma reff172_not1046 : ~ @Equation1046 Fin4 reff172_inst.
Proof. unfold Equation1046. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff172_inst, reff172_op in H. discriminate H. Qed.

Lemma reff172_not1048 : ~ @Equation1048 Fin4 reff172_inst.
Proof. unfold Equation1048. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff172_inst, reff172_op in H. discriminate H. Qed.

Lemma reff172_not1049 : ~ @Equation1049 Fin4 reff172_inst.
Proof. unfold Equation1049. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff172_inst, reff172_op in H. discriminate H. Qed.

Lemma reff172_not1072 : ~ @Equation1072 Fin4 reff172_inst.
Proof. unfold Equation1072. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff172_inst, reff172_op in H. discriminate H. Qed.

Lemma reff172_not1073 : ~ @Equation1073 Fin4 reff172_inst.
Proof. unfold Equation1073. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff172_inst, reff172_op in H. discriminate H. Qed.

Lemma reff172_not1076 : ~ @Equation1076 Fin4 reff172_inst.
Proof. unfold Equation1076. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff172_inst, reff172_op in H. discriminate H. Qed.

Lemma reff172_not1083 : ~ @Equation1083 Fin4 reff172_inst.
Proof. unfold Equation1083. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff172_inst, reff172_op in H. discriminate H. Qed.

Lemma reff172_not1085 : ~ @Equation1085 Fin4 reff172_inst.
Proof. unfold Equation1085. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff172_inst, reff172_op in H. discriminate H. Qed.

Lemma reff172_not1086 : ~ @Equation1086 Fin4 reff172_inst.
Proof. unfold Equation1086. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff172_inst, reff172_op in H. discriminate H. Qed.

Lemma reff172_not1110 : ~ @Equation1110 Fin4 reff172_inst.
Proof. unfold Equation1110. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff172_inst, reff172_op in H. discriminate H. Qed.

Lemma reff172_not1112 : ~ @Equation1112 Fin4 reff172_inst.
Proof. unfold Equation1112. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff172_inst, reff172_op in H. discriminate H. Qed.

Lemma reff172_not1113 : ~ @Equation1113 Fin4 reff172_inst.
Proof. unfold Equation1113. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff172_inst, reff172_op in H. discriminate H. Qed.

Lemma reff172_not1119 : ~ @Equation1119 Fin4 reff172_inst.
Proof. unfold Equation1119. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff172_inst, reff172_op in H. discriminate H. Qed.

Lemma reff172_not1120 : ~ @Equation1120 Fin4 reff172_inst.
Proof. unfold Equation1120. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff172_inst, reff172_op in H. discriminate H. Qed.

Lemma reff172_not1224 : ~ @Equation1224 Fin4 reff172_inst.
Proof. unfold Equation1224. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff172_inst, reff172_op in H. discriminate H. Qed.

Lemma reff172_not1225 : ~ @Equation1225 Fin4 reff172_inst.
Proof. unfold Equation1225. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff172_inst, reff172_op in H. discriminate H. Qed.

Lemma reff172_not1226 : ~ @Equation1226 Fin4 reff172_inst.
Proof. unfold Equation1226. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff172_inst, reff172_op in H. discriminate H. Qed.

Lemma reff172_not1228 : ~ @Equation1228 Fin4 reff172_inst.
Proof. unfold Equation1228. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff172_inst, reff172_op in H. discriminate H. Qed.

Lemma reff172_not1229 : ~ @Equation1229 Fin4 reff172_inst.
Proof. unfold Equation1229. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff172_inst, reff172_op in H. discriminate H. Qed.

Lemma reff172_not1231 : ~ @Equation1231 Fin4 reff172_inst.
Proof. unfold Equation1231. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff172_inst, reff172_op in H. discriminate H. Qed.

Lemma reff172_not1232 : ~ @Equation1232 Fin4 reff172_inst.
Proof. unfold Equation1232. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff172_inst, reff172_op in H. discriminate H. Qed.

Lemma reff172_not1238 : ~ @Equation1238 Fin4 reff172_inst.
Proof. unfold Equation1238. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff172_inst, reff172_op in H. discriminate H. Qed.

Lemma reff172_not1239 : ~ @Equation1239 Fin4 reff172_inst.
Proof. unfold Equation1239. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff172_inst, reff172_op in H. discriminate H. Qed.

Lemma reff172_not1241 : ~ @Equation1241 Fin4 reff172_inst.
Proof. unfold Equation1241. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff172_inst, reff172_op in H. discriminate H. Qed.

Lemma reff172_not1242 : ~ @Equation1242 Fin4 reff172_inst.
Proof. unfold Equation1242. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff172_inst, reff172_op in H. discriminate H. Qed.

Lemma reff172_not1248 : ~ @Equation1248 Fin4 reff172_inst.
Proof. unfold Equation1248. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff172_inst, reff172_op in H. discriminate H. Qed.

Lemma reff172_not1249 : ~ @Equation1249 Fin4 reff172_inst.
Proof. unfold Equation1249. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff172_inst, reff172_op in H. discriminate H. Qed.

Lemma reff172_not1251 : ~ @Equation1251 Fin4 reff172_inst.
Proof. unfold Equation1251. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff172_inst, reff172_op in H. discriminate H. Qed.

Lemma reff172_not1252 : ~ @Equation1252 Fin4 reff172_inst.
Proof. unfold Equation1252. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff172_inst, reff172_op in H. discriminate H. Qed.

Lemma reff172_not1275 : ~ @Equation1275 Fin4 reff172_inst.
Proof. unfold Equation1275. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff172_inst, reff172_op in H. discriminate H. Qed.

Lemma reff172_not1276 : ~ @Equation1276 Fin4 reff172_inst.
Proof. unfold Equation1276. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff172_inst, reff172_op in H. discriminate H. Qed.

Lemma reff172_not1278 : ~ @Equation1278 Fin4 reff172_inst.
Proof. unfold Equation1278. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff172_inst, reff172_op in H. discriminate H. Qed.

Lemma reff172_not1279 : ~ @Equation1279 Fin4 reff172_inst.
Proof. unfold Equation1279. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff172_inst, reff172_op in H. discriminate H. Qed.

Lemma reff172_not1285 : ~ @Equation1285 Fin4 reff172_inst.
Proof. unfold Equation1285. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff172_inst, reff172_op in H. discriminate H. Qed.

Lemma reff172_not1286 : ~ @Equation1286 Fin4 reff172_inst.
Proof. unfold Equation1286. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff172_inst, reff172_op in H. discriminate H. Qed.

Lemma reff172_not1288 : ~ @Equation1288 Fin4 reff172_inst.
Proof. unfold Equation1288. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff172_inst, reff172_op in H. discriminate H. Qed.

Lemma reff172_not1289 : ~ @Equation1289 Fin4 reff172_inst.
Proof. unfold Equation1289. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff172_inst, reff172_op in H. discriminate H. Qed.

Lemma reff172_not1313 : ~ @Equation1313 Fin4 reff172_inst.
Proof. unfold Equation1313. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff172_inst, reff172_op in H. discriminate H. Qed.

Lemma reff172_not1315 : ~ @Equation1315 Fin4 reff172_inst.
Proof. unfold Equation1315. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff172_inst, reff172_op in H. discriminate H. Qed.

Lemma reff172_not1316 : ~ @Equation1316 Fin4 reff172_inst.
Proof. unfold Equation1316. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff172_inst, reff172_op in H. discriminate H. Qed.

Lemma reff172_not1322 : ~ @Equation1322 Fin4 reff172_inst.
Proof. unfold Equation1322. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff172_inst, reff172_op in H. discriminate H. Qed.

Lemma reff172_not1323 : ~ @Equation1323 Fin4 reff172_inst.
Proof. unfold Equation1323. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff172_inst, reff172_op in H. discriminate H. Qed.

Lemma reff172_not1427 : ~ @Equation1427 Fin4 reff172_inst.
Proof. unfold Equation1427. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff172_inst, reff172_op in H. discriminate H. Qed.

Lemma reff172_not1428 : ~ @Equation1428 Fin4 reff172_inst.
Proof. unfold Equation1428. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff172_inst, reff172_op in H. discriminate H. Qed.

Lemma reff172_not1429 : ~ @Equation1429 Fin4 reff172_inst.
Proof. unfold Equation1429. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff172_inst, reff172_op in H. discriminate H. Qed.

Lemma reff172_not1431 : ~ @Equation1431 Fin4 reff172_inst.
Proof. unfold Equation1431. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff172_inst, reff172_op in H. discriminate H. Qed.

Lemma reff172_not1432 : ~ @Equation1432 Fin4 reff172_inst.
Proof. unfold Equation1432. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff172_inst, reff172_op in H. discriminate H. Qed.

Lemma reff172_not1435 : ~ @Equation1435 Fin4 reff172_inst.
Proof. unfold Equation1435. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff172_inst, reff172_op in H. discriminate H. Qed.

Lemma reff172_not1441 : ~ @Equation1441 Fin4 reff172_inst.
Proof. unfold Equation1441. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff172_inst, reff172_op in H. discriminate H. Qed.

Lemma reff172_not1442 : ~ @Equation1442 Fin4 reff172_inst.
Proof. unfold Equation1442. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff172_inst, reff172_op in H. discriminate H. Qed.

Lemma reff172_not1444 : ~ @Equation1444 Fin4 reff172_inst.
Proof. unfold Equation1444. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff172_inst, reff172_op in H. discriminate H. Qed.

Lemma reff172_not1445 : ~ @Equation1445 Fin4 reff172_inst.
Proof. unfold Equation1445. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff172_inst, reff172_op in H. discriminate H. Qed.

Lemma reff172_not1451 : ~ @Equation1451 Fin4 reff172_inst.
Proof. unfold Equation1451. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff172_inst, reff172_op in H. discriminate H. Qed.

Lemma reff172_not1452 : ~ @Equation1452 Fin4 reff172_inst.
Proof. unfold Equation1452. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff172_inst, reff172_op in H. discriminate H. Qed.

Lemma reff172_not1454 : ~ @Equation1454 Fin4 reff172_inst.
Proof. unfold Equation1454. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff172_inst, reff172_op in H. discriminate H. Qed.

Lemma reff172_not1455 : ~ @Equation1455 Fin4 reff172_inst.
Proof. unfold Equation1455. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff172_inst, reff172_op in H. discriminate H. Qed.

Lemma reff172_not1478 : ~ @Equation1478 Fin4 reff172_inst.
Proof. unfold Equation1478. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff172_inst, reff172_op in H. discriminate H. Qed.

Lemma reff172_not1479 : ~ @Equation1479 Fin4 reff172_inst.
Proof. unfold Equation1479. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff172_inst, reff172_op in H. discriminate H. Qed.

Lemma reff172_not1482 : ~ @Equation1482 Fin4 reff172_inst.
Proof. unfold Equation1482. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff172_inst, reff172_op in H. discriminate H. Qed.

Lemma reff172_not1489 : ~ @Equation1489 Fin4 reff172_inst.
Proof. unfold Equation1489. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff172_inst, reff172_op in H. discriminate H. Qed.

Lemma reff172_not1491 : ~ @Equation1491 Fin4 reff172_inst.
Proof. unfold Equation1491. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff172_inst, reff172_op in H. discriminate H. Qed.

Lemma reff172_not1492 : ~ @Equation1492 Fin4 reff172_inst.
Proof. unfold Equation1492. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff172_inst, reff172_op in H. discriminate H. Qed.

Lemma reff172_not1515 : ~ @Equation1515 Fin4 reff172_inst.
Proof. unfold Equation1515. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff172_inst, reff172_op in H. discriminate H. Qed.

Lemma reff172_not1516 : ~ @Equation1516 Fin4 reff172_inst.
Proof. unfold Equation1516. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff172_inst, reff172_op in H. discriminate H. Qed.

Lemma reff172_not1518 : ~ @Equation1518 Fin4 reff172_inst.
Proof. unfold Equation1518. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff172_inst, reff172_op in H. discriminate H. Qed.

Lemma reff172_not1519 : ~ @Equation1519 Fin4 reff172_inst.
Proof. unfold Equation1519. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff172_inst, reff172_op in H. discriminate H. Qed.

Lemma reff172_not1525 : ~ @Equation1525 Fin4 reff172_inst.
Proof. unfold Equation1525. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff172_inst, reff172_op in H. discriminate H. Qed.

Lemma reff172_not1526 : ~ @Equation1526 Fin4 reff172_inst.
Proof. unfold Equation1526. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff172_inst, reff172_op in H. discriminate H. Qed.

Lemma reff172_not1528 : ~ @Equation1528 Fin4 reff172_inst.
Proof. unfold Equation1528. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff172_inst, reff172_op in H. discriminate H. Qed.

Lemma reff172_not1630 : ~ @Equation1630 Fin4 reff172_inst.
Proof. unfold Equation1630. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff172_inst, reff172_op in H. discriminate H. Qed.

Lemma reff172_not1631 : ~ @Equation1631 Fin4 reff172_inst.
Proof. unfold Equation1631. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff172_inst, reff172_op in H. discriminate H. Qed.

Lemma reff172_not1632 : ~ @Equation1632 Fin4 reff172_inst.
Proof. unfold Equation1632. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff172_inst, reff172_op in H. discriminate H. Qed.

Lemma reff172_not1634 : ~ @Equation1634 Fin4 reff172_inst.
Proof. unfold Equation1634. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff172_inst, reff172_op in H. discriminate H. Qed.

Lemma reff172_not1635 : ~ @Equation1635 Fin4 reff172_inst.
Proof. unfold Equation1635. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff172_inst, reff172_op in H. discriminate H. Qed.

Lemma reff172_not1637 : ~ @Equation1637 Fin4 reff172_inst.
Proof. unfold Equation1637. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff172_inst, reff172_op in H. discriminate H. Qed.

Lemma reff172_not1638 : ~ @Equation1638 Fin4 reff172_inst.
Proof. unfold Equation1638. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff172_inst, reff172_op in H. discriminate H. Qed.

Lemma reff172_not1644 : ~ @Equation1644 Fin4 reff172_inst.
Proof. unfold Equation1644. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff172_inst, reff172_op in H. discriminate H. Qed.

Lemma reff172_not1645 : ~ @Equation1645 Fin4 reff172_inst.
Proof. unfold Equation1645. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff172_inst, reff172_op in H. discriminate H. Qed.

Lemma reff172_not1648 : ~ @Equation1648 Fin4 reff172_inst.
Proof. unfold Equation1648. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff172_inst, reff172_op in H. discriminate H. Qed.

Lemma reff172_not1654 : ~ @Equation1654 Fin4 reff172_inst.
Proof. unfold Equation1654. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff172_inst, reff172_op in H. discriminate H. Qed.

Lemma reff172_not1655 : ~ @Equation1655 Fin4 reff172_inst.
Proof. unfold Equation1655. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff172_inst, reff172_op in H. discriminate H. Qed.

Lemma reff172_not1657 : ~ @Equation1657 Fin4 reff172_inst.
Proof. unfold Equation1657. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff172_inst, reff172_op in H. discriminate H. Qed.

Lemma reff172_not1658 : ~ @Equation1658 Fin4 reff172_inst.
Proof. unfold Equation1658. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff172_inst, reff172_op in H. discriminate H. Qed.

Lemma reff172_not1681 : ~ @Equation1681 Fin4 reff172_inst.
Proof. unfold Equation1681. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff172_inst, reff172_op in H. discriminate H. Qed.

Lemma reff172_not1682 : ~ @Equation1682 Fin4 reff172_inst.
Proof. unfold Equation1682. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff172_inst, reff172_op in H. discriminate H. Qed.

Lemma reff172_not1684 : ~ @Equation1684 Fin4 reff172_inst.
Proof. unfold Equation1684. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff172_inst, reff172_op in H. discriminate H. Qed.

Lemma reff172_not1685 : ~ @Equation1685 Fin4 reff172_inst.
Proof. unfold Equation1685. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff172_inst, reff172_op in H. discriminate H. Qed.

Lemma reff172_not1692 : ~ @Equation1692 Fin4 reff172_inst.
Proof. unfold Equation1692. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff172_inst, reff172_op in H. discriminate H. Qed.

Lemma reff172_not1694 : ~ @Equation1694 Fin4 reff172_inst.
Proof. unfold Equation1694. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff172_inst, reff172_op in H. discriminate H. Qed.

Lemma reff172_not1695 : ~ @Equation1695 Fin4 reff172_inst.
Proof. unfold Equation1695. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff172_inst, reff172_op in H. discriminate H. Qed.

Lemma reff172_not1718 : ~ @Equation1718 Fin4 reff172_inst.
Proof. unfold Equation1718. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff172_inst, reff172_op in H. discriminate H. Qed.

Lemma reff172_not1719 : ~ @Equation1719 Fin4 reff172_inst.
Proof. unfold Equation1719. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff172_inst, reff172_op in H. discriminate H. Qed.

Lemma reff172_not1721 : ~ @Equation1721 Fin4 reff172_inst.
Proof. unfold Equation1721. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff172_inst, reff172_op in H. discriminate H. Qed.

Lemma reff172_not1722 : ~ @Equation1722 Fin4 reff172_inst.
Proof. unfold Equation1722. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff172_inst, reff172_op in H. discriminate H. Qed.

Lemma reff172_not1728 : ~ @Equation1728 Fin4 reff172_inst.
Proof. unfold Equation1728. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff172_inst, reff172_op in H. discriminate H. Qed.

Lemma reff172_not1729 : ~ @Equation1729 Fin4 reff172_inst.
Proof. unfold Equation1729. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff172_inst, reff172_op in H. discriminate H. Qed.

Lemma reff172_not1833 : ~ @Equation1833 Fin4 reff172_inst.
Proof. unfold Equation1833. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff172_inst, reff172_op in H. discriminate H. Qed.

Lemma reff172_not1834 : ~ @Equation1834 Fin4 reff172_inst.
Proof. unfold Equation1834. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff172_inst, reff172_op in H. discriminate H. Qed.

Lemma reff172_not1835 : ~ @Equation1835 Fin4 reff172_inst.
Proof. unfold Equation1835. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff172_inst, reff172_op in H. discriminate H. Qed.

Lemma reff172_not1837 : ~ @Equation1837 Fin4 reff172_inst.
Proof. unfold Equation1837. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff172_inst, reff172_op in H. discriminate H. Qed.

Lemma reff172_not1838 : ~ @Equation1838 Fin4 reff172_inst.
Proof. unfold Equation1838. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff172_inst, reff172_op in H. discriminate H. Qed.

Lemma reff172_not1841 : ~ @Equation1841 Fin4 reff172_inst.
Proof. unfold Equation1841. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff172_inst, reff172_op in H. discriminate H. Qed.

Lemma reff172_not1847 : ~ @Equation1847 Fin4 reff172_inst.
Proof. unfold Equation1847. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff172_inst, reff172_op in H. discriminate H. Qed.

Lemma reff172_not1848 : ~ @Equation1848 Fin4 reff172_inst.
Proof. unfold Equation1848. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff172_inst, reff172_op in H. discriminate H. Qed.

Lemma reff172_not1851 : ~ @Equation1851 Fin4 reff172_inst.
Proof. unfold Equation1851. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff172_inst, reff172_op in H. discriminate H. Qed.

Lemma reff172_not1857 : ~ @Equation1857 Fin4 reff172_inst.
Proof. unfold Equation1857. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff172_inst, reff172_op in H. discriminate H. Qed.

Lemma reff172_not1858 : ~ @Equation1858 Fin4 reff172_inst.
Proof. unfold Equation1858. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff172_inst, reff172_op in H. discriminate H. Qed.

Lemma reff172_not1860 : ~ @Equation1860 Fin4 reff172_inst.
Proof. unfold Equation1860. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff172_inst, reff172_op in H. discriminate H. Qed.

Lemma reff172_not1861 : ~ @Equation1861 Fin4 reff172_inst.
Proof. unfold Equation1861. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff172_inst, reff172_op in H. discriminate H. Qed.

Lemma reff172_not1884 : ~ @Equation1884 Fin4 reff172_inst.
Proof. unfold Equation1884. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff172_inst, reff172_op in H. discriminate H. Qed.

Lemma reff172_not1885 : ~ @Equation1885 Fin4 reff172_inst.
Proof. unfold Equation1885. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff172_inst, reff172_op in H. discriminate H. Qed.

Lemma reff172_not1888 : ~ @Equation1888 Fin4 reff172_inst.
Proof. unfold Equation1888. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff172_inst, reff172_op in H. discriminate H. Qed.

Lemma reff172_not1894 : ~ @Equation1894 Fin4 reff172_inst.
Proof. unfold Equation1894. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff172_inst, reff172_op in H. discriminate H. Qed.

Lemma reff172_not1895 : ~ @Equation1895 Fin4 reff172_inst.
Proof. unfold Equation1895. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff172_inst, reff172_op in H. discriminate H. Qed.

Lemma reff172_not1897 : ~ @Equation1897 Fin4 reff172_inst.
Proof. unfold Equation1897. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff172_inst, reff172_op in H. discriminate H. Qed.

Lemma reff172_not1898 : ~ @Equation1898 Fin4 reff172_inst.
Proof. unfold Equation1898. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff172_inst, reff172_op in H. discriminate H. Qed.

Lemma reff172_not1922 : ~ @Equation1922 Fin4 reff172_inst.
Proof. unfold Equation1922. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff172_inst, reff172_op in H. discriminate H. Qed.

Lemma reff172_not1924 : ~ @Equation1924 Fin4 reff172_inst.
Proof. unfold Equation1924. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff172_inst, reff172_op in H. discriminate H. Qed.

Lemma reff172_not1925 : ~ @Equation1925 Fin4 reff172_inst.
Proof. unfold Equation1925. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff172_inst, reff172_op in H. discriminate H. Qed.

Lemma reff172_not1931 : ~ @Equation1931 Fin4 reff172_inst.
Proof. unfold Equation1931. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff172_inst, reff172_op in H. discriminate H. Qed.

Lemma reff172_not1932 : ~ @Equation1932 Fin4 reff172_inst.
Proof. unfold Equation1932. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff172_inst, reff172_op in H. discriminate H. Qed.

Lemma reff172_not2036 : ~ @Equation2036 Fin4 reff172_inst.
Proof. unfold Equation2036. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff172_inst, reff172_op in H. discriminate H. Qed.

Lemma reff172_not2037 : ~ @Equation2037 Fin4 reff172_inst.
Proof. unfold Equation2037. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff172_inst, reff172_op in H. discriminate H. Qed.

Lemma reff172_not2038 : ~ @Equation2038 Fin4 reff172_inst.
Proof. unfold Equation2038. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff172_inst, reff172_op in H. discriminate H. Qed.

Lemma reff172_not2040 : ~ @Equation2040 Fin4 reff172_inst.
Proof. unfold Equation2040. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff172_inst, reff172_op in H. discriminate H. Qed.

Lemma reff172_not2041 : ~ @Equation2041 Fin4 reff172_inst.
Proof. unfold Equation2041. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff172_inst, reff172_op in H. discriminate H. Qed.

Lemma reff172_not2043 : ~ @Equation2043 Fin4 reff172_inst.
Proof. unfold Equation2043. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff172_inst, reff172_op in H. discriminate H. Qed.

Lemma reff172_not2044 : ~ @Equation2044 Fin4 reff172_inst.
Proof. unfold Equation2044. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff172_inst, reff172_op in H. discriminate H. Qed.

Lemma reff172_not2050 : ~ @Equation2050 Fin4 reff172_inst.
Proof. unfold Equation2050. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff172_inst, reff172_op in H. discriminate H. Qed.

Lemma reff172_not2051 : ~ @Equation2051 Fin4 reff172_inst.
Proof. unfold Equation2051. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff172_inst, reff172_op in H. discriminate H. Qed.

Lemma reff172_not2053 : ~ @Equation2053 Fin4 reff172_inst.
Proof. unfold Equation2053. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff172_inst, reff172_op in H. discriminate H. Qed.

Lemma reff172_not2054 : ~ @Equation2054 Fin4 reff172_inst.
Proof. unfold Equation2054. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff172_inst, reff172_op in H. discriminate H. Qed.

Lemma reff172_not2060 : ~ @Equation2060 Fin4 reff172_inst.
Proof. unfold Equation2060. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff172_inst, reff172_op in H. discriminate H. Qed.

Lemma reff172_not2061 : ~ @Equation2061 Fin4 reff172_inst.
Proof. unfold Equation2061. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff172_inst, reff172_op in H. discriminate H. Qed.

Lemma reff172_not2063 : ~ @Equation2063 Fin4 reff172_inst.
Proof. unfold Equation2063. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff172_inst, reff172_op in H. discriminate H. Qed.

Lemma reff172_not2064 : ~ @Equation2064 Fin4 reff172_inst.
Proof. unfold Equation2064. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff172_inst, reff172_op in H. discriminate H. Qed.

Lemma reff172_not2087 : ~ @Equation2087 Fin4 reff172_inst.
Proof. unfold Equation2087. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff172_inst, reff172_op in H. discriminate H. Qed.

Lemma reff172_not2088 : ~ @Equation2088 Fin4 reff172_inst.
Proof. unfold Equation2088. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff172_inst, reff172_op in H. discriminate H. Qed.

Lemma reff172_not2091 : ~ @Equation2091 Fin4 reff172_inst.
Proof. unfold Equation2091. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff172_inst, reff172_op in H. discriminate H. Qed.

Lemma reff172_not2097 : ~ @Equation2097 Fin4 reff172_inst.
Proof. unfold Equation2097. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff172_inst, reff172_op in H. discriminate H. Qed.

Lemma reff172_not2098 : ~ @Equation2098 Fin4 reff172_inst.
Proof. unfold Equation2098. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff172_inst, reff172_op in H. discriminate H. Qed.

Lemma reff172_not2100 : ~ @Equation2100 Fin4 reff172_inst.
Proof. unfold Equation2100. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff172_inst, reff172_op in H. discriminate H. Qed.

Lemma reff172_not2101 : ~ @Equation2101 Fin4 reff172_inst.
Proof. unfold Equation2101. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff172_inst, reff172_op in H. discriminate H. Qed.

Lemma reff172_not2124 : ~ @Equation2124 Fin4 reff172_inst.
Proof. unfold Equation2124. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff172_inst, reff172_op in H. discriminate H. Qed.

Lemma reff172_not2125 : ~ @Equation2125 Fin4 reff172_inst.
Proof. unfold Equation2125. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff172_inst, reff172_op in H. discriminate H. Qed.

Lemma reff172_not2127 : ~ @Equation2127 Fin4 reff172_inst.
Proof. unfold Equation2127. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff172_inst, reff172_op in H. discriminate H. Qed.

Lemma reff172_not2128 : ~ @Equation2128 Fin4 reff172_inst.
Proof. unfold Equation2128. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff172_inst, reff172_op in H. discriminate H. Qed.

Lemma reff172_not2134 : ~ @Equation2134 Fin4 reff172_inst.
Proof. unfold Equation2134. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff172_inst, reff172_op in H. discriminate H. Qed.

Lemma reff172_not2135 : ~ @Equation2135 Fin4 reff172_inst.
Proof. unfold Equation2135. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff172_inst, reff172_op in H. discriminate H. Qed.

Lemma reff172_not2239 : ~ @Equation2239 Fin4 reff172_inst.
Proof. unfold Equation2239. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff172_inst, reff172_op in H. discriminate H. Qed.

Lemma reff172_not2240 : ~ @Equation2240 Fin4 reff172_inst.
Proof. unfold Equation2240. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff172_inst, reff172_op in H. discriminate H. Qed.

Lemma reff172_not2241 : ~ @Equation2241 Fin4 reff172_inst.
Proof. unfold Equation2241. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff172_inst, reff172_op in H. discriminate H. Qed.

Lemma reff172_not2243 : ~ @Equation2243 Fin4 reff172_inst.
Proof. unfold Equation2243. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff172_inst, reff172_op in H. discriminate H. Qed.

Lemma reff172_not2244 : ~ @Equation2244 Fin4 reff172_inst.
Proof. unfold Equation2244. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff172_inst, reff172_op in H. discriminate H. Qed.

Lemma reff172_not2246 : ~ @Equation2246 Fin4 reff172_inst.
Proof. unfold Equation2246. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff172_inst, reff172_op in H. discriminate H. Qed.

Lemma reff172_not2247 : ~ @Equation2247 Fin4 reff172_inst.
Proof. unfold Equation2247. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff172_inst, reff172_op in H. discriminate H. Qed.

Lemma reff172_not2253 : ~ @Equation2253 Fin4 reff172_inst.
Proof. unfold Equation2253. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff172_inst, reff172_op in H. discriminate H. Qed.

Lemma reff172_not2254 : ~ @Equation2254 Fin4 reff172_inst.
Proof. unfold Equation2254. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff172_inst, reff172_op in H. discriminate H. Qed.

Lemma reff172_not2256 : ~ @Equation2256 Fin4 reff172_inst.
Proof. unfold Equation2256. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff172_inst, reff172_op in H. discriminate H. Qed.

Lemma reff172_not2257 : ~ @Equation2257 Fin4 reff172_inst.
Proof. unfold Equation2257. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff172_inst, reff172_op in H. discriminate H. Qed.

Lemma reff172_not2264 : ~ @Equation2264 Fin4 reff172_inst.
Proof. unfold Equation2264. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff172_inst, reff172_op in H. discriminate H. Qed.

Lemma reff172_not2266 : ~ @Equation2266 Fin4 reff172_inst.
Proof. unfold Equation2266. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff172_inst, reff172_op in H. discriminate H. Qed.

Lemma reff172_not2267 : ~ @Equation2267 Fin4 reff172_inst.
Proof. unfold Equation2267. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff172_inst, reff172_op in H. discriminate H. Qed.

Lemma reff172_not2290 : ~ @Equation2290 Fin4 reff172_inst.
Proof. unfold Equation2290. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff172_inst, reff172_op in H. discriminate H. Qed.

Lemma reff172_not2291 : ~ @Equation2291 Fin4 reff172_inst.
Proof. unfold Equation2291. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff172_inst, reff172_op in H. discriminate H. Qed.

Lemma reff172_not2293 : ~ @Equation2293 Fin4 reff172_inst.
Proof. unfold Equation2293. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff172_inst, reff172_op in H. discriminate H. Qed.

Lemma reff172_not2294 : ~ @Equation2294 Fin4 reff172_inst.
Proof. unfold Equation2294. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff172_inst, reff172_op in H. discriminate H. Qed.

Lemma reff172_not2301 : ~ @Equation2301 Fin4 reff172_inst.
Proof. unfold Equation2301. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff172_inst, reff172_op in H. discriminate H. Qed.

Lemma reff172_not2303 : ~ @Equation2303 Fin4 reff172_inst.
Proof. unfold Equation2303. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff172_inst, reff172_op in H. discriminate H. Qed.

Lemma reff172_not2304 : ~ @Equation2304 Fin4 reff172_inst.
Proof. unfold Equation2304. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff172_inst, reff172_op in H. discriminate H. Qed.

Lemma reff172_not2328 : ~ @Equation2328 Fin4 reff172_inst.
Proof. unfold Equation2328. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff172_inst, reff172_op in H. discriminate H. Qed.

Lemma reff172_not2330 : ~ @Equation2330 Fin4 reff172_inst.
Proof. unfold Equation2330. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff172_inst, reff172_op in H. discriminate H. Qed.

Lemma reff172_not2331 : ~ @Equation2331 Fin4 reff172_inst.
Proof. unfold Equation2331. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff172_inst, reff172_op in H. discriminate H. Qed.

Lemma reff172_not2337 : ~ @Equation2337 Fin4 reff172_inst.
Proof. unfold Equation2337. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff172_inst, reff172_op in H. discriminate H. Qed.

Lemma reff172_not2338 : ~ @Equation2338 Fin4 reff172_inst.
Proof. unfold Equation2338. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff172_inst, reff172_op in H. discriminate H. Qed.

Lemma reff172_not2340 : ~ @Equation2340 Fin4 reff172_inst.
Proof. unfold Equation2340. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff172_inst, reff172_op in H. discriminate H. Qed.

Lemma reff172_not2442 : ~ @Equation2442 Fin4 reff172_inst.
Proof. unfold Equation2442. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff172_inst, reff172_op in H. discriminate H. Qed.

Lemma reff172_not2443 : ~ @Equation2443 Fin4 reff172_inst.
Proof. unfold Equation2443. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff172_inst, reff172_op in H. discriminate H. Qed.

Lemma reff172_not2444 : ~ @Equation2444 Fin4 reff172_inst.
Proof. unfold Equation2444. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff172_inst, reff172_op in H. discriminate H. Qed.

Lemma reff172_not2446 : ~ @Equation2446 Fin4 reff172_inst.
Proof. unfold Equation2446. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff172_inst, reff172_op in H. discriminate H. Qed.

Lemma reff172_not2447 : ~ @Equation2447 Fin4 reff172_inst.
Proof. unfold Equation2447. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff172_inst, reff172_op in H. discriminate H. Qed.

Lemma reff172_not2449 : ~ @Equation2449 Fin4 reff172_inst.
Proof. unfold Equation2449. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff172_inst, reff172_op in H. discriminate H. Qed.

Lemma reff172_not2450 : ~ @Equation2450 Fin4 reff172_inst.
Proof. unfold Equation2450. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff172_inst, reff172_op in H. discriminate H. Qed.

Lemma reff172_not2456 : ~ @Equation2456 Fin4 reff172_inst.
Proof. unfold Equation2456. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff172_inst, reff172_op in H. discriminate H. Qed.

Lemma reff172_not2457 : ~ @Equation2457 Fin4 reff172_inst.
Proof. unfold Equation2457. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff172_inst, reff172_op in H. discriminate H. Qed.

Lemma reff172_not2460 : ~ @Equation2460 Fin4 reff172_inst.
Proof. unfold Equation2460. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff172_inst, reff172_op in H. discriminate H. Qed.

Lemma reff172_not2466 : ~ @Equation2466 Fin4 reff172_inst.
Proof. unfold Equation2466. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff172_inst, reff172_op in H. discriminate H. Qed.

Lemma reff172_not2467 : ~ @Equation2467 Fin4 reff172_inst.
Proof. unfold Equation2467. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff172_inst, reff172_op in H. discriminate H. Qed.

Lemma reff172_not2469 : ~ @Equation2469 Fin4 reff172_inst.
Proof. unfold Equation2469. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff172_inst, reff172_op in H. discriminate H. Qed.

Lemma reff172_not2470 : ~ @Equation2470 Fin4 reff172_inst.
Proof. unfold Equation2470. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff172_inst, reff172_op in H. discriminate H. Qed.

Lemma reff172_not2493 : ~ @Equation2493 Fin4 reff172_inst.
Proof. unfold Equation2493. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff172_inst, reff172_op in H. discriminate H. Qed.

Lemma reff172_not2494 : ~ @Equation2494 Fin4 reff172_inst.
Proof. unfold Equation2494. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff172_inst, reff172_op in H. discriminate H. Qed.

Lemma reff172_not2496 : ~ @Equation2496 Fin4 reff172_inst.
Proof. unfold Equation2496. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff172_inst, reff172_op in H. discriminate H. Qed.

Lemma reff172_not2497 : ~ @Equation2497 Fin4 reff172_inst.
Proof. unfold Equation2497. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff172_inst, reff172_op in H. discriminate H. Qed.

Lemma reff172_not2503 : ~ @Equation2503 Fin4 reff172_inst.
Proof. unfold Equation2503. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff172_inst, reff172_op in H. discriminate H. Qed.

Lemma reff172_not2504 : ~ @Equation2504 Fin4 reff172_inst.
Proof. unfold Equation2504. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff172_inst, reff172_op in H. discriminate H. Qed.

Lemma reff172_not2506 : ~ @Equation2506 Fin4 reff172_inst.
Proof. unfold Equation2506. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff172_inst, reff172_op in H. discriminate H. Qed.

Lemma reff172_not2507 : ~ @Equation2507 Fin4 reff172_inst.
Proof. unfold Equation2507. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff172_inst, reff172_op in H. discriminate H. Qed.

Lemma reff172_not2531 : ~ @Equation2531 Fin4 reff172_inst.
Proof. unfold Equation2531. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff172_inst, reff172_op in H. discriminate H. Qed.

Lemma reff172_not2533 : ~ @Equation2533 Fin4 reff172_inst.
Proof. unfold Equation2533. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff172_inst, reff172_op in H. discriminate H. Qed.

Lemma reff172_not2534 : ~ @Equation2534 Fin4 reff172_inst.
Proof. unfold Equation2534. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff172_inst, reff172_op in H. discriminate H. Qed.

Lemma reff172_not2540 : ~ @Equation2540 Fin4 reff172_inst.
Proof. unfold Equation2540. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff172_inst, reff172_op in H. discriminate H. Qed.

Lemma reff172_not2541 : ~ @Equation2541 Fin4 reff172_inst.
Proof. unfold Equation2541. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff172_inst, reff172_op in H. discriminate H. Qed.

Lemma reff172_not2543 : ~ @Equation2543 Fin4 reff172_inst.
Proof. unfold Equation2543. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff172_inst, reff172_op in H. discriminate H. Qed.

Lemma reff172_not2645 : ~ @Equation2645 Fin4 reff172_inst.
Proof. unfold Equation2645. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff172_inst, reff172_op in H. discriminate H. Qed.

Lemma reff172_not2646 : ~ @Equation2646 Fin4 reff172_inst.
Proof. unfold Equation2646. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff172_inst, reff172_op in H. discriminate H. Qed.

Lemma reff172_not2647 : ~ @Equation2647 Fin4 reff172_inst.
Proof. unfold Equation2647. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff172_inst, reff172_op in H. discriminate H. Qed.

Lemma reff172_not2649 : ~ @Equation2649 Fin4 reff172_inst.
Proof. unfold Equation2649. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff172_inst, reff172_op in H. discriminate H. Qed.

Lemma reff172_not2650 : ~ @Equation2650 Fin4 reff172_inst.
Proof. unfold Equation2650. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff172_inst, reff172_op in H. discriminate H. Qed.

Lemma reff172_not2652 : ~ @Equation2652 Fin4 reff172_inst.
Proof. unfold Equation2652. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff172_inst, reff172_op in H. discriminate H. Qed.

Lemma reff172_not2653 : ~ @Equation2653 Fin4 reff172_inst.
Proof. unfold Equation2653. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff172_inst, reff172_op in H. discriminate H. Qed.

Lemma reff172_not2659 : ~ @Equation2659 Fin4 reff172_inst.
Proof. unfold Equation2659. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff172_inst, reff172_op in H. discriminate H. Qed.

Lemma reff172_not2660 : ~ @Equation2660 Fin4 reff172_inst.
Proof. unfold Equation2660. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff172_inst, reff172_op in H. discriminate H. Qed.

Lemma reff172_not2662 : ~ @Equation2662 Fin4 reff172_inst.
Proof. unfold Equation2662. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff172_inst, reff172_op in H. discriminate H. Qed.

Lemma reff172_not2663 : ~ @Equation2663 Fin4 reff172_inst.
Proof. unfold Equation2663. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff172_inst, reff172_op in H. discriminate H. Qed.

Lemma reff172_not2669 : ~ @Equation2669 Fin4 reff172_inst.
Proof. unfold Equation2669. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff172_inst, reff172_op in H. discriminate H. Qed.

Lemma reff172_not2670 : ~ @Equation2670 Fin4 reff172_inst.
Proof. unfold Equation2670. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff172_inst, reff172_op in H. discriminate H. Qed.

Lemma reff172_not2672 : ~ @Equation2672 Fin4 reff172_inst.
Proof. unfold Equation2672. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff172_inst, reff172_op in H. discriminate H. Qed.

Lemma reff172_not2673 : ~ @Equation2673 Fin4 reff172_inst.
Proof. unfold Equation2673. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff172_inst, reff172_op in H. discriminate H. Qed.

Lemma reff172_not2696 : ~ @Equation2696 Fin4 reff172_inst.
Proof. unfold Equation2696. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff172_inst, reff172_op in H. discriminate H. Qed.

Lemma reff172_not2697 : ~ @Equation2697 Fin4 reff172_inst.
Proof. unfold Equation2697. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff172_inst, reff172_op in H. discriminate H. Qed.

Lemma reff172_not2700 : ~ @Equation2700 Fin4 reff172_inst.
Proof. unfold Equation2700. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff172_inst, reff172_op in H. discriminate H. Qed.

Lemma reff172_not2707 : ~ @Equation2707 Fin4 reff172_inst.
Proof. unfold Equation2707. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff172_inst, reff172_op in H. discriminate H. Qed.

Lemma reff172_not2709 : ~ @Equation2709 Fin4 reff172_inst.
Proof. unfold Equation2709. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff172_inst, reff172_op in H. discriminate H. Qed.

Lemma reff172_not2710 : ~ @Equation2710 Fin4 reff172_inst.
Proof. unfold Equation2710. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff172_inst, reff172_op in H. discriminate H. Qed.

Lemma reff172_not2733 : ~ @Equation2733 Fin4 reff172_inst.
Proof. unfold Equation2733. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff172_inst, reff172_op in H. discriminate H. Qed.

Lemma reff172_not2734 : ~ @Equation2734 Fin4 reff172_inst.
Proof. unfold Equation2734. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff172_inst, reff172_op in H. discriminate H. Qed.

Lemma reff172_not2736 : ~ @Equation2736 Fin4 reff172_inst.
Proof. unfold Equation2736. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff172_inst, reff172_op in H. discriminate H. Qed.

Lemma reff172_not2737 : ~ @Equation2737 Fin4 reff172_inst.
Proof. unfold Equation2737. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff172_inst, reff172_op in H. discriminate H. Qed.

Lemma reff172_not2743 : ~ @Equation2743 Fin4 reff172_inst.
Proof. unfold Equation2743. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff172_inst, reff172_op in H. discriminate H. Qed.

Lemma reff172_not2744 : ~ @Equation2744 Fin4 reff172_inst.
Proof. unfold Equation2744. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff172_inst, reff172_op in H. discriminate H. Qed.

Lemma reff172_not2746 : ~ @Equation2746 Fin4 reff172_inst.
Proof. unfold Equation2746. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff172_inst, reff172_op in H. discriminate H. Qed.

Lemma reff172_not2848 : ~ @Equation2848 Fin4 reff172_inst.
Proof. unfold Equation2848. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff172_inst, reff172_op in H. discriminate H. Qed.

Lemma reff172_not2849 : ~ @Equation2849 Fin4 reff172_inst.
Proof. unfold Equation2849. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff172_inst, reff172_op in H. discriminate H. Qed.

Lemma reff172_not2850 : ~ @Equation2850 Fin4 reff172_inst.
Proof. unfold Equation2850. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff172_inst, reff172_op in H. discriminate H. Qed.

Lemma reff172_not2852 : ~ @Equation2852 Fin4 reff172_inst.
Proof. unfold Equation2852. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff172_inst, reff172_op in H. discriminate H. Qed.

Lemma reff172_not2853 : ~ @Equation2853 Fin4 reff172_inst.
Proof. unfold Equation2853. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff172_inst, reff172_op in H. discriminate H. Qed.

Lemma reff172_not2855 : ~ @Equation2855 Fin4 reff172_inst.
Proof. unfold Equation2855. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff172_inst, reff172_op in H. discriminate H. Qed.

Lemma reff172_not2856 : ~ @Equation2856 Fin4 reff172_inst.
Proof. unfold Equation2856. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff172_inst, reff172_op in H. discriminate H. Qed.

Lemma reff172_not2862 : ~ @Equation2862 Fin4 reff172_inst.
Proof. unfold Equation2862. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff172_inst, reff172_op in H. discriminate H. Qed.

Lemma reff172_not2863 : ~ @Equation2863 Fin4 reff172_inst.
Proof. unfold Equation2863. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff172_inst, reff172_op in H. discriminate H. Qed.

Lemma reff172_not2865 : ~ @Equation2865 Fin4 reff172_inst.
Proof. unfold Equation2865. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff172_inst, reff172_op in H. discriminate H. Qed.

Lemma reff172_not2866 : ~ @Equation2866 Fin4 reff172_inst.
Proof. unfold Equation2866. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff172_inst, reff172_op in H. discriminate H. Qed.

Lemma reff172_not2872 : ~ @Equation2872 Fin4 reff172_inst.
Proof. unfold Equation2872. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff172_inst, reff172_op in H. discriminate H. Qed.

Lemma reff172_not2873 : ~ @Equation2873 Fin4 reff172_inst.
Proof. unfold Equation2873. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff172_inst, reff172_op in H. discriminate H. Qed.

Lemma reff172_not2875 : ~ @Equation2875 Fin4 reff172_inst.
Proof. unfold Equation2875. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff172_inst, reff172_op in H. discriminate H. Qed.

Lemma reff172_not2876 : ~ @Equation2876 Fin4 reff172_inst.
Proof. unfold Equation2876. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff172_inst, reff172_op in H. discriminate H. Qed.

Lemma reff172_not2899 : ~ @Equation2899 Fin4 reff172_inst.
Proof. unfold Equation2899. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff172_inst, reff172_op in H. discriminate H. Qed.

Lemma reff172_not2900 : ~ @Equation2900 Fin4 reff172_inst.
Proof. unfold Equation2900. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff172_inst, reff172_op in H. discriminate H. Qed.

Lemma reff172_not2902 : ~ @Equation2902 Fin4 reff172_inst.
Proof. unfold Equation2902. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff172_inst, reff172_op in H. discriminate H. Qed.

Lemma reff172_not2903 : ~ @Equation2903 Fin4 reff172_inst.
Proof. unfold Equation2903. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff172_inst, reff172_op in H. discriminate H. Qed.

Lemma reff172_not2909 : ~ @Equation2909 Fin4 reff172_inst.
Proof. unfold Equation2909. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff172_inst, reff172_op in H. discriminate H. Qed.

Lemma reff172_not2910 : ~ @Equation2910 Fin4 reff172_inst.
Proof. unfold Equation2910. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff172_inst, reff172_op in H. discriminate H. Qed.

Lemma reff172_not2912 : ~ @Equation2912 Fin4 reff172_inst.
Proof. unfold Equation2912. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff172_inst, reff172_op in H. discriminate H. Qed.

Lemma reff172_not2913 : ~ @Equation2913 Fin4 reff172_inst.
Proof. unfold Equation2913. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff172_inst, reff172_op in H. discriminate H. Qed.

Lemma reff172_not2937 : ~ @Equation2937 Fin4 reff172_inst.
Proof. unfold Equation2937. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff172_inst, reff172_op in H. discriminate H. Qed.

Lemma reff172_not2939 : ~ @Equation2939 Fin4 reff172_inst.
Proof. unfold Equation2939. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff172_inst, reff172_op in H. discriminate H. Qed.

Lemma reff172_not2940 : ~ @Equation2940 Fin4 reff172_inst.
Proof. unfold Equation2940. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff172_inst, reff172_op in H. discriminate H. Qed.

Lemma reff172_not2946 : ~ @Equation2946 Fin4 reff172_inst.
Proof. unfold Equation2946. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff172_inst, reff172_op in H. discriminate H. Qed.

Lemma reff172_not2947 : ~ @Equation2947 Fin4 reff172_inst.
Proof. unfold Equation2947. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff172_inst, reff172_op in H. discriminate H. Qed.

Lemma reff172_not2949 : ~ @Equation2949 Fin4 reff172_inst.
Proof. unfold Equation2949. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff172_inst, reff172_op in H. discriminate H. Qed.

Lemma reff172_not3051 : ~ @Equation3051 Fin4 reff172_inst.
Proof. unfold Equation3051. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff172_inst, reff172_op in H. discriminate H. Qed.

Lemma reff172_not3052 : ~ @Equation3052 Fin4 reff172_inst.
Proof. unfold Equation3052. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff172_inst, reff172_op in H. discriminate H. Qed.

Lemma reff172_not3053 : ~ @Equation3053 Fin4 reff172_inst.
Proof. unfold Equation3053. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff172_inst, reff172_op in H. discriminate H. Qed.

Lemma reff172_not3055 : ~ @Equation3055 Fin4 reff172_inst.
Proof. unfold Equation3055. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff172_inst, reff172_op in H. discriminate H. Qed.

Lemma reff172_not3056 : ~ @Equation3056 Fin4 reff172_inst.
Proof. unfold Equation3056. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff172_inst, reff172_op in H. discriminate H. Qed.

Lemma reff172_not3058 : ~ @Equation3058 Fin4 reff172_inst.
Proof. unfold Equation3058. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff172_inst, reff172_op in H. discriminate H. Qed.

Lemma reff172_not3059 : ~ @Equation3059 Fin4 reff172_inst.
Proof. unfold Equation3059. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff172_inst, reff172_op in H. discriminate H. Qed.

Lemma reff172_not3065 : ~ @Equation3065 Fin4 reff172_inst.
Proof. unfold Equation3065. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff172_inst, reff172_op in H. discriminate H. Qed.

Lemma reff172_not3066 : ~ @Equation3066 Fin4 reff172_inst.
Proof. unfold Equation3066. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff172_inst, reff172_op in H. discriminate H. Qed.

Lemma reff172_not3069 : ~ @Equation3069 Fin4 reff172_inst.
Proof. unfold Equation3069. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff172_inst, reff172_op in H. discriminate H. Qed.

Lemma reff172_not3075 : ~ @Equation3075 Fin4 reff172_inst.
Proof. unfold Equation3075. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff172_inst, reff172_op in H. discriminate H. Qed.

Lemma reff172_not3076 : ~ @Equation3076 Fin4 reff172_inst.
Proof. unfold Equation3076. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff172_inst, reff172_op in H. discriminate H. Qed.

Lemma reff172_not3078 : ~ @Equation3078 Fin4 reff172_inst.
Proof. unfold Equation3078. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff172_inst, reff172_op in H. discriminate H. Qed.

Lemma reff172_not3079 : ~ @Equation3079 Fin4 reff172_inst.
Proof. unfold Equation3079. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff172_inst, reff172_op in H. discriminate H. Qed.

Lemma reff172_not3102 : ~ @Equation3102 Fin4 reff172_inst.
Proof. unfold Equation3102. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff172_inst, reff172_op in H. discriminate H. Qed.

Lemma reff172_not3103 : ~ @Equation3103 Fin4 reff172_inst.
Proof. unfold Equation3103. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff172_inst, reff172_op in H. discriminate H. Qed.

Lemma reff172_not3105 : ~ @Equation3105 Fin4 reff172_inst.
Proof. unfold Equation3105. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff172_inst, reff172_op in H. discriminate H. Qed.

Lemma reff172_not3106 : ~ @Equation3106 Fin4 reff172_inst.
Proof. unfold Equation3106. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff172_inst, reff172_op in H. discriminate H. Qed.

Lemma reff172_not3112 : ~ @Equation3112 Fin4 reff172_inst.
Proof. unfold Equation3112. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff172_inst, reff172_op in H. discriminate H. Qed.

Lemma reff172_not3113 : ~ @Equation3113 Fin4 reff172_inst.
Proof. unfold Equation3113. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff172_inst, reff172_op in H. discriminate H. Qed.

Lemma reff172_not3115 : ~ @Equation3115 Fin4 reff172_inst.
Proof. unfold Equation3115. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff172_inst, reff172_op in H. discriminate H. Qed.

Lemma reff172_not3116 : ~ @Equation3116 Fin4 reff172_inst.
Proof. unfold Equation3116. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff172_inst, reff172_op in H. discriminate H. Qed.

Lemma reff172_not3139 : ~ @Equation3139 Fin4 reff172_inst.
Proof. unfold Equation3139. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff172_inst, reff172_op in H. discriminate H. Qed.

Lemma reff172_not3140 : ~ @Equation3140 Fin4 reff172_inst.
Proof. unfold Equation3140. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff172_inst, reff172_op in H. discriminate H. Qed.

Lemma reff172_not3142 : ~ @Equation3142 Fin4 reff172_inst.
Proof. unfold Equation3142. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff172_inst, reff172_op in H. discriminate H. Qed.

Lemma reff172_not3143 : ~ @Equation3143 Fin4 reff172_inst.
Proof. unfold Equation3143. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff172_inst, reff172_op in H. discriminate H. Qed.

Lemma reff172_not3149 : ~ @Equation3149 Fin4 reff172_inst.
Proof. unfold Equation3149. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff172_inst, reff172_op in H. discriminate H. Qed.

Lemma reff172_not3150 : ~ @Equation3150 Fin4 reff172_inst.
Proof. unfold Equation3150. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff172_inst, reff172_op in H. discriminate H. Qed.

Lemma reff172_not3152 : ~ @Equation3152 Fin4 reff172_inst.
Proof. unfold Equation3152. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff172_inst, reff172_op in H. discriminate H. Qed.

Lemma reff172_not3254 : ~ @Equation3254 Fin4 reff172_inst.
Proof. unfold Equation3254. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff172_inst, reff172_op in H. discriminate H. Qed.

Lemma reff172_not3255 : ~ @Equation3255 Fin4 reff172_inst.
Proof. unfold Equation3255. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff172_inst, reff172_op in H. discriminate H. Qed.

Lemma reff172_not3256 : ~ @Equation3256 Fin4 reff172_inst.
Proof. unfold Equation3256. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff172_inst, reff172_op in H. discriminate H. Qed.

Lemma reff172_not3258 : ~ @Equation3258 Fin4 reff172_inst.
Proof. unfold Equation3258. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff172_inst, reff172_op in H. discriminate H. Qed.

Lemma reff172_not3259 : ~ @Equation3259 Fin4 reff172_inst.
Proof. unfold Equation3259. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff172_inst, reff172_op in H. discriminate H. Qed.

Lemma reff172_not3262 : ~ @Equation3262 Fin4 reff172_inst.
Proof. unfold Equation3262. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff172_inst, reff172_op in H. discriminate H. Qed.

Lemma reff172_not3268 : ~ @Equation3268 Fin4 reff172_inst.
Proof. unfold Equation3268. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff172_inst, reff172_op in H. discriminate H. Qed.

Lemma reff172_not3269 : ~ @Equation3269 Fin4 reff172_inst.
Proof. unfold Equation3269. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff172_inst, reff172_op in H. discriminate H. Qed.

Lemma reff172_not3272 : ~ @Equation3272 Fin4 reff172_inst.
Proof. unfold Equation3272. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff172_inst, reff172_op in H. discriminate H. Qed.

Lemma reff172_not3279 : ~ @Equation3279 Fin4 reff172_inst.
Proof. unfold Equation3279. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff172_inst, reff172_op in H. discriminate H. Qed.

Lemma reff172_not3281 : ~ @Equation3281 Fin4 reff172_inst.
Proof. unfold Equation3281. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff172_inst, reff172_op in H. discriminate H. Qed.

Lemma reff172_not3308 : ~ @Equation3308 Fin4 reff172_inst.
Proof. unfold Equation3308. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff172_inst, reff172_op in H. discriminate H. Qed.

Lemma reff172_not3309 : ~ @Equation3309 Fin4 reff172_inst.
Proof. unfold Equation3309. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff172_inst, reff172_op in H. discriminate H. Qed.

Lemma reff172_not3315 : ~ @Equation3315 Fin4 reff172_inst.
Proof. unfold Equation3315. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff172_inst, reff172_op in H. discriminate H. Qed.

Lemma reff172_not3316 : ~ @Equation3316 Fin4 reff172_inst.
Proof. unfold Equation3316. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff172_inst, reff172_op in H. discriminate H. Qed.

Lemma reff172_not3318 : ~ @Equation3318 Fin4 reff172_inst.
Proof. unfold Equation3318. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff172_inst, reff172_op in H. discriminate H. Qed.

Lemma reff172_not3342 : ~ @Equation3342 Fin4 reff172_inst.
Proof. unfold Equation3342. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff172_inst, reff172_op in H. discriminate H. Qed.

Lemma reff172_not3343 : ~ @Equation3343 Fin4 reff172_inst.
Proof. unfold Equation3343. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff172_inst, reff172_op in H. discriminate H. Qed.

Lemma reff172_not3345 : ~ @Equation3345 Fin4 reff172_inst.
Proof. unfold Equation3345. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff172_inst, reff172_op in H. discriminate H. Qed.

Lemma reff172_not3352 : ~ @Equation3352 Fin4 reff172_inst.
Proof. unfold Equation3352. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff172_inst, reff172_op in H. discriminate H. Qed.

Lemma reff172_not3457 : ~ @Equation3457 Fin4 reff172_inst.
Proof. unfold Equation3457. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff172_inst, reff172_op in H. discriminate H. Qed.

Lemma reff172_not3458 : ~ @Equation3458 Fin4 reff172_inst.
Proof. unfold Equation3458. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff172_inst, reff172_op in H. discriminate H. Qed.

Lemma reff172_not3459 : ~ @Equation3459 Fin4 reff172_inst.
Proof. unfold Equation3459. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff172_inst, reff172_op in H. discriminate H. Qed.

Lemma reff172_not3461 : ~ @Equation3461 Fin4 reff172_inst.
Proof. unfold Equation3461. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff172_inst, reff172_op in H. discriminate H. Qed.

Lemma reff172_not3462 : ~ @Equation3462 Fin4 reff172_inst.
Proof. unfold Equation3462. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff172_inst, reff172_op in H. discriminate H. Qed.

Lemma reff172_not3464 : ~ @Equation3464 Fin4 reff172_inst.
Proof. unfold Equation3464. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff172_inst, reff172_op in H. discriminate H. Qed.

Lemma reff172_not3465 : ~ @Equation3465 Fin4 reff172_inst.
Proof. unfold Equation3465. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff172_inst, reff172_op in H. discriminate H. Qed.

Lemma reff172_not3472 : ~ @Equation3472 Fin4 reff172_inst.
Proof. unfold Equation3472. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff172_inst, reff172_op in H. discriminate H. Qed.

Lemma reff172_not3474 : ~ @Equation3474 Fin4 reff172_inst.
Proof. unfold Equation3474. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff172_inst, reff172_op in H. discriminate H. Qed.

Lemma reff172_not3475 : ~ @Equation3475 Fin4 reff172_inst.
Proof. unfold Equation3475. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff172_inst, reff172_op in H. discriminate H. Qed.

Lemma reff172_not3482 : ~ @Equation3482 Fin4 reff172_inst.
Proof. unfold Equation3482. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff172_inst, reff172_op in H. discriminate H. Qed.

Lemma reff172_not3484 : ~ @Equation3484 Fin4 reff172_inst.
Proof. unfold Equation3484. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff172_inst, reff172_op in H. discriminate H. Qed.

Lemma reff172_not3509 : ~ @Equation3509 Fin4 reff172_inst.
Proof. unfold Equation3509. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff172_inst, reff172_op in H. discriminate H. Qed.

Lemma reff172_not3511 : ~ @Equation3511 Fin4 reff172_inst.
Proof. unfold Equation3511. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff172_inst, reff172_op in H. discriminate H. Qed.

Lemma reff172_not3512 : ~ @Equation3512 Fin4 reff172_inst.
Proof. unfold Equation3512. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff172_inst, reff172_op in H. discriminate H. Qed.

Lemma reff172_not3518 : ~ @Equation3518 Fin4 reff172_inst.
Proof. unfold Equation3518. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff172_inst, reff172_op in H. discriminate H. Qed.

Lemma reff172_not3519 : ~ @Equation3519 Fin4 reff172_inst.
Proof. unfold Equation3519. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff172_inst, reff172_op in H. discriminate H. Qed.

Lemma reff172_not3521 : ~ @Equation3521 Fin4 reff172_inst.
Proof. unfold Equation3521. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff172_inst, reff172_op in H. discriminate H. Qed.

Lemma reff172_not3545 : ~ @Equation3545 Fin4 reff172_inst.
Proof. unfold Equation3545. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff172_inst, reff172_op in H. discriminate H. Qed.

Lemma reff172_not3546 : ~ @Equation3546 Fin4 reff172_inst.
Proof. unfold Equation3546. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff172_inst, reff172_op in H. discriminate H. Qed.

Lemma reff172_not3548 : ~ @Equation3548 Fin4 reff172_inst.
Proof. unfold Equation3548. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff172_inst, reff172_op in H. discriminate H. Qed.

Lemma reff172_not3555 : ~ @Equation3555 Fin4 reff172_inst.
Proof. unfold Equation3555. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff172_inst, reff172_op in H. discriminate H. Qed.

Lemma reff172_not3556 : ~ @Equation3556 Fin4 reff172_inst.
Proof. unfold Equation3556. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff172_inst, reff172_op in H. discriminate H. Qed.

Lemma reff172_not3558 : ~ @Equation3558 Fin4 reff172_inst.
Proof. unfold Equation3558. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff172_inst, reff172_op in H. discriminate H. Qed.

Lemma reff172_not3660 : ~ @Equation3660 Fin4 reff172_inst.
Proof. unfold Equation3660. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff172_inst, reff172_op in H. discriminate H. Qed.

Lemma reff172_not3661 : ~ @Equation3661 Fin4 reff172_inst.
Proof. unfold Equation3661. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff172_inst, reff172_op in H. discriminate H. Qed.

Lemma reff172_not3662 : ~ @Equation3662 Fin4 reff172_inst.
Proof. unfold Equation3662. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff172_inst, reff172_op in H. discriminate H. Qed.

Lemma reff172_not3664 : ~ @Equation3664 Fin4 reff172_inst.
Proof. unfold Equation3664. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff172_inst, reff172_op in H. discriminate H. Qed.

Lemma reff172_not3665 : ~ @Equation3665 Fin4 reff172_inst.
Proof. unfold Equation3665. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff172_inst, reff172_op in H. discriminate H. Qed.

Lemma reff172_not3667 : ~ @Equation3667 Fin4 reff172_inst.
Proof. unfold Equation3667. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff172_inst, reff172_op in H. discriminate H. Qed.

Lemma reff172_not3668 : ~ @Equation3668 Fin4 reff172_inst.
Proof. unfold Equation3668. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff172_inst, reff172_op in H. discriminate H. Qed.

Lemma reff172_not3674 : ~ @Equation3674 Fin4 reff172_inst.
Proof. unfold Equation3674. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff172_inst, reff172_op in H. discriminate H. Qed.

Lemma reff172_not3675 : ~ @Equation3675 Fin4 reff172_inst.
Proof. unfold Equation3675. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff172_inst, reff172_op in H. discriminate H. Qed.

Lemma reff172_not3678 : ~ @Equation3678 Fin4 reff172_inst.
Proof. unfold Equation3678. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff172_inst, reff172_op in H. discriminate H. Qed.

Lemma reff172_not3684 : ~ @Equation3684 Fin4 reff172_inst.
Proof. unfold Equation3684. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff172_inst, reff172_op in H. discriminate H. Qed.

Lemma reff172_not3685 : ~ @Equation3685 Fin4 reff172_inst.
Proof. unfold Equation3685. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff172_inst, reff172_op in H. discriminate H. Qed.

Lemma reff172_not3687 : ~ @Equation3687 Fin4 reff172_inst.
Proof. unfold Equation3687. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff172_inst, reff172_op in H. discriminate H. Qed.

Lemma reff172_not3712 : ~ @Equation3712 Fin4 reff172_inst.
Proof. unfold Equation3712. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff172_inst, reff172_op in H. discriminate H. Qed.

Lemma reff172_not3714 : ~ @Equation3714 Fin4 reff172_inst.
Proof. unfold Equation3714. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff172_inst, reff172_op in H. discriminate H. Qed.

Lemma reff172_not3721 : ~ @Equation3721 Fin4 reff172_inst.
Proof. unfold Equation3721. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff172_inst, reff172_op in H. discriminate H. Qed.

Lemma reff172_not3722 : ~ @Equation3722 Fin4 reff172_inst.
Proof. unfold Equation3722. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff172_inst, reff172_op in H. discriminate H. Qed.

Lemma reff172_not3724 : ~ @Equation3724 Fin4 reff172_inst.
Proof. unfold Equation3724. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff172_inst, reff172_op in H. discriminate H. Qed.

Lemma reff172_not3748 : ~ @Equation3748 Fin4 reff172_inst.
Proof. unfold Equation3748. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff172_inst, reff172_op in H. discriminate H. Qed.

Lemma reff172_not3749 : ~ @Equation3749 Fin4 reff172_inst.
Proof. unfold Equation3749. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff172_inst, reff172_op in H. discriminate H. Qed.

Lemma reff172_not3751 : ~ @Equation3751 Fin4 reff172_inst.
Proof. unfold Equation3751. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff172_inst, reff172_op in H. discriminate H. Qed.

Lemma reff172_not3752 : ~ @Equation3752 Fin4 reff172_inst.
Proof. unfold Equation3752. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff172_inst, reff172_op in H. discriminate H. Qed.

Lemma reff172_not3761 : ~ @Equation3761 Fin4 reff172_inst.
Proof. unfold Equation3761. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff172_inst, reff172_op in H. discriminate H. Qed.

Lemma reff172_not3864 : ~ @Equation3864 Fin4 reff172_inst.
Proof. unfold Equation3864. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff172_inst, reff172_op in H. discriminate H. Qed.

Lemma reff172_not3865 : ~ @Equation3865 Fin4 reff172_inst.
Proof. unfold Equation3865. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff172_inst, reff172_op in H. discriminate H. Qed.

Lemma reff172_not3867 : ~ @Equation3867 Fin4 reff172_inst.
Proof. unfold Equation3867. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff172_inst, reff172_op in H. discriminate H. Qed.

Lemma reff172_not3868 : ~ @Equation3868 Fin4 reff172_inst.
Proof. unfold Equation3868. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff172_inst, reff172_op in H. discriminate H. Qed.

Lemma reff172_not3870 : ~ @Equation3870 Fin4 reff172_inst.
Proof. unfold Equation3870. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff172_inst, reff172_op in H. discriminate H. Qed.

Lemma reff172_not3871 : ~ @Equation3871 Fin4 reff172_inst.
Proof. unfold Equation3871. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff172_inst, reff172_op in H. discriminate H. Qed.

Lemma reff172_not3877 : ~ @Equation3877 Fin4 reff172_inst.
Proof. unfold Equation3877. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff172_inst, reff172_op in H. discriminate H. Qed.

Lemma reff172_not3878 : ~ @Equation3878 Fin4 reff172_inst.
Proof. unfold Equation3878. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff172_inst, reff172_op in H. discriminate H. Qed.

Lemma reff172_not3880 : ~ @Equation3880 Fin4 reff172_inst.
Proof. unfold Equation3880. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff172_inst, reff172_op in H. discriminate H. Qed.

Lemma reff172_not3881 : ~ @Equation3881 Fin4 reff172_inst.
Proof. unfold Equation3881. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff172_inst, reff172_op in H. discriminate H. Qed.

Lemma reff172_not3888 : ~ @Equation3888 Fin4 reff172_inst.
Proof. unfold Equation3888. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff172_inst, reff172_op in H. discriminate H. Qed.

Lemma reff172_not3890 : ~ @Equation3890 Fin4 reff172_inst.
Proof. unfold Equation3890. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff172_inst, reff172_op in H. discriminate H. Qed.

Lemma reff172_not3917 : ~ @Equation3917 Fin4 reff172_inst.
Proof. unfold Equation3917. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff172_inst, reff172_op in H. discriminate H. Qed.

Lemma reff172_not3918 : ~ @Equation3918 Fin4 reff172_inst.
Proof. unfold Equation3918. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff172_inst, reff172_op in H. discriminate H. Qed.

Lemma reff172_not3924 : ~ @Equation3924 Fin4 reff172_inst.
Proof. unfold Equation3924. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff172_inst, reff172_op in H. discriminate H. Qed.

Lemma reff172_not3925 : ~ @Equation3925 Fin4 reff172_inst.
Proof. unfold Equation3925. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff172_inst, reff172_op in H. discriminate H. Qed.

Lemma reff172_not3927 : ~ @Equation3927 Fin4 reff172_inst.
Proof. unfold Equation3927. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff172_inst, reff172_op in H. discriminate H. Qed.

Lemma reff172_not3951 : ~ @Equation3951 Fin4 reff172_inst.
Proof. unfold Equation3951. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff172_inst, reff172_op in H. discriminate H. Qed.

Lemma reff172_not3952 : ~ @Equation3952 Fin4 reff172_inst.
Proof. unfold Equation3952. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff172_inst, reff172_op in H. discriminate H. Qed.

Lemma reff172_not3954 : ~ @Equation3954 Fin4 reff172_inst.
Proof. unfold Equation3954. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff172_inst, reff172_op in H. discriminate H. Qed.

Lemma reff172_not3961 : ~ @Equation3961 Fin4 reff172_inst.
Proof. unfold Equation3961. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff172_inst, reff172_op in H. discriminate H. Qed.

Lemma reff172_not3964 : ~ @Equation3964 Fin4 reff172_inst.
Proof. unfold Equation3964. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff172_inst, reff172_op in H. discriminate H. Qed.

Lemma reff172_not4066 : ~ @Equation4066 Fin4 reff172_inst.
Proof. unfold Equation4066. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff172_inst, reff172_op in H. discriminate H. Qed.

Lemma reff172_not4067 : ~ @Equation4067 Fin4 reff172_inst.
Proof. unfold Equation4067. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff172_inst, reff172_op in H. discriminate H. Qed.

Lemma reff172_not4068 : ~ @Equation4068 Fin4 reff172_inst.
Proof. unfold Equation4068. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff172_inst, reff172_op in H. discriminate H. Qed.

Lemma reff172_not4070 : ~ @Equation4070 Fin4 reff172_inst.
Proof. unfold Equation4070. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff172_inst, reff172_op in H. discriminate H. Qed.

Lemma reff172_not4071 : ~ @Equation4071 Fin4 reff172_inst.
Proof. unfold Equation4071. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff172_inst, reff172_op in H. discriminate H. Qed.

Lemma reff172_not4073 : ~ @Equation4073 Fin4 reff172_inst.
Proof. unfold Equation4073. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff172_inst, reff172_op in H. discriminate H. Qed.

Lemma reff172_not4074 : ~ @Equation4074 Fin4 reff172_inst.
Proof. unfold Equation4074. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff172_inst, reff172_op in H. discriminate H. Qed.

Lemma reff172_not4080 : ~ @Equation4080 Fin4 reff172_inst.
Proof. unfold Equation4080. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff172_inst, reff172_op in H. discriminate H. Qed.

Lemma reff172_not4081 : ~ @Equation4081 Fin4 reff172_inst.
Proof. unfold Equation4081. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff172_inst, reff172_op in H. discriminate H. Qed.

Lemma reff172_not4083 : ~ @Equation4083 Fin4 reff172_inst.
Proof. unfold Equation4083. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff172_inst, reff172_op in H. discriminate H. Qed.

Lemma reff172_not4084 : ~ @Equation4084 Fin4 reff172_inst.
Proof. unfold Equation4084. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff172_inst, reff172_op in H. discriminate H. Qed.

Lemma reff172_not4090 : ~ @Equation4090 Fin4 reff172_inst.
Proof. unfold Equation4090. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff172_inst, reff172_op in H. discriminate H. Qed.

Lemma reff172_not4091 : ~ @Equation4091 Fin4 reff172_inst.
Proof. unfold Equation4091. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff172_inst, reff172_op in H. discriminate H. Qed.

Lemma reff172_not4093 : ~ @Equation4093 Fin4 reff172_inst.
Proof. unfold Equation4093. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff172_inst, reff172_op in H. discriminate H. Qed.

Lemma reff172_not4120 : ~ @Equation4120 Fin4 reff172_inst.
Proof. unfold Equation4120. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff172_inst, reff172_op in H. discriminate H. Qed.

Lemma reff172_not4121 : ~ @Equation4121 Fin4 reff172_inst.
Proof. unfold Equation4121. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff172_inst, reff172_op in H. discriminate H. Qed.

Lemma reff172_not4127 : ~ @Equation4127 Fin4 reff172_inst.
Proof. unfold Equation4127. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff172_inst, reff172_op in H. discriminate H. Qed.

Lemma reff172_not4128 : ~ @Equation4128 Fin4 reff172_inst.
Proof. unfold Equation4128. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff172_inst, reff172_op in H. discriminate H. Qed.

Lemma reff172_not4130 : ~ @Equation4130 Fin4 reff172_inst.
Proof. unfold Equation4130. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff172_inst, reff172_op in H. discriminate H. Qed.

Lemma reff172_not4155 : ~ @Equation4155 Fin4 reff172_inst.
Proof. unfold Equation4155. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff172_inst, reff172_op in H. discriminate H. Qed.

Lemma reff172_not4157 : ~ @Equation4157 Fin4 reff172_inst.
Proof. unfold Equation4157. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff172_inst, reff172_op in H. discriminate H. Qed.

Lemma reff172_not4158 : ~ @Equation4158 Fin4 reff172_inst.
Proof. unfold Equation4158. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff172_inst, reff172_op in H. discriminate H. Qed.

Lemma reff172_not4164 : ~ @Equation4164 Fin4 reff172_inst.
Proof. unfold Equation4164. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff172_inst, reff172_op in H. discriminate H. Qed.

Lemma reff172_not4165 : ~ @Equation4165 Fin4 reff172_inst.
Proof. unfold Equation4165. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff172_inst, reff172_op in H. discriminate H. Qed.

Lemma reff172_not4167 : ~ @Equation4167 Fin4 reff172_inst.
Proof. unfold Equation4167. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff172_inst, reff172_op in H. discriminate H. Qed.

Lemma reff172_not4268 : ~ @Equation4268 Fin4 reff172_inst.
Proof. unfold Equation4268. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff172_inst, reff172_op in H. discriminate H. Qed.

Lemma reff172_not4269 : ~ @Equation4269 Fin4 reff172_inst.
Proof. unfold Equation4269. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff172_inst, reff172_op in H. discriminate H. Qed.

Lemma reff172_not4270 : ~ @Equation4270 Fin4 reff172_inst.
Proof. unfold Equation4270. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff172_inst, reff172_op in H. discriminate H. Qed.

Lemma reff172_not4272 : ~ @Equation4272 Fin4 reff172_inst.
Proof. unfold Equation4272. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff172_inst, reff172_op in H. discriminate H. Qed.

Lemma reff172_not4273 : ~ @Equation4273 Fin4 reff172_inst.
Proof. unfold Equation4273. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff172_inst, reff172_op in H. discriminate H. Qed.

Lemma reff172_not4276 : ~ @Equation4276 Fin4 reff172_inst.
Proof. unfold Equation4276. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff172_inst, reff172_op in H. discriminate H. Qed.

Lemma reff172_not4283 : ~ @Equation4283 Fin4 reff172_inst.
Proof. unfold Equation4283. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff172_inst, reff172_op in H. discriminate H. Qed.

Lemma reff172_not4284 : ~ @Equation4284 Fin4 reff172_inst.
Proof. unfold Equation4284. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff172_inst, reff172_op in H. discriminate H. Qed.

Lemma reff172_not4290 : ~ @Equation4290 Fin4 reff172_inst.
Proof. unfold Equation4290. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff172_inst, reff172_op in H. discriminate H. Qed.

Lemma reff172_not4291 : ~ @Equation4291 Fin4 reff172_inst.
Proof. unfold Equation4291. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff172_inst, reff172_op in H. discriminate H. Qed.

Lemma reff172_not4293 : ~ @Equation4293 Fin4 reff172_inst.
Proof. unfold Equation4293. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff172_inst, reff172_op in H. discriminate H. Qed.

Lemma reff172_not4314 : ~ @Equation4314 Fin4 reff172_inst.
Proof. unfold Equation4314. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff172_inst, reff172_op in H. discriminate H. Qed.

Lemma reff172_not4321 : ~ @Equation4321 Fin4 reff172_inst.
Proof. unfold Equation4321. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff172_inst, reff172_op in H. discriminate H. Qed.

Lemma reff172_not4343 : ~ @Equation4343 Fin4 reff172_inst.
Proof. unfold Equation4343. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff172_inst, reff172_op in H. discriminate H. Qed.

Lemma reff172_not4396 : ~ @Equation4396 Fin4 reff172_inst.
Proof. unfold Equation4396. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff172_inst, reff172_op in H. discriminate H. Qed.

Lemma reff172_not4398 : ~ @Equation4398 Fin4 reff172_inst.
Proof. unfold Equation4398. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff172_inst, reff172_op in H. discriminate H. Qed.

Lemma reff172_not4399 : ~ @Equation4399 Fin4 reff172_inst.
Proof. unfold Equation4399. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff172_inst, reff172_op in H. discriminate H. Qed.

Lemma reff172_not4405 : ~ @Equation4405 Fin4 reff172_inst.
Proof. unfold Equation4405. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff172_inst, reff172_op in H. discriminate H. Qed.

Lemma reff172_not4406 : ~ @Equation4406 Fin4 reff172_inst.
Proof. unfold Equation4406. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff172_inst, reff172_op in H. discriminate H. Qed.

Lemma reff172_not4408 : ~ @Equation4408 Fin4 reff172_inst.
Proof. unfold Equation4408. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff172_inst, reff172_op in H. discriminate H. Qed.

Lemma reff172_not4433 : ~ @Equation4433 Fin4 reff172_inst.
Proof. unfold Equation4433. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff172_inst, reff172_op in H. discriminate H. Qed.

Lemma reff172_not4435 : ~ @Equation4435 Fin4 reff172_inst.
Proof. unfold Equation4435. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff172_inst, reff172_op in H. discriminate H. Qed.

Lemma reff172_not4436 : ~ @Equation4436 Fin4 reff172_inst.
Proof. unfold Equation4436. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff172_inst, reff172_op in H. discriminate H. Qed.

Lemma reff172_not4443 : ~ @Equation4443 Fin4 reff172_inst.
Proof. unfold Equation4443. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff172_inst, reff172_op in H. discriminate H. Qed.

Lemma reff172_not4445 : ~ @Equation4445 Fin4 reff172_inst.
Proof. unfold Equation4445. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff172_inst, reff172_op in H. discriminate H. Qed.

Lemma reff172_not4470 : ~ @Equation4470 Fin4 reff172_inst.
Proof. unfold Equation4470. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff172_inst, reff172_op in H. discriminate H. Qed.

Lemma reff172_not4472 : ~ @Equation4472 Fin4 reff172_inst.
Proof. unfold Equation4472. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff172_inst, reff172_op in H. discriminate H. Qed.

Lemma reff172_not4479 : ~ @Equation4479 Fin4 reff172_inst.
Proof. unfold Equation4479. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff172_inst, reff172_op in H. discriminate H. Qed.

Lemma reff172_not4480 : ~ @Equation4480 Fin4 reff172_inst.
Proof. unfold Equation4480. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff172_inst, reff172_op in H. discriminate H. Qed.

Lemma reff172_not4482 : ~ @Equation4482 Fin4 reff172_inst.
Proof. unfold Equation4482. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff172_inst, reff172_op in H. discriminate H. Qed.

Lemma reff172_not4583 : ~ @Equation4583 Fin4 reff172_inst.
Proof. unfold Equation4583. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff172_inst, reff172_op in H. discriminate H. Qed.

Lemma reff172_not4584 : ~ @Equation4584 Fin4 reff172_inst.
Proof. unfold Equation4584. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff172_inst, reff172_op in H. discriminate H. Qed.

Lemma reff172_not4585 : ~ @Equation4585 Fin4 reff172_inst.
Proof. unfold Equation4585. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff172_inst, reff172_op in H. discriminate H. Qed.

Lemma reff172_not4587 : ~ @Equation4587 Fin4 reff172_inst.
Proof. unfold Equation4587. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff172_inst, reff172_op in H. discriminate H. Qed.

Lemma reff172_not4588 : ~ @Equation4588 Fin4 reff172_inst.
Proof. unfold Equation4588. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff172_inst, reff172_op in H. discriminate H. Qed.

Lemma reff172_not4590 : ~ @Equation4590 Fin4 reff172_inst.
Proof. unfold Equation4590. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff172_inst, reff172_op in H. discriminate H. Qed.

Lemma reff172_not4591 : ~ @Equation4591 Fin4 reff172_inst.
Proof. unfold Equation4591. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff172_inst, reff172_op in H. discriminate H. Qed.

Lemma reff172_not4598 : ~ @Equation4598 Fin4 reff172_inst.
Proof. unfold Equation4598. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff172_inst, reff172_op in H. discriminate H. Qed.

Lemma reff172_not4599 : ~ @Equation4599 Fin4 reff172_inst.
Proof. unfold Equation4599. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff172_inst, reff172_op in H. discriminate H. Qed.

Lemma reff172_not4605 : ~ @Equation4605 Fin4 reff172_inst.
Proof. unfold Equation4605. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff172_inst, reff172_op in H. discriminate H. Qed.

Lemma reff172_not4606 : ~ @Equation4606 Fin4 reff172_inst.
Proof. unfold Equation4606. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff172_inst, reff172_op in H. discriminate H. Qed.

Lemma reff172_not4608 : ~ @Equation4608 Fin4 reff172_inst.
Proof. unfold Equation4608. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff172_inst, reff172_op in H. discriminate H. Qed.

Lemma reff172_not4629 : ~ @Equation4629 Fin4 reff172_inst.
Proof. unfold Equation4629. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff172_inst, reff172_op in H. discriminate H. Qed.

Lemma reff172_not4635 : ~ @Equation4635 Fin4 reff172_inst.
Proof. unfold Equation4635. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff172_inst, reff172_op in H. discriminate H. Qed.

Lemma reff172_not4636 : ~ @Equation4636 Fin4 reff172_inst.
Proof. unfold Equation4636. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff172_inst, reff172_op in H. discriminate H. Qed.

Lemma reff172_not4658 : ~ @Equation4658 Fin4 reff172_inst.
Proof. unfold Equation4658. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff172_inst, reff172_op in H. discriminate H. Qed.

(** ---- reff174 (Fin4) ---- *)

Definition reff174_op (x y : Fin4) : Fin4 :=
  match x, y with
  | F4_0, F4_0 => F4_0 | F4_0, F4_1 => F4_1 | F4_0, F4_2 => F4_2 | F4_0, F4_3 => F4_3
  | F4_1, F4_0 => F4_0 | F4_1, F4_1 => F4_2 | F4_1, F4_2 => F4_0 | F4_1, F4_3 => F4_2
  | F4_2, F4_0 => F4_2 | F4_2, F4_1 => F4_1 | F4_2, F4_2 => F4_0 | F4_2, F4_3 => F4_3
  | F4_3, F4_0 => F4_2 | F4_3, F4_1 => F4_2 | F4_3, F4_2 => F4_2 | F4_3, F4_3 => F4_2
  end.

#[local] Instance reff174_inst : Magma Fin4 := {| magma_op := reff174_op |}.

Lemma reff174_sat23 : @Equation23 Fin4 reff174_inst.
Proof. unfold Equation23, magma_op, reff174_inst, reff174_op. intros x. destruct x; reflexivity. Qed.

Lemma reff174_sat1731 : @Equation1731 Fin4 reff174_inst.
Proof. unfold Equation1731, magma_op, reff174_inst, reff174_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff174_sat2238 : @Equation2238 Fin4 reff174_inst.
Proof. unfold Equation2238, magma_op, reff174_inst, reff174_op. intros x. destruct x; reflexivity. Qed.

Lemma reff174_sat2706 : @Equation2706 Fin4 reff174_inst.
Proof. unfold Equation2706, magma_op, reff174_inst, reff174_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff174_sat2746 : @Equation2746 Fin4 reff174_inst.
Proof. unfold Equation2746, magma_op, reff174_inst, reff174_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff174_sat3509 : @Equation3509 Fin4 reff174_inst.
Proof. unfold Equation3509, magma_op, reff174_inst, reff174_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff174_sat4165 : @Equation4165 Fin4 reff174_inst.
Proof. unfold Equation4165, magma_op, reff174_inst, reff174_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff174_not47 : ~ @Equation47 Fin4 reff174_inst.
Proof. unfold Equation47. intro H. specialize (H F4_1). unfold magma_op, reff174_inst, reff174_op in H. discriminate H. Qed.

Lemma reff174_not99 : ~ @Equation99 Fin4 reff174_inst.
Proof. unfold Equation99. intro H. specialize (H F4_1). unfold magma_op, reff174_inst, reff174_op in H. discriminate H. Qed.

Lemma reff174_not151 : ~ @Equation151 Fin4 reff174_inst.
Proof. unfold Equation151. intro H. specialize (H F4_1). unfold magma_op, reff174_inst, reff174_op in H. discriminate H. Qed.

Lemma reff174_not203 : ~ @Equation203 Fin4 reff174_inst.
Proof. unfold Equation203. intro H. specialize (H F4_2). unfold magma_op, reff174_inst, reff174_op in H. discriminate H. Qed.

Lemma reff174_not255 : ~ @Equation255 Fin4 reff174_inst.
Proof. unfold Equation255. intro H. specialize (H F4_1). unfold magma_op, reff174_inst, reff174_op in H. discriminate H. Qed.

Lemma reff174_not359 : ~ @Equation359 Fin4 reff174_inst.
Proof. unfold Equation359. intro H. specialize (H F4_1). unfold magma_op, reff174_inst, reff174_op in H. discriminate H. Qed.

Lemma reff174_not411 : ~ @Equation411 Fin4 reff174_inst.
Proof. unfold Equation411. intro H. specialize (H F4_1). unfold magma_op, reff174_inst, reff174_op in H. discriminate H. Qed.

Lemma reff174_not614 : ~ @Equation614 Fin4 reff174_inst.
Proof. unfold Equation614. intro H. specialize (H F4_1). unfold magma_op, reff174_inst, reff174_op in H. discriminate H. Qed.

Lemma reff174_not817 : ~ @Equation817 Fin4 reff174_inst.
Proof. unfold Equation817. intro H. specialize (H F4_1). unfold magma_op, reff174_inst, reff174_op in H. discriminate H. Qed.

Lemma reff174_not1020 : ~ @Equation1020 Fin4 reff174_inst.
Proof. unfold Equation1020. intro H. specialize (H F4_1). unfold magma_op, reff174_inst, reff174_op in H. discriminate H. Qed.

Lemma reff174_not1223 : ~ @Equation1223 Fin4 reff174_inst.
Proof. unfold Equation1223. intro H. specialize (H F4_1). unfold magma_op, reff174_inst, reff174_op in H. discriminate H. Qed.

Lemma reff174_not1426 : ~ @Equation1426 Fin4 reff174_inst.
Proof. unfold Equation1426. intro H. specialize (H F4_1). unfold magma_op, reff174_inst, reff174_op in H. discriminate H. Qed.

Lemma reff174_not1630 : ~ @Equation1630 Fin4 reff174_inst.
Proof. unfold Equation1630. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff174_inst, reff174_op in H. discriminate H. Qed.

Lemma reff174_not1631 : ~ @Equation1631 Fin4 reff174_inst.
Proof. unfold Equation1631. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff174_inst, reff174_op in H. discriminate H. Qed.

Lemma reff174_not1632 : ~ @Equation1632 Fin4 reff174_inst.
Proof. unfold Equation1632. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff174_inst, reff174_op in H. discriminate H. Qed.

Lemma reff174_not1634 : ~ @Equation1634 Fin4 reff174_inst.
Proof. unfold Equation1634. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff174_inst, reff174_op in H. discriminate H. Qed.

Lemma reff174_not1635 : ~ @Equation1635 Fin4 reff174_inst.
Proof. unfold Equation1635. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff174_inst, reff174_op in H. discriminate H. Qed.

Lemma reff174_not1637 : ~ @Equation1637 Fin4 reff174_inst.
Proof. unfold Equation1637. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff174_inst, reff174_op in H. discriminate H. Qed.

Lemma reff174_not1638 : ~ @Equation1638 Fin4 reff174_inst.
Proof. unfold Equation1638. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff174_inst, reff174_op in H. discriminate H. Qed.

Lemma reff174_not1644 : ~ @Equation1644 Fin4 reff174_inst.
Proof. unfold Equation1644. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff174_inst, reff174_op in H. discriminate H. Qed.

Lemma reff174_not1645 : ~ @Equation1645 Fin4 reff174_inst.
Proof. unfold Equation1645. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff174_inst, reff174_op in H. discriminate H. Qed.

Lemma reff174_not1647 : ~ @Equation1647 Fin4 reff174_inst.
Proof. unfold Equation1647. intro H. specialize (H F4_0 F4_3). unfold magma_op, reff174_inst, reff174_op in H. discriminate H. Qed.

Lemma reff174_not1648 : ~ @Equation1648 Fin4 reff174_inst.
Proof. unfold Equation1648. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff174_inst, reff174_op in H. discriminate H. Qed.

Lemma reff174_not1654 : ~ @Equation1654 Fin4 reff174_inst.
Proof. unfold Equation1654. intro H. specialize (H F4_0 F4_3). unfold magma_op, reff174_inst, reff174_op in H. discriminate H. Qed.

Lemma reff174_not1655 : ~ @Equation1655 Fin4 reff174_inst.
Proof. unfold Equation1655. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff174_inst, reff174_op in H. discriminate H. Qed.

Lemma reff174_not1657 : ~ @Equation1657 Fin4 reff174_inst.
Proof. unfold Equation1657. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff174_inst, reff174_op in H. discriminate H. Qed.

Lemma reff174_not1658 : ~ @Equation1658 Fin4 reff174_inst.
Proof. unfold Equation1658. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff174_inst, reff174_op in H. discriminate H. Qed.

Lemma reff174_not1681 : ~ @Equation1681 Fin4 reff174_inst.
Proof. unfold Equation1681. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff174_inst, reff174_op in H. discriminate H. Qed.

Lemma reff174_not1682 : ~ @Equation1682 Fin4 reff174_inst.
Proof. unfold Equation1682. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff174_inst, reff174_op in H. discriminate H. Qed.

Lemma reff174_not1684 : ~ @Equation1684 Fin4 reff174_inst.
Proof. unfold Equation1684. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff174_inst, reff174_op in H. discriminate H. Qed.

Lemma reff174_not1685 : ~ @Equation1685 Fin4 reff174_inst.
Proof. unfold Equation1685. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff174_inst, reff174_op in H. discriminate H. Qed.

Lemma reff174_not1691 : ~ @Equation1691 Fin4 reff174_inst.
Proof. unfold Equation1691. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff174_inst, reff174_op in H. discriminate H. Qed.

Lemma reff174_not1692 : ~ @Equation1692 Fin4 reff174_inst.
Proof. unfold Equation1692. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff174_inst, reff174_op in H. discriminate H. Qed.

Lemma reff174_not1694 : ~ @Equation1694 Fin4 reff174_inst.
Proof. unfold Equation1694. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff174_inst, reff174_op in H. discriminate H. Qed.

Lemma reff174_not1695 : ~ @Equation1695 Fin4 reff174_inst.
Proof. unfold Equation1695. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff174_inst, reff174_op in H. discriminate H. Qed.

Lemma reff174_not1718 : ~ @Equation1718 Fin4 reff174_inst.
Proof. unfold Equation1718. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff174_inst, reff174_op in H. discriminate H. Qed.

Lemma reff174_not1719 : ~ @Equation1719 Fin4 reff174_inst.
Proof. unfold Equation1719. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff174_inst, reff174_op in H. discriminate H. Qed.

Lemma reff174_not1721 : ~ @Equation1721 Fin4 reff174_inst.
Proof. unfold Equation1721. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff174_inst, reff174_op in H. discriminate H. Qed.

Lemma reff174_not1722 : ~ @Equation1722 Fin4 reff174_inst.
Proof. unfold Equation1722. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff174_inst, reff174_op in H. discriminate H. Qed.

Lemma reff174_not1728 : ~ @Equation1728 Fin4 reff174_inst.
Proof. unfold Equation1728. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff174_inst, reff174_op in H. discriminate H. Qed.

Lemma reff174_not1729 : ~ @Equation1729 Fin4 reff174_inst.
Proof. unfold Equation1729. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff174_inst, reff174_op in H. discriminate H. Qed.

Lemma reff174_not1832 : ~ @Equation1832 Fin4 reff174_inst.
Proof. unfold Equation1832. intro H. specialize (H F4_1). unfold magma_op, reff174_inst, reff174_op in H. discriminate H. Qed.

Lemma reff174_not2035 : ~ @Equation2035 Fin4 reff174_inst.
Proof. unfold Equation2035. intro H. specialize (H F4_1). unfold magma_op, reff174_inst, reff174_op in H. discriminate H. Qed.

Lemma reff174_not2239 : ~ @Equation2239 Fin4 reff174_inst.
Proof. unfold Equation2239. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff174_inst, reff174_op in H. discriminate H. Qed.

Lemma reff174_not2240 : ~ @Equation2240 Fin4 reff174_inst.
Proof. unfold Equation2240. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff174_inst, reff174_op in H. discriminate H. Qed.

Lemma reff174_not2241 : ~ @Equation2241 Fin4 reff174_inst.
Proof. unfold Equation2241. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff174_inst, reff174_op in H. discriminate H. Qed.

Lemma reff174_not2243 : ~ @Equation2243 Fin4 reff174_inst.
Proof. unfold Equation2243. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff174_inst, reff174_op in H. discriminate H. Qed.

Lemma reff174_not2244 : ~ @Equation2244 Fin4 reff174_inst.
Proof. unfold Equation2244. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff174_inst, reff174_op in H. discriminate H. Qed.

Lemma reff174_not2246 : ~ @Equation2246 Fin4 reff174_inst.
Proof. unfold Equation2246. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff174_inst, reff174_op in H. discriminate H. Qed.

Lemma reff174_not2247 : ~ @Equation2247 Fin4 reff174_inst.
Proof. unfold Equation2247. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff174_inst, reff174_op in H. discriminate H. Qed.

Lemma reff174_not2253 : ~ @Equation2253 Fin4 reff174_inst.
Proof. unfold Equation2253. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff174_inst, reff174_op in H. discriminate H. Qed.

Lemma reff174_not2254 : ~ @Equation2254 Fin4 reff174_inst.
Proof. unfold Equation2254. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff174_inst, reff174_op in H. discriminate H. Qed.

Lemma reff174_not2256 : ~ @Equation2256 Fin4 reff174_inst.
Proof. unfold Equation2256. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff174_inst, reff174_op in H. discriminate H. Qed.

Lemma reff174_not2257 : ~ @Equation2257 Fin4 reff174_inst.
Proof. unfold Equation2257. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff174_inst, reff174_op in H. discriminate H. Qed.

Lemma reff174_not2263 : ~ @Equation2263 Fin4 reff174_inst.
Proof. unfold Equation2263. intro H. specialize (H F4_0 F4_3). unfold magma_op, reff174_inst, reff174_op in H. discriminate H. Qed.

Lemma reff174_not2264 : ~ @Equation2264 Fin4 reff174_inst.
Proof. unfold Equation2264. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff174_inst, reff174_op in H. discriminate H. Qed.

Lemma reff174_not2266 : ~ @Equation2266 Fin4 reff174_inst.
Proof. unfold Equation2266. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff174_inst, reff174_op in H. discriminate H. Qed.

Lemma reff174_not2267 : ~ @Equation2267 Fin4 reff174_inst.
Proof. unfold Equation2267. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff174_inst, reff174_op in H. discriminate H. Qed.

Lemma reff174_not2290 : ~ @Equation2290 Fin4 reff174_inst.
Proof. unfold Equation2290. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff174_inst, reff174_op in H. discriminate H. Qed.

Lemma reff174_not2291 : ~ @Equation2291 Fin4 reff174_inst.
Proof. unfold Equation2291. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff174_inst, reff174_op in H. discriminate H. Qed.

Lemma reff174_not2293 : ~ @Equation2293 Fin4 reff174_inst.
Proof. unfold Equation2293. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff174_inst, reff174_op in H. discriminate H. Qed.

Lemma reff174_not2294 : ~ @Equation2294 Fin4 reff174_inst.
Proof. unfold Equation2294. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff174_inst, reff174_op in H. discriminate H. Qed.

Lemma reff174_not2300 : ~ @Equation2300 Fin4 reff174_inst.
Proof. unfold Equation2300. intro H. specialize (H F4_0 F4_3). unfold magma_op, reff174_inst, reff174_op in H. discriminate H. Qed.

Lemma reff174_not2301 : ~ @Equation2301 Fin4 reff174_inst.
Proof. unfold Equation2301. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff174_inst, reff174_op in H. discriminate H. Qed.

Lemma reff174_not2303 : ~ @Equation2303 Fin4 reff174_inst.
Proof. unfold Equation2303. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff174_inst, reff174_op in H. discriminate H. Qed.

Lemma reff174_not2304 : ~ @Equation2304 Fin4 reff174_inst.
Proof. unfold Equation2304. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff174_inst, reff174_op in H. discriminate H. Qed.

Lemma reff174_not2327 : ~ @Equation2327 Fin4 reff174_inst.
Proof. unfold Equation2327. intro H. specialize (H F4_0 F4_3). unfold magma_op, reff174_inst, reff174_op in H. discriminate H. Qed.

Lemma reff174_not2328 : ~ @Equation2328 Fin4 reff174_inst.
Proof. unfold Equation2328. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff174_inst, reff174_op in H. discriminate H. Qed.

Lemma reff174_not2330 : ~ @Equation2330 Fin4 reff174_inst.
Proof. unfold Equation2330. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff174_inst, reff174_op in H. discriminate H. Qed.

Lemma reff174_not2331 : ~ @Equation2331 Fin4 reff174_inst.
Proof. unfold Equation2331. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff174_inst, reff174_op in H. discriminate H. Qed.

Lemma reff174_not2337 : ~ @Equation2337 Fin4 reff174_inst.
Proof. unfold Equation2337. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff174_inst, reff174_op in H. discriminate H. Qed.

Lemma reff174_not2338 : ~ @Equation2338 Fin4 reff174_inst.
Proof. unfold Equation2338. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff174_inst, reff174_op in H. discriminate H. Qed.

Lemma reff174_not2340 : ~ @Equation2340 Fin4 reff174_inst.
Proof. unfold Equation2340. intro H. specialize (H F4_0 F4_3). unfold magma_op, reff174_inst, reff174_op in H. discriminate H. Qed.

Lemma reff174_not2442 : ~ @Equation2442 Fin4 reff174_inst.
Proof. unfold Equation2442. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff174_inst, reff174_op in H. discriminate H. Qed.

Lemma reff174_not2443 : ~ @Equation2443 Fin4 reff174_inst.
Proof. unfold Equation2443. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff174_inst, reff174_op in H. discriminate H. Qed.

Lemma reff174_not2444 : ~ @Equation2444 Fin4 reff174_inst.
Proof. unfold Equation2444. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff174_inst, reff174_op in H. discriminate H. Qed.

Lemma reff174_not2446 : ~ @Equation2446 Fin4 reff174_inst.
Proof. unfold Equation2446. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff174_inst, reff174_op in H. discriminate H. Qed.

Lemma reff174_not2447 : ~ @Equation2447 Fin4 reff174_inst.
Proof. unfold Equation2447. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff174_inst, reff174_op in H. discriminate H. Qed.

Lemma reff174_not2449 : ~ @Equation2449 Fin4 reff174_inst.
Proof. unfold Equation2449. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff174_inst, reff174_op in H. discriminate H. Qed.

Lemma reff174_not2450 : ~ @Equation2450 Fin4 reff174_inst.
Proof. unfold Equation2450. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff174_inst, reff174_op in H. discriminate H. Qed.

Lemma reff174_not2456 : ~ @Equation2456 Fin4 reff174_inst.
Proof. unfold Equation2456. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff174_inst, reff174_op in H. discriminate H. Qed.

Lemma reff174_not2457 : ~ @Equation2457 Fin4 reff174_inst.
Proof. unfold Equation2457. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff174_inst, reff174_op in H. discriminate H. Qed.

Lemma reff174_not2459 : ~ @Equation2459 Fin4 reff174_inst.
Proof. unfold Equation2459. intro H. specialize (H F4_0 F4_3). unfold magma_op, reff174_inst, reff174_op in H. discriminate H. Qed.

Lemma reff174_not2460 : ~ @Equation2460 Fin4 reff174_inst.
Proof. unfold Equation2460. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff174_inst, reff174_op in H. discriminate H. Qed.

Lemma reff174_not2466 : ~ @Equation2466 Fin4 reff174_inst.
Proof. unfold Equation2466. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff174_inst, reff174_op in H. discriminate H. Qed.

Lemma reff174_not2467 : ~ @Equation2467 Fin4 reff174_inst.
Proof. unfold Equation2467. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff174_inst, reff174_op in H. discriminate H. Qed.

Lemma reff174_not2469 : ~ @Equation2469 Fin4 reff174_inst.
Proof. unfold Equation2469. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff174_inst, reff174_op in H. discriminate H. Qed.

Lemma reff174_not2470 : ~ @Equation2470 Fin4 reff174_inst.
Proof. unfold Equation2470. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff174_inst, reff174_op in H. discriminate H. Qed.

Lemma reff174_not2493 : ~ @Equation2493 Fin4 reff174_inst.
Proof. unfold Equation2493. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff174_inst, reff174_op in H. discriminate H. Qed.

Lemma reff174_not2494 : ~ @Equation2494 Fin4 reff174_inst.
Proof. unfold Equation2494. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff174_inst, reff174_op in H. discriminate H. Qed.

Lemma reff174_not2496 : ~ @Equation2496 Fin4 reff174_inst.
Proof. unfold Equation2496. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff174_inst, reff174_op in H. discriminate H. Qed.

Lemma reff174_not2497 : ~ @Equation2497 Fin4 reff174_inst.
Proof. unfold Equation2497. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff174_inst, reff174_op in H. discriminate H. Qed.

Lemma reff174_not2503 : ~ @Equation2503 Fin4 reff174_inst.
Proof. unfold Equation2503. intro H. specialize (H F4_0 F4_3). unfold magma_op, reff174_inst, reff174_op in H. discriminate H. Qed.

Lemma reff174_not2504 : ~ @Equation2504 Fin4 reff174_inst.
Proof. unfold Equation2504. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff174_inst, reff174_op in H. discriminate H. Qed.

Lemma reff174_not2506 : ~ @Equation2506 Fin4 reff174_inst.
Proof. unfold Equation2506. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff174_inst, reff174_op in H. discriminate H. Qed.

Lemma reff174_not2507 : ~ @Equation2507 Fin4 reff174_inst.
Proof. unfold Equation2507. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff174_inst, reff174_op in H. discriminate H. Qed.

Lemma reff174_not2530 : ~ @Equation2530 Fin4 reff174_inst.
Proof. unfold Equation2530. intro H. specialize (H F4_0 F4_3). unfold magma_op, reff174_inst, reff174_op in H. discriminate H. Qed.

Lemma reff174_not2531 : ~ @Equation2531 Fin4 reff174_inst.
Proof. unfold Equation2531. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff174_inst, reff174_op in H. discriminate H. Qed.

Lemma reff174_not2533 : ~ @Equation2533 Fin4 reff174_inst.
Proof. unfold Equation2533. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff174_inst, reff174_op in H. discriminate H. Qed.

Lemma reff174_not2534 : ~ @Equation2534 Fin4 reff174_inst.
Proof. unfold Equation2534. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff174_inst, reff174_op in H. discriminate H. Qed.

Lemma reff174_not2540 : ~ @Equation2540 Fin4 reff174_inst.
Proof. unfold Equation2540. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff174_inst, reff174_op in H. discriminate H. Qed.

Lemma reff174_not2541 : ~ @Equation2541 Fin4 reff174_inst.
Proof. unfold Equation2541. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff174_inst, reff174_op in H. discriminate H. Qed.

Lemma reff174_not2543 : ~ @Equation2543 Fin4 reff174_inst.
Proof. unfold Equation2543. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff174_inst, reff174_op in H. discriminate H. Qed.

Lemma reff174_not2645 : ~ @Equation2645 Fin4 reff174_inst.
Proof. unfold Equation2645. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff174_inst, reff174_op in H. discriminate H. Qed.

Lemma reff174_not2646 : ~ @Equation2646 Fin4 reff174_inst.
Proof. unfold Equation2646. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff174_inst, reff174_op in H. discriminate H. Qed.

Lemma reff174_not2647 : ~ @Equation2647 Fin4 reff174_inst.
Proof. unfold Equation2647. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff174_inst, reff174_op in H. discriminate H. Qed.

Lemma reff174_not2649 : ~ @Equation2649 Fin4 reff174_inst.
Proof. unfold Equation2649. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff174_inst, reff174_op in H. discriminate H. Qed.

Lemma reff174_not2650 : ~ @Equation2650 Fin4 reff174_inst.
Proof. unfold Equation2650. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff174_inst, reff174_op in H. discriminate H. Qed.

Lemma reff174_not2652 : ~ @Equation2652 Fin4 reff174_inst.
Proof. unfold Equation2652. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff174_inst, reff174_op in H. discriminate H. Qed.

Lemma reff174_not2653 : ~ @Equation2653 Fin4 reff174_inst.
Proof. unfold Equation2653. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff174_inst, reff174_op in H. discriminate H. Qed.

Lemma reff174_not2659 : ~ @Equation2659 Fin4 reff174_inst.
Proof. unfold Equation2659. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff174_inst, reff174_op in H. discriminate H. Qed.

Lemma reff174_not2660 : ~ @Equation2660 Fin4 reff174_inst.
Proof. unfold Equation2660. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff174_inst, reff174_op in H. discriminate H. Qed.

Lemma reff174_not2662 : ~ @Equation2662 Fin4 reff174_inst.
Proof. unfold Equation2662. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff174_inst, reff174_op in H. discriminate H. Qed.

Lemma reff174_not2663 : ~ @Equation2663 Fin4 reff174_inst.
Proof. unfold Equation2663. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff174_inst, reff174_op in H. discriminate H. Qed.

Lemma reff174_not2669 : ~ @Equation2669 Fin4 reff174_inst.
Proof. unfold Equation2669. intro H. specialize (H F4_0 F4_3). unfold magma_op, reff174_inst, reff174_op in H. discriminate H. Qed.

Lemma reff174_not2670 : ~ @Equation2670 Fin4 reff174_inst.
Proof. unfold Equation2670. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff174_inst, reff174_op in H. discriminate H. Qed.

Lemma reff174_not2672 : ~ @Equation2672 Fin4 reff174_inst.
Proof. unfold Equation2672. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff174_inst, reff174_op in H. discriminate H. Qed.

Lemma reff174_not2673 : ~ @Equation2673 Fin4 reff174_inst.
Proof. unfold Equation2673. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff174_inst, reff174_op in H. discriminate H. Qed.

Lemma reff174_not2696 : ~ @Equation2696 Fin4 reff174_inst.
Proof. unfold Equation2696. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff174_inst, reff174_op in H. discriminate H. Qed.

Lemma reff174_not2697 : ~ @Equation2697 Fin4 reff174_inst.
Proof. unfold Equation2697. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff174_inst, reff174_op in H. discriminate H. Qed.

Lemma reff174_not2699 : ~ @Equation2699 Fin4 reff174_inst.
Proof. unfold Equation2699. intro H. specialize (H F4_0 F4_3). unfold magma_op, reff174_inst, reff174_op in H. discriminate H. Qed.

Lemma reff174_not2700 : ~ @Equation2700 Fin4 reff174_inst.
Proof. unfold Equation2700. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff174_inst, reff174_op in H. discriminate H. Qed.

Lemma reff174_not2707 : ~ @Equation2707 Fin4 reff174_inst.
Proof. unfold Equation2707. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff174_inst, reff174_op in H. discriminate H. Qed.

Lemma reff174_not2709 : ~ @Equation2709 Fin4 reff174_inst.
Proof. unfold Equation2709. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff174_inst, reff174_op in H. discriminate H. Qed.

Lemma reff174_not2710 : ~ @Equation2710 Fin4 reff174_inst.
Proof. unfold Equation2710. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff174_inst, reff174_op in H. discriminate H. Qed.

Lemma reff174_not2733 : ~ @Equation2733 Fin4 reff174_inst.
Proof. unfold Equation2733. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff174_inst, reff174_op in H. discriminate H. Qed.

Lemma reff174_not2734 : ~ @Equation2734 Fin4 reff174_inst.
Proof. unfold Equation2734. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff174_inst, reff174_op in H. discriminate H. Qed.

Lemma reff174_not2736 : ~ @Equation2736 Fin4 reff174_inst.
Proof. unfold Equation2736. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff174_inst, reff174_op in H. discriminate H. Qed.

Lemma reff174_not2737 : ~ @Equation2737 Fin4 reff174_inst.
Proof. unfold Equation2737. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff174_inst, reff174_op in H. discriminate H. Qed.

Lemma reff174_not2743 : ~ @Equation2743 Fin4 reff174_inst.
Proof. unfold Equation2743. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff174_inst, reff174_op in H. discriminate H. Qed.

Lemma reff174_not2744 : ~ @Equation2744 Fin4 reff174_inst.
Proof. unfold Equation2744. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff174_inst, reff174_op in H. discriminate H. Qed.

Lemma reff174_not2847 : ~ @Equation2847 Fin4 reff174_inst.
Proof. unfold Equation2847. intro H. specialize (H F4_1). unfold magma_op, reff174_inst, reff174_op in H. discriminate H. Qed.

Lemma reff174_not3051 : ~ @Equation3051 Fin4 reff174_inst.
Proof. unfold Equation3051. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff174_inst, reff174_op in H. discriminate H. Qed.

Lemma reff174_not3052 : ~ @Equation3052 Fin4 reff174_inst.
Proof. unfold Equation3052. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff174_inst, reff174_op in H. discriminate H. Qed.

Lemma reff174_not3053 : ~ @Equation3053 Fin4 reff174_inst.
Proof. unfold Equation3053. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff174_inst, reff174_op in H. discriminate H. Qed.

Lemma reff174_not3055 : ~ @Equation3055 Fin4 reff174_inst.
Proof. unfold Equation3055. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff174_inst, reff174_op in H. discriminate H. Qed.

Lemma reff174_not3056 : ~ @Equation3056 Fin4 reff174_inst.
Proof. unfold Equation3056. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff174_inst, reff174_op in H. discriminate H. Qed.

Lemma reff174_not3058 : ~ @Equation3058 Fin4 reff174_inst.
Proof. unfold Equation3058. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff174_inst, reff174_op in H. discriminate H. Qed.

Lemma reff174_not3059 : ~ @Equation3059 Fin4 reff174_inst.
Proof. unfold Equation3059. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff174_inst, reff174_op in H. discriminate H. Qed.

Lemma reff174_not3065 : ~ @Equation3065 Fin4 reff174_inst.
Proof. unfold Equation3065. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff174_inst, reff174_op in H. discriminate H. Qed.

Lemma reff174_not3066 : ~ @Equation3066 Fin4 reff174_inst.
Proof. unfold Equation3066. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff174_inst, reff174_op in H. discriminate H. Qed.

Lemma reff174_not3068 : ~ @Equation3068 Fin4 reff174_inst.
Proof. unfold Equation3068. intro H. specialize (H F4_0 F4_3). unfold magma_op, reff174_inst, reff174_op in H. discriminate H. Qed.

Lemma reff174_not3069 : ~ @Equation3069 Fin4 reff174_inst.
Proof. unfold Equation3069. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff174_inst, reff174_op in H. discriminate H. Qed.

Lemma reff174_not3075 : ~ @Equation3075 Fin4 reff174_inst.
Proof. unfold Equation3075. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff174_inst, reff174_op in H. discriminate H. Qed.

Lemma reff174_not3076 : ~ @Equation3076 Fin4 reff174_inst.
Proof. unfold Equation3076. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff174_inst, reff174_op in H. discriminate H. Qed.

Lemma reff174_not3078 : ~ @Equation3078 Fin4 reff174_inst.
Proof. unfold Equation3078. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff174_inst, reff174_op in H. discriminate H. Qed.

Lemma reff174_not3079 : ~ @Equation3079 Fin4 reff174_inst.
Proof. unfold Equation3079. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff174_inst, reff174_op in H. discriminate H. Qed.

Lemma reff174_not3102 : ~ @Equation3102 Fin4 reff174_inst.
Proof. unfold Equation3102. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff174_inst, reff174_op in H. discriminate H. Qed.

Lemma reff174_not3103 : ~ @Equation3103 Fin4 reff174_inst.
Proof. unfold Equation3103. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff174_inst, reff174_op in H. discriminate H. Qed.

Lemma reff174_not3105 : ~ @Equation3105 Fin4 reff174_inst.
Proof. unfold Equation3105. intro H. specialize (H F4_0 F4_3). unfold magma_op, reff174_inst, reff174_op in H. discriminate H. Qed.

Lemma reff174_not3106 : ~ @Equation3106 Fin4 reff174_inst.
Proof. unfold Equation3106. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff174_inst, reff174_op in H. discriminate H. Qed.

Lemma reff174_not3112 : ~ @Equation3112 Fin4 reff174_inst.
Proof. unfold Equation3112. intro H. specialize (H F4_0 F4_3). unfold magma_op, reff174_inst, reff174_op in H. discriminate H. Qed.

Lemma reff174_not3113 : ~ @Equation3113 Fin4 reff174_inst.
Proof. unfold Equation3113. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff174_inst, reff174_op in H. discriminate H. Qed.

Lemma reff174_not3115 : ~ @Equation3115 Fin4 reff174_inst.
Proof. unfold Equation3115. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff174_inst, reff174_op in H. discriminate H. Qed.

Lemma reff174_not3116 : ~ @Equation3116 Fin4 reff174_inst.
Proof. unfold Equation3116. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff174_inst, reff174_op in H. discriminate H. Qed.

Lemma reff174_not3139 : ~ @Equation3139 Fin4 reff174_inst.
Proof. unfold Equation3139. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff174_inst, reff174_op in H. discriminate H. Qed.

Lemma reff174_not3140 : ~ @Equation3140 Fin4 reff174_inst.
Proof. unfold Equation3140. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff174_inst, reff174_op in H. discriminate H. Qed.

Lemma reff174_not3142 : ~ @Equation3142 Fin4 reff174_inst.
Proof. unfold Equation3142. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff174_inst, reff174_op in H. discriminate H. Qed.

Lemma reff174_not3143 : ~ @Equation3143 Fin4 reff174_inst.
Proof. unfold Equation3143. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff174_inst, reff174_op in H. discriminate H. Qed.

Lemma reff174_not3149 : ~ @Equation3149 Fin4 reff174_inst.
Proof. unfold Equation3149. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff174_inst, reff174_op in H. discriminate H. Qed.

Lemma reff174_not3150 : ~ @Equation3150 Fin4 reff174_inst.
Proof. unfold Equation3150. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff174_inst, reff174_op in H. discriminate H. Qed.

Lemma reff174_not3152 : ~ @Equation3152 Fin4 reff174_inst.
Proof. unfold Equation3152. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff174_inst, reff174_op in H. discriminate H. Qed.

Lemma reff174_not3253 : ~ @Equation3253 Fin4 reff174_inst.
Proof. unfold Equation3253. intro H. specialize (H F4_1). unfold magma_op, reff174_inst, reff174_op in H. discriminate H. Qed.

Lemma reff174_not3457 : ~ @Equation3457 Fin4 reff174_inst.
Proof. unfold Equation3457. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff174_inst, reff174_op in H. discriminate H. Qed.

Lemma reff174_not3458 : ~ @Equation3458 Fin4 reff174_inst.
Proof. unfold Equation3458. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff174_inst, reff174_op in H. discriminate H. Qed.

Lemma reff174_not3459 : ~ @Equation3459 Fin4 reff174_inst.
Proof. unfold Equation3459. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff174_inst, reff174_op in H. discriminate H. Qed.

Lemma reff174_not3461 : ~ @Equation3461 Fin4 reff174_inst.
Proof. unfold Equation3461. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff174_inst, reff174_op in H. discriminate H. Qed.

Lemma reff174_not3462 : ~ @Equation3462 Fin4 reff174_inst.
Proof. unfold Equation3462. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff174_inst, reff174_op in H. discriminate H. Qed.

Lemma reff174_not3464 : ~ @Equation3464 Fin4 reff174_inst.
Proof. unfold Equation3464. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff174_inst, reff174_op in H. discriminate H. Qed.

Lemma reff174_not3465 : ~ @Equation3465 Fin4 reff174_inst.
Proof. unfold Equation3465. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff174_inst, reff174_op in H. discriminate H. Qed.

Lemma reff174_not3472 : ~ @Equation3472 Fin4 reff174_inst.
Proof. unfold Equation3472. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff174_inst, reff174_op in H. discriminate H. Qed.

Lemma reff174_not3474 : ~ @Equation3474 Fin4 reff174_inst.
Proof. unfold Equation3474. intro H. specialize (H F4_0 F4_3). unfold magma_op, reff174_inst, reff174_op in H. discriminate H. Qed.

Lemma reff174_not3475 : ~ @Equation3475 Fin4 reff174_inst.
Proof. unfold Equation3475. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff174_inst, reff174_op in H. discriminate H. Qed.

Lemma reff174_not3481 : ~ @Equation3481 Fin4 reff174_inst.
Proof. unfold Equation3481. intro H. specialize (H F4_0 F4_3). unfold magma_op, reff174_inst, reff174_op in H. discriminate H. Qed.

Lemma reff174_not3482 : ~ @Equation3482 Fin4 reff174_inst.
Proof. unfold Equation3482. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff174_inst, reff174_op in H. discriminate H. Qed.

Lemma reff174_not3484 : ~ @Equation3484 Fin4 reff174_inst.
Proof. unfold Equation3484. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff174_inst, reff174_op in H. discriminate H. Qed.

Lemma reff174_not3511 : ~ @Equation3511 Fin4 reff174_inst.
Proof. unfold Equation3511. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff174_inst, reff174_op in H. discriminate H. Qed.

Lemma reff174_not3512 : ~ @Equation3512 Fin4 reff174_inst.
Proof. unfold Equation3512. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff174_inst, reff174_op in H. discriminate H. Qed.

Lemma reff174_not3518 : ~ @Equation3518 Fin4 reff174_inst.
Proof. unfold Equation3518. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff174_inst, reff174_op in H. discriminate H. Qed.

Lemma reff174_not3519 : ~ @Equation3519 Fin4 reff174_inst.
Proof. unfold Equation3519. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff174_inst, reff174_op in H. discriminate H. Qed.

Lemma reff174_not3521 : ~ @Equation3521 Fin4 reff174_inst.
Proof. unfold Equation3521. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff174_inst, reff174_op in H. discriminate H. Qed.

Lemma reff174_not3545 : ~ @Equation3545 Fin4 reff174_inst.
Proof. unfold Equation3545. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff174_inst, reff174_op in H. discriminate H. Qed.

Lemma reff174_not3546 : ~ @Equation3546 Fin4 reff174_inst.
Proof. unfold Equation3546. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff174_inst, reff174_op in H. discriminate H. Qed.

Lemma reff174_not3548 : ~ @Equation3548 Fin4 reff174_inst.
Proof. unfold Equation3548. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff174_inst, reff174_op in H. discriminate H. Qed.

Lemma reff174_not3549 : ~ @Equation3549 Fin4 reff174_inst.
Proof. unfold Equation3549. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff174_inst, reff174_op in H. discriminate H. Qed.

Lemma reff174_not3555 : ~ @Equation3555 Fin4 reff174_inst.
Proof. unfold Equation3555. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff174_inst, reff174_op in H. discriminate H. Qed.

Lemma reff174_not3556 : ~ @Equation3556 Fin4 reff174_inst.
Proof. unfold Equation3556. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff174_inst, reff174_op in H. discriminate H. Qed.

Lemma reff174_not3558 : ~ @Equation3558 Fin4 reff174_inst.
Proof. unfold Equation3558. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff174_inst, reff174_op in H. discriminate H. Qed.

Lemma reff174_not3659 : ~ @Equation3659 Fin4 reff174_inst.
Proof. unfold Equation3659. intro H. specialize (H F4_1). unfold magma_op, reff174_inst, reff174_op in H. discriminate H. Qed.

Lemma reff174_not3862 : ~ @Equation3862 Fin4 reff174_inst.
Proof. unfold Equation3862. intro H. specialize (H F4_1). unfold magma_op, reff174_inst, reff174_op in H. discriminate H. Qed.

Lemma reff174_not4066 : ~ @Equation4066 Fin4 reff174_inst.
Proof. unfold Equation4066. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff174_inst, reff174_op in H. discriminate H. Qed.

Lemma reff174_not4067 : ~ @Equation4067 Fin4 reff174_inst.
Proof. unfold Equation4067. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff174_inst, reff174_op in H. discriminate H. Qed.

Lemma reff174_not4068 : ~ @Equation4068 Fin4 reff174_inst.
Proof. unfold Equation4068. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff174_inst, reff174_op in H. discriminate H. Qed.

Lemma reff174_not4070 : ~ @Equation4070 Fin4 reff174_inst.
Proof. unfold Equation4070. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff174_inst, reff174_op in H. discriminate H. Qed.

Lemma reff174_not4071 : ~ @Equation4071 Fin4 reff174_inst.
Proof. unfold Equation4071. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff174_inst, reff174_op in H. discriminate H. Qed.

Lemma reff174_not4073 : ~ @Equation4073 Fin4 reff174_inst.
Proof. unfold Equation4073. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff174_inst, reff174_op in H. discriminate H. Qed.

Lemma reff174_not4074 : ~ @Equation4074 Fin4 reff174_inst.
Proof. unfold Equation4074. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff174_inst, reff174_op in H. discriminate H. Qed.

Lemma reff174_not4080 : ~ @Equation4080 Fin4 reff174_inst.
Proof. unfold Equation4080. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff174_inst, reff174_op in H. discriminate H. Qed.

Lemma reff174_not4083 : ~ @Equation4083 Fin4 reff174_inst.
Proof. unfold Equation4083. intro H. specialize (H F4_0 F4_3). unfold magma_op, reff174_inst, reff174_op in H. discriminate H. Qed.

Lemma reff174_not4084 : ~ @Equation4084 Fin4 reff174_inst.
Proof. unfold Equation4084. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff174_inst, reff174_op in H. discriminate H. Qed.

Lemma reff174_not4090 : ~ @Equation4090 Fin4 reff174_inst.
Proof. unfold Equation4090. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff174_inst, reff174_op in H. discriminate H. Qed.

Lemma reff174_not4091 : ~ @Equation4091 Fin4 reff174_inst.
Proof. unfold Equation4091. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff174_inst, reff174_op in H. discriminate H. Qed.

Lemma reff174_not4093 : ~ @Equation4093 Fin4 reff174_inst.
Proof. unfold Equation4093. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff174_inst, reff174_op in H. discriminate H. Qed.

Lemma reff174_not4120 : ~ @Equation4120 Fin4 reff174_inst.
Proof. unfold Equation4120. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff174_inst, reff174_op in H. discriminate H. Qed.

Lemma reff174_not4121 : ~ @Equation4121 Fin4 reff174_inst.
Proof. unfold Equation4121. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff174_inst, reff174_op in H. discriminate H. Qed.

Lemma reff174_not4127 : ~ @Equation4127 Fin4 reff174_inst.
Proof. unfold Equation4127. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff174_inst, reff174_op in H. discriminate H. Qed.

Lemma reff174_not4128 : ~ @Equation4128 Fin4 reff174_inst.
Proof. unfold Equation4128. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff174_inst, reff174_op in H. discriminate H. Qed.

Lemma reff174_not4130 : ~ @Equation4130 Fin4 reff174_inst.
Proof. unfold Equation4130. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff174_inst, reff174_op in H. discriminate H. Qed.

Lemma reff174_not4155 : ~ @Equation4155 Fin4 reff174_inst.
Proof. unfold Equation4155. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff174_inst, reff174_op in H. discriminate H. Qed.

Lemma reff174_not4157 : ~ @Equation4157 Fin4 reff174_inst.
Proof. unfold Equation4157. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff174_inst, reff174_op in H. discriminate H. Qed.

Lemma reff174_not4158 : ~ @Equation4158 Fin4 reff174_inst.
Proof. unfold Equation4158. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff174_inst, reff174_op in H. discriminate H. Qed.

Lemma reff174_not4164 : ~ @Equation4164 Fin4 reff174_inst.
Proof. unfold Equation4164. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff174_inst, reff174_op in H. discriminate H. Qed.

Lemma reff174_not4167 : ~ @Equation4167 Fin4 reff174_inst.
Proof. unfold Equation4167. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff174_inst, reff174_op in H. discriminate H. Qed.

Lemma reff174_not4268 : ~ @Equation4268 Fin4 reff174_inst.
Proof. unfold Equation4268. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff174_inst, reff174_op in H. discriminate H. Qed.

Lemma reff174_not4269 : ~ @Equation4269 Fin4 reff174_inst.
Proof. unfold Equation4269. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff174_inst, reff174_op in H. discriminate H. Qed.

Lemma reff174_not4270 : ~ @Equation4270 Fin4 reff174_inst.
Proof. unfold Equation4270. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff174_inst, reff174_op in H. discriminate H. Qed.

Lemma reff174_not4272 : ~ @Equation4272 Fin4 reff174_inst.
Proof. unfold Equation4272. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff174_inst, reff174_op in H. discriminate H. Qed.

Lemma reff174_not4273 : ~ @Equation4273 Fin4 reff174_inst.
Proof. unfold Equation4273. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff174_inst, reff174_op in H. discriminate H. Qed.

Lemma reff174_not4275 : ~ @Equation4275 Fin4 reff174_inst.
Proof. unfold Equation4275. intro H. specialize (H F4_0 F4_3). unfold magma_op, reff174_inst, reff174_op in H. discriminate H. Qed.

Lemma reff174_not4276 : ~ @Equation4276 Fin4 reff174_inst.
Proof. unfold Equation4276. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff174_inst, reff174_op in H. discriminate H. Qed.

Lemma reff174_not4283 : ~ @Equation4283 Fin4 reff174_inst.
Proof. unfold Equation4283. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff174_inst, reff174_op in H. discriminate H. Qed.

Lemma reff174_not4284 : ~ @Equation4284 Fin4 reff174_inst.
Proof. unfold Equation4284. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff174_inst, reff174_op in H. discriminate H. Qed.

Lemma reff174_not4290 : ~ @Equation4290 Fin4 reff174_inst.
Proof. unfold Equation4290. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff174_inst, reff174_op in H. discriminate H. Qed.

Lemma reff174_not4291 : ~ @Equation4291 Fin4 reff174_inst.
Proof. unfold Equation4291. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff174_inst, reff174_op in H. discriminate H. Qed.

Lemma reff174_not4293 : ~ @Equation4293 Fin4 reff174_inst.
Proof. unfold Equation4293. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff174_inst, reff174_op in H. discriminate H. Qed.

Lemma reff174_not4314 : ~ @Equation4314 Fin4 reff174_inst.
Proof. unfold Equation4314. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff174_inst, reff174_op in H. discriminate H. Qed.

Lemma reff174_not4320 : ~ @Equation4320 Fin4 reff174_inst.
Proof. unfold Equation4320. intro H. specialize (H F4_1 F4_2). unfold magma_op, reff174_inst, reff174_op in H. discriminate H. Qed.

Lemma reff174_not4321 : ~ @Equation4321 Fin4 reff174_inst.
Proof. unfold Equation4321. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff174_inst, reff174_op in H. discriminate H. Qed.

Lemma reff174_not4343 : ~ @Equation4343 Fin4 reff174_inst.
Proof. unfold Equation4343. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff174_inst, reff174_op in H. discriminate H. Qed.

Lemma reff174_not4380 : ~ @Equation4380 Fin4 reff174_inst.
Proof. unfold Equation4380. intro H. specialize (H F4_1). unfold magma_op, reff174_inst, reff174_op in H. discriminate H. Qed.

Lemma reff174_not4583 : ~ @Equation4583 Fin4 reff174_inst.
Proof. unfold Equation4583. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff174_inst, reff174_op in H. discriminate H. Qed.

Lemma reff174_not4584 : ~ @Equation4584 Fin4 reff174_inst.
Proof. unfold Equation4584. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff174_inst, reff174_op in H. discriminate H. Qed.

Lemma reff174_not4585 : ~ @Equation4585 Fin4 reff174_inst.
Proof. unfold Equation4585. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff174_inst, reff174_op in H. discriminate H. Qed.

Lemma reff174_not4587 : ~ @Equation4587 Fin4 reff174_inst.
Proof. unfold Equation4587. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff174_inst, reff174_op in H. discriminate H. Qed.

Lemma reff174_not4588 : ~ @Equation4588 Fin4 reff174_inst.
Proof. unfold Equation4588. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff174_inst, reff174_op in H. discriminate H. Qed.

Lemma reff174_not4590 : ~ @Equation4590 Fin4 reff174_inst.
Proof. unfold Equation4590. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff174_inst, reff174_op in H. discriminate H. Qed.

Lemma reff174_not4591 : ~ @Equation4591 Fin4 reff174_inst.
Proof. unfold Equation4591. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff174_inst, reff174_op in H. discriminate H. Qed.

Lemma reff174_not4598 : ~ @Equation4598 Fin4 reff174_inst.
Proof. unfold Equation4598. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff174_inst, reff174_op in H. discriminate H. Qed.

Lemma reff174_not4599 : ~ @Equation4599 Fin4 reff174_inst.
Proof. unfold Equation4599. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff174_inst, reff174_op in H. discriminate H. Qed.

Lemma reff174_not4605 : ~ @Equation4605 Fin4 reff174_inst.
Proof. unfold Equation4605. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff174_inst, reff174_op in H. discriminate H. Qed.

Lemma reff174_not4606 : ~ @Equation4606 Fin4 reff174_inst.
Proof. unfold Equation4606. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff174_inst, reff174_op in H. discriminate H. Qed.

Lemma reff174_not4608 : ~ @Equation4608 Fin4 reff174_inst.
Proof. unfold Equation4608. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff174_inst, reff174_op in H. discriminate H. Qed.

Lemma reff174_not4629 : ~ @Equation4629 Fin4 reff174_inst.
Proof. unfold Equation4629. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff174_inst, reff174_op in H. discriminate H. Qed.

Lemma reff174_not4635 : ~ @Equation4635 Fin4 reff174_inst.
Proof. unfold Equation4635. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff174_inst, reff174_op in H. discriminate H. Qed.

Lemma reff174_not4636 : ~ @Equation4636 Fin4 reff174_inst.
Proof. unfold Equation4636. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff174_inst, reff174_op in H. discriminate H. Qed.

Lemma reff174_not4658 : ~ @Equation4658 Fin4 reff174_inst.
Proof. unfold Equation4658. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff174_inst, reff174_op in H. discriminate H. Qed.

(** ---- reff176 (Fin3) ---- *)

Definition reff176_op (x y : Fin3) : Fin3 :=
  match x, y with
  | F3_0, F3_0 => F3_0 | F3_0, F3_1 => F3_2 | F3_0, F3_2 => F3_0
  | F3_1, F3_0 => F3_1 | F3_1, F3_1 => F3_2 | F3_1, F3_2 => F3_2
  | F3_2, F3_0 => F3_1 | F3_2, F3_1 => F3_1 | F3_2, F3_2 => F3_0
  end.

#[local] Instance reff176_inst : Magma Fin3 := {| magma_op := reff176_op |}.

Lemma reff176_sat205 : @Equation205 Fin3 reff176_inst.
Proof. unfold Equation205, magma_op, reff176_inst, reff176_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff176_sat2459 : @Equation2459 Fin3 reff176_inst.
Proof. unfold Equation2459, magma_op, reff176_inst, reff176_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff176_sat4128 : @Equation4128 Fin3 reff176_inst.
Proof. unfold Equation4128, magma_op, reff176_inst, reff176_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff176_sat4268 : @Equation4268 Fin3 reff176_inst.
Proof. unfold Equation4268, magma_op, reff176_inst, reff176_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff176_not47 : ~ @Equation47 Fin3 reff176_inst.
Proof. unfold Equation47. intro H. specialize (H F3_1). unfold magma_op, reff176_inst, reff176_op in H. discriminate H. Qed.

Lemma reff176_not99 : ~ @Equation99 Fin3 reff176_inst.
Proof. unfold Equation99. intro H. specialize (H F3_1). unfold magma_op, reff176_inst, reff176_op in H. discriminate H. Qed.

Lemma reff176_not151 : ~ @Equation151 Fin3 reff176_inst.
Proof. unfold Equation151. intro H. specialize (H F3_1). unfold magma_op, reff176_inst, reff176_op in H. discriminate H. Qed.

Lemma reff176_not206 : ~ @Equation206 Fin3 reff176_inst.
Proof. unfold Equation206. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff176_inst, reff176_op in H. discriminate H. Qed.

Lemma reff176_not209 : ~ @Equation209 Fin3 reff176_inst.
Proof. unfold Equation209. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff176_inst, reff176_op in H. discriminate H. Qed.

Lemma reff176_not211 : ~ @Equation211 Fin3 reff176_inst.
Proof. unfold Equation211. intro H. specialize (H F3_1 F3_0). unfold magma_op, reff176_inst, reff176_op in H. discriminate H. Qed.

Lemma reff176_not212 : ~ @Equation212 Fin3 reff176_inst.
Proof. unfold Equation212. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff176_inst, reff176_op in H. discriminate H. Qed.

Lemma reff176_not219 : ~ @Equation219 Fin3 reff176_inst.
Proof. unfold Equation219. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff176_inst, reff176_op in H. discriminate H. Qed.

Lemma reff176_not221 : ~ @Equation221 Fin3 reff176_inst.
Proof. unfold Equation221. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff176_inst, reff176_op in H. discriminate H. Qed.

Lemma reff176_not222 : ~ @Equation222 Fin3 reff176_inst.
Proof. unfold Equation222. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff176_inst, reff176_op in H. discriminate H. Qed.

Lemma reff176_not228 : ~ @Equation228 Fin3 reff176_inst.
Proof. unfold Equation228. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff176_inst, reff176_op in H. discriminate H. Qed.

Lemma reff176_not229 : ~ @Equation229 Fin3 reff176_inst.
Proof. unfold Equation229. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff176_inst, reff176_op in H. discriminate H. Qed.

Lemma reff176_not231 : ~ @Equation231 Fin3 reff176_inst.
Proof. unfold Equation231. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff176_inst, reff176_op in H. discriminate H. Qed.

Lemma reff176_not255 : ~ @Equation255 Fin3 reff176_inst.
Proof. unfold Equation255. intro H. specialize (H F3_1). unfold magma_op, reff176_inst, reff176_op in H. discriminate H. Qed.

Lemma reff176_not359 : ~ @Equation359 Fin3 reff176_inst.
Proof. unfold Equation359. intro H. specialize (H F3_1). unfold magma_op, reff176_inst, reff176_op in H. discriminate H. Qed.

Lemma reff176_not411 : ~ @Equation411 Fin3 reff176_inst.
Proof. unfold Equation411. intro H. specialize (H F3_1). unfold magma_op, reff176_inst, reff176_op in H. discriminate H. Qed.

Lemma reff176_not614 : ~ @Equation614 Fin3 reff176_inst.
Proof. unfold Equation614. intro H. specialize (H F3_1). unfold magma_op, reff176_inst, reff176_op in H. discriminate H. Qed.

Lemma reff176_not817 : ~ @Equation817 Fin3 reff176_inst.
Proof. unfold Equation817. intro H. specialize (H F3_2). unfold magma_op, reff176_inst, reff176_op in H. discriminate H. Qed.

Lemma reff176_not1020 : ~ @Equation1020 Fin3 reff176_inst.
Proof. unfold Equation1020. intro H. specialize (H F3_1). unfold magma_op, reff176_inst, reff176_op in H. discriminate H. Qed.

Lemma reff176_not1223 : ~ @Equation1223 Fin3 reff176_inst.
Proof. unfold Equation1223. intro H. specialize (H F3_1). unfold magma_op, reff176_inst, reff176_op in H. discriminate H. Qed.

Lemma reff176_not1426 : ~ @Equation1426 Fin3 reff176_inst.
Proof. unfold Equation1426. intro H. specialize (H F3_1). unfold magma_op, reff176_inst, reff176_op in H. discriminate H. Qed.

Lemma reff176_not1629 : ~ @Equation1629 Fin3 reff176_inst.
Proof. unfold Equation1629. intro H. specialize (H F3_2). unfold magma_op, reff176_inst, reff176_op in H. discriminate H. Qed.

Lemma reff176_not1832 : ~ @Equation1832 Fin3 reff176_inst.
Proof. unfold Equation1832. intro H. specialize (H F3_1). unfold magma_op, reff176_inst, reff176_op in H. discriminate H. Qed.

Lemma reff176_not2035 : ~ @Equation2035 Fin3 reff176_inst.
Proof. unfold Equation2035. intro H. specialize (H F3_1). unfold magma_op, reff176_inst, reff176_op in H. discriminate H. Qed.

Lemma reff176_not2239 : ~ @Equation2239 Fin3 reff176_inst.
Proof. unfold Equation2239. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff176_inst, reff176_op in H. discriminate H. Qed.

Lemma reff176_not2241 : ~ @Equation2241 Fin3 reff176_inst.
Proof. unfold Equation2241. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff176_inst, reff176_op in H. discriminate H. Qed.

Lemma reff176_not2244 : ~ @Equation2244 Fin3 reff176_inst.
Proof. unfold Equation2244. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff176_inst, reff176_op in H. discriminate H. Qed.

Lemma reff176_not2247 : ~ @Equation2247 Fin3 reff176_inst.
Proof. unfold Equation2247. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff176_inst, reff176_op in H. discriminate H. Qed.

Lemma reff176_not2253 : ~ @Equation2253 Fin3 reff176_inst.
Proof. unfold Equation2253. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff176_inst, reff176_op in H. discriminate H. Qed.

Lemma reff176_not2254 : ~ @Equation2254 Fin3 reff176_inst.
Proof. unfold Equation2254. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff176_inst, reff176_op in H. discriminate H. Qed.

Lemma reff176_not2256 : ~ @Equation2256 Fin3 reff176_inst.
Proof. unfold Equation2256. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff176_inst, reff176_op in H. discriminate H. Qed.

Lemma reff176_not2257 : ~ @Equation2257 Fin3 reff176_inst.
Proof. unfold Equation2257. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff176_inst, reff176_op in H. discriminate H. Qed.

Lemma reff176_not2263 : ~ @Equation2263 Fin3 reff176_inst.
Proof. unfold Equation2263. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff176_inst, reff176_op in H. discriminate H. Qed.

Lemma reff176_not2264 : ~ @Equation2264 Fin3 reff176_inst.
Proof. unfold Equation2264. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff176_inst, reff176_op in H. discriminate H. Qed.

Lemma reff176_not2266 : ~ @Equation2266 Fin3 reff176_inst.
Proof. unfold Equation2266. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff176_inst, reff176_op in H. discriminate H. Qed.

Lemma reff176_not2267 : ~ @Equation2267 Fin3 reff176_inst.
Proof. unfold Equation2267. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff176_inst, reff176_op in H. discriminate H. Qed.

Lemma reff176_not2290 : ~ @Equation2290 Fin3 reff176_inst.
Proof. unfold Equation2290. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff176_inst, reff176_op in H. discriminate H. Qed.

Lemma reff176_not2291 : ~ @Equation2291 Fin3 reff176_inst.
Proof. unfold Equation2291. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff176_inst, reff176_op in H. discriminate H. Qed.

Lemma reff176_not2293 : ~ @Equation2293 Fin3 reff176_inst.
Proof. unfold Equation2293. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff176_inst, reff176_op in H. discriminate H. Qed.

Lemma reff176_not2294 : ~ @Equation2294 Fin3 reff176_inst.
Proof. unfold Equation2294. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff176_inst, reff176_op in H. discriminate H. Qed.

Lemma reff176_not2300 : ~ @Equation2300 Fin3 reff176_inst.
Proof. unfold Equation2300. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff176_inst, reff176_op in H. discriminate H. Qed.

Lemma reff176_not2301 : ~ @Equation2301 Fin3 reff176_inst.
Proof. unfold Equation2301. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff176_inst, reff176_op in H. discriminate H. Qed.

Lemma reff176_not2303 : ~ @Equation2303 Fin3 reff176_inst.
Proof. unfold Equation2303. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff176_inst, reff176_op in H. discriminate H. Qed.

Lemma reff176_not2304 : ~ @Equation2304 Fin3 reff176_inst.
Proof. unfold Equation2304. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff176_inst, reff176_op in H. discriminate H. Qed.

Lemma reff176_not2327 : ~ @Equation2327 Fin3 reff176_inst.
Proof. unfold Equation2327. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff176_inst, reff176_op in H. discriminate H. Qed.

Lemma reff176_not2328 : ~ @Equation2328 Fin3 reff176_inst.
Proof. unfold Equation2328. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff176_inst, reff176_op in H. discriminate H. Qed.

Lemma reff176_not2330 : ~ @Equation2330 Fin3 reff176_inst.
Proof. unfold Equation2330. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff176_inst, reff176_op in H. discriminate H. Qed.

Lemma reff176_not2331 : ~ @Equation2331 Fin3 reff176_inst.
Proof. unfold Equation2331. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff176_inst, reff176_op in H. discriminate H. Qed.

Lemma reff176_not2337 : ~ @Equation2337 Fin3 reff176_inst.
Proof. unfold Equation2337. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff176_inst, reff176_op in H. discriminate H. Qed.

Lemma reff176_not2338 : ~ @Equation2338 Fin3 reff176_inst.
Proof. unfold Equation2338. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff176_inst, reff176_op in H. discriminate H. Qed.

Lemma reff176_not2340 : ~ @Equation2340 Fin3 reff176_inst.
Proof. unfold Equation2340. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff176_inst, reff176_op in H. discriminate H. Qed.

Lemma reff176_not2442 : ~ @Equation2442 Fin3 reff176_inst.
Proof. unfold Equation2442. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff176_inst, reff176_op in H. discriminate H. Qed.

Lemma reff176_not2443 : ~ @Equation2443 Fin3 reff176_inst.
Proof. unfold Equation2443. intro H. specialize (H F3_1 F3_2). unfold magma_op, reff176_inst, reff176_op in H. discriminate H. Qed.

Lemma reff176_not2444 : ~ @Equation2444 Fin3 reff176_inst.
Proof. unfold Equation2444. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff176_inst, reff176_op in H. discriminate H. Qed.

Lemma reff176_not2446 : ~ @Equation2446 Fin3 reff176_inst.
Proof. unfold Equation2446. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff176_inst, reff176_op in H. discriminate H. Qed.

Lemma reff176_not2447 : ~ @Equation2447 Fin3 reff176_inst.
Proof. unfold Equation2447. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff176_inst, reff176_op in H. discriminate H. Qed.

Lemma reff176_not2449 : ~ @Equation2449 Fin3 reff176_inst.
Proof. unfold Equation2449. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff176_inst, reff176_op in H. discriminate H. Qed.

Lemma reff176_not2450 : ~ @Equation2450 Fin3 reff176_inst.
Proof. unfold Equation2450. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff176_inst, reff176_op in H. discriminate H. Qed.

Lemma reff176_not2456 : ~ @Equation2456 Fin3 reff176_inst.
Proof. unfold Equation2456. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff176_inst, reff176_op in H. discriminate H. Qed.

Lemma reff176_not2457 : ~ @Equation2457 Fin3 reff176_inst.
Proof. unfold Equation2457. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff176_inst, reff176_op in H. discriminate H. Qed.

Lemma reff176_not2460 : ~ @Equation2460 Fin3 reff176_inst.
Proof. unfold Equation2460. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff176_inst, reff176_op in H. discriminate H. Qed.

Lemma reff176_not2466 : ~ @Equation2466 Fin3 reff176_inst.
Proof. unfold Equation2466. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff176_inst, reff176_op in H. discriminate H. Qed.

Lemma reff176_not2467 : ~ @Equation2467 Fin3 reff176_inst.
Proof. unfold Equation2467. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff176_inst, reff176_op in H. discriminate H. Qed.

Lemma reff176_not2469 : ~ @Equation2469 Fin3 reff176_inst.
Proof. unfold Equation2469. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff176_inst, reff176_op in H. discriminate H. Qed.

Lemma reff176_not2470 : ~ @Equation2470 Fin3 reff176_inst.
Proof. unfold Equation2470. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff176_inst, reff176_op in H. discriminate H. Qed.

Lemma reff176_not2493 : ~ @Equation2493 Fin3 reff176_inst.
Proof. unfold Equation2493. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff176_inst, reff176_op in H. discriminate H. Qed.

Lemma reff176_not2494 : ~ @Equation2494 Fin3 reff176_inst.
Proof. unfold Equation2494. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff176_inst, reff176_op in H. discriminate H. Qed.

Lemma reff176_not2496 : ~ @Equation2496 Fin3 reff176_inst.
Proof. unfold Equation2496. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff176_inst, reff176_op in H. discriminate H. Qed.

Lemma reff176_not2497 : ~ @Equation2497 Fin3 reff176_inst.
Proof. unfold Equation2497. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff176_inst, reff176_op in H. discriminate H. Qed.

Lemma reff176_not2503 : ~ @Equation2503 Fin3 reff176_inst.
Proof. unfold Equation2503. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff176_inst, reff176_op in H. discriminate H. Qed.

Lemma reff176_not2504 : ~ @Equation2504 Fin3 reff176_inst.
Proof. unfold Equation2504. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff176_inst, reff176_op in H. discriminate H. Qed.

Lemma reff176_not2506 : ~ @Equation2506 Fin3 reff176_inst.
Proof. unfold Equation2506. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff176_inst, reff176_op in H. discriminate H. Qed.

Lemma reff176_not2507 : ~ @Equation2507 Fin3 reff176_inst.
Proof. unfold Equation2507. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff176_inst, reff176_op in H. discriminate H. Qed.

Lemma reff176_not2530 : ~ @Equation2530 Fin3 reff176_inst.
Proof. unfold Equation2530. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff176_inst, reff176_op in H. discriminate H. Qed.

Lemma reff176_not2531 : ~ @Equation2531 Fin3 reff176_inst.
Proof. unfold Equation2531. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff176_inst, reff176_op in H. discriminate H. Qed.

Lemma reff176_not2533 : ~ @Equation2533 Fin3 reff176_inst.
Proof. unfold Equation2533. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff176_inst, reff176_op in H. discriminate H. Qed.

Lemma reff176_not2534 : ~ @Equation2534 Fin3 reff176_inst.
Proof. unfold Equation2534. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff176_inst, reff176_op in H. discriminate H. Qed.

Lemma reff176_not2540 : ~ @Equation2540 Fin3 reff176_inst.
Proof. unfold Equation2540. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff176_inst, reff176_op in H. discriminate H. Qed.

Lemma reff176_not2541 : ~ @Equation2541 Fin3 reff176_inst.
Proof. unfold Equation2541. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff176_inst, reff176_op in H. discriminate H. Qed.

Lemma reff176_not2543 : ~ @Equation2543 Fin3 reff176_inst.
Proof. unfold Equation2543. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff176_inst, reff176_op in H. discriminate H. Qed.

Lemma reff176_not2644 : ~ @Equation2644 Fin3 reff176_inst.
Proof. unfold Equation2644. intro H. specialize (H F3_1). unfold magma_op, reff176_inst, reff176_op in H. discriminate H. Qed.

Lemma reff176_not2847 : ~ @Equation2847 Fin3 reff176_inst.
Proof. unfold Equation2847. intro H. specialize (H F3_1). unfold magma_op, reff176_inst, reff176_op in H. discriminate H. Qed.

Lemma reff176_not3050 : ~ @Equation3050 Fin3 reff176_inst.
Proof. unfold Equation3050. intro H. specialize (H F3_2). unfold magma_op, reff176_inst, reff176_op in H. discriminate H. Qed.

Lemma reff176_not3253 : ~ @Equation3253 Fin3 reff176_inst.
Proof. unfold Equation3253. intro H. specialize (H F3_2). unfold magma_op, reff176_inst, reff176_op in H. discriminate H. Qed.

Lemma reff176_not3456 : ~ @Equation3456 Fin3 reff176_inst.
Proof. unfold Equation3456. intro H. specialize (H F3_2). unfold magma_op, reff176_inst, reff176_op in H. discriminate H. Qed.

Lemma reff176_not3659 : ~ @Equation3659 Fin3 reff176_inst.
Proof. unfold Equation3659. intro H. specialize (H F3_1). unfold magma_op, reff176_inst, reff176_op in H. discriminate H. Qed.

Lemma reff176_not3862 : ~ @Equation3862 Fin3 reff176_inst.
Proof. unfold Equation3862. intro H. specialize (H F3_1). unfold magma_op, reff176_inst, reff176_op in H. discriminate H. Qed.

Lemma reff176_not4066 : ~ @Equation4066 Fin3 reff176_inst.
Proof. unfold Equation4066. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff176_inst, reff176_op in H. discriminate H. Qed.

Lemma reff176_not4067 : ~ @Equation4067 Fin3 reff176_inst.
Proof. unfold Equation4067. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff176_inst, reff176_op in H. discriminate H. Qed.

Lemma reff176_not4068 : ~ @Equation4068 Fin3 reff176_inst.
Proof. unfold Equation4068. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff176_inst, reff176_op in H. discriminate H. Qed.

Lemma reff176_not4070 : ~ @Equation4070 Fin3 reff176_inst.
Proof. unfold Equation4070. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff176_inst, reff176_op in H. discriminate H. Qed.

Lemma reff176_not4071 : ~ @Equation4071 Fin3 reff176_inst.
Proof. unfold Equation4071. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff176_inst, reff176_op in H. discriminate H. Qed.

Lemma reff176_not4073 : ~ @Equation4073 Fin3 reff176_inst.
Proof. unfold Equation4073. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff176_inst, reff176_op in H. discriminate H. Qed.

Lemma reff176_not4074 : ~ @Equation4074 Fin3 reff176_inst.
Proof. unfold Equation4074. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff176_inst, reff176_op in H. discriminate H. Qed.

Lemma reff176_not4080 : ~ @Equation4080 Fin3 reff176_inst.
Proof. unfold Equation4080. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff176_inst, reff176_op in H. discriminate H. Qed.

Lemma reff176_not4083 : ~ @Equation4083 Fin3 reff176_inst.
Proof. unfold Equation4083. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff176_inst, reff176_op in H. discriminate H. Qed.

Lemma reff176_not4084 : ~ @Equation4084 Fin3 reff176_inst.
Proof. unfold Equation4084. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff176_inst, reff176_op in H. discriminate H. Qed.

Lemma reff176_not4090 : ~ @Equation4090 Fin3 reff176_inst.
Proof. unfold Equation4090. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff176_inst, reff176_op in H. discriminate H. Qed.

Lemma reff176_not4091 : ~ @Equation4091 Fin3 reff176_inst.
Proof. unfold Equation4091. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff176_inst, reff176_op in H. discriminate H. Qed.

Lemma reff176_not4093 : ~ @Equation4093 Fin3 reff176_inst.
Proof. unfold Equation4093. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff176_inst, reff176_op in H. discriminate H. Qed.

Lemma reff176_not4118 : ~ @Equation4118 Fin3 reff176_inst.
Proof. unfold Equation4118. intro H. specialize (H F3_2 F3_0). unfold magma_op, reff176_inst, reff176_op in H. discriminate H. Qed.

Lemma reff176_not4120 : ~ @Equation4120 Fin3 reff176_inst.
Proof. unfold Equation4120. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff176_inst, reff176_op in H. discriminate H. Qed.

Lemma reff176_not4121 : ~ @Equation4121 Fin3 reff176_inst.
Proof. unfold Equation4121. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff176_inst, reff176_op in H. discriminate H. Qed.

Lemma reff176_not4127 : ~ @Equation4127 Fin3 reff176_inst.
Proof. unfold Equation4127. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff176_inst, reff176_op in H. discriminate H. Qed.

Lemma reff176_not4130 : ~ @Equation4130 Fin3 reff176_inst.
Proof. unfold Equation4130. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff176_inst, reff176_op in H. discriminate H. Qed.

Lemma reff176_not4131 : ~ @Equation4131 Fin3 reff176_inst.
Proof. unfold Equation4131. intro H. specialize (H F3_1 F3_2). unfold magma_op, reff176_inst, reff176_op in H. discriminate H. Qed.

Lemma reff176_not4155 : ~ @Equation4155 Fin3 reff176_inst.
Proof. unfold Equation4155. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff176_inst, reff176_op in H. discriminate H. Qed.

Lemma reff176_not4157 : ~ @Equation4157 Fin3 reff176_inst.
Proof. unfold Equation4157. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff176_inst, reff176_op in H. discriminate H. Qed.

Lemma reff176_not4158 : ~ @Equation4158 Fin3 reff176_inst.
Proof. unfold Equation4158. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff176_inst, reff176_op in H. discriminate H. Qed.

Lemma reff176_not4164 : ~ @Equation4164 Fin3 reff176_inst.
Proof. unfold Equation4164. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff176_inst, reff176_op in H. discriminate H. Qed.

Lemma reff176_not4165 : ~ @Equation4165 Fin3 reff176_inst.
Proof. unfold Equation4165. intro H. specialize (H F3_1 F3_2). unfold magma_op, reff176_inst, reff176_op in H. discriminate H. Qed.

Lemma reff176_not4167 : ~ @Equation4167 Fin3 reff176_inst.
Proof. unfold Equation4167. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff176_inst, reff176_op in H. discriminate H. Qed.

Lemma reff176_not4269 : ~ @Equation4269 Fin3 reff176_inst.
Proof. unfold Equation4269. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff176_inst, reff176_op in H. discriminate H. Qed.

Lemma reff176_not4270 : ~ @Equation4270 Fin3 reff176_inst.
Proof. unfold Equation4270. intro H. specialize (H F3_1 F3_0). unfold magma_op, reff176_inst, reff176_op in H. discriminate H. Qed.

Lemma reff176_not4272 : ~ @Equation4272 Fin3 reff176_inst.
Proof. unfold Equation4272. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff176_inst, reff176_op in H. discriminate H. Qed.

Lemma reff176_not4273 : ~ @Equation4273 Fin3 reff176_inst.
Proof. unfold Equation4273. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff176_inst, reff176_op in H. discriminate H. Qed.

Lemma reff176_not4275 : ~ @Equation4275 Fin3 reff176_inst.
Proof. unfold Equation4275. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff176_inst, reff176_op in H. discriminate H. Qed.

Lemma reff176_not4276 : ~ @Equation4276 Fin3 reff176_inst.
Proof. unfold Equation4276. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff176_inst, reff176_op in H. discriminate H. Qed.

Lemma reff176_not4283 : ~ @Equation4283 Fin3 reff176_inst.
Proof. unfold Equation4283. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff176_inst, reff176_op in H. discriminate H. Qed.

Lemma reff176_not4284 : ~ @Equation4284 Fin3 reff176_inst.
Proof. unfold Equation4284. intro H. specialize (H F3_1 F3_0). unfold magma_op, reff176_inst, reff176_op in H. discriminate H. Qed.

Lemma reff176_not4290 : ~ @Equation4290 Fin3 reff176_inst.
Proof. unfold Equation4290. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff176_inst, reff176_op in H. discriminate H. Qed.

Lemma reff176_not4291 : ~ @Equation4291 Fin3 reff176_inst.
Proof. unfold Equation4291. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff176_inst, reff176_op in H. discriminate H. Qed.

Lemma reff176_not4293 : ~ @Equation4293 Fin3 reff176_inst.
Proof. unfold Equation4293. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff176_inst, reff176_op in H. discriminate H. Qed.

Lemma reff176_not4314 : ~ @Equation4314 Fin3 reff176_inst.
Proof. unfold Equation4314. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff176_inst, reff176_op in H. discriminate H. Qed.

Lemma reff176_not4320 : ~ @Equation4320 Fin3 reff176_inst.
Proof. unfold Equation4320. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff176_inst, reff176_op in H. discriminate H. Qed.

Lemma reff176_not4321 : ~ @Equation4321 Fin3 reff176_inst.
Proof. unfold Equation4321. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff176_inst, reff176_op in H. discriminate H. Qed.

Lemma reff176_not4343 : ~ @Equation4343 Fin3 reff176_inst.
Proof. unfold Equation4343. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff176_inst, reff176_op in H. discriminate H. Qed.

Lemma reff176_not4380 : ~ @Equation4380 Fin3 reff176_inst.
Proof. unfold Equation4380. intro H. specialize (H F3_1). unfold magma_op, reff176_inst, reff176_op in H. discriminate H. Qed.

Lemma reff176_not4583 : ~ @Equation4583 Fin3 reff176_inst.
Proof. unfold Equation4583. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff176_inst, reff176_op in H. discriminate H. Qed.

Lemma reff176_not4584 : ~ @Equation4584 Fin3 reff176_inst.
Proof. unfold Equation4584. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff176_inst, reff176_op in H. discriminate H. Qed.

Lemma reff176_not4585 : ~ @Equation4585 Fin3 reff176_inst.
Proof. unfold Equation4585. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff176_inst, reff176_op in H. discriminate H. Qed.

Lemma reff176_not4587 : ~ @Equation4587 Fin3 reff176_inst.
Proof. unfold Equation4587. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff176_inst, reff176_op in H. discriminate H. Qed.

Lemma reff176_not4588 : ~ @Equation4588 Fin3 reff176_inst.
Proof. unfold Equation4588. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff176_inst, reff176_op in H. discriminate H. Qed.

Lemma reff176_not4590 : ~ @Equation4590 Fin3 reff176_inst.
Proof. unfold Equation4590. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff176_inst, reff176_op in H. discriminate H. Qed.

Lemma reff176_not4591 : ~ @Equation4591 Fin3 reff176_inst.
Proof. unfold Equation4591. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff176_inst, reff176_op in H. discriminate H. Qed.

Lemma reff176_not4598 : ~ @Equation4598 Fin3 reff176_inst.
Proof. unfold Equation4598. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff176_inst, reff176_op in H. discriminate H. Qed.

Lemma reff176_not4599 : ~ @Equation4599 Fin3 reff176_inst.
Proof. unfold Equation4599. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff176_inst, reff176_op in H. discriminate H. Qed.

Lemma reff176_not4605 : ~ @Equation4605 Fin3 reff176_inst.
Proof. unfold Equation4605. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff176_inst, reff176_op in H. discriminate H. Qed.

Lemma reff176_not4606 : ~ @Equation4606 Fin3 reff176_inst.
Proof. unfold Equation4606. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff176_inst, reff176_op in H. discriminate H. Qed.

Lemma reff176_not4608 : ~ @Equation4608 Fin3 reff176_inst.
Proof. unfold Equation4608. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff176_inst, reff176_op in H. discriminate H. Qed.

Lemma reff176_not4629 : ~ @Equation4629 Fin3 reff176_inst.
Proof. unfold Equation4629. intro H. specialize (H F3_1 F3_0). unfold magma_op, reff176_inst, reff176_op in H. discriminate H. Qed.

Lemma reff176_not4635 : ~ @Equation4635 Fin3 reff176_inst.
Proof. unfold Equation4635. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff176_inst, reff176_op in H. discriminate H. Qed.

Lemma reff176_not4636 : ~ @Equation4636 Fin3 reff176_inst.
Proof. unfold Equation4636. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff176_inst, reff176_op in H. discriminate H. Qed.

Lemma reff176_not4658 : ~ @Equation4658 Fin3 reff176_inst.
Proof. unfold Equation4658. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff176_inst, reff176_op in H. discriminate H. Qed.

(** ---- reff178 (Fin4) ---- *)

Definition reff178_op (x y : Fin4) : Fin4 :=
  match x, y with
  | F4_0, F4_0 => F4_0 | F4_0, F4_1 => F4_1 | F4_0, F4_2 => F4_0 | F4_0, F4_3 => F4_1
  | F4_1, F4_0 => F4_2 | F4_1, F4_1 => F4_2 | F4_1, F4_2 => F4_0 | F4_1, F4_3 => F4_0
  | F4_2, F4_0 => F4_0 | F4_2, F4_1 => F4_3 | F4_2, F4_2 => F4_0 | F4_2, F4_3 => F4_3
  | F4_3, F4_0 => F4_2 | F4_3, F4_1 => F4_0 | F4_3, F4_2 => F4_0 | F4_3, F4_3 => F4_2
  end.

#[local] Instance reff178_inst : Magma Fin4 := {| magma_op := reff178_op |}.

Lemma reff178_sat3258 : @Equation3258 Fin4 reff178_inst.
Proof. unfold Equation3258, magma_op, reff178_inst, reff178_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff178_sat3262 : @Equation3262 Fin4 reff178_inst.
Proof. unfold Equation3262, magma_op, reff178_inst, reff178_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff178_sat3306 : @Equation3306 Fin4 reff178_inst.
Proof. unfold Equation3306, magma_op, reff178_inst, reff178_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff178_sat4276 : @Equation4276 Fin4 reff178_inst.
Proof. unfold Equation4276, magma_op, reff178_inst, reff178_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff178_not47 : ~ @Equation47 Fin4 reff178_inst.
Proof. unfold Equation47. intro H. specialize (H F4_1). unfold magma_op, reff178_inst, reff178_op in H. discriminate H. Qed.

Lemma reff178_not99 : ~ @Equation99 Fin4 reff178_inst.
Proof. unfold Equation99. intro H. specialize (H F4_1). unfold magma_op, reff178_inst, reff178_op in H. discriminate H. Qed.

Lemma reff178_not151 : ~ @Equation151 Fin4 reff178_inst.
Proof. unfold Equation151. intro H. specialize (H F4_1). unfold magma_op, reff178_inst, reff178_op in H. discriminate H. Qed.

Lemma reff178_not203 : ~ @Equation203 Fin4 reff178_inst.
Proof. unfold Equation203. intro H. specialize (H F4_2). unfold magma_op, reff178_inst, reff178_op in H. discriminate H. Qed.

Lemma reff178_not255 : ~ @Equation255 Fin4 reff178_inst.
Proof. unfold Equation255. intro H. specialize (H F4_1). unfold magma_op, reff178_inst, reff178_op in H. discriminate H. Qed.

Lemma reff178_not307 : ~ @Equation307 Fin4 reff178_inst.
Proof. unfold Equation307. intro H. specialize (H F4_1). unfold magma_op, reff178_inst, reff178_op in H. discriminate H. Qed.

Lemma reff178_not411 : ~ @Equation411 Fin4 reff178_inst.
Proof. unfold Equation411. intro H. specialize (H F4_1). unfold magma_op, reff178_inst, reff178_op in H. discriminate H. Qed.

Lemma reff178_not614 : ~ @Equation614 Fin4 reff178_inst.
Proof. unfold Equation614. intro H. specialize (H F4_1). unfold magma_op, reff178_inst, reff178_op in H. discriminate H. Qed.

Lemma reff178_not817 : ~ @Equation817 Fin4 reff178_inst.
Proof. unfold Equation817. intro H. specialize (H F4_1). unfold magma_op, reff178_inst, reff178_op in H. discriminate H. Qed.

Lemma reff178_not1020 : ~ @Equation1020 Fin4 reff178_inst.
Proof. unfold Equation1020. intro H. specialize (H F4_1). unfold magma_op, reff178_inst, reff178_op in H. discriminate H. Qed.

Lemma reff178_not1223 : ~ @Equation1223 Fin4 reff178_inst.
Proof. unfold Equation1223. intro H. specialize (H F4_1). unfold magma_op, reff178_inst, reff178_op in H. discriminate H. Qed.

Lemma reff178_not1426 : ~ @Equation1426 Fin4 reff178_inst.
Proof. unfold Equation1426. intro H. specialize (H F4_1). unfold magma_op, reff178_inst, reff178_op in H. discriminate H. Qed.

Lemma reff178_not1629 : ~ @Equation1629 Fin4 reff178_inst.
Proof. unfold Equation1629. intro H. specialize (H F4_1). unfold magma_op, reff178_inst, reff178_op in H. discriminate H. Qed.

Lemma reff178_not1832 : ~ @Equation1832 Fin4 reff178_inst.
Proof. unfold Equation1832. intro H. specialize (H F4_1). unfold magma_op, reff178_inst, reff178_op in H. discriminate H. Qed.

Lemma reff178_not2035 : ~ @Equation2035 Fin4 reff178_inst.
Proof. unfold Equation2035. intro H. specialize (H F4_1). unfold magma_op, reff178_inst, reff178_op in H. discriminate H. Qed.

Lemma reff178_not2238 : ~ @Equation2238 Fin4 reff178_inst.
Proof. unfold Equation2238. intro H. specialize (H F4_1). unfold magma_op, reff178_inst, reff178_op in H. discriminate H. Qed.

Lemma reff178_not2441 : ~ @Equation2441 Fin4 reff178_inst.
Proof. unfold Equation2441. intro H. specialize (H F4_2). unfold magma_op, reff178_inst, reff178_op in H. discriminate H. Qed.

Lemma reff178_not2644 : ~ @Equation2644 Fin4 reff178_inst.
Proof. unfold Equation2644. intro H. specialize (H F4_2). unfold magma_op, reff178_inst, reff178_op in H. discriminate H. Qed.

Lemma reff178_not2847 : ~ @Equation2847 Fin4 reff178_inst.
Proof. unfold Equation2847. intro H. specialize (H F4_1). unfold magma_op, reff178_inst, reff178_op in H. discriminate H. Qed.

Lemma reff178_not3050 : ~ @Equation3050 Fin4 reff178_inst.
Proof. unfold Equation3050. intro H. specialize (H F4_2). unfold magma_op, reff178_inst, reff178_op in H. discriminate H. Qed.

Lemma reff178_not3254 : ~ @Equation3254 Fin4 reff178_inst.
Proof. unfold Equation3254. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff178_inst, reff178_op in H. discriminate H. Qed.

Lemma reff178_not3255 : ~ @Equation3255 Fin4 reff178_inst.
Proof. unfold Equation3255. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff178_inst, reff178_op in H. discriminate H. Qed.

Lemma reff178_not3256 : ~ @Equation3256 Fin4 reff178_inst.
Proof. unfold Equation3256. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff178_inst, reff178_op in H. discriminate H. Qed.

Lemma reff178_not3259 : ~ @Equation3259 Fin4 reff178_inst.
Proof. unfold Equation3259. intro H. specialize (H F4_1 F4_3). unfold magma_op, reff178_inst, reff178_op in H. discriminate H. Qed.

Lemma reff178_not3261 : ~ @Equation3261 Fin4 reff178_inst.
Proof. unfold Equation3261. intro H. specialize (H F4_1 F4_2). unfold magma_op, reff178_inst, reff178_op in H. discriminate H. Qed.

Lemma reff178_not3268 : ~ @Equation3268 Fin4 reff178_inst.
Proof. unfold Equation3268. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff178_inst, reff178_op in H. discriminate H. Qed.

Lemma reff178_not3271 : ~ @Equation3271 Fin4 reff178_inst.
Proof. unfold Equation3271. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff178_inst, reff178_op in H. discriminate H. Qed.

Lemma reff178_not3272 : ~ @Equation3272 Fin4 reff178_inst.
Proof. unfold Equation3272. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff178_inst, reff178_op in H. discriminate H. Qed.

Lemma reff178_not3278 : ~ @Equation3278 Fin4 reff178_inst.
Proof. unfold Equation3278. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff178_inst, reff178_op in H. discriminate H. Qed.

Lemma reff178_not3279 : ~ @Equation3279 Fin4 reff178_inst.
Proof. unfold Equation3279. intro H. specialize (H F4_0 F4_3). unfold magma_op, reff178_inst, reff178_op in H. discriminate H. Qed.

Lemma reff178_not3281 : ~ @Equation3281 Fin4 reff178_inst.
Proof. unfold Equation3281. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff178_inst, reff178_op in H. discriminate H. Qed.

Lemma reff178_not3308 : ~ @Equation3308 Fin4 reff178_inst.
Proof. unfold Equation3308. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff178_inst, reff178_op in H. discriminate H. Qed.

Lemma reff178_not3309 : ~ @Equation3309 Fin4 reff178_inst.
Proof. unfold Equation3309. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff178_inst, reff178_op in H. discriminate H. Qed.

Lemma reff178_not3315 : ~ @Equation3315 Fin4 reff178_inst.
Proof. unfold Equation3315. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff178_inst, reff178_op in H. discriminate H. Qed.

Lemma reff178_not3316 : ~ @Equation3316 Fin4 reff178_inst.
Proof. unfold Equation3316. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff178_inst, reff178_op in H. discriminate H. Qed.

Lemma reff178_not3318 : ~ @Equation3318 Fin4 reff178_inst.
Proof. unfold Equation3318. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff178_inst, reff178_op in H. discriminate H. Qed.

Lemma reff178_not3319 : ~ @Equation3319 Fin4 reff178_inst.
Proof. unfold Equation3319. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff178_inst, reff178_op in H. discriminate H. Qed.

Lemma reff178_not3342 : ~ @Equation3342 Fin4 reff178_inst.
Proof. unfold Equation3342. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff178_inst, reff178_op in H. discriminate H. Qed.

Lemma reff178_not3343 : ~ @Equation3343 Fin4 reff178_inst.
Proof. unfold Equation3343. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff178_inst, reff178_op in H. discriminate H. Qed.

Lemma reff178_not3345 : ~ @Equation3345 Fin4 reff178_inst.
Proof. unfold Equation3345. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff178_inst, reff178_op in H. discriminate H. Qed.

Lemma reff178_not3346 : ~ @Equation3346 Fin4 reff178_inst.
Proof. unfold Equation3346. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff178_inst, reff178_op in H. discriminate H. Qed.

Lemma reff178_not3352 : ~ @Equation3352 Fin4 reff178_inst.
Proof. unfold Equation3352. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff178_inst, reff178_op in H. discriminate H. Qed.

Lemma reff178_not3353 : ~ @Equation3353 Fin4 reff178_inst.
Proof. unfold Equation3353. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff178_inst, reff178_op in H. discriminate H. Qed.

Lemma reff178_not3456 : ~ @Equation3456 Fin4 reff178_inst.
Proof. unfold Equation3456. intro H. specialize (H F4_1). unfold magma_op, reff178_inst, reff178_op in H. discriminate H. Qed.

Lemma reff178_not3659 : ~ @Equation3659 Fin4 reff178_inst.
Proof. unfold Equation3659. intro H. specialize (H F4_1). unfold magma_op, reff178_inst, reff178_op in H. discriminate H. Qed.

Lemma reff178_not3862 : ~ @Equation3862 Fin4 reff178_inst.
Proof. unfold Equation3862. intro H. specialize (H F4_1). unfold magma_op, reff178_inst, reff178_op in H. discriminate H. Qed.

Lemma reff178_not4065 : ~ @Equation4065 Fin4 reff178_inst.
Proof. unfold Equation4065. intro H. specialize (H F4_1). unfold magma_op, reff178_inst, reff178_op in H. discriminate H. Qed.

Lemma reff178_not4268 : ~ @Equation4268 Fin4 reff178_inst.
Proof. unfold Equation4268. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff178_inst, reff178_op in H. discriminate H. Qed.

Lemma reff178_not4269 : ~ @Equation4269 Fin4 reff178_inst.
Proof. unfold Equation4269. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff178_inst, reff178_op in H. discriminate H. Qed.

Lemma reff178_not4270 : ~ @Equation4270 Fin4 reff178_inst.
Proof. unfold Equation4270. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff178_inst, reff178_op in H. discriminate H. Qed.

Lemma reff178_not4272 : ~ @Equation4272 Fin4 reff178_inst.
Proof. unfold Equation4272. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff178_inst, reff178_op in H. discriminate H. Qed.

Lemma reff178_not4273 : ~ @Equation4273 Fin4 reff178_inst.
Proof. unfold Equation4273. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff178_inst, reff178_op in H. discriminate H. Qed.

Lemma reff178_not4275 : ~ @Equation4275 Fin4 reff178_inst.
Proof. unfold Equation4275. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff178_inst, reff178_op in H. discriminate H. Qed.

Lemma reff178_not4283 : ~ @Equation4283 Fin4 reff178_inst.
Proof. unfold Equation4283. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff178_inst, reff178_op in H. discriminate H. Qed.

Lemma reff178_not4284 : ~ @Equation4284 Fin4 reff178_inst.
Proof. unfold Equation4284. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff178_inst, reff178_op in H. discriminate H. Qed.

Lemma reff178_not4290 : ~ @Equation4290 Fin4 reff178_inst.
Proof. unfold Equation4290. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff178_inst, reff178_op in H. discriminate H. Qed.

Lemma reff178_not4291 : ~ @Equation4291 Fin4 reff178_inst.
Proof. unfold Equation4291. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff178_inst, reff178_op in H. discriminate H. Qed.

Lemma reff178_not4293 : ~ @Equation4293 Fin4 reff178_inst.
Proof. unfold Equation4293. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff178_inst, reff178_op in H. discriminate H. Qed.

Lemma reff178_not4314 : ~ @Equation4314 Fin4 reff178_inst.
Proof. unfold Equation4314. intro H. specialize (H F4_1 F4_2). unfold magma_op, reff178_inst, reff178_op in H. discriminate H. Qed.

Lemma reff178_not4320 : ~ @Equation4320 Fin4 reff178_inst.
Proof. unfold Equation4320. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff178_inst, reff178_op in H. discriminate H. Qed.

Lemma reff178_not4321 : ~ @Equation4321 Fin4 reff178_inst.
Proof. unfold Equation4321. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff178_inst, reff178_op in H. discriminate H. Qed.

Lemma reff178_not4343 : ~ @Equation4343 Fin4 reff178_inst.
Proof. unfold Equation4343. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff178_inst, reff178_op in H. discriminate H. Qed.

Lemma reff178_not4380 : ~ @Equation4380 Fin4 reff178_inst.
Proof. unfold Equation4380. intro H. specialize (H F4_1). unfold magma_op, reff178_inst, reff178_op in H. discriminate H. Qed.

Lemma reff178_not4583 : ~ @Equation4583 Fin4 reff178_inst.
Proof. unfold Equation4583. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff178_inst, reff178_op in H. discriminate H. Qed.

Lemma reff178_not4584 : ~ @Equation4584 Fin4 reff178_inst.
Proof. unfold Equation4584. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff178_inst, reff178_op in H. discriminate H. Qed.

Lemma reff178_not4585 : ~ @Equation4585 Fin4 reff178_inst.
Proof. unfold Equation4585. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff178_inst, reff178_op in H. discriminate H. Qed.

Lemma reff178_not4587 : ~ @Equation4587 Fin4 reff178_inst.
Proof. unfold Equation4587. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff178_inst, reff178_op in H. discriminate H. Qed.

Lemma reff178_not4588 : ~ @Equation4588 Fin4 reff178_inst.
Proof. unfold Equation4588. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff178_inst, reff178_op in H. discriminate H. Qed.

Lemma reff178_not4590 : ~ @Equation4590 Fin4 reff178_inst.
Proof. unfold Equation4590. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff178_inst, reff178_op in H. discriminate H. Qed.

Lemma reff178_not4591 : ~ @Equation4591 Fin4 reff178_inst.
Proof. unfold Equation4591. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff178_inst, reff178_op in H. discriminate H. Qed.

Lemma reff178_not4598 : ~ @Equation4598 Fin4 reff178_inst.
Proof. unfold Equation4598. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff178_inst, reff178_op in H. discriminate H. Qed.

Lemma reff178_not4599 : ~ @Equation4599 Fin4 reff178_inst.
Proof. unfold Equation4599. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff178_inst, reff178_op in H. discriminate H. Qed.

Lemma reff178_not4605 : ~ @Equation4605 Fin4 reff178_inst.
Proof. unfold Equation4605. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff178_inst, reff178_op in H. discriminate H. Qed.

Lemma reff178_not4606 : ~ @Equation4606 Fin4 reff178_inst.
Proof. unfold Equation4606. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff178_inst, reff178_op in H. discriminate H. Qed.

Lemma reff178_not4608 : ~ @Equation4608 Fin4 reff178_inst.
Proof. unfold Equation4608. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff178_inst, reff178_op in H. discriminate H. Qed.

Lemma reff178_not4629 : ~ @Equation4629 Fin4 reff178_inst.
Proof. unfold Equation4629. intro H. specialize (H F4_0 F4_3). unfold magma_op, reff178_inst, reff178_op in H. discriminate H. Qed.

Lemma reff178_not4635 : ~ @Equation4635 Fin4 reff178_inst.
Proof. unfold Equation4635. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff178_inst, reff178_op in H. discriminate H. Qed.

Lemma reff178_not4636 : ~ @Equation4636 Fin4 reff178_inst.
Proof. unfold Equation4636. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff178_inst, reff178_op in H. discriminate H. Qed.

Lemma reff178_not4658 : ~ @Equation4658 Fin4 reff178_inst.
Proof. unfold Equation4658. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff178_inst, reff178_op in H. discriminate H. Qed.

(** ---- reff18 (Fin4) ---- *)

Definition reff18_op (x y : Fin4) : Fin4 :=
  match x, y with
  | F4_0, F4_0 => F4_0 | F4_0, F4_1 => F4_1 | F4_0, F4_2 => F4_0 | F4_0, F4_3 => F4_1
  | F4_1, F4_0 => F4_0 | F4_1, F4_1 => F4_0 | F4_1, F4_2 => F4_2 | F4_1, F4_3 => F4_2
  | F4_2, F4_0 => F4_0 | F4_2, F4_1 => F4_3 | F4_2, F4_2 => F4_0 | F4_2, F4_3 => F4_3
  | F4_3, F4_0 => F4_0 | F4_3, F4_1 => F4_2 | F4_3, F4_2 => F4_2 | F4_3, F4_3 => F4_0
  end.

#[local] Instance reff18_inst : Magma Fin4 := {| magma_op := reff18_op |}.

Lemma reff18_sat316 : @Equation316 Fin4 reff18_inst.
Proof. unfold Equation316, magma_op, reff18_inst, reff18_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff18_sat323 : @Equation323 Fin4 reff18_inst.
Proof. unfold Equation323, magma_op, reff18_inst, reff18_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff18_not47 : ~ @Equation47 Fin4 reff18_inst.
Proof. unfold Equation47. intro H. specialize (H F4_1). unfold magma_op, reff18_inst, reff18_op in H. discriminate H. Qed.

Lemma reff18_not99 : ~ @Equation99 Fin4 reff18_inst.
Proof. unfold Equation99. intro H. specialize (H F4_1). unfold magma_op, reff18_inst, reff18_op in H. discriminate H. Qed.

Lemma reff18_not151 : ~ @Equation151 Fin4 reff18_inst.
Proof. unfold Equation151. intro H. specialize (H F4_1). unfold magma_op, reff18_inst, reff18_op in H. discriminate H. Qed.

Lemma reff18_not203 : ~ @Equation203 Fin4 reff18_inst.
Proof. unfold Equation203. intro H. specialize (H F4_2). unfold magma_op, reff18_inst, reff18_op in H. discriminate H. Qed.

Lemma reff18_not255 : ~ @Equation255 Fin4 reff18_inst.
Proof. unfold Equation255. intro H. specialize (H F4_1). unfold magma_op, reff18_inst, reff18_op in H. discriminate H. Qed.

Lemma reff18_not411 : ~ @Equation411 Fin4 reff18_inst.
Proof. unfold Equation411. intro H. specialize (H F4_1). unfold magma_op, reff18_inst, reff18_op in H. discriminate H. Qed.

Lemma reff18_not614 : ~ @Equation614 Fin4 reff18_inst.
Proof. unfold Equation614. intro H. specialize (H F4_1). unfold magma_op, reff18_inst, reff18_op in H. discriminate H. Qed.

Lemma reff18_not817 : ~ @Equation817 Fin4 reff18_inst.
Proof. unfold Equation817. intro H. specialize (H F4_1). unfold magma_op, reff18_inst, reff18_op in H. discriminate H. Qed.

Lemma reff18_not1020 : ~ @Equation1020 Fin4 reff18_inst.
Proof. unfold Equation1020. intro H. specialize (H F4_1). unfold magma_op, reff18_inst, reff18_op in H. discriminate H. Qed.

Lemma reff18_not1223 : ~ @Equation1223 Fin4 reff18_inst.
Proof. unfold Equation1223. intro H. specialize (H F4_1). unfold magma_op, reff18_inst, reff18_op in H. discriminate H. Qed.

Lemma reff18_not1426 : ~ @Equation1426 Fin4 reff18_inst.
Proof. unfold Equation1426. intro H. specialize (H F4_1). unfold magma_op, reff18_inst, reff18_op in H. discriminate H. Qed.

Lemma reff18_not1629 : ~ @Equation1629 Fin4 reff18_inst.
Proof. unfold Equation1629. intro H. specialize (H F4_2). unfold magma_op, reff18_inst, reff18_op in H. discriminate H. Qed.

Lemma reff18_not1832 : ~ @Equation1832 Fin4 reff18_inst.
Proof. unfold Equation1832. intro H. specialize (H F4_1). unfold magma_op, reff18_inst, reff18_op in H. discriminate H. Qed.

Lemma reff18_not2035 : ~ @Equation2035 Fin4 reff18_inst.
Proof. unfold Equation2035. intro H. specialize (H F4_1). unfold magma_op, reff18_inst, reff18_op in H. discriminate H. Qed.

Lemma reff18_not2238 : ~ @Equation2238 Fin4 reff18_inst.
Proof. unfold Equation2238. intro H. specialize (H F4_2). unfold magma_op, reff18_inst, reff18_op in H. discriminate H. Qed.

Lemma reff18_not2441 : ~ @Equation2441 Fin4 reff18_inst.
Proof. unfold Equation2441. intro H. specialize (H F4_2). unfold magma_op, reff18_inst, reff18_op in H. discriminate H. Qed.

Lemma reff18_not2644 : ~ @Equation2644 Fin4 reff18_inst.
Proof. unfold Equation2644. intro H. specialize (H F4_2). unfold magma_op, reff18_inst, reff18_op in H. discriminate H. Qed.

Lemma reff18_not2847 : ~ @Equation2847 Fin4 reff18_inst.
Proof. unfold Equation2847. intro H. specialize (H F4_1). unfold magma_op, reff18_inst, reff18_op in H. discriminate H. Qed.

Lemma reff18_not3050 : ~ @Equation3050 Fin4 reff18_inst.
Proof. unfold Equation3050. intro H. specialize (H F4_2). unfold magma_op, reff18_inst, reff18_op in H. discriminate H. Qed.

Lemma reff18_not3254 : ~ @Equation3254 Fin4 reff18_inst.
Proof. unfold Equation3254. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff18_inst, reff18_op in H. discriminate H. Qed.

Lemma reff18_not3255 : ~ @Equation3255 Fin4 reff18_inst.
Proof. unfold Equation3255. intro H. specialize (H F4_1 F4_2). unfold magma_op, reff18_inst, reff18_op in H. discriminate H. Qed.

Lemma reff18_not3259 : ~ @Equation3259 Fin4 reff18_inst.
Proof. unfold Equation3259. intro H. specialize (H F4_1 F4_3). unfold magma_op, reff18_inst, reff18_op in H. discriminate H. Qed.

Lemma reff18_not3261 : ~ @Equation3261 Fin4 reff18_inst.
Proof. unfold Equation3261. intro H. specialize (H F4_1 F4_2). unfold magma_op, reff18_inst, reff18_op in H. discriminate H. Qed.

Lemma reff18_not3269 : ~ @Equation3269 Fin4 reff18_inst.
Proof. unfold Equation3269. intro H. specialize (H F4_0 F4_3). unfold magma_op, reff18_inst, reff18_op in H. discriminate H. Qed.

Lemma reff18_not3271 : ~ @Equation3271 Fin4 reff18_inst.
Proof. unfold Equation3271. intro H. specialize (H F4_1 F4_3). unfold magma_op, reff18_inst, reff18_op in H. discriminate H. Qed.

Lemma reff18_not3279 : ~ @Equation3279 Fin4 reff18_inst.
Proof. unfold Equation3279. intro H. specialize (H F4_0 F4_3). unfold magma_op, reff18_inst, reff18_op in H. discriminate H. Qed.

Lemma reff18_not3281 : ~ @Equation3281 Fin4 reff18_inst.
Proof. unfold Equation3281. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff18_inst, reff18_op in H. discriminate H. Qed.

Lemma reff18_not3308 : ~ @Equation3308 Fin4 reff18_inst.
Proof. unfold Equation3308. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff18_inst, reff18_op in H. discriminate H. Qed.

Lemma reff18_not3309 : ~ @Equation3309 Fin4 reff18_inst.
Proof. unfold Equation3309. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff18_inst, reff18_op in H. discriminate H. Qed.

Lemma reff18_not3315 : ~ @Equation3315 Fin4 reff18_inst.
Proof. unfold Equation3315. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff18_inst, reff18_op in H. discriminate H. Qed.

Lemma reff18_not3316 : ~ @Equation3316 Fin4 reff18_inst.
Proof. unfold Equation3316. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff18_inst, reff18_op in H. discriminate H. Qed.

Lemma reff18_not3318 : ~ @Equation3318 Fin4 reff18_inst.
Proof. unfold Equation3318. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff18_inst, reff18_op in H. discriminate H. Qed.

Lemma reff18_not3319 : ~ @Equation3319 Fin4 reff18_inst.
Proof. unfold Equation3319. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff18_inst, reff18_op in H. discriminate H. Qed.

Lemma reff18_not3342 : ~ @Equation3342 Fin4 reff18_inst.
Proof. unfold Equation3342. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff18_inst, reff18_op in H. discriminate H. Qed.

Lemma reff18_not3343 : ~ @Equation3343 Fin4 reff18_inst.
Proof. unfold Equation3343. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff18_inst, reff18_op in H. discriminate H. Qed.

Lemma reff18_not3345 : ~ @Equation3345 Fin4 reff18_inst.
Proof. unfold Equation3345. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff18_inst, reff18_op in H. discriminate H. Qed.

Lemma reff18_not3346 : ~ @Equation3346 Fin4 reff18_inst.
Proof. unfold Equation3346. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff18_inst, reff18_op in H. discriminate H. Qed.

Lemma reff18_not3352 : ~ @Equation3352 Fin4 reff18_inst.
Proof. unfold Equation3352. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff18_inst, reff18_op in H. discriminate H. Qed.

Lemma reff18_not3353 : ~ @Equation3353 Fin4 reff18_inst.
Proof. unfold Equation3353. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff18_inst, reff18_op in H. discriminate H. Qed.

Lemma reff18_not3456 : ~ @Equation3456 Fin4 reff18_inst.
Proof. unfold Equation3456. intro H. specialize (H F4_3). unfold magma_op, reff18_inst, reff18_op in H. discriminate H. Qed.

Lemma reff18_not3660 : ~ @Equation3660 Fin4 reff18_inst.
Proof. unfold Equation3660. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff18_inst, reff18_op in H. discriminate H. Qed.

Lemma reff18_not3661 : ~ @Equation3661 Fin4 reff18_inst.
Proof. unfold Equation3661. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff18_inst, reff18_op in H. discriminate H. Qed.

Lemma reff18_not3667 : ~ @Equation3667 Fin4 reff18_inst.
Proof. unfold Equation3667. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff18_inst, reff18_op in H. discriminate H. Qed.

Lemma reff18_not3675 : ~ @Equation3675 Fin4 reff18_inst.
Proof. unfold Equation3675. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff18_inst, reff18_op in H. discriminate H. Qed.

Lemma reff18_not3685 : ~ @Equation3685 Fin4 reff18_inst.
Proof. unfold Equation3685. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff18_inst, reff18_op in H. discriminate H. Qed.

Lemma reff18_not3687 : ~ @Equation3687 Fin4 reff18_inst.
Proof. unfold Equation3687. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff18_inst, reff18_op in H. discriminate H. Qed.

Lemma reff18_not3712 : ~ @Equation3712 Fin4 reff18_inst.
Proof. unfold Equation3712. intro H. specialize (H F4_1 F4_2). unfold magma_op, reff18_inst, reff18_op in H. discriminate H. Qed.

Lemma reff18_not3714 : ~ @Equation3714 Fin4 reff18_inst.
Proof. unfold Equation3714. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff18_inst, reff18_op in H. discriminate H. Qed.

Lemma reff18_not3721 : ~ @Equation3721 Fin4 reff18_inst.
Proof. unfold Equation3721. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff18_inst, reff18_op in H. discriminate H. Qed.

Lemma reff18_not3722 : ~ @Equation3722 Fin4 reff18_inst.
Proof. unfold Equation3722. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff18_inst, reff18_op in H. discriminate H. Qed.

Lemma reff18_not3724 : ~ @Equation3724 Fin4 reff18_inst.
Proof. unfold Equation3724. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff18_inst, reff18_op in H. discriminate H. Qed.

Lemma reff18_not3725 : ~ @Equation3725 Fin4 reff18_inst.
Proof. unfold Equation3725. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff18_inst, reff18_op in H. discriminate H. Qed.

Lemma reff18_not3748 : ~ @Equation3748 Fin4 reff18_inst.
Proof. unfold Equation3748. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff18_inst, reff18_op in H. discriminate H. Qed.

Lemma reff18_not3749 : ~ @Equation3749 Fin4 reff18_inst.
Proof. unfold Equation3749. intro H. specialize (H F4_1 F4_3). unfold magma_op, reff18_inst, reff18_op in H. discriminate H. Qed.

Lemma reff18_not3751 : ~ @Equation3751 Fin4 reff18_inst.
Proof. unfold Equation3751. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff18_inst, reff18_op in H. discriminate H. Qed.

Lemma reff18_not3752 : ~ @Equation3752 Fin4 reff18_inst.
Proof. unfold Equation3752. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff18_inst, reff18_op in H. discriminate H. Qed.

Lemma reff18_not3759 : ~ @Equation3759 Fin4 reff18_inst.
Proof. unfold Equation3759. intro H. specialize (H F4_1 F4_2). unfold magma_op, reff18_inst, reff18_op in H. discriminate H. Qed.

Lemma reff18_not3761 : ~ @Equation3761 Fin4 reff18_inst.
Proof. unfold Equation3761. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff18_inst, reff18_op in H. discriminate H. Qed.

Lemma reff18_not3862 : ~ @Equation3862 Fin4 reff18_inst.
Proof. unfold Equation3862. intro H. specialize (H F4_1). unfold magma_op, reff18_inst, reff18_op in H. discriminate H. Qed.

Lemma reff18_not4065 : ~ @Equation4065 Fin4 reff18_inst.
Proof. unfold Equation4065. intro H. specialize (H F4_3). unfold magma_op, reff18_inst, reff18_op in H. discriminate H. Qed.

Lemma reff18_not4268 : ~ @Equation4268 Fin4 reff18_inst.
Proof. unfold Equation4268. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff18_inst, reff18_op in H. discriminate H. Qed.

Lemma reff18_not4269 : ~ @Equation4269 Fin4 reff18_inst.
Proof. unfold Equation4269. intro H. specialize (H F4_1 F4_2). unfold magma_op, reff18_inst, reff18_op in H. discriminate H. Qed.

Lemma reff18_not4273 : ~ @Equation4273 Fin4 reff18_inst.
Proof. unfold Equation4273. intro H. specialize (H F4_0 F4_3). unfold magma_op, reff18_inst, reff18_op in H. discriminate H. Qed.

Lemma reff18_not4275 : ~ @Equation4275 Fin4 reff18_inst.
Proof. unfold Equation4275. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff18_inst, reff18_op in H. discriminate H. Qed.

Lemma reff18_not4283 : ~ @Equation4283 Fin4 reff18_inst.
Proof. unfold Equation4283. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff18_inst, reff18_op in H. discriminate H. Qed.

Lemma reff18_not4284 : ~ @Equation4284 Fin4 reff18_inst.
Proof. unfold Equation4284. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff18_inst, reff18_op in H. discriminate H. Qed.

Lemma reff18_not4290 : ~ @Equation4290 Fin4 reff18_inst.
Proof. unfold Equation4290. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff18_inst, reff18_op in H. discriminate H. Qed.

Lemma reff18_not4291 : ~ @Equation4291 Fin4 reff18_inst.
Proof. unfold Equation4291. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff18_inst, reff18_op in H. discriminate H. Qed.

Lemma reff18_not4293 : ~ @Equation4293 Fin4 reff18_inst.
Proof. unfold Equation4293. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff18_inst, reff18_op in H. discriminate H. Qed.

Lemma reff18_not4314 : ~ @Equation4314 Fin4 reff18_inst.
Proof. unfold Equation4314. intro H. specialize (H F4_1 F4_2). unfold magma_op, reff18_inst, reff18_op in H. discriminate H. Qed.

Lemma reff18_not4320 : ~ @Equation4320 Fin4 reff18_inst.
Proof. unfold Equation4320. intro H. specialize (H F4_1 F4_2). unfold magma_op, reff18_inst, reff18_op in H. discriminate H. Qed.

Lemma reff18_not4321 : ~ @Equation4321 Fin4 reff18_inst.
Proof. unfold Equation4321. intro H. specialize (H F4_0 F4_3). unfold magma_op, reff18_inst, reff18_op in H. discriminate H. Qed.

Lemma reff18_not4380 : ~ @Equation4380 Fin4 reff18_inst.
Proof. unfold Equation4380. intro H. specialize (H F4_1). unfold magma_op, reff18_inst, reff18_op in H. discriminate H. Qed.

Lemma reff18_not4583 : ~ @Equation4583 Fin4 reff18_inst.
Proof. unfold Equation4583. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff18_inst, reff18_op in H. discriminate H. Qed.

Lemma reff18_not4584 : ~ @Equation4584 Fin4 reff18_inst.
Proof. unfold Equation4584. intro H. specialize (H F4_1 F4_2). unfold magma_op, reff18_inst, reff18_op in H. discriminate H. Qed.

Lemma reff18_not4585 : ~ @Equation4585 Fin4 reff18_inst.
Proof. unfold Equation4585. intro H. specialize (H F4_0 F4_3). unfold magma_op, reff18_inst, reff18_op in H. discriminate H. Qed.

Lemma reff18_not4587 : ~ @Equation4587 Fin4 reff18_inst.
Proof. unfold Equation4587. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff18_inst, reff18_op in H. discriminate H. Qed.

Lemma reff18_not4588 : ~ @Equation4588 Fin4 reff18_inst.
Proof. unfold Equation4588. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff18_inst, reff18_op in H. discriminate H. Qed.

Lemma reff18_not4591 : ~ @Equation4591 Fin4 reff18_inst.
Proof. unfold Equation4591. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff18_inst, reff18_op in H. discriminate H. Qed.

Lemma reff18_not4598 : ~ @Equation4598 Fin4 reff18_inst.
Proof. unfold Equation4598. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff18_inst, reff18_op in H. discriminate H. Qed.

Lemma reff18_not4599 : ~ @Equation4599 Fin4 reff18_inst.
Proof. unfold Equation4599. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff18_inst, reff18_op in H. discriminate H. Qed.

Lemma reff18_not4605 : ~ @Equation4605 Fin4 reff18_inst.
Proof. unfold Equation4605. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff18_inst, reff18_op in H. discriminate H. Qed.

Lemma reff18_not4606 : ~ @Equation4606 Fin4 reff18_inst.
Proof. unfold Equation4606. intro H. specialize (H F4_1 F4_2). unfold magma_op, reff18_inst, reff18_op in H. discriminate H. Qed.

Lemma reff18_not4608 : ~ @Equation4608 Fin4 reff18_inst.
Proof. unfold Equation4608. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff18_inst, reff18_op in H. discriminate H. Qed.

Lemma reff18_not4629 : ~ @Equation4629 Fin4 reff18_inst.
Proof. unfold Equation4629. intro H. specialize (H F4_0 F4_3). unfold magma_op, reff18_inst, reff18_op in H. discriminate H. Qed.

Lemma reff18_not4635 : ~ @Equation4635 Fin4 reff18_inst.
Proof. unfold Equation4635. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff18_inst, reff18_op in H. discriminate H. Qed.

Lemma reff18_not4636 : ~ @Equation4636 Fin4 reff18_inst.
Proof. unfold Equation4636. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff18_inst, reff18_op in H. discriminate H. Qed.

Lemma reff18_not4658 : ~ @Equation4658 Fin4 reff18_inst.
Proof. unfold Equation4658. intro H. specialize (H F4_0 F4_3). unfold magma_op, reff18_inst, reff18_op in H. discriminate H. Qed.
