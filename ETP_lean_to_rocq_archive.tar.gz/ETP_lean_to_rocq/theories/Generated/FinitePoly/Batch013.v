(** * FinitePoly counterexamples — batch 13
    Auto-generated from Lean4 FinitePoly files. *)

From Stdlib Require Import Utf8.

From ETP Require Import Magma.
From ETP Require Import FinMagma.
From ETP.Equations Require Import All.

Open Scope magma_scope.

(** ---- reff690 (Fin5) ---- *)

Definition reff690_op (x y : Fin5) : Fin5 :=
  match x, y with
  | F5_0, F5_0 => F5_0 | F5_0, F5_1 => F5_2 | F5_0, F5_2 => F5_4 | F5_0, F5_3 => F5_1 | F5_0, F5_4 => F5_3
  | F5_1, F5_0 => F5_2 | F5_1, F5_1 => F5_4 | F5_1, F5_2 => F5_1 | F5_1, F5_3 => F5_3 | F5_1, F5_4 => F5_0
  | F5_2, F5_0 => F5_4 | F5_2, F5_1 => F5_1 | F5_2, F5_2 => F5_3 | F5_2, F5_3 => F5_0 | F5_2, F5_4 => F5_2
  | F5_3, F5_0 => F5_1 | F5_3, F5_1 => F5_3 | F5_3, F5_2 => F5_0 | F5_3, F5_3 => F5_2 | F5_3, F5_4 => F5_4
  | F5_4, F5_0 => F5_3 | F5_4, F5_1 => F5_0 | F5_4, F5_2 => F5_2 | F5_4, F5_3 => F5_4 | F5_4, F5_4 => F5_1
  end.

#[local] Instance reff690_inst : Magma Fin5 := {| magma_op := reff690_op |}.

Lemma reff690_sat43 : @Equation43 Fin5 reff690_inst.
Proof. unfold Equation43, magma_op, reff690_inst, reff690_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff690_sat151 : @Equation151 Fin5 reff690_inst.
Proof. unfold Equation151, magma_op, reff690_inst, reff690_op. intros x. destruct x; reflexivity. Qed.

Lemma reff690_sat420 : @Equation420 Fin5 reff690_inst.
Proof. unfold Equation420, magma_op, reff690_inst, reff690_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff690_sat556 : @Equation556 Fin5 reff690_inst.
Proof. unfold Equation556, magma_op, reff690_inst, reff690_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff690_sat623 : @Equation623 Fin5 reff690_inst.
Proof. unfold Equation623, magma_op, reff690_inst, reff690_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff690_sat749 : @Equation749 Fin5 reff690_inst.
Proof. unfold Equation749, magma_op, reff690_inst, reff690_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff690_sat775 : @Equation775 Fin5 reff690_inst.
Proof. unfold Equation775, magma_op, reff690_inst, reff690_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff690_sat1048 : @Equation1048 Fin5 reff690_inst.
Proof. unfold Equation1048, magma_op, reff690_inst, reff690_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff690_sat1117 : @Equation1117 Fin5 reff690_inst.
Proof. unfold Equation1117, magma_op, reff690_inst, reff690_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff690_sat1131 : @Equation1131 Fin5 reff690_inst.
Proof. unfold Equation1131, magma_op, reff690_inst, reff690_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff690_sat1251 : @Equation1251 Fin5 reff690_inst.
Proof. unfold Equation1251, magma_op, reff690_inst, reff690_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff690_sat1301 : @Equation1301 Fin5 reff690_inst.
Proof. unfold Equation1301, magma_op, reff690_inst, reff690_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff690_sat1355 : @Equation1355 Fin5 reff690_inst.
Proof. unfold Equation1355, magma_op, reff690_inst, reff690_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff690_sat2266 : @Equation2266 Fin5 reff690_inst.
Proof. unfold Equation2266, magma_op, reff690_inst, reff690_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff690_sat2370 : @Equation2370 Fin5 reff690_inst.
Proof. unfold Equation2370, magma_op, reff690_inst, reff690_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff690_sat2383 : @Equation2383 Fin5 reff690_inst.
Proof. unfold Equation2383, magma_op, reff690_inst, reff690_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff690_sat2469 : @Equation2469 Fin5 reff690_inst.
Proof. unfold Equation2469, magma_op, reff690_inst, reff690_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff690_sat2511 : @Equation2511 Fin5 reff690_inst.
Proof. unfold Equation2511, magma_op, reff690_inst, reff690_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff690_sat2538 : @Equation2538 Fin5 reff690_inst.
Proof. unfold Equation2538, magma_op, reff690_inst, reff690_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff690_sat2928 : @Equation2928 Fin5 reff690_inst.
Proof. unfold Equation2928, magma_op, reff690_inst, reff690_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff690_sat2946 : @Equation2946 Fin5 reff690_inst.
Proof. unfold Equation2946, magma_op, reff690_inst, reff690_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff690_sat2982 : @Equation2982 Fin5 reff690_inst.
Proof. unfold Equation2982, magma_op, reff690_inst, reff690_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff690_sat3128 : @Equation3128 Fin5 reff690_inst.
Proof. unfold Equation3128, magma_op, reff690_inst, reff690_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff690_sat3149 : @Equation3149 Fin5 reff690_inst.
Proof. unfold Equation3149, magma_op, reff690_inst, reff690_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff690_sat4389 : @Equation4389 Fin5 reff690_inst.
Proof. unfold Equation4389, magma_op, reff690_inst, reff690_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff690_not47 : ~ @Equation47 Fin5 reff690_inst.
Proof. unfold Equation47. intro H. specialize (H F5_1). unfold magma_op, reff690_inst, reff690_op in H. discriminate H. Qed.

Lemma reff690_not99 : ~ @Equation99 Fin5 reff690_inst.
Proof. unfold Equation99. intro H. specialize (H F5_1). unfold magma_op, reff690_inst, reff690_op in H. discriminate H. Qed.

Lemma reff690_not154 : ~ @Equation154 Fin5 reff690_inst.
Proof. unfold Equation154. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff690_inst, reff690_op in H. discriminate H. Qed.

Lemma reff690_not157 : ~ @Equation157 Fin5 reff690_inst.
Proof. unfold Equation157. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff690_inst, reff690_op in H. discriminate H. Qed.

Lemma reff690_not159 : ~ @Equation159 Fin5 reff690_inst.
Proof. unfold Equation159. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff690_inst, reff690_op in H. discriminate H. Qed.

Lemma reff690_not160 : ~ @Equation160 Fin5 reff690_inst.
Proof. unfold Equation160. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff690_inst, reff690_op in H. discriminate H. Qed.

Lemma reff690_not167 : ~ @Equation167 Fin5 reff690_inst.
Proof. unfold Equation167. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff690_inst, reff690_op in H. discriminate H. Qed.

Lemma reff690_not169 : ~ @Equation169 Fin5 reff690_inst.
Proof. unfold Equation169. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff690_inst, reff690_op in H. discriminate H. Qed.

Lemma reff690_not170 : ~ @Equation170 Fin5 reff690_inst.
Proof. unfold Equation170. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff690_inst, reff690_op in H. discriminate H. Qed.

Lemma reff690_not176 : ~ @Equation176 Fin5 reff690_inst.
Proof. unfold Equation176. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff690_inst, reff690_op in H. discriminate H. Qed.

Lemma reff690_not177 : ~ @Equation177 Fin5 reff690_inst.
Proof. unfold Equation177. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff690_inst, reff690_op in H. discriminate H. Qed.

Lemma reff690_not179 : ~ @Equation179 Fin5 reff690_inst.
Proof. unfold Equation179. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff690_inst, reff690_op in H. discriminate H. Qed.

Lemma reff690_not203 : ~ @Equation203 Fin5 reff690_inst.
Proof. unfold Equation203. intro H. specialize (H F5_1). unfold magma_op, reff690_inst, reff690_op in H. discriminate H. Qed.

Lemma reff690_not255 : ~ @Equation255 Fin5 reff690_inst.
Proof. unfold Equation255. intro H. specialize (H F5_1). unfold magma_op, reff690_inst, reff690_op in H. discriminate H. Qed.

Lemma reff690_not412 : ~ @Equation412 Fin5 reff690_inst.
Proof. unfold Equation412. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff690_inst, reff690_op in H. discriminate H. Qed.

Lemma reff690_not413 : ~ @Equation413 Fin5 reff690_inst.
Proof. unfold Equation413. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff690_inst, reff690_op in H. discriminate H. Qed.

Lemma reff690_not414 : ~ @Equation414 Fin5 reff690_inst.
Proof. unfold Equation414. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff690_inst, reff690_op in H. discriminate H. Qed.

Lemma reff690_not416 : ~ @Equation416 Fin5 reff690_inst.
Proof. unfold Equation416. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff690_inst, reff690_op in H. discriminate H. Qed.

Lemma reff690_not417 : ~ @Equation417 Fin5 reff690_inst.
Proof. unfold Equation417. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff690_inst, reff690_op in H. discriminate H. Qed.

Lemma reff690_not419 : ~ @Equation419 Fin5 reff690_inst.
Proof. unfold Equation419. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff690_inst, reff690_op in H. discriminate H. Qed.

Lemma reff690_not426 : ~ @Equation426 Fin5 reff690_inst.
Proof. unfold Equation426. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff690_inst, reff690_op in H. discriminate H. Qed.

Lemma reff690_not430 : ~ @Equation430 Fin5 reff690_inst.
Proof. unfold Equation430. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff690_inst, reff690_op in H. discriminate H. Qed.

Lemma reff690_not436 : ~ @Equation436 Fin5 reff690_inst.
Proof. unfold Equation436. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff690_inst, reff690_op in H. discriminate H. Qed.

Lemma reff690_not437 : ~ @Equation437 Fin5 reff690_inst.
Proof. unfold Equation437. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff690_inst, reff690_op in H. discriminate H. Qed.

Lemma reff690_not439 : ~ @Equation439 Fin5 reff690_inst.
Proof. unfold Equation439. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff690_inst, reff690_op in H. discriminate H. Qed.

Lemma reff690_not440 : ~ @Equation440 Fin5 reff690_inst.
Proof. unfold Equation440. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff690_inst, reff690_op in H. discriminate H. Qed.

Lemma reff690_not463 : ~ @Equation463 Fin5 reff690_inst.
Proof. unfold Equation463. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff690_inst, reff690_op in H. discriminate H. Qed.

Lemma reff690_not464 : ~ @Equation464 Fin5 reff690_inst.
Proof. unfold Equation464. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff690_inst, reff690_op in H. discriminate H. Qed.

Lemma reff690_not466 : ~ @Equation466 Fin5 reff690_inst.
Proof. unfold Equation466. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff690_inst, reff690_op in H. discriminate H. Qed.

Lemma reff690_not467 : ~ @Equation467 Fin5 reff690_inst.
Proof. unfold Equation467. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff690_inst, reff690_op in H. discriminate H. Qed.

Lemma reff690_not474 : ~ @Equation474 Fin5 reff690_inst.
Proof. unfold Equation474. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff690_inst, reff690_op in H. discriminate H. Qed.

Lemma reff690_not476 : ~ @Equation476 Fin5 reff690_inst.
Proof. unfold Equation476. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff690_inst, reff690_op in H. discriminate H. Qed.

Lemma reff690_not477 : ~ @Equation477 Fin5 reff690_inst.
Proof. unfold Equation477. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff690_inst, reff690_op in H. discriminate H. Qed.

Lemma reff690_not500 : ~ @Equation500 Fin5 reff690_inst.
Proof. unfold Equation500. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff690_inst, reff690_op in H. discriminate H. Qed.

Lemma reff690_not501 : ~ @Equation501 Fin5 reff690_inst.
Proof. unfold Equation501. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff690_inst, reff690_op in H. discriminate H. Qed.

Lemma reff690_not503 : ~ @Equation503 Fin5 reff690_inst.
Proof. unfold Equation503. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff690_inst, reff690_op in H. discriminate H. Qed.

Lemma reff690_not504 : ~ @Equation504 Fin5 reff690_inst.
Proof. unfold Equation504. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff690_inst, reff690_op in H. discriminate H. Qed.

Lemma reff690_not510 : ~ @Equation510 Fin5 reff690_inst.
Proof. unfold Equation510. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff690_inst, reff690_op in H. discriminate H. Qed.

Lemma reff690_not615 : ~ @Equation615 Fin5 reff690_inst.
Proof. unfold Equation615. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff690_inst, reff690_op in H. discriminate H. Qed.

Lemma reff690_not616 : ~ @Equation616 Fin5 reff690_inst.
Proof. unfold Equation616. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff690_inst, reff690_op in H. discriminate H. Qed.

Lemma reff690_not617 : ~ @Equation617 Fin5 reff690_inst.
Proof. unfold Equation617. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff690_inst, reff690_op in H. discriminate H. Qed.

Lemma reff690_not619 : ~ @Equation619 Fin5 reff690_inst.
Proof. unfold Equation619. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff690_inst, reff690_op in H. discriminate H. Qed.

Lemma reff690_not620 : ~ @Equation620 Fin5 reff690_inst.
Proof. unfold Equation620. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff690_inst, reff690_op in H. discriminate H. Qed.

Lemma reff690_not622 : ~ @Equation622 Fin5 reff690_inst.
Proof. unfold Equation622. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff690_inst, reff690_op in H. discriminate H. Qed.

Lemma reff690_not629 : ~ @Equation629 Fin5 reff690_inst.
Proof. unfold Equation629. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff690_inst, reff690_op in H. discriminate H. Qed.

Lemma reff690_not630 : ~ @Equation630 Fin5 reff690_inst.
Proof. unfold Equation630. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff690_inst, reff690_op in H. discriminate H. Qed.

Lemma reff690_not633 : ~ @Equation633 Fin5 reff690_inst.
Proof. unfold Equation633. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff690_inst, reff690_op in H. discriminate H. Qed.

Lemma reff690_not640 : ~ @Equation640 Fin5 reff690_inst.
Proof. unfold Equation640. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff690_inst, reff690_op in H. discriminate H. Qed.

Lemma reff690_not642 : ~ @Equation642 Fin5 reff690_inst.
Proof. unfold Equation642. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff690_inst, reff690_op in H. discriminate H. Qed.

Lemma reff690_not643 : ~ @Equation643 Fin5 reff690_inst.
Proof. unfold Equation643. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff690_inst, reff690_op in H. discriminate H. Qed.

Lemma reff690_not666 : ~ @Equation666 Fin5 reff690_inst.
Proof. unfold Equation666. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff690_inst, reff690_op in H. discriminate H. Qed.

Lemma reff690_not669 : ~ @Equation669 Fin5 reff690_inst.
Proof. unfold Equation669. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff690_inst, reff690_op in H. discriminate H. Qed.

Lemma reff690_not670 : ~ @Equation670 Fin5 reff690_inst.
Proof. unfold Equation670. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff690_inst, reff690_op in H. discriminate H. Qed.

Lemma reff690_not676 : ~ @Equation676 Fin5 reff690_inst.
Proof. unfold Equation676. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff690_inst, reff690_op in H. discriminate H. Qed.

Lemma reff690_not677 : ~ @Equation677 Fin5 reff690_inst.
Proof. unfold Equation677. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff690_inst, reff690_op in H. discriminate H. Qed.

Lemma reff690_not679 : ~ @Equation679 Fin5 reff690_inst.
Proof. unfold Equation679. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff690_inst, reff690_op in H. discriminate H. Qed.

Lemma reff690_not680 : ~ @Equation680 Fin5 reff690_inst.
Proof. unfold Equation680. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff690_inst, reff690_op in H. discriminate H. Qed.

Lemma reff690_not703 : ~ @Equation703 Fin5 reff690_inst.
Proof. unfold Equation703. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff690_inst, reff690_op in H. discriminate H. Qed.

Lemma reff690_not704 : ~ @Equation704 Fin5 reff690_inst.
Proof. unfold Equation704. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff690_inst, reff690_op in H. discriminate H. Qed.

Lemma reff690_not706 : ~ @Equation706 Fin5 reff690_inst.
Proof. unfold Equation706. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff690_inst, reff690_op in H. discriminate H. Qed.

Lemma reff690_not713 : ~ @Equation713 Fin5 reff690_inst.
Proof. unfold Equation713. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff690_inst, reff690_op in H. discriminate H. Qed.

Lemma reff690_not716 : ~ @Equation716 Fin5 reff690_inst.
Proof. unfold Equation716. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff690_inst, reff690_op in H. discriminate H. Qed.

Lemma reff690_not817 : ~ @Equation817 Fin5 reff690_inst.
Proof. unfold Equation817. intro H. specialize (H F5_1). unfold magma_op, reff690_inst, reff690_op in H. discriminate H. Qed.

Lemma reff690_not1021 : ~ @Equation1021 Fin5 reff690_inst.
Proof. unfold Equation1021. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff690_inst, reff690_op in H. discriminate H. Qed.

Lemma reff690_not1022 : ~ @Equation1022 Fin5 reff690_inst.
Proof. unfold Equation1022. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff690_inst, reff690_op in H. discriminate H. Qed.

Lemma reff690_not1025 : ~ @Equation1025 Fin5 reff690_inst.
Proof. unfold Equation1025. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff690_inst, reff690_op in H. discriminate H. Qed.

Lemma reff690_not1028 : ~ @Equation1028 Fin5 reff690_inst.
Proof. unfold Equation1028. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff690_inst, reff690_op in H. discriminate H. Qed.

Lemma reff690_not1029 : ~ @Equation1029 Fin5 reff690_inst.
Proof. unfold Equation1029. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff690_inst, reff690_op in H. discriminate H. Qed.

Lemma reff690_not1035 : ~ @Equation1035 Fin5 reff690_inst.
Proof. unfold Equation1035. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff690_inst, reff690_op in H. discriminate H. Qed.

Lemma reff690_not1036 : ~ @Equation1036 Fin5 reff690_inst.
Proof. unfold Equation1036. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff690_inst, reff690_op in H. discriminate H. Qed.

Lemma reff690_not1038 : ~ @Equation1038 Fin5 reff690_inst.
Proof. unfold Equation1038. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff690_inst, reff690_op in H. discriminate H. Qed.

Lemma reff690_not1039 : ~ @Equation1039 Fin5 reff690_inst.
Proof. unfold Equation1039. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff690_inst, reff690_op in H. discriminate H. Qed.

Lemma reff690_not1045 : ~ @Equation1045 Fin5 reff690_inst.
Proof. unfold Equation1045. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff690_inst, reff690_op in H. discriminate H. Qed.

Lemma reff690_not1046 : ~ @Equation1046 Fin5 reff690_inst.
Proof. unfold Equation1046. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff690_inst, reff690_op in H. discriminate H. Qed.

Lemma reff690_not1049 : ~ @Equation1049 Fin5 reff690_inst.
Proof. unfold Equation1049. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff690_inst, reff690_op in H. discriminate H. Qed.

Lemma reff690_not1072 : ~ @Equation1072 Fin5 reff690_inst.
Proof. unfold Equation1072. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff690_inst, reff690_op in H. discriminate H. Qed.

Lemma reff690_not1073 : ~ @Equation1073 Fin5 reff690_inst.
Proof. unfold Equation1073. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff690_inst, reff690_op in H. discriminate H. Qed.

Lemma reff690_not1075 : ~ @Equation1075 Fin5 reff690_inst.
Proof. unfold Equation1075. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff690_inst, reff690_op in H. discriminate H. Qed.

Lemma reff690_not1076 : ~ @Equation1076 Fin5 reff690_inst.
Proof. unfold Equation1076. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff690_inst, reff690_op in H. discriminate H. Qed.

Lemma reff690_not1082 : ~ @Equation1082 Fin5 reff690_inst.
Proof. unfold Equation1082. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff690_inst, reff690_op in H. discriminate H. Qed.

Lemma reff690_not1083 : ~ @Equation1083 Fin5 reff690_inst.
Proof. unfold Equation1083. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff690_inst, reff690_op in H. discriminate H. Qed.

Lemma reff690_not1085 : ~ @Equation1085 Fin5 reff690_inst.
Proof. unfold Equation1085. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff690_inst, reff690_op in H. discriminate H. Qed.

Lemma reff690_not1086 : ~ @Equation1086 Fin5 reff690_inst.
Proof. unfold Equation1086. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff690_inst, reff690_op in H. discriminate H. Qed.

Lemma reff690_not1110 : ~ @Equation1110 Fin5 reff690_inst.
Proof. unfold Equation1110. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff690_inst, reff690_op in H. discriminate H. Qed.

Lemma reff690_not1112 : ~ @Equation1112 Fin5 reff690_inst.
Proof. unfold Equation1112. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff690_inst, reff690_op in H. discriminate H. Qed.

Lemma reff690_not1119 : ~ @Equation1119 Fin5 reff690_inst.
Proof. unfold Equation1119. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff690_inst, reff690_op in H. discriminate H. Qed.

Lemma reff690_not1122 : ~ @Equation1122 Fin5 reff690_inst.
Proof. unfold Equation1122. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff690_inst, reff690_op in H. discriminate H. Qed.

Lemma reff690_not1224 : ~ @Equation1224 Fin5 reff690_inst.
Proof. unfold Equation1224. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff690_inst, reff690_op in H. discriminate H. Qed.

Lemma reff690_not1225 : ~ @Equation1225 Fin5 reff690_inst.
Proof. unfold Equation1225. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff690_inst, reff690_op in H. discriminate H. Qed.

Lemma reff690_not1226 : ~ @Equation1226 Fin5 reff690_inst.
Proof. unfold Equation1226. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff690_inst, reff690_op in H. discriminate H. Qed.

Lemma reff690_not1228 : ~ @Equation1228 Fin5 reff690_inst.
Proof. unfold Equation1228. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff690_inst, reff690_op in H. discriminate H. Qed.

Lemma reff690_not1231 : ~ @Equation1231 Fin5 reff690_inst.
Proof. unfold Equation1231. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff690_inst, reff690_op in H. discriminate H. Qed.

Lemma reff690_not1232 : ~ @Equation1232 Fin5 reff690_inst.
Proof. unfold Equation1232. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff690_inst, reff690_op in H. discriminate H. Qed.

Lemma reff690_not1238 : ~ @Equation1238 Fin5 reff690_inst.
Proof. unfold Equation1238. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff690_inst, reff690_op in H. discriminate H. Qed.

Lemma reff690_not1241 : ~ @Equation1241 Fin5 reff690_inst.
Proof. unfold Equation1241. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff690_inst, reff690_op in H. discriminate H. Qed.

Lemma reff690_not1242 : ~ @Equation1242 Fin5 reff690_inst.
Proof. unfold Equation1242. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff690_inst, reff690_op in H. discriminate H. Qed.

Lemma reff690_not1248 : ~ @Equation1248 Fin5 reff690_inst.
Proof. unfold Equation1248. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff690_inst, reff690_op in H. discriminate H. Qed.

Lemma reff690_not1249 : ~ @Equation1249 Fin5 reff690_inst.
Proof. unfold Equation1249. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff690_inst, reff690_op in H. discriminate H. Qed.

Lemma reff690_not1252 : ~ @Equation1252 Fin5 reff690_inst.
Proof. unfold Equation1252. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff690_inst, reff690_op in H. discriminate H. Qed.

Lemma reff690_not1275 : ~ @Equation1275 Fin5 reff690_inst.
Proof. unfold Equation1275. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff690_inst, reff690_op in H. discriminate H. Qed.

Lemma reff690_not1276 : ~ @Equation1276 Fin5 reff690_inst.
Proof. unfold Equation1276. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff690_inst, reff690_op in H. discriminate H. Qed.

Lemma reff690_not1279 : ~ @Equation1279 Fin5 reff690_inst.
Proof. unfold Equation1279. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff690_inst, reff690_op in H. discriminate H. Qed.

Lemma reff690_not1285 : ~ @Equation1285 Fin5 reff690_inst.
Proof. unfold Equation1285. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff690_inst, reff690_op in H. discriminate H. Qed.

Lemma reff690_not1286 : ~ @Equation1286 Fin5 reff690_inst.
Proof. unfold Equation1286. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff690_inst, reff690_op in H. discriminate H. Qed.

Lemma reff690_not1288 : ~ @Equation1288 Fin5 reff690_inst.
Proof. unfold Equation1288. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff690_inst, reff690_op in H. discriminate H. Qed.

Lemma reff690_not1312 : ~ @Equation1312 Fin5 reff690_inst.
Proof. unfold Equation1312. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff690_inst, reff690_op in H. discriminate H. Qed.

Lemma reff690_not1313 : ~ @Equation1313 Fin5 reff690_inst.
Proof. unfold Equation1313. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff690_inst, reff690_op in H. discriminate H. Qed.

Lemma reff690_not1315 : ~ @Equation1315 Fin5 reff690_inst.
Proof. unfold Equation1315. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff690_inst, reff690_op in H. discriminate H. Qed.

Lemma reff690_not1322 : ~ @Equation1322 Fin5 reff690_inst.
Proof. unfold Equation1322. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff690_inst, reff690_op in H. discriminate H. Qed.

Lemma reff690_not1323 : ~ @Equation1323 Fin5 reff690_inst.
Proof. unfold Equation1323. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff690_inst, reff690_op in H. discriminate H. Qed.

Lemma reff690_not1325 : ~ @Equation1325 Fin5 reff690_inst.
Proof. unfold Equation1325. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff690_inst, reff690_op in H. discriminate H. Qed.

Lemma reff690_not1426 : ~ @Equation1426 Fin5 reff690_inst.
Proof. unfold Equation1426. intro H. specialize (H F5_1). unfold magma_op, reff690_inst, reff690_op in H. discriminate H. Qed.

Lemma reff690_not1629 : ~ @Equation1629 Fin5 reff690_inst.
Proof. unfold Equation1629. intro H. specialize (H F5_1). unfold magma_op, reff690_inst, reff690_op in H. discriminate H. Qed.

Lemma reff690_not1832 : ~ @Equation1832 Fin5 reff690_inst.
Proof. unfold Equation1832. intro H. specialize (H F5_1). unfold magma_op, reff690_inst, reff690_op in H. discriminate H. Qed.

Lemma reff690_not2035 : ~ @Equation2035 Fin5 reff690_inst.
Proof. unfold Equation2035. intro H. specialize (H F5_1). unfold magma_op, reff690_inst, reff690_op in H. discriminate H. Qed.

Lemma reff690_not2239 : ~ @Equation2239 Fin5 reff690_inst.
Proof. unfold Equation2239. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff690_inst, reff690_op in H. discriminate H. Qed.

Lemma reff690_not2240 : ~ @Equation2240 Fin5 reff690_inst.
Proof. unfold Equation2240. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff690_inst, reff690_op in H. discriminate H. Qed.

Lemma reff690_not2241 : ~ @Equation2241 Fin5 reff690_inst.
Proof. unfold Equation2241. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff690_inst, reff690_op in H. discriminate H. Qed.

Lemma reff690_not2243 : ~ @Equation2243 Fin5 reff690_inst.
Proof. unfold Equation2243. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff690_inst, reff690_op in H. discriminate H. Qed.

Lemma reff690_not2244 : ~ @Equation2244 Fin5 reff690_inst.
Proof. unfold Equation2244. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff690_inst, reff690_op in H. discriminate H. Qed.

Lemma reff690_not2246 : ~ @Equation2246 Fin5 reff690_inst.
Proof. unfold Equation2246. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff690_inst, reff690_op in H. discriminate H. Qed.

Lemma reff690_not2247 : ~ @Equation2247 Fin5 reff690_inst.
Proof. unfold Equation2247. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff690_inst, reff690_op in H. discriminate H. Qed.

Lemma reff690_not2253 : ~ @Equation2253 Fin5 reff690_inst.
Proof. unfold Equation2253. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff690_inst, reff690_op in H. discriminate H. Qed.

Lemma reff690_not2256 : ~ @Equation2256 Fin5 reff690_inst.
Proof. unfold Equation2256. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff690_inst, reff690_op in H. discriminate H. Qed.

Lemma reff690_not2257 : ~ @Equation2257 Fin5 reff690_inst.
Proof. unfold Equation2257. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff690_inst, reff690_op in H. discriminate H. Qed.

Lemma reff690_not2263 : ~ @Equation2263 Fin5 reff690_inst.
Proof. unfold Equation2263. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff690_inst, reff690_op in H. discriminate H. Qed.

Lemma reff690_not2264 : ~ @Equation2264 Fin5 reff690_inst.
Proof. unfold Equation2264. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff690_inst, reff690_op in H. discriminate H. Qed.

Lemma reff690_not2267 : ~ @Equation2267 Fin5 reff690_inst.
Proof. unfold Equation2267. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff690_inst, reff690_op in H. discriminate H. Qed.

Lemma reff690_not2290 : ~ @Equation2290 Fin5 reff690_inst.
Proof. unfold Equation2290. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff690_inst, reff690_op in H. discriminate H. Qed.

Lemma reff690_not2291 : ~ @Equation2291 Fin5 reff690_inst.
Proof. unfold Equation2291. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff690_inst, reff690_op in H. discriminate H. Qed.

Lemma reff690_not2294 : ~ @Equation2294 Fin5 reff690_inst.
Proof. unfold Equation2294. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff690_inst, reff690_op in H. discriminate H. Qed.

Lemma reff690_not2301 : ~ @Equation2301 Fin5 reff690_inst.
Proof. unfold Equation2301. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff690_inst, reff690_op in H. discriminate H. Qed.

Lemma reff690_not2303 : ~ @Equation2303 Fin5 reff690_inst.
Proof. unfold Equation2303. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff690_inst, reff690_op in H. discriminate H. Qed.

Lemma reff690_not2304 : ~ @Equation2304 Fin5 reff690_inst.
Proof. unfold Equation2304. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff690_inst, reff690_op in H. discriminate H. Qed.

Lemma reff690_not2327 : ~ @Equation2327 Fin5 reff690_inst.
Proof. unfold Equation2327. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff690_inst, reff690_op in H. discriminate H. Qed.

Lemma reff690_not2328 : ~ @Equation2328 Fin5 reff690_inst.
Proof. unfold Equation2328. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff690_inst, reff690_op in H. discriminate H. Qed.

Lemma reff690_not2330 : ~ @Equation2330 Fin5 reff690_inst.
Proof. unfold Equation2330. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff690_inst, reff690_op in H. discriminate H. Qed.

Lemma reff690_not2337 : ~ @Equation2337 Fin5 reff690_inst.
Proof. unfold Equation2337. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff690_inst, reff690_op in H. discriminate H. Qed.

Lemma reff690_not2340 : ~ @Equation2340 Fin5 reff690_inst.
Proof. unfold Equation2340. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff690_inst, reff690_op in H. discriminate H. Qed.

Lemma reff690_not2442 : ~ @Equation2442 Fin5 reff690_inst.
Proof. unfold Equation2442. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff690_inst, reff690_op in H. discriminate H. Qed.

Lemma reff690_not2443 : ~ @Equation2443 Fin5 reff690_inst.
Proof. unfold Equation2443. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff690_inst, reff690_op in H. discriminate H. Qed.

Lemma reff690_not2446 : ~ @Equation2446 Fin5 reff690_inst.
Proof. unfold Equation2446. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff690_inst, reff690_op in H. discriminate H. Qed.

Lemma reff690_not2447 : ~ @Equation2447 Fin5 reff690_inst.
Proof. unfold Equation2447. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff690_inst, reff690_op in H. discriminate H. Qed.

Lemma reff690_not2449 : ~ @Equation2449 Fin5 reff690_inst.
Proof. unfold Equation2449. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff690_inst, reff690_op in H. discriminate H. Qed.

Lemma reff690_not2450 : ~ @Equation2450 Fin5 reff690_inst.
Proof. unfold Equation2450. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff690_inst, reff690_op in H. discriminate H. Qed.

Lemma reff690_not2456 : ~ @Equation2456 Fin5 reff690_inst.
Proof. unfold Equation2456. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff690_inst, reff690_op in H. discriminate H. Qed.

Lemma reff690_not2457 : ~ @Equation2457 Fin5 reff690_inst.
Proof. unfold Equation2457. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff690_inst, reff690_op in H. discriminate H. Qed.

Lemma reff690_not2459 : ~ @Equation2459 Fin5 reff690_inst.
Proof. unfold Equation2459. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff690_inst, reff690_op in H. discriminate H. Qed.

Lemma reff690_not2460 : ~ @Equation2460 Fin5 reff690_inst.
Proof. unfold Equation2460. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff690_inst, reff690_op in H. discriminate H. Qed.

Lemma reff690_not2466 : ~ @Equation2466 Fin5 reff690_inst.
Proof. unfold Equation2466. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff690_inst, reff690_op in H. discriminate H. Qed.

Lemma reff690_not2467 : ~ @Equation2467 Fin5 reff690_inst.
Proof. unfold Equation2467. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff690_inst, reff690_op in H. discriminate H. Qed.

Lemma reff690_not2470 : ~ @Equation2470 Fin5 reff690_inst.
Proof. unfold Equation2470. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff690_inst, reff690_op in H. discriminate H. Qed.

Lemma reff690_not2493 : ~ @Equation2493 Fin5 reff690_inst.
Proof. unfold Equation2493. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff690_inst, reff690_op in H. discriminate H. Qed.

Lemma reff690_not2494 : ~ @Equation2494 Fin5 reff690_inst.
Proof. unfold Equation2494. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff690_inst, reff690_op in H. discriminate H. Qed.

Lemma reff690_not2496 : ~ @Equation2496 Fin5 reff690_inst.
Proof. unfold Equation2496. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff690_inst, reff690_op in H. discriminate H. Qed.

Lemma reff690_not2497 : ~ @Equation2497 Fin5 reff690_inst.
Proof. unfold Equation2497. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff690_inst, reff690_op in H. discriminate H. Qed.

Lemma reff690_not2504 : ~ @Equation2504 Fin5 reff690_inst.
Proof. unfold Equation2504. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff690_inst, reff690_op in H. discriminate H. Qed.

Lemma reff690_not2506 : ~ @Equation2506 Fin5 reff690_inst.
Proof. unfold Equation2506. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff690_inst, reff690_op in H. discriminate H. Qed.

Lemma reff690_not2531 : ~ @Equation2531 Fin5 reff690_inst.
Proof. unfold Equation2531. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff690_inst, reff690_op in H. discriminate H. Qed.

Lemma reff690_not2533 : ~ @Equation2533 Fin5 reff690_inst.
Proof. unfold Equation2533. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff690_inst, reff690_op in H. discriminate H. Qed.

Lemma reff690_not2540 : ~ @Equation2540 Fin5 reff690_inst.
Proof. unfold Equation2540. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff690_inst, reff690_op in H. discriminate H. Qed.

Lemma reff690_not2541 : ~ @Equation2541 Fin5 reff690_inst.
Proof. unfold Equation2541. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff690_inst, reff690_op in H. discriminate H. Qed.

Lemma reff690_not2543 : ~ @Equation2543 Fin5 reff690_inst.
Proof. unfold Equation2543. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff690_inst, reff690_op in H. discriminate H. Qed.

Lemma reff690_not2644 : ~ @Equation2644 Fin5 reff690_inst.
Proof. unfold Equation2644. intro H. specialize (H F5_1). unfold magma_op, reff690_inst, reff690_op in H. discriminate H. Qed.

Lemma reff690_not2848 : ~ @Equation2848 Fin5 reff690_inst.
Proof. unfold Equation2848. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff690_inst, reff690_op in H. discriminate H. Qed.

Lemma reff690_not2849 : ~ @Equation2849 Fin5 reff690_inst.
Proof. unfold Equation2849. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff690_inst, reff690_op in H. discriminate H. Qed.

Lemma reff690_not2850 : ~ @Equation2850 Fin5 reff690_inst.
Proof. unfold Equation2850. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff690_inst, reff690_op in H. discriminate H. Qed.

Lemma reff690_not2852 : ~ @Equation2852 Fin5 reff690_inst.
Proof. unfold Equation2852. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff690_inst, reff690_op in H. discriminate H. Qed.

Lemma reff690_not2853 : ~ @Equation2853 Fin5 reff690_inst.
Proof. unfold Equation2853. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff690_inst, reff690_op in H. discriminate H. Qed.

Lemma reff690_not2856 : ~ @Equation2856 Fin5 reff690_inst.
Proof. unfold Equation2856. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff690_inst, reff690_op in H. discriminate H. Qed.

Lemma reff690_not2862 : ~ @Equation2862 Fin5 reff690_inst.
Proof. unfold Equation2862. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff690_inst, reff690_op in H. discriminate H. Qed.

Lemma reff690_not2863 : ~ @Equation2863 Fin5 reff690_inst.
Proof. unfold Equation2863. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff690_inst, reff690_op in H. discriminate H. Qed.

Lemma reff690_not2866 : ~ @Equation2866 Fin5 reff690_inst.
Proof. unfold Equation2866. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff690_inst, reff690_op in H. discriminate H. Qed.

Lemma reff690_not2872 : ~ @Equation2872 Fin5 reff690_inst.
Proof. unfold Equation2872. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff690_inst, reff690_op in H. discriminate H. Qed.

Lemma reff690_not2873 : ~ @Equation2873 Fin5 reff690_inst.
Proof. unfold Equation2873. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff690_inst, reff690_op in H. discriminate H. Qed.

Lemma reff690_not2875 : ~ @Equation2875 Fin5 reff690_inst.
Proof. unfold Equation2875. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff690_inst, reff690_op in H. discriminate H. Qed.

Lemma reff690_not2876 : ~ @Equation2876 Fin5 reff690_inst.
Proof. unfold Equation2876. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff690_inst, reff690_op in H. discriminate H. Qed.

Lemma reff690_not2899 : ~ @Equation2899 Fin5 reff690_inst.
Proof. unfold Equation2899. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff690_inst, reff690_op in H. discriminate H. Qed.

Lemma reff690_not2902 : ~ @Equation2902 Fin5 reff690_inst.
Proof. unfold Equation2902. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff690_inst, reff690_op in H. discriminate H. Qed.

Lemma reff690_not2903 : ~ @Equation2903 Fin5 reff690_inst.
Proof. unfold Equation2903. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff690_inst, reff690_op in H. discriminate H. Qed.

Lemma reff690_not2909 : ~ @Equation2909 Fin5 reff690_inst.
Proof. unfold Equation2909. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff690_inst, reff690_op in H. discriminate H. Qed.

Lemma reff690_not2910 : ~ @Equation2910 Fin5 reff690_inst.
Proof. unfold Equation2910. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff690_inst, reff690_op in H. discriminate H. Qed.

Lemma reff690_not2912 : ~ @Equation2912 Fin5 reff690_inst.
Proof. unfold Equation2912. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff690_inst, reff690_op in H. discriminate H. Qed.

Lemma reff690_not2936 : ~ @Equation2936 Fin5 reff690_inst.
Proof. unfold Equation2936. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff690_inst, reff690_op in H. discriminate H. Qed.

Lemma reff690_not2937 : ~ @Equation2937 Fin5 reff690_inst.
Proof. unfold Equation2937. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff690_inst, reff690_op in H. discriminate H. Qed.

Lemma reff690_not2939 : ~ @Equation2939 Fin5 reff690_inst.
Proof. unfold Equation2939. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff690_inst, reff690_op in H. discriminate H. Qed.

Lemma reff690_not2947 : ~ @Equation2947 Fin5 reff690_inst.
Proof. unfold Equation2947. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff690_inst, reff690_op in H. discriminate H. Qed.

Lemma reff690_not2949 : ~ @Equation2949 Fin5 reff690_inst.
Proof. unfold Equation2949. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff690_inst, reff690_op in H. discriminate H. Qed.

Lemma reff690_not3051 : ~ @Equation3051 Fin5 reff690_inst.
Proof. unfold Equation3051. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff690_inst, reff690_op in H. discriminate H. Qed.

Lemma reff690_not3052 : ~ @Equation3052 Fin5 reff690_inst.
Proof. unfold Equation3052. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff690_inst, reff690_op in H. discriminate H. Qed.

Lemma reff690_not3053 : ~ @Equation3053 Fin5 reff690_inst.
Proof. unfold Equation3053. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff690_inst, reff690_op in H. discriminate H. Qed.

Lemma reff690_not3055 : ~ @Equation3055 Fin5 reff690_inst.
Proof. unfold Equation3055. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff690_inst, reff690_op in H. discriminate H. Qed.

Lemma reff690_not3058 : ~ @Equation3058 Fin5 reff690_inst.
Proof. unfold Equation3058. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff690_inst, reff690_op in H. discriminate H. Qed.

Lemma reff690_not3059 : ~ @Equation3059 Fin5 reff690_inst.
Proof. unfold Equation3059. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff690_inst, reff690_op in H. discriminate H. Qed.

Lemma reff690_not3065 : ~ @Equation3065 Fin5 reff690_inst.
Proof. unfold Equation3065. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff690_inst, reff690_op in H. discriminate H. Qed.

Lemma reff690_not3066 : ~ @Equation3066 Fin5 reff690_inst.
Proof. unfold Equation3066. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff690_inst, reff690_op in H. discriminate H. Qed.

Lemma reff690_not3069 : ~ @Equation3069 Fin5 reff690_inst.
Proof. unfold Equation3069. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff690_inst, reff690_op in H. discriminate H. Qed.

Lemma reff690_not3075 : ~ @Equation3075 Fin5 reff690_inst.
Proof. unfold Equation3075. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff690_inst, reff690_op in H. discriminate H. Qed.

Lemma reff690_not3076 : ~ @Equation3076 Fin5 reff690_inst.
Proof. unfold Equation3076. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff690_inst, reff690_op in H. discriminate H. Qed.

Lemma reff690_not3078 : ~ @Equation3078 Fin5 reff690_inst.
Proof. unfold Equation3078. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff690_inst, reff690_op in H. discriminate H. Qed.

Lemma reff690_not3102 : ~ @Equation3102 Fin5 reff690_inst.
Proof. unfold Equation3102. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff690_inst, reff690_op in H. discriminate H. Qed.

Lemma reff690_not3103 : ~ @Equation3103 Fin5 reff690_inst.
Proof. unfold Equation3103. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff690_inst, reff690_op in H. discriminate H. Qed.

Lemma reff690_not3106 : ~ @Equation3106 Fin5 reff690_inst.
Proof. unfold Equation3106. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff690_inst, reff690_op in H. discriminate H. Qed.

Lemma reff690_not3112 : ~ @Equation3112 Fin5 reff690_inst.
Proof. unfold Equation3112. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff690_inst, reff690_op in H. discriminate H. Qed.

Lemma reff690_not3113 : ~ @Equation3113 Fin5 reff690_inst.
Proof. unfold Equation3113. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff690_inst, reff690_op in H. discriminate H. Qed.

Lemma reff690_not3115 : ~ @Equation3115 Fin5 reff690_inst.
Proof. unfold Equation3115. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff690_inst, reff690_op in H. discriminate H. Qed.

Lemma reff690_not3139 : ~ @Equation3139 Fin5 reff690_inst.
Proof. unfold Equation3139. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff690_inst, reff690_op in H. discriminate H. Qed.

Lemma reff690_not3140 : ~ @Equation3140 Fin5 reff690_inst.
Proof. unfold Equation3140. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff690_inst, reff690_op in H. discriminate H. Qed.

Lemma reff690_not3142 : ~ @Equation3142 Fin5 reff690_inst.
Proof. unfold Equation3142. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff690_inst, reff690_op in H. discriminate H. Qed.

Lemma reff690_not3143 : ~ @Equation3143 Fin5 reff690_inst.
Proof. unfold Equation3143. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff690_inst, reff690_op in H. discriminate H. Qed.

Lemma reff690_not3150 : ~ @Equation3150 Fin5 reff690_inst.
Proof. unfold Equation3150. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff690_inst, reff690_op in H. discriminate H. Qed.

Lemma reff690_not3152 : ~ @Equation3152 Fin5 reff690_inst.
Proof. unfold Equation3152. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff690_inst, reff690_op in H. discriminate H. Qed.

Lemma reff690_not3253 : ~ @Equation3253 Fin5 reff690_inst.
Proof. unfold Equation3253. intro H. specialize (H F5_1). unfold magma_op, reff690_inst, reff690_op in H. discriminate H. Qed.

Lemma reff690_not3456 : ~ @Equation3456 Fin5 reff690_inst.
Proof. unfold Equation3456. intro H. specialize (H F5_1). unfold magma_op, reff690_inst, reff690_op in H. discriminate H. Qed.

Lemma reff690_not3659 : ~ @Equation3659 Fin5 reff690_inst.
Proof. unfold Equation3659. intro H. specialize (H F5_1). unfold magma_op, reff690_inst, reff690_op in H. discriminate H. Qed.

Lemma reff690_not3862 : ~ @Equation3862 Fin5 reff690_inst.
Proof. unfold Equation3862. intro H. specialize (H F5_1). unfold magma_op, reff690_inst, reff690_op in H. discriminate H. Qed.

Lemma reff690_not4065 : ~ @Equation4065 Fin5 reff690_inst.
Proof. unfold Equation4065. intro H. specialize (H F5_1). unfold magma_op, reff690_inst, reff690_op in H. discriminate H. Qed.

Lemma reff690_not4268 : ~ @Equation4268 Fin5 reff690_inst.
Proof. unfold Equation4268. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff690_inst, reff690_op in H. discriminate H. Qed.

Lemma reff690_not4269 : ~ @Equation4269 Fin5 reff690_inst.
Proof. unfold Equation4269. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff690_inst, reff690_op in H. discriminate H. Qed.

Lemma reff690_not4270 : ~ @Equation4270 Fin5 reff690_inst.
Proof. unfold Equation4270. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff690_inst, reff690_op in H. discriminate H. Qed.

Lemma reff690_not4272 : ~ @Equation4272 Fin5 reff690_inst.
Proof. unfold Equation4272. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff690_inst, reff690_op in H. discriminate H. Qed.

Lemma reff690_not4273 : ~ @Equation4273 Fin5 reff690_inst.
Proof. unfold Equation4273. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff690_inst, reff690_op in H. discriminate H. Qed.

Lemma reff690_not4275 : ~ @Equation4275 Fin5 reff690_inst.
Proof. unfold Equation4275. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff690_inst, reff690_op in H. discriminate H. Qed.

Lemma reff690_not4284 : ~ @Equation4284 Fin5 reff690_inst.
Proof. unfold Equation4284. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff690_inst, reff690_op in H. discriminate H. Qed.

Lemma reff690_not4290 : ~ @Equation4290 Fin5 reff690_inst.
Proof. unfold Equation4290. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff690_inst, reff690_op in H. discriminate H. Qed.

Lemma reff690_not4291 : ~ @Equation4291 Fin5 reff690_inst.
Proof. unfold Equation4291. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff690_inst, reff690_op in H. discriminate H. Qed.

Lemma reff690_not4293 : ~ @Equation4293 Fin5 reff690_inst.
Proof. unfold Equation4293. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff690_inst, reff690_op in H. discriminate H. Qed.

Lemma reff690_not4314 : ~ @Equation4314 Fin5 reff690_inst.
Proof. unfold Equation4314. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff690_inst, reff690_op in H. discriminate H. Qed.

Lemma reff690_not4320 : ~ @Equation4320 Fin5 reff690_inst.
Proof. unfold Equation4320. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff690_inst, reff690_op in H. discriminate H. Qed.

Lemma reff690_not4321 : ~ @Equation4321 Fin5 reff690_inst.
Proof. unfold Equation4321. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff690_inst, reff690_op in H. discriminate H. Qed.

Lemma reff690_not4343 : ~ @Equation4343 Fin5 reff690_inst.
Proof. unfold Equation4343. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff690_inst, reff690_op in H. discriminate H. Qed.

Lemma reff690_not4396 : ~ @Equation4396 Fin5 reff690_inst.
Proof. unfold Equation4396. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff690_inst, reff690_op in H. discriminate H. Qed.

Lemma reff690_not4399 : ~ @Equation4399 Fin5 reff690_inst.
Proof. unfold Equation4399. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff690_inst, reff690_op in H. discriminate H. Qed.

Lemma reff690_not4406 : ~ @Equation4406 Fin5 reff690_inst.
Proof. unfold Equation4406. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff690_inst, reff690_op in H. discriminate H. Qed.

Lemma reff690_not4408 : ~ @Equation4408 Fin5 reff690_inst.
Proof. unfold Equation4408. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff690_inst, reff690_op in H. discriminate H. Qed.

Lemma reff690_not4433 : ~ @Equation4433 Fin5 reff690_inst.
Proof. unfold Equation4433. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff690_inst, reff690_op in H. discriminate H. Qed.

Lemma reff690_not4436 : ~ @Equation4436 Fin5 reff690_inst.
Proof. unfold Equation4436. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff690_inst, reff690_op in H. discriminate H. Qed.

Lemma reff690_not4443 : ~ @Equation4443 Fin5 reff690_inst.
Proof. unfold Equation4443. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff690_inst, reff690_op in H. discriminate H. Qed.

Lemma reff690_not4445 : ~ @Equation4445 Fin5 reff690_inst.
Proof. unfold Equation4445. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff690_inst, reff690_op in H. discriminate H. Qed.

Lemma reff690_not4470 : ~ @Equation4470 Fin5 reff690_inst.
Proof. unfold Equation4470. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff690_inst, reff690_op in H. discriminate H. Qed.

Lemma reff690_not4472 : ~ @Equation4472 Fin5 reff690_inst.
Proof. unfold Equation4472. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff690_inst, reff690_op in H. discriminate H. Qed.

Lemma reff690_not4473 : ~ @Equation4473 Fin5 reff690_inst.
Proof. unfold Equation4473. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff690_inst, reff690_op in H. discriminate H. Qed.

Lemma reff690_not4479 : ~ @Equation4479 Fin5 reff690_inst.
Proof. unfold Equation4479. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff690_inst, reff690_op in H. discriminate H. Qed.

Lemma reff690_not4480 : ~ @Equation4480 Fin5 reff690_inst.
Proof. unfold Equation4480. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff690_inst, reff690_op in H. discriminate H. Qed.

Lemma reff690_not4583 : ~ @Equation4583 Fin5 reff690_inst.
Proof. unfold Equation4583. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff690_inst, reff690_op in H. discriminate H. Qed.

Lemma reff690_not4584 : ~ @Equation4584 Fin5 reff690_inst.
Proof. unfold Equation4584. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff690_inst, reff690_op in H. discriminate H. Qed.

Lemma reff690_not4585 : ~ @Equation4585 Fin5 reff690_inst.
Proof. unfold Equation4585. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff690_inst, reff690_op in H. discriminate H. Qed.

Lemma reff690_not4587 : ~ @Equation4587 Fin5 reff690_inst.
Proof. unfold Equation4587. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff690_inst, reff690_op in H. discriminate H. Qed.

Lemma reff690_not4588 : ~ @Equation4588 Fin5 reff690_inst.
Proof. unfold Equation4588. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff690_inst, reff690_op in H. discriminate H. Qed.

Lemma reff690_not4590 : ~ @Equation4590 Fin5 reff690_inst.
Proof. unfold Equation4590. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff690_inst, reff690_op in H. discriminate H. Qed.

Lemma reff690_not4598 : ~ @Equation4598 Fin5 reff690_inst.
Proof. unfold Equation4598. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff690_inst, reff690_op in H. discriminate H. Qed.

Lemma reff690_not4599 : ~ @Equation4599 Fin5 reff690_inst.
Proof. unfold Equation4599. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff690_inst, reff690_op in H. discriminate H. Qed.

Lemma reff690_not4605 : ~ @Equation4605 Fin5 reff690_inst.
Proof. unfold Equation4605. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff690_inst, reff690_op in H. discriminate H. Qed.

Lemma reff690_not4606 : ~ @Equation4606 Fin5 reff690_inst.
Proof. unfold Equation4606. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff690_inst, reff690_op in H. discriminate H. Qed.

Lemma reff690_not4608 : ~ @Equation4608 Fin5 reff690_inst.
Proof. unfold Equation4608. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff690_inst, reff690_op in H. discriminate H. Qed.

Lemma reff690_not4629 : ~ @Equation4629 Fin5 reff690_inst.
Proof. unfold Equation4629. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff690_inst, reff690_op in H. discriminate H. Qed.

Lemma reff690_not4636 : ~ @Equation4636 Fin5 reff690_inst.
Proof. unfold Equation4636. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff690_inst, reff690_op in H. discriminate H. Qed.

Lemma reff690_not4658 : ~ @Equation4658 Fin5 reff690_inst.
Proof. unfold Equation4658. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff690_inst, reff690_op in H. discriminate H. Qed.

(** ---- reff72 (Fin3) ---- *)

Definition reff72_op (x y : Fin3) : Fin3 :=
  match x, y with
  | F3_0, F3_0 => F3_0 | F3_0, F3_1 => F3_2 | F3_0, F3_2 => F3_0
  | F3_1, F3_0 => F3_0 | F3_1, F3_1 => F3_2 | F3_1, F3_2 => F3_0
  | F3_2, F3_0 => F3_0 | F3_2, F3_1 => F3_2 | F3_2, F3_2 => F3_0
  end.

#[local] Instance reff72_inst : Magma Fin3 := {| magma_op := reff72_op |}.

Lemma reff72_sat39 : @Equation39 Fin3 reff72_inst.
Proof. unfold Equation39, magma_op, reff72_inst, reff72_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff72_sat4274 : @Equation4274 Fin3 reff72_inst.
Proof. unfold Equation4274, magma_op, reff72_inst, reff72_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff72_not47 : ~ @Equation47 Fin3 reff72_inst.
Proof. unfold Equation47. intro H. specialize (H F3_1). unfold magma_op, reff72_inst, reff72_op in H. discriminate H. Qed.

Lemma reff72_not99 : ~ @Equation99 Fin3 reff72_inst.
Proof. unfold Equation99. intro H. specialize (H F3_1). unfold magma_op, reff72_inst, reff72_op in H. discriminate H. Qed.

Lemma reff72_not151 : ~ @Equation151 Fin3 reff72_inst.
Proof. unfold Equation151. intro H. specialize (H F3_1). unfold magma_op, reff72_inst, reff72_op in H. discriminate H. Qed.

Lemma reff72_not203 : ~ @Equation203 Fin3 reff72_inst.
Proof. unfold Equation203. intro H. specialize (H F3_1). unfold magma_op, reff72_inst, reff72_op in H. discriminate H. Qed.

Lemma reff72_not255 : ~ @Equation255 Fin3 reff72_inst.
Proof. unfold Equation255. intro H. specialize (H F3_1). unfold magma_op, reff72_inst, reff72_op in H. discriminate H. Qed.

Lemma reff72_not411 : ~ @Equation411 Fin3 reff72_inst.
Proof. unfold Equation411. intro H. specialize (H F3_1). unfold magma_op, reff72_inst, reff72_op in H. discriminate H. Qed.

Lemma reff72_not614 : ~ @Equation614 Fin3 reff72_inst.
Proof. unfold Equation614. intro H. specialize (H F3_1). unfold magma_op, reff72_inst, reff72_op in H. discriminate H. Qed.

Lemma reff72_not817 : ~ @Equation817 Fin3 reff72_inst.
Proof. unfold Equation817. intro H. specialize (H F3_1). unfold magma_op, reff72_inst, reff72_op in H. discriminate H. Qed.

Lemma reff72_not1020 : ~ @Equation1020 Fin3 reff72_inst.
Proof. unfold Equation1020. intro H. specialize (H F3_1). unfold magma_op, reff72_inst, reff72_op in H. discriminate H. Qed.

Lemma reff72_not1223 : ~ @Equation1223 Fin3 reff72_inst.
Proof. unfold Equation1223. intro H. specialize (H F3_1). unfold magma_op, reff72_inst, reff72_op in H. discriminate H. Qed.

Lemma reff72_not1426 : ~ @Equation1426 Fin3 reff72_inst.
Proof. unfold Equation1426. intro H. specialize (H F3_1). unfold magma_op, reff72_inst, reff72_op in H. discriminate H. Qed.

Lemma reff72_not1629 : ~ @Equation1629 Fin3 reff72_inst.
Proof. unfold Equation1629. intro H. specialize (H F3_1). unfold magma_op, reff72_inst, reff72_op in H. discriminate H. Qed.

Lemma reff72_not1832 : ~ @Equation1832 Fin3 reff72_inst.
Proof. unfold Equation1832. intro H. specialize (H F3_1). unfold magma_op, reff72_inst, reff72_op in H. discriminate H. Qed.

Lemma reff72_not2035 : ~ @Equation2035 Fin3 reff72_inst.
Proof. unfold Equation2035. intro H. specialize (H F3_1). unfold magma_op, reff72_inst, reff72_op in H. discriminate H. Qed.

Lemma reff72_not2238 : ~ @Equation2238 Fin3 reff72_inst.
Proof. unfold Equation2238. intro H. specialize (H F3_1). unfold magma_op, reff72_inst, reff72_op in H. discriminate H. Qed.

Lemma reff72_not2441 : ~ @Equation2441 Fin3 reff72_inst.
Proof. unfold Equation2441. intro H. specialize (H F3_1). unfold magma_op, reff72_inst, reff72_op in H. discriminate H. Qed.

Lemma reff72_not2644 : ~ @Equation2644 Fin3 reff72_inst.
Proof. unfold Equation2644. intro H. specialize (H F3_1). unfold magma_op, reff72_inst, reff72_op in H. discriminate H. Qed.

Lemma reff72_not2847 : ~ @Equation2847 Fin3 reff72_inst.
Proof. unfold Equation2847. intro H. specialize (H F3_1). unfold magma_op, reff72_inst, reff72_op in H. discriminate H. Qed.

Lemma reff72_not3050 : ~ @Equation3050 Fin3 reff72_inst.
Proof. unfold Equation3050. intro H. specialize (H F3_1). unfold magma_op, reff72_inst, reff72_op in H. discriminate H. Qed.

Lemma reff72_not3253 : ~ @Equation3253 Fin3 reff72_inst.
Proof. unfold Equation3253. intro H. specialize (H F3_1). unfold magma_op, reff72_inst, reff72_op in H. discriminate H. Qed.

Lemma reff72_not3456 : ~ @Equation3456 Fin3 reff72_inst.
Proof. unfold Equation3456. intro H. specialize (H F3_1). unfold magma_op, reff72_inst, reff72_op in H. discriminate H. Qed.

Lemma reff72_not3659 : ~ @Equation3659 Fin3 reff72_inst.
Proof. unfold Equation3659. intro H. specialize (H F3_1). unfold magma_op, reff72_inst, reff72_op in H. discriminate H. Qed.

Lemma reff72_not3865 : ~ @Equation3865 Fin3 reff72_inst.
Proof. unfold Equation3865. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff72_inst, reff72_op in H. discriminate H. Qed.

Lemma reff72_not3868 : ~ @Equation3868 Fin3 reff72_inst.
Proof. unfold Equation3868. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff72_inst, reff72_op in H. discriminate H. Qed.

Lemma reff72_not3871 : ~ @Equation3871 Fin3 reff72_inst.
Proof. unfold Equation3871. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff72_inst, reff72_op in H. discriminate H. Qed.

Lemma reff72_not3878 : ~ @Equation3878 Fin3 reff72_inst.
Proof. unfold Equation3878. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff72_inst, reff72_op in H. discriminate H. Qed.

Lemma reff72_not3881 : ~ @Equation3881 Fin3 reff72_inst.
Proof. unfold Equation3881. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff72_inst, reff72_op in H. discriminate H. Qed.

Lemma reff72_not3888 : ~ @Equation3888 Fin3 reff72_inst.
Proof. unfold Equation3888. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff72_inst, reff72_op in H. discriminate H. Qed.

Lemma reff72_not3917 : ~ @Equation3917 Fin3 reff72_inst.
Proof. unfold Equation3917. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff72_inst, reff72_op in H. discriminate H. Qed.

Lemma reff72_not3927 : ~ @Equation3927 Fin3 reff72_inst.
Proof. unfold Equation3927. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff72_inst, reff72_op in H. discriminate H. Qed.

Lemma reff72_not3951 : ~ @Equation3951 Fin3 reff72_inst.
Proof. unfold Equation3951. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff72_inst, reff72_op in H. discriminate H. Qed.

Lemma reff72_not3954 : ~ @Equation3954 Fin3 reff72_inst.
Proof. unfold Equation3954. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff72_inst, reff72_op in H. discriminate H. Qed.

Lemma reff72_not3961 : ~ @Equation3961 Fin3 reff72_inst.
Proof. unfold Equation3961. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff72_inst, reff72_op in H. discriminate H. Qed.

Lemma reff72_not3964 : ~ @Equation3964 Fin3 reff72_inst.
Proof. unfold Equation3964. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff72_inst, reff72_op in H. discriminate H. Qed.

Lemma reff72_not4066 : ~ @Equation4066 Fin3 reff72_inst.
Proof. unfold Equation4066. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff72_inst, reff72_op in H. discriminate H. Qed.

Lemma reff72_not4068 : ~ @Equation4068 Fin3 reff72_inst.
Proof. unfold Equation4068. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff72_inst, reff72_op in H. discriminate H. Qed.

Lemma reff72_not4071 : ~ @Equation4071 Fin3 reff72_inst.
Proof. unfold Equation4071. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff72_inst, reff72_op in H. discriminate H. Qed.

Lemma reff72_not4074 : ~ @Equation4074 Fin3 reff72_inst.
Proof. unfold Equation4074. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff72_inst, reff72_op in H. discriminate H. Qed.

Lemma reff72_not4084 : ~ @Equation4084 Fin3 reff72_inst.
Proof. unfold Equation4084. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff72_inst, reff72_op in H. discriminate H. Qed.

Lemma reff72_not4091 : ~ @Equation4091 Fin3 reff72_inst.
Proof. unfold Equation4091. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff72_inst, reff72_op in H. discriminate H. Qed.

Lemma reff72_not4120 : ~ @Equation4120 Fin3 reff72_inst.
Proof. unfold Equation4120. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff72_inst, reff72_op in H. discriminate H. Qed.

Lemma reff72_not4127 : ~ @Equation4127 Fin3 reff72_inst.
Proof. unfold Equation4127. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff72_inst, reff72_op in H. discriminate H. Qed.

Lemma reff72_not4130 : ~ @Equation4130 Fin3 reff72_inst.
Proof. unfold Equation4130. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff72_inst, reff72_op in H. discriminate H. Qed.

Lemma reff72_not4157 : ~ @Equation4157 Fin3 reff72_inst.
Proof. unfold Equation4157. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff72_inst, reff72_op in H. discriminate H. Qed.

Lemma reff72_not4164 : ~ @Equation4164 Fin3 reff72_inst.
Proof. unfold Equation4164. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff72_inst, reff72_op in H. discriminate H. Qed.

Lemma reff72_not4167 : ~ @Equation4167 Fin3 reff72_inst.
Proof. unfold Equation4167. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff72_inst, reff72_op in H. discriminate H. Qed.

Lemma reff72_not4380 : ~ @Equation4380 Fin3 reff72_inst.
Proof. unfold Equation4380. intro H. specialize (H F3_1). unfold magma_op, reff72_inst, reff72_op in H. discriminate H. Qed.

Lemma reff72_not4583 : ~ @Equation4583 Fin3 reff72_inst.
Proof. unfold Equation4583. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff72_inst, reff72_op in H. discriminate H. Qed.

Lemma reff72_not4585 : ~ @Equation4585 Fin3 reff72_inst.
Proof. unfold Equation4585. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff72_inst, reff72_op in H. discriminate H. Qed.

Lemma reff72_not4588 : ~ @Equation4588 Fin3 reff72_inst.
Proof. unfold Equation4588. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff72_inst, reff72_op in H. discriminate H. Qed.

Lemma reff72_not4591 : ~ @Equation4591 Fin3 reff72_inst.
Proof. unfold Equation4591. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff72_inst, reff72_op in H. discriminate H. Qed.

Lemma reff72_not4598 : ~ @Equation4598 Fin3 reff72_inst.
Proof. unfold Equation4598. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff72_inst, reff72_op in H. discriminate H. Qed.

Lemma reff72_not4605 : ~ @Equation4605 Fin3 reff72_inst.
Proof. unfold Equation4605. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff72_inst, reff72_op in H. discriminate H. Qed.

Lemma reff72_not4608 : ~ @Equation4608 Fin3 reff72_inst.
Proof. unfold Equation4608. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff72_inst, reff72_op in H. discriminate H. Qed.

Lemma reff72_not4629 : ~ @Equation4629 Fin3 reff72_inst.
Proof. unfold Equation4629. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff72_inst, reff72_op in H. discriminate H. Qed.

Lemma reff72_not4636 : ~ @Equation4636 Fin3 reff72_inst.
Proof. unfold Equation4636. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff72_inst, reff72_op in H. discriminate H. Qed.

Lemma reff72_not4658 : ~ @Equation4658 Fin3 reff72_inst.
Proof. unfold Equation4658. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff72_inst, reff72_op in H. discriminate H. Qed.

(** ---- reff74 (Fin3) ---- *)

Definition reff74_op (x y : Fin3) : Fin3 :=
  match x, y with
  | F3_0, F3_0 => F3_0 | F3_0, F3_1 => F3_1 | F3_0, F3_2 => F3_0
  | F3_1, F3_0 => F3_0 | F3_1, F3_1 => F3_1 | F3_1, F3_2 => F3_0
  | F3_2, F3_0 => F3_2 | F3_2, F3_1 => F3_0 | F3_2, F3_2 => F3_2
  end.

#[local] Instance reff74_inst : Magma Fin3 := {| magma_op := reff74_op |}.

Lemma reff74_sat3 : @Equation3 Fin3 reff74_inst.
Proof. unfold Equation3, magma_op, reff74_inst, reff74_op. intros x. destruct x; reflexivity. Qed.

Lemma reff74_sat101 : @Equation101 Fin3 reff74_inst.
Proof. unfold Equation101, magma_op, reff74_inst, reff74_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff74_sat104 : @Equation104 Fin3 reff74_inst.
Proof. unfold Equation104, magma_op, reff74_inst, reff74_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff74_sat205 : @Equation205 Fin3 reff74_inst.
Proof. unfold Equation205, magma_op, reff74_inst, reff74_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff74_sat208 : @Equation208 Fin3 reff74_inst.
Proof. unfold Equation208, magma_op, reff74_inst, reff74_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff74_sat616 : @Equation616 Fin3 reff74_inst.
Proof. unfold Equation616, magma_op, reff74_inst, reff74_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff74_sat619 : @Equation619 Fin3 reff74_inst.
Proof. unfold Equation619, magma_op, reff74_inst, reff74_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff74_sat822 : @Equation822 Fin3 reff74_inst.
Proof. unfold Equation822, magma_op, reff74_inst, reff74_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff74_sat832 : @Equation832 Fin3 reff74_inst.
Proof. unfold Equation832, magma_op, reff74_inst, reff74_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff74_sat1035 : @Equation1035 Fin3 reff74_inst.
Proof. unfold Equation1035, magma_op, reff74_inst, reff74_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff74_sat1234 : @Equation1234 Fin3 reff74_inst.
Proof. unfold Equation1234, magma_op, reff74_inst, reff74_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff74_sat1244 : @Equation1244 Fin3 reff74_inst.
Proof. unfold Equation1244, magma_op, reff74_inst, reff74_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff74_sat1631 : @Equation1631 Fin3 reff74_inst.
Proof. unfold Equation1631, magma_op, reff74_inst, reff74_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff74_sat1634 : @Equation1634 Fin3 reff74_inst.
Proof. unfold Equation1634, magma_op, reff74_inst, reff74_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff74_sat1837 : @Equation1837 Fin3 reff74_inst.
Proof. unfold Equation1837, magma_op, reff74_inst, reff74_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff74_sat1847 : @Equation1847 Fin3 reff74_inst.
Proof. unfold Equation1847, magma_op, reff74_inst, reff74_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff74_sat2259 : @Equation2259 Fin3 reff74_inst.
Proof. unfold Equation2259, magma_op, reff74_inst, reff74_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff74_sat2273 : @Equation2273 Fin3 reff74_inst.
Proof. unfold Equation2273, magma_op, reff74_inst, reff74_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff74_sat2443 : @Equation2443 Fin3 reff74_inst.
Proof. unfold Equation2443, magma_op, reff74_inst, reff74_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff74_sat2646 : @Equation2646 Fin3 reff74_inst.
Proof. unfold Equation2646, magma_op, reff74_inst, reff74_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff74_sat2649 : @Equation2649 Fin3 reff74_inst.
Proof. unfold Equation2649, magma_op, reff74_inst, reff74_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff74_sat2852 : @Equation2852 Fin3 reff74_inst.
Proof. unfold Equation2852, magma_op, reff74_inst, reff74_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff74_sat2862 : @Equation2862 Fin3 reff74_inst.
Proof. unfold Equation2862, magma_op, reff74_inst, reff74_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff74_sat3525 : @Equation3525 Fin3 reff74_inst.
Proof. unfold Equation3525, magma_op, reff74_inst, reff74_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff74_sat3533 : @Equation3533 Fin3 reff74_inst.
Proof. unfold Equation3533, magma_op, reff74_inst, reff74_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff74_sat3921 : @Equation3921 Fin3 reff74_inst.
Proof. unfold Equation3921, magma_op, reff74_inst, reff74_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff74_sat3935 : @Equation3935 Fin3 reff74_inst.
Proof. unfold Equation3935, magma_op, reff74_inst, reff74_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff74_not50 : ~ @Equation50 Fin3 reff74_inst.
Proof. unfold Equation50. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff74_inst, reff74_op in H. discriminate H. Qed.

Lemma reff74_not53 : ~ @Equation53 Fin3 reff74_inst.
Proof. unfold Equation53. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff74_inst, reff74_op in H. discriminate H. Qed.

Lemma reff74_not55 : ~ @Equation55 Fin3 reff74_inst.
Proof. unfold Equation55. intro H. specialize (H F3_1 F3_2). unfold magma_op, reff74_inst, reff74_op in H. discriminate H. Qed.

Lemma reff74_not56 : ~ @Equation56 Fin3 reff74_inst.
Proof. unfold Equation56. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff74_inst, reff74_op in H. discriminate H. Qed.

Lemma reff74_not63 : ~ @Equation63 Fin3 reff74_inst.
Proof. unfold Equation63. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff74_inst, reff74_op in H. discriminate H. Qed.

Lemma reff74_not65 : ~ @Equation65 Fin3 reff74_inst.
Proof. unfold Equation65. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff74_inst, reff74_op in H. discriminate H. Qed.

Lemma reff74_not66 : ~ @Equation66 Fin3 reff74_inst.
Proof. unfold Equation66. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff74_inst, reff74_op in H. discriminate H. Qed.

Lemma reff74_not72 : ~ @Equation72 Fin3 reff74_inst.
Proof. unfold Equation72. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff74_inst, reff74_op in H. discriminate H. Qed.

Lemma reff74_not73 : ~ @Equation73 Fin3 reff74_inst.
Proof. unfold Equation73. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff74_inst, reff74_op in H. discriminate H. Qed.

Lemma reff74_not75 : ~ @Equation75 Fin3 reff74_inst.
Proof. unfold Equation75. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff74_inst, reff74_op in H. discriminate H. Qed.

Lemma reff74_not102 : ~ @Equation102 Fin3 reff74_inst.
Proof. unfold Equation102. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff74_inst, reff74_op in H. discriminate H. Qed.

Lemma reff74_not105 : ~ @Equation105 Fin3 reff74_inst.
Proof. unfold Equation105. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff74_inst, reff74_op in H. discriminate H. Qed.

Lemma reff74_not107 : ~ @Equation107 Fin3 reff74_inst.
Proof. unfold Equation107. intro H. specialize (H F3_1 F3_2). unfold magma_op, reff74_inst, reff74_op in H. discriminate H. Qed.

Lemma reff74_not108 : ~ @Equation108 Fin3 reff74_inst.
Proof. unfold Equation108. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff74_inst, reff74_op in H. discriminate H. Qed.

Lemma reff74_not115 : ~ @Equation115 Fin3 reff74_inst.
Proof. unfold Equation115. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff74_inst, reff74_op in H. discriminate H. Qed.

Lemma reff74_not117 : ~ @Equation117 Fin3 reff74_inst.
Proof. unfold Equation117. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff74_inst, reff74_op in H. discriminate H. Qed.

Lemma reff74_not118 : ~ @Equation118 Fin3 reff74_inst.
Proof. unfold Equation118. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff74_inst, reff74_op in H. discriminate H. Qed.

Lemma reff74_not124 : ~ @Equation124 Fin3 reff74_inst.
Proof. unfold Equation124. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff74_inst, reff74_op in H. discriminate H. Qed.

Lemma reff74_not125 : ~ @Equation125 Fin3 reff74_inst.
Proof. unfold Equation125. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff74_inst, reff74_op in H. discriminate H. Qed.

Lemma reff74_not127 : ~ @Equation127 Fin3 reff74_inst.
Proof. unfold Equation127. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff74_inst, reff74_op in H. discriminate H. Qed.

Lemma reff74_not154 : ~ @Equation154 Fin3 reff74_inst.
Proof. unfold Equation154. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff74_inst, reff74_op in H. discriminate H. Qed.

Lemma reff74_not157 : ~ @Equation157 Fin3 reff74_inst.
Proof. unfold Equation157. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff74_inst, reff74_op in H. discriminate H. Qed.

Lemma reff74_not159 : ~ @Equation159 Fin3 reff74_inst.
Proof. unfold Equation159. intro H. specialize (H F3_1 F3_2). unfold magma_op, reff74_inst, reff74_op in H. discriminate H. Qed.

Lemma reff74_not160 : ~ @Equation160 Fin3 reff74_inst.
Proof. unfold Equation160. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff74_inst, reff74_op in H. discriminate H. Qed.

Lemma reff74_not167 : ~ @Equation167 Fin3 reff74_inst.
Proof. unfold Equation167. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff74_inst, reff74_op in H. discriminate H. Qed.

Lemma reff74_not169 : ~ @Equation169 Fin3 reff74_inst.
Proof. unfold Equation169. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff74_inst, reff74_op in H. discriminate H. Qed.

Lemma reff74_not170 : ~ @Equation170 Fin3 reff74_inst.
Proof. unfold Equation170. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff74_inst, reff74_op in H. discriminate H. Qed.

Lemma reff74_not176 : ~ @Equation176 Fin3 reff74_inst.
Proof. unfold Equation176. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff74_inst, reff74_op in H. discriminate H. Qed.

Lemma reff74_not177 : ~ @Equation177 Fin3 reff74_inst.
Proof. unfold Equation177. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff74_inst, reff74_op in H. discriminate H. Qed.

Lemma reff74_not179 : ~ @Equation179 Fin3 reff74_inst.
Proof. unfold Equation179. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff74_inst, reff74_op in H. discriminate H. Qed.

Lemma reff74_not206 : ~ @Equation206 Fin3 reff74_inst.
Proof. unfold Equation206. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff74_inst, reff74_op in H. discriminate H. Qed.

Lemma reff74_not209 : ~ @Equation209 Fin3 reff74_inst.
Proof. unfold Equation209. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff74_inst, reff74_op in H. discriminate H. Qed.

Lemma reff74_not211 : ~ @Equation211 Fin3 reff74_inst.
Proof. unfold Equation211. intro H. specialize (H F3_2 F3_1). unfold magma_op, reff74_inst, reff74_op in H. discriminate H. Qed.

Lemma reff74_not212 : ~ @Equation212 Fin3 reff74_inst.
Proof. unfold Equation212. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff74_inst, reff74_op in H. discriminate H. Qed.

Lemma reff74_not219 : ~ @Equation219 Fin3 reff74_inst.
Proof. unfold Equation219. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff74_inst, reff74_op in H. discriminate H. Qed.

Lemma reff74_not221 : ~ @Equation221 Fin3 reff74_inst.
Proof. unfold Equation221. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff74_inst, reff74_op in H. discriminate H. Qed.

Lemma reff74_not222 : ~ @Equation222 Fin3 reff74_inst.
Proof. unfold Equation222. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff74_inst, reff74_op in H. discriminate H. Qed.

Lemma reff74_not228 : ~ @Equation228 Fin3 reff74_inst.
Proof. unfold Equation228. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff74_inst, reff74_op in H. discriminate H. Qed.

Lemma reff74_not229 : ~ @Equation229 Fin3 reff74_inst.
Proof. unfold Equation229. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff74_inst, reff74_op in H. discriminate H. Qed.

Lemma reff74_not231 : ~ @Equation231 Fin3 reff74_inst.
Proof. unfold Equation231. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff74_inst, reff74_op in H. discriminate H. Qed.

Lemma reff74_not258 : ~ @Equation258 Fin3 reff74_inst.
Proof. unfold Equation258. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff74_inst, reff74_op in H. discriminate H. Qed.

Lemma reff74_not261 : ~ @Equation261 Fin3 reff74_inst.
Proof. unfold Equation261. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff74_inst, reff74_op in H. discriminate H. Qed.

Lemma reff74_not263 : ~ @Equation263 Fin3 reff74_inst.
Proof. unfold Equation263. intro H. specialize (H F3_2 F3_1). unfold magma_op, reff74_inst, reff74_op in H. discriminate H. Qed.

Lemma reff74_not264 : ~ @Equation264 Fin3 reff74_inst.
Proof. unfold Equation264. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff74_inst, reff74_op in H. discriminate H. Qed.

Lemma reff74_not271 : ~ @Equation271 Fin3 reff74_inst.
Proof. unfold Equation271. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff74_inst, reff74_op in H. discriminate H. Qed.

Lemma reff74_not273 : ~ @Equation273 Fin3 reff74_inst.
Proof. unfold Equation273. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff74_inst, reff74_op in H. discriminate H. Qed.

Lemma reff74_not274 : ~ @Equation274 Fin3 reff74_inst.
Proof. unfold Equation274. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff74_inst, reff74_op in H. discriminate H. Qed.

Lemma reff74_not280 : ~ @Equation280 Fin3 reff74_inst.
Proof. unfold Equation280. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff74_inst, reff74_op in H. discriminate H. Qed.

Lemma reff74_not281 : ~ @Equation281 Fin3 reff74_inst.
Proof. unfold Equation281. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff74_inst, reff74_op in H. discriminate H. Qed.

Lemma reff74_not283 : ~ @Equation283 Fin3 reff74_inst.
Proof. unfold Equation283. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff74_inst, reff74_op in H. discriminate H. Qed.

Lemma reff74_not412 : ~ @Equation412 Fin3 reff74_inst.
Proof. unfold Equation412. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff74_inst, reff74_op in H. discriminate H. Qed.

Lemma reff74_not413 : ~ @Equation413 Fin3 reff74_inst.
Proof. unfold Equation413. intro H. specialize (H F3_1 F3_2). unfold magma_op, reff74_inst, reff74_op in H. discriminate H. Qed.

Lemma reff74_not414 : ~ @Equation414 Fin3 reff74_inst.
Proof. unfold Equation414. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff74_inst, reff74_op in H. discriminate H. Qed.

Lemma reff74_not416 : ~ @Equation416 Fin3 reff74_inst.
Proof. unfold Equation416. intro H. specialize (H F3_1 F3_2). unfold magma_op, reff74_inst, reff74_op in H. discriminate H. Qed.

Lemma reff74_not417 : ~ @Equation417 Fin3 reff74_inst.
Proof. unfold Equation417. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff74_inst, reff74_op in H. discriminate H. Qed.

Lemma reff74_not419 : ~ @Equation419 Fin3 reff74_inst.
Proof. unfold Equation419. intro H. specialize (H F3_1 F3_2). unfold magma_op, reff74_inst, reff74_op in H. discriminate H. Qed.

Lemma reff74_not420 : ~ @Equation420 Fin3 reff74_inst.
Proof. unfold Equation420. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff74_inst, reff74_op in H. discriminate H. Qed.

Lemma reff74_not426 : ~ @Equation426 Fin3 reff74_inst.
Proof. unfold Equation426. intro H. specialize (H F3_1 F3_2). unfold magma_op, reff74_inst, reff74_op in H. discriminate H. Qed.

Lemma reff74_not427 : ~ @Equation427 Fin3 reff74_inst.
Proof. unfold Equation427. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff74_inst, reff74_op in H. discriminate H. Qed.

Lemma reff74_not429 : ~ @Equation429 Fin3 reff74_inst.
Proof. unfold Equation429. intro H. specialize (H F3_1 F3_2). unfold magma_op, reff74_inst, reff74_op in H. discriminate H. Qed.

Lemma reff74_not430 : ~ @Equation430 Fin3 reff74_inst.
Proof. unfold Equation430. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff74_inst, reff74_op in H. discriminate H. Qed.

Lemma reff74_not436 : ~ @Equation436 Fin3 reff74_inst.
Proof. unfold Equation436. intro H. specialize (H F3_1 F3_2). unfold magma_op, reff74_inst, reff74_op in H. discriminate H. Qed.

Lemma reff74_not437 : ~ @Equation437 Fin3 reff74_inst.
Proof. unfold Equation437. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff74_inst, reff74_op in H. discriminate H. Qed.

Lemma reff74_not439 : ~ @Equation439 Fin3 reff74_inst.
Proof. unfold Equation439. intro H. specialize (H F3_1 F3_2). unfold magma_op, reff74_inst, reff74_op in H. discriminate H. Qed.

Lemma reff74_not440 : ~ @Equation440 Fin3 reff74_inst.
Proof. unfold Equation440. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff74_inst, reff74_op in H. discriminate H. Qed.

Lemma reff74_not463 : ~ @Equation463 Fin3 reff74_inst.
Proof. unfold Equation463. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff74_inst, reff74_op in H. discriminate H. Qed.

Lemma reff74_not464 : ~ @Equation464 Fin3 reff74_inst.
Proof. unfold Equation464. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff74_inst, reff74_op in H. discriminate H. Qed.

Lemma reff74_not466 : ~ @Equation466 Fin3 reff74_inst.
Proof. unfold Equation466. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff74_inst, reff74_op in H. discriminate H. Qed.

Lemma reff74_not467 : ~ @Equation467 Fin3 reff74_inst.
Proof. unfold Equation467. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff74_inst, reff74_op in H. discriminate H. Qed.

Lemma reff74_not473 : ~ @Equation473 Fin3 reff74_inst.
Proof. unfold Equation473. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff74_inst, reff74_op in H. discriminate H. Qed.

Lemma reff74_not474 : ~ @Equation474 Fin3 reff74_inst.
Proof. unfold Equation474. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff74_inst, reff74_op in H. discriminate H. Qed.

Lemma reff74_not476 : ~ @Equation476 Fin3 reff74_inst.
Proof. unfold Equation476. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff74_inst, reff74_op in H. discriminate H. Qed.

Lemma reff74_not477 : ~ @Equation477 Fin3 reff74_inst.
Proof. unfold Equation477. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff74_inst, reff74_op in H. discriminate H. Qed.

Lemma reff74_not500 : ~ @Equation500 Fin3 reff74_inst.
Proof. unfold Equation500. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff74_inst, reff74_op in H. discriminate H. Qed.

Lemma reff74_not501 : ~ @Equation501 Fin3 reff74_inst.
Proof. unfold Equation501. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff74_inst, reff74_op in H. discriminate H. Qed.

Lemma reff74_not503 : ~ @Equation503 Fin3 reff74_inst.
Proof. unfold Equation503. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff74_inst, reff74_op in H. discriminate H. Qed.

Lemma reff74_not504 : ~ @Equation504 Fin3 reff74_inst.
Proof. unfold Equation504. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff74_inst, reff74_op in H. discriminate H. Qed.

Lemma reff74_not510 : ~ @Equation510 Fin3 reff74_inst.
Proof. unfold Equation510. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff74_inst, reff74_op in H. discriminate H. Qed.

Lemma reff74_not511 : ~ @Equation511 Fin3 reff74_inst.
Proof. unfold Equation511. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff74_inst, reff74_op in H. discriminate H. Qed.

Lemma reff74_not513 : ~ @Equation513 Fin3 reff74_inst.
Proof. unfold Equation513. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff74_inst, reff74_op in H. discriminate H. Qed.

Lemma reff74_not615 : ~ @Equation615 Fin3 reff74_inst.
Proof. unfold Equation615. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff74_inst, reff74_op in H. discriminate H. Qed.

Lemma reff74_not617 : ~ @Equation617 Fin3 reff74_inst.
Proof. unfold Equation617. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff74_inst, reff74_op in H. discriminate H. Qed.

Lemma reff74_not620 : ~ @Equation620 Fin3 reff74_inst.
Proof. unfold Equation620. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff74_inst, reff74_op in H. discriminate H. Qed.

Lemma reff74_not622 : ~ @Equation622 Fin3 reff74_inst.
Proof. unfold Equation622. intro H. specialize (H F3_1 F3_2). unfold magma_op, reff74_inst, reff74_op in H. discriminate H. Qed.

Lemma reff74_not623 : ~ @Equation623 Fin3 reff74_inst.
Proof. unfold Equation623. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff74_inst, reff74_op in H. discriminate H. Qed.

Lemma reff74_not629 : ~ @Equation629 Fin3 reff74_inst.
Proof. unfold Equation629. intro H. specialize (H F3_1 F3_2). unfold magma_op, reff74_inst, reff74_op in H. discriminate H. Qed.

Lemma reff74_not630 : ~ @Equation630 Fin3 reff74_inst.
Proof. unfold Equation630. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff74_inst, reff74_op in H. discriminate H. Qed.

Lemma reff74_not632 : ~ @Equation632 Fin3 reff74_inst.
Proof. unfold Equation632. intro H. specialize (H F3_1 F3_2). unfold magma_op, reff74_inst, reff74_op in H. discriminate H. Qed.

Lemma reff74_not633 : ~ @Equation633 Fin3 reff74_inst.
Proof. unfold Equation633. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff74_inst, reff74_op in H. discriminate H. Qed.

Lemma reff74_not639 : ~ @Equation639 Fin3 reff74_inst.
Proof. unfold Equation639. intro H. specialize (H F3_1 F3_2). unfold magma_op, reff74_inst, reff74_op in H. discriminate H. Qed.

Lemma reff74_not640 : ~ @Equation640 Fin3 reff74_inst.
Proof. unfold Equation640. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff74_inst, reff74_op in H. discriminate H. Qed.

Lemma reff74_not642 : ~ @Equation642 Fin3 reff74_inst.
Proof. unfold Equation642. intro H. specialize (H F3_1 F3_2). unfold magma_op, reff74_inst, reff74_op in H. discriminate H. Qed.

Lemma reff74_not643 : ~ @Equation643 Fin3 reff74_inst.
Proof. unfold Equation643. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff74_inst, reff74_op in H. discriminate H. Qed.

Lemma reff74_not666 : ~ @Equation666 Fin3 reff74_inst.
Proof. unfold Equation666. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff74_inst, reff74_op in H. discriminate H. Qed.

Lemma reff74_not667 : ~ @Equation667 Fin3 reff74_inst.
Proof. unfold Equation667. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff74_inst, reff74_op in H. discriminate H. Qed.

Lemma reff74_not669 : ~ @Equation669 Fin3 reff74_inst.
Proof. unfold Equation669. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff74_inst, reff74_op in H. discriminate H. Qed.

Lemma reff74_not670 : ~ @Equation670 Fin3 reff74_inst.
Proof. unfold Equation670. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff74_inst, reff74_op in H. discriminate H. Qed.

Lemma reff74_not676 : ~ @Equation676 Fin3 reff74_inst.
Proof. unfold Equation676. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff74_inst, reff74_op in H. discriminate H. Qed.

Lemma reff74_not677 : ~ @Equation677 Fin3 reff74_inst.
Proof. unfold Equation677. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff74_inst, reff74_op in H. discriminate H. Qed.

Lemma reff74_not679 : ~ @Equation679 Fin3 reff74_inst.
Proof. unfold Equation679. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff74_inst, reff74_op in H. discriminate H. Qed.

Lemma reff74_not680 : ~ @Equation680 Fin3 reff74_inst.
Proof. unfold Equation680. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff74_inst, reff74_op in H. discriminate H. Qed.

Lemma reff74_not703 : ~ @Equation703 Fin3 reff74_inst.
Proof. unfold Equation703. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff74_inst, reff74_op in H. discriminate H. Qed.

Lemma reff74_not704 : ~ @Equation704 Fin3 reff74_inst.
Proof. unfold Equation704. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff74_inst, reff74_op in H. discriminate H. Qed.

Lemma reff74_not706 : ~ @Equation706 Fin3 reff74_inst.
Proof. unfold Equation706. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff74_inst, reff74_op in H. discriminate H. Qed.

Lemma reff74_not707 : ~ @Equation707 Fin3 reff74_inst.
Proof. unfold Equation707. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff74_inst, reff74_op in H. discriminate H. Qed.

Lemma reff74_not713 : ~ @Equation713 Fin3 reff74_inst.
Proof. unfold Equation713. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff74_inst, reff74_op in H. discriminate H. Qed.

Lemma reff74_not714 : ~ @Equation714 Fin3 reff74_inst.
Proof. unfold Equation714. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff74_inst, reff74_op in H. discriminate H. Qed.

Lemma reff74_not716 : ~ @Equation716 Fin3 reff74_inst.
Proof. unfold Equation716. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff74_inst, reff74_op in H. discriminate H. Qed.

Lemma reff74_not818 : ~ @Equation818 Fin3 reff74_inst.
Proof. unfold Equation818. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff74_inst, reff74_op in H. discriminate H. Qed.

Lemma reff74_not819 : ~ @Equation819 Fin3 reff74_inst.
Proof. unfold Equation819. intro H. specialize (H F3_1 F3_2). unfold magma_op, reff74_inst, reff74_op in H. discriminate H. Qed.

Lemma reff74_not820 : ~ @Equation820 Fin3 reff74_inst.
Proof. unfold Equation820. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff74_inst, reff74_op in H. discriminate H. Qed.

Lemma reff74_not823 : ~ @Equation823 Fin3 reff74_inst.
Proof. unfold Equation823. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff74_inst, reff74_op in H. discriminate H. Qed.

Lemma reff74_not825 : ~ @Equation825 Fin3 reff74_inst.
Proof. unfold Equation825. intro H. specialize (H F3_1 F3_2). unfold magma_op, reff74_inst, reff74_op in H. discriminate H. Qed.

Lemma reff74_not826 : ~ @Equation826 Fin3 reff74_inst.
Proof. unfold Equation826. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff74_inst, reff74_op in H. discriminate H. Qed.

Lemma reff74_not833 : ~ @Equation833 Fin3 reff74_inst.
Proof. unfold Equation833. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff74_inst, reff74_op in H. discriminate H. Qed.

Lemma reff74_not835 : ~ @Equation835 Fin3 reff74_inst.
Proof. unfold Equation835. intro H. specialize (H F3_1 F3_2). unfold magma_op, reff74_inst, reff74_op in H. discriminate H. Qed.

Lemma reff74_not836 : ~ @Equation836 Fin3 reff74_inst.
Proof. unfold Equation836. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff74_inst, reff74_op in H. discriminate H. Qed.

Lemma reff74_not842 : ~ @Equation842 Fin3 reff74_inst.
Proof. unfold Equation842. intro H. specialize (H F3_1 F3_2). unfold magma_op, reff74_inst, reff74_op in H. discriminate H. Qed.

Lemma reff74_not843 : ~ @Equation843 Fin3 reff74_inst.
Proof. unfold Equation843. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff74_inst, reff74_op in H. discriminate H. Qed.

Lemma reff74_not845 : ~ @Equation845 Fin3 reff74_inst.
Proof. unfold Equation845. intro H. specialize (H F3_1 F3_2). unfold magma_op, reff74_inst, reff74_op in H. discriminate H. Qed.

Lemma reff74_not846 : ~ @Equation846 Fin3 reff74_inst.
Proof. unfold Equation846. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff74_inst, reff74_op in H. discriminate H. Qed.

Lemma reff74_not869 : ~ @Equation869 Fin3 reff74_inst.
Proof. unfold Equation869. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff74_inst, reff74_op in H. discriminate H. Qed.

Lemma reff74_not870 : ~ @Equation870 Fin3 reff74_inst.
Proof. unfold Equation870. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff74_inst, reff74_op in H. discriminate H. Qed.

Lemma reff74_not872 : ~ @Equation872 Fin3 reff74_inst.
Proof. unfold Equation872. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff74_inst, reff74_op in H. discriminate H. Qed.

Lemma reff74_not873 : ~ @Equation873 Fin3 reff74_inst.
Proof. unfold Equation873. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff74_inst, reff74_op in H. discriminate H. Qed.

Lemma reff74_not879 : ~ @Equation879 Fin3 reff74_inst.
Proof. unfold Equation879. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff74_inst, reff74_op in H. discriminate H. Qed.

Lemma reff74_not880 : ~ @Equation880 Fin3 reff74_inst.
Proof. unfold Equation880. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff74_inst, reff74_op in H. discriminate H. Qed.

Lemma reff74_not882 : ~ @Equation882 Fin3 reff74_inst.
Proof. unfold Equation882. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff74_inst, reff74_op in H. discriminate H. Qed.

Lemma reff74_not883 : ~ @Equation883 Fin3 reff74_inst.
Proof. unfold Equation883. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff74_inst, reff74_op in H. discriminate H. Qed.

Lemma reff74_not906 : ~ @Equation906 Fin3 reff74_inst.
Proof. unfold Equation906. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff74_inst, reff74_op in H. discriminate H. Qed.

Lemma reff74_not907 : ~ @Equation907 Fin3 reff74_inst.
Proof. unfold Equation907. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff74_inst, reff74_op in H. discriminate H. Qed.

Lemma reff74_not909 : ~ @Equation909 Fin3 reff74_inst.
Proof. unfold Equation909. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff74_inst, reff74_op in H. discriminate H. Qed.

Lemma reff74_not910 : ~ @Equation910 Fin3 reff74_inst.
Proof. unfold Equation910. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff74_inst, reff74_op in H. discriminate H. Qed.

Lemma reff74_not916 : ~ @Equation916 Fin3 reff74_inst.
Proof. unfold Equation916. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff74_inst, reff74_op in H. discriminate H. Qed.

Lemma reff74_not917 : ~ @Equation917 Fin3 reff74_inst.
Proof. unfold Equation917. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff74_inst, reff74_op in H. discriminate H. Qed.

Lemma reff74_not919 : ~ @Equation919 Fin3 reff74_inst.
Proof. unfold Equation919. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff74_inst, reff74_op in H. discriminate H. Qed.

Lemma reff74_not1021 : ~ @Equation1021 Fin3 reff74_inst.
Proof. unfold Equation1021. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff74_inst, reff74_op in H. discriminate H. Qed.

Lemma reff74_not1023 : ~ @Equation1023 Fin3 reff74_inst.
Proof. unfold Equation1023. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff74_inst, reff74_op in H. discriminate H. Qed.

Lemma reff74_not1026 : ~ @Equation1026 Fin3 reff74_inst.
Proof. unfold Equation1026. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff74_inst, reff74_op in H. discriminate H. Qed.

Lemma reff74_not1029 : ~ @Equation1029 Fin3 reff74_inst.
Proof. unfold Equation1029. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff74_inst, reff74_op in H. discriminate H. Qed.

Lemma reff74_not1036 : ~ @Equation1036 Fin3 reff74_inst.
Proof. unfold Equation1036. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff74_inst, reff74_op in H. discriminate H. Qed.

Lemma reff74_not1038 : ~ @Equation1038 Fin3 reff74_inst.
Proof. unfold Equation1038. intro H. specialize (H F3_1 F3_2). unfold magma_op, reff74_inst, reff74_op in H. discriminate H. Qed.

Lemma reff74_not1039 : ~ @Equation1039 Fin3 reff74_inst.
Proof. unfold Equation1039. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff74_inst, reff74_op in H. discriminate H. Qed.

Lemma reff74_not1045 : ~ @Equation1045 Fin3 reff74_inst.
Proof. unfold Equation1045. intro H. specialize (H F3_1 F3_2). unfold magma_op, reff74_inst, reff74_op in H. discriminate H. Qed.

Lemma reff74_not1046 : ~ @Equation1046 Fin3 reff74_inst.
Proof. unfold Equation1046. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff74_inst, reff74_op in H. discriminate H. Qed.

Lemma reff74_not1048 : ~ @Equation1048 Fin3 reff74_inst.
Proof. unfold Equation1048. intro H. specialize (H F3_1 F3_2). unfold magma_op, reff74_inst, reff74_op in H. discriminate H. Qed.

Lemma reff74_not1049 : ~ @Equation1049 Fin3 reff74_inst.
Proof. unfold Equation1049. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff74_inst, reff74_op in H. discriminate H. Qed.

Lemma reff74_not1072 : ~ @Equation1072 Fin3 reff74_inst.
Proof. unfold Equation1072. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff74_inst, reff74_op in H. discriminate H. Qed.

Lemma reff74_not1073 : ~ @Equation1073 Fin3 reff74_inst.
Proof. unfold Equation1073. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff74_inst, reff74_op in H. discriminate H. Qed.

Lemma reff74_not1075 : ~ @Equation1075 Fin3 reff74_inst.
Proof. unfold Equation1075. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff74_inst, reff74_op in H. discriminate H. Qed.

Lemma reff74_not1076 : ~ @Equation1076 Fin3 reff74_inst.
Proof. unfold Equation1076. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff74_inst, reff74_op in H. discriminate H. Qed.

Lemma reff74_not1082 : ~ @Equation1082 Fin3 reff74_inst.
Proof. unfold Equation1082. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff74_inst, reff74_op in H. discriminate H. Qed.

Lemma reff74_not1083 : ~ @Equation1083 Fin3 reff74_inst.
Proof. unfold Equation1083. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff74_inst, reff74_op in H. discriminate H. Qed.

Lemma reff74_not1085 : ~ @Equation1085 Fin3 reff74_inst.
Proof. unfold Equation1085. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff74_inst, reff74_op in H. discriminate H. Qed.

Lemma reff74_not1086 : ~ @Equation1086 Fin3 reff74_inst.
Proof. unfold Equation1086. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff74_inst, reff74_op in H. discriminate H. Qed.

Lemma reff74_not1109 : ~ @Equation1109 Fin3 reff74_inst.
Proof. unfold Equation1109. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff74_inst, reff74_op in H. discriminate H. Qed.

Lemma reff74_not1110 : ~ @Equation1110 Fin3 reff74_inst.
Proof. unfold Equation1110. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff74_inst, reff74_op in H. discriminate H. Qed.

Lemma reff74_not1112 : ~ @Equation1112 Fin3 reff74_inst.
Proof. unfold Equation1112. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff74_inst, reff74_op in H. discriminate H. Qed.

Lemma reff74_not1113 : ~ @Equation1113 Fin3 reff74_inst.
Proof. unfold Equation1113. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff74_inst, reff74_op in H. discriminate H. Qed.

Lemma reff74_not1119 : ~ @Equation1119 Fin3 reff74_inst.
Proof. unfold Equation1119. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff74_inst, reff74_op in H. discriminate H. Qed.

Lemma reff74_not1120 : ~ @Equation1120 Fin3 reff74_inst.
Proof. unfold Equation1120. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff74_inst, reff74_op in H. discriminate H. Qed.

Lemma reff74_not1122 : ~ @Equation1122 Fin3 reff74_inst.
Proof. unfold Equation1122. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff74_inst, reff74_op in H. discriminate H. Qed.

Lemma reff74_not1224 : ~ @Equation1224 Fin3 reff74_inst.
Proof. unfold Equation1224. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff74_inst, reff74_op in H. discriminate H. Qed.

Lemma reff74_not1226 : ~ @Equation1226 Fin3 reff74_inst.
Proof. unfold Equation1226. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff74_inst, reff74_op in H. discriminate H. Qed.

Lemma reff74_not1229 : ~ @Equation1229 Fin3 reff74_inst.
Proof. unfold Equation1229. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff74_inst, reff74_op in H. discriminate H. Qed.

Lemma reff74_not1232 : ~ @Equation1232 Fin3 reff74_inst.
Proof. unfold Equation1232. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff74_inst, reff74_op in H. discriminate H. Qed.

Lemma reff74_not1239 : ~ @Equation1239 Fin3 reff74_inst.
Proof. unfold Equation1239. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff74_inst, reff74_op in H. discriminate H. Qed.

Lemma reff74_not1242 : ~ @Equation1242 Fin3 reff74_inst.
Proof. unfold Equation1242. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff74_inst, reff74_op in H. discriminate H. Qed.

Lemma reff74_not1249 : ~ @Equation1249 Fin3 reff74_inst.
Proof. unfold Equation1249. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff74_inst, reff74_op in H. discriminate H. Qed.

Lemma reff74_not1251 : ~ @Equation1251 Fin3 reff74_inst.
Proof. unfold Equation1251. intro H. specialize (H F3_1 F3_2). unfold magma_op, reff74_inst, reff74_op in H. discriminate H. Qed.

Lemma reff74_not1252 : ~ @Equation1252 Fin3 reff74_inst.
Proof. unfold Equation1252. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff74_inst, reff74_op in H. discriminate H. Qed.

Lemma reff74_not1275 : ~ @Equation1275 Fin3 reff74_inst.
Proof. unfold Equation1275. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff74_inst, reff74_op in H. discriminate H. Qed.

Lemma reff74_not1276 : ~ @Equation1276 Fin3 reff74_inst.
Proof. unfold Equation1276. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff74_inst, reff74_op in H. discriminate H. Qed.

Lemma reff74_not1278 : ~ @Equation1278 Fin3 reff74_inst.
Proof. unfold Equation1278. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff74_inst, reff74_op in H. discriminate H. Qed.

Lemma reff74_not1279 : ~ @Equation1279 Fin3 reff74_inst.
Proof. unfold Equation1279. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff74_inst, reff74_op in H. discriminate H. Qed.

Lemma reff74_not1285 : ~ @Equation1285 Fin3 reff74_inst.
Proof. unfold Equation1285. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff74_inst, reff74_op in H. discriminate H. Qed.

Lemma reff74_not1286 : ~ @Equation1286 Fin3 reff74_inst.
Proof. unfold Equation1286. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff74_inst, reff74_op in H. discriminate H. Qed.

Lemma reff74_not1288 : ~ @Equation1288 Fin3 reff74_inst.
Proof. unfold Equation1288. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff74_inst, reff74_op in H. discriminate H. Qed.

Lemma reff74_not1289 : ~ @Equation1289 Fin3 reff74_inst.
Proof. unfold Equation1289. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff74_inst, reff74_op in H. discriminate H. Qed.

Lemma reff74_not1312 : ~ @Equation1312 Fin3 reff74_inst.
Proof. unfold Equation1312. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff74_inst, reff74_op in H. discriminate H. Qed.

Lemma reff74_not1313 : ~ @Equation1313 Fin3 reff74_inst.
Proof. unfold Equation1313. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff74_inst, reff74_op in H. discriminate H. Qed.

Lemma reff74_not1315 : ~ @Equation1315 Fin3 reff74_inst.
Proof. unfold Equation1315. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff74_inst, reff74_op in H. discriminate H. Qed.

Lemma reff74_not1316 : ~ @Equation1316 Fin3 reff74_inst.
Proof. unfold Equation1316. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff74_inst, reff74_op in H. discriminate H. Qed.

Lemma reff74_not1322 : ~ @Equation1322 Fin3 reff74_inst.
Proof. unfold Equation1322. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff74_inst, reff74_op in H. discriminate H. Qed.

Lemma reff74_not1323 : ~ @Equation1323 Fin3 reff74_inst.
Proof. unfold Equation1323. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff74_inst, reff74_op in H. discriminate H. Qed.

Lemma reff74_not1325 : ~ @Equation1325 Fin3 reff74_inst.
Proof. unfold Equation1325. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff74_inst, reff74_op in H. discriminate H. Qed.

Lemma reff74_not1427 : ~ @Equation1427 Fin3 reff74_inst.
Proof. unfold Equation1427. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff74_inst, reff74_op in H. discriminate H. Qed.

Lemma reff74_not1428 : ~ @Equation1428 Fin3 reff74_inst.
Proof. unfold Equation1428. intro H. specialize (H F3_1 F3_2). unfold magma_op, reff74_inst, reff74_op in H. discriminate H. Qed.

Lemma reff74_not1429 : ~ @Equation1429 Fin3 reff74_inst.
Proof. unfold Equation1429. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff74_inst, reff74_op in H. discriminate H. Qed.

Lemma reff74_not1431 : ~ @Equation1431 Fin3 reff74_inst.
Proof. unfold Equation1431. intro H. specialize (H F3_1 F3_2). unfold magma_op, reff74_inst, reff74_op in H. discriminate H. Qed.

Lemma reff74_not1432 : ~ @Equation1432 Fin3 reff74_inst.
Proof. unfold Equation1432. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff74_inst, reff74_op in H. discriminate H. Qed.

Lemma reff74_not1434 : ~ @Equation1434 Fin3 reff74_inst.
Proof. unfold Equation1434. intro H. specialize (H F3_1 F3_2). unfold magma_op, reff74_inst, reff74_op in H. discriminate H. Qed.

Lemma reff74_not1435 : ~ @Equation1435 Fin3 reff74_inst.
Proof. unfold Equation1435. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff74_inst, reff74_op in H. discriminate H. Qed.

Lemma reff74_not1441 : ~ @Equation1441 Fin3 reff74_inst.
Proof. unfold Equation1441. intro H. specialize (H F3_2 F3_1). unfold magma_op, reff74_inst, reff74_op in H. discriminate H. Qed.

Lemma reff74_not1442 : ~ @Equation1442 Fin3 reff74_inst.
Proof. unfold Equation1442. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff74_inst, reff74_op in H. discriminate H. Qed.

Lemma reff74_not1444 : ~ @Equation1444 Fin3 reff74_inst.
Proof. unfold Equation1444. intro H. specialize (H F3_1 F3_2). unfold magma_op, reff74_inst, reff74_op in H. discriminate H. Qed.

Lemma reff74_not1445 : ~ @Equation1445 Fin3 reff74_inst.
Proof. unfold Equation1445. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff74_inst, reff74_op in H. discriminate H. Qed.

Lemma reff74_not1451 : ~ @Equation1451 Fin3 reff74_inst.
Proof. unfold Equation1451. intro H. specialize (H F3_1 F3_2). unfold magma_op, reff74_inst, reff74_op in H. discriminate H. Qed.

Lemma reff74_not1452 : ~ @Equation1452 Fin3 reff74_inst.
Proof. unfold Equation1452. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff74_inst, reff74_op in H. discriminate H. Qed.

Lemma reff74_not1454 : ~ @Equation1454 Fin3 reff74_inst.
Proof. unfold Equation1454. intro H. specialize (H F3_1 F3_2). unfold magma_op, reff74_inst, reff74_op in H. discriminate H. Qed.

Lemma reff74_not1455 : ~ @Equation1455 Fin3 reff74_inst.
Proof. unfold Equation1455. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff74_inst, reff74_op in H. discriminate H. Qed.

Lemma reff74_not1478 : ~ @Equation1478 Fin3 reff74_inst.
Proof. unfold Equation1478. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff74_inst, reff74_op in H. discriminate H. Qed.

Lemma reff74_not1479 : ~ @Equation1479 Fin3 reff74_inst.
Proof. unfold Equation1479. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff74_inst, reff74_op in H. discriminate H. Qed.

Lemma reff74_not1481 : ~ @Equation1481 Fin3 reff74_inst.
Proof. unfold Equation1481. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff74_inst, reff74_op in H. discriminate H. Qed.

Lemma reff74_not1482 : ~ @Equation1482 Fin3 reff74_inst.
Proof. unfold Equation1482. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff74_inst, reff74_op in H. discriminate H. Qed.

Lemma reff74_not1488 : ~ @Equation1488 Fin3 reff74_inst.
Proof. unfold Equation1488. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff74_inst, reff74_op in H. discriminate H. Qed.

Lemma reff74_not1489 : ~ @Equation1489 Fin3 reff74_inst.
Proof. unfold Equation1489. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff74_inst, reff74_op in H. discriminate H. Qed.

Lemma reff74_not1491 : ~ @Equation1491 Fin3 reff74_inst.
Proof. unfold Equation1491. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff74_inst, reff74_op in H. discriminate H. Qed.

Lemma reff74_not1492 : ~ @Equation1492 Fin3 reff74_inst.
Proof. unfold Equation1492. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff74_inst, reff74_op in H. discriminate H. Qed.

Lemma reff74_not1515 : ~ @Equation1515 Fin3 reff74_inst.
Proof. unfold Equation1515. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff74_inst, reff74_op in H. discriminate H. Qed.

Lemma reff74_not1516 : ~ @Equation1516 Fin3 reff74_inst.
Proof. unfold Equation1516. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff74_inst, reff74_op in H. discriminate H. Qed.

Lemma reff74_not1518 : ~ @Equation1518 Fin3 reff74_inst.
Proof. unfold Equation1518. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff74_inst, reff74_op in H. discriminate H. Qed.

Lemma reff74_not1519 : ~ @Equation1519 Fin3 reff74_inst.
Proof. unfold Equation1519. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff74_inst, reff74_op in H. discriminate H. Qed.

Lemma reff74_not1525 : ~ @Equation1525 Fin3 reff74_inst.
Proof. unfold Equation1525. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff74_inst, reff74_op in H. discriminate H. Qed.

Lemma reff74_not1526 : ~ @Equation1526 Fin3 reff74_inst.
Proof. unfold Equation1526. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff74_inst, reff74_op in H. discriminate H. Qed.

Lemma reff74_not1528 : ~ @Equation1528 Fin3 reff74_inst.
Proof. unfold Equation1528. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff74_inst, reff74_op in H. discriminate H. Qed.

Lemma reff74_not1630 : ~ @Equation1630 Fin3 reff74_inst.
Proof. unfold Equation1630. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff74_inst, reff74_op in H. discriminate H. Qed.

Lemma reff74_not1632 : ~ @Equation1632 Fin3 reff74_inst.
Proof. unfold Equation1632. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff74_inst, reff74_op in H. discriminate H. Qed.

Lemma reff74_not1635 : ~ @Equation1635 Fin3 reff74_inst.
Proof. unfold Equation1635. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff74_inst, reff74_op in H. discriminate H. Qed.

Lemma reff74_not1637 : ~ @Equation1637 Fin3 reff74_inst.
Proof. unfold Equation1637. intro H. specialize (H F3_1 F3_2). unfold magma_op, reff74_inst, reff74_op in H. discriminate H. Qed.

Lemma reff74_not1638 : ~ @Equation1638 Fin3 reff74_inst.
Proof. unfold Equation1638. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff74_inst, reff74_op in H. discriminate H. Qed.

Lemma reff74_not1644 : ~ @Equation1644 Fin3 reff74_inst.
Proof. unfold Equation1644. intro H. specialize (H F3_2 F3_1). unfold magma_op, reff74_inst, reff74_op in H. discriminate H. Qed.

Lemma reff74_not1645 : ~ @Equation1645 Fin3 reff74_inst.
Proof. unfold Equation1645. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff74_inst, reff74_op in H. discriminate H. Qed.

Lemma reff74_not1647 : ~ @Equation1647 Fin3 reff74_inst.
Proof. unfold Equation1647. intro H. specialize (H F3_2 F3_1). unfold magma_op, reff74_inst, reff74_op in H. discriminate H. Qed.

Lemma reff74_not1648 : ~ @Equation1648 Fin3 reff74_inst.
Proof. unfold Equation1648. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff74_inst, reff74_op in H. discriminate H. Qed.

Lemma reff74_not1654 : ~ @Equation1654 Fin3 reff74_inst.
Proof. unfold Equation1654. intro H. specialize (H F3_2 F3_1). unfold magma_op, reff74_inst, reff74_op in H. discriminate H. Qed.

Lemma reff74_not1655 : ~ @Equation1655 Fin3 reff74_inst.
Proof. unfold Equation1655. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff74_inst, reff74_op in H. discriminate H. Qed.

Lemma reff74_not1657 : ~ @Equation1657 Fin3 reff74_inst.
Proof. unfold Equation1657. intro H. specialize (H F3_1 F3_2). unfold magma_op, reff74_inst, reff74_op in H. discriminate H. Qed.

Lemma reff74_not1658 : ~ @Equation1658 Fin3 reff74_inst.
Proof. unfold Equation1658. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff74_inst, reff74_op in H. discriminate H. Qed.

Lemma reff74_not1681 : ~ @Equation1681 Fin3 reff74_inst.
Proof. unfold Equation1681. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff74_inst, reff74_op in H. discriminate H. Qed.

Lemma reff74_not1682 : ~ @Equation1682 Fin3 reff74_inst.
Proof. unfold Equation1682. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff74_inst, reff74_op in H. discriminate H. Qed.

Lemma reff74_not1684 : ~ @Equation1684 Fin3 reff74_inst.
Proof. unfold Equation1684. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff74_inst, reff74_op in H. discriminate H. Qed.

Lemma reff74_not1685 : ~ @Equation1685 Fin3 reff74_inst.
Proof. unfold Equation1685. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff74_inst, reff74_op in H. discriminate H. Qed.

Lemma reff74_not1691 : ~ @Equation1691 Fin3 reff74_inst.
Proof. unfold Equation1691. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff74_inst, reff74_op in H. discriminate H. Qed.

Lemma reff74_not1692 : ~ @Equation1692 Fin3 reff74_inst.
Proof. unfold Equation1692. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff74_inst, reff74_op in H. discriminate H. Qed.

Lemma reff74_not1694 : ~ @Equation1694 Fin3 reff74_inst.
Proof. unfold Equation1694. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff74_inst, reff74_op in H. discriminate H. Qed.

Lemma reff74_not1695 : ~ @Equation1695 Fin3 reff74_inst.
Proof. unfold Equation1695. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff74_inst, reff74_op in H. discriminate H. Qed.

Lemma reff74_not1718 : ~ @Equation1718 Fin3 reff74_inst.
Proof. unfold Equation1718. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff74_inst, reff74_op in H. discriminate H. Qed.

Lemma reff74_not1719 : ~ @Equation1719 Fin3 reff74_inst.
Proof. unfold Equation1719. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff74_inst, reff74_op in H. discriminate H. Qed.

Lemma reff74_not1721 : ~ @Equation1721 Fin3 reff74_inst.
Proof. unfold Equation1721. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff74_inst, reff74_op in H. discriminate H. Qed.

Lemma reff74_not1722 : ~ @Equation1722 Fin3 reff74_inst.
Proof. unfold Equation1722. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff74_inst, reff74_op in H. discriminate H. Qed.

Lemma reff74_not1728 : ~ @Equation1728 Fin3 reff74_inst.
Proof. unfold Equation1728. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff74_inst, reff74_op in H. discriminate H. Qed.

Lemma reff74_not1729 : ~ @Equation1729 Fin3 reff74_inst.
Proof. unfold Equation1729. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff74_inst, reff74_op in H. discriminate H. Qed.

Lemma reff74_not1731 : ~ @Equation1731 Fin3 reff74_inst.
Proof. unfold Equation1731. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff74_inst, reff74_op in H. discriminate H. Qed.

Lemma reff74_not1833 : ~ @Equation1833 Fin3 reff74_inst.
Proof. unfold Equation1833. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff74_inst, reff74_op in H. discriminate H. Qed.

Lemma reff74_not1834 : ~ @Equation1834 Fin3 reff74_inst.
Proof. unfold Equation1834. intro H. specialize (H F3_1 F3_2). unfold magma_op, reff74_inst, reff74_op in H. discriminate H. Qed.

Lemma reff74_not1835 : ~ @Equation1835 Fin3 reff74_inst.
Proof. unfold Equation1835. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff74_inst, reff74_op in H. discriminate H. Qed.

Lemma reff74_not1838 : ~ @Equation1838 Fin3 reff74_inst.
Proof. unfold Equation1838. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff74_inst, reff74_op in H. discriminate H. Qed.

Lemma reff74_not1840 : ~ @Equation1840 Fin3 reff74_inst.
Proof. unfold Equation1840. intro H. specialize (H F3_1 F3_2). unfold magma_op, reff74_inst, reff74_op in H. discriminate H. Qed.

Lemma reff74_not1841 : ~ @Equation1841 Fin3 reff74_inst.
Proof. unfold Equation1841. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff74_inst, reff74_op in H. discriminate H. Qed.

Lemma reff74_not1848 : ~ @Equation1848 Fin3 reff74_inst.
Proof. unfold Equation1848. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff74_inst, reff74_op in H. discriminate H. Qed.

Lemma reff74_not1850 : ~ @Equation1850 Fin3 reff74_inst.
Proof. unfold Equation1850. intro H. specialize (H F3_1 F3_2). unfold magma_op, reff74_inst, reff74_op in H. discriminate H. Qed.

Lemma reff74_not1851 : ~ @Equation1851 Fin3 reff74_inst.
Proof. unfold Equation1851. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff74_inst, reff74_op in H. discriminate H. Qed.

Lemma reff74_not1857 : ~ @Equation1857 Fin3 reff74_inst.
Proof. unfold Equation1857. intro H. specialize (H F3_2 F3_1). unfold magma_op, reff74_inst, reff74_op in H. discriminate H. Qed.

Lemma reff74_not1858 : ~ @Equation1858 Fin3 reff74_inst.
Proof. unfold Equation1858. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff74_inst, reff74_op in H. discriminate H. Qed.

Lemma reff74_not1860 : ~ @Equation1860 Fin3 reff74_inst.
Proof. unfold Equation1860. intro H. specialize (H F3_1 F3_2). unfold magma_op, reff74_inst, reff74_op in H. discriminate H. Qed.

Lemma reff74_not1861 : ~ @Equation1861 Fin3 reff74_inst.
Proof. unfold Equation1861. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff74_inst, reff74_op in H. discriminate H. Qed.

Lemma reff74_not1884 : ~ @Equation1884 Fin3 reff74_inst.
Proof. unfold Equation1884. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff74_inst, reff74_op in H. discriminate H. Qed.

Lemma reff74_not1885 : ~ @Equation1885 Fin3 reff74_inst.
Proof. unfold Equation1885. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff74_inst, reff74_op in H. discriminate H. Qed.

Lemma reff74_not1887 : ~ @Equation1887 Fin3 reff74_inst.
Proof. unfold Equation1887. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff74_inst, reff74_op in H. discriminate H. Qed.

Lemma reff74_not1888 : ~ @Equation1888 Fin3 reff74_inst.
Proof. unfold Equation1888. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff74_inst, reff74_op in H. discriminate H. Qed.

Lemma reff74_not1894 : ~ @Equation1894 Fin3 reff74_inst.
Proof. unfold Equation1894. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff74_inst, reff74_op in H. discriminate H. Qed.

Lemma reff74_not1895 : ~ @Equation1895 Fin3 reff74_inst.
Proof. unfold Equation1895. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff74_inst, reff74_op in H. discriminate H. Qed.

Lemma reff74_not1897 : ~ @Equation1897 Fin3 reff74_inst.
Proof. unfold Equation1897. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff74_inst, reff74_op in H. discriminate H. Qed.

Lemma reff74_not1898 : ~ @Equation1898 Fin3 reff74_inst.
Proof. unfold Equation1898. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff74_inst, reff74_op in H. discriminate H. Qed.

Lemma reff74_not1921 : ~ @Equation1921 Fin3 reff74_inst.
Proof. unfold Equation1921. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff74_inst, reff74_op in H. discriminate H. Qed.

Lemma reff74_not1922 : ~ @Equation1922 Fin3 reff74_inst.
Proof. unfold Equation1922. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff74_inst, reff74_op in H. discriminate H. Qed.

Lemma reff74_not1924 : ~ @Equation1924 Fin3 reff74_inst.
Proof. unfold Equation1924. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff74_inst, reff74_op in H. discriminate H. Qed.

Lemma reff74_not1925 : ~ @Equation1925 Fin3 reff74_inst.
Proof. unfold Equation1925. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff74_inst, reff74_op in H. discriminate H. Qed.

Lemma reff74_not1931 : ~ @Equation1931 Fin3 reff74_inst.
Proof. unfold Equation1931. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff74_inst, reff74_op in H. discriminate H. Qed.

Lemma reff74_not1932 : ~ @Equation1932 Fin3 reff74_inst.
Proof. unfold Equation1932. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff74_inst, reff74_op in H. discriminate H. Qed.

Lemma reff74_not1934 : ~ @Equation1934 Fin3 reff74_inst.
Proof. unfold Equation1934. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff74_inst, reff74_op in H. discriminate H. Qed.

Lemma reff74_not2036 : ~ @Equation2036 Fin3 reff74_inst.
Proof. unfold Equation2036. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff74_inst, reff74_op in H. discriminate H. Qed.

Lemma reff74_not2037 : ~ @Equation2037 Fin3 reff74_inst.
Proof. unfold Equation2037. intro H. specialize (H F3_1 F3_2). unfold magma_op, reff74_inst, reff74_op in H. discriminate H. Qed.

Lemma reff74_not2038 : ~ @Equation2038 Fin3 reff74_inst.
Proof. unfold Equation2038. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff74_inst, reff74_op in H. discriminate H. Qed.

Lemma reff74_not2040 : ~ @Equation2040 Fin3 reff74_inst.
Proof. unfold Equation2040. intro H. specialize (H F3_2 F3_1). unfold magma_op, reff74_inst, reff74_op in H. discriminate H. Qed.

Lemma reff74_not2041 : ~ @Equation2041 Fin3 reff74_inst.
Proof. unfold Equation2041. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff74_inst, reff74_op in H. discriminate H. Qed.

Lemma reff74_not2043 : ~ @Equation2043 Fin3 reff74_inst.
Proof. unfold Equation2043. intro H. specialize (H F3_1 F3_2). unfold magma_op, reff74_inst, reff74_op in H. discriminate H. Qed.

Lemma reff74_not2044 : ~ @Equation2044 Fin3 reff74_inst.
Proof. unfold Equation2044. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff74_inst, reff74_op in H. discriminate H. Qed.

Lemma reff74_not2050 : ~ @Equation2050 Fin3 reff74_inst.
Proof. unfold Equation2050. intro H. specialize (H F3_2 F3_1). unfold magma_op, reff74_inst, reff74_op in H. discriminate H. Qed.

Lemma reff74_not2051 : ~ @Equation2051 Fin3 reff74_inst.
Proof. unfold Equation2051. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff74_inst, reff74_op in H. discriminate H. Qed.

Lemma reff74_not2053 : ~ @Equation2053 Fin3 reff74_inst.
Proof. unfold Equation2053. intro H. specialize (H F3_1 F3_2). unfold magma_op, reff74_inst, reff74_op in H. discriminate H. Qed.

Lemma reff74_not2054 : ~ @Equation2054 Fin3 reff74_inst.
Proof. unfold Equation2054. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff74_inst, reff74_op in H. discriminate H. Qed.

Lemma reff74_not2060 : ~ @Equation2060 Fin3 reff74_inst.
Proof. unfold Equation2060. intro H. specialize (H F3_2 F3_1). unfold magma_op, reff74_inst, reff74_op in H. discriminate H. Qed.

Lemma reff74_not2061 : ~ @Equation2061 Fin3 reff74_inst.
Proof. unfold Equation2061. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff74_inst, reff74_op in H. discriminate H. Qed.

Lemma reff74_not2063 : ~ @Equation2063 Fin3 reff74_inst.
Proof. unfold Equation2063. intro H. specialize (H F3_1 F3_2). unfold magma_op, reff74_inst, reff74_op in H. discriminate H. Qed.

Lemma reff74_not2064 : ~ @Equation2064 Fin3 reff74_inst.
Proof. unfold Equation2064. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff74_inst, reff74_op in H. discriminate H. Qed.

Lemma reff74_not2087 : ~ @Equation2087 Fin3 reff74_inst.
Proof. unfold Equation2087. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff74_inst, reff74_op in H. discriminate H. Qed.

Lemma reff74_not2088 : ~ @Equation2088 Fin3 reff74_inst.
Proof. unfold Equation2088. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff74_inst, reff74_op in H. discriminate H. Qed.

Lemma reff74_not2090 : ~ @Equation2090 Fin3 reff74_inst.
Proof. unfold Equation2090. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff74_inst, reff74_op in H. discriminate H. Qed.

Lemma reff74_not2091 : ~ @Equation2091 Fin3 reff74_inst.
Proof. unfold Equation2091. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff74_inst, reff74_op in H. discriminate H. Qed.

Lemma reff74_not2097 : ~ @Equation2097 Fin3 reff74_inst.
Proof. unfold Equation2097. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff74_inst, reff74_op in H. discriminate H. Qed.

Lemma reff74_not2098 : ~ @Equation2098 Fin3 reff74_inst.
Proof. unfold Equation2098. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff74_inst, reff74_op in H. discriminate H. Qed.

Lemma reff74_not2100 : ~ @Equation2100 Fin3 reff74_inst.
Proof. unfold Equation2100. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff74_inst, reff74_op in H. discriminate H. Qed.

Lemma reff74_not2101 : ~ @Equation2101 Fin3 reff74_inst.
Proof. unfold Equation2101. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff74_inst, reff74_op in H. discriminate H. Qed.

Lemma reff74_not2124 : ~ @Equation2124 Fin3 reff74_inst.
Proof. unfold Equation2124. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff74_inst, reff74_op in H. discriminate H. Qed.

Lemma reff74_not2125 : ~ @Equation2125 Fin3 reff74_inst.
Proof. unfold Equation2125. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff74_inst, reff74_op in H. discriminate H. Qed.

Lemma reff74_not2127 : ~ @Equation2127 Fin3 reff74_inst.
Proof. unfold Equation2127. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff74_inst, reff74_op in H. discriminate H. Qed.

Lemma reff74_not2128 : ~ @Equation2128 Fin3 reff74_inst.
Proof. unfold Equation2128. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff74_inst, reff74_op in H. discriminate H. Qed.

Lemma reff74_not2134 : ~ @Equation2134 Fin3 reff74_inst.
Proof. unfold Equation2134. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff74_inst, reff74_op in H. discriminate H. Qed.

Lemma reff74_not2135 : ~ @Equation2135 Fin3 reff74_inst.
Proof. unfold Equation2135. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff74_inst, reff74_op in H. discriminate H. Qed.

Lemma reff74_not2137 : ~ @Equation2137 Fin3 reff74_inst.
Proof. unfold Equation2137. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff74_inst, reff74_op in H. discriminate H. Qed.

Lemma reff74_not2239 : ~ @Equation2239 Fin3 reff74_inst.
Proof. unfold Equation2239. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff74_inst, reff74_op in H. discriminate H. Qed.

Lemma reff74_not2241 : ~ @Equation2241 Fin3 reff74_inst.
Proof. unfold Equation2241. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff74_inst, reff74_op in H. discriminate H. Qed.

Lemma reff74_not2244 : ~ @Equation2244 Fin3 reff74_inst.
Proof. unfold Equation2244. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff74_inst, reff74_op in H. discriminate H. Qed.

Lemma reff74_not2247 : ~ @Equation2247 Fin3 reff74_inst.
Proof. unfold Equation2247. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff74_inst, reff74_op in H. discriminate H. Qed.

Lemma reff74_not2254 : ~ @Equation2254 Fin3 reff74_inst.
Proof. unfold Equation2254. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff74_inst, reff74_op in H. discriminate H. Qed.

Lemma reff74_not2257 : ~ @Equation2257 Fin3 reff74_inst.
Proof. unfold Equation2257. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff74_inst, reff74_op in H. discriminate H. Qed.

Lemma reff74_not2264 : ~ @Equation2264 Fin3 reff74_inst.
Proof. unfold Equation2264. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff74_inst, reff74_op in H. discriminate H. Qed.

Lemma reff74_not2266 : ~ @Equation2266 Fin3 reff74_inst.
Proof. unfold Equation2266. intro H. specialize (H F3_2 F3_1). unfold magma_op, reff74_inst, reff74_op in H. discriminate H. Qed.

Lemma reff74_not2267 : ~ @Equation2267 Fin3 reff74_inst.
Proof. unfold Equation2267. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff74_inst, reff74_op in H. discriminate H. Qed.

Lemma reff74_not2290 : ~ @Equation2290 Fin3 reff74_inst.
Proof. unfold Equation2290. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff74_inst, reff74_op in H. discriminate H. Qed.

Lemma reff74_not2291 : ~ @Equation2291 Fin3 reff74_inst.
Proof. unfold Equation2291. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff74_inst, reff74_op in H. discriminate H. Qed.

Lemma reff74_not2293 : ~ @Equation2293 Fin3 reff74_inst.
Proof. unfold Equation2293. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff74_inst, reff74_op in H. discriminate H. Qed.

Lemma reff74_not2294 : ~ @Equation2294 Fin3 reff74_inst.
Proof. unfold Equation2294. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff74_inst, reff74_op in H. discriminate H. Qed.

Lemma reff74_not2300 : ~ @Equation2300 Fin3 reff74_inst.
Proof. unfold Equation2300. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff74_inst, reff74_op in H. discriminate H. Qed.

Lemma reff74_not2301 : ~ @Equation2301 Fin3 reff74_inst.
Proof. unfold Equation2301. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff74_inst, reff74_op in H. discriminate H. Qed.

Lemma reff74_not2303 : ~ @Equation2303 Fin3 reff74_inst.
Proof. unfold Equation2303. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff74_inst, reff74_op in H. discriminate H. Qed.

Lemma reff74_not2304 : ~ @Equation2304 Fin3 reff74_inst.
Proof. unfold Equation2304. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff74_inst, reff74_op in H. discriminate H. Qed.

Lemma reff74_not2327 : ~ @Equation2327 Fin3 reff74_inst.
Proof. unfold Equation2327. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff74_inst, reff74_op in H. discriminate H. Qed.

Lemma reff74_not2328 : ~ @Equation2328 Fin3 reff74_inst.
Proof. unfold Equation2328. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff74_inst, reff74_op in H. discriminate H. Qed.

Lemma reff74_not2330 : ~ @Equation2330 Fin3 reff74_inst.
Proof. unfold Equation2330. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff74_inst, reff74_op in H. discriminate H. Qed.

Lemma reff74_not2331 : ~ @Equation2331 Fin3 reff74_inst.
Proof. unfold Equation2331. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff74_inst, reff74_op in H. discriminate H. Qed.

Lemma reff74_not2337 : ~ @Equation2337 Fin3 reff74_inst.
Proof. unfold Equation2337. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff74_inst, reff74_op in H. discriminate H. Qed.

Lemma reff74_not2338 : ~ @Equation2338 Fin3 reff74_inst.
Proof. unfold Equation2338. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff74_inst, reff74_op in H. discriminate H. Qed.

Lemma reff74_not2340 : ~ @Equation2340 Fin3 reff74_inst.
Proof. unfold Equation2340. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff74_inst, reff74_op in H. discriminate H. Qed.

Lemma reff74_not2442 : ~ @Equation2442 Fin3 reff74_inst.
Proof. unfold Equation2442. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff74_inst, reff74_op in H. discriminate H. Qed.

Lemma reff74_not2444 : ~ @Equation2444 Fin3 reff74_inst.
Proof. unfold Equation2444. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff74_inst, reff74_op in H. discriminate H. Qed.

Lemma reff74_not2447 : ~ @Equation2447 Fin3 reff74_inst.
Proof. unfold Equation2447. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff74_inst, reff74_op in H. discriminate H. Qed.

Lemma reff74_not2449 : ~ @Equation2449 Fin3 reff74_inst.
Proof. unfold Equation2449. intro H. specialize (H F3_2 F3_1). unfold magma_op, reff74_inst, reff74_op in H. discriminate H. Qed.

Lemma reff74_not2450 : ~ @Equation2450 Fin3 reff74_inst.
Proof. unfold Equation2450. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff74_inst, reff74_op in H. discriminate H. Qed.

Lemma reff74_not2457 : ~ @Equation2457 Fin3 reff74_inst.
Proof. unfold Equation2457. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff74_inst, reff74_op in H. discriminate H. Qed.

Lemma reff74_not2459 : ~ @Equation2459 Fin3 reff74_inst.
Proof. unfold Equation2459. intro H. specialize (H F3_2 F3_1). unfold magma_op, reff74_inst, reff74_op in H. discriminate H. Qed.

Lemma reff74_not2460 : ~ @Equation2460 Fin3 reff74_inst.
Proof. unfold Equation2460. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff74_inst, reff74_op in H. discriminate H. Qed.

Lemma reff74_not2467 : ~ @Equation2467 Fin3 reff74_inst.
Proof. unfold Equation2467. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff74_inst, reff74_op in H. discriminate H. Qed.

Lemma reff74_not2469 : ~ @Equation2469 Fin3 reff74_inst.
Proof. unfold Equation2469. intro H. specialize (H F3_2 F3_1). unfold magma_op, reff74_inst, reff74_op in H. discriminate H. Qed.

Lemma reff74_not2470 : ~ @Equation2470 Fin3 reff74_inst.
Proof. unfold Equation2470. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff74_inst, reff74_op in H. discriminate H. Qed.

Lemma reff74_not2493 : ~ @Equation2493 Fin3 reff74_inst.
Proof. unfold Equation2493. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff74_inst, reff74_op in H. discriminate H. Qed.

Lemma reff74_not2494 : ~ @Equation2494 Fin3 reff74_inst.
Proof. unfold Equation2494. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff74_inst, reff74_op in H. discriminate H. Qed.

Lemma reff74_not2496 : ~ @Equation2496 Fin3 reff74_inst.
Proof. unfold Equation2496. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff74_inst, reff74_op in H. discriminate H. Qed.

Lemma reff74_not2497 : ~ @Equation2497 Fin3 reff74_inst.
Proof. unfold Equation2497. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff74_inst, reff74_op in H. discriminate H. Qed.

Lemma reff74_not2503 : ~ @Equation2503 Fin3 reff74_inst.
Proof. unfold Equation2503. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff74_inst, reff74_op in H. discriminate H. Qed.

Lemma reff74_not2504 : ~ @Equation2504 Fin3 reff74_inst.
Proof. unfold Equation2504. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff74_inst, reff74_op in H. discriminate H. Qed.

Lemma reff74_not2506 : ~ @Equation2506 Fin3 reff74_inst.
Proof. unfold Equation2506. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff74_inst, reff74_op in H. discriminate H. Qed.

Lemma reff74_not2507 : ~ @Equation2507 Fin3 reff74_inst.
Proof. unfold Equation2507. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff74_inst, reff74_op in H. discriminate H. Qed.

Lemma reff74_not2530 : ~ @Equation2530 Fin3 reff74_inst.
Proof. unfold Equation2530. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff74_inst, reff74_op in H. discriminate H. Qed.

Lemma reff74_not2531 : ~ @Equation2531 Fin3 reff74_inst.
Proof. unfold Equation2531. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff74_inst, reff74_op in H. discriminate H. Qed.

Lemma reff74_not2533 : ~ @Equation2533 Fin3 reff74_inst.
Proof. unfold Equation2533. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff74_inst, reff74_op in H. discriminate H. Qed.

Lemma reff74_not2534 : ~ @Equation2534 Fin3 reff74_inst.
Proof. unfold Equation2534. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff74_inst, reff74_op in H. discriminate H. Qed.

Lemma reff74_not2540 : ~ @Equation2540 Fin3 reff74_inst.
Proof. unfold Equation2540. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff74_inst, reff74_op in H. discriminate H. Qed.

Lemma reff74_not2541 : ~ @Equation2541 Fin3 reff74_inst.
Proof. unfold Equation2541. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff74_inst, reff74_op in H. discriminate H. Qed.

Lemma reff74_not2543 : ~ @Equation2543 Fin3 reff74_inst.
Proof. unfold Equation2543. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff74_inst, reff74_op in H. discriminate H. Qed.

Lemma reff74_not2645 : ~ @Equation2645 Fin3 reff74_inst.
Proof. unfold Equation2645. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff74_inst, reff74_op in H. discriminate H. Qed.

Lemma reff74_not2647 : ~ @Equation2647 Fin3 reff74_inst.
Proof. unfold Equation2647. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff74_inst, reff74_op in H. discriminate H. Qed.

Lemma reff74_not2650 : ~ @Equation2650 Fin3 reff74_inst.
Proof. unfold Equation2650. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff74_inst, reff74_op in H. discriminate H. Qed.

Lemma reff74_not2652 : ~ @Equation2652 Fin3 reff74_inst.
Proof. unfold Equation2652. intro H. specialize (H F3_2 F3_1). unfold magma_op, reff74_inst, reff74_op in H. discriminate H. Qed.

Lemma reff74_not2653 : ~ @Equation2653 Fin3 reff74_inst.
Proof. unfold Equation2653. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff74_inst, reff74_op in H. discriminate H. Qed.

Lemma reff74_not2659 : ~ @Equation2659 Fin3 reff74_inst.
Proof. unfold Equation2659. intro H. specialize (H F3_2 F3_1). unfold magma_op, reff74_inst, reff74_op in H. discriminate H. Qed.

Lemma reff74_not2660 : ~ @Equation2660 Fin3 reff74_inst.
Proof. unfold Equation2660. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff74_inst, reff74_op in H. discriminate H. Qed.

Lemma reff74_not2662 : ~ @Equation2662 Fin3 reff74_inst.
Proof. unfold Equation2662. intro H. specialize (H F3_2 F3_1). unfold magma_op, reff74_inst, reff74_op in H. discriminate H. Qed.

Lemma reff74_not2663 : ~ @Equation2663 Fin3 reff74_inst.
Proof. unfold Equation2663. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff74_inst, reff74_op in H. discriminate H. Qed.

Lemma reff74_not2669 : ~ @Equation2669 Fin3 reff74_inst.
Proof. unfold Equation2669. intro H. specialize (H F3_2 F3_1). unfold magma_op, reff74_inst, reff74_op in H. discriminate H. Qed.

Lemma reff74_not2670 : ~ @Equation2670 Fin3 reff74_inst.
Proof. unfold Equation2670. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff74_inst, reff74_op in H. discriminate H. Qed.

Lemma reff74_not2672 : ~ @Equation2672 Fin3 reff74_inst.
Proof. unfold Equation2672. intro H. specialize (H F3_2 F3_1). unfold magma_op, reff74_inst, reff74_op in H. discriminate H. Qed.

Lemma reff74_not2673 : ~ @Equation2673 Fin3 reff74_inst.
Proof. unfold Equation2673. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff74_inst, reff74_op in H. discriminate H. Qed.

Lemma reff74_not2696 : ~ @Equation2696 Fin3 reff74_inst.
Proof. unfold Equation2696. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff74_inst, reff74_op in H. discriminate H. Qed.

Lemma reff74_not2697 : ~ @Equation2697 Fin3 reff74_inst.
Proof. unfold Equation2697. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff74_inst, reff74_op in H. discriminate H. Qed.

Lemma reff74_not2699 : ~ @Equation2699 Fin3 reff74_inst.
Proof. unfold Equation2699. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff74_inst, reff74_op in H. discriminate H. Qed.

Lemma reff74_not2700 : ~ @Equation2700 Fin3 reff74_inst.
Proof. unfold Equation2700. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff74_inst, reff74_op in H. discriminate H. Qed.

Lemma reff74_not2706 : ~ @Equation2706 Fin3 reff74_inst.
Proof. unfold Equation2706. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff74_inst, reff74_op in H. discriminate H. Qed.

Lemma reff74_not2707 : ~ @Equation2707 Fin3 reff74_inst.
Proof. unfold Equation2707. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff74_inst, reff74_op in H. discriminate H. Qed.

Lemma reff74_not2709 : ~ @Equation2709 Fin3 reff74_inst.
Proof. unfold Equation2709. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff74_inst, reff74_op in H. discriminate H. Qed.

Lemma reff74_not2710 : ~ @Equation2710 Fin3 reff74_inst.
Proof. unfold Equation2710. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff74_inst, reff74_op in H. discriminate H. Qed.

Lemma reff74_not2733 : ~ @Equation2733 Fin3 reff74_inst.
Proof. unfold Equation2733. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff74_inst, reff74_op in H. discriminate H. Qed.

Lemma reff74_not2734 : ~ @Equation2734 Fin3 reff74_inst.
Proof. unfold Equation2734. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff74_inst, reff74_op in H. discriminate H. Qed.

Lemma reff74_not2736 : ~ @Equation2736 Fin3 reff74_inst.
Proof. unfold Equation2736. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff74_inst, reff74_op in H. discriminate H. Qed.

Lemma reff74_not2737 : ~ @Equation2737 Fin3 reff74_inst.
Proof. unfold Equation2737. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff74_inst, reff74_op in H. discriminate H. Qed.

Lemma reff74_not2743 : ~ @Equation2743 Fin3 reff74_inst.
Proof. unfold Equation2743. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff74_inst, reff74_op in H. discriminate H. Qed.

Lemma reff74_not2744 : ~ @Equation2744 Fin3 reff74_inst.
Proof. unfold Equation2744. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff74_inst, reff74_op in H. discriminate H. Qed.

Lemma reff74_not2746 : ~ @Equation2746 Fin3 reff74_inst.
Proof. unfold Equation2746. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff74_inst, reff74_op in H. discriminate H. Qed.

Lemma reff74_not2848 : ~ @Equation2848 Fin3 reff74_inst.
Proof. unfold Equation2848. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff74_inst, reff74_op in H. discriminate H. Qed.

Lemma reff74_not2849 : ~ @Equation2849 Fin3 reff74_inst.
Proof. unfold Equation2849. intro H. specialize (H F3_2 F3_1). unfold magma_op, reff74_inst, reff74_op in H. discriminate H. Qed.

Lemma reff74_not2850 : ~ @Equation2850 Fin3 reff74_inst.
Proof. unfold Equation2850. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff74_inst, reff74_op in H. discriminate H. Qed.

Lemma reff74_not2853 : ~ @Equation2853 Fin3 reff74_inst.
Proof. unfold Equation2853. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff74_inst, reff74_op in H. discriminate H. Qed.

Lemma reff74_not2855 : ~ @Equation2855 Fin3 reff74_inst.
Proof. unfold Equation2855. intro H. specialize (H F3_2 F3_1). unfold magma_op, reff74_inst, reff74_op in H. discriminate H. Qed.

Lemma reff74_not2856 : ~ @Equation2856 Fin3 reff74_inst.
Proof. unfold Equation2856. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff74_inst, reff74_op in H. discriminate H. Qed.

Lemma reff74_not2863 : ~ @Equation2863 Fin3 reff74_inst.
Proof. unfold Equation2863. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff74_inst, reff74_op in H. discriminate H. Qed.

Lemma reff74_not2865 : ~ @Equation2865 Fin3 reff74_inst.
Proof. unfold Equation2865. intro H. specialize (H F3_2 F3_1). unfold magma_op, reff74_inst, reff74_op in H. discriminate H. Qed.

Lemma reff74_not2866 : ~ @Equation2866 Fin3 reff74_inst.
Proof. unfold Equation2866. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff74_inst, reff74_op in H. discriminate H. Qed.

Lemma reff74_not2872 : ~ @Equation2872 Fin3 reff74_inst.
Proof. unfold Equation2872. intro H. specialize (H F3_2 F3_1). unfold magma_op, reff74_inst, reff74_op in H. discriminate H. Qed.

Lemma reff74_not2873 : ~ @Equation2873 Fin3 reff74_inst.
Proof. unfold Equation2873. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff74_inst, reff74_op in H. discriminate H. Qed.

Lemma reff74_not2875 : ~ @Equation2875 Fin3 reff74_inst.
Proof. unfold Equation2875. intro H. specialize (H F3_2 F3_1). unfold magma_op, reff74_inst, reff74_op in H. discriminate H. Qed.

Lemma reff74_not2876 : ~ @Equation2876 Fin3 reff74_inst.
Proof. unfold Equation2876. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff74_inst, reff74_op in H. discriminate H. Qed.

Lemma reff74_not2899 : ~ @Equation2899 Fin3 reff74_inst.
Proof. unfold Equation2899. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff74_inst, reff74_op in H. discriminate H. Qed.

Lemma reff74_not2900 : ~ @Equation2900 Fin3 reff74_inst.
Proof. unfold Equation2900. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff74_inst, reff74_op in H. discriminate H. Qed.

Lemma reff74_not2902 : ~ @Equation2902 Fin3 reff74_inst.
Proof. unfold Equation2902. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff74_inst, reff74_op in H. discriminate H. Qed.

Lemma reff74_not2903 : ~ @Equation2903 Fin3 reff74_inst.
Proof. unfold Equation2903. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff74_inst, reff74_op in H. discriminate H. Qed.

Lemma reff74_not2909 : ~ @Equation2909 Fin3 reff74_inst.
Proof. unfold Equation2909. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff74_inst, reff74_op in H. discriminate H. Qed.

Lemma reff74_not2910 : ~ @Equation2910 Fin3 reff74_inst.
Proof. unfold Equation2910. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff74_inst, reff74_op in H. discriminate H. Qed.

Lemma reff74_not2912 : ~ @Equation2912 Fin3 reff74_inst.
Proof. unfold Equation2912. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff74_inst, reff74_op in H. discriminate H. Qed.

Lemma reff74_not2913 : ~ @Equation2913 Fin3 reff74_inst.
Proof. unfold Equation2913. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff74_inst, reff74_op in H. discriminate H. Qed.

Lemma reff74_not2936 : ~ @Equation2936 Fin3 reff74_inst.
Proof. unfold Equation2936. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff74_inst, reff74_op in H. discriminate H. Qed.

Lemma reff74_not2937 : ~ @Equation2937 Fin3 reff74_inst.
Proof. unfold Equation2937. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff74_inst, reff74_op in H. discriminate H. Qed.

Lemma reff74_not2939 : ~ @Equation2939 Fin3 reff74_inst.
Proof. unfold Equation2939. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff74_inst, reff74_op in H. discriminate H. Qed.

Lemma reff74_not2940 : ~ @Equation2940 Fin3 reff74_inst.
Proof. unfold Equation2940. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff74_inst, reff74_op in H. discriminate H. Qed.

Lemma reff74_not2946 : ~ @Equation2946 Fin3 reff74_inst.
Proof. unfold Equation2946. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff74_inst, reff74_op in H. discriminate H. Qed.

Lemma reff74_not2947 : ~ @Equation2947 Fin3 reff74_inst.
Proof. unfold Equation2947. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff74_inst, reff74_op in H. discriminate H. Qed.

Lemma reff74_not2949 : ~ @Equation2949 Fin3 reff74_inst.
Proof. unfold Equation2949. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff74_inst, reff74_op in H. discriminate H. Qed.

Lemma reff74_not3051 : ~ @Equation3051 Fin3 reff74_inst.
Proof. unfold Equation3051. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff74_inst, reff74_op in H. discriminate H. Qed.

Lemma reff74_not3052 : ~ @Equation3052 Fin3 reff74_inst.
Proof. unfold Equation3052. intro H. specialize (H F3_2 F3_1). unfold magma_op, reff74_inst, reff74_op in H. discriminate H. Qed.

Lemma reff74_not3053 : ~ @Equation3053 Fin3 reff74_inst.
Proof. unfold Equation3053. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff74_inst, reff74_op in H. discriminate H. Qed.

Lemma reff74_not3055 : ~ @Equation3055 Fin3 reff74_inst.
Proof. unfold Equation3055. intro H. specialize (H F3_2 F3_1). unfold magma_op, reff74_inst, reff74_op in H. discriminate H. Qed.

Lemma reff74_not3056 : ~ @Equation3056 Fin3 reff74_inst.
Proof. unfold Equation3056. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff74_inst, reff74_op in H. discriminate H. Qed.

Lemma reff74_not3058 : ~ @Equation3058 Fin3 reff74_inst.
Proof. unfold Equation3058. intro H. specialize (H F3_2 F3_1). unfold magma_op, reff74_inst, reff74_op in H. discriminate H. Qed.

Lemma reff74_not3059 : ~ @Equation3059 Fin3 reff74_inst.
Proof. unfold Equation3059. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff74_inst, reff74_op in H. discriminate H. Qed.

Lemma reff74_not3065 : ~ @Equation3065 Fin3 reff74_inst.
Proof. unfold Equation3065. intro H. specialize (H F3_2 F3_1). unfold magma_op, reff74_inst, reff74_op in H. discriminate H. Qed.

Lemma reff74_not3066 : ~ @Equation3066 Fin3 reff74_inst.
Proof. unfold Equation3066. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff74_inst, reff74_op in H. discriminate H. Qed.

Lemma reff74_not3068 : ~ @Equation3068 Fin3 reff74_inst.
Proof. unfold Equation3068. intro H. specialize (H F3_2 F3_1). unfold magma_op, reff74_inst, reff74_op in H. discriminate H. Qed.

Lemma reff74_not3069 : ~ @Equation3069 Fin3 reff74_inst.
Proof. unfold Equation3069. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff74_inst, reff74_op in H. discriminate H. Qed.

Lemma reff74_not3075 : ~ @Equation3075 Fin3 reff74_inst.
Proof. unfold Equation3075. intro H. specialize (H F3_2 F3_1). unfold magma_op, reff74_inst, reff74_op in H. discriminate H. Qed.

Lemma reff74_not3076 : ~ @Equation3076 Fin3 reff74_inst.
Proof. unfold Equation3076. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff74_inst, reff74_op in H. discriminate H. Qed.

Lemma reff74_not3078 : ~ @Equation3078 Fin3 reff74_inst.
Proof. unfold Equation3078. intro H. specialize (H F3_2 F3_1). unfold magma_op, reff74_inst, reff74_op in H. discriminate H. Qed.

Lemma reff74_not3079 : ~ @Equation3079 Fin3 reff74_inst.
Proof. unfold Equation3079. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff74_inst, reff74_op in H. discriminate H. Qed.

Lemma reff74_not3102 : ~ @Equation3102 Fin3 reff74_inst.
Proof. unfold Equation3102. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff74_inst, reff74_op in H. discriminate H. Qed.

Lemma reff74_not3103 : ~ @Equation3103 Fin3 reff74_inst.
Proof. unfold Equation3103. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff74_inst, reff74_op in H. discriminate H. Qed.

Lemma reff74_not3105 : ~ @Equation3105 Fin3 reff74_inst.
Proof. unfold Equation3105. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff74_inst, reff74_op in H. discriminate H. Qed.

Lemma reff74_not3106 : ~ @Equation3106 Fin3 reff74_inst.
Proof. unfold Equation3106. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff74_inst, reff74_op in H. discriminate H. Qed.

Lemma reff74_not3112 : ~ @Equation3112 Fin3 reff74_inst.
Proof. unfold Equation3112. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff74_inst, reff74_op in H. discriminate H. Qed.

Lemma reff74_not3113 : ~ @Equation3113 Fin3 reff74_inst.
Proof. unfold Equation3113. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff74_inst, reff74_op in H. discriminate H. Qed.

Lemma reff74_not3115 : ~ @Equation3115 Fin3 reff74_inst.
Proof. unfold Equation3115. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff74_inst, reff74_op in H. discriminate H. Qed.

Lemma reff74_not3116 : ~ @Equation3116 Fin3 reff74_inst.
Proof. unfold Equation3116. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff74_inst, reff74_op in H. discriminate H. Qed.

Lemma reff74_not3139 : ~ @Equation3139 Fin3 reff74_inst.
Proof. unfold Equation3139. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff74_inst, reff74_op in H. discriminate H. Qed.

Lemma reff74_not3140 : ~ @Equation3140 Fin3 reff74_inst.
Proof. unfold Equation3140. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff74_inst, reff74_op in H. discriminate H. Qed.

Lemma reff74_not3142 : ~ @Equation3142 Fin3 reff74_inst.
Proof. unfold Equation3142. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff74_inst, reff74_op in H. discriminate H. Qed.

Lemma reff74_not3143 : ~ @Equation3143 Fin3 reff74_inst.
Proof. unfold Equation3143. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff74_inst, reff74_op in H. discriminate H. Qed.

Lemma reff74_not3149 : ~ @Equation3149 Fin3 reff74_inst.
Proof. unfold Equation3149. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff74_inst, reff74_op in H. discriminate H. Qed.

Lemma reff74_not3150 : ~ @Equation3150 Fin3 reff74_inst.
Proof. unfold Equation3150. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff74_inst, reff74_op in H. discriminate H. Qed.

Lemma reff74_not3152 : ~ @Equation3152 Fin3 reff74_inst.
Proof. unfold Equation3152. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff74_inst, reff74_op in H. discriminate H. Qed.

Lemma reff74_not3254 : ~ @Equation3254 Fin3 reff74_inst.
Proof. unfold Equation3254. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff74_inst, reff74_op in H. discriminate H. Qed.

Lemma reff74_not3255 : ~ @Equation3255 Fin3 reff74_inst.
Proof. unfold Equation3255. intro H. specialize (H F3_1 F3_2). unfold magma_op, reff74_inst, reff74_op in H. discriminate H. Qed.

Lemma reff74_not3256 : ~ @Equation3256 Fin3 reff74_inst.
Proof. unfold Equation3256. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff74_inst, reff74_op in H. discriminate H. Qed.

Lemma reff74_not3258 : ~ @Equation3258 Fin3 reff74_inst.
Proof. unfold Equation3258. intro H. specialize (H F3_1 F3_2). unfold magma_op, reff74_inst, reff74_op in H. discriminate H. Qed.

Lemma reff74_not3259 : ~ @Equation3259 Fin3 reff74_inst.
Proof. unfold Equation3259. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff74_inst, reff74_op in H. discriminate H. Qed.

Lemma reff74_not3261 : ~ @Equation3261 Fin3 reff74_inst.
Proof. unfold Equation3261. intro H. specialize (H F3_1 F3_2). unfold magma_op, reff74_inst, reff74_op in H. discriminate H. Qed.

Lemma reff74_not3262 : ~ @Equation3262 Fin3 reff74_inst.
Proof. unfold Equation3262. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff74_inst, reff74_op in H. discriminate H. Qed.

Lemma reff74_not3268 : ~ @Equation3268 Fin3 reff74_inst.
Proof. unfold Equation3268. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff74_inst, reff74_op in H. discriminate H. Qed.

Lemma reff74_not3269 : ~ @Equation3269 Fin3 reff74_inst.
Proof. unfold Equation3269. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff74_inst, reff74_op in H. discriminate H. Qed.

Lemma reff74_not3271 : ~ @Equation3271 Fin3 reff74_inst.
Proof. unfold Equation3271. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff74_inst, reff74_op in H. discriminate H. Qed.

Lemma reff74_not3272 : ~ @Equation3272 Fin3 reff74_inst.
Proof. unfold Equation3272. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff74_inst, reff74_op in H. discriminate H. Qed.

Lemma reff74_not3278 : ~ @Equation3278 Fin3 reff74_inst.
Proof. unfold Equation3278. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff74_inst, reff74_op in H. discriminate H. Qed.

Lemma reff74_not3279 : ~ @Equation3279 Fin3 reff74_inst.
Proof. unfold Equation3279. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff74_inst, reff74_op in H. discriminate H. Qed.

Lemma reff74_not3281 : ~ @Equation3281 Fin3 reff74_inst.
Proof. unfold Equation3281. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff74_inst, reff74_op in H. discriminate H. Qed.

Lemma reff74_not3306 : ~ @Equation3306 Fin3 reff74_inst.
Proof. unfold Equation3306. intro H. specialize (H F3_2 F3_1). unfold magma_op, reff74_inst, reff74_op in H. discriminate H. Qed.

Lemma reff74_not3308 : ~ @Equation3308 Fin3 reff74_inst.
Proof. unfold Equation3308. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff74_inst, reff74_op in H. discriminate H. Qed.

Lemma reff74_not3309 : ~ @Equation3309 Fin3 reff74_inst.
Proof. unfold Equation3309. intro H. specialize (H F3_2 F3_1). unfold magma_op, reff74_inst, reff74_op in H. discriminate H. Qed.

Lemma reff74_not3315 : ~ @Equation3315 Fin3 reff74_inst.
Proof. unfold Equation3315. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff74_inst, reff74_op in H. discriminate H. Qed.

Lemma reff74_not3316 : ~ @Equation3316 Fin3 reff74_inst.
Proof. unfold Equation3316. intro H. specialize (H F3_2 F3_1). unfold magma_op, reff74_inst, reff74_op in H. discriminate H. Qed.

Lemma reff74_not3318 : ~ @Equation3318 Fin3 reff74_inst.
Proof. unfold Equation3318. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff74_inst, reff74_op in H. discriminate H. Qed.

Lemma reff74_not3342 : ~ @Equation3342 Fin3 reff74_inst.
Proof. unfold Equation3342. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff74_inst, reff74_op in H. discriminate H. Qed.

Lemma reff74_not3343 : ~ @Equation3343 Fin3 reff74_inst.
Proof. unfold Equation3343. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff74_inst, reff74_op in H. discriminate H. Qed.

Lemma reff74_not3345 : ~ @Equation3345 Fin3 reff74_inst.
Proof. unfold Equation3345. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff74_inst, reff74_op in H. discriminate H. Qed.

Lemma reff74_not3346 : ~ @Equation3346 Fin3 reff74_inst.
Proof. unfold Equation3346. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff74_inst, reff74_op in H. discriminate H. Qed.

Lemma reff74_not3352 : ~ @Equation3352 Fin3 reff74_inst.
Proof. unfold Equation3352. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff74_inst, reff74_op in H. discriminate H. Qed.

Lemma reff74_not3353 : ~ @Equation3353 Fin3 reff74_inst.
Proof. unfold Equation3353. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff74_inst, reff74_op in H. discriminate H. Qed.

Lemma reff74_not3457 : ~ @Equation3457 Fin3 reff74_inst.
Proof. unfold Equation3457. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff74_inst, reff74_op in H. discriminate H. Qed.

Lemma reff74_not3459 : ~ @Equation3459 Fin3 reff74_inst.
Proof. unfold Equation3459. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff74_inst, reff74_op in H. discriminate H. Qed.

Lemma reff74_not3462 : ~ @Equation3462 Fin3 reff74_inst.
Proof. unfold Equation3462. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff74_inst, reff74_op in H. discriminate H. Qed.

Lemma reff74_not3464 : ~ @Equation3464 Fin3 reff74_inst.
Proof. unfold Equation3464. intro H. specialize (H F3_1 F3_2). unfold magma_op, reff74_inst, reff74_op in H. discriminate H. Qed.

Lemma reff74_not3465 : ~ @Equation3465 Fin3 reff74_inst.
Proof. unfold Equation3465. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff74_inst, reff74_op in H. discriminate H. Qed.

Lemma reff74_not3472 : ~ @Equation3472 Fin3 reff74_inst.
Proof. unfold Equation3472. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff74_inst, reff74_op in H. discriminate H. Qed.

Lemma reff74_not3474 : ~ @Equation3474 Fin3 reff74_inst.
Proof. unfold Equation3474. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff74_inst, reff74_op in H. discriminate H. Qed.

Lemma reff74_not3475 : ~ @Equation3475 Fin3 reff74_inst.
Proof. unfold Equation3475. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff74_inst, reff74_op in H. discriminate H. Qed.

Lemma reff74_not3481 : ~ @Equation3481 Fin3 reff74_inst.
Proof. unfold Equation3481. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff74_inst, reff74_op in H. discriminate H. Qed.

Lemma reff74_not3482 : ~ @Equation3482 Fin3 reff74_inst.
Proof. unfold Equation3482. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff74_inst, reff74_op in H. discriminate H. Qed.

Lemma reff74_not3484 : ~ @Equation3484 Fin3 reff74_inst.
Proof. unfold Equation3484. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff74_inst, reff74_op in H. discriminate H. Qed.

Lemma reff74_not3509 : ~ @Equation3509 Fin3 reff74_inst.
Proof. unfold Equation3509. intro H. specialize (H F3_2 F3_1). unfold magma_op, reff74_inst, reff74_op in H. discriminate H. Qed.

Lemma reff74_not3511 : ~ @Equation3511 Fin3 reff74_inst.
Proof. unfold Equation3511. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff74_inst, reff74_op in H. discriminate H. Qed.

Lemma reff74_not3518 : ~ @Equation3518 Fin3 reff74_inst.
Proof. unfold Equation3518. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff74_inst, reff74_op in H. discriminate H. Qed.

Lemma reff74_not3521 : ~ @Equation3521 Fin3 reff74_inst.
Proof. unfold Equation3521. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff74_inst, reff74_op in H. discriminate H. Qed.

Lemma reff74_not3545 : ~ @Equation3545 Fin3 reff74_inst.
Proof. unfold Equation3545. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff74_inst, reff74_op in H. discriminate H. Qed.

Lemma reff74_not3546 : ~ @Equation3546 Fin3 reff74_inst.
Proof. unfold Equation3546. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff74_inst, reff74_op in H. discriminate H. Qed.

Lemma reff74_not3548 : ~ @Equation3548 Fin3 reff74_inst.
Proof. unfold Equation3548. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff74_inst, reff74_op in H. discriminate H. Qed.

Lemma reff74_not3549 : ~ @Equation3549 Fin3 reff74_inst.
Proof. unfold Equation3549. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff74_inst, reff74_op in H. discriminate H. Qed.

Lemma reff74_not3555 : ~ @Equation3555 Fin3 reff74_inst.
Proof. unfold Equation3555. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff74_inst, reff74_op in H. discriminate H. Qed.

Lemma reff74_not3556 : ~ @Equation3556 Fin3 reff74_inst.
Proof. unfold Equation3556. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff74_inst, reff74_op in H. discriminate H. Qed.

Lemma reff74_not3558 : ~ @Equation3558 Fin3 reff74_inst.
Proof. unfold Equation3558. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff74_inst, reff74_op in H. discriminate H. Qed.

Lemma reff74_not3660 : ~ @Equation3660 Fin3 reff74_inst.
Proof. unfold Equation3660. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff74_inst, reff74_op in H. discriminate H. Qed.

Lemma reff74_not3661 : ~ @Equation3661 Fin3 reff74_inst.
Proof. unfold Equation3661. intro H. specialize (H F3_1 F3_2). unfold magma_op, reff74_inst, reff74_op in H. discriminate H. Qed.

Lemma reff74_not3662 : ~ @Equation3662 Fin3 reff74_inst.
Proof. unfold Equation3662. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff74_inst, reff74_op in H. discriminate H. Qed.

Lemma reff74_not3664 : ~ @Equation3664 Fin3 reff74_inst.
Proof. unfold Equation3664. intro H. specialize (H F3_2 F3_1). unfold magma_op, reff74_inst, reff74_op in H. discriminate H. Qed.

Lemma reff74_not3665 : ~ @Equation3665 Fin3 reff74_inst.
Proof. unfold Equation3665. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff74_inst, reff74_op in H. discriminate H. Qed.

Lemma reff74_not3667 : ~ @Equation3667 Fin3 reff74_inst.
Proof. unfold Equation3667. intro H. specialize (H F3_1 F3_2). unfold magma_op, reff74_inst, reff74_op in H. discriminate H. Qed.

Lemma reff74_not3668 : ~ @Equation3668 Fin3 reff74_inst.
Proof. unfold Equation3668. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff74_inst, reff74_op in H. discriminate H. Qed.

Lemma reff74_not3674 : ~ @Equation3674 Fin3 reff74_inst.
Proof. unfold Equation3674. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff74_inst, reff74_op in H. discriminate H. Qed.

Lemma reff74_not3675 : ~ @Equation3675 Fin3 reff74_inst.
Proof. unfold Equation3675. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff74_inst, reff74_op in H. discriminate H. Qed.

Lemma reff74_not3677 : ~ @Equation3677 Fin3 reff74_inst.
Proof. unfold Equation3677. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff74_inst, reff74_op in H. discriminate H. Qed.

Lemma reff74_not3678 : ~ @Equation3678 Fin3 reff74_inst.
Proof. unfold Equation3678. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff74_inst, reff74_op in H. discriminate H. Qed.

Lemma reff74_not3684 : ~ @Equation3684 Fin3 reff74_inst.
Proof. unfold Equation3684. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff74_inst, reff74_op in H. discriminate H. Qed.

Lemma reff74_not3685 : ~ @Equation3685 Fin3 reff74_inst.
Proof. unfold Equation3685. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff74_inst, reff74_op in H. discriminate H. Qed.

Lemma reff74_not3687 : ~ @Equation3687 Fin3 reff74_inst.
Proof. unfold Equation3687. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff74_inst, reff74_op in H. discriminate H. Qed.

Lemma reff74_not3712 : ~ @Equation3712 Fin3 reff74_inst.
Proof. unfold Equation3712. intro H. specialize (H F3_2 F3_1). unfold magma_op, reff74_inst, reff74_op in H. discriminate H. Qed.

Lemma reff74_not3714 : ~ @Equation3714 Fin3 reff74_inst.
Proof. unfold Equation3714. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff74_inst, reff74_op in H. discriminate H. Qed.

Lemma reff74_not3721 : ~ @Equation3721 Fin3 reff74_inst.
Proof. unfold Equation3721. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff74_inst, reff74_op in H. discriminate H. Qed.

Lemma reff74_not3724 : ~ @Equation3724 Fin3 reff74_inst.
Proof. unfold Equation3724. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff74_inst, reff74_op in H. discriminate H. Qed.

Lemma reff74_not3725 : ~ @Equation3725 Fin3 reff74_inst.
Proof. unfold Equation3725. intro H. specialize (H F3_2 F3_1). unfold magma_op, reff74_inst, reff74_op in H. discriminate H. Qed.

Lemma reff74_not3748 : ~ @Equation3748 Fin3 reff74_inst.
Proof. unfold Equation3748. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff74_inst, reff74_op in H. discriminate H. Qed.

Lemma reff74_not3749 : ~ @Equation3749 Fin3 reff74_inst.
Proof. unfold Equation3749. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff74_inst, reff74_op in H. discriminate H. Qed.

Lemma reff74_not3751 : ~ @Equation3751 Fin3 reff74_inst.
Proof. unfold Equation3751. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff74_inst, reff74_op in H. discriminate H. Qed.

Lemma reff74_not3752 : ~ @Equation3752 Fin3 reff74_inst.
Proof. unfold Equation3752. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff74_inst, reff74_op in H. discriminate H. Qed.

Lemma reff74_not3758 : ~ @Equation3758 Fin3 reff74_inst.
Proof. unfold Equation3758. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff74_inst, reff74_op in H. discriminate H. Qed.

Lemma reff74_not3759 : ~ @Equation3759 Fin3 reff74_inst.
Proof. unfold Equation3759. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff74_inst, reff74_op in H. discriminate H. Qed.

Lemma reff74_not3761 : ~ @Equation3761 Fin3 reff74_inst.
Proof. unfold Equation3761. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff74_inst, reff74_op in H. discriminate H. Qed.

Lemma reff74_not3865 : ~ @Equation3865 Fin3 reff74_inst.
Proof. unfold Equation3865. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff74_inst, reff74_op in H. discriminate H. Qed.

Lemma reff74_not3868 : ~ @Equation3868 Fin3 reff74_inst.
Proof. unfold Equation3868. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff74_inst, reff74_op in H. discriminate H. Qed.

Lemma reff74_not3870 : ~ @Equation3870 Fin3 reff74_inst.
Proof. unfold Equation3870. intro H. specialize (H F3_2 F3_1). unfold magma_op, reff74_inst, reff74_op in H. discriminate H. Qed.

Lemma reff74_not3871 : ~ @Equation3871 Fin3 reff74_inst.
Proof. unfold Equation3871. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff74_inst, reff74_op in H. discriminate H. Qed.

Lemma reff74_not3877 : ~ @Equation3877 Fin3 reff74_inst.
Proof. unfold Equation3877. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff74_inst, reff74_op in H. discriminate H. Qed.

Lemma reff74_not3878 : ~ @Equation3878 Fin3 reff74_inst.
Proof. unfold Equation3878. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff74_inst, reff74_op in H. discriminate H. Qed.

Lemma reff74_not3880 : ~ @Equation3880 Fin3 reff74_inst.
Proof. unfold Equation3880. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff74_inst, reff74_op in H. discriminate H. Qed.

Lemma reff74_not3881 : ~ @Equation3881 Fin3 reff74_inst.
Proof. unfold Equation3881. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff74_inst, reff74_op in H. discriminate H. Qed.

Lemma reff74_not3887 : ~ @Equation3887 Fin3 reff74_inst.
Proof. unfold Equation3887. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff74_inst, reff74_op in H. discriminate H. Qed.

Lemma reff74_not3888 : ~ @Equation3888 Fin3 reff74_inst.
Proof. unfold Equation3888. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff74_inst, reff74_op in H. discriminate H. Qed.

Lemma reff74_not3890 : ~ @Equation3890 Fin3 reff74_inst.
Proof. unfold Equation3890. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff74_inst, reff74_op in H. discriminate H. Qed.

Lemma reff74_not3917 : ~ @Equation3917 Fin3 reff74_inst.
Proof. unfold Equation3917. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff74_inst, reff74_op in H. discriminate H. Qed.

Lemma reff74_not3924 : ~ @Equation3924 Fin3 reff74_inst.
Proof. unfold Equation3924. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff74_inst, reff74_op in H. discriminate H. Qed.

Lemma reff74_not3927 : ~ @Equation3927 Fin3 reff74_inst.
Proof. unfold Equation3927. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff74_inst, reff74_op in H. discriminate H. Qed.

Lemma reff74_not3928 : ~ @Equation3928 Fin3 reff74_inst.
Proof. unfold Equation3928. intro H. specialize (H F3_2 F3_1). unfold magma_op, reff74_inst, reff74_op in H. discriminate H. Qed.

Lemma reff74_not3951 : ~ @Equation3951 Fin3 reff74_inst.
Proof. unfold Equation3951. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff74_inst, reff74_op in H. discriminate H. Qed.

Lemma reff74_not3952 : ~ @Equation3952 Fin3 reff74_inst.
Proof. unfold Equation3952. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff74_inst, reff74_op in H. discriminate H. Qed.

Lemma reff74_not3954 : ~ @Equation3954 Fin3 reff74_inst.
Proof. unfold Equation3954. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff74_inst, reff74_op in H. discriminate H. Qed.

Lemma reff74_not3955 : ~ @Equation3955 Fin3 reff74_inst.
Proof. unfold Equation3955. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff74_inst, reff74_op in H. discriminate H. Qed.

Lemma reff74_not3961 : ~ @Equation3961 Fin3 reff74_inst.
Proof. unfold Equation3961. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff74_inst, reff74_op in H. discriminate H. Qed.

Lemma reff74_not3962 : ~ @Equation3962 Fin3 reff74_inst.
Proof. unfold Equation3962. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff74_inst, reff74_op in H. discriminate H. Qed.

Lemma reff74_not3964 : ~ @Equation3964 Fin3 reff74_inst.
Proof. unfold Equation3964. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff74_inst, reff74_op in H. discriminate H. Qed.

Lemma reff74_not4066 : ~ @Equation4066 Fin3 reff74_inst.
Proof. unfold Equation4066. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff74_inst, reff74_op in H. discriminate H. Qed.

Lemma reff74_not4067 : ~ @Equation4067 Fin3 reff74_inst.
Proof. unfold Equation4067. intro H. specialize (H F3_2 F3_1). unfold magma_op, reff74_inst, reff74_op in H. discriminate H. Qed.

Lemma reff74_not4068 : ~ @Equation4068 Fin3 reff74_inst.
Proof. unfold Equation4068. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff74_inst, reff74_op in H. discriminate H. Qed.

Lemma reff74_not4070 : ~ @Equation4070 Fin3 reff74_inst.
Proof. unfold Equation4070. intro H. specialize (H F3_2 F3_1). unfold magma_op, reff74_inst, reff74_op in H. discriminate H. Qed.

Lemma reff74_not4071 : ~ @Equation4071 Fin3 reff74_inst.
Proof. unfold Equation4071. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff74_inst, reff74_op in H. discriminate H. Qed.

Lemma reff74_not4073 : ~ @Equation4073 Fin3 reff74_inst.
Proof. unfold Equation4073. intro H. specialize (H F3_2 F3_1). unfold magma_op, reff74_inst, reff74_op in H. discriminate H. Qed.

Lemma reff74_not4074 : ~ @Equation4074 Fin3 reff74_inst.
Proof. unfold Equation4074. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff74_inst, reff74_op in H. discriminate H. Qed.

Lemma reff74_not4080 : ~ @Equation4080 Fin3 reff74_inst.
Proof. unfold Equation4080. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff74_inst, reff74_op in H. discriminate H. Qed.

Lemma reff74_not4081 : ~ @Equation4081 Fin3 reff74_inst.
Proof. unfold Equation4081. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff74_inst, reff74_op in H. discriminate H. Qed.

Lemma reff74_not4083 : ~ @Equation4083 Fin3 reff74_inst.
Proof. unfold Equation4083. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff74_inst, reff74_op in H. discriminate H. Qed.

Lemma reff74_not4084 : ~ @Equation4084 Fin3 reff74_inst.
Proof. unfold Equation4084. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff74_inst, reff74_op in H. discriminate H. Qed.

Lemma reff74_not4090 : ~ @Equation4090 Fin3 reff74_inst.
Proof. unfold Equation4090. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff74_inst, reff74_op in H. discriminate H. Qed.

Lemma reff74_not4091 : ~ @Equation4091 Fin3 reff74_inst.
Proof. unfold Equation4091. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff74_inst, reff74_op in H. discriminate H. Qed.

Lemma reff74_not4093 : ~ @Equation4093 Fin3 reff74_inst.
Proof. unfold Equation4093. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff74_inst, reff74_op in H. discriminate H. Qed.

Lemma reff74_not4120 : ~ @Equation4120 Fin3 reff74_inst.
Proof. unfold Equation4120. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff74_inst, reff74_op in H. discriminate H. Qed.

Lemma reff74_not4121 : ~ @Equation4121 Fin3 reff74_inst.
Proof. unfold Equation4121. intro H. specialize (H F3_2 F3_1). unfold magma_op, reff74_inst, reff74_op in H. discriminate H. Qed.

Lemma reff74_not4127 : ~ @Equation4127 Fin3 reff74_inst.
Proof. unfold Equation4127. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff74_inst, reff74_op in H. discriminate H. Qed.

Lemma reff74_not4128 : ~ @Equation4128 Fin3 reff74_inst.
Proof. unfold Equation4128. intro H. specialize (H F3_2 F3_1). unfold magma_op, reff74_inst, reff74_op in H. discriminate H. Qed.

Lemma reff74_not4130 : ~ @Equation4130 Fin3 reff74_inst.
Proof. unfold Equation4130. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff74_inst, reff74_op in H. discriminate H. Qed.

Lemma reff74_not4131 : ~ @Equation4131 Fin3 reff74_inst.
Proof. unfold Equation4131. intro H. specialize (H F3_2 F3_1). unfold magma_op, reff74_inst, reff74_op in H. discriminate H. Qed.

Lemma reff74_not4155 : ~ @Equation4155 Fin3 reff74_inst.
Proof. unfold Equation4155. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff74_inst, reff74_op in H. discriminate H. Qed.

Lemma reff74_not4157 : ~ @Equation4157 Fin3 reff74_inst.
Proof. unfold Equation4157. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff74_inst, reff74_op in H. discriminate H. Qed.

Lemma reff74_not4158 : ~ @Equation4158 Fin3 reff74_inst.
Proof. unfold Equation4158. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff74_inst, reff74_op in H. discriminate H. Qed.

Lemma reff74_not4164 : ~ @Equation4164 Fin3 reff74_inst.
Proof. unfold Equation4164. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff74_inst, reff74_op in H. discriminate H. Qed.

Lemma reff74_not4165 : ~ @Equation4165 Fin3 reff74_inst.
Proof. unfold Equation4165. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff74_inst, reff74_op in H. discriminate H. Qed.

Lemma reff74_not4167 : ~ @Equation4167 Fin3 reff74_inst.
Proof. unfold Equation4167. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff74_inst, reff74_op in H. discriminate H. Qed.

Lemma reff74_not4268 : ~ @Equation4268 Fin3 reff74_inst.
Proof. unfold Equation4268. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff74_inst, reff74_op in H. discriminate H. Qed.

Lemma reff74_not4269 : ~ @Equation4269 Fin3 reff74_inst.
Proof. unfold Equation4269. intro H. specialize (H F3_1 F3_2). unfold magma_op, reff74_inst, reff74_op in H. discriminate H. Qed.

Lemma reff74_not4270 : ~ @Equation4270 Fin3 reff74_inst.
Proof. unfold Equation4270. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff74_inst, reff74_op in H. discriminate H. Qed.

Lemma reff74_not4272 : ~ @Equation4272 Fin3 reff74_inst.
Proof. unfold Equation4272. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff74_inst, reff74_op in H. discriminate H. Qed.

Lemma reff74_not4273 : ~ @Equation4273 Fin3 reff74_inst.
Proof. unfold Equation4273. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff74_inst, reff74_op in H. discriminate H. Qed.

Lemma reff74_not4275 : ~ @Equation4275 Fin3 reff74_inst.
Proof. unfold Equation4275. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff74_inst, reff74_op in H. discriminate H. Qed.

Lemma reff74_not4276 : ~ @Equation4276 Fin3 reff74_inst.
Proof. unfold Equation4276. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff74_inst, reff74_op in H. discriminate H. Qed.

Lemma reff74_not4283 : ~ @Equation4283 Fin3 reff74_inst.
Proof. unfold Equation4283. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff74_inst, reff74_op in H. discriminate H. Qed.

Lemma reff74_not4284 : ~ @Equation4284 Fin3 reff74_inst.
Proof. unfold Equation4284. intro H. specialize (H F3_2 F3_1). unfold magma_op, reff74_inst, reff74_op in H. discriminate H. Qed.

Lemma reff74_not4290 : ~ @Equation4290 Fin3 reff74_inst.
Proof. unfold Equation4290. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff74_inst, reff74_op in H. discriminate H. Qed.

Lemma reff74_not4291 : ~ @Equation4291 Fin3 reff74_inst.
Proof. unfold Equation4291. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff74_inst, reff74_op in H. discriminate H. Qed.

Lemma reff74_not4293 : ~ @Equation4293 Fin3 reff74_inst.
Proof. unfold Equation4293. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff74_inst, reff74_op in H. discriminate H. Qed.

Lemma reff74_not4314 : ~ @Equation4314 Fin3 reff74_inst.
Proof. unfold Equation4314. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff74_inst, reff74_op in H. discriminate H. Qed.

Lemma reff74_not4320 : ~ @Equation4320 Fin3 reff74_inst.
Proof. unfold Equation4320. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff74_inst, reff74_op in H. discriminate H. Qed.

Lemma reff74_not4321 : ~ @Equation4321 Fin3 reff74_inst.
Proof. unfold Equation4321. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff74_inst, reff74_op in H. discriminate H. Qed.

Lemma reff74_not4343 : ~ @Equation4343 Fin3 reff74_inst.
Proof. unfold Equation4343. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff74_inst, reff74_op in H. discriminate H. Qed.

Lemma reff74_not4396 : ~ @Equation4396 Fin3 reff74_inst.
Proof. unfold Equation4396. intro H. specialize (H F3_2 F3_1). unfold magma_op, reff74_inst, reff74_op in H. discriminate H. Qed.

Lemma reff74_not4398 : ~ @Equation4398 Fin3 reff74_inst.
Proof. unfold Equation4398. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff74_inst, reff74_op in H. discriminate H. Qed.

Lemma reff74_not4399 : ~ @Equation4399 Fin3 reff74_inst.
Proof. unfold Equation4399. intro H. specialize (H F3_2 F3_1). unfold magma_op, reff74_inst, reff74_op in H. discriminate H. Qed.

Lemma reff74_not4405 : ~ @Equation4405 Fin3 reff74_inst.
Proof. unfold Equation4405. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff74_inst, reff74_op in H. discriminate H. Qed.

Lemma reff74_not4406 : ~ @Equation4406 Fin3 reff74_inst.
Proof. unfold Equation4406. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff74_inst, reff74_op in H. discriminate H. Qed.

Lemma reff74_not4408 : ~ @Equation4408 Fin3 reff74_inst.
Proof. unfold Equation4408. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff74_inst, reff74_op in H. discriminate H. Qed.

Lemma reff74_not4433 : ~ @Equation4433 Fin3 reff74_inst.
Proof. unfold Equation4433. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff74_inst, reff74_op in H. discriminate H. Qed.

Lemma reff74_not4435 : ~ @Equation4435 Fin3 reff74_inst.
Proof. unfold Equation4435. intro H. specialize (H F3_1 F3_2). unfold magma_op, reff74_inst, reff74_op in H. discriminate H. Qed.

Lemma reff74_not4436 : ~ @Equation4436 Fin3 reff74_inst.
Proof. unfold Equation4436. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff74_inst, reff74_op in H. discriminate H. Qed.

Lemma reff74_not4442 : ~ @Equation4442 Fin3 reff74_inst.
Proof. unfold Equation4442. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff74_inst, reff74_op in H. discriminate H. Qed.

Lemma reff74_not4443 : ~ @Equation4443 Fin3 reff74_inst.
Proof. unfold Equation4443. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff74_inst, reff74_op in H. discriminate H. Qed.

Lemma reff74_not4445 : ~ @Equation4445 Fin3 reff74_inst.
Proof. unfold Equation4445. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff74_inst, reff74_op in H. discriminate H. Qed.

Lemma reff74_not4472 : ~ @Equation4472 Fin3 reff74_inst.
Proof. unfold Equation4472. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff74_inst, reff74_op in H. discriminate H. Qed.

Lemma reff74_not4473 : ~ @Equation4473 Fin3 reff74_inst.
Proof. unfold Equation4473. intro H. specialize (H F3_2 F3_1). unfold magma_op, reff74_inst, reff74_op in H. discriminate H. Qed.

Lemma reff74_not4479 : ~ @Equation4479 Fin3 reff74_inst.
Proof. unfold Equation4479. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff74_inst, reff74_op in H. discriminate H. Qed.

Lemma reff74_not4480 : ~ @Equation4480 Fin3 reff74_inst.
Proof. unfold Equation4480. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff74_inst, reff74_op in H. discriminate H. Qed.

Lemma reff74_not4482 : ~ @Equation4482 Fin3 reff74_inst.
Proof. unfold Equation4482. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff74_inst, reff74_op in H. discriminate H. Qed.

Lemma reff74_not4583 : ~ @Equation4583 Fin3 reff74_inst.
Proof. unfold Equation4583. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff74_inst, reff74_op in H. discriminate H. Qed.

Lemma reff74_not4584 : ~ @Equation4584 Fin3 reff74_inst.
Proof. unfold Equation4584. intro H. specialize (H F3_2 F3_1). unfold magma_op, reff74_inst, reff74_op in H. discriminate H. Qed.

Lemma reff74_not4585 : ~ @Equation4585 Fin3 reff74_inst.
Proof. unfold Equation4585. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff74_inst, reff74_op in H. discriminate H. Qed.

Lemma reff74_not4587 : ~ @Equation4587 Fin3 reff74_inst.
Proof. unfold Equation4587. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff74_inst, reff74_op in H. discriminate H. Qed.

Lemma reff74_not4588 : ~ @Equation4588 Fin3 reff74_inst.
Proof. unfold Equation4588. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff74_inst, reff74_op in H. discriminate H. Qed.

Lemma reff74_not4590 : ~ @Equation4590 Fin3 reff74_inst.
Proof. unfold Equation4590. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff74_inst, reff74_op in H. discriminate H. Qed.

Lemma reff74_not4591 : ~ @Equation4591 Fin3 reff74_inst.
Proof. unfold Equation4591. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff74_inst, reff74_op in H. discriminate H. Qed.

Lemma reff74_not4598 : ~ @Equation4598 Fin3 reff74_inst.
Proof. unfold Equation4598. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff74_inst, reff74_op in H. discriminate H. Qed.

Lemma reff74_not4599 : ~ @Equation4599 Fin3 reff74_inst.
Proof. unfold Equation4599. intro H. specialize (H F3_2 F3_1). unfold magma_op, reff74_inst, reff74_op in H. discriminate H. Qed.

Lemma reff74_not4605 : ~ @Equation4605 Fin3 reff74_inst.
Proof. unfold Equation4605. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff74_inst, reff74_op in H. discriminate H. Qed.

Lemma reff74_not4606 : ~ @Equation4606 Fin3 reff74_inst.
Proof. unfold Equation4606. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff74_inst, reff74_op in H. discriminate H. Qed.

Lemma reff74_not4608 : ~ @Equation4608 Fin3 reff74_inst.
Proof. unfold Equation4608. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff74_inst, reff74_op in H. discriminate H. Qed.

Lemma reff74_not4629 : ~ @Equation4629 Fin3 reff74_inst.
Proof. unfold Equation4629. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff74_inst, reff74_op in H. discriminate H. Qed.

Lemma reff74_not4635 : ~ @Equation4635 Fin3 reff74_inst.
Proof. unfold Equation4635. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff74_inst, reff74_op in H. discriminate H. Qed.

Lemma reff74_not4636 : ~ @Equation4636 Fin3 reff74_inst.
Proof. unfold Equation4636. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff74_inst, reff74_op in H. discriminate H. Qed.

Lemma reff74_not4658 : ~ @Equation4658 Fin3 reff74_inst.
Proof. unfold Equation4658. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff74_inst, reff74_op in H. discriminate H. Qed.

(** ---- reff78 (Fin2) ---- *)

Definition reff78_op (x y : Fin2) : Fin2 :=
  match x, y with
  | F2_0, F2_0 => F2_0 | F2_0, F2_1 => F2_1
  | F2_1, F2_0 => F2_0 | F2_1, F2_1 => F2_0
  end.

#[local] Instance reff78_inst : Magma Fin2 := {| magma_op := reff78_op |}.

Lemma reff78_sat25 : @Equation25 Fin2 reff78_inst.
Proof. unfold Equation25, magma_op, reff78_inst, reff78_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff78_sat31 : @Equation31 Fin2 reff78_inst.
Proof. unfold Equation31, magma_op, reff78_inst, reff78_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff78_sat224 : @Equation224 Fin2 reff78_inst.
Proof. unfold Equation224, magma_op, reff78_inst, reff78_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff78_sat242 : @Equation242 Fin2 reff78_inst.
Proof. unfold Equation242, magma_op, reff78_inst, reff78_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff78_sat246 : @Equation246 Fin2 reff78_inst.
Proof. unfold Equation246, magma_op, reff78_inst, reff78_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff78_sat319 : @Equation319 Fin2 reff78_inst.
Proof. unfold Equation319, magma_op, reff78_inst, reff78_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff78_sat323 : @Equation323 Fin2 reff78_inst.
Proof. unfold Equation323, magma_op, reff78_inst, reff78_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff78_sat1672 : @Equation1672 Fin2 reff78_inst.
Proof. unfold Equation1672, magma_op, reff78_inst, reff78_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff78_sat1724 : @Equation1724 Fin2 reff78_inst.
Proof. unfold Equation1724, magma_op, reff78_inst, reff78_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff78_sat2376 : @Equation2376 Fin2 reff78_inst.
Proof. unfold Equation2376, magma_op, reff78_inst, reff78_op. intros x y z w. destruct x, y, z, w; reflexivity. Qed.

Lemma reff78_sat2420 : @Equation2420 Fin2 reff78_inst.
Proof. unfold Equation2420, magma_op, reff78_inst, reff78_op. intros x y z w. destruct x, y, z, w; reflexivity. Qed.

Lemma reff78_sat2425 : @Equation2425 Fin2 reff78_inst.
Proof. unfold Equation2425, magma_op, reff78_inst, reff78_op. intros x y z w. destruct x, y, z, w; reflexivity. Qed.

Lemma reff78_sat2430 : @Equation2430 Fin2 reff78_inst.
Proof. unfold Equation2430, magma_op, reff78_inst, reff78_op. intros x y z w. destruct x, y, z, w; reflexivity. Qed.

Lemma reff78_sat2536 : @Equation2536 Fin2 reff78_inst.
Proof. unfold Equation2536, magma_op, reff78_inst, reff78_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff78_sat2558 : @Equation2558 Fin2 reff78_inst.
Proof. unfold Equation2558, magma_op, reff78_inst, reff78_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff78_sat2712 : @Equation2712 Fin2 reff78_inst.
Proof. unfold Equation2712, magma_op, reff78_inst, reff78_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff78_sat3093 : @Equation3093 Fin2 reff78_inst.
Proof. unfold Equation3093, magma_op, reff78_inst, reff78_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff78_sat3145 : @Equation3145 Fin2 reff78_inst.
Proof. unfold Equation3145, magma_op, reff78_inst, reff78_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff78_sat3180 : @Equation3180 Fin2 reff78_inst.
Proof. unfold Equation3180, magma_op, reff78_inst, reff78_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff78_sat3197 : @Equation3197 Fin2 reff78_inst.
Proof. unfold Equation3197, magma_op, reff78_inst, reff78_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff78_sat3289 : @Equation3289 Fin2 reff78_inst.
Proof. unfold Equation3289, magma_op, reff78_inst, reff78_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff78_sat3489 : @Equation3489 Fin2 reff78_inst.
Proof. unfold Equation3489, magma_op, reff78_inst, reff78_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff78_sat3529 : @Equation3529 Fin2 reff78_inst.
Proof. unfold Equation3529, magma_op, reff78_inst, reff78_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff78_sat3769 : @Equation3769 Fin2 reff78_inst.
Proof. unfold Equation3769, magma_op, reff78_inst, reff78_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff78_sat3786 : @Equation3786 Fin2 reff78_inst.
Proof. unfold Equation3786, magma_op, reff78_inst, reff78_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff78_sat4105 : @Equation4105 Fin2 reff78_inst.
Proof. unfold Equation4105, magma_op, reff78_inst, reff78_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff78_sat4131 : @Equation4131 Fin2 reff78_inst.
Proof. unfold Equation4131, magma_op, reff78_inst, reff78_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff78_sat4175 : @Equation4175 Fin2 reff78_inst.
Proof. unfold Equation4175, magma_op, reff78_inst, reff78_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff78_sat4362 : @Equation4362 Fin2 reff78_inst.
Proof. unfold Equation4362, magma_op, reff78_inst, reff78_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff78_sat4611 : @Equation4611 Fin2 reff78_inst.
Proof. unfold Equation4611, magma_op, reff78_inst, reff78_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff78_sat4658 : @Equation4658 Fin2 reff78_inst.
Proof. unfold Equation4658, magma_op, reff78_inst, reff78_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff78_not47 : ~ @Equation47 Fin2 reff78_inst.
Proof. unfold Equation47. intro H. specialize (H F2_1). unfold magma_op, reff78_inst, reff78_op in H. discriminate H. Qed.

Lemma reff78_not99 : ~ @Equation99 Fin2 reff78_inst.
Proof. unfold Equation99. intro H. specialize (H F2_1). unfold magma_op, reff78_inst, reff78_op in H. discriminate H. Qed.

Lemma reff78_not151 : ~ @Equation151 Fin2 reff78_inst.
Proof. unfold Equation151. intro H. specialize (H F2_1). unfold magma_op, reff78_inst, reff78_op in H. discriminate H. Qed.

Lemma reff78_not206 : ~ @Equation206 Fin2 reff78_inst.
Proof. unfold Equation206. intro H. specialize (H F2_1 F2_0). unfold magma_op, reff78_inst, reff78_op in H. discriminate H. Qed.

Lemma reff78_not209 : ~ @Equation209 Fin2 reff78_inst.
Proof. unfold Equation209. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff78_inst, reff78_op in H. discriminate H. Qed.

Lemma reff78_not212 : ~ @Equation212 Fin2 reff78_inst.
Proof. unfold Equation212. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff78_inst, reff78_op in H. discriminate H. Qed.

Lemma reff78_not219 : ~ @Equation219 Fin2 reff78_inst.
Proof. unfold Equation219. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff78_inst, reff78_op in H. discriminate H. Qed.

Lemma reff78_not222 : ~ @Equation222 Fin2 reff78_inst.
Proof. unfold Equation222. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff78_inst, reff78_op in H. discriminate H. Qed.

Lemma reff78_not228 : ~ @Equation228 Fin2 reff78_inst.
Proof. unfold Equation228. intro H. specialize (H F2_1 F2_0). unfold magma_op, reff78_inst, reff78_op in H. discriminate H. Qed.

Lemma reff78_not229 : ~ @Equation229 Fin2 reff78_inst.
Proof. unfold Equation229. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff78_inst, reff78_op in H. discriminate H. Qed.

Lemma reff78_not255 : ~ @Equation255 Fin2 reff78_inst.
Proof. unfold Equation255. intro H. specialize (H F2_1). unfold magma_op, reff78_inst, reff78_op in H. discriminate H. Qed.

Lemma reff78_not359 : ~ @Equation359 Fin2 reff78_inst.
Proof. unfold Equation359. intro H. specialize (H F2_1). unfold magma_op, reff78_inst, reff78_op in H. discriminate H. Qed.

Lemma reff78_not411 : ~ @Equation411 Fin2 reff78_inst.
Proof. unfold Equation411. intro H. specialize (H F2_1). unfold magma_op, reff78_inst, reff78_op in H. discriminate H. Qed.

Lemma reff78_not614 : ~ @Equation614 Fin2 reff78_inst.
Proof. unfold Equation614. intro H. specialize (H F2_1). unfold magma_op, reff78_inst, reff78_op in H. discriminate H. Qed.

Lemma reff78_not817 : ~ @Equation817 Fin2 reff78_inst.
Proof. unfold Equation817. intro H. specialize (H F2_1). unfold magma_op, reff78_inst, reff78_op in H. discriminate H. Qed.

Lemma reff78_not1020 : ~ @Equation1020 Fin2 reff78_inst.
Proof. unfold Equation1020. intro H. specialize (H F2_1). unfold magma_op, reff78_inst, reff78_op in H. discriminate H. Qed.

Lemma reff78_not1223 : ~ @Equation1223 Fin2 reff78_inst.
Proof. unfold Equation1223. intro H. specialize (H F2_1). unfold magma_op, reff78_inst, reff78_op in H. discriminate H. Qed.

Lemma reff78_not1426 : ~ @Equation1426 Fin2 reff78_inst.
Proof. unfold Equation1426. intro H. specialize (H F2_1). unfold magma_op, reff78_inst, reff78_op in H. discriminate H. Qed.

Lemma reff78_not1630 : ~ @Equation1630 Fin2 reff78_inst.
Proof. unfold Equation1630. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff78_inst, reff78_op in H. discriminate H. Qed.

Lemma reff78_not1632 : ~ @Equation1632 Fin2 reff78_inst.
Proof. unfold Equation1632. intro H. specialize (H F2_1 F2_0). unfold magma_op, reff78_inst, reff78_op in H. discriminate H. Qed.

Lemma reff78_not1634 : ~ @Equation1634 Fin2 reff78_inst.
Proof. unfold Equation1634. intro H. specialize (H F2_1 F2_0). unfold magma_op, reff78_inst, reff78_op in H. discriminate H. Qed.

Lemma reff78_not1635 : ~ @Equation1635 Fin2 reff78_inst.
Proof. unfold Equation1635. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff78_inst, reff78_op in H. discriminate H. Qed.

Lemma reff78_not1638 : ~ @Equation1638 Fin2 reff78_inst.
Proof. unfold Equation1638. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff78_inst, reff78_op in H. discriminate H. Qed.

Lemma reff78_not1645 : ~ @Equation1645 Fin2 reff78_inst.
Proof. unfold Equation1645. intro H. specialize (H F2_1 F2_0). unfold magma_op, reff78_inst, reff78_op in H. discriminate H. Qed.

Lemma reff78_not1648 : ~ @Equation1648 Fin2 reff78_inst.
Proof. unfold Equation1648. intro H. specialize (H F2_1 F2_0). unfold magma_op, reff78_inst, reff78_op in H. discriminate H. Qed.

Lemma reff78_not1654 : ~ @Equation1654 Fin2 reff78_inst.
Proof. unfold Equation1654. intro H. specialize (H F2_1 F2_0). unfold magma_op, reff78_inst, reff78_op in H. discriminate H. Qed.

Lemma reff78_not1655 : ~ @Equation1655 Fin2 reff78_inst.
Proof. unfold Equation1655. intro H. specialize (H F2_1 F2_0). unfold magma_op, reff78_inst, reff78_op in H. discriminate H. Qed.

Lemma reff78_not1658 : ~ @Equation1658 Fin2 reff78_inst.
Proof. unfold Equation1658. intro H. specialize (H F2_1 F2_0). unfold magma_op, reff78_inst, reff78_op in H. discriminate H. Qed.

Lemma reff78_not1681 : ~ @Equation1681 Fin2 reff78_inst.
Proof. unfold Equation1681. intro H. specialize (H F2_1 F2_0). unfold magma_op, reff78_inst, reff78_op in H. discriminate H. Qed.

Lemma reff78_not1682 : ~ @Equation1682 Fin2 reff78_inst.
Proof. unfold Equation1682. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff78_inst, reff78_op in H. discriminate H. Qed.

Lemma reff78_not1684 : ~ @Equation1684 Fin2 reff78_inst.
Proof. unfold Equation1684. intro H. specialize (H F2_1 F2_0). unfold magma_op, reff78_inst, reff78_op in H. discriminate H. Qed.

Lemma reff78_not1685 : ~ @Equation1685 Fin2 reff78_inst.
Proof. unfold Equation1685. intro H. specialize (H F2_1 F2_0). unfold magma_op, reff78_inst, reff78_op in H. discriminate H. Qed.

Lemma reff78_not1691 : ~ @Equation1691 Fin2 reff78_inst.
Proof. unfold Equation1691. intro H. specialize (H F2_1 F2_0). unfold magma_op, reff78_inst, reff78_op in H. discriminate H. Qed.

Lemma reff78_not1692 : ~ @Equation1692 Fin2 reff78_inst.
Proof. unfold Equation1692. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff78_inst, reff78_op in H. discriminate H. Qed.

Lemma reff78_not1694 : ~ @Equation1694 Fin2 reff78_inst.
Proof. unfold Equation1694. intro H. specialize (H F2_1 F2_0). unfold magma_op, reff78_inst, reff78_op in H. discriminate H. Qed.

Lemma reff78_not1695 : ~ @Equation1695 Fin2 reff78_inst.
Proof. unfold Equation1695. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff78_inst, reff78_op in H. discriminate H. Qed.

Lemma reff78_not1719 : ~ @Equation1719 Fin2 reff78_inst.
Proof. unfold Equation1719. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff78_inst, reff78_op in H. discriminate H. Qed.

Lemma reff78_not1722 : ~ @Equation1722 Fin2 reff78_inst.
Proof. unfold Equation1722. intro H. specialize (H F2_1 F2_0). unfold magma_op, reff78_inst, reff78_op in H. discriminate H. Qed.

Lemma reff78_not1728 : ~ @Equation1728 Fin2 reff78_inst.
Proof. unfold Equation1728. intro H. specialize (H F2_1 F2_0). unfold magma_op, reff78_inst, reff78_op in H. discriminate H. Qed.

Lemma reff78_not1729 : ~ @Equation1729 Fin2 reff78_inst.
Proof. unfold Equation1729. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff78_inst, reff78_op in H. discriminate H. Qed.

Lemma reff78_not1832 : ~ @Equation1832 Fin2 reff78_inst.
Proof. unfold Equation1832. intro H. specialize (H F2_1). unfold magma_op, reff78_inst, reff78_op in H. discriminate H. Qed.

Lemma reff78_not2035 : ~ @Equation2035 Fin2 reff78_inst.
Proof. unfold Equation2035. intro H. specialize (H F2_1). unfold magma_op, reff78_inst, reff78_op in H. discriminate H. Qed.

Lemma reff78_not2239 : ~ @Equation2239 Fin2 reff78_inst.
Proof. unfold Equation2239. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff78_inst, reff78_op in H. discriminate H. Qed.

Lemma reff78_not2241 : ~ @Equation2241 Fin2 reff78_inst.
Proof. unfold Equation2241. intro H. specialize (H F2_1 F2_0). unfold magma_op, reff78_inst, reff78_op in H. discriminate H. Qed.

Lemma reff78_not2244 : ~ @Equation2244 Fin2 reff78_inst.
Proof. unfold Equation2244. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff78_inst, reff78_op in H. discriminate H. Qed.

Lemma reff78_not2247 : ~ @Equation2247 Fin2 reff78_inst.
Proof. unfold Equation2247. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff78_inst, reff78_op in H. discriminate H. Qed.

Lemma reff78_not2254 : ~ @Equation2254 Fin2 reff78_inst.
Proof. unfold Equation2254. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff78_inst, reff78_op in H. discriminate H. Qed.

Lemma reff78_not2257 : ~ @Equation2257 Fin2 reff78_inst.
Proof. unfold Equation2257. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff78_inst, reff78_op in H. discriminate H. Qed.

Lemma reff78_not2264 : ~ @Equation2264 Fin2 reff78_inst.
Proof. unfold Equation2264. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff78_inst, reff78_op in H. discriminate H. Qed.

Lemma reff78_not2267 : ~ @Equation2267 Fin2 reff78_inst.
Proof. unfold Equation2267. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff78_inst, reff78_op in H. discriminate H. Qed.

Lemma reff78_not2291 : ~ @Equation2291 Fin2 reff78_inst.
Proof. unfold Equation2291. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff78_inst, reff78_op in H. discriminate H. Qed.

Lemma reff78_not2294 : ~ @Equation2294 Fin2 reff78_inst.
Proof. unfold Equation2294. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff78_inst, reff78_op in H. discriminate H. Qed.

Lemma reff78_not2301 : ~ @Equation2301 Fin2 reff78_inst.
Proof. unfold Equation2301. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff78_inst, reff78_op in H. discriminate H. Qed.

Lemma reff78_not2304 : ~ @Equation2304 Fin2 reff78_inst.
Proof. unfold Equation2304. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff78_inst, reff78_op in H. discriminate H. Qed.

Lemma reff78_not2328 : ~ @Equation2328 Fin2 reff78_inst.
Proof. unfold Equation2328. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff78_inst, reff78_op in H. discriminate H. Qed.

Lemma reff78_not2331 : ~ @Equation2331 Fin2 reff78_inst.
Proof. unfold Equation2331. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff78_inst, reff78_op in H. discriminate H. Qed.

Lemma reff78_not2337 : ~ @Equation2337 Fin2 reff78_inst.
Proof. unfold Equation2337. intro H. specialize (H F2_1 F2_0). unfold magma_op, reff78_inst, reff78_op in H. discriminate H. Qed.

Lemma reff78_not2338 : ~ @Equation2338 Fin2 reff78_inst.
Proof. unfold Equation2338. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff78_inst, reff78_op in H. discriminate H. Qed.

Lemma reff78_not2442 : ~ @Equation2442 Fin2 reff78_inst.
Proof. unfold Equation2442. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff78_inst, reff78_op in H. discriminate H. Qed.

Lemma reff78_not2444 : ~ @Equation2444 Fin2 reff78_inst.
Proof. unfold Equation2444. intro H. specialize (H F2_1 F2_0). unfold magma_op, reff78_inst, reff78_op in H. discriminate H. Qed.

Lemma reff78_not2447 : ~ @Equation2447 Fin2 reff78_inst.
Proof. unfold Equation2447. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff78_inst, reff78_op in H. discriminate H. Qed.

Lemma reff78_not2450 : ~ @Equation2450 Fin2 reff78_inst.
Proof. unfold Equation2450. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff78_inst, reff78_op in H. discriminate H. Qed.

Lemma reff78_not2457 : ~ @Equation2457 Fin2 reff78_inst.
Proof. unfold Equation2457. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff78_inst, reff78_op in H. discriminate H. Qed.

Lemma reff78_not2460 : ~ @Equation2460 Fin2 reff78_inst.
Proof. unfold Equation2460. intro H. specialize (H F2_1 F2_0). unfold magma_op, reff78_inst, reff78_op in H. discriminate H. Qed.

Lemma reff78_not2467 : ~ @Equation2467 Fin2 reff78_inst.
Proof. unfold Equation2467. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff78_inst, reff78_op in H. discriminate H. Qed.

Lemma reff78_not2470 : ~ @Equation2470 Fin2 reff78_inst.
Proof. unfold Equation2470. intro H. specialize (H F2_1 F2_0). unfold magma_op, reff78_inst, reff78_op in H. discriminate H. Qed.

Lemma reff78_not2493 : ~ @Equation2493 Fin2 reff78_inst.
Proof. unfold Equation2493. intro H. specialize (H F2_1 F2_0). unfold magma_op, reff78_inst, reff78_op in H. discriminate H. Qed.

Lemma reff78_not2494 : ~ @Equation2494 Fin2 reff78_inst.
Proof. unfold Equation2494. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff78_inst, reff78_op in H. discriminate H. Qed.

Lemma reff78_not2497 : ~ @Equation2497 Fin2 reff78_inst.
Proof. unfold Equation2497. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff78_inst, reff78_op in H. discriminate H. Qed.

Lemma reff78_not2503 : ~ @Equation2503 Fin2 reff78_inst.
Proof. unfold Equation2503. intro H. specialize (H F2_1 F2_0). unfold magma_op, reff78_inst, reff78_op in H. discriminate H. Qed.

Lemma reff78_not2504 : ~ @Equation2504 Fin2 reff78_inst.
Proof. unfold Equation2504. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff78_inst, reff78_op in H. discriminate H. Qed.

Lemma reff78_not2507 : ~ @Equation2507 Fin2 reff78_inst.
Proof. unfold Equation2507. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff78_inst, reff78_op in H. discriminate H. Qed.

Lemma reff78_not2531 : ~ @Equation2531 Fin2 reff78_inst.
Proof. unfold Equation2531. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff78_inst, reff78_op in H. discriminate H. Qed.

Lemma reff78_not2534 : ~ @Equation2534 Fin2 reff78_inst.
Proof. unfold Equation2534. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff78_inst, reff78_op in H. discriminate H. Qed.

Lemma reff78_not2540 : ~ @Equation2540 Fin2 reff78_inst.
Proof. unfold Equation2540. intro H. specialize (H F2_1 F2_0). unfold magma_op, reff78_inst, reff78_op in H. discriminate H. Qed.

Lemma reff78_not2541 : ~ @Equation2541 Fin2 reff78_inst.
Proof. unfold Equation2541. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff78_inst, reff78_op in H. discriminate H. Qed.

Lemma reff78_not2645 : ~ @Equation2645 Fin2 reff78_inst.
Proof. unfold Equation2645. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff78_inst, reff78_op in H. discriminate H. Qed.

Lemma reff78_not2647 : ~ @Equation2647 Fin2 reff78_inst.
Proof. unfold Equation2647. intro H. specialize (H F2_1 F2_0). unfold magma_op, reff78_inst, reff78_op in H. discriminate H. Qed.

Lemma reff78_not2649 : ~ @Equation2649 Fin2 reff78_inst.
Proof. unfold Equation2649. intro H. specialize (H F2_1 F2_0). unfold magma_op, reff78_inst, reff78_op in H. discriminate H. Qed.

Lemma reff78_not2650 : ~ @Equation2650 Fin2 reff78_inst.
Proof. unfold Equation2650. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff78_inst, reff78_op in H. discriminate H. Qed.

Lemma reff78_not2653 : ~ @Equation2653 Fin2 reff78_inst.
Proof. unfold Equation2653. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff78_inst, reff78_op in H. discriminate H. Qed.

Lemma reff78_not2660 : ~ @Equation2660 Fin2 reff78_inst.
Proof. unfold Equation2660. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff78_inst, reff78_op in H. discriminate H. Qed.

Lemma reff78_not2663 : ~ @Equation2663 Fin2 reff78_inst.
Proof. unfold Equation2663. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff78_inst, reff78_op in H. discriminate H. Qed.

Lemma reff78_not2669 : ~ @Equation2669 Fin2 reff78_inst.
Proof. unfold Equation2669. intro H. specialize (H F2_1 F2_0). unfold magma_op, reff78_inst, reff78_op in H. discriminate H. Qed.

Lemma reff78_not2670 : ~ @Equation2670 Fin2 reff78_inst.
Proof. unfold Equation2670. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff78_inst, reff78_op in H. discriminate H. Qed.

Lemma reff78_not2673 : ~ @Equation2673 Fin2 reff78_inst.
Proof. unfold Equation2673. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff78_inst, reff78_op in H. discriminate H. Qed.

Lemma reff78_not2697 : ~ @Equation2697 Fin2 reff78_inst.
Proof. unfold Equation2697. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff78_inst, reff78_op in H. discriminate H. Qed.

Lemma reff78_not2700 : ~ @Equation2700 Fin2 reff78_inst.
Proof. unfold Equation2700. intro H. specialize (H F2_1 F2_0). unfold magma_op, reff78_inst, reff78_op in H. discriminate H. Qed.

Lemma reff78_not2707 : ~ @Equation2707 Fin2 reff78_inst.
Proof. unfold Equation2707. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff78_inst, reff78_op in H. discriminate H. Qed.

Lemma reff78_not2710 : ~ @Equation2710 Fin2 reff78_inst.
Proof. unfold Equation2710. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff78_inst, reff78_op in H. discriminate H. Qed.

Lemma reff78_not2734 : ~ @Equation2734 Fin2 reff78_inst.
Proof. unfold Equation2734. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff78_inst, reff78_op in H. discriminate H. Qed.

Lemma reff78_not2737 : ~ @Equation2737 Fin2 reff78_inst.
Proof. unfold Equation2737. intro H. specialize (H F2_1 F2_0). unfold magma_op, reff78_inst, reff78_op in H. discriminate H. Qed.

Lemma reff78_not2743 : ~ @Equation2743 Fin2 reff78_inst.
Proof. unfold Equation2743. intro H. specialize (H F2_1 F2_0). unfold magma_op, reff78_inst, reff78_op in H. discriminate H. Qed.

Lemma reff78_not2744 : ~ @Equation2744 Fin2 reff78_inst.
Proof. unfold Equation2744. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff78_inst, reff78_op in H. discriminate H. Qed.

Lemma reff78_not2847 : ~ @Equation2847 Fin2 reff78_inst.
Proof. unfold Equation2847. intro H. specialize (H F2_1). unfold magma_op, reff78_inst, reff78_op in H. discriminate H. Qed.

Lemma reff78_not3051 : ~ @Equation3051 Fin2 reff78_inst.
Proof. unfold Equation3051. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff78_inst, reff78_op in H. discriminate H. Qed.

Lemma reff78_not3053 : ~ @Equation3053 Fin2 reff78_inst.
Proof. unfold Equation3053. intro H. specialize (H F2_1 F2_0). unfold magma_op, reff78_inst, reff78_op in H. discriminate H. Qed.

Lemma reff78_not3055 : ~ @Equation3055 Fin2 reff78_inst.
Proof. unfold Equation3055. intro H. specialize (H F2_1 F2_0). unfold magma_op, reff78_inst, reff78_op in H. discriminate H. Qed.

Lemma reff78_not3056 : ~ @Equation3056 Fin2 reff78_inst.
Proof. unfold Equation3056. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff78_inst, reff78_op in H. discriminate H. Qed.

Lemma reff78_not3059 : ~ @Equation3059 Fin2 reff78_inst.
Proof. unfold Equation3059. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff78_inst, reff78_op in H. discriminate H. Qed.

Lemma reff78_not3066 : ~ @Equation3066 Fin2 reff78_inst.
Proof. unfold Equation3066. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff78_inst, reff78_op in H. discriminate H. Qed.

Lemma reff78_not3069 : ~ @Equation3069 Fin2 reff78_inst.
Proof. unfold Equation3069. intro H. specialize (H F2_1 F2_0). unfold magma_op, reff78_inst, reff78_op in H. discriminate H. Qed.

Lemma reff78_not3075 : ~ @Equation3075 Fin2 reff78_inst.
Proof. unfold Equation3075. intro H. specialize (H F2_1 F2_0). unfold magma_op, reff78_inst, reff78_op in H. discriminate H. Qed.

Lemma reff78_not3076 : ~ @Equation3076 Fin2 reff78_inst.
Proof. unfold Equation3076. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff78_inst, reff78_op in H. discriminate H. Qed.

Lemma reff78_not3079 : ~ @Equation3079 Fin2 reff78_inst.
Proof. unfold Equation3079. intro H. specialize (H F2_1 F2_0). unfold magma_op, reff78_inst, reff78_op in H. discriminate H. Qed.

Lemma reff78_not3102 : ~ @Equation3102 Fin2 reff78_inst.
Proof. unfold Equation3102. intro H. specialize (H F2_1 F2_0). unfold magma_op, reff78_inst, reff78_op in H. discriminate H. Qed.

Lemma reff78_not3103 : ~ @Equation3103 Fin2 reff78_inst.
Proof. unfold Equation3103. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff78_inst, reff78_op in H. discriminate H. Qed.

Lemma reff78_not3106 : ~ @Equation3106 Fin2 reff78_inst.
Proof. unfold Equation3106. intro H. specialize (H F2_1 F2_0). unfold magma_op, reff78_inst, reff78_op in H. discriminate H. Qed.

Lemma reff78_not3112 : ~ @Equation3112 Fin2 reff78_inst.
Proof. unfold Equation3112. intro H. specialize (H F2_1 F2_0). unfold magma_op, reff78_inst, reff78_op in H. discriminate H. Qed.

Lemma reff78_not3113 : ~ @Equation3113 Fin2 reff78_inst.
Proof. unfold Equation3113. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff78_inst, reff78_op in H. discriminate H. Qed.

Lemma reff78_not3116 : ~ @Equation3116 Fin2 reff78_inst.
Proof. unfold Equation3116. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff78_inst, reff78_op in H. discriminate H. Qed.

Lemma reff78_not3140 : ~ @Equation3140 Fin2 reff78_inst.
Proof. unfold Equation3140. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff78_inst, reff78_op in H. discriminate H. Qed.

Lemma reff78_not3143 : ~ @Equation3143 Fin2 reff78_inst.
Proof. unfold Equation3143. intro H. specialize (H F2_1 F2_0). unfold magma_op, reff78_inst, reff78_op in H. discriminate H. Qed.

Lemma reff78_not3149 : ~ @Equation3149 Fin2 reff78_inst.
Proof. unfold Equation3149. intro H. specialize (H F2_1 F2_0). unfold magma_op, reff78_inst, reff78_op in H. discriminate H. Qed.

Lemma reff78_not3150 : ~ @Equation3150 Fin2 reff78_inst.
Proof. unfold Equation3150. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff78_inst, reff78_op in H. discriminate H. Qed.

Lemma reff78_not3254 : ~ @Equation3254 Fin2 reff78_inst.
Proof. unfold Equation3254. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff78_inst, reff78_op in H. discriminate H. Qed.

Lemma reff78_not3281 : ~ @Equation3281 Fin2 reff78_inst.
Proof. unfold Equation3281. intro H. specialize (H F2_1 F2_0). unfold magma_op, reff78_inst, reff78_op in H. discriminate H. Qed.

Lemma reff78_not3308 : ~ @Equation3308 Fin2 reff78_inst.
Proof. unfold Equation3308. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff78_inst, reff78_op in H. discriminate H. Qed.

Lemma reff78_not3309 : ~ @Equation3309 Fin2 reff78_inst.
Proof. unfold Equation3309. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff78_inst, reff78_op in H. discriminate H. Qed.

Lemma reff78_not3315 : ~ @Equation3315 Fin2 reff78_inst.
Proof. unfold Equation3315. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff78_inst, reff78_op in H. discriminate H. Qed.

Lemma reff78_not3316 : ~ @Equation3316 Fin2 reff78_inst.
Proof. unfold Equation3316. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff78_inst, reff78_op in H. discriminate H. Qed.

Lemma reff78_not3318 : ~ @Equation3318 Fin2 reff78_inst.
Proof. unfold Equation3318. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff78_inst, reff78_op in H. discriminate H. Qed.

Lemma reff78_not3319 : ~ @Equation3319 Fin2 reff78_inst.
Proof. unfold Equation3319. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff78_inst, reff78_op in H. discriminate H. Qed.

Lemma reff78_not3342 : ~ @Equation3342 Fin2 reff78_inst.
Proof. unfold Equation3342. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff78_inst, reff78_op in H. discriminate H. Qed.

Lemma reff78_not3343 : ~ @Equation3343 Fin2 reff78_inst.
Proof. unfold Equation3343. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff78_inst, reff78_op in H. discriminate H. Qed.

Lemma reff78_not3345 : ~ @Equation3345 Fin2 reff78_inst.
Proof. unfold Equation3345. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff78_inst, reff78_op in H. discriminate H. Qed.

Lemma reff78_not3346 : ~ @Equation3346 Fin2 reff78_inst.
Proof. unfold Equation3346. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff78_inst, reff78_op in H. discriminate H. Qed.

Lemma reff78_not3352 : ~ @Equation3352 Fin2 reff78_inst.
Proof. unfold Equation3352. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff78_inst, reff78_op in H. discriminate H. Qed.

Lemma reff78_not3353 : ~ @Equation3353 Fin2 reff78_inst.
Proof. unfold Equation3353. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff78_inst, reff78_op in H. discriminate H. Qed.

Lemma reff78_not3457 : ~ @Equation3457 Fin2 reff78_inst.
Proof. unfold Equation3457. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff78_inst, reff78_op in H. discriminate H. Qed.

Lemma reff78_not3462 : ~ @Equation3462 Fin2 reff78_inst.
Proof. unfold Equation3462. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff78_inst, reff78_op in H. discriminate H. Qed.

Lemma reff78_not3465 : ~ @Equation3465 Fin2 reff78_inst.
Proof. unfold Equation3465. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff78_inst, reff78_op in H. discriminate H. Qed.

Lemma reff78_not3471 : ~ @Equation3471 Fin2 reff78_inst.
Proof. unfold Equation3471. intro H. specialize (H F2_1 F2_0). unfold magma_op, reff78_inst, reff78_op in H. discriminate H. Qed.

Lemma reff78_not3474 : ~ @Equation3474 Fin2 reff78_inst.
Proof. unfold Equation3474. intro H. specialize (H F2_1 F2_0). unfold magma_op, reff78_inst, reff78_op in H. discriminate H. Qed.

Lemma reff78_not3484 : ~ @Equation3484 Fin2 reff78_inst.
Proof. unfold Equation3484. intro H. specialize (H F2_1 F2_0). unfold magma_op, reff78_inst, reff78_op in H. discriminate H. Qed.

Lemma reff78_not3511 : ~ @Equation3511 Fin2 reff78_inst.
Proof. unfold Equation3511. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff78_inst, reff78_op in H. discriminate H. Qed.

Lemma reff78_not3512 : ~ @Equation3512 Fin2 reff78_inst.
Proof. unfold Equation3512. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff78_inst, reff78_op in H. discriminate H. Qed.

Lemma reff78_not3518 : ~ @Equation3518 Fin2 reff78_inst.
Proof. unfold Equation3518. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff78_inst, reff78_op in H. discriminate H. Qed.

Lemma reff78_not3521 : ~ @Equation3521 Fin2 reff78_inst.
Proof. unfold Equation3521. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff78_inst, reff78_op in H. discriminate H. Qed.

Lemma reff78_not3545 : ~ @Equation3545 Fin2 reff78_inst.
Proof. unfold Equation3545. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff78_inst, reff78_op in H. discriminate H. Qed.

Lemma reff78_not3546 : ~ @Equation3546 Fin2 reff78_inst.
Proof. unfold Equation3546. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff78_inst, reff78_op in H. discriminate H. Qed.

Lemma reff78_not3548 : ~ @Equation3548 Fin2 reff78_inst.
Proof. unfold Equation3548. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff78_inst, reff78_op in H. discriminate H. Qed.

Lemma reff78_not3549 : ~ @Equation3549 Fin2 reff78_inst.
Proof. unfold Equation3549. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff78_inst, reff78_op in H. discriminate H. Qed.

Lemma reff78_not3555 : ~ @Equation3555 Fin2 reff78_inst.
Proof. unfold Equation3555. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff78_inst, reff78_op in H. discriminate H. Qed.

Lemma reff78_not3556 : ~ @Equation3556 Fin2 reff78_inst.
Proof. unfold Equation3556. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff78_inst, reff78_op in H. discriminate H. Qed.

Lemma reff78_not3558 : ~ @Equation3558 Fin2 reff78_inst.
Proof. unfold Equation3558. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff78_inst, reff78_op in H. discriminate H. Qed.

Lemma reff78_not3660 : ~ @Equation3660 Fin2 reff78_inst.
Proof. unfold Equation3660. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff78_inst, reff78_op in H. discriminate H. Qed.

Lemma reff78_not3661 : ~ @Equation3661 Fin2 reff78_inst.
Proof. unfold Equation3661. intro H. specialize (H F2_1 F2_0). unfold magma_op, reff78_inst, reff78_op in H. discriminate H. Qed.

Lemma reff78_not3667 : ~ @Equation3667 Fin2 reff78_inst.
Proof. unfold Equation3667. intro H. specialize (H F2_1 F2_0). unfold magma_op, reff78_inst, reff78_op in H. discriminate H. Qed.

Lemma reff78_not3675 : ~ @Equation3675 Fin2 reff78_inst.
Proof. unfold Equation3675. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff78_inst, reff78_op in H. discriminate H. Qed.

Lemma reff78_not3685 : ~ @Equation3685 Fin2 reff78_inst.
Proof. unfold Equation3685. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff78_inst, reff78_op in H. discriminate H. Qed.

Lemma reff78_not3687 : ~ @Equation3687 Fin2 reff78_inst.
Proof. unfold Equation3687. intro H. specialize (H F2_1 F2_0). unfold magma_op, reff78_inst, reff78_op in H. discriminate H. Qed.

Lemma reff78_not3714 : ~ @Equation3714 Fin2 reff78_inst.
Proof. unfold Equation3714. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff78_inst, reff78_op in H. discriminate H. Qed.

Lemma reff78_not3721 : ~ @Equation3721 Fin2 reff78_inst.
Proof. unfold Equation3721. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff78_inst, reff78_op in H. discriminate H. Qed.

Lemma reff78_not3722 : ~ @Equation3722 Fin2 reff78_inst.
Proof. unfold Equation3722. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff78_inst, reff78_op in H. discriminate H. Qed.

Lemma reff78_not3724 : ~ @Equation3724 Fin2 reff78_inst.
Proof. unfold Equation3724. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff78_inst, reff78_op in H. discriminate H. Qed.

Lemma reff78_not3725 : ~ @Equation3725 Fin2 reff78_inst.
Proof. unfold Equation3725. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff78_inst, reff78_op in H. discriminate H. Qed.

Lemma reff78_not3748 : ~ @Equation3748 Fin2 reff78_inst.
Proof. unfold Equation3748. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff78_inst, reff78_op in H. discriminate H. Qed.

Lemma reff78_not3751 : ~ @Equation3751 Fin2 reff78_inst.
Proof. unfold Equation3751. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff78_inst, reff78_op in H. discriminate H. Qed.

Lemma reff78_not3752 : ~ @Equation3752 Fin2 reff78_inst.
Proof. unfold Equation3752. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff78_inst, reff78_op in H. discriminate H. Qed.

Lemma reff78_not3761 : ~ @Equation3761 Fin2 reff78_inst.
Proof. unfold Equation3761. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff78_inst, reff78_op in H. discriminate H. Qed.

Lemma reff78_not3862 : ~ @Equation3862 Fin2 reff78_inst.
Proof. unfold Equation3862. intro H. specialize (H F2_1). unfold magma_op, reff78_inst, reff78_op in H. discriminate H. Qed.

Lemma reff78_not4066 : ~ @Equation4066 Fin2 reff78_inst.
Proof. unfold Equation4066. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff78_inst, reff78_op in H. discriminate H. Qed.

Lemma reff78_not4067 : ~ @Equation4067 Fin2 reff78_inst.
Proof. unfold Equation4067. intro H. specialize (H F2_1 F2_0). unfold magma_op, reff78_inst, reff78_op in H. discriminate H. Qed.

Lemma reff78_not4071 : ~ @Equation4071 Fin2 reff78_inst.
Proof. unfold Equation4071. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff78_inst, reff78_op in H. discriminate H. Qed.

Lemma reff78_not4073 : ~ @Equation4073 Fin2 reff78_inst.
Proof. unfold Equation4073. intro H. specialize (H F2_1 F2_0). unfold magma_op, reff78_inst, reff78_op in H. discriminate H. Qed.

Lemma reff78_not4074 : ~ @Equation4074 Fin2 reff78_inst.
Proof. unfold Equation4074. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff78_inst, reff78_op in H. discriminate H. Qed.

Lemma reff78_not4080 : ~ @Equation4080 Fin2 reff78_inst.
Proof. unfold Equation4080. intro H. specialize (H F2_1 F2_0). unfold magma_op, reff78_inst, reff78_op in H. discriminate H. Qed.

Lemma reff78_not4081 : ~ @Equation4081 Fin2 reff78_inst.
Proof. unfold Equation4081. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff78_inst, reff78_op in H. discriminate H. Qed.

Lemma reff78_not4083 : ~ @Equation4083 Fin2 reff78_inst.
Proof. unfold Equation4083. intro H. specialize (H F2_1 F2_0). unfold magma_op, reff78_inst, reff78_op in H. discriminate H. Qed.

Lemma reff78_not4091 : ~ @Equation4091 Fin2 reff78_inst.
Proof. unfold Equation4091. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff78_inst, reff78_op in H. discriminate H. Qed.

Lemma reff78_not4093 : ~ @Equation4093 Fin2 reff78_inst.
Proof. unfold Equation4093. intro H. specialize (H F2_1 F2_0). unfold magma_op, reff78_inst, reff78_op in H. discriminate H. Qed.

Lemma reff78_not4120 : ~ @Equation4120 Fin2 reff78_inst.
Proof. unfold Equation4120. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff78_inst, reff78_op in H. discriminate H. Qed.

Lemma reff78_not4121 : ~ @Equation4121 Fin2 reff78_inst.
Proof. unfold Equation4121. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff78_inst, reff78_op in H. discriminate H. Qed.

Lemma reff78_not4127 : ~ @Equation4127 Fin2 reff78_inst.
Proof. unfold Equation4127. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff78_inst, reff78_op in H. discriminate H. Qed.

Lemma reff78_not4130 : ~ @Equation4130 Fin2 reff78_inst.
Proof. unfold Equation4130. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff78_inst, reff78_op in H. discriminate H. Qed.

Lemma reff78_not4157 : ~ @Equation4157 Fin2 reff78_inst.
Proof. unfold Equation4157. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff78_inst, reff78_op in H. discriminate H. Qed.

Lemma reff78_not4158 : ~ @Equation4158 Fin2 reff78_inst.
Proof. unfold Equation4158. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff78_inst, reff78_op in H. discriminate H. Qed.

Lemma reff78_not4164 : ~ @Equation4164 Fin2 reff78_inst.
Proof. unfold Equation4164. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff78_inst, reff78_op in H. discriminate H. Qed.

Lemma reff78_not4167 : ~ @Equation4167 Fin2 reff78_inst.
Proof. unfold Equation4167. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff78_inst, reff78_op in H. discriminate H. Qed.

Lemma reff78_not4268 : ~ @Equation4268 Fin2 reff78_inst.
Proof. unfold Equation4268. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff78_inst, reff78_op in H. discriminate H. Qed.

Lemma reff78_not4275 : ~ @Equation4275 Fin2 reff78_inst.
Proof. unfold Equation4275. intro H. specialize (H F2_1 F2_0). unfold magma_op, reff78_inst, reff78_op in H. discriminate H. Qed.

Lemma reff78_not4283 : ~ @Equation4283 Fin2 reff78_inst.
Proof. unfold Equation4283. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff78_inst, reff78_op in H. discriminate H. Qed.

Lemma reff78_not4284 : ~ @Equation4284 Fin2 reff78_inst.
Proof. unfold Equation4284. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff78_inst, reff78_op in H. discriminate H. Qed.

Lemma reff78_not4290 : ~ @Equation4290 Fin2 reff78_inst.
Proof. unfold Equation4290. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff78_inst, reff78_op in H. discriminate H. Qed.

Lemma reff78_not4291 : ~ @Equation4291 Fin2 reff78_inst.
Proof. unfold Equation4291. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff78_inst, reff78_op in H. discriminate H. Qed.

Lemma reff78_not4293 : ~ @Equation4293 Fin2 reff78_inst.
Proof. unfold Equation4293. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff78_inst, reff78_op in H. discriminate H. Qed.

Lemma reff78_not4380 : ~ @Equation4380 Fin2 reff78_inst.
Proof. unfold Equation4380. intro H. specialize (H F2_1). unfold magma_op, reff78_inst, reff78_op in H. discriminate H. Qed.

Lemma reff78_not4583 : ~ @Equation4583 Fin2 reff78_inst.
Proof. unfold Equation4583. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff78_inst, reff78_op in H. discriminate H. Qed.

Lemma reff78_not4585 : ~ @Equation4585 Fin2 reff78_inst.
Proof. unfold Equation4585. intro H. specialize (H F2_1 F2_0). unfold magma_op, reff78_inst, reff78_op in H. discriminate H. Qed.

Lemma reff78_not4587 : ~ @Equation4587 Fin2 reff78_inst.
Proof. unfold Equation4587. intro H. specialize (H F2_1 F2_0). unfold magma_op, reff78_inst, reff78_op in H. discriminate H. Qed.

Lemma reff78_not4588 : ~ @Equation4588 Fin2 reff78_inst.
Proof. unfold Equation4588. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff78_inst, reff78_op in H. discriminate H. Qed.

Lemma reff78_not4591 : ~ @Equation4591 Fin2 reff78_inst.
Proof. unfold Equation4591. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff78_inst, reff78_op in H. discriminate H. Qed.

Lemma reff78_not4598 : ~ @Equation4598 Fin2 reff78_inst.
Proof. unfold Equation4598. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff78_inst, reff78_op in H. discriminate H. Qed.

Lemma reff78_not4599 : ~ @Equation4599 Fin2 reff78_inst.
Proof. unfold Equation4599. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff78_inst, reff78_op in H. discriminate H. Qed.

Lemma reff78_not4605 : ~ @Equation4605 Fin2 reff78_inst.
Proof. unfold Equation4605. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff78_inst, reff78_op in H. discriminate H. Qed.

Lemma reff78_not4608 : ~ @Equation4608 Fin2 reff78_inst.
Proof. unfold Equation4608. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff78_inst, reff78_op in H. discriminate H. Qed.

Lemma reff78_not4629 : ~ @Equation4629 Fin2 reff78_inst.
Proof. unfold Equation4629. intro H. specialize (H F2_1 F2_0). unfold magma_op, reff78_inst, reff78_op in H. discriminate H. Qed.

Lemma reff78_not4635 : ~ @Equation4635 Fin2 reff78_inst.
Proof. unfold Equation4635. intro H. specialize (H F2_1 F2_0). unfold magma_op, reff78_inst, reff78_op in H. discriminate H. Qed.

Lemma reff78_not4636 : ~ @Equation4636 Fin2 reff78_inst.
Proof. unfold Equation4636. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff78_inst, reff78_op in H. discriminate H. Qed.

(** ---- reff8 (Fin2) ---- *)

Definition reff8_op (x y : Fin2) : Fin2 :=
  match x, y with
  | F2_0, F2_0 => F2_0 | F2_0, F2_1 => F2_1
  | F2_1, F2_0 => F2_0 | F2_1, F2_1 => F2_1
  end.

#[local] Instance reff8_inst : Magma Fin2 := {| magma_op := reff8_op |}.

Lemma reff8_sat5 : @Equation5 Fin2 reff8_inst.
Proof. unfold Equation5, magma_op, reff8_inst, reff8_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff8_not50 : ~ @Equation50 Fin2 reff8_inst.
Proof. unfold Equation50. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff8_inst, reff8_op in H. discriminate H. Qed.

Lemma reff8_not53 : ~ @Equation53 Fin2 reff8_inst.
Proof. unfold Equation53. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff8_inst, reff8_op in H. discriminate H. Qed.

Lemma reff8_not56 : ~ @Equation56 Fin2 reff8_inst.
Proof. unfold Equation56. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff8_inst, reff8_op in H. discriminate H. Qed.

Lemma reff8_not63 : ~ @Equation63 Fin2 reff8_inst.
Proof. unfold Equation63. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff8_inst, reff8_op in H. discriminate H. Qed.

Lemma reff8_not66 : ~ @Equation66 Fin2 reff8_inst.
Proof. unfold Equation66. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff8_inst, reff8_op in H. discriminate H. Qed.

Lemma reff8_not73 : ~ @Equation73 Fin2 reff8_inst.
Proof. unfold Equation73. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff8_inst, reff8_op in H. discriminate H. Qed.

Lemma reff8_not102 : ~ @Equation102 Fin2 reff8_inst.
Proof. unfold Equation102. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff8_inst, reff8_op in H. discriminate H. Qed.

Lemma reff8_not105 : ~ @Equation105 Fin2 reff8_inst.
Proof. unfold Equation105. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff8_inst, reff8_op in H. discriminate H. Qed.

Lemma reff8_not108 : ~ @Equation108 Fin2 reff8_inst.
Proof. unfold Equation108. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff8_inst, reff8_op in H. discriminate H. Qed.

Lemma reff8_not115 : ~ @Equation115 Fin2 reff8_inst.
Proof. unfold Equation115. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff8_inst, reff8_op in H. discriminate H. Qed.

Lemma reff8_not118 : ~ @Equation118 Fin2 reff8_inst.
Proof. unfold Equation118. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff8_inst, reff8_op in H. discriminate H. Qed.

Lemma reff8_not125 : ~ @Equation125 Fin2 reff8_inst.
Proof. unfold Equation125. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff8_inst, reff8_op in H. discriminate H. Qed.

Lemma reff8_not154 : ~ @Equation154 Fin2 reff8_inst.
Proof. unfold Equation154. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff8_inst, reff8_op in H. discriminate H. Qed.

Lemma reff8_not157 : ~ @Equation157 Fin2 reff8_inst.
Proof. unfold Equation157. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff8_inst, reff8_op in H. discriminate H. Qed.

Lemma reff8_not160 : ~ @Equation160 Fin2 reff8_inst.
Proof. unfold Equation160. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff8_inst, reff8_op in H. discriminate H. Qed.

Lemma reff8_not167 : ~ @Equation167 Fin2 reff8_inst.
Proof. unfold Equation167. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff8_inst, reff8_op in H. discriminate H. Qed.

Lemma reff8_not170 : ~ @Equation170 Fin2 reff8_inst.
Proof. unfold Equation170. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff8_inst, reff8_op in H. discriminate H. Qed.

Lemma reff8_not177 : ~ @Equation177 Fin2 reff8_inst.
Proof. unfold Equation177. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff8_inst, reff8_op in H. discriminate H. Qed.

Lemma reff8_not206 : ~ @Equation206 Fin2 reff8_inst.
Proof. unfold Equation206. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff8_inst, reff8_op in H. discriminate H. Qed.

Lemma reff8_not209 : ~ @Equation209 Fin2 reff8_inst.
Proof. unfold Equation209. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff8_inst, reff8_op in H. discriminate H. Qed.

Lemma reff8_not212 : ~ @Equation212 Fin2 reff8_inst.
Proof. unfold Equation212. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff8_inst, reff8_op in H. discriminate H. Qed.

Lemma reff8_not219 : ~ @Equation219 Fin2 reff8_inst.
Proof. unfold Equation219. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff8_inst, reff8_op in H. discriminate H. Qed.

Lemma reff8_not222 : ~ @Equation222 Fin2 reff8_inst.
Proof. unfold Equation222. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff8_inst, reff8_op in H. discriminate H. Qed.

Lemma reff8_not229 : ~ @Equation229 Fin2 reff8_inst.
Proof. unfold Equation229. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff8_inst, reff8_op in H. discriminate H. Qed.

Lemma reff8_not258 : ~ @Equation258 Fin2 reff8_inst.
Proof. unfold Equation258. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff8_inst, reff8_op in H. discriminate H. Qed.

Lemma reff8_not261 : ~ @Equation261 Fin2 reff8_inst.
Proof. unfold Equation261. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff8_inst, reff8_op in H. discriminate H. Qed.

Lemma reff8_not264 : ~ @Equation264 Fin2 reff8_inst.
Proof. unfold Equation264. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff8_inst, reff8_op in H. discriminate H. Qed.

Lemma reff8_not271 : ~ @Equation271 Fin2 reff8_inst.
Proof. unfold Equation271. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff8_inst, reff8_op in H. discriminate H. Qed.

Lemma reff8_not274 : ~ @Equation274 Fin2 reff8_inst.
Proof. unfold Equation274. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff8_inst, reff8_op in H. discriminate H. Qed.

Lemma reff8_not281 : ~ @Equation281 Fin2 reff8_inst.
Proof. unfold Equation281. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff8_inst, reff8_op in H. discriminate H. Qed.

Lemma reff8_not335 : ~ @Equation335 Fin2 reff8_inst.
Proof. unfold Equation335. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff8_inst, reff8_op in H. discriminate H. Qed.

Lemma reff8_not412 : ~ @Equation412 Fin2 reff8_inst.
Proof. unfold Equation412. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff8_inst, reff8_op in H. discriminate H. Qed.

Lemma reff8_not414 : ~ @Equation414 Fin2 reff8_inst.
Proof. unfold Equation414. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff8_inst, reff8_op in H. discriminate H. Qed.

Lemma reff8_not417 : ~ @Equation417 Fin2 reff8_inst.
Proof. unfold Equation417. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff8_inst, reff8_op in H. discriminate H. Qed.

Lemma reff8_not420 : ~ @Equation420 Fin2 reff8_inst.
Proof. unfold Equation420. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff8_inst, reff8_op in H. discriminate H. Qed.

Lemma reff8_not427 : ~ @Equation427 Fin2 reff8_inst.
Proof. unfold Equation427. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff8_inst, reff8_op in H. discriminate H. Qed.

Lemma reff8_not430 : ~ @Equation430 Fin2 reff8_inst.
Proof. unfold Equation430. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff8_inst, reff8_op in H. discriminate H. Qed.

Lemma reff8_not437 : ~ @Equation437 Fin2 reff8_inst.
Proof. unfold Equation437. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff8_inst, reff8_op in H. discriminate H. Qed.

Lemma reff8_not440 : ~ @Equation440 Fin2 reff8_inst.
Proof. unfold Equation440. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff8_inst, reff8_op in H. discriminate H. Qed.

Lemma reff8_not464 : ~ @Equation464 Fin2 reff8_inst.
Proof. unfold Equation464. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff8_inst, reff8_op in H. discriminate H. Qed.

Lemma reff8_not467 : ~ @Equation467 Fin2 reff8_inst.
Proof. unfold Equation467. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff8_inst, reff8_op in H. discriminate H. Qed.

Lemma reff8_not474 : ~ @Equation474 Fin2 reff8_inst.
Proof. unfold Equation474. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff8_inst, reff8_op in H. discriminate H. Qed.

Lemma reff8_not477 : ~ @Equation477 Fin2 reff8_inst.
Proof. unfold Equation477. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff8_inst, reff8_op in H. discriminate H. Qed.

Lemma reff8_not501 : ~ @Equation501 Fin2 reff8_inst.
Proof. unfold Equation501. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff8_inst, reff8_op in H. discriminate H. Qed.

Lemma reff8_not504 : ~ @Equation504 Fin2 reff8_inst.
Proof. unfold Equation504. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff8_inst, reff8_op in H. discriminate H. Qed.

Lemma reff8_not511 : ~ @Equation511 Fin2 reff8_inst.
Proof. unfold Equation511. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff8_inst, reff8_op in H. discriminate H. Qed.

Lemma reff8_not615 : ~ @Equation615 Fin2 reff8_inst.
Proof. unfold Equation615. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff8_inst, reff8_op in H. discriminate H. Qed.

Lemma reff8_not617 : ~ @Equation617 Fin2 reff8_inst.
Proof. unfold Equation617. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff8_inst, reff8_op in H. discriminate H. Qed.

Lemma reff8_not620 : ~ @Equation620 Fin2 reff8_inst.
Proof. unfold Equation620. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff8_inst, reff8_op in H. discriminate H. Qed.

Lemma reff8_not623 : ~ @Equation623 Fin2 reff8_inst.
Proof. unfold Equation623. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff8_inst, reff8_op in H. discriminate H. Qed.

Lemma reff8_not630 : ~ @Equation630 Fin2 reff8_inst.
Proof. unfold Equation630. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff8_inst, reff8_op in H. discriminate H. Qed.

Lemma reff8_not633 : ~ @Equation633 Fin2 reff8_inst.
Proof. unfold Equation633. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff8_inst, reff8_op in H. discriminate H. Qed.

Lemma reff8_not640 : ~ @Equation640 Fin2 reff8_inst.
Proof. unfold Equation640. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff8_inst, reff8_op in H. discriminate H. Qed.

Lemma reff8_not643 : ~ @Equation643 Fin2 reff8_inst.
Proof. unfold Equation643. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff8_inst, reff8_op in H. discriminate H. Qed.

Lemma reff8_not667 : ~ @Equation667 Fin2 reff8_inst.
Proof. unfold Equation667. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff8_inst, reff8_op in H. discriminate H. Qed.

Lemma reff8_not670 : ~ @Equation670 Fin2 reff8_inst.
Proof. unfold Equation670. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff8_inst, reff8_op in H. discriminate H. Qed.

Lemma reff8_not677 : ~ @Equation677 Fin2 reff8_inst.
Proof. unfold Equation677. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff8_inst, reff8_op in H. discriminate H. Qed.

Lemma reff8_not680 : ~ @Equation680 Fin2 reff8_inst.
Proof. unfold Equation680. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff8_inst, reff8_op in H. discriminate H. Qed.

Lemma reff8_not704 : ~ @Equation704 Fin2 reff8_inst.
Proof. unfold Equation704. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff8_inst, reff8_op in H. discriminate H. Qed.

Lemma reff8_not707 : ~ @Equation707 Fin2 reff8_inst.
Proof. unfold Equation707. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff8_inst, reff8_op in H. discriminate H. Qed.

Lemma reff8_not714 : ~ @Equation714 Fin2 reff8_inst.
Proof. unfold Equation714. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff8_inst, reff8_op in H. discriminate H. Qed.

Lemma reff8_not818 : ~ @Equation818 Fin2 reff8_inst.
Proof. unfold Equation818. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff8_inst, reff8_op in H. discriminate H. Qed.

Lemma reff8_not820 : ~ @Equation820 Fin2 reff8_inst.
Proof. unfold Equation820. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff8_inst, reff8_op in H. discriminate H. Qed.

Lemma reff8_not823 : ~ @Equation823 Fin2 reff8_inst.
Proof. unfold Equation823. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff8_inst, reff8_op in H. discriminate H. Qed.

Lemma reff8_not826 : ~ @Equation826 Fin2 reff8_inst.
Proof. unfold Equation826. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff8_inst, reff8_op in H. discriminate H. Qed.

Lemma reff8_not833 : ~ @Equation833 Fin2 reff8_inst.
Proof. unfold Equation833. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff8_inst, reff8_op in H. discriminate H. Qed.

Lemma reff8_not836 : ~ @Equation836 Fin2 reff8_inst.
Proof. unfold Equation836. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff8_inst, reff8_op in H. discriminate H. Qed.

Lemma reff8_not843 : ~ @Equation843 Fin2 reff8_inst.
Proof. unfold Equation843. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff8_inst, reff8_op in H. discriminate H. Qed.

Lemma reff8_not846 : ~ @Equation846 Fin2 reff8_inst.
Proof. unfold Equation846. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff8_inst, reff8_op in H. discriminate H. Qed.

Lemma reff8_not870 : ~ @Equation870 Fin2 reff8_inst.
Proof. unfold Equation870. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff8_inst, reff8_op in H. discriminate H. Qed.

Lemma reff8_not873 : ~ @Equation873 Fin2 reff8_inst.
Proof. unfold Equation873. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff8_inst, reff8_op in H. discriminate H. Qed.

Lemma reff8_not880 : ~ @Equation880 Fin2 reff8_inst.
Proof. unfold Equation880. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff8_inst, reff8_op in H. discriminate H. Qed.

Lemma reff8_not883 : ~ @Equation883 Fin2 reff8_inst.
Proof. unfold Equation883. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff8_inst, reff8_op in H. discriminate H. Qed.

Lemma reff8_not907 : ~ @Equation907 Fin2 reff8_inst.
Proof. unfold Equation907. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff8_inst, reff8_op in H. discriminate H. Qed.

Lemma reff8_not910 : ~ @Equation910 Fin2 reff8_inst.
Proof. unfold Equation910. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff8_inst, reff8_op in H. discriminate H. Qed.

Lemma reff8_not917 : ~ @Equation917 Fin2 reff8_inst.
Proof. unfold Equation917. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff8_inst, reff8_op in H. discriminate H. Qed.

Lemma reff8_not1021 : ~ @Equation1021 Fin2 reff8_inst.
Proof. unfold Equation1021. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff8_inst, reff8_op in H. discriminate H. Qed.

Lemma reff8_not1023 : ~ @Equation1023 Fin2 reff8_inst.
Proof. unfold Equation1023. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff8_inst, reff8_op in H. discriminate H. Qed.

Lemma reff8_not1026 : ~ @Equation1026 Fin2 reff8_inst.
Proof. unfold Equation1026. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff8_inst, reff8_op in H. discriminate H. Qed.

Lemma reff8_not1029 : ~ @Equation1029 Fin2 reff8_inst.
Proof. unfold Equation1029. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff8_inst, reff8_op in H. discriminate H. Qed.

Lemma reff8_not1036 : ~ @Equation1036 Fin2 reff8_inst.
Proof. unfold Equation1036. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff8_inst, reff8_op in H. discriminate H. Qed.

Lemma reff8_not1039 : ~ @Equation1039 Fin2 reff8_inst.
Proof. unfold Equation1039. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff8_inst, reff8_op in H. discriminate H. Qed.

Lemma reff8_not1046 : ~ @Equation1046 Fin2 reff8_inst.
Proof. unfold Equation1046. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff8_inst, reff8_op in H. discriminate H. Qed.

Lemma reff8_not1049 : ~ @Equation1049 Fin2 reff8_inst.
Proof. unfold Equation1049. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff8_inst, reff8_op in H. discriminate H. Qed.

Lemma reff8_not1073 : ~ @Equation1073 Fin2 reff8_inst.
Proof. unfold Equation1073. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff8_inst, reff8_op in H. discriminate H. Qed.

Lemma reff8_not1076 : ~ @Equation1076 Fin2 reff8_inst.
Proof. unfold Equation1076. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff8_inst, reff8_op in H. discriminate H. Qed.

Lemma reff8_not1083 : ~ @Equation1083 Fin2 reff8_inst.
Proof. unfold Equation1083. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff8_inst, reff8_op in H. discriminate H. Qed.

Lemma reff8_not1086 : ~ @Equation1086 Fin2 reff8_inst.
Proof. unfold Equation1086. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff8_inst, reff8_op in H. discriminate H. Qed.

Lemma reff8_not1110 : ~ @Equation1110 Fin2 reff8_inst.
Proof. unfold Equation1110. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff8_inst, reff8_op in H. discriminate H. Qed.

Lemma reff8_not1113 : ~ @Equation1113 Fin2 reff8_inst.
Proof. unfold Equation1113. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff8_inst, reff8_op in H. discriminate H. Qed.

Lemma reff8_not1120 : ~ @Equation1120 Fin2 reff8_inst.
Proof. unfold Equation1120. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff8_inst, reff8_op in H. discriminate H. Qed.

Lemma reff8_not1224 : ~ @Equation1224 Fin2 reff8_inst.
Proof. unfold Equation1224. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff8_inst, reff8_op in H. discriminate H. Qed.

Lemma reff8_not1226 : ~ @Equation1226 Fin2 reff8_inst.
Proof. unfold Equation1226. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff8_inst, reff8_op in H. discriminate H. Qed.

Lemma reff8_not1229 : ~ @Equation1229 Fin2 reff8_inst.
Proof. unfold Equation1229. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff8_inst, reff8_op in H. discriminate H. Qed.

Lemma reff8_not1232 : ~ @Equation1232 Fin2 reff8_inst.
Proof. unfold Equation1232. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff8_inst, reff8_op in H. discriminate H. Qed.

Lemma reff8_not1239 : ~ @Equation1239 Fin2 reff8_inst.
Proof. unfold Equation1239. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff8_inst, reff8_op in H. discriminate H. Qed.

Lemma reff8_not1242 : ~ @Equation1242 Fin2 reff8_inst.
Proof. unfold Equation1242. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff8_inst, reff8_op in H. discriminate H. Qed.

Lemma reff8_not1249 : ~ @Equation1249 Fin2 reff8_inst.
Proof. unfold Equation1249. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff8_inst, reff8_op in H. discriminate H. Qed.

Lemma reff8_not1252 : ~ @Equation1252 Fin2 reff8_inst.
Proof. unfold Equation1252. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff8_inst, reff8_op in H. discriminate H. Qed.

Lemma reff8_not1276 : ~ @Equation1276 Fin2 reff8_inst.
Proof. unfold Equation1276. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff8_inst, reff8_op in H. discriminate H. Qed.

Lemma reff8_not1279 : ~ @Equation1279 Fin2 reff8_inst.
Proof. unfold Equation1279. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff8_inst, reff8_op in H. discriminate H. Qed.

Lemma reff8_not1286 : ~ @Equation1286 Fin2 reff8_inst.
Proof. unfold Equation1286. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff8_inst, reff8_op in H. discriminate H. Qed.

Lemma reff8_not1289 : ~ @Equation1289 Fin2 reff8_inst.
Proof. unfold Equation1289. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff8_inst, reff8_op in H. discriminate H. Qed.

Lemma reff8_not1313 : ~ @Equation1313 Fin2 reff8_inst.
Proof. unfold Equation1313. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff8_inst, reff8_op in H. discriminate H. Qed.

Lemma reff8_not1316 : ~ @Equation1316 Fin2 reff8_inst.
Proof. unfold Equation1316. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff8_inst, reff8_op in H. discriminate H. Qed.

Lemma reff8_not1323 : ~ @Equation1323 Fin2 reff8_inst.
Proof. unfold Equation1323. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff8_inst, reff8_op in H. discriminate H. Qed.

Lemma reff8_not1427 : ~ @Equation1427 Fin2 reff8_inst.
Proof. unfold Equation1427. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff8_inst, reff8_op in H. discriminate H. Qed.

Lemma reff8_not1429 : ~ @Equation1429 Fin2 reff8_inst.
Proof. unfold Equation1429. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff8_inst, reff8_op in H. discriminate H. Qed.

Lemma reff8_not1432 : ~ @Equation1432 Fin2 reff8_inst.
Proof. unfold Equation1432. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff8_inst, reff8_op in H. discriminate H. Qed.

Lemma reff8_not1435 : ~ @Equation1435 Fin2 reff8_inst.
Proof. unfold Equation1435. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff8_inst, reff8_op in H. discriminate H. Qed.

Lemma reff8_not1442 : ~ @Equation1442 Fin2 reff8_inst.
Proof. unfold Equation1442. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff8_inst, reff8_op in H. discriminate H. Qed.

Lemma reff8_not1445 : ~ @Equation1445 Fin2 reff8_inst.
Proof. unfold Equation1445. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff8_inst, reff8_op in H. discriminate H. Qed.

Lemma reff8_not1452 : ~ @Equation1452 Fin2 reff8_inst.
Proof. unfold Equation1452. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff8_inst, reff8_op in H. discriminate H. Qed.

Lemma reff8_not1455 : ~ @Equation1455 Fin2 reff8_inst.
Proof. unfold Equation1455. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff8_inst, reff8_op in H. discriminate H. Qed.

Lemma reff8_not1479 : ~ @Equation1479 Fin2 reff8_inst.
Proof. unfold Equation1479. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff8_inst, reff8_op in H. discriminate H. Qed.

Lemma reff8_not1482 : ~ @Equation1482 Fin2 reff8_inst.
Proof. unfold Equation1482. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff8_inst, reff8_op in H. discriminate H. Qed.

Lemma reff8_not1489 : ~ @Equation1489 Fin2 reff8_inst.
Proof. unfold Equation1489. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff8_inst, reff8_op in H. discriminate H. Qed.

Lemma reff8_not1492 : ~ @Equation1492 Fin2 reff8_inst.
Proof. unfold Equation1492. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff8_inst, reff8_op in H. discriminate H. Qed.

Lemma reff8_not1516 : ~ @Equation1516 Fin2 reff8_inst.
Proof. unfold Equation1516. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff8_inst, reff8_op in H. discriminate H. Qed.

Lemma reff8_not1519 : ~ @Equation1519 Fin2 reff8_inst.
Proof. unfold Equation1519. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff8_inst, reff8_op in H. discriminate H. Qed.

Lemma reff8_not1526 : ~ @Equation1526 Fin2 reff8_inst.
Proof. unfold Equation1526. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff8_inst, reff8_op in H. discriminate H. Qed.

Lemma reff8_not1630 : ~ @Equation1630 Fin2 reff8_inst.
Proof. unfold Equation1630. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff8_inst, reff8_op in H. discriminate H. Qed.

Lemma reff8_not1632 : ~ @Equation1632 Fin2 reff8_inst.
Proof. unfold Equation1632. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff8_inst, reff8_op in H. discriminate H. Qed.

Lemma reff8_not1635 : ~ @Equation1635 Fin2 reff8_inst.
Proof. unfold Equation1635. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff8_inst, reff8_op in H. discriminate H. Qed.

Lemma reff8_not1638 : ~ @Equation1638 Fin2 reff8_inst.
Proof. unfold Equation1638. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff8_inst, reff8_op in H. discriminate H. Qed.

Lemma reff8_not1645 : ~ @Equation1645 Fin2 reff8_inst.
Proof. unfold Equation1645. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff8_inst, reff8_op in H. discriminate H. Qed.

Lemma reff8_not1648 : ~ @Equation1648 Fin2 reff8_inst.
Proof. unfold Equation1648. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff8_inst, reff8_op in H. discriminate H. Qed.

Lemma reff8_not1655 : ~ @Equation1655 Fin2 reff8_inst.
Proof. unfold Equation1655. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff8_inst, reff8_op in H. discriminate H. Qed.

Lemma reff8_not1658 : ~ @Equation1658 Fin2 reff8_inst.
Proof. unfold Equation1658. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff8_inst, reff8_op in H. discriminate H. Qed.

Lemma reff8_not1682 : ~ @Equation1682 Fin2 reff8_inst.
Proof. unfold Equation1682. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff8_inst, reff8_op in H. discriminate H. Qed.

Lemma reff8_not1685 : ~ @Equation1685 Fin2 reff8_inst.
Proof. unfold Equation1685. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff8_inst, reff8_op in H. discriminate H. Qed.

Lemma reff8_not1692 : ~ @Equation1692 Fin2 reff8_inst.
Proof. unfold Equation1692. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff8_inst, reff8_op in H. discriminate H. Qed.

Lemma reff8_not1695 : ~ @Equation1695 Fin2 reff8_inst.
Proof. unfold Equation1695. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff8_inst, reff8_op in H. discriminate H. Qed.

Lemma reff8_not1719 : ~ @Equation1719 Fin2 reff8_inst.
Proof. unfold Equation1719. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff8_inst, reff8_op in H. discriminate H. Qed.

Lemma reff8_not1722 : ~ @Equation1722 Fin2 reff8_inst.
Proof. unfold Equation1722. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff8_inst, reff8_op in H. discriminate H. Qed.

Lemma reff8_not1729 : ~ @Equation1729 Fin2 reff8_inst.
Proof. unfold Equation1729. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff8_inst, reff8_op in H. discriminate H. Qed.

Lemma reff8_not1833 : ~ @Equation1833 Fin2 reff8_inst.
Proof. unfold Equation1833. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff8_inst, reff8_op in H. discriminate H. Qed.

Lemma reff8_not1835 : ~ @Equation1835 Fin2 reff8_inst.
Proof. unfold Equation1835. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff8_inst, reff8_op in H. discriminate H. Qed.

Lemma reff8_not1838 : ~ @Equation1838 Fin2 reff8_inst.
Proof. unfold Equation1838. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff8_inst, reff8_op in H. discriminate H. Qed.

Lemma reff8_not1841 : ~ @Equation1841 Fin2 reff8_inst.
Proof. unfold Equation1841. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff8_inst, reff8_op in H. discriminate H. Qed.

Lemma reff8_not1848 : ~ @Equation1848 Fin2 reff8_inst.
Proof. unfold Equation1848. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff8_inst, reff8_op in H. discriminate H. Qed.

Lemma reff8_not1851 : ~ @Equation1851 Fin2 reff8_inst.
Proof. unfold Equation1851. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff8_inst, reff8_op in H. discriminate H. Qed.

Lemma reff8_not1858 : ~ @Equation1858 Fin2 reff8_inst.
Proof. unfold Equation1858. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff8_inst, reff8_op in H. discriminate H. Qed.

Lemma reff8_not1861 : ~ @Equation1861 Fin2 reff8_inst.
Proof. unfold Equation1861. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff8_inst, reff8_op in H. discriminate H. Qed.

Lemma reff8_not1885 : ~ @Equation1885 Fin2 reff8_inst.
Proof. unfold Equation1885. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff8_inst, reff8_op in H. discriminate H. Qed.

Lemma reff8_not1888 : ~ @Equation1888 Fin2 reff8_inst.
Proof. unfold Equation1888. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff8_inst, reff8_op in H. discriminate H. Qed.

Lemma reff8_not1895 : ~ @Equation1895 Fin2 reff8_inst.
Proof. unfold Equation1895. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff8_inst, reff8_op in H. discriminate H. Qed.

Lemma reff8_not1898 : ~ @Equation1898 Fin2 reff8_inst.
Proof. unfold Equation1898. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff8_inst, reff8_op in H. discriminate H. Qed.

Lemma reff8_not1922 : ~ @Equation1922 Fin2 reff8_inst.
Proof. unfold Equation1922. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff8_inst, reff8_op in H. discriminate H. Qed.

Lemma reff8_not1925 : ~ @Equation1925 Fin2 reff8_inst.
Proof. unfold Equation1925. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff8_inst, reff8_op in H. discriminate H. Qed.

Lemma reff8_not1932 : ~ @Equation1932 Fin2 reff8_inst.
Proof. unfold Equation1932. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff8_inst, reff8_op in H. discriminate H. Qed.

Lemma reff8_not2036 : ~ @Equation2036 Fin2 reff8_inst.
Proof. unfold Equation2036. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff8_inst, reff8_op in H. discriminate H. Qed.

Lemma reff8_not2038 : ~ @Equation2038 Fin2 reff8_inst.
Proof. unfold Equation2038. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff8_inst, reff8_op in H. discriminate H. Qed.

Lemma reff8_not2041 : ~ @Equation2041 Fin2 reff8_inst.
Proof. unfold Equation2041. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff8_inst, reff8_op in H. discriminate H. Qed.

Lemma reff8_not2044 : ~ @Equation2044 Fin2 reff8_inst.
Proof. unfold Equation2044. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff8_inst, reff8_op in H. discriminate H. Qed.

Lemma reff8_not2051 : ~ @Equation2051 Fin2 reff8_inst.
Proof. unfold Equation2051. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff8_inst, reff8_op in H. discriminate H. Qed.

Lemma reff8_not2054 : ~ @Equation2054 Fin2 reff8_inst.
Proof. unfold Equation2054. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff8_inst, reff8_op in H. discriminate H. Qed.

Lemma reff8_not2061 : ~ @Equation2061 Fin2 reff8_inst.
Proof. unfold Equation2061. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff8_inst, reff8_op in H. discriminate H. Qed.

Lemma reff8_not2064 : ~ @Equation2064 Fin2 reff8_inst.
Proof. unfold Equation2064. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff8_inst, reff8_op in H. discriminate H. Qed.

Lemma reff8_not2088 : ~ @Equation2088 Fin2 reff8_inst.
Proof. unfold Equation2088. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff8_inst, reff8_op in H. discriminate H. Qed.

Lemma reff8_not2091 : ~ @Equation2091 Fin2 reff8_inst.
Proof. unfold Equation2091. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff8_inst, reff8_op in H. discriminate H. Qed.

Lemma reff8_not2098 : ~ @Equation2098 Fin2 reff8_inst.
Proof. unfold Equation2098. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff8_inst, reff8_op in H. discriminate H. Qed.

Lemma reff8_not2101 : ~ @Equation2101 Fin2 reff8_inst.
Proof. unfold Equation2101. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff8_inst, reff8_op in H. discriminate H. Qed.

Lemma reff8_not2125 : ~ @Equation2125 Fin2 reff8_inst.
Proof. unfold Equation2125. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff8_inst, reff8_op in H. discriminate H. Qed.

Lemma reff8_not2128 : ~ @Equation2128 Fin2 reff8_inst.
Proof. unfold Equation2128. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff8_inst, reff8_op in H. discriminate H. Qed.

Lemma reff8_not2135 : ~ @Equation2135 Fin2 reff8_inst.
Proof. unfold Equation2135. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff8_inst, reff8_op in H. discriminate H. Qed.

Lemma reff8_not2239 : ~ @Equation2239 Fin2 reff8_inst.
Proof. unfold Equation2239. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff8_inst, reff8_op in H. discriminate H. Qed.

Lemma reff8_not2241 : ~ @Equation2241 Fin2 reff8_inst.
Proof. unfold Equation2241. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff8_inst, reff8_op in H. discriminate H. Qed.

Lemma reff8_not2244 : ~ @Equation2244 Fin2 reff8_inst.
Proof. unfold Equation2244. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff8_inst, reff8_op in H. discriminate H. Qed.

Lemma reff8_not2247 : ~ @Equation2247 Fin2 reff8_inst.
Proof. unfold Equation2247. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff8_inst, reff8_op in H. discriminate H. Qed.

Lemma reff8_not2254 : ~ @Equation2254 Fin2 reff8_inst.
Proof. unfold Equation2254. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff8_inst, reff8_op in H. discriminate H. Qed.

Lemma reff8_not2257 : ~ @Equation2257 Fin2 reff8_inst.
Proof. unfold Equation2257. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff8_inst, reff8_op in H. discriminate H. Qed.

Lemma reff8_not2264 : ~ @Equation2264 Fin2 reff8_inst.
Proof. unfold Equation2264. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff8_inst, reff8_op in H. discriminate H. Qed.

Lemma reff8_not2267 : ~ @Equation2267 Fin2 reff8_inst.
Proof. unfold Equation2267. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff8_inst, reff8_op in H. discriminate H. Qed.

Lemma reff8_not2291 : ~ @Equation2291 Fin2 reff8_inst.
Proof. unfold Equation2291. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff8_inst, reff8_op in H. discriminate H. Qed.

Lemma reff8_not2294 : ~ @Equation2294 Fin2 reff8_inst.
Proof. unfold Equation2294. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff8_inst, reff8_op in H. discriminate H. Qed.

Lemma reff8_not2301 : ~ @Equation2301 Fin2 reff8_inst.
Proof. unfold Equation2301. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff8_inst, reff8_op in H. discriminate H. Qed.

Lemma reff8_not2304 : ~ @Equation2304 Fin2 reff8_inst.
Proof. unfold Equation2304. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff8_inst, reff8_op in H. discriminate H. Qed.

Lemma reff8_not2328 : ~ @Equation2328 Fin2 reff8_inst.
Proof. unfold Equation2328. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff8_inst, reff8_op in H. discriminate H. Qed.

Lemma reff8_not2331 : ~ @Equation2331 Fin2 reff8_inst.
Proof. unfold Equation2331. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff8_inst, reff8_op in H. discriminate H. Qed.

Lemma reff8_not2338 : ~ @Equation2338 Fin2 reff8_inst.
Proof. unfold Equation2338. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff8_inst, reff8_op in H. discriminate H. Qed.

Lemma reff8_not2442 : ~ @Equation2442 Fin2 reff8_inst.
Proof. unfold Equation2442. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff8_inst, reff8_op in H. discriminate H. Qed.

Lemma reff8_not2444 : ~ @Equation2444 Fin2 reff8_inst.
Proof. unfold Equation2444. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff8_inst, reff8_op in H. discriminate H. Qed.

Lemma reff8_not2447 : ~ @Equation2447 Fin2 reff8_inst.
Proof. unfold Equation2447. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff8_inst, reff8_op in H. discriminate H. Qed.

Lemma reff8_not2450 : ~ @Equation2450 Fin2 reff8_inst.
Proof. unfold Equation2450. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff8_inst, reff8_op in H. discriminate H. Qed.

Lemma reff8_not2457 : ~ @Equation2457 Fin2 reff8_inst.
Proof. unfold Equation2457. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff8_inst, reff8_op in H. discriminate H. Qed.

Lemma reff8_not2460 : ~ @Equation2460 Fin2 reff8_inst.
Proof. unfold Equation2460. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff8_inst, reff8_op in H. discriminate H. Qed.

Lemma reff8_not2467 : ~ @Equation2467 Fin2 reff8_inst.
Proof. unfold Equation2467. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff8_inst, reff8_op in H. discriminate H. Qed.

Lemma reff8_not2470 : ~ @Equation2470 Fin2 reff8_inst.
Proof. unfold Equation2470. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff8_inst, reff8_op in H. discriminate H. Qed.

Lemma reff8_not2494 : ~ @Equation2494 Fin2 reff8_inst.
Proof. unfold Equation2494. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff8_inst, reff8_op in H. discriminate H. Qed.

Lemma reff8_not2497 : ~ @Equation2497 Fin2 reff8_inst.
Proof. unfold Equation2497. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff8_inst, reff8_op in H. discriminate H. Qed.

Lemma reff8_not2504 : ~ @Equation2504 Fin2 reff8_inst.
Proof. unfold Equation2504. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff8_inst, reff8_op in H. discriminate H. Qed.

Lemma reff8_not2507 : ~ @Equation2507 Fin2 reff8_inst.
Proof. unfold Equation2507. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff8_inst, reff8_op in H. discriminate H. Qed.

Lemma reff8_not2531 : ~ @Equation2531 Fin2 reff8_inst.
Proof. unfold Equation2531. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff8_inst, reff8_op in H. discriminate H. Qed.

Lemma reff8_not2534 : ~ @Equation2534 Fin2 reff8_inst.
Proof. unfold Equation2534. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff8_inst, reff8_op in H. discriminate H. Qed.

Lemma reff8_not2541 : ~ @Equation2541 Fin2 reff8_inst.
Proof. unfold Equation2541. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff8_inst, reff8_op in H. discriminate H. Qed.

Lemma reff8_not2645 : ~ @Equation2645 Fin2 reff8_inst.
Proof. unfold Equation2645. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff8_inst, reff8_op in H. discriminate H. Qed.

Lemma reff8_not2647 : ~ @Equation2647 Fin2 reff8_inst.
Proof. unfold Equation2647. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff8_inst, reff8_op in H. discriminate H. Qed.

Lemma reff8_not2650 : ~ @Equation2650 Fin2 reff8_inst.
Proof. unfold Equation2650. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff8_inst, reff8_op in H. discriminate H. Qed.

Lemma reff8_not2653 : ~ @Equation2653 Fin2 reff8_inst.
Proof. unfold Equation2653. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff8_inst, reff8_op in H. discriminate H. Qed.

Lemma reff8_not2660 : ~ @Equation2660 Fin2 reff8_inst.
Proof. unfold Equation2660. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff8_inst, reff8_op in H. discriminate H. Qed.

Lemma reff8_not2663 : ~ @Equation2663 Fin2 reff8_inst.
Proof. unfold Equation2663. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff8_inst, reff8_op in H. discriminate H. Qed.

Lemma reff8_not2670 : ~ @Equation2670 Fin2 reff8_inst.
Proof. unfold Equation2670. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff8_inst, reff8_op in H. discriminate H. Qed.

Lemma reff8_not2673 : ~ @Equation2673 Fin2 reff8_inst.
Proof. unfold Equation2673. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff8_inst, reff8_op in H. discriminate H. Qed.

Lemma reff8_not2697 : ~ @Equation2697 Fin2 reff8_inst.
Proof. unfold Equation2697. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff8_inst, reff8_op in H. discriminate H. Qed.

Lemma reff8_not2700 : ~ @Equation2700 Fin2 reff8_inst.
Proof. unfold Equation2700. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff8_inst, reff8_op in H. discriminate H. Qed.

Lemma reff8_not2707 : ~ @Equation2707 Fin2 reff8_inst.
Proof. unfold Equation2707. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff8_inst, reff8_op in H. discriminate H. Qed.

Lemma reff8_not2710 : ~ @Equation2710 Fin2 reff8_inst.
Proof. unfold Equation2710. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff8_inst, reff8_op in H. discriminate H. Qed.

Lemma reff8_not2734 : ~ @Equation2734 Fin2 reff8_inst.
Proof. unfold Equation2734. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff8_inst, reff8_op in H. discriminate H. Qed.

Lemma reff8_not2737 : ~ @Equation2737 Fin2 reff8_inst.
Proof. unfold Equation2737. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff8_inst, reff8_op in H. discriminate H. Qed.

Lemma reff8_not2744 : ~ @Equation2744 Fin2 reff8_inst.
Proof. unfold Equation2744. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff8_inst, reff8_op in H. discriminate H. Qed.

Lemma reff8_not2848 : ~ @Equation2848 Fin2 reff8_inst.
Proof. unfold Equation2848. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff8_inst, reff8_op in H. discriminate H. Qed.

Lemma reff8_not2850 : ~ @Equation2850 Fin2 reff8_inst.
Proof. unfold Equation2850. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff8_inst, reff8_op in H. discriminate H. Qed.

Lemma reff8_not2853 : ~ @Equation2853 Fin2 reff8_inst.
Proof. unfold Equation2853. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff8_inst, reff8_op in H. discriminate H. Qed.

Lemma reff8_not2856 : ~ @Equation2856 Fin2 reff8_inst.
Proof. unfold Equation2856. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff8_inst, reff8_op in H. discriminate H. Qed.

Lemma reff8_not2863 : ~ @Equation2863 Fin2 reff8_inst.
Proof. unfold Equation2863. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff8_inst, reff8_op in H. discriminate H. Qed.

Lemma reff8_not2866 : ~ @Equation2866 Fin2 reff8_inst.
Proof. unfold Equation2866. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff8_inst, reff8_op in H. discriminate H. Qed.

Lemma reff8_not2873 : ~ @Equation2873 Fin2 reff8_inst.
Proof. unfold Equation2873. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff8_inst, reff8_op in H. discriminate H. Qed.

Lemma reff8_not2876 : ~ @Equation2876 Fin2 reff8_inst.
Proof. unfold Equation2876. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff8_inst, reff8_op in H. discriminate H. Qed.

Lemma reff8_not2900 : ~ @Equation2900 Fin2 reff8_inst.
Proof. unfold Equation2900. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff8_inst, reff8_op in H. discriminate H. Qed.

Lemma reff8_not2903 : ~ @Equation2903 Fin2 reff8_inst.
Proof. unfold Equation2903. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff8_inst, reff8_op in H. discriminate H. Qed.

Lemma reff8_not2910 : ~ @Equation2910 Fin2 reff8_inst.
Proof. unfold Equation2910. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff8_inst, reff8_op in H. discriminate H. Qed.

Lemma reff8_not2913 : ~ @Equation2913 Fin2 reff8_inst.
Proof. unfold Equation2913. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff8_inst, reff8_op in H. discriminate H. Qed.

Lemma reff8_not2937 : ~ @Equation2937 Fin2 reff8_inst.
Proof. unfold Equation2937. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff8_inst, reff8_op in H. discriminate H. Qed.

Lemma reff8_not2940 : ~ @Equation2940 Fin2 reff8_inst.
Proof. unfold Equation2940. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff8_inst, reff8_op in H. discriminate H. Qed.

Lemma reff8_not2947 : ~ @Equation2947 Fin2 reff8_inst.
Proof. unfold Equation2947. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff8_inst, reff8_op in H. discriminate H. Qed.

Lemma reff8_not3051 : ~ @Equation3051 Fin2 reff8_inst.
Proof. unfold Equation3051. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff8_inst, reff8_op in H. discriminate H. Qed.

Lemma reff8_not3053 : ~ @Equation3053 Fin2 reff8_inst.
Proof. unfold Equation3053. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff8_inst, reff8_op in H. discriminate H. Qed.

Lemma reff8_not3056 : ~ @Equation3056 Fin2 reff8_inst.
Proof. unfold Equation3056. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff8_inst, reff8_op in H. discriminate H. Qed.

Lemma reff8_not3059 : ~ @Equation3059 Fin2 reff8_inst.
Proof. unfold Equation3059. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff8_inst, reff8_op in H. discriminate H. Qed.

Lemma reff8_not3066 : ~ @Equation3066 Fin2 reff8_inst.
Proof. unfold Equation3066. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff8_inst, reff8_op in H. discriminate H. Qed.

Lemma reff8_not3069 : ~ @Equation3069 Fin2 reff8_inst.
Proof. unfold Equation3069. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff8_inst, reff8_op in H. discriminate H. Qed.

Lemma reff8_not3076 : ~ @Equation3076 Fin2 reff8_inst.
Proof. unfold Equation3076. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff8_inst, reff8_op in H. discriminate H. Qed.

Lemma reff8_not3079 : ~ @Equation3079 Fin2 reff8_inst.
Proof. unfold Equation3079. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff8_inst, reff8_op in H. discriminate H. Qed.

Lemma reff8_not3103 : ~ @Equation3103 Fin2 reff8_inst.
Proof. unfold Equation3103. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff8_inst, reff8_op in H. discriminate H. Qed.

Lemma reff8_not3106 : ~ @Equation3106 Fin2 reff8_inst.
Proof. unfold Equation3106. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff8_inst, reff8_op in H. discriminate H. Qed.

Lemma reff8_not3113 : ~ @Equation3113 Fin2 reff8_inst.
Proof. unfold Equation3113. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff8_inst, reff8_op in H. discriminate H. Qed.

Lemma reff8_not3116 : ~ @Equation3116 Fin2 reff8_inst.
Proof. unfold Equation3116. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff8_inst, reff8_op in H. discriminate H. Qed.

Lemma reff8_not3140 : ~ @Equation3140 Fin2 reff8_inst.
Proof. unfold Equation3140. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff8_inst, reff8_op in H. discriminate H. Qed.

Lemma reff8_not3143 : ~ @Equation3143 Fin2 reff8_inst.
Proof. unfold Equation3143. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff8_inst, reff8_op in H. discriminate H. Qed.

Lemma reff8_not3150 : ~ @Equation3150 Fin2 reff8_inst.
Proof. unfold Equation3150. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff8_inst, reff8_op in H. discriminate H. Qed.

Lemma reff8_not3254 : ~ @Equation3254 Fin2 reff8_inst.
Proof. unfold Equation3254. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff8_inst, reff8_op in H. discriminate H. Qed.

Lemma reff8_not3256 : ~ @Equation3256 Fin2 reff8_inst.
Proof. unfold Equation3256. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff8_inst, reff8_op in H. discriminate H. Qed.

Lemma reff8_not3259 : ~ @Equation3259 Fin2 reff8_inst.
Proof. unfold Equation3259. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff8_inst, reff8_op in H. discriminate H. Qed.

Lemma reff8_not3262 : ~ @Equation3262 Fin2 reff8_inst.
Proof. unfold Equation3262. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff8_inst, reff8_op in H. discriminate H. Qed.

Lemma reff8_not3269 : ~ @Equation3269 Fin2 reff8_inst.
Proof. unfold Equation3269. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff8_inst, reff8_op in H. discriminate H. Qed.

Lemma reff8_not3272 : ~ @Equation3272 Fin2 reff8_inst.
Proof. unfold Equation3272. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff8_inst, reff8_op in H. discriminate H. Qed.

Lemma reff8_not3279 : ~ @Equation3279 Fin2 reff8_inst.
Proof. unfold Equation3279. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff8_inst, reff8_op in H. discriminate H. Qed.

Lemma reff8_not3308 : ~ @Equation3308 Fin2 reff8_inst.
Proof. unfold Equation3308. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff8_inst, reff8_op in H. discriminate H. Qed.

Lemma reff8_not3315 : ~ @Equation3315 Fin2 reff8_inst.
Proof. unfold Equation3315. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff8_inst, reff8_op in H. discriminate H. Qed.

Lemma reff8_not3318 : ~ @Equation3318 Fin2 reff8_inst.
Proof. unfold Equation3318. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff8_inst, reff8_op in H. discriminate H. Qed.

Lemma reff8_not3342 : ~ @Equation3342 Fin2 reff8_inst.
Proof. unfold Equation3342. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff8_inst, reff8_op in H. discriminate H. Qed.

Lemma reff8_not3345 : ~ @Equation3345 Fin2 reff8_inst.
Proof. unfold Equation3345. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff8_inst, reff8_op in H. discriminate H. Qed.

Lemma reff8_not3352 : ~ @Equation3352 Fin2 reff8_inst.
Proof. unfold Equation3352. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff8_inst, reff8_op in H. discriminate H. Qed.

Lemma reff8_not3355 : ~ @Equation3355 Fin2 reff8_inst.
Proof. unfold Equation3355. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff8_inst, reff8_op in H. discriminate H. Qed.

Lemma reff8_not3457 : ~ @Equation3457 Fin2 reff8_inst.
Proof. unfold Equation3457. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff8_inst, reff8_op in H. discriminate H. Qed.

Lemma reff8_not3459 : ~ @Equation3459 Fin2 reff8_inst.
Proof. unfold Equation3459. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff8_inst, reff8_op in H. discriminate H. Qed.

Lemma reff8_not3462 : ~ @Equation3462 Fin2 reff8_inst.
Proof. unfold Equation3462. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff8_inst, reff8_op in H. discriminate H. Qed.

Lemma reff8_not3465 : ~ @Equation3465 Fin2 reff8_inst.
Proof. unfold Equation3465. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff8_inst, reff8_op in H. discriminate H. Qed.

Lemma reff8_not3472 : ~ @Equation3472 Fin2 reff8_inst.
Proof. unfold Equation3472. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff8_inst, reff8_op in H. discriminate H. Qed.

Lemma reff8_not3475 : ~ @Equation3475 Fin2 reff8_inst.
Proof. unfold Equation3475. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff8_inst, reff8_op in H. discriminate H. Qed.

Lemma reff8_not3482 : ~ @Equation3482 Fin2 reff8_inst.
Proof. unfold Equation3482. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff8_inst, reff8_op in H. discriminate H. Qed.

Lemma reff8_not3511 : ~ @Equation3511 Fin2 reff8_inst.
Proof. unfold Equation3511. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff8_inst, reff8_op in H. discriminate H. Qed.

Lemma reff8_not3518 : ~ @Equation3518 Fin2 reff8_inst.
Proof. unfold Equation3518. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff8_inst, reff8_op in H. discriminate H. Qed.

Lemma reff8_not3521 : ~ @Equation3521 Fin2 reff8_inst.
Proof. unfold Equation3521. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff8_inst, reff8_op in H. discriminate H. Qed.

Lemma reff8_not3545 : ~ @Equation3545 Fin2 reff8_inst.
Proof. unfold Equation3545. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff8_inst, reff8_op in H. discriminate H. Qed.

Lemma reff8_not3548 : ~ @Equation3548 Fin2 reff8_inst.
Proof. unfold Equation3548. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff8_inst, reff8_op in H. discriminate H. Qed.

Lemma reff8_not3555 : ~ @Equation3555 Fin2 reff8_inst.
Proof. unfold Equation3555. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff8_inst, reff8_op in H. discriminate H. Qed.

Lemma reff8_not3558 : ~ @Equation3558 Fin2 reff8_inst.
Proof. unfold Equation3558. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff8_inst, reff8_op in H. discriminate H. Qed.

Lemma reff8_not3660 : ~ @Equation3660 Fin2 reff8_inst.
Proof. unfold Equation3660. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff8_inst, reff8_op in H. discriminate H. Qed.

Lemma reff8_not3662 : ~ @Equation3662 Fin2 reff8_inst.
Proof. unfold Equation3662. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff8_inst, reff8_op in H. discriminate H. Qed.

Lemma reff8_not3665 : ~ @Equation3665 Fin2 reff8_inst.
Proof. unfold Equation3665. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff8_inst, reff8_op in H. discriminate H. Qed.

Lemma reff8_not3668 : ~ @Equation3668 Fin2 reff8_inst.
Proof. unfold Equation3668. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff8_inst, reff8_op in H. discriminate H. Qed.

Lemma reff8_not3675 : ~ @Equation3675 Fin2 reff8_inst.
Proof. unfold Equation3675. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff8_inst, reff8_op in H. discriminate H. Qed.

Lemma reff8_not3678 : ~ @Equation3678 Fin2 reff8_inst.
Proof. unfold Equation3678. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff8_inst, reff8_op in H. discriminate H. Qed.

Lemma reff8_not3685 : ~ @Equation3685 Fin2 reff8_inst.
Proof. unfold Equation3685. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff8_inst, reff8_op in H. discriminate H. Qed.

Lemma reff8_not3714 : ~ @Equation3714 Fin2 reff8_inst.
Proof. unfold Equation3714. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff8_inst, reff8_op in H. discriminate H. Qed.

Lemma reff8_not3721 : ~ @Equation3721 Fin2 reff8_inst.
Proof. unfold Equation3721. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff8_inst, reff8_op in H. discriminate H. Qed.

Lemma reff8_not3724 : ~ @Equation3724 Fin2 reff8_inst.
Proof. unfold Equation3724. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff8_inst, reff8_op in H. discriminate H. Qed.

Lemma reff8_not3748 : ~ @Equation3748 Fin2 reff8_inst.
Proof. unfold Equation3748. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff8_inst, reff8_op in H. discriminate H. Qed.

Lemma reff8_not3751 : ~ @Equation3751 Fin2 reff8_inst.
Proof. unfold Equation3751. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff8_inst, reff8_op in H. discriminate H. Qed.

Lemma reff8_not3758 : ~ @Equation3758 Fin2 reff8_inst.
Proof. unfold Equation3758. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff8_inst, reff8_op in H. discriminate H. Qed.

Lemma reff8_not3761 : ~ @Equation3761 Fin2 reff8_inst.
Proof. unfold Equation3761. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff8_inst, reff8_op in H. discriminate H. Qed.

Lemma reff8_not3865 : ~ @Equation3865 Fin2 reff8_inst.
Proof. unfold Equation3865. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff8_inst, reff8_op in H. discriminate H. Qed.

Lemma reff8_not3868 : ~ @Equation3868 Fin2 reff8_inst.
Proof. unfold Equation3868. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff8_inst, reff8_op in H. discriminate H. Qed.

Lemma reff8_not3871 : ~ @Equation3871 Fin2 reff8_inst.
Proof. unfold Equation3871. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff8_inst, reff8_op in H. discriminate H. Qed.

Lemma reff8_not3878 : ~ @Equation3878 Fin2 reff8_inst.
Proof. unfold Equation3878. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff8_inst, reff8_op in H. discriminate H. Qed.

Lemma reff8_not3881 : ~ @Equation3881 Fin2 reff8_inst.
Proof. unfold Equation3881. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff8_inst, reff8_op in H. discriminate H. Qed.

Lemma reff8_not3888 : ~ @Equation3888 Fin2 reff8_inst.
Proof. unfold Equation3888. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff8_inst, reff8_op in H. discriminate H. Qed.

Lemma reff8_not3917 : ~ @Equation3917 Fin2 reff8_inst.
Proof. unfold Equation3917. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff8_inst, reff8_op in H. discriminate H. Qed.

Lemma reff8_not3924 : ~ @Equation3924 Fin2 reff8_inst.
Proof. unfold Equation3924. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff8_inst, reff8_op in H. discriminate H. Qed.

Lemma reff8_not3927 : ~ @Equation3927 Fin2 reff8_inst.
Proof. unfold Equation3927. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff8_inst, reff8_op in H. discriminate H. Qed.

Lemma reff8_not3951 : ~ @Equation3951 Fin2 reff8_inst.
Proof. unfold Equation3951. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff8_inst, reff8_op in H. discriminate H. Qed.

Lemma reff8_not3954 : ~ @Equation3954 Fin2 reff8_inst.
Proof. unfold Equation3954. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff8_inst, reff8_op in H. discriminate H. Qed.

Lemma reff8_not3961 : ~ @Equation3961 Fin2 reff8_inst.
Proof. unfold Equation3961. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff8_inst, reff8_op in H. discriminate H. Qed.

Lemma reff8_not3964 : ~ @Equation3964 Fin2 reff8_inst.
Proof. unfold Equation3964. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff8_inst, reff8_op in H. discriminate H. Qed.

Lemma reff8_not4066 : ~ @Equation4066 Fin2 reff8_inst.
Proof. unfold Equation4066. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff8_inst, reff8_op in H. discriminate H. Qed.

Lemma reff8_not4068 : ~ @Equation4068 Fin2 reff8_inst.
Proof. unfold Equation4068. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff8_inst, reff8_op in H. discriminate H. Qed.

Lemma reff8_not4071 : ~ @Equation4071 Fin2 reff8_inst.
Proof. unfold Equation4071. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff8_inst, reff8_op in H. discriminate H. Qed.

Lemma reff8_not4074 : ~ @Equation4074 Fin2 reff8_inst.
Proof. unfold Equation4074. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff8_inst, reff8_op in H. discriminate H. Qed.

Lemma reff8_not4081 : ~ @Equation4081 Fin2 reff8_inst.
Proof. unfold Equation4081. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff8_inst, reff8_op in H. discriminate H. Qed.

Lemma reff8_not4084 : ~ @Equation4084 Fin2 reff8_inst.
Proof. unfold Equation4084. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff8_inst, reff8_op in H. discriminate H. Qed.

Lemma reff8_not4091 : ~ @Equation4091 Fin2 reff8_inst.
Proof. unfold Equation4091. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff8_inst, reff8_op in H. discriminate H. Qed.

Lemma reff8_not4120 : ~ @Equation4120 Fin2 reff8_inst.
Proof. unfold Equation4120. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff8_inst, reff8_op in H. discriminate H. Qed.

Lemma reff8_not4127 : ~ @Equation4127 Fin2 reff8_inst.
Proof. unfold Equation4127. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff8_inst, reff8_op in H. discriminate H. Qed.

Lemma reff8_not4130 : ~ @Equation4130 Fin2 reff8_inst.
Proof. unfold Equation4130. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff8_inst, reff8_op in H. discriminate H. Qed.

Lemma reff8_not4154 : ~ @Equation4154 Fin2 reff8_inst.
Proof. unfold Equation4154. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff8_inst, reff8_op in H. discriminate H. Qed.

Lemma reff8_not4157 : ~ @Equation4157 Fin2 reff8_inst.
Proof. unfold Equation4157. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff8_inst, reff8_op in H. discriminate H. Qed.

Lemma reff8_not4164 : ~ @Equation4164 Fin2 reff8_inst.
Proof. unfold Equation4164. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff8_inst, reff8_op in H. discriminate H. Qed.

Lemma reff8_not4167 : ~ @Equation4167 Fin2 reff8_inst.
Proof. unfold Equation4167. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff8_inst, reff8_op in H. discriminate H. Qed.

Lemma reff8_not4268 : ~ @Equation4268 Fin2 reff8_inst.
Proof. unfold Equation4268. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff8_inst, reff8_op in H. discriminate H. Qed.

Lemma reff8_not4270 : ~ @Equation4270 Fin2 reff8_inst.
Proof. unfold Equation4270. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff8_inst, reff8_op in H. discriminate H. Qed.

Lemma reff8_not4273 : ~ @Equation4273 Fin2 reff8_inst.
Proof. unfold Equation4273. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff8_inst, reff8_op in H. discriminate H. Qed.

Lemma reff8_not4276 : ~ @Equation4276 Fin2 reff8_inst.
Proof. unfold Equation4276. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff8_inst, reff8_op in H. discriminate H. Qed.

Lemma reff8_not4283 : ~ @Equation4283 Fin2 reff8_inst.
Proof. unfold Equation4283. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff8_inst, reff8_op in H. discriminate H. Qed.

Lemma reff8_not4290 : ~ @Equation4290 Fin2 reff8_inst.
Proof. unfold Equation4290. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff8_inst, reff8_op in H. discriminate H. Qed.

Lemma reff8_not4293 : ~ @Equation4293 Fin2 reff8_inst.
Proof. unfold Equation4293. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff8_inst, reff8_op in H. discriminate H. Qed.

Lemma reff8_not4314 : ~ @Equation4314 Fin2 reff8_inst.
Proof. unfold Equation4314. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff8_inst, reff8_op in H. discriminate H. Qed.

Lemma reff8_not4321 : ~ @Equation4321 Fin2 reff8_inst.
Proof. unfold Equation4321. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff8_inst, reff8_op in H. discriminate H. Qed.

Lemma reff8_not4343 : ~ @Equation4343 Fin2 reff8_inst.
Proof. unfold Equation4343. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff8_inst, reff8_op in H. discriminate H. Qed.

Lemma reff8_not4398 : ~ @Equation4398 Fin2 reff8_inst.
Proof. unfold Equation4398. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff8_inst, reff8_op in H. discriminate H. Qed.

Lemma reff8_not4405 : ~ @Equation4405 Fin2 reff8_inst.
Proof. unfold Equation4405. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff8_inst, reff8_op in H. discriminate H. Qed.

Lemma reff8_not4408 : ~ @Equation4408 Fin2 reff8_inst.
Proof. unfold Equation4408. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff8_inst, reff8_op in H. discriminate H. Qed.

Lemma reff8_not4433 : ~ @Equation4433 Fin2 reff8_inst.
Proof. unfold Equation4433. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff8_inst, reff8_op in H. discriminate H. Qed.

Lemma reff8_not4436 : ~ @Equation4436 Fin2 reff8_inst.
Proof. unfold Equation4436. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff8_inst, reff8_op in H. discriminate H. Qed.

Lemma reff8_not4443 : ~ @Equation4443 Fin2 reff8_inst.
Proof. unfold Equation4443. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff8_inst, reff8_op in H. discriminate H. Qed.

Lemma reff8_not4472 : ~ @Equation4472 Fin2 reff8_inst.
Proof. unfold Equation4472. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff8_inst, reff8_op in H. discriminate H. Qed.

Lemma reff8_not4479 : ~ @Equation4479 Fin2 reff8_inst.
Proof. unfold Equation4479. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff8_inst, reff8_op in H. discriminate H. Qed.

Lemma reff8_not4482 : ~ @Equation4482 Fin2 reff8_inst.
Proof. unfold Equation4482. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff8_inst, reff8_op in H. discriminate H. Qed.

Lemma reff8_not4583 : ~ @Equation4583 Fin2 reff8_inst.
Proof. unfold Equation4583. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff8_inst, reff8_op in H. discriminate H. Qed.

Lemma reff8_not4585 : ~ @Equation4585 Fin2 reff8_inst.
Proof. unfold Equation4585. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff8_inst, reff8_op in H. discriminate H. Qed.

Lemma reff8_not4588 : ~ @Equation4588 Fin2 reff8_inst.
Proof. unfold Equation4588. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff8_inst, reff8_op in H. discriminate H. Qed.

Lemma reff8_not4591 : ~ @Equation4591 Fin2 reff8_inst.
Proof. unfold Equation4591. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff8_inst, reff8_op in H. discriminate H. Qed.

Lemma reff8_not4598 : ~ @Equation4598 Fin2 reff8_inst.
Proof. unfold Equation4598. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff8_inst, reff8_op in H. discriminate H. Qed.

Lemma reff8_not4605 : ~ @Equation4605 Fin2 reff8_inst.
Proof. unfold Equation4605. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff8_inst, reff8_op in H. discriminate H. Qed.

Lemma reff8_not4608 : ~ @Equation4608 Fin2 reff8_inst.
Proof. unfold Equation4608. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff8_inst, reff8_op in H. discriminate H. Qed.

Lemma reff8_not4629 : ~ @Equation4629 Fin2 reff8_inst.
Proof. unfold Equation4629. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff8_inst, reff8_op in H. discriminate H. Qed.

Lemma reff8_not4636 : ~ @Equation4636 Fin2 reff8_inst.
Proof. unfold Equation4636. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff8_inst, reff8_op in H. discriminate H. Qed.

Lemma reff8_not4658 : ~ @Equation4658 Fin2 reff8_inst.
Proof. unfold Equation4658. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff8_inst, reff8_op in H. discriminate H. Qed.

(** ---- reff82 (Fin2) ---- *)

Definition reff82_op (x y : Fin2) : Fin2 :=
  match x, y with
  | F2_0, F2_0 => F2_0 | F2_0, F2_1 => F2_0
  | F2_1, F2_0 => F2_1 | F2_1, F2_1 => F2_0
  end.

#[local] Instance reff82_inst : Magma Fin2 := {| magma_op := reff82_op |}.

Lemma reff82_sat10 : @Equation10 Fin2 reff82_inst.
Proof. unfold Equation10, magma_op, reff82_inst, reff82_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff82_sat11 : @Equation11 Fin2 reff82_inst.
Proof. unfold Equation11, magma_op, reff82_inst, reff82_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff82_sat106 : @Equation106 Fin2 reff82_inst.
Proof. unfold Equation106, magma_op, reff82_inst, reff82_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff82_sat109 : @Equation109 Fin2 reff82_inst.
Proof. unfold Equation109, magma_op, reff82_inst, reff82_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff82_sat111 : @Equation111 Fin2 reff82_inst.
Proof. unfold Equation111, magma_op, reff82_inst, reff82_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff82_sat371 : @Equation371 Fin2 reff82_inst.
Proof. unfold Equation371, magma_op, reff82_inst, reff82_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff82_sat378 : @Equation378 Fin2 reff82_inst.
Proof. unfold Equation378, magma_op, reff82_inst, reff82_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff82_sat433 : @Equation433 Fin2 reff82_inst.
Proof. unfold Equation433, magma_op, reff82_inst, reff82_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff82_sat434 : @Equation434 Fin2 reff82_inst.
Proof. unfold Equation434, magma_op, reff82_inst, reff82_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff82_sat442 : @Equation442 Fin2 reff82_inst.
Proof. unfold Equation442, magma_op, reff82_inst, reff82_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff82_sat443 : @Equation443 Fin2 reff82_inst.
Proof. unfold Equation443, magma_op, reff82_inst, reff82_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff82_sat854 : @Equation854 Fin2 reff82_inst.
Proof. unfold Equation854, magma_op, reff82_inst, reff82_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff82_sat1043 : @Equation1043 Fin2 reff82_inst.
Proof. unfold Equation1043, magma_op, reff82_inst, reff82_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff82_sat1053 : @Equation1053 Fin2 reff82_inst.
Proof. unfold Equation1053, magma_op, reff82_inst, reff82_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff82_sat1247 : @Equation1247 Fin2 reff82_inst.
Proof. unfold Equation1247, magma_op, reff82_inst, reff82_op. intros x y z w. destruct x, y, z, w; reflexivity. Qed.

Lemma reff82_sat1257 : @Equation1257 Fin2 reff82_inst.
Proof. unfold Equation1257, magma_op, reff82_inst, reff82_op. intros x y z w. destruct x, y, z, w; reflexivity. Qed.

Lemma reff82_sat1265 : @Equation1265 Fin2 reff82_inst.
Proof. unfold Equation1265, magma_op, reff82_inst, reff82_op. intros x y z w. destruct x, y, z, w; reflexivity. Qed.

Lemma reff82_sat1271 : @Equation1271 Fin2 reff82_inst.
Proof. unfold Equation1271, magma_op, reff82_inst, reff82_op. intros x y z w. destruct x, y, z, w; reflexivity. Qed.

Lemma reff82_sat1855 : @Equation1855 Fin2 reff82_inst.
Proof. unfold Equation1855, magma_op, reff82_inst, reff82_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff82_sat1863 : @Equation1863 Fin2 reff82_inst.
Proof. unfold Equation1863, magma_op, reff82_inst, reff82_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff82_sat3285 : @Equation3285 Fin2 reff82_inst.
Proof. unfold Equation3285, magma_op, reff82_inst, reff82_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff82_sat3306 : @Equation3306 Fin2 reff82_inst.
Proof. unfold Equation3306, magma_op, reff82_inst, reff82_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff82_sat3321 : @Equation3321 Fin2 reff82_inst.
Proof. unfold Equation3321, magma_op, reff82_inst, reff82_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff82_sat3726 : @Equation3726 Fin2 reff82_inst.
Proof. unfold Equation3726, magma_op, reff82_inst, reff82_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff82_sat3727 : @Equation3727 Fin2 reff82_inst.
Proof. unfold Equation3727, magma_op, reff82_inst, reff82_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff82_sat3895 : @Equation3895 Fin2 reff82_inst.
Proof. unfold Equation3895, magma_op, reff82_inst, reff82_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff82_sat3931 : @Equation3931 Fin2 reff82_inst.
Proof. unfold Equation3931, magma_op, reff82_inst, reff82_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff82_sat4087 : @Equation4087 Fin2 reff82_inst.
Proof. unfold Equation4087, magma_op, reff82_inst, reff82_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff82_sat4293 : @Equation4293 Fin2 reff82_inst.
Proof. unfold Equation4293, magma_op, reff82_inst, reff82_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff82_sat4318 : @Equation4318 Fin2 reff82_inst.
Proof. unfold Equation4318, magma_op, reff82_inst, reff82_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff82_sat4673 : @Equation4673 Fin2 reff82_inst.
Proof. unfold Equation4673, magma_op, reff82_inst, reff82_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff82_not47 : ~ @Equation47 Fin2 reff82_inst.
Proof. unfold Equation47. intro H. specialize (H F2_1). unfold magma_op, reff82_inst, reff82_op in H. discriminate H. Qed.

Lemma reff82_not102 : ~ @Equation102 Fin2 reff82_inst.
Proof. unfold Equation102. intro H. specialize (H F2_1 F2_0). unfold magma_op, reff82_inst, reff82_op in H. discriminate H. Qed.

Lemma reff82_not115 : ~ @Equation115 Fin2 reff82_inst.
Proof. unfold Equation115. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff82_inst, reff82_op in H. discriminate H. Qed.

Lemma reff82_not117 : ~ @Equation117 Fin2 reff82_inst.
Proof. unfold Equation117. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff82_inst, reff82_op in H. discriminate H. Qed.

Lemma reff82_not118 : ~ @Equation118 Fin2 reff82_inst.
Proof. unfold Equation118. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff82_inst, reff82_op in H. discriminate H. Qed.

Lemma reff82_not124 : ~ @Equation124 Fin2 reff82_inst.
Proof. unfold Equation124. intro H. specialize (H F2_1 F2_0). unfold magma_op, reff82_inst, reff82_op in H. discriminate H. Qed.

Lemma reff82_not125 : ~ @Equation125 Fin2 reff82_inst.
Proof. unfold Equation125. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff82_inst, reff82_op in H. discriminate H. Qed.

Lemma reff82_not127 : ~ @Equation127 Fin2 reff82_inst.
Proof. unfold Equation127. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff82_inst, reff82_op in H. discriminate H. Qed.

Lemma reff82_not151 : ~ @Equation151 Fin2 reff82_inst.
Proof. unfold Equation151. intro H. specialize (H F2_1). unfold magma_op, reff82_inst, reff82_op in H. discriminate H. Qed.

Lemma reff82_not203 : ~ @Equation203 Fin2 reff82_inst.
Proof. unfold Equation203. intro H. specialize (H F2_1). unfold magma_op, reff82_inst, reff82_op in H. discriminate H. Qed.

Lemma reff82_not255 : ~ @Equation255 Fin2 reff82_inst.
Proof. unfold Equation255. intro H. specialize (H F2_1). unfold magma_op, reff82_inst, reff82_op in H. discriminate H. Qed.

Lemma reff82_not307 : ~ @Equation307 Fin2 reff82_inst.
Proof. unfold Equation307. intro H. specialize (H F2_1). unfold magma_op, reff82_inst, reff82_op in H. discriminate H. Qed.

Lemma reff82_not412 : ~ @Equation412 Fin2 reff82_inst.
Proof. unfold Equation412. intro H. specialize (H F2_1 F2_0). unfold magma_op, reff82_inst, reff82_op in H. discriminate H. Qed.

Lemma reff82_not416 : ~ @Equation416 Fin2 reff82_inst.
Proof. unfold Equation416. intro H. specialize (H F2_1 F2_0). unfold magma_op, reff82_inst, reff82_op in H. discriminate H. Qed.

Lemma reff82_not417 : ~ @Equation417 Fin2 reff82_inst.
Proof. unfold Equation417. intro H. specialize (H F2_1 F2_0). unfold magma_op, reff82_inst, reff82_op in H. discriminate H. Qed.

Lemma reff82_not419 : ~ @Equation419 Fin2 reff82_inst.
Proof. unfold Equation419. intro H. specialize (H F2_1 F2_0). unfold magma_op, reff82_inst, reff82_op in H. discriminate H. Qed.

Lemma reff82_not420 : ~ @Equation420 Fin2 reff82_inst.
Proof. unfold Equation420. intro H. specialize (H F2_1 F2_0). unfold magma_op, reff82_inst, reff82_op in H. discriminate H. Qed.

Lemma reff82_not463 : ~ @Equation463 Fin2 reff82_inst.
Proof. unfold Equation463. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff82_inst, reff82_op in H. discriminate H. Qed.

Lemma reff82_not464 : ~ @Equation464 Fin2 reff82_inst.
Proof. unfold Equation464. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff82_inst, reff82_op in H. discriminate H. Qed.

Lemma reff82_not466 : ~ @Equation466 Fin2 reff82_inst.
Proof. unfold Equation466. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff82_inst, reff82_op in H. discriminate H. Qed.

Lemma reff82_not467 : ~ @Equation467 Fin2 reff82_inst.
Proof. unfold Equation467. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff82_inst, reff82_op in H. discriminate H. Qed.

Lemma reff82_not473 : ~ @Equation473 Fin2 reff82_inst.
Proof. unfold Equation473. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff82_inst, reff82_op in H. discriminate H. Qed.

Lemma reff82_not474 : ~ @Equation474 Fin2 reff82_inst.
Proof. unfold Equation474. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff82_inst, reff82_op in H. discriminate H. Qed.

Lemma reff82_not476 : ~ @Equation476 Fin2 reff82_inst.
Proof. unfold Equation476. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff82_inst, reff82_op in H. discriminate H. Qed.

Lemma reff82_not477 : ~ @Equation477 Fin2 reff82_inst.
Proof. unfold Equation477. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff82_inst, reff82_op in H. discriminate H. Qed.

Lemma reff82_not500 : ~ @Equation500 Fin2 reff82_inst.
Proof. unfold Equation500. intro H. specialize (H F2_1 F2_0). unfold magma_op, reff82_inst, reff82_op in H. discriminate H. Qed.

Lemma reff82_not501 : ~ @Equation501 Fin2 reff82_inst.
Proof. unfold Equation501. intro H. specialize (H F2_1 F2_0). unfold magma_op, reff82_inst, reff82_op in H. discriminate H. Qed.

Lemma reff82_not503 : ~ @Equation503 Fin2 reff82_inst.
Proof. unfold Equation503. intro H. specialize (H F2_1 F2_0). unfold magma_op, reff82_inst, reff82_op in H. discriminate H. Qed.

Lemma reff82_not504 : ~ @Equation504 Fin2 reff82_inst.
Proof. unfold Equation504. intro H. specialize (H F2_1 F2_0). unfold magma_op, reff82_inst, reff82_op in H. discriminate H. Qed.

Lemma reff82_not510 : ~ @Equation510 Fin2 reff82_inst.
Proof. unfold Equation510. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff82_inst, reff82_op in H. discriminate H. Qed.

Lemma reff82_not511 : ~ @Equation511 Fin2 reff82_inst.
Proof. unfold Equation511. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff82_inst, reff82_op in H. discriminate H. Qed.

Lemma reff82_not513 : ~ @Equation513 Fin2 reff82_inst.
Proof. unfold Equation513. intro H. specialize (H F2_1 F2_0). unfold magma_op, reff82_inst, reff82_op in H. discriminate H. Qed.

Lemma reff82_not614 : ~ @Equation614 Fin2 reff82_inst.
Proof. unfold Equation614. intro H. specialize (H F2_1). unfold magma_op, reff82_inst, reff82_op in H. discriminate H. Qed.

Lemma reff82_not822 : ~ @Equation822 Fin2 reff82_inst.
Proof. unfold Equation822. intro H. specialize (H F2_1 F2_0). unfold magma_op, reff82_inst, reff82_op in H. discriminate H. Qed.

Lemma reff82_not825 : ~ @Equation825 Fin2 reff82_inst.
Proof. unfold Equation825. intro H. specialize (H F2_1 F2_0). unfold magma_op, reff82_inst, reff82_op in H. discriminate H. Qed.

Lemma reff82_not826 : ~ @Equation826 Fin2 reff82_inst.
Proof. unfold Equation826. intro H. specialize (H F2_1 F2_0). unfold magma_op, reff82_inst, reff82_op in H. discriminate H. Qed.

Lemma reff82_not869 : ~ @Equation869 Fin2 reff82_inst.
Proof. unfold Equation869. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff82_inst, reff82_op in H. discriminate H. Qed.

Lemma reff82_not870 : ~ @Equation870 Fin2 reff82_inst.
Proof. unfold Equation870. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff82_inst, reff82_op in H. discriminate H. Qed.

Lemma reff82_not872 : ~ @Equation872 Fin2 reff82_inst.
Proof. unfold Equation872. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff82_inst, reff82_op in H. discriminate H. Qed.

Lemma reff82_not873 : ~ @Equation873 Fin2 reff82_inst.
Proof. unfold Equation873. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff82_inst, reff82_op in H. discriminate H. Qed.

Lemma reff82_not879 : ~ @Equation879 Fin2 reff82_inst.
Proof. unfold Equation879. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff82_inst, reff82_op in H. discriminate H. Qed.

Lemma reff82_not880 : ~ @Equation880 Fin2 reff82_inst.
Proof. unfold Equation880. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff82_inst, reff82_op in H. discriminate H. Qed.

Lemma reff82_not882 : ~ @Equation882 Fin2 reff82_inst.
Proof. unfold Equation882. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff82_inst, reff82_op in H. discriminate H. Qed.

Lemma reff82_not883 : ~ @Equation883 Fin2 reff82_inst.
Proof. unfold Equation883. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff82_inst, reff82_op in H. discriminate H. Qed.

Lemma reff82_not906 : ~ @Equation906 Fin2 reff82_inst.
Proof. unfold Equation906. intro H. specialize (H F2_1 F2_0). unfold magma_op, reff82_inst, reff82_op in H. discriminate H. Qed.

Lemma reff82_not907 : ~ @Equation907 Fin2 reff82_inst.
Proof. unfold Equation907. intro H. specialize (H F2_1 F2_0). unfold magma_op, reff82_inst, reff82_op in H. discriminate H. Qed.

Lemma reff82_not909 : ~ @Equation909 Fin2 reff82_inst.
Proof. unfold Equation909. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff82_inst, reff82_op in H. discriminate H. Qed.

Lemma reff82_not910 : ~ @Equation910 Fin2 reff82_inst.
Proof. unfold Equation910. intro H. specialize (H F2_1 F2_0). unfold magma_op, reff82_inst, reff82_op in H. discriminate H. Qed.

Lemma reff82_not916 : ~ @Equation916 Fin2 reff82_inst.
Proof. unfold Equation916. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff82_inst, reff82_op in H. discriminate H. Qed.

Lemma reff82_not917 : ~ @Equation917 Fin2 reff82_inst.
Proof. unfold Equation917. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff82_inst, reff82_op in H. discriminate H. Qed.

Lemma reff82_not919 : ~ @Equation919 Fin2 reff82_inst.
Proof. unfold Equation919. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff82_inst, reff82_op in H. discriminate H. Qed.

Lemma reff82_not1021 : ~ @Equation1021 Fin2 reff82_inst.
Proof. unfold Equation1021. intro H. specialize (H F2_1 F2_0). unfold magma_op, reff82_inst, reff82_op in H. discriminate H. Qed.

Lemma reff82_not1026 : ~ @Equation1026 Fin2 reff82_inst.
Proof. unfold Equation1026. intro H. specialize (H F2_1 F2_0). unfold magma_op, reff82_inst, reff82_op in H. discriminate H. Qed.

Lemma reff82_not1029 : ~ @Equation1029 Fin2 reff82_inst.
Proof. unfold Equation1029. intro H. specialize (H F2_1 F2_0). unfold magma_op, reff82_inst, reff82_op in H. discriminate H. Qed.

Lemma reff82_not1072 : ~ @Equation1072 Fin2 reff82_inst.
Proof. unfold Equation1072. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff82_inst, reff82_op in H. discriminate H. Qed.

Lemma reff82_not1073 : ~ @Equation1073 Fin2 reff82_inst.
Proof. unfold Equation1073. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff82_inst, reff82_op in H. discriminate H. Qed.

Lemma reff82_not1075 : ~ @Equation1075 Fin2 reff82_inst.
Proof. unfold Equation1075. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff82_inst, reff82_op in H. discriminate H. Qed.

Lemma reff82_not1076 : ~ @Equation1076 Fin2 reff82_inst.
Proof. unfold Equation1076. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff82_inst, reff82_op in H. discriminate H. Qed.

Lemma reff82_not1082 : ~ @Equation1082 Fin2 reff82_inst.
Proof. unfold Equation1082. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff82_inst, reff82_op in H. discriminate H. Qed.

Lemma reff82_not1083 : ~ @Equation1083 Fin2 reff82_inst.
Proof. unfold Equation1083. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff82_inst, reff82_op in H. discriminate H. Qed.

Lemma reff82_not1085 : ~ @Equation1085 Fin2 reff82_inst.
Proof. unfold Equation1085. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff82_inst, reff82_op in H. discriminate H. Qed.

Lemma reff82_not1086 : ~ @Equation1086 Fin2 reff82_inst.
Proof. unfold Equation1086. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff82_inst, reff82_op in H. discriminate H. Qed.

Lemma reff82_not1109 : ~ @Equation1109 Fin2 reff82_inst.
Proof. unfold Equation1109. intro H. specialize (H F2_1 F2_0). unfold magma_op, reff82_inst, reff82_op in H. discriminate H. Qed.

Lemma reff82_not1110 : ~ @Equation1110 Fin2 reff82_inst.
Proof. unfold Equation1110. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff82_inst, reff82_op in H. discriminate H. Qed.

Lemma reff82_not1112 : ~ @Equation1112 Fin2 reff82_inst.
Proof. unfold Equation1112. intro H. specialize (H F2_1 F2_0). unfold magma_op, reff82_inst, reff82_op in H. discriminate H. Qed.

Lemma reff82_not1113 : ~ @Equation1113 Fin2 reff82_inst.
Proof. unfold Equation1113. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff82_inst, reff82_op in H. discriminate H. Qed.

Lemma reff82_not1119 : ~ @Equation1119 Fin2 reff82_inst.
Proof. unfold Equation1119. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff82_inst, reff82_op in H. discriminate H. Qed.

Lemma reff82_not1120 : ~ @Equation1120 Fin2 reff82_inst.
Proof. unfold Equation1120. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff82_inst, reff82_op in H. discriminate H. Qed.

Lemma reff82_not1122 : ~ @Equation1122 Fin2 reff82_inst.
Proof. unfold Equation1122. intro H. specialize (H F2_1 F2_0). unfold magma_op, reff82_inst, reff82_op in H. discriminate H. Qed.

Lemma reff82_not1232 : ~ @Equation1232 Fin2 reff82_inst.
Proof. unfold Equation1232. intro H. specialize (H F2_1 F2_0). unfold magma_op, reff82_inst, reff82_op in H. discriminate H. Qed.

Lemma reff82_not1275 : ~ @Equation1275 Fin2 reff82_inst.
Proof. unfold Equation1275. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff82_inst, reff82_op in H. discriminate H. Qed.

Lemma reff82_not1276 : ~ @Equation1276 Fin2 reff82_inst.
Proof. unfold Equation1276. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff82_inst, reff82_op in H. discriminate H. Qed.

Lemma reff82_not1278 : ~ @Equation1278 Fin2 reff82_inst.
Proof. unfold Equation1278. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff82_inst, reff82_op in H. discriminate H. Qed.

Lemma reff82_not1279 : ~ @Equation1279 Fin2 reff82_inst.
Proof. unfold Equation1279. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff82_inst, reff82_op in H. discriminate H. Qed.

Lemma reff82_not1285 : ~ @Equation1285 Fin2 reff82_inst.
Proof. unfold Equation1285. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff82_inst, reff82_op in H. discriminate H. Qed.

Lemma reff82_not1286 : ~ @Equation1286 Fin2 reff82_inst.
Proof. unfold Equation1286. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff82_inst, reff82_op in H. discriminate H. Qed.

Lemma reff82_not1288 : ~ @Equation1288 Fin2 reff82_inst.
Proof. unfold Equation1288. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff82_inst, reff82_op in H. discriminate H. Qed.

Lemma reff82_not1289 : ~ @Equation1289 Fin2 reff82_inst.
Proof. unfold Equation1289. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff82_inst, reff82_op in H. discriminate H. Qed.

Lemma reff82_not1312 : ~ @Equation1312 Fin2 reff82_inst.
Proof. unfold Equation1312. intro H. specialize (H F2_1 F2_0). unfold magma_op, reff82_inst, reff82_op in H. discriminate H. Qed.

Lemma reff82_not1313 : ~ @Equation1313 Fin2 reff82_inst.
Proof. unfold Equation1313. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff82_inst, reff82_op in H. discriminate H. Qed.

Lemma reff82_not1315 : ~ @Equation1315 Fin2 reff82_inst.
Proof. unfold Equation1315. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff82_inst, reff82_op in H. discriminate H. Qed.

Lemma reff82_not1316 : ~ @Equation1316 Fin2 reff82_inst.
Proof. unfold Equation1316. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff82_inst, reff82_op in H. discriminate H. Qed.

Lemma reff82_not1322 : ~ @Equation1322 Fin2 reff82_inst.
Proof. unfold Equation1322. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff82_inst, reff82_op in H. discriminate H. Qed.

Lemma reff82_not1323 : ~ @Equation1323 Fin2 reff82_inst.
Proof. unfold Equation1323. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff82_inst, reff82_op in H. discriminate H. Qed.

Lemma reff82_not1325 : ~ @Equation1325 Fin2 reff82_inst.
Proof. unfold Equation1325. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff82_inst, reff82_op in H. discriminate H. Qed.

Lemma reff82_not1426 : ~ @Equation1426 Fin2 reff82_inst.
Proof. unfold Equation1426. intro H. specialize (H F2_1). unfold magma_op, reff82_inst, reff82_op in H. discriminate H. Qed.

Lemma reff82_not1629 : ~ @Equation1629 Fin2 reff82_inst.
Proof. unfold Equation1629. intro H. specialize (H F2_1). unfold magma_op, reff82_inst, reff82_op in H. discriminate H. Qed.

Lemma reff82_not1833 : ~ @Equation1833 Fin2 reff82_inst.
Proof. unfold Equation1833. intro H. specialize (H F2_1 F2_0). unfold magma_op, reff82_inst, reff82_op in H. discriminate H. Qed.

Lemma reff82_not1837 : ~ @Equation1837 Fin2 reff82_inst.
Proof. unfold Equation1837. intro H. specialize (H F2_1 F2_0). unfold magma_op, reff82_inst, reff82_op in H. discriminate H. Qed.

Lemma reff82_not1838 : ~ @Equation1838 Fin2 reff82_inst.
Proof. unfold Equation1838. intro H. specialize (H F2_1 F2_0). unfold magma_op, reff82_inst, reff82_op in H. discriminate H. Qed.

Lemma reff82_not1840 : ~ @Equation1840 Fin2 reff82_inst.
Proof. unfold Equation1840. intro H. specialize (H F2_1 F2_0). unfold magma_op, reff82_inst, reff82_op in H. discriminate H. Qed.

Lemma reff82_not1841 : ~ @Equation1841 Fin2 reff82_inst.
Proof. unfold Equation1841. intro H. specialize (H F2_1 F2_0). unfold magma_op, reff82_inst, reff82_op in H. discriminate H. Qed.

Lemma reff82_not1848 : ~ @Equation1848 Fin2 reff82_inst.
Proof. unfold Equation1848. intro H. specialize (H F2_1 F2_0). unfold magma_op, reff82_inst, reff82_op in H. discriminate H. Qed.

Lemma reff82_not1858 : ~ @Equation1858 Fin2 reff82_inst.
Proof. unfold Equation1858. intro H. specialize (H F2_1 F2_0). unfold magma_op, reff82_inst, reff82_op in H. discriminate H. Qed.

Lemma reff82_not1884 : ~ @Equation1884 Fin2 reff82_inst.
Proof. unfold Equation1884. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff82_inst, reff82_op in H. discriminate H. Qed.

Lemma reff82_not1885 : ~ @Equation1885 Fin2 reff82_inst.
Proof. unfold Equation1885. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff82_inst, reff82_op in H. discriminate H. Qed.

Lemma reff82_not1887 : ~ @Equation1887 Fin2 reff82_inst.
Proof. unfold Equation1887. intro H. specialize (H F2_1 F2_0). unfold magma_op, reff82_inst, reff82_op in H. discriminate H. Qed.

Lemma reff82_not1888 : ~ @Equation1888 Fin2 reff82_inst.
Proof. unfold Equation1888. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff82_inst, reff82_op in H. discriminate H. Qed.

Lemma reff82_not1894 : ~ @Equation1894 Fin2 reff82_inst.
Proof. unfold Equation1894. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff82_inst, reff82_op in H. discriminate H. Qed.

Lemma reff82_not1895 : ~ @Equation1895 Fin2 reff82_inst.
Proof. unfold Equation1895. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff82_inst, reff82_op in H. discriminate H. Qed.

Lemma reff82_not1897 : ~ @Equation1897 Fin2 reff82_inst.
Proof. unfold Equation1897. intro H. specialize (H F2_1 F2_0). unfold magma_op, reff82_inst, reff82_op in H. discriminate H. Qed.

Lemma reff82_not1898 : ~ @Equation1898 Fin2 reff82_inst.
Proof. unfold Equation1898. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff82_inst, reff82_op in H. discriminate H. Qed.

Lemma reff82_not1921 : ~ @Equation1921 Fin2 reff82_inst.
Proof. unfold Equation1921. intro H. specialize (H F2_1 F2_0). unfold magma_op, reff82_inst, reff82_op in H. discriminate H. Qed.

Lemma reff82_not1922 : ~ @Equation1922 Fin2 reff82_inst.
Proof. unfold Equation1922. intro H. specialize (H F2_1 F2_0). unfold magma_op, reff82_inst, reff82_op in H. discriminate H. Qed.

Lemma reff82_not1924 : ~ @Equation1924 Fin2 reff82_inst.
Proof. unfold Equation1924. intro H. specialize (H F2_1 F2_0). unfold magma_op, reff82_inst, reff82_op in H. discriminate H. Qed.

Lemma reff82_not1925 : ~ @Equation1925 Fin2 reff82_inst.
Proof. unfold Equation1925. intro H. specialize (H F2_1 F2_0). unfold magma_op, reff82_inst, reff82_op in H. discriminate H. Qed.

Lemma reff82_not1931 : ~ @Equation1931 Fin2 reff82_inst.
Proof. unfold Equation1931. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff82_inst, reff82_op in H. discriminate H. Qed.

Lemma reff82_not1932 : ~ @Equation1932 Fin2 reff82_inst.
Proof. unfold Equation1932. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff82_inst, reff82_op in H. discriminate H. Qed.

Lemma reff82_not1934 : ~ @Equation1934 Fin2 reff82_inst.
Proof. unfold Equation1934. intro H. specialize (H F2_1 F2_0). unfold magma_op, reff82_inst, reff82_op in H. discriminate H. Qed.

Lemma reff82_not2035 : ~ @Equation2035 Fin2 reff82_inst.
Proof. unfold Equation2035. intro H. specialize (H F2_1). unfold magma_op, reff82_inst, reff82_op in H. discriminate H. Qed.

Lemma reff82_not2238 : ~ @Equation2238 Fin2 reff82_inst.
Proof. unfold Equation2238. intro H. specialize (H F2_1). unfold magma_op, reff82_inst, reff82_op in H. discriminate H. Qed.

Lemma reff82_not2441 : ~ @Equation2441 Fin2 reff82_inst.
Proof. unfold Equation2441. intro H. specialize (H F2_1). unfold magma_op, reff82_inst, reff82_op in H. discriminate H. Qed.

Lemma reff82_not2644 : ~ @Equation2644 Fin2 reff82_inst.
Proof. unfold Equation2644. intro H. specialize (H F2_1). unfold magma_op, reff82_inst, reff82_op in H. discriminate H. Qed.

Lemma reff82_not2847 : ~ @Equation2847 Fin2 reff82_inst.
Proof. unfold Equation2847. intro H. specialize (H F2_1). unfold magma_op, reff82_inst, reff82_op in H. discriminate H. Qed.

Lemma reff82_not3050 : ~ @Equation3050 Fin2 reff82_inst.
Proof. unfold Equation3050. intro H. specialize (H F2_1). unfold magma_op, reff82_inst, reff82_op in H. discriminate H. Qed.

Lemma reff82_not3254 : ~ @Equation3254 Fin2 reff82_inst.
Proof. unfold Equation3254. intro H. specialize (H F2_1 F2_0). unfold magma_op, reff82_inst, reff82_op in H. discriminate H. Qed.

Lemma reff82_not3258 : ~ @Equation3258 Fin2 reff82_inst.
Proof. unfold Equation3258. intro H. specialize (H F2_1 F2_0). unfold magma_op, reff82_inst, reff82_op in H. discriminate H. Qed.

Lemma reff82_not3259 : ~ @Equation3259 Fin2 reff82_inst.
Proof. unfold Equation3259. intro H. specialize (H F2_1 F2_0). unfold magma_op, reff82_inst, reff82_op in H. discriminate H. Qed.

Lemma reff82_not3261 : ~ @Equation3261 Fin2 reff82_inst.
Proof. unfold Equation3261. intro H. specialize (H F2_1 F2_0). unfold magma_op, reff82_inst, reff82_op in H. discriminate H. Qed.

Lemma reff82_not3262 : ~ @Equation3262 Fin2 reff82_inst.
Proof. unfold Equation3262. intro H. specialize (H F2_1 F2_0). unfold magma_op, reff82_inst, reff82_op in H. discriminate H. Qed.

Lemma reff82_not3268 : ~ @Equation3268 Fin2 reff82_inst.
Proof. unfold Equation3268. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff82_inst, reff82_op in H. discriminate H. Qed.

Lemma reff82_not3269 : ~ @Equation3269 Fin2 reff82_inst.
Proof. unfold Equation3269. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff82_inst, reff82_op in H. discriminate H. Qed.

Lemma reff82_not3271 : ~ @Equation3271 Fin2 reff82_inst.
Proof. unfold Equation3271. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff82_inst, reff82_op in H. discriminate H. Qed.

Lemma reff82_not3272 : ~ @Equation3272 Fin2 reff82_inst.
Proof. unfold Equation3272. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff82_inst, reff82_op in H. discriminate H. Qed.

Lemma reff82_not3281 : ~ @Equation3281 Fin2 reff82_inst.
Proof. unfold Equation3281. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff82_inst, reff82_op in H. discriminate H. Qed.

Lemma reff82_not3308 : ~ @Equation3308 Fin2 reff82_inst.
Proof. unfold Equation3308. intro H. specialize (H F2_1 F2_0). unfold magma_op, reff82_inst, reff82_op in H. discriminate H. Qed.

Lemma reff82_not3309 : ~ @Equation3309 Fin2 reff82_inst.
Proof. unfold Equation3309. intro H. specialize (H F2_1 F2_0). unfold magma_op, reff82_inst, reff82_op in H. discriminate H. Qed.

Lemma reff82_not3342 : ~ @Equation3342 Fin2 reff82_inst.
Proof. unfold Equation3342. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff82_inst, reff82_op in H. discriminate H. Qed.

Lemma reff82_not3343 : ~ @Equation3343 Fin2 reff82_inst.
Proof. unfold Equation3343. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff82_inst, reff82_op in H. discriminate H. Qed.

Lemma reff82_not3345 : ~ @Equation3345 Fin2 reff82_inst.
Proof. unfold Equation3345. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff82_inst, reff82_op in H. discriminate H. Qed.

Lemma reff82_not3346 : ~ @Equation3346 Fin2 reff82_inst.
Proof. unfold Equation3346. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff82_inst, reff82_op in H. discriminate H. Qed.

Lemma reff82_not3352 : ~ @Equation3352 Fin2 reff82_inst.
Proof. unfold Equation3352. intro H. specialize (H F2_1 F2_0). unfold magma_op, reff82_inst, reff82_op in H. discriminate H. Qed.

Lemma reff82_not3353 : ~ @Equation3353 Fin2 reff82_inst.
Proof. unfold Equation3353. intro H. specialize (H F2_1 F2_0). unfold magma_op, reff82_inst, reff82_op in H. discriminate H. Qed.

Lemma reff82_not3456 : ~ @Equation3456 Fin2 reff82_inst.
Proof. unfold Equation3456. intro H. specialize (H F2_1). unfold magma_op, reff82_inst, reff82_op in H. discriminate H. Qed.

Lemma reff82_not3664 : ~ @Equation3664 Fin2 reff82_inst.
Proof. unfold Equation3664. intro H. specialize (H F2_1 F2_0). unfold magma_op, reff82_inst, reff82_op in H. discriminate H. Qed.

Lemma reff82_not3667 : ~ @Equation3667 Fin2 reff82_inst.
Proof. unfold Equation3667. intro H. specialize (H F2_1 F2_0). unfold magma_op, reff82_inst, reff82_op in H. discriminate H. Qed.

Lemma reff82_not3668 : ~ @Equation3668 Fin2 reff82_inst.
Proof. unfold Equation3668. intro H. specialize (H F2_1 F2_0). unfold magma_op, reff82_inst, reff82_op in H. discriminate H. Qed.

Lemma reff82_not3674 : ~ @Equation3674 Fin2 reff82_inst.
Proof. unfold Equation3674. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff82_inst, reff82_op in H. discriminate H. Qed.

Lemma reff82_not3675 : ~ @Equation3675 Fin2 reff82_inst.
Proof. unfold Equation3675. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff82_inst, reff82_op in H. discriminate H. Qed.

Lemma reff82_not3678 : ~ @Equation3678 Fin2 reff82_inst.
Proof. unfold Equation3678. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff82_inst, reff82_op in H. discriminate H. Qed.

Lemma reff82_not3712 : ~ @Equation3712 Fin2 reff82_inst.
Proof. unfold Equation3712. intro H. specialize (H F2_1 F2_0). unfold magma_op, reff82_inst, reff82_op in H. discriminate H. Qed.

Lemma reff82_not3714 : ~ @Equation3714 Fin2 reff82_inst.
Proof. unfold Equation3714. intro H. specialize (H F2_1 F2_0). unfold magma_op, reff82_inst, reff82_op in H. discriminate H. Qed.

Lemma reff82_not3722 : ~ @Equation3722 Fin2 reff82_inst.
Proof. unfold Equation3722. intro H. specialize (H F2_1 F2_0). unfold magma_op, reff82_inst, reff82_op in H. discriminate H. Qed.

Lemma reff82_not3748 : ~ @Equation3748 Fin2 reff82_inst.
Proof. unfold Equation3748. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff82_inst, reff82_op in H. discriminate H. Qed.

Lemma reff82_not3749 : ~ @Equation3749 Fin2 reff82_inst.
Proof. unfold Equation3749. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff82_inst, reff82_op in H. discriminate H. Qed.

Lemma reff82_not3751 : ~ @Equation3751 Fin2 reff82_inst.
Proof. unfold Equation3751. intro H. specialize (H F2_1 F2_0). unfold magma_op, reff82_inst, reff82_op in H. discriminate H. Qed.

Lemma reff82_not3752 : ~ @Equation3752 Fin2 reff82_inst.
Proof. unfold Equation3752. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff82_inst, reff82_op in H. discriminate H. Qed.

Lemma reff82_not3759 : ~ @Equation3759 Fin2 reff82_inst.
Proof. unfold Equation3759. intro H. specialize (H F2_1 F2_0). unfold magma_op, reff82_inst, reff82_op in H. discriminate H. Qed.

Lemma reff82_not3761 : ~ @Equation3761 Fin2 reff82_inst.
Proof. unfold Equation3761. intro H. specialize (H F2_1 F2_0). unfold magma_op, reff82_inst, reff82_op in H. discriminate H. Qed.

Lemma reff82_not3863 : ~ @Equation3863 Fin2 reff82_inst.
Proof. unfold Equation3863. intro H. specialize (H F2_1 F2_0). unfold magma_op, reff82_inst, reff82_op in H. discriminate H. Qed.

Lemma reff82_not3868 : ~ @Equation3868 Fin2 reff82_inst.
Proof. unfold Equation3868. intro H. specialize (H F2_1 F2_0). unfold magma_op, reff82_inst, reff82_op in H. discriminate H. Qed.

Lemma reff82_not3871 : ~ @Equation3871 Fin2 reff82_inst.
Proof. unfold Equation3871. intro H. specialize (H F2_1 F2_0). unfold magma_op, reff82_inst, reff82_op in H. discriminate H. Qed.

Lemma reff82_not3877 : ~ @Equation3877 Fin2 reff82_inst.
Proof. unfold Equation3877. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff82_inst, reff82_op in H. discriminate H. Qed.

Lemma reff82_not3880 : ~ @Equation3880 Fin2 reff82_inst.
Proof. unfold Equation3880. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff82_inst, reff82_op in H. discriminate H. Qed.

Lemma reff82_not3890 : ~ @Equation3890 Fin2 reff82_inst.
Proof. unfold Equation3890. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff82_inst, reff82_op in H. discriminate H. Qed.

Lemma reff82_not3917 : ~ @Equation3917 Fin2 reff82_inst.
Proof. unfold Equation3917. intro H. specialize (H F2_1 F2_0). unfold magma_op, reff82_inst, reff82_op in H. discriminate H. Qed.

Lemma reff82_not3918 : ~ @Equation3918 Fin2 reff82_inst.
Proof. unfold Equation3918. intro H. specialize (H F2_1 F2_0). unfold magma_op, reff82_inst, reff82_op in H. discriminate H. Qed.

Lemma reff82_not3924 : ~ @Equation3924 Fin2 reff82_inst.
Proof. unfold Equation3924. intro H. specialize (H F2_1 F2_0). unfold magma_op, reff82_inst, reff82_op in H. discriminate H. Qed.

Lemma reff82_not3927 : ~ @Equation3927 Fin2 reff82_inst.
Proof. unfold Equation3927. intro H. specialize (H F2_1 F2_0). unfold magma_op, reff82_inst, reff82_op in H. discriminate H. Qed.

Lemma reff82_not3951 : ~ @Equation3951 Fin2 reff82_inst.
Proof. unfold Equation3951. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff82_inst, reff82_op in H. discriminate H. Qed.

Lemma reff82_not3952 : ~ @Equation3952 Fin2 reff82_inst.
Proof. unfold Equation3952. intro H. specialize (H F2_1 F2_0). unfold magma_op, reff82_inst, reff82_op in H. discriminate H. Qed.

Lemma reff82_not3954 : ~ @Equation3954 Fin2 reff82_inst.
Proof. unfold Equation3954. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff82_inst, reff82_op in H. discriminate H. Qed.

Lemma reff82_not3955 : ~ @Equation3955 Fin2 reff82_inst.
Proof. unfold Equation3955. intro H. specialize (H F2_1 F2_0). unfold magma_op, reff82_inst, reff82_op in H. discriminate H. Qed.

Lemma reff82_not3961 : ~ @Equation3961 Fin2 reff82_inst.
Proof. unfold Equation3961. intro H. specialize (H F2_1 F2_0). unfold magma_op, reff82_inst, reff82_op in H. discriminate H. Qed.

Lemma reff82_not3962 : ~ @Equation3962 Fin2 reff82_inst.
Proof. unfold Equation3962. intro H. specialize (H F2_1 F2_0). unfold magma_op, reff82_inst, reff82_op in H. discriminate H. Qed.

Lemma reff82_not3964 : ~ @Equation3964 Fin2 reff82_inst.
Proof. unfold Equation3964. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff82_inst, reff82_op in H. discriminate H. Qed.

Lemma reff82_not4074 : ~ @Equation4074 Fin2 reff82_inst.
Proof. unfold Equation4074. intro H. specialize (H F2_1 F2_0). unfold magma_op, reff82_inst, reff82_op in H. discriminate H. Qed.

Lemma reff82_not4080 : ~ @Equation4080 Fin2 reff82_inst.
Proof. unfold Equation4080. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff82_inst, reff82_op in H. discriminate H. Qed.

Lemma reff82_not4118 : ~ @Equation4118 Fin2 reff82_inst.
Proof. unfold Equation4118. intro H. specialize (H F2_1 F2_0). unfold magma_op, reff82_inst, reff82_op in H. discriminate H. Qed.

Lemma reff82_not4120 : ~ @Equation4120 Fin2 reff82_inst.
Proof. unfold Equation4120. intro H. specialize (H F2_1 F2_0). unfold magma_op, reff82_inst, reff82_op in H. discriminate H. Qed.

Lemma reff82_not4121 : ~ @Equation4121 Fin2 reff82_inst.
Proof. unfold Equation4121. intro H. specialize (H F2_1 F2_0). unfold magma_op, reff82_inst, reff82_op in H. discriminate H. Qed.

Lemma reff82_not4127 : ~ @Equation4127 Fin2 reff82_inst.
Proof. unfold Equation4127. intro H. specialize (H F2_1 F2_0). unfold magma_op, reff82_inst, reff82_op in H. discriminate H. Qed.

Lemma reff82_not4128 : ~ @Equation4128 Fin2 reff82_inst.
Proof. unfold Equation4128. intro H. specialize (H F2_1 F2_0). unfold magma_op, reff82_inst, reff82_op in H. discriminate H. Qed.

Lemma reff82_not4130 : ~ @Equation4130 Fin2 reff82_inst.
Proof. unfold Equation4130. intro H. specialize (H F2_1 F2_0). unfold magma_op, reff82_inst, reff82_op in H. discriminate H. Qed.

Lemma reff82_not4155 : ~ @Equation4155 Fin2 reff82_inst.
Proof. unfold Equation4155. intro H. specialize (H F2_1 F2_0). unfold magma_op, reff82_inst, reff82_op in H. discriminate H. Qed.

Lemma reff82_not4157 : ~ @Equation4157 Fin2 reff82_inst.
Proof. unfold Equation4157. intro H. specialize (H F2_1 F2_0). unfold magma_op, reff82_inst, reff82_op in H. discriminate H. Qed.

Lemma reff82_not4158 : ~ @Equation4158 Fin2 reff82_inst.
Proof. unfold Equation4158. intro H. specialize (H F2_1 F2_0). unfold magma_op, reff82_inst, reff82_op in H. discriminate H. Qed.

Lemma reff82_not4164 : ~ @Equation4164 Fin2 reff82_inst.
Proof. unfold Equation4164. intro H. specialize (H F2_1 F2_0). unfold magma_op, reff82_inst, reff82_op in H. discriminate H. Qed.

Lemma reff82_not4165 : ~ @Equation4165 Fin2 reff82_inst.
Proof. unfold Equation4165. intro H. specialize (H F2_1 F2_0). unfold magma_op, reff82_inst, reff82_op in H. discriminate H. Qed.

Lemma reff82_not4167 : ~ @Equation4167 Fin2 reff82_inst.
Proof. unfold Equation4167. intro H. specialize (H F2_1 F2_0). unfold magma_op, reff82_inst, reff82_op in H. discriminate H. Qed.

Lemma reff82_not4268 : ~ @Equation4268 Fin2 reff82_inst.
Proof. unfold Equation4268. intro H. specialize (H F2_1 F2_0). unfold magma_op, reff82_inst, reff82_op in H. discriminate H. Qed.

Lemma reff82_not4272 : ~ @Equation4272 Fin2 reff82_inst.
Proof. unfold Equation4272. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff82_inst, reff82_op in H. discriminate H. Qed.

Lemma reff82_not4273 : ~ @Equation4273 Fin2 reff82_inst.
Proof. unfold Equation4273. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff82_inst, reff82_op in H. discriminate H. Qed.

Lemma reff82_not4275 : ~ @Equation4275 Fin2 reff82_inst.
Proof. unfold Equation4275. intro H. specialize (H F2_1 F2_0). unfold magma_op, reff82_inst, reff82_op in H. discriminate H. Qed.

Lemma reff82_not4276 : ~ @Equation4276 Fin2 reff82_inst.
Proof. unfold Equation4276. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff82_inst, reff82_op in H. discriminate H. Qed.

Lemma reff82_not4283 : ~ @Equation4283 Fin2 reff82_inst.
Proof. unfold Equation4283. intro H. specialize (H F2_1 F2_0). unfold magma_op, reff82_inst, reff82_op in H. discriminate H. Qed.

Lemma reff82_not4284 : ~ @Equation4284 Fin2 reff82_inst.
Proof. unfold Equation4284. intro H. specialize (H F2_1 F2_0). unfold magma_op, reff82_inst, reff82_op in H. discriminate H. Qed.

Lemma reff82_not4290 : ~ @Equation4290 Fin2 reff82_inst.
Proof. unfold Equation4290. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff82_inst, reff82_op in H. discriminate H. Qed.

Lemma reff82_not4291 : ~ @Equation4291 Fin2 reff82_inst.
Proof. unfold Equation4291. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff82_inst, reff82_op in H. discriminate H. Qed.

Lemma reff82_not4320 : ~ @Equation4320 Fin2 reff82_inst.
Proof. unfold Equation4320. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff82_inst, reff82_op in H. discriminate H. Qed.

Lemma reff82_not4321 : ~ @Equation4321 Fin2 reff82_inst.
Proof. unfold Equation4321. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff82_inst, reff82_op in H. discriminate H. Qed.

Lemma reff82_not4343 : ~ @Equation4343 Fin2 reff82_inst.
Proof. unfold Equation4343. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff82_inst, reff82_op in H. discriminate H. Qed.

Lemma reff82_not4380 : ~ @Equation4380 Fin2 reff82_inst.
Proof. unfold Equation4380. intro H. specialize (H F2_1). unfold magma_op, reff82_inst, reff82_op in H. discriminate H. Qed.

Lemma reff82_not4585 : ~ @Equation4585 Fin2 reff82_inst.
Proof. unfold Equation4585. intro H. specialize (H F2_1 F2_0). unfold magma_op, reff82_inst, reff82_op in H. discriminate H. Qed.

Lemma reff82_not4587 : ~ @Equation4587 Fin2 reff82_inst.
Proof. unfold Equation4587. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff82_inst, reff82_op in H. discriminate H. Qed.

Lemma reff82_not4599 : ~ @Equation4599 Fin2 reff82_inst.
Proof. unfold Equation4599. intro H. specialize (H F2_1 F2_0). unfold magma_op, reff82_inst, reff82_op in H. discriminate H. Qed.

Lemma reff82_not4605 : ~ @Equation4605 Fin2 reff82_inst.
Proof. unfold Equation4605. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff82_inst, reff82_op in H. discriminate H. Qed.

Lemma reff82_not4629 : ~ @Equation4629 Fin2 reff82_inst.
Proof. unfold Equation4629. intro H. specialize (H F2_1 F2_0). unfold magma_op, reff82_inst, reff82_op in H. discriminate H. Qed.

Lemma reff82_not4635 : ~ @Equation4635 Fin2 reff82_inst.
Proof. unfold Equation4635. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff82_inst, reff82_op in H. discriminate H. Qed.

Lemma reff82_not4658 : ~ @Equation4658 Fin2 reff82_inst.
Proof. unfold Equation4658. intro H. specialize (H F2_0 F2_1). unfold magma_op, reff82_inst, reff82_op in H. discriminate H. Qed.

(** ---- reff84 (Fin3) ---- *)

Definition reff84_op (x y : Fin3) : Fin3 :=
  match x, y with
  | F3_0, F3_0 => F3_0 | F3_0, F3_1 => F3_2 | F3_0, F3_2 => F3_2
  | F3_1, F3_0 => F3_0 | F3_1, F3_1 => F3_0 | F3_1, F3_2 => F3_1
  | F3_2, F3_0 => F3_0 | F3_2, F3_1 => F3_1 | F3_2, F3_2 => F3_0
  end.

#[local] Instance reff84_inst : Magma Fin3 := {| magma_op := reff84_op |}.

Lemma reff84_sat316 : @Equation316 Fin3 reff84_inst.
Proof. unfold Equation316, magma_op, reff84_inst, reff84_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff84_not3306 : ~ @Equation3306 Fin3 reff84_inst.
Proof. unfold Equation3306. intro H. specialize (H F3_1 F3_2). unfold magma_op, reff84_inst, reff84_op in H. discriminate H. Qed.

(** ---- reff88 (Fin4) ---- *)

Definition reff88_op (x y : Fin4) : Fin4 :=
  match x, y with
  | F4_0, F4_0 => F4_0 | F4_0, F4_1 => F4_1 | F4_0, F4_2 => F4_0 | F4_0, F4_3 => F4_1
  | F4_1, F4_0 => F4_3 | F4_1, F4_1 => F4_0 | F4_1, F4_2 => F4_3 | F4_1, F4_3 => F4_0
  | F4_2, F4_0 => F4_2 | F4_2, F4_1 => F4_3 | F4_2, F4_2 => F4_2 | F4_2, F4_3 => F4_3
  | F4_3, F4_0 => F4_1 | F4_3, F4_1 => F4_2 | F4_3, F4_2 => F4_1 | F4_3, F4_3 => F4_2
  end.

#[local] Instance reff88_inst : Magma Fin4 := {| magma_op := reff88_op |}.

Lemma reff88_sat26 : @Equation26 Fin4 reff88_inst.
Proof. unfold Equation26, magma_op, reff88_inst, reff88_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff88_sat1459 : @Equation1459 Fin4 reff88_inst.
Proof. unfold Equation1459, magma_op, reff88_inst, reff88_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff88_sat1467 : @Equation1467 Fin4 reff88_inst.
Proof. unfold Equation1467, magma_op, reff88_inst, reff88_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff88_sat1470 : @Equation1470 Fin4 reff88_inst.
Proof. unfold Equation1470, magma_op, reff88_inst, reff88_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff88_sat1670 : @Equation1670 Fin4 reff88_inst.
Proof. unfold Equation1670, magma_op, reff88_inst, reff88_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff88_sat1673 : @Equation1673 Fin4 reff88_inst.
Proof. unfold Equation1673, magma_op, reff88_inst, reff88_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff88_sat1865 : @Equation1865 Fin4 reff88_inst.
Proof. unfold Equation1865, magma_op, reff88_inst, reff88_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff88_sat1876 : @Equation1876 Fin4 reff88_inst.
Proof. unfold Equation1876, magma_op, reff88_inst, reff88_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff88_sat2271 : @Equation2271 Fin4 reff88_inst.
Proof. unfold Equation2271, magma_op, reff88_inst, reff88_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff88_sat2279 : @Equation2279 Fin4 reff88_inst.
Proof. unfold Equation2279, magma_op, reff88_inst, reff88_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff88_sat2282 : @Equation2282 Fin4 reff88_inst.
Proof. unfold Equation2282, magma_op, reff88_inst, reff88_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff88_sat2474 : @Equation2474 Fin4 reff88_inst.
Proof. unfold Equation2474, magma_op, reff88_inst, reff88_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff88_sat2482 : @Equation2482 Fin4 reff88_inst.
Proof. unfold Equation2482, magma_op, reff88_inst, reff88_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff88_sat2652 : @Equation2652 Fin4 reff88_inst.
Proof. unfold Equation2652, magma_op, reff88_inst, reff88_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff88_sat3323 : @Equation3323 Fin4 reff88_inst.
Proof. unfold Equation3323, magma_op, reff88_inst, reff88_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff88_sat3331 : @Equation3331 Fin4 reff88_inst.
Proof. unfold Equation3331, magma_op, reff88_inst, reff88_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff88_sat3334 : @Equation3334 Fin4 reff88_inst.
Proof. unfold Equation3334, magma_op, reff88_inst, reff88_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff88_sat3537 : @Equation3537 Fin4 reff88_inst.
Proof. unfold Equation3537, magma_op, reff88_inst, reff88_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff88_sat3662 : @Equation3662 Fin4 reff88_inst.
Proof. unfold Equation3662, magma_op, reff88_inst, reff88_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff88_sat4270 : @Equation4270 Fin4 reff88_inst.
Proof. unfold Equation4270, magma_op, reff88_inst, reff88_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff88_sat4358 : @Equation4358 Fin4 reff88_inst.
Proof. unfold Equation4358, magma_op, reff88_inst, reff88_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff88_not47 : ~ @Equation47 Fin4 reff88_inst.
Proof. unfold Equation47. intro H. specialize (H F4_1). unfold magma_op, reff88_inst, reff88_op in H. discriminate H. Qed.

Lemma reff88_not99 : ~ @Equation99 Fin4 reff88_inst.
Proof. unfold Equation99. intro H. specialize (H F4_1). unfold magma_op, reff88_inst, reff88_op in H. discriminate H. Qed.

Lemma reff88_not151 : ~ @Equation151 Fin4 reff88_inst.
Proof. unfold Equation151. intro H. specialize (H F4_1). unfold magma_op, reff88_inst, reff88_op in H. discriminate H. Qed.

Lemma reff88_not203 : ~ @Equation203 Fin4 reff88_inst.
Proof. unfold Equation203. intro H. specialize (H F4_1). unfold magma_op, reff88_inst, reff88_op in H. discriminate H. Qed.

Lemma reff88_not255 : ~ @Equation255 Fin4 reff88_inst.
Proof. unfold Equation255. intro H. specialize (H F4_1). unfold magma_op, reff88_inst, reff88_op in H. discriminate H. Qed.

Lemma reff88_not307 : ~ @Equation307 Fin4 reff88_inst.
Proof. unfold Equation307. intro H. specialize (H F4_1). unfold magma_op, reff88_inst, reff88_op in H. discriminate H. Qed.

Lemma reff88_not359 : ~ @Equation359 Fin4 reff88_inst.
Proof. unfold Equation359. intro H. specialize (H F4_1). unfold magma_op, reff88_inst, reff88_op in H. discriminate H. Qed.

Lemma reff88_not411 : ~ @Equation411 Fin4 reff88_inst.
Proof. unfold Equation411. intro H. specialize (H F4_1). unfold magma_op, reff88_inst, reff88_op in H. discriminate H. Qed.

Lemma reff88_not614 : ~ @Equation614 Fin4 reff88_inst.
Proof. unfold Equation614. intro H. specialize (H F4_1). unfold magma_op, reff88_inst, reff88_op in H. discriminate H. Qed.

Lemma reff88_not817 : ~ @Equation817 Fin4 reff88_inst.
Proof. unfold Equation817. intro H. specialize (H F4_1). unfold magma_op, reff88_inst, reff88_op in H. discriminate H. Qed.

Lemma reff88_not1020 : ~ @Equation1020 Fin4 reff88_inst.
Proof. unfold Equation1020. intro H. specialize (H F4_1). unfold magma_op, reff88_inst, reff88_op in H. discriminate H. Qed.

Lemma reff88_not1223 : ~ @Equation1223 Fin4 reff88_inst.
Proof. unfold Equation1223. intro H. specialize (H F4_1). unfold magma_op, reff88_inst, reff88_op in H. discriminate H. Qed.

Lemma reff88_not1427 : ~ @Equation1427 Fin4 reff88_inst.
Proof. unfold Equation1427. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff88_inst, reff88_op in H. discriminate H. Qed.

Lemma reff88_not1428 : ~ @Equation1428 Fin4 reff88_inst.
Proof. unfold Equation1428. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff88_inst, reff88_op in H. discriminate H. Qed.

Lemma reff88_not1431 : ~ @Equation1431 Fin4 reff88_inst.
Proof. unfold Equation1431. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff88_inst, reff88_op in H. discriminate H. Qed.

Lemma reff88_not1435 : ~ @Equation1435 Fin4 reff88_inst.
Proof. unfold Equation1435. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff88_inst, reff88_op in H. discriminate H. Qed.

Lemma reff88_not1441 : ~ @Equation1441 Fin4 reff88_inst.
Proof. unfold Equation1441. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff88_inst, reff88_op in H. discriminate H. Qed.

Lemma reff88_not1445 : ~ @Equation1445 Fin4 reff88_inst.
Proof. unfold Equation1445. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff88_inst, reff88_op in H. discriminate H. Qed.

Lemma reff88_not1452 : ~ @Equation1452 Fin4 reff88_inst.
Proof. unfold Equation1452. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff88_inst, reff88_op in H. discriminate H. Qed.

Lemma reff88_not1454 : ~ @Equation1454 Fin4 reff88_inst.
Proof. unfold Equation1454. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff88_inst, reff88_op in H. discriminate H. Qed.

Lemma reff88_not1478 : ~ @Equation1478 Fin4 reff88_inst.
Proof. unfold Equation1478. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff88_inst, reff88_op in H. discriminate H. Qed.

Lemma reff88_not1479 : ~ @Equation1479 Fin4 reff88_inst.
Proof. unfold Equation1479. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff88_inst, reff88_op in H. discriminate H. Qed.

Lemma reff88_not1481 : ~ @Equation1481 Fin4 reff88_inst.
Proof. unfold Equation1481. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff88_inst, reff88_op in H. discriminate H. Qed.

Lemma reff88_not1482 : ~ @Equation1482 Fin4 reff88_inst.
Proof. unfold Equation1482. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff88_inst, reff88_op in H. discriminate H. Qed.

Lemma reff88_not1488 : ~ @Equation1488 Fin4 reff88_inst.
Proof. unfold Equation1488. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff88_inst, reff88_op in H. discriminate H. Qed.

Lemma reff88_not1489 : ~ @Equation1489 Fin4 reff88_inst.
Proof. unfold Equation1489. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff88_inst, reff88_op in H. discriminate H. Qed.

Lemma reff88_not1491 : ~ @Equation1491 Fin4 reff88_inst.
Proof. unfold Equation1491. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff88_inst, reff88_op in H. discriminate H. Qed.

Lemma reff88_not1492 : ~ @Equation1492 Fin4 reff88_inst.
Proof. unfold Equation1492. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff88_inst, reff88_op in H. discriminate H. Qed.

Lemma reff88_not1515 : ~ @Equation1515 Fin4 reff88_inst.
Proof. unfold Equation1515. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff88_inst, reff88_op in H. discriminate H. Qed.

Lemma reff88_not1516 : ~ @Equation1516 Fin4 reff88_inst.
Proof. unfold Equation1516. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff88_inst, reff88_op in H. discriminate H. Qed.

Lemma reff88_not1518 : ~ @Equation1518 Fin4 reff88_inst.
Proof. unfold Equation1518. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff88_inst, reff88_op in H. discriminate H. Qed.

Lemma reff88_not1519 : ~ @Equation1519 Fin4 reff88_inst.
Proof. unfold Equation1519. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff88_inst, reff88_op in H. discriminate H. Qed.

Lemma reff88_not1525 : ~ @Equation1525 Fin4 reff88_inst.
Proof. unfold Equation1525. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff88_inst, reff88_op in H. discriminate H. Qed.

Lemma reff88_not1526 : ~ @Equation1526 Fin4 reff88_inst.
Proof. unfold Equation1526. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff88_inst, reff88_op in H. discriminate H. Qed.

Lemma reff88_not1528 : ~ @Equation1528 Fin4 reff88_inst.
Proof. unfold Equation1528. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff88_inst, reff88_op in H. discriminate H. Qed.

Lemma reff88_not1630 : ~ @Equation1630 Fin4 reff88_inst.
Proof. unfold Equation1630. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff88_inst, reff88_op in H. discriminate H. Qed.

Lemma reff88_not1631 : ~ @Equation1631 Fin4 reff88_inst.
Proof. unfold Equation1631. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff88_inst, reff88_op in H. discriminate H. Qed.

Lemma reff88_not1634 : ~ @Equation1634 Fin4 reff88_inst.
Proof. unfold Equation1634. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff88_inst, reff88_op in H. discriminate H. Qed.

Lemma reff88_not1638 : ~ @Equation1638 Fin4 reff88_inst.
Proof. unfold Equation1638. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff88_inst, reff88_op in H. discriminate H. Qed.

Lemma reff88_not1644 : ~ @Equation1644 Fin4 reff88_inst.
Proof. unfold Equation1644. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff88_inst, reff88_op in H. discriminate H. Qed.

Lemma reff88_not1648 : ~ @Equation1648 Fin4 reff88_inst.
Proof. unfold Equation1648. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff88_inst, reff88_op in H. discriminate H. Qed.

Lemma reff88_not1655 : ~ @Equation1655 Fin4 reff88_inst.
Proof. unfold Equation1655. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff88_inst, reff88_op in H. discriminate H. Qed.

Lemma reff88_not1657 : ~ @Equation1657 Fin4 reff88_inst.
Proof. unfold Equation1657. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff88_inst, reff88_op in H. discriminate H. Qed.

Lemma reff88_not1681 : ~ @Equation1681 Fin4 reff88_inst.
Proof. unfold Equation1681. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff88_inst, reff88_op in H. discriminate H. Qed.

Lemma reff88_not1682 : ~ @Equation1682 Fin4 reff88_inst.
Proof. unfold Equation1682. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff88_inst, reff88_op in H. discriminate H. Qed.

Lemma reff88_not1684 : ~ @Equation1684 Fin4 reff88_inst.
Proof. unfold Equation1684. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff88_inst, reff88_op in H. discriminate H. Qed.

Lemma reff88_not1685 : ~ @Equation1685 Fin4 reff88_inst.
Proof. unfold Equation1685. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff88_inst, reff88_op in H. discriminate H. Qed.

Lemma reff88_not1691 : ~ @Equation1691 Fin4 reff88_inst.
Proof. unfold Equation1691. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff88_inst, reff88_op in H. discriminate H. Qed.

Lemma reff88_not1692 : ~ @Equation1692 Fin4 reff88_inst.
Proof. unfold Equation1692. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff88_inst, reff88_op in H. discriminate H. Qed.

Lemma reff88_not1694 : ~ @Equation1694 Fin4 reff88_inst.
Proof. unfold Equation1694. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff88_inst, reff88_op in H. discriminate H. Qed.

Lemma reff88_not1695 : ~ @Equation1695 Fin4 reff88_inst.
Proof. unfold Equation1695. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff88_inst, reff88_op in H. discriminate H. Qed.

Lemma reff88_not1718 : ~ @Equation1718 Fin4 reff88_inst.
Proof. unfold Equation1718. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff88_inst, reff88_op in H. discriminate H. Qed.

Lemma reff88_not1719 : ~ @Equation1719 Fin4 reff88_inst.
Proof. unfold Equation1719. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff88_inst, reff88_op in H. discriminate H. Qed.

Lemma reff88_not1721 : ~ @Equation1721 Fin4 reff88_inst.
Proof. unfold Equation1721. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff88_inst, reff88_op in H. discriminate H. Qed.

Lemma reff88_not1722 : ~ @Equation1722 Fin4 reff88_inst.
Proof. unfold Equation1722. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff88_inst, reff88_op in H. discriminate H. Qed.

Lemma reff88_not1728 : ~ @Equation1728 Fin4 reff88_inst.
Proof. unfold Equation1728. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff88_inst, reff88_op in H. discriminate H. Qed.

Lemma reff88_not1729 : ~ @Equation1729 Fin4 reff88_inst.
Proof. unfold Equation1729. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff88_inst, reff88_op in H. discriminate H. Qed.

Lemma reff88_not1731 : ~ @Equation1731 Fin4 reff88_inst.
Proof. unfold Equation1731. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff88_inst, reff88_op in H. discriminate H. Qed.

Lemma reff88_not1833 : ~ @Equation1833 Fin4 reff88_inst.
Proof. unfold Equation1833. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff88_inst, reff88_op in H. discriminate H. Qed.

Lemma reff88_not1834 : ~ @Equation1834 Fin4 reff88_inst.
Proof. unfold Equation1834. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff88_inst, reff88_op in H. discriminate H. Qed.

Lemma reff88_not1837 : ~ @Equation1837 Fin4 reff88_inst.
Proof. unfold Equation1837. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff88_inst, reff88_op in H. discriminate H. Qed.

Lemma reff88_not1841 : ~ @Equation1841 Fin4 reff88_inst.
Proof. unfold Equation1841. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff88_inst, reff88_op in H. discriminate H. Qed.

Lemma reff88_not1847 : ~ @Equation1847 Fin4 reff88_inst.
Proof. unfold Equation1847. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff88_inst, reff88_op in H. discriminate H. Qed.

Lemma reff88_not1851 : ~ @Equation1851 Fin4 reff88_inst.
Proof. unfold Equation1851. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff88_inst, reff88_op in H. discriminate H. Qed.

Lemma reff88_not1858 : ~ @Equation1858 Fin4 reff88_inst.
Proof. unfold Equation1858. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff88_inst, reff88_op in H. discriminate H. Qed.

Lemma reff88_not1860 : ~ @Equation1860 Fin4 reff88_inst.
Proof. unfold Equation1860. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff88_inst, reff88_op in H. discriminate H. Qed.

Lemma reff88_not1884 : ~ @Equation1884 Fin4 reff88_inst.
Proof. unfold Equation1884. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff88_inst, reff88_op in H. discriminate H. Qed.

Lemma reff88_not1885 : ~ @Equation1885 Fin4 reff88_inst.
Proof. unfold Equation1885. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff88_inst, reff88_op in H. discriminate H. Qed.

Lemma reff88_not1887 : ~ @Equation1887 Fin4 reff88_inst.
Proof. unfold Equation1887. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff88_inst, reff88_op in H. discriminate H. Qed.

Lemma reff88_not1888 : ~ @Equation1888 Fin4 reff88_inst.
Proof. unfold Equation1888. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff88_inst, reff88_op in H. discriminate H. Qed.

Lemma reff88_not1894 : ~ @Equation1894 Fin4 reff88_inst.
Proof. unfold Equation1894. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff88_inst, reff88_op in H. discriminate H. Qed.

Lemma reff88_not1895 : ~ @Equation1895 Fin4 reff88_inst.
Proof. unfold Equation1895. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff88_inst, reff88_op in H. discriminate H. Qed.

Lemma reff88_not1897 : ~ @Equation1897 Fin4 reff88_inst.
Proof. unfold Equation1897. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff88_inst, reff88_op in H. discriminate H. Qed.

Lemma reff88_not1898 : ~ @Equation1898 Fin4 reff88_inst.
Proof. unfold Equation1898. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff88_inst, reff88_op in H. discriminate H. Qed.

Lemma reff88_not1921 : ~ @Equation1921 Fin4 reff88_inst.
Proof. unfold Equation1921. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff88_inst, reff88_op in H. discriminate H. Qed.

Lemma reff88_not1922 : ~ @Equation1922 Fin4 reff88_inst.
Proof. unfold Equation1922. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff88_inst, reff88_op in H. discriminate H. Qed.

Lemma reff88_not1924 : ~ @Equation1924 Fin4 reff88_inst.
Proof. unfold Equation1924. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff88_inst, reff88_op in H. discriminate H. Qed.

Lemma reff88_not1925 : ~ @Equation1925 Fin4 reff88_inst.
Proof. unfold Equation1925. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff88_inst, reff88_op in H. discriminate H. Qed.

Lemma reff88_not1931 : ~ @Equation1931 Fin4 reff88_inst.
Proof. unfold Equation1931. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff88_inst, reff88_op in H. discriminate H. Qed.

Lemma reff88_not1932 : ~ @Equation1932 Fin4 reff88_inst.
Proof. unfold Equation1932. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff88_inst, reff88_op in H. discriminate H. Qed.

Lemma reff88_not1934 : ~ @Equation1934 Fin4 reff88_inst.
Proof. unfold Equation1934. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff88_inst, reff88_op in H. discriminate H. Qed.

Lemma reff88_not2035 : ~ @Equation2035 Fin4 reff88_inst.
Proof. unfold Equation2035. intro H. specialize (H F4_1). unfold magma_op, reff88_inst, reff88_op in H. discriminate H. Qed.

Lemma reff88_not2239 : ~ @Equation2239 Fin4 reff88_inst.
Proof. unfold Equation2239. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff88_inst, reff88_op in H. discriminate H. Qed.

Lemma reff88_not2240 : ~ @Equation2240 Fin4 reff88_inst.
Proof. unfold Equation2240. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff88_inst, reff88_op in H. discriminate H. Qed.

Lemma reff88_not2243 : ~ @Equation2243 Fin4 reff88_inst.
Proof. unfold Equation2243. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff88_inst, reff88_op in H. discriminate H. Qed.

Lemma reff88_not2247 : ~ @Equation2247 Fin4 reff88_inst.
Proof. unfold Equation2247. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff88_inst, reff88_op in H. discriminate H. Qed.

Lemma reff88_not2253 : ~ @Equation2253 Fin4 reff88_inst.
Proof. unfold Equation2253. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff88_inst, reff88_op in H. discriminate H. Qed.

Lemma reff88_not2257 : ~ @Equation2257 Fin4 reff88_inst.
Proof. unfold Equation2257. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff88_inst, reff88_op in H. discriminate H. Qed.

Lemma reff88_not2264 : ~ @Equation2264 Fin4 reff88_inst.
Proof. unfold Equation2264. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff88_inst, reff88_op in H. discriminate H. Qed.

Lemma reff88_not2266 : ~ @Equation2266 Fin4 reff88_inst.
Proof. unfold Equation2266. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff88_inst, reff88_op in H. discriminate H. Qed.

Lemma reff88_not2290 : ~ @Equation2290 Fin4 reff88_inst.
Proof. unfold Equation2290. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff88_inst, reff88_op in H. discriminate H. Qed.

Lemma reff88_not2291 : ~ @Equation2291 Fin4 reff88_inst.
Proof. unfold Equation2291. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff88_inst, reff88_op in H. discriminate H. Qed.

Lemma reff88_not2293 : ~ @Equation2293 Fin4 reff88_inst.
Proof. unfold Equation2293. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff88_inst, reff88_op in H. discriminate H. Qed.

Lemma reff88_not2294 : ~ @Equation2294 Fin4 reff88_inst.
Proof. unfold Equation2294. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff88_inst, reff88_op in H. discriminate H. Qed.

Lemma reff88_not2300 : ~ @Equation2300 Fin4 reff88_inst.
Proof. unfold Equation2300. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff88_inst, reff88_op in H. discriminate H. Qed.

Lemma reff88_not2301 : ~ @Equation2301 Fin4 reff88_inst.
Proof. unfold Equation2301. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff88_inst, reff88_op in H. discriminate H. Qed.

Lemma reff88_not2303 : ~ @Equation2303 Fin4 reff88_inst.
Proof. unfold Equation2303. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff88_inst, reff88_op in H. discriminate H. Qed.

Lemma reff88_not2304 : ~ @Equation2304 Fin4 reff88_inst.
Proof. unfold Equation2304. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff88_inst, reff88_op in H. discriminate H. Qed.

Lemma reff88_not2327 : ~ @Equation2327 Fin4 reff88_inst.
Proof. unfold Equation2327. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff88_inst, reff88_op in H. discriminate H. Qed.

Lemma reff88_not2328 : ~ @Equation2328 Fin4 reff88_inst.
Proof. unfold Equation2328. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff88_inst, reff88_op in H. discriminate H. Qed.

Lemma reff88_not2330 : ~ @Equation2330 Fin4 reff88_inst.
Proof. unfold Equation2330. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff88_inst, reff88_op in H. discriminate H. Qed.

Lemma reff88_not2331 : ~ @Equation2331 Fin4 reff88_inst.
Proof. unfold Equation2331. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff88_inst, reff88_op in H. discriminate H. Qed.

Lemma reff88_not2337 : ~ @Equation2337 Fin4 reff88_inst.
Proof. unfold Equation2337. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff88_inst, reff88_op in H. discriminate H. Qed.

Lemma reff88_not2338 : ~ @Equation2338 Fin4 reff88_inst.
Proof. unfold Equation2338. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff88_inst, reff88_op in H. discriminate H. Qed.

Lemma reff88_not2340 : ~ @Equation2340 Fin4 reff88_inst.
Proof. unfold Equation2340. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff88_inst, reff88_op in H. discriminate H. Qed.

Lemma reff88_not2442 : ~ @Equation2442 Fin4 reff88_inst.
Proof. unfold Equation2442. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff88_inst, reff88_op in H. discriminate H. Qed.

Lemma reff88_not2443 : ~ @Equation2443 Fin4 reff88_inst.
Proof. unfold Equation2443. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff88_inst, reff88_op in H. discriminate H. Qed.

Lemma reff88_not2446 : ~ @Equation2446 Fin4 reff88_inst.
Proof. unfold Equation2446. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff88_inst, reff88_op in H. discriminate H. Qed.

Lemma reff88_not2450 : ~ @Equation2450 Fin4 reff88_inst.
Proof. unfold Equation2450. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff88_inst, reff88_op in H. discriminate H. Qed.

Lemma reff88_not2456 : ~ @Equation2456 Fin4 reff88_inst.
Proof. unfold Equation2456. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff88_inst, reff88_op in H. discriminate H. Qed.

Lemma reff88_not2460 : ~ @Equation2460 Fin4 reff88_inst.
Proof. unfold Equation2460. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff88_inst, reff88_op in H. discriminate H. Qed.

Lemma reff88_not2467 : ~ @Equation2467 Fin4 reff88_inst.
Proof. unfold Equation2467. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff88_inst, reff88_op in H. discriminate H. Qed.

Lemma reff88_not2469 : ~ @Equation2469 Fin4 reff88_inst.
Proof. unfold Equation2469. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff88_inst, reff88_op in H. discriminate H. Qed.

Lemma reff88_not2493 : ~ @Equation2493 Fin4 reff88_inst.
Proof. unfold Equation2493. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff88_inst, reff88_op in H. discriminate H. Qed.

Lemma reff88_not2494 : ~ @Equation2494 Fin4 reff88_inst.
Proof. unfold Equation2494. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff88_inst, reff88_op in H. discriminate H. Qed.

Lemma reff88_not2496 : ~ @Equation2496 Fin4 reff88_inst.
Proof. unfold Equation2496. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff88_inst, reff88_op in H. discriminate H. Qed.

Lemma reff88_not2497 : ~ @Equation2497 Fin4 reff88_inst.
Proof. unfold Equation2497. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff88_inst, reff88_op in H. discriminate H. Qed.

Lemma reff88_not2503 : ~ @Equation2503 Fin4 reff88_inst.
Proof. unfold Equation2503. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff88_inst, reff88_op in H. discriminate H. Qed.

Lemma reff88_not2504 : ~ @Equation2504 Fin4 reff88_inst.
Proof. unfold Equation2504. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff88_inst, reff88_op in H. discriminate H. Qed.

Lemma reff88_not2506 : ~ @Equation2506 Fin4 reff88_inst.
Proof. unfold Equation2506. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff88_inst, reff88_op in H. discriminate H. Qed.

Lemma reff88_not2507 : ~ @Equation2507 Fin4 reff88_inst.
Proof. unfold Equation2507. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff88_inst, reff88_op in H. discriminate H. Qed.

Lemma reff88_not2530 : ~ @Equation2530 Fin4 reff88_inst.
Proof. unfold Equation2530. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff88_inst, reff88_op in H. discriminate H. Qed.

Lemma reff88_not2531 : ~ @Equation2531 Fin4 reff88_inst.
Proof. unfold Equation2531. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff88_inst, reff88_op in H. discriminate H. Qed.

Lemma reff88_not2533 : ~ @Equation2533 Fin4 reff88_inst.
Proof. unfold Equation2533. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff88_inst, reff88_op in H. discriminate H. Qed.

Lemma reff88_not2534 : ~ @Equation2534 Fin4 reff88_inst.
Proof. unfold Equation2534. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff88_inst, reff88_op in H. discriminate H. Qed.

Lemma reff88_not2540 : ~ @Equation2540 Fin4 reff88_inst.
Proof. unfold Equation2540. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff88_inst, reff88_op in H. discriminate H. Qed.

Lemma reff88_not2541 : ~ @Equation2541 Fin4 reff88_inst.
Proof. unfold Equation2541. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff88_inst, reff88_op in H. discriminate H. Qed.

Lemma reff88_not2543 : ~ @Equation2543 Fin4 reff88_inst.
Proof. unfold Equation2543. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff88_inst, reff88_op in H. discriminate H. Qed.

Lemma reff88_not2645 : ~ @Equation2645 Fin4 reff88_inst.
Proof. unfold Equation2645. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff88_inst, reff88_op in H. discriminate H. Qed.

Lemma reff88_not2646 : ~ @Equation2646 Fin4 reff88_inst.
Proof. unfold Equation2646. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff88_inst, reff88_op in H. discriminate H. Qed.

Lemma reff88_not2647 : ~ @Equation2647 Fin4 reff88_inst.
Proof. unfold Equation2647. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff88_inst, reff88_op in H. discriminate H. Qed.

Lemma reff88_not2649 : ~ @Equation2649 Fin4 reff88_inst.
Proof. unfold Equation2649. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff88_inst, reff88_op in H. discriminate H. Qed.

Lemma reff88_not2650 : ~ @Equation2650 Fin4 reff88_inst.
Proof. unfold Equation2650. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff88_inst, reff88_op in H. discriminate H. Qed.

Lemma reff88_not2653 : ~ @Equation2653 Fin4 reff88_inst.
Proof. unfold Equation2653. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff88_inst, reff88_op in H. discriminate H. Qed.

Lemma reff88_not2659 : ~ @Equation2659 Fin4 reff88_inst.
Proof. unfold Equation2659. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff88_inst, reff88_op in H. discriminate H. Qed.

Lemma reff88_not2660 : ~ @Equation2660 Fin4 reff88_inst.
Proof. unfold Equation2660. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff88_inst, reff88_op in H. discriminate H. Qed.

Lemma reff88_not2662 : ~ @Equation2662 Fin4 reff88_inst.
Proof. unfold Equation2662. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff88_inst, reff88_op in H. discriminate H. Qed.

Lemma reff88_not2663 : ~ @Equation2663 Fin4 reff88_inst.
Proof. unfold Equation2663. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff88_inst, reff88_op in H. discriminate H. Qed.

Lemma reff88_not2669 : ~ @Equation2669 Fin4 reff88_inst.
Proof. unfold Equation2669. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff88_inst, reff88_op in H. discriminate H. Qed.

Lemma reff88_not2670 : ~ @Equation2670 Fin4 reff88_inst.
Proof. unfold Equation2670. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff88_inst, reff88_op in H. discriminate H. Qed.

Lemma reff88_not2672 : ~ @Equation2672 Fin4 reff88_inst.
Proof. unfold Equation2672. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff88_inst, reff88_op in H. discriminate H. Qed.

Lemma reff88_not2673 : ~ @Equation2673 Fin4 reff88_inst.
Proof. unfold Equation2673. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff88_inst, reff88_op in H. discriminate H. Qed.

Lemma reff88_not2696 : ~ @Equation2696 Fin4 reff88_inst.
Proof. unfold Equation2696. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff88_inst, reff88_op in H. discriminate H. Qed.

Lemma reff88_not2697 : ~ @Equation2697 Fin4 reff88_inst.
Proof. unfold Equation2697. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff88_inst, reff88_op in H. discriminate H. Qed.

Lemma reff88_not2699 : ~ @Equation2699 Fin4 reff88_inst.
Proof. unfold Equation2699. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff88_inst, reff88_op in H. discriminate H. Qed.

Lemma reff88_not2700 : ~ @Equation2700 Fin4 reff88_inst.
Proof. unfold Equation2700. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff88_inst, reff88_op in H. discriminate H. Qed.

Lemma reff88_not2706 : ~ @Equation2706 Fin4 reff88_inst.
Proof. unfold Equation2706. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff88_inst, reff88_op in H. discriminate H. Qed.

Lemma reff88_not2707 : ~ @Equation2707 Fin4 reff88_inst.
Proof. unfold Equation2707. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff88_inst, reff88_op in H. discriminate H. Qed.

Lemma reff88_not2709 : ~ @Equation2709 Fin4 reff88_inst.
Proof. unfold Equation2709. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff88_inst, reff88_op in H. discriminate H. Qed.

Lemma reff88_not2710 : ~ @Equation2710 Fin4 reff88_inst.
Proof. unfold Equation2710. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff88_inst, reff88_op in H. discriminate H. Qed.

Lemma reff88_not2733 : ~ @Equation2733 Fin4 reff88_inst.
Proof. unfold Equation2733. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff88_inst, reff88_op in H. discriminate H. Qed.

Lemma reff88_not2734 : ~ @Equation2734 Fin4 reff88_inst.
Proof. unfold Equation2734. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff88_inst, reff88_op in H. discriminate H. Qed.

Lemma reff88_not2736 : ~ @Equation2736 Fin4 reff88_inst.
Proof. unfold Equation2736. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff88_inst, reff88_op in H. discriminate H. Qed.

Lemma reff88_not2737 : ~ @Equation2737 Fin4 reff88_inst.
Proof. unfold Equation2737. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff88_inst, reff88_op in H. discriminate H. Qed.

Lemma reff88_not2743 : ~ @Equation2743 Fin4 reff88_inst.
Proof. unfold Equation2743. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff88_inst, reff88_op in H. discriminate H. Qed.

Lemma reff88_not2744 : ~ @Equation2744 Fin4 reff88_inst.
Proof. unfold Equation2744. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff88_inst, reff88_op in H. discriminate H. Qed.

Lemma reff88_not2746 : ~ @Equation2746 Fin4 reff88_inst.
Proof. unfold Equation2746. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff88_inst, reff88_op in H. discriminate H. Qed.

Lemma reff88_not2847 : ~ @Equation2847 Fin4 reff88_inst.
Proof. unfold Equation2847. intro H. specialize (H F4_1). unfold magma_op, reff88_inst, reff88_op in H. discriminate H. Qed.

Lemma reff88_not3051 : ~ @Equation3051 Fin4 reff88_inst.
Proof. unfold Equation3051. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff88_inst, reff88_op in H. discriminate H. Qed.

Lemma reff88_not3052 : ~ @Equation3052 Fin4 reff88_inst.
Proof. unfold Equation3052. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff88_inst, reff88_op in H. discriminate H. Qed.

Lemma reff88_not3055 : ~ @Equation3055 Fin4 reff88_inst.
Proof. unfold Equation3055. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff88_inst, reff88_op in H. discriminate H. Qed.

Lemma reff88_not3056 : ~ @Equation3056 Fin4 reff88_inst.
Proof. unfold Equation3056. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff88_inst, reff88_op in H. discriminate H. Qed.

Lemma reff88_not3059 : ~ @Equation3059 Fin4 reff88_inst.
Proof. unfold Equation3059. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff88_inst, reff88_op in H. discriminate H. Qed.

Lemma reff88_not3065 : ~ @Equation3065 Fin4 reff88_inst.
Proof. unfold Equation3065. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff88_inst, reff88_op in H. discriminate H. Qed.

Lemma reff88_not3068 : ~ @Equation3068 Fin4 reff88_inst.
Proof. unfold Equation3068. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff88_inst, reff88_op in H. discriminate H. Qed.

Lemma reff88_not3069 : ~ @Equation3069 Fin4 reff88_inst.
Proof. unfold Equation3069. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff88_inst, reff88_op in H. discriminate H. Qed.

Lemma reff88_not3076 : ~ @Equation3076 Fin4 reff88_inst.
Proof. unfold Equation3076. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff88_inst, reff88_op in H. discriminate H. Qed.

Lemma reff88_not3078 : ~ @Equation3078 Fin4 reff88_inst.
Proof. unfold Equation3078. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff88_inst, reff88_op in H. discriminate H. Qed.

Lemma reff88_not3102 : ~ @Equation3102 Fin4 reff88_inst.
Proof. unfold Equation3102. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff88_inst, reff88_op in H. discriminate H. Qed.

Lemma reff88_not3103 : ~ @Equation3103 Fin4 reff88_inst.
Proof. unfold Equation3103. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff88_inst, reff88_op in H. discriminate H. Qed.

Lemma reff88_not3105 : ~ @Equation3105 Fin4 reff88_inst.
Proof. unfold Equation3105. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff88_inst, reff88_op in H. discriminate H. Qed.

Lemma reff88_not3106 : ~ @Equation3106 Fin4 reff88_inst.
Proof. unfold Equation3106. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff88_inst, reff88_op in H. discriminate H. Qed.

Lemma reff88_not3112 : ~ @Equation3112 Fin4 reff88_inst.
Proof. unfold Equation3112. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff88_inst, reff88_op in H. discriminate H. Qed.

Lemma reff88_not3113 : ~ @Equation3113 Fin4 reff88_inst.
Proof. unfold Equation3113. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff88_inst, reff88_op in H. discriminate H. Qed.

Lemma reff88_not3115 : ~ @Equation3115 Fin4 reff88_inst.
Proof. unfold Equation3115. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff88_inst, reff88_op in H. discriminate H. Qed.

Lemma reff88_not3116 : ~ @Equation3116 Fin4 reff88_inst.
Proof. unfold Equation3116. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff88_inst, reff88_op in H. discriminate H. Qed.

Lemma reff88_not3139 : ~ @Equation3139 Fin4 reff88_inst.
Proof. unfold Equation3139. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff88_inst, reff88_op in H. discriminate H. Qed.

Lemma reff88_not3140 : ~ @Equation3140 Fin4 reff88_inst.
Proof. unfold Equation3140. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff88_inst, reff88_op in H. discriminate H. Qed.

Lemma reff88_not3142 : ~ @Equation3142 Fin4 reff88_inst.
Proof. unfold Equation3142. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff88_inst, reff88_op in H. discriminate H. Qed.

Lemma reff88_not3143 : ~ @Equation3143 Fin4 reff88_inst.
Proof. unfold Equation3143. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff88_inst, reff88_op in H. discriminate H. Qed.

Lemma reff88_not3149 : ~ @Equation3149 Fin4 reff88_inst.
Proof. unfold Equation3149. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff88_inst, reff88_op in H. discriminate H. Qed.

Lemma reff88_not3150 : ~ @Equation3150 Fin4 reff88_inst.
Proof. unfold Equation3150. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff88_inst, reff88_op in H. discriminate H. Qed.

Lemma reff88_not3152 : ~ @Equation3152 Fin4 reff88_inst.
Proof. unfold Equation3152. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff88_inst, reff88_op in H. discriminate H. Qed.

Lemma reff88_not3254 : ~ @Equation3254 Fin4 reff88_inst.
Proof. unfold Equation3254. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff88_inst, reff88_op in H. discriminate H. Qed.

Lemma reff88_not3255 : ~ @Equation3255 Fin4 reff88_inst.
Proof. unfold Equation3255. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff88_inst, reff88_op in H. discriminate H. Qed.

Lemma reff88_not3258 : ~ @Equation3258 Fin4 reff88_inst.
Proof. unfold Equation3258. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff88_inst, reff88_op in H. discriminate H. Qed.

Lemma reff88_not3262 : ~ @Equation3262 Fin4 reff88_inst.
Proof. unfold Equation3262. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff88_inst, reff88_op in H. discriminate H. Qed.

Lemma reff88_not3268 : ~ @Equation3268 Fin4 reff88_inst.
Proof. unfold Equation3268. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff88_inst, reff88_op in H. discriminate H. Qed.

Lemma reff88_not3269 : ~ @Equation3269 Fin4 reff88_inst.
Proof. unfold Equation3269. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff88_inst, reff88_op in H. discriminate H. Qed.

Lemma reff88_not3271 : ~ @Equation3271 Fin4 reff88_inst.
Proof. unfold Equation3271. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff88_inst, reff88_op in H. discriminate H. Qed.

Lemma reff88_not3272 : ~ @Equation3272 Fin4 reff88_inst.
Proof. unfold Equation3272. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff88_inst, reff88_op in H. discriminate H. Qed.

Lemma reff88_not3278 : ~ @Equation3278 Fin4 reff88_inst.
Proof. unfold Equation3278. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff88_inst, reff88_op in H. discriminate H. Qed.

Lemma reff88_not3279 : ~ @Equation3279 Fin4 reff88_inst.
Proof. unfold Equation3279. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff88_inst, reff88_op in H. discriminate H. Qed.

Lemma reff88_not3281 : ~ @Equation3281 Fin4 reff88_inst.
Proof. unfold Equation3281. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff88_inst, reff88_op in H. discriminate H. Qed.

Lemma reff88_not3309 : ~ @Equation3309 Fin4 reff88_inst.
Proof. unfold Equation3309. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff88_inst, reff88_op in H. discriminate H. Qed.

Lemma reff88_not3316 : ~ @Equation3316 Fin4 reff88_inst.
Proof. unfold Equation3316. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff88_inst, reff88_op in H. discriminate H. Qed.

Lemma reff88_not3318 : ~ @Equation3318 Fin4 reff88_inst.
Proof. unfold Equation3318. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff88_inst, reff88_op in H. discriminate H. Qed.

Lemma reff88_not3342 : ~ @Equation3342 Fin4 reff88_inst.
Proof. unfold Equation3342. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff88_inst, reff88_op in H. discriminate H. Qed.

Lemma reff88_not3343 : ~ @Equation3343 Fin4 reff88_inst.
Proof. unfold Equation3343. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff88_inst, reff88_op in H. discriminate H. Qed.

Lemma reff88_not3345 : ~ @Equation3345 Fin4 reff88_inst.
Proof. unfold Equation3345. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff88_inst, reff88_op in H. discriminate H. Qed.

Lemma reff88_not3346 : ~ @Equation3346 Fin4 reff88_inst.
Proof. unfold Equation3346. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff88_inst, reff88_op in H. discriminate H. Qed.

Lemma reff88_not3352 : ~ @Equation3352 Fin4 reff88_inst.
Proof. unfold Equation3352. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff88_inst, reff88_op in H. discriminate H. Qed.

Lemma reff88_not3353 : ~ @Equation3353 Fin4 reff88_inst.
Proof. unfold Equation3353. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff88_inst, reff88_op in H. discriminate H. Qed.

Lemma reff88_not3457 : ~ @Equation3457 Fin4 reff88_inst.
Proof. unfold Equation3457. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff88_inst, reff88_op in H. discriminate H. Qed.

Lemma reff88_not3458 : ~ @Equation3458 Fin4 reff88_inst.
Proof. unfold Equation3458. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff88_inst, reff88_op in H. discriminate H. Qed.

Lemma reff88_not3461 : ~ @Equation3461 Fin4 reff88_inst.
Proof. unfold Equation3461. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff88_inst, reff88_op in H. discriminate H. Qed.

Lemma reff88_not3465 : ~ @Equation3465 Fin4 reff88_inst.
Proof. unfold Equation3465. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff88_inst, reff88_op in H. discriminate H. Qed.

Lemma reff88_not3472 : ~ @Equation3472 Fin4 reff88_inst.
Proof. unfold Equation3472. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff88_inst, reff88_op in H. discriminate H. Qed.

Lemma reff88_not3474 : ~ @Equation3474 Fin4 reff88_inst.
Proof. unfold Equation3474. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff88_inst, reff88_op in H. discriminate H. Qed.

Lemma reff88_not3475 : ~ @Equation3475 Fin4 reff88_inst.
Proof. unfold Equation3475. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff88_inst, reff88_op in H. discriminate H. Qed.

Lemma reff88_not3481 : ~ @Equation3481 Fin4 reff88_inst.
Proof. unfold Equation3481. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff88_inst, reff88_op in H. discriminate H. Qed.

Lemma reff88_not3482 : ~ @Equation3482 Fin4 reff88_inst.
Proof. unfold Equation3482. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff88_inst, reff88_op in H. discriminate H. Qed.

Lemma reff88_not3484 : ~ @Equation3484 Fin4 reff88_inst.
Proof. unfold Equation3484. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff88_inst, reff88_op in H. discriminate H. Qed.

Lemma reff88_not3512 : ~ @Equation3512 Fin4 reff88_inst.
Proof. unfold Equation3512. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff88_inst, reff88_op in H. discriminate H. Qed.

Lemma reff88_not3519 : ~ @Equation3519 Fin4 reff88_inst.
Proof. unfold Equation3519. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff88_inst, reff88_op in H. discriminate H. Qed.

Lemma reff88_not3521 : ~ @Equation3521 Fin4 reff88_inst.
Proof. unfold Equation3521. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff88_inst, reff88_op in H. discriminate H. Qed.

Lemma reff88_not3545 : ~ @Equation3545 Fin4 reff88_inst.
Proof. unfold Equation3545. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff88_inst, reff88_op in H. discriminate H. Qed.

Lemma reff88_not3546 : ~ @Equation3546 Fin4 reff88_inst.
Proof. unfold Equation3546. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff88_inst, reff88_op in H. discriminate H. Qed.

Lemma reff88_not3548 : ~ @Equation3548 Fin4 reff88_inst.
Proof. unfold Equation3548. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff88_inst, reff88_op in H. discriminate H. Qed.

Lemma reff88_not3549 : ~ @Equation3549 Fin4 reff88_inst.
Proof. unfold Equation3549. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff88_inst, reff88_op in H. discriminate H. Qed.

Lemma reff88_not3555 : ~ @Equation3555 Fin4 reff88_inst.
Proof. unfold Equation3555. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff88_inst, reff88_op in H. discriminate H. Qed.

Lemma reff88_not3556 : ~ @Equation3556 Fin4 reff88_inst.
Proof. unfold Equation3556. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff88_inst, reff88_op in H. discriminate H. Qed.

Lemma reff88_not3558 : ~ @Equation3558 Fin4 reff88_inst.
Proof. unfold Equation3558. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff88_inst, reff88_op in H. discriminate H. Qed.

Lemma reff88_not3660 : ~ @Equation3660 Fin4 reff88_inst.
Proof. unfold Equation3660. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff88_inst, reff88_op in H. discriminate H. Qed.

Lemma reff88_not3661 : ~ @Equation3661 Fin4 reff88_inst.
Proof. unfold Equation3661. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff88_inst, reff88_op in H. discriminate H. Qed.

Lemma reff88_not3664 : ~ @Equation3664 Fin4 reff88_inst.
Proof. unfold Equation3664. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff88_inst, reff88_op in H. discriminate H. Qed.

Lemma reff88_not3665 : ~ @Equation3665 Fin4 reff88_inst.
Proof. unfold Equation3665. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff88_inst, reff88_op in H. discriminate H. Qed.

Lemma reff88_not3667 : ~ @Equation3667 Fin4 reff88_inst.
Proof. unfold Equation3667. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff88_inst, reff88_op in H. discriminate H. Qed.

Lemma reff88_not3668 : ~ @Equation3668 Fin4 reff88_inst.
Proof. unfold Equation3668. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff88_inst, reff88_op in H. discriminate H. Qed.

Lemma reff88_not3674 : ~ @Equation3674 Fin4 reff88_inst.
Proof. unfold Equation3674. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff88_inst, reff88_op in H. discriminate H. Qed.

Lemma reff88_not3675 : ~ @Equation3675 Fin4 reff88_inst.
Proof. unfold Equation3675. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff88_inst, reff88_op in H. discriminate H. Qed.

Lemma reff88_not3677 : ~ @Equation3677 Fin4 reff88_inst.
Proof. unfold Equation3677. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff88_inst, reff88_op in H. discriminate H. Qed.

Lemma reff88_not3678 : ~ @Equation3678 Fin4 reff88_inst.
Proof. unfold Equation3678. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff88_inst, reff88_op in H. discriminate H. Qed.

Lemma reff88_not3684 : ~ @Equation3684 Fin4 reff88_inst.
Proof. unfold Equation3684. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff88_inst, reff88_op in H. discriminate H. Qed.

Lemma reff88_not3685 : ~ @Equation3685 Fin4 reff88_inst.
Proof. unfold Equation3685. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff88_inst, reff88_op in H. discriminate H. Qed.

Lemma reff88_not3687 : ~ @Equation3687 Fin4 reff88_inst.
Proof. unfold Equation3687. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff88_inst, reff88_op in H. discriminate H. Qed.

Lemma reff88_not3712 : ~ @Equation3712 Fin4 reff88_inst.
Proof. unfold Equation3712. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff88_inst, reff88_op in H. discriminate H. Qed.

Lemma reff88_not3714 : ~ @Equation3714 Fin4 reff88_inst.
Proof. unfold Equation3714. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff88_inst, reff88_op in H. discriminate H. Qed.

Lemma reff88_not3721 : ~ @Equation3721 Fin4 reff88_inst.
Proof. unfold Equation3721. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff88_inst, reff88_op in H. discriminate H. Qed.

Lemma reff88_not3722 : ~ @Equation3722 Fin4 reff88_inst.
Proof. unfold Equation3722. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff88_inst, reff88_op in H. discriminate H. Qed.

Lemma reff88_not3724 : ~ @Equation3724 Fin4 reff88_inst.
Proof. unfold Equation3724. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff88_inst, reff88_op in H. discriminate H. Qed.

Lemma reff88_not3725 : ~ @Equation3725 Fin4 reff88_inst.
Proof. unfold Equation3725. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff88_inst, reff88_op in H. discriminate H. Qed.

Lemma reff88_not3748 : ~ @Equation3748 Fin4 reff88_inst.
Proof. unfold Equation3748. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff88_inst, reff88_op in H. discriminate H. Qed.

Lemma reff88_not3749 : ~ @Equation3749 Fin4 reff88_inst.
Proof. unfold Equation3749. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff88_inst, reff88_op in H. discriminate H. Qed.

Lemma reff88_not3751 : ~ @Equation3751 Fin4 reff88_inst.
Proof. unfold Equation3751. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff88_inst, reff88_op in H. discriminate H. Qed.

Lemma reff88_not3752 : ~ @Equation3752 Fin4 reff88_inst.
Proof. unfold Equation3752. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff88_inst, reff88_op in H. discriminate H. Qed.

Lemma reff88_not3759 : ~ @Equation3759 Fin4 reff88_inst.
Proof. unfold Equation3759. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff88_inst, reff88_op in H. discriminate H. Qed.

Lemma reff88_not3761 : ~ @Equation3761 Fin4 reff88_inst.
Proof. unfold Equation3761. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff88_inst, reff88_op in H. discriminate H. Qed.

Lemma reff88_not3862 : ~ @Equation3862 Fin4 reff88_inst.
Proof. unfold Equation3862. intro H. specialize (H F4_1). unfold magma_op, reff88_inst, reff88_op in H. discriminate H. Qed.

Lemma reff88_not4066 : ~ @Equation4066 Fin4 reff88_inst.
Proof. unfold Equation4066. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff88_inst, reff88_op in H. discriminate H. Qed.

Lemma reff88_not4067 : ~ @Equation4067 Fin4 reff88_inst.
Proof. unfold Equation4067. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff88_inst, reff88_op in H. discriminate H. Qed.

Lemma reff88_not4070 : ~ @Equation4070 Fin4 reff88_inst.
Proof. unfold Equation4070. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff88_inst, reff88_op in H. discriminate H. Qed.

Lemma reff88_not4071 : ~ @Equation4071 Fin4 reff88_inst.
Proof. unfold Equation4071. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff88_inst, reff88_op in H. discriminate H. Qed.

Lemma reff88_not4074 : ~ @Equation4074 Fin4 reff88_inst.
Proof. unfold Equation4074. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff88_inst, reff88_op in H. discriminate H. Qed.

Lemma reff88_not4080 : ~ @Equation4080 Fin4 reff88_inst.
Proof. unfold Equation4080. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff88_inst, reff88_op in H. discriminate H. Qed.

Lemma reff88_not4081 : ~ @Equation4081 Fin4 reff88_inst.
Proof. unfold Equation4081. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff88_inst, reff88_op in H. discriminate H. Qed.

Lemma reff88_not4083 : ~ @Equation4083 Fin4 reff88_inst.
Proof. unfold Equation4083. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff88_inst, reff88_op in H. discriminate H. Qed.

Lemma reff88_not4084 : ~ @Equation4084 Fin4 reff88_inst.
Proof. unfold Equation4084. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff88_inst, reff88_op in H. discriminate H. Qed.

Lemma reff88_not4090 : ~ @Equation4090 Fin4 reff88_inst.
Proof. unfold Equation4090. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff88_inst, reff88_op in H. discriminate H. Qed.

Lemma reff88_not4091 : ~ @Equation4091 Fin4 reff88_inst.
Proof. unfold Equation4091. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff88_inst, reff88_op in H. discriminate H. Qed.

Lemma reff88_not4093 : ~ @Equation4093 Fin4 reff88_inst.
Proof. unfold Equation4093. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff88_inst, reff88_op in H. discriminate H. Qed.

Lemma reff88_not4120 : ~ @Equation4120 Fin4 reff88_inst.
Proof. unfold Equation4120. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff88_inst, reff88_op in H. discriminate H. Qed.

Lemma reff88_not4121 : ~ @Equation4121 Fin4 reff88_inst.
Proof. unfold Equation4121. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff88_inst, reff88_op in H. discriminate H. Qed.

Lemma reff88_not4128 : ~ @Equation4128 Fin4 reff88_inst.
Proof. unfold Equation4128. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff88_inst, reff88_op in H. discriminate H. Qed.

Lemma reff88_not4130 : ~ @Equation4130 Fin4 reff88_inst.
Proof. unfold Equation4130. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff88_inst, reff88_op in H. discriminate H. Qed.

Lemma reff88_not4155 : ~ @Equation4155 Fin4 reff88_inst.
Proof. unfold Equation4155. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff88_inst, reff88_op in H. discriminate H. Qed.

Lemma reff88_not4157 : ~ @Equation4157 Fin4 reff88_inst.
Proof. unfold Equation4157. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff88_inst, reff88_op in H. discriminate H. Qed.

Lemma reff88_not4158 : ~ @Equation4158 Fin4 reff88_inst.
Proof. unfold Equation4158. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff88_inst, reff88_op in H. discriminate H. Qed.

Lemma reff88_not4164 : ~ @Equation4164 Fin4 reff88_inst.
Proof. unfold Equation4164. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff88_inst, reff88_op in H. discriminate H. Qed.

Lemma reff88_not4165 : ~ @Equation4165 Fin4 reff88_inst.
Proof. unfold Equation4165. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff88_inst, reff88_op in H. discriminate H. Qed.

Lemma reff88_not4167 : ~ @Equation4167 Fin4 reff88_inst.
Proof. unfold Equation4167. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff88_inst, reff88_op in H. discriminate H. Qed.

Lemma reff88_not4268 : ~ @Equation4268 Fin4 reff88_inst.
Proof. unfold Equation4268. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff88_inst, reff88_op in H. discriminate H. Qed.

Lemma reff88_not4269 : ~ @Equation4269 Fin4 reff88_inst.
Proof. unfold Equation4269. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff88_inst, reff88_op in H. discriminate H. Qed.

Lemma reff88_not4272 : ~ @Equation4272 Fin4 reff88_inst.
Proof. unfold Equation4272. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff88_inst, reff88_op in H. discriminate H. Qed.

Lemma reff88_not4273 : ~ @Equation4273 Fin4 reff88_inst.
Proof. unfold Equation4273. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff88_inst, reff88_op in H. discriminate H. Qed.

Lemma reff88_not4275 : ~ @Equation4275 Fin4 reff88_inst.
Proof. unfold Equation4275. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff88_inst, reff88_op in H. discriminate H. Qed.

Lemma reff88_not4276 : ~ @Equation4276 Fin4 reff88_inst.
Proof. unfold Equation4276. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff88_inst, reff88_op in H. discriminate H. Qed.

Lemma reff88_not4284 : ~ @Equation4284 Fin4 reff88_inst.
Proof. unfold Equation4284. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff88_inst, reff88_op in H. discriminate H. Qed.

Lemma reff88_not4290 : ~ @Equation4290 Fin4 reff88_inst.
Proof. unfold Equation4290. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff88_inst, reff88_op in H. discriminate H. Qed.

Lemma reff88_not4291 : ~ @Equation4291 Fin4 reff88_inst.
Proof. unfold Equation4291. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff88_inst, reff88_op in H. discriminate H. Qed.

Lemma reff88_not4293 : ~ @Equation4293 Fin4 reff88_inst.
Proof. unfold Equation4293. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff88_inst, reff88_op in H. discriminate H. Qed.

Lemma reff88_not4314 : ~ @Equation4314 Fin4 reff88_inst.
Proof. unfold Equation4314. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff88_inst, reff88_op in H. discriminate H. Qed.

Lemma reff88_not4320 : ~ @Equation4320 Fin4 reff88_inst.
Proof. unfold Equation4320. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff88_inst, reff88_op in H. discriminate H. Qed.

Lemma reff88_not4321 : ~ @Equation4321 Fin4 reff88_inst.
Proof. unfold Equation4321. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff88_inst, reff88_op in H. discriminate H. Qed.

Lemma reff88_not4343 : ~ @Equation4343 Fin4 reff88_inst.
Proof. unfold Equation4343. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff88_inst, reff88_op in H. discriminate H. Qed.

Lemma reff88_not4380 : ~ @Equation4380 Fin4 reff88_inst.
Proof. unfold Equation4380. intro H. specialize (H F4_1). unfold magma_op, reff88_inst, reff88_op in H. discriminate H. Qed.

Lemma reff88_not4583 : ~ @Equation4583 Fin4 reff88_inst.
Proof. unfold Equation4583. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff88_inst, reff88_op in H. discriminate H. Qed.

Lemma reff88_not4584 : ~ @Equation4584 Fin4 reff88_inst.
Proof. unfold Equation4584. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff88_inst, reff88_op in H. discriminate H. Qed.

Lemma reff88_not4587 : ~ @Equation4587 Fin4 reff88_inst.
Proof. unfold Equation4587. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff88_inst, reff88_op in H. discriminate H. Qed.

Lemma reff88_not4588 : ~ @Equation4588 Fin4 reff88_inst.
Proof. unfold Equation4588. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff88_inst, reff88_op in H. discriminate H. Qed.

Lemma reff88_not4590 : ~ @Equation4590 Fin4 reff88_inst.
Proof. unfold Equation4590. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff88_inst, reff88_op in H. discriminate H. Qed.

Lemma reff88_not4591 : ~ @Equation4591 Fin4 reff88_inst.
Proof. unfold Equation4591. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff88_inst, reff88_op in H. discriminate H. Qed.

Lemma reff88_not4598 : ~ @Equation4598 Fin4 reff88_inst.
Proof. unfold Equation4598. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff88_inst, reff88_op in H. discriminate H. Qed.

Lemma reff88_not4599 : ~ @Equation4599 Fin4 reff88_inst.
Proof. unfold Equation4599. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff88_inst, reff88_op in H. discriminate H. Qed.

Lemma reff88_not4605 : ~ @Equation4605 Fin4 reff88_inst.
Proof. unfold Equation4605. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff88_inst, reff88_op in H. discriminate H. Qed.

Lemma reff88_not4606 : ~ @Equation4606 Fin4 reff88_inst.
Proof. unfold Equation4606. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff88_inst, reff88_op in H. discriminate H. Qed.

Lemma reff88_not4608 : ~ @Equation4608 Fin4 reff88_inst.
Proof. unfold Equation4608. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff88_inst, reff88_op in H. discriminate H. Qed.

Lemma reff88_not4629 : ~ @Equation4629 Fin4 reff88_inst.
Proof. unfold Equation4629. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff88_inst, reff88_op in H. discriminate H. Qed.

Lemma reff88_not4635 : ~ @Equation4635 Fin4 reff88_inst.
Proof. unfold Equation4635. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff88_inst, reff88_op in H. discriminate H. Qed.

Lemma reff88_not4636 : ~ @Equation4636 Fin4 reff88_inst.
Proof. unfold Equation4636. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff88_inst, reff88_op in H. discriminate H. Qed.

Lemma reff88_not4658 : ~ @Equation4658 Fin4 reff88_inst.
Proof. unfold Equation4658. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff88_inst, reff88_op in H. discriminate H. Qed.

(** ---- reff90 (Fin4) ---- *)

Definition reff90_op (x y : Fin4) : Fin4 :=
  match x, y with
  | F4_0, F4_0 => F4_0 | F4_0, F4_1 => F4_1 | F4_0, F4_2 => F4_2 | F4_0, F4_3 => F4_3
  | F4_1, F4_0 => F4_3 | F4_1, F4_1 => F4_2 | F4_1, F4_2 => F4_1 | F4_1, F4_3 => F4_0
  | F4_2, F4_0 => F4_0 | F4_2, F4_1 => F4_1 | F4_2, F4_2 => F4_2 | F4_2, F4_3 => F4_3
  | F4_3, F4_0 => F4_3 | F4_3, F4_1 => F4_2 | F4_3, F4_2 => F4_1 | F4_3, F4_3 => F4_0
  end.

#[local] Instance reff90_inst : Magma Fin4 := {| magma_op := reff90_op |}.

Lemma reff90_sat16 : @Equation16 Fin4 reff90_inst.
Proof. unfold Equation16, magma_op, reff90_inst, reff90_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff90_sat31 : @Equation31 Fin4 reff90_inst.
Proof. unfold Equation31, magma_op, reff90_inst, reff90_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff90_sat562 : @Equation562 Fin4 reff90_inst.
Proof. unfold Equation562, magma_op, reff90_inst, reff90_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff90_sat731 : @Equation731 Fin4 reff90_inst.
Proof. unfold Equation731, magma_op, reff90_inst, reff90_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff90_sat765 : @Equation765 Fin4 reff90_inst.
Proof. unfold Equation765, magma_op, reff90_inst, reff90_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff90_sat778 : @Equation778 Fin4 reff90_inst.
Proof. unfold Equation778, magma_op, reff90_inst, reff90_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff90_sat934 : @Equation934 Fin4 reff90_inst.
Proof. unfold Equation934, magma_op, reff90_inst, reff90_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff90_sat968 : @Equation968 Fin4 reff90_inst.
Proof. unfold Equation968, magma_op, reff90_inst, reff90_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff90_sat981 : @Equation981 Fin4 reff90_inst.
Proof. unfold Equation981, magma_op, reff90_inst, reff90_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff90_sat1137 : @Equation1137 Fin4 reff90_inst.
Proof. unfold Equation1137, magma_op, reff90_inst, reff90_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff90_sat1171 : @Equation1171 Fin4 reff90_inst.
Proof. unfold Equation1171, magma_op, reff90_inst, reff90_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff90_sat1340 : @Equation1340 Fin4 reff90_inst.
Proof. unfold Equation1340, magma_op, reff90_inst, reff90_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff90_sat1374 : @Equation1374 Fin4 reff90_inst.
Proof. unfold Equation1374, magma_op, reff90_inst, reff90_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff90_sat1387 : @Equation1387 Fin4 reff90_inst.
Proof. unfold Equation1387, magma_op, reff90_inst, reff90_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff90_sat1543 : @Equation1543 Fin4 reff90_inst.
Proof. unfold Equation1543, magma_op, reff90_inst, reff90_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff90_sat1577 : @Equation1577 Fin4 reff90_inst.
Proof. unfold Equation1577, magma_op, reff90_inst, reff90_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff90_sat1590 : @Equation1590 Fin4 reff90_inst.
Proof. unfold Equation1590, magma_op, reff90_inst, reff90_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff90_sat1793 : @Equation1793 Fin4 reff90_inst.
Proof. unfold Equation1793, magma_op, reff90_inst, reff90_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff90_sat1983 : @Equation1983 Fin4 reff90_inst.
Proof. unfold Equation1983, magma_op, reff90_inst, reff90_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff90_sat1996 : @Equation1996 Fin4 reff90_inst.
Proof. unfold Equation1996, magma_op, reff90_inst, reff90_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff90_sat2152 : @Equation2152 Fin4 reff90_inst.
Proof. unfold Equation2152, magma_op, reff90_inst, reff90_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff90_sat2186 : @Equation2186 Fin4 reff90_inst.
Proof. unfold Equation2186, magma_op, reff90_inst, reff90_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff90_sat2199 : @Equation2199 Fin4 reff90_inst.
Proof. unfold Equation2199, magma_op, reff90_inst, reff90_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff90_sat2355 : @Equation2355 Fin4 reff90_inst.
Proof. unfold Equation2355, magma_op, reff90_inst, reff90_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff90_sat2389 : @Equation2389 Fin4 reff90_inst.
Proof. unfold Equation2389, magma_op, reff90_inst, reff90_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff90_sat2402 : @Equation2402 Fin4 reff90_inst.
Proof. unfold Equation2402, magma_op, reff90_inst, reff90_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff90_sat2558 : @Equation2558 Fin4 reff90_inst.
Proof. unfold Equation2558, magma_op, reff90_inst, reff90_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff90_sat2592 : @Equation2592 Fin4 reff90_inst.
Proof. unfold Equation2592, magma_op, reff90_inst, reff90_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff90_sat2808 : @Equation2808 Fin4 reff90_inst.
Proof. unfold Equation2808, magma_op, reff90_inst, reff90_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff90_sat2964 : @Equation2964 Fin4 reff90_inst.
Proof. unfold Equation2964, magma_op, reff90_inst, reff90_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff90_sat2998 : @Equation2998 Fin4 reff90_inst.
Proof. unfold Equation2998, magma_op, reff90_inst, reff90_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff90_sat3011 : @Equation3011 Fin4 reff90_inst.
Proof. unfold Equation3011, magma_op, reff90_inst, reff90_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff90_sat3201 : @Equation3201 Fin4 reff90_inst.
Proof. unfold Equation3201, magma_op, reff90_inst, reff90_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff90_sat3214 : @Equation3214 Fin4 reff90_inst.
Proof. unfold Equation3214, magma_op, reff90_inst, reff90_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff90_sat3388 : @Equation3388 Fin4 reff90_inst.
Proof. unfold Equation3388, magma_op, reff90_inst, reff90_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff90_sat3591 : @Equation3591 Fin4 reff90_inst.
Proof. unfold Equation3591, magma_op, reff90_inst, reff90_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff90_sat3617 : @Equation3617 Fin4 reff90_inst.
Proof. unfold Equation3617, magma_op, reff90_inst, reff90_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff90_sat3740 : @Equation3740 Fin4 reff90_inst.
Proof. unfold Equation3740, magma_op, reff90_inst, reff90_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff90_sat3794 : @Equation3794 Fin4 reff90_inst.
Proof. unfold Equation3794, magma_op, reff90_inst, reff90_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff90_sat3943 : @Equation3943 Fin4 reff90_inst.
Proof. unfold Equation3943, magma_op, reff90_inst, reff90_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff90_sat4146 : @Equation4146 Fin4 reff90_inst.
Proof. unfold Equation4146, magma_op, reff90_inst, reff90_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff90_sat4200 : @Equation4200 Fin4 reff90_inst.
Proof. unfold Equation4200, magma_op, reff90_inst, reff90_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff90_sat4362 : @Equation4362 Fin4 reff90_inst.
Proof. unfold Equation4362, magma_op, reff90_inst, reff90_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff90_sat4424 : @Equation4424 Fin4 reff90_inst.
Proof. unfold Equation4424, magma_op, reff90_inst, reff90_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff90_sat4512 : @Equation4512 Fin4 reff90_inst.
Proof. unfold Equation4512, magma_op, reff90_inst, reff90_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff90_sat4525 : @Equation4525 Fin4 reff90_inst.
Proof. unfold Equation4525, magma_op, reff90_inst, reff90_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff90_sat4677 : @Equation4677 Fin4 reff90_inst.
Proof. unfold Equation4677, magma_op, reff90_inst, reff90_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff90_not47 : ~ @Equation47 Fin4 reff90_inst.
Proof. unfold Equation47. intro H. specialize (H F4_1). unfold magma_op, reff90_inst, reff90_op in H. discriminate H. Qed.

Lemma reff90_not99 : ~ @Equation99 Fin4 reff90_inst.
Proof. unfold Equation99. intro H. specialize (H F4_1). unfold magma_op, reff90_inst, reff90_op in H. discriminate H. Qed.

Lemma reff90_not151 : ~ @Equation151 Fin4 reff90_inst.
Proof. unfold Equation151. intro H. specialize (H F4_1). unfold magma_op, reff90_inst, reff90_op in H. discriminate H. Qed.

Lemma reff90_not203 : ~ @Equation203 Fin4 reff90_inst.
Proof. unfold Equation203. intro H. specialize (H F4_1). unfold magma_op, reff90_inst, reff90_op in H. discriminate H. Qed.

Lemma reff90_not255 : ~ @Equation255 Fin4 reff90_inst.
Proof. unfold Equation255. intro H. specialize (H F4_1). unfold magma_op, reff90_inst, reff90_op in H. discriminate H. Qed.

Lemma reff90_not307 : ~ @Equation307 Fin4 reff90_inst.
Proof. unfold Equation307. intro H. specialize (H F4_1). unfold magma_op, reff90_inst, reff90_op in H. discriminate H. Qed.

Lemma reff90_not359 : ~ @Equation359 Fin4 reff90_inst.
Proof. unfold Equation359. intro H. specialize (H F4_1). unfold magma_op, reff90_inst, reff90_op in H. discriminate H. Qed.

Lemma reff90_not412 : ~ @Equation412 Fin4 reff90_inst.
Proof. unfold Equation412. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff90_inst, reff90_op in H. discriminate H. Qed.

Lemma reff90_not413 : ~ @Equation413 Fin4 reff90_inst.
Proof. unfold Equation413. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff90_inst, reff90_op in H. discriminate H. Qed.

Lemma reff90_not414 : ~ @Equation414 Fin4 reff90_inst.
Proof. unfold Equation414. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff90_inst, reff90_op in H. discriminate H. Qed.

Lemma reff90_not416 : ~ @Equation416 Fin4 reff90_inst.
Proof. unfold Equation416. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff90_inst, reff90_op in H. discriminate H. Qed.

Lemma reff90_not417 : ~ @Equation417 Fin4 reff90_inst.
Proof. unfold Equation417. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff90_inst, reff90_op in H. discriminate H. Qed.

Lemma reff90_not420 : ~ @Equation420 Fin4 reff90_inst.
Proof. unfold Equation420. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff90_inst, reff90_op in H. discriminate H. Qed.

Lemma reff90_not426 : ~ @Equation426 Fin4 reff90_inst.
Proof. unfold Equation426. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff90_inst, reff90_op in H. discriminate H. Qed.

Lemma reff90_not427 : ~ @Equation427 Fin4 reff90_inst.
Proof. unfold Equation427. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff90_inst, reff90_op in H. discriminate H. Qed.

Lemma reff90_not430 : ~ @Equation430 Fin4 reff90_inst.
Proof. unfold Equation430. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff90_inst, reff90_op in H. discriminate H. Qed.

Lemma reff90_not437 : ~ @Equation437 Fin4 reff90_inst.
Proof. unfold Equation437. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff90_inst, reff90_op in H. discriminate H. Qed.

Lemma reff90_not439 : ~ @Equation439 Fin4 reff90_inst.
Proof. unfold Equation439. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff90_inst, reff90_op in H. discriminate H. Qed.

Lemma reff90_not440 : ~ @Equation440 Fin4 reff90_inst.
Proof. unfold Equation440. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff90_inst, reff90_op in H. discriminate H. Qed.

Lemma reff90_not463 : ~ @Equation463 Fin4 reff90_inst.
Proof. unfold Equation463. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff90_inst, reff90_op in H. discriminate H. Qed.

Lemma reff90_not464 : ~ @Equation464 Fin4 reff90_inst.
Proof. unfold Equation464. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff90_inst, reff90_op in H. discriminate H. Qed.

Lemma reff90_not467 : ~ @Equation467 Fin4 reff90_inst.
Proof. unfold Equation467. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff90_inst, reff90_op in H. discriminate H. Qed.

Lemma reff90_not474 : ~ @Equation474 Fin4 reff90_inst.
Proof. unfold Equation474. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff90_inst, reff90_op in H. discriminate H. Qed.

Lemma reff90_not476 : ~ @Equation476 Fin4 reff90_inst.
Proof. unfold Equation476. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff90_inst, reff90_op in H. discriminate H. Qed.

Lemma reff90_not477 : ~ @Equation477 Fin4 reff90_inst.
Proof. unfold Equation477. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff90_inst, reff90_op in H. discriminate H. Qed.

Lemma reff90_not501 : ~ @Equation501 Fin4 reff90_inst.
Proof. unfold Equation501. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff90_inst, reff90_op in H. discriminate H. Qed.

Lemma reff90_not503 : ~ @Equation503 Fin4 reff90_inst.
Proof. unfold Equation503. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff90_inst, reff90_op in H. discriminate H. Qed.

Lemma reff90_not504 : ~ @Equation504 Fin4 reff90_inst.
Proof. unfold Equation504. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff90_inst, reff90_op in H. discriminate H. Qed.

Lemma reff90_not510 : ~ @Equation510 Fin4 reff90_inst.
Proof. unfold Equation510. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff90_inst, reff90_op in H. discriminate H. Qed.

Lemma reff90_not511 : ~ @Equation511 Fin4 reff90_inst.
Proof. unfold Equation511. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff90_inst, reff90_op in H. discriminate H. Qed.

Lemma reff90_not615 : ~ @Equation615 Fin4 reff90_inst.
Proof. unfold Equation615. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff90_inst, reff90_op in H. discriminate H. Qed.

Lemma reff90_not616 : ~ @Equation616 Fin4 reff90_inst.
Proof. unfold Equation616. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff90_inst, reff90_op in H. discriminate H. Qed.

Lemma reff90_not617 : ~ @Equation617 Fin4 reff90_inst.
Proof. unfold Equation617. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff90_inst, reff90_op in H. discriminate H. Qed.

Lemma reff90_not619 : ~ @Equation619 Fin4 reff90_inst.
Proof. unfold Equation619. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff90_inst, reff90_op in H. discriminate H. Qed.

Lemma reff90_not620 : ~ @Equation620 Fin4 reff90_inst.
Proof. unfold Equation620. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff90_inst, reff90_op in H. discriminate H. Qed.

Lemma reff90_not623 : ~ @Equation623 Fin4 reff90_inst.
Proof. unfold Equation623. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff90_inst, reff90_op in H. discriminate H. Qed.

Lemma reff90_not629 : ~ @Equation629 Fin4 reff90_inst.
Proof. unfold Equation629. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff90_inst, reff90_op in H. discriminate H. Qed.

Lemma reff90_not630 : ~ @Equation630 Fin4 reff90_inst.
Proof. unfold Equation630. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff90_inst, reff90_op in H. discriminate H. Qed.

Lemma reff90_not633 : ~ @Equation633 Fin4 reff90_inst.
Proof. unfold Equation633. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff90_inst, reff90_op in H. discriminate H. Qed.

Lemma reff90_not640 : ~ @Equation640 Fin4 reff90_inst.
Proof. unfold Equation640. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff90_inst, reff90_op in H. discriminate H. Qed.

Lemma reff90_not642 : ~ @Equation642 Fin4 reff90_inst.
Proof. unfold Equation642. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff90_inst, reff90_op in H. discriminate H. Qed.

Lemma reff90_not643 : ~ @Equation643 Fin4 reff90_inst.
Proof. unfold Equation643. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff90_inst, reff90_op in H. discriminate H. Qed.

Lemma reff90_not666 : ~ @Equation666 Fin4 reff90_inst.
Proof. unfold Equation666. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff90_inst, reff90_op in H. discriminate H. Qed.

Lemma reff90_not667 : ~ @Equation667 Fin4 reff90_inst.
Proof. unfold Equation667. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff90_inst, reff90_op in H. discriminate H. Qed.

Lemma reff90_not670 : ~ @Equation670 Fin4 reff90_inst.
Proof. unfold Equation670. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff90_inst, reff90_op in H. discriminate H. Qed.

Lemma reff90_not677 : ~ @Equation677 Fin4 reff90_inst.
Proof. unfold Equation677. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff90_inst, reff90_op in H. discriminate H. Qed.

Lemma reff90_not679 : ~ @Equation679 Fin4 reff90_inst.
Proof. unfold Equation679. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff90_inst, reff90_op in H. discriminate H. Qed.

Lemma reff90_not680 : ~ @Equation680 Fin4 reff90_inst.
Proof. unfold Equation680. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff90_inst, reff90_op in H. discriminate H. Qed.

Lemma reff90_not704 : ~ @Equation704 Fin4 reff90_inst.
Proof. unfold Equation704. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff90_inst, reff90_op in H. discriminate H. Qed.

Lemma reff90_not706 : ~ @Equation706 Fin4 reff90_inst.
Proof. unfold Equation706. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff90_inst, reff90_op in H. discriminate H. Qed.

Lemma reff90_not707 : ~ @Equation707 Fin4 reff90_inst.
Proof. unfold Equation707. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff90_inst, reff90_op in H. discriminate H. Qed.

Lemma reff90_not713 : ~ @Equation713 Fin4 reff90_inst.
Proof. unfold Equation713. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff90_inst, reff90_op in H. discriminate H. Qed.

Lemma reff90_not714 : ~ @Equation714 Fin4 reff90_inst.
Proof. unfold Equation714. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff90_inst, reff90_op in H. discriminate H. Qed.

Lemma reff90_not818 : ~ @Equation818 Fin4 reff90_inst.
Proof. unfold Equation818. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff90_inst, reff90_op in H. discriminate H. Qed.

Lemma reff90_not819 : ~ @Equation819 Fin4 reff90_inst.
Proof. unfold Equation819. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff90_inst, reff90_op in H. discriminate H. Qed.

Lemma reff90_not820 : ~ @Equation820 Fin4 reff90_inst.
Proof. unfold Equation820. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff90_inst, reff90_op in H. discriminate H. Qed.

Lemma reff90_not822 : ~ @Equation822 Fin4 reff90_inst.
Proof. unfold Equation822. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff90_inst, reff90_op in H. discriminate H. Qed.

Lemma reff90_not823 : ~ @Equation823 Fin4 reff90_inst.
Proof. unfold Equation823. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff90_inst, reff90_op in H. discriminate H. Qed.

Lemma reff90_not826 : ~ @Equation826 Fin4 reff90_inst.
Proof. unfold Equation826. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff90_inst, reff90_op in H. discriminate H. Qed.

Lemma reff90_not832 : ~ @Equation832 Fin4 reff90_inst.
Proof. unfold Equation832. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff90_inst, reff90_op in H. discriminate H. Qed.

Lemma reff90_not833 : ~ @Equation833 Fin4 reff90_inst.
Proof. unfold Equation833. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff90_inst, reff90_op in H. discriminate H. Qed.

Lemma reff90_not836 : ~ @Equation836 Fin4 reff90_inst.
Proof. unfold Equation836. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff90_inst, reff90_op in H. discriminate H. Qed.

Lemma reff90_not843 : ~ @Equation843 Fin4 reff90_inst.
Proof. unfold Equation843. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff90_inst, reff90_op in H. discriminate H. Qed.

Lemma reff90_not845 : ~ @Equation845 Fin4 reff90_inst.
Proof. unfold Equation845. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff90_inst, reff90_op in H. discriminate H. Qed.

Lemma reff90_not846 : ~ @Equation846 Fin4 reff90_inst.
Proof. unfold Equation846. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff90_inst, reff90_op in H. discriminate H. Qed.

Lemma reff90_not869 : ~ @Equation869 Fin4 reff90_inst.
Proof. unfold Equation869. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff90_inst, reff90_op in H. discriminate H. Qed.

Lemma reff90_not870 : ~ @Equation870 Fin4 reff90_inst.
Proof. unfold Equation870. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff90_inst, reff90_op in H. discriminate H. Qed.

Lemma reff90_not873 : ~ @Equation873 Fin4 reff90_inst.
Proof. unfold Equation873. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff90_inst, reff90_op in H. discriminate H. Qed.

Lemma reff90_not880 : ~ @Equation880 Fin4 reff90_inst.
Proof. unfold Equation880. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff90_inst, reff90_op in H. discriminate H. Qed.

Lemma reff90_not882 : ~ @Equation882 Fin4 reff90_inst.
Proof. unfold Equation882. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff90_inst, reff90_op in H. discriminate H. Qed.

Lemma reff90_not883 : ~ @Equation883 Fin4 reff90_inst.
Proof. unfold Equation883. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff90_inst, reff90_op in H. discriminate H. Qed.

Lemma reff90_not907 : ~ @Equation907 Fin4 reff90_inst.
Proof. unfold Equation907. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff90_inst, reff90_op in H. discriminate H. Qed.

Lemma reff90_not909 : ~ @Equation909 Fin4 reff90_inst.
Proof. unfold Equation909. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff90_inst, reff90_op in H. discriminate H. Qed.

Lemma reff90_not910 : ~ @Equation910 Fin4 reff90_inst.
Proof. unfold Equation910. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff90_inst, reff90_op in H. discriminate H. Qed.

Lemma reff90_not916 : ~ @Equation916 Fin4 reff90_inst.
Proof. unfold Equation916. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff90_inst, reff90_op in H. discriminate H. Qed.

Lemma reff90_not917 : ~ @Equation917 Fin4 reff90_inst.
Proof. unfold Equation917. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff90_inst, reff90_op in H. discriminate H. Qed.

Lemma reff90_not1021 : ~ @Equation1021 Fin4 reff90_inst.
Proof. unfold Equation1021. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff90_inst, reff90_op in H. discriminate H. Qed.

Lemma reff90_not1022 : ~ @Equation1022 Fin4 reff90_inst.
Proof. unfold Equation1022. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff90_inst, reff90_op in H. discriminate H. Qed.

Lemma reff90_not1023 : ~ @Equation1023 Fin4 reff90_inst.
Proof. unfold Equation1023. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff90_inst, reff90_op in H. discriminate H. Qed.

Lemma reff90_not1025 : ~ @Equation1025 Fin4 reff90_inst.
Proof. unfold Equation1025. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff90_inst, reff90_op in H. discriminate H. Qed.

Lemma reff90_not1026 : ~ @Equation1026 Fin4 reff90_inst.
Proof. unfold Equation1026. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff90_inst, reff90_op in H. discriminate H. Qed.

Lemma reff90_not1029 : ~ @Equation1029 Fin4 reff90_inst.
Proof. unfold Equation1029. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff90_inst, reff90_op in H. discriminate H. Qed.

Lemma reff90_not1035 : ~ @Equation1035 Fin4 reff90_inst.
Proof. unfold Equation1035. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff90_inst, reff90_op in H. discriminate H. Qed.

Lemma reff90_not1036 : ~ @Equation1036 Fin4 reff90_inst.
Proof. unfold Equation1036. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff90_inst, reff90_op in H. discriminate H. Qed.

Lemma reff90_not1039 : ~ @Equation1039 Fin4 reff90_inst.
Proof. unfold Equation1039. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff90_inst, reff90_op in H. discriminate H. Qed.

Lemma reff90_not1046 : ~ @Equation1046 Fin4 reff90_inst.
Proof. unfold Equation1046. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff90_inst, reff90_op in H. discriminate H. Qed.

Lemma reff90_not1048 : ~ @Equation1048 Fin4 reff90_inst.
Proof. unfold Equation1048. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff90_inst, reff90_op in H. discriminate H. Qed.

Lemma reff90_not1049 : ~ @Equation1049 Fin4 reff90_inst.
Proof. unfold Equation1049. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff90_inst, reff90_op in H. discriminate H. Qed.

Lemma reff90_not1072 : ~ @Equation1072 Fin4 reff90_inst.
Proof. unfold Equation1072. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff90_inst, reff90_op in H. discriminate H. Qed.

Lemma reff90_not1073 : ~ @Equation1073 Fin4 reff90_inst.
Proof. unfold Equation1073. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff90_inst, reff90_op in H. discriminate H. Qed.

Lemma reff90_not1076 : ~ @Equation1076 Fin4 reff90_inst.
Proof. unfold Equation1076. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff90_inst, reff90_op in H. discriminate H. Qed.

Lemma reff90_not1083 : ~ @Equation1083 Fin4 reff90_inst.
Proof. unfold Equation1083. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff90_inst, reff90_op in H. discriminate H. Qed.

Lemma reff90_not1085 : ~ @Equation1085 Fin4 reff90_inst.
Proof. unfold Equation1085. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff90_inst, reff90_op in H. discriminate H. Qed.

Lemma reff90_not1086 : ~ @Equation1086 Fin4 reff90_inst.
Proof. unfold Equation1086. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff90_inst, reff90_op in H. discriminate H. Qed.

Lemma reff90_not1110 : ~ @Equation1110 Fin4 reff90_inst.
Proof. unfold Equation1110. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff90_inst, reff90_op in H. discriminate H. Qed.

Lemma reff90_not1112 : ~ @Equation1112 Fin4 reff90_inst.
Proof. unfold Equation1112. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff90_inst, reff90_op in H. discriminate H. Qed.

Lemma reff90_not1113 : ~ @Equation1113 Fin4 reff90_inst.
Proof. unfold Equation1113. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff90_inst, reff90_op in H. discriminate H. Qed.

Lemma reff90_not1119 : ~ @Equation1119 Fin4 reff90_inst.
Proof. unfold Equation1119. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff90_inst, reff90_op in H. discriminate H. Qed.

Lemma reff90_not1120 : ~ @Equation1120 Fin4 reff90_inst.
Proof. unfold Equation1120. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff90_inst, reff90_op in H. discriminate H. Qed.

Lemma reff90_not1224 : ~ @Equation1224 Fin4 reff90_inst.
Proof. unfold Equation1224. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff90_inst, reff90_op in H. discriminate H. Qed.

Lemma reff90_not1225 : ~ @Equation1225 Fin4 reff90_inst.
Proof. unfold Equation1225. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff90_inst, reff90_op in H. discriminate H. Qed.

Lemma reff90_not1226 : ~ @Equation1226 Fin4 reff90_inst.
Proof. unfold Equation1226. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff90_inst, reff90_op in H. discriminate H. Qed.

Lemma reff90_not1228 : ~ @Equation1228 Fin4 reff90_inst.
Proof. unfold Equation1228. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff90_inst, reff90_op in H. discriminate H. Qed.

Lemma reff90_not1229 : ~ @Equation1229 Fin4 reff90_inst.
Proof. unfold Equation1229. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff90_inst, reff90_op in H. discriminate H. Qed.

Lemma reff90_not1232 : ~ @Equation1232 Fin4 reff90_inst.
Proof. unfold Equation1232. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff90_inst, reff90_op in H. discriminate H. Qed.

Lemma reff90_not1238 : ~ @Equation1238 Fin4 reff90_inst.
Proof. unfold Equation1238. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff90_inst, reff90_op in H. discriminate H. Qed.

Lemma reff90_not1239 : ~ @Equation1239 Fin4 reff90_inst.
Proof. unfold Equation1239. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff90_inst, reff90_op in H. discriminate H. Qed.

Lemma reff90_not1242 : ~ @Equation1242 Fin4 reff90_inst.
Proof. unfold Equation1242. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff90_inst, reff90_op in H. discriminate H. Qed.

Lemma reff90_not1249 : ~ @Equation1249 Fin4 reff90_inst.
Proof. unfold Equation1249. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff90_inst, reff90_op in H. discriminate H. Qed.

Lemma reff90_not1251 : ~ @Equation1251 Fin4 reff90_inst.
Proof. unfold Equation1251. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff90_inst, reff90_op in H. discriminate H. Qed.

Lemma reff90_not1252 : ~ @Equation1252 Fin4 reff90_inst.
Proof. unfold Equation1252. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff90_inst, reff90_op in H. discriminate H. Qed.

Lemma reff90_not1275 : ~ @Equation1275 Fin4 reff90_inst.
Proof. unfold Equation1275. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff90_inst, reff90_op in H. discriminate H. Qed.

Lemma reff90_not1276 : ~ @Equation1276 Fin4 reff90_inst.
Proof. unfold Equation1276. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff90_inst, reff90_op in H. discriminate H. Qed.

Lemma reff90_not1279 : ~ @Equation1279 Fin4 reff90_inst.
Proof. unfold Equation1279. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff90_inst, reff90_op in H. discriminate H. Qed.

Lemma reff90_not1286 : ~ @Equation1286 Fin4 reff90_inst.
Proof. unfold Equation1286. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff90_inst, reff90_op in H. discriminate H. Qed.

Lemma reff90_not1288 : ~ @Equation1288 Fin4 reff90_inst.
Proof. unfold Equation1288. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff90_inst, reff90_op in H. discriminate H. Qed.

Lemma reff90_not1289 : ~ @Equation1289 Fin4 reff90_inst.
Proof. unfold Equation1289. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff90_inst, reff90_op in H. discriminate H. Qed.

Lemma reff90_not1313 : ~ @Equation1313 Fin4 reff90_inst.
Proof. unfold Equation1313. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff90_inst, reff90_op in H. discriminate H. Qed.

Lemma reff90_not1315 : ~ @Equation1315 Fin4 reff90_inst.
Proof. unfold Equation1315. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff90_inst, reff90_op in H. discriminate H. Qed.

Lemma reff90_not1316 : ~ @Equation1316 Fin4 reff90_inst.
Proof. unfold Equation1316. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff90_inst, reff90_op in H. discriminate H. Qed.

Lemma reff90_not1322 : ~ @Equation1322 Fin4 reff90_inst.
Proof. unfold Equation1322. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff90_inst, reff90_op in H. discriminate H. Qed.

Lemma reff90_not1323 : ~ @Equation1323 Fin4 reff90_inst.
Proof. unfold Equation1323. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff90_inst, reff90_op in H. discriminate H. Qed.

Lemma reff90_not1427 : ~ @Equation1427 Fin4 reff90_inst.
Proof. unfold Equation1427. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff90_inst, reff90_op in H. discriminate H. Qed.

Lemma reff90_not1428 : ~ @Equation1428 Fin4 reff90_inst.
Proof. unfold Equation1428. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff90_inst, reff90_op in H. discriminate H. Qed.

Lemma reff90_not1429 : ~ @Equation1429 Fin4 reff90_inst.
Proof. unfold Equation1429. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff90_inst, reff90_op in H. discriminate H. Qed.

Lemma reff90_not1431 : ~ @Equation1431 Fin4 reff90_inst.
Proof. unfold Equation1431. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff90_inst, reff90_op in H. discriminate H. Qed.

Lemma reff90_not1432 : ~ @Equation1432 Fin4 reff90_inst.
Proof. unfold Equation1432. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff90_inst, reff90_op in H. discriminate H. Qed.

Lemma reff90_not1435 : ~ @Equation1435 Fin4 reff90_inst.
Proof. unfold Equation1435. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff90_inst, reff90_op in H. discriminate H. Qed.

Lemma reff90_not1441 : ~ @Equation1441 Fin4 reff90_inst.
Proof. unfold Equation1441. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff90_inst, reff90_op in H. discriminate H. Qed.

Lemma reff90_not1442 : ~ @Equation1442 Fin4 reff90_inst.
Proof. unfold Equation1442. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff90_inst, reff90_op in H. discriminate H. Qed.

Lemma reff90_not1445 : ~ @Equation1445 Fin4 reff90_inst.
Proof. unfold Equation1445. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff90_inst, reff90_op in H. discriminate H. Qed.

Lemma reff90_not1452 : ~ @Equation1452 Fin4 reff90_inst.
Proof. unfold Equation1452. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff90_inst, reff90_op in H. discriminate H. Qed.

Lemma reff90_not1454 : ~ @Equation1454 Fin4 reff90_inst.
Proof. unfold Equation1454. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff90_inst, reff90_op in H. discriminate H. Qed.

Lemma reff90_not1455 : ~ @Equation1455 Fin4 reff90_inst.
Proof. unfold Equation1455. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff90_inst, reff90_op in H. discriminate H. Qed.

Lemma reff90_not1478 : ~ @Equation1478 Fin4 reff90_inst.
Proof. unfold Equation1478. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff90_inst, reff90_op in H. discriminate H. Qed.

Lemma reff90_not1479 : ~ @Equation1479 Fin4 reff90_inst.
Proof. unfold Equation1479. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff90_inst, reff90_op in H. discriminate H. Qed.

Lemma reff90_not1482 : ~ @Equation1482 Fin4 reff90_inst.
Proof. unfold Equation1482. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff90_inst, reff90_op in H. discriminate H. Qed.

Lemma reff90_not1489 : ~ @Equation1489 Fin4 reff90_inst.
Proof. unfold Equation1489. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff90_inst, reff90_op in H. discriminate H. Qed.

Lemma reff90_not1491 : ~ @Equation1491 Fin4 reff90_inst.
Proof. unfold Equation1491. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff90_inst, reff90_op in H. discriminate H. Qed.

Lemma reff90_not1492 : ~ @Equation1492 Fin4 reff90_inst.
Proof. unfold Equation1492. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff90_inst, reff90_op in H. discriminate H. Qed.

Lemma reff90_not1516 : ~ @Equation1516 Fin4 reff90_inst.
Proof. unfold Equation1516. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff90_inst, reff90_op in H. discriminate H. Qed.

Lemma reff90_not1518 : ~ @Equation1518 Fin4 reff90_inst.
Proof. unfold Equation1518. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff90_inst, reff90_op in H. discriminate H. Qed.

Lemma reff90_not1519 : ~ @Equation1519 Fin4 reff90_inst.
Proof. unfold Equation1519. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff90_inst, reff90_op in H. discriminate H. Qed.

Lemma reff90_not1525 : ~ @Equation1525 Fin4 reff90_inst.
Proof. unfold Equation1525. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff90_inst, reff90_op in H. discriminate H. Qed.

Lemma reff90_not1526 : ~ @Equation1526 Fin4 reff90_inst.
Proof. unfold Equation1526. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff90_inst, reff90_op in H. discriminate H. Qed.

Lemma reff90_not1630 : ~ @Equation1630 Fin4 reff90_inst.
Proof. unfold Equation1630. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff90_inst, reff90_op in H. discriminate H. Qed.

Lemma reff90_not1631 : ~ @Equation1631 Fin4 reff90_inst.
Proof. unfold Equation1631. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff90_inst, reff90_op in H. discriminate H. Qed.

Lemma reff90_not1632 : ~ @Equation1632 Fin4 reff90_inst.
Proof. unfold Equation1632. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff90_inst, reff90_op in H. discriminate H. Qed.

Lemma reff90_not1634 : ~ @Equation1634 Fin4 reff90_inst.
Proof. unfold Equation1634. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff90_inst, reff90_op in H. discriminate H. Qed.

Lemma reff90_not1635 : ~ @Equation1635 Fin4 reff90_inst.
Proof. unfold Equation1635. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff90_inst, reff90_op in H. discriminate H. Qed.

Lemma reff90_not1638 : ~ @Equation1638 Fin4 reff90_inst.
Proof. unfold Equation1638. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff90_inst, reff90_op in H. discriminate H. Qed.

Lemma reff90_not1644 : ~ @Equation1644 Fin4 reff90_inst.
Proof. unfold Equation1644. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff90_inst, reff90_op in H. discriminate H. Qed.

Lemma reff90_not1645 : ~ @Equation1645 Fin4 reff90_inst.
Proof. unfold Equation1645. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff90_inst, reff90_op in H. discriminate H. Qed.

Lemma reff90_not1648 : ~ @Equation1648 Fin4 reff90_inst.
Proof. unfold Equation1648. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff90_inst, reff90_op in H. discriminate H. Qed.

Lemma reff90_not1655 : ~ @Equation1655 Fin4 reff90_inst.
Proof. unfold Equation1655. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff90_inst, reff90_op in H. discriminate H. Qed.

Lemma reff90_not1657 : ~ @Equation1657 Fin4 reff90_inst.
Proof. unfold Equation1657. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff90_inst, reff90_op in H. discriminate H. Qed.

Lemma reff90_not1658 : ~ @Equation1658 Fin4 reff90_inst.
Proof. unfold Equation1658. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff90_inst, reff90_op in H. discriminate H. Qed.

Lemma reff90_not1681 : ~ @Equation1681 Fin4 reff90_inst.
Proof. unfold Equation1681. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff90_inst, reff90_op in H. discriminate H. Qed.

Lemma reff90_not1682 : ~ @Equation1682 Fin4 reff90_inst.
Proof. unfold Equation1682. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff90_inst, reff90_op in H. discriminate H. Qed.

Lemma reff90_not1685 : ~ @Equation1685 Fin4 reff90_inst.
Proof. unfold Equation1685. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff90_inst, reff90_op in H. discriminate H. Qed.

Lemma reff90_not1692 : ~ @Equation1692 Fin4 reff90_inst.
Proof. unfold Equation1692. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff90_inst, reff90_op in H. discriminate H. Qed.

Lemma reff90_not1694 : ~ @Equation1694 Fin4 reff90_inst.
Proof. unfold Equation1694. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff90_inst, reff90_op in H. discriminate H. Qed.

Lemma reff90_not1695 : ~ @Equation1695 Fin4 reff90_inst.
Proof. unfold Equation1695. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff90_inst, reff90_op in H. discriminate H. Qed.

Lemma reff90_not1719 : ~ @Equation1719 Fin4 reff90_inst.
Proof. unfold Equation1719. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff90_inst, reff90_op in H. discriminate H. Qed.

Lemma reff90_not1721 : ~ @Equation1721 Fin4 reff90_inst.
Proof. unfold Equation1721. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff90_inst, reff90_op in H. discriminate H. Qed.

Lemma reff90_not1722 : ~ @Equation1722 Fin4 reff90_inst.
Proof. unfold Equation1722. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff90_inst, reff90_op in H. discriminate H. Qed.

Lemma reff90_not1728 : ~ @Equation1728 Fin4 reff90_inst.
Proof. unfold Equation1728. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff90_inst, reff90_op in H. discriminate H. Qed.

Lemma reff90_not1729 : ~ @Equation1729 Fin4 reff90_inst.
Proof. unfold Equation1729. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff90_inst, reff90_op in H. discriminate H. Qed.

Lemma reff90_not1833 : ~ @Equation1833 Fin4 reff90_inst.
Proof. unfold Equation1833. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff90_inst, reff90_op in H. discriminate H. Qed.

Lemma reff90_not1834 : ~ @Equation1834 Fin4 reff90_inst.
Proof. unfold Equation1834. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff90_inst, reff90_op in H. discriminate H. Qed.

Lemma reff90_not1835 : ~ @Equation1835 Fin4 reff90_inst.
Proof. unfold Equation1835. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff90_inst, reff90_op in H. discriminate H. Qed.

Lemma reff90_not1837 : ~ @Equation1837 Fin4 reff90_inst.
Proof. unfold Equation1837. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff90_inst, reff90_op in H. discriminate H. Qed.

Lemma reff90_not1838 : ~ @Equation1838 Fin4 reff90_inst.
Proof. unfold Equation1838. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff90_inst, reff90_op in H. discriminate H. Qed.

Lemma reff90_not1841 : ~ @Equation1841 Fin4 reff90_inst.
Proof. unfold Equation1841. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff90_inst, reff90_op in H. discriminate H. Qed.

Lemma reff90_not1847 : ~ @Equation1847 Fin4 reff90_inst.
Proof. unfold Equation1847. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff90_inst, reff90_op in H. discriminate H. Qed.

Lemma reff90_not1848 : ~ @Equation1848 Fin4 reff90_inst.
Proof. unfold Equation1848. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff90_inst, reff90_op in H. discriminate H. Qed.

Lemma reff90_not1851 : ~ @Equation1851 Fin4 reff90_inst.
Proof. unfold Equation1851. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff90_inst, reff90_op in H. discriminate H. Qed.

Lemma reff90_not1858 : ~ @Equation1858 Fin4 reff90_inst.
Proof. unfold Equation1858. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff90_inst, reff90_op in H. discriminate H. Qed.

Lemma reff90_not1860 : ~ @Equation1860 Fin4 reff90_inst.
Proof. unfold Equation1860. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff90_inst, reff90_op in H. discriminate H. Qed.

Lemma reff90_not1861 : ~ @Equation1861 Fin4 reff90_inst.
Proof. unfold Equation1861. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff90_inst, reff90_op in H. discriminate H. Qed.

Lemma reff90_not1884 : ~ @Equation1884 Fin4 reff90_inst.
Proof. unfold Equation1884. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff90_inst, reff90_op in H. discriminate H. Qed.

Lemma reff90_not1885 : ~ @Equation1885 Fin4 reff90_inst.
Proof. unfold Equation1885. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff90_inst, reff90_op in H. discriminate H. Qed.

Lemma reff90_not1888 : ~ @Equation1888 Fin4 reff90_inst.
Proof. unfold Equation1888. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff90_inst, reff90_op in H. discriminate H. Qed.

Lemma reff90_not1895 : ~ @Equation1895 Fin4 reff90_inst.
Proof. unfold Equation1895. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff90_inst, reff90_op in H. discriminate H. Qed.

Lemma reff90_not1897 : ~ @Equation1897 Fin4 reff90_inst.
Proof. unfold Equation1897. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff90_inst, reff90_op in H. discriminate H. Qed.

Lemma reff90_not1898 : ~ @Equation1898 Fin4 reff90_inst.
Proof. unfold Equation1898. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff90_inst, reff90_op in H. discriminate H. Qed.

Lemma reff90_not1922 : ~ @Equation1922 Fin4 reff90_inst.
Proof. unfold Equation1922. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff90_inst, reff90_op in H. discriminate H. Qed.

Lemma reff90_not1924 : ~ @Equation1924 Fin4 reff90_inst.
Proof. unfold Equation1924. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff90_inst, reff90_op in H. discriminate H. Qed.

Lemma reff90_not1925 : ~ @Equation1925 Fin4 reff90_inst.
Proof. unfold Equation1925. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff90_inst, reff90_op in H. discriminate H. Qed.

Lemma reff90_not1931 : ~ @Equation1931 Fin4 reff90_inst.
Proof. unfold Equation1931. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff90_inst, reff90_op in H. discriminate H. Qed.

Lemma reff90_not1932 : ~ @Equation1932 Fin4 reff90_inst.
Proof. unfold Equation1932. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff90_inst, reff90_op in H. discriminate H. Qed.

Lemma reff90_not2036 : ~ @Equation2036 Fin4 reff90_inst.
Proof. unfold Equation2036. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff90_inst, reff90_op in H. discriminate H. Qed.

Lemma reff90_not2037 : ~ @Equation2037 Fin4 reff90_inst.
Proof. unfold Equation2037. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff90_inst, reff90_op in H. discriminate H. Qed.

Lemma reff90_not2038 : ~ @Equation2038 Fin4 reff90_inst.
Proof. unfold Equation2038. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff90_inst, reff90_op in H. discriminate H. Qed.

Lemma reff90_not2040 : ~ @Equation2040 Fin4 reff90_inst.
Proof. unfold Equation2040. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff90_inst, reff90_op in H. discriminate H. Qed.

Lemma reff90_not2041 : ~ @Equation2041 Fin4 reff90_inst.
Proof. unfold Equation2041. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff90_inst, reff90_op in H. discriminate H. Qed.

Lemma reff90_not2044 : ~ @Equation2044 Fin4 reff90_inst.
Proof. unfold Equation2044. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff90_inst, reff90_op in H. discriminate H. Qed.

Lemma reff90_not2050 : ~ @Equation2050 Fin4 reff90_inst.
Proof. unfold Equation2050. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff90_inst, reff90_op in H. discriminate H. Qed.

Lemma reff90_not2051 : ~ @Equation2051 Fin4 reff90_inst.
Proof. unfold Equation2051. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff90_inst, reff90_op in H. discriminate H. Qed.

Lemma reff90_not2054 : ~ @Equation2054 Fin4 reff90_inst.
Proof. unfold Equation2054. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff90_inst, reff90_op in H. discriminate H. Qed.

Lemma reff90_not2061 : ~ @Equation2061 Fin4 reff90_inst.
Proof. unfold Equation2061. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff90_inst, reff90_op in H. discriminate H. Qed.

Lemma reff90_not2063 : ~ @Equation2063 Fin4 reff90_inst.
Proof. unfold Equation2063. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff90_inst, reff90_op in H. discriminate H. Qed.

Lemma reff90_not2064 : ~ @Equation2064 Fin4 reff90_inst.
Proof. unfold Equation2064. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff90_inst, reff90_op in H. discriminate H. Qed.

Lemma reff90_not2087 : ~ @Equation2087 Fin4 reff90_inst.
Proof. unfold Equation2087. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff90_inst, reff90_op in H. discriminate H. Qed.

Lemma reff90_not2088 : ~ @Equation2088 Fin4 reff90_inst.
Proof. unfold Equation2088. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff90_inst, reff90_op in H. discriminate H. Qed.

Lemma reff90_not2091 : ~ @Equation2091 Fin4 reff90_inst.
Proof. unfold Equation2091. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff90_inst, reff90_op in H. discriminate H. Qed.

Lemma reff90_not2098 : ~ @Equation2098 Fin4 reff90_inst.
Proof. unfold Equation2098. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff90_inst, reff90_op in H. discriminate H. Qed.

Lemma reff90_not2100 : ~ @Equation2100 Fin4 reff90_inst.
Proof. unfold Equation2100. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff90_inst, reff90_op in H. discriminate H. Qed.

Lemma reff90_not2101 : ~ @Equation2101 Fin4 reff90_inst.
Proof. unfold Equation2101. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff90_inst, reff90_op in H. discriminate H. Qed.

Lemma reff90_not2125 : ~ @Equation2125 Fin4 reff90_inst.
Proof. unfold Equation2125. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff90_inst, reff90_op in H. discriminate H. Qed.

Lemma reff90_not2127 : ~ @Equation2127 Fin4 reff90_inst.
Proof. unfold Equation2127. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff90_inst, reff90_op in H. discriminate H. Qed.

Lemma reff90_not2128 : ~ @Equation2128 Fin4 reff90_inst.
Proof. unfold Equation2128. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff90_inst, reff90_op in H. discriminate H. Qed.

Lemma reff90_not2134 : ~ @Equation2134 Fin4 reff90_inst.
Proof. unfold Equation2134. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff90_inst, reff90_op in H. discriminate H. Qed.

Lemma reff90_not2135 : ~ @Equation2135 Fin4 reff90_inst.
Proof. unfold Equation2135. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff90_inst, reff90_op in H. discriminate H. Qed.

Lemma reff90_not2239 : ~ @Equation2239 Fin4 reff90_inst.
Proof. unfold Equation2239. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff90_inst, reff90_op in H. discriminate H. Qed.

Lemma reff90_not2240 : ~ @Equation2240 Fin4 reff90_inst.
Proof. unfold Equation2240. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff90_inst, reff90_op in H. discriminate H. Qed.

Lemma reff90_not2241 : ~ @Equation2241 Fin4 reff90_inst.
Proof. unfold Equation2241. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff90_inst, reff90_op in H. discriminate H. Qed.

Lemma reff90_not2243 : ~ @Equation2243 Fin4 reff90_inst.
Proof. unfold Equation2243. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff90_inst, reff90_op in H. discriminate H. Qed.

Lemma reff90_not2244 : ~ @Equation2244 Fin4 reff90_inst.
Proof. unfold Equation2244. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff90_inst, reff90_op in H. discriminate H. Qed.

Lemma reff90_not2247 : ~ @Equation2247 Fin4 reff90_inst.
Proof. unfold Equation2247. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff90_inst, reff90_op in H. discriminate H. Qed.

Lemma reff90_not2253 : ~ @Equation2253 Fin4 reff90_inst.
Proof. unfold Equation2253. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff90_inst, reff90_op in H. discriminate H. Qed.

Lemma reff90_not2254 : ~ @Equation2254 Fin4 reff90_inst.
Proof. unfold Equation2254. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff90_inst, reff90_op in H. discriminate H. Qed.

Lemma reff90_not2257 : ~ @Equation2257 Fin4 reff90_inst.
Proof. unfold Equation2257. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff90_inst, reff90_op in H. discriminate H. Qed.

Lemma reff90_not2264 : ~ @Equation2264 Fin4 reff90_inst.
Proof. unfold Equation2264. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff90_inst, reff90_op in H. discriminate H. Qed.

Lemma reff90_not2266 : ~ @Equation2266 Fin4 reff90_inst.
Proof. unfold Equation2266. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff90_inst, reff90_op in H. discriminate H. Qed.

Lemma reff90_not2267 : ~ @Equation2267 Fin4 reff90_inst.
Proof. unfold Equation2267. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff90_inst, reff90_op in H. discriminate H. Qed.

Lemma reff90_not2290 : ~ @Equation2290 Fin4 reff90_inst.
Proof. unfold Equation2290. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff90_inst, reff90_op in H. discriminate H. Qed.

Lemma reff90_not2291 : ~ @Equation2291 Fin4 reff90_inst.
Proof. unfold Equation2291. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff90_inst, reff90_op in H. discriminate H. Qed.

Lemma reff90_not2294 : ~ @Equation2294 Fin4 reff90_inst.
Proof. unfold Equation2294. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff90_inst, reff90_op in H. discriminate H. Qed.

Lemma reff90_not2301 : ~ @Equation2301 Fin4 reff90_inst.
Proof. unfold Equation2301. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff90_inst, reff90_op in H. discriminate H. Qed.

Lemma reff90_not2303 : ~ @Equation2303 Fin4 reff90_inst.
Proof. unfold Equation2303. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff90_inst, reff90_op in H. discriminate H. Qed.

Lemma reff90_not2304 : ~ @Equation2304 Fin4 reff90_inst.
Proof. unfold Equation2304. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff90_inst, reff90_op in H. discriminate H. Qed.

Lemma reff90_not2328 : ~ @Equation2328 Fin4 reff90_inst.
Proof. unfold Equation2328. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff90_inst, reff90_op in H. discriminate H. Qed.

Lemma reff90_not2330 : ~ @Equation2330 Fin4 reff90_inst.
Proof. unfold Equation2330. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff90_inst, reff90_op in H. discriminate H. Qed.

Lemma reff90_not2331 : ~ @Equation2331 Fin4 reff90_inst.
Proof. unfold Equation2331. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff90_inst, reff90_op in H. discriminate H. Qed.

Lemma reff90_not2337 : ~ @Equation2337 Fin4 reff90_inst.
Proof. unfold Equation2337. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff90_inst, reff90_op in H. discriminate H. Qed.

Lemma reff90_not2338 : ~ @Equation2338 Fin4 reff90_inst.
Proof. unfold Equation2338. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff90_inst, reff90_op in H. discriminate H. Qed.

Lemma reff90_not2442 : ~ @Equation2442 Fin4 reff90_inst.
Proof. unfold Equation2442. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff90_inst, reff90_op in H. discriminate H. Qed.

Lemma reff90_not2443 : ~ @Equation2443 Fin4 reff90_inst.
Proof. unfold Equation2443. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff90_inst, reff90_op in H. discriminate H. Qed.

Lemma reff90_not2444 : ~ @Equation2444 Fin4 reff90_inst.
Proof. unfold Equation2444. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff90_inst, reff90_op in H. discriminate H. Qed.

Lemma reff90_not2446 : ~ @Equation2446 Fin4 reff90_inst.
Proof. unfold Equation2446. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff90_inst, reff90_op in H. discriminate H. Qed.

Lemma reff90_not2447 : ~ @Equation2447 Fin4 reff90_inst.
Proof. unfold Equation2447. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff90_inst, reff90_op in H. discriminate H. Qed.

Lemma reff90_not2450 : ~ @Equation2450 Fin4 reff90_inst.
Proof. unfold Equation2450. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff90_inst, reff90_op in H. discriminate H. Qed.

Lemma reff90_not2456 : ~ @Equation2456 Fin4 reff90_inst.
Proof. unfold Equation2456. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff90_inst, reff90_op in H. discriminate H. Qed.

Lemma reff90_not2457 : ~ @Equation2457 Fin4 reff90_inst.
Proof. unfold Equation2457. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff90_inst, reff90_op in H. discriminate H. Qed.

Lemma reff90_not2460 : ~ @Equation2460 Fin4 reff90_inst.
Proof. unfold Equation2460. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff90_inst, reff90_op in H. discriminate H. Qed.

Lemma reff90_not2467 : ~ @Equation2467 Fin4 reff90_inst.
Proof. unfold Equation2467. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff90_inst, reff90_op in H. discriminate H. Qed.

Lemma reff90_not2469 : ~ @Equation2469 Fin4 reff90_inst.
Proof. unfold Equation2469. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff90_inst, reff90_op in H. discriminate H. Qed.

Lemma reff90_not2470 : ~ @Equation2470 Fin4 reff90_inst.
Proof. unfold Equation2470. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff90_inst, reff90_op in H. discriminate H. Qed.

Lemma reff90_not2493 : ~ @Equation2493 Fin4 reff90_inst.
Proof. unfold Equation2493. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff90_inst, reff90_op in H. discriminate H. Qed.

Lemma reff90_not2494 : ~ @Equation2494 Fin4 reff90_inst.
Proof. unfold Equation2494. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff90_inst, reff90_op in H. discriminate H. Qed.

Lemma reff90_not2497 : ~ @Equation2497 Fin4 reff90_inst.
Proof. unfold Equation2497. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff90_inst, reff90_op in H. discriminate H. Qed.

Lemma reff90_not2504 : ~ @Equation2504 Fin4 reff90_inst.
Proof. unfold Equation2504. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff90_inst, reff90_op in H. discriminate H. Qed.

Lemma reff90_not2506 : ~ @Equation2506 Fin4 reff90_inst.
Proof. unfold Equation2506. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff90_inst, reff90_op in H. discriminate H. Qed.

Lemma reff90_not2507 : ~ @Equation2507 Fin4 reff90_inst.
Proof. unfold Equation2507. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff90_inst, reff90_op in H. discriminate H. Qed.

Lemma reff90_not2531 : ~ @Equation2531 Fin4 reff90_inst.
Proof. unfold Equation2531. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff90_inst, reff90_op in H. discriminate H. Qed.

Lemma reff90_not2533 : ~ @Equation2533 Fin4 reff90_inst.
Proof. unfold Equation2533. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff90_inst, reff90_op in H. discriminate H. Qed.

Lemma reff90_not2534 : ~ @Equation2534 Fin4 reff90_inst.
Proof. unfold Equation2534. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff90_inst, reff90_op in H. discriminate H. Qed.

Lemma reff90_not2540 : ~ @Equation2540 Fin4 reff90_inst.
Proof. unfold Equation2540. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff90_inst, reff90_op in H. discriminate H. Qed.

Lemma reff90_not2541 : ~ @Equation2541 Fin4 reff90_inst.
Proof. unfold Equation2541. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff90_inst, reff90_op in H. discriminate H. Qed.

Lemma reff90_not2645 : ~ @Equation2645 Fin4 reff90_inst.
Proof. unfold Equation2645. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff90_inst, reff90_op in H. discriminate H. Qed.

Lemma reff90_not2646 : ~ @Equation2646 Fin4 reff90_inst.
Proof. unfold Equation2646. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff90_inst, reff90_op in H. discriminate H. Qed.

Lemma reff90_not2647 : ~ @Equation2647 Fin4 reff90_inst.
Proof. unfold Equation2647. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff90_inst, reff90_op in H. discriminate H. Qed.

Lemma reff90_not2649 : ~ @Equation2649 Fin4 reff90_inst.
Proof. unfold Equation2649. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff90_inst, reff90_op in H. discriminate H. Qed.

Lemma reff90_not2650 : ~ @Equation2650 Fin4 reff90_inst.
Proof. unfold Equation2650. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff90_inst, reff90_op in H. discriminate H. Qed.

Lemma reff90_not2653 : ~ @Equation2653 Fin4 reff90_inst.
Proof. unfold Equation2653. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff90_inst, reff90_op in H. discriminate H. Qed.

Lemma reff90_not2659 : ~ @Equation2659 Fin4 reff90_inst.
Proof. unfold Equation2659. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff90_inst, reff90_op in H. discriminate H. Qed.

Lemma reff90_not2660 : ~ @Equation2660 Fin4 reff90_inst.
Proof. unfold Equation2660. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff90_inst, reff90_op in H. discriminate H. Qed.

Lemma reff90_not2663 : ~ @Equation2663 Fin4 reff90_inst.
Proof. unfold Equation2663. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff90_inst, reff90_op in H. discriminate H. Qed.

Lemma reff90_not2670 : ~ @Equation2670 Fin4 reff90_inst.
Proof. unfold Equation2670. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff90_inst, reff90_op in H. discriminate H. Qed.

Lemma reff90_not2672 : ~ @Equation2672 Fin4 reff90_inst.
Proof. unfold Equation2672. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff90_inst, reff90_op in H. discriminate H. Qed.

Lemma reff90_not2673 : ~ @Equation2673 Fin4 reff90_inst.
Proof. unfold Equation2673. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff90_inst, reff90_op in H. discriminate H. Qed.

Lemma reff90_not2696 : ~ @Equation2696 Fin4 reff90_inst.
Proof. unfold Equation2696. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff90_inst, reff90_op in H. discriminate H. Qed.

Lemma reff90_not2697 : ~ @Equation2697 Fin4 reff90_inst.
Proof. unfold Equation2697. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff90_inst, reff90_op in H. discriminate H. Qed.

Lemma reff90_not2700 : ~ @Equation2700 Fin4 reff90_inst.
Proof. unfold Equation2700. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff90_inst, reff90_op in H. discriminate H. Qed.

Lemma reff90_not2707 : ~ @Equation2707 Fin4 reff90_inst.
Proof. unfold Equation2707. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff90_inst, reff90_op in H. discriminate H. Qed.

Lemma reff90_not2709 : ~ @Equation2709 Fin4 reff90_inst.
Proof. unfold Equation2709. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff90_inst, reff90_op in H. discriminate H. Qed.

Lemma reff90_not2710 : ~ @Equation2710 Fin4 reff90_inst.
Proof. unfold Equation2710. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff90_inst, reff90_op in H. discriminate H. Qed.

Lemma reff90_not2734 : ~ @Equation2734 Fin4 reff90_inst.
Proof. unfold Equation2734. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff90_inst, reff90_op in H. discriminate H. Qed.

Lemma reff90_not2736 : ~ @Equation2736 Fin4 reff90_inst.
Proof. unfold Equation2736. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff90_inst, reff90_op in H. discriminate H. Qed.

Lemma reff90_not2737 : ~ @Equation2737 Fin4 reff90_inst.
Proof. unfold Equation2737. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff90_inst, reff90_op in H. discriminate H. Qed.

Lemma reff90_not2743 : ~ @Equation2743 Fin4 reff90_inst.
Proof. unfold Equation2743. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff90_inst, reff90_op in H. discriminate H. Qed.

Lemma reff90_not2744 : ~ @Equation2744 Fin4 reff90_inst.
Proof. unfold Equation2744. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff90_inst, reff90_op in H. discriminate H. Qed.

Lemma reff90_not2848 : ~ @Equation2848 Fin4 reff90_inst.
Proof. unfold Equation2848. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff90_inst, reff90_op in H. discriminate H. Qed.

Lemma reff90_not2849 : ~ @Equation2849 Fin4 reff90_inst.
Proof. unfold Equation2849. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff90_inst, reff90_op in H. discriminate H. Qed.

Lemma reff90_not2850 : ~ @Equation2850 Fin4 reff90_inst.
Proof. unfold Equation2850. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff90_inst, reff90_op in H. discriminate H. Qed.

Lemma reff90_not2852 : ~ @Equation2852 Fin4 reff90_inst.
Proof. unfold Equation2852. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff90_inst, reff90_op in H. discriminate H. Qed.

Lemma reff90_not2853 : ~ @Equation2853 Fin4 reff90_inst.
Proof. unfold Equation2853. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff90_inst, reff90_op in H. discriminate H. Qed.

Lemma reff90_not2856 : ~ @Equation2856 Fin4 reff90_inst.
Proof. unfold Equation2856. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff90_inst, reff90_op in H. discriminate H. Qed.

Lemma reff90_not2862 : ~ @Equation2862 Fin4 reff90_inst.
Proof. unfold Equation2862. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff90_inst, reff90_op in H. discriminate H. Qed.

Lemma reff90_not2863 : ~ @Equation2863 Fin4 reff90_inst.
Proof. unfold Equation2863. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff90_inst, reff90_op in H. discriminate H. Qed.

Lemma reff90_not2866 : ~ @Equation2866 Fin4 reff90_inst.
Proof. unfold Equation2866. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff90_inst, reff90_op in H. discriminate H. Qed.

Lemma reff90_not2873 : ~ @Equation2873 Fin4 reff90_inst.
Proof. unfold Equation2873. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff90_inst, reff90_op in H. discriminate H. Qed.

Lemma reff90_not2875 : ~ @Equation2875 Fin4 reff90_inst.
Proof. unfold Equation2875. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff90_inst, reff90_op in H. discriminate H. Qed.

Lemma reff90_not2876 : ~ @Equation2876 Fin4 reff90_inst.
Proof. unfold Equation2876. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff90_inst, reff90_op in H. discriminate H. Qed.

Lemma reff90_not2899 : ~ @Equation2899 Fin4 reff90_inst.
Proof. unfold Equation2899. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff90_inst, reff90_op in H. discriminate H. Qed.

Lemma reff90_not2900 : ~ @Equation2900 Fin4 reff90_inst.
Proof. unfold Equation2900. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff90_inst, reff90_op in H. discriminate H. Qed.

Lemma reff90_not2903 : ~ @Equation2903 Fin4 reff90_inst.
Proof. unfold Equation2903. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff90_inst, reff90_op in H. discriminate H. Qed.

Lemma reff90_not2910 : ~ @Equation2910 Fin4 reff90_inst.
Proof. unfold Equation2910. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff90_inst, reff90_op in H. discriminate H. Qed.

Lemma reff90_not2912 : ~ @Equation2912 Fin4 reff90_inst.
Proof. unfold Equation2912. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff90_inst, reff90_op in H. discriminate H. Qed.

Lemma reff90_not2913 : ~ @Equation2913 Fin4 reff90_inst.
Proof. unfold Equation2913. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff90_inst, reff90_op in H. discriminate H. Qed.

Lemma reff90_not2937 : ~ @Equation2937 Fin4 reff90_inst.
Proof. unfold Equation2937. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff90_inst, reff90_op in H. discriminate H. Qed.

Lemma reff90_not2939 : ~ @Equation2939 Fin4 reff90_inst.
Proof. unfold Equation2939. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff90_inst, reff90_op in H. discriminate H. Qed.

Lemma reff90_not2940 : ~ @Equation2940 Fin4 reff90_inst.
Proof. unfold Equation2940. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff90_inst, reff90_op in H. discriminate H. Qed.

Lemma reff90_not2946 : ~ @Equation2946 Fin4 reff90_inst.
Proof. unfold Equation2946. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff90_inst, reff90_op in H. discriminate H. Qed.

Lemma reff90_not2947 : ~ @Equation2947 Fin4 reff90_inst.
Proof. unfold Equation2947. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff90_inst, reff90_op in H. discriminate H. Qed.

Lemma reff90_not3051 : ~ @Equation3051 Fin4 reff90_inst.
Proof. unfold Equation3051. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff90_inst, reff90_op in H. discriminate H. Qed.

Lemma reff90_not3052 : ~ @Equation3052 Fin4 reff90_inst.
Proof. unfold Equation3052. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff90_inst, reff90_op in H. discriminate H. Qed.

Lemma reff90_not3053 : ~ @Equation3053 Fin4 reff90_inst.
Proof. unfold Equation3053. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff90_inst, reff90_op in H. discriminate H. Qed.

Lemma reff90_not3055 : ~ @Equation3055 Fin4 reff90_inst.
Proof. unfold Equation3055. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff90_inst, reff90_op in H. discriminate H. Qed.

Lemma reff90_not3056 : ~ @Equation3056 Fin4 reff90_inst.
Proof. unfold Equation3056. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff90_inst, reff90_op in H. discriminate H. Qed.

Lemma reff90_not3059 : ~ @Equation3059 Fin4 reff90_inst.
Proof. unfold Equation3059. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff90_inst, reff90_op in H. discriminate H. Qed.

Lemma reff90_not3065 : ~ @Equation3065 Fin4 reff90_inst.
Proof. unfold Equation3065. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff90_inst, reff90_op in H. discriminate H. Qed.

Lemma reff90_not3066 : ~ @Equation3066 Fin4 reff90_inst.
Proof. unfold Equation3066. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff90_inst, reff90_op in H. discriminate H. Qed.

Lemma reff90_not3069 : ~ @Equation3069 Fin4 reff90_inst.
Proof. unfold Equation3069. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff90_inst, reff90_op in H. discriminate H. Qed.

Lemma reff90_not3076 : ~ @Equation3076 Fin4 reff90_inst.
Proof. unfold Equation3076. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff90_inst, reff90_op in H. discriminate H. Qed.

Lemma reff90_not3078 : ~ @Equation3078 Fin4 reff90_inst.
Proof. unfold Equation3078. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff90_inst, reff90_op in H. discriminate H. Qed.

Lemma reff90_not3079 : ~ @Equation3079 Fin4 reff90_inst.
Proof. unfold Equation3079. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff90_inst, reff90_op in H. discriminate H. Qed.

Lemma reff90_not3102 : ~ @Equation3102 Fin4 reff90_inst.
Proof. unfold Equation3102. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff90_inst, reff90_op in H. discriminate H. Qed.

Lemma reff90_not3103 : ~ @Equation3103 Fin4 reff90_inst.
Proof. unfold Equation3103. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff90_inst, reff90_op in H. discriminate H. Qed.

Lemma reff90_not3106 : ~ @Equation3106 Fin4 reff90_inst.
Proof. unfold Equation3106. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff90_inst, reff90_op in H. discriminate H. Qed.

Lemma reff90_not3113 : ~ @Equation3113 Fin4 reff90_inst.
Proof. unfold Equation3113. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff90_inst, reff90_op in H. discriminate H. Qed.

Lemma reff90_not3115 : ~ @Equation3115 Fin4 reff90_inst.
Proof. unfold Equation3115. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff90_inst, reff90_op in H. discriminate H. Qed.

Lemma reff90_not3116 : ~ @Equation3116 Fin4 reff90_inst.
Proof. unfold Equation3116. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff90_inst, reff90_op in H. discriminate H. Qed.

Lemma reff90_not3140 : ~ @Equation3140 Fin4 reff90_inst.
Proof. unfold Equation3140. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff90_inst, reff90_op in H. discriminate H. Qed.

Lemma reff90_not3142 : ~ @Equation3142 Fin4 reff90_inst.
Proof. unfold Equation3142. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff90_inst, reff90_op in H. discriminate H. Qed.

Lemma reff90_not3143 : ~ @Equation3143 Fin4 reff90_inst.
Proof. unfold Equation3143. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff90_inst, reff90_op in H. discriminate H. Qed.

Lemma reff90_not3149 : ~ @Equation3149 Fin4 reff90_inst.
Proof. unfold Equation3149. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff90_inst, reff90_op in H. discriminate H. Qed.

Lemma reff90_not3150 : ~ @Equation3150 Fin4 reff90_inst.
Proof. unfold Equation3150. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff90_inst, reff90_op in H. discriminate H. Qed.

Lemma reff90_not3254 : ~ @Equation3254 Fin4 reff90_inst.
Proof. unfold Equation3254. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff90_inst, reff90_op in H. discriminate H. Qed.

Lemma reff90_not3255 : ~ @Equation3255 Fin4 reff90_inst.
Proof. unfold Equation3255. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff90_inst, reff90_op in H. discriminate H. Qed.

Lemma reff90_not3256 : ~ @Equation3256 Fin4 reff90_inst.
Proof. unfold Equation3256. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff90_inst, reff90_op in H. discriminate H. Qed.

Lemma reff90_not3258 : ~ @Equation3258 Fin4 reff90_inst.
Proof. unfold Equation3258. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff90_inst, reff90_op in H. discriminate H. Qed.

Lemma reff90_not3259 : ~ @Equation3259 Fin4 reff90_inst.
Proof. unfold Equation3259. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff90_inst, reff90_op in H. discriminate H. Qed.

Lemma reff90_not3262 : ~ @Equation3262 Fin4 reff90_inst.
Proof. unfold Equation3262. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff90_inst, reff90_op in H. discriminate H. Qed.

Lemma reff90_not3268 : ~ @Equation3268 Fin4 reff90_inst.
Proof. unfold Equation3268. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff90_inst, reff90_op in H. discriminate H. Qed.

Lemma reff90_not3269 : ~ @Equation3269 Fin4 reff90_inst.
Proof. unfold Equation3269. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff90_inst, reff90_op in H. discriminate H. Qed.

Lemma reff90_not3272 : ~ @Equation3272 Fin4 reff90_inst.
Proof. unfold Equation3272. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff90_inst, reff90_op in H. discriminate H. Qed.

Lemma reff90_not3279 : ~ @Equation3279 Fin4 reff90_inst.
Proof. unfold Equation3279. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff90_inst, reff90_op in H. discriminate H. Qed.

Lemma reff90_not3281 : ~ @Equation3281 Fin4 reff90_inst.
Proof. unfold Equation3281. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff90_inst, reff90_op in H. discriminate H. Qed.

Lemma reff90_not3308 : ~ @Equation3308 Fin4 reff90_inst.
Proof. unfold Equation3308. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff90_inst, reff90_op in H. discriminate H. Qed.

Lemma reff90_not3309 : ~ @Equation3309 Fin4 reff90_inst.
Proof. unfold Equation3309. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff90_inst, reff90_op in H. discriminate H. Qed.

Lemma reff90_not3315 : ~ @Equation3315 Fin4 reff90_inst.
Proof. unfold Equation3315. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff90_inst, reff90_op in H. discriminate H. Qed.

Lemma reff90_not3316 : ~ @Equation3316 Fin4 reff90_inst.
Proof. unfold Equation3316. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff90_inst, reff90_op in H. discriminate H. Qed.

Lemma reff90_not3318 : ~ @Equation3318 Fin4 reff90_inst.
Proof. unfold Equation3318. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff90_inst, reff90_op in H. discriminate H. Qed.

Lemma reff90_not3342 : ~ @Equation3342 Fin4 reff90_inst.
Proof. unfold Equation3342. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff90_inst, reff90_op in H. discriminate H. Qed.

Lemma reff90_not3343 : ~ @Equation3343 Fin4 reff90_inst.
Proof. unfold Equation3343. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff90_inst, reff90_op in H. discriminate H. Qed.

Lemma reff90_not3345 : ~ @Equation3345 Fin4 reff90_inst.
Proof. unfold Equation3345. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff90_inst, reff90_op in H. discriminate H. Qed.

Lemma reff90_not3352 : ~ @Equation3352 Fin4 reff90_inst.
Proof. unfold Equation3352. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff90_inst, reff90_op in H. discriminate H. Qed.

Lemma reff90_not3355 : ~ @Equation3355 Fin4 reff90_inst.
Proof. unfold Equation3355. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff90_inst, reff90_op in H. discriminate H. Qed.

Lemma reff90_not3457 : ~ @Equation3457 Fin4 reff90_inst.
Proof. unfold Equation3457. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff90_inst, reff90_op in H. discriminate H. Qed.

Lemma reff90_not3458 : ~ @Equation3458 Fin4 reff90_inst.
Proof. unfold Equation3458. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff90_inst, reff90_op in H. discriminate H. Qed.

Lemma reff90_not3459 : ~ @Equation3459 Fin4 reff90_inst.
Proof. unfold Equation3459. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff90_inst, reff90_op in H. discriminate H. Qed.

Lemma reff90_not3461 : ~ @Equation3461 Fin4 reff90_inst.
Proof. unfold Equation3461. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff90_inst, reff90_op in H. discriminate H. Qed.

Lemma reff90_not3462 : ~ @Equation3462 Fin4 reff90_inst.
Proof. unfold Equation3462. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff90_inst, reff90_op in H. discriminate H. Qed.

Lemma reff90_not3465 : ~ @Equation3465 Fin4 reff90_inst.
Proof. unfold Equation3465. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff90_inst, reff90_op in H. discriminate H. Qed.

Lemma reff90_not3472 : ~ @Equation3472 Fin4 reff90_inst.
Proof. unfold Equation3472. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff90_inst, reff90_op in H. discriminate H. Qed.

Lemma reff90_not3475 : ~ @Equation3475 Fin4 reff90_inst.
Proof. unfold Equation3475. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff90_inst, reff90_op in H. discriminate H. Qed.

Lemma reff90_not3482 : ~ @Equation3482 Fin4 reff90_inst.
Proof. unfold Equation3482. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff90_inst, reff90_op in H. discriminate H. Qed.

Lemma reff90_not3484 : ~ @Equation3484 Fin4 reff90_inst.
Proof. unfold Equation3484. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff90_inst, reff90_op in H. discriminate H. Qed.

Lemma reff90_not3511 : ~ @Equation3511 Fin4 reff90_inst.
Proof. unfold Equation3511. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff90_inst, reff90_op in H. discriminate H. Qed.

Lemma reff90_not3512 : ~ @Equation3512 Fin4 reff90_inst.
Proof. unfold Equation3512. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff90_inst, reff90_op in H. discriminate H. Qed.

Lemma reff90_not3518 : ~ @Equation3518 Fin4 reff90_inst.
Proof. unfold Equation3518. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff90_inst, reff90_op in H. discriminate H. Qed.

Lemma reff90_not3519 : ~ @Equation3519 Fin4 reff90_inst.
Proof. unfold Equation3519. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff90_inst, reff90_op in H. discriminate H. Qed.

Lemma reff90_not3521 : ~ @Equation3521 Fin4 reff90_inst.
Proof. unfold Equation3521. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff90_inst, reff90_op in H. discriminate H. Qed.

Lemma reff90_not3545 : ~ @Equation3545 Fin4 reff90_inst.
Proof. unfold Equation3545. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff90_inst, reff90_op in H. discriminate H. Qed.

Lemma reff90_not3546 : ~ @Equation3546 Fin4 reff90_inst.
Proof. unfold Equation3546. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff90_inst, reff90_op in H. discriminate H. Qed.

Lemma reff90_not3548 : ~ @Equation3548 Fin4 reff90_inst.
Proof. unfold Equation3548. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff90_inst, reff90_op in H. discriminate H. Qed.

Lemma reff90_not3555 : ~ @Equation3555 Fin4 reff90_inst.
Proof. unfold Equation3555. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff90_inst, reff90_op in H. discriminate H. Qed.

Lemma reff90_not3558 : ~ @Equation3558 Fin4 reff90_inst.
Proof. unfold Equation3558. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff90_inst, reff90_op in H. discriminate H. Qed.

Lemma reff90_not3660 : ~ @Equation3660 Fin4 reff90_inst.
Proof. unfold Equation3660. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff90_inst, reff90_op in H. discriminate H. Qed.

Lemma reff90_not3661 : ~ @Equation3661 Fin4 reff90_inst.
Proof. unfold Equation3661. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff90_inst, reff90_op in H. discriminate H. Qed.

Lemma reff90_not3662 : ~ @Equation3662 Fin4 reff90_inst.
Proof. unfold Equation3662. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff90_inst, reff90_op in H. discriminate H. Qed.

Lemma reff90_not3664 : ~ @Equation3664 Fin4 reff90_inst.
Proof. unfold Equation3664. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff90_inst, reff90_op in H. discriminate H. Qed.

Lemma reff90_not3665 : ~ @Equation3665 Fin4 reff90_inst.
Proof. unfold Equation3665. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff90_inst, reff90_op in H. discriminate H. Qed.

Lemma reff90_not3668 : ~ @Equation3668 Fin4 reff90_inst.
Proof. unfold Equation3668. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff90_inst, reff90_op in H. discriminate H. Qed.

Lemma reff90_not3674 : ~ @Equation3674 Fin4 reff90_inst.
Proof. unfold Equation3674. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff90_inst, reff90_op in H. discriminate H. Qed.

Lemma reff90_not3675 : ~ @Equation3675 Fin4 reff90_inst.
Proof. unfold Equation3675. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff90_inst, reff90_op in H. discriminate H. Qed.

Lemma reff90_not3678 : ~ @Equation3678 Fin4 reff90_inst.
Proof. unfold Equation3678. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff90_inst, reff90_op in H. discriminate H. Qed.

Lemma reff90_not3685 : ~ @Equation3685 Fin4 reff90_inst.
Proof. unfold Equation3685. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff90_inst, reff90_op in H. discriminate H. Qed.

Lemma reff90_not3687 : ~ @Equation3687 Fin4 reff90_inst.
Proof. unfold Equation3687. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff90_inst, reff90_op in H. discriminate H. Qed.

Lemma reff90_not3714 : ~ @Equation3714 Fin4 reff90_inst.
Proof. unfold Equation3714. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff90_inst, reff90_op in H. discriminate H. Qed.

Lemma reff90_not3721 : ~ @Equation3721 Fin4 reff90_inst.
Proof. unfold Equation3721. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff90_inst, reff90_op in H. discriminate H. Qed.

Lemma reff90_not3722 : ~ @Equation3722 Fin4 reff90_inst.
Proof. unfold Equation3722. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff90_inst, reff90_op in H. discriminate H. Qed.

Lemma reff90_not3724 : ~ @Equation3724 Fin4 reff90_inst.
Proof. unfold Equation3724. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff90_inst, reff90_op in H. discriminate H. Qed.

Lemma reff90_not3748 : ~ @Equation3748 Fin4 reff90_inst.
Proof. unfold Equation3748. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff90_inst, reff90_op in H. discriminate H. Qed.

Lemma reff90_not3749 : ~ @Equation3749 Fin4 reff90_inst.
Proof. unfold Equation3749. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff90_inst, reff90_op in H. discriminate H. Qed.

Lemma reff90_not3751 : ~ @Equation3751 Fin4 reff90_inst.
Proof. unfold Equation3751. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff90_inst, reff90_op in H. discriminate H. Qed.

Lemma reff90_not3761 : ~ @Equation3761 Fin4 reff90_inst.
Proof. unfold Equation3761. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff90_inst, reff90_op in H. discriminate H. Qed.

Lemma reff90_not3864 : ~ @Equation3864 Fin4 reff90_inst.
Proof. unfold Equation3864. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff90_inst, reff90_op in H. discriminate H. Qed.

Lemma reff90_not3865 : ~ @Equation3865 Fin4 reff90_inst.
Proof. unfold Equation3865. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff90_inst, reff90_op in H. discriminate H. Qed.

Lemma reff90_not3867 : ~ @Equation3867 Fin4 reff90_inst.
Proof. unfold Equation3867. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff90_inst, reff90_op in H. discriminate H. Qed.

Lemma reff90_not3868 : ~ @Equation3868 Fin4 reff90_inst.
Proof. unfold Equation3868. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff90_inst, reff90_op in H. discriminate H. Qed.

Lemma reff90_not3871 : ~ @Equation3871 Fin4 reff90_inst.
Proof. unfold Equation3871. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff90_inst, reff90_op in H. discriminate H. Qed.

Lemma reff90_not3877 : ~ @Equation3877 Fin4 reff90_inst.
Proof. unfold Equation3877. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff90_inst, reff90_op in H. discriminate H. Qed.

Lemma reff90_not3878 : ~ @Equation3878 Fin4 reff90_inst.
Proof. unfold Equation3878. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff90_inst, reff90_op in H. discriminate H. Qed.

Lemma reff90_not3881 : ~ @Equation3881 Fin4 reff90_inst.
Proof. unfold Equation3881. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff90_inst, reff90_op in H. discriminate H. Qed.

Lemma reff90_not3888 : ~ @Equation3888 Fin4 reff90_inst.
Proof. unfold Equation3888. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff90_inst, reff90_op in H. discriminate H. Qed.

Lemma reff90_not3890 : ~ @Equation3890 Fin4 reff90_inst.
Proof. unfold Equation3890. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff90_inst, reff90_op in H. discriminate H. Qed.

Lemma reff90_not3917 : ~ @Equation3917 Fin4 reff90_inst.
Proof. unfold Equation3917. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff90_inst, reff90_op in H. discriminate H. Qed.

Lemma reff90_not3918 : ~ @Equation3918 Fin4 reff90_inst.
Proof. unfold Equation3918. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff90_inst, reff90_op in H. discriminate H. Qed.

Lemma reff90_not3924 : ~ @Equation3924 Fin4 reff90_inst.
Proof. unfold Equation3924. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff90_inst, reff90_op in H. discriminate H. Qed.

Lemma reff90_not3925 : ~ @Equation3925 Fin4 reff90_inst.
Proof. unfold Equation3925. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff90_inst, reff90_op in H. discriminate H. Qed.

Lemma reff90_not3927 : ~ @Equation3927 Fin4 reff90_inst.
Proof. unfold Equation3927. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff90_inst, reff90_op in H. discriminate H. Qed.

Lemma reff90_not3951 : ~ @Equation3951 Fin4 reff90_inst.
Proof. unfold Equation3951. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff90_inst, reff90_op in H. discriminate H. Qed.

Lemma reff90_not3952 : ~ @Equation3952 Fin4 reff90_inst.
Proof. unfold Equation3952. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff90_inst, reff90_op in H. discriminate H. Qed.

Lemma reff90_not3954 : ~ @Equation3954 Fin4 reff90_inst.
Proof. unfold Equation3954. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff90_inst, reff90_op in H. discriminate H. Qed.

Lemma reff90_not3961 : ~ @Equation3961 Fin4 reff90_inst.
Proof. unfold Equation3961. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff90_inst, reff90_op in H. discriminate H. Qed.

Lemma reff90_not3964 : ~ @Equation3964 Fin4 reff90_inst.
Proof. unfold Equation3964. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff90_inst, reff90_op in H. discriminate H. Qed.

Lemma reff90_not4066 : ~ @Equation4066 Fin4 reff90_inst.
Proof. unfold Equation4066. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff90_inst, reff90_op in H. discriminate H. Qed.

Lemma reff90_not4067 : ~ @Equation4067 Fin4 reff90_inst.
Proof. unfold Equation4067. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff90_inst, reff90_op in H. discriminate H. Qed.

Lemma reff90_not4068 : ~ @Equation4068 Fin4 reff90_inst.
Proof. unfold Equation4068. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff90_inst, reff90_op in H. discriminate H. Qed.

Lemma reff90_not4070 : ~ @Equation4070 Fin4 reff90_inst.
Proof. unfold Equation4070. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff90_inst, reff90_op in H. discriminate H. Qed.

Lemma reff90_not4071 : ~ @Equation4071 Fin4 reff90_inst.
Proof. unfold Equation4071. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff90_inst, reff90_op in H. discriminate H. Qed.

Lemma reff90_not4074 : ~ @Equation4074 Fin4 reff90_inst.
Proof. unfold Equation4074. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff90_inst, reff90_op in H. discriminate H. Qed.

Lemma reff90_not4080 : ~ @Equation4080 Fin4 reff90_inst.
Proof. unfold Equation4080. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff90_inst, reff90_op in H. discriminate H. Qed.

Lemma reff90_not4081 : ~ @Equation4081 Fin4 reff90_inst.
Proof. unfold Equation4081. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff90_inst, reff90_op in H. discriminate H. Qed.

Lemma reff90_not4084 : ~ @Equation4084 Fin4 reff90_inst.
Proof. unfold Equation4084. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff90_inst, reff90_op in H. discriminate H. Qed.

Lemma reff90_not4091 : ~ @Equation4091 Fin4 reff90_inst.
Proof. unfold Equation4091. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff90_inst, reff90_op in H. discriminate H. Qed.

Lemma reff90_not4093 : ~ @Equation4093 Fin4 reff90_inst.
Proof. unfold Equation4093. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff90_inst, reff90_op in H. discriminate H. Qed.

Lemma reff90_not4120 : ~ @Equation4120 Fin4 reff90_inst.
Proof. unfold Equation4120. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff90_inst, reff90_op in H. discriminate H. Qed.

Lemma reff90_not4121 : ~ @Equation4121 Fin4 reff90_inst.
Proof. unfold Equation4121. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff90_inst, reff90_op in H. discriminate H. Qed.

Lemma reff90_not4127 : ~ @Equation4127 Fin4 reff90_inst.
Proof. unfold Equation4127. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff90_inst, reff90_op in H. discriminate H. Qed.

Lemma reff90_not4128 : ~ @Equation4128 Fin4 reff90_inst.
Proof. unfold Equation4128. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff90_inst, reff90_op in H. discriminate H. Qed.

Lemma reff90_not4130 : ~ @Equation4130 Fin4 reff90_inst.
Proof. unfold Equation4130. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff90_inst, reff90_op in H. discriminate H. Qed.

Lemma reff90_not4154 : ~ @Equation4154 Fin4 reff90_inst.
Proof. unfold Equation4154. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff90_inst, reff90_op in H. discriminate H. Qed.

Lemma reff90_not4155 : ~ @Equation4155 Fin4 reff90_inst.
Proof. unfold Equation4155. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff90_inst, reff90_op in H. discriminate H. Qed.

Lemma reff90_not4157 : ~ @Equation4157 Fin4 reff90_inst.
Proof. unfold Equation4157. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff90_inst, reff90_op in H. discriminate H. Qed.

Lemma reff90_not4164 : ~ @Equation4164 Fin4 reff90_inst.
Proof. unfold Equation4164. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff90_inst, reff90_op in H. discriminate H. Qed.

Lemma reff90_not4167 : ~ @Equation4167 Fin4 reff90_inst.
Proof. unfold Equation4167. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff90_inst, reff90_op in H. discriminate H. Qed.

Lemma reff90_not4268 : ~ @Equation4268 Fin4 reff90_inst.
Proof. unfold Equation4268. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff90_inst, reff90_op in H. discriminate H. Qed.

Lemma reff90_not4269 : ~ @Equation4269 Fin4 reff90_inst.
Proof. unfold Equation4269. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff90_inst, reff90_op in H. discriminate H. Qed.

Lemma reff90_not4270 : ~ @Equation4270 Fin4 reff90_inst.
Proof. unfold Equation4270. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff90_inst, reff90_op in H. discriminate H. Qed.

Lemma reff90_not4272 : ~ @Equation4272 Fin4 reff90_inst.
Proof. unfold Equation4272. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff90_inst, reff90_op in H. discriminate H. Qed.

Lemma reff90_not4273 : ~ @Equation4273 Fin4 reff90_inst.
Proof. unfold Equation4273. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff90_inst, reff90_op in H. discriminate H. Qed.

Lemma reff90_not4276 : ~ @Equation4276 Fin4 reff90_inst.
Proof. unfold Equation4276. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff90_inst, reff90_op in H. discriminate H. Qed.

Lemma reff90_not4283 : ~ @Equation4283 Fin4 reff90_inst.
Proof. unfold Equation4283. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff90_inst, reff90_op in H. discriminate H. Qed.

Lemma reff90_not4284 : ~ @Equation4284 Fin4 reff90_inst.
Proof. unfold Equation4284. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff90_inst, reff90_op in H. discriminate H. Qed.

Lemma reff90_not4290 : ~ @Equation4290 Fin4 reff90_inst.
Proof. unfold Equation4290. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff90_inst, reff90_op in H. discriminate H. Qed.

Lemma reff90_not4291 : ~ @Equation4291 Fin4 reff90_inst.
Proof. unfold Equation4291. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff90_inst, reff90_op in H. discriminate H. Qed.

Lemma reff90_not4293 : ~ @Equation4293 Fin4 reff90_inst.
Proof. unfold Equation4293. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff90_inst, reff90_op in H. discriminate H. Qed.

Lemma reff90_not4314 : ~ @Equation4314 Fin4 reff90_inst.
Proof. unfold Equation4314. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff90_inst, reff90_op in H. discriminate H. Qed.

Lemma reff90_not4321 : ~ @Equation4321 Fin4 reff90_inst.
Proof. unfold Equation4321. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff90_inst, reff90_op in H. discriminate H. Qed.

Lemma reff90_not4343 : ~ @Equation4343 Fin4 reff90_inst.
Proof. unfold Equation4343. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff90_inst, reff90_op in H. discriminate H. Qed.

Lemma reff90_not4398 : ~ @Equation4398 Fin4 reff90_inst.
Proof. unfold Equation4398. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff90_inst, reff90_op in H. discriminate H. Qed.

Lemma reff90_not4399 : ~ @Equation4399 Fin4 reff90_inst.
Proof. unfold Equation4399. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff90_inst, reff90_op in H. discriminate H. Qed.

Lemma reff90_not4405 : ~ @Equation4405 Fin4 reff90_inst.
Proof. unfold Equation4405. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff90_inst, reff90_op in H. discriminate H. Qed.

Lemma reff90_not4406 : ~ @Equation4406 Fin4 reff90_inst.
Proof. unfold Equation4406. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff90_inst, reff90_op in H. discriminate H. Qed.

Lemma reff90_not4408 : ~ @Equation4408 Fin4 reff90_inst.
Proof. unfold Equation4408. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff90_inst, reff90_op in H. discriminate H. Qed.

Lemma reff90_not4433 : ~ @Equation4433 Fin4 reff90_inst.
Proof. unfold Equation4433. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff90_inst, reff90_op in H. discriminate H. Qed.

Lemma reff90_not4436 : ~ @Equation4436 Fin4 reff90_inst.
Proof. unfold Equation4436. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff90_inst, reff90_op in H. discriminate H. Qed.

Lemma reff90_not4443 : ~ @Equation4443 Fin4 reff90_inst.
Proof. unfold Equation4443. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff90_inst, reff90_op in H. discriminate H. Qed.

Lemma reff90_not4445 : ~ @Equation4445 Fin4 reff90_inst.
Proof. unfold Equation4445. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff90_inst, reff90_op in H. discriminate H. Qed.

Lemma reff90_not4470 : ~ @Equation4470 Fin4 reff90_inst.
Proof. unfold Equation4470. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff90_inst, reff90_op in H. discriminate H. Qed.

Lemma reff90_not4472 : ~ @Equation4472 Fin4 reff90_inst.
Proof. unfold Equation4472. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff90_inst, reff90_op in H. discriminate H. Qed.

Lemma reff90_not4479 : ~ @Equation4479 Fin4 reff90_inst.
Proof. unfold Equation4479. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff90_inst, reff90_op in H. discriminate H. Qed.

Lemma reff90_not4482 : ~ @Equation4482 Fin4 reff90_inst.
Proof. unfold Equation4482. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff90_inst, reff90_op in H. discriminate H. Qed.

Lemma reff90_not4583 : ~ @Equation4583 Fin4 reff90_inst.
Proof. unfold Equation4583. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff90_inst, reff90_op in H. discriminate H. Qed.

Lemma reff90_not4584 : ~ @Equation4584 Fin4 reff90_inst.
Proof. unfold Equation4584. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff90_inst, reff90_op in H. discriminate H. Qed.

Lemma reff90_not4585 : ~ @Equation4585 Fin4 reff90_inst.
Proof. unfold Equation4585. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff90_inst, reff90_op in H. discriminate H. Qed.

Lemma reff90_not4587 : ~ @Equation4587 Fin4 reff90_inst.
Proof. unfold Equation4587. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff90_inst, reff90_op in H. discriminate H. Qed.

Lemma reff90_not4588 : ~ @Equation4588 Fin4 reff90_inst.
Proof. unfold Equation4588. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff90_inst, reff90_op in H. discriminate H. Qed.

Lemma reff90_not4591 : ~ @Equation4591 Fin4 reff90_inst.
Proof. unfold Equation4591. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff90_inst, reff90_op in H. discriminate H. Qed.

Lemma reff90_not4598 : ~ @Equation4598 Fin4 reff90_inst.
Proof. unfold Equation4598. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff90_inst, reff90_op in H. discriminate H. Qed.

Lemma reff90_not4599 : ~ @Equation4599 Fin4 reff90_inst.
Proof. unfold Equation4599. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff90_inst, reff90_op in H. discriminate H. Qed.

Lemma reff90_not4605 : ~ @Equation4605 Fin4 reff90_inst.
Proof. unfold Equation4605. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff90_inst, reff90_op in H. discriminate H. Qed.

Lemma reff90_not4606 : ~ @Equation4606 Fin4 reff90_inst.
Proof. unfold Equation4606. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff90_inst, reff90_op in H. discriminate H. Qed.

Lemma reff90_not4608 : ~ @Equation4608 Fin4 reff90_inst.
Proof. unfold Equation4608. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff90_inst, reff90_op in H. discriminate H. Qed.

Lemma reff90_not4629 : ~ @Equation4629 Fin4 reff90_inst.
Proof. unfold Equation4629. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff90_inst, reff90_op in H. discriminate H. Qed.

Lemma reff90_not4636 : ~ @Equation4636 Fin4 reff90_inst.
Proof. unfold Equation4636. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff90_inst, reff90_op in H. discriminate H. Qed.

Lemma reff90_not4658 : ~ @Equation4658 Fin4 reff90_inst.
Proof. unfold Equation4658. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff90_inst, reff90_op in H. discriminate H. Qed.

(** ---- reff92 (Fin5) ---- *)

Definition reff92_op (x y : Fin5) : Fin5 :=
  match x, y with
  | F5_0, F5_0 => F5_0 | F5_0, F5_1 => F5_2 | F5_0, F5_2 => F5_2 | F5_0, F5_3 => F5_0 | F5_0, F5_4 => F5_1
  | F5_1, F5_0 => F5_1 | F5_1, F5_1 => F5_3 | F5_1, F5_2 => F5_3 | F5_1, F5_3 => F5_1 | F5_1, F5_4 => F5_2
  | F5_2, F5_0 => F5_2 | F5_2, F5_1 => F5_4 | F5_2, F5_2 => F5_4 | F5_2, F5_3 => F5_2 | F5_2, F5_4 => F5_3
  | F5_3, F5_0 => F5_3 | F5_3, F5_1 => F5_0 | F5_3, F5_2 => F5_0 | F5_3, F5_3 => F5_3 | F5_3, F5_4 => F5_4
  | F5_4, F5_0 => F5_4 | F5_4, F5_1 => F5_1 | F5_4, F5_2 => F5_1 | F5_4, F5_3 => F5_4 | F5_4, F5_4 => F5_0
  end.

#[local] Instance reff92_inst : Magma Fin5 := {| magma_op := reff92_op |}.

Lemma reff92_sat846 : @Equation846 Fin5 reff92_inst.
Proof. unfold Equation846, magma_op, reff92_inst, reff92_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff92_sat1049 : @Equation1049 Fin5 reff92_inst.
Proof. unfold Equation1049, magma_op, reff92_inst, reff92_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff92_sat4673 : @Equation4673 Fin5 reff92_inst.
Proof. unfold Equation4673, magma_op, reff92_inst, reff92_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff92_not47 : ~ @Equation47 Fin5 reff92_inst.
Proof. unfold Equation47. intro H. specialize (H F5_1). unfold magma_op, reff92_inst, reff92_op in H. discriminate H. Qed.

Lemma reff92_not99 : ~ @Equation99 Fin5 reff92_inst.
Proof. unfold Equation99. intro H. specialize (H F5_2). unfold magma_op, reff92_inst, reff92_op in H. discriminate H. Qed.

Lemma reff92_not151 : ~ @Equation151 Fin5 reff92_inst.
Proof. unfold Equation151. intro H. specialize (H F5_1). unfold magma_op, reff92_inst, reff92_op in H. discriminate H. Qed.

Lemma reff92_not203 : ~ @Equation203 Fin5 reff92_inst.
Proof. unfold Equation203. intro H. specialize (H F5_1). unfold magma_op, reff92_inst, reff92_op in H. discriminate H. Qed.

Lemma reff92_not255 : ~ @Equation255 Fin5 reff92_inst.
Proof. unfold Equation255. intro H. specialize (H F5_1). unfold magma_op, reff92_inst, reff92_op in H. discriminate H. Qed.

Lemma reff92_not411 : ~ @Equation411 Fin5 reff92_inst.
Proof. unfold Equation411. intro H. specialize (H F5_2). unfold magma_op, reff92_inst, reff92_op in H. discriminate H. Qed.

Lemma reff92_not614 : ~ @Equation614 Fin5 reff92_inst.
Proof. unfold Equation614. intro H. specialize (H F5_1). unfold magma_op, reff92_inst, reff92_op in H. discriminate H. Qed.

Lemma reff92_not818 : ~ @Equation818 Fin5 reff92_inst.
Proof. unfold Equation818. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff92_inst, reff92_op in H. discriminate H. Qed.

Lemma reff92_not819 : ~ @Equation819 Fin5 reff92_inst.
Proof. unfold Equation819. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff92_inst, reff92_op in H. discriminate H. Qed.

Lemma reff92_not820 : ~ @Equation820 Fin5 reff92_inst.
Proof. unfold Equation820. intro H. specialize (H F5_0 F5_2). unfold magma_op, reff92_inst, reff92_op in H. discriminate H. Qed.

Lemma reff92_not822 : ~ @Equation822 Fin5 reff92_inst.
Proof. unfold Equation822. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff92_inst, reff92_op in H. discriminate H. Qed.

Lemma reff92_not823 : ~ @Equation823 Fin5 reff92_inst.
Proof. unfold Equation823. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff92_inst, reff92_op in H. discriminate H. Qed.

Lemma reff92_not825 : ~ @Equation825 Fin5 reff92_inst.
Proof. unfold Equation825. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff92_inst, reff92_op in H. discriminate H. Qed.

Lemma reff92_not826 : ~ @Equation826 Fin5 reff92_inst.
Proof. unfold Equation826. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff92_inst, reff92_op in H. discriminate H. Qed.

Lemma reff92_not832 : ~ @Equation832 Fin5 reff92_inst.
Proof. unfold Equation832. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff92_inst, reff92_op in H. discriminate H. Qed.

Lemma reff92_not833 : ~ @Equation833 Fin5 reff92_inst.
Proof. unfold Equation833. intro H. specialize (H F5_0 F5_2). unfold magma_op, reff92_inst, reff92_op in H. discriminate H. Qed.

Lemma reff92_not835 : ~ @Equation835 Fin5 reff92_inst.
Proof. unfold Equation835. intro H. specialize (H F5_0 F5_2). unfold magma_op, reff92_inst, reff92_op in H. discriminate H. Qed.

Lemma reff92_not836 : ~ @Equation836 Fin5 reff92_inst.
Proof. unfold Equation836. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff92_inst, reff92_op in H. discriminate H. Qed.

Lemma reff92_not842 : ~ @Equation842 Fin5 reff92_inst.
Proof. unfold Equation842. intro H. specialize (H F5_0 F5_2). unfold magma_op, reff92_inst, reff92_op in H. discriminate H. Qed.

Lemma reff92_not843 : ~ @Equation843 Fin5 reff92_inst.
Proof. unfold Equation843. intro H. specialize (H F5_0 F5_2). unfold magma_op, reff92_inst, reff92_op in H. discriminate H. Qed.

Lemma reff92_not845 : ~ @Equation845 Fin5 reff92_inst.
Proof. unfold Equation845. intro H. specialize (H F5_0 F5_2). unfold magma_op, reff92_inst, reff92_op in H. discriminate H. Qed.

Lemma reff92_not869 : ~ @Equation869 Fin5 reff92_inst.
Proof. unfold Equation869. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff92_inst, reff92_op in H. discriminate H. Qed.

Lemma reff92_not870 : ~ @Equation870 Fin5 reff92_inst.
Proof. unfold Equation870. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff92_inst, reff92_op in H. discriminate H. Qed.

Lemma reff92_not872 : ~ @Equation872 Fin5 reff92_inst.
Proof. unfold Equation872. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff92_inst, reff92_op in H. discriminate H. Qed.

Lemma reff92_not873 : ~ @Equation873 Fin5 reff92_inst.
Proof. unfold Equation873. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff92_inst, reff92_op in H. discriminate H. Qed.

Lemma reff92_not879 : ~ @Equation879 Fin5 reff92_inst.
Proof. unfold Equation879. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff92_inst, reff92_op in H. discriminate H. Qed.

Lemma reff92_not880 : ~ @Equation880 Fin5 reff92_inst.
Proof. unfold Equation880. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff92_inst, reff92_op in H. discriminate H. Qed.

Lemma reff92_not882 : ~ @Equation882 Fin5 reff92_inst.
Proof. unfold Equation882. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff92_inst, reff92_op in H. discriminate H. Qed.

Lemma reff92_not883 : ~ @Equation883 Fin5 reff92_inst.
Proof. unfold Equation883. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff92_inst, reff92_op in H. discriminate H. Qed.

Lemma reff92_not906 : ~ @Equation906 Fin5 reff92_inst.
Proof. unfold Equation906. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff92_inst, reff92_op in H. discriminate H. Qed.

Lemma reff92_not907 : ~ @Equation907 Fin5 reff92_inst.
Proof. unfold Equation907. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff92_inst, reff92_op in H. discriminate H. Qed.

Lemma reff92_not909 : ~ @Equation909 Fin5 reff92_inst.
Proof. unfold Equation909. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff92_inst, reff92_op in H. discriminate H. Qed.

Lemma reff92_not910 : ~ @Equation910 Fin5 reff92_inst.
Proof. unfold Equation910. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff92_inst, reff92_op in H. discriminate H. Qed.

Lemma reff92_not916 : ~ @Equation916 Fin5 reff92_inst.
Proof. unfold Equation916. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff92_inst, reff92_op in H. discriminate H. Qed.

Lemma reff92_not917 : ~ @Equation917 Fin5 reff92_inst.
Proof. unfold Equation917. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff92_inst, reff92_op in H. discriminate H. Qed.

Lemma reff92_not919 : ~ @Equation919 Fin5 reff92_inst.
Proof. unfold Equation919. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff92_inst, reff92_op in H. discriminate H. Qed.

Lemma reff92_not1021 : ~ @Equation1021 Fin5 reff92_inst.
Proof. unfold Equation1021. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff92_inst, reff92_op in H. discriminate H. Qed.

Lemma reff92_not1022 : ~ @Equation1022 Fin5 reff92_inst.
Proof. unfold Equation1022. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff92_inst, reff92_op in H. discriminate H. Qed.

Lemma reff92_not1023 : ~ @Equation1023 Fin5 reff92_inst.
Proof. unfold Equation1023. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff92_inst, reff92_op in H. discriminate H. Qed.

Lemma reff92_not1025 : ~ @Equation1025 Fin5 reff92_inst.
Proof. unfold Equation1025. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff92_inst, reff92_op in H. discriminate H. Qed.

Lemma reff92_not1026 : ~ @Equation1026 Fin5 reff92_inst.
Proof. unfold Equation1026. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff92_inst, reff92_op in H. discriminate H. Qed.

Lemma reff92_not1028 : ~ @Equation1028 Fin5 reff92_inst.
Proof. unfold Equation1028. intro H. specialize (H F5_0 F5_2). unfold magma_op, reff92_inst, reff92_op in H. discriminate H. Qed.

Lemma reff92_not1029 : ~ @Equation1029 Fin5 reff92_inst.
Proof. unfold Equation1029. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff92_inst, reff92_op in H. discriminate H. Qed.

Lemma reff92_not1035 : ~ @Equation1035 Fin5 reff92_inst.
Proof. unfold Equation1035. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff92_inst, reff92_op in H. discriminate H. Qed.

Lemma reff92_not1036 : ~ @Equation1036 Fin5 reff92_inst.
Proof. unfold Equation1036. intro H. specialize (H F5_0 F5_2). unfold magma_op, reff92_inst, reff92_op in H. discriminate H. Qed.

Lemma reff92_not1038 : ~ @Equation1038 Fin5 reff92_inst.
Proof. unfold Equation1038. intro H. specialize (H F5_0 F5_2). unfold magma_op, reff92_inst, reff92_op in H. discriminate H. Qed.

Lemma reff92_not1039 : ~ @Equation1039 Fin5 reff92_inst.
Proof. unfold Equation1039. intro H. specialize (H F5_0 F5_2). unfold magma_op, reff92_inst, reff92_op in H. discriminate H. Qed.

Lemma reff92_not1045 : ~ @Equation1045 Fin5 reff92_inst.
Proof. unfold Equation1045. intro H. specialize (H F5_0 F5_2). unfold magma_op, reff92_inst, reff92_op in H. discriminate H. Qed.

Lemma reff92_not1046 : ~ @Equation1046 Fin5 reff92_inst.
Proof. unfold Equation1046. intro H. specialize (H F5_0 F5_2). unfold magma_op, reff92_inst, reff92_op in H. discriminate H. Qed.

Lemma reff92_not1048 : ~ @Equation1048 Fin5 reff92_inst.
Proof. unfold Equation1048. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff92_inst, reff92_op in H. discriminate H. Qed.

Lemma reff92_not1072 : ~ @Equation1072 Fin5 reff92_inst.
Proof. unfold Equation1072. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff92_inst, reff92_op in H. discriminate H. Qed.

Lemma reff92_not1073 : ~ @Equation1073 Fin5 reff92_inst.
Proof. unfold Equation1073. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff92_inst, reff92_op in H. discriminate H. Qed.

Lemma reff92_not1075 : ~ @Equation1075 Fin5 reff92_inst.
Proof. unfold Equation1075. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff92_inst, reff92_op in H. discriminate H. Qed.

Lemma reff92_not1076 : ~ @Equation1076 Fin5 reff92_inst.
Proof. unfold Equation1076. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff92_inst, reff92_op in H. discriminate H. Qed.

Lemma reff92_not1082 : ~ @Equation1082 Fin5 reff92_inst.
Proof. unfold Equation1082. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff92_inst, reff92_op in H. discriminate H. Qed.

Lemma reff92_not1083 : ~ @Equation1083 Fin5 reff92_inst.
Proof. unfold Equation1083. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff92_inst, reff92_op in H. discriminate H. Qed.

Lemma reff92_not1085 : ~ @Equation1085 Fin5 reff92_inst.
Proof. unfold Equation1085. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff92_inst, reff92_op in H. discriminate H. Qed.

Lemma reff92_not1086 : ~ @Equation1086 Fin5 reff92_inst.
Proof. unfold Equation1086. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff92_inst, reff92_op in H. discriminate H. Qed.

Lemma reff92_not1109 : ~ @Equation1109 Fin5 reff92_inst.
Proof. unfold Equation1109. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff92_inst, reff92_op in H. discriminate H. Qed.

Lemma reff92_not1110 : ~ @Equation1110 Fin5 reff92_inst.
Proof. unfold Equation1110. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff92_inst, reff92_op in H. discriminate H. Qed.

Lemma reff92_not1112 : ~ @Equation1112 Fin5 reff92_inst.
Proof. unfold Equation1112. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff92_inst, reff92_op in H. discriminate H. Qed.

Lemma reff92_not1113 : ~ @Equation1113 Fin5 reff92_inst.
Proof. unfold Equation1113. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff92_inst, reff92_op in H. discriminate H. Qed.

Lemma reff92_not1119 : ~ @Equation1119 Fin5 reff92_inst.
Proof. unfold Equation1119. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff92_inst, reff92_op in H. discriminate H. Qed.

Lemma reff92_not1120 : ~ @Equation1120 Fin5 reff92_inst.
Proof. unfold Equation1120. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff92_inst, reff92_op in H. discriminate H. Qed.

Lemma reff92_not1122 : ~ @Equation1122 Fin5 reff92_inst.
Proof. unfold Equation1122. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff92_inst, reff92_op in H. discriminate H. Qed.

Lemma reff92_not1223 : ~ @Equation1223 Fin5 reff92_inst.
Proof. unfold Equation1223. intro H. specialize (H F5_1). unfold magma_op, reff92_inst, reff92_op in H. discriminate H. Qed.

Lemma reff92_not1426 : ~ @Equation1426 Fin5 reff92_inst.
Proof. unfold Equation1426. intro H. specialize (H F5_1). unfold magma_op, reff92_inst, reff92_op in H. discriminate H. Qed.

Lemma reff92_not1629 : ~ @Equation1629 Fin5 reff92_inst.
Proof. unfold Equation1629. intro H. specialize (H F5_1). unfold magma_op, reff92_inst, reff92_op in H. discriminate H. Qed.

Lemma reff92_not1832 : ~ @Equation1832 Fin5 reff92_inst.
Proof. unfold Equation1832. intro H. specialize (H F5_2). unfold magma_op, reff92_inst, reff92_op in H. discriminate H. Qed.

Lemma reff92_not2035 : ~ @Equation2035 Fin5 reff92_inst.
Proof. unfold Equation2035. intro H. specialize (H F5_1). unfold magma_op, reff92_inst, reff92_op in H. discriminate H. Qed.

Lemma reff92_not2238 : ~ @Equation2238 Fin5 reff92_inst.
Proof. unfold Equation2238. intro H. specialize (H F5_1). unfold magma_op, reff92_inst, reff92_op in H. discriminate H. Qed.

Lemma reff92_not2441 : ~ @Equation2441 Fin5 reff92_inst.
Proof. unfold Equation2441. intro H. specialize (H F5_1). unfold magma_op, reff92_inst, reff92_op in H. discriminate H. Qed.

Lemma reff92_not2644 : ~ @Equation2644 Fin5 reff92_inst.
Proof. unfold Equation2644. intro H. specialize (H F5_1). unfold magma_op, reff92_inst, reff92_op in H. discriminate H. Qed.

Lemma reff92_not2847 : ~ @Equation2847 Fin5 reff92_inst.
Proof. unfold Equation2847. intro H. specialize (H F5_1). unfold magma_op, reff92_inst, reff92_op in H. discriminate H. Qed.

Lemma reff92_not3050 : ~ @Equation3050 Fin5 reff92_inst.
Proof. unfold Equation3050. intro H. specialize (H F5_1). unfold magma_op, reff92_inst, reff92_op in H. discriminate H. Qed.

Lemma reff92_not3253 : ~ @Equation3253 Fin5 reff92_inst.
Proof. unfold Equation3253. intro H. specialize (H F5_2). unfold magma_op, reff92_inst, reff92_op in H. discriminate H. Qed.

Lemma reff92_not3456 : ~ @Equation3456 Fin5 reff92_inst.
Proof. unfold Equation3456. intro H. specialize (H F5_1). unfold magma_op, reff92_inst, reff92_op in H. discriminate H. Qed.

Lemma reff92_not3659 : ~ @Equation3659 Fin5 reff92_inst.
Proof. unfold Equation3659. intro H. specialize (H F5_2). unfold magma_op, reff92_inst, reff92_op in H. discriminate H. Qed.

Lemma reff92_not3862 : ~ @Equation3862 Fin5 reff92_inst.
Proof. unfold Equation3862. intro H. specialize (H F5_2). unfold magma_op, reff92_inst, reff92_op in H. discriminate H. Qed.

Lemma reff92_not4065 : ~ @Equation4065 Fin5 reff92_inst.
Proof. unfold Equation4065. intro H. specialize (H F5_1). unfold magma_op, reff92_inst, reff92_op in H. discriminate H. Qed.

Lemma reff92_not4268 : ~ @Equation4268 Fin5 reff92_inst.
Proof. unfold Equation4268. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff92_inst, reff92_op in H. discriminate H. Qed.

Lemma reff92_not4269 : ~ @Equation4269 Fin5 reff92_inst.
Proof. unfold Equation4269. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff92_inst, reff92_op in H. discriminate H. Qed.

Lemma reff92_not4270 : ~ @Equation4270 Fin5 reff92_inst.
Proof. unfold Equation4270. intro H. specialize (H F5_0 F5_2). unfold magma_op, reff92_inst, reff92_op in H. discriminate H. Qed.

Lemma reff92_not4272 : ~ @Equation4272 Fin5 reff92_inst.
Proof. unfold Equation4272. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff92_inst, reff92_op in H. discriminate H. Qed.

Lemma reff92_not4273 : ~ @Equation4273 Fin5 reff92_inst.
Proof. unfold Equation4273. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff92_inst, reff92_op in H. discriminate H. Qed.

Lemma reff92_not4275 : ~ @Equation4275 Fin5 reff92_inst.
Proof. unfold Equation4275. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff92_inst, reff92_op in H. discriminate H. Qed.

Lemma reff92_not4276 : ~ @Equation4276 Fin5 reff92_inst.
Proof. unfold Equation4276. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff92_inst, reff92_op in H. discriminate H. Qed.

Lemma reff92_not4283 : ~ @Equation4283 Fin5 reff92_inst.
Proof. unfold Equation4283. intro H. specialize (H F5_0 F5_4). unfold magma_op, reff92_inst, reff92_op in H. discriminate H. Qed.

Lemma reff92_not4284 : ~ @Equation4284 Fin5 reff92_inst.
Proof. unfold Equation4284. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff92_inst, reff92_op in H. discriminate H. Qed.

Lemma reff92_not4290 : ~ @Equation4290 Fin5 reff92_inst.
Proof. unfold Equation4290. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff92_inst, reff92_op in H. discriminate H. Qed.

Lemma reff92_not4291 : ~ @Equation4291 Fin5 reff92_inst.
Proof. unfold Equation4291. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff92_inst, reff92_op in H. discriminate H. Qed.

Lemma reff92_not4293 : ~ @Equation4293 Fin5 reff92_inst.
Proof. unfold Equation4293. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff92_inst, reff92_op in H. discriminate H. Qed.

Lemma reff92_not4314 : ~ @Equation4314 Fin5 reff92_inst.
Proof. unfold Equation4314. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff92_inst, reff92_op in H. discriminate H. Qed.

Lemma reff92_not4320 : ~ @Equation4320 Fin5 reff92_inst.
Proof. unfold Equation4320. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff92_inst, reff92_op in H. discriminate H. Qed.

Lemma reff92_not4321 : ~ @Equation4321 Fin5 reff92_inst.
Proof. unfold Equation4321. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff92_inst, reff92_op in H. discriminate H. Qed.

Lemma reff92_not4343 : ~ @Equation4343 Fin5 reff92_inst.
Proof. unfold Equation4343. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff92_inst, reff92_op in H. discriminate H. Qed.

Lemma reff92_not4380 : ~ @Equation4380 Fin5 reff92_inst.
Proof. unfold Equation4380. intro H. specialize (H F5_1). unfold magma_op, reff92_inst, reff92_op in H. discriminate H. Qed.

Lemma reff92_not4583 : ~ @Equation4583 Fin5 reff92_inst.
Proof. unfold Equation4583. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff92_inst, reff92_op in H. discriminate H. Qed.

Lemma reff92_not4584 : ~ @Equation4584 Fin5 reff92_inst.
Proof. unfold Equation4584. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff92_inst, reff92_op in H. discriminate H. Qed.

Lemma reff92_not4585 : ~ @Equation4585 Fin5 reff92_inst.
Proof. unfold Equation4585. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff92_inst, reff92_op in H. discriminate H. Qed.

Lemma reff92_not4587 : ~ @Equation4587 Fin5 reff92_inst.
Proof. unfold Equation4587. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff92_inst, reff92_op in H. discriminate H. Qed.

Lemma reff92_not4588 : ~ @Equation4588 Fin5 reff92_inst.
Proof. unfold Equation4588. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff92_inst, reff92_op in H. discriminate H. Qed.

Lemma reff92_not4590 : ~ @Equation4590 Fin5 reff92_inst.
Proof. unfold Equation4590. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff92_inst, reff92_op in H. discriminate H. Qed.

Lemma reff92_not4591 : ~ @Equation4591 Fin5 reff92_inst.
Proof. unfold Equation4591. intro H. specialize (H F5_0 F5_2). unfold magma_op, reff92_inst, reff92_op in H. discriminate H. Qed.

Lemma reff92_not4599 : ~ @Equation4599 Fin5 reff92_inst.
Proof. unfold Equation4599. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff92_inst, reff92_op in H. discriminate H. Qed.

Lemma reff92_not4605 : ~ @Equation4605 Fin5 reff92_inst.
Proof. unfold Equation4605. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff92_inst, reff92_op in H. discriminate H. Qed.

Lemma reff92_not4606 : ~ @Equation4606 Fin5 reff92_inst.
Proof. unfold Equation4606. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff92_inst, reff92_op in H. discriminate H. Qed.

Lemma reff92_not4608 : ~ @Equation4608 Fin5 reff92_inst.
Proof. unfold Equation4608. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff92_inst, reff92_op in H. discriminate H. Qed.

Lemma reff92_not4629 : ~ @Equation4629 Fin5 reff92_inst.
Proof. unfold Equation4629. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff92_inst, reff92_op in H. discriminate H. Qed.

Lemma reff92_not4635 : ~ @Equation4635 Fin5 reff92_inst.
Proof. unfold Equation4635. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff92_inst, reff92_op in H. discriminate H. Qed.

Lemma reff92_not4636 : ~ @Equation4636 Fin5 reff92_inst.
Proof. unfold Equation4636. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff92_inst, reff92_op in H. discriminate H. Qed.

Lemma reff92_not4658 : ~ @Equation4658 Fin5 reff92_inst.
Proof. unfold Equation4658. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff92_inst, reff92_op in H. discriminate H. Qed.
