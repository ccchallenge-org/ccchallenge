(** * FinitePoly counterexamples — batch 10
    Auto-generated from Lean4 FinitePoly files. *)

From Stdlib Require Import Utf8.

From ETP Require Import Magma.
From ETP Require Import FinMagma.
From ETP.Equations Require Import All.

Open Scope magma_scope.

(** ---- reff432 (Fin3) ---- *)

Definition reff432_op (x y : Fin3) : Fin3 :=
  match x, y with
  | F3_0, F3_0 => F3_0 | F3_0, F3_1 => F3_2 | F3_0, F3_2 => F3_0
  | F3_1, F3_0 => F3_1 | F3_1, F3_1 => F3_0 | F3_1, F3_2 => F3_1
  | F3_2, F3_0 => F3_0 | F3_2, F3_1 => F3_2 | F3_2, F3_2 => F3_0
  end.

#[local] Instance reff432_inst : Magma Fin3 := {| magma_op := reff432_op |}.

Lemma reff432_sat3285 : @Equation3285 Fin3 reff432_inst.
Proof. unfold Equation3285, magma_op, reff432_inst, reff432_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff432_sat3322 : @Equation3322 Fin3 reff432_inst.
Proof. unfold Equation3322, magma_op, reff432_inst, reff432_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff432_sat3323 : @Equation3323 Fin3 reff432_inst.
Proof. unfold Equation3323, magma_op, reff432_inst, reff432_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff432_sat3902 : @Equation3902 Fin3 reff432_inst.
Proof. unfold Equation3902, magma_op, reff432_inst, reff432_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff432_sat3935 : @Equation3935 Fin3 reff432_inst.
Proof. unfold Equation3935, magma_op, reff432_inst, reff432_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff432_sat3943 : @Equation3943 Fin3 reff432_inst.
Proof. unfold Equation3943, magma_op, reff432_inst, reff432_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff432_not47 : ~ @Equation47 Fin3 reff432_inst.
Proof. unfold Equation47. intro H. specialize (H F3_1). unfold magma_op, reff432_inst, reff432_op in H. discriminate H. Qed.

Lemma reff432_not99 : ~ @Equation99 Fin3 reff432_inst.
Proof. unfold Equation99. intro H. specialize (H F3_2). unfold magma_op, reff432_inst, reff432_op in H. discriminate H. Qed.

Lemma reff432_not151 : ~ @Equation151 Fin3 reff432_inst.
Proof. unfold Equation151. intro H. specialize (H F3_1). unfold magma_op, reff432_inst, reff432_op in H. discriminate H. Qed.

Lemma reff432_not203 : ~ @Equation203 Fin3 reff432_inst.
Proof. unfold Equation203. intro H. specialize (H F3_1). unfold magma_op, reff432_inst, reff432_op in H. discriminate H. Qed.

Lemma reff432_not255 : ~ @Equation255 Fin3 reff432_inst.
Proof. unfold Equation255. intro H. specialize (H F3_1). unfold magma_op, reff432_inst, reff432_op in H. discriminate H. Qed.

Lemma reff432_not307 : ~ @Equation307 Fin3 reff432_inst.
Proof. unfold Equation307. intro H. specialize (H F3_1). unfold magma_op, reff432_inst, reff432_op in H. discriminate H. Qed.

Lemma reff432_not411 : ~ @Equation411 Fin3 reff432_inst.
Proof. unfold Equation411. intro H. specialize (H F3_2). unfold magma_op, reff432_inst, reff432_op in H. discriminate H. Qed.

Lemma reff432_not614 : ~ @Equation614 Fin3 reff432_inst.
Proof. unfold Equation614. intro H. specialize (H F3_1). unfold magma_op, reff432_inst, reff432_op in H. discriminate H. Qed.

Lemma reff432_not817 : ~ @Equation817 Fin3 reff432_inst.
Proof. unfold Equation817. intro H. specialize (H F3_2). unfold magma_op, reff432_inst, reff432_op in H. discriminate H. Qed.

Lemma reff432_not1020 : ~ @Equation1020 Fin3 reff432_inst.
Proof. unfold Equation1020. intro H. specialize (H F3_2). unfold magma_op, reff432_inst, reff432_op in H. discriminate H. Qed.

Lemma reff432_not1223 : ~ @Equation1223 Fin3 reff432_inst.
Proof. unfold Equation1223. intro H. specialize (H F3_2). unfold magma_op, reff432_inst, reff432_op in H. discriminate H. Qed.

Lemma reff432_not1426 : ~ @Equation1426 Fin3 reff432_inst.
Proof. unfold Equation1426. intro H. specialize (H F3_1). unfold magma_op, reff432_inst, reff432_op in H. discriminate H. Qed.

Lemma reff432_not1629 : ~ @Equation1629 Fin3 reff432_inst.
Proof. unfold Equation1629. intro H. specialize (H F3_1). unfold magma_op, reff432_inst, reff432_op in H. discriminate H. Qed.

Lemma reff432_not1832 : ~ @Equation1832 Fin3 reff432_inst.
Proof. unfold Equation1832. intro H. specialize (H F3_2). unfold magma_op, reff432_inst, reff432_op in H. discriminate H. Qed.

Lemma reff432_not2035 : ~ @Equation2035 Fin3 reff432_inst.
Proof. unfold Equation2035. intro H. specialize (H F3_1). unfold magma_op, reff432_inst, reff432_op in H. discriminate H. Qed.

Lemma reff432_not2238 : ~ @Equation2238 Fin3 reff432_inst.
Proof. unfold Equation2238. intro H. specialize (H F3_1). unfold magma_op, reff432_inst, reff432_op in H. discriminate H. Qed.

Lemma reff432_not2441 : ~ @Equation2441 Fin3 reff432_inst.
Proof. unfold Equation2441. intro H. specialize (H F3_1). unfold magma_op, reff432_inst, reff432_op in H. discriminate H. Qed.

Lemma reff432_not2644 : ~ @Equation2644 Fin3 reff432_inst.
Proof. unfold Equation2644. intro H. specialize (H F3_1). unfold magma_op, reff432_inst, reff432_op in H. discriminate H. Qed.

Lemma reff432_not2847 : ~ @Equation2847 Fin3 reff432_inst.
Proof. unfold Equation2847. intro H. specialize (H F3_1). unfold magma_op, reff432_inst, reff432_op in H. discriminate H. Qed.

Lemma reff432_not3050 : ~ @Equation3050 Fin3 reff432_inst.
Proof. unfold Equation3050. intro H. specialize (H F3_1). unfold magma_op, reff432_inst, reff432_op in H. discriminate H. Qed.

Lemma reff432_not3254 : ~ @Equation3254 Fin3 reff432_inst.
Proof. unfold Equation3254. intro H. specialize (H F3_1 F3_0). unfold magma_op, reff432_inst, reff432_op in H. discriminate H. Qed.

Lemma reff432_not3258 : ~ @Equation3258 Fin3 reff432_inst.
Proof. unfold Equation3258. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff432_inst, reff432_op in H. discriminate H. Qed.

Lemma reff432_not3259 : ~ @Equation3259 Fin3 reff432_inst.
Proof. unfold Equation3259. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff432_inst, reff432_op in H. discriminate H. Qed.

Lemma reff432_not3261 : ~ @Equation3261 Fin3 reff432_inst.
Proof. unfold Equation3261. intro H. specialize (H F3_1 F3_0). unfold magma_op, reff432_inst, reff432_op in H. discriminate H. Qed.

Lemma reff432_not3262 : ~ @Equation3262 Fin3 reff432_inst.
Proof. unfold Equation3262. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff432_inst, reff432_op in H. discriminate H. Qed.

Lemma reff432_not3268 : ~ @Equation3268 Fin3 reff432_inst.
Proof. unfold Equation3268. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff432_inst, reff432_op in H. discriminate H. Qed.

Lemma reff432_not3269 : ~ @Equation3269 Fin3 reff432_inst.
Proof. unfold Equation3269. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff432_inst, reff432_op in H. discriminate H. Qed.

Lemma reff432_not3271 : ~ @Equation3271 Fin3 reff432_inst.
Proof. unfold Equation3271. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff432_inst, reff432_op in H. discriminate H. Qed.

Lemma reff432_not3272 : ~ @Equation3272 Fin3 reff432_inst.
Proof. unfold Equation3272. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff432_inst, reff432_op in H. discriminate H. Qed.

Lemma reff432_not3281 : ~ @Equation3281 Fin3 reff432_inst.
Proof. unfold Equation3281. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff432_inst, reff432_op in H. discriminate H. Qed.

Lemma reff432_not3306 : ~ @Equation3306 Fin3 reff432_inst.
Proof. unfold Equation3306. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff432_inst, reff432_op in H. discriminate H. Qed.

Lemma reff432_not3308 : ~ @Equation3308 Fin3 reff432_inst.
Proof. unfold Equation3308. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff432_inst, reff432_op in H. discriminate H. Qed.

Lemma reff432_not3309 : ~ @Equation3309 Fin3 reff432_inst.
Proof. unfold Equation3309. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff432_inst, reff432_op in H. discriminate H. Qed.

Lemma reff432_not3318 : ~ @Equation3318 Fin3 reff432_inst.
Proof. unfold Equation3318. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff432_inst, reff432_op in H. discriminate H. Qed.

Lemma reff432_not3342 : ~ @Equation3342 Fin3 reff432_inst.
Proof. unfold Equation3342. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff432_inst, reff432_op in H. discriminate H. Qed.

Lemma reff432_not3343 : ~ @Equation3343 Fin3 reff432_inst.
Proof. unfold Equation3343. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff432_inst, reff432_op in H. discriminate H. Qed.

Lemma reff432_not3345 : ~ @Equation3345 Fin3 reff432_inst.
Proof. unfold Equation3345. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff432_inst, reff432_op in H. discriminate H. Qed.

Lemma reff432_not3346 : ~ @Equation3346 Fin3 reff432_inst.
Proof. unfold Equation3346. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff432_inst, reff432_op in H. discriminate H. Qed.

Lemma reff432_not3352 : ~ @Equation3352 Fin3 reff432_inst.
Proof. unfold Equation3352. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff432_inst, reff432_op in H. discriminate H. Qed.

Lemma reff432_not3353 : ~ @Equation3353 Fin3 reff432_inst.
Proof. unfold Equation3353. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff432_inst, reff432_op in H. discriminate H. Qed.

Lemma reff432_not3456 : ~ @Equation3456 Fin3 reff432_inst.
Proof. unfold Equation3456. intro H. specialize (H F3_1). unfold magma_op, reff432_inst, reff432_op in H. discriminate H. Qed.

Lemma reff432_not3660 : ~ @Equation3660 Fin3 reff432_inst.
Proof. unfold Equation3660. intro H. specialize (H F3_1 F3_0). unfold magma_op, reff432_inst, reff432_op in H. discriminate H. Qed.

Lemma reff432_not3661 : ~ @Equation3661 Fin3 reff432_inst.
Proof. unfold Equation3661. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff432_inst, reff432_op in H. discriminate H. Qed.

Lemma reff432_not3664 : ~ @Equation3664 Fin3 reff432_inst.
Proof. unfold Equation3664. intro H. specialize (H F3_1 F3_0). unfold magma_op, reff432_inst, reff432_op in H. discriminate H. Qed.

Lemma reff432_not3667 : ~ @Equation3667 Fin3 reff432_inst.
Proof. unfold Equation3667. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff432_inst, reff432_op in H. discriminate H. Qed.

Lemma reff432_not3668 : ~ @Equation3668 Fin3 reff432_inst.
Proof. unfold Equation3668. intro H. specialize (H F3_1 F3_0). unfold magma_op, reff432_inst, reff432_op in H. discriminate H. Qed.

Lemma reff432_not3674 : ~ @Equation3674 Fin3 reff432_inst.
Proof. unfold Equation3674. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff432_inst, reff432_op in H. discriminate H. Qed.

Lemma reff432_not3675 : ~ @Equation3675 Fin3 reff432_inst.
Proof. unfold Equation3675. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff432_inst, reff432_op in H. discriminate H. Qed.

Lemma reff432_not3678 : ~ @Equation3678 Fin3 reff432_inst.
Proof. unfold Equation3678. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff432_inst, reff432_op in H. discriminate H. Qed.

Lemma reff432_not3685 : ~ @Equation3685 Fin3 reff432_inst.
Proof. unfold Equation3685. intro H. specialize (H F3_1 F3_0). unfold magma_op, reff432_inst, reff432_op in H. discriminate H. Qed.

Lemma reff432_not3687 : ~ @Equation3687 Fin3 reff432_inst.
Proof. unfold Equation3687. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff432_inst, reff432_op in H. discriminate H. Qed.

Lemma reff432_not3712 : ~ @Equation3712 Fin3 reff432_inst.
Proof. unfold Equation3712. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff432_inst, reff432_op in H. discriminate H. Qed.

Lemma reff432_not3714 : ~ @Equation3714 Fin3 reff432_inst.
Proof. unfold Equation3714. intro H. specialize (H F3_1 F3_0). unfold magma_op, reff432_inst, reff432_op in H. discriminate H. Qed.

Lemma reff432_not3721 : ~ @Equation3721 Fin3 reff432_inst.
Proof. unfold Equation3721. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff432_inst, reff432_op in H. discriminate H. Qed.

Lemma reff432_not3722 : ~ @Equation3722 Fin3 reff432_inst.
Proof. unfold Equation3722. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff432_inst, reff432_op in H. discriminate H. Qed.

Lemma reff432_not3725 : ~ @Equation3725 Fin3 reff432_inst.
Proof. unfold Equation3725. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff432_inst, reff432_op in H. discriminate H. Qed.

Lemma reff432_not3748 : ~ @Equation3748 Fin3 reff432_inst.
Proof. unfold Equation3748. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff432_inst, reff432_op in H. discriminate H. Qed.

Lemma reff432_not3749 : ~ @Equation3749 Fin3 reff432_inst.
Proof. unfold Equation3749. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff432_inst, reff432_op in H. discriminate H. Qed.

Lemma reff432_not3751 : ~ @Equation3751 Fin3 reff432_inst.
Proof. unfold Equation3751. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff432_inst, reff432_op in H. discriminate H. Qed.

Lemma reff432_not3752 : ~ @Equation3752 Fin3 reff432_inst.
Proof. unfold Equation3752. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff432_inst, reff432_op in H. discriminate H. Qed.

Lemma reff432_not3759 : ~ @Equation3759 Fin3 reff432_inst.
Proof. unfold Equation3759. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff432_inst, reff432_op in H. discriminate H. Qed.

Lemma reff432_not3761 : ~ @Equation3761 Fin3 reff432_inst.
Proof. unfold Equation3761. intro H. specialize (H F3_1 F3_0). unfold magma_op, reff432_inst, reff432_op in H. discriminate H. Qed.

Lemma reff432_not3864 : ~ @Equation3864 Fin3 reff432_inst.
Proof. unfold Equation3864. intro H. specialize (H F3_1 F3_0). unfold magma_op, reff432_inst, reff432_op in H. discriminate H. Qed.

Lemma reff432_not3865 : ~ @Equation3865 Fin3 reff432_inst.
Proof. unfold Equation3865. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff432_inst, reff432_op in H. discriminate H. Qed.

Lemma reff432_not3868 : ~ @Equation3868 Fin3 reff432_inst.
Proof. unfold Equation3868. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff432_inst, reff432_op in H. discriminate H. Qed.

Lemma reff432_not3871 : ~ @Equation3871 Fin3 reff432_inst.
Proof. unfold Equation3871. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff432_inst, reff432_op in H. discriminate H. Qed.

Lemma reff432_not3877 : ~ @Equation3877 Fin3 reff432_inst.
Proof. unfold Equation3877. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff432_inst, reff432_op in H. discriminate H. Qed.

Lemma reff432_not3880 : ~ @Equation3880 Fin3 reff432_inst.
Proof. unfold Equation3880. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff432_inst, reff432_op in H. discriminate H. Qed.

Lemma reff432_not3887 : ~ @Equation3887 Fin3 reff432_inst.
Proof. unfold Equation3887. intro H. specialize (H F3_1 F3_0). unfold magma_op, reff432_inst, reff432_op in H. discriminate H. Qed.

Lemma reff432_not3888 : ~ @Equation3888 Fin3 reff432_inst.
Proof. unfold Equation3888. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff432_inst, reff432_op in H. discriminate H. Qed.

Lemma reff432_not3890 : ~ @Equation3890 Fin3 reff432_inst.
Proof. unfold Equation3890. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff432_inst, reff432_op in H. discriminate H. Qed.

Lemma reff432_not3917 : ~ @Equation3917 Fin3 reff432_inst.
Proof. unfold Equation3917. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff432_inst, reff432_op in H. discriminate H. Qed.

Lemma reff432_not3918 : ~ @Equation3918 Fin3 reff432_inst.
Proof. unfold Equation3918. intro H. specialize (H F3_1 F3_0). unfold magma_op, reff432_inst, reff432_op in H. discriminate H. Qed.

Lemma reff432_not3924 : ~ @Equation3924 Fin3 reff432_inst.
Proof. unfold Equation3924. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff432_inst, reff432_op in H. discriminate H. Qed.

Lemma reff432_not3927 : ~ @Equation3927 Fin3 reff432_inst.
Proof. unfold Equation3927. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff432_inst, reff432_op in H. discriminate H. Qed.

Lemma reff432_not3951 : ~ @Equation3951 Fin3 reff432_inst.
Proof. unfold Equation3951. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff432_inst, reff432_op in H. discriminate H. Qed.

Lemma reff432_not3952 : ~ @Equation3952 Fin3 reff432_inst.
Proof. unfold Equation3952. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff432_inst, reff432_op in H. discriminate H. Qed.

Lemma reff432_not3954 : ~ @Equation3954 Fin3 reff432_inst.
Proof. unfold Equation3954. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff432_inst, reff432_op in H. discriminate H. Qed.

Lemma reff432_not3955 : ~ @Equation3955 Fin3 reff432_inst.
Proof. unfold Equation3955. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff432_inst, reff432_op in H. discriminate H. Qed.

Lemma reff432_not3961 : ~ @Equation3961 Fin3 reff432_inst.
Proof. unfold Equation3961. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff432_inst, reff432_op in H. discriminate H. Qed.

Lemma reff432_not3962 : ~ @Equation3962 Fin3 reff432_inst.
Proof. unfold Equation3962. intro H. specialize (H F3_1 F3_0). unfold magma_op, reff432_inst, reff432_op in H. discriminate H. Qed.

Lemma reff432_not3964 : ~ @Equation3964 Fin3 reff432_inst.
Proof. unfold Equation3964. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff432_inst, reff432_op in H. discriminate H. Qed.

Lemma reff432_not4065 : ~ @Equation4065 Fin3 reff432_inst.
Proof. unfold Equation4065. intro H. specialize (H F3_1). unfold magma_op, reff432_inst, reff432_op in H. discriminate H. Qed.

Lemma reff432_not4268 : ~ @Equation4268 Fin3 reff432_inst.
Proof. unfold Equation4268. intro H. specialize (H F3_1 F3_0). unfold magma_op, reff432_inst, reff432_op in H. discriminate H. Qed.

Lemma reff432_not4269 : ~ @Equation4269 Fin3 reff432_inst.
Proof. unfold Equation4269. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff432_inst, reff432_op in H. discriminate H. Qed.

Lemma reff432_not4272 : ~ @Equation4272 Fin3 reff432_inst.
Proof. unfold Equation4272. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff432_inst, reff432_op in H. discriminate H. Qed.

Lemma reff432_not4273 : ~ @Equation4273 Fin3 reff432_inst.
Proof. unfold Equation4273. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff432_inst, reff432_op in H. discriminate H. Qed.

Lemma reff432_not4275 : ~ @Equation4275 Fin3 reff432_inst.
Proof. unfold Equation4275. intro H. specialize (H F3_1 F3_0). unfold magma_op, reff432_inst, reff432_op in H. discriminate H. Qed.

Lemma reff432_not4276 : ~ @Equation4276 Fin3 reff432_inst.
Proof. unfold Equation4276. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff432_inst, reff432_op in H. discriminate H. Qed.

Lemma reff432_not4283 : ~ @Equation4283 Fin3 reff432_inst.
Proof. unfold Equation4283. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff432_inst, reff432_op in H. discriminate H. Qed.

Lemma reff432_not4284 : ~ @Equation4284 Fin3 reff432_inst.
Proof. unfold Equation4284. intro H. specialize (H F3_1 F3_0). unfold magma_op, reff432_inst, reff432_op in H. discriminate H. Qed.

Lemma reff432_not4290 : ~ @Equation4290 Fin3 reff432_inst.
Proof. unfold Equation4290. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff432_inst, reff432_op in H. discriminate H. Qed.

Lemma reff432_not4291 : ~ @Equation4291 Fin3 reff432_inst.
Proof. unfold Equation4291. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff432_inst, reff432_op in H. discriminate H. Qed.

Lemma reff432_not4314 : ~ @Equation4314 Fin3 reff432_inst.
Proof. unfold Equation4314. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff432_inst, reff432_op in H. discriminate H. Qed.

Lemma reff432_not4320 : ~ @Equation4320 Fin3 reff432_inst.
Proof. unfold Equation4320. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff432_inst, reff432_op in H. discriminate H. Qed.

Lemma reff432_not4321 : ~ @Equation4321 Fin3 reff432_inst.
Proof. unfold Equation4321. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff432_inst, reff432_op in H. discriminate H. Qed.

Lemma reff432_not4343 : ~ @Equation4343 Fin3 reff432_inst.
Proof. unfold Equation4343. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff432_inst, reff432_op in H. discriminate H. Qed.

Lemma reff432_not4380 : ~ @Equation4380 Fin3 reff432_inst.
Proof. unfold Equation4380. intro H. specialize (H F3_1). unfold magma_op, reff432_inst, reff432_op in H. discriminate H. Qed.

Lemma reff432_not4583 : ~ @Equation4583 Fin3 reff432_inst.
Proof. unfold Equation4583. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff432_inst, reff432_op in H. discriminate H. Qed.

Lemma reff432_not4584 : ~ @Equation4584 Fin3 reff432_inst.
Proof. unfold Equation4584. intro H. specialize (H F3_1 F3_0). unfold magma_op, reff432_inst, reff432_op in H. discriminate H. Qed.

Lemma reff432_not4585 : ~ @Equation4585 Fin3 reff432_inst.
Proof. unfold Equation4585. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff432_inst, reff432_op in H. discriminate H. Qed.

Lemma reff432_not4587 : ~ @Equation4587 Fin3 reff432_inst.
Proof. unfold Equation4587. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff432_inst, reff432_op in H. discriminate H. Qed.

Lemma reff432_not4588 : ~ @Equation4588 Fin3 reff432_inst.
Proof. unfold Equation4588. intro H. specialize (H F3_1 F3_0). unfold magma_op, reff432_inst, reff432_op in H. discriminate H. Qed.

Lemma reff432_not4591 : ~ @Equation4591 Fin3 reff432_inst.
Proof. unfold Equation4591. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff432_inst, reff432_op in H. discriminate H. Qed.

Lemma reff432_not4598 : ~ @Equation4598 Fin3 reff432_inst.
Proof. unfold Equation4598. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff432_inst, reff432_op in H. discriminate H. Qed.

Lemma reff432_not4599 : ~ @Equation4599 Fin3 reff432_inst.
Proof. unfold Equation4599. intro H. specialize (H F3_1 F3_0). unfold magma_op, reff432_inst, reff432_op in H. discriminate H. Qed.

Lemma reff432_not4605 : ~ @Equation4605 Fin3 reff432_inst.
Proof. unfold Equation4605. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff432_inst, reff432_op in H. discriminate H. Qed.

Lemma reff432_not4606 : ~ @Equation4606 Fin3 reff432_inst.
Proof. unfold Equation4606. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff432_inst, reff432_op in H. discriminate H. Qed.

Lemma reff432_not4608 : ~ @Equation4608 Fin3 reff432_inst.
Proof. unfold Equation4608. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff432_inst, reff432_op in H. discriminate H. Qed.

Lemma reff432_not4629 : ~ @Equation4629 Fin3 reff432_inst.
Proof. unfold Equation4629. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff432_inst, reff432_op in H. discriminate H. Qed.

Lemma reff432_not4635 : ~ @Equation4635 Fin3 reff432_inst.
Proof. unfold Equation4635. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff432_inst, reff432_op in H. discriminate H. Qed.

Lemma reff432_not4658 : ~ @Equation4658 Fin3 reff432_inst.
Proof. unfold Equation4658. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff432_inst, reff432_op in H. discriminate H. Qed.

(** ---- reff444 (Fin3) ---- *)

Definition reff444_op (x y : Fin3) : Fin3 :=
  match x, y with
  | F3_0, F3_0 => F3_0 | F3_0, F3_1 => F3_2 | F3_0, F3_2 => F3_2
  | F3_1, F3_0 => F3_1 | F3_1, F3_1 => F3_2 | F3_1, F3_2 => F3_1
  | F3_2, F3_0 => F3_0 | F3_2, F3_1 => F3_0 | F3_2, F3_2 => F3_1
  end.

#[local] Instance reff444_inst : Magma Fin3 := {| magma_op := reff444_op |}.

Lemma reff444_sat156 : @Equation156 Fin3 reff444_inst.
Proof. unfold Equation156, magma_op, reff444_inst, reff444_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff444_sat159 : @Equation159 Fin3 reff444_inst.
Proof. unfold Equation159, magma_op, reff444_inst, reff444_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff444_sat4067 : @Equation4067 Fin3 reff444_inst.
Proof. unfold Equation4067, magma_op, reff444_inst, reff444_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff444_not359 : ~ @Equation359 Fin3 reff444_inst.
Proof. unfold Equation359. intro H. specialize (H F3_1). unfold magma_op, reff444_inst, reff444_op in H. discriminate H. Qed.

Lemma reff444_not1426 : ~ @Equation1426 Fin3 reff444_inst.
Proof. unfold Equation1426. intro H. specialize (H F3_1). unfold magma_op, reff444_inst, reff444_op in H. discriminate H. Qed.

Lemma reff444_not1629 : ~ @Equation1629 Fin3 reff444_inst.
Proof. unfold Equation1629. intro H. specialize (H F3_1). unfold magma_op, reff444_inst, reff444_op in H. discriminate H. Qed.

Lemma reff444_not1833 : ~ @Equation1833 Fin3 reff444_inst.
Proof. unfold Equation1833. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff444_inst, reff444_op in H. discriminate H. Qed.

Lemma reff444_not1834 : ~ @Equation1834 Fin3 reff444_inst.
Proof. unfold Equation1834. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff444_inst, reff444_op in H. discriminate H. Qed.

Lemma reff444_not1835 : ~ @Equation1835 Fin3 reff444_inst.
Proof. unfold Equation1835. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff444_inst, reff444_op in H. discriminate H. Qed.

Lemma reff444_not1838 : ~ @Equation1838 Fin3 reff444_inst.
Proof. unfold Equation1838. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff444_inst, reff444_op in H. discriminate H. Qed.

Lemma reff444_not1840 : ~ @Equation1840 Fin3 reff444_inst.
Proof. unfold Equation1840. intro H. specialize (H F3_1 F3_2). unfold magma_op, reff444_inst, reff444_op in H. discriminate H. Qed.

Lemma reff444_not1841 : ~ @Equation1841 Fin3 reff444_inst.
Proof. unfold Equation1841. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff444_inst, reff444_op in H. discriminate H. Qed.

Lemma reff444_not1848 : ~ @Equation1848 Fin3 reff444_inst.
Proof. unfold Equation1848. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff444_inst, reff444_op in H. discriminate H. Qed.

Lemma reff444_not1850 : ~ @Equation1850 Fin3 reff444_inst.
Proof. unfold Equation1850. intro H. specialize (H F3_2 F3_0). unfold magma_op, reff444_inst, reff444_op in H. discriminate H. Qed.

Lemma reff444_not1851 : ~ @Equation1851 Fin3 reff444_inst.
Proof. unfold Equation1851. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff444_inst, reff444_op in H. discriminate H. Qed.

Lemma reff444_not1858 : ~ @Equation1858 Fin3 reff444_inst.
Proof. unfold Equation1858. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff444_inst, reff444_op in H. discriminate H. Qed.

Lemma reff444_not1860 : ~ @Equation1860 Fin3 reff444_inst.
Proof. unfold Equation1860. intro H. specialize (H F3_1 F3_2). unfold magma_op, reff444_inst, reff444_op in H. discriminate H. Qed.

Lemma reff444_not1861 : ~ @Equation1861 Fin3 reff444_inst.
Proof. unfold Equation1861. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff444_inst, reff444_op in H. discriminate H. Qed.

Lemma reff444_not1884 : ~ @Equation1884 Fin3 reff444_inst.
Proof. unfold Equation1884. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff444_inst, reff444_op in H. discriminate H. Qed.

Lemma reff444_not1885 : ~ @Equation1885 Fin3 reff444_inst.
Proof. unfold Equation1885. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff444_inst, reff444_op in H. discriminate H. Qed.

Lemma reff444_not1887 : ~ @Equation1887 Fin3 reff444_inst.
Proof. unfold Equation1887. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff444_inst, reff444_op in H. discriminate H. Qed.

Lemma reff444_not1888 : ~ @Equation1888 Fin3 reff444_inst.
Proof. unfold Equation1888. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff444_inst, reff444_op in H. discriminate H. Qed.

Lemma reff444_not1894 : ~ @Equation1894 Fin3 reff444_inst.
Proof. unfold Equation1894. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff444_inst, reff444_op in H. discriminate H. Qed.

Lemma reff444_not1895 : ~ @Equation1895 Fin3 reff444_inst.
Proof. unfold Equation1895. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff444_inst, reff444_op in H. discriminate H. Qed.

Lemma reff444_not1897 : ~ @Equation1897 Fin3 reff444_inst.
Proof. unfold Equation1897. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff444_inst, reff444_op in H. discriminate H. Qed.

Lemma reff444_not1898 : ~ @Equation1898 Fin3 reff444_inst.
Proof. unfold Equation1898. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff444_inst, reff444_op in H. discriminate H. Qed.

Lemma reff444_not1921 : ~ @Equation1921 Fin3 reff444_inst.
Proof. unfold Equation1921. intro H. specialize (H F3_1 F3_2). unfold magma_op, reff444_inst, reff444_op in H. discriminate H. Qed.

Lemma reff444_not1922 : ~ @Equation1922 Fin3 reff444_inst.
Proof. unfold Equation1922. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff444_inst, reff444_op in H. discriminate H. Qed.

Lemma reff444_not1924 : ~ @Equation1924 Fin3 reff444_inst.
Proof. unfold Equation1924. intro H. specialize (H F3_1 F3_2). unfold magma_op, reff444_inst, reff444_op in H. discriminate H. Qed.

Lemma reff444_not1925 : ~ @Equation1925 Fin3 reff444_inst.
Proof. unfold Equation1925. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff444_inst, reff444_op in H. discriminate H. Qed.

Lemma reff444_not1931 : ~ @Equation1931 Fin3 reff444_inst.
Proof. unfold Equation1931. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff444_inst, reff444_op in H. discriminate H. Qed.

Lemma reff444_not1932 : ~ @Equation1932 Fin3 reff444_inst.
Proof. unfold Equation1932. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff444_inst, reff444_op in H. discriminate H. Qed.

Lemma reff444_not1934 : ~ @Equation1934 Fin3 reff444_inst.
Proof. unfold Equation1934. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff444_inst, reff444_op in H. discriminate H. Qed.

Lemma reff444_not2035 : ~ @Equation2035 Fin3 reff444_inst.
Proof. unfold Equation2035. intro H. specialize (H F3_1). unfold magma_op, reff444_inst, reff444_op in H. discriminate H. Qed.

Lemma reff444_not3253 : ~ @Equation3253 Fin3 reff444_inst.
Proof. unfold Equation3253. intro H. specialize (H F3_2). unfold magma_op, reff444_inst, reff444_op in H. discriminate H. Qed.

Lemma reff444_not3456 : ~ @Equation3456 Fin3 reff444_inst.
Proof. unfold Equation3456. intro H. specialize (H F3_1). unfold magma_op, reff444_inst, reff444_op in H. discriminate H. Qed.

Lemma reff444_not3862 : ~ @Equation3862 Fin3 reff444_inst.
Proof. unfold Equation3862. intro H. specialize (H F3_2). unfold magma_op, reff444_inst, reff444_op in H. discriminate H. Qed.

Lemma reff444_not4066 : ~ @Equation4066 Fin3 reff444_inst.
Proof. unfold Equation4066. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff444_inst, reff444_op in H. discriminate H. Qed.

Lemma reff444_not4068 : ~ @Equation4068 Fin3 reff444_inst.
Proof. unfold Equation4068. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff444_inst, reff444_op in H. discriminate H. Qed.

Lemma reff444_not4070 : ~ @Equation4070 Fin3 reff444_inst.
Proof. unfold Equation4070. intro H. specialize (H F3_1 F3_0). unfold magma_op, reff444_inst, reff444_op in H. discriminate H. Qed.

Lemma reff444_not4071 : ~ @Equation4071 Fin3 reff444_inst.
Proof. unfold Equation4071. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff444_inst, reff444_op in H. discriminate H. Qed.

Lemma reff444_not4073 : ~ @Equation4073 Fin3 reff444_inst.
Proof. unfold Equation4073. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff444_inst, reff444_op in H. discriminate H. Qed.

Lemma reff444_not4074 : ~ @Equation4074 Fin3 reff444_inst.
Proof. unfold Equation4074. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff444_inst, reff444_op in H. discriminate H. Qed.

Lemma reff444_not4080 : ~ @Equation4080 Fin3 reff444_inst.
Proof. unfold Equation4080. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff444_inst, reff444_op in H. discriminate H. Qed.

Lemma reff444_not4083 : ~ @Equation4083 Fin3 reff444_inst.
Proof. unfold Equation4083. intro H. specialize (H F3_1 F3_2). unfold magma_op, reff444_inst, reff444_op in H. discriminate H. Qed.

Lemma reff444_not4084 : ~ @Equation4084 Fin3 reff444_inst.
Proof. unfold Equation4084. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff444_inst, reff444_op in H. discriminate H. Qed.

Lemma reff444_not4090 : ~ @Equation4090 Fin3 reff444_inst.
Proof. unfold Equation4090. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff444_inst, reff444_op in H. discriminate H. Qed.

Lemma reff444_not4091 : ~ @Equation4091 Fin3 reff444_inst.
Proof. unfold Equation4091. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff444_inst, reff444_op in H. discriminate H. Qed.

Lemma reff444_not4093 : ~ @Equation4093 Fin3 reff444_inst.
Proof. unfold Equation4093. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff444_inst, reff444_op in H. discriminate H. Qed.

Lemma reff444_not4118 : ~ @Equation4118 Fin3 reff444_inst.
Proof. unfold Equation4118. intro H. specialize (H F3_1 F3_0). unfold magma_op, reff444_inst, reff444_op in H. discriminate H. Qed.

Lemma reff444_not4120 : ~ @Equation4120 Fin3 reff444_inst.
Proof. unfold Equation4120. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff444_inst, reff444_op in H. discriminate H. Qed.

Lemma reff444_not4121 : ~ @Equation4121 Fin3 reff444_inst.
Proof. unfold Equation4121. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff444_inst, reff444_op in H. discriminate H. Qed.

Lemma reff444_not4127 : ~ @Equation4127 Fin3 reff444_inst.
Proof. unfold Equation4127. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff444_inst, reff444_op in H. discriminate H. Qed.

Lemma reff444_not4128 : ~ @Equation4128 Fin3 reff444_inst.
Proof. unfold Equation4128. intro H. specialize (H F3_1 F3_0). unfold magma_op, reff444_inst, reff444_op in H. discriminate H. Qed.

Lemma reff444_not4130 : ~ @Equation4130 Fin3 reff444_inst.
Proof. unfold Equation4130. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff444_inst, reff444_op in H. discriminate H. Qed.

Lemma reff444_not4131 : ~ @Equation4131 Fin3 reff444_inst.
Proof. unfold Equation4131. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff444_inst, reff444_op in H. discriminate H. Qed.

Lemma reff444_not4155 : ~ @Equation4155 Fin3 reff444_inst.
Proof. unfold Equation4155. intro H. specialize (H F3_1 F3_0). unfold magma_op, reff444_inst, reff444_op in H. discriminate H. Qed.

Lemma reff444_not4157 : ~ @Equation4157 Fin3 reff444_inst.
Proof. unfold Equation4157. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff444_inst, reff444_op in H. discriminate H. Qed.

Lemma reff444_not4158 : ~ @Equation4158 Fin3 reff444_inst.
Proof. unfold Equation4158. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff444_inst, reff444_op in H. discriminate H. Qed.

Lemma reff444_not4164 : ~ @Equation4164 Fin3 reff444_inst.
Proof. unfold Equation4164. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff444_inst, reff444_op in H. discriminate H. Qed.

Lemma reff444_not4165 : ~ @Equation4165 Fin3 reff444_inst.
Proof. unfold Equation4165. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff444_inst, reff444_op in H. discriminate H. Qed.

Lemma reff444_not4167 : ~ @Equation4167 Fin3 reff444_inst.
Proof. unfold Equation4167. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff444_inst, reff444_op in H. discriminate H. Qed.

Lemma reff444_not4283 : ~ @Equation4283 Fin3 reff444_inst.
Proof. unfold Equation4283. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff444_inst, reff444_op in H. discriminate H. Qed.

Lemma reff444_not4380 : ~ @Equation4380 Fin3 reff444_inst.
Proof. unfold Equation4380. intro H. specialize (H F3_1). unfold magma_op, reff444_inst, reff444_op in H. discriminate H. Qed.

Lemma reff444_not4635 : ~ @Equation4635 Fin3 reff444_inst.
Proof. unfold Equation4635. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff444_inst, reff444_op in H. discriminate H. Qed.

(** ---- reff454 (Fin4) ---- *)

Definition reff454_op (x y : Fin4) : Fin4 :=
  match x, y with
  | F4_0, F4_0 => F4_0 | F4_0, F4_1 => F4_1 | F4_0, F4_2 => F4_2 | F4_0, F4_3 => F4_3
  | F4_1, F4_0 => F4_3 | F4_1, F4_1 => F4_2 | F4_1, F4_2 => F4_1 | F4_1, F4_3 => F4_0
  | F4_2, F4_0 => F4_2 | F4_2, F4_1 => F4_3 | F4_2, F4_2 => F4_0 | F4_2, F4_3 => F4_1
  | F4_3, F4_0 => F4_1 | F4_3, F4_1 => F4_0 | F4_3, F4_2 => F4_3 | F4_3, F4_3 => F4_2
  end.

#[local] Instance reff454_inst : Magma Fin4 := {| magma_op := reff454_op |}.

Lemma reff454_sat562 : @Equation562 Fin4 reff454_inst.
Proof. unfold Equation562, magma_op, reff454_inst, reff454_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff454_sat1098 : @Equation1098 Fin4 reff454_inst.
Proof. unfold Equation1098, magma_op, reff454_inst, reff454_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff454_sat1152 : @Equation1152 Fin4 reff454_inst.
Proof. unfold Equation1152, magma_op, reff454_inst, reff454_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff454_sat1764 : @Equation1764 Fin4 reff454_inst.
Proof. unfold Equation1764, magma_op, reff454_inst, reff454_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff454_sat1876 : @Equation1876 Fin4 reff454_inst.
Proof. unfold Equation1876, magma_op, reff454_inst, reff454_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff454_sat1913 : @Equation1913 Fin4 reff454_inst.
Proof. unfold Equation1913, magma_op, reff454_inst, reff454_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff454_sat2576 : @Equation2576 Fin4 reff454_inst.
Proof. unfold Equation2576, magma_op, reff454_inst, reff454_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff454_sat2592 : @Equation2592 Fin4 reff454_inst.
Proof. unfold Equation2592, magma_op, reff454_inst, reff454_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff454_sat2722 : @Equation2722 Fin4 reff454_inst.
Proof. unfold Equation2722, magma_op, reff454_inst, reff454_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff454_sat2776 : @Equation2776 Fin4 reff454_inst.
Proof. unfold Equation2776, magma_op, reff454_inst, reff454_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff454_sat2808 : @Equation2808 Fin4 reff454_inst.
Proof. unfold Equation2808, magma_op, reff454_inst, reff454_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff454_sat3185 : @Equation3185 Fin4 reff454_inst.
Proof. unfold Equation3185, magma_op, reff454_inst, reff454_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff454_sat3201 : @Equation3201 Fin4 reff454_inst.
Proof. unfold Equation3201, magma_op, reff454_inst, reff454_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff454_sat3388 : @Equation3388 Fin4 reff454_inst.
Proof. unfold Equation3388, magma_op, reff454_inst, reff454_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff454_sat3973 : @Equation3973 Fin4 reff454_inst.
Proof. unfold Equation3973, magma_op, reff454_inst, reff454_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff454_sat4007 : @Equation4007 Fin4 reff454_inst.
Proof. unfold Equation4007, magma_op, reff454_inst, reff454_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff454_sat4588 : @Equation4588 Fin4 reff454_inst.
Proof. unfold Equation4588, magma_op, reff454_inst, reff454_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff454_not47 : ~ @Equation47 Fin4 reff454_inst.
Proof. unfold Equation47. intro H. specialize (H F4_1). unfold magma_op, reff454_inst, reff454_op in H. discriminate H. Qed.

Lemma reff454_not99 : ~ @Equation99 Fin4 reff454_inst.
Proof. unfold Equation99. intro H. specialize (H F4_1). unfold magma_op, reff454_inst, reff454_op in H. discriminate H. Qed.

Lemma reff454_not151 : ~ @Equation151 Fin4 reff454_inst.
Proof. unfold Equation151. intro H. specialize (H F4_1). unfold magma_op, reff454_inst, reff454_op in H. discriminate H. Qed.

Lemma reff454_not203 : ~ @Equation203 Fin4 reff454_inst.
Proof. unfold Equation203. intro H. specialize (H F4_1). unfold magma_op, reff454_inst, reff454_op in H. discriminate H. Qed.

Lemma reff454_not255 : ~ @Equation255 Fin4 reff454_inst.
Proof. unfold Equation255. intro H. specialize (H F4_1). unfold magma_op, reff454_inst, reff454_op in H. discriminate H. Qed.

Lemma reff454_not307 : ~ @Equation307 Fin4 reff454_inst.
Proof. unfold Equation307. intro H. specialize (H F4_1). unfold magma_op, reff454_inst, reff454_op in H. discriminate H. Qed.

Lemma reff454_not412 : ~ @Equation412 Fin4 reff454_inst.
Proof. unfold Equation412. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff454_inst, reff454_op in H. discriminate H. Qed.

Lemma reff454_not413 : ~ @Equation413 Fin4 reff454_inst.
Proof. unfold Equation413. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff454_inst, reff454_op in H. discriminate H. Qed.

Lemma reff454_not414 : ~ @Equation414 Fin4 reff454_inst.
Proof. unfold Equation414. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff454_inst, reff454_op in H. discriminate H. Qed.

Lemma reff454_not416 : ~ @Equation416 Fin4 reff454_inst.
Proof. unfold Equation416. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff454_inst, reff454_op in H. discriminate H. Qed.

Lemma reff454_not417 : ~ @Equation417 Fin4 reff454_inst.
Proof. unfold Equation417. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff454_inst, reff454_op in H. discriminate H. Qed.

Lemma reff454_not420 : ~ @Equation420 Fin4 reff454_inst.
Proof. unfold Equation420. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff454_inst, reff454_op in H. discriminate H. Qed.

Lemma reff454_not426 : ~ @Equation426 Fin4 reff454_inst.
Proof. unfold Equation426. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff454_inst, reff454_op in H. discriminate H. Qed.

Lemma reff454_not427 : ~ @Equation427 Fin4 reff454_inst.
Proof. unfold Equation427. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff454_inst, reff454_op in H. discriminate H. Qed.

Lemma reff454_not430 : ~ @Equation430 Fin4 reff454_inst.
Proof. unfold Equation430. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff454_inst, reff454_op in H. discriminate H. Qed.

Lemma reff454_not437 : ~ @Equation437 Fin4 reff454_inst.
Proof. unfold Equation437. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff454_inst, reff454_op in H. discriminate H. Qed.

Lemma reff454_not439 : ~ @Equation439 Fin4 reff454_inst.
Proof. unfold Equation439. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff454_inst, reff454_op in H. discriminate H. Qed.

Lemma reff454_not440 : ~ @Equation440 Fin4 reff454_inst.
Proof. unfold Equation440. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff454_inst, reff454_op in H. discriminate H. Qed.

Lemma reff454_not463 : ~ @Equation463 Fin4 reff454_inst.
Proof. unfold Equation463. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff454_inst, reff454_op in H. discriminate H. Qed.

Lemma reff454_not464 : ~ @Equation464 Fin4 reff454_inst.
Proof. unfold Equation464. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff454_inst, reff454_op in H. discriminate H. Qed.

Lemma reff454_not467 : ~ @Equation467 Fin4 reff454_inst.
Proof. unfold Equation467. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff454_inst, reff454_op in H. discriminate H. Qed.

Lemma reff454_not474 : ~ @Equation474 Fin4 reff454_inst.
Proof. unfold Equation474. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff454_inst, reff454_op in H. discriminate H. Qed.

Lemma reff454_not476 : ~ @Equation476 Fin4 reff454_inst.
Proof. unfold Equation476. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff454_inst, reff454_op in H. discriminate H. Qed.

Lemma reff454_not477 : ~ @Equation477 Fin4 reff454_inst.
Proof. unfold Equation477. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff454_inst, reff454_op in H. discriminate H. Qed.

Lemma reff454_not501 : ~ @Equation501 Fin4 reff454_inst.
Proof. unfold Equation501. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff454_inst, reff454_op in H. discriminate H. Qed.

Lemma reff454_not503 : ~ @Equation503 Fin4 reff454_inst.
Proof. unfold Equation503. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff454_inst, reff454_op in H. discriminate H. Qed.

Lemma reff454_not504 : ~ @Equation504 Fin4 reff454_inst.
Proof. unfold Equation504. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff454_inst, reff454_op in H. discriminate H. Qed.

Lemma reff454_not510 : ~ @Equation510 Fin4 reff454_inst.
Proof. unfold Equation510. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff454_inst, reff454_op in H. discriminate H. Qed.

Lemma reff454_not511 : ~ @Equation511 Fin4 reff454_inst.
Proof. unfold Equation511. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff454_inst, reff454_op in H. discriminate H. Qed.

Lemma reff454_not614 : ~ @Equation614 Fin4 reff454_inst.
Proof. unfold Equation614. intro H. specialize (H F4_1). unfold magma_op, reff454_inst, reff454_op in H. discriminate H. Qed.

Lemma reff454_not817 : ~ @Equation817 Fin4 reff454_inst.
Proof. unfold Equation817. intro H. specialize (H F4_1). unfold magma_op, reff454_inst, reff454_op in H. discriminate H. Qed.

Lemma reff454_not1021 : ~ @Equation1021 Fin4 reff454_inst.
Proof. unfold Equation1021. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff454_inst, reff454_op in H. discriminate H. Qed.

Lemma reff454_not1022 : ~ @Equation1022 Fin4 reff454_inst.
Proof. unfold Equation1022. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff454_inst, reff454_op in H. discriminate H. Qed.

Lemma reff454_not1023 : ~ @Equation1023 Fin4 reff454_inst.
Proof. unfold Equation1023. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff454_inst, reff454_op in H. discriminate H. Qed.

Lemma reff454_not1025 : ~ @Equation1025 Fin4 reff454_inst.
Proof. unfold Equation1025. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff454_inst, reff454_op in H. discriminate H. Qed.

Lemma reff454_not1028 : ~ @Equation1028 Fin4 reff454_inst.
Proof. unfold Equation1028. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff454_inst, reff454_op in H. discriminate H. Qed.

Lemma reff454_not1029 : ~ @Equation1029 Fin4 reff454_inst.
Proof. unfold Equation1029. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff454_inst, reff454_op in H. discriminate H. Qed.

Lemma reff454_not1035 : ~ @Equation1035 Fin4 reff454_inst.
Proof. unfold Equation1035. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff454_inst, reff454_op in H. discriminate H. Qed.

Lemma reff454_not1038 : ~ @Equation1038 Fin4 reff454_inst.
Proof. unfold Equation1038. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff454_inst, reff454_op in H. discriminate H. Qed.

Lemma reff454_not1039 : ~ @Equation1039 Fin4 reff454_inst.
Proof. unfold Equation1039. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff454_inst, reff454_op in H. discriminate H. Qed.

Lemma reff454_not1046 : ~ @Equation1046 Fin4 reff454_inst.
Proof. unfold Equation1046. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff454_inst, reff454_op in H. discriminate H. Qed.

Lemma reff454_not1048 : ~ @Equation1048 Fin4 reff454_inst.
Proof. unfold Equation1048. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff454_inst, reff454_op in H. discriminate H. Qed.

Lemma reff454_not1049 : ~ @Equation1049 Fin4 reff454_inst.
Proof. unfold Equation1049. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff454_inst, reff454_op in H. discriminate H. Qed.

Lemma reff454_not1072 : ~ @Equation1072 Fin4 reff454_inst.
Proof. unfold Equation1072. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff454_inst, reff454_op in H. discriminate H. Qed.

Lemma reff454_not1073 : ~ @Equation1073 Fin4 reff454_inst.
Proof. unfold Equation1073. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff454_inst, reff454_op in H. discriminate H. Qed.

Lemma reff454_not1076 : ~ @Equation1076 Fin4 reff454_inst.
Proof. unfold Equation1076. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff454_inst, reff454_op in H. discriminate H. Qed.

Lemma reff454_not1082 : ~ @Equation1082 Fin4 reff454_inst.
Proof. unfold Equation1082. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff454_inst, reff454_op in H. discriminate H. Qed.

Lemma reff454_not1083 : ~ @Equation1083 Fin4 reff454_inst.
Proof. unfold Equation1083. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff454_inst, reff454_op in H. discriminate H. Qed.

Lemma reff454_not1085 : ~ @Equation1085 Fin4 reff454_inst.
Proof. unfold Equation1085. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff454_inst, reff454_op in H. discriminate H. Qed.

Lemma reff454_not1109 : ~ @Equation1109 Fin4 reff454_inst.
Proof. unfold Equation1109. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff454_inst, reff454_op in H. discriminate H. Qed.

Lemma reff454_not1110 : ~ @Equation1110 Fin4 reff454_inst.
Proof. unfold Equation1110. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff454_inst, reff454_op in H. discriminate H. Qed.

Lemma reff454_not1112 : ~ @Equation1112 Fin4 reff454_inst.
Proof. unfold Equation1112. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff454_inst, reff454_op in H. discriminate H. Qed.

Lemma reff454_not1119 : ~ @Equation1119 Fin4 reff454_inst.
Proof. unfold Equation1119. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff454_inst, reff454_op in H. discriminate H. Qed.

Lemma reff454_not1120 : ~ @Equation1120 Fin4 reff454_inst.
Proof. unfold Equation1120. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff454_inst, reff454_op in H. discriminate H. Qed.

Lemma reff454_not1223 : ~ @Equation1223 Fin4 reff454_inst.
Proof. unfold Equation1223. intro H. specialize (H F4_1). unfold magma_op, reff454_inst, reff454_op in H. discriminate H. Qed.

Lemma reff454_not1426 : ~ @Equation1426 Fin4 reff454_inst.
Proof. unfold Equation1426. intro H. specialize (H F4_1). unfold magma_op, reff454_inst, reff454_op in H. discriminate H. Qed.

Lemma reff454_not1630 : ~ @Equation1630 Fin4 reff454_inst.
Proof. unfold Equation1630. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff454_inst, reff454_op in H. discriminate H. Qed.

Lemma reff454_not1631 : ~ @Equation1631 Fin4 reff454_inst.
Proof. unfold Equation1631. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff454_inst, reff454_op in H. discriminate H. Qed.

Lemma reff454_not1632 : ~ @Equation1632 Fin4 reff454_inst.
Proof. unfold Equation1632. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff454_inst, reff454_op in H. discriminate H. Qed.

Lemma reff454_not1634 : ~ @Equation1634 Fin4 reff454_inst.
Proof. unfold Equation1634. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff454_inst, reff454_op in H. discriminate H. Qed.

Lemma reff454_not1637 : ~ @Equation1637 Fin4 reff454_inst.
Proof. unfold Equation1637. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff454_inst, reff454_op in H. discriminate H. Qed.

Lemma reff454_not1638 : ~ @Equation1638 Fin4 reff454_inst.
Proof. unfold Equation1638. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff454_inst, reff454_op in H. discriminate H. Qed.

Lemma reff454_not1644 : ~ @Equation1644 Fin4 reff454_inst.
Proof. unfold Equation1644. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff454_inst, reff454_op in H. discriminate H. Qed.

Lemma reff454_not1645 : ~ @Equation1645 Fin4 reff454_inst.
Proof. unfold Equation1645. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff454_inst, reff454_op in H. discriminate H. Qed.

Lemma reff454_not1648 : ~ @Equation1648 Fin4 reff454_inst.
Proof. unfold Equation1648. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff454_inst, reff454_op in H. discriminate H. Qed.

Lemma reff454_not1654 : ~ @Equation1654 Fin4 reff454_inst.
Proof. unfold Equation1654. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff454_inst, reff454_op in H. discriminate H. Qed.

Lemma reff454_not1655 : ~ @Equation1655 Fin4 reff454_inst.
Proof. unfold Equation1655. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff454_inst, reff454_op in H. discriminate H. Qed.

Lemma reff454_not1657 : ~ @Equation1657 Fin4 reff454_inst.
Proof. unfold Equation1657. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff454_inst, reff454_op in H. discriminate H. Qed.

Lemma reff454_not1681 : ~ @Equation1681 Fin4 reff454_inst.
Proof. unfold Equation1681. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff454_inst, reff454_op in H. discriminate H. Qed.

Lemma reff454_not1684 : ~ @Equation1684 Fin4 reff454_inst.
Proof. unfold Equation1684. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff454_inst, reff454_op in H. discriminate H. Qed.

Lemma reff454_not1685 : ~ @Equation1685 Fin4 reff454_inst.
Proof. unfold Equation1685. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff454_inst, reff454_op in H. discriminate H. Qed.

Lemma reff454_not1692 : ~ @Equation1692 Fin4 reff454_inst.
Proof. unfold Equation1692. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff454_inst, reff454_op in H. discriminate H. Qed.

Lemma reff454_not1694 : ~ @Equation1694 Fin4 reff454_inst.
Proof. unfold Equation1694. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff454_inst, reff454_op in H. discriminate H. Qed.

Lemma reff454_not1695 : ~ @Equation1695 Fin4 reff454_inst.
Proof. unfold Equation1695. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff454_inst, reff454_op in H. discriminate H. Qed.

Lemma reff454_not1718 : ~ @Equation1718 Fin4 reff454_inst.
Proof. unfold Equation1718. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff454_inst, reff454_op in H. discriminate H. Qed.

Lemma reff454_not1719 : ~ @Equation1719 Fin4 reff454_inst.
Proof. unfold Equation1719. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff454_inst, reff454_op in H. discriminate H. Qed.

Lemma reff454_not1721 : ~ @Equation1721 Fin4 reff454_inst.
Proof. unfold Equation1721. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff454_inst, reff454_op in H. discriminate H. Qed.

Lemma reff454_not1728 : ~ @Equation1728 Fin4 reff454_inst.
Proof. unfold Equation1728. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff454_inst, reff454_op in H. discriminate H. Qed.

Lemma reff454_not1729 : ~ @Equation1729 Fin4 reff454_inst.
Proof. unfold Equation1729. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff454_inst, reff454_op in H. discriminate H. Qed.

Lemma reff454_not1833 : ~ @Equation1833 Fin4 reff454_inst.
Proof. unfold Equation1833. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff454_inst, reff454_op in H. discriminate H. Qed.

Lemma reff454_not1834 : ~ @Equation1834 Fin4 reff454_inst.
Proof. unfold Equation1834. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff454_inst, reff454_op in H. discriminate H. Qed.

Lemma reff454_not1835 : ~ @Equation1835 Fin4 reff454_inst.
Proof. unfold Equation1835. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff454_inst, reff454_op in H. discriminate H. Qed.

Lemma reff454_not1837 : ~ @Equation1837 Fin4 reff454_inst.
Proof. unfold Equation1837. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff454_inst, reff454_op in H. discriminate H. Qed.

Lemma reff454_not1838 : ~ @Equation1838 Fin4 reff454_inst.
Proof. unfold Equation1838. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff454_inst, reff454_op in H. discriminate H. Qed.

Lemma reff454_not1841 : ~ @Equation1841 Fin4 reff454_inst.
Proof. unfold Equation1841. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff454_inst, reff454_op in H. discriminate H. Qed.

Lemma reff454_not1847 : ~ @Equation1847 Fin4 reff454_inst.
Proof. unfold Equation1847. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff454_inst, reff454_op in H. discriminate H. Qed.

Lemma reff454_not1850 : ~ @Equation1850 Fin4 reff454_inst.
Proof. unfold Equation1850. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff454_inst, reff454_op in H. discriminate H. Qed.

Lemma reff454_not1851 : ~ @Equation1851 Fin4 reff454_inst.
Proof. unfold Equation1851. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff454_inst, reff454_op in H. discriminate H. Qed.

Lemma reff454_not1857 : ~ @Equation1857 Fin4 reff454_inst.
Proof. unfold Equation1857. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff454_inst, reff454_op in H. discriminate H. Qed.

Lemma reff454_not1858 : ~ @Equation1858 Fin4 reff454_inst.
Proof. unfold Equation1858. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff454_inst, reff454_op in H. discriminate H. Qed.

Lemma reff454_not1860 : ~ @Equation1860 Fin4 reff454_inst.
Proof. unfold Equation1860. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff454_inst, reff454_op in H. discriminate H. Qed.

Lemma reff454_not1884 : ~ @Equation1884 Fin4 reff454_inst.
Proof. unfold Equation1884. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff454_inst, reff454_op in H. discriminate H. Qed.

Lemma reff454_not1887 : ~ @Equation1887 Fin4 reff454_inst.
Proof. unfold Equation1887. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff454_inst, reff454_op in H. discriminate H. Qed.

Lemma reff454_not1888 : ~ @Equation1888 Fin4 reff454_inst.
Proof. unfold Equation1888. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff454_inst, reff454_op in H. discriminate H. Qed.

Lemma reff454_not1894 : ~ @Equation1894 Fin4 reff454_inst.
Proof. unfold Equation1894. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff454_inst, reff454_op in H. discriminate H. Qed.

Lemma reff454_not1895 : ~ @Equation1895 Fin4 reff454_inst.
Proof. unfold Equation1895. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff454_inst, reff454_op in H. discriminate H. Qed.

Lemma reff454_not1897 : ~ @Equation1897 Fin4 reff454_inst.
Proof. unfold Equation1897. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff454_inst, reff454_op in H. discriminate H. Qed.

Lemma reff454_not1922 : ~ @Equation1922 Fin4 reff454_inst.
Proof. unfold Equation1922. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff454_inst, reff454_op in H. discriminate H. Qed.

Lemma reff454_not1924 : ~ @Equation1924 Fin4 reff454_inst.
Proof. unfold Equation1924. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff454_inst, reff454_op in H. discriminate H. Qed.

Lemma reff454_not1925 : ~ @Equation1925 Fin4 reff454_inst.
Proof. unfold Equation1925. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff454_inst, reff454_op in H. discriminate H. Qed.

Lemma reff454_not1931 : ~ @Equation1931 Fin4 reff454_inst.
Proof. unfold Equation1931. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff454_inst, reff454_op in H. discriminate H. Qed.

Lemma reff454_not1932 : ~ @Equation1932 Fin4 reff454_inst.
Proof. unfold Equation1932. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff454_inst, reff454_op in H. discriminate H. Qed.

Lemma reff454_not2035 : ~ @Equation2035 Fin4 reff454_inst.
Proof. unfold Equation2035. intro H. specialize (H F4_1). unfold magma_op, reff454_inst, reff454_op in H. discriminate H. Qed.

Lemma reff454_not2238 : ~ @Equation2238 Fin4 reff454_inst.
Proof. unfold Equation2238. intro H. specialize (H F4_1). unfold magma_op, reff454_inst, reff454_op in H. discriminate H. Qed.

Lemma reff454_not2442 : ~ @Equation2442 Fin4 reff454_inst.
Proof. unfold Equation2442. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff454_inst, reff454_op in H. discriminate H. Qed.

Lemma reff454_not2443 : ~ @Equation2443 Fin4 reff454_inst.
Proof. unfold Equation2443. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff454_inst, reff454_op in H. discriminate H. Qed.

Lemma reff454_not2444 : ~ @Equation2444 Fin4 reff454_inst.
Proof. unfold Equation2444. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff454_inst, reff454_op in H. discriminate H. Qed.

Lemma reff454_not2446 : ~ @Equation2446 Fin4 reff454_inst.
Proof. unfold Equation2446. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff454_inst, reff454_op in H. discriminate H. Qed.

Lemma reff454_not2449 : ~ @Equation2449 Fin4 reff454_inst.
Proof. unfold Equation2449. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff454_inst, reff454_op in H. discriminate H. Qed.

Lemma reff454_not2450 : ~ @Equation2450 Fin4 reff454_inst.
Proof. unfold Equation2450. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff454_inst, reff454_op in H. discriminate H. Qed.

Lemma reff454_not2456 : ~ @Equation2456 Fin4 reff454_inst.
Proof. unfold Equation2456. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff454_inst, reff454_op in H. discriminate H. Qed.

Lemma reff454_not2457 : ~ @Equation2457 Fin4 reff454_inst.
Proof. unfold Equation2457. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff454_inst, reff454_op in H. discriminate H. Qed.

Lemma reff454_not2460 : ~ @Equation2460 Fin4 reff454_inst.
Proof. unfold Equation2460. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff454_inst, reff454_op in H. discriminate H. Qed.

Lemma reff454_not2466 : ~ @Equation2466 Fin4 reff454_inst.
Proof. unfold Equation2466. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff454_inst, reff454_op in H. discriminate H. Qed.

Lemma reff454_not2467 : ~ @Equation2467 Fin4 reff454_inst.
Proof. unfold Equation2467. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff454_inst, reff454_op in H. discriminate H. Qed.

Lemma reff454_not2469 : ~ @Equation2469 Fin4 reff454_inst.
Proof. unfold Equation2469. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff454_inst, reff454_op in H. discriminate H. Qed.

Lemma reff454_not2493 : ~ @Equation2493 Fin4 reff454_inst.
Proof. unfold Equation2493. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff454_inst, reff454_op in H. discriminate H. Qed.

Lemma reff454_not2496 : ~ @Equation2496 Fin4 reff454_inst.
Proof. unfold Equation2496. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff454_inst, reff454_op in H. discriminate H. Qed.

Lemma reff454_not2497 : ~ @Equation2497 Fin4 reff454_inst.
Proof. unfold Equation2497. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff454_inst, reff454_op in H. discriminate H. Qed.

Lemma reff454_not2504 : ~ @Equation2504 Fin4 reff454_inst.
Proof. unfold Equation2504. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff454_inst, reff454_op in H. discriminate H. Qed.

Lemma reff454_not2506 : ~ @Equation2506 Fin4 reff454_inst.
Proof. unfold Equation2506. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff454_inst, reff454_op in H. discriminate H. Qed.

Lemma reff454_not2507 : ~ @Equation2507 Fin4 reff454_inst.
Proof. unfold Equation2507. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff454_inst, reff454_op in H. discriminate H. Qed.

Lemma reff454_not2530 : ~ @Equation2530 Fin4 reff454_inst.
Proof. unfold Equation2530. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff454_inst, reff454_op in H. discriminate H. Qed.

Lemma reff454_not2531 : ~ @Equation2531 Fin4 reff454_inst.
Proof. unfold Equation2531. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff454_inst, reff454_op in H. discriminate H. Qed.

Lemma reff454_not2533 : ~ @Equation2533 Fin4 reff454_inst.
Proof. unfold Equation2533. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff454_inst, reff454_op in H. discriminate H. Qed.

Lemma reff454_not2540 : ~ @Equation2540 Fin4 reff454_inst.
Proof. unfold Equation2540. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff454_inst, reff454_op in H. discriminate H. Qed.

Lemma reff454_not2541 : ~ @Equation2541 Fin4 reff454_inst.
Proof. unfold Equation2541. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff454_inst, reff454_op in H. discriminate H. Qed.

Lemma reff454_not2645 : ~ @Equation2645 Fin4 reff454_inst.
Proof. unfold Equation2645. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff454_inst, reff454_op in H. discriminate H. Qed.

Lemma reff454_not2646 : ~ @Equation2646 Fin4 reff454_inst.
Proof. unfold Equation2646. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff454_inst, reff454_op in H. discriminate H. Qed.

Lemma reff454_not2647 : ~ @Equation2647 Fin4 reff454_inst.
Proof. unfold Equation2647. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff454_inst, reff454_op in H. discriminate H. Qed.

Lemma reff454_not2649 : ~ @Equation2649 Fin4 reff454_inst.
Proof. unfold Equation2649. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff454_inst, reff454_op in H. discriminate H. Qed.

Lemma reff454_not2652 : ~ @Equation2652 Fin4 reff454_inst.
Proof. unfold Equation2652. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff454_inst, reff454_op in H. discriminate H. Qed.

Lemma reff454_not2653 : ~ @Equation2653 Fin4 reff454_inst.
Proof. unfold Equation2653. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff454_inst, reff454_op in H. discriminate H. Qed.

Lemma reff454_not2659 : ~ @Equation2659 Fin4 reff454_inst.
Proof. unfold Equation2659. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff454_inst, reff454_op in H. discriminate H. Qed.

Lemma reff454_not2662 : ~ @Equation2662 Fin4 reff454_inst.
Proof. unfold Equation2662. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff454_inst, reff454_op in H. discriminate H. Qed.

Lemma reff454_not2663 : ~ @Equation2663 Fin4 reff454_inst.
Proof. unfold Equation2663. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff454_inst, reff454_op in H. discriminate H. Qed.

Lemma reff454_not2670 : ~ @Equation2670 Fin4 reff454_inst.
Proof. unfold Equation2670. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff454_inst, reff454_op in H. discriminate H. Qed.

Lemma reff454_not2672 : ~ @Equation2672 Fin4 reff454_inst.
Proof. unfold Equation2672. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff454_inst, reff454_op in H. discriminate H. Qed.

Lemma reff454_not2673 : ~ @Equation2673 Fin4 reff454_inst.
Proof. unfold Equation2673. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff454_inst, reff454_op in H. discriminate H. Qed.

Lemma reff454_not2696 : ~ @Equation2696 Fin4 reff454_inst.
Proof. unfold Equation2696. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff454_inst, reff454_op in H. discriminate H. Qed.

Lemma reff454_not2697 : ~ @Equation2697 Fin4 reff454_inst.
Proof. unfold Equation2697. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff454_inst, reff454_op in H. discriminate H. Qed.

Lemma reff454_not2700 : ~ @Equation2700 Fin4 reff454_inst.
Proof. unfold Equation2700. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff454_inst, reff454_op in H. discriminate H. Qed.

Lemma reff454_not2706 : ~ @Equation2706 Fin4 reff454_inst.
Proof. unfold Equation2706. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff454_inst, reff454_op in H. discriminate H. Qed.

Lemma reff454_not2707 : ~ @Equation2707 Fin4 reff454_inst.
Proof. unfold Equation2707. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff454_inst, reff454_op in H. discriminate H. Qed.

Lemma reff454_not2709 : ~ @Equation2709 Fin4 reff454_inst.
Proof. unfold Equation2709. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff454_inst, reff454_op in H. discriminate H. Qed.

Lemma reff454_not2733 : ~ @Equation2733 Fin4 reff454_inst.
Proof. unfold Equation2733. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff454_inst, reff454_op in H. discriminate H. Qed.

Lemma reff454_not2734 : ~ @Equation2734 Fin4 reff454_inst.
Proof. unfold Equation2734. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff454_inst, reff454_op in H. discriminate H. Qed.

Lemma reff454_not2736 : ~ @Equation2736 Fin4 reff454_inst.
Proof. unfold Equation2736. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff454_inst, reff454_op in H. discriminate H. Qed.

Lemma reff454_not2743 : ~ @Equation2743 Fin4 reff454_inst.
Proof. unfold Equation2743. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff454_inst, reff454_op in H. discriminate H. Qed.

Lemma reff454_not2744 : ~ @Equation2744 Fin4 reff454_inst.
Proof. unfold Equation2744. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff454_inst, reff454_op in H. discriminate H. Qed.

Lemma reff454_not2847 : ~ @Equation2847 Fin4 reff454_inst.
Proof. unfold Equation2847. intro H. specialize (H F4_1). unfold magma_op, reff454_inst, reff454_op in H. discriminate H. Qed.

Lemma reff454_not3051 : ~ @Equation3051 Fin4 reff454_inst.
Proof. unfold Equation3051. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff454_inst, reff454_op in H. discriminate H. Qed.

Lemma reff454_not3052 : ~ @Equation3052 Fin4 reff454_inst.
Proof. unfold Equation3052. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff454_inst, reff454_op in H. discriminate H. Qed.

Lemma reff454_not3053 : ~ @Equation3053 Fin4 reff454_inst.
Proof. unfold Equation3053. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff454_inst, reff454_op in H. discriminate H. Qed.

Lemma reff454_not3055 : ~ @Equation3055 Fin4 reff454_inst.
Proof. unfold Equation3055. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff454_inst, reff454_op in H. discriminate H. Qed.

Lemma reff454_not3058 : ~ @Equation3058 Fin4 reff454_inst.
Proof. unfold Equation3058. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff454_inst, reff454_op in H. discriminate H. Qed.

Lemma reff454_not3059 : ~ @Equation3059 Fin4 reff454_inst.
Proof. unfold Equation3059. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff454_inst, reff454_op in H. discriminate H. Qed.

Lemma reff454_not3065 : ~ @Equation3065 Fin4 reff454_inst.
Proof. unfold Equation3065. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff454_inst, reff454_op in H. discriminate H. Qed.

Lemma reff454_not3066 : ~ @Equation3066 Fin4 reff454_inst.
Proof. unfold Equation3066. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff454_inst, reff454_op in H. discriminate H. Qed.

Lemma reff454_not3069 : ~ @Equation3069 Fin4 reff454_inst.
Proof. unfold Equation3069. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff454_inst, reff454_op in H. discriminate H. Qed.

Lemma reff454_not3075 : ~ @Equation3075 Fin4 reff454_inst.
Proof. unfold Equation3075. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff454_inst, reff454_op in H. discriminate H. Qed.

Lemma reff454_not3076 : ~ @Equation3076 Fin4 reff454_inst.
Proof. unfold Equation3076. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff454_inst, reff454_op in H. discriminate H. Qed.

Lemma reff454_not3078 : ~ @Equation3078 Fin4 reff454_inst.
Proof. unfold Equation3078. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff454_inst, reff454_op in H. discriminate H. Qed.

Lemma reff454_not3102 : ~ @Equation3102 Fin4 reff454_inst.
Proof. unfold Equation3102. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff454_inst, reff454_op in H. discriminate H. Qed.

Lemma reff454_not3105 : ~ @Equation3105 Fin4 reff454_inst.
Proof. unfold Equation3105. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff454_inst, reff454_op in H. discriminate H. Qed.

Lemma reff454_not3106 : ~ @Equation3106 Fin4 reff454_inst.
Proof. unfold Equation3106. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff454_inst, reff454_op in H. discriminate H. Qed.

Lemma reff454_not3113 : ~ @Equation3113 Fin4 reff454_inst.
Proof. unfold Equation3113. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff454_inst, reff454_op in H. discriminate H. Qed.

Lemma reff454_not3115 : ~ @Equation3115 Fin4 reff454_inst.
Proof. unfold Equation3115. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff454_inst, reff454_op in H. discriminate H. Qed.

Lemma reff454_not3116 : ~ @Equation3116 Fin4 reff454_inst.
Proof. unfold Equation3116. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff454_inst, reff454_op in H. discriminate H. Qed.

Lemma reff454_not3139 : ~ @Equation3139 Fin4 reff454_inst.
Proof. unfold Equation3139. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff454_inst, reff454_op in H. discriminate H. Qed.

Lemma reff454_not3140 : ~ @Equation3140 Fin4 reff454_inst.
Proof. unfold Equation3140. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff454_inst, reff454_op in H. discriminate H. Qed.

Lemma reff454_not3142 : ~ @Equation3142 Fin4 reff454_inst.
Proof. unfold Equation3142. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff454_inst, reff454_op in H. discriminate H. Qed.

Lemma reff454_not3149 : ~ @Equation3149 Fin4 reff454_inst.
Proof. unfold Equation3149. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff454_inst, reff454_op in H. discriminate H. Qed.

Lemma reff454_not3150 : ~ @Equation3150 Fin4 reff454_inst.
Proof. unfold Equation3150. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff454_inst, reff454_op in H. discriminate H. Qed.

Lemma reff454_not3254 : ~ @Equation3254 Fin4 reff454_inst.
Proof. unfold Equation3254. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff454_inst, reff454_op in H. discriminate H. Qed.

Lemma reff454_not3255 : ~ @Equation3255 Fin4 reff454_inst.
Proof. unfold Equation3255. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff454_inst, reff454_op in H. discriminate H. Qed.

Lemma reff454_not3256 : ~ @Equation3256 Fin4 reff454_inst.
Proof. unfold Equation3256. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff454_inst, reff454_op in H. discriminate H. Qed.

Lemma reff454_not3258 : ~ @Equation3258 Fin4 reff454_inst.
Proof. unfold Equation3258. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff454_inst, reff454_op in H. discriminate H. Qed.

Lemma reff454_not3259 : ~ @Equation3259 Fin4 reff454_inst.
Proof. unfold Equation3259. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff454_inst, reff454_op in H. discriminate H. Qed.

Lemma reff454_not3262 : ~ @Equation3262 Fin4 reff454_inst.
Proof. unfold Equation3262. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff454_inst, reff454_op in H. discriminate H. Qed.

Lemma reff454_not3268 : ~ @Equation3268 Fin4 reff454_inst.
Proof. unfold Equation3268. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff454_inst, reff454_op in H. discriminate H. Qed.

Lemma reff454_not3272 : ~ @Equation3272 Fin4 reff454_inst.
Proof. unfold Equation3272. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff454_inst, reff454_op in H. discriminate H. Qed.

Lemma reff454_not3279 : ~ @Equation3279 Fin4 reff454_inst.
Proof. unfold Equation3279. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff454_inst, reff454_op in H. discriminate H. Qed.

Lemma reff454_not3281 : ~ @Equation3281 Fin4 reff454_inst.
Proof. unfold Equation3281. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff454_inst, reff454_op in H. discriminate H. Qed.

Lemma reff454_not3308 : ~ @Equation3308 Fin4 reff454_inst.
Proof. unfold Equation3308. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff454_inst, reff454_op in H. discriminate H. Qed.

Lemma reff454_not3309 : ~ @Equation3309 Fin4 reff454_inst.
Proof. unfold Equation3309. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff454_inst, reff454_op in H. discriminate H. Qed.

Lemma reff454_not3315 : ~ @Equation3315 Fin4 reff454_inst.
Proof. unfold Equation3315. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff454_inst, reff454_op in H. discriminate H. Qed.

Lemma reff454_not3316 : ~ @Equation3316 Fin4 reff454_inst.
Proof. unfold Equation3316. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff454_inst, reff454_op in H. discriminate H. Qed.

Lemma reff454_not3318 : ~ @Equation3318 Fin4 reff454_inst.
Proof. unfold Equation3318. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff454_inst, reff454_op in H. discriminate H. Qed.

Lemma reff454_not3342 : ~ @Equation3342 Fin4 reff454_inst.
Proof. unfold Equation3342. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff454_inst, reff454_op in H. discriminate H. Qed.

Lemma reff454_not3343 : ~ @Equation3343 Fin4 reff454_inst.
Proof. unfold Equation3343. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff454_inst, reff454_op in H. discriminate H. Qed.

Lemma reff454_not3345 : ~ @Equation3345 Fin4 reff454_inst.
Proof. unfold Equation3345. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff454_inst, reff454_op in H. discriminate H. Qed.

Lemma reff454_not3352 : ~ @Equation3352 Fin4 reff454_inst.
Proof. unfold Equation3352. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff454_inst, reff454_op in H. discriminate H. Qed.

Lemma reff454_not3456 : ~ @Equation3456 Fin4 reff454_inst.
Proof. unfold Equation3456. intro H. specialize (H F4_1). unfold magma_op, reff454_inst, reff454_op in H. discriminate H. Qed.

Lemma reff454_not3659 : ~ @Equation3659 Fin4 reff454_inst.
Proof. unfold Equation3659. intro H. specialize (H F4_1). unfold magma_op, reff454_inst, reff454_op in H. discriminate H. Qed.

Lemma reff454_not3864 : ~ @Equation3864 Fin4 reff454_inst.
Proof. unfold Equation3864. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff454_inst, reff454_op in H. discriminate H. Qed.

Lemma reff454_not3865 : ~ @Equation3865 Fin4 reff454_inst.
Proof. unfold Equation3865. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff454_inst, reff454_op in H. discriminate H. Qed.

Lemma reff454_not3867 : ~ @Equation3867 Fin4 reff454_inst.
Proof. unfold Equation3867. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff454_inst, reff454_op in H. discriminate H. Qed.

Lemma reff454_not3870 : ~ @Equation3870 Fin4 reff454_inst.
Proof. unfold Equation3870. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff454_inst, reff454_op in H. discriminate H. Qed.

Lemma reff454_not3871 : ~ @Equation3871 Fin4 reff454_inst.
Proof. unfold Equation3871. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff454_inst, reff454_op in H. discriminate H. Qed.

Lemma reff454_not3877 : ~ @Equation3877 Fin4 reff454_inst.
Proof. unfold Equation3877. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff454_inst, reff454_op in H. discriminate H. Qed.

Lemma reff454_not3880 : ~ @Equation3880 Fin4 reff454_inst.
Proof. unfold Equation3880. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff454_inst, reff454_op in H. discriminate H. Qed.

Lemma reff454_not3881 : ~ @Equation3881 Fin4 reff454_inst.
Proof. unfold Equation3881. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff454_inst, reff454_op in H. discriminate H. Qed.

Lemma reff454_not3888 : ~ @Equation3888 Fin4 reff454_inst.
Proof. unfold Equation3888. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff454_inst, reff454_op in H. discriminate H. Qed.

Lemma reff454_not3890 : ~ @Equation3890 Fin4 reff454_inst.
Proof. unfold Equation3890. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff454_inst, reff454_op in H. discriminate H. Qed.

Lemma reff454_not3917 : ~ @Equation3917 Fin4 reff454_inst.
Proof. unfold Equation3917. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff454_inst, reff454_op in H. discriminate H. Qed.

Lemma reff454_not3918 : ~ @Equation3918 Fin4 reff454_inst.
Proof. unfold Equation3918. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff454_inst, reff454_op in H. discriminate H. Qed.

Lemma reff454_not3925 : ~ @Equation3925 Fin4 reff454_inst.
Proof. unfold Equation3925. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff454_inst, reff454_op in H. discriminate H. Qed.

Lemma reff454_not3927 : ~ @Equation3927 Fin4 reff454_inst.
Proof. unfold Equation3927. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff454_inst, reff454_op in H. discriminate H. Qed.

Lemma reff454_not3928 : ~ @Equation3928 Fin4 reff454_inst.
Proof. unfold Equation3928. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff454_inst, reff454_op in H. discriminate H. Qed.

Lemma reff454_not3952 : ~ @Equation3952 Fin4 reff454_inst.
Proof. unfold Equation3952. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff454_inst, reff454_op in H. discriminate H. Qed.

Lemma reff454_not3954 : ~ @Equation3954 Fin4 reff454_inst.
Proof. unfold Equation3954. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff454_inst, reff454_op in H. discriminate H. Qed.

Lemma reff454_not3955 : ~ @Equation3955 Fin4 reff454_inst.
Proof. unfold Equation3955. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff454_inst, reff454_op in H. discriminate H. Qed.

Lemma reff454_not3961 : ~ @Equation3961 Fin4 reff454_inst.
Proof. unfold Equation3961. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff454_inst, reff454_op in H. discriminate H. Qed.

Lemma reff454_not3964 : ~ @Equation3964 Fin4 reff454_inst.
Proof. unfold Equation3964. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff454_inst, reff454_op in H. discriminate H. Qed.

Lemma reff454_not4065 : ~ @Equation4065 Fin4 reff454_inst.
Proof. unfold Equation4065. intro H. specialize (H F4_1). unfold magma_op, reff454_inst, reff454_op in H. discriminate H. Qed.

Lemma reff454_not4268 : ~ @Equation4268 Fin4 reff454_inst.
Proof. unfold Equation4268. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff454_inst, reff454_op in H. discriminate H. Qed.

Lemma reff454_not4269 : ~ @Equation4269 Fin4 reff454_inst.
Proof. unfold Equation4269. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff454_inst, reff454_op in H. discriminate H. Qed.

Lemma reff454_not4270 : ~ @Equation4270 Fin4 reff454_inst.
Proof. unfold Equation4270. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff454_inst, reff454_op in H. discriminate H. Qed.

Lemma reff454_not4272 : ~ @Equation4272 Fin4 reff454_inst.
Proof. unfold Equation4272. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff454_inst, reff454_op in H. discriminate H. Qed.

Lemma reff454_not4273 : ~ @Equation4273 Fin4 reff454_inst.
Proof. unfold Equation4273. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff454_inst, reff454_op in H. discriminate H. Qed.

Lemma reff454_not4276 : ~ @Equation4276 Fin4 reff454_inst.
Proof. unfold Equation4276. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff454_inst, reff454_op in H. discriminate H. Qed.

Lemma reff454_not4283 : ~ @Equation4283 Fin4 reff454_inst.
Proof. unfold Equation4283. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff454_inst, reff454_op in H. discriminate H. Qed.

Lemma reff454_not4284 : ~ @Equation4284 Fin4 reff454_inst.
Proof. unfold Equation4284. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff454_inst, reff454_op in H. discriminate H. Qed.

Lemma reff454_not4290 : ~ @Equation4290 Fin4 reff454_inst.
Proof. unfold Equation4290. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff454_inst, reff454_op in H. discriminate H. Qed.

Lemma reff454_not4291 : ~ @Equation4291 Fin4 reff454_inst.
Proof. unfold Equation4291. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff454_inst, reff454_op in H. discriminate H. Qed.

Lemma reff454_not4293 : ~ @Equation4293 Fin4 reff454_inst.
Proof. unfold Equation4293. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff454_inst, reff454_op in H. discriminate H. Qed.

Lemma reff454_not4314 : ~ @Equation4314 Fin4 reff454_inst.
Proof. unfold Equation4314. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff454_inst, reff454_op in H. discriminate H. Qed.

Lemma reff454_not4321 : ~ @Equation4321 Fin4 reff454_inst.
Proof. unfold Equation4321. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff454_inst, reff454_op in H. discriminate H. Qed.

Lemma reff454_not4343 : ~ @Equation4343 Fin4 reff454_inst.
Proof. unfold Equation4343. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff454_inst, reff454_op in H. discriminate H. Qed.

Lemma reff454_not4380 : ~ @Equation4380 Fin4 reff454_inst.
Proof. unfold Equation4380. intro H. specialize (H F4_1). unfold magma_op, reff454_inst, reff454_op in H. discriminate H. Qed.

Lemma reff454_not4583 : ~ @Equation4583 Fin4 reff454_inst.
Proof. unfold Equation4583. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff454_inst, reff454_op in H. discriminate H. Qed.

Lemma reff454_not4584 : ~ @Equation4584 Fin4 reff454_inst.
Proof. unfold Equation4584. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff454_inst, reff454_op in H. discriminate H. Qed.

Lemma reff454_not4585 : ~ @Equation4585 Fin4 reff454_inst.
Proof. unfold Equation4585. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff454_inst, reff454_op in H. discriminate H. Qed.

Lemma reff454_not4587 : ~ @Equation4587 Fin4 reff454_inst.
Proof. unfold Equation4587. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff454_inst, reff454_op in H. discriminate H. Qed.

Lemma reff454_not4590 : ~ @Equation4590 Fin4 reff454_inst.
Proof. unfold Equation4590. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff454_inst, reff454_op in H. discriminate H. Qed.

Lemma reff454_not4591 : ~ @Equation4591 Fin4 reff454_inst.
Proof. unfold Equation4591. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff454_inst, reff454_op in H. discriminate H. Qed.

Lemma reff454_not4598 : ~ @Equation4598 Fin4 reff454_inst.
Proof. unfold Equation4598. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff454_inst, reff454_op in H. discriminate H. Qed.

Lemma reff454_not4599 : ~ @Equation4599 Fin4 reff454_inst.
Proof. unfold Equation4599. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff454_inst, reff454_op in H. discriminate H. Qed.

Lemma reff454_not4606 : ~ @Equation4606 Fin4 reff454_inst.
Proof. unfold Equation4606. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff454_inst, reff454_op in H. discriminate H. Qed.

Lemma reff454_not4608 : ~ @Equation4608 Fin4 reff454_inst.
Proof. unfold Equation4608. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff454_inst, reff454_op in H. discriminate H. Qed.

Lemma reff454_not4629 : ~ @Equation4629 Fin4 reff454_inst.
Proof. unfold Equation4629. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff454_inst, reff454_op in H. discriminate H. Qed.

Lemma reff454_not4635 : ~ @Equation4635 Fin4 reff454_inst.
Proof. unfold Equation4635. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff454_inst, reff454_op in H. discriminate H. Qed.

Lemma reff454_not4636 : ~ @Equation4636 Fin4 reff454_inst.
Proof. unfold Equation4636. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff454_inst, reff454_op in H. discriminate H. Qed.

Lemma reff454_not4658 : ~ @Equation4658 Fin4 reff454_inst.
Proof. unfold Equation4658. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff454_inst, reff454_op in H. discriminate H. Qed.

(** ---- reff46 (Fin3) ---- *)

Definition reff46_op (x y : Fin3) : Fin3 :=
  match x, y with
  | F3_0, F3_0 => F3_0 | F3_0, F3_1 => F3_1 | F3_0, F3_2 => F3_1
  | F3_1, F3_0 => F3_1 | F3_1, F3_1 => F3_0 | F3_1, F3_2 => F3_1
  | F3_2, F3_0 => F3_1 | F3_2, F3_1 => F3_1 | F3_2, F3_2 => F3_0
  end.

#[local] Instance reff46_inst : Magma Fin3 := {| magma_op := reff46_op |}.

Lemma reff46_sat43 : @Equation43 Fin3 reff46_inst.
Proof. unfold Equation43, magma_op, reff46_inst, reff46_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff46_sat3703 : @Equation3703 Fin3 reff46_inst.
Proof. unfold Equation3703, magma_op, reff46_inst, reff46_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff46_sat3729 : @Equation3729 Fin3 reff46_inst.
Proof. unfold Equation3729, magma_op, reff46_inst, reff46_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff46_sat3756 : @Equation3756 Fin3 reff46_inst.
Proof. unfold Equation3756, magma_op, reff46_inst, reff46_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff46_sat3820 : @Equation3820 Fin3 reff46_inst.
Proof. unfold Equation3820, magma_op, reff46_inst, reff46_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff46_sat3823 : @Equation3823 Fin3 reff46_inst.
Proof. unfold Equation3823, magma_op, reff46_inst, reff46_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff46_sat4497 : @Equation4497 Fin3 reff46_inst.
Proof. unfold Equation4497, magma_op, reff46_inst, reff46_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff46_not47 : ~ @Equation47 Fin3 reff46_inst.
Proof. unfold Equation47. intro H. specialize (H F3_1). unfold magma_op, reff46_inst, reff46_op in H. discriminate H. Qed.

Lemma reff46_not99 : ~ @Equation99 Fin3 reff46_inst.
Proof. unfold Equation99. intro H. specialize (H F3_1). unfold magma_op, reff46_inst, reff46_op in H. discriminate H. Qed.

Lemma reff46_not151 : ~ @Equation151 Fin3 reff46_inst.
Proof. unfold Equation151. intro H. specialize (H F3_1). unfold magma_op, reff46_inst, reff46_op in H. discriminate H. Qed.

Lemma reff46_not203 : ~ @Equation203 Fin3 reff46_inst.
Proof. unfold Equation203. intro H. specialize (H F3_1). unfold magma_op, reff46_inst, reff46_op in H. discriminate H. Qed.

Lemma reff46_not255 : ~ @Equation255 Fin3 reff46_inst.
Proof. unfold Equation255. intro H. specialize (H F3_1). unfold magma_op, reff46_inst, reff46_op in H. discriminate H. Qed.

Lemma reff46_not411 : ~ @Equation411 Fin3 reff46_inst.
Proof. unfold Equation411. intro H. specialize (H F3_2). unfold magma_op, reff46_inst, reff46_op in H. discriminate H. Qed.

Lemma reff46_not614 : ~ @Equation614 Fin3 reff46_inst.
Proof. unfold Equation614. intro H. specialize (H F3_2). unfold magma_op, reff46_inst, reff46_op in H. discriminate H. Qed.

Lemma reff46_not817 : ~ @Equation817 Fin3 reff46_inst.
Proof. unfold Equation817. intro H. specialize (H F3_2). unfold magma_op, reff46_inst, reff46_op in H. discriminate H. Qed.

Lemma reff46_not1020 : ~ @Equation1020 Fin3 reff46_inst.
Proof. unfold Equation1020. intro H. specialize (H F3_2). unfold magma_op, reff46_inst, reff46_op in H. discriminate H. Qed.

Lemma reff46_not1223 : ~ @Equation1223 Fin3 reff46_inst.
Proof. unfold Equation1223. intro H. specialize (H F3_2). unfold magma_op, reff46_inst, reff46_op in H. discriminate H. Qed.

Lemma reff46_not1426 : ~ @Equation1426 Fin3 reff46_inst.
Proof. unfold Equation1426. intro H. specialize (H F3_2). unfold magma_op, reff46_inst, reff46_op in H. discriminate H. Qed.

Lemma reff46_not1629 : ~ @Equation1629 Fin3 reff46_inst.
Proof. unfold Equation1629. intro H. specialize (H F3_2). unfold magma_op, reff46_inst, reff46_op in H. discriminate H. Qed.

Lemma reff46_not1832 : ~ @Equation1832 Fin3 reff46_inst.
Proof. unfold Equation1832. intro H. specialize (H F3_2). unfold magma_op, reff46_inst, reff46_op in H. discriminate H. Qed.

Lemma reff46_not2035 : ~ @Equation2035 Fin3 reff46_inst.
Proof. unfold Equation2035. intro H. specialize (H F3_2). unfold magma_op, reff46_inst, reff46_op in H. discriminate H. Qed.

Lemma reff46_not2238 : ~ @Equation2238 Fin3 reff46_inst.
Proof. unfold Equation2238. intro H. specialize (H F3_2). unfold magma_op, reff46_inst, reff46_op in H. discriminate H. Qed.

Lemma reff46_not2441 : ~ @Equation2441 Fin3 reff46_inst.
Proof. unfold Equation2441. intro H. specialize (H F3_2). unfold magma_op, reff46_inst, reff46_op in H. discriminate H. Qed.

Lemma reff46_not2644 : ~ @Equation2644 Fin3 reff46_inst.
Proof. unfold Equation2644. intro H. specialize (H F3_2). unfold magma_op, reff46_inst, reff46_op in H. discriminate H. Qed.

Lemma reff46_not2847 : ~ @Equation2847 Fin3 reff46_inst.
Proof. unfold Equation2847. intro H. specialize (H F3_2). unfold magma_op, reff46_inst, reff46_op in H. discriminate H. Qed.

Lemma reff46_not3050 : ~ @Equation3050 Fin3 reff46_inst.
Proof. unfold Equation3050. intro H. specialize (H F3_2). unfold magma_op, reff46_inst, reff46_op in H. discriminate H. Qed.

Lemma reff46_not3253 : ~ @Equation3253 Fin3 reff46_inst.
Proof. unfold Equation3253. intro H. specialize (H F3_2). unfold magma_op, reff46_inst, reff46_op in H. discriminate H. Qed.

Lemma reff46_not3456 : ~ @Equation3456 Fin3 reff46_inst.
Proof. unfold Equation3456. intro H. specialize (H F3_2). unfold magma_op, reff46_inst, reff46_op in H. discriminate H. Qed.

Lemma reff46_not3660 : ~ @Equation3660 Fin3 reff46_inst.
Proof. unfold Equation3660. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff46_inst, reff46_op in H. discriminate H. Qed.

Lemma reff46_not3661 : ~ @Equation3661 Fin3 reff46_inst.
Proof. unfold Equation3661. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff46_inst, reff46_op in H. discriminate H. Qed.

Lemma reff46_not3664 : ~ @Equation3664 Fin3 reff46_inst.
Proof. unfold Equation3664. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff46_inst, reff46_op in H. discriminate H. Qed.

Lemma reff46_not3668 : ~ @Equation3668 Fin3 reff46_inst.
Proof. unfold Equation3668. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff46_inst, reff46_op in H. discriminate H. Qed.

Lemma reff46_not3674 : ~ @Equation3674 Fin3 reff46_inst.
Proof. unfold Equation3674. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff46_inst, reff46_op in H. discriminate H. Qed.

Lemma reff46_not3678 : ~ @Equation3678 Fin3 reff46_inst.
Proof. unfold Equation3678. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff46_inst, reff46_op in H. discriminate H. Qed.

Lemma reff46_not3685 : ~ @Equation3685 Fin3 reff46_inst.
Proof. unfold Equation3685. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff46_inst, reff46_op in H. discriminate H. Qed.

Lemma reff46_not3687 : ~ @Equation3687 Fin3 reff46_inst.
Proof. unfold Equation3687. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff46_inst, reff46_op in H. discriminate H. Qed.

Lemma reff46_not3722 : ~ @Equation3722 Fin3 reff46_inst.
Proof. unfold Equation3722. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff46_inst, reff46_op in H. discriminate H. Qed.

Lemma reff46_not3724 : ~ @Equation3724 Fin3 reff46_inst.
Proof. unfold Equation3724. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff46_inst, reff46_op in H. discriminate H. Qed.

Lemma reff46_not3737 : ~ @Equation3737 Fin3 reff46_inst.
Proof. unfold Equation3737. intro H. specialize (H F3_0 F3_1 F3_2). unfold magma_op, reff46_inst, reff46_op in H. discriminate H. Qed.

Lemma reff46_not3740 : ~ @Equation3740 Fin3 reff46_inst.
Proof. unfold Equation3740. intro H. specialize (H F3_0 F3_1 F3_2). unfold magma_op, reff46_inst, reff46_op in H. discriminate H. Qed.

Lemma reff46_not3749 : ~ @Equation3749 Fin3 reff46_inst.
Proof. unfold Equation3749. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff46_inst, reff46_op in H. discriminate H. Qed.

Lemma reff46_not3751 : ~ @Equation3751 Fin3 reff46_inst.
Proof. unfold Equation3751. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff46_inst, reff46_op in H. discriminate H. Qed.

Lemma reff46_not3791 : ~ @Equation3791 Fin3 reff46_inst.
Proof. unfold Equation3791. intro H. specialize (H F3_0 F3_1 F3_2). unfold magma_op, reff46_inst, reff46_op in H. discriminate H. Qed.

Lemma reff46_not3794 : ~ @Equation3794 Fin3 reff46_inst.
Proof. unfold Equation3794. intro H. specialize (H F3_0 F3_1 F3_2). unfold magma_op, reff46_inst, reff46_op in H. discriminate H. Qed.

Lemma reff46_not3862 : ~ @Equation3862 Fin3 reff46_inst.
Proof. unfold Equation3862. intro H. specialize (H F3_2). unfold magma_op, reff46_inst, reff46_op in H. discriminate H. Qed.

Lemma reff46_not4065 : ~ @Equation4065 Fin3 reff46_inst.
Proof. unfold Equation4065. intro H. specialize (H F3_2). unfold magma_op, reff46_inst, reff46_op in H. discriminate H. Qed.

Lemma reff46_not4268 : ~ @Equation4268 Fin3 reff46_inst.
Proof. unfold Equation4268. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff46_inst, reff46_op in H. discriminate H. Qed.

Lemma reff46_not4269 : ~ @Equation4269 Fin3 reff46_inst.
Proof. unfold Equation4269. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff46_inst, reff46_op in H. discriminate H. Qed.

Lemma reff46_not4272 : ~ @Equation4272 Fin3 reff46_inst.
Proof. unfold Equation4272. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff46_inst, reff46_op in H. discriminate H. Qed.

Lemma reff46_not4273 : ~ @Equation4273 Fin3 reff46_inst.
Proof. unfold Equation4273. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff46_inst, reff46_op in H. discriminate H. Qed.

Lemma reff46_not4275 : ~ @Equation4275 Fin3 reff46_inst.
Proof. unfold Equation4275. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff46_inst, reff46_op in H. discriminate H. Qed.

Lemma reff46_not4276 : ~ @Equation4276 Fin3 reff46_inst.
Proof. unfold Equation4276. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff46_inst, reff46_op in H. discriminate H. Qed.

Lemma reff46_not4284 : ~ @Equation4284 Fin3 reff46_inst.
Proof. unfold Equation4284. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff46_inst, reff46_op in H. discriminate H. Qed.

Lemma reff46_not4290 : ~ @Equation4290 Fin3 reff46_inst.
Proof. unfold Equation4290. intro H. specialize (H F3_1 F3_2). unfold magma_op, reff46_inst, reff46_op in H. discriminate H. Qed.

Lemma reff46_not4291 : ~ @Equation4291 Fin3 reff46_inst.
Proof. unfold Equation4291. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff46_inst, reff46_op in H. discriminate H. Qed.

Lemma reff46_not4293 : ~ @Equation4293 Fin3 reff46_inst.
Proof. unfold Equation4293. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff46_inst, reff46_op in H. discriminate H. Qed.

Lemma reff46_not4314 : ~ @Equation4314 Fin3 reff46_inst.
Proof. unfold Equation4314. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff46_inst, reff46_op in H. discriminate H. Qed.

Lemma reff46_not4320 : ~ @Equation4320 Fin3 reff46_inst.
Proof. unfold Equation4320. intro H. specialize (H F3_1 F3_2). unfold magma_op, reff46_inst, reff46_op in H. discriminate H. Qed.

Lemma reff46_not4321 : ~ @Equation4321 Fin3 reff46_inst.
Proof. unfold Equation4321. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff46_inst, reff46_op in H. discriminate H. Qed.

Lemma reff46_not4343 : ~ @Equation4343 Fin3 reff46_inst.
Proof. unfold Equation4343. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff46_inst, reff46_op in H. discriminate H. Qed.

Lemma reff46_not4396 : ~ @Equation4396 Fin3 reff46_inst.
Proof. unfold Equation4396. intro H. specialize (H F3_1 F3_2). unfold magma_op, reff46_inst, reff46_op in H. discriminate H. Qed.

Lemma reff46_not4399 : ~ @Equation4399 Fin3 reff46_inst.
Proof. unfold Equation4399. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff46_inst, reff46_op in H. discriminate H. Qed.

Lemma reff46_not4406 : ~ @Equation4406 Fin3 reff46_inst.
Proof. unfold Equation4406. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff46_inst, reff46_op in H. discriminate H. Qed.

Lemma reff46_not4408 : ~ @Equation4408 Fin3 reff46_inst.
Proof. unfold Equation4408. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff46_inst, reff46_op in H. discriminate H. Qed.

Lemma reff46_not4433 : ~ @Equation4433 Fin3 reff46_inst.
Proof. unfold Equation4433. intro H. specialize (H F3_1 F3_2). unfold magma_op, reff46_inst, reff46_op in H. discriminate H. Qed.

Lemma reff46_not4436 : ~ @Equation4436 Fin3 reff46_inst.
Proof. unfold Equation4436. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff46_inst, reff46_op in H. discriminate H. Qed.

Lemma reff46_not4443 : ~ @Equation4443 Fin3 reff46_inst.
Proof. unfold Equation4443. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff46_inst, reff46_op in H. discriminate H. Qed.

Lemma reff46_not4445 : ~ @Equation4445 Fin3 reff46_inst.
Proof. unfold Equation4445. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff46_inst, reff46_op in H. discriminate H. Qed.

Lemma reff46_not4470 : ~ @Equation4470 Fin3 reff46_inst.
Proof. unfold Equation4470. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff46_inst, reff46_op in H. discriminate H. Qed.

Lemma reff46_not4472 : ~ @Equation4472 Fin3 reff46_inst.
Proof. unfold Equation4472. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff46_inst, reff46_op in H. discriminate H. Qed.

Lemma reff46_not4473 : ~ @Equation4473 Fin3 reff46_inst.
Proof. unfold Equation4473. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff46_inst, reff46_op in H. discriminate H. Qed.

Lemma reff46_not4479 : ~ @Equation4479 Fin3 reff46_inst.
Proof. unfold Equation4479. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff46_inst, reff46_op in H. discriminate H. Qed.

Lemma reff46_not4480 : ~ @Equation4480 Fin3 reff46_inst.
Proof. unfold Equation4480. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff46_inst, reff46_op in H. discriminate H. Qed.

Lemma reff46_not4583 : ~ @Equation4583 Fin3 reff46_inst.
Proof. unfold Equation4583. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff46_inst, reff46_op in H. discriminate H. Qed.

Lemma reff46_not4584 : ~ @Equation4584 Fin3 reff46_inst.
Proof. unfold Equation4584. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff46_inst, reff46_op in H. discriminate H. Qed.

Lemma reff46_not4585 : ~ @Equation4585 Fin3 reff46_inst.
Proof. unfold Equation4585. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff46_inst, reff46_op in H. discriminate H. Qed.

Lemma reff46_not4587 : ~ @Equation4587 Fin3 reff46_inst.
Proof. unfold Equation4587. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff46_inst, reff46_op in H. discriminate H. Qed.

Lemma reff46_not4588 : ~ @Equation4588 Fin3 reff46_inst.
Proof. unfold Equation4588. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff46_inst, reff46_op in H. discriminate H. Qed.

Lemma reff46_not4591 : ~ @Equation4591 Fin3 reff46_inst.
Proof. unfold Equation4591. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff46_inst, reff46_op in H. discriminate H. Qed.

Lemma reff46_not4598 : ~ @Equation4598 Fin3 reff46_inst.
Proof. unfold Equation4598. intro H. specialize (H F3_1 F3_2). unfold magma_op, reff46_inst, reff46_op in H. discriminate H. Qed.

Lemma reff46_not4599 : ~ @Equation4599 Fin3 reff46_inst.
Proof. unfold Equation4599. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff46_inst, reff46_op in H. discriminate H. Qed.

Lemma reff46_not4605 : ~ @Equation4605 Fin3 reff46_inst.
Proof. unfold Equation4605. intro H. specialize (H F3_1 F3_2). unfold magma_op, reff46_inst, reff46_op in H. discriminate H. Qed.

Lemma reff46_not4606 : ~ @Equation4606 Fin3 reff46_inst.
Proof. unfold Equation4606. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff46_inst, reff46_op in H. discriminate H. Qed.

Lemma reff46_not4608 : ~ @Equation4608 Fin3 reff46_inst.
Proof. unfold Equation4608. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff46_inst, reff46_op in H. discriminate H. Qed.

Lemma reff46_not4629 : ~ @Equation4629 Fin3 reff46_inst.
Proof. unfold Equation4629. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff46_inst, reff46_op in H. discriminate H. Qed.

Lemma reff46_not4636 : ~ @Equation4636 Fin3 reff46_inst.
Proof. unfold Equation4636. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff46_inst, reff46_op in H. discriminate H. Qed.

Lemma reff46_not4658 : ~ @Equation4658 Fin3 reff46_inst.
Proof. unfold Equation4658. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff46_inst, reff46_op in H. discriminate H. Qed.

(** ---- reff470 (Fin4) ---- *)

Definition reff470_op (x y : Fin4) : Fin4 :=
  match x, y with
  | F4_0, F4_0 => F4_0 | F4_0, F4_1 => F4_2 | F4_0, F4_2 => F4_0 | F4_0, F4_3 => F4_2
  | F4_1, F4_0 => F4_0 | F4_1, F4_1 => F4_0 | F4_1, F4_2 => F4_0 | F4_1, F4_3 => F4_0
  | F4_2, F4_0 => F4_0 | F4_2, F4_1 => F4_2 | F4_2, F4_2 => F4_0 | F4_2, F4_3 => F4_2
  | F4_3, F4_0 => F4_0 | F4_3, F4_1 => F4_0 | F4_3, F4_2 => F4_0 | F4_3, F4_3 => F4_0
  end.

#[local] Instance reff470_inst : Magma Fin4 := {| magma_op := reff470_op |}.

Lemma reff470_sat314 : @Equation314 Fin4 reff470_inst.
Proof. unfold Equation314, magma_op, reff470_inst, reff470_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff470_sat4593 : @Equation4593 Fin4 reff470_inst.
Proof. unfold Equation4593, magma_op, reff470_inst, reff470_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff470_not47 : ~ @Equation47 Fin4 reff470_inst.
Proof. unfold Equation47. intro H. specialize (H F4_1). unfold magma_op, reff470_inst, reff470_op in H. discriminate H. Qed.

Lemma reff470_not99 : ~ @Equation99 Fin4 reff470_inst.
Proof. unfold Equation99. intro H. specialize (H F4_1). unfold magma_op, reff470_inst, reff470_op in H. discriminate H. Qed.

Lemma reff470_not151 : ~ @Equation151 Fin4 reff470_inst.
Proof. unfold Equation151. intro H. specialize (H F4_1). unfold magma_op, reff470_inst, reff470_op in H. discriminate H. Qed.

Lemma reff470_not203 : ~ @Equation203 Fin4 reff470_inst.
Proof. unfold Equation203. intro H. specialize (H F4_1). unfold magma_op, reff470_inst, reff470_op in H. discriminate H. Qed.

Lemma reff470_not255 : ~ @Equation255 Fin4 reff470_inst.
Proof. unfold Equation255. intro H. specialize (H F4_1). unfold magma_op, reff470_inst, reff470_op in H. discriminate H. Qed.

Lemma reff470_not411 : ~ @Equation411 Fin4 reff470_inst.
Proof. unfold Equation411. intro H. specialize (H F4_1). unfold magma_op, reff470_inst, reff470_op in H. discriminate H. Qed.

Lemma reff470_not614 : ~ @Equation614 Fin4 reff470_inst.
Proof. unfold Equation614. intro H. specialize (H F4_1). unfold magma_op, reff470_inst, reff470_op in H. discriminate H. Qed.

Lemma reff470_not817 : ~ @Equation817 Fin4 reff470_inst.
Proof. unfold Equation817. intro H. specialize (H F4_1). unfold magma_op, reff470_inst, reff470_op in H. discriminate H. Qed.

Lemma reff470_not1020 : ~ @Equation1020 Fin4 reff470_inst.
Proof. unfold Equation1020. intro H. specialize (H F4_1). unfold magma_op, reff470_inst, reff470_op in H. discriminate H. Qed.

Lemma reff470_not1223 : ~ @Equation1223 Fin4 reff470_inst.
Proof. unfold Equation1223. intro H. specialize (H F4_1). unfold magma_op, reff470_inst, reff470_op in H. discriminate H. Qed.

Lemma reff470_not1426 : ~ @Equation1426 Fin4 reff470_inst.
Proof. unfold Equation1426. intro H. specialize (H F4_1). unfold magma_op, reff470_inst, reff470_op in H. discriminate H. Qed.

Lemma reff470_not1629 : ~ @Equation1629 Fin4 reff470_inst.
Proof. unfold Equation1629. intro H. specialize (H F4_1). unfold magma_op, reff470_inst, reff470_op in H. discriminate H. Qed.

Lemma reff470_not1832 : ~ @Equation1832 Fin4 reff470_inst.
Proof. unfold Equation1832. intro H. specialize (H F4_1). unfold magma_op, reff470_inst, reff470_op in H. discriminate H. Qed.

Lemma reff470_not2035 : ~ @Equation2035 Fin4 reff470_inst.
Proof. unfold Equation2035. intro H. specialize (H F4_1). unfold magma_op, reff470_inst, reff470_op in H. discriminate H. Qed.

Lemma reff470_not2238 : ~ @Equation2238 Fin4 reff470_inst.
Proof. unfold Equation2238. intro H. specialize (H F4_1). unfold magma_op, reff470_inst, reff470_op in H. discriminate H. Qed.

Lemma reff470_not2441 : ~ @Equation2441 Fin4 reff470_inst.
Proof. unfold Equation2441. intro H. specialize (H F4_1). unfold magma_op, reff470_inst, reff470_op in H. discriminate H. Qed.

Lemma reff470_not2644 : ~ @Equation2644 Fin4 reff470_inst.
Proof. unfold Equation2644. intro H. specialize (H F4_1). unfold magma_op, reff470_inst, reff470_op in H. discriminate H. Qed.

Lemma reff470_not2847 : ~ @Equation2847 Fin4 reff470_inst.
Proof. unfold Equation2847. intro H. specialize (H F4_1). unfold magma_op, reff470_inst, reff470_op in H. discriminate H. Qed.

Lemma reff470_not3050 : ~ @Equation3050 Fin4 reff470_inst.
Proof. unfold Equation3050. intro H. specialize (H F4_1). unfold magma_op, reff470_inst, reff470_op in H. discriminate H. Qed.

Lemma reff470_not3306 : ~ @Equation3306 Fin4 reff470_inst.
Proof. unfold Equation3306. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff470_inst, reff470_op in H. discriminate H. Qed.

Lemma reff470_not3308 : ~ @Equation3308 Fin4 reff470_inst.
Proof. unfold Equation3308. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff470_inst, reff470_op in H. discriminate H. Qed.

Lemma reff470_not3309 : ~ @Equation3309 Fin4 reff470_inst.
Proof. unfold Equation3309. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff470_inst, reff470_op in H. discriminate H. Qed.

Lemma reff470_not3315 : ~ @Equation3315 Fin4 reff470_inst.
Proof. unfold Equation3315. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff470_inst, reff470_op in H. discriminate H. Qed.

Lemma reff470_not3316 : ~ @Equation3316 Fin4 reff470_inst.
Proof. unfold Equation3316. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff470_inst, reff470_op in H. discriminate H. Qed.

Lemma reff470_not3318 : ~ @Equation3318 Fin4 reff470_inst.
Proof. unfold Equation3318. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff470_inst, reff470_op in H. discriminate H. Qed.

Lemma reff470_not3319 : ~ @Equation3319 Fin4 reff470_inst.
Proof. unfold Equation3319. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff470_inst, reff470_op in H. discriminate H. Qed.

Lemma reff470_not3342 : ~ @Equation3342 Fin4 reff470_inst.
Proof. unfold Equation3342. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff470_inst, reff470_op in H. discriminate H. Qed.

Lemma reff470_not3343 : ~ @Equation3343 Fin4 reff470_inst.
Proof. unfold Equation3343. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff470_inst, reff470_op in H. discriminate H. Qed.

Lemma reff470_not3345 : ~ @Equation3345 Fin4 reff470_inst.
Proof. unfold Equation3345. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff470_inst, reff470_op in H. discriminate H. Qed.

Lemma reff470_not3346 : ~ @Equation3346 Fin4 reff470_inst.
Proof. unfold Equation3346. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff470_inst, reff470_op in H. discriminate H. Qed.

Lemma reff470_not3352 : ~ @Equation3352 Fin4 reff470_inst.
Proof. unfold Equation3352. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff470_inst, reff470_op in H. discriminate H. Qed.

Lemma reff470_not3353 : ~ @Equation3353 Fin4 reff470_inst.
Proof. unfold Equation3353. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff470_inst, reff470_op in H. discriminate H. Qed.

Lemma reff470_not3509 : ~ @Equation3509 Fin4 reff470_inst.
Proof. unfold Equation3509. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff470_inst, reff470_op in H. discriminate H. Qed.

Lemma reff470_not3511 : ~ @Equation3511 Fin4 reff470_inst.
Proof. unfold Equation3511. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff470_inst, reff470_op in H. discriminate H. Qed.

Lemma reff470_not3512 : ~ @Equation3512 Fin4 reff470_inst.
Proof. unfold Equation3512. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff470_inst, reff470_op in H. discriminate H. Qed.

Lemma reff470_not3518 : ~ @Equation3518 Fin4 reff470_inst.
Proof. unfold Equation3518. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff470_inst, reff470_op in H. discriminate H. Qed.

Lemma reff470_not3519 : ~ @Equation3519 Fin4 reff470_inst.
Proof. unfold Equation3519. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff470_inst, reff470_op in H. discriminate H. Qed.

Lemma reff470_not3521 : ~ @Equation3521 Fin4 reff470_inst.
Proof. unfold Equation3521. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff470_inst, reff470_op in H. discriminate H. Qed.

Lemma reff470_not3522 : ~ @Equation3522 Fin4 reff470_inst.
Proof. unfold Equation3522. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff470_inst, reff470_op in H. discriminate H. Qed.

Lemma reff470_not3545 : ~ @Equation3545 Fin4 reff470_inst.
Proof. unfold Equation3545. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff470_inst, reff470_op in H. discriminate H. Qed.

Lemma reff470_not3546 : ~ @Equation3546 Fin4 reff470_inst.
Proof. unfold Equation3546. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff470_inst, reff470_op in H. discriminate H. Qed.

Lemma reff470_not3548 : ~ @Equation3548 Fin4 reff470_inst.
Proof. unfold Equation3548. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff470_inst, reff470_op in H. discriminate H. Qed.

Lemma reff470_not3549 : ~ @Equation3549 Fin4 reff470_inst.
Proof. unfold Equation3549. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff470_inst, reff470_op in H. discriminate H. Qed.

Lemma reff470_not3555 : ~ @Equation3555 Fin4 reff470_inst.
Proof. unfold Equation3555. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff470_inst, reff470_op in H. discriminate H. Qed.

Lemma reff470_not3558 : ~ @Equation3558 Fin4 reff470_inst.
Proof. unfold Equation3558. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff470_inst, reff470_op in H. discriminate H. Qed.

Lemma reff470_not3712 : ~ @Equation3712 Fin4 reff470_inst.
Proof. unfold Equation3712. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff470_inst, reff470_op in H. discriminate H. Qed.

Lemma reff470_not3714 : ~ @Equation3714 Fin4 reff470_inst.
Proof. unfold Equation3714. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff470_inst, reff470_op in H. discriminate H. Qed.

Lemma reff470_not3721 : ~ @Equation3721 Fin4 reff470_inst.
Proof. unfold Equation3721. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff470_inst, reff470_op in H. discriminate H. Qed.

Lemma reff470_not3722 : ~ @Equation3722 Fin4 reff470_inst.
Proof. unfold Equation3722. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff470_inst, reff470_op in H. discriminate H. Qed.

Lemma reff470_not3724 : ~ @Equation3724 Fin4 reff470_inst.
Proof. unfold Equation3724. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff470_inst, reff470_op in H. discriminate H. Qed.

Lemma reff470_not3725 : ~ @Equation3725 Fin4 reff470_inst.
Proof. unfold Equation3725. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff470_inst, reff470_op in H. discriminate H. Qed.

Lemma reff470_not3748 : ~ @Equation3748 Fin4 reff470_inst.
Proof. unfold Equation3748. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff470_inst, reff470_op in H. discriminate H. Qed.

Lemma reff470_not3749 : ~ @Equation3749 Fin4 reff470_inst.
Proof. unfold Equation3749. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff470_inst, reff470_op in H. discriminate H. Qed.

Lemma reff470_not3751 : ~ @Equation3751 Fin4 reff470_inst.
Proof. unfold Equation3751. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff470_inst, reff470_op in H. discriminate H. Qed.

Lemma reff470_not3752 : ~ @Equation3752 Fin4 reff470_inst.
Proof. unfold Equation3752. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff470_inst, reff470_op in H. discriminate H. Qed.

Lemma reff470_not3759 : ~ @Equation3759 Fin4 reff470_inst.
Proof. unfold Equation3759. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff470_inst, reff470_op in H. discriminate H. Qed.

Lemma reff470_not3761 : ~ @Equation3761 Fin4 reff470_inst.
Proof. unfold Equation3761. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff470_inst, reff470_op in H. discriminate H. Qed.

Lemma reff470_not3862 : ~ @Equation3862 Fin4 reff470_inst.
Proof. unfold Equation3862. intro H. specialize (H F4_1). unfold magma_op, reff470_inst, reff470_op in H. discriminate H. Qed.

Lemma reff470_not4065 : ~ @Equation4065 Fin4 reff470_inst.
Proof. unfold Equation4065. intro H. specialize (H F4_1). unfold magma_op, reff470_inst, reff470_op in H. discriminate H. Qed.

Lemma reff470_not4380 : ~ @Equation4380 Fin4 reff470_inst.
Proof. unfold Equation4380. intro H. specialize (H F4_1). unfold magma_op, reff470_inst, reff470_op in H. discriminate H. Qed.

Lemma reff470_not4583 : ~ @Equation4583 Fin4 reff470_inst.
Proof. unfold Equation4583. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff470_inst, reff470_op in H. discriminate H. Qed.

Lemma reff470_not4585 : ~ @Equation4585 Fin4 reff470_inst.
Proof. unfold Equation4585. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff470_inst, reff470_op in H. discriminate H. Qed.

Lemma reff470_not4588 : ~ @Equation4588 Fin4 reff470_inst.
Proof. unfold Equation4588. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff470_inst, reff470_op in H. discriminate H. Qed.

Lemma reff470_not4591 : ~ @Equation4591 Fin4 reff470_inst.
Proof. unfold Equation4591. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff470_inst, reff470_op in H. discriminate H. Qed.

Lemma reff470_not4598 : ~ @Equation4598 Fin4 reff470_inst.
Proof. unfold Equation4598. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff470_inst, reff470_op in H. discriminate H. Qed.

Lemma reff470_not4605 : ~ @Equation4605 Fin4 reff470_inst.
Proof. unfold Equation4605. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff470_inst, reff470_op in H. discriminate H. Qed.

Lemma reff470_not4608 : ~ @Equation4608 Fin4 reff470_inst.
Proof. unfold Equation4608. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff470_inst, reff470_op in H. discriminate H. Qed.

Lemma reff470_not4629 : ~ @Equation4629 Fin4 reff470_inst.
Proof. unfold Equation4629. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff470_inst, reff470_op in H. discriminate H. Qed.

Lemma reff470_not4636 : ~ @Equation4636 Fin4 reff470_inst.
Proof. unfold Equation4636. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff470_inst, reff470_op in H. discriminate H. Qed.

Lemma reff470_not4658 : ~ @Equation4658 Fin4 reff470_inst.
Proof. unfold Equation4658. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff470_inst, reff470_op in H. discriminate H. Qed.

(** ---- reff472 (Fin5) ---- *)

Definition reff472_op (x y : Fin5) : Fin5 :=
  match x, y with
  | F5_0, F5_0 => F5_0 | F5_0, F5_1 => F5_0 | F5_0, F5_2 => F5_0 | F5_0, F5_3 => F5_0 | F5_0, F5_4 => F5_0
  | F5_1, F5_0 => F5_3 | F5_1, F5_1 => F5_0 | F5_1, F5_2 => F5_2 | F5_1, F5_3 => F5_4 | F5_1, F5_4 => F5_1
  | F5_2, F5_0 => F5_2 | F5_2, F5_1 => F5_1 | F5_2, F5_2 => F5_0 | F5_2, F5_3 => F5_4 | F5_2, F5_4 => F5_3
  | F5_3, F5_0 => F5_2 | F5_3, F5_1 => F5_3 | F5_3, F5_2 => F5_4 | F5_3, F5_3 => F5_0 | F5_3, F5_4 => F5_1
  | F5_4, F5_0 => F5_3 | F5_4, F5_1 => F5_1 | F5_4, F5_2 => F5_4 | F5_4, F5_3 => F5_2 | F5_4, F5_4 => F5_0
  end.

#[local] Instance reff472_inst : Magma Fin5 := {| magma_op := reff472_op |}.

Lemma reff472_sat368 : @Equation368 Fin5 reff472_inst.
Proof. unfold Equation368, magma_op, reff472_inst, reff472_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff472_not4131 : ~ @Equation4131 Fin5 reff472_inst.
Proof. unfold Equation4131. intro H. specialize (H F5_1 F5_0). unfold magma_op, reff472_inst, reff472_op in H. discriminate H. Qed.

(** ---- reff474 (Fin4) ---- *)

Definition reff474_op (x y : Fin4) : Fin4 :=
  match x, y with
  | F4_0, F4_0 => F4_0 | F4_0, F4_1 => F4_0 | F4_0, F4_2 => F4_2 | F4_0, F4_3 => F4_2
  | F4_1, F4_0 => F4_2 | F4_1, F4_1 => F4_0 | F4_1, F4_2 => F4_0 | F4_1, F4_3 => F4_2
  | F4_2, F4_0 => F4_0 | F4_2, F4_1 => F4_0 | F4_2, F4_2 => F4_2 | F4_2, F4_3 => F4_2
  | F4_3, F4_0 => F4_2 | F4_3, F4_1 => F4_0 | F4_3, F4_2 => F4_0 | F4_3, F4_3 => F4_2
  end.

#[local] Instance reff474_inst : Magma Fin4 := {| magma_op := reff474_op |}.

Lemma reff474_sat370 : @Equation370 Fin4 reff474_inst.
Proof. unfold Equation370, magma_op, reff474_inst, reff474_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff474_sat3414 : @Equation3414 Fin4 reff474_inst.
Proof. unfold Equation3414, magma_op, reff474_inst, reff474_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff474_sat3837 : @Equation3837 Fin4 reff474_inst.
Proof. unfold Equation3837, magma_op, reff474_inst, reff474_op. intros x y z w. destruct x, y, z, w; reflexivity. Qed.

Lemma reff474_not307 : ~ @Equation307 Fin4 reff474_inst.
Proof. unfold Equation307. intro H. specialize (H F4_1). unfold magma_op, reff474_inst, reff474_op in H. discriminate H. Qed.

Lemma reff474_not3254 : ~ @Equation3254 Fin4 reff474_inst.
Proof. unfold Equation3254. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff474_inst, reff474_op in H. discriminate H. Qed.

Lemma reff474_not3255 : ~ @Equation3255 Fin4 reff474_inst.
Proof. unfold Equation3255. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff474_inst, reff474_op in H. discriminate H. Qed.

Lemma reff474_not3256 : ~ @Equation3256 Fin4 reff474_inst.
Proof. unfold Equation3256. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff474_inst, reff474_op in H. discriminate H. Qed.

Lemma reff474_not3258 : ~ @Equation3258 Fin4 reff474_inst.
Proof. unfold Equation3258. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff474_inst, reff474_op in H. discriminate H. Qed.

Lemma reff474_not3259 : ~ @Equation3259 Fin4 reff474_inst.
Proof. unfold Equation3259. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff474_inst, reff474_op in H. discriminate H. Qed.

Lemma reff474_not3261 : ~ @Equation3261 Fin4 reff474_inst.
Proof. unfold Equation3261. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff474_inst, reff474_op in H. discriminate H. Qed.

Lemma reff474_not3262 : ~ @Equation3262 Fin4 reff474_inst.
Proof. unfold Equation3262. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff474_inst, reff474_op in H. discriminate H. Qed.

Lemma reff474_not3269 : ~ @Equation3269 Fin4 reff474_inst.
Proof. unfold Equation3269. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff474_inst, reff474_op in H. discriminate H. Qed.

Lemma reff474_not3271 : ~ @Equation3271 Fin4 reff474_inst.
Proof. unfold Equation3271. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff474_inst, reff474_op in H. discriminate H. Qed.

Lemma reff474_not3308 : ~ @Equation3308 Fin4 reff474_inst.
Proof. unfold Equation3308. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff474_inst, reff474_op in H. discriminate H. Qed.

Lemma reff474_not3319 : ~ @Equation3319 Fin4 reff474_inst.
Proof. unfold Equation3319. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff474_inst, reff474_op in H. discriminate H. Qed.

Lemma reff474_not3346 : ~ @Equation3346 Fin4 reff474_inst.
Proof. unfold Equation3346. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff474_inst, reff474_op in H. discriminate H. Qed.

Lemma reff474_not3456 : ~ @Equation3456 Fin4 reff474_inst.
Proof. unfold Equation3456. intro H. specialize (H F4_1). unfold magma_op, reff474_inst, reff474_op in H. discriminate H. Qed.

Lemma reff474_not3660 : ~ @Equation3660 Fin4 reff474_inst.
Proof. unfold Equation3660. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff474_inst, reff474_op in H. discriminate H. Qed.

Lemma reff474_not3661 : ~ @Equation3661 Fin4 reff474_inst.
Proof. unfold Equation3661. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff474_inst, reff474_op in H. discriminate H. Qed.

Lemma reff474_not3662 : ~ @Equation3662 Fin4 reff474_inst.
Proof. unfold Equation3662. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff474_inst, reff474_op in H. discriminate H. Qed.

Lemma reff474_not3665 : ~ @Equation3665 Fin4 reff474_inst.
Proof. unfold Equation3665. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff474_inst, reff474_op in H. discriminate H. Qed.

Lemma reff474_not3667 : ~ @Equation3667 Fin4 reff474_inst.
Proof. unfold Equation3667. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff474_inst, reff474_op in H. discriminate H. Qed.

Lemma reff474_not3668 : ~ @Equation3668 Fin4 reff474_inst.
Proof. unfold Equation3668. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff474_inst, reff474_op in H. discriminate H. Qed.

Lemma reff474_not3675 : ~ @Equation3675 Fin4 reff474_inst.
Proof. unfold Equation3675. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff474_inst, reff474_op in H. discriminate H. Qed.

Lemma reff474_not3677 : ~ @Equation3677 Fin4 reff474_inst.
Proof. unfold Equation3677. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff474_inst, reff474_op in H. discriminate H. Qed.

Lemma reff474_not3678 : ~ @Equation3678 Fin4 reff474_inst.
Proof. unfold Equation3678. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff474_inst, reff474_op in H. discriminate H. Qed.

Lemma reff474_not3685 : ~ @Equation3685 Fin4 reff474_inst.
Proof. unfold Equation3685. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff474_inst, reff474_op in H. discriminate H. Qed.

Lemma reff474_not3687 : ~ @Equation3687 Fin4 reff474_inst.
Proof. unfold Equation3687. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff474_inst, reff474_op in H. discriminate H. Qed.

Lemma reff474_not3714 : ~ @Equation3714 Fin4 reff474_inst.
Proof. unfold Equation3714. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff474_inst, reff474_op in H. discriminate H. Qed.

Lemma reff474_not3721 : ~ @Equation3721 Fin4 reff474_inst.
Proof. unfold Equation3721. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff474_inst, reff474_op in H. discriminate H. Qed.

Lemma reff474_not3724 : ~ @Equation3724 Fin4 reff474_inst.
Proof. unfold Equation3724. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff474_inst, reff474_op in H. discriminate H. Qed.

Lemma reff474_not3725 : ~ @Equation3725 Fin4 reff474_inst.
Proof. unfold Equation3725. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff474_inst, reff474_op in H. discriminate H. Qed.

Lemma reff474_not3748 : ~ @Equation3748 Fin4 reff474_inst.
Proof. unfold Equation3748. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff474_inst, reff474_op in H. discriminate H. Qed.

Lemma reff474_not3751 : ~ @Equation3751 Fin4 reff474_inst.
Proof. unfold Equation3751. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff474_inst, reff474_op in H. discriminate H. Qed.

Lemma reff474_not3752 : ~ @Equation3752 Fin4 reff474_inst.
Proof. unfold Equation3752. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff474_inst, reff474_op in H. discriminate H. Qed.

Lemma reff474_not3761 : ~ @Equation3761 Fin4 reff474_inst.
Proof. unfold Equation3761. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff474_inst, reff474_op in H. discriminate H. Qed.

Lemma reff474_not3865 : ~ @Equation3865 Fin4 reff474_inst.
Proof. unfold Equation3865. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff474_inst, reff474_op in H. discriminate H. Qed.

Lemma reff474_not3868 : ~ @Equation3868 Fin4 reff474_inst.
Proof. unfold Equation3868. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff474_inst, reff474_op in H. discriminate H. Qed.

Lemma reff474_not3871 : ~ @Equation3871 Fin4 reff474_inst.
Proof. unfold Equation3871. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff474_inst, reff474_op in H. discriminate H. Qed.

Lemma reff474_not3878 : ~ @Equation3878 Fin4 reff474_inst.
Proof. unfold Equation3878. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff474_inst, reff474_op in H. discriminate H. Qed.

Lemma reff474_not3881 : ~ @Equation3881 Fin4 reff474_inst.
Proof. unfold Equation3881. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff474_inst, reff474_op in H. discriminate H. Qed.

Lemma reff474_not3888 : ~ @Equation3888 Fin4 reff474_inst.
Proof. unfold Equation3888. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff474_inst, reff474_op in H. discriminate H. Qed.

Lemma reff474_not3915 : ~ @Equation3915 Fin4 reff474_inst.
Proof. unfold Equation3915. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff474_inst, reff474_op in H. discriminate H. Qed.

Lemma reff474_not3917 : ~ @Equation3917 Fin4 reff474_inst.
Proof. unfold Equation3917. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff474_inst, reff474_op in H. discriminate H. Qed.

Lemma reff474_not3918 : ~ @Equation3918 Fin4 reff474_inst.
Proof. unfold Equation3918. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff474_inst, reff474_op in H. discriminate H. Qed.

Lemma reff474_not3924 : ~ @Equation3924 Fin4 reff474_inst.
Proof. unfold Equation3924. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff474_inst, reff474_op in H. discriminate H. Qed.

Lemma reff474_not3925 : ~ @Equation3925 Fin4 reff474_inst.
Proof. unfold Equation3925. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff474_inst, reff474_op in H. discriminate H. Qed.

Lemma reff474_not3927 : ~ @Equation3927 Fin4 reff474_inst.
Proof. unfold Equation3927. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff474_inst, reff474_op in H. discriminate H. Qed.

Lemma reff474_not3928 : ~ @Equation3928 Fin4 reff474_inst.
Proof. unfold Equation3928. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff474_inst, reff474_op in H. discriminate H. Qed.

Lemma reff474_not3951 : ~ @Equation3951 Fin4 reff474_inst.
Proof. unfold Equation3951. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff474_inst, reff474_op in H. discriminate H. Qed.

Lemma reff474_not3952 : ~ @Equation3952 Fin4 reff474_inst.
Proof. unfold Equation3952. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff474_inst, reff474_op in H. discriminate H. Qed.

Lemma reff474_not3954 : ~ @Equation3954 Fin4 reff474_inst.
Proof. unfold Equation3954. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff474_inst, reff474_op in H. discriminate H. Qed.

Lemma reff474_not3955 : ~ @Equation3955 Fin4 reff474_inst.
Proof. unfold Equation3955. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff474_inst, reff474_op in H. discriminate H. Qed.

Lemma reff474_not3961 : ~ @Equation3961 Fin4 reff474_inst.
Proof. unfold Equation3961. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff474_inst, reff474_op in H. discriminate H. Qed.

Lemma reff474_not3962 : ~ @Equation3962 Fin4 reff474_inst.
Proof. unfold Equation3962. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff474_inst, reff474_op in H. discriminate H. Qed.

Lemma reff474_not3964 : ~ @Equation3964 Fin4 reff474_inst.
Proof. unfold Equation3964. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff474_inst, reff474_op in H. discriminate H. Qed.

Lemma reff474_not4066 : ~ @Equation4066 Fin4 reff474_inst.
Proof. unfold Equation4066. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff474_inst, reff474_op in H. discriminate H. Qed.

Lemma reff474_not4068 : ~ @Equation4068 Fin4 reff474_inst.
Proof. unfold Equation4068. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff474_inst, reff474_op in H. discriminate H. Qed.

Lemma reff474_not4071 : ~ @Equation4071 Fin4 reff474_inst.
Proof. unfold Equation4071. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff474_inst, reff474_op in H. discriminate H. Qed.

Lemma reff474_not4074 : ~ @Equation4074 Fin4 reff474_inst.
Proof. unfold Equation4074. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff474_inst, reff474_op in H. discriminate H. Qed.

Lemma reff474_not4081 : ~ @Equation4081 Fin4 reff474_inst.
Proof. unfold Equation4081. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff474_inst, reff474_op in H. discriminate H. Qed.

Lemma reff474_not4084 : ~ @Equation4084 Fin4 reff474_inst.
Proof. unfold Equation4084. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff474_inst, reff474_op in H. discriminate H. Qed.

Lemma reff474_not4091 : ~ @Equation4091 Fin4 reff474_inst.
Proof. unfold Equation4091. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff474_inst, reff474_op in H. discriminate H. Qed.

Lemma reff474_not4118 : ~ @Equation4118 Fin4 reff474_inst.
Proof. unfold Equation4118. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff474_inst, reff474_op in H. discriminate H. Qed.

Lemma reff474_not4120 : ~ @Equation4120 Fin4 reff474_inst.
Proof. unfold Equation4120. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff474_inst, reff474_op in H. discriminate H. Qed.

Lemma reff474_not4121 : ~ @Equation4121 Fin4 reff474_inst.
Proof. unfold Equation4121. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff474_inst, reff474_op in H. discriminate H. Qed.

Lemma reff474_not4127 : ~ @Equation4127 Fin4 reff474_inst.
Proof. unfold Equation4127. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff474_inst, reff474_op in H. discriminate H. Qed.

Lemma reff474_not4128 : ~ @Equation4128 Fin4 reff474_inst.
Proof. unfold Equation4128. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff474_inst, reff474_op in H. discriminate H. Qed.

Lemma reff474_not4130 : ~ @Equation4130 Fin4 reff474_inst.
Proof. unfold Equation4130. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff474_inst, reff474_op in H. discriminate H. Qed.

Lemma reff474_not4131 : ~ @Equation4131 Fin4 reff474_inst.
Proof. unfold Equation4131. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff474_inst, reff474_op in H. discriminate H. Qed.

Lemma reff474_not4155 : ~ @Equation4155 Fin4 reff474_inst.
Proof. unfold Equation4155. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff474_inst, reff474_op in H. discriminate H. Qed.

Lemma reff474_not4157 : ~ @Equation4157 Fin4 reff474_inst.
Proof. unfold Equation4157. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff474_inst, reff474_op in H. discriminate H. Qed.

Lemma reff474_not4158 : ~ @Equation4158 Fin4 reff474_inst.
Proof. unfold Equation4158. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff474_inst, reff474_op in H. discriminate H. Qed.

Lemma reff474_not4164 : ~ @Equation4164 Fin4 reff474_inst.
Proof. unfold Equation4164. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff474_inst, reff474_op in H. discriminate H. Qed.

Lemma reff474_not4165 : ~ @Equation4165 Fin4 reff474_inst.
Proof. unfold Equation4165. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff474_inst, reff474_op in H. discriminate H. Qed.

Lemma reff474_not4167 : ~ @Equation4167 Fin4 reff474_inst.
Proof. unfold Equation4167. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff474_inst, reff474_op in H. discriminate H. Qed.

Lemma reff474_not4268 : ~ @Equation4268 Fin4 reff474_inst.
Proof. unfold Equation4268. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff474_inst, reff474_op in H. discriminate H. Qed.

Lemma reff474_not4269 : ~ @Equation4269 Fin4 reff474_inst.
Proof. unfold Equation4269. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff474_inst, reff474_op in H. discriminate H. Qed.

Lemma reff474_not4270 : ~ @Equation4270 Fin4 reff474_inst.
Proof. unfold Equation4270. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff474_inst, reff474_op in H. discriminate H. Qed.

Lemma reff474_not4275 : ~ @Equation4275 Fin4 reff474_inst.
Proof. unfold Equation4275. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff474_inst, reff474_op in H. discriminate H. Qed.

Lemma reff474_not4283 : ~ @Equation4283 Fin4 reff474_inst.
Proof. unfold Equation4283. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff474_inst, reff474_op in H. discriminate H. Qed.

Lemma reff474_not4284 : ~ @Equation4284 Fin4 reff474_inst.
Proof. unfold Equation4284. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff474_inst, reff474_op in H. discriminate H. Qed.

Lemma reff474_not4314 : ~ @Equation4314 Fin4 reff474_inst.
Proof. unfold Equation4314. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff474_inst, reff474_op in H. discriminate H. Qed.

Lemma reff474_not4320 : ~ @Equation4320 Fin4 reff474_inst.
Proof. unfold Equation4320. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff474_inst, reff474_op in H. discriminate H. Qed.

Lemma reff474_not4380 : ~ @Equation4380 Fin4 reff474_inst.
Proof. unfold Equation4380. intro H. specialize (H F4_1). unfold magma_op, reff474_inst, reff474_op in H. discriminate H. Qed.

(** ---- reff476 (Fin3) ---- *)

Definition reff476_op (x y : Fin3) : Fin3 :=
  match x, y with
  | F3_0, F3_0 => F3_0 | F3_0, F3_1 => F3_2 | F3_0, F3_2 => F3_1
  | F3_1, F3_0 => F3_2 | F3_1, F3_1 => F3_1 | F3_1, F3_2 => F3_0
  | F3_2, F3_0 => F3_1 | F3_2, F3_1 => F3_0 | F3_2, F3_2 => F3_2
  end.

#[local] Instance reff476_inst : Magma Fin3 := {| magma_op := reff476_op |}.

Lemma reff476_sat3 : @Equation3 Fin3 reff476_inst.
Proof. unfold Equation3, magma_op, reff476_inst, reff476_op. intros x. destruct x; reflexivity. Qed.

Lemma reff476_sat14 : @Equation14 Fin3 reff476_inst.
Proof. unfold Equation14, magma_op, reff476_inst, reff476_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff476_sat16 : @Equation16 Fin3 reff476_inst.
Proof. unfold Equation16, magma_op, reff476_inst, reff476_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff476_sat26 : @Equation26 Fin3 reff476_inst.
Proof. unfold Equation26, magma_op, reff476_inst, reff476_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff476_sat53 : @Equation53 Fin3 reff476_inst.
Proof. unfold Equation53, magma_op, reff476_inst, reff476_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff476_sat55 : @Equation55 Fin3 reff476_inst.
Proof. unfold Equation55, magma_op, reff476_inst, reff476_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff476_sat66 : @Equation66 Fin3 reff476_inst.
Proof. unfold Equation66, magma_op, reff476_inst, reff476_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff476_sat72 : @Equation72 Fin3 reff476_inst.
Proof. unfold Equation72, magma_op, reff476_inst, reff476_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff476_sat102 : @Equation102 Fin3 reff476_inst.
Proof. unfold Equation102, magma_op, reff476_inst, reff476_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff476_sat105 : @Equation105 Fin3 reff476_inst.
Proof. unfold Equation105, magma_op, reff476_inst, reff476_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff476_sat115 : @Equation115 Fin3 reff476_inst.
Proof. unfold Equation115, magma_op, reff476_inst, reff476_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff476_sat127 : @Equation127 Fin3 reff476_inst.
Proof. unfold Equation127, magma_op, reff476_inst, reff476_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff476_sat160 : @Equation160 Fin3 reff476_inst.
Proof. unfold Equation160, magma_op, reff476_inst, reff476_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff476_sat170 : @Equation170 Fin3 reff476_inst.
Proof. unfold Equation170, magma_op, reff476_inst, reff476_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff476_sat177 : @Equation177 Fin3 reff476_inst.
Proof. unfold Equation177, magma_op, reff476_inst, reff476_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff476_sat179 : @Equation179 Fin3 reff476_inst.
Proof. unfold Equation179, magma_op, reff476_inst, reff476_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff476_sat212 : @Equation212 Fin3 reff476_inst.
Proof. unfold Equation212, magma_op, reff476_inst, reff476_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff476_sat219 : @Equation219 Fin3 reff476_inst.
Proof. unfold Equation219, magma_op, reff476_inst, reff476_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff476_sat221 : @Equation221 Fin3 reff476_inst.
Proof. unfold Equation221, magma_op, reff476_inst, reff476_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff476_sat228 : @Equation228 Fin3 reff476_inst.
Proof. unfold Equation228, magma_op, reff476_inst, reff476_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff476_sat258 : @Equation258 Fin3 reff476_inst.
Proof. unfold Equation258, magma_op, reff476_inst, reff476_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff476_sat263 : @Equation263 Fin3 reff476_inst.
Proof. unfold Equation263, magma_op, reff476_inst, reff476_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff476_sat273 : @Equation273 Fin3 reff476_inst.
Proof. unfold Equation273, magma_op, reff476_inst, reff476_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff476_sat281 : @Equation281 Fin3 reff476_inst.
Proof. unfold Equation281, magma_op, reff476_inst, reff476_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff476_sat313 : @Equation313 Fin3 reff476_inst.
Proof. unfold Equation313, magma_op, reff476_inst, reff476_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff476_sat315 : @Equation315 Fin3 reff476_inst.
Proof. unfold Equation315, magma_op, reff476_inst, reff476_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff476_sat332 : @Equation332 Fin3 reff476_inst.
Proof. unfold Equation332, magma_op, reff476_inst, reff476_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff476_sat362 : @Equation362 Fin3 reff476_inst.
Proof. unfold Equation362, magma_op, reff476_inst, reff476_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff476_sat365 : @Equation365 Fin3 reff476_inst.
Proof. unfold Equation365, magma_op, reff476_inst, reff476_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff476_sat430 : @Equation430 Fin3 reff476_inst.
Proof. unfold Equation430, magma_op, reff476_inst, reff476_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff476_sat492 : @Equation492 Fin3 reff476_inst.
Proof. unfold Equation492, magma_op, reff476_inst, reff476_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff476_sat522 : @Equation522 Fin3 reff476_inst.
Proof. unfold Equation522, magma_op, reff476_inst, reff476_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff476_sat572 : @Equation572 Fin3 reff476_inst.
Proof. unfold Equation572, magma_op, reff476_inst, reff476_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff476_sat642 : @Equation642 Fin3 reff476_inst.
Proof. unfold Equation642, magma_op, reff476_inst, reff476_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff476_sat684 : @Equation684 Fin3 reff476_inst.
Proof. unfold Equation684, magma_op, reff476_inst, reff476_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff476_sat692 : @Equation692 Fin3 reff476_inst.
Proof. unfold Equation692, magma_op, reff476_inst, reff476_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff476_sat711 : @Equation711 Fin3 reff476_inst.
Proof. unfold Equation711, magma_op, reff476_inst, reff476_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff476_sat725 : @Equation725 Fin3 reff476_inst.
Proof. unfold Equation725, magma_op, reff476_inst, reff476_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff476_sat759 : @Equation759 Fin3 reff476_inst.
Proof. unfold Equation759, magma_op, reff476_inst, reff476_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff476_sat826 : @Equation826 Fin3 reff476_inst.
Proof. unfold Equation826, magma_op, reff476_inst, reff476_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff476_sat836 : @Equation836 Fin3 reff476_inst.
Proof. unfold Equation836, magma_op, reff476_inst, reff476_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff476_sat843 : @Equation843 Fin3 reff476_inst.
Proof. unfold Equation843, magma_op, reff476_inst, reff476_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff476_sat845 : @Equation845 Fin3 reff476_inst.
Proof. unfold Equation845, magma_op, reff476_inst, reff476_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff476_sat873 : @Equation873 Fin3 reff476_inst.
Proof. unfold Equation873, magma_op, reff476_inst, reff476_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff476_sat880 : @Equation880 Fin3 reff476_inst.
Proof. unfold Equation880, magma_op, reff476_inst, reff476_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff476_sat882 : @Equation882 Fin3 reff476_inst.
Proof. unfold Equation882, magma_op, reff476_inst, reff476_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff476_sat907 : @Equation907 Fin3 reff476_inst.
Proof. unfold Equation907, magma_op, reff476_inst, reff476_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff476_sat909 : @Equation909 Fin3 reff476_inst.
Proof. unfold Equation909, magma_op, reff476_inst, reff476_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff476_sat916 : @Equation916 Fin3 reff476_inst.
Proof. unfold Equation916, magma_op, reff476_inst, reff476_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff476_sat1029 : @Equation1029 Fin3 reff476_inst.
Proof. unfold Equation1029, magma_op, reff476_inst, reff476_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff476_sat1152 : @Equation1152 Fin3 reff476_inst.
Proof. unfold Equation1152, magma_op, reff476_inst, reff476_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff476_sat1165 : @Equation1165 Fin3 reff476_inst.
Proof. unfold Equation1165, magma_op, reff476_inst, reff476_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff476_sat1171 : @Equation1171 Fin3 reff476_inst.
Proof. unfold Equation1171, magma_op, reff476_inst, reff476_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff476_sat1181 : @Equation1181 Fin3 reff476_inst.
Proof. unfold Equation1181, magma_op, reff476_inst, reff476_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff476_sat1249 : @Equation1249 Fin3 reff476_inst.
Proof. unfold Equation1249, magma_op, reff476_inst, reff476_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff476_sat1293 : @Equation1293 Fin3 reff476_inst.
Proof. unfold Equation1293, magma_op, reff476_inst, reff476_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff476_sat1304 : @Equation1304 Fin3 reff476_inst.
Proof. unfold Equation1304, magma_op, reff476_inst, reff476_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff476_sat1320 : @Equation1320 Fin3 reff476_inst.
Proof. unfold Equation1320, magma_op, reff476_inst, reff476_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff476_sat1340 : @Equation1340 Fin3 reff476_inst.
Proof. unfold Equation1340, magma_op, reff476_inst, reff476_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff476_sat1358 : @Equation1358 Fin3 reff476_inst.
Proof. unfold Equation1358, magma_op, reff476_inst, reff476_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff476_sat1374 : @Equation1374 Fin3 reff476_inst.
Proof. unfold Equation1374, magma_op, reff476_inst, reff476_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff476_sat1467 : @Equation1467 Fin3 reff476_inst.
Proof. unfold Equation1467, magma_op, reff476_inst, reff476_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff476_sat1470 : @Equation1470 Fin3 reff476_inst.
Proof. unfold Equation1470, magma_op, reff476_inst, reff476_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff476_sat1504 : @Equation1504 Fin3 reff476_inst.
Proof. unfold Equation1504, magma_op, reff476_inst, reff476_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff476_sat1507 : @Equation1507 Fin3 reff476_inst.
Proof. unfold Equation1507, magma_op, reff476_inst, reff476_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff476_sat1525 : @Equation1525 Fin3 reff476_inst.
Proof. unfold Equation1525, magma_op, reff476_inst, reff476_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff476_sat1561 : @Equation1561 Fin3 reff476_inst.
Proof. unfold Equation1561, magma_op, reff476_inst, reff476_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff476_sat1670 : @Equation1670 Fin3 reff476_inst.
Proof. unfold Equation1670, magma_op, reff476_inst, reff476_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff476_sat1699 : @Equation1699 Fin3 reff476_inst.
Proof. unfold Equation1699, magma_op, reff476_inst, reff476_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff476_sat1719 : @Equation1719 Fin3 reff476_inst.
Proof. unfold Equation1719, magma_op, reff476_inst, reff476_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff476_sat1793 : @Equation1793 Fin3 reff476_inst.
Proof. unfold Equation1793, magma_op, reff476_inst, reff476_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff476_sat1876 : @Equation1876 Fin3 reff476_inst.
Proof. unfold Equation1876, magma_op, reff476_inst, reff476_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff476_sat1888 : @Equation1888 Fin3 reff476_inst.
Proof. unfold Equation1888, magma_op, reff476_inst, reff476_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff476_sat1943 : @Equation1943 Fin3 reff476_inst.
Proof. unfold Equation1943, magma_op, reff476_inst, reff476_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff476_sat1983 : @Equation1983 Fin3 reff476_inst.
Proof. unfold Equation1983, magma_op, reff476_inst, reff476_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff476_sat2044 : @Equation2044 Fin3 reff476_inst.
Proof. unfold Equation2044, magma_op, reff476_inst, reff476_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff476_sat2170 : @Equation2170 Fin3 reff476_inst.
Proof. unfold Equation2170, magma_op, reff476_inst, reff476_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff476_sat2180 : @Equation2180 Fin3 reff476_inst.
Proof. unfold Equation2180, magma_op, reff476_inst, reff476_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff476_sat2186 : @Equation2186 Fin3 reff476_inst.
Proof. unfold Equation2186, magma_op, reff476_inst, reff476_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff476_sat2196 : @Equation2196 Fin3 reff476_inst.
Proof. unfold Equation2196, magma_op, reff476_inst, reff476_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff476_sat2199 : @Equation2199 Fin3 reff476_inst.
Proof. unfold Equation2199, magma_op, reff476_inst, reff476_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff476_sat2271 : @Equation2271 Fin3 reff476_inst.
Proof. unfold Equation2271, magma_op, reff476_inst, reff476_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff476_sat2279 : @Equation2279 Fin3 reff476_inst.
Proof. unfold Equation2279, magma_op, reff476_inst, reff476_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff476_sat2303 : @Equation2303 Fin3 reff476_inst.
Proof. unfold Equation2303, magma_op, reff476_inst, reff476_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff476_sat2335 : @Equation2335 Fin3 reff476_inst.
Proof. unfold Equation2335, magma_op, reff476_inst, reff476_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff476_sat2349 : @Equation2349 Fin3 reff476_inst.
Proof. unfold Equation2349, magma_op, reff476_inst, reff476_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff476_sat2373 : @Equation2373 Fin3 reff476_inst.
Proof. unfold Equation2373, magma_op, reff476_inst, reff476_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff476_sat2399 : @Equation2399 Fin3 reff476_inst.
Proof. unfold Equation2399, magma_op, reff476_inst, reff476_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff476_sat2482 : @Equation2482 Fin3 reff476_inst.
Proof. unfold Equation2482, magma_op, reff476_inst, reff476_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff476_sat2519 : @Equation2519 Fin3 reff476_inst.
Proof. unfold Equation2519, magma_op, reff476_inst, reff476_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff476_sat2522 : @Equation2522 Fin3 reff476_inst.
Proof. unfold Equation2522, magma_op, reff476_inst, reff476_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff476_sat2540 : @Equation2540 Fin3 reff476_inst.
Proof. unfold Equation2540, magma_op, reff476_inst, reff476_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff476_sat2573 : @Equation2573 Fin3 reff476_inst.
Proof. unfold Equation2573, magma_op, reff476_inst, reff476_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff476_sat2653 : @Equation2653 Fin3 reff476_inst.
Proof. unfold Equation2653, magma_op, reff476_inst, reff476_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff476_sat2663 : @Equation2663 Fin3 reff476_inst.
Proof. unfold Equation2663, magma_op, reff476_inst, reff476_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff476_sat2670 : @Equation2670 Fin3 reff476_inst.
Proof. unfold Equation2670, magma_op, reff476_inst, reff476_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff476_sat2672 : @Equation2672 Fin3 reff476_inst.
Proof. unfold Equation2672, magma_op, reff476_inst, reff476_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff476_sat2700 : @Equation2700 Fin3 reff476_inst.
Proof. unfold Equation2700, magma_op, reff476_inst, reff476_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff476_sat2707 : @Equation2707 Fin3 reff476_inst.
Proof. unfold Equation2707, magma_op, reff476_inst, reff476_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff476_sat2709 : @Equation2709 Fin3 reff476_inst.
Proof. unfold Equation2709, magma_op, reff476_inst, reff476_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff476_sat2734 : @Equation2734 Fin3 reff476_inst.
Proof. unfold Equation2734, magma_op, reff476_inst, reff476_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff476_sat2736 : @Equation2736 Fin3 reff476_inst.
Proof. unfold Equation2736, magma_op, reff476_inst, reff476_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff476_sat2743 : @Equation2743 Fin3 reff476_inst.
Proof. unfold Equation2743, magma_op, reff476_inst, reff476_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff476_sat2875 : @Equation2875 Fin3 reff476_inst.
Proof. unfold Equation2875, magma_op, reff476_inst, reff476_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff476_sat2917 : @Equation2917 Fin3 reff476_inst.
Proof. unfold Equation2917, magma_op, reff476_inst, reff476_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff476_sat2925 : @Equation2925 Fin3 reff476_inst.
Proof. unfold Equation2925, magma_op, reff476_inst, reff476_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff476_sat2944 : @Equation2944 Fin3 reff476_inst.
Proof. unfold Equation2944, magma_op, reff476_inst, reff476_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff476_sat2958 : @Equation2958 Fin3 reff476_inst.
Proof. unfold Equation2958, magma_op, reff476_inst, reff476_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff476_sat2992 : @Equation2992 Fin3 reff476_inst.
Proof. unfold Equation2992, magma_op, reff476_inst, reff476_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff476_sat3120 : @Equation3120 Fin3 reff476_inst.
Proof. unfold Equation3120, magma_op, reff476_inst, reff476_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff476_sat3131 : @Equation3131 Fin3 reff476_inst.
Proof. unfold Equation3131, magma_op, reff476_inst, reff476_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff476_sat3142 : @Equation3142 Fin3 reff476_inst.
Proof. unfold Equation3142, magma_op, reff476_inst, reff476_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff476_sat3211 : @Equation3211 Fin3 reff476_inst.
Proof. unfold Equation3211, magma_op, reff476_inst, reff476_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff476_sat3272 : @Equation3272 Fin3 reff476_inst.
Proof. unfold Equation3272, magma_op, reff476_inst, reff476_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff476_sat3364 : @Equation3364 Fin3 reff476_inst.
Proof. unfold Equation3364, magma_op, reff476_inst, reff476_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff476_sat3417 : @Equation3417 Fin3 reff476_inst.
Proof. unfold Equation3417, magma_op, reff476_inst, reff476_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff476_sat3484 : @Equation3484 Fin3 reff476_inst.
Proof. unfold Equation3484, magma_op, reff476_inst, reff476_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff476_sat3601 : @Equation3601 Fin3 reff476_inst.
Proof. unfold Equation3601, magma_op, reff476_inst, reff476_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff476_sat3668 : @Equation3668 Fin3 reff476_inst.
Proof. unfold Equation3668, magma_op, reff476_inst, reff476_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff476_sat3687 : @Equation3687 Fin3 reff476_inst.
Proof. unfold Equation3687, magma_op, reff476_inst, reff476_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff476_sat3724 : @Equation3724 Fin3 reff476_inst.
Proof. unfold Equation3724, magma_op, reff476_inst, reff476_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff476_sat3749 : @Equation3749 Fin3 reff476_inst.
Proof. unfold Equation3749, magma_op, reff476_inst, reff476_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff476_sat3751 : @Equation3751 Fin3 reff476_inst.
Proof. unfold Equation3751, magma_op, reff476_inst, reff476_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff476_sat3871 : @Equation3871 Fin3 reff476_inst.
Proof. unfold Equation3871, magma_op, reff476_inst, reff476_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff476_sat4007 : @Equation4007 Fin3 reff476_inst.
Proof. unfold Equation4007, magma_op, reff476_inst, reff476_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff476_sat4091 : @Equation4091 Fin3 reff476_inst.
Proof. unfold Equation4091, magma_op, reff476_inst, reff476_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff476_sat4216 : @Equation4216 Fin3 reff476_inst.
Proof. unfold Equation4216, magma_op, reff476_inst, reff476_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff476_sat4305 : @Equation4305 Fin3 reff476_inst.
Proof. unfold Equation4305, magma_op, reff476_inst, reff476_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff476_sat4413 : @Equation4413 Fin3 reff476_inst.
Proof. unfold Equation4413, magma_op, reff476_inst, reff476_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff476_sat4421 : @Equation4421 Fin3 reff476_inst.
Proof. unfold Equation4421, magma_op, reff476_inst, reff476_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff476_sat4450 : @Equation4450 Fin3 reff476_inst.
Proof. unfold Equation4450, magma_op, reff476_inst, reff476_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff476_sat4640 : @Equation4640 Fin3 reff476_inst.
Proof. unfold Equation4640, magma_op, reff476_inst, reff476_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff476_not50 : ~ @Equation50 Fin3 reff476_inst.
Proof. unfold Equation50. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff476_inst, reff476_op in H. discriminate H. Qed.

Lemma reff476_not56 : ~ @Equation56 Fin3 reff476_inst.
Proof. unfold Equation56. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff476_inst, reff476_op in H. discriminate H. Qed.

Lemma reff476_not63 : ~ @Equation63 Fin3 reff476_inst.
Proof. unfold Equation63. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff476_inst, reff476_op in H. discriminate H. Qed.

Lemma reff476_not65 : ~ @Equation65 Fin3 reff476_inst.
Proof. unfold Equation65. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff476_inst, reff476_op in H. discriminate H. Qed.

Lemma reff476_not73 : ~ @Equation73 Fin3 reff476_inst.
Proof. unfold Equation73. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff476_inst, reff476_op in H. discriminate H. Qed.

Lemma reff476_not75 : ~ @Equation75 Fin3 reff476_inst.
Proof. unfold Equation75. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff476_inst, reff476_op in H. discriminate H. Qed.

Lemma reff476_not107 : ~ @Equation107 Fin3 reff476_inst.
Proof. unfold Equation107. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff476_inst, reff476_op in H. discriminate H. Qed.

Lemma reff476_not108 : ~ @Equation108 Fin3 reff476_inst.
Proof. unfold Equation108. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff476_inst, reff476_op in H. discriminate H. Qed.

Lemma reff476_not117 : ~ @Equation117 Fin3 reff476_inst.
Proof. unfold Equation117. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff476_inst, reff476_op in H. discriminate H. Qed.

Lemma reff476_not118 : ~ @Equation118 Fin3 reff476_inst.
Proof. unfold Equation118. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff476_inst, reff476_op in H. discriminate H. Qed.

Lemma reff476_not124 : ~ @Equation124 Fin3 reff476_inst.
Proof. unfold Equation124. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff476_inst, reff476_op in H. discriminate H. Qed.

Lemma reff476_not125 : ~ @Equation125 Fin3 reff476_inst.
Proof. unfold Equation125. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff476_inst, reff476_op in H. discriminate H. Qed.

Lemma reff476_not154 : ~ @Equation154 Fin3 reff476_inst.
Proof. unfold Equation154. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff476_inst, reff476_op in H. discriminate H. Qed.

Lemma reff476_not157 : ~ @Equation157 Fin3 reff476_inst.
Proof. unfold Equation157. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff476_inst, reff476_op in H. discriminate H. Qed.

Lemma reff476_not159 : ~ @Equation159 Fin3 reff476_inst.
Proof. unfold Equation159. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff476_inst, reff476_op in H. discriminate H. Qed.

Lemma reff476_not167 : ~ @Equation167 Fin3 reff476_inst.
Proof. unfold Equation167. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff476_inst, reff476_op in H. discriminate H. Qed.

Lemma reff476_not169 : ~ @Equation169 Fin3 reff476_inst.
Proof. unfold Equation169. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff476_inst, reff476_op in H. discriminate H. Qed.

Lemma reff476_not176 : ~ @Equation176 Fin3 reff476_inst.
Proof. unfold Equation176. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff476_inst, reff476_op in H. discriminate H. Qed.

Lemma reff476_not206 : ~ @Equation206 Fin3 reff476_inst.
Proof. unfold Equation206. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff476_inst, reff476_op in H. discriminate H. Qed.

Lemma reff476_not209 : ~ @Equation209 Fin3 reff476_inst.
Proof. unfold Equation209. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff476_inst, reff476_op in H. discriminate H. Qed.

Lemma reff476_not211 : ~ @Equation211 Fin3 reff476_inst.
Proof. unfold Equation211. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff476_inst, reff476_op in H. discriminate H. Qed.

Lemma reff476_not222 : ~ @Equation222 Fin3 reff476_inst.
Proof. unfold Equation222. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff476_inst, reff476_op in H. discriminate H. Qed.

Lemma reff476_not229 : ~ @Equation229 Fin3 reff476_inst.
Proof. unfold Equation229. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff476_inst, reff476_op in H. discriminate H. Qed.

Lemma reff476_not231 : ~ @Equation231 Fin3 reff476_inst.
Proof. unfold Equation231. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff476_inst, reff476_op in H. discriminate H. Qed.

Lemma reff476_not261 : ~ @Equation261 Fin3 reff476_inst.
Proof. unfold Equation261. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff476_inst, reff476_op in H. discriminate H. Qed.

Lemma reff476_not264 : ~ @Equation264 Fin3 reff476_inst.
Proof. unfold Equation264. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff476_inst, reff476_op in H. discriminate H. Qed.

Lemma reff476_not271 : ~ @Equation271 Fin3 reff476_inst.
Proof. unfold Equation271. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff476_inst, reff476_op in H. discriminate H. Qed.

Lemma reff476_not274 : ~ @Equation274 Fin3 reff476_inst.
Proof. unfold Equation274. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff476_inst, reff476_op in H. discriminate H. Qed.

Lemma reff476_not280 : ~ @Equation280 Fin3 reff476_inst.
Proof. unfold Equation280. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff476_inst, reff476_op in H. discriminate H. Qed.

Lemma reff476_not283 : ~ @Equation283 Fin3 reff476_inst.
Proof. unfold Equation283. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff476_inst, reff476_op in H. discriminate H. Qed.

Lemma reff476_not323 : ~ @Equation323 Fin3 reff476_inst.
Proof. unfold Equation323. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff476_inst, reff476_op in H. discriminate H. Qed.

Lemma reff476_not333 : ~ @Equation333 Fin3 reff476_inst.
Proof. unfold Equation333. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff476_inst, reff476_op in H. discriminate H. Qed.

Lemma reff476_not377 : ~ @Equation377 Fin3 reff476_inst.
Proof. unfold Equation377. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff476_inst, reff476_op in H. discriminate H. Qed.

Lemma reff476_not378 : ~ @Equation378 Fin3 reff476_inst.
Proof. unfold Equation378. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff476_inst, reff476_op in H. discriminate H. Qed.

Lemma reff476_not412 : ~ @Equation412 Fin3 reff476_inst.
Proof. unfold Equation412. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff476_inst, reff476_op in H. discriminate H. Qed.

Lemma reff476_not413 : ~ @Equation413 Fin3 reff476_inst.
Proof. unfold Equation413. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff476_inst, reff476_op in H. discriminate H. Qed.

Lemma reff476_not414 : ~ @Equation414 Fin3 reff476_inst.
Proof. unfold Equation414. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff476_inst, reff476_op in H. discriminate H. Qed.

Lemma reff476_not416 : ~ @Equation416 Fin3 reff476_inst.
Proof. unfold Equation416. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff476_inst, reff476_op in H. discriminate H. Qed.

Lemma reff476_not420 : ~ @Equation420 Fin3 reff476_inst.
Proof. unfold Equation420. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff476_inst, reff476_op in H. discriminate H. Qed.

Lemma reff476_not426 : ~ @Equation426 Fin3 reff476_inst.
Proof. unfold Equation426. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff476_inst, reff476_op in H. discriminate H. Qed.

Lemma reff476_not427 : ~ @Equation427 Fin3 reff476_inst.
Proof. unfold Equation427. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff476_inst, reff476_op in H. discriminate H. Qed.

Lemma reff476_not429 : ~ @Equation429 Fin3 reff476_inst.
Proof. unfold Equation429. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff476_inst, reff476_op in H. discriminate H. Qed.

Lemma reff476_not437 : ~ @Equation437 Fin3 reff476_inst.
Proof. unfold Equation437. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff476_inst, reff476_op in H. discriminate H. Qed.

Lemma reff476_not439 : ~ @Equation439 Fin3 reff476_inst.
Proof. unfold Equation439. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff476_inst, reff476_op in H. discriminate H. Qed.

Lemma reff476_not440 : ~ @Equation440 Fin3 reff476_inst.
Proof. unfold Equation440. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff476_inst, reff476_op in H. discriminate H. Qed.

Lemma reff476_not463 : ~ @Equation463 Fin3 reff476_inst.
Proof. unfold Equation463. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff476_inst, reff476_op in H. discriminate H. Qed.

Lemma reff476_not467 : ~ @Equation467 Fin3 reff476_inst.
Proof. unfold Equation467. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff476_inst, reff476_op in H. discriminate H. Qed.

Lemma reff476_not473 : ~ @Equation473 Fin3 reff476_inst.
Proof. unfold Equation473. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff476_inst, reff476_op in H. discriminate H. Qed.

Lemma reff476_not474 : ~ @Equation474 Fin3 reff476_inst.
Proof. unfold Equation474. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff476_inst, reff476_op in H. discriminate H. Qed.

Lemma reff476_not476 : ~ @Equation476 Fin3 reff476_inst.
Proof. unfold Equation476. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff476_inst, reff476_op in H. discriminate H. Qed.

Lemma reff476_not501 : ~ @Equation501 Fin3 reff476_inst.
Proof. unfold Equation501. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff476_inst, reff476_op in H. discriminate H. Qed.

Lemma reff476_not503 : ~ @Equation503 Fin3 reff476_inst.
Proof. unfold Equation503. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff476_inst, reff476_op in H. discriminate H. Qed.

Lemma reff476_not504 : ~ @Equation504 Fin3 reff476_inst.
Proof. unfold Equation504. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff476_inst, reff476_op in H. discriminate H. Qed.

Lemma reff476_not510 : ~ @Equation510 Fin3 reff476_inst.
Proof. unfold Equation510. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff476_inst, reff476_op in H. discriminate H. Qed.

Lemma reff476_not615 : ~ @Equation615 Fin3 reff476_inst.
Proof. unfold Equation615. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff476_inst, reff476_op in H. discriminate H. Qed.

Lemma reff476_not616 : ~ @Equation616 Fin3 reff476_inst.
Proof. unfold Equation616. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff476_inst, reff476_op in H. discriminate H. Qed.

Lemma reff476_not619 : ~ @Equation619 Fin3 reff476_inst.
Proof. unfold Equation619. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff476_inst, reff476_op in H. discriminate H. Qed.

Lemma reff476_not622 : ~ @Equation622 Fin3 reff476_inst.
Proof. unfold Equation622. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff476_inst, reff476_op in H. discriminate H. Qed.

Lemma reff476_not623 : ~ @Equation623 Fin3 reff476_inst.
Proof. unfold Equation623. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff476_inst, reff476_op in H. discriminate H. Qed.

Lemma reff476_not629 : ~ @Equation629 Fin3 reff476_inst.
Proof. unfold Equation629. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff476_inst, reff476_op in H. discriminate H. Qed.

Lemma reff476_not632 : ~ @Equation632 Fin3 reff476_inst.
Proof. unfold Equation632. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff476_inst, reff476_op in H. discriminate H. Qed.

Lemma reff476_not633 : ~ @Equation633 Fin3 reff476_inst.
Proof. unfold Equation633. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff476_inst, reff476_op in H. discriminate H. Qed.

Lemma reff476_not639 : ~ @Equation639 Fin3 reff476_inst.
Proof. unfold Equation639. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff476_inst, reff476_op in H. discriminate H. Qed.

Lemma reff476_not640 : ~ @Equation640 Fin3 reff476_inst.
Proof. unfold Equation640. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff476_inst, reff476_op in H. discriminate H. Qed.

Lemma reff476_not643 : ~ @Equation643 Fin3 reff476_inst.
Proof. unfold Equation643. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff476_inst, reff476_op in H. discriminate H. Qed.

Lemma reff476_not666 : ~ @Equation666 Fin3 reff476_inst.
Proof. unfold Equation666. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff476_inst, reff476_op in H. discriminate H. Qed.

Lemma reff476_not667 : ~ @Equation667 Fin3 reff476_inst.
Proof. unfold Equation667. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff476_inst, reff476_op in H. discriminate H. Qed.

Lemma reff476_not670 : ~ @Equation670 Fin3 reff476_inst.
Proof. unfold Equation670. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff476_inst, reff476_op in H. discriminate H. Qed.

Lemma reff476_not677 : ~ @Equation677 Fin3 reff476_inst.
Proof. unfold Equation677. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff476_inst, reff476_op in H. discriminate H. Qed.

Lemma reff476_not679 : ~ @Equation679 Fin3 reff476_inst.
Proof. unfold Equation679. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff476_inst, reff476_op in H. discriminate H. Qed.

Lemma reff476_not704 : ~ @Equation704 Fin3 reff476_inst.
Proof. unfold Equation704. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff476_inst, reff476_op in H. discriminate H. Qed.

Lemma reff476_not706 : ~ @Equation706 Fin3 reff476_inst.
Proof. unfold Equation706. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff476_inst, reff476_op in H. discriminate H. Qed.

Lemma reff476_not713 : ~ @Equation713 Fin3 reff476_inst.
Proof. unfold Equation713. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff476_inst, reff476_op in H. discriminate H. Qed.

Lemma reff476_not716 : ~ @Equation716 Fin3 reff476_inst.
Proof. unfold Equation716. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff476_inst, reff476_op in H. discriminate H. Qed.

Lemma reff476_not818 : ~ @Equation818 Fin3 reff476_inst.
Proof. unfold Equation818. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff476_inst, reff476_op in H. discriminate H. Qed.

Lemma reff476_not819 : ~ @Equation819 Fin3 reff476_inst.
Proof. unfold Equation819. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff476_inst, reff476_op in H. discriminate H. Qed.

Lemma reff476_not820 : ~ @Equation820 Fin3 reff476_inst.
Proof. unfold Equation820. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff476_inst, reff476_op in H. discriminate H. Qed.

Lemma reff476_not822 : ~ @Equation822 Fin3 reff476_inst.
Proof. unfold Equation822. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff476_inst, reff476_op in H. discriminate H. Qed.

Lemma reff476_not823 : ~ @Equation823 Fin3 reff476_inst.
Proof. unfold Equation823. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff476_inst, reff476_op in H. discriminate H. Qed.

Lemma reff476_not825 : ~ @Equation825 Fin3 reff476_inst.
Proof. unfold Equation825. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff476_inst, reff476_op in H. discriminate H. Qed.

Lemma reff476_not832 : ~ @Equation832 Fin3 reff476_inst.
Proof. unfold Equation832. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff476_inst, reff476_op in H. discriminate H. Qed.

Lemma reff476_not833 : ~ @Equation833 Fin3 reff476_inst.
Proof. unfold Equation833. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff476_inst, reff476_op in H. discriminate H. Qed.

Lemma reff476_not835 : ~ @Equation835 Fin3 reff476_inst.
Proof. unfold Equation835. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff476_inst, reff476_op in H. discriminate H. Qed.

Lemma reff476_not842 : ~ @Equation842 Fin3 reff476_inst.
Proof. unfold Equation842. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff476_inst, reff476_op in H. discriminate H. Qed.

Lemma reff476_not846 : ~ @Equation846 Fin3 reff476_inst.
Proof. unfold Equation846. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff476_inst, reff476_op in H. discriminate H. Qed.

Lemma reff476_not869 : ~ @Equation869 Fin3 reff476_inst.
Proof. unfold Equation869. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff476_inst, reff476_op in H. discriminate H. Qed.

Lemma reff476_not870 : ~ @Equation870 Fin3 reff476_inst.
Proof. unfold Equation870. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff476_inst, reff476_op in H. discriminate H. Qed.

Lemma reff476_not872 : ~ @Equation872 Fin3 reff476_inst.
Proof. unfold Equation872. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff476_inst, reff476_op in H. discriminate H. Qed.

Lemma reff476_not879 : ~ @Equation879 Fin3 reff476_inst.
Proof. unfold Equation879. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff476_inst, reff476_op in H. discriminate H. Qed.

Lemma reff476_not883 : ~ @Equation883 Fin3 reff476_inst.
Proof. unfold Equation883. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff476_inst, reff476_op in H. discriminate H. Qed.

Lemma reff476_not906 : ~ @Equation906 Fin3 reff476_inst.
Proof. unfold Equation906. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff476_inst, reff476_op in H. discriminate H. Qed.

Lemma reff476_not910 : ~ @Equation910 Fin3 reff476_inst.
Proof. unfold Equation910. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff476_inst, reff476_op in H. discriminate H. Qed.

Lemma reff476_not917 : ~ @Equation917 Fin3 reff476_inst.
Proof. unfold Equation917. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff476_inst, reff476_op in H. discriminate H. Qed.

Lemma reff476_not919 : ~ @Equation919 Fin3 reff476_inst.
Proof. unfold Equation919. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff476_inst, reff476_op in H. discriminate H. Qed.

Lemma reff476_not1021 : ~ @Equation1021 Fin3 reff476_inst.
Proof. unfold Equation1021. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff476_inst, reff476_op in H. discriminate H. Qed.

Lemma reff476_not1022 : ~ @Equation1022 Fin3 reff476_inst.
Proof. unfold Equation1022. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff476_inst, reff476_op in H. discriminate H. Qed.

Lemma reff476_not1023 : ~ @Equation1023 Fin3 reff476_inst.
Proof. unfold Equation1023. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff476_inst, reff476_op in H. discriminate H. Qed.

Lemma reff476_not1025 : ~ @Equation1025 Fin3 reff476_inst.
Proof. unfold Equation1025. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff476_inst, reff476_op in H. discriminate H. Qed.

Lemma reff476_not1026 : ~ @Equation1026 Fin3 reff476_inst.
Proof. unfold Equation1026. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff476_inst, reff476_op in H. discriminate H. Qed.

Lemma reff476_not1028 : ~ @Equation1028 Fin3 reff476_inst.
Proof. unfold Equation1028. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff476_inst, reff476_op in H. discriminate H. Qed.

Lemma reff476_not1035 : ~ @Equation1035 Fin3 reff476_inst.
Proof. unfold Equation1035. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff476_inst, reff476_op in H. discriminate H. Qed.

Lemma reff476_not1039 : ~ @Equation1039 Fin3 reff476_inst.
Proof. unfold Equation1039. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff476_inst, reff476_op in H. discriminate H. Qed.

Lemma reff476_not1046 : ~ @Equation1046 Fin3 reff476_inst.
Proof. unfold Equation1046. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff476_inst, reff476_op in H. discriminate H. Qed.

Lemma reff476_not1048 : ~ @Equation1048 Fin3 reff476_inst.
Proof. unfold Equation1048. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff476_inst, reff476_op in H. discriminate H. Qed.

Lemma reff476_not1049 : ~ @Equation1049 Fin3 reff476_inst.
Proof. unfold Equation1049. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff476_inst, reff476_op in H. discriminate H. Qed.

Lemma reff476_not1072 : ~ @Equation1072 Fin3 reff476_inst.
Proof. unfold Equation1072. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff476_inst, reff476_op in H. discriminate H. Qed.

Lemma reff476_not1076 : ~ @Equation1076 Fin3 reff476_inst.
Proof. unfold Equation1076. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff476_inst, reff476_op in H. discriminate H. Qed.

Lemma reff476_not1083 : ~ @Equation1083 Fin3 reff476_inst.
Proof. unfold Equation1083. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff476_inst, reff476_op in H. discriminate H. Qed.

Lemma reff476_not1085 : ~ @Equation1085 Fin3 reff476_inst.
Proof. unfold Equation1085. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff476_inst, reff476_op in H. discriminate H. Qed.

Lemma reff476_not1086 : ~ @Equation1086 Fin3 reff476_inst.
Proof. unfold Equation1086. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff476_inst, reff476_op in H. discriminate H. Qed.

Lemma reff476_not1109 : ~ @Equation1109 Fin3 reff476_inst.
Proof. unfold Equation1109. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff476_inst, reff476_op in H. discriminate H. Qed.

Lemma reff476_not1110 : ~ @Equation1110 Fin3 reff476_inst.
Proof. unfold Equation1110. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff476_inst, reff476_op in H. discriminate H. Qed.

Lemma reff476_not1112 : ~ @Equation1112 Fin3 reff476_inst.
Proof. unfold Equation1112. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff476_inst, reff476_op in H. discriminate H. Qed.

Lemma reff476_not1119 : ~ @Equation1119 Fin3 reff476_inst.
Proof. unfold Equation1119. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff476_inst, reff476_op in H. discriminate H. Qed.

Lemma reff476_not1224 : ~ @Equation1224 Fin3 reff476_inst.
Proof. unfold Equation1224. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff476_inst, reff476_op in H. discriminate H. Qed.

Lemma reff476_not1225 : ~ @Equation1225 Fin3 reff476_inst.
Proof. unfold Equation1225. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff476_inst, reff476_op in H. discriminate H. Qed.

Lemma reff476_not1228 : ~ @Equation1228 Fin3 reff476_inst.
Proof. unfold Equation1228. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff476_inst, reff476_op in H. discriminate H. Qed.

Lemma reff476_not1229 : ~ @Equation1229 Fin3 reff476_inst.
Proof. unfold Equation1229. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff476_inst, reff476_op in H. discriminate H. Qed.

Lemma reff476_not1232 : ~ @Equation1232 Fin3 reff476_inst.
Proof. unfold Equation1232. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff476_inst, reff476_op in H. discriminate H. Qed.

Lemma reff476_not1238 : ~ @Equation1238 Fin3 reff476_inst.
Proof. unfold Equation1238. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff476_inst, reff476_op in H. discriminate H. Qed.

Lemma reff476_not1239 : ~ @Equation1239 Fin3 reff476_inst.
Proof. unfold Equation1239. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff476_inst, reff476_op in H. discriminate H. Qed.

Lemma reff476_not1242 : ~ @Equation1242 Fin3 reff476_inst.
Proof. unfold Equation1242. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff476_inst, reff476_op in H. discriminate H. Qed.

Lemma reff476_not1248 : ~ @Equation1248 Fin3 reff476_inst.
Proof. unfold Equation1248. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff476_inst, reff476_op in H. discriminate H. Qed.

Lemma reff476_not1251 : ~ @Equation1251 Fin3 reff476_inst.
Proof. unfold Equation1251. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff476_inst, reff476_op in H. discriminate H. Qed.

Lemma reff476_not1252 : ~ @Equation1252 Fin3 reff476_inst.
Proof. unfold Equation1252. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff476_inst, reff476_op in H. discriminate H. Qed.

Lemma reff476_not1275 : ~ @Equation1275 Fin3 reff476_inst.
Proof. unfold Equation1275. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff476_inst, reff476_op in H. discriminate H. Qed.

Lemma reff476_not1278 : ~ @Equation1278 Fin3 reff476_inst.
Proof. unfold Equation1278. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff476_inst, reff476_op in H. discriminate H. Qed.

Lemma reff476_not1279 : ~ @Equation1279 Fin3 reff476_inst.
Proof. unfold Equation1279. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff476_inst, reff476_op in H. discriminate H. Qed.

Lemma reff476_not1286 : ~ @Equation1286 Fin3 reff476_inst.
Proof. unfold Equation1286. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff476_inst, reff476_op in H. discriminate H. Qed.

Lemma reff476_not1288 : ~ @Equation1288 Fin3 reff476_inst.
Proof. unfold Equation1288. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff476_inst, reff476_op in H. discriminate H. Qed.

Lemma reff476_not1313 : ~ @Equation1313 Fin3 reff476_inst.
Proof. unfold Equation1313. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff476_inst, reff476_op in H. discriminate H. Qed.

Lemma reff476_not1315 : ~ @Equation1315 Fin3 reff476_inst.
Proof. unfold Equation1315. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff476_inst, reff476_op in H. discriminate H. Qed.

Lemma reff476_not1322 : ~ @Equation1322 Fin3 reff476_inst.
Proof. unfold Equation1322. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff476_inst, reff476_op in H. discriminate H. Qed.

Lemma reff476_not1323 : ~ @Equation1323 Fin3 reff476_inst.
Proof. unfold Equation1323. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff476_inst, reff476_op in H. discriminate H. Qed.

Lemma reff476_not1427 : ~ @Equation1427 Fin3 reff476_inst.
Proof. unfold Equation1427. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff476_inst, reff476_op in H. discriminate H. Qed.

Lemma reff476_not1428 : ~ @Equation1428 Fin3 reff476_inst.
Proof. unfold Equation1428. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff476_inst, reff476_op in H. discriminate H. Qed.

Lemma reff476_not1429 : ~ @Equation1429 Fin3 reff476_inst.
Proof. unfold Equation1429. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff476_inst, reff476_op in H. discriminate H. Qed.

Lemma reff476_not1431 : ~ @Equation1431 Fin3 reff476_inst.
Proof. unfold Equation1431. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff476_inst, reff476_op in H. discriminate H. Qed.

Lemma reff476_not1435 : ~ @Equation1435 Fin3 reff476_inst.
Proof. unfold Equation1435. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff476_inst, reff476_op in H. discriminate H. Qed.

Lemma reff476_not1441 : ~ @Equation1441 Fin3 reff476_inst.
Proof. unfold Equation1441. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff476_inst, reff476_op in H. discriminate H. Qed.

Lemma reff476_not1445 : ~ @Equation1445 Fin3 reff476_inst.
Proof. unfold Equation1445. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff476_inst, reff476_op in H. discriminate H. Qed.

Lemma reff476_not1451 : ~ @Equation1451 Fin3 reff476_inst.
Proof. unfold Equation1451. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff476_inst, reff476_op in H. discriminate H. Qed.

Lemma reff476_not1452 : ~ @Equation1452 Fin3 reff476_inst.
Proof. unfold Equation1452. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff476_inst, reff476_op in H. discriminate H. Qed.

Lemma reff476_not1454 : ~ @Equation1454 Fin3 reff476_inst.
Proof. unfold Equation1454. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff476_inst, reff476_op in H. discriminate H. Qed.

Lemma reff476_not1478 : ~ @Equation1478 Fin3 reff476_inst.
Proof. unfold Equation1478. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff476_inst, reff476_op in H. discriminate H. Qed.

Lemma reff476_not1482 : ~ @Equation1482 Fin3 reff476_inst.
Proof. unfold Equation1482. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff476_inst, reff476_op in H. discriminate H. Qed.

Lemma reff476_not1488 : ~ @Equation1488 Fin3 reff476_inst.
Proof. unfold Equation1488. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff476_inst, reff476_op in H. discriminate H. Qed.

Lemma reff476_not1489 : ~ @Equation1489 Fin3 reff476_inst.
Proof. unfold Equation1489. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff476_inst, reff476_op in H. discriminate H. Qed.

Lemma reff476_not1491 : ~ @Equation1491 Fin3 reff476_inst.
Proof. unfold Equation1491. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff476_inst, reff476_op in H. discriminate H. Qed.

Lemma reff476_not1515 : ~ @Equation1515 Fin3 reff476_inst.
Proof. unfold Equation1515. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff476_inst, reff476_op in H. discriminate H. Qed.

Lemma reff476_not1516 : ~ @Equation1516 Fin3 reff476_inst.
Proof. unfold Equation1516. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff476_inst, reff476_op in H. discriminate H. Qed.

Lemma reff476_not1518 : ~ @Equation1518 Fin3 reff476_inst.
Proof. unfold Equation1518. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff476_inst, reff476_op in H. discriminate H. Qed.

Lemma reff476_not1526 : ~ @Equation1526 Fin3 reff476_inst.
Proof. unfold Equation1526. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff476_inst, reff476_op in H. discriminate H. Qed.

Lemma reff476_not1528 : ~ @Equation1528 Fin3 reff476_inst.
Proof. unfold Equation1528. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff476_inst, reff476_op in H. discriminate H. Qed.

Lemma reff476_not1630 : ~ @Equation1630 Fin3 reff476_inst.
Proof. unfold Equation1630. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff476_inst, reff476_op in H. discriminate H. Qed.

Lemma reff476_not1631 : ~ @Equation1631 Fin3 reff476_inst.
Proof. unfold Equation1631. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff476_inst, reff476_op in H. discriminate H. Qed.

Lemma reff476_not1634 : ~ @Equation1634 Fin3 reff476_inst.
Proof. unfold Equation1634. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff476_inst, reff476_op in H. discriminate H. Qed.

Lemma reff476_not1637 : ~ @Equation1637 Fin3 reff476_inst.
Proof. unfold Equation1637. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff476_inst, reff476_op in H. discriminate H. Qed.

Lemma reff476_not1638 : ~ @Equation1638 Fin3 reff476_inst.
Proof. unfold Equation1638. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff476_inst, reff476_op in H. discriminate H. Qed.

Lemma reff476_not1644 : ~ @Equation1644 Fin3 reff476_inst.
Proof. unfold Equation1644. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff476_inst, reff476_op in H. discriminate H. Qed.

Lemma reff476_not1645 : ~ @Equation1645 Fin3 reff476_inst.
Proof. unfold Equation1645. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff476_inst, reff476_op in H. discriminate H. Qed.

Lemma reff476_not1648 : ~ @Equation1648 Fin3 reff476_inst.
Proof. unfold Equation1648. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff476_inst, reff476_op in H. discriminate H. Qed.

Lemma reff476_not1655 : ~ @Equation1655 Fin3 reff476_inst.
Proof. unfold Equation1655. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff476_inst, reff476_op in H. discriminate H. Qed.

Lemma reff476_not1657 : ~ @Equation1657 Fin3 reff476_inst.
Proof. unfold Equation1657. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff476_inst, reff476_op in H. discriminate H. Qed.

Lemma reff476_not1681 : ~ @Equation1681 Fin3 reff476_inst.
Proof. unfold Equation1681. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff476_inst, reff476_op in H. discriminate H. Qed.

Lemma reff476_not1682 : ~ @Equation1682 Fin3 reff476_inst.
Proof. unfold Equation1682. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff476_inst, reff476_op in H. discriminate H. Qed.

Lemma reff476_not1685 : ~ @Equation1685 Fin3 reff476_inst.
Proof. unfold Equation1685. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff476_inst, reff476_op in H. discriminate H. Qed.

Lemma reff476_not1692 : ~ @Equation1692 Fin3 reff476_inst.
Proof. unfold Equation1692. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff476_inst, reff476_op in H. discriminate H. Qed.

Lemma reff476_not1694 : ~ @Equation1694 Fin3 reff476_inst.
Proof. unfold Equation1694. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff476_inst, reff476_op in H. discriminate H. Qed.

Lemma reff476_not1718 : ~ @Equation1718 Fin3 reff476_inst.
Proof. unfold Equation1718. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff476_inst, reff476_op in H. discriminate H. Qed.

Lemma reff476_not1721 : ~ @Equation1721 Fin3 reff476_inst.
Proof. unfold Equation1721. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff476_inst, reff476_op in H. discriminate H. Qed.

Lemma reff476_not1722 : ~ @Equation1722 Fin3 reff476_inst.
Proof. unfold Equation1722. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff476_inst, reff476_op in H. discriminate H. Qed.

Lemma reff476_not1728 : ~ @Equation1728 Fin3 reff476_inst.
Proof. unfold Equation1728. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff476_inst, reff476_op in H. discriminate H. Qed.

Lemma reff476_not1729 : ~ @Equation1729 Fin3 reff476_inst.
Proof. unfold Equation1729. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff476_inst, reff476_op in H. discriminate H. Qed.

Lemma reff476_not1833 : ~ @Equation1833 Fin3 reff476_inst.
Proof. unfold Equation1833. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff476_inst, reff476_op in H. discriminate H. Qed.

Lemma reff476_not1834 : ~ @Equation1834 Fin3 reff476_inst.
Proof. unfold Equation1834. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff476_inst, reff476_op in H. discriminate H. Qed.

Lemma reff476_not1835 : ~ @Equation1835 Fin3 reff476_inst.
Proof. unfold Equation1835. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff476_inst, reff476_op in H. discriminate H. Qed.

Lemma reff476_not1837 : ~ @Equation1837 Fin3 reff476_inst.
Proof. unfold Equation1837. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff476_inst, reff476_op in H. discriminate H. Qed.

Lemma reff476_not1841 : ~ @Equation1841 Fin3 reff476_inst.
Proof. unfold Equation1841. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff476_inst, reff476_op in H. discriminate H. Qed.

Lemma reff476_not1847 : ~ @Equation1847 Fin3 reff476_inst.
Proof. unfold Equation1847. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff476_inst, reff476_op in H. discriminate H. Qed.

Lemma reff476_not1851 : ~ @Equation1851 Fin3 reff476_inst.
Proof. unfold Equation1851. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff476_inst, reff476_op in H. discriminate H. Qed.

Lemma reff476_not1857 : ~ @Equation1857 Fin3 reff476_inst.
Proof. unfold Equation1857. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff476_inst, reff476_op in H. discriminate H. Qed.

Lemma reff476_not1858 : ~ @Equation1858 Fin3 reff476_inst.
Proof. unfold Equation1858. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff476_inst, reff476_op in H. discriminate H. Qed.

Lemma reff476_not1860 : ~ @Equation1860 Fin3 reff476_inst.
Proof. unfold Equation1860. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff476_inst, reff476_op in H. discriminate H. Qed.

Lemma reff476_not1884 : ~ @Equation1884 Fin3 reff476_inst.
Proof. unfold Equation1884. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff476_inst, reff476_op in H. discriminate H. Qed.

Lemma reff476_not1885 : ~ @Equation1885 Fin3 reff476_inst.
Proof. unfold Equation1885. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff476_inst, reff476_op in H. discriminate H. Qed.

Lemma reff476_not1887 : ~ @Equation1887 Fin3 reff476_inst.
Proof. unfold Equation1887. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff476_inst, reff476_op in H. discriminate H. Qed.

Lemma reff476_not1895 : ~ @Equation1895 Fin3 reff476_inst.
Proof. unfold Equation1895. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff476_inst, reff476_op in H. discriminate H. Qed.

Lemma reff476_not1897 : ~ @Equation1897 Fin3 reff476_inst.
Proof. unfold Equation1897. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff476_inst, reff476_op in H. discriminate H. Qed.

Lemma reff476_not1898 : ~ @Equation1898 Fin3 reff476_inst.
Proof. unfold Equation1898. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff476_inst, reff476_op in H. discriminate H. Qed.

Lemma reff476_not1922 : ~ @Equation1922 Fin3 reff476_inst.
Proof. unfold Equation1922. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff476_inst, reff476_op in H. discriminate H. Qed.

Lemma reff476_not1924 : ~ @Equation1924 Fin3 reff476_inst.
Proof. unfold Equation1924. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff476_inst, reff476_op in H. discriminate H. Qed.

Lemma reff476_not1925 : ~ @Equation1925 Fin3 reff476_inst.
Proof. unfold Equation1925. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff476_inst, reff476_op in H. discriminate H. Qed.

Lemma reff476_not1931 : ~ @Equation1931 Fin3 reff476_inst.
Proof. unfold Equation1931. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff476_inst, reff476_op in H. discriminate H. Qed.

Lemma reff476_not2036 : ~ @Equation2036 Fin3 reff476_inst.
Proof. unfold Equation2036. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff476_inst, reff476_op in H. discriminate H. Qed.

Lemma reff476_not2037 : ~ @Equation2037 Fin3 reff476_inst.
Proof. unfold Equation2037. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff476_inst, reff476_op in H. discriminate H. Qed.

Lemma reff476_not2038 : ~ @Equation2038 Fin3 reff476_inst.
Proof. unfold Equation2038. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff476_inst, reff476_op in H. discriminate H. Qed.

Lemma reff476_not2040 : ~ @Equation2040 Fin3 reff476_inst.
Proof. unfold Equation2040. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff476_inst, reff476_op in H. discriminate H. Qed.

Lemma reff476_not2041 : ~ @Equation2041 Fin3 reff476_inst.
Proof. unfold Equation2041. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff476_inst, reff476_op in H. discriminate H. Qed.

Lemma reff476_not2043 : ~ @Equation2043 Fin3 reff476_inst.
Proof. unfold Equation2043. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff476_inst, reff476_op in H. discriminate H. Qed.

Lemma reff476_not2050 : ~ @Equation2050 Fin3 reff476_inst.
Proof. unfold Equation2050. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff476_inst, reff476_op in H. discriminate H. Qed.

Lemma reff476_not2054 : ~ @Equation2054 Fin3 reff476_inst.
Proof. unfold Equation2054. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff476_inst, reff476_op in H. discriminate H. Qed.

Lemma reff476_not2061 : ~ @Equation2061 Fin3 reff476_inst.
Proof. unfold Equation2061. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff476_inst, reff476_op in H. discriminate H. Qed.

Lemma reff476_not2063 : ~ @Equation2063 Fin3 reff476_inst.
Proof. unfold Equation2063. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff476_inst, reff476_op in H. discriminate H. Qed.

Lemma reff476_not2064 : ~ @Equation2064 Fin3 reff476_inst.
Proof. unfold Equation2064. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff476_inst, reff476_op in H. discriminate H. Qed.

Lemma reff476_not2087 : ~ @Equation2087 Fin3 reff476_inst.
Proof. unfold Equation2087. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff476_inst, reff476_op in H. discriminate H. Qed.

Lemma reff476_not2091 : ~ @Equation2091 Fin3 reff476_inst.
Proof. unfold Equation2091. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff476_inst, reff476_op in H. discriminate H. Qed.

Lemma reff476_not2098 : ~ @Equation2098 Fin3 reff476_inst.
Proof. unfold Equation2098. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff476_inst, reff476_op in H. discriminate H. Qed.

Lemma reff476_not2100 : ~ @Equation2100 Fin3 reff476_inst.
Proof. unfold Equation2100. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff476_inst, reff476_op in H. discriminate H. Qed.

Lemma reff476_not2101 : ~ @Equation2101 Fin3 reff476_inst.
Proof. unfold Equation2101. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff476_inst, reff476_op in H. discriminate H. Qed.

Lemma reff476_not2124 : ~ @Equation2124 Fin3 reff476_inst.
Proof. unfold Equation2124. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff476_inst, reff476_op in H. discriminate H. Qed.

Lemma reff476_not2125 : ~ @Equation2125 Fin3 reff476_inst.
Proof. unfold Equation2125. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff476_inst, reff476_op in H. discriminate H. Qed.

Lemma reff476_not2127 : ~ @Equation2127 Fin3 reff476_inst.
Proof. unfold Equation2127. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff476_inst, reff476_op in H. discriminate H. Qed.

Lemma reff476_not2134 : ~ @Equation2134 Fin3 reff476_inst.
Proof. unfold Equation2134. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff476_inst, reff476_op in H. discriminate H. Qed.

Lemma reff476_not2239 : ~ @Equation2239 Fin3 reff476_inst.
Proof. unfold Equation2239. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff476_inst, reff476_op in H. discriminate H. Qed.

Lemma reff476_not2240 : ~ @Equation2240 Fin3 reff476_inst.
Proof. unfold Equation2240. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff476_inst, reff476_op in H. discriminate H. Qed.

Lemma reff476_not2243 : ~ @Equation2243 Fin3 reff476_inst.
Proof. unfold Equation2243. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff476_inst, reff476_op in H. discriminate H. Qed.

Lemma reff476_not2246 : ~ @Equation2246 Fin3 reff476_inst.
Proof. unfold Equation2246. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff476_inst, reff476_op in H. discriminate H. Qed.

Lemma reff476_not2247 : ~ @Equation2247 Fin3 reff476_inst.
Proof. unfold Equation2247. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff476_inst, reff476_op in H. discriminate H. Qed.

Lemma reff476_not2253 : ~ @Equation2253 Fin3 reff476_inst.
Proof. unfold Equation2253. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff476_inst, reff476_op in H. discriminate H. Qed.

Lemma reff476_not2254 : ~ @Equation2254 Fin3 reff476_inst.
Proof. unfold Equation2254. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff476_inst, reff476_op in H. discriminate H. Qed.

Lemma reff476_not2257 : ~ @Equation2257 Fin3 reff476_inst.
Proof. unfold Equation2257. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff476_inst, reff476_op in H. discriminate H. Qed.

Lemma reff476_not2264 : ~ @Equation2264 Fin3 reff476_inst.
Proof. unfold Equation2264. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff476_inst, reff476_op in H. discriminate H. Qed.

Lemma reff476_not2266 : ~ @Equation2266 Fin3 reff476_inst.
Proof. unfold Equation2266. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff476_inst, reff476_op in H. discriminate H. Qed.

Lemma reff476_not2290 : ~ @Equation2290 Fin3 reff476_inst.
Proof. unfold Equation2290. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff476_inst, reff476_op in H. discriminate H. Qed.

Lemma reff476_not2293 : ~ @Equation2293 Fin3 reff476_inst.
Proof. unfold Equation2293. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff476_inst, reff476_op in H. discriminate H. Qed.

Lemma reff476_not2294 : ~ @Equation2294 Fin3 reff476_inst.
Proof. unfold Equation2294. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff476_inst, reff476_op in H. discriminate H. Qed.

Lemma reff476_not2300 : ~ @Equation2300 Fin3 reff476_inst.
Proof. unfold Equation2300. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff476_inst, reff476_op in H. discriminate H. Qed.

Lemma reff476_not2301 : ~ @Equation2301 Fin3 reff476_inst.
Proof. unfold Equation2301. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff476_inst, reff476_op in H. discriminate H. Qed.

Lemma reff476_not2304 : ~ @Equation2304 Fin3 reff476_inst.
Proof. unfold Equation2304. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff476_inst, reff476_op in H. discriminate H. Qed.

Lemma reff476_not2328 : ~ @Equation2328 Fin3 reff476_inst.
Proof. unfold Equation2328. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff476_inst, reff476_op in H. discriminate H. Qed.

Lemma reff476_not2330 : ~ @Equation2330 Fin3 reff476_inst.
Proof. unfold Equation2330. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff476_inst, reff476_op in H. discriminate H. Qed.

Lemma reff476_not2337 : ~ @Equation2337 Fin3 reff476_inst.
Proof. unfold Equation2337. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff476_inst, reff476_op in H. discriminate H. Qed.

Lemma reff476_not2340 : ~ @Equation2340 Fin3 reff476_inst.
Proof. unfold Equation2340. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff476_inst, reff476_op in H. discriminate H. Qed.

Lemma reff476_not2442 : ~ @Equation2442 Fin3 reff476_inst.
Proof. unfold Equation2442. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff476_inst, reff476_op in H. discriminate H. Qed.

Lemma reff476_not2443 : ~ @Equation2443 Fin3 reff476_inst.
Proof. unfold Equation2443. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff476_inst, reff476_op in H. discriminate H. Qed.

Lemma reff476_not2444 : ~ @Equation2444 Fin3 reff476_inst.
Proof. unfold Equation2444. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff476_inst, reff476_op in H. discriminate H. Qed.

Lemma reff476_not2446 : ~ @Equation2446 Fin3 reff476_inst.
Proof. unfold Equation2446. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff476_inst, reff476_op in H. discriminate H. Qed.

Lemma reff476_not2450 : ~ @Equation2450 Fin3 reff476_inst.
Proof. unfold Equation2450. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff476_inst, reff476_op in H. discriminate H. Qed.

Lemma reff476_not2456 : ~ @Equation2456 Fin3 reff476_inst.
Proof. unfold Equation2456. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff476_inst, reff476_op in H. discriminate H. Qed.

Lemma reff476_not2460 : ~ @Equation2460 Fin3 reff476_inst.
Proof. unfold Equation2460. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff476_inst, reff476_op in H. discriminate H. Qed.

Lemma reff476_not2466 : ~ @Equation2466 Fin3 reff476_inst.
Proof. unfold Equation2466. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff476_inst, reff476_op in H. discriminate H. Qed.

Lemma reff476_not2467 : ~ @Equation2467 Fin3 reff476_inst.
Proof. unfold Equation2467. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff476_inst, reff476_op in H. discriminate H. Qed.

Lemma reff476_not2469 : ~ @Equation2469 Fin3 reff476_inst.
Proof. unfold Equation2469. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff476_inst, reff476_op in H. discriminate H. Qed.

Lemma reff476_not2493 : ~ @Equation2493 Fin3 reff476_inst.
Proof. unfold Equation2493. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff476_inst, reff476_op in H. discriminate H. Qed.

Lemma reff476_not2497 : ~ @Equation2497 Fin3 reff476_inst.
Proof. unfold Equation2497. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff476_inst, reff476_op in H. discriminate H. Qed.

Lemma reff476_not2503 : ~ @Equation2503 Fin3 reff476_inst.
Proof. unfold Equation2503. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff476_inst, reff476_op in H. discriminate H. Qed.

Lemma reff476_not2504 : ~ @Equation2504 Fin3 reff476_inst.
Proof. unfold Equation2504. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff476_inst, reff476_op in H. discriminate H. Qed.

Lemma reff476_not2506 : ~ @Equation2506 Fin3 reff476_inst.
Proof. unfold Equation2506. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff476_inst, reff476_op in H. discriminate H. Qed.

Lemma reff476_not2530 : ~ @Equation2530 Fin3 reff476_inst.
Proof. unfold Equation2530. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff476_inst, reff476_op in H. discriminate H. Qed.

Lemma reff476_not2531 : ~ @Equation2531 Fin3 reff476_inst.
Proof. unfold Equation2531. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff476_inst, reff476_op in H. discriminate H. Qed.

Lemma reff476_not2533 : ~ @Equation2533 Fin3 reff476_inst.
Proof. unfold Equation2533. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff476_inst, reff476_op in H. discriminate H. Qed.

Lemma reff476_not2541 : ~ @Equation2541 Fin3 reff476_inst.
Proof. unfold Equation2541. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff476_inst, reff476_op in H. discriminate H. Qed.

Lemma reff476_not2543 : ~ @Equation2543 Fin3 reff476_inst.
Proof. unfold Equation2543. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff476_inst, reff476_op in H. discriminate H. Qed.

Lemma reff476_not2645 : ~ @Equation2645 Fin3 reff476_inst.
Proof. unfold Equation2645. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff476_inst, reff476_op in H. discriminate H. Qed.

Lemma reff476_not2646 : ~ @Equation2646 Fin3 reff476_inst.
Proof. unfold Equation2646. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff476_inst, reff476_op in H. discriminate H. Qed.

Lemma reff476_not2647 : ~ @Equation2647 Fin3 reff476_inst.
Proof. unfold Equation2647. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff476_inst, reff476_op in H. discriminate H. Qed.

Lemma reff476_not2649 : ~ @Equation2649 Fin3 reff476_inst.
Proof. unfold Equation2649. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff476_inst, reff476_op in H. discriminate H. Qed.

Lemma reff476_not2650 : ~ @Equation2650 Fin3 reff476_inst.
Proof. unfold Equation2650. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff476_inst, reff476_op in H. discriminate H. Qed.

Lemma reff476_not2652 : ~ @Equation2652 Fin3 reff476_inst.
Proof. unfold Equation2652. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff476_inst, reff476_op in H. discriminate H. Qed.

Lemma reff476_not2659 : ~ @Equation2659 Fin3 reff476_inst.
Proof. unfold Equation2659. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff476_inst, reff476_op in H. discriminate H. Qed.

Lemma reff476_not2660 : ~ @Equation2660 Fin3 reff476_inst.
Proof. unfold Equation2660. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff476_inst, reff476_op in H. discriminate H. Qed.

Lemma reff476_not2662 : ~ @Equation2662 Fin3 reff476_inst.
Proof. unfold Equation2662. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff476_inst, reff476_op in H. discriminate H. Qed.

Lemma reff476_not2669 : ~ @Equation2669 Fin3 reff476_inst.
Proof. unfold Equation2669. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff476_inst, reff476_op in H. discriminate H. Qed.

Lemma reff476_not2673 : ~ @Equation2673 Fin3 reff476_inst.
Proof. unfold Equation2673. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff476_inst, reff476_op in H. discriminate H. Qed.

Lemma reff476_not2696 : ~ @Equation2696 Fin3 reff476_inst.
Proof. unfold Equation2696. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff476_inst, reff476_op in H. discriminate H. Qed.

Lemma reff476_not2697 : ~ @Equation2697 Fin3 reff476_inst.
Proof. unfold Equation2697. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff476_inst, reff476_op in H. discriminate H. Qed.

Lemma reff476_not2699 : ~ @Equation2699 Fin3 reff476_inst.
Proof. unfold Equation2699. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff476_inst, reff476_op in H. discriminate H. Qed.

Lemma reff476_not2706 : ~ @Equation2706 Fin3 reff476_inst.
Proof. unfold Equation2706. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff476_inst, reff476_op in H. discriminate H. Qed.

Lemma reff476_not2710 : ~ @Equation2710 Fin3 reff476_inst.
Proof. unfold Equation2710. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff476_inst, reff476_op in H. discriminate H. Qed.

Lemma reff476_not2733 : ~ @Equation2733 Fin3 reff476_inst.
Proof. unfold Equation2733. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff476_inst, reff476_op in H. discriminate H. Qed.

Lemma reff476_not2737 : ~ @Equation2737 Fin3 reff476_inst.
Proof. unfold Equation2737. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff476_inst, reff476_op in H. discriminate H. Qed.

Lemma reff476_not2744 : ~ @Equation2744 Fin3 reff476_inst.
Proof. unfold Equation2744. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff476_inst, reff476_op in H. discriminate H. Qed.

Lemma reff476_not2746 : ~ @Equation2746 Fin3 reff476_inst.
Proof. unfold Equation2746. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff476_inst, reff476_op in H. discriminate H. Qed.

Lemma reff476_not2848 : ~ @Equation2848 Fin3 reff476_inst.
Proof. unfold Equation2848. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff476_inst, reff476_op in H. discriminate H. Qed.

Lemma reff476_not2849 : ~ @Equation2849 Fin3 reff476_inst.
Proof. unfold Equation2849. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff476_inst, reff476_op in H. discriminate H. Qed.

Lemma reff476_not2852 : ~ @Equation2852 Fin3 reff476_inst.
Proof. unfold Equation2852. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff476_inst, reff476_op in H. discriminate H. Qed.

Lemma reff476_not2855 : ~ @Equation2855 Fin3 reff476_inst.
Proof. unfold Equation2855. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff476_inst, reff476_op in H. discriminate H. Qed.

Lemma reff476_not2856 : ~ @Equation2856 Fin3 reff476_inst.
Proof. unfold Equation2856. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff476_inst, reff476_op in H. discriminate H. Qed.

Lemma reff476_not2862 : ~ @Equation2862 Fin3 reff476_inst.
Proof. unfold Equation2862. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff476_inst, reff476_op in H. discriminate H. Qed.

Lemma reff476_not2865 : ~ @Equation2865 Fin3 reff476_inst.
Proof. unfold Equation2865. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff476_inst, reff476_op in H. discriminate H. Qed.

Lemma reff476_not2866 : ~ @Equation2866 Fin3 reff476_inst.
Proof. unfold Equation2866. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff476_inst, reff476_op in H. discriminate H. Qed.

Lemma reff476_not2872 : ~ @Equation2872 Fin3 reff476_inst.
Proof. unfold Equation2872. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff476_inst, reff476_op in H. discriminate H. Qed.

Lemma reff476_not2873 : ~ @Equation2873 Fin3 reff476_inst.
Proof. unfold Equation2873. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff476_inst, reff476_op in H. discriminate H. Qed.

Lemma reff476_not2876 : ~ @Equation2876 Fin3 reff476_inst.
Proof. unfold Equation2876. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff476_inst, reff476_op in H. discriminate H. Qed.

Lemma reff476_not2899 : ~ @Equation2899 Fin3 reff476_inst.
Proof. unfold Equation2899. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff476_inst, reff476_op in H. discriminate H. Qed.

Lemma reff476_not2900 : ~ @Equation2900 Fin3 reff476_inst.
Proof. unfold Equation2900. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff476_inst, reff476_op in H. discriminate H. Qed.

Lemma reff476_not2903 : ~ @Equation2903 Fin3 reff476_inst.
Proof. unfold Equation2903. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff476_inst, reff476_op in H. discriminate H. Qed.

Lemma reff476_not2910 : ~ @Equation2910 Fin3 reff476_inst.
Proof. unfold Equation2910. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff476_inst, reff476_op in H. discriminate H. Qed.

Lemma reff476_not2912 : ~ @Equation2912 Fin3 reff476_inst.
Proof. unfold Equation2912. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff476_inst, reff476_op in H. discriminate H. Qed.

Lemma reff476_not2937 : ~ @Equation2937 Fin3 reff476_inst.
Proof. unfold Equation2937. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff476_inst, reff476_op in H. discriminate H. Qed.

Lemma reff476_not2939 : ~ @Equation2939 Fin3 reff476_inst.
Proof. unfold Equation2939. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff476_inst, reff476_op in H. discriminate H. Qed.

Lemma reff476_not2946 : ~ @Equation2946 Fin3 reff476_inst.
Proof. unfold Equation2946. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff476_inst, reff476_op in H. discriminate H. Qed.

Lemma reff476_not2949 : ~ @Equation2949 Fin3 reff476_inst.
Proof. unfold Equation2949. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff476_inst, reff476_op in H. discriminate H. Qed.

Lemma reff476_not3051 : ~ @Equation3051 Fin3 reff476_inst.
Proof. unfold Equation3051. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff476_inst, reff476_op in H. discriminate H. Qed.

Lemma reff476_not3052 : ~ @Equation3052 Fin3 reff476_inst.
Proof. unfold Equation3052. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff476_inst, reff476_op in H. discriminate H. Qed.

Lemma reff476_not3055 : ~ @Equation3055 Fin3 reff476_inst.
Proof. unfold Equation3055. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff476_inst, reff476_op in H. discriminate H. Qed.

Lemma reff476_not3056 : ~ @Equation3056 Fin3 reff476_inst.
Proof. unfold Equation3056. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff476_inst, reff476_op in H. discriminate H. Qed.

Lemma reff476_not3059 : ~ @Equation3059 Fin3 reff476_inst.
Proof. unfold Equation3059. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff476_inst, reff476_op in H. discriminate H. Qed.

Lemma reff476_not3065 : ~ @Equation3065 Fin3 reff476_inst.
Proof. unfold Equation3065. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff476_inst, reff476_op in H. discriminate H. Qed.

Lemma reff476_not3068 : ~ @Equation3068 Fin3 reff476_inst.
Proof. unfold Equation3068. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff476_inst, reff476_op in H. discriminate H. Qed.

Lemma reff476_not3069 : ~ @Equation3069 Fin3 reff476_inst.
Proof. unfold Equation3069. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff476_inst, reff476_op in H. discriminate H. Qed.

Lemma reff476_not3076 : ~ @Equation3076 Fin3 reff476_inst.
Proof. unfold Equation3076. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff476_inst, reff476_op in H. discriminate H. Qed.

Lemma reff476_not3078 : ~ @Equation3078 Fin3 reff476_inst.
Proof. unfold Equation3078. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff476_inst, reff476_op in H. discriminate H. Qed.

Lemma reff476_not3102 : ~ @Equation3102 Fin3 reff476_inst.
Proof. unfold Equation3102. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff476_inst, reff476_op in H. discriminate H. Qed.

Lemma reff476_not3105 : ~ @Equation3105 Fin3 reff476_inst.
Proof. unfold Equation3105. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff476_inst, reff476_op in H. discriminate H. Qed.

Lemma reff476_not3106 : ~ @Equation3106 Fin3 reff476_inst.
Proof. unfold Equation3106. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff476_inst, reff476_op in H. discriminate H. Qed.

Lemma reff476_not3113 : ~ @Equation3113 Fin3 reff476_inst.
Proof. unfold Equation3113. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff476_inst, reff476_op in H. discriminate H. Qed.

Lemma reff476_not3115 : ~ @Equation3115 Fin3 reff476_inst.
Proof. unfold Equation3115. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff476_inst, reff476_op in H. discriminate H. Qed.

Lemma reff476_not3139 : ~ @Equation3139 Fin3 reff476_inst.
Proof. unfold Equation3139. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff476_inst, reff476_op in H. discriminate H. Qed.

Lemma reff476_not3140 : ~ @Equation3140 Fin3 reff476_inst.
Proof. unfold Equation3140. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff476_inst, reff476_op in H. discriminate H. Qed.

Lemma reff476_not3143 : ~ @Equation3143 Fin3 reff476_inst.
Proof. unfold Equation3143. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff476_inst, reff476_op in H. discriminate H. Qed.

Lemma reff476_not3149 : ~ @Equation3149 Fin3 reff476_inst.
Proof. unfold Equation3149. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff476_inst, reff476_op in H. discriminate H. Qed.

Lemma reff476_not3152 : ~ @Equation3152 Fin3 reff476_inst.
Proof. unfold Equation3152. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff476_inst, reff476_op in H. discriminate H. Qed.

Lemma reff476_not3254 : ~ @Equation3254 Fin3 reff476_inst.
Proof. unfold Equation3254. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff476_inst, reff476_op in H. discriminate H. Qed.

Lemma reff476_not3255 : ~ @Equation3255 Fin3 reff476_inst.
Proof. unfold Equation3255. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff476_inst, reff476_op in H. discriminate H. Qed.

Lemma reff476_not3256 : ~ @Equation3256 Fin3 reff476_inst.
Proof. unfold Equation3256. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff476_inst, reff476_op in H. discriminate H. Qed.

Lemma reff476_not3258 : ~ @Equation3258 Fin3 reff476_inst.
Proof. unfold Equation3258. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff476_inst, reff476_op in H. discriminate H. Qed.

Lemma reff476_not3262 : ~ @Equation3262 Fin3 reff476_inst.
Proof. unfold Equation3262. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff476_inst, reff476_op in H. discriminate H. Qed.

Lemma reff476_not3268 : ~ @Equation3268 Fin3 reff476_inst.
Proof. unfold Equation3268. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff476_inst, reff476_op in H. discriminate H. Qed.

Lemma reff476_not3269 : ~ @Equation3269 Fin3 reff476_inst.
Proof. unfold Equation3269. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff476_inst, reff476_op in H. discriminate H. Qed.

Lemma reff476_not3271 : ~ @Equation3271 Fin3 reff476_inst.
Proof. unfold Equation3271. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff476_inst, reff476_op in H. discriminate H. Qed.

Lemma reff476_not3279 : ~ @Equation3279 Fin3 reff476_inst.
Proof. unfold Equation3279. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff476_inst, reff476_op in H. discriminate H. Qed.

Lemma reff476_not3281 : ~ @Equation3281 Fin3 reff476_inst.
Proof. unfold Equation3281. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff476_inst, reff476_op in H. discriminate H. Qed.

Lemma reff476_not3309 : ~ @Equation3309 Fin3 reff476_inst.
Proof. unfold Equation3309. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff476_inst, reff476_op in H. discriminate H. Qed.

Lemma reff476_not3315 : ~ @Equation3315 Fin3 reff476_inst.
Proof. unfold Equation3315. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff476_inst, reff476_op in H. discriminate H. Qed.

Lemma reff476_not3316 : ~ @Equation3316 Fin3 reff476_inst.
Proof. unfold Equation3316. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff476_inst, reff476_op in H. discriminate H. Qed.

Lemma reff476_not3318 : ~ @Equation3318 Fin3 reff476_inst.
Proof. unfold Equation3318. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff476_inst, reff476_op in H. discriminate H. Qed.

Lemma reff476_not3343 : ~ @Equation3343 Fin3 reff476_inst.
Proof. unfold Equation3343. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff476_inst, reff476_op in H. discriminate H. Qed.

Lemma reff476_not3345 : ~ @Equation3345 Fin3 reff476_inst.
Proof. unfold Equation3345. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff476_inst, reff476_op in H. discriminate H. Qed.

Lemma reff476_not3346 : ~ @Equation3346 Fin3 reff476_inst.
Proof. unfold Equation3346. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff476_inst, reff476_op in H. discriminate H. Qed.

Lemma reff476_not3352 : ~ @Equation3352 Fin3 reff476_inst.
Proof. unfold Equation3352. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff476_inst, reff476_op in H. discriminate H. Qed.

Lemma reff476_not3457 : ~ @Equation3457 Fin3 reff476_inst.
Proof. unfold Equation3457. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff476_inst, reff476_op in H. discriminate H. Qed.

Lemma reff476_not3458 : ~ @Equation3458 Fin3 reff476_inst.
Proof. unfold Equation3458. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff476_inst, reff476_op in H. discriminate H. Qed.

Lemma reff476_not3461 : ~ @Equation3461 Fin3 reff476_inst.
Proof. unfold Equation3461. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff476_inst, reff476_op in H. discriminate H. Qed.

Lemma reff476_not3464 : ~ @Equation3464 Fin3 reff476_inst.
Proof. unfold Equation3464. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff476_inst, reff476_op in H. discriminate H. Qed.

Lemma reff476_not3465 : ~ @Equation3465 Fin3 reff476_inst.
Proof. unfold Equation3465. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff476_inst, reff476_op in H. discriminate H. Qed.

Lemma reff476_not3474 : ~ @Equation3474 Fin3 reff476_inst.
Proof. unfold Equation3474. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff476_inst, reff476_op in H. discriminate H. Qed.

Lemma reff476_not3475 : ~ @Equation3475 Fin3 reff476_inst.
Proof. unfold Equation3475. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff476_inst, reff476_op in H. discriminate H. Qed.

Lemma reff476_not3481 : ~ @Equation3481 Fin3 reff476_inst.
Proof. unfold Equation3481. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff476_inst, reff476_op in H. discriminate H. Qed.

Lemma reff476_not3482 : ~ @Equation3482 Fin3 reff476_inst.
Proof. unfold Equation3482. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff476_inst, reff476_op in H. discriminate H. Qed.

Lemma reff476_not3509 : ~ @Equation3509 Fin3 reff476_inst.
Proof. unfold Equation3509. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff476_inst, reff476_op in H. discriminate H. Qed.

Lemma reff476_not3512 : ~ @Equation3512 Fin3 reff476_inst.
Proof. unfold Equation3512. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff476_inst, reff476_op in H. discriminate H. Qed.

Lemma reff476_not3519 : ~ @Equation3519 Fin3 reff476_inst.
Proof. unfold Equation3519. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff476_inst, reff476_op in H. discriminate H. Qed.

Lemma reff476_not3521 : ~ @Equation3521 Fin3 reff476_inst.
Proof. unfold Equation3521. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff476_inst, reff476_op in H. discriminate H. Qed.

Lemma reff476_not3546 : ~ @Equation3546 Fin3 reff476_inst.
Proof. unfold Equation3546. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff476_inst, reff476_op in H. discriminate H. Qed.

Lemma reff476_not3548 : ~ @Equation3548 Fin3 reff476_inst.
Proof. unfold Equation3548. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff476_inst, reff476_op in H. discriminate H. Qed.

Lemma reff476_not3555 : ~ @Equation3555 Fin3 reff476_inst.
Proof. unfold Equation3555. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff476_inst, reff476_op in H. discriminate H. Qed.

Lemma reff476_not3558 : ~ @Equation3558 Fin3 reff476_inst.
Proof. unfold Equation3558. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff476_inst, reff476_op in H. discriminate H. Qed.

Lemma reff476_not3660 : ~ @Equation3660 Fin3 reff476_inst.
Proof. unfold Equation3660. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff476_inst, reff476_op in H. discriminate H. Qed.

Lemma reff476_not3661 : ~ @Equation3661 Fin3 reff476_inst.
Proof. unfold Equation3661. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff476_inst, reff476_op in H. discriminate H. Qed.

Lemma reff476_not3662 : ~ @Equation3662 Fin3 reff476_inst.
Proof. unfold Equation3662. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff476_inst, reff476_op in H. discriminate H. Qed.

Lemma reff476_not3664 : ~ @Equation3664 Fin3 reff476_inst.
Proof. unfold Equation3664. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff476_inst, reff476_op in H. discriminate H. Qed.

Lemma reff476_not3665 : ~ @Equation3665 Fin3 reff476_inst.
Proof. unfold Equation3665. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff476_inst, reff476_op in H. discriminate H. Qed.

Lemma reff476_not3667 : ~ @Equation3667 Fin3 reff476_inst.
Proof. unfold Equation3667. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff476_inst, reff476_op in H. discriminate H. Qed.

Lemma reff476_not3674 : ~ @Equation3674 Fin3 reff476_inst.
Proof. unfold Equation3674. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff476_inst, reff476_op in H. discriminate H. Qed.

Lemma reff476_not3675 : ~ @Equation3675 Fin3 reff476_inst.
Proof. unfold Equation3675. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff476_inst, reff476_op in H. discriminate H. Qed.

Lemma reff476_not3677 : ~ @Equation3677 Fin3 reff476_inst.
Proof. unfold Equation3677. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff476_inst, reff476_op in H. discriminate H. Qed.

Lemma reff476_not3684 : ~ @Equation3684 Fin3 reff476_inst.
Proof. unfold Equation3684. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff476_inst, reff476_op in H. discriminate H. Qed.

Lemma reff476_not3712 : ~ @Equation3712 Fin3 reff476_inst.
Proof. unfold Equation3712. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff476_inst, reff476_op in H. discriminate H. Qed.

Lemma reff476_not3714 : ~ @Equation3714 Fin3 reff476_inst.
Proof. unfold Equation3714. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff476_inst, reff476_op in H. discriminate H. Qed.

Lemma reff476_not3721 : ~ @Equation3721 Fin3 reff476_inst.
Proof. unfold Equation3721. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff476_inst, reff476_op in H. discriminate H. Qed.

Lemma reff476_not3725 : ~ @Equation3725 Fin3 reff476_inst.
Proof. unfold Equation3725. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff476_inst, reff476_op in H. discriminate H. Qed.

Lemma reff476_not3748 : ~ @Equation3748 Fin3 reff476_inst.
Proof. unfold Equation3748. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff476_inst, reff476_op in H. discriminate H. Qed.

Lemma reff476_not3752 : ~ @Equation3752 Fin3 reff476_inst.
Proof. unfold Equation3752. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff476_inst, reff476_op in H. discriminate H. Qed.

Lemma reff476_not3759 : ~ @Equation3759 Fin3 reff476_inst.
Proof. unfold Equation3759. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff476_inst, reff476_op in H. discriminate H. Qed.

Lemma reff476_not3761 : ~ @Equation3761 Fin3 reff476_inst.
Proof. unfold Equation3761. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff476_inst, reff476_op in H. discriminate H. Qed.

Lemma reff476_not3864 : ~ @Equation3864 Fin3 reff476_inst.
Proof. unfold Equation3864. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff476_inst, reff476_op in H. discriminate H. Qed.

Lemma reff476_not3865 : ~ @Equation3865 Fin3 reff476_inst.
Proof. unfold Equation3865. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff476_inst, reff476_op in H. discriminate H. Qed.

Lemma reff476_not3867 : ~ @Equation3867 Fin3 reff476_inst.
Proof. unfold Equation3867. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff476_inst, reff476_op in H. discriminate H. Qed.

Lemma reff476_not3868 : ~ @Equation3868 Fin3 reff476_inst.
Proof. unfold Equation3868. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff476_inst, reff476_op in H. discriminate H. Qed.

Lemma reff476_not3870 : ~ @Equation3870 Fin3 reff476_inst.
Proof. unfold Equation3870. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff476_inst, reff476_op in H. discriminate H. Qed.

Lemma reff476_not3877 : ~ @Equation3877 Fin3 reff476_inst.
Proof. unfold Equation3877. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff476_inst, reff476_op in H. discriminate H. Qed.

Lemma reff476_not3881 : ~ @Equation3881 Fin3 reff476_inst.
Proof. unfold Equation3881. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff476_inst, reff476_op in H. discriminate H. Qed.

Lemma reff476_not3888 : ~ @Equation3888 Fin3 reff476_inst.
Proof. unfold Equation3888. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff476_inst, reff476_op in H. discriminate H. Qed.

Lemma reff476_not3890 : ~ @Equation3890 Fin3 reff476_inst.
Proof. unfold Equation3890. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff476_inst, reff476_op in H. discriminate H. Qed.

Lemma reff476_not3918 : ~ @Equation3918 Fin3 reff476_inst.
Proof. unfold Equation3918. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff476_inst, reff476_op in H. discriminate H. Qed.

Lemma reff476_not3925 : ~ @Equation3925 Fin3 reff476_inst.
Proof. unfold Equation3925. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff476_inst, reff476_op in H. discriminate H. Qed.

Lemma reff476_not3927 : ~ @Equation3927 Fin3 reff476_inst.
Proof. unfold Equation3927. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff476_inst, reff476_op in H. discriminate H. Qed.

Lemma reff476_not3928 : ~ @Equation3928 Fin3 reff476_inst.
Proof. unfold Equation3928. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff476_inst, reff476_op in H. discriminate H. Qed.

Lemma reff476_not3951 : ~ @Equation3951 Fin3 reff476_inst.
Proof. unfold Equation3951. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff476_inst, reff476_op in H. discriminate H. Qed.

Lemma reff476_not3952 : ~ @Equation3952 Fin3 reff476_inst.
Proof. unfold Equation3952. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff476_inst, reff476_op in H. discriminate H. Qed.

Lemma reff476_not3954 : ~ @Equation3954 Fin3 reff476_inst.
Proof. unfold Equation3954. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff476_inst, reff476_op in H. discriminate H. Qed.

Lemma reff476_not3961 : ~ @Equation3961 Fin3 reff476_inst.
Proof. unfold Equation3961. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff476_inst, reff476_op in H. discriminate H. Qed.

Lemma reff476_not4066 : ~ @Equation4066 Fin3 reff476_inst.
Proof. unfold Equation4066. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff476_inst, reff476_op in H. discriminate H. Qed.

Lemma reff476_not4067 : ~ @Equation4067 Fin3 reff476_inst.
Proof. unfold Equation4067. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff476_inst, reff476_op in H. discriminate H. Qed.

Lemma reff476_not4070 : ~ @Equation4070 Fin3 reff476_inst.
Proof. unfold Equation4070. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff476_inst, reff476_op in H. discriminate H. Qed.

Lemma reff476_not4071 : ~ @Equation4071 Fin3 reff476_inst.
Proof. unfold Equation4071. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff476_inst, reff476_op in H. discriminate H. Qed.

Lemma reff476_not4074 : ~ @Equation4074 Fin3 reff476_inst.
Proof. unfold Equation4074. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff476_inst, reff476_op in H. discriminate H. Qed.

Lemma reff476_not4080 : ~ @Equation4080 Fin3 reff476_inst.
Proof. unfold Equation4080. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff476_inst, reff476_op in H. discriminate H. Qed.

Lemma reff476_not4081 : ~ @Equation4081 Fin3 reff476_inst.
Proof. unfold Equation4081. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff476_inst, reff476_op in H. discriminate H. Qed.

Lemma reff476_not4084 : ~ @Equation4084 Fin3 reff476_inst.
Proof. unfold Equation4084. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff476_inst, reff476_op in H. discriminate H. Qed.

Lemma reff476_not4090 : ~ @Equation4090 Fin3 reff476_inst.
Proof. unfold Equation4090. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff476_inst, reff476_op in H. discriminate H. Qed.

Lemma reff476_not4093 : ~ @Equation4093 Fin3 reff476_inst.
Proof. unfold Equation4093. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff476_inst, reff476_op in H. discriminate H. Qed.

Lemma reff476_not4120 : ~ @Equation4120 Fin3 reff476_inst.
Proof. unfold Equation4120. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff476_inst, reff476_op in H. discriminate H. Qed.

Lemma reff476_not4121 : ~ @Equation4121 Fin3 reff476_inst.
Proof. unfold Equation4121. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff476_inst, reff476_op in H. discriminate H. Qed.

Lemma reff476_not4128 : ~ @Equation4128 Fin3 reff476_inst.
Proof. unfold Equation4128. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff476_inst, reff476_op in H. discriminate H. Qed.

Lemma reff476_not4130 : ~ @Equation4130 Fin3 reff476_inst.
Proof. unfold Equation4130. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff476_inst, reff476_op in H. discriminate H. Qed.

Lemma reff476_not4155 : ~ @Equation4155 Fin3 reff476_inst.
Proof. unfold Equation4155. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff476_inst, reff476_op in H. discriminate H. Qed.

Lemma reff476_not4157 : ~ @Equation4157 Fin3 reff476_inst.
Proof. unfold Equation4157. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff476_inst, reff476_op in H. discriminate H. Qed.

Lemma reff476_not4164 : ~ @Equation4164 Fin3 reff476_inst.
Proof. unfold Equation4164. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff476_inst, reff476_op in H. discriminate H. Qed.

Lemma reff476_not4165 : ~ @Equation4165 Fin3 reff476_inst.
Proof. unfold Equation4165. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff476_inst, reff476_op in H. discriminate H. Qed.

Lemma reff476_not4268 : ~ @Equation4268 Fin3 reff476_inst.
Proof. unfold Equation4268. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff476_inst, reff476_op in H. discriminate H. Qed.

Lemma reff476_not4269 : ~ @Equation4269 Fin3 reff476_inst.
Proof. unfold Equation4269. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff476_inst, reff476_op in H. discriminate H. Qed.

Lemma reff476_not4270 : ~ @Equation4270 Fin3 reff476_inst.
Proof. unfold Equation4270. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff476_inst, reff476_op in H. discriminate H. Qed.

Lemma reff476_not4272 : ~ @Equation4272 Fin3 reff476_inst.
Proof. unfold Equation4272. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff476_inst, reff476_op in H. discriminate H. Qed.

Lemma reff476_not4276 : ~ @Equation4276 Fin3 reff476_inst.
Proof. unfold Equation4276. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff476_inst, reff476_op in H. discriminate H. Qed.

Lemma reff476_not4284 : ~ @Equation4284 Fin3 reff476_inst.
Proof. unfold Equation4284. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff476_inst, reff476_op in H. discriminate H. Qed.

Lemma reff476_not4290 : ~ @Equation4290 Fin3 reff476_inst.
Proof. unfold Equation4290. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff476_inst, reff476_op in H. discriminate H. Qed.

Lemma reff476_not4291 : ~ @Equation4291 Fin3 reff476_inst.
Proof. unfold Equation4291. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff476_inst, reff476_op in H. discriminate H. Qed.

Lemma reff476_not4293 : ~ @Equation4293 Fin3 reff476_inst.
Proof. unfold Equation4293. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff476_inst, reff476_op in H. discriminate H. Qed.

Lemma reff476_not4314 : ~ @Equation4314 Fin3 reff476_inst.
Proof. unfold Equation4314. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff476_inst, reff476_op in H. discriminate H. Qed.

Lemma reff476_not4320 : ~ @Equation4320 Fin3 reff476_inst.
Proof. unfold Equation4320. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff476_inst, reff476_op in H. discriminate H. Qed.

Lemma reff476_not4321 : ~ @Equation4321 Fin3 reff476_inst.
Proof. unfold Equation4321. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff476_inst, reff476_op in H. discriminate H. Qed.

Lemma reff476_not4396 : ~ @Equation4396 Fin3 reff476_inst.
Proof. unfold Equation4396. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff476_inst, reff476_op in H. discriminate H. Qed.

Lemma reff476_not4399 : ~ @Equation4399 Fin3 reff476_inst.
Proof. unfold Equation4399. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff476_inst, reff476_op in H. discriminate H. Qed.

Lemma reff476_not4406 : ~ @Equation4406 Fin3 reff476_inst.
Proof. unfold Equation4406. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff476_inst, reff476_op in H. discriminate H. Qed.

Lemma reff476_not4408 : ~ @Equation4408 Fin3 reff476_inst.
Proof. unfold Equation4408. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff476_inst, reff476_op in H. discriminate H. Qed.

Lemma reff476_not4433 : ~ @Equation4433 Fin3 reff476_inst.
Proof. unfold Equation4433. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff476_inst, reff476_op in H. discriminate H. Qed.

Lemma reff476_not4436 : ~ @Equation4436 Fin3 reff476_inst.
Proof. unfold Equation4436. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff476_inst, reff476_op in H. discriminate H. Qed.

Lemma reff476_not4443 : ~ @Equation4443 Fin3 reff476_inst.
Proof. unfold Equation4443. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff476_inst, reff476_op in H. discriminate H. Qed.

Lemma reff476_not4445 : ~ @Equation4445 Fin3 reff476_inst.
Proof. unfold Equation4445. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff476_inst, reff476_op in H. discriminate H. Qed.

Lemma reff476_not4472 : ~ @Equation4472 Fin3 reff476_inst.
Proof. unfold Equation4472. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff476_inst, reff476_op in H. discriminate H. Qed.

Lemma reff476_not4473 : ~ @Equation4473 Fin3 reff476_inst.
Proof. unfold Equation4473. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff476_inst, reff476_op in H. discriminate H. Qed.

Lemma reff476_not4479 : ~ @Equation4479 Fin3 reff476_inst.
Proof. unfold Equation4479. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff476_inst, reff476_op in H. discriminate H. Qed.

Lemma reff476_not4480 : ~ @Equation4480 Fin3 reff476_inst.
Proof. unfold Equation4480. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff476_inst, reff476_op in H. discriminate H. Qed.

Lemma reff476_not4583 : ~ @Equation4583 Fin3 reff476_inst.
Proof. unfold Equation4583. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff476_inst, reff476_op in H. discriminate H. Qed.

Lemma reff476_not4584 : ~ @Equation4584 Fin3 reff476_inst.
Proof. unfold Equation4584. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff476_inst, reff476_op in H. discriminate H. Qed.

Lemma reff476_not4587 : ~ @Equation4587 Fin3 reff476_inst.
Proof. unfold Equation4587. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff476_inst, reff476_op in H. discriminate H. Qed.

Lemma reff476_not4590 : ~ @Equation4590 Fin3 reff476_inst.
Proof. unfold Equation4590. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff476_inst, reff476_op in H. discriminate H. Qed.

Lemma reff476_not4591 : ~ @Equation4591 Fin3 reff476_inst.
Proof. unfold Equation4591. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff476_inst, reff476_op in H. discriminate H. Qed.

Lemma reff476_not4598 : ~ @Equation4598 Fin3 reff476_inst.
Proof. unfold Equation4598. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff476_inst, reff476_op in H. discriminate H. Qed.

Lemma reff476_not4599 : ~ @Equation4599 Fin3 reff476_inst.
Proof. unfold Equation4599. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff476_inst, reff476_op in H. discriminate H. Qed.

Lemma reff476_not4605 : ~ @Equation4605 Fin3 reff476_inst.
Proof. unfold Equation4605. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff476_inst, reff476_op in H. discriminate H. Qed.

Lemma reff476_not4606 : ~ @Equation4606 Fin3 reff476_inst.
Proof. unfold Equation4606. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff476_inst, reff476_op in H. discriminate H. Qed.

Lemma reff476_not4629 : ~ @Equation4629 Fin3 reff476_inst.
Proof. unfold Equation4629. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff476_inst, reff476_op in H. discriminate H. Qed.

Lemma reff476_not4636 : ~ @Equation4636 Fin3 reff476_inst.
Proof. unfold Equation4636. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff476_inst, reff476_op in H. discriminate H. Qed.

Lemma reff476_not4658 : ~ @Equation4658 Fin3 reff476_inst.
Proof. unfold Equation4658. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff476_inst, reff476_op in H. discriminate H. Qed.

(** ---- reff482 (Fin5) ---- *)

Definition reff482_op (x y : Fin5) : Fin5 :=
  match x, y with
  | F5_0, F5_0 => F5_0 | F5_0, F5_1 => F5_1 | F5_0, F5_2 => F5_2 | F5_0, F5_3 => F5_3 | F5_0, F5_4 => F5_4
  | F5_1, F5_0 => F5_2 | F5_1, F5_1 => F5_3 | F5_1, F5_2 => F5_4 | F5_1, F5_3 => F5_0 | F5_1, F5_4 => F5_1
  | F5_2, F5_0 => F5_4 | F5_2, F5_1 => F5_0 | F5_2, F5_2 => F5_1 | F5_2, F5_3 => F5_2 | F5_2, F5_4 => F5_3
  | F5_3, F5_0 => F5_1 | F5_3, F5_1 => F5_2 | F5_3, F5_2 => F5_3 | F5_3, F5_3 => F5_4 | F5_3, F5_4 => F5_0
  | F5_4, F5_0 => F5_3 | F5_4, F5_1 => F5_4 | F5_4, F5_2 => F5_0 | F5_4, F5_3 => F5_1 | F5_4, F5_4 => F5_2
  end.

#[local] Instance reff482_inst : Magma Fin5 := {| magma_op := reff482_op |}.

Lemma reff482_sat209 : @Equation209 Fin5 reff482_inst.
Proof. unfold Equation209, magma_op, reff482_inst, reff482_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff482_sat219 : @Equation219 Fin5 reff482_inst.
Proof. unfold Equation219, magma_op, reff482_inst, reff482_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff482_sat231 : @Equation231 Fin5 reff482_inst.
Proof. unfold Equation231, magma_op, reff482_inst, reff482_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff482_sat620 : @Equation620 Fin5 reff482_inst.
Proof. unfold Equation620, magma_op, reff482_inst, reff482_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff482_sat633 : @Equation633 Fin5 reff482_inst.
Proof. unfold Equation633, magma_op, reff482_inst, reff482_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff482_sat670 : @Equation670 Fin5 reff482_inst.
Proof. unfold Equation670, magma_op, reff482_inst, reff482_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff482_sat704 : @Equation704 Fin5 reff482_inst.
Proof. unfold Equation704, magma_op, reff482_inst, reff482_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff482_sat716 : @Equation716 Fin5 reff482_inst.
Proof. unfold Equation716, magma_op, reff482_inst, reff482_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff482_sat826 : @Equation826 Fin5 reff482_inst.
Proof. unfold Equation826, magma_op, reff482_inst, reff482_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff482_sat833 : @Equation833 Fin5 reff482_inst.
Proof. unfold Equation833, magma_op, reff482_inst, reff482_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff482_sat873 : @Equation873 Fin5 reff482_inst.
Proof. unfold Equation873, magma_op, reff482_inst, reff482_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff482_sat880 : @Equation880 Fin5 reff482_inst.
Proof. unfold Equation880, magma_op, reff482_inst, reff482_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff482_sat919 : @Equation919 Fin5 reff482_inst.
Proof. unfold Equation919, magma_op, reff482_inst, reff482_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff482_sat1435 : @Equation1435 Fin5 reff482_inst.
Proof. unfold Equation1435, magma_op, reff482_inst, reff482_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff482_sat1445 : @Equation1445 Fin5 reff482_inst.
Proof. unfold Equation1445, magma_op, reff482_inst, reff482_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff482_sat1452 : @Equation1452 Fin5 reff482_inst.
Proof. unfold Equation1452, magma_op, reff482_inst, reff482_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff482_sat1479 : @Equation1479 Fin5 reff482_inst.
Proof. unfold Equation1479, magma_op, reff482_inst, reff482_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff482_sat1528 : @Equation1528 Fin5 reff482_inst.
Proof. unfold Equation1528, magma_op, reff482_inst, reff482_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff482_sat3140 : @Equation3140 Fin5 reff482_inst.
Proof. unfold Equation3140, magma_op, reff482_inst, reff482_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff482_sat3201 : @Equation3201 Fin5 reff482_inst.
Proof. unfold Equation3201, magma_op, reff482_inst, reff482_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff482_sat4276 : @Equation4276 Fin5 reff482_inst.
Proof. unfold Equation4276, magma_op, reff482_inst, reff482_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff482_sat4588 : @Equation4588 Fin5 reff482_inst.
Proof. unfold Equation4588, magma_op, reff482_inst, reff482_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff482_sat4608 : @Equation4608 Fin5 reff482_inst.
Proof. unfold Equation4608, magma_op, reff482_inst, reff482_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff482_not47 : ~ @Equation47 Fin5 reff482_inst.
Proof. unfold Equation47. intro H. specialize (H F5_1). unfold magma_op, reff482_inst, reff482_op in H. discriminate H. Qed.

Lemma reff482_not99 : ~ @Equation99 Fin5 reff482_inst.
Proof. unfold Equation99. intro H. specialize (H F5_1). unfold magma_op, reff482_inst, reff482_op in H. discriminate H. Qed.

Lemma reff482_not151 : ~ @Equation151 Fin5 reff482_inst.
Proof. unfold Equation151. intro H. specialize (H F5_1). unfold magma_op, reff482_inst, reff482_op in H. discriminate H. Qed.

Lemma reff482_not206 : ~ @Equation206 Fin5 reff482_inst.
Proof. unfold Equation206. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff482_inst, reff482_op in H. discriminate H. Qed.

Lemma reff482_not211 : ~ @Equation211 Fin5 reff482_inst.
Proof. unfold Equation211. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff482_inst, reff482_op in H. discriminate H. Qed.

Lemma reff482_not212 : ~ @Equation212 Fin5 reff482_inst.
Proof. unfold Equation212. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff482_inst, reff482_op in H. discriminate H. Qed.

Lemma reff482_not221 : ~ @Equation221 Fin5 reff482_inst.
Proof. unfold Equation221. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff482_inst, reff482_op in H. discriminate H. Qed.

Lemma reff482_not222 : ~ @Equation222 Fin5 reff482_inst.
Proof. unfold Equation222. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff482_inst, reff482_op in H. discriminate H. Qed.

Lemma reff482_not228 : ~ @Equation228 Fin5 reff482_inst.
Proof. unfold Equation228. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff482_inst, reff482_op in H. discriminate H. Qed.

Lemma reff482_not229 : ~ @Equation229 Fin5 reff482_inst.
Proof. unfold Equation229. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff482_inst, reff482_op in H. discriminate H. Qed.

Lemma reff482_not255 : ~ @Equation255 Fin5 reff482_inst.
Proof. unfold Equation255. intro H. specialize (H F5_1). unfold magma_op, reff482_inst, reff482_op in H. discriminate H. Qed.

Lemma reff482_not411 : ~ @Equation411 Fin5 reff482_inst.
Proof. unfold Equation411. intro H. specialize (H F5_1). unfold magma_op, reff482_inst, reff482_op in H. discriminate H. Qed.

Lemma reff482_not615 : ~ @Equation615 Fin5 reff482_inst.
Proof. unfold Equation615. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff482_inst, reff482_op in H. discriminate H. Qed.

Lemma reff482_not616 : ~ @Equation616 Fin5 reff482_inst.
Proof. unfold Equation616. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff482_inst, reff482_op in H. discriminate H. Qed.

Lemma reff482_not617 : ~ @Equation617 Fin5 reff482_inst.
Proof. unfold Equation617. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff482_inst, reff482_op in H. discriminate H. Qed.

Lemma reff482_not619 : ~ @Equation619 Fin5 reff482_inst.
Proof. unfold Equation619. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff482_inst, reff482_op in H. discriminate H. Qed.

Lemma reff482_not622 : ~ @Equation622 Fin5 reff482_inst.
Proof. unfold Equation622. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff482_inst, reff482_op in H. discriminate H. Qed.

Lemma reff482_not623 : ~ @Equation623 Fin5 reff482_inst.
Proof. unfold Equation623. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff482_inst, reff482_op in H. discriminate H. Qed.

Lemma reff482_not629 : ~ @Equation629 Fin5 reff482_inst.
Proof. unfold Equation629. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff482_inst, reff482_op in H. discriminate H. Qed.

Lemma reff482_not630 : ~ @Equation630 Fin5 reff482_inst.
Proof. unfold Equation630. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff482_inst, reff482_op in H. discriminate H. Qed.

Lemma reff482_not632 : ~ @Equation632 Fin5 reff482_inst.
Proof. unfold Equation632. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff482_inst, reff482_op in H. discriminate H. Qed.

Lemma reff482_not639 : ~ @Equation639 Fin5 reff482_inst.
Proof. unfold Equation639. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff482_inst, reff482_op in H. discriminate H. Qed.

Lemma reff482_not640 : ~ @Equation640 Fin5 reff482_inst.
Proof. unfold Equation640. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff482_inst, reff482_op in H. discriminate H. Qed.

Lemma reff482_not642 : ~ @Equation642 Fin5 reff482_inst.
Proof. unfold Equation642. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff482_inst, reff482_op in H. discriminate H. Qed.

Lemma reff482_not643 : ~ @Equation643 Fin5 reff482_inst.
Proof. unfold Equation643. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff482_inst, reff482_op in H. discriminate H. Qed.

Lemma reff482_not666 : ~ @Equation666 Fin5 reff482_inst.
Proof. unfold Equation666. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff482_inst, reff482_op in H. discriminate H. Qed.

Lemma reff482_not667 : ~ @Equation667 Fin5 reff482_inst.
Proof. unfold Equation667. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff482_inst, reff482_op in H. discriminate H. Qed.

Lemma reff482_not669 : ~ @Equation669 Fin5 reff482_inst.
Proof. unfold Equation669. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff482_inst, reff482_op in H. discriminate H. Qed.

Lemma reff482_not676 : ~ @Equation676 Fin5 reff482_inst.
Proof. unfold Equation676. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff482_inst, reff482_op in H. discriminate H. Qed.

Lemma reff482_not677 : ~ @Equation677 Fin5 reff482_inst.
Proof. unfold Equation677. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff482_inst, reff482_op in H. discriminate H. Qed.

Lemma reff482_not679 : ~ @Equation679 Fin5 reff482_inst.
Proof. unfold Equation679. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff482_inst, reff482_op in H. discriminate H. Qed.

Lemma reff482_not680 : ~ @Equation680 Fin5 reff482_inst.
Proof. unfold Equation680. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff482_inst, reff482_op in H. discriminate H. Qed.

Lemma reff482_not703 : ~ @Equation703 Fin5 reff482_inst.
Proof. unfold Equation703. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff482_inst, reff482_op in H. discriminate H. Qed.

Lemma reff482_not706 : ~ @Equation706 Fin5 reff482_inst.
Proof. unfold Equation706. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff482_inst, reff482_op in H. discriminate H. Qed.

Lemma reff482_not707 : ~ @Equation707 Fin5 reff482_inst.
Proof. unfold Equation707. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff482_inst, reff482_op in H. discriminate H. Qed.

Lemma reff482_not713 : ~ @Equation713 Fin5 reff482_inst.
Proof. unfold Equation713. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff482_inst, reff482_op in H. discriminate H. Qed.

Lemma reff482_not714 : ~ @Equation714 Fin5 reff482_inst.
Proof. unfold Equation714. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff482_inst, reff482_op in H. discriminate H. Qed.

Lemma reff482_not818 : ~ @Equation818 Fin5 reff482_inst.
Proof. unfold Equation818. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff482_inst, reff482_op in H. discriminate H. Qed.

Lemma reff482_not819 : ~ @Equation819 Fin5 reff482_inst.
Proof. unfold Equation819. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff482_inst, reff482_op in H. discriminate H. Qed.

Lemma reff482_not820 : ~ @Equation820 Fin5 reff482_inst.
Proof. unfold Equation820. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff482_inst, reff482_op in H. discriminate H. Qed.

Lemma reff482_not822 : ~ @Equation822 Fin5 reff482_inst.
Proof. unfold Equation822. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff482_inst, reff482_op in H. discriminate H. Qed.

Lemma reff482_not823 : ~ @Equation823 Fin5 reff482_inst.
Proof. unfold Equation823. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff482_inst, reff482_op in H. discriminate H. Qed.

Lemma reff482_not825 : ~ @Equation825 Fin5 reff482_inst.
Proof. unfold Equation825. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff482_inst, reff482_op in H. discriminate H. Qed.

Lemma reff482_not832 : ~ @Equation832 Fin5 reff482_inst.
Proof. unfold Equation832. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff482_inst, reff482_op in H. discriminate H. Qed.

Lemma reff482_not835 : ~ @Equation835 Fin5 reff482_inst.
Proof. unfold Equation835. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff482_inst, reff482_op in H. discriminate H. Qed.

Lemma reff482_not836 : ~ @Equation836 Fin5 reff482_inst.
Proof. unfold Equation836. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff482_inst, reff482_op in H. discriminate H. Qed.

Lemma reff482_not842 : ~ @Equation842 Fin5 reff482_inst.
Proof. unfold Equation842. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff482_inst, reff482_op in H. discriminate H. Qed.

Lemma reff482_not843 : ~ @Equation843 Fin5 reff482_inst.
Proof. unfold Equation843. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff482_inst, reff482_op in H. discriminate H. Qed.

Lemma reff482_not845 : ~ @Equation845 Fin5 reff482_inst.
Proof. unfold Equation845. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff482_inst, reff482_op in H. discriminate H. Qed.

Lemma reff482_not846 : ~ @Equation846 Fin5 reff482_inst.
Proof. unfold Equation846. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff482_inst, reff482_op in H. discriminate H. Qed.

Lemma reff482_not869 : ~ @Equation869 Fin5 reff482_inst.
Proof. unfold Equation869. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff482_inst, reff482_op in H. discriminate H. Qed.

Lemma reff482_not870 : ~ @Equation870 Fin5 reff482_inst.
Proof. unfold Equation870. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff482_inst, reff482_op in H. discriminate H. Qed.

Lemma reff482_not872 : ~ @Equation872 Fin5 reff482_inst.
Proof. unfold Equation872. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff482_inst, reff482_op in H. discriminate H. Qed.

Lemma reff482_not879 : ~ @Equation879 Fin5 reff482_inst.
Proof. unfold Equation879. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff482_inst, reff482_op in H. discriminate H. Qed.

Lemma reff482_not882 : ~ @Equation882 Fin5 reff482_inst.
Proof. unfold Equation882. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff482_inst, reff482_op in H. discriminate H. Qed.

Lemma reff482_not883 : ~ @Equation883 Fin5 reff482_inst.
Proof. unfold Equation883. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff482_inst, reff482_op in H. discriminate H. Qed.

Lemma reff482_not906 : ~ @Equation906 Fin5 reff482_inst.
Proof. unfold Equation906. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff482_inst, reff482_op in H. discriminate H. Qed.

Lemma reff482_not907 : ~ @Equation907 Fin5 reff482_inst.
Proof. unfold Equation907. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff482_inst, reff482_op in H. discriminate H. Qed.

Lemma reff482_not909 : ~ @Equation909 Fin5 reff482_inst.
Proof. unfold Equation909. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff482_inst, reff482_op in H. discriminate H. Qed.

Lemma reff482_not910 : ~ @Equation910 Fin5 reff482_inst.
Proof. unfold Equation910. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff482_inst, reff482_op in H. discriminate H. Qed.

Lemma reff482_not916 : ~ @Equation916 Fin5 reff482_inst.
Proof. unfold Equation916. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff482_inst, reff482_op in H. discriminate H. Qed.

Lemma reff482_not917 : ~ @Equation917 Fin5 reff482_inst.
Proof. unfold Equation917. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff482_inst, reff482_op in H. discriminate H. Qed.

Lemma reff482_not1020 : ~ @Equation1020 Fin5 reff482_inst.
Proof. unfold Equation1020. intro H. specialize (H F5_1). unfold magma_op, reff482_inst, reff482_op in H. discriminate H. Qed.

Lemma reff482_not1223 : ~ @Equation1223 Fin5 reff482_inst.
Proof. unfold Equation1223. intro H. specialize (H F5_1). unfold magma_op, reff482_inst, reff482_op in H. discriminate H. Qed.

Lemma reff482_not1427 : ~ @Equation1427 Fin5 reff482_inst.
Proof. unfold Equation1427. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff482_inst, reff482_op in H. discriminate H. Qed.

Lemma reff482_not1428 : ~ @Equation1428 Fin5 reff482_inst.
Proof. unfold Equation1428. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff482_inst, reff482_op in H. discriminate H. Qed.

Lemma reff482_not1429 : ~ @Equation1429 Fin5 reff482_inst.
Proof. unfold Equation1429. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff482_inst, reff482_op in H. discriminate H. Qed.

Lemma reff482_not1431 : ~ @Equation1431 Fin5 reff482_inst.
Proof. unfold Equation1431. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff482_inst, reff482_op in H. discriminate H. Qed.

Lemma reff482_not1432 : ~ @Equation1432 Fin5 reff482_inst.
Proof. unfold Equation1432. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff482_inst, reff482_op in H. discriminate H. Qed.

Lemma reff482_not1434 : ~ @Equation1434 Fin5 reff482_inst.
Proof. unfold Equation1434. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff482_inst, reff482_op in H. discriminate H. Qed.

Lemma reff482_not1441 : ~ @Equation1441 Fin5 reff482_inst.
Proof. unfold Equation1441. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff482_inst, reff482_op in H. discriminate H. Qed.

Lemma reff482_not1442 : ~ @Equation1442 Fin5 reff482_inst.
Proof. unfold Equation1442. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff482_inst, reff482_op in H. discriminate H. Qed.

Lemma reff482_not1444 : ~ @Equation1444 Fin5 reff482_inst.
Proof. unfold Equation1444. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff482_inst, reff482_op in H. discriminate H. Qed.

Lemma reff482_not1451 : ~ @Equation1451 Fin5 reff482_inst.
Proof. unfold Equation1451. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff482_inst, reff482_op in H. discriminate H. Qed.

Lemma reff482_not1454 : ~ @Equation1454 Fin5 reff482_inst.
Proof. unfold Equation1454. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff482_inst, reff482_op in H. discriminate H. Qed.

Lemma reff482_not1455 : ~ @Equation1455 Fin5 reff482_inst.
Proof. unfold Equation1455. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff482_inst, reff482_op in H. discriminate H. Qed.

Lemma reff482_not1478 : ~ @Equation1478 Fin5 reff482_inst.
Proof. unfold Equation1478. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff482_inst, reff482_op in H. discriminate H. Qed.

Lemma reff482_not1481 : ~ @Equation1481 Fin5 reff482_inst.
Proof. unfold Equation1481. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff482_inst, reff482_op in H. discriminate H. Qed.

Lemma reff482_not1482 : ~ @Equation1482 Fin5 reff482_inst.
Proof. unfold Equation1482. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff482_inst, reff482_op in H. discriminate H. Qed.

Lemma reff482_not1488 : ~ @Equation1488 Fin5 reff482_inst.
Proof. unfold Equation1488. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff482_inst, reff482_op in H. discriminate H. Qed.

Lemma reff482_not1489 : ~ @Equation1489 Fin5 reff482_inst.
Proof. unfold Equation1489. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff482_inst, reff482_op in H. discriminate H. Qed.

Lemma reff482_not1491 : ~ @Equation1491 Fin5 reff482_inst.
Proof. unfold Equation1491. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff482_inst, reff482_op in H. discriminate H. Qed.

Lemma reff482_not1492 : ~ @Equation1492 Fin5 reff482_inst.
Proof. unfold Equation1492. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff482_inst, reff482_op in H. discriminate H. Qed.

Lemma reff482_not1515 : ~ @Equation1515 Fin5 reff482_inst.
Proof. unfold Equation1515. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff482_inst, reff482_op in H. discriminate H. Qed.

Lemma reff482_not1516 : ~ @Equation1516 Fin5 reff482_inst.
Proof. unfold Equation1516. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff482_inst, reff482_op in H. discriminate H. Qed.

Lemma reff482_not1518 : ~ @Equation1518 Fin5 reff482_inst.
Proof. unfold Equation1518. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff482_inst, reff482_op in H. discriminate H. Qed.

Lemma reff482_not1519 : ~ @Equation1519 Fin5 reff482_inst.
Proof. unfold Equation1519. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff482_inst, reff482_op in H. discriminate H. Qed.

Lemma reff482_not1525 : ~ @Equation1525 Fin5 reff482_inst.
Proof. unfold Equation1525. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff482_inst, reff482_op in H. discriminate H. Qed.

Lemma reff482_not1526 : ~ @Equation1526 Fin5 reff482_inst.
Proof. unfold Equation1526. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff482_inst, reff482_op in H. discriminate H. Qed.

Lemma reff482_not1629 : ~ @Equation1629 Fin5 reff482_inst.
Proof. unfold Equation1629. intro H. specialize (H F5_1). unfold magma_op, reff482_inst, reff482_op in H. discriminate H. Qed.

Lemma reff482_not1832 : ~ @Equation1832 Fin5 reff482_inst.
Proof. unfold Equation1832. intro H. specialize (H F5_1). unfold magma_op, reff482_inst, reff482_op in H. discriminate H. Qed.

Lemma reff482_not2035 : ~ @Equation2035 Fin5 reff482_inst.
Proof. unfold Equation2035. intro H. specialize (H F5_1). unfold magma_op, reff482_inst, reff482_op in H. discriminate H. Qed.

Lemma reff482_not2238 : ~ @Equation2238 Fin5 reff482_inst.
Proof. unfold Equation2238. intro H. specialize (H F5_1). unfold magma_op, reff482_inst, reff482_op in H. discriminate H. Qed.

Lemma reff482_not2441 : ~ @Equation2441 Fin5 reff482_inst.
Proof. unfold Equation2441. intro H. specialize (H F5_1). unfold magma_op, reff482_inst, reff482_op in H. discriminate H. Qed.

Lemma reff482_not2644 : ~ @Equation2644 Fin5 reff482_inst.
Proof. unfold Equation2644. intro H. specialize (H F5_1). unfold magma_op, reff482_inst, reff482_op in H. discriminate H. Qed.

Lemma reff482_not2847 : ~ @Equation2847 Fin5 reff482_inst.
Proof. unfold Equation2847. intro H. specialize (H F5_1). unfold magma_op, reff482_inst, reff482_op in H. discriminate H. Qed.

Lemma reff482_not3051 : ~ @Equation3051 Fin5 reff482_inst.
Proof. unfold Equation3051. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff482_inst, reff482_op in H. discriminate H. Qed.

Lemma reff482_not3052 : ~ @Equation3052 Fin5 reff482_inst.
Proof. unfold Equation3052. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff482_inst, reff482_op in H. discriminate H. Qed.

Lemma reff482_not3053 : ~ @Equation3053 Fin5 reff482_inst.
Proof. unfold Equation3053. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff482_inst, reff482_op in H. discriminate H. Qed.

Lemma reff482_not3055 : ~ @Equation3055 Fin5 reff482_inst.
Proof. unfold Equation3055. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff482_inst, reff482_op in H. discriminate H. Qed.

Lemma reff482_not3058 : ~ @Equation3058 Fin5 reff482_inst.
Proof. unfold Equation3058. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff482_inst, reff482_op in H. discriminate H. Qed.

Lemma reff482_not3059 : ~ @Equation3059 Fin5 reff482_inst.
Proof. unfold Equation3059. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff482_inst, reff482_op in H. discriminate H. Qed.

Lemma reff482_not3065 : ~ @Equation3065 Fin5 reff482_inst.
Proof. unfold Equation3065. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff482_inst, reff482_op in H. discriminate H. Qed.

Lemma reff482_not3066 : ~ @Equation3066 Fin5 reff482_inst.
Proof. unfold Equation3066. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff482_inst, reff482_op in H. discriminate H. Qed.

Lemma reff482_not3069 : ~ @Equation3069 Fin5 reff482_inst.
Proof. unfold Equation3069. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff482_inst, reff482_op in H. discriminate H. Qed.

Lemma reff482_not3075 : ~ @Equation3075 Fin5 reff482_inst.
Proof. unfold Equation3075. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff482_inst, reff482_op in H. discriminate H. Qed.

Lemma reff482_not3076 : ~ @Equation3076 Fin5 reff482_inst.
Proof. unfold Equation3076. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff482_inst, reff482_op in H. discriminate H. Qed.

Lemma reff482_not3078 : ~ @Equation3078 Fin5 reff482_inst.
Proof. unfold Equation3078. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff482_inst, reff482_op in H. discriminate H. Qed.

Lemma reff482_not3102 : ~ @Equation3102 Fin5 reff482_inst.
Proof. unfold Equation3102. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff482_inst, reff482_op in H. discriminate H. Qed.

Lemma reff482_not3103 : ~ @Equation3103 Fin5 reff482_inst.
Proof. unfold Equation3103. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff482_inst, reff482_op in H. discriminate H. Qed.

Lemma reff482_not3105 : ~ @Equation3105 Fin5 reff482_inst.
Proof. unfold Equation3105. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff482_inst, reff482_op in H. discriminate H. Qed.

Lemma reff482_not3106 : ~ @Equation3106 Fin5 reff482_inst.
Proof. unfold Equation3106. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff482_inst, reff482_op in H. discriminate H. Qed.

Lemma reff482_not3113 : ~ @Equation3113 Fin5 reff482_inst.
Proof. unfold Equation3113. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff482_inst, reff482_op in H. discriminate H. Qed.

Lemma reff482_not3115 : ~ @Equation3115 Fin5 reff482_inst.
Proof. unfold Equation3115. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff482_inst, reff482_op in H. discriminate H. Qed.

Lemma reff482_not3116 : ~ @Equation3116 Fin5 reff482_inst.
Proof. unfold Equation3116. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff482_inst, reff482_op in H. discriminate H. Qed.

Lemma reff482_not3139 : ~ @Equation3139 Fin5 reff482_inst.
Proof. unfold Equation3139. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff482_inst, reff482_op in H. discriminate H. Qed.

Lemma reff482_not3142 : ~ @Equation3142 Fin5 reff482_inst.
Proof. unfold Equation3142. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff482_inst, reff482_op in H. discriminate H. Qed.

Lemma reff482_not3143 : ~ @Equation3143 Fin5 reff482_inst.
Proof. unfold Equation3143. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff482_inst, reff482_op in H. discriminate H. Qed.

Lemma reff482_not3149 : ~ @Equation3149 Fin5 reff482_inst.
Proof. unfold Equation3149. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff482_inst, reff482_op in H. discriminate H. Qed.

Lemma reff482_not3150 : ~ @Equation3150 Fin5 reff482_inst.
Proof. unfold Equation3150. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff482_inst, reff482_op in H. discriminate H. Qed.

Lemma reff482_not3253 : ~ @Equation3253 Fin5 reff482_inst.
Proof. unfold Equation3253. intro H. specialize (H F5_1). unfold magma_op, reff482_inst, reff482_op in H. discriminate H. Qed.

Lemma reff482_not3456 : ~ @Equation3456 Fin5 reff482_inst.
Proof. unfold Equation3456. intro H. specialize (H F5_1). unfold magma_op, reff482_inst, reff482_op in H. discriminate H. Qed.

Lemma reff482_not3659 : ~ @Equation3659 Fin5 reff482_inst.
Proof. unfold Equation3659. intro H. specialize (H F5_1). unfold magma_op, reff482_inst, reff482_op in H. discriminate H. Qed.

Lemma reff482_not3862 : ~ @Equation3862 Fin5 reff482_inst.
Proof. unfold Equation3862. intro H. specialize (H F5_1). unfold magma_op, reff482_inst, reff482_op in H. discriminate H. Qed.

Lemma reff482_not4065 : ~ @Equation4065 Fin5 reff482_inst.
Proof. unfold Equation4065. intro H. specialize (H F5_1). unfold magma_op, reff482_inst, reff482_op in H. discriminate H. Qed.

Lemma reff482_not4268 : ~ @Equation4268 Fin5 reff482_inst.
Proof. unfold Equation4268. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff482_inst, reff482_op in H. discriminate H. Qed.

Lemma reff482_not4269 : ~ @Equation4269 Fin5 reff482_inst.
Proof. unfold Equation4269. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff482_inst, reff482_op in H. discriminate H. Qed.

Lemma reff482_not4270 : ~ @Equation4270 Fin5 reff482_inst.
Proof. unfold Equation4270. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff482_inst, reff482_op in H. discriminate H. Qed.

Lemma reff482_not4272 : ~ @Equation4272 Fin5 reff482_inst.
Proof. unfold Equation4272. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff482_inst, reff482_op in H. discriminate H. Qed.

Lemma reff482_not4273 : ~ @Equation4273 Fin5 reff482_inst.
Proof. unfold Equation4273. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff482_inst, reff482_op in H. discriminate H. Qed.

Lemma reff482_not4275 : ~ @Equation4275 Fin5 reff482_inst.
Proof. unfold Equation4275. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff482_inst, reff482_op in H. discriminate H. Qed.

Lemma reff482_not4283 : ~ @Equation4283 Fin5 reff482_inst.
Proof. unfold Equation4283. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff482_inst, reff482_op in H. discriminate H. Qed.

Lemma reff482_not4284 : ~ @Equation4284 Fin5 reff482_inst.
Proof. unfold Equation4284. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff482_inst, reff482_op in H. discriminate H. Qed.

Lemma reff482_not4290 : ~ @Equation4290 Fin5 reff482_inst.
Proof. unfold Equation4290. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff482_inst, reff482_op in H. discriminate H. Qed.

Lemma reff482_not4291 : ~ @Equation4291 Fin5 reff482_inst.
Proof. unfold Equation4291. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff482_inst, reff482_op in H. discriminate H. Qed.

Lemma reff482_not4293 : ~ @Equation4293 Fin5 reff482_inst.
Proof. unfold Equation4293. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff482_inst, reff482_op in H. discriminate H. Qed.

Lemma reff482_not4314 : ~ @Equation4314 Fin5 reff482_inst.
Proof. unfold Equation4314. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff482_inst, reff482_op in H. discriminate H. Qed.

Lemma reff482_not4321 : ~ @Equation4321 Fin5 reff482_inst.
Proof. unfold Equation4321. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff482_inst, reff482_op in H. discriminate H. Qed.

Lemma reff482_not4343 : ~ @Equation4343 Fin5 reff482_inst.
Proof. unfold Equation4343. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff482_inst, reff482_op in H. discriminate H. Qed.

Lemma reff482_not4380 : ~ @Equation4380 Fin5 reff482_inst.
Proof. unfold Equation4380. intro H. specialize (H F5_1). unfold magma_op, reff482_inst, reff482_op in H. discriminate H. Qed.

Lemma reff482_not4583 : ~ @Equation4583 Fin5 reff482_inst.
Proof. unfold Equation4583. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff482_inst, reff482_op in H. discriminate H. Qed.

Lemma reff482_not4584 : ~ @Equation4584 Fin5 reff482_inst.
Proof. unfold Equation4584. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff482_inst, reff482_op in H. discriminate H. Qed.

Lemma reff482_not4585 : ~ @Equation4585 Fin5 reff482_inst.
Proof. unfold Equation4585. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff482_inst, reff482_op in H. discriminate H. Qed.

Lemma reff482_not4587 : ~ @Equation4587 Fin5 reff482_inst.
Proof. unfold Equation4587. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff482_inst, reff482_op in H. discriminate H. Qed.

Lemma reff482_not4590 : ~ @Equation4590 Fin5 reff482_inst.
Proof. unfold Equation4590. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff482_inst, reff482_op in H. discriminate H. Qed.

Lemma reff482_not4591 : ~ @Equation4591 Fin5 reff482_inst.
Proof. unfold Equation4591. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff482_inst, reff482_op in H. discriminate H. Qed.

Lemma reff482_not4598 : ~ @Equation4598 Fin5 reff482_inst.
Proof. unfold Equation4598. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff482_inst, reff482_op in H. discriminate H. Qed.

Lemma reff482_not4599 : ~ @Equation4599 Fin5 reff482_inst.
Proof. unfold Equation4599. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff482_inst, reff482_op in H. discriminate H. Qed.

Lemma reff482_not4605 : ~ @Equation4605 Fin5 reff482_inst.
Proof. unfold Equation4605. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff482_inst, reff482_op in H. discriminate H. Qed.

Lemma reff482_not4606 : ~ @Equation4606 Fin5 reff482_inst.
Proof. unfold Equation4606. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff482_inst, reff482_op in H. discriminate H. Qed.

Lemma reff482_not4629 : ~ @Equation4629 Fin5 reff482_inst.
Proof. unfold Equation4629. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff482_inst, reff482_op in H. discriminate H. Qed.

Lemma reff482_not4635 : ~ @Equation4635 Fin5 reff482_inst.
Proof. unfold Equation4635. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff482_inst, reff482_op in H. discriminate H. Qed.

Lemma reff482_not4636 : ~ @Equation4636 Fin5 reff482_inst.
Proof. unfold Equation4636. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff482_inst, reff482_op in H. discriminate H. Qed.

Lemma reff482_not4658 : ~ @Equation4658 Fin5 reff482_inst.
Proof. unfold Equation4658. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff482_inst, reff482_op in H. discriminate H. Qed.

(** ---- reff488 (Fin5) ---- *)

Definition reff488_op (x y : Fin5) : Fin5 :=
  match x, y with
  | F5_0, F5_0 => F5_0 | F5_0, F5_1 => F5_0 | F5_0, F5_2 => F5_1 | F5_0, F5_3 => F5_3 | F5_0, F5_4 => F5_1
  | F5_1, F5_0 => F5_2 | F5_1, F5_1 => F5_1 | F5_1, F5_2 => F5_1 | F5_1, F5_3 => F5_2 | F5_1, F5_4 => F5_4
  | F5_2, F5_0 => F5_0 | F5_2, F5_1 => F5_3 | F5_2, F5_2 => F5_2 | F5_2, F5_3 => F5_2 | F5_2, F5_4 => F5_3
  | F5_3, F5_0 => F5_4 | F5_3, F5_1 => F5_1 | F5_3, F5_2 => F5_4 | F5_3, F5_3 => F5_3 | F5_3, F5_4 => F5_3
  | F5_4, F5_0 => F5_4 | F5_4, F5_1 => F5_0 | F5_4, F5_2 => F5_2 | F5_4, F5_3 => F5_0 | F5_4, F5_4 => F5_4
  end.

#[local] Instance reff488_inst : Magma Fin5 := {| magma_op := reff488_op |}.

Lemma reff488_sat49 : @Equation49 Fin5 reff488_inst.
Proof. unfold Equation49, magma_op, reff488_inst, reff488_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff488_sat167 : @Equation167 Fin5 reff488_inst.
Proof. unfold Equation167, magma_op, reff488_inst, reff488_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff488_sat413 : @Equation413 Fin5 reff488_inst.
Proof. unfold Equation413, magma_op, reff488_inst, reff488_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff488_sat416 : @Equation416 Fin5 reff488_inst.
Proof. unfold Equation416, magma_op, reff488_inst, reff488_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff488_sat429 : @Equation429 Fin5 reff488_inst.
Proof. unfold Equation429, magma_op, reff488_inst, reff488_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff488_sat819 : @Equation819 Fin5 reff488_inst.
Proof. unfold Equation819, magma_op, reff488_inst, reff488_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff488_sat833 : @Equation833 Fin5 reff488_inst.
Proof. unfold Equation833, magma_op, reff488_inst, reff488_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff488_sat1428 : @Equation1428 Fin5 reff488_inst.
Proof. unfold Equation1428, magma_op, reff488_inst, reff488_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff488_sat1482 : @Equation1482 Fin5 reff488_inst.
Proof. unfold Equation1482, magma_op, reff488_inst, reff488_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff488_sat1682 : @Equation1682 Fin5 reff488_inst.
Proof. unfold Equation1682, magma_op, reff488_inst, reff488_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff488_sat1885 : @Equation1885 Fin5 reff488_inst.
Proof. unfold Equation1885, magma_op, reff488_inst, reff488_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff488_sat2088 : @Equation2088 Fin5 reff488_inst.
Proof. unfold Equation2088, magma_op, reff488_inst, reff488_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff488_sat2125 : @Equation2125 Fin5 reff488_inst.
Proof. unfold Equation2125, magma_op, reff488_inst, reff488_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff488_sat2243 : @Equation2243 Fin5 reff488_inst.
Proof. unfold Equation2243, magma_op, reff488_inst, reff488_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff488_sat2699 : @Equation2699 Fin5 reff488_inst.
Proof. unfold Equation2699, magma_op, reff488_inst, reff488_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff488_sat2862 : @Equation2862 Fin5 reff488_inst.
Proof. unfold Equation2862, magma_op, reff488_inst, reff488_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff488_sat3255 : @Equation3255 Fin5 reff488_inst.
Proof. unfold Equation3255, magma_op, reff488_inst, reff488_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff488_sat3675 : @Equation3675 Fin5 reff488_inst.
Proof. unfold Equation3675, magma_op, reff488_inst, reff488_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff488_sat3918 : @Equation3918 Fin5 reff488_inst.
Proof. unfold Equation3918, magma_op, reff488_inst, reff488_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff488_not50 : ~ @Equation50 Fin5 reff488_inst.
Proof. unfold Equation50. intro H. specialize (H F5_0 F5_3). unfold magma_op, reff488_inst, reff488_op in H. discriminate H. Qed.

Lemma reff488_not53 : ~ @Equation53 Fin5 reff488_inst.
Proof. unfold Equation53. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff488_inst, reff488_op in H. discriminate H. Qed.

Lemma reff488_not55 : ~ @Equation55 Fin5 reff488_inst.
Proof. unfold Equation55. intro H. specialize (H F5_0 F5_3). unfold magma_op, reff488_inst, reff488_op in H. discriminate H. Qed.

Lemma reff488_not56 : ~ @Equation56 Fin5 reff488_inst.
Proof. unfold Equation56. intro H. specialize (H F5_0 F5_2). unfold magma_op, reff488_inst, reff488_op in H. discriminate H. Qed.

Lemma reff488_not63 : ~ @Equation63 Fin5 reff488_inst.
Proof. unfold Equation63. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff488_inst, reff488_op in H. discriminate H. Qed.

Lemma reff488_not65 : ~ @Equation65 Fin5 reff488_inst.
Proof. unfold Equation65. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff488_inst, reff488_op in H. discriminate H. Qed.

Lemma reff488_not66 : ~ @Equation66 Fin5 reff488_inst.
Proof. unfold Equation66. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff488_inst, reff488_op in H. discriminate H. Qed.

Lemma reff488_not72 : ~ @Equation72 Fin5 reff488_inst.
Proof. unfold Equation72. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff488_inst, reff488_op in H. discriminate H. Qed.

Lemma reff488_not73 : ~ @Equation73 Fin5 reff488_inst.
Proof. unfold Equation73. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff488_inst, reff488_op in H. discriminate H. Qed.

Lemma reff488_not75 : ~ @Equation75 Fin5 reff488_inst.
Proof. unfold Equation75. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff488_inst, reff488_op in H. discriminate H. Qed.

Lemma reff488_not102 : ~ @Equation102 Fin5 reff488_inst.
Proof. unfold Equation102. intro H. specialize (H F5_0 F5_3). unfold magma_op, reff488_inst, reff488_op in H. discriminate H. Qed.

Lemma reff488_not105 : ~ @Equation105 Fin5 reff488_inst.
Proof. unfold Equation105. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff488_inst, reff488_op in H. discriminate H. Qed.

Lemma reff488_not107 : ~ @Equation107 Fin5 reff488_inst.
Proof. unfold Equation107. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff488_inst, reff488_op in H. discriminate H. Qed.

Lemma reff488_not108 : ~ @Equation108 Fin5 reff488_inst.
Proof. unfold Equation108. intro H. specialize (H F5_0 F5_2). unfold magma_op, reff488_inst, reff488_op in H. discriminate H. Qed.

Lemma reff488_not115 : ~ @Equation115 Fin5 reff488_inst.
Proof. unfold Equation115. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff488_inst, reff488_op in H. discriminate H. Qed.

Lemma reff488_not117 : ~ @Equation117 Fin5 reff488_inst.
Proof. unfold Equation117. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff488_inst, reff488_op in H. discriminate H. Qed.

Lemma reff488_not118 : ~ @Equation118 Fin5 reff488_inst.
Proof. unfold Equation118. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff488_inst, reff488_op in H. discriminate H. Qed.

Lemma reff488_not124 : ~ @Equation124 Fin5 reff488_inst.
Proof. unfold Equation124. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff488_inst, reff488_op in H. discriminate H. Qed.

Lemma reff488_not125 : ~ @Equation125 Fin5 reff488_inst.
Proof. unfold Equation125. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff488_inst, reff488_op in H. discriminate H. Qed.

Lemma reff488_not127 : ~ @Equation127 Fin5 reff488_inst.
Proof. unfold Equation127. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff488_inst, reff488_op in H. discriminate H. Qed.

Lemma reff488_not154 : ~ @Equation154 Fin5 reff488_inst.
Proof. unfold Equation154. intro H. specialize (H F5_0 F5_2). unfold magma_op, reff488_inst, reff488_op in H. discriminate H. Qed.

Lemma reff488_not157 : ~ @Equation157 Fin5 reff488_inst.
Proof. unfold Equation157. intro H. specialize (H F5_0 F5_2). unfold magma_op, reff488_inst, reff488_op in H. discriminate H. Qed.

Lemma reff488_not159 : ~ @Equation159 Fin5 reff488_inst.
Proof. unfold Equation159. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff488_inst, reff488_op in H. discriminate H. Qed.

Lemma reff488_not160 : ~ @Equation160 Fin5 reff488_inst.
Proof. unfold Equation160. intro H. specialize (H F5_0 F5_2). unfold magma_op, reff488_inst, reff488_op in H. discriminate H. Qed.

Lemma reff488_not169 : ~ @Equation169 Fin5 reff488_inst.
Proof. unfold Equation169. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff488_inst, reff488_op in H. discriminate H. Qed.

Lemma reff488_not170 : ~ @Equation170 Fin5 reff488_inst.
Proof. unfold Equation170. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff488_inst, reff488_op in H. discriminate H. Qed.

Lemma reff488_not176 : ~ @Equation176 Fin5 reff488_inst.
Proof. unfold Equation176. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff488_inst, reff488_op in H. discriminate H. Qed.

Lemma reff488_not177 : ~ @Equation177 Fin5 reff488_inst.
Proof. unfold Equation177. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff488_inst, reff488_op in H. discriminate H. Qed.

Lemma reff488_not179 : ~ @Equation179 Fin5 reff488_inst.
Proof. unfold Equation179. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff488_inst, reff488_op in H. discriminate H. Qed.

Lemma reff488_not206 : ~ @Equation206 Fin5 reff488_inst.
Proof. unfold Equation206. intro H. specialize (H F5_0 F5_2). unfold magma_op, reff488_inst, reff488_op in H. discriminate H. Qed.

Lemma reff488_not209 : ~ @Equation209 Fin5 reff488_inst.
Proof. unfold Equation209. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff488_inst, reff488_op in H. discriminate H. Qed.

Lemma reff488_not211 : ~ @Equation211 Fin5 reff488_inst.
Proof. unfold Equation211. intro H. specialize (H F5_0 F5_2). unfold magma_op, reff488_inst, reff488_op in H. discriminate H. Qed.

Lemma reff488_not212 : ~ @Equation212 Fin5 reff488_inst.
Proof. unfold Equation212. intro H. specialize (H F5_0 F5_2). unfold magma_op, reff488_inst, reff488_op in H. discriminate H. Qed.

Lemma reff488_not219 : ~ @Equation219 Fin5 reff488_inst.
Proof. unfold Equation219. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff488_inst, reff488_op in H. discriminate H. Qed.

Lemma reff488_not221 : ~ @Equation221 Fin5 reff488_inst.
Proof. unfold Equation221. intro H. specialize (H F5_0 F5_2). unfold magma_op, reff488_inst, reff488_op in H. discriminate H. Qed.

Lemma reff488_not222 : ~ @Equation222 Fin5 reff488_inst.
Proof. unfold Equation222. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff488_inst, reff488_op in H. discriminate H. Qed.

Lemma reff488_not228 : ~ @Equation228 Fin5 reff488_inst.
Proof. unfold Equation228. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff488_inst, reff488_op in H. discriminate H. Qed.

Lemma reff488_not229 : ~ @Equation229 Fin5 reff488_inst.
Proof. unfold Equation229. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff488_inst, reff488_op in H. discriminate H. Qed.

Lemma reff488_not231 : ~ @Equation231 Fin5 reff488_inst.
Proof. unfold Equation231. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff488_inst, reff488_op in H. discriminate H. Qed.

Lemma reff488_not258 : ~ @Equation258 Fin5 reff488_inst.
Proof. unfold Equation258. intro H. specialize (H F5_0 F5_2). unfold magma_op, reff488_inst, reff488_op in H. discriminate H. Qed.

Lemma reff488_not261 : ~ @Equation261 Fin5 reff488_inst.
Proof. unfold Equation261. intro H. specialize (H F5_0 F5_2). unfold magma_op, reff488_inst, reff488_op in H. discriminate H. Qed.

Lemma reff488_not263 : ~ @Equation263 Fin5 reff488_inst.
Proof. unfold Equation263. intro H. specialize (H F5_0 F5_2). unfold magma_op, reff488_inst, reff488_op in H. discriminate H. Qed.

Lemma reff488_not264 : ~ @Equation264 Fin5 reff488_inst.
Proof. unfold Equation264. intro H. specialize (H F5_0 F5_2). unfold magma_op, reff488_inst, reff488_op in H. discriminate H. Qed.

Lemma reff488_not271 : ~ @Equation271 Fin5 reff488_inst.
Proof. unfold Equation271. intro H. specialize (H F5_0 F5_2). unfold magma_op, reff488_inst, reff488_op in H. discriminate H. Qed.

Lemma reff488_not273 : ~ @Equation273 Fin5 reff488_inst.
Proof. unfold Equation273. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff488_inst, reff488_op in H. discriminate H. Qed.

Lemma reff488_not274 : ~ @Equation274 Fin5 reff488_inst.
Proof. unfold Equation274. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff488_inst, reff488_op in H. discriminate H. Qed.

Lemma reff488_not280 : ~ @Equation280 Fin5 reff488_inst.
Proof. unfold Equation280. intro H. specialize (H F5_0 F5_3). unfold magma_op, reff488_inst, reff488_op in H. discriminate H. Qed.

Lemma reff488_not281 : ~ @Equation281 Fin5 reff488_inst.
Proof. unfold Equation281. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff488_inst, reff488_op in H. discriminate H. Qed.

Lemma reff488_not283 : ~ @Equation283 Fin5 reff488_inst.
Proof. unfold Equation283. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff488_inst, reff488_op in H. discriminate H. Qed.

Lemma reff488_not412 : ~ @Equation412 Fin5 reff488_inst.
Proof. unfold Equation412. intro H. specialize (H F5_0 F5_3). unfold magma_op, reff488_inst, reff488_op in H. discriminate H. Qed.

Lemma reff488_not414 : ~ @Equation414 Fin5 reff488_inst.
Proof. unfold Equation414. intro H. specialize (H F5_0 F5_3). unfold magma_op, reff488_inst, reff488_op in H. discriminate H. Qed.

Lemma reff488_not417 : ~ @Equation417 Fin5 reff488_inst.
Proof. unfold Equation417. intro H. specialize (H F5_0 F5_2). unfold magma_op, reff488_inst, reff488_op in H. discriminate H. Qed.

Lemma reff488_not419 : ~ @Equation419 Fin5 reff488_inst.
Proof. unfold Equation419. intro H. specialize (H F5_0 F5_3). unfold magma_op, reff488_inst, reff488_op in H. discriminate H. Qed.

Lemma reff488_not420 : ~ @Equation420 Fin5 reff488_inst.
Proof. unfold Equation420. intro H. specialize (H F5_0 F5_3). unfold magma_op, reff488_inst, reff488_op in H. discriminate H. Qed.

Lemma reff488_not426 : ~ @Equation426 Fin5 reff488_inst.
Proof. unfold Equation426. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff488_inst, reff488_op in H. discriminate H. Qed.

Lemma reff488_not427 : ~ @Equation427 Fin5 reff488_inst.
Proof. unfold Equation427. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff488_inst, reff488_op in H. discriminate H. Qed.

Lemma reff488_not430 : ~ @Equation430 Fin5 reff488_inst.
Proof. unfold Equation430. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff488_inst, reff488_op in H. discriminate H. Qed.

Lemma reff488_not436 : ~ @Equation436 Fin5 reff488_inst.
Proof. unfold Equation436. intro H. specialize (H F5_0 F5_3). unfold magma_op, reff488_inst, reff488_op in H. discriminate H. Qed.

Lemma reff488_not437 : ~ @Equation437 Fin5 reff488_inst.
Proof. unfold Equation437. intro H. specialize (H F5_0 F5_2). unfold magma_op, reff488_inst, reff488_op in H. discriminate H. Qed.

Lemma reff488_not439 : ~ @Equation439 Fin5 reff488_inst.
Proof. unfold Equation439. intro H. specialize (H F5_0 F5_3). unfold magma_op, reff488_inst, reff488_op in H. discriminate H. Qed.

Lemma reff488_not440 : ~ @Equation440 Fin5 reff488_inst.
Proof. unfold Equation440. intro H. specialize (H F5_0 F5_2). unfold magma_op, reff488_inst, reff488_op in H. discriminate H. Qed.

Lemma reff488_not463 : ~ @Equation463 Fin5 reff488_inst.
Proof. unfold Equation463. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff488_inst, reff488_op in H. discriminate H. Qed.

Lemma reff488_not464 : ~ @Equation464 Fin5 reff488_inst.
Proof. unfold Equation464. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff488_inst, reff488_op in H. discriminate H. Qed.

Lemma reff488_not466 : ~ @Equation466 Fin5 reff488_inst.
Proof. unfold Equation466. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff488_inst, reff488_op in H. discriminate H. Qed.

Lemma reff488_not467 : ~ @Equation467 Fin5 reff488_inst.
Proof. unfold Equation467. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff488_inst, reff488_op in H. discriminate H. Qed.

Lemma reff488_not473 : ~ @Equation473 Fin5 reff488_inst.
Proof. unfold Equation473. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff488_inst, reff488_op in H. discriminate H. Qed.

Lemma reff488_not474 : ~ @Equation474 Fin5 reff488_inst.
Proof. unfold Equation474. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff488_inst, reff488_op in H. discriminate H. Qed.

Lemma reff488_not476 : ~ @Equation476 Fin5 reff488_inst.
Proof. unfold Equation476. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff488_inst, reff488_op in H. discriminate H. Qed.

Lemma reff488_not477 : ~ @Equation477 Fin5 reff488_inst.
Proof. unfold Equation477. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff488_inst, reff488_op in H. discriminate H. Qed.

Lemma reff488_not500 : ~ @Equation500 Fin5 reff488_inst.
Proof. unfold Equation500. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff488_inst, reff488_op in H. discriminate H. Qed.

Lemma reff488_not501 : ~ @Equation501 Fin5 reff488_inst.
Proof. unfold Equation501. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff488_inst, reff488_op in H. discriminate H. Qed.

Lemma reff488_not503 : ~ @Equation503 Fin5 reff488_inst.
Proof. unfold Equation503. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff488_inst, reff488_op in H. discriminate H. Qed.

Lemma reff488_not504 : ~ @Equation504 Fin5 reff488_inst.
Proof. unfold Equation504. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff488_inst, reff488_op in H. discriminate H. Qed.

Lemma reff488_not510 : ~ @Equation510 Fin5 reff488_inst.
Proof. unfold Equation510. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff488_inst, reff488_op in H. discriminate H. Qed.

Lemma reff488_not511 : ~ @Equation511 Fin5 reff488_inst.
Proof. unfold Equation511. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff488_inst, reff488_op in H. discriminate H. Qed.

Lemma reff488_not513 : ~ @Equation513 Fin5 reff488_inst.
Proof. unfold Equation513. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff488_inst, reff488_op in H. discriminate H. Qed.

Lemma reff488_not615 : ~ @Equation615 Fin5 reff488_inst.
Proof. unfold Equation615. intro H. specialize (H F5_0 F5_3). unfold magma_op, reff488_inst, reff488_op in H. discriminate H. Qed.

Lemma reff488_not617 : ~ @Equation617 Fin5 reff488_inst.
Proof. unfold Equation617. intro H. specialize (H F5_0 F5_3). unfold magma_op, reff488_inst, reff488_op in H. discriminate H. Qed.

Lemma reff488_not620 : ~ @Equation620 Fin5 reff488_inst.
Proof. unfold Equation620. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff488_inst, reff488_op in H. discriminate H. Qed.

Lemma reff488_not623 : ~ @Equation623 Fin5 reff488_inst.
Proof. unfold Equation623. intro H. specialize (H F5_0 F5_3). unfold magma_op, reff488_inst, reff488_op in H. discriminate H. Qed.

Lemma reff488_not629 : ~ @Equation629 Fin5 reff488_inst.
Proof. unfold Equation629. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff488_inst, reff488_op in H. discriminate H. Qed.

Lemma reff488_not630 : ~ @Equation630 Fin5 reff488_inst.
Proof. unfold Equation630. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff488_inst, reff488_op in H. discriminate H. Qed.

Lemma reff488_not632 : ~ @Equation632 Fin5 reff488_inst.
Proof. unfold Equation632. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff488_inst, reff488_op in H. discriminate H. Qed.

Lemma reff488_not633 : ~ @Equation633 Fin5 reff488_inst.
Proof. unfold Equation633. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff488_inst, reff488_op in H. discriminate H. Qed.

Lemma reff488_not639 : ~ @Equation639 Fin5 reff488_inst.
Proof. unfold Equation639. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff488_inst, reff488_op in H. discriminate H. Qed.

Lemma reff488_not640 : ~ @Equation640 Fin5 reff488_inst.
Proof. unfold Equation640. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff488_inst, reff488_op in H. discriminate H. Qed.

Lemma reff488_not642 : ~ @Equation642 Fin5 reff488_inst.
Proof. unfold Equation642. intro H. specialize (H F5_0 F5_3). unfold magma_op, reff488_inst, reff488_op in H. discriminate H. Qed.

Lemma reff488_not643 : ~ @Equation643 Fin5 reff488_inst.
Proof. unfold Equation643. intro H. specialize (H F5_0 F5_2). unfold magma_op, reff488_inst, reff488_op in H. discriminate H. Qed.

Lemma reff488_not666 : ~ @Equation666 Fin5 reff488_inst.
Proof. unfold Equation666. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff488_inst, reff488_op in H. discriminate H. Qed.

Lemma reff488_not667 : ~ @Equation667 Fin5 reff488_inst.
Proof. unfold Equation667. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff488_inst, reff488_op in H. discriminate H. Qed.

Lemma reff488_not669 : ~ @Equation669 Fin5 reff488_inst.
Proof. unfold Equation669. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff488_inst, reff488_op in H. discriminate H. Qed.

Lemma reff488_not670 : ~ @Equation670 Fin5 reff488_inst.
Proof. unfold Equation670. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff488_inst, reff488_op in H. discriminate H. Qed.

Lemma reff488_not676 : ~ @Equation676 Fin5 reff488_inst.
Proof. unfold Equation676. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff488_inst, reff488_op in H. discriminate H. Qed.

Lemma reff488_not677 : ~ @Equation677 Fin5 reff488_inst.
Proof. unfold Equation677. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff488_inst, reff488_op in H. discriminate H. Qed.

Lemma reff488_not679 : ~ @Equation679 Fin5 reff488_inst.
Proof. unfold Equation679. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff488_inst, reff488_op in H. discriminate H. Qed.

Lemma reff488_not680 : ~ @Equation680 Fin5 reff488_inst.
Proof. unfold Equation680. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff488_inst, reff488_op in H. discriminate H. Qed.

Lemma reff488_not703 : ~ @Equation703 Fin5 reff488_inst.
Proof. unfold Equation703. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff488_inst, reff488_op in H. discriminate H. Qed.

Lemma reff488_not704 : ~ @Equation704 Fin5 reff488_inst.
Proof. unfold Equation704. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff488_inst, reff488_op in H. discriminate H. Qed.

Lemma reff488_not706 : ~ @Equation706 Fin5 reff488_inst.
Proof. unfold Equation706. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff488_inst, reff488_op in H. discriminate H. Qed.

Lemma reff488_not707 : ~ @Equation707 Fin5 reff488_inst.
Proof. unfold Equation707. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff488_inst, reff488_op in H. discriminate H. Qed.

Lemma reff488_not713 : ~ @Equation713 Fin5 reff488_inst.
Proof. unfold Equation713. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff488_inst, reff488_op in H. discriminate H. Qed.

Lemma reff488_not714 : ~ @Equation714 Fin5 reff488_inst.
Proof. unfold Equation714. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff488_inst, reff488_op in H. discriminate H. Qed.

Lemma reff488_not716 : ~ @Equation716 Fin5 reff488_inst.
Proof. unfold Equation716. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff488_inst, reff488_op in H. discriminate H. Qed.

Lemma reff488_not818 : ~ @Equation818 Fin5 reff488_inst.
Proof. unfold Equation818. intro H. specialize (H F5_0 F5_3). unfold magma_op, reff488_inst, reff488_op in H. discriminate H. Qed.

Lemma reff488_not820 : ~ @Equation820 Fin5 reff488_inst.
Proof. unfold Equation820. intro H. specialize (H F5_0 F5_3). unfold magma_op, reff488_inst, reff488_op in H. discriminate H. Qed.

Lemma reff488_not822 : ~ @Equation822 Fin5 reff488_inst.
Proof. unfold Equation822. intro H. specialize (H F5_0 F5_2). unfold magma_op, reff488_inst, reff488_op in H. discriminate H. Qed.

Lemma reff488_not823 : ~ @Equation823 Fin5 reff488_inst.
Proof. unfold Equation823. intro H. specialize (H F5_0 F5_3). unfold magma_op, reff488_inst, reff488_op in H. discriminate H. Qed.

Lemma reff488_not825 : ~ @Equation825 Fin5 reff488_inst.
Proof. unfold Equation825. intro H. specialize (H F5_0 F5_2). unfold magma_op, reff488_inst, reff488_op in H. discriminate H. Qed.

Lemma reff488_not826 : ~ @Equation826 Fin5 reff488_inst.
Proof. unfold Equation826. intro H. specialize (H F5_0 F5_3). unfold magma_op, reff488_inst, reff488_op in H. discriminate H. Qed.

Lemma reff488_not832 : ~ @Equation832 Fin5 reff488_inst.
Proof. unfold Equation832. intro H. specialize (H F5_0 F5_3). unfold magma_op, reff488_inst, reff488_op in H. discriminate H. Qed.

Lemma reff488_not835 : ~ @Equation835 Fin5 reff488_inst.
Proof. unfold Equation835. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff488_inst, reff488_op in H. discriminate H. Qed.

Lemma reff488_not836 : ~ @Equation836 Fin5 reff488_inst.
Proof. unfold Equation836. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff488_inst, reff488_op in H. discriminate H. Qed.

Lemma reff488_not842 : ~ @Equation842 Fin5 reff488_inst.
Proof. unfold Equation842. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff488_inst, reff488_op in H. discriminate H. Qed.

Lemma reff488_not843 : ~ @Equation843 Fin5 reff488_inst.
Proof. unfold Equation843. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff488_inst, reff488_op in H. discriminate H. Qed.

Lemma reff488_not845 : ~ @Equation845 Fin5 reff488_inst.
Proof. unfold Equation845. intro H. specialize (H F5_0 F5_3). unfold magma_op, reff488_inst, reff488_op in H. discriminate H. Qed.

Lemma reff488_not846 : ~ @Equation846 Fin5 reff488_inst.
Proof. unfold Equation846. intro H. specialize (H F5_0 F5_2). unfold magma_op, reff488_inst, reff488_op in H. discriminate H. Qed.

Lemma reff488_not869 : ~ @Equation869 Fin5 reff488_inst.
Proof. unfold Equation869. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff488_inst, reff488_op in H. discriminate H. Qed.

Lemma reff488_not870 : ~ @Equation870 Fin5 reff488_inst.
Proof. unfold Equation870. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff488_inst, reff488_op in H. discriminate H. Qed.

Lemma reff488_not872 : ~ @Equation872 Fin5 reff488_inst.
Proof. unfold Equation872. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff488_inst, reff488_op in H. discriminate H. Qed.

Lemma reff488_not873 : ~ @Equation873 Fin5 reff488_inst.
Proof. unfold Equation873. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff488_inst, reff488_op in H. discriminate H. Qed.

Lemma reff488_not879 : ~ @Equation879 Fin5 reff488_inst.
Proof. unfold Equation879. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff488_inst, reff488_op in H. discriminate H. Qed.

Lemma reff488_not880 : ~ @Equation880 Fin5 reff488_inst.
Proof. unfold Equation880. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff488_inst, reff488_op in H. discriminate H. Qed.

Lemma reff488_not882 : ~ @Equation882 Fin5 reff488_inst.
Proof. unfold Equation882. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff488_inst, reff488_op in H. discriminate H. Qed.

Lemma reff488_not883 : ~ @Equation883 Fin5 reff488_inst.
Proof. unfold Equation883. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff488_inst, reff488_op in H. discriminate H. Qed.

Lemma reff488_not906 : ~ @Equation906 Fin5 reff488_inst.
Proof. unfold Equation906. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff488_inst, reff488_op in H. discriminate H. Qed.

Lemma reff488_not907 : ~ @Equation907 Fin5 reff488_inst.
Proof. unfold Equation907. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff488_inst, reff488_op in H. discriminate H. Qed.

Lemma reff488_not909 : ~ @Equation909 Fin5 reff488_inst.
Proof. unfold Equation909. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff488_inst, reff488_op in H. discriminate H. Qed.

Lemma reff488_not910 : ~ @Equation910 Fin5 reff488_inst.
Proof. unfold Equation910. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff488_inst, reff488_op in H. discriminate H. Qed.

Lemma reff488_not916 : ~ @Equation916 Fin5 reff488_inst.
Proof. unfold Equation916. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff488_inst, reff488_op in H. discriminate H. Qed.

Lemma reff488_not917 : ~ @Equation917 Fin5 reff488_inst.
Proof. unfold Equation917. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff488_inst, reff488_op in H. discriminate H. Qed.

Lemma reff488_not919 : ~ @Equation919 Fin5 reff488_inst.
Proof. unfold Equation919. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff488_inst, reff488_op in H. discriminate H. Qed.

Lemma reff488_not1021 : ~ @Equation1021 Fin5 reff488_inst.
Proof. unfold Equation1021. intro H. specialize (H F5_0 F5_3). unfold magma_op, reff488_inst, reff488_op in H. discriminate H. Qed.

Lemma reff488_not1022 : ~ @Equation1022 Fin5 reff488_inst.
Proof. unfold Equation1022. intro H. specialize (H F5_0 F5_3). unfold magma_op, reff488_inst, reff488_op in H. discriminate H. Qed.

Lemma reff488_not1023 : ~ @Equation1023 Fin5 reff488_inst.
Proof. unfold Equation1023. intro H. specialize (H F5_0 F5_3). unfold magma_op, reff488_inst, reff488_op in H. discriminate H. Qed.

Lemma reff488_not1025 : ~ @Equation1025 Fin5 reff488_inst.
Proof. unfold Equation1025. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff488_inst, reff488_op in H. discriminate H. Qed.

Lemma reff488_not1026 : ~ @Equation1026 Fin5 reff488_inst.
Proof. unfold Equation1026. intro H. specialize (H F5_0 F5_3). unfold magma_op, reff488_inst, reff488_op in H. discriminate H. Qed.

Lemma reff488_not1028 : ~ @Equation1028 Fin5 reff488_inst.
Proof. unfold Equation1028. intro H. specialize (H F5_0 F5_2). unfold magma_op, reff488_inst, reff488_op in H. discriminate H. Qed.

Lemma reff488_not1029 : ~ @Equation1029 Fin5 reff488_inst.
Proof. unfold Equation1029. intro H. specialize (H F5_0 F5_3). unfold magma_op, reff488_inst, reff488_op in H. discriminate H. Qed.

Lemma reff488_not1035 : ~ @Equation1035 Fin5 reff488_inst.
Proof. unfold Equation1035. intro H. specialize (H F5_0 F5_3). unfold magma_op, reff488_inst, reff488_op in H. discriminate H. Qed.

Lemma reff488_not1036 : ~ @Equation1036 Fin5 reff488_inst.
Proof. unfold Equation1036. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff488_inst, reff488_op in H. discriminate H. Qed.

Lemma reff488_not1038 : ~ @Equation1038 Fin5 reff488_inst.
Proof. unfold Equation1038. intro H. specialize (H F5_0 F5_2). unfold magma_op, reff488_inst, reff488_op in H. discriminate H. Qed.

Lemma reff488_not1039 : ~ @Equation1039 Fin5 reff488_inst.
Proof. unfold Equation1039. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff488_inst, reff488_op in H. discriminate H. Qed.

Lemma reff488_not1045 : ~ @Equation1045 Fin5 reff488_inst.
Proof. unfold Equation1045. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff488_inst, reff488_op in H. discriminate H. Qed.

Lemma reff488_not1046 : ~ @Equation1046 Fin5 reff488_inst.
Proof. unfold Equation1046. intro H. specialize (H F5_0 F5_3). unfold magma_op, reff488_inst, reff488_op in H. discriminate H. Qed.

Lemma reff488_not1048 : ~ @Equation1048 Fin5 reff488_inst.
Proof. unfold Equation1048. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff488_inst, reff488_op in H. discriminate H. Qed.

Lemma reff488_not1049 : ~ @Equation1049 Fin5 reff488_inst.
Proof. unfold Equation1049. intro H. specialize (H F5_0 F5_2). unfold magma_op, reff488_inst, reff488_op in H. discriminate H. Qed.

Lemma reff488_not1072 : ~ @Equation1072 Fin5 reff488_inst.
Proof. unfold Equation1072. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff488_inst, reff488_op in H. discriminate H. Qed.

Lemma reff488_not1073 : ~ @Equation1073 Fin5 reff488_inst.
Proof. unfold Equation1073. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff488_inst, reff488_op in H. discriminate H. Qed.

Lemma reff488_not1075 : ~ @Equation1075 Fin5 reff488_inst.
Proof. unfold Equation1075. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff488_inst, reff488_op in H. discriminate H. Qed.

Lemma reff488_not1076 : ~ @Equation1076 Fin5 reff488_inst.
Proof. unfold Equation1076. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff488_inst, reff488_op in H. discriminate H. Qed.

Lemma reff488_not1082 : ~ @Equation1082 Fin5 reff488_inst.
Proof. unfold Equation1082. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff488_inst, reff488_op in H. discriminate H. Qed.

Lemma reff488_not1083 : ~ @Equation1083 Fin5 reff488_inst.
Proof. unfold Equation1083. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff488_inst, reff488_op in H. discriminate H. Qed.

Lemma reff488_not1085 : ~ @Equation1085 Fin5 reff488_inst.
Proof. unfold Equation1085. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff488_inst, reff488_op in H. discriminate H. Qed.

Lemma reff488_not1086 : ~ @Equation1086 Fin5 reff488_inst.
Proof. unfold Equation1086. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff488_inst, reff488_op in H. discriminate H. Qed.

Lemma reff488_not1109 : ~ @Equation1109 Fin5 reff488_inst.
Proof. unfold Equation1109. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff488_inst, reff488_op in H. discriminate H. Qed.

Lemma reff488_not1110 : ~ @Equation1110 Fin5 reff488_inst.
Proof. unfold Equation1110. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff488_inst, reff488_op in H. discriminate H. Qed.

Lemma reff488_not1112 : ~ @Equation1112 Fin5 reff488_inst.
Proof. unfold Equation1112. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff488_inst, reff488_op in H. discriminate H. Qed.

Lemma reff488_not1113 : ~ @Equation1113 Fin5 reff488_inst.
Proof. unfold Equation1113. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff488_inst, reff488_op in H. discriminate H. Qed.

Lemma reff488_not1119 : ~ @Equation1119 Fin5 reff488_inst.
Proof. unfold Equation1119. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff488_inst, reff488_op in H. discriminate H. Qed.

Lemma reff488_not1120 : ~ @Equation1120 Fin5 reff488_inst.
Proof. unfold Equation1120. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff488_inst, reff488_op in H. discriminate H. Qed.

Lemma reff488_not1122 : ~ @Equation1122 Fin5 reff488_inst.
Proof. unfold Equation1122. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff488_inst, reff488_op in H. discriminate H. Qed.

Lemma reff488_not1224 : ~ @Equation1224 Fin5 reff488_inst.
Proof. unfold Equation1224. intro H. specialize (H F5_0 F5_3). unfold magma_op, reff488_inst, reff488_op in H. discriminate H. Qed.

Lemma reff488_not1225 : ~ @Equation1225 Fin5 reff488_inst.
Proof. unfold Equation1225. intro H. specialize (H F5_0 F5_2). unfold magma_op, reff488_inst, reff488_op in H. discriminate H. Qed.

Lemma reff488_not1226 : ~ @Equation1226 Fin5 reff488_inst.
Proof. unfold Equation1226. intro H. specialize (H F5_0 F5_3). unfold magma_op, reff488_inst, reff488_op in H. discriminate H. Qed.

Lemma reff488_not1228 : ~ @Equation1228 Fin5 reff488_inst.
Proof. unfold Equation1228. intro H. specialize (H F5_0 F5_3). unfold magma_op, reff488_inst, reff488_op in H. discriminate H. Qed.

Lemma reff488_not1229 : ~ @Equation1229 Fin5 reff488_inst.
Proof. unfold Equation1229. intro H. specialize (H F5_0 F5_2). unfold magma_op, reff488_inst, reff488_op in H. discriminate H. Qed.

Lemma reff488_not1231 : ~ @Equation1231 Fin5 reff488_inst.
Proof. unfold Equation1231. intro H. specialize (H F5_0 F5_2). unfold magma_op, reff488_inst, reff488_op in H. discriminate H. Qed.

Lemma reff488_not1232 : ~ @Equation1232 Fin5 reff488_inst.
Proof. unfold Equation1232. intro H. specialize (H F5_0 F5_3). unfold magma_op, reff488_inst, reff488_op in H. discriminate H. Qed.

Lemma reff488_not1238 : ~ @Equation1238 Fin5 reff488_inst.
Proof. unfold Equation1238. intro H. specialize (H F5_0 F5_3). unfold magma_op, reff488_inst, reff488_op in H. discriminate H. Qed.

Lemma reff488_not1239 : ~ @Equation1239 Fin5 reff488_inst.
Proof. unfold Equation1239. intro H. specialize (H F5_0 F5_4). unfold magma_op, reff488_inst, reff488_op in H. discriminate H. Qed.

Lemma reff488_not1241 : ~ @Equation1241 Fin5 reff488_inst.
Proof. unfold Equation1241. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff488_inst, reff488_op in H. discriminate H. Qed.

Lemma reff488_not1242 : ~ @Equation1242 Fin5 reff488_inst.
Proof. unfold Equation1242. intro H. specialize (H F5_0 F5_3). unfold magma_op, reff488_inst, reff488_op in H. discriminate H. Qed.

Lemma reff488_not1248 : ~ @Equation1248 Fin5 reff488_inst.
Proof. unfold Equation1248. intro H. specialize (H F5_0 F5_3). unfold magma_op, reff488_inst, reff488_op in H. discriminate H. Qed.

Lemma reff488_not1249 : ~ @Equation1249 Fin5 reff488_inst.
Proof. unfold Equation1249. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff488_inst, reff488_op in H. discriminate H. Qed.

Lemma reff488_not1251 : ~ @Equation1251 Fin5 reff488_inst.
Proof. unfold Equation1251. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff488_inst, reff488_op in H. discriminate H. Qed.

Lemma reff488_not1252 : ~ @Equation1252 Fin5 reff488_inst.
Proof. unfold Equation1252. intro H. specialize (H F5_0 F5_2). unfold magma_op, reff488_inst, reff488_op in H. discriminate H. Qed.

Lemma reff488_not1275 : ~ @Equation1275 Fin5 reff488_inst.
Proof. unfold Equation1275. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff488_inst, reff488_op in H. discriminate H. Qed.

Lemma reff488_not1276 : ~ @Equation1276 Fin5 reff488_inst.
Proof. unfold Equation1276. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff488_inst, reff488_op in H. discriminate H. Qed.

Lemma reff488_not1278 : ~ @Equation1278 Fin5 reff488_inst.
Proof. unfold Equation1278. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff488_inst, reff488_op in H. discriminate H. Qed.

Lemma reff488_not1279 : ~ @Equation1279 Fin5 reff488_inst.
Proof. unfold Equation1279. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff488_inst, reff488_op in H. discriminate H. Qed.

Lemma reff488_not1285 : ~ @Equation1285 Fin5 reff488_inst.
Proof. unfold Equation1285. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff488_inst, reff488_op in H. discriminate H. Qed.

Lemma reff488_not1286 : ~ @Equation1286 Fin5 reff488_inst.
Proof. unfold Equation1286. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff488_inst, reff488_op in H. discriminate H. Qed.

Lemma reff488_not1288 : ~ @Equation1288 Fin5 reff488_inst.
Proof. unfold Equation1288. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff488_inst, reff488_op in H. discriminate H. Qed.

Lemma reff488_not1289 : ~ @Equation1289 Fin5 reff488_inst.
Proof. unfold Equation1289. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff488_inst, reff488_op in H. discriminate H. Qed.

Lemma reff488_not1312 : ~ @Equation1312 Fin5 reff488_inst.
Proof. unfold Equation1312. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff488_inst, reff488_op in H. discriminate H. Qed.

Lemma reff488_not1313 : ~ @Equation1313 Fin5 reff488_inst.
Proof. unfold Equation1313. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff488_inst, reff488_op in H. discriminate H. Qed.

Lemma reff488_not1315 : ~ @Equation1315 Fin5 reff488_inst.
Proof. unfold Equation1315. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff488_inst, reff488_op in H. discriminate H. Qed.

Lemma reff488_not1316 : ~ @Equation1316 Fin5 reff488_inst.
Proof. unfold Equation1316. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff488_inst, reff488_op in H. discriminate H. Qed.

Lemma reff488_not1322 : ~ @Equation1322 Fin5 reff488_inst.
Proof. unfold Equation1322. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff488_inst, reff488_op in H. discriminate H. Qed.

Lemma reff488_not1323 : ~ @Equation1323 Fin5 reff488_inst.
Proof. unfold Equation1323. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff488_inst, reff488_op in H. discriminate H. Qed.

Lemma reff488_not1325 : ~ @Equation1325 Fin5 reff488_inst.
Proof. unfold Equation1325. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff488_inst, reff488_op in H. discriminate H. Qed.

Lemma reff488_not1427 : ~ @Equation1427 Fin5 reff488_inst.
Proof. unfold Equation1427. intro H. specialize (H F5_0 F5_3). unfold magma_op, reff488_inst, reff488_op in H. discriminate H. Qed.

Lemma reff488_not1429 : ~ @Equation1429 Fin5 reff488_inst.
Proof. unfold Equation1429. intro H. specialize (H F5_0 F5_3). unfold magma_op, reff488_inst, reff488_op in H. discriminate H. Qed.

Lemma reff488_not1431 : ~ @Equation1431 Fin5 reff488_inst.
Proof. unfold Equation1431. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff488_inst, reff488_op in H. discriminate H. Qed.

Lemma reff488_not1432 : ~ @Equation1432 Fin5 reff488_inst.
Proof. unfold Equation1432. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff488_inst, reff488_op in H. discriminate H. Qed.

Lemma reff488_not1434 : ~ @Equation1434 Fin5 reff488_inst.
Proof. unfold Equation1434. intro H. specialize (H F5_0 F5_3). unfold magma_op, reff488_inst, reff488_op in H. discriminate H. Qed.

Lemma reff488_not1435 : ~ @Equation1435 Fin5 reff488_inst.
Proof. unfold Equation1435. intro H. specialize (H F5_0 F5_2). unfold magma_op, reff488_inst, reff488_op in H. discriminate H. Qed.

Lemma reff488_not1441 : ~ @Equation1441 Fin5 reff488_inst.
Proof. unfold Equation1441. intro H. specialize (H F5_0 F5_2). unfold magma_op, reff488_inst, reff488_op in H. discriminate H. Qed.

Lemma reff488_not1442 : ~ @Equation1442 Fin5 reff488_inst.
Proof. unfold Equation1442. intro H. specialize (H F5_0 F5_2). unfold magma_op, reff488_inst, reff488_op in H. discriminate H. Qed.

Lemma reff488_not1444 : ~ @Equation1444 Fin5 reff488_inst.
Proof. unfold Equation1444. intro H. specialize (H F5_0 F5_2). unfold magma_op, reff488_inst, reff488_op in H. discriminate H. Qed.

Lemma reff488_not1445 : ~ @Equation1445 Fin5 reff488_inst.
Proof. unfold Equation1445. intro H. specialize (H F5_0 F5_2). unfold magma_op, reff488_inst, reff488_op in H. discriminate H. Qed.

Lemma reff488_not1451 : ~ @Equation1451 Fin5 reff488_inst.
Proof. unfold Equation1451. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff488_inst, reff488_op in H. discriminate H. Qed.

Lemma reff488_not1452 : ~ @Equation1452 Fin5 reff488_inst.
Proof. unfold Equation1452. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff488_inst, reff488_op in H. discriminate H. Qed.

Lemma reff488_not1454 : ~ @Equation1454 Fin5 reff488_inst.
Proof. unfold Equation1454. intro H. specialize (H F5_0 F5_2). unfold magma_op, reff488_inst, reff488_op in H. discriminate H. Qed.

Lemma reff488_not1455 : ~ @Equation1455 Fin5 reff488_inst.
Proof. unfold Equation1455. intro H. specialize (H F5_0 F5_2). unfold magma_op, reff488_inst, reff488_op in H. discriminate H. Qed.

Lemma reff488_not1478 : ~ @Equation1478 Fin5 reff488_inst.
Proof. unfold Equation1478. intro H. specialize (H F5_0 F5_3). unfold magma_op, reff488_inst, reff488_op in H. discriminate H. Qed.

Lemma reff488_not1479 : ~ @Equation1479 Fin5 reff488_inst.
Proof. unfold Equation1479. intro H. specialize (H F5_0 F5_4). unfold magma_op, reff488_inst, reff488_op in H. discriminate H. Qed.

Lemma reff488_not1481 : ~ @Equation1481 Fin5 reff488_inst.
Proof. unfold Equation1481. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff488_inst, reff488_op in H. discriminate H. Qed.

Lemma reff488_not1488 : ~ @Equation1488 Fin5 reff488_inst.
Proof. unfold Equation1488. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff488_inst, reff488_op in H. discriminate H. Qed.

Lemma reff488_not1489 : ~ @Equation1489 Fin5 reff488_inst.
Proof. unfold Equation1489. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff488_inst, reff488_op in H. discriminate H. Qed.

Lemma reff488_not1491 : ~ @Equation1491 Fin5 reff488_inst.
Proof. unfold Equation1491. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff488_inst, reff488_op in H. discriminate H. Qed.

Lemma reff488_not1492 : ~ @Equation1492 Fin5 reff488_inst.
Proof. unfold Equation1492. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff488_inst, reff488_op in H. discriminate H. Qed.

Lemma reff488_not1515 : ~ @Equation1515 Fin5 reff488_inst.
Proof. unfold Equation1515. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff488_inst, reff488_op in H. discriminate H. Qed.

Lemma reff488_not1516 : ~ @Equation1516 Fin5 reff488_inst.
Proof. unfold Equation1516. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff488_inst, reff488_op in H. discriminate H. Qed.

Lemma reff488_not1518 : ~ @Equation1518 Fin5 reff488_inst.
Proof. unfold Equation1518. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff488_inst, reff488_op in H. discriminate H. Qed.

Lemma reff488_not1519 : ~ @Equation1519 Fin5 reff488_inst.
Proof. unfold Equation1519. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff488_inst, reff488_op in H. discriminate H. Qed.

Lemma reff488_not1525 : ~ @Equation1525 Fin5 reff488_inst.
Proof. unfold Equation1525. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff488_inst, reff488_op in H. discriminate H. Qed.

Lemma reff488_not1526 : ~ @Equation1526 Fin5 reff488_inst.
Proof. unfold Equation1526. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff488_inst, reff488_op in H. discriminate H. Qed.

Lemma reff488_not1528 : ~ @Equation1528 Fin5 reff488_inst.
Proof. unfold Equation1528. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff488_inst, reff488_op in H. discriminate H. Qed.

Lemma reff488_not1630 : ~ @Equation1630 Fin5 reff488_inst.
Proof. unfold Equation1630. intro H. specialize (H F5_0 F5_3). unfold magma_op, reff488_inst, reff488_op in H. discriminate H. Qed.

Lemma reff488_not1631 : ~ @Equation1631 Fin5 reff488_inst.
Proof. unfold Equation1631. intro H. specialize (H F5_0 F5_2). unfold magma_op, reff488_inst, reff488_op in H. discriminate H. Qed.

Lemma reff488_not1632 : ~ @Equation1632 Fin5 reff488_inst.
Proof. unfold Equation1632. intro H. specialize (H F5_0 F5_3). unfold magma_op, reff488_inst, reff488_op in H. discriminate H. Qed.

Lemma reff488_not1634 : ~ @Equation1634 Fin5 reff488_inst.
Proof. unfold Equation1634. intro H. specialize (H F5_0 F5_3). unfold magma_op, reff488_inst, reff488_op in H. discriminate H. Qed.

Lemma reff488_not1635 : ~ @Equation1635 Fin5 reff488_inst.
Proof. unfold Equation1635. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff488_inst, reff488_op in H. discriminate H. Qed.

Lemma reff488_not1637 : ~ @Equation1637 Fin5 reff488_inst.
Proof. unfold Equation1637. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff488_inst, reff488_op in H. discriminate H. Qed.

Lemma reff488_not1638 : ~ @Equation1638 Fin5 reff488_inst.
Proof. unfold Equation1638. intro H. specialize (H F5_0 F5_2). unfold magma_op, reff488_inst, reff488_op in H. discriminate H. Qed.

Lemma reff488_not1644 : ~ @Equation1644 Fin5 reff488_inst.
Proof. unfold Equation1644. intro H. specialize (H F5_0 F5_2). unfold magma_op, reff488_inst, reff488_op in H. discriminate H. Qed.

Lemma reff488_not1645 : ~ @Equation1645 Fin5 reff488_inst.
Proof. unfold Equation1645. intro H. specialize (H F5_0 F5_2). unfold magma_op, reff488_inst, reff488_op in H. discriminate H. Qed.

Lemma reff488_not1647 : ~ @Equation1647 Fin5 reff488_inst.
Proof. unfold Equation1647. intro H. specialize (H F5_0 F5_2). unfold magma_op, reff488_inst, reff488_op in H. discriminate H. Qed.

Lemma reff488_not1648 : ~ @Equation1648 Fin5 reff488_inst.
Proof. unfold Equation1648. intro H. specialize (H F5_0 F5_2). unfold magma_op, reff488_inst, reff488_op in H. discriminate H. Qed.

Lemma reff488_not1654 : ~ @Equation1654 Fin5 reff488_inst.
Proof. unfold Equation1654. intro H. specialize (H F5_0 F5_2). unfold magma_op, reff488_inst, reff488_op in H. discriminate H. Qed.

Lemma reff488_not1655 : ~ @Equation1655 Fin5 reff488_inst.
Proof. unfold Equation1655. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff488_inst, reff488_op in H. discriminate H. Qed.

Lemma reff488_not1657 : ~ @Equation1657 Fin5 reff488_inst.
Proof. unfold Equation1657. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff488_inst, reff488_op in H. discriminate H. Qed.

Lemma reff488_not1658 : ~ @Equation1658 Fin5 reff488_inst.
Proof. unfold Equation1658. intro H. specialize (H F5_0 F5_2). unfold magma_op, reff488_inst, reff488_op in H. discriminate H. Qed.

Lemma reff488_not1681 : ~ @Equation1681 Fin5 reff488_inst.
Proof. unfold Equation1681. intro H. specialize (H F5_0 F5_3). unfold magma_op, reff488_inst, reff488_op in H. discriminate H. Qed.

Lemma reff488_not1684 : ~ @Equation1684 Fin5 reff488_inst.
Proof. unfold Equation1684. intro H. specialize (H F5_0 F5_2). unfold magma_op, reff488_inst, reff488_op in H. discriminate H. Qed.

Lemma reff488_not1685 : ~ @Equation1685 Fin5 reff488_inst.
Proof. unfold Equation1685. intro H. specialize (H F5_0 F5_4). unfold magma_op, reff488_inst, reff488_op in H. discriminate H. Qed.

Lemma reff488_not1691 : ~ @Equation1691 Fin5 reff488_inst.
Proof. unfold Equation1691. intro H. specialize (H F5_0 F5_3). unfold magma_op, reff488_inst, reff488_op in H. discriminate H. Qed.

Lemma reff488_not1692 : ~ @Equation1692 Fin5 reff488_inst.
Proof. unfold Equation1692. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff488_inst, reff488_op in H. discriminate H. Qed.

Lemma reff488_not1694 : ~ @Equation1694 Fin5 reff488_inst.
Proof. unfold Equation1694. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff488_inst, reff488_op in H. discriminate H. Qed.

Lemma reff488_not1695 : ~ @Equation1695 Fin5 reff488_inst.
Proof. unfold Equation1695. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff488_inst, reff488_op in H. discriminate H. Qed.

Lemma reff488_not1718 : ~ @Equation1718 Fin5 reff488_inst.
Proof. unfold Equation1718. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff488_inst, reff488_op in H. discriminate H. Qed.

Lemma reff488_not1719 : ~ @Equation1719 Fin5 reff488_inst.
Proof. unfold Equation1719. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff488_inst, reff488_op in H. discriminate H. Qed.

Lemma reff488_not1721 : ~ @Equation1721 Fin5 reff488_inst.
Proof. unfold Equation1721. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff488_inst, reff488_op in H. discriminate H. Qed.

Lemma reff488_not1722 : ~ @Equation1722 Fin5 reff488_inst.
Proof. unfold Equation1722. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff488_inst, reff488_op in H. discriminate H. Qed.

Lemma reff488_not1728 : ~ @Equation1728 Fin5 reff488_inst.
Proof. unfold Equation1728. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff488_inst, reff488_op in H. discriminate H. Qed.

Lemma reff488_not1729 : ~ @Equation1729 Fin5 reff488_inst.
Proof. unfold Equation1729. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff488_inst, reff488_op in H. discriminate H. Qed.

Lemma reff488_not1731 : ~ @Equation1731 Fin5 reff488_inst.
Proof. unfold Equation1731. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff488_inst, reff488_op in H. discriminate H. Qed.

Lemma reff488_not1833 : ~ @Equation1833 Fin5 reff488_inst.
Proof. unfold Equation1833. intro H. specialize (H F5_0 F5_3). unfold magma_op, reff488_inst, reff488_op in H. discriminate H. Qed.

Lemma reff488_not1834 : ~ @Equation1834 Fin5 reff488_inst.
Proof. unfold Equation1834. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff488_inst, reff488_op in H. discriminate H. Qed.

Lemma reff488_not1835 : ~ @Equation1835 Fin5 reff488_inst.
Proof. unfold Equation1835. intro H. specialize (H F5_0 F5_2). unfold magma_op, reff488_inst, reff488_op in H. discriminate H. Qed.

Lemma reff488_not1837 : ~ @Equation1837 Fin5 reff488_inst.
Proof. unfold Equation1837. intro H. specialize (H F5_0 F5_3). unfold magma_op, reff488_inst, reff488_op in H. discriminate H. Qed.

Lemma reff488_not1838 : ~ @Equation1838 Fin5 reff488_inst.
Proof. unfold Equation1838. intro H. specialize (H F5_0 F5_3). unfold magma_op, reff488_inst, reff488_op in H. discriminate H. Qed.

Lemma reff488_not1840 : ~ @Equation1840 Fin5 reff488_inst.
Proof. unfold Equation1840. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff488_inst, reff488_op in H. discriminate H. Qed.

Lemma reff488_not1841 : ~ @Equation1841 Fin5 reff488_inst.
Proof. unfold Equation1841. intro H. specialize (H F5_0 F5_2). unfold magma_op, reff488_inst, reff488_op in H. discriminate H. Qed.

Lemma reff488_not1847 : ~ @Equation1847 Fin5 reff488_inst.
Proof. unfold Equation1847. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff488_inst, reff488_op in H. discriminate H. Qed.

Lemma reff488_not1848 : ~ @Equation1848 Fin5 reff488_inst.
Proof. unfold Equation1848. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff488_inst, reff488_op in H. discriminate H. Qed.

Lemma reff488_not1850 : ~ @Equation1850 Fin5 reff488_inst.
Proof. unfold Equation1850. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff488_inst, reff488_op in H. discriminate H. Qed.

Lemma reff488_not1851 : ~ @Equation1851 Fin5 reff488_inst.
Proof. unfold Equation1851. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff488_inst, reff488_op in H. discriminate H. Qed.

Lemma reff488_not1857 : ~ @Equation1857 Fin5 reff488_inst.
Proof. unfold Equation1857. intro H. specialize (H F5_0 F5_2). unfold magma_op, reff488_inst, reff488_op in H. discriminate H. Qed.

Lemma reff488_not1858 : ~ @Equation1858 Fin5 reff488_inst.
Proof. unfold Equation1858. intro H. specialize (H F5_0 F5_2). unfold magma_op, reff488_inst, reff488_op in H. discriminate H. Qed.

Lemma reff488_not1860 : ~ @Equation1860 Fin5 reff488_inst.
Proof. unfold Equation1860. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff488_inst, reff488_op in H. discriminate H. Qed.

Lemma reff488_not1861 : ~ @Equation1861 Fin5 reff488_inst.
Proof. unfold Equation1861. intro H. specialize (H F5_0 F5_2). unfold magma_op, reff488_inst, reff488_op in H. discriminate H. Qed.

Lemma reff488_not1884 : ~ @Equation1884 Fin5 reff488_inst.
Proof. unfold Equation1884. intro H. specialize (H F5_0 F5_3). unfold magma_op, reff488_inst, reff488_op in H. discriminate H. Qed.

Lemma reff488_not1887 : ~ @Equation1887 Fin5 reff488_inst.
Proof. unfold Equation1887. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff488_inst, reff488_op in H. discriminate H. Qed.

Lemma reff488_not1888 : ~ @Equation1888 Fin5 reff488_inst.
Proof. unfold Equation1888. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff488_inst, reff488_op in H. discriminate H. Qed.

Lemma reff488_not1894 : ~ @Equation1894 Fin5 reff488_inst.
Proof. unfold Equation1894. intro H. specialize (H F5_0 F5_2). unfold magma_op, reff488_inst, reff488_op in H. discriminate H. Qed.

Lemma reff488_not1895 : ~ @Equation1895 Fin5 reff488_inst.
Proof. unfold Equation1895. intro H. specialize (H F5_0 F5_2). unfold magma_op, reff488_inst, reff488_op in H. discriminate H. Qed.

Lemma reff488_not1897 : ~ @Equation1897 Fin5 reff488_inst.
Proof. unfold Equation1897. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff488_inst, reff488_op in H. discriminate H. Qed.

Lemma reff488_not1898 : ~ @Equation1898 Fin5 reff488_inst.
Proof. unfold Equation1898. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff488_inst, reff488_op in H. discriminate H. Qed.

Lemma reff488_not1921 : ~ @Equation1921 Fin5 reff488_inst.
Proof. unfold Equation1921. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff488_inst, reff488_op in H. discriminate H. Qed.

Lemma reff488_not1922 : ~ @Equation1922 Fin5 reff488_inst.
Proof. unfold Equation1922. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff488_inst, reff488_op in H. discriminate H. Qed.

Lemma reff488_not1924 : ~ @Equation1924 Fin5 reff488_inst.
Proof. unfold Equation1924. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff488_inst, reff488_op in H. discriminate H. Qed.

Lemma reff488_not1925 : ~ @Equation1925 Fin5 reff488_inst.
Proof. unfold Equation1925. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff488_inst, reff488_op in H. discriminate H. Qed.

Lemma reff488_not1931 : ~ @Equation1931 Fin5 reff488_inst.
Proof. unfold Equation1931. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff488_inst, reff488_op in H. discriminate H. Qed.

Lemma reff488_not1932 : ~ @Equation1932 Fin5 reff488_inst.
Proof. unfold Equation1932. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff488_inst, reff488_op in H. discriminate H. Qed.

Lemma reff488_not1934 : ~ @Equation1934 Fin5 reff488_inst.
Proof. unfold Equation1934. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff488_inst, reff488_op in H. discriminate H. Qed.

Lemma reff488_not2036 : ~ @Equation2036 Fin5 reff488_inst.
Proof. unfold Equation2036. intro H. specialize (H F5_0 F5_3). unfold magma_op, reff488_inst, reff488_op in H. discriminate H. Qed.

Lemma reff488_not2037 : ~ @Equation2037 Fin5 reff488_inst.
Proof. unfold Equation2037. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff488_inst, reff488_op in H. discriminate H. Qed.

Lemma reff488_not2038 : ~ @Equation2038 Fin5 reff488_inst.
Proof. unfold Equation2038. intro H. specialize (H F5_0 F5_2). unfold magma_op, reff488_inst, reff488_op in H. discriminate H. Qed.

Lemma reff488_not2040 : ~ @Equation2040 Fin5 reff488_inst.
Proof. unfold Equation2040. intro H. specialize (H F5_0 F5_2). unfold magma_op, reff488_inst, reff488_op in H. discriminate H. Qed.

Lemma reff488_not2041 : ~ @Equation2041 Fin5 reff488_inst.
Proof. unfold Equation2041. intro H. specialize (H F5_0 F5_2). unfold magma_op, reff488_inst, reff488_op in H. discriminate H. Qed.

Lemma reff488_not2043 : ~ @Equation2043 Fin5 reff488_inst.
Proof. unfold Equation2043. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff488_inst, reff488_op in H. discriminate H. Qed.

Lemma reff488_not2044 : ~ @Equation2044 Fin5 reff488_inst.
Proof. unfold Equation2044. intro H. specialize (H F5_0 F5_2). unfold magma_op, reff488_inst, reff488_op in H. discriminate H. Qed.

Lemma reff488_not2050 : ~ @Equation2050 Fin5 reff488_inst.
Proof. unfold Equation2050. intro H. specialize (H F5_0 F5_3). unfold magma_op, reff488_inst, reff488_op in H. discriminate H. Qed.

Lemma reff488_not2051 : ~ @Equation2051 Fin5 reff488_inst.
Proof. unfold Equation2051. intro H. specialize (H F5_0 F5_2). unfold magma_op, reff488_inst, reff488_op in H. discriminate H. Qed.

Lemma reff488_not2053 : ~ @Equation2053 Fin5 reff488_inst.
Proof. unfold Equation2053. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff488_inst, reff488_op in H. discriminate H. Qed.

Lemma reff488_not2054 : ~ @Equation2054 Fin5 reff488_inst.
Proof. unfold Equation2054. intro H. specialize (H F5_0 F5_2). unfold magma_op, reff488_inst, reff488_op in H. discriminate H. Qed.

Lemma reff488_not2060 : ~ @Equation2060 Fin5 reff488_inst.
Proof. unfold Equation2060. intro H. specialize (H F5_0 F5_2). unfold magma_op, reff488_inst, reff488_op in H. discriminate H. Qed.

Lemma reff488_not2061 : ~ @Equation2061 Fin5 reff488_inst.
Proof. unfold Equation2061. intro H. specialize (H F5_0 F5_2). unfold magma_op, reff488_inst, reff488_op in H. discriminate H. Qed.

Lemma reff488_not2063 : ~ @Equation2063 Fin5 reff488_inst.
Proof. unfold Equation2063. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff488_inst, reff488_op in H. discriminate H. Qed.

Lemma reff488_not2064 : ~ @Equation2064 Fin5 reff488_inst.
Proof. unfold Equation2064. intro H. specialize (H F5_0 F5_2). unfold magma_op, reff488_inst, reff488_op in H. discriminate H. Qed.

Lemma reff488_not2087 : ~ @Equation2087 Fin5 reff488_inst.
Proof. unfold Equation2087. intro H. specialize (H F5_0 F5_3). unfold magma_op, reff488_inst, reff488_op in H. discriminate H. Qed.

Lemma reff488_not2090 : ~ @Equation2090 Fin5 reff488_inst.
Proof. unfold Equation2090. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff488_inst, reff488_op in H. discriminate H. Qed.

Lemma reff488_not2091 : ~ @Equation2091 Fin5 reff488_inst.
Proof. unfold Equation2091. intro H. specialize (H F5_0 F5_2). unfold magma_op, reff488_inst, reff488_op in H. discriminate H. Qed.

Lemma reff488_not2097 : ~ @Equation2097 Fin5 reff488_inst.
Proof. unfold Equation2097. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff488_inst, reff488_op in H. discriminate H. Qed.

Lemma reff488_not2098 : ~ @Equation2098 Fin5 reff488_inst.
Proof. unfold Equation2098. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff488_inst, reff488_op in H. discriminate H. Qed.

Lemma reff488_not2100 : ~ @Equation2100 Fin5 reff488_inst.
Proof. unfold Equation2100. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff488_inst, reff488_op in H. discriminate H. Qed.

Lemma reff488_not2101 : ~ @Equation2101 Fin5 reff488_inst.
Proof. unfold Equation2101. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff488_inst, reff488_op in H. discriminate H. Qed.

Lemma reff488_not2124 : ~ @Equation2124 Fin5 reff488_inst.
Proof. unfold Equation2124. intro H. specialize (H F5_0 F5_3). unfold magma_op, reff488_inst, reff488_op in H. discriminate H. Qed.

Lemma reff488_not2127 : ~ @Equation2127 Fin5 reff488_inst.
Proof. unfold Equation2127. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff488_inst, reff488_op in H. discriminate H. Qed.

Lemma reff488_not2128 : ~ @Equation2128 Fin5 reff488_inst.
Proof. unfold Equation2128. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff488_inst, reff488_op in H. discriminate H. Qed.

Lemma reff488_not2134 : ~ @Equation2134 Fin5 reff488_inst.
Proof. unfold Equation2134. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff488_inst, reff488_op in H. discriminate H. Qed.

Lemma reff488_not2135 : ~ @Equation2135 Fin5 reff488_inst.
Proof. unfold Equation2135. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff488_inst, reff488_op in H. discriminate H. Qed.

Lemma reff488_not2137 : ~ @Equation2137 Fin5 reff488_inst.
Proof. unfold Equation2137. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff488_inst, reff488_op in H. discriminate H. Qed.

Lemma reff488_not2239 : ~ @Equation2239 Fin5 reff488_inst.
Proof. unfold Equation2239. intro H. specialize (H F5_0 F5_2). unfold magma_op, reff488_inst, reff488_op in H. discriminate H. Qed.

Lemma reff488_not2240 : ~ @Equation2240 Fin5 reff488_inst.
Proof. unfold Equation2240. intro H. specialize (H F5_0 F5_3). unfold magma_op, reff488_inst, reff488_op in H. discriminate H. Qed.

Lemma reff488_not2241 : ~ @Equation2241 Fin5 reff488_inst.
Proof. unfold Equation2241. intro H. specialize (H F5_0 F5_2). unfold magma_op, reff488_inst, reff488_op in H. discriminate H. Qed.

Lemma reff488_not2244 : ~ @Equation2244 Fin5 reff488_inst.
Proof. unfold Equation2244. intro H. specialize (H F5_0 F5_2). unfold magma_op, reff488_inst, reff488_op in H. discriminate H. Qed.

Lemma reff488_not2246 : ~ @Equation2246 Fin5 reff488_inst.
Proof. unfold Equation2246. intro H. specialize (H F5_0 F5_3). unfold magma_op, reff488_inst, reff488_op in H. discriminate H. Qed.

Lemma reff488_not2247 : ~ @Equation2247 Fin5 reff488_inst.
Proof. unfold Equation2247. intro H. specialize (H F5_0 F5_2). unfold magma_op, reff488_inst, reff488_op in H. discriminate H. Qed.

Lemma reff488_not2253 : ~ @Equation2253 Fin5 reff488_inst.
Proof. unfold Equation2253. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff488_inst, reff488_op in H. discriminate H. Qed.

Lemma reff488_not2254 : ~ @Equation2254 Fin5 reff488_inst.
Proof. unfold Equation2254. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff488_inst, reff488_op in H. discriminate H. Qed.

Lemma reff488_not2256 : ~ @Equation2256 Fin5 reff488_inst.
Proof. unfold Equation2256. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff488_inst, reff488_op in H. discriminate H. Qed.

Lemma reff488_not2257 : ~ @Equation2257 Fin5 reff488_inst.
Proof. unfold Equation2257. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff488_inst, reff488_op in H. discriminate H. Qed.

Lemma reff488_not2263 : ~ @Equation2263 Fin5 reff488_inst.
Proof. unfold Equation2263. intro H. specialize (H F5_0 F5_3). unfold magma_op, reff488_inst, reff488_op in H. discriminate H. Qed.

Lemma reff488_not2264 : ~ @Equation2264 Fin5 reff488_inst.
Proof. unfold Equation2264. intro H. specialize (H F5_0 F5_2). unfold magma_op, reff488_inst, reff488_op in H. discriminate H. Qed.

Lemma reff488_not2266 : ~ @Equation2266 Fin5 reff488_inst.
Proof. unfold Equation2266. intro H. specialize (H F5_0 F5_2). unfold magma_op, reff488_inst, reff488_op in H. discriminate H. Qed.

Lemma reff488_not2267 : ~ @Equation2267 Fin5 reff488_inst.
Proof. unfold Equation2267. intro H. specialize (H F5_0 F5_2). unfold magma_op, reff488_inst, reff488_op in H. discriminate H. Qed.

Lemma reff488_not2290 : ~ @Equation2290 Fin5 reff488_inst.
Proof. unfold Equation2290. intro H. specialize (H F5_0 F5_3). unfold magma_op, reff488_inst, reff488_op in H. discriminate H. Qed.

Lemma reff488_not2291 : ~ @Equation2291 Fin5 reff488_inst.
Proof. unfold Equation2291. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff488_inst, reff488_op in H. discriminate H. Qed.

Lemma reff488_not2293 : ~ @Equation2293 Fin5 reff488_inst.
Proof. unfold Equation2293. intro H. specialize (H F5_0 F5_3). unfold magma_op, reff488_inst, reff488_op in H. discriminate H. Qed.

Lemma reff488_not2294 : ~ @Equation2294 Fin5 reff488_inst.
Proof. unfold Equation2294. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff488_inst, reff488_op in H. discriminate H. Qed.

Lemma reff488_not2300 : ~ @Equation2300 Fin5 reff488_inst.
Proof. unfold Equation2300. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff488_inst, reff488_op in H. discriminate H. Qed.

Lemma reff488_not2301 : ~ @Equation2301 Fin5 reff488_inst.
Proof. unfold Equation2301. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff488_inst, reff488_op in H. discriminate H. Qed.

Lemma reff488_not2303 : ~ @Equation2303 Fin5 reff488_inst.
Proof. unfold Equation2303. intro H. specialize (H F5_0 F5_2). unfold magma_op, reff488_inst, reff488_op in H. discriminate H. Qed.

Lemma reff488_not2304 : ~ @Equation2304 Fin5 reff488_inst.
Proof. unfold Equation2304. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff488_inst, reff488_op in H. discriminate H. Qed.

Lemma reff488_not2327 : ~ @Equation2327 Fin5 reff488_inst.
Proof. unfold Equation2327. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff488_inst, reff488_op in H. discriminate H. Qed.

Lemma reff488_not2328 : ~ @Equation2328 Fin5 reff488_inst.
Proof. unfold Equation2328. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff488_inst, reff488_op in H. discriminate H. Qed.

Lemma reff488_not2330 : ~ @Equation2330 Fin5 reff488_inst.
Proof. unfold Equation2330. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff488_inst, reff488_op in H. discriminate H. Qed.

Lemma reff488_not2331 : ~ @Equation2331 Fin5 reff488_inst.
Proof. unfold Equation2331. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff488_inst, reff488_op in H. discriminate H. Qed.

Lemma reff488_not2337 : ~ @Equation2337 Fin5 reff488_inst.
Proof. unfold Equation2337. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff488_inst, reff488_op in H. discriminate H. Qed.

Lemma reff488_not2338 : ~ @Equation2338 Fin5 reff488_inst.
Proof. unfold Equation2338. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff488_inst, reff488_op in H. discriminate H. Qed.

Lemma reff488_not2340 : ~ @Equation2340 Fin5 reff488_inst.
Proof. unfold Equation2340. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff488_inst, reff488_op in H. discriminate H. Qed.

Lemma reff488_not2442 : ~ @Equation2442 Fin5 reff488_inst.
Proof. unfold Equation2442. intro H. specialize (H F5_0 F5_2). unfold magma_op, reff488_inst, reff488_op in H. discriminate H. Qed.

Lemma reff488_not2443 : ~ @Equation2443 Fin5 reff488_inst.
Proof. unfold Equation2443. intro H. specialize (H F5_0 F5_3). unfold magma_op, reff488_inst, reff488_op in H. discriminate H. Qed.

Lemma reff488_not2444 : ~ @Equation2444 Fin5 reff488_inst.
Proof. unfold Equation2444. intro H. specialize (H F5_0 F5_2). unfold magma_op, reff488_inst, reff488_op in H. discriminate H. Qed.

Lemma reff488_not2446 : ~ @Equation2446 Fin5 reff488_inst.
Proof. unfold Equation2446. intro H. specialize (H F5_0 F5_2). unfold magma_op, reff488_inst, reff488_op in H. discriminate H. Qed.

Lemma reff488_not2447 : ~ @Equation2447 Fin5 reff488_inst.
Proof. unfold Equation2447. intro H. specialize (H F5_0 F5_2). unfold magma_op, reff488_inst, reff488_op in H. discriminate H. Qed.

Lemma reff488_not2449 : ~ @Equation2449 Fin5 reff488_inst.
Proof. unfold Equation2449. intro H. specialize (H F5_0 F5_3). unfold magma_op, reff488_inst, reff488_op in H. discriminate H. Qed.

Lemma reff488_not2450 : ~ @Equation2450 Fin5 reff488_inst.
Proof. unfold Equation2450. intro H. specialize (H F5_0 F5_2). unfold magma_op, reff488_inst, reff488_op in H. discriminate H. Qed.

Lemma reff488_not2456 : ~ @Equation2456 Fin5 reff488_inst.
Proof. unfold Equation2456. intro H. specialize (H F5_0 F5_3). unfold magma_op, reff488_inst, reff488_op in H. discriminate H. Qed.

Lemma reff488_not2457 : ~ @Equation2457 Fin5 reff488_inst.
Proof. unfold Equation2457. intro H. specialize (H F5_0 F5_2). unfold magma_op, reff488_inst, reff488_op in H. discriminate H. Qed.

Lemma reff488_not2459 : ~ @Equation2459 Fin5 reff488_inst.
Proof. unfold Equation2459. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff488_inst, reff488_op in H. discriminate H. Qed.

Lemma reff488_not2460 : ~ @Equation2460 Fin5 reff488_inst.
Proof. unfold Equation2460. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff488_inst, reff488_op in H. discriminate H. Qed.

Lemma reff488_not2466 : ~ @Equation2466 Fin5 reff488_inst.
Proof. unfold Equation2466. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff488_inst, reff488_op in H. discriminate H. Qed.

Lemma reff488_not2467 : ~ @Equation2467 Fin5 reff488_inst.
Proof. unfold Equation2467. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff488_inst, reff488_op in H. discriminate H. Qed.

Lemma reff488_not2469 : ~ @Equation2469 Fin5 reff488_inst.
Proof. unfold Equation2469. intro H. specialize (H F5_0 F5_2). unfold magma_op, reff488_inst, reff488_op in H. discriminate H. Qed.

Lemma reff488_not2470 : ~ @Equation2470 Fin5 reff488_inst.
Proof. unfold Equation2470. intro H. specialize (H F5_0 F5_2). unfold magma_op, reff488_inst, reff488_op in H. discriminate H. Qed.

Lemma reff488_not2493 : ~ @Equation2493 Fin5 reff488_inst.
Proof. unfold Equation2493. intro H. specialize (H F5_0 F5_3). unfold magma_op, reff488_inst, reff488_op in H. discriminate H. Qed.

Lemma reff488_not2494 : ~ @Equation2494 Fin5 reff488_inst.
Proof. unfold Equation2494. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff488_inst, reff488_op in H. discriminate H. Qed.

Lemma reff488_not2496 : ~ @Equation2496 Fin5 reff488_inst.
Proof. unfold Equation2496. intro H. specialize (H F5_0 F5_2). unfold magma_op, reff488_inst, reff488_op in H. discriminate H. Qed.

Lemma reff488_not2497 : ~ @Equation2497 Fin5 reff488_inst.
Proof. unfold Equation2497. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff488_inst, reff488_op in H. discriminate H. Qed.

Lemma reff488_not2503 : ~ @Equation2503 Fin5 reff488_inst.
Proof. unfold Equation2503. intro H. specialize (H F5_0 F5_3). unfold magma_op, reff488_inst, reff488_op in H. discriminate H. Qed.

Lemma reff488_not2504 : ~ @Equation2504 Fin5 reff488_inst.
Proof. unfold Equation2504. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff488_inst, reff488_op in H. discriminate H. Qed.

Lemma reff488_not2506 : ~ @Equation2506 Fin5 reff488_inst.
Proof. unfold Equation2506. intro H. specialize (H F5_0 F5_2). unfold magma_op, reff488_inst, reff488_op in H. discriminate H. Qed.

Lemma reff488_not2507 : ~ @Equation2507 Fin5 reff488_inst.
Proof. unfold Equation2507. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff488_inst, reff488_op in H. discriminate H. Qed.

Lemma reff488_not2530 : ~ @Equation2530 Fin5 reff488_inst.
Proof. unfold Equation2530. intro H. specialize (H F5_0 F5_3). unfold magma_op, reff488_inst, reff488_op in H. discriminate H. Qed.

Lemma reff488_not2531 : ~ @Equation2531 Fin5 reff488_inst.
Proof. unfold Equation2531. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff488_inst, reff488_op in H. discriminate H. Qed.

Lemma reff488_not2533 : ~ @Equation2533 Fin5 reff488_inst.
Proof. unfold Equation2533. intro H. specialize (H F5_0 F5_2). unfold magma_op, reff488_inst, reff488_op in H. discriminate H. Qed.

Lemma reff488_not2534 : ~ @Equation2534 Fin5 reff488_inst.
Proof. unfold Equation2534. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff488_inst, reff488_op in H. discriminate H. Qed.

Lemma reff488_not2540 : ~ @Equation2540 Fin5 reff488_inst.
Proof. unfold Equation2540. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff488_inst, reff488_op in H. discriminate H. Qed.

Lemma reff488_not2541 : ~ @Equation2541 Fin5 reff488_inst.
Proof. unfold Equation2541. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff488_inst, reff488_op in H. discriminate H. Qed.

Lemma reff488_not2543 : ~ @Equation2543 Fin5 reff488_inst.
Proof. unfold Equation2543. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff488_inst, reff488_op in H. discriminate H. Qed.

Lemma reff488_not2645 : ~ @Equation2645 Fin5 reff488_inst.
Proof. unfold Equation2645. intro H. specialize (H F5_0 F5_2). unfold magma_op, reff488_inst, reff488_op in H. discriminate H. Qed.

Lemma reff488_not2646 : ~ @Equation2646 Fin5 reff488_inst.
Proof. unfold Equation2646. intro H. specialize (H F5_0 F5_3). unfold magma_op, reff488_inst, reff488_op in H. discriminate H. Qed.

Lemma reff488_not2647 : ~ @Equation2647 Fin5 reff488_inst.
Proof. unfold Equation2647. intro H. specialize (H F5_0 F5_2). unfold magma_op, reff488_inst, reff488_op in H. discriminate H. Qed.

Lemma reff488_not2649 : ~ @Equation2649 Fin5 reff488_inst.
Proof. unfold Equation2649. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff488_inst, reff488_op in H. discriminate H. Qed.

Lemma reff488_not2650 : ~ @Equation2650 Fin5 reff488_inst.
Proof. unfold Equation2650. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff488_inst, reff488_op in H. discriminate H. Qed.

Lemma reff488_not2652 : ~ @Equation2652 Fin5 reff488_inst.
Proof. unfold Equation2652. intro H. specialize (H F5_0 F5_2). unfold magma_op, reff488_inst, reff488_op in H. discriminate H. Qed.

Lemma reff488_not2653 : ~ @Equation2653 Fin5 reff488_inst.
Proof. unfold Equation2653. intro H. specialize (H F5_0 F5_2). unfold magma_op, reff488_inst, reff488_op in H. discriminate H. Qed.

Lemma reff488_not2659 : ~ @Equation2659 Fin5 reff488_inst.
Proof. unfold Equation2659. intro H. specialize (H F5_0 F5_3). unfold magma_op, reff488_inst, reff488_op in H. discriminate H. Qed.

Lemma reff488_not2660 : ~ @Equation2660 Fin5 reff488_inst.
Proof. unfold Equation2660. intro H. specialize (H F5_0 F5_2). unfold magma_op, reff488_inst, reff488_op in H. discriminate H. Qed.

Lemma reff488_not2662 : ~ @Equation2662 Fin5 reff488_inst.
Proof. unfold Equation2662. intro H. specialize (H F5_0 F5_2). unfold magma_op, reff488_inst, reff488_op in H. discriminate H. Qed.

Lemma reff488_not2663 : ~ @Equation2663 Fin5 reff488_inst.
Proof. unfold Equation2663. intro H. specialize (H F5_0 F5_2). unfold magma_op, reff488_inst, reff488_op in H. discriminate H. Qed.

Lemma reff488_not2669 : ~ @Equation2669 Fin5 reff488_inst.
Proof. unfold Equation2669. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff488_inst, reff488_op in H. discriminate H. Qed.

Lemma reff488_not2670 : ~ @Equation2670 Fin5 reff488_inst.
Proof. unfold Equation2670. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff488_inst, reff488_op in H. discriminate H. Qed.

Lemma reff488_not2672 : ~ @Equation2672 Fin5 reff488_inst.
Proof. unfold Equation2672. intro H. specialize (H F5_0 F5_2). unfold magma_op, reff488_inst, reff488_op in H. discriminate H. Qed.

Lemma reff488_not2673 : ~ @Equation2673 Fin5 reff488_inst.
Proof. unfold Equation2673. intro H. specialize (H F5_0 F5_2). unfold magma_op, reff488_inst, reff488_op in H. discriminate H. Qed.

Lemma reff488_not2696 : ~ @Equation2696 Fin5 reff488_inst.
Proof. unfold Equation2696. intro H. specialize (H F5_0 F5_3). unfold magma_op, reff488_inst, reff488_op in H. discriminate H. Qed.

Lemma reff488_not2697 : ~ @Equation2697 Fin5 reff488_inst.
Proof. unfold Equation2697. intro H. specialize (H F5_0 F5_2). unfold magma_op, reff488_inst, reff488_op in H. discriminate H. Qed.

Lemma reff488_not2700 : ~ @Equation2700 Fin5 reff488_inst.
Proof. unfold Equation2700. intro H. specialize (H F5_0 F5_2). unfold magma_op, reff488_inst, reff488_op in H. discriminate H. Qed.

Lemma reff488_not2706 : ~ @Equation2706 Fin5 reff488_inst.
Proof. unfold Equation2706. intro H. specialize (H F5_0 F5_3). unfold magma_op, reff488_inst, reff488_op in H. discriminate H. Qed.

Lemma reff488_not2707 : ~ @Equation2707 Fin5 reff488_inst.
Proof. unfold Equation2707. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff488_inst, reff488_op in H. discriminate H. Qed.

Lemma reff488_not2709 : ~ @Equation2709 Fin5 reff488_inst.
Proof. unfold Equation2709. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff488_inst, reff488_op in H. discriminate H. Qed.

Lemma reff488_not2710 : ~ @Equation2710 Fin5 reff488_inst.
Proof. unfold Equation2710. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff488_inst, reff488_op in H. discriminate H. Qed.

Lemma reff488_not2733 : ~ @Equation2733 Fin5 reff488_inst.
Proof. unfold Equation2733. intro H. specialize (H F5_0 F5_3). unfold magma_op, reff488_inst, reff488_op in H. discriminate H. Qed.

Lemma reff488_not2734 : ~ @Equation2734 Fin5 reff488_inst.
Proof. unfold Equation2734. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff488_inst, reff488_op in H. discriminate H. Qed.

Lemma reff488_not2736 : ~ @Equation2736 Fin5 reff488_inst.
Proof. unfold Equation2736. intro H. specialize (H F5_0 F5_2). unfold magma_op, reff488_inst, reff488_op in H. discriminate H. Qed.

Lemma reff488_not2737 : ~ @Equation2737 Fin5 reff488_inst.
Proof. unfold Equation2737. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff488_inst, reff488_op in H. discriminate H. Qed.

Lemma reff488_not2743 : ~ @Equation2743 Fin5 reff488_inst.
Proof. unfold Equation2743. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff488_inst, reff488_op in H. discriminate H. Qed.

Lemma reff488_not2744 : ~ @Equation2744 Fin5 reff488_inst.
Proof. unfold Equation2744. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff488_inst, reff488_op in H. discriminate H. Qed.

Lemma reff488_not2746 : ~ @Equation2746 Fin5 reff488_inst.
Proof. unfold Equation2746. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff488_inst, reff488_op in H. discriminate H. Qed.

Lemma reff488_not2848 : ~ @Equation2848 Fin5 reff488_inst.
Proof. unfold Equation2848. intro H. specialize (H F5_0 F5_2). unfold magma_op, reff488_inst, reff488_op in H. discriminate H. Qed.

Lemma reff488_not2849 : ~ @Equation2849 Fin5 reff488_inst.
Proof. unfold Equation2849. intro H. specialize (H F5_0 F5_2). unfold magma_op, reff488_inst, reff488_op in H. discriminate H. Qed.

Lemma reff488_not2850 : ~ @Equation2850 Fin5 reff488_inst.
Proof. unfold Equation2850. intro H. specialize (H F5_0 F5_2). unfold magma_op, reff488_inst, reff488_op in H. discriminate H. Qed.

Lemma reff488_not2852 : ~ @Equation2852 Fin5 reff488_inst.
Proof. unfold Equation2852. intro H. specialize (H F5_0 F5_3). unfold magma_op, reff488_inst, reff488_op in H. discriminate H. Qed.

Lemma reff488_not2853 : ~ @Equation2853 Fin5 reff488_inst.
Proof. unfold Equation2853. intro H. specialize (H F5_0 F5_2). unfold magma_op, reff488_inst, reff488_op in H. discriminate H. Qed.

Lemma reff488_not2855 : ~ @Equation2855 Fin5 reff488_inst.
Proof. unfold Equation2855. intro H. specialize (H F5_0 F5_2). unfold magma_op, reff488_inst, reff488_op in H. discriminate H. Qed.

Lemma reff488_not2856 : ~ @Equation2856 Fin5 reff488_inst.
Proof. unfold Equation2856. intro H. specialize (H F5_0 F5_2). unfold magma_op, reff488_inst, reff488_op in H. discriminate H. Qed.

Lemma reff488_not2863 : ~ @Equation2863 Fin5 reff488_inst.
Proof. unfold Equation2863. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff488_inst, reff488_op in H. discriminate H. Qed.

Lemma reff488_not2865 : ~ @Equation2865 Fin5 reff488_inst.
Proof. unfold Equation2865. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff488_inst, reff488_op in H. discriminate H. Qed.

Lemma reff488_not2866 : ~ @Equation2866 Fin5 reff488_inst.
Proof. unfold Equation2866. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff488_inst, reff488_op in H. discriminate H. Qed.

Lemma reff488_not2872 : ~ @Equation2872 Fin5 reff488_inst.
Proof. unfold Equation2872. intro H. specialize (H F5_0 F5_3). unfold magma_op, reff488_inst, reff488_op in H. discriminate H. Qed.

Lemma reff488_not2873 : ~ @Equation2873 Fin5 reff488_inst.
Proof. unfold Equation2873. intro H. specialize (H F5_0 F5_2). unfold magma_op, reff488_inst, reff488_op in H. discriminate H. Qed.

Lemma reff488_not2875 : ~ @Equation2875 Fin5 reff488_inst.
Proof. unfold Equation2875. intro H. specialize (H F5_0 F5_2). unfold magma_op, reff488_inst, reff488_op in H. discriminate H. Qed.

Lemma reff488_not2876 : ~ @Equation2876 Fin5 reff488_inst.
Proof. unfold Equation2876. intro H. specialize (H F5_0 F5_2). unfold magma_op, reff488_inst, reff488_op in H. discriminate H. Qed.

Lemma reff488_not2899 : ~ @Equation2899 Fin5 reff488_inst.
Proof. unfold Equation2899. intro H. specialize (H F5_0 F5_3). unfold magma_op, reff488_inst, reff488_op in H. discriminate H. Qed.

Lemma reff488_not2900 : ~ @Equation2900 Fin5 reff488_inst.
Proof. unfold Equation2900. intro H. specialize (H F5_0 F5_2). unfold magma_op, reff488_inst, reff488_op in H. discriminate H. Qed.

Lemma reff488_not2902 : ~ @Equation2902 Fin5 reff488_inst.
Proof. unfold Equation2902. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff488_inst, reff488_op in H. discriminate H. Qed.

Lemma reff488_not2903 : ~ @Equation2903 Fin5 reff488_inst.
Proof. unfold Equation2903. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff488_inst, reff488_op in H. discriminate H. Qed.

Lemma reff488_not2909 : ~ @Equation2909 Fin5 reff488_inst.
Proof. unfold Equation2909. intro H. specialize (H F5_0 F5_2). unfold magma_op, reff488_inst, reff488_op in H. discriminate H. Qed.

Lemma reff488_not2910 : ~ @Equation2910 Fin5 reff488_inst.
Proof. unfold Equation2910. intro H. specialize (H F5_0 F5_2). unfold magma_op, reff488_inst, reff488_op in H. discriminate H. Qed.

Lemma reff488_not2912 : ~ @Equation2912 Fin5 reff488_inst.
Proof. unfold Equation2912. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff488_inst, reff488_op in H. discriminate H. Qed.

Lemma reff488_not2913 : ~ @Equation2913 Fin5 reff488_inst.
Proof. unfold Equation2913. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff488_inst, reff488_op in H. discriminate H. Qed.

Lemma reff488_not2936 : ~ @Equation2936 Fin5 reff488_inst.
Proof. unfold Equation2936. intro H. specialize (H F5_0 F5_3). unfold magma_op, reff488_inst, reff488_op in H. discriminate H. Qed.

Lemma reff488_not2937 : ~ @Equation2937 Fin5 reff488_inst.
Proof. unfold Equation2937. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff488_inst, reff488_op in H. discriminate H. Qed.

Lemma reff488_not2939 : ~ @Equation2939 Fin5 reff488_inst.
Proof. unfold Equation2939. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff488_inst, reff488_op in H. discriminate H. Qed.

Lemma reff488_not2940 : ~ @Equation2940 Fin5 reff488_inst.
Proof. unfold Equation2940. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff488_inst, reff488_op in H. discriminate H. Qed.

Lemma reff488_not2946 : ~ @Equation2946 Fin5 reff488_inst.
Proof. unfold Equation2946. intro H. specialize (H F5_0 F5_3). unfold magma_op, reff488_inst, reff488_op in H. discriminate H. Qed.

Lemma reff488_not2947 : ~ @Equation2947 Fin5 reff488_inst.
Proof. unfold Equation2947. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff488_inst, reff488_op in H. discriminate H. Qed.

Lemma reff488_not2949 : ~ @Equation2949 Fin5 reff488_inst.
Proof. unfold Equation2949. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff488_inst, reff488_op in H. discriminate H. Qed.

Lemma reff488_not3051 : ~ @Equation3051 Fin5 reff488_inst.
Proof. unfold Equation3051. intro H. specialize (H F5_0 F5_2). unfold magma_op, reff488_inst, reff488_op in H. discriminate H. Qed.

Lemma reff488_not3052 : ~ @Equation3052 Fin5 reff488_inst.
Proof. unfold Equation3052. intro H. specialize (H F5_0 F5_2). unfold magma_op, reff488_inst, reff488_op in H. discriminate H. Qed.

Lemma reff488_not3053 : ~ @Equation3053 Fin5 reff488_inst.
Proof. unfold Equation3053. intro H. specialize (H F5_0 F5_2). unfold magma_op, reff488_inst, reff488_op in H. discriminate H. Qed.

Lemma reff488_not3055 : ~ @Equation3055 Fin5 reff488_inst.
Proof. unfold Equation3055. intro H. specialize (H F5_0 F5_3). unfold magma_op, reff488_inst, reff488_op in H. discriminate H. Qed.

Lemma reff488_not3056 : ~ @Equation3056 Fin5 reff488_inst.
Proof. unfold Equation3056. intro H. specialize (H F5_0 F5_2). unfold magma_op, reff488_inst, reff488_op in H. discriminate H. Qed.

Lemma reff488_not3058 : ~ @Equation3058 Fin5 reff488_inst.
Proof. unfold Equation3058. intro H. specialize (H F5_0 F5_2). unfold magma_op, reff488_inst, reff488_op in H. discriminate H. Qed.

Lemma reff488_not3059 : ~ @Equation3059 Fin5 reff488_inst.
Proof. unfold Equation3059. intro H. specialize (H F5_0 F5_2). unfold magma_op, reff488_inst, reff488_op in H. discriminate H. Qed.

Lemma reff488_not3065 : ~ @Equation3065 Fin5 reff488_inst.
Proof. unfold Equation3065. intro H. specialize (H F5_0 F5_3). unfold magma_op, reff488_inst, reff488_op in H. discriminate H. Qed.

Lemma reff488_not3066 : ~ @Equation3066 Fin5 reff488_inst.
Proof. unfold Equation3066. intro H. specialize (H F5_0 F5_2). unfold magma_op, reff488_inst, reff488_op in H. discriminate H. Qed.

Lemma reff488_not3068 : ~ @Equation3068 Fin5 reff488_inst.
Proof. unfold Equation3068. intro H. specialize (H F5_0 F5_4). unfold magma_op, reff488_inst, reff488_op in H. discriminate H. Qed.

Lemma reff488_not3069 : ~ @Equation3069 Fin5 reff488_inst.
Proof. unfold Equation3069. intro H. specialize (H F5_0 F5_2). unfold magma_op, reff488_inst, reff488_op in H. discriminate H. Qed.

Lemma reff488_not3075 : ~ @Equation3075 Fin5 reff488_inst.
Proof. unfold Equation3075. intro H. specialize (H F5_0 F5_3). unfold magma_op, reff488_inst, reff488_op in H. discriminate H. Qed.

Lemma reff488_not3076 : ~ @Equation3076 Fin5 reff488_inst.
Proof. unfold Equation3076. intro H. specialize (H F5_0 F5_2). unfold magma_op, reff488_inst, reff488_op in H. discriminate H. Qed.

Lemma reff488_not3078 : ~ @Equation3078 Fin5 reff488_inst.
Proof. unfold Equation3078. intro H. specialize (H F5_0 F5_2). unfold magma_op, reff488_inst, reff488_op in H. discriminate H. Qed.

Lemma reff488_not3079 : ~ @Equation3079 Fin5 reff488_inst.
Proof. unfold Equation3079. intro H. specialize (H F5_0 F5_2). unfold magma_op, reff488_inst, reff488_op in H. discriminate H. Qed.

Lemma reff488_not3102 : ~ @Equation3102 Fin5 reff488_inst.
Proof. unfold Equation3102. intro H. specialize (H F5_0 F5_3). unfold magma_op, reff488_inst, reff488_op in H. discriminate H. Qed.

Lemma reff488_not3103 : ~ @Equation3103 Fin5 reff488_inst.
Proof. unfold Equation3103. intro H. specialize (H F5_0 F5_2). unfold magma_op, reff488_inst, reff488_op in H. discriminate H. Qed.

Lemma reff488_not3105 : ~ @Equation3105 Fin5 reff488_inst.
Proof. unfold Equation3105. intro H. specialize (H F5_0 F5_2). unfold magma_op, reff488_inst, reff488_op in H. discriminate H. Qed.

Lemma reff488_not3106 : ~ @Equation3106 Fin5 reff488_inst.
Proof. unfold Equation3106. intro H. specialize (H F5_0 F5_2). unfold magma_op, reff488_inst, reff488_op in H. discriminate H. Qed.

Lemma reff488_not3112 : ~ @Equation3112 Fin5 reff488_inst.
Proof. unfold Equation3112. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff488_inst, reff488_op in H. discriminate H. Qed.

Lemma reff488_not3113 : ~ @Equation3113 Fin5 reff488_inst.
Proof. unfold Equation3113. intro H. specialize (H F5_0 F5_2). unfold magma_op, reff488_inst, reff488_op in H. discriminate H. Qed.

Lemma reff488_not3115 : ~ @Equation3115 Fin5 reff488_inst.
Proof. unfold Equation3115. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff488_inst, reff488_op in H. discriminate H. Qed.

Lemma reff488_not3116 : ~ @Equation3116 Fin5 reff488_inst.
Proof. unfold Equation3116. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff488_inst, reff488_op in H. discriminate H. Qed.

Lemma reff488_not3139 : ~ @Equation3139 Fin5 reff488_inst.
Proof. unfold Equation3139. intro H. specialize (H F5_0 F5_3). unfold magma_op, reff488_inst, reff488_op in H. discriminate H. Qed.

Lemma reff488_not3140 : ~ @Equation3140 Fin5 reff488_inst.
Proof. unfold Equation3140. intro H. specialize (H F5_0 F5_2). unfold magma_op, reff488_inst, reff488_op in H. discriminate H. Qed.

Lemma reff488_not3142 : ~ @Equation3142 Fin5 reff488_inst.
Proof. unfold Equation3142. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff488_inst, reff488_op in H. discriminate H. Qed.

Lemma reff488_not3143 : ~ @Equation3143 Fin5 reff488_inst.
Proof. unfold Equation3143. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff488_inst, reff488_op in H. discriminate H. Qed.

Lemma reff488_not3149 : ~ @Equation3149 Fin5 reff488_inst.
Proof. unfold Equation3149. intro H. specialize (H F5_0 F5_3). unfold magma_op, reff488_inst, reff488_op in H. discriminate H. Qed.

Lemma reff488_not3150 : ~ @Equation3150 Fin5 reff488_inst.
Proof. unfold Equation3150. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff488_inst, reff488_op in H. discriminate H. Qed.

Lemma reff488_not3152 : ~ @Equation3152 Fin5 reff488_inst.
Proof. unfold Equation3152. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff488_inst, reff488_op in H. discriminate H. Qed.

Lemma reff488_not3254 : ~ @Equation3254 Fin5 reff488_inst.
Proof. unfold Equation3254. intro H. specialize (H F5_0 F5_3). unfold magma_op, reff488_inst, reff488_op in H. discriminate H. Qed.

Lemma reff488_not3256 : ~ @Equation3256 Fin5 reff488_inst.
Proof. unfold Equation3256. intro H. specialize (H F5_0 F5_3). unfold magma_op, reff488_inst, reff488_op in H. discriminate H. Qed.

Lemma reff488_not3258 : ~ @Equation3258 Fin5 reff488_inst.
Proof. unfold Equation3258. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff488_inst, reff488_op in H. discriminate H. Qed.

Lemma reff488_not3259 : ~ @Equation3259 Fin5 reff488_inst.
Proof. unfold Equation3259. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff488_inst, reff488_op in H. discriminate H. Qed.

Lemma reff488_not3261 : ~ @Equation3261 Fin5 reff488_inst.
Proof. unfold Equation3261. intro H. specialize (H F5_0 F5_3). unfold magma_op, reff488_inst, reff488_op in H. discriminate H. Qed.

Lemma reff488_not3262 : ~ @Equation3262 Fin5 reff488_inst.
Proof. unfold Equation3262. intro H. specialize (H F5_0 F5_2). unfold magma_op, reff488_inst, reff488_op in H. discriminate H. Qed.

Lemma reff488_not3268 : ~ @Equation3268 Fin5 reff488_inst.
Proof. unfold Equation3268. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff488_inst, reff488_op in H. discriminate H. Qed.

Lemma reff488_not3269 : ~ @Equation3269 Fin5 reff488_inst.
Proof. unfold Equation3269. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff488_inst, reff488_op in H. discriminate H. Qed.

Lemma reff488_not3271 : ~ @Equation3271 Fin5 reff488_inst.
Proof. unfold Equation3271. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff488_inst, reff488_op in H. discriminate H. Qed.

Lemma reff488_not3272 : ~ @Equation3272 Fin5 reff488_inst.
Proof. unfold Equation3272. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff488_inst, reff488_op in H. discriminate H. Qed.

Lemma reff488_not3278 : ~ @Equation3278 Fin5 reff488_inst.
Proof. unfold Equation3278. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff488_inst, reff488_op in H. discriminate H. Qed.

Lemma reff488_not3279 : ~ @Equation3279 Fin5 reff488_inst.
Proof. unfold Equation3279. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff488_inst, reff488_op in H. discriminate H. Qed.

Lemma reff488_not3281 : ~ @Equation3281 Fin5 reff488_inst.
Proof. unfold Equation3281. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff488_inst, reff488_op in H. discriminate H. Qed.

Lemma reff488_not3306 : ~ @Equation3306 Fin5 reff488_inst.
Proof. unfold Equation3306. intro H. specialize (H F5_0 F5_2). unfold magma_op, reff488_inst, reff488_op in H. discriminate H. Qed.

Lemma reff488_not3308 : ~ @Equation3308 Fin5 reff488_inst.
Proof. unfold Equation3308. intro H. specialize (H F5_0 F5_2). unfold magma_op, reff488_inst, reff488_op in H. discriminate H. Qed.

Lemma reff488_not3309 : ~ @Equation3309 Fin5 reff488_inst.
Proof. unfold Equation3309. intro H. specialize (H F5_0 F5_2). unfold magma_op, reff488_inst, reff488_op in H. discriminate H. Qed.

Lemma reff488_not3315 : ~ @Equation3315 Fin5 reff488_inst.
Proof. unfold Equation3315. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff488_inst, reff488_op in H. discriminate H. Qed.

Lemma reff488_not3316 : ~ @Equation3316 Fin5 reff488_inst.
Proof. unfold Equation3316. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff488_inst, reff488_op in H. discriminate H. Qed.

Lemma reff488_not3318 : ~ @Equation3318 Fin5 reff488_inst.
Proof. unfold Equation3318. intro H. specialize (H F5_0 F5_2). unfold magma_op, reff488_inst, reff488_op in H. discriminate H. Qed.

Lemma reff488_not3342 : ~ @Equation3342 Fin5 reff488_inst.
Proof. unfold Equation3342. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff488_inst, reff488_op in H. discriminate H. Qed.

Lemma reff488_not3343 : ~ @Equation3343 Fin5 reff488_inst.
Proof. unfold Equation3343. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff488_inst, reff488_op in H. discriminate H. Qed.

Lemma reff488_not3345 : ~ @Equation3345 Fin5 reff488_inst.
Proof. unfold Equation3345. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff488_inst, reff488_op in H. discriminate H. Qed.

Lemma reff488_not3346 : ~ @Equation3346 Fin5 reff488_inst.
Proof. unfold Equation3346. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff488_inst, reff488_op in H. discriminate H. Qed.

Lemma reff488_not3352 : ~ @Equation3352 Fin5 reff488_inst.
Proof. unfold Equation3352. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff488_inst, reff488_op in H. discriminate H. Qed.

Lemma reff488_not3353 : ~ @Equation3353 Fin5 reff488_inst.
Proof. unfold Equation3353. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff488_inst, reff488_op in H. discriminate H. Qed.

Lemma reff488_not3457 : ~ @Equation3457 Fin5 reff488_inst.
Proof. unfold Equation3457. intro H. specialize (H F5_0 F5_3). unfold magma_op, reff488_inst, reff488_op in H. discriminate H. Qed.

Lemma reff488_not3458 : ~ @Equation3458 Fin5 reff488_inst.
Proof. unfold Equation3458. intro H. specialize (H F5_0 F5_2). unfold magma_op, reff488_inst, reff488_op in H. discriminate H. Qed.

Lemma reff488_not3459 : ~ @Equation3459 Fin5 reff488_inst.
Proof. unfold Equation3459. intro H. specialize (H F5_0 F5_3). unfold magma_op, reff488_inst, reff488_op in H. discriminate H. Qed.

Lemma reff488_not3461 : ~ @Equation3461 Fin5 reff488_inst.
Proof. unfold Equation3461. intro H. specialize (H F5_0 F5_3). unfold magma_op, reff488_inst, reff488_op in H. discriminate H. Qed.

Lemma reff488_not3462 : ~ @Equation3462 Fin5 reff488_inst.
Proof. unfold Equation3462. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff488_inst, reff488_op in H. discriminate H. Qed.

Lemma reff488_not3464 : ~ @Equation3464 Fin5 reff488_inst.
Proof. unfold Equation3464. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff488_inst, reff488_op in H. discriminate H. Qed.

Lemma reff488_not3465 : ~ @Equation3465 Fin5 reff488_inst.
Proof. unfold Equation3465. intro H. specialize (H F5_0 F5_2). unfold magma_op, reff488_inst, reff488_op in H. discriminate H. Qed.

Lemma reff488_not3472 : ~ @Equation3472 Fin5 reff488_inst.
Proof. unfold Equation3472. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff488_inst, reff488_op in H. discriminate H. Qed.

Lemma reff488_not3474 : ~ @Equation3474 Fin5 reff488_inst.
Proof. unfold Equation3474. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff488_inst, reff488_op in H. discriminate H. Qed.

Lemma reff488_not3475 : ~ @Equation3475 Fin5 reff488_inst.
Proof. unfold Equation3475. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff488_inst, reff488_op in H. discriminate H. Qed.

Lemma reff488_not3481 : ~ @Equation3481 Fin5 reff488_inst.
Proof. unfold Equation3481. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff488_inst, reff488_op in H. discriminate H. Qed.

Lemma reff488_not3482 : ~ @Equation3482 Fin5 reff488_inst.
Proof. unfold Equation3482. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff488_inst, reff488_op in H. discriminate H. Qed.

Lemma reff488_not3484 : ~ @Equation3484 Fin5 reff488_inst.
Proof. unfold Equation3484. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff488_inst, reff488_op in H. discriminate H. Qed.

Lemma reff488_not3509 : ~ @Equation3509 Fin5 reff488_inst.
Proof. unfold Equation3509. intro H. specialize (H F5_0 F5_2). unfold magma_op, reff488_inst, reff488_op in H. discriminate H. Qed.

Lemma reff488_not3511 : ~ @Equation3511 Fin5 reff488_inst.
Proof. unfold Equation3511. intro H. specialize (H F5_0 F5_3). unfold magma_op, reff488_inst, reff488_op in H. discriminate H. Qed.

Lemma reff488_not3512 : ~ @Equation3512 Fin5 reff488_inst.
Proof. unfold Equation3512. intro H. specialize (H F5_0 F5_2). unfold magma_op, reff488_inst, reff488_op in H. discriminate H. Qed.

Lemma reff488_not3518 : ~ @Equation3518 Fin5 reff488_inst.
Proof. unfold Equation3518. intro H. specialize (H F5_0 F5_2). unfold magma_op, reff488_inst, reff488_op in H. discriminate H. Qed.

Lemma reff488_not3519 : ~ @Equation3519 Fin5 reff488_inst.
Proof. unfold Equation3519. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff488_inst, reff488_op in H. discriminate H. Qed.

Lemma reff488_not3521 : ~ @Equation3521 Fin5 reff488_inst.
Proof. unfold Equation3521. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff488_inst, reff488_op in H. discriminate H. Qed.

Lemma reff488_not3545 : ~ @Equation3545 Fin5 reff488_inst.
Proof. unfold Equation3545. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff488_inst, reff488_op in H. discriminate H. Qed.

Lemma reff488_not3546 : ~ @Equation3546 Fin5 reff488_inst.
Proof. unfold Equation3546. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff488_inst, reff488_op in H. discriminate H. Qed.

Lemma reff488_not3548 : ~ @Equation3548 Fin5 reff488_inst.
Proof. unfold Equation3548. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff488_inst, reff488_op in H. discriminate H. Qed.

Lemma reff488_not3549 : ~ @Equation3549 Fin5 reff488_inst.
Proof. unfold Equation3549. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff488_inst, reff488_op in H. discriminate H. Qed.

Lemma reff488_not3555 : ~ @Equation3555 Fin5 reff488_inst.
Proof. unfold Equation3555. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff488_inst, reff488_op in H. discriminate H. Qed.

Lemma reff488_not3556 : ~ @Equation3556 Fin5 reff488_inst.
Proof. unfold Equation3556. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff488_inst, reff488_op in H. discriminate H. Qed.

Lemma reff488_not3558 : ~ @Equation3558 Fin5 reff488_inst.
Proof. unfold Equation3558. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff488_inst, reff488_op in H. discriminate H. Qed.

Lemma reff488_not3660 : ~ @Equation3660 Fin5 reff488_inst.
Proof. unfold Equation3660. intro H. specialize (H F5_0 F5_3). unfold magma_op, reff488_inst, reff488_op in H. discriminate H. Qed.

Lemma reff488_not3661 : ~ @Equation3661 Fin5 reff488_inst.
Proof. unfold Equation3661. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff488_inst, reff488_op in H. discriminate H. Qed.

Lemma reff488_not3662 : ~ @Equation3662 Fin5 reff488_inst.
Proof. unfold Equation3662. intro H. specialize (H F5_0 F5_2). unfold magma_op, reff488_inst, reff488_op in H. discriminate H. Qed.

Lemma reff488_not3664 : ~ @Equation3664 Fin5 reff488_inst.
Proof. unfold Equation3664. intro H. specialize (H F5_0 F5_2). unfold magma_op, reff488_inst, reff488_op in H. discriminate H. Qed.

Lemma reff488_not3665 : ~ @Equation3665 Fin5 reff488_inst.
Proof. unfold Equation3665. intro H. specialize (H F5_0 F5_2). unfold magma_op, reff488_inst, reff488_op in H. discriminate H. Qed.

Lemma reff488_not3667 : ~ @Equation3667 Fin5 reff488_inst.
Proof. unfold Equation3667. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff488_inst, reff488_op in H. discriminate H. Qed.

Lemma reff488_not3668 : ~ @Equation3668 Fin5 reff488_inst.
Proof. unfold Equation3668. intro H. specialize (H F5_0 F5_2). unfold magma_op, reff488_inst, reff488_op in H. discriminate H. Qed.

Lemma reff488_not3674 : ~ @Equation3674 Fin5 reff488_inst.
Proof. unfold Equation3674. intro H. specialize (H F5_0 F5_3). unfold magma_op, reff488_inst, reff488_op in H. discriminate H. Qed.

Lemma reff488_not3677 : ~ @Equation3677 Fin5 reff488_inst.
Proof. unfold Equation3677. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff488_inst, reff488_op in H. discriminate H. Qed.

Lemma reff488_not3678 : ~ @Equation3678 Fin5 reff488_inst.
Proof. unfold Equation3678. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff488_inst, reff488_op in H. discriminate H. Qed.

Lemma reff488_not3684 : ~ @Equation3684 Fin5 reff488_inst.
Proof. unfold Equation3684. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff488_inst, reff488_op in H. discriminate H. Qed.

Lemma reff488_not3685 : ~ @Equation3685 Fin5 reff488_inst.
Proof. unfold Equation3685. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff488_inst, reff488_op in H. discriminate H. Qed.

Lemma reff488_not3687 : ~ @Equation3687 Fin5 reff488_inst.
Proof. unfold Equation3687. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff488_inst, reff488_op in H. discriminate H. Qed.

Lemma reff488_not3712 : ~ @Equation3712 Fin5 reff488_inst.
Proof. unfold Equation3712. intro H. specialize (H F5_0 F5_2). unfold magma_op, reff488_inst, reff488_op in H. discriminate H. Qed.

Lemma reff488_not3714 : ~ @Equation3714 Fin5 reff488_inst.
Proof. unfold Equation3714. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff488_inst, reff488_op in H. discriminate H. Qed.

Lemma reff488_not3721 : ~ @Equation3721 Fin5 reff488_inst.
Proof. unfold Equation3721. intro H. specialize (H F5_0 F5_2). unfold magma_op, reff488_inst, reff488_op in H. discriminate H. Qed.

Lemma reff488_not3724 : ~ @Equation3724 Fin5 reff488_inst.
Proof. unfold Equation3724. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff488_inst, reff488_op in H. discriminate H. Qed.

Lemma reff488_not3725 : ~ @Equation3725 Fin5 reff488_inst.
Proof. unfold Equation3725. intro H. specialize (H F5_0 F5_4). unfold magma_op, reff488_inst, reff488_op in H. discriminate H. Qed.

Lemma reff488_not3748 : ~ @Equation3748 Fin5 reff488_inst.
Proof. unfold Equation3748. intro H. specialize (H F5_0 F5_2). unfold magma_op, reff488_inst, reff488_op in H. discriminate H. Qed.

Lemma reff488_not3749 : ~ @Equation3749 Fin5 reff488_inst.
Proof. unfold Equation3749. intro H. specialize (H F5_0 F5_2). unfold magma_op, reff488_inst, reff488_op in H. discriminate H. Qed.

Lemma reff488_not3751 : ~ @Equation3751 Fin5 reff488_inst.
Proof. unfold Equation3751. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff488_inst, reff488_op in H. discriminate H. Qed.

Lemma reff488_not3752 : ~ @Equation3752 Fin5 reff488_inst.
Proof. unfold Equation3752. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff488_inst, reff488_op in H. discriminate H. Qed.

Lemma reff488_not3758 : ~ @Equation3758 Fin5 reff488_inst.
Proof. unfold Equation3758. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff488_inst, reff488_op in H. discriminate H. Qed.

Lemma reff488_not3759 : ~ @Equation3759 Fin5 reff488_inst.
Proof. unfold Equation3759. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff488_inst, reff488_op in H. discriminate H. Qed.

Lemma reff488_not3761 : ~ @Equation3761 Fin5 reff488_inst.
Proof. unfold Equation3761. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff488_inst, reff488_op in H. discriminate H. Qed.

Lemma reff488_not3864 : ~ @Equation3864 Fin5 reff488_inst.
Proof. unfold Equation3864. intro H. specialize (H F5_0 F5_3). unfold magma_op, reff488_inst, reff488_op in H. discriminate H. Qed.

Lemma reff488_not3865 : ~ @Equation3865 Fin5 reff488_inst.
Proof. unfold Equation3865. intro H. specialize (H F5_0 F5_2). unfold magma_op, reff488_inst, reff488_op in H. discriminate H. Qed.

Lemma reff488_not3867 : ~ @Equation3867 Fin5 reff488_inst.
Proof. unfold Equation3867. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff488_inst, reff488_op in H. discriminate H. Qed.

Lemma reff488_not3868 : ~ @Equation3868 Fin5 reff488_inst.
Proof. unfold Equation3868. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff488_inst, reff488_op in H. discriminate H. Qed.

Lemma reff488_not3870 : ~ @Equation3870 Fin5 reff488_inst.
Proof. unfold Equation3870. intro H. specialize (H F5_0 F5_2). unfold magma_op, reff488_inst, reff488_op in H. discriminate H. Qed.

Lemma reff488_not3871 : ~ @Equation3871 Fin5 reff488_inst.
Proof. unfold Equation3871. intro H. specialize (H F5_0 F5_2). unfold magma_op, reff488_inst, reff488_op in H. discriminate H. Qed.

Lemma reff488_not3877 : ~ @Equation3877 Fin5 reff488_inst.
Proof. unfold Equation3877. intro H. specialize (H F5_0 F5_3). unfold magma_op, reff488_inst, reff488_op in H. discriminate H. Qed.

Lemma reff488_not3878 : ~ @Equation3878 Fin5 reff488_inst.
Proof. unfold Equation3878. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff488_inst, reff488_op in H. discriminate H. Qed.

Lemma reff488_not3880 : ~ @Equation3880 Fin5 reff488_inst.
Proof. unfold Equation3880. intro H. specialize (H F5_0 F5_2). unfold magma_op, reff488_inst, reff488_op in H. discriminate H. Qed.

Lemma reff488_not3881 : ~ @Equation3881 Fin5 reff488_inst.
Proof. unfold Equation3881. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff488_inst, reff488_op in H. discriminate H. Qed.

Lemma reff488_not3887 : ~ @Equation3887 Fin5 reff488_inst.
Proof. unfold Equation3887. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff488_inst, reff488_op in H. discriminate H. Qed.

Lemma reff488_not3888 : ~ @Equation3888 Fin5 reff488_inst.
Proof. unfold Equation3888. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff488_inst, reff488_op in H. discriminate H. Qed.

Lemma reff488_not3890 : ~ @Equation3890 Fin5 reff488_inst.
Proof. unfold Equation3890. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff488_inst, reff488_op in H. discriminate H. Qed.

Lemma reff488_not3917 : ~ @Equation3917 Fin5 reff488_inst.
Proof. unfold Equation3917. intro H. specialize (H F5_0 F5_2). unfold magma_op, reff488_inst, reff488_op in H. discriminate H. Qed.

Lemma reff488_not3924 : ~ @Equation3924 Fin5 reff488_inst.
Proof. unfold Equation3924. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff488_inst, reff488_op in H. discriminate H. Qed.

Lemma reff488_not3925 : ~ @Equation3925 Fin5 reff488_inst.
Proof. unfold Equation3925. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff488_inst, reff488_op in H. discriminate H. Qed.

Lemma reff488_not3927 : ~ @Equation3927 Fin5 reff488_inst.
Proof. unfold Equation3927. intro H. specialize (H F5_0 F5_2). unfold magma_op, reff488_inst, reff488_op in H. discriminate H. Qed.

Lemma reff488_not3928 : ~ @Equation3928 Fin5 reff488_inst.
Proof. unfold Equation3928. intro H. specialize (H F5_0 F5_4). unfold magma_op, reff488_inst, reff488_op in H. discriminate H. Qed.

Lemma reff488_not3951 : ~ @Equation3951 Fin5 reff488_inst.
Proof. unfold Equation3951. intro H. specialize (H F5_0 F5_2). unfold magma_op, reff488_inst, reff488_op in H. discriminate H. Qed.

Lemma reff488_not3952 : ~ @Equation3952 Fin5 reff488_inst.
Proof. unfold Equation3952. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff488_inst, reff488_op in H. discriminate H. Qed.

Lemma reff488_not3954 : ~ @Equation3954 Fin5 reff488_inst.
Proof. unfold Equation3954. intro H. specialize (H F5_0 F5_2). unfold magma_op, reff488_inst, reff488_op in H. discriminate H. Qed.

Lemma reff488_not3955 : ~ @Equation3955 Fin5 reff488_inst.
Proof. unfold Equation3955. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff488_inst, reff488_op in H. discriminate H. Qed.

Lemma reff488_not3961 : ~ @Equation3961 Fin5 reff488_inst.
Proof. unfold Equation3961. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff488_inst, reff488_op in H. discriminate H. Qed.

Lemma reff488_not3962 : ~ @Equation3962 Fin5 reff488_inst.
Proof. unfold Equation3962. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff488_inst, reff488_op in H. discriminate H. Qed.

Lemma reff488_not3964 : ~ @Equation3964 Fin5 reff488_inst.
Proof. unfold Equation3964. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff488_inst, reff488_op in H. discriminate H. Qed.

Lemma reff488_not4066 : ~ @Equation4066 Fin5 reff488_inst.
Proof. unfold Equation4066. intro H. specialize (H F5_0 F5_2). unfold magma_op, reff488_inst, reff488_op in H. discriminate H. Qed.

Lemma reff488_not4067 : ~ @Equation4067 Fin5 reff488_inst.
Proof. unfold Equation4067. intro H. specialize (H F5_0 F5_2). unfold magma_op, reff488_inst, reff488_op in H. discriminate H. Qed.

Lemma reff488_not4068 : ~ @Equation4068 Fin5 reff488_inst.
Proof. unfold Equation4068. intro H. specialize (H F5_0 F5_2). unfold magma_op, reff488_inst, reff488_op in H. discriminate H. Qed.

Lemma reff488_not4070 : ~ @Equation4070 Fin5 reff488_inst.
Proof. unfold Equation4070. intro H. specialize (H F5_0 F5_3). unfold magma_op, reff488_inst, reff488_op in H. discriminate H. Qed.

Lemma reff488_not4071 : ~ @Equation4071 Fin5 reff488_inst.
Proof. unfold Equation4071. intro H. specialize (H F5_0 F5_2). unfold magma_op, reff488_inst, reff488_op in H. discriminate H. Qed.

Lemma reff488_not4073 : ~ @Equation4073 Fin5 reff488_inst.
Proof. unfold Equation4073. intro H. specialize (H F5_0 F5_2). unfold magma_op, reff488_inst, reff488_op in H. discriminate H. Qed.

Lemma reff488_not4074 : ~ @Equation4074 Fin5 reff488_inst.
Proof. unfold Equation4074. intro H. specialize (H F5_0 F5_2). unfold magma_op, reff488_inst, reff488_op in H. discriminate H. Qed.

Lemma reff488_not4080 : ~ @Equation4080 Fin5 reff488_inst.
Proof. unfold Equation4080. intro H. specialize (H F5_0 F5_3). unfold magma_op, reff488_inst, reff488_op in H. discriminate H. Qed.

Lemma reff488_not4081 : ~ @Equation4081 Fin5 reff488_inst.
Proof. unfold Equation4081. intro H. specialize (H F5_0 F5_2). unfold magma_op, reff488_inst, reff488_op in H. discriminate H. Qed.

Lemma reff488_not4083 : ~ @Equation4083 Fin5 reff488_inst.
Proof. unfold Equation4083. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff488_inst, reff488_op in H. discriminate H. Qed.

Lemma reff488_not4084 : ~ @Equation4084 Fin5 reff488_inst.
Proof. unfold Equation4084. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff488_inst, reff488_op in H. discriminate H. Qed.

Lemma reff488_not4090 : ~ @Equation4090 Fin5 reff488_inst.
Proof. unfold Equation4090. intro H. specialize (H F5_0 F5_3). unfold magma_op, reff488_inst, reff488_op in H. discriminate H. Qed.

Lemma reff488_not4091 : ~ @Equation4091 Fin5 reff488_inst.
Proof. unfold Equation4091. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff488_inst, reff488_op in H. discriminate H. Qed.

Lemma reff488_not4093 : ~ @Equation4093 Fin5 reff488_inst.
Proof. unfold Equation4093. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff488_inst, reff488_op in H. discriminate H. Qed.

Lemma reff488_not4120 : ~ @Equation4120 Fin5 reff488_inst.
Proof. unfold Equation4120. intro H. specialize (H F5_0 F5_2). unfold magma_op, reff488_inst, reff488_op in H. discriminate H. Qed.

Lemma reff488_not4121 : ~ @Equation4121 Fin5 reff488_inst.
Proof. unfold Equation4121. intro H. specialize (H F5_0 F5_4). unfold magma_op, reff488_inst, reff488_op in H. discriminate H. Qed.

Lemma reff488_not4127 : ~ @Equation4127 Fin5 reff488_inst.
Proof. unfold Equation4127. intro H. specialize (H F5_0 F5_2). unfold magma_op, reff488_inst, reff488_op in H. discriminate H. Qed.

Lemma reff488_not4128 : ~ @Equation4128 Fin5 reff488_inst.
Proof. unfold Equation4128. intro H. specialize (H F5_0 F5_2). unfold magma_op, reff488_inst, reff488_op in H. discriminate H. Qed.

Lemma reff488_not4130 : ~ @Equation4130 Fin5 reff488_inst.
Proof. unfold Equation4130. intro H. specialize (H F5_0 F5_2). unfold magma_op, reff488_inst, reff488_op in H. discriminate H. Qed.

Lemma reff488_not4131 : ~ @Equation4131 Fin5 reff488_inst.
Proof. unfold Equation4131. intro H. specialize (H F5_0 F5_4). unfold magma_op, reff488_inst, reff488_op in H. discriminate H. Qed.

Lemma reff488_not4155 : ~ @Equation4155 Fin5 reff488_inst.
Proof. unfold Equation4155. intro H. specialize (H F5_0 F5_3). unfold magma_op, reff488_inst, reff488_op in H. discriminate H. Qed.

Lemma reff488_not4157 : ~ @Equation4157 Fin5 reff488_inst.
Proof. unfold Equation4157. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff488_inst, reff488_op in H. discriminate H. Qed.

Lemma reff488_not4158 : ~ @Equation4158 Fin5 reff488_inst.
Proof. unfold Equation4158. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff488_inst, reff488_op in H. discriminate H. Qed.

Lemma reff488_not4164 : ~ @Equation4164 Fin5 reff488_inst.
Proof. unfold Equation4164. intro H. specialize (H F5_0 F5_2). unfold magma_op, reff488_inst, reff488_op in H. discriminate H. Qed.

Lemma reff488_not4165 : ~ @Equation4165 Fin5 reff488_inst.
Proof. unfold Equation4165. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff488_inst, reff488_op in H. discriminate H. Qed.

Lemma reff488_not4167 : ~ @Equation4167 Fin5 reff488_inst.
Proof. unfold Equation4167. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff488_inst, reff488_op in H. discriminate H. Qed.

Lemma reff488_not4268 : ~ @Equation4268 Fin5 reff488_inst.
Proof. unfold Equation4268. intro H. specialize (H F5_0 F5_3). unfold magma_op, reff488_inst, reff488_op in H. discriminate H. Qed.

Lemma reff488_not4269 : ~ @Equation4269 Fin5 reff488_inst.
Proof. unfold Equation4269. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff488_inst, reff488_op in H. discriminate H. Qed.

Lemma reff488_not4270 : ~ @Equation4270 Fin5 reff488_inst.
Proof. unfold Equation4270. intro H. specialize (H F5_0 F5_2). unfold magma_op, reff488_inst, reff488_op in H. discriminate H. Qed.

Lemma reff488_not4272 : ~ @Equation4272 Fin5 reff488_inst.
Proof. unfold Equation4272. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff488_inst, reff488_op in H. discriminate H. Qed.

Lemma reff488_not4273 : ~ @Equation4273 Fin5 reff488_inst.
Proof. unfold Equation4273. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff488_inst, reff488_op in H. discriminate H. Qed.

Lemma reff488_not4275 : ~ @Equation4275 Fin5 reff488_inst.
Proof. unfold Equation4275. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff488_inst, reff488_op in H. discriminate H. Qed.

Lemma reff488_not4276 : ~ @Equation4276 Fin5 reff488_inst.
Proof. unfold Equation4276. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff488_inst, reff488_op in H. discriminate H. Qed.

Lemma reff488_not4283 : ~ @Equation4283 Fin5 reff488_inst.
Proof. unfold Equation4283. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff488_inst, reff488_op in H. discriminate H. Qed.

Lemma reff488_not4284 : ~ @Equation4284 Fin5 reff488_inst.
Proof. unfold Equation4284. intro H. specialize (H F5_0 F5_2). unfold magma_op, reff488_inst, reff488_op in H. discriminate H. Qed.

Lemma reff488_not4290 : ~ @Equation4290 Fin5 reff488_inst.
Proof. unfold Equation4290. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff488_inst, reff488_op in H. discriminate H. Qed.

Lemma reff488_not4291 : ~ @Equation4291 Fin5 reff488_inst.
Proof. unfold Equation4291. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff488_inst, reff488_op in H. discriminate H. Qed.

Lemma reff488_not4293 : ~ @Equation4293 Fin5 reff488_inst.
Proof. unfold Equation4293. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff488_inst, reff488_op in H. discriminate H. Qed.

Lemma reff488_not4314 : ~ @Equation4314 Fin5 reff488_inst.
Proof. unfold Equation4314. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff488_inst, reff488_op in H. discriminate H. Qed.

Lemma reff488_not4320 : ~ @Equation4320 Fin5 reff488_inst.
Proof. unfold Equation4320. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff488_inst, reff488_op in H. discriminate H. Qed.

Lemma reff488_not4321 : ~ @Equation4321 Fin5 reff488_inst.
Proof. unfold Equation4321. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff488_inst, reff488_op in H. discriminate H. Qed.

Lemma reff488_not4343 : ~ @Equation4343 Fin5 reff488_inst.
Proof. unfold Equation4343. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff488_inst, reff488_op in H. discriminate H. Qed.

Lemma reff488_not4396 : ~ @Equation4396 Fin5 reff488_inst.
Proof. unfold Equation4396. intro H. specialize (H F5_0 F5_2). unfold magma_op, reff488_inst, reff488_op in H. discriminate H. Qed.

Lemma reff488_not4398 : ~ @Equation4398 Fin5 reff488_inst.
Proof. unfold Equation4398. intro H. specialize (H F5_0 F5_2). unfold magma_op, reff488_inst, reff488_op in H. discriminate H. Qed.

Lemma reff488_not4399 : ~ @Equation4399 Fin5 reff488_inst.
Proof. unfold Equation4399. intro H. specialize (H F5_0 F5_2). unfold magma_op, reff488_inst, reff488_op in H. discriminate H. Qed.

Lemma reff488_not4405 : ~ @Equation4405 Fin5 reff488_inst.
Proof. unfold Equation4405. intro H. specialize (H F5_0 F5_3). unfold magma_op, reff488_inst, reff488_op in H. discriminate H. Qed.

Lemma reff488_not4406 : ~ @Equation4406 Fin5 reff488_inst.
Proof. unfold Equation4406. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff488_inst, reff488_op in H. discriminate H. Qed.

Lemma reff488_not4408 : ~ @Equation4408 Fin5 reff488_inst.
Proof. unfold Equation4408. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff488_inst, reff488_op in H. discriminate H. Qed.

Lemma reff488_not4433 : ~ @Equation4433 Fin5 reff488_inst.
Proof. unfold Equation4433. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff488_inst, reff488_op in H. discriminate H. Qed.

Lemma reff488_not4435 : ~ @Equation4435 Fin5 reff488_inst.
Proof. unfold Equation4435. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff488_inst, reff488_op in H. discriminate H. Qed.

Lemma reff488_not4436 : ~ @Equation4436 Fin5 reff488_inst.
Proof. unfold Equation4436. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff488_inst, reff488_op in H. discriminate H. Qed.

Lemma reff488_not4442 : ~ @Equation4442 Fin5 reff488_inst.
Proof. unfold Equation4442. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff488_inst, reff488_op in H. discriminate H. Qed.

Lemma reff488_not4443 : ~ @Equation4443 Fin5 reff488_inst.
Proof. unfold Equation4443. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff488_inst, reff488_op in H. discriminate H. Qed.

Lemma reff488_not4445 : ~ @Equation4445 Fin5 reff488_inst.
Proof. unfold Equation4445. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff488_inst, reff488_op in H. discriminate H. Qed.

Lemma reff488_not4472 : ~ @Equation4472 Fin5 reff488_inst.
Proof. unfold Equation4472. intro H. specialize (H F5_0 F5_2). unfold magma_op, reff488_inst, reff488_op in H. discriminate H. Qed.

Lemma reff488_not4473 : ~ @Equation4473 Fin5 reff488_inst.
Proof. unfold Equation4473. intro H. specialize (H F5_0 F5_4). unfold magma_op, reff488_inst, reff488_op in H. discriminate H. Qed.

Lemma reff488_not4479 : ~ @Equation4479 Fin5 reff488_inst.
Proof. unfold Equation4479. intro H. specialize (H F5_0 F5_2). unfold magma_op, reff488_inst, reff488_op in H. discriminate H. Qed.

Lemma reff488_not4480 : ~ @Equation4480 Fin5 reff488_inst.
Proof. unfold Equation4480. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff488_inst, reff488_op in H. discriminate H. Qed.

Lemma reff488_not4482 : ~ @Equation4482 Fin5 reff488_inst.
Proof. unfold Equation4482. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff488_inst, reff488_op in H. discriminate H. Qed.

Lemma reff488_not4583 : ~ @Equation4583 Fin5 reff488_inst.
Proof. unfold Equation4583. intro H. specialize (H F5_0 F5_2). unfold magma_op, reff488_inst, reff488_op in H. discriminate H. Qed.

Lemma reff488_not4584 : ~ @Equation4584 Fin5 reff488_inst.
Proof. unfold Equation4584. intro H. specialize (H F5_0 F5_2). unfold magma_op, reff488_inst, reff488_op in H. discriminate H. Qed.

Lemma reff488_not4585 : ~ @Equation4585 Fin5 reff488_inst.
Proof. unfold Equation4585. intro H. specialize (H F5_0 F5_2). unfold magma_op, reff488_inst, reff488_op in H. discriminate H. Qed.

Lemma reff488_not4587 : ~ @Equation4587 Fin5 reff488_inst.
Proof. unfold Equation4587. intro H. specialize (H F5_0 F5_3). unfold magma_op, reff488_inst, reff488_op in H. discriminate H. Qed.

Lemma reff488_not4588 : ~ @Equation4588 Fin5 reff488_inst.
Proof. unfold Equation4588. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff488_inst, reff488_op in H. discriminate H. Qed.

Lemma reff488_not4590 : ~ @Equation4590 Fin5 reff488_inst.
Proof. unfold Equation4590. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff488_inst, reff488_op in H. discriminate H. Qed.

Lemma reff488_not4591 : ~ @Equation4591 Fin5 reff488_inst.
Proof. unfold Equation4591. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff488_inst, reff488_op in H. discriminate H. Qed.

Lemma reff488_not4598 : ~ @Equation4598 Fin5 reff488_inst.
Proof. unfold Equation4598. intro H. specialize (H F5_0 F5_2). unfold magma_op, reff488_inst, reff488_op in H. discriminate H. Qed.

Lemma reff488_not4599 : ~ @Equation4599 Fin5 reff488_inst.
Proof. unfold Equation4599. intro H. specialize (H F5_0 F5_4). unfold magma_op, reff488_inst, reff488_op in H. discriminate H. Qed.

Lemma reff488_not4605 : ~ @Equation4605 Fin5 reff488_inst.
Proof. unfold Equation4605. intro H. specialize (H F5_0 F5_2). unfold magma_op, reff488_inst, reff488_op in H. discriminate H. Qed.

Lemma reff488_not4606 : ~ @Equation4606 Fin5 reff488_inst.
Proof. unfold Equation4606. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff488_inst, reff488_op in H. discriminate H. Qed.

Lemma reff488_not4608 : ~ @Equation4608 Fin5 reff488_inst.
Proof. unfold Equation4608. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff488_inst, reff488_op in H. discriminate H. Qed.

Lemma reff488_not4629 : ~ @Equation4629 Fin5 reff488_inst.
Proof. unfold Equation4629. intro H. specialize (H F5_0 F5_2). unfold magma_op, reff488_inst, reff488_op in H. discriminate H. Qed.

Lemma reff488_not4635 : ~ @Equation4635 Fin5 reff488_inst.
Proof. unfold Equation4635. intro H. specialize (H F5_0 F5_2). unfold magma_op, reff488_inst, reff488_op in H. discriminate H. Qed.

Lemma reff488_not4636 : ~ @Equation4636 Fin5 reff488_inst.
Proof. unfold Equation4636. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff488_inst, reff488_op in H. discriminate H. Qed.

Lemma reff488_not4658 : ~ @Equation4658 Fin5 reff488_inst.
Proof. unfold Equation4658. intro H. specialize (H F5_0 F5_2). unfold magma_op, reff488_inst, reff488_op in H. discriminate H. Qed.
