(** * FinitePoly counterexamples — batch 7
    Auto-generated from Lean4 FinitePoly files. *)

From Stdlib Require Import Utf8.

From ETP Require Import Magma.
From ETP Require Import FinMagma.
From ETP.Equations Require Import All.

Open Scope magma_scope.

(** ---- reff328 (Fin4) ---- *)

Definition reff328_op (x y : Fin4) : Fin4 :=
  match x, y with
  | F4_0, F4_0 => F4_0 | F4_0, F4_1 => F4_2 | F4_0, F4_2 => F4_2 | F4_0, F4_3 => F4_0
  | F4_1, F4_0 => F4_0 | F4_1, F4_1 => F4_2 | F4_1, F4_2 => F4_2 | F4_1, F4_3 => F4_0
  | F4_2, F4_0 => F4_2 | F4_2, F4_1 => F4_0 | F4_2, F4_2 => F4_0 | F4_2, F4_3 => F4_2
  | F4_3, F4_0 => F4_2 | F4_3, F4_1 => F4_0 | F4_3, F4_2 => F4_0 | F4_3, F4_3 => F4_2
  end.

#[local] Instance reff328_inst : Magma Fin4 := {| magma_op := reff328_op |}.

Lemma reff328_sat3388 : @Equation3388 Fin4 reff328_inst.
Proof. unfold Equation3388, magma_op, reff328_inst, reff328_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff328_not411 : ~ @Equation411 Fin4 reff328_inst.
Proof. unfold Equation411. intro H. specialize (H F4_1). unfold magma_op, reff328_inst, reff328_op in H. discriminate H. Qed.

Lemma reff328_not1020 : ~ @Equation1020 Fin4 reff328_inst.
Proof. unfold Equation1020. intro H. specialize (H F4_1). unfold magma_op, reff328_inst, reff328_op in H. discriminate H. Qed.

Lemma reff328_not1223 : ~ @Equation1223 Fin4 reff328_inst.
Proof. unfold Equation1223. intro H. specialize (H F4_1). unfold magma_op, reff328_inst, reff328_op in H. discriminate H. Qed.

Lemma reff328_not1629 : ~ @Equation1629 Fin4 reff328_inst.
Proof. unfold Equation1629. intro H. specialize (H F4_1). unfold magma_op, reff328_inst, reff328_op in H. discriminate H. Qed.

Lemma reff328_not1832 : ~ @Equation1832 Fin4 reff328_inst.
Proof. unfold Equation1832. intro H. specialize (H F4_1). unfold magma_op, reff328_inst, reff328_op in H. discriminate H. Qed.

Lemma reff328_not2035 : ~ @Equation2035 Fin4 reff328_inst.
Proof. unfold Equation2035. intro H. specialize (H F4_1). unfold magma_op, reff328_inst, reff328_op in H. discriminate H. Qed.

Lemma reff328_not3862 : ~ @Equation3862 Fin4 reff328_inst.
Proof. unfold Equation3862. intro H. specialize (H F4_1). unfold magma_op, reff328_inst, reff328_op in H. discriminate H. Qed.

(** ---- reff330 (Fin3) ---- *)

Definition reff330_op (x y : Fin3) : Fin3 :=
  match x, y with
  | F3_0, F3_0 => F3_0 | F3_0, F3_1 => F3_2 | F3_0, F3_2 => F3_0
  | F3_1, F3_0 => F3_1 | F3_1, F3_1 => F3_1 | F3_1, F3_2 => F3_0
  | F3_2, F3_0 => F3_1 | F3_2, F3_1 => F3_2 | F3_2, F3_2 => F3_2
  end.

#[local] Instance reff330_inst : Magma Fin3 := {| magma_op := reff330_op |}.

Lemma reff330_sat9 : @Equation9 Fin3 reff330_inst.
Proof. unfold Equation9, magma_op, reff330_inst, reff330_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff330_sat102 : @Equation102 Fin3 reff330_inst.
Proof. unfold Equation102, magma_op, reff330_inst, reff330_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff330_sat378 : @Equation378 Fin3 reff330_inst.
Proof. unfold Equation378, magma_op, reff330_inst, reff330_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff330_sat429 : @Equation429 Fin3 reff330_inst.
Proof. unfold Equation429, magma_op, reff330_inst, reff330_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff330_sat825 : @Equation825 Fin3 reff330_inst.
Proof. unfold Equation825, magma_op, reff330_inst, reff330_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff330_sat829 : @Equation829 Fin3 reff330_inst.
Proof. unfold Equation829, magma_op, reff330_inst, reff330_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff330_sat1032 : @Equation1032 Fin3 reff330_inst.
Proof. unfold Equation1032, magma_op, reff330_inst, reff330_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff330_sat1039 : @Equation1039 Fin3 reff330_inst.
Proof. unfold Equation1039, magma_op, reff330_inst, reff330_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff330_sat1226 : @Equation1226 Fin3 reff330_inst.
Proof. unfold Equation1226, magma_op, reff330_inst, reff330_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff330_sat1232 : @Equation1232 Fin3 reff330_inst.
Proof. unfold Equation1232, magma_op, reff330_inst, reff330_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff330_sat1481 : @Equation1481 Fin3 reff330_inst.
Proof. unfold Equation1481, magma_op, reff330_inst, reff330_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff330_sat1632 : @Equation1632 Fin3 reff330_inst.
Proof. unfold Equation1632, magma_op, reff330_inst, reff330_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff330_sat2051 : @Equation2051 Fin3 reff330_inst.
Proof. unfold Equation2051, magma_op, reff330_inst, reff330_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff330_sat2098 : @Equation2098 Fin3 reff330_inst.
Proof. unfold Equation2098, magma_op, reff330_inst, reff330_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff330_sat2449 : @Equation2449 Fin3 reff330_inst.
Proof. unfold Equation2449, magma_op, reff330_inst, reff330_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff330_sat2852 : @Equation2852 Fin3 reff330_inst.
Proof. unfold Equation2852, magma_op, reff330_inst, reff330_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff330_sat3459 : @Equation3459 Fin3 reff330_inst.
Proof. unfold Equation3459, magma_op, reff330_inst, reff330_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff330_sat3511 : @Equation3511 Fin3 reff330_inst.
Proof. unfold Equation3511, magma_op, reff330_inst, reff330_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff330_sat3519 : @Equation3519 Fin3 reff330_inst.
Proof. unfold Equation3519, magma_op, reff330_inst, reff330_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff330_sat3725 : @Equation3725 Fin3 reff330_inst.
Proof. unfold Equation3725, magma_op, reff330_inst, reff330_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff330_sat3928 : @Equation3928 Fin3 reff330_inst.
Proof. unfold Equation3928, magma_op, reff330_inst, reff330_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff330_sat3955 : @Equation3955 Fin3 reff330_inst.
Proof. unfold Equation3955, magma_op, reff330_inst, reff330_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff330_sat4121 : @Equation4121 Fin3 reff330_inst.
Proof. unfold Equation4121, magma_op, reff330_inst, reff330_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff330_sat4473 : @Equation4473 Fin3 reff330_inst.
Proof. unfold Equation4473, magma_op, reff330_inst, reff330_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff330_sat4599 : @Equation4599 Fin3 reff330_inst.
Proof. unfold Equation4599, magma_op, reff330_inst, reff330_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff330_sat4636 : @Equation4636 Fin3 reff330_inst.
Proof. unfold Equation4636, magma_op, reff330_inst, reff330_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff330_not53 : ~ @Equation53 Fin3 reff330_inst.
Proof. unfold Equation53. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff330_inst, reff330_op in H. discriminate H. Qed.

Lemma reff330_not55 : ~ @Equation55 Fin3 reff330_inst.
Proof. unfold Equation55. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff330_inst, reff330_op in H. discriminate H. Qed.

Lemma reff330_not56 : ~ @Equation56 Fin3 reff330_inst.
Proof. unfold Equation56. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff330_inst, reff330_op in H. discriminate H. Qed.

Lemma reff330_not63 : ~ @Equation63 Fin3 reff330_inst.
Proof. unfold Equation63. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff330_inst, reff330_op in H. discriminate H. Qed.

Lemma reff330_not65 : ~ @Equation65 Fin3 reff330_inst.
Proof. unfold Equation65. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff330_inst, reff330_op in H. discriminate H. Qed.

Lemma reff330_not66 : ~ @Equation66 Fin3 reff330_inst.
Proof. unfold Equation66. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff330_inst, reff330_op in H. discriminate H. Qed.

Lemma reff330_not72 : ~ @Equation72 Fin3 reff330_inst.
Proof. unfold Equation72. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff330_inst, reff330_op in H. discriminate H. Qed.

Lemma reff330_not73 : ~ @Equation73 Fin3 reff330_inst.
Proof. unfold Equation73. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff330_inst, reff330_op in H. discriminate H. Qed.

Lemma reff330_not75 : ~ @Equation75 Fin3 reff330_inst.
Proof. unfold Equation75. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff330_inst, reff330_op in H. discriminate H. Qed.

Lemma reff330_not105 : ~ @Equation105 Fin3 reff330_inst.
Proof. unfold Equation105. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff330_inst, reff330_op in H. discriminate H. Qed.

Lemma reff330_not107 : ~ @Equation107 Fin3 reff330_inst.
Proof. unfold Equation107. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff330_inst, reff330_op in H. discriminate H. Qed.

Lemma reff330_not108 : ~ @Equation108 Fin3 reff330_inst.
Proof. unfold Equation108. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff330_inst, reff330_op in H. discriminate H. Qed.

Lemma reff330_not115 : ~ @Equation115 Fin3 reff330_inst.
Proof. unfold Equation115. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff330_inst, reff330_op in H. discriminate H. Qed.

Lemma reff330_not117 : ~ @Equation117 Fin3 reff330_inst.
Proof. unfold Equation117. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff330_inst, reff330_op in H. discriminate H. Qed.

Lemma reff330_not118 : ~ @Equation118 Fin3 reff330_inst.
Proof. unfold Equation118. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff330_inst, reff330_op in H. discriminate H. Qed.

Lemma reff330_not124 : ~ @Equation124 Fin3 reff330_inst.
Proof. unfold Equation124. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff330_inst, reff330_op in H. discriminate H. Qed.

Lemma reff330_not125 : ~ @Equation125 Fin3 reff330_inst.
Proof. unfold Equation125. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff330_inst, reff330_op in H. discriminate H. Qed.

Lemma reff330_not127 : ~ @Equation127 Fin3 reff330_inst.
Proof. unfold Equation127. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff330_inst, reff330_op in H. discriminate H. Qed.

Lemma reff330_not154 : ~ @Equation154 Fin3 reff330_inst.
Proof. unfold Equation154. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff330_inst, reff330_op in H. discriminate H. Qed.

Lemma reff330_not157 : ~ @Equation157 Fin3 reff330_inst.
Proof. unfold Equation157. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff330_inst, reff330_op in H. discriminate H. Qed.

Lemma reff330_not159 : ~ @Equation159 Fin3 reff330_inst.
Proof. unfold Equation159. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff330_inst, reff330_op in H. discriminate H. Qed.

Lemma reff330_not160 : ~ @Equation160 Fin3 reff330_inst.
Proof. unfold Equation160. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff330_inst, reff330_op in H. discriminate H. Qed.

Lemma reff330_not167 : ~ @Equation167 Fin3 reff330_inst.
Proof. unfold Equation167. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff330_inst, reff330_op in H. discriminate H. Qed.

Lemma reff330_not169 : ~ @Equation169 Fin3 reff330_inst.
Proof. unfold Equation169. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff330_inst, reff330_op in H. discriminate H. Qed.

Lemma reff330_not170 : ~ @Equation170 Fin3 reff330_inst.
Proof. unfold Equation170. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff330_inst, reff330_op in H. discriminate H. Qed.

Lemma reff330_not176 : ~ @Equation176 Fin3 reff330_inst.
Proof. unfold Equation176. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff330_inst, reff330_op in H. discriminate H. Qed.

Lemma reff330_not177 : ~ @Equation177 Fin3 reff330_inst.
Proof. unfold Equation177. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff330_inst, reff330_op in H. discriminate H. Qed.

Lemma reff330_not179 : ~ @Equation179 Fin3 reff330_inst.
Proof. unfold Equation179. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff330_inst, reff330_op in H. discriminate H. Qed.

Lemma reff330_not206 : ~ @Equation206 Fin3 reff330_inst.
Proof. unfold Equation206. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff330_inst, reff330_op in H. discriminate H. Qed.

Lemma reff330_not209 : ~ @Equation209 Fin3 reff330_inst.
Proof. unfold Equation209. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff330_inst, reff330_op in H. discriminate H. Qed.

Lemma reff330_not211 : ~ @Equation211 Fin3 reff330_inst.
Proof. unfold Equation211. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff330_inst, reff330_op in H. discriminate H. Qed.

Lemma reff330_not212 : ~ @Equation212 Fin3 reff330_inst.
Proof. unfold Equation212. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff330_inst, reff330_op in H. discriminate H. Qed.

Lemma reff330_not219 : ~ @Equation219 Fin3 reff330_inst.
Proof. unfold Equation219. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff330_inst, reff330_op in H. discriminate H. Qed.

Lemma reff330_not221 : ~ @Equation221 Fin3 reff330_inst.
Proof. unfold Equation221. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff330_inst, reff330_op in H. discriminate H. Qed.

Lemma reff330_not222 : ~ @Equation222 Fin3 reff330_inst.
Proof. unfold Equation222. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff330_inst, reff330_op in H. discriminate H. Qed.

Lemma reff330_not228 : ~ @Equation228 Fin3 reff330_inst.
Proof. unfold Equation228. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff330_inst, reff330_op in H. discriminate H. Qed.

Lemma reff330_not229 : ~ @Equation229 Fin3 reff330_inst.
Proof. unfold Equation229. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff330_inst, reff330_op in H. discriminate H. Qed.

Lemma reff330_not231 : ~ @Equation231 Fin3 reff330_inst.
Proof. unfold Equation231. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff330_inst, reff330_op in H. discriminate H. Qed.

Lemma reff330_not258 : ~ @Equation258 Fin3 reff330_inst.
Proof. unfold Equation258. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff330_inst, reff330_op in H. discriminate H. Qed.

Lemma reff330_not261 : ~ @Equation261 Fin3 reff330_inst.
Proof. unfold Equation261. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff330_inst, reff330_op in H. discriminate H. Qed.

Lemma reff330_not263 : ~ @Equation263 Fin3 reff330_inst.
Proof. unfold Equation263. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff330_inst, reff330_op in H. discriminate H. Qed.

Lemma reff330_not264 : ~ @Equation264 Fin3 reff330_inst.
Proof. unfold Equation264. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff330_inst, reff330_op in H. discriminate H. Qed.

Lemma reff330_not271 : ~ @Equation271 Fin3 reff330_inst.
Proof. unfold Equation271. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff330_inst, reff330_op in H. discriminate H. Qed.

Lemma reff330_not273 : ~ @Equation273 Fin3 reff330_inst.
Proof. unfold Equation273. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff330_inst, reff330_op in H. discriminate H. Qed.

Lemma reff330_not274 : ~ @Equation274 Fin3 reff330_inst.
Proof. unfold Equation274. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff330_inst, reff330_op in H. discriminate H. Qed.

Lemma reff330_not280 : ~ @Equation280 Fin3 reff330_inst.
Proof. unfold Equation280. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff330_inst, reff330_op in H. discriminate H. Qed.

Lemma reff330_not281 : ~ @Equation281 Fin3 reff330_inst.
Proof. unfold Equation281. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff330_inst, reff330_op in H. discriminate H. Qed.

Lemma reff330_not283 : ~ @Equation283 Fin3 reff330_inst.
Proof. unfold Equation283. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff330_inst, reff330_op in H. discriminate H. Qed.

Lemma reff330_not426 : ~ @Equation426 Fin3 reff330_inst.
Proof. unfold Equation426. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff330_inst, reff330_op in H. discriminate H. Qed.

Lemma reff330_not427 : ~ @Equation427 Fin3 reff330_inst.
Proof. unfold Equation427. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff330_inst, reff330_op in H. discriminate H. Qed.

Lemma reff330_not430 : ~ @Equation430 Fin3 reff330_inst.
Proof. unfold Equation430. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff330_inst, reff330_op in H. discriminate H. Qed.

Lemma reff330_not436 : ~ @Equation436 Fin3 reff330_inst.
Proof. unfold Equation436. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff330_inst, reff330_op in H. discriminate H. Qed.

Lemma reff330_not437 : ~ @Equation437 Fin3 reff330_inst.
Proof. unfold Equation437. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff330_inst, reff330_op in H. discriminate H. Qed.

Lemma reff330_not439 : ~ @Equation439 Fin3 reff330_inst.
Proof. unfold Equation439. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff330_inst, reff330_op in H. discriminate H. Qed.

Lemma reff330_not440 : ~ @Equation440 Fin3 reff330_inst.
Proof. unfold Equation440. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff330_inst, reff330_op in H. discriminate H. Qed.

Lemma reff330_not463 : ~ @Equation463 Fin3 reff330_inst.
Proof. unfold Equation463. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff330_inst, reff330_op in H. discriminate H. Qed.

Lemma reff330_not464 : ~ @Equation464 Fin3 reff330_inst.
Proof. unfold Equation464. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff330_inst, reff330_op in H. discriminate H. Qed.

Lemma reff330_not466 : ~ @Equation466 Fin3 reff330_inst.
Proof. unfold Equation466. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff330_inst, reff330_op in H. discriminate H. Qed.

Lemma reff330_not467 : ~ @Equation467 Fin3 reff330_inst.
Proof. unfold Equation467. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff330_inst, reff330_op in H. discriminate H. Qed.

Lemma reff330_not473 : ~ @Equation473 Fin3 reff330_inst.
Proof. unfold Equation473. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff330_inst, reff330_op in H. discriminate H. Qed.

Lemma reff330_not474 : ~ @Equation474 Fin3 reff330_inst.
Proof. unfold Equation474. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff330_inst, reff330_op in H. discriminate H. Qed.

Lemma reff330_not476 : ~ @Equation476 Fin3 reff330_inst.
Proof. unfold Equation476. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff330_inst, reff330_op in H. discriminate H. Qed.

Lemma reff330_not477 : ~ @Equation477 Fin3 reff330_inst.
Proof. unfold Equation477. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff330_inst, reff330_op in H. discriminate H. Qed.

Lemma reff330_not500 : ~ @Equation500 Fin3 reff330_inst.
Proof. unfold Equation500. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff330_inst, reff330_op in H. discriminate H. Qed.

Lemma reff330_not501 : ~ @Equation501 Fin3 reff330_inst.
Proof. unfold Equation501. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff330_inst, reff330_op in H. discriminate H. Qed.

Lemma reff330_not503 : ~ @Equation503 Fin3 reff330_inst.
Proof. unfold Equation503. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff330_inst, reff330_op in H. discriminate H. Qed.

Lemma reff330_not504 : ~ @Equation504 Fin3 reff330_inst.
Proof. unfold Equation504. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff330_inst, reff330_op in H. discriminate H. Qed.

Lemma reff330_not510 : ~ @Equation510 Fin3 reff330_inst.
Proof. unfold Equation510. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff330_inst, reff330_op in H. discriminate H. Qed.

Lemma reff330_not511 : ~ @Equation511 Fin3 reff330_inst.
Proof. unfold Equation511. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff330_inst, reff330_op in H. discriminate H. Qed.

Lemma reff330_not513 : ~ @Equation513 Fin3 reff330_inst.
Proof. unfold Equation513. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff330_inst, reff330_op in H. discriminate H. Qed.

Lemma reff330_not629 : ~ @Equation629 Fin3 reff330_inst.
Proof. unfold Equation629. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff330_inst, reff330_op in H. discriminate H. Qed.

Lemma reff330_not630 : ~ @Equation630 Fin3 reff330_inst.
Proof. unfold Equation630. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff330_inst, reff330_op in H. discriminate H. Qed.

Lemma reff330_not632 : ~ @Equation632 Fin3 reff330_inst.
Proof. unfold Equation632. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff330_inst, reff330_op in H. discriminate H. Qed.

Lemma reff330_not633 : ~ @Equation633 Fin3 reff330_inst.
Proof. unfold Equation633. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff330_inst, reff330_op in H. discriminate H. Qed.

Lemma reff330_not639 : ~ @Equation639 Fin3 reff330_inst.
Proof. unfold Equation639. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff330_inst, reff330_op in H. discriminate H. Qed.

Lemma reff330_not640 : ~ @Equation640 Fin3 reff330_inst.
Proof. unfold Equation640. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff330_inst, reff330_op in H. discriminate H. Qed.

Lemma reff330_not642 : ~ @Equation642 Fin3 reff330_inst.
Proof. unfold Equation642. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff330_inst, reff330_op in H. discriminate H. Qed.

Lemma reff330_not643 : ~ @Equation643 Fin3 reff330_inst.
Proof. unfold Equation643. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff330_inst, reff330_op in H. discriminate H. Qed.

Lemma reff330_not666 : ~ @Equation666 Fin3 reff330_inst.
Proof. unfold Equation666. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff330_inst, reff330_op in H. discriminate H. Qed.

Lemma reff330_not667 : ~ @Equation667 Fin3 reff330_inst.
Proof. unfold Equation667. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff330_inst, reff330_op in H. discriminate H. Qed.

Lemma reff330_not669 : ~ @Equation669 Fin3 reff330_inst.
Proof. unfold Equation669. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff330_inst, reff330_op in H. discriminate H. Qed.

Lemma reff330_not670 : ~ @Equation670 Fin3 reff330_inst.
Proof. unfold Equation670. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff330_inst, reff330_op in H. discriminate H. Qed.

Lemma reff330_not676 : ~ @Equation676 Fin3 reff330_inst.
Proof. unfold Equation676. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff330_inst, reff330_op in H. discriminate H. Qed.

Lemma reff330_not677 : ~ @Equation677 Fin3 reff330_inst.
Proof. unfold Equation677. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff330_inst, reff330_op in H. discriminate H. Qed.

Lemma reff330_not679 : ~ @Equation679 Fin3 reff330_inst.
Proof. unfold Equation679. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff330_inst, reff330_op in H. discriminate H. Qed.

Lemma reff330_not680 : ~ @Equation680 Fin3 reff330_inst.
Proof. unfold Equation680. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff330_inst, reff330_op in H. discriminate H. Qed.

Lemma reff330_not703 : ~ @Equation703 Fin3 reff330_inst.
Proof. unfold Equation703. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff330_inst, reff330_op in H. discriminate H. Qed.

Lemma reff330_not704 : ~ @Equation704 Fin3 reff330_inst.
Proof. unfold Equation704. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff330_inst, reff330_op in H. discriminate H. Qed.

Lemma reff330_not706 : ~ @Equation706 Fin3 reff330_inst.
Proof. unfold Equation706. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff330_inst, reff330_op in H. discriminate H. Qed.

Lemma reff330_not707 : ~ @Equation707 Fin3 reff330_inst.
Proof. unfold Equation707. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff330_inst, reff330_op in H. discriminate H. Qed.

Lemma reff330_not713 : ~ @Equation713 Fin3 reff330_inst.
Proof. unfold Equation713. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff330_inst, reff330_op in H. discriminate H. Qed.

Lemma reff330_not714 : ~ @Equation714 Fin3 reff330_inst.
Proof. unfold Equation714. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff330_inst, reff330_op in H. discriminate H. Qed.

Lemma reff330_not716 : ~ @Equation716 Fin3 reff330_inst.
Proof. unfold Equation716. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff330_inst, reff330_op in H. discriminate H. Qed.

Lemma reff330_not822 : ~ @Equation822 Fin3 reff330_inst.
Proof. unfold Equation822. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff330_inst, reff330_op in H. discriminate H. Qed.

Lemma reff330_not827 : ~ @Equation827 Fin3 reff330_inst.
Proof. unfold Equation827. intro H. specialize (H F3_0 F3_1 F3_2). unfold magma_op, reff330_inst, reff330_op in H. discriminate H. Qed.

Lemma reff330_not832 : ~ @Equation832 Fin3 reff330_inst.
Proof. unfold Equation832. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff330_inst, reff330_op in H. discriminate H. Qed.

Lemma reff330_not833 : ~ @Equation833 Fin3 reff330_inst.
Proof. unfold Equation833. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff330_inst, reff330_op in H. discriminate H. Qed.

Lemma reff330_not835 : ~ @Equation835 Fin3 reff330_inst.
Proof. unfold Equation835. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff330_inst, reff330_op in H. discriminate H. Qed.

Lemma reff330_not836 : ~ @Equation836 Fin3 reff330_inst.
Proof. unfold Equation836. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff330_inst, reff330_op in H. discriminate H. Qed.

Lemma reff330_not842 : ~ @Equation842 Fin3 reff330_inst.
Proof. unfold Equation842. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff330_inst, reff330_op in H. discriminate H. Qed.

Lemma reff330_not843 : ~ @Equation843 Fin3 reff330_inst.
Proof. unfold Equation843. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff330_inst, reff330_op in H. discriminate H. Qed.

Lemma reff330_not845 : ~ @Equation845 Fin3 reff330_inst.
Proof. unfold Equation845. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff330_inst, reff330_op in H. discriminate H. Qed.

Lemma reff330_not846 : ~ @Equation846 Fin3 reff330_inst.
Proof. unfold Equation846. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff330_inst, reff330_op in H. discriminate H. Qed.

Lemma reff330_not869 : ~ @Equation869 Fin3 reff330_inst.
Proof. unfold Equation869. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff330_inst, reff330_op in H. discriminate H. Qed.

Lemma reff330_not870 : ~ @Equation870 Fin3 reff330_inst.
Proof. unfold Equation870. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff330_inst, reff330_op in H. discriminate H. Qed.

Lemma reff330_not872 : ~ @Equation872 Fin3 reff330_inst.
Proof. unfold Equation872. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff330_inst, reff330_op in H. discriminate H. Qed.

Lemma reff330_not873 : ~ @Equation873 Fin3 reff330_inst.
Proof. unfold Equation873. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff330_inst, reff330_op in H. discriminate H. Qed.

Lemma reff330_not879 : ~ @Equation879 Fin3 reff330_inst.
Proof. unfold Equation879. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff330_inst, reff330_op in H. discriminate H. Qed.

Lemma reff330_not880 : ~ @Equation880 Fin3 reff330_inst.
Proof. unfold Equation880. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff330_inst, reff330_op in H. discriminate H. Qed.

Lemma reff330_not882 : ~ @Equation882 Fin3 reff330_inst.
Proof. unfold Equation882. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff330_inst, reff330_op in H. discriminate H. Qed.

Lemma reff330_not883 : ~ @Equation883 Fin3 reff330_inst.
Proof. unfold Equation883. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff330_inst, reff330_op in H. discriminate H. Qed.

Lemma reff330_not906 : ~ @Equation906 Fin3 reff330_inst.
Proof. unfold Equation906. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff330_inst, reff330_op in H. discriminate H. Qed.

Lemma reff330_not907 : ~ @Equation907 Fin3 reff330_inst.
Proof. unfold Equation907. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff330_inst, reff330_op in H. discriminate H. Qed.

Lemma reff330_not909 : ~ @Equation909 Fin3 reff330_inst.
Proof. unfold Equation909. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff330_inst, reff330_op in H. discriminate H. Qed.

Lemma reff330_not910 : ~ @Equation910 Fin3 reff330_inst.
Proof. unfold Equation910. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff330_inst, reff330_op in H. discriminate H. Qed.

Lemma reff330_not916 : ~ @Equation916 Fin3 reff330_inst.
Proof. unfold Equation916. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff330_inst, reff330_op in H. discriminate H. Qed.

Lemma reff330_not917 : ~ @Equation917 Fin3 reff330_inst.
Proof. unfold Equation917. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff330_inst, reff330_op in H. discriminate H. Qed.

Lemma reff330_not919 : ~ @Equation919 Fin3 reff330_inst.
Proof. unfold Equation919. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff330_inst, reff330_op in H. discriminate H. Qed.

Lemma reff330_not1025 : ~ @Equation1025 Fin3 reff330_inst.
Proof. unfold Equation1025. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff330_inst, reff330_op in H. discriminate H. Qed.

Lemma reff330_not1028 : ~ @Equation1028 Fin3 reff330_inst.
Proof. unfold Equation1028. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff330_inst, reff330_op in H. discriminate H. Qed.

Lemma reff330_not1035 : ~ @Equation1035 Fin3 reff330_inst.
Proof. unfold Equation1035. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff330_inst, reff330_op in H. discriminate H. Qed.

Lemma reff330_not1036 : ~ @Equation1036 Fin3 reff330_inst.
Proof. unfold Equation1036. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff330_inst, reff330_op in H. discriminate H. Qed.

Lemma reff330_not1038 : ~ @Equation1038 Fin3 reff330_inst.
Proof. unfold Equation1038. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff330_inst, reff330_op in H. discriminate H. Qed.

Lemma reff330_not1045 : ~ @Equation1045 Fin3 reff330_inst.
Proof. unfold Equation1045. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff330_inst, reff330_op in H. discriminate H. Qed.

Lemma reff330_not1046 : ~ @Equation1046 Fin3 reff330_inst.
Proof. unfold Equation1046. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff330_inst, reff330_op in H. discriminate H. Qed.

Lemma reff330_not1048 : ~ @Equation1048 Fin3 reff330_inst.
Proof. unfold Equation1048. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff330_inst, reff330_op in H. discriminate H. Qed.

Lemma reff330_not1049 : ~ @Equation1049 Fin3 reff330_inst.
Proof. unfold Equation1049. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff330_inst, reff330_op in H. discriminate H. Qed.

Lemma reff330_not1072 : ~ @Equation1072 Fin3 reff330_inst.
Proof. unfold Equation1072. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff330_inst, reff330_op in H. discriminate H. Qed.

Lemma reff330_not1073 : ~ @Equation1073 Fin3 reff330_inst.
Proof. unfold Equation1073. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff330_inst, reff330_op in H. discriminate H. Qed.

Lemma reff330_not1075 : ~ @Equation1075 Fin3 reff330_inst.
Proof. unfold Equation1075. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff330_inst, reff330_op in H. discriminate H. Qed.

Lemma reff330_not1076 : ~ @Equation1076 Fin3 reff330_inst.
Proof. unfold Equation1076. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff330_inst, reff330_op in H. discriminate H. Qed.

Lemma reff330_not1082 : ~ @Equation1082 Fin3 reff330_inst.
Proof. unfold Equation1082. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff330_inst, reff330_op in H. discriminate H. Qed.

Lemma reff330_not1083 : ~ @Equation1083 Fin3 reff330_inst.
Proof. unfold Equation1083. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff330_inst, reff330_op in H. discriminate H. Qed.

Lemma reff330_not1085 : ~ @Equation1085 Fin3 reff330_inst.
Proof. unfold Equation1085. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff330_inst, reff330_op in H. discriminate H. Qed.

Lemma reff330_not1086 : ~ @Equation1086 Fin3 reff330_inst.
Proof. unfold Equation1086. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff330_inst, reff330_op in H. discriminate H. Qed.

Lemma reff330_not1109 : ~ @Equation1109 Fin3 reff330_inst.
Proof. unfold Equation1109. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff330_inst, reff330_op in H. discriminate H. Qed.

Lemma reff330_not1110 : ~ @Equation1110 Fin3 reff330_inst.
Proof. unfold Equation1110. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff330_inst, reff330_op in H. discriminate H. Qed.

Lemma reff330_not1112 : ~ @Equation1112 Fin3 reff330_inst.
Proof. unfold Equation1112. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff330_inst, reff330_op in H. discriminate H. Qed.

Lemma reff330_not1113 : ~ @Equation1113 Fin3 reff330_inst.
Proof. unfold Equation1113. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff330_inst, reff330_op in H. discriminate H. Qed.

Lemma reff330_not1119 : ~ @Equation1119 Fin3 reff330_inst.
Proof. unfold Equation1119. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff330_inst, reff330_op in H. discriminate H. Qed.

Lemma reff330_not1120 : ~ @Equation1120 Fin3 reff330_inst.
Proof. unfold Equation1120. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff330_inst, reff330_op in H. discriminate H. Qed.

Lemma reff330_not1122 : ~ @Equation1122 Fin3 reff330_inst.
Proof. unfold Equation1122. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff330_inst, reff330_op in H. discriminate H. Qed.

Lemma reff330_not1225 : ~ @Equation1225 Fin3 reff330_inst.
Proof. unfold Equation1225. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff330_inst, reff330_op in H. discriminate H. Qed.

Lemma reff330_not1228 : ~ @Equation1228 Fin3 reff330_inst.
Proof. unfold Equation1228. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff330_inst, reff330_op in H. discriminate H. Qed.

Lemma reff330_not1229 : ~ @Equation1229 Fin3 reff330_inst.
Proof. unfold Equation1229. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff330_inst, reff330_op in H. discriminate H. Qed.

Lemma reff330_not1231 : ~ @Equation1231 Fin3 reff330_inst.
Proof. unfold Equation1231. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff330_inst, reff330_op in H. discriminate H. Qed.

Lemma reff330_not1238 : ~ @Equation1238 Fin3 reff330_inst.
Proof. unfold Equation1238. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff330_inst, reff330_op in H. discriminate H. Qed.

Lemma reff330_not1239 : ~ @Equation1239 Fin3 reff330_inst.
Proof. unfold Equation1239. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff330_inst, reff330_op in H. discriminate H. Qed.

Lemma reff330_not1241 : ~ @Equation1241 Fin3 reff330_inst.
Proof. unfold Equation1241. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff330_inst, reff330_op in H. discriminate H. Qed.

Lemma reff330_not1242 : ~ @Equation1242 Fin3 reff330_inst.
Proof. unfold Equation1242. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff330_inst, reff330_op in H. discriminate H. Qed.

Lemma reff330_not1248 : ~ @Equation1248 Fin3 reff330_inst.
Proof. unfold Equation1248. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff330_inst, reff330_op in H. discriminate H. Qed.

Lemma reff330_not1249 : ~ @Equation1249 Fin3 reff330_inst.
Proof. unfold Equation1249. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff330_inst, reff330_op in H. discriminate H. Qed.

Lemma reff330_not1251 : ~ @Equation1251 Fin3 reff330_inst.
Proof. unfold Equation1251. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff330_inst, reff330_op in H. discriminate H. Qed.

Lemma reff330_not1252 : ~ @Equation1252 Fin3 reff330_inst.
Proof. unfold Equation1252. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff330_inst, reff330_op in H. discriminate H. Qed.

Lemma reff330_not1275 : ~ @Equation1275 Fin3 reff330_inst.
Proof. unfold Equation1275. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff330_inst, reff330_op in H. discriminate H. Qed.

Lemma reff330_not1276 : ~ @Equation1276 Fin3 reff330_inst.
Proof. unfold Equation1276. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff330_inst, reff330_op in H. discriminate H. Qed.

Lemma reff330_not1278 : ~ @Equation1278 Fin3 reff330_inst.
Proof. unfold Equation1278. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff330_inst, reff330_op in H. discriminate H. Qed.

Lemma reff330_not1279 : ~ @Equation1279 Fin3 reff330_inst.
Proof. unfold Equation1279. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff330_inst, reff330_op in H. discriminate H. Qed.

Lemma reff330_not1285 : ~ @Equation1285 Fin3 reff330_inst.
Proof. unfold Equation1285. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff330_inst, reff330_op in H. discriminate H. Qed.

Lemma reff330_not1286 : ~ @Equation1286 Fin3 reff330_inst.
Proof. unfold Equation1286. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff330_inst, reff330_op in H. discriminate H. Qed.

Lemma reff330_not1288 : ~ @Equation1288 Fin3 reff330_inst.
Proof. unfold Equation1288. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff330_inst, reff330_op in H. discriminate H. Qed.

Lemma reff330_not1289 : ~ @Equation1289 Fin3 reff330_inst.
Proof. unfold Equation1289. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff330_inst, reff330_op in H. discriminate H. Qed.

Lemma reff330_not1312 : ~ @Equation1312 Fin3 reff330_inst.
Proof. unfold Equation1312. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff330_inst, reff330_op in H. discriminate H. Qed.

Lemma reff330_not1313 : ~ @Equation1313 Fin3 reff330_inst.
Proof. unfold Equation1313. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff330_inst, reff330_op in H. discriminate H. Qed.

Lemma reff330_not1315 : ~ @Equation1315 Fin3 reff330_inst.
Proof. unfold Equation1315. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff330_inst, reff330_op in H. discriminate H. Qed.

Lemma reff330_not1316 : ~ @Equation1316 Fin3 reff330_inst.
Proof. unfold Equation1316. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff330_inst, reff330_op in H. discriminate H. Qed.

Lemma reff330_not1322 : ~ @Equation1322 Fin3 reff330_inst.
Proof. unfold Equation1322. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff330_inst, reff330_op in H. discriminate H. Qed.

Lemma reff330_not1323 : ~ @Equation1323 Fin3 reff330_inst.
Proof. unfold Equation1323. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff330_inst, reff330_op in H. discriminate H. Qed.

Lemma reff330_not1325 : ~ @Equation1325 Fin3 reff330_inst.
Proof. unfold Equation1325. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff330_inst, reff330_op in H. discriminate H. Qed.

Lemma reff330_not1431 : ~ @Equation1431 Fin3 reff330_inst.
Proof. unfold Equation1431. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff330_inst, reff330_op in H. discriminate H. Qed.

Lemma reff330_not1432 : ~ @Equation1432 Fin3 reff330_inst.
Proof. unfold Equation1432. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff330_inst, reff330_op in H. discriminate H. Qed.

Lemma reff330_not1434 : ~ @Equation1434 Fin3 reff330_inst.
Proof. unfold Equation1434. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff330_inst, reff330_op in H. discriminate H. Qed.

Lemma reff330_not1435 : ~ @Equation1435 Fin3 reff330_inst.
Proof. unfold Equation1435. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff330_inst, reff330_op in H. discriminate H. Qed.

Lemma reff330_not1441 : ~ @Equation1441 Fin3 reff330_inst.
Proof. unfold Equation1441. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff330_inst, reff330_op in H. discriminate H. Qed.

Lemma reff330_not1442 : ~ @Equation1442 Fin3 reff330_inst.
Proof. unfold Equation1442. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff330_inst, reff330_op in H. discriminate H. Qed.

Lemma reff330_not1444 : ~ @Equation1444 Fin3 reff330_inst.
Proof. unfold Equation1444. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff330_inst, reff330_op in H. discriminate H. Qed.

Lemma reff330_not1445 : ~ @Equation1445 Fin3 reff330_inst.
Proof. unfold Equation1445. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff330_inst, reff330_op in H. discriminate H. Qed.

Lemma reff330_not1451 : ~ @Equation1451 Fin3 reff330_inst.
Proof. unfold Equation1451. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff330_inst, reff330_op in H. discriminate H. Qed.

Lemma reff330_not1452 : ~ @Equation1452 Fin3 reff330_inst.
Proof. unfold Equation1452. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff330_inst, reff330_op in H. discriminate H. Qed.

Lemma reff330_not1454 : ~ @Equation1454 Fin3 reff330_inst.
Proof. unfold Equation1454. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff330_inst, reff330_op in H. discriminate H. Qed.

Lemma reff330_not1455 : ~ @Equation1455 Fin3 reff330_inst.
Proof. unfold Equation1455. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff330_inst, reff330_op in H. discriminate H. Qed.

Lemma reff330_not1478 : ~ @Equation1478 Fin3 reff330_inst.
Proof. unfold Equation1478. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff330_inst, reff330_op in H. discriminate H. Qed.

Lemma reff330_not1479 : ~ @Equation1479 Fin3 reff330_inst.
Proof. unfold Equation1479. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff330_inst, reff330_op in H. discriminate H. Qed.

Lemma reff330_not1482 : ~ @Equation1482 Fin3 reff330_inst.
Proof. unfold Equation1482. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff330_inst, reff330_op in H. discriminate H. Qed.

Lemma reff330_not1488 : ~ @Equation1488 Fin3 reff330_inst.
Proof. unfold Equation1488. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff330_inst, reff330_op in H. discriminate H. Qed.

Lemma reff330_not1489 : ~ @Equation1489 Fin3 reff330_inst.
Proof. unfold Equation1489. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff330_inst, reff330_op in H. discriminate H. Qed.

Lemma reff330_not1491 : ~ @Equation1491 Fin3 reff330_inst.
Proof. unfold Equation1491. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff330_inst, reff330_op in H. discriminate H. Qed.

Lemma reff330_not1492 : ~ @Equation1492 Fin3 reff330_inst.
Proof. unfold Equation1492. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff330_inst, reff330_op in H. discriminate H. Qed.

Lemma reff330_not1515 : ~ @Equation1515 Fin3 reff330_inst.
Proof. unfold Equation1515. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff330_inst, reff330_op in H. discriminate H. Qed.

Lemma reff330_not1516 : ~ @Equation1516 Fin3 reff330_inst.
Proof. unfold Equation1516. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff330_inst, reff330_op in H. discriminate H. Qed.

Lemma reff330_not1518 : ~ @Equation1518 Fin3 reff330_inst.
Proof. unfold Equation1518. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff330_inst, reff330_op in H. discriminate H. Qed.

Lemma reff330_not1519 : ~ @Equation1519 Fin3 reff330_inst.
Proof. unfold Equation1519. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff330_inst, reff330_op in H. discriminate H. Qed.

Lemma reff330_not1525 : ~ @Equation1525 Fin3 reff330_inst.
Proof. unfold Equation1525. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff330_inst, reff330_op in H. discriminate H. Qed.

Lemma reff330_not1526 : ~ @Equation1526 Fin3 reff330_inst.
Proof. unfold Equation1526. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff330_inst, reff330_op in H. discriminate H. Qed.

Lemma reff330_not1528 : ~ @Equation1528 Fin3 reff330_inst.
Proof. unfold Equation1528. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff330_inst, reff330_op in H. discriminate H. Qed.

Lemma reff330_not1631 : ~ @Equation1631 Fin3 reff330_inst.
Proof. unfold Equation1631. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff330_inst, reff330_op in H. discriminate H. Qed.

Lemma reff330_not1634 : ~ @Equation1634 Fin3 reff330_inst.
Proof. unfold Equation1634. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff330_inst, reff330_op in H. discriminate H. Qed.

Lemma reff330_not1635 : ~ @Equation1635 Fin3 reff330_inst.
Proof. unfold Equation1635. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff330_inst, reff330_op in H. discriminate H. Qed.

Lemma reff330_not1637 : ~ @Equation1637 Fin3 reff330_inst.
Proof. unfold Equation1637. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff330_inst, reff330_op in H. discriminate H. Qed.

Lemma reff330_not1638 : ~ @Equation1638 Fin3 reff330_inst.
Proof. unfold Equation1638. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff330_inst, reff330_op in H. discriminate H. Qed.

Lemma reff330_not1644 : ~ @Equation1644 Fin3 reff330_inst.
Proof. unfold Equation1644. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff330_inst, reff330_op in H. discriminate H. Qed.

Lemma reff330_not1645 : ~ @Equation1645 Fin3 reff330_inst.
Proof. unfold Equation1645. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff330_inst, reff330_op in H. discriminate H. Qed.

Lemma reff330_not1647 : ~ @Equation1647 Fin3 reff330_inst.
Proof. unfold Equation1647. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff330_inst, reff330_op in H. discriminate H. Qed.

Lemma reff330_not1648 : ~ @Equation1648 Fin3 reff330_inst.
Proof. unfold Equation1648. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff330_inst, reff330_op in H. discriminate H. Qed.

Lemma reff330_not1654 : ~ @Equation1654 Fin3 reff330_inst.
Proof. unfold Equation1654. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff330_inst, reff330_op in H. discriminate H. Qed.

Lemma reff330_not1655 : ~ @Equation1655 Fin3 reff330_inst.
Proof. unfold Equation1655. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff330_inst, reff330_op in H. discriminate H. Qed.

Lemma reff330_not1657 : ~ @Equation1657 Fin3 reff330_inst.
Proof. unfold Equation1657. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff330_inst, reff330_op in H. discriminate H. Qed.

Lemma reff330_not1658 : ~ @Equation1658 Fin3 reff330_inst.
Proof. unfold Equation1658. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff330_inst, reff330_op in H. discriminate H. Qed.

Lemma reff330_not1681 : ~ @Equation1681 Fin3 reff330_inst.
Proof. unfold Equation1681. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff330_inst, reff330_op in H. discriminate H. Qed.

Lemma reff330_not1682 : ~ @Equation1682 Fin3 reff330_inst.
Proof. unfold Equation1682. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff330_inst, reff330_op in H. discriminate H. Qed.

Lemma reff330_not1684 : ~ @Equation1684 Fin3 reff330_inst.
Proof. unfold Equation1684. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff330_inst, reff330_op in H. discriminate H. Qed.

Lemma reff330_not1685 : ~ @Equation1685 Fin3 reff330_inst.
Proof. unfold Equation1685. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff330_inst, reff330_op in H. discriminate H. Qed.

Lemma reff330_not1691 : ~ @Equation1691 Fin3 reff330_inst.
Proof. unfold Equation1691. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff330_inst, reff330_op in H. discriminate H. Qed.

Lemma reff330_not1692 : ~ @Equation1692 Fin3 reff330_inst.
Proof. unfold Equation1692. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff330_inst, reff330_op in H. discriminate H. Qed.

Lemma reff330_not1694 : ~ @Equation1694 Fin3 reff330_inst.
Proof. unfold Equation1694. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff330_inst, reff330_op in H. discriminate H. Qed.

Lemma reff330_not1695 : ~ @Equation1695 Fin3 reff330_inst.
Proof. unfold Equation1695. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff330_inst, reff330_op in H. discriminate H. Qed.

Lemma reff330_not1718 : ~ @Equation1718 Fin3 reff330_inst.
Proof. unfold Equation1718. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff330_inst, reff330_op in H. discriminate H. Qed.

Lemma reff330_not1719 : ~ @Equation1719 Fin3 reff330_inst.
Proof. unfold Equation1719. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff330_inst, reff330_op in H. discriminate H. Qed.

Lemma reff330_not1721 : ~ @Equation1721 Fin3 reff330_inst.
Proof. unfold Equation1721. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff330_inst, reff330_op in H. discriminate H. Qed.

Lemma reff330_not1722 : ~ @Equation1722 Fin3 reff330_inst.
Proof. unfold Equation1722. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff330_inst, reff330_op in H. discriminate H. Qed.

Lemma reff330_not1728 : ~ @Equation1728 Fin3 reff330_inst.
Proof. unfold Equation1728. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff330_inst, reff330_op in H. discriminate H. Qed.

Lemma reff330_not1729 : ~ @Equation1729 Fin3 reff330_inst.
Proof. unfold Equation1729. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff330_inst, reff330_op in H. discriminate H. Qed.

Lemma reff330_not1731 : ~ @Equation1731 Fin3 reff330_inst.
Proof. unfold Equation1731. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff330_inst, reff330_op in H. discriminate H. Qed.

Lemma reff330_not1834 : ~ @Equation1834 Fin3 reff330_inst.
Proof. unfold Equation1834. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff330_inst, reff330_op in H. discriminate H. Qed.

Lemma reff330_not1835 : ~ @Equation1835 Fin3 reff330_inst.
Proof. unfold Equation1835. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff330_inst, reff330_op in H. discriminate H. Qed.

Lemma reff330_not1840 : ~ @Equation1840 Fin3 reff330_inst.
Proof. unfold Equation1840. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff330_inst, reff330_op in H. discriminate H. Qed.

Lemma reff330_not1841 : ~ @Equation1841 Fin3 reff330_inst.
Proof. unfold Equation1841. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff330_inst, reff330_op in H. discriminate H. Qed.

Lemma reff330_not1847 : ~ @Equation1847 Fin3 reff330_inst.
Proof. unfold Equation1847. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff330_inst, reff330_op in H. discriminate H. Qed.

Lemma reff330_not1848 : ~ @Equation1848 Fin3 reff330_inst.
Proof. unfold Equation1848. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff330_inst, reff330_op in H. discriminate H. Qed.

Lemma reff330_not1850 : ~ @Equation1850 Fin3 reff330_inst.
Proof. unfold Equation1850. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff330_inst, reff330_op in H. discriminate H. Qed.

Lemma reff330_not1851 : ~ @Equation1851 Fin3 reff330_inst.
Proof. unfold Equation1851. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff330_inst, reff330_op in H. discriminate H. Qed.

Lemma reff330_not1857 : ~ @Equation1857 Fin3 reff330_inst.
Proof. unfold Equation1857. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff330_inst, reff330_op in H. discriminate H. Qed.

Lemma reff330_not1858 : ~ @Equation1858 Fin3 reff330_inst.
Proof. unfold Equation1858. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff330_inst, reff330_op in H. discriminate H. Qed.

Lemma reff330_not1860 : ~ @Equation1860 Fin3 reff330_inst.
Proof. unfold Equation1860. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff330_inst, reff330_op in H. discriminate H. Qed.

Lemma reff330_not1861 : ~ @Equation1861 Fin3 reff330_inst.
Proof. unfold Equation1861. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff330_inst, reff330_op in H. discriminate H. Qed.

Lemma reff330_not1884 : ~ @Equation1884 Fin3 reff330_inst.
Proof. unfold Equation1884. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff330_inst, reff330_op in H. discriminate H. Qed.

Lemma reff330_not1885 : ~ @Equation1885 Fin3 reff330_inst.
Proof. unfold Equation1885. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff330_inst, reff330_op in H. discriminate H. Qed.

Lemma reff330_not1887 : ~ @Equation1887 Fin3 reff330_inst.
Proof. unfold Equation1887. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff330_inst, reff330_op in H. discriminate H. Qed.

Lemma reff330_not1888 : ~ @Equation1888 Fin3 reff330_inst.
Proof. unfold Equation1888. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff330_inst, reff330_op in H. discriminate H. Qed.

Lemma reff330_not1894 : ~ @Equation1894 Fin3 reff330_inst.
Proof. unfold Equation1894. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff330_inst, reff330_op in H. discriminate H. Qed.

Lemma reff330_not1895 : ~ @Equation1895 Fin3 reff330_inst.
Proof. unfold Equation1895. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff330_inst, reff330_op in H. discriminate H. Qed.

Lemma reff330_not1897 : ~ @Equation1897 Fin3 reff330_inst.
Proof. unfold Equation1897. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff330_inst, reff330_op in H. discriminate H. Qed.

Lemma reff330_not1898 : ~ @Equation1898 Fin3 reff330_inst.
Proof. unfold Equation1898. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff330_inst, reff330_op in H. discriminate H. Qed.

Lemma reff330_not1921 : ~ @Equation1921 Fin3 reff330_inst.
Proof. unfold Equation1921. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff330_inst, reff330_op in H. discriminate H. Qed.

Lemma reff330_not1922 : ~ @Equation1922 Fin3 reff330_inst.
Proof. unfold Equation1922. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff330_inst, reff330_op in H. discriminate H. Qed.

Lemma reff330_not1924 : ~ @Equation1924 Fin3 reff330_inst.
Proof. unfold Equation1924. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff330_inst, reff330_op in H. discriminate H. Qed.

Lemma reff330_not1925 : ~ @Equation1925 Fin3 reff330_inst.
Proof. unfold Equation1925. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff330_inst, reff330_op in H. discriminate H. Qed.

Lemma reff330_not1931 : ~ @Equation1931 Fin3 reff330_inst.
Proof. unfold Equation1931. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff330_inst, reff330_op in H. discriminate H. Qed.

Lemma reff330_not1932 : ~ @Equation1932 Fin3 reff330_inst.
Proof. unfold Equation1932. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff330_inst, reff330_op in H. discriminate H. Qed.

Lemma reff330_not1934 : ~ @Equation1934 Fin3 reff330_inst.
Proof. unfold Equation1934. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff330_inst, reff330_op in H. discriminate H. Qed.

Lemma reff330_not2037 : ~ @Equation2037 Fin3 reff330_inst.
Proof. unfold Equation2037. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff330_inst, reff330_op in H. discriminate H. Qed.

Lemma reff330_not2038 : ~ @Equation2038 Fin3 reff330_inst.
Proof. unfold Equation2038. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff330_inst, reff330_op in H. discriminate H. Qed.

Lemma reff330_not2040 : ~ @Equation2040 Fin3 reff330_inst.
Proof. unfold Equation2040. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff330_inst, reff330_op in H. discriminate H. Qed.

Lemma reff330_not2041 : ~ @Equation2041 Fin3 reff330_inst.
Proof. unfold Equation2041. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff330_inst, reff330_op in H. discriminate H. Qed.

Lemma reff330_not2043 : ~ @Equation2043 Fin3 reff330_inst.
Proof. unfold Equation2043. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff330_inst, reff330_op in H. discriminate H. Qed.

Lemma reff330_not2044 : ~ @Equation2044 Fin3 reff330_inst.
Proof. unfold Equation2044. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff330_inst, reff330_op in H. discriminate H. Qed.

Lemma reff330_not2050 : ~ @Equation2050 Fin3 reff330_inst.
Proof. unfold Equation2050. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff330_inst, reff330_op in H. discriminate H. Qed.

Lemma reff330_not2053 : ~ @Equation2053 Fin3 reff330_inst.
Proof. unfold Equation2053. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff330_inst, reff330_op in H. discriminate H. Qed.

Lemma reff330_not2054 : ~ @Equation2054 Fin3 reff330_inst.
Proof. unfold Equation2054. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff330_inst, reff330_op in H. discriminate H. Qed.

Lemma reff330_not2060 : ~ @Equation2060 Fin3 reff330_inst.
Proof. unfold Equation2060. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff330_inst, reff330_op in H. discriminate H. Qed.

Lemma reff330_not2061 : ~ @Equation2061 Fin3 reff330_inst.
Proof. unfold Equation2061. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff330_inst, reff330_op in H. discriminate H. Qed.

Lemma reff330_not2063 : ~ @Equation2063 Fin3 reff330_inst.
Proof. unfold Equation2063. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff330_inst, reff330_op in H. discriminate H. Qed.

Lemma reff330_not2064 : ~ @Equation2064 Fin3 reff330_inst.
Proof. unfold Equation2064. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff330_inst, reff330_op in H. discriminate H. Qed.

Lemma reff330_not2087 : ~ @Equation2087 Fin3 reff330_inst.
Proof. unfold Equation2087. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff330_inst, reff330_op in H. discriminate H. Qed.

Lemma reff330_not2088 : ~ @Equation2088 Fin3 reff330_inst.
Proof. unfold Equation2088. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff330_inst, reff330_op in H. discriminate H. Qed.

Lemma reff330_not2090 : ~ @Equation2090 Fin3 reff330_inst.
Proof. unfold Equation2090. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff330_inst, reff330_op in H. discriminate H. Qed.

Lemma reff330_not2091 : ~ @Equation2091 Fin3 reff330_inst.
Proof. unfold Equation2091. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff330_inst, reff330_op in H. discriminate H. Qed.

Lemma reff330_not2097 : ~ @Equation2097 Fin3 reff330_inst.
Proof. unfold Equation2097. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff330_inst, reff330_op in H. discriminate H. Qed.

Lemma reff330_not2100 : ~ @Equation2100 Fin3 reff330_inst.
Proof. unfold Equation2100. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff330_inst, reff330_op in H. discriminate H. Qed.

Lemma reff330_not2101 : ~ @Equation2101 Fin3 reff330_inst.
Proof. unfold Equation2101. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff330_inst, reff330_op in H. discriminate H. Qed.

Lemma reff330_not2124 : ~ @Equation2124 Fin3 reff330_inst.
Proof. unfold Equation2124. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff330_inst, reff330_op in H. discriminate H. Qed.

Lemma reff330_not2125 : ~ @Equation2125 Fin3 reff330_inst.
Proof. unfold Equation2125. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff330_inst, reff330_op in H. discriminate H. Qed.

Lemma reff330_not2127 : ~ @Equation2127 Fin3 reff330_inst.
Proof. unfold Equation2127. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff330_inst, reff330_op in H. discriminate H. Qed.

Lemma reff330_not2128 : ~ @Equation2128 Fin3 reff330_inst.
Proof. unfold Equation2128. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff330_inst, reff330_op in H. discriminate H. Qed.

Lemma reff330_not2134 : ~ @Equation2134 Fin3 reff330_inst.
Proof. unfold Equation2134. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff330_inst, reff330_op in H. discriminate H. Qed.

Lemma reff330_not2135 : ~ @Equation2135 Fin3 reff330_inst.
Proof. unfold Equation2135. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff330_inst, reff330_op in H. discriminate H. Qed.

Lemma reff330_not2137 : ~ @Equation2137 Fin3 reff330_inst.
Proof. unfold Equation2137. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff330_inst, reff330_op in H. discriminate H. Qed.

Lemma reff330_not2239 : ~ @Equation2239 Fin3 reff330_inst.
Proof. unfold Equation2239. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff330_inst, reff330_op in H. discriminate H. Qed.

Lemma reff330_not2241 : ~ @Equation2241 Fin3 reff330_inst.
Proof. unfold Equation2241. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff330_inst, reff330_op in H. discriminate H. Qed.

Lemma reff330_not2244 : ~ @Equation2244 Fin3 reff330_inst.
Proof. unfold Equation2244. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff330_inst, reff330_op in H. discriminate H. Qed.

Lemma reff330_not2247 : ~ @Equation2247 Fin3 reff330_inst.
Proof. unfold Equation2247. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff330_inst, reff330_op in H. discriminate H. Qed.

Lemma reff330_not2253 : ~ @Equation2253 Fin3 reff330_inst.
Proof. unfold Equation2253. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff330_inst, reff330_op in H. discriminate H. Qed.

Lemma reff330_not2254 : ~ @Equation2254 Fin3 reff330_inst.
Proof. unfold Equation2254. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff330_inst, reff330_op in H. discriminate H. Qed.

Lemma reff330_not2256 : ~ @Equation2256 Fin3 reff330_inst.
Proof. unfold Equation2256. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff330_inst, reff330_op in H. discriminate H. Qed.

Lemma reff330_not2257 : ~ @Equation2257 Fin3 reff330_inst.
Proof. unfold Equation2257. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff330_inst, reff330_op in H. discriminate H. Qed.

Lemma reff330_not2263 : ~ @Equation2263 Fin3 reff330_inst.
Proof. unfold Equation2263. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff330_inst, reff330_op in H. discriminate H. Qed.

Lemma reff330_not2264 : ~ @Equation2264 Fin3 reff330_inst.
Proof. unfold Equation2264. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff330_inst, reff330_op in H. discriminate H. Qed.

Lemma reff330_not2266 : ~ @Equation2266 Fin3 reff330_inst.
Proof. unfold Equation2266. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff330_inst, reff330_op in H. discriminate H. Qed.

Lemma reff330_not2267 : ~ @Equation2267 Fin3 reff330_inst.
Proof. unfold Equation2267. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff330_inst, reff330_op in H. discriminate H. Qed.

Lemma reff330_not2290 : ~ @Equation2290 Fin3 reff330_inst.
Proof. unfold Equation2290. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff330_inst, reff330_op in H. discriminate H. Qed.

Lemma reff330_not2291 : ~ @Equation2291 Fin3 reff330_inst.
Proof. unfold Equation2291. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff330_inst, reff330_op in H. discriminate H. Qed.

Lemma reff330_not2293 : ~ @Equation2293 Fin3 reff330_inst.
Proof. unfold Equation2293. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff330_inst, reff330_op in H. discriminate H. Qed.

Lemma reff330_not2294 : ~ @Equation2294 Fin3 reff330_inst.
Proof. unfold Equation2294. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff330_inst, reff330_op in H. discriminate H. Qed.

Lemma reff330_not2300 : ~ @Equation2300 Fin3 reff330_inst.
Proof. unfold Equation2300. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff330_inst, reff330_op in H. discriminate H. Qed.

Lemma reff330_not2301 : ~ @Equation2301 Fin3 reff330_inst.
Proof. unfold Equation2301. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff330_inst, reff330_op in H. discriminate H. Qed.

Lemma reff330_not2303 : ~ @Equation2303 Fin3 reff330_inst.
Proof. unfold Equation2303. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff330_inst, reff330_op in H. discriminate H. Qed.

Lemma reff330_not2304 : ~ @Equation2304 Fin3 reff330_inst.
Proof. unfold Equation2304. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff330_inst, reff330_op in H. discriminate H. Qed.

Lemma reff330_not2327 : ~ @Equation2327 Fin3 reff330_inst.
Proof. unfold Equation2327. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff330_inst, reff330_op in H. discriminate H. Qed.

Lemma reff330_not2328 : ~ @Equation2328 Fin3 reff330_inst.
Proof. unfold Equation2328. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff330_inst, reff330_op in H. discriminate H. Qed.

Lemma reff330_not2330 : ~ @Equation2330 Fin3 reff330_inst.
Proof. unfold Equation2330. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff330_inst, reff330_op in H. discriminate H. Qed.

Lemma reff330_not2331 : ~ @Equation2331 Fin3 reff330_inst.
Proof. unfold Equation2331. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff330_inst, reff330_op in H. discriminate H. Qed.

Lemma reff330_not2337 : ~ @Equation2337 Fin3 reff330_inst.
Proof. unfold Equation2337. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff330_inst, reff330_op in H. discriminate H. Qed.

Lemma reff330_not2338 : ~ @Equation2338 Fin3 reff330_inst.
Proof. unfold Equation2338. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff330_inst, reff330_op in H. discriminate H. Qed.

Lemma reff330_not2340 : ~ @Equation2340 Fin3 reff330_inst.
Proof. unfold Equation2340. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff330_inst, reff330_op in H. discriminate H. Qed.

Lemma reff330_not2442 : ~ @Equation2442 Fin3 reff330_inst.
Proof. unfold Equation2442. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff330_inst, reff330_op in H. discriminate H. Qed.

Lemma reff330_not2444 : ~ @Equation2444 Fin3 reff330_inst.
Proof. unfold Equation2444. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff330_inst, reff330_op in H. discriminate H. Qed.

Lemma reff330_not2446 : ~ @Equation2446 Fin3 reff330_inst.
Proof. unfold Equation2446. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff330_inst, reff330_op in H. discriminate H. Qed.

Lemma reff330_not2447 : ~ @Equation2447 Fin3 reff330_inst.
Proof. unfold Equation2447. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff330_inst, reff330_op in H. discriminate H. Qed.

Lemma reff330_not2450 : ~ @Equation2450 Fin3 reff330_inst.
Proof. unfold Equation2450. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff330_inst, reff330_op in H. discriminate H. Qed.

Lemma reff330_not2456 : ~ @Equation2456 Fin3 reff330_inst.
Proof. unfold Equation2456. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff330_inst, reff330_op in H. discriminate H. Qed.

Lemma reff330_not2457 : ~ @Equation2457 Fin3 reff330_inst.
Proof. unfold Equation2457. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff330_inst, reff330_op in H. discriminate H. Qed.

Lemma reff330_not2459 : ~ @Equation2459 Fin3 reff330_inst.
Proof. unfold Equation2459. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff330_inst, reff330_op in H. discriminate H. Qed.

Lemma reff330_not2460 : ~ @Equation2460 Fin3 reff330_inst.
Proof. unfold Equation2460. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff330_inst, reff330_op in H. discriminate H. Qed.

Lemma reff330_not2466 : ~ @Equation2466 Fin3 reff330_inst.
Proof. unfold Equation2466. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff330_inst, reff330_op in H. discriminate H. Qed.

Lemma reff330_not2467 : ~ @Equation2467 Fin3 reff330_inst.
Proof. unfold Equation2467. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff330_inst, reff330_op in H. discriminate H. Qed.

Lemma reff330_not2469 : ~ @Equation2469 Fin3 reff330_inst.
Proof. unfold Equation2469. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff330_inst, reff330_op in H. discriminate H. Qed.

Lemma reff330_not2470 : ~ @Equation2470 Fin3 reff330_inst.
Proof. unfold Equation2470. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff330_inst, reff330_op in H. discriminate H. Qed.

Lemma reff330_not2493 : ~ @Equation2493 Fin3 reff330_inst.
Proof. unfold Equation2493. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff330_inst, reff330_op in H. discriminate H. Qed.

Lemma reff330_not2494 : ~ @Equation2494 Fin3 reff330_inst.
Proof. unfold Equation2494. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff330_inst, reff330_op in H. discriminate H. Qed.

Lemma reff330_not2496 : ~ @Equation2496 Fin3 reff330_inst.
Proof. unfold Equation2496. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff330_inst, reff330_op in H. discriminate H. Qed.

Lemma reff330_not2497 : ~ @Equation2497 Fin3 reff330_inst.
Proof. unfold Equation2497. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff330_inst, reff330_op in H. discriminate H. Qed.

Lemma reff330_not2503 : ~ @Equation2503 Fin3 reff330_inst.
Proof. unfold Equation2503. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff330_inst, reff330_op in H. discriminate H. Qed.

Lemma reff330_not2504 : ~ @Equation2504 Fin3 reff330_inst.
Proof. unfold Equation2504. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff330_inst, reff330_op in H. discriminate H. Qed.

Lemma reff330_not2506 : ~ @Equation2506 Fin3 reff330_inst.
Proof. unfold Equation2506. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff330_inst, reff330_op in H. discriminate H. Qed.

Lemma reff330_not2507 : ~ @Equation2507 Fin3 reff330_inst.
Proof. unfold Equation2507. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff330_inst, reff330_op in H. discriminate H. Qed.

Lemma reff330_not2530 : ~ @Equation2530 Fin3 reff330_inst.
Proof. unfold Equation2530. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff330_inst, reff330_op in H. discriminate H. Qed.

Lemma reff330_not2531 : ~ @Equation2531 Fin3 reff330_inst.
Proof. unfold Equation2531. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff330_inst, reff330_op in H. discriminate H. Qed.

Lemma reff330_not2533 : ~ @Equation2533 Fin3 reff330_inst.
Proof. unfold Equation2533. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff330_inst, reff330_op in H. discriminate H. Qed.

Lemma reff330_not2534 : ~ @Equation2534 Fin3 reff330_inst.
Proof. unfold Equation2534. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff330_inst, reff330_op in H. discriminate H. Qed.

Lemma reff330_not2540 : ~ @Equation2540 Fin3 reff330_inst.
Proof. unfold Equation2540. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff330_inst, reff330_op in H. discriminate H. Qed.

Lemma reff330_not2541 : ~ @Equation2541 Fin3 reff330_inst.
Proof. unfold Equation2541. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff330_inst, reff330_op in H. discriminate H. Qed.

Lemma reff330_not2543 : ~ @Equation2543 Fin3 reff330_inst.
Proof. unfold Equation2543. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff330_inst, reff330_op in H. discriminate H. Qed.

Lemma reff330_not2645 : ~ @Equation2645 Fin3 reff330_inst.
Proof. unfold Equation2645. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff330_inst, reff330_op in H. discriminate H. Qed.

Lemma reff330_not2647 : ~ @Equation2647 Fin3 reff330_inst.
Proof. unfold Equation2647. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff330_inst, reff330_op in H. discriminate H. Qed.

Lemma reff330_not2649 : ~ @Equation2649 Fin3 reff330_inst.
Proof. unfold Equation2649. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff330_inst, reff330_op in H. discriminate H. Qed.

Lemma reff330_not2650 : ~ @Equation2650 Fin3 reff330_inst.
Proof. unfold Equation2650. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff330_inst, reff330_op in H. discriminate H. Qed.

Lemma reff330_not2652 : ~ @Equation2652 Fin3 reff330_inst.
Proof. unfold Equation2652. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff330_inst, reff330_op in H. discriminate H. Qed.

Lemma reff330_not2653 : ~ @Equation2653 Fin3 reff330_inst.
Proof. unfold Equation2653. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff330_inst, reff330_op in H. discriminate H. Qed.

Lemma reff330_not2659 : ~ @Equation2659 Fin3 reff330_inst.
Proof. unfold Equation2659. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff330_inst, reff330_op in H. discriminate H. Qed.

Lemma reff330_not2660 : ~ @Equation2660 Fin3 reff330_inst.
Proof. unfold Equation2660. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff330_inst, reff330_op in H. discriminate H. Qed.

Lemma reff330_not2662 : ~ @Equation2662 Fin3 reff330_inst.
Proof. unfold Equation2662. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff330_inst, reff330_op in H. discriminate H. Qed.

Lemma reff330_not2663 : ~ @Equation2663 Fin3 reff330_inst.
Proof. unfold Equation2663. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff330_inst, reff330_op in H. discriminate H. Qed.

Lemma reff330_not2669 : ~ @Equation2669 Fin3 reff330_inst.
Proof. unfold Equation2669. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff330_inst, reff330_op in H. discriminate H. Qed.

Lemma reff330_not2670 : ~ @Equation2670 Fin3 reff330_inst.
Proof. unfold Equation2670. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff330_inst, reff330_op in H. discriminate H. Qed.

Lemma reff330_not2672 : ~ @Equation2672 Fin3 reff330_inst.
Proof. unfold Equation2672. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff330_inst, reff330_op in H. discriminate H. Qed.

Lemma reff330_not2673 : ~ @Equation2673 Fin3 reff330_inst.
Proof. unfold Equation2673. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff330_inst, reff330_op in H. discriminate H. Qed.

Lemma reff330_not2696 : ~ @Equation2696 Fin3 reff330_inst.
Proof. unfold Equation2696. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff330_inst, reff330_op in H. discriminate H. Qed.

Lemma reff330_not2697 : ~ @Equation2697 Fin3 reff330_inst.
Proof. unfold Equation2697. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff330_inst, reff330_op in H. discriminate H. Qed.

Lemma reff330_not2699 : ~ @Equation2699 Fin3 reff330_inst.
Proof. unfold Equation2699. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff330_inst, reff330_op in H. discriminate H. Qed.

Lemma reff330_not2700 : ~ @Equation2700 Fin3 reff330_inst.
Proof. unfold Equation2700. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff330_inst, reff330_op in H. discriminate H. Qed.

Lemma reff330_not2706 : ~ @Equation2706 Fin3 reff330_inst.
Proof. unfold Equation2706. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff330_inst, reff330_op in H. discriminate H. Qed.

Lemma reff330_not2707 : ~ @Equation2707 Fin3 reff330_inst.
Proof. unfold Equation2707. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff330_inst, reff330_op in H. discriminate H. Qed.

Lemma reff330_not2709 : ~ @Equation2709 Fin3 reff330_inst.
Proof. unfold Equation2709. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff330_inst, reff330_op in H. discriminate H. Qed.

Lemma reff330_not2710 : ~ @Equation2710 Fin3 reff330_inst.
Proof. unfold Equation2710. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff330_inst, reff330_op in H. discriminate H. Qed.

Lemma reff330_not2733 : ~ @Equation2733 Fin3 reff330_inst.
Proof. unfold Equation2733. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff330_inst, reff330_op in H. discriminate H. Qed.

Lemma reff330_not2734 : ~ @Equation2734 Fin3 reff330_inst.
Proof. unfold Equation2734. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff330_inst, reff330_op in H. discriminate H. Qed.

Lemma reff330_not2736 : ~ @Equation2736 Fin3 reff330_inst.
Proof. unfold Equation2736. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff330_inst, reff330_op in H. discriminate H. Qed.

Lemma reff330_not2737 : ~ @Equation2737 Fin3 reff330_inst.
Proof. unfold Equation2737. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff330_inst, reff330_op in H. discriminate H. Qed.

Lemma reff330_not2743 : ~ @Equation2743 Fin3 reff330_inst.
Proof. unfold Equation2743. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff330_inst, reff330_op in H. discriminate H. Qed.

Lemma reff330_not2744 : ~ @Equation2744 Fin3 reff330_inst.
Proof. unfold Equation2744. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff330_inst, reff330_op in H. discriminate H. Qed.

Lemma reff330_not2746 : ~ @Equation2746 Fin3 reff330_inst.
Proof. unfold Equation2746. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff330_inst, reff330_op in H. discriminate H. Qed.

Lemma reff330_not2848 : ~ @Equation2848 Fin3 reff330_inst.
Proof. unfold Equation2848. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff330_inst, reff330_op in H. discriminate H. Qed.

Lemma reff330_not2849 : ~ @Equation2849 Fin3 reff330_inst.
Proof. unfold Equation2849. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff330_inst, reff330_op in H. discriminate H. Qed.

Lemma reff330_not2850 : ~ @Equation2850 Fin3 reff330_inst.
Proof. unfold Equation2850. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff330_inst, reff330_op in H. discriminate H. Qed.

Lemma reff330_not2853 : ~ @Equation2853 Fin3 reff330_inst.
Proof. unfold Equation2853. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff330_inst, reff330_op in H. discriminate H. Qed.

Lemma reff330_not2855 : ~ @Equation2855 Fin3 reff330_inst.
Proof. unfold Equation2855. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff330_inst, reff330_op in H. discriminate H. Qed.

Lemma reff330_not2856 : ~ @Equation2856 Fin3 reff330_inst.
Proof. unfold Equation2856. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff330_inst, reff330_op in H. discriminate H. Qed.

Lemma reff330_not2862 : ~ @Equation2862 Fin3 reff330_inst.
Proof. unfold Equation2862. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff330_inst, reff330_op in H. discriminate H. Qed.

Lemma reff330_not2863 : ~ @Equation2863 Fin3 reff330_inst.
Proof. unfold Equation2863. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff330_inst, reff330_op in H. discriminate H. Qed.

Lemma reff330_not2865 : ~ @Equation2865 Fin3 reff330_inst.
Proof. unfold Equation2865. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff330_inst, reff330_op in H. discriminate H. Qed.

Lemma reff330_not2866 : ~ @Equation2866 Fin3 reff330_inst.
Proof. unfold Equation2866. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff330_inst, reff330_op in H. discriminate H. Qed.

Lemma reff330_not2872 : ~ @Equation2872 Fin3 reff330_inst.
Proof. unfold Equation2872. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff330_inst, reff330_op in H. discriminate H. Qed.

Lemma reff330_not2873 : ~ @Equation2873 Fin3 reff330_inst.
Proof. unfold Equation2873. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff330_inst, reff330_op in H. discriminate H. Qed.

Lemma reff330_not2875 : ~ @Equation2875 Fin3 reff330_inst.
Proof. unfold Equation2875. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff330_inst, reff330_op in H. discriminate H. Qed.

Lemma reff330_not2876 : ~ @Equation2876 Fin3 reff330_inst.
Proof. unfold Equation2876. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff330_inst, reff330_op in H. discriminate H. Qed.

Lemma reff330_not2899 : ~ @Equation2899 Fin3 reff330_inst.
Proof. unfold Equation2899. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff330_inst, reff330_op in H. discriminate H. Qed.

Lemma reff330_not2900 : ~ @Equation2900 Fin3 reff330_inst.
Proof. unfold Equation2900. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff330_inst, reff330_op in H. discriminate H. Qed.

Lemma reff330_not2902 : ~ @Equation2902 Fin3 reff330_inst.
Proof. unfold Equation2902. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff330_inst, reff330_op in H. discriminate H. Qed.

Lemma reff330_not2903 : ~ @Equation2903 Fin3 reff330_inst.
Proof. unfold Equation2903. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff330_inst, reff330_op in H. discriminate H. Qed.

Lemma reff330_not2909 : ~ @Equation2909 Fin3 reff330_inst.
Proof. unfold Equation2909. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff330_inst, reff330_op in H. discriminate H. Qed.

Lemma reff330_not2910 : ~ @Equation2910 Fin3 reff330_inst.
Proof. unfold Equation2910. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff330_inst, reff330_op in H. discriminate H. Qed.

Lemma reff330_not2912 : ~ @Equation2912 Fin3 reff330_inst.
Proof. unfold Equation2912. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff330_inst, reff330_op in H. discriminate H. Qed.

Lemma reff330_not2913 : ~ @Equation2913 Fin3 reff330_inst.
Proof. unfold Equation2913. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff330_inst, reff330_op in H. discriminate H. Qed.

Lemma reff330_not2936 : ~ @Equation2936 Fin3 reff330_inst.
Proof. unfold Equation2936. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff330_inst, reff330_op in H. discriminate H. Qed.

Lemma reff330_not2937 : ~ @Equation2937 Fin3 reff330_inst.
Proof. unfold Equation2937. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff330_inst, reff330_op in H. discriminate H. Qed.

Lemma reff330_not2939 : ~ @Equation2939 Fin3 reff330_inst.
Proof. unfold Equation2939. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff330_inst, reff330_op in H. discriminate H. Qed.

Lemma reff330_not2940 : ~ @Equation2940 Fin3 reff330_inst.
Proof. unfold Equation2940. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff330_inst, reff330_op in H. discriminate H. Qed.

Lemma reff330_not2946 : ~ @Equation2946 Fin3 reff330_inst.
Proof. unfold Equation2946. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff330_inst, reff330_op in H. discriminate H. Qed.

Lemma reff330_not2947 : ~ @Equation2947 Fin3 reff330_inst.
Proof. unfold Equation2947. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff330_inst, reff330_op in H. discriminate H. Qed.

Lemma reff330_not2949 : ~ @Equation2949 Fin3 reff330_inst.
Proof. unfold Equation2949. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff330_inst, reff330_op in H. discriminate H. Qed.

Lemma reff330_not3051 : ~ @Equation3051 Fin3 reff330_inst.
Proof. unfold Equation3051. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff330_inst, reff330_op in H. discriminate H. Qed.

Lemma reff330_not3052 : ~ @Equation3052 Fin3 reff330_inst.
Proof. unfold Equation3052. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff330_inst, reff330_op in H. discriminate H. Qed.

Lemma reff330_not3053 : ~ @Equation3053 Fin3 reff330_inst.
Proof. unfold Equation3053. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff330_inst, reff330_op in H. discriminate H. Qed.

Lemma reff330_not3055 : ~ @Equation3055 Fin3 reff330_inst.
Proof. unfold Equation3055. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff330_inst, reff330_op in H. discriminate H. Qed.

Lemma reff330_not3056 : ~ @Equation3056 Fin3 reff330_inst.
Proof. unfold Equation3056. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff330_inst, reff330_op in H. discriminate H. Qed.

Lemma reff330_not3058 : ~ @Equation3058 Fin3 reff330_inst.
Proof. unfold Equation3058. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff330_inst, reff330_op in H. discriminate H. Qed.

Lemma reff330_not3059 : ~ @Equation3059 Fin3 reff330_inst.
Proof. unfold Equation3059. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff330_inst, reff330_op in H. discriminate H. Qed.

Lemma reff330_not3065 : ~ @Equation3065 Fin3 reff330_inst.
Proof. unfold Equation3065. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff330_inst, reff330_op in H. discriminate H. Qed.

Lemma reff330_not3066 : ~ @Equation3066 Fin3 reff330_inst.
Proof. unfold Equation3066. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff330_inst, reff330_op in H. discriminate H. Qed.

Lemma reff330_not3068 : ~ @Equation3068 Fin3 reff330_inst.
Proof. unfold Equation3068. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff330_inst, reff330_op in H. discriminate H. Qed.

Lemma reff330_not3069 : ~ @Equation3069 Fin3 reff330_inst.
Proof. unfold Equation3069. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff330_inst, reff330_op in H. discriminate H. Qed.

Lemma reff330_not3075 : ~ @Equation3075 Fin3 reff330_inst.
Proof. unfold Equation3075. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff330_inst, reff330_op in H. discriminate H. Qed.

Lemma reff330_not3076 : ~ @Equation3076 Fin3 reff330_inst.
Proof. unfold Equation3076. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff330_inst, reff330_op in H. discriminate H. Qed.

Lemma reff330_not3078 : ~ @Equation3078 Fin3 reff330_inst.
Proof. unfold Equation3078. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff330_inst, reff330_op in H. discriminate H. Qed.

Lemma reff330_not3079 : ~ @Equation3079 Fin3 reff330_inst.
Proof. unfold Equation3079. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff330_inst, reff330_op in H. discriminate H. Qed.

Lemma reff330_not3102 : ~ @Equation3102 Fin3 reff330_inst.
Proof. unfold Equation3102. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff330_inst, reff330_op in H. discriminate H. Qed.

Lemma reff330_not3103 : ~ @Equation3103 Fin3 reff330_inst.
Proof. unfold Equation3103. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff330_inst, reff330_op in H. discriminate H. Qed.

Lemma reff330_not3105 : ~ @Equation3105 Fin3 reff330_inst.
Proof. unfold Equation3105. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff330_inst, reff330_op in H. discriminate H. Qed.

Lemma reff330_not3106 : ~ @Equation3106 Fin3 reff330_inst.
Proof. unfold Equation3106. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff330_inst, reff330_op in H. discriminate H. Qed.

Lemma reff330_not3112 : ~ @Equation3112 Fin3 reff330_inst.
Proof. unfold Equation3112. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff330_inst, reff330_op in H. discriminate H. Qed.

Lemma reff330_not3113 : ~ @Equation3113 Fin3 reff330_inst.
Proof. unfold Equation3113. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff330_inst, reff330_op in H. discriminate H. Qed.

Lemma reff330_not3115 : ~ @Equation3115 Fin3 reff330_inst.
Proof. unfold Equation3115. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff330_inst, reff330_op in H. discriminate H. Qed.

Lemma reff330_not3116 : ~ @Equation3116 Fin3 reff330_inst.
Proof. unfold Equation3116. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff330_inst, reff330_op in H. discriminate H. Qed.

Lemma reff330_not3139 : ~ @Equation3139 Fin3 reff330_inst.
Proof. unfold Equation3139. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff330_inst, reff330_op in H. discriminate H. Qed.

Lemma reff330_not3140 : ~ @Equation3140 Fin3 reff330_inst.
Proof. unfold Equation3140. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff330_inst, reff330_op in H. discriminate H. Qed.

Lemma reff330_not3142 : ~ @Equation3142 Fin3 reff330_inst.
Proof. unfold Equation3142. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff330_inst, reff330_op in H. discriminate H. Qed.

Lemma reff330_not3143 : ~ @Equation3143 Fin3 reff330_inst.
Proof. unfold Equation3143. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff330_inst, reff330_op in H. discriminate H. Qed.

Lemma reff330_not3149 : ~ @Equation3149 Fin3 reff330_inst.
Proof. unfold Equation3149. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff330_inst, reff330_op in H. discriminate H. Qed.

Lemma reff330_not3150 : ~ @Equation3150 Fin3 reff330_inst.
Proof. unfold Equation3150. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff330_inst, reff330_op in H. discriminate H. Qed.

Lemma reff330_not3152 : ~ @Equation3152 Fin3 reff330_inst.
Proof. unfold Equation3152. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff330_inst, reff330_op in H. discriminate H. Qed.

Lemma reff330_not3258 : ~ @Equation3258 Fin3 reff330_inst.
Proof. unfold Equation3258. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff330_inst, reff330_op in H. discriminate H. Qed.

Lemma reff330_not3259 : ~ @Equation3259 Fin3 reff330_inst.
Proof. unfold Equation3259. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff330_inst, reff330_op in H. discriminate H. Qed.

Lemma reff330_not3261 : ~ @Equation3261 Fin3 reff330_inst.
Proof. unfold Equation3261. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff330_inst, reff330_op in H. discriminate H. Qed.

Lemma reff330_not3262 : ~ @Equation3262 Fin3 reff330_inst.
Proof. unfold Equation3262. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff330_inst, reff330_op in H. discriminate H. Qed.

Lemma reff330_not3268 : ~ @Equation3268 Fin3 reff330_inst.
Proof. unfold Equation3268. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff330_inst, reff330_op in H. discriminate H. Qed.

Lemma reff330_not3269 : ~ @Equation3269 Fin3 reff330_inst.
Proof. unfold Equation3269. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff330_inst, reff330_op in H. discriminate H. Qed.

Lemma reff330_not3271 : ~ @Equation3271 Fin3 reff330_inst.
Proof. unfold Equation3271. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff330_inst, reff330_op in H. discriminate H. Qed.

Lemma reff330_not3272 : ~ @Equation3272 Fin3 reff330_inst.
Proof. unfold Equation3272. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff330_inst, reff330_op in H. discriminate H. Qed.

Lemma reff330_not3278 : ~ @Equation3278 Fin3 reff330_inst.
Proof. unfold Equation3278. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff330_inst, reff330_op in H. discriminate H. Qed.

Lemma reff330_not3279 : ~ @Equation3279 Fin3 reff330_inst.
Proof. unfold Equation3279. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff330_inst, reff330_op in H. discriminate H. Qed.

Lemma reff330_not3281 : ~ @Equation3281 Fin3 reff330_inst.
Proof. unfold Equation3281. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff330_inst, reff330_op in H. discriminate H. Qed.

Lemma reff330_not3306 : ~ @Equation3306 Fin3 reff330_inst.
Proof. unfold Equation3306. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff330_inst, reff330_op in H. discriminate H. Qed.

Lemma reff330_not3308 : ~ @Equation3308 Fin3 reff330_inst.
Proof. unfold Equation3308. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff330_inst, reff330_op in H. discriminate H. Qed.

Lemma reff330_not3309 : ~ @Equation3309 Fin3 reff330_inst.
Proof. unfold Equation3309. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff330_inst, reff330_op in H. discriminate H. Qed.

Lemma reff330_not3315 : ~ @Equation3315 Fin3 reff330_inst.
Proof. unfold Equation3315. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff330_inst, reff330_op in H. discriminate H. Qed.

Lemma reff330_not3316 : ~ @Equation3316 Fin3 reff330_inst.
Proof. unfold Equation3316. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff330_inst, reff330_op in H. discriminate H. Qed.

Lemma reff330_not3342 : ~ @Equation3342 Fin3 reff330_inst.
Proof. unfold Equation3342. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff330_inst, reff330_op in H. discriminate H. Qed.

Lemma reff330_not3343 : ~ @Equation3343 Fin3 reff330_inst.
Proof. unfold Equation3343. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff330_inst, reff330_op in H. discriminate H. Qed.

Lemma reff330_not3345 : ~ @Equation3345 Fin3 reff330_inst.
Proof. unfold Equation3345. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff330_inst, reff330_op in H. discriminate H. Qed.

Lemma reff330_not3346 : ~ @Equation3346 Fin3 reff330_inst.
Proof. unfold Equation3346. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff330_inst, reff330_op in H. discriminate H. Qed.

Lemma reff330_not3352 : ~ @Equation3352 Fin3 reff330_inst.
Proof. unfold Equation3352. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff330_inst, reff330_op in H. discriminate H. Qed.

Lemma reff330_not3353 : ~ @Equation3353 Fin3 reff330_inst.
Proof. unfold Equation3353. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff330_inst, reff330_op in H. discriminate H. Qed.

Lemma reff330_not3458 : ~ @Equation3458 Fin3 reff330_inst.
Proof. unfold Equation3458. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff330_inst, reff330_op in H. discriminate H. Qed.

Lemma reff330_not3461 : ~ @Equation3461 Fin3 reff330_inst.
Proof. unfold Equation3461. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff330_inst, reff330_op in H. discriminate H. Qed.

Lemma reff330_not3462 : ~ @Equation3462 Fin3 reff330_inst.
Proof. unfold Equation3462. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff330_inst, reff330_op in H. discriminate H. Qed.

Lemma reff330_not3464 : ~ @Equation3464 Fin3 reff330_inst.
Proof. unfold Equation3464. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff330_inst, reff330_op in H. discriminate H. Qed.

Lemma reff330_not3465 : ~ @Equation3465 Fin3 reff330_inst.
Proof. unfold Equation3465. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff330_inst, reff330_op in H. discriminate H. Qed.

Lemma reff330_not3472 : ~ @Equation3472 Fin3 reff330_inst.
Proof. unfold Equation3472. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff330_inst, reff330_op in H. discriminate H. Qed.

Lemma reff330_not3474 : ~ @Equation3474 Fin3 reff330_inst.
Proof. unfold Equation3474. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff330_inst, reff330_op in H. discriminate H. Qed.

Lemma reff330_not3475 : ~ @Equation3475 Fin3 reff330_inst.
Proof. unfold Equation3475. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff330_inst, reff330_op in H. discriminate H. Qed.

Lemma reff330_not3481 : ~ @Equation3481 Fin3 reff330_inst.
Proof. unfold Equation3481. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff330_inst, reff330_op in H. discriminate H. Qed.

Lemma reff330_not3482 : ~ @Equation3482 Fin3 reff330_inst.
Proof. unfold Equation3482. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff330_inst, reff330_op in H. discriminate H. Qed.

Lemma reff330_not3484 : ~ @Equation3484 Fin3 reff330_inst.
Proof. unfold Equation3484. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff330_inst, reff330_op in H. discriminate H. Qed.

Lemma reff330_not3509 : ~ @Equation3509 Fin3 reff330_inst.
Proof. unfold Equation3509. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff330_inst, reff330_op in H. discriminate H. Qed.

Lemma reff330_not3512 : ~ @Equation3512 Fin3 reff330_inst.
Proof. unfold Equation3512. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff330_inst, reff330_op in H. discriminate H. Qed.

Lemma reff330_not3518 : ~ @Equation3518 Fin3 reff330_inst.
Proof. unfold Equation3518. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff330_inst, reff330_op in H. discriminate H. Qed.

Lemma reff330_not3521 : ~ @Equation3521 Fin3 reff330_inst.
Proof. unfold Equation3521. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff330_inst, reff330_op in H. discriminate H. Qed.

Lemma reff330_not3545 : ~ @Equation3545 Fin3 reff330_inst.
Proof. unfold Equation3545. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff330_inst, reff330_op in H. discriminate H. Qed.

Lemma reff330_not3546 : ~ @Equation3546 Fin3 reff330_inst.
Proof. unfold Equation3546. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff330_inst, reff330_op in H. discriminate H. Qed.

Lemma reff330_not3548 : ~ @Equation3548 Fin3 reff330_inst.
Proof. unfold Equation3548. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff330_inst, reff330_op in H. discriminate H. Qed.

Lemma reff330_not3549 : ~ @Equation3549 Fin3 reff330_inst.
Proof. unfold Equation3549. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff330_inst, reff330_op in H. discriminate H. Qed.

Lemma reff330_not3555 : ~ @Equation3555 Fin3 reff330_inst.
Proof. unfold Equation3555. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff330_inst, reff330_op in H. discriminate H. Qed.

Lemma reff330_not3556 : ~ @Equation3556 Fin3 reff330_inst.
Proof. unfold Equation3556. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff330_inst, reff330_op in H. discriminate H. Qed.

Lemma reff330_not3558 : ~ @Equation3558 Fin3 reff330_inst.
Proof. unfold Equation3558. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff330_inst, reff330_op in H. discriminate H. Qed.

Lemma reff330_not3661 : ~ @Equation3661 Fin3 reff330_inst.
Proof. unfold Equation3661. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff330_inst, reff330_op in H. discriminate H. Qed.

Lemma reff330_not3662 : ~ @Equation3662 Fin3 reff330_inst.
Proof. unfold Equation3662. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff330_inst, reff330_op in H. discriminate H. Qed.

Lemma reff330_not3664 : ~ @Equation3664 Fin3 reff330_inst.
Proof. unfold Equation3664. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff330_inst, reff330_op in H. discriminate H. Qed.

Lemma reff330_not3665 : ~ @Equation3665 Fin3 reff330_inst.
Proof. unfold Equation3665. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff330_inst, reff330_op in H. discriminate H. Qed.

Lemma reff330_not3667 : ~ @Equation3667 Fin3 reff330_inst.
Proof. unfold Equation3667. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff330_inst, reff330_op in H. discriminate H. Qed.

Lemma reff330_not3668 : ~ @Equation3668 Fin3 reff330_inst.
Proof. unfold Equation3668. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff330_inst, reff330_op in H. discriminate H. Qed.

Lemma reff330_not3674 : ~ @Equation3674 Fin3 reff330_inst.
Proof. unfold Equation3674. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff330_inst, reff330_op in H. discriminate H. Qed.

Lemma reff330_not3675 : ~ @Equation3675 Fin3 reff330_inst.
Proof. unfold Equation3675. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff330_inst, reff330_op in H. discriminate H. Qed.

Lemma reff330_not3677 : ~ @Equation3677 Fin3 reff330_inst.
Proof. unfold Equation3677. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff330_inst, reff330_op in H. discriminate H. Qed.

Lemma reff330_not3678 : ~ @Equation3678 Fin3 reff330_inst.
Proof. unfold Equation3678. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff330_inst, reff330_op in H. discriminate H. Qed.

Lemma reff330_not3684 : ~ @Equation3684 Fin3 reff330_inst.
Proof. unfold Equation3684. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff330_inst, reff330_op in H. discriminate H. Qed.

Lemma reff330_not3685 : ~ @Equation3685 Fin3 reff330_inst.
Proof. unfold Equation3685. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff330_inst, reff330_op in H. discriminate H. Qed.

Lemma reff330_not3687 : ~ @Equation3687 Fin3 reff330_inst.
Proof. unfold Equation3687. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff330_inst, reff330_op in H. discriminate H. Qed.

Lemma reff330_not3712 : ~ @Equation3712 Fin3 reff330_inst.
Proof. unfold Equation3712. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff330_inst, reff330_op in H. discriminate H. Qed.

Lemma reff330_not3714 : ~ @Equation3714 Fin3 reff330_inst.
Proof. unfold Equation3714. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff330_inst, reff330_op in H. discriminate H. Qed.

Lemma reff330_not3721 : ~ @Equation3721 Fin3 reff330_inst.
Proof. unfold Equation3721. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff330_inst, reff330_op in H. discriminate H. Qed.

Lemma reff330_not3724 : ~ @Equation3724 Fin3 reff330_inst.
Proof. unfold Equation3724. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff330_inst, reff330_op in H. discriminate H. Qed.

Lemma reff330_not3748 : ~ @Equation3748 Fin3 reff330_inst.
Proof. unfold Equation3748. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff330_inst, reff330_op in H. discriminate H. Qed.

Lemma reff330_not3749 : ~ @Equation3749 Fin3 reff330_inst.
Proof. unfold Equation3749. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff330_inst, reff330_op in H. discriminate H. Qed.

Lemma reff330_not3751 : ~ @Equation3751 Fin3 reff330_inst.
Proof. unfold Equation3751. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff330_inst, reff330_op in H. discriminate H. Qed.

Lemma reff330_not3752 : ~ @Equation3752 Fin3 reff330_inst.
Proof. unfold Equation3752. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff330_inst, reff330_op in H. discriminate H. Qed.

Lemma reff330_not3758 : ~ @Equation3758 Fin3 reff330_inst.
Proof. unfold Equation3758. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff330_inst, reff330_op in H. discriminate H. Qed.

Lemma reff330_not3759 : ~ @Equation3759 Fin3 reff330_inst.
Proof. unfold Equation3759. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff330_inst, reff330_op in H. discriminate H. Qed.

Lemma reff330_not3761 : ~ @Equation3761 Fin3 reff330_inst.
Proof. unfold Equation3761. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff330_inst, reff330_op in H. discriminate H. Qed.

Lemma reff330_not3865 : ~ @Equation3865 Fin3 reff330_inst.
Proof. unfold Equation3865. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff330_inst, reff330_op in H. discriminate H. Qed.

Lemma reff330_not3867 : ~ @Equation3867 Fin3 reff330_inst.
Proof. unfold Equation3867. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff330_inst, reff330_op in H. discriminate H. Qed.

Lemma reff330_not3868 : ~ @Equation3868 Fin3 reff330_inst.
Proof. unfold Equation3868. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff330_inst, reff330_op in H. discriminate H. Qed.

Lemma reff330_not3870 : ~ @Equation3870 Fin3 reff330_inst.
Proof. unfold Equation3870. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff330_inst, reff330_op in H. discriminate H. Qed.

Lemma reff330_not3871 : ~ @Equation3871 Fin3 reff330_inst.
Proof. unfold Equation3871. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff330_inst, reff330_op in H. discriminate H. Qed.

Lemma reff330_not3877 : ~ @Equation3877 Fin3 reff330_inst.
Proof. unfold Equation3877. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff330_inst, reff330_op in H. discriminate H. Qed.

Lemma reff330_not3878 : ~ @Equation3878 Fin3 reff330_inst.
Proof. unfold Equation3878. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff330_inst, reff330_op in H. discriminate H. Qed.

Lemma reff330_not3880 : ~ @Equation3880 Fin3 reff330_inst.
Proof. unfold Equation3880. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff330_inst, reff330_op in H. discriminate H. Qed.

Lemma reff330_not3881 : ~ @Equation3881 Fin3 reff330_inst.
Proof. unfold Equation3881. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff330_inst, reff330_op in H. discriminate H. Qed.

Lemma reff330_not3887 : ~ @Equation3887 Fin3 reff330_inst.
Proof. unfold Equation3887. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff330_inst, reff330_op in H. discriminate H. Qed.

Lemma reff330_not3888 : ~ @Equation3888 Fin3 reff330_inst.
Proof. unfold Equation3888. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff330_inst, reff330_op in H. discriminate H. Qed.

Lemma reff330_not3890 : ~ @Equation3890 Fin3 reff330_inst.
Proof. unfold Equation3890. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff330_inst, reff330_op in H. discriminate H. Qed.

Lemma reff330_not3917 : ~ @Equation3917 Fin3 reff330_inst.
Proof. unfold Equation3917. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff330_inst, reff330_op in H. discriminate H. Qed.

Lemma reff330_not3924 : ~ @Equation3924 Fin3 reff330_inst.
Proof. unfold Equation3924. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff330_inst, reff330_op in H. discriminate H. Qed.

Lemma reff330_not3925 : ~ @Equation3925 Fin3 reff330_inst.
Proof. unfold Equation3925. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff330_inst, reff330_op in H. discriminate H. Qed.

Lemma reff330_not3927 : ~ @Equation3927 Fin3 reff330_inst.
Proof. unfold Equation3927. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff330_inst, reff330_op in H. discriminate H. Qed.

Lemma reff330_not3951 : ~ @Equation3951 Fin3 reff330_inst.
Proof. unfold Equation3951. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff330_inst, reff330_op in H. discriminate H. Qed.

Lemma reff330_not3952 : ~ @Equation3952 Fin3 reff330_inst.
Proof. unfold Equation3952. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff330_inst, reff330_op in H. discriminate H. Qed.

Lemma reff330_not3954 : ~ @Equation3954 Fin3 reff330_inst.
Proof. unfold Equation3954. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff330_inst, reff330_op in H. discriminate H. Qed.

Lemma reff330_not3961 : ~ @Equation3961 Fin3 reff330_inst.
Proof. unfold Equation3961. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff330_inst, reff330_op in H. discriminate H. Qed.

Lemma reff330_not3962 : ~ @Equation3962 Fin3 reff330_inst.
Proof. unfold Equation3962. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff330_inst, reff330_op in H. discriminate H. Qed.

Lemma reff330_not3964 : ~ @Equation3964 Fin3 reff330_inst.
Proof. unfold Equation3964. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff330_inst, reff330_op in H. discriminate H. Qed.

Lemma reff330_not4066 : ~ @Equation4066 Fin3 reff330_inst.
Proof. unfold Equation4066. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff330_inst, reff330_op in H. discriminate H. Qed.

Lemma reff330_not4067 : ~ @Equation4067 Fin3 reff330_inst.
Proof. unfold Equation4067. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff330_inst, reff330_op in H. discriminate H. Qed.

Lemma reff330_not4068 : ~ @Equation4068 Fin3 reff330_inst.
Proof. unfold Equation4068. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff330_inst, reff330_op in H. discriminate H. Qed.

Lemma reff330_not4070 : ~ @Equation4070 Fin3 reff330_inst.
Proof. unfold Equation4070. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff330_inst, reff330_op in H. discriminate H. Qed.

Lemma reff330_not4071 : ~ @Equation4071 Fin3 reff330_inst.
Proof. unfold Equation4071. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff330_inst, reff330_op in H. discriminate H. Qed.

Lemma reff330_not4073 : ~ @Equation4073 Fin3 reff330_inst.
Proof. unfold Equation4073. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff330_inst, reff330_op in H. discriminate H. Qed.

Lemma reff330_not4074 : ~ @Equation4074 Fin3 reff330_inst.
Proof. unfold Equation4074. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff330_inst, reff330_op in H. discriminate H. Qed.

Lemma reff330_not4080 : ~ @Equation4080 Fin3 reff330_inst.
Proof. unfold Equation4080. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff330_inst, reff330_op in H. discriminate H. Qed.

Lemma reff330_not4081 : ~ @Equation4081 Fin3 reff330_inst.
Proof. unfold Equation4081. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff330_inst, reff330_op in H. discriminate H. Qed.

Lemma reff330_not4083 : ~ @Equation4083 Fin3 reff330_inst.
Proof. unfold Equation4083. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff330_inst, reff330_op in H. discriminate H. Qed.

Lemma reff330_not4084 : ~ @Equation4084 Fin3 reff330_inst.
Proof. unfold Equation4084. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff330_inst, reff330_op in H. discriminate H. Qed.

Lemma reff330_not4090 : ~ @Equation4090 Fin3 reff330_inst.
Proof. unfold Equation4090. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff330_inst, reff330_op in H. discriminate H. Qed.

Lemma reff330_not4091 : ~ @Equation4091 Fin3 reff330_inst.
Proof. unfold Equation4091. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff330_inst, reff330_op in H. discriminate H. Qed.

Lemma reff330_not4093 : ~ @Equation4093 Fin3 reff330_inst.
Proof. unfold Equation4093. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff330_inst, reff330_op in H. discriminate H. Qed.

Lemma reff330_not4120 : ~ @Equation4120 Fin3 reff330_inst.
Proof. unfold Equation4120. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff330_inst, reff330_op in H. discriminate H. Qed.

Lemma reff330_not4127 : ~ @Equation4127 Fin3 reff330_inst.
Proof. unfold Equation4127. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff330_inst, reff330_op in H. discriminate H. Qed.

Lemma reff330_not4128 : ~ @Equation4128 Fin3 reff330_inst.
Proof. unfold Equation4128. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff330_inst, reff330_op in H. discriminate H. Qed.

Lemma reff330_not4130 : ~ @Equation4130 Fin3 reff330_inst.
Proof. unfold Equation4130. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff330_inst, reff330_op in H. discriminate H. Qed.

Lemma reff330_not4155 : ~ @Equation4155 Fin3 reff330_inst.
Proof. unfold Equation4155. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff330_inst, reff330_op in H. discriminate H. Qed.

Lemma reff330_not4157 : ~ @Equation4157 Fin3 reff330_inst.
Proof. unfold Equation4157. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff330_inst, reff330_op in H. discriminate H. Qed.

Lemma reff330_not4158 : ~ @Equation4158 Fin3 reff330_inst.
Proof. unfold Equation4158. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff330_inst, reff330_op in H. discriminate H. Qed.

Lemma reff330_not4164 : ~ @Equation4164 Fin3 reff330_inst.
Proof. unfold Equation4164. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff330_inst, reff330_op in H. discriminate H. Qed.

Lemma reff330_not4165 : ~ @Equation4165 Fin3 reff330_inst.
Proof. unfold Equation4165. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff330_inst, reff330_op in H. discriminate H. Qed.

Lemma reff330_not4167 : ~ @Equation4167 Fin3 reff330_inst.
Proof. unfold Equation4167. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff330_inst, reff330_op in H. discriminate H. Qed.

Lemma reff330_not4269 : ~ @Equation4269 Fin3 reff330_inst.
Proof. unfold Equation4269. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff330_inst, reff330_op in H. discriminate H. Qed.

Lemma reff330_not4270 : ~ @Equation4270 Fin3 reff330_inst.
Proof. unfold Equation4270. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff330_inst, reff330_op in H. discriminate H. Qed.

Lemma reff330_not4272 : ~ @Equation4272 Fin3 reff330_inst.
Proof. unfold Equation4272. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff330_inst, reff330_op in H. discriminate H. Qed.

Lemma reff330_not4273 : ~ @Equation4273 Fin3 reff330_inst.
Proof. unfold Equation4273. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff330_inst, reff330_op in H. discriminate H. Qed.

Lemma reff330_not4275 : ~ @Equation4275 Fin3 reff330_inst.
Proof. unfold Equation4275. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff330_inst, reff330_op in H. discriminate H. Qed.

Lemma reff330_not4276 : ~ @Equation4276 Fin3 reff330_inst.
Proof. unfold Equation4276. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff330_inst, reff330_op in H. discriminate H. Qed.

Lemma reff330_not4283 : ~ @Equation4283 Fin3 reff330_inst.
Proof. unfold Equation4283. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff330_inst, reff330_op in H. discriminate H. Qed.

Lemma reff330_not4284 : ~ @Equation4284 Fin3 reff330_inst.
Proof. unfold Equation4284. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff330_inst, reff330_op in H. discriminate H. Qed.

Lemma reff330_not4290 : ~ @Equation4290 Fin3 reff330_inst.
Proof. unfold Equation4290. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff330_inst, reff330_op in H. discriminate H. Qed.

Lemma reff330_not4291 : ~ @Equation4291 Fin3 reff330_inst.
Proof. unfold Equation4291. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff330_inst, reff330_op in H. discriminate H. Qed.

Lemma reff330_not4293 : ~ @Equation4293 Fin3 reff330_inst.
Proof. unfold Equation4293. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff330_inst, reff330_op in H. discriminate H. Qed.

Lemma reff330_not4314 : ~ @Equation4314 Fin3 reff330_inst.
Proof. unfold Equation4314. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff330_inst, reff330_op in H. discriminate H. Qed.

Lemma reff330_not4320 : ~ @Equation4320 Fin3 reff330_inst.
Proof. unfold Equation4320. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff330_inst, reff330_op in H. discriminate H. Qed.

Lemma reff330_not4321 : ~ @Equation4321 Fin3 reff330_inst.
Proof. unfold Equation4321. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff330_inst, reff330_op in H. discriminate H. Qed.

Lemma reff330_not4343 : ~ @Equation4343 Fin3 reff330_inst.
Proof. unfold Equation4343. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff330_inst, reff330_op in H. discriminate H. Qed.

Lemma reff330_not4396 : ~ @Equation4396 Fin3 reff330_inst.
Proof. unfold Equation4396. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff330_inst, reff330_op in H. discriminate H. Qed.

Lemma reff330_not4398 : ~ @Equation4398 Fin3 reff330_inst.
Proof. unfold Equation4398. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff330_inst, reff330_op in H. discriminate H. Qed.

Lemma reff330_not4399 : ~ @Equation4399 Fin3 reff330_inst.
Proof. unfold Equation4399. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff330_inst, reff330_op in H. discriminate H. Qed.

Lemma reff330_not4405 : ~ @Equation4405 Fin3 reff330_inst.
Proof. unfold Equation4405. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff330_inst, reff330_op in H. discriminate H. Qed.

Lemma reff330_not4406 : ~ @Equation4406 Fin3 reff330_inst.
Proof. unfold Equation4406. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff330_inst, reff330_op in H. discriminate H. Qed.

Lemma reff330_not4408 : ~ @Equation4408 Fin3 reff330_inst.
Proof. unfold Equation4408. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff330_inst, reff330_op in H. discriminate H. Qed.

Lemma reff330_not4433 : ~ @Equation4433 Fin3 reff330_inst.
Proof. unfold Equation4433. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff330_inst, reff330_op in H. discriminate H. Qed.

Lemma reff330_not4435 : ~ @Equation4435 Fin3 reff330_inst.
Proof. unfold Equation4435. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff330_inst, reff330_op in H. discriminate H. Qed.

Lemma reff330_not4436 : ~ @Equation4436 Fin3 reff330_inst.
Proof. unfold Equation4436. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff330_inst, reff330_op in H. discriminate H. Qed.

Lemma reff330_not4442 : ~ @Equation4442 Fin3 reff330_inst.
Proof. unfold Equation4442. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff330_inst, reff330_op in H. discriminate H. Qed.

Lemma reff330_not4443 : ~ @Equation4443 Fin3 reff330_inst.
Proof. unfold Equation4443. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff330_inst, reff330_op in H. discriminate H. Qed.

Lemma reff330_not4445 : ~ @Equation4445 Fin3 reff330_inst.
Proof. unfold Equation4445. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff330_inst, reff330_op in H. discriminate H. Qed.

Lemma reff330_not4472 : ~ @Equation4472 Fin3 reff330_inst.
Proof. unfold Equation4472. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff330_inst, reff330_op in H. discriminate H. Qed.

Lemma reff330_not4479 : ~ @Equation4479 Fin3 reff330_inst.
Proof. unfold Equation4479. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff330_inst, reff330_op in H. discriminate H. Qed.

Lemma reff330_not4480 : ~ @Equation4480 Fin3 reff330_inst.
Proof. unfold Equation4480. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff330_inst, reff330_op in H. discriminate H. Qed.

Lemma reff330_not4482 : ~ @Equation4482 Fin3 reff330_inst.
Proof. unfold Equation4482. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff330_inst, reff330_op in H. discriminate H. Qed.

Lemma reff330_not4583 : ~ @Equation4583 Fin3 reff330_inst.
Proof. unfold Equation4583. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff330_inst, reff330_op in H. discriminate H. Qed.

Lemma reff330_not4584 : ~ @Equation4584 Fin3 reff330_inst.
Proof. unfold Equation4584. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff330_inst, reff330_op in H. discriminate H. Qed.

Lemma reff330_not4585 : ~ @Equation4585 Fin3 reff330_inst.
Proof. unfold Equation4585. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff330_inst, reff330_op in H. discriminate H. Qed.

Lemma reff330_not4587 : ~ @Equation4587 Fin3 reff330_inst.
Proof. unfold Equation4587. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff330_inst, reff330_op in H. discriminate H. Qed.

Lemma reff330_not4588 : ~ @Equation4588 Fin3 reff330_inst.
Proof. unfold Equation4588. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff330_inst, reff330_op in H. discriminate H. Qed.

Lemma reff330_not4590 : ~ @Equation4590 Fin3 reff330_inst.
Proof. unfold Equation4590. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff330_inst, reff330_op in H. discriminate H. Qed.

Lemma reff330_not4591 : ~ @Equation4591 Fin3 reff330_inst.
Proof. unfold Equation4591. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff330_inst, reff330_op in H. discriminate H. Qed.

Lemma reff330_not4598 : ~ @Equation4598 Fin3 reff330_inst.
Proof. unfold Equation4598. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff330_inst, reff330_op in H. discriminate H. Qed.

Lemma reff330_not4605 : ~ @Equation4605 Fin3 reff330_inst.
Proof. unfold Equation4605. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff330_inst, reff330_op in H. discriminate H. Qed.

Lemma reff330_not4606 : ~ @Equation4606 Fin3 reff330_inst.
Proof. unfold Equation4606. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff330_inst, reff330_op in H. discriminate H. Qed.

Lemma reff330_not4608 : ~ @Equation4608 Fin3 reff330_inst.
Proof. unfold Equation4608. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff330_inst, reff330_op in H. discriminate H. Qed.

Lemma reff330_not4629 : ~ @Equation4629 Fin3 reff330_inst.
Proof. unfold Equation4629. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff330_inst, reff330_op in H. discriminate H. Qed.

Lemma reff330_not4635 : ~ @Equation4635 Fin3 reff330_inst.
Proof. unfold Equation4635. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff330_inst, reff330_op in H. discriminate H. Qed.

Lemma reff330_not4658 : ~ @Equation4658 Fin3 reff330_inst.
Proof. unfold Equation4658. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff330_inst, reff330_op in H. discriminate H. Qed.

(** ---- reff34 (Fin4) ---- *)

Definition reff34_op (x y : Fin4) : Fin4 :=
  match x, y with
  | F4_0, F4_0 => F4_0 | F4_0, F4_1 => F4_2 | F4_0, F4_2 => F4_0 | F4_0, F4_3 => F4_2
  | F4_1, F4_0 => F4_0 | F4_1, F4_1 => F4_2 | F4_1, F4_2 => F4_0 | F4_1, F4_3 => F4_2
  | F4_2, F4_0 => F4_2 | F4_2, F4_1 => F4_0 | F4_2, F4_2 => F4_2 | F4_2, F4_3 => F4_0
  | F4_3, F4_0 => F4_2 | F4_3, F4_1 => F4_0 | F4_3, F4_2 => F4_2 | F4_3, F4_3 => F4_0
  end.

#[local] Instance reff34_inst : Magma Fin4 := {| magma_op := reff34_op |}.

Lemma reff34_sat3730 : @Equation3730 Fin4 reff34_inst.
Proof. unfold Equation3730, magma_op, reff34_inst, reff34_op. intros x y z w. destruct x, y, z, w; reflexivity. Qed.

Lemma reff34_sat3947 : @Equation3947 Fin4 reff34_inst.
Proof. unfold Equation3947, magma_op, reff34_inst, reff34_op. intros x y z w. destruct x, y, z, w; reflexivity. Qed.

Lemma reff34_sat4143 : @Equation4143 Fin4 reff34_inst.
Proof. unfold Equation4143, magma_op, reff34_inst, reff34_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff34_sat4521 : @Equation4521 Fin4 reff34_inst.
Proof. unfold Equation4521, magma_op, reff34_inst, reff34_op. intros x y z w. destruct x, y, z, w; reflexivity. Qed.

Lemma reff34_sat4673 : @Equation4673 Fin4 reff34_inst.
Proof. unfold Equation4673, magma_op, reff34_inst, reff34_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff34_not47 : ~ @Equation47 Fin4 reff34_inst.
Proof. unfold Equation47. intro H. specialize (H F4_1). unfold magma_op, reff34_inst, reff34_op in H. discriminate H. Qed.

Lemma reff34_not99 : ~ @Equation99 Fin4 reff34_inst.
Proof. unfold Equation99. intro H. specialize (H F4_1). unfold magma_op, reff34_inst, reff34_op in H. discriminate H. Qed.

Lemma reff34_not151 : ~ @Equation151 Fin4 reff34_inst.
Proof. unfold Equation151. intro H. specialize (H F4_1). unfold magma_op, reff34_inst, reff34_op in H. discriminate H. Qed.

Lemma reff34_not203 : ~ @Equation203 Fin4 reff34_inst.
Proof. unfold Equation203. intro H. specialize (H F4_1). unfold magma_op, reff34_inst, reff34_op in H. discriminate H. Qed.

Lemma reff34_not255 : ~ @Equation255 Fin4 reff34_inst.
Proof. unfold Equation255. intro H. specialize (H F4_1). unfold magma_op, reff34_inst, reff34_op in H. discriminate H. Qed.

Lemma reff34_not359 : ~ @Equation359 Fin4 reff34_inst.
Proof. unfold Equation359. intro H. specialize (H F4_1). unfold magma_op, reff34_inst, reff34_op in H. discriminate H. Qed.

Lemma reff34_not411 : ~ @Equation411 Fin4 reff34_inst.
Proof. unfold Equation411. intro H. specialize (H F4_1). unfold magma_op, reff34_inst, reff34_op in H. discriminate H. Qed.

Lemma reff34_not614 : ~ @Equation614 Fin4 reff34_inst.
Proof. unfold Equation614. intro H. specialize (H F4_1). unfold magma_op, reff34_inst, reff34_op in H. discriminate H. Qed.

Lemma reff34_not817 : ~ @Equation817 Fin4 reff34_inst.
Proof. unfold Equation817. intro H. specialize (H F4_1). unfold magma_op, reff34_inst, reff34_op in H. discriminate H. Qed.

Lemma reff34_not1020 : ~ @Equation1020 Fin4 reff34_inst.
Proof. unfold Equation1020. intro H. specialize (H F4_1). unfold magma_op, reff34_inst, reff34_op in H. discriminate H. Qed.

Lemma reff34_not1223 : ~ @Equation1223 Fin4 reff34_inst.
Proof. unfold Equation1223. intro H. specialize (H F4_1). unfold magma_op, reff34_inst, reff34_op in H. discriminate H. Qed.

Lemma reff34_not1426 : ~ @Equation1426 Fin4 reff34_inst.
Proof. unfold Equation1426. intro H. specialize (H F4_1). unfold magma_op, reff34_inst, reff34_op in H. discriminate H. Qed.

Lemma reff34_not1629 : ~ @Equation1629 Fin4 reff34_inst.
Proof. unfold Equation1629. intro H. specialize (H F4_1). unfold magma_op, reff34_inst, reff34_op in H. discriminate H. Qed.

Lemma reff34_not1832 : ~ @Equation1832 Fin4 reff34_inst.
Proof. unfold Equation1832. intro H. specialize (H F4_1). unfold magma_op, reff34_inst, reff34_op in H. discriminate H. Qed.

Lemma reff34_not2035 : ~ @Equation2035 Fin4 reff34_inst.
Proof. unfold Equation2035. intro H. specialize (H F4_1). unfold magma_op, reff34_inst, reff34_op in H. discriminate H. Qed.

Lemma reff34_not2238 : ~ @Equation2238 Fin4 reff34_inst.
Proof. unfold Equation2238. intro H. specialize (H F4_1). unfold magma_op, reff34_inst, reff34_op in H. discriminate H. Qed.

Lemma reff34_not2441 : ~ @Equation2441 Fin4 reff34_inst.
Proof. unfold Equation2441. intro H. specialize (H F4_1). unfold magma_op, reff34_inst, reff34_op in H. discriminate H. Qed.

Lemma reff34_not2644 : ~ @Equation2644 Fin4 reff34_inst.
Proof. unfold Equation2644. intro H. specialize (H F4_1). unfold magma_op, reff34_inst, reff34_op in H. discriminate H. Qed.

Lemma reff34_not2847 : ~ @Equation2847 Fin4 reff34_inst.
Proof. unfold Equation2847. intro H. specialize (H F4_1). unfold magma_op, reff34_inst, reff34_op in H. discriminate H. Qed.

Lemma reff34_not3050 : ~ @Equation3050 Fin4 reff34_inst.
Proof. unfold Equation3050. intro H. specialize (H F4_1). unfold magma_op, reff34_inst, reff34_op in H. discriminate H. Qed.

Lemma reff34_not3253 : ~ @Equation3253 Fin4 reff34_inst.
Proof. unfold Equation3253. intro H. specialize (H F4_1). unfold magma_op, reff34_inst, reff34_op in H. discriminate H. Qed.

Lemma reff34_not3456 : ~ @Equation3456 Fin4 reff34_inst.
Proof. unfold Equation3456. intro H. specialize (H F4_1). unfold magma_op, reff34_inst, reff34_op in H. discriminate H. Qed.

Lemma reff34_not3664 : ~ @Equation3664 Fin4 reff34_inst.
Proof. unfold Equation3664. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff34_inst, reff34_op in H. discriminate H. Qed.

Lemma reff34_not3665 : ~ @Equation3665 Fin4 reff34_inst.
Proof. unfold Equation3665. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff34_inst, reff34_op in H. discriminate H. Qed.

Lemma reff34_not3667 : ~ @Equation3667 Fin4 reff34_inst.
Proof. unfold Equation3667. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff34_inst, reff34_op in H. discriminate H. Qed.

Lemma reff34_not3668 : ~ @Equation3668 Fin4 reff34_inst.
Proof. unfold Equation3668. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff34_inst, reff34_op in H. discriminate H. Qed.

Lemma reff34_not3674 : ~ @Equation3674 Fin4 reff34_inst.
Proof. unfold Equation3674. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff34_inst, reff34_op in H. discriminate H. Qed.

Lemma reff34_not3675 : ~ @Equation3675 Fin4 reff34_inst.
Proof. unfold Equation3675. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff34_inst, reff34_op in H. discriminate H. Qed.

Lemma reff34_not3677 : ~ @Equation3677 Fin4 reff34_inst.
Proof. unfold Equation3677. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff34_inst, reff34_op in H. discriminate H. Qed.

Lemma reff34_not3678 : ~ @Equation3678 Fin4 reff34_inst.
Proof. unfold Equation3678. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff34_inst, reff34_op in H. discriminate H. Qed.

Lemma reff34_not3684 : ~ @Equation3684 Fin4 reff34_inst.
Proof. unfold Equation3684. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff34_inst, reff34_op in H. discriminate H. Qed.

Lemma reff34_not3685 : ~ @Equation3685 Fin4 reff34_inst.
Proof. unfold Equation3685. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff34_inst, reff34_op in H. discriminate H. Qed.

Lemma reff34_not3687 : ~ @Equation3687 Fin4 reff34_inst.
Proof. unfold Equation3687. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff34_inst, reff34_op in H. discriminate H. Qed.

Lemma reff34_not3712 : ~ @Equation3712 Fin4 reff34_inst.
Proof. unfold Equation3712. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff34_inst, reff34_op in H. discriminate H. Qed.

Lemma reff34_not3714 : ~ @Equation3714 Fin4 reff34_inst.
Proof. unfold Equation3714. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff34_inst, reff34_op in H. discriminate H. Qed.

Lemma reff34_not3748 : ~ @Equation3748 Fin4 reff34_inst.
Proof. unfold Equation3748. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff34_inst, reff34_op in H. discriminate H. Qed.

Lemma reff34_not3749 : ~ @Equation3749 Fin4 reff34_inst.
Proof. unfold Equation3749. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff34_inst, reff34_op in H. discriminate H. Qed.

Lemma reff34_not3751 : ~ @Equation3751 Fin4 reff34_inst.
Proof. unfold Equation3751. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff34_inst, reff34_op in H. discriminate H. Qed.

Lemma reff34_not3752 : ~ @Equation3752 Fin4 reff34_inst.
Proof. unfold Equation3752. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff34_inst, reff34_op in H. discriminate H. Qed.

Lemma reff34_not3759 : ~ @Equation3759 Fin4 reff34_inst.
Proof. unfold Equation3759. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff34_inst, reff34_op in H. discriminate H. Qed.

Lemma reff34_not3761 : ~ @Equation3761 Fin4 reff34_inst.
Proof. unfold Equation3761. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff34_inst, reff34_op in H. discriminate H. Qed.

Lemma reff34_not3865 : ~ @Equation3865 Fin4 reff34_inst.
Proof. unfold Equation3865. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff34_inst, reff34_op in H. discriminate H. Qed.

Lemma reff34_not3868 : ~ @Equation3868 Fin4 reff34_inst.
Proof. unfold Equation3868. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff34_inst, reff34_op in H. discriminate H. Qed.

Lemma reff34_not3871 : ~ @Equation3871 Fin4 reff34_inst.
Proof. unfold Equation3871. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff34_inst, reff34_op in H. discriminate H. Qed.

Lemma reff34_not3877 : ~ @Equation3877 Fin4 reff34_inst.
Proof. unfold Equation3877. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff34_inst, reff34_op in H. discriminate H. Qed.

Lemma reff34_not3878 : ~ @Equation3878 Fin4 reff34_inst.
Proof. unfold Equation3878. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff34_inst, reff34_op in H. discriminate H. Qed.

Lemma reff34_not3880 : ~ @Equation3880 Fin4 reff34_inst.
Proof. unfold Equation3880. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff34_inst, reff34_op in H. discriminate H. Qed.

Lemma reff34_not3881 : ~ @Equation3881 Fin4 reff34_inst.
Proof. unfold Equation3881. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff34_inst, reff34_op in H. discriminate H. Qed.

Lemma reff34_not3887 : ~ @Equation3887 Fin4 reff34_inst.
Proof. unfold Equation3887. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff34_inst, reff34_op in H. discriminate H. Qed.

Lemma reff34_not3888 : ~ @Equation3888 Fin4 reff34_inst.
Proof. unfold Equation3888. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff34_inst, reff34_op in H. discriminate H. Qed.

Lemma reff34_not3890 : ~ @Equation3890 Fin4 reff34_inst.
Proof. unfold Equation3890. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff34_inst, reff34_op in H. discriminate H. Qed.

Lemma reff34_not3917 : ~ @Equation3917 Fin4 reff34_inst.
Proof. unfold Equation3917. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff34_inst, reff34_op in H. discriminate H. Qed.

Lemma reff34_not3927 : ~ @Equation3927 Fin4 reff34_inst.
Proof. unfold Equation3927. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff34_inst, reff34_op in H. discriminate H. Qed.

Lemma reff34_not3951 : ~ @Equation3951 Fin4 reff34_inst.
Proof. unfold Equation3951. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff34_inst, reff34_op in H. discriminate H. Qed.

Lemma reff34_not3952 : ~ @Equation3952 Fin4 reff34_inst.
Proof. unfold Equation3952. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff34_inst, reff34_op in H. discriminate H. Qed.

Lemma reff34_not3954 : ~ @Equation3954 Fin4 reff34_inst.
Proof. unfold Equation3954. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff34_inst, reff34_op in H. discriminate H. Qed.

Lemma reff34_not3955 : ~ @Equation3955 Fin4 reff34_inst.
Proof. unfold Equation3955. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff34_inst, reff34_op in H. discriminate H. Qed.

Lemma reff34_not3961 : ~ @Equation3961 Fin4 reff34_inst.
Proof. unfold Equation3961. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff34_inst, reff34_op in H. discriminate H. Qed.

Lemma reff34_not3962 : ~ @Equation3962 Fin4 reff34_inst.
Proof. unfold Equation3962. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff34_inst, reff34_op in H. discriminate H. Qed.

Lemma reff34_not3964 : ~ @Equation3964 Fin4 reff34_inst.
Proof. unfold Equation3964. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff34_inst, reff34_op in H. discriminate H. Qed.

Lemma reff34_not4066 : ~ @Equation4066 Fin4 reff34_inst.
Proof. unfold Equation4066. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff34_inst, reff34_op in H. discriminate H. Qed.

Lemma reff34_not4067 : ~ @Equation4067 Fin4 reff34_inst.
Proof. unfold Equation4067. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff34_inst, reff34_op in H. discriminate H. Qed.

Lemma reff34_not4070 : ~ @Equation4070 Fin4 reff34_inst.
Proof. unfold Equation4070. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff34_inst, reff34_op in H. discriminate H. Qed.

Lemma reff34_not4074 : ~ @Equation4074 Fin4 reff34_inst.
Proof. unfold Equation4074. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff34_inst, reff34_op in H. discriminate H. Qed.

Lemma reff34_not4080 : ~ @Equation4080 Fin4 reff34_inst.
Proof. unfold Equation4080. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff34_inst, reff34_op in H. discriminate H. Qed.

Lemma reff34_not4081 : ~ @Equation4081 Fin4 reff34_inst.
Proof. unfold Equation4081. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff34_inst, reff34_op in H. discriminate H. Qed.

Lemma reff34_not4083 : ~ @Equation4083 Fin4 reff34_inst.
Proof. unfold Equation4083. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff34_inst, reff34_op in H. discriminate H. Qed.

Lemma reff34_not4084 : ~ @Equation4084 Fin4 reff34_inst.
Proof. unfold Equation4084. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff34_inst, reff34_op in H. discriminate H. Qed.

Lemma reff34_not4090 : ~ @Equation4090 Fin4 reff34_inst.
Proof. unfold Equation4090. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff34_inst, reff34_op in H. discriminate H. Qed.

Lemma reff34_not4091 : ~ @Equation4091 Fin4 reff34_inst.
Proof. unfold Equation4091. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff34_inst, reff34_op in H. discriminate H. Qed.

Lemma reff34_not4093 : ~ @Equation4093 Fin4 reff34_inst.
Proof. unfold Equation4093. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff34_inst, reff34_op in H. discriminate H. Qed.

Lemma reff34_not4121 : ~ @Equation4121 Fin4 reff34_inst.
Proof. unfold Equation4121. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff34_inst, reff34_op in H. discriminate H. Qed.

Lemma reff34_not4128 : ~ @Equation4128 Fin4 reff34_inst.
Proof. unfold Equation4128. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff34_inst, reff34_op in H. discriminate H. Qed.

Lemma reff34_not4130 : ~ @Equation4130 Fin4 reff34_inst.
Proof. unfold Equation4130. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff34_inst, reff34_op in H. discriminate H. Qed.

Lemma reff34_not4155 : ~ @Equation4155 Fin4 reff34_inst.
Proof. unfold Equation4155. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff34_inst, reff34_op in H. discriminate H. Qed.

Lemma reff34_not4157 : ~ @Equation4157 Fin4 reff34_inst.
Proof. unfold Equation4157. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff34_inst, reff34_op in H. discriminate H. Qed.

Lemma reff34_not4158 : ~ @Equation4158 Fin4 reff34_inst.
Proof. unfold Equation4158. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff34_inst, reff34_op in H. discriminate H. Qed.

Lemma reff34_not4164 : ~ @Equation4164 Fin4 reff34_inst.
Proof. unfold Equation4164. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff34_inst, reff34_op in H. discriminate H. Qed.

Lemma reff34_not4165 : ~ @Equation4165 Fin4 reff34_inst.
Proof. unfold Equation4165. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff34_inst, reff34_op in H. discriminate H. Qed.

Lemma reff34_not4167 : ~ @Equation4167 Fin4 reff34_inst.
Proof. unfold Equation4167. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff34_inst, reff34_op in H. discriminate H. Qed.

Lemma reff34_not4272 : ~ @Equation4272 Fin4 reff34_inst.
Proof. unfold Equation4272. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff34_inst, reff34_op in H. discriminate H. Qed.

Lemma reff34_not4273 : ~ @Equation4273 Fin4 reff34_inst.
Proof. unfold Equation4273. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff34_inst, reff34_op in H. discriminate H. Qed.

Lemma reff34_not4275 : ~ @Equation4275 Fin4 reff34_inst.
Proof. unfold Equation4275. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff34_inst, reff34_op in H. discriminate H. Qed.

Lemma reff34_not4276 : ~ @Equation4276 Fin4 reff34_inst.
Proof. unfold Equation4276. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff34_inst, reff34_op in H. discriminate H. Qed.

Lemma reff34_not4290 : ~ @Equation4290 Fin4 reff34_inst.
Proof. unfold Equation4290. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff34_inst, reff34_op in H. discriminate H. Qed.

Lemma reff34_not4291 : ~ @Equation4291 Fin4 reff34_inst.
Proof. unfold Equation4291. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff34_inst, reff34_op in H. discriminate H. Qed.

Lemma reff34_not4293 : ~ @Equation4293 Fin4 reff34_inst.
Proof. unfold Equation4293. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff34_inst, reff34_op in H. discriminate H. Qed.

Lemma reff34_not4320 : ~ @Equation4320 Fin4 reff34_inst.
Proof. unfold Equation4320. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff34_inst, reff34_op in H. discriminate H. Qed.

Lemma reff34_not4321 : ~ @Equation4321 Fin4 reff34_inst.
Proof. unfold Equation4321. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff34_inst, reff34_op in H. discriminate H. Qed.

Lemma reff34_not4343 : ~ @Equation4343 Fin4 reff34_inst.
Proof. unfold Equation4343. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff34_inst, reff34_op in H. discriminate H. Qed.

Lemma reff34_not4396 : ~ @Equation4396 Fin4 reff34_inst.
Proof. unfold Equation4396. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff34_inst, reff34_op in H. discriminate H. Qed.

Lemma reff34_not4398 : ~ @Equation4398 Fin4 reff34_inst.
Proof. unfold Equation4398. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff34_inst, reff34_op in H. discriminate H. Qed.

Lemma reff34_not4405 : ~ @Equation4405 Fin4 reff34_inst.
Proof. unfold Equation4405. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff34_inst, reff34_op in H. discriminate H. Qed.

Lemma reff34_not4406 : ~ @Equation4406 Fin4 reff34_inst.
Proof. unfold Equation4406. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff34_inst, reff34_op in H. discriminate H. Qed.

Lemma reff34_not4408 : ~ @Equation4408 Fin4 reff34_inst.
Proof. unfold Equation4408. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff34_inst, reff34_op in H. discriminate H. Qed.

Lemma reff34_not4433 : ~ @Equation4433 Fin4 reff34_inst.
Proof. unfold Equation4433. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff34_inst, reff34_op in H. discriminate H. Qed.

Lemma reff34_not4435 : ~ @Equation4435 Fin4 reff34_inst.
Proof. unfold Equation4435. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff34_inst, reff34_op in H. discriminate H. Qed.

Lemma reff34_not4442 : ~ @Equation4442 Fin4 reff34_inst.
Proof. unfold Equation4442. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff34_inst, reff34_op in H. discriminate H. Qed.

Lemma reff34_not4443 : ~ @Equation4443 Fin4 reff34_inst.
Proof. unfold Equation4443. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff34_inst, reff34_op in H. discriminate H. Qed.

Lemma reff34_not4445 : ~ @Equation4445 Fin4 reff34_inst.
Proof. unfold Equation4445. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff34_inst, reff34_op in H. discriminate H. Qed.

Lemma reff34_not4470 : ~ @Equation4470 Fin4 reff34_inst.
Proof. unfold Equation4470. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff34_inst, reff34_op in H. discriminate H. Qed.

Lemma reff34_not4472 : ~ @Equation4472 Fin4 reff34_inst.
Proof. unfold Equation4472. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff34_inst, reff34_op in H. discriminate H. Qed.

Lemma reff34_not4479 : ~ @Equation4479 Fin4 reff34_inst.
Proof. unfold Equation4479. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff34_inst, reff34_op in H. discriminate H. Qed.

Lemma reff34_not4480 : ~ @Equation4480 Fin4 reff34_inst.
Proof. unfold Equation4480. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff34_inst, reff34_op in H. discriminate H. Qed.

Lemma reff34_not4482 : ~ @Equation4482 Fin4 reff34_inst.
Proof. unfold Equation4482. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff34_inst, reff34_op in H. discriminate H. Qed.

Lemma reff34_not4583 : ~ @Equation4583 Fin4 reff34_inst.
Proof. unfold Equation4583. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff34_inst, reff34_op in H. discriminate H. Qed.

Lemma reff34_not4584 : ~ @Equation4584 Fin4 reff34_inst.
Proof. unfold Equation4584. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff34_inst, reff34_op in H. discriminate H. Qed.

Lemma reff34_not4587 : ~ @Equation4587 Fin4 reff34_inst.
Proof. unfold Equation4587. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff34_inst, reff34_op in H. discriminate H. Qed.

Lemma reff34_not4588 : ~ @Equation4588 Fin4 reff34_inst.
Proof. unfold Equation4588. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff34_inst, reff34_op in H. discriminate H. Qed.

Lemma reff34_not4590 : ~ @Equation4590 Fin4 reff34_inst.
Proof. unfold Equation4590. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff34_inst, reff34_op in H. discriminate H. Qed.

Lemma reff34_not4591 : ~ @Equation4591 Fin4 reff34_inst.
Proof. unfold Equation4591. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff34_inst, reff34_op in H. discriminate H. Qed.

Lemma reff34_not4599 : ~ @Equation4599 Fin4 reff34_inst.
Proof. unfold Equation4599. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff34_inst, reff34_op in H. discriminate H. Qed.

Lemma reff34_not4605 : ~ @Equation4605 Fin4 reff34_inst.
Proof. unfold Equation4605. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff34_inst, reff34_op in H. discriminate H. Qed.

Lemma reff34_not4606 : ~ @Equation4606 Fin4 reff34_inst.
Proof. unfold Equation4606. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff34_inst, reff34_op in H. discriminate H. Qed.

Lemma reff34_not4608 : ~ @Equation4608 Fin4 reff34_inst.
Proof. unfold Equation4608. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff34_inst, reff34_op in H. discriminate H. Qed.

Lemma reff34_not4629 : ~ @Equation4629 Fin4 reff34_inst.
Proof. unfold Equation4629. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff34_inst, reff34_op in H. discriminate H. Qed.

Lemma reff34_not4635 : ~ @Equation4635 Fin4 reff34_inst.
Proof. unfold Equation4635. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff34_inst, reff34_op in H. discriminate H. Qed.

Lemma reff34_not4636 : ~ @Equation4636 Fin4 reff34_inst.
Proof. unfold Equation4636. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff34_inst, reff34_op in H. discriminate H. Qed.

Lemma reff34_not4658 : ~ @Equation4658 Fin4 reff34_inst.
Proof. unfold Equation4658. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff34_inst, reff34_op in H. discriminate H. Qed.

(** ---- reff340 (Fin4) ---- *)

Definition reff340_op (x y : Fin4) : Fin4 :=
  match x, y with
  | F4_0, F4_0 => F4_0 | F4_0, F4_1 => F4_0 | F4_0, F4_2 => F4_0 | F4_0, F4_3 => F4_0
  | F4_1, F4_0 => F4_2 | F4_1, F4_1 => F4_2 | F4_1, F4_2 => F4_2 | F4_1, F4_3 => F4_2
  | F4_2, F4_0 => F4_0 | F4_2, F4_1 => F4_0 | F4_2, F4_2 => F4_0 | F4_2, F4_3 => F4_0
  | F4_3, F4_0 => F4_2 | F4_3, F4_1 => F4_2 | F4_3, F4_2 => F4_2 | F4_3, F4_3 => F4_2
  end.

#[local] Instance reff340_inst : Magma Fin4 := {| magma_op := reff340_op |}.

Lemma reff340_sat38 : @Equation38 Fin4 reff340_inst.
Proof. unfold Equation38, magma_op, reff340_inst, reff340_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff340_sat4589 : @Equation4589 Fin4 reff340_inst.
Proof. unfold Equation4589, magma_op, reff340_inst, reff340_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff340_not47 : ~ @Equation47 Fin4 reff340_inst.
Proof. unfold Equation47. intro H. specialize (H F4_1). unfold magma_op, reff340_inst, reff340_op in H. discriminate H. Qed.

Lemma reff340_not99 : ~ @Equation99 Fin4 reff340_inst.
Proof. unfold Equation99. intro H. specialize (H F4_1). unfold magma_op, reff340_inst, reff340_op in H. discriminate H. Qed.

Lemma reff340_not151 : ~ @Equation151 Fin4 reff340_inst.
Proof. unfold Equation151. intro H. specialize (H F4_1). unfold magma_op, reff340_inst, reff340_op in H. discriminate H. Qed.

Lemma reff340_not203 : ~ @Equation203 Fin4 reff340_inst.
Proof. unfold Equation203. intro H. specialize (H F4_1). unfold magma_op, reff340_inst, reff340_op in H. discriminate H. Qed.

Lemma reff340_not255 : ~ @Equation255 Fin4 reff340_inst.
Proof. unfold Equation255. intro H. specialize (H F4_1). unfold magma_op, reff340_inst, reff340_op in H. discriminate H. Qed.

Lemma reff340_not411 : ~ @Equation411 Fin4 reff340_inst.
Proof. unfold Equation411. intro H. specialize (H F4_1). unfold magma_op, reff340_inst, reff340_op in H. discriminate H. Qed.

Lemma reff340_not614 : ~ @Equation614 Fin4 reff340_inst.
Proof. unfold Equation614. intro H. specialize (H F4_1). unfold magma_op, reff340_inst, reff340_op in H. discriminate H. Qed.

Lemma reff340_not817 : ~ @Equation817 Fin4 reff340_inst.
Proof. unfold Equation817. intro H. specialize (H F4_1). unfold magma_op, reff340_inst, reff340_op in H. discriminate H. Qed.

Lemma reff340_not1020 : ~ @Equation1020 Fin4 reff340_inst.
Proof. unfold Equation1020. intro H. specialize (H F4_1). unfold magma_op, reff340_inst, reff340_op in H. discriminate H. Qed.

Lemma reff340_not1223 : ~ @Equation1223 Fin4 reff340_inst.
Proof. unfold Equation1223. intro H. specialize (H F4_1). unfold magma_op, reff340_inst, reff340_op in H. discriminate H. Qed.

Lemma reff340_not1426 : ~ @Equation1426 Fin4 reff340_inst.
Proof. unfold Equation1426. intro H. specialize (H F4_1). unfold magma_op, reff340_inst, reff340_op in H. discriminate H. Qed.

Lemma reff340_not1629 : ~ @Equation1629 Fin4 reff340_inst.
Proof. unfold Equation1629. intro H. specialize (H F4_1). unfold magma_op, reff340_inst, reff340_op in H. discriminate H. Qed.

Lemma reff340_not1832 : ~ @Equation1832 Fin4 reff340_inst.
Proof. unfold Equation1832. intro H. specialize (H F4_1). unfold magma_op, reff340_inst, reff340_op in H. discriminate H. Qed.

Lemma reff340_not2035 : ~ @Equation2035 Fin4 reff340_inst.
Proof. unfold Equation2035. intro H. specialize (H F4_1). unfold magma_op, reff340_inst, reff340_op in H. discriminate H. Qed.

Lemma reff340_not2238 : ~ @Equation2238 Fin4 reff340_inst.
Proof. unfold Equation2238. intro H. specialize (H F4_1). unfold magma_op, reff340_inst, reff340_op in H. discriminate H. Qed.

Lemma reff340_not2441 : ~ @Equation2441 Fin4 reff340_inst.
Proof. unfold Equation2441. intro H. specialize (H F4_1). unfold magma_op, reff340_inst, reff340_op in H. discriminate H. Qed.

Lemma reff340_not2644 : ~ @Equation2644 Fin4 reff340_inst.
Proof. unfold Equation2644. intro H. specialize (H F4_1). unfold magma_op, reff340_inst, reff340_op in H. discriminate H. Qed.

Lemma reff340_not2847 : ~ @Equation2847 Fin4 reff340_inst.
Proof. unfold Equation2847. intro H. specialize (H F4_1). unfold magma_op, reff340_inst, reff340_op in H. discriminate H. Qed.

Lemma reff340_not3050 : ~ @Equation3050 Fin4 reff340_inst.
Proof. unfold Equation3050. intro H. specialize (H F4_1). unfold magma_op, reff340_inst, reff340_op in H. discriminate H. Qed.

Lemma reff340_not3268 : ~ @Equation3268 Fin4 reff340_inst.
Proof. unfold Equation3268. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff340_inst, reff340_op in H. discriminate H. Qed.

Lemma reff340_not3271 : ~ @Equation3271 Fin4 reff340_inst.
Proof. unfold Equation3271. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff340_inst, reff340_op in H. discriminate H. Qed.

Lemma reff340_not3272 : ~ @Equation3272 Fin4 reff340_inst.
Proof. unfold Equation3272. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff340_inst, reff340_op in H. discriminate H. Qed.

Lemma reff340_not3278 : ~ @Equation3278 Fin4 reff340_inst.
Proof. unfold Equation3278. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff340_inst, reff340_op in H. discriminate H. Qed.

Lemma reff340_not3279 : ~ @Equation3279 Fin4 reff340_inst.
Proof. unfold Equation3279. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff340_inst, reff340_op in H. discriminate H. Qed.

Lemma reff340_not3281 : ~ @Equation3281 Fin4 reff340_inst.
Proof. unfold Equation3281. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff340_inst, reff340_op in H. discriminate H. Qed.

Lemma reff340_not3342 : ~ @Equation3342 Fin4 reff340_inst.
Proof. unfold Equation3342. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff340_inst, reff340_op in H. discriminate H. Qed.

Lemma reff340_not3343 : ~ @Equation3343 Fin4 reff340_inst.
Proof. unfold Equation3343. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff340_inst, reff340_op in H. discriminate H. Qed.

Lemma reff340_not3345 : ~ @Equation3345 Fin4 reff340_inst.
Proof. unfold Equation3345. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff340_inst, reff340_op in H. discriminate H. Qed.

Lemma reff340_not3346 : ~ @Equation3346 Fin4 reff340_inst.
Proof. unfold Equation3346. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff340_inst, reff340_op in H. discriminate H. Qed.

Lemma reff340_not3352 : ~ @Equation3352 Fin4 reff340_inst.
Proof. unfold Equation3352. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff340_inst, reff340_op in H. discriminate H. Qed.

Lemma reff340_not3353 : ~ @Equation3353 Fin4 reff340_inst.
Proof. unfold Equation3353. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff340_inst, reff340_op in H. discriminate H. Qed.

Lemma reff340_not3472 : ~ @Equation3472 Fin4 reff340_inst.
Proof. unfold Equation3472. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff340_inst, reff340_op in H. discriminate H. Qed.

Lemma reff340_not3474 : ~ @Equation3474 Fin4 reff340_inst.
Proof. unfold Equation3474. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff340_inst, reff340_op in H. discriminate H. Qed.

Lemma reff340_not3475 : ~ @Equation3475 Fin4 reff340_inst.
Proof. unfold Equation3475. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff340_inst, reff340_op in H. discriminate H. Qed.

Lemma reff340_not3481 : ~ @Equation3481 Fin4 reff340_inst.
Proof. unfold Equation3481. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff340_inst, reff340_op in H. discriminate H. Qed.

Lemma reff340_not3482 : ~ @Equation3482 Fin4 reff340_inst.
Proof. unfold Equation3482. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff340_inst, reff340_op in H. discriminate H. Qed.

Lemma reff340_not3484 : ~ @Equation3484 Fin4 reff340_inst.
Proof. unfold Equation3484. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff340_inst, reff340_op in H. discriminate H. Qed.

Lemma reff340_not3545 : ~ @Equation3545 Fin4 reff340_inst.
Proof. unfold Equation3545. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff340_inst, reff340_op in H. discriminate H. Qed.

Lemma reff340_not3546 : ~ @Equation3546 Fin4 reff340_inst.
Proof. unfold Equation3546. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff340_inst, reff340_op in H. discriminate H. Qed.

Lemma reff340_not3548 : ~ @Equation3548 Fin4 reff340_inst.
Proof. unfold Equation3548. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff340_inst, reff340_op in H. discriminate H. Qed.

Lemma reff340_not3549 : ~ @Equation3549 Fin4 reff340_inst.
Proof. unfold Equation3549. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff340_inst, reff340_op in H. discriminate H. Qed.

Lemma reff340_not3555 : ~ @Equation3555 Fin4 reff340_inst.
Proof. unfold Equation3555. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff340_inst, reff340_op in H. discriminate H. Qed.

Lemma reff340_not3558 : ~ @Equation3558 Fin4 reff340_inst.
Proof. unfold Equation3558. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff340_inst, reff340_op in H. discriminate H. Qed.

Lemma reff340_not3659 : ~ @Equation3659 Fin4 reff340_inst.
Proof. unfold Equation3659. intro H. specialize (H F4_1). unfold magma_op, reff340_inst, reff340_op in H. discriminate H. Qed.

Lemma reff340_not3862 : ~ @Equation3862 Fin4 reff340_inst.
Proof. unfold Equation3862. intro H. specialize (H F4_1). unfold magma_op, reff340_inst, reff340_op in H. discriminate H. Qed.

Lemma reff340_not4065 : ~ @Equation4065 Fin4 reff340_inst.
Proof. unfold Equation4065. intro H. specialize (H F4_1). unfold magma_op, reff340_inst, reff340_op in H. discriminate H. Qed.

Lemma reff340_not4272 : ~ @Equation4272 Fin4 reff340_inst.
Proof. unfold Equation4272. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff340_inst, reff340_op in H. discriminate H. Qed.

Lemma reff340_not4273 : ~ @Equation4273 Fin4 reff340_inst.
Proof. unfold Equation4273. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff340_inst, reff340_op in H. discriminate H. Qed.

Lemma reff340_not4275 : ~ @Equation4275 Fin4 reff340_inst.
Proof. unfold Equation4275. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff340_inst, reff340_op in H. discriminate H. Qed.

Lemma reff340_not4276 : ~ @Equation4276 Fin4 reff340_inst.
Proof. unfold Equation4276. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff340_inst, reff340_op in H. discriminate H. Qed.

Lemma reff340_not4290 : ~ @Equation4290 Fin4 reff340_inst.
Proof. unfold Equation4290. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff340_inst, reff340_op in H. discriminate H. Qed.

Lemma reff340_not4291 : ~ @Equation4291 Fin4 reff340_inst.
Proof. unfold Equation4291. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff340_inst, reff340_op in H. discriminate H. Qed.

Lemma reff340_not4293 : ~ @Equation4293 Fin4 reff340_inst.
Proof. unfold Equation4293. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff340_inst, reff340_op in H. discriminate H. Qed.

Lemma reff340_not4320 : ~ @Equation4320 Fin4 reff340_inst.
Proof. unfold Equation4320. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff340_inst, reff340_op in H. discriminate H. Qed.

Lemma reff340_not4321 : ~ @Equation4321 Fin4 reff340_inst.
Proof. unfold Equation4321. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff340_inst, reff340_op in H. discriminate H. Qed.

Lemma reff340_not4343 : ~ @Equation4343 Fin4 reff340_inst.
Proof. unfold Equation4343. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff340_inst, reff340_op in H. discriminate H. Qed.

Lemma reff340_not4380 : ~ @Equation4380 Fin4 reff340_inst.
Proof. unfold Equation4380. intro H. specialize (H F4_1). unfold magma_op, reff340_inst, reff340_op in H. discriminate H. Qed.

(** ---- reff342 (Fin4) ---- *)

Definition reff342_op (x y : Fin4) : Fin4 :=
  match x, y with
  | F4_0, F4_0 => F4_0 | F4_0, F4_1 => F4_2 | F4_0, F4_2 => F4_2 | F4_0, F4_3 => F4_0
  | F4_1, F4_0 => F4_3 | F4_1, F4_1 => F4_1 | F4_1, F4_2 => F4_1 | F4_1, F4_3 => F4_3
  | F4_2, F4_0 => F4_2 | F4_2, F4_1 => F4_0 | F4_2, F4_2 => F4_0 | F4_2, F4_3 => F4_2
  | F4_3, F4_0 => F4_1 | F4_3, F4_1 => F4_3 | F4_3, F4_2 => F4_3 | F4_3, F4_3 => F4_1
  end.

#[local] Instance reff342_inst : Magma Fin4 := {| magma_op := reff342_op |}.

Lemma reff342_sat419 : @Equation419 Fin4 reff342_inst.
Proof. unfold Equation419, magma_op, reff342_inst, reff342_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff342_sat436 : @Equation436 Fin4 reff342_inst.
Proof. unfold Equation436, magma_op, reff342_inst, reff342_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff342_sat620 : @Equation620 Fin4 reff342_inst.
Proof. unfold Equation620, magma_op, reff342_inst, reff342_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff342_sat622 : @Equation622 Fin4 reff342_inst.
Proof. unfold Equation622, magma_op, reff342_inst, reff342_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff342_sat842 : @Equation842 Fin4 reff342_inst.
Proof. unfold Equation842, magma_op, reff342_inst, reff342_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff342_sat1036 : @Equation1036 Fin4 reff342_inst.
Proof. unfold Equation1036, magma_op, reff342_inst, reff342_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff342_sat1470 : @Equation1470 Fin4 reff342_inst.
Proof. unfold Equation1470, magma_op, reff342_inst, reff342_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff342_sat1670 : @Equation1670 Fin4 reff342_inst.
Proof. unfold Equation1670, magma_op, reff342_inst, reff342_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff342_sat1673 : @Equation1673 Fin4 reff342_inst.
Proof. unfold Equation1673, magma_op, reff342_inst, reff342_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff342_sat2271 : @Equation2271 Fin4 reff342_inst.
Proof. unfold Equation2271, magma_op, reff342_inst, reff342_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff342_sat2474 : @Equation2474 Fin4 reff342_inst.
Proof. unfold Equation2474, magma_op, reff342_inst, reff342_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff342_sat2482 : @Equation2482 Fin4 reff342_inst.
Proof. unfold Equation2482, magma_op, reff342_inst, reff342_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff342_sat3334 : @Equation3334 Fin4 reff342_inst.
Proof. unfold Equation3334, magma_op, reff342_inst, reff342_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff342_sat3534 : @Equation3534 Fin4 reff342_inst.
Proof. unfold Equation3534, magma_op, reff342_inst, reff342_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff342_sat3537 : @Equation3537 Fin4 reff342_inst.
Proof. unfold Equation3537, magma_op, reff342_inst, reff342_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff342_not47 : ~ @Equation47 Fin4 reff342_inst.
Proof. unfold Equation47. intro H. specialize (H F4_2). unfold magma_op, reff342_inst, reff342_op in H. discriminate H. Qed.

Lemma reff342_not99 : ~ @Equation99 Fin4 reff342_inst.
Proof. unfold Equation99. intro H. specialize (H F4_2). unfold magma_op, reff342_inst, reff342_op in H. discriminate H. Qed.

Lemma reff342_not151 : ~ @Equation151 Fin4 reff342_inst.
Proof. unfold Equation151. intro H. specialize (H F4_2). unfold magma_op, reff342_inst, reff342_op in H. discriminate H. Qed.

Lemma reff342_not203 : ~ @Equation203 Fin4 reff342_inst.
Proof. unfold Equation203. intro H. specialize (H F4_2). unfold magma_op, reff342_inst, reff342_op in H. discriminate H. Qed.

Lemma reff342_not255 : ~ @Equation255 Fin4 reff342_inst.
Proof. unfold Equation255. intro H. specialize (H F4_2). unfold magma_op, reff342_inst, reff342_op in H. discriminate H. Qed.

Lemma reff342_not307 : ~ @Equation307 Fin4 reff342_inst.
Proof. unfold Equation307. intro H. specialize (H F4_2). unfold magma_op, reff342_inst, reff342_op in H. discriminate H. Qed.

Lemma reff342_not359 : ~ @Equation359 Fin4 reff342_inst.
Proof. unfold Equation359. intro H. specialize (H F4_2). unfold magma_op, reff342_inst, reff342_op in H. discriminate H. Qed.

Lemma reff342_not412 : ~ @Equation412 Fin4 reff342_inst.
Proof. unfold Equation412. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff342_inst, reff342_op in H. discriminate H. Qed.

Lemma reff342_not413 : ~ @Equation413 Fin4 reff342_inst.
Proof. unfold Equation413. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff342_inst, reff342_op in H. discriminate H. Qed.

Lemma reff342_not414 : ~ @Equation414 Fin4 reff342_inst.
Proof. unfold Equation414. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff342_inst, reff342_op in H. discriminate H. Qed.

Lemma reff342_not416 : ~ @Equation416 Fin4 reff342_inst.
Proof. unfold Equation416. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff342_inst, reff342_op in H. discriminate H. Qed.

Lemma reff342_not417 : ~ @Equation417 Fin4 reff342_inst.
Proof. unfold Equation417. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff342_inst, reff342_op in H. discriminate H. Qed.

Lemma reff342_not420 : ~ @Equation420 Fin4 reff342_inst.
Proof. unfold Equation420. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff342_inst, reff342_op in H. discriminate H. Qed.

Lemma reff342_not426 : ~ @Equation426 Fin4 reff342_inst.
Proof. unfold Equation426. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff342_inst, reff342_op in H. discriminate H. Qed.

Lemma reff342_not427 : ~ @Equation427 Fin4 reff342_inst.
Proof. unfold Equation427. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff342_inst, reff342_op in H. discriminate H. Qed.

Lemma reff342_not430 : ~ @Equation430 Fin4 reff342_inst.
Proof. unfold Equation430. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff342_inst, reff342_op in H. discriminate H. Qed.

Lemma reff342_not437 : ~ @Equation437 Fin4 reff342_inst.
Proof. unfold Equation437. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff342_inst, reff342_op in H. discriminate H. Qed.

Lemma reff342_not439 : ~ @Equation439 Fin4 reff342_inst.
Proof. unfold Equation439. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff342_inst, reff342_op in H. discriminate H. Qed.

Lemma reff342_not440 : ~ @Equation440 Fin4 reff342_inst.
Proof. unfold Equation440. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff342_inst, reff342_op in H. discriminate H. Qed.

Lemma reff342_not463 : ~ @Equation463 Fin4 reff342_inst.
Proof. unfold Equation463. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff342_inst, reff342_op in H. discriminate H. Qed.

Lemma reff342_not464 : ~ @Equation464 Fin4 reff342_inst.
Proof. unfold Equation464. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff342_inst, reff342_op in H. discriminate H. Qed.

Lemma reff342_not466 : ~ @Equation466 Fin4 reff342_inst.
Proof. unfold Equation466. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff342_inst, reff342_op in H. discriminate H. Qed.

Lemma reff342_not467 : ~ @Equation467 Fin4 reff342_inst.
Proof. unfold Equation467. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff342_inst, reff342_op in H. discriminate H. Qed.

Lemma reff342_not473 : ~ @Equation473 Fin4 reff342_inst.
Proof. unfold Equation473. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff342_inst, reff342_op in H. discriminate H. Qed.

Lemma reff342_not474 : ~ @Equation474 Fin4 reff342_inst.
Proof. unfold Equation474. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff342_inst, reff342_op in H. discriminate H. Qed.

Lemma reff342_not476 : ~ @Equation476 Fin4 reff342_inst.
Proof. unfold Equation476. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff342_inst, reff342_op in H. discriminate H. Qed.

Lemma reff342_not477 : ~ @Equation477 Fin4 reff342_inst.
Proof. unfold Equation477. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff342_inst, reff342_op in H. discriminate H. Qed.

Lemma reff342_not500 : ~ @Equation500 Fin4 reff342_inst.
Proof. unfold Equation500. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff342_inst, reff342_op in H. discriminate H. Qed.

Lemma reff342_not501 : ~ @Equation501 Fin4 reff342_inst.
Proof. unfold Equation501. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff342_inst, reff342_op in H. discriminate H. Qed.

Lemma reff342_not503 : ~ @Equation503 Fin4 reff342_inst.
Proof. unfold Equation503. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff342_inst, reff342_op in H. discriminate H. Qed.

Lemma reff342_not504 : ~ @Equation504 Fin4 reff342_inst.
Proof. unfold Equation504. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff342_inst, reff342_op in H. discriminate H. Qed.

Lemma reff342_not510 : ~ @Equation510 Fin4 reff342_inst.
Proof. unfold Equation510. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff342_inst, reff342_op in H. discriminate H. Qed.

Lemma reff342_not511 : ~ @Equation511 Fin4 reff342_inst.
Proof. unfold Equation511. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff342_inst, reff342_op in H. discriminate H. Qed.

Lemma reff342_not513 : ~ @Equation513 Fin4 reff342_inst.
Proof. unfold Equation513. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff342_inst, reff342_op in H. discriminate H. Qed.

Lemma reff342_not615 : ~ @Equation615 Fin4 reff342_inst.
Proof. unfold Equation615. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff342_inst, reff342_op in H. discriminate H. Qed.

Lemma reff342_not616 : ~ @Equation616 Fin4 reff342_inst.
Proof. unfold Equation616. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff342_inst, reff342_op in H. discriminate H. Qed.

Lemma reff342_not619 : ~ @Equation619 Fin4 reff342_inst.
Proof. unfold Equation619. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff342_inst, reff342_op in H. discriminate H. Qed.

Lemma reff342_not623 : ~ @Equation623 Fin4 reff342_inst.
Proof. unfold Equation623. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff342_inst, reff342_op in H. discriminate H. Qed.

Lemma reff342_not629 : ~ @Equation629 Fin4 reff342_inst.
Proof. unfold Equation629. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff342_inst, reff342_op in H. discriminate H. Qed.

Lemma reff342_not630 : ~ @Equation630 Fin4 reff342_inst.
Proof. unfold Equation630. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff342_inst, reff342_op in H. discriminate H. Qed.

Lemma reff342_not632 : ~ @Equation632 Fin4 reff342_inst.
Proof. unfold Equation632. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff342_inst, reff342_op in H. discriminate H. Qed.

Lemma reff342_not633 : ~ @Equation633 Fin4 reff342_inst.
Proof. unfold Equation633. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff342_inst, reff342_op in H. discriminate H. Qed.

Lemma reff342_not639 : ~ @Equation639 Fin4 reff342_inst.
Proof. unfold Equation639. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff342_inst, reff342_op in H. discriminate H. Qed.

Lemma reff342_not640 : ~ @Equation640 Fin4 reff342_inst.
Proof. unfold Equation640. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff342_inst, reff342_op in H. discriminate H. Qed.

Lemma reff342_not642 : ~ @Equation642 Fin4 reff342_inst.
Proof. unfold Equation642. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff342_inst, reff342_op in H. discriminate H. Qed.

Lemma reff342_not643 : ~ @Equation643 Fin4 reff342_inst.
Proof. unfold Equation643. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff342_inst, reff342_op in H. discriminate H. Qed.

Lemma reff342_not666 : ~ @Equation666 Fin4 reff342_inst.
Proof. unfold Equation666. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff342_inst, reff342_op in H. discriminate H. Qed.

Lemma reff342_not667 : ~ @Equation667 Fin4 reff342_inst.
Proof. unfold Equation667. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff342_inst, reff342_op in H. discriminate H. Qed.

Lemma reff342_not669 : ~ @Equation669 Fin4 reff342_inst.
Proof. unfold Equation669. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff342_inst, reff342_op in H. discriminate H. Qed.

Lemma reff342_not670 : ~ @Equation670 Fin4 reff342_inst.
Proof. unfold Equation670. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff342_inst, reff342_op in H. discriminate H. Qed.

Lemma reff342_not676 : ~ @Equation676 Fin4 reff342_inst.
Proof. unfold Equation676. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff342_inst, reff342_op in H. discriminate H. Qed.

Lemma reff342_not677 : ~ @Equation677 Fin4 reff342_inst.
Proof. unfold Equation677. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff342_inst, reff342_op in H. discriminate H. Qed.

Lemma reff342_not679 : ~ @Equation679 Fin4 reff342_inst.
Proof. unfold Equation679. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff342_inst, reff342_op in H. discriminate H. Qed.

Lemma reff342_not680 : ~ @Equation680 Fin4 reff342_inst.
Proof. unfold Equation680. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff342_inst, reff342_op in H. discriminate H. Qed.

Lemma reff342_not703 : ~ @Equation703 Fin4 reff342_inst.
Proof. unfold Equation703. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff342_inst, reff342_op in H. discriminate H. Qed.

Lemma reff342_not704 : ~ @Equation704 Fin4 reff342_inst.
Proof. unfold Equation704. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff342_inst, reff342_op in H. discriminate H. Qed.

Lemma reff342_not706 : ~ @Equation706 Fin4 reff342_inst.
Proof. unfold Equation706. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff342_inst, reff342_op in H. discriminate H. Qed.

Lemma reff342_not707 : ~ @Equation707 Fin4 reff342_inst.
Proof. unfold Equation707. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff342_inst, reff342_op in H. discriminate H. Qed.

Lemma reff342_not713 : ~ @Equation713 Fin4 reff342_inst.
Proof. unfold Equation713. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff342_inst, reff342_op in H. discriminate H. Qed.

Lemma reff342_not714 : ~ @Equation714 Fin4 reff342_inst.
Proof. unfold Equation714. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff342_inst, reff342_op in H. discriminate H. Qed.

Lemma reff342_not716 : ~ @Equation716 Fin4 reff342_inst.
Proof. unfold Equation716. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff342_inst, reff342_op in H. discriminate H. Qed.

Lemma reff342_not818 : ~ @Equation818 Fin4 reff342_inst.
Proof. unfold Equation818. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff342_inst, reff342_op in H. discriminate H. Qed.

Lemma reff342_not819 : ~ @Equation819 Fin4 reff342_inst.
Proof. unfold Equation819. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff342_inst, reff342_op in H. discriminate H. Qed.

Lemma reff342_not820 : ~ @Equation820 Fin4 reff342_inst.
Proof. unfold Equation820. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff342_inst, reff342_op in H. discriminate H. Qed.

Lemma reff342_not822 : ~ @Equation822 Fin4 reff342_inst.
Proof. unfold Equation822. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff342_inst, reff342_op in H. discriminate H. Qed.

Lemma reff342_not825 : ~ @Equation825 Fin4 reff342_inst.
Proof. unfold Equation825. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff342_inst, reff342_op in H. discriminate H. Qed.

Lemma reff342_not826 : ~ @Equation826 Fin4 reff342_inst.
Proof. unfold Equation826. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff342_inst, reff342_op in H. discriminate H. Qed.

Lemma reff342_not832 : ~ @Equation832 Fin4 reff342_inst.
Proof. unfold Equation832. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff342_inst, reff342_op in H. discriminate H. Qed.

Lemma reff342_not835 : ~ @Equation835 Fin4 reff342_inst.
Proof. unfold Equation835. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff342_inst, reff342_op in H. discriminate H. Qed.

Lemma reff342_not836 : ~ @Equation836 Fin4 reff342_inst.
Proof. unfold Equation836. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff342_inst, reff342_op in H. discriminate H. Qed.

Lemma reff342_not843 : ~ @Equation843 Fin4 reff342_inst.
Proof. unfold Equation843. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff342_inst, reff342_op in H. discriminate H. Qed.

Lemma reff342_not845 : ~ @Equation845 Fin4 reff342_inst.
Proof. unfold Equation845. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff342_inst, reff342_op in H. discriminate H. Qed.

Lemma reff342_not846 : ~ @Equation846 Fin4 reff342_inst.
Proof. unfold Equation846. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff342_inst, reff342_op in H. discriminate H. Qed.

Lemma reff342_not869 : ~ @Equation869 Fin4 reff342_inst.
Proof. unfold Equation869. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff342_inst, reff342_op in H. discriminate H. Qed.

Lemma reff342_not870 : ~ @Equation870 Fin4 reff342_inst.
Proof. unfold Equation870. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff342_inst, reff342_op in H. discriminate H. Qed.

Lemma reff342_not872 : ~ @Equation872 Fin4 reff342_inst.
Proof. unfold Equation872. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff342_inst, reff342_op in H. discriminate H. Qed.

Lemma reff342_not873 : ~ @Equation873 Fin4 reff342_inst.
Proof. unfold Equation873. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff342_inst, reff342_op in H. discriminate H. Qed.

Lemma reff342_not879 : ~ @Equation879 Fin4 reff342_inst.
Proof. unfold Equation879. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff342_inst, reff342_op in H. discriminate H. Qed.

Lemma reff342_not880 : ~ @Equation880 Fin4 reff342_inst.
Proof. unfold Equation880. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff342_inst, reff342_op in H. discriminate H. Qed.

Lemma reff342_not882 : ~ @Equation882 Fin4 reff342_inst.
Proof. unfold Equation882. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff342_inst, reff342_op in H. discriminate H. Qed.

Lemma reff342_not883 : ~ @Equation883 Fin4 reff342_inst.
Proof. unfold Equation883. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff342_inst, reff342_op in H. discriminate H. Qed.

Lemma reff342_not906 : ~ @Equation906 Fin4 reff342_inst.
Proof. unfold Equation906. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff342_inst, reff342_op in H. discriminate H. Qed.

Lemma reff342_not907 : ~ @Equation907 Fin4 reff342_inst.
Proof. unfold Equation907. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff342_inst, reff342_op in H. discriminate H. Qed.

Lemma reff342_not909 : ~ @Equation909 Fin4 reff342_inst.
Proof. unfold Equation909. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff342_inst, reff342_op in H. discriminate H. Qed.

Lemma reff342_not910 : ~ @Equation910 Fin4 reff342_inst.
Proof. unfold Equation910. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff342_inst, reff342_op in H. discriminate H. Qed.

Lemma reff342_not916 : ~ @Equation916 Fin4 reff342_inst.
Proof. unfold Equation916. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff342_inst, reff342_op in H. discriminate H. Qed.

Lemma reff342_not917 : ~ @Equation917 Fin4 reff342_inst.
Proof. unfold Equation917. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff342_inst, reff342_op in H. discriminate H. Qed.

Lemma reff342_not919 : ~ @Equation919 Fin4 reff342_inst.
Proof. unfold Equation919. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff342_inst, reff342_op in H. discriminate H. Qed.

Lemma reff342_not1021 : ~ @Equation1021 Fin4 reff342_inst.
Proof. unfold Equation1021. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff342_inst, reff342_op in H. discriminate H. Qed.

Lemma reff342_not1022 : ~ @Equation1022 Fin4 reff342_inst.
Proof. unfold Equation1022. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff342_inst, reff342_op in H. discriminate H. Qed.

Lemma reff342_not1025 : ~ @Equation1025 Fin4 reff342_inst.
Proof. unfold Equation1025. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff342_inst, reff342_op in H. discriminate H. Qed.

Lemma reff342_not1026 : ~ @Equation1026 Fin4 reff342_inst.
Proof. unfold Equation1026. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff342_inst, reff342_op in H. discriminate H. Qed.

Lemma reff342_not1028 : ~ @Equation1028 Fin4 reff342_inst.
Proof. unfold Equation1028. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff342_inst, reff342_op in H. discriminate H. Qed.

Lemma reff342_not1029 : ~ @Equation1029 Fin4 reff342_inst.
Proof. unfold Equation1029. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff342_inst, reff342_op in H. discriminate H. Qed.

Lemma reff342_not1035 : ~ @Equation1035 Fin4 reff342_inst.
Proof. unfold Equation1035. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff342_inst, reff342_op in H. discriminate H. Qed.

Lemma reff342_not1039 : ~ @Equation1039 Fin4 reff342_inst.
Proof. unfold Equation1039. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff342_inst, reff342_op in H. discriminate H. Qed.

Lemma reff342_not1045 : ~ @Equation1045 Fin4 reff342_inst.
Proof. unfold Equation1045. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff342_inst, reff342_op in H. discriminate H. Qed.

Lemma reff342_not1046 : ~ @Equation1046 Fin4 reff342_inst.
Proof. unfold Equation1046. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff342_inst, reff342_op in H. discriminate H. Qed.

Lemma reff342_not1048 : ~ @Equation1048 Fin4 reff342_inst.
Proof. unfold Equation1048. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff342_inst, reff342_op in H. discriminate H. Qed.

Lemma reff342_not1049 : ~ @Equation1049 Fin4 reff342_inst.
Proof. unfold Equation1049. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff342_inst, reff342_op in H. discriminate H. Qed.

Lemma reff342_not1072 : ~ @Equation1072 Fin4 reff342_inst.
Proof. unfold Equation1072. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff342_inst, reff342_op in H. discriminate H. Qed.

Lemma reff342_not1073 : ~ @Equation1073 Fin4 reff342_inst.
Proof. unfold Equation1073. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff342_inst, reff342_op in H. discriminate H. Qed.

Lemma reff342_not1075 : ~ @Equation1075 Fin4 reff342_inst.
Proof. unfold Equation1075. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff342_inst, reff342_op in H. discriminate H. Qed.

Lemma reff342_not1076 : ~ @Equation1076 Fin4 reff342_inst.
Proof. unfold Equation1076. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff342_inst, reff342_op in H. discriminate H. Qed.

Lemma reff342_not1082 : ~ @Equation1082 Fin4 reff342_inst.
Proof. unfold Equation1082. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff342_inst, reff342_op in H. discriminate H. Qed.

Lemma reff342_not1083 : ~ @Equation1083 Fin4 reff342_inst.
Proof. unfold Equation1083. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff342_inst, reff342_op in H. discriminate H. Qed.

Lemma reff342_not1085 : ~ @Equation1085 Fin4 reff342_inst.
Proof. unfold Equation1085. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff342_inst, reff342_op in H. discriminate H. Qed.

Lemma reff342_not1086 : ~ @Equation1086 Fin4 reff342_inst.
Proof. unfold Equation1086. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff342_inst, reff342_op in H. discriminate H. Qed.

Lemma reff342_not1109 : ~ @Equation1109 Fin4 reff342_inst.
Proof. unfold Equation1109. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff342_inst, reff342_op in H. discriminate H. Qed.

Lemma reff342_not1110 : ~ @Equation1110 Fin4 reff342_inst.
Proof. unfold Equation1110. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff342_inst, reff342_op in H. discriminate H. Qed.

Lemma reff342_not1112 : ~ @Equation1112 Fin4 reff342_inst.
Proof. unfold Equation1112. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff342_inst, reff342_op in H. discriminate H. Qed.

Lemma reff342_not1113 : ~ @Equation1113 Fin4 reff342_inst.
Proof. unfold Equation1113. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff342_inst, reff342_op in H. discriminate H. Qed.

Lemma reff342_not1119 : ~ @Equation1119 Fin4 reff342_inst.
Proof. unfold Equation1119. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff342_inst, reff342_op in H. discriminate H. Qed.

Lemma reff342_not1120 : ~ @Equation1120 Fin4 reff342_inst.
Proof. unfold Equation1120. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff342_inst, reff342_op in H. discriminate H. Qed.

Lemma reff342_not1122 : ~ @Equation1122 Fin4 reff342_inst.
Proof. unfold Equation1122. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff342_inst, reff342_op in H. discriminate H. Qed.

Lemma reff342_not1224 : ~ @Equation1224 Fin4 reff342_inst.
Proof. unfold Equation1224. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff342_inst, reff342_op in H. discriminate H. Qed.

Lemma reff342_not1225 : ~ @Equation1225 Fin4 reff342_inst.
Proof. unfold Equation1225. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff342_inst, reff342_op in H. discriminate H. Qed.

Lemma reff342_not1228 : ~ @Equation1228 Fin4 reff342_inst.
Proof. unfold Equation1228. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff342_inst, reff342_op in H. discriminate H. Qed.

Lemma reff342_not1232 : ~ @Equation1232 Fin4 reff342_inst.
Proof. unfold Equation1232. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff342_inst, reff342_op in H. discriminate H. Qed.

Lemma reff342_not1238 : ~ @Equation1238 Fin4 reff342_inst.
Proof. unfold Equation1238. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff342_inst, reff342_op in H. discriminate H. Qed.

Lemma reff342_not1239 : ~ @Equation1239 Fin4 reff342_inst.
Proof. unfold Equation1239. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff342_inst, reff342_op in H. discriminate H. Qed.

Lemma reff342_not1241 : ~ @Equation1241 Fin4 reff342_inst.
Proof. unfold Equation1241. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff342_inst, reff342_op in H. discriminate H. Qed.

Lemma reff342_not1242 : ~ @Equation1242 Fin4 reff342_inst.
Proof. unfold Equation1242. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff342_inst, reff342_op in H. discriminate H. Qed.

Lemma reff342_not1248 : ~ @Equation1248 Fin4 reff342_inst.
Proof. unfold Equation1248. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff342_inst, reff342_op in H. discriminate H. Qed.

Lemma reff342_not1249 : ~ @Equation1249 Fin4 reff342_inst.
Proof. unfold Equation1249. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff342_inst, reff342_op in H. discriminate H. Qed.

Lemma reff342_not1251 : ~ @Equation1251 Fin4 reff342_inst.
Proof. unfold Equation1251. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff342_inst, reff342_op in H. discriminate H. Qed.

Lemma reff342_not1252 : ~ @Equation1252 Fin4 reff342_inst.
Proof. unfold Equation1252. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff342_inst, reff342_op in H. discriminate H. Qed.

Lemma reff342_not1275 : ~ @Equation1275 Fin4 reff342_inst.
Proof. unfold Equation1275. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff342_inst, reff342_op in H. discriminate H. Qed.

Lemma reff342_not1276 : ~ @Equation1276 Fin4 reff342_inst.
Proof. unfold Equation1276. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff342_inst, reff342_op in H. discriminate H. Qed.

Lemma reff342_not1278 : ~ @Equation1278 Fin4 reff342_inst.
Proof. unfold Equation1278. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff342_inst, reff342_op in H. discriminate H. Qed.

Lemma reff342_not1279 : ~ @Equation1279 Fin4 reff342_inst.
Proof. unfold Equation1279. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff342_inst, reff342_op in H. discriminate H. Qed.

Lemma reff342_not1285 : ~ @Equation1285 Fin4 reff342_inst.
Proof. unfold Equation1285. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff342_inst, reff342_op in H. discriminate H. Qed.

Lemma reff342_not1286 : ~ @Equation1286 Fin4 reff342_inst.
Proof. unfold Equation1286. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff342_inst, reff342_op in H. discriminate H. Qed.

Lemma reff342_not1288 : ~ @Equation1288 Fin4 reff342_inst.
Proof. unfold Equation1288. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff342_inst, reff342_op in H. discriminate H. Qed.

Lemma reff342_not1289 : ~ @Equation1289 Fin4 reff342_inst.
Proof. unfold Equation1289. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff342_inst, reff342_op in H. discriminate H. Qed.

Lemma reff342_not1312 : ~ @Equation1312 Fin4 reff342_inst.
Proof. unfold Equation1312. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff342_inst, reff342_op in H. discriminate H. Qed.

Lemma reff342_not1313 : ~ @Equation1313 Fin4 reff342_inst.
Proof. unfold Equation1313. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff342_inst, reff342_op in H. discriminate H. Qed.

Lemma reff342_not1315 : ~ @Equation1315 Fin4 reff342_inst.
Proof. unfold Equation1315. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff342_inst, reff342_op in H. discriminate H. Qed.

Lemma reff342_not1316 : ~ @Equation1316 Fin4 reff342_inst.
Proof. unfold Equation1316. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff342_inst, reff342_op in H. discriminate H. Qed.

Lemma reff342_not1322 : ~ @Equation1322 Fin4 reff342_inst.
Proof. unfold Equation1322. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff342_inst, reff342_op in H. discriminate H. Qed.

Lemma reff342_not1323 : ~ @Equation1323 Fin4 reff342_inst.
Proof. unfold Equation1323. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff342_inst, reff342_op in H. discriminate H. Qed.

Lemma reff342_not1325 : ~ @Equation1325 Fin4 reff342_inst.
Proof. unfold Equation1325. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff342_inst, reff342_op in H. discriminate H. Qed.

Lemma reff342_not1427 : ~ @Equation1427 Fin4 reff342_inst.
Proof. unfold Equation1427. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff342_inst, reff342_op in H. discriminate H. Qed.

Lemma reff342_not1428 : ~ @Equation1428 Fin4 reff342_inst.
Proof. unfold Equation1428. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff342_inst, reff342_op in H. discriminate H. Qed.

Lemma reff342_not1429 : ~ @Equation1429 Fin4 reff342_inst.
Proof. unfold Equation1429. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff342_inst, reff342_op in H. discriminate H. Qed.

Lemma reff342_not1431 : ~ @Equation1431 Fin4 reff342_inst.
Proof. unfold Equation1431. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff342_inst, reff342_op in H. discriminate H. Qed.

Lemma reff342_not1432 : ~ @Equation1432 Fin4 reff342_inst.
Proof. unfold Equation1432. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff342_inst, reff342_op in H. discriminate H. Qed.

Lemma reff342_not1435 : ~ @Equation1435 Fin4 reff342_inst.
Proof. unfold Equation1435. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff342_inst, reff342_op in H. discriminate H. Qed.

Lemma reff342_not1441 : ~ @Equation1441 Fin4 reff342_inst.
Proof. unfold Equation1441. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff342_inst, reff342_op in H. discriminate H. Qed.

Lemma reff342_not1444 : ~ @Equation1444 Fin4 reff342_inst.
Proof. unfold Equation1444. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff342_inst, reff342_op in H. discriminate H. Qed.

Lemma reff342_not1445 : ~ @Equation1445 Fin4 reff342_inst.
Proof. unfold Equation1445. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff342_inst, reff342_op in H. discriminate H. Qed.

Lemma reff342_not1451 : ~ @Equation1451 Fin4 reff342_inst.
Proof. unfold Equation1451. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff342_inst, reff342_op in H. discriminate H. Qed.

Lemma reff342_not1452 : ~ @Equation1452 Fin4 reff342_inst.
Proof. unfold Equation1452. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff342_inst, reff342_op in H. discriminate H. Qed.

Lemma reff342_not1454 : ~ @Equation1454 Fin4 reff342_inst.
Proof. unfold Equation1454. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff342_inst, reff342_op in H. discriminate H. Qed.

Lemma reff342_not1478 : ~ @Equation1478 Fin4 reff342_inst.
Proof. unfold Equation1478. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff342_inst, reff342_op in H. discriminate H. Qed.

Lemma reff342_not1479 : ~ @Equation1479 Fin4 reff342_inst.
Proof. unfold Equation1479. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff342_inst, reff342_op in H. discriminate H. Qed.

Lemma reff342_not1481 : ~ @Equation1481 Fin4 reff342_inst.
Proof. unfold Equation1481. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff342_inst, reff342_op in H. discriminate H. Qed.

Lemma reff342_not1482 : ~ @Equation1482 Fin4 reff342_inst.
Proof. unfold Equation1482. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff342_inst, reff342_op in H. discriminate H. Qed.

Lemma reff342_not1488 : ~ @Equation1488 Fin4 reff342_inst.
Proof. unfold Equation1488. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff342_inst, reff342_op in H. discriminate H. Qed.

Lemma reff342_not1489 : ~ @Equation1489 Fin4 reff342_inst.
Proof. unfold Equation1489. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff342_inst, reff342_op in H. discriminate H. Qed.

Lemma reff342_not1491 : ~ @Equation1491 Fin4 reff342_inst.
Proof. unfold Equation1491. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff342_inst, reff342_op in H. discriminate H. Qed.

Lemma reff342_not1492 : ~ @Equation1492 Fin4 reff342_inst.
Proof. unfold Equation1492. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff342_inst, reff342_op in H. discriminate H. Qed.

Lemma reff342_not1515 : ~ @Equation1515 Fin4 reff342_inst.
Proof. unfold Equation1515. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff342_inst, reff342_op in H. discriminate H. Qed.

Lemma reff342_not1516 : ~ @Equation1516 Fin4 reff342_inst.
Proof. unfold Equation1516. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff342_inst, reff342_op in H. discriminate H. Qed.

Lemma reff342_not1518 : ~ @Equation1518 Fin4 reff342_inst.
Proof. unfold Equation1518. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff342_inst, reff342_op in H. discriminate H. Qed.

Lemma reff342_not1519 : ~ @Equation1519 Fin4 reff342_inst.
Proof. unfold Equation1519. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff342_inst, reff342_op in H. discriminate H. Qed.

Lemma reff342_not1525 : ~ @Equation1525 Fin4 reff342_inst.
Proof. unfold Equation1525. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff342_inst, reff342_op in H. discriminate H. Qed.

Lemma reff342_not1526 : ~ @Equation1526 Fin4 reff342_inst.
Proof. unfold Equation1526. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff342_inst, reff342_op in H. discriminate H. Qed.

Lemma reff342_not1528 : ~ @Equation1528 Fin4 reff342_inst.
Proof. unfold Equation1528. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff342_inst, reff342_op in H. discriminate H. Qed.

Lemma reff342_not1630 : ~ @Equation1630 Fin4 reff342_inst.
Proof. unfold Equation1630. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff342_inst, reff342_op in H. discriminate H. Qed.

Lemma reff342_not1631 : ~ @Equation1631 Fin4 reff342_inst.
Proof. unfold Equation1631. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff342_inst, reff342_op in H. discriminate H. Qed.

Lemma reff342_not1634 : ~ @Equation1634 Fin4 reff342_inst.
Proof. unfold Equation1634. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff342_inst, reff342_op in H. discriminate H. Qed.

Lemma reff342_not1638 : ~ @Equation1638 Fin4 reff342_inst.
Proof. unfold Equation1638. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff342_inst, reff342_op in H. discriminate H. Qed.

Lemma reff342_not1644 : ~ @Equation1644 Fin4 reff342_inst.
Proof. unfold Equation1644. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff342_inst, reff342_op in H. discriminate H. Qed.

Lemma reff342_not1648 : ~ @Equation1648 Fin4 reff342_inst.
Proof. unfold Equation1648. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff342_inst, reff342_op in H. discriminate H. Qed.

Lemma reff342_not1655 : ~ @Equation1655 Fin4 reff342_inst.
Proof. unfold Equation1655. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff342_inst, reff342_op in H. discriminate H. Qed.

Lemma reff342_not1657 : ~ @Equation1657 Fin4 reff342_inst.
Proof. unfold Equation1657. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff342_inst, reff342_op in H. discriminate H. Qed.

Lemma reff342_not1681 : ~ @Equation1681 Fin4 reff342_inst.
Proof. unfold Equation1681. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff342_inst, reff342_op in H. discriminate H. Qed.

Lemma reff342_not1682 : ~ @Equation1682 Fin4 reff342_inst.
Proof. unfold Equation1682. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff342_inst, reff342_op in H. discriminate H. Qed.

Lemma reff342_not1684 : ~ @Equation1684 Fin4 reff342_inst.
Proof. unfold Equation1684. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff342_inst, reff342_op in H. discriminate H. Qed.

Lemma reff342_not1685 : ~ @Equation1685 Fin4 reff342_inst.
Proof. unfold Equation1685. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff342_inst, reff342_op in H. discriminate H. Qed.

Lemma reff342_not1691 : ~ @Equation1691 Fin4 reff342_inst.
Proof. unfold Equation1691. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff342_inst, reff342_op in H. discriminate H. Qed.

Lemma reff342_not1692 : ~ @Equation1692 Fin4 reff342_inst.
Proof. unfold Equation1692. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff342_inst, reff342_op in H. discriminate H. Qed.

Lemma reff342_not1694 : ~ @Equation1694 Fin4 reff342_inst.
Proof. unfold Equation1694. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff342_inst, reff342_op in H. discriminate H. Qed.

Lemma reff342_not1695 : ~ @Equation1695 Fin4 reff342_inst.
Proof. unfold Equation1695. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff342_inst, reff342_op in H. discriminate H. Qed.

Lemma reff342_not1718 : ~ @Equation1718 Fin4 reff342_inst.
Proof. unfold Equation1718. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff342_inst, reff342_op in H. discriminate H. Qed.

Lemma reff342_not1719 : ~ @Equation1719 Fin4 reff342_inst.
Proof. unfold Equation1719. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff342_inst, reff342_op in H. discriminate H. Qed.

Lemma reff342_not1721 : ~ @Equation1721 Fin4 reff342_inst.
Proof. unfold Equation1721. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff342_inst, reff342_op in H. discriminate H. Qed.

Lemma reff342_not1722 : ~ @Equation1722 Fin4 reff342_inst.
Proof. unfold Equation1722. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff342_inst, reff342_op in H. discriminate H. Qed.

Lemma reff342_not1728 : ~ @Equation1728 Fin4 reff342_inst.
Proof. unfold Equation1728. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff342_inst, reff342_op in H. discriminate H. Qed.

Lemma reff342_not1729 : ~ @Equation1729 Fin4 reff342_inst.
Proof. unfold Equation1729. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff342_inst, reff342_op in H. discriminate H. Qed.

Lemma reff342_not1731 : ~ @Equation1731 Fin4 reff342_inst.
Proof. unfold Equation1731. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff342_inst, reff342_op in H. discriminate H. Qed.

Lemma reff342_not1833 : ~ @Equation1833 Fin4 reff342_inst.
Proof. unfold Equation1833. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff342_inst, reff342_op in H. discriminate H. Qed.

Lemma reff342_not1834 : ~ @Equation1834 Fin4 reff342_inst.
Proof. unfold Equation1834. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff342_inst, reff342_op in H. discriminate H. Qed.

Lemma reff342_not1835 : ~ @Equation1835 Fin4 reff342_inst.
Proof. unfold Equation1835. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff342_inst, reff342_op in H. discriminate H. Qed.

Lemma reff342_not1837 : ~ @Equation1837 Fin4 reff342_inst.
Proof. unfold Equation1837. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff342_inst, reff342_op in H. discriminate H. Qed.

Lemma reff342_not1840 : ~ @Equation1840 Fin4 reff342_inst.
Proof. unfold Equation1840. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff342_inst, reff342_op in H. discriminate H. Qed.

Lemma reff342_not1841 : ~ @Equation1841 Fin4 reff342_inst.
Proof. unfold Equation1841. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff342_inst, reff342_op in H. discriminate H. Qed.

Lemma reff342_not1847 : ~ @Equation1847 Fin4 reff342_inst.
Proof. unfold Equation1847. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff342_inst, reff342_op in H. discriminate H. Qed.

Lemma reff342_not1848 : ~ @Equation1848 Fin4 reff342_inst.
Proof. unfold Equation1848. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff342_inst, reff342_op in H. discriminate H. Qed.

Lemma reff342_not1851 : ~ @Equation1851 Fin4 reff342_inst.
Proof. unfold Equation1851. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff342_inst, reff342_op in H. discriminate H. Qed.

Lemma reff342_not1857 : ~ @Equation1857 Fin4 reff342_inst.
Proof. unfold Equation1857. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff342_inst, reff342_op in H. discriminate H. Qed.

Lemma reff342_not1858 : ~ @Equation1858 Fin4 reff342_inst.
Proof. unfold Equation1858. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff342_inst, reff342_op in H. discriminate H. Qed.

Lemma reff342_not1860 : ~ @Equation1860 Fin4 reff342_inst.
Proof. unfold Equation1860. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff342_inst, reff342_op in H. discriminate H. Qed.

Lemma reff342_not1884 : ~ @Equation1884 Fin4 reff342_inst.
Proof. unfold Equation1884. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff342_inst, reff342_op in H. discriminate H. Qed.

Lemma reff342_not1885 : ~ @Equation1885 Fin4 reff342_inst.
Proof. unfold Equation1885. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff342_inst, reff342_op in H. discriminate H. Qed.

Lemma reff342_not1887 : ~ @Equation1887 Fin4 reff342_inst.
Proof. unfold Equation1887. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff342_inst, reff342_op in H. discriminate H. Qed.

Lemma reff342_not1888 : ~ @Equation1888 Fin4 reff342_inst.
Proof. unfold Equation1888. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff342_inst, reff342_op in H. discriminate H. Qed.

Lemma reff342_not1894 : ~ @Equation1894 Fin4 reff342_inst.
Proof. unfold Equation1894. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff342_inst, reff342_op in H. discriminate H. Qed.

Lemma reff342_not1895 : ~ @Equation1895 Fin4 reff342_inst.
Proof. unfold Equation1895. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff342_inst, reff342_op in H. discriminate H. Qed.

Lemma reff342_not1897 : ~ @Equation1897 Fin4 reff342_inst.
Proof. unfold Equation1897. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff342_inst, reff342_op in H. discriminate H. Qed.

Lemma reff342_not1898 : ~ @Equation1898 Fin4 reff342_inst.
Proof. unfold Equation1898. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff342_inst, reff342_op in H. discriminate H. Qed.

Lemma reff342_not1921 : ~ @Equation1921 Fin4 reff342_inst.
Proof. unfold Equation1921. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff342_inst, reff342_op in H. discriminate H. Qed.

Lemma reff342_not1922 : ~ @Equation1922 Fin4 reff342_inst.
Proof. unfold Equation1922. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff342_inst, reff342_op in H. discriminate H. Qed.

Lemma reff342_not1924 : ~ @Equation1924 Fin4 reff342_inst.
Proof. unfold Equation1924. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff342_inst, reff342_op in H. discriminate H. Qed.

Lemma reff342_not1925 : ~ @Equation1925 Fin4 reff342_inst.
Proof. unfold Equation1925. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff342_inst, reff342_op in H. discriminate H. Qed.

Lemma reff342_not1931 : ~ @Equation1931 Fin4 reff342_inst.
Proof. unfold Equation1931. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff342_inst, reff342_op in H. discriminate H. Qed.

Lemma reff342_not1932 : ~ @Equation1932 Fin4 reff342_inst.
Proof. unfold Equation1932. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff342_inst, reff342_op in H. discriminate H. Qed.

Lemma reff342_not1934 : ~ @Equation1934 Fin4 reff342_inst.
Proof. unfold Equation1934. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff342_inst, reff342_op in H. discriminate H. Qed.

Lemma reff342_not2036 : ~ @Equation2036 Fin4 reff342_inst.
Proof. unfold Equation2036. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff342_inst, reff342_op in H. discriminate H. Qed.

Lemma reff342_not2037 : ~ @Equation2037 Fin4 reff342_inst.
Proof. unfold Equation2037. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff342_inst, reff342_op in H. discriminate H. Qed.

Lemma reff342_not2038 : ~ @Equation2038 Fin4 reff342_inst.
Proof. unfold Equation2038. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff342_inst, reff342_op in H. discriminate H. Qed.

Lemma reff342_not2040 : ~ @Equation2040 Fin4 reff342_inst.
Proof. unfold Equation2040. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff342_inst, reff342_op in H. discriminate H. Qed.

Lemma reff342_not2043 : ~ @Equation2043 Fin4 reff342_inst.
Proof. unfold Equation2043. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff342_inst, reff342_op in H. discriminate H. Qed.

Lemma reff342_not2044 : ~ @Equation2044 Fin4 reff342_inst.
Proof. unfold Equation2044. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff342_inst, reff342_op in H. discriminate H. Qed.

Lemma reff342_not2050 : ~ @Equation2050 Fin4 reff342_inst.
Proof. unfold Equation2050. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff342_inst, reff342_op in H. discriminate H. Qed.

Lemma reff342_not2053 : ~ @Equation2053 Fin4 reff342_inst.
Proof. unfold Equation2053. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff342_inst, reff342_op in H. discriminate H. Qed.

Lemma reff342_not2054 : ~ @Equation2054 Fin4 reff342_inst.
Proof. unfold Equation2054. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff342_inst, reff342_op in H. discriminate H. Qed.

Lemma reff342_not2061 : ~ @Equation2061 Fin4 reff342_inst.
Proof. unfold Equation2061. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff342_inst, reff342_op in H. discriminate H. Qed.

Lemma reff342_not2063 : ~ @Equation2063 Fin4 reff342_inst.
Proof. unfold Equation2063. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff342_inst, reff342_op in H. discriminate H. Qed.

Lemma reff342_not2064 : ~ @Equation2064 Fin4 reff342_inst.
Proof. unfold Equation2064. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff342_inst, reff342_op in H. discriminate H. Qed.

Lemma reff342_not2087 : ~ @Equation2087 Fin4 reff342_inst.
Proof. unfold Equation2087. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff342_inst, reff342_op in H. discriminate H. Qed.

Lemma reff342_not2088 : ~ @Equation2088 Fin4 reff342_inst.
Proof. unfold Equation2088. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff342_inst, reff342_op in H. discriminate H. Qed.

Lemma reff342_not2090 : ~ @Equation2090 Fin4 reff342_inst.
Proof. unfold Equation2090. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff342_inst, reff342_op in H. discriminate H. Qed.

Lemma reff342_not2091 : ~ @Equation2091 Fin4 reff342_inst.
Proof. unfold Equation2091. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff342_inst, reff342_op in H. discriminate H. Qed.

Lemma reff342_not2097 : ~ @Equation2097 Fin4 reff342_inst.
Proof. unfold Equation2097. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff342_inst, reff342_op in H. discriminate H. Qed.

Lemma reff342_not2098 : ~ @Equation2098 Fin4 reff342_inst.
Proof. unfold Equation2098. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff342_inst, reff342_op in H. discriminate H. Qed.

Lemma reff342_not2100 : ~ @Equation2100 Fin4 reff342_inst.
Proof. unfold Equation2100. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff342_inst, reff342_op in H. discriminate H. Qed.

Lemma reff342_not2101 : ~ @Equation2101 Fin4 reff342_inst.
Proof. unfold Equation2101. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff342_inst, reff342_op in H. discriminate H. Qed.

Lemma reff342_not2124 : ~ @Equation2124 Fin4 reff342_inst.
Proof. unfold Equation2124. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff342_inst, reff342_op in H. discriminate H. Qed.

Lemma reff342_not2125 : ~ @Equation2125 Fin4 reff342_inst.
Proof. unfold Equation2125. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff342_inst, reff342_op in H. discriminate H. Qed.

Lemma reff342_not2127 : ~ @Equation2127 Fin4 reff342_inst.
Proof. unfold Equation2127. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff342_inst, reff342_op in H. discriminate H. Qed.

Lemma reff342_not2128 : ~ @Equation2128 Fin4 reff342_inst.
Proof. unfold Equation2128. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff342_inst, reff342_op in H. discriminate H. Qed.

Lemma reff342_not2134 : ~ @Equation2134 Fin4 reff342_inst.
Proof. unfold Equation2134. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff342_inst, reff342_op in H. discriminate H. Qed.

Lemma reff342_not2135 : ~ @Equation2135 Fin4 reff342_inst.
Proof. unfold Equation2135. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff342_inst, reff342_op in H. discriminate H. Qed.

Lemma reff342_not2137 : ~ @Equation2137 Fin4 reff342_inst.
Proof. unfold Equation2137. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff342_inst, reff342_op in H. discriminate H. Qed.

Lemma reff342_not2239 : ~ @Equation2239 Fin4 reff342_inst.
Proof. unfold Equation2239. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff342_inst, reff342_op in H. discriminate H. Qed.

Lemma reff342_not2240 : ~ @Equation2240 Fin4 reff342_inst.
Proof. unfold Equation2240. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff342_inst, reff342_op in H. discriminate H. Qed.

Lemma reff342_not2243 : ~ @Equation2243 Fin4 reff342_inst.
Proof. unfold Equation2243. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff342_inst, reff342_op in H. discriminate H. Qed.

Lemma reff342_not2244 : ~ @Equation2244 Fin4 reff342_inst.
Proof. unfold Equation2244. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff342_inst, reff342_op in H. discriminate H. Qed.

Lemma reff342_not2246 : ~ @Equation2246 Fin4 reff342_inst.
Proof. unfold Equation2246. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff342_inst, reff342_op in H. discriminate H. Qed.

Lemma reff342_not2247 : ~ @Equation2247 Fin4 reff342_inst.
Proof. unfold Equation2247. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff342_inst, reff342_op in H. discriminate H. Qed.

Lemma reff342_not2253 : ~ @Equation2253 Fin4 reff342_inst.
Proof. unfold Equation2253. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff342_inst, reff342_op in H. discriminate H. Qed.

Lemma reff342_not2254 : ~ @Equation2254 Fin4 reff342_inst.
Proof. unfold Equation2254. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff342_inst, reff342_op in H. discriminate H. Qed.

Lemma reff342_not2256 : ~ @Equation2256 Fin4 reff342_inst.
Proof. unfold Equation2256. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff342_inst, reff342_op in H. discriminate H. Qed.

Lemma reff342_not2257 : ~ @Equation2257 Fin4 reff342_inst.
Proof. unfold Equation2257. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff342_inst, reff342_op in H. discriminate H. Qed.

Lemma reff342_not2264 : ~ @Equation2264 Fin4 reff342_inst.
Proof. unfold Equation2264. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff342_inst, reff342_op in H. discriminate H. Qed.

Lemma reff342_not2266 : ~ @Equation2266 Fin4 reff342_inst.
Proof. unfold Equation2266. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff342_inst, reff342_op in H. discriminate H. Qed.

Lemma reff342_not2290 : ~ @Equation2290 Fin4 reff342_inst.
Proof. unfold Equation2290. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff342_inst, reff342_op in H. discriminate H. Qed.

Lemma reff342_not2291 : ~ @Equation2291 Fin4 reff342_inst.
Proof. unfold Equation2291. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff342_inst, reff342_op in H. discriminate H. Qed.

Lemma reff342_not2293 : ~ @Equation2293 Fin4 reff342_inst.
Proof. unfold Equation2293. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff342_inst, reff342_op in H. discriminate H. Qed.

Lemma reff342_not2294 : ~ @Equation2294 Fin4 reff342_inst.
Proof. unfold Equation2294. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff342_inst, reff342_op in H. discriminate H. Qed.

Lemma reff342_not2300 : ~ @Equation2300 Fin4 reff342_inst.
Proof. unfold Equation2300. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff342_inst, reff342_op in H. discriminate H. Qed.

Lemma reff342_not2301 : ~ @Equation2301 Fin4 reff342_inst.
Proof. unfold Equation2301. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff342_inst, reff342_op in H. discriminate H. Qed.

Lemma reff342_not2303 : ~ @Equation2303 Fin4 reff342_inst.
Proof. unfold Equation2303. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff342_inst, reff342_op in H. discriminate H. Qed.

Lemma reff342_not2304 : ~ @Equation2304 Fin4 reff342_inst.
Proof. unfold Equation2304. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff342_inst, reff342_op in H. discriminate H. Qed.

Lemma reff342_not2327 : ~ @Equation2327 Fin4 reff342_inst.
Proof. unfold Equation2327. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff342_inst, reff342_op in H. discriminate H. Qed.

Lemma reff342_not2328 : ~ @Equation2328 Fin4 reff342_inst.
Proof. unfold Equation2328. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff342_inst, reff342_op in H. discriminate H. Qed.

Lemma reff342_not2330 : ~ @Equation2330 Fin4 reff342_inst.
Proof. unfold Equation2330. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff342_inst, reff342_op in H. discriminate H. Qed.

Lemma reff342_not2331 : ~ @Equation2331 Fin4 reff342_inst.
Proof. unfold Equation2331. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff342_inst, reff342_op in H. discriminate H. Qed.

Lemma reff342_not2337 : ~ @Equation2337 Fin4 reff342_inst.
Proof. unfold Equation2337. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff342_inst, reff342_op in H. discriminate H. Qed.

Lemma reff342_not2338 : ~ @Equation2338 Fin4 reff342_inst.
Proof. unfold Equation2338. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff342_inst, reff342_op in H. discriminate H. Qed.

Lemma reff342_not2340 : ~ @Equation2340 Fin4 reff342_inst.
Proof. unfold Equation2340. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff342_inst, reff342_op in H. discriminate H. Qed.

Lemma reff342_not2442 : ~ @Equation2442 Fin4 reff342_inst.
Proof. unfold Equation2442. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff342_inst, reff342_op in H. discriminate H. Qed.

Lemma reff342_not2443 : ~ @Equation2443 Fin4 reff342_inst.
Proof. unfold Equation2443. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff342_inst, reff342_op in H. discriminate H. Qed.

Lemma reff342_not2446 : ~ @Equation2446 Fin4 reff342_inst.
Proof. unfold Equation2446. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff342_inst, reff342_op in H. discriminate H. Qed.

Lemma reff342_not2450 : ~ @Equation2450 Fin4 reff342_inst.
Proof. unfold Equation2450. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff342_inst, reff342_op in H. discriminate H. Qed.

Lemma reff342_not2456 : ~ @Equation2456 Fin4 reff342_inst.
Proof. unfold Equation2456. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff342_inst, reff342_op in H. discriminate H. Qed.

Lemma reff342_not2460 : ~ @Equation2460 Fin4 reff342_inst.
Proof. unfold Equation2460. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff342_inst, reff342_op in H. discriminate H. Qed.

Lemma reff342_not2467 : ~ @Equation2467 Fin4 reff342_inst.
Proof. unfold Equation2467. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff342_inst, reff342_op in H. discriminate H. Qed.

Lemma reff342_not2469 : ~ @Equation2469 Fin4 reff342_inst.
Proof. unfold Equation2469. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff342_inst, reff342_op in H. discriminate H. Qed.

Lemma reff342_not2493 : ~ @Equation2493 Fin4 reff342_inst.
Proof. unfold Equation2493. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff342_inst, reff342_op in H. discriminate H. Qed.

Lemma reff342_not2494 : ~ @Equation2494 Fin4 reff342_inst.
Proof. unfold Equation2494. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff342_inst, reff342_op in H. discriminate H. Qed.

Lemma reff342_not2496 : ~ @Equation2496 Fin4 reff342_inst.
Proof. unfold Equation2496. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff342_inst, reff342_op in H. discriminate H. Qed.

Lemma reff342_not2497 : ~ @Equation2497 Fin4 reff342_inst.
Proof. unfold Equation2497. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff342_inst, reff342_op in H. discriminate H. Qed.

Lemma reff342_not2503 : ~ @Equation2503 Fin4 reff342_inst.
Proof. unfold Equation2503. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff342_inst, reff342_op in H. discriminate H. Qed.

Lemma reff342_not2504 : ~ @Equation2504 Fin4 reff342_inst.
Proof. unfold Equation2504. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff342_inst, reff342_op in H. discriminate H. Qed.

Lemma reff342_not2506 : ~ @Equation2506 Fin4 reff342_inst.
Proof. unfold Equation2506. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff342_inst, reff342_op in H. discriminate H. Qed.

Lemma reff342_not2507 : ~ @Equation2507 Fin4 reff342_inst.
Proof. unfold Equation2507. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff342_inst, reff342_op in H. discriminate H. Qed.

Lemma reff342_not2530 : ~ @Equation2530 Fin4 reff342_inst.
Proof. unfold Equation2530. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff342_inst, reff342_op in H. discriminate H. Qed.

Lemma reff342_not2531 : ~ @Equation2531 Fin4 reff342_inst.
Proof. unfold Equation2531. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff342_inst, reff342_op in H. discriminate H. Qed.

Lemma reff342_not2533 : ~ @Equation2533 Fin4 reff342_inst.
Proof. unfold Equation2533. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff342_inst, reff342_op in H. discriminate H. Qed.

Lemma reff342_not2534 : ~ @Equation2534 Fin4 reff342_inst.
Proof. unfold Equation2534. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff342_inst, reff342_op in H. discriminate H. Qed.

Lemma reff342_not2540 : ~ @Equation2540 Fin4 reff342_inst.
Proof. unfold Equation2540. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff342_inst, reff342_op in H. discriminate H. Qed.

Lemma reff342_not2541 : ~ @Equation2541 Fin4 reff342_inst.
Proof. unfold Equation2541. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff342_inst, reff342_op in H. discriminate H. Qed.

Lemma reff342_not2543 : ~ @Equation2543 Fin4 reff342_inst.
Proof. unfold Equation2543. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff342_inst, reff342_op in H. discriminate H. Qed.

Lemma reff342_not2645 : ~ @Equation2645 Fin4 reff342_inst.
Proof. unfold Equation2645. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff342_inst, reff342_op in H. discriminate H. Qed.

Lemma reff342_not2646 : ~ @Equation2646 Fin4 reff342_inst.
Proof. unfold Equation2646. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff342_inst, reff342_op in H. discriminate H. Qed.

Lemma reff342_not2649 : ~ @Equation2649 Fin4 reff342_inst.
Proof. unfold Equation2649. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff342_inst, reff342_op in H. discriminate H. Qed.

Lemma reff342_not2650 : ~ @Equation2650 Fin4 reff342_inst.
Proof. unfold Equation2650. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff342_inst, reff342_op in H. discriminate H. Qed.

Lemma reff342_not2652 : ~ @Equation2652 Fin4 reff342_inst.
Proof. unfold Equation2652. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff342_inst, reff342_op in H. discriminate H. Qed.

Lemma reff342_not2653 : ~ @Equation2653 Fin4 reff342_inst.
Proof. unfold Equation2653. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff342_inst, reff342_op in H. discriminate H. Qed.

Lemma reff342_not2659 : ~ @Equation2659 Fin4 reff342_inst.
Proof. unfold Equation2659. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff342_inst, reff342_op in H. discriminate H. Qed.

Lemma reff342_not2663 : ~ @Equation2663 Fin4 reff342_inst.
Proof. unfold Equation2663. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff342_inst, reff342_op in H. discriminate H. Qed.

Lemma reff342_not2669 : ~ @Equation2669 Fin4 reff342_inst.
Proof. unfold Equation2669. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff342_inst, reff342_op in H. discriminate H. Qed.

Lemma reff342_not2670 : ~ @Equation2670 Fin4 reff342_inst.
Proof. unfold Equation2670. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff342_inst, reff342_op in H. discriminate H. Qed.

Lemma reff342_not2672 : ~ @Equation2672 Fin4 reff342_inst.
Proof. unfold Equation2672. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff342_inst, reff342_op in H. discriminate H. Qed.

Lemma reff342_not2673 : ~ @Equation2673 Fin4 reff342_inst.
Proof. unfold Equation2673. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff342_inst, reff342_op in H. discriminate H. Qed.

Lemma reff342_not2696 : ~ @Equation2696 Fin4 reff342_inst.
Proof. unfold Equation2696. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff342_inst, reff342_op in H. discriminate H. Qed.

Lemma reff342_not2697 : ~ @Equation2697 Fin4 reff342_inst.
Proof. unfold Equation2697. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff342_inst, reff342_op in H. discriminate H. Qed.

Lemma reff342_not2699 : ~ @Equation2699 Fin4 reff342_inst.
Proof. unfold Equation2699. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff342_inst, reff342_op in H. discriminate H. Qed.

Lemma reff342_not2700 : ~ @Equation2700 Fin4 reff342_inst.
Proof. unfold Equation2700. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff342_inst, reff342_op in H. discriminate H. Qed.

Lemma reff342_not2706 : ~ @Equation2706 Fin4 reff342_inst.
Proof. unfold Equation2706. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff342_inst, reff342_op in H. discriminate H. Qed.

Lemma reff342_not2707 : ~ @Equation2707 Fin4 reff342_inst.
Proof. unfold Equation2707. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff342_inst, reff342_op in H. discriminate H. Qed.

Lemma reff342_not2709 : ~ @Equation2709 Fin4 reff342_inst.
Proof. unfold Equation2709. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff342_inst, reff342_op in H. discriminate H. Qed.

Lemma reff342_not2710 : ~ @Equation2710 Fin4 reff342_inst.
Proof. unfold Equation2710. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff342_inst, reff342_op in H. discriminate H. Qed.

Lemma reff342_not2733 : ~ @Equation2733 Fin4 reff342_inst.
Proof. unfold Equation2733. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff342_inst, reff342_op in H. discriminate H. Qed.

Lemma reff342_not2734 : ~ @Equation2734 Fin4 reff342_inst.
Proof. unfold Equation2734. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff342_inst, reff342_op in H. discriminate H. Qed.

Lemma reff342_not2736 : ~ @Equation2736 Fin4 reff342_inst.
Proof. unfold Equation2736. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff342_inst, reff342_op in H. discriminate H. Qed.

Lemma reff342_not2737 : ~ @Equation2737 Fin4 reff342_inst.
Proof. unfold Equation2737. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff342_inst, reff342_op in H. discriminate H. Qed.

Lemma reff342_not2743 : ~ @Equation2743 Fin4 reff342_inst.
Proof. unfold Equation2743. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff342_inst, reff342_op in H. discriminate H. Qed.

Lemma reff342_not2744 : ~ @Equation2744 Fin4 reff342_inst.
Proof. unfold Equation2744. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff342_inst, reff342_op in H. discriminate H. Qed.

Lemma reff342_not2746 : ~ @Equation2746 Fin4 reff342_inst.
Proof. unfold Equation2746. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff342_inst, reff342_op in H. discriminate H. Qed.

Lemma reff342_not2848 : ~ @Equation2848 Fin4 reff342_inst.
Proof. unfold Equation2848. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff342_inst, reff342_op in H. discriminate H. Qed.

Lemma reff342_not2849 : ~ @Equation2849 Fin4 reff342_inst.
Proof. unfold Equation2849. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff342_inst, reff342_op in H. discriminate H. Qed.

Lemma reff342_not2852 : ~ @Equation2852 Fin4 reff342_inst.
Proof. unfold Equation2852. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff342_inst, reff342_op in H. discriminate H. Qed.

Lemma reff342_not2856 : ~ @Equation2856 Fin4 reff342_inst.
Proof. unfold Equation2856. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff342_inst, reff342_op in H. discriminate H. Qed.

Lemma reff342_not2862 : ~ @Equation2862 Fin4 reff342_inst.
Proof. unfold Equation2862. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff342_inst, reff342_op in H. discriminate H. Qed.

Lemma reff342_not2863 : ~ @Equation2863 Fin4 reff342_inst.
Proof. unfold Equation2863. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff342_inst, reff342_op in H. discriminate H. Qed.

Lemma reff342_not2865 : ~ @Equation2865 Fin4 reff342_inst.
Proof. unfold Equation2865. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff342_inst, reff342_op in H. discriminate H. Qed.

Lemma reff342_not2866 : ~ @Equation2866 Fin4 reff342_inst.
Proof. unfold Equation2866. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff342_inst, reff342_op in H. discriminate H. Qed.

Lemma reff342_not2872 : ~ @Equation2872 Fin4 reff342_inst.
Proof. unfold Equation2872. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff342_inst, reff342_op in H. discriminate H. Qed.

Lemma reff342_not2873 : ~ @Equation2873 Fin4 reff342_inst.
Proof. unfold Equation2873. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff342_inst, reff342_op in H. discriminate H. Qed.

Lemma reff342_not2875 : ~ @Equation2875 Fin4 reff342_inst.
Proof. unfold Equation2875. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff342_inst, reff342_op in H. discriminate H. Qed.

Lemma reff342_not2876 : ~ @Equation2876 Fin4 reff342_inst.
Proof. unfold Equation2876. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff342_inst, reff342_op in H. discriminate H. Qed.

Lemma reff342_not2899 : ~ @Equation2899 Fin4 reff342_inst.
Proof. unfold Equation2899. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff342_inst, reff342_op in H. discriminate H. Qed.

Lemma reff342_not2900 : ~ @Equation2900 Fin4 reff342_inst.
Proof. unfold Equation2900. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff342_inst, reff342_op in H. discriminate H. Qed.

Lemma reff342_not2902 : ~ @Equation2902 Fin4 reff342_inst.
Proof. unfold Equation2902. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff342_inst, reff342_op in H. discriminate H. Qed.

Lemma reff342_not2903 : ~ @Equation2903 Fin4 reff342_inst.
Proof. unfold Equation2903. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff342_inst, reff342_op in H. discriminate H. Qed.

Lemma reff342_not2909 : ~ @Equation2909 Fin4 reff342_inst.
Proof. unfold Equation2909. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff342_inst, reff342_op in H. discriminate H. Qed.

Lemma reff342_not2910 : ~ @Equation2910 Fin4 reff342_inst.
Proof. unfold Equation2910. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff342_inst, reff342_op in H. discriminate H. Qed.

Lemma reff342_not2912 : ~ @Equation2912 Fin4 reff342_inst.
Proof. unfold Equation2912. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff342_inst, reff342_op in H. discriminate H. Qed.

Lemma reff342_not2913 : ~ @Equation2913 Fin4 reff342_inst.
Proof. unfold Equation2913. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff342_inst, reff342_op in H. discriminate H. Qed.

Lemma reff342_not2936 : ~ @Equation2936 Fin4 reff342_inst.
Proof. unfold Equation2936. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff342_inst, reff342_op in H. discriminate H. Qed.

Lemma reff342_not2937 : ~ @Equation2937 Fin4 reff342_inst.
Proof. unfold Equation2937. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff342_inst, reff342_op in H. discriminate H. Qed.

Lemma reff342_not2939 : ~ @Equation2939 Fin4 reff342_inst.
Proof. unfold Equation2939. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff342_inst, reff342_op in H. discriminate H. Qed.

Lemma reff342_not2940 : ~ @Equation2940 Fin4 reff342_inst.
Proof. unfold Equation2940. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff342_inst, reff342_op in H. discriminate H. Qed.

Lemma reff342_not2946 : ~ @Equation2946 Fin4 reff342_inst.
Proof. unfold Equation2946. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff342_inst, reff342_op in H. discriminate H. Qed.

Lemma reff342_not2947 : ~ @Equation2947 Fin4 reff342_inst.
Proof. unfold Equation2947. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff342_inst, reff342_op in H. discriminate H. Qed.

Lemma reff342_not2949 : ~ @Equation2949 Fin4 reff342_inst.
Proof. unfold Equation2949. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff342_inst, reff342_op in H. discriminate H. Qed.

Lemma reff342_not3051 : ~ @Equation3051 Fin4 reff342_inst.
Proof. unfold Equation3051. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff342_inst, reff342_op in H. discriminate H. Qed.

Lemma reff342_not3052 : ~ @Equation3052 Fin4 reff342_inst.
Proof. unfold Equation3052. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff342_inst, reff342_op in H. discriminate H. Qed.

Lemma reff342_not3055 : ~ @Equation3055 Fin4 reff342_inst.
Proof. unfold Equation3055. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff342_inst, reff342_op in H. discriminate H. Qed.

Lemma reff342_not3059 : ~ @Equation3059 Fin4 reff342_inst.
Proof. unfold Equation3059. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff342_inst, reff342_op in H. discriminate H. Qed.

Lemma reff342_not3065 : ~ @Equation3065 Fin4 reff342_inst.
Proof. unfold Equation3065. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff342_inst, reff342_op in H. discriminate H. Qed.

Lemma reff342_not3069 : ~ @Equation3069 Fin4 reff342_inst.
Proof. unfold Equation3069. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff342_inst, reff342_op in H. discriminate H. Qed.

Lemma reff342_not3076 : ~ @Equation3076 Fin4 reff342_inst.
Proof. unfold Equation3076. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff342_inst, reff342_op in H. discriminate H. Qed.

Lemma reff342_not3078 : ~ @Equation3078 Fin4 reff342_inst.
Proof. unfold Equation3078. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff342_inst, reff342_op in H. discriminate H. Qed.

Lemma reff342_not3102 : ~ @Equation3102 Fin4 reff342_inst.
Proof. unfold Equation3102. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff342_inst, reff342_op in H. discriminate H. Qed.

Lemma reff342_not3103 : ~ @Equation3103 Fin4 reff342_inst.
Proof. unfold Equation3103. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff342_inst, reff342_op in H. discriminate H. Qed.

Lemma reff342_not3105 : ~ @Equation3105 Fin4 reff342_inst.
Proof. unfold Equation3105. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff342_inst, reff342_op in H. discriminate H. Qed.

Lemma reff342_not3106 : ~ @Equation3106 Fin4 reff342_inst.
Proof. unfold Equation3106. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff342_inst, reff342_op in H. discriminate H. Qed.

Lemma reff342_not3112 : ~ @Equation3112 Fin4 reff342_inst.
Proof. unfold Equation3112. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff342_inst, reff342_op in H. discriminate H. Qed.

Lemma reff342_not3113 : ~ @Equation3113 Fin4 reff342_inst.
Proof. unfold Equation3113. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff342_inst, reff342_op in H. discriminate H. Qed.

Lemma reff342_not3115 : ~ @Equation3115 Fin4 reff342_inst.
Proof. unfold Equation3115. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff342_inst, reff342_op in H. discriminate H. Qed.

Lemma reff342_not3116 : ~ @Equation3116 Fin4 reff342_inst.
Proof. unfold Equation3116. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff342_inst, reff342_op in H. discriminate H. Qed.

Lemma reff342_not3139 : ~ @Equation3139 Fin4 reff342_inst.
Proof. unfold Equation3139. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff342_inst, reff342_op in H. discriminate H. Qed.

Lemma reff342_not3140 : ~ @Equation3140 Fin4 reff342_inst.
Proof. unfold Equation3140. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff342_inst, reff342_op in H. discriminate H. Qed.

Lemma reff342_not3142 : ~ @Equation3142 Fin4 reff342_inst.
Proof. unfold Equation3142. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff342_inst, reff342_op in H. discriminate H. Qed.

Lemma reff342_not3143 : ~ @Equation3143 Fin4 reff342_inst.
Proof. unfold Equation3143. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff342_inst, reff342_op in H. discriminate H. Qed.

Lemma reff342_not3149 : ~ @Equation3149 Fin4 reff342_inst.
Proof. unfold Equation3149. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff342_inst, reff342_op in H. discriminate H. Qed.

Lemma reff342_not3150 : ~ @Equation3150 Fin4 reff342_inst.
Proof. unfold Equation3150. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff342_inst, reff342_op in H. discriminate H. Qed.

Lemma reff342_not3152 : ~ @Equation3152 Fin4 reff342_inst.
Proof. unfold Equation3152. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff342_inst, reff342_op in H. discriminate H. Qed.

Lemma reff342_not3254 : ~ @Equation3254 Fin4 reff342_inst.
Proof. unfold Equation3254. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff342_inst, reff342_op in H. discriminate H. Qed.

Lemma reff342_not3255 : ~ @Equation3255 Fin4 reff342_inst.
Proof. unfold Equation3255. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff342_inst, reff342_op in H. discriminate H. Qed.

Lemma reff342_not3256 : ~ @Equation3256 Fin4 reff342_inst.
Proof. unfold Equation3256. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff342_inst, reff342_op in H. discriminate H. Qed.

Lemma reff342_not3258 : ~ @Equation3258 Fin4 reff342_inst.
Proof. unfold Equation3258. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff342_inst, reff342_op in H. discriminate H. Qed.

Lemma reff342_not3259 : ~ @Equation3259 Fin4 reff342_inst.
Proof. unfold Equation3259. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff342_inst, reff342_op in H. discriminate H. Qed.

Lemma reff342_not3262 : ~ @Equation3262 Fin4 reff342_inst.
Proof. unfold Equation3262. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff342_inst, reff342_op in H. discriminate H. Qed.

Lemma reff342_not3268 : ~ @Equation3268 Fin4 reff342_inst.
Proof. unfold Equation3268. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff342_inst, reff342_op in H. discriminate H. Qed.

Lemma reff342_not3269 : ~ @Equation3269 Fin4 reff342_inst.
Proof. unfold Equation3269. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff342_inst, reff342_op in H. discriminate H. Qed.

Lemma reff342_not3271 : ~ @Equation3271 Fin4 reff342_inst.
Proof. unfold Equation3271. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff342_inst, reff342_op in H. discriminate H. Qed.

Lemma reff342_not3272 : ~ @Equation3272 Fin4 reff342_inst.
Proof. unfold Equation3272. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff342_inst, reff342_op in H. discriminate H. Qed.

Lemma reff342_not3278 : ~ @Equation3278 Fin4 reff342_inst.
Proof. unfold Equation3278. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff342_inst, reff342_op in H. discriminate H. Qed.

Lemma reff342_not3279 : ~ @Equation3279 Fin4 reff342_inst.
Proof. unfold Equation3279. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff342_inst, reff342_op in H. discriminate H. Qed.

Lemma reff342_not3281 : ~ @Equation3281 Fin4 reff342_inst.
Proof. unfold Equation3281. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff342_inst, reff342_op in H. discriminate H. Qed.

Lemma reff342_not3308 : ~ @Equation3308 Fin4 reff342_inst.
Proof. unfold Equation3308. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff342_inst, reff342_op in H. discriminate H. Qed.

Lemma reff342_not3309 : ~ @Equation3309 Fin4 reff342_inst.
Proof. unfold Equation3309. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff342_inst, reff342_op in H. discriminate H. Qed.

Lemma reff342_not3315 : ~ @Equation3315 Fin4 reff342_inst.
Proof. unfold Equation3315. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff342_inst, reff342_op in H. discriminate H. Qed.

Lemma reff342_not3316 : ~ @Equation3316 Fin4 reff342_inst.
Proof. unfold Equation3316. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff342_inst, reff342_op in H. discriminate H. Qed.

Lemma reff342_not3318 : ~ @Equation3318 Fin4 reff342_inst.
Proof. unfold Equation3318. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff342_inst, reff342_op in H. discriminate H. Qed.

Lemma reff342_not3342 : ~ @Equation3342 Fin4 reff342_inst.
Proof. unfold Equation3342. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff342_inst, reff342_op in H. discriminate H. Qed.

Lemma reff342_not3343 : ~ @Equation3343 Fin4 reff342_inst.
Proof. unfold Equation3343. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff342_inst, reff342_op in H. discriminate H. Qed.

Lemma reff342_not3345 : ~ @Equation3345 Fin4 reff342_inst.
Proof. unfold Equation3345. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff342_inst, reff342_op in H. discriminate H. Qed.

Lemma reff342_not3346 : ~ @Equation3346 Fin4 reff342_inst.
Proof. unfold Equation3346. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff342_inst, reff342_op in H. discriminate H. Qed.

Lemma reff342_not3352 : ~ @Equation3352 Fin4 reff342_inst.
Proof. unfold Equation3352. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff342_inst, reff342_op in H. discriminate H. Qed.

Lemma reff342_not3353 : ~ @Equation3353 Fin4 reff342_inst.
Proof. unfold Equation3353. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff342_inst, reff342_op in H. discriminate H. Qed.

Lemma reff342_not3457 : ~ @Equation3457 Fin4 reff342_inst.
Proof. unfold Equation3457. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff342_inst, reff342_op in H. discriminate H. Qed.

Lemma reff342_not3458 : ~ @Equation3458 Fin4 reff342_inst.
Proof. unfold Equation3458. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff342_inst, reff342_op in H. discriminate H. Qed.

Lemma reff342_not3461 : ~ @Equation3461 Fin4 reff342_inst.
Proof. unfold Equation3461. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff342_inst, reff342_op in H. discriminate H. Qed.

Lemma reff342_not3465 : ~ @Equation3465 Fin4 reff342_inst.
Proof. unfold Equation3465. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff342_inst, reff342_op in H. discriminate H. Qed.

Lemma reff342_not3472 : ~ @Equation3472 Fin4 reff342_inst.
Proof. unfold Equation3472. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff342_inst, reff342_op in H. discriminate H. Qed.

Lemma reff342_not3474 : ~ @Equation3474 Fin4 reff342_inst.
Proof. unfold Equation3474. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff342_inst, reff342_op in H. discriminate H. Qed.

Lemma reff342_not3475 : ~ @Equation3475 Fin4 reff342_inst.
Proof. unfold Equation3475. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff342_inst, reff342_op in H. discriminate H. Qed.

Lemma reff342_not3481 : ~ @Equation3481 Fin4 reff342_inst.
Proof. unfold Equation3481. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff342_inst, reff342_op in H. discriminate H. Qed.

Lemma reff342_not3482 : ~ @Equation3482 Fin4 reff342_inst.
Proof. unfold Equation3482. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff342_inst, reff342_op in H. discriminate H. Qed.

Lemma reff342_not3484 : ~ @Equation3484 Fin4 reff342_inst.
Proof. unfold Equation3484. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff342_inst, reff342_op in H. discriminate H. Qed.

Lemma reff342_not3512 : ~ @Equation3512 Fin4 reff342_inst.
Proof. unfold Equation3512. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff342_inst, reff342_op in H. discriminate H. Qed.

Lemma reff342_not3519 : ~ @Equation3519 Fin4 reff342_inst.
Proof. unfold Equation3519. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff342_inst, reff342_op in H. discriminate H. Qed.

Lemma reff342_not3521 : ~ @Equation3521 Fin4 reff342_inst.
Proof. unfold Equation3521. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff342_inst, reff342_op in H. discriminate H. Qed.

Lemma reff342_not3545 : ~ @Equation3545 Fin4 reff342_inst.
Proof. unfold Equation3545. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff342_inst, reff342_op in H. discriminate H. Qed.

Lemma reff342_not3546 : ~ @Equation3546 Fin4 reff342_inst.
Proof. unfold Equation3546. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff342_inst, reff342_op in H. discriminate H. Qed.

Lemma reff342_not3548 : ~ @Equation3548 Fin4 reff342_inst.
Proof. unfold Equation3548. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff342_inst, reff342_op in H. discriminate H. Qed.

Lemma reff342_not3549 : ~ @Equation3549 Fin4 reff342_inst.
Proof. unfold Equation3549. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff342_inst, reff342_op in H. discriminate H. Qed.

Lemma reff342_not3555 : ~ @Equation3555 Fin4 reff342_inst.
Proof. unfold Equation3555. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff342_inst, reff342_op in H. discriminate H. Qed.

Lemma reff342_not3556 : ~ @Equation3556 Fin4 reff342_inst.
Proof. unfold Equation3556. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff342_inst, reff342_op in H. discriminate H. Qed.

Lemma reff342_not3558 : ~ @Equation3558 Fin4 reff342_inst.
Proof. unfold Equation3558. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff342_inst, reff342_op in H. discriminate H. Qed.

Lemma reff342_not3660 : ~ @Equation3660 Fin4 reff342_inst.
Proof. unfold Equation3660. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff342_inst, reff342_op in H. discriminate H. Qed.

Lemma reff342_not3661 : ~ @Equation3661 Fin4 reff342_inst.
Proof. unfold Equation3661. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff342_inst, reff342_op in H. discriminate H. Qed.

Lemma reff342_not3662 : ~ @Equation3662 Fin4 reff342_inst.
Proof. unfold Equation3662. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff342_inst, reff342_op in H. discriminate H. Qed.

Lemma reff342_not3664 : ~ @Equation3664 Fin4 reff342_inst.
Proof. unfold Equation3664. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff342_inst, reff342_op in H. discriminate H. Qed.

Lemma reff342_not3667 : ~ @Equation3667 Fin4 reff342_inst.
Proof. unfold Equation3667. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff342_inst, reff342_op in H. discriminate H. Qed.

Lemma reff342_not3668 : ~ @Equation3668 Fin4 reff342_inst.
Proof. unfold Equation3668. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff342_inst, reff342_op in H. discriminate H. Qed.

Lemma reff342_not3674 : ~ @Equation3674 Fin4 reff342_inst.
Proof. unfold Equation3674. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff342_inst, reff342_op in H. discriminate H. Qed.

Lemma reff342_not3675 : ~ @Equation3675 Fin4 reff342_inst.
Proof. unfold Equation3675. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff342_inst, reff342_op in H. discriminate H. Qed.

Lemma reff342_not3677 : ~ @Equation3677 Fin4 reff342_inst.
Proof. unfold Equation3677. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff342_inst, reff342_op in H. discriminate H. Qed.

Lemma reff342_not3678 : ~ @Equation3678 Fin4 reff342_inst.
Proof. unfold Equation3678. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff342_inst, reff342_op in H. discriminate H. Qed.

Lemma reff342_not3684 : ~ @Equation3684 Fin4 reff342_inst.
Proof. unfold Equation3684. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff342_inst, reff342_op in H. discriminate H. Qed.

Lemma reff342_not3685 : ~ @Equation3685 Fin4 reff342_inst.
Proof. unfold Equation3685. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff342_inst, reff342_op in H. discriminate H. Qed.

Lemma reff342_not3687 : ~ @Equation3687 Fin4 reff342_inst.
Proof. unfold Equation3687. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff342_inst, reff342_op in H. discriminate H. Qed.

Lemma reff342_not3714 : ~ @Equation3714 Fin4 reff342_inst.
Proof. unfold Equation3714. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff342_inst, reff342_op in H. discriminate H. Qed.

Lemma reff342_not3722 : ~ @Equation3722 Fin4 reff342_inst.
Proof. unfold Equation3722. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff342_inst, reff342_op in H. discriminate H. Qed.

Lemma reff342_not3724 : ~ @Equation3724 Fin4 reff342_inst.
Proof. unfold Equation3724. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff342_inst, reff342_op in H. discriminate H. Qed.

Lemma reff342_not3725 : ~ @Equation3725 Fin4 reff342_inst.
Proof. unfold Equation3725. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff342_inst, reff342_op in H. discriminate H. Qed.

Lemma reff342_not3748 : ~ @Equation3748 Fin4 reff342_inst.
Proof. unfold Equation3748. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff342_inst, reff342_op in H. discriminate H. Qed.

Lemma reff342_not3749 : ~ @Equation3749 Fin4 reff342_inst.
Proof. unfold Equation3749. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff342_inst, reff342_op in H. discriminate H. Qed.

Lemma reff342_not3751 : ~ @Equation3751 Fin4 reff342_inst.
Proof. unfold Equation3751. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff342_inst, reff342_op in H. discriminate H. Qed.

Lemma reff342_not3752 : ~ @Equation3752 Fin4 reff342_inst.
Proof. unfold Equation3752. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff342_inst, reff342_op in H. discriminate H. Qed.

Lemma reff342_not3759 : ~ @Equation3759 Fin4 reff342_inst.
Proof. unfold Equation3759. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff342_inst, reff342_op in H. discriminate H. Qed.

Lemma reff342_not3761 : ~ @Equation3761 Fin4 reff342_inst.
Proof. unfold Equation3761. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff342_inst, reff342_op in H. discriminate H. Qed.

Lemma reff342_not3864 : ~ @Equation3864 Fin4 reff342_inst.
Proof. unfold Equation3864. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff342_inst, reff342_op in H. discriminate H. Qed.

Lemma reff342_not3867 : ~ @Equation3867 Fin4 reff342_inst.
Proof. unfold Equation3867. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff342_inst, reff342_op in H. discriminate H. Qed.

Lemma reff342_not3868 : ~ @Equation3868 Fin4 reff342_inst.
Proof. unfold Equation3868. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff342_inst, reff342_op in H. discriminate H. Qed.

Lemma reff342_not3870 : ~ @Equation3870 Fin4 reff342_inst.
Proof. unfold Equation3870. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff342_inst, reff342_op in H. discriminate H. Qed.

Lemma reff342_not3871 : ~ @Equation3871 Fin4 reff342_inst.
Proof. unfold Equation3871. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff342_inst, reff342_op in H. discriminate H. Qed.

Lemma reff342_not3877 : ~ @Equation3877 Fin4 reff342_inst.
Proof. unfold Equation3877. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff342_inst, reff342_op in H. discriminate H. Qed.

Lemma reff342_not3878 : ~ @Equation3878 Fin4 reff342_inst.
Proof. unfold Equation3878. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff342_inst, reff342_op in H. discriminate H. Qed.

Lemma reff342_not3880 : ~ @Equation3880 Fin4 reff342_inst.
Proof. unfold Equation3880. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff342_inst, reff342_op in H. discriminate H. Qed.

Lemma reff342_not3881 : ~ @Equation3881 Fin4 reff342_inst.
Proof. unfold Equation3881. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff342_inst, reff342_op in H. discriminate H. Qed.

Lemma reff342_not3887 : ~ @Equation3887 Fin4 reff342_inst.
Proof. unfold Equation3887. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff342_inst, reff342_op in H. discriminate H. Qed.

Lemma reff342_not3888 : ~ @Equation3888 Fin4 reff342_inst.
Proof. unfold Equation3888. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff342_inst, reff342_op in H. discriminate H. Qed.

Lemma reff342_not3890 : ~ @Equation3890 Fin4 reff342_inst.
Proof. unfold Equation3890. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff342_inst, reff342_op in H. discriminate H. Qed.

Lemma reff342_not3918 : ~ @Equation3918 Fin4 reff342_inst.
Proof. unfold Equation3918. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff342_inst, reff342_op in H. discriminate H. Qed.

Lemma reff342_not3924 : ~ @Equation3924 Fin4 reff342_inst.
Proof. unfold Equation3924. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff342_inst, reff342_op in H. discriminate H. Qed.

Lemma reff342_not3925 : ~ @Equation3925 Fin4 reff342_inst.
Proof. unfold Equation3925. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff342_inst, reff342_op in H. discriminate H. Qed.

Lemma reff342_not3927 : ~ @Equation3927 Fin4 reff342_inst.
Proof. unfold Equation3927. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff342_inst, reff342_op in H. discriminate H. Qed.

Lemma reff342_not3928 : ~ @Equation3928 Fin4 reff342_inst.
Proof. unfold Equation3928. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff342_inst, reff342_op in H. discriminate H. Qed.

Lemma reff342_not3951 : ~ @Equation3951 Fin4 reff342_inst.
Proof. unfold Equation3951. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff342_inst, reff342_op in H. discriminate H. Qed.

Lemma reff342_not3952 : ~ @Equation3952 Fin4 reff342_inst.
Proof. unfold Equation3952. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff342_inst, reff342_op in H. discriminate H. Qed.

Lemma reff342_not3954 : ~ @Equation3954 Fin4 reff342_inst.
Proof. unfold Equation3954. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff342_inst, reff342_op in H. discriminate H. Qed.

Lemma reff342_not3955 : ~ @Equation3955 Fin4 reff342_inst.
Proof. unfold Equation3955. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff342_inst, reff342_op in H. discriminate H. Qed.

Lemma reff342_not3961 : ~ @Equation3961 Fin4 reff342_inst.
Proof. unfold Equation3961. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff342_inst, reff342_op in H. discriminate H. Qed.

Lemma reff342_not3962 : ~ @Equation3962 Fin4 reff342_inst.
Proof. unfold Equation3962. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff342_inst, reff342_op in H. discriminate H. Qed.

Lemma reff342_not3964 : ~ @Equation3964 Fin4 reff342_inst.
Proof. unfold Equation3964. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff342_inst, reff342_op in H. discriminate H. Qed.

Lemma reff342_not4066 : ~ @Equation4066 Fin4 reff342_inst.
Proof. unfold Equation4066. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff342_inst, reff342_op in H. discriminate H. Qed.

Lemma reff342_not4067 : ~ @Equation4067 Fin4 reff342_inst.
Proof. unfold Equation4067. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff342_inst, reff342_op in H. discriminate H. Qed.

Lemma reff342_not4070 : ~ @Equation4070 Fin4 reff342_inst.
Proof. unfold Equation4070. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff342_inst, reff342_op in H. discriminate H. Qed.

Lemma reff342_not4074 : ~ @Equation4074 Fin4 reff342_inst.
Proof. unfold Equation4074. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff342_inst, reff342_op in H. discriminate H. Qed.

Lemma reff342_not4080 : ~ @Equation4080 Fin4 reff342_inst.
Proof. unfold Equation4080. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff342_inst, reff342_op in H. discriminate H. Qed.

Lemma reff342_not4081 : ~ @Equation4081 Fin4 reff342_inst.
Proof. unfold Equation4081. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff342_inst, reff342_op in H. discriminate H. Qed.

Lemma reff342_not4083 : ~ @Equation4083 Fin4 reff342_inst.
Proof. unfold Equation4083. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff342_inst, reff342_op in H. discriminate H. Qed.

Lemma reff342_not4084 : ~ @Equation4084 Fin4 reff342_inst.
Proof. unfold Equation4084. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff342_inst, reff342_op in H. discriminate H. Qed.

Lemma reff342_not4090 : ~ @Equation4090 Fin4 reff342_inst.
Proof. unfold Equation4090. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff342_inst, reff342_op in H. discriminate H. Qed.

Lemma reff342_not4091 : ~ @Equation4091 Fin4 reff342_inst.
Proof. unfold Equation4091. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff342_inst, reff342_op in H. discriminate H. Qed.

Lemma reff342_not4093 : ~ @Equation4093 Fin4 reff342_inst.
Proof. unfold Equation4093. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff342_inst, reff342_op in H. discriminate H. Qed.

Lemma reff342_not4121 : ~ @Equation4121 Fin4 reff342_inst.
Proof. unfold Equation4121. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff342_inst, reff342_op in H. discriminate H. Qed.

Lemma reff342_not4128 : ~ @Equation4128 Fin4 reff342_inst.
Proof. unfold Equation4128. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff342_inst, reff342_op in H. discriminate H. Qed.

Lemma reff342_not4130 : ~ @Equation4130 Fin4 reff342_inst.
Proof. unfold Equation4130. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff342_inst, reff342_op in H. discriminate H. Qed.

Lemma reff342_not4155 : ~ @Equation4155 Fin4 reff342_inst.
Proof. unfold Equation4155. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff342_inst, reff342_op in H. discriminate H. Qed.

Lemma reff342_not4157 : ~ @Equation4157 Fin4 reff342_inst.
Proof. unfold Equation4157. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff342_inst, reff342_op in H. discriminate H. Qed.

Lemma reff342_not4158 : ~ @Equation4158 Fin4 reff342_inst.
Proof. unfold Equation4158. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff342_inst, reff342_op in H. discriminate H. Qed.

Lemma reff342_not4164 : ~ @Equation4164 Fin4 reff342_inst.
Proof. unfold Equation4164. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff342_inst, reff342_op in H. discriminate H. Qed.

Lemma reff342_not4165 : ~ @Equation4165 Fin4 reff342_inst.
Proof. unfold Equation4165. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff342_inst, reff342_op in H. discriminate H. Qed.

Lemma reff342_not4167 : ~ @Equation4167 Fin4 reff342_inst.
Proof. unfold Equation4167. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff342_inst, reff342_op in H. discriminate H. Qed.

Lemma reff342_not4268 : ~ @Equation4268 Fin4 reff342_inst.
Proof. unfold Equation4268. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff342_inst, reff342_op in H. discriminate H. Qed.

Lemma reff342_not4269 : ~ @Equation4269 Fin4 reff342_inst.
Proof. unfold Equation4269. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff342_inst, reff342_op in H. discriminate H. Qed.

Lemma reff342_not4270 : ~ @Equation4270 Fin4 reff342_inst.
Proof. unfold Equation4270. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff342_inst, reff342_op in H. discriminate H. Qed.

Lemma reff342_not4272 : ~ @Equation4272 Fin4 reff342_inst.
Proof. unfold Equation4272. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff342_inst, reff342_op in H. discriminate H. Qed.

Lemma reff342_not4273 : ~ @Equation4273 Fin4 reff342_inst.
Proof. unfold Equation4273. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff342_inst, reff342_op in H. discriminate H. Qed.

Lemma reff342_not4275 : ~ @Equation4275 Fin4 reff342_inst.
Proof. unfold Equation4275. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff342_inst, reff342_op in H. discriminate H. Qed.

Lemma reff342_not4276 : ~ @Equation4276 Fin4 reff342_inst.
Proof. unfold Equation4276. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff342_inst, reff342_op in H. discriminate H. Qed.

Lemma reff342_not4283 : ~ @Equation4283 Fin4 reff342_inst.
Proof. unfold Equation4283. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff342_inst, reff342_op in H. discriminate H. Qed.

Lemma reff342_not4284 : ~ @Equation4284 Fin4 reff342_inst.
Proof. unfold Equation4284. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff342_inst, reff342_op in H. discriminate H. Qed.

Lemma reff342_not4290 : ~ @Equation4290 Fin4 reff342_inst.
Proof. unfold Equation4290. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff342_inst, reff342_op in H. discriminate H. Qed.

Lemma reff342_not4291 : ~ @Equation4291 Fin4 reff342_inst.
Proof. unfold Equation4291. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff342_inst, reff342_op in H. discriminate H. Qed.

Lemma reff342_not4293 : ~ @Equation4293 Fin4 reff342_inst.
Proof. unfold Equation4293. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff342_inst, reff342_op in H. discriminate H. Qed.

Lemma reff342_not4314 : ~ @Equation4314 Fin4 reff342_inst.
Proof. unfold Equation4314. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff342_inst, reff342_op in H. discriminate H. Qed.

Lemma reff342_not4320 : ~ @Equation4320 Fin4 reff342_inst.
Proof. unfold Equation4320. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff342_inst, reff342_op in H. discriminate H. Qed.

Lemma reff342_not4321 : ~ @Equation4321 Fin4 reff342_inst.
Proof. unfold Equation4321. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff342_inst, reff342_op in H. discriminate H. Qed.

Lemma reff342_not4343 : ~ @Equation4343 Fin4 reff342_inst.
Proof. unfold Equation4343. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff342_inst, reff342_op in H. discriminate H. Qed.

Lemma reff342_not4399 : ~ @Equation4399 Fin4 reff342_inst.
Proof. unfold Equation4399. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff342_inst, reff342_op in H. discriminate H. Qed.

Lemma reff342_not4405 : ~ @Equation4405 Fin4 reff342_inst.
Proof. unfold Equation4405. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff342_inst, reff342_op in H. discriminate H. Qed.

Lemma reff342_not4406 : ~ @Equation4406 Fin4 reff342_inst.
Proof. unfold Equation4406. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff342_inst, reff342_op in H. discriminate H. Qed.

Lemma reff342_not4408 : ~ @Equation4408 Fin4 reff342_inst.
Proof. unfold Equation4408. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff342_inst, reff342_op in H. discriminate H. Qed.

Lemma reff342_not4433 : ~ @Equation4433 Fin4 reff342_inst.
Proof. unfold Equation4433. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff342_inst, reff342_op in H. discriminate H. Qed.

Lemma reff342_not4435 : ~ @Equation4435 Fin4 reff342_inst.
Proof. unfold Equation4435. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff342_inst, reff342_op in H. discriminate H. Qed.

Lemma reff342_not4436 : ~ @Equation4436 Fin4 reff342_inst.
Proof. unfold Equation4436. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff342_inst, reff342_op in H. discriminate H. Qed.

Lemma reff342_not4442 : ~ @Equation4442 Fin4 reff342_inst.
Proof. unfold Equation4442. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff342_inst, reff342_op in H. discriminate H. Qed.

Lemma reff342_not4443 : ~ @Equation4443 Fin4 reff342_inst.
Proof. unfold Equation4443. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff342_inst, reff342_op in H. discriminate H. Qed.

Lemma reff342_not4445 : ~ @Equation4445 Fin4 reff342_inst.
Proof. unfold Equation4445. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff342_inst, reff342_op in H. discriminate H. Qed.

Lemma reff342_not4470 : ~ @Equation4470 Fin4 reff342_inst.
Proof. unfold Equation4470. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff342_inst, reff342_op in H. discriminate H. Qed.

Lemma reff342_not4472 : ~ @Equation4472 Fin4 reff342_inst.
Proof. unfold Equation4472. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff342_inst, reff342_op in H. discriminate H. Qed.

Lemma reff342_not4473 : ~ @Equation4473 Fin4 reff342_inst.
Proof. unfold Equation4473. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff342_inst, reff342_op in H. discriminate H. Qed.

Lemma reff342_not4479 : ~ @Equation4479 Fin4 reff342_inst.
Proof. unfold Equation4479. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff342_inst, reff342_op in H. discriminate H. Qed.

Lemma reff342_not4480 : ~ @Equation4480 Fin4 reff342_inst.
Proof. unfold Equation4480. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff342_inst, reff342_op in H. discriminate H. Qed.

Lemma reff342_not4482 : ~ @Equation4482 Fin4 reff342_inst.
Proof. unfold Equation4482. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff342_inst, reff342_op in H. discriminate H. Qed.

Lemma reff342_not4583 : ~ @Equation4583 Fin4 reff342_inst.
Proof. unfold Equation4583. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff342_inst, reff342_op in H. discriminate H. Qed.

Lemma reff342_not4584 : ~ @Equation4584 Fin4 reff342_inst.
Proof. unfold Equation4584. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff342_inst, reff342_op in H. discriminate H. Qed.

Lemma reff342_not4587 : ~ @Equation4587 Fin4 reff342_inst.
Proof. unfold Equation4587. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff342_inst, reff342_op in H. discriminate H. Qed.

Lemma reff342_not4588 : ~ @Equation4588 Fin4 reff342_inst.
Proof. unfold Equation4588. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff342_inst, reff342_op in H. discriminate H. Qed.

Lemma reff342_not4590 : ~ @Equation4590 Fin4 reff342_inst.
Proof. unfold Equation4590. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff342_inst, reff342_op in H. discriminate H. Qed.

Lemma reff342_not4591 : ~ @Equation4591 Fin4 reff342_inst.
Proof. unfold Equation4591. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff342_inst, reff342_op in H. discriminate H. Qed.

Lemma reff342_not4599 : ~ @Equation4599 Fin4 reff342_inst.
Proof. unfold Equation4599. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff342_inst, reff342_op in H. discriminate H. Qed.

Lemma reff342_not4605 : ~ @Equation4605 Fin4 reff342_inst.
Proof. unfold Equation4605. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff342_inst, reff342_op in H. discriminate H. Qed.

Lemma reff342_not4606 : ~ @Equation4606 Fin4 reff342_inst.
Proof. unfold Equation4606. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff342_inst, reff342_op in H. discriminate H. Qed.

Lemma reff342_not4608 : ~ @Equation4608 Fin4 reff342_inst.
Proof. unfold Equation4608. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff342_inst, reff342_op in H. discriminate H. Qed.

Lemma reff342_not4629 : ~ @Equation4629 Fin4 reff342_inst.
Proof. unfold Equation4629. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff342_inst, reff342_op in H. discriminate H. Qed.

Lemma reff342_not4635 : ~ @Equation4635 Fin4 reff342_inst.
Proof. unfold Equation4635. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff342_inst, reff342_op in H. discriminate H. Qed.

Lemma reff342_not4636 : ~ @Equation4636 Fin4 reff342_inst.
Proof. unfold Equation4636. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff342_inst, reff342_op in H. discriminate H. Qed.

Lemma reff342_not4658 : ~ @Equation4658 Fin4 reff342_inst.
Proof. unfold Equation4658. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff342_inst, reff342_op in H. discriminate H. Qed.

(** ---- reff344 (Fin5) ---- *)

Definition reff344_op (x y : Fin5) : Fin5 :=
  match x, y with
  | F5_0, F5_0 => F5_0 | F5_0, F5_1 => F5_1 | F5_0, F5_2 => F5_2 | F5_0, F5_3 => F5_3 | F5_0, F5_4 => F5_4
  | F5_1, F5_0 => F5_4 | F5_1, F5_1 => F5_0 | F5_1, F5_2 => F5_1 | F5_1, F5_3 => F5_2 | F5_1, F5_4 => F5_3
  | F5_2, F5_0 => F5_3 | F5_2, F5_1 => F5_4 | F5_2, F5_2 => F5_0 | F5_2, F5_3 => F5_1 | F5_2, F5_4 => F5_2
  | F5_3, F5_0 => F5_2 | F5_3, F5_1 => F5_3 | F5_3, F5_2 => F5_4 | F5_3, F5_3 => F5_0 | F5_3, F5_4 => F5_1
  | F5_4, F5_0 => F5_1 | F5_4, F5_1 => F5_2 | F5_4, F5_2 => F5_3 | F5_4, F5_3 => F5_4 | F5_4, F5_4 => F5_0
  end.

#[local] Instance reff344_inst : Magma Fin5 := {| magma_op := reff344_op |}.

Lemma reff344_sat26 : @Equation26 Fin5 reff344_inst.
Proof. unfold Equation26, magma_op, reff344_inst, reff344_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff344_sat31 : @Equation31 Fin5 reff344_inst.
Proof. unfold Equation31, magma_op, reff344_inst, reff344_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff344_sat1090 : @Equation1090 Fin5 reff344_inst.
Proof. unfold Equation1090, magma_op, reff344_inst, reff344_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff344_sat1101 : @Equation1101 Fin5 reff344_inst.
Proof. unfold Equation1101, magma_op, reff344_inst, reff344_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff344_sat1117 : @Equation1117 Fin5 reff344_inst.
Proof. unfold Equation1117, magma_op, reff344_inst, reff344_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff344_sat1137 : @Equation1137 Fin5 reff344_inst.
Proof. unfold Equation1137, magma_op, reff344_inst, reff344_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff344_sat1155 : @Equation1155 Fin5 reff344_inst.
Proof. unfold Equation1155, magma_op, reff344_inst, reff344_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff344_sat1171 : @Equation1171 Fin5 reff344_inst.
Proof. unfold Equation1171, magma_op, reff344_inst, reff344_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff344_sat1673 : @Equation1673 Fin5 reff344_inst.
Proof. unfold Equation1673, magma_op, reff344_inst, reff344_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff344_sat1726 : @Equation1726 Fin5 reff344_inst.
Proof. unfold Equation1726, magma_op, reff344_inst, reff344_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff344_sat1761 : @Equation1761 Fin5 reff344_inst.
Proof. unfold Equation1761, magma_op, reff344_inst, reff344_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff344_sat1793 : @Equation1793 Fin5 reff344_inst.
Proof. unfold Equation1793, magma_op, reff344_inst, reff344_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff344_sat1865 : @Equation1865 Fin5 reff344_inst.
Proof. unfold Equation1865, magma_op, reff344_inst, reff344_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff344_sat1902 : @Equation1902 Fin5 reff344_inst.
Proof. unfold Equation1902, magma_op, reff344_inst, reff344_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff344_sat1910 : @Equation1910 Fin5 reff344_inst.
Proof. unfold Equation1910, magma_op, reff344_inst, reff344_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff344_sat1983 : @Equation1983 Fin5 reff344_inst.
Proof. unfold Equation1983, magma_op, reff344_inst, reff344_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff344_sat1996 : @Equation1996 Fin5 reff344_inst.
Proof. unfold Equation1996, magma_op, reff344_inst, reff344_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff344_sat2474 : @Equation2474 Fin5 reff344_inst.
Proof. unfold Equation2474, magma_op, reff344_inst, reff344_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff344_sat2538 : @Equation2538 Fin5 reff344_inst.
Proof. unfold Equation2538, magma_op, reff344_inst, reff344_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff344_sat2558 : @Equation2558 Fin5 reff344_inst.
Proof. unfold Equation2558, magma_op, reff344_inst, reff344_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff344_sat2573 : @Equation2573 Fin5 reff344_inst.
Proof. unfold Equation2573, magma_op, reff344_inst, reff344_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff344_sat2714 : @Equation2714 Fin5 reff344_inst.
Proof. unfold Equation2714, magma_op, reff344_inst, reff344_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff344_sat2725 : @Equation2725 Fin5 reff344_inst.
Proof. unfold Equation2725, magma_op, reff344_inst, reff344_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff344_sat2741 : @Equation2741 Fin5 reff344_inst.
Proof. unfold Equation2741, magma_op, reff344_inst, reff344_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff344_sat2779 : @Equation2779 Fin5 reff344_inst.
Proof. unfold Equation2779, magma_op, reff344_inst, reff344_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff344_sat3147 : @Equation3147 Fin5 reff344_inst.
Proof. unfold Equation3147, magma_op, reff344_inst, reff344_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff344_sat3182 : @Equation3182 Fin5 reff344_inst.
Proof. unfold Equation3182, magma_op, reff344_inst, reff344_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff344_sat3214 : @Equation3214 Fin5 reff344_inst.
Proof. unfold Equation3214, magma_op, reff344_inst, reff344_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff344_sat3489 : @Equation3489 Fin5 reff344_inst.
Proof. unfold Equation3489, magma_op, reff344_inst, reff344_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff344_sat3601 : @Equation3601 Fin5 reff344_inst.
Proof. unfold Equation3601, magma_op, reff344_inst, reff344_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff344_sat3756 : @Equation3756 Fin5 reff344_inst.
Proof. unfold Equation3756, magma_op, reff344_inst, reff344_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff344_sat3794 : @Equation3794 Fin5 reff344_inst.
Proof. unfold Equation3794, magma_op, reff344_inst, reff344_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff344_sat4109 : @Equation4109 Fin5 reff344_inst.
Proof. unfold Equation4109, magma_op, reff344_inst, reff344_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff344_sat4210 : @Equation4210 Fin5 reff344_inst.
Proof. unfold Equation4210, magma_op, reff344_inst, reff344_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff344_sat4325 : @Equation4325 Fin5 reff344_inst.
Proof. unfold Equation4325, magma_op, reff344_inst, reff344_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff344_sat4612 : @Equation4612 Fin5 reff344_inst.
Proof. unfold Equation4612, magma_op, reff344_inst, reff344_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff344_sat4684 : @Equation4684 Fin5 reff344_inst.
Proof. unfold Equation4684, magma_op, reff344_inst, reff344_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff344_not47 : ~ @Equation47 Fin5 reff344_inst.
Proof. unfold Equation47. intro H. specialize (H F5_1). unfold magma_op, reff344_inst, reff344_op in H. discriminate H. Qed.

Lemma reff344_not99 : ~ @Equation99 Fin5 reff344_inst.
Proof. unfold Equation99. intro H. specialize (H F5_1). unfold magma_op, reff344_inst, reff344_op in H. discriminate H. Qed.

Lemma reff344_not151 : ~ @Equation151 Fin5 reff344_inst.
Proof. unfold Equation151. intro H. specialize (H F5_1). unfold magma_op, reff344_inst, reff344_op in H. discriminate H. Qed.

Lemma reff344_not203 : ~ @Equation203 Fin5 reff344_inst.
Proof. unfold Equation203. intro H. specialize (H F5_1). unfold magma_op, reff344_inst, reff344_op in H. discriminate H. Qed.

Lemma reff344_not255 : ~ @Equation255 Fin5 reff344_inst.
Proof. unfold Equation255. intro H. specialize (H F5_1). unfold magma_op, reff344_inst, reff344_op in H. discriminate H. Qed.

Lemma reff344_not359 : ~ @Equation359 Fin5 reff344_inst.
Proof. unfold Equation359. intro H. specialize (H F5_1). unfold magma_op, reff344_inst, reff344_op in H. discriminate H. Qed.

Lemma reff344_not411 : ~ @Equation411 Fin5 reff344_inst.
Proof. unfold Equation411. intro H. specialize (H F5_1). unfold magma_op, reff344_inst, reff344_op in H. discriminate H. Qed.

Lemma reff344_not614 : ~ @Equation614 Fin5 reff344_inst.
Proof. unfold Equation614. intro H. specialize (H F5_1). unfold magma_op, reff344_inst, reff344_op in H. discriminate H. Qed.

Lemma reff344_not817 : ~ @Equation817 Fin5 reff344_inst.
Proof. unfold Equation817. intro H. specialize (H F5_1). unfold magma_op, reff344_inst, reff344_op in H. discriminate H. Qed.

Lemma reff344_not1021 : ~ @Equation1021 Fin5 reff344_inst.
Proof. unfold Equation1021. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff344_inst, reff344_op in H. discriminate H. Qed.

Lemma reff344_not1022 : ~ @Equation1022 Fin5 reff344_inst.
Proof. unfold Equation1022. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff344_inst, reff344_op in H. discriminate H. Qed.

Lemma reff344_not1025 : ~ @Equation1025 Fin5 reff344_inst.
Proof. unfold Equation1025. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff344_inst, reff344_op in H. discriminate H. Qed.

Lemma reff344_not1026 : ~ @Equation1026 Fin5 reff344_inst.
Proof. unfold Equation1026. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff344_inst, reff344_op in H. discriminate H. Qed.

Lemma reff344_not1029 : ~ @Equation1029 Fin5 reff344_inst.
Proof. unfold Equation1029. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff344_inst, reff344_op in H. discriminate H. Qed.

Lemma reff344_not1035 : ~ @Equation1035 Fin5 reff344_inst.
Proof. unfold Equation1035. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff344_inst, reff344_op in H. discriminate H. Qed.

Lemma reff344_not1036 : ~ @Equation1036 Fin5 reff344_inst.
Proof. unfold Equation1036. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff344_inst, reff344_op in H. discriminate H. Qed.

Lemma reff344_not1039 : ~ @Equation1039 Fin5 reff344_inst.
Proof. unfold Equation1039. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff344_inst, reff344_op in H. discriminate H. Qed.

Lemma reff344_not1045 : ~ @Equation1045 Fin5 reff344_inst.
Proof. unfold Equation1045. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff344_inst, reff344_op in H. discriminate H. Qed.

Lemma reff344_not1046 : ~ @Equation1046 Fin5 reff344_inst.
Proof. unfold Equation1046. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff344_inst, reff344_op in H. discriminate H. Qed.

Lemma reff344_not1048 : ~ @Equation1048 Fin5 reff344_inst.
Proof. unfold Equation1048. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff344_inst, reff344_op in H. discriminate H. Qed.

Lemma reff344_not1049 : ~ @Equation1049 Fin5 reff344_inst.
Proof. unfold Equation1049. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff344_inst, reff344_op in H. discriminate H. Qed.

Lemma reff344_not1072 : ~ @Equation1072 Fin5 reff344_inst.
Proof. unfold Equation1072. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff344_inst, reff344_op in H. discriminate H. Qed.

Lemma reff344_not1075 : ~ @Equation1075 Fin5 reff344_inst.
Proof. unfold Equation1075. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff344_inst, reff344_op in H. discriminate H. Qed.

Lemma reff344_not1076 : ~ @Equation1076 Fin5 reff344_inst.
Proof. unfold Equation1076. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff344_inst, reff344_op in H. discriminate H. Qed.

Lemma reff344_not1083 : ~ @Equation1083 Fin5 reff344_inst.
Proof. unfold Equation1083. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff344_inst, reff344_op in H. discriminate H. Qed.

Lemma reff344_not1085 : ~ @Equation1085 Fin5 reff344_inst.
Proof. unfold Equation1085. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff344_inst, reff344_op in H. discriminate H. Qed.

Lemma reff344_not1110 : ~ @Equation1110 Fin5 reff344_inst.
Proof. unfold Equation1110. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff344_inst, reff344_op in H. discriminate H. Qed.

Lemma reff344_not1112 : ~ @Equation1112 Fin5 reff344_inst.
Proof. unfold Equation1112. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff344_inst, reff344_op in H. discriminate H. Qed.

Lemma reff344_not1119 : ~ @Equation1119 Fin5 reff344_inst.
Proof. unfold Equation1119. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff344_inst, reff344_op in H. discriminate H. Qed.

Lemma reff344_not1120 : ~ @Equation1120 Fin5 reff344_inst.
Proof. unfold Equation1120. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff344_inst, reff344_op in H. discriminate H. Qed.

Lemma reff344_not1223 : ~ @Equation1223 Fin5 reff344_inst.
Proof. unfold Equation1223. intro H. specialize (H F5_1). unfold magma_op, reff344_inst, reff344_op in H. discriminate H. Qed.

Lemma reff344_not1426 : ~ @Equation1426 Fin5 reff344_inst.
Proof. unfold Equation1426. intro H. specialize (H F5_1). unfold magma_op, reff344_inst, reff344_op in H. discriminate H. Qed.

Lemma reff344_not1630 : ~ @Equation1630 Fin5 reff344_inst.
Proof. unfold Equation1630. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff344_inst, reff344_op in H. discriminate H. Qed.

Lemma reff344_not1631 : ~ @Equation1631 Fin5 reff344_inst.
Proof. unfold Equation1631. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff344_inst, reff344_op in H. discriminate H. Qed.

Lemma reff344_not1634 : ~ @Equation1634 Fin5 reff344_inst.
Proof. unfold Equation1634. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff344_inst, reff344_op in H. discriminate H. Qed.

Lemma reff344_not1635 : ~ @Equation1635 Fin5 reff344_inst.
Proof. unfold Equation1635. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff344_inst, reff344_op in H. discriminate H. Qed.

Lemma reff344_not1638 : ~ @Equation1638 Fin5 reff344_inst.
Proof. unfold Equation1638. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff344_inst, reff344_op in H. discriminate H. Qed.

Lemma reff344_not1644 : ~ @Equation1644 Fin5 reff344_inst.
Proof. unfold Equation1644. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff344_inst, reff344_op in H. discriminate H. Qed.

Lemma reff344_not1647 : ~ @Equation1647 Fin5 reff344_inst.
Proof. unfold Equation1647. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff344_inst, reff344_op in H. discriminate H. Qed.

Lemma reff344_not1648 : ~ @Equation1648 Fin5 reff344_inst.
Proof. unfold Equation1648. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff344_inst, reff344_op in H. discriminate H. Qed.

Lemma reff344_not1655 : ~ @Equation1655 Fin5 reff344_inst.
Proof. unfold Equation1655. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff344_inst, reff344_op in H. discriminate H. Qed.

Lemma reff344_not1657 : ~ @Equation1657 Fin5 reff344_inst.
Proof. unfold Equation1657. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff344_inst, reff344_op in H. discriminate H. Qed.

Lemma reff344_not1681 : ~ @Equation1681 Fin5 reff344_inst.
Proof. unfold Equation1681. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff344_inst, reff344_op in H. discriminate H. Qed.

Lemma reff344_not1682 : ~ @Equation1682 Fin5 reff344_inst.
Proof. unfold Equation1682. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff344_inst, reff344_op in H. discriminate H. Qed.

Lemma reff344_not1685 : ~ @Equation1685 Fin5 reff344_inst.
Proof. unfold Equation1685. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff344_inst, reff344_op in H. discriminate H. Qed.

Lemma reff344_not1691 : ~ @Equation1691 Fin5 reff344_inst.
Proof. unfold Equation1691. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff344_inst, reff344_op in H. discriminate H. Qed.

Lemma reff344_not1692 : ~ @Equation1692 Fin5 reff344_inst.
Proof. unfold Equation1692. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff344_inst, reff344_op in H. discriminate H. Qed.

Lemma reff344_not1694 : ~ @Equation1694 Fin5 reff344_inst.
Proof. unfold Equation1694. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff344_inst, reff344_op in H. discriminate H. Qed.

Lemma reff344_not1695 : ~ @Equation1695 Fin5 reff344_inst.
Proof. unfold Equation1695. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff344_inst, reff344_op in H. discriminate H. Qed.

Lemma reff344_not1719 : ~ @Equation1719 Fin5 reff344_inst.
Proof. unfold Equation1719. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff344_inst, reff344_op in H. discriminate H. Qed.

Lemma reff344_not1721 : ~ @Equation1721 Fin5 reff344_inst.
Proof. unfold Equation1721. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff344_inst, reff344_op in H. discriminate H. Qed.

Lemma reff344_not1728 : ~ @Equation1728 Fin5 reff344_inst.
Proof. unfold Equation1728. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff344_inst, reff344_op in H. discriminate H. Qed.

Lemma reff344_not1729 : ~ @Equation1729 Fin5 reff344_inst.
Proof. unfold Equation1729. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff344_inst, reff344_op in H. discriminate H. Qed.

Lemma reff344_not1833 : ~ @Equation1833 Fin5 reff344_inst.
Proof. unfold Equation1833. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff344_inst, reff344_op in H. discriminate H. Qed.

Lemma reff344_not1834 : ~ @Equation1834 Fin5 reff344_inst.
Proof. unfold Equation1834. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff344_inst, reff344_op in H. discriminate H. Qed.

Lemma reff344_not1837 : ~ @Equation1837 Fin5 reff344_inst.
Proof. unfold Equation1837. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff344_inst, reff344_op in H. discriminate H. Qed.

Lemma reff344_not1840 : ~ @Equation1840 Fin5 reff344_inst.
Proof. unfold Equation1840. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff344_inst, reff344_op in H. discriminate H. Qed.

Lemma reff344_not1841 : ~ @Equation1841 Fin5 reff344_inst.
Proof. unfold Equation1841. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff344_inst, reff344_op in H. discriminate H. Qed.

Lemma reff344_not1847 : ~ @Equation1847 Fin5 reff344_inst.
Proof. unfold Equation1847. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff344_inst, reff344_op in H. discriminate H. Qed.

Lemma reff344_not1848 : ~ @Equation1848 Fin5 reff344_inst.
Proof. unfold Equation1848. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff344_inst, reff344_op in H. discriminate H. Qed.

Lemma reff344_not1851 : ~ @Equation1851 Fin5 reff344_inst.
Proof. unfold Equation1851. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff344_inst, reff344_op in H. discriminate H. Qed.

Lemma reff344_not1858 : ~ @Equation1858 Fin5 reff344_inst.
Proof. unfold Equation1858. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff344_inst, reff344_op in H. discriminate H. Qed.

Lemma reff344_not1860 : ~ @Equation1860 Fin5 reff344_inst.
Proof. unfold Equation1860. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff344_inst, reff344_op in H. discriminate H. Qed.

Lemma reff344_not1884 : ~ @Equation1884 Fin5 reff344_inst.
Proof. unfold Equation1884. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff344_inst, reff344_op in H. discriminate H. Qed.

Lemma reff344_not1885 : ~ @Equation1885 Fin5 reff344_inst.
Proof. unfold Equation1885. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff344_inst, reff344_op in H. discriminate H. Qed.

Lemma reff344_not1888 : ~ @Equation1888 Fin5 reff344_inst.
Proof. unfold Equation1888. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff344_inst, reff344_op in H. discriminate H. Qed.

Lemma reff344_not1895 : ~ @Equation1895 Fin5 reff344_inst.
Proof. unfold Equation1895. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff344_inst, reff344_op in H. discriminate H. Qed.

Lemma reff344_not1897 : ~ @Equation1897 Fin5 reff344_inst.
Proof. unfold Equation1897. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff344_inst, reff344_op in H. discriminate H. Qed.

Lemma reff344_not1921 : ~ @Equation1921 Fin5 reff344_inst.
Proof. unfold Equation1921. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff344_inst, reff344_op in H. discriminate H. Qed.

Lemma reff344_not1922 : ~ @Equation1922 Fin5 reff344_inst.
Proof. unfold Equation1922. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff344_inst, reff344_op in H. discriminate H. Qed.

Lemma reff344_not1924 : ~ @Equation1924 Fin5 reff344_inst.
Proof. unfold Equation1924. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff344_inst, reff344_op in H. discriminate H. Qed.

Lemma reff344_not1925 : ~ @Equation1925 Fin5 reff344_inst.
Proof. unfold Equation1925. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff344_inst, reff344_op in H. discriminate H. Qed.

Lemma reff344_not1931 : ~ @Equation1931 Fin5 reff344_inst.
Proof. unfold Equation1931. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff344_inst, reff344_op in H. discriminate H. Qed.

Lemma reff344_not1932 : ~ @Equation1932 Fin5 reff344_inst.
Proof. unfold Equation1932. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff344_inst, reff344_op in H. discriminate H. Qed.

Lemma reff344_not2035 : ~ @Equation2035 Fin5 reff344_inst.
Proof. unfold Equation2035. intro H. specialize (H F5_1). unfold magma_op, reff344_inst, reff344_op in H. discriminate H. Qed.

Lemma reff344_not2238 : ~ @Equation2238 Fin5 reff344_inst.
Proof. unfold Equation2238. intro H. specialize (H F5_1). unfold magma_op, reff344_inst, reff344_op in H. discriminate H. Qed.

Lemma reff344_not2442 : ~ @Equation2442 Fin5 reff344_inst.
Proof. unfold Equation2442. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff344_inst, reff344_op in H. discriminate H. Qed.

Lemma reff344_not2443 : ~ @Equation2443 Fin5 reff344_inst.
Proof. unfold Equation2443. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff344_inst, reff344_op in H. discriminate H. Qed.

Lemma reff344_not2446 : ~ @Equation2446 Fin5 reff344_inst.
Proof. unfold Equation2446. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff344_inst, reff344_op in H. discriminate H. Qed.

Lemma reff344_not2447 : ~ @Equation2447 Fin5 reff344_inst.
Proof. unfold Equation2447. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff344_inst, reff344_op in H. discriminate H. Qed.

Lemma reff344_not2450 : ~ @Equation2450 Fin5 reff344_inst.
Proof. unfold Equation2450. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff344_inst, reff344_op in H. discriminate H. Qed.

Lemma reff344_not2456 : ~ @Equation2456 Fin5 reff344_inst.
Proof. unfold Equation2456. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff344_inst, reff344_op in H. discriminate H. Qed.

Lemma reff344_not2459 : ~ @Equation2459 Fin5 reff344_inst.
Proof. unfold Equation2459. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff344_inst, reff344_op in H. discriminate H. Qed.

Lemma reff344_not2460 : ~ @Equation2460 Fin5 reff344_inst.
Proof. unfold Equation2460. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff344_inst, reff344_op in H. discriminate H. Qed.

Lemma reff344_not2467 : ~ @Equation2467 Fin5 reff344_inst.
Proof. unfold Equation2467. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff344_inst, reff344_op in H. discriminate H. Qed.

Lemma reff344_not2469 : ~ @Equation2469 Fin5 reff344_inst.
Proof. unfold Equation2469. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff344_inst, reff344_op in H. discriminate H. Qed.

Lemma reff344_not2493 : ~ @Equation2493 Fin5 reff344_inst.
Proof. unfold Equation2493. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff344_inst, reff344_op in H. discriminate H. Qed.

Lemma reff344_not2494 : ~ @Equation2494 Fin5 reff344_inst.
Proof. unfold Equation2494. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff344_inst, reff344_op in H. discriminate H. Qed.

Lemma reff344_not2497 : ~ @Equation2497 Fin5 reff344_inst.
Proof. unfold Equation2497. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff344_inst, reff344_op in H. discriminate H. Qed.

Lemma reff344_not2503 : ~ @Equation2503 Fin5 reff344_inst.
Proof. unfold Equation2503. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff344_inst, reff344_op in H. discriminate H. Qed.

Lemma reff344_not2504 : ~ @Equation2504 Fin5 reff344_inst.
Proof. unfold Equation2504. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff344_inst, reff344_op in H. discriminate H. Qed.

Lemma reff344_not2506 : ~ @Equation2506 Fin5 reff344_inst.
Proof. unfold Equation2506. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff344_inst, reff344_op in H. discriminate H. Qed.

Lemma reff344_not2507 : ~ @Equation2507 Fin5 reff344_inst.
Proof. unfold Equation2507. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff344_inst, reff344_op in H. discriminate H. Qed.

Lemma reff344_not2531 : ~ @Equation2531 Fin5 reff344_inst.
Proof. unfold Equation2531. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff344_inst, reff344_op in H. discriminate H. Qed.

Lemma reff344_not2533 : ~ @Equation2533 Fin5 reff344_inst.
Proof. unfold Equation2533. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff344_inst, reff344_op in H. discriminate H. Qed.

Lemma reff344_not2540 : ~ @Equation2540 Fin5 reff344_inst.
Proof. unfold Equation2540. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff344_inst, reff344_op in H. discriminate H. Qed.

Lemma reff344_not2541 : ~ @Equation2541 Fin5 reff344_inst.
Proof. unfold Equation2541. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff344_inst, reff344_op in H. discriminate H. Qed.

Lemma reff344_not2645 : ~ @Equation2645 Fin5 reff344_inst.
Proof. unfold Equation2645. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff344_inst, reff344_op in H. discriminate H. Qed.

Lemma reff344_not2646 : ~ @Equation2646 Fin5 reff344_inst.
Proof. unfold Equation2646. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff344_inst, reff344_op in H. discriminate H. Qed.

Lemma reff344_not2649 : ~ @Equation2649 Fin5 reff344_inst.
Proof. unfold Equation2649. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff344_inst, reff344_op in H. discriminate H. Qed.

Lemma reff344_not2650 : ~ @Equation2650 Fin5 reff344_inst.
Proof. unfold Equation2650. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff344_inst, reff344_op in H. discriminate H. Qed.

Lemma reff344_not2653 : ~ @Equation2653 Fin5 reff344_inst.
Proof. unfold Equation2653. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff344_inst, reff344_op in H. discriminate H. Qed.

Lemma reff344_not2659 : ~ @Equation2659 Fin5 reff344_inst.
Proof. unfold Equation2659. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff344_inst, reff344_op in H. discriminate H. Qed.

Lemma reff344_not2660 : ~ @Equation2660 Fin5 reff344_inst.
Proof. unfold Equation2660. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff344_inst, reff344_op in H. discriminate H. Qed.

Lemma reff344_not2663 : ~ @Equation2663 Fin5 reff344_inst.
Proof. unfold Equation2663. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff344_inst, reff344_op in H. discriminate H. Qed.

Lemma reff344_not2669 : ~ @Equation2669 Fin5 reff344_inst.
Proof. unfold Equation2669. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff344_inst, reff344_op in H. discriminate H. Qed.

Lemma reff344_not2670 : ~ @Equation2670 Fin5 reff344_inst.
Proof. unfold Equation2670. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff344_inst, reff344_op in H. discriminate H. Qed.

Lemma reff344_not2672 : ~ @Equation2672 Fin5 reff344_inst.
Proof. unfold Equation2672. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff344_inst, reff344_op in H. discriminate H. Qed.

Lemma reff344_not2673 : ~ @Equation2673 Fin5 reff344_inst.
Proof. unfold Equation2673. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff344_inst, reff344_op in H. discriminate H. Qed.

Lemma reff344_not2696 : ~ @Equation2696 Fin5 reff344_inst.
Proof. unfold Equation2696. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff344_inst, reff344_op in H. discriminate H. Qed.

Lemma reff344_not2699 : ~ @Equation2699 Fin5 reff344_inst.
Proof. unfold Equation2699. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff344_inst, reff344_op in H. discriminate H. Qed.

Lemma reff344_not2700 : ~ @Equation2700 Fin5 reff344_inst.
Proof. unfold Equation2700. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff344_inst, reff344_op in H. discriminate H. Qed.

Lemma reff344_not2707 : ~ @Equation2707 Fin5 reff344_inst.
Proof. unfold Equation2707. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff344_inst, reff344_op in H. discriminate H. Qed.

Lemma reff344_not2709 : ~ @Equation2709 Fin5 reff344_inst.
Proof. unfold Equation2709. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff344_inst, reff344_op in H. discriminate H. Qed.

Lemma reff344_not2734 : ~ @Equation2734 Fin5 reff344_inst.
Proof. unfold Equation2734. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff344_inst, reff344_op in H. discriminate H. Qed.

Lemma reff344_not2736 : ~ @Equation2736 Fin5 reff344_inst.
Proof. unfold Equation2736. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff344_inst, reff344_op in H. discriminate H. Qed.

Lemma reff344_not2743 : ~ @Equation2743 Fin5 reff344_inst.
Proof. unfold Equation2743. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff344_inst, reff344_op in H. discriminate H. Qed.

Lemma reff344_not2744 : ~ @Equation2744 Fin5 reff344_inst.
Proof. unfold Equation2744. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff344_inst, reff344_op in H. discriminate H. Qed.

Lemma reff344_not2847 : ~ @Equation2847 Fin5 reff344_inst.
Proof. unfold Equation2847. intro H. specialize (H F5_1). unfold magma_op, reff344_inst, reff344_op in H. discriminate H. Qed.

Lemma reff344_not3051 : ~ @Equation3051 Fin5 reff344_inst.
Proof. unfold Equation3051. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff344_inst, reff344_op in H. discriminate H. Qed.

Lemma reff344_not3052 : ~ @Equation3052 Fin5 reff344_inst.
Proof. unfold Equation3052. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff344_inst, reff344_op in H. discriminate H. Qed.

Lemma reff344_not3055 : ~ @Equation3055 Fin5 reff344_inst.
Proof. unfold Equation3055. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff344_inst, reff344_op in H. discriminate H. Qed.

Lemma reff344_not3056 : ~ @Equation3056 Fin5 reff344_inst.
Proof. unfold Equation3056. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff344_inst, reff344_op in H. discriminate H. Qed.

Lemma reff344_not3059 : ~ @Equation3059 Fin5 reff344_inst.
Proof. unfold Equation3059. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff344_inst, reff344_op in H. discriminate H. Qed.

Lemma reff344_not3065 : ~ @Equation3065 Fin5 reff344_inst.
Proof. unfold Equation3065. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff344_inst, reff344_op in H. discriminate H. Qed.

Lemma reff344_not3068 : ~ @Equation3068 Fin5 reff344_inst.
Proof. unfold Equation3068. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff344_inst, reff344_op in H. discriminate H. Qed.

Lemma reff344_not3069 : ~ @Equation3069 Fin5 reff344_inst.
Proof. unfold Equation3069. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff344_inst, reff344_op in H. discriminate H. Qed.

Lemma reff344_not3076 : ~ @Equation3076 Fin5 reff344_inst.
Proof. unfold Equation3076. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff344_inst, reff344_op in H. discriminate H. Qed.

Lemma reff344_not3078 : ~ @Equation3078 Fin5 reff344_inst.
Proof. unfold Equation3078. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff344_inst, reff344_op in H. discriminate H. Qed.

Lemma reff344_not3102 : ~ @Equation3102 Fin5 reff344_inst.
Proof. unfold Equation3102. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff344_inst, reff344_op in H. discriminate H. Qed.

Lemma reff344_not3103 : ~ @Equation3103 Fin5 reff344_inst.
Proof. unfold Equation3103. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff344_inst, reff344_op in H. discriminate H. Qed.

Lemma reff344_not3106 : ~ @Equation3106 Fin5 reff344_inst.
Proof. unfold Equation3106. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff344_inst, reff344_op in H. discriminate H. Qed.

Lemma reff344_not3112 : ~ @Equation3112 Fin5 reff344_inst.
Proof. unfold Equation3112. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff344_inst, reff344_op in H. discriminate H. Qed.

Lemma reff344_not3113 : ~ @Equation3113 Fin5 reff344_inst.
Proof. unfold Equation3113. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff344_inst, reff344_op in H. discriminate H. Qed.

Lemma reff344_not3115 : ~ @Equation3115 Fin5 reff344_inst.
Proof. unfold Equation3115. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff344_inst, reff344_op in H. discriminate H. Qed.

Lemma reff344_not3116 : ~ @Equation3116 Fin5 reff344_inst.
Proof. unfold Equation3116. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff344_inst, reff344_op in H. discriminate H. Qed.

Lemma reff344_not3140 : ~ @Equation3140 Fin5 reff344_inst.
Proof. unfold Equation3140. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff344_inst, reff344_op in H. discriminate H. Qed.

Lemma reff344_not3142 : ~ @Equation3142 Fin5 reff344_inst.
Proof. unfold Equation3142. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff344_inst, reff344_op in H. discriminate H. Qed.

Lemma reff344_not3149 : ~ @Equation3149 Fin5 reff344_inst.
Proof. unfold Equation3149. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff344_inst, reff344_op in H. discriminate H. Qed.

Lemma reff344_not3150 : ~ @Equation3150 Fin5 reff344_inst.
Proof. unfold Equation3150. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff344_inst, reff344_op in H. discriminate H. Qed.

Lemma reff344_not3253 : ~ @Equation3253 Fin5 reff344_inst.
Proof. unfold Equation3253. intro H. specialize (H F5_1). unfold magma_op, reff344_inst, reff344_op in H. discriminate H. Qed.

Lemma reff344_not3457 : ~ @Equation3457 Fin5 reff344_inst.
Proof. unfold Equation3457. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff344_inst, reff344_op in H. discriminate H. Qed.

Lemma reff344_not3458 : ~ @Equation3458 Fin5 reff344_inst.
Proof. unfold Equation3458. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff344_inst, reff344_op in H. discriminate H. Qed.

Lemma reff344_not3461 : ~ @Equation3461 Fin5 reff344_inst.
Proof. unfold Equation3461. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff344_inst, reff344_op in H. discriminate H. Qed.

Lemma reff344_not3462 : ~ @Equation3462 Fin5 reff344_inst.
Proof. unfold Equation3462. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff344_inst, reff344_op in H. discriminate H. Qed.

Lemma reff344_not3465 : ~ @Equation3465 Fin5 reff344_inst.
Proof. unfold Equation3465. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff344_inst, reff344_op in H. discriminate H. Qed.

Lemma reff344_not3474 : ~ @Equation3474 Fin5 reff344_inst.
Proof. unfold Equation3474. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff344_inst, reff344_op in H. discriminate H. Qed.

Lemma reff344_not3475 : ~ @Equation3475 Fin5 reff344_inst.
Proof. unfold Equation3475. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff344_inst, reff344_op in H. discriminate H. Qed.

Lemma reff344_not3482 : ~ @Equation3482 Fin5 reff344_inst.
Proof. unfold Equation3482. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff344_inst, reff344_op in H. discriminate H. Qed.

Lemma reff344_not3484 : ~ @Equation3484 Fin5 reff344_inst.
Proof. unfold Equation3484. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff344_inst, reff344_op in H. discriminate H. Qed.

Lemma reff344_not3511 : ~ @Equation3511 Fin5 reff344_inst.
Proof. unfold Equation3511. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff344_inst, reff344_op in H. discriminate H. Qed.

Lemma reff344_not3512 : ~ @Equation3512 Fin5 reff344_inst.
Proof. unfold Equation3512. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff344_inst, reff344_op in H. discriminate H. Qed.

Lemma reff344_not3519 : ~ @Equation3519 Fin5 reff344_inst.
Proof. unfold Equation3519. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff344_inst, reff344_op in H. discriminate H. Qed.

Lemma reff344_not3521 : ~ @Equation3521 Fin5 reff344_inst.
Proof. unfold Equation3521. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff344_inst, reff344_op in H. discriminate H. Qed.

Lemma reff344_not3545 : ~ @Equation3545 Fin5 reff344_inst.
Proof. unfold Equation3545. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff344_inst, reff344_op in H. discriminate H. Qed.

Lemma reff344_not3546 : ~ @Equation3546 Fin5 reff344_inst.
Proof. unfold Equation3546. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff344_inst, reff344_op in H. discriminate H. Qed.

Lemma reff344_not3548 : ~ @Equation3548 Fin5 reff344_inst.
Proof. unfold Equation3548. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff344_inst, reff344_op in H. discriminate H. Qed.

Lemma reff344_not3549 : ~ @Equation3549 Fin5 reff344_inst.
Proof. unfold Equation3549. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff344_inst, reff344_op in H. discriminate H. Qed.

Lemma reff344_not3555 : ~ @Equation3555 Fin5 reff344_inst.
Proof. unfold Equation3555. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff344_inst, reff344_op in H. discriminate H. Qed.

Lemma reff344_not3558 : ~ @Equation3558 Fin5 reff344_inst.
Proof. unfold Equation3558. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff344_inst, reff344_op in H. discriminate H. Qed.

Lemma reff344_not3660 : ~ @Equation3660 Fin5 reff344_inst.
Proof. unfold Equation3660. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff344_inst, reff344_op in H. discriminate H. Qed.

Lemma reff344_not3661 : ~ @Equation3661 Fin5 reff344_inst.
Proof. unfold Equation3661. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff344_inst, reff344_op in H. discriminate H. Qed.

Lemma reff344_not3664 : ~ @Equation3664 Fin5 reff344_inst.
Proof. unfold Equation3664. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff344_inst, reff344_op in H. discriminate H. Qed.

Lemma reff344_not3667 : ~ @Equation3667 Fin5 reff344_inst.
Proof. unfold Equation3667. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff344_inst, reff344_op in H. discriminate H. Qed.

Lemma reff344_not3668 : ~ @Equation3668 Fin5 reff344_inst.
Proof. unfold Equation3668. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff344_inst, reff344_op in H. discriminate H. Qed.

Lemma reff344_not3674 : ~ @Equation3674 Fin5 reff344_inst.
Proof. unfold Equation3674. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff344_inst, reff344_op in H. discriminate H. Qed.

Lemma reff344_not3675 : ~ @Equation3675 Fin5 reff344_inst.
Proof. unfold Equation3675. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff344_inst, reff344_op in H. discriminate H. Qed.

Lemma reff344_not3678 : ~ @Equation3678 Fin5 reff344_inst.
Proof. unfold Equation3678. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff344_inst, reff344_op in H. discriminate H. Qed.

Lemma reff344_not3685 : ~ @Equation3685 Fin5 reff344_inst.
Proof. unfold Equation3685. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff344_inst, reff344_op in H. discriminate H. Qed.

Lemma reff344_not3687 : ~ @Equation3687 Fin5 reff344_inst.
Proof. unfold Equation3687. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff344_inst, reff344_op in H. discriminate H. Qed.

Lemma reff344_not3714 : ~ @Equation3714 Fin5 reff344_inst.
Proof. unfold Equation3714. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff344_inst, reff344_op in H. discriminate H. Qed.

Lemma reff344_not3721 : ~ @Equation3721 Fin5 reff344_inst.
Proof. unfold Equation3721. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff344_inst, reff344_op in H. discriminate H. Qed.

Lemma reff344_not3722 : ~ @Equation3722 Fin5 reff344_inst.
Proof. unfold Equation3722. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff344_inst, reff344_op in H. discriminate H. Qed.

Lemma reff344_not3724 : ~ @Equation3724 Fin5 reff344_inst.
Proof. unfold Equation3724. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff344_inst, reff344_op in H. discriminate H. Qed.

Lemma reff344_not3725 : ~ @Equation3725 Fin5 reff344_inst.
Proof. unfold Equation3725. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff344_inst, reff344_op in H. discriminate H. Qed.

Lemma reff344_not3749 : ~ @Equation3749 Fin5 reff344_inst.
Proof. unfold Equation3749. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff344_inst, reff344_op in H. discriminate H. Qed.

Lemma reff344_not3751 : ~ @Equation3751 Fin5 reff344_inst.
Proof. unfold Equation3751. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff344_inst, reff344_op in H. discriminate H. Qed.

Lemma reff344_not3761 : ~ @Equation3761 Fin5 reff344_inst.
Proof. unfold Equation3761. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff344_inst, reff344_op in H. discriminate H. Qed.

Lemma reff344_not3862 : ~ @Equation3862 Fin5 reff344_inst.
Proof. unfold Equation3862. intro H. specialize (H F5_1). unfold magma_op, reff344_inst, reff344_op in H. discriminate H. Qed.

Lemma reff344_not4066 : ~ @Equation4066 Fin5 reff344_inst.
Proof. unfold Equation4066. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff344_inst, reff344_op in H. discriminate H. Qed.

Lemma reff344_not4067 : ~ @Equation4067 Fin5 reff344_inst.
Proof. unfold Equation4067. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff344_inst, reff344_op in H. discriminate H. Qed.

Lemma reff344_not4070 : ~ @Equation4070 Fin5 reff344_inst.
Proof. unfold Equation4070. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff344_inst, reff344_op in H. discriminate H. Qed.

Lemma reff344_not4071 : ~ @Equation4071 Fin5 reff344_inst.
Proof. unfold Equation4071. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff344_inst, reff344_op in H. discriminate H. Qed.

Lemma reff344_not4074 : ~ @Equation4074 Fin5 reff344_inst.
Proof. unfold Equation4074. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff344_inst, reff344_op in H. discriminate H. Qed.

Lemma reff344_not4080 : ~ @Equation4080 Fin5 reff344_inst.
Proof. unfold Equation4080. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff344_inst, reff344_op in H. discriminate H. Qed.

Lemma reff344_not4083 : ~ @Equation4083 Fin5 reff344_inst.
Proof. unfold Equation4083. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff344_inst, reff344_op in H. discriminate H. Qed.

Lemma reff344_not4084 : ~ @Equation4084 Fin5 reff344_inst.
Proof. unfold Equation4084. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff344_inst, reff344_op in H. discriminate H. Qed.

Lemma reff344_not4091 : ~ @Equation4091 Fin5 reff344_inst.
Proof. unfold Equation4091. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff344_inst, reff344_op in H. discriminate H. Qed.

Lemma reff344_not4093 : ~ @Equation4093 Fin5 reff344_inst.
Proof. unfold Equation4093. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff344_inst, reff344_op in H. discriminate H. Qed.

Lemma reff344_not4120 : ~ @Equation4120 Fin5 reff344_inst.
Proof. unfold Equation4120. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff344_inst, reff344_op in H. discriminate H. Qed.

Lemma reff344_not4121 : ~ @Equation4121 Fin5 reff344_inst.
Proof. unfold Equation4121. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff344_inst, reff344_op in H. discriminate H. Qed.

Lemma reff344_not4128 : ~ @Equation4128 Fin5 reff344_inst.
Proof. unfold Equation4128. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff344_inst, reff344_op in H. discriminate H. Qed.

Lemma reff344_not4130 : ~ @Equation4130 Fin5 reff344_inst.
Proof. unfold Equation4130. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff344_inst, reff344_op in H. discriminate H. Qed.

Lemma reff344_not4155 : ~ @Equation4155 Fin5 reff344_inst.
Proof. unfold Equation4155. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff344_inst, reff344_op in H. discriminate H. Qed.

Lemma reff344_not4157 : ~ @Equation4157 Fin5 reff344_inst.
Proof. unfold Equation4157. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff344_inst, reff344_op in H. discriminate H. Qed.

Lemma reff344_not4158 : ~ @Equation4158 Fin5 reff344_inst.
Proof. unfold Equation4158. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff344_inst, reff344_op in H. discriminate H. Qed.

Lemma reff344_not4164 : ~ @Equation4164 Fin5 reff344_inst.
Proof. unfold Equation4164. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff344_inst, reff344_op in H. discriminate H. Qed.

Lemma reff344_not4167 : ~ @Equation4167 Fin5 reff344_inst.
Proof. unfold Equation4167. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff344_inst, reff344_op in H. discriminate H. Qed.

Lemma reff344_not4268 : ~ @Equation4268 Fin5 reff344_inst.
Proof. unfold Equation4268. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff344_inst, reff344_op in H. discriminate H. Qed.

Lemma reff344_not4269 : ~ @Equation4269 Fin5 reff344_inst.
Proof. unfold Equation4269. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff344_inst, reff344_op in H. discriminate H. Qed.

Lemma reff344_not4272 : ~ @Equation4272 Fin5 reff344_inst.
Proof. unfold Equation4272. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff344_inst, reff344_op in H. discriminate H. Qed.

Lemma reff344_not4275 : ~ @Equation4275 Fin5 reff344_inst.
Proof. unfold Equation4275. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff344_inst, reff344_op in H. discriminate H. Qed.

Lemma reff344_not4276 : ~ @Equation4276 Fin5 reff344_inst.
Proof. unfold Equation4276. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff344_inst, reff344_op in H. discriminate H. Qed.

Lemma reff344_not4283 : ~ @Equation4283 Fin5 reff344_inst.
Proof. unfold Equation4283. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff344_inst, reff344_op in H. discriminate H. Qed.

Lemma reff344_not4284 : ~ @Equation4284 Fin5 reff344_inst.
Proof. unfold Equation4284. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff344_inst, reff344_op in H. discriminate H. Qed.

Lemma reff344_not4290 : ~ @Equation4290 Fin5 reff344_inst.
Proof. unfold Equation4290. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff344_inst, reff344_op in H. discriminate H. Qed.

Lemma reff344_not4291 : ~ @Equation4291 Fin5 reff344_inst.
Proof. unfold Equation4291. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff344_inst, reff344_op in H. discriminate H. Qed.

Lemma reff344_not4293 : ~ @Equation4293 Fin5 reff344_inst.
Proof. unfold Equation4293. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff344_inst, reff344_op in H. discriminate H. Qed.

Lemma reff344_not4314 : ~ @Equation4314 Fin5 reff344_inst.
Proof. unfold Equation4314. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff344_inst, reff344_op in H. discriminate H. Qed.

Lemma reff344_not4321 : ~ @Equation4321 Fin5 reff344_inst.
Proof. unfold Equation4321. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff344_inst, reff344_op in H. discriminate H. Qed.

Lemma reff344_not4343 : ~ @Equation4343 Fin5 reff344_inst.
Proof. unfold Equation4343. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff344_inst, reff344_op in H. discriminate H. Qed.

Lemma reff344_not4380 : ~ @Equation4380 Fin5 reff344_inst.
Proof. unfold Equation4380. intro H. specialize (H F5_1). unfold magma_op, reff344_inst, reff344_op in H. discriminate H. Qed.

Lemma reff344_not4583 : ~ @Equation4583 Fin5 reff344_inst.
Proof. unfold Equation4583. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff344_inst, reff344_op in H. discriminate H. Qed.

Lemma reff344_not4584 : ~ @Equation4584 Fin5 reff344_inst.
Proof. unfold Equation4584. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff344_inst, reff344_op in H. discriminate H. Qed.

Lemma reff344_not4587 : ~ @Equation4587 Fin5 reff344_inst.
Proof. unfold Equation4587. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff344_inst, reff344_op in H. discriminate H. Qed.

Lemma reff344_not4588 : ~ @Equation4588 Fin5 reff344_inst.
Proof. unfold Equation4588. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff344_inst, reff344_op in H. discriminate H. Qed.

Lemma reff344_not4591 : ~ @Equation4591 Fin5 reff344_inst.
Proof. unfold Equation4591. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff344_inst, reff344_op in H. discriminate H. Qed.

Lemma reff344_not4598 : ~ @Equation4598 Fin5 reff344_inst.
Proof. unfold Equation4598. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff344_inst, reff344_op in H. discriminate H. Qed.

Lemma reff344_not4599 : ~ @Equation4599 Fin5 reff344_inst.
Proof. unfold Equation4599. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff344_inst, reff344_op in H. discriminate H. Qed.

Lemma reff344_not4606 : ~ @Equation4606 Fin5 reff344_inst.
Proof. unfold Equation4606. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff344_inst, reff344_op in H. discriminate H. Qed.

Lemma reff344_not4608 : ~ @Equation4608 Fin5 reff344_inst.
Proof. unfold Equation4608. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff344_inst, reff344_op in H. discriminate H. Qed.

Lemma reff344_not4629 : ~ @Equation4629 Fin5 reff344_inst.
Proof. unfold Equation4629. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff344_inst, reff344_op in H. discriminate H. Qed.

Lemma reff344_not4635 : ~ @Equation4635 Fin5 reff344_inst.
Proof. unfold Equation4635. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff344_inst, reff344_op in H. discriminate H. Qed.

Lemma reff344_not4636 : ~ @Equation4636 Fin5 reff344_inst.
Proof. unfold Equation4636. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff344_inst, reff344_op in H. discriminate H. Qed.

Lemma reff344_not4658 : ~ @Equation4658 Fin5 reff344_inst.
Proof. unfold Equation4658. intro H. specialize (H F5_0 F5_1). unfold magma_op, reff344_inst, reff344_op in H. discriminate H. Qed.

(** ---- reff346 (Fin4) ---- *)

Definition reff346_op (x y : Fin4) : Fin4 :=
  match x, y with
  | F4_0, F4_0 => F4_0 | F4_0, F4_1 => F4_0 | F4_0, F4_2 => F4_0 | F4_0, F4_3 => F4_0
  | F4_1, F4_0 => F4_0 | F4_1, F4_1 => F4_2 | F4_1, F4_2 => F4_0 | F4_1, F4_3 => F4_2
  | F4_2, F4_0 => F4_2 | F4_2, F4_1 => F4_2 | F4_2, F4_2 => F4_2 | F4_2, F4_3 => F4_2
  | F4_3, F4_0 => F4_2 | F4_3, F4_1 => F4_0 | F4_3, F4_2 => F4_2 | F4_3, F4_3 => F4_0
  end.

#[local] Instance reff346_inst : Magma Fin4 := {| magma_op := reff346_op |}.

Lemma reff346_sat379 : @Equation379 Fin4 reff346_inst.
Proof. unfold Equation379, magma_op, reff346_inst, reff346_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff346_sat4271 : @Equation4271 Fin4 reff346_inst.
Proof. unfold Equation4271, magma_op, reff346_inst, reff346_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff346_not47 : ~ @Equation47 Fin4 reff346_inst.
Proof. unfold Equation47. intro H. specialize (H F4_1). unfold magma_op, reff346_inst, reff346_op in H. discriminate H. Qed.

Lemma reff346_not99 : ~ @Equation99 Fin4 reff346_inst.
Proof. unfold Equation99. intro H. specialize (H F4_1). unfold magma_op, reff346_inst, reff346_op in H. discriminate H. Qed.

Lemma reff346_not151 : ~ @Equation151 Fin4 reff346_inst.
Proof. unfold Equation151. intro H. specialize (H F4_1). unfold magma_op, reff346_inst, reff346_op in H. discriminate H. Qed.

Lemma reff346_not203 : ~ @Equation203 Fin4 reff346_inst.
Proof. unfold Equation203. intro H. specialize (H F4_1). unfold magma_op, reff346_inst, reff346_op in H. discriminate H. Qed.

Lemma reff346_not255 : ~ @Equation255 Fin4 reff346_inst.
Proof. unfold Equation255. intro H. specialize (H F4_1). unfold magma_op, reff346_inst, reff346_op in H. discriminate H. Qed.

Lemma reff346_not411 : ~ @Equation411 Fin4 reff346_inst.
Proof. unfold Equation411. intro H. specialize (H F4_1). unfold magma_op, reff346_inst, reff346_op in H. discriminate H. Qed.

Lemma reff346_not614 : ~ @Equation614 Fin4 reff346_inst.
Proof. unfold Equation614. intro H. specialize (H F4_1). unfold magma_op, reff346_inst, reff346_op in H. discriminate H. Qed.

Lemma reff346_not817 : ~ @Equation817 Fin4 reff346_inst.
Proof. unfold Equation817. intro H. specialize (H F4_1). unfold magma_op, reff346_inst, reff346_op in H. discriminate H. Qed.

Lemma reff346_not1020 : ~ @Equation1020 Fin4 reff346_inst.
Proof. unfold Equation1020. intro H. specialize (H F4_1). unfold magma_op, reff346_inst, reff346_op in H. discriminate H. Qed.

Lemma reff346_not1223 : ~ @Equation1223 Fin4 reff346_inst.
Proof. unfold Equation1223. intro H. specialize (H F4_1). unfold magma_op, reff346_inst, reff346_op in H. discriminate H. Qed.

Lemma reff346_not1426 : ~ @Equation1426 Fin4 reff346_inst.
Proof. unfold Equation1426. intro H. specialize (H F4_1). unfold magma_op, reff346_inst, reff346_op in H. discriminate H. Qed.

Lemma reff346_not1629 : ~ @Equation1629 Fin4 reff346_inst.
Proof. unfold Equation1629. intro H. specialize (H F4_1). unfold magma_op, reff346_inst, reff346_op in H. discriminate H. Qed.

Lemma reff346_not1832 : ~ @Equation1832 Fin4 reff346_inst.
Proof. unfold Equation1832. intro H. specialize (H F4_1). unfold magma_op, reff346_inst, reff346_op in H. discriminate H. Qed.

Lemma reff346_not2035 : ~ @Equation2035 Fin4 reff346_inst.
Proof. unfold Equation2035. intro H. specialize (H F4_1). unfold magma_op, reff346_inst, reff346_op in H. discriminate H. Qed.

Lemma reff346_not2238 : ~ @Equation2238 Fin4 reff346_inst.
Proof. unfold Equation2238. intro H. specialize (H F4_1). unfold magma_op, reff346_inst, reff346_op in H. discriminate H. Qed.

Lemma reff346_not2441 : ~ @Equation2441 Fin4 reff346_inst.
Proof. unfold Equation2441. intro H. specialize (H F4_1). unfold magma_op, reff346_inst, reff346_op in H. discriminate H. Qed.

Lemma reff346_not2644 : ~ @Equation2644 Fin4 reff346_inst.
Proof. unfold Equation2644. intro H. specialize (H F4_1). unfold magma_op, reff346_inst, reff346_op in H. discriminate H. Qed.

Lemma reff346_not2847 : ~ @Equation2847 Fin4 reff346_inst.
Proof. unfold Equation2847. intro H. specialize (H F4_1). unfold magma_op, reff346_inst, reff346_op in H. discriminate H. Qed.

Lemma reff346_not3050 : ~ @Equation3050 Fin4 reff346_inst.
Proof. unfold Equation3050. intro H. specialize (H F4_1). unfold magma_op, reff346_inst, reff346_op in H. discriminate H. Qed.

Lemma reff346_not3253 : ~ @Equation3253 Fin4 reff346_inst.
Proof. unfold Equation3253. intro H. specialize (H F4_1). unfold magma_op, reff346_inst, reff346_op in H. discriminate H. Qed.

Lemma reff346_not3456 : ~ @Equation3456 Fin4 reff346_inst.
Proof. unfold Equation3456. intro H. specialize (H F4_1). unfold magma_op, reff346_inst, reff346_op in H. discriminate H. Qed.

Lemma reff346_not3664 : ~ @Equation3664 Fin4 reff346_inst.
Proof. unfold Equation3664. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff346_inst, reff346_op in H. discriminate H. Qed.

Lemma reff346_not3665 : ~ @Equation3665 Fin4 reff346_inst.
Proof. unfold Equation3665. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff346_inst, reff346_op in H. discriminate H. Qed.

Lemma reff346_not3667 : ~ @Equation3667 Fin4 reff346_inst.
Proof. unfold Equation3667. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff346_inst, reff346_op in H. discriminate H. Qed.

Lemma reff346_not3668 : ~ @Equation3668 Fin4 reff346_inst.
Proof. unfold Equation3668. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff346_inst, reff346_op in H. discriminate H. Qed.

Lemma reff346_not3674 : ~ @Equation3674 Fin4 reff346_inst.
Proof. unfold Equation3674. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff346_inst, reff346_op in H. discriminate H. Qed.

Lemma reff346_not3675 : ~ @Equation3675 Fin4 reff346_inst.
Proof. unfold Equation3675. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff346_inst, reff346_op in H. discriminate H. Qed.

Lemma reff346_not3677 : ~ @Equation3677 Fin4 reff346_inst.
Proof. unfold Equation3677. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff346_inst, reff346_op in H. discriminate H. Qed.

Lemma reff346_not3678 : ~ @Equation3678 Fin4 reff346_inst.
Proof. unfold Equation3678. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff346_inst, reff346_op in H. discriminate H. Qed.

Lemma reff346_not3684 : ~ @Equation3684 Fin4 reff346_inst.
Proof. unfold Equation3684. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff346_inst, reff346_op in H. discriminate H. Qed.

Lemma reff346_not3685 : ~ @Equation3685 Fin4 reff346_inst.
Proof. unfold Equation3685. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff346_inst, reff346_op in H. discriminate H. Qed.

Lemma reff346_not3687 : ~ @Equation3687 Fin4 reff346_inst.
Proof. unfold Equation3687. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff346_inst, reff346_op in H. discriminate H. Qed.

Lemma reff346_not3712 : ~ @Equation3712 Fin4 reff346_inst.
Proof. unfold Equation3712. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff346_inst, reff346_op in H. discriminate H. Qed.

Lemma reff346_not3714 : ~ @Equation3714 Fin4 reff346_inst.
Proof. unfold Equation3714. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff346_inst, reff346_op in H. discriminate H. Qed.

Lemma reff346_not3748 : ~ @Equation3748 Fin4 reff346_inst.
Proof. unfold Equation3748. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff346_inst, reff346_op in H. discriminate H. Qed.

Lemma reff346_not3749 : ~ @Equation3749 Fin4 reff346_inst.
Proof. unfold Equation3749. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff346_inst, reff346_op in H. discriminate H. Qed.

Lemma reff346_not3751 : ~ @Equation3751 Fin4 reff346_inst.
Proof. unfold Equation3751. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff346_inst, reff346_op in H. discriminate H. Qed.

Lemma reff346_not3752 : ~ @Equation3752 Fin4 reff346_inst.
Proof. unfold Equation3752. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff346_inst, reff346_op in H. discriminate H. Qed.

Lemma reff346_not3759 : ~ @Equation3759 Fin4 reff346_inst.
Proof. unfold Equation3759. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff346_inst, reff346_op in H. discriminate H. Qed.

Lemma reff346_not3761 : ~ @Equation3761 Fin4 reff346_inst.
Proof. unfold Equation3761. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff346_inst, reff346_op in H. discriminate H. Qed.

Lemma reff346_not3862 : ~ @Equation3862 Fin4 reff346_inst.
Proof. unfold Equation3862. intro H. specialize (H F4_1). unfold magma_op, reff346_inst, reff346_op in H. discriminate H. Qed.

Lemma reff346_not4070 : ~ @Equation4070 Fin4 reff346_inst.
Proof. unfold Equation4070. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff346_inst, reff346_op in H. discriminate H. Qed.

Lemma reff346_not4071 : ~ @Equation4071 Fin4 reff346_inst.
Proof. unfold Equation4071. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff346_inst, reff346_op in H. discriminate H. Qed.

Lemma reff346_not4073 : ~ @Equation4073 Fin4 reff346_inst.
Proof. unfold Equation4073. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff346_inst, reff346_op in H. discriminate H. Qed.

Lemma reff346_not4074 : ~ @Equation4074 Fin4 reff346_inst.
Proof. unfold Equation4074. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff346_inst, reff346_op in H. discriminate H. Qed.

Lemma reff346_not4080 : ~ @Equation4080 Fin4 reff346_inst.
Proof. unfold Equation4080. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff346_inst, reff346_op in H. discriminate H. Qed.

Lemma reff346_not4081 : ~ @Equation4081 Fin4 reff346_inst.
Proof. unfold Equation4081. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff346_inst, reff346_op in H. discriminate H. Qed.

Lemma reff346_not4083 : ~ @Equation4083 Fin4 reff346_inst.
Proof. unfold Equation4083. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff346_inst, reff346_op in H. discriminate H. Qed.

Lemma reff346_not4084 : ~ @Equation4084 Fin4 reff346_inst.
Proof. unfold Equation4084. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff346_inst, reff346_op in H. discriminate H. Qed.

Lemma reff346_not4090 : ~ @Equation4090 Fin4 reff346_inst.
Proof. unfold Equation4090. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff346_inst, reff346_op in H. discriminate H. Qed.

Lemma reff346_not4091 : ~ @Equation4091 Fin4 reff346_inst.
Proof. unfold Equation4091. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff346_inst, reff346_op in H. discriminate H. Qed.

Lemma reff346_not4093 : ~ @Equation4093 Fin4 reff346_inst.
Proof. unfold Equation4093. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff346_inst, reff346_op in H. discriminate H. Qed.

Lemma reff346_not4118 : ~ @Equation4118 Fin4 reff346_inst.
Proof. unfold Equation4118. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff346_inst, reff346_op in H. discriminate H. Qed.

Lemma reff346_not4120 : ~ @Equation4120 Fin4 reff346_inst.
Proof. unfold Equation4120. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff346_inst, reff346_op in H. discriminate H. Qed.

Lemma reff346_not4121 : ~ @Equation4121 Fin4 reff346_inst.
Proof. unfold Equation4121. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff346_inst, reff346_op in H. discriminate H. Qed.

Lemma reff346_not4155 : ~ @Equation4155 Fin4 reff346_inst.
Proof. unfold Equation4155. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff346_inst, reff346_op in H. discriminate H. Qed.

Lemma reff346_not4157 : ~ @Equation4157 Fin4 reff346_inst.
Proof. unfold Equation4157. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff346_inst, reff346_op in H. discriminate H. Qed.

Lemma reff346_not4158 : ~ @Equation4158 Fin4 reff346_inst.
Proof. unfold Equation4158. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff346_inst, reff346_op in H. discriminate H. Qed.

Lemma reff346_not4164 : ~ @Equation4164 Fin4 reff346_inst.
Proof. unfold Equation4164. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff346_inst, reff346_op in H. discriminate H. Qed.

Lemma reff346_not4165 : ~ @Equation4165 Fin4 reff346_inst.
Proof. unfold Equation4165. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff346_inst, reff346_op in H. discriminate H. Qed.

Lemma reff346_not4167 : ~ @Equation4167 Fin4 reff346_inst.
Proof. unfold Equation4167. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff346_inst, reff346_op in H. discriminate H. Qed.

Lemma reff346_not4272 : ~ @Equation4272 Fin4 reff346_inst.
Proof. unfold Equation4272. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff346_inst, reff346_op in H. discriminate H. Qed.

Lemma reff346_not4273 : ~ @Equation4273 Fin4 reff346_inst.
Proof. unfold Equation4273. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff346_inst, reff346_op in H. discriminate H. Qed.

Lemma reff346_not4275 : ~ @Equation4275 Fin4 reff346_inst.
Proof. unfold Equation4275. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff346_inst, reff346_op in H. discriminate H. Qed.

Lemma reff346_not4276 : ~ @Equation4276 Fin4 reff346_inst.
Proof. unfold Equation4276. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff346_inst, reff346_op in H. discriminate H. Qed.

Lemma reff346_not4290 : ~ @Equation4290 Fin4 reff346_inst.
Proof. unfold Equation4290. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff346_inst, reff346_op in H. discriminate H. Qed.

Lemma reff346_not4291 : ~ @Equation4291 Fin4 reff346_inst.
Proof. unfold Equation4291. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff346_inst, reff346_op in H. discriminate H. Qed.

Lemma reff346_not4293 : ~ @Equation4293 Fin4 reff346_inst.
Proof. unfold Equation4293. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff346_inst, reff346_op in H. discriminate H. Qed.

Lemma reff346_not4320 : ~ @Equation4320 Fin4 reff346_inst.
Proof. unfold Equation4320. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff346_inst, reff346_op in H. discriminate H. Qed.

Lemma reff346_not4321 : ~ @Equation4321 Fin4 reff346_inst.
Proof. unfold Equation4321. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff346_inst, reff346_op in H. discriminate H. Qed.

Lemma reff346_not4343 : ~ @Equation4343 Fin4 reff346_inst.
Proof. unfold Equation4343. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff346_inst, reff346_op in H. discriminate H. Qed.

Lemma reff346_not4380 : ~ @Equation4380 Fin4 reff346_inst.
Proof. unfold Equation4380. intro H. specialize (H F4_1). unfold magma_op, reff346_inst, reff346_op in H. discriminate H. Qed.

Lemma reff346_not4584 : ~ @Equation4584 Fin4 reff346_inst.
Proof. unfold Equation4584. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff346_inst, reff346_op in H. discriminate H. Qed.

Lemma reff346_not4585 : ~ @Equation4585 Fin4 reff346_inst.
Proof. unfold Equation4585. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff346_inst, reff346_op in H. discriminate H. Qed.

Lemma reff346_not4587 : ~ @Equation4587 Fin4 reff346_inst.
Proof. unfold Equation4587. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff346_inst, reff346_op in H. discriminate H. Qed.

Lemma reff346_not4588 : ~ @Equation4588 Fin4 reff346_inst.
Proof. unfold Equation4588. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff346_inst, reff346_op in H. discriminate H. Qed.

Lemma reff346_not4590 : ~ @Equation4590 Fin4 reff346_inst.
Proof. unfold Equation4590. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff346_inst, reff346_op in H. discriminate H. Qed.

Lemma reff346_not4591 : ~ @Equation4591 Fin4 reff346_inst.
Proof. unfold Equation4591. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff346_inst, reff346_op in H. discriminate H. Qed.

Lemma reff346_not4598 : ~ @Equation4598 Fin4 reff346_inst.
Proof. unfold Equation4598. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff346_inst, reff346_op in H. discriminate H. Qed.

Lemma reff346_not4599 : ~ @Equation4599 Fin4 reff346_inst.
Proof. unfold Equation4599. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff346_inst, reff346_op in H. discriminate H. Qed.

Lemma reff346_not4605 : ~ @Equation4605 Fin4 reff346_inst.
Proof. unfold Equation4605. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff346_inst, reff346_op in H. discriminate H. Qed.

Lemma reff346_not4606 : ~ @Equation4606 Fin4 reff346_inst.
Proof. unfold Equation4606. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff346_inst, reff346_op in H. discriminate H. Qed.

Lemma reff346_not4608 : ~ @Equation4608 Fin4 reff346_inst.
Proof. unfold Equation4608. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff346_inst, reff346_op in H. discriminate H. Qed.

Lemma reff346_not4635 : ~ @Equation4635 Fin4 reff346_inst.
Proof. unfold Equation4635. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff346_inst, reff346_op in H. discriminate H. Qed.

Lemma reff346_not4636 : ~ @Equation4636 Fin4 reff346_inst.
Proof. unfold Equation4636. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff346_inst, reff346_op in H. discriminate H. Qed.

Lemma reff346_not4658 : ~ @Equation4658 Fin4 reff346_inst.
Proof. unfold Equation4658. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff346_inst, reff346_op in H. discriminate H. Qed.

(** ---- reff352 (Fin4) ---- *)

Definition reff352_op (x y : Fin4) : Fin4 :=
  match x, y with
  | F4_0, F4_0 => F4_0 | F4_0, F4_1 => F4_3 | F4_0, F4_2 => F4_0 | F4_0, F4_3 => F4_3
  | F4_1, F4_0 => F4_3 | F4_1, F4_1 => F4_2 | F4_1, F4_2 => F4_3 | F4_1, F4_3 => F4_2
  | F4_2, F4_0 => F4_0 | F4_2, F4_1 => F4_3 | F4_2, F4_2 => F4_0 | F4_2, F4_3 => F4_3
  | F4_3, F4_0 => F4_3 | F4_3, F4_1 => F4_2 | F4_3, F4_2 => F4_3 | F4_3, F4_3 => F4_2
  end.

#[local] Instance reff352_inst : Magma Fin4 := {| magma_op := reff352_op |}.

Lemma reff352_sat3323 : @Equation3323 Fin4 reff352_inst.
Proof. unfold Equation3323, magma_op, reff352_inst, reff352_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff352_sat3350 : @Equation3350 Fin4 reff352_inst.
Proof. unfold Equation3350, magma_op, reff352_inst, reff352_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff352_sat3364 : @Equation3364 Fin4 reff352_inst.
Proof. unfold Equation3364, magma_op, reff352_inst, reff352_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff352_sat3537 : @Equation3537 Fin4 reff352_inst.
Proof. unfold Equation3537, magma_op, reff352_inst, reff352_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff352_sat3943 : @Equation3943 Fin4 reff352_inst.
Proof. unfold Equation3943, magma_op, reff352_inst, reff352_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff352_sat4216 : @Equation4216 Fin4 reff352_inst.
Proof. unfold Equation4216, magma_op, reff352_inst, reff352_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff352_sat4226 : @Equation4226 Fin4 reff352_inst.
Proof. unfold Equation4226, magma_op, reff352_inst, reff352_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff352_sat4229 : @Equation4229 Fin4 reff352_inst.
Proof. unfold Equation4229, magma_op, reff352_inst, reff352_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff352_sat4497 : @Equation4497 Fin4 reff352_inst.
Proof. unfold Equation4497, magma_op, reff352_inst, reff352_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff352_not307 : ~ @Equation307 Fin4 reff352_inst.
Proof. unfold Equation307. intro H. specialize (H F4_1). unfold magma_op, reff352_inst, reff352_op in H. discriminate H. Qed.

Lemma reff352_not411 : ~ @Equation411 Fin4 reff352_inst.
Proof. unfold Equation411. intro H. specialize (H F4_1). unfold magma_op, reff352_inst, reff352_op in H. discriminate H. Qed.

Lemma reff352_not614 : ~ @Equation614 Fin4 reff352_inst.
Proof. unfold Equation614. intro H. specialize (H F4_1). unfold magma_op, reff352_inst, reff352_op in H. discriminate H. Qed.

Lemma reff352_not817 : ~ @Equation817 Fin4 reff352_inst.
Proof. unfold Equation817. intro H. specialize (H F4_1). unfold magma_op, reff352_inst, reff352_op in H. discriminate H. Qed.

Lemma reff352_not1020 : ~ @Equation1020 Fin4 reff352_inst.
Proof. unfold Equation1020. intro H. specialize (H F4_1). unfold magma_op, reff352_inst, reff352_op in H. discriminate H. Qed.

Lemma reff352_not1223 : ~ @Equation1223 Fin4 reff352_inst.
Proof. unfold Equation1223. intro H. specialize (H F4_1). unfold magma_op, reff352_inst, reff352_op in H. discriminate H. Qed.

Lemma reff352_not1426 : ~ @Equation1426 Fin4 reff352_inst.
Proof. unfold Equation1426. intro H. specialize (H F4_1). unfold magma_op, reff352_inst, reff352_op in H. discriminate H. Qed.

Lemma reff352_not1629 : ~ @Equation1629 Fin4 reff352_inst.
Proof. unfold Equation1629. intro H. specialize (H F4_1). unfold magma_op, reff352_inst, reff352_op in H. discriminate H. Qed.

Lemma reff352_not1832 : ~ @Equation1832 Fin4 reff352_inst.
Proof. unfold Equation1832. intro H. specialize (H F4_1). unfold magma_op, reff352_inst, reff352_op in H. discriminate H. Qed.

Lemma reff352_not2035 : ~ @Equation2035 Fin4 reff352_inst.
Proof. unfold Equation2035. intro H. specialize (H F4_1). unfold magma_op, reff352_inst, reff352_op in H. discriminate H. Qed.

Lemma reff352_not2238 : ~ @Equation2238 Fin4 reff352_inst.
Proof. unfold Equation2238. intro H. specialize (H F4_1). unfold magma_op, reff352_inst, reff352_op in H. discriminate H. Qed.

Lemma reff352_not2441 : ~ @Equation2441 Fin4 reff352_inst.
Proof. unfold Equation2441. intro H. specialize (H F4_1). unfold magma_op, reff352_inst, reff352_op in H. discriminate H. Qed.

Lemma reff352_not2644 : ~ @Equation2644 Fin4 reff352_inst.
Proof. unfold Equation2644. intro H. specialize (H F4_1). unfold magma_op, reff352_inst, reff352_op in H. discriminate H. Qed.

Lemma reff352_not2847 : ~ @Equation2847 Fin4 reff352_inst.
Proof. unfold Equation2847. intro H. specialize (H F4_1). unfold magma_op, reff352_inst, reff352_op in H. discriminate H. Qed.

Lemma reff352_not3050 : ~ @Equation3050 Fin4 reff352_inst.
Proof. unfold Equation3050. intro H. specialize (H F4_1). unfold magma_op, reff352_inst, reff352_op in H. discriminate H. Qed.

Lemma reff352_not3254 : ~ @Equation3254 Fin4 reff352_inst.
Proof. unfold Equation3254. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff352_inst, reff352_op in H. discriminate H. Qed.

Lemma reff352_not3255 : ~ @Equation3255 Fin4 reff352_inst.
Proof. unfold Equation3255. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff352_inst, reff352_op in H. discriminate H. Qed.

Lemma reff352_not3258 : ~ @Equation3258 Fin4 reff352_inst.
Proof. unfold Equation3258. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff352_inst, reff352_op in H. discriminate H. Qed.

Lemma reff352_not3262 : ~ @Equation3262 Fin4 reff352_inst.
Proof. unfold Equation3262. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff352_inst, reff352_op in H. discriminate H. Qed.

Lemma reff352_not3268 : ~ @Equation3268 Fin4 reff352_inst.
Proof. unfold Equation3268. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff352_inst, reff352_op in H. discriminate H. Qed.

Lemma reff352_not3271 : ~ @Equation3271 Fin4 reff352_inst.
Proof. unfold Equation3271. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff352_inst, reff352_op in H. discriminate H. Qed.

Lemma reff352_not3272 : ~ @Equation3272 Fin4 reff352_inst.
Proof. unfold Equation3272. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff352_inst, reff352_op in H. discriminate H. Qed.

Lemma reff352_not3278 : ~ @Equation3278 Fin4 reff352_inst.
Proof. unfold Equation3278. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff352_inst, reff352_op in H. discriminate H. Qed.

Lemma reff352_not3279 : ~ @Equation3279 Fin4 reff352_inst.
Proof. unfold Equation3279. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff352_inst, reff352_op in H. discriminate H. Qed.

Lemma reff352_not3281 : ~ @Equation3281 Fin4 reff352_inst.
Proof. unfold Equation3281. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff352_inst, reff352_op in H. discriminate H. Qed.

Lemma reff352_not3309 : ~ @Equation3309 Fin4 reff352_inst.
Proof. unfold Equation3309. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff352_inst, reff352_op in H. discriminate H. Qed.

Lemma reff352_not3316 : ~ @Equation3316 Fin4 reff352_inst.
Proof. unfold Equation3316. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff352_inst, reff352_op in H. discriminate H. Qed.

Lemma reff352_not3318 : ~ @Equation3318 Fin4 reff352_inst.
Proof. unfold Equation3318. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff352_inst, reff352_op in H. discriminate H. Qed.

Lemma reff352_not3343 : ~ @Equation3343 Fin4 reff352_inst.
Proof. unfold Equation3343. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff352_inst, reff352_op in H. discriminate H. Qed.

Lemma reff352_not3345 : ~ @Equation3345 Fin4 reff352_inst.
Proof. unfold Equation3345. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff352_inst, reff352_op in H. discriminate H. Qed.

Lemma reff352_not3352 : ~ @Equation3352 Fin4 reff352_inst.
Proof. unfold Equation3352. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff352_inst, reff352_op in H. discriminate H. Qed.

Lemma reff352_not3458 : ~ @Equation3458 Fin4 reff352_inst.
Proof. unfold Equation3458. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff352_inst, reff352_op in H. discriminate H. Qed.

Lemma reff352_not3472 : ~ @Equation3472 Fin4 reff352_inst.
Proof. unfold Equation3472. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff352_inst, reff352_op in H. discriminate H. Qed.

Lemma reff352_not3474 : ~ @Equation3474 Fin4 reff352_inst.
Proof. unfold Equation3474. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff352_inst, reff352_op in H. discriminate H. Qed.

Lemma reff352_not3481 : ~ @Equation3481 Fin4 reff352_inst.
Proof. unfold Equation3481. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff352_inst, reff352_op in H. discriminate H. Qed.

Lemma reff352_not3482 : ~ @Equation3482 Fin4 reff352_inst.
Proof. unfold Equation3482. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff352_inst, reff352_op in H. discriminate H. Qed.

Lemma reff352_not3519 : ~ @Equation3519 Fin4 reff352_inst.
Proof. unfold Equation3519. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff352_inst, reff352_op in H. discriminate H. Qed.

Lemma reff352_not3659 : ~ @Equation3659 Fin4 reff352_inst.
Proof. unfold Equation3659. intro H. specialize (H F4_1). unfold magma_op, reff352_inst, reff352_op in H. discriminate H. Qed.

Lemma reff352_not3864 : ~ @Equation3864 Fin4 reff352_inst.
Proof. unfold Equation3864. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff352_inst, reff352_op in H. discriminate H. Qed.

Lemma reff352_not3865 : ~ @Equation3865 Fin4 reff352_inst.
Proof. unfold Equation3865. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff352_inst, reff352_op in H. discriminate H. Qed.

Lemma reff352_not3867 : ~ @Equation3867 Fin4 reff352_inst.
Proof. unfold Equation3867. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff352_inst, reff352_op in H. discriminate H. Qed.

Lemma reff352_not3868 : ~ @Equation3868 Fin4 reff352_inst.
Proof. unfold Equation3868. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff352_inst, reff352_op in H. discriminate H. Qed.

Lemma reff352_not3871 : ~ @Equation3871 Fin4 reff352_inst.
Proof. unfold Equation3871. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff352_inst, reff352_op in H. discriminate H. Qed.

Lemma reff352_not3877 : ~ @Equation3877 Fin4 reff352_inst.
Proof. unfold Equation3877. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff352_inst, reff352_op in H. discriminate H. Qed.

Lemma reff352_not3878 : ~ @Equation3878 Fin4 reff352_inst.
Proof. unfold Equation3878. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff352_inst, reff352_op in H. discriminate H. Qed.

Lemma reff352_not3881 : ~ @Equation3881 Fin4 reff352_inst.
Proof. unfold Equation3881. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff352_inst, reff352_op in H. discriminate H. Qed.

Lemma reff352_not3888 : ~ @Equation3888 Fin4 reff352_inst.
Proof. unfold Equation3888. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff352_inst, reff352_op in H. discriminate H. Qed.

Lemma reff352_not3890 : ~ @Equation3890 Fin4 reff352_inst.
Proof. unfold Equation3890. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff352_inst, reff352_op in H. discriminate H. Qed.

Lemma reff352_not3918 : ~ @Equation3918 Fin4 reff352_inst.
Proof. unfold Equation3918. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff352_inst, reff352_op in H. discriminate H. Qed.

Lemma reff352_not3925 : ~ @Equation3925 Fin4 reff352_inst.
Proof. unfold Equation3925. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff352_inst, reff352_op in H. discriminate H. Qed.

Lemma reff352_not3927 : ~ @Equation3927 Fin4 reff352_inst.
Proof. unfold Equation3927. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff352_inst, reff352_op in H. discriminate H. Qed.

Lemma reff352_not3952 : ~ @Equation3952 Fin4 reff352_inst.
Proof. unfold Equation3952. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff352_inst, reff352_op in H. discriminate H. Qed.

Lemma reff352_not3954 : ~ @Equation3954 Fin4 reff352_inst.
Proof. unfold Equation3954. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff352_inst, reff352_op in H. discriminate H. Qed.

Lemma reff352_not3961 : ~ @Equation3961 Fin4 reff352_inst.
Proof. unfold Equation3961. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff352_inst, reff352_op in H. discriminate H. Qed.

Lemma reff352_not4068 : ~ @Equation4068 Fin4 reff352_inst.
Proof. unfold Equation4068. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff352_inst, reff352_op in H. discriminate H. Qed.

Lemma reff352_not4070 : ~ @Equation4070 Fin4 reff352_inst.
Proof. unfold Equation4070. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff352_inst, reff352_op in H. discriminate H. Qed.

Lemma reff352_not4071 : ~ @Equation4071 Fin4 reff352_inst.
Proof. unfold Equation4071. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff352_inst, reff352_op in H. discriminate H. Qed.

Lemma reff352_not4084 : ~ @Equation4084 Fin4 reff352_inst.
Proof. unfold Equation4084. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff352_inst, reff352_op in H. discriminate H. Qed.

Lemma reff352_not4128 : ~ @Equation4128 Fin4 reff352_inst.
Proof. unfold Equation4128. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff352_inst, reff352_op in H. discriminate H. Qed.

Lemma reff352_not4273 : ~ @Equation4273 Fin4 reff352_inst.
Proof. unfold Equation4273. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff352_inst, reff352_op in H. discriminate H. Qed.

Lemma reff352_not4275 : ~ @Equation4275 Fin4 reff352_inst.
Proof. unfold Equation4275. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff352_inst, reff352_op in H. discriminate H. Qed.

Lemma reff352_not4290 : ~ @Equation4290 Fin4 reff352_inst.
Proof. unfold Equation4290. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff352_inst, reff352_op in H. discriminate H. Qed.

Lemma reff352_not4320 : ~ @Equation4320 Fin4 reff352_inst.
Proof. unfold Equation4320. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff352_inst, reff352_op in H. discriminate H. Qed.

Lemma reff352_not4321 : ~ @Equation4321 Fin4 reff352_inst.
Proof. unfold Equation4321. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff352_inst, reff352_op in H. discriminate H. Qed.

Lemma reff352_not4396 : ~ @Equation4396 Fin4 reff352_inst.
Proof. unfold Equation4396. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff352_inst, reff352_op in H. discriminate H. Qed.

Lemma reff352_not4399 : ~ @Equation4399 Fin4 reff352_inst.
Proof. unfold Equation4399. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff352_inst, reff352_op in H. discriminate H. Qed.

Lemma reff352_not4406 : ~ @Equation4406 Fin4 reff352_inst.
Proof. unfold Equation4406. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff352_inst, reff352_op in H. discriminate H. Qed.

Lemma reff352_not4408 : ~ @Equation4408 Fin4 reff352_inst.
Proof. unfold Equation4408. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff352_inst, reff352_op in H. discriminate H. Qed.

Lemma reff352_not4433 : ~ @Equation4433 Fin4 reff352_inst.
Proof. unfold Equation4433. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff352_inst, reff352_op in H. discriminate H. Qed.

Lemma reff352_not4436 : ~ @Equation4436 Fin4 reff352_inst.
Proof. unfold Equation4436. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff352_inst, reff352_op in H. discriminate H. Qed.

Lemma reff352_not4443 : ~ @Equation4443 Fin4 reff352_inst.
Proof. unfold Equation4443. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff352_inst, reff352_op in H. discriminate H. Qed.

Lemma reff352_not4445 : ~ @Equation4445 Fin4 reff352_inst.
Proof. unfold Equation4445. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff352_inst, reff352_op in H. discriminate H. Qed.

Lemma reff352_not4470 : ~ @Equation4470 Fin4 reff352_inst.
Proof. unfold Equation4470. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff352_inst, reff352_op in H. discriminate H. Qed.

Lemma reff352_not4472 : ~ @Equation4472 Fin4 reff352_inst.
Proof. unfold Equation4472. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff352_inst, reff352_op in H. discriminate H. Qed.

Lemma reff352_not4473 : ~ @Equation4473 Fin4 reff352_inst.
Proof. unfold Equation4473. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff352_inst, reff352_op in H. discriminate H. Qed.

Lemma reff352_not4479 : ~ @Equation4479 Fin4 reff352_inst.
Proof. unfold Equation4479. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff352_inst, reff352_op in H. discriminate H. Qed.

Lemma reff352_not4480 : ~ @Equation4480 Fin4 reff352_inst.
Proof. unfold Equation4480. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff352_inst, reff352_op in H. discriminate H. Qed.

Lemma reff352_not4585 : ~ @Equation4585 Fin4 reff352_inst.
Proof. unfold Equation4585. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff352_inst, reff352_op in H. discriminate H. Qed.

Lemma reff352_not4588 : ~ @Equation4588 Fin4 reff352_inst.
Proof. unfold Equation4588. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff352_inst, reff352_op in H. discriminate H. Qed.

Lemma reff352_not4598 : ~ @Equation4598 Fin4 reff352_inst.
Proof. unfold Equation4598. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff352_inst, reff352_op in H. discriminate H. Qed.

Lemma reff352_not4605 : ~ @Equation4605 Fin4 reff352_inst.
Proof. unfold Equation4605. intro H. specialize (H F4_1 F4_0). unfold magma_op, reff352_inst, reff352_op in H. discriminate H. Qed.

Lemma reff352_not4658 : ~ @Equation4658 Fin4 reff352_inst.
Proof. unfold Equation4658. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff352_inst, reff352_op in H. discriminate H. Qed.

(** ---- reff356 (Fin3) ---- *)

Definition reff356_op (x y : Fin3) : Fin3 :=
  match x, y with
  | F3_0, F3_0 => F3_0 | F3_0, F3_1 => F3_0 | F3_0, F3_2 => F3_2
  | F3_1, F3_0 => F3_1 | F3_1, F3_1 => F3_0 | F3_1, F3_2 => F3_1
  | F3_2, F3_0 => F3_1 | F3_2, F3_1 => F3_2 | F3_2, F3_2 => F3_2
  end.

#[local] Instance reff356_inst : Magma Fin3 := {| magma_op := reff356_op |}.

Lemma reff356_sat10 : @Equation10 Fin3 reff356_inst.
Proof. unfold Equation10, magma_op, reff356_inst, reff356_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff356_sat378 : @Equation378 Fin3 reff356_inst.
Proof. unfold Equation378, magma_op, reff356_inst, reff356_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff356_sat839 : @Equation839 Fin3 reff356_inst.
Proof. unfold Equation839, magma_op, reff356_inst, reff356_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff356_sat1260 : @Equation1260 Fin3 reff356_inst.
Proof. unfold Equation1260, magma_op, reff356_inst, reff356_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff356_not47 : ~ @Equation47 Fin3 reff356_inst.
Proof. unfold Equation47. intro H. specialize (H F3_1). unfold magma_op, reff356_inst, reff356_op in H. discriminate H. Qed.

Lemma reff356_not102 : ~ @Equation102 Fin3 reff356_inst.
Proof. unfold Equation102. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff356_inst, reff356_op in H. discriminate H. Qed.

Lemma reff356_not105 : ~ @Equation105 Fin3 reff356_inst.
Proof. unfold Equation105. intro H. specialize (H F3_2 F3_1). unfold magma_op, reff356_inst, reff356_op in H. discriminate H. Qed.

Lemma reff356_not108 : ~ @Equation108 Fin3 reff356_inst.
Proof. unfold Equation108. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff356_inst, reff356_op in H. discriminate H. Qed.

Lemma reff356_not115 : ~ @Equation115 Fin3 reff356_inst.
Proof. unfold Equation115. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff356_inst, reff356_op in H. discriminate H. Qed.

Lemma reff356_not117 : ~ @Equation117 Fin3 reff356_inst.
Proof. unfold Equation117. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff356_inst, reff356_op in H. discriminate H. Qed.

Lemma reff356_not118 : ~ @Equation118 Fin3 reff356_inst.
Proof. unfold Equation118. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff356_inst, reff356_op in H. discriminate H. Qed.

Lemma reff356_not124 : ~ @Equation124 Fin3 reff356_inst.
Proof. unfold Equation124. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff356_inst, reff356_op in H. discriminate H. Qed.

Lemma reff356_not125 : ~ @Equation125 Fin3 reff356_inst.
Proof. unfold Equation125. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff356_inst, reff356_op in H. discriminate H. Qed.

Lemma reff356_not127 : ~ @Equation127 Fin3 reff356_inst.
Proof. unfold Equation127. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff356_inst, reff356_op in H. discriminate H. Qed.

Lemma reff356_not151 : ~ @Equation151 Fin3 reff356_inst.
Proof. unfold Equation151. intro H. specialize (H F3_1). unfold magma_op, reff356_inst, reff356_op in H. discriminate H. Qed.

Lemma reff356_not203 : ~ @Equation203 Fin3 reff356_inst.
Proof. unfold Equation203. intro H. specialize (H F3_1). unfold magma_op, reff356_inst, reff356_op in H. discriminate H. Qed.

Lemma reff356_not255 : ~ @Equation255 Fin3 reff356_inst.
Proof. unfold Equation255. intro H. specialize (H F3_1). unfold magma_op, reff356_inst, reff356_op in H. discriminate H. Qed.

Lemma reff356_not307 : ~ @Equation307 Fin3 reff356_inst.
Proof. unfold Equation307. intro H. specialize (H F3_1). unfold magma_op, reff356_inst, reff356_op in H. discriminate H. Qed.

Lemma reff356_not412 : ~ @Equation412 Fin3 reff356_inst.
Proof. unfold Equation412. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff356_inst, reff356_op in H. discriminate H. Qed.

Lemma reff356_not414 : ~ @Equation414 Fin3 reff356_inst.
Proof. unfold Equation414. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff356_inst, reff356_op in H. discriminate H. Qed.

Lemma reff356_not416 : ~ @Equation416 Fin3 reff356_inst.
Proof. unfold Equation416. intro H. specialize (H F3_1 F3_0). unfold magma_op, reff356_inst, reff356_op in H. discriminate H. Qed.

Lemma reff356_not417 : ~ @Equation417 Fin3 reff356_inst.
Proof. unfold Equation417. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff356_inst, reff356_op in H. discriminate H. Qed.

Lemma reff356_not419 : ~ @Equation419 Fin3 reff356_inst.
Proof. unfold Equation419. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff356_inst, reff356_op in H. discriminate H. Qed.

Lemma reff356_not420 : ~ @Equation420 Fin3 reff356_inst.
Proof. unfold Equation420. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff356_inst, reff356_op in H. discriminate H. Qed.

Lemma reff356_not427 : ~ @Equation427 Fin3 reff356_inst.
Proof. unfold Equation427. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff356_inst, reff356_op in H. discriminate H. Qed.

Lemma reff356_not430 : ~ @Equation430 Fin3 reff356_inst.
Proof. unfold Equation430. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff356_inst, reff356_op in H. discriminate H. Qed.

Lemma reff356_not436 : ~ @Equation436 Fin3 reff356_inst.
Proof. unfold Equation436. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff356_inst, reff356_op in H. discriminate H. Qed.

Lemma reff356_not437 : ~ @Equation437 Fin3 reff356_inst.
Proof. unfold Equation437. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff356_inst, reff356_op in H. discriminate H. Qed.

Lemma reff356_not439 : ~ @Equation439 Fin3 reff356_inst.
Proof. unfold Equation439. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff356_inst, reff356_op in H. discriminate H. Qed.

Lemma reff356_not440 : ~ @Equation440 Fin3 reff356_inst.
Proof. unfold Equation440. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff356_inst, reff356_op in H. discriminate H. Qed.

Lemma reff356_not463 : ~ @Equation463 Fin3 reff356_inst.
Proof. unfold Equation463. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff356_inst, reff356_op in H. discriminate H. Qed.

Lemma reff356_not464 : ~ @Equation464 Fin3 reff356_inst.
Proof. unfold Equation464. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff356_inst, reff356_op in H. discriminate H. Qed.

Lemma reff356_not466 : ~ @Equation466 Fin3 reff356_inst.
Proof. unfold Equation466. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff356_inst, reff356_op in H. discriminate H. Qed.

Lemma reff356_not467 : ~ @Equation467 Fin3 reff356_inst.
Proof. unfold Equation467. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff356_inst, reff356_op in H. discriminate H. Qed.

Lemma reff356_not473 : ~ @Equation473 Fin3 reff356_inst.
Proof. unfold Equation473. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff356_inst, reff356_op in H. discriminate H. Qed.

Lemma reff356_not474 : ~ @Equation474 Fin3 reff356_inst.
Proof. unfold Equation474. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff356_inst, reff356_op in H. discriminate H. Qed.

Lemma reff356_not476 : ~ @Equation476 Fin3 reff356_inst.
Proof. unfold Equation476. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff356_inst, reff356_op in H. discriminate H. Qed.

Lemma reff356_not477 : ~ @Equation477 Fin3 reff356_inst.
Proof. unfold Equation477. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff356_inst, reff356_op in H. discriminate H. Qed.

Lemma reff356_not500 : ~ @Equation500 Fin3 reff356_inst.
Proof. unfold Equation500. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff356_inst, reff356_op in H. discriminate H. Qed.

Lemma reff356_not501 : ~ @Equation501 Fin3 reff356_inst.
Proof. unfold Equation501. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff356_inst, reff356_op in H. discriminate H. Qed.

Lemma reff356_not503 : ~ @Equation503 Fin3 reff356_inst.
Proof. unfold Equation503. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff356_inst, reff356_op in H. discriminate H. Qed.

Lemma reff356_not504 : ~ @Equation504 Fin3 reff356_inst.
Proof. unfold Equation504. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff356_inst, reff356_op in H. discriminate H. Qed.

Lemma reff356_not510 : ~ @Equation510 Fin3 reff356_inst.
Proof. unfold Equation510. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff356_inst, reff356_op in H. discriminate H. Qed.

Lemma reff356_not511 : ~ @Equation511 Fin3 reff356_inst.
Proof. unfold Equation511. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff356_inst, reff356_op in H. discriminate H. Qed.

Lemma reff356_not513 : ~ @Equation513 Fin3 reff356_inst.
Proof. unfold Equation513. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff356_inst, reff356_op in H. discriminate H. Qed.

Lemma reff356_not614 : ~ @Equation614 Fin3 reff356_inst.
Proof. unfold Equation614. intro H. specialize (H F3_1). unfold magma_op, reff356_inst, reff356_op in H. discriminate H. Qed.

Lemma reff356_not818 : ~ @Equation818 Fin3 reff356_inst.
Proof. unfold Equation818. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff356_inst, reff356_op in H. discriminate H. Qed.

Lemma reff356_not820 : ~ @Equation820 Fin3 reff356_inst.
Proof. unfold Equation820. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff356_inst, reff356_op in H. discriminate H. Qed.

Lemma reff356_not822 : ~ @Equation822 Fin3 reff356_inst.
Proof. unfold Equation822. intro H. specialize (H F3_1 F3_0). unfold magma_op, reff356_inst, reff356_op in H. discriminate H. Qed.

Lemma reff356_not823 : ~ @Equation823 Fin3 reff356_inst.
Proof. unfold Equation823. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff356_inst, reff356_op in H. discriminate H. Qed.

Lemma reff356_not825 : ~ @Equation825 Fin3 reff356_inst.
Proof. unfold Equation825. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff356_inst, reff356_op in H. discriminate H. Qed.

Lemma reff356_not826 : ~ @Equation826 Fin3 reff356_inst.
Proof. unfold Equation826. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff356_inst, reff356_op in H. discriminate H. Qed.

Lemma reff356_not832 : ~ @Equation832 Fin3 reff356_inst.
Proof. unfold Equation832. intro H. specialize (H F3_1 F3_2). unfold magma_op, reff356_inst, reff356_op in H. discriminate H. Qed.

Lemma reff356_not835 : ~ @Equation835 Fin3 reff356_inst.
Proof. unfold Equation835. intro H. specialize (H F3_2 F3_1). unfold magma_op, reff356_inst, reff356_op in H. discriminate H. Qed.

Lemma reff356_not842 : ~ @Equation842 Fin3 reff356_inst.
Proof. unfold Equation842. intro H. specialize (H F3_1 F3_2). unfold magma_op, reff356_inst, reff356_op in H. discriminate H. Qed.

Lemma reff356_not843 : ~ @Equation843 Fin3 reff356_inst.
Proof. unfold Equation843. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff356_inst, reff356_op in H. discriminate H. Qed.

Lemma reff356_not845 : ~ @Equation845 Fin3 reff356_inst.
Proof. unfold Equation845. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff356_inst, reff356_op in H. discriminate H. Qed.

Lemma reff356_not846 : ~ @Equation846 Fin3 reff356_inst.
Proof. unfold Equation846. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff356_inst, reff356_op in H. discriminate H. Qed.

Lemma reff356_not869 : ~ @Equation869 Fin3 reff356_inst.
Proof. unfold Equation869. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff356_inst, reff356_op in H. discriminate H. Qed.

Lemma reff356_not870 : ~ @Equation870 Fin3 reff356_inst.
Proof. unfold Equation870. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff356_inst, reff356_op in H. discriminate H. Qed.

Lemma reff356_not872 : ~ @Equation872 Fin3 reff356_inst.
Proof. unfold Equation872. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff356_inst, reff356_op in H. discriminate H. Qed.

Lemma reff356_not873 : ~ @Equation873 Fin3 reff356_inst.
Proof. unfold Equation873. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff356_inst, reff356_op in H. discriminate H. Qed.

Lemma reff356_not879 : ~ @Equation879 Fin3 reff356_inst.
Proof. unfold Equation879. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff356_inst, reff356_op in H. discriminate H. Qed.

Lemma reff356_not880 : ~ @Equation880 Fin3 reff356_inst.
Proof. unfold Equation880. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff356_inst, reff356_op in H. discriminate H. Qed.

Lemma reff356_not882 : ~ @Equation882 Fin3 reff356_inst.
Proof. unfold Equation882. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff356_inst, reff356_op in H. discriminate H. Qed.

Lemma reff356_not883 : ~ @Equation883 Fin3 reff356_inst.
Proof. unfold Equation883. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff356_inst, reff356_op in H. discriminate H. Qed.

Lemma reff356_not906 : ~ @Equation906 Fin3 reff356_inst.
Proof. unfold Equation906. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff356_inst, reff356_op in H. discriminate H. Qed.

Lemma reff356_not907 : ~ @Equation907 Fin3 reff356_inst.
Proof. unfold Equation907. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff356_inst, reff356_op in H. discriminate H. Qed.

Lemma reff356_not909 : ~ @Equation909 Fin3 reff356_inst.
Proof. unfold Equation909. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff356_inst, reff356_op in H. discriminate H. Qed.

Lemma reff356_not910 : ~ @Equation910 Fin3 reff356_inst.
Proof. unfold Equation910. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff356_inst, reff356_op in H. discriminate H. Qed.

Lemma reff356_not916 : ~ @Equation916 Fin3 reff356_inst.
Proof. unfold Equation916. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff356_inst, reff356_op in H. discriminate H. Qed.

Lemma reff356_not917 : ~ @Equation917 Fin3 reff356_inst.
Proof. unfold Equation917. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff356_inst, reff356_op in H. discriminate H. Qed.

Lemma reff356_not919 : ~ @Equation919 Fin3 reff356_inst.
Proof. unfold Equation919. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff356_inst, reff356_op in H. discriminate H. Qed.

Lemma reff356_not1021 : ~ @Equation1021 Fin3 reff356_inst.
Proof. unfold Equation1021. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff356_inst, reff356_op in H. discriminate H. Qed.

Lemma reff356_not1023 : ~ @Equation1023 Fin3 reff356_inst.
Proof. unfold Equation1023. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff356_inst, reff356_op in H. discriminate H. Qed.

Lemma reff356_not1026 : ~ @Equation1026 Fin3 reff356_inst.
Proof. unfold Equation1026. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff356_inst, reff356_op in H. discriminate H. Qed.

Lemma reff356_not1029 : ~ @Equation1029 Fin3 reff356_inst.
Proof. unfold Equation1029. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff356_inst, reff356_op in H. discriminate H. Qed.

Lemma reff356_not1036 : ~ @Equation1036 Fin3 reff356_inst.
Proof. unfold Equation1036. intro H. specialize (H F3_1 F3_2). unfold magma_op, reff356_inst, reff356_op in H. discriminate H. Qed.

Lemma reff356_not1039 : ~ @Equation1039 Fin3 reff356_inst.
Proof. unfold Equation1039. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff356_inst, reff356_op in H. discriminate H. Qed.

Lemma reff356_not1046 : ~ @Equation1046 Fin3 reff356_inst.
Proof. unfold Equation1046. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff356_inst, reff356_op in H. discriminate H. Qed.

Lemma reff356_not1049 : ~ @Equation1049 Fin3 reff356_inst.
Proof. unfold Equation1049. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff356_inst, reff356_op in H. discriminate H. Qed.

Lemma reff356_not1072 : ~ @Equation1072 Fin3 reff356_inst.
Proof. unfold Equation1072. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff356_inst, reff356_op in H. discriminate H. Qed.

Lemma reff356_not1073 : ~ @Equation1073 Fin3 reff356_inst.
Proof. unfold Equation1073. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff356_inst, reff356_op in H. discriminate H. Qed.

Lemma reff356_not1075 : ~ @Equation1075 Fin3 reff356_inst.
Proof. unfold Equation1075. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff356_inst, reff356_op in H. discriminate H. Qed.

Lemma reff356_not1076 : ~ @Equation1076 Fin3 reff356_inst.
Proof. unfold Equation1076. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff356_inst, reff356_op in H. discriminate H. Qed.

Lemma reff356_not1082 : ~ @Equation1082 Fin3 reff356_inst.
Proof. unfold Equation1082. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff356_inst, reff356_op in H. discriminate H. Qed.

Lemma reff356_not1083 : ~ @Equation1083 Fin3 reff356_inst.
Proof. unfold Equation1083. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff356_inst, reff356_op in H. discriminate H. Qed.

Lemma reff356_not1085 : ~ @Equation1085 Fin3 reff356_inst.
Proof. unfold Equation1085. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff356_inst, reff356_op in H. discriminate H. Qed.

Lemma reff356_not1086 : ~ @Equation1086 Fin3 reff356_inst.
Proof. unfold Equation1086. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff356_inst, reff356_op in H. discriminate H. Qed.

Lemma reff356_not1109 : ~ @Equation1109 Fin3 reff356_inst.
Proof. unfold Equation1109. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff356_inst, reff356_op in H. discriminate H. Qed.

Lemma reff356_not1110 : ~ @Equation1110 Fin3 reff356_inst.
Proof. unfold Equation1110. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff356_inst, reff356_op in H. discriminate H. Qed.

Lemma reff356_not1112 : ~ @Equation1112 Fin3 reff356_inst.
Proof. unfold Equation1112. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff356_inst, reff356_op in H. discriminate H. Qed.

Lemma reff356_not1113 : ~ @Equation1113 Fin3 reff356_inst.
Proof. unfold Equation1113. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff356_inst, reff356_op in H. discriminate H. Qed.

Lemma reff356_not1119 : ~ @Equation1119 Fin3 reff356_inst.
Proof. unfold Equation1119. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff356_inst, reff356_op in H. discriminate H. Qed.

Lemma reff356_not1120 : ~ @Equation1120 Fin3 reff356_inst.
Proof. unfold Equation1120. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff356_inst, reff356_op in H. discriminate H. Qed.

Lemma reff356_not1122 : ~ @Equation1122 Fin3 reff356_inst.
Proof. unfold Equation1122. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff356_inst, reff356_op in H. discriminate H. Qed.

Lemma reff356_not1224 : ~ @Equation1224 Fin3 reff356_inst.
Proof. unfold Equation1224. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff356_inst, reff356_op in H. discriminate H. Qed.

Lemma reff356_not1226 : ~ @Equation1226 Fin3 reff356_inst.
Proof. unfold Equation1226. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff356_inst, reff356_op in H. discriminate H. Qed.

Lemma reff356_not1232 : ~ @Equation1232 Fin3 reff356_inst.
Proof. unfold Equation1232. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff356_inst, reff356_op in H. discriminate H. Qed.

Lemma reff356_not1239 : ~ @Equation1239 Fin3 reff356_inst.
Proof. unfold Equation1239. intro H. specialize (H F3_2 F3_1). unfold magma_op, reff356_inst, reff356_op in H. discriminate H. Qed.

Lemma reff356_not1242 : ~ @Equation1242 Fin3 reff356_inst.
Proof. unfold Equation1242. intro H. specialize (H F3_2 F3_1). unfold magma_op, reff356_inst, reff356_op in H. discriminate H. Qed.

Lemma reff356_not1252 : ~ @Equation1252 Fin3 reff356_inst.
Proof. unfold Equation1252. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff356_inst, reff356_op in H. discriminate H. Qed.

Lemma reff356_not1275 : ~ @Equation1275 Fin3 reff356_inst.
Proof. unfold Equation1275. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff356_inst, reff356_op in H. discriminate H. Qed.

Lemma reff356_not1276 : ~ @Equation1276 Fin3 reff356_inst.
Proof. unfold Equation1276. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff356_inst, reff356_op in H. discriminate H. Qed.

Lemma reff356_not1278 : ~ @Equation1278 Fin3 reff356_inst.
Proof. unfold Equation1278. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff356_inst, reff356_op in H. discriminate H. Qed.

Lemma reff356_not1279 : ~ @Equation1279 Fin3 reff356_inst.
Proof. unfold Equation1279. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff356_inst, reff356_op in H. discriminate H. Qed.

Lemma reff356_not1285 : ~ @Equation1285 Fin3 reff356_inst.
Proof. unfold Equation1285. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff356_inst, reff356_op in H. discriminate H. Qed.

Lemma reff356_not1286 : ~ @Equation1286 Fin3 reff356_inst.
Proof. unfold Equation1286. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff356_inst, reff356_op in H. discriminate H. Qed.

Lemma reff356_not1288 : ~ @Equation1288 Fin3 reff356_inst.
Proof. unfold Equation1288. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff356_inst, reff356_op in H. discriminate H. Qed.

Lemma reff356_not1289 : ~ @Equation1289 Fin3 reff356_inst.
Proof. unfold Equation1289. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff356_inst, reff356_op in H. discriminate H. Qed.

Lemma reff356_not1312 : ~ @Equation1312 Fin3 reff356_inst.
Proof. unfold Equation1312. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff356_inst, reff356_op in H. discriminate H. Qed.

Lemma reff356_not1313 : ~ @Equation1313 Fin3 reff356_inst.
Proof. unfold Equation1313. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff356_inst, reff356_op in H. discriminate H. Qed.

Lemma reff356_not1315 : ~ @Equation1315 Fin3 reff356_inst.
Proof. unfold Equation1315. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff356_inst, reff356_op in H. discriminate H. Qed.

Lemma reff356_not1316 : ~ @Equation1316 Fin3 reff356_inst.
Proof. unfold Equation1316. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff356_inst, reff356_op in H. discriminate H. Qed.

Lemma reff356_not1322 : ~ @Equation1322 Fin3 reff356_inst.
Proof. unfold Equation1322. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff356_inst, reff356_op in H. discriminate H. Qed.

Lemma reff356_not1323 : ~ @Equation1323 Fin3 reff356_inst.
Proof. unfold Equation1323. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff356_inst, reff356_op in H. discriminate H. Qed.

Lemma reff356_not1325 : ~ @Equation1325 Fin3 reff356_inst.
Proof. unfold Equation1325. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff356_inst, reff356_op in H. discriminate H. Qed.

Lemma reff356_not1426 : ~ @Equation1426 Fin3 reff356_inst.
Proof. unfold Equation1426. intro H. specialize (H F3_1). unfold magma_op, reff356_inst, reff356_op in H. discriminate H. Qed.

Lemma reff356_not1629 : ~ @Equation1629 Fin3 reff356_inst.
Proof. unfold Equation1629. intro H. specialize (H F3_1). unfold magma_op, reff356_inst, reff356_op in H. discriminate H. Qed.

Lemma reff356_not1833 : ~ @Equation1833 Fin3 reff356_inst.
Proof. unfold Equation1833. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff356_inst, reff356_op in H. discriminate H. Qed.

Lemma reff356_not1835 : ~ @Equation1835 Fin3 reff356_inst.
Proof. unfold Equation1835. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff356_inst, reff356_op in H. discriminate H. Qed.

Lemma reff356_not1837 : ~ @Equation1837 Fin3 reff356_inst.
Proof. unfold Equation1837. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff356_inst, reff356_op in H. discriminate H. Qed.

Lemma reff356_not1838 : ~ @Equation1838 Fin3 reff356_inst.
Proof. unfold Equation1838. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff356_inst, reff356_op in H. discriminate H. Qed.

Lemma reff356_not1840 : ~ @Equation1840 Fin3 reff356_inst.
Proof. unfold Equation1840. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff356_inst, reff356_op in H. discriminate H. Qed.

Lemma reff356_not1841 : ~ @Equation1841 Fin3 reff356_inst.
Proof. unfold Equation1841. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff356_inst, reff356_op in H. discriminate H. Qed.

Lemma reff356_not1848 : ~ @Equation1848 Fin3 reff356_inst.
Proof. unfold Equation1848. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff356_inst, reff356_op in H. discriminate H. Qed.

Lemma reff356_not1851 : ~ @Equation1851 Fin3 reff356_inst.
Proof. unfold Equation1851. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff356_inst, reff356_op in H. discriminate H. Qed.

Lemma reff356_not1857 : ~ @Equation1857 Fin3 reff356_inst.
Proof. unfold Equation1857. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff356_inst, reff356_op in H. discriminate H. Qed.

Lemma reff356_not1858 : ~ @Equation1858 Fin3 reff356_inst.
Proof. unfold Equation1858. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff356_inst, reff356_op in H. discriminate H. Qed.

Lemma reff356_not1860 : ~ @Equation1860 Fin3 reff356_inst.
Proof. unfold Equation1860. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff356_inst, reff356_op in H. discriminate H. Qed.

Lemma reff356_not1861 : ~ @Equation1861 Fin3 reff356_inst.
Proof. unfold Equation1861. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff356_inst, reff356_op in H. discriminate H. Qed.

Lemma reff356_not1884 : ~ @Equation1884 Fin3 reff356_inst.
Proof. unfold Equation1884. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff356_inst, reff356_op in H. discriminate H. Qed.

Lemma reff356_not1885 : ~ @Equation1885 Fin3 reff356_inst.
Proof. unfold Equation1885. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff356_inst, reff356_op in H. discriminate H. Qed.

Lemma reff356_not1887 : ~ @Equation1887 Fin3 reff356_inst.
Proof. unfold Equation1887. intro H. specialize (H F3_1 F3_0). unfold magma_op, reff356_inst, reff356_op in H. discriminate H. Qed.

Lemma reff356_not1888 : ~ @Equation1888 Fin3 reff356_inst.
Proof. unfold Equation1888. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff356_inst, reff356_op in H. discriminate H. Qed.

Lemma reff356_not1894 : ~ @Equation1894 Fin3 reff356_inst.
Proof. unfold Equation1894. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff356_inst, reff356_op in H. discriminate H. Qed.

Lemma reff356_not1895 : ~ @Equation1895 Fin3 reff356_inst.
Proof. unfold Equation1895. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff356_inst, reff356_op in H. discriminate H. Qed.

Lemma reff356_not1897 : ~ @Equation1897 Fin3 reff356_inst.
Proof. unfold Equation1897. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff356_inst, reff356_op in H. discriminate H. Qed.

Lemma reff356_not1898 : ~ @Equation1898 Fin3 reff356_inst.
Proof. unfold Equation1898. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff356_inst, reff356_op in H. discriminate H. Qed.

Lemma reff356_not1921 : ~ @Equation1921 Fin3 reff356_inst.
Proof. unfold Equation1921. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff356_inst, reff356_op in H. discriminate H. Qed.

Lemma reff356_not1922 : ~ @Equation1922 Fin3 reff356_inst.
Proof. unfold Equation1922. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff356_inst, reff356_op in H. discriminate H. Qed.

Lemma reff356_not1924 : ~ @Equation1924 Fin3 reff356_inst.
Proof. unfold Equation1924. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff356_inst, reff356_op in H. discriminate H. Qed.

Lemma reff356_not1925 : ~ @Equation1925 Fin3 reff356_inst.
Proof. unfold Equation1925. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff356_inst, reff356_op in H. discriminate H. Qed.

Lemma reff356_not1931 : ~ @Equation1931 Fin3 reff356_inst.
Proof. unfold Equation1931. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff356_inst, reff356_op in H. discriminate H. Qed.

Lemma reff356_not1932 : ~ @Equation1932 Fin3 reff356_inst.
Proof. unfold Equation1932. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff356_inst, reff356_op in H. discriminate H. Qed.

Lemma reff356_not1934 : ~ @Equation1934 Fin3 reff356_inst.
Proof. unfold Equation1934. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff356_inst, reff356_op in H. discriminate H. Qed.

Lemma reff356_not2035 : ~ @Equation2035 Fin3 reff356_inst.
Proof. unfold Equation2035. intro H. specialize (H F3_1). unfold magma_op, reff356_inst, reff356_op in H. discriminate H. Qed.

Lemma reff356_not2238 : ~ @Equation2238 Fin3 reff356_inst.
Proof. unfold Equation2238. intro H. specialize (H F3_1). unfold magma_op, reff356_inst, reff356_op in H. discriminate H. Qed.

Lemma reff356_not2441 : ~ @Equation2441 Fin3 reff356_inst.
Proof. unfold Equation2441. intro H. specialize (H F3_1). unfold magma_op, reff356_inst, reff356_op in H. discriminate H. Qed.

Lemma reff356_not2644 : ~ @Equation2644 Fin3 reff356_inst.
Proof. unfold Equation2644. intro H. specialize (H F3_1). unfold magma_op, reff356_inst, reff356_op in H. discriminate H. Qed.

Lemma reff356_not2847 : ~ @Equation2847 Fin3 reff356_inst.
Proof. unfold Equation2847. intro H. specialize (H F3_1). unfold magma_op, reff356_inst, reff356_op in H. discriminate H. Qed.

Lemma reff356_not3050 : ~ @Equation3050 Fin3 reff356_inst.
Proof. unfold Equation3050. intro H. specialize (H F3_1). unfold magma_op, reff356_inst, reff356_op in H. discriminate H. Qed.

Lemma reff356_not3254 : ~ @Equation3254 Fin3 reff356_inst.
Proof. unfold Equation3254. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff356_inst, reff356_op in H. discriminate H. Qed.

Lemma reff356_not3256 : ~ @Equation3256 Fin3 reff356_inst.
Proof. unfold Equation3256. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff356_inst, reff356_op in H. discriminate H. Qed.

Lemma reff356_not3258 : ~ @Equation3258 Fin3 reff356_inst.
Proof. unfold Equation3258. intro H. specialize (H F3_1 F3_0). unfold magma_op, reff356_inst, reff356_op in H. discriminate H. Qed.

Lemma reff356_not3259 : ~ @Equation3259 Fin3 reff356_inst.
Proof. unfold Equation3259. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff356_inst, reff356_op in H. discriminate H. Qed.

Lemma reff356_not3261 : ~ @Equation3261 Fin3 reff356_inst.
Proof. unfold Equation3261. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff356_inst, reff356_op in H. discriminate H. Qed.

Lemma reff356_not3262 : ~ @Equation3262 Fin3 reff356_inst.
Proof. unfold Equation3262. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff356_inst, reff356_op in H. discriminate H. Qed.

Lemma reff356_not3268 : ~ @Equation3268 Fin3 reff356_inst.
Proof. unfold Equation3268. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff356_inst, reff356_op in H. discriminate H. Qed.

Lemma reff356_not3269 : ~ @Equation3269 Fin3 reff356_inst.
Proof. unfold Equation3269. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff356_inst, reff356_op in H. discriminate H. Qed.

Lemma reff356_not3271 : ~ @Equation3271 Fin3 reff356_inst.
Proof. unfold Equation3271. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff356_inst, reff356_op in H. discriminate H. Qed.

Lemma reff356_not3272 : ~ @Equation3272 Fin3 reff356_inst.
Proof. unfold Equation3272. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff356_inst, reff356_op in H. discriminate H. Qed.

Lemma reff356_not3278 : ~ @Equation3278 Fin3 reff356_inst.
Proof. unfold Equation3278. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff356_inst, reff356_op in H. discriminate H. Qed.

Lemma reff356_not3279 : ~ @Equation3279 Fin3 reff356_inst.
Proof. unfold Equation3279. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff356_inst, reff356_op in H. discriminate H. Qed.

Lemma reff356_not3281 : ~ @Equation3281 Fin3 reff356_inst.
Proof. unfold Equation3281. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff356_inst, reff356_op in H. discriminate H. Qed.

Lemma reff356_not3306 : ~ @Equation3306 Fin3 reff356_inst.
Proof. unfold Equation3306. intro H. specialize (H F3_2 F3_0). unfold magma_op, reff356_inst, reff356_op in H. discriminate H. Qed.

Lemma reff356_not3308 : ~ @Equation3308 Fin3 reff356_inst.
Proof. unfold Equation3308. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff356_inst, reff356_op in H. discriminate H. Qed.

Lemma reff356_not3309 : ~ @Equation3309 Fin3 reff356_inst.
Proof. unfold Equation3309. intro H. specialize (H F3_1 F3_0). unfold magma_op, reff356_inst, reff356_op in H. discriminate H. Qed.

Lemma reff356_not3315 : ~ @Equation3315 Fin3 reff356_inst.
Proof. unfold Equation3315. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff356_inst, reff356_op in H. discriminate H. Qed.

Lemma reff356_not3318 : ~ @Equation3318 Fin3 reff356_inst.
Proof. unfold Equation3318. intro H. specialize (H F3_2 F3_0). unfold magma_op, reff356_inst, reff356_op in H. discriminate H. Qed.

Lemma reff356_not3342 : ~ @Equation3342 Fin3 reff356_inst.
Proof. unfold Equation3342. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff356_inst, reff356_op in H. discriminate H. Qed.

Lemma reff356_not3343 : ~ @Equation3343 Fin3 reff356_inst.
Proof. unfold Equation3343. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff356_inst, reff356_op in H. discriminate H. Qed.

Lemma reff356_not3345 : ~ @Equation3345 Fin3 reff356_inst.
Proof. unfold Equation3345. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff356_inst, reff356_op in H. discriminate H. Qed.

Lemma reff356_not3346 : ~ @Equation3346 Fin3 reff356_inst.
Proof. unfold Equation3346. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff356_inst, reff356_op in H. discriminate H. Qed.

Lemma reff356_not3352 : ~ @Equation3352 Fin3 reff356_inst.
Proof. unfold Equation3352. intro H. specialize (H F3_1 F3_0). unfold magma_op, reff356_inst, reff356_op in H. discriminate H. Qed.

Lemma reff356_not3353 : ~ @Equation3353 Fin3 reff356_inst.
Proof. unfold Equation3353. intro H. specialize (H F3_1 F3_0). unfold magma_op, reff356_inst, reff356_op in H. discriminate H. Qed.

Lemma reff356_not3456 : ~ @Equation3456 Fin3 reff356_inst.
Proof. unfold Equation3456. intro H. specialize (H F3_1). unfold magma_op, reff356_inst, reff356_op in H. discriminate H. Qed.

Lemma reff356_not3660 : ~ @Equation3660 Fin3 reff356_inst.
Proof. unfold Equation3660. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff356_inst, reff356_op in H. discriminate H. Qed.

Lemma reff356_not3661 : ~ @Equation3661 Fin3 reff356_inst.
Proof. unfold Equation3661. intro H. specialize (H F3_1 F3_2). unfold magma_op, reff356_inst, reff356_op in H. discriminate H. Qed.

Lemma reff356_not3662 : ~ @Equation3662 Fin3 reff356_inst.
Proof. unfold Equation3662. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff356_inst, reff356_op in H. discriminate H. Qed.

Lemma reff356_not3664 : ~ @Equation3664 Fin3 reff356_inst.
Proof. unfold Equation3664. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff356_inst, reff356_op in H. discriminate H. Qed.

Lemma reff356_not3665 : ~ @Equation3665 Fin3 reff356_inst.
Proof. unfold Equation3665. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff356_inst, reff356_op in H. discriminate H. Qed.

Lemma reff356_not3667 : ~ @Equation3667 Fin3 reff356_inst.
Proof. unfold Equation3667. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff356_inst, reff356_op in H. discriminate H. Qed.

Lemma reff356_not3668 : ~ @Equation3668 Fin3 reff356_inst.
Proof. unfold Equation3668. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff356_inst, reff356_op in H. discriminate H. Qed.

Lemma reff356_not3674 : ~ @Equation3674 Fin3 reff356_inst.
Proof. unfold Equation3674. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff356_inst, reff356_op in H. discriminate H. Qed.

Lemma reff356_not3675 : ~ @Equation3675 Fin3 reff356_inst.
Proof. unfold Equation3675. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff356_inst, reff356_op in H. discriminate H. Qed.

Lemma reff356_not3677 : ~ @Equation3677 Fin3 reff356_inst.
Proof. unfold Equation3677. intro H. specialize (H F3_1 F3_2). unfold magma_op, reff356_inst, reff356_op in H. discriminate H. Qed.

Lemma reff356_not3678 : ~ @Equation3678 Fin3 reff356_inst.
Proof. unfold Equation3678. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff356_inst, reff356_op in H. discriminate H. Qed.

Lemma reff356_not3684 : ~ @Equation3684 Fin3 reff356_inst.
Proof. unfold Equation3684. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff356_inst, reff356_op in H. discriminate H. Qed.

Lemma reff356_not3685 : ~ @Equation3685 Fin3 reff356_inst.
Proof. unfold Equation3685. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff356_inst, reff356_op in H. discriminate H. Qed.

Lemma reff356_not3687 : ~ @Equation3687 Fin3 reff356_inst.
Proof. unfold Equation3687. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff356_inst, reff356_op in H. discriminate H. Qed.

Lemma reff356_not3712 : ~ @Equation3712 Fin3 reff356_inst.
Proof. unfold Equation3712. intro H. specialize (H F3_1 F3_0). unfold magma_op, reff356_inst, reff356_op in H. discriminate H. Qed.

Lemma reff356_not3714 : ~ @Equation3714 Fin3 reff356_inst.
Proof. unfold Equation3714. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff356_inst, reff356_op in H. discriminate H. Qed.

Lemma reff356_not3721 : ~ @Equation3721 Fin3 reff356_inst.
Proof. unfold Equation3721. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff356_inst, reff356_op in H. discriminate H. Qed.

Lemma reff356_not3722 : ~ @Equation3722 Fin3 reff356_inst.
Proof. unfold Equation3722. intro H. specialize (H F3_1 F3_0). unfold magma_op, reff356_inst, reff356_op in H. discriminate H. Qed.

Lemma reff356_not3725 : ~ @Equation3725 Fin3 reff356_inst.
Proof. unfold Equation3725. intro H. specialize (H F3_2 F3_1). unfold magma_op, reff356_inst, reff356_op in H. discriminate H. Qed.

Lemma reff356_not3748 : ~ @Equation3748 Fin3 reff356_inst.
Proof. unfold Equation3748. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff356_inst, reff356_op in H. discriminate H. Qed.

Lemma reff356_not3749 : ~ @Equation3749 Fin3 reff356_inst.
Proof. unfold Equation3749. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff356_inst, reff356_op in H. discriminate H. Qed.

Lemma reff356_not3751 : ~ @Equation3751 Fin3 reff356_inst.
Proof. unfold Equation3751. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff356_inst, reff356_op in H. discriminate H. Qed.

Lemma reff356_not3752 : ~ @Equation3752 Fin3 reff356_inst.
Proof. unfold Equation3752. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff356_inst, reff356_op in H. discriminate H. Qed.

Lemma reff356_not3759 : ~ @Equation3759 Fin3 reff356_inst.
Proof. unfold Equation3759. intro H. specialize (H F3_1 F3_0). unfold magma_op, reff356_inst, reff356_op in H. discriminate H. Qed.

Lemma reff356_not3761 : ~ @Equation3761 Fin3 reff356_inst.
Proof. unfold Equation3761. intro H. specialize (H F3_1 F3_0). unfold magma_op, reff356_inst, reff356_op in H. discriminate H. Qed.

Lemma reff356_not3864 : ~ @Equation3864 Fin3 reff356_inst.
Proof. unfold Equation3864. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff356_inst, reff356_op in H. discriminate H. Qed.

Lemma reff356_not3865 : ~ @Equation3865 Fin3 reff356_inst.
Proof. unfold Equation3865. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff356_inst, reff356_op in H. discriminate H. Qed.

Lemma reff356_not3868 : ~ @Equation3868 Fin3 reff356_inst.
Proof. unfold Equation3868. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff356_inst, reff356_op in H. discriminate H. Qed.

Lemma reff356_not3870 : ~ @Equation3870 Fin3 reff356_inst.
Proof. unfold Equation3870. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff356_inst, reff356_op in H. discriminate H. Qed.

Lemma reff356_not3871 : ~ @Equation3871 Fin3 reff356_inst.
Proof. unfold Equation3871. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff356_inst, reff356_op in H. discriminate H. Qed.

Lemma reff356_not3877 : ~ @Equation3877 Fin3 reff356_inst.
Proof. unfold Equation3877. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff356_inst, reff356_op in H. discriminate H. Qed.

Lemma reff356_not3878 : ~ @Equation3878 Fin3 reff356_inst.
Proof. unfold Equation3878. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff356_inst, reff356_op in H. discriminate H. Qed.

Lemma reff356_not3880 : ~ @Equation3880 Fin3 reff356_inst.
Proof. unfold Equation3880. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff356_inst, reff356_op in H. discriminate H. Qed.

Lemma reff356_not3881 : ~ @Equation3881 Fin3 reff356_inst.
Proof. unfold Equation3881. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff356_inst, reff356_op in H. discriminate H. Qed.

Lemma reff356_not3887 : ~ @Equation3887 Fin3 reff356_inst.
Proof. unfold Equation3887. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff356_inst, reff356_op in H. discriminate H. Qed.

Lemma reff356_not3888 : ~ @Equation3888 Fin3 reff356_inst.
Proof. unfold Equation3888. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff356_inst, reff356_op in H. discriminate H. Qed.

Lemma reff356_not3890 : ~ @Equation3890 Fin3 reff356_inst.
Proof. unfold Equation3890. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff356_inst, reff356_op in H. discriminate H. Qed.

Lemma reff356_not3917 : ~ @Equation3917 Fin3 reff356_inst.
Proof. unfold Equation3917. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff356_inst, reff356_op in H. discriminate H. Qed.

Lemma reff356_not3918 : ~ @Equation3918 Fin3 reff356_inst.
Proof. unfold Equation3918. intro H. specialize (H F3_1 F3_0). unfold magma_op, reff356_inst, reff356_op in H. discriminate H. Qed.

Lemma reff356_not3924 : ~ @Equation3924 Fin3 reff356_inst.
Proof. unfold Equation3924. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff356_inst, reff356_op in H. discriminate H. Qed.

Lemma reff356_not3927 : ~ @Equation3927 Fin3 reff356_inst.
Proof. unfold Equation3927. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff356_inst, reff356_op in H. discriminate H. Qed.

Lemma reff356_not3928 : ~ @Equation3928 Fin3 reff356_inst.
Proof. unfold Equation3928. intro H. specialize (H F3_2 F3_1). unfold magma_op, reff356_inst, reff356_op in H. discriminate H. Qed.

Lemma reff356_not3951 : ~ @Equation3951 Fin3 reff356_inst.
Proof. unfold Equation3951. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff356_inst, reff356_op in H. discriminate H. Qed.

Lemma reff356_not3952 : ~ @Equation3952 Fin3 reff356_inst.
Proof. unfold Equation3952. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff356_inst, reff356_op in H. discriminate H. Qed.

Lemma reff356_not3954 : ~ @Equation3954 Fin3 reff356_inst.
Proof. unfold Equation3954. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff356_inst, reff356_op in H. discriminate H. Qed.

Lemma reff356_not3955 : ~ @Equation3955 Fin3 reff356_inst.
Proof. unfold Equation3955. intro H. specialize (H F3_1 F3_0). unfold magma_op, reff356_inst, reff356_op in H. discriminate H. Qed.

Lemma reff356_not3961 : ~ @Equation3961 Fin3 reff356_inst.
Proof. unfold Equation3961. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff356_inst, reff356_op in H. discriminate H. Qed.

Lemma reff356_not3962 : ~ @Equation3962 Fin3 reff356_inst.
Proof. unfold Equation3962. intro H. specialize (H F3_1 F3_0). unfold magma_op, reff356_inst, reff356_op in H. discriminate H. Qed.

Lemma reff356_not3964 : ~ @Equation3964 Fin3 reff356_inst.
Proof. unfold Equation3964. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff356_inst, reff356_op in H. discriminate H. Qed.

Lemma reff356_not4066 : ~ @Equation4066 Fin3 reff356_inst.
Proof. unfold Equation4066. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff356_inst, reff356_op in H. discriminate H. Qed.

Lemma reff356_not4067 : ~ @Equation4067 Fin3 reff356_inst.
Proof. unfold Equation4067. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff356_inst, reff356_op in H. discriminate H. Qed.

Lemma reff356_not4068 : ~ @Equation4068 Fin3 reff356_inst.
Proof. unfold Equation4068. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff356_inst, reff356_op in H. discriminate H. Qed.

Lemma reff356_not4070 : ~ @Equation4070 Fin3 reff356_inst.
Proof. unfold Equation4070. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff356_inst, reff356_op in H. discriminate H. Qed.

Lemma reff356_not4071 : ~ @Equation4071 Fin3 reff356_inst.
Proof. unfold Equation4071. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff356_inst, reff356_op in H. discriminate H. Qed.

Lemma reff356_not4073 : ~ @Equation4073 Fin3 reff356_inst.
Proof. unfold Equation4073. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff356_inst, reff356_op in H. discriminate H. Qed.

Lemma reff356_not4074 : ~ @Equation4074 Fin3 reff356_inst.
Proof. unfold Equation4074. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff356_inst, reff356_op in H. discriminate H. Qed.

Lemma reff356_not4080 : ~ @Equation4080 Fin3 reff356_inst.
Proof. unfold Equation4080. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff356_inst, reff356_op in H. discriminate H. Qed.

Lemma reff356_not4081 : ~ @Equation4081 Fin3 reff356_inst.
Proof. unfold Equation4081. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff356_inst, reff356_op in H. discriminate H. Qed.

Lemma reff356_not4083 : ~ @Equation4083 Fin3 reff356_inst.
Proof. unfold Equation4083. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff356_inst, reff356_op in H. discriminate H. Qed.

Lemma reff356_not4084 : ~ @Equation4084 Fin3 reff356_inst.
Proof. unfold Equation4084. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff356_inst, reff356_op in H. discriminate H. Qed.

Lemma reff356_not4090 : ~ @Equation4090 Fin3 reff356_inst.
Proof. unfold Equation4090. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff356_inst, reff356_op in H. discriminate H. Qed.

Lemma reff356_not4091 : ~ @Equation4091 Fin3 reff356_inst.
Proof. unfold Equation4091. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff356_inst, reff356_op in H. discriminate H. Qed.

Lemma reff356_not4093 : ~ @Equation4093 Fin3 reff356_inst.
Proof. unfold Equation4093. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff356_inst, reff356_op in H. discriminate H. Qed.

Lemma reff356_not4118 : ~ @Equation4118 Fin3 reff356_inst.
Proof. unfold Equation4118. intro H. specialize (H F3_1 F3_0). unfold magma_op, reff356_inst, reff356_op in H. discriminate H. Qed.

Lemma reff356_not4120 : ~ @Equation4120 Fin3 reff356_inst.
Proof. unfold Equation4120. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff356_inst, reff356_op in H. discriminate H. Qed.

Lemma reff356_not4121 : ~ @Equation4121 Fin3 reff356_inst.
Proof. unfold Equation4121. intro H. specialize (H F3_1 F3_0). unfold magma_op, reff356_inst, reff356_op in H. discriminate H. Qed.

Lemma reff356_not4127 : ~ @Equation4127 Fin3 reff356_inst.
Proof. unfold Equation4127. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff356_inst, reff356_op in H. discriminate H. Qed.

Lemma reff356_not4128 : ~ @Equation4128 Fin3 reff356_inst.
Proof. unfold Equation4128. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff356_inst, reff356_op in H. discriminate H. Qed.

Lemma reff356_not4130 : ~ @Equation4130 Fin3 reff356_inst.
Proof. unfold Equation4130. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff356_inst, reff356_op in H. discriminate H. Qed.

Lemma reff356_not4155 : ~ @Equation4155 Fin3 reff356_inst.
Proof. unfold Equation4155. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff356_inst, reff356_op in H. discriminate H. Qed.

Lemma reff356_not4157 : ~ @Equation4157 Fin3 reff356_inst.
Proof. unfold Equation4157. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff356_inst, reff356_op in H. discriminate H. Qed.

Lemma reff356_not4158 : ~ @Equation4158 Fin3 reff356_inst.
Proof. unfold Equation4158. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff356_inst, reff356_op in H. discriminate H. Qed.

Lemma reff356_not4164 : ~ @Equation4164 Fin3 reff356_inst.
Proof. unfold Equation4164. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff356_inst, reff356_op in H. discriminate H. Qed.

Lemma reff356_not4165 : ~ @Equation4165 Fin3 reff356_inst.
Proof. unfold Equation4165. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff356_inst, reff356_op in H. discriminate H. Qed.

Lemma reff356_not4167 : ~ @Equation4167 Fin3 reff356_inst.
Proof. unfold Equation4167. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff356_inst, reff356_op in H. discriminate H. Qed.

Lemma reff356_not4268 : ~ @Equation4268 Fin3 reff356_inst.
Proof. unfold Equation4268. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff356_inst, reff356_op in H. discriminate H. Qed.

Lemma reff356_not4270 : ~ @Equation4270 Fin3 reff356_inst.
Proof. unfold Equation4270. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff356_inst, reff356_op in H. discriminate H. Qed.

Lemma reff356_not4272 : ~ @Equation4272 Fin3 reff356_inst.
Proof. unfold Equation4272. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff356_inst, reff356_op in H. discriminate H. Qed.

Lemma reff356_not4273 : ~ @Equation4273 Fin3 reff356_inst.
Proof. unfold Equation4273. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff356_inst, reff356_op in H. discriminate H. Qed.

Lemma reff356_not4275 : ~ @Equation4275 Fin3 reff356_inst.
Proof. unfold Equation4275. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff356_inst, reff356_op in H. discriminate H. Qed.

Lemma reff356_not4276 : ~ @Equation4276 Fin3 reff356_inst.
Proof. unfold Equation4276. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff356_inst, reff356_op in H. discriminate H. Qed.

Lemma reff356_not4283 : ~ @Equation4283 Fin3 reff356_inst.
Proof. unfold Equation4283. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff356_inst, reff356_op in H. discriminate H. Qed.

Lemma reff356_not4284 : ~ @Equation4284 Fin3 reff356_inst.
Proof. unfold Equation4284. intro H. specialize (H F3_1 F3_0). unfold magma_op, reff356_inst, reff356_op in H. discriminate H. Qed.

Lemma reff356_not4290 : ~ @Equation4290 Fin3 reff356_inst.
Proof. unfold Equation4290. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff356_inst, reff356_op in H. discriminate H. Qed.

Lemma reff356_not4291 : ~ @Equation4291 Fin3 reff356_inst.
Proof. unfold Equation4291. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff356_inst, reff356_op in H. discriminate H. Qed.

Lemma reff356_not4293 : ~ @Equation4293 Fin3 reff356_inst.
Proof. unfold Equation4293. intro H. specialize (H F3_1 F3_2). unfold magma_op, reff356_inst, reff356_op in H. discriminate H. Qed.

Lemma reff356_not4314 : ~ @Equation4314 Fin3 reff356_inst.
Proof. unfold Equation4314. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff356_inst, reff356_op in H. discriminate H. Qed.

Lemma reff356_not4320 : ~ @Equation4320 Fin3 reff356_inst.
Proof. unfold Equation4320. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff356_inst, reff356_op in H. discriminate H. Qed.

Lemma reff356_not4321 : ~ @Equation4321 Fin3 reff356_inst.
Proof. unfold Equation4321. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff356_inst, reff356_op in H. discriminate H. Qed.

Lemma reff356_not4343 : ~ @Equation4343 Fin3 reff356_inst.
Proof. unfold Equation4343. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff356_inst, reff356_op in H. discriminate H. Qed.

Lemma reff356_not4380 : ~ @Equation4380 Fin3 reff356_inst.
Proof. unfold Equation4380. intro H. specialize (H F3_1). unfold magma_op, reff356_inst, reff356_op in H. discriminate H. Qed.

Lemma reff356_not4583 : ~ @Equation4583 Fin3 reff356_inst.
Proof. unfold Equation4583. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff356_inst, reff356_op in H. discriminate H. Qed.

Lemma reff356_not4584 : ~ @Equation4584 Fin3 reff356_inst.
Proof. unfold Equation4584. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff356_inst, reff356_op in H. discriminate H. Qed.

Lemma reff356_not4585 : ~ @Equation4585 Fin3 reff356_inst.
Proof. unfold Equation4585. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff356_inst, reff356_op in H. discriminate H. Qed.

Lemma reff356_not4587 : ~ @Equation4587 Fin3 reff356_inst.
Proof. unfold Equation4587. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff356_inst, reff356_op in H. discriminate H. Qed.

Lemma reff356_not4588 : ~ @Equation4588 Fin3 reff356_inst.
Proof. unfold Equation4588. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff356_inst, reff356_op in H. discriminate H. Qed.

Lemma reff356_not4590 : ~ @Equation4590 Fin3 reff356_inst.
Proof. unfold Equation4590. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff356_inst, reff356_op in H. discriminate H. Qed.

Lemma reff356_not4591 : ~ @Equation4591 Fin3 reff356_inst.
Proof. unfold Equation4591. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff356_inst, reff356_op in H. discriminate H. Qed.

Lemma reff356_not4598 : ~ @Equation4598 Fin3 reff356_inst.
Proof. unfold Equation4598. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff356_inst, reff356_op in H. discriminate H. Qed.

Lemma reff356_not4599 : ~ @Equation4599 Fin3 reff356_inst.
Proof. unfold Equation4599. intro H. specialize (H F3_1 F3_0). unfold magma_op, reff356_inst, reff356_op in H. discriminate H. Qed.

Lemma reff356_not4605 : ~ @Equation4605 Fin3 reff356_inst.
Proof. unfold Equation4605. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff356_inst, reff356_op in H. discriminate H. Qed.

Lemma reff356_not4606 : ~ @Equation4606 Fin3 reff356_inst.
Proof. unfold Equation4606. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff356_inst, reff356_op in H. discriminate H. Qed.

Lemma reff356_not4608 : ~ @Equation4608 Fin3 reff356_inst.
Proof. unfold Equation4608. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff356_inst, reff356_op in H. discriminate H. Qed.

Lemma reff356_not4629 : ~ @Equation4629 Fin3 reff356_inst.
Proof. unfold Equation4629. intro H. specialize (H F3_0 F3_2). unfold magma_op, reff356_inst, reff356_op in H. discriminate H. Qed.

Lemma reff356_not4635 : ~ @Equation4635 Fin3 reff356_inst.
Proof. unfold Equation4635. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff356_inst, reff356_op in H. discriminate H. Qed.

Lemma reff356_not4636 : ~ @Equation4636 Fin3 reff356_inst.
Proof. unfold Equation4636. intro H. specialize (H F3_1 F3_2). unfold magma_op, reff356_inst, reff356_op in H. discriminate H. Qed.

Lemma reff356_not4658 : ~ @Equation4658 Fin3 reff356_inst.
Proof. unfold Equation4658. intro H. specialize (H F3_0 F3_1). unfold magma_op, reff356_inst, reff356_op in H. discriminate H. Qed.

(** ---- reff364 (Fin4) ---- *)

Definition reff364_op (x y : Fin4) : Fin4 :=
  match x, y with
  | F4_0, F4_0 => F4_0 | F4_0, F4_1 => F4_1 | F4_0, F4_2 => F4_0 | F4_0, F4_3 => F4_1
  | F4_1, F4_0 => F4_2 | F4_1, F4_1 => F4_1 | F4_1, F4_2 => F4_2 | F4_1, F4_3 => F4_1
  | F4_2, F4_0 => F4_2 | F4_2, F4_1 => F4_3 | F4_2, F4_2 => F4_2 | F4_2, F4_3 => F4_3
  | F4_3, F4_0 => F4_0 | F4_3, F4_1 => F4_3 | F4_3, F4_2 => F4_0 | F4_3, F4_3 => F4_3
  end.

#[local] Instance reff364_inst : Magma Fin4 := {| magma_op := reff364_op |}.

Lemma reff364_sat10 : @Equation10 Fin4 reff364_inst.
Proof. unfold Equation10, magma_op, reff364_inst, reff364_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff364_sat58 : @Equation58 Fin4 reff364_inst.
Proof. unfold Equation58, magma_op, reff364_inst, reff364_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff364_sat153 : @Equation153 Fin4 reff364_inst.
Proof. unfold Equation153, magma_op, reff364_inst, reff364_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff364_sat208 : @Equation208 Fin4 reff364_inst.
Proof. unfold Equation208, magma_op, reff364_inst, reff364_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff364_sat329 : @Equation329 Fin4 reff364_inst.
Proof. unfold Equation329, magma_op, reff364_inst, reff364_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff364_sat458 : @Equation458 Fin4 reff364_inst.
Proof. unfold Equation458, magma_op, reff364_inst, reff364_op. intros x y z w. destruct x, y, z, w; reflexivity. Qed.

Lemma reff364_sat1437 : @Equation1437 Fin4 reff364_inst.
Proof. unfold Equation1437, magma_op, reff364_inst, reff364_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff364_sat2037 : @Equation2037 Fin4 reff364_inst.
Proof. unfold Equation2037, magma_op, reff364_inst, reff364_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff364_sat2273 : @Equation2273 Fin4 reff364_inst.
Proof. unfold Equation2273, magma_op, reff364_inst, reff364_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff364_sat2649 : @Equation2649 Fin4 reff364_inst.
Proof. unfold Equation2649, magma_op, reff364_inst, reff364_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff364_sat2862 : @Equation2862 Fin4 reff364_inst.
Proof. unfold Equation2862, magma_op, reff364_inst, reff364_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff364_sat3068 : @Equation3068 Fin4 reff364_inst.
Proof. unfold Equation3068, magma_op, reff364_inst, reff364_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma reff364_sat3718 : @Equation3718 Fin4 reff364_inst.
Proof. unfold Equation3718, magma_op, reff364_inst, reff364_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff364_sat3728 : @Equation3728 Fin4 reff364_inst.
Proof. unfold Equation3728, magma_op, reff364_inst, reff364_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff364_sat3939 : @Equation3939 Fin4 reff364_inst.
Proof. unfold Equation3939, magma_op, reff364_inst, reff364_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff364_sat4508 : @Equation4508 Fin4 reff364_inst.
Proof. unfold Equation4508, magma_op, reff364_inst, reff364_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff364_sat4516 : @Equation4516 Fin4 reff364_inst.
Proof. unfold Equation4516, magma_op, reff364_inst, reff364_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma reff364_not50 : ~ @Equation50 Fin4 reff364_inst.
Proof. unfold Equation50. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff364_inst, reff364_op in H. discriminate H. Qed.

Lemma reff364_not53 : ~ @Equation53 Fin4 reff364_inst.
Proof. unfold Equation53. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff364_inst, reff364_op in H. discriminate H. Qed.

Lemma reff364_not56 : ~ @Equation56 Fin4 reff364_inst.
Proof. unfold Equation56. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff364_inst, reff364_op in H. discriminate H. Qed.

Lemma reff364_not63 : ~ @Equation63 Fin4 reff364_inst.
Proof. unfold Equation63. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff364_inst, reff364_op in H. discriminate H. Qed.

Lemma reff364_not65 : ~ @Equation65 Fin4 reff364_inst.
Proof. unfold Equation65. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff364_inst, reff364_op in H. discriminate H. Qed.

Lemma reff364_not66 : ~ @Equation66 Fin4 reff364_inst.
Proof. unfold Equation66. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff364_inst, reff364_op in H. discriminate H. Qed.

Lemma reff364_not72 : ~ @Equation72 Fin4 reff364_inst.
Proof. unfold Equation72. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff364_inst, reff364_op in H. discriminate H. Qed.

Lemma reff364_not73 : ~ @Equation73 Fin4 reff364_inst.
Proof. unfold Equation73. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff364_inst, reff364_op in H. discriminate H. Qed.

Lemma reff364_not75 : ~ @Equation75 Fin4 reff364_inst.
Proof. unfold Equation75. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff364_inst, reff364_op in H. discriminate H. Qed.

Lemma reff364_not102 : ~ @Equation102 Fin4 reff364_inst.
Proof. unfold Equation102. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff364_inst, reff364_op in H. discriminate H. Qed.

Lemma reff364_not105 : ~ @Equation105 Fin4 reff364_inst.
Proof. unfold Equation105. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff364_inst, reff364_op in H. discriminate H. Qed.

Lemma reff364_not108 : ~ @Equation108 Fin4 reff364_inst.
Proof. unfold Equation108. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff364_inst, reff364_op in H. discriminate H. Qed.

Lemma reff364_not115 : ~ @Equation115 Fin4 reff364_inst.
Proof. unfold Equation115. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff364_inst, reff364_op in H. discriminate H. Qed.

Lemma reff364_not117 : ~ @Equation117 Fin4 reff364_inst.
Proof. unfold Equation117. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff364_inst, reff364_op in H. discriminate H. Qed.

Lemma reff364_not118 : ~ @Equation118 Fin4 reff364_inst.
Proof. unfold Equation118. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff364_inst, reff364_op in H. discriminate H. Qed.

Lemma reff364_not124 : ~ @Equation124 Fin4 reff364_inst.
Proof. unfold Equation124. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff364_inst, reff364_op in H. discriminate H. Qed.

Lemma reff364_not125 : ~ @Equation125 Fin4 reff364_inst.
Proof. unfold Equation125. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff364_inst, reff364_op in H. discriminate H. Qed.

Lemma reff364_not127 : ~ @Equation127 Fin4 reff364_inst.
Proof. unfold Equation127. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff364_inst, reff364_op in H. discriminate H. Qed.

Lemma reff364_not154 : ~ @Equation154 Fin4 reff364_inst.
Proof. unfold Equation154. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff364_inst, reff364_op in H. discriminate H. Qed.

Lemma reff364_not157 : ~ @Equation157 Fin4 reff364_inst.
Proof. unfold Equation157. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff364_inst, reff364_op in H. discriminate H. Qed.

Lemma reff364_not159 : ~ @Equation159 Fin4 reff364_inst.
Proof. unfold Equation159. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff364_inst, reff364_op in H. discriminate H. Qed.

Lemma reff364_not160 : ~ @Equation160 Fin4 reff364_inst.
Proof. unfold Equation160. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff364_inst, reff364_op in H. discriminate H. Qed.

Lemma reff364_not167 : ~ @Equation167 Fin4 reff364_inst.
Proof. unfold Equation167. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff364_inst, reff364_op in H. discriminate H. Qed.

Lemma reff364_not169 : ~ @Equation169 Fin4 reff364_inst.
Proof. unfold Equation169. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff364_inst, reff364_op in H. discriminate H. Qed.

Lemma reff364_not170 : ~ @Equation170 Fin4 reff364_inst.
Proof. unfold Equation170. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff364_inst, reff364_op in H. discriminate H. Qed.

Lemma reff364_not176 : ~ @Equation176 Fin4 reff364_inst.
Proof. unfold Equation176. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff364_inst, reff364_op in H. discriminate H. Qed.

Lemma reff364_not177 : ~ @Equation177 Fin4 reff364_inst.
Proof. unfold Equation177. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff364_inst, reff364_op in H. discriminate H. Qed.

Lemma reff364_not179 : ~ @Equation179 Fin4 reff364_inst.
Proof. unfold Equation179. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff364_inst, reff364_op in H. discriminate H. Qed.

Lemma reff364_not206 : ~ @Equation206 Fin4 reff364_inst.
Proof. unfold Equation206. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff364_inst, reff364_op in H. discriminate H. Qed.

Lemma reff364_not209 : ~ @Equation209 Fin4 reff364_inst.
Proof. unfold Equation209. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff364_inst, reff364_op in H. discriminate H. Qed.

Lemma reff364_not211 : ~ @Equation211 Fin4 reff364_inst.
Proof. unfold Equation211. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff364_inst, reff364_op in H. discriminate H. Qed.

Lemma reff364_not212 : ~ @Equation212 Fin4 reff364_inst.
Proof. unfold Equation212. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff364_inst, reff364_op in H. discriminate H. Qed.

Lemma reff364_not219 : ~ @Equation219 Fin4 reff364_inst.
Proof. unfold Equation219. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff364_inst, reff364_op in H. discriminate H. Qed.

Lemma reff364_not221 : ~ @Equation221 Fin4 reff364_inst.
Proof. unfold Equation221. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff364_inst, reff364_op in H. discriminate H. Qed.

Lemma reff364_not222 : ~ @Equation222 Fin4 reff364_inst.
Proof. unfold Equation222. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff364_inst, reff364_op in H. discriminate H. Qed.

Lemma reff364_not228 : ~ @Equation228 Fin4 reff364_inst.
Proof. unfold Equation228. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff364_inst, reff364_op in H. discriminate H. Qed.

Lemma reff364_not229 : ~ @Equation229 Fin4 reff364_inst.
Proof. unfold Equation229. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff364_inst, reff364_op in H. discriminate H. Qed.

Lemma reff364_not231 : ~ @Equation231 Fin4 reff364_inst.
Proof. unfold Equation231. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff364_inst, reff364_op in H. discriminate H. Qed.

Lemma reff364_not258 : ~ @Equation258 Fin4 reff364_inst.
Proof. unfold Equation258. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff364_inst, reff364_op in H. discriminate H. Qed.

Lemma reff364_not261 : ~ @Equation261 Fin4 reff364_inst.
Proof. unfold Equation261. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff364_inst, reff364_op in H. discriminate H. Qed.

Lemma reff364_not263 : ~ @Equation263 Fin4 reff364_inst.
Proof. unfold Equation263. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff364_inst, reff364_op in H. discriminate H. Qed.

Lemma reff364_not264 : ~ @Equation264 Fin4 reff364_inst.
Proof. unfold Equation264. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff364_inst, reff364_op in H. discriminate H. Qed.

Lemma reff364_not271 : ~ @Equation271 Fin4 reff364_inst.
Proof. unfold Equation271. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff364_inst, reff364_op in H. discriminate H. Qed.

Lemma reff364_not273 : ~ @Equation273 Fin4 reff364_inst.
Proof. unfold Equation273. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff364_inst, reff364_op in H. discriminate H. Qed.

Lemma reff364_not274 : ~ @Equation274 Fin4 reff364_inst.
Proof. unfold Equation274. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff364_inst, reff364_op in H. discriminate H. Qed.

Lemma reff364_not280 : ~ @Equation280 Fin4 reff364_inst.
Proof. unfold Equation280. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff364_inst, reff364_op in H. discriminate H. Qed.

Lemma reff364_not281 : ~ @Equation281 Fin4 reff364_inst.
Proof. unfold Equation281. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff364_inst, reff364_op in H. discriminate H. Qed.

Lemma reff364_not283 : ~ @Equation283 Fin4 reff364_inst.
Proof. unfold Equation283. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff364_inst, reff364_op in H. discriminate H. Qed.

Lemma reff364_not412 : ~ @Equation412 Fin4 reff364_inst.
Proof. unfold Equation412. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff364_inst, reff364_op in H. discriminate H. Qed.

Lemma reff364_not414 : ~ @Equation414 Fin4 reff364_inst.
Proof. unfold Equation414. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff364_inst, reff364_op in H. discriminate H. Qed.

Lemma reff364_not417 : ~ @Equation417 Fin4 reff364_inst.
Proof. unfold Equation417. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff364_inst, reff364_op in H. discriminate H. Qed.

Lemma reff364_not420 : ~ @Equation420 Fin4 reff364_inst.
Proof. unfold Equation420. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff364_inst, reff364_op in H. discriminate H. Qed.

Lemma reff364_not427 : ~ @Equation427 Fin4 reff364_inst.
Proof. unfold Equation427. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff364_inst, reff364_op in H. discriminate H. Qed.

Lemma reff364_not430 : ~ @Equation430 Fin4 reff364_inst.
Proof. unfold Equation430. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff364_inst, reff364_op in H. discriminate H. Qed.

Lemma reff364_not437 : ~ @Equation437 Fin4 reff364_inst.
Proof. unfold Equation437. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff364_inst, reff364_op in H. discriminate H. Qed.

Lemma reff364_not440 : ~ @Equation440 Fin4 reff364_inst.
Proof. unfold Equation440. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff364_inst, reff364_op in H. discriminate H. Qed.

Lemma reff364_not463 : ~ @Equation463 Fin4 reff364_inst.
Proof. unfold Equation463. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff364_inst, reff364_op in H. discriminate H. Qed.

Lemma reff364_not464 : ~ @Equation464 Fin4 reff364_inst.
Proof. unfold Equation464. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff364_inst, reff364_op in H. discriminate H. Qed.

Lemma reff364_not466 : ~ @Equation466 Fin4 reff364_inst.
Proof. unfold Equation466. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff364_inst, reff364_op in H. discriminate H. Qed.

Lemma reff364_not467 : ~ @Equation467 Fin4 reff364_inst.
Proof. unfold Equation467. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff364_inst, reff364_op in H. discriminate H. Qed.

Lemma reff364_not473 : ~ @Equation473 Fin4 reff364_inst.
Proof. unfold Equation473. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff364_inst, reff364_op in H. discriminate H. Qed.

Lemma reff364_not474 : ~ @Equation474 Fin4 reff364_inst.
Proof. unfold Equation474. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff364_inst, reff364_op in H. discriminate H. Qed.

Lemma reff364_not476 : ~ @Equation476 Fin4 reff364_inst.
Proof. unfold Equation476. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff364_inst, reff364_op in H. discriminate H. Qed.

Lemma reff364_not477 : ~ @Equation477 Fin4 reff364_inst.
Proof. unfold Equation477. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff364_inst, reff364_op in H. discriminate H. Qed.

Lemma reff364_not500 : ~ @Equation500 Fin4 reff364_inst.
Proof. unfold Equation500. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff364_inst, reff364_op in H. discriminate H. Qed.

Lemma reff364_not501 : ~ @Equation501 Fin4 reff364_inst.
Proof. unfold Equation501. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff364_inst, reff364_op in H. discriminate H. Qed.

Lemma reff364_not503 : ~ @Equation503 Fin4 reff364_inst.
Proof. unfold Equation503. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff364_inst, reff364_op in H. discriminate H. Qed.

Lemma reff364_not504 : ~ @Equation504 Fin4 reff364_inst.
Proof. unfold Equation504. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff364_inst, reff364_op in H. discriminate H. Qed.

Lemma reff364_not510 : ~ @Equation510 Fin4 reff364_inst.
Proof. unfold Equation510. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff364_inst, reff364_op in H. discriminate H. Qed.

Lemma reff364_not511 : ~ @Equation511 Fin4 reff364_inst.
Proof. unfold Equation511. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff364_inst, reff364_op in H. discriminate H. Qed.

Lemma reff364_not513 : ~ @Equation513 Fin4 reff364_inst.
Proof. unfold Equation513. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff364_inst, reff364_op in H. discriminate H. Qed.

Lemma reff364_not615 : ~ @Equation615 Fin4 reff364_inst.
Proof. unfold Equation615. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff364_inst, reff364_op in H. discriminate H. Qed.

Lemma reff364_not617 : ~ @Equation617 Fin4 reff364_inst.
Proof. unfold Equation617. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff364_inst, reff364_op in H. discriminate H. Qed.

Lemma reff364_not620 : ~ @Equation620 Fin4 reff364_inst.
Proof. unfold Equation620. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff364_inst, reff364_op in H. discriminate H. Qed.

Lemma reff364_not623 : ~ @Equation623 Fin4 reff364_inst.
Proof. unfold Equation623. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff364_inst, reff364_op in H. discriminate H. Qed.

Lemma reff364_not630 : ~ @Equation630 Fin4 reff364_inst.
Proof. unfold Equation630. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff364_inst, reff364_op in H. discriminate H. Qed.

Lemma reff364_not633 : ~ @Equation633 Fin4 reff364_inst.
Proof. unfold Equation633. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff364_inst, reff364_op in H. discriminate H. Qed.

Lemma reff364_not640 : ~ @Equation640 Fin4 reff364_inst.
Proof. unfold Equation640. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff364_inst, reff364_op in H. discriminate H. Qed.

Lemma reff364_not643 : ~ @Equation643 Fin4 reff364_inst.
Proof. unfold Equation643. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff364_inst, reff364_op in H. discriminate H. Qed.

Lemma reff364_not666 : ~ @Equation666 Fin4 reff364_inst.
Proof. unfold Equation666. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff364_inst, reff364_op in H. discriminate H. Qed.

Lemma reff364_not667 : ~ @Equation667 Fin4 reff364_inst.
Proof. unfold Equation667. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff364_inst, reff364_op in H. discriminate H. Qed.

Lemma reff364_not669 : ~ @Equation669 Fin4 reff364_inst.
Proof. unfold Equation669. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff364_inst, reff364_op in H. discriminate H. Qed.

Lemma reff364_not670 : ~ @Equation670 Fin4 reff364_inst.
Proof. unfold Equation670. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff364_inst, reff364_op in H. discriminate H. Qed.

Lemma reff364_not676 : ~ @Equation676 Fin4 reff364_inst.
Proof. unfold Equation676. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff364_inst, reff364_op in H. discriminate H. Qed.

Lemma reff364_not677 : ~ @Equation677 Fin4 reff364_inst.
Proof. unfold Equation677. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff364_inst, reff364_op in H. discriminate H. Qed.

Lemma reff364_not679 : ~ @Equation679 Fin4 reff364_inst.
Proof. unfold Equation679. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff364_inst, reff364_op in H. discriminate H. Qed.

Lemma reff364_not680 : ~ @Equation680 Fin4 reff364_inst.
Proof. unfold Equation680. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff364_inst, reff364_op in H. discriminate H. Qed.

Lemma reff364_not703 : ~ @Equation703 Fin4 reff364_inst.
Proof. unfold Equation703. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff364_inst, reff364_op in H. discriminate H. Qed.

Lemma reff364_not704 : ~ @Equation704 Fin4 reff364_inst.
Proof. unfold Equation704. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff364_inst, reff364_op in H. discriminate H. Qed.

Lemma reff364_not706 : ~ @Equation706 Fin4 reff364_inst.
Proof. unfold Equation706. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff364_inst, reff364_op in H. discriminate H. Qed.

Lemma reff364_not707 : ~ @Equation707 Fin4 reff364_inst.
Proof. unfold Equation707. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff364_inst, reff364_op in H. discriminate H. Qed.

Lemma reff364_not713 : ~ @Equation713 Fin4 reff364_inst.
Proof. unfold Equation713. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff364_inst, reff364_op in H. discriminate H. Qed.

Lemma reff364_not714 : ~ @Equation714 Fin4 reff364_inst.
Proof. unfold Equation714. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff364_inst, reff364_op in H. discriminate H. Qed.

Lemma reff364_not716 : ~ @Equation716 Fin4 reff364_inst.
Proof. unfold Equation716. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff364_inst, reff364_op in H. discriminate H. Qed.

Lemma reff364_not818 : ~ @Equation818 Fin4 reff364_inst.
Proof. unfold Equation818. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff364_inst, reff364_op in H. discriminate H. Qed.

Lemma reff364_not820 : ~ @Equation820 Fin4 reff364_inst.
Proof. unfold Equation820. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff364_inst, reff364_op in H. discriminate H. Qed.

Lemma reff364_not823 : ~ @Equation823 Fin4 reff364_inst.
Proof. unfold Equation823. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff364_inst, reff364_op in H. discriminate H. Qed.

Lemma reff364_not826 : ~ @Equation826 Fin4 reff364_inst.
Proof. unfold Equation826. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff364_inst, reff364_op in H. discriminate H. Qed.

Lemma reff364_not833 : ~ @Equation833 Fin4 reff364_inst.
Proof. unfold Equation833. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff364_inst, reff364_op in H. discriminate H. Qed.

Lemma reff364_not836 : ~ @Equation836 Fin4 reff364_inst.
Proof. unfold Equation836. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff364_inst, reff364_op in H. discriminate H. Qed.

Lemma reff364_not843 : ~ @Equation843 Fin4 reff364_inst.
Proof. unfold Equation843. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff364_inst, reff364_op in H. discriminate H. Qed.

Lemma reff364_not846 : ~ @Equation846 Fin4 reff364_inst.
Proof. unfold Equation846. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff364_inst, reff364_op in H. discriminate H. Qed.

Lemma reff364_not869 : ~ @Equation869 Fin4 reff364_inst.
Proof. unfold Equation869. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff364_inst, reff364_op in H. discriminate H. Qed.

Lemma reff364_not870 : ~ @Equation870 Fin4 reff364_inst.
Proof. unfold Equation870. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff364_inst, reff364_op in H. discriminate H. Qed.

Lemma reff364_not872 : ~ @Equation872 Fin4 reff364_inst.
Proof. unfold Equation872. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff364_inst, reff364_op in H. discriminate H. Qed.

Lemma reff364_not873 : ~ @Equation873 Fin4 reff364_inst.
Proof. unfold Equation873. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff364_inst, reff364_op in H. discriminate H. Qed.

Lemma reff364_not879 : ~ @Equation879 Fin4 reff364_inst.
Proof. unfold Equation879. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff364_inst, reff364_op in H. discriminate H. Qed.

Lemma reff364_not880 : ~ @Equation880 Fin4 reff364_inst.
Proof. unfold Equation880. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff364_inst, reff364_op in H. discriminate H. Qed.

Lemma reff364_not882 : ~ @Equation882 Fin4 reff364_inst.
Proof. unfold Equation882. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff364_inst, reff364_op in H. discriminate H. Qed.

Lemma reff364_not883 : ~ @Equation883 Fin4 reff364_inst.
Proof. unfold Equation883. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff364_inst, reff364_op in H. discriminate H. Qed.

Lemma reff364_not906 : ~ @Equation906 Fin4 reff364_inst.
Proof. unfold Equation906. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff364_inst, reff364_op in H. discriminate H. Qed.

Lemma reff364_not907 : ~ @Equation907 Fin4 reff364_inst.
Proof. unfold Equation907. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff364_inst, reff364_op in H. discriminate H. Qed.

Lemma reff364_not909 : ~ @Equation909 Fin4 reff364_inst.
Proof. unfold Equation909. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff364_inst, reff364_op in H. discriminate H. Qed.

Lemma reff364_not910 : ~ @Equation910 Fin4 reff364_inst.
Proof. unfold Equation910. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff364_inst, reff364_op in H. discriminate H. Qed.

Lemma reff364_not916 : ~ @Equation916 Fin4 reff364_inst.
Proof. unfold Equation916. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff364_inst, reff364_op in H. discriminate H. Qed.

Lemma reff364_not917 : ~ @Equation917 Fin4 reff364_inst.
Proof. unfold Equation917. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff364_inst, reff364_op in H. discriminate H. Qed.

Lemma reff364_not919 : ~ @Equation919 Fin4 reff364_inst.
Proof. unfold Equation919. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff364_inst, reff364_op in H. discriminate H. Qed.

Lemma reff364_not1021 : ~ @Equation1021 Fin4 reff364_inst.
Proof. unfold Equation1021. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff364_inst, reff364_op in H. discriminate H. Qed.

Lemma reff364_not1023 : ~ @Equation1023 Fin4 reff364_inst.
Proof. unfold Equation1023. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff364_inst, reff364_op in H. discriminate H. Qed.

Lemma reff364_not1026 : ~ @Equation1026 Fin4 reff364_inst.
Proof. unfold Equation1026. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff364_inst, reff364_op in H. discriminate H. Qed.

Lemma reff364_not1029 : ~ @Equation1029 Fin4 reff364_inst.
Proof. unfold Equation1029. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff364_inst, reff364_op in H. discriminate H. Qed.

Lemma reff364_not1036 : ~ @Equation1036 Fin4 reff364_inst.
Proof. unfold Equation1036. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff364_inst, reff364_op in H. discriminate H. Qed.

Lemma reff364_not1039 : ~ @Equation1039 Fin4 reff364_inst.
Proof. unfold Equation1039. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff364_inst, reff364_op in H. discriminate H. Qed.

Lemma reff364_not1046 : ~ @Equation1046 Fin4 reff364_inst.
Proof. unfold Equation1046. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff364_inst, reff364_op in H. discriminate H. Qed.

Lemma reff364_not1049 : ~ @Equation1049 Fin4 reff364_inst.
Proof. unfold Equation1049. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff364_inst, reff364_op in H. discriminate H. Qed.

Lemma reff364_not1072 : ~ @Equation1072 Fin4 reff364_inst.
Proof. unfold Equation1072. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff364_inst, reff364_op in H. discriminate H. Qed.

Lemma reff364_not1073 : ~ @Equation1073 Fin4 reff364_inst.
Proof. unfold Equation1073. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff364_inst, reff364_op in H. discriminate H. Qed.

Lemma reff364_not1075 : ~ @Equation1075 Fin4 reff364_inst.
Proof. unfold Equation1075. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff364_inst, reff364_op in H. discriminate H. Qed.

Lemma reff364_not1076 : ~ @Equation1076 Fin4 reff364_inst.
Proof. unfold Equation1076. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff364_inst, reff364_op in H. discriminate H. Qed.

Lemma reff364_not1082 : ~ @Equation1082 Fin4 reff364_inst.
Proof. unfold Equation1082. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff364_inst, reff364_op in H. discriminate H. Qed.

Lemma reff364_not1083 : ~ @Equation1083 Fin4 reff364_inst.
Proof. unfold Equation1083. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff364_inst, reff364_op in H. discriminate H. Qed.

Lemma reff364_not1085 : ~ @Equation1085 Fin4 reff364_inst.
Proof. unfold Equation1085. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff364_inst, reff364_op in H. discriminate H. Qed.

Lemma reff364_not1086 : ~ @Equation1086 Fin4 reff364_inst.
Proof. unfold Equation1086. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff364_inst, reff364_op in H. discriminate H. Qed.

Lemma reff364_not1109 : ~ @Equation1109 Fin4 reff364_inst.
Proof. unfold Equation1109. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff364_inst, reff364_op in H. discriminate H. Qed.

Lemma reff364_not1110 : ~ @Equation1110 Fin4 reff364_inst.
Proof. unfold Equation1110. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff364_inst, reff364_op in H. discriminate H. Qed.

Lemma reff364_not1112 : ~ @Equation1112 Fin4 reff364_inst.
Proof. unfold Equation1112. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff364_inst, reff364_op in H. discriminate H. Qed.

Lemma reff364_not1113 : ~ @Equation1113 Fin4 reff364_inst.
Proof. unfold Equation1113. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff364_inst, reff364_op in H. discriminate H. Qed.

Lemma reff364_not1119 : ~ @Equation1119 Fin4 reff364_inst.
Proof. unfold Equation1119. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff364_inst, reff364_op in H. discriminate H. Qed.

Lemma reff364_not1120 : ~ @Equation1120 Fin4 reff364_inst.
Proof. unfold Equation1120. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff364_inst, reff364_op in H. discriminate H. Qed.

Lemma reff364_not1122 : ~ @Equation1122 Fin4 reff364_inst.
Proof. unfold Equation1122. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff364_inst, reff364_op in H. discriminate H. Qed.

Lemma reff364_not1224 : ~ @Equation1224 Fin4 reff364_inst.
Proof. unfold Equation1224. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff364_inst, reff364_op in H. discriminate H. Qed.

Lemma reff364_not1226 : ~ @Equation1226 Fin4 reff364_inst.
Proof. unfold Equation1226. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff364_inst, reff364_op in H. discriminate H. Qed.

Lemma reff364_not1229 : ~ @Equation1229 Fin4 reff364_inst.
Proof. unfold Equation1229. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff364_inst, reff364_op in H. discriminate H. Qed.

Lemma reff364_not1232 : ~ @Equation1232 Fin4 reff364_inst.
Proof. unfold Equation1232. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff364_inst, reff364_op in H. discriminate H. Qed.

Lemma reff364_not1239 : ~ @Equation1239 Fin4 reff364_inst.
Proof. unfold Equation1239. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff364_inst, reff364_op in H. discriminate H. Qed.

Lemma reff364_not1242 : ~ @Equation1242 Fin4 reff364_inst.
Proof. unfold Equation1242. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff364_inst, reff364_op in H. discriminate H. Qed.

Lemma reff364_not1249 : ~ @Equation1249 Fin4 reff364_inst.
Proof. unfold Equation1249. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff364_inst, reff364_op in H. discriminate H. Qed.

Lemma reff364_not1252 : ~ @Equation1252 Fin4 reff364_inst.
Proof. unfold Equation1252. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff364_inst, reff364_op in H. discriminate H. Qed.

Lemma reff364_not1275 : ~ @Equation1275 Fin4 reff364_inst.
Proof. unfold Equation1275. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff364_inst, reff364_op in H. discriminate H. Qed.

Lemma reff364_not1276 : ~ @Equation1276 Fin4 reff364_inst.
Proof. unfold Equation1276. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff364_inst, reff364_op in H. discriminate H. Qed.

Lemma reff364_not1278 : ~ @Equation1278 Fin4 reff364_inst.
Proof. unfold Equation1278. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff364_inst, reff364_op in H. discriminate H. Qed.

Lemma reff364_not1279 : ~ @Equation1279 Fin4 reff364_inst.
Proof. unfold Equation1279. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff364_inst, reff364_op in H. discriminate H. Qed.

Lemma reff364_not1285 : ~ @Equation1285 Fin4 reff364_inst.
Proof. unfold Equation1285. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff364_inst, reff364_op in H. discriminate H. Qed.

Lemma reff364_not1286 : ~ @Equation1286 Fin4 reff364_inst.
Proof. unfold Equation1286. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff364_inst, reff364_op in H. discriminate H. Qed.

Lemma reff364_not1288 : ~ @Equation1288 Fin4 reff364_inst.
Proof. unfold Equation1288. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff364_inst, reff364_op in H. discriminate H. Qed.

Lemma reff364_not1289 : ~ @Equation1289 Fin4 reff364_inst.
Proof. unfold Equation1289. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff364_inst, reff364_op in H. discriminate H. Qed.

Lemma reff364_not1312 : ~ @Equation1312 Fin4 reff364_inst.
Proof. unfold Equation1312. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff364_inst, reff364_op in H. discriminate H. Qed.

Lemma reff364_not1313 : ~ @Equation1313 Fin4 reff364_inst.
Proof. unfold Equation1313. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff364_inst, reff364_op in H. discriminate H. Qed.

Lemma reff364_not1315 : ~ @Equation1315 Fin4 reff364_inst.
Proof. unfold Equation1315. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff364_inst, reff364_op in H. discriminate H. Qed.

Lemma reff364_not1316 : ~ @Equation1316 Fin4 reff364_inst.
Proof. unfold Equation1316. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff364_inst, reff364_op in H. discriminate H. Qed.

Lemma reff364_not1322 : ~ @Equation1322 Fin4 reff364_inst.
Proof. unfold Equation1322. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff364_inst, reff364_op in H. discriminate H. Qed.

Lemma reff364_not1323 : ~ @Equation1323 Fin4 reff364_inst.
Proof. unfold Equation1323. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff364_inst, reff364_op in H. discriminate H. Qed.

Lemma reff364_not1325 : ~ @Equation1325 Fin4 reff364_inst.
Proof. unfold Equation1325. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff364_inst, reff364_op in H. discriminate H. Qed.

Lemma reff364_not1427 : ~ @Equation1427 Fin4 reff364_inst.
Proof. unfold Equation1427. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff364_inst, reff364_op in H. discriminate H. Qed.

Lemma reff364_not1429 : ~ @Equation1429 Fin4 reff364_inst.
Proof. unfold Equation1429. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff364_inst, reff364_op in H. discriminate H. Qed.

Lemma reff364_not1432 : ~ @Equation1432 Fin4 reff364_inst.
Proof. unfold Equation1432. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff364_inst, reff364_op in H. discriminate H. Qed.

Lemma reff364_not1435 : ~ @Equation1435 Fin4 reff364_inst.
Proof. unfold Equation1435. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff364_inst, reff364_op in H. discriminate H. Qed.

Lemma reff364_not1441 : ~ @Equation1441 Fin4 reff364_inst.
Proof. unfold Equation1441. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff364_inst, reff364_op in H. discriminate H. Qed.

Lemma reff364_not1442 : ~ @Equation1442 Fin4 reff364_inst.
Proof. unfold Equation1442. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff364_inst, reff364_op in H. discriminate H. Qed.

Lemma reff364_not1444 : ~ @Equation1444 Fin4 reff364_inst.
Proof. unfold Equation1444. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff364_inst, reff364_op in H. discriminate H. Qed.

Lemma reff364_not1445 : ~ @Equation1445 Fin4 reff364_inst.
Proof. unfold Equation1445. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff364_inst, reff364_op in H. discriminate H. Qed.

Lemma reff364_not1451 : ~ @Equation1451 Fin4 reff364_inst.
Proof. unfold Equation1451. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff364_inst, reff364_op in H. discriminate H. Qed.

Lemma reff364_not1452 : ~ @Equation1452 Fin4 reff364_inst.
Proof. unfold Equation1452. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff364_inst, reff364_op in H. discriminate H. Qed.

Lemma reff364_not1454 : ~ @Equation1454 Fin4 reff364_inst.
Proof. unfold Equation1454. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff364_inst, reff364_op in H. discriminate H. Qed.

Lemma reff364_not1455 : ~ @Equation1455 Fin4 reff364_inst.
Proof. unfold Equation1455. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff364_inst, reff364_op in H. discriminate H. Qed.

Lemma reff364_not1478 : ~ @Equation1478 Fin4 reff364_inst.
Proof. unfold Equation1478. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff364_inst, reff364_op in H. discriminate H. Qed.

Lemma reff364_not1479 : ~ @Equation1479 Fin4 reff364_inst.
Proof. unfold Equation1479. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff364_inst, reff364_op in H. discriminate H. Qed.

Lemma reff364_not1481 : ~ @Equation1481 Fin4 reff364_inst.
Proof. unfold Equation1481. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff364_inst, reff364_op in H. discriminate H. Qed.

Lemma reff364_not1482 : ~ @Equation1482 Fin4 reff364_inst.
Proof. unfold Equation1482. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff364_inst, reff364_op in H. discriminate H. Qed.

Lemma reff364_not1488 : ~ @Equation1488 Fin4 reff364_inst.
Proof. unfold Equation1488. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff364_inst, reff364_op in H. discriminate H. Qed.

Lemma reff364_not1489 : ~ @Equation1489 Fin4 reff364_inst.
Proof. unfold Equation1489. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff364_inst, reff364_op in H. discriminate H. Qed.

Lemma reff364_not1491 : ~ @Equation1491 Fin4 reff364_inst.
Proof. unfold Equation1491. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff364_inst, reff364_op in H. discriminate H. Qed.

Lemma reff364_not1492 : ~ @Equation1492 Fin4 reff364_inst.
Proof. unfold Equation1492. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff364_inst, reff364_op in H. discriminate H. Qed.

Lemma reff364_not1515 : ~ @Equation1515 Fin4 reff364_inst.
Proof. unfold Equation1515. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff364_inst, reff364_op in H. discriminate H. Qed.

Lemma reff364_not1516 : ~ @Equation1516 Fin4 reff364_inst.
Proof. unfold Equation1516. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff364_inst, reff364_op in H. discriminate H. Qed.

Lemma reff364_not1518 : ~ @Equation1518 Fin4 reff364_inst.
Proof. unfold Equation1518. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff364_inst, reff364_op in H. discriminate H. Qed.

Lemma reff364_not1519 : ~ @Equation1519 Fin4 reff364_inst.
Proof. unfold Equation1519. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff364_inst, reff364_op in H. discriminate H. Qed.

Lemma reff364_not1525 : ~ @Equation1525 Fin4 reff364_inst.
Proof. unfold Equation1525. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff364_inst, reff364_op in H. discriminate H. Qed.

Lemma reff364_not1526 : ~ @Equation1526 Fin4 reff364_inst.
Proof. unfold Equation1526. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff364_inst, reff364_op in H. discriminate H. Qed.

Lemma reff364_not1528 : ~ @Equation1528 Fin4 reff364_inst.
Proof. unfold Equation1528. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff364_inst, reff364_op in H. discriminate H. Qed.

Lemma reff364_not1630 : ~ @Equation1630 Fin4 reff364_inst.
Proof. unfold Equation1630. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff364_inst, reff364_op in H. discriminate H. Qed.

Lemma reff364_not1632 : ~ @Equation1632 Fin4 reff364_inst.
Proof. unfold Equation1632. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff364_inst, reff364_op in H. discriminate H. Qed.

Lemma reff364_not1635 : ~ @Equation1635 Fin4 reff364_inst.
Proof. unfold Equation1635. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff364_inst, reff364_op in H. discriminate H. Qed.

Lemma reff364_not1638 : ~ @Equation1638 Fin4 reff364_inst.
Proof. unfold Equation1638. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff364_inst, reff364_op in H. discriminate H. Qed.

Lemma reff364_not1644 : ~ @Equation1644 Fin4 reff364_inst.
Proof. unfold Equation1644. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff364_inst, reff364_op in H. discriminate H. Qed.

Lemma reff364_not1645 : ~ @Equation1645 Fin4 reff364_inst.
Proof. unfold Equation1645. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff364_inst, reff364_op in H. discriminate H. Qed.

Lemma reff364_not1647 : ~ @Equation1647 Fin4 reff364_inst.
Proof. unfold Equation1647. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff364_inst, reff364_op in H. discriminate H. Qed.

Lemma reff364_not1648 : ~ @Equation1648 Fin4 reff364_inst.
Proof. unfold Equation1648. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff364_inst, reff364_op in H. discriminate H. Qed.

Lemma reff364_not1654 : ~ @Equation1654 Fin4 reff364_inst.
Proof. unfold Equation1654. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff364_inst, reff364_op in H. discriminate H. Qed.

Lemma reff364_not1655 : ~ @Equation1655 Fin4 reff364_inst.
Proof. unfold Equation1655. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff364_inst, reff364_op in H. discriminate H. Qed.

Lemma reff364_not1657 : ~ @Equation1657 Fin4 reff364_inst.
Proof. unfold Equation1657. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff364_inst, reff364_op in H. discriminate H. Qed.

Lemma reff364_not1658 : ~ @Equation1658 Fin4 reff364_inst.
Proof. unfold Equation1658. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff364_inst, reff364_op in H. discriminate H. Qed.

Lemma reff364_not1681 : ~ @Equation1681 Fin4 reff364_inst.
Proof. unfold Equation1681. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff364_inst, reff364_op in H. discriminate H. Qed.

Lemma reff364_not1682 : ~ @Equation1682 Fin4 reff364_inst.
Proof. unfold Equation1682. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff364_inst, reff364_op in H. discriminate H. Qed.

Lemma reff364_not1684 : ~ @Equation1684 Fin4 reff364_inst.
Proof. unfold Equation1684. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff364_inst, reff364_op in H. discriminate H. Qed.

Lemma reff364_not1685 : ~ @Equation1685 Fin4 reff364_inst.
Proof. unfold Equation1685. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff364_inst, reff364_op in H. discriminate H. Qed.

Lemma reff364_not1691 : ~ @Equation1691 Fin4 reff364_inst.
Proof. unfold Equation1691. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff364_inst, reff364_op in H. discriminate H. Qed.

Lemma reff364_not1692 : ~ @Equation1692 Fin4 reff364_inst.
Proof. unfold Equation1692. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff364_inst, reff364_op in H. discriminate H. Qed.

Lemma reff364_not1694 : ~ @Equation1694 Fin4 reff364_inst.
Proof. unfold Equation1694. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff364_inst, reff364_op in H. discriminate H. Qed.

Lemma reff364_not1695 : ~ @Equation1695 Fin4 reff364_inst.
Proof. unfold Equation1695. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff364_inst, reff364_op in H. discriminate H. Qed.

Lemma reff364_not1718 : ~ @Equation1718 Fin4 reff364_inst.
Proof. unfold Equation1718. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff364_inst, reff364_op in H. discriminate H. Qed.

Lemma reff364_not1719 : ~ @Equation1719 Fin4 reff364_inst.
Proof. unfold Equation1719. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff364_inst, reff364_op in H. discriminate H. Qed.

Lemma reff364_not1721 : ~ @Equation1721 Fin4 reff364_inst.
Proof. unfold Equation1721. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff364_inst, reff364_op in H. discriminate H. Qed.

Lemma reff364_not1722 : ~ @Equation1722 Fin4 reff364_inst.
Proof. unfold Equation1722. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff364_inst, reff364_op in H. discriminate H. Qed.

Lemma reff364_not1728 : ~ @Equation1728 Fin4 reff364_inst.
Proof. unfold Equation1728. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff364_inst, reff364_op in H. discriminate H. Qed.

Lemma reff364_not1729 : ~ @Equation1729 Fin4 reff364_inst.
Proof. unfold Equation1729. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff364_inst, reff364_op in H. discriminate H. Qed.

Lemma reff364_not1731 : ~ @Equation1731 Fin4 reff364_inst.
Proof. unfold Equation1731. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff364_inst, reff364_op in H. discriminate H. Qed.

Lemma reff364_not1833 : ~ @Equation1833 Fin4 reff364_inst.
Proof. unfold Equation1833. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff364_inst, reff364_op in H. discriminate H. Qed.

Lemma reff364_not1835 : ~ @Equation1835 Fin4 reff364_inst.
Proof. unfold Equation1835. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff364_inst, reff364_op in H. discriminate H. Qed.

Lemma reff364_not1837 : ~ @Equation1837 Fin4 reff364_inst.
Proof. unfold Equation1837. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff364_inst, reff364_op in H. discriminate H. Qed.

Lemma reff364_not1838 : ~ @Equation1838 Fin4 reff364_inst.
Proof. unfold Equation1838. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff364_inst, reff364_op in H. discriminate H. Qed.

Lemma reff364_not1840 : ~ @Equation1840 Fin4 reff364_inst.
Proof. unfold Equation1840. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff364_inst, reff364_op in H. discriminate H. Qed.

Lemma reff364_not1841 : ~ @Equation1841 Fin4 reff364_inst.
Proof. unfold Equation1841. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff364_inst, reff364_op in H. discriminate H. Qed.

Lemma reff364_not1848 : ~ @Equation1848 Fin4 reff364_inst.
Proof. unfold Equation1848. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff364_inst, reff364_op in H. discriminate H. Qed.

Lemma reff364_not1851 : ~ @Equation1851 Fin4 reff364_inst.
Proof. unfold Equation1851. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff364_inst, reff364_op in H. discriminate H. Qed.

Lemma reff364_not1857 : ~ @Equation1857 Fin4 reff364_inst.
Proof. unfold Equation1857. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff364_inst, reff364_op in H. discriminate H. Qed.

Lemma reff364_not1858 : ~ @Equation1858 Fin4 reff364_inst.
Proof. unfold Equation1858. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff364_inst, reff364_op in H. discriminate H. Qed.

Lemma reff364_not1860 : ~ @Equation1860 Fin4 reff364_inst.
Proof. unfold Equation1860. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff364_inst, reff364_op in H. discriminate H. Qed.

Lemma reff364_not1861 : ~ @Equation1861 Fin4 reff364_inst.
Proof. unfold Equation1861. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff364_inst, reff364_op in H. discriminate H. Qed.

Lemma reff364_not1884 : ~ @Equation1884 Fin4 reff364_inst.
Proof. unfold Equation1884. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff364_inst, reff364_op in H. discriminate H. Qed.

Lemma reff364_not1885 : ~ @Equation1885 Fin4 reff364_inst.
Proof. unfold Equation1885. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff364_inst, reff364_op in H. discriminate H. Qed.

Lemma reff364_not1887 : ~ @Equation1887 Fin4 reff364_inst.
Proof. unfold Equation1887. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff364_inst, reff364_op in H. discriminate H. Qed.

Lemma reff364_not1888 : ~ @Equation1888 Fin4 reff364_inst.
Proof. unfold Equation1888. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff364_inst, reff364_op in H. discriminate H. Qed.

Lemma reff364_not1894 : ~ @Equation1894 Fin4 reff364_inst.
Proof. unfold Equation1894. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff364_inst, reff364_op in H. discriminate H. Qed.

Lemma reff364_not1895 : ~ @Equation1895 Fin4 reff364_inst.
Proof. unfold Equation1895. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff364_inst, reff364_op in H. discriminate H. Qed.

Lemma reff364_not1897 : ~ @Equation1897 Fin4 reff364_inst.
Proof. unfold Equation1897. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff364_inst, reff364_op in H. discriminate H. Qed.

Lemma reff364_not1898 : ~ @Equation1898 Fin4 reff364_inst.
Proof. unfold Equation1898. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff364_inst, reff364_op in H. discriminate H. Qed.

Lemma reff364_not1921 : ~ @Equation1921 Fin4 reff364_inst.
Proof. unfold Equation1921. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff364_inst, reff364_op in H. discriminate H. Qed.

Lemma reff364_not1922 : ~ @Equation1922 Fin4 reff364_inst.
Proof. unfold Equation1922. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff364_inst, reff364_op in H. discriminate H. Qed.

Lemma reff364_not1924 : ~ @Equation1924 Fin4 reff364_inst.
Proof. unfold Equation1924. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff364_inst, reff364_op in H. discriminate H. Qed.

Lemma reff364_not1925 : ~ @Equation1925 Fin4 reff364_inst.
Proof. unfold Equation1925. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff364_inst, reff364_op in H. discriminate H. Qed.

Lemma reff364_not1931 : ~ @Equation1931 Fin4 reff364_inst.
Proof. unfold Equation1931. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff364_inst, reff364_op in H. discriminate H. Qed.

Lemma reff364_not1932 : ~ @Equation1932 Fin4 reff364_inst.
Proof. unfold Equation1932. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff364_inst, reff364_op in H. discriminate H. Qed.

Lemma reff364_not1934 : ~ @Equation1934 Fin4 reff364_inst.
Proof. unfold Equation1934. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff364_inst, reff364_op in H. discriminate H. Qed.

Lemma reff364_not2036 : ~ @Equation2036 Fin4 reff364_inst.
Proof. unfold Equation2036. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff364_inst, reff364_op in H. discriminate H. Qed.

Lemma reff364_not2038 : ~ @Equation2038 Fin4 reff364_inst.
Proof. unfold Equation2038. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff364_inst, reff364_op in H. discriminate H. Qed.

Lemma reff364_not2040 : ~ @Equation2040 Fin4 reff364_inst.
Proof. unfold Equation2040. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff364_inst, reff364_op in H. discriminate H. Qed.

Lemma reff364_not2041 : ~ @Equation2041 Fin4 reff364_inst.
Proof. unfold Equation2041. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff364_inst, reff364_op in H. discriminate H. Qed.

Lemma reff364_not2043 : ~ @Equation2043 Fin4 reff364_inst.
Proof. unfold Equation2043. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff364_inst, reff364_op in H. discriminate H. Qed.

Lemma reff364_not2044 : ~ @Equation2044 Fin4 reff364_inst.
Proof. unfold Equation2044. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff364_inst, reff364_op in H. discriminate H. Qed.

Lemma reff364_not2050 : ~ @Equation2050 Fin4 reff364_inst.
Proof. unfold Equation2050. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff364_inst, reff364_op in H. discriminate H. Qed.

Lemma reff364_not2051 : ~ @Equation2051 Fin4 reff364_inst.
Proof. unfold Equation2051. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff364_inst, reff364_op in H. discriminate H. Qed.

Lemma reff364_not2053 : ~ @Equation2053 Fin4 reff364_inst.
Proof. unfold Equation2053. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff364_inst, reff364_op in H. discriminate H. Qed.

Lemma reff364_not2054 : ~ @Equation2054 Fin4 reff364_inst.
Proof. unfold Equation2054. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff364_inst, reff364_op in H. discriminate H. Qed.

Lemma reff364_not2060 : ~ @Equation2060 Fin4 reff364_inst.
Proof. unfold Equation2060. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff364_inst, reff364_op in H. discriminate H. Qed.

Lemma reff364_not2061 : ~ @Equation2061 Fin4 reff364_inst.
Proof. unfold Equation2061. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff364_inst, reff364_op in H. discriminate H. Qed.

Lemma reff364_not2063 : ~ @Equation2063 Fin4 reff364_inst.
Proof. unfold Equation2063. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff364_inst, reff364_op in H. discriminate H. Qed.

Lemma reff364_not2064 : ~ @Equation2064 Fin4 reff364_inst.
Proof. unfold Equation2064. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff364_inst, reff364_op in H. discriminate H. Qed.

Lemma reff364_not2087 : ~ @Equation2087 Fin4 reff364_inst.
Proof. unfold Equation2087. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff364_inst, reff364_op in H. discriminate H. Qed.

Lemma reff364_not2088 : ~ @Equation2088 Fin4 reff364_inst.
Proof. unfold Equation2088. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff364_inst, reff364_op in H. discriminate H. Qed.

Lemma reff364_not2090 : ~ @Equation2090 Fin4 reff364_inst.
Proof. unfold Equation2090. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff364_inst, reff364_op in H. discriminate H. Qed.

Lemma reff364_not2091 : ~ @Equation2091 Fin4 reff364_inst.
Proof. unfold Equation2091. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff364_inst, reff364_op in H. discriminate H. Qed.

Lemma reff364_not2097 : ~ @Equation2097 Fin4 reff364_inst.
Proof. unfold Equation2097. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff364_inst, reff364_op in H. discriminate H. Qed.

Lemma reff364_not2098 : ~ @Equation2098 Fin4 reff364_inst.
Proof. unfold Equation2098. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff364_inst, reff364_op in H. discriminate H. Qed.

Lemma reff364_not2100 : ~ @Equation2100 Fin4 reff364_inst.
Proof. unfold Equation2100. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff364_inst, reff364_op in H. discriminate H. Qed.

Lemma reff364_not2101 : ~ @Equation2101 Fin4 reff364_inst.
Proof. unfold Equation2101. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff364_inst, reff364_op in H. discriminate H. Qed.

Lemma reff364_not2124 : ~ @Equation2124 Fin4 reff364_inst.
Proof. unfold Equation2124. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff364_inst, reff364_op in H. discriminate H. Qed.

Lemma reff364_not2125 : ~ @Equation2125 Fin4 reff364_inst.
Proof. unfold Equation2125. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff364_inst, reff364_op in H. discriminate H. Qed.

Lemma reff364_not2127 : ~ @Equation2127 Fin4 reff364_inst.
Proof. unfold Equation2127. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff364_inst, reff364_op in H. discriminate H. Qed.

Lemma reff364_not2128 : ~ @Equation2128 Fin4 reff364_inst.
Proof. unfold Equation2128. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff364_inst, reff364_op in H. discriminate H. Qed.

Lemma reff364_not2134 : ~ @Equation2134 Fin4 reff364_inst.
Proof. unfold Equation2134. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff364_inst, reff364_op in H. discriminate H. Qed.

Lemma reff364_not2135 : ~ @Equation2135 Fin4 reff364_inst.
Proof. unfold Equation2135. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff364_inst, reff364_op in H. discriminate H. Qed.

Lemma reff364_not2137 : ~ @Equation2137 Fin4 reff364_inst.
Proof. unfold Equation2137. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff364_inst, reff364_op in H. discriminate H. Qed.

Lemma reff364_not2239 : ~ @Equation2239 Fin4 reff364_inst.
Proof. unfold Equation2239. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff364_inst, reff364_op in H. discriminate H. Qed.

Lemma reff364_not2240 : ~ @Equation2240 Fin4 reff364_inst.
Proof. unfold Equation2240. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff364_inst, reff364_op in H. discriminate H. Qed.

Lemma reff364_not2241 : ~ @Equation2241 Fin4 reff364_inst.
Proof. unfold Equation2241. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff364_inst, reff364_op in H. discriminate H. Qed.

Lemma reff364_not2244 : ~ @Equation2244 Fin4 reff364_inst.
Proof. unfold Equation2244. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff364_inst, reff364_op in H. discriminate H. Qed.

Lemma reff364_not2246 : ~ @Equation2246 Fin4 reff364_inst.
Proof. unfold Equation2246. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff364_inst, reff364_op in H. discriminate H. Qed.

Lemma reff364_not2247 : ~ @Equation2247 Fin4 reff364_inst.
Proof. unfold Equation2247. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff364_inst, reff364_op in H. discriminate H. Qed.

Lemma reff364_not2254 : ~ @Equation2254 Fin4 reff364_inst.
Proof. unfold Equation2254. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff364_inst, reff364_op in H. discriminate H. Qed.

Lemma reff364_not2256 : ~ @Equation2256 Fin4 reff364_inst.
Proof. unfold Equation2256. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff364_inst, reff364_op in H. discriminate H. Qed.

Lemma reff364_not2257 : ~ @Equation2257 Fin4 reff364_inst.
Proof. unfold Equation2257. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff364_inst, reff364_op in H. discriminate H. Qed.

Lemma reff364_not2264 : ~ @Equation2264 Fin4 reff364_inst.
Proof. unfold Equation2264. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff364_inst, reff364_op in H. discriminate H. Qed.

Lemma reff364_not2266 : ~ @Equation2266 Fin4 reff364_inst.
Proof. unfold Equation2266. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff364_inst, reff364_op in H. discriminate H. Qed.

Lemma reff364_not2267 : ~ @Equation2267 Fin4 reff364_inst.
Proof. unfold Equation2267. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff364_inst, reff364_op in H. discriminate H. Qed.

Lemma reff364_not2290 : ~ @Equation2290 Fin4 reff364_inst.
Proof. unfold Equation2290. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff364_inst, reff364_op in H. discriminate H. Qed.

Lemma reff364_not2291 : ~ @Equation2291 Fin4 reff364_inst.
Proof. unfold Equation2291. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff364_inst, reff364_op in H. discriminate H. Qed.

Lemma reff364_not2293 : ~ @Equation2293 Fin4 reff364_inst.
Proof. unfold Equation2293. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff364_inst, reff364_op in H. discriminate H. Qed.

Lemma reff364_not2294 : ~ @Equation2294 Fin4 reff364_inst.
Proof. unfold Equation2294. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff364_inst, reff364_op in H. discriminate H. Qed.

Lemma reff364_not2300 : ~ @Equation2300 Fin4 reff364_inst.
Proof. unfold Equation2300. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff364_inst, reff364_op in H. discriminate H. Qed.

Lemma reff364_not2301 : ~ @Equation2301 Fin4 reff364_inst.
Proof. unfold Equation2301. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff364_inst, reff364_op in H. discriminate H. Qed.

Lemma reff364_not2303 : ~ @Equation2303 Fin4 reff364_inst.
Proof. unfold Equation2303. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff364_inst, reff364_op in H. discriminate H. Qed.

Lemma reff364_not2304 : ~ @Equation2304 Fin4 reff364_inst.
Proof. unfold Equation2304. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff364_inst, reff364_op in H. discriminate H. Qed.

Lemma reff364_not2327 : ~ @Equation2327 Fin4 reff364_inst.
Proof. unfold Equation2327. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff364_inst, reff364_op in H. discriminate H. Qed.

Lemma reff364_not2328 : ~ @Equation2328 Fin4 reff364_inst.
Proof. unfold Equation2328. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff364_inst, reff364_op in H. discriminate H. Qed.

Lemma reff364_not2330 : ~ @Equation2330 Fin4 reff364_inst.
Proof. unfold Equation2330. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff364_inst, reff364_op in H. discriminate H. Qed.

Lemma reff364_not2331 : ~ @Equation2331 Fin4 reff364_inst.
Proof. unfold Equation2331. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff364_inst, reff364_op in H. discriminate H. Qed.

Lemma reff364_not2337 : ~ @Equation2337 Fin4 reff364_inst.
Proof. unfold Equation2337. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff364_inst, reff364_op in H. discriminate H. Qed.

Lemma reff364_not2338 : ~ @Equation2338 Fin4 reff364_inst.
Proof. unfold Equation2338. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff364_inst, reff364_op in H. discriminate H. Qed.

Lemma reff364_not2340 : ~ @Equation2340 Fin4 reff364_inst.
Proof. unfold Equation2340. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff364_inst, reff364_op in H. discriminate H. Qed.

Lemma reff364_not2442 : ~ @Equation2442 Fin4 reff364_inst.
Proof. unfold Equation2442. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff364_inst, reff364_op in H. discriminate H. Qed.

Lemma reff364_not2443 : ~ @Equation2443 Fin4 reff364_inst.
Proof. unfold Equation2443. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff364_inst, reff364_op in H. discriminate H. Qed.

Lemma reff364_not2444 : ~ @Equation2444 Fin4 reff364_inst.
Proof. unfold Equation2444. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff364_inst, reff364_op in H. discriminate H. Qed.

Lemma reff364_not2447 : ~ @Equation2447 Fin4 reff364_inst.
Proof. unfold Equation2447. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff364_inst, reff364_op in H. discriminate H. Qed.

Lemma reff364_not2449 : ~ @Equation2449 Fin4 reff364_inst.
Proof. unfold Equation2449. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff364_inst, reff364_op in H. discriminate H. Qed.

Lemma reff364_not2450 : ~ @Equation2450 Fin4 reff364_inst.
Proof. unfold Equation2450. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff364_inst, reff364_op in H. discriminate H. Qed.

Lemma reff364_not2457 : ~ @Equation2457 Fin4 reff364_inst.
Proof. unfold Equation2457. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff364_inst, reff364_op in H. discriminate H. Qed.

Lemma reff364_not2459 : ~ @Equation2459 Fin4 reff364_inst.
Proof. unfold Equation2459. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff364_inst, reff364_op in H. discriminate H. Qed.

Lemma reff364_not2460 : ~ @Equation2460 Fin4 reff364_inst.
Proof. unfold Equation2460. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff364_inst, reff364_op in H. discriminate H. Qed.

Lemma reff364_not2467 : ~ @Equation2467 Fin4 reff364_inst.
Proof. unfold Equation2467. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff364_inst, reff364_op in H. discriminate H. Qed.

Lemma reff364_not2469 : ~ @Equation2469 Fin4 reff364_inst.
Proof. unfold Equation2469. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff364_inst, reff364_op in H. discriminate H. Qed.

Lemma reff364_not2470 : ~ @Equation2470 Fin4 reff364_inst.
Proof. unfold Equation2470. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff364_inst, reff364_op in H. discriminate H. Qed.

Lemma reff364_not2493 : ~ @Equation2493 Fin4 reff364_inst.
Proof. unfold Equation2493. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff364_inst, reff364_op in H. discriminate H. Qed.

Lemma reff364_not2494 : ~ @Equation2494 Fin4 reff364_inst.
Proof. unfold Equation2494. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff364_inst, reff364_op in H. discriminate H. Qed.

Lemma reff364_not2496 : ~ @Equation2496 Fin4 reff364_inst.
Proof. unfold Equation2496. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff364_inst, reff364_op in H. discriminate H. Qed.

Lemma reff364_not2497 : ~ @Equation2497 Fin4 reff364_inst.
Proof. unfold Equation2497. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff364_inst, reff364_op in H. discriminate H. Qed.

Lemma reff364_not2503 : ~ @Equation2503 Fin4 reff364_inst.
Proof. unfold Equation2503. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff364_inst, reff364_op in H. discriminate H. Qed.

Lemma reff364_not2504 : ~ @Equation2504 Fin4 reff364_inst.
Proof. unfold Equation2504. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff364_inst, reff364_op in H. discriminate H. Qed.

Lemma reff364_not2506 : ~ @Equation2506 Fin4 reff364_inst.
Proof. unfold Equation2506. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff364_inst, reff364_op in H. discriminate H. Qed.

Lemma reff364_not2507 : ~ @Equation2507 Fin4 reff364_inst.
Proof. unfold Equation2507. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff364_inst, reff364_op in H. discriminate H. Qed.

Lemma reff364_not2530 : ~ @Equation2530 Fin4 reff364_inst.
Proof. unfold Equation2530. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff364_inst, reff364_op in H. discriminate H. Qed.

Lemma reff364_not2531 : ~ @Equation2531 Fin4 reff364_inst.
Proof. unfold Equation2531. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff364_inst, reff364_op in H. discriminate H. Qed.

Lemma reff364_not2533 : ~ @Equation2533 Fin4 reff364_inst.
Proof. unfold Equation2533. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff364_inst, reff364_op in H. discriminate H. Qed.

Lemma reff364_not2534 : ~ @Equation2534 Fin4 reff364_inst.
Proof. unfold Equation2534. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff364_inst, reff364_op in H. discriminate H. Qed.

Lemma reff364_not2540 : ~ @Equation2540 Fin4 reff364_inst.
Proof. unfold Equation2540. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff364_inst, reff364_op in H. discriminate H. Qed.

Lemma reff364_not2541 : ~ @Equation2541 Fin4 reff364_inst.
Proof. unfold Equation2541. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff364_inst, reff364_op in H. discriminate H. Qed.

Lemma reff364_not2543 : ~ @Equation2543 Fin4 reff364_inst.
Proof. unfold Equation2543. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff364_inst, reff364_op in H. discriminate H. Qed.

Lemma reff364_not2645 : ~ @Equation2645 Fin4 reff364_inst.
Proof. unfold Equation2645. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff364_inst, reff364_op in H. discriminate H. Qed.

Lemma reff364_not2646 : ~ @Equation2646 Fin4 reff364_inst.
Proof. unfold Equation2646. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff364_inst, reff364_op in H. discriminate H. Qed.

Lemma reff364_not2647 : ~ @Equation2647 Fin4 reff364_inst.
Proof. unfold Equation2647. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff364_inst, reff364_op in H. discriminate H. Qed.

Lemma reff364_not2650 : ~ @Equation2650 Fin4 reff364_inst.
Proof. unfold Equation2650. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff364_inst, reff364_op in H. discriminate H. Qed.

Lemma reff364_not2652 : ~ @Equation2652 Fin4 reff364_inst.
Proof. unfold Equation2652. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff364_inst, reff364_op in H. discriminate H. Qed.

Lemma reff364_not2653 : ~ @Equation2653 Fin4 reff364_inst.
Proof. unfold Equation2653. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff364_inst, reff364_op in H. discriminate H. Qed.

Lemma reff364_not2659 : ~ @Equation2659 Fin4 reff364_inst.
Proof. unfold Equation2659. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff364_inst, reff364_op in H. discriminate H. Qed.

Lemma reff364_not2660 : ~ @Equation2660 Fin4 reff364_inst.
Proof. unfold Equation2660. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff364_inst, reff364_op in H. discriminate H. Qed.

Lemma reff364_not2662 : ~ @Equation2662 Fin4 reff364_inst.
Proof. unfold Equation2662. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff364_inst, reff364_op in H. discriminate H. Qed.

Lemma reff364_not2663 : ~ @Equation2663 Fin4 reff364_inst.
Proof. unfold Equation2663. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff364_inst, reff364_op in H. discriminate H. Qed.

Lemma reff364_not2669 : ~ @Equation2669 Fin4 reff364_inst.
Proof. unfold Equation2669. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff364_inst, reff364_op in H. discriminate H. Qed.

Lemma reff364_not2670 : ~ @Equation2670 Fin4 reff364_inst.
Proof. unfold Equation2670. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff364_inst, reff364_op in H. discriminate H. Qed.

Lemma reff364_not2672 : ~ @Equation2672 Fin4 reff364_inst.
Proof. unfold Equation2672. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff364_inst, reff364_op in H. discriminate H. Qed.

Lemma reff364_not2673 : ~ @Equation2673 Fin4 reff364_inst.
Proof. unfold Equation2673. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff364_inst, reff364_op in H. discriminate H. Qed.

Lemma reff364_not2696 : ~ @Equation2696 Fin4 reff364_inst.
Proof. unfold Equation2696. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff364_inst, reff364_op in H. discriminate H. Qed.

Lemma reff364_not2697 : ~ @Equation2697 Fin4 reff364_inst.
Proof. unfold Equation2697. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff364_inst, reff364_op in H. discriminate H. Qed.

Lemma reff364_not2699 : ~ @Equation2699 Fin4 reff364_inst.
Proof. unfold Equation2699. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff364_inst, reff364_op in H. discriminate H. Qed.

Lemma reff364_not2700 : ~ @Equation2700 Fin4 reff364_inst.
Proof. unfold Equation2700. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff364_inst, reff364_op in H. discriminate H. Qed.

Lemma reff364_not2706 : ~ @Equation2706 Fin4 reff364_inst.
Proof. unfold Equation2706. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff364_inst, reff364_op in H. discriminate H. Qed.

Lemma reff364_not2707 : ~ @Equation2707 Fin4 reff364_inst.
Proof. unfold Equation2707. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff364_inst, reff364_op in H. discriminate H. Qed.

Lemma reff364_not2709 : ~ @Equation2709 Fin4 reff364_inst.
Proof. unfold Equation2709. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff364_inst, reff364_op in H. discriminate H. Qed.

Lemma reff364_not2710 : ~ @Equation2710 Fin4 reff364_inst.
Proof. unfold Equation2710. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff364_inst, reff364_op in H. discriminate H. Qed.

Lemma reff364_not2733 : ~ @Equation2733 Fin4 reff364_inst.
Proof. unfold Equation2733. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff364_inst, reff364_op in H. discriminate H. Qed.

Lemma reff364_not2734 : ~ @Equation2734 Fin4 reff364_inst.
Proof. unfold Equation2734. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff364_inst, reff364_op in H. discriminate H. Qed.

Lemma reff364_not2736 : ~ @Equation2736 Fin4 reff364_inst.
Proof. unfold Equation2736. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff364_inst, reff364_op in H. discriminate H. Qed.

Lemma reff364_not2737 : ~ @Equation2737 Fin4 reff364_inst.
Proof. unfold Equation2737. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff364_inst, reff364_op in H. discriminate H. Qed.

Lemma reff364_not2743 : ~ @Equation2743 Fin4 reff364_inst.
Proof. unfold Equation2743. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff364_inst, reff364_op in H. discriminate H. Qed.

Lemma reff364_not2744 : ~ @Equation2744 Fin4 reff364_inst.
Proof. unfold Equation2744. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff364_inst, reff364_op in H. discriminate H. Qed.

Lemma reff364_not2746 : ~ @Equation2746 Fin4 reff364_inst.
Proof. unfold Equation2746. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff364_inst, reff364_op in H. discriminate H. Qed.

Lemma reff364_not2848 : ~ @Equation2848 Fin4 reff364_inst.
Proof. unfold Equation2848. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff364_inst, reff364_op in H. discriminate H. Qed.

Lemma reff364_not2849 : ~ @Equation2849 Fin4 reff364_inst.
Proof. unfold Equation2849. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff364_inst, reff364_op in H. discriminate H. Qed.

Lemma reff364_not2850 : ~ @Equation2850 Fin4 reff364_inst.
Proof. unfold Equation2850. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff364_inst, reff364_op in H. discriminate H. Qed.

Lemma reff364_not2852 : ~ @Equation2852 Fin4 reff364_inst.
Proof. unfold Equation2852. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff364_inst, reff364_op in H. discriminate H. Qed.

Lemma reff364_not2853 : ~ @Equation2853 Fin4 reff364_inst.
Proof. unfold Equation2853. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff364_inst, reff364_op in H. discriminate H. Qed.

Lemma reff364_not2855 : ~ @Equation2855 Fin4 reff364_inst.
Proof. unfold Equation2855. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff364_inst, reff364_op in H. discriminate H. Qed.

Lemma reff364_not2856 : ~ @Equation2856 Fin4 reff364_inst.
Proof. unfold Equation2856. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff364_inst, reff364_op in H. discriminate H. Qed.

Lemma reff364_not2863 : ~ @Equation2863 Fin4 reff364_inst.
Proof. unfold Equation2863. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff364_inst, reff364_op in H. discriminate H. Qed.

Lemma reff364_not2865 : ~ @Equation2865 Fin4 reff364_inst.
Proof. unfold Equation2865. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff364_inst, reff364_op in H. discriminate H. Qed.

Lemma reff364_not2866 : ~ @Equation2866 Fin4 reff364_inst.
Proof. unfold Equation2866. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff364_inst, reff364_op in H. discriminate H. Qed.

Lemma reff364_not2872 : ~ @Equation2872 Fin4 reff364_inst.
Proof. unfold Equation2872. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff364_inst, reff364_op in H. discriminate H. Qed.

Lemma reff364_not2873 : ~ @Equation2873 Fin4 reff364_inst.
Proof. unfold Equation2873. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff364_inst, reff364_op in H. discriminate H. Qed.

Lemma reff364_not2875 : ~ @Equation2875 Fin4 reff364_inst.
Proof. unfold Equation2875. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff364_inst, reff364_op in H. discriminate H. Qed.

Lemma reff364_not2876 : ~ @Equation2876 Fin4 reff364_inst.
Proof. unfold Equation2876. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff364_inst, reff364_op in H. discriminate H. Qed.

Lemma reff364_not2899 : ~ @Equation2899 Fin4 reff364_inst.
Proof. unfold Equation2899. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff364_inst, reff364_op in H. discriminate H. Qed.

Lemma reff364_not2900 : ~ @Equation2900 Fin4 reff364_inst.
Proof. unfold Equation2900. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff364_inst, reff364_op in H. discriminate H. Qed.

Lemma reff364_not2902 : ~ @Equation2902 Fin4 reff364_inst.
Proof. unfold Equation2902. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff364_inst, reff364_op in H. discriminate H. Qed.

Lemma reff364_not2903 : ~ @Equation2903 Fin4 reff364_inst.
Proof. unfold Equation2903. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff364_inst, reff364_op in H. discriminate H. Qed.

Lemma reff364_not2909 : ~ @Equation2909 Fin4 reff364_inst.
Proof. unfold Equation2909. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff364_inst, reff364_op in H. discriminate H. Qed.

Lemma reff364_not2910 : ~ @Equation2910 Fin4 reff364_inst.
Proof. unfold Equation2910. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff364_inst, reff364_op in H. discriminate H. Qed.

Lemma reff364_not2912 : ~ @Equation2912 Fin4 reff364_inst.
Proof. unfold Equation2912. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff364_inst, reff364_op in H. discriminate H. Qed.

Lemma reff364_not2913 : ~ @Equation2913 Fin4 reff364_inst.
Proof. unfold Equation2913. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff364_inst, reff364_op in H. discriminate H. Qed.

Lemma reff364_not2936 : ~ @Equation2936 Fin4 reff364_inst.
Proof. unfold Equation2936. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff364_inst, reff364_op in H. discriminate H. Qed.

Lemma reff364_not2937 : ~ @Equation2937 Fin4 reff364_inst.
Proof. unfold Equation2937. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff364_inst, reff364_op in H. discriminate H. Qed.

Lemma reff364_not2939 : ~ @Equation2939 Fin4 reff364_inst.
Proof. unfold Equation2939. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff364_inst, reff364_op in H. discriminate H. Qed.

Lemma reff364_not2940 : ~ @Equation2940 Fin4 reff364_inst.
Proof. unfold Equation2940. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff364_inst, reff364_op in H. discriminate H. Qed.

Lemma reff364_not2946 : ~ @Equation2946 Fin4 reff364_inst.
Proof. unfold Equation2946. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff364_inst, reff364_op in H. discriminate H. Qed.

Lemma reff364_not2947 : ~ @Equation2947 Fin4 reff364_inst.
Proof. unfold Equation2947. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff364_inst, reff364_op in H. discriminate H. Qed.

Lemma reff364_not2949 : ~ @Equation2949 Fin4 reff364_inst.
Proof. unfold Equation2949. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff364_inst, reff364_op in H. discriminate H. Qed.

Lemma reff364_not3051 : ~ @Equation3051 Fin4 reff364_inst.
Proof. unfold Equation3051. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff364_inst, reff364_op in H. discriminate H. Qed.

Lemma reff364_not3052 : ~ @Equation3052 Fin4 reff364_inst.
Proof. unfold Equation3052. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff364_inst, reff364_op in H. discriminate H. Qed.

Lemma reff364_not3053 : ~ @Equation3053 Fin4 reff364_inst.
Proof. unfold Equation3053. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff364_inst, reff364_op in H. discriminate H. Qed.

Lemma reff364_not3055 : ~ @Equation3055 Fin4 reff364_inst.
Proof. unfold Equation3055. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff364_inst, reff364_op in H. discriminate H. Qed.

Lemma reff364_not3056 : ~ @Equation3056 Fin4 reff364_inst.
Proof. unfold Equation3056. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff364_inst, reff364_op in H. discriminate H. Qed.

Lemma reff364_not3058 : ~ @Equation3058 Fin4 reff364_inst.
Proof. unfold Equation3058. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff364_inst, reff364_op in H. discriminate H. Qed.

Lemma reff364_not3059 : ~ @Equation3059 Fin4 reff364_inst.
Proof. unfold Equation3059. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff364_inst, reff364_op in H. discriminate H. Qed.

Lemma reff364_not3065 : ~ @Equation3065 Fin4 reff364_inst.
Proof. unfold Equation3065. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff364_inst, reff364_op in H. discriminate H. Qed.

Lemma reff364_not3066 : ~ @Equation3066 Fin4 reff364_inst.
Proof. unfold Equation3066. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff364_inst, reff364_op in H. discriminate H. Qed.

Lemma reff364_not3069 : ~ @Equation3069 Fin4 reff364_inst.
Proof. unfold Equation3069. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff364_inst, reff364_op in H. discriminate H. Qed.

Lemma reff364_not3075 : ~ @Equation3075 Fin4 reff364_inst.
Proof. unfold Equation3075. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff364_inst, reff364_op in H. discriminate H. Qed.

Lemma reff364_not3076 : ~ @Equation3076 Fin4 reff364_inst.
Proof. unfold Equation3076. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff364_inst, reff364_op in H. discriminate H. Qed.

Lemma reff364_not3078 : ~ @Equation3078 Fin4 reff364_inst.
Proof. unfold Equation3078. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff364_inst, reff364_op in H. discriminate H. Qed.

Lemma reff364_not3079 : ~ @Equation3079 Fin4 reff364_inst.
Proof. unfold Equation3079. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff364_inst, reff364_op in H. discriminate H. Qed.

Lemma reff364_not3102 : ~ @Equation3102 Fin4 reff364_inst.
Proof. unfold Equation3102. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff364_inst, reff364_op in H. discriminate H. Qed.

Lemma reff364_not3103 : ~ @Equation3103 Fin4 reff364_inst.
Proof. unfold Equation3103. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff364_inst, reff364_op in H. discriminate H. Qed.

Lemma reff364_not3105 : ~ @Equation3105 Fin4 reff364_inst.
Proof. unfold Equation3105. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff364_inst, reff364_op in H. discriminate H. Qed.

Lemma reff364_not3106 : ~ @Equation3106 Fin4 reff364_inst.
Proof. unfold Equation3106. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff364_inst, reff364_op in H. discriminate H. Qed.

Lemma reff364_not3112 : ~ @Equation3112 Fin4 reff364_inst.
Proof. unfold Equation3112. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff364_inst, reff364_op in H. discriminate H. Qed.

Lemma reff364_not3113 : ~ @Equation3113 Fin4 reff364_inst.
Proof. unfold Equation3113. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff364_inst, reff364_op in H. discriminate H. Qed.

Lemma reff364_not3115 : ~ @Equation3115 Fin4 reff364_inst.
Proof. unfold Equation3115. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff364_inst, reff364_op in H. discriminate H. Qed.

Lemma reff364_not3116 : ~ @Equation3116 Fin4 reff364_inst.
Proof. unfold Equation3116. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff364_inst, reff364_op in H. discriminate H. Qed.

Lemma reff364_not3139 : ~ @Equation3139 Fin4 reff364_inst.
Proof. unfold Equation3139. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff364_inst, reff364_op in H. discriminate H. Qed.

Lemma reff364_not3140 : ~ @Equation3140 Fin4 reff364_inst.
Proof. unfold Equation3140. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff364_inst, reff364_op in H. discriminate H. Qed.

Lemma reff364_not3142 : ~ @Equation3142 Fin4 reff364_inst.
Proof. unfold Equation3142. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff364_inst, reff364_op in H. discriminate H. Qed.

Lemma reff364_not3143 : ~ @Equation3143 Fin4 reff364_inst.
Proof. unfold Equation3143. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff364_inst, reff364_op in H. discriminate H. Qed.

Lemma reff364_not3149 : ~ @Equation3149 Fin4 reff364_inst.
Proof. unfold Equation3149. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff364_inst, reff364_op in H. discriminate H. Qed.

Lemma reff364_not3150 : ~ @Equation3150 Fin4 reff364_inst.
Proof. unfold Equation3150. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff364_inst, reff364_op in H. discriminate H. Qed.

Lemma reff364_not3152 : ~ @Equation3152 Fin4 reff364_inst.
Proof. unfold Equation3152. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff364_inst, reff364_op in H. discriminate H. Qed.

Lemma reff364_not3254 : ~ @Equation3254 Fin4 reff364_inst.
Proof. unfold Equation3254. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff364_inst, reff364_op in H. discriminate H. Qed.

Lemma reff364_not3256 : ~ @Equation3256 Fin4 reff364_inst.
Proof. unfold Equation3256. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff364_inst, reff364_op in H. discriminate H. Qed.

Lemma reff364_not3259 : ~ @Equation3259 Fin4 reff364_inst.
Proof. unfold Equation3259. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff364_inst, reff364_op in H. discriminate H. Qed.

Lemma reff364_not3262 : ~ @Equation3262 Fin4 reff364_inst.
Proof. unfold Equation3262. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff364_inst, reff364_op in H. discriminate H. Qed.

Lemma reff364_not3268 : ~ @Equation3268 Fin4 reff364_inst.
Proof. unfold Equation3268. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff364_inst, reff364_op in H. discriminate H. Qed.

Lemma reff364_not3269 : ~ @Equation3269 Fin4 reff364_inst.
Proof. unfold Equation3269. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff364_inst, reff364_op in H. discriminate H. Qed.

Lemma reff364_not3271 : ~ @Equation3271 Fin4 reff364_inst.
Proof. unfold Equation3271. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff364_inst, reff364_op in H. discriminate H. Qed.

Lemma reff364_not3272 : ~ @Equation3272 Fin4 reff364_inst.
Proof. unfold Equation3272. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff364_inst, reff364_op in H. discriminate H. Qed.

Lemma reff364_not3278 : ~ @Equation3278 Fin4 reff364_inst.
Proof. unfold Equation3278. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff364_inst, reff364_op in H. discriminate H. Qed.

Lemma reff364_not3279 : ~ @Equation3279 Fin4 reff364_inst.
Proof. unfold Equation3279. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff364_inst, reff364_op in H. discriminate H. Qed.

Lemma reff364_not3281 : ~ @Equation3281 Fin4 reff364_inst.
Proof. unfold Equation3281. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff364_inst, reff364_op in H. discriminate H. Qed.

Lemma reff364_not3308 : ~ @Equation3308 Fin4 reff364_inst.
Proof. unfold Equation3308. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff364_inst, reff364_op in H. discriminate H. Qed.

Lemma reff364_not3315 : ~ @Equation3315 Fin4 reff364_inst.
Proof. unfold Equation3315. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff364_inst, reff364_op in H. discriminate H. Qed.

Lemma reff364_not3318 : ~ @Equation3318 Fin4 reff364_inst.
Proof. unfold Equation3318. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff364_inst, reff364_op in H. discriminate H. Qed.

Lemma reff364_not3342 : ~ @Equation3342 Fin4 reff364_inst.
Proof. unfold Equation3342. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff364_inst, reff364_op in H. discriminate H. Qed.

Lemma reff364_not3343 : ~ @Equation3343 Fin4 reff364_inst.
Proof. unfold Equation3343. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff364_inst, reff364_op in H. discriminate H. Qed.

Lemma reff364_not3345 : ~ @Equation3345 Fin4 reff364_inst.
Proof. unfold Equation3345. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff364_inst, reff364_op in H. discriminate H. Qed.

Lemma reff364_not3346 : ~ @Equation3346 Fin4 reff364_inst.
Proof. unfold Equation3346. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff364_inst, reff364_op in H. discriminate H. Qed.

Lemma reff364_not3352 : ~ @Equation3352 Fin4 reff364_inst.
Proof. unfold Equation3352. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff364_inst, reff364_op in H. discriminate H. Qed.

Lemma reff364_not3353 : ~ @Equation3353 Fin4 reff364_inst.
Proof. unfold Equation3353. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff364_inst, reff364_op in H. discriminate H. Qed.

Lemma reff364_not3457 : ~ @Equation3457 Fin4 reff364_inst.
Proof. unfold Equation3457. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff364_inst, reff364_op in H. discriminate H. Qed.

Lemma reff364_not3459 : ~ @Equation3459 Fin4 reff364_inst.
Proof. unfold Equation3459. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff364_inst, reff364_op in H. discriminate H. Qed.

Lemma reff364_not3462 : ~ @Equation3462 Fin4 reff364_inst.
Proof. unfold Equation3462. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff364_inst, reff364_op in H. discriminate H. Qed.

Lemma reff364_not3465 : ~ @Equation3465 Fin4 reff364_inst.
Proof. unfold Equation3465. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff364_inst, reff364_op in H. discriminate H. Qed.

Lemma reff364_not3472 : ~ @Equation3472 Fin4 reff364_inst.
Proof. unfold Equation3472. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff364_inst, reff364_op in H. discriminate H. Qed.

Lemma reff364_not3474 : ~ @Equation3474 Fin4 reff364_inst.
Proof. unfold Equation3474. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff364_inst, reff364_op in H. discriminate H. Qed.

Lemma reff364_not3475 : ~ @Equation3475 Fin4 reff364_inst.
Proof. unfold Equation3475. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff364_inst, reff364_op in H. discriminate H. Qed.

Lemma reff364_not3481 : ~ @Equation3481 Fin4 reff364_inst.
Proof. unfold Equation3481. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff364_inst, reff364_op in H. discriminate H. Qed.

Lemma reff364_not3482 : ~ @Equation3482 Fin4 reff364_inst.
Proof. unfold Equation3482. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff364_inst, reff364_op in H. discriminate H. Qed.

Lemma reff364_not3484 : ~ @Equation3484 Fin4 reff364_inst.
Proof. unfold Equation3484. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff364_inst, reff364_op in H. discriminate H. Qed.

Lemma reff364_not3511 : ~ @Equation3511 Fin4 reff364_inst.
Proof. unfold Equation3511. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff364_inst, reff364_op in H. discriminate H. Qed.

Lemma reff364_not3518 : ~ @Equation3518 Fin4 reff364_inst.
Proof. unfold Equation3518. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff364_inst, reff364_op in H. discriminate H. Qed.

Lemma reff364_not3521 : ~ @Equation3521 Fin4 reff364_inst.
Proof. unfold Equation3521. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff364_inst, reff364_op in H. discriminate H. Qed.

Lemma reff364_not3545 : ~ @Equation3545 Fin4 reff364_inst.
Proof. unfold Equation3545. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff364_inst, reff364_op in H. discriminate H. Qed.

Lemma reff364_not3546 : ~ @Equation3546 Fin4 reff364_inst.
Proof. unfold Equation3546. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff364_inst, reff364_op in H. discriminate H. Qed.

Lemma reff364_not3548 : ~ @Equation3548 Fin4 reff364_inst.
Proof. unfold Equation3548. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff364_inst, reff364_op in H. discriminate H. Qed.

Lemma reff364_not3549 : ~ @Equation3549 Fin4 reff364_inst.
Proof. unfold Equation3549. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff364_inst, reff364_op in H. discriminate H. Qed.

Lemma reff364_not3555 : ~ @Equation3555 Fin4 reff364_inst.
Proof. unfold Equation3555. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff364_inst, reff364_op in H. discriminate H. Qed.

Lemma reff364_not3556 : ~ @Equation3556 Fin4 reff364_inst.
Proof. unfold Equation3556. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff364_inst, reff364_op in H. discriminate H. Qed.

Lemma reff364_not3558 : ~ @Equation3558 Fin4 reff364_inst.
Proof. unfold Equation3558. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff364_inst, reff364_op in H. discriminate H. Qed.

Lemma reff364_not3660 : ~ @Equation3660 Fin4 reff364_inst.
Proof. unfold Equation3660. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff364_inst, reff364_op in H. discriminate H. Qed.

Lemma reff364_not3662 : ~ @Equation3662 Fin4 reff364_inst.
Proof. unfold Equation3662. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff364_inst, reff364_op in H. discriminate H. Qed.

Lemma reff364_not3664 : ~ @Equation3664 Fin4 reff364_inst.
Proof. unfold Equation3664. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff364_inst, reff364_op in H. discriminate H. Qed.

Lemma reff364_not3665 : ~ @Equation3665 Fin4 reff364_inst.
Proof. unfold Equation3665. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff364_inst, reff364_op in H. discriminate H. Qed.

Lemma reff364_not3667 : ~ @Equation3667 Fin4 reff364_inst.
Proof. unfold Equation3667. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff364_inst, reff364_op in H. discriminate H. Qed.

Lemma reff364_not3668 : ~ @Equation3668 Fin4 reff364_inst.
Proof. unfold Equation3668. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff364_inst, reff364_op in H. discriminate H. Qed.

Lemma reff364_not3674 : ~ @Equation3674 Fin4 reff364_inst.
Proof. unfold Equation3674. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff364_inst, reff364_op in H. discriminate H. Qed.

Lemma reff364_not3675 : ~ @Equation3675 Fin4 reff364_inst.
Proof. unfold Equation3675. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff364_inst, reff364_op in H. discriminate H. Qed.

Lemma reff364_not3677 : ~ @Equation3677 Fin4 reff364_inst.
Proof. unfold Equation3677. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff364_inst, reff364_op in H. discriminate H. Qed.

Lemma reff364_not3678 : ~ @Equation3678 Fin4 reff364_inst.
Proof. unfold Equation3678. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff364_inst, reff364_op in H. discriminate H. Qed.

Lemma reff364_not3684 : ~ @Equation3684 Fin4 reff364_inst.
Proof. unfold Equation3684. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff364_inst, reff364_op in H. discriminate H. Qed.

Lemma reff364_not3685 : ~ @Equation3685 Fin4 reff364_inst.
Proof. unfold Equation3685. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff364_inst, reff364_op in H. discriminate H. Qed.

Lemma reff364_not3687 : ~ @Equation3687 Fin4 reff364_inst.
Proof. unfold Equation3687. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff364_inst, reff364_op in H. discriminate H. Qed.

Lemma reff364_not3714 : ~ @Equation3714 Fin4 reff364_inst.
Proof. unfold Equation3714. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff364_inst, reff364_op in H. discriminate H. Qed.

Lemma reff364_not3721 : ~ @Equation3721 Fin4 reff364_inst.
Proof. unfold Equation3721. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff364_inst, reff364_op in H. discriminate H. Qed.

Lemma reff364_not3724 : ~ @Equation3724 Fin4 reff364_inst.
Proof. unfold Equation3724. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff364_inst, reff364_op in H. discriminate H. Qed.

Lemma reff364_not3748 : ~ @Equation3748 Fin4 reff364_inst.
Proof. unfold Equation3748. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff364_inst, reff364_op in H. discriminate H. Qed.

Lemma reff364_not3749 : ~ @Equation3749 Fin4 reff364_inst.
Proof. unfold Equation3749. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff364_inst, reff364_op in H. discriminate H. Qed.

Lemma reff364_not3751 : ~ @Equation3751 Fin4 reff364_inst.
Proof. unfold Equation3751. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff364_inst, reff364_op in H. discriminate H. Qed.

Lemma reff364_not3752 : ~ @Equation3752 Fin4 reff364_inst.
Proof. unfold Equation3752. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff364_inst, reff364_op in H. discriminate H. Qed.

Lemma reff364_not3758 : ~ @Equation3758 Fin4 reff364_inst.
Proof. unfold Equation3758. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff364_inst, reff364_op in H. discriminate H. Qed.

Lemma reff364_not3759 : ~ @Equation3759 Fin4 reff364_inst.
Proof. unfold Equation3759. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff364_inst, reff364_op in H. discriminate H. Qed.

Lemma reff364_not3761 : ~ @Equation3761 Fin4 reff364_inst.
Proof. unfold Equation3761. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff364_inst, reff364_op in H. discriminate H. Qed.

Lemma reff364_not3864 : ~ @Equation3864 Fin4 reff364_inst.
Proof. unfold Equation3864. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff364_inst, reff364_op in H. discriminate H. Qed.

Lemma reff364_not3865 : ~ @Equation3865 Fin4 reff364_inst.
Proof. unfold Equation3865. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff364_inst, reff364_op in H. discriminate H. Qed.

Lemma reff364_not3868 : ~ @Equation3868 Fin4 reff364_inst.
Proof. unfold Equation3868. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff364_inst, reff364_op in H. discriminate H. Qed.

Lemma reff364_not3870 : ~ @Equation3870 Fin4 reff364_inst.
Proof. unfold Equation3870. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff364_inst, reff364_op in H. discriminate H. Qed.

Lemma reff364_not3871 : ~ @Equation3871 Fin4 reff364_inst.
Proof. unfold Equation3871. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff364_inst, reff364_op in H. discriminate H. Qed.

Lemma reff364_not3877 : ~ @Equation3877 Fin4 reff364_inst.
Proof. unfold Equation3877. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff364_inst, reff364_op in H. discriminate H. Qed.

Lemma reff364_not3878 : ~ @Equation3878 Fin4 reff364_inst.
Proof. unfold Equation3878. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff364_inst, reff364_op in H. discriminate H. Qed.

Lemma reff364_not3880 : ~ @Equation3880 Fin4 reff364_inst.
Proof. unfold Equation3880. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff364_inst, reff364_op in H. discriminate H. Qed.

Lemma reff364_not3881 : ~ @Equation3881 Fin4 reff364_inst.
Proof. unfold Equation3881. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff364_inst, reff364_op in H. discriminate H. Qed.

Lemma reff364_not3887 : ~ @Equation3887 Fin4 reff364_inst.
Proof. unfold Equation3887. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff364_inst, reff364_op in H. discriminate H. Qed.

Lemma reff364_not3888 : ~ @Equation3888 Fin4 reff364_inst.
Proof. unfold Equation3888. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff364_inst, reff364_op in H. discriminate H. Qed.

Lemma reff364_not3890 : ~ @Equation3890 Fin4 reff364_inst.
Proof. unfold Equation3890. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff364_inst, reff364_op in H. discriminate H. Qed.

Lemma reff364_not3917 : ~ @Equation3917 Fin4 reff364_inst.
Proof. unfold Equation3917. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff364_inst, reff364_op in H. discriminate H. Qed.

Lemma reff364_not3924 : ~ @Equation3924 Fin4 reff364_inst.
Proof. unfold Equation3924. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff364_inst, reff364_op in H. discriminate H. Qed.

Lemma reff364_not3927 : ~ @Equation3927 Fin4 reff364_inst.
Proof. unfold Equation3927. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff364_inst, reff364_op in H. discriminate H. Qed.

Lemma reff364_not3951 : ~ @Equation3951 Fin4 reff364_inst.
Proof. unfold Equation3951. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff364_inst, reff364_op in H. discriminate H. Qed.

Lemma reff364_not3952 : ~ @Equation3952 Fin4 reff364_inst.
Proof. unfold Equation3952. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff364_inst, reff364_op in H. discriminate H. Qed.

Lemma reff364_not3954 : ~ @Equation3954 Fin4 reff364_inst.
Proof. unfold Equation3954. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff364_inst, reff364_op in H. discriminate H. Qed.

Lemma reff364_not3955 : ~ @Equation3955 Fin4 reff364_inst.
Proof. unfold Equation3955. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff364_inst, reff364_op in H. discriminate H. Qed.

Lemma reff364_not3961 : ~ @Equation3961 Fin4 reff364_inst.
Proof. unfold Equation3961. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff364_inst, reff364_op in H. discriminate H. Qed.

Lemma reff364_not3962 : ~ @Equation3962 Fin4 reff364_inst.
Proof. unfold Equation3962. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff364_inst, reff364_op in H. discriminate H. Qed.

Lemma reff364_not3964 : ~ @Equation3964 Fin4 reff364_inst.
Proof. unfold Equation3964. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff364_inst, reff364_op in H. discriminate H. Qed.

Lemma reff364_not4066 : ~ @Equation4066 Fin4 reff364_inst.
Proof. unfold Equation4066. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff364_inst, reff364_op in H. discriminate H. Qed.

Lemma reff364_not4067 : ~ @Equation4067 Fin4 reff364_inst.
Proof. unfold Equation4067. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff364_inst, reff364_op in H. discriminate H. Qed.

Lemma reff364_not4068 : ~ @Equation4068 Fin4 reff364_inst.
Proof. unfold Equation4068. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff364_inst, reff364_op in H. discriminate H. Qed.

Lemma reff364_not4070 : ~ @Equation4070 Fin4 reff364_inst.
Proof. unfold Equation4070. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff364_inst, reff364_op in H. discriminate H. Qed.

Lemma reff364_not4071 : ~ @Equation4071 Fin4 reff364_inst.
Proof. unfold Equation4071. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff364_inst, reff364_op in H. discriminate H. Qed.

Lemma reff364_not4073 : ~ @Equation4073 Fin4 reff364_inst.
Proof. unfold Equation4073. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff364_inst, reff364_op in H. discriminate H. Qed.

Lemma reff364_not4074 : ~ @Equation4074 Fin4 reff364_inst.
Proof. unfold Equation4074. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff364_inst, reff364_op in H. discriminate H. Qed.

Lemma reff364_not4080 : ~ @Equation4080 Fin4 reff364_inst.
Proof. unfold Equation4080. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff364_inst, reff364_op in H. discriminate H. Qed.

Lemma reff364_not4081 : ~ @Equation4081 Fin4 reff364_inst.
Proof. unfold Equation4081. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff364_inst, reff364_op in H. discriminate H. Qed.

Lemma reff364_not4083 : ~ @Equation4083 Fin4 reff364_inst.
Proof. unfold Equation4083. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff364_inst, reff364_op in H. discriminate H. Qed.

Lemma reff364_not4084 : ~ @Equation4084 Fin4 reff364_inst.
Proof. unfold Equation4084. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff364_inst, reff364_op in H. discriminate H. Qed.

Lemma reff364_not4090 : ~ @Equation4090 Fin4 reff364_inst.
Proof. unfold Equation4090. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff364_inst, reff364_op in H. discriminate H. Qed.

Lemma reff364_not4091 : ~ @Equation4091 Fin4 reff364_inst.
Proof. unfold Equation4091. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff364_inst, reff364_op in H. discriminate H. Qed.

Lemma reff364_not4093 : ~ @Equation4093 Fin4 reff364_inst.
Proof. unfold Equation4093. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff364_inst, reff364_op in H. discriminate H. Qed.

Lemma reff364_not4120 : ~ @Equation4120 Fin4 reff364_inst.
Proof. unfold Equation4120. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff364_inst, reff364_op in H. discriminate H. Qed.

Lemma reff364_not4127 : ~ @Equation4127 Fin4 reff364_inst.
Proof. unfold Equation4127. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff364_inst, reff364_op in H. discriminate H. Qed.

Lemma reff364_not4128 : ~ @Equation4128 Fin4 reff364_inst.
Proof. unfold Equation4128. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff364_inst, reff364_op in H. discriminate H. Qed.

Lemma reff364_not4130 : ~ @Equation4130 Fin4 reff364_inst.
Proof. unfold Equation4130. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff364_inst, reff364_op in H. discriminate H. Qed.

Lemma reff364_not4155 : ~ @Equation4155 Fin4 reff364_inst.
Proof. unfold Equation4155. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff364_inst, reff364_op in H. discriminate H. Qed.

Lemma reff364_not4157 : ~ @Equation4157 Fin4 reff364_inst.
Proof. unfold Equation4157. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff364_inst, reff364_op in H. discriminate H. Qed.

Lemma reff364_not4158 : ~ @Equation4158 Fin4 reff364_inst.
Proof. unfold Equation4158. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff364_inst, reff364_op in H. discriminate H. Qed.

Lemma reff364_not4164 : ~ @Equation4164 Fin4 reff364_inst.
Proof. unfold Equation4164. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff364_inst, reff364_op in H. discriminate H. Qed.

Lemma reff364_not4165 : ~ @Equation4165 Fin4 reff364_inst.
Proof. unfold Equation4165. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff364_inst, reff364_op in H. discriminate H. Qed.

Lemma reff364_not4167 : ~ @Equation4167 Fin4 reff364_inst.
Proof. unfold Equation4167. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff364_inst, reff364_op in H. discriminate H. Qed.

Lemma reff364_not4268 : ~ @Equation4268 Fin4 reff364_inst.
Proof. unfold Equation4268. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff364_inst, reff364_op in H. discriminate H. Qed.

Lemma reff364_not4270 : ~ @Equation4270 Fin4 reff364_inst.
Proof. unfold Equation4270. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff364_inst, reff364_op in H. discriminate H. Qed.

Lemma reff364_not4272 : ~ @Equation4272 Fin4 reff364_inst.
Proof. unfold Equation4272. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff364_inst, reff364_op in H. discriminate H. Qed.

Lemma reff364_not4273 : ~ @Equation4273 Fin4 reff364_inst.
Proof. unfold Equation4273. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff364_inst, reff364_op in H. discriminate H. Qed.

Lemma reff364_not4275 : ~ @Equation4275 Fin4 reff364_inst.
Proof. unfold Equation4275. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff364_inst, reff364_op in H. discriminate H. Qed.

Lemma reff364_not4276 : ~ @Equation4276 Fin4 reff364_inst.
Proof. unfold Equation4276. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff364_inst, reff364_op in H. discriminate H. Qed.

Lemma reff364_not4283 : ~ @Equation4283 Fin4 reff364_inst.
Proof. unfold Equation4283. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff364_inst, reff364_op in H. discriminate H. Qed.

Lemma reff364_not4290 : ~ @Equation4290 Fin4 reff364_inst.
Proof. unfold Equation4290. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff364_inst, reff364_op in H. discriminate H. Qed.

Lemma reff364_not4291 : ~ @Equation4291 Fin4 reff364_inst.
Proof. unfold Equation4291. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff364_inst, reff364_op in H. discriminate H. Qed.

Lemma reff364_not4293 : ~ @Equation4293 Fin4 reff364_inst.
Proof. unfold Equation4293. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff364_inst, reff364_op in H. discriminate H. Qed.

Lemma reff364_not4314 : ~ @Equation4314 Fin4 reff364_inst.
Proof. unfold Equation4314. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff364_inst, reff364_op in H. discriminate H. Qed.

Lemma reff364_not4320 : ~ @Equation4320 Fin4 reff364_inst.
Proof. unfold Equation4320. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff364_inst, reff364_op in H. discriminate H. Qed.

Lemma reff364_not4321 : ~ @Equation4321 Fin4 reff364_inst.
Proof. unfold Equation4321. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff364_inst, reff364_op in H. discriminate H. Qed.

Lemma reff364_not4343 : ~ @Equation4343 Fin4 reff364_inst.
Proof. unfold Equation4343. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff364_inst, reff364_op in H. discriminate H. Qed.

Lemma reff364_not4398 : ~ @Equation4398 Fin4 reff364_inst.
Proof. unfold Equation4398. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff364_inst, reff364_op in H. discriminate H. Qed.

Lemma reff364_not4405 : ~ @Equation4405 Fin4 reff364_inst.
Proof. unfold Equation4405. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff364_inst, reff364_op in H. discriminate H. Qed.

Lemma reff364_not4406 : ~ @Equation4406 Fin4 reff364_inst.
Proof. unfold Equation4406. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff364_inst, reff364_op in H. discriminate H. Qed.

Lemma reff364_not4408 : ~ @Equation4408 Fin4 reff364_inst.
Proof. unfold Equation4408. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff364_inst, reff364_op in H. discriminate H. Qed.

Lemma reff364_not4433 : ~ @Equation4433 Fin4 reff364_inst.
Proof. unfold Equation4433. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff364_inst, reff364_op in H. discriminate H. Qed.

Lemma reff364_not4435 : ~ @Equation4435 Fin4 reff364_inst.
Proof. unfold Equation4435. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff364_inst, reff364_op in H. discriminate H. Qed.

Lemma reff364_not4436 : ~ @Equation4436 Fin4 reff364_inst.
Proof. unfold Equation4436. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff364_inst, reff364_op in H. discriminate H. Qed.

Lemma reff364_not4442 : ~ @Equation4442 Fin4 reff364_inst.
Proof. unfold Equation4442. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff364_inst, reff364_op in H. discriminate H. Qed.

Lemma reff364_not4443 : ~ @Equation4443 Fin4 reff364_inst.
Proof. unfold Equation4443. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff364_inst, reff364_op in H. discriminate H. Qed.

Lemma reff364_not4445 : ~ @Equation4445 Fin4 reff364_inst.
Proof. unfold Equation4445. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff364_inst, reff364_op in H. discriminate H. Qed.

Lemma reff364_not4472 : ~ @Equation4472 Fin4 reff364_inst.
Proof. unfold Equation4472. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff364_inst, reff364_op in H. discriminate H. Qed.

Lemma reff364_not4479 : ~ @Equation4479 Fin4 reff364_inst.
Proof. unfold Equation4479. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff364_inst, reff364_op in H. discriminate H. Qed.

Lemma reff364_not4480 : ~ @Equation4480 Fin4 reff364_inst.
Proof. unfold Equation4480. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff364_inst, reff364_op in H. discriminate H. Qed.

Lemma reff364_not4482 : ~ @Equation4482 Fin4 reff364_inst.
Proof. unfold Equation4482. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff364_inst, reff364_op in H. discriminate H. Qed.

Lemma reff364_not4583 : ~ @Equation4583 Fin4 reff364_inst.
Proof. unfold Equation4583. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff364_inst, reff364_op in H. discriminate H. Qed.

Lemma reff364_not4584 : ~ @Equation4584 Fin4 reff364_inst.
Proof. unfold Equation4584. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff364_inst, reff364_op in H. discriminate H. Qed.

Lemma reff364_not4585 : ~ @Equation4585 Fin4 reff364_inst.
Proof. unfold Equation4585. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff364_inst, reff364_op in H. discriminate H. Qed.

Lemma reff364_not4587 : ~ @Equation4587 Fin4 reff364_inst.
Proof. unfold Equation4587. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff364_inst, reff364_op in H. discriminate H. Qed.

Lemma reff364_not4588 : ~ @Equation4588 Fin4 reff364_inst.
Proof. unfold Equation4588. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff364_inst, reff364_op in H. discriminate H. Qed.

Lemma reff364_not4590 : ~ @Equation4590 Fin4 reff364_inst.
Proof. unfold Equation4590. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff364_inst, reff364_op in H. discriminate H. Qed.

Lemma reff364_not4591 : ~ @Equation4591 Fin4 reff364_inst.
Proof. unfold Equation4591. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff364_inst, reff364_op in H. discriminate H. Qed.

Lemma reff364_not4598 : ~ @Equation4598 Fin4 reff364_inst.
Proof. unfold Equation4598. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff364_inst, reff364_op in H. discriminate H. Qed.

Lemma reff364_not4605 : ~ @Equation4605 Fin4 reff364_inst.
Proof. unfold Equation4605. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff364_inst, reff364_op in H. discriminate H. Qed.

Lemma reff364_not4606 : ~ @Equation4606 Fin4 reff364_inst.
Proof. unfold Equation4606. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff364_inst, reff364_op in H. discriminate H. Qed.

Lemma reff364_not4608 : ~ @Equation4608 Fin4 reff364_inst.
Proof. unfold Equation4608. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff364_inst, reff364_op in H. discriminate H. Qed.

Lemma reff364_not4629 : ~ @Equation4629 Fin4 reff364_inst.
Proof. unfold Equation4629. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff364_inst, reff364_op in H. discriminate H. Qed.

Lemma reff364_not4635 : ~ @Equation4635 Fin4 reff364_inst.
Proof. unfold Equation4635. intro H. specialize (H F4_0 F4_2). unfold magma_op, reff364_inst, reff364_op in H. discriminate H. Qed.

Lemma reff364_not4636 : ~ @Equation4636 Fin4 reff364_inst.
Proof. unfold Equation4636. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff364_inst, reff364_op in H. discriminate H. Qed.

Lemma reff364_not4658 : ~ @Equation4658 Fin4 reff364_inst.
Proof. unfold Equation4658. intro H. specialize (H F4_0 F4_1). unfold magma_op, reff364_inst, reff364_op in H. discriminate H. Qed.
