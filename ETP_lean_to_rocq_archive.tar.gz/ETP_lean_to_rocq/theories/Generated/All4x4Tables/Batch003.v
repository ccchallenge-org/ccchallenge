(** * All4x4 counterexamples — batch 3
    Auto-generated from Lean4 All4x4 files. *)

From Stdlib Require Import Utf8.

From ETP Require Import Magma.
From ETP Require Import FinMagma.
From ETP.Equations Require Import All.

Open Scope magma_scope.

(** ---- refa189 (Fin3) ---- *)

Definition refa189_op (x y : Fin3) : Fin3 :=
  match x, y with
  | F3_0, F3_0 => F3_1 | F3_0, F3_1 => F3_0 | F3_0, F3_2 => F3_1
  | F3_1, F3_0 => F3_0 | F3_1, F3_1 => F3_2 | F3_1, F3_2 => F3_1
  | F3_2, F3_0 => F3_0 | F3_2, F3_1 => F3_0 | F3_2, F3_2 => F3_1
  end.

#[local] Instance refa189_inst : Magma Fin3 := {| magma_op := refa189_op |}.

Lemma refa189_sat2090 : @Equation2090 Fin3 refa189_inst.
Proof. unfold Equation2090, magma_op, refa189_inst, refa189_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa189_not3253 : ~ @Equation3253 Fin3 refa189_inst.
Proof. unfold Equation3253. intro H. specialize (H F3_2). unfold magma_op, refa189_inst, refa189_op in H. discriminate H. Qed.

Lemma refa189_not3962 : ~ @Equation3962 Fin3 refa189_inst.
Proof. unfold Equation3962. intro H. specialize (H F3_2 F3_0). unfold magma_op, refa189_inst, refa189_op in H. discriminate H. Qed.

(** ---- refa19 (Fin7) ---- *)

Definition refa19_op (x y : Fin7) : Fin7 :=
  match x, y with
  | F7_0, F7_0 => F7_1 | F7_0, F7_1 => F7_2 | F7_0, F7_2 => F7_3 | F7_0, F7_3 => F7_4 | F7_0, F7_4 => F7_5 | F7_0, F7_5 => F7_0 | F7_0, F7_6 => F7_6
  | F7_1, F7_0 => F7_5 | F7_1, F7_1 => F7_4 | F7_1, F7_2 => F7_0 | F7_1, F7_3 => F7_3 | F7_1, F7_4 => F7_6 | F7_1, F7_5 => F7_1 | F7_1, F7_6 => F7_2
  | F7_2, F7_0 => F7_4 | F7_2, F7_1 => F7_1 | F7_2, F7_2 => F7_6 | F7_2, F7_3 => F7_5 | F7_2, F7_4 => F7_3 | F7_2, F7_5 => F7_2 | F7_2, F7_6 => F7_0
  | F7_3, F7_0 => F7_0 | F7_3, F7_1 => F7_6 | F7_3, F7_2 => F7_4 | F7_3, F7_3 => F7_2 | F7_3, F7_4 => F7_1 | F7_3, F7_5 => F7_3 | F7_3, F7_6 => F7_5
  | F7_4, F7_0 => F7_3 | F7_4, F7_1 => F7_5 | F7_4, F7_2 => F7_2 | F7_4, F7_3 => F7_6 | F7_4, F7_4 => F7_0 | F7_4, F7_5 => F7_4 | F7_4, F7_6 => F7_1
  | F7_5, F7_0 => F7_6 | F7_5, F7_1 => F7_3 | F7_5, F7_2 => F7_1 | F7_5, F7_3 => F7_0 | F7_5, F7_4 => F7_2 | F7_5, F7_5 => F7_5 | F7_5, F7_6 => F7_4
  | F7_6, F7_0 => F7_2 | F7_6, F7_1 => F7_0 | F7_6, F7_2 => F7_5 | F7_6, F7_3 => F7_1 | F7_6, F7_4 => F7_4 | F7_6, F7_5 => F7_6 | F7_6, F7_6 => F7_3
  end.

#[local] Instance refa19_inst : Magma Fin7 := {| magma_op := refa19_op |}.

Lemma refa19_sat2328 : @Equation2328 Fin7 refa19_inst.
Proof. unfold Equation2328, magma_op, refa19_inst, refa19_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa19_not47 : ~ @Equation47 Fin7 refa19_inst.
Proof. unfold Equation47. intro H. specialize (H F7_0). unfold magma_op, refa19_inst, refa19_op in H. discriminate H. Qed.

Lemma refa19_not105 : ~ @Equation105 Fin7 refa19_inst.
Proof. unfold Equation105. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa19_inst, refa19_op in H. discriminate H. Qed.

Lemma refa19_not107 : ~ @Equation107 Fin7 refa19_inst.
Proof. unfold Equation107. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa19_inst, refa19_op in H. discriminate H. Qed.

Lemma refa19_not151 : ~ @Equation151 Fin7 refa19_inst.
Proof. unfold Equation151. intro H. specialize (H F7_0). unfold magma_op, refa19_inst, refa19_op in H. discriminate H. Qed.

Lemma refa19_not203 : ~ @Equation203 Fin7 refa19_inst.
Proof. unfold Equation203. intro H. specialize (H F7_0). unfold magma_op, refa19_inst, refa19_op in H. discriminate H. Qed.

Lemma refa19_not255 : ~ @Equation255 Fin7 refa19_inst.
Proof. unfold Equation255. intro H. specialize (H F7_0). unfold magma_op, refa19_inst, refa19_op in H. discriminate H. Qed.

Lemma refa19_not411 : ~ @Equation411 Fin7 refa19_inst.
Proof. unfold Equation411. intro H. specialize (H F7_0). unfold magma_op, refa19_inst, refa19_op in H. discriminate H. Qed.

Lemma refa19_not614 : ~ @Equation614 Fin7 refa19_inst.
Proof. unfold Equation614. intro H. specialize (H F7_0). unfold magma_op, refa19_inst, refa19_op in H. discriminate H. Qed.

Lemma refa19_not817 : ~ @Equation817 Fin7 refa19_inst.
Proof. unfold Equation817. intro H. specialize (H F7_0). unfold magma_op, refa19_inst, refa19_op in H. discriminate H. Qed.

Lemma refa19_not1020 : ~ @Equation1020 Fin7 refa19_inst.
Proof. unfold Equation1020. intro H. specialize (H F7_0). unfold magma_op, refa19_inst, refa19_op in H. discriminate H. Qed.

Lemma refa19_not1223 : ~ @Equation1223 Fin7 refa19_inst.
Proof. unfold Equation1223. intro H. specialize (H F7_0). unfold magma_op, refa19_inst, refa19_op in H. discriminate H. Qed.

Lemma refa19_not1427 : ~ @Equation1427 Fin7 refa19_inst.
Proof. unfold Equation1427. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa19_inst, refa19_op in H. discriminate H. Qed.

Lemma refa19_not1428 : ~ @Equation1428 Fin7 refa19_inst.
Proof. unfold Equation1428. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa19_inst, refa19_op in H. discriminate H. Qed.

Lemma refa19_not1429 : ~ @Equation1429 Fin7 refa19_inst.
Proof. unfold Equation1429. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa19_inst, refa19_op in H. discriminate H. Qed.

Lemma refa19_not1431 : ~ @Equation1431 Fin7 refa19_inst.
Proof. unfold Equation1431. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa19_inst, refa19_op in H. discriminate H. Qed.

Lemma refa19_not1434 : ~ @Equation1434 Fin7 refa19_inst.
Proof. unfold Equation1434. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa19_inst, refa19_op in H. discriminate H. Qed.

Lemma refa19_not1435 : ~ @Equation1435 Fin7 refa19_inst.
Proof. unfold Equation1435. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa19_inst, refa19_op in H. discriminate H. Qed.

Lemma refa19_not1441 : ~ @Equation1441 Fin7 refa19_inst.
Proof. unfold Equation1441. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa19_inst, refa19_op in H. discriminate H. Qed.

Lemma refa19_not1445 : ~ @Equation1445 Fin7 refa19_inst.
Proof. unfold Equation1445. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa19_inst, refa19_op in H. discriminate H. Qed.

Lemma refa19_not1454 : ~ @Equation1454 Fin7 refa19_inst.
Proof. unfold Equation1454. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa19_inst, refa19_op in H. discriminate H. Qed.

Lemma refa19_not1478 : ~ @Equation1478 Fin7 refa19_inst.
Proof. unfold Equation1478. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa19_inst, refa19_op in H. discriminate H. Qed.

Lemma refa19_not1482 : ~ @Equation1482 Fin7 refa19_inst.
Proof. unfold Equation1482. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa19_inst, refa19_op in H. discriminate H. Qed.

Lemma refa19_not1488 : ~ @Equation1488 Fin7 refa19_inst.
Proof. unfold Equation1488. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa19_inst, refa19_op in H. discriminate H. Qed.

Lemma refa19_not1515 : ~ @Equation1515 Fin7 refa19_inst.
Proof. unfold Equation1515. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa19_inst, refa19_op in H. discriminate H. Qed.

Lemma refa19_not1516 : ~ @Equation1516 Fin7 refa19_inst.
Proof. unfold Equation1516. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa19_inst, refa19_op in H. discriminate H. Qed.

Lemma refa19_not1519 : ~ @Equation1519 Fin7 refa19_inst.
Proof. unfold Equation1519. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa19_inst, refa19_op in H. discriminate H. Qed.

Lemma refa19_not1629 : ~ @Equation1629 Fin7 refa19_inst.
Proof. unfold Equation1629. intro H. specialize (H F7_0). unfold magma_op, refa19_inst, refa19_op in H. discriminate H. Qed.

Lemma refa19_not1832 : ~ @Equation1832 Fin7 refa19_inst.
Proof. unfold Equation1832. intro H. specialize (H F7_0). unfold magma_op, refa19_inst, refa19_op in H. discriminate H. Qed.

Lemma refa19_not2035 : ~ @Equation2035 Fin7 refa19_inst.
Proof. unfold Equation2035. intro H. specialize (H F7_0). unfold magma_op, refa19_inst, refa19_op in H. discriminate H. Qed.

Lemma refa19_not2240 : ~ @Equation2240 Fin7 refa19_inst.
Proof. unfold Equation2240. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa19_inst, refa19_op in H. discriminate H. Qed.

Lemma refa19_not2244 : ~ @Equation2244 Fin7 refa19_inst.
Proof. unfold Equation2244. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa19_inst, refa19_op in H. discriminate H. Qed.

Lemma refa19_not2246 : ~ @Equation2246 Fin7 refa19_inst.
Proof. unfold Equation2246. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa19_inst, refa19_op in H. discriminate H. Qed.

Lemma refa19_not2247 : ~ @Equation2247 Fin7 refa19_inst.
Proof. unfold Equation2247. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa19_inst, refa19_op in H. discriminate H. Qed.

Lemma refa19_not2254 : ~ @Equation2254 Fin7 refa19_inst.
Proof. unfold Equation2254. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa19_inst, refa19_op in H. discriminate H. Qed.

Lemma refa19_not2256 : ~ @Equation2256 Fin7 refa19_inst.
Proof. unfold Equation2256. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa19_inst, refa19_op in H. discriminate H. Qed.

Lemma refa19_not2257 : ~ @Equation2257 Fin7 refa19_inst.
Proof. unfold Equation2257. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa19_inst, refa19_op in H. discriminate H. Qed.

Lemma refa19_not2264 : ~ @Equation2264 Fin7 refa19_inst.
Proof. unfold Equation2264. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa19_inst, refa19_op in H. discriminate H. Qed.

Lemma refa19_not2266 : ~ @Equation2266 Fin7 refa19_inst.
Proof. unfold Equation2266. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa19_inst, refa19_op in H. discriminate H. Qed.

Lemma refa19_not2291 : ~ @Equation2291 Fin7 refa19_inst.
Proof. unfold Equation2291. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa19_inst, refa19_op in H. discriminate H. Qed.

Lemma refa19_not2300 : ~ @Equation2300 Fin7 refa19_inst.
Proof. unfold Equation2300. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa19_inst, refa19_op in H. discriminate H. Qed.

Lemma refa19_not2301 : ~ @Equation2301 Fin7 refa19_inst.
Proof. unfold Equation2301. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa19_inst, refa19_op in H. discriminate H. Qed.

Lemma refa19_not2303 : ~ @Equation2303 Fin7 refa19_inst.
Proof. unfold Equation2303. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa19_inst, refa19_op in H. discriminate H. Qed.

Lemma refa19_not2330 : ~ @Equation2330 Fin7 refa19_inst.
Proof. unfold Equation2330. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa19_inst, refa19_op in H. discriminate H. Qed.

Lemma refa19_not2340 : ~ @Equation2340 Fin7 refa19_inst.
Proof. unfold Equation2340. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa19_inst, refa19_op in H. discriminate H. Qed.

Lemma refa19_not2441 : ~ @Equation2441 Fin7 refa19_inst.
Proof. unfold Equation2441. intro H. specialize (H F7_0). unfold magma_op, refa19_inst, refa19_op in H. discriminate H. Qed.

Lemma refa19_not2644 : ~ @Equation2644 Fin7 refa19_inst.
Proof. unfold Equation2644. intro H. specialize (H F7_0). unfold magma_op, refa19_inst, refa19_op in H. discriminate H. Qed.

Lemma refa19_not2847 : ~ @Equation2847 Fin7 refa19_inst.
Proof. unfold Equation2847. intro H. specialize (H F7_0). unfold magma_op, refa19_inst, refa19_op in H. discriminate H. Qed.

Lemma refa19_not3050 : ~ @Equation3050 Fin7 refa19_inst.
Proof. unfold Equation3050. intro H. specialize (H F7_0). unfold magma_op, refa19_inst, refa19_op in H. discriminate H. Qed.

Lemma refa19_not3253 : ~ @Equation3253 Fin7 refa19_inst.
Proof. unfold Equation3253. intro H. specialize (H F7_0). unfold magma_op, refa19_inst, refa19_op in H. discriminate H. Qed.

Lemma refa19_not3456 : ~ @Equation3456 Fin7 refa19_inst.
Proof. unfold Equation3456. intro H. specialize (H F7_0). unfold magma_op, refa19_inst, refa19_op in H. discriminate H. Qed.

Lemma refa19_not3659 : ~ @Equation3659 Fin7 refa19_inst.
Proof. unfold Equation3659. intro H. specialize (H F7_0). unfold magma_op, refa19_inst, refa19_op in H. discriminate H. Qed.

Lemma refa19_not3862 : ~ @Equation3862 Fin7 refa19_inst.
Proof. unfold Equation3862. intro H. specialize (H F7_0). unfold magma_op, refa19_inst, refa19_op in H. discriminate H. Qed.

Lemma refa19_not4065 : ~ @Equation4065 Fin7 refa19_inst.
Proof. unfold Equation4065. intro H. specialize (H F7_0). unfold magma_op, refa19_inst, refa19_op in H. discriminate H. Qed.

Lemma refa19_not4268 : ~ @Equation4268 Fin7 refa19_inst.
Proof. unfold Equation4268. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa19_inst, refa19_op in H. discriminate H. Qed.

Lemma refa19_not4269 : ~ @Equation4269 Fin7 refa19_inst.
Proof. unfold Equation4269. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa19_inst, refa19_op in H. discriminate H. Qed.

Lemma refa19_not4270 : ~ @Equation4270 Fin7 refa19_inst.
Proof. unfold Equation4270. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa19_inst, refa19_op in H. discriminate H. Qed.

Lemma refa19_not4272 : ~ @Equation4272 Fin7 refa19_inst.
Proof. unfold Equation4272. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa19_inst, refa19_op in H. discriminate H. Qed.

Lemma refa19_not4273 : ~ @Equation4273 Fin7 refa19_inst.
Proof. unfold Equation4273. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa19_inst, refa19_op in H. discriminate H. Qed.

Lemma refa19_not4275 : ~ @Equation4275 Fin7 refa19_inst.
Proof. unfold Equation4275. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa19_inst, refa19_op in H. discriminate H. Qed.

Lemma refa19_not4283 : ~ @Equation4283 Fin7 refa19_inst.
Proof. unfold Equation4283. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa19_inst, refa19_op in H. discriminate H. Qed.

Lemma refa19_not4284 : ~ @Equation4284 Fin7 refa19_inst.
Proof. unfold Equation4284. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa19_inst, refa19_op in H. discriminate H. Qed.

Lemma refa19_not4290 : ~ @Equation4290 Fin7 refa19_inst.
Proof. unfold Equation4290. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa19_inst, refa19_op in H. discriminate H. Qed.

Lemma refa19_not4291 : ~ @Equation4291 Fin7 refa19_inst.
Proof. unfold Equation4291. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa19_inst, refa19_op in H. discriminate H. Qed.

Lemma refa19_not4293 : ~ @Equation4293 Fin7 refa19_inst.
Proof. unfold Equation4293. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa19_inst, refa19_op in H. discriminate H. Qed.

Lemma refa19_not4314 : ~ @Equation4314 Fin7 refa19_inst.
Proof. unfold Equation4314. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa19_inst, refa19_op in H. discriminate H. Qed.

Lemma refa19_not4343 : ~ @Equation4343 Fin7 refa19_inst.
Proof. unfold Equation4343. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa19_inst, refa19_op in H. discriminate H. Qed.

Lemma refa19_not4380 : ~ @Equation4380 Fin7 refa19_inst.
Proof. unfold Equation4380. intro H. specialize (H F7_0). unfold magma_op, refa19_inst, refa19_op in H. discriminate H. Qed.

Lemma refa19_not4583 : ~ @Equation4583 Fin7 refa19_inst.
Proof. unfold Equation4583. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa19_inst, refa19_op in H. discriminate H. Qed.

Lemma refa19_not4584 : ~ @Equation4584 Fin7 refa19_inst.
Proof. unfold Equation4584. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa19_inst, refa19_op in H. discriminate H. Qed.

Lemma refa19_not4585 : ~ @Equation4585 Fin7 refa19_inst.
Proof. unfold Equation4585. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa19_inst, refa19_op in H. discriminate H. Qed.

Lemma refa19_not4587 : ~ @Equation4587 Fin7 refa19_inst.
Proof. unfold Equation4587. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa19_inst, refa19_op in H. discriminate H. Qed.

Lemma refa19_not4588 : ~ @Equation4588 Fin7 refa19_inst.
Proof. unfold Equation4588. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa19_inst, refa19_op in H. discriminate H. Qed.

Lemma refa19_not4590 : ~ @Equation4590 Fin7 refa19_inst.
Proof. unfold Equation4590. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa19_inst, refa19_op in H. discriminate H. Qed.

Lemma refa19_not4599 : ~ @Equation4599 Fin7 refa19_inst.
Proof. unfold Equation4599. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa19_inst, refa19_op in H. discriminate H. Qed.

Lemma refa19_not4606 : ~ @Equation4606 Fin7 refa19_inst.
Proof. unfold Equation4606. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa19_inst, refa19_op in H. discriminate H. Qed.

Lemma refa19_not4608 : ~ @Equation4608 Fin7 refa19_inst.
Proof. unfold Equation4608. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa19_inst, refa19_op in H. discriminate H. Qed.

Lemma refa19_not4629 : ~ @Equation4629 Fin7 refa19_inst.
Proof. unfold Equation4629. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa19_inst, refa19_op in H. discriminate H. Qed.

Lemma refa19_not4635 : ~ @Equation4635 Fin7 refa19_inst.
Proof. unfold Equation4635. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa19_inst, refa19_op in H. discriminate H. Qed.

Lemma refa19_not4658 : ~ @Equation4658 Fin7 refa19_inst.
Proof. unfold Equation4658. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa19_inst, refa19_op in H. discriminate H. Qed.

Lemma refa19_not4684 : ~ @Equation4684 Fin7 refa19_inst.
Proof. unfold Equation4684. intro H. specialize (H F7_0 F7_0 F7_1). unfold magma_op, refa19_inst, refa19_op in H. discriminate H. Qed.

(** ---- refa190 (Fin3) ---- *)

Definition refa190_op (x y : Fin3) : Fin3 :=
  match x, y with
  | F3_0, F3_0 => F3_0 | F3_0, F3_1 => F3_0 | F3_0, F3_2 => F3_1
  | F3_1, F3_0 => F3_0 | F3_1, F3_1 => F3_0 | F3_1, F3_2 => F3_1
  | F3_2, F3_0 => F3_2 | F3_2, F3_1 => F3_2 | F3_2, F3_2 => F3_0
  end.

#[local] Instance refa190_inst : Magma Fin3 := {| magma_op := refa190_op |}.

Lemma refa190_sat3902 : @Equation3902 Fin3 refa190_inst.
Proof. unfold Equation3902, magma_op, refa190_inst, refa190_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa190_not3660 : ~ @Equation3660 Fin3 refa190_inst.
Proof. unfold Equation3660. intro H. specialize (H F3_2 F3_0). unfold magma_op, refa190_inst, refa190_op in H. discriminate H. Qed.

Lemma refa190_not3661 : ~ @Equation3661 Fin3 refa190_inst.
Proof. unfold Equation3661. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa190_inst, refa190_op in H. discriminate H. Qed.

Lemma refa190_not3685 : ~ @Equation3685 Fin3 refa190_inst.
Proof. unfold Equation3685. intro H. specialize (H F3_2 F3_0). unfold magma_op, refa190_inst, refa190_op in H. discriminate H. Qed.

Lemma refa190_not3687 : ~ @Equation3687 Fin3 refa190_inst.
Proof. unfold Equation3687. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa190_inst, refa190_op in H. discriminate H. Qed.

Lemma refa190_not3721 : ~ @Equation3721 Fin3 refa190_inst.
Proof. unfold Equation3721. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa190_inst, refa190_op in H. discriminate H. Qed.

Lemma refa190_not3725 : ~ @Equation3725 Fin3 refa190_inst.
Proof. unfold Equation3725. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa190_inst, refa190_op in H. discriminate H. Qed.

Lemma refa190_not3864 : ~ @Equation3864 Fin3 refa190_inst.
Proof. unfold Equation3864. intro H. specialize (H F3_2 F3_0). unfold magma_op, refa190_inst, refa190_op in H. discriminate H. Qed.

Lemma refa190_not3888 : ~ @Equation3888 Fin3 refa190_inst.
Proof. unfold Equation3888. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa190_inst, refa190_op in H. discriminate H. Qed.

Lemma refa190_not4065 : ~ @Equation4065 Fin3 refa190_inst.
Proof. unfold Equation4065. intro H. specialize (H F3_2). unfold magma_op, refa190_inst, refa190_op in H. discriminate H. Qed.

(** ---- refa191 (Fin3) ---- *)

Definition refa191_op (x y : Fin3) : Fin3 :=
  match x, y with
  | F3_0, F3_0 => F3_0 | F3_0, F3_1 => F3_0 | F3_0, F3_2 => F3_2
  | F3_1, F3_0 => F3_0 | F3_1, F3_1 => F3_0 | F3_1, F3_2 => F3_2
  | F3_2, F3_0 => F3_0 | F3_2, F3_1 => F3_2 | F3_2, F3_2 => F3_2
  end.

#[local] Instance refa191_inst : Magma Fin3 := {| magma_op := refa191_op |}.

Lemma refa191_sat3583 : @Equation3583 Fin3 refa191_inst.
Proof. unfold Equation3583, magma_op, refa191_inst, refa191_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa191_sat3587 : @Equation3587 Fin3 refa191_inst.
Proof. unfold Equation3587, magma_op, refa191_inst, refa191_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa191_sat3600 : @Equation3600 Fin3 refa191_inst.
Proof. unfold Equation3600, magma_op, refa191_inst, refa191_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa191_not3255 : ~ @Equation3255 Fin3 refa191_inst.
Proof. unfold Equation3255. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa191_inst, refa191_op in H. discriminate H. Qed.

Lemma refa191_not3261 : ~ @Equation3261 Fin3 refa191_inst.
Proof. unfold Equation3261. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa191_inst, refa191_op in H. discriminate H. Qed.

Lemma refa191_not3271 : ~ @Equation3271 Fin3 refa191_inst.
Proof. unfold Equation3271. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa191_inst, refa191_op in H. discriminate H. Qed.

Lemma refa191_not3281 : ~ @Equation3281 Fin3 refa191_inst.
Proof. unfold Equation3281. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa191_inst, refa191_op in H. discriminate H. Qed.

Lemma refa191_not3309 : ~ @Equation3309 Fin3 refa191_inst.
Proof. unfold Equation3309. intro H. specialize (H F3_2 F3_1). unfold magma_op, refa191_inst, refa191_op in H. discriminate H. Qed.

Lemma refa191_not3319 : ~ @Equation3319 Fin3 refa191_inst.
Proof. unfold Equation3319. intro H. specialize (H F3_2 F3_1). unfold magma_op, refa191_inst, refa191_op in H. discriminate H. Qed.

Lemma refa191_not3346 : ~ @Equation3346 Fin3 refa191_inst.
Proof. unfold Equation3346. intro H. specialize (H F3_2 F3_1). unfold magma_op, refa191_inst, refa191_op in H. discriminate H. Qed.

Lemma refa191_not3458 : ~ @Equation3458 Fin3 refa191_inst.
Proof. unfold Equation3458. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa191_inst, refa191_op in H. discriminate H. Qed.

Lemma refa191_not3461 : ~ @Equation3461 Fin3 refa191_inst.
Proof. unfold Equation3461. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa191_inst, refa191_op in H. discriminate H. Qed.

Lemma refa191_not3464 : ~ @Equation3464 Fin3 refa191_inst.
Proof. unfold Equation3464. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa191_inst, refa191_op in H. discriminate H. Qed.

Lemma refa191_not3474 : ~ @Equation3474 Fin3 refa191_inst.
Proof. unfold Equation3474. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa191_inst, refa191_op in H. discriminate H. Qed.

Lemma refa191_not3481 : ~ @Equation3481 Fin3 refa191_inst.
Proof. unfold Equation3481. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa191_inst, refa191_op in H. discriminate H. Qed.

Lemma refa191_not3484 : ~ @Equation3484 Fin3 refa191_inst.
Proof. unfold Equation3484. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa191_inst, refa191_op in H. discriminate H. Qed.

Lemma refa191_not3522 : ~ @Equation3522 Fin3 refa191_inst.
Proof. unfold Equation3522. intro H. specialize (H F3_2 F3_1). unfold magma_op, refa191_inst, refa191_op in H. discriminate H. Qed.

Lemma refa191_not3661 : ~ @Equation3661 Fin3 refa191_inst.
Proof. unfold Equation3661. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa191_inst, refa191_op in H. discriminate H. Qed.

Lemma refa191_not3667 : ~ @Equation3667 Fin3 refa191_inst.
Proof. unfold Equation3667. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa191_inst, refa191_op in H. discriminate H. Qed.

Lemma refa191_not3677 : ~ @Equation3677 Fin3 refa191_inst.
Proof. unfold Equation3677. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa191_inst, refa191_op in H. discriminate H. Qed.

Lemma refa191_not3687 : ~ @Equation3687 Fin3 refa191_inst.
Proof. unfold Equation3687. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa191_inst, refa191_op in H. discriminate H. Qed.

Lemma refa191_not3725 : ~ @Equation3725 Fin3 refa191_inst.
Proof. unfold Equation3725. intro H. specialize (H F3_2 F3_1). unfold magma_op, refa191_inst, refa191_op in H. discriminate H. Qed.

Lemma refa191_not3752 : ~ @Equation3752 Fin3 refa191_inst.
Proof. unfold Equation3752. intro H. specialize (H F3_2 F3_1). unfold magma_op, refa191_inst, refa191_op in H. discriminate H. Qed.

Lemma refa191_not3864 : ~ @Equation3864 Fin3 refa191_inst.
Proof. unfold Equation3864. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa191_inst, refa191_op in H. discriminate H. Qed.

Lemma refa191_not3867 : ~ @Equation3867 Fin3 refa191_inst.
Proof. unfold Equation3867. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa191_inst, refa191_op in H. discriminate H. Qed.

Lemma refa191_not3870 : ~ @Equation3870 Fin3 refa191_inst.
Proof. unfold Equation3870. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa191_inst, refa191_op in H. discriminate H. Qed.

Lemma refa191_not3880 : ~ @Equation3880 Fin3 refa191_inst.
Proof. unfold Equation3880. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa191_inst, refa191_op in H. discriminate H. Qed.

Lemma refa191_not3887 : ~ @Equation3887 Fin3 refa191_inst.
Proof. unfold Equation3887. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa191_inst, refa191_op in H. discriminate H. Qed.

Lemma refa191_not3890 : ~ @Equation3890 Fin3 refa191_inst.
Proof. unfold Equation3890. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa191_inst, refa191_op in H. discriminate H. Qed.

Lemma refa191_not3928 : ~ @Equation3928 Fin3 refa191_inst.
Proof. unfold Equation3928. intro H. specialize (H F3_2 F3_1). unfold magma_op, refa191_inst, refa191_op in H. discriminate H. Qed.

Lemma refa191_not4067 : ~ @Equation4067 Fin3 refa191_inst.
Proof. unfold Equation4067. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa191_inst, refa191_op in H. discriminate H. Qed.

Lemma refa191_not4070 : ~ @Equation4070 Fin3 refa191_inst.
Proof. unfold Equation4070. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa191_inst, refa191_op in H. discriminate H. Qed.

Lemma refa191_not4073 : ~ @Equation4073 Fin3 refa191_inst.
Proof. unfold Equation4073. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa191_inst, refa191_op in H. discriminate H. Qed.

Lemma refa191_not4080 : ~ @Equation4080 Fin3 refa191_inst.
Proof. unfold Equation4080. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa191_inst, refa191_op in H. discriminate H. Qed.

Lemma refa191_not4083 : ~ @Equation4083 Fin3 refa191_inst.
Proof. unfold Equation4083. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa191_inst, refa191_op in H. discriminate H. Qed.

Lemma refa191_not4090 : ~ @Equation4090 Fin3 refa191_inst.
Proof. unfold Equation4090. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa191_inst, refa191_op in H. discriminate H. Qed.

Lemma refa191_not4093 : ~ @Equation4093 Fin3 refa191_inst.
Proof. unfold Equation4093. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa191_inst, refa191_op in H. discriminate H. Qed.

Lemma refa191_not4269 : ~ @Equation4269 Fin3 refa191_inst.
Proof. unfold Equation4269. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa191_inst, refa191_op in H. discriminate H. Qed.

Lemma refa191_not4275 : ~ @Equation4275 Fin3 refa191_inst.
Proof. unfold Equation4275. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa191_inst, refa191_op in H. discriminate H. Qed.

Lemma refa191_not4284 : ~ @Equation4284 Fin3 refa191_inst.
Proof. unfold Equation4284. intro H. specialize (H F3_2 F3_1). unfold magma_op, refa191_inst, refa191_op in H. discriminate H. Qed.

Lemma refa191_not4320 : ~ @Equation4320 Fin3 refa191_inst.
Proof. unfold Equation4320. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa191_inst, refa191_op in H. discriminate H. Qed.

Lemma refa191_not4470 : ~ @Equation4470 Fin3 refa191_inst.
Proof. unfold Equation4470. intro H. specialize (H F3_2 F3_1). unfold magma_op, refa191_inst, refa191_op in H. discriminate H. Qed.

Lemma refa191_not4473 : ~ @Equation4473 Fin3 refa191_inst.
Proof. unfold Equation4473. intro H. specialize (H F3_2 F3_1). unfold magma_op, refa191_inst, refa191_op in H. discriminate H. Qed.

Lemma refa191_not4480 : ~ @Equation4480 Fin3 refa191_inst.
Proof. unfold Equation4480. intro H. specialize (H F3_2 F3_1). unfold magma_op, refa191_inst, refa191_op in H. discriminate H. Qed.

Lemma refa191_not4584 : ~ @Equation4584 Fin3 refa191_inst.
Proof. unfold Equation4584. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa191_inst, refa191_op in H. discriminate H. Qed.

Lemma refa191_not4587 : ~ @Equation4587 Fin3 refa191_inst.
Proof. unfold Equation4587. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa191_inst, refa191_op in H. discriminate H. Qed.

Lemma refa191_not4590 : ~ @Equation4590 Fin3 refa191_inst.
Proof. unfold Equation4590. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa191_inst, refa191_op in H. discriminate H. Qed.

Lemma refa191_not4677 : ~ @Equation4677 Fin3 refa191_inst.
Proof. unfold Equation4677. intro H. specialize (H F3_0 F3_2 F3_1). unfold magma_op, refa191_inst, refa191_op in H. discriminate H. Qed.

(** ---- refa192 (Fin3) ---- *)

Definition refa192_op (x y : Fin3) : Fin3 :=
  match x, y with
  | F3_0, F3_0 => F3_0 | F3_0, F3_1 => F3_0 | F3_0, F3_2 => F3_2
  | F3_1, F3_0 => F3_0 | F3_1, F3_1 => F3_0 | F3_1, F3_2 => F3_0
  | F3_2, F3_0 => F3_0 | F3_2, F3_1 => F3_2 | F3_2, F3_2 => F3_2
  end.

#[local] Instance refa192_inst : Magma Fin3 := {| magma_op := refa192_op |}.

Lemma refa192_sat3837 : @Equation3837 Fin3 refa192_inst.
Proof. unfold Equation3837, magma_op, refa192_inst, refa192_op. intros x y z w. destruct x, y, z, w; reflexivity. Qed.

Lemma refa192_not4606 : ~ @Equation4606 Fin3 refa192_inst.
Proof. unfold Equation4606. intro H. specialize (H F3_2 F3_1). unfold magma_op, refa192_inst, refa192_op in H. discriminate H. Qed.

(** ---- refa193 (Fin3) ---- *)

Definition refa193_op (x y : Fin3) : Fin3 :=
  match x, y with
  | F3_0, F3_0 => F3_0 | F3_0, F3_1 => F3_1 | F3_0, F3_2 => F3_2
  | F3_1, F3_0 => F3_2 | F3_1, F3_1 => F3_0 | F3_1, F3_2 => F3_1
  | F3_2, F3_0 => F3_1 | F3_2, F3_1 => F3_2 | F3_2, F3_2 => F3_0
  end.

#[local] Instance refa193_inst : Magma Fin3 := {| magma_op := refa193_op |}.

Lemma refa193_sat50 : @Equation50 Fin3 refa193_inst.
Proof. unfold Equation50, magma_op, refa193_inst, refa193_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa193_sat53 : @Equation53 Fin3 refa193_inst.
Proof. unfold Equation53, magma_op, refa193_inst, refa193_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa193_sat63 : @Equation63 Fin3 refa193_inst.
Proof. unfold Equation63, magma_op, refa193_inst, refa193_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa193_sat75 : @Equation75 Fin3 refa193_inst.
Proof. unfold Equation75, magma_op, refa193_inst, refa193_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa193_sat1046 : @Equation1046 Fin3 refa193_inst.
Proof. unfold Equation1046, magma_op, refa193_inst, refa193_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa193_sat1090 : @Equation1090 Fin3 refa193_inst.
Proof. unfold Equation1090, magma_op, refa193_inst, refa193_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa193_sat1692 : @Equation1692 Fin3 refa193_inst.
Proof. unfold Equation1692, magma_op, refa193_inst, refa193_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa193_sat2504 : @Equation2504 Fin3 refa193_inst.
Proof. unfold Equation2504, magma_op, refa193_inst, refa193_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa193_sat2670 : @Equation2670 Fin3 refa193_inst.
Proof. unfold Equation2670, magma_op, refa193_inst, refa193_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa193_sat3113 : @Equation3113 Fin3 refa193_inst.
Proof. unfold Equation3113, magma_op, refa193_inst, refa193_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa193_sat3548 : @Equation3548 Fin3 refa193_inst.
Proof. unfold Equation3548, magma_op, refa193_inst, refa193_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa193_sat3724 : @Equation3724 Fin3 refa193_inst.
Proof. unfold Equation3724, magma_op, refa193_inst, refa193_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa193_sat4157 : @Equation4157 Fin3 refa193_inst.
Proof. unfold Equation4157, magma_op, refa193_inst, refa193_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa193_not56 : ~ @Equation56 Fin3 refa193_inst.
Proof. unfold Equation56. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa193_inst, refa193_op in H. discriminate H. Qed.

Lemma refa193_not65 : ~ @Equation65 Fin3 refa193_inst.
Proof. unfold Equation65. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa193_inst, refa193_op in H. discriminate H. Qed.

Lemma refa193_not73 : ~ @Equation73 Fin3 refa193_inst.
Proof. unfold Equation73. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa193_inst, refa193_op in H. discriminate H. Qed.

Lemma refa193_not99 : ~ @Equation99 Fin3 refa193_inst.
Proof. unfold Equation99. intro H. specialize (H F3_1). unfold magma_op, refa193_inst, refa193_op in H. discriminate H. Qed.

Lemma refa193_not151 : ~ @Equation151 Fin3 refa193_inst.
Proof. unfold Equation151. intro H. specialize (H F3_1). unfold magma_op, refa193_inst, refa193_op in H. discriminate H. Qed.

Lemma refa193_not203 : ~ @Equation203 Fin3 refa193_inst.
Proof. unfold Equation203. intro H. specialize (H F3_1). unfold magma_op, refa193_inst, refa193_op in H. discriminate H. Qed.

Lemma refa193_not255 : ~ @Equation255 Fin3 refa193_inst.
Proof. unfold Equation255. intro H. specialize (H F3_1). unfold magma_op, refa193_inst, refa193_op in H. discriminate H. Qed.

Lemma refa193_not359 : ~ @Equation359 Fin3 refa193_inst.
Proof. unfold Equation359. intro H. specialize (H F3_1). unfold magma_op, refa193_inst, refa193_op in H. discriminate H. Qed.

Lemma refa193_not411 : ~ @Equation411 Fin3 refa193_inst.
Proof. unfold Equation411. intro H. specialize (H F3_1). unfold magma_op, refa193_inst, refa193_op in H. discriminate H. Qed.

Lemma refa193_not614 : ~ @Equation614 Fin3 refa193_inst.
Proof. unfold Equation614. intro H. specialize (H F3_1). unfold magma_op, refa193_inst, refa193_op in H. discriminate H. Qed.

Lemma refa193_not817 : ~ @Equation817 Fin3 refa193_inst.
Proof. unfold Equation817. intro H. specialize (H F3_1). unfold magma_op, refa193_inst, refa193_op in H. discriminate H. Qed.

Lemma refa193_not1021 : ~ @Equation1021 Fin3 refa193_inst.
Proof. unfold Equation1021. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa193_inst, refa193_op in H. discriminate H. Qed.

Lemma refa193_not1029 : ~ @Equation1029 Fin3 refa193_inst.
Proof. unfold Equation1029. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa193_inst, refa193_op in H. discriminate H. Qed.

Lemma refa193_not1035 : ~ @Equation1035 Fin3 refa193_inst.
Proof. unfold Equation1035. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa193_inst, refa193_op in H. discriminate H. Qed.

Lemma refa193_not1036 : ~ @Equation1036 Fin3 refa193_inst.
Proof. unfold Equation1036. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa193_inst, refa193_op in H. discriminate H. Qed.

Lemma refa193_not1039 : ~ @Equation1039 Fin3 refa193_inst.
Proof. unfold Equation1039. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa193_inst, refa193_op in H. discriminate H. Qed.

Lemma refa193_not1045 : ~ @Equation1045 Fin3 refa193_inst.
Proof. unfold Equation1045. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa193_inst, refa193_op in H. discriminate H. Qed.

Lemma refa193_not1048 : ~ @Equation1048 Fin3 refa193_inst.
Proof. unfold Equation1048. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa193_inst, refa193_op in H. discriminate H. Qed.

Lemma refa193_not1049 : ~ @Equation1049 Fin3 refa193_inst.
Proof. unfold Equation1049. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa193_inst, refa193_op in H. discriminate H. Qed.

Lemma refa193_not1075 : ~ @Equation1075 Fin3 refa193_inst.
Proof. unfold Equation1075. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa193_inst, refa193_op in H. discriminate H. Qed.

Lemma refa193_not1076 : ~ @Equation1076 Fin3 refa193_inst.
Proof. unfold Equation1076. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa193_inst, refa193_op in H. discriminate H. Qed.

Lemma refa193_not1083 : ~ @Equation1083 Fin3 refa193_inst.
Proof. unfold Equation1083. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa193_inst, refa193_op in H. discriminate H. Qed.

Lemma refa193_not1085 : ~ @Equation1085 Fin3 refa193_inst.
Proof. unfold Equation1085. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa193_inst, refa193_op in H. discriminate H. Qed.

Lemma refa193_not1110 : ~ @Equation1110 Fin3 refa193_inst.
Proof. unfold Equation1110. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa193_inst, refa193_op in H. discriminate H. Qed.

Lemma refa193_not1112 : ~ @Equation1112 Fin3 refa193_inst.
Proof. unfold Equation1112. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa193_inst, refa193_op in H. discriminate H. Qed.

Lemma refa193_not1223 : ~ @Equation1223 Fin3 refa193_inst.
Proof. unfold Equation1223. intro H. specialize (H F3_1). unfold magma_op, refa193_inst, refa193_op in H. discriminate H. Qed.

Lemma refa193_not1426 : ~ @Equation1426 Fin3 refa193_inst.
Proof. unfold Equation1426. intro H. specialize (H F3_1). unfold magma_op, refa193_inst, refa193_op in H. discriminate H. Qed.

Lemma refa193_not1630 : ~ @Equation1630 Fin3 refa193_inst.
Proof. unfold Equation1630. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa193_inst, refa193_op in H. discriminate H. Qed.

Lemma refa193_not1631 : ~ @Equation1631 Fin3 refa193_inst.
Proof. unfold Equation1631. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa193_inst, refa193_op in H. discriminate H. Qed.

Lemma refa193_not1634 : ~ @Equation1634 Fin3 refa193_inst.
Proof. unfold Equation1634. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa193_inst, refa193_op in H. discriminate H. Qed.

Lemma refa193_not1635 : ~ @Equation1635 Fin3 refa193_inst.
Proof. unfold Equation1635. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa193_inst, refa193_op in H. discriminate H. Qed.

Lemma refa193_not1638 : ~ @Equation1638 Fin3 refa193_inst.
Proof. unfold Equation1638. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa193_inst, refa193_op in H. discriminate H. Qed.

Lemma refa193_not1644 : ~ @Equation1644 Fin3 refa193_inst.
Proof. unfold Equation1644. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa193_inst, refa193_op in H. discriminate H. Qed.

Lemma refa193_not1648 : ~ @Equation1648 Fin3 refa193_inst.
Proof. unfold Equation1648. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa193_inst, refa193_op in H. discriminate H. Qed.

Lemma refa193_not1655 : ~ @Equation1655 Fin3 refa193_inst.
Proof. unfold Equation1655. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa193_inst, refa193_op in H. discriminate H. Qed.

Lemma refa193_not1657 : ~ @Equation1657 Fin3 refa193_inst.
Proof. unfold Equation1657. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa193_inst, refa193_op in H. discriminate H. Qed.

Lemma refa193_not1681 : ~ @Equation1681 Fin3 refa193_inst.
Proof. unfold Equation1681. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa193_inst, refa193_op in H. discriminate H. Qed.

Lemma refa193_not1682 : ~ @Equation1682 Fin3 refa193_inst.
Proof. unfold Equation1682. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa193_inst, refa193_op in H. discriminate H. Qed.

Lemma refa193_not1685 : ~ @Equation1685 Fin3 refa193_inst.
Proof. unfold Equation1685. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa193_inst, refa193_op in H. discriminate H. Qed.

Lemma refa193_not1691 : ~ @Equation1691 Fin3 refa193_inst.
Proof. unfold Equation1691. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa193_inst, refa193_op in H. discriminate H. Qed.

Lemma refa193_not1694 : ~ @Equation1694 Fin3 refa193_inst.
Proof. unfold Equation1694. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa193_inst, refa193_op in H. discriminate H. Qed.

Lemma refa193_not1719 : ~ @Equation1719 Fin3 refa193_inst.
Proof. unfold Equation1719. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa193_inst, refa193_op in H. discriminate H. Qed.

Lemma refa193_not1721 : ~ @Equation1721 Fin3 refa193_inst.
Proof. unfold Equation1721. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa193_inst, refa193_op in H. discriminate H. Qed.

Lemma refa193_not1728 : ~ @Equation1728 Fin3 refa193_inst.
Proof. unfold Equation1728. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa193_inst, refa193_op in H. discriminate H. Qed.

Lemma refa193_not1833 : ~ @Equation1833 Fin3 refa193_inst.
Proof. unfold Equation1833. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa193_inst, refa193_op in H. discriminate H. Qed.

Lemma refa193_not1834 : ~ @Equation1834 Fin3 refa193_inst.
Proof. unfold Equation1834. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa193_inst, refa193_op in H. discriminate H. Qed.

Lemma refa193_not1837 : ~ @Equation1837 Fin3 refa193_inst.
Proof. unfold Equation1837. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa193_inst, refa193_op in H. discriminate H. Qed.

Lemma refa193_not1840 : ~ @Equation1840 Fin3 refa193_inst.
Proof. unfold Equation1840. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa193_inst, refa193_op in H. discriminate H. Qed.

Lemma refa193_not1841 : ~ @Equation1841 Fin3 refa193_inst.
Proof. unfold Equation1841. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa193_inst, refa193_op in H. discriminate H. Qed.

Lemma refa193_not1847 : ~ @Equation1847 Fin3 refa193_inst.
Proof. unfold Equation1847. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa193_inst, refa193_op in H. discriminate H. Qed.

Lemma refa193_not1848 : ~ @Equation1848 Fin3 refa193_inst.
Proof. unfold Equation1848. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa193_inst, refa193_op in H. discriminate H. Qed.

Lemma refa193_not1851 : ~ @Equation1851 Fin3 refa193_inst.
Proof. unfold Equation1851. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa193_inst, refa193_op in H. discriminate H. Qed.

Lemma refa193_not1858 : ~ @Equation1858 Fin3 refa193_inst.
Proof. unfold Equation1858. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa193_inst, refa193_op in H. discriminate H. Qed.

Lemma refa193_not1860 : ~ @Equation1860 Fin3 refa193_inst.
Proof. unfold Equation1860. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa193_inst, refa193_op in H. discriminate H. Qed.

Lemma refa193_not1888 : ~ @Equation1888 Fin3 refa193_inst.
Proof. unfold Equation1888. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa193_inst, refa193_op in H. discriminate H. Qed.

Lemma refa193_not1895 : ~ @Equation1895 Fin3 refa193_inst.
Proof. unfold Equation1895. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa193_inst, refa193_op in H. discriminate H. Qed.

Lemma refa193_not1897 : ~ @Equation1897 Fin3 refa193_inst.
Proof. unfold Equation1897. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa193_inst, refa193_op in H. discriminate H. Qed.

Lemma refa193_not1921 : ~ @Equation1921 Fin3 refa193_inst.
Proof. unfold Equation1921. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa193_inst, refa193_op in H. discriminate H. Qed.

Lemma refa193_not1924 : ~ @Equation1924 Fin3 refa193_inst.
Proof. unfold Equation1924. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa193_inst, refa193_op in H. discriminate H. Qed.

Lemma refa193_not1925 : ~ @Equation1925 Fin3 refa193_inst.
Proof. unfold Equation1925. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa193_inst, refa193_op in H. discriminate H. Qed.

Lemma refa193_not1931 : ~ @Equation1931 Fin3 refa193_inst.
Proof. unfold Equation1931. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa193_inst, refa193_op in H. discriminate H. Qed.

Lemma refa193_not2035 : ~ @Equation2035 Fin3 refa193_inst.
Proof. unfold Equation2035. intro H. specialize (H F3_1). unfold magma_op, refa193_inst, refa193_op in H. discriminate H. Qed.

Lemma refa193_not2238 : ~ @Equation2238 Fin3 refa193_inst.
Proof. unfold Equation2238. intro H. specialize (H F3_1). unfold magma_op, refa193_inst, refa193_op in H. discriminate H. Qed.

Lemma refa193_not2443 : ~ @Equation2443 Fin3 refa193_inst.
Proof. unfold Equation2443. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa193_inst, refa193_op in H. discriminate H. Qed.

Lemma refa193_not2446 : ~ @Equation2446 Fin3 refa193_inst.
Proof. unfold Equation2446. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa193_inst, refa193_op in H. discriminate H. Qed.

Lemma refa193_not2447 : ~ @Equation2447 Fin3 refa193_inst.
Proof. unfold Equation2447. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa193_inst, refa193_op in H. discriminate H. Qed.

Lemma refa193_not2459 : ~ @Equation2459 Fin3 refa193_inst.
Proof. unfold Equation2459. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa193_inst, refa193_op in H. discriminate H. Qed.

Lemma refa193_not2460 : ~ @Equation2460 Fin3 refa193_inst.
Proof. unfold Equation2460. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa193_inst, refa193_op in H. discriminate H. Qed.

Lemma refa193_not2467 : ~ @Equation2467 Fin3 refa193_inst.
Proof. unfold Equation2467. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa193_inst, refa193_op in H. discriminate H. Qed.

Lemma refa193_not2469 : ~ @Equation2469 Fin3 refa193_inst.
Proof. unfold Equation2469. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa193_inst, refa193_op in H. discriminate H. Qed.

Lemma refa193_not2497 : ~ @Equation2497 Fin3 refa193_inst.
Proof. unfold Equation2497. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa193_inst, refa193_op in H. discriminate H. Qed.

Lemma refa193_not2503 : ~ @Equation2503 Fin3 refa193_inst.
Proof. unfold Equation2503. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa193_inst, refa193_op in H. discriminate H. Qed.

Lemma refa193_not2506 : ~ @Equation2506 Fin3 refa193_inst.
Proof. unfold Equation2506. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa193_inst, refa193_op in H. discriminate H. Qed.

Lemma refa193_not2531 : ~ @Equation2531 Fin3 refa193_inst.
Proof. unfold Equation2531. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa193_inst, refa193_op in H. discriminate H. Qed.

Lemma refa193_not2533 : ~ @Equation2533 Fin3 refa193_inst.
Proof. unfold Equation2533. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa193_inst, refa193_op in H. discriminate H. Qed.

Lemma refa193_not2540 : ~ @Equation2540 Fin3 refa193_inst.
Proof. unfold Equation2540. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa193_inst, refa193_op in H. discriminate H. Qed.

Lemma refa193_not2541 : ~ @Equation2541 Fin3 refa193_inst.
Proof. unfold Equation2541. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa193_inst, refa193_op in H. discriminate H. Qed.

Lemma refa193_not2646 : ~ @Equation2646 Fin3 refa193_inst.
Proof. unfold Equation2646. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa193_inst, refa193_op in H. discriminate H. Qed.

Lemma refa193_not2650 : ~ @Equation2650 Fin3 refa193_inst.
Proof. unfold Equation2650. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa193_inst, refa193_op in H. discriminate H. Qed.

Lemma refa193_not2659 : ~ @Equation2659 Fin3 refa193_inst.
Proof. unfold Equation2659. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa193_inst, refa193_op in H. discriminate H. Qed.

Lemma refa193_not2660 : ~ @Equation2660 Fin3 refa193_inst.
Proof. unfold Equation2660. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa193_inst, refa193_op in H. discriminate H. Qed.

Lemma refa193_not2669 : ~ @Equation2669 Fin3 refa193_inst.
Proof. unfold Equation2669. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa193_inst, refa193_op in H. discriminate H. Qed.

Lemma refa193_not2672 : ~ @Equation2672 Fin3 refa193_inst.
Proof. unfold Equation2672. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa193_inst, refa193_op in H. discriminate H. Qed.

Lemma refa193_not2699 : ~ @Equation2699 Fin3 refa193_inst.
Proof. unfold Equation2699. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa193_inst, refa193_op in H. discriminate H. Qed.

Lemma refa193_not2700 : ~ @Equation2700 Fin3 refa193_inst.
Proof. unfold Equation2700. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa193_inst, refa193_op in H. discriminate H. Qed.

Lemma refa193_not2709 : ~ @Equation2709 Fin3 refa193_inst.
Proof. unfold Equation2709. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa193_inst, refa193_op in H. discriminate H. Qed.

Lemma refa193_not2734 : ~ @Equation2734 Fin3 refa193_inst.
Proof. unfold Equation2734. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa193_inst, refa193_op in H. discriminate H. Qed.

Lemma refa193_not2736 : ~ @Equation2736 Fin3 refa193_inst.
Proof. unfold Equation2736. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa193_inst, refa193_op in H. discriminate H. Qed.

Lemma refa193_not2743 : ~ @Equation2743 Fin3 refa193_inst.
Proof. unfold Equation2743. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa193_inst, refa193_op in H. discriminate H. Qed.

Lemma refa193_not2744 : ~ @Equation2744 Fin3 refa193_inst.
Proof. unfold Equation2744. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa193_inst, refa193_op in H. discriminate H. Qed.

Lemma refa193_not2847 : ~ @Equation2847 Fin3 refa193_inst.
Proof. unfold Equation2847. intro H. specialize (H F3_1). unfold magma_op, refa193_inst, refa193_op in H. discriminate H. Qed.

Lemma refa193_not3052 : ~ @Equation3052 Fin3 refa193_inst.
Proof. unfold Equation3052. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa193_inst, refa193_op in H. discriminate H. Qed.

Lemma refa193_not3055 : ~ @Equation3055 Fin3 refa193_inst.
Proof. unfold Equation3055. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa193_inst, refa193_op in H. discriminate H. Qed.

Lemma refa193_not3056 : ~ @Equation3056 Fin3 refa193_inst.
Proof. unfold Equation3056. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa193_inst, refa193_op in H. discriminate H. Qed.

Lemma refa193_not3065 : ~ @Equation3065 Fin3 refa193_inst.
Proof. unfold Equation3065. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa193_inst, refa193_op in H. discriminate H. Qed.

Lemma refa193_not3068 : ~ @Equation3068 Fin3 refa193_inst.
Proof. unfold Equation3068. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa193_inst, refa193_op in H. discriminate H. Qed.

Lemma refa193_not3069 : ~ @Equation3069 Fin3 refa193_inst.
Proof. unfold Equation3069. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa193_inst, refa193_op in H. discriminate H. Qed.

Lemma refa193_not3076 : ~ @Equation3076 Fin3 refa193_inst.
Proof. unfold Equation3076. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa193_inst, refa193_op in H. discriminate H. Qed.

Lemma refa193_not3106 : ~ @Equation3106 Fin3 refa193_inst.
Proof. unfold Equation3106. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa193_inst, refa193_op in H. discriminate H. Qed.

Lemma refa193_not3112 : ~ @Equation3112 Fin3 refa193_inst.
Proof. unfold Equation3112. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa193_inst, refa193_op in H. discriminate H. Qed.

Lemma refa193_not3115 : ~ @Equation3115 Fin3 refa193_inst.
Proof. unfold Equation3115. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa193_inst, refa193_op in H. discriminate H. Qed.

Lemma refa193_not3116 : ~ @Equation3116 Fin3 refa193_inst.
Proof. unfold Equation3116. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa193_inst, refa193_op in H. discriminate H. Qed.

Lemma refa193_not3140 : ~ @Equation3140 Fin3 refa193_inst.
Proof. unfold Equation3140. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa193_inst, refa193_op in H. discriminate H. Qed.

Lemma refa193_not3142 : ~ @Equation3142 Fin3 refa193_inst.
Proof. unfold Equation3142. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa193_inst, refa193_op in H. discriminate H. Qed.

Lemma refa193_not3149 : ~ @Equation3149 Fin3 refa193_inst.
Proof. unfold Equation3149. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa193_inst, refa193_op in H. discriminate H. Qed.

Lemma refa193_not3150 : ~ @Equation3150 Fin3 refa193_inst.
Proof. unfold Equation3150. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa193_inst, refa193_op in H. discriminate H. Qed.

Lemma refa193_not3253 : ~ @Equation3253 Fin3 refa193_inst.
Proof. unfold Equation3253. intro H. specialize (H F3_1). unfold magma_op, refa193_inst, refa193_op in H. discriminate H. Qed.

Lemma refa193_not3457 : ~ @Equation3457 Fin3 refa193_inst.
Proof. unfold Equation3457. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa193_inst, refa193_op in H. discriminate H. Qed.

Lemma refa193_not3458 : ~ @Equation3458 Fin3 refa193_inst.
Proof. unfold Equation3458. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa193_inst, refa193_op in H. discriminate H. Qed.

Lemma refa193_not3461 : ~ @Equation3461 Fin3 refa193_inst.
Proof. unfold Equation3461. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa193_inst, refa193_op in H. discriminate H. Qed.

Lemma refa193_not3462 : ~ @Equation3462 Fin3 refa193_inst.
Proof. unfold Equation3462. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa193_inst, refa193_op in H. discriminate H. Qed.

Lemma refa193_not3465 : ~ @Equation3465 Fin3 refa193_inst.
Proof. unfold Equation3465. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa193_inst, refa193_op in H. discriminate H. Qed.

Lemma refa193_not3474 : ~ @Equation3474 Fin3 refa193_inst.
Proof. unfold Equation3474. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa193_inst, refa193_op in H. discriminate H. Qed.

Lemma refa193_not3475 : ~ @Equation3475 Fin3 refa193_inst.
Proof. unfold Equation3475. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa193_inst, refa193_op in H. discriminate H. Qed.

Lemma refa193_not3482 : ~ @Equation3482 Fin3 refa193_inst.
Proof. unfold Equation3482. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa193_inst, refa193_op in H. discriminate H. Qed.

Lemma refa193_not3484 : ~ @Equation3484 Fin3 refa193_inst.
Proof. unfold Equation3484. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa193_inst, refa193_op in H. discriminate H. Qed.

Lemma refa193_not3511 : ~ @Equation3511 Fin3 refa193_inst.
Proof. unfold Equation3511. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa193_inst, refa193_op in H. discriminate H. Qed.

Lemma refa193_not3512 : ~ @Equation3512 Fin3 refa193_inst.
Proof. unfold Equation3512. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa193_inst, refa193_op in H. discriminate H. Qed.

Lemma refa193_not3519 : ~ @Equation3519 Fin3 refa193_inst.
Proof. unfold Equation3519. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa193_inst, refa193_op in H. discriminate H. Qed.

Lemma refa193_not3521 : ~ @Equation3521 Fin3 refa193_inst.
Proof. unfold Equation3521. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa193_inst, refa193_op in H. discriminate H. Qed.

Lemma refa193_not3545 : ~ @Equation3545 Fin3 refa193_inst.
Proof. unfold Equation3545. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa193_inst, refa193_op in H. discriminate H. Qed.

Lemma refa193_not3546 : ~ @Equation3546 Fin3 refa193_inst.
Proof. unfold Equation3546. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa193_inst, refa193_op in H. discriminate H. Qed.

Lemma refa193_not3549 : ~ @Equation3549 Fin3 refa193_inst.
Proof. unfold Equation3549. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa193_inst, refa193_op in H. discriminate H. Qed.

Lemma refa193_not3555 : ~ @Equation3555 Fin3 refa193_inst.
Proof. unfold Equation3555. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa193_inst, refa193_op in H. discriminate H. Qed.

Lemma refa193_not3558 : ~ @Equation3558 Fin3 refa193_inst.
Proof. unfold Equation3558. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa193_inst, refa193_op in H. discriminate H. Qed.

Lemma refa193_not3660 : ~ @Equation3660 Fin3 refa193_inst.
Proof. unfold Equation3660. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa193_inst, refa193_op in H. discriminate H. Qed.

Lemma refa193_not3661 : ~ @Equation3661 Fin3 refa193_inst.
Proof. unfold Equation3661. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa193_inst, refa193_op in H. discriminate H. Qed.

Lemma refa193_not3664 : ~ @Equation3664 Fin3 refa193_inst.
Proof. unfold Equation3664. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa193_inst, refa193_op in H. discriminate H. Qed.

Lemma refa193_not3667 : ~ @Equation3667 Fin3 refa193_inst.
Proof. unfold Equation3667. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa193_inst, refa193_op in H. discriminate H. Qed.

Lemma refa193_not3668 : ~ @Equation3668 Fin3 refa193_inst.
Proof. unfold Equation3668. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa193_inst, refa193_op in H. discriminate H. Qed.

Lemma refa193_not3674 : ~ @Equation3674 Fin3 refa193_inst.
Proof. unfold Equation3674. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa193_inst, refa193_op in H. discriminate H. Qed.

Lemma refa193_not3675 : ~ @Equation3675 Fin3 refa193_inst.
Proof. unfold Equation3675. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa193_inst, refa193_op in H. discriminate H. Qed.

Lemma refa193_not3678 : ~ @Equation3678 Fin3 refa193_inst.
Proof. unfold Equation3678. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa193_inst, refa193_op in H. discriminate H. Qed.

Lemma refa193_not3685 : ~ @Equation3685 Fin3 refa193_inst.
Proof. unfold Equation3685. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa193_inst, refa193_op in H. discriminate H. Qed.

Lemma refa193_not3687 : ~ @Equation3687 Fin3 refa193_inst.
Proof. unfold Equation3687. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa193_inst, refa193_op in H. discriminate H. Qed.

Lemma refa193_not3714 : ~ @Equation3714 Fin3 refa193_inst.
Proof. unfold Equation3714. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa193_inst, refa193_op in H. discriminate H. Qed.

Lemma refa193_not3721 : ~ @Equation3721 Fin3 refa193_inst.
Proof. unfold Equation3721. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa193_inst, refa193_op in H. discriminate H. Qed.

Lemma refa193_not3722 : ~ @Equation3722 Fin3 refa193_inst.
Proof. unfold Equation3722. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa193_inst, refa193_op in H. discriminate H. Qed.

Lemma refa193_not3725 : ~ @Equation3725 Fin3 refa193_inst.
Proof. unfold Equation3725. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa193_inst, refa193_op in H. discriminate H. Qed.

Lemma refa193_not3749 : ~ @Equation3749 Fin3 refa193_inst.
Proof. unfold Equation3749. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa193_inst, refa193_op in H. discriminate H. Qed.

Lemma refa193_not3761 : ~ @Equation3761 Fin3 refa193_inst.
Proof. unfold Equation3761. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa193_inst, refa193_op in H. discriminate H. Qed.

Lemma refa193_not3862 : ~ @Equation3862 Fin3 refa193_inst.
Proof. unfold Equation3862. intro H. specialize (H F3_1). unfold magma_op, refa193_inst, refa193_op in H. discriminate H. Qed.

Lemma refa193_not4066 : ~ @Equation4066 Fin3 refa193_inst.
Proof. unfold Equation4066. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa193_inst, refa193_op in H. discriminate H. Qed.

Lemma refa193_not4067 : ~ @Equation4067 Fin3 refa193_inst.
Proof. unfold Equation4067. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa193_inst, refa193_op in H. discriminate H. Qed.

Lemma refa193_not4070 : ~ @Equation4070 Fin3 refa193_inst.
Proof. unfold Equation4070. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa193_inst, refa193_op in H. discriminate H. Qed.

Lemma refa193_not4071 : ~ @Equation4071 Fin3 refa193_inst.
Proof. unfold Equation4071. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa193_inst, refa193_op in H. discriminate H. Qed.

Lemma refa193_not4074 : ~ @Equation4074 Fin3 refa193_inst.
Proof. unfold Equation4074. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa193_inst, refa193_op in H. discriminate H. Qed.

Lemma refa193_not4083 : ~ @Equation4083 Fin3 refa193_inst.
Proof. unfold Equation4083. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa193_inst, refa193_op in H. discriminate H. Qed.

Lemma refa193_not4084 : ~ @Equation4084 Fin3 refa193_inst.
Proof. unfold Equation4084. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa193_inst, refa193_op in H. discriminate H. Qed.

Lemma refa193_not4091 : ~ @Equation4091 Fin3 refa193_inst.
Proof. unfold Equation4091. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa193_inst, refa193_op in H. discriminate H. Qed.

Lemma refa193_not4093 : ~ @Equation4093 Fin3 refa193_inst.
Proof. unfold Equation4093. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa193_inst, refa193_op in H. discriminate H. Qed.

Lemma refa193_not4120 : ~ @Equation4120 Fin3 refa193_inst.
Proof. unfold Equation4120. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa193_inst, refa193_op in H. discriminate H. Qed.

Lemma refa193_not4121 : ~ @Equation4121 Fin3 refa193_inst.
Proof. unfold Equation4121. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa193_inst, refa193_op in H. discriminate H. Qed.

Lemma refa193_not4128 : ~ @Equation4128 Fin3 refa193_inst.
Proof. unfold Equation4128. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa193_inst, refa193_op in H. discriminate H. Qed.

Lemma refa193_not4130 : ~ @Equation4130 Fin3 refa193_inst.
Proof. unfold Equation4130. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa193_inst, refa193_op in H. discriminate H. Qed.

Lemma refa193_not4155 : ~ @Equation4155 Fin3 refa193_inst.
Proof. unfold Equation4155. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa193_inst, refa193_op in H. discriminate H. Qed.

Lemma refa193_not4158 : ~ @Equation4158 Fin3 refa193_inst.
Proof. unfold Equation4158. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa193_inst, refa193_op in H. discriminate H. Qed.

Lemma refa193_not4164 : ~ @Equation4164 Fin3 refa193_inst.
Proof. unfold Equation4164. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa193_inst, refa193_op in H. discriminate H. Qed.

Lemma refa193_not4167 : ~ @Equation4167 Fin3 refa193_inst.
Proof. unfold Equation4167. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa193_inst, refa193_op in H. discriminate H. Qed.

Lemma refa193_not4268 : ~ @Equation4268 Fin3 refa193_inst.
Proof. unfold Equation4268. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa193_inst, refa193_op in H. discriminate H. Qed.

Lemma refa193_not4269 : ~ @Equation4269 Fin3 refa193_inst.
Proof. unfold Equation4269. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa193_inst, refa193_op in H. discriminate H. Qed.

Lemma refa193_not4272 : ~ @Equation4272 Fin3 refa193_inst.
Proof. unfold Equation4272. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa193_inst, refa193_op in H. discriminate H. Qed.

Lemma refa193_not4275 : ~ @Equation4275 Fin3 refa193_inst.
Proof. unfold Equation4275. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa193_inst, refa193_op in H. discriminate H. Qed.

Lemma refa193_not4276 : ~ @Equation4276 Fin3 refa193_inst.
Proof. unfold Equation4276. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa193_inst, refa193_op in H. discriminate H. Qed.

Lemma refa193_not4283 : ~ @Equation4283 Fin3 refa193_inst.
Proof. unfold Equation4283. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa193_inst, refa193_op in H. discriminate H. Qed.

Lemma refa193_not4284 : ~ @Equation4284 Fin3 refa193_inst.
Proof. unfold Equation4284. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa193_inst, refa193_op in H. discriminate H. Qed.

Lemma refa193_not4290 : ~ @Equation4290 Fin3 refa193_inst.
Proof. unfold Equation4290. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa193_inst, refa193_op in H. discriminate H. Qed.

Lemma refa193_not4291 : ~ @Equation4291 Fin3 refa193_inst.
Proof. unfold Equation4291. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa193_inst, refa193_op in H. discriminate H. Qed.

Lemma refa193_not4314 : ~ @Equation4314 Fin3 refa193_inst.
Proof. unfold Equation4314. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa193_inst, refa193_op in H. discriminate H. Qed.

Lemma refa193_not4321 : ~ @Equation4321 Fin3 refa193_inst.
Proof. unfold Equation4321. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa193_inst, refa193_op in H. discriminate H. Qed.

Lemma refa193_not4343 : ~ @Equation4343 Fin3 refa193_inst.
Proof. unfold Equation4343. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa193_inst, refa193_op in H. discriminate H. Qed.

Lemma refa193_not4380 : ~ @Equation4380 Fin3 refa193_inst.
Proof. unfold Equation4380. intro H. specialize (H F3_1). unfold magma_op, refa193_inst, refa193_op in H. discriminate H. Qed.

Lemma refa193_not4583 : ~ @Equation4583 Fin3 refa193_inst.
Proof. unfold Equation4583. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa193_inst, refa193_op in H. discriminate H. Qed.

Lemma refa193_not4584 : ~ @Equation4584 Fin3 refa193_inst.
Proof. unfold Equation4584. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa193_inst, refa193_op in H. discriminate H. Qed.

Lemma refa193_not4587 : ~ @Equation4587 Fin3 refa193_inst.
Proof. unfold Equation4587. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa193_inst, refa193_op in H. discriminate H. Qed.

Lemma refa193_not4588 : ~ @Equation4588 Fin3 refa193_inst.
Proof. unfold Equation4588. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa193_inst, refa193_op in H. discriminate H. Qed.

Lemma refa193_not4591 : ~ @Equation4591 Fin3 refa193_inst.
Proof. unfold Equation4591. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa193_inst, refa193_op in H. discriminate H. Qed.

Lemma refa193_not4598 : ~ @Equation4598 Fin3 refa193_inst.
Proof. unfold Equation4598. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa193_inst, refa193_op in H. discriminate H. Qed.

Lemma refa193_not4599 : ~ @Equation4599 Fin3 refa193_inst.
Proof. unfold Equation4599. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa193_inst, refa193_op in H. discriminate H. Qed.

Lemma refa193_not4606 : ~ @Equation4606 Fin3 refa193_inst.
Proof. unfold Equation4606. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa193_inst, refa193_op in H. discriminate H. Qed.

Lemma refa193_not4608 : ~ @Equation4608 Fin3 refa193_inst.
Proof. unfold Equation4608. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa193_inst, refa193_op in H. discriminate H. Qed.

Lemma refa193_not4629 : ~ @Equation4629 Fin3 refa193_inst.
Proof. unfold Equation4629. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa193_inst, refa193_op in H. discriminate H. Qed.

Lemma refa193_not4635 : ~ @Equation4635 Fin3 refa193_inst.
Proof. unfold Equation4635. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa193_inst, refa193_op in H. discriminate H. Qed.

Lemma refa193_not4658 : ~ @Equation4658 Fin3 refa193_inst.
Proof. unfold Equation4658. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa193_inst, refa193_op in H. discriminate H. Qed.

(** ---- refa194 (Fin3) ---- *)

Definition refa194_op (x y : Fin3) : Fin3 :=
  match x, y with
  | F3_0, F3_0 => F3_0 | F3_0, F3_1 => F3_1 | F3_0, F3_2 => F3_2
  | F3_1, F3_0 => F3_1 | F3_1, F3_1 => F3_0 | F3_1, F3_2 => F3_1
  | F3_2, F3_0 => F3_2 | F3_2, F3_1 => F3_2 | F3_2, F3_2 => F3_0
  end.

#[local] Instance refa194_inst : Magma Fin3 := {| magma_op := refa194_op |}.

Lemma refa194_sat2688 : @Equation2688 Fin3 refa194_inst.
Proof. unfold Equation2688, magma_op, refa194_inst, refa194_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa194_sat3011 : @Equation3011 Fin3 refa194_inst.
Proof. unfold Equation3011, magma_op, refa194_inst, refa194_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa194_sat3214 : @Equation3214 Fin3 refa194_inst.
Proof. unfold Equation3214, magma_op, refa194_inst, refa194_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa194_sat4477 : @Equation4477 Fin3 refa194_inst.
Proof. unfold Equation4477, magma_op, refa194_inst, refa194_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa194_not2041 : ~ @Equation2041 Fin3 refa194_inst.
Proof. unfold Equation2041. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa194_inst, refa194_op in H. discriminate H. Qed.

Lemma refa194_not2043 : ~ @Equation2043 Fin3 refa194_inst.
Proof. unfold Equation2043. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa194_inst, refa194_op in H. discriminate H. Qed.

Lemma refa194_not2053 : ~ @Equation2053 Fin3 refa194_inst.
Proof. unfold Equation2053. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa194_inst, refa194_op in H. discriminate H. Qed.

Lemma refa194_not2650 : ~ @Equation2650 Fin3 refa194_inst.
Proof. unfold Equation2650. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa194_inst, refa194_op in H. discriminate H. Qed.

Lemma refa194_not2669 : ~ @Equation2669 Fin3 refa194_inst.
Proof. unfold Equation2669. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa194_inst, refa194_op in H. discriminate H. Qed.

Lemma refa194_not2855 : ~ @Equation2855 Fin3 refa194_inst.
Proof. unfold Equation2855. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa194_inst, refa194_op in H. discriminate H. Qed.

Lemma refa194_not2863 : ~ @Equation2863 Fin3 refa194_inst.
Proof. unfold Equation2863. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa194_inst, refa194_op in H. discriminate H. Qed.

Lemma refa194_not2865 : ~ @Equation2865 Fin3 refa194_inst.
Proof. unfold Equation2865. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa194_inst, refa194_op in H. discriminate H. Qed.

Lemma refa194_not2909 : ~ @Equation2909 Fin3 refa194_inst.
Proof. unfold Equation2909. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa194_inst, refa194_op in H. discriminate H. Qed.

Lemma refa194_not2936 : ~ @Equation2936 Fin3 refa194_inst.
Proof. unfold Equation2936. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa194_inst, refa194_op in H. discriminate H. Qed.

Lemma refa194_not3068 : ~ @Equation3068 Fin3 refa194_inst.
Proof. unfold Equation3068. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa194_inst, refa194_op in H. discriminate H. Qed.

Lemma refa194_not3112 : ~ @Equation3112 Fin3 refa194_inst.
Proof. unfold Equation3112. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa194_inst, refa194_op in H. discriminate H. Qed.

Lemma refa194_not3259 : ~ @Equation3259 Fin3 refa194_inst.
Proof. unfold Equation3259. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa194_inst, refa194_op in H. discriminate H. Qed.

Lemma refa194_not3261 : ~ @Equation3261 Fin3 refa194_inst.
Proof. unfold Equation3261. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa194_inst, refa194_op in H. discriminate H. Qed.

Lemma refa194_not3271 : ~ @Equation3271 Fin3 refa194_inst.
Proof. unfold Equation3271. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa194_inst, refa194_op in H. discriminate H. Qed.

Lemma refa194_not3308 : ~ @Equation3308 Fin3 refa194_inst.
Proof. unfold Equation3308. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa194_inst, refa194_op in H. discriminate H. Qed.

Lemma refa194_not3462 : ~ @Equation3462 Fin3 refa194_inst.
Proof. unfold Equation3462. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa194_inst, refa194_op in H. discriminate H. Qed.

Lemma refa194_not3474 : ~ @Equation3474 Fin3 refa194_inst.
Proof. unfold Equation3474. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa194_inst, refa194_op in H. discriminate H. Qed.

Lemma refa194_not3667 : ~ @Equation3667 Fin3 refa194_inst.
Proof. unfold Equation3667. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa194_inst, refa194_op in H. discriminate H. Qed.

Lemma refa194_not4283 : ~ @Equation4283 Fin3 refa194_inst.
Proof. unfold Equation4283. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa194_inst, refa194_op in H. discriminate H. Qed.

Lemma refa194_not4320 : ~ @Equation4320 Fin3 refa194_inst.
Proof. unfold Equation4320. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa194_inst, refa194_op in H. discriminate H. Qed.

Lemma refa194_not4598 : ~ @Equation4598 Fin3 refa194_inst.
Proof. unfold Equation4598. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa194_inst, refa194_op in H. discriminate H. Qed.

(** ---- refa195 (Fin3) ---- *)

Definition refa195_op (x y : Fin3) : Fin3 :=
  match x, y with
  | F3_0, F3_0 => F3_0 | F3_0, F3_1 => F3_0 | F3_0, F3_2 => F3_1
  | F3_1, F3_0 => F3_0 | F3_1, F3_1 => F3_0 | F3_1, F3_2 => F3_2
  | F3_2, F3_0 => F3_0 | F3_2, F3_1 => F3_0 | F3_2, F3_2 => F3_0
  end.

#[local] Instance refa195_inst : Magma Fin3 := {| magma_op := refa195_op |}.

Lemma refa195_sat3493 : @Equation3493 Fin3 refa195_inst.
Proof. unfold Equation3493, magma_op, refa195_inst, refa195_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa195_sat3498 : @Equation3498 Fin3 refa195_inst.
Proof. unfold Equation3498, magma_op, refa195_inst, refa195_op. intros x y z w. destruct x, y, z, w; reflexivity. Qed.

Lemma refa195_sat4331 : @Equation4331 Fin3 refa195_inst.
Proof. unfold Equation4331, magma_op, refa195_inst, refa195_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa195_not3459 : ~ @Equation3459 Fin3 refa195_inst.
Proof. unfold Equation3459. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa195_inst, refa195_op in H. discriminate H. Qed.

Lemma refa195_not3481 : ~ @Equation3481 Fin3 refa195_inst.
Proof. unfold Equation3481. intro H. specialize (H F3_2 F3_0). unfold magma_op, refa195_inst, refa195_op in H. discriminate H. Qed.

Lemma refa195_not3660 : ~ @Equation3660 Fin3 refa195_inst.
Proof. unfold Equation3660. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa195_inst, refa195_op in H. discriminate H. Qed.

Lemma refa195_not3661 : ~ @Equation3661 Fin3 refa195_inst.
Proof. unfold Equation3661. intro H. specialize (H F3_2 F3_1). unfold magma_op, refa195_inst, refa195_op in H. discriminate H. Qed.

Lemma refa195_not3667 : ~ @Equation3667 Fin3 refa195_inst.
Proof. unfold Equation3667. intro H. specialize (H F3_2 F3_1). unfold magma_op, refa195_inst, refa195_op in H. discriminate H. Qed.

Lemma refa195_not3675 : ~ @Equation3675 Fin3 refa195_inst.
Proof. unfold Equation3675. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa195_inst, refa195_op in H. discriminate H. Qed.

Lemma refa195_not3685 : ~ @Equation3685 Fin3 refa195_inst.
Proof. unfold Equation3685. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa195_inst, refa195_op in H. discriminate H. Qed.

Lemma refa195_not3687 : ~ @Equation3687 Fin3 refa195_inst.
Proof. unfold Equation3687. intro H. specialize (H F3_2 F3_1). unfold magma_op, refa195_inst, refa195_op in H. discriminate H. Qed.

Lemma refa195_not4362 : ~ @Equation4362 Fin3 refa195_inst.
Proof. unfold Equation4362. intro H. specialize (H F3_0 F3_1 F3_2). unfold magma_op, refa195_inst, refa195_op in H. discriminate H. Qed.

(** ---- refa196 (Fin3) ---- *)

Definition refa196_op (x y : Fin3) : Fin3 :=
  match x, y with
  | F3_0, F3_0 => F3_0 | F3_0, F3_1 => F3_1 | F3_0, F3_2 => F3_1
  | F3_1, F3_0 => F3_1 | F3_1, F3_1 => F3_0 | F3_1, F3_2 => F3_1
  | F3_2, F3_0 => F3_2 | F3_2, F3_1 => F3_0 | F3_2, F3_2 => F3_0
  end.

#[local] Instance refa196_inst : Magma Fin3 := {| magma_op := refa196_op |}.

Lemma refa196_sat658 : @Equation658 Fin3 refa196_inst.
Proof. unfold Equation658, magma_op, refa196_inst, refa196_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa196_not1023 : ~ @Equation1023 Fin3 refa196_inst.
Proof. unfold Equation1023. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa196_inst, refa196_op in H. discriminate H. Qed.

Lemma refa196_not1223 : ~ @Equation1223 Fin3 refa196_inst.
Proof. unfold Equation1223. intro H. specialize (H F3_2). unfold magma_op, refa196_inst, refa196_op in H. discriminate H. Qed.

Lemma refa196_not4065 : ~ @Equation4065 Fin3 refa196_inst.
Proof. unfold Equation4065. intro H. specialize (H F3_2). unfold magma_op, refa196_inst, refa196_op in H. discriminate H. Qed.

Lemma refa196_not4380 : ~ @Equation4380 Fin3 refa196_inst.
Proof. unfold Equation4380. intro H. specialize (H F3_2). unfold magma_op, refa196_inst, refa196_op in H. discriminate H. Qed.

Lemma refa196_not4656 : ~ @Equation4656 Fin3 refa196_inst.
Proof. unfold Equation4656. intro H. specialize (H F3_0 F3_0 F3_2). unfold magma_op, refa196_inst, refa196_op in H. discriminate H. Qed.

(** ---- refa197 (Fin3) ---- *)

Definition refa197_op (x y : Fin3) : Fin3 :=
  match x, y with
  | F3_0, F3_0 => F3_0 | F3_0, F3_1 => F3_2 | F3_0, F3_2 => F3_1
  | F3_1, F3_0 => F3_0 | F3_1, F3_1 => F3_2 | F3_1, F3_2 => F3_0
  | F3_2, F3_0 => F3_2 | F3_2, F3_1 => F3_1 | F3_2, F3_2 => F3_1
  end.

#[local] Instance refa197_inst : Magma Fin3 := {| magma_op := refa197_op |}.

Lemma refa197_sat1897 : @Equation1897 Fin3 refa197_inst.
Proof. unfold Equation1897, magma_op, refa197_inst, refa197_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa197_not1629 : ~ @Equation1629 Fin3 refa197_inst.
Proof. unfold Equation1629. intro H. specialize (H F3_2). unfold magma_op, refa197_inst, refa197_op in H. discriminate H. Qed.

Lemma refa197_not3862 : ~ @Equation3862 Fin3 refa197_inst.
Proof. unfold Equation3862. intro H. specialize (H F3_2). unfold magma_op, refa197_inst, refa197_op in H. discriminate H. Qed.

(** ---- refa198 (Fin3) ---- *)

Definition refa198_op (x y : Fin3) : Fin3 :=
  match x, y with
  | F3_0, F3_0 => F3_0 | F3_0, F3_1 => F3_0 | F3_0, F3_2 => F3_0
  | F3_1, F3_0 => F3_1 | F3_1, F3_1 => F3_1 | F3_1, F3_2 => F3_0
  | F3_2, F3_0 => F3_1 | F3_2, F3_1 => F3_2 | F3_2, F3_2 => F3_2
  end.

#[local] Instance refa198_inst : Magma Fin3 := {| magma_op := refa198_op |}.

Lemma refa198_sat829 : @Equation829 Fin3 refa198_inst.
Proof. unfold Equation829, magma_op, refa198_inst, refa198_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa198_not1228 : ~ @Equation1228 Fin3 refa198_inst.
Proof. unfold Equation1228. intro H. specialize (H F3_2 F3_0). unfold magma_op, refa198_inst, refa198_op in H. discriminate H. Qed.

Lemma refa198_not4127 : ~ @Equation4127 Fin3 refa198_inst.
Proof. unfold Equation4127. intro H. specialize (H F3_2 F3_0). unfold magma_op, refa198_inst, refa198_op in H. discriminate H. Qed.

(** ---- refa199 (Fin3) ---- *)

Definition refa199_op (x y : Fin3) : Fin3 :=
  match x, y with
  | F3_0, F3_0 => F3_0 | F3_0, F3_1 => F3_0 | F3_0, F3_2 => F3_2
  | F3_1, F3_0 => F3_1 | F3_1, F3_1 => F3_1 | F3_1, F3_2 => F3_2
  | F3_2, F3_0 => F3_0 | F3_2, F3_1 => F3_0 | F3_2, F3_2 => F3_2
  end.

#[local] Instance refa199_inst : Magma Fin3 := {| magma_op := refa199_op |}.

Lemma refa199_sat3718 : @Equation3718 Fin3 refa199_inst.
Proof. unfold Equation3718, magma_op, refa199_inst, refa199_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa199_sat3939 : @Equation3939 Fin3 refa199_inst.
Proof. unfold Equation3939, magma_op, refa199_inst, refa199_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa199_not3864 : ~ @Equation3864 Fin3 refa199_inst.
Proof. unfold Equation3864. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa199_inst, refa199_op in H. discriminate H. Qed.

Lemma refa199_not3870 : ~ @Equation3870 Fin3 refa199_inst.
Proof. unfold Equation3870. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa199_inst, refa199_op in H. discriminate H. Qed.

Lemma refa199_not4070 : ~ @Equation4070 Fin3 refa199_inst.
Proof. unfold Equation4070. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa199_inst, refa199_op in H. discriminate H. Qed.

Lemma refa199_not4073 : ~ @Equation4073 Fin3 refa199_inst.
Proof. unfold Equation4073. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa199_inst, refa199_op in H. discriminate H. Qed.

(** ---- refa2 (Fin7) ---- *)

Definition refa2_op (x y : Fin7) : Fin7 :=
  match x, y with
  | F7_0, F7_0 => F7_0 | F7_0, F7_1 => F7_2 | F7_0, F7_2 => F7_3 | F7_0, F7_3 => F7_4 | F7_0, F7_4 => F7_5 | F7_0, F7_5 => F7_6 | F7_0, F7_6 => F7_1
  | F7_1, F7_0 => F7_6 | F7_1, F7_1 => F7_1 | F7_1, F7_2 => F7_0 | F7_1, F7_3 => F7_5 | F7_1, F7_4 => F7_2 | F7_1, F7_5 => F7_4 | F7_1, F7_6 => F7_3
  | F7_2, F7_0 => F7_1 | F7_2, F7_1 => F7_4 | F7_2, F7_2 => F7_2 | F7_2, F7_3 => F7_0 | F7_2, F7_4 => F7_6 | F7_2, F7_5 => F7_3 | F7_2, F7_6 => F7_5
  | F7_3, F7_0 => F7_2 | F7_3, F7_1 => F7_6 | F7_3, F7_2 => F7_5 | F7_3, F7_3 => F7_3 | F7_3, F7_4 => F7_0 | F7_3, F7_5 => F7_1 | F7_3, F7_6 => F7_4
  | F7_4, F7_0 => F7_3 | F7_4, F7_1 => F7_5 | F7_4, F7_2 => F7_1 | F7_4, F7_3 => F7_6 | F7_4, F7_4 => F7_4 | F7_4, F7_5 => F7_0 | F7_4, F7_6 => F7_2
  | F7_5, F7_0 => F7_4 | F7_5, F7_1 => F7_3 | F7_5, F7_2 => F7_6 | F7_5, F7_3 => F7_2 | F7_5, F7_4 => F7_1 | F7_5, F7_5 => F7_5 | F7_5, F7_6 => F7_0
  | F7_6, F7_0 => F7_5 | F7_6, F7_1 => F7_0 | F7_6, F7_2 => F7_4 | F7_6, F7_3 => F7_1 | F7_6, F7_4 => F7_3 | F7_6, F7_5 => F7_2 | F7_6, F7_6 => F7_6
  end.

#[local] Instance refa2_inst : Magma Fin7 := {| magma_op := refa2_op |}.

Lemma refa2_sat1119 : @Equation1119 Fin7 refa2_inst.
Proof. unfold Equation1119, magma_op, refa2_inst, refa2_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa2_sat2856 : @Equation2856 Fin7 refa2_inst.
Proof. unfold Equation2856, magma_op, refa2_inst, refa2_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa2_not107 : ~ @Equation107 Fin7 refa2_inst.
Proof. unfold Equation107. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa2_inst, refa2_op in H. discriminate H. Qed.

Lemma refa2_not124 : ~ @Equation124 Fin7 refa2_inst.
Proof. unfold Equation124. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa2_inst, refa2_op in H. discriminate H. Qed.

Lemma refa2_not127 : ~ @Equation127 Fin7 refa2_inst.
Proof. unfold Equation127. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa2_inst, refa2_op in H. discriminate H. Qed.

Lemma refa2_not159 : ~ @Equation159 Fin7 refa2_inst.
Proof. unfold Equation159. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa2_inst, refa2_op in H. discriminate H. Qed.

Lemma refa2_not261 : ~ @Equation261 Fin7 refa2_inst.
Proof. unfold Equation261. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa2_inst, refa2_op in H. discriminate H. Qed.

Lemma refa2_not263 : ~ @Equation263 Fin7 refa2_inst.
Proof. unfold Equation263. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa2_inst, refa2_op in H. discriminate H. Qed.

Lemma refa2_not413 : ~ @Equation413 Fin7 refa2_inst.
Proof. unfold Equation413. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa2_inst, refa2_op in H. discriminate H. Qed.

Lemma refa2_not416 : ~ @Equation416 Fin7 refa2_inst.
Proof. unfold Equation416. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa2_inst, refa2_op in H. discriminate H. Qed.

Lemma refa2_not419 : ~ @Equation419 Fin7 refa2_inst.
Proof. unfold Equation419. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa2_inst, refa2_op in H. discriminate H. Qed.

Lemma refa2_not426 : ~ @Equation426 Fin7 refa2_inst.
Proof. unfold Equation426. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa2_inst, refa2_op in H. discriminate H. Qed.

Lemma refa2_not429 : ~ @Equation429 Fin7 refa2_inst.
Proof. unfold Equation429. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa2_inst, refa2_op in H. discriminate H. Qed.

Lemma refa2_not436 : ~ @Equation436 Fin7 refa2_inst.
Proof. unfold Equation436. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa2_inst, refa2_op in H. discriminate H. Qed.

Lemma refa2_not439 : ~ @Equation439 Fin7 refa2_inst.
Proof. unfold Equation439. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa2_inst, refa2_op in H. discriminate H. Qed.

Lemma refa2_not473 : ~ @Equation473 Fin7 refa2_inst.
Proof. unfold Equation473. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa2_inst, refa2_op in H. discriminate H. Qed.

Lemma refa2_not476 : ~ @Equation476 Fin7 refa2_inst.
Proof. unfold Equation476. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa2_inst, refa2_op in H. discriminate H. Qed.

Lemma refa2_not503 : ~ @Equation503 Fin7 refa2_inst.
Proof. unfold Equation503. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa2_inst, refa2_op in H. discriminate H. Qed.

Lemma refa2_not513 : ~ @Equation513 Fin7 refa2_inst.
Proof. unfold Equation513. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa2_inst, refa2_op in H. discriminate H. Qed.

Lemma refa2_not1022 : ~ @Equation1022 Fin7 refa2_inst.
Proof. unfold Equation1022. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa2_inst, refa2_op in H. discriminate H. Qed.

Lemma refa2_not1025 : ~ @Equation1025 Fin7 refa2_inst.
Proof. unfold Equation1025. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa2_inst, refa2_op in H. discriminate H. Qed.

Lemma refa2_not1028 : ~ @Equation1028 Fin7 refa2_inst.
Proof. unfold Equation1028. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa2_inst, refa2_op in H. discriminate H. Qed.

Lemma refa2_not1035 : ~ @Equation1035 Fin7 refa2_inst.
Proof. unfold Equation1035. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa2_inst, refa2_op in H. discriminate H. Qed.

Lemma refa2_not1045 : ~ @Equation1045 Fin7 refa2_inst.
Proof. unfold Equation1045. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa2_inst, refa2_op in H. discriminate H. Qed.

Lemma refa2_not1048 : ~ @Equation1048 Fin7 refa2_inst.
Proof. unfold Equation1048. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa2_inst, refa2_op in H. discriminate H. Qed.

Lemma refa2_not1082 : ~ @Equation1082 Fin7 refa2_inst.
Proof. unfold Equation1082. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa2_inst, refa2_op in H. discriminate H. Qed.

Lemma refa2_not1085 : ~ @Equation1085 Fin7 refa2_inst.
Proof. unfold Equation1085. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa2_inst, refa2_op in H. discriminate H. Qed.

Lemma refa2_not1109 : ~ @Equation1109 Fin7 refa2_inst.
Proof. unfold Equation1109. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa2_inst, refa2_op in H. discriminate H. Qed.

Lemma refa2_not1112 : ~ @Equation1112 Fin7 refa2_inst.
Proof. unfold Equation1112. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa2_inst, refa2_op in H. discriminate H. Qed.

Lemma refa2_not1122 : ~ @Equation1122 Fin7 refa2_inst.
Proof. unfold Equation1122. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa2_inst, refa2_op in H. discriminate H. Qed.

Lemma refa2_not1225 : ~ @Equation1225 Fin7 refa2_inst.
Proof. unfold Equation1225. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa2_inst, refa2_op in H. discriminate H. Qed.

Lemma refa2_not1228 : ~ @Equation1228 Fin7 refa2_inst.
Proof. unfold Equation1228. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa2_inst, refa2_op in H. discriminate H. Qed.

Lemma refa2_not1231 : ~ @Equation1231 Fin7 refa2_inst.
Proof. unfold Equation1231. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa2_inst, refa2_op in H. discriminate H. Qed.

Lemma refa2_not1238 : ~ @Equation1238 Fin7 refa2_inst.
Proof. unfold Equation1238. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa2_inst, refa2_op in H. discriminate H. Qed.

Lemma refa2_not1248 : ~ @Equation1248 Fin7 refa2_inst.
Proof. unfold Equation1248. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa2_inst, refa2_op in H. discriminate H. Qed.

Lemma refa2_not1251 : ~ @Equation1251 Fin7 refa2_inst.
Proof. unfold Equation1251. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa2_inst, refa2_op in H. discriminate H. Qed.

Lemma refa2_not1278 : ~ @Equation1278 Fin7 refa2_inst.
Proof. unfold Equation1278. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa2_inst, refa2_op in H. discriminate H. Qed.

Lemma refa2_not1285 : ~ @Equation1285 Fin7 refa2_inst.
Proof. unfold Equation1285. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa2_inst, refa2_op in H. discriminate H. Qed.

Lemma refa2_not1288 : ~ @Equation1288 Fin7 refa2_inst.
Proof. unfold Equation1288. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa2_inst, refa2_op in H. discriminate H. Qed.

Lemma refa2_not1312 : ~ @Equation1312 Fin7 refa2_inst.
Proof. unfold Equation1312. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa2_inst, refa2_op in H. discriminate H. Qed.

Lemma refa2_not1315 : ~ @Equation1315 Fin7 refa2_inst.
Proof. unfold Equation1315. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa2_inst, refa2_op in H. discriminate H. Qed.

Lemma refa2_not1322 : ~ @Equation1322 Fin7 refa2_inst.
Proof. unfold Equation1322. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa2_inst, refa2_op in H. discriminate H. Qed.

Lemma refa2_not1631 : ~ @Equation1631 Fin7 refa2_inst.
Proof. unfold Equation1631. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa2_inst, refa2_op in H. discriminate H. Qed.

Lemma refa2_not1634 : ~ @Equation1634 Fin7 refa2_inst.
Proof. unfold Equation1634. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa2_inst, refa2_op in H. discriminate H. Qed.

Lemma refa2_not1637 : ~ @Equation1637 Fin7 refa2_inst.
Proof. unfold Equation1637. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa2_inst, refa2_op in H. discriminate H. Qed.

Lemma refa2_not1644 : ~ @Equation1644 Fin7 refa2_inst.
Proof. unfold Equation1644. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa2_inst, refa2_op in H. discriminate H. Qed.

Lemma refa2_not1654 : ~ @Equation1654 Fin7 refa2_inst.
Proof. unfold Equation1654. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa2_inst, refa2_op in H. discriminate H. Qed.

Lemma refa2_not1657 : ~ @Equation1657 Fin7 refa2_inst.
Proof. unfold Equation1657. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa2_inst, refa2_op in H. discriminate H. Qed.

Lemma refa2_not1681 : ~ @Equation1681 Fin7 refa2_inst.
Proof. unfold Equation1681. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa2_inst, refa2_op in H. discriminate H. Qed.

Lemma refa2_not1691 : ~ @Equation1691 Fin7 refa2_inst.
Proof. unfold Equation1691. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa2_inst, refa2_op in H. discriminate H. Qed.

Lemma refa2_not1694 : ~ @Equation1694 Fin7 refa2_inst.
Proof. unfold Equation1694. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa2_inst, refa2_op in H. discriminate H. Qed.

Lemma refa2_not1721 : ~ @Equation1721 Fin7 refa2_inst.
Proof. unfold Equation1721. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa2_inst, refa2_op in H. discriminate H. Qed.

Lemma refa2_not1728 : ~ @Equation1728 Fin7 refa2_inst.
Proof. unfold Equation1728. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa2_inst, refa2_op in H. discriminate H. Qed.

Lemma refa2_not1731 : ~ @Equation1731 Fin7 refa2_inst.
Proof. unfold Equation1731. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa2_inst, refa2_op in H. discriminate H. Qed.

Lemma refa2_not1834 : ~ @Equation1834 Fin7 refa2_inst.
Proof. unfold Equation1834. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa2_inst, refa2_op in H. discriminate H. Qed.

Lemma refa2_not1837 : ~ @Equation1837 Fin7 refa2_inst.
Proof. unfold Equation1837. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa2_inst, refa2_op in H. discriminate H. Qed.

Lemma refa2_not1840 : ~ @Equation1840 Fin7 refa2_inst.
Proof. unfold Equation1840. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa2_inst, refa2_op in H. discriminate H. Qed.

Lemma refa2_not1847 : ~ @Equation1847 Fin7 refa2_inst.
Proof. unfold Equation1847. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa2_inst, refa2_op in H. discriminate H. Qed.

Lemma refa2_not1857 : ~ @Equation1857 Fin7 refa2_inst.
Proof. unfold Equation1857. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa2_inst, refa2_op in H. discriminate H. Qed.

Lemma refa2_not1860 : ~ @Equation1860 Fin7 refa2_inst.
Proof. unfold Equation1860. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa2_inst, refa2_op in H. discriminate H. Qed.

Lemma refa2_not1884 : ~ @Equation1884 Fin7 refa2_inst.
Proof. unfold Equation1884. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa2_inst, refa2_op in H. discriminate H. Qed.

Lemma refa2_not1887 : ~ @Equation1887 Fin7 refa2_inst.
Proof. unfold Equation1887. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa2_inst, refa2_op in H. discriminate H. Qed.

Lemma refa2_not1897 : ~ @Equation1897 Fin7 refa2_inst.
Proof. unfold Equation1897. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa2_inst, refa2_op in H. discriminate H. Qed.

Lemma refa2_not1921 : ~ @Equation1921 Fin7 refa2_inst.
Proof. unfold Equation1921. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa2_inst, refa2_op in H. discriminate H. Qed.

Lemma refa2_not1924 : ~ @Equation1924 Fin7 refa2_inst.
Proof. unfold Equation1924. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa2_inst, refa2_op in H. discriminate H. Qed.

Lemma refa2_not1931 : ~ @Equation1931 Fin7 refa2_inst.
Proof. unfold Equation1931. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa2_inst, refa2_op in H. discriminate H. Qed.

Lemma refa2_not2036 : ~ @Equation2036 Fin7 refa2_inst.
Proof. unfold Equation2036. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa2_inst, refa2_op in H. discriminate H. Qed.

Lemma refa2_not2037 : ~ @Equation2037 Fin7 refa2_inst.
Proof. unfold Equation2037. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa2_inst, refa2_op in H. discriminate H. Qed.

Lemma refa2_not2040 : ~ @Equation2040 Fin7 refa2_inst.
Proof. unfold Equation2040. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa2_inst, refa2_op in H. discriminate H. Qed.

Lemma refa2_not2043 : ~ @Equation2043 Fin7 refa2_inst.
Proof. unfold Equation2043. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa2_inst, refa2_op in H. discriminate H. Qed.

Lemma refa2_not2050 : ~ @Equation2050 Fin7 refa2_inst.
Proof. unfold Equation2050. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa2_inst, refa2_op in H. discriminate H. Qed.

Lemma refa2_not2053 : ~ @Equation2053 Fin7 refa2_inst.
Proof. unfold Equation2053. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa2_inst, refa2_op in H. discriminate H. Qed.

Lemma refa2_not2060 : ~ @Equation2060 Fin7 refa2_inst.
Proof. unfold Equation2060. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa2_inst, refa2_op in H. discriminate H. Qed.

Lemma refa2_not2061 : ~ @Equation2061 Fin7 refa2_inst.
Proof. unfold Equation2061. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa2_inst, refa2_op in H. discriminate H. Qed.

Lemma refa2_not2063 : ~ @Equation2063 Fin7 refa2_inst.
Proof. unfold Equation2063. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa2_inst, refa2_op in H. discriminate H. Qed.

Lemma refa2_not2087 : ~ @Equation2087 Fin7 refa2_inst.
Proof. unfold Equation2087. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa2_inst, refa2_op in H. discriminate H. Qed.

Lemma refa2_not2100 : ~ @Equation2100 Fin7 refa2_inst.
Proof. unfold Equation2100. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa2_inst, refa2_op in H. discriminate H. Qed.

Lemma refa2_not2124 : ~ @Equation2124 Fin7 refa2_inst.
Proof. unfold Equation2124. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa2_inst, refa2_op in H. discriminate H. Qed.

Lemma refa2_not2127 : ~ @Equation2127 Fin7 refa2_inst.
Proof. unfold Equation2127. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa2_inst, refa2_op in H. discriminate H. Qed.

Lemma refa2_not2134 : ~ @Equation2134 Fin7 refa2_inst.
Proof. unfold Equation2134. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa2_inst, refa2_op in H. discriminate H. Qed.

Lemma refa2_not2137 : ~ @Equation2137 Fin7 refa2_inst.
Proof. unfold Equation2137. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa2_inst, refa2_op in H. discriminate H. Qed.

Lemma refa2_not2646 : ~ @Equation2646 Fin7 refa2_inst.
Proof. unfold Equation2646. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa2_inst, refa2_op in H. discriminate H. Qed.

Lemma refa2_not2650 : ~ @Equation2650 Fin7 refa2_inst.
Proof. unfold Equation2650. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa2_inst, refa2_op in H. discriminate H. Qed.

Lemma refa2_not2660 : ~ @Equation2660 Fin7 refa2_inst.
Proof. unfold Equation2660. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa2_inst, refa2_op in H. discriminate H. Qed.

Lemma refa2_not2669 : ~ @Equation2669 Fin7 refa2_inst.
Proof. unfold Equation2669. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa2_inst, refa2_op in H. discriminate H. Qed.

Lemma refa2_not2852 : ~ @Equation2852 Fin7 refa2_inst.
Proof. unfold Equation2852. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa2_inst, refa2_op in H. discriminate H. Qed.

Lemma refa2_not2865 : ~ @Equation2865 Fin7 refa2_inst.
Proof. unfold Equation2865. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa2_inst, refa2_op in H. discriminate H. Qed.

Lemma refa2_not3254 : ~ @Equation3254 Fin7 refa2_inst.
Proof. unfold Equation3254. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa2_inst, refa2_op in H. discriminate H. Qed.

Lemma refa2_not3255 : ~ @Equation3255 Fin7 refa2_inst.
Proof. unfold Equation3255. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa2_inst, refa2_op in H. discriminate H. Qed.

Lemma refa2_not3256 : ~ @Equation3256 Fin7 refa2_inst.
Proof. unfold Equation3256. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa2_inst, refa2_op in H. discriminate H. Qed.

Lemma refa2_not3258 : ~ @Equation3258 Fin7 refa2_inst.
Proof. unfold Equation3258. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa2_inst, refa2_op in H. discriminate H. Qed.

Lemma refa2_not3261 : ~ @Equation3261 Fin7 refa2_inst.
Proof. unfold Equation3261. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa2_inst, refa2_op in H. discriminate H. Qed.

Lemma refa2_not3268 : ~ @Equation3268 Fin7 refa2_inst.
Proof. unfold Equation3268. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa2_inst, refa2_op in H. discriminate H. Qed.

Lemma refa2_not3271 : ~ @Equation3271 Fin7 refa2_inst.
Proof. unfold Equation3271. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa2_inst, refa2_op in H. discriminate H. Qed.

Lemma refa2_not3278 : ~ @Equation3278 Fin7 refa2_inst.
Proof. unfold Equation3278. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa2_inst, refa2_op in H. discriminate H. Qed.

Lemma refa2_not3281 : ~ @Equation3281 Fin7 refa2_inst.
Proof. unfold Equation3281. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa2_inst, refa2_op in H. discriminate H. Qed.

Lemma refa2_not3306 : ~ @Equation3306 Fin7 refa2_inst.
Proof. unfold Equation3306. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa2_inst, refa2_op in H. discriminate H. Qed.

Lemma refa2_not3309 : ~ @Equation3309 Fin7 refa2_inst.
Proof. unfold Equation3309. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa2_inst, refa2_op in H. discriminate H. Qed.

Lemma refa2_not3315 : ~ @Equation3315 Fin7 refa2_inst.
Proof. unfold Equation3315. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa2_inst, refa2_op in H. discriminate H. Qed.

Lemma refa2_not3316 : ~ @Equation3316 Fin7 refa2_inst.
Proof. unfold Equation3316. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa2_inst, refa2_op in H. discriminate H. Qed.

Lemma refa2_not3343 : ~ @Equation3343 Fin7 refa2_inst.
Proof. unfold Equation3343. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa2_inst, refa2_op in H. discriminate H. Qed.

Lemma refa2_not3346 : ~ @Equation3346 Fin7 refa2_inst.
Proof. unfold Equation3346. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa2_inst, refa2_op in H. discriminate H. Qed.

Lemma refa2_not3353 : ~ @Equation3353 Fin7 refa2_inst.
Proof. unfold Equation3353. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa2_inst, refa2_op in H. discriminate H. Qed.

Lemma refa2_not3457 : ~ @Equation3457 Fin7 refa2_inst.
Proof. unfold Equation3457. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa2_inst, refa2_op in H. discriminate H. Qed.

Lemma refa2_not3458 : ~ @Equation3458 Fin7 refa2_inst.
Proof. unfold Equation3458. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa2_inst, refa2_op in H. discriminate H. Qed.

Lemma refa2_not3459 : ~ @Equation3459 Fin7 refa2_inst.
Proof. unfold Equation3459. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa2_inst, refa2_op in H. discriminate H. Qed.

Lemma refa2_not3519 : ~ @Equation3519 Fin7 refa2_inst.
Proof. unfold Equation3519. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa2_inst, refa2_op in H. discriminate H. Qed.

Lemma refa2_not3521 : ~ @Equation3521 Fin7 refa2_inst.
Proof. unfold Equation3521. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa2_inst, refa2_op in H. discriminate H. Qed.

Lemma refa2_not3864 : ~ @Equation3864 Fin7 refa2_inst.
Proof. unfold Equation3864. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa2_inst, refa2_op in H. discriminate H. Qed.

Lemma refa2_not3867 : ~ @Equation3867 Fin7 refa2_inst.
Proof. unfold Equation3867. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa2_inst, refa2_op in H. discriminate H. Qed.

Lemma refa2_not3870 : ~ @Equation3870 Fin7 refa2_inst.
Proof. unfold Equation3870. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa2_inst, refa2_op in H. discriminate H. Qed.

Lemma refa2_not3877 : ~ @Equation3877 Fin7 refa2_inst.
Proof. unfold Equation3877. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa2_inst, refa2_op in H. discriminate H. Qed.

Lemma refa2_not3887 : ~ @Equation3887 Fin7 refa2_inst.
Proof. unfold Equation3887. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa2_inst, refa2_op in H. discriminate H. Qed.

Lemma refa2_not3890 : ~ @Equation3890 Fin7 refa2_inst.
Proof. unfold Equation3890. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa2_inst, refa2_op in H. discriminate H. Qed.

Lemma refa2_not3918 : ~ @Equation3918 Fin7 refa2_inst.
Proof. unfold Equation3918. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa2_inst, refa2_op in H. discriminate H. Qed.

Lemma refa2_not3925 : ~ @Equation3925 Fin7 refa2_inst.
Proof. unfold Equation3925. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa2_inst, refa2_op in H. discriminate H. Qed.

Lemma refa2_not3928 : ~ @Equation3928 Fin7 refa2_inst.
Proof. unfold Equation3928. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa2_inst, refa2_op in H. discriminate H. Qed.

Lemma refa2_not3952 : ~ @Equation3952 Fin7 refa2_inst.
Proof. unfold Equation3952. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa2_inst, refa2_op in H. discriminate H. Qed.

Lemma refa2_not3962 : ~ @Equation3962 Fin7 refa2_inst.
Proof. unfold Equation3962. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa2_inst, refa2_op in H. discriminate H. Qed.

Lemma refa2_not4067 : ~ @Equation4067 Fin7 refa2_inst.
Proof. unfold Equation4067. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa2_inst, refa2_op in H. discriminate H. Qed.

Lemma refa2_not4070 : ~ @Equation4070 Fin7 refa2_inst.
Proof. unfold Equation4070. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa2_inst, refa2_op in H. discriminate H. Qed.

Lemma refa2_not4073 : ~ @Equation4073 Fin7 refa2_inst.
Proof. unfold Equation4073. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa2_inst, refa2_op in H. discriminate H. Qed.

Lemma refa2_not4080 : ~ @Equation4080 Fin7 refa2_inst.
Proof. unfold Equation4080. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa2_inst, refa2_op in H. discriminate H. Qed.

Lemma refa2_not4090 : ~ @Equation4090 Fin7 refa2_inst.
Proof. unfold Equation4090. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa2_inst, refa2_op in H. discriminate H. Qed.

Lemma refa2_not4093 : ~ @Equation4093 Fin7 refa2_inst.
Proof. unfold Equation4093. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa2_inst, refa2_op in H. discriminate H. Qed.

Lemma refa2_not4121 : ~ @Equation4121 Fin7 refa2_inst.
Proof. unfold Equation4121. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa2_inst, refa2_op in H. discriminate H. Qed.

Lemma refa2_not4128 : ~ @Equation4128 Fin7 refa2_inst.
Proof. unfold Equation4128. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa2_inst, refa2_op in H. discriminate H. Qed.

Lemma refa2_not4131 : ~ @Equation4131 Fin7 refa2_inst.
Proof. unfold Equation4131. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa2_inst, refa2_op in H. discriminate H. Qed.

Lemma refa2_not4155 : ~ @Equation4155 Fin7 refa2_inst.
Proof. unfold Equation4155. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa2_inst, refa2_op in H. discriminate H. Qed.

Lemma refa2_not4165 : ~ @Equation4165 Fin7 refa2_inst.
Proof. unfold Equation4165. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa2_inst, refa2_op in H. discriminate H. Qed.

Lemma refa2_not4268 : ~ @Equation4268 Fin7 refa2_inst.
Proof. unfold Equation4268. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa2_inst, refa2_op in H. discriminate H. Qed.

Lemma refa2_not4269 : ~ @Equation4269 Fin7 refa2_inst.
Proof. unfold Equation4269. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa2_inst, refa2_op in H. discriminate H. Qed.

Lemma refa2_not4272 : ~ @Equation4272 Fin7 refa2_inst.
Proof. unfold Equation4272. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa2_inst, refa2_op in H. discriminate H. Qed.

Lemma refa2_not4275 : ~ @Equation4275 Fin7 refa2_inst.
Proof. unfold Equation4275. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa2_inst, refa2_op in H. discriminate H. Qed.

Lemma refa2_not4284 : ~ @Equation4284 Fin7 refa2_inst.
Proof. unfold Equation4284. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa2_inst, refa2_op in H. discriminate H. Qed.

Lemma refa2_not4291 : ~ @Equation4291 Fin7 refa2_inst.
Proof. unfold Equation4291. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa2_inst, refa2_op in H. discriminate H. Qed.

Lemma refa2_not4314 : ~ @Equation4314 Fin7 refa2_inst.
Proof. unfold Equation4314. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa2_inst, refa2_op in H. discriminate H. Qed.

Lemma refa2_not4320 : ~ @Equation4320 Fin7 refa2_inst.
Proof. unfold Equation4320. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa2_inst, refa2_op in H. discriminate H. Qed.

Lemma refa2_not4584 : ~ @Equation4584 Fin7 refa2_inst.
Proof. unfold Equation4584. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa2_inst, refa2_op in H. discriminate H. Qed.

Lemma refa2_not4585 : ~ @Equation4585 Fin7 refa2_inst.
Proof. unfold Equation4585. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa2_inst, refa2_op in H. discriminate H. Qed.

Lemma refa2_not4587 : ~ @Equation4587 Fin7 refa2_inst.
Proof. unfold Equation4587. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa2_inst, refa2_op in H. discriminate H. Qed.

Lemma refa2_not4590 : ~ @Equation4590 Fin7 refa2_inst.
Proof. unfold Equation4590. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa2_inst, refa2_op in H. discriminate H. Qed.

Lemma refa2_not4598 : ~ @Equation4598 Fin7 refa2_inst.
Proof. unfold Equation4598. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa2_inst, refa2_op in H. discriminate H. Qed.

Lemma refa2_not4599 : ~ @Equation4599 Fin7 refa2_inst.
Proof. unfold Equation4599. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa2_inst, refa2_op in H. discriminate H. Qed.

Lemma refa2_not4606 : ~ @Equation4606 Fin7 refa2_inst.
Proof. unfold Equation4606. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa2_inst, refa2_op in H. discriminate H. Qed.

Lemma refa2_not4635 : ~ @Equation4635 Fin7 refa2_inst.
Proof. unfold Equation4635. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa2_inst, refa2_op in H. discriminate H. Qed.

(** ---- refa20 (Fin7) ---- *)

Definition refa20_op (x y : Fin7) : Fin7 :=
  match x, y with
  | F7_0, F7_0 => F7_1 | F7_0, F7_1 => F7_2 | F7_0, F7_2 => F7_0 | F7_0, F7_3 => F7_6 | F7_0, F7_4 => F7_4 | F7_0, F7_5 => F7_3 | F7_0, F7_6 => F7_5
  | F7_1, F7_0 => F7_4 | F7_1, F7_1 => F7_3 | F7_1, F7_2 => F7_1 | F7_1, F7_3 => F7_2 | F7_1, F7_4 => F7_5 | F7_1, F7_5 => F7_0 | F7_1, F7_6 => F7_6
  | F7_2, F7_0 => F7_3 | F7_2, F7_1 => F7_5 | F7_2, F7_2 => F7_2 | F7_2, F7_3 => F7_4 | F7_2, F7_4 => F7_0 | F7_2, F7_5 => F7_6 | F7_2, F7_6 => F7_1
  | F7_3, F7_0 => F7_0 | F7_3, F7_1 => F7_6 | F7_3, F7_2 => F7_3 | F7_3, F7_3 => F7_5 | F7_3, F7_4 => F7_1 | F7_3, F7_5 => F7_2 | F7_3, F7_6 => F7_4
  | F7_4, F7_0 => F7_5 | F7_4, F7_1 => F7_0 | F7_4, F7_2 => F7_4 | F7_4, F7_3 => F7_3 | F7_4, F7_4 => F7_6 | F7_4, F7_5 => F7_1 | F7_4, F7_6 => F7_2
  | F7_5, F7_0 => F7_6 | F7_5, F7_1 => F7_1 | F7_5, F7_2 => F7_5 | F7_5, F7_3 => F7_0 | F7_5, F7_4 => F7_2 | F7_5, F7_5 => F7_4 | F7_5, F7_6 => F7_3
  | F7_6, F7_0 => F7_2 | F7_6, F7_1 => F7_4 | F7_6, F7_2 => F7_6 | F7_6, F7_3 => F7_1 | F7_6, F7_4 => F7_3 | F7_6, F7_5 => F7_5 | F7_6, F7_6 => F7_0
  end.

#[local] Instance refa20_inst : Magma Fin7 := {| magma_op := refa20_op |}.

Lemma refa20_sat2091 : @Equation2091 Fin7 refa20_inst.
Proof. unfold Equation2091, magma_op, refa20_inst, refa20_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa20_sat2098 : @Equation2098 Fin7 refa20_inst.
Proof. unfold Equation2098, magma_op, refa20_inst, refa20_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa20_sat2700 : @Equation2700 Fin7 refa20_inst.
Proof. unfold Equation2700, magma_op, refa20_inst, refa20_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa20_sat2910 : @Equation2910 Fin7 refa20_inst.
Proof. unfold Equation2910, magma_op, refa20_inst, refa20_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa20_not65 : ~ @Equation65 Fin7 refa20_inst.
Proof. unfold Equation65. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa20_inst, refa20_op in H. discriminate H. Qed.

Lemma refa20_not73 : ~ @Equation73 Fin7 refa20_inst.
Proof. unfold Equation73. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa20_inst, refa20_op in H. discriminate H. Qed.

Lemma refa20_not99 : ~ @Equation99 Fin7 refa20_inst.
Proof. unfold Equation99. intro H. specialize (H F7_0). unfold magma_op, refa20_inst, refa20_op in H. discriminate H. Qed.

Lemma refa20_not151 : ~ @Equation151 Fin7 refa20_inst.
Proof. unfold Equation151. intro H. specialize (H F7_0). unfold magma_op, refa20_inst, refa20_op in H. discriminate H. Qed.

Lemma refa20_not203 : ~ @Equation203 Fin7 refa20_inst.
Proof. unfold Equation203. intro H. specialize (H F7_0). unfold magma_op, refa20_inst, refa20_op in H. discriminate H. Qed.

Lemma refa20_not255 : ~ @Equation255 Fin7 refa20_inst.
Proof. unfold Equation255. intro H. specialize (H F7_0). unfold magma_op, refa20_inst, refa20_op in H. discriminate H. Qed.

Lemma refa20_not411 : ~ @Equation411 Fin7 refa20_inst.
Proof. unfold Equation411. intro H. specialize (H F7_0). unfold magma_op, refa20_inst, refa20_op in H. discriminate H. Qed.

Lemma refa20_not614 : ~ @Equation614 Fin7 refa20_inst.
Proof. unfold Equation614. intro H. specialize (H F7_0). unfold magma_op, refa20_inst, refa20_op in H. discriminate H. Qed.

Lemma refa20_not817 : ~ @Equation817 Fin7 refa20_inst.
Proof. unfold Equation817. intro H. specialize (H F7_0). unfold magma_op, refa20_inst, refa20_op in H. discriminate H. Qed.

Lemma refa20_not1020 : ~ @Equation1020 Fin7 refa20_inst.
Proof. unfold Equation1020. intro H. specialize (H F7_0). unfold magma_op, refa20_inst, refa20_op in H. discriminate H. Qed.

Lemma refa20_not1223 : ~ @Equation1223 Fin7 refa20_inst.
Proof. unfold Equation1223. intro H. specialize (H F7_0). unfold magma_op, refa20_inst, refa20_op in H. discriminate H. Qed.

Lemma refa20_not1426 : ~ @Equation1426 Fin7 refa20_inst.
Proof. unfold Equation1426. intro H. specialize (H F7_0). unfold magma_op, refa20_inst, refa20_op in H. discriminate H. Qed.

Lemma refa20_not1629 : ~ @Equation1629 Fin7 refa20_inst.
Proof. unfold Equation1629. intro H. specialize (H F7_0). unfold magma_op, refa20_inst, refa20_op in H. discriminate H. Qed.

Lemma refa20_not1832 : ~ @Equation1832 Fin7 refa20_inst.
Proof. unfold Equation1832. intro H. specialize (H F7_0). unfold magma_op, refa20_inst, refa20_op in H. discriminate H. Qed.

Lemma refa20_not2036 : ~ @Equation2036 Fin7 refa20_inst.
Proof. unfold Equation2036. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa20_inst, refa20_op in H. discriminate H. Qed.

Lemma refa20_not2037 : ~ @Equation2037 Fin7 refa20_inst.
Proof. unfold Equation2037. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa20_inst, refa20_op in H. discriminate H. Qed.

Lemma refa20_not2038 : ~ @Equation2038 Fin7 refa20_inst.
Proof. unfold Equation2038. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa20_inst, refa20_op in H. discriminate H. Qed.

Lemma refa20_not2040 : ~ @Equation2040 Fin7 refa20_inst.
Proof. unfold Equation2040. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa20_inst, refa20_op in H. discriminate H. Qed.

Lemma refa20_not2041 : ~ @Equation2041 Fin7 refa20_inst.
Proof. unfold Equation2041. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa20_inst, refa20_op in H. discriminate H. Qed.

Lemma refa20_not2043 : ~ @Equation2043 Fin7 refa20_inst.
Proof. unfold Equation2043. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa20_inst, refa20_op in H. discriminate H. Qed.

Lemma refa20_not2044 : ~ @Equation2044 Fin7 refa20_inst.
Proof. unfold Equation2044. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa20_inst, refa20_op in H. discriminate H. Qed.

Lemma refa20_not2050 : ~ @Equation2050 Fin7 refa20_inst.
Proof. unfold Equation2050. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa20_inst, refa20_op in H. discriminate H. Qed.

Lemma refa20_not2060 : ~ @Equation2060 Fin7 refa20_inst.
Proof. unfold Equation2060. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa20_inst, refa20_op in H. discriminate H. Qed.

Lemma refa20_not2063 : ~ @Equation2063 Fin7 refa20_inst.
Proof. unfold Equation2063. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa20_inst, refa20_op in H. discriminate H. Qed.

Lemma refa20_not2087 : ~ @Equation2087 Fin7 refa20_inst.
Proof. unfold Equation2087. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa20_inst, refa20_op in H. discriminate H. Qed.

Lemma refa20_not2088 : ~ @Equation2088 Fin7 refa20_inst.
Proof. unfold Equation2088. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa20_inst, refa20_op in H. discriminate H. Qed.

Lemma refa20_not2124 : ~ @Equation2124 Fin7 refa20_inst.
Proof. unfold Equation2124. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa20_inst, refa20_op in H. discriminate H. Qed.

Lemma refa20_not2127 : ~ @Equation2127 Fin7 refa20_inst.
Proof. unfold Equation2127. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa20_inst, refa20_op in H. discriminate H. Qed.

Lemma refa20_not2128 : ~ @Equation2128 Fin7 refa20_inst.
Proof. unfold Equation2128. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa20_inst, refa20_op in H. discriminate H. Qed.

Lemma refa20_not2134 : ~ @Equation2134 Fin7 refa20_inst.
Proof. unfold Equation2134. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa20_inst, refa20_op in H. discriminate H. Qed.

Lemma refa20_not2238 : ~ @Equation2238 Fin7 refa20_inst.
Proof. unfold Equation2238. intro H. specialize (H F7_0). unfold magma_op, refa20_inst, refa20_op in H. discriminate H. Qed.

Lemma refa20_not2441 : ~ @Equation2441 Fin7 refa20_inst.
Proof. unfold Equation2441. intro H. specialize (H F7_0). unfold magma_op, refa20_inst, refa20_op in H. discriminate H. Qed.

Lemma refa20_not2670 : ~ @Equation2670 Fin7 refa20_inst.
Proof. unfold Equation2670. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa20_inst, refa20_op in H. discriminate H. Qed.

Lemma refa20_not2672 : ~ @Equation2672 Fin7 refa20_inst.
Proof. unfold Equation2672. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa20_inst, refa20_op in H. discriminate H. Qed.

Lemma refa20_not2697 : ~ @Equation2697 Fin7 refa20_inst.
Proof. unfold Equation2697. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa20_inst, refa20_op in H. discriminate H. Qed.

Lemma refa20_not2699 : ~ @Equation2699 Fin7 refa20_inst.
Proof. unfold Equation2699. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa20_inst, refa20_op in H. discriminate H. Qed.

Lemma refa20_not2710 : ~ @Equation2710 Fin7 refa20_inst.
Proof. unfold Equation2710. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa20_inst, refa20_op in H. discriminate H. Qed.

Lemma refa20_not2734 : ~ @Equation2734 Fin7 refa20_inst.
Proof. unfold Equation2734. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa20_inst, refa20_op in H. discriminate H. Qed.

Lemma refa20_not2743 : ~ @Equation2743 Fin7 refa20_inst.
Proof. unfold Equation2743. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa20_inst, refa20_op in H. discriminate H. Qed.

Lemma refa20_not2744 : ~ @Equation2744 Fin7 refa20_inst.
Proof. unfold Equation2744. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa20_inst, refa20_op in H. discriminate H. Qed.

Lemma refa20_not2746 : ~ @Equation2746 Fin7 refa20_inst.
Proof. unfold Equation2746. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa20_inst, refa20_op in H. discriminate H. Qed.

Lemma refa20_not2853 : ~ @Equation2853 Fin7 refa20_inst.
Proof. unfold Equation2853. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa20_inst, refa20_op in H. discriminate H. Qed.

Lemma refa20_not2863 : ~ @Equation2863 Fin7 refa20_inst.
Proof. unfold Equation2863. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa20_inst, refa20_op in H. discriminate H. Qed.

Lemma refa20_not2875 : ~ @Equation2875 Fin7 refa20_inst.
Proof. unfold Equation2875. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa20_inst, refa20_op in H. discriminate H. Qed.

Lemma refa20_not2900 : ~ @Equation2900 Fin7 refa20_inst.
Proof. unfold Equation2900. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa20_inst, refa20_op in H. discriminate H. Qed.

Lemma refa20_not2902 : ~ @Equation2902 Fin7 refa20_inst.
Proof. unfold Equation2902. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa20_inst, refa20_op in H. discriminate H. Qed.

Lemma refa20_not2903 : ~ @Equation2903 Fin7 refa20_inst.
Proof. unfold Equation2903. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa20_inst, refa20_op in H. discriminate H. Qed.

Lemma refa20_not2909 : ~ @Equation2909 Fin7 refa20_inst.
Proof. unfold Equation2909. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa20_inst, refa20_op in H. discriminate H. Qed.

Lemma refa20_not2937 : ~ @Equation2937 Fin7 refa20_inst.
Proof. unfold Equation2937. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa20_inst, refa20_op in H. discriminate H. Qed.

Lemma refa20_not2939 : ~ @Equation2939 Fin7 refa20_inst.
Proof. unfold Equation2939. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa20_inst, refa20_op in H. discriminate H. Qed.

Lemma refa20_not2940 : ~ @Equation2940 Fin7 refa20_inst.
Proof. unfold Equation2940. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa20_inst, refa20_op in H. discriminate H. Qed.

Lemma refa20_not2947 : ~ @Equation2947 Fin7 refa20_inst.
Proof. unfold Equation2947. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa20_inst, refa20_op in H. discriminate H. Qed.

Lemma refa20_not2949 : ~ @Equation2949 Fin7 refa20_inst.
Proof. unfold Equation2949. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa20_inst, refa20_op in H. discriminate H. Qed.

Lemma refa20_not3050 : ~ @Equation3050 Fin7 refa20_inst.
Proof. unfold Equation3050. intro H. specialize (H F7_0). unfold magma_op, refa20_inst, refa20_op in H. discriminate H. Qed.

Lemma refa20_not3253 : ~ @Equation3253 Fin7 refa20_inst.
Proof. unfold Equation3253. intro H. specialize (H F7_0). unfold magma_op, refa20_inst, refa20_op in H. discriminate H. Qed.

Lemma refa20_not3456 : ~ @Equation3456 Fin7 refa20_inst.
Proof. unfold Equation3456. intro H. specialize (H F7_0). unfold magma_op, refa20_inst, refa20_op in H. discriminate H. Qed.

Lemma refa20_not3659 : ~ @Equation3659 Fin7 refa20_inst.
Proof. unfold Equation3659. intro H. specialize (H F7_0). unfold magma_op, refa20_inst, refa20_op in H. discriminate H. Qed.

Lemma refa20_not3862 : ~ @Equation3862 Fin7 refa20_inst.
Proof. unfold Equation3862. intro H. specialize (H F7_0). unfold magma_op, refa20_inst, refa20_op in H. discriminate H. Qed.

Lemma refa20_not4065 : ~ @Equation4065 Fin7 refa20_inst.
Proof. unfold Equation4065. intro H. specialize (H F7_0). unfold magma_op, refa20_inst, refa20_op in H. discriminate H. Qed.

Lemma refa20_not4273 : ~ @Equation4273 Fin7 refa20_inst.
Proof. unfold Equation4273. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa20_inst, refa20_op in H. discriminate H. Qed.

Lemma refa20_not4275 : ~ @Equation4275 Fin7 refa20_inst.
Proof. unfold Equation4275. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa20_inst, refa20_op in H. discriminate H. Qed.

Lemma refa20_not4283 : ~ @Equation4283 Fin7 refa20_inst.
Proof. unfold Equation4283. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa20_inst, refa20_op in H. discriminate H. Qed.

Lemma refa20_not4293 : ~ @Equation4293 Fin7 refa20_inst.
Proof. unfold Equation4293. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa20_inst, refa20_op in H. discriminate H. Qed.

Lemma refa20_not4320 : ~ @Equation4320 Fin7 refa20_inst.
Proof. unfold Equation4320. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa20_inst, refa20_op in H. discriminate H. Qed.

Lemma refa20_not4343 : ~ @Equation4343 Fin7 refa20_inst.
Proof. unfold Equation4343. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa20_inst, refa20_op in H. discriminate H. Qed.

Lemma refa20_not4380 : ~ @Equation4380 Fin7 refa20_inst.
Proof. unfold Equation4380. intro H. specialize (H F7_0). unfold magma_op, refa20_inst, refa20_op in H. discriminate H. Qed.

Lemma refa20_not4585 : ~ @Equation4585 Fin7 refa20_inst.
Proof. unfold Equation4585. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa20_inst, refa20_op in H. discriminate H. Qed.

Lemma refa20_not4588 : ~ @Equation4588 Fin7 refa20_inst.
Proof. unfold Equation4588. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa20_inst, refa20_op in H. discriminate H. Qed.

Lemma refa20_not4608 : ~ @Equation4608 Fin7 refa20_inst.
Proof. unfold Equation4608. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa20_inst, refa20_op in H. discriminate H. Qed.

Lemma refa20_not4635 : ~ @Equation4635 Fin7 refa20_inst.
Proof. unfold Equation4635. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa20_inst, refa20_op in H. discriminate H. Qed.

Lemma refa20_not4636 : ~ @Equation4636 Fin7 refa20_inst.
Proof. unfold Equation4636. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa20_inst, refa20_op in H. discriminate H. Qed.

(** ---- refa200 (Fin3) ---- *)

Definition refa200_op (x y : Fin3) : Fin3 :=
  match x, y with
  | F3_0, F3_0 => F3_0 | F3_0, F3_1 => F3_1 | F3_0, F3_2 => F3_1
  | F3_1, F3_0 => F3_0 | F3_1, F3_1 => F3_1 | F3_1, F3_2 => F3_2
  | F3_2, F3_0 => F3_1 | F3_2, F3_1 => F3_0 | F3_2, F3_2 => F3_2
  end.

#[local] Instance refa200_inst : Magma Fin3 := {| magma_op := refa200_op |}.

Lemma refa200_sat2347 : @Equation2347 Fin3 refa200_inst.
Proof. unfold Equation2347, magma_op, refa200_inst, refa200_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa200_sat2787 : @Equation2787 Fin3 refa200_inst.
Proof. unfold Equation2787, magma_op, refa200_inst, refa200_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa200_sat2804 : @Equation2804 Fin3 refa200_inst.
Proof. unfold Equation2804, magma_op, refa200_inst, refa200_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa200_not323 : ~ @Equation323 Fin3 refa200_inst.
Proof. unfold Equation323. intro H. specialize (H F3_2 F3_0). unfold magma_op, refa200_inst, refa200_op in H. discriminate H. Qed.

Lemma refa200_not333 : ~ @Equation333 Fin3 refa200_inst.
Proof. unfold Equation333. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa200_inst, refa200_op in H. discriminate H. Qed.

Lemma refa200_not1025 : ~ @Equation1025 Fin3 refa200_inst.
Proof. unfold Equation1025. intro H. specialize (H F3_2 F3_0). unfold magma_op, refa200_inst, refa200_op in H. discriminate H. Qed.

Lemma refa200_not1847 : ~ @Equation1847 Fin3 refa200_inst.
Proof. unfold Equation1847. intro H. specialize (H F3_2 F3_0). unfold magma_op, refa200_inst, refa200_op in H. discriminate H. Qed.

Lemma refa200_not2253 : ~ @Equation2253 Fin3 refa200_inst.
Proof. unfold Equation2253. intro H. specialize (H F3_2 F3_0). unfold magma_op, refa200_inst, refa200_op in H. discriminate H. Qed.

Lemma refa200_not2263 : ~ @Equation2263 Fin3 refa200_inst.
Proof. unfold Equation2263. intro H. specialize (H F3_2 F3_0). unfold magma_op, refa200_inst, refa200_op in H. discriminate H. Qed.

Lemma refa200_not2300 : ~ @Equation2300 Fin3 refa200_inst.
Proof. unfold Equation2300. intro H. specialize (H F3_2 F3_0). unfold magma_op, refa200_inst, refa200_op in H. discriminate H. Qed.

Lemma refa200_not2446 : ~ @Equation2446 Fin3 refa200_inst.
Proof. unfold Equation2446. intro H. specialize (H F3_2 F3_1). unfold magma_op, refa200_inst, refa200_op in H. discriminate H. Qed.

Lemma refa200_not2466 : ~ @Equation2466 Fin3 refa200_inst.
Proof. unfold Equation2466. intro H. specialize (H F3_2 F3_0). unfold magma_op, refa200_inst, refa200_op in H. discriminate H. Qed.

Lemma refa200_not2649 : ~ @Equation2649 Fin3 refa200_inst.
Proof. unfold Equation2649. intro H. specialize (H F3_2 F3_0). unfold magma_op, refa200_inst, refa200_op in H. discriminate H. Qed.

Lemma refa200_not3309 : ~ @Equation3309 Fin3 refa200_inst.
Proof. unfold Equation3309. intro H. specialize (H F3_2 F3_0). unfold magma_op, refa200_inst, refa200_op in H. discriminate H. Qed.

Lemma refa200_not3316 : ~ @Equation3316 Fin3 refa200_inst.
Proof. unfold Equation3316. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa200_inst, refa200_op in H. discriminate H. Qed.

Lemma refa200_not3343 : ~ @Equation3343 Fin3 refa200_inst.
Proof. unfold Equation3343. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa200_inst, refa200_op in H. discriminate H. Qed.

Lemma refa200_not3346 : ~ @Equation3346 Fin3 refa200_inst.
Proof. unfold Equation3346. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa200_inst, refa200_op in H. discriminate H. Qed.

Lemma refa200_not3509 : ~ @Equation3509 Fin3 refa200_inst.
Proof. unfold Equation3509. intro H. specialize (H F3_2 F3_0). unfold magma_op, refa200_inst, refa200_op in H. discriminate H. Qed.

Lemma refa200_not3519 : ~ @Equation3519 Fin3 refa200_inst.
Proof. unfold Equation3519. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa200_inst, refa200_op in H. discriminate H. Qed.

Lemma refa200_not3546 : ~ @Equation3546 Fin3 refa200_inst.
Proof. unfold Equation3546. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa200_inst, refa200_op in H. discriminate H. Qed.

Lemma refa200_not3556 : ~ @Equation3556 Fin3 refa200_inst.
Proof. unfold Equation3556. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa200_inst, refa200_op in H. discriminate H. Qed.

Lemma refa200_not3712 : ~ @Equation3712 Fin3 refa200_inst.
Proof. unfold Equation3712. intro H. specialize (H F3_2 F3_0). unfold magma_op, refa200_inst, refa200_op in H. discriminate H. Qed.

Lemma refa200_not3749 : ~ @Equation3749 Fin3 refa200_inst.
Proof. unfold Equation3749. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa200_inst, refa200_op in H. discriminate H. Qed.

Lemma refa200_not3752 : ~ @Equation3752 Fin3 refa200_inst.
Proof. unfold Equation3752. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa200_inst, refa200_op in H. discriminate H. Qed.

Lemma refa200_not3759 : ~ @Equation3759 Fin3 refa200_inst.
Proof. unfold Equation3759. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa200_inst, refa200_op in H. discriminate H. Qed.

Lemma refa200_not3867 : ~ @Equation3867 Fin3 refa200_inst.
Proof. unfold Equation3867. intro H. specialize (H F3_2 F3_0). unfold magma_op, refa200_inst, refa200_op in H. discriminate H. Qed.

Lemma refa200_not3925 : ~ @Equation3925 Fin3 refa200_inst.
Proof. unfold Equation3925. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa200_inst, refa200_op in H. discriminate H. Qed.

Lemma refa200_not3952 : ~ @Equation3952 Fin3 refa200_inst.
Proof. unfold Equation3952. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa200_inst, refa200_op in H. discriminate H. Qed.

Lemma refa200_not3962 : ~ @Equation3962 Fin3 refa200_inst.
Proof. unfold Equation3962. intro H. specialize (H F3_2 F3_0). unfold magma_op, refa200_inst, refa200_op in H. discriminate H. Qed.

Lemma refa200_not4128 : ~ @Equation4128 Fin3 refa200_inst.
Proof. unfold Equation4128. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa200_inst, refa200_op in H. discriminate H. Qed.

Lemma refa200_not4165 : ~ @Equation4165 Fin3 refa200_inst.
Proof. unfold Equation4165. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa200_inst, refa200_op in H. discriminate H. Qed.

Lemma refa200_not4284 : ~ @Equation4284 Fin3 refa200_inst.
Proof. unfold Equation4284. intro H. specialize (H F3_2 F3_0). unfold magma_op, refa200_inst, refa200_op in H. discriminate H. Qed.

Lemma refa200_not4291 : ~ @Equation4291 Fin3 refa200_inst.
Proof. unfold Equation4291. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa200_inst, refa200_op in H. discriminate H. Qed.

Lemma refa200_not4320 : ~ @Equation4320 Fin3 refa200_inst.
Proof. unfold Equation4320. intro H. specialize (H F3_2 F3_0). unfold magma_op, refa200_inst, refa200_op in H. discriminate H. Qed.

Lemma refa200_not4396 : ~ @Equation4396 Fin3 refa200_inst.
Proof. unfold Equation4396. intro H. specialize (H F3_2 F3_0). unfold magma_op, refa200_inst, refa200_op in H. discriminate H. Qed.

Lemma refa200_not4406 : ~ @Equation4406 Fin3 refa200_inst.
Proof. unfold Equation4406. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa200_inst, refa200_op in H. discriminate H. Qed.

Lemma refa200_not4435 : ~ @Equation4435 Fin3 refa200_inst.
Proof. unfold Equation4435. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa200_inst, refa200_op in H. discriminate H. Qed.

Lemma refa200_not4445 : ~ @Equation4445 Fin3 refa200_inst.
Proof. unfold Equation4445. intro H. specialize (H F3_2 F3_0). unfold magma_op, refa200_inst, refa200_op in H. discriminate H. Qed.

Lemma refa200_not4480 : ~ @Equation4480 Fin3 refa200_inst.
Proof. unfold Equation4480. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa200_inst, refa200_op in H. discriminate H. Qed.

Lemma refa200_not4606 : ~ @Equation4606 Fin3 refa200_inst.
Proof. unfold Equation4606. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa200_inst, refa200_op in H. discriminate H. Qed.

(** ---- refa201 (Fin3) ---- *)

Definition refa201_op (x y : Fin3) : Fin3 :=
  match x, y with
  | F3_0, F3_0 => F3_0 | F3_0, F3_1 => F3_0 | F3_0, F3_2 => F3_0
  | F3_1, F3_0 => F3_0 | F3_1, F3_1 => F3_0 | F3_1, F3_2 => F3_0
  | F3_2, F3_0 => F3_0 | F3_2, F3_1 => F3_0 | F3_2, F3_2 => F3_1
  end.

#[local] Instance refa201_inst : Magma Fin3 := {| magma_op := refa201_op |}.

Lemma refa201_sat4526 : @Equation4526 Fin3 refa201_inst.
Proof. unfold Equation4526, magma_op, refa201_inst, refa201_op. intros x y z w. destruct x, y, z, w; reflexivity. Qed.

Lemma refa201_not3253 : ~ @Equation3253 Fin3 refa201_inst.
Proof. unfold Equation3253. intro H. specialize (H F3_2). unfold magma_op, refa201_inst, refa201_op in H. discriminate H. Qed.

Lemma refa201_not3456 : ~ @Equation3456 Fin3 refa201_inst.
Proof. unfold Equation3456. intro H. specialize (H F3_2). unfold magma_op, refa201_inst, refa201_op in H. discriminate H. Qed.

Lemma refa201_not3659 : ~ @Equation3659 Fin3 refa201_inst.
Proof. unfold Equation3659. intro H. specialize (H F3_2). unfold magma_op, refa201_inst, refa201_op in H. discriminate H. Qed.

Lemma refa201_not3862 : ~ @Equation3862 Fin3 refa201_inst.
Proof. unfold Equation3862. intro H. specialize (H F3_2). unfold magma_op, refa201_inst, refa201_op in H. discriminate H. Qed.

Lemma refa201_not4065 : ~ @Equation4065 Fin3 refa201_inst.
Proof. unfold Equation4065. intro H. specialize (H F3_2). unfold magma_op, refa201_inst, refa201_op in H. discriminate H. Qed.

(** ---- refa202 (Fin3) ---- *)

Definition refa202_op (x y : Fin3) : Fin3 :=
  match x, y with
  | F3_0, F3_0 => F3_1 | F3_0, F3_1 => F3_0 | F3_0, F3_2 => F3_1
  | F3_1, F3_0 => F3_2 | F3_1, F3_1 => F3_0 | F3_1, F3_2 => F3_2
  | F3_2, F3_0 => F3_0 | F3_2, F3_1 => F3_0 | F3_2, F3_2 => F3_0
  end.

#[local] Instance refa202_inst : Magma Fin3 := {| magma_op := refa202_op |}.

Lemma refa202_sat2036 : @Equation2036 Fin3 refa202_inst.
Proof. unfold Equation2036, magma_op, refa202_inst, refa202_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa202_sat2050 : @Equation2050 Fin3 refa202_inst.
Proof. unfold Equation2050, magma_op, refa202_inst, refa202_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa202_not3253 : ~ @Equation3253 Fin3 refa202_inst.
Proof. unfold Equation3253. intro H. specialize (H F3_1). unfold magma_op, refa202_inst, refa202_op in H. discriminate H. Qed.

Lemma refa202_not3456 : ~ @Equation3456 Fin3 refa202_inst.
Proof. unfold Equation3456. intro H. specialize (H F3_1). unfold magma_op, refa202_inst, refa202_op in H. discriminate H. Qed.

Lemma refa202_not4284 : ~ @Equation4284 Fin3 refa202_inst.
Proof. unfold Equation4284. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa202_inst, refa202_op in H. discriminate H. Qed.

(** ---- refa203 (Fin3) ---- *)

Definition refa203_op (x y : Fin3) : Fin3 :=
  match x, y with
  | F3_0, F3_0 => F3_0 | F3_0, F3_1 => F3_1 | F3_0, F3_2 => F3_2
  | F3_1, F3_0 => F3_0 | F3_1, F3_1 => F3_0 | F3_1, F3_2 => F3_1
  | F3_2, F3_0 => F3_0 | F3_2, F3_1 => F3_2 | F3_2, F3_2 => F3_0
  end.

#[local] Instance refa203_inst : Magma Fin3 := {| magma_op := refa203_op |}.

Lemma refa203_sat2296 : @Equation2296 Fin3 refa203_inst.
Proof. unfold Equation2296, magma_op, refa203_inst, refa203_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa203_sat2351 : @Equation2351 Fin3 refa203_inst.
Proof. unfold Equation2351, magma_op, refa203_inst, refa203_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa203_sat2402 : @Equation2402 Fin3 refa203_inst.
Proof. unfold Equation2402, magma_op, refa203_inst, refa203_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa203_sat2554 : @Equation2554 Fin3 refa203_inst.
Proof. unfold Equation2554, magma_op, refa203_inst, refa203_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa203_not221 : ~ @Equation221 Fin3 refa203_inst.
Proof. unfold Equation221. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa203_inst, refa203_op in H. discriminate H. Qed.

Lemma refa203_not2256 : ~ @Equation2256 Fin3 refa203_inst.
Proof. unfold Equation2256. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa203_inst, refa203_op in H. discriminate H. Qed.

Lemma refa203_not2300 : ~ @Equation2300 Fin3 refa203_inst.
Proof. unfold Equation2300. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa203_inst, refa203_op in H. discriminate H. Qed.

Lemma refa203_not2443 : ~ @Equation2443 Fin3 refa203_inst.
Proof. unfold Equation2443. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa203_inst, refa203_op in H. discriminate H. Qed.

Lemma refa203_not2456 : ~ @Equation2456 Fin3 refa203_inst.
Proof. unfold Equation2456. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa203_inst, refa203_op in H. discriminate H. Qed.

Lemma refa203_not2469 : ~ @Equation2469 Fin3 refa203_inst.
Proof. unfold Equation2469. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa203_inst, refa203_op in H. discriminate H. Qed.

Lemma refa203_not2506 : ~ @Equation2506 Fin3 refa203_inst.
Proof. unfold Equation2506. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa203_inst, refa203_op in H. discriminate H. Qed.

Lemma refa203_not3749 : ~ @Equation3749 Fin3 refa203_inst.
Proof. unfold Equation3749. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa203_inst, refa203_op in H. discriminate H. Qed.

Lemma refa203_not4320 : ~ @Equation4320 Fin3 refa203_inst.
Proof. unfold Equation4320. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa203_inst, refa203_op in H. discriminate H. Qed.

(** ---- refa204 (Fin3) ---- *)

Definition refa204_op (x y : Fin3) : Fin3 :=
  match x, y with
  | F3_0, F3_0 => F3_1 | F3_0, F3_1 => F3_1 | F3_0, F3_2 => F3_0
  | F3_1, F3_0 => F3_0 | F3_1, F3_1 => F3_2 | F3_1, F3_2 => F3_2
  | F3_2, F3_0 => F3_0 | F3_2, F3_1 => F3_0 | F3_2, F3_2 => F3_0
  end.

#[local] Instance refa204_inst : Magma Fin3 := {| magma_op := refa204_op |}.

Lemma refa204_sat2659 : @Equation2659 Fin3 refa204_inst.
Proof. unfold Equation2659, magma_op, refa204_inst, refa204_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa204_not3456 : ~ @Equation3456 Fin3 refa204_inst.
Proof. unfold Equation3456. intro H. specialize (H F3_1). unfold magma_op, refa204_inst, refa204_op in H. discriminate H. Qed.

(** ---- refa205 (Fin3) ---- *)

Definition refa205_op (x y : Fin3) : Fin3 :=
  match x, y with
  | F3_0, F3_0 => F3_0 | F3_0, F3_1 => F3_1 | F3_0, F3_2 => F3_2
  | F3_1, F3_0 => F3_0 | F3_1, F3_1 => F3_0 | F3_1, F3_2 => F3_1
  | F3_2, F3_0 => F3_0 | F3_2, F3_1 => F3_0 | F3_2, F3_2 => F3_1
  end.

#[local] Instance refa205_inst : Magma Fin3 := {| magma_op := refa205_op |}.

Lemma refa205_sat2385 : @Equation2385 Fin3 refa205_inst.
Proof. unfold Equation2385, magma_op, refa205_inst, refa205_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa205_sat2484 : @Equation2484 Fin3 refa205_inst.
Proof. unfold Equation2484, magma_op, refa205_inst, refa205_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa205_sat2588 : @Equation2588 Fin3 refa205_inst.
Proof. unfold Equation2588, magma_op, refa205_inst, refa205_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa205_sat2778 : @Equation2778 Fin3 refa205_inst.
Proof. unfold Equation2778, magma_op, refa205_inst, refa205_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa205_sat2812 : @Equation2812 Fin3 refa205_inst.
Proof. unfold Equation2812, magma_op, refa205_inst, refa205_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa205_not1629 : ~ @Equation1629 Fin3 refa205_inst.
Proof. unfold Equation1629. intro H. specialize (H F3_2). unfold magma_op, refa205_inst, refa205_op in H. discriminate H. Qed.

Lemma refa205_not2300 : ~ @Equation2300 Fin3 refa205_inst.
Proof. unfold Equation2300. intro H. specialize (H F3_2 F3_0). unfold magma_op, refa205_inst, refa205_op in H. discriminate H. Qed.

Lemma refa205_not2443 : ~ @Equation2443 Fin3 refa205_inst.
Proof. unfold Equation2443. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa205_inst, refa205_op in H. discriminate H. Qed.

Lemma refa205_not2459 : ~ @Equation2459 Fin3 refa205_inst.
Proof. unfold Equation2459. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa205_inst, refa205_op in H. discriminate H. Qed.

Lemma refa205_not2466 : ~ @Equation2466 Fin3 refa205_inst.
Proof. unfold Equation2466. intro H. specialize (H F3_2 F3_0). unfold magma_op, refa205_inst, refa205_op in H. discriminate H. Qed.

Lemma refa205_not2496 : ~ @Equation2496 Fin3 refa205_inst.
Proof. unfold Equation2496. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa205_inst, refa205_op in H. discriminate H. Qed.

Lemma refa205_not2530 : ~ @Equation2530 Fin3 refa205_inst.
Proof. unfold Equation2530. intro H. specialize (H F3_2 F3_0). unfold magma_op, refa205_inst, refa205_op in H. discriminate H. Qed.

Lemma refa205_not2533 : ~ @Equation2533 Fin3 refa205_inst.
Proof. unfold Equation2533. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa205_inst, refa205_op in H. discriminate H. Qed.

Lemma refa205_not2646 : ~ @Equation2646 Fin3 refa205_inst.
Proof. unfold Equation2646. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa205_inst, refa205_op in H. discriminate H. Qed.

Lemma refa205_not2652 : ~ @Equation2652 Fin3 refa205_inst.
Proof. unfold Equation2652. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa205_inst, refa205_op in H. discriminate H. Qed.

Lemma refa205_not2659 : ~ @Equation2659 Fin3 refa205_inst.
Proof. unfold Equation2659. intro H. specialize (H F3_2 F3_0). unfold magma_op, refa205_inst, refa205_op in H. discriminate H. Qed.

Lemma refa205_not2699 : ~ @Equation2699 Fin3 refa205_inst.
Proof. unfold Equation2699. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa205_inst, refa205_op in H. discriminate H. Qed.

Lemma refa205_not2709 : ~ @Equation2709 Fin3 refa205_inst.
Proof. unfold Equation2709. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa205_inst, refa205_op in H. discriminate H. Qed.

Lemma refa205_not3050 : ~ @Equation3050 Fin3 refa205_inst.
Proof. unfold Equation3050. intro H. specialize (H F3_2). unfold magma_op, refa205_inst, refa205_op in H. discriminate H. Qed.

Lemma refa205_not3253 : ~ @Equation3253 Fin3 refa205_inst.
Proof. unfold Equation3253. intro H. specialize (H F3_2). unfold magma_op, refa205_inst, refa205_op in H. discriminate H. Qed.

Lemma refa205_not3456 : ~ @Equation3456 Fin3 refa205_inst.
Proof. unfold Equation3456. intro H. specialize (H F3_2). unfold magma_op, refa205_inst, refa205_op in H. discriminate H. Qed.

Lemma refa205_not3659 : ~ @Equation3659 Fin3 refa205_inst.
Proof. unfold Equation3659. intro H. specialize (H F3_2). unfold magma_op, refa205_inst, refa205_op in H. discriminate H. Qed.

Lemma refa205_not4068 : ~ @Equation4068 Fin3 refa205_inst.
Proof. unfold Equation4068. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa205_inst, refa205_op in H. discriminate H. Qed.

Lemma refa205_not4070 : ~ @Equation4070 Fin3 refa205_inst.
Proof. unfold Equation4070. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa205_inst, refa205_op in H. discriminate H. Qed.

Lemma refa205_not4090 : ~ @Equation4090 Fin3 refa205_inst.
Proof. unfold Equation4090. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa205_inst, refa205_op in H. discriminate H. Qed.

Lemma refa205_not4128 : ~ @Equation4128 Fin3 refa205_inst.
Proof. unfold Equation4128. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa205_inst, refa205_op in H. discriminate H. Qed.

Lemma refa205_not4131 : ~ @Equation4131 Fin3 refa205_inst.
Proof. unfold Equation4131. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa205_inst, refa205_op in H. discriminate H. Qed.

Lemma refa205_not4165 : ~ @Equation4165 Fin3 refa205_inst.
Proof. unfold Equation4165. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa205_inst, refa205_op in H. discriminate H. Qed.

Lemma refa205_not4269 : ~ @Equation4269 Fin3 refa205_inst.
Proof. unfold Equation4269. intro H. specialize (H F3_2 F3_0). unfold magma_op, refa205_inst, refa205_op in H. discriminate H. Qed.

Lemma refa205_not4270 : ~ @Equation4270 Fin3 refa205_inst.
Proof. unfold Equation4270. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa205_inst, refa205_op in H. discriminate H. Qed.

Lemma refa205_not4272 : ~ @Equation4272 Fin3 refa205_inst.
Proof. unfold Equation4272. intro H. specialize (H F3_2 F3_0). unfold magma_op, refa205_inst, refa205_op in H. discriminate H. Qed.

Lemma refa205_not4314 : ~ @Equation4314 Fin3 refa205_inst.
Proof. unfold Equation4314. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa205_inst, refa205_op in H. discriminate H. Qed.

Lemma refa205_not4622 : ~ @Equation4622 Fin3 refa205_inst.
Proof. unfold Equation4622. intro H. specialize (H F3_0 F3_1 F3_2). unfold magma_op, refa205_inst, refa205_op in H. discriminate H. Qed.

Lemma refa205_not4631 : ~ @Equation4631 Fin3 refa205_inst.
Proof. unfold Equation4631. intro H. specialize (H F3_1 F3_0 F3_2). unfold magma_op, refa205_inst, refa205_op in H. discriminate H. Qed.

(** ---- refa206 (Fin3) ---- *)

Definition refa206_op (x y : Fin3) : Fin3 :=
  match x, y with
  | F3_0, F3_0 => F3_0 | F3_0, F3_1 => F3_0 | F3_0, F3_2 => F3_2
  | F3_1, F3_0 => F3_2 | F3_1, F3_1 => F3_2 | F3_1, F3_2 => F3_2
  | F3_2, F3_0 => F3_1 | F3_2, F3_1 => F3_1 | F3_2, F3_2 => F3_0
  end.

#[local] Instance refa206_inst : Magma Fin3 := {| magma_op := refa206_op |}.

Lemma refa206_sat1631 : @Equation1631 Fin3 refa206_inst.
Proof. unfold Equation1631, magma_op, refa206_inst, refa206_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa206_sat1645 : @Equation1645 Fin3 refa206_inst.
Proof. unfold Equation1645, magma_op, refa206_inst, refa206_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa206_not1637 : ~ @Equation1637 Fin3 refa206_inst.
Proof. unfold Equation1637. intro H. specialize (H F3_2 F3_1). unfold magma_op, refa206_inst, refa206_op in H. discriminate H. Qed.

Lemma refa206_not1832 : ~ @Equation1832 Fin3 refa206_inst.
Proof. unfold Equation1832. intro H. specialize (H F3_1). unfold magma_op, refa206_inst, refa206_op in H. discriminate H. Qed.

Lemma refa206_not2444 : ~ @Equation2444 Fin3 refa206_inst.
Proof. unfold Equation2444. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa206_inst, refa206_op in H. discriminate H. Qed.

Lemma refa206_not2470 : ~ @Equation2470 Fin3 refa206_inst.
Proof. unfold Equation2470. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa206_inst, refa206_op in H. discriminate H. Qed.

Lemma refa206_not3253 : ~ @Equation3253 Fin3 refa206_inst.
Proof. unfold Equation3253. intro H. specialize (H F3_2). unfold magma_op, refa206_inst, refa206_op in H. discriminate H. Qed.

(** ---- refa207 (Fin3) ---- *)

Definition refa207_op (x y : Fin3) : Fin3 :=
  match x, y with
  | F3_0, F3_0 => F3_0 | F3_0, F3_1 => F3_0 | F3_0, F3_2 => F3_0
  | F3_1, F3_0 => F3_0 | F3_1, F3_1 => F3_0 | F3_1, F3_2 => F3_1
  | F3_2, F3_0 => F3_1 | F3_2, F3_1 => F3_2 | F3_2, F3_2 => F3_0
  end.

#[local] Instance refa207_inst : Magma Fin3 := {| magma_op := refa207_op |}.

Lemma refa207_sat4106 : @Equation4106 Fin3 refa207_inst.
Proof. unfold Equation4106, magma_op, refa207_inst, refa207_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa207_not3862 : ~ @Equation3862 Fin3 refa207_inst.
Proof. unfold Equation3862. intro H. specialize (H F3_2). unfold magma_op, refa207_inst, refa207_op in H. discriminate H. Qed.

Lemma refa207_not4598 : ~ @Equation4598 Fin3 refa207_inst.
Proof. unfold Equation4598. intro H. specialize (H F3_2 F3_0). unfold magma_op, refa207_inst, refa207_op in H. discriminate H. Qed.

Lemma refa207_not4647 : ~ @Equation4647 Fin3 refa207_inst.
Proof. unfold Equation4647. intro H. specialize (H F3_0 F3_0 F3_2). unfold magma_op, refa207_inst, refa207_op in H. discriminate H. Qed.

(** ---- refa208 (Fin3) ---- *)

Definition refa208_op (x y : Fin3) : Fin3 :=
  match x, y with
  | F3_0, F3_0 => F3_0 | F3_0, F3_1 => F3_0 | F3_0, F3_2 => F3_0
  | F3_1, F3_0 => F3_1 | F3_1, F3_1 => F3_0 | F3_1, F3_2 => F3_0
  | F3_2, F3_0 => F3_2 | F3_2, F3_1 => F3_1 | F3_2, F3_2 => F3_2
  end.

#[local] Instance refa208_inst : Magma Fin3 := {| magma_op := refa208_op |}.

Lemma refa208_sat1245 : @Equation1245 Fin3 refa208_inst.
Proof. unfold Equation1245, magma_op, refa208_inst, refa208_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa208_sat1259 : @Equation1259 Fin3 refa208_inst.
Proof. unfold Equation1259, magma_op, refa208_inst, refa208_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa208_not107 : ~ @Equation107 Fin3 refa208_inst.
Proof. unfold Equation107. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa208_inst, refa208_op in H. discriminate H. Qed.

Lemma refa208_not108 : ~ @Equation108 Fin3 refa208_inst.
Proof. unfold Equation108. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa208_inst, refa208_op in H. discriminate H. Qed.

Lemma refa208_not846 : ~ @Equation846 Fin3 refa208_inst.
Proof. unfold Equation846. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa208_inst, refa208_op in H. discriminate H. Qed.

Lemma refa208_not1224 : ~ @Equation1224 Fin3 refa208_inst.
Proof. unfold Equation1224. intro H. specialize (H F3_2 F3_1). unfold magma_op, refa208_inst, refa208_op in H. discriminate H. Qed.

Lemma refa208_not1251 : ~ @Equation1251 Fin3 refa208_inst.
Proof. unfold Equation1251. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa208_inst, refa208_op in H. discriminate H. Qed.

Lemma refa208_not4598 : ~ @Equation4598 Fin3 refa208_inst.
Proof. unfold Equation4598. intro H. specialize (H F3_2 F3_1). unfold magma_op, refa208_inst, refa208_op in H. discriminate H. Qed.

(** ---- refa209 (Fin3) ---- *)

Definition refa209_op (x y : Fin3) : Fin3 :=
  match x, y with
  | F3_0, F3_0 => F3_0 | F3_0, F3_1 => F3_1 | F3_0, F3_2 => F3_1
  | F3_1, F3_0 => F3_0 | F3_1, F3_1 => F3_1 | F3_1, F3_2 => F3_2
  | F3_2, F3_0 => F3_1 | F3_2, F3_1 => F3_1 | F3_2, F3_2 => F3_2
  end.

#[local] Instance refa209_inst : Magma Fin3 := {| magma_op := refa209_op |}.

Lemma refa209_sat2499 : @Equation2499 Fin3 refa209_inst.
Proof. unfold Equation2499, magma_op, refa209_inst, refa209_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa209_not55 : ~ @Equation55 Fin3 refa209_inst.
Proof. unfold Equation55. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa209_inst, refa209_op in H. discriminate H. Qed.

Lemma refa209_not65 : ~ @Equation65 Fin3 refa209_inst.
Proof. unfold Equation65. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa209_inst, refa209_op in H. discriminate H. Qed.

Lemma refa209_not75 : ~ @Equation75 Fin3 refa209_inst.
Proof. unfold Equation75. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa209_inst, refa209_op in H. discriminate H. Qed.

Lemma refa209_not107 : ~ @Equation107 Fin3 refa209_inst.
Proof. unfold Equation107. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa209_inst, refa209_op in H. discriminate H. Qed.

Lemma refa209_not124 : ~ @Equation124 Fin3 refa209_inst.
Proof. unfold Equation124. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa209_inst, refa209_op in H. discriminate H. Qed.

Lemma refa209_not127 : ~ @Equation127 Fin3 refa209_inst.
Proof. unfold Equation127. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa209_inst, refa209_op in H. discriminate H. Qed.

Lemma refa209_not159 : ~ @Equation159 Fin3 refa209_inst.
Proof. unfold Equation159. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa209_inst, refa209_op in H. discriminate H. Qed.

Lemma refa209_not231 : ~ @Equation231 Fin3 refa209_inst.
Proof. unfold Equation231. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa209_inst, refa209_op in H. discriminate H. Qed.

Lemma refa209_not263 : ~ @Equation263 Fin3 refa209_inst.
Proof. unfold Equation263. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa209_inst, refa209_op in H. discriminate H. Qed.

Lemma refa209_not273 : ~ @Equation273 Fin3 refa209_inst.
Proof. unfold Equation273. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa209_inst, refa209_op in H. discriminate H. Qed.

Lemma refa209_not283 : ~ @Equation283 Fin3 refa209_inst.
Proof. unfold Equation283. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa209_inst, refa209_op in H. discriminate H. Qed.

Lemma refa209_not413 : ~ @Equation413 Fin3 refa209_inst.
Proof. unfold Equation413. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa209_inst, refa209_op in H. discriminate H. Qed.

Lemma refa209_not416 : ~ @Equation416 Fin3 refa209_inst.
Proof. unfold Equation416. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa209_inst, refa209_op in H. discriminate H. Qed.

Lemma refa209_not419 : ~ @Equation419 Fin3 refa209_inst.
Proof. unfold Equation419. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa209_inst, refa209_op in H. discriminate H. Qed.

Lemma refa209_not426 : ~ @Equation426 Fin3 refa209_inst.
Proof. unfold Equation426. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa209_inst, refa209_op in H. discriminate H. Qed.

Lemma refa209_not429 : ~ @Equation429 Fin3 refa209_inst.
Proof. unfold Equation429. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa209_inst, refa209_op in H. discriminate H. Qed.

Lemma refa209_not436 : ~ @Equation436 Fin3 refa209_inst.
Proof. unfold Equation436. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa209_inst, refa209_op in H. discriminate H. Qed.

Lemma refa209_not439 : ~ @Equation439 Fin3 refa209_inst.
Proof. unfold Equation439. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa209_inst, refa209_op in H. discriminate H. Qed.

Lemma refa209_not466 : ~ @Equation466 Fin3 refa209_inst.
Proof. unfold Equation466. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa209_inst, refa209_op in H. discriminate H. Qed.

Lemma refa209_not473 : ~ @Equation473 Fin3 refa209_inst.
Proof. unfold Equation473. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa209_inst, refa209_op in H. discriminate H. Qed.

Lemma refa209_not476 : ~ @Equation476 Fin3 refa209_inst.
Proof. unfold Equation476. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa209_inst, refa209_op in H. discriminate H. Qed.

Lemma refa209_not503 : ~ @Equation503 Fin3 refa209_inst.
Proof. unfold Equation503. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa209_inst, refa209_op in H. discriminate H. Qed.

Lemma refa209_not513 : ~ @Equation513 Fin3 refa209_inst.
Proof. unfold Equation513. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa209_inst, refa209_op in H. discriminate H. Qed.

Lemma refa209_not622 : ~ @Equation622 Fin3 refa209_inst.
Proof. unfold Equation622. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa209_inst, refa209_op in H. discriminate H. Qed.

Lemma refa209_not629 : ~ @Equation629 Fin3 refa209_inst.
Proof. unfold Equation629. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa209_inst, refa209_op in H. discriminate H. Qed.

Lemma refa209_not632 : ~ @Equation632 Fin3 refa209_inst.
Proof. unfold Equation632. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa209_inst, refa209_op in H. discriminate H. Qed.

Lemma refa209_not639 : ~ @Equation639 Fin3 refa209_inst.
Proof. unfold Equation639. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa209_inst, refa209_op in H. discriminate H. Qed.

Lemma refa209_not642 : ~ @Equation642 Fin3 refa209_inst.
Proof. unfold Equation642. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa209_inst, refa209_op in H. discriminate H. Qed.

Lemma refa209_not669 : ~ @Equation669 Fin3 refa209_inst.
Proof. unfold Equation669. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa209_inst, refa209_op in H. discriminate H. Qed.

Lemma refa209_not676 : ~ @Equation676 Fin3 refa209_inst.
Proof. unfold Equation676. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa209_inst, refa209_op in H. discriminate H. Qed.

Lemma refa209_not679 : ~ @Equation679 Fin3 refa209_inst.
Proof. unfold Equation679. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa209_inst, refa209_op in H. discriminate H. Qed.

Lemma refa209_not706 : ~ @Equation706 Fin3 refa209_inst.
Proof. unfold Equation706. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa209_inst, refa209_op in H. discriminate H. Qed.

Lemma refa209_not713 : ~ @Equation713 Fin3 refa209_inst.
Proof. unfold Equation713. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa209_inst, refa209_op in H. discriminate H. Qed.

Lemma refa209_not716 : ~ @Equation716 Fin3 refa209_inst.
Proof. unfold Equation716. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa209_inst, refa209_op in H. discriminate H. Qed.

Lemma refa209_not819 : ~ @Equation819 Fin3 refa209_inst.
Proof. unfold Equation819. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa209_inst, refa209_op in H. discriminate H. Qed.

Lemma refa209_not825 : ~ @Equation825 Fin3 refa209_inst.
Proof. unfold Equation825. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa209_inst, refa209_op in H. discriminate H. Qed.

Lemma refa209_not835 : ~ @Equation835 Fin3 refa209_inst.
Proof. unfold Equation835. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa209_inst, refa209_op in H. discriminate H. Qed.

Lemma refa209_not842 : ~ @Equation842 Fin3 refa209_inst.
Proof. unfold Equation842. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa209_inst, refa209_op in H. discriminate H. Qed.

Lemma refa209_not845 : ~ @Equation845 Fin3 refa209_inst.
Proof. unfold Equation845. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa209_inst, refa209_op in H. discriminate H. Qed.

Lemma refa209_not872 : ~ @Equation872 Fin3 refa209_inst.
Proof. unfold Equation872. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa209_inst, refa209_op in H. discriminate H. Qed.

Lemma refa209_not879 : ~ @Equation879 Fin3 refa209_inst.
Proof. unfold Equation879. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa209_inst, refa209_op in H. discriminate H. Qed.

Lemma refa209_not882 : ~ @Equation882 Fin3 refa209_inst.
Proof. unfold Equation882. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa209_inst, refa209_op in H. discriminate H. Qed.

Lemma refa209_not906 : ~ @Equation906 Fin3 refa209_inst.
Proof. unfold Equation906. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa209_inst, refa209_op in H. discriminate H. Qed.

Lemma refa209_not1048 : ~ @Equation1048 Fin3 refa209_inst.
Proof. unfold Equation1048. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa209_inst, refa209_op in H. discriminate H. Qed.

Lemma refa209_not1075 : ~ @Equation1075 Fin3 refa209_inst.
Proof. unfold Equation1075. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa209_inst, refa209_op in H. discriminate H. Qed.

Lemma refa209_not1082 : ~ @Equation1082 Fin3 refa209_inst.
Proof. unfold Equation1082. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa209_inst, refa209_op in H. discriminate H. Qed.

Lemma refa209_not1085 : ~ @Equation1085 Fin3 refa209_inst.
Proof. unfold Equation1085. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa209_inst, refa209_op in H. discriminate H. Qed.

Lemma refa209_not1109 : ~ @Equation1109 Fin3 refa209_inst.
Proof. unfold Equation1109. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa209_inst, refa209_op in H. discriminate H. Qed.

Lemma refa209_not1112 : ~ @Equation1112 Fin3 refa209_inst.
Proof. unfold Equation1112. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa209_inst, refa209_op in H. discriminate H. Qed.

Lemma refa209_not1119 : ~ @Equation1119 Fin3 refa209_inst.
Proof. unfold Equation1119. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa209_inst, refa209_op in H. discriminate H. Qed.

Lemma refa209_not1122 : ~ @Equation1122 Fin3 refa209_inst.
Proof. unfold Equation1122. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa209_inst, refa209_op in H. discriminate H. Qed.

Lemma refa209_not1231 : ~ @Equation1231 Fin3 refa209_inst.
Proof. unfold Equation1231. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa209_inst, refa209_op in H. discriminate H. Qed.

Lemma refa209_not1241 : ~ @Equation1241 Fin3 refa209_inst.
Proof. unfold Equation1241. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa209_inst, refa209_op in H. discriminate H. Qed.

Lemma refa209_not1251 : ~ @Equation1251 Fin3 refa209_inst.
Proof. unfold Equation1251. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa209_inst, refa209_op in H. discriminate H. Qed.

Lemma refa209_not1278 : ~ @Equation1278 Fin3 refa209_inst.
Proof. unfold Equation1278. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa209_inst, refa209_op in H. discriminate H. Qed.

Lemma refa209_not1285 : ~ @Equation1285 Fin3 refa209_inst.
Proof. unfold Equation1285. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa209_inst, refa209_op in H. discriminate H. Qed.

Lemma refa209_not1288 : ~ @Equation1288 Fin3 refa209_inst.
Proof. unfold Equation1288. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa209_inst, refa209_op in H. discriminate H. Qed.

Lemma refa209_not1312 : ~ @Equation1312 Fin3 refa209_inst.
Proof. unfold Equation1312. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa209_inst, refa209_op in H. discriminate H. Qed.

Lemma refa209_not1315 : ~ @Equation1315 Fin3 refa209_inst.
Proof. unfold Equation1315. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa209_inst, refa209_op in H. discriminate H. Qed.

Lemma refa209_not1322 : ~ @Equation1322 Fin3 refa209_inst.
Proof. unfold Equation1322. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa209_inst, refa209_op in H. discriminate H. Qed.

Lemma refa209_not1428 : ~ @Equation1428 Fin3 refa209_inst.
Proof. unfold Equation1428. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa209_inst, refa209_op in H. discriminate H. Qed.

Lemma refa209_not1431 : ~ @Equation1431 Fin3 refa209_inst.
Proof. unfold Equation1431. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa209_inst, refa209_op in H. discriminate H. Qed.

Lemma refa209_not1434 : ~ @Equation1434 Fin3 refa209_inst.
Proof. unfold Equation1434. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa209_inst, refa209_op in H. discriminate H. Qed.

Lemma refa209_not1444 : ~ @Equation1444 Fin3 refa209_inst.
Proof. unfold Equation1444. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa209_inst, refa209_op in H. discriminate H. Qed.

Lemma refa209_not1451 : ~ @Equation1451 Fin3 refa209_inst.
Proof. unfold Equation1451. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa209_inst, refa209_op in H. discriminate H. Qed.

Lemma refa209_not1454 : ~ @Equation1454 Fin3 refa209_inst.
Proof. unfold Equation1454. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa209_inst, refa209_op in H. discriminate H. Qed.

Lemma refa209_not1488 : ~ @Equation1488 Fin3 refa209_inst.
Proof. unfold Equation1488. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa209_inst, refa209_op in H. discriminate H. Qed.

Lemma refa209_not1491 : ~ @Equation1491 Fin3 refa209_inst.
Proof. unfold Equation1491. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa209_inst, refa209_op in H. discriminate H. Qed.

Lemma refa209_not1515 : ~ @Equation1515 Fin3 refa209_inst.
Proof. unfold Equation1515. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa209_inst, refa209_op in H. discriminate H. Qed.

Lemma refa209_not1518 : ~ @Equation1518 Fin3 refa209_inst.
Proof. unfold Equation1518. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa209_inst, refa209_op in H. discriminate H. Qed.

Lemma refa209_not1525 : ~ @Equation1525 Fin3 refa209_inst.
Proof. unfold Equation1525. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa209_inst, refa209_op in H. discriminate H. Qed.

Lemma refa209_not1637 : ~ @Equation1637 Fin3 refa209_inst.
Proof. unfold Equation1637. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa209_inst, refa209_op in H. discriminate H. Qed.

Lemma refa209_not1657 : ~ @Equation1657 Fin3 refa209_inst.
Proof. unfold Equation1657. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa209_inst, refa209_op in H. discriminate H. Qed.

Lemma refa209_not1694 : ~ @Equation1694 Fin3 refa209_inst.
Proof. unfold Equation1694. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa209_inst, refa209_op in H. discriminate H. Qed.

Lemma refa209_not1721 : ~ @Equation1721 Fin3 refa209_inst.
Proof. unfold Equation1721. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa209_inst, refa209_op in H. discriminate H. Qed.

Lemma refa209_not1728 : ~ @Equation1728 Fin3 refa209_inst.
Proof. unfold Equation1728. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa209_inst, refa209_op in H. discriminate H. Qed.

Lemma refa209_not1731 : ~ @Equation1731 Fin3 refa209_inst.
Proof. unfold Equation1731. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa209_inst, refa209_op in H. discriminate H. Qed.

Lemma refa209_not1834 : ~ @Equation1834 Fin3 refa209_inst.
Proof. unfold Equation1834. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa209_inst, refa209_op in H. discriminate H. Qed.

Lemma refa209_not1840 : ~ @Equation1840 Fin3 refa209_inst.
Proof. unfold Equation1840. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa209_inst, refa209_op in H. discriminate H. Qed.

Lemma refa209_not1860 : ~ @Equation1860 Fin3 refa209_inst.
Proof. unfold Equation1860. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa209_inst, refa209_op in H. discriminate H. Qed.

Lemma refa209_not1887 : ~ @Equation1887 Fin3 refa209_inst.
Proof. unfold Equation1887. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa209_inst, refa209_op in H. discriminate H. Qed.

Lemma refa209_not1897 : ~ @Equation1897 Fin3 refa209_inst.
Proof. unfold Equation1897. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa209_inst, refa209_op in H. discriminate H. Qed.

Lemma refa209_not1924 : ~ @Equation1924 Fin3 refa209_inst.
Proof. unfold Equation1924. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa209_inst, refa209_op in H. discriminate H. Qed.

Lemma refa209_not1931 : ~ @Equation1931 Fin3 refa209_inst.
Proof. unfold Equation1931. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa209_inst, refa209_op in H. discriminate H. Qed.

Lemma refa209_not2037 : ~ @Equation2037 Fin3 refa209_inst.
Proof. unfold Equation2037. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa209_inst, refa209_op in H. discriminate H. Qed.

Lemma refa209_not2043 : ~ @Equation2043 Fin3 refa209_inst.
Proof. unfold Equation2043. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa209_inst, refa209_op in H. discriminate H. Qed.

Lemma refa209_not2053 : ~ @Equation2053 Fin3 refa209_inst.
Proof. unfold Equation2053. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa209_inst, refa209_op in H. discriminate H. Qed.

Lemma refa209_not2060 : ~ @Equation2060 Fin3 refa209_inst.
Proof. unfold Equation2060. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa209_inst, refa209_op in H. discriminate H. Qed.

Lemma refa209_not2063 : ~ @Equation2063 Fin3 refa209_inst.
Proof. unfold Equation2063. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa209_inst, refa209_op in H. discriminate H. Qed.

Lemma refa209_not2097 : ~ @Equation2097 Fin3 refa209_inst.
Proof. unfold Equation2097. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa209_inst, refa209_op in H. discriminate H. Qed.

Lemma refa209_not2100 : ~ @Equation2100 Fin3 refa209_inst.
Proof. unfold Equation2100. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa209_inst, refa209_op in H. discriminate H. Qed.

Lemma refa209_not2127 : ~ @Equation2127 Fin3 refa209_inst.
Proof. unfold Equation2127. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa209_inst, refa209_op in H. discriminate H. Qed.

Lemma refa209_not2134 : ~ @Equation2134 Fin3 refa209_inst.
Proof. unfold Equation2134. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa209_inst, refa209_op in H. discriminate H. Qed.

Lemma refa209_not2137 : ~ @Equation2137 Fin3 refa209_inst.
Proof. unfold Equation2137. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa209_inst, refa209_op in H. discriminate H. Qed.

Lemma refa209_not2340 : ~ @Equation2340 Fin3 refa209_inst.
Proof. unfold Equation2340. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa209_inst, refa209_op in H. discriminate H. Qed.

Lemma refa209_not2506 : ~ @Equation2506 Fin3 refa209_inst.
Proof. unfold Equation2506. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa209_inst, refa209_op in H. discriminate H. Qed.

Lemma refa209_not2533 : ~ @Equation2533 Fin3 refa209_inst.
Proof. unfold Equation2533. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa209_inst, refa209_op in H. discriminate H. Qed.

Lemma refa209_not2543 : ~ @Equation2543 Fin3 refa209_inst.
Proof. unfold Equation2543. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa209_inst, refa209_op in H. discriminate H. Qed.

Lemma refa209_not2672 : ~ @Equation2672 Fin3 refa209_inst.
Proof. unfold Equation2672. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa209_inst, refa209_op in H. discriminate H. Qed.

Lemma refa209_not2709 : ~ @Equation2709 Fin3 refa209_inst.
Proof. unfold Equation2709. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa209_inst, refa209_op in H. discriminate H. Qed.

Lemma refa209_not2746 : ~ @Equation2746 Fin3 refa209_inst.
Proof. unfold Equation2746. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa209_inst, refa209_op in H. discriminate H. Qed.

Lemma refa209_not2855 : ~ @Equation2855 Fin3 refa209_inst.
Proof. unfold Equation2855. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa209_inst, refa209_op in H. discriminate H. Qed.

Lemma refa209_not2865 : ~ @Equation2865 Fin3 refa209_inst.
Proof. unfold Equation2865. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa209_inst, refa209_op in H. discriminate H. Qed.

Lemma refa209_not2875 : ~ @Equation2875 Fin3 refa209_inst.
Proof. unfold Equation2875. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa209_inst, refa209_op in H. discriminate H. Qed.

Lemma refa209_not2902 : ~ @Equation2902 Fin3 refa209_inst.
Proof. unfold Equation2902. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa209_inst, refa209_op in H. discriminate H. Qed.

Lemma refa209_not2912 : ~ @Equation2912 Fin3 refa209_inst.
Proof. unfold Equation2912. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa209_inst, refa209_op in H. discriminate H. Qed.

Lemma refa209_not2939 : ~ @Equation2939 Fin3 refa209_inst.
Proof. unfold Equation2939. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa209_inst, refa209_op in H. discriminate H. Qed.

Lemma refa209_not2949 : ~ @Equation2949 Fin3 refa209_inst.
Proof. unfold Equation2949. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa209_inst, refa209_op in H. discriminate H. Qed.

Lemma refa209_not3058 : ~ @Equation3058 Fin3 refa209_inst.
Proof. unfold Equation3058. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa209_inst, refa209_op in H. discriminate H. Qed.

Lemma refa209_not3078 : ~ @Equation3078 Fin3 refa209_inst.
Proof. unfold Equation3078. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa209_inst, refa209_op in H. discriminate H. Qed.

Lemma refa209_not3115 : ~ @Equation3115 Fin3 refa209_inst.
Proof. unfold Equation3115. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa209_inst, refa209_op in H. discriminate H. Qed.

Lemma refa209_not3142 : ~ @Equation3142 Fin3 refa209_inst.
Proof. unfold Equation3142. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa209_inst, refa209_op in H. discriminate H. Qed.

Lemma refa209_not3152 : ~ @Equation3152 Fin3 refa209_inst.
Proof. unfold Equation3152. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa209_inst, refa209_op in H. discriminate H. Qed.

Lemma refa209_not3255 : ~ @Equation3255 Fin3 refa209_inst.
Proof. unfold Equation3255. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa209_inst, refa209_op in H. discriminate H. Qed.

Lemma refa209_not3256 : ~ @Equation3256 Fin3 refa209_inst.
Proof. unfold Equation3256. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa209_inst, refa209_op in H. discriminate H. Qed.

Lemma refa209_not3258 : ~ @Equation3258 Fin3 refa209_inst.
Proof. unfold Equation3258. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa209_inst, refa209_op in H. discriminate H. Qed.

Lemma refa209_not3261 : ~ @Equation3261 Fin3 refa209_inst.
Proof. unfold Equation3261. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa209_inst, refa209_op in H. discriminate H. Qed.

Lemma refa209_not3268 : ~ @Equation3268 Fin3 refa209_inst.
Proof. unfold Equation3268. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa209_inst, refa209_op in H. discriminate H. Qed.

Lemma refa209_not3271 : ~ @Equation3271 Fin3 refa209_inst.
Proof. unfold Equation3271. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa209_inst, refa209_op in H. discriminate H. Qed.

Lemma refa209_not3278 : ~ @Equation3278 Fin3 refa209_inst.
Proof. unfold Equation3278. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa209_inst, refa209_op in H. discriminate H. Qed.

Lemma refa209_not3281 : ~ @Equation3281 Fin3 refa209_inst.
Proof. unfold Equation3281. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa209_inst, refa209_op in H. discriminate H. Qed.

Lemma refa209_not3464 : ~ @Equation3464 Fin3 refa209_inst.
Proof. unfold Equation3464. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa209_inst, refa209_op in H. discriminate H. Qed.

Lemma refa209_not3474 : ~ @Equation3474 Fin3 refa209_inst.
Proof. unfold Equation3474. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa209_inst, refa209_op in H. discriminate H. Qed.

Lemma refa209_not3481 : ~ @Equation3481 Fin3 refa209_inst.
Proof. unfold Equation3481. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa209_inst, refa209_op in H. discriminate H. Qed.

Lemma refa209_not3484 : ~ @Equation3484 Fin3 refa209_inst.
Proof. unfold Equation3484. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa209_inst, refa209_op in H. discriminate H. Qed.

Lemma refa209_not3515 : ~ @Equation3515 Fin3 refa209_inst.
Proof. unfold Equation3515. intro H. specialize (H F3_1 F3_0 F3_2). unfold magma_op, refa209_inst, refa209_op in H. discriminate H. Qed.

Lemma refa209_not3549 : ~ @Equation3549 Fin3 refa209_inst.
Proof. unfold Equation3549. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa209_inst, refa209_op in H. discriminate H. Qed.

Lemma refa209_not3556 : ~ @Equation3556 Fin3 refa209_inst.
Proof. unfold Equation3556. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa209_inst, refa209_op in H. discriminate H. Qed.

Lemma refa209_not3661 : ~ @Equation3661 Fin3 refa209_inst.
Proof. unfold Equation3661. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa209_inst, refa209_op in H. discriminate H. Qed.

Lemma refa209_not3667 : ~ @Equation3667 Fin3 refa209_inst.
Proof. unfold Equation3667. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa209_inst, refa209_op in H. discriminate H. Qed.

Lemma refa209_not3677 : ~ @Equation3677 Fin3 refa209_inst.
Proof. unfold Equation3677. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa209_inst, refa209_op in H. discriminate H. Qed.

Lemma refa209_not3684 : ~ @Equation3684 Fin3 refa209_inst.
Proof. unfold Equation3684. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa209_inst, refa209_op in H. discriminate H. Qed.

Lemma refa209_not3687 : ~ @Equation3687 Fin3 refa209_inst.
Proof. unfold Equation3687. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa209_inst, refa209_op in H. discriminate H. Qed.

Lemma refa209_not3725 : ~ @Equation3725 Fin3 refa209_inst.
Proof. unfold Equation3725. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa209_inst, refa209_op in H. discriminate H. Qed.

Lemma refa209_not3732 : ~ @Equation3732 Fin3 refa209_inst.
Proof. unfold Equation3732. intro H. specialize (H F3_1 F3_0 F3_2). unfold magma_op, refa209_inst, refa209_op in H. discriminate H. Qed.

Lemma refa209_not3752 : ~ @Equation3752 Fin3 refa209_inst.
Proof. unfold Equation3752. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa209_inst, refa209_op in H. discriminate H. Qed.

Lemma refa209_not3890 : ~ @Equation3890 Fin3 refa209_inst.
Proof. unfold Equation3890. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa209_inst, refa209_op in H. discriminate H. Qed.

Lemma refa209_not3918 : ~ @Equation3918 Fin3 refa209_inst.
Proof. unfold Equation3918. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa209_inst, refa209_op in H. discriminate H. Qed.

Lemma refa209_not3925 : ~ @Equation3925 Fin3 refa209_inst.
Proof. unfold Equation3925. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa209_inst, refa209_op in H. discriminate H. Qed.

Lemma refa209_not3928 : ~ @Equation3928 Fin3 refa209_inst.
Proof. unfold Equation3928. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa209_inst, refa209_op in H. discriminate H. Qed.

Lemma refa209_not3952 : ~ @Equation3952 Fin3 refa209_inst.
Proof. unfold Equation3952. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa209_inst, refa209_op in H. discriminate H. Qed.

Lemma refa209_not3955 : ~ @Equation3955 Fin3 refa209_inst.
Proof. unfold Equation3955. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa209_inst, refa209_op in H. discriminate H. Qed.

Lemma refa209_not3962 : ~ @Equation3962 Fin3 refa209_inst.
Proof. unfold Equation3962. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa209_inst, refa209_op in H. discriminate H. Qed.

Lemma refa209_not4073 : ~ @Equation4073 Fin3 refa209_inst.
Proof. unfold Equation4073. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa209_inst, refa209_op in H. discriminate H. Qed.

Lemma refa209_not4083 : ~ @Equation4083 Fin3 refa209_inst.
Proof. unfold Equation4083. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa209_inst, refa209_op in H. discriminate H. Qed.

Lemma refa209_not4093 : ~ @Equation4093 Fin3 refa209_inst.
Proof. unfold Equation4093. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa209_inst, refa209_op in H. discriminate H. Qed.

Lemma refa209_not4121 : ~ @Equation4121 Fin3 refa209_inst.
Proof. unfold Equation4121. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa209_inst, refa209_op in H. discriminate H. Qed.

Lemma refa209_not4131 : ~ @Equation4131 Fin3 refa209_inst.
Proof. unfold Equation4131. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa209_inst, refa209_op in H. discriminate H. Qed.

Lemma refa209_not4158 : ~ @Equation4158 Fin3 refa209_inst.
Proof. unfold Equation4158. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa209_inst, refa209_op in H. discriminate H. Qed.

Lemma refa209_not4165 : ~ @Equation4165 Fin3 refa209_inst.
Proof. unfold Equation4165. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa209_inst, refa209_op in H. discriminate H. Qed.

Lemma refa209_not4269 : ~ @Equation4269 Fin3 refa209_inst.
Proof. unfold Equation4269. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa209_inst, refa209_op in H. discriminate H. Qed.

Lemma refa209_not4272 : ~ @Equation4272 Fin3 refa209_inst.
Proof. unfold Equation4272. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa209_inst, refa209_op in H. discriminate H. Qed.

Lemma refa209_not4275 : ~ @Equation4275 Fin3 refa209_inst.
Proof. unfold Equation4275. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa209_inst, refa209_op in H. discriminate H. Qed.

Lemma refa209_not4399 : ~ @Equation4399 Fin3 refa209_inst.
Proof. unfold Equation4399. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa209_inst, refa209_op in H. discriminate H. Qed.

Lemma refa209_not4406 : ~ @Equation4406 Fin3 refa209_inst.
Proof. unfold Equation4406. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa209_inst, refa209_op in H. discriminate H. Qed.

Lemma refa209_not4435 : ~ @Equation4435 Fin3 refa209_inst.
Proof. unfold Equation4435. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa209_inst, refa209_op in H. discriminate H. Qed.

Lemma refa209_not4442 : ~ @Equation4442 Fin3 refa209_inst.
Proof. unfold Equation4442. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa209_inst, refa209_op in H. discriminate H. Qed.

Lemma refa209_not4473 : ~ @Equation4473 Fin3 refa209_inst.
Proof. unfold Equation4473. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa209_inst, refa209_op in H. discriminate H. Qed.

Lemma refa209_not4480 : ~ @Equation4480 Fin3 refa209_inst.
Proof. unfold Equation4480. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa209_inst, refa209_op in H. discriminate H. Qed.

Lemma refa209_not4590 : ~ @Equation4590 Fin3 refa209_inst.
Proof. unfold Equation4590. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa209_inst, refa209_op in H. discriminate H. Qed.

Lemma refa209_not4599 : ~ @Equation4599 Fin3 refa209_inst.
Proof. unfold Equation4599. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa209_inst, refa209_op in H. discriminate H. Qed.

Lemma refa209_not4606 : ~ @Equation4606 Fin3 refa209_inst.
Proof. unfold Equation4606. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa209_inst, refa209_op in H. discriminate H. Qed.

Lemma refa209_not4677 : ~ @Equation4677 Fin3 refa209_inst.
Proof. unfold Equation4677. intro H. specialize (H F3_0 F3_1 F3_2). unfold magma_op, refa209_inst, refa209_op in H. discriminate H. Qed.

(** ---- refa21 (Fin7) ---- *)

Definition refa21_op (x y : Fin7) : Fin7 :=
  match x, y with
  | F7_0, F7_0 => F7_1 | F7_0, F7_1 => F7_2 | F7_0, F7_2 => F7_0 | F7_0, F7_3 => F7_3 | F7_0, F7_4 => F7_6 | F7_0, F7_5 => F7_4 | F7_0, F7_6 => F7_5
  | F7_1, F7_0 => F7_4 | F7_1, F7_1 => F7_1 | F7_1, F7_2 => F7_6 | F7_1, F7_3 => F7_2 | F7_1, F7_4 => F7_5 | F7_1, F7_5 => F7_0 | F7_1, F7_6 => F7_3
  | F7_2, F7_0 => F7_3 | F7_2, F7_1 => F7_5 | F7_2, F7_2 => F7_1 | F7_2, F7_3 => F7_6 | F7_2, F7_4 => F7_4 | F7_2, F7_5 => F7_2 | F7_2, F7_6 => F7_0
  | F7_3, F7_0 => F7_0 | F7_3, F7_1 => F7_4 | F7_3, F7_2 => F7_5 | F7_3, F7_3 => F7_1 | F7_3, F7_4 => F7_3 | F7_3, F7_5 => F7_6 | F7_3, F7_6 => F7_2
  | F7_4, F7_0 => F7_5 | F7_4, F7_1 => F7_6 | F7_4, F7_2 => F7_2 | F7_4, F7_3 => F7_0 | F7_4, F7_4 => F7_1 | F7_4, F7_5 => F7_3 | F7_4, F7_6 => F7_4
  | F7_5, F7_0 => F7_2 | F7_5, F7_1 => F7_3 | F7_5, F7_2 => F7_4 | F7_5, F7_3 => F7_5 | F7_5, F7_4 => F7_0 | F7_5, F7_5 => F7_1 | F7_5, F7_6 => F7_6
  | F7_6, F7_0 => F7_6 | F7_6, F7_1 => F7_0 | F7_6, F7_2 => F7_3 | F7_6, F7_3 => F7_4 | F7_6, F7_4 => F7_2 | F7_6, F7_5 => F7_5 | F7_6, F7_6 => F7_1
  end.

#[local] Instance refa21_inst : Magma Fin7 := {| magma_op := refa21_op |}.

Lemma refa21_sat2910 : @Equation2910 Fin7 refa21_inst.
Proof. unfold Equation2910, magma_op, refa21_inst, refa21_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa21_not56 : ~ @Equation56 Fin7 refa21_inst.
Proof. unfold Equation56. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa21_inst, refa21_op in H. discriminate H. Qed.

Lemma refa21_not2035 : ~ @Equation2035 Fin7 refa21_inst.
Proof. unfold Equation2035. intro H. specialize (H F7_0). unfold magma_op, refa21_inst, refa21_op in H. discriminate H. Qed.

Lemma refa21_not2644 : ~ @Equation2644 Fin7 refa21_inst.
Proof. unfold Equation2644. intro H. specialize (H F7_0). unfold magma_op, refa21_inst, refa21_op in H. discriminate H. Qed.

(** ---- refa210 (Fin3) ---- *)

Definition refa210_op (x y : Fin3) : Fin3 :=
  match x, y with
  | F3_0, F3_0 => F3_1 | F3_0, F3_1 => F3_0 | F3_0, F3_2 => F3_0
  | F3_1, F3_0 => F3_1 | F3_1, F3_1 => F3_2 | F3_1, F3_2 => F3_0
  | F3_2, F3_0 => F3_0 | F3_2, F3_1 => F3_2 | F3_2, F3_2 => F3_0
  end.

#[local] Instance refa210_inst : Magma Fin3 := {| magma_op := refa210_op |}.

Lemma refa210_sat819 : @Equation819 Fin3 refa210_inst.
Proof. unfold Equation819, magma_op, refa210_inst, refa210_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa210_not3862 : ~ @Equation3862 Fin3 refa210_inst.
Proof. unfold Equation3862. intro H. specialize (H F3_1). unfold magma_op, refa210_inst, refa210_op in H. discriminate H. Qed.

(** ---- refa211 (Fin3) ---- *)

Definition refa211_op (x y : Fin3) : Fin3 :=
  match x, y with
  | F3_0, F3_0 => F3_0 | F3_0, F3_1 => F3_0 | F3_0, F3_2 => F3_0
  | F3_1, F3_0 => F3_0 | F3_1, F3_1 => F3_0 | F3_1, F3_2 => F3_1
  | F3_2, F3_0 => F3_2 | F3_2, F3_1 => F3_2 | F3_2, F3_2 => F3_2
  end.

#[local] Instance refa211_inst : Magma Fin3 := {| magma_op := refa211_op |}.

Lemma refa211_sat3931 : @Equation3931 Fin3 refa211_inst.
Proof. unfold Equation3931, magma_op, refa211_inst, refa211_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa211_sat4072 : @Equation4072 Fin3 refa211_inst.
Proof. unfold Equation4072, magma_op, refa211_inst, refa211_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa211_sat4397 : @Equation4397 Fin3 refa211_inst.
Proof. unfold Equation4397, magma_op, refa211_inst, refa211_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa211_sat4401 : @Equation4401 Fin3 refa211_inst.
Proof. unfold Equation4401, magma_op, refa211_inst, refa211_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa211_sat4601 : @Equation4601 Fin3 refa211_inst.
Proof. unfold Equation4601, magma_op, refa211_inst, refa211_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa211_not3915 : ~ @Equation3915 Fin3 refa211_inst.
Proof. unfold Equation3915. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa211_inst, refa211_op in H. discriminate H. Qed.

Lemma refa211_not4269 : ~ @Equation4269 Fin3 refa211_inst.
Proof. unfold Equation4269. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa211_inst, refa211_op in H. discriminate H. Qed.

Lemma refa211_not4270 : ~ @Equation4270 Fin3 refa211_inst.
Proof. unfold Equation4270. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa211_inst, refa211_op in H. discriminate H. Qed.

Lemma refa211_not4283 : ~ @Equation4283 Fin3 refa211_inst.
Proof. unfold Equation4283. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa211_inst, refa211_op in H. discriminate H. Qed.

Lemma refa211_not4284 : ~ @Equation4284 Fin3 refa211_inst.
Proof. unfold Equation4284. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa211_inst, refa211_op in H. discriminate H. Qed.

Lemma refa211_not4435 : ~ @Equation4435 Fin3 refa211_inst.
Proof. unfold Equation4435. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa211_inst, refa211_op in H. discriminate H. Qed.

Lemma refa211_not4470 : ~ @Equation4470 Fin3 refa211_inst.
Proof. unfold Equation4470. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa211_inst, refa211_op in H. discriminate H. Qed.

Lemma refa211_not4472 : ~ @Equation4472 Fin3 refa211_inst.
Proof. unfold Equation4472. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa211_inst, refa211_op in H. discriminate H. Qed.

(** ---- refa212 (Fin3) ---- *)

Definition refa212_op (x y : Fin3) : Fin3 :=
  match x, y with
  | F3_0, F3_0 => F3_0 | F3_0, F3_1 => F3_0 | F3_0, F3_2 => F3_2
  | F3_1, F3_0 => F3_1 | F3_1, F3_1 => F3_2 | F3_1, F3_2 => F3_2
  | F3_2, F3_0 => F3_0 | F3_2, F3_1 => F3_0 | F3_2, F3_2 => F3_2
  end.

#[local] Instance refa212_inst : Magma Fin3 := {| magma_op := refa212_op |}.

Lemma refa212_sat1041 : @Equation1041 Fin3 refa212_inst.
Proof. unfold Equation1041, magma_op, refa212_inst, refa212_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa212_not1028 : ~ @Equation1028 Fin3 refa212_inst.
Proof. unfold Equation1028. intro H. specialize (H F3_1 F3_0). unfold magma_op, refa212_inst, refa212_op in H. discriminate H. Qed.

(** ---- refa213 (Fin3) ---- *)

Definition refa213_op (x y : Fin3) : Fin3 :=
  match x, y with
  | F3_0, F3_0 => F3_1 | F3_0, F3_1 => F3_2 | F3_0, F3_2 => F3_0
  | F3_1, F3_0 => F3_1 | F3_1, F3_1 => F3_2 | F3_1, F3_2 => F3_0
  | F3_2, F3_0 => F3_1 | F3_2, F3_1 => F3_2 | F3_2, F3_2 => F3_0
  end.

#[local] Instance refa213_inst : Magma Fin3 := {| magma_op := refa213_op |}.

Lemma refa213_sat1539 : @Equation1539 Fin3 refa213_inst.
Proof. unfold Equation1539, magma_op, refa213_inst, refa213_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa213_not56 : ~ @Equation56 Fin3 refa213_inst.
Proof. unfold Equation56. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa213_inst, refa213_op in H. discriminate H. Qed.

Lemma refa213_not99 : ~ @Equation99 Fin3 refa213_inst.
Proof. unfold Equation99. intro H. specialize (H F3_0). unfold magma_op, refa213_inst, refa213_op in H. discriminate H. Qed.

Lemma refa213_not151 : ~ @Equation151 Fin3 refa213_inst.
Proof. unfold Equation151. intro H. specialize (H F3_0). unfold magma_op, refa213_inst, refa213_op in H. discriminate H. Qed.

Lemma refa213_not203 : ~ @Equation203 Fin3 refa213_inst.
Proof. unfold Equation203. intro H. specialize (H F3_0). unfold magma_op, refa213_inst, refa213_op in H. discriminate H. Qed.

Lemma refa213_not255 : ~ @Equation255 Fin3 refa213_inst.
Proof. unfold Equation255. intro H. specialize (H F3_0). unfold magma_op, refa213_inst, refa213_op in H. discriminate H. Qed.

Lemma refa213_not411 : ~ @Equation411 Fin3 refa213_inst.
Proof. unfold Equation411. intro H. specialize (H F3_0). unfold magma_op, refa213_inst, refa213_op in H. discriminate H. Qed.

Lemma refa213_not615 : ~ @Equation615 Fin3 refa213_inst.
Proof. unfold Equation615. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa213_inst, refa213_op in H. discriminate H. Qed.

Lemma refa213_not620 : ~ @Equation620 Fin3 refa213_inst.
Proof. unfold Equation620. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa213_inst, refa213_op in H. discriminate H. Qed.

Lemma refa213_not623 : ~ @Equation623 Fin3 refa213_inst.
Proof. unfold Equation623. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa213_inst, refa213_op in H. discriminate H. Qed.

Lemma refa213_not630 : ~ @Equation630 Fin3 refa213_inst.
Proof. unfold Equation630. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa213_inst, refa213_op in H. discriminate H. Qed.

Lemma refa213_not633 : ~ @Equation633 Fin3 refa213_inst.
Proof. unfold Equation633. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa213_inst, refa213_op in H. discriminate H. Qed.

Lemma refa213_not640 : ~ @Equation640 Fin3 refa213_inst.
Proof. unfold Equation640. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa213_inst, refa213_op in H. discriminate H. Qed.

Lemma refa213_not643 : ~ @Equation643 Fin3 refa213_inst.
Proof. unfold Equation643. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa213_inst, refa213_op in H. discriminate H. Qed.

Lemma refa213_not667 : ~ @Equation667 Fin3 refa213_inst.
Proof. unfold Equation667. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa213_inst, refa213_op in H. discriminate H. Qed.

Lemma refa213_not680 : ~ @Equation680 Fin3 refa213_inst.
Proof. unfold Equation680. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa213_inst, refa213_op in H. discriminate H. Qed.

Lemma refa213_not707 : ~ @Equation707 Fin3 refa213_inst.
Proof. unfold Equation707. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa213_inst, refa213_op in H. discriminate H. Qed.

Lemma refa213_not826 : ~ @Equation826 Fin3 refa213_inst.
Proof. unfold Equation826. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa213_inst, refa213_op in H. discriminate H. Qed.

Lemma refa213_not833 : ~ @Equation833 Fin3 refa213_inst.
Proof. unfold Equation833. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa213_inst, refa213_op in H. discriminate H. Qed.

Lemma refa213_not836 : ~ @Equation836 Fin3 refa213_inst.
Proof. unfold Equation836. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa213_inst, refa213_op in H. discriminate H. Qed.

Lemma refa213_not843 : ~ @Equation843 Fin3 refa213_inst.
Proof. unfold Equation843. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa213_inst, refa213_op in H. discriminate H. Qed.

Lemma refa213_not846 : ~ @Equation846 Fin3 refa213_inst.
Proof. unfold Equation846. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa213_inst, refa213_op in H. discriminate H. Qed.

Lemma refa213_not870 : ~ @Equation870 Fin3 refa213_inst.
Proof. unfold Equation870. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa213_inst, refa213_op in H. discriminate H. Qed.

Lemma refa213_not883 : ~ @Equation883 Fin3 refa213_inst.
Proof. unfold Equation883. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa213_inst, refa213_op in H. discriminate H. Qed.

Lemma refa213_not917 : ~ @Equation917 Fin3 refa213_inst.
Proof. unfold Equation917. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa213_inst, refa213_op in H. discriminate H. Qed.

Lemma refa213_not1020 : ~ @Equation1020 Fin3 refa213_inst.
Proof. unfold Equation1020. intro H. specialize (H F3_0). unfold magma_op, refa213_inst, refa213_op in H. discriminate H. Qed.

Lemma refa213_not1223 : ~ @Equation1223 Fin3 refa213_inst.
Proof. unfold Equation1223. intro H. specialize (H F3_0). unfold magma_op, refa213_inst, refa213_op in H. discriminate H. Qed.

Lemma refa213_not1427 : ~ @Equation1427 Fin3 refa213_inst.
Proof. unfold Equation1427. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa213_inst, refa213_op in H. discriminate H. Qed.

Lemma refa213_not1429 : ~ @Equation1429 Fin3 refa213_inst.
Proof. unfold Equation1429. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa213_inst, refa213_op in H. discriminate H. Qed.

Lemma refa213_not1435 : ~ @Equation1435 Fin3 refa213_inst.
Proof. unfold Equation1435. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa213_inst, refa213_op in H. discriminate H. Qed.

Lemma refa213_not1445 : ~ @Equation1445 Fin3 refa213_inst.
Proof. unfold Equation1445. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa213_inst, refa213_op in H. discriminate H. Qed.

Lemma refa213_not1479 : ~ @Equation1479 Fin3 refa213_inst.
Proof. unfold Equation1479. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa213_inst, refa213_op in H. discriminate H. Qed.

Lemma refa213_not1519 : ~ @Equation1519 Fin3 refa213_inst.
Proof. unfold Equation1519. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa213_inst, refa213_op in H. discriminate H. Qed.

Lemma refa213_not1629 : ~ @Equation1629 Fin3 refa213_inst.
Proof. unfold Equation1629. intro H. specialize (H F3_0). unfold magma_op, refa213_inst, refa213_op in H. discriminate H. Qed.

Lemma refa213_not1832 : ~ @Equation1832 Fin3 refa213_inst.
Proof. unfold Equation1832. intro H. specialize (H F3_0). unfold magma_op, refa213_inst, refa213_op in H. discriminate H. Qed.

Lemma refa213_not2035 : ~ @Equation2035 Fin3 refa213_inst.
Proof. unfold Equation2035. intro H. specialize (H F3_0). unfold magma_op, refa213_inst, refa213_op in H. discriminate H. Qed.

Lemma refa213_not2238 : ~ @Equation2238 Fin3 refa213_inst.
Proof. unfold Equation2238. intro H. specialize (H F3_0). unfold magma_op, refa213_inst, refa213_op in H. discriminate H. Qed.

Lemma refa213_not2441 : ~ @Equation2441 Fin3 refa213_inst.
Proof. unfold Equation2441. intro H. specialize (H F3_0). unfold magma_op, refa213_inst, refa213_op in H. discriminate H. Qed.

Lemma refa213_not2644 : ~ @Equation2644 Fin3 refa213_inst.
Proof. unfold Equation2644. intro H. specialize (H F3_0). unfold magma_op, refa213_inst, refa213_op in H. discriminate H. Qed.

Lemma refa213_not2847 : ~ @Equation2847 Fin3 refa213_inst.
Proof. unfold Equation2847. intro H. specialize (H F3_0). unfold magma_op, refa213_inst, refa213_op in H. discriminate H. Qed.

Lemma refa213_not3050 : ~ @Equation3050 Fin3 refa213_inst.
Proof. unfold Equation3050. intro H. specialize (H F3_0). unfold magma_op, refa213_inst, refa213_op in H. discriminate H. Qed.

Lemma refa213_not3253 : ~ @Equation3253 Fin3 refa213_inst.
Proof. unfold Equation3253. intro H. specialize (H F3_0). unfold magma_op, refa213_inst, refa213_op in H. discriminate H. Qed.

Lemma refa213_not3456 : ~ @Equation3456 Fin3 refa213_inst.
Proof. unfold Equation3456. intro H. specialize (H F3_0). unfold magma_op, refa213_inst, refa213_op in H. discriminate H. Qed.

Lemma refa213_not3659 : ~ @Equation3659 Fin3 refa213_inst.
Proof. unfold Equation3659. intro H. specialize (H F3_0). unfold magma_op, refa213_inst, refa213_op in H. discriminate H. Qed.

Lemma refa213_not3865 : ~ @Equation3865 Fin3 refa213_inst.
Proof. unfold Equation3865. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa213_inst, refa213_op in H. discriminate H. Qed.

Lemma refa213_not3868 : ~ @Equation3868 Fin3 refa213_inst.
Proof. unfold Equation3868. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa213_inst, refa213_op in H. discriminate H. Qed.

Lemma refa213_not3871 : ~ @Equation3871 Fin3 refa213_inst.
Proof. unfold Equation3871. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa213_inst, refa213_op in H. discriminate H. Qed.

Lemma refa213_not3878 : ~ @Equation3878 Fin3 refa213_inst.
Proof. unfold Equation3878. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa213_inst, refa213_op in H. discriminate H. Qed.

Lemma refa213_not3917 : ~ @Equation3917 Fin3 refa213_inst.
Proof. unfold Equation3917. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa213_inst, refa213_op in H. discriminate H. Qed.

Lemma refa213_not3927 : ~ @Equation3927 Fin3 refa213_inst.
Proof. unfold Equation3927. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa213_inst, refa213_op in H. discriminate H. Qed.

Lemma refa213_not3951 : ~ @Equation3951 Fin3 refa213_inst.
Proof. unfold Equation3951. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa213_inst, refa213_op in H. discriminate H. Qed.

Lemma refa213_not3964 : ~ @Equation3964 Fin3 refa213_inst.
Proof. unfold Equation3964. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa213_inst, refa213_op in H. discriminate H. Qed.

Lemma refa213_not4066 : ~ @Equation4066 Fin3 refa213_inst.
Proof. unfold Equation4066. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa213_inst, refa213_op in H. discriminate H. Qed.

Lemma refa213_not4068 : ~ @Equation4068 Fin3 refa213_inst.
Proof. unfold Equation4068. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa213_inst, refa213_op in H. discriminate H. Qed.

Lemma refa213_not4071 : ~ @Equation4071 Fin3 refa213_inst.
Proof. unfold Equation4071. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa213_inst, refa213_op in H. discriminate H. Qed.

Lemma refa213_not4074 : ~ @Equation4074 Fin3 refa213_inst.
Proof. unfold Equation4074. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa213_inst, refa213_op in H. discriminate H. Qed.

Lemma refa213_not4120 : ~ @Equation4120 Fin3 refa213_inst.
Proof. unfold Equation4120. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa213_inst, refa213_op in H. discriminate H. Qed.

Lemma refa213_not4127 : ~ @Equation4127 Fin3 refa213_inst.
Proof. unfold Equation4127. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa213_inst, refa213_op in H. discriminate H. Qed.

Lemma refa213_not4130 : ~ @Equation4130 Fin3 refa213_inst.
Proof. unfold Equation4130. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa213_inst, refa213_op in H. discriminate H. Qed.

Lemma refa213_not4167 : ~ @Equation4167 Fin3 refa213_inst.
Proof. unfold Equation4167. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa213_inst, refa213_op in H. discriminate H. Qed.

Lemma refa213_not4268 : ~ @Equation4268 Fin3 refa213_inst.
Proof. unfold Equation4268. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa213_inst, refa213_op in H. discriminate H. Qed.

Lemma refa213_not4270 : ~ @Equation4270 Fin3 refa213_inst.
Proof. unfold Equation4270. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa213_inst, refa213_op in H. discriminate H. Qed.

Lemma refa213_not4273 : ~ @Equation4273 Fin3 refa213_inst.
Proof. unfold Equation4273. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa213_inst, refa213_op in H. discriminate H. Qed.

Lemma refa213_not4283 : ~ @Equation4283 Fin3 refa213_inst.
Proof. unfold Equation4283. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa213_inst, refa213_op in H. discriminate H. Qed.

Lemma refa213_not4290 : ~ @Equation4290 Fin3 refa213_inst.
Proof. unfold Equation4290. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa213_inst, refa213_op in H. discriminate H. Qed.

Lemma refa213_not4314 : ~ @Equation4314 Fin3 refa213_inst.
Proof. unfold Equation4314. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa213_inst, refa213_op in H. discriminate H. Qed.

Lemma refa213_not4380 : ~ @Equation4380 Fin3 refa213_inst.
Proof. unfold Equation4380. intro H. specialize (H F3_0). unfold magma_op, refa213_inst, refa213_op in H. discriminate H. Qed.

Lemma refa213_not4583 : ~ @Equation4583 Fin3 refa213_inst.
Proof. unfold Equation4583. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa213_inst, refa213_op in H. discriminate H. Qed.

Lemma refa213_not4585 : ~ @Equation4585 Fin3 refa213_inst.
Proof. unfold Equation4585. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa213_inst, refa213_op in H. discriminate H. Qed.

Lemma refa213_not4588 : ~ @Equation4588 Fin3 refa213_inst.
Proof. unfold Equation4588. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa213_inst, refa213_op in H. discriminate H. Qed.

Lemma refa213_not4598 : ~ @Equation4598 Fin3 refa213_inst.
Proof. unfold Equation4598. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa213_inst, refa213_op in H. discriminate H. Qed.

Lemma refa213_not4605 : ~ @Equation4605 Fin3 refa213_inst.
Proof. unfold Equation4605. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa213_inst, refa213_op in H. discriminate H. Qed.

Lemma refa213_not4629 : ~ @Equation4629 Fin3 refa213_inst.
Proof. unfold Equation4629. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa213_inst, refa213_op in H. discriminate H. Qed.

(** ---- refa214 (Fin3) ---- *)

Definition refa214_op (x y : Fin3) : Fin3 :=
  match x, y with
  | F3_0, F3_0 => F3_0 | F3_0, F3_1 => F3_0 | F3_0, F3_2 => F3_2
  | F3_1, F3_0 => F3_0 | F3_1, F3_1 => F3_2 | F3_1, F3_2 => F3_2
  | F3_2, F3_0 => F3_0 | F3_2, F3_1 => F3_0 | F3_2, F3_2 => F3_2
  end.

#[local] Instance refa214_inst : Magma Fin3 := {| magma_op := refa214_op |}.

Lemma refa214_sat343 : @Equation343 Fin3 refa214_inst.
Proof. unfold Equation343, magma_op, refa214_inst, refa214_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa214_not3255 : ~ @Equation3255 Fin3 refa214_inst.
Proof. unfold Equation3255. intro H. specialize (H F3_1 F3_0). unfold magma_op, refa214_inst, refa214_op in H. discriminate H. Qed.

Lemma refa214_not3261 : ~ @Equation3261 Fin3 refa214_inst.
Proof. unfold Equation3261. intro H. specialize (H F3_1 F3_0). unfold magma_op, refa214_inst, refa214_op in H. discriminate H. Qed.

Lemma refa214_not3271 : ~ @Equation3271 Fin3 refa214_inst.
Proof. unfold Equation3271. intro H. specialize (H F3_1 F3_0). unfold magma_op, refa214_inst, refa214_op in H. discriminate H. Qed.

Lemma refa214_not3281 : ~ @Equation3281 Fin3 refa214_inst.
Proof. unfold Equation3281. intro H. specialize (H F3_1 F3_0). unfold magma_op, refa214_inst, refa214_op in H. discriminate H. Qed.

Lemma refa214_not3309 : ~ @Equation3309 Fin3 refa214_inst.
Proof. unfold Equation3309. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa214_inst, refa214_op in H. discriminate H. Qed.

Lemma refa214_not3319 : ~ @Equation3319 Fin3 refa214_inst.
Proof. unfold Equation3319. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa214_inst, refa214_op in H. discriminate H. Qed.

Lemma refa214_not3346 : ~ @Equation3346 Fin3 refa214_inst.
Proof. unfold Equation3346. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa214_inst, refa214_op in H. discriminate H. Qed.

Lemma refa214_not3456 : ~ @Equation3456 Fin3 refa214_inst.
Proof. unfold Equation3456. intro H. specialize (H F3_1). unfold magma_op, refa214_inst, refa214_op in H. discriminate H. Qed.

Lemma refa214_not3661 : ~ @Equation3661 Fin3 refa214_inst.
Proof. unfold Equation3661. intro H. specialize (H F3_1 F3_0). unfold magma_op, refa214_inst, refa214_op in H. discriminate H. Qed.

Lemma refa214_not3667 : ~ @Equation3667 Fin3 refa214_inst.
Proof. unfold Equation3667. intro H. specialize (H F3_1 F3_0). unfold magma_op, refa214_inst, refa214_op in H. discriminate H. Qed.

Lemma refa214_not3677 : ~ @Equation3677 Fin3 refa214_inst.
Proof. unfold Equation3677. intro H. specialize (H F3_1 F3_0). unfold magma_op, refa214_inst, refa214_op in H. discriminate H. Qed.

Lemma refa214_not3687 : ~ @Equation3687 Fin3 refa214_inst.
Proof. unfold Equation3687. intro H. specialize (H F3_1 F3_0). unfold magma_op, refa214_inst, refa214_op in H. discriminate H. Qed.

Lemma refa214_not3721 : ~ @Equation3721 Fin3 refa214_inst.
Proof. unfold Equation3721. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa214_inst, refa214_op in H. discriminate H. Qed.

Lemma refa214_not3724 : ~ @Equation3724 Fin3 refa214_inst.
Proof. unfold Equation3724. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa214_inst, refa214_op in H. discriminate H. Qed.

Lemma refa214_not3725 : ~ @Equation3725 Fin3 refa214_inst.
Proof. unfold Equation3725. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa214_inst, refa214_op in H. discriminate H. Qed.

Lemma refa214_not3752 : ~ @Equation3752 Fin3 refa214_inst.
Proof. unfold Equation3752. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa214_inst, refa214_op in H. discriminate H. Qed.

Lemma refa214_not3862 : ~ @Equation3862 Fin3 refa214_inst.
Proof. unfold Equation3862. intro H. specialize (H F3_1). unfold magma_op, refa214_inst, refa214_op in H. discriminate H. Qed.

Lemma refa214_not4065 : ~ @Equation4065 Fin3 refa214_inst.
Proof. unfold Equation4065. intro H. specialize (H F3_1). unfold magma_op, refa214_inst, refa214_op in H. discriminate H. Qed.

Lemma refa214_not4269 : ~ @Equation4269 Fin3 refa214_inst.
Proof. unfold Equation4269. intro H. specialize (H F3_1 F3_0). unfold magma_op, refa214_inst, refa214_op in H. discriminate H. Qed.

Lemma refa214_not4275 : ~ @Equation4275 Fin3 refa214_inst.
Proof. unfold Equation4275. intro H. specialize (H F3_1 F3_0). unfold magma_op, refa214_inst, refa214_op in H. discriminate H. Qed.

Lemma refa214_not4284 : ~ @Equation4284 Fin3 refa214_inst.
Proof. unfold Equation4284. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa214_inst, refa214_op in H. discriminate H. Qed.

Lemma refa214_not4320 : ~ @Equation4320 Fin3 refa214_inst.
Proof. unfold Equation4320. intro H. specialize (H F3_1 F3_0). unfold magma_op, refa214_inst, refa214_op in H. discriminate H. Qed.

Lemma refa214_not4380 : ~ @Equation4380 Fin3 refa214_inst.
Proof. unfold Equation4380. intro H. specialize (H F3_1). unfold magma_op, refa214_inst, refa214_op in H. discriminate H. Qed.

Lemma refa214_not4629 : ~ @Equation4629 Fin3 refa214_inst.
Proof. unfold Equation4629. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa214_inst, refa214_op in H. discriminate H. Qed.

(** ---- refa215 (Fin3) ---- *)

Definition refa215_op (x y : Fin3) : Fin3 :=
  match x, y with
  | F3_0, F3_0 => F3_0 | F3_0, F3_1 => F3_1 | F3_0, F3_2 => F3_2
  | F3_1, F3_0 => F3_0 | F3_1, F3_1 => F3_0 | F3_1, F3_2 => F3_1
  | F3_2, F3_0 => F3_0 | F3_2, F3_1 => F3_1 | F3_2, F3_2 => F3_1
  end.

#[local] Instance refa215_inst : Magma Fin3 := {| magma_op := refa215_op |}.

Lemma refa215_sat309 : @Equation309 Fin3 refa215_inst.
Proof. unfold Equation309, magma_op, refa215_inst, refa215_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa215_sat2709 : @Equation2709 Fin3 refa215_inst.
Proof. unfold Equation2709, magma_op, refa215_inst, refa215_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa215_not2441 : ~ @Equation2441 Fin3 refa215_inst.
Proof. unfold Equation2441. intro H. specialize (H F3_2). unfold magma_op, refa215_inst, refa215_op in H. discriminate H. Qed.

Lemma refa215_not2652 : ~ @Equation2652 Fin3 refa215_inst.
Proof. unfold Equation2652. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa215_inst, refa215_op in H. discriminate H. Qed.

Lemma refa215_not3058 : ~ @Equation3058 Fin3 refa215_inst.
Proof. unfold Equation3058. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa215_inst, refa215_op in H. discriminate H. Qed.

Lemma refa215_not3115 : ~ @Equation3115 Fin3 refa215_inst.
Proof. unfold Equation3115. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa215_inst, refa215_op in H. discriminate H. Qed.

Lemma refa215_not3152 : ~ @Equation3152 Fin3 refa215_inst.
Proof. unfold Equation3152. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa215_inst, refa215_op in H. discriminate H. Qed.

Lemma refa215_not3258 : ~ @Equation3258 Fin3 refa215_inst.
Proof. unfold Equation3258. intro H. specialize (H F3_2 F3_1). unfold magma_op, refa215_inst, refa215_op in H. discriminate H. Qed.

Lemma refa215_not3522 : ~ @Equation3522 Fin3 refa215_inst.
Proof. unfold Equation3522. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa215_inst, refa215_op in H. discriminate H. Qed.

Lemma refa215_not3659 : ~ @Equation3659 Fin3 refa215_inst.
Proof. unfold Equation3659. intro H. specialize (H F3_2). unfold magma_op, refa215_inst, refa215_op in H. discriminate H. Qed.

(** ---- refa216 (Fin3) ---- *)

Definition refa216_op (x y : Fin3) : Fin3 :=
  match x, y with
  | F3_0, F3_0 => F3_0 | F3_0, F3_1 => F3_0 | F3_0, F3_2 => F3_0
  | F3_1, F3_0 => F3_1 | F3_1, F3_1 => F3_0 | F3_1, F3_2 => F3_0
  | F3_2, F3_0 => F3_2 | F3_2, F3_1 => F3_1 | F3_2, F3_2 => F3_0
  end.

#[local] Instance refa216_inst : Magma Fin3 := {| magma_op := refa216_op |}.

Lemma refa216_sat1271 : @Equation1271 Fin3 refa216_inst.
Proof. unfold Equation1271, magma_op, refa216_inst, refa216_op. intros x y z w. destruct x, y, z, w; reflexivity. Qed.

Lemma refa216_not413 : ~ @Equation413 Fin3 refa216_inst.
Proof. unfold Equation413. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa216_inst, refa216_op in H. discriminate H. Qed.

Lemma refa216_not437 : ~ @Equation437 Fin3 refa216_inst.
Proof. unfold Equation437. intro H. specialize (H F3_2 F3_1). unfold magma_op, refa216_inst, refa216_op in H. discriminate H. Qed.

Lemma refa216_not3255 : ~ @Equation3255 Fin3 refa216_inst.
Proof. unfold Equation3255. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa216_inst, refa216_op in H. discriminate H. Qed.

Lemma refa216_not3316 : ~ @Equation3316 Fin3 refa216_inst.
Proof. unfold Equation3316. intro H. specialize (H F3_2 F3_1). unfold magma_op, refa216_inst, refa216_op in H. discriminate H. Qed.

(** ---- refa217 (Fin3) ---- *)

Definition refa217_op (x y : Fin3) : Fin3 :=
  match x, y with
  | F3_0, F3_0 => F3_0 | F3_0, F3_1 => F3_0 | F3_0, F3_2 => F3_1
  | F3_1, F3_0 => F3_2 | F3_1, F3_1 => F3_1 | F3_1, F3_2 => F3_2
  | F3_2, F3_0 => F3_0 | F3_2, F3_1 => F3_2 | F3_2, F3_2 => F3_1
  end.

#[local] Instance refa217_inst : Magma Fin3 := {| magma_op := refa217_op |}.

Lemma refa217_sat1682 : @Equation1682 Fin3 refa217_inst.
Proof. unfold Equation1682, magma_op, refa217_inst, refa217_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa217_not414 : ~ @Equation414 Fin3 refa217_inst.
Proof. unfold Equation414. intro H. specialize (H F3_1 F3_0). unfold magma_op, refa217_inst, refa217_op in H. discriminate H. Qed.

Lemma refa217_not427 : ~ @Equation427 Fin3 refa217_inst.
Proof. unfold Equation427. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa217_inst, refa217_op in H. discriminate H. Qed.

Lemma refa217_not473 : ~ @Equation473 Fin3 refa217_inst.
Proof. unfold Equation473. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa217_inst, refa217_op in H. discriminate H. Qed.

Lemma refa217_not477 : ~ @Equation477 Fin3 refa217_inst.
Proof. unfold Equation477. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa217_inst, refa217_op in H. discriminate H. Qed.

Lemma refa217_not511 : ~ @Equation511 Fin3 refa217_inst.
Proof. unfold Equation511. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa217_inst, refa217_op in H. discriminate H. Qed.

Lemma refa217_not513 : ~ @Equation513 Fin3 refa217_inst.
Proof. unfold Equation513. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa217_inst, refa217_op in H. discriminate H. Qed.

Lemma refa217_not622 : ~ @Equation622 Fin3 refa217_inst.
Proof. unfold Equation622. intro H. specialize (H F3_1 F3_0). unfold magma_op, refa217_inst, refa217_op in H. discriminate H. Qed.

Lemma refa217_not632 : ~ @Equation632 Fin3 refa217_inst.
Proof. unfold Equation632. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa217_inst, refa217_op in H. discriminate H. Qed.

Lemma refa217_not639 : ~ @Equation639 Fin3 refa217_inst.
Proof. unfold Equation639. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa217_inst, refa217_op in H. discriminate H. Qed.

Lemma refa217_not667 : ~ @Equation667 Fin3 refa217_inst.
Proof. unfold Equation667. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa217_inst, refa217_op in H. discriminate H. Qed.

Lemma refa217_not680 : ~ @Equation680 Fin3 refa217_inst.
Proof. unfold Equation680. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa217_inst, refa217_op in H. discriminate H. Qed.

Lemma refa217_not707 : ~ @Equation707 Fin3 refa217_inst.
Proof. unfold Equation707. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa217_inst, refa217_op in H. discriminate H. Qed.

Lemma refa217_not1023 : ~ @Equation1023 Fin3 refa217_inst.
Proof. unfold Equation1023. intro H. specialize (H F3_1 F3_0). unfold magma_op, refa217_inst, refa217_op in H. discriminate H. Qed.

Lemma refa217_not1109 : ~ @Equation1109 Fin3 refa217_inst.
Proof. unfold Equation1109. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa217_inst, refa217_op in H. discriminate H. Qed.

Lemma refa217_not1122 : ~ @Equation1122 Fin3 refa217_inst.
Proof. unfold Equation1122. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa217_inst, refa217_op in H. discriminate H. Qed.

Lemma refa217_not1239 : ~ @Equation1239 Fin3 refa217_inst.
Proof. unfold Equation1239. intro H. specialize (H F3_1 F3_0). unfold magma_op, refa217_inst, refa217_op in H. discriminate H. Qed.

Lemma refa217_not1278 : ~ @Equation1278 Fin3 refa217_inst.
Proof. unfold Equation1278. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa217_inst, refa217_op in H. discriminate H. Qed.

Lemma refa217_not1289 : ~ @Equation1289 Fin3 refa217_inst.
Proof. unfold Equation1289. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa217_inst, refa217_op in H. discriminate H. Qed.

Lemma refa217_not1429 : ~ @Equation1429 Fin3 refa217_inst.
Proof. unfold Equation1429. intro H. specialize (H F3_1 F3_0). unfold magma_op, refa217_inst, refa217_op in H. discriminate H. Qed.

Lemma refa217_not1451 : ~ @Equation1451 Fin3 refa217_inst.
Proof. unfold Equation1451. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa217_inst, refa217_op in H. discriminate H. Qed.

Lemma refa217_not1488 : ~ @Equation1488 Fin3 refa217_inst.
Proof. unfold Equation1488. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa217_inst, refa217_op in H. discriminate H. Qed.

Lemma refa217_not1515 : ~ @Equation1515 Fin3 refa217_inst.
Proof. unfold Equation1515. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa217_inst, refa217_op in H. discriminate H. Qed.

Lemma refa217_not1519 : ~ @Equation1519 Fin3 refa217_inst.
Proof. unfold Equation1519. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa217_inst, refa217_op in H. discriminate H. Qed.

Lemma refa217_not1637 : ~ @Equation1637 Fin3 refa217_inst.
Proof. unfold Equation1637. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa217_inst, refa217_op in H. discriminate H. Qed.

Lemma refa217_not1645 : ~ @Equation1645 Fin3 refa217_inst.
Proof. unfold Equation1645. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa217_inst, refa217_op in H. discriminate H. Qed.

Lemma refa217_not1658 : ~ @Equation1658 Fin3 refa217_inst.
Proof. unfold Equation1658. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa217_inst, refa217_op in H. discriminate H. Qed.

Lemma refa217_not1731 : ~ @Equation1731 Fin3 refa217_inst.
Proof. unfold Equation1731. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa217_inst, refa217_op in H. discriminate H. Qed.

Lemma refa217_not1857 : ~ @Equation1857 Fin3 refa217_inst.
Proof. unfold Equation1857. intro H. specialize (H F3_1 F3_0). unfold magma_op, refa217_inst, refa217_op in H. discriminate H. Qed.

Lemma refa217_not1861 : ~ @Equation1861 Fin3 refa217_inst.
Proof. unfold Equation1861. intro H. specialize (H F3_1 F3_0). unfold magma_op, refa217_inst, refa217_op in H. discriminate H. Qed.

Lemma refa217_not1885 : ~ @Equation1885 Fin3 refa217_inst.
Proof. unfold Equation1885. intro H. specialize (H F3_2 F3_0). unfold magma_op, refa217_inst, refa217_op in H. discriminate H. Qed.

Lemma refa217_not1887 : ~ @Equation1887 Fin3 refa217_inst.
Proof. unfold Equation1887. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa217_inst, refa217_op in H. discriminate H. Qed.

Lemma refa217_not2038 : ~ @Equation2038 Fin3 refa217_inst.
Proof. unfold Equation2038. intro H. specialize (H F3_1 F3_0). unfold magma_op, refa217_inst, refa217_op in H. discriminate H. Qed.

Lemma refa217_not2041 : ~ @Equation2041 Fin3 refa217_inst.
Proof. unfold Equation2041. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa217_inst, refa217_op in H. discriminate H. Qed.

Lemma refa217_not2043 : ~ @Equation2043 Fin3 refa217_inst.
Proof. unfold Equation2043. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa217_inst, refa217_op in H. discriminate H. Qed.

Lemma refa217_not2124 : ~ @Equation2124 Fin3 refa217_inst.
Proof. unfold Equation2124. intro H. specialize (H F3_1 F3_0). unfold magma_op, refa217_inst, refa217_op in H. discriminate H. Qed.

Lemma refa217_not2128 : ~ @Equation2128 Fin3 refa217_inst.
Proof. unfold Equation2128. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa217_inst, refa217_op in H. discriminate H. Qed.

Lemma refa217_not2137 : ~ @Equation2137 Fin3 refa217_inst.
Proof. unfold Equation2137. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa217_inst, refa217_op in H. discriminate H. Qed.

Lemma refa217_not2254 : ~ @Equation2254 Fin3 refa217_inst.
Proof. unfold Equation2254. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa217_inst, refa217_op in H. discriminate H. Qed.

Lemma refa217_not2267 : ~ @Equation2267 Fin3 refa217_inst.
Proof. unfold Equation2267. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa217_inst, refa217_op in H. discriminate H. Qed.

Lemma refa217_not2293 : ~ @Equation2293 Fin3 refa217_inst.
Proof. unfold Equation2293. intro H. specialize (H F3_2 F3_0). unfold magma_op, refa217_inst, refa217_op in H. discriminate H. Qed.

Lemma refa217_not2338 : ~ @Equation2338 Fin3 refa217_inst.
Proof. unfold Equation2338. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa217_inst, refa217_op in H. discriminate H. Qed.

Lemma refa217_not2444 : ~ @Equation2444 Fin3 refa217_inst.
Proof. unfold Equation2444. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa217_inst, refa217_op in H. discriminate H. Qed.

Lemma refa217_not2530 : ~ @Equation2530 Fin3 refa217_inst.
Proof. unfold Equation2530. intro H. specialize (H F3_1 F3_0). unfold magma_op, refa217_inst, refa217_op in H. discriminate H. Qed.

Lemma refa217_not2855 : ~ @Equation2855 Fin3 refa217_inst.
Proof. unfold Equation2855. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa217_inst, refa217_op in H. discriminate H. Qed.

Lemma refa217_not2872 : ~ @Equation2872 Fin3 refa217_inst.
Proof. unfold Equation2872. intro H. specialize (H F3_1 F3_0). unfold magma_op, refa217_inst, refa217_op in H. discriminate H. Qed.

Lemma refa217_not2900 : ~ @Equation2900 Fin3 refa217_inst.
Proof. unfold Equation2900. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa217_inst, refa217_op in H. discriminate H. Qed.

Lemma refa217_not2947 : ~ @Equation2947 Fin3 refa217_inst.
Proof. unfold Equation2947. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa217_inst, refa217_op in H. discriminate H. Qed.

Lemma refa217_not3056 : ~ @Equation3056 Fin3 refa217_inst.
Proof. unfold Equation3056. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa217_inst, refa217_op in H. discriminate H. Qed.

Lemma refa217_not3079 : ~ @Equation3079 Fin3 refa217_inst.
Proof. unfold Equation3079. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa217_inst, refa217_op in H. discriminate H. Qed.

Lemma refa217_not3105 : ~ @Equation3105 Fin3 refa217_inst.
Proof. unfold Equation3105. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa217_inst, refa217_op in H. discriminate H. Qed.

Lemma refa217_not3116 : ~ @Equation3116 Fin3 refa217_inst.
Proof. unfold Equation3116. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa217_inst, refa217_op in H. discriminate H. Qed.

Lemma refa217_not3139 : ~ @Equation3139 Fin3 refa217_inst.
Proof. unfold Equation3139. intro H. specialize (H F3_1 F3_0). unfold magma_op, refa217_inst, refa217_op in H. discriminate H. Qed.

Lemma refa217_not3150 : ~ @Equation3150 Fin3 refa217_inst.
Proof. unfold Equation3150. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa217_inst, refa217_op in H. discriminate H. Qed.

Lemma refa217_not3662 : ~ @Equation3662 Fin3 refa217_inst.
Proof. unfold Equation3662. intro H. specialize (H F3_1 F3_0). unfold magma_op, refa217_inst, refa217_op in H. discriminate H. Qed.

Lemma refa217_not3665 : ~ @Equation3665 Fin3 refa217_inst.
Proof. unfold Equation3665. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa217_inst, refa217_op in H. discriminate H. Qed.

Lemma refa217_not3667 : ~ @Equation3667 Fin3 refa217_inst.
Proof. unfold Equation3667. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa217_inst, refa217_op in H. discriminate H. Qed.

Lemma refa217_not3675 : ~ @Equation3675 Fin3 refa217_inst.
Proof. unfold Equation3675. intro H. specialize (H F3_2 F3_0). unfold magma_op, refa217_inst, refa217_op in H. discriminate H. Qed.

Lemma refa217_not3677 : ~ @Equation3677 Fin3 refa217_inst.
Proof. unfold Equation3677. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa217_inst, refa217_op in H. discriminate H. Qed.

Lemma refa217_not3684 : ~ @Equation3684 Fin3 refa217_inst.
Proof. unfold Equation3684. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa217_inst, refa217_op in H. discriminate H. Qed.

Lemma refa217_not4270 : ~ @Equation4270 Fin3 refa217_inst.
Proof. unfold Equation4270. intro H. specialize (H F3_1 F3_0). unfold magma_op, refa217_inst, refa217_op in H. discriminate H. Qed.

Lemma refa217_not4283 : ~ @Equation4283 Fin3 refa217_inst.
Proof. unfold Equation4283. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa217_inst, refa217_op in H. discriminate H. Qed.

Lemma refa217_not4398 : ~ @Equation4398 Fin3 refa217_inst.
Proof. unfold Equation4398. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa217_inst, refa217_op in H. discriminate H. Qed.

Lemma refa217_not4405 : ~ @Equation4405 Fin3 refa217_inst.
Proof. unfold Equation4405. intro H. specialize (H F3_1 F3_0). unfold magma_op, refa217_inst, refa217_op in H. discriminate H. Qed.

Lemma refa217_not4442 : ~ @Equation4442 Fin3 refa217_inst.
Proof. unfold Equation4442. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa217_inst, refa217_op in H. discriminate H. Qed.

Lemma refa217_not4482 : ~ @Equation4482 Fin3 refa217_inst.
Proof. unfold Equation4482. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa217_inst, refa217_op in H. discriminate H. Qed.

Lemma refa217_not4622 : ~ @Equation4622 Fin3 refa217_inst.
Proof. unfold Equation4622. intro H. specialize (H F3_0 F3_0 F3_1). unfold magma_op, refa217_inst, refa217_op in H. discriminate H. Qed.

Lemma refa217_not4635 : ~ @Equation4635 Fin3 refa217_inst.
Proof. unfold Equation4635. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa217_inst, refa217_op in H. discriminate H. Qed.

(** ---- refa218 (Fin3) ---- *)

Definition refa218_op (x y : Fin3) : Fin3 :=
  match x, y with
  | F3_0, F3_0 => F3_0 | F3_0, F3_1 => F3_1 | F3_0, F3_2 => F3_1
  | F3_1, F3_0 => F3_1 | F3_1, F3_1 => F3_0 | F3_1, F3_2 => F3_2
  | F3_2, F3_0 => F3_0 | F3_2, F3_1 => F3_1 | F3_2, F3_2 => F3_0
  end.

#[local] Instance refa218_inst : Magma Fin3 := {| magma_op := refa218_op |}.

Lemma refa218_sat2530 : @Equation2530 Fin3 refa218_inst.
Proof. unfold Equation2530, magma_op, refa218_inst, refa218_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa218_not1629 : ~ @Equation1629 Fin3 refa218_inst.
Proof. unfold Equation1629. intro H. specialize (H F3_2). unfold magma_op, refa218_inst, refa218_op in H. discriminate H. Qed.

Lemma refa218_not2459 : ~ @Equation2459 Fin3 refa218_inst.
Proof. unfold Equation2459. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa218_inst, refa218_op in H. discriminate H. Qed.

(** ---- refa219 (Fin3) ---- *)

Definition refa219_op (x y : Fin3) : Fin3 :=
  match x, y with
  | F3_0, F3_0 => F3_0 | F3_0, F3_1 => F3_1 | F3_0, F3_2 => F3_1
  | F3_1, F3_0 => F3_0 | F3_1, F3_1 => F3_1 | F3_1, F3_2 => F3_2
  | F3_2, F3_0 => F3_0 | F3_2, F3_1 => F3_0 | F3_2, F3_2 => F3_0
  end.

#[local] Instance refa219_inst : Magma Fin3 := {| magma_op := refa219_op |}.

Lemma refa219_sat2919 : @Equation2919 Fin3 refa219_inst.
Proof. unfold Equation2919, magma_op, refa219_inst, refa219_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa219_not47 : ~ @Equation47 Fin3 refa219_inst.
Proof. unfold Equation47. intro H. specialize (H F3_2). unfold magma_op, refa219_inst, refa219_op in H. discriminate H. Qed.

Lemma refa219_not99 : ~ @Equation99 Fin3 refa219_inst.
Proof. unfold Equation99. intro H. specialize (H F3_2). unfold magma_op, refa219_inst, refa219_op in H. discriminate H. Qed.

Lemma refa219_not151 : ~ @Equation151 Fin3 refa219_inst.
Proof. unfold Equation151. intro H. specialize (H F3_2). unfold magma_op, refa219_inst, refa219_op in H. discriminate H. Qed.

Lemma refa219_not203 : ~ @Equation203 Fin3 refa219_inst.
Proof. unfold Equation203. intro H. specialize (H F3_2). unfold magma_op, refa219_inst, refa219_op in H. discriminate H. Qed.

Lemma refa219_not263 : ~ @Equation263 Fin3 refa219_inst.
Proof. unfold Equation263. intro H. specialize (H F3_2 F3_0). unfold magma_op, refa219_inst, refa219_op in H. discriminate H. Qed.

Lemma refa219_not280 : ~ @Equation280 Fin3 refa219_inst.
Proof. unfold Equation280. intro H. specialize (H F3_2 F3_1). unfold magma_op, refa219_inst, refa219_op in H. discriminate H. Qed.

Lemma refa219_not283 : ~ @Equation283 Fin3 refa219_inst.
Proof. unfold Equation283. intro H. specialize (H F3_2 F3_0). unfold magma_op, refa219_inst, refa219_op in H. discriminate H. Qed.

Lemma refa219_not411 : ~ @Equation411 Fin3 refa219_inst.
Proof. unfold Equation411. intro H. specialize (H F3_2). unfold magma_op, refa219_inst, refa219_op in H. discriminate H. Qed.

Lemma refa219_not614 : ~ @Equation614 Fin3 refa219_inst.
Proof. unfold Equation614. intro H. specialize (H F3_2). unfold magma_op, refa219_inst, refa219_op in H. discriminate H. Qed.

Lemma refa219_not817 : ~ @Equation817 Fin3 refa219_inst.
Proof. unfold Equation817. intro H. specialize (H F3_2). unfold magma_op, refa219_inst, refa219_op in H. discriminate H. Qed.

Lemma refa219_not1020 : ~ @Equation1020 Fin3 refa219_inst.
Proof. unfold Equation1020. intro H. specialize (H F3_2). unfold magma_op, refa219_inst, refa219_op in H. discriminate H. Qed.

Lemma refa219_not1223 : ~ @Equation1223 Fin3 refa219_inst.
Proof. unfold Equation1223. intro H. specialize (H F3_2). unfold magma_op, refa219_inst, refa219_op in H. discriminate H. Qed.

Lemma refa219_not1426 : ~ @Equation1426 Fin3 refa219_inst.
Proof. unfold Equation1426. intro H. specialize (H F3_2). unfold magma_op, refa219_inst, refa219_op in H. discriminate H. Qed.

Lemma refa219_not1629 : ~ @Equation1629 Fin3 refa219_inst.
Proof. unfold Equation1629. intro H. specialize (H F3_2). unfold magma_op, refa219_inst, refa219_op in H. discriminate H. Qed.

Lemma refa219_not1832 : ~ @Equation1832 Fin3 refa219_inst.
Proof. unfold Equation1832. intro H. specialize (H F3_2). unfold magma_op, refa219_inst, refa219_op in H. discriminate H. Qed.

Lemma refa219_not2037 : ~ @Equation2037 Fin3 refa219_inst.
Proof. unfold Equation2037. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa219_inst, refa219_op in H. discriminate H. Qed.

Lemma refa219_not2040 : ~ @Equation2040 Fin3 refa219_inst.
Proof. unfold Equation2040. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa219_inst, refa219_op in H. discriminate H. Qed.

Lemma refa219_not2043 : ~ @Equation2043 Fin3 refa219_inst.
Proof. unfold Equation2043. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa219_inst, refa219_op in H. discriminate H. Qed.

Lemma refa219_not2053 : ~ @Equation2053 Fin3 refa219_inst.
Proof. unfold Equation2053. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa219_inst, refa219_op in H. discriminate H. Qed.

Lemma refa219_not2060 : ~ @Equation2060 Fin3 refa219_inst.
Proof. unfold Equation2060. intro H. specialize (H F3_2 F3_0). unfold magma_op, refa219_inst, refa219_op in H. discriminate H. Qed.

Lemma refa219_not2063 : ~ @Equation2063 Fin3 refa219_inst.
Proof. unfold Equation2063. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa219_inst, refa219_op in H. discriminate H. Qed.

Lemma refa219_not2087 : ~ @Equation2087 Fin3 refa219_inst.
Proof. unfold Equation2087. intro H. specialize (H F3_2 F3_0). unfold magma_op, refa219_inst, refa219_op in H. discriminate H. Qed.

Lemma refa219_not2124 : ~ @Equation2124 Fin3 refa219_inst.
Proof. unfold Equation2124. intro H. specialize (H F3_2 F3_0). unfold magma_op, refa219_inst, refa219_op in H. discriminate H. Qed.

Lemma refa219_not2127 : ~ @Equation2127 Fin3 refa219_inst.
Proof. unfold Equation2127. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa219_inst, refa219_op in H. discriminate H. Qed.

Lemma refa219_not2134 : ~ @Equation2134 Fin3 refa219_inst.
Proof. unfold Equation2134. intro H. specialize (H F3_2 F3_0). unfold magma_op, refa219_inst, refa219_op in H. discriminate H. Qed.

Lemma refa219_not2238 : ~ @Equation2238 Fin3 refa219_inst.
Proof. unfold Equation2238. intro H. specialize (H F3_2). unfold magma_op, refa219_inst, refa219_op in H. discriminate H. Qed.

Lemma refa219_not2441 : ~ @Equation2441 Fin3 refa219_inst.
Proof. unfold Equation2441. intro H. specialize (H F3_2). unfold magma_op, refa219_inst, refa219_op in H. discriminate H. Qed.

Lemma refa219_not2646 : ~ @Equation2646 Fin3 refa219_inst.
Proof. unfold Equation2646. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa219_inst, refa219_op in H. discriminate H. Qed.

Lemma refa219_not2652 : ~ @Equation2652 Fin3 refa219_inst.
Proof. unfold Equation2652. intro H. specialize (H F3_2 F3_0). unfold magma_op, refa219_inst, refa219_op in H. discriminate H. Qed.

Lemma refa219_not2662 : ~ @Equation2662 Fin3 refa219_inst.
Proof. unfold Equation2662. intro H. specialize (H F3_2 F3_0). unfold magma_op, refa219_inst, refa219_op in H. discriminate H. Qed.

Lemma refa219_not2672 : ~ @Equation2672 Fin3 refa219_inst.
Proof. unfold Equation2672. intro H. specialize (H F3_2 F3_0). unfold magma_op, refa219_inst, refa219_op in H. discriminate H. Qed.

Lemma refa219_not2699 : ~ @Equation2699 Fin3 refa219_inst.
Proof. unfold Equation2699. intro H. specialize (H F3_2 F3_0). unfold magma_op, refa219_inst, refa219_op in H. discriminate H. Qed.

Lemma refa219_not2709 : ~ @Equation2709 Fin3 refa219_inst.
Proof. unfold Equation2709. intro H. specialize (H F3_2 F3_0). unfold magma_op, refa219_inst, refa219_op in H. discriminate H. Qed.

Lemma refa219_not2736 : ~ @Equation2736 Fin3 refa219_inst.
Proof. unfold Equation2736. intro H. specialize (H F3_2 F3_0). unfold magma_op, refa219_inst, refa219_op in H. discriminate H. Qed.

Lemma refa219_not2743 : ~ @Equation2743 Fin3 refa219_inst.
Proof. unfold Equation2743. intro H. specialize (H F3_2 F3_1). unfold magma_op, refa219_inst, refa219_op in H. discriminate H. Qed.

Lemma refa219_not2746 : ~ @Equation2746 Fin3 refa219_inst.
Proof. unfold Equation2746. intro H. specialize (H F3_2 F3_0). unfold magma_op, refa219_inst, refa219_op in H. discriminate H. Qed.

Lemma refa219_not2849 : ~ @Equation2849 Fin3 refa219_inst.
Proof. unfold Equation2849. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa219_inst, refa219_op in H. discriminate H. Qed.

Lemma refa219_not2855 : ~ @Equation2855 Fin3 refa219_inst.
Proof. unfold Equation2855. intro H. specialize (H F3_2 F3_0). unfold magma_op, refa219_inst, refa219_op in H. discriminate H. Qed.

Lemma refa219_not2865 : ~ @Equation2865 Fin3 refa219_inst.
Proof. unfold Equation2865. intro H. specialize (H F3_2 F3_0). unfold magma_op, refa219_inst, refa219_op in H. discriminate H. Qed.

Lemma refa219_not2875 : ~ @Equation2875 Fin3 refa219_inst.
Proof. unfold Equation2875. intro H. specialize (H F3_2 F3_0). unfold magma_op, refa219_inst, refa219_op in H. discriminate H. Qed.

Lemma refa219_not2902 : ~ @Equation2902 Fin3 refa219_inst.
Proof. unfold Equation2902. intro H. specialize (H F3_2 F3_0). unfold magma_op, refa219_inst, refa219_op in H. discriminate H. Qed.

Lemma refa219_not2912 : ~ @Equation2912 Fin3 refa219_inst.
Proof. unfold Equation2912. intro H. specialize (H F3_2 F3_0). unfold magma_op, refa219_inst, refa219_op in H. discriminate H. Qed.

Lemma refa219_not2939 : ~ @Equation2939 Fin3 refa219_inst.
Proof. unfold Equation2939. intro H. specialize (H F3_2 F3_0). unfold magma_op, refa219_inst, refa219_op in H. discriminate H. Qed.

Lemma refa219_not2946 : ~ @Equation2946 Fin3 refa219_inst.
Proof. unfold Equation2946. intro H. specialize (H F3_2 F3_1). unfold magma_op, refa219_inst, refa219_op in H. discriminate H. Qed.

Lemma refa219_not2949 : ~ @Equation2949 Fin3 refa219_inst.
Proof. unfold Equation2949. intro H. specialize (H F3_2 F3_0). unfold magma_op, refa219_inst, refa219_op in H. discriminate H. Qed.

Lemma refa219_not3050 : ~ @Equation3050 Fin3 refa219_inst.
Proof. unfold Equation3050. intro H. specialize (H F3_2). unfold magma_op, refa219_inst, refa219_op in H. discriminate H. Qed.

Lemma refa219_not3255 : ~ @Equation3255 Fin3 refa219_inst.
Proof. unfold Equation3255. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa219_inst, refa219_op in H. discriminate H. Qed.

Lemma refa219_not3261 : ~ @Equation3261 Fin3 refa219_inst.
Proof. unfold Equation3261. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa219_inst, refa219_op in H. discriminate H. Qed.

Lemma refa219_not3271 : ~ @Equation3271 Fin3 refa219_inst.
Proof. unfold Equation3271. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa219_inst, refa219_op in H. discriminate H. Qed.

Lemma refa219_not3281 : ~ @Equation3281 Fin3 refa219_inst.
Proof. unfold Equation3281. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa219_inst, refa219_op in H. discriminate H. Qed.

Lemma refa219_not3326 : ~ @Equation3326 Fin3 refa219_inst.
Proof. unfold Equation3326. intro H. specialize (H F3_0 F3_1 F3_2). unfold magma_op, refa219_inst, refa219_op in H. discriminate H. Qed.

Lemma refa219_not3343 : ~ @Equation3343 Fin3 refa219_inst.
Proof. unfold Equation3343. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa219_inst, refa219_op in H. discriminate H. Qed.

Lemma refa219_not3346 : ~ @Equation3346 Fin3 refa219_inst.
Proof. unfold Equation3346. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa219_inst, refa219_op in H. discriminate H. Qed.

Lemma refa219_not3353 : ~ @Equation3353 Fin3 refa219_inst.
Proof. unfold Equation3353. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa219_inst, refa219_op in H. discriminate H. Qed.

Lemma refa219_not3458 : ~ @Equation3458 Fin3 refa219_inst.
Proof. unfold Equation3458. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa219_inst, refa219_op in H. discriminate H. Qed.

Lemma refa219_not3471 : ~ @Equation3471 Fin3 refa219_inst.
Proof. unfold Equation3471. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa219_inst, refa219_op in H. discriminate H. Qed.

Lemma refa219_not3474 : ~ @Equation3474 Fin3 refa219_inst.
Proof. unfold Equation3474. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa219_inst, refa219_op in H. discriminate H. Qed.

Lemma refa219_not3481 : ~ @Equation3481 Fin3 refa219_inst.
Proof. unfold Equation3481. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa219_inst, refa219_op in H. discriminate H. Qed.

Lemma refa219_not3484 : ~ @Equation3484 Fin3 refa219_inst.
Proof. unfold Equation3484. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa219_inst, refa219_op in H. discriminate H. Qed.

Lemma refa219_not3537 : ~ @Equation3537 Fin3 refa219_inst.
Proof. unfold Equation3537. intro H. specialize (H F3_1 F3_2 F3_0). unfold magma_op, refa219_inst, refa219_op in H. discriminate H. Qed.

Lemma refa219_not3546 : ~ @Equation3546 Fin3 refa219_inst.
Proof. unfold Equation3546. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa219_inst, refa219_op in H. discriminate H. Qed.

Lemma refa219_not3549 : ~ @Equation3549 Fin3 refa219_inst.
Proof. unfold Equation3549. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa219_inst, refa219_op in H. discriminate H. Qed.

Lemma refa219_not3661 : ~ @Equation3661 Fin3 refa219_inst.
Proof. unfold Equation3661. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa219_inst, refa219_op in H. discriminate H. Qed.

Lemma refa219_not3667 : ~ @Equation3667 Fin3 refa219_inst.
Proof. unfold Equation3667. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa219_inst, refa219_op in H. discriminate H. Qed.

Lemma refa219_not3677 : ~ @Equation3677 Fin3 refa219_inst.
Proof. unfold Equation3677. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa219_inst, refa219_op in H. discriminate H. Qed.

Lemma refa219_not3687 : ~ @Equation3687 Fin3 refa219_inst.
Proof. unfold Equation3687. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa219_inst, refa219_op in H. discriminate H. Qed.

Lemma refa219_not3722 : ~ @Equation3722 Fin3 refa219_inst.
Proof. unfold Equation3722. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa219_inst, refa219_op in H. discriminate H. Qed.

Lemma refa219_not3725 : ~ @Equation3725 Fin3 refa219_inst.
Proof. unfold Equation3725. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa219_inst, refa219_op in H. discriminate H. Qed.

Lemma refa219_not3752 : ~ @Equation3752 Fin3 refa219_inst.
Proof. unfold Equation3752. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa219_inst, refa219_op in H. discriminate H. Qed.

Lemma refa219_not3759 : ~ @Equation3759 Fin3 refa219_inst.
Proof. unfold Equation3759. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa219_inst, refa219_op in H. discriminate H. Qed.

Lemma refa219_not3862 : ~ @Equation3862 Fin3 refa219_inst.
Proof. unfold Equation3862. intro H. specialize (H F3_2). unfold magma_op, refa219_inst, refa219_op in H. discriminate H. Qed.

Lemma refa219_not4065 : ~ @Equation4065 Fin3 refa219_inst.
Proof. unfold Equation4065. intro H. specialize (H F3_2). unfold magma_op, refa219_inst, refa219_op in H. discriminate H. Qed.

Lemma refa219_not4269 : ~ @Equation4269 Fin3 refa219_inst.
Proof. unfold Equation4269. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa219_inst, refa219_op in H. discriminate H. Qed.

Lemma refa219_not4275 : ~ @Equation4275 Fin3 refa219_inst.
Proof. unfold Equation4275. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa219_inst, refa219_op in H. discriminate H. Qed.

Lemma refa219_not4291 : ~ @Equation4291 Fin3 refa219_inst.
Proof. unfold Equation4291. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa219_inst, refa219_op in H. discriminate H. Qed.

Lemma refa219_not4380 : ~ @Equation4380 Fin3 refa219_inst.
Proof. unfold Equation4380. intro H. specialize (H F3_2). unfold magma_op, refa219_inst, refa219_op in H. discriminate H. Qed.

Lemma refa219_not4584 : ~ @Equation4584 Fin3 refa219_inst.
Proof. unfold Equation4584. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa219_inst, refa219_op in H. discriminate H. Qed.

Lemma refa219_not4587 : ~ @Equation4587 Fin3 refa219_inst.
Proof. unfold Equation4587. intro H. specialize (H F3_2 F3_0). unfold magma_op, refa219_inst, refa219_op in H. discriminate H. Qed.

Lemma refa219_not4590 : ~ @Equation4590 Fin3 refa219_inst.
Proof. unfold Equation4590. intro H. specialize (H F3_2 F3_1). unfold magma_op, refa219_inst, refa219_op in H. discriminate H. Qed.

Lemma refa219_not4599 : ~ @Equation4599 Fin3 refa219_inst.
Proof. unfold Equation4599. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa219_inst, refa219_op in H. discriminate H. Qed.

Lemma refa219_not4635 : ~ @Equation4635 Fin3 refa219_inst.
Proof. unfold Equation4635. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa219_inst, refa219_op in H. discriminate H. Qed.

(** ---- refa22 (Fin8) ---- *)

Definition refa22_op (x y : Fin8) : Fin8 :=
  match x, y with
  | F8_0, F8_0 => F8_1 | F8_0, F8_1 => F8_2 | F8_0, F8_2 => F8_3 | F8_0, F8_3 => F8_4 | F8_0, F8_4 => F8_5 | F8_0, F8_5 => F8_6 | F8_0, F8_6 => F8_7 | F8_0, F8_7 => F8_0
  | F8_1, F8_0 => F8_6 | F8_1, F8_1 => F8_3 | F8_1, F8_2 => F8_4 | F8_1, F8_3 => F8_5 | F8_1, F8_4 => F8_2 | F8_1, F8_5 => F8_7 | F8_1, F8_6 => F8_0 | F8_1, F8_7 => F8_1
  | F8_2, F8_0 => F8_7 | F8_2, F8_1 => F8_0 | F8_2, F8_2 => F8_5 | F8_2, F8_3 => F8_6 | F8_2, F8_4 => F8_3 | F8_2, F8_5 => F8_4 | F8_2, F8_6 => F8_1 | F8_2, F8_7 => F8_2
  | F8_3, F8_0 => F8_4 | F8_3, F8_1 => F8_5 | F8_3, F8_2 => F8_6 | F8_3, F8_3 => F8_3 | F8_3, F8_4 => F8_0 | F8_3, F8_5 => F8_1 | F8_3, F8_6 => F8_2 | F8_3, F8_7 => F8_7
  | F8_4, F8_0 => F8_5 | F8_4, F8_1 => F8_6 | F8_4, F8_2 => F8_7 | F8_4, F8_3 => F8_0 | F8_4, F8_4 => F8_1 | F8_4, F8_5 => F8_2 | F8_4, F8_6 => F8_3 | F8_4, F8_7 => F8_4
  | F8_5, F8_0 => F8_2 | F8_5, F8_1 => F8_7 | F8_5, F8_2 => F8_0 | F8_5, F8_3 => F8_1 | F8_5, F8_4 => F8_6 | F8_5, F8_5 => F8_3 | F8_5, F8_6 => F8_4 | F8_5, F8_7 => F8_5
  | F8_6, F8_0 => F8_3 | F8_6, F8_1 => F8_4 | F8_6, F8_2 => F8_1 | F8_6, F8_3 => F8_2 | F8_6, F8_4 => F8_7 | F8_6, F8_5 => F8_0 | F8_6, F8_6 => F8_5 | F8_6, F8_7 => F8_6
  | F8_7, F8_0 => F8_0 | F8_7, F8_1 => F8_1 | F8_7, F8_2 => F8_2 | F8_7, F8_3 => F8_7 | F8_7, F8_4 => F8_4 | F8_7, F8_5 => F8_5 | F8_7, F8_6 => F8_6 | F8_7, F8_7 => F8_3
  end.

#[local] Instance refa22_inst : Magma Fin8 := {| magma_op := refa22_op |}.

Lemma refa22_sat1932 : @Equation1932 Fin8 refa22_inst.
Proof. unfold Equation1932, magma_op, refa22_inst, refa22_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa22_not411 : ~ @Equation411 Fin8 refa22_inst.
Proof. unfold Equation411. intro H. specialize (H F8_0). unfold magma_op, refa22_inst, refa22_op in H. discriminate H. Qed.

Lemma refa22_not707 : ~ @Equation707 Fin8 refa22_inst.
Proof. unfold Equation707. intro H. specialize (H F8_1 F8_0). unfold magma_op, refa22_inst, refa22_op in H. discriminate H. Qed.

Lemma refa22_not817 : ~ @Equation817 Fin8 refa22_inst.
Proof. unfold Equation817. intro H. specialize (H F8_0). unfold magma_op, refa22_inst, refa22_op in H. discriminate H. Qed.

Lemma refa22_not1426 : ~ @Equation1426 Fin8 refa22_inst.
Proof. unfold Equation1426. intro H. specialize (H F8_0). unfold magma_op, refa22_inst, refa22_op in H. discriminate H. Qed.

Lemma refa22_not2035 : ~ @Equation2035 Fin8 refa22_inst.
Proof. unfold Equation2035. intro H. specialize (H F8_0). unfold magma_op, refa22_inst, refa22_op in H. discriminate H. Qed.

Lemma refa22_not3050 : ~ @Equation3050 Fin8 refa22_inst.
Proof. unfold Equation3050. intro H. specialize (H F8_0). unfold magma_op, refa22_inst, refa22_op in H. discriminate H. Qed.

Lemma refa22_not4380 : ~ @Equation4380 Fin8 refa22_inst.
Proof. unfold Equation4380. intro H. specialize (H F8_0). unfold magma_op, refa22_inst, refa22_op in H. discriminate H. Qed.

(** ---- refa220 (Fin3) ---- *)

Definition refa220_op (x y : Fin3) : Fin3 :=
  match x, y with
  | F3_0, F3_0 => F3_0 | F3_0, F3_1 => F3_1 | F3_0, F3_2 => F3_1
  | F3_1, F3_0 => F3_0 | F3_1, F3_1 => F3_1 | F3_1, F3_2 => F3_0
  | F3_2, F3_0 => F3_0 | F3_2, F3_1 => F3_1 | F3_2, F3_2 => F3_0
  end.

#[local] Instance refa220_inst : Magma Fin3 := {| magma_op := refa220_op |}.

Lemma refa220_sat343 : @Equation343 Fin3 refa220_inst.
Proof. unfold Equation343, magma_op, refa220_inst, refa220_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa220_not4599 : ~ @Equation4599 Fin3 refa220_inst.
Proof. unfold Equation4599. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa220_inst, refa220_op in H. discriminate H. Qed.

Lemma refa220_not4635 : ~ @Equation4635 Fin3 refa220_inst.
Proof. unfold Equation4635. intro H. specialize (H F3_2 F3_0). unfold magma_op, refa220_inst, refa220_op in H. discriminate H. Qed.

(** ---- refa221 (Fin3) ---- *)

Definition refa221_op (x y : Fin3) : Fin3 :=
  match x, y with
  | F3_0, F3_0 => F3_0 | F3_0, F3_1 => F3_0 | F3_0, F3_2 => F3_1
  | F3_1, F3_0 => F3_0 | F3_1, F3_1 => F3_0 | F3_1, F3_2 => F3_1
  | F3_2, F3_0 => F3_1 | F3_2, F3_1 => F3_1 | F3_2, F3_2 => F3_0
  end.

#[local] Instance refa221_inst : Magma Fin3 := {| magma_op := refa221_op |}.

Lemma refa221_sat4535 : @Equation4535 Fin3 refa221_inst.
Proof. unfold Equation4535, magma_op, refa221_inst, refa221_op. intros x y z w. destruct x, y, z, w; reflexivity. Qed.

Lemma refa221_not4272 : ~ @Equation4272 Fin3 refa221_inst.
Proof. unfold Equation4272. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa221_inst, refa221_op in H. discriminate H. Qed.

Lemma refa221_not4273 : ~ @Equation4273 Fin3 refa221_inst.
Proof. unfold Equation4273. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa221_inst, refa221_op in H. discriminate H. Qed.

Lemma refa221_not4275 : ~ @Equation4275 Fin3 refa221_inst.
Proof. unfold Equation4275. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa221_inst, refa221_op in H. discriminate H. Qed.

Lemma refa221_not4276 : ~ @Equation4276 Fin3 refa221_inst.
Proof. unfold Equation4276. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa221_inst, refa221_op in H. discriminate H. Qed.

Lemma refa221_not4290 : ~ @Equation4290 Fin3 refa221_inst.
Proof. unfold Equation4290. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa221_inst, refa221_op in H. discriminate H. Qed.

Lemma refa221_not4291 : ~ @Equation4291 Fin3 refa221_inst.
Proof. unfold Equation4291. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa221_inst, refa221_op in H. discriminate H. Qed.

Lemma refa221_not4293 : ~ @Equation4293 Fin3 refa221_inst.
Proof. unfold Equation4293. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa221_inst, refa221_op in H. discriminate H. Qed.

Lemma refa221_not4320 : ~ @Equation4320 Fin3 refa221_inst.
Proof. unfold Equation4320. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa221_inst, refa221_op in H. discriminate H. Qed.

Lemma refa221_not4321 : ~ @Equation4321 Fin3 refa221_inst.
Proof. unfold Equation4321. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa221_inst, refa221_op in H. discriminate H. Qed.

Lemma refa221_not4343 : ~ @Equation4343 Fin3 refa221_inst.
Proof. unfold Equation4343. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa221_inst, refa221_op in H. discriminate H. Qed.

Lemma refa221_not4396 : ~ @Equation4396 Fin3 refa221_inst.
Proof. unfold Equation4396. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa221_inst, refa221_op in H. discriminate H. Qed.

Lemma refa221_not4399 : ~ @Equation4399 Fin3 refa221_inst.
Proof. unfold Equation4399. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa221_inst, refa221_op in H. discriminate H. Qed.

Lemma refa221_not4406 : ~ @Equation4406 Fin3 refa221_inst.
Proof. unfold Equation4406. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa221_inst, refa221_op in H. discriminate H. Qed.

Lemma refa221_not4433 : ~ @Equation4433 Fin3 refa221_inst.
Proof. unfold Equation4433. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa221_inst, refa221_op in H. discriminate H. Qed.

Lemma refa221_not4436 : ~ @Equation4436 Fin3 refa221_inst.
Proof. unfold Equation4436. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa221_inst, refa221_op in H. discriminate H. Qed.

Lemma refa221_not4443 : ~ @Equation4443 Fin3 refa221_inst.
Proof. unfold Equation4443. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa221_inst, refa221_op in H. discriminate H. Qed.

Lemma refa221_not4470 : ~ @Equation4470 Fin3 refa221_inst.
Proof. unfold Equation4470. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa221_inst, refa221_op in H. discriminate H. Qed.

Lemma refa221_not4473 : ~ @Equation4473 Fin3 refa221_inst.
Proof. unfold Equation4473. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa221_inst, refa221_op in H. discriminate H. Qed.

Lemma refa221_not4480 : ~ @Equation4480 Fin3 refa221_inst.
Proof. unfold Equation4480. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa221_inst, refa221_op in H. discriminate H. Qed.

Lemma refa221_not4583 : ~ @Equation4583 Fin3 refa221_inst.
Proof. unfold Equation4583. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa221_inst, refa221_op in H. discriminate H. Qed.

Lemma refa221_not4585 : ~ @Equation4585 Fin3 refa221_inst.
Proof. unfold Equation4585. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa221_inst, refa221_op in H. discriminate H. Qed.

Lemma refa221_not4588 : ~ @Equation4588 Fin3 refa221_inst.
Proof. unfold Equation4588. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa221_inst, refa221_op in H. discriminate H. Qed.

Lemma refa221_not4591 : ~ @Equation4591 Fin3 refa221_inst.
Proof. unfold Equation4591. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa221_inst, refa221_op in H. discriminate H. Qed.

Lemma refa221_not4598 : ~ @Equation4598 Fin3 refa221_inst.
Proof. unfold Equation4598. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa221_inst, refa221_op in H. discriminate H. Qed.

Lemma refa221_not4605 : ~ @Equation4605 Fin3 refa221_inst.
Proof. unfold Equation4605. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa221_inst, refa221_op in H. discriminate H. Qed.

Lemma refa221_not4608 : ~ @Equation4608 Fin3 refa221_inst.
Proof. unfold Equation4608. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa221_inst, refa221_op in H. discriminate H. Qed.

Lemma refa221_not4629 : ~ @Equation4629 Fin3 refa221_inst.
Proof. unfold Equation4629. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa221_inst, refa221_op in H. discriminate H. Qed.

Lemma refa221_not4636 : ~ @Equation4636 Fin3 refa221_inst.
Proof. unfold Equation4636. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa221_inst, refa221_op in H. discriminate H. Qed.

Lemma refa221_not4658 : ~ @Equation4658 Fin3 refa221_inst.
Proof. unfold Equation4658. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa221_inst, refa221_op in H. discriminate H. Qed.

(** ---- refa222 (Fin3) ---- *)

Definition refa222_op (x y : Fin3) : Fin3 :=
  match x, y with
  | F3_0, F3_0 => F3_0 | F3_0, F3_1 => F3_0 | F3_0, F3_2 => F3_2
  | F3_1, F3_0 => F3_2 | F3_1, F3_1 => F3_1 | F3_1, F3_2 => F3_2
  | F3_2, F3_0 => F3_0 | F3_2, F3_1 => F3_1 | F3_2, F3_2 => F3_1
  end.

#[local] Instance refa222_inst : Magma Fin3 := {| magma_op := refa222_op |}.

Lemma refa222_sat2306 : @Equation2306 Fin3 refa222_inst.
Proof. unfold Equation2306, magma_op, refa222_inst, refa222_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa222_not221 : ~ @Equation221 Fin3 refa222_inst.
Proof. unfold Equation221. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa222_inst, refa222_op in H. discriminate H. Qed.

Lemma refa222_not2293 : ~ @Equation2293 Fin3 refa222_inst.
Proof. unfold Equation2293. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa222_inst, refa222_op in H. discriminate H. Qed.

Lemma refa222_not2330 : ~ @Equation2330 Fin3 refa222_inst.
Proof. unfold Equation2330. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa222_inst, refa222_op in H. discriminate H. Qed.

Lemma refa222_not2646 : ~ @Equation2646 Fin3 refa222_inst.
Proof. unfold Equation2646. intro H. specialize (H F3_2 F3_0). unfold magma_op, refa222_inst, refa222_op in H. discriminate H. Qed.

Lemma refa222_not2662 : ~ @Equation2662 Fin3 refa222_inst.
Proof. unfold Equation2662. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa222_inst, refa222_op in H. discriminate H. Qed.

Lemma refa222_not3509 : ~ @Equation3509 Fin3 refa222_inst.
Proof. unfold Equation3509. intro H. specialize (H F3_2 F3_0). unfold magma_op, refa222_inst, refa222_op in H. discriminate H. Qed.

Lemma refa222_not3664 : ~ @Equation3664 Fin3 refa222_inst.
Proof. unfold Equation3664. intro H. specialize (H F3_2 F3_0). unfold magma_op, refa222_inst, refa222_op in H. discriminate H. Qed.

Lemma refa222_not3712 : ~ @Equation3712 Fin3 refa222_inst.
Proof. unfold Equation3712. intro H. specialize (H F3_2 F3_0). unfold magma_op, refa222_inst, refa222_op in H. discriminate H. Qed.

(** ---- refa223 (Fin3) ---- *)

Definition refa223_op (x y : Fin3) : Fin3 :=
  match x, y with
  | F3_0, F3_0 => F3_1 | F3_0, F3_1 => F3_0 | F3_0, F3_2 => F3_2
  | F3_1, F3_0 => F3_2 | F3_1, F3_1 => F3_2 | F3_1, F3_2 => F3_0
  | F3_2, F3_0 => F3_0 | F3_2, F3_1 => F3_1 | F3_2, F3_2 => F3_1
  end.

#[local] Instance refa223_inst : Magma Fin3 := {| magma_op := refa223_op |}.

Lemma refa223_sat1658 : @Equation1658 Fin3 refa223_inst.
Proof. unfold Equation1658, magma_op, refa223_inst, refa223_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa223_not1832 : ~ @Equation1832 Fin3 refa223_inst.
Proof. unfold Equation1832. intro H. specialize (H F3_1). unfold magma_op, refa223_inst, refa223_op in H. discriminate H. Qed.

(** ---- refa224 (Fin3) ---- *)

Definition refa224_op (x y : Fin3) : Fin3 :=
  match x, y with
  | F3_0, F3_0 => F3_0 | F3_0, F3_1 => F3_0 | F3_0, F3_2 => F3_1
  | F3_1, F3_0 => F3_1 | F3_1, F3_1 => F3_1 | F3_1, F3_2 => F3_2
  | F3_2, F3_0 => F3_2 | F3_2, F3_1 => F3_2 | F3_2, F3_2 => F3_1
  end.

#[local] Instance refa224_inst : Magma Fin3 := {| magma_op := refa224_op |}.

Lemma refa224_sat647 : @Equation647 Fin3 refa224_inst.
Proof. unfold Equation647, magma_op, refa224_inst, refa224_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa224_sat1252 : @Equation1252 Fin3 refa224_inst.
Proof. unfold Equation1252, magma_op, refa224_inst, refa224_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa224_not622 : ~ @Equation622 Fin3 refa224_inst.
Proof. unfold Equation622. intro H. specialize (H F3_2 F3_0). unfold magma_op, refa224_inst, refa224_op in H. discriminate H. Qed.

Lemma refa224_not630 : ~ @Equation630 Fin3 refa224_inst.
Proof. unfold Equation630. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa224_inst, refa224_op in H. discriminate H. Qed.

Lemma refa224_not1229 : ~ @Equation1229 Fin3 refa224_inst.
Proof. unfold Equation1229. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa224_inst, refa224_op in H. discriminate H. Qed.

Lemma refa224_not1248 : ~ @Equation1248 Fin3 refa224_inst.
Proof. unfold Equation1248. intro H. specialize (H F3_2 F3_0). unfold magma_op, refa224_inst, refa224_op in H. discriminate H. Qed.

Lemma refa224_not3306 : ~ @Equation3306 Fin3 refa224_inst.
Proof. unfold Equation3306. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa224_inst, refa224_op in H. discriminate H. Qed.

Lemma refa224_not3464 : ~ @Equation3464 Fin3 refa224_inst.
Proof. unfold Equation3464. intro H. specialize (H F3_2 F3_0). unfold magma_op, refa224_inst, refa224_op in H. discriminate H. Qed.

Lemma refa224_not3509 : ~ @Equation3509 Fin3 refa224_inst.
Proof. unfold Equation3509. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa224_inst, refa224_op in H. discriminate H. Qed.

Lemma refa224_not3511 : ~ @Equation3511 Fin3 refa224_inst.
Proof. unfold Equation3511. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa224_inst, refa224_op in H. discriminate H. Qed.

Lemma refa224_not3665 : ~ @Equation3665 Fin3 refa224_inst.
Proof. unfold Equation3665. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa224_inst, refa224_op in H. discriminate H. Qed.

Lemma refa224_not4068 : ~ @Equation4068 Fin3 refa224_inst.
Proof. unfold Equation4068. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa224_inst, refa224_op in H. discriminate H. Qed.

(** ---- refa225 (Fin3) ---- *)

Definition refa225_op (x y : Fin3) : Fin3 :=
  match x, y with
  | F3_0, F3_0 => F3_0 | F3_0, F3_1 => F3_0 | F3_0, F3_2 => F3_1
  | F3_1, F3_0 => F3_2 | F3_1, F3_1 => F3_1 | F3_1, F3_2 => F3_1
  | F3_2, F3_0 => F3_2 | F3_2, F3_1 => F3_0 | F3_2, F3_2 => F3_2
  end.

#[local] Instance refa225_inst : Magma Fin3 := {| magma_op := refa225_op |}.

Lemma refa225_sat1039 : @Equation1039 Fin3 refa225_inst.
Proof. unfold Equation1039, magma_op, refa225_inst, refa225_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa225_sat2098 : @Equation2098 Fin3 refa225_inst.
Proof. unfold Equation2098, magma_op, refa225_inst, refa225_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa225_not56 : ~ @Equation56 Fin3 refa225_inst.
Proof. unfold Equation56. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa225_inst, refa225_op in H. discriminate H. Qed.

Lemma refa225_not75 : ~ @Equation75 Fin3 refa225_inst.
Proof. unfold Equation75. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa225_inst, refa225_op in H. discriminate H. Qed.

Lemma refa225_not1045 : ~ @Equation1045 Fin3 refa225_inst.
Proof. unfold Equation1045. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa225_inst, refa225_op in H. discriminate H. Qed.

Lemma refa225_not1049 : ~ @Equation1049 Fin3 refa225_inst.
Proof. unfold Equation1049. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa225_inst, refa225_op in H. discriminate H. Qed.

Lemma refa225_not2064 : ~ @Equation2064 Fin3 refa225_inst.
Proof. unfold Equation2064. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa225_inst, refa225_op in H. discriminate H. Qed.

Lemma refa225_not2091 : ~ @Equation2091 Fin3 refa225_inst.
Proof. unfold Equation2091. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa225_inst, refa225_op in H. discriminate H. Qed.

Lemma refa225_not2125 : ~ @Equation2125 Fin3 refa225_inst.
Proof. unfold Equation2125. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa225_inst, refa225_op in H. discriminate H. Qed.

Lemma refa225_not4598 : ~ @Equation4598 Fin3 refa225_inst.
Proof. unfold Equation4598. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa225_inst, refa225_op in H. discriminate H. Qed.

(** ---- refa226 (Fin3) ---- *)

Definition refa226_op (x y : Fin3) : Fin3 :=
  match x, y with
  | F3_0, F3_0 => F3_0 | F3_0, F3_1 => F3_0 | F3_0, F3_2 => F3_0
  | F3_1, F3_0 => F3_0 | F3_1, F3_1 => F3_0 | F3_1, F3_2 => F3_2
  | F3_2, F3_0 => F3_2 | F3_2, F3_1 => F3_2 | F3_2, F3_2 => F3_2
  end.

#[local] Instance refa226_inst : Magma Fin3 := {| magma_op := refa226_op |}.

Lemma refa226_sat3919 : @Equation3919 Fin3 refa226_inst.
Proof. unfold Equation3919, magma_op, refa226_inst, refa226_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa226_sat3926 : @Equation3926 Fin3 refa226_inst.
Proof. unfold Equation3926, magma_op, refa226_inst, refa226_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa226_sat3929 : @Equation3929 Fin3 refa226_inst.
Proof. unfold Equation3929, magma_op, refa226_inst, refa226_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa226_not3254 : ~ @Equation3254 Fin3 refa226_inst.
Proof. unfold Equation3254. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa226_inst, refa226_op in H. discriminate H. Qed.

Lemma refa226_not3255 : ~ @Equation3255 Fin3 refa226_inst.
Proof. unfold Equation3255. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa226_inst, refa226_op in H. discriminate H. Qed.

Lemma refa226_not3256 : ~ @Equation3256 Fin3 refa226_inst.
Proof. unfold Equation3256. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa226_inst, refa226_op in H. discriminate H. Qed.

Lemma refa226_not3258 : ~ @Equation3258 Fin3 refa226_inst.
Proof. unfold Equation3258. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa226_inst, refa226_op in H. discriminate H. Qed.

Lemma refa226_not3259 : ~ @Equation3259 Fin3 refa226_inst.
Proof. unfold Equation3259. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa226_inst, refa226_op in H. discriminate H. Qed.

Lemma refa226_not3261 : ~ @Equation3261 Fin3 refa226_inst.
Proof. unfold Equation3261. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa226_inst, refa226_op in H. discriminate H. Qed.

Lemma refa226_not3262 : ~ @Equation3262 Fin3 refa226_inst.
Proof. unfold Equation3262. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa226_inst, refa226_op in H. discriminate H. Qed.

Lemma refa226_not3458 : ~ @Equation3458 Fin3 refa226_inst.
Proof. unfold Equation3458. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa226_inst, refa226_op in H. discriminate H. Qed.

Lemma refa226_not3459 : ~ @Equation3459 Fin3 refa226_inst.
Proof. unfold Equation3459. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa226_inst, refa226_op in H. discriminate H. Qed.

Lemma refa226_not3461 : ~ @Equation3461 Fin3 refa226_inst.
Proof. unfold Equation3461. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa226_inst, refa226_op in H. discriminate H. Qed.

Lemma refa226_not3462 : ~ @Equation3462 Fin3 refa226_inst.
Proof. unfold Equation3462. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa226_inst, refa226_op in H. discriminate H. Qed.

Lemma refa226_not3464 : ~ @Equation3464 Fin3 refa226_inst.
Proof. unfold Equation3464. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa226_inst, refa226_op in H. discriminate H. Qed.

Lemma refa226_not3465 : ~ @Equation3465 Fin3 refa226_inst.
Proof. unfold Equation3465. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa226_inst, refa226_op in H. discriminate H. Qed.

Lemma refa226_not3509 : ~ @Equation3509 Fin3 refa226_inst.
Proof. unfold Equation3509. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa226_inst, refa226_op in H. discriminate H. Qed.

Lemma refa226_not3664 : ~ @Equation3664 Fin3 refa226_inst.
Proof. unfold Equation3664. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa226_inst, refa226_op in H. discriminate H. Qed.

Lemma refa226_not3665 : ~ @Equation3665 Fin3 refa226_inst.
Proof. unfold Equation3665. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa226_inst, refa226_op in H. discriminate H. Qed.

Lemma refa226_not3667 : ~ @Equation3667 Fin3 refa226_inst.
Proof. unfold Equation3667. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa226_inst, refa226_op in H. discriminate H. Qed.

Lemma refa226_not3668 : ~ @Equation3668 Fin3 refa226_inst.
Proof. unfold Equation3668. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa226_inst, refa226_op in H. discriminate H. Qed.

Lemma refa226_not3712 : ~ @Equation3712 Fin3 refa226_inst.
Proof. unfold Equation3712. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa226_inst, refa226_op in H. discriminate H. Qed.

Lemma refa226_not3714 : ~ @Equation3714 Fin3 refa226_inst.
Proof. unfold Equation3714. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa226_inst, refa226_op in H. discriminate H. Qed.

Lemma refa226_not3864 : ~ @Equation3864 Fin3 refa226_inst.
Proof. unfold Equation3864. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa226_inst, refa226_op in H. discriminate H. Qed.

Lemma refa226_not3865 : ~ @Equation3865 Fin3 refa226_inst.
Proof. unfold Equation3865. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa226_inst, refa226_op in H. discriminate H. Qed.

Lemma refa226_not3867 : ~ @Equation3867 Fin3 refa226_inst.
Proof. unfold Equation3867. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa226_inst, refa226_op in H. discriminate H. Qed.

Lemma refa226_not3868 : ~ @Equation3868 Fin3 refa226_inst.
Proof. unfold Equation3868. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa226_inst, refa226_op in H. discriminate H. Qed.

Lemma refa226_not3870 : ~ @Equation3870 Fin3 refa226_inst.
Proof. unfold Equation3870. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa226_inst, refa226_op in H. discriminate H. Qed.

Lemma refa226_not3871 : ~ @Equation3871 Fin3 refa226_inst.
Proof. unfold Equation3871. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa226_inst, refa226_op in H. discriminate H. Qed.

Lemma refa226_not3915 : ~ @Equation3915 Fin3 refa226_inst.
Proof. unfold Equation3915. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa226_inst, refa226_op in H. discriminate H. Qed.

Lemma refa226_not4070 : ~ @Equation4070 Fin3 refa226_inst.
Proof. unfold Equation4070. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa226_inst, refa226_op in H. discriminate H. Qed.

Lemma refa226_not4071 : ~ @Equation4071 Fin3 refa226_inst.
Proof. unfold Equation4071. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa226_inst, refa226_op in H. discriminate H. Qed.

Lemma refa226_not4073 : ~ @Equation4073 Fin3 refa226_inst.
Proof. unfold Equation4073. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa226_inst, refa226_op in H. discriminate H. Qed.

Lemma refa226_not4074 : ~ @Equation4074 Fin3 refa226_inst.
Proof. unfold Equation4074. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa226_inst, refa226_op in H. discriminate H. Qed.

Lemma refa226_not4118 : ~ @Equation4118 Fin3 refa226_inst.
Proof. unfold Equation4118. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa226_inst, refa226_op in H. discriminate H. Qed.

Lemma refa226_not4120 : ~ @Equation4120 Fin3 refa226_inst.
Proof. unfold Equation4120. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa226_inst, refa226_op in H. discriminate H. Qed.

Lemma refa226_not4121 : ~ @Equation4121 Fin3 refa226_inst.
Proof. unfold Equation4121. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa226_inst, refa226_op in H. discriminate H. Qed.

Lemma refa226_not4268 : ~ @Equation4268 Fin3 refa226_inst.
Proof. unfold Equation4268. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa226_inst, refa226_op in H. discriminate H. Qed.

Lemma refa226_not4269 : ~ @Equation4269 Fin3 refa226_inst.
Proof. unfold Equation4269. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa226_inst, refa226_op in H. discriminate H. Qed.

Lemma refa226_not4270 : ~ @Equation4270 Fin3 refa226_inst.
Proof. unfold Equation4270. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa226_inst, refa226_op in H. discriminate H. Qed.

Lemma refa226_not4358 : ~ @Equation4358 Fin3 refa226_inst.
Proof. unfold Equation4358. intro H. specialize (H F3_1 F3_0 F3_2). unfold magma_op, refa226_inst, refa226_op in H. discriminate H. Qed.

Lemma refa226_not4396 : ~ @Equation4396 Fin3 refa226_inst.
Proof. unfold Equation4396. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa226_inst, refa226_op in H. discriminate H. Qed.

Lemma refa226_not4433 : ~ @Equation4433 Fin3 refa226_inst.
Proof. unfold Equation4433. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa226_inst, refa226_op in H. discriminate H. Qed.

Lemma refa226_not4470 : ~ @Equation4470 Fin3 refa226_inst.
Proof. unfold Equation4470. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa226_inst, refa226_op in H. discriminate H. Qed.

Lemma refa226_not4584 : ~ @Equation4584 Fin3 refa226_inst.
Proof. unfold Equation4584. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa226_inst, refa226_op in H. discriminate H. Qed.

Lemma refa226_not4585 : ~ @Equation4585 Fin3 refa226_inst.
Proof. unfold Equation4585. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa226_inst, refa226_op in H. discriminate H. Qed.

Lemma refa226_not4598 : ~ @Equation4598 Fin3 refa226_inst.
Proof. unfold Equation4598. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa226_inst, refa226_op in H. discriminate H. Qed.

Lemma refa226_not4599 : ~ @Equation4599 Fin3 refa226_inst.
Proof. unfold Equation4599. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa226_inst, refa226_op in H. discriminate H. Qed.

(** ---- refa227 (Fin3) ---- *)

Definition refa227_op (x y : Fin3) : Fin3 :=
  match x, y with
  | F3_0, F3_0 => F3_0 | F3_0, F3_1 => F3_1 | F3_0, F3_2 => F3_2
  | F3_1, F3_0 => F3_0 | F3_1, F3_1 => F3_1 | F3_1, F3_2 => F3_2
  | F3_2, F3_0 => F3_0 | F3_2, F3_1 => F3_0 | F3_2, F3_2 => F3_1
  end.

#[local] Instance refa227_inst : Magma Fin3 := {| magma_op := refa227_op |}.

Lemma refa227_sat2420 : @Equation2420 Fin3 refa227_inst.
Proof. unfold Equation2420, magma_op, refa227_inst, refa227_op. intros x y z w. destruct x, y, z, w; reflexivity. Qed.

Lemma refa227_sat2558 : @Equation2558 Fin3 refa227_inst.
Proof. unfold Equation2558, magma_op, refa227_inst, refa227_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa227_not1631 : ~ @Equation1631 Fin3 refa227_inst.
Proof. unfold Equation1631. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa227_inst, refa227_op in H. discriminate H. Qed.

Lemma refa227_not1644 : ~ @Equation1644 Fin3 refa227_inst.
Proof. unfold Equation1644. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa227_inst, refa227_op in H. discriminate H. Qed.

Lemma refa227_not1657 : ~ @Equation1657 Fin3 refa227_inst.
Proof. unfold Equation1657. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa227_inst, refa227_op in H. discriminate H. Qed.

Lemma refa227_not1721 : ~ @Equation1721 Fin3 refa227_inst.
Proof. unfold Equation1721. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa227_inst, refa227_op in H. discriminate H. Qed.

Lemma refa227_not2240 : ~ @Equation2240 Fin3 refa227_inst.
Proof. unfold Equation2240. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa227_inst, refa227_op in H. discriminate H. Qed.

Lemma refa227_not2443 : ~ @Equation2443 Fin3 refa227_inst.
Proof. unfold Equation2443. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa227_inst, refa227_op in H. discriminate H. Qed.

Lemma refa227_not2459 : ~ @Equation2459 Fin3 refa227_inst.
Proof. unfold Equation2459. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa227_inst, refa227_op in H. discriminate H. Qed.

Lemma refa227_not2469 : ~ @Equation2469 Fin3 refa227_inst.
Proof. unfold Equation2469. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa227_inst, refa227_op in H. discriminate H. Qed.

Lemma refa227_not2646 : ~ @Equation2646 Fin3 refa227_inst.
Proof. unfold Equation2646. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa227_inst, refa227_op in H. discriminate H. Qed.

Lemma refa227_not2699 : ~ @Equation2699 Fin3 refa227_inst.
Proof. unfold Equation2699. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa227_inst, refa227_op in H. discriminate H. Qed.

Lemma refa227_not2736 : ~ @Equation2736 Fin3 refa227_inst.
Proof. unfold Equation2736. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa227_inst, refa227_op in H. discriminate H. Qed.

Lemma refa227_not3052 : ~ @Equation3052 Fin3 refa227_inst.
Proof. unfold Equation3052. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa227_inst, refa227_op in H. discriminate H. Qed.

Lemma refa227_not3068 : ~ @Equation3068 Fin3 refa227_inst.
Proof. unfold Equation3068. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa227_inst, refa227_op in H. discriminate H. Qed.

Lemma refa227_not3105 : ~ @Equation3105 Fin3 refa227_inst.
Proof. unfold Equation3105. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa227_inst, refa227_op in H. discriminate H. Qed.

Lemma refa227_not3142 : ~ @Equation3142 Fin3 refa227_inst.
Proof. unfold Equation3142. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa227_inst, refa227_op in H. discriminate H. Qed.

Lemma refa227_not3253 : ~ @Equation3253 Fin3 refa227_inst.
Proof. unfold Equation3253. intro H. specialize (H F3_2). unfold magma_op, refa227_inst, refa227_op in H. discriminate H. Qed.

Lemma refa227_not3458 : ~ @Equation3458 Fin3 refa227_inst.
Proof. unfold Equation3458. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa227_inst, refa227_op in H. discriminate H. Qed.

Lemma refa227_not3459 : ~ @Equation3459 Fin3 refa227_inst.
Proof. unfold Equation3459. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa227_inst, refa227_op in H. discriminate H. Qed.

Lemma refa227_not3461 : ~ @Equation3461 Fin3 refa227_inst.
Proof. unfold Equation3461. intro H. specialize (H F3_2 F3_0). unfold magma_op, refa227_inst, refa227_op in H. discriminate H. Qed.

Lemma refa227_not3481 : ~ @Equation3481 Fin3 refa227_inst.
Proof. unfold Equation3481. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa227_inst, refa227_op in H. discriminate H. Qed.

Lemma refa227_not3664 : ~ @Equation3664 Fin3 refa227_inst.
Proof. unfold Equation3664. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa227_inst, refa227_op in H. discriminate H. Qed.

Lemma refa227_not3674 : ~ @Equation3674 Fin3 refa227_inst.
Proof. unfold Equation3674. intro H. specialize (H F3_2 F3_0). unfold magma_op, refa227_inst, refa227_op in H. discriminate H. Qed.

Lemma refa227_not3677 : ~ @Equation3677 Fin3 refa227_inst.
Proof. unfold Equation3677. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa227_inst, refa227_op in H. discriminate H. Qed.

Lemma refa227_not4131 : ~ @Equation4131 Fin3 refa227_inst.
Proof. unfold Equation4131. intro H. specialize (H F3_2 F3_1). unfold magma_op, refa227_inst, refa227_op in H. discriminate H. Qed.

Lemma refa227_not4155 : ~ @Equation4155 Fin3 refa227_inst.
Proof. unfold Equation4155. intro H. specialize (H F3_2 F3_1). unfold magma_op, refa227_inst, refa227_op in H. discriminate H. Qed.

Lemma refa227_not4269 : ~ @Equation4269 Fin3 refa227_inst.
Proof. unfold Equation4269. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa227_inst, refa227_op in H. discriminate H. Qed.

Lemma refa227_not4272 : ~ @Equation4272 Fin3 refa227_inst.
Proof. unfold Equation4272. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa227_inst, refa227_op in H. discriminate H. Qed.

Lemma refa227_not4314 : ~ @Equation4314 Fin3 refa227_inst.
Proof. unfold Equation4314. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa227_inst, refa227_op in H. discriminate H. Qed.

Lemma refa227_not4606 : ~ @Equation4606 Fin3 refa227_inst.
Proof. unfold Equation4606. intro H. specialize (H F3_2 F3_1). unfold magma_op, refa227_inst, refa227_op in H. discriminate H. Qed.

Lemma refa227_not4631 : ~ @Equation4631 Fin3 refa227_inst.
Proof. unfold Equation4631. intro H. specialize (H F3_1 F3_0 F3_2). unfold magma_op, refa227_inst, refa227_op in H. discriminate H. Qed.

(** ---- refa228 (Fin3) ---- *)

Definition refa228_op (x y : Fin3) : Fin3 :=
  match x, y with
  | F3_0, F3_0 => F3_0 | F3_0, F3_1 => F3_0 | F3_0, F3_2 => F3_1
  | F3_1, F3_0 => F3_0 | F3_1, F3_1 => F3_0 | F3_1, F3_2 => F3_1
  | F3_2, F3_0 => F3_0 | F3_2, F3_1 => F3_2 | F3_2, F3_2 => F3_0
  end.

#[local] Instance refa228_inst : Magma Fin3 := {| magma_op := refa228_op |}.

Lemma refa228_sat317 : @Equation317 Fin3 refa228_inst.
Proof. unfold Equation317, magma_op, refa228_inst, refa228_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa228_sat3275 : @Equation3275 Fin3 refa228_inst.
Proof. unfold Equation3275, magma_op, refa228_inst, refa228_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa228_not3259 : ~ @Equation3259 Fin3 refa228_inst.
Proof. unfold Equation3259. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa228_inst, refa228_op in H. discriminate H. Qed.

Lemma refa228_not3271 : ~ @Equation3271 Fin3 refa228_inst.
Proof. unfold Equation3271. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa228_inst, refa228_op in H. discriminate H. Qed.

Lemma refa228_not3306 : ~ @Equation3306 Fin3 refa228_inst.
Proof. unfold Equation3306. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa228_inst, refa228_op in H. discriminate H. Qed.

Lemma refa228_not3456 : ~ @Equation3456 Fin3 refa228_inst.
Proof. unfold Equation3456. intro H. specialize (H F3_2). unfold magma_op, refa228_inst, refa228_op in H. discriminate H. Qed.

Lemma refa228_not3660 : ~ @Equation3660 Fin3 refa228_inst.
Proof. unfold Equation3660. intro H. specialize (H F3_2 F3_1). unfold magma_op, refa228_inst, refa228_op in H. discriminate H. Qed.

Lemma refa228_not3661 : ~ @Equation3661 Fin3 refa228_inst.
Proof. unfold Equation3661. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa228_inst, refa228_op in H. discriminate H. Qed.

Lemma refa228_not3667 : ~ @Equation3667 Fin3 refa228_inst.
Proof. unfold Equation3667. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa228_inst, refa228_op in H. discriminate H. Qed.

Lemma refa228_not3675 : ~ @Equation3675 Fin3 refa228_inst.
Proof. unfold Equation3675. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa228_inst, refa228_op in H. discriminate H. Qed.

Lemma refa228_not3685 : ~ @Equation3685 Fin3 refa228_inst.
Proof. unfold Equation3685. intro H. specialize (H F3_2 F3_1). unfold magma_op, refa228_inst, refa228_op in H. discriminate H. Qed.

Lemma refa228_not3687 : ~ @Equation3687 Fin3 refa228_inst.
Proof. unfold Equation3687. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa228_inst, refa228_op in H. discriminate H. Qed.

Lemma refa228_not3712 : ~ @Equation3712 Fin3 refa228_inst.
Proof. unfold Equation3712. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa228_inst, refa228_op in H. discriminate H. Qed.

Lemma refa228_not3749 : ~ @Equation3749 Fin3 refa228_inst.
Proof. unfold Equation3749. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa228_inst, refa228_op in H. discriminate H. Qed.

Lemma refa228_not3759 : ~ @Equation3759 Fin3 refa228_inst.
Proof. unfold Equation3759. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa228_inst, refa228_op in H. discriminate H. Qed.

Lemma refa228_not3862 : ~ @Equation3862 Fin3 refa228_inst.
Proof. unfold Equation3862. intro H. specialize (H F3_2). unfold magma_op, refa228_inst, refa228_op in H. discriminate H. Qed.

Lemma refa228_not4065 : ~ @Equation4065 Fin3 refa228_inst.
Proof. unfold Equation4065. intro H. specialize (H F3_2). unfold magma_op, refa228_inst, refa228_op in H. discriminate H. Qed.

Lemma refa228_not4269 : ~ @Equation4269 Fin3 refa228_inst.
Proof. unfold Equation4269. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa228_inst, refa228_op in H. discriminate H. Qed.

Lemma refa228_not4273 : ~ @Equation4273 Fin3 refa228_inst.
Proof. unfold Equation4273. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa228_inst, refa228_op in H. discriminate H. Qed.

Lemma refa228_not4283 : ~ @Equation4283 Fin3 refa228_inst.
Proof. unfold Equation4283. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa228_inst, refa228_op in H. discriminate H. Qed.

Lemma refa228_not4291 : ~ @Equation4291 Fin3 refa228_inst.
Proof. unfold Equation4291. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa228_inst, refa228_op in H. discriminate H. Qed.

Lemma refa228_not4314 : ~ @Equation4314 Fin3 refa228_inst.
Proof. unfold Equation4314. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa228_inst, refa228_op in H. discriminate H. Qed.

Lemma refa228_not4320 : ~ @Equation4320 Fin3 refa228_inst.
Proof. unfold Equation4320. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa228_inst, refa228_op in H. discriminate H. Qed.

Lemma refa228_not4321 : ~ @Equation4321 Fin3 refa228_inst.
Proof. unfold Equation4321. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa228_inst, refa228_op in H. discriminate H. Qed.

Lemma refa228_not4369 : ~ @Equation4369 Fin3 refa228_inst.
Proof. unfold Equation4369. intro H. specialize (H F3_0 F3_2 F3_1). unfold magma_op, refa228_inst, refa228_op in H. discriminate H. Qed.

Lemma refa228_not4380 : ~ @Equation4380 Fin3 refa228_inst.
Proof. unfold Equation4380. intro H. specialize (H F3_2). unfold magma_op, refa228_inst, refa228_op in H. discriminate H. Qed.

Lemma refa228_not4583 : ~ @Equation4583 Fin3 refa228_inst.
Proof. unfold Equation4583. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa228_inst, refa228_op in H. discriminate H. Qed.

Lemma refa228_not4584 : ~ @Equation4584 Fin3 refa228_inst.
Proof. unfold Equation4584. intro H. specialize (H F3_2 F3_1). unfold magma_op, refa228_inst, refa228_op in H. discriminate H. Qed.

Lemma refa228_not4588 : ~ @Equation4588 Fin3 refa228_inst.
Proof. unfold Equation4588. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa228_inst, refa228_op in H. discriminate H. Qed.

Lemma refa228_not4591 : ~ @Equation4591 Fin3 refa228_inst.
Proof. unfold Equation4591. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa228_inst, refa228_op in H. discriminate H. Qed.

Lemma refa228_not4598 : ~ @Equation4598 Fin3 refa228_inst.
Proof. unfold Equation4598. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa228_inst, refa228_op in H. discriminate H. Qed.

Lemma refa228_not4606 : ~ @Equation4606 Fin3 refa228_inst.
Proof. unfold Equation4606. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa228_inst, refa228_op in H. discriminate H. Qed.

Lemma refa228_not4608 : ~ @Equation4608 Fin3 refa228_inst.
Proof. unfold Equation4608. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa228_inst, refa228_op in H. discriminate H. Qed.

Lemma refa228_not4636 : ~ @Equation4636 Fin3 refa228_inst.
Proof. unfold Equation4636. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa228_inst, refa228_op in H. discriminate H. Qed.

Lemma refa228_not4658 : ~ @Equation4658 Fin3 refa228_inst.
Proof. unfold Equation4658. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa228_inst, refa228_op in H. discriminate H. Qed.

(** ---- refa229 (Fin3) ---- *)

Definition refa229_op (x y : Fin3) : Fin3 :=
  match x, y with
  | F3_0, F3_0 => F3_0 | F3_0, F3_1 => F3_0 | F3_0, F3_2 => F3_0
  | F3_1, F3_0 => F3_1 | F3_1, F3_1 => F3_1 | F3_1, F3_2 => F3_2
  | F3_2, F3_0 => F3_1 | F3_2, F3_1 => F3_1 | F3_2, F3_2 => F3_2
  end.

#[local] Instance refa229_inst : Magma Fin3 := {| magma_op := refa229_op |}.

Lemma refa229_sat3515 : @Equation3515 Fin3 refa229_inst.
Proof. unfold Equation3515, magma_op, refa229_inst, refa229_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa229_sat3736 : @Equation3736 Fin3 refa229_inst.
Proof. unfold Equation3736, magma_op, refa229_inst, refa229_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa229_sat4399 : @Equation4399 Fin3 refa229_inst.
Proof. unfold Equation4399, magma_op, refa229_inst, refa229_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa229_not3255 : ~ @Equation3255 Fin3 refa229_inst.
Proof. unfold Equation3255. intro H. specialize (H F3_2 F3_0). unfold magma_op, refa229_inst, refa229_op in H. discriminate H. Qed.

Lemma refa229_not3461 : ~ @Equation3461 Fin3 refa229_inst.
Proof. unfold Equation3461. intro H. specialize (H F3_2 F3_0). unfold magma_op, refa229_inst, refa229_op in H. discriminate H. Qed.

Lemma refa229_not3464 : ~ @Equation3464 Fin3 refa229_inst.
Proof. unfold Equation3464. intro H. specialize (H F3_2 F3_0). unfold magma_op, refa229_inst, refa229_op in H. discriminate H. Qed.

Lemma refa229_not3661 : ~ @Equation3661 Fin3 refa229_inst.
Proof. unfold Equation3661. intro H. specialize (H F3_2 F3_0). unfold magma_op, refa229_inst, refa229_op in H. discriminate H. Qed.

Lemma refa229_not3667 : ~ @Equation3667 Fin3 refa229_inst.
Proof. unfold Equation3667. intro H. specialize (H F3_2 F3_0). unfold magma_op, refa229_inst, refa229_op in H. discriminate H. Qed.

Lemma refa229_not4360 : ~ @Equation4360 Fin3 refa229_inst.
Proof. unfold Equation4360. intro H. specialize (H F3_1 F3_0 F3_2 F3_1). unfold magma_op, refa229_inst, refa229_op in H. discriminate H. Qed.

Lemma refa229_not4432 : ~ @Equation4432 Fin3 refa229_inst.
Proof. unfold Equation4432. intro H. specialize (H F3_2 F3_0). unfold magma_op, refa229_inst, refa229_op in H. discriminate H. Qed.

Lemma refa229_not4435 : ~ @Equation4435 Fin3 refa229_inst.
Proof. unfold Equation4435. intro H. specialize (H F3_2 F3_0). unfold magma_op, refa229_inst, refa229_op in H. discriminate H. Qed.

(** ---- refa23 (Fin8) ---- *)

Definition refa23_op (x y : Fin8) : Fin8 :=
  match x, y with
  | F8_0, F8_0 => F8_1 | F8_0, F8_1 => F8_2 | F8_0, F8_2 => F8_3 | F8_0, F8_3 => F8_0 | F8_0, F8_4 => F8_6 | F8_0, F8_5 => F8_7 | F8_0, F8_6 => F8_4 | F8_0, F8_7 => F8_5
  | F8_1, F8_0 => F8_4 | F8_1, F8_1 => F8_3 | F8_1, F8_2 => F8_5 | F8_1, F8_3 => F8_1 | F8_1, F8_4 => F8_2 | F8_1, F8_5 => F8_0 | F8_1, F8_6 => F8_6 | F8_1, F8_7 => F8_7
  | F8_2, F8_0 => F8_3 | F8_2, F8_1 => F8_0 | F8_2, F8_2 => F8_1 | F8_2, F8_3 => F8_2 | F8_2, F8_4 => F8_7 | F8_2, F8_5 => F8_6 | F8_2, F8_6 => F8_5 | F8_2, F8_7 => F8_4
  | F8_3, F8_0 => F8_5 | F8_3, F8_1 => F8_1 | F8_3, F8_2 => F8_4 | F8_3, F8_3 => F8_3 | F8_3, F8_4 => F8_0 | F8_3, F8_5 => F8_2 | F8_3, F8_6 => F8_7 | F8_3, F8_7 => F8_6
  | F8_4, F8_0 => F8_6 | F8_4, F8_1 => F8_5 | F8_4, F8_2 => F8_7 | F8_4, F8_3 => F8_4 | F8_4, F8_4 => F8_1 | F8_4, F8_5 => F8_3 | F8_4, F8_6 => F8_0 | F8_4, F8_7 => F8_2
  | F8_5, F8_0 => F8_7 | F8_5, F8_1 => F8_4 | F8_5, F8_2 => F8_6 | F8_5, F8_3 => F8_5 | F8_5, F8_4 => F8_3 | F8_5, F8_5 => F8_1 | F8_5, F8_6 => F8_2 | F8_5, F8_7 => F8_0
  | F8_6, F8_0 => F8_2 | F8_6, F8_1 => F8_7 | F8_6, F8_2 => F8_0 | F8_6, F8_3 => F8_6 | F8_6, F8_4 => F8_4 | F8_6, F8_5 => F8_5 | F8_6, F8_6 => F8_3 | F8_6, F8_7 => F8_1
  | F8_7, F8_0 => F8_0 | F8_7, F8_1 => F8_6 | F8_7, F8_2 => F8_2 | F8_7, F8_3 => F8_7 | F8_7, F8_4 => F8_5 | F8_7, F8_5 => F8_4 | F8_7, F8_6 => F8_1 | F8_7, F8_7 => F8_3
  end.

#[local] Instance refa23_inst : Magma Fin8 := {| magma_op := refa23_op |}.

Lemma refa23_sat870 : @Equation870 Fin8 refa23_inst.
Proof. unfold Equation870, magma_op, refa23_inst, refa23_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa23_not417 : ~ @Equation417 Fin8 refa23_inst.
Proof. unfold Equation417. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa23_inst, refa23_op in H. discriminate H. Qed.

Lemma refa23_not419 : ~ @Equation419 Fin8 refa23_inst.
Proof. unfold Equation419. intro H. specialize (H F8_0 F8_4). unfold magma_op, refa23_inst, refa23_op in H. discriminate H. Qed.

Lemma refa23_not427 : ~ @Equation427 Fin8 refa23_inst.
Proof. unfold Equation427. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa23_inst, refa23_op in H. discriminate H. Qed.

Lemma refa23_not429 : ~ @Equation429 Fin8 refa23_inst.
Proof. unfold Equation429. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa23_inst, refa23_op in H. discriminate H. Qed.

Lemma refa23_not436 : ~ @Equation436 Fin8 refa23_inst.
Proof. unfold Equation436. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa23_inst, refa23_op in H. discriminate H. Qed.

Lemma refa23_not466 : ~ @Equation466 Fin8 refa23_inst.
Proof. unfold Equation466. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa23_inst, refa23_op in H. discriminate H. Qed.

Lemma refa23_not473 : ~ @Equation473 Fin8 refa23_inst.
Proof. unfold Equation473. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa23_inst, refa23_op in H. discriminate H. Qed.

Lemma refa23_not477 : ~ @Equation477 Fin8 refa23_inst.
Proof. unfold Equation477. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa23_inst, refa23_op in H. discriminate H. Qed.

Lemma refa23_not504 : ~ @Equation504 Fin8 refa23_inst.
Proof. unfold Equation504. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa23_inst, refa23_op in H. discriminate H. Qed.

Lemma refa23_not511 : ~ @Equation511 Fin8 refa23_inst.
Proof. unfold Equation511. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa23_inst, refa23_op in H. discriminate H. Qed.

Lemma refa23_not614 : ~ @Equation614 Fin8 refa23_inst.
Proof. unfold Equation614. intro H. specialize (H F8_0). unfold magma_op, refa23_inst, refa23_op in H. discriminate H. Qed.

Lemma refa23_not825 : ~ @Equation825 Fin8 refa23_inst.
Proof. unfold Equation825. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa23_inst, refa23_op in H. discriminate H. Qed.

Lemma refa23_not833 : ~ @Equation833 Fin8 refa23_inst.
Proof. unfold Equation833. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa23_inst, refa23_op in H. discriminate H. Qed.

Lemma refa23_not835 : ~ @Equation835 Fin8 refa23_inst.
Proof. unfold Equation835. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa23_inst, refa23_op in H. discriminate H. Qed.

Lemma refa23_not842 : ~ @Equation842 Fin8 refa23_inst.
Proof. unfold Equation842. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa23_inst, refa23_op in H. discriminate H. Qed.

Lemma refa23_not872 : ~ @Equation872 Fin8 refa23_inst.
Proof. unfold Equation872. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa23_inst, refa23_op in H. discriminate H. Qed.

Lemma refa23_not879 : ~ @Equation879 Fin8 refa23_inst.
Proof. unfold Equation879. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa23_inst, refa23_op in H. discriminate H. Qed.

Lemma refa23_not883 : ~ @Equation883 Fin8 refa23_inst.
Proof. unfold Equation883. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa23_inst, refa23_op in H. discriminate H. Qed.

Lemma refa23_not906 : ~ @Equation906 Fin8 refa23_inst.
Proof. unfold Equation906. intro H. specialize (H F8_0 F8_4). unfold magma_op, refa23_inst, refa23_op in H. discriminate H. Qed.

Lemma refa23_not917 : ~ @Equation917 Fin8 refa23_inst.
Proof. unfold Equation917. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa23_inst, refa23_op in H. discriminate H. Qed.

Lemma refa23_not1023 : ~ @Equation1023 Fin8 refa23_inst.
Proof. unfold Equation1023. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa23_inst, refa23_op in H. discriminate H. Qed.

Lemma refa23_not1026 : ~ @Equation1026 Fin8 refa23_inst.
Proof. unfold Equation1026. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa23_inst, refa23_op in H. discriminate H. Qed.

Lemma refa23_not1028 : ~ @Equation1028 Fin8 refa23_inst.
Proof. unfold Equation1028. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa23_inst, refa23_op in H. discriminate H. Qed.

Lemma refa23_not1036 : ~ @Equation1036 Fin8 refa23_inst.
Proof. unfold Equation1036. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa23_inst, refa23_op in H. discriminate H. Qed.

Lemma refa23_not1038 : ~ @Equation1038 Fin8 refa23_inst.
Proof. unfold Equation1038. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa23_inst, refa23_op in H. discriminate H. Qed.

Lemma refa23_not1045 : ~ @Equation1045 Fin8 refa23_inst.
Proof. unfold Equation1045. intro H. specialize (H F8_0 F8_4). unfold magma_op, refa23_inst, refa23_op in H. discriminate H. Qed.

Lemma refa23_not1082 : ~ @Equation1082 Fin8 refa23_inst.
Proof. unfold Equation1082. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa23_inst, refa23_op in H. discriminate H. Qed.

Lemma refa23_not1086 : ~ @Equation1086 Fin8 refa23_inst.
Proof. unfold Equation1086. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa23_inst, refa23_op in H. discriminate H. Qed.

Lemma refa23_not1109 : ~ @Equation1109 Fin8 refa23_inst.
Proof. unfold Equation1109. intro H. specialize (H F8_0 F8_4). unfold magma_op, refa23_inst, refa23_op in H. discriminate H. Qed.

Lemma refa23_not1113 : ~ @Equation1113 Fin8 refa23_inst.
Proof. unfold Equation1113. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa23_inst, refa23_op in H. discriminate H. Qed.

Lemma refa23_not1122 : ~ @Equation1122 Fin8 refa23_inst.
Proof. unfold Equation1122. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa23_inst, refa23_op in H. discriminate H. Qed.

Lemma refa23_not1223 : ~ @Equation1223 Fin8 refa23_inst.
Proof. unfold Equation1223. intro H. specialize (H F8_0). unfold magma_op, refa23_inst, refa23_op in H. discriminate H. Qed.

Lemma refa23_not1426 : ~ @Equation1426 Fin8 refa23_inst.
Proof. unfold Equation1426. intro H. specialize (H F8_0). unfold magma_op, refa23_inst, refa23_op in H. discriminate H. Qed.

Lemma refa23_not1629 : ~ @Equation1629 Fin8 refa23_inst.
Proof. unfold Equation1629. intro H. specialize (H F8_0). unfold magma_op, refa23_inst, refa23_op in H. discriminate H. Qed.

Lemma refa23_not1838 : ~ @Equation1838 Fin8 refa23_inst.
Proof. unfold Equation1838. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa23_inst, refa23_op in H. discriminate H. Qed.

Lemma refa23_not1848 : ~ @Equation1848 Fin8 refa23_inst.
Proof. unfold Equation1848. intro H. specialize (H F8_1 F8_0). unfold magma_op, refa23_inst, refa23_op in H. discriminate H. Qed.

Lemma refa23_not1857 : ~ @Equation1857 Fin8 refa23_inst.
Proof. unfold Equation1857. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa23_inst, refa23_op in H. discriminate H. Qed.

Lemma refa23_not1885 : ~ @Equation1885 Fin8 refa23_inst.
Proof. unfold Equation1885. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa23_inst, refa23_op in H. discriminate H. Qed.

Lemma refa23_not1887 : ~ @Equation1887 Fin8 refa23_inst.
Proof. unfold Equation1887. intro H. specialize (H F8_0 F8_4). unfold magma_op, refa23_inst, refa23_op in H. discriminate H. Qed.

Lemma refa23_not1894 : ~ @Equation1894 Fin8 refa23_inst.
Proof. unfold Equation1894. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa23_inst, refa23_op in H. discriminate H. Qed.

Lemma refa23_not1921 : ~ @Equation1921 Fin8 refa23_inst.
Proof. unfold Equation1921. intro H. specialize (H F8_0 F8_4). unfold magma_op, refa23_inst, refa23_op in H. discriminate H. Qed.

Lemma refa23_not1925 : ~ @Equation1925 Fin8 refa23_inst.
Proof. unfold Equation1925. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa23_inst, refa23_op in H. discriminate H. Qed.

Lemma refa23_not2035 : ~ @Equation2035 Fin8 refa23_inst.
Proof. unfold Equation2035. intro H. specialize (H F8_0). unfold magma_op, refa23_inst, refa23_op in H. discriminate H. Qed.

Lemma refa23_not2238 : ~ @Equation2238 Fin8 refa23_inst.
Proof. unfold Equation2238. intro H. specialize (H F8_0). unfold magma_op, refa23_inst, refa23_op in H. discriminate H. Qed.

Lemma refa23_not2441 : ~ @Equation2441 Fin8 refa23_inst.
Proof. unfold Equation2441. intro H. specialize (H F8_0). unfold magma_op, refa23_inst, refa23_op in H. discriminate H. Qed.

Lemma refa23_not2644 : ~ @Equation2644 Fin8 refa23_inst.
Proof. unfold Equation2644. intro H. specialize (H F8_0). unfold magma_op, refa23_inst, refa23_op in H. discriminate H. Qed.

Lemma refa23_not2847 : ~ @Equation2847 Fin8 refa23_inst.
Proof. unfold Equation2847. intro H. specialize (H F8_0). unfold magma_op, refa23_inst, refa23_op in H. discriminate H. Qed.

Lemma refa23_not3050 : ~ @Equation3050 Fin8 refa23_inst.
Proof. unfold Equation3050. intro H. specialize (H F8_0). unfold magma_op, refa23_inst, refa23_op in H. discriminate H. Qed.

Lemma refa23_not3253 : ~ @Equation3253 Fin8 refa23_inst.
Proof. unfold Equation3253. intro H. specialize (H F8_0). unfold magma_op, refa23_inst, refa23_op in H. discriminate H. Qed.

Lemma refa23_not3456 : ~ @Equation3456 Fin8 refa23_inst.
Proof. unfold Equation3456. intro H. specialize (H F8_0). unfold magma_op, refa23_inst, refa23_op in H. discriminate H. Qed.

Lemma refa23_not3659 : ~ @Equation3659 Fin8 refa23_inst.
Proof. unfold Equation3659. intro H. specialize (H F8_0). unfold magma_op, refa23_inst, refa23_op in H. discriminate H. Qed.

Lemma refa23_not3862 : ~ @Equation3862 Fin8 refa23_inst.
Proof. unfold Equation3862. intro H. specialize (H F8_0). unfold magma_op, refa23_inst, refa23_op in H. discriminate H. Qed.

Lemma refa23_not4065 : ~ @Equation4065 Fin8 refa23_inst.
Proof. unfold Equation4065. intro H. specialize (H F8_0). unfold magma_op, refa23_inst, refa23_op in H. discriminate H. Qed.

Lemma refa23_not4270 : ~ @Equation4270 Fin8 refa23_inst.
Proof. unfold Equation4270. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa23_inst, refa23_op in H. discriminate H. Qed.

Lemma refa23_not4273 : ~ @Equation4273 Fin8 refa23_inst.
Proof. unfold Equation4273. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa23_inst, refa23_op in H. discriminate H. Qed.

Lemma refa23_not4275 : ~ @Equation4275 Fin8 refa23_inst.
Proof. unfold Equation4275. intro H. specialize (H F8_0 F8_4). unfold magma_op, refa23_inst, refa23_op in H. discriminate H. Qed.

Lemma refa23_not4283 : ~ @Equation4283 Fin8 refa23_inst.
Proof. unfold Equation4283. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa23_inst, refa23_op in H. discriminate H. Qed.

Lemma refa23_not4290 : ~ @Equation4290 Fin8 refa23_inst.
Proof. unfold Equation4290. intro H. specialize (H F8_0 F8_4). unfold magma_op, refa23_inst, refa23_op in H. discriminate H. Qed.

Lemma refa23_not4320 : ~ @Equation4320 Fin8 refa23_inst.
Proof. unfold Equation4320. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa23_inst, refa23_op in H. discriminate H. Qed.

Lemma refa23_not4380 : ~ @Equation4380 Fin8 refa23_inst.
Proof. unfold Equation4380. intro H. specialize (H F8_0). unfold magma_op, refa23_inst, refa23_op in H. discriminate H. Qed.

Lemma refa23_not4585 : ~ @Equation4585 Fin8 refa23_inst.
Proof. unfold Equation4585. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa23_inst, refa23_op in H. discriminate H. Qed.

Lemma refa23_not4588 : ~ @Equation4588 Fin8 refa23_inst.
Proof. unfold Equation4588. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa23_inst, refa23_op in H. discriminate H. Qed.

Lemma refa23_not4590 : ~ @Equation4590 Fin8 refa23_inst.
Proof. unfold Equation4590. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa23_inst, refa23_op in H. discriminate H. Qed.

Lemma refa23_not4605 : ~ @Equation4605 Fin8 refa23_inst.
Proof. unfold Equation4605. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa23_inst, refa23_op in H. discriminate H. Qed.

Lemma refa23_not4635 : ~ @Equation4635 Fin8 refa23_inst.
Proof. unfold Equation4635. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa23_inst, refa23_op in H. discriminate H. Qed.

Lemma refa23_not4673 : ~ @Equation4673 Fin8 refa23_inst.
Proof. unfold Equation4673. intro H. specialize (H F8_0 F8_4 F8_6). unfold magma_op, refa23_inst, refa23_op in H. discriminate H. Qed.

(** ---- refa230 (Fin3) ---- *)

Definition refa230_op (x y : Fin3) : Fin3 :=
  match x, y with
  | F3_0, F3_0 => F3_0 | F3_0, F3_1 => F3_0 | F3_0, F3_2 => F3_0
  | F3_1, F3_0 => F3_1 | F3_1, F3_1 => F3_2 | F3_1, F3_2 => F3_0
  | F3_2, F3_0 => F3_2 | F3_2, F3_1 => F3_0 | F3_2, F3_2 => F3_1
  end.

#[local] Instance refa230_inst : Magma Fin3 := {| magma_op := refa230_op |}.

Lemma refa230_sat151 : @Equation151 Fin3 refa230_inst.
Proof. unfold Equation151, magma_op, refa230_inst, refa230_op. intros x. destruct x; reflexivity. Qed.

Lemma refa230_sat1036 : @Equation1036 Fin3 refa230_inst.
Proof. unfold Equation1036, magma_op, refa230_inst, refa230_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa230_sat1050 : @Equation1050 Fin3 refa230_inst.
Proof. unfold Equation1050, magma_op, refa230_inst, refa230_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa230_sat1240 : @Equation1240 Fin3 refa230_inst.
Proof. unfold Equation1240, magma_op, refa230_inst, refa230_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa230_sat1243 : @Equation1243 Fin3 refa230_inst.
Proof. unfold Equation1243, magma_op, refa230_inst, refa230_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa230_sat1263 : @Equation1263 Fin3 refa230_inst.
Proof. unfold Equation1263, magma_op, refa230_inst, refa230_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa230_not53 : ~ @Equation53 Fin3 refa230_inst.
Proof. unfold Equation53. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa230_inst, refa230_op in H. discriminate H. Qed.

Lemma refa230_not107 : ~ @Equation107 Fin3 refa230_inst.
Proof. unfold Equation107. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa230_inst, refa230_op in H. discriminate H. Qed.

Lemma refa230_not159 : ~ @Equation159 Fin3 refa230_inst.
Proof. unfold Equation159. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa230_inst, refa230_op in H. discriminate H. Qed.

Lemma refa230_not203 : ~ @Equation203 Fin3 refa230_inst.
Proof. unfold Equation203. intro H. specialize (H F3_1). unfold magma_op, refa230_inst, refa230_op in H. discriminate H. Qed.

Lemma refa230_not255 : ~ @Equation255 Fin3 refa230_inst.
Proof. unfold Equation255. intro H. specialize (H F3_1). unfold magma_op, refa230_inst, refa230_op in H. discriminate H. Qed.

Lemma refa230_not411 : ~ @Equation411 Fin3 refa230_inst.
Proof. unfold Equation411. intro H. specialize (H F3_1). unfold magma_op, refa230_inst, refa230_op in H. discriminate H. Qed.

Lemma refa230_not614 : ~ @Equation614 Fin3 refa230_inst.
Proof. unfold Equation614. intro H. specialize (H F3_1). unfold magma_op, refa230_inst, refa230_op in H. discriminate H. Qed.

Lemma refa230_not817 : ~ @Equation817 Fin3 refa230_inst.
Proof. unfold Equation817. intro H. specialize (H F3_1). unfold magma_op, refa230_inst, refa230_op in H. discriminate H. Qed.

Lemma refa230_not1022 : ~ @Equation1022 Fin3 refa230_inst.
Proof. unfold Equation1022. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa230_inst, refa230_op in H. discriminate H. Qed.

Lemma refa230_not1023 : ~ @Equation1023 Fin3 refa230_inst.
Proof. unfold Equation1023. intro H. specialize (H F3_1 F3_0). unfold magma_op, refa230_inst, refa230_op in H. discriminate H. Qed.

Lemma refa230_not1028 : ~ @Equation1028 Fin3 refa230_inst.
Proof. unfold Equation1028. intro H. specialize (H F3_1 F3_0). unfold magma_op, refa230_inst, refa230_op in H. discriminate H. Qed.

Lemma refa230_not1029 : ~ @Equation1029 Fin3 refa230_inst.
Proof. unfold Equation1029. intro H. specialize (H F3_1 F3_0). unfold magma_op, refa230_inst, refa230_op in H. discriminate H. Qed.

Lemma refa230_not1035 : ~ @Equation1035 Fin3 refa230_inst.
Proof. unfold Equation1035. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa230_inst, refa230_op in H. discriminate H. Qed.

Lemma refa230_not1039 : ~ @Equation1039 Fin3 refa230_inst.
Proof. unfold Equation1039. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa230_inst, refa230_op in H. discriminate H. Qed.

Lemma refa230_not1046 : ~ @Equation1046 Fin3 refa230_inst.
Proof. unfold Equation1046. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa230_inst, refa230_op in H. discriminate H. Qed.

Lemma refa230_not1225 : ~ @Equation1225 Fin3 refa230_inst.
Proof. unfold Equation1225. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa230_inst, refa230_op in H. discriminate H. Qed.

Lemma refa230_not1229 : ~ @Equation1229 Fin3 refa230_inst.
Proof. unfold Equation1229. intro H. specialize (H F3_1 F3_0). unfold magma_op, refa230_inst, refa230_op in H. discriminate H. Qed.

Lemma refa230_not1249 : ~ @Equation1249 Fin3 refa230_inst.
Proof. unfold Equation1249. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa230_inst, refa230_op in H. discriminate H. Qed.

Lemma refa230_not1426 : ~ @Equation1426 Fin3 refa230_inst.
Proof. unfold Equation1426. intro H. specialize (H F3_1). unfold magma_op, refa230_inst, refa230_op in H. discriminate H. Qed.

Lemma refa230_not1629 : ~ @Equation1629 Fin3 refa230_inst.
Proof. unfold Equation1629. intro H. specialize (H F3_1). unfold magma_op, refa230_inst, refa230_op in H. discriminate H. Qed.

Lemma refa230_not1832 : ~ @Equation1832 Fin3 refa230_inst.
Proof. unfold Equation1832. intro H. specialize (H F3_1). unfold magma_op, refa230_inst, refa230_op in H. discriminate H. Qed.

Lemma refa230_not2035 : ~ @Equation2035 Fin3 refa230_inst.
Proof. unfold Equation2035. intro H. specialize (H F3_1). unfold magma_op, refa230_inst, refa230_op in H. discriminate H. Qed.

Lemma refa230_not2238 : ~ @Equation2238 Fin3 refa230_inst.
Proof. unfold Equation2238. intro H. specialize (H F3_1). unfold magma_op, refa230_inst, refa230_op in H. discriminate H. Qed.

Lemma refa230_not2441 : ~ @Equation2441 Fin3 refa230_inst.
Proof. unfold Equation2441. intro H. specialize (H F3_1). unfold magma_op, refa230_inst, refa230_op in H. discriminate H. Qed.

Lemma refa230_not2644 : ~ @Equation2644 Fin3 refa230_inst.
Proof. unfold Equation2644. intro H. specialize (H F3_1). unfold magma_op, refa230_inst, refa230_op in H. discriminate H. Qed.

Lemma refa230_not2847 : ~ @Equation2847 Fin3 refa230_inst.
Proof. unfold Equation2847. intro H. specialize (H F3_1). unfold magma_op, refa230_inst, refa230_op in H. discriminate H. Qed.

Lemma refa230_not3050 : ~ @Equation3050 Fin3 refa230_inst.
Proof. unfold Equation3050. intro H. specialize (H F3_1). unfold magma_op, refa230_inst, refa230_op in H. discriminate H. Qed.

Lemma refa230_not3253 : ~ @Equation3253 Fin3 refa230_inst.
Proof. unfold Equation3253. intro H. specialize (H F3_1). unfold magma_op, refa230_inst, refa230_op in H. discriminate H. Qed.

Lemma refa230_not3456 : ~ @Equation3456 Fin3 refa230_inst.
Proof. unfold Equation3456. intro H. specialize (H F3_1). unfold magma_op, refa230_inst, refa230_op in H. discriminate H. Qed.

Lemma refa230_not3659 : ~ @Equation3659 Fin3 refa230_inst.
Proof. unfold Equation3659. intro H. specialize (H F3_1). unfold magma_op, refa230_inst, refa230_op in H. discriminate H. Qed.

Lemma refa230_not3862 : ~ @Equation3862 Fin3 refa230_inst.
Proof. unfold Equation3862. intro H. specialize (H F3_1). unfold magma_op, refa230_inst, refa230_op in H. discriminate H. Qed.

Lemma refa230_not4065 : ~ @Equation4065 Fin3 refa230_inst.
Proof. unfold Equation4065. intro H. specialize (H F3_1). unfold magma_op, refa230_inst, refa230_op in H. discriminate H. Qed.

Lemma refa230_not4268 : ~ @Equation4268 Fin3 refa230_inst.
Proof. unfold Equation4268. intro H. specialize (H F3_1 F3_0). unfold magma_op, refa230_inst, refa230_op in H. discriminate H. Qed.

Lemma refa230_not4269 : ~ @Equation4269 Fin3 refa230_inst.
Proof. unfold Equation4269. intro H. specialize (H F3_1 F3_0). unfold magma_op, refa230_inst, refa230_op in H. discriminate H. Qed.

Lemma refa230_not4270 : ~ @Equation4270 Fin3 refa230_inst.
Proof. unfold Equation4270. intro H. specialize (H F3_1 F3_0). unfold magma_op, refa230_inst, refa230_op in H. discriminate H. Qed.

Lemma refa230_not4283 : ~ @Equation4283 Fin3 refa230_inst.
Proof. unfold Equation4283. intro H. specialize (H F3_1 F3_0). unfold magma_op, refa230_inst, refa230_op in H. discriminate H. Qed.

Lemma refa230_not4284 : ~ @Equation4284 Fin3 refa230_inst.
Proof. unfold Equation4284. intro H. specialize (H F3_1 F3_0). unfold magma_op, refa230_inst, refa230_op in H. discriminate H. Qed.

Lemma refa230_not4293 : ~ @Equation4293 Fin3 refa230_inst.
Proof. unfold Equation4293. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa230_inst, refa230_op in H. discriminate H. Qed.

Lemma refa230_not4314 : ~ @Equation4314 Fin3 refa230_inst.
Proof. unfold Equation4314. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa230_inst, refa230_op in H. discriminate H. Qed.

Lemma refa230_not4398 : ~ @Equation4398 Fin3 refa230_inst.
Proof. unfold Equation4398. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa230_inst, refa230_op in H. discriminate H. Qed.

Lemma refa230_not4399 : ~ @Equation4399 Fin3 refa230_inst.
Proof. unfold Equation4399. intro H. specialize (H F3_1 F3_0). unfold magma_op, refa230_inst, refa230_op in H. discriminate H. Qed.

Lemma refa230_not4433 : ~ @Equation4433 Fin3 refa230_inst.
Proof. unfold Equation4433. intro H. specialize (H F3_1 F3_0). unfold magma_op, refa230_inst, refa230_op in H. discriminate H. Qed.

Lemma refa230_not4435 : ~ @Equation4435 Fin3 refa230_inst.
Proof. unfold Equation4435. intro H. specialize (H F3_1 F3_0). unfold magma_op, refa230_inst, refa230_op in H. discriminate H. Qed.

Lemma refa230_not4436 : ~ @Equation4436 Fin3 refa230_inst.
Proof. unfold Equation4436. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa230_inst, refa230_op in H. discriminate H. Qed.

Lemma refa230_not4470 : ~ @Equation4470 Fin3 refa230_inst.
Proof. unfold Equation4470. intro H. specialize (H F3_1 F3_0). unfold magma_op, refa230_inst, refa230_op in H. discriminate H. Qed.

Lemma refa230_not4472 : ~ @Equation4472 Fin3 refa230_inst.
Proof. unfold Equation4472. intro H. specialize (H F3_1 F3_0). unfold magma_op, refa230_inst, refa230_op in H. discriminate H. Qed.

Lemma refa230_not4473 : ~ @Equation4473 Fin3 refa230_inst.
Proof. unfold Equation4473. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa230_inst, refa230_op in H. discriminate H. Qed.

Lemma refa230_not4583 : ~ @Equation4583 Fin3 refa230_inst.
Proof. unfold Equation4583. intro H. specialize (H F3_1 F3_0). unfold magma_op, refa230_inst, refa230_op in H. discriminate H. Qed.

Lemma refa230_not4584 : ~ @Equation4584 Fin3 refa230_inst.
Proof. unfold Equation4584. intro H. specialize (H F3_1 F3_0). unfold magma_op, refa230_inst, refa230_op in H. discriminate H. Qed.

Lemma refa230_not4585 : ~ @Equation4585 Fin3 refa230_inst.
Proof. unfold Equation4585. intro H. specialize (H F3_1 F3_0). unfold magma_op, refa230_inst, refa230_op in H. discriminate H. Qed.

Lemma refa230_not4590 : ~ @Equation4590 Fin3 refa230_inst.
Proof. unfold Equation4590. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa230_inst, refa230_op in H. discriminate H. Qed.

Lemma refa230_not4598 : ~ @Equation4598 Fin3 refa230_inst.
Proof. unfold Equation4598. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa230_inst, refa230_op in H. discriminate H. Qed.

Lemma refa230_not4599 : ~ @Equation4599 Fin3 refa230_inst.
Proof. unfold Equation4599. intro H. specialize (H F3_1 F3_0). unfold magma_op, refa230_inst, refa230_op in H. discriminate H. Qed.

Lemma refa230_not4606 : ~ @Equation4606 Fin3 refa230_inst.
Proof. unfold Equation4606. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa230_inst, refa230_op in H. discriminate H. Qed.

Lemma refa230_not4608 : ~ @Equation4608 Fin3 refa230_inst.
Proof. unfold Equation4608. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa230_inst, refa230_op in H. discriminate H. Qed.

Lemma refa230_not4629 : ~ @Equation4629 Fin3 refa230_inst.
Proof. unfold Equation4629. intro H. specialize (H F3_1 F3_0). unfold magma_op, refa230_inst, refa230_op in H. discriminate H. Qed.

Lemma refa230_not4636 : ~ @Equation4636 Fin3 refa230_inst.
Proof. unfold Equation4636. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa230_inst, refa230_op in H. discriminate H. Qed.

(** ---- refa231 (Fin3) ---- *)

Definition refa231_op (x y : Fin3) : Fin3 :=
  match x, y with
  | F3_0, F3_0 => F3_0 | F3_0, F3_1 => F3_1 | F3_0, F3_2 => F3_2
  | F3_1, F3_0 => F3_0 | F3_1, F3_1 => F3_0 | F3_1, F3_2 => F3_0
  | F3_2, F3_0 => F3_0 | F3_2, F3_1 => F3_1 | F3_2, F3_2 => F3_1
  end.

#[local] Instance refa231_inst : Magma Fin3 := {| magma_op := refa231_op |}.

Lemma refa231_sat2443 : @Equation2443 Fin3 refa231_inst.
Proof. unfold Equation2443, magma_op, refa231_inst, refa231_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa231_sat2533 : @Equation2533 Fin3 refa231_inst.
Proof. unfold Equation2533, magma_op, refa231_inst, refa231_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa231_sat2709 : @Equation2709 Fin3 refa231_inst.
Proof. unfold Equation2709, magma_op, refa231_inst, refa231_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa231_not203 : ~ @Equation203 Fin3 refa231_inst.
Proof. unfold Equation203. intro H. specialize (H F3_2). unfold magma_op, refa231_inst, refa231_op in H. discriminate H. Qed.

Lemma refa231_not1629 : ~ @Equation1629 Fin3 refa231_inst.
Proof. unfold Equation1629. intro H. specialize (H F3_2). unfold magma_op, refa231_inst, refa231_op in H. discriminate H. Qed.

Lemma refa231_not2238 : ~ @Equation2238 Fin3 refa231_inst.
Proof. unfold Equation2238. intro H. specialize (H F3_2). unfold magma_op, refa231_inst, refa231_op in H. discriminate H. Qed.

Lemma refa231_not2459 : ~ @Equation2459 Fin3 refa231_inst.
Proof. unfold Equation2459. intro H. specialize (H F3_2 F3_1). unfold magma_op, refa231_inst, refa231_op in H. discriminate H. Qed.

Lemma refa231_not3050 : ~ @Equation3050 Fin3 refa231_inst.
Proof. unfold Equation3050. intro H. specialize (H F3_2). unfold magma_op, refa231_inst, refa231_op in H. discriminate H. Qed.

Lemma refa231_not3456 : ~ @Equation3456 Fin3 refa231_inst.
Proof. unfold Equation3456. intro H. specialize (H F3_2). unfold magma_op, refa231_inst, refa231_op in H. discriminate H. Qed.

Lemma refa231_not4065 : ~ @Equation4065 Fin3 refa231_inst.
Proof. unfold Equation4065. intro H. specialize (H F3_2). unfold magma_op, refa231_inst, refa231_op in H. discriminate H. Qed.

(** ---- refa232 (Fin3) ---- *)

Definition refa232_op (x y : Fin3) : Fin3 :=
  match x, y with
  | F3_0, F3_0 => F3_0 | F3_0, F3_1 => F3_0 | F3_0, F3_2 => F3_1
  | F3_1, F3_0 => F3_0 | F3_1, F3_1 => F3_0 | F3_1, F3_2 => F3_2
  | F3_2, F3_0 => F3_1 | F3_2, F3_1 => F3_2 | F3_2, F3_2 => F3_2
  end.

#[local] Instance refa232_inst : Magma Fin3 := {| magma_op := refa232_op |}.

Lemma refa232_sat3343 : @Equation3343 Fin3 refa232_inst.
Proof. unfold Equation3343, magma_op, refa232_inst, refa232_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa232_sat3345 : @Equation3345 Fin3 refa232_inst.
Proof. unfold Equation3345, magma_op, refa232_inst, refa232_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa232_sat3548 : @Equation3548 Fin3 refa232_inst.
Proof. unfold Equation3548, magma_op, refa232_inst, refa232_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa232_sat3555 : @Equation3555 Fin3 refa232_inst.
Proof. unfold Equation3555, magma_op, refa232_inst, refa232_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa232_sat4130 : @Equation4130 Fin3 refa232_inst.
Proof. unfold Equation4130, magma_op, refa232_inst, refa232_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa232_sat4155 : @Equation4155 Fin3 refa232_inst.
Proof. unfold Equation4155, magma_op, refa232_inst, refa232_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa232_sat4157 : @Equation4157 Fin3 refa232_inst.
Proof. unfold Equation4157, magma_op, refa232_inst, refa232_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa232_not3306 : ~ @Equation3306 Fin3 refa232_inst.
Proof. unfold Equation3306. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa232_inst, refa232_op in H. discriminate H. Qed.

Lemma refa232_not3315 : ~ @Equation3315 Fin3 refa232_inst.
Proof. unfold Equation3315. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa232_inst, refa232_op in H. discriminate H. Qed.

Lemma refa232_not3319 : ~ @Equation3319 Fin3 refa232_inst.
Proof. unfold Equation3319. intro H. specialize (H F3_2 F3_1). unfold magma_op, refa232_inst, refa232_op in H. discriminate H. Qed.

Lemma refa232_not3353 : ~ @Equation3353 Fin3 refa232_inst.
Proof. unfold Equation3353. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa232_inst, refa232_op in H. discriminate H. Qed.

Lemma refa232_not3509 : ~ @Equation3509 Fin3 refa232_inst.
Proof. unfold Equation3509. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa232_inst, refa232_op in H. discriminate H. Qed.

Lemma refa232_not3518 : ~ @Equation3518 Fin3 refa232_inst.
Proof. unfold Equation3518. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa232_inst, refa232_op in H. discriminate H. Qed.

Lemma refa232_not3522 : ~ @Equation3522 Fin3 refa232_inst.
Proof. unfold Equation3522. intro H. specialize (H F3_2 F3_1). unfold magma_op, refa232_inst, refa232_op in H. discriminate H. Qed.

Lemma refa232_not3549 : ~ @Equation3549 Fin3 refa232_inst.
Proof. unfold Equation3549. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa232_inst, refa232_op in H. discriminate H. Qed.

Lemma refa232_not3556 : ~ @Equation3556 Fin3 refa232_inst.
Proof. unfold Equation3556. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa232_inst, refa232_op in H. discriminate H. Qed.

Lemma refa232_not3558 : ~ @Equation3558 Fin3 refa232_inst.
Proof. unfold Equation3558. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa232_inst, refa232_op in H. discriminate H. Qed.

Lemma refa232_not3712 : ~ @Equation3712 Fin3 refa232_inst.
Proof. unfold Equation3712. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa232_inst, refa232_op in H. discriminate H. Qed.

Lemma refa232_not3714 : ~ @Equation3714 Fin3 refa232_inst.
Proof. unfold Equation3714. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa232_inst, refa232_op in H. discriminate H. Qed.

Lemma refa232_not3721 : ~ @Equation3721 Fin3 refa232_inst.
Proof. unfold Equation3721. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa232_inst, refa232_op in H. discriminate H. Qed.

Lemma refa232_not3722 : ~ @Equation3722 Fin3 refa232_inst.
Proof. unfold Equation3722. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa232_inst, refa232_op in H. discriminate H. Qed.

Lemma refa232_not3724 : ~ @Equation3724 Fin3 refa232_inst.
Proof. unfold Equation3724. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa232_inst, refa232_op in H. discriminate H. Qed.

Lemma refa232_not3725 : ~ @Equation3725 Fin3 refa232_inst.
Proof. unfold Equation3725. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa232_inst, refa232_op in H. discriminate H. Qed.

Lemma refa232_not3748 : ~ @Equation3748 Fin3 refa232_inst.
Proof. unfold Equation3748. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa232_inst, refa232_op in H. discriminate H. Qed.

Lemma refa232_not3749 : ~ @Equation3749 Fin3 refa232_inst.
Proof. unfold Equation3749. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa232_inst, refa232_op in H. discriminate H. Qed.

Lemma refa232_not3752 : ~ @Equation3752 Fin3 refa232_inst.
Proof. unfold Equation3752. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa232_inst, refa232_op in H. discriminate H. Qed.

Lemma refa232_not3759 : ~ @Equation3759 Fin3 refa232_inst.
Proof. unfold Equation3759. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa232_inst, refa232_op in H. discriminate H. Qed.

Lemma refa232_not3761 : ~ @Equation3761 Fin3 refa232_inst.
Proof. unfold Equation3761. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa232_inst, refa232_op in H. discriminate H. Qed.

Lemma refa232_not4118 : ~ @Equation4118 Fin3 refa232_inst.
Proof. unfold Equation4118. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa232_inst, refa232_op in H. discriminate H. Qed.

Lemma refa232_not4127 : ~ @Equation4127 Fin3 refa232_inst.
Proof. unfold Equation4127. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa232_inst, refa232_op in H. discriminate H. Qed.

Lemma refa232_not4131 : ~ @Equation4131 Fin3 refa232_inst.
Proof. unfold Equation4131. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa232_inst, refa232_op in H. discriminate H. Qed.

Lemma refa232_not4293 : ~ @Equation4293 Fin3 refa232_inst.
Proof. unfold Equation4293. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa232_inst, refa232_op in H. discriminate H. Qed.

Lemma refa232_not4321 : ~ @Equation4321 Fin3 refa232_inst.
Proof. unfold Equation4321. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa232_inst, refa232_op in H. discriminate H. Qed.

Lemma refa232_not4606 : ~ @Equation4606 Fin3 refa232_inst.
Proof. unfold Equation4606. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa232_inst, refa232_op in H. discriminate H. Qed.

Lemma refa232_not4636 : ~ @Equation4636 Fin3 refa232_inst.
Proof. unfold Equation4636. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa232_inst, refa232_op in H. discriminate H. Qed.

Lemma refa232_not4658 : ~ @Equation4658 Fin3 refa232_inst.
Proof. unfold Equation4658. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa232_inst, refa232_op in H. discriminate H. Qed.
