(** * All4x4 counterexamples — batch 9
    Auto-generated from Lean4 All4x4 files. *)

From Stdlib Require Import Utf8.

From ETP Require Import Magma.
From ETP Require Import FinMagma.
From ETP.Equations Require Import All.

Open Scope magma_scope.

(** ---- refa46 (Fin2) ---- *)

Definition refa46_op (x y : Fin2) : Fin2 :=
  match x, y with
  | F2_0, F2_0 => F2_0 | F2_0, F2_1 => F2_0
  | F2_1, F2_0 => F2_1 | F2_1, F2_1 => F2_1
  end.

#[local] Instance refa46_inst : Magma Fin2 := {| magma_op := refa46_op |}.

Lemma refa46_sat4 : @Equation4 Fin2 refa46_inst.
Proof. unfold Equation4, magma_op, refa46_inst, refa46_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa46_not65 : ~ @Equation65 Fin2 refa46_inst.
Proof. unfold Equation65. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa46_inst, refa46_op in H. discriminate H. Qed.

Lemma refa46_not66 : ~ @Equation66 Fin2 refa46_inst.
Proof. unfold Equation66. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa46_inst, refa46_op in H. discriminate H. Qed.

Lemma refa46_not73 : ~ @Equation73 Fin2 refa46_inst.
Proof. unfold Equation73. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa46_inst, refa46_op in H. discriminate H. Qed.

Lemma refa46_not75 : ~ @Equation75 Fin2 refa46_inst.
Proof. unfold Equation75. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa46_inst, refa46_op in H. discriminate H. Qed.

Lemma refa46_not117 : ~ @Equation117 Fin2 refa46_inst.
Proof. unfold Equation117. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa46_inst, refa46_op in H. discriminate H. Qed.

Lemma refa46_not118 : ~ @Equation118 Fin2 refa46_inst.
Proof. unfold Equation118. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa46_inst, refa46_op in H. discriminate H. Qed.

Lemma refa46_not124 : ~ @Equation124 Fin2 refa46_inst.
Proof. unfold Equation124. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa46_inst, refa46_op in H. discriminate H. Qed.

Lemma refa46_not127 : ~ @Equation127 Fin2 refa46_inst.
Proof. unfold Equation127. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa46_inst, refa46_op in H. discriminate H. Qed.

Lemma refa46_not167 : ~ @Equation167 Fin2 refa46_inst.
Proof. unfold Equation167. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa46_inst, refa46_op in H. discriminate H. Qed.

Lemma refa46_not221 : ~ @Equation221 Fin2 refa46_inst.
Proof. unfold Equation221. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa46_inst, refa46_op in H. discriminate H. Qed.

Lemma refa46_not229 : ~ @Equation229 Fin2 refa46_inst.
Proof. unfold Equation229. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa46_inst, refa46_op in H. discriminate H. Qed.

Lemma refa46_not231 : ~ @Equation231 Fin2 refa46_inst.
Proof. unfold Equation231. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa46_inst, refa46_op in H. discriminate H. Qed.

Lemma refa46_not273 : ~ @Equation273 Fin2 refa46_inst.
Proof. unfold Equation273. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa46_inst, refa46_op in H. discriminate H. Qed.

Lemma refa46_not274 : ~ @Equation274 Fin2 refa46_inst.
Proof. unfold Equation274. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa46_inst, refa46_op in H. discriminate H. Qed.

Lemma refa46_not280 : ~ @Equation280 Fin2 refa46_inst.
Proof. unfold Equation280. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa46_inst, refa46_op in H. discriminate H. Qed.

Lemma refa46_not283 : ~ @Equation283 Fin2 refa46_inst.
Proof. unfold Equation283. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa46_inst, refa46_op in H. discriminate H. Qed.

Lemma refa46_not384 : ~ @Equation384 Fin2 refa46_inst.
Proof. unfold Equation384. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa46_inst, refa46_op in H. discriminate H. Qed.

Lemma refa46_not464 : ~ @Equation464 Fin2 refa46_inst.
Proof. unfold Equation464. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa46_inst, refa46_op in H. discriminate H. Qed.

Lemma refa46_not466 : ~ @Equation466 Fin2 refa46_inst.
Proof. unfold Equation466. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa46_inst, refa46_op in H. discriminate H. Qed.

Lemma refa46_not467 : ~ @Equation467 Fin2 refa46_inst.
Proof. unfold Equation467. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa46_inst, refa46_op in H. discriminate H. Qed.

Lemma refa46_not473 : ~ @Equation473 Fin2 refa46_inst.
Proof. unfold Equation473. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa46_inst, refa46_op in H. discriminate H. Qed.

Lemma refa46_not474 : ~ @Equation474 Fin2 refa46_inst.
Proof. unfold Equation474. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa46_inst, refa46_op in H. discriminate H. Qed.

Lemma refa46_not476 : ~ @Equation476 Fin2 refa46_inst.
Proof. unfold Equation476. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa46_inst, refa46_op in H. discriminate H. Qed.

Lemma refa46_not477 : ~ @Equation477 Fin2 refa46_inst.
Proof. unfold Equation477. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa46_inst, refa46_op in H. discriminate H. Qed.

Lemma refa46_not501 : ~ @Equation501 Fin2 refa46_inst.
Proof. unfold Equation501. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa46_inst, refa46_op in H. discriminate H. Qed.

Lemma refa46_not503 : ~ @Equation503 Fin2 refa46_inst.
Proof. unfold Equation503. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa46_inst, refa46_op in H. discriminate H. Qed.

Lemma refa46_not504 : ~ @Equation504 Fin2 refa46_inst.
Proof. unfold Equation504. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa46_inst, refa46_op in H. discriminate H. Qed.

Lemma refa46_not510 : ~ @Equation510 Fin2 refa46_inst.
Proof. unfold Equation510. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa46_inst, refa46_op in H. discriminate H. Qed.

Lemma refa46_not511 : ~ @Equation511 Fin2 refa46_inst.
Proof. unfold Equation511. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa46_inst, refa46_op in H. discriminate H. Qed.

Lemma refa46_not513 : ~ @Equation513 Fin2 refa46_inst.
Proof. unfold Equation513. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa46_inst, refa46_op in H. discriminate H. Qed.

Lemma refa46_not667 : ~ @Equation667 Fin2 refa46_inst.
Proof. unfold Equation667. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa46_inst, refa46_op in H. discriminate H. Qed.

Lemma refa46_not669 : ~ @Equation669 Fin2 refa46_inst.
Proof. unfold Equation669. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa46_inst, refa46_op in H. discriminate H. Qed.

Lemma refa46_not670 : ~ @Equation670 Fin2 refa46_inst.
Proof. unfold Equation670. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa46_inst, refa46_op in H. discriminate H. Qed.

Lemma refa46_not676 : ~ @Equation676 Fin2 refa46_inst.
Proof. unfold Equation676. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa46_inst, refa46_op in H. discriminate H. Qed.

Lemma refa46_not677 : ~ @Equation677 Fin2 refa46_inst.
Proof. unfold Equation677. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa46_inst, refa46_op in H. discriminate H. Qed.

Lemma refa46_not679 : ~ @Equation679 Fin2 refa46_inst.
Proof. unfold Equation679. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa46_inst, refa46_op in H. discriminate H. Qed.

Lemma refa46_not680 : ~ @Equation680 Fin2 refa46_inst.
Proof. unfold Equation680. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa46_inst, refa46_op in H. discriminate H. Qed.

Lemma refa46_not704 : ~ @Equation704 Fin2 refa46_inst.
Proof. unfold Equation704. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa46_inst, refa46_op in H. discriminate H. Qed.

Lemma refa46_not706 : ~ @Equation706 Fin2 refa46_inst.
Proof. unfold Equation706. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa46_inst, refa46_op in H. discriminate H. Qed.

Lemma refa46_not707 : ~ @Equation707 Fin2 refa46_inst.
Proof. unfold Equation707. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa46_inst, refa46_op in H. discriminate H. Qed.

Lemma refa46_not713 : ~ @Equation713 Fin2 refa46_inst.
Proof. unfold Equation713. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa46_inst, refa46_op in H. discriminate H. Qed.

Lemma refa46_not716 : ~ @Equation716 Fin2 refa46_inst.
Proof. unfold Equation716. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa46_inst, refa46_op in H. discriminate H. Qed.

Lemma refa46_not870 : ~ @Equation870 Fin2 refa46_inst.
Proof. unfold Equation870. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa46_inst, refa46_op in H. discriminate H. Qed.

Lemma refa46_not872 : ~ @Equation872 Fin2 refa46_inst.
Proof. unfold Equation872. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa46_inst, refa46_op in H. discriminate H. Qed.

Lemma refa46_not873 : ~ @Equation873 Fin2 refa46_inst.
Proof. unfold Equation873. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa46_inst, refa46_op in H. discriminate H. Qed.

Lemma refa46_not879 : ~ @Equation879 Fin2 refa46_inst.
Proof. unfold Equation879. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa46_inst, refa46_op in H. discriminate H. Qed.

Lemma refa46_not882 : ~ @Equation882 Fin2 refa46_inst.
Proof. unfold Equation882. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa46_inst, refa46_op in H. discriminate H. Qed.

Lemma refa46_not883 : ~ @Equation883 Fin2 refa46_inst.
Proof. unfold Equation883. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa46_inst, refa46_op in H. discriminate H. Qed.

Lemma refa46_not906 : ~ @Equation906 Fin2 refa46_inst.
Proof. unfold Equation906. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa46_inst, refa46_op in H. discriminate H. Qed.

Lemma refa46_not907 : ~ @Equation907 Fin2 refa46_inst.
Proof. unfold Equation907. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa46_inst, refa46_op in H. discriminate H. Qed.

Lemma refa46_not916 : ~ @Equation916 Fin2 refa46_inst.
Proof. unfold Equation916. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa46_inst, refa46_op in H. discriminate H. Qed.

Lemma refa46_not917 : ~ @Equation917 Fin2 refa46_inst.
Proof. unfold Equation917. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa46_inst, refa46_op in H. discriminate H. Qed.

Lemma refa46_not1075 : ~ @Equation1075 Fin2 refa46_inst.
Proof. unfold Equation1075. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa46_inst, refa46_op in H. discriminate H. Qed.

Lemma refa46_not1076 : ~ @Equation1076 Fin2 refa46_inst.
Proof. unfold Equation1076. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa46_inst, refa46_op in H. discriminate H. Qed.

Lemma refa46_not1082 : ~ @Equation1082 Fin2 refa46_inst.
Proof. unfold Equation1082. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa46_inst, refa46_op in H. discriminate H. Qed.

Lemma refa46_not1083 : ~ @Equation1083 Fin2 refa46_inst.
Proof. unfold Equation1083. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa46_inst, refa46_op in H. discriminate H. Qed.

Lemma refa46_not1085 : ~ @Equation1085 Fin2 refa46_inst.
Proof. unfold Equation1085. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa46_inst, refa46_op in H. discriminate H. Qed.

Lemma refa46_not1086 : ~ @Equation1086 Fin2 refa46_inst.
Proof. unfold Equation1086. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa46_inst, refa46_op in H. discriminate H. Qed.

Lemma refa46_not1109 : ~ @Equation1109 Fin2 refa46_inst.
Proof. unfold Equation1109. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa46_inst, refa46_op in H. discriminate H. Qed.

Lemma refa46_not1110 : ~ @Equation1110 Fin2 refa46_inst.
Proof. unfold Equation1110. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa46_inst, refa46_op in H. discriminate H. Qed.

Lemma refa46_not1112 : ~ @Equation1112 Fin2 refa46_inst.
Proof. unfold Equation1112. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa46_inst, refa46_op in H. discriminate H. Qed.

Lemma refa46_not1113 : ~ @Equation1113 Fin2 refa46_inst.
Proof. unfold Equation1113. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa46_inst, refa46_op in H. discriminate H. Qed.

Lemma refa46_not1119 : ~ @Equation1119 Fin2 refa46_inst.
Proof. unfold Equation1119. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa46_inst, refa46_op in H. discriminate H. Qed.

Lemma refa46_not1122 : ~ @Equation1122 Fin2 refa46_inst.
Proof. unfold Equation1122. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa46_inst, refa46_op in H. discriminate H. Qed.

Lemma refa46_not1276 : ~ @Equation1276 Fin2 refa46_inst.
Proof. unfold Equation1276. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa46_inst, refa46_op in H. discriminate H. Qed.

Lemma refa46_not1278 : ~ @Equation1278 Fin2 refa46_inst.
Proof. unfold Equation1278. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa46_inst, refa46_op in H. discriminate H. Qed.

Lemma refa46_not1279 : ~ @Equation1279 Fin2 refa46_inst.
Proof. unfold Equation1279. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa46_inst, refa46_op in H. discriminate H. Qed.

Lemma refa46_not1285 : ~ @Equation1285 Fin2 refa46_inst.
Proof. unfold Equation1285. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa46_inst, refa46_op in H. discriminate H. Qed.

Lemma refa46_not1286 : ~ @Equation1286 Fin2 refa46_inst.
Proof. unfold Equation1286. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa46_inst, refa46_op in H. discriminate H. Qed.

Lemma refa46_not1288 : ~ @Equation1288 Fin2 refa46_inst.
Proof. unfold Equation1288. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa46_inst, refa46_op in H. discriminate H. Qed.

Lemma refa46_not1289 : ~ @Equation1289 Fin2 refa46_inst.
Proof. unfold Equation1289. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa46_inst, refa46_op in H. discriminate H. Qed.

Lemma refa46_not1312 : ~ @Equation1312 Fin2 refa46_inst.
Proof. unfold Equation1312. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa46_inst, refa46_op in H. discriminate H. Qed.

Lemma refa46_not1313 : ~ @Equation1313 Fin2 refa46_inst.
Proof. unfold Equation1313. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa46_inst, refa46_op in H. discriminate H. Qed.

Lemma refa46_not1315 : ~ @Equation1315 Fin2 refa46_inst.
Proof. unfold Equation1315. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa46_inst, refa46_op in H. discriminate H. Qed.

Lemma refa46_not1322 : ~ @Equation1322 Fin2 refa46_inst.
Proof. unfold Equation1322. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa46_inst, refa46_op in H. discriminate H. Qed.

Lemma refa46_not1325 : ~ @Equation1325 Fin2 refa46_inst.
Proof. unfold Equation1325. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa46_inst, refa46_op in H. discriminate H. Qed.

Lemma refa46_not1478 : ~ @Equation1478 Fin2 refa46_inst.
Proof. unfold Equation1478. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa46_inst, refa46_op in H. discriminate H. Qed.

Lemma refa46_not1479 : ~ @Equation1479 Fin2 refa46_inst.
Proof. unfold Equation1479. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa46_inst, refa46_op in H. discriminate H. Qed.

Lemma refa46_not1482 : ~ @Equation1482 Fin2 refa46_inst.
Proof. unfold Equation1482. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa46_inst, refa46_op in H. discriminate H. Qed.

Lemma refa46_not1488 : ~ @Equation1488 Fin2 refa46_inst.
Proof. unfold Equation1488. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa46_inst, refa46_op in H. discriminate H. Qed.

Lemma refa46_not1489 : ~ @Equation1489 Fin2 refa46_inst.
Proof. unfold Equation1489. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa46_inst, refa46_op in H. discriminate H. Qed.

Lemma refa46_not1491 : ~ @Equation1491 Fin2 refa46_inst.
Proof. unfold Equation1491. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa46_inst, refa46_op in H. discriminate H. Qed.

Lemma refa46_not1515 : ~ @Equation1515 Fin2 refa46_inst.
Proof. unfold Equation1515. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa46_inst, refa46_op in H. discriminate H. Qed.

Lemma refa46_not1516 : ~ @Equation1516 Fin2 refa46_inst.
Proof. unfold Equation1516. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa46_inst, refa46_op in H. discriminate H. Qed.

Lemma refa46_not1518 : ~ @Equation1518 Fin2 refa46_inst.
Proof. unfold Equation1518. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa46_inst, refa46_op in H. discriminate H. Qed.

Lemma refa46_not1519 : ~ @Equation1519 Fin2 refa46_inst.
Proof. unfold Equation1519. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa46_inst, refa46_op in H. discriminate H. Qed.

Lemma refa46_not1525 : ~ @Equation1525 Fin2 refa46_inst.
Proof. unfold Equation1525. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa46_inst, refa46_op in H. discriminate H. Qed.

Lemma refa46_not1526 : ~ @Equation1526 Fin2 refa46_inst.
Proof. unfold Equation1526. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa46_inst, refa46_op in H. discriminate H. Qed.

Lemma refa46_not1681 : ~ @Equation1681 Fin2 refa46_inst.
Proof. unfold Equation1681. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa46_inst, refa46_op in H. discriminate H. Qed.

Lemma refa46_not1682 : ~ @Equation1682 Fin2 refa46_inst.
Proof. unfold Equation1682. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa46_inst, refa46_op in H. discriminate H. Qed.

Lemma refa46_not1684 : ~ @Equation1684 Fin2 refa46_inst.
Proof. unfold Equation1684. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa46_inst, refa46_op in H. discriminate H. Qed.

Lemma refa46_not1685 : ~ @Equation1685 Fin2 refa46_inst.
Proof. unfold Equation1685. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa46_inst, refa46_op in H. discriminate H. Qed.

Lemma refa46_not1691 : ~ @Equation1691 Fin2 refa46_inst.
Proof. unfold Equation1691. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa46_inst, refa46_op in H. discriminate H. Qed.

Lemma refa46_not1692 : ~ @Equation1692 Fin2 refa46_inst.
Proof. unfold Equation1692. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa46_inst, refa46_op in H. discriminate H. Qed.

Lemma refa46_not1694 : ~ @Equation1694 Fin2 refa46_inst.
Proof. unfold Equation1694. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa46_inst, refa46_op in H. discriminate H. Qed.

Lemma refa46_not1719 : ~ @Equation1719 Fin2 refa46_inst.
Proof. unfold Equation1719. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa46_inst, refa46_op in H. discriminate H. Qed.

Lemma refa46_not1721 : ~ @Equation1721 Fin2 refa46_inst.
Proof. unfold Equation1721. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa46_inst, refa46_op in H. discriminate H. Qed.

Lemma refa46_not1722 : ~ @Equation1722 Fin2 refa46_inst.
Proof. unfold Equation1722. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa46_inst, refa46_op in H. discriminate H. Qed.

Lemma refa46_not1728 : ~ @Equation1728 Fin2 refa46_inst.
Proof. unfold Equation1728. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa46_inst, refa46_op in H. discriminate H. Qed.

Lemma refa46_not1731 : ~ @Equation1731 Fin2 refa46_inst.
Proof. unfold Equation1731. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa46_inst, refa46_op in H. discriminate H. Qed.

Lemma refa46_not1884 : ~ @Equation1884 Fin2 refa46_inst.
Proof. unfold Equation1884. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa46_inst, refa46_op in H. discriminate H. Qed.

Lemma refa46_not1885 : ~ @Equation1885 Fin2 refa46_inst.
Proof. unfold Equation1885. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa46_inst, refa46_op in H. discriminate H. Qed.

Lemma refa46_not1887 : ~ @Equation1887 Fin2 refa46_inst.
Proof. unfold Equation1887. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa46_inst, refa46_op in H. discriminate H. Qed.

Lemma refa46_not1888 : ~ @Equation1888 Fin2 refa46_inst.
Proof. unfold Equation1888. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa46_inst, refa46_op in H. discriminate H. Qed.

Lemma refa46_not1894 : ~ @Equation1894 Fin2 refa46_inst.
Proof. unfold Equation1894. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa46_inst, refa46_op in H. discriminate H. Qed.

Lemma refa46_not1895 : ~ @Equation1895 Fin2 refa46_inst.
Proof. unfold Equation1895. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa46_inst, refa46_op in H. discriminate H. Qed.

Lemma refa46_not1897 : ~ @Equation1897 Fin2 refa46_inst.
Proof. unfold Equation1897. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa46_inst, refa46_op in H. discriminate H. Qed.

Lemma refa46_not1921 : ~ @Equation1921 Fin2 refa46_inst.
Proof. unfold Equation1921. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa46_inst, refa46_op in H. discriminate H. Qed.

Lemma refa46_not1922 : ~ @Equation1922 Fin2 refa46_inst.
Proof. unfold Equation1922. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa46_inst, refa46_op in H. discriminate H. Qed.

Lemma refa46_not1924 : ~ @Equation1924 Fin2 refa46_inst.
Proof. unfold Equation1924. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa46_inst, refa46_op in H. discriminate H. Qed.

Lemma refa46_not1925 : ~ @Equation1925 Fin2 refa46_inst.
Proof. unfold Equation1925. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa46_inst, refa46_op in H. discriminate H. Qed.

Lemma refa46_not1931 : ~ @Equation1931 Fin2 refa46_inst.
Proof. unfold Equation1931. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa46_inst, refa46_op in H. discriminate H. Qed.

Lemma refa46_not2087 : ~ @Equation2087 Fin2 refa46_inst.
Proof. unfold Equation2087. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa46_inst, refa46_op in H. discriminate H. Qed.

Lemma refa46_not2088 : ~ @Equation2088 Fin2 refa46_inst.
Proof. unfold Equation2088. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa46_inst, refa46_op in H. discriminate H. Qed.

Lemma refa46_not2091 : ~ @Equation2091 Fin2 refa46_inst.
Proof. unfold Equation2091. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa46_inst, refa46_op in H. discriminate H. Qed.

Lemma refa46_not2097 : ~ @Equation2097 Fin2 refa46_inst.
Proof. unfold Equation2097. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa46_inst, refa46_op in H. discriminate H. Qed.

Lemma refa46_not2098 : ~ @Equation2098 Fin2 refa46_inst.
Proof. unfold Equation2098. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa46_inst, refa46_op in H. discriminate H. Qed.

Lemma refa46_not2101 : ~ @Equation2101 Fin2 refa46_inst.
Proof. unfold Equation2101. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa46_inst, refa46_op in H. discriminate H. Qed.

Lemma refa46_not2124 : ~ @Equation2124 Fin2 refa46_inst.
Proof. unfold Equation2124. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa46_inst, refa46_op in H. discriminate H. Qed.

Lemma refa46_not2125 : ~ @Equation2125 Fin2 refa46_inst.
Proof. unfold Equation2125. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa46_inst, refa46_op in H. discriminate H. Qed.

Lemma refa46_not2127 : ~ @Equation2127 Fin2 refa46_inst.
Proof. unfold Equation2127. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa46_inst, refa46_op in H. discriminate H. Qed.

Lemma refa46_not2128 : ~ @Equation2128 Fin2 refa46_inst.
Proof. unfold Equation2128. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa46_inst, refa46_op in H. discriminate H. Qed.

Lemma refa46_not2134 : ~ @Equation2134 Fin2 refa46_inst.
Proof. unfold Equation2134. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa46_inst, refa46_op in H. discriminate H. Qed.

Lemma refa46_not2290 : ~ @Equation2290 Fin2 refa46_inst.
Proof. unfold Equation2290. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa46_inst, refa46_op in H. discriminate H. Qed.

Lemma refa46_not2291 : ~ @Equation2291 Fin2 refa46_inst.
Proof. unfold Equation2291. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa46_inst, refa46_op in H. discriminate H. Qed.

Lemma refa46_not2293 : ~ @Equation2293 Fin2 refa46_inst.
Proof. unfold Equation2293. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa46_inst, refa46_op in H. discriminate H. Qed.

Lemma refa46_not2294 : ~ @Equation2294 Fin2 refa46_inst.
Proof. unfold Equation2294. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa46_inst, refa46_op in H. discriminate H. Qed.

Lemma refa46_not2300 : ~ @Equation2300 Fin2 refa46_inst.
Proof. unfold Equation2300. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa46_inst, refa46_op in H. discriminate H. Qed.

Lemma refa46_not2301 : ~ @Equation2301 Fin2 refa46_inst.
Proof. unfold Equation2301. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa46_inst, refa46_op in H. discriminate H. Qed.

Lemma refa46_not2303 : ~ @Equation2303 Fin2 refa46_inst.
Proof. unfold Equation2303. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa46_inst, refa46_op in H. discriminate H. Qed.

Lemma refa46_not2327 : ~ @Equation2327 Fin2 refa46_inst.
Proof. unfold Equation2327. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa46_inst, refa46_op in H. discriminate H. Qed.

Lemma refa46_not2328 : ~ @Equation2328 Fin2 refa46_inst.
Proof. unfold Equation2328. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa46_inst, refa46_op in H. discriminate H. Qed.

Lemma refa46_not2330 : ~ @Equation2330 Fin2 refa46_inst.
Proof. unfold Equation2330. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa46_inst, refa46_op in H. discriminate H. Qed.

Lemma refa46_not2337 : ~ @Equation2337 Fin2 refa46_inst.
Proof. unfold Equation2337. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa46_inst, refa46_op in H. discriminate H. Qed.

Lemma refa46_not2338 : ~ @Equation2338 Fin2 refa46_inst.
Proof. unfold Equation2338. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa46_inst, refa46_op in H. discriminate H. Qed.

Lemma refa46_not2340 : ~ @Equation2340 Fin2 refa46_inst.
Proof. unfold Equation2340. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa46_inst, refa46_op in H. discriminate H. Qed.

Lemma refa46_not2493 : ~ @Equation2493 Fin2 refa46_inst.
Proof. unfold Equation2493. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa46_inst, refa46_op in H. discriminate H. Qed.

Lemma refa46_not2496 : ~ @Equation2496 Fin2 refa46_inst.
Proof. unfold Equation2496. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa46_inst, refa46_op in H. discriminate H. Qed.

Lemma refa46_not2497 : ~ @Equation2497 Fin2 refa46_inst.
Proof. unfold Equation2497. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa46_inst, refa46_op in H. discriminate H. Qed.

Lemma refa46_not2503 : ~ @Equation2503 Fin2 refa46_inst.
Proof. unfold Equation2503. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa46_inst, refa46_op in H. discriminate H. Qed.

Lemma refa46_not2504 : ~ @Equation2504 Fin2 refa46_inst.
Proof. unfold Equation2504. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa46_inst, refa46_op in H. discriminate H. Qed.

Lemma refa46_not2506 : ~ @Equation2506 Fin2 refa46_inst.
Proof. unfold Equation2506. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa46_inst, refa46_op in H. discriminate H. Qed.

Lemma refa46_not2530 : ~ @Equation2530 Fin2 refa46_inst.
Proof. unfold Equation2530. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa46_inst, refa46_op in H. discriminate H. Qed.

Lemma refa46_not2531 : ~ @Equation2531 Fin2 refa46_inst.
Proof. unfold Equation2531. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa46_inst, refa46_op in H. discriminate H. Qed.

Lemma refa46_not2533 : ~ @Equation2533 Fin2 refa46_inst.
Proof. unfold Equation2533. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa46_inst, refa46_op in H. discriminate H. Qed.

Lemma refa46_not2534 : ~ @Equation2534 Fin2 refa46_inst.
Proof. unfold Equation2534. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa46_inst, refa46_op in H. discriminate H. Qed.

Lemma refa46_not2540 : ~ @Equation2540 Fin2 refa46_inst.
Proof. unfold Equation2540. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa46_inst, refa46_op in H. discriminate H. Qed.

Lemma refa46_not2541 : ~ @Equation2541 Fin2 refa46_inst.
Proof. unfold Equation2541. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa46_inst, refa46_op in H. discriminate H. Qed.

Lemma refa46_not2543 : ~ @Equation2543 Fin2 refa46_inst.
Proof. unfold Equation2543. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa46_inst, refa46_op in H. discriminate H. Qed.

Lemma refa46_not2696 : ~ @Equation2696 Fin2 refa46_inst.
Proof. unfold Equation2696. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa46_inst, refa46_op in H. discriminate H. Qed.

Lemma refa46_not2697 : ~ @Equation2697 Fin2 refa46_inst.
Proof. unfold Equation2697. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa46_inst, refa46_op in H. discriminate H. Qed.

Lemma refa46_not2699 : ~ @Equation2699 Fin2 refa46_inst.
Proof. unfold Equation2699. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa46_inst, refa46_op in H. discriminate H. Qed.

Lemma refa46_not2700 : ~ @Equation2700 Fin2 refa46_inst.
Proof. unfold Equation2700. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa46_inst, refa46_op in H. discriminate H. Qed.

Lemma refa46_not2706 : ~ @Equation2706 Fin2 refa46_inst.
Proof. unfold Equation2706. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa46_inst, refa46_op in H. discriminate H. Qed.

Lemma refa46_not2709 : ~ @Equation2709 Fin2 refa46_inst.
Proof. unfold Equation2709. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa46_inst, refa46_op in H. discriminate H. Qed.

Lemma refa46_not2710 : ~ @Equation2710 Fin2 refa46_inst.
Proof. unfold Equation2710. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa46_inst, refa46_op in H. discriminate H. Qed.

Lemma refa46_not2733 : ~ @Equation2733 Fin2 refa46_inst.
Proof. unfold Equation2733. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa46_inst, refa46_op in H. discriminate H. Qed.

Lemma refa46_not2734 : ~ @Equation2734 Fin2 refa46_inst.
Proof. unfold Equation2734. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa46_inst, refa46_op in H. discriminate H. Qed.

Lemma refa46_not2736 : ~ @Equation2736 Fin2 refa46_inst.
Proof. unfold Equation2736. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa46_inst, refa46_op in H. discriminate H. Qed.

Lemma refa46_not2743 : ~ @Equation2743 Fin2 refa46_inst.
Proof. unfold Equation2743. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa46_inst, refa46_op in H. discriminate H. Qed.

Lemma refa46_not2744 : ~ @Equation2744 Fin2 refa46_inst.
Proof. unfold Equation2744. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa46_inst, refa46_op in H. discriminate H. Qed.

Lemma refa46_not2746 : ~ @Equation2746 Fin2 refa46_inst.
Proof. unfold Equation2746. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa46_inst, refa46_op in H. discriminate H. Qed.

Lemma refa46_not2899 : ~ @Equation2899 Fin2 refa46_inst.
Proof. unfold Equation2899. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa46_inst, refa46_op in H. discriminate H. Qed.

Lemma refa46_not2900 : ~ @Equation2900 Fin2 refa46_inst.
Proof. unfold Equation2900. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa46_inst, refa46_op in H. discriminate H. Qed.

Lemma refa46_not2902 : ~ @Equation2902 Fin2 refa46_inst.
Proof. unfold Equation2902. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa46_inst, refa46_op in H. discriminate H. Qed.

Lemma refa46_not2903 : ~ @Equation2903 Fin2 refa46_inst.
Proof. unfold Equation2903. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa46_inst, refa46_op in H. discriminate H. Qed.

Lemma refa46_not2909 : ~ @Equation2909 Fin2 refa46_inst.
Proof. unfold Equation2909. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa46_inst, refa46_op in H. discriminate H. Qed.

Lemma refa46_not2910 : ~ @Equation2910 Fin2 refa46_inst.
Proof. unfold Equation2910. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa46_inst, refa46_op in H. discriminate H. Qed.

Lemma refa46_not2912 : ~ @Equation2912 Fin2 refa46_inst.
Proof. unfold Equation2912. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa46_inst, refa46_op in H. discriminate H. Qed.

Lemma refa46_not2936 : ~ @Equation2936 Fin2 refa46_inst.
Proof. unfold Equation2936. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa46_inst, refa46_op in H. discriminate H. Qed.

Lemma refa46_not2937 : ~ @Equation2937 Fin2 refa46_inst.
Proof. unfold Equation2937. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa46_inst, refa46_op in H. discriminate H. Qed.

Lemma refa46_not2939 : ~ @Equation2939 Fin2 refa46_inst.
Proof. unfold Equation2939. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa46_inst, refa46_op in H. discriminate H. Qed.

Lemma refa46_not2940 : ~ @Equation2940 Fin2 refa46_inst.
Proof. unfold Equation2940. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa46_inst, refa46_op in H. discriminate H. Qed.

Lemma refa46_not2946 : ~ @Equation2946 Fin2 refa46_inst.
Proof. unfold Equation2946. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa46_inst, refa46_op in H. discriminate H. Qed.

Lemma refa46_not2947 : ~ @Equation2947 Fin2 refa46_inst.
Proof. unfold Equation2947. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa46_inst, refa46_op in H. discriminate H. Qed.

Lemma refa46_not2949 : ~ @Equation2949 Fin2 refa46_inst.
Proof. unfold Equation2949. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa46_inst, refa46_op in H. discriminate H. Qed.

Lemma refa46_not3102 : ~ @Equation3102 Fin2 refa46_inst.
Proof. unfold Equation3102. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa46_inst, refa46_op in H. discriminate H. Qed.

Lemma refa46_not3103 : ~ @Equation3103 Fin2 refa46_inst.
Proof. unfold Equation3103. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa46_inst, refa46_op in H. discriminate H. Qed.

Lemma refa46_not3105 : ~ @Equation3105 Fin2 refa46_inst.
Proof. unfold Equation3105. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa46_inst, refa46_op in H. discriminate H. Qed.

Lemma refa46_not3106 : ~ @Equation3106 Fin2 refa46_inst.
Proof. unfold Equation3106. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa46_inst, refa46_op in H. discriminate H. Qed.

Lemma refa46_not3112 : ~ @Equation3112 Fin2 refa46_inst.
Proof. unfold Equation3112. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa46_inst, refa46_op in H. discriminate H. Qed.

Lemma refa46_not3113 : ~ @Equation3113 Fin2 refa46_inst.
Proof. unfold Equation3113. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa46_inst, refa46_op in H. discriminate H. Qed.

Lemma refa46_not3115 : ~ @Equation3115 Fin2 refa46_inst.
Proof. unfold Equation3115. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa46_inst, refa46_op in H. discriminate H. Qed.

Lemma refa46_not3116 : ~ @Equation3116 Fin2 refa46_inst.
Proof. unfold Equation3116. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa46_inst, refa46_op in H. discriminate H. Qed.

Lemma refa46_not3139 : ~ @Equation3139 Fin2 refa46_inst.
Proof. unfold Equation3139. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa46_inst, refa46_op in H. discriminate H. Qed.

Lemma refa46_not3140 : ~ @Equation3140 Fin2 refa46_inst.
Proof. unfold Equation3140. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa46_inst, refa46_op in H. discriminate H. Qed.

Lemma refa46_not3142 : ~ @Equation3142 Fin2 refa46_inst.
Proof. unfold Equation3142. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa46_inst, refa46_op in H. discriminate H. Qed.

Lemma refa46_not3143 : ~ @Equation3143 Fin2 refa46_inst.
Proof. unfold Equation3143. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa46_inst, refa46_op in H. discriminate H. Qed.

Lemma refa46_not3149 : ~ @Equation3149 Fin2 refa46_inst.
Proof. unfold Equation3149. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa46_inst, refa46_op in H. discriminate H. Qed.

Lemma refa46_not3150 : ~ @Equation3150 Fin2 refa46_inst.
Proof. unfold Equation3150. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa46_inst, refa46_op in H. discriminate H. Qed.

Lemma refa46_not3152 : ~ @Equation3152 Fin2 refa46_inst.
Proof. unfold Equation3152. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa46_inst, refa46_op in H. discriminate H. Qed.

Lemma refa46_not3268 : ~ @Equation3268 Fin2 refa46_inst.
Proof. unfold Equation3268. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa46_inst, refa46_op in H. discriminate H. Qed.

Lemma refa46_not3269 : ~ @Equation3269 Fin2 refa46_inst.
Proof. unfold Equation3269. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa46_inst, refa46_op in H. discriminate H. Qed.

Lemma refa46_not3271 : ~ @Equation3271 Fin2 refa46_inst.
Proof. unfold Equation3271. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa46_inst, refa46_op in H. discriminate H. Qed.

Lemma refa46_not3272 : ~ @Equation3272 Fin2 refa46_inst.
Proof. unfold Equation3272. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa46_inst, refa46_op in H. discriminate H. Qed.

Lemma refa46_not3278 : ~ @Equation3278 Fin2 refa46_inst.
Proof. unfold Equation3278. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa46_inst, refa46_op in H. discriminate H. Qed.

Lemma refa46_not3279 : ~ @Equation3279 Fin2 refa46_inst.
Proof. unfold Equation3279. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa46_inst, refa46_op in H. discriminate H. Qed.

Lemma refa46_not3281 : ~ @Equation3281 Fin2 refa46_inst.
Proof. unfold Equation3281. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa46_inst, refa46_op in H. discriminate H. Qed.

Lemma refa46_not3342 : ~ @Equation3342 Fin2 refa46_inst.
Proof. unfold Equation3342. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa46_inst, refa46_op in H. discriminate H. Qed.

Lemma refa46_not3343 : ~ @Equation3343 Fin2 refa46_inst.
Proof. unfold Equation3343. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa46_inst, refa46_op in H. discriminate H. Qed.

Lemma refa46_not3345 : ~ @Equation3345 Fin2 refa46_inst.
Proof. unfold Equation3345. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa46_inst, refa46_op in H. discriminate H. Qed.

Lemma refa46_not3346 : ~ @Equation3346 Fin2 refa46_inst.
Proof. unfold Equation3346. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa46_inst, refa46_op in H. discriminate H. Qed.

Lemma refa46_not3352 : ~ @Equation3352 Fin2 refa46_inst.
Proof. unfold Equation3352. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa46_inst, refa46_op in H. discriminate H. Qed.

Lemma refa46_not3353 : ~ @Equation3353 Fin2 refa46_inst.
Proof. unfold Equation3353. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa46_inst, refa46_op in H. discriminate H. Qed.

Lemma refa46_not3355 : ~ @Equation3355 Fin2 refa46_inst.
Proof. unfold Equation3355. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa46_inst, refa46_op in H. discriminate H. Qed.

Lemma refa46_not3472 : ~ @Equation3472 Fin2 refa46_inst.
Proof. unfold Equation3472. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa46_inst, refa46_op in H. discriminate H. Qed.

Lemma refa46_not3474 : ~ @Equation3474 Fin2 refa46_inst.
Proof. unfold Equation3474. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa46_inst, refa46_op in H. discriminate H. Qed.

Lemma refa46_not3475 : ~ @Equation3475 Fin2 refa46_inst.
Proof. unfold Equation3475. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa46_inst, refa46_op in H. discriminate H. Qed.

Lemma refa46_not3481 : ~ @Equation3481 Fin2 refa46_inst.
Proof. unfold Equation3481. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa46_inst, refa46_op in H. discriminate H. Qed.

Lemma refa46_not3482 : ~ @Equation3482 Fin2 refa46_inst.
Proof. unfold Equation3482. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa46_inst, refa46_op in H. discriminate H. Qed.

Lemma refa46_not3484 : ~ @Equation3484 Fin2 refa46_inst.
Proof. unfold Equation3484. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa46_inst, refa46_op in H. discriminate H. Qed.

Lemma refa46_not3545 : ~ @Equation3545 Fin2 refa46_inst.
Proof. unfold Equation3545. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa46_inst, refa46_op in H. discriminate H. Qed.

Lemma refa46_not3546 : ~ @Equation3546 Fin2 refa46_inst.
Proof. unfold Equation3546. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa46_inst, refa46_op in H. discriminate H. Qed.

Lemma refa46_not3548 : ~ @Equation3548 Fin2 refa46_inst.
Proof. unfold Equation3548. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa46_inst, refa46_op in H. discriminate H. Qed.

Lemma refa46_not3549 : ~ @Equation3549 Fin2 refa46_inst.
Proof. unfold Equation3549. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa46_inst, refa46_op in H. discriminate H. Qed.

Lemma refa46_not3555 : ~ @Equation3555 Fin2 refa46_inst.
Proof. unfold Equation3555. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa46_inst, refa46_op in H. discriminate H. Qed.

Lemma refa46_not3556 : ~ @Equation3556 Fin2 refa46_inst.
Proof. unfold Equation3556. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa46_inst, refa46_op in H. discriminate H. Qed.

Lemma refa46_not3558 : ~ @Equation3558 Fin2 refa46_inst.
Proof. unfold Equation3558. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa46_inst, refa46_op in H. discriminate H. Qed.

Lemma refa46_not3674 : ~ @Equation3674 Fin2 refa46_inst.
Proof. unfold Equation3674. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa46_inst, refa46_op in H. discriminate H. Qed.

Lemma refa46_not3675 : ~ @Equation3675 Fin2 refa46_inst.
Proof. unfold Equation3675. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa46_inst, refa46_op in H. discriminate H. Qed.

Lemma refa46_not3677 : ~ @Equation3677 Fin2 refa46_inst.
Proof. unfold Equation3677. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa46_inst, refa46_op in H. discriminate H. Qed.

Lemma refa46_not3678 : ~ @Equation3678 Fin2 refa46_inst.
Proof. unfold Equation3678. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa46_inst, refa46_op in H. discriminate H. Qed.

Lemma refa46_not3684 : ~ @Equation3684 Fin2 refa46_inst.
Proof. unfold Equation3684. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa46_inst, refa46_op in H. discriminate H. Qed.

Lemma refa46_not3685 : ~ @Equation3685 Fin2 refa46_inst.
Proof. unfold Equation3685. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa46_inst, refa46_op in H. discriminate H. Qed.

Lemma refa46_not3687 : ~ @Equation3687 Fin2 refa46_inst.
Proof. unfold Equation3687. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa46_inst, refa46_op in H. discriminate H. Qed.

Lemma refa46_not3748 : ~ @Equation3748 Fin2 refa46_inst.
Proof. unfold Equation3748. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa46_inst, refa46_op in H. discriminate H. Qed.

Lemma refa46_not3749 : ~ @Equation3749 Fin2 refa46_inst.
Proof. unfold Equation3749. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa46_inst, refa46_op in H. discriminate H. Qed.

Lemma refa46_not3752 : ~ @Equation3752 Fin2 refa46_inst.
Proof. unfold Equation3752. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa46_inst, refa46_op in H. discriminate H. Qed.

Lemma refa46_not3759 : ~ @Equation3759 Fin2 refa46_inst.
Proof. unfold Equation3759. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa46_inst, refa46_op in H. discriminate H. Qed.

Lemma refa46_not3761 : ~ @Equation3761 Fin2 refa46_inst.
Proof. unfold Equation3761. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa46_inst, refa46_op in H. discriminate H. Qed.

Lemma refa46_not3877 : ~ @Equation3877 Fin2 refa46_inst.
Proof. unfold Equation3877. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa46_inst, refa46_op in H. discriminate H. Qed.

Lemma refa46_not3878 : ~ @Equation3878 Fin2 refa46_inst.
Proof. unfold Equation3878. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa46_inst, refa46_op in H. discriminate H. Qed.

Lemma refa46_not3880 : ~ @Equation3880 Fin2 refa46_inst.
Proof. unfold Equation3880. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa46_inst, refa46_op in H. discriminate H. Qed.

Lemma refa46_not3881 : ~ @Equation3881 Fin2 refa46_inst.
Proof. unfold Equation3881. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa46_inst, refa46_op in H. discriminate H. Qed.

Lemma refa46_not3887 : ~ @Equation3887 Fin2 refa46_inst.
Proof. unfold Equation3887. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa46_inst, refa46_op in H. discriminate H. Qed.

Lemma refa46_not3888 : ~ @Equation3888 Fin2 refa46_inst.
Proof. unfold Equation3888. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa46_inst, refa46_op in H. discriminate H. Qed.

Lemma refa46_not3890 : ~ @Equation3890 Fin2 refa46_inst.
Proof. unfold Equation3890. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa46_inst, refa46_op in H. discriminate H. Qed.

Lemma refa46_not3951 : ~ @Equation3951 Fin2 refa46_inst.
Proof. unfold Equation3951. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa46_inst, refa46_op in H. discriminate H. Qed.

Lemma refa46_not3952 : ~ @Equation3952 Fin2 refa46_inst.
Proof. unfold Equation3952. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa46_inst, refa46_op in H. discriminate H. Qed.

Lemma refa46_not3954 : ~ @Equation3954 Fin2 refa46_inst.
Proof. unfold Equation3954. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa46_inst, refa46_op in H. discriminate H. Qed.

Lemma refa46_not3955 : ~ @Equation3955 Fin2 refa46_inst.
Proof. unfold Equation3955. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa46_inst, refa46_op in H. discriminate H. Qed.

Lemma refa46_not3961 : ~ @Equation3961 Fin2 refa46_inst.
Proof. unfold Equation3961. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa46_inst, refa46_op in H. discriminate H. Qed.

Lemma refa46_not3962 : ~ @Equation3962 Fin2 refa46_inst.
Proof. unfold Equation3962. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa46_inst, refa46_op in H. discriminate H. Qed.

Lemma refa46_not3964 : ~ @Equation3964 Fin2 refa46_inst.
Proof. unfold Equation3964. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa46_inst, refa46_op in H. discriminate H. Qed.

Lemma refa46_not4080 : ~ @Equation4080 Fin2 refa46_inst.
Proof. unfold Equation4080. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa46_inst, refa46_op in H. discriminate H. Qed.

Lemma refa46_not4081 : ~ @Equation4081 Fin2 refa46_inst.
Proof. unfold Equation4081. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa46_inst, refa46_op in H. discriminate H. Qed.

Lemma refa46_not4083 : ~ @Equation4083 Fin2 refa46_inst.
Proof. unfold Equation4083. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa46_inst, refa46_op in H. discriminate H. Qed.

Lemma refa46_not4084 : ~ @Equation4084 Fin2 refa46_inst.
Proof. unfold Equation4084. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa46_inst, refa46_op in H. discriminate H. Qed.

Lemma refa46_not4090 : ~ @Equation4090 Fin2 refa46_inst.
Proof. unfold Equation4090. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa46_inst, refa46_op in H. discriminate H. Qed.

Lemma refa46_not4091 : ~ @Equation4091 Fin2 refa46_inst.
Proof. unfold Equation4091. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa46_inst, refa46_op in H. discriminate H. Qed.

Lemma refa46_not4093 : ~ @Equation4093 Fin2 refa46_inst.
Proof. unfold Equation4093. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa46_inst, refa46_op in H. discriminate H. Qed.

Lemma refa46_not4154 : ~ @Equation4154 Fin2 refa46_inst.
Proof. unfold Equation4154. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa46_inst, refa46_op in H. discriminate H. Qed.

Lemma refa46_not4155 : ~ @Equation4155 Fin2 refa46_inst.
Proof. unfold Equation4155. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa46_inst, refa46_op in H. discriminate H. Qed.

Lemma refa46_not4157 : ~ @Equation4157 Fin2 refa46_inst.
Proof. unfold Equation4157. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa46_inst, refa46_op in H. discriminate H. Qed.

Lemma refa46_not4158 : ~ @Equation4158 Fin2 refa46_inst.
Proof. unfold Equation4158. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa46_inst, refa46_op in H. discriminate H. Qed.

Lemma refa46_not4164 : ~ @Equation4164 Fin2 refa46_inst.
Proof. unfold Equation4164. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa46_inst, refa46_op in H. discriminate H. Qed.

Lemma refa46_not4165 : ~ @Equation4165 Fin2 refa46_inst.
Proof. unfold Equation4165. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa46_inst, refa46_op in H. discriminate H. Qed.

Lemma refa46_not4167 : ~ @Equation4167 Fin2 refa46_inst.
Proof. unfold Equation4167. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa46_inst, refa46_op in H. discriminate H. Qed.

Lemma refa46_not4272 : ~ @Equation4272 Fin2 refa46_inst.
Proof. unfold Equation4272. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa46_inst, refa46_op in H. discriminate H. Qed.

Lemma refa46_not4273 : ~ @Equation4273 Fin2 refa46_inst.
Proof. unfold Equation4273. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa46_inst, refa46_op in H. discriminate H. Qed.

Lemma refa46_not4275 : ~ @Equation4275 Fin2 refa46_inst.
Proof. unfold Equation4275. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa46_inst, refa46_op in H. discriminate H. Qed.

Lemma refa46_not4276 : ~ @Equation4276 Fin2 refa46_inst.
Proof. unfold Equation4276. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa46_inst, refa46_op in H. discriminate H. Qed.

Lemma refa46_not4290 : ~ @Equation4290 Fin2 refa46_inst.
Proof. unfold Equation4290. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa46_inst, refa46_op in H. discriminate H. Qed.

Lemma refa46_not4291 : ~ @Equation4291 Fin2 refa46_inst.
Proof. unfold Equation4291. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa46_inst, refa46_op in H. discriminate H. Qed.

Lemma refa46_not4293 : ~ @Equation4293 Fin2 refa46_inst.
Proof. unfold Equation4293. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa46_inst, refa46_op in H. discriminate H. Qed.

Lemma refa46_not4320 : ~ @Equation4320 Fin2 refa46_inst.
Proof. unfold Equation4320. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa46_inst, refa46_op in H. discriminate H. Qed.

Lemma refa46_not4321 : ~ @Equation4321 Fin2 refa46_inst.
Proof. unfold Equation4321. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa46_inst, refa46_op in H. discriminate H. Qed.

Lemma refa46_not4343 : ~ @Equation4343 Fin2 refa46_inst.
Proof. unfold Equation4343. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa46_inst, refa46_op in H. discriminate H. Qed.

Lemma refa46_not4405 : ~ @Equation4405 Fin2 refa46_inst.
Proof. unfold Equation4405. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa46_inst, refa46_op in H. discriminate H. Qed.

Lemma refa46_not4406 : ~ @Equation4406 Fin2 refa46_inst.
Proof. unfold Equation4406. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa46_inst, refa46_op in H. discriminate H. Qed.

Lemma refa46_not4408 : ~ @Equation4408 Fin2 refa46_inst.
Proof. unfold Equation4408. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa46_inst, refa46_op in H. discriminate H. Qed.

Lemma refa46_not4442 : ~ @Equation4442 Fin2 refa46_inst.
Proof. unfold Equation4442. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa46_inst, refa46_op in H. discriminate H. Qed.

Lemma refa46_not4443 : ~ @Equation4443 Fin2 refa46_inst.
Proof. unfold Equation4443. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa46_inst, refa46_op in H. discriminate H. Qed.

Lemma refa46_not4445 : ~ @Equation4445 Fin2 refa46_inst.
Proof. unfold Equation4445. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa46_inst, refa46_op in H. discriminate H. Qed.

Lemma refa46_not4479 : ~ @Equation4479 Fin2 refa46_inst.
Proof. unfold Equation4479. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa46_inst, refa46_op in H. discriminate H. Qed.

Lemma refa46_not4480 : ~ @Equation4480 Fin2 refa46_inst.
Proof. unfold Equation4480. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa46_inst, refa46_op in H. discriminate H. Qed.

Lemma refa46_not4482 : ~ @Equation4482 Fin2 refa46_inst.
Proof. unfold Equation4482. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa46_inst, refa46_op in H. discriminate H. Qed.

Lemma refa46_not4587 : ~ @Equation4587 Fin2 refa46_inst.
Proof. unfold Equation4587. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa46_inst, refa46_op in H. discriminate H. Qed.

Lemma refa46_not4588 : ~ @Equation4588 Fin2 refa46_inst.
Proof. unfold Equation4588. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa46_inst, refa46_op in H. discriminate H. Qed.

Lemma refa46_not4590 : ~ @Equation4590 Fin2 refa46_inst.
Proof. unfold Equation4590. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa46_inst, refa46_op in H. discriminate H. Qed.

Lemma refa46_not4591 : ~ @Equation4591 Fin2 refa46_inst.
Proof. unfold Equation4591. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa46_inst, refa46_op in H. discriminate H. Qed.

Lemma refa46_not4605 : ~ @Equation4605 Fin2 refa46_inst.
Proof. unfold Equation4605. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa46_inst, refa46_op in H. discriminate H. Qed.

Lemma refa46_not4606 : ~ @Equation4606 Fin2 refa46_inst.
Proof. unfold Equation4606. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa46_inst, refa46_op in H. discriminate H. Qed.

Lemma refa46_not4608 : ~ @Equation4608 Fin2 refa46_inst.
Proof. unfold Equation4608. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa46_inst, refa46_op in H. discriminate H. Qed.

Lemma refa46_not4635 : ~ @Equation4635 Fin2 refa46_inst.
Proof. unfold Equation4635. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa46_inst, refa46_op in H. discriminate H. Qed.

Lemma refa46_not4636 : ~ @Equation4636 Fin2 refa46_inst.
Proof. unfold Equation4636. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa46_inst, refa46_op in H. discriminate H. Qed.

Lemma refa46_not4658 : ~ @Equation4658 Fin2 refa46_inst.
Proof. unfold Equation4658. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa46_inst, refa46_op in H. discriminate H. Qed.

(** ---- refa460 (Fin4) ---- *)

Definition refa460_op (x y : Fin4) : Fin4 :=
  match x, y with
  | F4_0, F4_0 => F4_3 | F4_0, F4_1 => F4_3 | F4_0, F4_2 => F4_1 | F4_0, F4_3 => F4_1
  | F4_1, F4_0 => F4_3 | F4_1, F4_1 => F4_2 | F4_1, F4_2 => F4_3 | F4_1, F4_3 => F4_2
  | F4_2, F4_0 => F4_0 | F4_2, F4_1 => F4_0 | F4_2, F4_2 => F4_1 | F4_2, F4_3 => F4_0
  | F4_3, F4_0 => F4_2 | F4_3, F4_1 => F4_2 | F4_3, F4_2 => F4_0 | F4_3, F4_3 => F4_0
  end.

#[local] Instance refa460_inst : Magma Fin4 := {| magma_op := refa460_op |}.

Lemma refa460_sat2060 : @Equation2060 Fin4 refa460_inst.
Proof. unfold Equation2060, magma_op, refa460_inst, refa460_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa460_not3253 : ~ @Equation3253 Fin4 refa460_inst.
Proof. unfold Equation3253. intro H. specialize (H F4_2). unfold magma_op, refa460_inst, refa460_op in H. discriminate H. Qed.

(** ---- refa461 (Fin4) ---- *)

Definition refa461_op (x y : Fin4) : Fin4 :=
  match x, y with
  | F4_0, F4_0 => F4_3 | F4_0, F4_1 => F4_1 | F4_0, F4_2 => F4_3 | F4_0, F4_3 => F4_3
  | F4_1, F4_0 => F4_2 | F4_1, F4_1 => F4_3 | F4_1, F4_2 => F4_0 | F4_1, F4_3 => F4_3
  | F4_2, F4_0 => F4_0 | F4_2, F4_1 => F4_3 | F4_2, F4_2 => F4_3 | F4_2, F4_3 => F4_3
  | F4_3, F4_0 => F4_0 | F4_3, F4_1 => F4_1 | F4_3, F4_2 => F4_2 | F4_3, F4_3 => F4_3
  end.

#[local] Instance refa461_inst : Magma Fin4 := {| magma_op := refa461_op |}.

Lemma refa461_sat2368 : @Equation2368 Fin4 refa461_inst.
Proof. unfold Equation2368, magma_op, refa461_inst, refa461_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa461_sat2554 : @Equation2554 Fin4 refa461_inst.
Proof. unfold Equation2554, magma_op, refa461_inst, refa461_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa461_sat2571 : @Equation2571 Fin4 refa461_inst.
Proof. unfold Equation2571, magma_op, refa461_inst, refa461_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa461_not2243 : ~ @Equation2243 Fin4 refa461_inst.
Proof. unfold Equation2243. intro H. specialize (H F4_2 F4_1). unfold magma_op, refa461_inst, refa461_op in H. discriminate H. Qed.

Lemma refa461_not2256 : ~ @Equation2256 Fin4 refa461_inst.
Proof. unfold Equation2256. intro H. specialize (H F4_1 F4_2). unfold magma_op, refa461_inst, refa461_op in H. discriminate H. Qed.

Lemma refa461_not2449 : ~ @Equation2449 Fin4 refa461_inst.
Proof. unfold Equation2449. intro H. specialize (H F4_1 F4_0). unfold magma_op, refa461_inst, refa461_op in H. discriminate H. Qed.

Lemma refa461_not2476 : ~ @Equation2476 Fin4 refa461_inst.
Proof. unfold Equation2476. intro H. specialize (H F4_2 F4_0 F4_1). unfold magma_op, refa461_inst, refa461_op in H. discriminate H. Qed.

Lemma refa461_not3115 : ~ @Equation3115 Fin4 refa461_inst.
Proof. unfold Equation3115. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa461_inst, refa461_op in H. discriminate H. Qed.

Lemma refa461_not3749 : ~ @Equation3749 Fin4 refa461_inst.
Proof. unfold Equation3749. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa461_inst, refa461_op in H. discriminate H. Qed.

Lemma refa461_not4070 : ~ @Equation4070 Fin4 refa461_inst.
Proof. unfold Equation4070. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa461_inst, refa461_op in H. discriminate H. Qed.

Lemma refa461_not4128 : ~ @Equation4128 Fin4 refa461_inst.
Proof. unfold Equation4128. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa461_inst, refa461_op in H. discriminate H. Qed.

(** ---- refa462 (Fin4) ---- *)

Definition refa462_op (x y : Fin4) : Fin4 :=
  match x, y with
  | F4_0, F4_0 => F4_3 | F4_0, F4_1 => F4_3 | F4_0, F4_2 => F4_1 | F4_0, F4_3 => F4_3
  | F4_1, F4_0 => F4_3 | F4_1, F4_1 => F4_3 | F4_1, F4_2 => F4_3 | F4_1, F4_3 => F4_3
  | F4_2, F4_0 => F4_2 | F4_2, F4_1 => F4_2 | F4_2, F4_2 => F4_2 | F4_2, F4_3 => F4_2
  | F4_3, F4_0 => F4_3 | F4_3, F4_1 => F4_3 | F4_3, F4_2 => F4_3 | F4_3, F4_3 => F4_3
  end.

#[local] Instance refa462_inst : Magma Fin4 := {| magma_op := refa462_op |}.

Lemma refa462_sat363 : @Equation363 Fin4 refa462_inst.
Proof. unfold Equation363, magma_op, refa462_inst, refa462_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa462_sat4404 : @Equation4404 Fin4 refa462_inst.
Proof. unfold Equation4404, magma_op, refa462_inst, refa462_op. intros x y z w. destruct x, y, z, w; reflexivity. Qed.

Lemma refa462_not4269 : ~ @Equation4269 Fin4 refa462_inst.
Proof. unfold Equation4269. intro H. specialize (H F4_0 F4_2). unfold magma_op, refa462_inst, refa462_op in H. discriminate H. Qed.

Lemma refa462_not4270 : ~ @Equation4270 Fin4 refa462_inst.
Proof. unfold Equation4270. intro H. specialize (H F4_0 F4_2). unfold magma_op, refa462_inst, refa462_op in H. discriminate H. Qed.

Lemma refa462_not4283 : ~ @Equation4283 Fin4 refa462_inst.
Proof. unfold Equation4283. intro H. specialize (H F4_0 F4_2). unfold magma_op, refa462_inst, refa462_op in H. discriminate H. Qed.

Lemma refa462_not4284 : ~ @Equation4284 Fin4 refa462_inst.
Proof. unfold Equation4284. intro H. specialize (H F4_0 F4_2). unfold magma_op, refa462_inst, refa462_op in H. discriminate H. Qed.

Lemma refa462_not4433 : ~ @Equation4433 Fin4 refa462_inst.
Proof. unfold Equation4433. intro H. specialize (H F4_0 F4_2). unfold magma_op, refa462_inst, refa462_op in H. discriminate H. Qed.

Lemma refa462_not4435 : ~ @Equation4435 Fin4 refa462_inst.
Proof. unfold Equation4435. intro H. specialize (H F4_0 F4_2). unfold magma_op, refa462_inst, refa462_op in H. discriminate H. Qed.

Lemma refa462_not4436 : ~ @Equation4436 Fin4 refa462_inst.
Proof. unfold Equation4436. intro H. specialize (H F4_0 F4_2). unfold magma_op, refa462_inst, refa462_op in H. discriminate H. Qed.

Lemma refa462_not4470 : ~ @Equation4470 Fin4 refa462_inst.
Proof. unfold Equation4470. intro H. specialize (H F4_0 F4_2). unfold magma_op, refa462_inst, refa462_op in H. discriminate H. Qed.

Lemma refa462_not4472 : ~ @Equation4472 Fin4 refa462_inst.
Proof. unfold Equation4472. intro H. specialize (H F4_0 F4_2). unfold magma_op, refa462_inst, refa462_op in H. discriminate H. Qed.

Lemma refa462_not4473 : ~ @Equation4473 Fin4 refa462_inst.
Proof. unfold Equation4473. intro H. specialize (H F4_0 F4_2). unfold magma_op, refa462_inst, refa462_op in H. discriminate H. Qed.

(** ---- refa463 (Fin4) ---- *)

Definition refa463_op (x y : Fin4) : Fin4 :=
  match x, y with
  | F4_0, F4_0 => F4_2 | F4_0, F4_1 => F4_2 | F4_0, F4_2 => F4_0 | F4_0, F4_3 => F4_1
  | F4_1, F4_0 => F4_3 | F4_1, F4_1 => F4_2 | F4_1, F4_2 => F4_0 | F4_1, F4_3 => F4_2
  | F4_2, F4_0 => F4_0 | F4_2, F4_1 => F4_1 | F4_2, F4_2 => F4_2 | F4_2, F4_3 => F4_3
  | F4_3, F4_0 => F4_2 | F4_3, F4_1 => F4_0 | F4_3, F4_2 => F4_1 | F4_3, F4_3 => F4_2
  end.

#[local] Instance refa463_inst : Magma Fin4 := {| magma_op := refa463_op |}.

Lemma refa463_sat3201 : @Equation3201 Fin4 refa463_inst.
Proof. unfold Equation3201, magma_op, refa463_inst, refa463_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa463_not2459 : ~ @Equation2459 Fin4 refa463_inst.
Proof. unfold Equation2459. intro H. specialize (H F4_0 F4_3). unfold magma_op, refa463_inst, refa463_op in H. discriminate H. Qed.

Lemma refa463_not2503 : ~ @Equation2503 Fin4 refa463_inst.
Proof. unfold Equation2503. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa463_inst, refa463_op in H. discriminate H. Qed.

(** ---- refa464 (Fin4) ---- *)

Definition refa464_op (x y : Fin4) : Fin4 :=
  match x, y with
  | F4_0, F4_0 => F4_3 | F4_0, F4_1 => F4_2 | F4_0, F4_2 => F4_0 | F4_0, F4_3 => F4_1
  | F4_1, F4_0 => F4_2 | F4_1, F4_1 => F4_3 | F4_1, F4_2 => F4_0 | F4_1, F4_3 => F4_1
  | F4_2, F4_0 => F4_2 | F4_2, F4_1 => F4_3 | F4_2, F4_2 => F4_1 | F4_2, F4_3 => F4_0
  | F4_3, F4_0 => F4_2 | F4_3, F4_1 => F4_3 | F4_3, F4_2 => F4_0 | F4_3, F4_3 => F4_1
  end.

#[local] Instance refa464_inst : Magma Fin4 := {| magma_op := refa464_op |}.

Lemma refa464_sat2115 : @Equation2115 Fin4 refa464_inst.
Proof. unfold Equation2115, magma_op, refa464_inst, refa464_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa464_not151 : ~ @Equation151 Fin4 refa464_inst.
Proof. unfold Equation151. intro H. specialize (H F4_0). unfold magma_op, refa464_inst, refa464_op in H. discriminate H. Qed.

Lemma refa464_not1315 : ~ @Equation1315 Fin4 refa464_inst.
Proof. unfold Equation1315. intro H. specialize (H F4_0 F4_2). unfold magma_op, refa464_inst, refa464_op in H. discriminate H. Qed.

Lemma refa464_not2050 : ~ @Equation2050 Fin4 refa464_inst.
Proof. unfold Equation2050. intro H. specialize (H F4_0 F4_2). unfold magma_op, refa464_inst, refa464_op in H. discriminate H. Qed.

Lemma refa464_not3862 : ~ @Equation3862 Fin4 refa464_inst.
Proof. unfold Equation3862. intro H. specialize (H F4_0). unfold magma_op, refa464_inst, refa464_op in H. discriminate H. Qed.

Lemma refa464_not4320 : ~ @Equation4320 Fin4 refa464_inst.
Proof. unfold Equation4320. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa464_inst, refa464_op in H. discriminate H. Qed.

Lemma refa464_not4606 : ~ @Equation4606 Fin4 refa464_inst.
Proof. unfold Equation4606. intro H. specialize (H F4_0 F4_2). unfold magma_op, refa464_inst, refa464_op in H. discriminate H. Qed.

(** ---- refa465 (Fin4) ---- *)

Definition refa465_op (x y : Fin4) : Fin4 :=
  match x, y with
  | F4_0, F4_0 => F4_3 | F4_0, F4_1 => F4_2 | F4_0, F4_2 => F4_3 | F4_0, F4_3 => F4_1
  | F4_1, F4_0 => F4_3 | F4_1, F4_1 => F4_1 | F4_1, F4_2 => F4_2 | F4_1, F4_3 => F4_1
  | F4_2, F4_0 => F4_1 | F4_2, F4_1 => F4_2 | F4_2, F4_2 => F4_2 | F4_2, F4_3 => F4_3
  | F4_3, F4_0 => F4_2 | F4_3, F4_1 => F4_1 | F4_3, F4_2 => F4_3 | F4_3, F4_3 => F4_3
  end.

#[local] Instance refa465_inst : Magma Fin4 := {| magma_op := refa465_op |}.

Lemma refa465_sat3555 : @Equation3555 Fin4 refa465_inst.
Proof. unfold Equation3555, magma_op, refa465_inst, refa465_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa465_not43 : ~ @Equation43 Fin4 refa465_inst.
Proof. unfold Equation43. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa465_inst, refa465_op in H. discriminate H. Qed.

Lemma refa465_not359 : ~ @Equation359 Fin4 refa465_inst.
Proof. unfold Equation359. intro H. specialize (H F4_0). unfold magma_op, refa465_inst, refa465_op in H. discriminate H. Qed.

Lemma refa465_not3253 : ~ @Equation3253 Fin4 refa465_inst.
Proof. unfold Equation3253. intro H. specialize (H F4_0). unfold magma_op, refa465_inst, refa465_op in H. discriminate H. Qed.

Lemma refa465_not3511 : ~ @Equation3511 Fin4 refa465_inst.
Proof. unfold Equation3511. intro H. specialize (H F4_1 F4_0). unfold magma_op, refa465_inst, refa465_op in H. discriminate H. Qed.

Lemma refa465_not3512 : ~ @Equation3512 Fin4 refa465_inst.
Proof. unfold Equation3512. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa465_inst, refa465_op in H. discriminate H. Qed.

Lemma refa465_not3519 : ~ @Equation3519 Fin4 refa465_inst.
Proof. unfold Equation3519. intro H. specialize (H F4_1 F4_0). unfold magma_op, refa465_inst, refa465_op in H. discriminate H. Qed.

Lemma refa465_not3521 : ~ @Equation3521 Fin4 refa465_inst.
Proof. unfold Equation3521. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa465_inst, refa465_op in H. discriminate H. Qed.

Lemma refa465_not3545 : ~ @Equation3545 Fin4 refa465_inst.
Proof. unfold Equation3545. intro H. specialize (H F4_0 F4_2). unfold magma_op, refa465_inst, refa465_op in H. discriminate H. Qed.

Lemma refa465_not3546 : ~ @Equation3546 Fin4 refa465_inst.
Proof. unfold Equation3546. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa465_inst, refa465_op in H. discriminate H. Qed.

Lemma refa465_not3548 : ~ @Equation3548 Fin4 refa465_inst.
Proof. unfold Equation3548. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa465_inst, refa465_op in H. discriminate H. Qed.

(** ---- refa466 (Fin4) ---- *)

Definition refa466_op (x y : Fin4) : Fin4 :=
  match x, y with
  | F4_0, F4_0 => F4_2 | F4_0, F4_1 => F4_0 | F4_0, F4_2 => F4_3 | F4_0, F4_3 => F4_1
  | F4_1, F4_0 => F4_2 | F4_1, F4_1 => F4_1 | F4_1, F4_2 => F4_1 | F4_1, F4_3 => F4_2
  | F4_2, F4_0 => F4_2 | F4_2, F4_1 => F4_2 | F4_2, F4_2 => F4_1 | F4_2, F4_3 => F4_2
  | F4_3, F4_0 => F4_2 | F4_3, F4_1 => F4_3 | F4_3, F4_2 => F4_3 | F4_3, F4_3 => F4_1
  end.

#[local] Instance refa466_inst : Magma Fin4 := {| magma_op := refa466_op |}.

Lemma refa466_sat443 : @Equation443 Fin4 refa466_inst.
Proof. unfold Equation443, magma_op, refa466_inst, refa466_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa466_not99 : ~ @Equation99 Fin4 refa466_inst.
Proof. unfold Equation99. intro H. specialize (H F4_0). unfold magma_op, refa466_inst, refa466_op in H. discriminate H. Qed.

Lemma refa466_not426 : ~ @Equation426 Fin4 refa466_inst.
Proof. unfold Equation426. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa466_inst, refa466_op in H. discriminate H. Qed.

Lemma refa466_not429 : ~ @Equation429 Fin4 refa466_inst.
Proof. unfold Equation429. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa466_inst, refa466_op in H. discriminate H. Qed.

Lemma refa466_not436 : ~ @Equation436 Fin4 refa466_inst.
Proof. unfold Equation436. intro H. specialize (H F4_0 F4_2). unfold magma_op, refa466_inst, refa466_op in H. discriminate H. Qed.

Lemma refa466_not819 : ~ @Equation819 Fin4 refa466_inst.
Proof. unfold Equation819. intro H. specialize (H F4_2 F4_0). unfold magma_op, refa466_inst, refa466_op in H. discriminate H. Qed.

Lemma refa466_not832 : ~ @Equation832 Fin4 refa466_inst.
Proof. unfold Equation832. intro H. specialize (H F4_1 F4_0). unfold magma_op, refa466_inst, refa466_op in H. discriminate H. Qed.

Lemma refa466_not833 : ~ @Equation833 Fin4 refa466_inst.
Proof. unfold Equation833. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa466_inst, refa466_op in H. discriminate H. Qed.

Lemma refa466_not836 : ~ @Equation836 Fin4 refa466_inst.
Proof. unfold Equation836. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa466_inst, refa466_op in H. discriminate H. Qed.

Lemma refa466_not842 : ~ @Equation842 Fin4 refa466_inst.
Proof. unfold Equation842. intro H. specialize (H F4_2 F4_0). unfold magma_op, refa466_inst, refa466_op in H. discriminate H. Qed.

Lemma refa466_not843 : ~ @Equation843 Fin4 refa466_inst.
Proof. unfold Equation843. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa466_inst, refa466_op in H. discriminate H. Qed.

Lemma refa466_not845 : ~ @Equation845 Fin4 refa466_inst.
Proof. unfold Equation845. intro H. specialize (H F4_2 F4_0). unfold magma_op, refa466_inst, refa466_op in H. discriminate H. Qed.

Lemma refa466_not1020 : ~ @Equation1020 Fin4 refa466_inst.
Proof. unfold Equation1020. intro H. specialize (H F4_0). unfold magma_op, refa466_inst, refa466_op in H. discriminate H. Qed.

Lemma refa466_not1223 : ~ @Equation1223 Fin4 refa466_inst.
Proof. unfold Equation1223. intro H. specialize (H F4_0). unfold magma_op, refa466_inst, refa466_op in H. discriminate H. Qed.

Lemma refa466_not1832 : ~ @Equation1832 Fin4 refa466_inst.
Proof. unfold Equation1832. intro H. specialize (H F4_0). unfold magma_op, refa466_inst, refa466_op in H. discriminate H. Qed.

Lemma refa466_not3253 : ~ @Equation3253 Fin4 refa466_inst.
Proof. unfold Equation3253. intro H. specialize (H F4_0). unfold magma_op, refa466_inst, refa466_op in H. discriminate H. Qed.

Lemma refa466_not3659 : ~ @Equation3659 Fin4 refa466_inst.
Proof. unfold Equation3659. intro H. specialize (H F4_0). unfold magma_op, refa466_inst, refa466_op in H. discriminate H. Qed.

Lemma refa466_not3864 : ~ @Equation3864 Fin4 refa466_inst.
Proof. unfold Equation3864. intro H. specialize (H F4_3 F4_1). unfold magma_op, refa466_inst, refa466_op in H. discriminate H. Qed.

Lemma refa466_not3865 : ~ @Equation3865 Fin4 refa466_inst.
Proof. unfold Equation3865. intro H. specialize (H F4_0 F4_2). unfold magma_op, refa466_inst, refa466_op in H. discriminate H. Qed.

Lemma refa466_not3867 : ~ @Equation3867 Fin4 refa466_inst.
Proof. unfold Equation3867. intro H. specialize (H F4_1 F4_0). unfold magma_op, refa466_inst, refa466_op in H. discriminate H. Qed.

Lemma refa466_not3878 : ~ @Equation3878 Fin4 refa466_inst.
Proof. unfold Equation3878. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa466_inst, refa466_op in H. discriminate H. Qed.

Lemma refa466_not3881 : ~ @Equation3881 Fin4 refa466_inst.
Proof. unfold Equation3881. intro H. specialize (H F4_0 F4_2). unfold magma_op, refa466_inst, refa466_op in H. discriminate H. Qed.

Lemma refa466_not3887 : ~ @Equation3887 Fin4 refa466_inst.
Proof. unfold Equation3887. intro H. specialize (H F4_1 F4_0). unfold magma_op, refa466_inst, refa466_op in H. discriminate H. Qed.

Lemma refa466_not3888 : ~ @Equation3888 Fin4 refa466_inst.
Proof. unfold Equation3888. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa466_inst, refa466_op in H. discriminate H. Qed.

Lemma refa466_not3915 : ~ @Equation3915 Fin4 refa466_inst.
Proof. unfold Equation3915. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa466_inst, refa466_op in H. discriminate H. Qed.

Lemma refa466_not3925 : ~ @Equation3925 Fin4 refa466_inst.
Proof. unfold Equation3925. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa466_inst, refa466_op in H. discriminate H. Qed.

Lemma refa466_not4065 : ~ @Equation4065 Fin4 refa466_inst.
Proof. unfold Equation4065. intro H. specialize (H F4_3). unfold magma_op, refa466_inst, refa466_op in H. discriminate H. Qed.

Lemma refa466_not4269 : ~ @Equation4269 Fin4 refa466_inst.
Proof. unfold Equation4269. intro H. specialize (H F4_1 F4_0). unfold magma_op, refa466_inst, refa466_op in H. discriminate H. Qed.

Lemma refa466_not4270 : ~ @Equation4270 Fin4 refa466_inst.
Proof. unfold Equation4270. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa466_inst, refa466_op in H. discriminate H. Qed.

Lemma refa466_not4293 : ~ @Equation4293 Fin4 refa466_inst.
Proof. unfold Equation4293. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa466_inst, refa466_op in H. discriminate H. Qed.

Lemma refa466_not4314 : ~ @Equation4314 Fin4 refa466_inst.
Proof. unfold Equation4314. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa466_inst, refa466_op in H. discriminate H. Qed.

Lemma refa466_not4583 : ~ @Equation4583 Fin4 refa466_inst.
Proof. unfold Equation4583. intro H. specialize (H F4_0 F4_2). unfold magma_op, refa466_inst, refa466_op in H. discriminate H. Qed.

Lemma refa466_not4591 : ~ @Equation4591 Fin4 refa466_inst.
Proof. unfold Equation4591. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa466_inst, refa466_op in H. discriminate H. Qed.

Lemma refa466_not4598 : ~ @Equation4598 Fin4 refa466_inst.
Proof. unfold Equation4598. intro H. specialize (H F4_0 F4_2). unfold magma_op, refa466_inst, refa466_op in H. discriminate H. Qed.

Lemma refa466_not4606 : ~ @Equation4606 Fin4 refa466_inst.
Proof. unfold Equation4606. intro H. specialize (H F4_1 F4_3). unfold magma_op, refa466_inst, refa466_op in H. discriminate H. Qed.

Lemma refa466_not4608 : ~ @Equation4608 Fin4 refa466_inst.
Proof. unfold Equation4608. intro H. specialize (H F4_0 F4_2). unfold magma_op, refa466_inst, refa466_op in H. discriminate H. Qed.

Lemma refa466_not4622 : ~ @Equation4622 Fin4 refa466_inst.
Proof. unfold Equation4622. intro H. specialize (H F4_0 F4_1 F4_1). unfold magma_op, refa466_inst, refa466_op in H. discriminate H. Qed.

Lemma refa466_not4631 : ~ @Equation4631 Fin4 refa466_inst.
Proof. unfold Equation4631. intro H. specialize (H F4_1 F4_0 F4_1). unfold magma_op, refa466_inst, refa466_op in H. discriminate H. Qed.

Lemma refa466_not4636 : ~ @Equation4636 Fin4 refa466_inst.
Proof. unfold Equation4636. intro H. specialize (H F4_0 F4_2). unfold magma_op, refa466_inst, refa466_op in H. discriminate H. Qed.

Lemma refa466_not4647 : ~ @Equation4647 Fin4 refa466_inst.
Proof. unfold Equation4647. intro H. specialize (H F4_0 F4_0 F4_2). unfold magma_op, refa466_inst, refa466_op in H. discriminate H. Qed.

(** ---- refa467 (Fin4) ---- *)

Definition refa467_op (x y : Fin4) : Fin4 :=
  match x, y with
  | F4_0, F4_0 => F4_1 | F4_0, F4_1 => F4_1 | F4_0, F4_2 => F4_2 | F4_0, F4_3 => F4_1
  | F4_1, F4_0 => F4_3 | F4_1, F4_1 => F4_3 | F4_1, F4_2 => F4_3 | F4_1, F4_3 => F4_3
  | F4_2, F4_0 => F4_3 | F4_2, F4_1 => F4_2 | F4_2, F4_2 => F4_3 | F4_2, F4_3 => F4_3
  | F4_3, F4_0 => F4_0 | F4_3, F4_1 => F4_0 | F4_3, F4_2 => F4_0 | F4_3, F4_3 => F4_0
  end.

#[local] Instance refa467_inst : Magma Fin4 := {| magma_op := refa467_op |}.

Lemma refa467_sat2868 : @Equation2868 Fin4 refa467_inst.
Proof. unfold Equation2868, magma_op, refa467_inst, refa467_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa467_not3306 : ~ @Equation3306 Fin4 refa467_inst.
Proof. unfold Equation3306. intro H. specialize (H F4_2 F4_1). unfold magma_op, refa467_inst, refa467_op in H. discriminate H. Qed.

(** ---- refa468 (Fin4) ---- *)

Definition refa468_op (x y : Fin4) : Fin4 :=
  match x, y with
  | F4_0, F4_0 => F4_3 | F4_0, F4_1 => F4_0 | F4_0, F4_2 => F4_3 | F4_0, F4_3 => F4_1
  | F4_1, F4_0 => F4_1 | F4_1, F4_1 => F4_3 | F4_1, F4_2 => F4_1 | F4_1, F4_3 => F4_2
  | F4_2, F4_0 => F4_2 | F4_2, F4_1 => F4_2 | F4_2, F4_2 => F4_0 | F4_2, F4_3 => F4_1
  | F4_3, F4_0 => F4_3 | F4_3, F4_1 => F4_3 | F4_3, F4_2 => F4_0 | F4_3, F4_3 => F4_3
  end.

#[local] Instance refa468_inst : Magma Fin4 := {| magma_op := refa468_op |}.

Lemma refa468_sat623 : @Equation623 Fin4 refa468_inst.
Proof. unfold Equation623, magma_op, refa468_inst, refa468_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa468_not47 : ~ @Equation47 Fin4 refa468_inst.
Proof. unfold Equation47. intro H. specialize (H F4_2). unfold magma_op, refa468_inst, refa468_op in H. discriminate H. Qed.

Lemma refa468_not359 : ~ @Equation359 Fin4 refa468_inst.
Proof. unfold Equation359. intro H. specialize (H F4_2). unfold magma_op, refa468_inst, refa468_op in H. discriminate H. Qed.

Lemma refa468_not620 : ~ @Equation620 Fin4 refa468_inst.
Proof. unfold Equation620. intro H. specialize (H F4_0 F4_2). unfold magma_op, refa468_inst, refa468_op in H. discriminate H. Qed.

Lemma refa468_not622 : ~ @Equation622 Fin4 refa468_inst.
Proof. unfold Equation622. intro H. specialize (H F4_1 F4_2). unfold magma_op, refa468_inst, refa468_op in H. discriminate H. Qed.

Lemma refa468_not3659 : ~ @Equation3659 Fin4 refa468_inst.
Proof. unfold Equation3659. intro H. specialize (H F4_2). unfold magma_op, refa468_inst, refa468_op in H. discriminate H. Qed.

Lemma refa468_not4270 : ~ @Equation4270 Fin4 refa468_inst.
Proof. unfold Equation4270. intro H. specialize (H F4_0 F4_2). unfold magma_op, refa468_inst, refa468_op in H. discriminate H. Qed.

(** ---- refa469 (Fin4) ---- *)

Definition refa469_op (x y : Fin4) : Fin4 :=
  match x, y with
  | F4_0, F4_0 => F4_0 | F4_0, F4_1 => F4_0 | F4_0, F4_2 => F4_2 | F4_0, F4_3 => F4_3
  | F4_1, F4_0 => F4_2 | F4_1, F4_1 => F4_1 | F4_1, F4_2 => F4_0 | F4_1, F4_3 => F4_2
  | F4_2, F4_0 => F4_2 | F4_2, F4_1 => F4_1 | F4_2, F4_2 => F4_0 | F4_2, F4_3 => F4_2
  | F4_3, F4_0 => F4_0 | F4_3, F4_1 => F4_0 | F4_3, F4_2 => F4_2 | F4_3, F4_3 => F4_1
  end.

#[local] Instance refa469_inst : Magma Fin4 := {| magma_op := refa469_op |}.

Lemma refa469_sat2300 : @Equation2300 Fin4 refa469_inst.
Proof. unfold Equation2300, magma_op, refa469_inst, refa469_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa469_not1629 : ~ @Equation1629 Fin4 refa469_inst.
Proof. unfold Equation1629. intro H. specialize (H F4_3). unfold magma_op, refa469_inst, refa469_op in H. discriminate H. Qed.

Lemma refa469_not2246 : ~ @Equation2246 Fin4 refa469_inst.
Proof. unfold Equation2246. intro H. specialize (H F4_1 F4_0). unfold magma_op, refa469_inst, refa469_op in H. discriminate H. Qed.

Lemma refa469_not2293 : ~ @Equation2293 Fin4 refa469_inst.
Proof. unfold Equation2293. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa469_inst, refa469_op in H. discriminate H. Qed.

Lemma refa469_not2441 : ~ @Equation2441 Fin4 refa469_inst.
Proof. unfold Equation2441. intro H. specialize (H F4_3). unfold magma_op, refa469_inst, refa469_op in H. discriminate H. Qed.

Lemma refa469_not3050 : ~ @Equation3050 Fin4 refa469_inst.
Proof. unfold Equation3050. intro H. specialize (H F4_3). unfold magma_op, refa469_inst, refa469_op in H. discriminate H. Qed.

(** ---- refa47 (Fin2) ---- *)

Definition refa47_op (x y : Fin2) : Fin2 :=
  match x, y with
  | F2_0, F2_0 => F2_0 | F2_0, F2_1 => F2_0
  | F2_1, F2_0 => F2_0 | F2_1, F2_1 => F2_1
  end.

#[local] Instance refa47_inst : Magma Fin2 := {| magma_op := refa47_op |}.

Lemma refa47_sat3 : @Equation3 Fin2 refa47_inst.
Proof. unfold Equation3, magma_op, refa47_inst, refa47_op. intros x. destruct x; reflexivity. Qed.

Lemma refa47_sat323 : @Equation323 Fin2 refa47_inst.
Proof. unfold Equation323, magma_op, refa47_inst, refa47_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa47_sat325 : @Equation325 Fin2 refa47_inst.
Proof. unfold Equation325, magma_op, refa47_inst, refa47_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa47_sat333 : @Equation333 Fin2 refa47_inst.
Proof. unfold Equation333, magma_op, refa47_inst, refa47_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa47_sat335 : @Equation335 Fin2 refa47_inst.
Proof. unfold Equation335, magma_op, refa47_inst, refa47_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa47_sat377 : @Equation377 Fin2 refa47_inst.
Proof. unfold Equation377, magma_op, refa47_inst, refa47_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa47_sat378 : @Equation378 Fin2 refa47_inst.
Proof. unfold Equation378, magma_op, refa47_inst, refa47_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa47_sat384 : @Equation384 Fin2 refa47_inst.
Proof. unfold Equation384, magma_op, refa47_inst, refa47_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa47_sat385 : @Equation385 Fin2 refa47_inst.
Proof. unfold Equation385, magma_op, refa47_inst, refa47_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa47_sat3308 : @Equation3308 Fin2 refa47_inst.
Proof. unfold Equation3308, magma_op, refa47_inst, refa47_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa47_sat3309 : @Equation3309 Fin2 refa47_inst.
Proof. unfold Equation3309, magma_op, refa47_inst, refa47_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa47_sat3315 : @Equation3315 Fin2 refa47_inst.
Proof. unfold Equation3315, magma_op, refa47_inst, refa47_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa47_sat3318 : @Equation3318 Fin2 refa47_inst.
Proof. unfold Equation3318, magma_op, refa47_inst, refa47_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa47_sat3345 : @Equation3345 Fin2 refa47_inst.
Proof. unfold Equation3345, magma_op, refa47_inst, refa47_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa47_sat3346 : @Equation3346 Fin2 refa47_inst.
Proof. unfold Equation3346, magma_op, refa47_inst, refa47_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa47_sat3352 : @Equation3352 Fin2 refa47_inst.
Proof. unfold Equation3352, magma_op, refa47_inst, refa47_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa47_sat3355 : @Equation3355 Fin2 refa47_inst.
Proof. unfold Equation3355, magma_op, refa47_inst, refa47_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa47_sat3509 : @Equation3509 Fin2 refa47_inst.
Proof. unfold Equation3509, magma_op, refa47_inst, refa47_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa47_sat3512 : @Equation3512 Fin2 refa47_inst.
Proof. unfold Equation3512, magma_op, refa47_inst, refa47_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa47_sat3519 : @Equation3519 Fin2 refa47_inst.
Proof. unfold Equation3519, magma_op, refa47_inst, refa47_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa47_sat3521 : @Equation3521 Fin2 refa47_inst.
Proof. unfold Equation3521, magma_op, refa47_inst, refa47_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa47_sat3546 : @Equation3546 Fin2 refa47_inst.
Proof. unfold Equation3546, magma_op, refa47_inst, refa47_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa47_sat3548 : @Equation3548 Fin2 refa47_inst.
Proof. unfold Equation3548, magma_op, refa47_inst, refa47_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa47_sat3549 : @Equation3549 Fin2 refa47_inst.
Proof. unfold Equation3549, magma_op, refa47_inst, refa47_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa47_sat3555 : @Equation3555 Fin2 refa47_inst.
Proof. unfold Equation3555, magma_op, refa47_inst, refa47_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa47_sat3556 : @Equation3556 Fin2 refa47_inst.
Proof. unfold Equation3556, magma_op, refa47_inst, refa47_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa47_sat3558 : @Equation3558 Fin2 refa47_inst.
Proof. unfold Equation3558, magma_op, refa47_inst, refa47_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa47_sat3748 : @Equation3748 Fin2 refa47_inst.
Proof. unfold Equation3748, magma_op, refa47_inst, refa47_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa47_sat3751 : @Equation3751 Fin2 refa47_inst.
Proof. unfold Equation3751, magma_op, refa47_inst, refa47_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa47_sat3752 : @Equation3752 Fin2 refa47_inst.
Proof. unfold Equation3752, magma_op, refa47_inst, refa47_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa47_sat3758 : @Equation3758 Fin2 refa47_inst.
Proof. unfold Equation3758, magma_op, refa47_inst, refa47_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa47_sat3759 : @Equation3759 Fin2 refa47_inst.
Proof. unfold Equation3759, magma_op, refa47_inst, refa47_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa47_sat3761 : @Equation3761 Fin2 refa47_inst.
Proof. unfold Equation3761, magma_op, refa47_inst, refa47_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa47_sat3917 : @Equation3917 Fin2 refa47_inst.
Proof. unfold Equation3917, magma_op, refa47_inst, refa47_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa47_sat3918 : @Equation3918 Fin2 refa47_inst.
Proof. unfold Equation3918, magma_op, refa47_inst, refa47_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa47_sat3924 : @Equation3924 Fin2 refa47_inst.
Proof. unfold Equation3924, magma_op, refa47_inst, refa47_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa47_sat3925 : @Equation3925 Fin2 refa47_inst.
Proof. unfold Equation3925, magma_op, refa47_inst, refa47_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa47_sat3927 : @Equation3927 Fin2 refa47_inst.
Proof. unfold Equation3927, magma_op, refa47_inst, refa47_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa47_sat3928 : @Equation3928 Fin2 refa47_inst.
Proof. unfold Equation3928, magma_op, refa47_inst, refa47_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa47_sat3951 : @Equation3951 Fin2 refa47_inst.
Proof. unfold Equation3951, magma_op, refa47_inst, refa47_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa47_sat3952 : @Equation3952 Fin2 refa47_inst.
Proof. unfold Equation3952, magma_op, refa47_inst, refa47_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa47_sat3954 : @Equation3954 Fin2 refa47_inst.
Proof. unfold Equation3954, magma_op, refa47_inst, refa47_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa47_sat3955 : @Equation3955 Fin2 refa47_inst.
Proof. unfold Equation3955, magma_op, refa47_inst, refa47_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa47_sat3961 : @Equation3961 Fin2 refa47_inst.
Proof. unfold Equation3961, magma_op, refa47_inst, refa47_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa47_sat4120 : @Equation4120 Fin2 refa47_inst.
Proof. unfold Equation4120, magma_op, refa47_inst, refa47_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa47_sat4121 : @Equation4121 Fin2 refa47_inst.
Proof. unfold Equation4121, magma_op, refa47_inst, refa47_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa47_sat4154 : @Equation4154 Fin2 refa47_inst.
Proof. unfold Equation4154, magma_op, refa47_inst, refa47_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa47_sat4157 : @Equation4157 Fin2 refa47_inst.
Proof. unfold Equation4157, magma_op, refa47_inst, refa47_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa47_sat4158 : @Equation4158 Fin2 refa47_inst.
Proof. unfold Equation4158, magma_op, refa47_inst, refa47_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa47_sat4164 : @Equation4164 Fin2 refa47_inst.
Proof. unfold Equation4164, magma_op, refa47_inst, refa47_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa47_sat4165 : @Equation4165 Fin2 refa47_inst.
Proof. unfold Equation4165, magma_op, refa47_inst, refa47_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa47_sat4284 : @Equation4284 Fin2 refa47_inst.
Proof. unfold Equation4284, magma_op, refa47_inst, refa47_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa47_sat4291 : @Equation4291 Fin2 refa47_inst.
Proof. unfold Equation4291, magma_op, refa47_inst, refa47_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa47_sat4293 : @Equation4293 Fin2 refa47_inst.
Proof. unfold Equation4293, magma_op, refa47_inst, refa47_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa47_sat4321 : @Equation4321 Fin2 refa47_inst.
Proof. unfold Equation4321, magma_op, refa47_inst, refa47_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa47_sat4362 : @Equation4362 Fin2 refa47_inst.
Proof. unfold Equation4362, magma_op, refa47_inst, refa47_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa47_sat4364 : @Equation4364 Fin2 refa47_inst.
Proof. unfold Equation4364, magma_op, refa47_inst, refa47_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa47_sat4369 : @Equation4369 Fin2 refa47_inst.
Proof. unfold Equation4369, magma_op, refa47_inst, refa47_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa47_sat4399 : @Equation4399 Fin2 refa47_inst.
Proof. unfold Equation4399, magma_op, refa47_inst, refa47_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa47_sat4406 : @Equation4406 Fin2 refa47_inst.
Proof. unfold Equation4406, magma_op, refa47_inst, refa47_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa47_sat4408 : @Equation4408 Fin2 refa47_inst.
Proof. unfold Equation4408, magma_op, refa47_inst, refa47_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa47_sat4436 : @Equation4436 Fin2 refa47_inst.
Proof. unfold Equation4436, magma_op, refa47_inst, refa47_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa47_sat4443 : @Equation4443 Fin2 refa47_inst.
Proof. unfold Equation4443, magma_op, refa47_inst, refa47_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa47_sat4445 : @Equation4445 Fin2 refa47_inst.
Proof. unfold Equation4445, magma_op, refa47_inst, refa47_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa47_sat4472 : @Equation4472 Fin2 refa47_inst.
Proof. unfold Equation4472, magma_op, refa47_inst, refa47_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa47_sat4479 : @Equation4479 Fin2 refa47_inst.
Proof. unfold Equation4479, magma_op, refa47_inst, refa47_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa47_sat4512 : @Equation4512 Fin2 refa47_inst.
Proof. unfold Equation4512, magma_op, refa47_inst, refa47_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa47_sat4515 : @Equation4515 Fin2 refa47_inst.
Proof. unfold Equation4515, magma_op, refa47_inst, refa47_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa47_sat4525 : @Equation4525 Fin2 refa47_inst.
Proof. unfold Equation4525, magma_op, refa47_inst, refa47_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa47_sat4541 : @Equation4541 Fin2 refa47_inst.
Proof. unfold Equation4541, magma_op, refa47_inst, refa47_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa47_sat4599 : @Equation4599 Fin2 refa47_inst.
Proof. unfold Equation4599, magma_op, refa47_inst, refa47_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa47_sat4606 : @Equation4606 Fin2 refa47_inst.
Proof. unfold Equation4606, magma_op, refa47_inst, refa47_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa47_sat4629 : @Equation4629 Fin2 refa47_inst.
Proof. unfold Equation4629, magma_op, refa47_inst, refa47_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa47_sat4636 : @Equation4636 Fin2 refa47_inst.
Proof. unfold Equation4636, magma_op, refa47_inst, refa47_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa47_sat4658 : @Equation4658 Fin2 refa47_inst.
Proof. unfold Equation4658, magma_op, refa47_inst, refa47_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa47_sat4679 : @Equation4679 Fin2 refa47_inst.
Proof. unfold Equation4679, magma_op, refa47_inst, refa47_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa47_sat4684 : @Equation4684 Fin2 refa47_inst.
Proof. unfold Equation4684, magma_op, refa47_inst, refa47_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa47_not50 : ~ @Equation50 Fin2 refa47_inst.
Proof. unfold Equation50. intro H. specialize (H F2_1 F2_0). unfold magma_op, refa47_inst, refa47_op in H. discriminate H. Qed.

Lemma refa47_not55 : ~ @Equation55 Fin2 refa47_inst.
Proof. unfold Equation55. intro H. specialize (H F2_1 F2_0). unfold magma_op, refa47_inst, refa47_op in H. discriminate H. Qed.

Lemma refa47_not56 : ~ @Equation56 Fin2 refa47_inst.
Proof. unfold Equation56. intro H. specialize (H F2_1 F2_0). unfold magma_op, refa47_inst, refa47_op in H. discriminate H. Qed.

Lemma refa47_not105 : ~ @Equation105 Fin2 refa47_inst.
Proof. unfold Equation105. intro H. specialize (H F2_1 F2_0). unfold magma_op, refa47_inst, refa47_op in H. discriminate H. Qed.

Lemma refa47_not107 : ~ @Equation107 Fin2 refa47_inst.
Proof. unfold Equation107. intro H. specialize (H F2_1 F2_0). unfold magma_op, refa47_inst, refa47_op in H. discriminate H. Qed.

Lemma refa47_not108 : ~ @Equation108 Fin2 refa47_inst.
Proof. unfold Equation108. intro H. specialize (H F2_1 F2_0). unfold magma_op, refa47_inst, refa47_op in H. discriminate H. Qed.

Lemma refa47_not159 : ~ @Equation159 Fin2 refa47_inst.
Proof. unfold Equation159. intro H. specialize (H F2_1 F2_0). unfold magma_op, refa47_inst, refa47_op in H. discriminate H. Qed.

Lemma refa47_not160 : ~ @Equation160 Fin2 refa47_inst.
Proof. unfold Equation160. intro H. specialize (H F2_1 F2_0). unfold magma_op, refa47_inst, refa47_op in H. discriminate H. Qed.

Lemma refa47_not206 : ~ @Equation206 Fin2 refa47_inst.
Proof. unfold Equation206. intro H. specialize (H F2_1 F2_0). unfold magma_op, refa47_inst, refa47_op in H. discriminate H. Qed.

Lemma refa47_not209 : ~ @Equation209 Fin2 refa47_inst.
Proof. unfold Equation209. intro H. specialize (H F2_1 F2_0). unfold magma_op, refa47_inst, refa47_op in H. discriminate H. Qed.

Lemma refa47_not211 : ~ @Equation211 Fin2 refa47_inst.
Proof. unfold Equation211. intro H. specialize (H F2_1 F2_0). unfold magma_op, refa47_inst, refa47_op in H. discriminate H. Qed.

Lemma refa47_not261 : ~ @Equation261 Fin2 refa47_inst.
Proof. unfold Equation261. intro H. specialize (H F2_1 F2_0). unfold magma_op, refa47_inst, refa47_op in H. discriminate H. Qed.

Lemma refa47_not263 : ~ @Equation263 Fin2 refa47_inst.
Proof. unfold Equation263. intro H. specialize (H F2_1 F2_0). unfold magma_op, refa47_inst, refa47_op in H. discriminate H. Qed.

Lemma refa47_not264 : ~ @Equation264 Fin2 refa47_inst.
Proof. unfold Equation264. intro H. specialize (H F2_1 F2_0). unfold magma_op, refa47_inst, refa47_op in H. discriminate H. Qed.

Lemma refa47_not412 : ~ @Equation412 Fin2 refa47_inst.
Proof. unfold Equation412. intro H. specialize (H F2_1 F2_0). unfold magma_op, refa47_inst, refa47_op in H. discriminate H. Qed.

Lemma refa47_not413 : ~ @Equation413 Fin2 refa47_inst.
Proof. unfold Equation413. intro H. specialize (H F2_1 F2_0). unfold magma_op, refa47_inst, refa47_op in H. discriminate H. Qed.

Lemma refa47_not414 : ~ @Equation414 Fin2 refa47_inst.
Proof. unfold Equation414. intro H. specialize (H F2_1 F2_0). unfold magma_op, refa47_inst, refa47_op in H. discriminate H. Qed.

Lemma refa47_not416 : ~ @Equation416 Fin2 refa47_inst.
Proof. unfold Equation416. intro H. specialize (H F2_1 F2_0). unfold magma_op, refa47_inst, refa47_op in H. discriminate H. Qed.

Lemma refa47_not417 : ~ @Equation417 Fin2 refa47_inst.
Proof. unfold Equation417. intro H. specialize (H F2_1 F2_0). unfold magma_op, refa47_inst, refa47_op in H. discriminate H. Qed.

Lemma refa47_not419 : ~ @Equation419 Fin2 refa47_inst.
Proof. unfold Equation419. intro H. specialize (H F2_1 F2_0). unfold magma_op, refa47_inst, refa47_op in H. discriminate H. Qed.

Lemma refa47_not420 : ~ @Equation420 Fin2 refa47_inst.
Proof. unfold Equation420. intro H. specialize (H F2_1 F2_0). unfold magma_op, refa47_inst, refa47_op in H. discriminate H. Qed.

Lemma refa47_not426 : ~ @Equation426 Fin2 refa47_inst.
Proof. unfold Equation426. intro H. specialize (H F2_1 F2_0). unfold magma_op, refa47_inst, refa47_op in H. discriminate H. Qed.

Lemma refa47_not427 : ~ @Equation427 Fin2 refa47_inst.
Proof. unfold Equation427. intro H. specialize (H F2_1 F2_0). unfold magma_op, refa47_inst, refa47_op in H. discriminate H. Qed.

Lemma refa47_not429 : ~ @Equation429 Fin2 refa47_inst.
Proof. unfold Equation429. intro H. specialize (H F2_1 F2_0). unfold magma_op, refa47_inst, refa47_op in H. discriminate H. Qed.

Lemma refa47_not430 : ~ @Equation430 Fin2 refa47_inst.
Proof. unfold Equation430. intro H. specialize (H F2_1 F2_0). unfold magma_op, refa47_inst, refa47_op in H. discriminate H. Qed.

Lemma refa47_not436 : ~ @Equation436 Fin2 refa47_inst.
Proof. unfold Equation436. intro H. specialize (H F2_1 F2_0). unfold magma_op, refa47_inst, refa47_op in H. discriminate H. Qed.

Lemma refa47_not437 : ~ @Equation437 Fin2 refa47_inst.
Proof. unfold Equation437. intro H. specialize (H F2_1 F2_0). unfold magma_op, refa47_inst, refa47_op in H. discriminate H. Qed.

Lemma refa47_not439 : ~ @Equation439 Fin2 refa47_inst.
Proof. unfold Equation439. intro H. specialize (H F2_1 F2_0). unfold magma_op, refa47_inst, refa47_op in H. discriminate H. Qed.

Lemma refa47_not440 : ~ @Equation440 Fin2 refa47_inst.
Proof. unfold Equation440. intro H. specialize (H F2_1 F2_0). unfold magma_op, refa47_inst, refa47_op in H. discriminate H. Qed.

Lemma refa47_not615 : ~ @Equation615 Fin2 refa47_inst.
Proof. unfold Equation615. intro H. specialize (H F2_1 F2_0). unfold magma_op, refa47_inst, refa47_op in H. discriminate H. Qed.

Lemma refa47_not616 : ~ @Equation616 Fin2 refa47_inst.
Proof. unfold Equation616. intro H. specialize (H F2_1 F2_0). unfold magma_op, refa47_inst, refa47_op in H. discriminate H. Qed.

Lemma refa47_not617 : ~ @Equation617 Fin2 refa47_inst.
Proof. unfold Equation617. intro H. specialize (H F2_1 F2_0). unfold magma_op, refa47_inst, refa47_op in H. discriminate H. Qed.

Lemma refa47_not619 : ~ @Equation619 Fin2 refa47_inst.
Proof. unfold Equation619. intro H. specialize (H F2_1 F2_0). unfold magma_op, refa47_inst, refa47_op in H. discriminate H. Qed.

Lemma refa47_not620 : ~ @Equation620 Fin2 refa47_inst.
Proof. unfold Equation620. intro H. specialize (H F2_1 F2_0). unfold magma_op, refa47_inst, refa47_op in H. discriminate H. Qed.

Lemma refa47_not622 : ~ @Equation622 Fin2 refa47_inst.
Proof. unfold Equation622. intro H. specialize (H F2_1 F2_0). unfold magma_op, refa47_inst, refa47_op in H. discriminate H. Qed.

Lemma refa47_not623 : ~ @Equation623 Fin2 refa47_inst.
Proof. unfold Equation623. intro H. specialize (H F2_1 F2_0). unfold magma_op, refa47_inst, refa47_op in H. discriminate H. Qed.

Lemma refa47_not629 : ~ @Equation629 Fin2 refa47_inst.
Proof. unfold Equation629. intro H. specialize (H F2_1 F2_0). unfold magma_op, refa47_inst, refa47_op in H. discriminate H. Qed.

Lemma refa47_not630 : ~ @Equation630 Fin2 refa47_inst.
Proof. unfold Equation630. intro H. specialize (H F2_1 F2_0). unfold magma_op, refa47_inst, refa47_op in H. discriminate H. Qed.

Lemma refa47_not632 : ~ @Equation632 Fin2 refa47_inst.
Proof. unfold Equation632. intro H. specialize (H F2_1 F2_0). unfold magma_op, refa47_inst, refa47_op in H. discriminate H. Qed.

Lemma refa47_not633 : ~ @Equation633 Fin2 refa47_inst.
Proof. unfold Equation633. intro H. specialize (H F2_1 F2_0). unfold magma_op, refa47_inst, refa47_op in H. discriminate H. Qed.

Lemma refa47_not639 : ~ @Equation639 Fin2 refa47_inst.
Proof. unfold Equation639. intro H. specialize (H F2_1 F2_0). unfold magma_op, refa47_inst, refa47_op in H. discriminate H. Qed.

Lemma refa47_not640 : ~ @Equation640 Fin2 refa47_inst.
Proof. unfold Equation640. intro H. specialize (H F2_1 F2_0). unfold magma_op, refa47_inst, refa47_op in H. discriminate H. Qed.

Lemma refa47_not642 : ~ @Equation642 Fin2 refa47_inst.
Proof. unfold Equation642. intro H. specialize (H F2_1 F2_0). unfold magma_op, refa47_inst, refa47_op in H. discriminate H. Qed.

Lemma refa47_not643 : ~ @Equation643 Fin2 refa47_inst.
Proof. unfold Equation643. intro H. specialize (H F2_1 F2_0). unfold magma_op, refa47_inst, refa47_op in H. discriminate H. Qed.

Lemma refa47_not667 : ~ @Equation667 Fin2 refa47_inst.
Proof. unfold Equation667. intro H. specialize (H F2_1 F2_0). unfold magma_op, refa47_inst, refa47_op in H. discriminate H. Qed.

Lemma refa47_not669 : ~ @Equation669 Fin2 refa47_inst.
Proof. unfold Equation669. intro H. specialize (H F2_1 F2_0). unfold magma_op, refa47_inst, refa47_op in H. discriminate H. Qed.

Lemma refa47_not676 : ~ @Equation676 Fin2 refa47_inst.
Proof. unfold Equation676. intro H. specialize (H F2_1 F2_0). unfold magma_op, refa47_inst, refa47_op in H. discriminate H. Qed.

Lemma refa47_not680 : ~ @Equation680 Fin2 refa47_inst.
Proof. unfold Equation680. intro H. specialize (H F2_1 F2_0). unfold magma_op, refa47_inst, refa47_op in H. discriminate H. Qed.

Lemma refa47_not707 : ~ @Equation707 Fin2 refa47_inst.
Proof. unfold Equation707. intro H. specialize (H F2_1 F2_0). unfold magma_op, refa47_inst, refa47_op in H. discriminate H. Qed.

Lemma refa47_not714 : ~ @Equation714 Fin2 refa47_inst.
Proof. unfold Equation714. intro H. specialize (H F2_1 F2_0). unfold magma_op, refa47_inst, refa47_op in H. discriminate H. Qed.

Lemma refa47_not716 : ~ @Equation716 Fin2 refa47_inst.
Proof. unfold Equation716. intro H. specialize (H F2_1 F2_0). unfold magma_op, refa47_inst, refa47_op in H. discriminate H. Qed.

Lemma refa47_not818 : ~ @Equation818 Fin2 refa47_inst.
Proof. unfold Equation818. intro H. specialize (H F2_1 F2_0). unfold magma_op, refa47_inst, refa47_op in H. discriminate H. Qed.

Lemma refa47_not819 : ~ @Equation819 Fin2 refa47_inst.
Proof. unfold Equation819. intro H. specialize (H F2_1 F2_0). unfold magma_op, refa47_inst, refa47_op in H. discriminate H. Qed.

Lemma refa47_not820 : ~ @Equation820 Fin2 refa47_inst.
Proof. unfold Equation820. intro H. specialize (H F2_1 F2_0). unfold magma_op, refa47_inst, refa47_op in H. discriminate H. Qed.

Lemma refa47_not822 : ~ @Equation822 Fin2 refa47_inst.
Proof. unfold Equation822. intro H. specialize (H F2_1 F2_0). unfold magma_op, refa47_inst, refa47_op in H. discriminate H. Qed.

Lemma refa47_not823 : ~ @Equation823 Fin2 refa47_inst.
Proof. unfold Equation823. intro H. specialize (H F2_1 F2_0). unfold magma_op, refa47_inst, refa47_op in H. discriminate H. Qed.

Lemma refa47_not825 : ~ @Equation825 Fin2 refa47_inst.
Proof. unfold Equation825. intro H. specialize (H F2_1 F2_0). unfold magma_op, refa47_inst, refa47_op in H. discriminate H. Qed.

Lemma refa47_not826 : ~ @Equation826 Fin2 refa47_inst.
Proof. unfold Equation826. intro H. specialize (H F2_1 F2_0). unfold magma_op, refa47_inst, refa47_op in H. discriminate H. Qed.

Lemma refa47_not832 : ~ @Equation832 Fin2 refa47_inst.
Proof. unfold Equation832. intro H. specialize (H F2_1 F2_0). unfold magma_op, refa47_inst, refa47_op in H. discriminate H. Qed.

Lemma refa47_not833 : ~ @Equation833 Fin2 refa47_inst.
Proof. unfold Equation833. intro H. specialize (H F2_1 F2_0). unfold magma_op, refa47_inst, refa47_op in H. discriminate H. Qed.

Lemma refa47_not835 : ~ @Equation835 Fin2 refa47_inst.
Proof. unfold Equation835. intro H. specialize (H F2_1 F2_0). unfold magma_op, refa47_inst, refa47_op in H. discriminate H. Qed.

Lemma refa47_not836 : ~ @Equation836 Fin2 refa47_inst.
Proof. unfold Equation836. intro H. specialize (H F2_1 F2_0). unfold magma_op, refa47_inst, refa47_op in H. discriminate H. Qed.

Lemma refa47_not842 : ~ @Equation842 Fin2 refa47_inst.
Proof. unfold Equation842. intro H. specialize (H F2_1 F2_0). unfold magma_op, refa47_inst, refa47_op in H. discriminate H. Qed.

Lemma refa47_not843 : ~ @Equation843 Fin2 refa47_inst.
Proof. unfold Equation843. intro H. specialize (H F2_1 F2_0). unfold magma_op, refa47_inst, refa47_op in H. discriminate H. Qed.

Lemma refa47_not845 : ~ @Equation845 Fin2 refa47_inst.
Proof. unfold Equation845. intro H. specialize (H F2_1 F2_0). unfold magma_op, refa47_inst, refa47_op in H. discriminate H. Qed.

Lemma refa47_not846 : ~ @Equation846 Fin2 refa47_inst.
Proof. unfold Equation846. intro H. specialize (H F2_1 F2_0). unfold magma_op, refa47_inst, refa47_op in H. discriminate H. Qed.

Lemma refa47_not1021 : ~ @Equation1021 Fin2 refa47_inst.
Proof. unfold Equation1021. intro H. specialize (H F2_1 F2_0). unfold magma_op, refa47_inst, refa47_op in H. discriminate H. Qed.

Lemma refa47_not1022 : ~ @Equation1022 Fin2 refa47_inst.
Proof. unfold Equation1022. intro H. specialize (H F2_1 F2_0). unfold magma_op, refa47_inst, refa47_op in H. discriminate H. Qed.

Lemma refa47_not1023 : ~ @Equation1023 Fin2 refa47_inst.
Proof. unfold Equation1023. intro H. specialize (H F2_1 F2_0). unfold magma_op, refa47_inst, refa47_op in H. discriminate H. Qed.

Lemma refa47_not1025 : ~ @Equation1025 Fin2 refa47_inst.
Proof. unfold Equation1025. intro H. specialize (H F2_1 F2_0). unfold magma_op, refa47_inst, refa47_op in H. discriminate H. Qed.

Lemma refa47_not1026 : ~ @Equation1026 Fin2 refa47_inst.
Proof. unfold Equation1026. intro H. specialize (H F2_1 F2_0). unfold magma_op, refa47_inst, refa47_op in H. discriminate H. Qed.

Lemma refa47_not1028 : ~ @Equation1028 Fin2 refa47_inst.
Proof. unfold Equation1028. intro H. specialize (H F2_1 F2_0). unfold magma_op, refa47_inst, refa47_op in H. discriminate H. Qed.

Lemma refa47_not1029 : ~ @Equation1029 Fin2 refa47_inst.
Proof. unfold Equation1029. intro H. specialize (H F2_1 F2_0). unfold magma_op, refa47_inst, refa47_op in H. discriminate H. Qed.

Lemma refa47_not1035 : ~ @Equation1035 Fin2 refa47_inst.
Proof. unfold Equation1035. intro H. specialize (H F2_1 F2_0). unfold magma_op, refa47_inst, refa47_op in H. discriminate H. Qed.

Lemma refa47_not1036 : ~ @Equation1036 Fin2 refa47_inst.
Proof. unfold Equation1036. intro H. specialize (H F2_1 F2_0). unfold magma_op, refa47_inst, refa47_op in H. discriminate H. Qed.

Lemma refa47_not1038 : ~ @Equation1038 Fin2 refa47_inst.
Proof. unfold Equation1038. intro H. specialize (H F2_1 F2_0). unfold magma_op, refa47_inst, refa47_op in H. discriminate H. Qed.

Lemma refa47_not1039 : ~ @Equation1039 Fin2 refa47_inst.
Proof. unfold Equation1039. intro H. specialize (H F2_1 F2_0). unfold magma_op, refa47_inst, refa47_op in H. discriminate H. Qed.

Lemma refa47_not1045 : ~ @Equation1045 Fin2 refa47_inst.
Proof. unfold Equation1045. intro H. specialize (H F2_1 F2_0). unfold magma_op, refa47_inst, refa47_op in H. discriminate H. Qed.

Lemma refa47_not1046 : ~ @Equation1046 Fin2 refa47_inst.
Proof. unfold Equation1046. intro H. specialize (H F2_1 F2_0). unfold magma_op, refa47_inst, refa47_op in H. discriminate H. Qed.

Lemma refa47_not1048 : ~ @Equation1048 Fin2 refa47_inst.
Proof. unfold Equation1048. intro H. specialize (H F2_1 F2_0). unfold magma_op, refa47_inst, refa47_op in H. discriminate H. Qed.

Lemma refa47_not1049 : ~ @Equation1049 Fin2 refa47_inst.
Proof. unfold Equation1049. intro H. specialize (H F2_1 F2_0). unfold magma_op, refa47_inst, refa47_op in H. discriminate H. Qed.

Lemma refa47_not1113 : ~ @Equation1113 Fin2 refa47_inst.
Proof. unfold Equation1113. intro H. specialize (H F2_1 F2_0). unfold magma_op, refa47_inst, refa47_op in H. discriminate H. Qed.

Lemma refa47_not1224 : ~ @Equation1224 Fin2 refa47_inst.
Proof. unfold Equation1224. intro H. specialize (H F2_1 F2_0). unfold magma_op, refa47_inst, refa47_op in H. discriminate H. Qed.

Lemma refa47_not1225 : ~ @Equation1225 Fin2 refa47_inst.
Proof. unfold Equation1225. intro H. specialize (H F2_1 F2_0). unfold magma_op, refa47_inst, refa47_op in H. discriminate H. Qed.

Lemma refa47_not1226 : ~ @Equation1226 Fin2 refa47_inst.
Proof. unfold Equation1226. intro H. specialize (H F2_1 F2_0). unfold magma_op, refa47_inst, refa47_op in H. discriminate H. Qed.

Lemma refa47_not1228 : ~ @Equation1228 Fin2 refa47_inst.
Proof. unfold Equation1228. intro H. specialize (H F2_1 F2_0). unfold magma_op, refa47_inst, refa47_op in H. discriminate H. Qed.

Lemma refa47_not1229 : ~ @Equation1229 Fin2 refa47_inst.
Proof. unfold Equation1229. intro H. specialize (H F2_1 F2_0). unfold magma_op, refa47_inst, refa47_op in H. discriminate H. Qed.

Lemma refa47_not1231 : ~ @Equation1231 Fin2 refa47_inst.
Proof. unfold Equation1231. intro H. specialize (H F2_1 F2_0). unfold magma_op, refa47_inst, refa47_op in H. discriminate H. Qed.

Lemma refa47_not1232 : ~ @Equation1232 Fin2 refa47_inst.
Proof. unfold Equation1232. intro H. specialize (H F2_1 F2_0). unfold magma_op, refa47_inst, refa47_op in H. discriminate H. Qed.

Lemma refa47_not1238 : ~ @Equation1238 Fin2 refa47_inst.
Proof. unfold Equation1238. intro H. specialize (H F2_1 F2_0). unfold magma_op, refa47_inst, refa47_op in H. discriminate H. Qed.

Lemma refa47_not1239 : ~ @Equation1239 Fin2 refa47_inst.
Proof. unfold Equation1239. intro H. specialize (H F2_1 F2_0). unfold magma_op, refa47_inst, refa47_op in H. discriminate H. Qed.

Lemma refa47_not1241 : ~ @Equation1241 Fin2 refa47_inst.
Proof. unfold Equation1241. intro H. specialize (H F2_1 F2_0). unfold magma_op, refa47_inst, refa47_op in H. discriminate H. Qed.

Lemma refa47_not1242 : ~ @Equation1242 Fin2 refa47_inst.
Proof. unfold Equation1242. intro H. specialize (H F2_1 F2_0). unfold magma_op, refa47_inst, refa47_op in H. discriminate H. Qed.

Lemma refa47_not1248 : ~ @Equation1248 Fin2 refa47_inst.
Proof. unfold Equation1248. intro H. specialize (H F2_1 F2_0). unfold magma_op, refa47_inst, refa47_op in H. discriminate H. Qed.

Lemma refa47_not1249 : ~ @Equation1249 Fin2 refa47_inst.
Proof. unfold Equation1249. intro H. specialize (H F2_1 F2_0). unfold magma_op, refa47_inst, refa47_op in H. discriminate H. Qed.

Lemma refa47_not1251 : ~ @Equation1251 Fin2 refa47_inst.
Proof. unfold Equation1251. intro H. specialize (H F2_1 F2_0). unfold magma_op, refa47_inst, refa47_op in H. discriminate H. Qed.

Lemma refa47_not1252 : ~ @Equation1252 Fin2 refa47_inst.
Proof. unfold Equation1252. intro H. specialize (H F2_1 F2_0). unfold magma_op, refa47_inst, refa47_op in H. discriminate H. Qed.

Lemma refa47_not1276 : ~ @Equation1276 Fin2 refa47_inst.
Proof. unfold Equation1276. intro H. specialize (H F2_1 F2_0). unfold magma_op, refa47_inst, refa47_op in H. discriminate H. Qed.

Lemma refa47_not1289 : ~ @Equation1289 Fin2 refa47_inst.
Proof. unfold Equation1289. intro H. specialize (H F2_1 F2_0). unfold magma_op, refa47_inst, refa47_op in H. discriminate H. Qed.

Lemma refa47_not1427 : ~ @Equation1427 Fin2 refa47_inst.
Proof. unfold Equation1427. intro H. specialize (H F2_1 F2_0). unfold magma_op, refa47_inst, refa47_op in H. discriminate H. Qed.

Lemma refa47_not1428 : ~ @Equation1428 Fin2 refa47_inst.
Proof. unfold Equation1428. intro H. specialize (H F2_1 F2_0). unfold magma_op, refa47_inst, refa47_op in H. discriminate H. Qed.

Lemma refa47_not1429 : ~ @Equation1429 Fin2 refa47_inst.
Proof. unfold Equation1429. intro H. specialize (H F2_1 F2_0). unfold magma_op, refa47_inst, refa47_op in H. discriminate H. Qed.

Lemma refa47_not1431 : ~ @Equation1431 Fin2 refa47_inst.
Proof. unfold Equation1431. intro H. specialize (H F2_1 F2_0). unfold magma_op, refa47_inst, refa47_op in H. discriminate H. Qed.

Lemma refa47_not1432 : ~ @Equation1432 Fin2 refa47_inst.
Proof. unfold Equation1432. intro H. specialize (H F2_1 F2_0). unfold magma_op, refa47_inst, refa47_op in H. discriminate H. Qed.

Lemma refa47_not1434 : ~ @Equation1434 Fin2 refa47_inst.
Proof. unfold Equation1434. intro H. specialize (H F2_1 F2_0). unfold magma_op, refa47_inst, refa47_op in H. discriminate H. Qed.

Lemma refa47_not1435 : ~ @Equation1435 Fin2 refa47_inst.
Proof. unfold Equation1435. intro H. specialize (H F2_1 F2_0). unfold magma_op, refa47_inst, refa47_op in H. discriminate H. Qed.

Lemma refa47_not1441 : ~ @Equation1441 Fin2 refa47_inst.
Proof. unfold Equation1441. intro H. specialize (H F2_1 F2_0). unfold magma_op, refa47_inst, refa47_op in H. discriminate H. Qed.

Lemma refa47_not1442 : ~ @Equation1442 Fin2 refa47_inst.
Proof. unfold Equation1442. intro H. specialize (H F2_1 F2_0). unfold magma_op, refa47_inst, refa47_op in H. discriminate H. Qed.

Lemma refa47_not1444 : ~ @Equation1444 Fin2 refa47_inst.
Proof. unfold Equation1444. intro H. specialize (H F2_1 F2_0). unfold magma_op, refa47_inst, refa47_op in H. discriminate H. Qed.

Lemma refa47_not1445 : ~ @Equation1445 Fin2 refa47_inst.
Proof. unfold Equation1445. intro H. specialize (H F2_1 F2_0). unfold magma_op, refa47_inst, refa47_op in H. discriminate H. Qed.

Lemma refa47_not1451 : ~ @Equation1451 Fin2 refa47_inst.
Proof. unfold Equation1451. intro H. specialize (H F2_1 F2_0). unfold magma_op, refa47_inst, refa47_op in H. discriminate H. Qed.

Lemma refa47_not1454 : ~ @Equation1454 Fin2 refa47_inst.
Proof. unfold Equation1454. intro H. specialize (H F2_1 F2_0). unfold magma_op, refa47_inst, refa47_op in H. discriminate H. Qed.

Lemma refa47_not1455 : ~ @Equation1455 Fin2 refa47_inst.
Proof. unfold Equation1455. intro H. specialize (H F2_1 F2_0). unfold magma_op, refa47_inst, refa47_op in H. discriminate H. Qed.

Lemma refa47_not1630 : ~ @Equation1630 Fin2 refa47_inst.
Proof. unfold Equation1630. intro H. specialize (H F2_1 F2_0). unfold magma_op, refa47_inst, refa47_op in H. discriminate H. Qed.

Lemma refa47_not1631 : ~ @Equation1631 Fin2 refa47_inst.
Proof. unfold Equation1631. intro H. specialize (H F2_1 F2_0). unfold magma_op, refa47_inst, refa47_op in H. discriminate H. Qed.

Lemma refa47_not1632 : ~ @Equation1632 Fin2 refa47_inst.
Proof. unfold Equation1632. intro H. specialize (H F2_1 F2_0). unfold magma_op, refa47_inst, refa47_op in H. discriminate H. Qed.

Lemma refa47_not1634 : ~ @Equation1634 Fin2 refa47_inst.
Proof. unfold Equation1634. intro H. specialize (H F2_1 F2_0). unfold magma_op, refa47_inst, refa47_op in H. discriminate H. Qed.

Lemma refa47_not1635 : ~ @Equation1635 Fin2 refa47_inst.
Proof. unfold Equation1635. intro H. specialize (H F2_1 F2_0). unfold magma_op, refa47_inst, refa47_op in H. discriminate H. Qed.

Lemma refa47_not1637 : ~ @Equation1637 Fin2 refa47_inst.
Proof. unfold Equation1637. intro H. specialize (H F2_1 F2_0). unfold magma_op, refa47_inst, refa47_op in H. discriminate H. Qed.

Lemma refa47_not1638 : ~ @Equation1638 Fin2 refa47_inst.
Proof. unfold Equation1638. intro H. specialize (H F2_1 F2_0). unfold magma_op, refa47_inst, refa47_op in H. discriminate H. Qed.

Lemma refa47_not1644 : ~ @Equation1644 Fin2 refa47_inst.
Proof. unfold Equation1644. intro H. specialize (H F2_1 F2_0). unfold magma_op, refa47_inst, refa47_op in H. discriminate H. Qed.

Lemma refa47_not1645 : ~ @Equation1645 Fin2 refa47_inst.
Proof. unfold Equation1645. intro H. specialize (H F2_1 F2_0). unfold magma_op, refa47_inst, refa47_op in H. discriminate H. Qed.

Lemma refa47_not1647 : ~ @Equation1647 Fin2 refa47_inst.
Proof. unfold Equation1647. intro H. specialize (H F2_1 F2_0). unfold magma_op, refa47_inst, refa47_op in H. discriminate H. Qed.

Lemma refa47_not1648 : ~ @Equation1648 Fin2 refa47_inst.
Proof. unfold Equation1648. intro H. specialize (H F2_1 F2_0). unfold magma_op, refa47_inst, refa47_op in H. discriminate H. Qed.

Lemma refa47_not1654 : ~ @Equation1654 Fin2 refa47_inst.
Proof. unfold Equation1654. intro H. specialize (H F2_1 F2_0). unfold magma_op, refa47_inst, refa47_op in H. discriminate H. Qed.

Lemma refa47_not1655 : ~ @Equation1655 Fin2 refa47_inst.
Proof. unfold Equation1655. intro H. specialize (H F2_1 F2_0). unfold magma_op, refa47_inst, refa47_op in H. discriminate H. Qed.

Lemma refa47_not1657 : ~ @Equation1657 Fin2 refa47_inst.
Proof. unfold Equation1657. intro H. specialize (H F2_1 F2_0). unfold magma_op, refa47_inst, refa47_op in H. discriminate H. Qed.

Lemma refa47_not1658 : ~ @Equation1658 Fin2 refa47_inst.
Proof. unfold Equation1658. intro H. specialize (H F2_1 F2_0). unfold magma_op, refa47_inst, refa47_op in H. discriminate H. Qed.

Lemma refa47_not1833 : ~ @Equation1833 Fin2 refa47_inst.
Proof. unfold Equation1833. intro H. specialize (H F2_1 F2_0). unfold magma_op, refa47_inst, refa47_op in H. discriminate H. Qed.

Lemma refa47_not1834 : ~ @Equation1834 Fin2 refa47_inst.
Proof. unfold Equation1834. intro H. specialize (H F2_1 F2_0). unfold magma_op, refa47_inst, refa47_op in H. discriminate H. Qed.

Lemma refa47_not1837 : ~ @Equation1837 Fin2 refa47_inst.
Proof. unfold Equation1837. intro H. specialize (H F2_1 F2_0). unfold magma_op, refa47_inst, refa47_op in H. discriminate H. Qed.

Lemma refa47_not1838 : ~ @Equation1838 Fin2 refa47_inst.
Proof. unfold Equation1838. intro H. specialize (H F2_1 F2_0). unfold magma_op, refa47_inst, refa47_op in H. discriminate H. Qed.

Lemma refa47_not1840 : ~ @Equation1840 Fin2 refa47_inst.
Proof. unfold Equation1840. intro H. specialize (H F2_1 F2_0). unfold magma_op, refa47_inst, refa47_op in H. discriminate H. Qed.

Lemma refa47_not1841 : ~ @Equation1841 Fin2 refa47_inst.
Proof. unfold Equation1841. intro H. specialize (H F2_1 F2_0). unfold magma_op, refa47_inst, refa47_op in H. discriminate H. Qed.

Lemma refa47_not1847 : ~ @Equation1847 Fin2 refa47_inst.
Proof. unfold Equation1847. intro H. specialize (H F2_1 F2_0). unfold magma_op, refa47_inst, refa47_op in H. discriminate H. Qed.

Lemma refa47_not1848 : ~ @Equation1848 Fin2 refa47_inst.
Proof. unfold Equation1848. intro H. specialize (H F2_1 F2_0). unfold magma_op, refa47_inst, refa47_op in H. discriminate H. Qed.

Lemma refa47_not1850 : ~ @Equation1850 Fin2 refa47_inst.
Proof. unfold Equation1850. intro H. specialize (H F2_1 F2_0). unfold magma_op, refa47_inst, refa47_op in H. discriminate H. Qed.

Lemma refa47_not1851 : ~ @Equation1851 Fin2 refa47_inst.
Proof. unfold Equation1851. intro H. specialize (H F2_1 F2_0). unfold magma_op, refa47_inst, refa47_op in H. discriminate H. Qed.

Lemma refa47_not1857 : ~ @Equation1857 Fin2 refa47_inst.
Proof. unfold Equation1857. intro H. specialize (H F2_1 F2_0). unfold magma_op, refa47_inst, refa47_op in H. discriminate H. Qed.

Lemma refa47_not1858 : ~ @Equation1858 Fin2 refa47_inst.
Proof. unfold Equation1858. intro H. specialize (H F2_1 F2_0). unfold magma_op, refa47_inst, refa47_op in H. discriminate H. Qed.

Lemma refa47_not1860 : ~ @Equation1860 Fin2 refa47_inst.
Proof. unfold Equation1860. intro H. specialize (H F2_1 F2_0). unfold magma_op, refa47_inst, refa47_op in H. discriminate H. Qed.

Lemma refa47_not1861 : ~ @Equation1861 Fin2 refa47_inst.
Proof. unfold Equation1861. intro H. specialize (H F2_1 F2_0). unfold magma_op, refa47_inst, refa47_op in H. discriminate H. Qed.

Lemma refa47_not2036 : ~ @Equation2036 Fin2 refa47_inst.
Proof. unfold Equation2036. intro H. specialize (H F2_1 F2_0). unfold magma_op, refa47_inst, refa47_op in H. discriminate H. Qed.

Lemma refa47_not2037 : ~ @Equation2037 Fin2 refa47_inst.
Proof. unfold Equation2037. intro H. specialize (H F2_1 F2_0). unfold magma_op, refa47_inst, refa47_op in H. discriminate H. Qed.

Lemma refa47_not2038 : ~ @Equation2038 Fin2 refa47_inst.
Proof. unfold Equation2038. intro H. specialize (H F2_1 F2_0). unfold magma_op, refa47_inst, refa47_op in H. discriminate H. Qed.

Lemma refa47_not2040 : ~ @Equation2040 Fin2 refa47_inst.
Proof. unfold Equation2040. intro H. specialize (H F2_1 F2_0). unfold magma_op, refa47_inst, refa47_op in H. discriminate H. Qed.

Lemma refa47_not2041 : ~ @Equation2041 Fin2 refa47_inst.
Proof. unfold Equation2041. intro H. specialize (H F2_1 F2_0). unfold magma_op, refa47_inst, refa47_op in H. discriminate H. Qed.

Lemma refa47_not2043 : ~ @Equation2043 Fin2 refa47_inst.
Proof. unfold Equation2043. intro H. specialize (H F2_1 F2_0). unfold magma_op, refa47_inst, refa47_op in H. discriminate H. Qed.

Lemma refa47_not2044 : ~ @Equation2044 Fin2 refa47_inst.
Proof. unfold Equation2044. intro H. specialize (H F2_1 F2_0). unfold magma_op, refa47_inst, refa47_op in H. discriminate H. Qed.

Lemma refa47_not2050 : ~ @Equation2050 Fin2 refa47_inst.
Proof. unfold Equation2050. intro H. specialize (H F2_1 F2_0). unfold magma_op, refa47_inst, refa47_op in H. discriminate H. Qed.

Lemma refa47_not2051 : ~ @Equation2051 Fin2 refa47_inst.
Proof. unfold Equation2051. intro H. specialize (H F2_1 F2_0). unfold magma_op, refa47_inst, refa47_op in H. discriminate H. Qed.

Lemma refa47_not2053 : ~ @Equation2053 Fin2 refa47_inst.
Proof. unfold Equation2053. intro H. specialize (H F2_1 F2_0). unfold magma_op, refa47_inst, refa47_op in H. discriminate H. Qed.

Lemma refa47_not2054 : ~ @Equation2054 Fin2 refa47_inst.
Proof. unfold Equation2054. intro H. specialize (H F2_1 F2_0). unfold magma_op, refa47_inst, refa47_op in H. discriminate H. Qed.

Lemma refa47_not2060 : ~ @Equation2060 Fin2 refa47_inst.
Proof. unfold Equation2060. intro H. specialize (H F2_1 F2_0). unfold magma_op, refa47_inst, refa47_op in H. discriminate H. Qed.

Lemma refa47_not2061 : ~ @Equation2061 Fin2 refa47_inst.
Proof. unfold Equation2061. intro H. specialize (H F2_1 F2_0). unfold magma_op, refa47_inst, refa47_op in H. discriminate H. Qed.

Lemma refa47_not2063 : ~ @Equation2063 Fin2 refa47_inst.
Proof. unfold Equation2063. intro H. specialize (H F2_1 F2_0). unfold magma_op, refa47_inst, refa47_op in H. discriminate H. Qed.

Lemma refa47_not2064 : ~ @Equation2064 Fin2 refa47_inst.
Proof. unfold Equation2064. intro H. specialize (H F2_1 F2_0). unfold magma_op, refa47_inst, refa47_op in H. discriminate H. Qed.

Lemma refa47_not2088 : ~ @Equation2088 Fin2 refa47_inst.
Proof. unfold Equation2088. intro H. specialize (H F2_1 F2_0). unfold magma_op, refa47_inst, refa47_op in H. discriminate H. Qed.

Lemma refa47_not2240 : ~ @Equation2240 Fin2 refa47_inst.
Proof. unfold Equation2240. intro H. specialize (H F2_1 F2_0). unfold magma_op, refa47_inst, refa47_op in H. discriminate H. Qed.

Lemma refa47_not2241 : ~ @Equation2241 Fin2 refa47_inst.
Proof. unfold Equation2241. intro H. specialize (H F2_1 F2_0). unfold magma_op, refa47_inst, refa47_op in H. discriminate H. Qed.

Lemma refa47_not2243 : ~ @Equation2243 Fin2 refa47_inst.
Proof. unfold Equation2243. intro H. specialize (H F2_1 F2_0). unfold magma_op, refa47_inst, refa47_op in H. discriminate H. Qed.

Lemma refa47_not2244 : ~ @Equation2244 Fin2 refa47_inst.
Proof. unfold Equation2244. intro H. specialize (H F2_1 F2_0). unfold magma_op, refa47_inst, refa47_op in H. discriminate H. Qed.

Lemma refa47_not2246 : ~ @Equation2246 Fin2 refa47_inst.
Proof. unfold Equation2246. intro H. specialize (H F2_1 F2_0). unfold magma_op, refa47_inst, refa47_op in H. discriminate H. Qed.

Lemma refa47_not2247 : ~ @Equation2247 Fin2 refa47_inst.
Proof. unfold Equation2247. intro H. specialize (H F2_1 F2_0). unfold magma_op, refa47_inst, refa47_op in H. discriminate H. Qed.

Lemma refa47_not2253 : ~ @Equation2253 Fin2 refa47_inst.
Proof. unfold Equation2253. intro H. specialize (H F2_1 F2_0). unfold magma_op, refa47_inst, refa47_op in H. discriminate H. Qed.

Lemma refa47_not2254 : ~ @Equation2254 Fin2 refa47_inst.
Proof. unfold Equation2254. intro H. specialize (H F2_1 F2_0). unfold magma_op, refa47_inst, refa47_op in H. discriminate H. Qed.

Lemma refa47_not2256 : ~ @Equation2256 Fin2 refa47_inst.
Proof. unfold Equation2256. intro H. specialize (H F2_1 F2_0). unfold magma_op, refa47_inst, refa47_op in H. discriminate H. Qed.

Lemma refa47_not2257 : ~ @Equation2257 Fin2 refa47_inst.
Proof. unfold Equation2257. intro H. specialize (H F2_1 F2_0). unfold magma_op, refa47_inst, refa47_op in H. discriminate H. Qed.

Lemma refa47_not2263 : ~ @Equation2263 Fin2 refa47_inst.
Proof. unfold Equation2263. intro H. specialize (H F2_1 F2_0). unfold magma_op, refa47_inst, refa47_op in H. discriminate H. Qed.

Lemma refa47_not2264 : ~ @Equation2264 Fin2 refa47_inst.
Proof. unfold Equation2264. intro H. specialize (H F2_1 F2_0). unfold magma_op, refa47_inst, refa47_op in H. discriminate H. Qed.

Lemma refa47_not2266 : ~ @Equation2266 Fin2 refa47_inst.
Proof. unfold Equation2266. intro H. specialize (H F2_1 F2_0). unfold magma_op, refa47_inst, refa47_op in H. discriminate H. Qed.

Lemma refa47_not2293 : ~ @Equation2293 Fin2 refa47_inst.
Proof. unfold Equation2293. intro H. specialize (H F2_1 F2_0). unfold magma_op, refa47_inst, refa47_op in H. discriminate H. Qed.

Lemma refa47_not2304 : ~ @Equation2304 Fin2 refa47_inst.
Proof. unfold Equation2304. intro H. specialize (H F2_1 F2_0). unfold magma_op, refa47_inst, refa47_op in H. discriminate H. Qed.

Lemma refa47_not2443 : ~ @Equation2443 Fin2 refa47_inst.
Proof. unfold Equation2443. intro H. specialize (H F2_1 F2_0). unfold magma_op, refa47_inst, refa47_op in H. discriminate H. Qed.

Lemma refa47_not2444 : ~ @Equation2444 Fin2 refa47_inst.
Proof. unfold Equation2444. intro H. specialize (H F2_1 F2_0). unfold magma_op, refa47_inst, refa47_op in H. discriminate H. Qed.

Lemma refa47_not2446 : ~ @Equation2446 Fin2 refa47_inst.
Proof. unfold Equation2446. intro H. specialize (H F2_1 F2_0). unfold magma_op, refa47_inst, refa47_op in H. discriminate H. Qed.

Lemma refa47_not2447 : ~ @Equation2447 Fin2 refa47_inst.
Proof. unfold Equation2447. intro H. specialize (H F2_1 F2_0). unfold magma_op, refa47_inst, refa47_op in H. discriminate H. Qed.

Lemma refa47_not2449 : ~ @Equation2449 Fin2 refa47_inst.
Proof. unfold Equation2449. intro H. specialize (H F2_1 F2_0). unfold magma_op, refa47_inst, refa47_op in H. discriminate H. Qed.

Lemma refa47_not2450 : ~ @Equation2450 Fin2 refa47_inst.
Proof. unfold Equation2450. intro H. specialize (H F2_1 F2_0). unfold magma_op, refa47_inst, refa47_op in H. discriminate H. Qed.

Lemma refa47_not2456 : ~ @Equation2456 Fin2 refa47_inst.
Proof. unfold Equation2456. intro H. specialize (H F2_1 F2_0). unfold magma_op, refa47_inst, refa47_op in H. discriminate H. Qed.

Lemma refa47_not2457 : ~ @Equation2457 Fin2 refa47_inst.
Proof. unfold Equation2457. intro H. specialize (H F2_1 F2_0). unfold magma_op, refa47_inst, refa47_op in H. discriminate H. Qed.

Lemma refa47_not2459 : ~ @Equation2459 Fin2 refa47_inst.
Proof. unfold Equation2459. intro H. specialize (H F2_1 F2_0). unfold magma_op, refa47_inst, refa47_op in H. discriminate H. Qed.

Lemma refa47_not2460 : ~ @Equation2460 Fin2 refa47_inst.
Proof. unfold Equation2460. intro H. specialize (H F2_1 F2_0). unfold magma_op, refa47_inst, refa47_op in H. discriminate H. Qed.

Lemma refa47_not2466 : ~ @Equation2466 Fin2 refa47_inst.
Proof. unfold Equation2466. intro H. specialize (H F2_1 F2_0). unfold magma_op, refa47_inst, refa47_op in H. discriminate H. Qed.

Lemma refa47_not2467 : ~ @Equation2467 Fin2 refa47_inst.
Proof. unfold Equation2467. intro H. specialize (H F2_1 F2_0). unfold magma_op, refa47_inst, refa47_op in H. discriminate H. Qed.

Lemma refa47_not2469 : ~ @Equation2469 Fin2 refa47_inst.
Proof. unfold Equation2469. intro H. specialize (H F2_1 F2_0). unfold magma_op, refa47_inst, refa47_op in H. discriminate H. Qed.

Lemma refa47_not2534 : ~ @Equation2534 Fin2 refa47_inst.
Proof. unfold Equation2534. intro H. specialize (H F2_1 F2_0). unfold magma_op, refa47_inst, refa47_op in H. discriminate H. Qed.

Lemma refa47_not2646 : ~ @Equation2646 Fin2 refa47_inst.
Proof. unfold Equation2646. intro H. specialize (H F2_1 F2_0). unfold magma_op, refa47_inst, refa47_op in H. discriminate H. Qed.

Lemma refa47_not2647 : ~ @Equation2647 Fin2 refa47_inst.
Proof. unfold Equation2647. intro H. specialize (H F2_1 F2_0). unfold magma_op, refa47_inst, refa47_op in H. discriminate H. Qed.

Lemma refa47_not2649 : ~ @Equation2649 Fin2 refa47_inst.
Proof. unfold Equation2649. intro H. specialize (H F2_1 F2_0). unfold magma_op, refa47_inst, refa47_op in H. discriminate H. Qed.

Lemma refa47_not2650 : ~ @Equation2650 Fin2 refa47_inst.
Proof. unfold Equation2650. intro H. specialize (H F2_1 F2_0). unfold magma_op, refa47_inst, refa47_op in H. discriminate H. Qed.

Lemma refa47_not2652 : ~ @Equation2652 Fin2 refa47_inst.
Proof. unfold Equation2652. intro H. specialize (H F2_1 F2_0). unfold magma_op, refa47_inst, refa47_op in H. discriminate H. Qed.

Lemma refa47_not2659 : ~ @Equation2659 Fin2 refa47_inst.
Proof. unfold Equation2659. intro H. specialize (H F2_1 F2_0). unfold magma_op, refa47_inst, refa47_op in H. discriminate H. Qed.

Lemma refa47_not2660 : ~ @Equation2660 Fin2 refa47_inst.
Proof. unfold Equation2660. intro H. specialize (H F2_1 F2_0). unfold magma_op, refa47_inst, refa47_op in H. discriminate H. Qed.

Lemma refa47_not2662 : ~ @Equation2662 Fin2 refa47_inst.
Proof. unfold Equation2662. intro H. specialize (H F2_1 F2_0). unfold magma_op, refa47_inst, refa47_op in H. discriminate H. Qed.

Lemma refa47_not2669 : ~ @Equation2669 Fin2 refa47_inst.
Proof. unfold Equation2669. intro H. specialize (H F2_1 F2_0). unfold magma_op, refa47_inst, refa47_op in H. discriminate H. Qed.

Lemma refa47_not2670 : ~ @Equation2670 Fin2 refa47_inst.
Proof. unfold Equation2670. intro H. specialize (H F2_1 F2_0). unfold magma_op, refa47_inst, refa47_op in H. discriminate H. Qed.

Lemma refa47_not2672 : ~ @Equation2672 Fin2 refa47_inst.
Proof. unfold Equation2672. intro H. specialize (H F2_1 F2_0). unfold magma_op, refa47_inst, refa47_op in H. discriminate H. Qed.

Lemma refa47_not2710 : ~ @Equation2710 Fin2 refa47_inst.
Proof. unfold Equation2710. intro H. specialize (H F2_1 F2_0). unfold magma_op, refa47_inst, refa47_op in H. discriminate H. Qed.

Lemma refa47_not2744 : ~ @Equation2744 Fin2 refa47_inst.
Proof. unfold Equation2744. intro H. specialize (H F2_1 F2_0). unfold magma_op, refa47_inst, refa47_op in H. discriminate H. Qed.

Lemma refa47_not2849 : ~ @Equation2849 Fin2 refa47_inst.
Proof. unfold Equation2849. intro H. specialize (H F2_1 F2_0). unfold magma_op, refa47_inst, refa47_op in H. discriminate H. Qed.

Lemma refa47_not2852 : ~ @Equation2852 Fin2 refa47_inst.
Proof. unfold Equation2852. intro H. specialize (H F2_1 F2_0). unfold magma_op, refa47_inst, refa47_op in H. discriminate H. Qed.

Lemma refa47_not2853 : ~ @Equation2853 Fin2 refa47_inst.
Proof. unfold Equation2853. intro H. specialize (H F2_1 F2_0). unfold magma_op, refa47_inst, refa47_op in H. discriminate H. Qed.

Lemma refa47_not2855 : ~ @Equation2855 Fin2 refa47_inst.
Proof. unfold Equation2855. intro H. specialize (H F2_1 F2_0). unfold magma_op, refa47_inst, refa47_op in H. discriminate H. Qed.

Lemma refa47_not2856 : ~ @Equation2856 Fin2 refa47_inst.
Proof. unfold Equation2856. intro H. specialize (H F2_1 F2_0). unfold magma_op, refa47_inst, refa47_op in H. discriminate H. Qed.

Lemma refa47_not2862 : ~ @Equation2862 Fin2 refa47_inst.
Proof. unfold Equation2862. intro H. specialize (H F2_1 F2_0). unfold magma_op, refa47_inst, refa47_op in H. discriminate H. Qed.

Lemma refa47_not2863 : ~ @Equation2863 Fin2 refa47_inst.
Proof. unfold Equation2863. intro H. specialize (H F2_1 F2_0). unfold magma_op, refa47_inst, refa47_op in H. discriminate H. Qed.

Lemma refa47_not2865 : ~ @Equation2865 Fin2 refa47_inst.
Proof. unfold Equation2865. intro H. specialize (H F2_1 F2_0). unfold magma_op, refa47_inst, refa47_op in H. discriminate H. Qed.

Lemma refa47_not2866 : ~ @Equation2866 Fin2 refa47_inst.
Proof. unfold Equation2866. intro H. specialize (H F2_1 F2_0). unfold magma_op, refa47_inst, refa47_op in H. discriminate H. Qed.

Lemma refa47_not2872 : ~ @Equation2872 Fin2 refa47_inst.
Proof. unfold Equation2872. intro H. specialize (H F2_1 F2_0). unfold magma_op, refa47_inst, refa47_op in H. discriminate H. Qed.

Lemma refa47_not2873 : ~ @Equation2873 Fin2 refa47_inst.
Proof. unfold Equation2873. intro H. specialize (H F2_1 F2_0). unfold magma_op, refa47_inst, refa47_op in H. discriminate H. Qed.

Lemma refa47_not2875 : ~ @Equation2875 Fin2 refa47_inst.
Proof. unfold Equation2875. intro H. specialize (H F2_1 F2_0). unfold magma_op, refa47_inst, refa47_op in H. discriminate H. Qed.

Lemma refa47_not3052 : ~ @Equation3052 Fin2 refa47_inst.
Proof. unfold Equation3052. intro H. specialize (H F2_1 F2_0). unfold magma_op, refa47_inst, refa47_op in H. discriminate H. Qed.

Lemma refa47_not3055 : ~ @Equation3055 Fin2 refa47_inst.
Proof. unfold Equation3055. intro H. specialize (H F2_1 F2_0). unfold magma_op, refa47_inst, refa47_op in H. discriminate H. Qed.

Lemma refa47_not3056 : ~ @Equation3056 Fin2 refa47_inst.
Proof. unfold Equation3056. intro H. specialize (H F2_1 F2_0). unfold magma_op, refa47_inst, refa47_op in H. discriminate H. Qed.

Lemma refa47_not3058 : ~ @Equation3058 Fin2 refa47_inst.
Proof. unfold Equation3058. intro H. specialize (H F2_1 F2_0). unfold magma_op, refa47_inst, refa47_op in H. discriminate H. Qed.

Lemma refa47_not3065 : ~ @Equation3065 Fin2 refa47_inst.
Proof. unfold Equation3065. intro H. specialize (H F2_1 F2_0). unfold magma_op, refa47_inst, refa47_op in H. discriminate H. Qed.

Lemma refa47_not3066 : ~ @Equation3066 Fin2 refa47_inst.
Proof. unfold Equation3066. intro H. specialize (H F2_1 F2_0). unfold magma_op, refa47_inst, refa47_op in H. discriminate H. Qed.

Lemma refa47_not3068 : ~ @Equation3068 Fin2 refa47_inst.
Proof. unfold Equation3068. intro H. specialize (H F2_1 F2_0). unfold magma_op, refa47_inst, refa47_op in H. discriminate H. Qed.

Lemma refa47_not3069 : ~ @Equation3069 Fin2 refa47_inst.
Proof. unfold Equation3069. intro H. specialize (H F2_1 F2_0). unfold magma_op, refa47_inst, refa47_op in H. discriminate H. Qed.

Lemma refa47_not3075 : ~ @Equation3075 Fin2 refa47_inst.
Proof. unfold Equation3075. intro H. specialize (H F2_1 F2_0). unfold magma_op, refa47_inst, refa47_op in H. discriminate H. Qed.

Lemma refa47_not3076 : ~ @Equation3076 Fin2 refa47_inst.
Proof. unfold Equation3076. intro H. specialize (H F2_1 F2_0). unfold magma_op, refa47_inst, refa47_op in H. discriminate H. Qed.

Lemma refa47_not3078 : ~ @Equation3078 Fin2 refa47_inst.
Proof. unfold Equation3078. intro H. specialize (H F2_1 F2_0). unfold magma_op, refa47_inst, refa47_op in H. discriminate H. Qed.

Lemma refa47_not3079 : ~ @Equation3079 Fin2 refa47_inst.
Proof. unfold Equation3079. intro H. specialize (H F2_1 F2_0). unfold magma_op, refa47_inst, refa47_op in H. discriminate H. Qed.

Lemma refa47_not3143 : ~ @Equation3143 Fin2 refa47_inst.
Proof. unfold Equation3143. intro H. specialize (H F2_1 F2_0). unfold magma_op, refa47_inst, refa47_op in H. discriminate H. Qed.

Lemma refa47_not3254 : ~ @Equation3254 Fin2 refa47_inst.
Proof. unfold Equation3254. intro H. specialize (H F2_1 F2_0). unfold magma_op, refa47_inst, refa47_op in H. discriminate H. Qed.

Lemma refa47_not3255 : ~ @Equation3255 Fin2 refa47_inst.
Proof. unfold Equation3255. intro H. specialize (H F2_1 F2_0). unfold magma_op, refa47_inst, refa47_op in H. discriminate H. Qed.

Lemma refa47_not3256 : ~ @Equation3256 Fin2 refa47_inst.
Proof. unfold Equation3256. intro H. specialize (H F2_1 F2_0). unfold magma_op, refa47_inst, refa47_op in H. discriminate H. Qed.

Lemma refa47_not3258 : ~ @Equation3258 Fin2 refa47_inst.
Proof. unfold Equation3258. intro H. specialize (H F2_1 F2_0). unfold magma_op, refa47_inst, refa47_op in H. discriminate H. Qed.

Lemma refa47_not3259 : ~ @Equation3259 Fin2 refa47_inst.
Proof. unfold Equation3259. intro H. specialize (H F2_1 F2_0). unfold magma_op, refa47_inst, refa47_op in H. discriminate H. Qed.

Lemma refa47_not3261 : ~ @Equation3261 Fin2 refa47_inst.
Proof. unfold Equation3261. intro H. specialize (H F2_1 F2_0). unfold magma_op, refa47_inst, refa47_op in H. discriminate H. Qed.

Lemma refa47_not3262 : ~ @Equation3262 Fin2 refa47_inst.
Proof. unfold Equation3262. intro H. specialize (H F2_1 F2_0). unfold magma_op, refa47_inst, refa47_op in H. discriminate H. Qed.

Lemma refa47_not3268 : ~ @Equation3268 Fin2 refa47_inst.
Proof. unfold Equation3268. intro H. specialize (H F2_1 F2_0). unfold magma_op, refa47_inst, refa47_op in H. discriminate H. Qed.

Lemma refa47_not3269 : ~ @Equation3269 Fin2 refa47_inst.
Proof. unfold Equation3269. intro H. specialize (H F2_1 F2_0). unfold magma_op, refa47_inst, refa47_op in H. discriminate H. Qed.

Lemma refa47_not3271 : ~ @Equation3271 Fin2 refa47_inst.
Proof. unfold Equation3271. intro H. specialize (H F2_1 F2_0). unfold magma_op, refa47_inst, refa47_op in H. discriminate H. Qed.

Lemma refa47_not3272 : ~ @Equation3272 Fin2 refa47_inst.
Proof. unfold Equation3272. intro H. specialize (H F2_1 F2_0). unfold magma_op, refa47_inst, refa47_op in H. discriminate H. Qed.

Lemma refa47_not3278 : ~ @Equation3278 Fin2 refa47_inst.
Proof. unfold Equation3278. intro H. specialize (H F2_1 F2_0). unfold magma_op, refa47_inst, refa47_op in H. discriminate H. Qed.

Lemma refa47_not3279 : ~ @Equation3279 Fin2 refa47_inst.
Proof. unfold Equation3279. intro H. specialize (H F2_1 F2_0). unfold magma_op, refa47_inst, refa47_op in H. discriminate H. Qed.

Lemma refa47_not3281 : ~ @Equation3281 Fin2 refa47_inst.
Proof. unfold Equation3281. intro H. specialize (H F2_1 F2_0). unfold magma_op, refa47_inst, refa47_op in H. discriminate H. Qed.

Lemma refa47_not3457 : ~ @Equation3457 Fin2 refa47_inst.
Proof. unfold Equation3457. intro H. specialize (H F2_1 F2_0). unfold magma_op, refa47_inst, refa47_op in H. discriminate H. Qed.

Lemma refa47_not3458 : ~ @Equation3458 Fin2 refa47_inst.
Proof. unfold Equation3458. intro H. specialize (H F2_1 F2_0). unfold magma_op, refa47_inst, refa47_op in H. discriminate H. Qed.

Lemma refa47_not3459 : ~ @Equation3459 Fin2 refa47_inst.
Proof. unfold Equation3459. intro H. specialize (H F2_1 F2_0). unfold magma_op, refa47_inst, refa47_op in H. discriminate H. Qed.

Lemma refa47_not3461 : ~ @Equation3461 Fin2 refa47_inst.
Proof. unfold Equation3461. intro H. specialize (H F2_1 F2_0). unfold magma_op, refa47_inst, refa47_op in H. discriminate H. Qed.

Lemma refa47_not3462 : ~ @Equation3462 Fin2 refa47_inst.
Proof. unfold Equation3462. intro H. specialize (H F2_1 F2_0). unfold magma_op, refa47_inst, refa47_op in H. discriminate H. Qed.

Lemma refa47_not3464 : ~ @Equation3464 Fin2 refa47_inst.
Proof. unfold Equation3464. intro H. specialize (H F2_1 F2_0). unfold magma_op, refa47_inst, refa47_op in H. discriminate H. Qed.

Lemma refa47_not3465 : ~ @Equation3465 Fin2 refa47_inst.
Proof. unfold Equation3465. intro H. specialize (H F2_1 F2_0). unfold magma_op, refa47_inst, refa47_op in H. discriminate H. Qed.

Lemma refa47_not3472 : ~ @Equation3472 Fin2 refa47_inst.
Proof. unfold Equation3472. intro H. specialize (H F2_1 F2_0). unfold magma_op, refa47_inst, refa47_op in H. discriminate H. Qed.

Lemma refa47_not3474 : ~ @Equation3474 Fin2 refa47_inst.
Proof. unfold Equation3474. intro H. specialize (H F2_1 F2_0). unfold magma_op, refa47_inst, refa47_op in H. discriminate H. Qed.

Lemma refa47_not3475 : ~ @Equation3475 Fin2 refa47_inst.
Proof. unfold Equation3475. intro H. specialize (H F2_1 F2_0). unfold magma_op, refa47_inst, refa47_op in H. discriminate H. Qed.

Lemma refa47_not3481 : ~ @Equation3481 Fin2 refa47_inst.
Proof. unfold Equation3481. intro H. specialize (H F2_1 F2_0). unfold magma_op, refa47_inst, refa47_op in H. discriminate H. Qed.

Lemma refa47_not3482 : ~ @Equation3482 Fin2 refa47_inst.
Proof. unfold Equation3482. intro H. specialize (H F2_1 F2_0). unfold magma_op, refa47_inst, refa47_op in H. discriminate H. Qed.

Lemma refa47_not3484 : ~ @Equation3484 Fin2 refa47_inst.
Proof. unfold Equation3484. intro H. specialize (H F2_1 F2_0). unfold magma_op, refa47_inst, refa47_op in H. discriminate H. Qed.

Lemma refa47_not3660 : ~ @Equation3660 Fin2 refa47_inst.
Proof. unfold Equation3660. intro H. specialize (H F2_1 F2_0). unfold magma_op, refa47_inst, refa47_op in H. discriminate H. Qed.

Lemma refa47_not3661 : ~ @Equation3661 Fin2 refa47_inst.
Proof. unfold Equation3661. intro H. specialize (H F2_1 F2_0). unfold magma_op, refa47_inst, refa47_op in H. discriminate H. Qed.

Lemma refa47_not3662 : ~ @Equation3662 Fin2 refa47_inst.
Proof. unfold Equation3662. intro H. specialize (H F2_1 F2_0). unfold magma_op, refa47_inst, refa47_op in H. discriminate H. Qed.

Lemma refa47_not3664 : ~ @Equation3664 Fin2 refa47_inst.
Proof. unfold Equation3664. intro H. specialize (H F2_1 F2_0). unfold magma_op, refa47_inst, refa47_op in H. discriminate H. Qed.

Lemma refa47_not3665 : ~ @Equation3665 Fin2 refa47_inst.
Proof. unfold Equation3665. intro H. specialize (H F2_1 F2_0). unfold magma_op, refa47_inst, refa47_op in H. discriminate H. Qed.

Lemma refa47_not3667 : ~ @Equation3667 Fin2 refa47_inst.
Proof. unfold Equation3667. intro H. specialize (H F2_1 F2_0). unfold magma_op, refa47_inst, refa47_op in H. discriminate H. Qed.

Lemma refa47_not3668 : ~ @Equation3668 Fin2 refa47_inst.
Proof. unfold Equation3668. intro H. specialize (H F2_1 F2_0). unfold magma_op, refa47_inst, refa47_op in H. discriminate H. Qed.

Lemma refa47_not3674 : ~ @Equation3674 Fin2 refa47_inst.
Proof. unfold Equation3674. intro H. specialize (H F2_1 F2_0). unfold magma_op, refa47_inst, refa47_op in H. discriminate H. Qed.

Lemma refa47_not3675 : ~ @Equation3675 Fin2 refa47_inst.
Proof. unfold Equation3675. intro H. specialize (H F2_1 F2_0). unfold magma_op, refa47_inst, refa47_op in H. discriminate H. Qed.

Lemma refa47_not3677 : ~ @Equation3677 Fin2 refa47_inst.
Proof. unfold Equation3677. intro H. specialize (H F2_1 F2_0). unfold magma_op, refa47_inst, refa47_op in H. discriminate H. Qed.

Lemma refa47_not3678 : ~ @Equation3678 Fin2 refa47_inst.
Proof. unfold Equation3678. intro H. specialize (H F2_1 F2_0). unfold magma_op, refa47_inst, refa47_op in H. discriminate H. Qed.

Lemma refa47_not3684 : ~ @Equation3684 Fin2 refa47_inst.
Proof. unfold Equation3684. intro H. specialize (H F2_1 F2_0). unfold magma_op, refa47_inst, refa47_op in H. discriminate H. Qed.

Lemma refa47_not3685 : ~ @Equation3685 Fin2 refa47_inst.
Proof. unfold Equation3685. intro H. specialize (H F2_1 F2_0). unfold magma_op, refa47_inst, refa47_op in H. discriminate H. Qed.

Lemma refa47_not3687 : ~ @Equation3687 Fin2 refa47_inst.
Proof. unfold Equation3687. intro H. specialize (H F2_1 F2_0). unfold magma_op, refa47_inst, refa47_op in H. discriminate H. Qed.

Lemma refa47_not3864 : ~ @Equation3864 Fin2 refa47_inst.
Proof. unfold Equation3864. intro H. specialize (H F2_1 F2_0). unfold magma_op, refa47_inst, refa47_op in H. discriminate H. Qed.

Lemma refa47_not3865 : ~ @Equation3865 Fin2 refa47_inst.
Proof. unfold Equation3865. intro H. specialize (H F2_1 F2_0). unfold magma_op, refa47_inst, refa47_op in H. discriminate H. Qed.

Lemma refa47_not3867 : ~ @Equation3867 Fin2 refa47_inst.
Proof. unfold Equation3867. intro H. specialize (H F2_1 F2_0). unfold magma_op, refa47_inst, refa47_op in H. discriminate H. Qed.

Lemma refa47_not3868 : ~ @Equation3868 Fin2 refa47_inst.
Proof. unfold Equation3868. intro H. specialize (H F2_1 F2_0). unfold magma_op, refa47_inst, refa47_op in H. discriminate H. Qed.

Lemma refa47_not3870 : ~ @Equation3870 Fin2 refa47_inst.
Proof. unfold Equation3870. intro H. specialize (H F2_1 F2_0). unfold magma_op, refa47_inst, refa47_op in H. discriminate H. Qed.

Lemma refa47_not3871 : ~ @Equation3871 Fin2 refa47_inst.
Proof. unfold Equation3871. intro H. specialize (H F2_1 F2_0). unfold magma_op, refa47_inst, refa47_op in H. discriminate H. Qed.

Lemma refa47_not3877 : ~ @Equation3877 Fin2 refa47_inst.
Proof. unfold Equation3877. intro H. specialize (H F2_1 F2_0). unfold magma_op, refa47_inst, refa47_op in H. discriminate H. Qed.

Lemma refa47_not3878 : ~ @Equation3878 Fin2 refa47_inst.
Proof. unfold Equation3878. intro H. specialize (H F2_1 F2_0). unfold magma_op, refa47_inst, refa47_op in H. discriminate H. Qed.

Lemma refa47_not3880 : ~ @Equation3880 Fin2 refa47_inst.
Proof. unfold Equation3880. intro H. specialize (H F2_1 F2_0). unfold magma_op, refa47_inst, refa47_op in H. discriminate H. Qed.

Lemma refa47_not3881 : ~ @Equation3881 Fin2 refa47_inst.
Proof. unfold Equation3881. intro H. specialize (H F2_1 F2_0). unfold magma_op, refa47_inst, refa47_op in H. discriminate H. Qed.

Lemma refa47_not3887 : ~ @Equation3887 Fin2 refa47_inst.
Proof. unfold Equation3887. intro H. specialize (H F2_1 F2_0). unfold magma_op, refa47_inst, refa47_op in H. discriminate H. Qed.

Lemma refa47_not3888 : ~ @Equation3888 Fin2 refa47_inst.
Proof. unfold Equation3888. intro H. specialize (H F2_1 F2_0). unfold magma_op, refa47_inst, refa47_op in H. discriminate H. Qed.

Lemma refa47_not3890 : ~ @Equation3890 Fin2 refa47_inst.
Proof. unfold Equation3890. intro H. specialize (H F2_1 F2_0). unfold magma_op, refa47_inst, refa47_op in H. discriminate H. Qed.

Lemma refa47_not4066 : ~ @Equation4066 Fin2 refa47_inst.
Proof. unfold Equation4066. intro H. specialize (H F2_1 F2_0). unfold magma_op, refa47_inst, refa47_op in H. discriminate H. Qed.

Lemma refa47_not4067 : ~ @Equation4067 Fin2 refa47_inst.
Proof. unfold Equation4067. intro H. specialize (H F2_1 F2_0). unfold magma_op, refa47_inst, refa47_op in H. discriminate H. Qed.

Lemma refa47_not4068 : ~ @Equation4068 Fin2 refa47_inst.
Proof. unfold Equation4068. intro H. specialize (H F2_1 F2_0). unfold magma_op, refa47_inst, refa47_op in H. discriminate H. Qed.

Lemma refa47_not4070 : ~ @Equation4070 Fin2 refa47_inst.
Proof. unfold Equation4070. intro H. specialize (H F2_1 F2_0). unfold magma_op, refa47_inst, refa47_op in H. discriminate H. Qed.

Lemma refa47_not4071 : ~ @Equation4071 Fin2 refa47_inst.
Proof. unfold Equation4071. intro H. specialize (H F2_1 F2_0). unfold magma_op, refa47_inst, refa47_op in H. discriminate H. Qed.

Lemma refa47_not4073 : ~ @Equation4073 Fin2 refa47_inst.
Proof. unfold Equation4073. intro H. specialize (H F2_1 F2_0). unfold magma_op, refa47_inst, refa47_op in H. discriminate H. Qed.

Lemma refa47_not4074 : ~ @Equation4074 Fin2 refa47_inst.
Proof. unfold Equation4074. intro H. specialize (H F2_1 F2_0). unfold magma_op, refa47_inst, refa47_op in H. discriminate H. Qed.

Lemma refa47_not4080 : ~ @Equation4080 Fin2 refa47_inst.
Proof. unfold Equation4080. intro H. specialize (H F2_1 F2_0). unfold magma_op, refa47_inst, refa47_op in H. discriminate H. Qed.

Lemma refa47_not4081 : ~ @Equation4081 Fin2 refa47_inst.
Proof. unfold Equation4081. intro H. specialize (H F2_1 F2_0). unfold magma_op, refa47_inst, refa47_op in H. discriminate H. Qed.

Lemma refa47_not4083 : ~ @Equation4083 Fin2 refa47_inst.
Proof. unfold Equation4083. intro H. specialize (H F2_1 F2_0). unfold magma_op, refa47_inst, refa47_op in H. discriminate H. Qed.

Lemma refa47_not4084 : ~ @Equation4084 Fin2 refa47_inst.
Proof. unfold Equation4084. intro H. specialize (H F2_1 F2_0). unfold magma_op, refa47_inst, refa47_op in H. discriminate H. Qed.

Lemma refa47_not4090 : ~ @Equation4090 Fin2 refa47_inst.
Proof. unfold Equation4090. intro H. specialize (H F2_1 F2_0). unfold magma_op, refa47_inst, refa47_op in H. discriminate H. Qed.

Lemma refa47_not4091 : ~ @Equation4091 Fin2 refa47_inst.
Proof. unfold Equation4091. intro H. specialize (H F2_1 F2_0). unfold magma_op, refa47_inst, refa47_op in H. discriminate H. Qed.

Lemma refa47_not4093 : ~ @Equation4093 Fin2 refa47_inst.
Proof. unfold Equation4093. intro H. specialize (H F2_1 F2_0). unfold magma_op, refa47_inst, refa47_op in H. discriminate H. Qed.

Lemma refa47_not4268 : ~ @Equation4268 Fin2 refa47_inst.
Proof. unfold Equation4268. intro H. specialize (H F2_1 F2_0). unfold magma_op, refa47_inst, refa47_op in H. discriminate H. Qed.

Lemma refa47_not4269 : ~ @Equation4269 Fin2 refa47_inst.
Proof. unfold Equation4269. intro H. specialize (H F2_1 F2_0). unfold magma_op, refa47_inst, refa47_op in H. discriminate H. Qed.

Lemma refa47_not4270 : ~ @Equation4270 Fin2 refa47_inst.
Proof. unfold Equation4270. intro H. specialize (H F2_1 F2_0). unfold magma_op, refa47_inst, refa47_op in H. discriminate H. Qed.

Lemma refa47_not4272 : ~ @Equation4272 Fin2 refa47_inst.
Proof. unfold Equation4272. intro H. specialize (H F2_1 F2_0). unfold magma_op, refa47_inst, refa47_op in H. discriminate H. Qed.

Lemma refa47_not4273 : ~ @Equation4273 Fin2 refa47_inst.
Proof. unfold Equation4273. intro H. specialize (H F2_1 F2_0). unfold magma_op, refa47_inst, refa47_op in H. discriminate H. Qed.

Lemma refa47_not4275 : ~ @Equation4275 Fin2 refa47_inst.
Proof. unfold Equation4275. intro H. specialize (H F2_1 F2_0). unfold magma_op, refa47_inst, refa47_op in H. discriminate H. Qed.

Lemma refa47_not4276 : ~ @Equation4276 Fin2 refa47_inst.
Proof. unfold Equation4276. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa47_inst, refa47_op in H. discriminate H. Qed.

Lemma refa47_not4583 : ~ @Equation4583 Fin2 refa47_inst.
Proof. unfold Equation4583. intro H. specialize (H F2_1 F2_0). unfold magma_op, refa47_inst, refa47_op in H. discriminate H. Qed.

Lemma refa47_not4584 : ~ @Equation4584 Fin2 refa47_inst.
Proof. unfold Equation4584. intro H. specialize (H F2_1 F2_0). unfold magma_op, refa47_inst, refa47_op in H. discriminate H. Qed.

Lemma refa47_not4585 : ~ @Equation4585 Fin2 refa47_inst.
Proof. unfold Equation4585. intro H. specialize (H F2_1 F2_0). unfold magma_op, refa47_inst, refa47_op in H. discriminate H. Qed.

Lemma refa47_not4587 : ~ @Equation4587 Fin2 refa47_inst.
Proof. unfold Equation4587. intro H. specialize (H F2_1 F2_0). unfold magma_op, refa47_inst, refa47_op in H. discriminate H. Qed.

Lemma refa47_not4588 : ~ @Equation4588 Fin2 refa47_inst.
Proof. unfold Equation4588. intro H. specialize (H F2_1 F2_0). unfold magma_op, refa47_inst, refa47_op in H. discriminate H. Qed.

Lemma refa47_not4590 : ~ @Equation4590 Fin2 refa47_inst.
Proof. unfold Equation4590. intro H. specialize (H F2_1 F2_0). unfold magma_op, refa47_inst, refa47_op in H. discriminate H. Qed.

Lemma refa47_not4591 : ~ @Equation4591 Fin2 refa47_inst.
Proof. unfold Equation4591. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa47_inst, refa47_op in H. discriminate H. Qed.

(** ---- refa470 (Fin4) ---- *)

Definition refa470_op (x y : Fin4) : Fin4 :=
  match x, y with
  | F4_0, F4_0 => F4_0 | F4_0, F4_1 => F4_0 | F4_0, F4_2 => F4_0 | F4_0, F4_3 => F4_1
  | F4_1, F4_0 => F4_1 | F4_1, F4_1 => F4_1 | F4_1, F4_2 => F4_1 | F4_1, F4_3 => F4_2
  | F4_2, F4_0 => F4_2 | F4_2, F4_1 => F4_2 | F4_2, F4_2 => F4_0 | F4_2, F4_3 => F4_3
  | F4_3, F4_0 => F4_3 | F4_3, F4_1 => F4_3 | F4_3, F4_2 => F4_1 | F4_3, F4_3 => F4_0
  end.

#[local] Instance refa470_inst : Magma Fin4 := {| magma_op := refa470_op |}.

Lemma refa470_sat100 : @Equation100 Fin4 refa470_inst.
Proof. unfold Equation100, magma_op, refa470_inst, refa470_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa470_not1223 : ~ @Equation1223 Fin4 refa470_inst.
Proof. unfold Equation1223. intro H. specialize (H F4_3). unfold magma_op, refa470_inst, refa470_op in H. discriminate H. Qed.

(** ---- refa471 (Fin4) ---- *)

Definition refa471_op (x y : Fin4) : Fin4 :=
  match x, y with
  | F4_0, F4_0 => F4_3 | F4_0, F4_1 => F4_2 | F4_0, F4_2 => F4_2 | F4_0, F4_3 => F4_3
  | F4_1, F4_0 => F4_3 | F4_1, F4_1 => F4_3 | F4_1, F4_2 => F4_3 | F4_1, F4_3 => F4_3
  | F4_2, F4_0 => F4_2 | F4_2, F4_1 => F4_2 | F4_2, F4_2 => F4_2 | F4_2, F4_3 => F4_2
  | F4_3, F4_0 => F4_3 | F4_3, F4_1 => F4_3 | F4_3, F4_2 => F4_3 | F4_3, F4_3 => F4_3
  end.

#[local] Instance refa471_inst : Magma Fin4 := {| magma_op := refa471_op |}.

Lemma refa471_sat3919 : @Equation3919 Fin4 refa471_inst.
Proof. unfold Equation3919, magma_op, refa471_inst, refa471_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa471_not3316 : ~ @Equation3316 Fin4 refa471_inst.
Proof. unfold Equation3316. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa471_inst, refa471_op in H. discriminate H. Qed.

Lemma refa471_not3318 : ~ @Equation3318 Fin4 refa471_inst.
Proof. unfold Equation3318. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa471_inst, refa471_op in H. discriminate H. Qed.

Lemma refa471_not3319 : ~ @Equation3319 Fin4 refa471_inst.
Proof. unfold Equation3319. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa471_inst, refa471_op in H. discriminate H. Qed.

Lemma refa471_not3518 : ~ @Equation3518 Fin4 refa471_inst.
Proof. unfold Equation3518. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa471_inst, refa471_op in H. discriminate H. Qed.

Lemma refa471_not3519 : ~ @Equation3519 Fin4 refa471_inst.
Proof. unfold Equation3519. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa471_inst, refa471_op in H. discriminate H. Qed.

Lemma refa471_not3924 : ~ @Equation3924 Fin4 refa471_inst.
Proof. unfold Equation3924. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa471_inst, refa471_op in H. discriminate H. Qed.

Lemma refa471_not3925 : ~ @Equation3925 Fin4 refa471_inst.
Proof. unfold Equation3925. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa471_inst, refa471_op in H. discriminate H. Qed.

Lemma refa471_not3927 : ~ @Equation3927 Fin4 refa471_inst.
Proof. unfold Equation3927. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa471_inst, refa471_op in H. discriminate H. Qed.

Lemma refa471_not3928 : ~ @Equation3928 Fin4 refa471_inst.
Proof. unfold Equation3928. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa471_inst, refa471_op in H. discriminate H. Qed.

Lemma refa471_not4283 : ~ @Equation4283 Fin4 refa471_inst.
Proof. unfold Equation4283. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa471_inst, refa471_op in H. discriminate H. Qed.

Lemma refa471_not4284 : ~ @Equation4284 Fin4 refa471_inst.
Proof. unfold Equation4284. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa471_inst, refa471_op in H. discriminate H. Qed.

Lemma refa471_not4435 : ~ @Equation4435 Fin4 refa471_inst.
Proof. unfold Equation4435. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa471_inst, refa471_op in H. discriminate H. Qed.

Lemma refa471_not4436 : ~ @Equation4436 Fin4 refa471_inst.
Proof. unfold Equation4436. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa471_inst, refa471_op in H. discriminate H. Qed.

Lemma refa471_not4472 : ~ @Equation4472 Fin4 refa471_inst.
Proof. unfold Equation4472. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa471_inst, refa471_op in H. discriminate H. Qed.

Lemma refa471_not4473 : ~ @Equation4473 Fin4 refa471_inst.
Proof. unfold Equation4473. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa471_inst, refa471_op in H. discriminate H. Qed.

(** ---- refa472 (Fin4) ---- *)

Definition refa472_op (x y : Fin4) : Fin4 :=
  match x, y with
  | F4_0, F4_0 => F4_0 | F4_0, F4_1 => F4_1 | F4_0, F4_2 => F4_2 | F4_0, F4_3 => F4_3
  | F4_1, F4_0 => F4_0 | F4_1, F4_1 => F4_1 | F4_1, F4_2 => F4_2 | F4_1, F4_3 => F4_3
  | F4_2, F4_0 => F4_0 | F4_2, F4_1 => F4_1 | F4_2, F4_2 => F4_2 | F4_2, F4_3 => F4_3
  | F4_3, F4_0 => F4_1 | F4_3, F4_1 => F4_2 | F4_3, F4_2 => F4_0 | F4_3, F4_3 => F4_3
  end.

#[local] Instance refa472_inst : Magma Fin4 := {| magma_op := refa472_op |}.

Lemma refa472_sat476 : @Equation476 Fin4 refa472_inst.
Proof. unfold Equation476, magma_op, refa472_inst, refa472_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa472_sat503 : @Equation503 Fin4 refa472_inst.
Proof. unfold Equation503, magma_op, refa472_inst, refa472_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa472_sat964 : @Equation964 Fin4 refa472_inst.
Proof. unfold Equation964, magma_op, refa472_inst, refa472_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa472_sat3566 : @Equation3566 Fin4 refa472_inst.
Proof. unfold Equation3566, magma_op, refa472_inst, refa472_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa472_sat3790 : @Equation3790 Fin4 refa472_inst.
Proof. unfold Equation3790, magma_op, refa472_inst, refa472_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa472_not55 : ~ @Equation55 Fin4 refa472_inst.
Proof. unfold Equation55. intro H. specialize (H F4_0 F4_3). unfold magma_op, refa472_inst, refa472_op in H. discriminate H. Qed.

Lemma refa472_not65 : ~ @Equation65 Fin4 refa472_inst.
Proof. unfold Equation65. intro H. specialize (H F4_0 F4_3). unfold magma_op, refa472_inst, refa472_op in H. discriminate H. Qed.

Lemma refa472_not616 : ~ @Equation616 Fin4 refa472_inst.
Proof. unfold Equation616. intro H. specialize (H F4_0 F4_3). unfold magma_op, refa472_inst, refa472_op in H. discriminate H. Qed.

Lemma refa472_not622 : ~ @Equation622 Fin4 refa472_inst.
Proof. unfold Equation622. intro H. specialize (H F4_0 F4_3). unfold magma_op, refa472_inst, refa472_op in H. discriminate H. Qed.

Lemma refa472_not629 : ~ @Equation629 Fin4 refa472_inst.
Proof. unfold Equation629. intro H. specialize (H F4_0 F4_3). unfold magma_op, refa472_inst, refa472_op in H. discriminate H. Qed.

Lemma refa472_not632 : ~ @Equation632 Fin4 refa472_inst.
Proof. unfold Equation632. intro H. specialize (H F4_0 F4_3). unfold magma_op, refa472_inst, refa472_op in H. discriminate H. Qed.

Lemma refa472_not639 : ~ @Equation639 Fin4 refa472_inst.
Proof. unfold Equation639. intro H. specialize (H F4_0 F4_3). unfold magma_op, refa472_inst, refa472_op in H. discriminate H. Qed.

Lemma refa472_not642 : ~ @Equation642 Fin4 refa472_inst.
Proof. unfold Equation642. intro H. specialize (H F4_0 F4_3). unfold magma_op, refa472_inst, refa472_op in H. discriminate H. Qed.

Lemma refa472_not669 : ~ @Equation669 Fin4 refa472_inst.
Proof. unfold Equation669. intro H. specialize (H F4_0 F4_3). unfold magma_op, refa472_inst, refa472_op in H. discriminate H. Qed.

Lemma refa472_not676 : ~ @Equation676 Fin4 refa472_inst.
Proof. unfold Equation676. intro H. specialize (H F4_0 F4_3). unfold magma_op, refa472_inst, refa472_op in H. discriminate H. Qed.

Lemma refa472_not679 : ~ @Equation679 Fin4 refa472_inst.
Proof. unfold Equation679. intro H. specialize (H F4_0 F4_3). unfold magma_op, refa472_inst, refa472_op in H. discriminate H. Qed.

Lemma refa472_not713 : ~ @Equation713 Fin4 refa472_inst.
Proof. unfold Equation713. intro H. specialize (H F4_0 F4_3). unfold magma_op, refa472_inst, refa472_op in H. discriminate H. Qed.

Lemma refa472_not819 : ~ @Equation819 Fin4 refa472_inst.
Proof. unfold Equation819. intro H. specialize (H F4_0 F4_3). unfold magma_op, refa472_inst, refa472_op in H. discriminate H. Qed.

Lemma refa472_not822 : ~ @Equation822 Fin4 refa472_inst.
Proof. unfold Equation822. intro H. specialize (H F4_0 F4_3). unfold magma_op, refa472_inst, refa472_op in H. discriminate H. Qed.

Lemma refa472_not825 : ~ @Equation825 Fin4 refa472_inst.
Proof. unfold Equation825. intro H. specialize (H F4_0 F4_3). unfold magma_op, refa472_inst, refa472_op in H. discriminate H. Qed.

Lemma refa472_not835 : ~ @Equation835 Fin4 refa472_inst.
Proof. unfold Equation835. intro H. specialize (H F4_0 F4_3). unfold magma_op, refa472_inst, refa472_op in H. discriminate H. Qed.

Lemma refa472_not842 : ~ @Equation842 Fin4 refa472_inst.
Proof. unfold Equation842. intro H. specialize (H F4_0 F4_3). unfold magma_op, refa472_inst, refa472_op in H. discriminate H. Qed.

Lemma refa472_not845 : ~ @Equation845 Fin4 refa472_inst.
Proof. unfold Equation845. intro H. specialize (H F4_0 F4_3). unfold magma_op, refa472_inst, refa472_op in H. discriminate H. Qed.

Lemma refa472_not872 : ~ @Equation872 Fin4 refa472_inst.
Proof. unfold Equation872. intro H. specialize (H F4_0 F4_3). unfold magma_op, refa472_inst, refa472_op in H. discriminate H. Qed.

Lemma refa472_not879 : ~ @Equation879 Fin4 refa472_inst.
Proof. unfold Equation879. intro H. specialize (H F4_0 F4_3). unfold magma_op, refa472_inst, refa472_op in H. discriminate H. Qed.

Lemma refa472_not906 : ~ @Equation906 Fin4 refa472_inst.
Proof. unfold Equation906. intro H. specialize (H F4_0 F4_3). unfold magma_op, refa472_inst, refa472_op in H. discriminate H. Qed.

Lemma refa472_not1428 : ~ @Equation1428 Fin4 refa472_inst.
Proof. unfold Equation1428. intro H. specialize (H F4_0 F4_3). unfold magma_op, refa472_inst, refa472_op in H. discriminate H. Qed.

Lemma refa472_not1431 : ~ @Equation1431 Fin4 refa472_inst.
Proof. unfold Equation1431. intro H. specialize (H F4_0 F4_3). unfold magma_op, refa472_inst, refa472_op in H. discriminate H. Qed.

Lemma refa472_not1434 : ~ @Equation1434 Fin4 refa472_inst.
Proof. unfold Equation1434. intro H. specialize (H F4_0 F4_3). unfold magma_op, refa472_inst, refa472_op in H. discriminate H. Qed.

Lemma refa472_not1441 : ~ @Equation1441 Fin4 refa472_inst.
Proof. unfold Equation1441. intro H. specialize (H F4_0 F4_3). unfold magma_op, refa472_inst, refa472_op in H. discriminate H. Qed.

Lemma refa472_not1444 : ~ @Equation1444 Fin4 refa472_inst.
Proof. unfold Equation1444. intro H. specialize (H F4_0 F4_3). unfold magma_op, refa472_inst, refa472_op in H. discriminate H. Qed.

Lemma refa472_not1451 : ~ @Equation1451 Fin4 refa472_inst.
Proof. unfold Equation1451. intro H. specialize (H F4_0 F4_3). unfold magma_op, refa472_inst, refa472_op in H. discriminate H. Qed.

Lemma refa472_not1488 : ~ @Equation1488 Fin4 refa472_inst.
Proof. unfold Equation1488. intro H. specialize (H F4_0 F4_3). unfold magma_op, refa472_inst, refa472_op in H. discriminate H. Qed.

Lemma refa472_not1491 : ~ @Equation1491 Fin4 refa472_inst.
Proof. unfold Equation1491. intro H. specialize (H F4_0 F4_3). unfold magma_op, refa472_inst, refa472_op in H. discriminate H. Qed.

Lemma refa472_not1515 : ~ @Equation1515 Fin4 refa472_inst.
Proof. unfold Equation1515. intro H. specialize (H F4_0 F4_3). unfold magma_op, refa472_inst, refa472_op in H. discriminate H. Qed.

Lemma refa472_not1518 : ~ @Equation1518 Fin4 refa472_inst.
Proof. unfold Equation1518. intro H. specialize (H F4_0 F4_3). unfold magma_op, refa472_inst, refa472_op in H. discriminate H. Qed.

Lemma refa472_not1525 : ~ @Equation1525 Fin4 refa472_inst.
Proof. unfold Equation1525. intro H. specialize (H F4_0 F4_3). unfold magma_op, refa472_inst, refa472_op in H. discriminate H. Qed.

Lemma refa472_not3306 : ~ @Equation3306 Fin4 refa472_inst.
Proof. unfold Equation3306. intro H. specialize (H F4_3 F4_0). unfold magma_op, refa472_inst, refa472_op in H. discriminate H. Qed.

Lemma refa472_not3864 : ~ @Equation3864 Fin4 refa472_inst.
Proof. unfold Equation3864. intro H. specialize (H F4_0 F4_3). unfold magma_op, refa472_inst, refa472_op in H. discriminate H. Qed.

Lemma refa472_not3870 : ~ @Equation3870 Fin4 refa472_inst.
Proof. unfold Equation3870. intro H. specialize (H F4_0 F4_3). unfold magma_op, refa472_inst, refa472_op in H. discriminate H. Qed.

Lemma refa472_not3880 : ~ @Equation3880 Fin4 refa472_inst.
Proof. unfold Equation3880. intro H. specialize (H F4_0 F4_3). unfold magma_op, refa472_inst, refa472_op in H. discriminate H. Qed.

Lemma refa472_not3890 : ~ @Equation3890 Fin4 refa472_inst.
Proof. unfold Equation3890. intro H. specialize (H F4_0 F4_3). unfold magma_op, refa472_inst, refa472_op in H. discriminate H. Qed.

Lemma refa472_not3918 : ~ @Equation3918 Fin4 refa472_inst.
Proof. unfold Equation3918. intro H. specialize (H F4_3 F4_0). unfold magma_op, refa472_inst, refa472_op in H. discriminate H. Qed.

Lemma refa472_not3928 : ~ @Equation3928 Fin4 refa472_inst.
Proof. unfold Equation3928. intro H. specialize (H F4_3 F4_0). unfold magma_op, refa472_inst, refa472_op in H. discriminate H. Qed.

Lemma refa472_not3955 : ~ @Equation3955 Fin4 refa472_inst.
Proof. unfold Equation3955. intro H. specialize (H F4_3 F4_0). unfold magma_op, refa472_inst, refa472_op in H. discriminate H. Qed.

Lemma refa472_not4067 : ~ @Equation4067 Fin4 refa472_inst.
Proof. unfold Equation4067. intro H. specialize (H F4_0 F4_3). unfold magma_op, refa472_inst, refa472_op in H. discriminate H. Qed.

Lemma refa472_not4073 : ~ @Equation4073 Fin4 refa472_inst.
Proof. unfold Equation4073. intro H. specialize (H F4_0 F4_3). unfold magma_op, refa472_inst, refa472_op in H. discriminate H. Qed.

Lemma refa472_not4083 : ~ @Equation4083 Fin4 refa472_inst.
Proof. unfold Equation4083. intro H. specialize (H F4_0 F4_3). unfold magma_op, refa472_inst, refa472_op in H. discriminate H. Qed.

Lemma refa472_not4093 : ~ @Equation4093 Fin4 refa472_inst.
Proof. unfold Equation4093. intro H. specialize (H F4_0 F4_3). unfold magma_op, refa472_inst, refa472_op in H. discriminate H. Qed.

Lemma refa472_not4121 : ~ @Equation4121 Fin4 refa472_inst.
Proof. unfold Equation4121. intro H. specialize (H F4_3 F4_0). unfold magma_op, refa472_inst, refa472_op in H. discriminate H. Qed.

Lemma refa472_not4131 : ~ @Equation4131 Fin4 refa472_inst.
Proof. unfold Equation4131. intro H. specialize (H F4_3 F4_0). unfold magma_op, refa472_inst, refa472_op in H. discriminate H. Qed.

Lemma refa472_not4158 : ~ @Equation4158 Fin4 refa472_inst.
Proof. unfold Equation4158. intro H. specialize (H F4_3 F4_0). unfold magma_op, refa472_inst, refa472_op in H. discriminate H. Qed.

Lemma refa472_not4269 : ~ @Equation4269 Fin4 refa472_inst.
Proof. unfold Equation4269. intro H. specialize (H F4_0 F4_3). unfold magma_op, refa472_inst, refa472_op in H. discriminate H. Qed.

Lemma refa472_not4272 : ~ @Equation4272 Fin4 refa472_inst.
Proof. unfold Equation4272. intro H. specialize (H F4_0 F4_3). unfold magma_op, refa472_inst, refa472_op in H. discriminate H. Qed.

Lemma refa472_not4275 : ~ @Equation4275 Fin4 refa472_inst.
Proof. unfold Equation4275. intro H. specialize (H F4_0 F4_3). unfold magma_op, refa472_inst, refa472_op in H. discriminate H. Qed.

Lemma refa472_not4284 : ~ @Equation4284 Fin4 refa472_inst.
Proof. unfold Equation4284. intro H. specialize (H F4_3 F4_0). unfold magma_op, refa472_inst, refa472_op in H. discriminate H. Qed.

Lemma refa472_not4291 : ~ @Equation4291 Fin4 refa472_inst.
Proof. unfold Equation4291. intro H. specialize (H F4_3 F4_0). unfold magma_op, refa472_inst, refa472_op in H. discriminate H. Qed.

Lemma refa472_not4599 : ~ @Equation4599 Fin4 refa472_inst.
Proof. unfold Equation4599. intro H. specialize (H F4_3 F4_0). unfold magma_op, refa472_inst, refa472_op in H. discriminate H. Qed.

Lemma refa472_not4622 : ~ @Equation4622 Fin4 refa472_inst.
Proof. unfold Equation4622. intro H. specialize (H F4_0 F4_0 F4_3). unfold magma_op, refa472_inst, refa472_op in H. discriminate H. Qed.

Lemma refa472_not4631 : ~ @Equation4631 Fin4 refa472_inst.
Proof. unfold Equation4631. intro H. specialize (H F4_0 F4_0 F4_3). unfold magma_op, refa472_inst, refa472_op in H. discriminate H. Qed.

Lemma refa472_not4635 : ~ @Equation4635 Fin4 refa472_inst.
Proof. unfold Equation4635. intro H. specialize (H F4_0 F4_3). unfold magma_op, refa472_inst, refa472_op in H. discriminate H. Qed.

(** ---- refa473 (Fin4) ---- *)

Definition refa473_op (x y : Fin4) : Fin4 :=
  match x, y with
  | F4_0, F4_0 => F4_0 | F4_0, F4_1 => F4_0 | F4_0, F4_2 => F4_2 | F4_0, F4_3 => F4_3
  | F4_1, F4_0 => F4_2 | F4_1, F4_1 => F4_2 | F4_1, F4_2 => F4_2 | F4_1, F4_3 => F4_0
  | F4_2, F4_0 => F4_0 | F4_2, F4_1 => F4_1 | F4_2, F4_2 => F4_2 | F4_2, F4_3 => F4_3
  | F4_3, F4_0 => F4_1 | F4_3, F4_1 => F4_2 | F4_3, F4_2 => F4_2 | F4_3, F4_3 => F4_1
  end.

#[local] Instance refa473_inst : Magma Fin4 := {| magma_op := refa473_op |}.

Lemma refa473_sat2736 : @Equation2736 Fin4 refa473_inst.
Proof. unfold Equation2736, magma_op, refa473_inst, refa473_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa473_not2441 : ~ @Equation2441 Fin4 refa473_inst.
Proof. unfold Equation2441. intro H. specialize (H F4_3). unfold magma_op, refa473_inst, refa473_op in H. discriminate H. Qed.

(** ---- refa474 (Fin4) ---- *)

Definition refa474_op (x y : Fin4) : Fin4 :=
  match x, y with
  | F4_0, F4_0 => F4_3 | F4_0, F4_1 => F4_1 | F4_0, F4_2 => F4_0 | F4_0, F4_3 => F4_1
  | F4_1, F4_0 => F4_2 | F4_1, F4_1 => F4_1 | F4_1, F4_2 => F4_0 | F4_1, F4_3 => F4_1
  | F4_2, F4_0 => F4_2 | F4_2, F4_1 => F4_1 | F4_2, F4_2 => F4_1 | F4_2, F4_3 => F4_1
  | F4_3, F4_0 => F4_2 | F4_3, F4_1 => F4_3 | F4_3, F4_2 => F4_0 | F4_3, F4_3 => F4_3
  end.

#[local] Instance refa474_inst : Magma Fin4 := {| magma_op := refa474_op |}.

Lemma refa474_sat1041 : @Equation1041 Fin4 refa474_inst.
Proof. unfold Equation1041, magma_op, refa474_inst, refa474_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa474_not3253 : ~ @Equation3253 Fin4 refa474_inst.
Proof. unfold Equation3253. intro H. specialize (H F4_0). unfold magma_op, refa474_inst, refa474_op in H. discriminate H. Qed.

(** ---- refa475 (Fin4) ---- *)

Definition refa475_op (x y : Fin4) : Fin4 :=
  match x, y with
  | F4_0, F4_0 => F4_3 | F4_0, F4_1 => F4_2 | F4_0, F4_2 => F4_0 | F4_0, F4_3 => F4_1
  | F4_1, F4_0 => F4_2 | F4_1, F4_1 => F4_0 | F4_1, F4_2 => F4_3 | F4_1, F4_3 => F4_1
  | F4_2, F4_0 => F4_2 | F4_2, F4_1 => F4_3 | F4_2, F4_2 => F4_1 | F4_2, F4_3 => F4_0
  | F4_3, F4_0 => F4_1 | F4_3, F4_1 => F4_3 | F4_3, F4_2 => F4_0 | F4_3, F4_3 => F4_2
  end.

#[local] Instance refa475_inst : Magma Fin4 := {| magma_op := refa475_op |}.

Lemma refa475_sat670 : @Equation670 Fin4 refa475_inst.
Proof. unfold Equation670, magma_op, refa475_inst, refa475_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa475_sat1238 : @Equation1238 Fin4 refa475_inst.
Proof. unfold Equation1238, magma_op, refa475_inst, refa475_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa475_sat1278 : @Equation1278 Fin4 refa475_inst.
Proof. unfold Equation1278, magma_op, refa475_inst, refa475_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa475_sat1288 : @Equation1288 Fin4 refa475_inst.
Proof. unfold Equation1288, magma_op, refa475_inst, refa475_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa475_not47 : ~ @Equation47 Fin4 refa475_inst.
Proof. unfold Equation47. intro H. specialize (H F4_0). unfold magma_op, refa475_inst, refa475_op in H. discriminate H. Qed.

Lemma refa475_not99 : ~ @Equation99 Fin4 refa475_inst.
Proof. unfold Equation99. intro H. specialize (H F4_0). unfold magma_op, refa475_inst, refa475_op in H. discriminate H. Qed.

Lemma refa475_not151 : ~ @Equation151 Fin4 refa475_inst.
Proof. unfold Equation151. intro H. specialize (H F4_0). unfold magma_op, refa475_inst, refa475_op in H. discriminate H. Qed.

Lemma refa475_not203 : ~ @Equation203 Fin4 refa475_inst.
Proof. unfold Equation203. intro H. specialize (H F4_0). unfold magma_op, refa475_inst, refa475_op in H. discriminate H. Qed.

Lemma refa475_not255 : ~ @Equation255 Fin4 refa475_inst.
Proof. unfold Equation255. intro H. specialize (H F4_0). unfold magma_op, refa475_inst, refa475_op in H. discriminate H. Qed.

Lemma refa475_not413 : ~ @Equation413 Fin4 refa475_inst.
Proof. unfold Equation413. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa475_inst, refa475_op in H. discriminate H. Qed.

Lemma refa475_not416 : ~ @Equation416 Fin4 refa475_inst.
Proof. unfold Equation416. intro H. specialize (H F4_0 F4_2). unfold magma_op, refa475_inst, refa475_op in H. discriminate H. Qed.

Lemma refa475_not417 : ~ @Equation417 Fin4 refa475_inst.
Proof. unfold Equation417. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa475_inst, refa475_op in H. discriminate H. Qed.

Lemma refa475_not419 : ~ @Equation419 Fin4 refa475_inst.
Proof. unfold Equation419. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa475_inst, refa475_op in H. discriminate H. Qed.

Lemma refa475_not420 : ~ @Equation420 Fin4 refa475_inst.
Proof. unfold Equation420. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa475_inst, refa475_op in H. discriminate H. Qed.

Lemma refa475_not426 : ~ @Equation426 Fin4 refa475_inst.
Proof. unfold Equation426. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa475_inst, refa475_op in H. discriminate H. Qed.

Lemma refa475_not427 : ~ @Equation427 Fin4 refa475_inst.
Proof. unfold Equation427. intro H. specialize (H F4_0 F4_2). unfold magma_op, refa475_inst, refa475_op in H. discriminate H. Qed.

Lemma refa475_not429 : ~ @Equation429 Fin4 refa475_inst.
Proof. unfold Equation429. intro H. specialize (H F4_0 F4_3). unfold magma_op, refa475_inst, refa475_op in H. discriminate H. Qed.

Lemma refa475_not436 : ~ @Equation436 Fin4 refa475_inst.
Proof. unfold Equation436. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa475_inst, refa475_op in H. discriminate H. Qed.

Lemma refa475_not437 : ~ @Equation437 Fin4 refa475_inst.
Proof. unfold Equation437. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa475_inst, refa475_op in H. discriminate H. Qed.

Lemma refa475_not440 : ~ @Equation440 Fin4 refa475_inst.
Proof. unfold Equation440. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa475_inst, refa475_op in H. discriminate H. Qed.

Lemma refa475_not466 : ~ @Equation466 Fin4 refa475_inst.
Proof. unfold Equation466. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa475_inst, refa475_op in H. discriminate H. Qed.

Lemma refa475_not467 : ~ @Equation467 Fin4 refa475_inst.
Proof. unfold Equation467. intro H. specialize (H F4_0 F4_2). unfold magma_op, refa475_inst, refa475_op in H. discriminate H. Qed.

Lemma refa475_not473 : ~ @Equation473 Fin4 refa475_inst.
Proof. unfold Equation473. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa475_inst, refa475_op in H. discriminate H. Qed.

Lemma refa475_not476 : ~ @Equation476 Fin4 refa475_inst.
Proof. unfold Equation476. intro H. specialize (H F4_0 F4_2). unfold magma_op, refa475_inst, refa475_op in H. discriminate H. Qed.

Lemma refa475_not477 : ~ @Equation477 Fin4 refa475_inst.
Proof. unfold Equation477. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa475_inst, refa475_op in H. discriminate H. Qed.

Lemma refa475_not501 : ~ @Equation501 Fin4 refa475_inst.
Proof. unfold Equation501. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa475_inst, refa475_op in H. discriminate H. Qed.

Lemma refa475_not503 : ~ @Equation503 Fin4 refa475_inst.
Proof. unfold Equation503. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa475_inst, refa475_op in H. discriminate H. Qed.

Lemma refa475_not504 : ~ @Equation504 Fin4 refa475_inst.
Proof. unfold Equation504. intro H. specialize (H F4_0 F4_2). unfold magma_op, refa475_inst, refa475_op in H. discriminate H. Qed.

Lemma refa475_not511 : ~ @Equation511 Fin4 refa475_inst.
Proof. unfold Equation511. intro H. specialize (H F4_0 F4_2). unfold magma_op, refa475_inst, refa475_op in H. discriminate H. Qed.

Lemma refa475_not677 : ~ @Equation677 Fin4 refa475_inst.
Proof. unfold Equation677. intro H. specialize (H F4_0 F4_2). unfold magma_op, refa475_inst, refa475_op in H. discriminate H. Qed.

Lemma refa475_not1112 : ~ @Equation1112 Fin4 refa475_inst.
Proof. unfold Equation1112. intro H. specialize (H F4_0 F4_2). unfold magma_op, refa475_inst, refa475_op in H. discriminate H. Qed.

Lemma refa475_not1241 : ~ @Equation1241 Fin4 refa475_inst.
Proof. unfold Equation1241. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa475_inst, refa475_op in H. discriminate H. Qed.

Lemma refa475_not1248 : ~ @Equation1248 Fin4 refa475_inst.
Proof. unfold Equation1248. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa475_inst, refa475_op in H. discriminate H. Qed.

Lemma refa475_not1251 : ~ @Equation1251 Fin4 refa475_inst.
Proof. unfold Equation1251. intro H. specialize (H F4_0 F4_2). unfold magma_op, refa475_inst, refa475_op in H. discriminate H. Qed.

Lemma refa475_not1315 : ~ @Equation1315 Fin4 refa475_inst.
Proof. unfold Equation1315. intro H. specialize (H F4_0 F4_2). unfold magma_op, refa475_inst, refa475_op in H. discriminate H. Qed.

Lemma refa475_not1426 : ~ @Equation1426 Fin4 refa475_inst.
Proof. unfold Equation1426. intro H. specialize (H F4_0). unfold magma_op, refa475_inst, refa475_op in H. discriminate H. Qed.

Lemma refa475_not1629 : ~ @Equation1629 Fin4 refa475_inst.
Proof. unfold Equation1629. intro H. specialize (H F4_0). unfold magma_op, refa475_inst, refa475_op in H. discriminate H. Qed.

Lemma refa475_not1832 : ~ @Equation1832 Fin4 refa475_inst.
Proof. unfold Equation1832. intro H. specialize (H F4_0). unfold magma_op, refa475_inst, refa475_op in H. discriminate H. Qed.

Lemma refa475_not2035 : ~ @Equation2035 Fin4 refa475_inst.
Proof. unfold Equation2035. intro H. specialize (H F4_0). unfold magma_op, refa475_inst, refa475_op in H. discriminate H. Qed.

Lemma refa475_not2238 : ~ @Equation2238 Fin4 refa475_inst.
Proof. unfold Equation2238. intro H. specialize (H F4_0). unfold magma_op, refa475_inst, refa475_op in H. discriminate H. Qed.

Lemma refa475_not2441 : ~ @Equation2441 Fin4 refa475_inst.
Proof. unfold Equation2441. intro H. specialize (H F4_0). unfold magma_op, refa475_inst, refa475_op in H. discriminate H. Qed.

Lemma refa475_not2644 : ~ @Equation2644 Fin4 refa475_inst.
Proof. unfold Equation2644. intro H. specialize (H F4_0). unfold magma_op, refa475_inst, refa475_op in H. discriminate H. Qed.

Lemma refa475_not2847 : ~ @Equation2847 Fin4 refa475_inst.
Proof. unfold Equation2847. intro H. specialize (H F4_0). unfold magma_op, refa475_inst, refa475_op in H. discriminate H. Qed.

Lemma refa475_not3050 : ~ @Equation3050 Fin4 refa475_inst.
Proof. unfold Equation3050. intro H. specialize (H F4_0). unfold magma_op, refa475_inst, refa475_op in H. discriminate H. Qed.

Lemma refa475_not3253 : ~ @Equation3253 Fin4 refa475_inst.
Proof. unfold Equation3253. intro H. specialize (H F4_0). unfold magma_op, refa475_inst, refa475_op in H. discriminate H. Qed.

Lemma refa475_not3456 : ~ @Equation3456 Fin4 refa475_inst.
Proof. unfold Equation3456. intro H. specialize (H F4_0). unfold magma_op, refa475_inst, refa475_op in H. discriminate H. Qed.

Lemma refa475_not3659 : ~ @Equation3659 Fin4 refa475_inst.
Proof. unfold Equation3659. intro H. specialize (H F4_0). unfold magma_op, refa475_inst, refa475_op in H. discriminate H. Qed.

Lemma refa475_not3862 : ~ @Equation3862 Fin4 refa475_inst.
Proof. unfold Equation3862. intro H. specialize (H F4_0). unfold magma_op, refa475_inst, refa475_op in H. discriminate H. Qed.

Lemma refa475_not4065 : ~ @Equation4065 Fin4 refa475_inst.
Proof. unfold Equation4065. intro H. specialize (H F4_0). unfold magma_op, refa475_inst, refa475_op in H. discriminate H. Qed.

Lemma refa475_not4283 : ~ @Equation4283 Fin4 refa475_inst.
Proof. unfold Equation4283. intro H. specialize (H F4_0 F4_2). unfold magma_op, refa475_inst, refa475_op in H. discriminate H. Qed.

Lemma refa475_not4343 : ~ @Equation4343 Fin4 refa475_inst.
Proof. unfold Equation4343. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa475_inst, refa475_op in H. discriminate H. Qed.

Lemma refa475_not4398 : ~ @Equation4398 Fin4 refa475_inst.
Proof. unfold Equation4398. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa475_inst, refa475_op in H. discriminate H. Qed.

Lemma refa475_not4405 : ~ @Equation4405 Fin4 refa475_inst.
Proof. unfold Equation4405. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa475_inst, refa475_op in H. discriminate H. Qed.

Lemma refa475_not4435 : ~ @Equation4435 Fin4 refa475_inst.
Proof. unfold Equation4435. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa475_inst, refa475_op in H. discriminate H. Qed.

Lemma refa475_not4442 : ~ @Equation4442 Fin4 refa475_inst.
Proof. unfold Equation4442. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa475_inst, refa475_op in H. discriminate H. Qed.

Lemma refa475_not4470 : ~ @Equation4470 Fin4 refa475_inst.
Proof. unfold Equation4470. intro H. specialize (H F4_0 F4_2). unfold magma_op, refa475_inst, refa475_op in H. discriminate H. Qed.

Lemma refa475_not4482 : ~ @Equation4482 Fin4 refa475_inst.
Proof. unfold Equation4482. intro H. specialize (H F4_0 F4_3). unfold magma_op, refa475_inst, refa475_op in H. discriminate H. Qed.

Lemma refa475_not4608 : ~ @Equation4608 Fin4 refa475_inst.
Proof. unfold Equation4608. intro H. specialize (H F4_0 F4_2). unfold magma_op, refa475_inst, refa475_op in H. discriminate H. Qed.

Lemma refa475_not4635 : ~ @Equation4635 Fin4 refa475_inst.
Proof. unfold Equation4635. intro H. specialize (H F4_0 F4_2). unfold magma_op, refa475_inst, refa475_op in H. discriminate H. Qed.

(** ---- refa476 (Fin4) ---- *)

Definition refa476_op (x y : Fin4) : Fin4 :=
  match x, y with
  | F4_0, F4_0 => F4_0 | F4_0, F4_1 => F4_0 | F4_0, F4_2 => F4_0 | F4_0, F4_3 => F4_1
  | F4_1, F4_0 => F4_1 | F4_1, F4_1 => F4_2 | F4_1, F4_2 => F4_0 | F4_1, F4_3 => F4_1
  | F4_2, F4_0 => F4_2 | F4_2, F4_1 => F4_2 | F4_2, F4_2 => F4_3 | F4_2, F4_3 => F4_0
  | F4_3, F4_0 => F4_3 | F4_3, F4_1 => F4_0 | F4_3, F4_2 => F4_3 | F4_3, F4_3 => F4_1
  end.

#[local] Instance refa476_inst : Magma Fin4 := {| magma_op := refa476_op |}.

Lemma refa476_sat630 : @Equation630 Fin4 refa476_inst.
Proof. unfold Equation630, magma_op, refa476_inst, refa476_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa476_sat640 : @Equation640 Fin4 refa476_inst.
Proof. unfold Equation640, magma_op, refa476_inst, refa476_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa476_not55 : ~ @Equation55 Fin4 refa476_inst.
Proof. unfold Equation55. intro H. specialize (H F4_0 F4_2). unfold magma_op, refa476_inst, refa476_op in H. discriminate H. Qed.

Lemma refa476_not99 : ~ @Equation99 Fin4 refa476_inst.
Proof. unfold Equation99. intro H. specialize (H F4_1). unfold magma_op, refa476_inst, refa476_op in H. discriminate H. Qed.

Lemma refa476_not151 : ~ @Equation151 Fin4 refa476_inst.
Proof. unfold Equation151. intro H. specialize (H F4_1). unfold magma_op, refa476_inst, refa476_op in H. discriminate H. Qed.

Lemma refa476_not203 : ~ @Equation203 Fin4 refa476_inst.
Proof. unfold Equation203. intro H. specialize (H F4_1). unfold magma_op, refa476_inst, refa476_op in H. discriminate H. Qed.

Lemma refa476_not255 : ~ @Equation255 Fin4 refa476_inst.
Proof. unfold Equation255. intro H. specialize (H F4_1). unfold magma_op, refa476_inst, refa476_op in H. discriminate H. Qed.

Lemma refa476_not411 : ~ @Equation411 Fin4 refa476_inst.
Proof. unfold Equation411. intro H. specialize (H F4_1). unfold magma_op, refa476_inst, refa476_op in H. discriminate H. Qed.

Lemma refa476_not615 : ~ @Equation615 Fin4 refa476_inst.
Proof. unfold Equation615. intro H. specialize (H F4_1 F4_2). unfold magma_op, refa476_inst, refa476_op in H. discriminate H. Qed.

Lemma refa476_not616 : ~ @Equation616 Fin4 refa476_inst.
Proof. unfold Equation616. intro H. specialize (H F4_1 F4_2). unfold magma_op, refa476_inst, refa476_op in H. discriminate H. Qed.

Lemma refa476_not619 : ~ @Equation619 Fin4 refa476_inst.
Proof. unfold Equation619. intro H. specialize (H F4_1 F4_0). unfold magma_op, refa476_inst, refa476_op in H. discriminate H. Qed.

Lemma refa476_not620 : ~ @Equation620 Fin4 refa476_inst.
Proof. unfold Equation620. intro H. specialize (H F4_1 F4_0). unfold magma_op, refa476_inst, refa476_op in H. discriminate H. Qed.

Lemma refa476_not622 : ~ @Equation622 Fin4 refa476_inst.
Proof. unfold Equation622. intro H. specialize (H F4_1 F4_0). unfold magma_op, refa476_inst, refa476_op in H. discriminate H. Qed.

Lemma refa476_not623 : ~ @Equation623 Fin4 refa476_inst.
Proof. unfold Equation623. intro H. specialize (H F4_1 F4_0). unfold magma_op, refa476_inst, refa476_op in H. discriminate H. Qed.

Lemma refa476_not629 : ~ @Equation629 Fin4 refa476_inst.
Proof. unfold Equation629. intro H. specialize (H F4_0 F4_3). unfold magma_op, refa476_inst, refa476_op in H. discriminate H. Qed.

Lemma refa476_not632 : ~ @Equation632 Fin4 refa476_inst.
Proof. unfold Equation632. intro H. specialize (H F4_1 F4_2). unfold magma_op, refa476_inst, refa476_op in H. discriminate H. Qed.

Lemma refa476_not633 : ~ @Equation633 Fin4 refa476_inst.
Proof. unfold Equation633. intro H. specialize (H F4_1 F4_2). unfold magma_op, refa476_inst, refa476_op in H. discriminate H. Qed.

Lemma refa476_not639 : ~ @Equation639 Fin4 refa476_inst.
Proof. unfold Equation639. intro H. specialize (H F4_0 F4_2). unfold magma_op, refa476_inst, refa476_op in H. discriminate H. Qed.

Lemma refa476_not642 : ~ @Equation642 Fin4 refa476_inst.
Proof. unfold Equation642. intro H. specialize (H F4_1 F4_2). unfold magma_op, refa476_inst, refa476_op in H. discriminate H. Qed.

Lemma refa476_not669 : ~ @Equation669 Fin4 refa476_inst.
Proof. unfold Equation669. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa476_inst, refa476_op in H. discriminate H. Qed.

Lemma refa476_not676 : ~ @Equation676 Fin4 refa476_inst.
Proof. unfold Equation676. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa476_inst, refa476_op in H. discriminate H. Qed.

Lemma refa476_not680 : ~ @Equation680 Fin4 refa476_inst.
Proof. unfold Equation680. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa476_inst, refa476_op in H. discriminate H. Qed.

Lemma refa476_not707 : ~ @Equation707 Fin4 refa476_inst.
Proof. unfold Equation707. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa476_inst, refa476_op in H. discriminate H. Qed.

Lemma refa476_not819 : ~ @Equation819 Fin4 refa476_inst.
Proof. unfold Equation819. intro H. specialize (H F4_1 F4_0). unfold magma_op, refa476_inst, refa476_op in H. discriminate H. Qed.

Lemma refa476_not825 : ~ @Equation825 Fin4 refa476_inst.
Proof. unfold Equation825. intro H. specialize (H F4_1 F4_0). unfold magma_op, refa476_inst, refa476_op in H. discriminate H. Qed.

Lemma refa476_not826 : ~ @Equation826 Fin4 refa476_inst.
Proof. unfold Equation826. intro H. specialize (H F4_1 F4_0). unfold magma_op, refa476_inst, refa476_op in H. discriminate H. Qed.

Lemma refa476_not832 : ~ @Equation832 Fin4 refa476_inst.
Proof. unfold Equation832. intro H. specialize (H F4_0 F4_3). unfold magma_op, refa476_inst, refa476_op in H. discriminate H. Qed.

Lemma refa476_not833 : ~ @Equation833 Fin4 refa476_inst.
Proof. unfold Equation833. intro H. specialize (H F4_1 F4_2). unfold magma_op, refa476_inst, refa476_op in H. discriminate H. Qed.

Lemma refa476_not835 : ~ @Equation835 Fin4 refa476_inst.
Proof. unfold Equation835. intro H. specialize (H F4_0 F4_2). unfold magma_op, refa476_inst, refa476_op in H. discriminate H. Qed.

Lemma refa476_not836 : ~ @Equation836 Fin4 refa476_inst.
Proof. unfold Equation836. intro H. specialize (H F4_3 F4_0). unfold magma_op, refa476_inst, refa476_op in H. discriminate H. Qed.

Lemma refa476_not842 : ~ @Equation842 Fin4 refa476_inst.
Proof. unfold Equation842. intro H. specialize (H F4_0 F4_2). unfold magma_op, refa476_inst, refa476_op in H. discriminate H. Qed.

Lemma refa476_not843 : ~ @Equation843 Fin4 refa476_inst.
Proof. unfold Equation843. intro H. specialize (H F4_0 F4_2). unfold magma_op, refa476_inst, refa476_op in H. discriminate H. Qed.

Lemma refa476_not845 : ~ @Equation845 Fin4 refa476_inst.
Proof. unfold Equation845. intro H. specialize (H F4_0 F4_2). unfold magma_op, refa476_inst, refa476_op in H. discriminate H. Qed.

Lemma refa476_not846 : ~ @Equation846 Fin4 refa476_inst.
Proof. unfold Equation846. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa476_inst, refa476_op in H. discriminate H. Qed.

Lemma refa476_not1020 : ~ @Equation1020 Fin4 refa476_inst.
Proof. unfold Equation1020. intro H. specialize (H F4_3). unfold magma_op, refa476_inst, refa476_op in H. discriminate H. Qed.

Lemma refa476_not1223 : ~ @Equation1223 Fin4 refa476_inst.
Proof. unfold Equation1223. intro H. specialize (H F4_1). unfold magma_op, refa476_inst, refa476_op in H. discriminate H. Qed.

Lemma refa476_not1426 : ~ @Equation1426 Fin4 refa476_inst.
Proof. unfold Equation1426. intro H. specialize (H F4_1). unfold magma_op, refa476_inst, refa476_op in H. discriminate H. Qed.

Lemma refa476_not1629 : ~ @Equation1629 Fin4 refa476_inst.
Proof. unfold Equation1629. intro H. specialize (H F4_1). unfold magma_op, refa476_inst, refa476_op in H. discriminate H. Qed.

Lemma refa476_not1832 : ~ @Equation1832 Fin4 refa476_inst.
Proof. unfold Equation1832. intro H. specialize (H F4_1). unfold magma_op, refa476_inst, refa476_op in H. discriminate H. Qed.

Lemma refa476_not2035 : ~ @Equation2035 Fin4 refa476_inst.
Proof. unfold Equation2035. intro H. specialize (H F4_1). unfold magma_op, refa476_inst, refa476_op in H. discriminate H. Qed.

Lemma refa476_not2238 : ~ @Equation2238 Fin4 refa476_inst.
Proof. unfold Equation2238. intro H. specialize (H F4_1). unfold magma_op, refa476_inst, refa476_op in H. discriminate H. Qed.

Lemma refa476_not2441 : ~ @Equation2441 Fin4 refa476_inst.
Proof. unfold Equation2441. intro H. specialize (H F4_1). unfold magma_op, refa476_inst, refa476_op in H. discriminate H. Qed.

Lemma refa476_not2644 : ~ @Equation2644 Fin4 refa476_inst.
Proof. unfold Equation2644. intro H. specialize (H F4_1). unfold magma_op, refa476_inst, refa476_op in H. discriminate H. Qed.

Lemma refa476_not2847 : ~ @Equation2847 Fin4 refa476_inst.
Proof. unfold Equation2847. intro H. specialize (H F4_1). unfold magma_op, refa476_inst, refa476_op in H. discriminate H. Qed.

Lemma refa476_not3050 : ~ @Equation3050 Fin4 refa476_inst.
Proof. unfold Equation3050. intro H. specialize (H F4_1). unfold magma_op, refa476_inst, refa476_op in H. discriminate H. Qed.

Lemma refa476_not3253 : ~ @Equation3253 Fin4 refa476_inst.
Proof. unfold Equation3253. intro H. specialize (H F4_1). unfold magma_op, refa476_inst, refa476_op in H. discriminate H. Qed.

Lemma refa476_not3456 : ~ @Equation3456 Fin4 refa476_inst.
Proof. unfold Equation3456. intro H. specialize (H F4_1). unfold magma_op, refa476_inst, refa476_op in H. discriminate H. Qed.

Lemma refa476_not3659 : ~ @Equation3659 Fin4 refa476_inst.
Proof. unfold Equation3659. intro H. specialize (H F4_1). unfold magma_op, refa476_inst, refa476_op in H. discriminate H. Qed.

Lemma refa476_not3862 : ~ @Equation3862 Fin4 refa476_inst.
Proof. unfold Equation3862. intro H. specialize (H F4_1). unfold magma_op, refa476_inst, refa476_op in H. discriminate H. Qed.

Lemma refa476_not4066 : ~ @Equation4066 Fin4 refa476_inst.
Proof. unfold Equation4066. intro H. specialize (H F4_0 F4_3). unfold magma_op, refa476_inst, refa476_op in H. discriminate H. Qed.

Lemma refa476_not4067 : ~ @Equation4067 Fin4 refa476_inst.
Proof. unfold Equation4067. intro H. specialize (H F4_0 F4_3). unfold magma_op, refa476_inst, refa476_op in H. discriminate H. Qed.

Lemma refa476_not4068 : ~ @Equation4068 Fin4 refa476_inst.
Proof. unfold Equation4068. intro H. specialize (H F4_0 F4_3). unfold magma_op, refa476_inst, refa476_op in H. discriminate H. Qed.

Lemma refa476_not4070 : ~ @Equation4070 Fin4 refa476_inst.
Proof. unfold Equation4070. intro H. specialize (H F4_0 F4_3). unfold magma_op, refa476_inst, refa476_op in H. discriminate H. Qed.

Lemma refa476_not4071 : ~ @Equation4071 Fin4 refa476_inst.
Proof. unfold Equation4071. intro H. specialize (H F4_0 F4_3). unfold magma_op, refa476_inst, refa476_op in H. discriminate H. Qed.

Lemma refa476_not4073 : ~ @Equation4073 Fin4 refa476_inst.
Proof. unfold Equation4073. intro H. specialize (H F4_0 F4_3). unfold magma_op, refa476_inst, refa476_op in H. discriminate H. Qed.

Lemma refa476_not4074 : ~ @Equation4074 Fin4 refa476_inst.
Proof. unfold Equation4074. intro H. specialize (H F4_0 F4_3). unfold magma_op, refa476_inst, refa476_op in H. discriminate H. Qed.

Lemma refa476_not4118 : ~ @Equation4118 Fin4 refa476_inst.
Proof. unfold Equation4118. intro H. specialize (H F4_1 F4_0). unfold magma_op, refa476_inst, refa476_op in H. discriminate H. Qed.

Lemma refa476_not4120 : ~ @Equation4120 Fin4 refa476_inst.
Proof. unfold Equation4120. intro H. specialize (H F4_1 F4_0). unfold magma_op, refa476_inst, refa476_op in H. discriminate H. Qed.

Lemma refa476_not4121 : ~ @Equation4121 Fin4 refa476_inst.
Proof. unfold Equation4121. intro H. specialize (H F4_1 F4_0). unfold magma_op, refa476_inst, refa476_op in H. discriminate H. Qed.

Lemma refa476_not4127 : ~ @Equation4127 Fin4 refa476_inst.
Proof. unfold Equation4127. intro H. specialize (H F4_1 F4_0). unfold magma_op, refa476_inst, refa476_op in H. discriminate H. Qed.

Lemma refa476_not4128 : ~ @Equation4128 Fin4 refa476_inst.
Proof. unfold Equation4128. intro H. specialize (H F4_1 F4_0). unfold magma_op, refa476_inst, refa476_op in H. discriminate H. Qed.

Lemma refa476_not4130 : ~ @Equation4130 Fin4 refa476_inst.
Proof. unfold Equation4130. intro H. specialize (H F4_1 F4_0). unfold magma_op, refa476_inst, refa476_op in H. discriminate H. Qed.

Lemma refa476_not4131 : ~ @Equation4131 Fin4 refa476_inst.
Proof. unfold Equation4131. intro H. specialize (H F4_2 F4_3). unfold magma_op, refa476_inst, refa476_op in H. discriminate H. Qed.

Lemma refa476_not4268 : ~ @Equation4268 Fin4 refa476_inst.
Proof. unfold Equation4268. intro H. specialize (H F4_1 F4_0). unfold magma_op, refa476_inst, refa476_op in H. discriminate H. Qed.

Lemma refa476_not4269 : ~ @Equation4269 Fin4 refa476_inst.
Proof. unfold Equation4269. intro H. specialize (H F4_0 F4_3). unfold magma_op, refa476_inst, refa476_op in H. discriminate H. Qed.

Lemma refa476_not4270 : ~ @Equation4270 Fin4 refa476_inst.
Proof. unfold Equation4270. intro H. specialize (H F4_0 F4_2). unfold magma_op, refa476_inst, refa476_op in H. discriminate H. Qed.

Lemma refa476_not4283 : ~ @Equation4283 Fin4 refa476_inst.
Proof. unfold Equation4283. intro H. specialize (H F4_0 F4_3). unfold magma_op, refa476_inst, refa476_op in H. discriminate H. Qed.

Lemma refa476_not4284 : ~ @Equation4284 Fin4 refa476_inst.
Proof. unfold Equation4284. intro H. specialize (H F4_0 F4_2). unfold magma_op, refa476_inst, refa476_op in H. discriminate H. Qed.

Lemma refa476_not4314 : ~ @Equation4314 Fin4 refa476_inst.
Proof. unfold Equation4314. intro H. specialize (H F4_0 F4_2). unfold magma_op, refa476_inst, refa476_op in H. discriminate H. Qed.

Lemma refa476_not4380 : ~ @Equation4380 Fin4 refa476_inst.
Proof. unfold Equation4380. intro H. specialize (H F4_1). unfold magma_op, refa476_inst, refa476_op in H. discriminate H. Qed.

Lemma refa476_not4583 : ~ @Equation4583 Fin4 refa476_inst.
Proof. unfold Equation4583. intro H. specialize (H F4_0 F4_3). unfold magma_op, refa476_inst, refa476_op in H. discriminate H. Qed.

Lemma refa476_not4584 : ~ @Equation4584 Fin4 refa476_inst.
Proof. unfold Equation4584. intro H. specialize (H F4_0 F4_3). unfold magma_op, refa476_inst, refa476_op in H. discriminate H. Qed.

Lemma refa476_not4585 : ~ @Equation4585 Fin4 refa476_inst.
Proof. unfold Equation4585. intro H. specialize (H F4_0 F4_3). unfold magma_op, refa476_inst, refa476_op in H. discriminate H. Qed.

Lemma refa476_not4598 : ~ @Equation4598 Fin4 refa476_inst.
Proof. unfold Equation4598. intro H. specialize (H F4_1 F4_2). unfold magma_op, refa476_inst, refa476_op in H. discriminate H. Qed.

Lemma refa476_not4599 : ~ @Equation4599 Fin4 refa476_inst.
Proof. unfold Equation4599. intro H. specialize (H F4_1 F4_0). unfold magma_op, refa476_inst, refa476_op in H. discriminate H. Qed.

Lemma refa476_not4629 : ~ @Equation4629 Fin4 refa476_inst.
Proof. unfold Equation4629. intro H. specialize (H F4_1 F4_0). unfold magma_op, refa476_inst, refa476_op in H. discriminate H. Qed.

(** ---- refa477 (Fin4) ---- *)

Definition refa477_op (x y : Fin4) : Fin4 :=
  match x, y with
  | F4_0, F4_0 => F4_1 | F4_0, F4_1 => F4_2 | F4_0, F4_2 => F4_2 | F4_0, F4_3 => F4_1
  | F4_1, F4_0 => F4_3 | F4_1, F4_1 => F4_3 | F4_1, F4_2 => F4_0 | F4_1, F4_3 => F4_0
  | F4_2, F4_0 => F4_3 | F4_2, F4_1 => F4_3 | F4_2, F4_2 => F4_2 | F4_2, F4_3 => F4_0
  | F4_3, F4_0 => F4_3 | F4_3, F4_1 => F4_3 | F4_3, F4_2 => F4_2 | F4_3, F4_3 => F4_1
  end.

#[local] Instance refa477_inst : Magma Fin4 := {| magma_op := refa477_op |}.

Lemma refa477_sat1664 : @Equation1664 Fin4 refa477_inst.
Proof. unfold Equation1664, magma_op, refa477_inst, refa477_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa477_not3253 : ~ @Equation3253 Fin4 refa477_inst.
Proof. unfold Equation3253. intro H. specialize (H F4_0). unfold magma_op, refa477_inst, refa477_op in H. discriminate H. Qed.

(** ---- refa478 (Fin4) ---- *)

Definition refa478_op (x y : Fin4) : Fin4 :=
  match x, y with
  | F4_0, F4_0 => F4_3 | F4_0, F4_1 => F4_2 | F4_0, F4_2 => F4_3 | F4_0, F4_3 => F4_3
  | F4_1, F4_0 => F4_3 | F4_1, F4_1 => F4_3 | F4_1, F4_2 => F4_3 | F4_1, F4_3 => F4_3
  | F4_2, F4_0 => F4_3 | F4_2, F4_1 => F4_3 | F4_2, F4_2 => F4_1 | F4_2, F4_3 => F4_3
  | F4_3, F4_0 => F4_3 | F4_3, F4_1 => F4_3 | F4_3, F4_2 => F4_3 | F4_3, F4_3 => F4_3
  end.

#[local] Instance refa478_inst : Magma Fin4 := {| magma_op := refa478_op |}.

Lemma refa478_sat4417 : @Equation4417 Fin4 refa478_inst.
Proof. unfold Equation4417, magma_op, refa478_inst, refa478_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa478_sat4426 : @Equation4426 Fin4 refa478_inst.
Proof. unfold Equation4426, magma_op, refa478_inst, refa478_op. intros x y z w. destruct x, y, z, w; reflexivity. Qed.

Lemma refa478_sat4430 : @Equation4430 Fin4 refa478_inst.
Proof. unfold Equation4430, magma_op, refa478_inst, refa478_op. intros x y z w. destruct x, y, z, w; reflexivity. Qed.

Lemma refa478_sat4434 : @Equation4434 Fin4 refa478_inst.
Proof. unfold Equation4434, magma_op, refa478_inst, refa478_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa478_not4270 : ~ @Equation4270 Fin4 refa478_inst.
Proof. unfold Equation4270. intro H. specialize (H F4_0 F4_2). unfold magma_op, refa478_inst, refa478_op in H. discriminate H. Qed.

Lemma refa478_not4272 : ~ @Equation4272 Fin4 refa478_inst.
Proof. unfold Equation4272. intro H. specialize (H F4_2 F4_0). unfold magma_op, refa478_inst, refa478_op in H. discriminate H. Qed.

Lemma refa478_not4284 : ~ @Equation4284 Fin4 refa478_inst.
Proof. unfold Equation4284. intro H. specialize (H F4_0 F4_2). unfold magma_op, refa478_inst, refa478_op in H. discriminate H. Qed.

Lemma refa478_not4290 : ~ @Equation4290 Fin4 refa478_inst.
Proof. unfold Equation4290. intro H. specialize (H F4_2 F4_0). unfold magma_op, refa478_inst, refa478_op in H. discriminate H. Qed.

Lemma refa478_not4314 : ~ @Equation4314 Fin4 refa478_inst.
Proof. unfold Equation4314. intro H. specialize (H F4_0 F4_2). unfold magma_op, refa478_inst, refa478_op in H. discriminate H. Qed.

Lemma refa478_not4343 : ~ @Equation4343 Fin4 refa478_inst.
Proof. unfold Equation4343. intro H. specialize (H F4_0 F4_2). unfold magma_op, refa478_inst, refa478_op in H. discriminate H. Qed.

Lemma refa478_not4470 : ~ @Equation4470 Fin4 refa478_inst.
Proof. unfold Equation4470. intro H. specialize (H F4_0 F4_2). unfold magma_op, refa478_inst, refa478_op in H. discriminate H. Qed.

Lemma refa478_not4472 : ~ @Equation4472 Fin4 refa478_inst.
Proof. unfold Equation4472. intro H. specialize (H F4_0 F4_2). unfold magma_op, refa478_inst, refa478_op in H. discriminate H. Qed.

Lemma refa478_not4480 : ~ @Equation4480 Fin4 refa478_inst.
Proof. unfold Equation4480. intro H. specialize (H F4_0 F4_2). unfold magma_op, refa478_inst, refa478_op in H. discriminate H. Qed.

Lemma refa478_not4482 : ~ @Equation4482 Fin4 refa478_inst.
Proof. unfold Equation4482. intro H. specialize (H F4_0 F4_2). unfold magma_op, refa478_inst, refa478_op in H. discriminate H. Qed.

Lemma refa478_not4673 : ~ @Equation4673 Fin4 refa478_inst.
Proof. unfold Equation4673. intro H. specialize (H F4_0 F4_1 F4_2). unfold magma_op, refa478_inst, refa478_op in H. discriminate H. Qed.

Lemma refa478_not4677 : ~ @Equation4677 Fin4 refa478_inst.
Proof. unfold Equation4677. intro H. specialize (H F4_0 F4_1 F4_2). unfold magma_op, refa478_inst, refa478_op in H. discriminate H. Qed.

(** ---- refa479 (Fin4) ---- *)

Definition refa479_op (x y : Fin4) : Fin4 :=
  match x, y with
  | F4_0, F4_0 => F4_3 | F4_0, F4_1 => F4_2 | F4_0, F4_2 => F4_3 | F4_0, F4_3 => F4_3
  | F4_1, F4_0 => F4_1 | F4_1, F4_1 => F4_1 | F4_1, F4_2 => F4_1 | F4_1, F4_3 => F4_1
  | F4_2, F4_0 => F4_2 | F4_2, F4_1 => F4_0 | F4_2, F4_2 => F4_2 | F4_2, F4_3 => F4_2
  | F4_3, F4_0 => F4_0 | F4_3, F4_1 => F4_3 | F4_3, F4_2 => F4_0 | F4_3, F4_3 => F4_0
  end.

#[local] Instance refa479_inst : Magma Fin4 := {| magma_op := refa479_op |}.

Lemma refa479_sat161 : @Equation161 Fin4 refa479_inst.
Proof. unfold Equation161, magma_op, refa479_inst, refa479_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa479_sat2463 : @Equation2463 Fin4 refa479_inst.
Proof. unfold Equation2463, magma_op, refa479_inst, refa479_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa479_not3056 : ~ @Equation3056 Fin4 refa479_inst.
Proof. unfold Equation3056. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa479_inst, refa479_op in H. discriminate H. Qed.

Lemma refa479_not3068 : ~ @Equation3068 Fin4 refa479_inst.
Proof. unfold Equation3068. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa479_inst, refa479_op in H. discriminate H. Qed.

Lemma refa479_not4071 : ~ @Equation4071 Fin4 refa479_inst.
Proof. unfold Equation4071. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa479_inst, refa479_op in H. discriminate H. Qed.

Lemma refa479_not4120 : ~ @Equation4120 Fin4 refa479_inst.
Proof. unfold Equation4120. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa479_inst, refa479_op in H. discriminate H. Qed.

Lemma refa479_not4598 : ~ @Equation4598 Fin4 refa479_inst.
Proof. unfold Equation4598. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa479_inst, refa479_op in H. discriminate H. Qed.

(** ---- refa48 (Fin2) ---- *)

Definition refa48_op (x y : Fin2) : Fin2 :=
  match x, y with
  | F2_0, F2_0 => F2_0 | F2_0, F2_1 => F2_1
  | F2_1, F2_0 => F2_0 | F2_1, F2_1 => F2_1
  end.

#[local] Instance refa48_inst : Magma Fin2 := {| magma_op := refa48_op |}.

Lemma refa48_sat5 : @Equation5 Fin2 refa48_inst.
Proof. unfold Equation5, magma_op, refa48_inst, refa48_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa48_not50 : ~ @Equation50 Fin2 refa48_inst.
Proof. unfold Equation50. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa48_inst, refa48_op in H. discriminate H. Qed.

Lemma refa48_not53 : ~ @Equation53 Fin2 refa48_inst.
Proof. unfold Equation53. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa48_inst, refa48_op in H. discriminate H. Qed.

Lemma refa48_not56 : ~ @Equation56 Fin2 refa48_inst.
Proof. unfold Equation56. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa48_inst, refa48_op in H. discriminate H. Qed.

Lemma refa48_not66 : ~ @Equation66 Fin2 refa48_inst.
Proof. unfold Equation66. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa48_inst, refa48_op in H. discriminate H. Qed.

Lemma refa48_not73 : ~ @Equation73 Fin2 refa48_inst.
Proof. unfold Equation73. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa48_inst, refa48_op in H. discriminate H. Qed.

Lemma refa48_not105 : ~ @Equation105 Fin2 refa48_inst.
Proof. unfold Equation105. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa48_inst, refa48_op in H. discriminate H. Qed.

Lemma refa48_not108 : ~ @Equation108 Fin2 refa48_inst.
Proof. unfold Equation108. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa48_inst, refa48_op in H. discriminate H. Qed.

Lemma refa48_not118 : ~ @Equation118 Fin2 refa48_inst.
Proof. unfold Equation118. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa48_inst, refa48_op in H. discriminate H. Qed.

Lemma refa48_not160 : ~ @Equation160 Fin2 refa48_inst.
Proof. unfold Equation160. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa48_inst, refa48_op in H. discriminate H. Qed.

Lemma refa48_not167 : ~ @Equation167 Fin2 refa48_inst.
Proof. unfold Equation167. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa48_inst, refa48_op in H. discriminate H. Qed.

Lemma refa48_not206 : ~ @Equation206 Fin2 refa48_inst.
Proof. unfold Equation206. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa48_inst, refa48_op in H. discriminate H. Qed.

Lemma refa48_not209 : ~ @Equation209 Fin2 refa48_inst.
Proof. unfold Equation209. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa48_inst, refa48_op in H. discriminate H. Qed.

Lemma refa48_not229 : ~ @Equation229 Fin2 refa48_inst.
Proof. unfold Equation229. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa48_inst, refa48_op in H. discriminate H. Qed.

Lemma refa48_not261 : ~ @Equation261 Fin2 refa48_inst.
Proof. unfold Equation261. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa48_inst, refa48_op in H. discriminate H. Qed.

Lemma refa48_not264 : ~ @Equation264 Fin2 refa48_inst.
Proof. unfold Equation264. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa48_inst, refa48_op in H. discriminate H. Qed.

Lemma refa48_not274 : ~ @Equation274 Fin2 refa48_inst.
Proof. unfold Equation274. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa48_inst, refa48_op in H. discriminate H. Qed.

Lemma refa48_not335 : ~ @Equation335 Fin2 refa48_inst.
Proof. unfold Equation335. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa48_inst, refa48_op in H. discriminate H. Qed.

Lemma refa48_not412 : ~ @Equation412 Fin2 refa48_inst.
Proof. unfold Equation412. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa48_inst, refa48_op in H. discriminate H. Qed.

Lemma refa48_not414 : ~ @Equation414 Fin2 refa48_inst.
Proof. unfold Equation414. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa48_inst, refa48_op in H. discriminate H. Qed.

Lemma refa48_not417 : ~ @Equation417 Fin2 refa48_inst.
Proof. unfold Equation417. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa48_inst, refa48_op in H. discriminate H. Qed.

Lemma refa48_not420 : ~ @Equation420 Fin2 refa48_inst.
Proof. unfold Equation420. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa48_inst, refa48_op in H. discriminate H. Qed.

Lemma refa48_not427 : ~ @Equation427 Fin2 refa48_inst.
Proof. unfold Equation427. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa48_inst, refa48_op in H. discriminate H. Qed.

Lemma refa48_not430 : ~ @Equation430 Fin2 refa48_inst.
Proof. unfold Equation430. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa48_inst, refa48_op in H. discriminate H. Qed.

Lemma refa48_not437 : ~ @Equation437 Fin2 refa48_inst.
Proof. unfold Equation437. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa48_inst, refa48_op in H. discriminate H. Qed.

Lemma refa48_not440 : ~ @Equation440 Fin2 refa48_inst.
Proof. unfold Equation440. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa48_inst, refa48_op in H. discriminate H. Qed.

Lemma refa48_not464 : ~ @Equation464 Fin2 refa48_inst.
Proof. unfold Equation464. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa48_inst, refa48_op in H. discriminate H. Qed.

Lemma refa48_not467 : ~ @Equation467 Fin2 refa48_inst.
Proof. unfold Equation467. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa48_inst, refa48_op in H. discriminate H. Qed.

Lemma refa48_not474 : ~ @Equation474 Fin2 refa48_inst.
Proof. unfold Equation474. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa48_inst, refa48_op in H. discriminate H. Qed.

Lemma refa48_not477 : ~ @Equation477 Fin2 refa48_inst.
Proof. unfold Equation477. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa48_inst, refa48_op in H. discriminate H. Qed.

Lemma refa48_not501 : ~ @Equation501 Fin2 refa48_inst.
Proof. unfold Equation501. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa48_inst, refa48_op in H. discriminate H. Qed.

Lemma refa48_not504 : ~ @Equation504 Fin2 refa48_inst.
Proof. unfold Equation504. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa48_inst, refa48_op in H. discriminate H. Qed.

Lemma refa48_not511 : ~ @Equation511 Fin2 refa48_inst.
Proof. unfold Equation511. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa48_inst, refa48_op in H. discriminate H. Qed.

Lemma refa48_not615 : ~ @Equation615 Fin2 refa48_inst.
Proof. unfold Equation615. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa48_inst, refa48_op in H. discriminate H. Qed.

Lemma refa48_not617 : ~ @Equation617 Fin2 refa48_inst.
Proof. unfold Equation617. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa48_inst, refa48_op in H. discriminate H. Qed.

Lemma refa48_not620 : ~ @Equation620 Fin2 refa48_inst.
Proof. unfold Equation620. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa48_inst, refa48_op in H. discriminate H. Qed.

Lemma refa48_not623 : ~ @Equation623 Fin2 refa48_inst.
Proof. unfold Equation623. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa48_inst, refa48_op in H. discriminate H. Qed.

Lemma refa48_not630 : ~ @Equation630 Fin2 refa48_inst.
Proof. unfold Equation630. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa48_inst, refa48_op in H. discriminate H. Qed.

Lemma refa48_not633 : ~ @Equation633 Fin2 refa48_inst.
Proof. unfold Equation633. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa48_inst, refa48_op in H. discriminate H. Qed.

Lemma refa48_not640 : ~ @Equation640 Fin2 refa48_inst.
Proof. unfold Equation640. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa48_inst, refa48_op in H. discriminate H. Qed.

Lemma refa48_not643 : ~ @Equation643 Fin2 refa48_inst.
Proof. unfold Equation643. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa48_inst, refa48_op in H. discriminate H. Qed.

Lemma refa48_not667 : ~ @Equation667 Fin2 refa48_inst.
Proof. unfold Equation667. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa48_inst, refa48_op in H. discriminate H. Qed.

Lemma refa48_not670 : ~ @Equation670 Fin2 refa48_inst.
Proof. unfold Equation670. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa48_inst, refa48_op in H. discriminate H. Qed.

Lemma refa48_not677 : ~ @Equation677 Fin2 refa48_inst.
Proof. unfold Equation677. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa48_inst, refa48_op in H. discriminate H. Qed.

Lemma refa48_not680 : ~ @Equation680 Fin2 refa48_inst.
Proof. unfold Equation680. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa48_inst, refa48_op in H. discriminate H. Qed.

Lemma refa48_not704 : ~ @Equation704 Fin2 refa48_inst.
Proof. unfold Equation704. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa48_inst, refa48_op in H. discriminate H. Qed.

Lemma refa48_not707 : ~ @Equation707 Fin2 refa48_inst.
Proof. unfold Equation707. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa48_inst, refa48_op in H. discriminate H. Qed.

Lemma refa48_not818 : ~ @Equation818 Fin2 refa48_inst.
Proof. unfold Equation818. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa48_inst, refa48_op in H. discriminate H. Qed.

Lemma refa48_not820 : ~ @Equation820 Fin2 refa48_inst.
Proof. unfold Equation820. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa48_inst, refa48_op in H. discriminate H. Qed.

Lemma refa48_not823 : ~ @Equation823 Fin2 refa48_inst.
Proof. unfold Equation823. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa48_inst, refa48_op in H. discriminate H. Qed.

Lemma refa48_not826 : ~ @Equation826 Fin2 refa48_inst.
Proof. unfold Equation826. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa48_inst, refa48_op in H. discriminate H. Qed.

Lemma refa48_not833 : ~ @Equation833 Fin2 refa48_inst.
Proof. unfold Equation833. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa48_inst, refa48_op in H. discriminate H. Qed.

Lemma refa48_not836 : ~ @Equation836 Fin2 refa48_inst.
Proof. unfold Equation836. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa48_inst, refa48_op in H. discriminate H. Qed.

Lemma refa48_not843 : ~ @Equation843 Fin2 refa48_inst.
Proof. unfold Equation843. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa48_inst, refa48_op in H. discriminate H. Qed.

Lemma refa48_not846 : ~ @Equation846 Fin2 refa48_inst.
Proof. unfold Equation846. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa48_inst, refa48_op in H. discriminate H. Qed.

Lemma refa48_not870 : ~ @Equation870 Fin2 refa48_inst.
Proof. unfold Equation870. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa48_inst, refa48_op in H. discriminate H. Qed.

Lemma refa48_not873 : ~ @Equation873 Fin2 refa48_inst.
Proof. unfold Equation873. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa48_inst, refa48_op in H. discriminate H. Qed.

Lemma refa48_not883 : ~ @Equation883 Fin2 refa48_inst.
Proof. unfold Equation883. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa48_inst, refa48_op in H. discriminate H. Qed.

Lemma refa48_not907 : ~ @Equation907 Fin2 refa48_inst.
Proof. unfold Equation907. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa48_inst, refa48_op in H. discriminate H. Qed.

Lemma refa48_not917 : ~ @Equation917 Fin2 refa48_inst.
Proof. unfold Equation917. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa48_inst, refa48_op in H. discriminate H. Qed.

Lemma refa48_not1021 : ~ @Equation1021 Fin2 refa48_inst.
Proof. unfold Equation1021. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa48_inst, refa48_op in H. discriminate H. Qed.

Lemma refa48_not1023 : ~ @Equation1023 Fin2 refa48_inst.
Proof. unfold Equation1023. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa48_inst, refa48_op in H. discriminate H. Qed.

Lemma refa48_not1026 : ~ @Equation1026 Fin2 refa48_inst.
Proof. unfold Equation1026. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa48_inst, refa48_op in H. discriminate H. Qed.

Lemma refa48_not1029 : ~ @Equation1029 Fin2 refa48_inst.
Proof. unfold Equation1029. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa48_inst, refa48_op in H. discriminate H. Qed.

Lemma refa48_not1036 : ~ @Equation1036 Fin2 refa48_inst.
Proof. unfold Equation1036. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa48_inst, refa48_op in H. discriminate H. Qed.

Lemma refa48_not1039 : ~ @Equation1039 Fin2 refa48_inst.
Proof. unfold Equation1039. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa48_inst, refa48_op in H. discriminate H. Qed.

Lemma refa48_not1046 : ~ @Equation1046 Fin2 refa48_inst.
Proof. unfold Equation1046. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa48_inst, refa48_op in H. discriminate H. Qed.

Lemma refa48_not1049 : ~ @Equation1049 Fin2 refa48_inst.
Proof. unfold Equation1049. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa48_inst, refa48_op in H. discriminate H. Qed.

Lemma refa48_not1076 : ~ @Equation1076 Fin2 refa48_inst.
Proof. unfold Equation1076. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa48_inst, refa48_op in H. discriminate H. Qed.

Lemma refa48_not1083 : ~ @Equation1083 Fin2 refa48_inst.
Proof. unfold Equation1083. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa48_inst, refa48_op in H. discriminate H. Qed.

Lemma refa48_not1086 : ~ @Equation1086 Fin2 refa48_inst.
Proof. unfold Equation1086. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa48_inst, refa48_op in H. discriminate H. Qed.

Lemma refa48_not1110 : ~ @Equation1110 Fin2 refa48_inst.
Proof. unfold Equation1110. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa48_inst, refa48_op in H. discriminate H. Qed.

Lemma refa48_not1113 : ~ @Equation1113 Fin2 refa48_inst.
Proof. unfold Equation1113. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa48_inst, refa48_op in H. discriminate H. Qed.

Lemma refa48_not1224 : ~ @Equation1224 Fin2 refa48_inst.
Proof. unfold Equation1224. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa48_inst, refa48_op in H. discriminate H. Qed.

Lemma refa48_not1226 : ~ @Equation1226 Fin2 refa48_inst.
Proof. unfold Equation1226. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa48_inst, refa48_op in H. discriminate H. Qed.

Lemma refa48_not1229 : ~ @Equation1229 Fin2 refa48_inst.
Proof. unfold Equation1229. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa48_inst, refa48_op in H. discriminate H. Qed.

Lemma refa48_not1232 : ~ @Equation1232 Fin2 refa48_inst.
Proof. unfold Equation1232. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa48_inst, refa48_op in H. discriminate H. Qed.

Lemma refa48_not1239 : ~ @Equation1239 Fin2 refa48_inst.
Proof. unfold Equation1239. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa48_inst, refa48_op in H. discriminate H. Qed.

Lemma refa48_not1242 : ~ @Equation1242 Fin2 refa48_inst.
Proof. unfold Equation1242. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa48_inst, refa48_op in H. discriminate H. Qed.

Lemma refa48_not1249 : ~ @Equation1249 Fin2 refa48_inst.
Proof. unfold Equation1249. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa48_inst, refa48_op in H. discriminate H. Qed.

Lemma refa48_not1252 : ~ @Equation1252 Fin2 refa48_inst.
Proof. unfold Equation1252. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa48_inst, refa48_op in H. discriminate H. Qed.

Lemma refa48_not1276 : ~ @Equation1276 Fin2 refa48_inst.
Proof. unfold Equation1276. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa48_inst, refa48_op in H. discriminate H. Qed.

Lemma refa48_not1279 : ~ @Equation1279 Fin2 refa48_inst.
Proof. unfold Equation1279. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa48_inst, refa48_op in H. discriminate H. Qed.

Lemma refa48_not1286 : ~ @Equation1286 Fin2 refa48_inst.
Proof. unfold Equation1286. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa48_inst, refa48_op in H. discriminate H. Qed.

Lemma refa48_not1289 : ~ @Equation1289 Fin2 refa48_inst.
Proof. unfold Equation1289. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa48_inst, refa48_op in H. discriminate H. Qed.

Lemma refa48_not1313 : ~ @Equation1313 Fin2 refa48_inst.
Proof. unfold Equation1313. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa48_inst, refa48_op in H. discriminate H. Qed.

Lemma refa48_not1427 : ~ @Equation1427 Fin2 refa48_inst.
Proof. unfold Equation1427. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa48_inst, refa48_op in H. discriminate H. Qed.

Lemma refa48_not1429 : ~ @Equation1429 Fin2 refa48_inst.
Proof. unfold Equation1429. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa48_inst, refa48_op in H. discriminate H. Qed.

Lemma refa48_not1432 : ~ @Equation1432 Fin2 refa48_inst.
Proof. unfold Equation1432. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa48_inst, refa48_op in H. discriminate H. Qed.

Lemma refa48_not1435 : ~ @Equation1435 Fin2 refa48_inst.
Proof. unfold Equation1435. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa48_inst, refa48_op in H. discriminate H. Qed.

Lemma refa48_not1445 : ~ @Equation1445 Fin2 refa48_inst.
Proof. unfold Equation1445. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa48_inst, refa48_op in H. discriminate H. Qed.

Lemma refa48_not1455 : ~ @Equation1455 Fin2 refa48_inst.
Proof. unfold Equation1455. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa48_inst, refa48_op in H. discriminate H. Qed.

Lemma refa48_not1479 : ~ @Equation1479 Fin2 refa48_inst.
Proof. unfold Equation1479. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa48_inst, refa48_op in H. discriminate H. Qed.

Lemma refa48_not1482 : ~ @Equation1482 Fin2 refa48_inst.
Proof. unfold Equation1482. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa48_inst, refa48_op in H. discriminate H. Qed.

Lemma refa48_not1489 : ~ @Equation1489 Fin2 refa48_inst.
Proof. unfold Equation1489. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa48_inst, refa48_op in H. discriminate H. Qed.

Lemma refa48_not1516 : ~ @Equation1516 Fin2 refa48_inst.
Proof. unfold Equation1516. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa48_inst, refa48_op in H. discriminate H. Qed.

Lemma refa48_not1519 : ~ @Equation1519 Fin2 refa48_inst.
Proof. unfold Equation1519. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa48_inst, refa48_op in H. discriminate H. Qed.

Lemma refa48_not1526 : ~ @Equation1526 Fin2 refa48_inst.
Proof. unfold Equation1526. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa48_inst, refa48_op in H. discriminate H. Qed.

Lemma refa48_not1630 : ~ @Equation1630 Fin2 refa48_inst.
Proof. unfold Equation1630. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa48_inst, refa48_op in H. discriminate H. Qed.

Lemma refa48_not1632 : ~ @Equation1632 Fin2 refa48_inst.
Proof. unfold Equation1632. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa48_inst, refa48_op in H. discriminate H. Qed.

Lemma refa48_not1635 : ~ @Equation1635 Fin2 refa48_inst.
Proof. unfold Equation1635. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa48_inst, refa48_op in H. discriminate H. Qed.

Lemma refa48_not1638 : ~ @Equation1638 Fin2 refa48_inst.
Proof. unfold Equation1638. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa48_inst, refa48_op in H. discriminate H. Qed.

Lemma refa48_not1645 : ~ @Equation1645 Fin2 refa48_inst.
Proof. unfold Equation1645. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa48_inst, refa48_op in H. discriminate H. Qed.

Lemma refa48_not1648 : ~ @Equation1648 Fin2 refa48_inst.
Proof. unfold Equation1648. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa48_inst, refa48_op in H. discriminate H. Qed.

Lemma refa48_not1655 : ~ @Equation1655 Fin2 refa48_inst.
Proof. unfold Equation1655. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa48_inst, refa48_op in H. discriminate H. Qed.

Lemma refa48_not1658 : ~ @Equation1658 Fin2 refa48_inst.
Proof. unfold Equation1658. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa48_inst, refa48_op in H. discriminate H. Qed.

Lemma refa48_not1682 : ~ @Equation1682 Fin2 refa48_inst.
Proof. unfold Equation1682. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa48_inst, refa48_op in H. discriminate H. Qed.

Lemma refa48_not1685 : ~ @Equation1685 Fin2 refa48_inst.
Proof. unfold Equation1685. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa48_inst, refa48_op in H. discriminate H. Qed.

Lemma refa48_not1692 : ~ @Equation1692 Fin2 refa48_inst.
Proof. unfold Equation1692. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa48_inst, refa48_op in H. discriminate H. Qed.

Lemma refa48_not1719 : ~ @Equation1719 Fin2 refa48_inst.
Proof. unfold Equation1719. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa48_inst, refa48_op in H. discriminate H. Qed.

Lemma refa48_not1722 : ~ @Equation1722 Fin2 refa48_inst.
Proof. unfold Equation1722. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa48_inst, refa48_op in H. discriminate H. Qed.

Lemma refa48_not1833 : ~ @Equation1833 Fin2 refa48_inst.
Proof. unfold Equation1833. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa48_inst, refa48_op in H. discriminate H. Qed.

Lemma refa48_not1838 : ~ @Equation1838 Fin2 refa48_inst.
Proof. unfold Equation1838. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa48_inst, refa48_op in H. discriminate H. Qed.

Lemma refa48_not1841 : ~ @Equation1841 Fin2 refa48_inst.
Proof. unfold Equation1841. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa48_inst, refa48_op in H. discriminate H. Qed.

Lemma refa48_not1848 : ~ @Equation1848 Fin2 refa48_inst.
Proof. unfold Equation1848. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa48_inst, refa48_op in H. discriminate H. Qed.

Lemma refa48_not1851 : ~ @Equation1851 Fin2 refa48_inst.
Proof. unfold Equation1851. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa48_inst, refa48_op in H. discriminate H. Qed.

Lemma refa48_not1858 : ~ @Equation1858 Fin2 refa48_inst.
Proof. unfold Equation1858. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa48_inst, refa48_op in H. discriminate H. Qed.

Lemma refa48_not1861 : ~ @Equation1861 Fin2 refa48_inst.
Proof. unfold Equation1861. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa48_inst, refa48_op in H. discriminate H. Qed.

Lemma refa48_not1885 : ~ @Equation1885 Fin2 refa48_inst.
Proof. unfold Equation1885. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa48_inst, refa48_op in H. discriminate H. Qed.

Lemma refa48_not1888 : ~ @Equation1888 Fin2 refa48_inst.
Proof. unfold Equation1888. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa48_inst, refa48_op in H. discriminate H. Qed.

Lemma refa48_not1895 : ~ @Equation1895 Fin2 refa48_inst.
Proof. unfold Equation1895. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa48_inst, refa48_op in H. discriminate H. Qed.

Lemma refa48_not1922 : ~ @Equation1922 Fin2 refa48_inst.
Proof. unfold Equation1922. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa48_inst, refa48_op in H. discriminate H. Qed.

Lemma refa48_not1925 : ~ @Equation1925 Fin2 refa48_inst.
Proof. unfold Equation1925. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa48_inst, refa48_op in H. discriminate H. Qed.

Lemma refa48_not2036 : ~ @Equation2036 Fin2 refa48_inst.
Proof. unfold Equation2036. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa48_inst, refa48_op in H. discriminate H. Qed.

Lemma refa48_not2038 : ~ @Equation2038 Fin2 refa48_inst.
Proof. unfold Equation2038. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa48_inst, refa48_op in H. discriminate H. Qed.

Lemma refa48_not2041 : ~ @Equation2041 Fin2 refa48_inst.
Proof. unfold Equation2041. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa48_inst, refa48_op in H. discriminate H. Qed.

Lemma refa48_not2044 : ~ @Equation2044 Fin2 refa48_inst.
Proof. unfold Equation2044. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa48_inst, refa48_op in H. discriminate H. Qed.

Lemma refa48_not2054 : ~ @Equation2054 Fin2 refa48_inst.
Proof. unfold Equation2054. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa48_inst, refa48_op in H. discriminate H. Qed.

Lemma refa48_not2061 : ~ @Equation2061 Fin2 refa48_inst.
Proof. unfold Equation2061. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa48_inst, refa48_op in H. discriminate H. Qed.

Lemma refa48_not2064 : ~ @Equation2064 Fin2 refa48_inst.
Proof. unfold Equation2064. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa48_inst, refa48_op in H. discriminate H. Qed.

Lemma refa48_not2088 : ~ @Equation2088 Fin2 refa48_inst.
Proof. unfold Equation2088. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa48_inst, refa48_op in H. discriminate H. Qed.

Lemma refa48_not2091 : ~ @Equation2091 Fin2 refa48_inst.
Proof. unfold Equation2091. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa48_inst, refa48_op in H. discriminate H. Qed.

Lemma refa48_not2098 : ~ @Equation2098 Fin2 refa48_inst.
Proof. unfold Equation2098. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa48_inst, refa48_op in H. discriminate H. Qed.

Lemma refa48_not2101 : ~ @Equation2101 Fin2 refa48_inst.
Proof. unfold Equation2101. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa48_inst, refa48_op in H. discriminate H. Qed.

Lemma refa48_not2125 : ~ @Equation2125 Fin2 refa48_inst.
Proof. unfold Equation2125. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa48_inst, refa48_op in H. discriminate H. Qed.

Lemma refa48_not2128 : ~ @Equation2128 Fin2 refa48_inst.
Proof. unfold Equation2128. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa48_inst, refa48_op in H. discriminate H. Qed.

Lemma refa48_not2241 : ~ @Equation2241 Fin2 refa48_inst.
Proof. unfold Equation2241. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa48_inst, refa48_op in H. discriminate H. Qed.

Lemma refa48_not2244 : ~ @Equation2244 Fin2 refa48_inst.
Proof. unfold Equation2244. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa48_inst, refa48_op in H. discriminate H. Qed.

Lemma refa48_not2247 : ~ @Equation2247 Fin2 refa48_inst.
Proof. unfold Equation2247. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa48_inst, refa48_op in H. discriminate H. Qed.

Lemma refa48_not2254 : ~ @Equation2254 Fin2 refa48_inst.
Proof. unfold Equation2254. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa48_inst, refa48_op in H. discriminate H. Qed.

Lemma refa48_not2257 : ~ @Equation2257 Fin2 refa48_inst.
Proof. unfold Equation2257. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa48_inst, refa48_op in H. discriminate H. Qed.

Lemma refa48_not2264 : ~ @Equation2264 Fin2 refa48_inst.
Proof. unfold Equation2264. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa48_inst, refa48_op in H. discriminate H. Qed.

Lemma refa48_not2291 : ~ @Equation2291 Fin2 refa48_inst.
Proof. unfold Equation2291. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa48_inst, refa48_op in H. discriminate H. Qed.

Lemma refa48_not2294 : ~ @Equation2294 Fin2 refa48_inst.
Proof. unfold Equation2294. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa48_inst, refa48_op in H. discriminate H. Qed.

Lemma refa48_not2301 : ~ @Equation2301 Fin2 refa48_inst.
Proof. unfold Equation2301. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa48_inst, refa48_op in H. discriminate H. Qed.

Lemma refa48_not2328 : ~ @Equation2328 Fin2 refa48_inst.
Proof. unfold Equation2328. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa48_inst, refa48_op in H. discriminate H. Qed.

Lemma refa48_not2338 : ~ @Equation2338 Fin2 refa48_inst.
Proof. unfold Equation2338. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa48_inst, refa48_op in H. discriminate H. Qed.

Lemma refa48_not2444 : ~ @Equation2444 Fin2 refa48_inst.
Proof. unfold Equation2444. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa48_inst, refa48_op in H. discriminate H. Qed.

Lemma refa48_not2447 : ~ @Equation2447 Fin2 refa48_inst.
Proof. unfold Equation2447. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa48_inst, refa48_op in H. discriminate H. Qed.

Lemma refa48_not2450 : ~ @Equation2450 Fin2 refa48_inst.
Proof. unfold Equation2450. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa48_inst, refa48_op in H. discriminate H. Qed.

Lemma refa48_not2457 : ~ @Equation2457 Fin2 refa48_inst.
Proof. unfold Equation2457. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa48_inst, refa48_op in H. discriminate H. Qed.

Lemma refa48_not2460 : ~ @Equation2460 Fin2 refa48_inst.
Proof. unfold Equation2460. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa48_inst, refa48_op in H. discriminate H. Qed.

Lemma refa48_not2467 : ~ @Equation2467 Fin2 refa48_inst.
Proof. unfold Equation2467. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa48_inst, refa48_op in H. discriminate H. Qed.

Lemma refa48_not2497 : ~ @Equation2497 Fin2 refa48_inst.
Proof. unfold Equation2497. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa48_inst, refa48_op in H. discriminate H. Qed.

Lemma refa48_not2504 : ~ @Equation2504 Fin2 refa48_inst.
Proof. unfold Equation2504. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa48_inst, refa48_op in H. discriminate H. Qed.

Lemma refa48_not2531 : ~ @Equation2531 Fin2 refa48_inst.
Proof. unfold Equation2531. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa48_inst, refa48_op in H. discriminate H. Qed.

Lemma refa48_not2534 : ~ @Equation2534 Fin2 refa48_inst.
Proof. unfold Equation2534. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa48_inst, refa48_op in H. discriminate H. Qed.

Lemma refa48_not2541 : ~ @Equation2541 Fin2 refa48_inst.
Proof. unfold Equation2541. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa48_inst, refa48_op in H. discriminate H. Qed.

Lemma refa48_not2647 : ~ @Equation2647 Fin2 refa48_inst.
Proof. unfold Equation2647. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa48_inst, refa48_op in H. discriminate H. Qed.

Lemma refa48_not2650 : ~ @Equation2650 Fin2 refa48_inst.
Proof. unfold Equation2650. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa48_inst, refa48_op in H. discriminate H. Qed.

Lemma refa48_not2653 : ~ @Equation2653 Fin2 refa48_inst.
Proof. unfold Equation2653. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa48_inst, refa48_op in H. discriminate H. Qed.

Lemma refa48_not2660 : ~ @Equation2660 Fin2 refa48_inst.
Proof. unfold Equation2660. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa48_inst, refa48_op in H. discriminate H. Qed.

Lemma refa48_not2670 : ~ @Equation2670 Fin2 refa48_inst.
Proof. unfold Equation2670. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa48_inst, refa48_op in H. discriminate H. Qed.

Lemma refa48_not2697 : ~ @Equation2697 Fin2 refa48_inst.
Proof. unfold Equation2697. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa48_inst, refa48_op in H. discriminate H. Qed.

Lemma refa48_not2700 : ~ @Equation2700 Fin2 refa48_inst.
Proof. unfold Equation2700. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa48_inst, refa48_op in H. discriminate H. Qed.

Lemma refa48_not2710 : ~ @Equation2710 Fin2 refa48_inst.
Proof. unfold Equation2710. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa48_inst, refa48_op in H. discriminate H. Qed.

Lemma refa48_not2734 : ~ @Equation2734 Fin2 refa48_inst.
Proof. unfold Equation2734. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa48_inst, refa48_op in H. discriminate H. Qed.

Lemma refa48_not2744 : ~ @Equation2744 Fin2 refa48_inst.
Proof. unfold Equation2744. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa48_inst, refa48_op in H. discriminate H. Qed.

Lemma refa48_not2853 : ~ @Equation2853 Fin2 refa48_inst.
Proof. unfold Equation2853. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa48_inst, refa48_op in H. discriminate H. Qed.

Lemma refa48_not2856 : ~ @Equation2856 Fin2 refa48_inst.
Proof. unfold Equation2856. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa48_inst, refa48_op in H. discriminate H. Qed.

Lemma refa48_not2863 : ~ @Equation2863 Fin2 refa48_inst.
Proof. unfold Equation2863. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa48_inst, refa48_op in H. discriminate H. Qed.

Lemma refa48_not2866 : ~ @Equation2866 Fin2 refa48_inst.
Proof. unfold Equation2866. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa48_inst, refa48_op in H. discriminate H. Qed.

Lemma refa48_not2873 : ~ @Equation2873 Fin2 refa48_inst.
Proof. unfold Equation2873. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa48_inst, refa48_op in H. discriminate H. Qed.

Lemma refa48_not2900 : ~ @Equation2900 Fin2 refa48_inst.
Proof. unfold Equation2900. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa48_inst, refa48_op in H. discriminate H. Qed.

Lemma refa48_not2903 : ~ @Equation2903 Fin2 refa48_inst.
Proof. unfold Equation2903. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa48_inst, refa48_op in H. discriminate H. Qed.

Lemma refa48_not2910 : ~ @Equation2910 Fin2 refa48_inst.
Proof. unfold Equation2910. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa48_inst, refa48_op in H. discriminate H. Qed.

Lemma refa48_not2937 : ~ @Equation2937 Fin2 refa48_inst.
Proof. unfold Equation2937. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa48_inst, refa48_op in H. discriminate H. Qed.

Lemma refa48_not2940 : ~ @Equation2940 Fin2 refa48_inst.
Proof. unfold Equation2940. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa48_inst, refa48_op in H. discriminate H. Qed.

Lemma refa48_not2947 : ~ @Equation2947 Fin2 refa48_inst.
Proof. unfold Equation2947. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa48_inst, refa48_op in H. discriminate H. Qed.

Lemma refa48_not3056 : ~ @Equation3056 Fin2 refa48_inst.
Proof. unfold Equation3056. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa48_inst, refa48_op in H. discriminate H. Qed.

Lemma refa48_not3059 : ~ @Equation3059 Fin2 refa48_inst.
Proof. unfold Equation3059. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa48_inst, refa48_op in H. discriminate H. Qed.

Lemma refa48_not3066 : ~ @Equation3066 Fin2 refa48_inst.
Proof. unfold Equation3066. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa48_inst, refa48_op in H. discriminate H. Qed.

Lemma refa48_not3069 : ~ @Equation3069 Fin2 refa48_inst.
Proof. unfold Equation3069. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa48_inst, refa48_op in H. discriminate H. Qed.

Lemma refa48_not3076 : ~ @Equation3076 Fin2 refa48_inst.
Proof. unfold Equation3076. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa48_inst, refa48_op in H. discriminate H. Qed.

Lemma refa48_not3079 : ~ @Equation3079 Fin2 refa48_inst.
Proof. unfold Equation3079. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa48_inst, refa48_op in H. discriminate H. Qed.

Lemma refa48_not3103 : ~ @Equation3103 Fin2 refa48_inst.
Proof. unfold Equation3103. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa48_inst, refa48_op in H. discriminate H. Qed.

Lemma refa48_not3106 : ~ @Equation3106 Fin2 refa48_inst.
Proof. unfold Equation3106. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa48_inst, refa48_op in H. discriminate H. Qed.

Lemma refa48_not3113 : ~ @Equation3113 Fin2 refa48_inst.
Proof. unfold Equation3113. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa48_inst, refa48_op in H. discriminate H. Qed.

Lemma refa48_not3116 : ~ @Equation3116 Fin2 refa48_inst.
Proof. unfold Equation3116. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa48_inst, refa48_op in H. discriminate H. Qed.

Lemma refa48_not3140 : ~ @Equation3140 Fin2 refa48_inst.
Proof. unfold Equation3140. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa48_inst, refa48_op in H. discriminate H. Qed.

Lemma refa48_not3143 : ~ @Equation3143 Fin2 refa48_inst.
Proof. unfold Equation3143. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa48_inst, refa48_op in H. discriminate H. Qed.

Lemma refa48_not3150 : ~ @Equation3150 Fin2 refa48_inst.
Proof. unfold Equation3150. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa48_inst, refa48_op in H. discriminate H. Qed.

Lemma refa48_not3254 : ~ @Equation3254 Fin2 refa48_inst.
Proof. unfold Equation3254. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa48_inst, refa48_op in H. discriminate H. Qed.

Lemma refa48_not3256 : ~ @Equation3256 Fin2 refa48_inst.
Proof. unfold Equation3256. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa48_inst, refa48_op in H. discriminate H. Qed.

Lemma refa48_not3259 : ~ @Equation3259 Fin2 refa48_inst.
Proof. unfold Equation3259. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa48_inst, refa48_op in H. discriminate H. Qed.

Lemma refa48_not3262 : ~ @Equation3262 Fin2 refa48_inst.
Proof. unfold Equation3262. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa48_inst, refa48_op in H. discriminate H. Qed.

Lemma refa48_not3269 : ~ @Equation3269 Fin2 refa48_inst.
Proof. unfold Equation3269. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa48_inst, refa48_op in H. discriminate H. Qed.

Lemma refa48_not3272 : ~ @Equation3272 Fin2 refa48_inst.
Proof. unfold Equation3272. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa48_inst, refa48_op in H. discriminate H. Qed.

Lemma refa48_not3279 : ~ @Equation3279 Fin2 refa48_inst.
Proof. unfold Equation3279. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa48_inst, refa48_op in H. discriminate H. Qed.

Lemma refa48_not3308 : ~ @Equation3308 Fin2 refa48_inst.
Proof. unfold Equation3308. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa48_inst, refa48_op in H. discriminate H. Qed.

Lemma refa48_not3315 : ~ @Equation3315 Fin2 refa48_inst.
Proof. unfold Equation3315. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa48_inst, refa48_op in H. discriminate H. Qed.

Lemma refa48_not3318 : ~ @Equation3318 Fin2 refa48_inst.
Proof. unfold Equation3318. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa48_inst, refa48_op in H. discriminate H. Qed.

Lemma refa48_not3342 : ~ @Equation3342 Fin2 refa48_inst.
Proof. unfold Equation3342. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa48_inst, refa48_op in H. discriminate H. Qed.

Lemma refa48_not3345 : ~ @Equation3345 Fin2 refa48_inst.
Proof. unfold Equation3345. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa48_inst, refa48_op in H. discriminate H. Qed.

Lemma refa48_not3352 : ~ @Equation3352 Fin2 refa48_inst.
Proof. unfold Equation3352. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa48_inst, refa48_op in H. discriminate H. Qed.

Lemma refa48_not3355 : ~ @Equation3355 Fin2 refa48_inst.
Proof. unfold Equation3355. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa48_inst, refa48_op in H. discriminate H. Qed.

Lemma refa48_not3457 : ~ @Equation3457 Fin2 refa48_inst.
Proof. unfold Equation3457. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa48_inst, refa48_op in H. discriminate H. Qed.

Lemma refa48_not3459 : ~ @Equation3459 Fin2 refa48_inst.
Proof. unfold Equation3459. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa48_inst, refa48_op in H. discriminate H. Qed.

Lemma refa48_not3462 : ~ @Equation3462 Fin2 refa48_inst.
Proof. unfold Equation3462. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa48_inst, refa48_op in H. discriminate H. Qed.

Lemma refa48_not3465 : ~ @Equation3465 Fin2 refa48_inst.
Proof. unfold Equation3465. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa48_inst, refa48_op in H. discriminate H. Qed.

Lemma refa48_not3472 : ~ @Equation3472 Fin2 refa48_inst.
Proof. unfold Equation3472. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa48_inst, refa48_op in H. discriminate H. Qed.

Lemma refa48_not3475 : ~ @Equation3475 Fin2 refa48_inst.
Proof. unfold Equation3475. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa48_inst, refa48_op in H. discriminate H. Qed.

Lemma refa48_not3482 : ~ @Equation3482 Fin2 refa48_inst.
Proof. unfold Equation3482. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa48_inst, refa48_op in H. discriminate H. Qed.

Lemma refa48_not3511 : ~ @Equation3511 Fin2 refa48_inst.
Proof. unfold Equation3511. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa48_inst, refa48_op in H. discriminate H. Qed.

Lemma refa48_not3518 : ~ @Equation3518 Fin2 refa48_inst.
Proof. unfold Equation3518. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa48_inst, refa48_op in H. discriminate H. Qed.

Lemma refa48_not3521 : ~ @Equation3521 Fin2 refa48_inst.
Proof. unfold Equation3521. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa48_inst, refa48_op in H. discriminate H. Qed.

Lemma refa48_not3545 : ~ @Equation3545 Fin2 refa48_inst.
Proof. unfold Equation3545. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa48_inst, refa48_op in H. discriminate H. Qed.

Lemma refa48_not3548 : ~ @Equation3548 Fin2 refa48_inst.
Proof. unfold Equation3548. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa48_inst, refa48_op in H. discriminate H. Qed.

Lemma refa48_not3555 : ~ @Equation3555 Fin2 refa48_inst.
Proof. unfold Equation3555. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa48_inst, refa48_op in H. discriminate H. Qed.

Lemma refa48_not3558 : ~ @Equation3558 Fin2 refa48_inst.
Proof. unfold Equation3558. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa48_inst, refa48_op in H. discriminate H. Qed.

Lemma refa48_not3660 : ~ @Equation3660 Fin2 refa48_inst.
Proof. unfold Equation3660. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa48_inst, refa48_op in H. discriminate H. Qed.

Lemma refa48_not3662 : ~ @Equation3662 Fin2 refa48_inst.
Proof. unfold Equation3662. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa48_inst, refa48_op in H. discriminate H. Qed.

Lemma refa48_not3665 : ~ @Equation3665 Fin2 refa48_inst.
Proof. unfold Equation3665. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa48_inst, refa48_op in H. discriminate H. Qed.

Lemma refa48_not3668 : ~ @Equation3668 Fin2 refa48_inst.
Proof. unfold Equation3668. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa48_inst, refa48_op in H. discriminate H. Qed.

Lemma refa48_not3675 : ~ @Equation3675 Fin2 refa48_inst.
Proof. unfold Equation3675. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa48_inst, refa48_op in H. discriminate H. Qed.

Lemma refa48_not3678 : ~ @Equation3678 Fin2 refa48_inst.
Proof. unfold Equation3678. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa48_inst, refa48_op in H. discriminate H. Qed.

Lemma refa48_not3685 : ~ @Equation3685 Fin2 refa48_inst.
Proof. unfold Equation3685. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa48_inst, refa48_op in H. discriminate H. Qed.

Lemma refa48_not3714 : ~ @Equation3714 Fin2 refa48_inst.
Proof. unfold Equation3714. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa48_inst, refa48_op in H. discriminate H. Qed.

Lemma refa48_not3721 : ~ @Equation3721 Fin2 refa48_inst.
Proof. unfold Equation3721. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa48_inst, refa48_op in H. discriminate H. Qed.

Lemma refa48_not3724 : ~ @Equation3724 Fin2 refa48_inst.
Proof. unfold Equation3724. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa48_inst, refa48_op in H. discriminate H. Qed.

Lemma refa48_not3748 : ~ @Equation3748 Fin2 refa48_inst.
Proof. unfold Equation3748. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa48_inst, refa48_op in H. discriminate H. Qed.

Lemma refa48_not3761 : ~ @Equation3761 Fin2 refa48_inst.
Proof. unfold Equation3761. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa48_inst, refa48_op in H. discriminate H. Qed.

Lemma refa48_not3865 : ~ @Equation3865 Fin2 refa48_inst.
Proof. unfold Equation3865. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa48_inst, refa48_op in H. discriminate H. Qed.

Lemma refa48_not3868 : ~ @Equation3868 Fin2 refa48_inst.
Proof. unfold Equation3868. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa48_inst, refa48_op in H. discriminate H. Qed.

Lemma refa48_not3871 : ~ @Equation3871 Fin2 refa48_inst.
Proof. unfold Equation3871. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa48_inst, refa48_op in H. discriminate H. Qed.

Lemma refa48_not3878 : ~ @Equation3878 Fin2 refa48_inst.
Proof. unfold Equation3878. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa48_inst, refa48_op in H. discriminate H. Qed.

Lemma refa48_not3881 : ~ @Equation3881 Fin2 refa48_inst.
Proof. unfold Equation3881. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa48_inst, refa48_op in H. discriminate H. Qed.

Lemma refa48_not3888 : ~ @Equation3888 Fin2 refa48_inst.
Proof. unfold Equation3888. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa48_inst, refa48_op in H. discriminate H. Qed.

Lemma refa48_not3917 : ~ @Equation3917 Fin2 refa48_inst.
Proof. unfold Equation3917. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa48_inst, refa48_op in H. discriminate H. Qed.

Lemma refa48_not3924 : ~ @Equation3924 Fin2 refa48_inst.
Proof. unfold Equation3924. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa48_inst, refa48_op in H. discriminate H. Qed.

Lemma refa48_not3927 : ~ @Equation3927 Fin2 refa48_inst.
Proof. unfold Equation3927. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa48_inst, refa48_op in H. discriminate H. Qed.

Lemma refa48_not3951 : ~ @Equation3951 Fin2 refa48_inst.
Proof. unfold Equation3951. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa48_inst, refa48_op in H. discriminate H. Qed.

Lemma refa48_not3954 : ~ @Equation3954 Fin2 refa48_inst.
Proof. unfold Equation3954. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa48_inst, refa48_op in H. discriminate H. Qed.

Lemma refa48_not3961 : ~ @Equation3961 Fin2 refa48_inst.
Proof. unfold Equation3961. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa48_inst, refa48_op in H. discriminate H. Qed.

Lemma refa48_not3964 : ~ @Equation3964 Fin2 refa48_inst.
Proof. unfold Equation3964. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa48_inst, refa48_op in H. discriminate H. Qed.

Lemma refa48_not4066 : ~ @Equation4066 Fin2 refa48_inst.
Proof. unfold Equation4066. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa48_inst, refa48_op in H. discriminate H. Qed.

Lemma refa48_not4068 : ~ @Equation4068 Fin2 refa48_inst.
Proof. unfold Equation4068. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa48_inst, refa48_op in H. discriminate H. Qed.

Lemma refa48_not4071 : ~ @Equation4071 Fin2 refa48_inst.
Proof. unfold Equation4071. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa48_inst, refa48_op in H. discriminate H. Qed.

Lemma refa48_not4074 : ~ @Equation4074 Fin2 refa48_inst.
Proof. unfold Equation4074. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa48_inst, refa48_op in H. discriminate H. Qed.

Lemma refa48_not4081 : ~ @Equation4081 Fin2 refa48_inst.
Proof. unfold Equation4081. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa48_inst, refa48_op in H. discriminate H. Qed.

Lemma refa48_not4084 : ~ @Equation4084 Fin2 refa48_inst.
Proof. unfold Equation4084. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa48_inst, refa48_op in H. discriminate H. Qed.

Lemma refa48_not4091 : ~ @Equation4091 Fin2 refa48_inst.
Proof. unfold Equation4091. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa48_inst, refa48_op in H. discriminate H. Qed.

Lemma refa48_not4120 : ~ @Equation4120 Fin2 refa48_inst.
Proof. unfold Equation4120. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa48_inst, refa48_op in H. discriminate H. Qed.

Lemma refa48_not4127 : ~ @Equation4127 Fin2 refa48_inst.
Proof. unfold Equation4127. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa48_inst, refa48_op in H. discriminate H. Qed.

Lemma refa48_not4130 : ~ @Equation4130 Fin2 refa48_inst.
Proof. unfold Equation4130. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa48_inst, refa48_op in H. discriminate H. Qed.

Lemma refa48_not4154 : ~ @Equation4154 Fin2 refa48_inst.
Proof. unfold Equation4154. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa48_inst, refa48_op in H. discriminate H. Qed.

Lemma refa48_not4157 : ~ @Equation4157 Fin2 refa48_inst.
Proof. unfold Equation4157. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa48_inst, refa48_op in H. discriminate H. Qed.

Lemma refa48_not4164 : ~ @Equation4164 Fin2 refa48_inst.
Proof. unfold Equation4164. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa48_inst, refa48_op in H. discriminate H. Qed.

Lemma refa48_not4167 : ~ @Equation4167 Fin2 refa48_inst.
Proof. unfold Equation4167. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa48_inst, refa48_op in H. discriminate H. Qed.

Lemma refa48_not4268 : ~ @Equation4268 Fin2 refa48_inst.
Proof. unfold Equation4268. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa48_inst, refa48_op in H. discriminate H. Qed.

Lemma refa48_not4270 : ~ @Equation4270 Fin2 refa48_inst.
Proof. unfold Equation4270. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa48_inst, refa48_op in H. discriminate H. Qed.

Lemma refa48_not4273 : ~ @Equation4273 Fin2 refa48_inst.
Proof. unfold Equation4273. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa48_inst, refa48_op in H. discriminate H. Qed.

Lemma refa48_not4276 : ~ @Equation4276 Fin2 refa48_inst.
Proof. unfold Equation4276. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa48_inst, refa48_op in H. discriminate H. Qed.

Lemma refa48_not4283 : ~ @Equation4283 Fin2 refa48_inst.
Proof. unfold Equation4283. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa48_inst, refa48_op in H. discriminate H. Qed.

Lemma refa48_not4290 : ~ @Equation4290 Fin2 refa48_inst.
Proof. unfold Equation4290. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa48_inst, refa48_op in H. discriminate H. Qed.

Lemma refa48_not4293 : ~ @Equation4293 Fin2 refa48_inst.
Proof. unfold Equation4293. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa48_inst, refa48_op in H. discriminate H. Qed.

Lemma refa48_not4314 : ~ @Equation4314 Fin2 refa48_inst.
Proof. unfold Equation4314. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa48_inst, refa48_op in H. discriminate H. Qed.

Lemma refa48_not4321 : ~ @Equation4321 Fin2 refa48_inst.
Proof. unfold Equation4321. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa48_inst, refa48_op in H. discriminate H. Qed.

Lemma refa48_not4343 : ~ @Equation4343 Fin2 refa48_inst.
Proof. unfold Equation4343. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa48_inst, refa48_op in H. discriminate H. Qed.

Lemma refa48_not4398 : ~ @Equation4398 Fin2 refa48_inst.
Proof. unfold Equation4398. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa48_inst, refa48_op in H. discriminate H. Qed.

Lemma refa48_not4405 : ~ @Equation4405 Fin2 refa48_inst.
Proof. unfold Equation4405. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa48_inst, refa48_op in H. discriminate H. Qed.

Lemma refa48_not4408 : ~ @Equation4408 Fin2 refa48_inst.
Proof. unfold Equation4408. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa48_inst, refa48_op in H. discriminate H. Qed.

Lemma refa48_not4433 : ~ @Equation4433 Fin2 refa48_inst.
Proof. unfold Equation4433. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa48_inst, refa48_op in H. discriminate H. Qed.

Lemma refa48_not4436 : ~ @Equation4436 Fin2 refa48_inst.
Proof. unfold Equation4436. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa48_inst, refa48_op in H. discriminate H. Qed.

Lemma refa48_not4443 : ~ @Equation4443 Fin2 refa48_inst.
Proof. unfold Equation4443. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa48_inst, refa48_op in H. discriminate H. Qed.

Lemma refa48_not4472 : ~ @Equation4472 Fin2 refa48_inst.
Proof. unfold Equation4472. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa48_inst, refa48_op in H. discriminate H. Qed.

Lemma refa48_not4479 : ~ @Equation4479 Fin2 refa48_inst.
Proof. unfold Equation4479. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa48_inst, refa48_op in H. discriminate H. Qed.

Lemma refa48_not4482 : ~ @Equation4482 Fin2 refa48_inst.
Proof. unfold Equation4482. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa48_inst, refa48_op in H. discriminate H. Qed.

Lemma refa48_not4583 : ~ @Equation4583 Fin2 refa48_inst.
Proof. unfold Equation4583. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa48_inst, refa48_op in H. discriminate H. Qed.

Lemma refa48_not4585 : ~ @Equation4585 Fin2 refa48_inst.
Proof. unfold Equation4585. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa48_inst, refa48_op in H. discriminate H. Qed.

Lemma refa48_not4588 : ~ @Equation4588 Fin2 refa48_inst.
Proof. unfold Equation4588. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa48_inst, refa48_op in H. discriminate H. Qed.

Lemma refa48_not4591 : ~ @Equation4591 Fin2 refa48_inst.
Proof. unfold Equation4591. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa48_inst, refa48_op in H. discriminate H. Qed.

Lemma refa48_not4598 : ~ @Equation4598 Fin2 refa48_inst.
Proof. unfold Equation4598. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa48_inst, refa48_op in H. discriminate H. Qed.

Lemma refa48_not4605 : ~ @Equation4605 Fin2 refa48_inst.
Proof. unfold Equation4605. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa48_inst, refa48_op in H. discriminate H. Qed.

Lemma refa48_not4608 : ~ @Equation4608 Fin2 refa48_inst.
Proof. unfold Equation4608. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa48_inst, refa48_op in H. discriminate H. Qed.

Lemma refa48_not4629 : ~ @Equation4629 Fin2 refa48_inst.
Proof. unfold Equation4629. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa48_inst, refa48_op in H. discriminate H. Qed.

Lemma refa48_not4636 : ~ @Equation4636 Fin2 refa48_inst.
Proof. unfold Equation4636. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa48_inst, refa48_op in H. discriminate H. Qed.

Lemma refa48_not4658 : ~ @Equation4658 Fin2 refa48_inst.
Proof. unfold Equation4658. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa48_inst, refa48_op in H. discriminate H. Qed.

(** ---- refa480 (Fin4) ---- *)

Definition refa480_op (x y : Fin4) : Fin4 :=
  match x, y with
  | F4_0, F4_0 => F4_3 | F4_0, F4_1 => F4_2 | F4_0, F4_2 => F4_0 | F4_0, F4_3 => F4_1
  | F4_1, F4_0 => F4_3 | F4_1, F4_1 => F4_2 | F4_1, F4_2 => F4_0 | F4_1, F4_3 => F4_1
  | F4_2, F4_0 => F4_1 | F4_2, F4_1 => F4_0 | F4_2, F4_2 => F4_2 | F4_2, F4_3 => F4_3
  | F4_3, F4_0 => F4_1 | F4_3, F4_1 => F4_0 | F4_3, F4_2 => F4_3 | F4_3, F4_3 => F4_2
  end.

#[local] Instance refa480_inst : Magma Fin4 := {| magma_op := refa480_op |}.

Lemma refa480_sat676 : @Equation676 Fin4 refa480_inst.
Proof. unfold Equation676, magma_op, refa480_inst, refa480_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa480_not1434 : ~ @Equation1434 Fin4 refa480_inst.
Proof. unfold Equation1434. intro H. specialize (H F4_0 F4_2). unfold magma_op, refa480_inst, refa480_op in H. discriminate H. Qed.

Lemma refa480_not3887 : ~ @Equation3887 Fin4 refa480_inst.
Proof. unfold Equation3887. intro H. specialize (H F4_2 F4_0). unfold magma_op, refa480_inst, refa480_op in H. discriminate H. Qed.

Lemma refa480_not4275 : ~ @Equation4275 Fin4 refa480_inst.
Proof. unfold Equation4275. intro H. specialize (H F4_0 F4_2). unfold magma_op, refa480_inst, refa480_op in H. discriminate H. Qed.

(** ---- refa481 (Fin4) ---- *)

Definition refa481_op (x y : Fin4) : Fin4 :=
  match x, y with
  | F4_0, F4_0 => F4_0 | F4_0, F4_1 => F4_3 | F4_0, F4_2 => F4_2 | F4_0, F4_3 => F4_3
  | F4_1, F4_0 => F4_3 | F4_1, F4_1 => F4_2 | F4_1, F4_2 => F4_1 | F4_1, F4_3 => F4_0
  | F4_2, F4_0 => F4_2 | F4_2, F4_1 => F4_1 | F4_2, F4_2 => F4_0 | F4_2, F4_3 => F4_1
  | F4_3, F4_0 => F4_3 | F4_3, F4_1 => F4_2 | F4_3, F4_2 => F4_1 | F4_3, F4_3 => F4_0
  end.

#[local] Instance refa481_inst : Magma Fin4 := {| magma_op := refa481_op |}.

Lemma refa481_sat1432 : @Equation1432 Fin4 refa481_inst.
Proof. unfold Equation1432, magma_op, refa481_inst, refa481_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa481_not3511 : ~ @Equation3511 Fin4 refa481_inst.
Proof. unfold Equation3511. intro H. specialize (H F4_1 F4_0). unfold magma_op, refa481_inst, refa481_op in H. discriminate H. Qed.

(** ---- refa482 (Fin4) ---- *)

Definition refa482_op (x y : Fin4) : Fin4 :=
  match x, y with
  | F4_0, F4_0 => F4_0 | F4_0, F4_1 => F4_2 | F4_0, F4_2 => F4_3 | F4_0, F4_3 => F4_1
  | F4_1, F4_0 => F4_2 | F4_1, F4_1 => F4_0 | F4_1, F4_2 => F4_1 | F4_1, F4_3 => F4_3
  | F4_2, F4_0 => F4_3 | F4_2, F4_1 => F4_1 | F4_2, F4_2 => F4_0 | F4_2, F4_3 => F4_2
  | F4_3, F4_0 => F4_1 | F4_3, F4_1 => F4_3 | F4_3, F4_2 => F4_2 | F4_3, F4_3 => F4_0
  end.

#[local] Instance refa482_inst : Magma Fin4 := {| magma_op := refa482_op |}.

Lemma refa482_sat125 : @Equation125 Fin4 refa482_inst.
Proof. unfold Equation125, magma_op, refa482_inst, refa482_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa482_sat222 : @Equation222 Fin4 refa482_inst.
Proof. unfold Equation222, magma_op, refa482_inst, refa482_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa482_sat280 : @Equation280 Fin4 refa482_inst.
Proof. unfold Equation280, magma_op, refa482_inst, refa482_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa482_not151 : ~ @Equation151 Fin4 refa482_inst.
Proof. unfold Equation151. intro H. specialize (H F4_1). unfold magma_op, refa482_inst, refa482_op in H. discriminate H. Qed.

Lemma refa482_not2441 : ~ @Equation2441 Fin4 refa482_inst.
Proof. unfold Equation2441. intro H. specialize (H F4_1). unfold magma_op, refa482_inst, refa482_op in H. discriminate H. Qed.

(** ---- refa483 (Fin4) ---- *)

Definition refa483_op (x y : Fin4) : Fin4 :=
  match x, y with
  | F4_0, F4_0 => F4_3 | F4_0, F4_1 => F4_0 | F4_0, F4_2 => F4_2 | F4_0, F4_3 => F4_3
  | F4_1, F4_0 => F4_3 | F4_1, F4_1 => F4_3 | F4_1, F4_2 => F4_0 | F4_1, F4_3 => F4_3
  | F4_2, F4_0 => F4_0 | F4_2, F4_1 => F4_1 | F4_2, F4_2 => F4_0 | F4_2, F4_3 => F4_3
  | F4_3, F4_0 => F4_0 | F4_3, F4_1 => F4_1 | F4_3, F4_2 => F4_2 | F4_3, F4_3 => F4_2
  end.

#[local] Instance refa483_inst : Magma Fin4 := {| magma_op := refa483_op |}.

Lemma refa483_sat2310 : @Equation2310 Fin4 refa483_inst.
Proof. unfold Equation2310, magma_op, refa483_inst, refa483_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa483_not2253 : ~ @Equation2253 Fin4 refa483_inst.
Proof. unfold Equation2253. intro H. specialize (H F4_1 F4_3). unfold magma_op, refa483_inst, refa483_op in H. discriminate H. Qed.

Lemma refa483_not2327 : ~ @Equation2327 Fin4 refa483_inst.
Proof. unfold Equation2327. intro H. specialize (H F4_3 F4_1). unfold magma_op, refa483_inst, refa483_op in H. discriminate H. Qed.

Lemma refa483_not3509 : ~ @Equation3509 Fin4 refa483_inst.
Proof. unfold Equation3509. intro H. specialize (H F4_0 F4_3). unfold magma_op, refa483_inst, refa483_op in H. discriminate H. Qed.

Lemma refa483_not4128 : ~ @Equation4128 Fin4 refa483_inst.
Proof. unfold Equation4128. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa483_inst, refa483_op in H. discriminate H. Qed.

(** ---- refa484 (Fin4) ---- *)

Definition refa484_op (x y : Fin4) : Fin4 :=
  match x, y with
  | F4_0, F4_0 => F4_0 | F4_0, F4_1 => F4_3 | F4_0, F4_2 => F4_0 | F4_0, F4_3 => F4_1
  | F4_1, F4_0 => F4_2 | F4_1, F4_1 => F4_2 | F4_1, F4_2 => F4_1 | F4_1, F4_3 => F4_1
  | F4_2, F4_0 => F4_2 | F4_2, F4_1 => F4_2 | F4_2, F4_2 => F4_2 | F4_2, F4_3 => F4_2
  | F4_3, F4_0 => F4_2 | F4_3, F4_1 => F4_3 | F4_3, F4_2 => F4_3 | F4_3, F4_3 => F4_2
  end.

#[local] Instance refa484_inst : Magma Fin4 := {| magma_op := refa484_op |}.

Lemma refa484_sat840 : @Equation840 Fin4 refa484_inst.
Proof. unfold Equation840, magma_op, refa484_inst, refa484_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa484_not818 : ~ @Equation818 Fin4 refa484_inst.
Proof. unfold Equation818. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa484_inst, refa484_op in H. discriminate H. Qed.

(** ---- refa485 (Fin4) ---- *)

Definition refa485_op (x y : Fin4) : Fin4 :=
  match x, y with
  | F4_0, F4_0 => F4_3 | F4_0, F4_1 => F4_1 | F4_0, F4_2 => F4_3 | F4_0, F4_3 => F4_1
  | F4_1, F4_0 => F4_3 | F4_1, F4_1 => F4_1 | F4_1, F4_2 => F4_1 | F4_1, F4_3 => F4_1
  | F4_2, F4_0 => F4_3 | F4_2, F4_1 => F4_1 | F4_2, F4_2 => F4_0 | F4_2, F4_3 => F4_1
  | F4_3, F4_0 => F4_3 | F4_3, F4_1 => F4_1 | F4_3, F4_2 => F4_1 | F4_3, F4_3 => F4_1
  end.

#[local] Instance refa485_inst : Magma Fin4 := {| magma_op := refa485_op |}.

Lemma refa485_sat4328 : @Equation4328 Fin4 refa485_inst.
Proof. unfold Equation4328, magma_op, refa485_inst, refa485_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa485_not4268 : ~ @Equation4268 Fin4 refa485_inst.
Proof. unfold Equation4268. intro H. specialize (H F4_2 F4_0). unfold magma_op, refa485_inst, refa485_op in H. discriminate H. Qed.

Lemma refa485_not4269 : ~ @Equation4269 Fin4 refa485_inst.
Proof. unfold Equation4269. intro H. specialize (H F4_2 F4_0). unfold magma_op, refa485_inst, refa485_op in H. discriminate H. Qed.

Lemma refa485_not4270 : ~ @Equation4270 Fin4 refa485_inst.
Proof. unfold Equation4270. intro H. specialize (H F4_0 F4_2). unfold magma_op, refa485_inst, refa485_op in H. discriminate H. Qed.

Lemma refa485_not4273 : ~ @Equation4273 Fin4 refa485_inst.
Proof. unfold Equation4273. intro H. specialize (H F4_2 F4_0). unfold magma_op, refa485_inst, refa485_op in H. discriminate H. Qed.

Lemma refa485_not4275 : ~ @Equation4275 Fin4 refa485_inst.
Proof. unfold Equation4275. intro H. specialize (H F4_2 F4_0). unfold magma_op, refa485_inst, refa485_op in H. discriminate H. Qed.

Lemma refa485_not4276 : ~ @Equation4276 Fin4 refa485_inst.
Proof. unfold Equation4276. intro H. specialize (H F4_0 F4_2). unfold magma_op, refa485_inst, refa485_op in H. discriminate H. Qed.

Lemma refa485_not4284 : ~ @Equation4284 Fin4 refa485_inst.
Proof. unfold Equation4284. intro H. specialize (H F4_0 F4_2). unfold magma_op, refa485_inst, refa485_op in H. discriminate H. Qed.

Lemma refa485_not4290 : ~ @Equation4290 Fin4 refa485_inst.
Proof. unfold Equation4290. intro H. specialize (H F4_2 F4_0). unfold magma_op, refa485_inst, refa485_op in H. discriminate H. Qed.

Lemma refa485_not4314 : ~ @Equation4314 Fin4 refa485_inst.
Proof. unfold Equation4314. intro H. specialize (H F4_0 F4_2). unfold magma_op, refa485_inst, refa485_op in H. discriminate H. Qed.

Lemma refa485_not4320 : ~ @Equation4320 Fin4 refa485_inst.
Proof. unfold Equation4320. intro H. specialize (H F4_2 F4_0). unfold magma_op, refa485_inst, refa485_op in H. discriminate H. Qed.

Lemma refa485_not4343 : ~ @Equation4343 Fin4 refa485_inst.
Proof. unfold Equation4343. intro H. specialize (H F4_0 F4_2). unfold magma_op, refa485_inst, refa485_op in H. discriminate H. Qed.

(** ---- refa486 (Fin4) ---- *)

Definition refa486_op (x y : Fin4) : Fin4 :=
  match x, y with
  | F4_0, F4_0 => F4_2 | F4_0, F4_1 => F4_0 | F4_0, F4_2 => F4_0 | F4_0, F4_3 => F4_3
  | F4_1, F4_0 => F4_2 | F4_1, F4_1 => F4_2 | F4_1, F4_2 => F4_1 | F4_1, F4_3 => F4_3
  | F4_2, F4_0 => F4_0 | F4_2, F4_1 => F4_3 | F4_2, F4_2 => F4_3 | F4_2, F4_3 => F4_2
  | F4_3, F4_0 => F4_3 | F4_3, F4_1 => F4_1 | F4_3, F4_2 => F4_2 | F4_3, F4_3 => F4_0
  end.

#[local] Instance refa486_inst : Magma Fin4 := {| magma_op := refa486_op |}.

Lemma refa486_sat2540 : @Equation2540 Fin4 refa486_inst.
Proof. unfold Equation2540, magma_op, refa486_inst, refa486_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa486_not4065 : ~ @Equation4065 Fin4 refa486_inst.
Proof. unfold Equation4065. intro H. specialize (H F4_1). unfold magma_op, refa486_inst, refa486_op in H. discriminate H. Qed.

(** ---- refa487 (Fin4) ---- *)

Definition refa487_op (x y : Fin4) : Fin4 :=
  match x, y with
  | F4_0, F4_0 => F4_3 | F4_0, F4_1 => F4_2 | F4_0, F4_2 => F4_2 | F4_0, F4_3 => F4_3
  | F4_1, F4_0 => F4_3 | F4_1, F4_1 => F4_3 | F4_1, F4_2 => F4_3 | F4_1, F4_3 => F4_3
  | F4_2, F4_0 => F4_1 | F4_2, F4_1 => F4_1 | F4_2, F4_2 => F4_0 | F4_2, F4_3 => F4_0
  | F4_3, F4_0 => F4_0 | F4_3, F4_1 => F4_0 | F4_3, F4_2 => F4_0 | F4_3, F4_3 => F4_0
  end.

#[local] Instance refa487_inst : Magma Fin4 := {| magma_op := refa487_op |}.

Lemma refa487_sat3085 : @Equation3085 Fin4 refa487_inst.
Proof. unfold Equation3085, magma_op, refa487_inst, refa487_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa487_not3052 : ~ @Equation3052 Fin4 refa487_inst.
Proof. unfold Equation3052. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa487_inst, refa487_op in H. discriminate H. Qed.

Lemma refa487_not3058 : ~ @Equation3058 Fin4 refa487_inst.
Proof. unfold Equation3058. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa487_inst, refa487_op in H. discriminate H. Qed.

Lemma refa487_not3068 : ~ @Equation3068 Fin4 refa487_inst.
Proof. unfold Equation3068. intro H. specialize (H F4_1 F4_0). unfold magma_op, refa487_inst, refa487_op in H. discriminate H. Qed.

Lemma refa487_not3253 : ~ @Equation3253 Fin4 refa487_inst.
Proof. unfold Equation3253. intro H. specialize (H F4_2). unfold magma_op, refa487_inst, refa487_op in H. discriminate H. Qed.

Lemma refa487_not3467 : ~ @Equation3467 Fin4 refa487_inst.
Proof. unfold Equation3467. intro H. specialize (H F4_0 F4_0 F4_1). unfold magma_op, refa487_inst, refa487_op in H. discriminate H. Qed.

Lemma refa487_not3512 : ~ @Equation3512 Fin4 refa487_inst.
Proof. unfold Equation3512. intro H. specialize (H F4_0 F4_2). unfold magma_op, refa487_inst, refa487_op in H. discriminate H. Qed.

Lemma refa487_not3537 : ~ @Equation3537 Fin4 refa487_inst.
Proof. unfold Equation3537. intro H. specialize (H F4_0 F4_1 F4_0). unfold magma_op, refa487_inst, refa487_op in H. discriminate H. Qed.

Lemma refa487_not4269 : ~ @Equation4269 Fin4 refa487_inst.
Proof. unfold Equation4269. intro H. specialize (H F4_0 F4_2). unfold magma_op, refa487_inst, refa487_op in H. discriminate H. Qed.

Lemma refa487_not4284 : ~ @Equation4284 Fin4 refa487_inst.
Proof. unfold Equation4284. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa487_inst, refa487_op in H. discriminate H. Qed.

Lemma refa487_not4599 : ~ @Equation4599 Fin4 refa487_inst.
Proof. unfold Equation4599. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa487_inst, refa487_op in H. discriminate H. Qed.

Lemma refa487_not4631 : ~ @Equation4631 Fin4 refa487_inst.
Proof. unfold Equation4631. intro H. specialize (H F4_0 F4_0 F4_1). unfold magma_op, refa487_inst, refa487_op in H. discriminate H. Qed.

(** ---- refa488 (Fin4) ---- *)

Definition refa488_op (x y : Fin4) : Fin4 :=
  match x, y with
  | F4_0, F4_0 => F4_2 | F4_0, F4_1 => F4_1 | F4_0, F4_2 => F4_1 | F4_0, F4_3 => F4_1
  | F4_1, F4_0 => F4_3 | F4_1, F4_1 => F4_0 | F4_1, F4_2 => F4_0 | F4_1, F4_3 => F4_3
  | F4_2, F4_0 => F4_0 | F4_2, F4_1 => F4_0 | F4_2, F4_2 => F4_3 | F4_2, F4_3 => F4_0
  | F4_3, F4_0 => F4_2 | F4_3, F4_1 => F4_2 | F4_3, F4_2 => F4_2 | F4_3, F4_3 => F4_1
  end.

#[local] Instance refa488_inst : Magma Fin4 := {| magma_op := refa488_op |}.

Lemma refa488_sat1633 : @Equation1633 Fin4 refa488_inst.
Proof. unfold Equation1633, magma_op, refa488_inst, refa488_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa488_not151 : ~ @Equation151 Fin4 refa488_inst.
Proof. unfold Equation151. intro H. specialize (H F4_0). unfold magma_op, refa488_inst, refa488_op in H. discriminate H. Qed.

Lemma refa488_not203 : ~ @Equation203 Fin4 refa488_inst.
Proof. unfold Equation203. intro H. specialize (H F4_0). unfold magma_op, refa488_inst, refa488_op in H. discriminate H. Qed.

Lemma refa488_not1426 : ~ @Equation1426 Fin4 refa488_inst.
Proof. unfold Equation1426. intro H. specialize (H F4_3). unfold magma_op, refa488_inst, refa488_op in H. discriminate H. Qed.

Lemma refa488_not1635 : ~ @Equation1635 Fin4 refa488_inst.
Proof. unfold Equation1635. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa488_inst, refa488_op in H. discriminate H. Qed.

Lemma refa488_not1832 : ~ @Equation1832 Fin4 refa488_inst.
Proof. unfold Equation1832. intro H. specialize (H F4_1). unfold magma_op, refa488_inst, refa488_op in H. discriminate H. Qed.

Lemma refa488_not2238 : ~ @Equation2238 Fin4 refa488_inst.
Proof. unfold Equation2238. intro H. specialize (H F4_0). unfold magma_op, refa488_inst, refa488_op in H. discriminate H. Qed.

Lemma refa488_not2443 : ~ @Equation2443 Fin4 refa488_inst.
Proof. unfold Equation2443. intro H. specialize (H F4_0 F4_2). unfold magma_op, refa488_inst, refa488_op in H. discriminate H. Qed.

Lemma refa488_not2446 : ~ @Equation2446 Fin4 refa488_inst.
Proof. unfold Equation2446. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa488_inst, refa488_op in H. discriminate H. Qed.

Lemma refa488_not2449 : ~ @Equation2449 Fin4 refa488_inst.
Proof. unfold Equation2449. intro H. specialize (H F4_0 F4_3). unfold magma_op, refa488_inst, refa488_op in H. discriminate H. Qed.

Lemma refa488_not3055 : ~ @Equation3055 Fin4 refa488_inst.
Proof. unfold Equation3055. intro H. specialize (H F4_2 F4_3). unfold magma_op, refa488_inst, refa488_op in H. discriminate H. Qed.

Lemma refa488_not3253 : ~ @Equation3253 Fin4 refa488_inst.
Proof. unfold Equation3253. intro H. specialize (H F4_0). unfold magma_op, refa488_inst, refa488_op in H. discriminate H. Qed.

Lemma refa488_not3457 : ~ @Equation3457 Fin4 refa488_inst.
Proof. unfold Equation3457. intro H. specialize (H F4_0 F4_2). unfold magma_op, refa488_inst, refa488_op in H. discriminate H. Qed.

Lemma refa488_not3458 : ~ @Equation3458 Fin4 refa488_inst.
Proof. unfold Equation3458. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa488_inst, refa488_op in H. discriminate H. Qed.

Lemma refa488_not3459 : ~ @Equation3459 Fin4 refa488_inst.
Proof. unfold Equation3459. intro H. specialize (H F4_0 F4_3). unfold magma_op, refa488_inst, refa488_op in H. discriminate H. Qed.

Lemma refa488_not3511 : ~ @Equation3511 Fin4 refa488_inst.
Proof. unfold Equation3511. intro H. specialize (H F4_1 F4_0). unfold magma_op, refa488_inst, refa488_op in H. discriminate H. Qed.

Lemma refa488_not3518 : ~ @Equation3518 Fin4 refa488_inst.
Proof. unfold Equation3518. intro H. specialize (H F4_0 F4_3). unfold magma_op, refa488_inst, refa488_op in H. discriminate H. Qed.

Lemma refa488_not3519 : ~ @Equation3519 Fin4 refa488_inst.
Proof. unfold Equation3519. intro H. specialize (H F4_0 F4_3). unfold magma_op, refa488_inst, refa488_op in H. discriminate H. Qed.

Lemma refa488_not4120 : ~ @Equation4120 Fin4 refa488_inst.
Proof. unfold Equation4120. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa488_inst, refa488_op in H. discriminate H. Qed.

Lemma refa488_not4121 : ~ @Equation4121 Fin4 refa488_inst.
Proof. unfold Equation4121. intro H. specialize (H F4_0 F4_2). unfold magma_op, refa488_inst, refa488_op in H. discriminate H. Qed.

Lemma refa488_not4127 : ~ @Equation4127 Fin4 refa488_inst.
Proof. unfold Equation4127. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa488_inst, refa488_op in H. discriminate H. Qed.

Lemma refa488_not4128 : ~ @Equation4128 Fin4 refa488_inst.
Proof. unfold Equation4128. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa488_inst, refa488_op in H. discriminate H. Qed.

Lemma refa488_not4130 : ~ @Equation4130 Fin4 refa488_inst.
Proof. unfold Equation4130. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa488_inst, refa488_op in H. discriminate H. Qed.

Lemma refa488_not4131 : ~ @Equation4131 Fin4 refa488_inst.
Proof. unfold Equation4131. intro H. specialize (H F4_1 F4_0). unfold magma_op, refa488_inst, refa488_op in H. discriminate H. Qed.

Lemma refa488_not4598 : ~ @Equation4598 Fin4 refa488_inst.
Proof. unfold Equation4598. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa488_inst, refa488_op in H. discriminate H. Qed.

Lemma refa488_not4599 : ~ @Equation4599 Fin4 refa488_inst.
Proof. unfold Equation4599. intro H. specialize (H F4_0 F4_2). unfold magma_op, refa488_inst, refa488_op in H. discriminate H. Qed.

Lemma refa488_not4629 : ~ @Equation4629 Fin4 refa488_inst.
Proof. unfold Equation4629. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa488_inst, refa488_op in H. discriminate H. Qed.

(** ---- refa489 (Fin4) ---- *)

Definition refa489_op (x y : Fin4) : Fin4 :=
  match x, y with
  | F4_0, F4_0 => F4_0 | F4_0, F4_1 => F4_1 | F4_0, F4_2 => F4_2 | F4_0, F4_3 => F4_3
  | F4_1, F4_0 => F4_1 | F4_1, F4_1 => F4_0 | F4_1, F4_2 => F4_3 | F4_1, F4_3 => F4_2
  | F4_2, F4_0 => F4_3 | F4_2, F4_1 => F4_2 | F4_2, F4_2 => F4_1 | F4_2, F4_3 => F4_0
  | F4_3, F4_0 => F4_2 | F4_3, F4_1 => F4_3 | F4_3, F4_2 => F4_0 | F4_3, F4_3 => F4_1
  end.

#[local] Instance refa489_inst : Magma Fin4 := {| magma_op := refa489_op |}.

Lemma refa489_sat2592 : @Equation2592 Fin4 refa489_inst.
Proof. unfold Equation2592, magma_op, refa489_inst, refa489_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa489_sat2722 : @Equation2722 Fin4 refa489_inst.
Proof. unfold Equation2722, magma_op, refa489_inst, refa489_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa489_sat2808 : @Equation2808 Fin4 refa489_inst.
Proof. unfold Equation2808, magma_op, refa489_inst, refa489_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa489_not417 : ~ @Equation417 Fin4 refa489_inst.
Proof. unfold Equation417. intro H. specialize (H F4_0 F4_2). unfold magma_op, refa489_inst, refa489_op in H. discriminate H. Qed.

Lemma refa489_not427 : ~ @Equation427 Fin4 refa489_inst.
Proof. unfold Equation427. intro H. specialize (H F4_0 F4_2). unfold magma_op, refa489_inst, refa489_op in H. discriminate H. Qed.

Lemma refa489_not440 : ~ @Equation440 Fin4 refa489_inst.
Proof. unfold Equation440. intro H. specialize (H F4_0 F4_2). unfold magma_op, refa489_inst, refa489_op in H. discriminate H. Qed.

Lemma refa489_not477 : ~ @Equation477 Fin4 refa489_inst.
Proof. unfold Equation477. intro H. specialize (H F4_0 F4_2). unfold magma_op, refa489_inst, refa489_op in H. discriminate H. Qed.

Lemma refa489_not504 : ~ @Equation504 Fin4 refa489_inst.
Proof. unfold Equation504. intro H. specialize (H F4_0 F4_2). unfold magma_op, refa489_inst, refa489_op in H. discriminate H. Qed.

Lemma refa489_not511 : ~ @Equation511 Fin4 refa489_inst.
Proof. unfold Equation511. intro H. specialize (H F4_0 F4_2). unfold magma_op, refa489_inst, refa489_op in H. discriminate H. Qed.

Lemma refa489_not614 : ~ @Equation614 Fin4 refa489_inst.
Proof. unfold Equation614. intro H. specialize (H F4_2). unfold magma_op, refa489_inst, refa489_op in H. discriminate H. Qed.

Lemma refa489_not820 : ~ @Equation820 Fin4 refa489_inst.
Proof. unfold Equation820. intro H. specialize (H F4_0 F4_2). unfold magma_op, refa489_inst, refa489_op in H. discriminate H. Qed.

Lemma refa489_not823 : ~ @Equation823 Fin4 refa489_inst.
Proof. unfold Equation823. intro H. specialize (H F4_0 F4_2). unfold magma_op, refa489_inst, refa489_op in H. discriminate H. Qed.

Lemma refa489_not825 : ~ @Equation825 Fin4 refa489_inst.
Proof. unfold Equation825. intro H. specialize (H F4_2 F4_0). unfold magma_op, refa489_inst, refa489_op in H. discriminate H. Qed.

Lemma refa489_not833 : ~ @Equation833 Fin4 refa489_inst.
Proof. unfold Equation833. intro H. specialize (H F4_2 F4_0). unfold magma_op, refa489_inst, refa489_op in H. discriminate H. Qed.

Lemma refa489_not835 : ~ @Equation835 Fin4 refa489_inst.
Proof. unfold Equation835. intro H. specialize (H F4_0 F4_2). unfold magma_op, refa489_inst, refa489_op in H. discriminate H. Qed.

Lemma refa489_not842 : ~ @Equation842 Fin4 refa489_inst.
Proof. unfold Equation842. intro H. specialize (H F4_0 F4_2). unfold magma_op, refa489_inst, refa489_op in H. discriminate H. Qed.

Lemma refa489_not846 : ~ @Equation846 Fin4 refa489_inst.
Proof. unfold Equation846. intro H. specialize (H F4_2 F4_0). unfold magma_op, refa489_inst, refa489_op in H. discriminate H. Qed.

Lemma refa489_not870 : ~ @Equation870 Fin4 refa489_inst.
Proof. unfold Equation870. intro H. specialize (H F4_0 F4_2). unfold magma_op, refa489_inst, refa489_op in H. discriminate H. Qed.

Lemma refa489_not872 : ~ @Equation872 Fin4 refa489_inst.
Proof. unfold Equation872. intro H. specialize (H F4_2 F4_0). unfold magma_op, refa489_inst, refa489_op in H. discriminate H. Qed.

Lemma refa489_not879 : ~ @Equation879 Fin4 refa489_inst.
Proof. unfold Equation879. intro H. specialize (H F4_2 F4_0). unfold magma_op, refa489_inst, refa489_op in H. discriminate H. Qed.

Lemma refa489_not883 : ~ @Equation883 Fin4 refa489_inst.
Proof. unfold Equation883. intro H. specialize (H F4_0 F4_2). unfold magma_op, refa489_inst, refa489_op in H. discriminate H. Qed.

Lemma refa489_not906 : ~ @Equation906 Fin4 refa489_inst.
Proof. unfold Equation906. intro H. specialize (H F4_0 F4_2). unfold magma_op, refa489_inst, refa489_op in H. discriminate H. Qed.

Lemma refa489_not917 : ~ @Equation917 Fin4 refa489_inst.
Proof. unfold Equation917. intro H. specialize (H F4_2 F4_0). unfold magma_op, refa489_inst, refa489_op in H. discriminate H. Qed.

Lemma refa489_not1023 : ~ @Equation1023 Fin4 refa489_inst.
Proof. unfold Equation1023. intro H. specialize (H F4_0 F4_2). unfold magma_op, refa489_inst, refa489_op in H. discriminate H. Qed.

Lemma refa489_not1028 : ~ @Equation1028 Fin4 refa489_inst.
Proof. unfold Equation1028. intro H. specialize (H F4_0 F4_2). unfold magma_op, refa489_inst, refa489_op in H. discriminate H. Qed.

Lemma refa489_not1038 : ~ @Equation1038 Fin4 refa489_inst.
Proof. unfold Equation1038. intro H. specialize (H F4_0 F4_2). unfold magma_op, refa489_inst, refa489_op in H. discriminate H. Qed.

Lemma refa489_not1049 : ~ @Equation1049 Fin4 refa489_inst.
Proof. unfold Equation1049. intro H. specialize (H F4_0 F4_2). unfold magma_op, refa489_inst, refa489_op in H. discriminate H. Qed.

Lemma refa489_not1082 : ~ @Equation1082 Fin4 refa489_inst.
Proof. unfold Equation1082. intro H. specialize (H F4_0 F4_2). unfold magma_op, refa489_inst, refa489_op in H. discriminate H. Qed.

Lemma refa489_not1109 : ~ @Equation1109 Fin4 refa489_inst.
Proof. unfold Equation1109. intro H. specialize (H F4_0 F4_2). unfold magma_op, refa489_inst, refa489_op in H. discriminate H. Qed.

Lemma refa489_not1223 : ~ @Equation1223 Fin4 refa489_inst.
Proof. unfold Equation1223. intro H. specialize (H F4_2). unfold magma_op, refa489_inst, refa489_op in H. discriminate H. Qed.

Lemma refa489_not1426 : ~ @Equation1426 Fin4 refa489_inst.
Proof. unfold Equation1426. intro H. specialize (H F4_2). unfold magma_op, refa489_inst, refa489_op in H. discriminate H. Qed.

Lemma refa489_not1632 : ~ @Equation1632 Fin4 refa489_inst.
Proof. unfold Equation1632. intro H. specialize (H F4_0 F4_2). unfold magma_op, refa489_inst, refa489_op in H. discriminate H. Qed.

Lemma refa489_not1637 : ~ @Equation1637 Fin4 refa489_inst.
Proof. unfold Equation1637. intro H. specialize (H F4_0 F4_2). unfold magma_op, refa489_inst, refa489_op in H. discriminate H. Qed.

Lemma refa489_not1645 : ~ @Equation1645 Fin4 refa489_inst.
Proof. unfold Equation1645. intro H. specialize (H F4_0 F4_2). unfold magma_op, refa489_inst, refa489_op in H. discriminate H. Qed.

Lemma refa489_not1654 : ~ @Equation1654 Fin4 refa489_inst.
Proof. unfold Equation1654. intro H. specialize (H F4_0 F4_2). unfold magma_op, refa489_inst, refa489_op in H. discriminate H. Qed.

Lemma refa489_not1684 : ~ @Equation1684 Fin4 refa489_inst.
Proof. unfold Equation1684. intro H. specialize (H F4_0 F4_2). unfold magma_op, refa489_inst, refa489_op in H. discriminate H. Qed.

Lemma refa489_not1838 : ~ @Equation1838 Fin4 refa489_inst.
Proof. unfold Equation1838. intro H. specialize (H F4_0 F4_2). unfold magma_op, refa489_inst, refa489_op in H. discriminate H. Qed.

Lemma refa489_not1857 : ~ @Equation1857 Fin4 refa489_inst.
Proof. unfold Equation1857. intro H. specialize (H F4_0 F4_2). unfold magma_op, refa489_inst, refa489_op in H. discriminate H. Qed.

Lemma refa489_not1887 : ~ @Equation1887 Fin4 refa489_inst.
Proof. unfold Equation1887. intro H. specialize (H F4_0 F4_2). unfold magma_op, refa489_inst, refa489_op in H. discriminate H. Qed.

Lemma refa489_not1894 : ~ @Equation1894 Fin4 refa489_inst.
Proof. unfold Equation1894. intro H. specialize (H F4_0 F4_2). unfold magma_op, refa489_inst, refa489_op in H. discriminate H. Qed.

Lemma refa489_not1925 : ~ @Equation1925 Fin4 refa489_inst.
Proof. unfold Equation1925. intro H. specialize (H F4_0 F4_2). unfold magma_op, refa489_inst, refa489_op in H. discriminate H. Qed.

Lemma refa489_not2035 : ~ @Equation2035 Fin4 refa489_inst.
Proof. unfold Equation2035. intro H. specialize (H F4_2). unfold magma_op, refa489_inst, refa489_op in H. discriminate H. Qed.

Lemma refa489_not2238 : ~ @Equation2238 Fin4 refa489_inst.
Proof. unfold Equation2238. intro H. specialize (H F4_2). unfold magma_op, refa489_inst, refa489_op in H. discriminate H. Qed.

Lemma refa489_not2444 : ~ @Equation2444 Fin4 refa489_inst.
Proof. unfold Equation2444. intro H. specialize (H F4_0 F4_2). unfold magma_op, refa489_inst, refa489_op in H. discriminate H. Qed.

Lemma refa489_not2449 : ~ @Equation2449 Fin4 refa489_inst.
Proof. unfold Equation2449. intro H. specialize (H F4_0 F4_2). unfold magma_op, refa489_inst, refa489_op in H. discriminate H. Qed.

Lemma refa489_not2457 : ~ @Equation2457 Fin4 refa489_inst.
Proof. unfold Equation2457. intro H. specialize (H F4_0 F4_2). unfold magma_op, refa489_inst, refa489_op in H. discriminate H. Qed.

Lemma refa489_not2466 : ~ @Equation2466 Fin4 refa489_inst.
Proof. unfold Equation2466. intro H. specialize (H F4_0 F4_2). unfold magma_op, refa489_inst, refa489_op in H. discriminate H. Qed.

Lemma refa489_not2496 : ~ @Equation2496 Fin4 refa489_inst.
Proof. unfold Equation2496. intro H. specialize (H F4_0 F4_2). unfold magma_op, refa489_inst, refa489_op in H. discriminate H. Qed.

Lemma refa489_not2530 : ~ @Equation2530 Fin4 refa489_inst.
Proof. unfold Equation2530. intro H. specialize (H F4_0 F4_2). unfold magma_op, refa489_inst, refa489_op in H. discriminate H. Qed.

Lemma refa489_not2541 : ~ @Equation2541 Fin4 refa489_inst.
Proof. unfold Equation2541. intro H. specialize (H F4_0 F4_2). unfold magma_op, refa489_inst, refa489_op in H. discriminate H. Qed.

Lemma refa489_not2647 : ~ @Equation2647 Fin4 refa489_inst.
Proof. unfold Equation2647. intro H. specialize (H F4_0 F4_2). unfold magma_op, refa489_inst, refa489_op in H. discriminate H. Qed.

Lemma refa489_not2652 : ~ @Equation2652 Fin4 refa489_inst.
Proof. unfold Equation2652. intro H. specialize (H F4_0 F4_2). unfold magma_op, refa489_inst, refa489_op in H. discriminate H. Qed.

Lemma refa489_not2662 : ~ @Equation2662 Fin4 refa489_inst.
Proof. unfold Equation2662. intro H. specialize (H F4_0 F4_2). unfold magma_op, refa489_inst, refa489_op in H. discriminate H. Qed.

Lemma refa489_not2697 : ~ @Equation2697 Fin4 refa489_inst.
Proof. unfold Equation2697. intro H. specialize (H F4_0 F4_2). unfold magma_op, refa489_inst, refa489_op in H. discriminate H. Qed.

Lemma refa489_not2744 : ~ @Equation2744 Fin4 refa489_inst.
Proof. unfold Equation2744. intro H. specialize (H F4_0 F4_2). unfold magma_op, refa489_inst, refa489_op in H. discriminate H. Qed.

Lemma refa489_not2847 : ~ @Equation2847 Fin4 refa489_inst.
Proof. unfold Equation2847. intro H. specialize (H F4_2). unfold magma_op, refa489_inst, refa489_op in H. discriminate H. Qed.

Lemma refa489_not3058 : ~ @Equation3058 Fin4 refa489_inst.
Proof. unfold Equation3058. intro H. specialize (H F4_0 F4_2). unfold magma_op, refa489_inst, refa489_op in H. discriminate H. Qed.

Lemma refa489_not3066 : ~ @Equation3066 Fin4 refa489_inst.
Proof. unfold Equation3066. intro H. specialize (H F4_0 F4_2). unfold magma_op, refa489_inst, refa489_op in H. discriminate H. Qed.

Lemma refa489_not3075 : ~ @Equation3075 Fin4 refa489_inst.
Proof. unfold Equation3075. intro H. specialize (H F4_0 F4_2). unfold magma_op, refa489_inst, refa489_op in H. discriminate H. Qed.

Lemma refa489_not3105 : ~ @Equation3105 Fin4 refa489_inst.
Proof. unfold Equation3105. intro H. specialize (H F4_0 F4_2). unfold magma_op, refa489_inst, refa489_op in H. discriminate H. Qed.

Lemma refa489_not3116 : ~ @Equation3116 Fin4 refa489_inst.
Proof. unfold Equation3116. intro H. specialize (H F4_0 F4_2). unfold magma_op, refa489_inst, refa489_op in H. discriminate H. Qed.

Lemma refa489_not3150 : ~ @Equation3150 Fin4 refa489_inst.
Proof. unfold Equation3150. intro H. specialize (H F4_0 F4_2). unfold magma_op, refa489_inst, refa489_op in H. discriminate H. Qed.

Lemma refa489_not3256 : ~ @Equation3256 Fin4 refa489_inst.
Proof. unfold Equation3256. intro H. specialize (H F4_0 F4_2). unfold magma_op, refa489_inst, refa489_op in H. discriminate H. Qed.

Lemma refa489_not3259 : ~ @Equation3259 Fin4 refa489_inst.
Proof. unfold Equation3259. intro H. specialize (H F4_0 F4_2). unfold magma_op, refa489_inst, refa489_op in H. discriminate H. Qed.

Lemma refa489_not3308 : ~ @Equation3308 Fin4 refa489_inst.
Proof. unfold Equation3308. intro H. specialize (H F4_0 F4_2). unfold magma_op, refa489_inst, refa489_op in H. discriminate H. Qed.

Lemma refa489_not3315 : ~ @Equation3315 Fin4 refa489_inst.
Proof. unfold Equation3315. intro H. specialize (H F4_0 F4_2). unfold magma_op, refa489_inst, refa489_op in H. discriminate H. Qed.

Lemma refa489_not3342 : ~ @Equation3342 Fin4 refa489_inst.
Proof. unfold Equation3342. intro H. specialize (H F4_0 F4_2). unfold magma_op, refa489_inst, refa489_op in H. discriminate H. Qed.

Lemma refa489_not3456 : ~ @Equation3456 Fin4 refa489_inst.
Proof. unfold Equation3456. intro H. specialize (H F4_2). unfold magma_op, refa489_inst, refa489_op in H. discriminate H. Qed.

Lemma refa489_not3659 : ~ @Equation3659 Fin4 refa489_inst.
Proof. unfold Equation3659. intro H. specialize (H F4_2). unfold magma_op, refa489_inst, refa489_op in H. discriminate H. Qed.

Lemma refa489_not3865 : ~ @Equation3865 Fin4 refa489_inst.
Proof. unfold Equation3865. intro H. specialize (H F4_0 F4_2). unfold magma_op, refa489_inst, refa489_op in H. discriminate H. Qed.

Lemma refa489_not3870 : ~ @Equation3870 Fin4 refa489_inst.
Proof. unfold Equation3870. intro H. specialize (H F4_0 F4_2). unfold magma_op, refa489_inst, refa489_op in H. discriminate H. Qed.

Lemma refa489_not3880 : ~ @Equation3880 Fin4 refa489_inst.
Proof. unfold Equation3880. intro H. specialize (H F4_0 F4_2). unfold magma_op, refa489_inst, refa489_op in H. discriminate H. Qed.

Lemma refa489_not3917 : ~ @Equation3917 Fin4 refa489_inst.
Proof. unfold Equation3917. intro H. specialize (H F4_0 F4_2). unfold magma_op, refa489_inst, refa489_op in H. discriminate H. Qed.

Lemma refa489_not3928 : ~ @Equation3928 Fin4 refa489_inst.
Proof. unfold Equation3928. intro H. specialize (H F4_0 F4_2). unfold magma_op, refa489_inst, refa489_op in H. discriminate H. Qed.

Lemma refa489_not3955 : ~ @Equation3955 Fin4 refa489_inst.
Proof. unfold Equation3955. intro H. specialize (H F4_0 F4_2). unfold magma_op, refa489_inst, refa489_op in H. discriminate H. Qed.

Lemma refa489_not3964 : ~ @Equation3964 Fin4 refa489_inst.
Proof. unfold Equation3964. intro H. specialize (H F4_0 F4_2). unfold magma_op, refa489_inst, refa489_op in H. discriminate H. Qed.

Lemma refa489_not4065 : ~ @Equation4065 Fin4 refa489_inst.
Proof. unfold Equation4065. intro H. specialize (H F4_2). unfold magma_op, refa489_inst, refa489_op in H. discriminate H. Qed.

Lemma refa489_not4270 : ~ @Equation4270 Fin4 refa489_inst.
Proof. unfold Equation4270. intro H. specialize (H F4_0 F4_2). unfold magma_op, refa489_inst, refa489_op in H. discriminate H. Qed.

Lemma refa489_not4273 : ~ @Equation4273 Fin4 refa489_inst.
Proof. unfold Equation4273. intro H. specialize (H F4_0 F4_2). unfold magma_op, refa489_inst, refa489_op in H. discriminate H. Qed.

Lemma refa489_not4283 : ~ @Equation4283 Fin4 refa489_inst.
Proof. unfold Equation4283. intro H. specialize (H F4_0 F4_2). unfold magma_op, refa489_inst, refa489_op in H. discriminate H. Qed.

Lemma refa489_not4290 : ~ @Equation4290 Fin4 refa489_inst.
Proof. unfold Equation4290. intro H. specialize (H F4_0 F4_2). unfold magma_op, refa489_inst, refa489_op in H. discriminate H. Qed.

Lemma refa489_not4380 : ~ @Equation4380 Fin4 refa489_inst.
Proof. unfold Equation4380. intro H. specialize (H F4_2). unfold magma_op, refa489_inst, refa489_op in H. discriminate H. Qed.

Lemma refa489_not4585 : ~ @Equation4585 Fin4 refa489_inst.
Proof. unfold Equation4585. intro H. specialize (H F4_0 F4_2). unfold magma_op, refa489_inst, refa489_op in H. discriminate H. Qed.

Lemma refa489_not4590 : ~ @Equation4590 Fin4 refa489_inst.
Proof. unfold Equation4590. intro H. specialize (H F4_0 F4_2). unfold magma_op, refa489_inst, refa489_op in H. discriminate H. Qed.

Lemma refa489_not4598 : ~ @Equation4598 Fin4 refa489_inst.
Proof. unfold Equation4598. intro H. specialize (H F4_0 F4_2). unfold magma_op, refa489_inst, refa489_op in H. discriminate H. Qed.

Lemma refa489_not4635 : ~ @Equation4635 Fin4 refa489_inst.
Proof. unfold Equation4635. intro H. specialize (H F4_0 F4_2). unfold magma_op, refa489_inst, refa489_op in H. discriminate H. Qed.

(** ---- refa49 (Fin2) ---- *)

Definition refa49_op (x y : Fin2) : Fin2 :=
  match x, y with
  | F2_0, F2_0 => F2_0 | F2_0, F2_1 => F2_1
  | F2_1, F2_0 => F2_0 | F2_1, F2_1 => F2_0
  end.

#[local] Instance refa49_inst : Magma Fin2 := {| magma_op := refa49_op |}.

Lemma refa49_sat319 : @Equation319 Fin2 refa49_inst.
Proof. unfold Equation319, magma_op, refa49_inst, refa49_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa49_sat2420 : @Equation2420 Fin2 refa49_inst.
Proof. unfold Equation2420, magma_op, refa49_inst, refa49_op. intros x y z w. destruct x, y, z, w; reflexivity. Qed.

Lemma refa49_sat2536 : @Equation2536 Fin2 refa49_inst.
Proof. unfold Equation2536, magma_op, refa49_inst, refa49_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa49_sat2782 : @Equation2782 Fin2 refa49_inst.
Proof. unfold Equation2782, magma_op, refa49_inst, refa49_op. intros x y z w. destruct x, y, z, w; reflexivity. Qed.

Lemma refa49_sat3275 : @Equation3275 Fin2 refa49_inst.
Proof. unfold Equation3275, magma_op, refa49_inst, refa49_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa49_sat3489 : @Equation3489 Fin2 refa49_inst.
Proof. unfold Equation3489, magma_op, refa49_inst, refa49_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa49_sat3529 : @Equation3529 Fin2 refa49_inst.
Proof. unfold Equation3529, magma_op, refa49_inst, refa49_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa49_sat4105 : @Equation4105 Fin2 refa49_inst.
Proof. unfold Equation4105, magma_op, refa49_inst, refa49_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa49_sat4131 : @Equation4131 Fin2 refa49_inst.
Proof. unfold Equation4131, magma_op, refa49_inst, refa49_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa49_sat4175 : @Equation4175 Fin2 refa49_inst.
Proof. unfold Equation4175, magma_op, refa49_inst, refa49_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa49_sat4362 : @Equation4362 Fin2 refa49_inst.
Proof. unfold Equation4362, magma_op, refa49_inst, refa49_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa49_sat4658 : @Equation4658 Fin2 refa49_inst.
Proof. unfold Equation4658, magma_op, refa49_inst, refa49_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa49_not47 : ~ @Equation47 Fin2 refa49_inst.
Proof. unfold Equation47. intro H. specialize (H F2_1). unfold magma_op, refa49_inst, refa49_op in H. discriminate H. Qed.

Lemma refa49_not99 : ~ @Equation99 Fin2 refa49_inst.
Proof. unfold Equation99. intro H. specialize (H F2_1). unfold magma_op, refa49_inst, refa49_op in H. discriminate H. Qed.

Lemma refa49_not151 : ~ @Equation151 Fin2 refa49_inst.
Proof. unfold Equation151. intro H. specialize (H F2_1). unfold magma_op, refa49_inst, refa49_op in H. discriminate H. Qed.

Lemma refa49_not255 : ~ @Equation255 Fin2 refa49_inst.
Proof. unfold Equation255. intro H. specialize (H F2_1). unfold magma_op, refa49_inst, refa49_op in H. discriminate H. Qed.

Lemma refa49_not359 : ~ @Equation359 Fin2 refa49_inst.
Proof. unfold Equation359. intro H. specialize (H F2_1). unfold magma_op, refa49_inst, refa49_op in H. discriminate H. Qed.

Lemma refa49_not411 : ~ @Equation411 Fin2 refa49_inst.
Proof. unfold Equation411. intro H. specialize (H F2_1). unfold magma_op, refa49_inst, refa49_op in H. discriminate H. Qed.

Lemma refa49_not614 : ~ @Equation614 Fin2 refa49_inst.
Proof. unfold Equation614. intro H. specialize (H F2_1). unfold magma_op, refa49_inst, refa49_op in H. discriminate H. Qed.

Lemma refa49_not817 : ~ @Equation817 Fin2 refa49_inst.
Proof. unfold Equation817. intro H. specialize (H F2_1). unfold magma_op, refa49_inst, refa49_op in H. discriminate H. Qed.

Lemma refa49_not1020 : ~ @Equation1020 Fin2 refa49_inst.
Proof. unfold Equation1020. intro H. specialize (H F2_1). unfold magma_op, refa49_inst, refa49_op in H. discriminate H. Qed.

Lemma refa49_not1223 : ~ @Equation1223 Fin2 refa49_inst.
Proof. unfold Equation1223. intro H. specialize (H F2_1). unfold magma_op, refa49_inst, refa49_op in H. discriminate H. Qed.

Lemma refa49_not1426 : ~ @Equation1426 Fin2 refa49_inst.
Proof. unfold Equation1426. intro H. specialize (H F2_1). unfold magma_op, refa49_inst, refa49_op in H. discriminate H. Qed.

Lemma refa49_not1630 : ~ @Equation1630 Fin2 refa49_inst.
Proof. unfold Equation1630. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa49_inst, refa49_op in H. discriminate H. Qed.

Lemma refa49_not1632 : ~ @Equation1632 Fin2 refa49_inst.
Proof. unfold Equation1632. intro H. specialize (H F2_1 F2_0). unfold magma_op, refa49_inst, refa49_op in H. discriminate H. Qed.

Lemma refa49_not1634 : ~ @Equation1634 Fin2 refa49_inst.
Proof. unfold Equation1634. intro H. specialize (H F2_1 F2_0). unfold magma_op, refa49_inst, refa49_op in H. discriminate H. Qed.

Lemma refa49_not1635 : ~ @Equation1635 Fin2 refa49_inst.
Proof. unfold Equation1635. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa49_inst, refa49_op in H. discriminate H. Qed.

Lemma refa49_not1638 : ~ @Equation1638 Fin2 refa49_inst.
Proof. unfold Equation1638. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa49_inst, refa49_op in H. discriminate H. Qed.

Lemma refa49_not1645 : ~ @Equation1645 Fin2 refa49_inst.
Proof. unfold Equation1645. intro H. specialize (H F2_1 F2_0). unfold magma_op, refa49_inst, refa49_op in H. discriminate H. Qed.

Lemma refa49_not1648 : ~ @Equation1648 Fin2 refa49_inst.
Proof. unfold Equation1648. intro H. specialize (H F2_1 F2_0). unfold magma_op, refa49_inst, refa49_op in H. discriminate H. Qed.

Lemma refa49_not1654 : ~ @Equation1654 Fin2 refa49_inst.
Proof. unfold Equation1654. intro H. specialize (H F2_1 F2_0). unfold magma_op, refa49_inst, refa49_op in H. discriminate H. Qed.

Lemma refa49_not1655 : ~ @Equation1655 Fin2 refa49_inst.
Proof. unfold Equation1655. intro H. specialize (H F2_1 F2_0). unfold magma_op, refa49_inst, refa49_op in H. discriminate H. Qed.

Lemma refa49_not1658 : ~ @Equation1658 Fin2 refa49_inst.
Proof. unfold Equation1658. intro H. specialize (H F2_1 F2_0). unfold magma_op, refa49_inst, refa49_op in H. discriminate H. Qed.

Lemma refa49_not1681 : ~ @Equation1681 Fin2 refa49_inst.
Proof. unfold Equation1681. intro H. specialize (H F2_1 F2_0). unfold magma_op, refa49_inst, refa49_op in H. discriminate H. Qed.

Lemma refa49_not1682 : ~ @Equation1682 Fin2 refa49_inst.
Proof. unfold Equation1682. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa49_inst, refa49_op in H. discriminate H. Qed.

Lemma refa49_not1684 : ~ @Equation1684 Fin2 refa49_inst.
Proof. unfold Equation1684. intro H. specialize (H F2_1 F2_0). unfold magma_op, refa49_inst, refa49_op in H. discriminate H. Qed.

Lemma refa49_not1691 : ~ @Equation1691 Fin2 refa49_inst.
Proof. unfold Equation1691. intro H. specialize (H F2_1 F2_0). unfold magma_op, refa49_inst, refa49_op in H. discriminate H. Qed.

Lemma refa49_not1694 : ~ @Equation1694 Fin2 refa49_inst.
Proof. unfold Equation1694. intro H. specialize (H F2_1 F2_0). unfold magma_op, refa49_inst, refa49_op in H. discriminate H. Qed.

Lemma refa49_not1722 : ~ @Equation1722 Fin2 refa49_inst.
Proof. unfold Equation1722. intro H. specialize (H F2_1 F2_0). unfold magma_op, refa49_inst, refa49_op in H. discriminate H. Qed.

Lemma refa49_not1728 : ~ @Equation1728 Fin2 refa49_inst.
Proof. unfold Equation1728. intro H. specialize (H F2_1 F2_0). unfold magma_op, refa49_inst, refa49_op in H. discriminate H. Qed.

Lemma refa49_not1832 : ~ @Equation1832 Fin2 refa49_inst.
Proof. unfold Equation1832. intro H. specialize (H F2_1). unfold magma_op, refa49_inst, refa49_op in H. discriminate H. Qed.

Lemma refa49_not2035 : ~ @Equation2035 Fin2 refa49_inst.
Proof. unfold Equation2035. intro H. specialize (H F2_1). unfold magma_op, refa49_inst, refa49_op in H. discriminate H. Qed.

Lemma refa49_not2244 : ~ @Equation2244 Fin2 refa49_inst.
Proof. unfold Equation2244. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa49_inst, refa49_op in H. discriminate H. Qed.

Lemma refa49_not2247 : ~ @Equation2247 Fin2 refa49_inst.
Proof. unfold Equation2247. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa49_inst, refa49_op in H. discriminate H. Qed.

Lemma refa49_not2254 : ~ @Equation2254 Fin2 refa49_inst.
Proof. unfold Equation2254. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa49_inst, refa49_op in H. discriminate H. Qed.

Lemma refa49_not2257 : ~ @Equation2257 Fin2 refa49_inst.
Proof. unfold Equation2257. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa49_inst, refa49_op in H. discriminate H. Qed.

Lemma refa49_not2264 : ~ @Equation2264 Fin2 refa49_inst.
Proof. unfold Equation2264. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa49_inst, refa49_op in H. discriminate H. Qed.

Lemma refa49_not2291 : ~ @Equation2291 Fin2 refa49_inst.
Proof. unfold Equation2291. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa49_inst, refa49_op in H. discriminate H. Qed.

Lemma refa49_not2444 : ~ @Equation2444 Fin2 refa49_inst.
Proof. unfold Equation2444. intro H. specialize (H F2_1 F2_0). unfold magma_op, refa49_inst, refa49_op in H. discriminate H. Qed.

Lemma refa49_not2447 : ~ @Equation2447 Fin2 refa49_inst.
Proof. unfold Equation2447. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa49_inst, refa49_op in H. discriminate H. Qed.

Lemma refa49_not2457 : ~ @Equation2457 Fin2 refa49_inst.
Proof. unfold Equation2457. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa49_inst, refa49_op in H. discriminate H. Qed.

Lemma refa49_not2460 : ~ @Equation2460 Fin2 refa49_inst.
Proof. unfold Equation2460. intro H. specialize (H F2_1 F2_0). unfold magma_op, refa49_inst, refa49_op in H. discriminate H. Qed.

Lemma refa49_not2467 : ~ @Equation2467 Fin2 refa49_inst.
Proof. unfold Equation2467. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa49_inst, refa49_op in H. discriminate H. Qed.

Lemma refa49_not2503 : ~ @Equation2503 Fin2 refa49_inst.
Proof. unfold Equation2503. intro H. specialize (H F2_1 F2_0). unfold magma_op, refa49_inst, refa49_op in H. discriminate H. Qed.

Lemma refa49_not2534 : ~ @Equation2534 Fin2 refa49_inst.
Proof. unfold Equation2534. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa49_inst, refa49_op in H. discriminate H. Qed.

Lemma refa49_not2540 : ~ @Equation2540 Fin2 refa49_inst.
Proof. unfold Equation2540. intro H. specialize (H F2_1 F2_0). unfold magma_op, refa49_inst, refa49_op in H. discriminate H. Qed.

Lemma refa49_not2541 : ~ @Equation2541 Fin2 refa49_inst.
Proof. unfold Equation2541. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa49_inst, refa49_op in H. discriminate H. Qed.

Lemma refa49_not2647 : ~ @Equation2647 Fin2 refa49_inst.
Proof. unfold Equation2647. intro H. specialize (H F2_1 F2_0). unfold magma_op, refa49_inst, refa49_op in H. discriminate H. Qed.

Lemma refa49_not2650 : ~ @Equation2650 Fin2 refa49_inst.
Proof. unfold Equation2650. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa49_inst, refa49_op in H. discriminate H. Qed.

Lemma refa49_not2660 : ~ @Equation2660 Fin2 refa49_inst.
Proof. unfold Equation2660. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa49_inst, refa49_op in H. discriminate H. Qed.

Lemma refa49_not2669 : ~ @Equation2669 Fin2 refa49_inst.
Proof. unfold Equation2669. intro H. specialize (H F2_1 F2_0). unfold magma_op, refa49_inst, refa49_op in H. discriminate H. Qed.

Lemma refa49_not2670 : ~ @Equation2670 Fin2 refa49_inst.
Proof. unfold Equation2670. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa49_inst, refa49_op in H. discriminate H. Qed.

Lemma refa49_not2697 : ~ @Equation2697 Fin2 refa49_inst.
Proof. unfold Equation2697. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa49_inst, refa49_op in H. discriminate H. Qed.

Lemma refa49_not2710 : ~ @Equation2710 Fin2 refa49_inst.
Proof. unfold Equation2710. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa49_inst, refa49_op in H. discriminate H. Qed.

Lemma refa49_not2743 : ~ @Equation2743 Fin2 refa49_inst.
Proof. unfold Equation2743. intro H. specialize (H F2_1 F2_0). unfold magma_op, refa49_inst, refa49_op in H. discriminate H. Qed.

Lemma refa49_not2744 : ~ @Equation2744 Fin2 refa49_inst.
Proof. unfold Equation2744. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa49_inst, refa49_op in H. discriminate H. Qed.

Lemma refa49_not2847 : ~ @Equation2847 Fin2 refa49_inst.
Proof. unfold Equation2847. intro H. specialize (H F2_1). unfold magma_op, refa49_inst, refa49_op in H. discriminate H. Qed.

Lemma refa49_not3055 : ~ @Equation3055 Fin2 refa49_inst.
Proof. unfold Equation3055. intro H. specialize (H F2_1 F2_0). unfold magma_op, refa49_inst, refa49_op in H. discriminate H. Qed.

Lemma refa49_not3056 : ~ @Equation3056 Fin2 refa49_inst.
Proof. unfold Equation3056. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa49_inst, refa49_op in H. discriminate H. Qed.

Lemma refa49_not3059 : ~ @Equation3059 Fin2 refa49_inst.
Proof. unfold Equation3059. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa49_inst, refa49_op in H. discriminate H. Qed.

Lemma refa49_not3066 : ~ @Equation3066 Fin2 refa49_inst.
Proof. unfold Equation3066. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa49_inst, refa49_op in H. discriminate H. Qed.

Lemma refa49_not3069 : ~ @Equation3069 Fin2 refa49_inst.
Proof. unfold Equation3069. intro H. specialize (H F2_1 F2_0). unfold magma_op, refa49_inst, refa49_op in H. discriminate H. Qed.

Lemma refa49_not3075 : ~ @Equation3075 Fin2 refa49_inst.
Proof. unfold Equation3075. intro H. specialize (H F2_1 F2_0). unfold magma_op, refa49_inst, refa49_op in H. discriminate H. Qed.

Lemma refa49_not3076 : ~ @Equation3076 Fin2 refa49_inst.
Proof. unfold Equation3076. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa49_inst, refa49_op in H. discriminate H. Qed.

Lemma refa49_not3079 : ~ @Equation3079 Fin2 refa49_inst.
Proof. unfold Equation3079. intro H. specialize (H F2_1 F2_0). unfold magma_op, refa49_inst, refa49_op in H. discriminate H. Qed.

Lemma refa49_not3112 : ~ @Equation3112 Fin2 refa49_inst.
Proof. unfold Equation3112. intro H. specialize (H F2_1 F2_0). unfold magma_op, refa49_inst, refa49_op in H. discriminate H. Qed.

Lemma refa49_not3116 : ~ @Equation3116 Fin2 refa49_inst.
Proof. unfold Equation3116. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa49_inst, refa49_op in H. discriminate H. Qed.

Lemma refa49_not3143 : ~ @Equation3143 Fin2 refa49_inst.
Proof. unfold Equation3143. intro H. specialize (H F2_1 F2_0). unfold magma_op, refa49_inst, refa49_op in H. discriminate H. Qed.

Lemma refa49_not3149 : ~ @Equation3149 Fin2 refa49_inst.
Proof. unfold Equation3149. intro H. specialize (H F2_1 F2_0). unfold magma_op, refa49_inst, refa49_op in H. discriminate H. Qed.

Lemma refa49_not3150 : ~ @Equation3150 Fin2 refa49_inst.
Proof. unfold Equation3150. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa49_inst, refa49_op in H. discriminate H. Qed.

Lemma refa49_not3254 : ~ @Equation3254 Fin2 refa49_inst.
Proof. unfold Equation3254. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa49_inst, refa49_op in H. discriminate H. Qed.

Lemma refa49_not3281 : ~ @Equation3281 Fin2 refa49_inst.
Proof. unfold Equation3281. intro H. specialize (H F2_1 F2_0). unfold magma_op, refa49_inst, refa49_op in H. discriminate H. Qed.

Lemma refa49_not3308 : ~ @Equation3308 Fin2 refa49_inst.
Proof. unfold Equation3308. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa49_inst, refa49_op in H. discriminate H. Qed.

Lemma refa49_not3309 : ~ @Equation3309 Fin2 refa49_inst.
Proof. unfold Equation3309. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa49_inst, refa49_op in H. discriminate H. Qed.

Lemma refa49_not3315 : ~ @Equation3315 Fin2 refa49_inst.
Proof. unfold Equation3315. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa49_inst, refa49_op in H. discriminate H. Qed.

Lemma refa49_not3316 : ~ @Equation3316 Fin2 refa49_inst.
Proof. unfold Equation3316. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa49_inst, refa49_op in H. discriminate H. Qed.

Lemma refa49_not3318 : ~ @Equation3318 Fin2 refa49_inst.
Proof. unfold Equation3318. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa49_inst, refa49_op in H. discriminate H. Qed.

Lemma refa49_not3319 : ~ @Equation3319 Fin2 refa49_inst.
Proof. unfold Equation3319. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa49_inst, refa49_op in H. discriminate H. Qed.

Lemma refa49_not3342 : ~ @Equation3342 Fin2 refa49_inst.
Proof. unfold Equation3342. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa49_inst, refa49_op in H. discriminate H. Qed.

Lemma refa49_not3343 : ~ @Equation3343 Fin2 refa49_inst.
Proof. unfold Equation3343. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa49_inst, refa49_op in H. discriminate H. Qed.

Lemma refa49_not3345 : ~ @Equation3345 Fin2 refa49_inst.
Proof. unfold Equation3345. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa49_inst, refa49_op in H. discriminate H. Qed.

Lemma refa49_not3346 : ~ @Equation3346 Fin2 refa49_inst.
Proof. unfold Equation3346. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa49_inst, refa49_op in H. discriminate H. Qed.

Lemma refa49_not3352 : ~ @Equation3352 Fin2 refa49_inst.
Proof. unfold Equation3352. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa49_inst, refa49_op in H. discriminate H. Qed.

Lemma refa49_not3353 : ~ @Equation3353 Fin2 refa49_inst.
Proof. unfold Equation3353. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa49_inst, refa49_op in H. discriminate H. Qed.

Lemma refa49_not3457 : ~ @Equation3457 Fin2 refa49_inst.
Proof. unfold Equation3457. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa49_inst, refa49_op in H. discriminate H. Qed.

Lemma refa49_not3462 : ~ @Equation3462 Fin2 refa49_inst.
Proof. unfold Equation3462. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa49_inst, refa49_op in H. discriminate H. Qed.

Lemma refa49_not3465 : ~ @Equation3465 Fin2 refa49_inst.
Proof. unfold Equation3465. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa49_inst, refa49_op in H. discriminate H. Qed.

Lemma refa49_not3471 : ~ @Equation3471 Fin2 refa49_inst.
Proof. unfold Equation3471. intro H. specialize (H F2_1 F2_0). unfold magma_op, refa49_inst, refa49_op in H. discriminate H. Qed.

Lemma refa49_not3474 : ~ @Equation3474 Fin2 refa49_inst.
Proof. unfold Equation3474. intro H. specialize (H F2_1 F2_0). unfold magma_op, refa49_inst, refa49_op in H. discriminate H. Qed.

Lemma refa49_not3484 : ~ @Equation3484 Fin2 refa49_inst.
Proof. unfold Equation3484. intro H. specialize (H F2_1 F2_0). unfold magma_op, refa49_inst, refa49_op in H. discriminate H. Qed.

Lemma refa49_not3511 : ~ @Equation3511 Fin2 refa49_inst.
Proof. unfold Equation3511. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa49_inst, refa49_op in H. discriminate H. Qed.

Lemma refa49_not3512 : ~ @Equation3512 Fin2 refa49_inst.
Proof. unfold Equation3512. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa49_inst, refa49_op in H. discriminate H. Qed.

Lemma refa49_not3518 : ~ @Equation3518 Fin2 refa49_inst.
Proof. unfold Equation3518. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa49_inst, refa49_op in H. discriminate H. Qed.

Lemma refa49_not3521 : ~ @Equation3521 Fin2 refa49_inst.
Proof. unfold Equation3521. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa49_inst, refa49_op in H. discriminate H. Qed.

Lemma refa49_not3545 : ~ @Equation3545 Fin2 refa49_inst.
Proof. unfold Equation3545. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa49_inst, refa49_op in H. discriminate H. Qed.

Lemma refa49_not3546 : ~ @Equation3546 Fin2 refa49_inst.
Proof. unfold Equation3546. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa49_inst, refa49_op in H. discriminate H. Qed.

Lemma refa49_not3548 : ~ @Equation3548 Fin2 refa49_inst.
Proof. unfold Equation3548. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa49_inst, refa49_op in H. discriminate H. Qed.

Lemma refa49_not3549 : ~ @Equation3549 Fin2 refa49_inst.
Proof. unfold Equation3549. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa49_inst, refa49_op in H. discriminate H. Qed.

Lemma refa49_not3555 : ~ @Equation3555 Fin2 refa49_inst.
Proof. unfold Equation3555. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa49_inst, refa49_op in H. discriminate H. Qed.

Lemma refa49_not3556 : ~ @Equation3556 Fin2 refa49_inst.
Proof. unfold Equation3556. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa49_inst, refa49_op in H. discriminate H. Qed.

Lemma refa49_not3558 : ~ @Equation3558 Fin2 refa49_inst.
Proof. unfold Equation3558. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa49_inst, refa49_op in H. discriminate H. Qed.

Lemma refa49_not3660 : ~ @Equation3660 Fin2 refa49_inst.
Proof. unfold Equation3660. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa49_inst, refa49_op in H. discriminate H. Qed.

Lemma refa49_not3661 : ~ @Equation3661 Fin2 refa49_inst.
Proof. unfold Equation3661. intro H. specialize (H F2_1 F2_0). unfold magma_op, refa49_inst, refa49_op in H. discriminate H. Qed.

Lemma refa49_not3667 : ~ @Equation3667 Fin2 refa49_inst.
Proof. unfold Equation3667. intro H. specialize (H F2_1 F2_0). unfold magma_op, refa49_inst, refa49_op in H. discriminate H. Qed.

Lemma refa49_not3675 : ~ @Equation3675 Fin2 refa49_inst.
Proof. unfold Equation3675. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa49_inst, refa49_op in H. discriminate H. Qed.

Lemma refa49_not3685 : ~ @Equation3685 Fin2 refa49_inst.
Proof. unfold Equation3685. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa49_inst, refa49_op in H. discriminate H. Qed.

Lemma refa49_not3687 : ~ @Equation3687 Fin2 refa49_inst.
Proof. unfold Equation3687. intro H. specialize (H F2_1 F2_0). unfold magma_op, refa49_inst, refa49_op in H. discriminate H. Qed.

Lemma refa49_not3714 : ~ @Equation3714 Fin2 refa49_inst.
Proof. unfold Equation3714. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa49_inst, refa49_op in H. discriminate H. Qed.

Lemma refa49_not3721 : ~ @Equation3721 Fin2 refa49_inst.
Proof. unfold Equation3721. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa49_inst, refa49_op in H. discriminate H. Qed.

Lemma refa49_not3722 : ~ @Equation3722 Fin2 refa49_inst.
Proof. unfold Equation3722. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa49_inst, refa49_op in H. discriminate H. Qed.

Lemma refa49_not3724 : ~ @Equation3724 Fin2 refa49_inst.
Proof. unfold Equation3724. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa49_inst, refa49_op in H. discriminate H. Qed.

Lemma refa49_not3725 : ~ @Equation3725 Fin2 refa49_inst.
Proof. unfold Equation3725. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa49_inst, refa49_op in H. discriminate H. Qed.

Lemma refa49_not3748 : ~ @Equation3748 Fin2 refa49_inst.
Proof. unfold Equation3748. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa49_inst, refa49_op in H. discriminate H. Qed.

Lemma refa49_not3752 : ~ @Equation3752 Fin2 refa49_inst.
Proof. unfold Equation3752. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa49_inst, refa49_op in H. discriminate H. Qed.

Lemma refa49_not3761 : ~ @Equation3761 Fin2 refa49_inst.
Proof. unfold Equation3761. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa49_inst, refa49_op in H. discriminate H. Qed.

Lemma refa49_not3862 : ~ @Equation3862 Fin2 refa49_inst.
Proof. unfold Equation3862. intro H. specialize (H F2_1). unfold magma_op, refa49_inst, refa49_op in H. discriminate H. Qed.

Lemma refa49_not4066 : ~ @Equation4066 Fin2 refa49_inst.
Proof. unfold Equation4066. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa49_inst, refa49_op in H. discriminate H. Qed.

Lemma refa49_not4067 : ~ @Equation4067 Fin2 refa49_inst.
Proof. unfold Equation4067. intro H. specialize (H F2_1 F2_0). unfold magma_op, refa49_inst, refa49_op in H. discriminate H. Qed.

Lemma refa49_not4071 : ~ @Equation4071 Fin2 refa49_inst.
Proof. unfold Equation4071. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa49_inst, refa49_op in H. discriminate H. Qed.

Lemma refa49_not4073 : ~ @Equation4073 Fin2 refa49_inst.
Proof. unfold Equation4073. intro H. specialize (H F2_1 F2_0). unfold magma_op, refa49_inst, refa49_op in H. discriminate H. Qed.

Lemma refa49_not4074 : ~ @Equation4074 Fin2 refa49_inst.
Proof. unfold Equation4074. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa49_inst, refa49_op in H. discriminate H. Qed.

Lemma refa49_not4081 : ~ @Equation4081 Fin2 refa49_inst.
Proof. unfold Equation4081. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa49_inst, refa49_op in H. discriminate H. Qed.

Lemma refa49_not4083 : ~ @Equation4083 Fin2 refa49_inst.
Proof. unfold Equation4083. intro H. specialize (H F2_1 F2_0). unfold magma_op, refa49_inst, refa49_op in H. discriminate H. Qed.

Lemma refa49_not4091 : ~ @Equation4091 Fin2 refa49_inst.
Proof. unfold Equation4091. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa49_inst, refa49_op in H. discriminate H. Qed.

Lemma refa49_not4093 : ~ @Equation4093 Fin2 refa49_inst.
Proof. unfold Equation4093. intro H. specialize (H F2_1 F2_0). unfold magma_op, refa49_inst, refa49_op in H. discriminate H. Qed.

Lemma refa49_not4120 : ~ @Equation4120 Fin2 refa49_inst.
Proof. unfold Equation4120. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa49_inst, refa49_op in H. discriminate H. Qed.

Lemma refa49_not4121 : ~ @Equation4121 Fin2 refa49_inst.
Proof. unfold Equation4121. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa49_inst, refa49_op in H. discriminate H. Qed.

Lemma refa49_not4127 : ~ @Equation4127 Fin2 refa49_inst.
Proof. unfold Equation4127. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa49_inst, refa49_op in H. discriminate H. Qed.

Lemma refa49_not4130 : ~ @Equation4130 Fin2 refa49_inst.
Proof. unfold Equation4130. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa49_inst, refa49_op in H. discriminate H. Qed.

Lemma refa49_not4157 : ~ @Equation4157 Fin2 refa49_inst.
Proof. unfold Equation4157. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa49_inst, refa49_op in H. discriminate H. Qed.

Lemma refa49_not4158 : ~ @Equation4158 Fin2 refa49_inst.
Proof. unfold Equation4158. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa49_inst, refa49_op in H. discriminate H. Qed.

Lemma refa49_not4164 : ~ @Equation4164 Fin2 refa49_inst.
Proof. unfold Equation4164. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa49_inst, refa49_op in H. discriminate H. Qed.

Lemma refa49_not4167 : ~ @Equation4167 Fin2 refa49_inst.
Proof. unfold Equation4167. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa49_inst, refa49_op in H. discriminate H. Qed.

Lemma refa49_not4268 : ~ @Equation4268 Fin2 refa49_inst.
Proof. unfold Equation4268. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa49_inst, refa49_op in H. discriminate H. Qed.

Lemma refa49_not4275 : ~ @Equation4275 Fin2 refa49_inst.
Proof. unfold Equation4275. intro H. specialize (H F2_1 F2_0). unfold magma_op, refa49_inst, refa49_op in H. discriminate H. Qed.

Lemma refa49_not4283 : ~ @Equation4283 Fin2 refa49_inst.
Proof. unfold Equation4283. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa49_inst, refa49_op in H. discriminate H. Qed.

Lemma refa49_not4284 : ~ @Equation4284 Fin2 refa49_inst.
Proof. unfold Equation4284. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa49_inst, refa49_op in H. discriminate H. Qed.

Lemma refa49_not4290 : ~ @Equation4290 Fin2 refa49_inst.
Proof. unfold Equation4290. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa49_inst, refa49_op in H. discriminate H. Qed.

Lemma refa49_not4291 : ~ @Equation4291 Fin2 refa49_inst.
Proof. unfold Equation4291. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa49_inst, refa49_op in H. discriminate H. Qed.

Lemma refa49_not4293 : ~ @Equation4293 Fin2 refa49_inst.
Proof. unfold Equation4293. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa49_inst, refa49_op in H. discriminate H. Qed.

Lemma refa49_not4380 : ~ @Equation4380 Fin2 refa49_inst.
Proof. unfold Equation4380. intro H. specialize (H F2_1). unfold magma_op, refa49_inst, refa49_op in H. discriminate H. Qed.

Lemma refa49_not4583 : ~ @Equation4583 Fin2 refa49_inst.
Proof. unfold Equation4583. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa49_inst, refa49_op in H. discriminate H. Qed.

Lemma refa49_not4585 : ~ @Equation4585 Fin2 refa49_inst.
Proof. unfold Equation4585. intro H. specialize (H F2_1 F2_0). unfold magma_op, refa49_inst, refa49_op in H. discriminate H. Qed.

Lemma refa49_not4587 : ~ @Equation4587 Fin2 refa49_inst.
Proof. unfold Equation4587. intro H. specialize (H F2_1 F2_0). unfold magma_op, refa49_inst, refa49_op in H. discriminate H. Qed.

Lemma refa49_not4588 : ~ @Equation4588 Fin2 refa49_inst.
Proof. unfold Equation4588. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa49_inst, refa49_op in H. discriminate H. Qed.

Lemma refa49_not4591 : ~ @Equation4591 Fin2 refa49_inst.
Proof. unfold Equation4591. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa49_inst, refa49_op in H. discriminate H. Qed.

Lemma refa49_not4598 : ~ @Equation4598 Fin2 refa49_inst.
Proof. unfold Equation4598. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa49_inst, refa49_op in H. discriminate H. Qed.

Lemma refa49_not4599 : ~ @Equation4599 Fin2 refa49_inst.
Proof. unfold Equation4599. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa49_inst, refa49_op in H. discriminate H. Qed.

Lemma refa49_not4605 : ~ @Equation4605 Fin2 refa49_inst.
Proof. unfold Equation4605. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa49_inst, refa49_op in H. discriminate H. Qed.

Lemma refa49_not4608 : ~ @Equation4608 Fin2 refa49_inst.
Proof. unfold Equation4608. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa49_inst, refa49_op in H. discriminate H. Qed.

Lemma refa49_not4629 : ~ @Equation4629 Fin2 refa49_inst.
Proof. unfold Equation4629. intro H. specialize (H F2_1 F2_0). unfold magma_op, refa49_inst, refa49_op in H. discriminate H. Qed.

Lemma refa49_not4635 : ~ @Equation4635 Fin2 refa49_inst.
Proof. unfold Equation4635. intro H. specialize (H F2_1 F2_0). unfold magma_op, refa49_inst, refa49_op in H. discriminate H. Qed.

Lemma refa49_not4636 : ~ @Equation4636 Fin2 refa49_inst.
Proof. unfold Equation4636. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa49_inst, refa49_op in H. discriminate H. Qed.

(** ---- refa490 (Fin4) ---- *)

Definition refa490_op (x y : Fin4) : Fin4 :=
  match x, y with
  | F4_0, F4_0 => F4_0 | F4_0, F4_1 => F4_1 | F4_0, F4_2 => F4_2 | F4_0, F4_3 => F4_3
  | F4_1, F4_0 => F4_0 | F4_1, F4_1 => F4_1 | F4_1, F4_2 => F4_2 | F4_1, F4_3 => F4_3
  | F4_2, F4_0 => F4_2 | F4_2, F4_1 => F4_3 | F4_2, F4_2 => F4_0 | F4_2, F4_3 => F4_1
  | F4_3, F4_0 => F4_3 | F4_3, F4_1 => F4_2 | F4_3, F4_2 => F4_1 | F4_3, F4_3 => F4_0
  end.

#[local] Instance refa490_inst : Magma Fin4 := {| magma_op := refa490_op |}.

Lemma refa490_sat731 : @Equation731 Fin4 refa490_inst.
Proof. unfold Equation731, magma_op, refa490_inst, refa490_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa490_not676 : ~ @Equation676 Fin4 refa490_inst.
Proof. unfold Equation676. intro H. specialize (H F4_1 F4_2). unfold magma_op, refa490_inst, refa490_op in H. discriminate H. Qed.

Lemma refa490_not835 : ~ @Equation835 Fin4 refa490_inst.
Proof. unfold Equation835. intro H. specialize (H F4_1 F4_2). unfold magma_op, refa490_inst, refa490_op in H. discriminate H. Qed.

Lemma refa490_not906 : ~ @Equation906 Fin4 refa490_inst.
Proof. unfold Equation906. intro H. specialize (H F4_1 F4_2). unfold magma_op, refa490_inst, refa490_op in H. discriminate H. Qed.

Lemma refa490_not3870 : ~ @Equation3870 Fin4 refa490_inst.
Proof. unfold Equation3870. intro H. specialize (H F4_2 F4_1). unfold magma_op, refa490_inst, refa490_op in H. discriminate H. Qed.

Lemma refa490_not3928 : ~ @Equation3928 Fin4 refa490_inst.
Proof. unfold Equation3928. intro H. specialize (H F4_2 F4_1). unfold magma_op, refa490_inst, refa490_op in H. discriminate H. Qed.

Lemma refa490_not3955 : ~ @Equation3955 Fin4 refa490_inst.
Proof. unfold Equation3955. intro H. specialize (H F4_2 F4_1). unfold magma_op, refa490_inst, refa490_op in H. discriminate H. Qed.

Lemma refa490_not4131 : ~ @Equation4131 Fin4 refa490_inst.
Proof. unfold Equation4131. intro H. specialize (H F4_2 F4_3). unfold magma_op, refa490_inst, refa490_op in H. discriminate H. Qed.

(** ---- refa491 (Fin4) ---- *)

Definition refa491_op (x y : Fin4) : Fin4 :=
  match x, y with
  | F4_0, F4_0 => F4_2 | F4_0, F4_1 => F4_1 | F4_0, F4_2 => F4_3 | F4_0, F4_3 => F4_3
  | F4_1, F4_0 => F4_2 | F4_1, F4_1 => F4_3 | F4_1, F4_2 => F4_0 | F4_1, F4_3 => F4_3
  | F4_2, F4_0 => F4_0 | F4_2, F4_1 => F4_1 | F4_2, F4_2 => F4_2 | F4_2, F4_3 => F4_3
  | F4_3, F4_0 => F4_0 | F4_3, F4_1 => F4_1 | F4_3, F4_2 => F4_2 | F4_3, F4_3 => F4_3
  end.

#[local] Instance refa491_inst : Magma Fin4 := {| magma_op := refa491_op |}.

Lemma refa491_sat2571 : @Equation2571 Fin4 refa491_inst.
Proof. unfold Equation2571, magma_op, refa491_inst, refa491_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa491_not2446 : ~ @Equation2446 Fin4 refa491_inst.
Proof. unfold Equation2446. intro H. specialize (H F4_2 F4_1). unfold magma_op, refa491_inst, refa491_op in H. discriminate H. Qed.

(** ---- refa492 (Fin4) ---- *)

Definition refa492_op (x y : Fin4) : Fin4 :=
  match x, y with
  | F4_0, F4_0 => F4_3 | F4_0, F4_1 => F4_2 | F4_0, F4_2 => F4_3 | F4_0, F4_3 => F4_3
  | F4_1, F4_0 => F4_3 | F4_1, F4_1 => F4_3 | F4_1, F4_2 => F4_3 | F4_1, F4_3 => F4_3
  | F4_2, F4_0 => F4_2 | F4_2, F4_1 => F4_2 | F4_2, F4_2 => F4_3 | F4_2, F4_3 => F4_3
  | F4_3, F4_0 => F4_3 | F4_3, F4_1 => F4_3 | F4_3, F4_2 => F4_3 | F4_3, F4_3 => F4_3
  end.

#[local] Instance refa492_inst : Magma Fin4 := {| magma_op := refa492_op |}.

Lemma refa492_sat314 : @Equation314 Fin4 refa492_inst.
Proof. unfold Equation314, magma_op, refa492_inst, refa492_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa492_sat3886 : @Equation3886 Fin4 refa492_inst.
Proof. unfold Equation3886, magma_op, refa492_inst, refa492_op. intros x y z w. destruct x, y, z, w; reflexivity. Qed.

Lemma refa492_sat4530 : @Equation4530 Fin4 refa492_inst.
Proof. unfold Equation4530, magma_op, refa492_inst, refa492_op. intros x y z w. destruct x, y, z, w; reflexivity. Qed.

Lemma refa492_not4070 : ~ @Equation4070 Fin4 refa492_inst.
Proof. unfold Equation4070. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa492_inst, refa492_op in H. discriminate H. Qed.

Lemma refa492_not4071 : ~ @Equation4071 Fin4 refa492_inst.
Proof. unfold Equation4071. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa492_inst, refa492_op in H. discriminate H. Qed.

Lemma refa492_not4073 : ~ @Equation4073 Fin4 refa492_inst.
Proof. unfold Equation4073. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa492_inst, refa492_op in H. discriminate H. Qed.

Lemma refa492_not4081 : ~ @Equation4081 Fin4 refa492_inst.
Proof. unfold Equation4081. intro H. specialize (H F4_1 F4_0). unfold magma_op, refa492_inst, refa492_op in H. discriminate H. Qed.

Lemma refa492_not4083 : ~ @Equation4083 Fin4 refa492_inst.
Proof. unfold Equation4083. intro H. specialize (H F4_1 F4_0). unfold magma_op, refa492_inst, refa492_op in H. discriminate H. Qed.

Lemma refa492_not4084 : ~ @Equation4084 Fin4 refa492_inst.
Proof. unfold Equation4084. intro H. specialize (H F4_1 F4_0). unfold magma_op, refa492_inst, refa492_op in H. discriminate H. Qed.

Lemma refa492_not4398 : ~ @Equation4398 Fin4 refa492_inst.
Proof. unfold Equation4398. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa492_inst, refa492_op in H. discriminate H. Qed.

Lemma refa492_not4406 : ~ @Equation4406 Fin4 refa492_inst.
Proof. unfold Equation4406. intro H. specialize (H F4_1 F4_0). unfold magma_op, refa492_inst, refa492_op in H. discriminate H. Qed.

Lemma refa492_not4435 : ~ @Equation4435 Fin4 refa492_inst.
Proof. unfold Equation4435. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa492_inst, refa492_op in H. discriminate H. Qed.

Lemma refa492_not4443 : ~ @Equation4443 Fin4 refa492_inst.
Proof. unfold Equation4443. intro H. specialize (H F4_1 F4_0). unfold magma_op, refa492_inst, refa492_op in H. discriminate H. Qed.

Lemma refa492_not4472 : ~ @Equation4472 Fin4 refa492_inst.
Proof. unfold Equation4472. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa492_inst, refa492_op in H. discriminate H. Qed.

Lemma refa492_not4480 : ~ @Equation4480 Fin4 refa492_inst.
Proof. unfold Equation4480. intro H. specialize (H F4_1 F4_0). unfold magma_op, refa492_inst, refa492_op in H. discriminate H. Qed.

Lemma refa492_not4598 : ~ @Equation4598 Fin4 refa492_inst.
Proof. unfold Equation4598. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa492_inst, refa492_op in H. discriminate H. Qed.

Lemma refa492_not4606 : ~ @Equation4606 Fin4 refa492_inst.
Proof. unfold Equation4606. intro H. specialize (H F4_1 F4_0). unfold magma_op, refa492_inst, refa492_op in H. discriminate H. Qed.

Lemma refa492_not4631 : ~ @Equation4631 Fin4 refa492_inst.
Proof. unfold Equation4631. intro H. specialize (H F4_0 F4_0 F4_1). unfold magma_op, refa492_inst, refa492_op in H. discriminate H. Qed.

Lemma refa492_not4636 : ~ @Equation4636 Fin4 refa492_inst.
Proof. unfold Equation4636. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa492_inst, refa492_op in H. discriminate H. Qed.

Lemma refa492_not4647 : ~ @Equation4647 Fin4 refa492_inst.
Proof. unfold Equation4647. intro H. specialize (H F4_0 F4_1 F4_1). unfold magma_op, refa492_inst, refa492_op in H. discriminate H. Qed.

(** ---- refa493 (Fin4) ---- *)

Definition refa493_op (x y : Fin4) : Fin4 :=
  match x, y with
  | F4_0, F4_0 => F4_3 | F4_0, F4_1 => F4_2 | F4_0, F4_2 => F4_0 | F4_0, F4_3 => F4_1
  | F4_1, F4_0 => F4_3 | F4_1, F4_1 => F4_2 | F4_1, F4_2 => F4_1 | F4_1, F4_3 => F4_0
  | F4_2, F4_0 => F4_3 | F4_2, F4_1 => F4_2 | F4_2, F4_2 => F4_1 | F4_2, F4_3 => F4_0
  | F4_3, F4_0 => F4_2 | F4_3, F4_1 => F4_3 | F4_3, F4_2 => F4_1 | F4_3, F4_3 => F4_0
  end.

#[local] Instance refa493_inst : Magma Fin4 := {| magma_op := refa493_op |}.

Lemma refa493_sat2115 : @Equation2115 Fin4 refa493_inst.
Proof. unfold Equation2115, magma_op, refa493_inst, refa493_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa493_not1223 : ~ @Equation1223 Fin4 refa493_inst.
Proof. unfold Equation1223. intro H. specialize (H F4_0). unfold magma_op, refa493_inst, refa493_op in H. discriminate H. Qed.

Lemma refa493_not2063 : ~ @Equation2063 Fin4 refa493_inst.
Proof. unfold Equation2063. intro H. specialize (H F4_0 F4_2). unfold magma_op, refa493_inst, refa493_op in H. discriminate H. Qed.

Lemma refa493_not4587 : ~ @Equation4587 Fin4 refa493_inst.
Proof. unfold Equation4587. intro H. specialize (H F4_0 F4_3). unfold magma_op, refa493_inst, refa493_op in H. discriminate H. Qed.

(** ---- refa494 (Fin4) ---- *)

Definition refa494_op (x y : Fin4) : Fin4 :=
  match x, y with
  | F4_0, F4_0 => F4_3 | F4_0, F4_1 => F4_1 | F4_0, F4_2 => F4_3 | F4_0, F4_3 => F4_3
  | F4_1, F4_0 => F4_3 | F4_1, F4_1 => F4_3 | F4_1, F4_2 => F4_1 | F4_1, F4_3 => F4_3
  | F4_2, F4_0 => F4_0 | F4_2, F4_1 => F4_0 | F4_2, F4_2 => F4_0 | F4_2, F4_3 => F4_0
  | F4_3, F4_0 => F4_3 | F4_3, F4_1 => F4_3 | F4_3, F4_2 => F4_0 | F4_3, F4_3 => F4_3
  end.

#[local] Instance refa494_inst : Magma Fin4 := {| magma_op := refa494_op |}.

Lemma refa494_sat4104 : @Equation4104 Fin4 refa494_inst.
Proof. unfold Equation4104, magma_op, refa494_inst, refa494_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa494_not4067 : ~ @Equation4067 Fin4 refa494_inst.
Proof. unfold Equation4067. intro H. specialize (H F4_1 F4_2). unfold magma_op, refa494_inst, refa494_op in H. discriminate H. Qed.

Lemma refa494_not4073 : ~ @Equation4073 Fin4 refa494_inst.
Proof. unfold Equation4073. intro H. specialize (H F4_2 F4_1). unfold magma_op, refa494_inst, refa494_op in H. discriminate H. Qed.

(** ---- refa495 (Fin4) ---- *)

Definition refa495_op (x y : Fin4) : Fin4 :=
  match x, y with
  | F4_0, F4_0 => F4_2 | F4_0, F4_1 => F4_2 | F4_0, F4_2 => F4_1 | F4_0, F4_3 => F4_1
  | F4_1, F4_0 => F4_3 | F4_1, F4_1 => F4_3 | F4_1, F4_2 => F4_0 | F4_1, F4_3 => F4_0
  | F4_2, F4_0 => F4_3 | F4_2, F4_1 => F4_3 | F4_2, F4_2 => F4_1 | F4_2, F4_3 => F4_1
  | F4_3, F4_0 => F4_2 | F4_3, F4_1 => F4_2 | F4_3, F4_2 => F4_0 | F4_3, F4_3 => F4_0
  end.

#[local] Instance refa495_inst : Magma Fin4 := {| magma_op := refa495_op |}.

Lemma refa495_sat2046 : @Equation2046 Fin4 refa495_inst.
Proof. unfold Equation2046, magma_op, refa495_inst, refa495_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa495_not2060 : ~ @Equation2060 Fin4 refa495_inst.
Proof. unfold Equation2060. intro H. specialize (H F4_0 F4_2). unfold magma_op, refa495_inst, refa495_op in H. discriminate H. Qed.

Lemma refa495_not2063 : ~ @Equation2063 Fin4 refa495_inst.
Proof. unfold Equation2063. intro H. specialize (H F4_0 F4_2). unfold magma_op, refa495_inst, refa495_op in H. discriminate H. Qed.

Lemma refa495_not4599 : ~ @Equation4599 Fin4 refa495_inst.
Proof. unfold Equation4599. intro H. specialize (H F4_0 F4_2). unfold magma_op, refa495_inst, refa495_op in H. discriminate H. Qed.

(** ---- refa496 (Fin4) ---- *)

Definition refa496_op (x y : Fin4) : Fin4 :=
  match x, y with
  | F4_0, F4_0 => F4_3 | F4_0, F4_1 => F4_2 | F4_0, F4_2 => F4_1 | F4_0, F4_3 => F4_1
  | F4_1, F4_0 => F4_3 | F4_1, F4_1 => F4_0 | F4_1, F4_2 => F4_3 | F4_1, F4_3 => F4_2
  | F4_2, F4_0 => F4_2 | F4_2, F4_1 => F4_2 | F4_2, F4_2 => F4_2 | F4_2, F4_3 => F4_2
  | F4_3, F4_0 => F4_2 | F4_3, F4_1 => F4_0 | F4_3, F4_2 => F4_0 | F4_3, F4_3 => F4_1
  end.

#[local] Instance refa496_inst : Magma Fin4 := {| magma_op := refa496_op |}.

Lemma refa496_sat1431 : @Equation1431 Fin4 refa496_inst.
Proof. unfold Equation1431, magma_op, refa496_inst, refa496_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa496_sat1638 : @Equation1638 Fin4 refa496_inst.
Proof. unfold Equation1638, magma_op, refa496_inst, refa496_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa496_not3253 : ~ @Equation3253 Fin4 refa496_inst.
Proof. unfold Equation3253. intro H. specialize (H F4_0). unfold magma_op, refa496_inst, refa496_op in H. discriminate H. Qed.

Lemma refa496_not3462 : ~ @Equation3462 Fin4 refa496_inst.
Proof. unfold Equation3462. intro H. specialize (H F4_0 F4_0). unfold magma_op, refa496_inst, refa496_op in H. discriminate H. Qed.

Lemma refa496_not3465 : ~ @Equation3465 Fin4 refa496_inst.
Proof. unfold Equation3465. intro H. specialize (H F4_0 F4_0). unfold magma_op, refa496_inst, refa496_op in H. discriminate H. Qed.

Lemma refa496_not3518 : ~ @Equation3518 Fin4 refa496_inst.
Proof. unfold Equation3518. intro H. specialize (H F4_0 F4_0). unfold magma_op, refa496_inst, refa496_op in H. discriminate H. Qed.

Lemma refa496_not3521 : ~ @Equation3521 Fin4 refa496_inst.
Proof. unfold Equation3521. intro H. specialize (H F4_0 F4_0). unfold magma_op, refa496_inst, refa496_op in H. discriminate H. Qed.

Lemma refa496_not4065 : ~ @Equation4065 Fin4 refa496_inst.
Proof. unfold Equation4065. intro H. specialize (H F4_0). unfold magma_op, refa496_inst, refa496_op in H. discriminate H. Qed.

Lemma refa496_not4314 : ~ @Equation4314 Fin4 refa496_inst.
Proof. unfold Equation4314. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa496_inst, refa496_op in H. discriminate H. Qed.

Lemma refa496_not4599 : ~ @Equation4599 Fin4 refa496_inst.
Proof. unfold Equation4599. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa496_inst, refa496_op in H. discriminate H. Qed.

(** ---- refa497 (Fin4) ---- *)

Definition refa497_op (x y : Fin4) : Fin4 :=
  match x, y with
  | F4_0, F4_0 => F4_1 | F4_0, F4_1 => F4_0 | F4_0, F4_2 => F4_2 | F4_0, F4_3 => F4_3
  | F4_1, F4_0 => F4_1 | F4_1, F4_1 => F4_0 | F4_1, F4_2 => F4_2 | F4_1, F4_3 => F4_3
  | F4_2, F4_0 => F4_0 | F4_2, F4_1 => F4_3 | F4_2, F4_2 => F4_2 | F4_2, F4_3 => F4_1
  | F4_3, F4_0 => F4_1 | F4_3, F4_1 => F4_0 | F4_3, F4_2 => F4_2 | F4_3, F4_3 => F4_3
  end.

#[local] Instance refa497_inst : Magma Fin4 := {| magma_op := refa497_op |}.

Lemma refa497_sat1797 : @Equation1797 Fin4 refa497_inst.
Proof. unfold Equation1797, magma_op, refa497_inst, refa497_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa497_sat2182 : @Equation2182 Fin4 refa497_inst.
Proof. unfold Equation2182, magma_op, refa497_inst, refa497_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa497_not429 : ~ @Equation429 Fin4 refa497_inst.
Proof. unfold Equation429. intro H. specialize (H F4_0 F4_2). unfold magma_op, refa497_inst, refa497_op in H. discriminate H. Qed.

Lemma refa497_not473 : ~ @Equation473 Fin4 refa497_inst.
Proof. unfold Equation473. intro H. specialize (H F4_0 F4_2). unfold magma_op, refa497_inst, refa497_op in H. discriminate H. Qed.

Lemma refa497_not3271 : ~ @Equation3271 Fin4 refa497_inst.
Proof. unfold Equation3271. intro H. specialize (H F4_0 F4_2). unfold magma_op, refa497_inst, refa497_op in H. discriminate H. Qed.

Lemma refa497_not3346 : ~ @Equation3346 Fin4 refa497_inst.
Proof. unfold Equation3346. intro H. specialize (H F4_2 F4_0). unfold magma_op, refa497_inst, refa497_op in H. discriminate H. Qed.

Lemma refa497_not4320 : ~ @Equation4320 Fin4 refa497_inst.
Proof. unfold Equation4320. intro H. specialize (H F4_0 F4_2). unfold magma_op, refa497_inst, refa497_op in H. discriminate H. Qed.

(** ---- refa498 (Fin4) ---- *)

Definition refa498_op (x y : Fin4) : Fin4 :=
  match x, y with
  | F4_0, F4_0 => F4_3 | F4_0, F4_1 => F4_1 | F4_0, F4_2 => F4_3 | F4_0, F4_3 => F4_1
  | F4_1, F4_0 => F4_3 | F4_1, F4_1 => F4_3 | F4_1, F4_2 => F4_3 | F4_1, F4_3 => F4_3
  | F4_2, F4_0 => F4_1 | F4_2, F4_1 => F4_3 | F4_2, F4_2 => F4_3 | F4_2, F4_3 => F4_0
  | F4_3, F4_0 => F4_3 | F4_3, F4_1 => F4_3 | F4_3, F4_2 => F4_3 | F4_3, F4_3 => F4_3
  end.

#[local] Instance refa498_inst : Magma Fin4 := {| magma_op := refa498_op |}.

Lemma refa498_sat4103 : @Equation4103 Fin4 refa498_inst.
Proof. unfold Equation4103, magma_op, refa498_inst, refa498_op. intros x y z w. destruct x, y, z, w; reflexivity. Qed.

Lemma refa498_not3664 : ~ @Equation3664 Fin4 refa498_inst.
Proof. unfold Equation3664. intro H. specialize (H F4_2 F4_3). unfold magma_op, refa498_inst, refa498_op in H. discriminate H. Qed.

Lemma refa498_not3667 : ~ @Equation3667 Fin4 refa498_inst.
Proof. unfold Equation3667. intro H. specialize (H F4_2 F4_3). unfold magma_op, refa498_inst, refa498_op in H. discriminate H. Qed.

Lemma refa498_not3668 : ~ @Equation3668 Fin4 refa498_inst.
Proof. unfold Equation3668. intro H. specialize (H F4_2 F4_3). unfold magma_op, refa498_inst, refa498_op in H. discriminate H. Qed.

Lemma refa498_not3674 : ~ @Equation3674 Fin4 refa498_inst.
Proof. unfold Equation3674. intro H. specialize (H F4_3 F4_2). unfold magma_op, refa498_inst, refa498_op in H. discriminate H. Qed.

Lemma refa498_not3675 : ~ @Equation3675 Fin4 refa498_inst.
Proof. unfold Equation3675. intro H. specialize (H F4_3 F4_2). unfold magma_op, refa498_inst, refa498_op in H. discriminate H. Qed.

Lemma refa498_not3678 : ~ @Equation3678 Fin4 refa498_inst.
Proof. unfold Equation3678. intro H. specialize (H F4_3 F4_2). unfold magma_op, refa498_inst, refa498_op in H. discriminate H. Qed.

Lemma refa498_not3863 : ~ @Equation3863 Fin4 refa498_inst.
Proof. unfold Equation3863. intro H. specialize (H F4_2 F4_1). unfold magma_op, refa498_inst, refa498_op in H. discriminate H. Qed.

Lemma refa498_not3865 : ~ @Equation3865 Fin4 refa498_inst.
Proof. unfold Equation3865. intro H. specialize (H F4_2 F4_1). unfold magma_op, refa498_inst, refa498_op in H. discriminate H. Qed.

Lemma refa498_not3868 : ~ @Equation3868 Fin4 refa498_inst.
Proof. unfold Equation3868. intro H. specialize (H F4_2 F4_1). unfold magma_op, refa498_inst, refa498_op in H. discriminate H. Qed.

Lemma refa498_not3871 : ~ @Equation3871 Fin4 refa498_inst.
Proof. unfold Equation3871. intro H. specialize (H F4_2 F4_1). unfold magma_op, refa498_inst, refa498_op in H. discriminate H. Qed.

Lemma refa498_not3877 : ~ @Equation3877 Fin4 refa498_inst.
Proof. unfold Equation3877. intro H. specialize (H F4_1 F4_2). unfold magma_op, refa498_inst, refa498_op in H. discriminate H. Qed.

Lemma refa498_not3880 : ~ @Equation3880 Fin4 refa498_inst.
Proof. unfold Equation3880. intro H. specialize (H F4_1 F4_2). unfold magma_op, refa498_inst, refa498_op in H. discriminate H. Qed.

Lemma refa498_not3887 : ~ @Equation3887 Fin4 refa498_inst.
Proof. unfold Equation3887. intro H. specialize (H F4_1 F4_2). unfold magma_op, refa498_inst, refa498_op in H. discriminate H. Qed.

Lemma refa498_not3890 : ~ @Equation3890 Fin4 refa498_inst.
Proof. unfold Equation3890. intro H. specialize (H F4_1 F4_2). unfold magma_op, refa498_inst, refa498_op in H. discriminate H. Qed.

Lemma refa498_not4629 : ~ @Equation4629 Fin4 refa498_inst.
Proof. unfold Equation4629. intro H. specialize (H F4_2 F4_3). unfold magma_op, refa498_inst, refa498_op in H. discriminate H. Qed.

(** ---- refa499 (Fin4) ---- *)

Definition refa499_op (x y : Fin4) : Fin4 :=
  match x, y with
  | F4_0, F4_0 => F4_0 | F4_0, F4_1 => F4_3 | F4_0, F4_2 => F4_1 | F4_0, F4_3 => F4_1
  | F4_1, F4_0 => F4_3 | F4_1, F4_1 => F4_1 | F4_1, F4_2 => F4_3 | F4_1, F4_3 => F4_2
  | F4_2, F4_0 => F4_1 | F4_2, F4_1 => F4_0 | F4_2, F4_2 => F4_2 | F4_2, F4_3 => F4_0
  | F4_3, F4_0 => F4_2 | F4_3, F4_1 => F4_2 | F4_3, F4_2 => F4_0 | F4_3, F4_3 => F4_3
  end.

#[local] Instance refa499_inst : Magma Fin4 := {| magma_op := refa499_op |}.

Lemma refa499_sat1232 : @Equation1232 Fin4 refa499_inst.
Proof. unfold Equation1232, magma_op, refa499_inst, refa499_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa499_not417 : ~ @Equation417 Fin4 refa499_inst.
Proof. unfold Equation417. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa499_inst, refa499_op in H. discriminate H. Qed.

Lemma refa499_not620 : ~ @Equation620 Fin4 refa499_inst.
Proof. unfold Equation620. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa499_inst, refa499_op in H. discriminate H. Qed.

Lemma refa499_not825 : ~ @Equation825 Fin4 refa499_inst.
Proof. unfold Equation825. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa499_inst, refa499_op in H. discriminate H. Qed.

Lemma refa499_not1023 : ~ @Equation1023 Fin4 refa499_inst.
Proof. unfold Equation1023. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa499_inst, refa499_op in H. discriminate H. Qed.

Lemma refa499_not4130 : ~ @Equation4130 Fin4 refa499_inst.
Proof. unfold Equation4130. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa499_inst, refa499_op in H. discriminate H. Qed.

Lemma refa499_not4435 : ~ @Equation4435 Fin4 refa499_inst.
Proof. unfold Equation4435. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa499_inst, refa499_op in H. discriminate H. Qed.

(** ---- refa5 (Fin8) ---- *)

Definition refa5_op (x y : Fin8) : Fin8 :=
  match x, y with
  | F8_0, F8_0 => F8_0 | F8_0, F8_1 => F8_2 | F8_0, F8_2 => F8_3 | F8_0, F8_3 => F8_4 | F8_0, F8_4 => F8_5 | F8_0, F8_5 => F8_6 | F8_0, F8_6 => F8_7 | F8_0, F8_7 => F8_1
  | F8_1, F8_0 => F8_6 | F8_1, F8_1 => F8_1 | F8_1, F8_2 => F8_5 | F8_1, F8_3 => F8_7 | F8_1, F8_4 => F8_3 | F8_1, F8_5 => F8_0 | F8_1, F8_6 => F8_4 | F8_1, F8_7 => F8_2
  | F8_2, F8_0 => F8_7 | F8_2, F8_1 => F8_3 | F8_2, F8_2 => F8_2 | F8_2, F8_3 => F8_6 | F8_2, F8_4 => F8_1 | F8_2, F8_5 => F8_4 | F8_2, F8_6 => F8_0 | F8_2, F8_7 => F8_5
  | F8_3, F8_0 => F8_1 | F8_3, F8_1 => F8_6 | F8_3, F8_2 => F8_4 | F8_3, F8_3 => F8_3 | F8_3, F8_4 => F8_7 | F8_3, F8_5 => F8_2 | F8_3, F8_6 => F8_5 | F8_3, F8_7 => F8_0
  | F8_4, F8_0 => F8_2 | F8_4, F8_1 => F8_0 | F8_4, F8_2 => F8_7 | F8_4, F8_3 => F8_5 | F8_4, F8_4 => F8_4 | F8_4, F8_5 => F8_1 | F8_4, F8_6 => F8_3 | F8_4, F8_7 => F8_6
  | F8_5, F8_0 => F8_3 | F8_5, F8_1 => F8_7 | F8_5, F8_2 => F8_0 | F8_5, F8_3 => F8_1 | F8_5, F8_4 => F8_6 | F8_5, F8_5 => F8_5 | F8_5, F8_6 => F8_2 | F8_5, F8_7 => F8_4
  | F8_6, F8_0 => F8_4 | F8_6, F8_1 => F8_5 | F8_6, F8_2 => F8_1 | F8_6, F8_3 => F8_0 | F8_6, F8_4 => F8_2 | F8_6, F8_5 => F8_7 | F8_6, F8_6 => F8_6 | F8_6, F8_7 => F8_3
  | F8_7, F8_0 => F8_5 | F8_7, F8_1 => F8_4 | F8_7, F8_2 => F8_6 | F8_7, F8_3 => F8_2 | F8_7, F8_4 => F8_0 | F8_7, F8_5 => F8_3 | F8_7, F8_6 => F8_1 | F8_7, F8_7 => F8_7
  end.

#[local] Instance refa5_inst : Magma Fin8 := {| magma_op := refa5_op |}.

Lemma refa5_sat125 : @Equation125 Fin8 refa5_inst.
Proof. unfold Equation125, magma_op, refa5_inst, refa5_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa5_sat271 : @Equation271 Fin8 refa5_inst.
Proof. unfold Equation271, magma_op, refa5_inst, refa5_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa5_sat476 : @Equation476 Fin8 refa5_inst.
Proof. unfold Equation476, magma_op, refa5_inst, refa5_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa5_sat704 : @Equation704 Fin8 refa5_inst.
Proof. unfold Equation704, magma_op, refa5_inst, refa5_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa5_sat1110 : @Equation1110 Fin8 refa5_inst.
Proof. unfold Equation1110, magma_op, refa5_inst, refa5_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa5_sat1895 : @Equation1895 Fin8 refa5_inst.
Proof. unfold Equation1895, magma_op, refa5_inst, refa5_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa5_sat2091 : @Equation2091 Fin8 refa5_inst.
Proof. unfold Equation2091, magma_op, refa5_inst, refa5_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa5_sat2241 : @Equation2241 Fin8 refa5_inst.
Proof. unfold Equation2241, magma_op, refa5_inst, refa5_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa5_sat3069 : @Equation3069 Fin8 refa5_inst.
Proof. unfold Equation3069, magma_op, refa5_inst, refa5_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa5_sat3140 : @Equation3140 Fin8 refa5_inst.
Proof. unfold Equation3140, magma_op, refa5_inst, refa5_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa5_not50 : ~ @Equation50 Fin8 refa5_inst.
Proof. unfold Equation50. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa5_inst, refa5_op in H. discriminate H. Qed.

Lemma refa5_not55 : ~ @Equation55 Fin8 refa5_inst.
Proof. unfold Equation55. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa5_inst, refa5_op in H. discriminate H. Qed.

Lemma refa5_not56 : ~ @Equation56 Fin8 refa5_inst.
Proof. unfold Equation56. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa5_inst, refa5_op in H. discriminate H. Qed.

Lemma refa5_not65 : ~ @Equation65 Fin8 refa5_inst.
Proof. unfold Equation65. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa5_inst, refa5_op in H. discriminate H. Qed.

Lemma refa5_not66 : ~ @Equation66 Fin8 refa5_inst.
Proof. unfold Equation66. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa5_inst, refa5_op in H. discriminate H. Qed.

Lemma refa5_not75 : ~ @Equation75 Fin8 refa5_inst.
Proof. unfold Equation75. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa5_inst, refa5_op in H. discriminate H. Qed.

Lemma refa5_not105 : ~ @Equation105 Fin8 refa5_inst.
Proof. unfold Equation105. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa5_inst, refa5_op in H. discriminate H. Qed.

Lemma refa5_not107 : ~ @Equation107 Fin8 refa5_inst.
Proof. unfold Equation107. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa5_inst, refa5_op in H. discriminate H. Qed.

Lemma refa5_not108 : ~ @Equation108 Fin8 refa5_inst.
Proof. unfold Equation108. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa5_inst, refa5_op in H. discriminate H. Qed.

Lemma refa5_not117 : ~ @Equation117 Fin8 refa5_inst.
Proof. unfold Equation117. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa5_inst, refa5_op in H. discriminate H. Qed.

Lemma refa5_not118 : ~ @Equation118 Fin8 refa5_inst.
Proof. unfold Equation118. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa5_inst, refa5_op in H. discriminate H. Qed.

Lemma refa5_not124 : ~ @Equation124 Fin8 refa5_inst.
Proof. unfold Equation124. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa5_inst, refa5_op in H. discriminate H. Qed.

Lemma refa5_not127 : ~ @Equation127 Fin8 refa5_inst.
Proof. unfold Equation127. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa5_inst, refa5_op in H. discriminate H. Qed.

Lemma refa5_not160 : ~ @Equation160 Fin8 refa5_inst.
Proof. unfold Equation160. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa5_inst, refa5_op in H. discriminate H. Qed.

Lemma refa5_not167 : ~ @Equation167 Fin8 refa5_inst.
Proof. unfold Equation167. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa5_inst, refa5_op in H. discriminate H. Qed.

Lemma refa5_not206 : ~ @Equation206 Fin8 refa5_inst.
Proof. unfold Equation206. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa5_inst, refa5_op in H. discriminate H. Qed.

Lemma refa5_not209 : ~ @Equation209 Fin8 refa5_inst.
Proof. unfold Equation209. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa5_inst, refa5_op in H. discriminate H. Qed.

Lemma refa5_not211 : ~ @Equation211 Fin8 refa5_inst.
Proof. unfold Equation211. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa5_inst, refa5_op in H. discriminate H. Qed.

Lemma refa5_not221 : ~ @Equation221 Fin8 refa5_inst.
Proof. unfold Equation221. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa5_inst, refa5_op in H. discriminate H. Qed.

Lemma refa5_not231 : ~ @Equation231 Fin8 refa5_inst.
Proof. unfold Equation231. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa5_inst, refa5_op in H. discriminate H. Qed.

Lemma refa5_not261 : ~ @Equation261 Fin8 refa5_inst.
Proof. unfold Equation261. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa5_inst, refa5_op in H. discriminate H. Qed.

Lemma refa5_not263 : ~ @Equation263 Fin8 refa5_inst.
Proof. unfold Equation263. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa5_inst, refa5_op in H. discriminate H. Qed.

Lemma refa5_not264 : ~ @Equation264 Fin8 refa5_inst.
Proof. unfold Equation264. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa5_inst, refa5_op in H. discriminate H. Qed.

Lemma refa5_not274 : ~ @Equation274 Fin8 refa5_inst.
Proof. unfold Equation274. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa5_inst, refa5_op in H. discriminate H. Qed.

Lemma refa5_not280 : ~ @Equation280 Fin8 refa5_inst.
Proof. unfold Equation280. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa5_inst, refa5_op in H. discriminate H. Qed.

Lemma refa5_not283 : ~ @Equation283 Fin8 refa5_inst.
Proof. unfold Equation283. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa5_inst, refa5_op in H. discriminate H. Qed.

Lemma refa5_not412 : ~ @Equation412 Fin8 refa5_inst.
Proof. unfold Equation412. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa5_inst, refa5_op in H. discriminate H. Qed.

Lemma refa5_not413 : ~ @Equation413 Fin8 refa5_inst.
Proof. unfold Equation413. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa5_inst, refa5_op in H. discriminate H. Qed.

Lemma refa5_not414 : ~ @Equation414 Fin8 refa5_inst.
Proof. unfold Equation414. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa5_inst, refa5_op in H. discriminate H. Qed.

Lemma refa5_not416 : ~ @Equation416 Fin8 refa5_inst.
Proof. unfold Equation416. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa5_inst, refa5_op in H. discriminate H. Qed.

Lemma refa5_not417 : ~ @Equation417 Fin8 refa5_inst.
Proof. unfold Equation417. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa5_inst, refa5_op in H. discriminate H. Qed.

Lemma refa5_not419 : ~ @Equation419 Fin8 refa5_inst.
Proof. unfold Equation419. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa5_inst, refa5_op in H. discriminate H. Qed.

Lemma refa5_not420 : ~ @Equation420 Fin8 refa5_inst.
Proof. unfold Equation420. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa5_inst, refa5_op in H. discriminate H. Qed.

Lemma refa5_not426 : ~ @Equation426 Fin8 refa5_inst.
Proof. unfold Equation426. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa5_inst, refa5_op in H. discriminate H. Qed.

Lemma refa5_not427 : ~ @Equation427 Fin8 refa5_inst.
Proof. unfold Equation427. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa5_inst, refa5_op in H. discriminate H. Qed.

Lemma refa5_not429 : ~ @Equation429 Fin8 refa5_inst.
Proof. unfold Equation429. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa5_inst, refa5_op in H. discriminate H. Qed.

Lemma refa5_not430 : ~ @Equation430 Fin8 refa5_inst.
Proof. unfold Equation430. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa5_inst, refa5_op in H. discriminate H. Qed.

Lemma refa5_not436 : ~ @Equation436 Fin8 refa5_inst.
Proof. unfold Equation436. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa5_inst, refa5_op in H. discriminate H. Qed.

Lemma refa5_not439 : ~ @Equation439 Fin8 refa5_inst.
Proof. unfold Equation439. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa5_inst, refa5_op in H. discriminate H. Qed.

Lemma refa5_not440 : ~ @Equation440 Fin8 refa5_inst.
Proof. unfold Equation440. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa5_inst, refa5_op in H. discriminate H. Qed.

Lemma refa5_not464 : ~ @Equation464 Fin8 refa5_inst.
Proof. unfold Equation464. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa5_inst, refa5_op in H. discriminate H. Qed.

Lemma refa5_not466 : ~ @Equation466 Fin8 refa5_inst.
Proof. unfold Equation466. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa5_inst, refa5_op in H. discriminate H. Qed.

Lemma refa5_not467 : ~ @Equation467 Fin8 refa5_inst.
Proof. unfold Equation467. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa5_inst, refa5_op in H. discriminate H. Qed.

Lemma refa5_not473 : ~ @Equation473 Fin8 refa5_inst.
Proof. unfold Equation473. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa5_inst, refa5_op in H. discriminate H. Qed.

Lemma refa5_not474 : ~ @Equation474 Fin8 refa5_inst.
Proof. unfold Equation474. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa5_inst, refa5_op in H. discriminate H. Qed.

Lemma refa5_not477 : ~ @Equation477 Fin8 refa5_inst.
Proof. unfold Equation477. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa5_inst, refa5_op in H. discriminate H. Qed.

Lemma refa5_not501 : ~ @Equation501 Fin8 refa5_inst.
Proof. unfold Equation501. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa5_inst, refa5_op in H. discriminate H. Qed.

Lemma refa5_not503 : ~ @Equation503 Fin8 refa5_inst.
Proof. unfold Equation503. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa5_inst, refa5_op in H. discriminate H. Qed.

Lemma refa5_not511 : ~ @Equation511 Fin8 refa5_inst.
Proof. unfold Equation511. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa5_inst, refa5_op in H. discriminate H. Qed.

Lemma refa5_not513 : ~ @Equation513 Fin8 refa5_inst.
Proof. unfold Equation513. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa5_inst, refa5_op in H. discriminate H. Qed.

Lemma refa5_not615 : ~ @Equation615 Fin8 refa5_inst.
Proof. unfold Equation615. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa5_inst, refa5_op in H. discriminate H. Qed.

Lemma refa5_not616 : ~ @Equation616 Fin8 refa5_inst.
Proof. unfold Equation616. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa5_inst, refa5_op in H. discriminate H. Qed.

Lemma refa5_not617 : ~ @Equation617 Fin8 refa5_inst.
Proof. unfold Equation617. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa5_inst, refa5_op in H. discriminate H. Qed.

Lemma refa5_not619 : ~ @Equation619 Fin8 refa5_inst.
Proof. unfold Equation619. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa5_inst, refa5_op in H. discriminate H. Qed.

Lemma refa5_not620 : ~ @Equation620 Fin8 refa5_inst.
Proof. unfold Equation620. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa5_inst, refa5_op in H. discriminate H. Qed.

Lemma refa5_not622 : ~ @Equation622 Fin8 refa5_inst.
Proof. unfold Equation622. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa5_inst, refa5_op in H. discriminate H. Qed.

Lemma refa5_not623 : ~ @Equation623 Fin8 refa5_inst.
Proof. unfold Equation623. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa5_inst, refa5_op in H. discriminate H. Qed.

Lemma refa5_not629 : ~ @Equation629 Fin8 refa5_inst.
Proof. unfold Equation629. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa5_inst, refa5_op in H. discriminate H. Qed.

Lemma refa5_not630 : ~ @Equation630 Fin8 refa5_inst.
Proof. unfold Equation630. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa5_inst, refa5_op in H. discriminate H. Qed.

Lemma refa5_not632 : ~ @Equation632 Fin8 refa5_inst.
Proof. unfold Equation632. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa5_inst, refa5_op in H. discriminate H. Qed.

Lemma refa5_not633 : ~ @Equation633 Fin8 refa5_inst.
Proof. unfold Equation633. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa5_inst, refa5_op in H. discriminate H. Qed.

Lemma refa5_not639 : ~ @Equation639 Fin8 refa5_inst.
Proof. unfold Equation639. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa5_inst, refa5_op in H. discriminate H. Qed.

Lemma refa5_not642 : ~ @Equation642 Fin8 refa5_inst.
Proof. unfold Equation642. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa5_inst, refa5_op in H. discriminate H. Qed.

Lemma refa5_not643 : ~ @Equation643 Fin8 refa5_inst.
Proof. unfold Equation643. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa5_inst, refa5_op in H. discriminate H. Qed.

Lemma refa5_not667 : ~ @Equation667 Fin8 refa5_inst.
Proof. unfold Equation667. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa5_inst, refa5_op in H. discriminate H. Qed.

Lemma refa5_not669 : ~ @Equation669 Fin8 refa5_inst.
Proof. unfold Equation669. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa5_inst, refa5_op in H. discriminate H. Qed.

Lemma refa5_not670 : ~ @Equation670 Fin8 refa5_inst.
Proof. unfold Equation670. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa5_inst, refa5_op in H. discriminate H. Qed.

Lemma refa5_not677 : ~ @Equation677 Fin8 refa5_inst.
Proof. unfold Equation677. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa5_inst, refa5_op in H. discriminate H. Qed.

Lemma refa5_not679 : ~ @Equation679 Fin8 refa5_inst.
Proof. unfold Equation679. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa5_inst, refa5_op in H. discriminate H. Qed.

Lemma refa5_not680 : ~ @Equation680 Fin8 refa5_inst.
Proof. unfold Equation680. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa5_inst, refa5_op in H. discriminate H. Qed.

Lemma refa5_not706 : ~ @Equation706 Fin8 refa5_inst.
Proof. unfold Equation706. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa5_inst, refa5_op in H. discriminate H. Qed.

Lemma refa5_not707 : ~ @Equation707 Fin8 refa5_inst.
Proof. unfold Equation707. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa5_inst, refa5_op in H. discriminate H. Qed.

Lemma refa5_not713 : ~ @Equation713 Fin8 refa5_inst.
Proof. unfold Equation713. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa5_inst, refa5_op in H. discriminate H. Qed.

Lemma refa5_not716 : ~ @Equation716 Fin8 refa5_inst.
Proof. unfold Equation716. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa5_inst, refa5_op in H. discriminate H. Qed.

Lemma refa5_not818 : ~ @Equation818 Fin8 refa5_inst.
Proof. unfold Equation818. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa5_inst, refa5_op in H. discriminate H. Qed.

Lemma refa5_not819 : ~ @Equation819 Fin8 refa5_inst.
Proof. unfold Equation819. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa5_inst, refa5_op in H. discriminate H. Qed.

Lemma refa5_not820 : ~ @Equation820 Fin8 refa5_inst.
Proof. unfold Equation820. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa5_inst, refa5_op in H. discriminate H. Qed.

Lemma refa5_not822 : ~ @Equation822 Fin8 refa5_inst.
Proof. unfold Equation822. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa5_inst, refa5_op in H. discriminate H. Qed.

Lemma refa5_not823 : ~ @Equation823 Fin8 refa5_inst.
Proof. unfold Equation823. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa5_inst, refa5_op in H. discriminate H. Qed.

Lemma refa5_not826 : ~ @Equation826 Fin8 refa5_inst.
Proof. unfold Equation826. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa5_inst, refa5_op in H. discriminate H. Qed.

Lemma refa5_not832 : ~ @Equation832 Fin8 refa5_inst.
Proof. unfold Equation832. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa5_inst, refa5_op in H. discriminate H. Qed.

Lemma refa5_not833 : ~ @Equation833 Fin8 refa5_inst.
Proof. unfold Equation833. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa5_inst, refa5_op in H. discriminate H. Qed.

Lemma refa5_not835 : ~ @Equation835 Fin8 refa5_inst.
Proof. unfold Equation835. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa5_inst, refa5_op in H. discriminate H. Qed.

Lemma refa5_not836 : ~ @Equation836 Fin8 refa5_inst.
Proof. unfold Equation836. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa5_inst, refa5_op in H. discriminate H. Qed.

Lemma refa5_not842 : ~ @Equation842 Fin8 refa5_inst.
Proof. unfold Equation842. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa5_inst, refa5_op in H. discriminate H. Qed.

Lemma refa5_not843 : ~ @Equation843 Fin8 refa5_inst.
Proof. unfold Equation843. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa5_inst, refa5_op in H. discriminate H. Qed.

Lemma refa5_not845 : ~ @Equation845 Fin8 refa5_inst.
Proof. unfold Equation845. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa5_inst, refa5_op in H. discriminate H. Qed.

Lemma refa5_not846 : ~ @Equation846 Fin8 refa5_inst.
Proof. unfold Equation846. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa5_inst, refa5_op in H. discriminate H. Qed.

Lemma refa5_not870 : ~ @Equation870 Fin8 refa5_inst.
Proof. unfold Equation870. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa5_inst, refa5_op in H. discriminate H. Qed.

Lemma refa5_not872 : ~ @Equation872 Fin8 refa5_inst.
Proof. unfold Equation872. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa5_inst, refa5_op in H. discriminate H. Qed.

Lemma refa5_not873 : ~ @Equation873 Fin8 refa5_inst.
Proof. unfold Equation873. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa5_inst, refa5_op in H. discriminate H. Qed.

Lemma refa5_not879 : ~ @Equation879 Fin8 refa5_inst.
Proof. unfold Equation879. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa5_inst, refa5_op in H. discriminate H. Qed.

Lemma refa5_not882 : ~ @Equation882 Fin8 refa5_inst.
Proof. unfold Equation882. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa5_inst, refa5_op in H. discriminate H. Qed.

Lemma refa5_not883 : ~ @Equation883 Fin8 refa5_inst.
Proof. unfold Equation883. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa5_inst, refa5_op in H. discriminate H. Qed.

Lemma refa5_not906 : ~ @Equation906 Fin8 refa5_inst.
Proof. unfold Equation906. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa5_inst, refa5_op in H. discriminate H. Qed.

Lemma refa5_not907 : ~ @Equation907 Fin8 refa5_inst.
Proof. unfold Equation907. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa5_inst, refa5_op in H. discriminate H. Qed.

Lemma refa5_not1021 : ~ @Equation1021 Fin8 refa5_inst.
Proof. unfold Equation1021. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa5_inst, refa5_op in H. discriminate H. Qed.

Lemma refa5_not1022 : ~ @Equation1022 Fin8 refa5_inst.
Proof. unfold Equation1022. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa5_inst, refa5_op in H. discriminate H. Qed.

Lemma refa5_not1023 : ~ @Equation1023 Fin8 refa5_inst.
Proof. unfold Equation1023. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa5_inst, refa5_op in H. discriminate H. Qed.

Lemma refa5_not1025 : ~ @Equation1025 Fin8 refa5_inst.
Proof. unfold Equation1025. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa5_inst, refa5_op in H. discriminate H. Qed.

Lemma refa5_not1026 : ~ @Equation1026 Fin8 refa5_inst.
Proof. unfold Equation1026. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa5_inst, refa5_op in H. discriminate H. Qed.

Lemma refa5_not1028 : ~ @Equation1028 Fin8 refa5_inst.
Proof. unfold Equation1028. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa5_inst, refa5_op in H. discriminate H. Qed.

Lemma refa5_not1029 : ~ @Equation1029 Fin8 refa5_inst.
Proof. unfold Equation1029. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa5_inst, refa5_op in H. discriminate H. Qed.

Lemma refa5_not1035 : ~ @Equation1035 Fin8 refa5_inst.
Proof. unfold Equation1035. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa5_inst, refa5_op in H. discriminate H. Qed.

Lemma refa5_not1036 : ~ @Equation1036 Fin8 refa5_inst.
Proof. unfold Equation1036. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa5_inst, refa5_op in H. discriminate H. Qed.

Lemma refa5_not1038 : ~ @Equation1038 Fin8 refa5_inst.
Proof. unfold Equation1038. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa5_inst, refa5_op in H. discriminate H. Qed.

Lemma refa5_not1039 : ~ @Equation1039 Fin8 refa5_inst.
Proof. unfold Equation1039. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa5_inst, refa5_op in H. discriminate H. Qed.

Lemma refa5_not1045 : ~ @Equation1045 Fin8 refa5_inst.
Proof. unfold Equation1045. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa5_inst, refa5_op in H. discriminate H. Qed.

Lemma refa5_not1048 : ~ @Equation1048 Fin8 refa5_inst.
Proof. unfold Equation1048. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa5_inst, refa5_op in H. discriminate H. Qed.

Lemma refa5_not1049 : ~ @Equation1049 Fin8 refa5_inst.
Proof. unfold Equation1049. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa5_inst, refa5_op in H. discriminate H. Qed.

Lemma refa5_not1075 : ~ @Equation1075 Fin8 refa5_inst.
Proof. unfold Equation1075. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa5_inst, refa5_op in H. discriminate H. Qed.

Lemma refa5_not1076 : ~ @Equation1076 Fin8 refa5_inst.
Proof. unfold Equation1076. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa5_inst, refa5_op in H. discriminate H. Qed.

Lemma refa5_not1083 : ~ @Equation1083 Fin8 refa5_inst.
Proof. unfold Equation1083. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa5_inst, refa5_op in H. discriminate H. Qed.

Lemma refa5_not1085 : ~ @Equation1085 Fin8 refa5_inst.
Proof. unfold Equation1085. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa5_inst, refa5_op in H. discriminate H. Qed.

Lemma refa5_not1086 : ~ @Equation1086 Fin8 refa5_inst.
Proof. unfold Equation1086. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa5_inst, refa5_op in H. discriminate H. Qed.

Lemma refa5_not1109 : ~ @Equation1109 Fin8 refa5_inst.
Proof. unfold Equation1109. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa5_inst, refa5_op in H. discriminate H. Qed.

Lemma refa5_not1112 : ~ @Equation1112 Fin8 refa5_inst.
Proof. unfold Equation1112. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa5_inst, refa5_op in H. discriminate H. Qed.

Lemma refa5_not1113 : ~ @Equation1113 Fin8 refa5_inst.
Proof. unfold Equation1113. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa5_inst, refa5_op in H. discriminate H. Qed.

Lemma refa5_not1119 : ~ @Equation1119 Fin8 refa5_inst.
Proof. unfold Equation1119. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa5_inst, refa5_op in H. discriminate H. Qed.

Lemma refa5_not1122 : ~ @Equation1122 Fin8 refa5_inst.
Proof. unfold Equation1122. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa5_inst, refa5_op in H. discriminate H. Qed.

Lemma refa5_not1224 : ~ @Equation1224 Fin8 refa5_inst.
Proof. unfold Equation1224. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa5_inst, refa5_op in H. discriminate H. Qed.

Lemma refa5_not1225 : ~ @Equation1225 Fin8 refa5_inst.
Proof. unfold Equation1225. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa5_inst, refa5_op in H. discriminate H. Qed.

Lemma refa5_not1226 : ~ @Equation1226 Fin8 refa5_inst.
Proof. unfold Equation1226. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa5_inst, refa5_op in H. discriminate H. Qed.

Lemma refa5_not1228 : ~ @Equation1228 Fin8 refa5_inst.
Proof. unfold Equation1228. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa5_inst, refa5_op in H. discriminate H. Qed.

Lemma refa5_not1229 : ~ @Equation1229 Fin8 refa5_inst.
Proof. unfold Equation1229. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa5_inst, refa5_op in H. discriminate H. Qed.

Lemma refa5_not1231 : ~ @Equation1231 Fin8 refa5_inst.
Proof. unfold Equation1231. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa5_inst, refa5_op in H. discriminate H. Qed.

Lemma refa5_not1232 : ~ @Equation1232 Fin8 refa5_inst.
Proof. unfold Equation1232. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa5_inst, refa5_op in H. discriminate H. Qed.

Lemma refa5_not1238 : ~ @Equation1238 Fin8 refa5_inst.
Proof. unfold Equation1238. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa5_inst, refa5_op in H. discriminate H. Qed.

Lemma refa5_not1241 : ~ @Equation1241 Fin8 refa5_inst.
Proof. unfold Equation1241. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa5_inst, refa5_op in H. discriminate H. Qed.

Lemma refa5_not1242 : ~ @Equation1242 Fin8 refa5_inst.
Proof. unfold Equation1242. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa5_inst, refa5_op in H. discriminate H. Qed.

Lemma refa5_not1248 : ~ @Equation1248 Fin8 refa5_inst.
Proof. unfold Equation1248. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa5_inst, refa5_op in H. discriminate H. Qed.

Lemma refa5_not1249 : ~ @Equation1249 Fin8 refa5_inst.
Proof. unfold Equation1249. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa5_inst, refa5_op in H. discriminate H. Qed.

Lemma refa5_not1251 : ~ @Equation1251 Fin8 refa5_inst.
Proof. unfold Equation1251. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa5_inst, refa5_op in H. discriminate H. Qed.

Lemma refa5_not1252 : ~ @Equation1252 Fin8 refa5_inst.
Proof. unfold Equation1252. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa5_inst, refa5_op in H. discriminate H. Qed.

Lemma refa5_not1276 : ~ @Equation1276 Fin8 refa5_inst.
Proof. unfold Equation1276. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa5_inst, refa5_op in H. discriminate H. Qed.

Lemma refa5_not1278 : ~ @Equation1278 Fin8 refa5_inst.
Proof. unfold Equation1278. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa5_inst, refa5_op in H. discriminate H. Qed.

Lemma refa5_not1279 : ~ @Equation1279 Fin8 refa5_inst.
Proof. unfold Equation1279. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa5_inst, refa5_op in H. discriminate H. Qed.

Lemma refa5_not1286 : ~ @Equation1286 Fin8 refa5_inst.
Proof. unfold Equation1286. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa5_inst, refa5_op in H. discriminate H. Qed.

Lemma refa5_not1288 : ~ @Equation1288 Fin8 refa5_inst.
Proof. unfold Equation1288. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa5_inst, refa5_op in H. discriminate H. Qed.

Lemma refa5_not1289 : ~ @Equation1289 Fin8 refa5_inst.
Proof. unfold Equation1289. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa5_inst, refa5_op in H. discriminate H. Qed.

Lemma refa5_not1312 : ~ @Equation1312 Fin8 refa5_inst.
Proof. unfold Equation1312. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa5_inst, refa5_op in H. discriminate H. Qed.

Lemma refa5_not1313 : ~ @Equation1313 Fin8 refa5_inst.
Proof. unfold Equation1313. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa5_inst, refa5_op in H. discriminate H. Qed.

Lemma refa5_not1315 : ~ @Equation1315 Fin8 refa5_inst.
Proof. unfold Equation1315. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa5_inst, refa5_op in H. discriminate H. Qed.

Lemma refa5_not1322 : ~ @Equation1322 Fin8 refa5_inst.
Proof. unfold Equation1322. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa5_inst, refa5_op in H. discriminate H. Qed.

Lemma refa5_not1325 : ~ @Equation1325 Fin8 refa5_inst.
Proof. unfold Equation1325. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa5_inst, refa5_op in H. discriminate H. Qed.

Lemma refa5_not1427 : ~ @Equation1427 Fin8 refa5_inst.
Proof. unfold Equation1427. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa5_inst, refa5_op in H. discriminate H. Qed.

Lemma refa5_not1428 : ~ @Equation1428 Fin8 refa5_inst.
Proof. unfold Equation1428. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa5_inst, refa5_op in H. discriminate H. Qed.

Lemma refa5_not1429 : ~ @Equation1429 Fin8 refa5_inst.
Proof. unfold Equation1429. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa5_inst, refa5_op in H. discriminate H. Qed.

Lemma refa5_not1431 : ~ @Equation1431 Fin8 refa5_inst.
Proof. unfold Equation1431. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa5_inst, refa5_op in H. discriminate H. Qed.

Lemma refa5_not1432 : ~ @Equation1432 Fin8 refa5_inst.
Proof. unfold Equation1432. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa5_inst, refa5_op in H. discriminate H. Qed.

Lemma refa5_not1434 : ~ @Equation1434 Fin8 refa5_inst.
Proof. unfold Equation1434. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa5_inst, refa5_op in H. discriminate H. Qed.

Lemma refa5_not1435 : ~ @Equation1435 Fin8 refa5_inst.
Proof. unfold Equation1435. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa5_inst, refa5_op in H. discriminate H. Qed.

Lemma refa5_not1441 : ~ @Equation1441 Fin8 refa5_inst.
Proof. unfold Equation1441. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa5_inst, refa5_op in H. discriminate H. Qed.

Lemma refa5_not1444 : ~ @Equation1444 Fin8 refa5_inst.
Proof. unfold Equation1444. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa5_inst, refa5_op in H. discriminate H. Qed.

Lemma refa5_not1445 : ~ @Equation1445 Fin8 refa5_inst.
Proof. unfold Equation1445. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa5_inst, refa5_op in H. discriminate H. Qed.

Lemma refa5_not1454 : ~ @Equation1454 Fin8 refa5_inst.
Proof. unfold Equation1454. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa5_inst, refa5_op in H. discriminate H. Qed.

Lemma refa5_not1455 : ~ @Equation1455 Fin8 refa5_inst.
Proof. unfold Equation1455. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa5_inst, refa5_op in H. discriminate H. Qed.

Lemma refa5_not1478 : ~ @Equation1478 Fin8 refa5_inst.
Proof. unfold Equation1478. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa5_inst, refa5_op in H. discriminate H. Qed.

Lemma refa5_not1482 : ~ @Equation1482 Fin8 refa5_inst.
Proof. unfold Equation1482. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa5_inst, refa5_op in H. discriminate H. Qed.

Lemma refa5_not1488 : ~ @Equation1488 Fin8 refa5_inst.
Proof. unfold Equation1488. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa5_inst, refa5_op in H. discriminate H. Qed.

Lemma refa5_not1489 : ~ @Equation1489 Fin8 refa5_inst.
Proof. unfold Equation1489. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa5_inst, refa5_op in H. discriminate H. Qed.

Lemma refa5_not1491 : ~ @Equation1491 Fin8 refa5_inst.
Proof. unfold Equation1491. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa5_inst, refa5_op in H. discriminate H. Qed.

Lemma refa5_not1515 : ~ @Equation1515 Fin8 refa5_inst.
Proof. unfold Equation1515. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa5_inst, refa5_op in H. discriminate H. Qed.

Lemma refa5_not1516 : ~ @Equation1516 Fin8 refa5_inst.
Proof. unfold Equation1516. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa5_inst, refa5_op in H. discriminate H. Qed.

Lemma refa5_not1518 : ~ @Equation1518 Fin8 refa5_inst.
Proof. unfold Equation1518. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa5_inst, refa5_op in H. discriminate H. Qed.

Lemma refa5_not1519 : ~ @Equation1519 Fin8 refa5_inst.
Proof. unfold Equation1519. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa5_inst, refa5_op in H. discriminate H. Qed.

Lemma refa5_not1525 : ~ @Equation1525 Fin8 refa5_inst.
Proof. unfold Equation1525. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa5_inst, refa5_op in H. discriminate H. Qed.

Lemma refa5_not1630 : ~ @Equation1630 Fin8 refa5_inst.
Proof. unfold Equation1630. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa5_inst, refa5_op in H. discriminate H. Qed.

Lemma refa5_not1631 : ~ @Equation1631 Fin8 refa5_inst.
Proof. unfold Equation1631. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa5_inst, refa5_op in H. discriminate H. Qed.

Lemma refa5_not1632 : ~ @Equation1632 Fin8 refa5_inst.
Proof. unfold Equation1632. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa5_inst, refa5_op in H. discriminate H. Qed.

Lemma refa5_not1634 : ~ @Equation1634 Fin8 refa5_inst.
Proof. unfold Equation1634. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa5_inst, refa5_op in H. discriminate H. Qed.

Lemma refa5_not1635 : ~ @Equation1635 Fin8 refa5_inst.
Proof. unfold Equation1635. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa5_inst, refa5_op in H. discriminate H. Qed.

Lemma refa5_not1637 : ~ @Equation1637 Fin8 refa5_inst.
Proof. unfold Equation1637. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa5_inst, refa5_op in H. discriminate H. Qed.

Lemma refa5_not1638 : ~ @Equation1638 Fin8 refa5_inst.
Proof. unfold Equation1638. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa5_inst, refa5_op in H. discriminate H. Qed.

Lemma refa5_not1644 : ~ @Equation1644 Fin8 refa5_inst.
Proof. unfold Equation1644. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa5_inst, refa5_op in H. discriminate H. Qed.

Lemma refa5_not1645 : ~ @Equation1645 Fin8 refa5_inst.
Proof. unfold Equation1645. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa5_inst, refa5_op in H. discriminate H. Qed.

Lemma refa5_not1648 : ~ @Equation1648 Fin8 refa5_inst.
Proof. unfold Equation1648. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa5_inst, refa5_op in H. discriminate H. Qed.

Lemma refa5_not1654 : ~ @Equation1654 Fin8 refa5_inst.
Proof. unfold Equation1654. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa5_inst, refa5_op in H. discriminate H. Qed.

Lemma refa5_not1655 : ~ @Equation1655 Fin8 refa5_inst.
Proof. unfold Equation1655. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa5_inst, refa5_op in H. discriminate H. Qed.

Lemma refa5_not1658 : ~ @Equation1658 Fin8 refa5_inst.
Proof. unfold Equation1658. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa5_inst, refa5_op in H. discriminate H. Qed.

Lemma refa5_not1681 : ~ @Equation1681 Fin8 refa5_inst.
Proof. unfold Equation1681. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa5_inst, refa5_op in H. discriminate H. Qed.

Lemma refa5_not1682 : ~ @Equation1682 Fin8 refa5_inst.
Proof. unfold Equation1682. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa5_inst, refa5_op in H. discriminate H. Qed.

Lemma refa5_not1684 : ~ @Equation1684 Fin8 refa5_inst.
Proof. unfold Equation1684. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa5_inst, refa5_op in H. discriminate H. Qed.

Lemma refa5_not1691 : ~ @Equation1691 Fin8 refa5_inst.
Proof. unfold Equation1691. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa5_inst, refa5_op in H. discriminate H. Qed.

Lemma refa5_not1692 : ~ @Equation1692 Fin8 refa5_inst.
Proof. unfold Equation1692. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa5_inst, refa5_op in H. discriminate H. Qed.

Lemma refa5_not1694 : ~ @Equation1694 Fin8 refa5_inst.
Proof. unfold Equation1694. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa5_inst, refa5_op in H. discriminate H. Qed.

Lemma refa5_not1719 : ~ @Equation1719 Fin8 refa5_inst.
Proof. unfold Equation1719. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa5_inst, refa5_op in H. discriminate H. Qed.

Lemma refa5_not1721 : ~ @Equation1721 Fin8 refa5_inst.
Proof. unfold Equation1721. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa5_inst, refa5_op in H. discriminate H. Qed.

Lemma refa5_not1722 : ~ @Equation1722 Fin8 refa5_inst.
Proof. unfold Equation1722. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa5_inst, refa5_op in H. discriminate H. Qed.

Lemma refa5_not1728 : ~ @Equation1728 Fin8 refa5_inst.
Proof. unfold Equation1728. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa5_inst, refa5_op in H. discriminate H. Qed.

Lemma refa5_not1731 : ~ @Equation1731 Fin8 refa5_inst.
Proof. unfold Equation1731. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa5_inst, refa5_op in H. discriminate H. Qed.

Lemma refa5_not1833 : ~ @Equation1833 Fin8 refa5_inst.
Proof. unfold Equation1833. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa5_inst, refa5_op in H. discriminate H. Qed.

Lemma refa5_not1834 : ~ @Equation1834 Fin8 refa5_inst.
Proof. unfold Equation1834. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa5_inst, refa5_op in H. discriminate H. Qed.

Lemma refa5_not1837 : ~ @Equation1837 Fin8 refa5_inst.
Proof. unfold Equation1837. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa5_inst, refa5_op in H. discriminate H. Qed.

Lemma refa5_not1838 : ~ @Equation1838 Fin8 refa5_inst.
Proof. unfold Equation1838. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa5_inst, refa5_op in H. discriminate H. Qed.

Lemma refa5_not1840 : ~ @Equation1840 Fin8 refa5_inst.
Proof. unfold Equation1840. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa5_inst, refa5_op in H. discriminate H. Qed.

Lemma refa5_not1841 : ~ @Equation1841 Fin8 refa5_inst.
Proof. unfold Equation1841. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa5_inst, refa5_op in H. discriminate H. Qed.

Lemma refa5_not1847 : ~ @Equation1847 Fin8 refa5_inst.
Proof. unfold Equation1847. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa5_inst, refa5_op in H. discriminate H. Qed.

Lemma refa5_not1848 : ~ @Equation1848 Fin8 refa5_inst.
Proof. unfold Equation1848. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa5_inst, refa5_op in H. discriminate H. Qed.

Lemma refa5_not1851 : ~ @Equation1851 Fin8 refa5_inst.
Proof. unfold Equation1851. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa5_inst, refa5_op in H. discriminate H. Qed.

Lemma refa5_not1857 : ~ @Equation1857 Fin8 refa5_inst.
Proof. unfold Equation1857. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa5_inst, refa5_op in H. discriminate H. Qed.

Lemma refa5_not1858 : ~ @Equation1858 Fin8 refa5_inst.
Proof. unfold Equation1858. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa5_inst, refa5_op in H. discriminate H. Qed.

Lemma refa5_not1861 : ~ @Equation1861 Fin8 refa5_inst.
Proof. unfold Equation1861. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa5_inst, refa5_op in H. discriminate H. Qed.

Lemma refa5_not1884 : ~ @Equation1884 Fin8 refa5_inst.
Proof. unfold Equation1884. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa5_inst, refa5_op in H. discriminate H. Qed.

Lemma refa5_not1885 : ~ @Equation1885 Fin8 refa5_inst.
Proof. unfold Equation1885. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa5_inst, refa5_op in H. discriminate H. Qed.

Lemma refa5_not1887 : ~ @Equation1887 Fin8 refa5_inst.
Proof. unfold Equation1887. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa5_inst, refa5_op in H. discriminate H. Qed.

Lemma refa5_not1888 : ~ @Equation1888 Fin8 refa5_inst.
Proof. unfold Equation1888. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa5_inst, refa5_op in H. discriminate H. Qed.

Lemma refa5_not1894 : ~ @Equation1894 Fin8 refa5_inst.
Proof. unfold Equation1894. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa5_inst, refa5_op in H. discriminate H. Qed.

Lemma refa5_not1897 : ~ @Equation1897 Fin8 refa5_inst.
Proof. unfold Equation1897. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa5_inst, refa5_op in H. discriminate H. Qed.

Lemma refa5_not1921 : ~ @Equation1921 Fin8 refa5_inst.
Proof. unfold Equation1921. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa5_inst, refa5_op in H. discriminate H. Qed.

Lemma refa5_not1922 : ~ @Equation1922 Fin8 refa5_inst.
Proof. unfold Equation1922. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa5_inst, refa5_op in H. discriminate H. Qed.

Lemma refa5_not1924 : ~ @Equation1924 Fin8 refa5_inst.
Proof. unfold Equation1924. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa5_inst, refa5_op in H. discriminate H. Qed.

Lemma refa5_not1931 : ~ @Equation1931 Fin8 refa5_inst.
Proof. unfold Equation1931. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa5_inst, refa5_op in H. discriminate H. Qed.

Lemma refa5_not2036 : ~ @Equation2036 Fin8 refa5_inst.
Proof. unfold Equation2036. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa5_inst, refa5_op in H. discriminate H. Qed.

Lemma refa5_not2037 : ~ @Equation2037 Fin8 refa5_inst.
Proof. unfold Equation2037. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa5_inst, refa5_op in H. discriminate H. Qed.

Lemma refa5_not2038 : ~ @Equation2038 Fin8 refa5_inst.
Proof. unfold Equation2038. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa5_inst, refa5_op in H. discriminate H. Qed.

Lemma refa5_not2040 : ~ @Equation2040 Fin8 refa5_inst.
Proof. unfold Equation2040. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa5_inst, refa5_op in H. discriminate H. Qed.

Lemma refa5_not2041 : ~ @Equation2041 Fin8 refa5_inst.
Proof. unfold Equation2041. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa5_inst, refa5_op in H. discriminate H. Qed.

Lemma refa5_not2044 : ~ @Equation2044 Fin8 refa5_inst.
Proof. unfold Equation2044. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa5_inst, refa5_op in H. discriminate H. Qed.

Lemma refa5_not2050 : ~ @Equation2050 Fin8 refa5_inst.
Proof. unfold Equation2050. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa5_inst, refa5_op in H. discriminate H. Qed.

Lemma refa5_not2053 : ~ @Equation2053 Fin8 refa5_inst.
Proof. unfold Equation2053. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa5_inst, refa5_op in H. discriminate H. Qed.

Lemma refa5_not2054 : ~ @Equation2054 Fin8 refa5_inst.
Proof. unfold Equation2054. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa5_inst, refa5_op in H. discriminate H. Qed.

Lemma refa5_not2060 : ~ @Equation2060 Fin8 refa5_inst.
Proof. unfold Equation2060. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa5_inst, refa5_op in H. discriminate H. Qed.

Lemma refa5_not2061 : ~ @Equation2061 Fin8 refa5_inst.
Proof. unfold Equation2061. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa5_inst, refa5_op in H. discriminate H. Qed.

Lemma refa5_not2063 : ~ @Equation2063 Fin8 refa5_inst.
Proof. unfold Equation2063. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa5_inst, refa5_op in H. discriminate H. Qed.

Lemma refa5_not2064 : ~ @Equation2064 Fin8 refa5_inst.
Proof. unfold Equation2064. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa5_inst, refa5_op in H. discriminate H. Qed.

Lemma refa5_not2087 : ~ @Equation2087 Fin8 refa5_inst.
Proof. unfold Equation2087. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa5_inst, refa5_op in H. discriminate H. Qed.

Lemma refa5_not2088 : ~ @Equation2088 Fin8 refa5_inst.
Proof. unfold Equation2088. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa5_inst, refa5_op in H. discriminate H. Qed.

Lemma refa5_not2097 : ~ @Equation2097 Fin8 refa5_inst.
Proof. unfold Equation2097. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa5_inst, refa5_op in H. discriminate H. Qed.

Lemma refa5_not2101 : ~ @Equation2101 Fin8 refa5_inst.
Proof. unfold Equation2101. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa5_inst, refa5_op in H. discriminate H. Qed.

Lemma refa5_not2124 : ~ @Equation2124 Fin8 refa5_inst.
Proof. unfold Equation2124. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa5_inst, refa5_op in H. discriminate H. Qed.

Lemma refa5_not2125 : ~ @Equation2125 Fin8 refa5_inst.
Proof. unfold Equation2125. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa5_inst, refa5_op in H. discriminate H. Qed.

Lemma refa5_not2127 : ~ @Equation2127 Fin8 refa5_inst.
Proof. unfold Equation2127. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa5_inst, refa5_op in H. discriminate H. Qed.

Lemma refa5_not2128 : ~ @Equation2128 Fin8 refa5_inst.
Proof. unfold Equation2128. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa5_inst, refa5_op in H. discriminate H. Qed.

Lemma refa5_not2134 : ~ @Equation2134 Fin8 refa5_inst.
Proof. unfold Equation2134. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa5_inst, refa5_op in H. discriminate H. Qed.

Lemma refa5_not2240 : ~ @Equation2240 Fin8 refa5_inst.
Proof. unfold Equation2240. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa5_inst, refa5_op in H. discriminate H. Qed.

Lemma refa5_not2243 : ~ @Equation2243 Fin8 refa5_inst.
Proof. unfold Equation2243. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa5_inst, refa5_op in H. discriminate H. Qed.

Lemma refa5_not2244 : ~ @Equation2244 Fin8 refa5_inst.
Proof. unfold Equation2244. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa5_inst, refa5_op in H. discriminate H. Qed.

Lemma refa5_not2246 : ~ @Equation2246 Fin8 refa5_inst.
Proof. unfold Equation2246. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa5_inst, refa5_op in H. discriminate H. Qed.

Lemma refa5_not2247 : ~ @Equation2247 Fin8 refa5_inst.
Proof. unfold Equation2247. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa5_inst, refa5_op in H. discriminate H. Qed.

Lemma refa5_not2253 : ~ @Equation2253 Fin8 refa5_inst.
Proof. unfold Equation2253. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa5_inst, refa5_op in H. discriminate H. Qed.

Lemma refa5_not2254 : ~ @Equation2254 Fin8 refa5_inst.
Proof. unfold Equation2254. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa5_inst, refa5_op in H. discriminate H. Qed.

Lemma refa5_not2256 : ~ @Equation2256 Fin8 refa5_inst.
Proof. unfold Equation2256. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa5_inst, refa5_op in H. discriminate H. Qed.

Lemma refa5_not2257 : ~ @Equation2257 Fin8 refa5_inst.
Proof. unfold Equation2257. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa5_inst, refa5_op in H. discriminate H. Qed.

Lemma refa5_not2263 : ~ @Equation2263 Fin8 refa5_inst.
Proof. unfold Equation2263. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa5_inst, refa5_op in H. discriminate H. Qed.

Lemma refa5_not2264 : ~ @Equation2264 Fin8 refa5_inst.
Proof. unfold Equation2264. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa5_inst, refa5_op in H. discriminate H. Qed.

Lemma refa5_not2266 : ~ @Equation2266 Fin8 refa5_inst.
Proof. unfold Equation2266. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa5_inst, refa5_op in H. discriminate H. Qed.

Lemma refa5_not2290 : ~ @Equation2290 Fin8 refa5_inst.
Proof. unfold Equation2290. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa5_inst, refa5_op in H. discriminate H. Qed.

Lemma refa5_not2291 : ~ @Equation2291 Fin8 refa5_inst.
Proof. unfold Equation2291. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa5_inst, refa5_op in H. discriminate H. Qed.

Lemma refa5_not2293 : ~ @Equation2293 Fin8 refa5_inst.
Proof. unfold Equation2293. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa5_inst, refa5_op in H. discriminate H. Qed.

Lemma refa5_not2294 : ~ @Equation2294 Fin8 refa5_inst.
Proof. unfold Equation2294. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa5_inst, refa5_op in H. discriminate H. Qed.

Lemma refa5_not2300 : ~ @Equation2300 Fin8 refa5_inst.
Proof. unfold Equation2300. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa5_inst, refa5_op in H. discriminate H. Qed.

Lemma refa5_not2301 : ~ @Equation2301 Fin8 refa5_inst.
Proof. unfold Equation2301. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa5_inst, refa5_op in H. discriminate H. Qed.

Lemma refa5_not2303 : ~ @Equation2303 Fin8 refa5_inst.
Proof. unfold Equation2303. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa5_inst, refa5_op in H. discriminate H. Qed.

Lemma refa5_not2327 : ~ @Equation2327 Fin8 refa5_inst.
Proof. unfold Equation2327. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa5_inst, refa5_op in H. discriminate H. Qed.

Lemma refa5_not2337 : ~ @Equation2337 Fin8 refa5_inst.
Proof. unfold Equation2337. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa5_inst, refa5_op in H. discriminate H. Qed.

Lemma refa5_not2338 : ~ @Equation2338 Fin8 refa5_inst.
Proof. unfold Equation2338. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa5_inst, refa5_op in H. discriminate H. Qed.

Lemma refa5_not2340 : ~ @Equation2340 Fin8 refa5_inst.
Proof. unfold Equation2340. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa5_inst, refa5_op in H. discriminate H. Qed.

Lemma refa5_not2443 : ~ @Equation2443 Fin8 refa5_inst.
Proof. unfold Equation2443. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa5_inst, refa5_op in H. discriminate H. Qed.

Lemma refa5_not2444 : ~ @Equation2444 Fin8 refa5_inst.
Proof. unfold Equation2444. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa5_inst, refa5_op in H. discriminate H. Qed.

Lemma refa5_not2446 : ~ @Equation2446 Fin8 refa5_inst.
Proof. unfold Equation2446. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa5_inst, refa5_op in H. discriminate H. Qed.

Lemma refa5_not2447 : ~ @Equation2447 Fin8 refa5_inst.
Proof. unfold Equation2447. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa5_inst, refa5_op in H. discriminate H. Qed.

Lemma refa5_not2449 : ~ @Equation2449 Fin8 refa5_inst.
Proof. unfold Equation2449. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa5_inst, refa5_op in H. discriminate H. Qed.

Lemma refa5_not2456 : ~ @Equation2456 Fin8 refa5_inst.
Proof. unfold Equation2456. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa5_inst, refa5_op in H. discriminate H. Qed.

Lemma refa5_not2457 : ~ @Equation2457 Fin8 refa5_inst.
Proof. unfold Equation2457. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa5_inst, refa5_op in H. discriminate H. Qed.

Lemma refa5_not2459 : ~ @Equation2459 Fin8 refa5_inst.
Proof. unfold Equation2459. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa5_inst, refa5_op in H. discriminate H. Qed.

Lemma refa5_not2460 : ~ @Equation2460 Fin8 refa5_inst.
Proof. unfold Equation2460. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa5_inst, refa5_op in H. discriminate H. Qed.

Lemma refa5_not2466 : ~ @Equation2466 Fin8 refa5_inst.
Proof. unfold Equation2466. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa5_inst, refa5_op in H. discriminate H. Qed.

Lemma refa5_not2467 : ~ @Equation2467 Fin8 refa5_inst.
Proof. unfold Equation2467. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa5_inst, refa5_op in H. discriminate H. Qed.

Lemma refa5_not2469 : ~ @Equation2469 Fin8 refa5_inst.
Proof. unfold Equation2469. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa5_inst, refa5_op in H. discriminate H. Qed.

Lemma refa5_not2493 : ~ @Equation2493 Fin8 refa5_inst.
Proof. unfold Equation2493. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa5_inst, refa5_op in H. discriminate H. Qed.

Lemma refa5_not2496 : ~ @Equation2496 Fin8 refa5_inst.
Proof. unfold Equation2496. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa5_inst, refa5_op in H. discriminate H. Qed.

Lemma refa5_not2497 : ~ @Equation2497 Fin8 refa5_inst.
Proof. unfold Equation2497. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa5_inst, refa5_op in H. discriminate H. Qed.

Lemma refa5_not2503 : ~ @Equation2503 Fin8 refa5_inst.
Proof. unfold Equation2503. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa5_inst, refa5_op in H. discriminate H. Qed.

Lemma refa5_not2504 : ~ @Equation2504 Fin8 refa5_inst.
Proof. unfold Equation2504. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa5_inst, refa5_op in H. discriminate H. Qed.

Lemma refa5_not2506 : ~ @Equation2506 Fin8 refa5_inst.
Proof. unfold Equation2506. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa5_inst, refa5_op in H. discriminate H. Qed.

Lemma refa5_not2530 : ~ @Equation2530 Fin8 refa5_inst.
Proof. unfold Equation2530. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa5_inst, refa5_op in H. discriminate H. Qed.

Lemma refa5_not2531 : ~ @Equation2531 Fin8 refa5_inst.
Proof. unfold Equation2531. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa5_inst, refa5_op in H. discriminate H. Qed.

Lemma refa5_not2534 : ~ @Equation2534 Fin8 refa5_inst.
Proof. unfold Equation2534. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa5_inst, refa5_op in H. discriminate H. Qed.

Lemma refa5_not2540 : ~ @Equation2540 Fin8 refa5_inst.
Proof. unfold Equation2540. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa5_inst, refa5_op in H. discriminate H. Qed.

Lemma refa5_not2543 : ~ @Equation2543 Fin8 refa5_inst.
Proof. unfold Equation2543. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa5_inst, refa5_op in H. discriminate H. Qed.

Lemma refa5_not2646 : ~ @Equation2646 Fin8 refa5_inst.
Proof. unfold Equation2646. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa5_inst, refa5_op in H. discriminate H. Qed.

Lemma refa5_not2647 : ~ @Equation2647 Fin8 refa5_inst.
Proof. unfold Equation2647. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa5_inst, refa5_op in H. discriminate H. Qed.

Lemma refa5_not2649 : ~ @Equation2649 Fin8 refa5_inst.
Proof. unfold Equation2649. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa5_inst, refa5_op in H. discriminate H. Qed.

Lemma refa5_not2650 : ~ @Equation2650 Fin8 refa5_inst.
Proof. unfold Equation2650. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa5_inst, refa5_op in H. discriminate H. Qed.

Lemma refa5_not2652 : ~ @Equation2652 Fin8 refa5_inst.
Proof. unfold Equation2652. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa5_inst, refa5_op in H. discriminate H. Qed.

Lemma refa5_not2659 : ~ @Equation2659 Fin8 refa5_inst.
Proof. unfold Equation2659. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa5_inst, refa5_op in H. discriminate H. Qed.

Lemma refa5_not2660 : ~ @Equation2660 Fin8 refa5_inst.
Proof. unfold Equation2660. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa5_inst, refa5_op in H. discriminate H. Qed.

Lemma refa5_not2662 : ~ @Equation2662 Fin8 refa5_inst.
Proof. unfold Equation2662. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa5_inst, refa5_op in H. discriminate H. Qed.

Lemma refa5_not2670 : ~ @Equation2670 Fin8 refa5_inst.
Proof. unfold Equation2670. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa5_inst, refa5_op in H. discriminate H. Qed.

Lemma refa5_not2672 : ~ @Equation2672 Fin8 refa5_inst.
Proof. unfold Equation2672. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa5_inst, refa5_op in H. discriminate H. Qed.

Lemma refa5_not2696 : ~ @Equation2696 Fin8 refa5_inst.
Proof. unfold Equation2696. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa5_inst, refa5_op in H. discriminate H. Qed.

Lemma refa5_not2699 : ~ @Equation2699 Fin8 refa5_inst.
Proof. unfold Equation2699. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa5_inst, refa5_op in H. discriminate H. Qed.

Lemma refa5_not2700 : ~ @Equation2700 Fin8 refa5_inst.
Proof. unfold Equation2700. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa5_inst, refa5_op in H. discriminate H. Qed.

Lemma refa5_not2706 : ~ @Equation2706 Fin8 refa5_inst.
Proof. unfold Equation2706. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa5_inst, refa5_op in H. discriminate H. Qed.

Lemma refa5_not2709 : ~ @Equation2709 Fin8 refa5_inst.
Proof. unfold Equation2709. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa5_inst, refa5_op in H. discriminate H. Qed.

Lemma refa5_not2710 : ~ @Equation2710 Fin8 refa5_inst.
Proof. unfold Equation2710. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa5_inst, refa5_op in H. discriminate H. Qed.

Lemma refa5_not2733 : ~ @Equation2733 Fin8 refa5_inst.
Proof. unfold Equation2733. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa5_inst, refa5_op in H. discriminate H. Qed.

Lemma refa5_not2734 : ~ @Equation2734 Fin8 refa5_inst.
Proof. unfold Equation2734. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa5_inst, refa5_op in H. discriminate H. Qed.

Lemma refa5_not2736 : ~ @Equation2736 Fin8 refa5_inst.
Proof. unfold Equation2736. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa5_inst, refa5_op in H. discriminate H. Qed.

Lemma refa5_not2743 : ~ @Equation2743 Fin8 refa5_inst.
Proof. unfold Equation2743. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa5_inst, refa5_op in H. discriminate H. Qed.

Lemma refa5_not2746 : ~ @Equation2746 Fin8 refa5_inst.
Proof. unfold Equation2746. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa5_inst, refa5_op in H. discriminate H. Qed.

Lemma refa5_not2849 : ~ @Equation2849 Fin8 refa5_inst.
Proof. unfold Equation2849. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa5_inst, refa5_op in H. discriminate H. Qed.

Lemma refa5_not2852 : ~ @Equation2852 Fin8 refa5_inst.
Proof. unfold Equation2852. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa5_inst, refa5_op in H. discriminate H. Qed.

Lemma refa5_not2853 : ~ @Equation2853 Fin8 refa5_inst.
Proof. unfold Equation2853. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa5_inst, refa5_op in H. discriminate H. Qed.

Lemma refa5_not2855 : ~ @Equation2855 Fin8 refa5_inst.
Proof. unfold Equation2855. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa5_inst, refa5_op in H. discriminate H. Qed.

Lemma refa5_not2856 : ~ @Equation2856 Fin8 refa5_inst.
Proof. unfold Equation2856. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa5_inst, refa5_op in H. discriminate H. Qed.

Lemma refa5_not2862 : ~ @Equation2862 Fin8 refa5_inst.
Proof. unfold Equation2862. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa5_inst, refa5_op in H. discriminate H. Qed.

Lemma refa5_not2863 : ~ @Equation2863 Fin8 refa5_inst.
Proof. unfold Equation2863. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa5_inst, refa5_op in H. discriminate H. Qed.

Lemma refa5_not2865 : ~ @Equation2865 Fin8 refa5_inst.
Proof. unfold Equation2865. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa5_inst, refa5_op in H. discriminate H. Qed.

Lemma refa5_not2872 : ~ @Equation2872 Fin8 refa5_inst.
Proof. unfold Equation2872. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa5_inst, refa5_op in H. discriminate H. Qed.

Lemma refa5_not2873 : ~ @Equation2873 Fin8 refa5_inst.
Proof. unfold Equation2873. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa5_inst, refa5_op in H. discriminate H. Qed.

Lemma refa5_not2875 : ~ @Equation2875 Fin8 refa5_inst.
Proof. unfold Equation2875. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa5_inst, refa5_op in H. discriminate H. Qed.

Lemma refa5_not2899 : ~ @Equation2899 Fin8 refa5_inst.
Proof. unfold Equation2899. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa5_inst, refa5_op in H. discriminate H. Qed.

Lemma refa5_not2902 : ~ @Equation2902 Fin8 refa5_inst.
Proof. unfold Equation2902. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa5_inst, refa5_op in H. discriminate H. Qed.

Lemma refa5_not2903 : ~ @Equation2903 Fin8 refa5_inst.
Proof. unfold Equation2903. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa5_inst, refa5_op in H. discriminate H. Qed.

Lemma refa5_not2909 : ~ @Equation2909 Fin8 refa5_inst.
Proof. unfold Equation2909. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa5_inst, refa5_op in H. discriminate H. Qed.

Lemma refa5_not2910 : ~ @Equation2910 Fin8 refa5_inst.
Proof. unfold Equation2910. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa5_inst, refa5_op in H. discriminate H. Qed.

Lemma refa5_not2912 : ~ @Equation2912 Fin8 refa5_inst.
Proof. unfold Equation2912. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa5_inst, refa5_op in H. discriminate H. Qed.

Lemma refa5_not2936 : ~ @Equation2936 Fin8 refa5_inst.
Proof. unfold Equation2936. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa5_inst, refa5_op in H. discriminate H. Qed.

Lemma refa5_not2937 : ~ @Equation2937 Fin8 refa5_inst.
Proof. unfold Equation2937. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa5_inst, refa5_op in H. discriminate H. Qed.

Lemma refa5_not2940 : ~ @Equation2940 Fin8 refa5_inst.
Proof. unfold Equation2940. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa5_inst, refa5_op in H. discriminate H. Qed.

Lemma refa5_not2946 : ~ @Equation2946 Fin8 refa5_inst.
Proof. unfold Equation2946. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa5_inst, refa5_op in H. discriminate H. Qed.

Lemma refa5_not2947 : ~ @Equation2947 Fin8 refa5_inst.
Proof. unfold Equation2947. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa5_inst, refa5_op in H. discriminate H. Qed.

Lemma refa5_not2949 : ~ @Equation2949 Fin8 refa5_inst.
Proof. unfold Equation2949. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa5_inst, refa5_op in H. discriminate H. Qed.

Lemma refa5_not3052 : ~ @Equation3052 Fin8 refa5_inst.
Proof. unfold Equation3052. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa5_inst, refa5_op in H. discriminate H. Qed.

Lemma refa5_not3055 : ~ @Equation3055 Fin8 refa5_inst.
Proof. unfold Equation3055. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa5_inst, refa5_op in H. discriminate H. Qed.

Lemma refa5_not3056 : ~ @Equation3056 Fin8 refa5_inst.
Proof. unfold Equation3056. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa5_inst, refa5_op in H. discriminate H. Qed.

Lemma refa5_not3058 : ~ @Equation3058 Fin8 refa5_inst.
Proof. unfold Equation3058. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa5_inst, refa5_op in H. discriminate H. Qed.

Lemma refa5_not3065 : ~ @Equation3065 Fin8 refa5_inst.
Proof. unfold Equation3065. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa5_inst, refa5_op in H. discriminate H. Qed.

Lemma refa5_not3066 : ~ @Equation3066 Fin8 refa5_inst.
Proof. unfold Equation3066. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa5_inst, refa5_op in H. discriminate H. Qed.

Lemma refa5_not3068 : ~ @Equation3068 Fin8 refa5_inst.
Proof. unfold Equation3068. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa5_inst, refa5_op in H. discriminate H. Qed.

Lemma refa5_not3075 : ~ @Equation3075 Fin8 refa5_inst.
Proof. unfold Equation3075. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa5_inst, refa5_op in H. discriminate H. Qed.

Lemma refa5_not3076 : ~ @Equation3076 Fin8 refa5_inst.
Proof. unfold Equation3076. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa5_inst, refa5_op in H. discriminate H. Qed.

Lemma refa5_not3078 : ~ @Equation3078 Fin8 refa5_inst.
Proof. unfold Equation3078. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa5_inst, refa5_op in H. discriminate H. Qed.

Lemma refa5_not3079 : ~ @Equation3079 Fin8 refa5_inst.
Proof. unfold Equation3079. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa5_inst, refa5_op in H. discriminate H. Qed.

Lemma refa5_not3102 : ~ @Equation3102 Fin8 refa5_inst.
Proof. unfold Equation3102. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa5_inst, refa5_op in H. discriminate H. Qed.

Lemma refa5_not3103 : ~ @Equation3103 Fin8 refa5_inst.
Proof. unfold Equation3103. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa5_inst, refa5_op in H. discriminate H. Qed.

Lemma refa5_not3106 : ~ @Equation3106 Fin8 refa5_inst.
Proof. unfold Equation3106. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa5_inst, refa5_op in H. discriminate H. Qed.

Lemma refa5_not3112 : ~ @Equation3112 Fin8 refa5_inst.
Proof. unfold Equation3112. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa5_inst, refa5_op in H. discriminate H. Qed.

Lemma refa5_not3113 : ~ @Equation3113 Fin8 refa5_inst.
Proof. unfold Equation3113. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa5_inst, refa5_op in H. discriminate H. Qed.

Lemma refa5_not3115 : ~ @Equation3115 Fin8 refa5_inst.
Proof. unfold Equation3115. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa5_inst, refa5_op in H. discriminate H. Qed.

Lemma refa5_not3116 : ~ @Equation3116 Fin8 refa5_inst.
Proof. unfold Equation3116. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa5_inst, refa5_op in H. discriminate H. Qed.

Lemma refa5_not3139 : ~ @Equation3139 Fin8 refa5_inst.
Proof. unfold Equation3139. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa5_inst, refa5_op in H. discriminate H. Qed.

Lemma refa5_not3142 : ~ @Equation3142 Fin8 refa5_inst.
Proof. unfold Equation3142. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa5_inst, refa5_op in H. discriminate H. Qed.

Lemma refa5_not3143 : ~ @Equation3143 Fin8 refa5_inst.
Proof. unfold Equation3143. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa5_inst, refa5_op in H. discriminate H. Qed.

Lemma refa5_not3149 : ~ @Equation3149 Fin8 refa5_inst.
Proof. unfold Equation3149. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa5_inst, refa5_op in H. discriminate H. Qed.

Lemma refa5_not3150 : ~ @Equation3150 Fin8 refa5_inst.
Proof. unfold Equation3150. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa5_inst, refa5_op in H. discriminate H. Qed.

Lemma refa5_not3152 : ~ @Equation3152 Fin8 refa5_inst.
Proof. unfold Equation3152. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa5_inst, refa5_op in H. discriminate H. Qed.

Lemma refa5_not3254 : ~ @Equation3254 Fin8 refa5_inst.
Proof. unfold Equation3254. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa5_inst, refa5_op in H. discriminate H. Qed.

Lemma refa5_not3255 : ~ @Equation3255 Fin8 refa5_inst.
Proof. unfold Equation3255. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa5_inst, refa5_op in H. discriminate H. Qed.

Lemma refa5_not3256 : ~ @Equation3256 Fin8 refa5_inst.
Proof. unfold Equation3256. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa5_inst, refa5_op in H. discriminate H. Qed.

Lemma refa5_not3258 : ~ @Equation3258 Fin8 refa5_inst.
Proof. unfold Equation3258. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa5_inst, refa5_op in H. discriminate H. Qed.

Lemma refa5_not3259 : ~ @Equation3259 Fin8 refa5_inst.
Proof. unfold Equation3259. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa5_inst, refa5_op in H. discriminate H. Qed.

Lemma refa5_not3261 : ~ @Equation3261 Fin8 refa5_inst.
Proof. unfold Equation3261. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa5_inst, refa5_op in H. discriminate H. Qed.

Lemma refa5_not3262 : ~ @Equation3262 Fin8 refa5_inst.
Proof. unfold Equation3262. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa5_inst, refa5_op in H. discriminate H. Qed.

Lemma refa5_not3268 : ~ @Equation3268 Fin8 refa5_inst.
Proof. unfold Equation3268. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa5_inst, refa5_op in H. discriminate H. Qed.

Lemma refa5_not3269 : ~ @Equation3269 Fin8 refa5_inst.
Proof. unfold Equation3269. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa5_inst, refa5_op in H. discriminate H. Qed.

Lemma refa5_not3271 : ~ @Equation3271 Fin8 refa5_inst.
Proof. unfold Equation3271. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa5_inst, refa5_op in H. discriminate H. Qed.

Lemma refa5_not3272 : ~ @Equation3272 Fin8 refa5_inst.
Proof. unfold Equation3272. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa5_inst, refa5_op in H. discriminate H. Qed.

Lemma refa5_not3278 : ~ @Equation3278 Fin8 refa5_inst.
Proof. unfold Equation3278. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa5_inst, refa5_op in H. discriminate H. Qed.

Lemma refa5_not3281 : ~ @Equation3281 Fin8 refa5_inst.
Proof. unfold Equation3281. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa5_inst, refa5_op in H. discriminate H. Qed.

Lemma refa5_not3306 : ~ @Equation3306 Fin8 refa5_inst.
Proof. unfold Equation3306. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa5_inst, refa5_op in H. discriminate H. Qed.

Lemma refa5_not3308 : ~ @Equation3308 Fin8 refa5_inst.
Proof. unfold Equation3308. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa5_inst, refa5_op in H. discriminate H. Qed.

Lemma refa5_not3309 : ~ @Equation3309 Fin8 refa5_inst.
Proof. unfold Equation3309. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa5_inst, refa5_op in H. discriminate H. Qed.

Lemma refa5_not3315 : ~ @Equation3315 Fin8 refa5_inst.
Proof. unfold Equation3315. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa5_inst, refa5_op in H. discriminate H. Qed.

Lemma refa5_not3316 : ~ @Equation3316 Fin8 refa5_inst.
Proof. unfold Equation3316. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa5_inst, refa5_op in H. discriminate H. Qed.

Lemma refa5_not3318 : ~ @Equation3318 Fin8 refa5_inst.
Proof. unfold Equation3318. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa5_inst, refa5_op in H. discriminate H. Qed.

Lemma refa5_not3342 : ~ @Equation3342 Fin8 refa5_inst.
Proof. unfold Equation3342. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa5_inst, refa5_op in H. discriminate H. Qed.

Lemma refa5_not3343 : ~ @Equation3343 Fin8 refa5_inst.
Proof. unfold Equation3343. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa5_inst, refa5_op in H. discriminate H. Qed.

Lemma refa5_not3346 : ~ @Equation3346 Fin8 refa5_inst.
Proof. unfold Equation3346. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa5_inst, refa5_op in H. discriminate H. Qed.

Lemma refa5_not3352 : ~ @Equation3352 Fin8 refa5_inst.
Proof. unfold Equation3352. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa5_inst, refa5_op in H. discriminate H. Qed.

Lemma refa5_not3353 : ~ @Equation3353 Fin8 refa5_inst.
Proof. unfold Equation3353. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa5_inst, refa5_op in H. discriminate H. Qed.

Lemma refa5_not3355 : ~ @Equation3355 Fin8 refa5_inst.
Proof. unfold Equation3355. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa5_inst, refa5_op in H. discriminate H. Qed.

Lemma refa5_not3457 : ~ @Equation3457 Fin8 refa5_inst.
Proof. unfold Equation3457. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa5_inst, refa5_op in H. discriminate H. Qed.

Lemma refa5_not3458 : ~ @Equation3458 Fin8 refa5_inst.
Proof. unfold Equation3458. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa5_inst, refa5_op in H. discriminate H. Qed.

Lemma refa5_not3459 : ~ @Equation3459 Fin8 refa5_inst.
Proof. unfold Equation3459. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa5_inst, refa5_op in H. discriminate H. Qed.

Lemma refa5_not3461 : ~ @Equation3461 Fin8 refa5_inst.
Proof. unfold Equation3461. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa5_inst, refa5_op in H. discriminate H. Qed.

Lemma refa5_not3462 : ~ @Equation3462 Fin8 refa5_inst.
Proof. unfold Equation3462. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa5_inst, refa5_op in H. discriminate H. Qed.

Lemma refa5_not3464 : ~ @Equation3464 Fin8 refa5_inst.
Proof. unfold Equation3464. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa5_inst, refa5_op in H. discriminate H. Qed.

Lemma refa5_not3465 : ~ @Equation3465 Fin8 refa5_inst.
Proof. unfold Equation3465. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa5_inst, refa5_op in H. discriminate H. Qed.

Lemma refa5_not3472 : ~ @Equation3472 Fin8 refa5_inst.
Proof. unfold Equation3472. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa5_inst, refa5_op in H. discriminate H. Qed.

Lemma refa5_not3474 : ~ @Equation3474 Fin8 refa5_inst.
Proof. unfold Equation3474. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa5_inst, refa5_op in H. discriminate H. Qed.

Lemma refa5_not3475 : ~ @Equation3475 Fin8 refa5_inst.
Proof. unfold Equation3475. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa5_inst, refa5_op in H. discriminate H. Qed.

Lemma refa5_not3481 : ~ @Equation3481 Fin8 refa5_inst.
Proof. unfold Equation3481. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa5_inst, refa5_op in H. discriminate H. Qed.

Lemma refa5_not3484 : ~ @Equation3484 Fin8 refa5_inst.
Proof. unfold Equation3484. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa5_inst, refa5_op in H. discriminate H. Qed.

Lemma refa5_not3509 : ~ @Equation3509 Fin8 refa5_inst.
Proof. unfold Equation3509. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa5_inst, refa5_op in H. discriminate H. Qed.

Lemma refa5_not3511 : ~ @Equation3511 Fin8 refa5_inst.
Proof. unfold Equation3511. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa5_inst, refa5_op in H. discriminate H. Qed.

Lemma refa5_not3512 : ~ @Equation3512 Fin8 refa5_inst.
Proof. unfold Equation3512. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa5_inst, refa5_op in H. discriminate H. Qed.

Lemma refa5_not3518 : ~ @Equation3518 Fin8 refa5_inst.
Proof. unfold Equation3518. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa5_inst, refa5_op in H. discriminate H. Qed.

Lemma refa5_not3519 : ~ @Equation3519 Fin8 refa5_inst.
Proof. unfold Equation3519. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa5_inst, refa5_op in H. discriminate H. Qed.

Lemma refa5_not3521 : ~ @Equation3521 Fin8 refa5_inst.
Proof. unfold Equation3521. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa5_inst, refa5_op in H. discriminate H. Qed.

Lemma refa5_not3545 : ~ @Equation3545 Fin8 refa5_inst.
Proof. unfold Equation3545. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa5_inst, refa5_op in H. discriminate H. Qed.

Lemma refa5_not3546 : ~ @Equation3546 Fin8 refa5_inst.
Proof. unfold Equation3546. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa5_inst, refa5_op in H. discriminate H. Qed.

Lemma refa5_not3549 : ~ @Equation3549 Fin8 refa5_inst.
Proof. unfold Equation3549. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa5_inst, refa5_op in H. discriminate H. Qed.

Lemma refa5_not3555 : ~ @Equation3555 Fin8 refa5_inst.
Proof. unfold Equation3555. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa5_inst, refa5_op in H. discriminate H. Qed.

Lemma refa5_not3556 : ~ @Equation3556 Fin8 refa5_inst.
Proof. unfold Equation3556. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa5_inst, refa5_op in H. discriminate H. Qed.

Lemma refa5_not3558 : ~ @Equation3558 Fin8 refa5_inst.
Proof. unfold Equation3558. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa5_inst, refa5_op in H. discriminate H. Qed.

Lemma refa5_not3660 : ~ @Equation3660 Fin8 refa5_inst.
Proof. unfold Equation3660. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa5_inst, refa5_op in H. discriminate H. Qed.

Lemma refa5_not3661 : ~ @Equation3661 Fin8 refa5_inst.
Proof. unfold Equation3661. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa5_inst, refa5_op in H. discriminate H. Qed.

Lemma refa5_not3662 : ~ @Equation3662 Fin8 refa5_inst.
Proof. unfold Equation3662. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa5_inst, refa5_op in H. discriminate H. Qed.

Lemma refa5_not3664 : ~ @Equation3664 Fin8 refa5_inst.
Proof. unfold Equation3664. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa5_inst, refa5_op in H. discriminate H. Qed.

Lemma refa5_not3665 : ~ @Equation3665 Fin8 refa5_inst.
Proof. unfold Equation3665. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa5_inst, refa5_op in H. discriminate H. Qed.

Lemma refa5_not3668 : ~ @Equation3668 Fin8 refa5_inst.
Proof. unfold Equation3668. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa5_inst, refa5_op in H. discriminate H. Qed.

Lemma refa5_not3674 : ~ @Equation3674 Fin8 refa5_inst.
Proof. unfold Equation3674. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa5_inst, refa5_op in H. discriminate H. Qed.

Lemma refa5_not3675 : ~ @Equation3675 Fin8 refa5_inst.
Proof. unfold Equation3675. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa5_inst, refa5_op in H. discriminate H. Qed.

Lemma refa5_not3677 : ~ @Equation3677 Fin8 refa5_inst.
Proof. unfold Equation3677. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa5_inst, refa5_op in H. discriminate H. Qed.

Lemma refa5_not3678 : ~ @Equation3678 Fin8 refa5_inst.
Proof. unfold Equation3678. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa5_inst, refa5_op in H. discriminate H. Qed.

Lemma refa5_not3684 : ~ @Equation3684 Fin8 refa5_inst.
Proof. unfold Equation3684. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa5_inst, refa5_op in H. discriminate H. Qed.

Lemma refa5_not3685 : ~ @Equation3685 Fin8 refa5_inst.
Proof. unfold Equation3685. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa5_inst, refa5_op in H. discriminate H. Qed.

Lemma refa5_not3687 : ~ @Equation3687 Fin8 refa5_inst.
Proof. unfold Equation3687. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa5_inst, refa5_op in H. discriminate H. Qed.

Lemma refa5_not3712 : ~ @Equation3712 Fin8 refa5_inst.
Proof. unfold Equation3712. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa5_inst, refa5_op in H. discriminate H. Qed.

Lemma refa5_not3714 : ~ @Equation3714 Fin8 refa5_inst.
Proof. unfold Equation3714. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa5_inst, refa5_op in H. discriminate H. Qed.

Lemma refa5_not3721 : ~ @Equation3721 Fin8 refa5_inst.
Proof. unfold Equation3721. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa5_inst, refa5_op in H. discriminate H. Qed.

Lemma refa5_not3724 : ~ @Equation3724 Fin8 refa5_inst.
Proof. unfold Equation3724. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa5_inst, refa5_op in H. discriminate H. Qed.

Lemma refa5_not3725 : ~ @Equation3725 Fin8 refa5_inst.
Proof. unfold Equation3725. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa5_inst, refa5_op in H. discriminate H. Qed.

Lemma refa5_not3748 : ~ @Equation3748 Fin8 refa5_inst.
Proof. unfold Equation3748. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa5_inst, refa5_op in H. discriminate H. Qed.

Lemma refa5_not3749 : ~ @Equation3749 Fin8 refa5_inst.
Proof. unfold Equation3749. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa5_inst, refa5_op in H. discriminate H. Qed.

Lemma refa5_not3752 : ~ @Equation3752 Fin8 refa5_inst.
Proof. unfold Equation3752. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa5_inst, refa5_op in H. discriminate H. Qed.

Lemma refa5_not3759 : ~ @Equation3759 Fin8 refa5_inst.
Proof. unfold Equation3759. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa5_inst, refa5_op in H. discriminate H. Qed.

Lemma refa5_not3761 : ~ @Equation3761 Fin8 refa5_inst.
Proof. unfold Equation3761. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa5_inst, refa5_op in H. discriminate H. Qed.

Lemma refa5_not3864 : ~ @Equation3864 Fin8 refa5_inst.
Proof. unfold Equation3864. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa5_inst, refa5_op in H. discriminate H. Qed.

Lemma refa5_not3865 : ~ @Equation3865 Fin8 refa5_inst.
Proof. unfold Equation3865. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa5_inst, refa5_op in H. discriminate H. Qed.

Lemma refa5_not3867 : ~ @Equation3867 Fin8 refa5_inst.
Proof. unfold Equation3867. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa5_inst, refa5_op in H. discriminate H. Qed.

Lemma refa5_not3868 : ~ @Equation3868 Fin8 refa5_inst.
Proof. unfold Equation3868. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa5_inst, refa5_op in H. discriminate H. Qed.

Lemma refa5_not3870 : ~ @Equation3870 Fin8 refa5_inst.
Proof. unfold Equation3870. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa5_inst, refa5_op in H. discriminate H. Qed.

Lemma refa5_not3871 : ~ @Equation3871 Fin8 refa5_inst.
Proof. unfold Equation3871. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa5_inst, refa5_op in H. discriminate H. Qed.

Lemma refa5_not3877 : ~ @Equation3877 Fin8 refa5_inst.
Proof. unfold Equation3877. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa5_inst, refa5_op in H. discriminate H. Qed.

Lemma refa5_not3878 : ~ @Equation3878 Fin8 refa5_inst.
Proof. unfold Equation3878. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa5_inst, refa5_op in H. discriminate H. Qed.

Lemma refa5_not3880 : ~ @Equation3880 Fin8 refa5_inst.
Proof. unfold Equation3880. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa5_inst, refa5_op in H. discriminate H. Qed.

Lemma refa5_not3881 : ~ @Equation3881 Fin8 refa5_inst.
Proof. unfold Equation3881. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa5_inst, refa5_op in H. discriminate H. Qed.

Lemma refa5_not3887 : ~ @Equation3887 Fin8 refa5_inst.
Proof. unfold Equation3887. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa5_inst, refa5_op in H. discriminate H. Qed.

Lemma refa5_not3890 : ~ @Equation3890 Fin8 refa5_inst.
Proof. unfold Equation3890. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa5_inst, refa5_op in H. discriminate H. Qed.

Lemma refa5_not3917 : ~ @Equation3917 Fin8 refa5_inst.
Proof. unfold Equation3917. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa5_inst, refa5_op in H. discriminate H. Qed.

Lemma refa5_not3918 : ~ @Equation3918 Fin8 refa5_inst.
Proof. unfold Equation3918. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa5_inst, refa5_op in H. discriminate H. Qed.

Lemma refa5_not3924 : ~ @Equation3924 Fin8 refa5_inst.
Proof. unfold Equation3924. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa5_inst, refa5_op in H. discriminate H. Qed.

Lemma refa5_not3925 : ~ @Equation3925 Fin8 refa5_inst.
Proof. unfold Equation3925. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa5_inst, refa5_op in H. discriminate H. Qed.

Lemma refa5_not3927 : ~ @Equation3927 Fin8 refa5_inst.
Proof. unfold Equation3927. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa5_inst, refa5_op in H. discriminate H. Qed.

Lemma refa5_not3928 : ~ @Equation3928 Fin8 refa5_inst.
Proof. unfold Equation3928. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa5_inst, refa5_op in H. discriminate H. Qed.

Lemma refa5_not3951 : ~ @Equation3951 Fin8 refa5_inst.
Proof. unfold Equation3951. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa5_inst, refa5_op in H. discriminate H. Qed.

Lemma refa5_not3952 : ~ @Equation3952 Fin8 refa5_inst.
Proof. unfold Equation3952. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa5_inst, refa5_op in H. discriminate H. Qed.

Lemma refa5_not3954 : ~ @Equation3954 Fin8 refa5_inst.
Proof. unfold Equation3954. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa5_inst, refa5_op in H. discriminate H. Qed.

Lemma refa5_not3955 : ~ @Equation3955 Fin8 refa5_inst.
Proof. unfold Equation3955. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa5_inst, refa5_op in H. discriminate H. Qed.

Lemma refa5_not3962 : ~ @Equation3962 Fin8 refa5_inst.
Proof. unfold Equation3962. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa5_inst, refa5_op in H. discriminate H. Qed.

Lemma refa5_not3964 : ~ @Equation3964 Fin8 refa5_inst.
Proof. unfold Equation3964. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa5_inst, refa5_op in H. discriminate H. Qed.

Lemma refa5_not4066 : ~ @Equation4066 Fin8 refa5_inst.
Proof. unfold Equation4066. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa5_inst, refa5_op in H. discriminate H. Qed.

Lemma refa5_not4067 : ~ @Equation4067 Fin8 refa5_inst.
Proof. unfold Equation4067. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa5_inst, refa5_op in H. discriminate H. Qed.

Lemma refa5_not4068 : ~ @Equation4068 Fin8 refa5_inst.
Proof. unfold Equation4068. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa5_inst, refa5_op in H. discriminate H. Qed.

Lemma refa5_not4070 : ~ @Equation4070 Fin8 refa5_inst.
Proof. unfold Equation4070. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa5_inst, refa5_op in H. discriminate H. Qed.

Lemma refa5_not4071 : ~ @Equation4071 Fin8 refa5_inst.
Proof. unfold Equation4071. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa5_inst, refa5_op in H. discriminate H. Qed.

Lemma refa5_not4073 : ~ @Equation4073 Fin8 refa5_inst.
Proof. unfold Equation4073. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa5_inst, refa5_op in H. discriminate H. Qed.

Lemma refa5_not4074 : ~ @Equation4074 Fin8 refa5_inst.
Proof. unfold Equation4074. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa5_inst, refa5_op in H. discriminate H. Qed.

Lemma refa5_not4080 : ~ @Equation4080 Fin8 refa5_inst.
Proof. unfold Equation4080. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa5_inst, refa5_op in H. discriminate H. Qed.

Lemma refa5_not4083 : ~ @Equation4083 Fin8 refa5_inst.
Proof. unfold Equation4083. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa5_inst, refa5_op in H. discriminate H. Qed.

Lemma refa5_not4084 : ~ @Equation4084 Fin8 refa5_inst.
Proof. unfold Equation4084. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa5_inst, refa5_op in H. discriminate H. Qed.

Lemma refa5_not4090 : ~ @Equation4090 Fin8 refa5_inst.
Proof. unfold Equation4090. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa5_inst, refa5_op in H. discriminate H. Qed.

Lemma refa5_not4091 : ~ @Equation4091 Fin8 refa5_inst.
Proof. unfold Equation4091. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa5_inst, refa5_op in H. discriminate H. Qed.

Lemma refa5_not4093 : ~ @Equation4093 Fin8 refa5_inst.
Proof. unfold Equation4093. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa5_inst, refa5_op in H. discriminate H. Qed.

Lemma refa5_not4120 : ~ @Equation4120 Fin8 refa5_inst.
Proof. unfold Equation4120. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa5_inst, refa5_op in H. discriminate H. Qed.

Lemma refa5_not4121 : ~ @Equation4121 Fin8 refa5_inst.
Proof. unfold Equation4121. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa5_inst, refa5_op in H. discriminate H. Qed.

Lemma refa5_not4127 : ~ @Equation4127 Fin8 refa5_inst.
Proof. unfold Equation4127. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa5_inst, refa5_op in H. discriminate H. Qed.

Lemma refa5_not4128 : ~ @Equation4128 Fin8 refa5_inst.
Proof. unfold Equation4128. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa5_inst, refa5_op in H. discriminate H. Qed.

Lemma refa5_not4130 : ~ @Equation4130 Fin8 refa5_inst.
Proof. unfold Equation4130. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa5_inst, refa5_op in H. discriminate H. Qed.

Lemma refa5_not4131 : ~ @Equation4131 Fin8 refa5_inst.
Proof. unfold Equation4131. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa5_inst, refa5_op in H. discriminate H. Qed.

Lemma refa5_not4155 : ~ @Equation4155 Fin8 refa5_inst.
Proof. unfold Equation4155. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa5_inst, refa5_op in H. discriminate H. Qed.

Lemma refa5_not4157 : ~ @Equation4157 Fin8 refa5_inst.
Proof. unfold Equation4157. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa5_inst, refa5_op in H. discriminate H. Qed.

Lemma refa5_not4158 : ~ @Equation4158 Fin8 refa5_inst.
Proof. unfold Equation4158. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa5_inst, refa5_op in H. discriminate H. Qed.

Lemma refa5_not4164 : ~ @Equation4164 Fin8 refa5_inst.
Proof. unfold Equation4164. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa5_inst, refa5_op in H. discriminate H. Qed.

Lemma refa5_not4165 : ~ @Equation4165 Fin8 refa5_inst.
Proof. unfold Equation4165. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa5_inst, refa5_op in H. discriminate H. Qed.

Lemma refa5_not4167 : ~ @Equation4167 Fin8 refa5_inst.
Proof. unfold Equation4167. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa5_inst, refa5_op in H. discriminate H. Qed.

Lemma refa5_not4268 : ~ @Equation4268 Fin8 refa5_inst.
Proof. unfold Equation4268. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa5_inst, refa5_op in H. discriminate H. Qed.

Lemma refa5_not4269 : ~ @Equation4269 Fin8 refa5_inst.
Proof. unfold Equation4269. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa5_inst, refa5_op in H. discriminate H. Qed.

Lemma refa5_not4270 : ~ @Equation4270 Fin8 refa5_inst.
Proof. unfold Equation4270. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa5_inst, refa5_op in H. discriminate H. Qed.

Lemma refa5_not4272 : ~ @Equation4272 Fin8 refa5_inst.
Proof. unfold Equation4272. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa5_inst, refa5_op in H. discriminate H. Qed.

Lemma refa5_not4273 : ~ @Equation4273 Fin8 refa5_inst.
Proof. unfold Equation4273. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa5_inst, refa5_op in H. discriminate H. Qed.

Lemma refa5_not4275 : ~ @Equation4275 Fin8 refa5_inst.
Proof. unfold Equation4275. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa5_inst, refa5_op in H. discriminate H. Qed.

Lemma refa5_not4276 : ~ @Equation4276 Fin8 refa5_inst.
Proof. unfold Equation4276. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa5_inst, refa5_op in H. discriminate H. Qed.

Lemma refa5_not4283 : ~ @Equation4283 Fin8 refa5_inst.
Proof. unfold Equation4283. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa5_inst, refa5_op in H. discriminate H. Qed.

Lemma refa5_not4284 : ~ @Equation4284 Fin8 refa5_inst.
Proof. unfold Equation4284. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa5_inst, refa5_op in H. discriminate H. Qed.

Lemma refa5_not4290 : ~ @Equation4290 Fin8 refa5_inst.
Proof. unfold Equation4290. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa5_inst, refa5_op in H. discriminate H. Qed.

Lemma refa5_not4291 : ~ @Equation4291 Fin8 refa5_inst.
Proof. unfold Equation4291. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa5_inst, refa5_op in H. discriminate H. Qed.

Lemma refa5_not4293 : ~ @Equation4293 Fin8 refa5_inst.
Proof. unfold Equation4293. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa5_inst, refa5_op in H. discriminate H. Qed.

Lemma refa5_not4314 : ~ @Equation4314 Fin8 refa5_inst.
Proof. unfold Equation4314. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa5_inst, refa5_op in H. discriminate H. Qed.

Lemma refa5_not4320 : ~ @Equation4320 Fin8 refa5_inst.
Proof. unfold Equation4320. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa5_inst, refa5_op in H. discriminate H. Qed.

Lemma refa5_not4321 : ~ @Equation4321 Fin8 refa5_inst.
Proof. unfold Equation4321. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa5_inst, refa5_op in H. discriminate H. Qed.

Lemma refa5_not4343 : ~ @Equation4343 Fin8 refa5_inst.
Proof. unfold Equation4343. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa5_inst, refa5_op in H. discriminate H. Qed.

Lemma refa5_not4396 : ~ @Equation4396 Fin8 refa5_inst.
Proof. unfold Equation4396. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa5_inst, refa5_op in H. discriminate H. Qed.

Lemma refa5_not4398 : ~ @Equation4398 Fin8 refa5_inst.
Proof. unfold Equation4398. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa5_inst, refa5_op in H. discriminate H. Qed.

Lemma refa5_not4405 : ~ @Equation4405 Fin8 refa5_inst.
Proof. unfold Equation4405. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa5_inst, refa5_op in H. discriminate H. Qed.

Lemma refa5_not4406 : ~ @Equation4406 Fin8 refa5_inst.
Proof. unfold Equation4406. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa5_inst, refa5_op in H. discriminate H. Qed.

Lemma refa5_not4408 : ~ @Equation4408 Fin8 refa5_inst.
Proof. unfold Equation4408. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa5_inst, refa5_op in H. discriminate H. Qed.

Lemma refa5_not4433 : ~ @Equation4433 Fin8 refa5_inst.
Proof. unfold Equation4433. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa5_inst, refa5_op in H. discriminate H. Qed.

Lemma refa5_not4436 : ~ @Equation4436 Fin8 refa5_inst.
Proof. unfold Equation4436. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa5_inst, refa5_op in H. discriminate H. Qed.

Lemma refa5_not4442 : ~ @Equation4442 Fin8 refa5_inst.
Proof. unfold Equation4442. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa5_inst, refa5_op in H. discriminate H. Qed.

Lemma refa5_not4443 : ~ @Equation4443 Fin8 refa5_inst.
Proof. unfold Equation4443. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa5_inst, refa5_op in H. discriminate H. Qed.

Lemma refa5_not4445 : ~ @Equation4445 Fin8 refa5_inst.
Proof. unfold Equation4445. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa5_inst, refa5_op in H. discriminate H. Qed.

Lemma refa5_not4472 : ~ @Equation4472 Fin8 refa5_inst.
Proof. unfold Equation4472. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa5_inst, refa5_op in H. discriminate H. Qed.

Lemma refa5_not4473 : ~ @Equation4473 Fin8 refa5_inst.
Proof. unfold Equation4473. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa5_inst, refa5_op in H. discriminate H. Qed.

Lemma refa5_not4479 : ~ @Equation4479 Fin8 refa5_inst.
Proof. unfold Equation4479. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa5_inst, refa5_op in H. discriminate H. Qed.

Lemma refa5_not4480 : ~ @Equation4480 Fin8 refa5_inst.
Proof. unfold Equation4480. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa5_inst, refa5_op in H. discriminate H. Qed.

Lemma refa5_not4482 : ~ @Equation4482 Fin8 refa5_inst.
Proof. unfold Equation4482. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa5_inst, refa5_op in H. discriminate H. Qed.

Lemma refa5_not4583 : ~ @Equation4583 Fin8 refa5_inst.
Proof. unfold Equation4583. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa5_inst, refa5_op in H. discriminate H. Qed.

Lemma refa5_not4584 : ~ @Equation4584 Fin8 refa5_inst.
Proof. unfold Equation4584. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa5_inst, refa5_op in H. discriminate H. Qed.

Lemma refa5_not4585 : ~ @Equation4585 Fin8 refa5_inst.
Proof. unfold Equation4585. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa5_inst, refa5_op in H. discriminate H. Qed.

Lemma refa5_not4587 : ~ @Equation4587 Fin8 refa5_inst.
Proof. unfold Equation4587. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa5_inst, refa5_op in H. discriminate H. Qed.

Lemma refa5_not4588 : ~ @Equation4588 Fin8 refa5_inst.
Proof. unfold Equation4588. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa5_inst, refa5_op in H. discriminate H. Qed.

Lemma refa5_not4590 : ~ @Equation4590 Fin8 refa5_inst.
Proof. unfold Equation4590. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa5_inst, refa5_op in H. discriminate H. Qed.

Lemma refa5_not4591 : ~ @Equation4591 Fin8 refa5_inst.
Proof. unfold Equation4591. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa5_inst, refa5_op in H. discriminate H. Qed.

Lemma refa5_not4598 : ~ @Equation4598 Fin8 refa5_inst.
Proof. unfold Equation4598. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa5_inst, refa5_op in H. discriminate H. Qed.

Lemma refa5_not4599 : ~ @Equation4599 Fin8 refa5_inst.
Proof. unfold Equation4599. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa5_inst, refa5_op in H. discriminate H. Qed.

Lemma refa5_not4605 : ~ @Equation4605 Fin8 refa5_inst.
Proof. unfold Equation4605. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa5_inst, refa5_op in H. discriminate H. Qed.

Lemma refa5_not4606 : ~ @Equation4606 Fin8 refa5_inst.
Proof. unfold Equation4606. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa5_inst, refa5_op in H. discriminate H. Qed.

Lemma refa5_not4608 : ~ @Equation4608 Fin8 refa5_inst.
Proof. unfold Equation4608. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa5_inst, refa5_op in H. discriminate H. Qed.

Lemma refa5_not4629 : ~ @Equation4629 Fin8 refa5_inst.
Proof. unfold Equation4629. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa5_inst, refa5_op in H. discriminate H. Qed.

Lemma refa5_not4635 : ~ @Equation4635 Fin8 refa5_inst.
Proof. unfold Equation4635. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa5_inst, refa5_op in H. discriminate H. Qed.

Lemma refa5_not4636 : ~ @Equation4636 Fin8 refa5_inst.
Proof. unfold Equation4636. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa5_inst, refa5_op in H. discriminate H. Qed.

Lemma refa5_not4658 : ~ @Equation4658 Fin8 refa5_inst.
Proof. unfold Equation4658. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa5_inst, refa5_op in H. discriminate H. Qed.

(** ---- refa50 (Fin2) ---- *)

Definition refa50_op (x y : Fin2) : Fin2 :=
  match x, y with
  | F2_0, F2_0 => F2_0 | F2_0, F2_1 => F2_0
  | F2_1, F2_0 => F2_0 | F2_1, F2_1 => F2_0
  end.

#[local] Instance refa50_inst : Magma Fin2 := {| magma_op := refa50_op |}.

Lemma refa50_sat41 : @Equation41 Fin2 refa50_inst.
Proof. unfold Equation41, magma_op, refa50_inst, refa50_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa50_not47 : ~ @Equation47 Fin2 refa50_inst.
Proof. unfold Equation47. intro H. specialize (H F2_1). unfold magma_op, refa50_inst, refa50_op in H. discriminate H. Qed.

Lemma refa50_not99 : ~ @Equation99 Fin2 refa50_inst.
Proof. unfold Equation99. intro H. specialize (H F2_1). unfold magma_op, refa50_inst, refa50_op in H. discriminate H. Qed.

Lemma refa50_not151 : ~ @Equation151 Fin2 refa50_inst.
Proof. unfold Equation151. intro H. specialize (H F2_1). unfold magma_op, refa50_inst, refa50_op in H. discriminate H. Qed.

Lemma refa50_not203 : ~ @Equation203 Fin2 refa50_inst.
Proof. unfold Equation203. intro H. specialize (H F2_1). unfold magma_op, refa50_inst, refa50_op in H. discriminate H. Qed.

Lemma refa50_not255 : ~ @Equation255 Fin2 refa50_inst.
Proof. unfold Equation255. intro H. specialize (H F2_1). unfold magma_op, refa50_inst, refa50_op in H. discriminate H. Qed.

Lemma refa50_not411 : ~ @Equation411 Fin2 refa50_inst.
Proof. unfold Equation411. intro H. specialize (H F2_1). unfold magma_op, refa50_inst, refa50_op in H. discriminate H. Qed.

Lemma refa50_not614 : ~ @Equation614 Fin2 refa50_inst.
Proof. unfold Equation614. intro H. specialize (H F2_1). unfold magma_op, refa50_inst, refa50_op in H. discriminate H. Qed.

Lemma refa50_not817 : ~ @Equation817 Fin2 refa50_inst.
Proof. unfold Equation817. intro H. specialize (H F2_1). unfold magma_op, refa50_inst, refa50_op in H. discriminate H. Qed.

Lemma refa50_not1020 : ~ @Equation1020 Fin2 refa50_inst.
Proof. unfold Equation1020. intro H. specialize (H F2_1). unfold magma_op, refa50_inst, refa50_op in H. discriminate H. Qed.

Lemma refa50_not1223 : ~ @Equation1223 Fin2 refa50_inst.
Proof. unfold Equation1223. intro H. specialize (H F2_1). unfold magma_op, refa50_inst, refa50_op in H. discriminate H. Qed.

Lemma refa50_not1426 : ~ @Equation1426 Fin2 refa50_inst.
Proof. unfold Equation1426. intro H. specialize (H F2_1). unfold magma_op, refa50_inst, refa50_op in H. discriminate H. Qed.

Lemma refa50_not1629 : ~ @Equation1629 Fin2 refa50_inst.
Proof. unfold Equation1629. intro H. specialize (H F2_1). unfold magma_op, refa50_inst, refa50_op in H. discriminate H. Qed.

Lemma refa50_not1832 : ~ @Equation1832 Fin2 refa50_inst.
Proof. unfold Equation1832. intro H. specialize (H F2_1). unfold magma_op, refa50_inst, refa50_op in H. discriminate H. Qed.

Lemma refa50_not2035 : ~ @Equation2035 Fin2 refa50_inst.
Proof. unfold Equation2035. intro H. specialize (H F2_1). unfold magma_op, refa50_inst, refa50_op in H. discriminate H. Qed.

Lemma refa50_not2238 : ~ @Equation2238 Fin2 refa50_inst.
Proof. unfold Equation2238. intro H. specialize (H F2_1). unfold magma_op, refa50_inst, refa50_op in H. discriminate H. Qed.

Lemma refa50_not2441 : ~ @Equation2441 Fin2 refa50_inst.
Proof. unfold Equation2441. intro H. specialize (H F2_1). unfold magma_op, refa50_inst, refa50_op in H. discriminate H. Qed.

Lemma refa50_not2644 : ~ @Equation2644 Fin2 refa50_inst.
Proof. unfold Equation2644. intro H. specialize (H F2_1). unfold magma_op, refa50_inst, refa50_op in H. discriminate H. Qed.

Lemma refa50_not2847 : ~ @Equation2847 Fin2 refa50_inst.
Proof. unfold Equation2847. intro H. specialize (H F2_1). unfold magma_op, refa50_inst, refa50_op in H. discriminate H. Qed.

Lemma refa50_not3050 : ~ @Equation3050 Fin2 refa50_inst.
Proof. unfold Equation3050. intro H. specialize (H F2_1). unfold magma_op, refa50_inst, refa50_op in H. discriminate H. Qed.

(** ---- refa500 (Fin4) ---- *)

Definition refa500_op (x y : Fin4) : Fin4 :=
  match x, y with
  | F4_0, F4_0 => F4_0 | F4_0, F4_1 => F4_1 | F4_0, F4_2 => F4_3 | F4_0, F4_3 => F4_3
  | F4_1, F4_0 => F4_3 | F4_1, F4_1 => F4_1 | F4_1, F4_2 => F4_3 | F4_1, F4_3 => F4_2
  | F4_2, F4_0 => F4_1 | F4_2, F4_1 => F4_3 | F4_2, F4_2 => F4_2 | F4_2, F4_3 => F4_3
  | F4_3, F4_0 => F4_0 | F4_3, F4_1 => F4_1 | F4_3, F4_2 => F4_2 | F4_3, F4_3 => F4_3
  end.

#[local] Instance refa500_inst : Magma Fin4 := {| magma_op := refa500_op |}.

Lemma refa500_sat3176 : @Equation3176 Fin4 refa500_inst.
Proof. unfold Equation3176, magma_op, refa500_inst, refa500_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa500_not2936 : ~ @Equation2936 Fin4 refa500_inst.
Proof. unfold Equation2936. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa500_inst, refa500_op in H. discriminate H. Qed.

(** ---- refa501 (Fin4) ---- *)

Definition refa501_op (x y : Fin4) : Fin4 :=
  match x, y with
  | F4_0, F4_0 => F4_2 | F4_0, F4_1 => F4_1 | F4_0, F4_2 => F4_3 | F4_0, F4_3 => F4_1
  | F4_1, F4_0 => F4_2 | F4_1, F4_1 => F4_2 | F4_1, F4_2 => F4_3 | F4_1, F4_3 => F4_3
  | F4_2, F4_0 => F4_2 | F4_2, F4_1 => F4_2 | F4_2, F4_2 => F4_3 | F4_2, F4_3 => F4_3
  | F4_3, F4_0 => F4_0 | F4_3, F4_1 => F4_1 | F4_3, F4_2 => F4_2 | F4_3, F4_3 => F4_3
  end.

#[local] Instance refa501_inst : Magma Fin4 := {| magma_op := refa501_op |}.

Lemma refa501_sat2588 : @Equation2588 Fin4 refa501_inst.
Proof. unfold Equation2588, magma_op, refa501_inst, refa501_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa501_not2662 : ~ @Equation2662 Fin4 refa501_inst.
Proof. unfold Equation2662. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa501_inst, refa501_op in H. discriminate H. Qed.

(** ---- refa502 (Fin4) ---- *)

Definition refa502_op (x y : Fin4) : Fin4 :=
  match x, y with
  | F4_0, F4_0 => F4_2 | F4_0, F4_1 => F4_2 | F4_0, F4_2 => F4_0 | F4_0, F4_3 => F4_1
  | F4_1, F4_0 => F4_3 | F4_1, F4_1 => F4_3 | F4_1, F4_2 => F4_0 | F4_1, F4_3 => F4_0
  | F4_2, F4_0 => F4_0 | F4_2, F4_1 => F4_0 | F4_2, F4_2 => F4_0 | F4_2, F4_3 => F4_0
  | F4_3, F4_0 => F4_1 | F4_3, F4_1 => F4_1 | F4_3, F4_2 => F4_1 | F4_3, F4_3 => F4_1
  end.

#[local] Instance refa502_inst : Magma Fin4 := {| magma_op := refa502_op |}.

Lemma refa502_sat1448 : @Equation1448 Fin4 refa502_inst.
Proof. unfold Equation1448, magma_op, refa502_inst, refa502_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa502_not1654 : ~ @Equation1654 Fin4 refa502_inst.
Proof. unfold Equation1654. intro H. specialize (H F4_1 F4_2). unfold magma_op, refa502_inst, refa502_op in H. discriminate H. Qed.

Lemma refa502_not1657 : ~ @Equation1657 Fin4 refa502_inst.
Proof. unfold Equation1657. intro H. specialize (H F4_1 F4_2). unfold magma_op, refa502_inst, refa502_op in H. discriminate H. Qed.

Lemma refa502_not1840 : ~ @Equation1840 Fin4 refa502_inst.
Proof. unfold Equation1840. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa502_inst, refa502_op in H. discriminate H. Qed.

Lemma refa502_not1860 : ~ @Equation1860 Fin4 refa502_inst.
Proof. unfold Equation1860. intro H. specialize (H F4_1 F4_0). unfold magma_op, refa502_inst, refa502_op in H. discriminate H. Qed.

Lemma refa502_not2035 : ~ @Equation2035 Fin4 refa502_inst.
Proof. unfold Equation2035. intro H. specialize (H F4_1). unfold magma_op, refa502_inst, refa502_op in H. discriminate H. Qed.

Lemma refa502_not3306 : ~ @Equation3306 Fin4 refa502_inst.
Proof. unfold Equation3306. intro H. specialize (H F4_0 F4_3). unfold magma_op, refa502_inst, refa502_op in H. discriminate H. Qed.

Lemma refa502_not3308 : ~ @Equation3308 Fin4 refa502_inst.
Proof. unfold Equation3308. intro H. specialize (H F4_0 F4_3). unfold magma_op, refa502_inst, refa502_op in H. discriminate H. Qed.

Lemma refa502_not3309 : ~ @Equation3309 Fin4 refa502_inst.
Proof. unfold Equation3309. intro H. specialize (H F4_0 F4_3). unfold magma_op, refa502_inst, refa502_op in H. discriminate H. Qed.

Lemma refa502_not3862 : ~ @Equation3862 Fin4 refa502_inst.
Proof. unfold Equation3862. intro H. specialize (H F4_1). unfold magma_op, refa502_inst, refa502_op in H. discriminate H. Qed.

Lemma refa502_not4073 : ~ @Equation4073 Fin4 refa502_inst.
Proof. unfold Equation4073. intro H. specialize (H F4_1 F4_2). unfold magma_op, refa502_inst, refa502_op in H. discriminate H. Qed.

Lemma refa502_not4121 : ~ @Equation4121 Fin4 refa502_inst.
Proof. unfold Equation4121. intro H. specialize (H F4_3 F4_2). unfold magma_op, refa502_inst, refa502_op in H. discriminate H. Qed.

Lemma refa502_not4131 : ~ @Equation4131 Fin4 refa502_inst.
Proof. unfold Equation4131. intro H. specialize (H F4_3 F4_2). unfold magma_op, refa502_inst, refa502_op in H. discriminate H. Qed.

Lemma refa502_not4283 : ~ @Equation4283 Fin4 refa502_inst.
Proof. unfold Equation4283. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa502_inst, refa502_op in H. discriminate H. Qed.

Lemma refa502_not4284 : ~ @Equation4284 Fin4 refa502_inst.
Proof. unfold Equation4284. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa502_inst, refa502_op in H. discriminate H. Qed.

Lemma refa502_not4380 : ~ @Equation4380 Fin4 refa502_inst.
Proof. unfold Equation4380. intro H. specialize (H F4_1). unfold magma_op, refa502_inst, refa502_op in H. discriminate H. Qed.

Lemma refa502_not4599 : ~ @Equation4599 Fin4 refa502_inst.
Proof. unfold Equation4599. intro H. specialize (H F4_1 F4_2). unfold magma_op, refa502_inst, refa502_op in H. discriminate H. Qed.

(** ---- refa503 (Fin4) ---- *)

Definition refa503_op (x y : Fin4) : Fin4 :=
  match x, y with
  | F4_0, F4_0 => F4_0 | F4_0, F4_1 => F4_3 | F4_0, F4_2 => F4_0 | F4_0, F4_3 => F4_3
  | F4_1, F4_0 => F4_2 | F4_1, F4_1 => F4_2 | F4_1, F4_2 => F4_2 | F4_1, F4_3 => F4_2
  | F4_2, F4_0 => F4_1 | F4_2, F4_1 => F4_1 | F4_2, F4_2 => F4_1 | F4_2, F4_3 => F4_1
  | F4_3, F4_0 => F4_3 | F4_3, F4_1 => F4_0 | F4_3, F4_2 => F4_3 | F4_3, F4_3 => F4_0
  end.

#[local] Instance refa503_inst : Magma Fin4 := {| magma_op := refa503_op |}.

Lemma refa503_sat2241 : @Equation2241 Fin4 refa503_inst.
Proof. unfold Equation2241, magma_op, refa503_inst, refa503_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa503_not3319 : ~ @Equation3319 Fin4 refa503_inst.
Proof. unfold Equation3319. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa503_inst, refa503_op in H. discriminate H. Qed.
