(** * All4x4 counterexamples — batch 8
    Auto-generated from Lean4 All4x4 files. *)

From Stdlib Require Import Utf8.

From ETP Require Import Magma.
From ETP Require Import FinMagma.
From ETP.Equations Require Import All.

Open Scope magma_scope.

(** ---- refa414 (Fin4) ---- *)

Definition refa414_op (x y : Fin4) : Fin4 :=
  match x, y with
  | F4_0, F4_0 => F4_1 | F4_0, F4_1 => F4_0 | F4_0, F4_2 => F4_0 | F4_0, F4_3 => F4_1
  | F4_1, F4_0 => F4_3 | F4_1, F4_1 => F4_1 | F4_1, F4_2 => F4_1 | F4_1, F4_3 => F4_3
  | F4_2, F4_0 => F4_3 | F4_2, F4_1 => F4_2 | F4_2, F4_2 => F4_2 | F4_2, F4_3 => F4_0
  | F4_3, F4_0 => F4_1 | F4_3, F4_1 => F4_3 | F4_3, F4_2 => F4_3 | F4_3, F4_3 => F4_2
  end.

#[local] Instance refa414_inst : Magma Fin4 := {| magma_op := refa414_op |}.

Lemma refa414_sat655 : @Equation655 Fin4 refa414_inst.
Proof. unfold Equation655, magma_op, refa414_inst, refa414_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa414_sat861 : @Equation861 Fin4 refa414_inst.
Proof. unfold Equation861, magma_op, refa414_inst, refa414_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa414_not3456 : ~ @Equation3456 Fin4 refa414_inst.
Proof. unfold Equation3456. intro H. specialize (H F4_3). unfold magma_op, refa414_inst, refa414_op in H. discriminate H. Qed.

Lemma refa414_not3665 : ~ @Equation3665 Fin4 refa414_inst.
Proof. unfold Equation3665. intro H. specialize (H F4_1 F4_0). unfold magma_op, refa414_inst, refa414_op in H. discriminate H. Qed.

Lemma refa414_not3667 : ~ @Equation3667 Fin4 refa414_inst.
Proof. unfold Equation3667. intro H. specialize (H F4_1 F4_3). unfold magma_op, refa414_inst, refa414_op in H. discriminate H. Qed.

Lemma refa414_not3865 : ~ @Equation3865 Fin4 refa414_inst.
Proof. unfold Equation3865. intro H. specialize (H F4_1 F4_3). unfold magma_op, refa414_inst, refa414_op in H. discriminate H. Qed.

Lemma refa414_not3868 : ~ @Equation3868 Fin4 refa414_inst.
Proof. unfold Equation3868. intro H. specialize (H F4_1 F4_3). unfold magma_op, refa414_inst, refa414_op in H. discriminate H. Qed.

Lemma refa414_not4065 : ~ @Equation4065 Fin4 refa414_inst.
Proof. unfold Equation4065. intro H. specialize (H F4_3). unfold magma_op, refa414_inst, refa414_op in H. discriminate H. Qed.

Lemma refa414_not4283 : ~ @Equation4283 Fin4 refa414_inst.
Proof. unfold Equation4283. intro H. specialize (H F4_2 F4_0). unfold magma_op, refa414_inst, refa414_op in H. discriminate H. Qed.

Lemma refa414_not4673 : ~ @Equation4673 Fin4 refa414_inst.
Proof. unfold Equation4673. intro H. specialize (H F4_1 F4_0 F4_3). unfold magma_op, refa414_inst, refa414_op in H. discriminate H. Qed.

(** ---- refa415 (Fin4) ---- *)

Definition refa415_op (x y : Fin4) : Fin4 :=
  match x, y with
  | F4_0, F4_0 => F4_0 | F4_0, F4_1 => F4_2 | F4_0, F4_2 => F4_3 | F4_0, F4_3 => F4_3
  | F4_1, F4_0 => F4_2 | F4_1, F4_1 => F4_1 | F4_1, F4_2 => F4_2 | F4_1, F4_3 => F4_3
  | F4_2, F4_0 => F4_0 | F4_2, F4_1 => F4_3 | F4_2, F4_2 => F4_2 | F4_2, F4_3 => F4_3
  | F4_3, F4_0 => F4_0 | F4_3, F4_1 => F4_1 | F4_3, F4_2 => F4_2 | F4_3, F4_3 => F4_3
  end.

#[local] Instance refa415_inst : Magma Fin4 := {| magma_op := refa415_op |}.

Lemma refa415_sat2584 : @Equation2584 Fin4 refa415_inst.
Proof. unfold Equation2584, magma_op, refa415_inst, refa415_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa415_sat2973 : @Equation2973 Fin4 refa415_inst.
Proof. unfold Equation2973, magma_op, refa415_inst, refa415_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa415_not1691 : ~ @Equation1691 Fin4 refa415_inst.
Proof. unfold Equation1691. intro H. specialize (H F4_1 F4_0). unfold magma_op, refa415_inst, refa415_op in H. discriminate H. Qed.

Lemma refa415_not2669 : ~ @Equation2669 Fin4 refa415_inst.
Proof. unfold Equation2669. intro H. specialize (H F4_1 F4_0). unfold magma_op, refa415_inst, refa415_op in H. discriminate H. Qed.

Lemma refa415_not3306 : ~ @Equation3306 Fin4 refa415_inst.
Proof. unfold Equation3306. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa415_inst, refa415_op in H. discriminate H. Qed.

Lemma refa415_not3512 : ~ @Equation3512 Fin4 refa415_inst.
Proof. unfold Equation3512. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa415_inst, refa415_op in H. discriminate H. Qed.

Lemma refa415_not3925 : ~ @Equation3925 Fin4 refa415_inst.
Proof. unfold Equation3925. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa415_inst, refa415_op in H. discriminate H. Qed.

Lemma refa415_not4155 : ~ @Equation4155 Fin4 refa415_inst.
Proof. unfold Equation4155. intro H. specialize (H F4_1 F4_0). unfold magma_op, refa415_inst, refa415_op in H. discriminate H. Qed.

(** ---- refa416 (Fin4) ---- *)

Definition refa416_op (x y : Fin4) : Fin4 :=
  match x, y with
  | F4_0, F4_0 => F4_0 | F4_0, F4_1 => F4_3 | F4_0, F4_2 => F4_1 | F4_0, F4_3 => F4_0
  | F4_1, F4_0 => F4_3 | F4_1, F4_1 => F4_1 | F4_1, F4_2 => F4_1 | F4_1, F4_3 => F4_1
  | F4_2, F4_0 => F4_3 | F4_2, F4_1 => F4_2 | F4_2, F4_2 => F4_2 | F4_2, F4_3 => F4_2
  | F4_3, F4_0 => F4_3 | F4_3, F4_1 => F4_3 | F4_3, F4_2 => F4_3 | F4_3, F4_3 => F4_3
  end.

#[local] Instance refa416_inst : Magma Fin4 := {| magma_op := refa416_op |}.

Lemma refa416_sat618 : @Equation618 Fin4 refa416_inst.
Proof. unfold Equation618, magma_op, refa416_inst, refa416_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa416_not3318 : ~ @Equation3318 Fin4 refa416_inst.
Proof. unfold Equation3318. intro H. specialize (H F4_2 F4_0). unfold magma_op, refa416_inst, refa416_op in H. discriminate H. Qed.

Lemma refa416_not3918 : ~ @Equation3918 Fin4 refa416_inst.
Proof. unfold Equation3918. intro H. specialize (H F4_0 F4_2). unfold magma_op, refa416_inst, refa416_op in H. discriminate H. Qed.

(** ---- refa417 (Fin4) ---- *)

Definition refa417_op (x y : Fin4) : Fin4 :=
  match x, y with
  | F4_0, F4_0 => F4_0 | F4_0, F4_1 => F4_0 | F4_0, F4_2 => F4_0 | F4_0, F4_3 => F4_1
  | F4_1, F4_0 => F4_1 | F4_1, F4_1 => F4_1 | F4_1, F4_2 => F4_0 | F4_1, F4_3 => F4_1
  | F4_2, F4_0 => F4_2 | F4_2, F4_1 => F4_0 | F4_2, F4_2 => F4_2 | F4_2, F4_3 => F4_0
  | F4_3, F4_0 => F4_3 | F4_3, F4_1 => F4_3 | F4_3, F4_2 => F4_0 | F4_3, F4_3 => F4_3
  end.

#[local] Instance refa417_inst : Magma Fin4 := {| magma_op := refa417_op |}.

Lemma refa417_sat1027 : @Equation1027 Fin4 refa417_inst.
Proof. unfold Equation1027, magma_op, refa417_inst, refa417_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa417_not826 : ~ @Equation826 Fin4 refa417_inst.
Proof. unfold Equation826. intro H. specialize (H F4_2 F4_3). unfold magma_op, refa417_inst, refa417_op in H. discriminate H. Qed.

Lemma refa417_not1029 : ~ @Equation1029 Fin4 refa417_inst.
Proof. unfold Equation1029. intro H. specialize (H F4_2 F4_3). unfold magma_op, refa417_inst, refa417_op in H. discriminate H. Qed.

Lemma refa417_not1226 : ~ @Equation1226 Fin4 refa417_inst.
Proof. unfold Equation1226. intro H. specialize (H F4_2 F4_3). unfold magma_op, refa417_inst, refa417_op in H. discriminate H. Qed.

Lemma refa417_not1229 : ~ @Equation1229 Fin4 refa417_inst.
Proof. unfold Equation1229. intro H. specialize (H F4_2 F4_3). unfold magma_op, refa417_inst, refa417_op in H. discriminate H. Qed.

Lemma refa417_not1232 : ~ @Equation1232 Fin4 refa417_inst.
Proof. unfold Equation1232. intro H. specialize (H F4_2 F4_3). unfold magma_op, refa417_inst, refa417_op in H. discriminate H. Qed.

Lemma refa417_not1632 : ~ @Equation1632 Fin4 refa417_inst.
Proof. unfold Equation1632. intro H. specialize (H F4_2 F4_3). unfold magma_op, refa417_inst, refa417_op in H. discriminate H. Qed.

Lemma refa417_not2449 : ~ @Equation2449 Fin4 refa417_inst.
Proof. unfold Equation2449. intro H. specialize (H F4_2 F4_3). unfold magma_op, refa417_inst, refa417_op in H. discriminate H. Qed.

Lemma refa417_not3315 : ~ @Equation3315 Fin4 refa417_inst.
Proof. unfold Equation3315. intro H. specialize (H F4_1 F4_2). unfold magma_op, refa417_inst, refa417_op in H. discriminate H. Qed.

Lemma refa417_not3322 : ~ @Equation3322 Fin4 refa417_inst.
Proof. unfold Equation3322. intro H. specialize (H F4_2 F4_0 F4_3). unfold magma_op, refa417_inst, refa417_op in H. discriminate H. Qed.

Lemma refa417_not3459 : ~ @Equation3459 Fin4 refa417_inst.
Proof. unfold Equation3459. intro H. specialize (H F4_2 F4_3). unfold magma_op, refa417_inst, refa417_op in H. discriminate H. Qed.

Lemma refa417_not3518 : ~ @Equation3518 Fin4 refa417_inst.
Proof. unfold Equation3518. intro H. specialize (H F4_1 F4_2). unfold magma_op, refa417_inst, refa417_op in H. discriminate H. Qed.

Lemma refa417_not3519 : ~ @Equation3519 Fin4 refa417_inst.
Proof. unfold Equation3519. intro H. specialize (H F4_1 F4_2). unfold magma_op, refa417_inst, refa417_op in H. discriminate H. Qed.

Lemma refa417_not3521 : ~ @Equation3521 Fin4 refa417_inst.
Proof. unfold Equation3521. intro H. specialize (H F4_1 F4_2). unfold magma_op, refa417_inst, refa417_op in H. discriminate H. Qed.

Lemma refa417_not3714 : ~ @Equation3714 Fin4 refa417_inst.
Proof. unfold Equation3714. intro H. specialize (H F4_1 F4_2). unfold magma_op, refa417_inst, refa417_op in H. discriminate H. Qed.

Lemma refa417_not3721 : ~ @Equation3721 Fin4 refa417_inst.
Proof. unfold Equation3721. intro H. specialize (H F4_3 F4_2). unfold magma_op, refa417_inst, refa417_op in H. discriminate H. Qed.

Lemma refa417_not3725 : ~ @Equation3725 Fin4 refa417_inst.
Proof. unfold Equation3725. intro H. specialize (H F4_2 F4_3). unfold magma_op, refa417_inst, refa417_op in H. discriminate H. Qed.

Lemma refa417_not3924 : ~ @Equation3924 Fin4 refa417_inst.
Proof. unfold Equation3924. intro H. specialize (H F4_1 F4_2). unfold magma_op, refa417_inst, refa417_op in H. discriminate H. Qed.

Lemma refa417_not3927 : ~ @Equation3927 Fin4 refa417_inst.
Proof. unfold Equation3927. intro H. specialize (H F4_3 F4_2). unfold magma_op, refa417_inst, refa417_op in H. discriminate H. Qed.

Lemma refa417_not3928 : ~ @Equation3928 Fin4 refa417_inst.
Proof. unfold Equation3928. intro H. specialize (H F4_2 F4_3). unfold magma_op, refa417_inst, refa417_op in H. discriminate H. Qed.

Lemma refa417_not4120 : ~ @Equation4120 Fin4 refa417_inst.
Proof. unfold Equation4120. intro H. specialize (H F4_3 F4_2). unfold magma_op, refa417_inst, refa417_op in H. discriminate H. Qed.

Lemma refa417_not4121 : ~ @Equation4121 Fin4 refa417_inst.
Proof. unfold Equation4121. intro H. specialize (H F4_2 F4_3). unfold magma_op, refa417_inst, refa417_op in H. discriminate H. Qed.

Lemma refa417_not4127 : ~ @Equation4127 Fin4 refa417_inst.
Proof. unfold Equation4127. intro H. specialize (H F4_3 F4_2). unfold magma_op, refa417_inst, refa417_op in H. discriminate H. Qed.

Lemma refa417_not4128 : ~ @Equation4128 Fin4 refa417_inst.
Proof. unfold Equation4128. intro H. specialize (H F4_2 F4_3). unfold magma_op, refa417_inst, refa417_op in H. discriminate H. Qed.

Lemma refa417_not4130 : ~ @Equation4130 Fin4 refa417_inst.
Proof. unfold Equation4130. intro H. specialize (H F4_3 F4_2). unfold magma_op, refa417_inst, refa417_op in H. discriminate H. Qed.

Lemma refa417_not4131 : ~ @Equation4131 Fin4 refa417_inst.
Proof. unfold Equation4131. intro H. specialize (H F4_2 F4_3). unfold magma_op, refa417_inst, refa417_op in H. discriminate H. Qed.

Lemma refa417_not4314 : ~ @Equation4314 Fin4 refa417_inst.
Proof. unfold Equation4314. intro H. specialize (H F4_1 F4_2). unfold magma_op, refa417_inst, refa417_op in H. discriminate H. Qed.

Lemma refa417_not4433 : ~ @Equation4433 Fin4 refa417_inst.
Proof. unfold Equation4433. intro H. specialize (H F4_1 F4_2). unfold magma_op, refa417_inst, refa417_op in H. discriminate H. Qed.

Lemma refa417_not4435 : ~ @Equation4435 Fin4 refa417_inst.
Proof. unfold Equation4435. intro H. specialize (H F4_1 F4_2). unfold magma_op, refa417_inst, refa417_op in H. discriminate H. Qed.

Lemma refa417_not4436 : ~ @Equation4436 Fin4 refa417_inst.
Proof. unfold Equation4436. intro H. specialize (H F4_1 F4_2). unfold magma_op, refa417_inst, refa417_op in H. discriminate H. Qed.

Lemma refa417_not4472 : ~ @Equation4472 Fin4 refa417_inst.
Proof. unfold Equation4472. intro H. specialize (H F4_3 F4_2). unfold magma_op, refa417_inst, refa417_op in H. discriminate H. Qed.

Lemma refa417_not4473 : ~ @Equation4473 Fin4 refa417_inst.
Proof. unfold Equation4473. intro H. specialize (H F4_2 F4_3). unfold magma_op, refa417_inst, refa417_op in H. discriminate H. Qed.

Lemma refa417_not4598 : ~ @Equation4598 Fin4 refa417_inst.
Proof. unfold Equation4598. intro H. specialize (H F4_3 F4_2). unfold magma_op, refa417_inst, refa417_op in H. discriminate H. Qed.

Lemma refa417_not4599 : ~ @Equation4599 Fin4 refa417_inst.
Proof. unfold Equation4599. intro H. specialize (H F4_2 F4_3). unfold magma_op, refa417_inst, refa417_op in H. discriminate H. Qed.

Lemma refa417_not4629 : ~ @Equation4629 Fin4 refa417_inst.
Proof. unfold Equation4629. intro H. specialize (H F4_2 F4_3). unfold magma_op, refa417_inst, refa417_op in H. discriminate H. Qed.

(** ---- refa418 (Fin4) ---- *)

Definition refa418_op (x y : Fin4) : Fin4 :=
  match x, y with
  | F4_0, F4_0 => F4_1 | F4_0, F4_1 => F4_3 | F4_0, F4_2 => F4_1 | F4_0, F4_3 => F4_3
  | F4_1, F4_0 => F4_3 | F4_1, F4_1 => F4_3 | F4_1, F4_2 => F4_1 | F4_1, F4_3 => F4_3
  | F4_2, F4_0 => F4_3 | F4_2, F4_1 => F4_3 | F4_2, F4_2 => F4_3 | F4_2, F4_3 => F4_3
  | F4_3, F4_0 => F4_3 | F4_3, F4_1 => F4_3 | F4_3, F4_2 => F4_3 | F4_3, F4_3 => F4_3
  end.

#[local] Instance refa418_inst : Magma Fin4 := {| magma_op := refa418_op |}.

Lemma refa418_sat4580 : @Equation4580 Fin4 refa418_inst.
Proof. unfold Equation4580, magma_op, refa418_inst, refa418_op. intros x y z w u. destruct x, y, z, w, u; reflexivity. Qed.

Lemma refa418_not4396 : ~ @Equation4396 Fin4 refa418_inst.
Proof. unfold Equation4396. intro H. specialize (H F4_0 F4_2). unfold magma_op, refa418_inst, refa418_op in H. discriminate H. Qed.

Lemma refa418_not4408 : ~ @Equation4408 Fin4 refa418_inst.
Proof. unfold Equation4408. intro H. specialize (H F4_2 F4_0). unfold magma_op, refa418_inst, refa418_op in H. discriminate H. Qed.

Lemma refa418_not4433 : ~ @Equation4433 Fin4 refa418_inst.
Proof. unfold Equation4433. intro H. specialize (H F4_0 F4_2). unfold magma_op, refa418_inst, refa418_op in H. discriminate H. Qed.

Lemma refa418_not4445 : ~ @Equation4445 Fin4 refa418_inst.
Proof. unfold Equation4445. intro H. specialize (H F4_2 F4_0). unfold magma_op, refa418_inst, refa418_op in H. discriminate H. Qed.

Lemma refa418_not4470 : ~ @Equation4470 Fin4 refa418_inst.
Proof. unfold Equation4470. intro H. specialize (H F4_0 F4_2). unfold magma_op, refa418_inst, refa418_op in H. discriminate H. Qed.

Lemma refa418_not4482 : ~ @Equation4482 Fin4 refa418_inst.
Proof. unfold Equation4482. intro H. specialize (H F4_2 F4_0). unfold magma_op, refa418_inst, refa418_op in H. discriminate H. Qed.

Lemma refa418_not4583 : ~ @Equation4583 Fin4 refa418_inst.
Proof. unfold Equation4583. intro H. specialize (H F4_0 F4_2). unfold magma_op, refa418_inst, refa418_op in H. discriminate H. Qed.

Lemma refa418_not4598 : ~ @Equation4598 Fin4 refa418_inst.
Proof. unfold Equation4598. intro H. specialize (H F4_0 F4_2). unfold magma_op, refa418_inst, refa418_op in H. discriminate H. Qed.

Lemma refa418_not4606 : ~ @Equation4606 Fin4 refa418_inst.
Proof. unfold Equation4606. intro H. specialize (H F4_0 F4_2). unfold magma_op, refa418_inst, refa418_op in H. discriminate H. Qed.

Lemma refa418_not4608 : ~ @Equation4608 Fin4 refa418_inst.
Proof. unfold Equation4608. intro H. specialize (H F4_0 F4_2). unfold magma_op, refa418_inst, refa418_op in H. discriminate H. Qed.

Lemma refa418_not4622 : ~ @Equation4622 Fin4 refa418_inst.
Proof. unfold Equation4622. intro H. specialize (H F4_0 F4_2 F4_1). unfold magma_op, refa418_inst, refa418_op in H. discriminate H. Qed.

(** ---- refa419 (Fin4) ---- *)

Definition refa419_op (x y : Fin4) : Fin4 :=
  match x, y with
  | F4_0, F4_0 => F4_3 | F4_0, F4_1 => F4_1 | F4_0, F4_2 => F4_3 | F4_0, F4_3 => F4_3
  | F4_1, F4_0 => F4_3 | F4_1, F4_1 => F4_3 | F4_1, F4_2 => F4_3 | F4_1, F4_3 => F4_3
  | F4_2, F4_0 => F4_1 | F4_2, F4_1 => F4_1 | F4_2, F4_2 => F4_3 | F4_2, F4_3 => F4_3
  | F4_3, F4_0 => F4_3 | F4_3, F4_1 => F4_3 | F4_3, F4_2 => F4_3 | F4_3, F4_3 => F4_3
  end.

#[local] Instance refa419_inst : Magma Fin4 := {| magma_op := refa419_op |}.

Lemma refa419_sat366 : @Equation366 Fin4 refa419_inst.
Proof. unfold Equation366, magma_op, refa419_inst, refa419_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa419_sat3480 : @Equation3480 Fin4 refa419_inst.
Proof. unfold Equation3480, magma_op, refa419_inst, refa419_op. intros x y z w. destruct x, y, z, w; reflexivity. Qed.

Lemma refa419_sat4481 : @Equation4481 Fin4 refa419_inst.
Proof. unfold Equation4481, magma_op, refa419_inst, refa419_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa419_not3255 : ~ @Equation3255 Fin4 refa419_inst.
Proof. unfold Equation3255. intro H. specialize (H F4_0 F4_2). unfold magma_op, refa419_inst, refa419_op in H. discriminate H. Qed.

Lemma refa419_not3259 : ~ @Equation3259 Fin4 refa419_inst.
Proof. unfold Equation3259. intro H. specialize (H F4_2 F4_0). unfold magma_op, refa419_inst, refa419_op in H. discriminate H. Qed.

Lemma refa419_not3261 : ~ @Equation3261 Fin4 refa419_inst.
Proof. unfold Equation3261. intro H. specialize (H F4_0 F4_2). unfold magma_op, refa419_inst, refa419_op in H. discriminate H. Qed.

Lemma refa419_not3269 : ~ @Equation3269 Fin4 refa419_inst.
Proof. unfold Equation3269. intro H. specialize (H F4_2 F4_0). unfold magma_op, refa419_inst, refa419_op in H. discriminate H. Qed.

Lemma refa419_not3271 : ~ @Equation3271 Fin4 refa419_inst.
Proof. unfold Equation3271. intro H. specialize (H F4_0 F4_2). unfold magma_op, refa419_inst, refa419_op in H. discriminate H. Qed.

Lemma refa419_not3279 : ~ @Equation3279 Fin4 refa419_inst.
Proof. unfold Equation3279. intro H. specialize (H F4_2 F4_0). unfold magma_op, refa419_inst, refa419_op in H. discriminate H. Qed.

Lemma refa419_not4269 : ~ @Equation4269 Fin4 refa419_inst.
Proof. unfold Equation4269. intro H. specialize (H F4_0 F4_2). unfold magma_op, refa419_inst, refa419_op in H. discriminate H. Qed.

Lemma refa419_not4273 : ~ @Equation4273 Fin4 refa419_inst.
Proof. unfold Equation4273. intro H. specialize (H F4_2 F4_0). unfold magma_op, refa419_inst, refa419_op in H. discriminate H. Qed.

Lemma refa419_not4314 : ~ @Equation4314 Fin4 refa419_inst.
Proof. unfold Equation4314. intro H. specialize (H F4_0 F4_2). unfold magma_op, refa419_inst, refa419_op in H. discriminate H. Qed.

Lemma refa419_not4320 : ~ @Equation4320 Fin4 refa419_inst.
Proof. unfold Equation4320. intro H. specialize (H F4_0 F4_2). unfold magma_op, refa419_inst, refa419_op in H. discriminate H. Qed.

Lemma refa419_not4321 : ~ @Equation4321 Fin4 refa419_inst.
Proof. unfold Equation4321. intro H. specialize (H F4_0 F4_2). unfold magma_op, refa419_inst, refa419_op in H. discriminate H. Qed.

Lemma refa419_not4433 : ~ @Equation4433 Fin4 refa419_inst.
Proof. unfold Equation4433. intro H. specialize (H F4_0 F4_2). unfold magma_op, refa419_inst, refa419_op in H. discriminate H. Qed.

Lemma refa419_not4435 : ~ @Equation4435 Fin4 refa419_inst.
Proof. unfold Equation4435. intro H. specialize (H F4_0 F4_2). unfold magma_op, refa419_inst, refa419_op in H. discriminate H. Qed.

Lemma refa419_not4436 : ~ @Equation4436 Fin4 refa419_inst.
Proof. unfold Equation4436. intro H. specialize (H F4_0 F4_2). unfold magma_op, refa419_inst, refa419_op in H. discriminate H. Qed.

Lemma refa419_not4442 : ~ @Equation4442 Fin4 refa419_inst.
Proof. unfold Equation4442. intro H. specialize (H F4_0 F4_2). unfold magma_op, refa419_inst, refa419_op in H. discriminate H. Qed.

Lemma refa419_not4443 : ~ @Equation4443 Fin4 refa419_inst.
Proof. unfold Equation4443. intro H. specialize (H F4_0 F4_2). unfold magma_op, refa419_inst, refa419_op in H. discriminate H. Qed.

Lemma refa419_not4445 : ~ @Equation4445 Fin4 refa419_inst.
Proof. unfold Equation4445. intro H. specialize (H F4_0 F4_2). unfold magma_op, refa419_inst, refa419_op in H. discriminate H. Qed.

(** ---- refa42 (Fin13) ---- *)

Definition refa42_op (x y : Fin13) : Fin13 :=
  match x, y with
  | F13_0, F13_0 => F13_0 | F13_0, F13_1 => F13_2 | F13_0, F13_2 => F13_3 | F13_0, F13_3 => F13_4 | F13_0, F13_4 => F13_5 | F13_0, F13_5 => F13_6 | F13_0, F13_6 => F13_7 | F13_0, F13_7 => F13_8 | F13_0, F13_8 => F13_9 | F13_0, F13_9 => F13_10 | F13_0, F13_10 => F13_11 | F13_0, F13_11 => F13_12 | F13_0, F13_12 => F13_1
  | F13_1, F13_0 => F13_2 | F13_1, F13_1 => F13_1 | F13_1, F13_2 => F13_11 | F13_1, F13_3 => F13_7 | F13_1, F13_4 => F13_9 | F13_1, F13_5 => F13_4 | F13_1, F13_6 => F13_8 | F13_1, F13_7 => F13_0 | F13_1, F13_8 => F13_3 | F13_1, F13_9 => F13_12 | F13_1, F13_10 => F13_6 | F13_1, F13_11 => F13_5 | F13_1, F13_12 => F13_10
  | F13_2, F13_0 => F13_3 | F13_2, F13_1 => F13_11 | F13_2, F13_2 => F13_2 | F13_2, F13_3 => F13_12 | F13_2, F13_4 => F13_8 | F13_2, F13_5 => F13_10 | F13_2, F13_6 => F13_5 | F13_2, F13_7 => F13_9 | F13_2, F13_8 => F13_0 | F13_2, F13_9 => F13_4 | F13_2, F13_10 => F13_1 | F13_2, F13_11 => F13_7 | F13_2, F13_12 => F13_6
  | F13_3, F13_0 => F13_4 | F13_3, F13_1 => F13_7 | F13_3, F13_2 => F13_12 | F13_3, F13_3 => F13_3 | F13_3, F13_4 => F13_1 | F13_3, F13_5 => F13_9 | F13_3, F13_6 => F13_11 | F13_3, F13_7 => F13_6 | F13_3, F13_8 => F13_10 | F13_3, F13_9 => F13_0 | F13_3, F13_10 => F13_5 | F13_3, F13_11 => F13_2 | F13_3, F13_12 => F13_8
  | F13_4, F13_0 => F13_5 | F13_4, F13_1 => F13_9 | F13_4, F13_2 => F13_8 | F13_4, F13_3 => F13_1 | F13_4, F13_4 => F13_4 | F13_4, F13_5 => F13_2 | F13_4, F13_6 => F13_10 | F13_4, F13_7 => F13_12 | F13_4, F13_8 => F13_7 | F13_4, F13_9 => F13_11 | F13_4, F13_10 => F13_0 | F13_4, F13_11 => F13_6 | F13_4, F13_12 => F13_3
  | F13_5, F13_0 => F13_6 | F13_5, F13_1 => F13_4 | F13_5, F13_2 => F13_10 | F13_5, F13_3 => F13_9 | F13_5, F13_4 => F13_2 | F13_5, F13_5 => F13_5 | F13_5, F13_6 => F13_3 | F13_5, F13_7 => F13_11 | F13_5, F13_8 => F13_1 | F13_5, F13_9 => F13_8 | F13_5, F13_10 => F13_12 | F13_5, F13_11 => F13_0 | F13_5, F13_12 => F13_7
  | F13_6, F13_0 => F13_7 | F13_6, F13_1 => F13_8 | F13_6, F13_2 => F13_5 | F13_6, F13_3 => F13_11 | F13_6, F13_4 => F13_10 | F13_6, F13_5 => F13_3 | F13_6, F13_6 => F13_6 | F13_6, F13_7 => F13_4 | F13_6, F13_8 => F13_12 | F13_6, F13_9 => F13_2 | F13_6, F13_10 => F13_9 | F13_6, F13_11 => F13_1 | F13_6, F13_12 => F13_0
  | F13_7, F13_0 => F13_8 | F13_7, F13_1 => F13_0 | F13_7, F13_2 => F13_9 | F13_7, F13_3 => F13_6 | F13_7, F13_4 => F13_12 | F13_7, F13_5 => F13_11 | F13_7, F13_6 => F13_4 | F13_7, F13_7 => F13_7 | F13_7, F13_8 => F13_5 | F13_7, F13_9 => F13_1 | F13_7, F13_10 => F13_3 | F13_7, F13_11 => F13_10 | F13_7, F13_12 => F13_2
  | F13_8, F13_0 => F13_9 | F13_8, F13_1 => F13_3 | F13_8, F13_2 => F13_0 | F13_8, F13_3 => F13_10 | F13_8, F13_4 => F13_7 | F13_8, F13_5 => F13_1 | F13_8, F13_6 => F13_12 | F13_8, F13_7 => F13_5 | F13_8, F13_8 => F13_8 | F13_8, F13_9 => F13_6 | F13_8, F13_10 => F13_2 | F13_8, F13_11 => F13_4 | F13_8, F13_12 => F13_11
  | F13_9, F13_0 => F13_10 | F13_9, F13_1 => F13_12 | F13_9, F13_2 => F13_4 | F13_9, F13_3 => F13_0 | F13_9, F13_4 => F13_11 | F13_9, F13_5 => F13_8 | F13_9, F13_6 => F13_2 | F13_9, F13_7 => F13_1 | F13_9, F13_8 => F13_6 | F13_9, F13_9 => F13_9 | F13_9, F13_10 => F13_7 | F13_9, F13_11 => F13_3 | F13_9, F13_12 => F13_5
  | F13_10, F13_0 => F13_11 | F13_10, F13_1 => F13_6 | F13_10, F13_2 => F13_1 | F13_10, F13_3 => F13_5 | F13_10, F13_4 => F13_0 | F13_10, F13_5 => F13_12 | F13_10, F13_6 => F13_9 | F13_10, F13_7 => F13_3 | F13_10, F13_8 => F13_2 | F13_10, F13_9 => F13_7 | F13_10, F13_10 => F13_10 | F13_10, F13_11 => F13_8 | F13_10, F13_12 => F13_4
  | F13_11, F13_0 => F13_12 | F13_11, F13_1 => F13_5 | F13_11, F13_2 => F13_7 | F13_11, F13_3 => F13_2 | F13_11, F13_4 => F13_6 | F13_11, F13_5 => F13_0 | F13_11, F13_6 => F13_1 | F13_11, F13_7 => F13_10 | F13_11, F13_8 => F13_4 | F13_11, F13_9 => F13_3 | F13_11, F13_10 => F13_8 | F13_11, F13_11 => F13_11 | F13_11, F13_12 => F13_9
  | F13_12, F13_0 => F13_1 | F13_12, F13_1 => F13_10 | F13_12, F13_2 => F13_6 | F13_12, F13_3 => F13_8 | F13_12, F13_4 => F13_3 | F13_12, F13_5 => F13_7 | F13_12, F13_6 => F13_0 | F13_12, F13_7 => F13_2 | F13_12, F13_8 => F13_11 | F13_12, F13_9 => F13_5 | F13_12, F13_10 => F13_4 | F13_12, F13_11 => F13_9 | F13_12, F13_12 => F13_12
  end.

#[local] Instance refa42_inst : Magma Fin13 := {| magma_op := refa42_op |}.

Lemma refa42_sat1076 : @Equation1076 Fin13 refa42_inst.
Proof. unfold Equation1076, magma_op, refa42_inst, refa42_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa42_sat1313 : @Equation1313 Fin13 refa42_inst.
Proof. unfold Equation1313, magma_op, refa42_inst, refa42_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa42_sat2294 : @Equation2294 Fin13 refa42_inst.
Proof. unfold Equation2294, magma_op, refa42_inst, refa42_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa42_sat2531 : @Equation2531 Fin13 refa42_inst.
Proof. unfold Equation2531, magma_op, refa42_inst, refa42_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa42_not50 : ~ @Equation50 Fin13 refa42_inst.
Proof. unfold Equation50. intro H. specialize (H F13_0 F13_1). unfold magma_op, refa42_inst, refa42_op in H. discriminate H. Qed.

Lemma refa42_not55 : ~ @Equation55 Fin13 refa42_inst.
Proof. unfold Equation55. intro H. specialize (H F13_0 F13_1). unfold magma_op, refa42_inst, refa42_op in H. discriminate H. Qed.

Lemma refa42_not56 : ~ @Equation56 Fin13 refa42_inst.
Proof. unfold Equation56. intro H. specialize (H F13_0 F13_1). unfold magma_op, refa42_inst, refa42_op in H. discriminate H. Qed.

Lemma refa42_not65 : ~ @Equation65 Fin13 refa42_inst.
Proof. unfold Equation65. intro H. specialize (H F13_0 F13_1). unfold magma_op, refa42_inst, refa42_op in H. discriminate H. Qed.

Lemma refa42_not66 : ~ @Equation66 Fin13 refa42_inst.
Proof. unfold Equation66. intro H. specialize (H F13_0 F13_1). unfold magma_op, refa42_inst, refa42_op in H. discriminate H. Qed.

Lemma refa42_not73 : ~ @Equation73 Fin13 refa42_inst.
Proof. unfold Equation73. intro H. specialize (H F13_0 F13_1). unfold magma_op, refa42_inst, refa42_op in H. discriminate H. Qed.

Lemma refa42_not75 : ~ @Equation75 Fin13 refa42_inst.
Proof. unfold Equation75. intro H. specialize (H F13_0 F13_1). unfold magma_op, refa42_inst, refa42_op in H. discriminate H. Qed.

Lemma refa42_not105 : ~ @Equation105 Fin13 refa42_inst.
Proof. unfold Equation105. intro H. specialize (H F13_0 F13_1). unfold magma_op, refa42_inst, refa42_op in H. discriminate H. Qed.

Lemma refa42_not107 : ~ @Equation107 Fin13 refa42_inst.
Proof. unfold Equation107. intro H. specialize (H F13_0 F13_1). unfold magma_op, refa42_inst, refa42_op in H. discriminate H. Qed.

Lemma refa42_not108 : ~ @Equation108 Fin13 refa42_inst.
Proof. unfold Equation108. intro H. specialize (H F13_0 F13_1). unfold magma_op, refa42_inst, refa42_op in H. discriminate H. Qed.

Lemma refa42_not117 : ~ @Equation117 Fin13 refa42_inst.
Proof. unfold Equation117. intro H. specialize (H F13_0 F13_1). unfold magma_op, refa42_inst, refa42_op in H. discriminate H. Qed.

Lemma refa42_not118 : ~ @Equation118 Fin13 refa42_inst.
Proof. unfold Equation118. intro H. specialize (H F13_0 F13_1). unfold magma_op, refa42_inst, refa42_op in H. discriminate H. Qed.

Lemma refa42_not124 : ~ @Equation124 Fin13 refa42_inst.
Proof. unfold Equation124. intro H. specialize (H F13_0 F13_1). unfold magma_op, refa42_inst, refa42_op in H. discriminate H. Qed.

Lemma refa42_not127 : ~ @Equation127 Fin13 refa42_inst.
Proof. unfold Equation127. intro H. specialize (H F13_0 F13_1). unfold magma_op, refa42_inst, refa42_op in H. discriminate H. Qed.

Lemma refa42_not159 : ~ @Equation159 Fin13 refa42_inst.
Proof. unfold Equation159. intro H. specialize (H F13_0 F13_1). unfold magma_op, refa42_inst, refa42_op in H. discriminate H. Qed.

Lemma refa42_not160 : ~ @Equation160 Fin13 refa42_inst.
Proof. unfold Equation160. intro H. specialize (H F13_0 F13_1). unfold magma_op, refa42_inst, refa42_op in H. discriminate H. Qed.

Lemma refa42_not167 : ~ @Equation167 Fin13 refa42_inst.
Proof. unfold Equation167. intro H. specialize (H F13_0 F13_1). unfold magma_op, refa42_inst, refa42_op in H. discriminate H. Qed.

Lemma refa42_not206 : ~ @Equation206 Fin13 refa42_inst.
Proof. unfold Equation206. intro H. specialize (H F13_0 F13_1). unfold magma_op, refa42_inst, refa42_op in H. discriminate H. Qed.

Lemma refa42_not209 : ~ @Equation209 Fin13 refa42_inst.
Proof. unfold Equation209. intro H. specialize (H F13_0 F13_1). unfold magma_op, refa42_inst, refa42_op in H. discriminate H. Qed.

Lemma refa42_not211 : ~ @Equation211 Fin13 refa42_inst.
Proof. unfold Equation211. intro H. specialize (H F13_0 F13_1). unfold magma_op, refa42_inst, refa42_op in H. discriminate H. Qed.

Lemma refa42_not221 : ~ @Equation221 Fin13 refa42_inst.
Proof. unfold Equation221. intro H. specialize (H F13_0 F13_1). unfold magma_op, refa42_inst, refa42_op in H. discriminate H. Qed.

Lemma refa42_not229 : ~ @Equation229 Fin13 refa42_inst.
Proof. unfold Equation229. intro H. specialize (H F13_0 F13_1). unfold magma_op, refa42_inst, refa42_op in H. discriminate H. Qed.

Lemma refa42_not231 : ~ @Equation231 Fin13 refa42_inst.
Proof. unfold Equation231. intro H. specialize (H F13_0 F13_1). unfold magma_op, refa42_inst, refa42_op in H. discriminate H. Qed.

Lemma refa42_not261 : ~ @Equation261 Fin13 refa42_inst.
Proof. unfold Equation261. intro H. specialize (H F13_0 F13_1). unfold magma_op, refa42_inst, refa42_op in H. discriminate H. Qed.

Lemma refa42_not263 : ~ @Equation263 Fin13 refa42_inst.
Proof. unfold Equation263. intro H. specialize (H F13_0 F13_1). unfold magma_op, refa42_inst, refa42_op in H. discriminate H. Qed.

Lemma refa42_not264 : ~ @Equation264 Fin13 refa42_inst.
Proof. unfold Equation264. intro H. specialize (H F13_0 F13_1). unfold magma_op, refa42_inst, refa42_op in H. discriminate H. Qed.

Lemma refa42_not274 : ~ @Equation274 Fin13 refa42_inst.
Proof. unfold Equation274. intro H. specialize (H F13_0 F13_1). unfold magma_op, refa42_inst, refa42_op in H. discriminate H. Qed.

Lemma refa42_not280 : ~ @Equation280 Fin13 refa42_inst.
Proof. unfold Equation280. intro H. specialize (H F13_0 F13_1). unfold magma_op, refa42_inst, refa42_op in H. discriminate H. Qed.

Lemma refa42_not283 : ~ @Equation283 Fin13 refa42_inst.
Proof. unfold Equation283. intro H. specialize (H F13_0 F13_1). unfold magma_op, refa42_inst, refa42_op in H. discriminate H. Qed.

Lemma refa42_not412 : ~ @Equation412 Fin13 refa42_inst.
Proof. unfold Equation412. intro H. specialize (H F13_0 F13_1). unfold magma_op, refa42_inst, refa42_op in H. discriminate H. Qed.

Lemma refa42_not413 : ~ @Equation413 Fin13 refa42_inst.
Proof. unfold Equation413. intro H. specialize (H F13_0 F13_1). unfold magma_op, refa42_inst, refa42_op in H. discriminate H. Qed.

Lemma refa42_not414 : ~ @Equation414 Fin13 refa42_inst.
Proof. unfold Equation414. intro H. specialize (H F13_0 F13_1). unfold magma_op, refa42_inst, refa42_op in H. discriminate H. Qed.

Lemma refa42_not416 : ~ @Equation416 Fin13 refa42_inst.
Proof. unfold Equation416. intro H. specialize (H F13_0 F13_1). unfold magma_op, refa42_inst, refa42_op in H. discriminate H. Qed.

Lemma refa42_not417 : ~ @Equation417 Fin13 refa42_inst.
Proof. unfold Equation417. intro H. specialize (H F13_0 F13_1). unfold magma_op, refa42_inst, refa42_op in H. discriminate H. Qed.

Lemma refa42_not419 : ~ @Equation419 Fin13 refa42_inst.
Proof. unfold Equation419. intro H. specialize (H F13_0 F13_1). unfold magma_op, refa42_inst, refa42_op in H. discriminate H. Qed.

Lemma refa42_not420 : ~ @Equation420 Fin13 refa42_inst.
Proof. unfold Equation420. intro H. specialize (H F13_0 F13_1). unfold magma_op, refa42_inst, refa42_op in H. discriminate H. Qed.

Lemma refa42_not426 : ~ @Equation426 Fin13 refa42_inst.
Proof. unfold Equation426. intro H. specialize (H F13_0 F13_1). unfold magma_op, refa42_inst, refa42_op in H. discriminate H. Qed.

Lemma refa42_not427 : ~ @Equation427 Fin13 refa42_inst.
Proof. unfold Equation427. intro H. specialize (H F13_0 F13_1). unfold magma_op, refa42_inst, refa42_op in H. discriminate H. Qed.

Lemma refa42_not429 : ~ @Equation429 Fin13 refa42_inst.
Proof. unfold Equation429. intro H. specialize (H F13_0 F13_1). unfold magma_op, refa42_inst, refa42_op in H. discriminate H. Qed.

Lemma refa42_not430 : ~ @Equation430 Fin13 refa42_inst.
Proof. unfold Equation430. intro H. specialize (H F13_0 F13_1). unfold magma_op, refa42_inst, refa42_op in H. discriminate H. Qed.

Lemma refa42_not436 : ~ @Equation436 Fin13 refa42_inst.
Proof. unfold Equation436. intro H. specialize (H F13_0 F13_1). unfold magma_op, refa42_inst, refa42_op in H. discriminate H. Qed.

Lemma refa42_not437 : ~ @Equation437 Fin13 refa42_inst.
Proof. unfold Equation437. intro H. specialize (H F13_0 F13_1). unfold magma_op, refa42_inst, refa42_op in H. discriminate H. Qed.

Lemma refa42_not439 : ~ @Equation439 Fin13 refa42_inst.
Proof. unfold Equation439. intro H. specialize (H F13_0 F13_1). unfold magma_op, refa42_inst, refa42_op in H. discriminate H. Qed.

Lemma refa42_not440 : ~ @Equation440 Fin13 refa42_inst.
Proof. unfold Equation440. intro H. specialize (H F13_0 F13_1). unfold magma_op, refa42_inst, refa42_op in H. discriminate H. Qed.

Lemma refa42_not464 : ~ @Equation464 Fin13 refa42_inst.
Proof. unfold Equation464. intro H. specialize (H F13_0 F13_1). unfold magma_op, refa42_inst, refa42_op in H. discriminate H. Qed.

Lemma refa42_not466 : ~ @Equation466 Fin13 refa42_inst.
Proof. unfold Equation466. intro H. specialize (H F13_0 F13_1). unfold magma_op, refa42_inst, refa42_op in H. discriminate H. Qed.

Lemma refa42_not467 : ~ @Equation467 Fin13 refa42_inst.
Proof. unfold Equation467. intro H. specialize (H F13_0 F13_1). unfold magma_op, refa42_inst, refa42_op in H. discriminate H. Qed.

Lemma refa42_not473 : ~ @Equation473 Fin13 refa42_inst.
Proof. unfold Equation473. intro H. specialize (H F13_0 F13_1). unfold magma_op, refa42_inst, refa42_op in H. discriminate H. Qed.

Lemma refa42_not474 : ~ @Equation474 Fin13 refa42_inst.
Proof. unfold Equation474. intro H. specialize (H F13_0 F13_1). unfold magma_op, refa42_inst, refa42_op in H. discriminate H. Qed.

Lemma refa42_not476 : ~ @Equation476 Fin13 refa42_inst.
Proof. unfold Equation476. intro H. specialize (H F13_0 F13_1). unfold magma_op, refa42_inst, refa42_op in H. discriminate H. Qed.

Lemma refa42_not477 : ~ @Equation477 Fin13 refa42_inst.
Proof. unfold Equation477. intro H. specialize (H F13_0 F13_1). unfold magma_op, refa42_inst, refa42_op in H. discriminate H. Qed.

Lemma refa42_not504 : ~ @Equation504 Fin13 refa42_inst.
Proof. unfold Equation504. intro H. specialize (H F13_0 F13_1). unfold magma_op, refa42_inst, refa42_op in H. discriminate H. Qed.

Lemma refa42_not511 : ~ @Equation511 Fin13 refa42_inst.
Proof. unfold Equation511. intro H. specialize (H F13_0 F13_1). unfold magma_op, refa42_inst, refa42_op in H. discriminate H. Qed.

Lemma refa42_not513 : ~ @Equation513 Fin13 refa42_inst.
Proof. unfold Equation513. intro H. specialize (H F13_0 F13_1). unfold magma_op, refa42_inst, refa42_op in H. discriminate H. Qed.

Lemma refa42_not615 : ~ @Equation615 Fin13 refa42_inst.
Proof. unfold Equation615. intro H. specialize (H F13_0 F13_1). unfold magma_op, refa42_inst, refa42_op in H. discriminate H. Qed.

Lemma refa42_not616 : ~ @Equation616 Fin13 refa42_inst.
Proof. unfold Equation616. intro H. specialize (H F13_0 F13_1). unfold magma_op, refa42_inst, refa42_op in H. discriminate H. Qed.

Lemma refa42_not617 : ~ @Equation617 Fin13 refa42_inst.
Proof. unfold Equation617. intro H. specialize (H F13_0 F13_1). unfold magma_op, refa42_inst, refa42_op in H. discriminate H. Qed.

Lemma refa42_not619 : ~ @Equation619 Fin13 refa42_inst.
Proof. unfold Equation619. intro H. specialize (H F13_0 F13_1). unfold magma_op, refa42_inst, refa42_op in H. discriminate H. Qed.

Lemma refa42_not620 : ~ @Equation620 Fin13 refa42_inst.
Proof. unfold Equation620. intro H. specialize (H F13_0 F13_1). unfold magma_op, refa42_inst, refa42_op in H. discriminate H. Qed.

Lemma refa42_not622 : ~ @Equation622 Fin13 refa42_inst.
Proof. unfold Equation622. intro H. specialize (H F13_0 F13_1). unfold magma_op, refa42_inst, refa42_op in H. discriminate H. Qed.

Lemma refa42_not623 : ~ @Equation623 Fin13 refa42_inst.
Proof. unfold Equation623. intro H. specialize (H F13_0 F13_1). unfold magma_op, refa42_inst, refa42_op in H. discriminate H. Qed.

Lemma refa42_not629 : ~ @Equation629 Fin13 refa42_inst.
Proof. unfold Equation629. intro H. specialize (H F13_0 F13_1). unfold magma_op, refa42_inst, refa42_op in H. discriminate H. Qed.

Lemma refa42_not630 : ~ @Equation630 Fin13 refa42_inst.
Proof. unfold Equation630. intro H. specialize (H F13_0 F13_1). unfold magma_op, refa42_inst, refa42_op in H. discriminate H. Qed.

Lemma refa42_not632 : ~ @Equation632 Fin13 refa42_inst.
Proof. unfold Equation632. intro H. specialize (H F13_0 F13_1). unfold magma_op, refa42_inst, refa42_op in H. discriminate H. Qed.

Lemma refa42_not633 : ~ @Equation633 Fin13 refa42_inst.
Proof. unfold Equation633. intro H. specialize (H F13_0 F13_1). unfold magma_op, refa42_inst, refa42_op in H. discriminate H. Qed.

Lemma refa42_not639 : ~ @Equation639 Fin13 refa42_inst.
Proof. unfold Equation639. intro H. specialize (H F13_0 F13_1). unfold magma_op, refa42_inst, refa42_op in H. discriminate H. Qed.

Lemma refa42_not640 : ~ @Equation640 Fin13 refa42_inst.
Proof. unfold Equation640. intro H. specialize (H F13_0 F13_1). unfold magma_op, refa42_inst, refa42_op in H. discriminate H. Qed.

Lemma refa42_not642 : ~ @Equation642 Fin13 refa42_inst.
Proof. unfold Equation642. intro H. specialize (H F13_0 F13_1). unfold magma_op, refa42_inst, refa42_op in H. discriminate H. Qed.

Lemma refa42_not643 : ~ @Equation643 Fin13 refa42_inst.
Proof. unfold Equation643. intro H. specialize (H F13_0 F13_1). unfold magma_op, refa42_inst, refa42_op in H. discriminate H. Qed.

Lemma refa42_not667 : ~ @Equation667 Fin13 refa42_inst.
Proof. unfold Equation667. intro H. specialize (H F13_0 F13_1). unfold magma_op, refa42_inst, refa42_op in H. discriminate H. Qed.

Lemma refa42_not669 : ~ @Equation669 Fin13 refa42_inst.
Proof. unfold Equation669. intro H. specialize (H F13_0 F13_1). unfold magma_op, refa42_inst, refa42_op in H. discriminate H. Qed.

Lemma refa42_not670 : ~ @Equation670 Fin13 refa42_inst.
Proof. unfold Equation670. intro H. specialize (H F13_0 F13_1). unfold magma_op, refa42_inst, refa42_op in H. discriminate H. Qed.

Lemma refa42_not676 : ~ @Equation676 Fin13 refa42_inst.
Proof. unfold Equation676. intro H. specialize (H F13_0 F13_1). unfold magma_op, refa42_inst, refa42_op in H. discriminate H. Qed.

Lemma refa42_not677 : ~ @Equation677 Fin13 refa42_inst.
Proof. unfold Equation677. intro H. specialize (H F13_0 F13_1). unfold magma_op, refa42_inst, refa42_op in H. discriminate H. Qed.

Lemma refa42_not679 : ~ @Equation679 Fin13 refa42_inst.
Proof. unfold Equation679. intro H. specialize (H F13_0 F13_1). unfold magma_op, refa42_inst, refa42_op in H. discriminate H. Qed.

Lemma refa42_not680 : ~ @Equation680 Fin13 refa42_inst.
Proof. unfold Equation680. intro H. specialize (H F13_0 F13_1). unfold magma_op, refa42_inst, refa42_op in H. discriminate H. Qed.

Lemma refa42_not704 : ~ @Equation704 Fin13 refa42_inst.
Proof. unfold Equation704. intro H. specialize (H F13_0 F13_1). unfold magma_op, refa42_inst, refa42_op in H. discriminate H. Qed.

Lemma refa42_not707 : ~ @Equation707 Fin13 refa42_inst.
Proof. unfold Equation707. intro H. specialize (H F13_0 F13_1). unfold magma_op, refa42_inst, refa42_op in H. discriminate H. Qed.

Lemma refa42_not716 : ~ @Equation716 Fin13 refa42_inst.
Proof. unfold Equation716. intro H. specialize (H F13_0 F13_1). unfold magma_op, refa42_inst, refa42_op in H. discriminate H. Qed.

Lemma refa42_not818 : ~ @Equation818 Fin13 refa42_inst.
Proof. unfold Equation818. intro H. specialize (H F13_0 F13_1). unfold magma_op, refa42_inst, refa42_op in H. discriminate H. Qed.

Lemma refa42_not819 : ~ @Equation819 Fin13 refa42_inst.
Proof. unfold Equation819. intro H. specialize (H F13_0 F13_1). unfold magma_op, refa42_inst, refa42_op in H. discriminate H. Qed.

Lemma refa42_not820 : ~ @Equation820 Fin13 refa42_inst.
Proof. unfold Equation820. intro H. specialize (H F13_0 F13_1). unfold magma_op, refa42_inst, refa42_op in H. discriminate H. Qed.

Lemma refa42_not822 : ~ @Equation822 Fin13 refa42_inst.
Proof. unfold Equation822. intro H. specialize (H F13_0 F13_1). unfold magma_op, refa42_inst, refa42_op in H. discriminate H. Qed.

Lemma refa42_not823 : ~ @Equation823 Fin13 refa42_inst.
Proof. unfold Equation823. intro H. specialize (H F13_0 F13_1). unfold magma_op, refa42_inst, refa42_op in H. discriminate H. Qed.

Lemma refa42_not825 : ~ @Equation825 Fin13 refa42_inst.
Proof. unfold Equation825. intro H. specialize (H F13_0 F13_1). unfold magma_op, refa42_inst, refa42_op in H. discriminate H. Qed.

Lemma refa42_not826 : ~ @Equation826 Fin13 refa42_inst.
Proof. unfold Equation826. intro H. specialize (H F13_0 F13_1). unfold magma_op, refa42_inst, refa42_op in H. discriminate H. Qed.

Lemma refa42_not832 : ~ @Equation832 Fin13 refa42_inst.
Proof. unfold Equation832. intro H. specialize (H F13_0 F13_1). unfold magma_op, refa42_inst, refa42_op in H. discriminate H. Qed.

Lemma refa42_not833 : ~ @Equation833 Fin13 refa42_inst.
Proof. unfold Equation833. intro H. specialize (H F13_0 F13_1). unfold magma_op, refa42_inst, refa42_op in H. discriminate H. Qed.

Lemma refa42_not835 : ~ @Equation835 Fin13 refa42_inst.
Proof. unfold Equation835. intro H. specialize (H F13_0 F13_1). unfold magma_op, refa42_inst, refa42_op in H. discriminate H. Qed.

Lemma refa42_not836 : ~ @Equation836 Fin13 refa42_inst.
Proof. unfold Equation836. intro H. specialize (H F13_0 F13_1). unfold magma_op, refa42_inst, refa42_op in H. discriminate H. Qed.

Lemma refa42_not842 : ~ @Equation842 Fin13 refa42_inst.
Proof. unfold Equation842. intro H. specialize (H F13_0 F13_1). unfold magma_op, refa42_inst, refa42_op in H. discriminate H. Qed.

Lemma refa42_not843 : ~ @Equation843 Fin13 refa42_inst.
Proof. unfold Equation843. intro H. specialize (H F13_0 F13_1). unfold magma_op, refa42_inst, refa42_op in H. discriminate H. Qed.

Lemma refa42_not845 : ~ @Equation845 Fin13 refa42_inst.
Proof. unfold Equation845. intro H. specialize (H F13_0 F13_1). unfold magma_op, refa42_inst, refa42_op in H. discriminate H. Qed.

Lemma refa42_not846 : ~ @Equation846 Fin13 refa42_inst.
Proof. unfold Equation846. intro H. specialize (H F13_0 F13_1). unfold magma_op, refa42_inst, refa42_op in H. discriminate H. Qed.

Lemma refa42_not870 : ~ @Equation870 Fin13 refa42_inst.
Proof. unfold Equation870. intro H. specialize (H F13_0 F13_1). unfold magma_op, refa42_inst, refa42_op in H. discriminate H. Qed.

Lemma refa42_not872 : ~ @Equation872 Fin13 refa42_inst.
Proof. unfold Equation872. intro H. specialize (H F13_0 F13_1). unfold magma_op, refa42_inst, refa42_op in H. discriminate H. Qed.

Lemma refa42_not873 : ~ @Equation873 Fin13 refa42_inst.
Proof. unfold Equation873. intro H. specialize (H F13_0 F13_1). unfold magma_op, refa42_inst, refa42_op in H. discriminate H. Qed.

Lemma refa42_not879 : ~ @Equation879 Fin13 refa42_inst.
Proof. unfold Equation879. intro H. specialize (H F13_0 F13_1). unfold magma_op, refa42_inst, refa42_op in H. discriminate H. Qed.

Lemma refa42_not882 : ~ @Equation882 Fin13 refa42_inst.
Proof. unfold Equation882. intro H. specialize (H F13_0 F13_1). unfold magma_op, refa42_inst, refa42_op in H. discriminate H. Qed.

Lemma refa42_not883 : ~ @Equation883 Fin13 refa42_inst.
Proof. unfold Equation883. intro H. specialize (H F13_0 F13_1). unfold magma_op, refa42_inst, refa42_op in H. discriminate H. Qed.

Lemma refa42_not906 : ~ @Equation906 Fin13 refa42_inst.
Proof. unfold Equation906. intro H. specialize (H F13_0 F13_1). unfold magma_op, refa42_inst, refa42_op in H. discriminate H. Qed.

Lemma refa42_not907 : ~ @Equation907 Fin13 refa42_inst.
Proof. unfold Equation907. intro H. specialize (H F13_0 F13_1). unfold magma_op, refa42_inst, refa42_op in H. discriminate H. Qed.

Lemma refa42_not917 : ~ @Equation917 Fin13 refa42_inst.
Proof. unfold Equation917. intro H. specialize (H F13_0 F13_1). unfold magma_op, refa42_inst, refa42_op in H. discriminate H. Qed.

Lemma refa42_not1021 : ~ @Equation1021 Fin13 refa42_inst.
Proof. unfold Equation1021. intro H. specialize (H F13_0 F13_1). unfold magma_op, refa42_inst, refa42_op in H. discriminate H. Qed.

Lemma refa42_not1022 : ~ @Equation1022 Fin13 refa42_inst.
Proof. unfold Equation1022. intro H. specialize (H F13_0 F13_1). unfold magma_op, refa42_inst, refa42_op in H. discriminate H. Qed.

Lemma refa42_not1023 : ~ @Equation1023 Fin13 refa42_inst.
Proof. unfold Equation1023. intro H. specialize (H F13_0 F13_1). unfold magma_op, refa42_inst, refa42_op in H. discriminate H. Qed.

Lemma refa42_not1025 : ~ @Equation1025 Fin13 refa42_inst.
Proof. unfold Equation1025. intro H. specialize (H F13_0 F13_1). unfold magma_op, refa42_inst, refa42_op in H. discriminate H. Qed.

Lemma refa42_not1026 : ~ @Equation1026 Fin13 refa42_inst.
Proof. unfold Equation1026. intro H. specialize (H F13_0 F13_1). unfold magma_op, refa42_inst, refa42_op in H. discriminate H. Qed.

Lemma refa42_not1028 : ~ @Equation1028 Fin13 refa42_inst.
Proof. unfold Equation1028. intro H. specialize (H F13_0 F13_1). unfold magma_op, refa42_inst, refa42_op in H. discriminate H. Qed.

Lemma refa42_not1029 : ~ @Equation1029 Fin13 refa42_inst.
Proof. unfold Equation1029. intro H. specialize (H F13_0 F13_1). unfold magma_op, refa42_inst, refa42_op in H. discriminate H. Qed.

Lemma refa42_not1035 : ~ @Equation1035 Fin13 refa42_inst.
Proof. unfold Equation1035. intro H. specialize (H F13_0 F13_1). unfold magma_op, refa42_inst, refa42_op in H. discriminate H. Qed.

Lemma refa42_not1036 : ~ @Equation1036 Fin13 refa42_inst.
Proof. unfold Equation1036. intro H. specialize (H F13_0 F13_1). unfold magma_op, refa42_inst, refa42_op in H. discriminate H. Qed.

Lemma refa42_not1038 : ~ @Equation1038 Fin13 refa42_inst.
Proof. unfold Equation1038. intro H. specialize (H F13_0 F13_1). unfold magma_op, refa42_inst, refa42_op in H. discriminate H. Qed.

Lemma refa42_not1039 : ~ @Equation1039 Fin13 refa42_inst.
Proof. unfold Equation1039. intro H. specialize (H F13_0 F13_1). unfold magma_op, refa42_inst, refa42_op in H. discriminate H. Qed.

Lemma refa42_not1045 : ~ @Equation1045 Fin13 refa42_inst.
Proof. unfold Equation1045. intro H. specialize (H F13_0 F13_1). unfold magma_op, refa42_inst, refa42_op in H. discriminate H. Qed.

Lemma refa42_not1046 : ~ @Equation1046 Fin13 refa42_inst.
Proof. unfold Equation1046. intro H. specialize (H F13_0 F13_1). unfold magma_op, refa42_inst, refa42_op in H. discriminate H. Qed.

Lemma refa42_not1048 : ~ @Equation1048 Fin13 refa42_inst.
Proof. unfold Equation1048. intro H. specialize (H F13_0 F13_1). unfold magma_op, refa42_inst, refa42_op in H. discriminate H. Qed.

Lemma refa42_not1049 : ~ @Equation1049 Fin13 refa42_inst.
Proof. unfold Equation1049. intro H. specialize (H F13_0 F13_1). unfold magma_op, refa42_inst, refa42_op in H. discriminate H. Qed.

Lemma refa42_not1075 : ~ @Equation1075 Fin13 refa42_inst.
Proof. unfold Equation1075. intro H. specialize (H F13_0 F13_1). unfold magma_op, refa42_inst, refa42_op in H. discriminate H. Qed.

Lemma refa42_not1082 : ~ @Equation1082 Fin13 refa42_inst.
Proof. unfold Equation1082. intro H. specialize (H F13_0 F13_1). unfold magma_op, refa42_inst, refa42_op in H. discriminate H. Qed.

Lemma refa42_not1085 : ~ @Equation1085 Fin13 refa42_inst.
Proof. unfold Equation1085. intro H. specialize (H F13_0 F13_1). unfold magma_op, refa42_inst, refa42_op in H. discriminate H. Qed.

Lemma refa42_not1086 : ~ @Equation1086 Fin13 refa42_inst.
Proof. unfold Equation1086. intro H. specialize (H F13_0 F13_1). unfold magma_op, refa42_inst, refa42_op in H. discriminate H. Qed.

Lemma refa42_not1109 : ~ @Equation1109 Fin13 refa42_inst.
Proof. unfold Equation1109. intro H. specialize (H F13_0 F13_1). unfold magma_op, refa42_inst, refa42_op in H. discriminate H. Qed.

Lemma refa42_not1110 : ~ @Equation1110 Fin13 refa42_inst.
Proof. unfold Equation1110. intro H. specialize (H F13_0 F13_1). unfold magma_op, refa42_inst, refa42_op in H. discriminate H. Qed.

Lemma refa42_not1112 : ~ @Equation1112 Fin13 refa42_inst.
Proof. unfold Equation1112. intro H. specialize (H F13_0 F13_1). unfold magma_op, refa42_inst, refa42_op in H. discriminate H. Qed.

Lemma refa42_not1113 : ~ @Equation1113 Fin13 refa42_inst.
Proof. unfold Equation1113. intro H. specialize (H F13_0 F13_1). unfold magma_op, refa42_inst, refa42_op in H. discriminate H. Qed.

Lemma refa42_not1119 : ~ @Equation1119 Fin13 refa42_inst.
Proof. unfold Equation1119. intro H. specialize (H F13_0 F13_1). unfold magma_op, refa42_inst, refa42_op in H. discriminate H. Qed.

Lemma refa42_not1122 : ~ @Equation1122 Fin13 refa42_inst.
Proof. unfold Equation1122. intro H. specialize (H F13_0 F13_1). unfold magma_op, refa42_inst, refa42_op in H. discriminate H. Qed.

Lemma refa42_not1224 : ~ @Equation1224 Fin13 refa42_inst.
Proof. unfold Equation1224. intro H. specialize (H F13_0 F13_1). unfold magma_op, refa42_inst, refa42_op in H. discriminate H. Qed.

Lemma refa42_not1225 : ~ @Equation1225 Fin13 refa42_inst.
Proof. unfold Equation1225. intro H. specialize (H F13_0 F13_1). unfold magma_op, refa42_inst, refa42_op in H. discriminate H. Qed.

Lemma refa42_not1226 : ~ @Equation1226 Fin13 refa42_inst.
Proof. unfold Equation1226. intro H. specialize (H F13_0 F13_1). unfold magma_op, refa42_inst, refa42_op in H. discriminate H. Qed.

Lemma refa42_not1228 : ~ @Equation1228 Fin13 refa42_inst.
Proof. unfold Equation1228. intro H. specialize (H F13_0 F13_1). unfold magma_op, refa42_inst, refa42_op in H. discriminate H. Qed.

Lemma refa42_not1229 : ~ @Equation1229 Fin13 refa42_inst.
Proof. unfold Equation1229. intro H. specialize (H F13_0 F13_1). unfold magma_op, refa42_inst, refa42_op in H. discriminate H. Qed.

Lemma refa42_not1231 : ~ @Equation1231 Fin13 refa42_inst.
Proof. unfold Equation1231. intro H. specialize (H F13_0 F13_1). unfold magma_op, refa42_inst, refa42_op in H. discriminate H. Qed.

Lemma refa42_not1232 : ~ @Equation1232 Fin13 refa42_inst.
Proof. unfold Equation1232. intro H. specialize (H F13_0 F13_1). unfold magma_op, refa42_inst, refa42_op in H. discriminate H. Qed.

Lemma refa42_not1238 : ~ @Equation1238 Fin13 refa42_inst.
Proof. unfold Equation1238. intro H. specialize (H F13_0 F13_1). unfold magma_op, refa42_inst, refa42_op in H. discriminate H. Qed.

Lemma refa42_not1239 : ~ @Equation1239 Fin13 refa42_inst.
Proof. unfold Equation1239. intro H. specialize (H F13_0 F13_1). unfold magma_op, refa42_inst, refa42_op in H. discriminate H. Qed.

Lemma refa42_not1241 : ~ @Equation1241 Fin13 refa42_inst.
Proof. unfold Equation1241. intro H. specialize (H F13_0 F13_1). unfold magma_op, refa42_inst, refa42_op in H. discriminate H. Qed.

Lemma refa42_not1242 : ~ @Equation1242 Fin13 refa42_inst.
Proof. unfold Equation1242. intro H. specialize (H F13_0 F13_1). unfold magma_op, refa42_inst, refa42_op in H. discriminate H. Qed.

Lemma refa42_not1248 : ~ @Equation1248 Fin13 refa42_inst.
Proof. unfold Equation1248. intro H. specialize (H F13_0 F13_1). unfold magma_op, refa42_inst, refa42_op in H. discriminate H. Qed.

Lemma refa42_not1249 : ~ @Equation1249 Fin13 refa42_inst.
Proof. unfold Equation1249. intro H. specialize (H F13_0 F13_1). unfold magma_op, refa42_inst, refa42_op in H. discriminate H. Qed.

Lemma refa42_not1251 : ~ @Equation1251 Fin13 refa42_inst.
Proof. unfold Equation1251. intro H. specialize (H F13_0 F13_1). unfold magma_op, refa42_inst, refa42_op in H. discriminate H. Qed.

Lemma refa42_not1252 : ~ @Equation1252 Fin13 refa42_inst.
Proof. unfold Equation1252. intro H. specialize (H F13_0 F13_1). unfold magma_op, refa42_inst, refa42_op in H. discriminate H. Qed.

Lemma refa42_not1276 : ~ @Equation1276 Fin13 refa42_inst.
Proof. unfold Equation1276. intro H. specialize (H F13_0 F13_1). unfold magma_op, refa42_inst, refa42_op in H. discriminate H. Qed.

Lemma refa42_not1278 : ~ @Equation1278 Fin13 refa42_inst.
Proof. unfold Equation1278. intro H. specialize (H F13_0 F13_1). unfold magma_op, refa42_inst, refa42_op in H. discriminate H. Qed.

Lemma refa42_not1279 : ~ @Equation1279 Fin13 refa42_inst.
Proof. unfold Equation1279. intro H. specialize (H F13_0 F13_1). unfold magma_op, refa42_inst, refa42_op in H. discriminate H. Qed.

Lemma refa42_not1285 : ~ @Equation1285 Fin13 refa42_inst.
Proof. unfold Equation1285. intro H. specialize (H F13_0 F13_1). unfold magma_op, refa42_inst, refa42_op in H. discriminate H. Qed.

Lemma refa42_not1288 : ~ @Equation1288 Fin13 refa42_inst.
Proof. unfold Equation1288. intro H. specialize (H F13_0 F13_1). unfold magma_op, refa42_inst, refa42_op in H. discriminate H. Qed.

Lemma refa42_not1289 : ~ @Equation1289 Fin13 refa42_inst.
Proof. unfold Equation1289. intro H. specialize (H F13_0 F13_1). unfold magma_op, refa42_inst, refa42_op in H. discriminate H. Qed.

Lemma refa42_not1312 : ~ @Equation1312 Fin13 refa42_inst.
Proof. unfold Equation1312. intro H. specialize (H F13_0 F13_1). unfold magma_op, refa42_inst, refa42_op in H. discriminate H. Qed.

Lemma refa42_not1315 : ~ @Equation1315 Fin13 refa42_inst.
Proof. unfold Equation1315. intro H. specialize (H F13_0 F13_1). unfold magma_op, refa42_inst, refa42_op in H. discriminate H. Qed.

Lemma refa42_not1322 : ~ @Equation1322 Fin13 refa42_inst.
Proof. unfold Equation1322. intro H. specialize (H F13_0 F13_1). unfold magma_op, refa42_inst, refa42_op in H. discriminate H. Qed.

Lemma refa42_not1325 : ~ @Equation1325 Fin13 refa42_inst.
Proof. unfold Equation1325. intro H. specialize (H F13_0 F13_1). unfold magma_op, refa42_inst, refa42_op in H. discriminate H. Qed.

Lemma refa42_not1427 : ~ @Equation1427 Fin13 refa42_inst.
Proof. unfold Equation1427. intro H. specialize (H F13_0 F13_1). unfold magma_op, refa42_inst, refa42_op in H. discriminate H. Qed.

Lemma refa42_not1428 : ~ @Equation1428 Fin13 refa42_inst.
Proof. unfold Equation1428. intro H. specialize (H F13_0 F13_1). unfold magma_op, refa42_inst, refa42_op in H. discriminate H. Qed.

Lemma refa42_not1429 : ~ @Equation1429 Fin13 refa42_inst.
Proof. unfold Equation1429. intro H. specialize (H F13_0 F13_1). unfold magma_op, refa42_inst, refa42_op in H. discriminate H. Qed.

Lemma refa42_not1431 : ~ @Equation1431 Fin13 refa42_inst.
Proof. unfold Equation1431. intro H. specialize (H F13_0 F13_1). unfold magma_op, refa42_inst, refa42_op in H. discriminate H. Qed.

Lemma refa42_not1432 : ~ @Equation1432 Fin13 refa42_inst.
Proof. unfold Equation1432. intro H. specialize (H F13_0 F13_1). unfold magma_op, refa42_inst, refa42_op in H. discriminate H. Qed.

Lemma refa42_not1434 : ~ @Equation1434 Fin13 refa42_inst.
Proof. unfold Equation1434. intro H. specialize (H F13_0 F13_1). unfold magma_op, refa42_inst, refa42_op in H. discriminate H. Qed.

Lemma refa42_not1435 : ~ @Equation1435 Fin13 refa42_inst.
Proof. unfold Equation1435. intro H. specialize (H F13_0 F13_1). unfold magma_op, refa42_inst, refa42_op in H. discriminate H. Qed.

Lemma refa42_not1441 : ~ @Equation1441 Fin13 refa42_inst.
Proof. unfold Equation1441. intro H. specialize (H F13_0 F13_1). unfold magma_op, refa42_inst, refa42_op in H. discriminate H. Qed.

Lemma refa42_not1444 : ~ @Equation1444 Fin13 refa42_inst.
Proof. unfold Equation1444. intro H. specialize (H F13_0 F13_1). unfold magma_op, refa42_inst, refa42_op in H. discriminate H. Qed.

Lemma refa42_not1445 : ~ @Equation1445 Fin13 refa42_inst.
Proof. unfold Equation1445. intro H. specialize (H F13_0 F13_1). unfold magma_op, refa42_inst, refa42_op in H. discriminate H. Qed.

Lemma refa42_not1451 : ~ @Equation1451 Fin13 refa42_inst.
Proof. unfold Equation1451. intro H. specialize (H F13_0 F13_1). unfold magma_op, refa42_inst, refa42_op in H. discriminate H. Qed.

Lemma refa42_not1454 : ~ @Equation1454 Fin13 refa42_inst.
Proof. unfold Equation1454. intro H. specialize (H F13_0 F13_1). unfold magma_op, refa42_inst, refa42_op in H. discriminate H. Qed.

Lemma refa42_not1455 : ~ @Equation1455 Fin13 refa42_inst.
Proof. unfold Equation1455. intro H. specialize (H F13_0 F13_1). unfold magma_op, refa42_inst, refa42_op in H. discriminate H. Qed.

Lemma refa42_not1478 : ~ @Equation1478 Fin13 refa42_inst.
Proof. unfold Equation1478. intro H. specialize (H F13_0 F13_1). unfold magma_op, refa42_inst, refa42_op in H. discriminate H. Qed.

Lemma refa42_not1479 : ~ @Equation1479 Fin13 refa42_inst.
Proof. unfold Equation1479. intro H. specialize (H F13_0 F13_1). unfold magma_op, refa42_inst, refa42_op in H. discriminate H. Qed.

Lemma refa42_not1482 : ~ @Equation1482 Fin13 refa42_inst.
Proof. unfold Equation1482. intro H. specialize (H F13_0 F13_1). unfold magma_op, refa42_inst, refa42_op in H. discriminate H. Qed.

Lemma refa42_not1488 : ~ @Equation1488 Fin13 refa42_inst.
Proof. unfold Equation1488. intro H. specialize (H F13_0 F13_1). unfold magma_op, refa42_inst, refa42_op in H. discriminate H. Qed.

Lemma refa42_not1489 : ~ @Equation1489 Fin13 refa42_inst.
Proof. unfold Equation1489. intro H. specialize (H F13_0 F13_1). unfold magma_op, refa42_inst, refa42_op in H. discriminate H. Qed.

Lemma refa42_not1491 : ~ @Equation1491 Fin13 refa42_inst.
Proof. unfold Equation1491. intro H. specialize (H F13_0 F13_1). unfold magma_op, refa42_inst, refa42_op in H. discriminate H. Qed.

Lemma refa42_not1515 : ~ @Equation1515 Fin13 refa42_inst.
Proof. unfold Equation1515. intro H. specialize (H F13_0 F13_1). unfold magma_op, refa42_inst, refa42_op in H. discriminate H. Qed.

Lemma refa42_not1516 : ~ @Equation1516 Fin13 refa42_inst.
Proof. unfold Equation1516. intro H. specialize (H F13_0 F13_1). unfold magma_op, refa42_inst, refa42_op in H. discriminate H. Qed.

Lemma refa42_not1518 : ~ @Equation1518 Fin13 refa42_inst.
Proof. unfold Equation1518. intro H. specialize (H F13_0 F13_1). unfold magma_op, refa42_inst, refa42_op in H. discriminate H. Qed.

Lemma refa42_not1519 : ~ @Equation1519 Fin13 refa42_inst.
Proof. unfold Equation1519. intro H. specialize (H F13_0 F13_1). unfold magma_op, refa42_inst, refa42_op in H. discriminate H. Qed.

Lemma refa42_not1525 : ~ @Equation1525 Fin13 refa42_inst.
Proof. unfold Equation1525. intro H. specialize (H F13_0 F13_1). unfold magma_op, refa42_inst, refa42_op in H. discriminate H. Qed.

Lemma refa42_not1526 : ~ @Equation1526 Fin13 refa42_inst.
Proof. unfold Equation1526. intro H. specialize (H F13_0 F13_1). unfold magma_op, refa42_inst, refa42_op in H. discriminate H. Qed.

Lemma refa42_not1630 : ~ @Equation1630 Fin13 refa42_inst.
Proof. unfold Equation1630. intro H. specialize (H F13_0 F13_1). unfold magma_op, refa42_inst, refa42_op in H. discriminate H. Qed.

Lemma refa42_not1631 : ~ @Equation1631 Fin13 refa42_inst.
Proof. unfold Equation1631. intro H. specialize (H F13_0 F13_1). unfold magma_op, refa42_inst, refa42_op in H. discriminate H. Qed.

Lemma refa42_not1632 : ~ @Equation1632 Fin13 refa42_inst.
Proof. unfold Equation1632. intro H. specialize (H F13_0 F13_1). unfold magma_op, refa42_inst, refa42_op in H. discriminate H. Qed.

Lemma refa42_not1634 : ~ @Equation1634 Fin13 refa42_inst.
Proof. unfold Equation1634. intro H. specialize (H F13_0 F13_1). unfold magma_op, refa42_inst, refa42_op in H. discriminate H. Qed.

Lemma refa42_not1635 : ~ @Equation1635 Fin13 refa42_inst.
Proof. unfold Equation1635. intro H. specialize (H F13_0 F13_1). unfold magma_op, refa42_inst, refa42_op in H. discriminate H. Qed.

Lemma refa42_not1637 : ~ @Equation1637 Fin13 refa42_inst.
Proof. unfold Equation1637. intro H. specialize (H F13_0 F13_1). unfold magma_op, refa42_inst, refa42_op in H. discriminate H. Qed.

Lemma refa42_not1638 : ~ @Equation1638 Fin13 refa42_inst.
Proof. unfold Equation1638. intro H. specialize (H F13_0 F13_1). unfold magma_op, refa42_inst, refa42_op in H. discriminate H. Qed.

Lemma refa42_not1644 : ~ @Equation1644 Fin13 refa42_inst.
Proof. unfold Equation1644. intro H. specialize (H F13_0 F13_1). unfold magma_op, refa42_inst, refa42_op in H. discriminate H. Qed.

Lemma refa42_not1645 : ~ @Equation1645 Fin13 refa42_inst.
Proof. unfold Equation1645. intro H. specialize (H F13_0 F13_1). unfold magma_op, refa42_inst, refa42_op in H. discriminate H. Qed.

Lemma refa42_not1648 : ~ @Equation1648 Fin13 refa42_inst.
Proof. unfold Equation1648. intro H. specialize (H F13_0 F13_1). unfold magma_op, refa42_inst, refa42_op in H. discriminate H. Qed.

Lemma refa42_not1654 : ~ @Equation1654 Fin13 refa42_inst.
Proof. unfold Equation1654. intro H. specialize (H F13_0 F13_1). unfold magma_op, refa42_inst, refa42_op in H. discriminate H. Qed.

Lemma refa42_not1655 : ~ @Equation1655 Fin13 refa42_inst.
Proof. unfold Equation1655. intro H. specialize (H F13_0 F13_1). unfold magma_op, refa42_inst, refa42_op in H. discriminate H. Qed.

Lemma refa42_not1657 : ~ @Equation1657 Fin13 refa42_inst.
Proof. unfold Equation1657. intro H. specialize (H F13_0 F13_1). unfold magma_op, refa42_inst, refa42_op in H. discriminate H. Qed.

Lemma refa42_not1658 : ~ @Equation1658 Fin13 refa42_inst.
Proof. unfold Equation1658. intro H. specialize (H F13_0 F13_1). unfold magma_op, refa42_inst, refa42_op in H. discriminate H. Qed.

Lemma refa42_not1681 : ~ @Equation1681 Fin13 refa42_inst.
Proof. unfold Equation1681. intro H. specialize (H F13_0 F13_1). unfold magma_op, refa42_inst, refa42_op in H. discriminate H. Qed.

Lemma refa42_not1682 : ~ @Equation1682 Fin13 refa42_inst.
Proof. unfold Equation1682. intro H. specialize (H F13_0 F13_1). unfold magma_op, refa42_inst, refa42_op in H. discriminate H. Qed.

Lemma refa42_not1684 : ~ @Equation1684 Fin13 refa42_inst.
Proof. unfold Equation1684. intro H. specialize (H F13_0 F13_1). unfold magma_op, refa42_inst, refa42_op in H. discriminate H. Qed.

Lemma refa42_not1685 : ~ @Equation1685 Fin13 refa42_inst.
Proof. unfold Equation1685. intro H. specialize (H F13_0 F13_1). unfold magma_op, refa42_inst, refa42_op in H. discriminate H. Qed.

Lemma refa42_not1691 : ~ @Equation1691 Fin13 refa42_inst.
Proof. unfold Equation1691. intro H. specialize (H F13_0 F13_1). unfold magma_op, refa42_inst, refa42_op in H. discriminate H. Qed.

Lemma refa42_not1692 : ~ @Equation1692 Fin13 refa42_inst.
Proof. unfold Equation1692. intro H. specialize (H F13_0 F13_1). unfold magma_op, refa42_inst, refa42_op in H. discriminate H. Qed.

Lemma refa42_not1694 : ~ @Equation1694 Fin13 refa42_inst.
Proof. unfold Equation1694. intro H. specialize (H F13_0 F13_1). unfold magma_op, refa42_inst, refa42_op in H. discriminate H. Qed.

Lemma refa42_not1719 : ~ @Equation1719 Fin13 refa42_inst.
Proof. unfold Equation1719. intro H. specialize (H F13_0 F13_1). unfold magma_op, refa42_inst, refa42_op in H. discriminate H. Qed.

Lemma refa42_not1721 : ~ @Equation1721 Fin13 refa42_inst.
Proof. unfold Equation1721. intro H. specialize (H F13_0 F13_1). unfold magma_op, refa42_inst, refa42_op in H. discriminate H. Qed.

Lemma refa42_not1722 : ~ @Equation1722 Fin13 refa42_inst.
Proof. unfold Equation1722. intro H. specialize (H F13_0 F13_1). unfold magma_op, refa42_inst, refa42_op in H. discriminate H. Qed.

Lemma refa42_not1728 : ~ @Equation1728 Fin13 refa42_inst.
Proof. unfold Equation1728. intro H. specialize (H F13_0 F13_1). unfold magma_op, refa42_inst, refa42_op in H. discriminate H. Qed.

Lemma refa42_not1731 : ~ @Equation1731 Fin13 refa42_inst.
Proof. unfold Equation1731. intro H. specialize (H F13_0 F13_1). unfold magma_op, refa42_inst, refa42_op in H. discriminate H. Qed.

Lemma refa42_not1833 : ~ @Equation1833 Fin13 refa42_inst.
Proof. unfold Equation1833. intro H. specialize (H F13_0 F13_1). unfold magma_op, refa42_inst, refa42_op in H. discriminate H. Qed.

Lemma refa42_not1834 : ~ @Equation1834 Fin13 refa42_inst.
Proof. unfold Equation1834. intro H. specialize (H F13_0 F13_1). unfold magma_op, refa42_inst, refa42_op in H. discriminate H. Qed.

Lemma refa42_not1837 : ~ @Equation1837 Fin13 refa42_inst.
Proof. unfold Equation1837. intro H. specialize (H F13_0 F13_1). unfold magma_op, refa42_inst, refa42_op in H. discriminate H. Qed.

Lemma refa42_not1838 : ~ @Equation1838 Fin13 refa42_inst.
Proof. unfold Equation1838. intro H. specialize (H F13_0 F13_1). unfold magma_op, refa42_inst, refa42_op in H. discriminate H. Qed.

Lemma refa42_not1840 : ~ @Equation1840 Fin13 refa42_inst.
Proof. unfold Equation1840. intro H. specialize (H F13_0 F13_1). unfold magma_op, refa42_inst, refa42_op in H. discriminate H. Qed.

Lemma refa42_not1841 : ~ @Equation1841 Fin13 refa42_inst.
Proof. unfold Equation1841. intro H. specialize (H F13_0 F13_1). unfold magma_op, refa42_inst, refa42_op in H. discriminate H. Qed.

Lemma refa42_not1847 : ~ @Equation1847 Fin13 refa42_inst.
Proof. unfold Equation1847. intro H. specialize (H F13_0 F13_1). unfold magma_op, refa42_inst, refa42_op in H. discriminate H. Qed.

Lemma refa42_not1848 : ~ @Equation1848 Fin13 refa42_inst.
Proof. unfold Equation1848. intro H. specialize (H F13_0 F13_1). unfold magma_op, refa42_inst, refa42_op in H. discriminate H. Qed.

Lemma refa42_not1851 : ~ @Equation1851 Fin13 refa42_inst.
Proof. unfold Equation1851. intro H. specialize (H F13_0 F13_1). unfold magma_op, refa42_inst, refa42_op in H. discriminate H. Qed.

Lemma refa42_not1857 : ~ @Equation1857 Fin13 refa42_inst.
Proof. unfold Equation1857. intro H. specialize (H F13_0 F13_1). unfold magma_op, refa42_inst, refa42_op in H. discriminate H. Qed.

Lemma refa42_not1858 : ~ @Equation1858 Fin13 refa42_inst.
Proof. unfold Equation1858. intro H. specialize (H F13_0 F13_1). unfold magma_op, refa42_inst, refa42_op in H. discriminate H. Qed.

Lemma refa42_not1860 : ~ @Equation1860 Fin13 refa42_inst.
Proof. unfold Equation1860. intro H. specialize (H F13_0 F13_1). unfold magma_op, refa42_inst, refa42_op in H. discriminate H. Qed.

Lemma refa42_not1861 : ~ @Equation1861 Fin13 refa42_inst.
Proof. unfold Equation1861. intro H. specialize (H F13_0 F13_1). unfold magma_op, refa42_inst, refa42_op in H. discriminate H. Qed.

Lemma refa42_not1884 : ~ @Equation1884 Fin13 refa42_inst.
Proof. unfold Equation1884. intro H. specialize (H F13_0 F13_1). unfold magma_op, refa42_inst, refa42_op in H. discriminate H. Qed.

Lemma refa42_not1885 : ~ @Equation1885 Fin13 refa42_inst.
Proof. unfold Equation1885. intro H. specialize (H F13_0 F13_1). unfold magma_op, refa42_inst, refa42_op in H. discriminate H. Qed.

Lemma refa42_not1887 : ~ @Equation1887 Fin13 refa42_inst.
Proof. unfold Equation1887. intro H. specialize (H F13_0 F13_1). unfold magma_op, refa42_inst, refa42_op in H. discriminate H. Qed.

Lemma refa42_not1888 : ~ @Equation1888 Fin13 refa42_inst.
Proof. unfold Equation1888. intro H. specialize (H F13_0 F13_1). unfold magma_op, refa42_inst, refa42_op in H. discriminate H. Qed.

Lemma refa42_not1894 : ~ @Equation1894 Fin13 refa42_inst.
Proof. unfold Equation1894. intro H. specialize (H F13_0 F13_1). unfold magma_op, refa42_inst, refa42_op in H. discriminate H. Qed.

Lemma refa42_not1895 : ~ @Equation1895 Fin13 refa42_inst.
Proof. unfold Equation1895. intro H. specialize (H F13_0 F13_1). unfold magma_op, refa42_inst, refa42_op in H. discriminate H. Qed.

Lemma refa42_not1897 : ~ @Equation1897 Fin13 refa42_inst.
Proof. unfold Equation1897. intro H. specialize (H F13_0 F13_1). unfold magma_op, refa42_inst, refa42_op in H. discriminate H. Qed.

Lemma refa42_not1921 : ~ @Equation1921 Fin13 refa42_inst.
Proof. unfold Equation1921. intro H. specialize (H F13_0 F13_1). unfold magma_op, refa42_inst, refa42_op in H. discriminate H. Qed.

Lemma refa42_not1922 : ~ @Equation1922 Fin13 refa42_inst.
Proof. unfold Equation1922. intro H. specialize (H F13_0 F13_1). unfold magma_op, refa42_inst, refa42_op in H. discriminate H. Qed.

Lemma refa42_not1924 : ~ @Equation1924 Fin13 refa42_inst.
Proof. unfold Equation1924. intro H. specialize (H F13_0 F13_1). unfold magma_op, refa42_inst, refa42_op in H. discriminate H. Qed.

Lemma refa42_not1925 : ~ @Equation1925 Fin13 refa42_inst.
Proof. unfold Equation1925. intro H. specialize (H F13_0 F13_1). unfold magma_op, refa42_inst, refa42_op in H. discriminate H. Qed.

Lemma refa42_not1931 : ~ @Equation1931 Fin13 refa42_inst.
Proof. unfold Equation1931. intro H. specialize (H F13_0 F13_1). unfold magma_op, refa42_inst, refa42_op in H. discriminate H. Qed.

Lemma refa42_not2036 : ~ @Equation2036 Fin13 refa42_inst.
Proof. unfold Equation2036. intro H. specialize (H F13_0 F13_1). unfold magma_op, refa42_inst, refa42_op in H. discriminate H. Qed.

Lemma refa42_not2037 : ~ @Equation2037 Fin13 refa42_inst.
Proof. unfold Equation2037. intro H. specialize (H F13_0 F13_1). unfold magma_op, refa42_inst, refa42_op in H. discriminate H. Qed.

Lemma refa42_not2038 : ~ @Equation2038 Fin13 refa42_inst.
Proof. unfold Equation2038. intro H. specialize (H F13_0 F13_1). unfold magma_op, refa42_inst, refa42_op in H. discriminate H. Qed.

Lemma refa42_not2040 : ~ @Equation2040 Fin13 refa42_inst.
Proof. unfold Equation2040. intro H. specialize (H F13_0 F13_1). unfold magma_op, refa42_inst, refa42_op in H. discriminate H. Qed.

Lemma refa42_not2041 : ~ @Equation2041 Fin13 refa42_inst.
Proof. unfold Equation2041. intro H. specialize (H F13_0 F13_1). unfold magma_op, refa42_inst, refa42_op in H. discriminate H. Qed.

Lemma refa42_not2043 : ~ @Equation2043 Fin13 refa42_inst.
Proof. unfold Equation2043. intro H. specialize (H F13_0 F13_1). unfold magma_op, refa42_inst, refa42_op in H. discriminate H. Qed.

Lemma refa42_not2044 : ~ @Equation2044 Fin13 refa42_inst.
Proof. unfold Equation2044. intro H. specialize (H F13_0 F13_1). unfold magma_op, refa42_inst, refa42_op in H. discriminate H. Qed.

Lemma refa42_not2050 : ~ @Equation2050 Fin13 refa42_inst.
Proof. unfold Equation2050. intro H. specialize (H F13_0 F13_1). unfold magma_op, refa42_inst, refa42_op in H. discriminate H. Qed.

Lemma refa42_not2053 : ~ @Equation2053 Fin13 refa42_inst.
Proof. unfold Equation2053. intro H. specialize (H F13_0 F13_1). unfold magma_op, refa42_inst, refa42_op in H. discriminate H. Qed.

Lemma refa42_not2054 : ~ @Equation2054 Fin13 refa42_inst.
Proof. unfold Equation2054. intro H. specialize (H F13_0 F13_1). unfold magma_op, refa42_inst, refa42_op in H. discriminate H. Qed.

Lemma refa42_not2060 : ~ @Equation2060 Fin13 refa42_inst.
Proof. unfold Equation2060. intro H. specialize (H F13_0 F13_1). unfold magma_op, refa42_inst, refa42_op in H. discriminate H. Qed.

Lemma refa42_not2061 : ~ @Equation2061 Fin13 refa42_inst.
Proof. unfold Equation2061. intro H. specialize (H F13_0 F13_1). unfold magma_op, refa42_inst, refa42_op in H. discriminate H. Qed.

Lemma refa42_not2063 : ~ @Equation2063 Fin13 refa42_inst.
Proof. unfold Equation2063. intro H. specialize (H F13_0 F13_1). unfold magma_op, refa42_inst, refa42_op in H. discriminate H. Qed.

Lemma refa42_not2064 : ~ @Equation2064 Fin13 refa42_inst.
Proof. unfold Equation2064. intro H. specialize (H F13_0 F13_1). unfold magma_op, refa42_inst, refa42_op in H. discriminate H. Qed.

Lemma refa42_not2087 : ~ @Equation2087 Fin13 refa42_inst.
Proof. unfold Equation2087. intro H. specialize (H F13_0 F13_1). unfold magma_op, refa42_inst, refa42_op in H. discriminate H. Qed.

Lemma refa42_not2088 : ~ @Equation2088 Fin13 refa42_inst.
Proof. unfold Equation2088. intro H. specialize (H F13_0 F13_1). unfold magma_op, refa42_inst, refa42_op in H. discriminate H. Qed.

Lemma refa42_not2091 : ~ @Equation2091 Fin13 refa42_inst.
Proof. unfold Equation2091. intro H. specialize (H F13_0 F13_1). unfold magma_op, refa42_inst, refa42_op in H. discriminate H. Qed.

Lemma refa42_not2097 : ~ @Equation2097 Fin13 refa42_inst.
Proof. unfold Equation2097. intro H. specialize (H F13_0 F13_1). unfold magma_op, refa42_inst, refa42_op in H. discriminate H. Qed.

Lemma refa42_not2098 : ~ @Equation2098 Fin13 refa42_inst.
Proof. unfold Equation2098. intro H. specialize (H F13_0 F13_1). unfold magma_op, refa42_inst, refa42_op in H. discriminate H. Qed.

Lemma refa42_not2101 : ~ @Equation2101 Fin13 refa42_inst.
Proof. unfold Equation2101. intro H. specialize (H F13_0 F13_1). unfold magma_op, refa42_inst, refa42_op in H. discriminate H. Qed.

Lemma refa42_not2124 : ~ @Equation2124 Fin13 refa42_inst.
Proof. unfold Equation2124. intro H. specialize (H F13_0 F13_1). unfold magma_op, refa42_inst, refa42_op in H. discriminate H. Qed.

Lemma refa42_not2125 : ~ @Equation2125 Fin13 refa42_inst.
Proof. unfold Equation2125. intro H. specialize (H F13_0 F13_1). unfold magma_op, refa42_inst, refa42_op in H. discriminate H. Qed.

Lemma refa42_not2127 : ~ @Equation2127 Fin13 refa42_inst.
Proof. unfold Equation2127. intro H. specialize (H F13_0 F13_1). unfold magma_op, refa42_inst, refa42_op in H. discriminate H. Qed.

Lemma refa42_not2128 : ~ @Equation2128 Fin13 refa42_inst.
Proof. unfold Equation2128. intro H. specialize (H F13_0 F13_1). unfold magma_op, refa42_inst, refa42_op in H. discriminate H. Qed.

Lemma refa42_not2134 : ~ @Equation2134 Fin13 refa42_inst.
Proof. unfold Equation2134. intro H. specialize (H F13_0 F13_1). unfold magma_op, refa42_inst, refa42_op in H. discriminate H. Qed.

Lemma refa42_not2240 : ~ @Equation2240 Fin13 refa42_inst.
Proof. unfold Equation2240. intro H. specialize (H F13_0 F13_1). unfold magma_op, refa42_inst, refa42_op in H. discriminate H. Qed.

Lemma refa42_not2241 : ~ @Equation2241 Fin13 refa42_inst.
Proof. unfold Equation2241. intro H. specialize (H F13_0 F13_1). unfold magma_op, refa42_inst, refa42_op in H. discriminate H. Qed.

Lemma refa42_not2243 : ~ @Equation2243 Fin13 refa42_inst.
Proof. unfold Equation2243. intro H. specialize (H F13_0 F13_1). unfold magma_op, refa42_inst, refa42_op in H. discriminate H. Qed.

Lemma refa42_not2244 : ~ @Equation2244 Fin13 refa42_inst.
Proof. unfold Equation2244. intro H. specialize (H F13_0 F13_1). unfold magma_op, refa42_inst, refa42_op in H. discriminate H. Qed.

Lemma refa42_not2246 : ~ @Equation2246 Fin13 refa42_inst.
Proof. unfold Equation2246. intro H. specialize (H F13_0 F13_1). unfold magma_op, refa42_inst, refa42_op in H. discriminate H. Qed.

Lemma refa42_not2247 : ~ @Equation2247 Fin13 refa42_inst.
Proof. unfold Equation2247. intro H. specialize (H F13_0 F13_1). unfold magma_op, refa42_inst, refa42_op in H. discriminate H. Qed.

Lemma refa42_not2253 : ~ @Equation2253 Fin13 refa42_inst.
Proof. unfold Equation2253. intro H. specialize (H F13_0 F13_1). unfold magma_op, refa42_inst, refa42_op in H. discriminate H. Qed.

Lemma refa42_not2254 : ~ @Equation2254 Fin13 refa42_inst.
Proof. unfold Equation2254. intro H. specialize (H F13_0 F13_1). unfold magma_op, refa42_inst, refa42_op in H. discriminate H. Qed.

Lemma refa42_not2256 : ~ @Equation2256 Fin13 refa42_inst.
Proof. unfold Equation2256. intro H. specialize (H F13_0 F13_1). unfold magma_op, refa42_inst, refa42_op in H. discriminate H. Qed.

Lemma refa42_not2257 : ~ @Equation2257 Fin13 refa42_inst.
Proof. unfold Equation2257. intro H. specialize (H F13_0 F13_1). unfold magma_op, refa42_inst, refa42_op in H. discriminate H. Qed.

Lemma refa42_not2263 : ~ @Equation2263 Fin13 refa42_inst.
Proof. unfold Equation2263. intro H. specialize (H F13_0 F13_1). unfold magma_op, refa42_inst, refa42_op in H. discriminate H. Qed.

Lemma refa42_not2264 : ~ @Equation2264 Fin13 refa42_inst.
Proof. unfold Equation2264. intro H. specialize (H F13_0 F13_1). unfold magma_op, refa42_inst, refa42_op in H. discriminate H. Qed.

Lemma refa42_not2266 : ~ @Equation2266 Fin13 refa42_inst.
Proof. unfold Equation2266. intro H. specialize (H F13_0 F13_1). unfold magma_op, refa42_inst, refa42_op in H. discriminate H. Qed.

Lemma refa42_not2290 : ~ @Equation2290 Fin13 refa42_inst.
Proof. unfold Equation2290. intro H. specialize (H F13_0 F13_1). unfold magma_op, refa42_inst, refa42_op in H. discriminate H. Qed.

Lemma refa42_not2291 : ~ @Equation2291 Fin13 refa42_inst.
Proof. unfold Equation2291. intro H. specialize (H F13_0 F13_1). unfold magma_op, refa42_inst, refa42_op in H. discriminate H. Qed.

Lemma refa42_not2293 : ~ @Equation2293 Fin13 refa42_inst.
Proof. unfold Equation2293. intro H. specialize (H F13_0 F13_1). unfold magma_op, refa42_inst, refa42_op in H. discriminate H. Qed.

Lemma refa42_not2300 : ~ @Equation2300 Fin13 refa42_inst.
Proof. unfold Equation2300. intro H. specialize (H F13_0 F13_1). unfold magma_op, refa42_inst, refa42_op in H. discriminate H. Qed.

Lemma refa42_not2303 : ~ @Equation2303 Fin13 refa42_inst.
Proof. unfold Equation2303. intro H. specialize (H F13_0 F13_1). unfold magma_op, refa42_inst, refa42_op in H. discriminate H. Qed.

Lemma refa42_not2327 : ~ @Equation2327 Fin13 refa42_inst.
Proof. unfold Equation2327. intro H. specialize (H F13_0 F13_1). unfold magma_op, refa42_inst, refa42_op in H. discriminate H. Qed.

Lemma refa42_not2328 : ~ @Equation2328 Fin13 refa42_inst.
Proof. unfold Equation2328. intro H. specialize (H F13_0 F13_1). unfold magma_op, refa42_inst, refa42_op in H. discriminate H. Qed.

Lemma refa42_not2330 : ~ @Equation2330 Fin13 refa42_inst.
Proof. unfold Equation2330. intro H. specialize (H F13_0 F13_1). unfold magma_op, refa42_inst, refa42_op in H. discriminate H. Qed.

Lemma refa42_not2337 : ~ @Equation2337 Fin13 refa42_inst.
Proof. unfold Equation2337. intro H. specialize (H F13_0 F13_1). unfold magma_op, refa42_inst, refa42_op in H. discriminate H. Qed.

Lemma refa42_not2338 : ~ @Equation2338 Fin13 refa42_inst.
Proof. unfold Equation2338. intro H. specialize (H F13_0 F13_1). unfold magma_op, refa42_inst, refa42_op in H. discriminate H. Qed.

Lemma refa42_not2340 : ~ @Equation2340 Fin13 refa42_inst.
Proof. unfold Equation2340. intro H. specialize (H F13_0 F13_1). unfold magma_op, refa42_inst, refa42_op in H. discriminate H. Qed.

Lemma refa42_not2443 : ~ @Equation2443 Fin13 refa42_inst.
Proof. unfold Equation2443. intro H. specialize (H F13_0 F13_1). unfold magma_op, refa42_inst, refa42_op in H. discriminate H. Qed.

Lemma refa42_not2444 : ~ @Equation2444 Fin13 refa42_inst.
Proof. unfold Equation2444. intro H. specialize (H F13_0 F13_1). unfold magma_op, refa42_inst, refa42_op in H. discriminate H. Qed.

Lemma refa42_not2446 : ~ @Equation2446 Fin13 refa42_inst.
Proof. unfold Equation2446. intro H. specialize (H F13_0 F13_1). unfold magma_op, refa42_inst, refa42_op in H. discriminate H. Qed.

Lemma refa42_not2447 : ~ @Equation2447 Fin13 refa42_inst.
Proof. unfold Equation2447. intro H. specialize (H F13_0 F13_1). unfold magma_op, refa42_inst, refa42_op in H. discriminate H. Qed.

Lemma refa42_not2449 : ~ @Equation2449 Fin13 refa42_inst.
Proof. unfold Equation2449. intro H. specialize (H F13_0 F13_1). unfold magma_op, refa42_inst, refa42_op in H. discriminate H. Qed.

Lemma refa42_not2450 : ~ @Equation2450 Fin13 refa42_inst.
Proof. unfold Equation2450. intro H. specialize (H F13_0 F13_1). unfold magma_op, refa42_inst, refa42_op in H. discriminate H. Qed.

Lemma refa42_not2456 : ~ @Equation2456 Fin13 refa42_inst.
Proof. unfold Equation2456. intro H. specialize (H F13_0 F13_1). unfold magma_op, refa42_inst, refa42_op in H. discriminate H. Qed.

Lemma refa42_not2457 : ~ @Equation2457 Fin13 refa42_inst.
Proof. unfold Equation2457. intro H. specialize (H F13_0 F13_1). unfold magma_op, refa42_inst, refa42_op in H. discriminate H. Qed.

Lemma refa42_not2459 : ~ @Equation2459 Fin13 refa42_inst.
Proof. unfold Equation2459. intro H. specialize (H F13_0 F13_1). unfold magma_op, refa42_inst, refa42_op in H. discriminate H. Qed.

Lemma refa42_not2460 : ~ @Equation2460 Fin13 refa42_inst.
Proof. unfold Equation2460. intro H. specialize (H F13_0 F13_1). unfold magma_op, refa42_inst, refa42_op in H. discriminate H. Qed.

Lemma refa42_not2466 : ~ @Equation2466 Fin13 refa42_inst.
Proof. unfold Equation2466. intro H. specialize (H F13_0 F13_1). unfold magma_op, refa42_inst, refa42_op in H. discriminate H. Qed.

Lemma refa42_not2467 : ~ @Equation2467 Fin13 refa42_inst.
Proof. unfold Equation2467. intro H. specialize (H F13_0 F13_1). unfold magma_op, refa42_inst, refa42_op in H. discriminate H. Qed.

Lemma refa42_not2469 : ~ @Equation2469 Fin13 refa42_inst.
Proof. unfold Equation2469. intro H. specialize (H F13_0 F13_1). unfold magma_op, refa42_inst, refa42_op in H. discriminate H. Qed.

Lemma refa42_not2493 : ~ @Equation2493 Fin13 refa42_inst.
Proof. unfold Equation2493. intro H. specialize (H F13_0 F13_1). unfold magma_op, refa42_inst, refa42_op in H. discriminate H. Qed.

Lemma refa42_not2496 : ~ @Equation2496 Fin13 refa42_inst.
Proof. unfold Equation2496. intro H. specialize (H F13_0 F13_1). unfold magma_op, refa42_inst, refa42_op in H. discriminate H. Qed.

Lemma refa42_not2497 : ~ @Equation2497 Fin13 refa42_inst.
Proof. unfold Equation2497. intro H. specialize (H F13_0 F13_1). unfold magma_op, refa42_inst, refa42_op in H. discriminate H. Qed.

Lemma refa42_not2503 : ~ @Equation2503 Fin13 refa42_inst.
Proof. unfold Equation2503. intro H. specialize (H F13_0 F13_1). unfold magma_op, refa42_inst, refa42_op in H. discriminate H. Qed.

Lemma refa42_not2506 : ~ @Equation2506 Fin13 refa42_inst.
Proof. unfold Equation2506. intro H. specialize (H F13_0 F13_1). unfold magma_op, refa42_inst, refa42_op in H. discriminate H. Qed.

Lemma refa42_not2530 : ~ @Equation2530 Fin13 refa42_inst.
Proof. unfold Equation2530. intro H. specialize (H F13_0 F13_1). unfold magma_op, refa42_inst, refa42_op in H. discriminate H. Qed.

Lemma refa42_not2533 : ~ @Equation2533 Fin13 refa42_inst.
Proof. unfold Equation2533. intro H. specialize (H F13_0 F13_1). unfold magma_op, refa42_inst, refa42_op in H. discriminate H. Qed.

Lemma refa42_not2534 : ~ @Equation2534 Fin13 refa42_inst.
Proof. unfold Equation2534. intro H. specialize (H F13_0 F13_1). unfold magma_op, refa42_inst, refa42_op in H. discriminate H. Qed.

Lemma refa42_not2540 : ~ @Equation2540 Fin13 refa42_inst.
Proof. unfold Equation2540. intro H. specialize (H F13_0 F13_1). unfold magma_op, refa42_inst, refa42_op in H. discriminate H. Qed.

Lemma refa42_not2541 : ~ @Equation2541 Fin13 refa42_inst.
Proof. unfold Equation2541. intro H. specialize (H F13_0 F13_1). unfold magma_op, refa42_inst, refa42_op in H. discriminate H. Qed.

Lemma refa42_not2543 : ~ @Equation2543 Fin13 refa42_inst.
Proof. unfold Equation2543. intro H. specialize (H F13_0 F13_1). unfold magma_op, refa42_inst, refa42_op in H. discriminate H. Qed.

Lemma refa42_not2646 : ~ @Equation2646 Fin13 refa42_inst.
Proof. unfold Equation2646. intro H. specialize (H F13_0 F13_1). unfold magma_op, refa42_inst, refa42_op in H. discriminate H. Qed.

Lemma refa42_not2647 : ~ @Equation2647 Fin13 refa42_inst.
Proof. unfold Equation2647. intro H. specialize (H F13_0 F13_1). unfold magma_op, refa42_inst, refa42_op in H. discriminate H. Qed.

Lemma refa42_not2649 : ~ @Equation2649 Fin13 refa42_inst.
Proof. unfold Equation2649. intro H. specialize (H F13_0 F13_1). unfold magma_op, refa42_inst, refa42_op in H. discriminate H. Qed.

Lemma refa42_not2650 : ~ @Equation2650 Fin13 refa42_inst.
Proof. unfold Equation2650. intro H. specialize (H F13_0 F13_1). unfold magma_op, refa42_inst, refa42_op in H. discriminate H. Qed.

Lemma refa42_not2652 : ~ @Equation2652 Fin13 refa42_inst.
Proof. unfold Equation2652. intro H. specialize (H F13_0 F13_1). unfold magma_op, refa42_inst, refa42_op in H. discriminate H. Qed.

Lemma refa42_not2659 : ~ @Equation2659 Fin13 refa42_inst.
Proof. unfold Equation2659. intro H. specialize (H F13_0 F13_1). unfold magma_op, refa42_inst, refa42_op in H. discriminate H. Qed.

Lemma refa42_not2660 : ~ @Equation2660 Fin13 refa42_inst.
Proof. unfold Equation2660. intro H. specialize (H F13_0 F13_1). unfold magma_op, refa42_inst, refa42_op in H. discriminate H. Qed.

Lemma refa42_not2662 : ~ @Equation2662 Fin13 refa42_inst.
Proof. unfold Equation2662. intro H. specialize (H F13_0 F13_1). unfold magma_op, refa42_inst, refa42_op in H. discriminate H. Qed.

Lemma refa42_not2669 : ~ @Equation2669 Fin13 refa42_inst.
Proof. unfold Equation2669. intro H. specialize (H F13_0 F13_1). unfold magma_op, refa42_inst, refa42_op in H. discriminate H. Qed.

Lemma refa42_not2670 : ~ @Equation2670 Fin13 refa42_inst.
Proof. unfold Equation2670. intro H. specialize (H F13_0 F13_1). unfold magma_op, refa42_inst, refa42_op in H. discriminate H. Qed.

Lemma refa42_not2672 : ~ @Equation2672 Fin13 refa42_inst.
Proof. unfold Equation2672. intro H. specialize (H F13_0 F13_1). unfold magma_op, refa42_inst, refa42_op in H. discriminate H. Qed.

Lemma refa42_not2696 : ~ @Equation2696 Fin13 refa42_inst.
Proof. unfold Equation2696. intro H. specialize (H F13_0 F13_1). unfold magma_op, refa42_inst, refa42_op in H. discriminate H. Qed.

Lemma refa42_not2697 : ~ @Equation2697 Fin13 refa42_inst.
Proof. unfold Equation2697. intro H. specialize (H F13_0 F13_1). unfold magma_op, refa42_inst, refa42_op in H. discriminate H. Qed.

Lemma refa42_not2699 : ~ @Equation2699 Fin13 refa42_inst.
Proof. unfold Equation2699. intro H. specialize (H F13_0 F13_1). unfold magma_op, refa42_inst, refa42_op in H. discriminate H. Qed.

Lemma refa42_not2700 : ~ @Equation2700 Fin13 refa42_inst.
Proof. unfold Equation2700. intro H. specialize (H F13_0 F13_1). unfold magma_op, refa42_inst, refa42_op in H. discriminate H. Qed.

Lemma refa42_not2706 : ~ @Equation2706 Fin13 refa42_inst.
Proof. unfold Equation2706. intro H. specialize (H F13_0 F13_1). unfold magma_op, refa42_inst, refa42_op in H. discriminate H. Qed.

Lemma refa42_not2709 : ~ @Equation2709 Fin13 refa42_inst.
Proof. unfold Equation2709. intro H. specialize (H F13_0 F13_1). unfold magma_op, refa42_inst, refa42_op in H. discriminate H. Qed.

Lemma refa42_not2710 : ~ @Equation2710 Fin13 refa42_inst.
Proof. unfold Equation2710. intro H. specialize (H F13_0 F13_1). unfold magma_op, refa42_inst, refa42_op in H. discriminate H. Qed.

Lemma refa42_not2733 : ~ @Equation2733 Fin13 refa42_inst.
Proof. unfold Equation2733. intro H. specialize (H F13_0 F13_1). unfold magma_op, refa42_inst, refa42_op in H. discriminate H. Qed.

Lemma refa42_not2734 : ~ @Equation2734 Fin13 refa42_inst.
Proof. unfold Equation2734. intro H. specialize (H F13_0 F13_1). unfold magma_op, refa42_inst, refa42_op in H. discriminate H. Qed.

Lemma refa42_not2736 : ~ @Equation2736 Fin13 refa42_inst.
Proof. unfold Equation2736. intro H. specialize (H F13_0 F13_1). unfold magma_op, refa42_inst, refa42_op in H. discriminate H. Qed.

Lemma refa42_not2743 : ~ @Equation2743 Fin13 refa42_inst.
Proof. unfold Equation2743. intro H. specialize (H F13_0 F13_1). unfold magma_op, refa42_inst, refa42_op in H. discriminate H. Qed.

Lemma refa42_not2744 : ~ @Equation2744 Fin13 refa42_inst.
Proof. unfold Equation2744. intro H. specialize (H F13_0 F13_1). unfold magma_op, refa42_inst, refa42_op in H. discriminate H. Qed.

Lemma refa42_not2746 : ~ @Equation2746 Fin13 refa42_inst.
Proof. unfold Equation2746. intro H. specialize (H F13_0 F13_1). unfold magma_op, refa42_inst, refa42_op in H. discriminate H. Qed.

Lemma refa42_not2849 : ~ @Equation2849 Fin13 refa42_inst.
Proof. unfold Equation2849. intro H. specialize (H F13_0 F13_1). unfold magma_op, refa42_inst, refa42_op in H. discriminate H. Qed.

Lemma refa42_not2852 : ~ @Equation2852 Fin13 refa42_inst.
Proof. unfold Equation2852. intro H. specialize (H F13_0 F13_1). unfold magma_op, refa42_inst, refa42_op in H. discriminate H. Qed.

Lemma refa42_not2853 : ~ @Equation2853 Fin13 refa42_inst.
Proof. unfold Equation2853. intro H. specialize (H F13_0 F13_1). unfold magma_op, refa42_inst, refa42_op in H. discriminate H. Qed.

Lemma refa42_not2855 : ~ @Equation2855 Fin13 refa42_inst.
Proof. unfold Equation2855. intro H. specialize (H F13_0 F13_1). unfold magma_op, refa42_inst, refa42_op in H. discriminate H. Qed.

Lemma refa42_not2862 : ~ @Equation2862 Fin13 refa42_inst.
Proof. unfold Equation2862. intro H. specialize (H F13_0 F13_1). unfold magma_op, refa42_inst, refa42_op in H. discriminate H. Qed.

Lemma refa42_not2863 : ~ @Equation2863 Fin13 refa42_inst.
Proof. unfold Equation2863. intro H. specialize (H F13_0 F13_1). unfold magma_op, refa42_inst, refa42_op in H. discriminate H. Qed.

Lemma refa42_not2865 : ~ @Equation2865 Fin13 refa42_inst.
Proof. unfold Equation2865. intro H. specialize (H F13_0 F13_1). unfold magma_op, refa42_inst, refa42_op in H. discriminate H. Qed.

Lemma refa42_not2872 : ~ @Equation2872 Fin13 refa42_inst.
Proof. unfold Equation2872. intro H. specialize (H F13_0 F13_1). unfold magma_op, refa42_inst, refa42_op in H. discriminate H. Qed.

Lemma refa42_not2873 : ~ @Equation2873 Fin13 refa42_inst.
Proof. unfold Equation2873. intro H. specialize (H F13_0 F13_1). unfold magma_op, refa42_inst, refa42_op in H. discriminate H. Qed.

Lemma refa42_not2875 : ~ @Equation2875 Fin13 refa42_inst.
Proof. unfold Equation2875. intro H. specialize (H F13_0 F13_1). unfold magma_op, refa42_inst, refa42_op in H. discriminate H. Qed.

Lemma refa42_not2899 : ~ @Equation2899 Fin13 refa42_inst.
Proof. unfold Equation2899. intro H. specialize (H F13_0 F13_1). unfold magma_op, refa42_inst, refa42_op in H. discriminate H. Qed.

Lemma refa42_not2900 : ~ @Equation2900 Fin13 refa42_inst.
Proof. unfold Equation2900. intro H. specialize (H F13_0 F13_1). unfold magma_op, refa42_inst, refa42_op in H. discriminate H. Qed.

Lemma refa42_not2902 : ~ @Equation2902 Fin13 refa42_inst.
Proof. unfold Equation2902. intro H. specialize (H F13_0 F13_1). unfold magma_op, refa42_inst, refa42_op in H. discriminate H. Qed.

Lemma refa42_not2903 : ~ @Equation2903 Fin13 refa42_inst.
Proof. unfold Equation2903. intro H. specialize (H F13_0 F13_1). unfold magma_op, refa42_inst, refa42_op in H. discriminate H. Qed.

Lemma refa42_not2909 : ~ @Equation2909 Fin13 refa42_inst.
Proof. unfold Equation2909. intro H. specialize (H F13_0 F13_1). unfold magma_op, refa42_inst, refa42_op in H. discriminate H. Qed.

Lemma refa42_not2910 : ~ @Equation2910 Fin13 refa42_inst.
Proof. unfold Equation2910. intro H. specialize (H F13_0 F13_1). unfold magma_op, refa42_inst, refa42_op in H. discriminate H. Qed.

Lemma refa42_not2912 : ~ @Equation2912 Fin13 refa42_inst.
Proof. unfold Equation2912. intro H. specialize (H F13_0 F13_1). unfold magma_op, refa42_inst, refa42_op in H. discriminate H. Qed.

Lemma refa42_not2936 : ~ @Equation2936 Fin13 refa42_inst.
Proof. unfold Equation2936. intro H. specialize (H F13_0 F13_1). unfold magma_op, refa42_inst, refa42_op in H. discriminate H. Qed.

Lemma refa42_not2937 : ~ @Equation2937 Fin13 refa42_inst.
Proof. unfold Equation2937. intro H. specialize (H F13_0 F13_1). unfold magma_op, refa42_inst, refa42_op in H. discriminate H. Qed.

Lemma refa42_not2939 : ~ @Equation2939 Fin13 refa42_inst.
Proof. unfold Equation2939. intro H. specialize (H F13_0 F13_1). unfold magma_op, refa42_inst, refa42_op in H. discriminate H. Qed.

Lemma refa42_not2940 : ~ @Equation2940 Fin13 refa42_inst.
Proof. unfold Equation2940. intro H. specialize (H F13_0 F13_1). unfold magma_op, refa42_inst, refa42_op in H. discriminate H. Qed.

Lemma refa42_not2946 : ~ @Equation2946 Fin13 refa42_inst.
Proof. unfold Equation2946. intro H. specialize (H F13_0 F13_1). unfold magma_op, refa42_inst, refa42_op in H. discriminate H. Qed.

Lemma refa42_not2947 : ~ @Equation2947 Fin13 refa42_inst.
Proof. unfold Equation2947. intro H. specialize (H F13_0 F13_1). unfold magma_op, refa42_inst, refa42_op in H. discriminate H. Qed.

Lemma refa42_not2949 : ~ @Equation2949 Fin13 refa42_inst.
Proof. unfold Equation2949. intro H. specialize (H F13_0 F13_1). unfold magma_op, refa42_inst, refa42_op in H. discriminate H. Qed.

Lemma refa42_not3052 : ~ @Equation3052 Fin13 refa42_inst.
Proof. unfold Equation3052. intro H. specialize (H F13_0 F13_1). unfold magma_op, refa42_inst, refa42_op in H. discriminate H. Qed.

Lemma refa42_not3055 : ~ @Equation3055 Fin13 refa42_inst.
Proof. unfold Equation3055. intro H. specialize (H F13_0 F13_1). unfold magma_op, refa42_inst, refa42_op in H. discriminate H. Qed.

Lemma refa42_not3056 : ~ @Equation3056 Fin13 refa42_inst.
Proof. unfold Equation3056. intro H. specialize (H F13_0 F13_1). unfold magma_op, refa42_inst, refa42_op in H. discriminate H. Qed.

Lemma refa42_not3058 : ~ @Equation3058 Fin13 refa42_inst.
Proof. unfold Equation3058. intro H. specialize (H F13_0 F13_1). unfold magma_op, refa42_inst, refa42_op in H. discriminate H. Qed.

Lemma refa42_not3065 : ~ @Equation3065 Fin13 refa42_inst.
Proof. unfold Equation3065. intro H. specialize (H F13_0 F13_1). unfold magma_op, refa42_inst, refa42_op in H. discriminate H. Qed.

Lemma refa42_not3066 : ~ @Equation3066 Fin13 refa42_inst.
Proof. unfold Equation3066. intro H. specialize (H F13_0 F13_1). unfold magma_op, refa42_inst, refa42_op in H. discriminate H. Qed.

Lemma refa42_not3068 : ~ @Equation3068 Fin13 refa42_inst.
Proof. unfold Equation3068. intro H. specialize (H F13_0 F13_1). unfold magma_op, refa42_inst, refa42_op in H. discriminate H. Qed.

Lemma refa42_not3075 : ~ @Equation3075 Fin13 refa42_inst.
Proof. unfold Equation3075. intro H. specialize (H F13_0 F13_1). unfold magma_op, refa42_inst, refa42_op in H. discriminate H. Qed.

Lemma refa42_not3076 : ~ @Equation3076 Fin13 refa42_inst.
Proof. unfold Equation3076. intro H. specialize (H F13_0 F13_1). unfold magma_op, refa42_inst, refa42_op in H. discriminate H. Qed.

Lemma refa42_not3078 : ~ @Equation3078 Fin13 refa42_inst.
Proof. unfold Equation3078. intro H. specialize (H F13_0 F13_1). unfold magma_op, refa42_inst, refa42_op in H. discriminate H. Qed.

Lemma refa42_not3079 : ~ @Equation3079 Fin13 refa42_inst.
Proof. unfold Equation3079. intro H. specialize (H F13_0 F13_1). unfold magma_op, refa42_inst, refa42_op in H. discriminate H. Qed.

Lemma refa42_not3102 : ~ @Equation3102 Fin13 refa42_inst.
Proof. unfold Equation3102. intro H. specialize (H F13_0 F13_1). unfold magma_op, refa42_inst, refa42_op in H. discriminate H. Qed.

Lemma refa42_not3103 : ~ @Equation3103 Fin13 refa42_inst.
Proof. unfold Equation3103. intro H. specialize (H F13_0 F13_1). unfold magma_op, refa42_inst, refa42_op in H. discriminate H. Qed.

Lemma refa42_not3105 : ~ @Equation3105 Fin13 refa42_inst.
Proof. unfold Equation3105. intro H. specialize (H F13_0 F13_1). unfold magma_op, refa42_inst, refa42_op in H. discriminate H. Qed.

Lemma refa42_not3112 : ~ @Equation3112 Fin13 refa42_inst.
Proof. unfold Equation3112. intro H. specialize (H F13_0 F13_1). unfold magma_op, refa42_inst, refa42_op in H. discriminate H. Qed.

Lemma refa42_not3113 : ~ @Equation3113 Fin13 refa42_inst.
Proof. unfold Equation3113. intro H. specialize (H F13_0 F13_1). unfold magma_op, refa42_inst, refa42_op in H. discriminate H. Qed.

Lemma refa42_not3115 : ~ @Equation3115 Fin13 refa42_inst.
Proof. unfold Equation3115. intro H. specialize (H F13_0 F13_1). unfold magma_op, refa42_inst, refa42_op in H. discriminate H. Qed.

Lemma refa42_not3116 : ~ @Equation3116 Fin13 refa42_inst.
Proof. unfold Equation3116. intro H. specialize (H F13_0 F13_1). unfold magma_op, refa42_inst, refa42_op in H. discriminate H. Qed.

Lemma refa42_not3139 : ~ @Equation3139 Fin13 refa42_inst.
Proof. unfold Equation3139. intro H. specialize (H F13_0 F13_1). unfold magma_op, refa42_inst, refa42_op in H. discriminate H. Qed.

Lemma refa42_not3140 : ~ @Equation3140 Fin13 refa42_inst.
Proof. unfold Equation3140. intro H. specialize (H F13_0 F13_1). unfold magma_op, refa42_inst, refa42_op in H. discriminate H. Qed.

Lemma refa42_not3142 : ~ @Equation3142 Fin13 refa42_inst.
Proof. unfold Equation3142. intro H. specialize (H F13_0 F13_1). unfold magma_op, refa42_inst, refa42_op in H. discriminate H. Qed.

Lemma refa42_not3143 : ~ @Equation3143 Fin13 refa42_inst.
Proof. unfold Equation3143. intro H. specialize (H F13_0 F13_1). unfold magma_op, refa42_inst, refa42_op in H. discriminate H. Qed.

Lemma refa42_not3149 : ~ @Equation3149 Fin13 refa42_inst.
Proof. unfold Equation3149. intro H. specialize (H F13_0 F13_1). unfold magma_op, refa42_inst, refa42_op in H. discriminate H. Qed.

Lemma refa42_not3150 : ~ @Equation3150 Fin13 refa42_inst.
Proof. unfold Equation3150. intro H. specialize (H F13_0 F13_1). unfold magma_op, refa42_inst, refa42_op in H. discriminate H. Qed.

Lemma refa42_not3152 : ~ @Equation3152 Fin13 refa42_inst.
Proof. unfold Equation3152. intro H. specialize (H F13_0 F13_1). unfold magma_op, refa42_inst, refa42_op in H. discriminate H. Qed.

Lemma refa42_not3254 : ~ @Equation3254 Fin13 refa42_inst.
Proof. unfold Equation3254. intro H. specialize (H F13_0 F13_1). unfold magma_op, refa42_inst, refa42_op in H. discriminate H. Qed.

Lemma refa42_not3255 : ~ @Equation3255 Fin13 refa42_inst.
Proof. unfold Equation3255. intro H. specialize (H F13_0 F13_1). unfold magma_op, refa42_inst, refa42_op in H. discriminate H. Qed.

Lemma refa42_not3256 : ~ @Equation3256 Fin13 refa42_inst.
Proof. unfold Equation3256. intro H. specialize (H F13_0 F13_1). unfold magma_op, refa42_inst, refa42_op in H. discriminate H. Qed.

Lemma refa42_not3258 : ~ @Equation3258 Fin13 refa42_inst.
Proof. unfold Equation3258. intro H. specialize (H F13_0 F13_1). unfold magma_op, refa42_inst, refa42_op in H. discriminate H. Qed.

Lemma refa42_not3259 : ~ @Equation3259 Fin13 refa42_inst.
Proof. unfold Equation3259. intro H. specialize (H F13_0 F13_1). unfold magma_op, refa42_inst, refa42_op in H. discriminate H. Qed.

Lemma refa42_not3261 : ~ @Equation3261 Fin13 refa42_inst.
Proof. unfold Equation3261. intro H. specialize (H F13_0 F13_1). unfold magma_op, refa42_inst, refa42_op in H. discriminate H. Qed.

Lemma refa42_not3262 : ~ @Equation3262 Fin13 refa42_inst.
Proof. unfold Equation3262. intro H. specialize (H F13_0 F13_1). unfold magma_op, refa42_inst, refa42_op in H. discriminate H. Qed.

Lemma refa42_not3268 : ~ @Equation3268 Fin13 refa42_inst.
Proof. unfold Equation3268. intro H. specialize (H F13_0 F13_1). unfold magma_op, refa42_inst, refa42_op in H. discriminate H. Qed.

Lemma refa42_not3269 : ~ @Equation3269 Fin13 refa42_inst.
Proof. unfold Equation3269. intro H. specialize (H F13_0 F13_1). unfold magma_op, refa42_inst, refa42_op in H. discriminate H. Qed.

Lemma refa42_not3271 : ~ @Equation3271 Fin13 refa42_inst.
Proof. unfold Equation3271. intro H. specialize (H F13_0 F13_1). unfold magma_op, refa42_inst, refa42_op in H. discriminate H. Qed.

Lemma refa42_not3272 : ~ @Equation3272 Fin13 refa42_inst.
Proof. unfold Equation3272. intro H. specialize (H F13_0 F13_1). unfold magma_op, refa42_inst, refa42_op in H. discriminate H. Qed.

Lemma refa42_not3278 : ~ @Equation3278 Fin13 refa42_inst.
Proof. unfold Equation3278. intro H. specialize (H F13_0 F13_1). unfold magma_op, refa42_inst, refa42_op in H. discriminate H. Qed.

Lemma refa42_not3279 : ~ @Equation3279 Fin13 refa42_inst.
Proof. unfold Equation3279. intro H. specialize (H F13_0 F13_1). unfold magma_op, refa42_inst, refa42_op in H. discriminate H. Qed.

Lemma refa42_not3281 : ~ @Equation3281 Fin13 refa42_inst.
Proof. unfold Equation3281. intro H. specialize (H F13_0 F13_1). unfold magma_op, refa42_inst, refa42_op in H. discriminate H. Qed.

Lemma refa42_not3306 : ~ @Equation3306 Fin13 refa42_inst.
Proof. unfold Equation3306. intro H. specialize (H F13_0 F13_1). unfold magma_op, refa42_inst, refa42_op in H. discriminate H. Qed.

Lemma refa42_not3308 : ~ @Equation3308 Fin13 refa42_inst.
Proof. unfold Equation3308. intro H. specialize (H F13_0 F13_1). unfold magma_op, refa42_inst, refa42_op in H. discriminate H. Qed.

Lemma refa42_not3309 : ~ @Equation3309 Fin13 refa42_inst.
Proof. unfold Equation3309. intro H. specialize (H F13_0 F13_1). unfold magma_op, refa42_inst, refa42_op in H. discriminate H. Qed.

Lemma refa42_not3315 : ~ @Equation3315 Fin13 refa42_inst.
Proof. unfold Equation3315. intro H. specialize (H F13_0 F13_1). unfold magma_op, refa42_inst, refa42_op in H. discriminate H. Qed.

Lemma refa42_not3316 : ~ @Equation3316 Fin13 refa42_inst.
Proof. unfold Equation3316. intro H. specialize (H F13_0 F13_1). unfold magma_op, refa42_inst, refa42_op in H. discriminate H. Qed.

Lemma refa42_not3318 : ~ @Equation3318 Fin13 refa42_inst.
Proof. unfold Equation3318. intro H. specialize (H F13_0 F13_1). unfold magma_op, refa42_inst, refa42_op in H. discriminate H. Qed.

Lemma refa42_not3343 : ~ @Equation3343 Fin13 refa42_inst.
Proof. unfold Equation3343. intro H. specialize (H F13_0 F13_1). unfold magma_op, refa42_inst, refa42_op in H. discriminate H. Qed.

Lemma refa42_not3345 : ~ @Equation3345 Fin13 refa42_inst.
Proof. unfold Equation3345. intro H. specialize (H F13_0 F13_1). unfold magma_op, refa42_inst, refa42_op in H. discriminate H. Qed.

Lemma refa42_not3346 : ~ @Equation3346 Fin13 refa42_inst.
Proof. unfold Equation3346. intro H. specialize (H F13_0 F13_1). unfold magma_op, refa42_inst, refa42_op in H. discriminate H. Qed.

Lemma refa42_not3352 : ~ @Equation3352 Fin13 refa42_inst.
Proof. unfold Equation3352. intro H. specialize (H F13_0 F13_1). unfold magma_op, refa42_inst, refa42_op in H. discriminate H. Qed.

Lemma refa42_not3353 : ~ @Equation3353 Fin13 refa42_inst.
Proof. unfold Equation3353. intro H. specialize (H F13_0 F13_1). unfold magma_op, refa42_inst, refa42_op in H. discriminate H. Qed.

Lemma refa42_not3355 : ~ @Equation3355 Fin13 refa42_inst.
Proof. unfold Equation3355. intro H. specialize (H F13_0 F13_1). unfold magma_op, refa42_inst, refa42_op in H. discriminate H. Qed.

Lemma refa42_not3457 : ~ @Equation3457 Fin13 refa42_inst.
Proof. unfold Equation3457. intro H. specialize (H F13_0 F13_1). unfold magma_op, refa42_inst, refa42_op in H. discriminate H. Qed.

Lemma refa42_not3458 : ~ @Equation3458 Fin13 refa42_inst.
Proof. unfold Equation3458. intro H. specialize (H F13_0 F13_1). unfold magma_op, refa42_inst, refa42_op in H. discriminate H. Qed.

Lemma refa42_not3459 : ~ @Equation3459 Fin13 refa42_inst.
Proof. unfold Equation3459. intro H. specialize (H F13_0 F13_1). unfold magma_op, refa42_inst, refa42_op in H. discriminate H. Qed.

Lemma refa42_not3461 : ~ @Equation3461 Fin13 refa42_inst.
Proof. unfold Equation3461. intro H. specialize (H F13_0 F13_1). unfold magma_op, refa42_inst, refa42_op in H. discriminate H. Qed.

Lemma refa42_not3462 : ~ @Equation3462 Fin13 refa42_inst.
Proof. unfold Equation3462. intro H. specialize (H F13_0 F13_1). unfold magma_op, refa42_inst, refa42_op in H. discriminate H. Qed.

Lemma refa42_not3464 : ~ @Equation3464 Fin13 refa42_inst.
Proof. unfold Equation3464. intro H. specialize (H F13_0 F13_1). unfold magma_op, refa42_inst, refa42_op in H. discriminate H. Qed.

Lemma refa42_not3465 : ~ @Equation3465 Fin13 refa42_inst.
Proof. unfold Equation3465. intro H. specialize (H F13_0 F13_1). unfold magma_op, refa42_inst, refa42_op in H. discriminate H. Qed.

Lemma refa42_not3472 : ~ @Equation3472 Fin13 refa42_inst.
Proof. unfold Equation3472. intro H. specialize (H F13_0 F13_1). unfold magma_op, refa42_inst, refa42_op in H. discriminate H. Qed.

Lemma refa42_not3474 : ~ @Equation3474 Fin13 refa42_inst.
Proof. unfold Equation3474. intro H. specialize (H F13_0 F13_1). unfold magma_op, refa42_inst, refa42_op in H. discriminate H. Qed.

Lemma refa42_not3475 : ~ @Equation3475 Fin13 refa42_inst.
Proof. unfold Equation3475. intro H. specialize (H F13_0 F13_1). unfold magma_op, refa42_inst, refa42_op in H. discriminate H. Qed.

Lemma refa42_not3481 : ~ @Equation3481 Fin13 refa42_inst.
Proof. unfold Equation3481. intro H. specialize (H F13_0 F13_1). unfold magma_op, refa42_inst, refa42_op in H. discriminate H. Qed.

Lemma refa42_not3482 : ~ @Equation3482 Fin13 refa42_inst.
Proof. unfold Equation3482. intro H. specialize (H F13_0 F13_1). unfold magma_op, refa42_inst, refa42_op in H. discriminate H. Qed.

Lemma refa42_not3484 : ~ @Equation3484 Fin13 refa42_inst.
Proof. unfold Equation3484. intro H. specialize (H F13_0 F13_1). unfold magma_op, refa42_inst, refa42_op in H. discriminate H. Qed.

Lemma refa42_not3509 : ~ @Equation3509 Fin13 refa42_inst.
Proof. unfold Equation3509. intro H. specialize (H F13_0 F13_1). unfold magma_op, refa42_inst, refa42_op in H. discriminate H. Qed.

Lemma refa42_not3511 : ~ @Equation3511 Fin13 refa42_inst.
Proof. unfold Equation3511. intro H. specialize (H F13_0 F13_1). unfold magma_op, refa42_inst, refa42_op in H. discriminate H. Qed.

Lemma refa42_not3512 : ~ @Equation3512 Fin13 refa42_inst.
Proof. unfold Equation3512. intro H. specialize (H F13_0 F13_1). unfold magma_op, refa42_inst, refa42_op in H. discriminate H. Qed.

Lemma refa42_not3518 : ~ @Equation3518 Fin13 refa42_inst.
Proof. unfold Equation3518. intro H. specialize (H F13_0 F13_1). unfold magma_op, refa42_inst, refa42_op in H. discriminate H. Qed.

Lemma refa42_not3519 : ~ @Equation3519 Fin13 refa42_inst.
Proof. unfold Equation3519. intro H. specialize (H F13_0 F13_1). unfold magma_op, refa42_inst, refa42_op in H. discriminate H. Qed.

Lemma refa42_not3521 : ~ @Equation3521 Fin13 refa42_inst.
Proof. unfold Equation3521. intro H. specialize (H F13_0 F13_1). unfold magma_op, refa42_inst, refa42_op in H. discriminate H. Qed.

Lemma refa42_not3546 : ~ @Equation3546 Fin13 refa42_inst.
Proof. unfold Equation3546. intro H. specialize (H F13_0 F13_1). unfold magma_op, refa42_inst, refa42_op in H. discriminate H. Qed.

Lemma refa42_not3548 : ~ @Equation3548 Fin13 refa42_inst.
Proof. unfold Equation3548. intro H. specialize (H F13_0 F13_1). unfold magma_op, refa42_inst, refa42_op in H. discriminate H. Qed.

Lemma refa42_not3549 : ~ @Equation3549 Fin13 refa42_inst.
Proof. unfold Equation3549. intro H. specialize (H F13_0 F13_1). unfold magma_op, refa42_inst, refa42_op in H. discriminate H. Qed.

Lemma refa42_not3555 : ~ @Equation3555 Fin13 refa42_inst.
Proof. unfold Equation3555. intro H. specialize (H F13_0 F13_1). unfold magma_op, refa42_inst, refa42_op in H. discriminate H. Qed.

Lemma refa42_not3556 : ~ @Equation3556 Fin13 refa42_inst.
Proof. unfold Equation3556. intro H. specialize (H F13_0 F13_1). unfold magma_op, refa42_inst, refa42_op in H. discriminate H. Qed.

Lemma refa42_not3558 : ~ @Equation3558 Fin13 refa42_inst.
Proof. unfold Equation3558. intro H. specialize (H F13_0 F13_1). unfold magma_op, refa42_inst, refa42_op in H. discriminate H. Qed.

Lemma refa42_not3660 : ~ @Equation3660 Fin13 refa42_inst.
Proof. unfold Equation3660. intro H. specialize (H F13_0 F13_1). unfold magma_op, refa42_inst, refa42_op in H. discriminate H. Qed.

Lemma refa42_not3661 : ~ @Equation3661 Fin13 refa42_inst.
Proof. unfold Equation3661. intro H. specialize (H F13_0 F13_1). unfold magma_op, refa42_inst, refa42_op in H. discriminate H. Qed.

Lemma refa42_not3662 : ~ @Equation3662 Fin13 refa42_inst.
Proof. unfold Equation3662. intro H. specialize (H F13_0 F13_1). unfold magma_op, refa42_inst, refa42_op in H. discriminate H. Qed.

Lemma refa42_not3664 : ~ @Equation3664 Fin13 refa42_inst.
Proof. unfold Equation3664. intro H. specialize (H F13_0 F13_1). unfold magma_op, refa42_inst, refa42_op in H. discriminate H. Qed.

Lemma refa42_not3665 : ~ @Equation3665 Fin13 refa42_inst.
Proof. unfold Equation3665. intro H. specialize (H F13_0 F13_1). unfold magma_op, refa42_inst, refa42_op in H. discriminate H. Qed.

Lemma refa42_not3667 : ~ @Equation3667 Fin13 refa42_inst.
Proof. unfold Equation3667. intro H. specialize (H F13_0 F13_1). unfold magma_op, refa42_inst, refa42_op in H. discriminate H. Qed.

Lemma refa42_not3668 : ~ @Equation3668 Fin13 refa42_inst.
Proof. unfold Equation3668. intro H. specialize (H F13_0 F13_1). unfold magma_op, refa42_inst, refa42_op in H. discriminate H. Qed.

Lemma refa42_not3674 : ~ @Equation3674 Fin13 refa42_inst.
Proof. unfold Equation3674. intro H. specialize (H F13_0 F13_1). unfold magma_op, refa42_inst, refa42_op in H. discriminate H. Qed.

Lemma refa42_not3675 : ~ @Equation3675 Fin13 refa42_inst.
Proof. unfold Equation3675. intro H. specialize (H F13_0 F13_1). unfold magma_op, refa42_inst, refa42_op in H. discriminate H. Qed.

Lemma refa42_not3677 : ~ @Equation3677 Fin13 refa42_inst.
Proof. unfold Equation3677. intro H. specialize (H F13_0 F13_1). unfold magma_op, refa42_inst, refa42_op in H. discriminate H. Qed.

Lemma refa42_not3678 : ~ @Equation3678 Fin13 refa42_inst.
Proof. unfold Equation3678. intro H. specialize (H F13_0 F13_1). unfold magma_op, refa42_inst, refa42_op in H. discriminate H. Qed.

Lemma refa42_not3684 : ~ @Equation3684 Fin13 refa42_inst.
Proof. unfold Equation3684. intro H. specialize (H F13_0 F13_1). unfold magma_op, refa42_inst, refa42_op in H. discriminate H. Qed.

Lemma refa42_not3685 : ~ @Equation3685 Fin13 refa42_inst.
Proof. unfold Equation3685. intro H. specialize (H F13_0 F13_1). unfold magma_op, refa42_inst, refa42_op in H. discriminate H. Qed.

Lemma refa42_not3687 : ~ @Equation3687 Fin13 refa42_inst.
Proof. unfold Equation3687. intro H. specialize (H F13_0 F13_1). unfold magma_op, refa42_inst, refa42_op in H. discriminate H. Qed.

Lemma refa42_not3712 : ~ @Equation3712 Fin13 refa42_inst.
Proof. unfold Equation3712. intro H. specialize (H F13_0 F13_1). unfold magma_op, refa42_inst, refa42_op in H. discriminate H. Qed.

Lemma refa42_not3714 : ~ @Equation3714 Fin13 refa42_inst.
Proof. unfold Equation3714. intro H. specialize (H F13_0 F13_1). unfold magma_op, refa42_inst, refa42_op in H. discriminate H. Qed.

Lemma refa42_not3721 : ~ @Equation3721 Fin13 refa42_inst.
Proof. unfold Equation3721. intro H. specialize (H F13_0 F13_1). unfold magma_op, refa42_inst, refa42_op in H. discriminate H. Qed.

Lemma refa42_not3725 : ~ @Equation3725 Fin13 refa42_inst.
Proof. unfold Equation3725. intro H. specialize (H F13_0 F13_1). unfold magma_op, refa42_inst, refa42_op in H. discriminate H. Qed.

Lemma refa42_not3748 : ~ @Equation3748 Fin13 refa42_inst.
Proof. unfold Equation3748. intro H. specialize (H F13_0 F13_1). unfold magma_op, refa42_inst, refa42_op in H. discriminate H. Qed.

Lemma refa42_not3752 : ~ @Equation3752 Fin13 refa42_inst.
Proof. unfold Equation3752. intro H. specialize (H F13_0 F13_1). unfold magma_op, refa42_inst, refa42_op in H. discriminate H. Qed.

Lemma refa42_not3759 : ~ @Equation3759 Fin13 refa42_inst.
Proof. unfold Equation3759. intro H. specialize (H F13_0 F13_1). unfold magma_op, refa42_inst, refa42_op in H. discriminate H. Qed.

Lemma refa42_not3761 : ~ @Equation3761 Fin13 refa42_inst.
Proof. unfold Equation3761. intro H. specialize (H F13_0 F13_1). unfold magma_op, refa42_inst, refa42_op in H. discriminate H. Qed.

Lemma refa42_not3864 : ~ @Equation3864 Fin13 refa42_inst.
Proof. unfold Equation3864. intro H. specialize (H F13_0 F13_1). unfold magma_op, refa42_inst, refa42_op in H. discriminate H. Qed.

Lemma refa42_not3865 : ~ @Equation3865 Fin13 refa42_inst.
Proof. unfold Equation3865. intro H. specialize (H F13_0 F13_1). unfold magma_op, refa42_inst, refa42_op in H. discriminate H. Qed.

Lemma refa42_not3867 : ~ @Equation3867 Fin13 refa42_inst.
Proof. unfold Equation3867. intro H. specialize (H F13_0 F13_1). unfold magma_op, refa42_inst, refa42_op in H. discriminate H. Qed.

Lemma refa42_not3868 : ~ @Equation3868 Fin13 refa42_inst.
Proof. unfold Equation3868. intro H. specialize (H F13_0 F13_1). unfold magma_op, refa42_inst, refa42_op in H. discriminate H. Qed.

Lemma refa42_not3870 : ~ @Equation3870 Fin13 refa42_inst.
Proof. unfold Equation3870. intro H. specialize (H F13_0 F13_1). unfold magma_op, refa42_inst, refa42_op in H. discriminate H. Qed.

Lemma refa42_not3871 : ~ @Equation3871 Fin13 refa42_inst.
Proof. unfold Equation3871. intro H. specialize (H F13_0 F13_1). unfold magma_op, refa42_inst, refa42_op in H. discriminate H. Qed.

Lemma refa42_not3877 : ~ @Equation3877 Fin13 refa42_inst.
Proof. unfold Equation3877. intro H. specialize (H F13_0 F13_1). unfold magma_op, refa42_inst, refa42_op in H. discriminate H. Qed.

Lemma refa42_not3878 : ~ @Equation3878 Fin13 refa42_inst.
Proof. unfold Equation3878. intro H. specialize (H F13_0 F13_1). unfold magma_op, refa42_inst, refa42_op in H. discriminate H. Qed.

Lemma refa42_not3880 : ~ @Equation3880 Fin13 refa42_inst.
Proof. unfold Equation3880. intro H. specialize (H F13_0 F13_1). unfold magma_op, refa42_inst, refa42_op in H. discriminate H. Qed.

Lemma refa42_not3881 : ~ @Equation3881 Fin13 refa42_inst.
Proof. unfold Equation3881. intro H. specialize (H F13_0 F13_1). unfold magma_op, refa42_inst, refa42_op in H. discriminate H. Qed.

Lemma refa42_not3887 : ~ @Equation3887 Fin13 refa42_inst.
Proof. unfold Equation3887. intro H. specialize (H F13_0 F13_1). unfold magma_op, refa42_inst, refa42_op in H. discriminate H. Qed.

Lemma refa42_not3888 : ~ @Equation3888 Fin13 refa42_inst.
Proof. unfold Equation3888. intro H. specialize (H F13_0 F13_1). unfold magma_op, refa42_inst, refa42_op in H. discriminate H. Qed.

Lemma refa42_not3890 : ~ @Equation3890 Fin13 refa42_inst.
Proof. unfold Equation3890. intro H. specialize (H F13_0 F13_1). unfold magma_op, refa42_inst, refa42_op in H. discriminate H. Qed.

Lemma refa42_not3917 : ~ @Equation3917 Fin13 refa42_inst.
Proof. unfold Equation3917. intro H. specialize (H F13_0 F13_1). unfold magma_op, refa42_inst, refa42_op in H. discriminate H. Qed.

Lemma refa42_not3918 : ~ @Equation3918 Fin13 refa42_inst.
Proof. unfold Equation3918. intro H. specialize (H F13_0 F13_1). unfold magma_op, refa42_inst, refa42_op in H. discriminate H. Qed.

Lemma refa42_not3924 : ~ @Equation3924 Fin13 refa42_inst.
Proof. unfold Equation3924. intro H. specialize (H F13_0 F13_1). unfold magma_op, refa42_inst, refa42_op in H. discriminate H. Qed.

Lemma refa42_not3925 : ~ @Equation3925 Fin13 refa42_inst.
Proof. unfold Equation3925. intro H. specialize (H F13_0 F13_1). unfold magma_op, refa42_inst, refa42_op in H. discriminate H. Qed.

Lemma refa42_not3927 : ~ @Equation3927 Fin13 refa42_inst.
Proof. unfold Equation3927. intro H. specialize (H F13_0 F13_1). unfold magma_op, refa42_inst, refa42_op in H. discriminate H. Qed.

Lemma refa42_not3928 : ~ @Equation3928 Fin13 refa42_inst.
Proof. unfold Equation3928. intro H. specialize (H F13_0 F13_1). unfold magma_op, refa42_inst, refa42_op in H. discriminate H. Qed.

Lemma refa42_not3951 : ~ @Equation3951 Fin13 refa42_inst.
Proof. unfold Equation3951. intro H. specialize (H F13_0 F13_1). unfold magma_op, refa42_inst, refa42_op in H. discriminate H. Qed.

Lemma refa42_not3952 : ~ @Equation3952 Fin13 refa42_inst.
Proof. unfold Equation3952. intro H. specialize (H F13_0 F13_1). unfold magma_op, refa42_inst, refa42_op in H. discriminate H. Qed.

Lemma refa42_not3954 : ~ @Equation3954 Fin13 refa42_inst.
Proof. unfold Equation3954. intro H. specialize (H F13_0 F13_1). unfold magma_op, refa42_inst, refa42_op in H. discriminate H. Qed.

Lemma refa42_not3955 : ~ @Equation3955 Fin13 refa42_inst.
Proof. unfold Equation3955. intro H. specialize (H F13_0 F13_1). unfold magma_op, refa42_inst, refa42_op in H. discriminate H. Qed.

Lemma refa42_not3961 : ~ @Equation3961 Fin13 refa42_inst.
Proof. unfold Equation3961. intro H. specialize (H F13_0 F13_1). unfold magma_op, refa42_inst, refa42_op in H. discriminate H. Qed.

Lemma refa42_not3962 : ~ @Equation3962 Fin13 refa42_inst.
Proof. unfold Equation3962. intro H. specialize (H F13_0 F13_1). unfold magma_op, refa42_inst, refa42_op in H. discriminate H. Qed.

Lemma refa42_not4066 : ~ @Equation4066 Fin13 refa42_inst.
Proof. unfold Equation4066. intro H. specialize (H F13_0 F13_1). unfold magma_op, refa42_inst, refa42_op in H. discriminate H. Qed.

Lemma refa42_not4067 : ~ @Equation4067 Fin13 refa42_inst.
Proof. unfold Equation4067. intro H. specialize (H F13_0 F13_1). unfold magma_op, refa42_inst, refa42_op in H. discriminate H. Qed.

Lemma refa42_not4068 : ~ @Equation4068 Fin13 refa42_inst.
Proof. unfold Equation4068. intro H. specialize (H F13_0 F13_1). unfold magma_op, refa42_inst, refa42_op in H. discriminate H. Qed.

Lemma refa42_not4070 : ~ @Equation4070 Fin13 refa42_inst.
Proof. unfold Equation4070. intro H. specialize (H F13_0 F13_1). unfold magma_op, refa42_inst, refa42_op in H. discriminate H. Qed.

Lemma refa42_not4071 : ~ @Equation4071 Fin13 refa42_inst.
Proof. unfold Equation4071. intro H. specialize (H F13_0 F13_1). unfold magma_op, refa42_inst, refa42_op in H. discriminate H. Qed.

Lemma refa42_not4073 : ~ @Equation4073 Fin13 refa42_inst.
Proof. unfold Equation4073. intro H. specialize (H F13_0 F13_1). unfold magma_op, refa42_inst, refa42_op in H. discriminate H. Qed.

Lemma refa42_not4074 : ~ @Equation4074 Fin13 refa42_inst.
Proof. unfold Equation4074. intro H. specialize (H F13_0 F13_1). unfold magma_op, refa42_inst, refa42_op in H. discriminate H. Qed.

Lemma refa42_not4080 : ~ @Equation4080 Fin13 refa42_inst.
Proof. unfold Equation4080. intro H. specialize (H F13_0 F13_1). unfold magma_op, refa42_inst, refa42_op in H. discriminate H. Qed.

Lemma refa42_not4081 : ~ @Equation4081 Fin13 refa42_inst.
Proof. unfold Equation4081. intro H. specialize (H F13_0 F13_1). unfold magma_op, refa42_inst, refa42_op in H. discriminate H. Qed.

Lemma refa42_not4083 : ~ @Equation4083 Fin13 refa42_inst.
Proof. unfold Equation4083. intro H. specialize (H F13_0 F13_1). unfold magma_op, refa42_inst, refa42_op in H. discriminate H. Qed.

Lemma refa42_not4084 : ~ @Equation4084 Fin13 refa42_inst.
Proof. unfold Equation4084. intro H. specialize (H F13_0 F13_1). unfold magma_op, refa42_inst, refa42_op in H. discriminate H. Qed.

Lemma refa42_not4090 : ~ @Equation4090 Fin13 refa42_inst.
Proof. unfold Equation4090. intro H. specialize (H F13_0 F13_1). unfold magma_op, refa42_inst, refa42_op in H. discriminate H. Qed.

Lemma refa42_not4091 : ~ @Equation4091 Fin13 refa42_inst.
Proof. unfold Equation4091. intro H. specialize (H F13_0 F13_1). unfold magma_op, refa42_inst, refa42_op in H. discriminate H. Qed.

Lemma refa42_not4093 : ~ @Equation4093 Fin13 refa42_inst.
Proof. unfold Equation4093. intro H. specialize (H F13_0 F13_1). unfold magma_op, refa42_inst, refa42_op in H. discriminate H. Qed.

Lemma refa42_not4120 : ~ @Equation4120 Fin13 refa42_inst.
Proof. unfold Equation4120. intro H. specialize (H F13_0 F13_1). unfold magma_op, refa42_inst, refa42_op in H. discriminate H. Qed.

Lemma refa42_not4121 : ~ @Equation4121 Fin13 refa42_inst.
Proof. unfold Equation4121. intro H. specialize (H F13_0 F13_1). unfold magma_op, refa42_inst, refa42_op in H. discriminate H. Qed.

Lemma refa42_not4127 : ~ @Equation4127 Fin13 refa42_inst.
Proof. unfold Equation4127. intro H. specialize (H F13_0 F13_1). unfold magma_op, refa42_inst, refa42_op in H. discriminate H. Qed.

Lemma refa42_not4128 : ~ @Equation4128 Fin13 refa42_inst.
Proof. unfold Equation4128. intro H. specialize (H F13_0 F13_1). unfold magma_op, refa42_inst, refa42_op in H. discriminate H. Qed.

Lemma refa42_not4130 : ~ @Equation4130 Fin13 refa42_inst.
Proof. unfold Equation4130. intro H. specialize (H F13_0 F13_1). unfold magma_op, refa42_inst, refa42_op in H. discriminate H. Qed.

Lemma refa42_not4131 : ~ @Equation4131 Fin13 refa42_inst.
Proof. unfold Equation4131. intro H. specialize (H F13_0 F13_1). unfold magma_op, refa42_inst, refa42_op in H. discriminate H. Qed.

Lemma refa42_not4154 : ~ @Equation4154 Fin13 refa42_inst.
Proof. unfold Equation4154. intro H. specialize (H F13_0 F13_1). unfold magma_op, refa42_inst, refa42_op in H. discriminate H. Qed.

Lemma refa42_not4155 : ~ @Equation4155 Fin13 refa42_inst.
Proof. unfold Equation4155. intro H. specialize (H F13_0 F13_1). unfold magma_op, refa42_inst, refa42_op in H. discriminate H. Qed.

Lemma refa42_not4157 : ~ @Equation4157 Fin13 refa42_inst.
Proof. unfold Equation4157. intro H. specialize (H F13_0 F13_1). unfold magma_op, refa42_inst, refa42_op in H. discriminate H. Qed.

Lemma refa42_not4158 : ~ @Equation4158 Fin13 refa42_inst.
Proof. unfold Equation4158. intro H. specialize (H F13_0 F13_1). unfold magma_op, refa42_inst, refa42_op in H. discriminate H. Qed.

Lemma refa42_not4164 : ~ @Equation4164 Fin13 refa42_inst.
Proof. unfold Equation4164. intro H. specialize (H F13_0 F13_1). unfold magma_op, refa42_inst, refa42_op in H. discriminate H. Qed.

Lemma refa42_not4165 : ~ @Equation4165 Fin13 refa42_inst.
Proof. unfold Equation4165. intro H. specialize (H F13_0 F13_1). unfold magma_op, refa42_inst, refa42_op in H. discriminate H. Qed.

Lemma refa42_not4268 : ~ @Equation4268 Fin13 refa42_inst.
Proof. unfold Equation4268. intro H. specialize (H F13_0 F13_1). unfold magma_op, refa42_inst, refa42_op in H. discriminate H. Qed.

Lemma refa42_not4269 : ~ @Equation4269 Fin13 refa42_inst.
Proof. unfold Equation4269. intro H. specialize (H F13_0 F13_1). unfold magma_op, refa42_inst, refa42_op in H. discriminate H. Qed.

Lemma refa42_not4270 : ~ @Equation4270 Fin13 refa42_inst.
Proof. unfold Equation4270. intro H. specialize (H F13_0 F13_1). unfold magma_op, refa42_inst, refa42_op in H. discriminate H. Qed.

Lemma refa42_not4272 : ~ @Equation4272 Fin13 refa42_inst.
Proof. unfold Equation4272. intro H. specialize (H F13_0 F13_1). unfold magma_op, refa42_inst, refa42_op in H. discriminate H. Qed.

Lemma refa42_not4273 : ~ @Equation4273 Fin13 refa42_inst.
Proof. unfold Equation4273. intro H. specialize (H F13_0 F13_1). unfold magma_op, refa42_inst, refa42_op in H. discriminate H. Qed.

Lemma refa42_not4275 : ~ @Equation4275 Fin13 refa42_inst.
Proof. unfold Equation4275. intro H. specialize (H F13_0 F13_1). unfold magma_op, refa42_inst, refa42_op in H. discriminate H. Qed.

Lemma refa42_not4276 : ~ @Equation4276 Fin13 refa42_inst.
Proof. unfold Equation4276. intro H. specialize (H F13_0 F13_1). unfold magma_op, refa42_inst, refa42_op in H. discriminate H. Qed.

Lemma refa42_not4284 : ~ @Equation4284 Fin13 refa42_inst.
Proof. unfold Equation4284. intro H. specialize (H F13_0 F13_1). unfold magma_op, refa42_inst, refa42_op in H. discriminate H. Qed.

Lemma refa42_not4290 : ~ @Equation4290 Fin13 refa42_inst.
Proof. unfold Equation4290. intro H. specialize (H F13_0 F13_1). unfold magma_op, refa42_inst, refa42_op in H. discriminate H. Qed.

Lemma refa42_not4291 : ~ @Equation4291 Fin13 refa42_inst.
Proof. unfold Equation4291. intro H. specialize (H F13_0 F13_1). unfold magma_op, refa42_inst, refa42_op in H. discriminate H. Qed.

Lemma refa42_not4293 : ~ @Equation4293 Fin13 refa42_inst.
Proof. unfold Equation4293. intro H. specialize (H F13_0 F13_1). unfold magma_op, refa42_inst, refa42_op in H. discriminate H. Qed.

Lemma refa42_not4314 : ~ @Equation4314 Fin13 refa42_inst.
Proof. unfold Equation4314. intro H. specialize (H F13_0 F13_1). unfold magma_op, refa42_inst, refa42_op in H. discriminate H. Qed.

Lemma refa42_not4320 : ~ @Equation4320 Fin13 refa42_inst.
Proof. unfold Equation4320. intro H. specialize (H F13_0 F13_1). unfold magma_op, refa42_inst, refa42_op in H. discriminate H. Qed.

Lemma refa42_not4321 : ~ @Equation4321 Fin13 refa42_inst.
Proof. unfold Equation4321. intro H. specialize (H F13_0 F13_1). unfold magma_op, refa42_inst, refa42_op in H. discriminate H. Qed.

Lemma refa42_not4396 : ~ @Equation4396 Fin13 refa42_inst.
Proof. unfold Equation4396. intro H. specialize (H F13_0 F13_1). unfold magma_op, refa42_inst, refa42_op in H. discriminate H. Qed.

Lemma refa42_not4399 : ~ @Equation4399 Fin13 refa42_inst.
Proof. unfold Equation4399. intro H. specialize (H F13_0 F13_1). unfold magma_op, refa42_inst, refa42_op in H. discriminate H. Qed.

Lemma refa42_not4406 : ~ @Equation4406 Fin13 refa42_inst.
Proof. unfold Equation4406. intro H. specialize (H F13_0 F13_1). unfold magma_op, refa42_inst, refa42_op in H. discriminate H. Qed.

Lemma refa42_not4408 : ~ @Equation4408 Fin13 refa42_inst.
Proof. unfold Equation4408. intro H. specialize (H F13_0 F13_1). unfold magma_op, refa42_inst, refa42_op in H. discriminate H. Qed.

Lemma refa42_not4433 : ~ @Equation4433 Fin13 refa42_inst.
Proof. unfold Equation4433. intro H. specialize (H F13_0 F13_1). unfold magma_op, refa42_inst, refa42_op in H. discriminate H. Qed.

Lemma refa42_not4436 : ~ @Equation4436 Fin13 refa42_inst.
Proof. unfold Equation4436. intro H. specialize (H F13_0 F13_1). unfold magma_op, refa42_inst, refa42_op in H. discriminate H. Qed.

Lemma refa42_not4443 : ~ @Equation4443 Fin13 refa42_inst.
Proof. unfold Equation4443. intro H. specialize (H F13_0 F13_1). unfold magma_op, refa42_inst, refa42_op in H. discriminate H. Qed.

Lemma refa42_not4445 : ~ @Equation4445 Fin13 refa42_inst.
Proof. unfold Equation4445. intro H. specialize (H F13_0 F13_1). unfold magma_op, refa42_inst, refa42_op in H. discriminate H. Qed.

Lemma refa42_not4472 : ~ @Equation4472 Fin13 refa42_inst.
Proof. unfold Equation4472. intro H. specialize (H F13_0 F13_1). unfold magma_op, refa42_inst, refa42_op in H. discriminate H. Qed.

Lemma refa42_not4473 : ~ @Equation4473 Fin13 refa42_inst.
Proof. unfold Equation4473. intro H. specialize (H F13_0 F13_1). unfold magma_op, refa42_inst, refa42_op in H. discriminate H. Qed.

Lemma refa42_not4479 : ~ @Equation4479 Fin13 refa42_inst.
Proof. unfold Equation4479. intro H. specialize (H F13_0 F13_1). unfold magma_op, refa42_inst, refa42_op in H. discriminate H. Qed.

Lemma refa42_not4480 : ~ @Equation4480 Fin13 refa42_inst.
Proof. unfold Equation4480. intro H. specialize (H F13_0 F13_1). unfold magma_op, refa42_inst, refa42_op in H. discriminate H. Qed.

Lemma refa42_not4583 : ~ @Equation4583 Fin13 refa42_inst.
Proof. unfold Equation4583. intro H. specialize (H F13_0 F13_1). unfold magma_op, refa42_inst, refa42_op in H. discriminate H. Qed.

Lemma refa42_not4584 : ~ @Equation4584 Fin13 refa42_inst.
Proof. unfold Equation4584. intro H. specialize (H F13_0 F13_1). unfold magma_op, refa42_inst, refa42_op in H. discriminate H. Qed.

Lemma refa42_not4585 : ~ @Equation4585 Fin13 refa42_inst.
Proof. unfold Equation4585. intro H. specialize (H F13_0 F13_1). unfold magma_op, refa42_inst, refa42_op in H. discriminate H. Qed.

Lemma refa42_not4587 : ~ @Equation4587 Fin13 refa42_inst.
Proof. unfold Equation4587. intro H. specialize (H F13_0 F13_1). unfold magma_op, refa42_inst, refa42_op in H. discriminate H. Qed.

Lemma refa42_not4588 : ~ @Equation4588 Fin13 refa42_inst.
Proof. unfold Equation4588. intro H. specialize (H F13_0 F13_1). unfold magma_op, refa42_inst, refa42_op in H. discriminate H. Qed.

Lemma refa42_not4590 : ~ @Equation4590 Fin13 refa42_inst.
Proof. unfold Equation4590. intro H. specialize (H F13_0 F13_1). unfold magma_op, refa42_inst, refa42_op in H. discriminate H. Qed.

Lemma refa42_not4591 : ~ @Equation4591 Fin13 refa42_inst.
Proof. unfold Equation4591. intro H. specialize (H F13_0 F13_1). unfold magma_op, refa42_inst, refa42_op in H. discriminate H. Qed.

Lemma refa42_not4598 : ~ @Equation4598 Fin13 refa42_inst.
Proof. unfold Equation4598. intro H. specialize (H F13_0 F13_1). unfold magma_op, refa42_inst, refa42_op in H. discriminate H. Qed.

Lemma refa42_not4599 : ~ @Equation4599 Fin13 refa42_inst.
Proof. unfold Equation4599. intro H. specialize (H F13_0 F13_1). unfold magma_op, refa42_inst, refa42_op in H. discriminate H. Qed.

Lemma refa42_not4605 : ~ @Equation4605 Fin13 refa42_inst.
Proof. unfold Equation4605. intro H. specialize (H F13_0 F13_1). unfold magma_op, refa42_inst, refa42_op in H. discriminate H. Qed.

Lemma refa42_not4606 : ~ @Equation4606 Fin13 refa42_inst.
Proof. unfold Equation4606. intro H. specialize (H F13_0 F13_1). unfold magma_op, refa42_inst, refa42_op in H. discriminate H. Qed.

Lemma refa42_not4629 : ~ @Equation4629 Fin13 refa42_inst.
Proof. unfold Equation4629. intro H. specialize (H F13_0 F13_1). unfold magma_op, refa42_inst, refa42_op in H. discriminate H. Qed.

Lemma refa42_not4636 : ~ @Equation4636 Fin13 refa42_inst.
Proof. unfold Equation4636. intro H. specialize (H F13_0 F13_1). unfold magma_op, refa42_inst, refa42_op in H. discriminate H. Qed.

Lemma refa42_not4658 : ~ @Equation4658 Fin13 refa42_inst.
Proof. unfold Equation4658. intro H. specialize (H F13_0 F13_1). unfold magma_op, refa42_inst, refa42_op in H. discriminate H. Qed.

(** ---- refa420 (Fin4) ---- *)

Definition refa420_op (x y : Fin4) : Fin4 :=
  match x, y with
  | F4_0, F4_0 => F4_3 | F4_0, F4_1 => F4_1 | F4_0, F4_2 => F4_3 | F4_0, F4_3 => F4_3
  | F4_1, F4_0 => F4_3 | F4_1, F4_1 => F4_1 | F4_1, F4_2 => F4_1 | F4_1, F4_3 => F4_3
  | F4_2, F4_0 => F4_1 | F4_2, F4_1 => F4_1 | F4_2, F4_2 => F4_1 | F4_2, F4_3 => F4_3
  | F4_3, F4_0 => F4_3 | F4_3, F4_1 => F4_1 | F4_3, F4_2 => F4_1 | F4_3, F4_3 => F4_3
  end.

#[local] Instance refa420_inst : Magma Fin4 := {| magma_op := refa420_op |}.

Lemma refa420_sat3503 : @Equation3503 Fin4 refa420_inst.
Proof. unfold Equation3503, magma_op, refa420_inst, refa420_op. intros x y z w. destruct x, y, z, w; reflexivity. Qed.

Lemma refa420_not3677 : ~ @Equation3677 Fin4 refa420_inst.
Proof. unfold Equation3677. intro H. specialize (H F4_0 F4_2). unfold magma_op, refa420_inst, refa420_op in H. discriminate H. Qed.

(** ---- refa421 (Fin4) ---- *)

Definition refa421_op (x y : Fin4) : Fin4 :=
  match x, y with
  | F4_0, F4_0 => F4_2 | F4_0, F4_1 => F4_1 | F4_0, F4_2 => F4_2 | F4_0, F4_3 => F4_3
  | F4_1, F4_0 => F4_2 | F4_1, F4_1 => F4_1 | F4_1, F4_2 => F4_2 | F4_1, F4_3 => F4_3
  | F4_2, F4_0 => F4_2 | F4_2, F4_1 => F4_1 | F4_2, F4_2 => F4_2 | F4_2, F4_3 => F4_3
  | F4_3, F4_0 => F4_1 | F4_3, F4_1 => F4_1 | F4_3, F4_2 => F4_2 | F4_3, F4_3 => F4_3
  end.

#[local] Instance refa421_inst : Magma Fin4 := {| magma_op := refa421_op |}.

Lemma refa421_sat3634 : @Equation3634 Fin4 refa421_inst.
Proof. unfold Equation3634, magma_op, refa421_inst, refa421_op. intros x y z w. destruct x, y, z, w; reflexivity. Qed.

Lemma refa421_not3255 : ~ @Equation3255 Fin4 refa421_inst.
Proof. unfold Equation3255. intro H. specialize (H F4_0 F4_3). unfold magma_op, refa421_inst, refa421_op in H. discriminate H. Qed.

Lemma refa421_not3261 : ~ @Equation3261 Fin4 refa421_inst.
Proof. unfold Equation3261. intro H. specialize (H F4_0 F4_3). unfold magma_op, refa421_inst, refa421_op in H. discriminate H. Qed.

Lemma refa421_not3271 : ~ @Equation3271 Fin4 refa421_inst.
Proof. unfold Equation3271. intro H. specialize (H F4_0 F4_3). unfold magma_op, refa421_inst, refa421_op in H. discriminate H. Qed.

Lemma refa421_not3281 : ~ @Equation3281 Fin4 refa421_inst.
Proof. unfold Equation3281. intro H. specialize (H F4_0 F4_3). unfold magma_op, refa421_inst, refa421_op in H. discriminate H. Qed.

Lemma refa421_not3309 : ~ @Equation3309 Fin4 refa421_inst.
Proof. unfold Equation3309. intro H. specialize (H F4_3 F4_0). unfold magma_op, refa421_inst, refa421_op in H. discriminate H. Qed.

Lemma refa421_not3319 : ~ @Equation3319 Fin4 refa421_inst.
Proof. unfold Equation3319. intro H. specialize (H F4_3 F4_0). unfold magma_op, refa421_inst, refa421_op in H. discriminate H. Qed.

Lemma refa421_not3346 : ~ @Equation3346 Fin4 refa421_inst.
Proof. unfold Equation3346. intro H. specialize (H F4_3 F4_0). unfold magma_op, refa421_inst, refa421_op in H. discriminate H. Qed.

Lemma refa421_not3458 : ~ @Equation3458 Fin4 refa421_inst.
Proof. unfold Equation3458. intro H. specialize (H F4_0 F4_3). unfold magma_op, refa421_inst, refa421_op in H. discriminate H. Qed.

Lemma refa421_not3464 : ~ @Equation3464 Fin4 refa421_inst.
Proof. unfold Equation3464. intro H. specialize (H F4_0 F4_3). unfold magma_op, refa421_inst, refa421_op in H. discriminate H. Qed.

Lemma refa421_not3474 : ~ @Equation3474 Fin4 refa421_inst.
Proof. unfold Equation3474. intro H. specialize (H F4_0 F4_3). unfold magma_op, refa421_inst, refa421_op in H. discriminate H. Qed.

Lemma refa421_not3484 : ~ @Equation3484 Fin4 refa421_inst.
Proof. unfold Equation3484. intro H. specialize (H F4_0 F4_3). unfold magma_op, refa421_inst, refa421_op in H. discriminate H. Qed.

Lemma refa421_not3512 : ~ @Equation3512 Fin4 refa421_inst.
Proof. unfold Equation3512. intro H. specialize (H F4_3 F4_0). unfold magma_op, refa421_inst, refa421_op in H. discriminate H. Qed.

Lemma refa421_not3522 : ~ @Equation3522 Fin4 refa421_inst.
Proof. unfold Equation3522. intro H. specialize (H F4_3 F4_0). unfold magma_op, refa421_inst, refa421_op in H. discriminate H. Qed.

Lemma refa421_not3549 : ~ @Equation3549 Fin4 refa421_inst.
Proof. unfold Equation3549. intro H. specialize (H F4_3 F4_0). unfold magma_op, refa421_inst, refa421_op in H. discriminate H. Qed.

Lemma refa421_not3661 : ~ @Equation3661 Fin4 refa421_inst.
Proof. unfold Equation3661. intro H. specialize (H F4_0 F4_3). unfold magma_op, refa421_inst, refa421_op in H. discriminate H. Qed.

Lemma refa421_not3667 : ~ @Equation3667 Fin4 refa421_inst.
Proof. unfold Equation3667. intro H. specialize (H F4_0 F4_3). unfold magma_op, refa421_inst, refa421_op in H. discriminate H. Qed.

Lemma refa421_not3677 : ~ @Equation3677 Fin4 refa421_inst.
Proof. unfold Equation3677. intro H. specialize (H F4_0 F4_3). unfold magma_op, refa421_inst, refa421_op in H. discriminate H. Qed.

Lemma refa421_not3687 : ~ @Equation3687 Fin4 refa421_inst.
Proof. unfold Equation3687. intro H. specialize (H F4_0 F4_3). unfold magma_op, refa421_inst, refa421_op in H. discriminate H. Qed.

Lemma refa421_not3725 : ~ @Equation3725 Fin4 refa421_inst.
Proof. unfold Equation3725. intro H. specialize (H F4_3 F4_0). unfold magma_op, refa421_inst, refa421_op in H. discriminate H. Qed.

Lemma refa421_not3752 : ~ @Equation3752 Fin4 refa421_inst.
Proof. unfold Equation3752. intro H. specialize (H F4_3 F4_0). unfold magma_op, refa421_inst, refa421_op in H. discriminate H. Qed.

Lemma refa421_not3864 : ~ @Equation3864 Fin4 refa421_inst.
Proof. unfold Equation3864. intro H. specialize (H F4_0 F4_3). unfold magma_op, refa421_inst, refa421_op in H. discriminate H. Qed.

Lemma refa421_not3870 : ~ @Equation3870 Fin4 refa421_inst.
Proof. unfold Equation3870. intro H. specialize (H F4_0 F4_3). unfold magma_op, refa421_inst, refa421_op in H. discriminate H. Qed.

Lemma refa421_not3880 : ~ @Equation3880 Fin4 refa421_inst.
Proof. unfold Equation3880. intro H. specialize (H F4_0 F4_3). unfold magma_op, refa421_inst, refa421_op in H. discriminate H. Qed.

Lemma refa421_not3890 : ~ @Equation3890 Fin4 refa421_inst.
Proof. unfold Equation3890. intro H. specialize (H F4_0 F4_3). unfold magma_op, refa421_inst, refa421_op in H. discriminate H. Qed.

Lemma refa421_not3918 : ~ @Equation3918 Fin4 refa421_inst.
Proof. unfold Equation3918. intro H. specialize (H F4_3 F4_0). unfold magma_op, refa421_inst, refa421_op in H. discriminate H. Qed.

Lemma refa421_not3928 : ~ @Equation3928 Fin4 refa421_inst.
Proof. unfold Equation3928. intro H. specialize (H F4_3 F4_0). unfold magma_op, refa421_inst, refa421_op in H. discriminate H. Qed.

Lemma refa421_not3955 : ~ @Equation3955 Fin4 refa421_inst.
Proof. unfold Equation3955. intro H. specialize (H F4_3 F4_0). unfold magma_op, refa421_inst, refa421_op in H. discriminate H. Qed.

Lemma refa421_not4067 : ~ @Equation4067 Fin4 refa421_inst.
Proof. unfold Equation4067. intro H. specialize (H F4_0 F4_3). unfold magma_op, refa421_inst, refa421_op in H. discriminate H. Qed.

Lemma refa421_not4073 : ~ @Equation4073 Fin4 refa421_inst.
Proof. unfold Equation4073. intro H. specialize (H F4_0 F4_3). unfold magma_op, refa421_inst, refa421_op in H. discriminate H. Qed.

Lemma refa421_not4083 : ~ @Equation4083 Fin4 refa421_inst.
Proof. unfold Equation4083. intro H. specialize (H F4_0 F4_3). unfold magma_op, refa421_inst, refa421_op in H. discriminate H. Qed.

Lemma refa421_not4093 : ~ @Equation4093 Fin4 refa421_inst.
Proof. unfold Equation4093. intro H. specialize (H F4_0 F4_3). unfold magma_op, refa421_inst, refa421_op in H. discriminate H. Qed.

Lemma refa421_not4121 : ~ @Equation4121 Fin4 refa421_inst.
Proof. unfold Equation4121. intro H. specialize (H F4_3 F4_0). unfold magma_op, refa421_inst, refa421_op in H. discriminate H. Qed.

Lemma refa421_not4131 : ~ @Equation4131 Fin4 refa421_inst.
Proof. unfold Equation4131. intro H. specialize (H F4_3 F4_0). unfold magma_op, refa421_inst, refa421_op in H. discriminate H. Qed.

Lemma refa421_not4158 : ~ @Equation4158 Fin4 refa421_inst.
Proof. unfold Equation4158. intro H. specialize (H F4_3 F4_0). unfold magma_op, refa421_inst, refa421_op in H. discriminate H. Qed.

Lemma refa421_not4269 : ~ @Equation4269 Fin4 refa421_inst.
Proof. unfold Equation4269. intro H. specialize (H F4_0 F4_3). unfold magma_op, refa421_inst, refa421_op in H. discriminate H. Qed.

Lemma refa421_not4275 : ~ @Equation4275 Fin4 refa421_inst.
Proof. unfold Equation4275. intro H. specialize (H F4_0 F4_3). unfold magma_op, refa421_inst, refa421_op in H. discriminate H. Qed.

Lemma refa421_not4284 : ~ @Equation4284 Fin4 refa421_inst.
Proof. unfold Equation4284. intro H. specialize (H F4_3 F4_0). unfold magma_op, refa421_inst, refa421_op in H. discriminate H. Qed.

Lemma refa421_not4320 : ~ @Equation4320 Fin4 refa421_inst.
Proof. unfold Equation4320. intro H. specialize (H F4_0 F4_3). unfold magma_op, refa421_inst, refa421_op in H. discriminate H. Qed.

Lemma refa421_not4399 : ~ @Equation4399 Fin4 refa421_inst.
Proof. unfold Equation4399. intro H. specialize (H F4_3 F4_0). unfold magma_op, refa421_inst, refa421_op in H. discriminate H. Qed.

Lemma refa421_not4442 : ~ @Equation4442 Fin4 refa421_inst.
Proof. unfold Equation4442. intro H. specialize (H F4_0 F4_3). unfold magma_op, refa421_inst, refa421_op in H. discriminate H. Qed.

Lemma refa421_not4470 : ~ @Equation4470 Fin4 refa421_inst.
Proof. unfold Equation4470. intro H. specialize (H F4_3 F4_0). unfold magma_op, refa421_inst, refa421_op in H. discriminate H. Qed.

Lemma refa421_not4480 : ~ @Equation4480 Fin4 refa421_inst.
Proof. unfold Equation4480. intro H. specialize (H F4_3 F4_0). unfold magma_op, refa421_inst, refa421_op in H. discriminate H. Qed.

Lemma refa421_not4599 : ~ @Equation4599 Fin4 refa421_inst.
Proof. unfold Equation4599. intro H. specialize (H F4_3 F4_0). unfold magma_op, refa421_inst, refa421_op in H. discriminate H. Qed.

Lemma refa421_not4622 : ~ @Equation4622 Fin4 refa421_inst.
Proof. unfold Equation4622. intro H. specialize (H F4_0 F4_0 F4_3). unfold magma_op, refa421_inst, refa421_op in H. discriminate H. Qed.

Lemma refa421_not4631 : ~ @Equation4631 Fin4 refa421_inst.
Proof. unfold Equation4631. intro H. specialize (H F4_0 F4_0 F4_3). unfold magma_op, refa421_inst, refa421_op in H. discriminate H. Qed.

Lemma refa421_not4635 : ~ @Equation4635 Fin4 refa421_inst.
Proof. unfold Equation4635. intro H. specialize (H F4_0 F4_3). unfold magma_op, refa421_inst, refa421_op in H. discriminate H. Qed.

(** ---- refa422 (Fin4) ---- *)

Definition refa422_op (x y : Fin4) : Fin4 :=
  match x, y with
  | F4_0, F4_0 => F4_2 | F4_0, F4_1 => F4_1 | F4_0, F4_2 => F4_2 | F4_0, F4_3 => F4_3
  | F4_1, F4_0 => F4_3 | F4_1, F4_1 => F4_3 | F4_1, F4_2 => F4_3 | F4_1, F4_3 => F4_2
  | F4_2, F4_0 => F4_0 | F4_2, F4_1 => F4_0 | F4_2, F4_2 => F4_0 | F4_2, F4_3 => F4_0
  | F4_3, F4_0 => F4_1 | F4_3, F4_1 => F4_2 | F4_3, F4_2 => F4_1 | F4_3, F4_3 => F4_1
  end.

#[local] Instance refa422_inst : Magma Fin4 := {| magma_op := refa422_op |}.

Lemma refa422_sat3056 : @Equation3056 Fin4 refa422_inst.
Proof. unfold Equation3056, magma_op, refa422_inst, refa422_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa422_not3068 : ~ @Equation3068 Fin4 refa422_inst.
Proof. unfold Equation3068. intro H. specialize (H F4_1 F4_3). unfold magma_op, refa422_inst, refa422_op in H. discriminate H. Qed.

(** ---- refa423 (Fin4) ---- *)

Definition refa423_op (x y : Fin4) : Fin4 :=
  match x, y with
  | F4_0, F4_0 => F4_3 | F4_0, F4_1 => F4_2 | F4_0, F4_2 => F4_3 | F4_0, F4_3 => F4_1
  | F4_1, F4_0 => F4_2 | F4_1, F4_1 => F4_2 | F4_1, F4_2 => F4_3 | F4_1, F4_3 => F4_0
  | F4_2, F4_0 => F4_2 | F4_2, F4_1 => F4_0 | F4_2, F4_2 => F4_1 | F4_2, F4_3 => F4_1
  | F4_3, F4_0 => F4_2 | F4_3, F4_1 => F4_0 | F4_3, F4_2 => F4_1 | F4_3, F4_3 => F4_0
  end.

#[local] Instance refa423_inst : Magma Fin4 := {| magma_op := refa423_op |}.

Lemma refa423_sat1434 : @Equation1434 Fin4 refa423_inst.
Proof. unfold Equation1434, magma_op, refa423_inst, refa423_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa423_not4065 : ~ @Equation4065 Fin4 refa423_inst.
Proof. unfold Equation4065. intro H. specialize (H F4_0). unfold magma_op, refa423_inst, refa423_op in H. discriminate H. Qed.

(** ---- refa424 (Fin4) ---- *)

Definition refa424_op (x y : Fin4) : Fin4 :=
  match x, y with
  | F4_0, F4_0 => F4_1 | F4_0, F4_1 => F4_1 | F4_0, F4_2 => F4_2 | F4_0, F4_3 => F4_1
  | F4_1, F4_0 => F4_3 | F4_1, F4_1 => F4_1 | F4_1, F4_2 => F4_2 | F4_1, F4_3 => F4_0
  | F4_2, F4_0 => F4_3 | F4_2, F4_1 => F4_1 | F4_2, F4_2 => F4_2 | F4_2, F4_3 => F4_0
  | F4_3, F4_0 => F4_1 | F4_3, F4_1 => F4_1 | F4_3, F4_2 => F4_2 | F4_3, F4_3 => F4_2
  end.

#[local] Instance refa424_inst : Magma Fin4 := {| magma_op := refa424_op |}.

Lemma refa424_sat1650 : @Equation1650 Fin4 refa424_inst.
Proof. unfold Equation1650, magma_op, refa424_inst, refa424_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa424_not4065 : ~ @Equation4065 Fin4 refa424_inst.
Proof. unfold Equation4065. intro H. specialize (H F4_3). unfold magma_op, refa424_inst, refa424_op in H. discriminate H. Qed.

(** ---- refa425 (Fin4) ---- *)

Definition refa425_op (x y : Fin4) : Fin4 :=
  match x, y with
  | F4_0, F4_0 => F4_2 | F4_0, F4_1 => F4_2 | F4_0, F4_2 => F4_3 | F4_0, F4_3 => F4_3
  | F4_1, F4_0 => F4_3 | F4_1, F4_1 => F4_3 | F4_1, F4_2 => F4_2 | F4_1, F4_3 => F4_2
  | F4_2, F4_0 => F4_1 | F4_2, F4_1 => F4_1 | F4_2, F4_2 => F4_0 | F4_2, F4_3 => F4_0
  | F4_3, F4_0 => F4_0 | F4_3, F4_1 => F4_0 | F4_3, F4_2 => F4_1 | F4_3, F4_3 => F4_1
  end.

#[local] Instance refa425_inst : Magma Fin4 := {| magma_op := refa425_op |}.

Lemma refa425_sat161 : @Equation161 Fin4 refa425_inst.
Proof. unfold Equation161, magma_op, refa425_inst, refa425_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa425_sat3083 : @Equation3083 Fin4 refa425_inst.
Proof. unfold Equation3083, magma_op, refa425_inst, refa425_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa425_sat3091 : @Equation3091 Fin4 refa425_inst.
Proof. unfold Equation3091, magma_op, refa425_inst, refa425_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa425_not211 : ~ @Equation211 Fin4 refa425_inst.
Proof. unfold Equation211. intro H. specialize (H F4_0 F4_2). unfold magma_op, refa425_inst, refa425_op in H. discriminate H. Qed.

Lemma refa425_not1431 : ~ @Equation1431 Fin4 refa425_inst.
Proof. unfold Equation1431. intro H. specialize (H F4_0 F4_2). unfold magma_op, refa425_inst, refa425_op in H. discriminate H. Qed.

Lemma refa425_not1434 : ~ @Equation1434 Fin4 refa425_inst.
Proof. unfold Equation1434. intro H. specialize (H F4_0 F4_2). unfold magma_op, refa425_inst, refa425_op in H. discriminate H. Qed.

Lemma refa425_not1435 : ~ @Equation1435 Fin4 refa425_inst.
Proof. unfold Equation1435. intro H. specialize (H F4_0 F4_2). unfold magma_op, refa425_inst, refa425_op in H. discriminate H. Qed.

Lemma refa425_not1441 : ~ @Equation1441 Fin4 refa425_inst.
Proof. unfold Equation1441. intro H. specialize (H F4_0 F4_2). unfold magma_op, refa425_inst, refa425_op in H. discriminate H. Qed.

Lemma refa425_not1445 : ~ @Equation1445 Fin4 refa425_inst.
Proof. unfold Equation1445. intro H. specialize (H F4_0 F4_2). unfold magma_op, refa425_inst, refa425_op in H. discriminate H. Qed.

Lemma refa425_not1629 : ~ @Equation1629 Fin4 refa425_inst.
Proof. unfold Equation1629. intro H. specialize (H F4_0). unfold magma_op, refa425_inst, refa425_op in H. discriminate H. Qed.

Lemma refa425_not1832 : ~ @Equation1832 Fin4 refa425_inst.
Proof. unfold Equation1832. intro H. specialize (H F4_0). unfold magma_op, refa425_inst, refa425_op in H. discriminate H. Qed.

Lemma refa425_not2244 : ~ @Equation2244 Fin4 refa425_inst.
Proof. unfold Equation2244. intro H. specialize (H F4_0 F4_2). unfold magma_op, refa425_inst, refa425_op in H. discriminate H. Qed.

Lemma refa425_not2247 : ~ @Equation2247 Fin4 refa425_inst.
Proof. unfold Equation2247. intro H. specialize (H F4_0 F4_2). unfold magma_op, refa425_inst, refa425_op in H. discriminate H. Qed.

Lemma refa425_not2253 : ~ @Equation2253 Fin4 refa425_inst.
Proof. unfold Equation2253. intro H. specialize (H F4_0 F4_2). unfold magma_op, refa425_inst, refa425_op in H. discriminate H. Qed.

Lemma refa425_not2256 : ~ @Equation2256 Fin4 refa425_inst.
Proof. unfold Equation2256. intro H. specialize (H F4_0 F4_2). unfold magma_op, refa425_inst, refa425_op in H. discriminate H. Qed.

Lemma refa425_not2266 : ~ @Equation2266 Fin4 refa425_inst.
Proof. unfold Equation2266. intro H. specialize (H F4_0 F4_2). unfold magma_op, refa425_inst, refa425_op in H. discriminate H. Qed.

Lemma refa425_not2441 : ~ @Equation2441 Fin4 refa425_inst.
Proof. unfold Equation2441. intro H. specialize (H F4_0). unfold magma_op, refa425_inst, refa425_op in H. discriminate H. Qed.

Lemma refa425_not3052 : ~ @Equation3052 Fin4 refa425_inst.
Proof. unfold Equation3052. intro H. specialize (H F4_0 F4_2). unfold magma_op, refa425_inst, refa425_op in H. discriminate H. Qed.

Lemma refa425_not3055 : ~ @Equation3055 Fin4 refa425_inst.
Proof. unfold Equation3055. intro H. specialize (H F4_0 F4_2). unfold magma_op, refa425_inst, refa425_op in H. discriminate H. Qed.

Lemma refa425_not3065 : ~ @Equation3065 Fin4 refa425_inst.
Proof. unfold Equation3065. intro H. specialize (H F4_0 F4_2). unfold magma_op, refa425_inst, refa425_op in H. discriminate H. Qed.

Lemma refa425_not3069 : ~ @Equation3069 Fin4 refa425_inst.
Proof. unfold Equation3069. intro H. specialize (H F4_0 F4_2). unfold magma_op, refa425_inst, refa425_op in H. discriminate H. Qed.

Lemma refa425_not3076 : ~ @Equation3076 Fin4 refa425_inst.
Proof. unfold Equation3076. intro H. specialize (H F4_0 F4_2). unfold magma_op, refa425_inst, refa425_op in H. discriminate H. Qed.

Lemma refa425_not3253 : ~ @Equation3253 Fin4 refa425_inst.
Proof. unfold Equation3253. intro H. specialize (H F4_0). unfold magma_op, refa425_inst, refa425_op in H. discriminate H. Qed.

Lemma refa425_not3461 : ~ @Equation3461 Fin4 refa425_inst.
Proof. unfold Equation3461. intro H. specialize (H F4_0 F4_2). unfold magma_op, refa425_inst, refa425_op in H. discriminate H. Qed.

Lemma refa425_not3462 : ~ @Equation3462 Fin4 refa425_inst.
Proof. unfold Equation3462. intro H. specialize (H F4_0 F4_2). unfold magma_op, refa425_inst, refa425_op in H. discriminate H. Qed.

Lemma refa425_not3464 : ~ @Equation3464 Fin4 refa425_inst.
Proof. unfold Equation3464. intro H. specialize (H F4_0 F4_2). unfold magma_op, refa425_inst, refa425_op in H. discriminate H. Qed.

Lemma refa425_not3465 : ~ @Equation3465 Fin4 refa425_inst.
Proof. unfold Equation3465. intro H. specialize (H F4_0 F4_2). unfold magma_op, refa425_inst, refa425_op in H. discriminate H. Qed.

Lemma refa425_not3509 : ~ @Equation3509 Fin4 refa425_inst.
Proof. unfold Equation3509. intro H. specialize (H F4_0 F4_2). unfold magma_op, refa425_inst, refa425_op in H. discriminate H. Qed.

Lemma refa425_not3511 : ~ @Equation3511 Fin4 refa425_inst.
Proof. unfold Equation3511. intro H. specialize (H F4_0 F4_2). unfold magma_op, refa425_inst, refa425_op in H. discriminate H. Qed.

Lemma refa425_not3512 : ~ @Equation3512 Fin4 refa425_inst.
Proof. unfold Equation3512. intro H. specialize (H F4_0 F4_2). unfold magma_op, refa425_inst, refa425_op in H. discriminate H. Qed.

Lemma refa425_not3659 : ~ @Equation3659 Fin4 refa425_inst.
Proof. unfold Equation3659. intro H. specialize (H F4_0). unfold magma_op, refa425_inst, refa425_op in H. discriminate H. Qed.

Lemma refa425_not4065 : ~ @Equation4065 Fin4 refa425_inst.
Proof. unfold Equation4065. intro H. specialize (H F4_0). unfold magma_op, refa425_inst, refa425_op in H. discriminate H. Qed.

Lemma refa425_not4269 : ~ @Equation4269 Fin4 refa425_inst.
Proof. unfold Equation4269. intro H. specialize (H F4_0 F4_2). unfold magma_op, refa425_inst, refa425_op in H. discriminate H. Qed.

Lemma refa425_not4270 : ~ @Equation4270 Fin4 refa425_inst.
Proof. unfold Equation4270. intro H. specialize (H F4_0 F4_2). unfold magma_op, refa425_inst, refa425_op in H. discriminate H. Qed.

Lemma refa425_not4283 : ~ @Equation4283 Fin4 refa425_inst.
Proof. unfold Equation4283. intro H. specialize (H F4_0 F4_2). unfold magma_op, refa425_inst, refa425_op in H. discriminate H. Qed.

Lemma refa425_not4284 : ~ @Equation4284 Fin4 refa425_inst.
Proof. unfold Equation4284. intro H. specialize (H F4_0 F4_2). unfold magma_op, refa425_inst, refa425_op in H. discriminate H. Qed.

Lemma refa425_not4583 : ~ @Equation4583 Fin4 refa425_inst.
Proof. unfold Equation4583. intro H. specialize (H F4_0 F4_2). unfold magma_op, refa425_inst, refa425_op in H. discriminate H. Qed.

Lemma refa425_not4584 : ~ @Equation4584 Fin4 refa425_inst.
Proof. unfold Equation4584. intro H. specialize (H F4_0 F4_2). unfold magma_op, refa425_inst, refa425_op in H. discriminate H. Qed.

Lemma refa425_not4599 : ~ @Equation4599 Fin4 refa425_inst.
Proof. unfold Equation4599. intro H. specialize (H F4_0 F4_2). unfold magma_op, refa425_inst, refa425_op in H. discriminate H. Qed.

Lemma refa425_not4629 : ~ @Equation4629 Fin4 refa425_inst.
Proof. unfold Equation4629. intro H. specialize (H F4_0 F4_2). unfold magma_op, refa425_inst, refa425_op in H. discriminate H. Qed.

(** ---- refa426 (Fin4) ---- *)

Definition refa426_op (x y : Fin4) : Fin4 :=
  match x, y with
  | F4_0, F4_0 => F4_0 | F4_0, F4_1 => F4_3 | F4_0, F4_2 => F4_3 | F4_0, F4_3 => F4_3
  | F4_1, F4_0 => F4_1 | F4_1, F4_1 => F4_1 | F4_1, F4_2 => F4_2 | F4_1, F4_3 => F4_2
  | F4_2, F4_0 => F4_1 | F4_2, F4_1 => F4_1 | F4_2, F4_2 => F4_2 | F4_2, F4_3 => F4_2
  | F4_3, F4_0 => F4_0 | F4_3, F4_1 => F4_3 | F4_3, F4_2 => F4_3 | F4_3, F4_3 => F4_3
  end.

#[local] Instance refa426_inst : Magma Fin4 := {| magma_op := refa426_op |}.

Lemma refa426_sat3736 : @Equation3736 Fin4 refa426_inst.
Proof. unfold Equation3736, magma_op, refa426_inst, refa426_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa426_not3316 : ~ @Equation3316 Fin4 refa426_inst.
Proof. unfold Equation3316. intro H. specialize (H F4_1 F4_0). unfold magma_op, refa426_inst, refa426_op in H. discriminate H. Qed.

(** ---- refa427 (Fin4) ---- *)

Definition refa427_op (x y : Fin4) : Fin4 :=
  match x, y with
  | F4_0, F4_0 => F4_3 | F4_0, F4_1 => F4_3 | F4_0, F4_2 => F4_1 | F4_0, F4_3 => F4_3
  | F4_1, F4_0 => F4_3 | F4_1, F4_1 => F4_3 | F4_1, F4_2 => F4_3 | F4_1, F4_3 => F4_3
  | F4_2, F4_0 => F4_2 | F4_2, F4_1 => F4_3 | F4_2, F4_2 => F4_3 | F4_2, F4_3 => F4_3
  | F4_3, F4_0 => F4_3 | F4_3, F4_1 => F4_0 | F4_3, F4_2 => F4_3 | F4_3, F4_3 => F4_3
  end.

#[local] Instance refa427_inst : Magma Fin4 := {| magma_op := refa427_op |}.

Lemma refa427_sat317 : @Equation317 Fin4 refa427_inst.
Proof. unfold Equation317, magma_op, refa427_inst, refa427_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa427_not3264 : ~ @Equation3264 Fin4 refa427_inst.
Proof. unfold Equation3264. intro H. specialize (H F4_2 F4_3 F4_0). unfold magma_op, refa427_inst, refa427_op in H. discriminate H. Qed.

(** ---- refa428 (Fin4) ---- *)

Definition refa428_op (x y : Fin4) : Fin4 :=
  match x, y with
  | F4_0, F4_0 => F4_3 | F4_0, F4_1 => F4_0 | F4_0, F4_2 => F4_3 | F4_0, F4_3 => F4_1
  | F4_1, F4_0 => F4_2 | F4_1, F4_1 => F4_3 | F4_1, F4_2 => F4_1 | F4_1, F4_3 => F4_2
  | F4_2, F4_0 => F4_1 | F4_2, F4_1 => F4_2 | F4_2, F4_2 => F4_3 | F4_2, F4_3 => F4_1
  | F4_3, F4_0 => F4_3 | F4_3, F4_1 => F4_3 | F4_3, F4_2 => F4_3 | F4_3, F4_3 => F4_3
  end.

#[local] Instance refa428_inst : Magma Fin4 := {| magma_op := refa428_op |}.

Lemma refa428_sat624 : @Equation624 Fin4 refa428_inst.
Proof. unfold Equation624, magma_op, refa428_inst, refa428_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa428_not620 : ~ @Equation620 Fin4 refa428_inst.
Proof. unfold Equation620. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa428_inst, refa428_op in H. discriminate H. Qed.

Lemma refa428_not1020 : ~ @Equation1020 Fin4 refa428_inst.
Proof. unfold Equation1020. intro H. specialize (H F4_0). unfold magma_op, refa428_inst, refa428_op in H. discriminate H. Qed.

Lemma refa428_not1832 : ~ @Equation1832 Fin4 refa428_inst.
Proof. unfold Equation1832. intro H. specialize (H F4_0). unfold magma_op, refa428_inst, refa428_op in H. discriminate H. Qed.

(** ---- refa429 (Fin4) ---- *)

Definition refa429_op (x y : Fin4) : Fin4 :=
  match x, y with
  | F4_0, F4_0 => F4_2 | F4_0, F4_1 => F4_2 | F4_0, F4_2 => F4_0 | F4_0, F4_3 => F4_3
  | F4_1, F4_0 => F4_2 | F4_1, F4_1 => F4_2 | F4_1, F4_2 => F4_0 | F4_1, F4_3 => F4_3
  | F4_2, F4_0 => F4_0 | F4_2, F4_1 => F4_1 | F4_2, F4_2 => F4_2 | F4_2, F4_3 => F4_3
  | F4_3, F4_0 => F4_0 | F4_3, F4_1 => F4_0 | F4_3, F4_2 => F4_3 | F4_3, F4_3 => F4_2
  end.

#[local] Instance refa429_inst : Magma Fin4 := {| magma_op := refa429_op |}.

Lemma refa429_sat2964 : @Equation2964 Fin4 refa429_inst.
Proof. unfold Equation2964, magma_op, refa429_inst, refa429_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa429_not2530 : ~ @Equation2530 Fin4 refa429_inst.
Proof. unfold Equation2530. intro H. specialize (H F4_1 F4_3). unfold magma_op, refa429_inst, refa429_op in H. discriminate H. Qed.

Lemma refa429_not2699 : ~ @Equation2699 Fin4 refa429_inst.
Proof. unfold Equation2699. intro H. specialize (H F4_1 F4_3). unfold magma_op, refa429_inst, refa429_op in H. discriminate H. Qed.

Lemma refa429_not2865 : ~ @Equation2865 Fin4 refa429_inst.
Proof. unfold Equation2865. intro H. specialize (H F4_1 F4_3). unfold magma_op, refa429_inst, refa429_op in H. discriminate H. Qed.

Lemma refa429_not3068 : ~ @Equation3068 Fin4 refa429_inst.
Proof. unfold Equation3068. intro H. specialize (H F4_1 F4_3). unfold magma_op, refa429_inst, refa429_op in H. discriminate H. Qed.

Lemma refa429_not3105 : ~ @Equation3105 Fin4 refa429_inst.
Proof. unfold Equation3105. intro H. specialize (H F4_1 F4_3). unfold magma_op, refa429_inst, refa429_op in H. discriminate H. Qed.

Lemma refa429_not3955 : ~ @Equation3955 Fin4 refa429_inst.
Proof. unfold Equation3955. intro H. specialize (H F4_3 F4_1). unfold magma_op, refa429_inst, refa429_op in H. discriminate H. Qed.

Lemma refa429_not4131 : ~ @Equation4131 Fin4 refa429_inst.
Proof. unfold Equation4131. intro H. specialize (H F4_3 F4_1). unfold magma_op, refa429_inst, refa429_op in H. discriminate H. Qed.

(** ---- refa43 (Fin5) ---- *)

Definition refa43_op (x y : Fin5) : Fin5 :=
  match x, y with
  | F5_0, F5_0 => F5_0 | F5_0, F5_1 => F5_2 | F5_0, F5_2 => F5_3 | F5_0, F5_3 => F5_0 | F5_0, F5_4 => F5_0
  | F5_1, F5_0 => F5_4 | F5_1, F5_1 => F5_1 | F5_1, F5_2 => F5_4 | F5_1, F5_3 => F5_4 | F5_1, F5_4 => F5_1
  | F5_2, F5_0 => F5_2 | F5_2, F5_1 => F5_2 | F5_2, F5_2 => F5_2 | F5_2, F5_3 => F5_2 | F5_2, F5_4 => F5_2
  | F5_3, F5_0 => F5_3 | F5_3, F5_1 => F5_3 | F5_3, F5_2 => F5_3 | F5_3, F5_3 => F5_3 | F5_3, F5_4 => F5_3
  | F5_4, F5_0 => F5_4 | F5_4, F5_1 => F5_4 | F5_4, F5_2 => F5_4 | F5_4, F5_3 => F5_4 | F5_4, F5_4 => F5_4
  end.

#[local] Instance refa43_inst : Magma Fin5 := {| magma_op := refa43_op |}.

Lemma refa43_sat418 : @Equation418 Fin5 refa43_inst.
Proof. unfold Equation418, magma_op, refa43_inst, refa43_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa43_not50 : ~ @Equation50 Fin5 refa43_inst.
Proof. unfold Equation50. intro H. specialize (H F5_0 F5_1). unfold magma_op, refa43_inst, refa43_op in H. discriminate H. Qed.

Lemma refa43_not101 : ~ @Equation101 Fin5 refa43_inst.
Proof. unfold Equation101. intro H. specialize (H F5_0 F5_1). unfold magma_op, refa43_inst, refa43_op in H. discriminate H. Qed.

Lemma refa43_not325 : ~ @Equation325 Fin5 refa43_inst.
Proof. unfold Equation325. intro H. specialize (H F5_0 F5_1). unfold magma_op, refa43_inst, refa43_op in H. discriminate H. Qed.

Lemma refa43_not419 : ~ @Equation419 Fin5 refa43_inst.
Proof. unfold Equation419. intro H. specialize (H F5_0 F5_1). unfold magma_op, refa43_inst, refa43_op in H. discriminate H. Qed.

Lemma refa43_not420 : ~ @Equation420 Fin5 refa43_inst.
Proof. unfold Equation420. intro H. specialize (H F5_0 F5_1). unfold magma_op, refa43_inst, refa43_op in H. discriminate H. Qed.

Lemma refa43_not623 : ~ @Equation623 Fin5 refa43_inst.
Proof. unfold Equation623. intro H. specialize (H F5_0 F5_1). unfold magma_op, refa43_inst, refa43_op in H. discriminate H. Qed.

Lemma refa43_not820 : ~ @Equation820 Fin5 refa43_inst.
Proof. unfold Equation820. intro H. specialize (H F5_0 F5_1). unfold magma_op, refa43_inst, refa43_op in H. discriminate H. Qed.

Lemma refa43_not823 : ~ @Equation823 Fin5 refa43_inst.
Proof. unfold Equation823. intro H. specialize (H F5_0 F5_1). unfold magma_op, refa43_inst, refa43_op in H. discriminate H. Qed.

Lemma refa43_not825 : ~ @Equation825 Fin5 refa43_inst.
Proof. unfold Equation825. intro H. specialize (H F5_0 F5_1). unfold magma_op, refa43_inst, refa43_op in H. discriminate H. Qed.

Lemma refa43_not826 : ~ @Equation826 Fin5 refa43_inst.
Proof. unfold Equation826. intro H. specialize (H F5_0 F5_1). unfold magma_op, refa43_inst, refa43_op in H. discriminate H. Qed.

Lemma refa43_not1021 : ~ @Equation1021 Fin5 refa43_inst.
Proof. unfold Equation1021. intro H. specialize (H F5_0 F5_1). unfold magma_op, refa43_inst, refa43_op in H. discriminate H. Qed.

Lemma refa43_not1026 : ~ @Equation1026 Fin5 refa43_inst.
Proof. unfold Equation1026. intro H. specialize (H F5_0 F5_1). unfold magma_op, refa43_inst, refa43_op in H. discriminate H. Qed.

Lemma refa43_not1029 : ~ @Equation1029 Fin5 refa43_inst.
Proof. unfold Equation1029. intro H. specialize (H F5_0 F5_1). unfold magma_op, refa43_inst, refa43_op in H. discriminate H. Qed.

Lemma refa43_not1224 : ~ @Equation1224 Fin5 refa43_inst.
Proof. unfold Equation1224. intro H. specialize (H F5_0 F5_1). unfold magma_op, refa43_inst, refa43_op in H. discriminate H. Qed.

Lemma refa43_not1226 : ~ @Equation1226 Fin5 refa43_inst.
Proof. unfold Equation1226. intro H. specialize (H F5_0 F5_1). unfold magma_op, refa43_inst, refa43_op in H. discriminate H. Qed.

Lemma refa43_not1228 : ~ @Equation1228 Fin5 refa43_inst.
Proof. unfold Equation1228. intro H. specialize (H F5_0 F5_1). unfold magma_op, refa43_inst, refa43_op in H. discriminate H. Qed.

Lemma refa43_not1232 : ~ @Equation1232 Fin5 refa43_inst.
Proof. unfold Equation1232. intro H. specialize (H F5_0 F5_1). unfold magma_op, refa43_inst, refa43_op in H. discriminate H. Qed.

Lemma refa43_not1429 : ~ @Equation1429 Fin5 refa43_inst.
Proof. unfold Equation1429. intro H. specialize (H F5_0 F5_1). unfold magma_op, refa43_inst, refa43_op in H. discriminate H. Qed.

Lemma refa43_not1630 : ~ @Equation1630 Fin5 refa43_inst.
Proof. unfold Equation1630. intro H. specialize (H F5_0 F5_1). unfold magma_op, refa43_inst, refa43_op in H. discriminate H. Qed.

Lemma refa43_not1632 : ~ @Equation1632 Fin5 refa43_inst.
Proof. unfold Equation1632. intro H. specialize (H F5_0 F5_1). unfold magma_op, refa43_inst, refa43_op in H. discriminate H. Qed.

Lemma refa43_not1833 : ~ @Equation1833 Fin5 refa43_inst.
Proof. unfold Equation1833. intro H. specialize (H F5_0 F5_1). unfold magma_op, refa43_inst, refa43_op in H. discriminate H. Qed.

Lemma refa43_not1837 : ~ @Equation1837 Fin5 refa43_inst.
Proof. unfold Equation1837. intro H. specialize (H F5_0 F5_1). unfold magma_op, refa43_inst, refa43_op in H. discriminate H. Qed.

Lemma refa43_not1838 : ~ @Equation1838 Fin5 refa43_inst.
Proof. unfold Equation1838. intro H. specialize (H F5_0 F5_1). unfold magma_op, refa43_inst, refa43_op in H. discriminate H. Qed.

Lemma refa43_not2036 : ~ @Equation2036 Fin5 refa43_inst.
Proof. unfold Equation2036. intro H. specialize (H F5_0 F5_1). unfold magma_op, refa43_inst, refa43_op in H. discriminate H. Qed.

Lemma refa43_not2246 : ~ @Equation2246 Fin5 refa43_inst.
Proof. unfold Equation2246. intro H. specialize (H F5_0 F5_1). unfold magma_op, refa43_inst, refa43_op in H. discriminate H. Qed.

Lemma refa43_not2443 : ~ @Equation2443 Fin5 refa43_inst.
Proof. unfold Equation2443. intro H. specialize (H F5_0 F5_1). unfold magma_op, refa43_inst, refa43_op in H. discriminate H. Qed.

Lemma refa43_not2449 : ~ @Equation2449 Fin5 refa43_inst.
Proof. unfold Equation2449. intro H. specialize (H F5_0 F5_1). unfold magma_op, refa43_inst, refa43_op in H. discriminate H. Qed.

Lemma refa43_not2646 : ~ @Equation2646 Fin5 refa43_inst.
Proof. unfold Equation2646. intro H. specialize (H F5_0 F5_1). unfold magma_op, refa43_inst, refa43_op in H. discriminate H. Qed.

Lemma refa43_not2852 : ~ @Equation2852 Fin5 refa43_inst.
Proof. unfold Equation2852. intro H. specialize (H F5_0 F5_1). unfold magma_op, refa43_inst, refa43_op in H. discriminate H. Qed.

Lemma refa43_not3256 : ~ @Equation3256 Fin5 refa43_inst.
Proof. unfold Equation3256. intro H. specialize (H F5_0 F5_1). unfold magma_op, refa43_inst, refa43_op in H. discriminate H. Qed.

Lemma refa43_not3457 : ~ @Equation3457 Fin5 refa43_inst.
Proof. unfold Equation3457. intro H. specialize (H F5_0 F5_1). unfold magma_op, refa43_inst, refa43_op in H. discriminate H. Qed.

Lemma refa43_not3459 : ~ @Equation3459 Fin5 refa43_inst.
Proof. unfold Equation3459. intro H. specialize (H F5_0 F5_1). unfold magma_op, refa43_inst, refa43_op in H. discriminate H. Qed.

Lemma refa43_not3660 : ~ @Equation3660 Fin5 refa43_inst.
Proof. unfold Equation3660. intro H. specialize (H F5_0 F5_1). unfold magma_op, refa43_inst, refa43_op in H. discriminate H. Qed.

Lemma refa43_not3864 : ~ @Equation3864 Fin5 refa43_inst.
Proof. unfold Equation3864. intro H. specialize (H F5_0 F5_1). unfold magma_op, refa43_inst, refa43_op in H. discriminate H. Qed.

Lemma refa43_not3918 : ~ @Equation3918 Fin5 refa43_inst.
Proof. unfold Equation3918. intro H. specialize (H F5_0 F5_1). unfold magma_op, refa43_inst, refa43_op in H. discriminate H. Qed.

Lemma refa43_not4268 : ~ @Equation4268 Fin5 refa43_inst.
Proof. unfold Equation4268. intro H. specialize (H F5_0 F5_1). unfold magma_op, refa43_inst, refa43_op in H. discriminate H. Qed.

(** ---- refa430 (Fin4) ---- *)

Definition refa430_op (x y : Fin4) : Fin4 :=
  match x, y with
  | F4_0, F4_0 => F4_1 | F4_0, F4_1 => F4_0 | F4_0, F4_2 => F4_3 | F4_0, F4_3 => F4_1
  | F4_1, F4_0 => F4_3 | F4_1, F4_1 => F4_1 | F4_1, F4_2 => F4_0 | F4_1, F4_3 => F4_3
  | F4_2, F4_0 => F4_1 | F4_2, F4_1 => F4_2 | F4_2, F4_2 => F4_1 | F4_2, F4_3 => F4_0
  | F4_3, F4_0 => F4_2 | F4_3, F4_1 => F4_3 | F4_3, F4_2 => F4_2 | F4_3, F4_3 => F4_1
  end.

#[local] Instance refa430_inst : Magma Fin4 := {| magma_op := refa430_op |}.

Lemma refa430_sat655 : @Equation655 Fin4 refa430_inst.
Proof. unfold Equation655, magma_op, refa430_inst, refa430_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa430_not417 : ~ @Equation417 Fin4 refa430_inst.
Proof. unfold Equation417. intro H. specialize (H F4_3 F4_2). unfold magma_op, refa430_inst, refa430_op in H. discriminate H. Qed.

Lemma refa430_not419 : ~ @Equation419 Fin4 refa430_inst.
Proof. unfold Equation419. intro H. specialize (H F4_0 F4_2). unfold magma_op, refa430_inst, refa430_op in H. discriminate H. Qed.

Lemma refa430_not427 : ~ @Equation427 Fin4 refa430_inst.
Proof. unfold Equation427. intro H. specialize (H F4_0 F4_2). unfold magma_op, refa430_inst, refa430_op in H. discriminate H. Qed.

Lemma refa430_not429 : ~ @Equation429 Fin4 refa430_inst.
Proof. unfold Equation429. intro H. specialize (H F4_2 F4_3). unfold magma_op, refa430_inst, refa430_op in H. discriminate H. Qed.

Lemma refa430_not617 : ~ @Equation617 Fin4 refa430_inst.
Proof. unfold Equation617. intro H. specialize (H F4_0 F4_2). unfold magma_op, refa430_inst, refa430_op in H. discriminate H. Qed.

Lemma refa430_not639 : ~ @Equation639 Fin4 refa430_inst.
Proof. unfold Equation639. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa430_inst, refa430_op in H. discriminate H. Qed.

Lemma refa430_not825 : ~ @Equation825 Fin4 refa430_inst.
Proof. unfold Equation825. intro H. specialize (H F4_0 F4_2). unfold magma_op, refa430_inst, refa430_op in H. discriminate H. Qed.

Lemma refa430_not833 : ~ @Equation833 Fin4 refa430_inst.
Proof. unfold Equation833. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa430_inst, refa430_op in H. discriminate H. Qed.

Lemma refa430_not1023 : ~ @Equation1023 Fin4 refa430_inst.
Proof. unfold Equation1023. intro H. specialize (H F4_0 F4_2). unfold magma_op, refa430_inst, refa430_op in H. discriminate H. Qed.

Lemma refa430_not1026 : ~ @Equation1026 Fin4 refa430_inst.
Proof. unfold Equation1026. intro H. specialize (H F4_0 F4_2). unfold magma_op, refa430_inst, refa430_op in H. discriminate H. Qed.

Lemma refa430_not1038 : ~ @Equation1038 Fin4 refa430_inst.
Proof. unfold Equation1038. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa430_inst, refa430_op in H. discriminate H. Qed.

Lemma refa430_not1045 : ~ @Equation1045 Fin4 refa430_inst.
Proof. unfold Equation1045. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa430_inst, refa430_op in H. discriminate H. Qed.

Lemma refa430_not1223 : ~ @Equation1223 Fin4 refa430_inst.
Proof. unfold Equation1223. intro H. specialize (H F4_0). unfold magma_op, refa430_inst, refa430_op in H. discriminate H. Qed.

Lemma refa430_not3259 : ~ @Equation3259 Fin4 refa430_inst.
Proof. unfold Equation3259. intro H. specialize (H F4_3 F4_2). unfold magma_op, refa430_inst, refa430_op in H. discriminate H. Qed.

Lemma refa430_not3261 : ~ @Equation3261 Fin4 refa430_inst.
Proof. unfold Equation3261. intro H. specialize (H F4_0 F4_2). unfold magma_op, refa430_inst, refa430_op in H. discriminate H. Qed.

Lemma refa430_not3306 : ~ @Equation3306 Fin4 refa430_inst.
Proof. unfold Equation3306. intro H. specialize (H F4_0 F4_2). unfold magma_op, refa430_inst, refa430_op in H. discriminate H. Qed.

Lemma refa430_not3308 : ~ @Equation3308 Fin4 refa430_inst.
Proof. unfold Equation3308. intro H. specialize (H F4_0 F4_2). unfold magma_op, refa430_inst, refa430_op in H. discriminate H. Qed.

Lemma refa430_not4598 : ~ @Equation4598 Fin4 refa430_inst.
Proof. unfold Equation4598. intro H. specialize (H F4_0 F4_2). unfold magma_op, refa430_inst, refa430_op in H. discriminate H. Qed.

(** ---- refa431 (Fin4) ---- *)

Definition refa431_op (x y : Fin4) : Fin4 :=
  match x, y with
  | F4_0, F4_0 => F4_3 | F4_0, F4_1 => F4_0 | F4_0, F4_2 => F4_1 | F4_0, F4_3 => F4_1
  | F4_1, F4_0 => F4_3 | F4_1, F4_1 => F4_0 | F4_1, F4_2 => F4_1 | F4_1, F4_3 => F4_1
  | F4_2, F4_0 => F4_3 | F4_2, F4_1 => F4_1 | F4_2, F4_2 => F4_0 | F4_2, F4_3 => F4_2
  | F4_3, F4_0 => F4_3 | F4_3, F4_1 => F4_0 | F4_3, F4_2 => F4_0 | F4_3, F4_3 => F4_1
  end.

#[local] Instance refa431_inst : Magma Fin4 := {| magma_op := refa431_op |}.

Lemma refa431_sat822 : @Equation822 Fin4 refa431_inst.
Proof. unfold Equation822, magma_op, refa431_inst, refa431_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa431_not614 : ~ @Equation614 Fin4 refa431_inst.
Proof. unfold Equation614. intro H. specialize (H F4_2). unfold magma_op, refa431_inst, refa431_op in H. discriminate H. Qed.

Lemma refa431_not832 : ~ @Equation832 Fin4 refa431_inst.
Proof. unfold Equation832. intro H. specialize (H F4_3 F4_2). unfold magma_op, refa431_inst, refa431_op in H. discriminate H. Qed.

Lemma refa431_not1426 : ~ @Equation1426 Fin4 refa431_inst.
Proof. unfold Equation1426. intro H. specialize (H F4_2). unfold magma_op, refa431_inst, refa431_op in H. discriminate H. Qed.

Lemma refa431_not4065 : ~ @Equation4065 Fin4 refa431_inst.
Proof. unfold Equation4065. intro H. specialize (H F4_2). unfold magma_op, refa431_inst, refa431_op in H. discriminate H. Qed.

(** ---- refa432 (Fin4) ---- *)

Definition refa432_op (x y : Fin4) : Fin4 :=
  match x, y with
  | F4_0, F4_0 => F4_2 | F4_0, F4_1 => F4_2 | F4_0, F4_2 => F4_1 | F4_0, F4_3 => F4_1
  | F4_1, F4_0 => F4_3 | F4_1, F4_1 => F4_3 | F4_1, F4_2 => F4_3 | F4_1, F4_3 => F4_3
  | F4_2, F4_0 => F4_3 | F4_2, F4_1 => F4_3 | F4_2, F4_2 => F4_0 | F4_2, F4_3 => F4_0
  | F4_3, F4_0 => F4_1 | F4_3, F4_1 => F4_1 | F4_3, F4_2 => F4_1 | F4_3, F4_3 => F4_1
  end.

#[local] Instance refa432_inst : Magma Fin4 := {| magma_op := refa432_op |}.

Lemma refa432_sat1632 : @Equation1632 Fin4 refa432_inst.
Proof. unfold Equation1632, magma_op, refa432_inst, refa432_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa432_not2441 : ~ @Equation2441 Fin4 refa432_inst.
Proof. unfold Equation2441. intro H. specialize (H F4_0). unfold magma_op, refa432_inst, refa432_op in H. discriminate H. Qed.

Lemma refa432_not3050 : ~ @Equation3050 Fin4 refa432_inst.
Proof. unfold Equation3050. intro H. specialize (H F4_0). unfold magma_op, refa432_inst, refa432_op in H. discriminate H. Qed.

(** ---- refa433 (Fin4) ---- *)

Definition refa433_op (x y : Fin4) : Fin4 :=
  match x, y with
  | F4_0, F4_0 => F4_3 | F4_0, F4_1 => F4_1 | F4_0, F4_2 => F4_0 | F4_0, F4_3 => F4_1
  | F4_1, F4_0 => F4_3 | F4_1, F4_1 => F4_1 | F4_1, F4_2 => F4_0 | F4_1, F4_3 => F4_1
  | F4_2, F4_0 => F4_3 | F4_2, F4_1 => F4_1 | F4_2, F4_2 => F4_0 | F4_2, F4_3 => F4_1
  | F4_3, F4_0 => F4_3 | F4_3, F4_1 => F4_3 | F4_3, F4_2 => F4_0 | F4_3, F4_3 => F4_3
  end.

#[local] Instance refa433_inst : Magma Fin4 := {| magma_op := refa433_op |}.

Lemma refa433_sat3939 : @Equation3939 Fin4 refa433_inst.
Proof. unfold Equation3939, magma_op, refa433_inst, refa433_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa433_not3915 : ~ @Equation3915 Fin4 refa433_inst.
Proof. unfold Equation3915. intro H. specialize (H F4_2 F4_1). unfold magma_op, refa433_inst, refa433_op in H. discriminate H. Qed.

Lemma refa433_not3925 : ~ @Equation3925 Fin4 refa433_inst.
Proof. unfold Equation3925. intro H. specialize (H F4_2 F4_1). unfold magma_op, refa433_inst, refa433_op in H. discriminate H. Qed.

(** ---- refa434 (Fin4) ---- *)

Definition refa434_op (x y : Fin4) : Fin4 :=
  match x, y with
  | F4_0, F4_0 => F4_3 | F4_0, F4_1 => F4_1 | F4_0, F4_2 => F4_3 | F4_0, F4_3 => F4_3
  | F4_1, F4_0 => F4_2 | F4_1, F4_1 => F4_2 | F4_1, F4_2 => F4_2 | F4_1, F4_3 => F4_2
  | F4_2, F4_0 => F4_1 | F4_2, F4_1 => F4_1 | F4_2, F4_2 => F4_1 | F4_2, F4_3 => F4_1
  | F4_3, F4_0 => F4_3 | F4_3, F4_1 => F4_3 | F4_3, F4_2 => F4_3 | F4_3, F4_3 => F4_3
  end.

#[local] Instance refa434_inst : Magma Fin4 := {| magma_op := refa434_op |}.

Lemma refa434_sat3527 : @Equation3527 Fin4 refa434_inst.
Proof. unfold Equation3527, magma_op, refa434_inst, refa434_op. intros x y z w. destruct x, y, z, w; reflexivity. Qed.

Lemma refa434_not4268 : ~ @Equation4268 Fin4 refa434_inst.
Proof. unfold Equation4268. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa434_inst, refa434_op in H. discriminate H. Qed.

Lemma refa434_not4599 : ~ @Equation4599 Fin4 refa434_inst.
Proof. unfold Equation4599. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa434_inst, refa434_op in H. discriminate H. Qed.

(** ---- refa435 (Fin4) ---- *)

Definition refa435_op (x y : Fin4) : Fin4 :=
  match x, y with
  | F4_0, F4_0 => F4_1 | F4_0, F4_1 => F4_3 | F4_0, F4_2 => F4_1 | F4_0, F4_3 => F4_3
  | F4_1, F4_0 => F4_3 | F4_1, F4_1 => F4_3 | F4_1, F4_2 => F4_3 | F4_1, F4_3 => F4_3
  | F4_2, F4_0 => F4_0 | F4_2, F4_1 => F4_3 | F4_2, F4_2 => F4_1 | F4_2, F4_3 => F4_3
  | F4_3, F4_0 => F4_3 | F4_3, F4_1 => F4_3 | F4_3, F4_2 => F4_3 | F4_3, F4_3 => F4_3
  end.

#[local] Instance refa435_inst : Magma Fin4 := {| magma_op := refa435_op |}.

Lemma refa435_sat4443 : @Equation4443 Fin4 refa435_inst.
Proof. unfold Equation4443, magma_op, refa435_inst, refa435_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa435_not4321 : ~ @Equation4321 Fin4 refa435_inst.
Proof. unfold Equation4321. intro H. specialize (H F4_0 F4_2). unfold magma_op, refa435_inst, refa435_op in H. discriminate H. Qed.

Lemma refa435_not4435 : ~ @Equation4435 Fin4 refa435_inst.
Proof. unfold Equation4435. intro H. specialize (H F4_0 F4_2). unfold magma_op, refa435_inst, refa435_op in H. discriminate H. Qed.

Lemma refa435_not4636 : ~ @Equation4636 Fin4 refa435_inst.
Proof. unfold Equation4636. intro H. specialize (H F4_0 F4_2). unfold magma_op, refa435_inst, refa435_op in H. discriminate H. Qed.

(** ---- refa436 (Fin4) ---- *)

Definition refa436_op (x y : Fin4) : Fin4 :=
  match x, y with
  | F4_0, F4_0 => F4_3 | F4_0, F4_1 => F4_0 | F4_0, F4_2 => F4_1 | F4_0, F4_3 => F4_1
  | F4_1, F4_0 => F4_1 | F4_1, F4_1 => F4_2 | F4_1, F4_2 => F4_0 | F4_1, F4_3 => F4_0
  | F4_2, F4_0 => F4_2 | F4_2, F4_1 => F4_2 | F4_2, F4_2 => F4_2 | F4_2, F4_3 => F4_2
  | F4_3, F4_0 => F4_2 | F4_3, F4_1 => F4_2 | F4_3, F4_2 => F4_3 | F4_3, F4_3 => F4_3
  end.

#[local] Instance refa436_inst : Magma Fin4 := {| magma_op := refa436_op |}.

Lemma refa436_sat624 : @Equation624 Fin4 refa436_inst.
Proof. unfold Equation624, magma_op, refa436_inst, refa436_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa436_not3660 : ~ @Equation3660 Fin4 refa436_inst.
Proof. unfold Equation3660. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa436_inst, refa436_op in H. discriminate H. Qed.

Lemma refa436_not3661 : ~ @Equation3661 Fin4 refa436_inst.
Proof. unfold Equation3661. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa436_inst, refa436_op in H. discriminate H. Qed.

Lemma refa436_not4065 : ~ @Equation4065 Fin4 refa436_inst.
Proof. unfold Equation4065. intro H. specialize (H F4_0). unfold magma_op, refa436_inst, refa436_op in H. discriminate H. Qed.

Lemma refa436_not4583 : ~ @Equation4583 Fin4 refa436_inst.
Proof. unfold Equation4583. intro H. specialize (H F4_0 F4_2). unfold magma_op, refa436_inst, refa436_op in H. discriminate H. Qed.

(** ---- refa437 (Fin4) ---- *)

Definition refa437_op (x y : Fin4) : Fin4 :=
  match x, y with
  | F4_0, F4_0 => F4_0 | F4_0, F4_1 => F4_1 | F4_0, F4_2 => F4_2 | F4_0, F4_3 => F4_3
  | F4_1, F4_0 => F4_2 | F4_1, F4_1 => F4_3 | F4_1, F4_2 => F4_1 | F4_1, F4_3 => F4_0
  | F4_2, F4_0 => F4_1 | F4_2, F4_1 => F4_2 | F4_2, F4_2 => F4_3 | F4_2, F4_3 => F4_0
  | F4_3, F4_0 => F4_1 | F4_3, F4_1 => F4_3 | F4_3, F4_2 => F4_0 | F4_3, F4_3 => F4_2
  end.

#[local] Instance refa437_inst : Magma Fin4 := {| magma_op := refa437_op |}.

Lemma refa437_sat420 : @Equation420 Fin4 refa437_inst.
Proof. unfold Equation420, magma_op, refa437_inst, refa437_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa437_sat501 : @Equation501 Fin4 refa437_inst.
Proof. unfold Equation501, magma_op, refa437_inst, refa437_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa437_not47 : ~ @Equation47 Fin4 refa437_inst.
Proof. unfold Equation47. intro H. specialize (H F4_1). unfold magma_op, refa437_inst, refa437_op in H. discriminate H. Qed.

Lemma refa437_not99 : ~ @Equation99 Fin4 refa437_inst.
Proof. unfold Equation99. intro H. specialize (H F4_1). unfold magma_op, refa437_inst, refa437_op in H. discriminate H. Qed.

Lemma refa437_not151 : ~ @Equation151 Fin4 refa437_inst.
Proof. unfold Equation151. intro H. specialize (H F4_1). unfold magma_op, refa437_inst, refa437_op in H. discriminate H. Qed.

Lemma refa437_not211 : ~ @Equation211 Fin4 refa437_inst.
Proof. unfold Equation211. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa437_inst, refa437_op in H. discriminate H. Qed.

Lemma refa437_not221 : ~ @Equation221 Fin4 refa437_inst.
Proof. unfold Equation221. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa437_inst, refa437_op in H. discriminate H. Qed.

Lemma refa437_not255 : ~ @Equation255 Fin4 refa437_inst.
Proof. unfold Equation255. intro H. specialize (H F4_1). unfold magma_op, refa437_inst, refa437_op in H. discriminate H. Qed.

Lemma refa437_not413 : ~ @Equation413 Fin4 refa437_inst.
Proof. unfold Equation413. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa437_inst, refa437_op in H. discriminate H. Qed.

Lemma refa437_not416 : ~ @Equation416 Fin4 refa437_inst.
Proof. unfold Equation416. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa437_inst, refa437_op in H. discriminate H. Qed.

Lemma refa437_not417 : ~ @Equation417 Fin4 refa437_inst.
Proof. unfold Equation417. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa437_inst, refa437_op in H. discriminate H. Qed.

Lemma refa437_not419 : ~ @Equation419 Fin4 refa437_inst.
Proof. unfold Equation419. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa437_inst, refa437_op in H. discriminate H. Qed.

Lemma refa437_not426 : ~ @Equation426 Fin4 refa437_inst.
Proof. unfold Equation426. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa437_inst, refa437_op in H. discriminate H. Qed.

Lemma refa437_not429 : ~ @Equation429 Fin4 refa437_inst.
Proof. unfold Equation429. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa437_inst, refa437_op in H. discriminate H. Qed.

Lemma refa437_not436 : ~ @Equation436 Fin4 refa437_inst.
Proof. unfold Equation436. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa437_inst, refa437_op in H. discriminate H. Qed.

Lemma refa437_not437 : ~ @Equation437 Fin4 refa437_inst.
Proof. unfold Equation437. intro H. specialize (H F4_1 F4_2). unfold magma_op, refa437_inst, refa437_op in H. discriminate H. Qed.

Lemma refa437_not440 : ~ @Equation440 Fin4 refa437_inst.
Proof. unfold Equation440. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa437_inst, refa437_op in H. discriminate H. Qed.

Lemma refa437_not466 : ~ @Equation466 Fin4 refa437_inst.
Proof. unfold Equation466. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa437_inst, refa437_op in H. discriminate H. Qed.

Lemma refa437_not477 : ~ @Equation477 Fin4 refa437_inst.
Proof. unfold Equation477. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa437_inst, refa437_op in H. discriminate H. Qed.

Lemma refa437_not614 : ~ @Equation614 Fin4 refa437_inst.
Proof. unfold Equation614. intro H. specialize (H F4_1). unfold magma_op, refa437_inst, refa437_op in H. discriminate H. Qed.

Lemma refa437_not817 : ~ @Equation817 Fin4 refa437_inst.
Proof. unfold Equation817. intro H. specialize (H F4_2). unfold magma_op, refa437_inst, refa437_op in H. discriminate H. Qed.

Lemma refa437_not1020 : ~ @Equation1020 Fin4 refa437_inst.
Proof. unfold Equation1020. intro H. specialize (H F4_1). unfold magma_op, refa437_inst, refa437_op in H. discriminate H. Qed.

Lemma refa437_not1223 : ~ @Equation1223 Fin4 refa437_inst.
Proof. unfold Equation1223. intro H. specialize (H F4_1). unfold magma_op, refa437_inst, refa437_op in H. discriminate H. Qed.

Lemma refa437_not1426 : ~ @Equation1426 Fin4 refa437_inst.
Proof. unfold Equation1426. intro H. specialize (H F4_2). unfold magma_op, refa437_inst, refa437_op in H. discriminate H. Qed.

Lemma refa437_not1629 : ~ @Equation1629 Fin4 refa437_inst.
Proof. unfold Equation1629. intro H. specialize (H F4_1). unfold magma_op, refa437_inst, refa437_op in H. discriminate H. Qed.

Lemma refa437_not1832 : ~ @Equation1832 Fin4 refa437_inst.
Proof. unfold Equation1832. intro H. specialize (H F4_1). unfold magma_op, refa437_inst, refa437_op in H. discriminate H. Qed.

Lemma refa437_not2035 : ~ @Equation2035 Fin4 refa437_inst.
Proof. unfold Equation2035. intro H. specialize (H F4_1). unfold magma_op, refa437_inst, refa437_op in H. discriminate H. Qed.

Lemma refa437_not2238 : ~ @Equation2238 Fin4 refa437_inst.
Proof. unfold Equation2238. intro H. specialize (H F4_1). unfold magma_op, refa437_inst, refa437_op in H. discriminate H. Qed.

Lemma refa437_not2441 : ~ @Equation2441 Fin4 refa437_inst.
Proof. unfold Equation2441. intro H. specialize (H F4_2). unfold magma_op, refa437_inst, refa437_op in H. discriminate H. Qed.

Lemma refa437_not2644 : ~ @Equation2644 Fin4 refa437_inst.
Proof. unfold Equation2644. intro H. specialize (H F4_1). unfold magma_op, refa437_inst, refa437_op in H. discriminate H. Qed.

Lemma refa437_not2847 : ~ @Equation2847 Fin4 refa437_inst.
Proof. unfold Equation2847. intro H. specialize (H F4_1). unfold magma_op, refa437_inst, refa437_op in H. discriminate H. Qed.

Lemma refa437_not3050 : ~ @Equation3050 Fin4 refa437_inst.
Proof. unfold Equation3050. intro H. specialize (H F4_1). unfold magma_op, refa437_inst, refa437_op in H. discriminate H. Qed.

Lemma refa437_not3253 : ~ @Equation3253 Fin4 refa437_inst.
Proof. unfold Equation3253. intro H. specialize (H F4_1). unfold magma_op, refa437_inst, refa437_op in H. discriminate H. Qed.

Lemma refa437_not3456 : ~ @Equation3456 Fin4 refa437_inst.
Proof. unfold Equation3456. intro H. specialize (H F4_1). unfold magma_op, refa437_inst, refa437_op in H. discriminate H. Qed.

Lemma refa437_not3659 : ~ @Equation3659 Fin4 refa437_inst.
Proof. unfold Equation3659. intro H. specialize (H F4_1). unfold magma_op, refa437_inst, refa437_op in H. discriminate H. Qed.

Lemma refa437_not3862 : ~ @Equation3862 Fin4 refa437_inst.
Proof. unfold Equation3862. intro H. specialize (H F4_1). unfold magma_op, refa437_inst, refa437_op in H. discriminate H. Qed.

Lemma refa437_not4065 : ~ @Equation4065 Fin4 refa437_inst.
Proof. unfold Equation4065. intro H. specialize (H F4_2). unfold magma_op, refa437_inst, refa437_op in H. discriminate H. Qed.

Lemma refa437_not4268 : ~ @Equation4268 Fin4 refa437_inst.
Proof. unfold Equation4268. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa437_inst, refa437_op in H. discriminate H. Qed.

Lemma refa437_not4269 : ~ @Equation4269 Fin4 refa437_inst.
Proof. unfold Equation4269. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa437_inst, refa437_op in H. discriminate H. Qed.

Lemma refa437_not4270 : ~ @Equation4270 Fin4 refa437_inst.
Proof. unfold Equation4270. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa437_inst, refa437_op in H. discriminate H. Qed.

Lemma refa437_not4273 : ~ @Equation4273 Fin4 refa437_inst.
Proof. unfold Equation4273. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa437_inst, refa437_op in H. discriminate H. Qed.

Lemma refa437_not4283 : ~ @Equation4283 Fin4 refa437_inst.
Proof. unfold Equation4283. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa437_inst, refa437_op in H. discriminate H. Qed.

Lemma refa437_not4284 : ~ @Equation4284 Fin4 refa437_inst.
Proof. unfold Equation4284. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa437_inst, refa437_op in H. discriminate H. Qed.

Lemma refa437_not4290 : ~ @Equation4290 Fin4 refa437_inst.
Proof. unfold Equation4290. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa437_inst, refa437_op in H. discriminate H. Qed.

Lemma refa437_not4314 : ~ @Equation4314 Fin4 refa437_inst.
Proof. unfold Equation4314. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa437_inst, refa437_op in H. discriminate H. Qed.

Lemma refa437_not4380 : ~ @Equation4380 Fin4 refa437_inst.
Proof. unfold Equation4380. intro H. specialize (H F4_1). unfold magma_op, refa437_inst, refa437_op in H. discriminate H. Qed.

Lemma refa437_not4583 : ~ @Equation4583 Fin4 refa437_inst.
Proof. unfold Equation4583. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa437_inst, refa437_op in H. discriminate H. Qed.

Lemma refa437_not4584 : ~ @Equation4584 Fin4 refa437_inst.
Proof. unfold Equation4584. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa437_inst, refa437_op in H. discriminate H. Qed.

Lemma refa437_not4585 : ~ @Equation4585 Fin4 refa437_inst.
Proof. unfold Equation4585. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa437_inst, refa437_op in H. discriminate H. Qed.

Lemma refa437_not4588 : ~ @Equation4588 Fin4 refa437_inst.
Proof. unfold Equation4588. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa437_inst, refa437_op in H. discriminate H. Qed.

Lemma refa437_not4598 : ~ @Equation4598 Fin4 refa437_inst.
Proof. unfold Equation4598. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa437_inst, refa437_op in H. discriminate H. Qed.

Lemma refa437_not4599 : ~ @Equation4599 Fin4 refa437_inst.
Proof. unfold Equation4599. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa437_inst, refa437_op in H. discriminate H. Qed.

Lemma refa437_not4605 : ~ @Equation4605 Fin4 refa437_inst.
Proof. unfold Equation4605. intro H. specialize (H F4_0 F4_3). unfold magma_op, refa437_inst, refa437_op in H. discriminate H. Qed.

Lemma refa437_not4629 : ~ @Equation4629 Fin4 refa437_inst.
Proof. unfold Equation4629. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa437_inst, refa437_op in H. discriminate H. Qed.

(** ---- refa438 (Fin4) ---- *)

Definition refa438_op (x y : Fin4) : Fin4 :=
  match x, y with
  | F4_0, F4_0 => F4_1 | F4_0, F4_1 => F4_2 | F4_0, F4_2 => F4_2 | F4_0, F4_3 => F4_1
  | F4_1, F4_0 => F4_3 | F4_1, F4_1 => F4_1 | F4_1, F4_2 => F4_2 | F4_1, F4_3 => F4_3
  | F4_2, F4_0 => F4_3 | F4_2, F4_1 => F4_1 | F4_2, F4_2 => F4_2 | F4_2, F4_3 => F4_3
  | F4_3, F4_0 => F4_0 | F4_3, F4_1 => F4_1 | F4_3, F4_2 => F4_1 | F4_3, F4_3 => F4_3
  end.

#[local] Instance refa438_inst : Magma Fin4 := {| magma_op := refa438_op |}.

Lemma refa438_sat2919 : @Equation2919 Fin4 refa438_inst.
Proof. unfold Equation2919, magma_op, refa438_inst, refa438_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa438_not3253 : ~ @Equation3253 Fin4 refa438_inst.
Proof. unfold Equation3253. intro H. specialize (H F4_0). unfold magma_op, refa438_inst, refa438_op in H. discriminate H. Qed.

Lemma refa438_not3684 : ~ @Equation3684 Fin4 refa438_inst.
Proof. unfold Equation3684. intro H. specialize (H F4_2 F4_3). unfold magma_op, refa438_inst, refa438_op in H. discriminate H. Qed.

(** ---- refa439 (Fin4) ---- *)

Definition refa439_op (x y : Fin4) : Fin4 :=
  match x, y with
  | F4_0, F4_0 => F4_3 | F4_0, F4_1 => F4_1 | F4_0, F4_2 => F4_0 | F4_0, F4_3 => F4_1
  | F4_1, F4_0 => F4_2 | F4_1, F4_1 => F4_2 | F4_1, F4_2 => F4_1 | F4_1, F4_3 => F4_2
  | F4_2, F4_0 => F4_2 | F4_2, F4_1 => F4_2 | F4_2, F4_2 => F4_2 | F4_2, F4_3 => F4_2
  | F4_3, F4_0 => F4_2 | F4_3, F4_1 => F4_2 | F4_3, F4_2 => F4_3 | F4_3, F4_3 => F4_2
  end.

#[local] Instance refa439_inst : Magma Fin4 := {| magma_op := refa439_op |}.

Lemma refa439_sat837 : @Equation837 Fin4 refa439_inst.
Proof. unfold Equation837, magma_op, refa439_inst, refa439_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa439_sat1051 : @Equation1051 Fin4 refa439_inst.
Proof. unfold Equation1051, magma_op, refa439_inst, refa439_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa439_not3253 : ~ @Equation3253 Fin4 refa439_inst.
Proof. unfold Equation3253. intro H. specialize (H F4_0). unfold magma_op, refa439_inst, refa439_op in H. discriminate H. Qed.

(** ---- refa44 (Fin2) ---- *)

Definition refa44_op (x y : Fin2) : Fin2 :=
  match x, y with
  | F2_0, F2_0 => F2_0 | F2_0, F2_1 => F2_0
  | F2_1, F2_0 => F2_1 | F2_1, F2_1 => F2_0
  end.

#[local] Instance refa44_inst : Magma Fin2 := {| magma_op := refa44_op |}.

Lemma refa44_sat106 : @Equation106 Fin2 refa44_inst.
Proof. unfold Equation106, magma_op, refa44_inst, refa44_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa44_sat371 : @Equation371 Fin2 refa44_inst.
Proof. unfold Equation371, magma_op, refa44_inst, refa44_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa44_sat1043 : @Equation1043 Fin2 refa44_inst.
Proof. unfold Equation1043, magma_op, refa44_inst, refa44_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa44_sat1271 : @Equation1271 Fin2 refa44_inst.
Proof. unfold Equation1271, magma_op, refa44_inst, refa44_op. intros x y z w. destruct x, y, z, w; reflexivity. Qed.

Lemma refa44_sat3285 : @Equation3285 Fin2 refa44_inst.
Proof. unfold Equation3285, magma_op, refa44_inst, refa44_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa44_sat3306 : @Equation3306 Fin2 refa44_inst.
Proof. unfold Equation3306, magma_op, refa44_inst, refa44_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa44_sat3321 : @Equation3321 Fin2 refa44_inst.
Proof. unfold Equation3321, magma_op, refa44_inst, refa44_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa44_sat3895 : @Equation3895 Fin2 refa44_inst.
Proof. unfold Equation3895, magma_op, refa44_inst, refa44_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa44_sat3931 : @Equation3931 Fin2 refa44_inst.
Proof. unfold Equation3931, magma_op, refa44_inst, refa44_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa44_sat4101 : @Equation4101 Fin2 refa44_inst.
Proof. unfold Equation4101, magma_op, refa44_inst, refa44_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa44_sat4293 : @Equation4293 Fin2 refa44_inst.
Proof. unfold Equation4293, magma_op, refa44_inst, refa44_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa44_sat4673 : @Equation4673 Fin2 refa44_inst.
Proof. unfold Equation4673, magma_op, refa44_inst, refa44_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa44_not47 : ~ @Equation47 Fin2 refa44_inst.
Proof. unfold Equation47. intro H. specialize (H F2_1). unfold magma_op, refa44_inst, refa44_op in H. discriminate H. Qed.

Lemma refa44_not151 : ~ @Equation151 Fin2 refa44_inst.
Proof. unfold Equation151. intro H. specialize (H F2_1). unfold magma_op, refa44_inst, refa44_op in H. discriminate H. Qed.

Lemma refa44_not203 : ~ @Equation203 Fin2 refa44_inst.
Proof. unfold Equation203. intro H. specialize (H F2_1). unfold magma_op, refa44_inst, refa44_op in H. discriminate H. Qed.

Lemma refa44_not255 : ~ @Equation255 Fin2 refa44_inst.
Proof. unfold Equation255. intro H. specialize (H F2_1). unfold magma_op, refa44_inst, refa44_op in H. discriminate H. Qed.

Lemma refa44_not307 : ~ @Equation307 Fin2 refa44_inst.
Proof. unfold Equation307. intro H. specialize (H F2_1). unfold magma_op, refa44_inst, refa44_op in H. discriminate H. Qed.

Lemma refa44_not416 : ~ @Equation416 Fin2 refa44_inst.
Proof. unfold Equation416. intro H. specialize (H F2_1 F2_0). unfold magma_op, refa44_inst, refa44_op in H. discriminate H. Qed.

Lemma refa44_not417 : ~ @Equation417 Fin2 refa44_inst.
Proof. unfold Equation417. intro H. specialize (H F2_1 F2_0). unfold magma_op, refa44_inst, refa44_op in H. discriminate H. Qed.

Lemma refa44_not419 : ~ @Equation419 Fin2 refa44_inst.
Proof. unfold Equation419. intro H. specialize (H F2_1 F2_0). unfold magma_op, refa44_inst, refa44_op in H. discriminate H. Qed.

Lemma refa44_not420 : ~ @Equation420 Fin2 refa44_inst.
Proof. unfold Equation420. intro H. specialize (H F2_1 F2_0). unfold magma_op, refa44_inst, refa44_op in H. discriminate H. Qed.

Lemma refa44_not466 : ~ @Equation466 Fin2 refa44_inst.
Proof. unfold Equation466. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa44_inst, refa44_op in H. discriminate H. Qed.

Lemma refa44_not467 : ~ @Equation467 Fin2 refa44_inst.
Proof. unfold Equation467. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa44_inst, refa44_op in H. discriminate H. Qed.

Lemma refa44_not473 : ~ @Equation473 Fin2 refa44_inst.
Proof. unfold Equation473. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa44_inst, refa44_op in H. discriminate H. Qed.

Lemma refa44_not474 : ~ @Equation474 Fin2 refa44_inst.
Proof. unfold Equation474. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa44_inst, refa44_op in H. discriminate H. Qed.

Lemma refa44_not476 : ~ @Equation476 Fin2 refa44_inst.
Proof. unfold Equation476. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa44_inst, refa44_op in H. discriminate H. Qed.

Lemma refa44_not477 : ~ @Equation477 Fin2 refa44_inst.
Proof. unfold Equation477. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa44_inst, refa44_op in H. discriminate H. Qed.

Lemma refa44_not501 : ~ @Equation501 Fin2 refa44_inst.
Proof. unfold Equation501. intro H. specialize (H F2_1 F2_0). unfold magma_op, refa44_inst, refa44_op in H. discriminate H. Qed.

Lemma refa44_not503 : ~ @Equation503 Fin2 refa44_inst.
Proof. unfold Equation503. intro H. specialize (H F2_1 F2_0). unfold magma_op, refa44_inst, refa44_op in H. discriminate H. Qed.

Lemma refa44_not504 : ~ @Equation504 Fin2 refa44_inst.
Proof. unfold Equation504. intro H. specialize (H F2_1 F2_0). unfold magma_op, refa44_inst, refa44_op in H. discriminate H. Qed.

Lemma refa44_not510 : ~ @Equation510 Fin2 refa44_inst.
Proof. unfold Equation510. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa44_inst, refa44_op in H. discriminate H. Qed.

Lemma refa44_not511 : ~ @Equation511 Fin2 refa44_inst.
Proof. unfold Equation511. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa44_inst, refa44_op in H. discriminate H. Qed.

Lemma refa44_not513 : ~ @Equation513 Fin2 refa44_inst.
Proof. unfold Equation513. intro H. specialize (H F2_1 F2_0). unfold magma_op, refa44_inst, refa44_op in H. discriminate H. Qed.

Lemma refa44_not614 : ~ @Equation614 Fin2 refa44_inst.
Proof. unfold Equation614. intro H. specialize (H F2_1). unfold magma_op, refa44_inst, refa44_op in H. discriminate H. Qed.

Lemma refa44_not825 : ~ @Equation825 Fin2 refa44_inst.
Proof. unfold Equation825. intro H. specialize (H F2_1 F2_0). unfold magma_op, refa44_inst, refa44_op in H. discriminate H. Qed.

Lemma refa44_not826 : ~ @Equation826 Fin2 refa44_inst.
Proof. unfold Equation826. intro H. specialize (H F2_1 F2_0). unfold magma_op, refa44_inst, refa44_op in H. discriminate H. Qed.

Lemma refa44_not870 : ~ @Equation870 Fin2 refa44_inst.
Proof. unfold Equation870. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa44_inst, refa44_op in H. discriminate H. Qed.

Lemma refa44_not872 : ~ @Equation872 Fin2 refa44_inst.
Proof. unfold Equation872. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa44_inst, refa44_op in H. discriminate H. Qed.

Lemma refa44_not873 : ~ @Equation873 Fin2 refa44_inst.
Proof. unfold Equation873. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa44_inst, refa44_op in H. discriminate H. Qed.

Lemma refa44_not879 : ~ @Equation879 Fin2 refa44_inst.
Proof. unfold Equation879. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa44_inst, refa44_op in H. discriminate H. Qed.

Lemma refa44_not882 : ~ @Equation882 Fin2 refa44_inst.
Proof. unfold Equation882. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa44_inst, refa44_op in H. discriminate H. Qed.

Lemma refa44_not883 : ~ @Equation883 Fin2 refa44_inst.
Proof. unfold Equation883. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa44_inst, refa44_op in H. discriminate H. Qed.

Lemma refa44_not906 : ~ @Equation906 Fin2 refa44_inst.
Proof. unfold Equation906. intro H. specialize (H F2_1 F2_0). unfold magma_op, refa44_inst, refa44_op in H. discriminate H. Qed.

Lemma refa44_not907 : ~ @Equation907 Fin2 refa44_inst.
Proof. unfold Equation907. intro H. specialize (H F2_1 F2_0). unfold magma_op, refa44_inst, refa44_op in H. discriminate H. Qed.

Lemma refa44_not917 : ~ @Equation917 Fin2 refa44_inst.
Proof. unfold Equation917. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa44_inst, refa44_op in H. discriminate H. Qed.

Lemma refa44_not1026 : ~ @Equation1026 Fin2 refa44_inst.
Proof. unfold Equation1026. intro H. specialize (H F2_1 F2_0). unfold magma_op, refa44_inst, refa44_op in H. discriminate H. Qed.

Lemma refa44_not1029 : ~ @Equation1029 Fin2 refa44_inst.
Proof. unfold Equation1029. intro H. specialize (H F2_1 F2_0). unfold magma_op, refa44_inst, refa44_op in H. discriminate H. Qed.

Lemma refa44_not1075 : ~ @Equation1075 Fin2 refa44_inst.
Proof. unfold Equation1075. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa44_inst, refa44_op in H. discriminate H. Qed.

Lemma refa44_not1076 : ~ @Equation1076 Fin2 refa44_inst.
Proof. unfold Equation1076. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa44_inst, refa44_op in H. discriminate H. Qed.

Lemma refa44_not1082 : ~ @Equation1082 Fin2 refa44_inst.
Proof. unfold Equation1082. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa44_inst, refa44_op in H. discriminate H. Qed.

Lemma refa44_not1083 : ~ @Equation1083 Fin2 refa44_inst.
Proof. unfold Equation1083. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa44_inst, refa44_op in H. discriminate H. Qed.

Lemma refa44_not1085 : ~ @Equation1085 Fin2 refa44_inst.
Proof. unfold Equation1085. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa44_inst, refa44_op in H. discriminate H. Qed.

Lemma refa44_not1086 : ~ @Equation1086 Fin2 refa44_inst.
Proof. unfold Equation1086. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa44_inst, refa44_op in H. discriminate H. Qed.

Lemma refa44_not1109 : ~ @Equation1109 Fin2 refa44_inst.
Proof. unfold Equation1109. intro H. specialize (H F2_1 F2_0). unfold magma_op, refa44_inst, refa44_op in H. discriminate H. Qed.

Lemma refa44_not1110 : ~ @Equation1110 Fin2 refa44_inst.
Proof. unfold Equation1110. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa44_inst, refa44_op in H. discriminate H. Qed.

Lemma refa44_not1112 : ~ @Equation1112 Fin2 refa44_inst.
Proof. unfold Equation1112. intro H. specialize (H F2_1 F2_0). unfold magma_op, refa44_inst, refa44_op in H. discriminate H. Qed.

Lemma refa44_not1113 : ~ @Equation1113 Fin2 refa44_inst.
Proof. unfold Equation1113. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa44_inst, refa44_op in H. discriminate H. Qed.

Lemma refa44_not1122 : ~ @Equation1122 Fin2 refa44_inst.
Proof. unfold Equation1122. intro H. specialize (H F2_1 F2_0). unfold magma_op, refa44_inst, refa44_op in H. discriminate H. Qed.

Lemma refa44_not1276 : ~ @Equation1276 Fin2 refa44_inst.
Proof. unfold Equation1276. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa44_inst, refa44_op in H. discriminate H. Qed.

Lemma refa44_not1278 : ~ @Equation1278 Fin2 refa44_inst.
Proof. unfold Equation1278. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa44_inst, refa44_op in H. discriminate H. Qed.

Lemma refa44_not1279 : ~ @Equation1279 Fin2 refa44_inst.
Proof. unfold Equation1279. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa44_inst, refa44_op in H. discriminate H. Qed.

Lemma refa44_not1285 : ~ @Equation1285 Fin2 refa44_inst.
Proof. unfold Equation1285. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa44_inst, refa44_op in H. discriminate H. Qed.

Lemma refa44_not1286 : ~ @Equation1286 Fin2 refa44_inst.
Proof. unfold Equation1286. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa44_inst, refa44_op in H. discriminate H. Qed.

Lemma refa44_not1288 : ~ @Equation1288 Fin2 refa44_inst.
Proof. unfold Equation1288. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa44_inst, refa44_op in H. discriminate H. Qed.

Lemma refa44_not1315 : ~ @Equation1315 Fin2 refa44_inst.
Proof. unfold Equation1315. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa44_inst, refa44_op in H. discriminate H. Qed.

Lemma refa44_not1322 : ~ @Equation1322 Fin2 refa44_inst.
Proof. unfold Equation1322. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa44_inst, refa44_op in H. discriminate H. Qed.

Lemma refa44_not1426 : ~ @Equation1426 Fin2 refa44_inst.
Proof. unfold Equation1426. intro H. specialize (H F2_1). unfold magma_op, refa44_inst, refa44_op in H. discriminate H. Qed.

Lemma refa44_not1629 : ~ @Equation1629 Fin2 refa44_inst.
Proof. unfold Equation1629. intro H. specialize (H F2_1). unfold magma_op, refa44_inst, refa44_op in H. discriminate H. Qed.

Lemma refa44_not1833 : ~ @Equation1833 Fin2 refa44_inst.
Proof. unfold Equation1833. intro H. specialize (H F2_1 F2_0). unfold magma_op, refa44_inst, refa44_op in H. discriminate H. Qed.

Lemma refa44_not1837 : ~ @Equation1837 Fin2 refa44_inst.
Proof. unfold Equation1837. intro H. specialize (H F2_1 F2_0). unfold magma_op, refa44_inst, refa44_op in H. discriminate H. Qed.

Lemma refa44_not1838 : ~ @Equation1838 Fin2 refa44_inst.
Proof. unfold Equation1838. intro H. specialize (H F2_1 F2_0). unfold magma_op, refa44_inst, refa44_op in H. discriminate H. Qed.

Lemma refa44_not1840 : ~ @Equation1840 Fin2 refa44_inst.
Proof. unfold Equation1840. intro H. specialize (H F2_1 F2_0). unfold magma_op, refa44_inst, refa44_op in H. discriminate H. Qed.

Lemma refa44_not1841 : ~ @Equation1841 Fin2 refa44_inst.
Proof. unfold Equation1841. intro H. specialize (H F2_1 F2_0). unfold magma_op, refa44_inst, refa44_op in H. discriminate H. Qed.

Lemma refa44_not1848 : ~ @Equation1848 Fin2 refa44_inst.
Proof. unfold Equation1848. intro H. specialize (H F2_1 F2_0). unfold magma_op, refa44_inst, refa44_op in H. discriminate H. Qed.

Lemma refa44_not1858 : ~ @Equation1858 Fin2 refa44_inst.
Proof. unfold Equation1858. intro H. specialize (H F2_1 F2_0). unfold magma_op, refa44_inst, refa44_op in H. discriminate H. Qed.

Lemma refa44_not1884 : ~ @Equation1884 Fin2 refa44_inst.
Proof. unfold Equation1884. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa44_inst, refa44_op in H. discriminate H. Qed.

Lemma refa44_not1885 : ~ @Equation1885 Fin2 refa44_inst.
Proof. unfold Equation1885. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa44_inst, refa44_op in H. discriminate H. Qed.

Lemma refa44_not1887 : ~ @Equation1887 Fin2 refa44_inst.
Proof. unfold Equation1887. intro H. specialize (H F2_1 F2_0). unfold magma_op, refa44_inst, refa44_op in H. discriminate H. Qed.

Lemma refa44_not1888 : ~ @Equation1888 Fin2 refa44_inst.
Proof. unfold Equation1888. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa44_inst, refa44_op in H. discriminate H. Qed.

Lemma refa44_not1894 : ~ @Equation1894 Fin2 refa44_inst.
Proof. unfold Equation1894. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa44_inst, refa44_op in H. discriminate H. Qed.

Lemma refa44_not1895 : ~ @Equation1895 Fin2 refa44_inst.
Proof. unfold Equation1895. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa44_inst, refa44_op in H. discriminate H. Qed.

Lemma refa44_not1897 : ~ @Equation1897 Fin2 refa44_inst.
Proof. unfold Equation1897. intro H. specialize (H F2_1 F2_0). unfold magma_op, refa44_inst, refa44_op in H. discriminate H. Qed.

Lemma refa44_not1921 : ~ @Equation1921 Fin2 refa44_inst.
Proof. unfold Equation1921. intro H. specialize (H F2_1 F2_0). unfold magma_op, refa44_inst, refa44_op in H. discriminate H. Qed.

Lemma refa44_not1922 : ~ @Equation1922 Fin2 refa44_inst.
Proof. unfold Equation1922. intro H. specialize (H F2_1 F2_0). unfold magma_op, refa44_inst, refa44_op in H. discriminate H. Qed.

Lemma refa44_not1924 : ~ @Equation1924 Fin2 refa44_inst.
Proof. unfold Equation1924. intro H. specialize (H F2_1 F2_0). unfold magma_op, refa44_inst, refa44_op in H. discriminate H. Qed.

Lemma refa44_not1925 : ~ @Equation1925 Fin2 refa44_inst.
Proof. unfold Equation1925. intro H. specialize (H F2_1 F2_0). unfold magma_op, refa44_inst, refa44_op in H. discriminate H. Qed.

Lemma refa44_not1931 : ~ @Equation1931 Fin2 refa44_inst.
Proof. unfold Equation1931. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa44_inst, refa44_op in H. discriminate H. Qed.

Lemma refa44_not2035 : ~ @Equation2035 Fin2 refa44_inst.
Proof. unfold Equation2035. intro H. specialize (H F2_1). unfold magma_op, refa44_inst, refa44_op in H. discriminate H. Qed.

Lemma refa44_not2238 : ~ @Equation2238 Fin2 refa44_inst.
Proof. unfold Equation2238. intro H. specialize (H F2_1). unfold magma_op, refa44_inst, refa44_op in H. discriminate H. Qed.

Lemma refa44_not2441 : ~ @Equation2441 Fin2 refa44_inst.
Proof. unfold Equation2441. intro H. specialize (H F2_1). unfold magma_op, refa44_inst, refa44_op in H. discriminate H. Qed.

Lemma refa44_not2644 : ~ @Equation2644 Fin2 refa44_inst.
Proof. unfold Equation2644. intro H. specialize (H F2_1). unfold magma_op, refa44_inst, refa44_op in H. discriminate H. Qed.

Lemma refa44_not2847 : ~ @Equation2847 Fin2 refa44_inst.
Proof. unfold Equation2847. intro H. specialize (H F2_1). unfold magma_op, refa44_inst, refa44_op in H. discriminate H. Qed.

Lemma refa44_not3050 : ~ @Equation3050 Fin2 refa44_inst.
Proof. unfold Equation3050. intro H. specialize (H F2_1). unfold magma_op, refa44_inst, refa44_op in H. discriminate H. Qed.

Lemma refa44_not3258 : ~ @Equation3258 Fin2 refa44_inst.
Proof. unfold Equation3258. intro H. specialize (H F2_1 F2_0). unfold magma_op, refa44_inst, refa44_op in H. discriminate H. Qed.

Lemma refa44_not3259 : ~ @Equation3259 Fin2 refa44_inst.
Proof. unfold Equation3259. intro H. specialize (H F2_1 F2_0). unfold magma_op, refa44_inst, refa44_op in H. discriminate H. Qed.

Lemma refa44_not3261 : ~ @Equation3261 Fin2 refa44_inst.
Proof. unfold Equation3261. intro H. specialize (H F2_1 F2_0). unfold magma_op, refa44_inst, refa44_op in H. discriminate H. Qed.

Lemma refa44_not3262 : ~ @Equation3262 Fin2 refa44_inst.
Proof. unfold Equation3262. intro H. specialize (H F2_1 F2_0). unfold magma_op, refa44_inst, refa44_op in H. discriminate H. Qed.

Lemma refa44_not3268 : ~ @Equation3268 Fin2 refa44_inst.
Proof. unfold Equation3268. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa44_inst, refa44_op in H. discriminate H. Qed.

Lemma refa44_not3269 : ~ @Equation3269 Fin2 refa44_inst.
Proof. unfold Equation3269. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa44_inst, refa44_op in H. discriminate H. Qed.

Lemma refa44_not3271 : ~ @Equation3271 Fin2 refa44_inst.
Proof. unfold Equation3271. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa44_inst, refa44_op in H. discriminate H. Qed.

Lemma refa44_not3272 : ~ @Equation3272 Fin2 refa44_inst.
Proof. unfold Equation3272. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa44_inst, refa44_op in H. discriminate H. Qed.

Lemma refa44_not3281 : ~ @Equation3281 Fin2 refa44_inst.
Proof. unfold Equation3281. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa44_inst, refa44_op in H. discriminate H. Qed.

Lemma refa44_not3308 : ~ @Equation3308 Fin2 refa44_inst.
Proof. unfold Equation3308. intro H. specialize (H F2_1 F2_0). unfold magma_op, refa44_inst, refa44_op in H. discriminate H. Qed.

Lemma refa44_not3309 : ~ @Equation3309 Fin2 refa44_inst.
Proof. unfold Equation3309. intro H. specialize (H F2_1 F2_0). unfold magma_op, refa44_inst, refa44_op in H. discriminate H. Qed.

Lemma refa44_not3342 : ~ @Equation3342 Fin2 refa44_inst.
Proof. unfold Equation3342. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa44_inst, refa44_op in H. discriminate H. Qed.

Lemma refa44_not3343 : ~ @Equation3343 Fin2 refa44_inst.
Proof. unfold Equation3343. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa44_inst, refa44_op in H. discriminate H. Qed.

Lemma refa44_not3345 : ~ @Equation3345 Fin2 refa44_inst.
Proof. unfold Equation3345. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa44_inst, refa44_op in H. discriminate H. Qed.

Lemma refa44_not3346 : ~ @Equation3346 Fin2 refa44_inst.
Proof. unfold Equation3346. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa44_inst, refa44_op in H. discriminate H. Qed.

Lemma refa44_not3352 : ~ @Equation3352 Fin2 refa44_inst.
Proof. unfold Equation3352. intro H. specialize (H F2_1 F2_0). unfold magma_op, refa44_inst, refa44_op in H. discriminate H. Qed.

Lemma refa44_not3353 : ~ @Equation3353 Fin2 refa44_inst.
Proof. unfold Equation3353. intro H. specialize (H F2_1 F2_0). unfold magma_op, refa44_inst, refa44_op in H. discriminate H. Qed.

Lemma refa44_not3456 : ~ @Equation3456 Fin2 refa44_inst.
Proof. unfold Equation3456. intro H. specialize (H F2_1). unfold magma_op, refa44_inst, refa44_op in H. discriminate H. Qed.

Lemma refa44_not3664 : ~ @Equation3664 Fin2 refa44_inst.
Proof. unfold Equation3664. intro H. specialize (H F2_1 F2_0). unfold magma_op, refa44_inst, refa44_op in H. discriminate H. Qed.

Lemma refa44_not3667 : ~ @Equation3667 Fin2 refa44_inst.
Proof. unfold Equation3667. intro H. specialize (H F2_1 F2_0). unfold magma_op, refa44_inst, refa44_op in H. discriminate H. Qed.

Lemma refa44_not3668 : ~ @Equation3668 Fin2 refa44_inst.
Proof. unfold Equation3668. intro H. specialize (H F2_1 F2_0). unfold magma_op, refa44_inst, refa44_op in H. discriminate H. Qed.

Lemma refa44_not3674 : ~ @Equation3674 Fin2 refa44_inst.
Proof. unfold Equation3674. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa44_inst, refa44_op in H. discriminate H. Qed.

Lemma refa44_not3675 : ~ @Equation3675 Fin2 refa44_inst.
Proof. unfold Equation3675. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa44_inst, refa44_op in H. discriminate H. Qed.

Lemma refa44_not3678 : ~ @Equation3678 Fin2 refa44_inst.
Proof. unfold Equation3678. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa44_inst, refa44_op in H. discriminate H. Qed.

Lemma refa44_not3712 : ~ @Equation3712 Fin2 refa44_inst.
Proof. unfold Equation3712. intro H. specialize (H F2_1 F2_0). unfold magma_op, refa44_inst, refa44_op in H. discriminate H. Qed.

Lemma refa44_not3714 : ~ @Equation3714 Fin2 refa44_inst.
Proof. unfold Equation3714. intro H. specialize (H F2_1 F2_0). unfold magma_op, refa44_inst, refa44_op in H. discriminate H. Qed.

Lemma refa44_not3722 : ~ @Equation3722 Fin2 refa44_inst.
Proof. unfold Equation3722. intro H. specialize (H F2_1 F2_0). unfold magma_op, refa44_inst, refa44_op in H. discriminate H. Qed.

Lemma refa44_not3748 : ~ @Equation3748 Fin2 refa44_inst.
Proof. unfold Equation3748. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa44_inst, refa44_op in H. discriminate H. Qed.

Lemma refa44_not3749 : ~ @Equation3749 Fin2 refa44_inst.
Proof. unfold Equation3749. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa44_inst, refa44_op in H. discriminate H. Qed.

Lemma refa44_not3752 : ~ @Equation3752 Fin2 refa44_inst.
Proof. unfold Equation3752. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa44_inst, refa44_op in H. discriminate H. Qed.

Lemma refa44_not3759 : ~ @Equation3759 Fin2 refa44_inst.
Proof. unfold Equation3759. intro H. specialize (H F2_1 F2_0). unfold magma_op, refa44_inst, refa44_op in H. discriminate H. Qed.

Lemma refa44_not3761 : ~ @Equation3761 Fin2 refa44_inst.
Proof. unfold Equation3761. intro H. specialize (H F2_1 F2_0). unfold magma_op, refa44_inst, refa44_op in H. discriminate H. Qed.

Lemma refa44_not3863 : ~ @Equation3863 Fin2 refa44_inst.
Proof. unfold Equation3863. intro H. specialize (H F2_1 F2_0). unfold magma_op, refa44_inst, refa44_op in H. discriminate H. Qed.

Lemma refa44_not3868 : ~ @Equation3868 Fin2 refa44_inst.
Proof. unfold Equation3868. intro H. specialize (H F2_1 F2_0). unfold magma_op, refa44_inst, refa44_op in H. discriminate H. Qed.

Lemma refa44_not3871 : ~ @Equation3871 Fin2 refa44_inst.
Proof. unfold Equation3871. intro H. specialize (H F2_1 F2_0). unfold magma_op, refa44_inst, refa44_op in H. discriminate H. Qed.

Lemma refa44_not3877 : ~ @Equation3877 Fin2 refa44_inst.
Proof. unfold Equation3877. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa44_inst, refa44_op in H. discriminate H. Qed.

Lemma refa44_not3880 : ~ @Equation3880 Fin2 refa44_inst.
Proof. unfold Equation3880. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa44_inst, refa44_op in H. discriminate H. Qed.

Lemma refa44_not3890 : ~ @Equation3890 Fin2 refa44_inst.
Proof. unfold Equation3890. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa44_inst, refa44_op in H. discriminate H. Qed.

Lemma refa44_not3917 : ~ @Equation3917 Fin2 refa44_inst.
Proof. unfold Equation3917. intro H. specialize (H F2_1 F2_0). unfold magma_op, refa44_inst, refa44_op in H. discriminate H. Qed.

Lemma refa44_not3918 : ~ @Equation3918 Fin2 refa44_inst.
Proof. unfold Equation3918. intro H. specialize (H F2_1 F2_0). unfold magma_op, refa44_inst, refa44_op in H. discriminate H. Qed.

Lemma refa44_not3924 : ~ @Equation3924 Fin2 refa44_inst.
Proof. unfold Equation3924. intro H. specialize (H F2_1 F2_0). unfold magma_op, refa44_inst, refa44_op in H. discriminate H. Qed.

Lemma refa44_not3927 : ~ @Equation3927 Fin2 refa44_inst.
Proof. unfold Equation3927. intro H. specialize (H F2_1 F2_0). unfold magma_op, refa44_inst, refa44_op in H. discriminate H. Qed.

Lemma refa44_not3951 : ~ @Equation3951 Fin2 refa44_inst.
Proof. unfold Equation3951. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa44_inst, refa44_op in H. discriminate H. Qed.

Lemma refa44_not3952 : ~ @Equation3952 Fin2 refa44_inst.
Proof. unfold Equation3952. intro H. specialize (H F2_1 F2_0). unfold magma_op, refa44_inst, refa44_op in H. discriminate H. Qed.

Lemma refa44_not3954 : ~ @Equation3954 Fin2 refa44_inst.
Proof. unfold Equation3954. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa44_inst, refa44_op in H. discriminate H. Qed.

Lemma refa44_not3955 : ~ @Equation3955 Fin2 refa44_inst.
Proof. unfold Equation3955. intro H. specialize (H F2_1 F2_0). unfold magma_op, refa44_inst, refa44_op in H. discriminate H. Qed.

Lemma refa44_not3961 : ~ @Equation3961 Fin2 refa44_inst.
Proof. unfold Equation3961. intro H. specialize (H F2_1 F2_0). unfold magma_op, refa44_inst, refa44_op in H. discriminate H. Qed.

Lemma refa44_not3962 : ~ @Equation3962 Fin2 refa44_inst.
Proof. unfold Equation3962. intro H. specialize (H F2_1 F2_0). unfold magma_op, refa44_inst, refa44_op in H. discriminate H. Qed.

Lemma refa44_not3964 : ~ @Equation3964 Fin2 refa44_inst.
Proof. unfold Equation3964. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa44_inst, refa44_op in H. discriminate H. Qed.

Lemma refa44_not4074 : ~ @Equation4074 Fin2 refa44_inst.
Proof. unfold Equation4074. intro H. specialize (H F2_1 F2_0). unfold magma_op, refa44_inst, refa44_op in H. discriminate H. Qed.

Lemma refa44_not4080 : ~ @Equation4080 Fin2 refa44_inst.
Proof. unfold Equation4080. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa44_inst, refa44_op in H. discriminate H. Qed.

Lemma refa44_not4118 : ~ @Equation4118 Fin2 refa44_inst.
Proof. unfold Equation4118. intro H. specialize (H F2_1 F2_0). unfold magma_op, refa44_inst, refa44_op in H. discriminate H. Qed.

Lemma refa44_not4120 : ~ @Equation4120 Fin2 refa44_inst.
Proof. unfold Equation4120. intro H. specialize (H F2_1 F2_0). unfold magma_op, refa44_inst, refa44_op in H. discriminate H. Qed.

Lemma refa44_not4121 : ~ @Equation4121 Fin2 refa44_inst.
Proof. unfold Equation4121. intro H. specialize (H F2_1 F2_0). unfold magma_op, refa44_inst, refa44_op in H. discriminate H. Qed.

Lemma refa44_not4127 : ~ @Equation4127 Fin2 refa44_inst.
Proof. unfold Equation4127. intro H. specialize (H F2_1 F2_0). unfold magma_op, refa44_inst, refa44_op in H. discriminate H. Qed.

Lemma refa44_not4128 : ~ @Equation4128 Fin2 refa44_inst.
Proof. unfold Equation4128. intro H. specialize (H F2_1 F2_0). unfold magma_op, refa44_inst, refa44_op in H. discriminate H. Qed.

Lemma refa44_not4130 : ~ @Equation4130 Fin2 refa44_inst.
Proof. unfold Equation4130. intro H. specialize (H F2_1 F2_0). unfold magma_op, refa44_inst, refa44_op in H. discriminate H. Qed.

Lemma refa44_not4155 : ~ @Equation4155 Fin2 refa44_inst.
Proof. unfold Equation4155. intro H. specialize (H F2_1 F2_0). unfold magma_op, refa44_inst, refa44_op in H. discriminate H. Qed.

Lemma refa44_not4157 : ~ @Equation4157 Fin2 refa44_inst.
Proof. unfold Equation4157. intro H. specialize (H F2_1 F2_0). unfold magma_op, refa44_inst, refa44_op in H. discriminate H. Qed.

Lemma refa44_not4158 : ~ @Equation4158 Fin2 refa44_inst.
Proof. unfold Equation4158. intro H. specialize (H F2_1 F2_0). unfold magma_op, refa44_inst, refa44_op in H. discriminate H. Qed.

Lemma refa44_not4164 : ~ @Equation4164 Fin2 refa44_inst.
Proof. unfold Equation4164. intro H. specialize (H F2_1 F2_0). unfold magma_op, refa44_inst, refa44_op in H. discriminate H. Qed.

Lemma refa44_not4165 : ~ @Equation4165 Fin2 refa44_inst.
Proof. unfold Equation4165. intro H. specialize (H F2_1 F2_0). unfold magma_op, refa44_inst, refa44_op in H. discriminate H. Qed.

Lemma refa44_not4167 : ~ @Equation4167 Fin2 refa44_inst.
Proof. unfold Equation4167. intro H. specialize (H F2_1 F2_0). unfold magma_op, refa44_inst, refa44_op in H. discriminate H. Qed.

Lemma refa44_not4268 : ~ @Equation4268 Fin2 refa44_inst.
Proof. unfold Equation4268. intro H. specialize (H F2_1 F2_0). unfold magma_op, refa44_inst, refa44_op in H. discriminate H. Qed.

Lemma refa44_not4272 : ~ @Equation4272 Fin2 refa44_inst.
Proof. unfold Equation4272. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa44_inst, refa44_op in H. discriminate H. Qed.

Lemma refa44_not4273 : ~ @Equation4273 Fin2 refa44_inst.
Proof. unfold Equation4273. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa44_inst, refa44_op in H. discriminate H. Qed.

Lemma refa44_not4275 : ~ @Equation4275 Fin2 refa44_inst.
Proof. unfold Equation4275. intro H. specialize (H F2_1 F2_0). unfold magma_op, refa44_inst, refa44_op in H. discriminate H. Qed.

Lemma refa44_not4276 : ~ @Equation4276 Fin2 refa44_inst.
Proof. unfold Equation4276. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa44_inst, refa44_op in H. discriminate H. Qed.

Lemma refa44_not4283 : ~ @Equation4283 Fin2 refa44_inst.
Proof. unfold Equation4283. intro H. specialize (H F2_1 F2_0). unfold magma_op, refa44_inst, refa44_op in H. discriminate H. Qed.

Lemma refa44_not4284 : ~ @Equation4284 Fin2 refa44_inst.
Proof. unfold Equation4284. intro H. specialize (H F2_1 F2_0). unfold magma_op, refa44_inst, refa44_op in H. discriminate H. Qed.

Lemma refa44_not4290 : ~ @Equation4290 Fin2 refa44_inst.
Proof. unfold Equation4290. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa44_inst, refa44_op in H. discriminate H. Qed.

Lemma refa44_not4291 : ~ @Equation4291 Fin2 refa44_inst.
Proof. unfold Equation4291. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa44_inst, refa44_op in H. discriminate H. Qed.

Lemma refa44_not4320 : ~ @Equation4320 Fin2 refa44_inst.
Proof. unfold Equation4320. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa44_inst, refa44_op in H. discriminate H. Qed.

Lemma refa44_not4321 : ~ @Equation4321 Fin2 refa44_inst.
Proof. unfold Equation4321. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa44_inst, refa44_op in H. discriminate H. Qed.

Lemma refa44_not4343 : ~ @Equation4343 Fin2 refa44_inst.
Proof. unfold Equation4343. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa44_inst, refa44_op in H. discriminate H. Qed.

Lemma refa44_not4380 : ~ @Equation4380 Fin2 refa44_inst.
Proof. unfold Equation4380. intro H. specialize (H F2_1). unfold magma_op, refa44_inst, refa44_op in H. discriminate H. Qed.

Lemma refa44_not4585 : ~ @Equation4585 Fin2 refa44_inst.
Proof. unfold Equation4585. intro H. specialize (H F2_1 F2_0). unfold magma_op, refa44_inst, refa44_op in H. discriminate H. Qed.

Lemma refa44_not4587 : ~ @Equation4587 Fin2 refa44_inst.
Proof. unfold Equation4587. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa44_inst, refa44_op in H. discriminate H. Qed.

Lemma refa44_not4599 : ~ @Equation4599 Fin2 refa44_inst.
Proof. unfold Equation4599. intro H. specialize (H F2_1 F2_0). unfold magma_op, refa44_inst, refa44_op in H. discriminate H. Qed.

Lemma refa44_not4605 : ~ @Equation4605 Fin2 refa44_inst.
Proof. unfold Equation4605. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa44_inst, refa44_op in H. discriminate H. Qed.

Lemma refa44_not4629 : ~ @Equation4629 Fin2 refa44_inst.
Proof. unfold Equation4629. intro H. specialize (H F2_1 F2_0). unfold magma_op, refa44_inst, refa44_op in H. discriminate H. Qed.

Lemma refa44_not4635 : ~ @Equation4635 Fin2 refa44_inst.
Proof. unfold Equation4635. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa44_inst, refa44_op in H. discriminate H. Qed.

Lemma refa44_not4658 : ~ @Equation4658 Fin2 refa44_inst.
Proof. unfold Equation4658. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa44_inst, refa44_op in H. discriminate H. Qed.

(** ---- refa440 (Fin4) ---- *)

Definition refa440_op (x y : Fin4) : Fin4 :=
  match x, y with
  | F4_0, F4_0 => F4_0 | F4_0, F4_1 => F4_3 | F4_0, F4_2 => F4_0 | F4_0, F4_3 => F4_3
  | F4_1, F4_0 => F4_3 | F4_1, F4_1 => F4_1 | F4_1, F4_2 => F4_3 | F4_1, F4_3 => F4_3
  | F4_2, F4_0 => F4_2 | F4_2, F4_1 => F4_3 | F4_2, F4_2 => F4_2 | F4_2, F4_3 => F4_3
  | F4_3, F4_0 => F4_2 | F4_3, F4_1 => F4_1 | F4_3, F4_2 => F4_0 | F4_3, F4_3 => F4_3
  end.

#[local] Instance refa440_inst : Magma Fin4 := {| magma_op := refa440_op |}.

Lemma refa440_sat1055 : @Equation1055 Fin4 refa440_inst.
Proof. unfold Equation1055, magma_op, refa440_inst, refa440_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa440_not3867 : ~ @Equation3867 Fin4 refa440_inst.
Proof. unfold Equation3867. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa440_inst, refa440_op in H. discriminate H. Qed.

Lemma refa440_not3925 : ~ @Equation3925 Fin4 refa440_inst.
Proof. unfold Equation3925. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa440_inst, refa440_op in H. discriminate H. Qed.

(** ---- refa441 (Fin4) ---- *)

Definition refa441_op (x y : Fin4) : Fin4 :=
  match x, y with
  | F4_0, F4_0 => F4_2 | F4_0, F4_1 => F4_3 | F4_0, F4_2 => F4_3 | F4_0, F4_3 => F4_1
  | F4_1, F4_0 => F4_3 | F4_1, F4_1 => F4_0 | F4_1, F4_2 => F4_3 | F4_1, F4_3 => F4_2
  | F4_2, F4_0 => F4_3 | F4_2, F4_1 => F4_3 | F4_2, F4_2 => F4_1 | F4_2, F4_3 => F4_0
  | F4_3, F4_0 => F4_3 | F4_3, F4_1 => F4_3 | F4_3, F4_2 => F4_3 | F4_3, F4_3 => F4_3
  end.

#[local] Instance refa441_inst : Magma Fin4 := {| magma_op := refa441_op |}.

Lemma refa441_sat1641 : @Equation1641 Fin4 refa441_inst.
Proof. unfold Equation1641, magma_op, refa441_inst, refa441_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa441_not151 : ~ @Equation151 Fin4 refa441_inst.
Proof. unfold Equation151. intro H. specialize (H F4_0). unfold magma_op, refa441_inst, refa441_op in H. discriminate H. Qed.

Lemma refa441_not3253 : ~ @Equation3253 Fin4 refa441_inst.
Proof. unfold Equation3253. intro H. specialize (H F4_0). unfold magma_op, refa441_inst, refa441_op in H. discriminate H. Qed.

Lemma refa441_not3456 : ~ @Equation3456 Fin4 refa441_inst.
Proof. unfold Equation3456. intro H. specialize (H F4_0). unfold magma_op, refa441_inst, refa441_op in H. discriminate H. Qed.

Lemma refa441_not4314 : ~ @Equation4314 Fin4 refa441_inst.
Proof. unfold Equation4314. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa441_inst, refa441_op in H. discriminate H. Qed.

(** ---- refa442 (Fin4) ---- *)

Definition refa442_op (x y : Fin4) : Fin4 :=
  match x, y with
  | F4_0, F4_0 => F4_2 | F4_0, F4_1 => F4_1 | F4_0, F4_2 => F4_0 | F4_0, F4_3 => F4_1
  | F4_1, F4_0 => F4_2 | F4_1, F4_1 => F4_2 | F4_1, F4_2 => F4_1 | F4_1, F4_3 => F4_0
  | F4_2, F4_0 => F4_2 | F4_2, F4_1 => F4_2 | F4_2, F4_2 => F4_2 | F4_2, F4_3 => F4_2
  | F4_3, F4_0 => F4_2 | F4_3, F4_1 => F4_3 | F4_3, F4_2 => F4_3 | F4_3, F4_3 => F4_2
  end.

#[local] Instance refa442_inst : Magma Fin4 := {| magma_op := refa442_op |}.

Lemma refa442_sat1042 : @Equation1042 Fin4 refa442_inst.
Proof. unfold Equation1042, magma_op, refa442_inst, refa442_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa442_sat1245 : @Equation1245 Fin4 refa442_inst.
Proof. unfold Equation1245, magma_op, refa442_inst, refa442_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa442_sat1259 : @Equation1259 Fin4 refa442_inst.
Proof. unfold Equation1259, magma_op, refa442_inst, refa442_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa442_sat3888 : @Equation3888 Fin4 refa442_inst.
Proof. unfold Equation3888, magma_op, refa442_inst, refa442_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa442_not437 : ~ @Equation437 Fin4 refa442_inst.
Proof. unfold Equation437. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa442_inst, refa442_op in H. discriminate H. Qed.

Lemma refa442_not1023 : ~ @Equation1023 Fin4 refa442_inst.
Proof. unfold Equation1023. intro H. specialize (H F4_0 F4_3). unfold magma_op, refa442_inst, refa442_op in H. discriminate H. Qed.

Lemma refa442_not1025 : ~ @Equation1025 Fin4 refa442_inst.
Proof. unfold Equation1025. intro H. specialize (H F4_1 F4_3). unfold magma_op, refa442_inst, refa442_op in H. discriminate H. Qed.

Lemma refa442_not1045 : ~ @Equation1045 Fin4 refa442_inst.
Proof. unfold Equation1045. intro H. specialize (H F4_3 F4_0). unfold magma_op, refa442_inst, refa442_op in H. discriminate H. Qed.

Lemma refa442_not1241 : ~ @Equation1241 Fin4 refa442_inst.
Proof. unfold Equation1241. intro H. specialize (H F4_3 F4_1). unfold magma_op, refa442_inst, refa442_op in H. discriminate H. Qed.

Lemma refa442_not3881 : ~ @Equation3881 Fin4 refa442_inst.
Proof. unfold Equation3881. intro H. specialize (H F4_3 F4_1). unfold magma_op, refa442_inst, refa442_op in H. discriminate H. Qed.

(** ---- refa443 (Fin4) ---- *)

Definition refa443_op (x y : Fin4) : Fin4 :=
  match x, y with
  | F4_0, F4_0 => F4_3 | F4_0, F4_1 => F4_1 | F4_0, F4_2 => F4_1 | F4_0, F4_3 => F4_1
  | F4_1, F4_0 => F4_3 | F4_1, F4_1 => F4_1 | F4_1, F4_2 => F4_1 | F4_1, F4_3 => F4_1
  | F4_2, F4_0 => F4_2 | F4_2, F4_1 => F4_3 | F4_2, F4_2 => F4_3 | F4_2, F4_3 => F4_3
  | F4_3, F4_0 => F4_2 | F4_3, F4_1 => F4_3 | F4_3, F4_2 => F4_3 | F4_3, F4_3 => F4_3
  end.

#[local] Instance refa443_inst : Magma Fin4 := {| magma_op := refa443_op |}.

Lemma refa443_sat3947 : @Equation3947 Fin4 refa443_inst.
Proof. unfold Equation3947, magma_op, refa443_inst, refa443_op. intros x y z w. destruct x, y, z, w; reflexivity. Qed.

Lemma refa443_not4065 : ~ @Equation4065 Fin4 refa443_inst.
Proof. unfold Equation4065. intro H. specialize (H F4_0). unfold magma_op, refa443_inst, refa443_op in H. discriminate H. Qed.

(** ---- refa444 (Fin4) ---- *)

Definition refa444_op (x y : Fin4) : Fin4 :=
  match x, y with
  | F4_0, F4_0 => F4_3 | F4_0, F4_1 => F4_2 | F4_0, F4_2 => F4_3 | F4_0, F4_3 => F4_3
  | F4_1, F4_0 => F4_3 | F4_1, F4_1 => F4_0 | F4_1, F4_2 => F4_0 | F4_1, F4_3 => F4_3
  | F4_2, F4_0 => F4_1 | F4_2, F4_1 => F4_3 | F4_2, F4_2 => F4_3 | F4_2, F4_3 => F4_3
  | F4_3, F4_0 => F4_0 | F4_3, F4_1 => F4_1 | F4_3, F4_2 => F4_2 | F4_3, F4_3 => F4_3
  end.

#[local] Instance refa444_inst : Magma Fin4 := {| magma_op := refa444_op |}.

Lemma refa444_sat2296 : @Equation2296 Fin4 refa444_inst.
Proof. unfold Equation2296, magma_op, refa444_inst, refa444_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa444_sat2351 : @Equation2351 Fin4 refa444_inst.
Proof. unfold Equation2351, magma_op, refa444_inst, refa444_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa444_not2441 : ~ @Equation2441 Fin4 refa444_inst.
Proof. unfold Equation2441. intro H. specialize (H F4_1). unfold magma_op, refa444_inst, refa444_op in H. discriminate H. Qed.

(** ---- refa445 (Fin4) ---- *)

Definition refa445_op (x y : Fin4) : Fin4 :=
  match x, y with
  | F4_0, F4_0 => F4_3 | F4_0, F4_1 => F4_1 | F4_0, F4_2 => F4_3 | F4_0, F4_3 => F4_3
  | F4_1, F4_0 => F4_2 | F4_1, F4_1 => F4_2 | F4_1, F4_2 => F4_2 | F4_1, F4_3 => F4_1
  | F4_2, F4_0 => F4_0 | F4_2, F4_1 => F4_1 | F4_2, F4_2 => F4_1 | F4_2, F4_3 => F4_1
  | F4_3, F4_0 => F4_0 | F4_3, F4_1 => F4_0 | F4_3, F4_2 => F4_2 | F4_3, F4_3 => F4_0
  end.

#[local] Instance refa445_inst : Magma Fin4 := {| magma_op := refa445_op |}.

Lemma refa445_sat1849 : @Equation1849 Fin4 refa445_inst.
Proof. unfold Equation1849, magma_op, refa445_inst, refa445_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa445_not1630 : ~ @Equation1630 Fin4 refa445_inst.
Proof. unfold Equation1630. intro H. specialize (H F4_0 F4_2). unfold magma_op, refa445_inst, refa445_op in H. discriminate H. Qed.

Lemma refa445_not1631 : ~ @Equation1631 Fin4 refa445_inst.
Proof. unfold Equation1631. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa445_inst, refa445_op in H. discriminate H. Qed.

Lemma refa445_not1632 : ~ @Equation1632 Fin4 refa445_inst.
Proof. unfold Equation1632. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa445_inst, refa445_op in H. discriminate H. Qed.

Lemma refa445_not1634 : ~ @Equation1634 Fin4 refa445_inst.
Proof. unfold Equation1634. intro H. specialize (H F4_3 F4_1). unfold magma_op, refa445_inst, refa445_op in H. discriminate H. Qed.

Lemma refa445_not1637 : ~ @Equation1637 Fin4 refa445_inst.
Proof. unfold Equation1637. intro H. specialize (H F4_0 F4_2). unfold magma_op, refa445_inst, refa445_op in H. discriminate H. Qed.

Lemma refa445_not1834 : ~ @Equation1834 Fin4 refa445_inst.
Proof. unfold Equation1834. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa445_inst, refa445_op in H. discriminate H. Qed.

Lemma refa445_not1837 : ~ @Equation1837 Fin4 refa445_inst.
Proof. unfold Equation1837. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa445_inst, refa445_op in H. discriminate H. Qed.

Lemma refa445_not1838 : ~ @Equation1838 Fin4 refa445_inst.
Proof. unfold Equation1838. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa445_inst, refa445_op in H. discriminate H. Qed.

Lemma refa445_not1840 : ~ @Equation1840 Fin4 refa445_inst.
Proof. unfold Equation1840. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa445_inst, refa445_op in H. discriminate H. Qed.

Lemma refa445_not2240 : ~ @Equation2240 Fin4 refa445_inst.
Proof. unfold Equation2240. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa445_inst, refa445_op in H. discriminate H. Qed.

Lemma refa445_not2246 : ~ @Equation2246 Fin4 refa445_inst.
Proof. unfold Equation2246. intro H. specialize (H F4_0 F4_2). unfold magma_op, refa445_inst, refa445_op in H. discriminate H. Qed.

Lemma refa445_not2253 : ~ @Equation2253 Fin4 refa445_inst.
Proof. unfold Equation2253. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa445_inst, refa445_op in H. discriminate H. Qed.

Lemma refa445_not2452 : ~ @Equation2452 Fin4 refa445_inst.
Proof. unfold Equation2452. intro H. specialize (H F4_0 F4_1 F4_3). unfold magma_op, refa445_inst, refa445_op in H. discriminate H. Qed.

Lemma refa445_not2459 : ~ @Equation2459 Fin4 refa445_inst.
Proof. unfold Equation2459. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa445_inst, refa445_op in H. discriminate H. Qed.

Lemma refa445_not3254 : ~ @Equation3254 Fin4 refa445_inst.
Proof. unfold Equation3254. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa445_inst, refa445_op in H. discriminate H. Qed.

Lemma refa445_not3256 : ~ @Equation3256 Fin4 refa445_inst.
Proof. unfold Equation3256. intro H. specialize (H F4_0 F4_2). unfold magma_op, refa445_inst, refa445_op in H. discriminate H. Qed.

Lemma refa445_not3258 : ~ @Equation3258 Fin4 refa445_inst.
Proof. unfold Equation3258. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa445_inst, refa445_op in H. discriminate H. Qed.

Lemma refa445_not3316 : ~ @Equation3316 Fin4 refa445_inst.
Proof. unfold Equation3316. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa445_inst, refa445_op in H. discriminate H. Qed.

Lemma refa445_not3318 : ~ @Equation3318 Fin4 refa445_inst.
Proof. unfold Equation3318. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa445_inst, refa445_op in H. discriminate H. Qed.

Lemma refa445_not3319 : ~ @Equation3319 Fin4 refa445_inst.
Proof. unfold Equation3319. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa445_inst, refa445_op in H. discriminate H. Qed.

Lemma refa445_not3460 : ~ @Equation3460 Fin4 refa445_inst.
Proof. unfold Equation3460. intro H. specialize (H F4_0 F4_1 F4_3). unfold magma_op, refa445_inst, refa445_op in H. discriminate H. Qed.

Lemma refa445_not3462 : ~ @Equation3462 Fin4 refa445_inst.
Proof. unfold Equation3462. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa445_inst, refa445_op in H. discriminate H. Qed.

Lemma refa445_not4120 : ~ @Equation4120 Fin4 refa445_inst.
Proof. unfold Equation4120. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa445_inst, refa445_op in H. discriminate H. Qed.

Lemma refa445_not4121 : ~ @Equation4121 Fin4 refa445_inst.
Proof. unfold Equation4121. intro H. specialize (H F4_0 F4_2). unfold magma_op, refa445_inst, refa445_op in H. discriminate H. Qed.

Lemma refa445_not4127 : ~ @Equation4127 Fin4 refa445_inst.
Proof. unfold Equation4127. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa445_inst, refa445_op in H. discriminate H. Qed.

Lemma refa445_not4130 : ~ @Equation4130 Fin4 refa445_inst.
Proof. unfold Equation4130. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa445_inst, refa445_op in H. discriminate H. Qed.

Lemma refa445_not4131 : ~ @Equation4131 Fin4 refa445_inst.
Proof. unfold Equation4131. intro H. specialize (H F4_0 F4_2). unfold magma_op, refa445_inst, refa445_op in H. discriminate H. Qed.

Lemma refa445_not4268 : ~ @Equation4268 Fin4 refa445_inst.
Proof. unfold Equation4268. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa445_inst, refa445_op in H. discriminate H. Qed.

Lemma refa445_not4283 : ~ @Equation4283 Fin4 refa445_inst.
Proof. unfold Equation4283. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa445_inst, refa445_op in H. discriminate H. Qed.

Lemma refa445_not4598 : ~ @Equation4598 Fin4 refa445_inst.
Proof. unfold Equation4598. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa445_inst, refa445_op in H. discriminate H. Qed.

Lemma refa445_not4599 : ~ @Equation4599 Fin4 refa445_inst.
Proof. unfold Equation4599. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa445_inst, refa445_op in H. discriminate H. Qed.

Lemma refa445_not4629 : ~ @Equation4629 Fin4 refa445_inst.
Proof. unfold Equation4629. intro H. specialize (H F4_0 F4_2). unfold magma_op, refa445_inst, refa445_op in H. discriminate H. Qed.

(** ---- refa446 (Fin4) ---- *)

Definition refa446_op (x y : Fin4) : Fin4 :=
  match x, y with
  | F4_0, F4_0 => F4_0 | F4_0, F4_1 => F4_2 | F4_0, F4_2 => F4_1 | F4_0, F4_3 => F4_3
  | F4_1, F4_0 => F4_0 | F4_1, F4_1 => F4_1 | F4_1, F4_2 => F4_2 | F4_1, F4_3 => F4_3
  | F4_2, F4_0 => F4_3 | F4_2, F4_1 => F4_1 | F4_2, F4_2 => F4_2 | F4_2, F4_3 => F4_0
  | F4_3, F4_0 => F4_0 | F4_3, F4_1 => F4_1 | F4_3, F4_2 => F4_2 | F4_3, F4_3 => F4_3
  end.

#[local] Instance refa446_inst : Magma Fin4 := {| magma_op := refa446_op |}.

Lemma refa446_sat65 : @Equation65 Fin4 refa446_inst.
Proof. unfold Equation65, magma_op, refa446_inst, refa446_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa446_sat679 : @Equation679 Fin4 refa446_inst.
Proof. unfold Equation679, magma_op, refa446_inst, refa446_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa446_sat1491 : @Equation1491 Fin4 refa446_inst.
Proof. unfold Equation1491, magma_op, refa446_inst, refa446_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa446_sat1518 : @Equation1518 Fin4 refa446_inst.
Proof. unfold Equation1518, magma_op, refa446_inst, refa446_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa446_not632 : ~ @Equation632 Fin4 refa446_inst.
Proof. unfold Equation632. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa446_inst, refa446_op in H. discriminate H. Qed.

Lemma refa446_not669 : ~ @Equation669 Fin4 refa446_inst.
Proof. unfold Equation669. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa446_inst, refa446_op in H. discriminate H. Qed.

Lemma refa446_not825 : ~ @Equation825 Fin4 refa446_inst.
Proof. unfold Equation825. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa446_inst, refa446_op in H. discriminate H. Qed.

Lemma refa446_not879 : ~ @Equation879 Fin4 refa446_inst.
Proof. unfold Equation879. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa446_inst, refa446_op in H. discriminate H. Qed.

Lemma refa446_not1444 : ~ @Equation1444 Fin4 refa446_inst.
Proof. unfold Equation1444. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa446_inst, refa446_op in H. discriminate H. Qed.

Lemma refa446_not1451 : ~ @Equation1451 Fin4 refa446_inst.
Proof. unfold Equation1451. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa446_inst, refa446_op in H. discriminate H. Qed.

Lemma refa446_not3925 : ~ @Equation3925 Fin4 refa446_inst.
Proof. unfold Equation3925. intro H. specialize (H F4_0 F4_2). unfold magma_op, refa446_inst, refa446_op in H. discriminate H. Qed.

Lemma refa446_not3952 : ~ @Equation3952 Fin4 refa446_inst.
Proof. unfold Equation3952. intro H. specialize (H F4_0 F4_2). unfold magma_op, refa446_inst, refa446_op in H. discriminate H. Qed.

Lemma refa446_not4128 : ~ @Equation4128 Fin4 refa446_inst.
Proof. unfold Equation4128. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa446_inst, refa446_op in H. discriminate H. Qed.

Lemma refa446_not4165 : ~ @Equation4165 Fin4 refa446_inst.
Proof. unfold Equation4165. intro H. specialize (H F4_0 F4_2). unfold magma_op, refa446_inst, refa446_op in H. discriminate H. Qed.

Lemma refa446_not4606 : ~ @Equation4606 Fin4 refa446_inst.
Proof. unfold Equation4606. intro H. specialize (H F4_0 F4_2). unfold magma_op, refa446_inst, refa446_op in H. discriminate H. Qed.

(** ---- refa447 (Fin4) ---- *)

Definition refa447_op (x y : Fin4) : Fin4 :=
  match x, y with
  | F4_0, F4_0 => F4_1 | F4_0, F4_1 => F4_1 | F4_0, F4_2 => F4_1 | F4_0, F4_3 => F4_1
  | F4_1, F4_0 => F4_2 | F4_1, F4_1 => F4_3 | F4_1, F4_2 => F4_2 | F4_1, F4_3 => F4_3
  | F4_2, F4_0 => F4_3 | F4_2, F4_1 => F4_1 | F4_2, F4_2 => F4_3 | F4_2, F4_3 => F4_3
  | F4_3, F4_0 => F4_0 | F4_3, F4_1 => F4_1 | F4_3, F4_2 => F4_2 | F4_3, F4_3 => F4_3
  end.

#[local] Instance refa447_inst : Magma Fin4 := {| magma_op := refa447_op |}.

Lemma refa447_sat3197 : @Equation3197 Fin4 refa447_inst.
Proof. unfold Equation3197, magma_op, refa447_inst, refa447_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa447_not203 : ~ @Equation203 Fin4 refa447_inst.
Proof. unfold Equation203. intro H. specialize (H F4_0). unfold magma_op, refa447_inst, refa447_op in H. discriminate H. Qed.

Lemma refa447_not1629 : ~ @Equation1629 Fin4 refa447_inst.
Proof. unfold Equation1629. intro H. specialize (H F4_0). unfold magma_op, refa447_inst, refa447_op in H. discriminate H. Qed.

Lemma refa447_not2238 : ~ @Equation2238 Fin4 refa447_inst.
Proof. unfold Equation2238. intro H. specialize (H F4_0). unfold magma_op, refa447_inst, refa447_op in H. discriminate H. Qed.

Lemma refa447_not2441 : ~ @Equation2441 Fin4 refa447_inst.
Proof. unfold Equation2441. intro H. specialize (H F4_0). unfold magma_op, refa447_inst, refa447_op in H. discriminate H. Qed.

Lemma refa447_not2652 : ~ @Equation2652 Fin4 refa447_inst.
Proof. unfold Equation2652. intro H. specialize (H F4_1 F4_0). unfold magma_op, refa447_inst, refa447_op in H. discriminate H. Qed.

Lemma refa447_not2709 : ~ @Equation2709 Fin4 refa447_inst.
Proof. unfold Equation2709. intro H. specialize (H F4_0 F4_3). unfold magma_op, refa447_inst, refa447_op in H. discriminate H. Qed.

Lemma refa447_not3058 : ~ @Equation3058 Fin4 refa447_inst.
Proof. unfold Equation3058. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa447_inst, refa447_op in H. discriminate H. Qed.

Lemma refa447_not3519 : ~ @Equation3519 Fin4 refa447_inst.
Proof. unfold Equation3519. intro H. specialize (H F4_3 F4_0). unfold magma_op, refa447_inst, refa447_op in H. discriminate H. Qed.

Lemma refa447_not3522 : ~ @Equation3522 Fin4 refa447_inst.
Proof. unfold Equation3522. intro H. specialize (H F4_3 F4_0). unfold magma_op, refa447_inst, refa447_op in H. discriminate H. Qed.

Lemma refa447_not3659 : ~ @Equation3659 Fin4 refa447_inst.
Proof. unfold Equation3659. intro H. specialize (H F4_0). unfold magma_op, refa447_inst, refa447_op in H. discriminate H. Qed.

Lemma refa447_not4065 : ~ @Equation4065 Fin4 refa447_inst.
Proof. unfold Equation4065. intro H. specialize (H F4_0). unfold magma_op, refa447_inst, refa447_op in H. discriminate H. Qed.

Lemma refa447_not4622 : ~ @Equation4622 Fin4 refa447_inst.
Proof. unfold Equation4622. intro H. specialize (H F4_0 F4_0 F4_1). unfold magma_op, refa447_inst, refa447_op in H. discriminate H. Qed.

(** ---- refa448 (Fin4) ---- *)

Definition refa448_op (x y : Fin4) : Fin4 :=
  match x, y with
  | F4_0, F4_0 => F4_2 | F4_0, F4_1 => F4_2 | F4_0, F4_2 => F4_1 | F4_0, F4_3 => F4_1
  | F4_1, F4_0 => F4_3 | F4_1, F4_1 => F4_3 | F4_1, F4_2 => F4_3 | F4_1, F4_3 => F4_2
  | F4_2, F4_0 => F4_1 | F4_2, F4_1 => F4_0 | F4_2, F4_2 => F4_0 | F4_2, F4_3 => F4_3
  | F4_3, F4_0 => F4_0 | F4_3, F4_1 => F4_1 | F4_3, F4_2 => F4_2 | F4_3, F4_3 => F4_0
  end.

#[local] Instance refa448_inst : Magma Fin4 := {| magma_op := refa448_op |}.

Lemma refa448_sat3106 : @Equation3106 Fin4 refa448_inst.
Proof. unfold Equation3106, magma_op, refa448_inst, refa448_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa448_sat3149 : @Equation3149 Fin4 refa448_inst.
Proof. unfold Equation3149, magma_op, refa448_inst, refa448_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa448_not99 : ~ @Equation99 Fin4 refa448_inst.
Proof. unfold Equation99. intro H. specialize (H F4_0). unfold magma_op, refa448_inst, refa448_op in H. discriminate H. Qed.

(** ---- refa449 (Fin4) ---- *)

Definition refa449_op (x y : Fin4) : Fin4 :=
  match x, y with
  | F4_0, F4_0 => F4_3 | F4_0, F4_1 => F4_1 | F4_0, F4_2 => F4_1 | F4_0, F4_3 => F4_1
  | F4_1, F4_0 => F4_1 | F4_1, F4_1 => F4_1 | F4_1, F4_2 => F4_1 | F4_1, F4_3 => F4_1
  | F4_2, F4_0 => F4_1 | F4_2, F4_1 => F4_3 | F4_2, F4_2 => F4_1 | F4_2, F4_3 => F4_1
  | F4_3, F4_0 => F4_3 | F4_3, F4_1 => F4_3 | F4_3, F4_2 => F4_3 | F4_3, F4_3 => F4_3
  end.

#[local] Instance refa449_inst : Magma Fin4 := {| magma_op := refa449_op |}.

Lemma refa449_sat379 : @Equation379 Fin4 refa449_inst.
Proof. unfold Equation379, magma_op, refa449_inst, refa449_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa449_not4314 : ~ @Equation4314 Fin4 refa449_inst.
Proof. unfold Equation4314. intro H. specialize (H F4_2 F4_0). unfold magma_op, refa449_inst, refa449_op in H. discriminate H. Qed.

(** ---- refa45 (Fin2) ---- *)

Definition refa45_op (x y : Fin2) : Fin2 :=
  match x, y with
  | F2_0, F2_0 => F2_0 | F2_0, F2_1 => F2_1
  | F2_1, F2_0 => F2_1 | F2_1, F2_1 => F2_0
  end.

#[local] Instance refa45_inst : Magma Fin2 := {| magma_op := refa45_op |}.

Lemma refa45_sat2113 : @Equation2113 Fin2 refa45_inst.
Proof. unfold Equation2113, magma_op, refa45_inst, refa45_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa45_not47 : ~ @Equation47 Fin2 refa45_inst.
Proof. unfold Equation47. intro H. specialize (H F2_1). unfold magma_op, refa45_inst, refa45_op in H. discriminate H. Qed.

Lemma refa45_not99 : ~ @Equation99 Fin2 refa45_inst.
Proof. unfold Equation99. intro H. specialize (H F2_1). unfold magma_op, refa45_inst, refa45_op in H. discriminate H. Qed.

Lemma refa45_not151 : ~ @Equation151 Fin2 refa45_inst.
Proof. unfold Equation151. intro H. specialize (H F2_1). unfold magma_op, refa45_inst, refa45_op in H. discriminate H. Qed.

Lemma refa45_not203 : ~ @Equation203 Fin2 refa45_inst.
Proof. unfold Equation203. intro H. specialize (H F2_1). unfold magma_op, refa45_inst, refa45_op in H. discriminate H. Qed.

Lemma refa45_not255 : ~ @Equation255 Fin2 refa45_inst.
Proof. unfold Equation255. intro H. specialize (H F2_1). unfold magma_op, refa45_inst, refa45_op in H. discriminate H. Qed.

Lemma refa45_not307 : ~ @Equation307 Fin2 refa45_inst.
Proof. unfold Equation307. intro H. specialize (H F2_1). unfold magma_op, refa45_inst, refa45_op in H. discriminate H. Qed.

Lemma refa45_not359 : ~ @Equation359 Fin2 refa45_inst.
Proof. unfold Equation359. intro H. specialize (H F2_1). unfold magma_op, refa45_inst, refa45_op in H. discriminate H. Qed.

Lemma refa45_not413 : ~ @Equation413 Fin2 refa45_inst.
Proof. unfold Equation413. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa45_inst, refa45_op in H. discriminate H. Qed.

Lemma refa45_not416 : ~ @Equation416 Fin2 refa45_inst.
Proof. unfold Equation416. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa45_inst, refa45_op in H. discriminate H. Qed.

Lemma refa45_not420 : ~ @Equation420 Fin2 refa45_inst.
Proof. unfold Equation420. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa45_inst, refa45_op in H. discriminate H. Qed.

Lemma refa45_not426 : ~ @Equation426 Fin2 refa45_inst.
Proof. unfold Equation426. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa45_inst, refa45_op in H. discriminate H. Qed.

Lemma refa45_not430 : ~ @Equation430 Fin2 refa45_inst.
Proof. unfold Equation430. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa45_inst, refa45_op in H. discriminate H. Qed.

Lemma refa45_not437 : ~ @Equation437 Fin2 refa45_inst.
Proof. unfold Equation437. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa45_inst, refa45_op in H. discriminate H. Qed.

Lemma refa45_not467 : ~ @Equation467 Fin2 refa45_inst.
Proof. unfold Equation467. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa45_inst, refa45_op in H. discriminate H. Qed.

Lemma refa45_not474 : ~ @Equation474 Fin2 refa45_inst.
Proof. unfold Equation474. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa45_inst, refa45_op in H. discriminate H. Qed.

Lemma refa45_not476 : ~ @Equation476 Fin2 refa45_inst.
Proof. unfold Equation476. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa45_inst, refa45_op in H. discriminate H. Qed.

Lemma refa45_not501 : ~ @Equation501 Fin2 refa45_inst.
Proof. unfold Equation501. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa45_inst, refa45_op in H. discriminate H. Qed.

Lemma refa45_not503 : ~ @Equation503 Fin2 refa45_inst.
Proof. unfold Equation503. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa45_inst, refa45_op in H. discriminate H. Qed.

Lemma refa45_not619 : ~ @Equation619 Fin2 refa45_inst.
Proof. unfold Equation619. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa45_inst, refa45_op in H. discriminate H. Qed.

Lemma refa45_not623 : ~ @Equation623 Fin2 refa45_inst.
Proof. unfold Equation623. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa45_inst, refa45_op in H. discriminate H. Qed.

Lemma refa45_not629 : ~ @Equation629 Fin2 refa45_inst.
Proof. unfold Equation629. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa45_inst, refa45_op in H. discriminate H. Qed.

Lemma refa45_not633 : ~ @Equation633 Fin2 refa45_inst.
Proof. unfold Equation633. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa45_inst, refa45_op in H. discriminate H. Qed.

Lemma refa45_not640 : ~ @Equation640 Fin2 refa45_inst.
Proof. unfold Equation640. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa45_inst, refa45_op in H. discriminate H. Qed.

Lemma refa45_not642 : ~ @Equation642 Fin2 refa45_inst.
Proof. unfold Equation642. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa45_inst, refa45_op in H. discriminate H. Qed.

Lemma refa45_not670 : ~ @Equation670 Fin2 refa45_inst.
Proof. unfold Equation670. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa45_inst, refa45_op in H. discriminate H. Qed.

Lemma refa45_not677 : ~ @Equation677 Fin2 refa45_inst.
Proof. unfold Equation677. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa45_inst, refa45_op in H. discriminate H. Qed.

Lemma refa45_not679 : ~ @Equation679 Fin2 refa45_inst.
Proof. unfold Equation679. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa45_inst, refa45_op in H. discriminate H. Qed.

Lemma refa45_not704 : ~ @Equation704 Fin2 refa45_inst.
Proof. unfold Equation704. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa45_inst, refa45_op in H. discriminate H. Qed.

Lemma refa45_not706 : ~ @Equation706 Fin2 refa45_inst.
Proof. unfold Equation706. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa45_inst, refa45_op in H. discriminate H. Qed.

Lemma refa45_not819 : ~ @Equation819 Fin2 refa45_inst.
Proof. unfold Equation819. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa45_inst, refa45_op in H. discriminate H. Qed.

Lemma refa45_not826 : ~ @Equation826 Fin2 refa45_inst.
Proof. unfold Equation826. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa45_inst, refa45_op in H. discriminate H. Qed.

Lemma refa45_not832 : ~ @Equation832 Fin2 refa45_inst.
Proof. unfold Equation832. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa45_inst, refa45_op in H. discriminate H. Qed.

Lemma refa45_not836 : ~ @Equation836 Fin2 refa45_inst.
Proof. unfold Equation836. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa45_inst, refa45_op in H. discriminate H. Qed.

Lemma refa45_not843 : ~ @Equation843 Fin2 refa45_inst.
Proof. unfold Equation843. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa45_inst, refa45_op in H. discriminate H. Qed.

Lemma refa45_not845 : ~ @Equation845 Fin2 refa45_inst.
Proof. unfold Equation845. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa45_inst, refa45_op in H. discriminate H. Qed.

Lemma refa45_not873 : ~ @Equation873 Fin2 refa45_inst.
Proof. unfold Equation873. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa45_inst, refa45_op in H. discriminate H. Qed.

Lemma refa45_not882 : ~ @Equation882 Fin2 refa45_inst.
Proof. unfold Equation882. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa45_inst, refa45_op in H. discriminate H. Qed.

Lemma refa45_not907 : ~ @Equation907 Fin2 refa45_inst.
Proof. unfold Equation907. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa45_inst, refa45_op in H. discriminate H. Qed.

Lemma refa45_not1025 : ~ @Equation1025 Fin2 refa45_inst.
Proof. unfold Equation1025. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa45_inst, refa45_op in H. discriminate H. Qed.

Lemma refa45_not1029 : ~ @Equation1029 Fin2 refa45_inst.
Proof. unfold Equation1029. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa45_inst, refa45_op in H. discriminate H. Qed.

Lemma refa45_not1035 : ~ @Equation1035 Fin2 refa45_inst.
Proof. unfold Equation1035. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa45_inst, refa45_op in H. discriminate H. Qed.

Lemma refa45_not1039 : ~ @Equation1039 Fin2 refa45_inst.
Proof. unfold Equation1039. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa45_inst, refa45_op in H. discriminate H. Qed.

Lemma refa45_not1046 : ~ @Equation1046 Fin2 refa45_inst.
Proof. unfold Equation1046. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa45_inst, refa45_op in H. discriminate H. Qed.

Lemma refa45_not1048 : ~ @Equation1048 Fin2 refa45_inst.
Proof. unfold Equation1048. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa45_inst, refa45_op in H. discriminate H. Qed.

Lemma refa45_not1076 : ~ @Equation1076 Fin2 refa45_inst.
Proof. unfold Equation1076. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa45_inst, refa45_op in H. discriminate H. Qed.

Lemma refa45_not1083 : ~ @Equation1083 Fin2 refa45_inst.
Proof. unfold Equation1083. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa45_inst, refa45_op in H. discriminate H. Qed.

Lemma refa45_not1085 : ~ @Equation1085 Fin2 refa45_inst.
Proof. unfold Equation1085. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa45_inst, refa45_op in H. discriminate H. Qed.

Lemma refa45_not1110 : ~ @Equation1110 Fin2 refa45_inst.
Proof. unfold Equation1110. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa45_inst, refa45_op in H. discriminate H. Qed.

Lemma refa45_not1112 : ~ @Equation1112 Fin2 refa45_inst.
Proof. unfold Equation1112. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa45_inst, refa45_op in H. discriminate H. Qed.

Lemma refa45_not1238 : ~ @Equation1238 Fin2 refa45_inst.
Proof. unfold Equation1238. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa45_inst, refa45_op in H. discriminate H. Qed.

Lemma refa45_not1242 : ~ @Equation1242 Fin2 refa45_inst.
Proof. unfold Equation1242. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa45_inst, refa45_op in H. discriminate H. Qed.

Lemma refa45_not1249 : ~ @Equation1249 Fin2 refa45_inst.
Proof. unfold Equation1249. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa45_inst, refa45_op in H. discriminate H. Qed.

Lemma refa45_not1251 : ~ @Equation1251 Fin2 refa45_inst.
Proof. unfold Equation1251. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa45_inst, refa45_op in H. discriminate H. Qed.

Lemma refa45_not1279 : ~ @Equation1279 Fin2 refa45_inst.
Proof. unfold Equation1279. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa45_inst, refa45_op in H. discriminate H. Qed.

Lemma refa45_not1286 : ~ @Equation1286 Fin2 refa45_inst.
Proof. unfold Equation1286. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa45_inst, refa45_op in H. discriminate H. Qed.

Lemma refa45_not1288 : ~ @Equation1288 Fin2 refa45_inst.
Proof. unfold Equation1288. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa45_inst, refa45_op in H. discriminate H. Qed.

Lemma refa45_not1315 : ~ @Equation1315 Fin2 refa45_inst.
Proof. unfold Equation1315. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa45_inst, refa45_op in H. discriminate H. Qed.

Lemma refa45_not1322 : ~ @Equation1322 Fin2 refa45_inst.
Proof. unfold Equation1322. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa45_inst, refa45_op in H. discriminate H. Qed.

Lemma refa45_not1427 : ~ @Equation1427 Fin2 refa45_inst.
Proof. unfold Equation1427. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa45_inst, refa45_op in H. discriminate H. Qed.

Lemma refa45_not1428 : ~ @Equation1428 Fin2 refa45_inst.
Proof. unfold Equation1428. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa45_inst, refa45_op in H. discriminate H. Qed.

Lemma refa45_not1431 : ~ @Equation1431 Fin2 refa45_inst.
Proof. unfold Equation1431. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa45_inst, refa45_op in H. discriminate H. Qed.

Lemma refa45_not1435 : ~ @Equation1435 Fin2 refa45_inst.
Proof. unfold Equation1435. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa45_inst, refa45_op in H. discriminate H. Qed.

Lemma refa45_not1441 : ~ @Equation1441 Fin2 refa45_inst.
Proof. unfold Equation1441. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa45_inst, refa45_op in H. discriminate H. Qed.

Lemma refa45_not1445 : ~ @Equation1445 Fin2 refa45_inst.
Proof. unfold Equation1445. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa45_inst, refa45_op in H. discriminate H. Qed.

Lemma refa45_not1454 : ~ @Equation1454 Fin2 refa45_inst.
Proof. unfold Equation1454. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa45_inst, refa45_op in H. discriminate H. Qed.

Lemma refa45_not1478 : ~ @Equation1478 Fin2 refa45_inst.
Proof. unfold Equation1478. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa45_inst, refa45_op in H. discriminate H. Qed.

Lemma refa45_not1482 : ~ @Equation1482 Fin2 refa45_inst.
Proof. unfold Equation1482. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa45_inst, refa45_op in H. discriminate H. Qed.

Lemma refa45_not1516 : ~ @Equation1516 Fin2 refa45_inst.
Proof. unfold Equation1516. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa45_inst, refa45_op in H. discriminate H. Qed.

Lemma refa45_not1525 : ~ @Equation1525 Fin2 refa45_inst.
Proof. unfold Equation1525. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa45_inst, refa45_op in H. discriminate H. Qed.

Lemma refa45_not1630 : ~ @Equation1630 Fin2 refa45_inst.
Proof. unfold Equation1630. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa45_inst, refa45_op in H. discriminate H. Qed.

Lemma refa45_not1631 : ~ @Equation1631 Fin2 refa45_inst.
Proof. unfold Equation1631. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa45_inst, refa45_op in H. discriminate H. Qed.

Lemma refa45_not1634 : ~ @Equation1634 Fin2 refa45_inst.
Proof. unfold Equation1634. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa45_inst, refa45_op in H. discriminate H. Qed.

Lemma refa45_not1638 : ~ @Equation1638 Fin2 refa45_inst.
Proof. unfold Equation1638. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa45_inst, refa45_op in H. discriminate H. Qed.

Lemma refa45_not1644 : ~ @Equation1644 Fin2 refa45_inst.
Proof. unfold Equation1644. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa45_inst, refa45_op in H. discriminate H. Qed.

Lemma refa45_not1648 : ~ @Equation1648 Fin2 refa45_inst.
Proof. unfold Equation1648. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa45_inst, refa45_op in H. discriminate H. Qed.

Lemma refa45_not1655 : ~ @Equation1655 Fin2 refa45_inst.
Proof. unfold Equation1655. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa45_inst, refa45_op in H. discriminate H. Qed.

Lemma refa45_not1657 : ~ @Equation1657 Fin2 refa45_inst.
Proof. unfold Equation1657. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa45_inst, refa45_op in H. discriminate H. Qed.

Lemma refa45_not1681 : ~ @Equation1681 Fin2 refa45_inst.
Proof. unfold Equation1681. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa45_inst, refa45_op in H. discriminate H. Qed.

Lemma refa45_not1685 : ~ @Equation1685 Fin2 refa45_inst.
Proof. unfold Equation1685. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa45_inst, refa45_op in H. discriminate H. Qed.

Lemma refa45_not1692 : ~ @Equation1692 Fin2 refa45_inst.
Proof. unfold Equation1692. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa45_inst, refa45_op in H. discriminate H. Qed.

Lemma refa45_not1694 : ~ @Equation1694 Fin2 refa45_inst.
Proof. unfold Equation1694. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa45_inst, refa45_op in H. discriminate H. Qed.

Lemma refa45_not1719 : ~ @Equation1719 Fin2 refa45_inst.
Proof. unfold Equation1719. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa45_inst, refa45_op in H. discriminate H. Qed.

Lemma refa45_not1721 : ~ @Equation1721 Fin2 refa45_inst.
Proof. unfold Equation1721. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa45_inst, refa45_op in H. discriminate H. Qed.

Lemma refa45_not1728 : ~ @Equation1728 Fin2 refa45_inst.
Proof. unfold Equation1728. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa45_inst, refa45_op in H. discriminate H. Qed.

Lemma refa45_not1833 : ~ @Equation1833 Fin2 refa45_inst.
Proof. unfold Equation1833. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa45_inst, refa45_op in H. discriminate H. Qed.

Lemma refa45_not1834 : ~ @Equation1834 Fin2 refa45_inst.
Proof. unfold Equation1834. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa45_inst, refa45_op in H. discriminate H. Qed.

Lemma refa45_not1837 : ~ @Equation1837 Fin2 refa45_inst.
Proof. unfold Equation1837. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa45_inst, refa45_op in H. discriminate H. Qed.

Lemma refa45_not1841 : ~ @Equation1841 Fin2 refa45_inst.
Proof. unfold Equation1841. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa45_inst, refa45_op in H. discriminate H. Qed.

Lemma refa45_not1847 : ~ @Equation1847 Fin2 refa45_inst.
Proof. unfold Equation1847. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa45_inst, refa45_op in H. discriminate H. Qed.

Lemma refa45_not1851 : ~ @Equation1851 Fin2 refa45_inst.
Proof. unfold Equation1851. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa45_inst, refa45_op in H. discriminate H. Qed.

Lemma refa45_not1858 : ~ @Equation1858 Fin2 refa45_inst.
Proof. unfold Equation1858. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa45_inst, refa45_op in H. discriminate H. Qed.

Lemma refa45_not1860 : ~ @Equation1860 Fin2 refa45_inst.
Proof. unfold Equation1860. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa45_inst, refa45_op in H. discriminate H. Qed.

Lemma refa45_not1884 : ~ @Equation1884 Fin2 refa45_inst.
Proof. unfold Equation1884. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa45_inst, refa45_op in H. discriminate H. Qed.

Lemma refa45_not1888 : ~ @Equation1888 Fin2 refa45_inst.
Proof. unfold Equation1888. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa45_inst, refa45_op in H. discriminate H. Qed.

Lemma refa45_not1895 : ~ @Equation1895 Fin2 refa45_inst.
Proof. unfold Equation1895. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa45_inst, refa45_op in H. discriminate H. Qed.

Lemma refa45_not1897 : ~ @Equation1897 Fin2 refa45_inst.
Proof. unfold Equation1897. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa45_inst, refa45_op in H. discriminate H. Qed.

Lemma refa45_not1922 : ~ @Equation1922 Fin2 refa45_inst.
Proof. unfold Equation1922. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa45_inst, refa45_op in H. discriminate H. Qed.

Lemma refa45_not1924 : ~ @Equation1924 Fin2 refa45_inst.
Proof. unfold Equation1924. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa45_inst, refa45_op in H. discriminate H. Qed.

Lemma refa45_not1931 : ~ @Equation1931 Fin2 refa45_inst.
Proof. unfold Equation1931. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa45_inst, refa45_op in H. discriminate H. Qed.

Lemma refa45_not2036 : ~ @Equation2036 Fin2 refa45_inst.
Proof. unfold Equation2036. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa45_inst, refa45_op in H. discriminate H. Qed.

Lemma refa45_not2037 : ~ @Equation2037 Fin2 refa45_inst.
Proof. unfold Equation2037. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa45_inst, refa45_op in H. discriminate H. Qed.

Lemma refa45_not2040 : ~ @Equation2040 Fin2 refa45_inst.
Proof. unfold Equation2040. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa45_inst, refa45_op in H. discriminate H. Qed.

Lemma refa45_not2044 : ~ @Equation2044 Fin2 refa45_inst.
Proof. unfold Equation2044. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa45_inst, refa45_op in H. discriminate H. Qed.

Lemma refa45_not2050 : ~ @Equation2050 Fin2 refa45_inst.
Proof. unfold Equation2050. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa45_inst, refa45_op in H. discriminate H. Qed.

Lemma refa45_not2063 : ~ @Equation2063 Fin2 refa45_inst.
Proof. unfold Equation2063. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa45_inst, refa45_op in H. discriminate H. Qed.

Lemma refa45_not2087 : ~ @Equation2087 Fin2 refa45_inst.
Proof. unfold Equation2087. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa45_inst, refa45_op in H. discriminate H. Qed.

Lemma refa45_not2091 : ~ @Equation2091 Fin2 refa45_inst.
Proof. unfold Equation2091. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa45_inst, refa45_op in H. discriminate H. Qed.

Lemma refa45_not2125 : ~ @Equation2125 Fin2 refa45_inst.
Proof. unfold Equation2125. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa45_inst, refa45_op in H. discriminate H. Qed.

Lemma refa45_not2127 : ~ @Equation2127 Fin2 refa45_inst.
Proof. unfold Equation2127. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa45_inst, refa45_op in H. discriminate H. Qed.

Lemma refa45_not2134 : ~ @Equation2134 Fin2 refa45_inst.
Proof. unfold Equation2134. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa45_inst, refa45_op in H. discriminate H. Qed.

Lemma refa45_not2240 : ~ @Equation2240 Fin2 refa45_inst.
Proof. unfold Equation2240. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa45_inst, refa45_op in H. discriminate H. Qed.

Lemma refa45_not2247 : ~ @Equation2247 Fin2 refa45_inst.
Proof. unfold Equation2247. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa45_inst, refa45_op in H. discriminate H. Qed.

Lemma refa45_not2257 : ~ @Equation2257 Fin2 refa45_inst.
Proof. unfold Equation2257. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa45_inst, refa45_op in H. discriminate H. Qed.

Lemma refa45_not2264 : ~ @Equation2264 Fin2 refa45_inst.
Proof. unfold Equation2264. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa45_inst, refa45_op in H. discriminate H. Qed.

Lemma refa45_not2266 : ~ @Equation2266 Fin2 refa45_inst.
Proof. unfold Equation2266. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa45_inst, refa45_op in H. discriminate H. Qed.

Lemma refa45_not2301 : ~ @Equation2301 Fin2 refa45_inst.
Proof. unfold Equation2301. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa45_inst, refa45_op in H. discriminate H. Qed.

Lemma refa45_not2303 : ~ @Equation2303 Fin2 refa45_inst.
Proof. unfold Equation2303. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa45_inst, refa45_op in H. discriminate H. Qed.

Lemma refa45_not2328 : ~ @Equation2328 Fin2 refa45_inst.
Proof. unfold Equation2328. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa45_inst, refa45_op in H. discriminate H. Qed.

Lemma refa45_not2330 : ~ @Equation2330 Fin2 refa45_inst.
Proof. unfold Equation2330. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa45_inst, refa45_op in H. discriminate H. Qed.

Lemma refa45_not2443 : ~ @Equation2443 Fin2 refa45_inst.
Proof. unfold Equation2443. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa45_inst, refa45_op in H. discriminate H. Qed.

Lemma refa45_not2446 : ~ @Equation2446 Fin2 refa45_inst.
Proof. unfold Equation2446. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa45_inst, refa45_op in H. discriminate H. Qed.

Lemma refa45_not2460 : ~ @Equation2460 Fin2 refa45_inst.
Proof. unfold Equation2460. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa45_inst, refa45_op in H. discriminate H. Qed.

Lemma refa45_not2467 : ~ @Equation2467 Fin2 refa45_inst.
Proof. unfold Equation2467. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa45_inst, refa45_op in H. discriminate H. Qed.

Lemma refa45_not2469 : ~ @Equation2469 Fin2 refa45_inst.
Proof. unfold Equation2469. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa45_inst, refa45_op in H. discriminate H. Qed.

Lemma refa45_not2497 : ~ @Equation2497 Fin2 refa45_inst.
Proof. unfold Equation2497. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa45_inst, refa45_op in H. discriminate H. Qed.

Lemma refa45_not2504 : ~ @Equation2504 Fin2 refa45_inst.
Proof. unfold Equation2504. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa45_inst, refa45_op in H. discriminate H. Qed.

Lemma refa45_not2506 : ~ @Equation2506 Fin2 refa45_inst.
Proof. unfold Equation2506. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa45_inst, refa45_op in H. discriminate H. Qed.

Lemma refa45_not2531 : ~ @Equation2531 Fin2 refa45_inst.
Proof. unfold Equation2531. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa45_inst, refa45_op in H. discriminate H. Qed.

Lemma refa45_not2533 : ~ @Equation2533 Fin2 refa45_inst.
Proof. unfold Equation2533. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa45_inst, refa45_op in H. discriminate H. Qed.

Lemma refa45_not2540 : ~ @Equation2540 Fin2 refa45_inst.
Proof. unfold Equation2540. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa45_inst, refa45_op in H. discriminate H. Qed.

Lemma refa45_not2646 : ~ @Equation2646 Fin2 refa45_inst.
Proof. unfold Equation2646. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa45_inst, refa45_op in H. discriminate H. Qed.

Lemma refa45_not2659 : ~ @Equation2659 Fin2 refa45_inst.
Proof. unfold Equation2659. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa45_inst, refa45_op in H. discriminate H. Qed.

Lemma refa45_not2670 : ~ @Equation2670 Fin2 refa45_inst.
Proof. unfold Equation2670. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa45_inst, refa45_op in H. discriminate H. Qed.

Lemma refa45_not2672 : ~ @Equation2672 Fin2 refa45_inst.
Proof. unfold Equation2672. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa45_inst, refa45_op in H. discriminate H. Qed.

Lemma refa45_not2700 : ~ @Equation2700 Fin2 refa45_inst.
Proof. unfold Equation2700. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa45_inst, refa45_op in H. discriminate H. Qed.

Lemma refa45_not2709 : ~ @Equation2709 Fin2 refa45_inst.
Proof. unfold Equation2709. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa45_inst, refa45_op in H. discriminate H. Qed.

Lemma refa45_not2734 : ~ @Equation2734 Fin2 refa45_inst.
Proof. unfold Equation2734. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa45_inst, refa45_op in H. discriminate H. Qed.

Lemma refa45_not2736 : ~ @Equation2736 Fin2 refa45_inst.
Proof. unfold Equation2736. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa45_inst, refa45_op in H. discriminate H. Qed.

Lemma refa45_not2743 : ~ @Equation2743 Fin2 refa45_inst.
Proof. unfold Equation2743. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa45_inst, refa45_op in H. discriminate H. Qed.

Lemma refa45_not2849 : ~ @Equation2849 Fin2 refa45_inst.
Proof. unfold Equation2849. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa45_inst, refa45_op in H. discriminate H. Qed.

Lemma refa45_not2852 : ~ @Equation2852 Fin2 refa45_inst.
Proof. unfold Equation2852. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa45_inst, refa45_op in H. discriminate H. Qed.

Lemma refa45_not2866 : ~ @Equation2866 Fin2 refa45_inst.
Proof. unfold Equation2866. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa45_inst, refa45_op in H. discriminate H. Qed.

Lemma refa45_not2873 : ~ @Equation2873 Fin2 refa45_inst.
Proof. unfold Equation2873. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa45_inst, refa45_op in H. discriminate H. Qed.

Lemma refa45_not2875 : ~ @Equation2875 Fin2 refa45_inst.
Proof. unfold Equation2875. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa45_inst, refa45_op in H. discriminate H. Qed.

Lemma refa45_not2903 : ~ @Equation2903 Fin2 refa45_inst.
Proof. unfold Equation2903. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa45_inst, refa45_op in H. discriminate H. Qed.

Lemma refa45_not2910 : ~ @Equation2910 Fin2 refa45_inst.
Proof. unfold Equation2910. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa45_inst, refa45_op in H. discriminate H. Qed.

Lemma refa45_not2912 : ~ @Equation2912 Fin2 refa45_inst.
Proof. unfold Equation2912. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa45_inst, refa45_op in H. discriminate H. Qed.

Lemma refa45_not2937 : ~ @Equation2937 Fin2 refa45_inst.
Proof. unfold Equation2937. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa45_inst, refa45_op in H. discriminate H. Qed.

Lemma refa45_not2939 : ~ @Equation2939 Fin2 refa45_inst.
Proof. unfold Equation2939. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa45_inst, refa45_op in H. discriminate H. Qed.

Lemma refa45_not2946 : ~ @Equation2946 Fin2 refa45_inst.
Proof. unfold Equation2946. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa45_inst, refa45_op in H. discriminate H. Qed.

Lemma refa45_not3052 : ~ @Equation3052 Fin2 refa45_inst.
Proof. unfold Equation3052. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa45_inst, refa45_op in H. discriminate H. Qed.

Lemma refa45_not3055 : ~ @Equation3055 Fin2 refa45_inst.
Proof. unfold Equation3055. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa45_inst, refa45_op in H. discriminate H. Qed.

Lemma refa45_not3065 : ~ @Equation3065 Fin2 refa45_inst.
Proof. unfold Equation3065. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa45_inst, refa45_op in H. discriminate H. Qed.

Lemma refa45_not3069 : ~ @Equation3069 Fin2 refa45_inst.
Proof. unfold Equation3069. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa45_inst, refa45_op in H. discriminate H. Qed.

Lemma refa45_not3076 : ~ @Equation3076 Fin2 refa45_inst.
Proof. unfold Equation3076. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa45_inst, refa45_op in H. discriminate H. Qed.

Lemma refa45_not3106 : ~ @Equation3106 Fin2 refa45_inst.
Proof. unfold Equation3106. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa45_inst, refa45_op in H. discriminate H. Qed.

Lemma refa45_not3113 : ~ @Equation3113 Fin2 refa45_inst.
Proof. unfold Equation3113. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa45_inst, refa45_op in H. discriminate H. Qed.

Lemma refa45_not3115 : ~ @Equation3115 Fin2 refa45_inst.
Proof. unfold Equation3115. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa45_inst, refa45_op in H. discriminate H. Qed.

Lemma refa45_not3140 : ~ @Equation3140 Fin2 refa45_inst.
Proof. unfold Equation3140. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa45_inst, refa45_op in H. discriminate H. Qed.

Lemma refa45_not3142 : ~ @Equation3142 Fin2 refa45_inst.
Proof. unfold Equation3142. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa45_inst, refa45_op in H. discriminate H. Qed.

Lemma refa45_not3149 : ~ @Equation3149 Fin2 refa45_inst.
Proof. unfold Equation3149. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa45_inst, refa45_op in H. discriminate H. Qed.

Lemma refa45_not3255 : ~ @Equation3255 Fin2 refa45_inst.
Proof. unfold Equation3255. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa45_inst, refa45_op in H. discriminate H. Qed.

Lemma refa45_not3258 : ~ @Equation3258 Fin2 refa45_inst.
Proof. unfold Equation3258. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa45_inst, refa45_op in H. discriminate H. Qed.

Lemma refa45_not3262 : ~ @Equation3262 Fin2 refa45_inst.
Proof. unfold Equation3262. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa45_inst, refa45_op in H. discriminate H. Qed.

Lemma refa45_not3268 : ~ @Equation3268 Fin2 refa45_inst.
Proof. unfold Equation3268. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa45_inst, refa45_op in H. discriminate H. Qed.

Lemma refa45_not3272 : ~ @Equation3272 Fin2 refa45_inst.
Proof. unfold Equation3272. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa45_inst, refa45_op in H. discriminate H. Qed.

Lemma refa45_not3279 : ~ @Equation3279 Fin2 refa45_inst.
Proof. unfold Equation3279. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa45_inst, refa45_op in H. discriminate H. Qed.

Lemma refa45_not3281 : ~ @Equation3281 Fin2 refa45_inst.
Proof. unfold Equation3281. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa45_inst, refa45_op in H. discriminate H. Qed.

Lemma refa45_not3309 : ~ @Equation3309 Fin2 refa45_inst.
Proof. unfold Equation3309. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa45_inst, refa45_op in H. discriminate H. Qed.

Lemma refa45_not3316 : ~ @Equation3316 Fin2 refa45_inst.
Proof. unfold Equation3316. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa45_inst, refa45_op in H. discriminate H. Qed.

Lemma refa45_not3318 : ~ @Equation3318 Fin2 refa45_inst.
Proof. unfold Equation3318. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa45_inst, refa45_op in H. discriminate H. Qed.

Lemma refa45_not3343 : ~ @Equation3343 Fin2 refa45_inst.
Proof. unfold Equation3343. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa45_inst, refa45_op in H. discriminate H. Qed.

Lemma refa45_not3345 : ~ @Equation3345 Fin2 refa45_inst.
Proof. unfold Equation3345. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa45_inst, refa45_op in H. discriminate H. Qed.

Lemma refa45_not3352 : ~ @Equation3352 Fin2 refa45_inst.
Proof. unfold Equation3352. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa45_inst, refa45_op in H. discriminate H. Qed.

Lemma refa45_not3457 : ~ @Equation3457 Fin2 refa45_inst.
Proof. unfold Equation3457. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa45_inst, refa45_op in H. discriminate H. Qed.

Lemma refa45_not3458 : ~ @Equation3458 Fin2 refa45_inst.
Proof. unfold Equation3458. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa45_inst, refa45_op in H. discriminate H. Qed.

Lemma refa45_not3461 : ~ @Equation3461 Fin2 refa45_inst.
Proof. unfold Equation3461. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa45_inst, refa45_op in H. discriminate H. Qed.

Lemma refa45_not3465 : ~ @Equation3465 Fin2 refa45_inst.
Proof. unfold Equation3465. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa45_inst, refa45_op in H. discriminate H. Qed.

Lemma refa45_not3475 : ~ @Equation3475 Fin2 refa45_inst.
Proof. unfold Equation3475. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa45_inst, refa45_op in H. discriminate H. Qed.

Lemma refa45_not3482 : ~ @Equation3482 Fin2 refa45_inst.
Proof. unfold Equation3482. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa45_inst, refa45_op in H. discriminate H. Qed.

Lemma refa45_not3484 : ~ @Equation3484 Fin2 refa45_inst.
Proof. unfold Equation3484. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa45_inst, refa45_op in H. discriminate H. Qed.

Lemma refa45_not3512 : ~ @Equation3512 Fin2 refa45_inst.
Proof. unfold Equation3512. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa45_inst, refa45_op in H. discriminate H. Qed.

Lemma refa45_not3519 : ~ @Equation3519 Fin2 refa45_inst.
Proof. unfold Equation3519. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa45_inst, refa45_op in H. discriminate H. Qed.

Lemma refa45_not3521 : ~ @Equation3521 Fin2 refa45_inst.
Proof. unfold Equation3521. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa45_inst, refa45_op in H. discriminate H. Qed.

Lemma refa45_not3546 : ~ @Equation3546 Fin2 refa45_inst.
Proof. unfold Equation3546. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa45_inst, refa45_op in H. discriminate H. Qed.

Lemma refa45_not3548 : ~ @Equation3548 Fin2 refa45_inst.
Proof. unfold Equation3548. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa45_inst, refa45_op in H. discriminate H. Qed.

Lemma refa45_not3555 : ~ @Equation3555 Fin2 refa45_inst.
Proof. unfold Equation3555. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa45_inst, refa45_op in H. discriminate H. Qed.

Lemma refa45_not3660 : ~ @Equation3660 Fin2 refa45_inst.
Proof. unfold Equation3660. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa45_inst, refa45_op in H. discriminate H. Qed.

Lemma refa45_not3661 : ~ @Equation3661 Fin2 refa45_inst.
Proof. unfold Equation3661. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa45_inst, refa45_op in H. discriminate H. Qed.

Lemma refa45_not3664 : ~ @Equation3664 Fin2 refa45_inst.
Proof. unfold Equation3664. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa45_inst, refa45_op in H. discriminate H. Qed.

Lemma refa45_not3668 : ~ @Equation3668 Fin2 refa45_inst.
Proof. unfold Equation3668. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa45_inst, refa45_op in H. discriminate H. Qed.

Lemma refa45_not3674 : ~ @Equation3674 Fin2 refa45_inst.
Proof. unfold Equation3674. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa45_inst, refa45_op in H. discriminate H. Qed.

Lemma refa45_not3678 : ~ @Equation3678 Fin2 refa45_inst.
Proof. unfold Equation3678. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa45_inst, refa45_op in H. discriminate H. Qed.

Lemma refa45_not3685 : ~ @Equation3685 Fin2 refa45_inst.
Proof. unfold Equation3685. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa45_inst, refa45_op in H. discriminate H. Qed.

Lemma refa45_not3687 : ~ @Equation3687 Fin2 refa45_inst.
Proof. unfold Equation3687. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa45_inst, refa45_op in H. discriminate H. Qed.

Lemma refa45_not3722 : ~ @Equation3722 Fin2 refa45_inst.
Proof. unfold Equation3722. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa45_inst, refa45_op in H. discriminate H. Qed.

Lemma refa45_not3724 : ~ @Equation3724 Fin2 refa45_inst.
Proof. unfold Equation3724. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa45_inst, refa45_op in H. discriminate H. Qed.

Lemma refa45_not3749 : ~ @Equation3749 Fin2 refa45_inst.
Proof. unfold Equation3749. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa45_inst, refa45_op in H. discriminate H. Qed.

Lemma refa45_not3864 : ~ @Equation3864 Fin2 refa45_inst.
Proof. unfold Equation3864. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa45_inst, refa45_op in H. discriminate H. Qed.

Lemma refa45_not3867 : ~ @Equation3867 Fin2 refa45_inst.
Proof. unfold Equation3867. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa45_inst, refa45_op in H. discriminate H. Qed.

Lemma refa45_not3871 : ~ @Equation3871 Fin2 refa45_inst.
Proof. unfold Equation3871. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa45_inst, refa45_op in H. discriminate H. Qed.

Lemma refa45_not3877 : ~ @Equation3877 Fin2 refa45_inst.
Proof. unfold Equation3877. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa45_inst, refa45_op in H. discriminate H. Qed.

Lemma refa45_not3881 : ~ @Equation3881 Fin2 refa45_inst.
Proof. unfold Equation3881. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa45_inst, refa45_op in H. discriminate H. Qed.

Lemma refa45_not3888 : ~ @Equation3888 Fin2 refa45_inst.
Proof. unfold Equation3888. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa45_inst, refa45_op in H. discriminate H. Qed.

Lemma refa45_not3890 : ~ @Equation3890 Fin2 refa45_inst.
Proof. unfold Equation3890. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa45_inst, refa45_op in H. discriminate H. Qed.

Lemma refa45_not3918 : ~ @Equation3918 Fin2 refa45_inst.
Proof. unfold Equation3918. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa45_inst, refa45_op in H. discriminate H. Qed.

Lemma refa45_not3925 : ~ @Equation3925 Fin2 refa45_inst.
Proof. unfold Equation3925. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa45_inst, refa45_op in H. discriminate H. Qed.

Lemma refa45_not3927 : ~ @Equation3927 Fin2 refa45_inst.
Proof. unfold Equation3927. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa45_inst, refa45_op in H. discriminate H. Qed.

Lemma refa45_not3952 : ~ @Equation3952 Fin2 refa45_inst.
Proof. unfold Equation3952. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa45_inst, refa45_op in H. discriminate H. Qed.

Lemma refa45_not3954 : ~ @Equation3954 Fin2 refa45_inst.
Proof. unfold Equation3954. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa45_inst, refa45_op in H. discriminate H. Qed.

Lemma refa45_not3961 : ~ @Equation3961 Fin2 refa45_inst.
Proof. unfold Equation3961. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa45_inst, refa45_op in H. discriminate H. Qed.

Lemma refa45_not4066 : ~ @Equation4066 Fin2 refa45_inst.
Proof. unfold Equation4066. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa45_inst, refa45_op in H. discriminate H. Qed.

Lemma refa45_not4067 : ~ @Equation4067 Fin2 refa45_inst.
Proof. unfold Equation4067. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa45_inst, refa45_op in H. discriminate H. Qed.

Lemma refa45_not4070 : ~ @Equation4070 Fin2 refa45_inst.
Proof. unfold Equation4070. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa45_inst, refa45_op in H. discriminate H. Qed.

Lemma refa45_not4074 : ~ @Equation4074 Fin2 refa45_inst.
Proof. unfold Equation4074. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa45_inst, refa45_op in H. discriminate H. Qed.

Lemma refa45_not4084 : ~ @Equation4084 Fin2 refa45_inst.
Proof. unfold Equation4084. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa45_inst, refa45_op in H. discriminate H. Qed.

Lemma refa45_not4091 : ~ @Equation4091 Fin2 refa45_inst.
Proof. unfold Equation4091. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa45_inst, refa45_op in H. discriminate H. Qed.

Lemma refa45_not4093 : ~ @Equation4093 Fin2 refa45_inst.
Proof. unfold Equation4093. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa45_inst, refa45_op in H. discriminate H. Qed.

Lemma refa45_not4121 : ~ @Equation4121 Fin2 refa45_inst.
Proof. unfold Equation4121. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa45_inst, refa45_op in H. discriminate H. Qed.

Lemma refa45_not4128 : ~ @Equation4128 Fin2 refa45_inst.
Proof. unfold Equation4128. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa45_inst, refa45_op in H. discriminate H. Qed.

Lemma refa45_not4130 : ~ @Equation4130 Fin2 refa45_inst.
Proof. unfold Equation4130. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa45_inst, refa45_op in H. discriminate H. Qed.

Lemma refa45_not4155 : ~ @Equation4155 Fin2 refa45_inst.
Proof. unfold Equation4155. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa45_inst, refa45_op in H. discriminate H. Qed.

Lemma refa45_not4157 : ~ @Equation4157 Fin2 refa45_inst.
Proof. unfold Equation4157. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa45_inst, refa45_op in H. discriminate H. Qed.

Lemma refa45_not4164 : ~ @Equation4164 Fin2 refa45_inst.
Proof. unfold Equation4164. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa45_inst, refa45_op in H. discriminate H. Qed.

Lemma refa45_not4268 : ~ @Equation4268 Fin2 refa45_inst.
Proof. unfold Equation4268. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa45_inst, refa45_op in H. discriminate H. Qed.

Lemma refa45_not4269 : ~ @Equation4269 Fin2 refa45_inst.
Proof. unfold Equation4269. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa45_inst, refa45_op in H. discriminate H. Qed.

Lemma refa45_not4272 : ~ @Equation4272 Fin2 refa45_inst.
Proof. unfold Equation4272. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa45_inst, refa45_op in H. discriminate H. Qed.

Lemma refa45_not4276 : ~ @Equation4276 Fin2 refa45_inst.
Proof. unfold Equation4276. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa45_inst, refa45_op in H. discriminate H. Qed.

Lemma refa45_not4284 : ~ @Equation4284 Fin2 refa45_inst.
Proof. unfold Equation4284. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa45_inst, refa45_op in H. discriminate H. Qed.

Lemma refa45_not4291 : ~ @Equation4291 Fin2 refa45_inst.
Proof. unfold Equation4291. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa45_inst, refa45_op in H. discriminate H. Qed.

Lemma refa45_not4293 : ~ @Equation4293 Fin2 refa45_inst.
Proof. unfold Equation4293. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa45_inst, refa45_op in H. discriminate H. Qed.

Lemma refa45_not4314 : ~ @Equation4314 Fin2 refa45_inst.
Proof. unfold Equation4314. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa45_inst, refa45_op in H. discriminate H. Qed.

Lemma refa45_not4321 : ~ @Equation4321 Fin2 refa45_inst.
Proof. unfold Equation4321. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa45_inst, refa45_op in H. discriminate H. Qed.

Lemma refa45_not4343 : ~ @Equation4343 Fin2 refa45_inst.
Proof. unfold Equation4343. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa45_inst, refa45_op in H. discriminate H. Qed.

Lemma refa45_not4399 : ~ @Equation4399 Fin2 refa45_inst.
Proof. unfold Equation4399. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa45_inst, refa45_op in H. discriminate H. Qed.

Lemma refa45_not4406 : ~ @Equation4406 Fin2 refa45_inst.
Proof. unfold Equation4406. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa45_inst, refa45_op in H. discriminate H. Qed.

Lemma refa45_not4408 : ~ @Equation4408 Fin2 refa45_inst.
Proof. unfold Equation4408. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa45_inst, refa45_op in H. discriminate H. Qed.

Lemma refa45_not4436 : ~ @Equation4436 Fin2 refa45_inst.
Proof. unfold Equation4436. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa45_inst, refa45_op in H. discriminate H. Qed.

Lemma refa45_not4443 : ~ @Equation4443 Fin2 refa45_inst.
Proof. unfold Equation4443. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa45_inst, refa45_op in H. discriminate H. Qed.

Lemma refa45_not4445 : ~ @Equation4445 Fin2 refa45_inst.
Proof. unfold Equation4445. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa45_inst, refa45_op in H. discriminate H. Qed.

Lemma refa45_not4470 : ~ @Equation4470 Fin2 refa45_inst.
Proof. unfold Equation4470. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa45_inst, refa45_op in H. discriminate H. Qed.

Lemma refa45_not4472 : ~ @Equation4472 Fin2 refa45_inst.
Proof. unfold Equation4472. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa45_inst, refa45_op in H. discriminate H. Qed.

Lemma refa45_not4479 : ~ @Equation4479 Fin2 refa45_inst.
Proof. unfold Equation4479. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa45_inst, refa45_op in H. discriminate H. Qed.

Lemma refa45_not4583 : ~ @Equation4583 Fin2 refa45_inst.
Proof. unfold Equation4583. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa45_inst, refa45_op in H. discriminate H. Qed.

Lemma refa45_not4584 : ~ @Equation4584 Fin2 refa45_inst.
Proof. unfold Equation4584. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa45_inst, refa45_op in H. discriminate H. Qed.

Lemma refa45_not4587 : ~ @Equation4587 Fin2 refa45_inst.
Proof. unfold Equation4587. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa45_inst, refa45_op in H. discriminate H. Qed.

Lemma refa45_not4591 : ~ @Equation4591 Fin2 refa45_inst.
Proof. unfold Equation4591. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa45_inst, refa45_op in H. discriminate H. Qed.

Lemma refa45_not4599 : ~ @Equation4599 Fin2 refa45_inst.
Proof. unfold Equation4599. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa45_inst, refa45_op in H. discriminate H. Qed.

Lemma refa45_not4606 : ~ @Equation4606 Fin2 refa45_inst.
Proof. unfold Equation4606. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa45_inst, refa45_op in H. discriminate H. Qed.

Lemma refa45_not4608 : ~ @Equation4608 Fin2 refa45_inst.
Proof. unfold Equation4608. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa45_inst, refa45_op in H. discriminate H. Qed.

Lemma refa45_not4629 : ~ @Equation4629 Fin2 refa45_inst.
Proof. unfold Equation4629. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa45_inst, refa45_op in H. discriminate H. Qed.

Lemma refa45_not4636 : ~ @Equation4636 Fin2 refa45_inst.
Proof. unfold Equation4636. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa45_inst, refa45_op in H. discriminate H. Qed.

Lemma refa45_not4658 : ~ @Equation4658 Fin2 refa45_inst.
Proof. unfold Equation4658. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa45_inst, refa45_op in H. discriminate H. Qed.

(** ---- refa450 (Fin4) ---- *)

Definition refa450_op (x y : Fin4) : Fin4 :=
  match x, y with
  | F4_0, F4_0 => F4_2 | F4_0, F4_1 => F4_1 | F4_0, F4_2 => F4_0 | F4_0, F4_3 => F4_3
  | F4_1, F4_0 => F4_2 | F4_1, F4_1 => F4_1 | F4_1, F4_2 => F4_3 | F4_1, F4_3 => F4_0
  | F4_2, F4_0 => F4_2 | F4_2, F4_1 => F4_1 | F4_2, F4_2 => F4_0 | F4_2, F4_3 => F4_3
  | F4_3, F4_0 => F4_2 | F4_3, F4_1 => F4_0 | F4_3, F4_2 => F4_1 | F4_3, F4_3 => F4_3
  end.

#[local] Instance refa450_inst : Magma Fin4 := {| magma_op := refa450_op |}.

Lemma refa450_sat473 : @Equation473 Fin4 refa450_inst.
Proof. unfold Equation473, magma_op, refa450_inst, refa450_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa450_sat3271 : @Equation3271 Fin4 refa450_inst.
Proof. unfold Equation3271, magma_op, refa450_inst, refa450_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa450_not513 : ~ @Equation513 Fin4 refa450_inst.
Proof. unfold Equation513. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa450_inst, refa450_op in H. discriminate H. Qed.

Lemma refa450_not1278 : ~ @Equation1278 Fin4 refa450_inst.
Proof. unfold Equation1278. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa450_inst, refa450_op in H. discriminate H. Qed.

Lemma refa450_not1325 : ~ @Equation1325 Fin4 refa450_inst.
Proof. unfold Equation1325. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa450_inst, refa450_op in H. discriminate H. Qed.

Lemma refa450_not2043 : ~ @Equation2043 Fin4 refa450_inst.
Proof. unfold Equation2043. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa450_inst, refa450_op in H. discriminate H. Qed.

Lemma refa450_not3278 : ~ @Equation3278 Fin4 refa450_inst.
Proof. unfold Equation3278. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa450_inst, refa450_op in H. discriminate H. Qed.

Lemma refa450_not3306 : ~ @Equation3306 Fin4 refa450_inst.
Proof. unfold Equation3306. intro H. specialize (H F4_1 F4_0). unfold magma_op, refa450_inst, refa450_op in H. discriminate H. Qed.

Lemma refa450_not3456 : ~ @Equation3456 Fin4 refa450_inst.
Proof. unfold Equation3456. intro H. specialize (H F4_0). unfold magma_op, refa450_inst, refa450_op in H. discriminate H. Qed.

Lemma refa450_not3659 : ~ @Equation3659 Fin4 refa450_inst.
Proof. unfold Equation3659. intro H. specialize (H F4_0). unfold magma_op, refa450_inst, refa450_op in H. discriminate H. Qed.

Lemma refa450_not3962 : ~ @Equation3962 Fin4 refa450_inst.
Proof. unfold Equation3962. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa450_inst, refa450_op in H. discriminate H. Qed.

Lemma refa450_not4275 : ~ @Equation4275 Fin4 refa450_inst.
Proof. unfold Equation4275. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa450_inst, refa450_op in H. discriminate H. Qed.

Lemma refa450_not4320 : ~ @Equation4320 Fin4 refa450_inst.
Proof. unfold Equation4320. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa450_inst, refa450_op in H. discriminate H. Qed.

(** ---- refa451 (Fin4) ---- *)

Definition refa451_op (x y : Fin4) : Fin4 :=
  match x, y with
  | F4_0, F4_0 => F4_2 | F4_0, F4_1 => F4_2 | F4_0, F4_2 => F4_1 | F4_0, F4_3 => F4_3
  | F4_1, F4_0 => F4_3 | F4_1, F4_1 => F4_3 | F4_1, F4_2 => F4_3 | F4_1, F4_3 => F4_3
  | F4_2, F4_0 => F4_1 | F4_2, F4_1 => F4_1 | F4_2, F4_2 => F4_0 | F4_2, F4_3 => F4_3
  | F4_3, F4_0 => F4_0 | F4_3, F4_1 => F4_1 | F4_3, F4_2 => F4_2 | F4_3, F4_3 => F4_0
  end.

#[local] Instance refa451_inst : Magma Fin4 := {| magma_op := refa451_op |}.

Lemma refa451_sat3052 : @Equation3052 Fin4 refa451_inst.
Proof. unfold Equation3052, magma_op, refa451_inst, refa451_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa451_not2644 : ~ @Equation2644 Fin4 refa451_inst.
Proof. unfold Equation2644. intro H. specialize (H F4_0). unfold magma_op, refa451_inst, refa451_op in H. discriminate H. Qed.

Lemma refa451_not3058 : ~ @Equation3058 Fin4 refa451_inst.
Proof. unfold Equation3058. intro H. specialize (H F4_0 F4_2). unfold magma_op, refa451_inst, refa451_op in H. discriminate H. Qed.

Lemma refa451_not3065 : ~ @Equation3065 Fin4 refa451_inst.
Proof. unfold Equation3065. intro H. specialize (H F4_0 F4_2). unfold magma_op, refa451_inst, refa451_op in H. discriminate H. Qed.

Lemma refa451_not3068 : ~ @Equation3068 Fin4 refa451_inst.
Proof. unfold Equation3068. intro H. specialize (H F4_0 F4_2). unfold magma_op, refa451_inst, refa451_op in H. discriminate H. Qed.

Lemma refa451_not3253 : ~ @Equation3253 Fin4 refa451_inst.
Proof. unfold Equation3253. intro H. specialize (H F4_2). unfold magma_op, refa451_inst, refa451_op in H. discriminate H. Qed.

Lemma refa451_not3456 : ~ @Equation3456 Fin4 refa451_inst.
Proof. unfold Equation3456. intro H. specialize (H F4_2). unfold magma_op, refa451_inst, refa451_op in H. discriminate H. Qed.

Lemma refa451_not3659 : ~ @Equation3659 Fin4 refa451_inst.
Proof. unfold Equation3659. intro H. specialize (H F4_0). unfold magma_op, refa451_inst, refa451_op in H. discriminate H. Qed.

Lemma refa451_not4269 : ~ @Equation4269 Fin4 refa451_inst.
Proof. unfold Equation4269. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa451_inst, refa451_op in H. discriminate H. Qed.

Lemma refa451_not4270 : ~ @Equation4270 Fin4 refa451_inst.
Proof. unfold Equation4270. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa451_inst, refa451_op in H. discriminate H. Qed.

Lemma refa451_not4314 : ~ @Equation4314 Fin4 refa451_inst.
Proof. unfold Equation4314. intro H. specialize (H F4_2 F4_0). unfold magma_op, refa451_inst, refa451_op in H. discriminate H. Qed.

Lemma refa451_not4631 : ~ @Equation4631 Fin4 refa451_inst.
Proof. unfold Equation4631. intro H. specialize (H F4_0 F4_0 F4_2). unfold magma_op, refa451_inst, refa451_op in H. discriminate H. Qed.

(** ---- refa452 (Fin4) ---- *)

Definition refa452_op (x y : Fin4) : Fin4 :=
  match x, y with
  | F4_0, F4_0 => F4_0 | F4_0, F4_1 => F4_1 | F4_0, F4_2 => F4_3 | F4_0, F4_3 => F4_3
  | F4_1, F4_0 => F4_2 | F4_1, F4_1 => F4_3 | F4_1, F4_2 => F4_3 | F4_1, F4_3 => F4_0
  | F4_2, F4_0 => F4_3 | F4_2, F4_1 => F4_1 | F4_2, F4_2 => F4_0 | F4_2, F4_3 => F4_3
  | F4_3, F4_0 => F4_0 | F4_3, F4_1 => F4_3 | F4_3, F4_2 => F4_2 | F4_3, F4_3 => F4_0
  end.

#[local] Instance refa452_inst : Magma Fin4 := {| magma_op := refa452_op |}.

Lemma refa452_sat2277 : @Equation2277 Fin4 refa452_inst.
Proof. unfold Equation2277, magma_op, refa452_inst, refa452_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa452_not2246 : ~ @Equation2246 Fin4 refa452_inst.
Proof. unfold Equation2246. intro H. specialize (H F4_1 F4_0). unfold magma_op, refa452_inst, refa452_op in H. discriminate H. Qed.

Lemma refa452_not2253 : ~ @Equation2253 Fin4 refa452_inst.
Proof. unfold Equation2253. intro H. specialize (H F4_2 F4_1). unfold magma_op, refa452_inst, refa452_op in H. discriminate H. Qed.

Lemma refa452_not3659 : ~ @Equation3659 Fin4 refa452_inst.
Proof. unfold Equation3659. intro H. specialize (H F4_1). unfold magma_op, refa452_inst, refa452_op in H. discriminate H. Qed.

(** ---- refa453 (Fin4) ---- *)

Definition refa453_op (x y : Fin4) : Fin4 :=
  match x, y with
  | F4_0, F4_0 => F4_0 | F4_0, F4_1 => F4_1 | F4_0, F4_2 => F4_1 | F4_0, F4_3 => F4_1
  | F4_1, F4_0 => F4_2 | F4_1, F4_1 => F4_3 | F4_1, F4_2 => F4_3 | F4_1, F4_3 => F4_3
  | F4_2, F4_0 => F4_3 | F4_2, F4_1 => F4_0 | F4_2, F4_2 => F4_0 | F4_2, F4_3 => F4_0
  | F4_3, F4_0 => F4_1 | F4_3, F4_1 => F4_2 | F4_3, F4_2 => F4_2 | F4_3, F4_3 => F4_2
  end.

#[local] Instance refa453_inst : Magma Fin4 := {| magma_op := refa453_op |}.

Lemma refa453_sat3056 : @Equation3056 Fin4 refa453_inst.
Proof. unfold Equation3056, magma_op, refa453_inst, refa453_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa453_not3079 : ~ @Equation3079 Fin4 refa453_inst.
Proof. unfold Equation3079. intro H. specialize (H F4_1 F4_0). unfold magma_op, refa453_inst, refa453_op in H. discriminate H. Qed.

(** ---- refa454 (Fin4) ---- *)

Definition refa454_op (x y : Fin4) : Fin4 :=
  match x, y with
  | F4_0, F4_0 => F4_3 | F4_0, F4_1 => F4_3 | F4_0, F4_2 => F4_2 | F4_0, F4_3 => F4_1
  | F4_1, F4_0 => F4_3 | F4_1, F4_1 => F4_3 | F4_1, F4_2 => F4_2 | F4_1, F4_3 => F4_0
  | F4_2, F4_0 => F4_0 | F4_2, F4_1 => F4_1 | F4_2, F4_2 => F4_3 | F4_2, F4_3 => F4_2
  | F4_3, F4_0 => F4_2 | F4_3, F4_1 => F4_2 | F4_3, F4_2 => F4_0 | F4_3, F4_3 => F4_3
  end.

#[local] Instance refa454_inst : Magma Fin4 := {| magma_op := refa454_op |}.

Lemma refa454_sat273 : @Equation273 Fin4 refa454_inst.
Proof. unfold Equation273, magma_op, refa454_inst, refa454_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa454_sat280 : @Equation280 Fin4 refa454_inst.
Proof. unfold Equation280, magma_op, refa454_inst, refa454_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa454_not1020 : ~ @Equation1020 Fin4 refa454_inst.
Proof. unfold Equation1020. intro H. specialize (H F4_0). unfold magma_op, refa454_inst, refa454_op in H. discriminate H. Qed.

Lemma refa454_not1629 : ~ @Equation1629 Fin4 refa454_inst.
Proof. unfold Equation1629. intro H. specialize (H F4_1). unfold magma_op, refa454_inst, refa454_op in H. discriminate H. Qed.

Lemma refa454_not1840 : ~ @Equation1840 Fin4 refa454_inst.
Proof. unfold Equation1840. intro H. specialize (H F4_1 F4_3). unfold magma_op, refa454_inst, refa454_op in H. discriminate H. Qed.

Lemma refa454_not1921 : ~ @Equation1921 Fin4 refa454_inst.
Proof. unfold Equation1921. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa454_inst, refa454_op in H. discriminate H. Qed.

Lemma refa454_not3319 : ~ @Equation3319 Fin4 refa454_inst.
Proof. unfold Equation3319. intro H. specialize (H F4_2 F4_0). unfold magma_op, refa454_inst, refa454_op in H. discriminate H. Qed.

Lemma refa454_not3353 : ~ @Equation3353 Fin4 refa454_inst.
Proof. unfold Equation3353. intro H. specialize (H F4_0 F4_3). unfold magma_op, refa454_inst, refa454_op in H. discriminate H. Qed.

Lemma refa454_not3915 : ~ @Equation3915 Fin4 refa454_inst.
Proof. unfold Equation3915. intro H. specialize (H F4_0 F4_3). unfold magma_op, refa454_inst, refa454_op in H. discriminate H. Qed.

Lemma refa454_not3962 : ~ @Equation3962 Fin4 refa454_inst.
Proof. unfold Equation3962. intro H. specialize (H F4_1 F4_3). unfold magma_op, refa454_inst, refa454_op in H. discriminate H. Qed.

Lemma refa454_not4275 : ~ @Equation4275 Fin4 refa454_inst.
Proof. unfold Equation4275. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa454_inst, refa454_op in H. discriminate H. Qed.

(** ---- refa455 (Fin4) ---- *)

Definition refa455_op (x y : Fin4) : Fin4 :=
  match x, y with
  | F4_0, F4_0 => F4_1 | F4_0, F4_1 => F4_2 | F4_0, F4_2 => F4_1 | F4_0, F4_3 => F4_3
  | F4_1, F4_0 => F4_3 | F4_1, F4_1 => F4_2 | F4_1, F4_2 => F4_1 | F4_1, F4_3 => F4_3
  | F4_2, F4_0 => F4_1 | F4_2, F4_1 => F4_2 | F4_2, F4_2 => F4_1 | F4_2, F4_3 => F4_3
  | F4_3, F4_0 => F4_1 | F4_3, F4_1 => F4_2 | F4_3, F4_2 => F4_1 | F4_3, F4_3 => F4_3
  end.

#[local] Instance refa455_inst : Magma Fin4 := {| magma_op := refa455_op |}.

Lemma refa455_sat4040 : @Equation4040 Fin4 refa455_inst.
Proof. unfold Equation4040, magma_op, refa455_inst, refa455_op. intros x y z w. destruct x, y, z, w; reflexivity. Qed.

Lemma refa455_not4587 : ~ @Equation4587 Fin4 refa455_inst.
Proof. unfold Equation4587. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa455_inst, refa455_op in H. discriminate H. Qed.

(** ---- refa456 (Fin4) ---- *)

Definition refa456_op (x y : Fin4) : Fin4 :=
  match x, y with
  | F4_0, F4_0 => F4_3 | F4_0, F4_1 => F4_3 | F4_0, F4_2 => F4_3 | F4_0, F4_3 => F4_1
  | F4_1, F4_0 => F4_3 | F4_1, F4_1 => F4_3 | F4_1, F4_2 => F4_3 | F4_1, F4_3 => F4_3
  | F4_2, F4_0 => F4_0 | F4_2, F4_1 => F4_0 | F4_2, F4_2 => F4_0 | F4_2, F4_3 => F4_0
  | F4_3, F4_0 => F4_2 | F4_3, F4_1 => F4_0 | F4_3, F4_2 => F4_2 | F4_3, F4_3 => F4_0
  end.

#[local] Instance refa456_inst : Magma Fin4 := {| magma_op := refa456_op |}.

Lemma refa456_sat2052 : @Equation2052 Fin4 refa456_inst.
Proof. unfold Equation2052, magma_op, refa456_inst, refa456_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa456_not3461 : ~ @Equation3461 Fin4 refa456_inst.
Proof. unfold Equation3461. intro H. specialize (H F4_0 F4_2). unfold magma_op, refa456_inst, refa456_op in H. discriminate H. Qed.

Lemma refa456_not3462 : ~ @Equation3462 Fin4 refa456_inst.
Proof. unfold Equation3462. intro H. specialize (H F4_0 F4_2). unfold magma_op, refa456_inst, refa456_op in H. discriminate H. Qed.

Lemma refa456_not4268 : ~ @Equation4268 Fin4 refa456_inst.
Proof. unfold Equation4268. intro H. specialize (H F4_0 F4_3). unfold magma_op, refa456_inst, refa456_op in H. discriminate H. Qed.

(** ---- refa457 (Fin4) ---- *)

Definition refa457_op (x y : Fin4) : Fin4 :=
  match x, y with
  | F4_0, F4_0 => F4_3 | F4_0, F4_1 => F4_2 | F4_0, F4_2 => F4_3 | F4_0, F4_3 => F4_3
  | F4_1, F4_0 => F4_3 | F4_1, F4_1 => F4_3 | F4_1, F4_2 => F4_3 | F4_1, F4_3 => F4_3
  | F4_2, F4_0 => F4_2 | F4_2, F4_1 => F4_3 | F4_2, F4_2 => F4_3 | F4_2, F4_3 => F4_3
  | F4_3, F4_0 => F4_1 | F4_3, F4_1 => F4_2 | F4_3, F4_2 => F4_3 | F4_3, F4_3 => F4_3
  end.

#[local] Instance refa457_inst : Magma Fin4 := {| magma_op := refa457_op |}.

Lemma refa457_sat3304 : @Equation3304 Fin4 refa457_inst.
Proof. unfold Equation3304, magma_op, refa457_inst, refa457_op. intros x y z w u. destruct x, y, z, w, u; reflexivity. Qed.

Lemma refa457_not323 : ~ @Equation323 Fin4 refa457_inst.
Proof. unfold Equation323. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa457_inst, refa457_op in H. discriminate H. Qed.

Lemma refa457_not359 : ~ @Equation359 Fin4 refa457_inst.
Proof. unfold Equation359. intro H. specialize (H F4_0). unfold magma_op, refa457_inst, refa457_op in H. discriminate H. Qed.

Lemma refa457_not3456 : ~ @Equation3456 Fin4 refa457_inst.
Proof. unfold Equation3456. intro H. specialize (H F4_0). unfold magma_op, refa457_inst, refa457_op in H. discriminate H. Qed.

Lemma refa457_not3660 : ~ @Equation3660 Fin4 refa457_inst.
Proof. unfold Equation3660. intro H. specialize (H F4_3 F4_0). unfold magma_op, refa457_inst, refa457_op in H. discriminate H. Qed.

Lemma refa457_not3661 : ~ @Equation3661 Fin4 refa457_inst.
Proof. unfold Equation3661. intro H. specialize (H F4_0 F4_3). unfold magma_op, refa457_inst, refa457_op in H. discriminate H. Qed.

Lemma refa457_not3667 : ~ @Equation3667 Fin4 refa457_inst.
Proof. unfold Equation3667. intro H. specialize (H F4_0 F4_3). unfold magma_op, refa457_inst, refa457_op in H. discriminate H. Qed.

Lemma refa457_not3675 : ~ @Equation3675 Fin4 refa457_inst.
Proof. unfold Equation3675. intro H. specialize (H F4_3 F4_0). unfold magma_op, refa457_inst, refa457_op in H. discriminate H. Qed.

Lemma refa457_not3685 : ~ @Equation3685 Fin4 refa457_inst.
Proof. unfold Equation3685. intro H. specialize (H F4_3 F4_0). unfold magma_op, refa457_inst, refa457_op in H. discriminate H. Qed.

Lemma refa457_not3687 : ~ @Equation3687 Fin4 refa457_inst.
Proof. unfold Equation3687. intro H. specialize (H F4_0 F4_3). unfold magma_op, refa457_inst, refa457_op in H. discriminate H. Qed.

Lemma refa457_not3862 : ~ @Equation3862 Fin4 refa457_inst.
Proof. unfold Equation3862. intro H. specialize (H F4_0). unfold magma_op, refa457_inst, refa457_op in H. discriminate H. Qed.

Lemma refa457_not4066 : ~ @Equation4066 Fin4 refa457_inst.
Proof. unfold Equation4066. intro H. specialize (H F4_1 F4_0). unfold magma_op, refa457_inst, refa457_op in H. discriminate H. Qed.

Lemma refa457_not4067 : ~ @Equation4067 Fin4 refa457_inst.
Proof. unfold Equation4067. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa457_inst, refa457_op in H. discriminate H. Qed.

Lemma refa457_not4070 : ~ @Equation4070 Fin4 refa457_inst.
Proof. unfold Equation4070. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa457_inst, refa457_op in H. discriminate H. Qed.

Lemma refa457_not4071 : ~ @Equation4071 Fin4 refa457_inst.
Proof. unfold Equation4071. intro H. specialize (H F4_1 F4_0). unfold magma_op, refa457_inst, refa457_op in H. discriminate H. Qed.

Lemma refa457_not4073 : ~ @Equation4073 Fin4 refa457_inst.
Proof. unfold Equation4073. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa457_inst, refa457_op in H. discriminate H. Qed.

Lemma refa457_not4081 : ~ @Equation4081 Fin4 refa457_inst.
Proof. unfold Equation4081. intro H. specialize (H F4_1 F4_0). unfold magma_op, refa457_inst, refa457_op in H. discriminate H. Qed.

Lemma refa457_not4083 : ~ @Equation4083 Fin4 refa457_inst.
Proof. unfold Equation4083. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa457_inst, refa457_op in H. discriminate H. Qed.

Lemma refa457_not4084 : ~ @Equation4084 Fin4 refa457_inst.
Proof. unfold Equation4084. intro H. specialize (H F4_1 F4_0). unfold magma_op, refa457_inst, refa457_op in H. discriminate H. Qed.

Lemma refa457_not4091 : ~ @Equation4091 Fin4 refa457_inst.
Proof. unfold Equation4091. intro H. specialize (H F4_1 F4_0). unfold magma_op, refa457_inst, refa457_op in H. discriminate H. Qed.

Lemma refa457_not4093 : ~ @Equation4093 Fin4 refa457_inst.
Proof. unfold Equation4093. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa457_inst, refa457_op in H. discriminate H. Qed.

Lemma refa457_not4268 : ~ @Equation4268 Fin4 refa457_inst.
Proof. unfold Equation4268. intro H. specialize (H F4_3 F4_0). unfold magma_op, refa457_inst, refa457_op in H. discriminate H. Qed.

Lemma refa457_not4269 : ~ @Equation4269 Fin4 refa457_inst.
Proof. unfold Equation4269. intro H. specialize (H F4_0 F4_3). unfold magma_op, refa457_inst, refa457_op in H. discriminate H. Qed.

Lemma refa457_not4273 : ~ @Equation4273 Fin4 refa457_inst.
Proof. unfold Equation4273. intro H. specialize (H F4_3 F4_0). unfold magma_op, refa457_inst, refa457_op in H. discriminate H. Qed.

Lemma refa457_not4275 : ~ @Equation4275 Fin4 refa457_inst.
Proof. unfold Equation4275. intro H. specialize (H F4_0 F4_3). unfold magma_op, refa457_inst, refa457_op in H. discriminate H. Qed.

Lemma refa457_not4283 : ~ @Equation4283 Fin4 refa457_inst.
Proof. unfold Equation4283. intro H. specialize (H F4_0 F4_3). unfold magma_op, refa457_inst, refa457_op in H. discriminate H. Qed.

Lemma refa457_not4284 : ~ @Equation4284 Fin4 refa457_inst.
Proof. unfold Equation4284. intro H. specialize (H F4_3 F4_0). unfold magma_op, refa457_inst, refa457_op in H. discriminate H. Qed.

Lemma refa457_not4290 : ~ @Equation4290 Fin4 refa457_inst.
Proof. unfold Equation4290. intro H. specialize (H F4_3 F4_0). unfold magma_op, refa457_inst, refa457_op in H. discriminate H. Qed.

Lemma refa457_not4293 : ~ @Equation4293 Fin4 refa457_inst.
Proof. unfold Equation4293. intro H. specialize (H F4_0 F4_3). unfold magma_op, refa457_inst, refa457_op in H. discriminate H. Qed.

Lemma refa457_not4300 : ~ @Equation4300 Fin4 refa457_inst.
Proof. unfold Equation4300. intro H. specialize (H F4_3 F4_0 F4_1). unfold magma_op, refa457_inst, refa457_op in H. discriminate H. Qed.

Lemma refa457_not4314 : ~ @Equation4314 Fin4 refa457_inst.
Proof. unfold Equation4314. intro H. specialize (H F4_0 F4_3). unfold magma_op, refa457_inst, refa457_op in H. discriminate H. Qed.

Lemma refa457_not4320 : ~ @Equation4320 Fin4 refa457_inst.
Proof. unfold Equation4320. intro H. specialize (H F4_0 F4_3). unfold magma_op, refa457_inst, refa457_op in H. discriminate H. Qed.

Lemma refa457_not4321 : ~ @Equation4321 Fin4 refa457_inst.
Proof. unfold Equation4321. intro H. specialize (H F4_0 F4_3). unfold magma_op, refa457_inst, refa457_op in H. discriminate H. Qed.

Lemma refa457_not4380 : ~ @Equation4380 Fin4 refa457_inst.
Proof. unfold Equation4380. intro H. specialize (H F4_0). unfold magma_op, refa457_inst, refa457_op in H. discriminate H. Qed.

Lemma refa457_not4583 : ~ @Equation4583 Fin4 refa457_inst.
Proof. unfold Equation4583. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa457_inst, refa457_op in H. discriminate H. Qed.

Lemma refa457_not4584 : ~ @Equation4584 Fin4 refa457_inst.
Proof. unfold Equation4584. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa457_inst, refa457_op in H. discriminate H. Qed.

Lemma refa457_not4588 : ~ @Equation4588 Fin4 refa457_inst.
Proof. unfold Equation4588. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa457_inst, refa457_op in H. discriminate H. Qed.

Lemma refa457_not4591 : ~ @Equation4591 Fin4 refa457_inst.
Proof. unfold Equation4591. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa457_inst, refa457_op in H. discriminate H. Qed.

Lemma refa457_not4598 : ~ @Equation4598 Fin4 refa457_inst.
Proof. unfold Equation4598. intro H. specialize (H F4_0 F4_2). unfold magma_op, refa457_inst, refa457_op in H. discriminate H. Qed.

Lemma refa457_not4606 : ~ @Equation4606 Fin4 refa457_inst.
Proof. unfold Equation4606. intro H. specialize (H F4_1 F4_0). unfold magma_op, refa457_inst, refa457_op in H. discriminate H. Qed.

Lemma refa457_not4608 : ~ @Equation4608 Fin4 refa457_inst.
Proof. unfold Equation4608. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa457_inst, refa457_op in H. discriminate H. Qed.

Lemma refa457_not4636 : ~ @Equation4636 Fin4 refa457_inst.
Proof. unfold Equation4636. intro H. specialize (H F4_0 F4_2). unfold magma_op, refa457_inst, refa457_op in H. discriminate H. Qed.

(** ---- refa458 (Fin4) ---- *)

Definition refa458_op (x y : Fin4) : Fin4 :=
  match x, y with
  | F4_0, F4_0 => F4_3 | F4_0, F4_1 => F4_0 | F4_0, F4_2 => F4_3 | F4_0, F4_3 => F4_1
  | F4_1, F4_0 => F4_3 | F4_1, F4_1 => F4_2 | F4_1, F4_2 => F4_3 | F4_1, F4_3 => F4_1
  | F4_2, F4_0 => F4_0 | F4_2, F4_1 => F4_2 | F4_2, F4_2 => F4_3 | F4_2, F4_3 => F4_1
  | F4_3, F4_0 => F4_3 | F4_3, F4_1 => F4_2 | F4_3, F4_2 => F4_3 | F4_3, F4_3 => F4_1
  end.

#[local] Instance refa458_inst : Magma Fin4 := {| magma_op := refa458_op |}.

Lemma refa458_sat635 : @Equation635 Fin4 refa458_inst.
Proof. unfold Equation635, magma_op, refa458_inst, refa458_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa458_not55 : ~ @Equation55 Fin4 refa458_inst.
Proof. unfold Equation55. intro H. specialize (H F4_0 F4_2). unfold magma_op, refa458_inst, refa458_op in H. discriminate H. Qed.

Lemma refa458_not835 : ~ @Equation835 Fin4 refa458_inst.
Proof. unfold Equation835. intro H. specialize (H F4_0 F4_2). unfold magma_op, refa458_inst, refa458_op in H. discriminate H. Qed.

Lemma refa458_not4131 : ~ @Equation4131 Fin4 refa458_inst.
Proof. unfold Equation4131. intro H. specialize (H F4_2 F4_0). unfold magma_op, refa458_inst, refa458_op in H. discriminate H. Qed.

(** ---- refa459 (Fin4) ---- *)

Definition refa459_op (x y : Fin4) : Fin4 :=
  match x, y with
  | F4_0, F4_0 => F4_3 | F4_0, F4_1 => F4_2 | F4_0, F4_2 => F4_0 | F4_0, F4_3 => F4_1
  | F4_1, F4_0 => F4_2 | F4_1, F4_1 => F4_3 | F4_1, F4_2 => F4_1 | F4_1, F4_3 => F4_0
  | F4_2, F4_0 => F4_0 | F4_2, F4_1 => F4_1 | F4_2, F4_2 => F4_2 | F4_2, F4_3 => F4_3
  | F4_3, F4_0 => F4_0 | F4_3, F4_1 => F4_1 | F4_3, F4_2 => F4_2 | F4_3, F4_3 => F4_3
  end.

#[local] Instance refa459_inst : Magma Fin4 := {| magma_op := refa459_op |}.

Lemma refa459_sat2808 : @Equation2808 Fin4 refa459_inst.
Proof. unfold Equation2808, magma_op, refa459_inst, refa459_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa459_sat2998 : @Equation2998 Fin4 refa459_inst.
Proof. unfold Equation2998, magma_op, refa459_inst, refa459_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa459_sat3214 : @Equation3214 Fin4 refa459_inst.
Proof. unfold Equation3214, magma_op, refa459_inst, refa459_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa459_not3253 : ~ @Equation3253 Fin4 refa459_inst.
Proof. unfold Equation3253. intro H. specialize (H F4_0). unfold magma_op, refa459_inst, refa459_op in H. discriminate H. Qed.

Lemma refa459_not3862 : ~ @Equation3862 Fin4 refa459_inst.
Proof. unfold Equation3862. intro H. specialize (H F4_0). unfold magma_op, refa459_inst, refa459_op in H. discriminate H. Qed.

Lemma refa459_not4073 : ~ @Equation4073 Fin4 refa459_inst.
Proof. unfold Equation4073. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa459_inst, refa459_op in H. discriminate H. Qed.

Lemma refa459_not4083 : ~ @Equation4083 Fin4 refa459_inst.
Proof. unfold Equation4083. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa459_inst, refa459_op in H. discriminate H. Qed.

Lemma refa459_not4131 : ~ @Equation4131 Fin4 refa459_inst.
Proof. unfold Equation4131. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa459_inst, refa459_op in H. discriminate H. Qed.

Lemma refa459_not4158 : ~ @Equation4158 Fin4 refa459_inst.
Proof. unfold Equation4158. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa459_inst, refa459_op in H. discriminate H. Qed.

Lemma refa459_not4635 : ~ @Equation4635 Fin4 refa459_inst.
Proof. unfold Equation4635. intro H. specialize (H F4_0 F4_3). unfold magma_op, refa459_inst, refa459_op in H. discriminate H. Qed.
