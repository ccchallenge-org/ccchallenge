(** * All4x4 counterexamples — batch 15
    Auto-generated from Lean4 All4x4 files. *)

From Stdlib Require Import Utf8.

From ETP Require Import Magma.
From ETP Require Import FinMagma.
From ETP.Equations Require Import All.

Open Scope magma_scope.

(** ---- refa73 (Fin3) ---- *)

Definition refa73_op (x y : Fin3) : Fin3 :=
  match x, y with
  | F3_0, F3_0 => F3_0 | F3_0, F3_1 => F3_0 | F3_0, F3_2 => F3_0
  | F3_1, F3_0 => F3_0 | F3_1, F3_1 => F3_0 | F3_1, F3_2 => F3_0
  | F3_2, F3_0 => F3_0 | F3_2, F3_1 => F3_2 | F3_2, F3_2 => F3_0
  end.

#[local] Instance refa73_inst : Magma Fin3 := {| magma_op := refa73_op |}.

Lemma refa73_sat314 : @Equation314 Fin3 refa73_inst.
Proof. unfold Equation314, magma_op, refa73_inst, refa73_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa73_sat3886 : @Equation3886 Fin3 refa73_inst.
Proof. unfold Equation3886, magma_op, refa73_inst, refa73_op. intros x y z w. destruct x, y, z, w; reflexivity. Qed.

Lemma refa73_sat4524 : @Equation4524 Fin3 refa73_inst.
Proof. unfold Equation4524, magma_op, refa73_inst, refa73_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa73_sat4530 : @Equation4530 Fin3 refa73_inst.
Proof. unfold Equation4530, magma_op, refa73_inst, refa73_op. intros x y z w. destruct x, y, z, w; reflexivity. Qed.

Lemma refa73_not3306 : ~ @Equation3306 Fin3 refa73_inst.
Proof. unfold Equation3306. intro H. specialize (H F3_2 F3_1). unfold magma_op, refa73_inst, refa73_op in H. discriminate H. Qed.

Lemma refa73_not3308 : ~ @Equation3308 Fin3 refa73_inst.
Proof. unfold Equation3308. intro H. specialize (H F3_2 F3_1). unfold magma_op, refa73_inst, refa73_op in H. discriminate H. Qed.

Lemma refa73_not3309 : ~ @Equation3309 Fin3 refa73_inst.
Proof. unfold Equation3309. intro H. specialize (H F3_2 F3_1). unfold magma_op, refa73_inst, refa73_op in H. discriminate H. Qed.

Lemma refa73_not3315 : ~ @Equation3315 Fin3 refa73_inst.
Proof. unfold Equation3315. intro H. specialize (H F3_2 F3_1). unfold magma_op, refa73_inst, refa73_op in H. discriminate H. Qed.

Lemma refa73_not3316 : ~ @Equation3316 Fin3 refa73_inst.
Proof. unfold Equation3316. intro H. specialize (H F3_2 F3_1). unfold magma_op, refa73_inst, refa73_op in H. discriminate H. Qed.

Lemma refa73_not3318 : ~ @Equation3318 Fin3 refa73_inst.
Proof. unfold Equation3318. intro H. specialize (H F3_2 F3_1). unfold magma_op, refa73_inst, refa73_op in H. discriminate H. Qed.

Lemma refa73_not3319 : ~ @Equation3319 Fin3 refa73_inst.
Proof. unfold Equation3319. intro H. specialize (H F3_2 F3_1). unfold magma_op, refa73_inst, refa73_op in H. discriminate H. Qed.

Lemma refa73_not3342 : ~ @Equation3342 Fin3 refa73_inst.
Proof. unfold Equation3342. intro H. specialize (H F3_2 F3_1). unfold magma_op, refa73_inst, refa73_op in H. discriminate H. Qed.

Lemma refa73_not3343 : ~ @Equation3343 Fin3 refa73_inst.
Proof. unfold Equation3343. intro H. specialize (H F3_2 F3_1). unfold magma_op, refa73_inst, refa73_op in H. discriminate H. Qed.

Lemma refa73_not3345 : ~ @Equation3345 Fin3 refa73_inst.
Proof. unfold Equation3345. intro H. specialize (H F3_2 F3_1). unfold magma_op, refa73_inst, refa73_op in H. discriminate H. Qed.

Lemma refa73_not3346 : ~ @Equation3346 Fin3 refa73_inst.
Proof. unfold Equation3346. intro H. specialize (H F3_2 F3_1). unfold magma_op, refa73_inst, refa73_op in H. discriminate H. Qed.

Lemma refa73_not3352 : ~ @Equation3352 Fin3 refa73_inst.
Proof. unfold Equation3352. intro H. specialize (H F3_2 F3_1). unfold magma_op, refa73_inst, refa73_op in H. discriminate H. Qed.

Lemma refa73_not3353 : ~ @Equation3353 Fin3 refa73_inst.
Proof. unfold Equation3353. intro H. specialize (H F3_2 F3_1). unfold magma_op, refa73_inst, refa73_op in H. discriminate H. Qed.

Lemma refa73_not3355 : ~ @Equation3355 Fin3 refa73_inst.
Proof. unfold Equation3355. intro H. specialize (H F3_2 F3_1). unfold magma_op, refa73_inst, refa73_op in H. discriminate H. Qed.

Lemma refa73_not3509 : ~ @Equation3509 Fin3 refa73_inst.
Proof. unfold Equation3509. intro H. specialize (H F3_2 F3_1). unfold magma_op, refa73_inst, refa73_op in H. discriminate H. Qed.

Lemma refa73_not3511 : ~ @Equation3511 Fin3 refa73_inst.
Proof. unfold Equation3511. intro H. specialize (H F3_2 F3_1). unfold magma_op, refa73_inst, refa73_op in H. discriminate H. Qed.

Lemma refa73_not3512 : ~ @Equation3512 Fin3 refa73_inst.
Proof. unfold Equation3512. intro H. specialize (H F3_2 F3_1). unfold magma_op, refa73_inst, refa73_op in H. discriminate H. Qed.

Lemma refa73_not3518 : ~ @Equation3518 Fin3 refa73_inst.
Proof. unfold Equation3518. intro H. specialize (H F3_2 F3_1). unfold magma_op, refa73_inst, refa73_op in H. discriminate H. Qed.

Lemma refa73_not3519 : ~ @Equation3519 Fin3 refa73_inst.
Proof. unfold Equation3519. intro H. specialize (H F3_2 F3_1). unfold magma_op, refa73_inst, refa73_op in H. discriminate H. Qed.

Lemma refa73_not3521 : ~ @Equation3521 Fin3 refa73_inst.
Proof. unfold Equation3521. intro H. specialize (H F3_2 F3_1). unfold magma_op, refa73_inst, refa73_op in H. discriminate H. Qed.

Lemma refa73_not3522 : ~ @Equation3522 Fin3 refa73_inst.
Proof. unfold Equation3522. intro H. specialize (H F3_2 F3_1). unfold magma_op, refa73_inst, refa73_op in H. discriminate H. Qed.

Lemma refa73_not3545 : ~ @Equation3545 Fin3 refa73_inst.
Proof. unfold Equation3545. intro H. specialize (H F3_2 F3_1). unfold magma_op, refa73_inst, refa73_op in H. discriminate H. Qed.

Lemma refa73_not3546 : ~ @Equation3546 Fin3 refa73_inst.
Proof. unfold Equation3546. intro H. specialize (H F3_2 F3_1). unfold magma_op, refa73_inst, refa73_op in H. discriminate H. Qed.

Lemma refa73_not3548 : ~ @Equation3548 Fin3 refa73_inst.
Proof. unfold Equation3548. intro H. specialize (H F3_2 F3_1). unfold magma_op, refa73_inst, refa73_op in H. discriminate H. Qed.

Lemma refa73_not3549 : ~ @Equation3549 Fin3 refa73_inst.
Proof. unfold Equation3549. intro H. specialize (H F3_2 F3_1). unfold magma_op, refa73_inst, refa73_op in H. discriminate H. Qed.

Lemma refa73_not3555 : ~ @Equation3555 Fin3 refa73_inst.
Proof. unfold Equation3555. intro H. specialize (H F3_2 F3_1). unfold magma_op, refa73_inst, refa73_op in H. discriminate H. Qed.

Lemma refa73_not3556 : ~ @Equation3556 Fin3 refa73_inst.
Proof. unfold Equation3556. intro H. specialize (H F3_2 F3_1). unfold magma_op, refa73_inst, refa73_op in H. discriminate H. Qed.

Lemma refa73_not3558 : ~ @Equation3558 Fin3 refa73_inst.
Proof. unfold Equation3558. intro H. specialize (H F3_2 F3_1). unfold magma_op, refa73_inst, refa73_op in H. discriminate H. Qed.

Lemma refa73_not3712 : ~ @Equation3712 Fin3 refa73_inst.
Proof. unfold Equation3712. intro H. specialize (H F3_2 F3_1). unfold magma_op, refa73_inst, refa73_op in H. discriminate H. Qed.

Lemma refa73_not3714 : ~ @Equation3714 Fin3 refa73_inst.
Proof. unfold Equation3714. intro H. specialize (H F3_2 F3_1). unfold magma_op, refa73_inst, refa73_op in H. discriminate H. Qed.

Lemma refa73_not3721 : ~ @Equation3721 Fin3 refa73_inst.
Proof. unfold Equation3721. intro H. specialize (H F3_2 F3_1). unfold magma_op, refa73_inst, refa73_op in H. discriminate H. Qed.

Lemma refa73_not3722 : ~ @Equation3722 Fin3 refa73_inst.
Proof. unfold Equation3722. intro H. specialize (H F3_2 F3_1). unfold magma_op, refa73_inst, refa73_op in H. discriminate H. Qed.

Lemma refa73_not3724 : ~ @Equation3724 Fin3 refa73_inst.
Proof. unfold Equation3724. intro H. specialize (H F3_2 F3_1). unfold magma_op, refa73_inst, refa73_op in H. discriminate H. Qed.

Lemma refa73_not3725 : ~ @Equation3725 Fin3 refa73_inst.
Proof. unfold Equation3725. intro H. specialize (H F3_2 F3_1). unfold magma_op, refa73_inst, refa73_op in H. discriminate H. Qed.

Lemma refa73_not3748 : ~ @Equation3748 Fin3 refa73_inst.
Proof. unfold Equation3748. intro H. specialize (H F3_2 F3_1). unfold magma_op, refa73_inst, refa73_op in H. discriminate H. Qed.

Lemma refa73_not3749 : ~ @Equation3749 Fin3 refa73_inst.
Proof. unfold Equation3749. intro H. specialize (H F3_2 F3_1). unfold magma_op, refa73_inst, refa73_op in H. discriminate H. Qed.

Lemma refa73_not3752 : ~ @Equation3752 Fin3 refa73_inst.
Proof. unfold Equation3752. intro H. specialize (H F3_2 F3_1). unfold magma_op, refa73_inst, refa73_op in H. discriminate H. Qed.

Lemma refa73_not3759 : ~ @Equation3759 Fin3 refa73_inst.
Proof. unfold Equation3759. intro H. specialize (H F3_2 F3_1). unfold magma_op, refa73_inst, refa73_op in H. discriminate H. Qed.

Lemma refa73_not3761 : ~ @Equation3761 Fin3 refa73_inst.
Proof. unfold Equation3761. intro H. specialize (H F3_2 F3_1). unfold magma_op, refa73_inst, refa73_op in H. discriminate H. Qed.

Lemma refa73_not3915 : ~ @Equation3915 Fin3 refa73_inst.
Proof. unfold Equation3915. intro H. specialize (H F3_2 F3_1). unfold magma_op, refa73_inst, refa73_op in H. discriminate H. Qed.

Lemma refa73_not3917 : ~ @Equation3917 Fin3 refa73_inst.
Proof. unfold Equation3917. intro H. specialize (H F3_2 F3_1). unfold magma_op, refa73_inst, refa73_op in H. discriminate H. Qed.

Lemma refa73_not3918 : ~ @Equation3918 Fin3 refa73_inst.
Proof. unfold Equation3918. intro H. specialize (H F3_2 F3_1). unfold magma_op, refa73_inst, refa73_op in H. discriminate H. Qed.

Lemma refa73_not3924 : ~ @Equation3924 Fin3 refa73_inst.
Proof. unfold Equation3924. intro H. specialize (H F3_2 F3_1). unfold magma_op, refa73_inst, refa73_op in H. discriminate H. Qed.

Lemma refa73_not3925 : ~ @Equation3925 Fin3 refa73_inst.
Proof. unfold Equation3925. intro H. specialize (H F3_2 F3_1). unfold magma_op, refa73_inst, refa73_op in H. discriminate H. Qed.

Lemma refa73_not3927 : ~ @Equation3927 Fin3 refa73_inst.
Proof. unfold Equation3927. intro H. specialize (H F3_2 F3_1). unfold magma_op, refa73_inst, refa73_op in H. discriminate H. Qed.

Lemma refa73_not3928 : ~ @Equation3928 Fin3 refa73_inst.
Proof. unfold Equation3928. intro H. specialize (H F3_2 F3_1). unfold magma_op, refa73_inst, refa73_op in H. discriminate H. Qed.

Lemma refa73_not3951 : ~ @Equation3951 Fin3 refa73_inst.
Proof. unfold Equation3951. intro H. specialize (H F3_2 F3_1). unfold magma_op, refa73_inst, refa73_op in H. discriminate H. Qed.

Lemma refa73_not3952 : ~ @Equation3952 Fin3 refa73_inst.
Proof. unfold Equation3952. intro H. specialize (H F3_2 F3_1). unfold magma_op, refa73_inst, refa73_op in H. discriminate H. Qed.

Lemma refa73_not3954 : ~ @Equation3954 Fin3 refa73_inst.
Proof. unfold Equation3954. intro H. specialize (H F3_2 F3_1). unfold magma_op, refa73_inst, refa73_op in H. discriminate H. Qed.

Lemma refa73_not3955 : ~ @Equation3955 Fin3 refa73_inst.
Proof. unfold Equation3955. intro H. specialize (H F3_2 F3_1). unfold magma_op, refa73_inst, refa73_op in H. discriminate H. Qed.

Lemma refa73_not3961 : ~ @Equation3961 Fin3 refa73_inst.
Proof. unfold Equation3961. intro H. specialize (H F3_2 F3_1). unfold magma_op, refa73_inst, refa73_op in H. discriminate H. Qed.

Lemma refa73_not3962 : ~ @Equation3962 Fin3 refa73_inst.
Proof. unfold Equation3962. intro H. specialize (H F3_2 F3_1). unfold magma_op, refa73_inst, refa73_op in H. discriminate H. Qed.

Lemma refa73_not3964 : ~ @Equation3964 Fin3 refa73_inst.
Proof. unfold Equation3964. intro H. specialize (H F3_2 F3_1). unfold magma_op, refa73_inst, refa73_op in H. discriminate H. Qed.

Lemma refa73_not4074 : ~ @Equation4074 Fin3 refa73_inst.
Proof. unfold Equation4074. intro H. specialize (H F3_2 F3_1). unfold magma_op, refa73_inst, refa73_op in H. discriminate H. Qed.

Lemma refa73_not4080 : ~ @Equation4080 Fin3 refa73_inst.
Proof. unfold Equation4080. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa73_inst, refa73_op in H. discriminate H. Qed.

Lemma refa73_not4118 : ~ @Equation4118 Fin3 refa73_inst.
Proof. unfold Equation4118. intro H. specialize (H F3_2 F3_1). unfold magma_op, refa73_inst, refa73_op in H. discriminate H. Qed.

Lemma refa73_not4120 : ~ @Equation4120 Fin3 refa73_inst.
Proof. unfold Equation4120. intro H. specialize (H F3_2 F3_1). unfold magma_op, refa73_inst, refa73_op in H. discriminate H. Qed.

Lemma refa73_not4121 : ~ @Equation4121 Fin3 refa73_inst.
Proof. unfold Equation4121. intro H. specialize (H F3_2 F3_1). unfold magma_op, refa73_inst, refa73_op in H. discriminate H. Qed.

Lemma refa73_not4127 : ~ @Equation4127 Fin3 refa73_inst.
Proof. unfold Equation4127. intro H. specialize (H F3_2 F3_1). unfold magma_op, refa73_inst, refa73_op in H. discriminate H. Qed.

Lemma refa73_not4128 : ~ @Equation4128 Fin3 refa73_inst.
Proof. unfold Equation4128. intro H. specialize (H F3_2 F3_1). unfold magma_op, refa73_inst, refa73_op in H. discriminate H. Qed.

Lemma refa73_not4130 : ~ @Equation4130 Fin3 refa73_inst.
Proof. unfold Equation4130. intro H. specialize (H F3_2 F3_1). unfold magma_op, refa73_inst, refa73_op in H. discriminate H. Qed.

Lemma refa73_not4154 : ~ @Equation4154 Fin3 refa73_inst.
Proof. unfold Equation4154. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa73_inst, refa73_op in H. discriminate H. Qed.

Lemma refa73_not4155 : ~ @Equation4155 Fin3 refa73_inst.
Proof. unfold Equation4155. intro H. specialize (H F3_2 F3_1). unfold magma_op, refa73_inst, refa73_op in H. discriminate H. Qed.

Lemma refa73_not4157 : ~ @Equation4157 Fin3 refa73_inst.
Proof. unfold Equation4157. intro H. specialize (H F3_2 F3_1). unfold magma_op, refa73_inst, refa73_op in H. discriminate H. Qed.

Lemma refa73_not4158 : ~ @Equation4158 Fin3 refa73_inst.
Proof. unfold Equation4158. intro H. specialize (H F3_2 F3_1). unfold magma_op, refa73_inst, refa73_op in H. discriminate H. Qed.

Lemma refa73_not4164 : ~ @Equation4164 Fin3 refa73_inst.
Proof. unfold Equation4164. intro H. specialize (H F3_2 F3_1). unfold magma_op, refa73_inst, refa73_op in H. discriminate H. Qed.

Lemma refa73_not4165 : ~ @Equation4165 Fin3 refa73_inst.
Proof. unfold Equation4165. intro H. specialize (H F3_2 F3_1). unfold magma_op, refa73_inst, refa73_op in H. discriminate H. Qed.

Lemma refa73_not4167 : ~ @Equation4167 Fin3 refa73_inst.
Proof. unfold Equation4167. intro H. specialize (H F3_2 F3_1). unfold magma_op, refa73_inst, refa73_op in H. discriminate H. Qed.

Lemma refa73_not4399 : ~ @Equation4399 Fin3 refa73_inst.
Proof. unfold Equation4399. intro H. specialize (H F3_2 F3_1). unfold magma_op, refa73_inst, refa73_op in H. discriminate H. Qed.

Lemma refa73_not4405 : ~ @Equation4405 Fin3 refa73_inst.
Proof. unfold Equation4405. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa73_inst, refa73_op in H. discriminate H. Qed.

Lemma refa73_not4436 : ~ @Equation4436 Fin3 refa73_inst.
Proof. unfold Equation4436. intro H. specialize (H F3_2 F3_1). unfold magma_op, refa73_inst, refa73_op in H. discriminate H. Qed.

Lemma refa73_not4442 : ~ @Equation4442 Fin3 refa73_inst.
Proof. unfold Equation4442. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa73_inst, refa73_op in H. discriminate H. Qed.

Lemma refa73_not4473 : ~ @Equation4473 Fin3 refa73_inst.
Proof. unfold Equation4473. intro H. specialize (H F3_2 F3_1). unfold magma_op, refa73_inst, refa73_op in H. discriminate H. Qed.

Lemma refa73_not4479 : ~ @Equation4479 Fin3 refa73_inst.
Proof. unfold Equation4479. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa73_inst, refa73_op in H. discriminate H. Qed.

Lemma refa73_not4585 : ~ @Equation4585 Fin3 refa73_inst.
Proof. unfold Equation4585. intro H. specialize (H F3_2 F3_1). unfold magma_op, refa73_inst, refa73_op in H. discriminate H. Qed.

Lemma refa73_not4587 : ~ @Equation4587 Fin3 refa73_inst.
Proof. unfold Equation4587. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa73_inst, refa73_op in H. discriminate H. Qed.

Lemma refa73_not4599 : ~ @Equation4599 Fin3 refa73_inst.
Proof. unfold Equation4599. intro H. specialize (H F3_2 F3_1). unfold magma_op, refa73_inst, refa73_op in H. discriminate H. Qed.

Lemma refa73_not4605 : ~ @Equation4605 Fin3 refa73_inst.
Proof. unfold Equation4605. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa73_inst, refa73_op in H. discriminate H. Qed.

Lemma refa73_not4629 : ~ @Equation4629 Fin3 refa73_inst.
Proof. unfold Equation4629. intro H. specialize (H F3_2 F3_1). unfold magma_op, refa73_inst, refa73_op in H. discriminate H. Qed.

Lemma refa73_not4635 : ~ @Equation4635 Fin3 refa73_inst.
Proof. unfold Equation4635. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa73_inst, refa73_op in H. discriminate H. Qed.

Lemma refa73_not4658 : ~ @Equation4658 Fin3 refa73_inst.
Proof. unfold Equation4658. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa73_inst, refa73_op in H. discriminate H. Qed.

(** ---- refa730 (Fin6) ---- *)

Definition refa730_op (x y : Fin6) : Fin6 :=
  match x, y with
  | F6_0, F6_0 => F6_0 | F6_0, F6_1 => F6_3 | F6_0, F6_2 => F6_3 | F6_0, F6_3 => F6_3 | F6_0, F6_4 => F6_4 | F6_0, F6_5 => F6_5
  | F6_1, F6_0 => F6_5 | F6_1, F6_1 => F6_1 | F6_1, F6_2 => F6_3 | F6_1, F6_3 => F6_3 | F6_1, F6_4 => F6_3 | F6_1, F6_5 => F6_5
  | F6_2, F6_0 => F6_4 | F6_2, F6_1 => F6_3 | F6_2, F6_2 => F6_2 | F6_2, F6_3 => F6_3 | F6_2, F6_4 => F6_4 | F6_2, F6_5 => F6_3
  | F6_3, F6_0 => F6_0 | F6_3, F6_1 => F6_1 | F6_3, F6_2 => F6_2 | F6_3, F6_3 => F6_3 | F6_3, F6_4 => F6_4 | F6_3, F6_5 => F6_5
  | F6_4, F6_0 => F6_0 | F6_4, F6_1 => F6_5 | F6_4, F6_2 => F6_2 | F6_4, F6_3 => F6_3 | F6_4, F6_4 => F6_4 | F6_4, F6_5 => F6_5
  | F6_5, F6_0 => F6_0 | F6_5, F6_1 => F6_1 | F6_5, F6_2 => F6_3 | F6_5, F6_3 => F6_3 | F6_5, F6_4 => F6_4 | F6_5, F6_5 => F6_5
  end.

#[local] Instance refa730_inst : Magma Fin6 := {| magma_op := refa730_op |}.

Lemma refa730_sat2499 : @Equation2499 Fin6 refa730_inst.
Proof. unfold Equation2499, magma_op, refa730_inst, refa730_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa730_not3529 : ~ @Equation3529 Fin6 refa730_inst.
Proof. unfold Equation3529. intro H. specialize (H F6_0 F6_1 F6_2). unfold magma_op, refa730_inst, refa730_op in H. discriminate H. Qed.

Lemma refa730_not4362 : ~ @Equation4362 Fin6 refa730_inst.
Proof. unfold Equation4362. intro H. specialize (H F6_0 F6_4 F6_1). unfold magma_op, refa730_inst, refa730_op in H. discriminate H. Qed.

(** ---- refa731 (Fin5) ---- *)

Definition refa731_op (x y : Fin5) : Fin5 :=
  match x, y with
  | F5_0, F5_0 => F5_4 | F5_0, F5_1 => F5_2 | F5_0, F5_2 => F5_2 | F5_0, F5_3 => F5_2 | F5_0, F5_4 => F5_4
  | F5_1, F5_0 => F5_3 | F5_1, F5_1 => F5_4 | F5_1, F5_2 => F5_3 | F5_1, F5_3 => F5_3 | F5_1, F5_4 => F5_4
  | F5_2, F5_0 => F5_0 | F5_2, F5_1 => F5_0 | F5_2, F5_2 => F5_4 | F5_2, F5_3 => F5_0 | F5_2, F5_4 => F5_4
  | F5_3, F5_0 => F5_1 | F5_3, F5_1 => F5_1 | F5_3, F5_2 => F5_1 | F5_3, F5_3 => F5_4 | F5_3, F5_4 => F5_4
  | F5_4, F5_0 => F5_0 | F5_4, F5_1 => F5_1 | F5_4, F5_2 => F5_2 | F5_4, F5_3 => F5_3 | F5_4, F5_4 => F5_4
  end.

#[local] Instance refa731_inst : Magma Fin5 := {| magma_op := refa731_op |}.

Lemma refa731_sat2536 : @Equation2536 Fin5 refa731_inst.
Proof. unfold Equation2536, magma_op, refa731_inst, refa731_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa731_not221 : ~ @Equation221 Fin5 refa731_inst.
Proof. unfold Equation221. intro H. specialize (H F5_0 F5_1). unfold magma_op, refa731_inst, refa731_op in H. discriminate H. Qed.

Lemma refa731_not2293 : ~ @Equation2293 Fin5 refa731_inst.
Proof. unfold Equation2293. intro H. specialize (H F5_0 F5_1). unfold magma_op, refa731_inst, refa731_op in H. discriminate H. Qed.

Lemma refa731_not2300 : ~ @Equation2300 Fin5 refa731_inst.
Proof. unfold Equation2300. intro H. specialize (H F5_0 F5_1). unfold magma_op, refa731_inst, refa731_op in H. discriminate H. Qed.

Lemma refa731_not2330 : ~ @Equation2330 Fin5 refa731_inst.
Proof. unfold Equation2330. intro H. specialize (H F5_0 F5_1). unfold magma_op, refa731_inst, refa731_op in H. discriminate H. Qed.

Lemma refa731_not2506 : ~ @Equation2506 Fin5 refa731_inst.
Proof. unfold Equation2506. intro H. specialize (H F5_0 F5_1). unfold magma_op, refa731_inst, refa731_op in H. discriminate H. Qed.

Lemma refa731_not2699 : ~ @Equation2699 Fin5 refa731_inst.
Proof. unfold Equation2699. intro H. specialize (H F5_0 F5_1). unfold magma_op, refa731_inst, refa731_op in H. discriminate H. Qed.

Lemma refa731_not3255 : ~ @Equation3255 Fin5 refa731_inst.
Proof. unfold Equation3255. intro H. specialize (H F5_0 F5_1). unfold magma_op, refa731_inst, refa731_op in H. discriminate H. Qed.

Lemma refa731_not3271 : ~ @Equation3271 Fin5 refa731_inst.
Proof. unfold Equation3271. intro H. specialize (H F5_0 F5_1). unfold magma_op, refa731_inst, refa731_op in H. discriminate H. Qed.

Lemma refa731_not3461 : ~ @Equation3461 Fin5 refa731_inst.
Proof. unfold Equation3461. intro H. specialize (H F5_0 F5_1). unfold magma_op, refa731_inst, refa731_op in H. discriminate H. Qed.

Lemma refa731_not3749 : ~ @Equation3749 Fin5 refa731_inst.
Proof. unfold Equation3749. intro H. specialize (H F5_0 F5_1). unfold magma_op, refa731_inst, refa731_op in H. discriminate H. Qed.

Lemma refa731_not4155 : ~ @Equation4155 Fin5 refa731_inst.
Proof. unfold Equation4155. intro H. specialize (H F5_0 F5_1). unfold magma_op, refa731_inst, refa731_op in H. discriminate H. Qed.

(** ---- refa732 (Fin5) ---- *)

Definition refa732_op (x y : Fin5) : Fin5 :=
  match x, y with
  | F5_0, F5_0 => F5_0 | F5_0, F5_1 => F5_4 | F5_0, F5_2 => F5_3 | F5_0, F5_3 => F5_3 | F5_0, F5_4 => F5_4
  | F5_1, F5_0 => F5_2 | F5_1, F5_1 => F5_1 | F5_1, F5_2 => F5_2 | F5_1, F5_3 => F5_3 | F5_1, F5_4 => F5_4
  | F5_2, F5_0 => F5_0 | F5_2, F5_1 => F5_4 | F5_2, F5_2 => F5_2 | F5_2, F5_3 => F5_4 | F5_2, F5_4 => F5_1
  | F5_3, F5_0 => F5_4 | F5_3, F5_1 => F5_1 | F5_3, F5_2 => F5_2 | F5_3, F5_3 => F5_3 | F5_3, F5_4 => F5_4
  | F5_4, F5_0 => F5_0 | F5_4, F5_1 => F5_1 | F5_4, F5_2 => F5_2 | F5_4, F5_3 => F5_3 | F5_4, F5_4 => F5_4
  end.

#[local] Instance refa732_inst : Magma Fin5 := {| magma_op := refa732_op |}.

Lemma refa732_sat2550 : @Equation2550 Fin5 refa732_inst.
Proof. unfold Equation2550, magma_op, refa732_inst, refa732_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa732_not2503 : ~ @Equation2503 Fin5 refa732_inst.
Proof. unfold Equation2503. intro H. specialize (H F5_0 F5_2). unfold magma_op, refa732_inst, refa732_op in H. discriminate H. Qed.

(** ---- refa733 (Fin6) ---- *)

Definition refa733_op (x y : Fin6) : Fin6 :=
  match x, y with
  | F6_0, F6_0 => F6_0 | F6_0, F6_1 => F6_4 | F6_0, F6_2 => F6_3 | F6_0, F6_3 => F6_3 | F6_0, F6_4 => F6_4 | F6_0, F6_5 => F6_2
  | F6_1, F6_0 => F6_2 | F6_1, F6_1 => F6_1 | F6_1, F6_2 => F6_2 | F6_1, F6_3 => F6_4 | F6_1, F6_4 => F6_4 | F6_1, F6_5 => F6_2
  | F6_2, F6_0 => F6_0 | F6_2, F6_1 => F6_1 | F6_2, F6_2 => F6_2 | F6_2, F6_3 => F6_4 | F6_2, F6_4 => F6_0 | F6_2, F6_5 => F6_5
  | F6_3, F6_0 => F6_4 | F6_3, F6_1 => F6_1 | F6_3, F6_2 => F6_2 | F6_3, F6_3 => F6_3 | F6_3, F6_4 => F6_0 | F6_3, F6_5 => F6_5
  | F6_4, F6_0 => F6_5 | F6_4, F6_1 => F6_1 | F6_4, F6_2 => F6_2 | F6_4, F6_3 => F6_3 | F6_4, F6_4 => F6_4 | F6_4, F6_5 => F6_2
  | F6_5, F6_0 => F6_0 | F6_5, F6_1 => F6_1 | F6_5, F6_2 => F6_3 | F6_5, F6_3 => F6_4 | F6_5, F6_4 => F6_0 | F6_5, F6_5 => F6_5
  end.

#[local] Instance refa733_inst : Magma Fin6 := {| magma_op := refa733_op |}.

Lemma refa733_sat2584 : @Equation2584 Fin6 refa733_inst.
Proof. unfold Equation2584, magma_op, refa733_inst, refa733_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa733_not2862 : ~ @Equation2862 Fin6 refa733_inst.
Proof. unfold Equation2862. intro H. specialize (H F6_0 F6_1). unfold magma_op, refa733_inst, refa733_op in H. discriminate H. Qed.

(** ---- refa734 (Fin5) ---- *)

Definition refa734_op (x y : Fin5) : Fin5 :=
  match x, y with
  | F5_0, F5_0 => F5_1 | F5_0, F5_1 => F5_3 | F5_0, F5_2 => F5_4 | F5_0, F5_3 => F5_1 | F5_0, F5_4 => F5_2
  | F5_1, F5_0 => F5_2 | F5_1, F5_1 => F5_4 | F5_1, F5_2 => F5_3 | F5_1, F5_3 => F5_2 | F5_1, F5_4 => F5_1
  | F5_2, F5_0 => F5_4 | F5_2, F5_1 => F5_2 | F5_2, F5_2 => F5_1 | F5_2, F5_3 => F5_4 | F5_2, F5_4 => F5_3
  | F5_3, F5_0 => F5_1 | F5_3, F5_1 => F5_0 | F5_3, F5_2 => F5_4 | F5_3, F5_3 => F5_4 | F5_3, F5_4 => F5_3
  | F5_4, F5_0 => F5_0 | F5_4, F5_1 => F5_1 | F5_4, F5_2 => F5_2 | F5_4, F5_3 => F5_3 | F5_4, F5_4 => F5_4
  end.

#[local] Instance refa734_inst : Magma Fin5 := {| magma_op := refa734_op |}.

Lemma refa734_sat2592 : @Equation2592 Fin5 refa734_inst.
Proof. unfold Equation2592, magma_op, refa734_inst, refa734_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa734_not1629 : ~ @Equation1629 Fin5 refa734_inst.
Proof. unfold Equation1629. intro H. specialize (H F5_0). unfold magma_op, refa734_inst, refa734_op in H. discriminate H. Qed.

Lemma refa734_not3261 : ~ @Equation3261 Fin5 refa734_inst.
Proof. unfold Equation3261. intro H. specialize (H F5_2 F5_3). unfold magma_op, refa734_inst, refa734_op in H. discriminate H. Qed.

Lemma refa734_not3271 : ~ @Equation3271 Fin5 refa734_inst.
Proof. unfold Equation3271. intro H. specialize (H F5_0 F5_3). unfold magma_op, refa734_inst, refa734_op in H. discriminate H. Qed.

Lemma refa734_not3868 : ~ @Equation3868 Fin5 refa734_inst.
Proof. unfold Equation3868. intro H. specialize (H F5_0 F5_3). unfold magma_op, refa734_inst, refa734_op in H. discriminate H. Qed.

Lemma refa734_not3887 : ~ @Equation3887 Fin5 refa734_inst.
Proof. unfold Equation3887. intro H. specialize (H F5_2 F5_3). unfold magma_op, refa734_inst, refa734_op in H. discriminate H. Qed.

Lemma refa734_not3915 : ~ @Equation3915 Fin5 refa734_inst.
Proof. unfold Equation3915. intro H. specialize (H F5_0 F5_1). unfold magma_op, refa734_inst, refa734_op in H. discriminate H. Qed.

Lemma refa734_not3962 : ~ @Equation3962 Fin5 refa734_inst.
Proof. unfold Equation3962. intro H. specialize (H F5_0 F5_1). unfold magma_op, refa734_inst, refa734_op in H. discriminate H. Qed.

Lemma refa734_not4320 : ~ @Equation4320 Fin5 refa734_inst.
Proof. unfold Equation4320. intro H. specialize (H F5_0 F5_3). unfold magma_op, refa734_inst, refa734_op in H. discriminate H. Qed.

(** ---- refa735 (Fin5) ---- *)

Definition refa735_op (x y : Fin5) : Fin5 :=
  match x, y with
  | F5_0, F5_0 => F5_1 | F5_0, F5_1 => F5_4 | F5_0, F5_2 => F5_3 | F5_0, F5_3 => F5_2 | F5_0, F5_4 => F5_0
  | F5_1, F5_0 => F5_2 | F5_1, F5_1 => F5_0 | F5_1, F5_2 => F5_1 | F5_1, F5_3 => F5_4 | F5_1, F5_4 => F5_3
  | F5_2, F5_0 => F5_3 | F5_2, F5_1 => F5_2 | F5_2, F5_2 => F5_4 | F5_2, F5_3 => F5_0 | F5_2, F5_4 => F5_1
  | F5_3, F5_0 => F5_0 | F5_3, F5_1 => F5_1 | F5_3, F5_2 => F5_2 | F5_3, F5_3 => F5_3 | F5_3, F5_4 => F5_4
  | F5_4, F5_0 => F5_4 | F5_4, F5_1 => F5_3 | F5_4, F5_2 => F5_0 | F5_4, F5_3 => F5_1 | F5_4, F5_4 => F5_2
  end.

#[local] Instance refa735_inst : Magma Fin5 := {| magma_op := refa735_op |}.

Lemma refa735_sat2592 : @Equation2592 Fin5 refa735_inst.
Proof. unfold Equation2592, magma_op, refa735_inst, refa735_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa735_not2644 : ~ @Equation2644 Fin5 refa735_inst.
Proof. unfold Equation2644. intro H. specialize (H F5_0). unfold magma_op, refa735_inst, refa735_op in H. discriminate H. Qed.

Lemma refa735_not3253 : ~ @Equation3253 Fin5 refa735_inst.
Proof. unfold Equation3253. intro H. specialize (H F5_0). unfold magma_op, refa735_inst, refa735_op in H. discriminate H. Qed.

Lemma refa735_not3862 : ~ @Equation3862 Fin5 refa735_inst.
Proof. unfold Equation3862. intro H. specialize (H F5_0). unfold magma_op, refa735_inst, refa735_op in H. discriminate H. Qed.

(** ---- refa736 (Fin5) ---- *)

Definition refa736_op (x y : Fin5) : Fin5 :=
  match x, y with
  | F5_0, F5_0 => F5_0 | F5_0, F5_1 => F5_0 | F5_0, F5_2 => F5_0 | F5_0, F5_3 => F5_4 | F5_0, F5_4 => F5_4
  | F5_1, F5_0 => F5_2 | F5_1, F5_1 => F5_2 | F5_1, F5_2 => F5_2 | F5_1, F5_3 => F5_2 | F5_1, F5_4 => F5_2
  | F5_2, F5_0 => F5_3 | F5_2, F5_1 => F5_3 | F5_2, F5_2 => F5_3 | F5_2, F5_3 => F5_3 | F5_2, F5_4 => F5_3
  | F5_3, F5_0 => F5_1 | F5_3, F5_1 => F5_1 | F5_3, F5_2 => F5_1 | F5_3, F5_3 => F5_1 | F5_3, F5_4 => F5_1
  | F5_4, F5_0 => F5_4 | F5_4, F5_1 => F5_4 | F5_4, F5_2 => F5_4 | F5_4, F5_3 => F5_0 | F5_4, F5_4 => F5_0
  end.

#[local] Instance refa736_inst : Magma Fin5 := {| magma_op := refa736_op |}.

Lemma refa736_sat2647 : @Equation2647 Fin5 refa736_inst.
Proof. unfold Equation2647, magma_op, refa736_inst, refa736_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa736_not3522 : ~ @Equation3522 Fin5 refa736_inst.
Proof. unfold Equation3522. intro H. specialize (H F5_0 F5_1). unfold magma_op, refa736_inst, refa736_op in H. discriminate H. Qed.

(** ---- refa737 (Fin7) ---- *)

Definition refa737_op (x y : Fin7) : Fin7 :=
  match x, y with
  | F7_0, F7_0 => F7_0 | F7_0, F7_1 => F7_2 | F7_0, F7_2 => F7_6 | F7_0, F7_3 => F7_1 | F7_0, F7_4 => F7_5 | F7_0, F7_5 => F7_3 | F7_0, F7_6 => F7_4
  | F7_1, F7_0 => F7_5 | F7_1, F7_1 => F7_5 | F7_1, F7_2 => F7_1 | F7_1, F7_3 => F7_6 | F7_1, F7_4 => F7_0 | F7_1, F7_5 => F7_5 | F7_1, F7_6 => F7_5
  | F7_2, F7_0 => F7_4 | F7_2, F7_1 => F7_3 | F7_2, F7_2 => F7_4 | F7_2, F7_3 => F7_4 | F7_2, F7_4 => F7_4 | F7_2, F7_5 => F7_2 | F7_2, F7_6 => F7_0
  | F7_3, F7_0 => F7_2 | F7_3, F7_1 => F7_0 | F7_3, F7_2 => F7_2 | F7_3, F7_3 => F7_2 | F7_3, F7_4 => F7_2 | F7_3, F7_5 => F7_4 | F7_3, F7_6 => F7_3
  | F7_4, F7_0 => F7_3 | F7_4, F7_1 => F7_4 | F7_4, F7_2 => F7_3 | F7_4, F7_3 => F7_3 | F7_4, F7_4 => F7_3 | F7_4, F7_5 => F7_0 | F7_4, F7_6 => F7_2
  | F7_5, F7_0 => F7_6 | F7_5, F7_1 => F7_6 | F7_5, F7_2 => F7_0 | F7_5, F7_3 => F7_5 | F7_5, F7_4 => F7_1 | F7_5, F7_5 => F7_6 | F7_5, F7_6 => F7_6
  | F7_6, F7_0 => F7_1 | F7_6, F7_1 => F7_1 | F7_6, F7_2 => F7_5 | F7_6, F7_3 => F7_0 | F7_6, F7_4 => F7_6 | F7_6, F7_5 => F7_1 | F7_6, F7_6 => F7_1
  end.

#[local] Instance refa737_inst : Magma Fin7 := {| magma_op := refa737_op |}.

Lemma refa737_sat2653 : @Equation2653 Fin7 refa737_inst.
Proof. unfold Equation2653, magma_op, refa737_inst, refa737_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa737_not3459 : ~ @Equation3459 Fin7 refa737_inst.
Proof. unfold Equation3459. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa737_inst, refa737_op in H. discriminate H. Qed.

(** ---- refa738 (Fin6) ---- *)

Definition refa738_op (x y : Fin6) : Fin6 :=
  match x, y with
  | F6_0, F6_0 => F6_2 | F6_0, F6_1 => F6_4 | F6_0, F6_2 => F6_2 | F6_0, F6_3 => F6_0 | F6_0, F6_4 => F6_2 | F6_0, F6_5 => F6_2
  | F6_1, F6_0 => F6_3 | F6_1, F6_1 => F6_3 | F6_1, F6_2 => F6_3 | F6_1, F6_3 => F6_3 | F6_1, F6_4 => F6_3 | F6_1, F6_5 => F6_3
  | F6_2, F6_0 => F6_4 | F6_2, F6_1 => F6_2 | F6_2, F6_2 => F6_4 | F6_2, F6_3 => F6_4 | F6_2, F6_4 => F6_4 | F6_2, F6_5 => F6_0
  | F6_3, F6_0 => F6_5 | F6_3, F6_1 => F6_5 | F6_3, F6_2 => F6_5 | F6_3, F6_3 => F6_5 | F6_3, F6_4 => F6_5 | F6_3, F6_5 => F6_5
  | F6_4, F6_0 => F6_0 | F6_4, F6_1 => F6_0 | F6_4, F6_2 => F6_0 | F6_4, F6_3 => F6_2 | F6_4, F6_4 => F6_0 | F6_4, F6_5 => F6_4
  | F6_5, F6_0 => F6_1 | F6_5, F6_1 => F6_1 | F6_5, F6_2 => F6_1 | F6_5, F6_3 => F6_1 | F6_5, F6_4 => F6_1 | F6_5, F6_5 => F6_1
  end.

#[local] Instance refa738_inst : Magma Fin6 := {| magma_op := refa738_op |}.

Lemma refa738_sat2656 : @Equation2656 Fin6 refa738_inst.
Proof. unfold Equation2656, magma_op, refa738_inst, refa738_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa738_not261 : ~ @Equation261 Fin6 refa738_inst.
Proof. unfold Equation261. intro H. specialize (H F6_0 F6_1). unfold magma_op, refa738_inst, refa738_op in H. discriminate H. Qed.

Lemma refa738_not263 : ~ @Equation263 Fin6 refa738_inst.
Proof. unfold Equation263. intro H. specialize (H F6_0 F6_1). unfold magma_op, refa738_inst, refa738_op in H. discriminate H. Qed.

Lemma refa738_not2043 : ~ @Equation2043 Fin6 refa738_inst.
Proof. unfold Equation2043. intro H. specialize (H F6_0 F6_1). unfold magma_op, refa738_inst, refa738_op in H. discriminate H. Qed.

Lemma refa738_not2044 : ~ @Equation2044 Fin6 refa738_inst.
Proof. unfold Equation2044. intro H. specialize (H F6_0 F6_1). unfold magma_op, refa738_inst, refa738_op in H. discriminate H. Qed.

Lemma refa738_not2060 : ~ @Equation2060 Fin6 refa738_inst.
Proof. unfold Equation2060. intro H. specialize (H F6_0 F6_1). unfold magma_op, refa738_inst, refa738_op in H. discriminate H. Qed.

Lemma refa738_not2061 : ~ @Equation2061 Fin6 refa738_inst.
Proof. unfold Equation2061. intro H. specialize (H F6_0 F6_1). unfold magma_op, refa738_inst, refa738_op in H. discriminate H. Qed.

Lemma refa738_not2660 : ~ @Equation2660 Fin6 refa738_inst.
Proof. unfold Equation2660. intro H. specialize (H F6_0 F6_1). unfold magma_op, refa738_inst, refa738_op in H. discriminate H. Qed.

Lemma refa738_not2669 : ~ @Equation2669 Fin6 refa738_inst.
Proof. unfold Equation2669. intro H. specialize (H F6_0 F6_1). unfold magma_op, refa738_inst, refa738_op in H. discriminate H. Qed.

Lemma refa738_not2672 : ~ @Equation2672 Fin6 refa738_inst.
Proof. unfold Equation2672. intro H. specialize (H F6_0 F6_1). unfold magma_op, refa738_inst, refa738_op in H. discriminate H. Qed.

Lemma refa738_not2856 : ~ @Equation2856 Fin6 refa738_inst.
Proof. unfold Equation2856. intro H. specialize (H F6_0 F6_1). unfold magma_op, refa738_inst, refa738_op in H. discriminate H. Qed.

Lemma refa738_not2863 : ~ @Equation2863 Fin6 refa738_inst.
Proof. unfold Equation2863. intro H. specialize (H F6_0 F6_1). unfold magma_op, refa738_inst, refa738_op in H. discriminate H. Qed.

Lemma refa738_not2873 : ~ @Equation2873 Fin6 refa738_inst.
Proof. unfold Equation2873. intro H. specialize (H F6_0 F6_1). unfold magma_op, refa738_inst, refa738_op in H. discriminate H. Qed.

Lemma refa738_not3315 : ~ @Equation3315 Fin6 refa738_inst.
Proof. unfold Equation3315. intro H. specialize (H F6_0 F6_1). unfold magma_op, refa738_inst, refa738_op in H. discriminate H. Qed.

Lemma refa738_not3316 : ~ @Equation3316 Fin6 refa738_inst.
Proof. unfold Equation3316. intro H. specialize (H F6_0 F6_1). unfold magma_op, refa738_inst, refa738_op in H. discriminate H. Qed.

Lemma refa738_not3318 : ~ @Equation3318 Fin6 refa738_inst.
Proof. unfold Equation3318. intro H. specialize (H F6_0 F6_1). unfold magma_op, refa738_inst, refa738_op in H. discriminate H. Qed.

Lemma refa738_not3319 : ~ @Equation3319 Fin6 refa738_inst.
Proof. unfold Equation3319. intro H. specialize (H F6_0 F6_1). unfold magma_op, refa738_inst, refa738_op in H. discriminate H. Qed.

Lemma refa738_not3518 : ~ @Equation3518 Fin6 refa738_inst.
Proof. unfold Equation3518. intro H. specialize (H F6_0 F6_1). unfold magma_op, refa738_inst, refa738_op in H. discriminate H. Qed.

Lemma refa738_not3519 : ~ @Equation3519 Fin6 refa738_inst.
Proof. unfold Equation3519. intro H. specialize (H F6_0 F6_1). unfold magma_op, refa738_inst, refa738_op in H. discriminate H. Qed.

Lemma refa738_not3521 : ~ @Equation3521 Fin6 refa738_inst.
Proof. unfold Equation3521. intro H. specialize (H F6_0 F6_1). unfold magma_op, refa738_inst, refa738_op in H. discriminate H. Qed.

Lemma refa738_not3522 : ~ @Equation3522 Fin6 refa738_inst.
Proof. unfold Equation3522. intro H. specialize (H F6_0 F6_1). unfold magma_op, refa738_inst, refa738_op in H. discriminate H. Qed.

Lemma refa738_not4598 : ~ @Equation4598 Fin6 refa738_inst.
Proof. unfold Equation4598. intro H. specialize (H F6_0 F6_1). unfold magma_op, refa738_inst, refa738_op in H. discriminate H. Qed.

Lemma refa738_not4656 : ~ @Equation4656 Fin6 refa738_inst.
Proof. unfold Equation4656. intro H. specialize (H F6_0 F6_0 F6_1). unfold magma_op, refa738_inst, refa738_op in H. discriminate H. Qed.

(** ---- refa739 (Fin5) ---- *)

Definition refa739_op (x y : Fin5) : Fin5 :=
  match x, y with
  | F5_0, F5_0 => F5_1 | F5_0, F5_1 => F5_2 | F5_0, F5_2 => F5_2 | F5_0, F5_3 => F5_1 | F5_0, F5_4 => F5_1
  | F5_1, F5_0 => F5_2 | F5_1, F5_1 => F5_2 | F5_1, F5_2 => F5_2 | F5_1, F5_3 => F5_2 | F5_1, F5_4 => F5_4
  | F5_2, F5_0 => F5_0 | F5_2, F5_1 => F5_4 | F5_2, F5_2 => F5_4 | F5_2, F5_3 => F5_3 | F5_2, F5_4 => F5_4
  | F5_3, F5_0 => F5_1 | F5_3, F5_1 => F5_1 | F5_3, F5_2 => F5_2 | F5_3, F5_3 => F5_1 | F5_3, F5_4 => F5_1
  | F5_4, F5_0 => F5_0 | F5_4, F5_1 => F5_1 | F5_4, F5_2 => F5_3 | F5_4, F5_3 => F5_3 | F5_4, F5_4 => F5_3
  end.

#[local] Instance refa739_inst : Magma Fin5 := {| magma_op := refa739_op |}.

Lemma refa739_sat2665 : @Equation2665 Fin5 refa739_inst.
Proof. unfold Equation2665, magma_op, refa739_inst, refa739_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa739_not3253 : ~ @Equation3253 Fin5 refa739_inst.
Proof. unfold Equation3253. intro H. specialize (H F5_0). unfold magma_op, refa739_inst, refa739_op in H. discriminate H. Qed.

Lemma refa739_not3456 : ~ @Equation3456 Fin5 refa739_inst.
Proof. unfold Equation3456. intro H. specialize (H F5_0). unfold magma_op, refa739_inst, refa739_op in H. discriminate H. Qed.

Lemma refa739_not4631 : ~ @Equation4631 Fin5 refa739_inst.
Proof. unfold Equation4631. intro H. specialize (H F5_0 F5_0 F5_1). unfold magma_op, refa739_inst, refa739_op in H. discriminate H. Qed.

(** ---- refa74 (Fin3) ---- *)

Definition refa74_op (x y : Fin3) : Fin3 :=
  match x, y with
  | F3_0, F3_0 => F3_0 | F3_0, F3_1 => F3_0 | F3_0, F3_2 => F3_0
  | F3_1, F3_0 => F3_0 | F3_1, F3_1 => F3_0 | F3_1, F3_2 => F3_0
  | F3_2, F3_0 => F3_1 | F3_2, F3_1 => F3_2 | F3_2, F3_2 => F3_0
  end.

#[local] Instance refa74_inst : Magma Fin3 := {| magma_op := refa74_op |}.

Lemma refa74_sat371 : @Equation371 Fin3 refa74_inst.
Proof. unfold Equation371, magma_op, refa74_inst, refa74_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa74_sat3882 : @Equation3882 Fin3 refa74_inst.
Proof. unfold Equation3882, magma_op, refa74_inst, refa74_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa74_sat3899 : @Equation3899 Fin3 refa74_inst.
Proof. unfold Equation3899, magma_op, refa74_inst, refa74_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa74_sat4076 : @Equation4076 Fin3 refa74_inst.
Proof. unfold Equation4076, magma_op, refa74_inst, refa74_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa74_sat4109 : @Equation4109 Fin3 refa74_inst.
Proof. unfold Equation4109, magma_op, refa74_inst, refa74_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa74_sat4318 : @Equation4318 Fin3 refa74_inst.
Proof. unfold Equation4318, magma_op, refa74_inst, refa74_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa74_not3253 : ~ @Equation3253 Fin3 refa74_inst.
Proof. unfold Equation3253. intro H. specialize (H F3_2). unfold magma_op, refa74_inst, refa74_op in H. discriminate H. Qed.

Lemma refa74_not3456 : ~ @Equation3456 Fin3 refa74_inst.
Proof. unfold Equation3456. intro H. specialize (H F3_2). unfold magma_op, refa74_inst, refa74_op in H. discriminate H. Qed.

Lemma refa74_not3664 : ~ @Equation3664 Fin3 refa74_inst.
Proof. unfold Equation3664. intro H. specialize (H F3_2 F3_1). unfold magma_op, refa74_inst, refa74_op in H. discriminate H. Qed.

Lemma refa74_not3667 : ~ @Equation3667 Fin3 refa74_inst.
Proof. unfold Equation3667. intro H. specialize (H F3_2 F3_1). unfold magma_op, refa74_inst, refa74_op in H. discriminate H. Qed.

Lemma refa74_not3668 : ~ @Equation3668 Fin3 refa74_inst.
Proof. unfold Equation3668. intro H. specialize (H F3_2 F3_1). unfold magma_op, refa74_inst, refa74_op in H. discriminate H. Qed.

Lemma refa74_not3674 : ~ @Equation3674 Fin3 refa74_inst.
Proof. unfold Equation3674. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa74_inst, refa74_op in H. discriminate H. Qed.

Lemma refa74_not3675 : ~ @Equation3675 Fin3 refa74_inst.
Proof. unfold Equation3675. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa74_inst, refa74_op in H. discriminate H. Qed.

Lemma refa74_not3678 : ~ @Equation3678 Fin3 refa74_inst.
Proof. unfold Equation3678. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa74_inst, refa74_op in H. discriminate H. Qed.

Lemma refa74_not3721 : ~ @Equation3721 Fin3 refa74_inst.
Proof. unfold Equation3721. intro H. specialize (H F3_2 F3_0). unfold magma_op, refa74_inst, refa74_op in H. discriminate H. Qed.

Lemma refa74_not3724 : ~ @Equation3724 Fin3 refa74_inst.
Proof. unfold Equation3724. intro H. specialize (H F3_2 F3_0). unfold magma_op, refa74_inst, refa74_op in H. discriminate H. Qed.

Lemma refa74_not3725 : ~ @Equation3725 Fin3 refa74_inst.
Proof. unfold Equation3725. intro H. specialize (H F3_2 F3_0). unfold magma_op, refa74_inst, refa74_op in H. discriminate H. Qed.

Lemma refa74_not3865 : ~ @Equation3865 Fin3 refa74_inst.
Proof. unfold Equation3865. intro H. specialize (H F3_2 F3_0). unfold magma_op, refa74_inst, refa74_op in H. discriminate H. Qed.

Lemma refa74_not3887 : ~ @Equation3887 Fin3 refa74_inst.
Proof. unfold Equation3887. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa74_inst, refa74_op in H. discriminate H. Qed.

Lemma refa74_not3915 : ~ @Equation3915 Fin3 refa74_inst.
Proof. unfold Equation3915. intro H. specialize (H F3_2 F3_0). unfold magma_op, refa74_inst, refa74_op in H. discriminate H. Qed.

Lemma refa74_not3925 : ~ @Equation3925 Fin3 refa74_inst.
Proof. unfold Equation3925. intro H. specialize (H F3_2 F3_0). unfold magma_op, refa74_inst, refa74_op in H. discriminate H. Qed.

Lemma refa74_not3928 : ~ @Equation3928 Fin3 refa74_inst.
Proof. unfold Equation3928. intro H. specialize (H F3_2 F3_0). unfold magma_op, refa74_inst, refa74_op in H. discriminate H. Qed.

Lemma refa74_not3952 : ~ @Equation3952 Fin3 refa74_inst.
Proof. unfold Equation3952. intro H. specialize (H F3_2 F3_0). unfold magma_op, refa74_inst, refa74_op in H. discriminate H. Qed.

Lemma refa74_not3955 : ~ @Equation3955 Fin3 refa74_inst.
Proof. unfold Equation3955. intro H. specialize (H F3_2 F3_0). unfold magma_op, refa74_inst, refa74_op in H. discriminate H. Qed.

Lemma refa74_not3962 : ~ @Equation3962 Fin3 refa74_inst.
Proof. unfold Equation3962. intro H. specialize (H F3_2 F3_0). unfold magma_op, refa74_inst, refa74_op in H. discriminate H. Qed.

Lemma refa74_not4131 : ~ @Equation4131 Fin3 refa74_inst.
Proof. unfold Equation4131. intro H. specialize (H F3_2 F3_0). unfold magma_op, refa74_inst, refa74_op in H. discriminate H. Qed.

Lemma refa74_not4158 : ~ @Equation4158 Fin3 refa74_inst.
Proof. unfold Equation4158. intro H. specialize (H F3_2 F3_0). unfold magma_op, refa74_inst, refa74_op in H. discriminate H. Qed.

Lemma refa74_not4268 : ~ @Equation4268 Fin3 refa74_inst.
Proof. unfold Equation4268. intro H. specialize (H F3_2 F3_0). unfold magma_op, refa74_inst, refa74_op in H. discriminate H. Qed.

Lemma refa74_not4275 : ~ @Equation4275 Fin3 refa74_inst.
Proof. unfold Equation4275. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa74_inst, refa74_op in H. discriminate H. Qed.

Lemma refa74_not4283 : ~ @Equation4283 Fin3 refa74_inst.
Proof. unfold Equation4283. intro H. specialize (H F3_2 F3_0). unfold magma_op, refa74_inst, refa74_op in H. discriminate H. Qed.

Lemma refa74_not4284 : ~ @Equation4284 Fin3 refa74_inst.
Proof. unfold Equation4284. intro H. specialize (H F3_2 F3_0). unfold magma_op, refa74_inst, refa74_op in H. discriminate H. Qed.

Lemma refa74_not4290 : ~ @Equation4290 Fin3 refa74_inst.
Proof. unfold Equation4290. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa74_inst, refa74_op in H. discriminate H. Qed.

Lemma refa74_not4293 : ~ @Equation4293 Fin3 refa74_inst.
Proof. unfold Equation4293. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa74_inst, refa74_op in H. discriminate H. Qed.

Lemma refa74_not4300 : ~ @Equation4300 Fin3 refa74_inst.
Proof. unfold Equation4300. intro H. specialize (H F3_0 F3_0 F3_2). unfold magma_op, refa74_inst, refa74_op in H. discriminate H. Qed.

Lemma refa74_not4380 : ~ @Equation4380 Fin3 refa74_inst.
Proof. unfold Equation4380. intro H. specialize (H F3_2). unfold magma_op, refa74_inst, refa74_op in H. discriminate H. Qed.

Lemma refa74_not4635 : ~ @Equation4635 Fin3 refa74_inst.
Proof. unfold Equation4635. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa74_inst, refa74_op in H. discriminate H. Qed.

Lemma refa74_not4673 : ~ @Equation4673 Fin3 refa74_inst.
Proof. unfold Equation4673. intro H. specialize (H F3_2 F3_0 F3_1). unfold magma_op, refa74_inst, refa74_op in H. discriminate H. Qed.

(** ---- refa740 (Fin5) ---- *)

Definition refa740_op (x y : Fin5) : Fin5 :=
  match x, y with
  | F5_0, F5_0 => F5_0 | F5_0, F5_1 => F5_0 | F5_0, F5_2 => F5_4 | F5_0, F5_3 => F5_0 | F5_0, F5_4 => F5_0
  | F5_1, F5_0 => F5_2 | F5_1, F5_1 => F5_2 | F5_1, F5_2 => F5_2 | F5_1, F5_3 => F5_2 | F5_1, F5_4 => F5_2
  | F5_2, F5_0 => F5_3 | F5_2, F5_1 => F5_3 | F5_2, F5_2 => F5_3 | F5_2, F5_3 => F5_3 | F5_2, F5_4 => F5_3
  | F5_3, F5_0 => F5_1 | F5_3, F5_1 => F5_1 | F5_3, F5_2 => F5_1 | F5_3, F5_3 => F5_1 | F5_3, F5_4 => F5_1
  | F5_4, F5_0 => F5_4 | F5_4, F5_1 => F5_4 | F5_4, F5_2 => F5_0 | F5_4, F5_3 => F5_4 | F5_4, F5_4 => F5_4
  end.

#[local] Instance refa740_inst : Magma Fin5 := {| magma_op := refa740_op |}.

Lemma refa740_sat2666 : @Equation2666 Fin5 refa740_inst.
Proof. unfold Equation2666, magma_op, refa740_inst, refa740_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa740_not2044 : ~ @Equation2044 Fin5 refa740_inst.
Proof. unfold Equation2044. intro H. specialize (H F5_0 F5_1). unfold magma_op, refa740_inst, refa740_op in H. discriminate H. Qed.

Lemma refa740_not2053 : ~ @Equation2053 Fin5 refa740_inst.
Proof. unfold Equation2053. intro H. specialize (H F5_0 F5_1). unfold magma_op, refa740_inst, refa740_op in H. discriminate H. Qed.

Lemma refa740_not2054 : ~ @Equation2054 Fin5 refa740_inst.
Proof. unfold Equation2054. intro H. specialize (H F5_0 F5_1). unfold magma_op, refa740_inst, refa740_op in H. discriminate H. Qed.

Lemma refa740_not2672 : ~ @Equation2672 Fin5 refa740_inst.
Proof. unfold Equation2672. intro H. specialize (H F5_0 F5_1). unfold magma_op, refa740_inst, refa740_op in H. discriminate H. Qed.

Lemma refa740_not2863 : ~ @Equation2863 Fin5 refa740_inst.
Proof. unfold Equation2863. intro H. specialize (H F5_0 F5_1). unfold magma_op, refa740_inst, refa740_op in H. discriminate H. Qed.

Lemma refa740_not2873 : ~ @Equation2873 Fin5 refa740_inst.
Proof. unfold Equation2873. intro H. specialize (H F5_0 F5_1). unfold magma_op, refa740_inst, refa740_op in H. discriminate H. Qed.

Lemma refa740_not2875 : ~ @Equation2875 Fin5 refa740_inst.
Proof. unfold Equation2875. intro H. specialize (H F5_0 F5_1). unfold magma_op, refa740_inst, refa740_op in H. discriminate H. Qed.

Lemma refa740_not3318 : ~ @Equation3318 Fin5 refa740_inst.
Proof. unfold Equation3318. intro H. specialize (H F5_0 F5_1). unfold magma_op, refa740_inst, refa740_op in H. discriminate H. Qed.

Lemma refa740_not3319 : ~ @Equation3319 Fin5 refa740_inst.
Proof. unfold Equation3319. intro H. specialize (H F5_0 F5_1). unfold magma_op, refa740_inst, refa740_op in H. discriminate H. Qed.

Lemma refa740_not3518 : ~ @Equation3518 Fin5 refa740_inst.
Proof. unfold Equation3518. intro H. specialize (H F5_0 F5_2). unfold magma_op, refa740_inst, refa740_op in H. discriminate H. Qed.

Lemma refa740_not3522 : ~ @Equation3522 Fin5 refa740_inst.
Proof. unfold Equation3522. intro H. specialize (H F5_0 F5_2). unfold magma_op, refa740_inst, refa740_op in H. discriminate H. Qed.

(** ---- refa741 (Fin5) ---- *)

Definition refa741_op (x y : Fin5) : Fin5 :=
  match x, y with
  | F5_0, F5_0 => F5_0 | F5_0, F5_1 => F5_3 | F5_0, F5_2 => F5_0 | F5_0, F5_3 => F5_0 | F5_0, F5_4 => F5_0
  | F5_1, F5_0 => F5_1 | F5_1, F5_1 => F5_1 | F5_1, F5_2 => F5_1 | F5_1, F5_3 => F5_2 | F5_1, F5_4 => F5_1
  | F5_2, F5_0 => F5_2 | F5_2, F5_1 => F5_2 | F5_2, F5_2 => F5_2 | F5_2, F5_3 => F5_1 | F5_2, F5_4 => F5_2
  | F5_3, F5_0 => F5_3 | F5_3, F5_1 => F5_0 | F5_3, F5_2 => F5_4 | F5_3, F5_3 => F5_3 | F5_3, F5_4 => F5_3
  | F5_4, F5_0 => F5_4 | F5_4, F5_1 => F5_4 | F5_4, F5_2 => F5_3 | F5_4, F5_3 => F5_4 | F5_4, F5_4 => F5_4
  end.

#[local] Instance refa741_inst : Magma Fin5 := {| magma_op := refa741_op |}.

Lemma refa741_sat2666 : @Equation2666 Fin5 refa741_inst.
Proof. unfold Equation2666, magma_op, refa741_inst, refa741_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa741_not4673 : ~ @Equation4673 Fin5 refa741_inst.
Proof. unfold Equation4673. intro H. specialize (H F5_0 F5_1 F5_2). unfold magma_op, refa741_inst, refa741_op in H. discriminate H. Qed.

(** ---- refa742 (Fin6) ---- *)

Definition refa742_op (x y : Fin6) : Fin6 :=
  match x, y with
  | F6_0, F6_0 => F6_1 | F6_0, F6_1 => F6_2 | F6_0, F6_2 => F6_2 | F6_0, F6_3 => F6_1 | F6_0, F6_4 => F6_1 | F6_0, F6_5 => F6_1
  | F6_1, F6_0 => F6_5 | F6_1, F6_1 => F6_5 | F6_1, F6_2 => F6_5 | F6_1, F6_3 => F6_5 | F6_1, F6_4 => F6_4 | F6_1, F6_5 => F6_4
  | F6_2, F6_0 => F6_4 | F6_2, F6_1 => F6_4 | F6_2, F6_2 => F6_4 | F6_2, F6_3 => F6_4 | F6_2, F6_4 => F6_5 | F6_2, F6_5 => F6_5
  | F6_3, F6_0 => F6_2 | F6_3, F6_1 => F6_1 | F6_3, F6_2 => F6_1 | F6_3, F6_3 => F6_2 | F6_3, F6_4 => F6_2 | F6_3, F6_5 => F6_2
  | F6_4, F6_0 => F6_3 | F6_4, F6_1 => F6_0 | F6_4, F6_2 => F6_0 | F6_4, F6_3 => F6_3 | F6_4, F6_4 => F6_0 | F6_4, F6_5 => F6_0
  | F6_5, F6_0 => F6_0 | F6_5, F6_1 => F6_3 | F6_5, F6_2 => F6_3 | F6_5, F6_3 => F6_0 | F6_5, F6_4 => F6_3 | F6_5, F6_5 => F6_3
  end.

#[local] Instance refa742_inst : Magma Fin6 := {| magma_op := refa742_op |}.

Lemma refa742_sat2675 : @Equation2675 Fin6 refa742_inst.
Proof. unfold Equation2675, magma_op, refa742_inst, refa742_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa742_not2035 : ~ @Equation2035 Fin6 refa742_inst.
Proof. unfold Equation2035. intro H. specialize (H F6_0). unfold magma_op, refa742_inst, refa742_op in H. discriminate H. Qed.

Lemma refa742_not3253 : ~ @Equation3253 Fin6 refa742_inst.
Proof. unfold Equation3253. intro H. specialize (H F6_0). unfold magma_op, refa742_inst, refa742_op in H. discriminate H. Qed.

(** ---- refa743 (Fin9) ---- *)

Definition refa743_op (x y : Fin9) : Fin9 :=
  match x, y with
  | F9_0, F9_0 => F9_1 | F9_0, F9_1 => F9_8 | F9_0, F9_2 => F9_7 | F9_0, F9_3 => F9_1 | F9_0, F9_4 => F9_1 | F9_0, F9_5 => F9_7 | F9_0, F9_6 => F9_7 | F9_0, F9_7 => F9_8 | F9_0, F9_8 => F9_8
  | F9_1, F9_0 => F9_2 | F9_1, F9_1 => F9_5 | F9_1, F9_2 => F9_6 | F9_1, F9_3 => F9_2 | F9_1, F9_4 => F9_2 | F9_1, F9_5 => F9_6 | F9_1, F9_6 => F9_6 | F9_1, F9_7 => F9_5 | F9_1, F9_8 => F9_5
  | F9_2, F9_0 => F9_3 | F9_2, F9_1 => F9_0 | F9_2, F9_2 => F9_4 | F9_2, F9_3 => F9_3 | F9_2, F9_4 => F9_3 | F9_2, F9_5 => F9_4 | F9_2, F9_6 => F9_4 | F9_2, F9_7 => F9_0 | F9_2, F9_8 => F9_0
  | F9_3, F9_0 => F9_7 | F9_3, F9_1 => F9_1 | F9_3, F9_2 => F9_8 | F9_3, F9_3 => F9_7 | F9_3, F9_4 => F9_7 | F9_3, F9_5 => F9_8 | F9_3, F9_6 => F9_8 | F9_3, F9_7 => F9_1 | F9_3, F9_8 => F9_1
  | F9_4, F9_0 => F9_8 | F9_4, F9_1 => F9_7 | F9_4, F9_2 => F9_1 | F9_4, F9_3 => F9_8 | F9_4, F9_4 => F9_8 | F9_4, F9_5 => F9_1 | F9_4, F9_6 => F9_1 | F9_4, F9_7 => F9_7 | F9_4, F9_8 => F9_7
  | F9_5, F9_0 => F9_0 | F9_5, F9_1 => F9_4 | F9_5, F9_2 => F9_3 | F9_5, F9_3 => F9_0 | F9_5, F9_4 => F9_0 | F9_5, F9_5 => F9_3 | F9_5, F9_6 => F9_3 | F9_5, F9_7 => F9_4 | F9_5, F9_8 => F9_4
  | F9_6, F9_0 => F9_4 | F9_6, F9_1 => F9_3 | F9_6, F9_2 => F9_0 | F9_6, F9_3 => F9_4 | F9_6, F9_4 => F9_4 | F9_6, F9_5 => F9_0 | F9_6, F9_6 => F9_0 | F9_6, F9_7 => F9_3 | F9_6, F9_8 => F9_3
  | F9_7, F9_0 => F9_6 | F9_7, F9_1 => F9_2 | F9_7, F9_2 => F9_5 | F9_7, F9_3 => F9_6 | F9_7, F9_4 => F9_6 | F9_7, F9_5 => F9_5 | F9_7, F9_6 => F9_5 | F9_7, F9_7 => F9_2 | F9_7, F9_8 => F9_2
  | F9_8, F9_0 => F9_5 | F9_8, F9_1 => F9_6 | F9_8, F9_2 => F9_2 | F9_8, F9_3 => F9_5 | F9_8, F9_4 => F9_5 | F9_8, F9_5 => F9_2 | F9_8, F9_6 => F9_2 | F9_8, F9_7 => F9_6 | F9_8, F9_8 => F9_6
  end.

#[local] Instance refa743_inst : Magma Fin9 := {| magma_op := refa743_op |}.

Lemma refa743_sat2065 : @Equation2065 Fin9 refa743_inst.
Proof. unfold Equation2065, magma_op, refa743_inst, refa743_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa743_not255 : ~ @Equation255 Fin9 refa743_inst.
Proof. unfold Equation255. intro H. specialize (H F9_0). unfold magma_op, refa743_inst, refa743_op in H. discriminate H. Qed.

Lemma refa743_not3253 : ~ @Equation3253 Fin9 refa743_inst.
Proof. unfold Equation3253. intro H. specialize (H F9_0). unfold magma_op, refa743_inst, refa743_op in H. discriminate H. Qed.

Lemma refa743_not3456 : ~ @Equation3456 Fin9 refa743_inst.
Proof. unfold Equation3456. intro H. specialize (H F9_0). unfold magma_op, refa743_inst, refa743_op in H. discriminate H. Qed.

Lemma refa743_not4656 : ~ @Equation4656 Fin9 refa743_inst.
Proof. unfold Equation4656. intro H. specialize (H F9_0 F9_0 F9_1). unfold magma_op, refa743_inst, refa743_op in H. discriminate H. Qed.

(** ---- refa744 (Fin5) ---- *)

Definition refa744_op (x y : Fin5) : Fin5 :=
  match x, y with
  | F5_0, F5_0 => F5_2 | F5_0, F5_1 => F5_0 | F5_0, F5_2 => F5_2 | F5_0, F5_3 => F5_2 | F5_0, F5_4 => F5_2
  | F5_1, F5_0 => F5_1 | F5_1, F5_1 => F5_1 | F5_1, F5_2 => F5_1 | F5_1, F5_3 => F5_1 | F5_1, F5_4 => F5_1
  | F5_2, F5_0 => F5_3 | F5_2, F5_1 => F5_3 | F5_2, F5_2 => F5_3 | F5_2, F5_3 => F5_3 | F5_2, F5_4 => F5_3
  | F5_3, F5_0 => F5_0 | F5_3, F5_1 => F5_4 | F5_3, F5_2 => F5_0 | F5_3, F5_3 => F5_0 | F5_3, F5_4 => F5_0
  | F5_4, F5_0 => F5_4 | F5_4, F5_1 => F5_2 | F5_4, F5_2 => F5_4 | F5_4, F5_3 => F5_4 | F5_4, F5_4 => F5_4
  end.

#[local] Instance refa744_inst : Magma Fin5 := {| magma_op := refa744_op |}.

Lemma refa744_sat2065 : @Equation2065 Fin5 refa744_inst.
Proof. unfold Equation2065, magma_op, refa744_inst, refa744_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa744_not4598 : ~ @Equation4598 Fin5 refa744_inst.
Proof. unfold Equation4598. intro H. specialize (H F5_0 F5_1). unfold magma_op, refa744_inst, refa744_op in H. discriminate H. Qed.

(** ---- refa745 (Fin5) ---- *)

Definition refa745_op (x y : Fin5) : Fin5 :=
  match x, y with
  | F5_0, F5_0 => F5_1 | F5_0, F5_1 => F5_2 | F5_0, F5_2 => F5_2 | F5_0, F5_3 => F5_2 | F5_0, F5_4 => F5_2
  | F5_1, F5_0 => F5_4 | F5_1, F5_1 => F5_4 | F5_1, F5_2 => F5_4 | F5_1, F5_3 => F5_4 | F5_1, F5_4 => F5_4
  | F5_2, F5_0 => F5_4 | F5_2, F5_1 => F5_4 | F5_2, F5_2 => F5_4 | F5_2, F5_3 => F5_4 | F5_2, F5_4 => F5_4
  | F5_3, F5_0 => F5_1 | F5_3, F5_1 => F5_1 | F5_3, F5_2 => F5_2 | F5_3, F5_3 => F5_1 | F5_3, F5_4 => F5_1
  | F5_4, F5_0 => F5_0 | F5_4, F5_1 => F5_3 | F5_4, F5_2 => F5_3 | F5_4, F5_3 => F5_3 | F5_4, F5_4 => F5_3
  end.

#[local] Instance refa745_inst : Magma Fin5 := {| magma_op := refa745_op |}.

Lemma refa745_sat2679 : @Equation2679 Fin5 refa745_inst.
Proof. unfold Equation2679, magma_op, refa745_inst, refa745_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa745_not2035 : ~ @Equation2035 Fin5 refa745_inst.
Proof. unfold Equation2035. intro H. specialize (H F5_0). unfold magma_op, refa745_inst, refa745_op in H. discriminate H. Qed.

Lemma refa745_not3253 : ~ @Equation3253 Fin5 refa745_inst.
Proof. unfold Equation3253. intro H. specialize (H F5_0). unfold magma_op, refa745_inst, refa745_op in H. discriminate H. Qed.

Lemma refa745_not3456 : ~ @Equation3456 Fin5 refa745_inst.
Proof. unfold Equation3456. intro H. specialize (H F5_0). unfold magma_op, refa745_inst, refa745_op in H. discriminate H. Qed.

Lemma refa745_not4284 : ~ @Equation4284 Fin5 refa745_inst.
Proof. unfold Equation4284. intro H. specialize (H F5_3 F5_2). unfold magma_op, refa745_inst, refa745_op in H. discriminate H. Qed.

(** ---- refa746 (Fin6) ---- *)

Definition refa746_op (x y : Fin6) : Fin6 :=
  match x, y with
  | F6_0, F6_0 => F6_0 | F6_0, F6_1 => F6_1 | F6_0, F6_2 => F6_0 | F6_0, F6_3 => F6_3 | F6_0, F6_4 => F6_4 | F6_0, F6_5 => F6_5
  | F6_1, F6_0 => F6_2 | F6_1, F6_1 => F6_5 | F6_1, F6_2 => F6_2 | F6_1, F6_3 => F6_5 | F6_1, F6_4 => F6_5 | F6_1, F6_5 => F6_5
  | F6_2, F6_0 => F6_2 | F6_2, F6_1 => F6_1 | F6_2, F6_2 => F6_2 | F6_2, F6_3 => F6_3 | F6_2, F6_4 => F6_4 | F6_2, F6_5 => F6_5
  | F6_3, F6_0 => F6_0 | F6_3, F6_1 => F6_1 | F6_3, F6_2 => F6_2 | F6_3, F6_3 => F6_4 | F6_3, F6_4 => F6_4 | F6_3, F6_5 => F6_4
  | F6_4, F6_0 => F6_0 | F6_4, F6_1 => F6_5 | F6_4, F6_2 => F6_2 | F6_4, F6_3 => F6_5 | F6_4, F6_4 => F6_5 | F6_4, F6_5 => F6_5
  | F6_5, F6_0 => F6_0 | F6_5, F6_1 => F6_3 | F6_5, F6_2 => F6_2 | F6_5, F6_3 => F6_3 | F6_5, F6_4 => F6_3 | F6_5, F6_5 => F6_3
  end.

#[local] Instance refa746_inst : Magma Fin6 := {| magma_op := refa746_op |}.

Lemma refa746_sat2683 : @Equation2683 Fin6 refa746_inst.
Proof. unfold Equation2683, magma_op, refa746_inst, refa746_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa746_not2035 : ~ @Equation2035 Fin6 refa746_inst.
Proof. unfold Equation2035. intro H. specialize (H F6_1). unfold magma_op, refa746_inst, refa746_op in H. discriminate H. Qed.

Lemma refa746_not2646 : ~ @Equation2646 Fin6 refa746_inst.
Proof. unfold Equation2646. intro H. specialize (H F6_0 F6_1). unfold magma_op, refa746_inst, refa746_op in H. discriminate H. Qed.

Lemma refa746_not2659 : ~ @Equation2659 Fin6 refa746_inst.
Proof. unfold Equation2659. intro H. specialize (H F6_0 F6_1). unfold magma_op, refa746_inst, refa746_op in H. discriminate H. Qed.

Lemma refa746_not2669 : ~ @Equation2669 Fin6 refa746_inst.
Proof. unfold Equation2669. intro H. specialize (H F6_0 F6_1). unfold magma_op, refa746_inst, refa746_op in H. discriminate H. Qed.

Lemma refa746_not2849 : ~ @Equation2849 Fin6 refa746_inst.
Proof. unfold Equation2849. intro H. specialize (H F6_0 F6_1). unfold magma_op, refa746_inst, refa746_op in H. discriminate H. Qed.

Lemma refa746_not2852 : ~ @Equation2852 Fin6 refa746_inst.
Proof. unfold Equation2852. intro H. specialize (H F6_0 F6_1). unfold magma_op, refa746_inst, refa746_op in H. discriminate H. Qed.

Lemma refa746_not2865 : ~ @Equation2865 Fin6 refa746_inst.
Proof. unfold Equation2865. intro H. specialize (H F6_0 F6_1). unfold magma_op, refa746_inst, refa746_op in H. discriminate H. Qed.

Lemma refa746_not2872 : ~ @Equation2872 Fin6 refa746_inst.
Proof. unfold Equation2872. intro H. specialize (H F6_1 F6_0). unfold magma_op, refa746_inst, refa746_op in H. discriminate H. Qed.

Lemma refa746_not2890 : ~ @Equation2890 Fin6 refa746_inst.
Proof. unfold Equation2890. intro H. specialize (H F6_0 F6_5 F6_1). unfold magma_op, refa746_inst, refa746_op in H. discriminate H. Qed.

Lemma refa746_not3309 : ~ @Equation3309 Fin6 refa746_inst.
Proof. unfold Equation3309. intro H. specialize (H F6_0 F6_1). unfold magma_op, refa746_inst, refa746_op in H. discriminate H. Qed.

Lemma refa746_not3316 : ~ @Equation3316 Fin6 refa746_inst.
Proof. unfold Equation3316. intro H. specialize (H F6_0 F6_1). unfold magma_op, refa746_inst, refa746_op in H. discriminate H. Qed.

Lemma refa746_not3319 : ~ @Equation3319 Fin6 refa746_inst.
Proof. unfold Equation3319. intro H. specialize (H F6_0 F6_1). unfold magma_op, refa746_inst, refa746_op in H. discriminate H. Qed.

Lemma refa746_not3509 : ~ @Equation3509 Fin6 refa746_inst.
Proof. unfold Equation3509. intro H. specialize (H F6_3 F6_1). unfold magma_op, refa746_inst, refa746_op in H. discriminate H. Qed.

Lemma refa746_not3519 : ~ @Equation3519 Fin6 refa746_inst.
Proof. unfold Equation3519. intro H. specialize (H F6_3 F6_1). unfold magma_op, refa746_inst, refa746_op in H. discriminate H. Qed.

Lemma refa746_not3522 : ~ @Equation3522 Fin6 refa746_inst.
Proof. unfold Equation3522. intro H. specialize (H F6_0 F6_1). unfold magma_op, refa746_inst, refa746_op in H. discriminate H. Qed.

Lemma refa746_not4284 : ~ @Equation4284 Fin6 refa746_inst.
Proof. unfold Equation4284. intro H. specialize (H F6_0 F6_1). unfold magma_op, refa746_inst, refa746_op in H. discriminate H. Qed.

Lemma refa746_not4631 : ~ @Equation4631 Fin6 refa746_inst.
Proof. unfold Equation4631. intro H. specialize (H F6_0 F6_0 F6_1). unfold magma_op, refa746_inst, refa746_op in H. discriminate H. Qed.

(** ---- refa747 (Fin6) ---- *)

Definition refa747_op (x y : Fin6) : Fin6 :=
  match x, y with
  | F6_0, F6_0 => F6_2 | F6_0, F6_1 => F6_3 | F6_0, F6_2 => F6_2 | F6_0, F6_3 => F6_3 | F6_0, F6_4 => F6_2 | F6_0, F6_5 => F6_2
  | F6_1, F6_0 => F6_2 | F6_1, F6_1 => F6_1 | F6_1, F6_2 => F6_2 | F6_1, F6_3 => F6_1 | F6_1, F6_4 => F6_4 | F6_1, F6_5 => F6_5
  | F6_2, F6_0 => F6_5 | F6_2, F6_1 => F6_1 | F6_2, F6_2 => F6_5 | F6_2, F6_3 => F6_3 | F6_2, F6_4 => F6_5 | F6_2, F6_5 => F6_5
  | F6_3, F6_0 => F6_0 | F6_3, F6_1 => F6_3 | F6_3, F6_2 => F6_2 | F6_3, F6_3 => F6_3 | F6_3, F6_4 => F6_4 | F6_3, F6_5 => F6_5
  | F6_4, F6_0 => F6_2 | F6_4, F6_1 => F6_1 | F6_4, F6_2 => F6_2 | F6_4, F6_3 => F6_3 | F6_4, F6_4 => F6_2 | F6_4, F6_5 => F6_2
  | F6_5, F6_0 => F6_0 | F6_5, F6_1 => F6_1 | F6_5, F6_2 => F6_4 | F6_5, F6_3 => F6_3 | F6_5, F6_4 => F6_4 | F6_5, F6_5 => F6_4
  end.

#[local] Instance refa747_inst : Magma Fin6 := {| magma_op := refa747_op |}.

Lemma refa747_sat2683 : @Equation2683 Fin6 refa747_inst.
Proof. unfold Equation2683, magma_op, refa747_inst, refa747_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa747_not2652 : ~ @Equation2652 Fin6 refa747_inst.
Proof. unfold Equation2652. intro H. specialize (H F6_0 F6_1). unfold magma_op, refa747_inst, refa747_op in H. discriminate H. Qed.

(** ---- refa748 (Fin6) ---- *)

Definition refa748_op (x y : Fin6) : Fin6 :=
  match x, y with
  | F6_0, F6_0 => F6_0 | F6_0, F6_1 => F6_1 | F6_0, F6_2 => F6_0 | F6_0, F6_3 => F6_3 | F6_0, F6_4 => F6_4 | F6_0, F6_5 => F6_5
  | F6_1, F6_0 => F6_2 | F6_1, F6_1 => F6_4 | F6_1, F6_2 => F6_0 | F6_1, F6_3 => F6_4 | F6_1, F6_4 => F6_4 | F6_1, F6_5 => F6_4
  | F6_2, F6_0 => F6_2 | F6_2, F6_1 => F6_1 | F6_2, F6_2 => F6_2 | F6_2, F6_3 => F6_3 | F6_2, F6_4 => F6_4 | F6_2, F6_5 => F6_5
  | F6_3, F6_0 => F6_0 | F6_3, F6_1 => F6_1 | F6_3, F6_2 => F6_2 | F6_3, F6_3 => F6_5 | F6_3, F6_4 => F6_5 | F6_3, F6_5 => F6_5
  | F6_4, F6_0 => F6_0 | F6_4, F6_1 => F6_3 | F6_4, F6_2 => F6_2 | F6_4, F6_3 => F6_3 | F6_4, F6_4 => F6_3 | F6_4, F6_5 => F6_3
  | F6_5, F6_0 => F6_0 | F6_5, F6_1 => F6_4 | F6_5, F6_2 => F6_2 | F6_5, F6_3 => F6_4 | F6_5, F6_4 => F6_4 | F6_5, F6_5 => F6_4
  end.

#[local] Instance refa748_inst : Magma Fin6 := {| magma_op := refa748_op |}.

Lemma refa748_sat2683 : @Equation2683 Fin6 refa748_inst.
Proof. unfold Equation2683, magma_op, refa748_inst, refa748_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa748_not323 : ~ @Equation323 Fin6 refa748_inst.
Proof. unfold Equation323. intro H. specialize (H F6_1 F6_0). unfold magma_op, refa748_inst, refa748_op in H. discriminate H. Qed.

(** ---- refa749 (Fin7) ---- *)

Definition refa749_op (x y : Fin7) : Fin7 :=
  match x, y with
  | F7_0, F7_0 => F7_5 | F7_0, F7_1 => F7_2 | F7_0, F7_2 => F7_3 | F7_0, F7_3 => F7_3 | F7_0, F7_4 => F7_5 | F7_0, F7_5 => F7_5 | F7_0, F7_6 => F7_5
  | F7_1, F7_0 => F7_4 | F7_1, F7_1 => F7_1 | F7_1, F7_2 => F7_3 | F7_1, F7_3 => F7_3 | F7_1, F7_4 => F7_4 | F7_1, F7_5 => F7_5 | F7_1, F7_6 => F7_6
  | F7_2, F7_0 => F7_0 | F7_2, F7_1 => F7_2 | F7_2, F7_2 => F7_2 | F7_2, F7_3 => F7_2 | F7_2, F7_4 => F7_4 | F7_2, F7_5 => F7_5 | F7_2, F7_6 => F7_6
  | F7_3, F7_0 => F7_0 | F7_3, F7_1 => F7_1 | F7_3, F7_2 => F7_3 | F7_3, F7_3 => F7_3 | F7_3, F7_4 => F7_4 | F7_3, F7_5 => F7_5 | F7_3, F7_6 => F7_6
  | F7_4, F7_0 => F7_5 | F7_4, F7_1 => F7_1 | F7_4, F7_2 => F7_2 | F7_4, F7_3 => F7_3 | F7_4, F7_4 => F7_5 | F7_4, F7_5 => F7_5 | F7_4, F7_6 => F7_5
  | F7_5, F7_0 => F7_6 | F7_5, F7_1 => F7_1 | F7_5, F7_2 => F7_2 | F7_5, F7_3 => F7_3 | F7_5, F7_4 => F7_6 | F7_5, F7_5 => F7_6 | F7_5, F7_6 => F7_6
  | F7_6, F7_0 => F7_0 | F7_6, F7_1 => F7_1 | F7_6, F7_2 => F7_2 | F7_6, F7_3 => F7_3 | F7_6, F7_4 => F7_4 | F7_6, F7_5 => F7_4 | F7_6, F7_6 => F7_4
  end.

#[local] Instance refa749_inst : Magma Fin7 := {| magma_op := refa749_op |}.

Lemma refa749_sat2683 : @Equation2683 Fin7 refa749_inst.
Proof. unfold Equation2683, magma_op, refa749_inst, refa749_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa749_not2855 : ~ @Equation2855 Fin7 refa749_inst.
Proof. unfold Equation2855. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa749_inst, refa749_op in H. discriminate H. Qed.

Lemma refa749_not3306 : ~ @Equation3306 Fin7 refa749_inst.
Proof. unfold Equation3306. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa749_inst, refa749_op in H. discriminate H. Qed.

(** ---- refa75 (Fin3) ---- *)

Definition refa75_op (x y : Fin3) : Fin3 :=
  match x, y with
  | F3_0, F3_0 => F3_0 | F3_0, F3_1 => F3_0 | F3_0, F3_2 => F3_1
  | F3_1, F3_0 => F3_1 | F3_1, F3_1 => F3_2 | F3_1, F3_2 => F3_0
  | F3_2, F3_0 => F3_2 | F3_2, F3_1 => F3_2 | F3_2, F3_2 => F3_1
  end.

#[local] Instance refa75_inst : Magma Fin3 := {| magma_op := refa75_op |}.

Lemma refa75_sat159 : @Equation159 Fin3 refa75_inst.
Proof. unfold Equation159, magma_op, refa75_inst, refa75_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa75_sat1850 : @Equation1850 Fin3 refa75_inst.
Proof. unfold Equation1850, magma_op, refa75_inst, refa75_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa75_not1629 : ~ @Equation1629 Fin3 refa75_inst.
Proof. unfold Equation1629. intro H. specialize (H F3_2). unfold magma_op, refa75_inst, refa75_op in H. discriminate H. Qed.

Lemma refa75_not3253 : ~ @Equation3253 Fin3 refa75_inst.
Proof. unfold Equation3253. intro H. specialize (H F3_1). unfold magma_op, refa75_inst, refa75_op in H. discriminate H. Qed.

Lemma refa75_not3862 : ~ @Equation3862 Fin3 refa75_inst.
Proof. unfold Equation3862. intro H. specialize (H F3_1). unfold magma_op, refa75_inst, refa75_op in H. discriminate H. Qed.

(** ---- refa750 (Fin5) ---- *)

Definition refa750_op (x y : Fin5) : Fin5 :=
  match x, y with
  | F5_0, F5_0 => F5_3 | F5_0, F5_1 => F5_2 | F5_0, F5_2 => F5_2 | F5_0, F5_3 => F5_3 | F5_0, F5_4 => F5_3
  | F5_1, F5_0 => F5_1 | F5_1, F5_1 => F5_1 | F5_1, F5_2 => F5_1 | F5_1, F5_3 => F5_1 | F5_1, F5_4 => F5_1
  | F5_2, F5_0 => F5_0 | F5_2, F5_1 => F5_2 | F5_2, F5_2 => F5_2 | F5_2, F5_3 => F5_3 | F5_2, F5_4 => F5_4
  | F5_3, F5_0 => F5_4 | F5_3, F5_1 => F5_2 | F5_3, F5_2 => F5_2 | F5_3, F5_3 => F5_4 | F5_3, F5_4 => F5_4
  | F5_4, F5_0 => F5_0 | F5_4, F5_1 => F5_2 | F5_4, F5_2 => F5_2 | F5_4, F5_3 => F5_0 | F5_4, F5_4 => F5_0
  end.

#[local] Instance refa750_inst : Magma Fin5 := {| magma_op := refa750_op |}.

Lemma refa750_sat2683 : @Equation2683 Fin5 refa750_inst.
Proof. unfold Equation2683, magma_op, refa750_inst, refa750_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa750_not2862 : ~ @Equation2862 Fin5 refa750_inst.
Proof. unfold Equation2862. intro H. specialize (H F5_0 F5_1). unfold magma_op, refa750_inst, refa750_op in H. discriminate H. Qed.

(** ---- refa751 (Fin6) ---- *)

Definition refa751_op (x y : Fin6) : Fin6 :=
  match x, y with
  | F6_0, F6_0 => F6_3 | F6_0, F6_1 => F6_3 | F6_0, F6_2 => F6_2 | F6_0, F6_3 => F6_3 | F6_0, F6_4 => F6_3 | F6_0, F6_5 => F6_3
  | F6_1, F6_0 => F6_0 | F6_1, F6_1 => F6_2 | F6_1, F6_2 => F6_2 | F6_1, F6_3 => F6_2 | F6_1, F6_4 => F6_2 | F6_1, F6_5 => F6_2
  | F6_2, F6_0 => F6_4 | F6_2, F6_1 => F6_3 | F6_2, F6_2 => F6_4 | F6_2, F6_3 => F6_3 | F6_2, F6_4 => F6_4 | F6_2, F6_5 => F6_4
  | F6_3, F6_0 => F6_1 | F6_3, F6_1 => F6_1 | F6_3, F6_2 => F6_5 | F6_3, F6_3 => F6_1 | F6_3, F6_4 => F6_4 | F6_3, F6_5 => F6_5
  | F6_4, F6_0 => F6_0 | F6_4, F6_1 => F6_1 | F6_4, F6_2 => F6_0 | F6_4, F6_3 => F6_0 | F6_4, F6_4 => F6_0 | F6_4, F6_5 => F6_5
  | F6_5, F6_0 => F6_0 | F6_5, F6_1 => F6_2 | F6_5, F6_2 => F6_2 | F6_5, F6_3 => F6_2 | F6_5, F6_4 => F6_2 | F6_5, F6_5 => F6_2
  end.

#[local] Instance refa751_inst : Magma Fin6 := {| magma_op := refa751_op |}.

Lemma refa751_sat2683 : @Equation2683 Fin6 refa751_inst.
Proof. unfold Equation2683, magma_op, refa751_inst, refa751_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa751_not2875 : ~ @Equation2875 Fin6 refa751_inst.
Proof. unfold Equation2875. intro H. specialize (H F6_0 F6_1). unfold magma_op, refa751_inst, refa751_op in H. discriminate H. Qed.

Lemma refa751_not3456 : ~ @Equation3456 Fin6 refa751_inst.
Proof. unfold Equation3456. intro H. specialize (H F6_3). unfold magma_op, refa751_inst, refa751_op in H. discriminate H. Qed.

(** ---- refa752 (Fin6) ---- *)

Definition refa752_op (x y : Fin6) : Fin6 :=
  match x, y with
  | F6_0, F6_0 => F6_1 | F6_0, F6_1 => F6_2 | F6_0, F6_2 => F6_3 | F6_0, F6_3 => F6_2 | F6_0, F6_4 => F6_5 | F6_0, F6_5 => F6_2
  | F6_1, F6_0 => F6_4 | F6_1, F6_1 => F6_3 | F6_1, F6_2 => F6_2 | F6_1, F6_3 => F6_3 | F6_1, F6_4 => F6_0 | F6_1, F6_5 => F6_3
  | F6_2, F6_0 => F6_3 | F6_2, F6_1 => F6_4 | F6_2, F6_2 => F6_5 | F6_2, F6_3 => F6_4 | F6_2, F6_4 => F6_1 | F6_2, F6_5 => F6_4
  | F6_3, F6_0 => F6_0 | F6_3, F6_1 => F6_5 | F6_3, F6_2 => F6_4 | F6_3, F6_3 => F6_5 | F6_3, F6_4 => F6_2 | F6_3, F6_5 => F6_5
  | F6_4, F6_0 => F6_5 | F6_4, F6_1 => F6_0 | F6_4, F6_2 => F6_1 | F6_4, F6_3 => F6_0 | F6_4, F6_4 => F6_3 | F6_4, F6_5 => F6_0
  | F6_5, F6_0 => F6_2 | F6_5, F6_1 => F6_1 | F6_5, F6_2 => F6_0 | F6_5, F6_3 => F6_1 | F6_5, F6_4 => F6_4 | F6_5, F6_5 => F6_1
  end.

#[local] Instance refa752_inst : Magma Fin6 := {| magma_op := refa752_op |}.

Lemma refa752_sat2880 : @Equation2880 Fin6 refa752_inst.
Proof. unfold Equation2880, magma_op, refa752_inst, refa752_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa752_not3253 : ~ @Equation3253 Fin6 refa752_inst.
Proof. unfold Equation3253. intro H. specialize (H F6_0). unfold magma_op, refa752_inst, refa752_op in H. discriminate H. Qed.

Lemma refa752_not3456 : ~ @Equation3456 Fin6 refa752_inst.
Proof. unfold Equation3456. intro H. specialize (H F6_0). unfold magma_op, refa752_inst, refa752_op in H. discriminate H. Qed.

(** ---- refa753 (Fin5) ---- *)

Definition refa753_op (x y : Fin5) : Fin5 :=
  match x, y with
  | F5_0, F5_0 => F5_3 | F5_0, F5_1 => F5_1 | F5_0, F5_2 => F5_3 | F5_0, F5_3 => F5_3 | F5_0, F5_4 => F5_3
  | F5_1, F5_0 => F5_2 | F5_1, F5_1 => F5_4 | F5_1, F5_2 => F5_2 | F5_1, F5_3 => F5_4 | F5_1, F5_4 => F5_4
  | F5_2, F5_0 => F5_0 | F5_2, F5_1 => F5_0 | F5_2, F5_2 => F5_0 | F5_2, F5_3 => F5_0 | F5_2, F5_4 => F5_0
  | F5_3, F5_0 => F5_4 | F5_3, F5_1 => F5_4 | F5_3, F5_2 => F5_2 | F5_3, F5_3 => F5_2 | F5_3, F5_4 => F5_4
  | F5_4, F5_0 => F5_0 | F5_4, F5_1 => F5_0 | F5_4, F5_2 => F5_0 | F5_4, F5_3 => F5_0 | F5_4, F5_4 => F5_0
  end.

#[local] Instance refa753_inst : Magma Fin5 := {| magma_op := refa753_op |}.

Lemma refa753_sat266 : @Equation266 Fin5 refa753_inst.
Proof. unfold Equation266, magma_op, refa753_inst, refa753_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa753_not4584 : ~ @Equation4584 Fin5 refa753_inst.
Proof. unfold Equation4584. intro H. specialize (H F5_0 F5_1). unfold magma_op, refa753_inst, refa753_op in H. discriminate H. Qed.

(** ---- refa754 (Fin6) ---- *)

Definition refa754_op (x y : Fin6) : Fin6 :=
  match x, y with
  | F6_0, F6_0 => F6_1 | F6_0, F6_1 => F6_2 | F6_0, F6_2 => F6_2 | F6_0, F6_3 => F6_3 | F6_0, F6_4 => F6_1 | F6_0, F6_5 => F6_5
  | F6_1, F6_0 => F6_2 | F6_1, F6_1 => F6_2 | F6_1, F6_2 => F6_3 | F6_1, F6_3 => F6_3 | F6_1, F6_4 => F6_4 | F6_1, F6_5 => F6_5
  | F6_2, F6_0 => F6_0 | F6_2, F6_1 => F6_3 | F6_2, F6_2 => F6_5 | F6_2, F6_3 => F6_5 | F6_2, F6_4 => F6_4 | F6_2, F6_5 => F6_5
  | F6_3, F6_0 => F6_0 | F6_3, F6_1 => F6_1 | F6_3, F6_2 => F6_5 | F6_3, F6_3 => F6_5 | F6_3, F6_4 => F6_4 | F6_3, F6_5 => F6_4
  | F6_4, F6_0 => F6_1 | F6_4, F6_1 => F6_1 | F6_4, F6_2 => F6_2 | F6_4, F6_3 => F6_3 | F6_4, F6_4 => F6_1 | F6_4, F6_5 => F6_0
  | F6_5, F6_0 => F6_0 | F6_5, F6_1 => F6_1 | F6_5, F6_2 => F6_2 | F6_5, F6_3 => F6_4 | F6_5, F6_4 => F6_0 | F6_5, F6_5 => F6_0
  end.

#[local] Instance refa754_inst : Magma Fin6 := {| magma_op := refa754_op |}.

Lemma refa754_sat2702 : @Equation2702 Fin6 refa754_inst.
Proof. unfold Equation2702, magma_op, refa754_inst, refa754_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa754_not211 : ~ @Equation211 Fin6 refa754_inst.
Proof. unfold Equation211. intro H. specialize (H F6_0 F6_5). unfold magma_op, refa754_inst, refa754_op in H. discriminate H. Qed.

Lemma refa754_not221 : ~ @Equation221 Fin6 refa754_inst.
Proof. unfold Equation221. intro H. specialize (H F6_0 F6_4). unfold magma_op, refa754_inst, refa754_op in H. discriminate H. Qed.

Lemma refa754_not231 : ~ @Equation231 Fin6 refa754_inst.
Proof. unfold Equation231. intro H. specialize (H F6_0 F6_3). unfold magma_op, refa754_inst, refa754_op in H. discriminate H. Qed.

Lemma refa754_not1629 : ~ @Equation1629 Fin6 refa754_inst.
Proof. unfold Equation1629. intro H. specialize (H F6_0). unfold magma_op, refa754_inst, refa754_op in H. discriminate H. Qed.

Lemma refa754_not2256 : ~ @Equation2256 Fin6 refa754_inst.
Proof. unfold Equation2256. intro H. specialize (H F6_0 F6_5). unfold magma_op, refa754_inst, refa754_op in H. discriminate H. Qed.

Lemma refa754_not2266 : ~ @Equation2266 Fin6 refa754_inst.
Proof. unfold Equation2266. intro H. specialize (H F6_0 F6_3). unfold magma_op, refa754_inst, refa754_op in H. discriminate H. Qed.

Lemma refa754_not2293 : ~ @Equation2293 Fin6 refa754_inst.
Proof. unfold Equation2293. intro H. specialize (H F6_0 F6_5). unfold magma_op, refa754_inst, refa754_op in H. discriminate H. Qed.

Lemma refa754_not2300 : ~ @Equation2300 Fin6 refa754_inst.
Proof. unfold Equation2300. intro H. specialize (H F6_0 F6_3). unfold magma_op, refa754_inst, refa754_op in H. discriminate H. Qed.

Lemma refa754_not2303 : ~ @Equation2303 Fin6 refa754_inst.
Proof. unfold Equation2303. intro H. specialize (H F6_0 F6_3). unfold magma_op, refa754_inst, refa754_op in H. discriminate H. Qed.

Lemma refa754_not2330 : ~ @Equation2330 Fin6 refa754_inst.
Proof. unfold Equation2330. intro H. specialize (H F6_0 F6_3). unfold magma_op, refa754_inst, refa754_op in H. discriminate H. Qed.

Lemma refa754_not2340 : ~ @Equation2340 Fin6 refa754_inst.
Proof. unfold Equation2340. intro H. specialize (H F6_0 F6_3). unfold magma_op, refa754_inst, refa754_op in H. discriminate H. Qed.

Lemma refa754_not2443 : ~ @Equation2443 Fin6 refa754_inst.
Proof. unfold Equation2443. intro H. specialize (H F6_0 F6_4). unfold magma_op, refa754_inst, refa754_op in H. discriminate H. Qed.

Lemma refa754_not2449 : ~ @Equation2449 Fin6 refa754_inst.
Proof. unfold Equation2449. intro H. specialize (H F6_0 F6_4). unfold magma_op, refa754_inst, refa754_op in H. discriminate H. Qed.

Lemma refa754_not2456 : ~ @Equation2456 Fin6 refa754_inst.
Proof. unfold Equation2456. intro H. specialize (H F6_0 F6_1). unfold magma_op, refa754_inst, refa754_op in H. discriminate H. Qed.

Lemma refa754_not2459 : ~ @Equation2459 Fin6 refa754_inst.
Proof. unfold Equation2459. intro H. specialize (H F6_0 F6_4). unfold magma_op, refa754_inst, refa754_op in H. discriminate H. Qed.

Lemma refa754_not2466 : ~ @Equation2466 Fin6 refa754_inst.
Proof. unfold Equation2466. intro H. specialize (H F6_0 F6_1). unfold magma_op, refa754_inst, refa754_op in H. discriminate H. Qed.

Lemma refa754_not2469 : ~ @Equation2469 Fin6 refa754_inst.
Proof. unfold Equation2469. intro H. specialize (H F6_0 F6_3). unfold magma_op, refa754_inst, refa754_op in H. discriminate H. Qed.

Lemma refa754_not2496 : ~ @Equation2496 Fin6 refa754_inst.
Proof. unfold Equation2496. intro H. specialize (H F6_0 F6_4). unfold magma_op, refa754_inst, refa754_op in H. discriminate H. Qed.

Lemma refa754_not2506 : ~ @Equation2506 Fin6 refa754_inst.
Proof. unfold Equation2506. intro H. specialize (H F6_0 F6_3). unfold magma_op, refa754_inst, refa754_op in H. discriminate H. Qed.

Lemma refa754_not2530 : ~ @Equation2530 Fin6 refa754_inst.
Proof. unfold Equation2530. intro H. specialize (H F6_0 F6_3). unfold magma_op, refa754_inst, refa754_op in H. discriminate H. Qed.

Lemma refa754_not2533 : ~ @Equation2533 Fin6 refa754_inst.
Proof. unfold Equation2533. intro H. specialize (H F6_0 F6_4). unfold magma_op, refa754_inst, refa754_op in H. discriminate H. Qed.

Lemma refa754_not2543 : ~ @Equation2543 Fin6 refa754_inst.
Proof. unfold Equation2543. intro H. specialize (H F6_0 F6_3). unfold magma_op, refa754_inst, refa754_op in H. discriminate H. Qed.

Lemma refa754_not2652 : ~ @Equation2652 Fin6 refa754_inst.
Proof. unfold Equation2652. intro H. specialize (H F6_1 F6_5). unfold magma_op, refa754_inst, refa754_op in H. discriminate H. Qed.

Lemma refa754_not2659 : ~ @Equation2659 Fin6 refa754_inst.
Proof. unfold Equation2659. intro H. specialize (H F6_0 F6_3). unfold magma_op, refa754_inst, refa754_op in H. discriminate H. Qed.

Lemma refa754_not2662 : ~ @Equation2662 Fin6 refa754_inst.
Proof. unfold Equation2662. intro H. specialize (H F6_0 F6_5). unfold magma_op, refa754_inst, refa754_op in H. discriminate H. Qed.

Lemma refa754_not2672 : ~ @Equation2672 Fin6 refa754_inst.
Proof. unfold Equation2672. intro H. specialize (H F6_0 F6_3). unfold magma_op, refa754_inst, refa754_op in H. discriminate H. Qed.

Lemma refa754_not2709 : ~ @Equation2709 Fin6 refa754_inst.
Proof. unfold Equation2709. intro H. specialize (H F6_0 F6_5). unfold magma_op, refa754_inst, refa754_op in H. discriminate H. Qed.

Lemma refa754_not2736 : ~ @Equation2736 Fin6 refa754_inst.
Proof. unfold Equation2736. intro H. specialize (H F6_0 F6_3). unfold magma_op, refa754_inst, refa754_op in H. discriminate H. Qed.

Lemma refa754_not2746 : ~ @Equation2746 Fin6 refa754_inst.
Proof. unfold Equation2746. intro H. specialize (H F6_0 F6_2). unfold magma_op, refa754_inst, refa754_op in H. discriminate H. Qed.

Lemma refa754_not3050 : ~ @Equation3050 Fin6 refa754_inst.
Proof. unfold Equation3050. intro H. specialize (H F6_0). unfold magma_op, refa754_inst, refa754_op in H. discriminate H. Qed.

Lemma refa754_not3253 : ~ @Equation3253 Fin6 refa754_inst.
Proof. unfold Equation3253. intro H. specialize (H F6_0). unfold magma_op, refa754_inst, refa754_op in H. discriminate H. Qed.

Lemma refa754_not3456 : ~ @Equation3456 Fin6 refa754_inst.
Proof. unfold Equation3456. intro H. specialize (H F6_0). unfold magma_op, refa754_inst, refa754_op in H. discriminate H. Qed.

Lemma refa754_not3659 : ~ @Equation3659 Fin6 refa754_inst.
Proof. unfold Equation3659. intro H. specialize (H F6_0). unfold magma_op, refa754_inst, refa754_op in H. discriminate H. Qed.

Lemma refa754_not4065 : ~ @Equation4065 Fin6 refa754_inst.
Proof. unfold Equation4065. intro H. specialize (H F6_0). unfold magma_op, refa754_inst, refa754_op in H. discriminate H. Qed.

Lemma refa754_not4269 : ~ @Equation4269 Fin6 refa754_inst.
Proof. unfold Equation4269. intro H. specialize (H F6_0 F6_2). unfold magma_op, refa754_inst, refa754_op in H. discriminate H. Qed.

Lemma refa754_not4272 : ~ @Equation4272 Fin6 refa754_inst.
Proof. unfold Equation4272. intro H. specialize (H F6_0 F6_2). unfold magma_op, refa754_inst, refa754_op in H. discriminate H. Qed.

Lemma refa754_not4320 : ~ @Equation4320 Fin6 refa754_inst.
Proof. unfold Equation4320. intro H. specialize (H F6_0 F6_2). unfold magma_op, refa754_inst, refa754_op in H. discriminate H. Qed.

Lemma refa754_not4606 : ~ @Equation4606 Fin6 refa754_inst.
Proof. unfold Equation4606. intro H. specialize (H F6_0 F6_1). unfold magma_op, refa754_inst, refa754_op in H. discriminate H. Qed.

Lemma refa754_not4622 : ~ @Equation4622 Fin6 refa754_inst.
Proof. unfold Equation4622. intro H. specialize (H F6_0 F6_0 F6_1). unfold magma_op, refa754_inst, refa754_op in H. discriminate H. Qed.

Lemma refa754_not4631 : ~ @Equation4631 Fin6 refa754_inst.
Proof. unfold Equation4631. intro H. specialize (H F6_0 F6_0 F6_1). unfold magma_op, refa754_inst, refa754_op in H. discriminate H. Qed.

(** ---- refa755 (Fin6) ---- *)

Definition refa755_op (x y : Fin6) : Fin6 :=
  match x, y with
  | F6_0, F6_0 => F6_0 | F6_0, F6_1 => F6_4 | F6_0, F6_2 => F6_1 | F6_0, F6_3 => F6_3 | F6_0, F6_4 => F6_4 | F6_0, F6_5 => F6_1
  | F6_1, F6_0 => F6_2 | F6_1, F6_1 => F6_1 | F6_1, F6_2 => F6_5 | F6_1, F6_3 => F6_5 | F6_1, F6_4 => F6_4 | F6_1, F6_5 => F6_5
  | F6_2, F6_0 => F6_3 | F6_2, F6_1 => F6_0 | F6_2, F6_2 => F6_2 | F6_2, F6_3 => F6_3 | F6_2, F6_4 => F6_0 | F6_2, F6_5 => F6_5
  | F6_3, F6_0 => F6_0 | F6_3, F6_1 => F6_0 | F6_3, F6_2 => F6_2 | F6_3, F6_3 => F6_3 | F6_3, F6_4 => F6_0 | F6_3, F6_5 => F6_0
  | F6_4, F6_0 => F6_0 | F6_4, F6_1 => F6_1 | F6_4, F6_2 => F6_1 | F6_4, F6_3 => F6_2 | F6_4, F6_4 => F6_4 | F6_4, F6_5 => F6_5
  | F6_5, F6_0 => F6_2 | F6_5, F6_1 => F6_1 | F6_5, F6_2 => F6_2 | F6_5, F6_3 => F6_2 | F6_5, F6_4 => F6_4 | F6_5, F6_5 => F6_5
  end.

#[local] Instance refa755_inst : Magma Fin6 := {| magma_op := refa755_op |}.

Lemma refa755_sat2702 : @Equation2702 Fin6 refa755_inst.
Proof. unfold Equation2702, magma_op, refa755_inst, refa755_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa755_not2253 : ~ @Equation2253 Fin6 refa755_inst.
Proof. unfold Equation2253. intro H. specialize (H F6_0 F6_1). unfold magma_op, refa755_inst, refa755_op in H. discriminate H. Qed.

Lemma refa755_not2290 : ~ @Equation2290 Fin6 refa755_inst.
Proof. unfold Equation2290. intro H. specialize (H F6_0 F6_1). unfold magma_op, refa755_inst, refa755_op in H. discriminate H. Qed.

(** ---- refa756 (Fin8) ---- *)

Definition refa756_op (x y : Fin8) : Fin8 :=
  match x, y with
  | F8_0, F8_0 => F8_1 | F8_0, F8_1 => F8_5 | F8_0, F8_2 => F8_1 | F8_0, F8_3 => F8_3 | F8_0, F8_4 => F8_7 | F8_0, F8_5 => F8_5 | F8_0, F8_6 => F8_6 | F8_0, F8_7 => F8_7
  | F8_1, F8_0 => F8_2 | F8_1, F8_1 => F8_6 | F8_1, F8_2 => F8_3 | F8_1, F8_3 => F8_3 | F8_1, F8_4 => F8_2 | F8_1, F8_5 => F8_7 | F8_1, F8_6 => F8_6 | F8_1, F8_7 => F8_3
  | F8_2, F8_0 => F8_4 | F8_2, F8_1 => F8_5 | F8_2, F8_2 => F8_2 | F8_2, F8_3 => F8_3 | F8_2, F8_4 => F8_7 | F8_2, F8_5 => F8_7 | F8_2, F8_6 => F8_7 | F8_2, F8_7 => F8_7
  | F8_3, F8_0 => F8_0 | F8_3, F8_1 => F8_1 | F8_3, F8_2 => F8_2 | F8_3, F8_3 => F8_3 | F8_3, F8_4 => F8_2 | F8_3, F8_5 => F8_7 | F8_3, F8_6 => F8_6 | F8_3, F8_7 => F8_2
  | F8_4, F8_0 => F8_4 | F8_4, F8_1 => F8_6 | F8_4, F8_2 => F8_1 | F8_4, F8_3 => F8_6 | F8_4, F8_4 => F8_4 | F8_4, F8_5 => F8_5 | F8_4, F8_6 => F8_6 | F8_4, F8_7 => F8_7
  | F8_5, F8_0 => F8_0 | F8_5, F8_1 => F8_6 | F8_5, F8_2 => F8_3 | F8_5, F8_3 => F8_6 | F8_5, F8_4 => F8_4 | F8_5, F8_5 => F8_5 | F8_5, F8_6 => F8_6 | F8_5, F8_7 => F8_3
  | F8_6, F8_0 => F8_0 | F8_6, F8_1 => F8_1 | F8_6, F8_2 => F8_3 | F8_6, F8_3 => F8_3 | F8_6, F8_4 => F8_4 | F8_6, F8_5 => F8_5 | F8_6, F8_6 => F8_6 | F8_6, F8_7 => F8_3
  | F8_7, F8_0 => F8_0 | F8_7, F8_1 => F8_5 | F8_7, F8_2 => F8_2 | F8_7, F8_3 => F8_5 | F8_7, F8_4 => F8_4 | F8_7, F8_5 => F8_4 | F8_7, F8_6 => F8_5 | F8_7, F8_7 => F8_7
  end.

#[local] Instance refa756_inst : Magma Fin8 := {| magma_op := refa756_op |}.

Lemma refa756_sat2702 : @Equation2702 Fin8 refa756_inst.
Proof. unfold Equation2702, magma_op, refa756_inst, refa756_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa756_not2441 : ~ @Equation2441 Fin8 refa756_inst.
Proof. unfold Equation2441. intro H. specialize (H F8_0). unfold magma_op, refa756_inst, refa756_op in H. discriminate H. Qed.

(** ---- refa757 (Fin5) ---- *)

Definition refa757_op (x y : Fin5) : Fin5 :=
  match x, y with
  | F5_0, F5_0 => F5_1 | F5_0, F5_1 => F5_2 | F5_0, F5_2 => F5_4 | F5_0, F5_3 => F5_3 | F5_0, F5_4 => F5_0
  | F5_1, F5_0 => F5_4 | F5_1, F5_1 => F5_3 | F5_1, F5_2 => F5_2 | F5_1, F5_3 => F5_0 | F5_1, F5_4 => F5_1
  | F5_2, F5_0 => F5_3 | F5_2, F5_1 => F5_1 | F5_2, F5_2 => F5_0 | F5_2, F5_3 => F5_4 | F5_2, F5_4 => F5_2
  | F5_3, F5_0 => F5_0 | F5_3, F5_1 => F5_4 | F5_3, F5_2 => F5_1 | F5_3, F5_3 => F5_2 | F5_3, F5_4 => F5_3
  | F5_4, F5_0 => F5_2 | F5_4, F5_1 => F5_0 | F5_4, F5_2 => F5_3 | F5_4, F5_3 => F5_1 | F5_4, F5_4 => F5_4
  end.

#[local] Instance refa757_inst : Magma Fin5 := {| magma_op := refa757_op |}.

Lemma refa757_sat452 : @Equation452 Fin5 refa757_inst.
Proof. unfold Equation452, magma_op, refa757_inst, refa757_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa757_sat467 : @Equation467 Fin5 refa757_inst.
Proof. unfold Equation467, magma_op, refa757_inst, refa757_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa757_sat2127 : @Equation2127 Fin5 refa757_inst.
Proof. unfold Equation2127, magma_op, refa757_inst, refa757_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa757_sat2707 : @Equation2707 Fin5 refa757_inst.
Proof. unfold Equation2707, magma_op, refa757_inst, refa757_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa757_sat2743 : @Equation2743 Fin5 refa757_inst.
Proof. unfold Equation2743, magma_op, refa757_inst, refa757_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa757_sat2903 : @Equation2903 Fin5 refa757_inst.
Proof. unfold Equation2903, magma_op, refa757_inst, refa757_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa757_sat2937 : @Equation2937 Fin5 refa757_inst.
Proof. unfold Equation2937, magma_op, refa757_inst, refa757_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa757_sat2939 : @Equation2939 Fin5 refa757_inst.
Proof. unfold Equation2939, magma_op, refa757_inst, refa757_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa757_not47 : ~ @Equation47 Fin5 refa757_inst.
Proof. unfold Equation47. intro H. specialize (H F5_0). unfold magma_op, refa757_inst, refa757_op in H. discriminate H. Qed.

Lemma refa757_not105 : ~ @Equation105 Fin5 refa757_inst.
Proof. unfold Equation105. intro H. specialize (H F5_0 F5_1). unfold magma_op, refa757_inst, refa757_op in H. discriminate H. Qed.

Lemma refa757_not107 : ~ @Equation107 Fin5 refa757_inst.
Proof. unfold Equation107. intro H. specialize (H F5_0 F5_1). unfold magma_op, refa757_inst, refa757_op in H. discriminate H. Qed.

Lemma refa757_not151 : ~ @Equation151 Fin5 refa757_inst.
Proof. unfold Equation151. intro H. specialize (H F5_0). unfold magma_op, refa757_inst, refa757_op in H. discriminate H. Qed.

Lemma refa757_not203 : ~ @Equation203 Fin5 refa757_inst.
Proof. unfold Equation203. intro H. specialize (H F5_0). unfold magma_op, refa757_inst, refa757_op in H. discriminate H. Qed.

Lemma refa757_not255 : ~ @Equation255 Fin5 refa757_inst.
Proof. unfold Equation255. intro H. specialize (H F5_0). unfold magma_op, refa757_inst, refa757_op in H. discriminate H. Qed.

Lemma refa757_not413 : ~ @Equation413 Fin5 refa757_inst.
Proof. unfold Equation413. intro H. specialize (H F5_0 F5_1). unfold magma_op, refa757_inst, refa757_op in H. discriminate H. Qed.

Lemma refa757_not416 : ~ @Equation416 Fin5 refa757_inst.
Proof. unfold Equation416. intro H. specialize (H F5_0 F5_1). unfold magma_op, refa757_inst, refa757_op in H. discriminate H. Qed.

Lemma refa757_not419 : ~ @Equation419 Fin5 refa757_inst.
Proof. unfold Equation419. intro H. specialize (H F5_0 F5_1). unfold magma_op, refa757_inst, refa757_op in H. discriminate H. Qed.

Lemma refa757_not420 : ~ @Equation420 Fin5 refa757_inst.
Proof. unfold Equation420. intro H. specialize (H F5_0 F5_1). unfold magma_op, refa757_inst, refa757_op in H. discriminate H. Qed.

Lemma refa757_not426 : ~ @Equation426 Fin5 refa757_inst.
Proof. unfold Equation426. intro H. specialize (H F5_0 F5_1). unfold magma_op, refa757_inst, refa757_op in H. discriminate H. Qed.

Lemma refa757_not436 : ~ @Equation436 Fin5 refa757_inst.
Proof. unfold Equation436. intro H. specialize (H F5_0 F5_1). unfold magma_op, refa757_inst, refa757_op in H. discriminate H. Qed.

Lemma refa757_not437 : ~ @Equation437 Fin5 refa757_inst.
Proof. unfold Equation437. intro H. specialize (H F5_0 F5_1). unfold magma_op, refa757_inst, refa757_op in H. discriminate H. Qed.

Lemma refa757_not466 : ~ @Equation466 Fin5 refa757_inst.
Proof. unfold Equation466. intro H. specialize (H F5_0 F5_1). unfold magma_op, refa757_inst, refa757_op in H. discriminate H. Qed.

Lemma refa757_not477 : ~ @Equation477 Fin5 refa757_inst.
Proof. unfold Equation477. intro H. specialize (H F5_0 F5_1). unfold magma_op, refa757_inst, refa757_op in H. discriminate H. Qed.

Lemma refa757_not501 : ~ @Equation501 Fin5 refa757_inst.
Proof. unfold Equation501. intro H. specialize (H F5_0 F5_1). unfold magma_op, refa757_inst, refa757_op in H. discriminate H. Qed.

Lemma refa757_not503 : ~ @Equation503 Fin5 refa757_inst.
Proof. unfold Equation503. intro H. specialize (H F5_0 F5_1). unfold magma_op, refa757_inst, refa757_op in H. discriminate H. Qed.

Lemma refa757_not504 : ~ @Equation504 Fin5 refa757_inst.
Proof. unfold Equation504. intro H. specialize (H F5_0 F5_1). unfold magma_op, refa757_inst, refa757_op in H. discriminate H. Qed.

Lemma refa757_not511 : ~ @Equation511 Fin5 refa757_inst.
Proof. unfold Equation511. intro H. specialize (H F5_0 F5_1). unfold magma_op, refa757_inst, refa757_op in H. discriminate H. Qed.

Lemma refa757_not614 : ~ @Equation614 Fin5 refa757_inst.
Proof. unfold Equation614. intro H. specialize (H F5_0). unfold magma_op, refa757_inst, refa757_op in H. discriminate H. Qed.

Lemma refa757_not817 : ~ @Equation817 Fin5 refa757_inst.
Proof. unfold Equation817. intro H. specialize (H F5_0). unfold magma_op, refa757_inst, refa757_op in H. discriminate H. Qed.

Lemma refa757_not1020 : ~ @Equation1020 Fin5 refa757_inst.
Proof. unfold Equation1020. intro H. specialize (H F5_0). unfold magma_op, refa757_inst, refa757_op in H. discriminate H. Qed.

Lemma refa757_not1223 : ~ @Equation1223 Fin5 refa757_inst.
Proof. unfold Equation1223. intro H. specialize (H F5_0). unfold magma_op, refa757_inst, refa757_op in H. discriminate H. Qed.

Lemma refa757_not1426 : ~ @Equation1426 Fin5 refa757_inst.
Proof. unfold Equation1426. intro H. specialize (H F5_0). unfold magma_op, refa757_inst, refa757_op in H. discriminate H. Qed.

Lemma refa757_not1629 : ~ @Equation1629 Fin5 refa757_inst.
Proof. unfold Equation1629. intro H. specialize (H F5_0). unfold magma_op, refa757_inst, refa757_op in H. discriminate H. Qed.

Lemma refa757_not1832 : ~ @Equation1832 Fin5 refa757_inst.
Proof. unfold Equation1832. intro H. specialize (H F5_0). unfold magma_op, refa757_inst, refa757_op in H. discriminate H. Qed.

Lemma refa757_not2036 : ~ @Equation2036 Fin5 refa757_inst.
Proof. unfold Equation2036. intro H. specialize (H F5_0 F5_1). unfold magma_op, refa757_inst, refa757_op in H. discriminate H. Qed.

Lemma refa757_not2037 : ~ @Equation2037 Fin5 refa757_inst.
Proof. unfold Equation2037. intro H. specialize (H F5_0 F5_1). unfold magma_op, refa757_inst, refa757_op in H. discriminate H. Qed.

Lemma refa757_not2038 : ~ @Equation2038 Fin5 refa757_inst.
Proof. unfold Equation2038. intro H. specialize (H F5_0 F5_1). unfold magma_op, refa757_inst, refa757_op in H. discriminate H. Qed.

Lemma refa757_not2040 : ~ @Equation2040 Fin5 refa757_inst.
Proof. unfold Equation2040. intro H. specialize (H F5_0 F5_1). unfold magma_op, refa757_inst, refa757_op in H. discriminate H. Qed.

Lemma refa757_not2041 : ~ @Equation2041 Fin5 refa757_inst.
Proof. unfold Equation2041. intro H. specialize (H F5_0 F5_1). unfold magma_op, refa757_inst, refa757_op in H. discriminate H. Qed.

Lemma refa757_not2044 : ~ @Equation2044 Fin5 refa757_inst.
Proof. unfold Equation2044. intro H. specialize (H F5_0 F5_1). unfold magma_op, refa757_inst, refa757_op in H. discriminate H. Qed.

Lemma refa757_not2050 : ~ @Equation2050 Fin5 refa757_inst.
Proof. unfold Equation2050. intro H. specialize (H F5_0 F5_1). unfold magma_op, refa757_inst, refa757_op in H. discriminate H. Qed.

Lemma refa757_not2060 : ~ @Equation2060 Fin5 refa757_inst.
Proof. unfold Equation2060. intro H. specialize (H F5_0 F5_1). unfold magma_op, refa757_inst, refa757_op in H. discriminate H. Qed.

Lemma refa757_not2063 : ~ @Equation2063 Fin5 refa757_inst.
Proof. unfold Equation2063. intro H. specialize (H F5_0 F5_1). unfold magma_op, refa757_inst, refa757_op in H. discriminate H. Qed.

Lemma refa757_not2128 : ~ @Equation2128 Fin5 refa757_inst.
Proof. unfold Equation2128. intro H. specialize (H F5_0 F5_1). unfold magma_op, refa757_inst, refa757_op in H. discriminate H. Qed.

Lemma refa757_not2238 : ~ @Equation2238 Fin5 refa757_inst.
Proof. unfold Equation2238. intro H. specialize (H F5_0). unfold magma_op, refa757_inst, refa757_op in H. discriminate H. Qed.

Lemma refa757_not2441 : ~ @Equation2441 Fin5 refa757_inst.
Proof. unfold Equation2441. intro H. specialize (H F5_0). unfold magma_op, refa757_inst, refa757_op in H. discriminate H. Qed.

Lemma refa757_not2670 : ~ @Equation2670 Fin5 refa757_inst.
Proof. unfold Equation2670. intro H. specialize (H F5_0 F5_1). unfold magma_op, refa757_inst, refa757_op in H. discriminate H. Qed.

Lemma refa757_not2672 : ~ @Equation2672 Fin5 refa757_inst.
Proof. unfold Equation2672. intro H. specialize (H F5_0 F5_1). unfold magma_op, refa757_inst, refa757_op in H. discriminate H. Qed.

Lemma refa757_not2700 : ~ @Equation2700 Fin5 refa757_inst.
Proof. unfold Equation2700. intro H. specialize (H F5_0 F5_1). unfold magma_op, refa757_inst, refa757_op in H. discriminate H. Qed.

Lemma refa757_not2709 : ~ @Equation2709 Fin5 refa757_inst.
Proof. unfold Equation2709. intro H. specialize (H F5_0 F5_1). unfold magma_op, refa757_inst, refa757_op in H. discriminate H. Qed.

Lemma refa757_not2710 : ~ @Equation2710 Fin5 refa757_inst.
Proof. unfold Equation2710. intro H. specialize (H F5_0 F5_1). unfold magma_op, refa757_inst, refa757_op in H. discriminate H. Qed.

Lemma refa757_not2736 : ~ @Equation2736 Fin5 refa757_inst.
Proof. unfold Equation2736. intro H. specialize (H F5_0 F5_1). unfold magma_op, refa757_inst, refa757_op in H. discriminate H. Qed.

Lemma refa757_not2853 : ~ @Equation2853 Fin5 refa757_inst.
Proof. unfold Equation2853. intro H. specialize (H F5_0 F5_1). unfold magma_op, refa757_inst, refa757_op in H. discriminate H. Qed.

Lemma refa757_not2863 : ~ @Equation2863 Fin5 refa757_inst.
Proof. unfold Equation2863. intro H. specialize (H F5_0 F5_1). unfold magma_op, refa757_inst, refa757_op in H. discriminate H. Qed.

Lemma refa757_not2875 : ~ @Equation2875 Fin5 refa757_inst.
Proof. unfold Equation2875. intro H. specialize (H F5_0 F5_1). unfold magma_op, refa757_inst, refa757_op in H. discriminate H. Qed.

Lemma refa757_not2902 : ~ @Equation2902 Fin5 refa757_inst.
Proof. unfold Equation2902. intro H. specialize (H F5_0 F5_1). unfold magma_op, refa757_inst, refa757_op in H. discriminate H. Qed.

Lemma refa757_not2912 : ~ @Equation2912 Fin5 refa757_inst.
Proof. unfold Equation2912. intro H. specialize (H F5_0 F5_1). unfold magma_op, refa757_inst, refa757_op in H. discriminate H. Qed.

Lemma refa757_not2940 : ~ @Equation2940 Fin5 refa757_inst.
Proof. unfold Equation2940. intro H. specialize (H F5_0 F5_1). unfold magma_op, refa757_inst, refa757_op in H. discriminate H. Qed.

Lemma refa757_not2947 : ~ @Equation2947 Fin5 refa757_inst.
Proof. unfold Equation2947. intro H. specialize (H F5_0 F5_1). unfold magma_op, refa757_inst, refa757_op in H. discriminate H. Qed.

Lemma refa757_not3050 : ~ @Equation3050 Fin5 refa757_inst.
Proof. unfold Equation3050. intro H. specialize (H F5_0). unfold magma_op, refa757_inst, refa757_op in H. discriminate H. Qed.

Lemma refa757_not3253 : ~ @Equation3253 Fin5 refa757_inst.
Proof. unfold Equation3253. intro H. specialize (H F5_0). unfold magma_op, refa757_inst, refa757_op in H. discriminate H. Qed.

Lemma refa757_not3456 : ~ @Equation3456 Fin5 refa757_inst.
Proof. unfold Equation3456. intro H. specialize (H F5_0). unfold magma_op, refa757_inst, refa757_op in H. discriminate H. Qed.

Lemma refa757_not3659 : ~ @Equation3659 Fin5 refa757_inst.
Proof. unfold Equation3659. intro H. specialize (H F5_0). unfold magma_op, refa757_inst, refa757_op in H. discriminate H. Qed.

Lemma refa757_not3862 : ~ @Equation3862 Fin5 refa757_inst.
Proof. unfold Equation3862. intro H. specialize (H F5_0). unfold magma_op, refa757_inst, refa757_op in H. discriminate H. Qed.

Lemma refa757_not4065 : ~ @Equation4065 Fin5 refa757_inst.
Proof. unfold Equation4065. intro H. specialize (H F5_0). unfold magma_op, refa757_inst, refa757_op in H. discriminate H. Qed.

Lemma refa757_not4275 : ~ @Equation4275 Fin5 refa757_inst.
Proof. unfold Equation4275. intro H. specialize (H F5_0 F5_1). unfold magma_op, refa757_inst, refa757_op in H. discriminate H. Qed.

Lemma refa757_not4283 : ~ @Equation4283 Fin5 refa757_inst.
Proof. unfold Equation4283. intro H. specialize (H F5_0 F5_1). unfold magma_op, refa757_inst, refa757_op in H. discriminate H. Qed.

Lemma refa757_not4293 : ~ @Equation4293 Fin5 refa757_inst.
Proof. unfold Equation4293. intro H. specialize (H F5_0 F5_1). unfold magma_op, refa757_inst, refa757_op in H. discriminate H. Qed.

Lemma refa757_not4380 : ~ @Equation4380 Fin5 refa757_inst.
Proof. unfold Equation4380. intro H. specialize (H F5_0). unfold magma_op, refa757_inst, refa757_op in H. discriminate H. Qed.

Lemma refa757_not4585 : ~ @Equation4585 Fin5 refa757_inst.
Proof. unfold Equation4585. intro H. specialize (H F5_0 F5_1). unfold magma_op, refa757_inst, refa757_op in H. discriminate H. Qed.

Lemma refa757_not4588 : ~ @Equation4588 Fin5 refa757_inst.
Proof. unfold Equation4588. intro H. specialize (H F5_0 F5_1). unfold magma_op, refa757_inst, refa757_op in H. discriminate H. Qed.

Lemma refa757_not4608 : ~ @Equation4608 Fin5 refa757_inst.
Proof. unfold Equation4608. intro H. specialize (H F5_0 F5_1). unfold magma_op, refa757_inst, refa757_op in H. discriminate H. Qed.

Lemma refa757_not4635 : ~ @Equation4635 Fin5 refa757_inst.
Proof. unfold Equation4635. intro H. specialize (H F5_0 F5_1). unfold magma_op, refa757_inst, refa757_op in H. discriminate H. Qed.

(** ---- refa758 (Fin5) ---- *)

Definition refa758_op (x y : Fin5) : Fin5 :=
  match x, y with
  | F5_0, F5_0 => F5_1 | F5_0, F5_1 => F5_0 | F5_0, F5_2 => F5_2 | F5_0, F5_3 => F5_4 | F5_0, F5_4 => F5_3
  | F5_1, F5_0 => F5_2 | F5_1, F5_1 => F5_3 | F5_1, F5_2 => F5_0 | F5_1, F5_3 => F5_1 | F5_1, F5_4 => F5_4
  | F5_2, F5_0 => F5_3 | F5_2, F5_1 => F5_1 | F5_2, F5_2 => F5_4 | F5_2, F5_3 => F5_0 | F5_2, F5_4 => F5_2
  | F5_3, F5_0 => F5_0 | F5_3, F5_1 => F5_4 | F5_3, F5_2 => F5_3 | F5_3, F5_3 => F5_2 | F5_3, F5_4 => F5_1
  | F5_4, F5_0 => F5_4 | F5_4, F5_1 => F5_2 | F5_4, F5_2 => F5_1 | F5_4, F5_3 => F5_3 | F5_4, F5_4 => F5_0
  end.

#[local] Instance refa758_inst : Magma Fin5 := {| magma_op := refa758_op |}.

Lemma refa758_sat474 : @Equation474 Fin5 refa758_inst.
Proof. unfold Equation474, magma_op, refa758_inst, refa758_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa758_sat2722 : @Equation2722 Fin5 refa758_inst.
Proof. unfold Equation2722, magma_op, refa758_inst, refa758_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa758_sat2743 : @Equation2743 Fin5 refa758_inst.
Proof. unfold Equation2743, magma_op, refa758_inst, refa758_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa758_not255 : ~ @Equation255 Fin5 refa758_inst.
Proof. unfold Equation255. intro H. specialize (H F5_0). unfold magma_op, refa758_inst, refa758_op in H. discriminate H. Qed.

Lemma refa758_not427 : ~ @Equation427 Fin5 refa758_inst.
Proof. unfold Equation427. intro H. specialize (H F5_0 F5_1). unfold magma_op, refa758_inst, refa758_op in H. discriminate H. Qed.

Lemma refa758_not429 : ~ @Equation429 Fin5 refa758_inst.
Proof. unfold Equation429. intro H. specialize (H F5_0 F5_1). unfold magma_op, refa758_inst, refa758_op in H. discriminate H. Qed.

Lemma refa758_not473 : ~ @Equation473 Fin5 refa758_inst.
Proof. unfold Equation473. intro H. specialize (H F5_0 F5_1). unfold magma_op, refa758_inst, refa758_op in H. discriminate H. Qed.

Lemma refa758_not817 : ~ @Equation817 Fin5 refa758_inst.
Proof. unfold Equation817. intro H. specialize (H F5_0). unfold magma_op, refa758_inst, refa758_op in H. discriminate H. Qed.

Lemma refa758_not1036 : ~ @Equation1036 Fin5 refa758_inst.
Proof. unfold Equation1036. intro H. specialize (H F5_0 F5_1). unfold magma_op, refa758_inst, refa758_op in H. discriminate H. Qed.

Lemma refa758_not1113 : ~ @Equation1113 Fin5 refa758_inst.
Proof. unfold Equation1113. intro H. specialize (H F5_0 F5_1). unfold magma_op, refa758_inst, refa758_op in H. discriminate H. Qed.

Lemma refa758_not1635 : ~ @Equation1635 Fin5 refa758_inst.
Proof. unfold Equation1635. intro H. specialize (H F5_0 F5_1). unfold magma_op, refa758_inst, refa758_op in H. discriminate H. Qed.

Lemma refa758_not1848 : ~ @Equation1848 Fin5 refa758_inst.
Proof. unfold Equation1848. intro H. specialize (H F5_0 F5_1). unfold magma_op, refa758_inst, refa758_op in H. discriminate H. Qed.

Lemma refa758_not1861 : ~ @Equation1861 Fin5 refa758_inst.
Proof. unfold Equation1861. intro H. specialize (H F5_0 F5_1). unfold magma_op, refa758_inst, refa758_op in H. discriminate H. Qed.

Lemma refa758_not2441 : ~ @Equation2441 Fin5 refa758_inst.
Proof. unfold Equation2441. intro H. specialize (H F5_0). unfold magma_op, refa758_inst, refa758_op in H. discriminate H. Qed.

Lemma refa758_not2669 : ~ @Equation2669 Fin5 refa758_inst.
Proof. unfold Equation2669. intro H. specialize (H F5_0 F5_1). unfold magma_op, refa758_inst, refa758_op in H. discriminate H. Qed.

Lemma refa758_not2746 : ~ @Equation2746 Fin5 refa758_inst.
Proof. unfold Equation2746. intro H. specialize (H F5_0 F5_1). unfold magma_op, refa758_inst, refa758_op in H. discriminate H. Qed.

Lemma refa758_not2847 : ~ @Equation2847 Fin5 refa758_inst.
Proof. unfold Equation2847. intro H. specialize (H F5_0). unfold magma_op, refa758_inst, refa758_op in H. discriminate H. Qed.

Lemma refa758_not3112 : ~ @Equation3112 Fin5 refa758_inst.
Proof. unfold Equation3112. intro H. specialize (H F5_0 F5_1). unfold magma_op, refa758_inst, refa758_op in H. discriminate H. Qed.

Lemma refa758_not3152 : ~ @Equation3152 Fin5 refa758_inst.
Proof. unfold Equation3152. intro H. specialize (H F5_0 F5_1). unfold magma_op, refa758_inst, refa758_op in H. discriminate H. Qed.

Lemma refa758_not3271 : ~ @Equation3271 Fin5 refa758_inst.
Proof. unfold Equation3271. intro H. specialize (H F5_0 F5_1). unfold magma_op, refa758_inst, refa758_op in H. discriminate H. Qed.

Lemma refa758_not3346 : ~ @Equation3346 Fin5 refa758_inst.
Proof. unfold Equation3346. intro H. specialize (H F5_0 F5_1). unfold magma_op, refa758_inst, refa758_op in H. discriminate H. Qed.

Lemma refa758_not3659 : ~ @Equation3659 Fin5 refa758_inst.
Proof. unfold Equation3659. intro H. specialize (H F5_0). unfold magma_op, refa758_inst, refa758_op in H. discriminate H. Qed.

Lemma refa758_not3878 : ~ @Equation3878 Fin5 refa758_inst.
Proof. unfold Equation3878. intro H. specialize (H F5_0 F5_1). unfold magma_op, refa758_inst, refa758_op in H. discriminate H. Qed.

Lemma refa758_not3924 : ~ @Equation3924 Fin5 refa758_inst.
Proof. unfold Equation3924. intro H. specialize (H F5_0 F5_1). unfold magma_op, refa758_inst, refa758_op in H. discriminate H. Qed.

Lemma refa758_not4320 : ~ @Equation4320 Fin5 refa758_inst.
Proof. unfold Equation4320. intro H. specialize (H F5_0 F5_1). unfold magma_op, refa758_inst, refa758_op in H. discriminate H. Qed.

Lemma refa758_not4647 : ~ @Equation4647 Fin5 refa758_inst.
Proof. unfold Equation4647. intro H. specialize (H F5_0 F5_0 F5_1). unfold magma_op, refa758_inst, refa758_op in H. discriminate H. Qed.

Lemma refa758_not4658 : ~ @Equation4658 Fin5 refa758_inst.
Proof. unfold Equation4658. intro H. specialize (H F5_0 F5_1). unfold magma_op, refa758_inst, refa758_op in H. discriminate H. Qed.

(** ---- refa759 (Fin5) ---- *)

Definition refa759_op (x y : Fin5) : Fin5 :=
  match x, y with
  | F5_0, F5_0 => F5_0 | F5_0, F5_1 => F5_3 | F5_0, F5_2 => F5_3 | F5_0, F5_3 => F5_4 | F5_0, F5_4 => F5_4
  | F5_1, F5_0 => F5_2 | F5_1, F5_1 => F5_1 | F5_1, F5_2 => F5_3 | F5_1, F5_3 => F5_3 | F5_1, F5_4 => F5_4
  | F5_2, F5_0 => F5_0 | F5_2, F5_1 => F5_3 | F5_2, F5_2 => F5_2 | F5_2, F5_3 => F5_4 | F5_2, F5_4 => F5_4
  | F5_3, F5_0 => F5_0 | F5_3, F5_1 => F5_1 | F5_3, F5_2 => F5_2 | F5_3, F5_3 => F5_3 | F5_3, F5_4 => F5_4
  | F5_4, F5_0 => F5_2 | F5_4, F5_1 => F5_1 | F5_4, F5_2 => F5_2 | F5_4, F5_3 => F5_3 | F5_4, F5_4 => F5_4
  end.

#[local] Instance refa759_inst : Magma Fin5 := {| magma_op := refa759_op |}.

Lemma refa759_sat2381 : @Equation2381 Fin5 refa759_inst.
Proof. unfold Equation2381, magma_op, refa759_inst, refa759_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa759_not2263 : ~ @Equation2263 Fin5 refa759_inst.
Proof. unfold Equation2263. intro H. specialize (H F5_0 F5_1). unfold magma_op, refa759_inst, refa759_op in H. discriminate H. Qed.

(** ---- refa76 (Fin3) ---- *)

Definition refa76_op (x y : Fin3) : Fin3 :=
  match x, y with
  | F3_0, F3_0 => F3_0 | F3_0, F3_1 => F3_1 | F3_0, F3_2 => F3_1
  | F3_1, F3_0 => F3_0 | F3_1, F3_1 => F3_1 | F3_1, F3_2 => F3_2
  | F3_2, F3_0 => F3_0 | F3_2, F3_1 => F3_1 | F3_2, F3_2 => F3_0
  end.

#[local] Instance refa76_inst : Magma Fin3 := {| magma_op := refa76_op |}.

Lemma refa76_sat312 : @Equation312 Fin3 refa76_inst.
Proof. unfold Equation312, magma_op, refa76_inst, refa76_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa76_sat323 : @Equation323 Fin3 refa76_inst.
Proof. unfold Equation323, magma_op, refa76_inst, refa76_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa76_sat2493 : @Equation2493 Fin3 refa76_inst.
Proof. unfold Equation2493, magma_op, refa76_inst, refa76_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa76_sat2899 : @Equation2899 Fin3 refa76_inst.
Proof. unfold Equation2899, magma_op, refa76_inst, refa76_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa76_sat4606 : @Equation4606 Fin3 refa76_inst.
Proof. unfold Equation4606, magma_op, refa76_inst, refa76_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa76_not47 : ~ @Equation47 Fin3 refa76_inst.
Proof. unfold Equation47. intro H. specialize (H F3_2). unfold magma_op, refa76_inst, refa76_op in H. discriminate H. Qed.

Lemma refa76_not99 : ~ @Equation99 Fin3 refa76_inst.
Proof. unfold Equation99. intro H. specialize (H F3_2). unfold magma_op, refa76_inst, refa76_op in H. discriminate H. Qed.

Lemma refa76_not151 : ~ @Equation151 Fin3 refa76_inst.
Proof. unfold Equation151. intro H. specialize (H F3_2). unfold magma_op, refa76_inst, refa76_op in H. discriminate H. Qed.

Lemma refa76_not203 : ~ @Equation203 Fin3 refa76_inst.
Proof. unfold Equation203. intro H. specialize (H F3_2). unfold magma_op, refa76_inst, refa76_op in H. discriminate H. Qed.

Lemma refa76_not263 : ~ @Equation263 Fin3 refa76_inst.
Proof. unfold Equation263. intro H. specialize (H F3_2 F3_0). unfold magma_op, refa76_inst, refa76_op in H. discriminate H. Qed.

Lemma refa76_not280 : ~ @Equation280 Fin3 refa76_inst.
Proof. unfold Equation280. intro H. specialize (H F3_2 F3_1). unfold magma_op, refa76_inst, refa76_op in H. discriminate H. Qed.

Lemma refa76_not283 : ~ @Equation283 Fin3 refa76_inst.
Proof. unfold Equation283. intro H. specialize (H F3_2 F3_0). unfold magma_op, refa76_inst, refa76_op in H. discriminate H. Qed.

Lemma refa76_not411 : ~ @Equation411 Fin3 refa76_inst.
Proof. unfold Equation411. intro H. specialize (H F3_2). unfold magma_op, refa76_inst, refa76_op in H. discriminate H. Qed.

Lemma refa76_not614 : ~ @Equation614 Fin3 refa76_inst.
Proof. unfold Equation614. intro H. specialize (H F3_2). unfold magma_op, refa76_inst, refa76_op in H. discriminate H. Qed.

Lemma refa76_not817 : ~ @Equation817 Fin3 refa76_inst.
Proof. unfold Equation817. intro H. specialize (H F3_2). unfold magma_op, refa76_inst, refa76_op in H. discriminate H. Qed.

Lemma refa76_not1020 : ~ @Equation1020 Fin3 refa76_inst.
Proof. unfold Equation1020. intro H. specialize (H F3_2). unfold magma_op, refa76_inst, refa76_op in H. discriminate H. Qed.

Lemma refa76_not1223 : ~ @Equation1223 Fin3 refa76_inst.
Proof. unfold Equation1223. intro H. specialize (H F3_2). unfold magma_op, refa76_inst, refa76_op in H. discriminate H. Qed.

Lemma refa76_not1426 : ~ @Equation1426 Fin3 refa76_inst.
Proof. unfold Equation1426. intro H. specialize (H F3_2). unfold magma_op, refa76_inst, refa76_op in H. discriminate H. Qed.

Lemma refa76_not1629 : ~ @Equation1629 Fin3 refa76_inst.
Proof. unfold Equation1629. intro H. specialize (H F3_2). unfold magma_op, refa76_inst, refa76_op in H. discriminate H. Qed.

Lemma refa76_not1832 : ~ @Equation1832 Fin3 refa76_inst.
Proof. unfold Equation1832. intro H. specialize (H F3_2). unfold magma_op, refa76_inst, refa76_op in H. discriminate H. Qed.

Lemma refa76_not2037 : ~ @Equation2037 Fin3 refa76_inst.
Proof. unfold Equation2037. intro H. specialize (H F3_2 F3_0). unfold magma_op, refa76_inst, refa76_op in H. discriminate H. Qed.

Lemma refa76_not2040 : ~ @Equation2040 Fin3 refa76_inst.
Proof. unfold Equation2040. intro H. specialize (H F3_2 F3_0). unfold magma_op, refa76_inst, refa76_op in H. discriminate H. Qed.

Lemma refa76_not2043 : ~ @Equation2043 Fin3 refa76_inst.
Proof. unfold Equation2043. intro H. specialize (H F3_2 F3_0). unfold magma_op, refa76_inst, refa76_op in H. discriminate H. Qed.

Lemma refa76_not2053 : ~ @Equation2053 Fin3 refa76_inst.
Proof. unfold Equation2053. intro H. specialize (H F3_2 F3_0). unfold magma_op, refa76_inst, refa76_op in H. discriminate H. Qed.

Lemma refa76_not2060 : ~ @Equation2060 Fin3 refa76_inst.
Proof. unfold Equation2060. intro H. specialize (H F3_2 F3_0). unfold magma_op, refa76_inst, refa76_op in H. discriminate H. Qed.

Lemma refa76_not2063 : ~ @Equation2063 Fin3 refa76_inst.
Proof. unfold Equation2063. intro H. specialize (H F3_2 F3_0). unfold magma_op, refa76_inst, refa76_op in H. discriminate H. Qed.

Lemma refa76_not2087 : ~ @Equation2087 Fin3 refa76_inst.
Proof. unfold Equation2087. intro H. specialize (H F3_2 F3_0). unfold magma_op, refa76_inst, refa76_op in H. discriminate H. Qed.

Lemma refa76_not2124 : ~ @Equation2124 Fin3 refa76_inst.
Proof. unfold Equation2124. intro H. specialize (H F3_2 F3_0). unfold magma_op, refa76_inst, refa76_op in H. discriminate H. Qed.

Lemma refa76_not2127 : ~ @Equation2127 Fin3 refa76_inst.
Proof. unfold Equation2127. intro H. specialize (H F3_2 F3_0). unfold magma_op, refa76_inst, refa76_op in H. discriminate H. Qed.

Lemma refa76_not2134 : ~ @Equation2134 Fin3 refa76_inst.
Proof. unfold Equation2134. intro H. specialize (H F3_2 F3_0). unfold magma_op, refa76_inst, refa76_op in H. discriminate H. Qed.

Lemma refa76_not2238 : ~ @Equation2238 Fin3 refa76_inst.
Proof. unfold Equation2238. intro H. specialize (H F3_2). unfold magma_op, refa76_inst, refa76_op in H. discriminate H. Qed.

Lemma refa76_not2443 : ~ @Equation2443 Fin3 refa76_inst.
Proof. unfold Equation2443. intro H. specialize (H F3_2 F3_0). unfold magma_op, refa76_inst, refa76_op in H. discriminate H. Qed.

Lemma refa76_not2449 : ~ @Equation2449 Fin3 refa76_inst.
Proof. unfold Equation2449. intro H. specialize (H F3_2 F3_0). unfold magma_op, refa76_inst, refa76_op in H. discriminate H. Qed.

Lemma refa76_not2459 : ~ @Equation2459 Fin3 refa76_inst.
Proof. unfold Equation2459. intro H. specialize (H F3_2 F3_0). unfold magma_op, refa76_inst, refa76_op in H. discriminate H. Qed.

Lemma refa76_not2466 : ~ @Equation2466 Fin3 refa76_inst.
Proof. unfold Equation2466. intro H. specialize (H F3_2 F3_1). unfold magma_op, refa76_inst, refa76_op in H. discriminate H. Qed.

Lemma refa76_not2469 : ~ @Equation2469 Fin3 refa76_inst.
Proof. unfold Equation2469. intro H. specialize (H F3_2 F3_0). unfold magma_op, refa76_inst, refa76_op in H. discriminate H. Qed.

Lemma refa76_not2496 : ~ @Equation2496 Fin3 refa76_inst.
Proof. unfold Equation2496. intro H. specialize (H F3_2 F3_0). unfold magma_op, refa76_inst, refa76_op in H. discriminate H. Qed.

Lemma refa76_not2506 : ~ @Equation2506 Fin3 refa76_inst.
Proof. unfold Equation2506. intro H. specialize (H F3_2 F3_0). unfold magma_op, refa76_inst, refa76_op in H. discriminate H. Qed.

Lemma refa76_not2530 : ~ @Equation2530 Fin3 refa76_inst.
Proof. unfold Equation2530. intro H. specialize (H F3_2 F3_1). unfold magma_op, refa76_inst, refa76_op in H. discriminate H. Qed.

Lemma refa76_not2533 : ~ @Equation2533 Fin3 refa76_inst.
Proof. unfold Equation2533. intro H. specialize (H F3_2 F3_0). unfold magma_op, refa76_inst, refa76_op in H. discriminate H. Qed.

Lemma refa76_not2540 : ~ @Equation2540 Fin3 refa76_inst.
Proof. unfold Equation2540. intro H. specialize (H F3_2 F3_1). unfold magma_op, refa76_inst, refa76_op in H. discriminate H. Qed.

Lemma refa76_not2543 : ~ @Equation2543 Fin3 refa76_inst.
Proof. unfold Equation2543. intro H. specialize (H F3_2 F3_0). unfold magma_op, refa76_inst, refa76_op in H. discriminate H. Qed.

Lemma refa76_not2646 : ~ @Equation2646 Fin3 refa76_inst.
Proof. unfold Equation2646. intro H. specialize (H F3_2 F3_0). unfold magma_op, refa76_inst, refa76_op in H. discriminate H. Qed.

Lemma refa76_not2652 : ~ @Equation2652 Fin3 refa76_inst.
Proof. unfold Equation2652. intro H. specialize (H F3_2 F3_0). unfold magma_op, refa76_inst, refa76_op in H. discriminate H. Qed.

Lemma refa76_not2662 : ~ @Equation2662 Fin3 refa76_inst.
Proof. unfold Equation2662. intro H. specialize (H F3_2 F3_0). unfold magma_op, refa76_inst, refa76_op in H. discriminate H. Qed.

Lemma refa76_not2672 : ~ @Equation2672 Fin3 refa76_inst.
Proof. unfold Equation2672. intro H. specialize (H F3_2 F3_0). unfold magma_op, refa76_inst, refa76_op in H. discriminate H. Qed.

Lemma refa76_not2699 : ~ @Equation2699 Fin3 refa76_inst.
Proof. unfold Equation2699. intro H. specialize (H F3_2 F3_0). unfold magma_op, refa76_inst, refa76_op in H. discriminate H. Qed.

Lemma refa76_not2709 : ~ @Equation2709 Fin3 refa76_inst.
Proof. unfold Equation2709. intro H. specialize (H F3_2 F3_0). unfold magma_op, refa76_inst, refa76_op in H. discriminate H. Qed.

Lemma refa76_not2736 : ~ @Equation2736 Fin3 refa76_inst.
Proof. unfold Equation2736. intro H. specialize (H F3_2 F3_0). unfold magma_op, refa76_inst, refa76_op in H. discriminate H. Qed.

Lemma refa76_not2743 : ~ @Equation2743 Fin3 refa76_inst.
Proof. unfold Equation2743. intro H. specialize (H F3_2 F3_1). unfold magma_op, refa76_inst, refa76_op in H. discriminate H. Qed.

Lemma refa76_not2746 : ~ @Equation2746 Fin3 refa76_inst.
Proof. unfold Equation2746. intro H. specialize (H F3_2 F3_0). unfold magma_op, refa76_inst, refa76_op in H. discriminate H. Qed.

Lemma refa76_not2849 : ~ @Equation2849 Fin3 refa76_inst.
Proof. unfold Equation2849. intro H. specialize (H F3_2 F3_0). unfold magma_op, refa76_inst, refa76_op in H. discriminate H. Qed.

Lemma refa76_not2852 : ~ @Equation2852 Fin3 refa76_inst.
Proof. unfold Equation2852. intro H. specialize (H F3_2 F3_1). unfold magma_op, refa76_inst, refa76_op in H. discriminate H. Qed.

Lemma refa76_not2855 : ~ @Equation2855 Fin3 refa76_inst.
Proof. unfold Equation2855. intro H. specialize (H F3_2 F3_0). unfold magma_op, refa76_inst, refa76_op in H. discriminate H. Qed.

Lemma refa76_not2862 : ~ @Equation2862 Fin3 refa76_inst.
Proof. unfold Equation2862. intro H. specialize (H F3_2 F3_0). unfold magma_op, refa76_inst, refa76_op in H. discriminate H. Qed.

Lemma refa76_not2865 : ~ @Equation2865 Fin3 refa76_inst.
Proof. unfold Equation2865. intro H. specialize (H F3_2 F3_0). unfold magma_op, refa76_inst, refa76_op in H. discriminate H. Qed.

Lemma refa76_not2872 : ~ @Equation2872 Fin3 refa76_inst.
Proof. unfold Equation2872. intro H. specialize (H F3_2 F3_1). unfold magma_op, refa76_inst, refa76_op in H. discriminate H. Qed.

Lemma refa76_not2875 : ~ @Equation2875 Fin3 refa76_inst.
Proof. unfold Equation2875. intro H. specialize (H F3_2 F3_0). unfold magma_op, refa76_inst, refa76_op in H. discriminate H. Qed.

Lemma refa76_not2902 : ~ @Equation2902 Fin3 refa76_inst.
Proof. unfold Equation2902. intro H. specialize (H F3_2 F3_0). unfold magma_op, refa76_inst, refa76_op in H. discriminate H. Qed.

Lemma refa76_not2909 : ~ @Equation2909 Fin3 refa76_inst.
Proof. unfold Equation2909. intro H. specialize (H F3_2 F3_1). unfold magma_op, refa76_inst, refa76_op in H. discriminate H. Qed.

Lemma refa76_not2912 : ~ @Equation2912 Fin3 refa76_inst.
Proof. unfold Equation2912. intro H. specialize (H F3_2 F3_0). unfold magma_op, refa76_inst, refa76_op in H. discriminate H. Qed.

Lemma refa76_not2939 : ~ @Equation2939 Fin3 refa76_inst.
Proof. unfold Equation2939. intro H. specialize (H F3_2 F3_0). unfold magma_op, refa76_inst, refa76_op in H. discriminate H. Qed.

Lemma refa76_not2946 : ~ @Equation2946 Fin3 refa76_inst.
Proof. unfold Equation2946. intro H. specialize (H F3_2 F3_1). unfold magma_op, refa76_inst, refa76_op in H. discriminate H. Qed.

Lemma refa76_not2949 : ~ @Equation2949 Fin3 refa76_inst.
Proof. unfold Equation2949. intro H. specialize (H F3_2 F3_0). unfold magma_op, refa76_inst, refa76_op in H. discriminate H. Qed.

Lemma refa76_not3050 : ~ @Equation3050 Fin3 refa76_inst.
Proof. unfold Equation3050. intro H. specialize (H F3_2). unfold magma_op, refa76_inst, refa76_op in H. discriminate H. Qed.

Lemma refa76_not3255 : ~ @Equation3255 Fin3 refa76_inst.
Proof. unfold Equation3255. intro H. specialize (H F3_2 F3_0). unfold magma_op, refa76_inst, refa76_op in H. discriminate H. Qed.

Lemma refa76_not3261 : ~ @Equation3261 Fin3 refa76_inst.
Proof. unfold Equation3261. intro H. specialize (H F3_2 F3_0). unfold magma_op, refa76_inst, refa76_op in H. discriminate H. Qed.

Lemma refa76_not3271 : ~ @Equation3271 Fin3 refa76_inst.
Proof. unfold Equation3271. intro H. specialize (H F3_2 F3_0). unfold magma_op, refa76_inst, refa76_op in H. discriminate H. Qed.

Lemma refa76_not3281 : ~ @Equation3281 Fin3 refa76_inst.
Proof. unfold Equation3281. intro H. specialize (H F3_2 F3_0). unfold magma_op, refa76_inst, refa76_op in H. discriminate H. Qed.

Lemma refa76_not3326 : ~ @Equation3326 Fin3 refa76_inst.
Proof. unfold Equation3326. intro H. specialize (H F3_1 F3_2 F3_0). unfold magma_op, refa76_inst, refa76_op in H. discriminate H. Qed.

Lemma refa76_not3343 : ~ @Equation3343 Fin3 refa76_inst.
Proof. unfold Equation3343. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa76_inst, refa76_op in H. discriminate H. Qed.

Lemma refa76_not3346 : ~ @Equation3346 Fin3 refa76_inst.
Proof. unfold Equation3346. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa76_inst, refa76_op in H. discriminate H. Qed.

Lemma refa76_not3353 : ~ @Equation3353 Fin3 refa76_inst.
Proof. unfold Equation3353. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa76_inst, refa76_op in H. discriminate H. Qed.

Lemma refa76_not3456 : ~ @Equation3456 Fin3 refa76_inst.
Proof. unfold Equation3456. intro H. specialize (H F3_2). unfold magma_op, refa76_inst, refa76_op in H. discriminate H. Qed.

Lemma refa76_not3661 : ~ @Equation3661 Fin3 refa76_inst.
Proof. unfold Equation3661. intro H. specialize (H F3_2 F3_0). unfold magma_op, refa76_inst, refa76_op in H. discriminate H. Qed.

Lemma refa76_not3667 : ~ @Equation3667 Fin3 refa76_inst.
Proof. unfold Equation3667. intro H. specialize (H F3_2 F3_0). unfold magma_op, refa76_inst, refa76_op in H. discriminate H. Qed.

Lemma refa76_not3677 : ~ @Equation3677 Fin3 refa76_inst.
Proof. unfold Equation3677. intro H. specialize (H F3_2 F3_0). unfold magma_op, refa76_inst, refa76_op in H. discriminate H. Qed.

Lemma refa76_not3687 : ~ @Equation3687 Fin3 refa76_inst.
Proof. unfold Equation3687. intro H. specialize (H F3_2 F3_0). unfold magma_op, refa76_inst, refa76_op in H. discriminate H. Qed.

Lemma refa76_not3722 : ~ @Equation3722 Fin3 refa76_inst.
Proof. unfold Equation3722. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa76_inst, refa76_op in H. discriminate H. Qed.

Lemma refa76_not3725 : ~ @Equation3725 Fin3 refa76_inst.
Proof. unfold Equation3725. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa76_inst, refa76_op in H. discriminate H. Qed.

Lemma refa76_not3752 : ~ @Equation3752 Fin3 refa76_inst.
Proof. unfold Equation3752. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa76_inst, refa76_op in H. discriminate H. Qed.

Lemma refa76_not3759 : ~ @Equation3759 Fin3 refa76_inst.
Proof. unfold Equation3759. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa76_inst, refa76_op in H. discriminate H. Qed.

Lemma refa76_not3862 : ~ @Equation3862 Fin3 refa76_inst.
Proof. unfold Equation3862. intro H. specialize (H F3_2). unfold magma_op, refa76_inst, refa76_op in H. discriminate H. Qed.

Lemma refa76_not4065 : ~ @Equation4065 Fin3 refa76_inst.
Proof. unfold Equation4065. intro H. specialize (H F3_2). unfold magma_op, refa76_inst, refa76_op in H. discriminate H. Qed.

Lemma refa76_not4269 : ~ @Equation4269 Fin3 refa76_inst.
Proof. unfold Equation4269. intro H. specialize (H F3_2 F3_0). unfold magma_op, refa76_inst, refa76_op in H. discriminate H. Qed.

Lemma refa76_not4275 : ~ @Equation4275 Fin3 refa76_inst.
Proof. unfold Equation4275. intro H. specialize (H F3_2 F3_0). unfold magma_op, refa76_inst, refa76_op in H. discriminate H. Qed.

Lemma refa76_not4291 : ~ @Equation4291 Fin3 refa76_inst.
Proof. unfold Equation4291. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa76_inst, refa76_op in H. discriminate H. Qed.

Lemma refa76_not4314 : ~ @Equation4314 Fin3 refa76_inst.
Proof. unfold Equation4314. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa76_inst, refa76_op in H. discriminate H. Qed.

Lemma refa76_not4320 : ~ @Equation4320 Fin3 refa76_inst.
Proof. unfold Equation4320. intro H. specialize (H F3_2 F3_0). unfold magma_op, refa76_inst, refa76_op in H. discriminate H. Qed.

Lemma refa76_not4380 : ~ @Equation4380 Fin3 refa76_inst.
Proof. unfold Equation4380. intro H. specialize (H F3_2). unfold magma_op, refa76_inst, refa76_op in H. discriminate H. Qed.

Lemma refa76_not4584 : ~ @Equation4584 Fin3 refa76_inst.
Proof. unfold Equation4584. intro H. specialize (H F3_2 F3_1). unfold magma_op, refa76_inst, refa76_op in H. discriminate H. Qed.

Lemma refa76_not4587 : ~ @Equation4587 Fin3 refa76_inst.
Proof. unfold Equation4587. intro H. specialize (H F3_2 F3_0). unfold magma_op, refa76_inst, refa76_op in H. discriminate H. Qed.

Lemma refa76_not4590 : ~ @Equation4590 Fin3 refa76_inst.
Proof. unfold Equation4590. intro H. specialize (H F3_2 F3_1). unfold magma_op, refa76_inst, refa76_op in H. discriminate H. Qed.

Lemma refa76_not4599 : ~ @Equation4599 Fin3 refa76_inst.
Proof. unfold Equation4599. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa76_inst, refa76_op in H. discriminate H. Qed.

Lemma refa76_not4635 : ~ @Equation4635 Fin3 refa76_inst.
Proof. unfold Equation4635. intro H. specialize (H F3_2 F3_0). unfold magma_op, refa76_inst, refa76_op in H. discriminate H. Qed.

(** ---- refa760 (Fin7) ---- *)

Definition refa760_op (x y : Fin7) : Fin7 :=
  match x, y with
  | F7_0, F7_0 => F7_1 | F7_0, F7_1 => F7_2 | F7_0, F7_2 => F7_3 | F7_0, F7_3 => F7_6 | F7_0, F7_4 => F7_6 | F7_0, F7_5 => F7_2 | F7_0, F7_6 => F7_6
  | F7_1, F7_0 => F7_4 | F7_1, F7_1 => F7_6 | F7_1, F7_2 => F7_2 | F7_1, F7_3 => F7_3 | F7_1, F7_4 => F7_6 | F7_1, F7_5 => F7_5 | F7_1, F7_6 => F7_6
  | F7_2, F7_0 => F7_0 | F7_2, F7_1 => F7_1 | F7_2, F7_2 => F7_5 | F7_2, F7_3 => F7_6 | F7_2, F7_4 => F7_4 | F7_2, F7_5 => F7_6 | F7_2, F7_6 => F7_6
  | F7_3, F7_0 => F7_4 | F7_3, F7_1 => F7_1 | F7_3, F7_2 => F7_3 | F7_3, F7_3 => F7_6 | F7_3, F7_4 => F7_4 | F7_3, F7_5 => F7_4 | F7_3, F7_6 => F7_6
  | F7_4, F7_0 => F7_4 | F7_4, F7_1 => F7_6 | F7_4, F7_2 => F7_2 | F7_4, F7_3 => F7_3 | F7_4, F7_4 => F7_6 | F7_4, F7_5 => F7_5 | F7_4, F7_6 => F7_6
  | F7_5, F7_0 => F7_0 | F7_5, F7_1 => F7_1 | F7_5, F7_2 => F7_5 | F7_5, F7_3 => F7_6 | F7_5, F7_4 => F7_4 | F7_5, F7_5 => F7_6 | F7_5, F7_6 => F7_6
  | F7_6, F7_0 => F7_0 | F7_6, F7_1 => F7_1 | F7_6, F7_2 => F7_2 | F7_6, F7_3 => F7_3 | F7_6, F7_4 => F7_4 | F7_6, F7_5 => F7_5 | F7_6, F7_6 => F7_6
  end.

#[local] Instance refa760_inst : Magma Fin7 := {| magma_op := refa760_op |}.

Lemma refa760_sat2778 : @Equation2778 Fin7 refa760_inst.
Proof. unfold Equation2778, magma_op, refa760_inst, refa760_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa760_not2238 : ~ @Equation2238 Fin7 refa760_inst.
Proof. unfold Equation2238. intro H. specialize (H F7_0). unfold magma_op, refa760_inst, refa760_op in H. discriminate H. Qed.

Lemma refa760_not4065 : ~ @Equation4065 Fin7 refa760_inst.
Proof. unfold Equation4065. intro H. specialize (H F7_0). unfold magma_op, refa760_inst, refa760_op in H. discriminate H. Qed.

(** ---- refa761 (Fin5) ---- *)

Definition refa761_op (x y : Fin5) : Fin5 :=
  match x, y with
  | F5_0, F5_0 => F5_1 | F5_0, F5_1 => F5_4 | F5_0, F5_2 => F5_3 | F5_0, F5_3 => F5_4 | F5_0, F5_4 => F5_4
  | F5_1, F5_0 => F5_2 | F5_1, F5_1 => F5_4 | F5_1, F5_2 => F5_3 | F5_1, F5_3 => F5_3 | F5_1, F5_4 => F5_4
  | F5_2, F5_0 => F5_1 | F5_2, F5_1 => F5_4 | F5_2, F5_2 => F5_3 | F5_2, F5_3 => F5_4 | F5_2, F5_4 => F5_4
  | F5_3, F5_0 => F5_1 | F5_3, F5_1 => F5_1 | F5_3, F5_2 => F5_0 | F5_3, F5_3 => F5_4 | F5_3, F5_4 => F5_4
  | F5_4, F5_0 => F5_0 | F5_4, F5_1 => F5_1 | F5_4, F5_2 => F5_2 | F5_4, F5_3 => F5_3 | F5_4, F5_4 => F5_4
  end.

#[local] Instance refa761_inst : Magma Fin5 := {| magma_op := refa761_op |}.

Lemma refa761_sat2778 : @Equation2778 Fin5 refa761_inst.
Proof. unfold Equation2778, magma_op, refa761_inst, refa761_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa761_not2441 : ~ @Equation2441 Fin5 refa761_inst.
Proof. unfold Equation2441. intro H. specialize (H F5_0). unfold magma_op, refa761_inst, refa761_op in H. discriminate H. Qed.

(** ---- refa762 (Fin6) ---- *)

Definition refa762_op (x y : Fin6) : Fin6 :=
  match x, y with
  | F6_0, F6_0 => F6_0 | F6_0, F6_1 => F6_4 | F6_0, F6_2 => F6_3 | F6_0, F6_3 => F6_3 | F6_0, F6_4 => F6_4 | F6_0, F6_5 => F6_5
  | F6_1, F6_0 => F6_2 | F6_1, F6_1 => F6_1 | F6_1, F6_2 => F6_5 | F6_1, F6_3 => F6_3 | F6_1, F6_4 => F6_4 | F6_1, F6_5 => F6_2
  | F6_2, F6_0 => F6_5 | F6_2, F6_1 => F6_4 | F6_2, F6_2 => F6_2 | F6_2, F6_3 => F6_3 | F6_2, F6_4 => F6_4 | F6_2, F6_5 => F6_5
  | F6_3, F6_0 => F6_4 | F6_3, F6_1 => F6_4 | F6_3, F6_2 => F6_2 | F6_3, F6_3 => F6_3 | F6_3, F6_4 => F6_5 | F6_3, F6_5 => F6_5
  | F6_4, F6_0 => F6_5 | F6_4, F6_1 => F6_1 | F6_4, F6_2 => F6_5 | F6_4, F6_3 => F6_3 | F6_4, F6_4 => F6_4 | F6_4, F6_5 => F6_5
  | F6_5, F6_0 => F6_0 | F6_5, F6_1 => F6_1 | F6_5, F6_2 => F6_2 | F6_5, F6_3 => F6_3 | F6_5, F6_4 => F6_4 | F6_5, F6_5 => F6_5
  end.

#[local] Instance refa762_inst : Magma Fin6 := {| magma_op := refa762_op |}.

Lemma refa762_sat2804 : @Equation2804 Fin6 refa762_inst.
Proof. unfold Equation2804, magma_op, refa762_inst, refa762_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa762_not2862 : ~ @Equation2862 Fin6 refa762_inst.
Proof. unfold Equation2862. intro H. specialize (H F6_0 F6_1). unfold magma_op, refa762_inst, refa762_op in H. discriminate H. Qed.

(** ---- refa763 (Fin5) ---- *)

Definition refa763_op (x y : Fin5) : Fin5 :=
  match x, y with
  | F5_0, F5_0 => F5_0 | F5_0, F5_1 => F5_3 | F5_0, F5_2 => F5_0 | F5_0, F5_3 => F5_0 | F5_0, F5_4 => F5_2
  | F5_1, F5_0 => F5_4 | F5_1, F5_1 => F5_1 | F5_1, F5_2 => F5_1 | F5_1, F5_3 => F5_1 | F5_1, F5_4 => F5_1
  | F5_2, F5_0 => F5_2 | F5_2, F5_1 => F5_2 | F5_2, F5_2 => F5_2 | F5_2, F5_3 => F5_2 | F5_2, F5_4 => F5_0
  | F5_3, F5_0 => F5_3 | F5_3, F5_1 => F5_0 | F5_3, F5_2 => F5_4 | F5_3, F5_3 => F5_3 | F5_3, F5_4 => F5_3
  | F5_4, F5_0 => F5_1 | F5_4, F5_1 => F5_4 | F5_4, F5_2 => F5_3 | F5_4, F5_3 => F5_4 | F5_4, F5_4 => F5_4
  end.

#[local] Instance refa763_inst : Magma Fin5 := {| magma_op := refa763_op |}.

Lemma refa763_sat2860 : @Equation2860 Fin5 refa763_inst.
Proof. unfold Equation2860, magma_op, refa763_inst, refa763_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa763_not3460 : ~ @Equation3460 Fin5 refa763_inst.
Proof. unfold Equation3460. intro H. specialize (H F5_0 F5_1 F5_2). unfold magma_op, refa763_inst, refa763_op in H. discriminate H. Qed.

Lemma refa763_not4673 : ~ @Equation4673 Fin5 refa763_inst.
Proof. unfold Equation4673. intro H. specialize (H F5_0 F5_1 F5_2). unfold magma_op, refa763_inst, refa763_op in H. discriminate H. Qed.

(** ---- refa764 (Fin5) ---- *)

Definition refa764_op (x y : Fin5) : Fin5 :=
  match x, y with
  | F5_0, F5_0 => F5_4 | F5_0, F5_1 => F5_1 | F5_0, F5_2 => F5_4 | F5_0, F5_3 => F5_4 | F5_0, F5_4 => F5_4
  | F5_1, F5_0 => F5_1 | F5_1, F5_1 => F5_4 | F5_1, F5_2 => F5_2 | F5_1, F5_3 => F5_2 | F5_1, F5_4 => F5_2
  | F5_2, F5_0 => F5_0 | F5_2, F5_1 => F5_0 | F5_2, F5_2 => F5_3 | F5_2, F5_3 => F5_3 | F5_2, F5_4 => F5_3
  | F5_3, F5_0 => F5_1 | F5_3, F5_1 => F5_1 | F5_3, F5_2 => F5_4 | F5_3, F5_3 => F5_4 | F5_3, F5_4 => F5_4
  | F5_4, F5_0 => F5_2 | F5_4, F5_1 => F5_2 | F5_4, F5_2 => F5_2 | F5_4, F5_3 => F5_2 | F5_4, F5_4 => F5_2
  end.

#[local] Instance refa764_inst : Magma Fin5 := {| magma_op := refa764_op |}.

Lemma refa764_sat2878 : @Equation2878 Fin5 refa764_inst.
Proof. unfold Equation2878, magma_op, refa764_inst, refa764_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa764_not2852 : ~ @Equation2852 Fin5 refa764_inst.
Proof. unfold Equation2852. intro H. specialize (H F5_0 F5_1). unfold magma_op, refa764_inst, refa764_op in H. discriminate H. Qed.

(** ---- refa765 (Fin6) ---- *)

Definition refa765_op (x y : Fin6) : Fin6 :=
  match x, y with
  | F6_0, F6_0 => F6_1 | F6_0, F6_1 => F6_1 | F6_0, F6_2 => F6_4 | F6_0, F6_3 => F6_1 | F6_0, F6_4 => F6_1 | F6_0, F6_5 => F6_4
  | F6_1, F6_0 => F6_2 | F6_1, F6_1 => F6_5 | F6_1, F6_2 => F6_5 | F6_1, F6_3 => F6_2 | F6_1, F6_4 => F6_5 | F6_1, F6_5 => F6_5
  | F6_2, F6_0 => F6_0 | F6_2, F6_1 => F6_3 | F6_2, F6_2 => F6_0 | F6_2, F6_3 => F6_0 | F6_2, F6_4 => F6_3 | F6_2, F6_5 => F6_0
  | F6_3, F6_0 => F6_4 | F6_3, F6_1 => F6_4 | F6_3, F6_2 => F6_1 | F6_3, F6_3 => F6_4 | F6_3, F6_4 => F6_4 | F6_3, F6_5 => F6_1
  | F6_4, F6_0 => F6_5 | F6_4, F6_1 => F6_2 | F6_4, F6_2 => F6_2 | F6_4, F6_3 => F6_5 | F6_4, F6_4 => F6_2 | F6_4, F6_5 => F6_2
  | F6_5, F6_0 => F6_3 | F6_5, F6_1 => F6_0 | F6_5, F6_2 => F6_3 | F6_5, F6_3 => F6_3 | F6_5, F6_4 => F6_0 | F6_5, F6_5 => F6_3
  end.

#[local] Instance refa765_inst : Magma Fin6 := {| magma_op := refa765_op |}.

Lemma refa765_sat2883 : @Equation2883 Fin6 refa765_inst.
Proof. unfold Equation2883, magma_op, refa765_inst, refa765_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa765_not2035 : ~ @Equation2035 Fin6 refa765_inst.
Proof. unfold Equation2035. intro H. specialize (H F6_0). unfold magma_op, refa765_inst, refa765_op in H. discriminate H. Qed.

Lemma refa765_not3456 : ~ @Equation3456 Fin6 refa765_inst.
Proof. unfold Equation3456. intro H. specialize (H F6_0). unfold magma_op, refa765_inst, refa765_op in H. discriminate H. Qed.

(** ---- refa766 (Fin7) ---- *)

Definition refa766_op (x y : Fin7) : Fin7 :=
  match x, y with
  | F7_0, F7_0 => F7_1 | F7_0, F7_1 => F7_5 | F7_0, F7_2 => F7_5 | F7_0, F7_3 => F7_3 | F7_0, F7_4 => F7_5 | F7_0, F7_5 => F7_5 | F7_0, F7_6 => F7_5
  | F7_1, F7_0 => F7_2 | F7_1, F7_1 => F7_2 | F7_1, F7_2 => F7_2 | F7_1, F7_3 => F7_2 | F7_1, F7_4 => F7_2 | F7_1, F7_5 => F7_2 | F7_1, F7_6 => F7_6
  | F7_2, F7_0 => F7_3 | F7_2, F7_1 => F7_3 | F7_2, F7_2 => F7_3 | F7_2, F7_3 => F7_3 | F7_2, F7_4 => F7_4 | F7_2, F7_5 => F7_5 | F7_2, F7_6 => F7_3
  | F7_3, F7_0 => F7_6 | F7_3, F7_1 => F7_1 | F7_3, F7_2 => F7_6 | F7_3, F7_3 => F7_6 | F7_3, F7_4 => F7_6 | F7_3, F7_5 => F7_6 | F7_3, F7_6 => F7_6
  | F7_4, F7_0 => F7_1 | F7_4, F7_1 => F7_1 | F7_4, F7_2 => F7_1 | F7_4, F7_3 => F7_3 | F7_4, F7_4 => F7_1 | F7_4, F7_5 => F7_5 | F7_4, F7_6 => F7_1
  | F7_5, F7_0 => F7_6 | F7_5, F7_1 => F7_6 | F7_5, F7_2 => F7_6 | F7_5, F7_3 => F7_6 | F7_5, F7_4 => F7_6 | F7_5, F7_5 => F7_6 | F7_5, F7_6 => F7_6
  | F7_6, F7_0 => F7_0 | F7_6, F7_1 => F7_4 | F7_6, F7_2 => F7_2 | F7_6, F7_3 => F7_4 | F7_6, F7_4 => F7_4 | F7_6, F7_5 => F7_4 | F7_6, F7_6 => F7_4
  end.

#[local] Instance refa766_inst : Magma Fin7 := {| magma_op := refa766_op |}.

Lemma refa766_sat2886 : @Equation2886 Fin7 refa766_inst.
Proof. unfold Equation2886, magma_op, refa766_inst, refa766_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa766_not255 : ~ @Equation255 Fin7 refa766_inst.
Proof. unfold Equation255. intro H. specialize (H F7_0). unfold magma_op, refa766_inst, refa766_op in H. discriminate H. Qed.

Lemma refa766_not2035 : ~ @Equation2035 Fin7 refa766_inst.
Proof. unfold Equation2035. intro H. specialize (H F7_0). unfold magma_op, refa766_inst, refa766_op in H. discriminate H. Qed.

Lemma refa766_not2644 : ~ @Equation2644 Fin7 refa766_inst.
Proof. unfold Equation2644. intro H. specialize (H F7_0). unfold magma_op, refa766_inst, refa766_op in H. discriminate H. Qed.

Lemma refa766_not2849 : ~ @Equation2849 Fin7 refa766_inst.
Proof. unfold Equation2849. intro H. specialize (H F7_1 F7_5). unfold magma_op, refa766_inst, refa766_op in H. discriminate H. Qed.

Lemma refa766_not2855 : ~ @Equation2855 Fin7 refa766_inst.
Proof. unfold Equation2855. intro H. specialize (H F7_1 F7_5). unfold magma_op, refa766_inst, refa766_op in H. discriminate H. Qed.

Lemma refa766_not3253 : ~ @Equation3253 Fin7 refa766_inst.
Proof. unfold Equation3253. intro H. specialize (H F7_0). unfold magma_op, refa766_inst, refa766_op in H. discriminate H. Qed.

Lemma refa766_not3456 : ~ @Equation3456 Fin7 refa766_inst.
Proof. unfold Equation3456. intro H. specialize (H F7_0). unfold magma_op, refa766_inst, refa766_op in H. discriminate H. Qed.

(** ---- refa767 (Fin8) ---- *)

Definition refa767_op (x y : Fin8) : Fin8 :=
  match x, y with
  | F8_0, F8_0 => F8_0 | F8_0, F8_1 => F8_2 | F8_0, F8_2 => F8_3 | F8_0, F8_3 => F8_5 | F8_0, F8_4 => F8_0 | F8_0, F8_5 => F8_5 | F8_0, F8_6 => F8_6 | F8_0, F8_7 => F8_7
  | F8_1, F8_0 => F8_4 | F8_1, F8_1 => F8_1 | F8_1, F8_2 => F8_5 | F8_1, F8_3 => F8_1 | F8_1, F8_4 => F8_4 | F8_1, F8_5 => F8_5 | F8_1, F8_6 => F8_1 | F8_1, F8_7 => F8_5
  | F8_2, F8_0 => F8_4 | F8_2, F8_1 => F8_6 | F8_2, F8_2 => F8_2 | F8_2, F8_3 => F8_6 | F8_2, F8_4 => F8_4 | F8_2, F8_5 => F8_2 | F8_2, F8_6 => F8_6 | F8_2, F8_7 => F8_2
  | F8_3, F8_0 => F8_4 | F8_3, F8_1 => F8_7 | F8_3, F8_2 => F8_7 | F8_3, F8_3 => F8_3 | F8_3, F8_4 => F8_4 | F8_3, F8_5 => F8_7 | F8_3, F8_6 => F8_3 | F8_3, F8_7 => F8_7
  | F8_4, F8_0 => F8_4 | F8_4, F8_1 => F8_1 | F8_4, F8_2 => F8_2 | F8_4, F8_3 => F8_3 | F8_4, F8_4 => F8_4 | F8_4, F8_5 => F8_5 | F8_4, F8_6 => F8_6 | F8_4, F8_7 => F8_7
  | F8_5, F8_0 => F8_0 | F8_5, F8_1 => F8_1 | F8_5, F8_2 => F8_5 | F8_5, F8_3 => F8_5 | F8_5, F8_4 => F8_4 | F8_5, F8_5 => F8_5 | F8_5, F8_6 => F8_6 | F8_5, F8_7 => F8_5
  | F8_6, F8_0 => F8_0 | F8_6, F8_1 => F8_6 | F8_6, F8_2 => F8_2 | F8_6, F8_3 => F8_6 | F8_6, F8_4 => F8_4 | F8_6, F8_5 => F8_5 | F8_6, F8_6 => F8_6 | F8_6, F8_7 => F8_2
  | F8_7, F8_0 => F8_0 | F8_7, F8_1 => F8_7 | F8_7, F8_2 => F8_7 | F8_7, F8_3 => F8_3 | F8_7, F8_4 => F8_4 | F8_7, F8_5 => F8_7 | F8_7, F8_6 => F8_3 | F8_7, F8_7 => F8_7
  end.

#[local] Instance refa767_inst : Magma Fin8 := {| magma_op := refa767_op |}.

Lemma refa767_sat2890 : @Equation2890 Fin8 refa767_inst.
Proof. unfold Equation2890, magma_op, refa767_inst, refa767_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa767_not2646 : ~ @Equation2646 Fin8 refa767_inst.
Proof. unfold Equation2646. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa767_inst, refa767_op in H. discriminate H. Qed.

Lemma refa767_not2652 : ~ @Equation2652 Fin8 refa767_inst.
Proof. unfold Equation2652. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa767_inst, refa767_op in H. discriminate H. Qed.

Lemma refa767_not2659 : ~ @Equation2659 Fin8 refa767_inst.
Proof. unfold Equation2659. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa767_inst, refa767_op in H. discriminate H. Qed.

Lemma refa767_not2662 : ~ @Equation2662 Fin8 refa767_inst.
Proof. unfold Equation2662. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa767_inst, refa767_op in H. discriminate H. Qed.

Lemma refa767_not2669 : ~ @Equation2669 Fin8 refa767_inst.
Proof. unfold Equation2669. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa767_inst, refa767_op in H. discriminate H. Qed.

Lemma refa767_not2849 : ~ @Equation2849 Fin8 refa767_inst.
Proof. unfold Equation2849. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa767_inst, refa767_op in H. discriminate H. Qed.

Lemma refa767_not2852 : ~ @Equation2852 Fin8 refa767_inst.
Proof. unfold Equation2852. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa767_inst, refa767_op in H. discriminate H. Qed.

Lemma refa767_not2865 : ~ @Equation2865 Fin8 refa767_inst.
Proof. unfold Equation2865. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa767_inst, refa767_op in H. discriminate H. Qed.

Lemma refa767_not2872 : ~ @Equation2872 Fin8 refa767_inst.
Proof. unfold Equation2872. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa767_inst, refa767_op in H. discriminate H. Qed.

Lemma refa767_not3306 : ~ @Equation3306 Fin8 refa767_inst.
Proof. unfold Equation3306. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa767_inst, refa767_op in H. discriminate H. Qed.

Lemma refa767_not4599 : ~ @Equation4599 Fin8 refa767_inst.
Proof. unfold Equation4599. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa767_inst, refa767_op in H. discriminate H. Qed.

Lemma refa767_not4631 : ~ @Equation4631 Fin8 refa767_inst.
Proof. unfold Equation4631. intro H. specialize (H F8_0 F8_0 F8_1). unfold magma_op, refa767_inst, refa767_op in H. discriminate H. Qed.

(** ---- refa768 (Fin6) ---- *)

Definition refa768_op (x y : Fin6) : Fin6 :=
  match x, y with
  | F6_0, F6_0 => F6_0 | F6_0, F6_1 => F6_2 | F6_0, F6_2 => F6_5 | F6_0, F6_3 => F6_0 | F6_0, F6_4 => F6_4 | F6_0, F6_5 => F6_5
  | F6_1, F6_0 => F6_3 | F6_1, F6_1 => F6_1 | F6_1, F6_2 => F6_3 | F6_1, F6_3 => F6_3 | F6_1, F6_4 => F6_1 | F6_1, F6_5 => F6_3
  | F6_2, F6_0 => F6_2 | F6_2, F6_1 => F6_4 | F6_2, F6_2 => F6_2 | F6_2, F6_3 => F6_2 | F6_2, F6_4 => F6_4 | F6_2, F6_5 => F6_2
  | F6_3, F6_0 => F6_3 | F6_3, F6_1 => F6_1 | F6_3, F6_2 => F6_3 | F6_3, F6_3 => F6_3 | F6_3, F6_4 => F6_1 | F6_3, F6_5 => F6_3
  | F6_4, F6_0 => F6_0 | F6_4, F6_1 => F6_4 | F6_4, F6_2 => F6_2 | F6_4, F6_3 => F6_0 | F6_4, F6_4 => F6_4 | F6_4, F6_5 => F6_5
  | F6_5, F6_0 => F6_0 | F6_5, F6_1 => F6_4 | F6_5, F6_2 => F6_5 | F6_5, F6_3 => F6_0 | F6_5, F6_4 => F6_4 | F6_5, F6_5 => F6_5
  end.

#[local] Instance refa768_inst : Magma Fin6 := {| magma_op := refa768_op |}.

Lemma refa768_sat2890 : @Equation2890 Fin6 refa768_inst.
Proof. unfold Equation2890, magma_op, refa768_inst, refa768_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa768_not257 : ~ @Equation257 Fin6 refa768_inst.
Proof. unfold Equation257. intro H. specialize (H F6_0 F6_1). unfold magma_op, refa768_inst, refa768_op in H. discriminate H. Qed.

Lemma refa768_not260 : ~ @Equation260 Fin6 refa768_inst.
Proof. unfold Equation260. intro H. specialize (H F6_0 F6_1). unfold magma_op, refa768_inst, refa768_op in H. discriminate H. Qed.

Lemma refa768_not309 : ~ @Equation309 Fin6 refa768_inst.
Proof. unfold Equation309. intro H. specialize (H F6_0 F6_2). unfold magma_op, refa768_inst, refa768_op in H. discriminate H. Qed.

Lemma refa768_not323 : ~ @Equation323 Fin6 refa768_inst.
Proof. unfold Equation323. intro H. specialize (H F6_0 F6_1). unfold magma_op, refa768_inst, refa768_op in H. discriminate H. Qed.

(** ---- refa769 (Fin7) ---- *)

Definition refa769_op (x y : Fin7) : Fin7 :=
  match x, y with
  | F7_0, F7_0 => F7_0 | F7_0, F7_1 => F7_2 | F7_0, F7_2 => F7_2 | F7_0, F7_3 => F7_0 | F7_0, F7_4 => F7_0 | F7_0, F7_5 => F7_0 | F7_0, F7_6 => F7_0
  | F7_1, F7_0 => F7_3 | F7_1, F7_1 => F7_3 | F7_1, F7_2 => F7_3 | F7_1, F7_3 => F7_3 | F7_1, F7_4 => F7_3 | F7_1, F7_5 => F7_3 | F7_1, F7_6 => F7_3
  | F7_2, F7_0 => F7_0 | F7_2, F7_1 => F7_2 | F7_2, F7_2 => F7_2 | F7_2, F7_3 => F7_4 | F7_2, F7_4 => F7_4 | F7_2, F7_5 => F7_0 | F7_2, F7_6 => F7_0
  | F7_3, F7_0 => F7_5 | F7_3, F7_1 => F7_5 | F7_3, F7_2 => F7_5 | F7_3, F7_3 => F7_5 | F7_3, F7_4 => F7_5 | F7_3, F7_5 => F7_5 | F7_3, F7_6 => F7_5
  | F7_4, F7_0 => F7_4 | F7_4, F7_1 => F7_4 | F7_4, F7_2 => F7_2 | F7_4, F7_3 => F7_4 | F7_4, F7_4 => F7_4 | F7_4, F7_5 => F7_4 | F7_4, F7_6 => F7_4
  | F7_5, F7_0 => F7_6 | F7_5, F7_1 => F7_1 | F7_5, F7_2 => F7_6 | F7_5, F7_3 => F7_6 | F7_5, F7_4 => F7_6 | F7_5, F7_5 => F7_6 | F7_5, F7_6 => F7_6
  | F7_6, F7_0 => F7_3 | F7_6, F7_1 => F7_3 | F7_6, F7_2 => F7_3 | F7_6, F7_3 => F7_3 | F7_6, F7_4 => F7_3 | F7_6, F7_5 => F7_3 | F7_6, F7_6 => F7_3
  end.

#[local] Instance refa769_inst : Magma Fin7 := {| magma_op := refa769_op |}.

Lemma refa769_sat2890 : @Equation2890 Fin7 refa769_inst.
Proof. unfold Equation2890, magma_op, refa769_inst, refa769_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa769_not2672 : ~ @Equation2672 Fin7 refa769_inst.
Proof. unfold Equation2672. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa769_inst, refa769_op in H. discriminate H. Qed.

(** ---- refa77 (Fin3) ---- *)

Definition refa77_op (x y : Fin3) : Fin3 :=
  match x, y with
  | F3_0, F3_0 => F3_0 | F3_0, F3_1 => F3_0 | F3_0, F3_2 => F3_2
  | F3_1, F3_0 => F3_1 | F3_1, F3_1 => F3_1 | F3_1, F3_2 => F3_2
  | F3_2, F3_0 => F3_2 | F3_2, F3_1 => F3_2 | F3_2, F3_2 => F3_0
  end.

#[local] Instance refa77_inst : Magma Fin3 := {| magma_op := refa77_op |}.

Lemma refa77_sat1432 : @Equation1432 Fin3 refa77_inst.
Proof. unfold Equation1432, magma_op, refa77_inst, refa77_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa77_sat2652 : @Equation2652 Fin3 refa77_inst.
Proof. unfold Equation2652, magma_op, refa77_inst, refa77_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa77_not1442 : ~ @Equation1442 Fin3 refa77_inst.
Proof. unfold Equation1442. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa77_inst, refa77_op in H. discriminate H. Qed.

Lemma refa77_not2662 : ~ @Equation2662 Fin3 refa77_inst.
Proof. unfold Equation2662. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa77_inst, refa77_op in H. discriminate H. Qed.

(** ---- refa770 (Fin5) ---- *)

Definition refa770_op (x y : Fin5) : Fin5 :=
  match x, y with
  | F5_0, F5_0 => F5_1 | F5_0, F5_1 => F5_2 | F5_0, F5_2 => F5_2 | F5_0, F5_3 => F5_1 | F5_0, F5_4 => F5_2
  | F5_1, F5_0 => F5_4 | F5_1, F5_1 => F5_2 | F5_1, F5_2 => F5_2 | F5_1, F5_3 => F5_4 | F5_1, F5_4 => F5_4
  | F5_2, F5_0 => F5_4 | F5_2, F5_1 => F5_3 | F5_2, F5_2 => F5_2 | F5_2, F5_3 => F5_3 | F5_2, F5_4 => F5_4
  | F5_3, F5_0 => F5_4 | F5_3, F5_1 => F5_1 | F5_3, F5_2 => F5_2 | F5_3, F5_3 => F5_3 | F5_3, F5_4 => F5_4
  | F5_4, F5_0 => F5_0 | F5_4, F5_1 => F5_3 | F5_4, F5_2 => F5_2 | F5_4, F5_3 => F5_3 | F5_4, F5_4 => F5_4
  end.

#[local] Instance refa770_inst : Magma Fin5 := {| magma_op := refa770_op |}.

Lemma refa770_sat2919 : @Equation2919 Fin5 refa770_inst.
Proof. unfold Equation2919, magma_op, refa770_inst, refa770_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa770_not3659 : ~ @Equation3659 Fin5 refa770_inst.
Proof. unfold Equation3659. intro H. specialize (H F5_0). unfold magma_op, refa770_inst, refa770_op in H. discriminate H. Qed.

(** ---- refa771 (Fin5) ---- *)

Definition refa771_op (x y : Fin5) : Fin5 :=
  match x, y with
  | F5_0, F5_0 => F5_1 | F5_0, F5_1 => F5_4 | F5_0, F5_2 => F5_2 | F5_0, F5_3 => F5_3 | F5_0, F5_4 => F5_0
  | F5_1, F5_0 => F5_2 | F5_1, F5_1 => F5_1 | F5_1, F5_2 => F5_3 | F5_1, F5_3 => F5_4 | F5_1, F5_4 => F5_2
  | F5_2, F5_0 => F5_0 | F5_2, F5_1 => F5_3 | F5_2, F5_2 => F5_1 | F5_2, F5_3 => F5_2 | F5_2, F5_4 => F5_4
  | F5_3, F5_0 => F5_0 | F5_3, F5_1 => F5_2 | F5_3, F5_2 => F5_4 | F5_3, F5_3 => F5_3 | F5_3, F5_4 => F5_1
  | F5_4, F5_0 => F5_3 | F5_4, F5_1 => F5_4 | F5_4, F5_2 => F5_2 | F5_4, F5_3 => F5_1 | F5_4, F5_4 => F5_3
  end.

#[local] Instance refa771_inst : Magma Fin5 := {| magma_op := refa771_op |}.

Lemma refa771_sat2939 : @Equation2939 Fin5 refa771_inst.
Proof. unfold Equation2939, magma_op, refa771_inst, refa771_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa771_not99 : ~ @Equation99 Fin5 refa771_inst.
Proof. unfold Equation99. intro H. specialize (H F5_0). unfold magma_op, refa771_inst, refa771_op in H. discriminate H. Qed.

Lemma refa771_not2035 : ~ @Equation2035 Fin5 refa771_inst.
Proof. unfold Equation2035. intro H. specialize (H F5_0). unfold magma_op, refa771_inst, refa771_op in H. discriminate H. Qed.

(** ---- refa772 (Fin5) ---- *)

Definition refa772_op (x y : Fin5) : Fin5 :=
  match x, y with
  | F5_0, F5_0 => F5_1 | F5_0, F5_1 => F5_2 | F5_0, F5_2 => F5_2 | F5_0, F5_3 => F5_1 | F5_0, F5_4 => F5_4
  | F5_1, F5_0 => F5_3 | F5_1, F5_1 => F5_1 | F5_1, F5_2 => F5_2 | F5_1, F5_3 => F5_4 | F5_1, F5_4 => F5_0
  | F5_2, F5_0 => F5_3 | F5_2, F5_1 => F5_1 | F5_2, F5_2 => F5_2 | F5_2, F5_3 => F5_4 | F5_2, F5_4 => F5_0
  | F5_3, F5_0 => F5_0 | F5_3, F5_1 => F5_2 | F5_3, F5_2 => F5_2 | F5_3, F5_3 => F5_1 | F5_3, F5_4 => F5_2
  | F5_4, F5_0 => F5_1 | F5_4, F5_1 => F5_1 | F5_4, F5_2 => F5_2 | F5_4, F5_3 => F5_3 | F5_4, F5_4 => F5_2
  end.

#[local] Instance refa772_inst : Magma Fin5 := {| magma_op := refa772_op |}.

Lemma refa772_sat2990 : @Equation2990 Fin5 refa772_inst.
Proof. unfold Equation2990, magma_op, refa772_inst, refa772_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa772_not3253 : ~ @Equation3253 Fin5 refa772_inst.
Proof. unfold Equation3253. intro H. specialize (H F5_0). unfold magma_op, refa772_inst, refa772_op in H. discriminate H. Qed.

Lemma refa772_not3456 : ~ @Equation3456 Fin5 refa772_inst.
Proof. unfold Equation3456. intro H. specialize (H F5_3). unfold magma_op, refa772_inst, refa772_op in H. discriminate H. Qed.

Lemma refa772_not3664 : ~ @Equation3664 Fin5 refa772_inst.
Proof. unfold Equation3664. intro H. specialize (H F5_1 F5_0). unfold magma_op, refa772_inst, refa772_op in H. discriminate H. Qed.

Lemma refa772_not3674 : ~ @Equation3674 Fin5 refa772_inst.
Proof. unfold Equation3674. intro H. specialize (H F5_0 F5_1). unfold magma_op, refa772_inst, refa772_op in H. discriminate H. Qed.

Lemma refa772_not3677 : ~ @Equation3677 Fin5 refa772_inst.
Proof. unfold Equation3677. intro H. specialize (H F5_1 F5_0). unfold magma_op, refa772_inst, refa772_op in H. discriminate H. Qed.

Lemma refa772_not4320 : ~ @Equation4320 Fin5 refa772_inst.
Proof. unfold Equation4320. intro H. specialize (H F5_0 F5_3). unfold magma_op, refa772_inst, refa772_op in H. discriminate H. Qed.

(** ---- refa773 (Fin6) ---- *)

Definition refa773_op (x y : Fin6) : Fin6 :=
  match x, y with
  | F6_0, F6_0 => F6_1 | F6_0, F6_1 => F6_1 | F6_0, F6_2 => F6_1 | F6_0, F6_3 => F6_3 | F6_0, F6_4 => F6_3 | F6_0, F6_5 => F6_5
  | F6_1, F6_0 => F6_2 | F6_1, F6_1 => F6_4 | F6_1, F6_2 => F6_2 | F6_1, F6_3 => F6_3 | F6_1, F6_4 => F6_4 | F6_1, F6_5 => F6_4
  | F6_2, F6_0 => F6_0 | F6_2, F6_1 => F6_1 | F6_2, F6_2 => F6_2 | F6_2, F6_3 => F6_3 | F6_2, F6_4 => F6_4 | F6_2, F6_5 => F6_5
  | F6_3, F6_0 => F6_0 | F6_3, F6_1 => F6_1 | F6_3, F6_2 => F6_2 | F6_3, F6_3 => F6_3 | F6_3, F6_4 => F6_4 | F6_3, F6_5 => F6_5
  | F6_4, F6_0 => F6_0 | F6_4, F6_1 => F6_5 | F6_4, F6_2 => F6_2 | F6_4, F6_3 => F6_0 | F6_4, F6_4 => F6_0 | F6_4, F6_5 => F6_3
  | F6_5, F6_0 => F6_0 | F6_5, F6_1 => F6_1 | F6_5, F6_2 => F6_2 | F6_5, F6_3 => F6_3 | F6_5, F6_4 => F6_4 | F6_5, F6_5 => F6_5
  end.

#[local] Instance refa773_inst : Magma Fin6 := {| magma_op := refa773_op |}.

Lemma refa773_sat2994 : @Equation2994 Fin6 refa773_inst.
Proof. unfold Equation2994, magma_op, refa773_inst, refa773_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa773_not47 : ~ @Equation47 Fin6 refa773_inst.
Proof. unfold Equation47. intro H. specialize (H F6_0). unfold magma_op, refa773_inst, refa773_op in H. discriminate H. Qed.

Lemma refa773_not99 : ~ @Equation99 Fin6 refa773_inst.
Proof. unfold Equation99. intro H. specialize (H F6_0). unfold magma_op, refa773_inst, refa773_op in H. discriminate H. Qed.

Lemma refa773_not151 : ~ @Equation151 Fin6 refa773_inst.
Proof. unfold Equation151. intro H. specialize (H F6_0). unfold magma_op, refa773_inst, refa773_op in H. discriminate H. Qed.

Lemma refa773_not203 : ~ @Equation203 Fin6 refa773_inst.
Proof. unfold Equation203. intro H. specialize (H F6_0). unfold magma_op, refa773_inst, refa773_op in H. discriminate H. Qed.

Lemma refa773_not263 : ~ @Equation263 Fin6 refa773_inst.
Proof. unfold Equation263. intro H. specialize (H F6_2 F6_4). unfold magma_op, refa773_inst, refa773_op in H. discriminate H. Qed.

Lemma refa773_not411 : ~ @Equation411 Fin6 refa773_inst.
Proof. unfold Equation411. intro H. specialize (H F6_0). unfold magma_op, refa773_inst, refa773_op in H. discriminate H. Qed.

Lemma refa773_not614 : ~ @Equation614 Fin6 refa773_inst.
Proof. unfold Equation614. intro H. specialize (H F6_0). unfold magma_op, refa773_inst, refa773_op in H. discriminate H. Qed.

Lemma refa773_not817 : ~ @Equation817 Fin6 refa773_inst.
Proof. unfold Equation817. intro H. specialize (H F6_0). unfold magma_op, refa773_inst, refa773_op in H. discriminate H. Qed.

Lemma refa773_not1020 : ~ @Equation1020 Fin6 refa773_inst.
Proof. unfold Equation1020. intro H. specialize (H F6_0). unfold magma_op, refa773_inst, refa773_op in H. discriminate H. Qed.

Lemma refa773_not1223 : ~ @Equation1223 Fin6 refa773_inst.
Proof. unfold Equation1223. intro H. specialize (H F6_0). unfold magma_op, refa773_inst, refa773_op in H. discriminate H. Qed.

Lemma refa773_not1426 : ~ @Equation1426 Fin6 refa773_inst.
Proof. unfold Equation1426. intro H. specialize (H F6_0). unfold magma_op, refa773_inst, refa773_op in H. discriminate H. Qed.

Lemma refa773_not1629 : ~ @Equation1629 Fin6 refa773_inst.
Proof. unfold Equation1629. intro H. specialize (H F6_0). unfold magma_op, refa773_inst, refa773_op in H. discriminate H. Qed.

Lemma refa773_not1832 : ~ @Equation1832 Fin6 refa773_inst.
Proof. unfold Equation1832. intro H. specialize (H F6_0). unfold magma_op, refa773_inst, refa773_op in H. discriminate H. Qed.

Lemma refa773_not2035 : ~ @Equation2035 Fin6 refa773_inst.
Proof. unfold Equation2035. intro H. specialize (H F6_0). unfold magma_op, refa773_inst, refa773_op in H. discriminate H. Qed.

Lemma refa773_not2238 : ~ @Equation2238 Fin6 refa773_inst.
Proof. unfold Equation2238. intro H. specialize (H F6_0). unfold magma_op, refa773_inst, refa773_op in H. discriminate H. Qed.

Lemma refa773_not2441 : ~ @Equation2441 Fin6 refa773_inst.
Proof. unfold Equation2441. intro H. specialize (H F6_0). unfold magma_op, refa773_inst, refa773_op in H. discriminate H. Qed.

Lemma refa773_not2646 : ~ @Equation2646 Fin6 refa773_inst.
Proof. unfold Equation2646. intro H. specialize (H F6_2 F6_0). unfold magma_op, refa773_inst, refa773_op in H. discriminate H. Qed.

Lemma refa773_not2649 : ~ @Equation2649 Fin6 refa773_inst.
Proof. unfold Equation2649. intro H. specialize (H F6_5 F6_1). unfold magma_op, refa773_inst, refa773_op in H. discriminate H. Qed.

Lemma refa773_not2652 : ~ @Equation2652 Fin6 refa773_inst.
Proof. unfold Equation2652. intro H. specialize (H F6_2 F6_4). unfold magma_op, refa773_inst, refa773_op in H. discriminate H. Qed.

Lemma refa773_not2659 : ~ @Equation2659 Fin6 refa773_inst.
Proof. unfold Equation2659. intro H. specialize (H F6_0 F6_3). unfold magma_op, refa773_inst, refa773_op in H. discriminate H. Qed.

Lemma refa773_not2662 : ~ @Equation2662 Fin6 refa773_inst.
Proof. unfold Equation2662. intro H. specialize (H F6_2 F6_4). unfold magma_op, refa773_inst, refa773_op in H. discriminate H. Qed.

Lemma refa773_not2669 : ~ @Equation2669 Fin6 refa773_inst.
Proof. unfold Equation2669. intro H. specialize (H F6_0 F6_3). unfold magma_op, refa773_inst, refa773_op in H. discriminate H. Qed.

Lemma refa773_not2672 : ~ @Equation2672 Fin6 refa773_inst.
Proof. unfold Equation2672. intro H. specialize (H F6_0 F6_4). unfold magma_op, refa773_inst, refa773_op in H. discriminate H. Qed.

Lemma refa773_not2699 : ~ @Equation2699 Fin6 refa773_inst.
Proof. unfold Equation2699. intro H. specialize (H F6_0 F6_1). unfold magma_op, refa773_inst, refa773_op in H. discriminate H. Qed.

Lemma refa773_not2709 : ~ @Equation2709 Fin6 refa773_inst.
Proof. unfold Equation2709. intro H. specialize (H F6_0 F6_2). unfold magma_op, refa773_inst, refa773_op in H. discriminate H. Qed.

Lemma refa773_not2736 : ~ @Equation2736 Fin6 refa773_inst.
Proof. unfold Equation2736. intro H. specialize (H F6_0 F6_2). unfold magma_op, refa773_inst, refa773_op in H. discriminate H. Qed.

Lemma refa773_not2743 : ~ @Equation2743 Fin6 refa773_inst.
Proof. unfold Equation2743. intro H. specialize (H F6_0 F6_2). unfold magma_op, refa773_inst, refa773_op in H. discriminate H. Qed.

Lemma refa773_not2746 : ~ @Equation2746 Fin6 refa773_inst.
Proof. unfold Equation2746. intro H. specialize (H F6_0 F6_1). unfold magma_op, refa773_inst, refa773_op in H. discriminate H. Qed.

Lemma refa773_not2849 : ~ @Equation2849 Fin6 refa773_inst.
Proof. unfold Equation2849. intro H. specialize (H F6_2 F6_0). unfold magma_op, refa773_inst, refa773_op in H. discriminate H. Qed.

Lemma refa773_not2852 : ~ @Equation2852 Fin6 refa773_inst.
Proof. unfold Equation2852. intro H. specialize (H F6_0 F6_3). unfold magma_op, refa773_inst, refa773_op in H. discriminate H. Qed.

Lemma refa773_not2855 : ~ @Equation2855 Fin6 refa773_inst.
Proof. unfold Equation2855. intro H. specialize (H F6_2 F6_4). unfold magma_op, refa773_inst, refa773_op in H. discriminate H. Qed.

Lemma refa773_not2865 : ~ @Equation2865 Fin6 refa773_inst.
Proof. unfold Equation2865. intro H. specialize (H F6_5 F6_4). unfold magma_op, refa773_inst, refa773_op in H. discriminate H. Qed.

Lemma refa773_not2872 : ~ @Equation2872 Fin6 refa773_inst.
Proof. unfold Equation2872. intro H. specialize (H F6_0 F6_1). unfold magma_op, refa773_inst, refa773_op in H. discriminate H. Qed.

Lemma refa773_not2875 : ~ @Equation2875 Fin6 refa773_inst.
Proof. unfold Equation2875. intro H. specialize (H F6_0 F6_1). unfold magma_op, refa773_inst, refa773_op in H. discriminate H. Qed.

Lemma refa773_not2899 : ~ @Equation2899 Fin6 refa773_inst.
Proof. unfold Equation2899. intro H. specialize (H F6_0 F6_1). unfold magma_op, refa773_inst, refa773_op in H. discriminate H. Qed.

Lemma refa773_not2902 : ~ @Equation2902 Fin6 refa773_inst.
Proof. unfold Equation2902. intro H. specialize (H F6_5 F6_4). unfold magma_op, refa773_inst, refa773_op in H. discriminate H. Qed.

Lemma refa773_not2909 : ~ @Equation2909 Fin6 refa773_inst.
Proof. unfold Equation2909. intro H. specialize (H F6_0 F6_1). unfold magma_op, refa773_inst, refa773_op in H. discriminate H. Qed.

Lemma refa773_not2939 : ~ @Equation2939 Fin6 refa773_inst.
Proof. unfold Equation2939. intro H. specialize (H F6_0 F6_1). unfold magma_op, refa773_inst, refa773_op in H. discriminate H. Qed.

Lemma refa773_not2946 : ~ @Equation2946 Fin6 refa773_inst.
Proof. unfold Equation2946. intro H. specialize (H F6_0 F6_1). unfold magma_op, refa773_inst, refa773_op in H. discriminate H. Qed.

Lemma refa773_not3050 : ~ @Equation3050 Fin6 refa773_inst.
Proof. unfold Equation3050. intro H. specialize (H F6_0). unfold magma_op, refa773_inst, refa773_op in H. discriminate H. Qed.

Lemma refa773_not3255 : ~ @Equation3255 Fin6 refa773_inst.
Proof. unfold Equation3255. intro H. specialize (H F6_2 F6_0). unfold magma_op, refa773_inst, refa773_op in H. discriminate H. Qed.

Lemma refa773_not3258 : ~ @Equation3258 Fin6 refa773_inst.
Proof. unfold Equation3258. intro H. specialize (H F6_0 F6_1). unfold magma_op, refa773_inst, refa773_op in H. discriminate H. Qed.

Lemma refa773_not3261 : ~ @Equation3261 Fin6 refa773_inst.
Proof. unfold Equation3261. intro H. specialize (H F6_1 F6_4). unfold magma_op, refa773_inst, refa773_op in H. discriminate H. Qed.

Lemma refa773_not3268 : ~ @Equation3268 Fin6 refa773_inst.
Proof. unfold Equation3268. intro H. specialize (H F6_0 F6_1). unfold magma_op, refa773_inst, refa773_op in H. discriminate H. Qed.

Lemma refa773_not3271 : ~ @Equation3271 Fin6 refa773_inst.
Proof. unfold Equation3271. intro H. specialize (H F6_0 F6_1). unfold magma_op, refa773_inst, refa773_op in H. discriminate H. Qed.

Lemma refa773_not3278 : ~ @Equation3278 Fin6 refa773_inst.
Proof. unfold Equation3278. intro H. specialize (H F6_0 F6_1). unfold magma_op, refa773_inst, refa773_op in H. discriminate H. Qed.

Lemma refa773_not3281 : ~ @Equation3281 Fin6 refa773_inst.
Proof. unfold Equation3281. intro H. specialize (H F6_0 F6_1). unfold magma_op, refa773_inst, refa773_op in H. discriminate H. Qed.

Lemma refa773_not3306 : ~ @Equation3306 Fin6 refa773_inst.
Proof. unfold Equation3306. intro H. specialize (H F6_4 F6_1). unfold magma_op, refa773_inst, refa773_op in H. discriminate H. Qed.

Lemma refa773_not3309 : ~ @Equation3309 Fin6 refa773_inst.
Proof. unfold Equation3309. intro H. specialize (H F6_0 F6_1). unfold magma_op, refa773_inst, refa773_op in H. discriminate H. Qed.

Lemma refa773_not3316 : ~ @Equation3316 Fin6 refa773_inst.
Proof. unfold Equation3316. intro H. specialize (H F6_0 F6_1). unfold magma_op, refa773_inst, refa773_op in H. discriminate H. Qed.

Lemma refa773_not3319 : ~ @Equation3319 Fin6 refa773_inst.
Proof. unfold Equation3319. intro H. specialize (H F6_0 F6_1). unfold magma_op, refa773_inst, refa773_op in H. discriminate H. Qed.

Lemma refa773_not3343 : ~ @Equation3343 Fin6 refa773_inst.
Proof. unfold Equation3343. intro H. specialize (H F6_0 F6_1). unfold magma_op, refa773_inst, refa773_op in H. discriminate H. Qed.

Lemma refa773_not3346 : ~ @Equation3346 Fin6 refa773_inst.
Proof. unfold Equation3346. intro H. specialize (H F6_0 F6_1). unfold magma_op, refa773_inst, refa773_op in H. discriminate H. Qed.

Lemma refa773_not3353 : ~ @Equation3353 Fin6 refa773_inst.
Proof. unfold Equation3353. intro H. specialize (H F6_0 F6_1). unfold magma_op, refa773_inst, refa773_op in H. discriminate H. Qed.

Lemma refa773_not3458 : ~ @Equation3458 Fin6 refa773_inst.
Proof. unfold Equation3458. intro H. specialize (H F6_2 F6_0). unfold magma_op, refa773_inst, refa773_op in H. discriminate H. Qed.

Lemma refa773_not3461 : ~ @Equation3461 Fin6 refa773_inst.
Proof. unfold Equation3461. intro H. specialize (H F6_5 F6_1). unfold magma_op, refa773_inst, refa773_op in H. discriminate H. Qed.

Lemma refa773_not3464 : ~ @Equation3464 Fin6 refa773_inst.
Proof. unfold Equation3464. intro H. specialize (H F6_2 F6_4). unfold magma_op, refa773_inst, refa773_op in H. discriminate H. Qed.

Lemma refa773_not3474 : ~ @Equation3474 Fin6 refa773_inst.
Proof. unfold Equation3474. intro H. specialize (H F6_0 F6_1). unfold magma_op, refa773_inst, refa773_op in H. discriminate H. Qed.

Lemma refa773_not3481 : ~ @Equation3481 Fin6 refa773_inst.
Proof. unfold Equation3481. intro H. specialize (H F6_0 F6_1). unfold magma_op, refa773_inst, refa773_op in H. discriminate H. Qed.

Lemma refa773_not3484 : ~ @Equation3484 Fin6 refa773_inst.
Proof. unfold Equation3484. intro H. specialize (H F6_0 F6_1). unfold magma_op, refa773_inst, refa773_op in H. discriminate H. Qed.

Lemma refa773_not3509 : ~ @Equation3509 Fin6 refa773_inst.
Proof. unfold Equation3509. intro H. specialize (H F6_0 F6_1). unfold magma_op, refa773_inst, refa773_op in H. discriminate H. Qed.

Lemma refa773_not3512 : ~ @Equation3512 Fin6 refa773_inst.
Proof. unfold Equation3512. intro H. specialize (H F6_0 F6_1). unfold magma_op, refa773_inst, refa773_op in H. discriminate H. Qed.

Lemma refa773_not3519 : ~ @Equation3519 Fin6 refa773_inst.
Proof. unfold Equation3519. intro H. specialize (H F6_2 F6_0). unfold magma_op, refa773_inst, refa773_op in H. discriminate H. Qed.

Lemma refa773_not3522 : ~ @Equation3522 Fin6 refa773_inst.
Proof. unfold Equation3522. intro H. specialize (H F6_0 F6_1). unfold magma_op, refa773_inst, refa773_op in H. discriminate H. Qed.

Lemma refa773_not3546 : ~ @Equation3546 Fin6 refa773_inst.
Proof. unfold Equation3546. intro H. specialize (H F6_0 F6_1). unfold magma_op, refa773_inst, refa773_op in H. discriminate H. Qed.

Lemma refa773_not3549 : ~ @Equation3549 Fin6 refa773_inst.
Proof. unfold Equation3549. intro H. specialize (H F6_0 F6_1). unfold magma_op, refa773_inst, refa773_op in H. discriminate H. Qed.

Lemma refa773_not3659 : ~ @Equation3659 Fin6 refa773_inst.
Proof. unfold Equation3659. intro H. specialize (H F6_0). unfold magma_op, refa773_inst, refa773_op in H. discriminate H. Qed.

Lemma refa773_not3862 : ~ @Equation3862 Fin6 refa773_inst.
Proof. unfold Equation3862. intro H. specialize (H F6_0). unfold magma_op, refa773_inst, refa773_op in H. discriminate H. Qed.

Lemma refa773_not4065 : ~ @Equation4065 Fin6 refa773_inst.
Proof. unfold Equation4065. intro H. specialize (H F6_0). unfold magma_op, refa773_inst, refa773_op in H. discriminate H. Qed.

Lemma refa773_not4269 : ~ @Equation4269 Fin6 refa773_inst.
Proof. unfold Equation4269. intro H. specialize (H F6_2 F6_0). unfold magma_op, refa773_inst, refa773_op in H. discriminate H. Qed.

Lemma refa773_not4272 : ~ @Equation4272 Fin6 refa773_inst.
Proof. unfold Equation4272. intro H. specialize (H F6_0 F6_1). unfold magma_op, refa773_inst, refa773_op in H. discriminate H. Qed.

Lemma refa773_not4275 : ~ @Equation4275 Fin6 refa773_inst.
Proof. unfold Equation4275. intro H. specialize (H F6_0 F6_1). unfold magma_op, refa773_inst, refa773_op in H. discriminate H. Qed.

Lemma refa773_not4284 : ~ @Equation4284 Fin6 refa773_inst.
Proof. unfold Equation4284. intro H. specialize (H F6_0 F6_1). unfold magma_op, refa773_inst, refa773_op in H. discriminate H. Qed.

Lemma refa773_not4291 : ~ @Equation4291 Fin6 refa773_inst.
Proof. unfold Equation4291. intro H. specialize (H F6_0 F6_1). unfold magma_op, refa773_inst, refa773_op in H. discriminate H. Qed.

Lemma refa773_not4320 : ~ @Equation4320 Fin6 refa773_inst.
Proof. unfold Equation4320. intro H. specialize (H F6_0 F6_1). unfold magma_op, refa773_inst, refa773_op in H. discriminate H. Qed.

Lemma refa773_not4380 : ~ @Equation4380 Fin6 refa773_inst.
Proof. unfold Equation4380. intro H. specialize (H F6_0). unfold magma_op, refa773_inst, refa773_op in H. discriminate H. Qed.

Lemma refa773_not4584 : ~ @Equation4584 Fin6 refa773_inst.
Proof. unfold Equation4584. intro H. specialize (H F6_0 F6_3). unfold magma_op, refa773_inst, refa773_op in H. discriminate H. Qed.

Lemma refa773_not4587 : ~ @Equation4587 Fin6 refa773_inst.
Proof. unfold Equation4587. intro H. specialize (H F6_0 F6_1). unfold magma_op, refa773_inst, refa773_op in H. discriminate H. Qed.

Lemma refa773_not4590 : ~ @Equation4590 Fin6 refa773_inst.
Proof. unfold Equation4590. intro H. specialize (H F6_0 F6_1). unfold magma_op, refa773_inst, refa773_op in H. discriminate H. Qed.

Lemma refa773_not4599 : ~ @Equation4599 Fin6 refa773_inst.
Proof. unfold Equation4599. intro H. specialize (H F6_0 F6_5). unfold magma_op, refa773_inst, refa773_op in H. discriminate H. Qed.

Lemma refa773_not4606 : ~ @Equation4606 Fin6 refa773_inst.
Proof. unfold Equation4606. intro H. specialize (H F6_0 F6_1). unfold magma_op, refa773_inst, refa773_op in H. discriminate H. Qed.

Lemma refa773_not4635 : ~ @Equation4635 Fin6 refa773_inst.
Proof. unfold Equation4635. intro H. specialize (H F6_0 F6_1). unfold magma_op, refa773_inst, refa773_op in H. discriminate H. Qed.

(** ---- refa774 (Fin6) ---- *)

Definition refa774_op (x y : Fin6) : Fin6 :=
  match x, y with
  | F6_0, F6_0 => F6_1 | F6_0, F6_1 => F6_2 | F6_0, F6_2 => F6_4 | F6_0, F6_3 => F6_4 | F6_0, F6_4 => F6_5 | F6_0, F6_5 => F6_2
  | F6_1, F6_0 => F6_5 | F6_1, F6_1 => F6_3 | F6_1, F6_2 => F6_2 | F6_1, F6_3 => F6_3 | F6_1, F6_4 => F6_5 | F6_1, F6_5 => F6_3
  | F6_2, F6_0 => F6_5 | F6_2, F6_1 => F6_5 | F6_2, F6_2 => F6_3 | F6_2, F6_3 => F6_0 | F6_2, F6_4 => F6_0 | F6_2, F6_5 => F6_4
  | F6_3, F6_0 => F6_0 | F6_3, F6_1 => F6_5 | F6_3, F6_2 => F6_4 | F6_3, F6_3 => F6_0 | F6_3, F6_4 => F6_0 | F6_3, F6_5 => F6_5
  | F6_4, F6_0 => F6_0 | F6_4, F6_1 => F6_1 | F6_4, F6_2 => F6_2 | F6_4, F6_3 => F6_3 | F6_4, F6_4 => F6_4 | F6_4, F6_5 => F6_5
  | F6_5, F6_0 => F6_0 | F6_5, F6_1 => F6_1 | F6_5, F6_2 => F6_2 | F6_5, F6_3 => F6_3 | F6_5, F6_4 => F6_4 | F6_5, F6_5 => F6_5
  end.

#[local] Instance refa774_inst : Magma Fin6 := {| magma_op := refa774_op |}.

Lemma refa774_sat2994 : @Equation2994 Fin6 refa774_inst.
Proof. unfold Equation2994, magma_op, refa774_inst, refa774_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa774_not2644 : ~ @Equation2644 Fin6 refa774_inst.
Proof. unfold Equation2644. intro H. specialize (H F6_1). unfold magma_op, refa774_inst, refa774_op in H. discriminate H. Qed.

Lemma refa774_not3253 : ~ @Equation3253 Fin6 refa774_inst.
Proof. unfold Equation3253. intro H. specialize (H F6_0). unfold magma_op, refa774_inst, refa774_op in H. discriminate H. Qed.

Lemma refa774_not3456 : ~ @Equation3456 Fin6 refa774_inst.
Proof. unfold Equation3456. intro H. specialize (H F6_0). unfold magma_op, refa774_inst, refa774_op in H. discriminate H. Qed.
