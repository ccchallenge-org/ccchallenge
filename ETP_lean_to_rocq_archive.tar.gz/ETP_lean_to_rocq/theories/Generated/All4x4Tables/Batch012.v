(** * All4x4 counterexamples — batch 12
    Auto-generated from Lean4 All4x4 files. *)

From Stdlib Require Import Utf8.

From ETP Require Import Magma.
From ETP Require Import FinMagma.
From ETP.Equations Require Import All.

Open Scope magma_scope.

(** ---- refa595 (Fin4) ---- *)

Definition refa595_op (x y : Fin4) : Fin4 :=
  match x, y with
  | F4_0, F4_0 => F4_2 | F4_0, F4_1 => F4_2 | F4_0, F4_2 => F4_0 | F4_0, F4_3 => F4_3
  | F4_1, F4_0 => F4_2 | F4_1, F4_1 => F4_3 | F4_1, F4_2 => F4_1 | F4_1, F4_3 => F4_0
  | F4_2, F4_0 => F4_2 | F4_2, F4_1 => F4_2 | F4_2, F4_2 => F4_1 | F4_2, F4_3 => F4_2
  | F4_3, F4_0 => F4_2 | F4_3, F4_1 => F4_0 | F4_3, F4_2 => F4_3 | F4_3, F4_3 => F4_1
  end.

#[local] Instance refa595_inst : Magma Fin4 := {| magma_op := refa595_op |}.

Lemma refa595_sat426 : @Equation426 Fin4 refa595_inst.
Proof. unfold Equation426, magma_op, refa595_inst, refa595_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa595_not99 : ~ @Equation99 Fin4 refa595_inst.
Proof. unfold Equation99. intro H. specialize (H F4_1). unfold magma_op, refa595_inst, refa595_op in H. discriminate H. Qed.

Lemma refa595_not413 : ~ @Equation413 Fin4 refa595_inst.
Proof. unfold Equation413. intro H. specialize (H F4_1 F4_0). unfold magma_op, refa595_inst, refa595_op in H. discriminate H. Qed.

Lemma refa595_not429 : ~ @Equation429 Fin4 refa595_inst.
Proof. unfold Equation429. intro H. specialize (H F4_1 F4_3). unfold magma_op, refa595_inst, refa595_op in H. discriminate H. Qed.

Lemma refa595_not436 : ~ @Equation436 Fin4 refa595_inst.
Proof. unfold Equation436. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa595_inst, refa595_op in H. discriminate H. Qed.

Lemma refa595_not437 : ~ @Equation437 Fin4 refa595_inst.
Proof. unfold Equation437. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa595_inst, refa595_op in H. discriminate H. Qed.

Lemma refa595_not440 : ~ @Equation440 Fin4 refa595_inst.
Proof. unfold Equation440. intro H. specialize (H F4_0 F4_2). unfold magma_op, refa595_inst, refa595_op in H. discriminate H. Qed.

Lemma refa595_not817 : ~ @Equation817 Fin4 refa595_inst.
Proof. unfold Equation817. intro H. specialize (H F4_0). unfold magma_op, refa595_inst, refa595_op in H. discriminate H. Qed.

Lemma refa595_not1020 : ~ @Equation1020 Fin4 refa595_inst.
Proof. unfold Equation1020. intro H. specialize (H F4_3). unfold magma_op, refa595_inst, refa595_op in H. discriminate H. Qed.

Lemma refa595_not1223 : ~ @Equation1223 Fin4 refa595_inst.
Proof. unfold Equation1223. intro H. specialize (H F4_3). unfold magma_op, refa595_inst, refa595_op in H. discriminate H. Qed.

Lemma refa595_not1832 : ~ @Equation1832 Fin4 refa595_inst.
Proof. unfold Equation1832. intro H. specialize (H F4_1). unfold magma_op, refa595_inst, refa595_op in H. discriminate H. Qed.

Lemma refa595_not3253 : ~ @Equation3253 Fin4 refa595_inst.
Proof. unfold Equation3253. intro H. specialize (H F4_1). unfold magma_op, refa595_inst, refa595_op in H. discriminate H. Qed.

Lemma refa595_not3659 : ~ @Equation3659 Fin4 refa595_inst.
Proof. unfold Equation3659. intro H. specialize (H F4_0). unfold magma_op, refa595_inst, refa595_op in H. discriminate H. Qed.

Lemma refa595_not3862 : ~ @Equation3862 Fin4 refa595_inst.
Proof. unfold Equation3862. intro H. specialize (H F4_1). unfold magma_op, refa595_inst, refa595_op in H. discriminate H. Qed.

Lemma refa595_not4065 : ~ @Equation4065 Fin4 refa595_inst.
Proof. unfold Equation4065. intro H. specialize (H F4_1). unfold magma_op, refa595_inst, refa595_op in H. discriminate H. Qed.

Lemma refa595_not4269 : ~ @Equation4269 Fin4 refa595_inst.
Proof. unfold Equation4269. intro H. specialize (H F4_1 F4_0). unfold magma_op, refa595_inst, refa595_op in H. discriminate H. Qed.

Lemma refa595_not4270 : ~ @Equation4270 Fin4 refa595_inst.
Proof. unfold Equation4270. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa595_inst, refa595_op in H. discriminate H. Qed.

Lemma refa595_not4293 : ~ @Equation4293 Fin4 refa595_inst.
Proof. unfold Equation4293. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa595_inst, refa595_op in H. discriminate H. Qed.

Lemma refa595_not4314 : ~ @Equation4314 Fin4 refa595_inst.
Proof. unfold Equation4314. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa595_inst, refa595_op in H. discriminate H. Qed.

Lemma refa595_not4583 : ~ @Equation4583 Fin4 refa595_inst.
Proof. unfold Equation4583. intro H. specialize (H F4_0 F4_2). unfold magma_op, refa595_inst, refa595_op in H. discriminate H. Qed.

Lemma refa595_not4591 : ~ @Equation4591 Fin4 refa595_inst.
Proof. unfold Equation4591. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa595_inst, refa595_op in H. discriminate H. Qed.

Lemma refa595_not4598 : ~ @Equation4598 Fin4 refa595_inst.
Proof. unfold Equation4598. intro H. specialize (H F4_0 F4_2). unfold magma_op, refa595_inst, refa595_op in H. discriminate H. Qed.

Lemma refa595_not4606 : ~ @Equation4606 Fin4 refa595_inst.
Proof. unfold Equation4606. intro H. specialize (H F4_1 F4_2). unfold magma_op, refa595_inst, refa595_op in H. discriminate H. Qed.

Lemma refa595_not4608 : ~ @Equation4608 Fin4 refa595_inst.
Proof. unfold Equation4608. intro H. specialize (H F4_0 F4_2). unfold magma_op, refa595_inst, refa595_op in H. discriminate H. Qed.

Lemma refa595_not4622 : ~ @Equation4622 Fin4 refa595_inst.
Proof. unfold Equation4622. intro H. specialize (H F4_0 F4_1 F4_1). unfold magma_op, refa595_inst, refa595_op in H. discriminate H. Qed.

Lemma refa595_not4631 : ~ @Equation4631 Fin4 refa595_inst.
Proof. unfold Equation4631. intro H. specialize (H F4_1 F4_0 F4_1). unfold magma_op, refa595_inst, refa595_op in H. discriminate H. Qed.

Lemma refa595_not4636 : ~ @Equation4636 Fin4 refa595_inst.
Proof. unfold Equation4636. intro H. specialize (H F4_0 F4_2). unfold magma_op, refa595_inst, refa595_op in H. discriminate H. Qed.

Lemma refa595_not4647 : ~ @Equation4647 Fin4 refa595_inst.
Proof. unfold Equation4647. intro H. specialize (H F4_0 F4_0 F4_2). unfold magma_op, refa595_inst, refa595_op in H. discriminate H. Qed.

(** ---- refa596 (Fin4) ---- *)

Definition refa596_op (x y : Fin4) : Fin4 :=
  match x, y with
  | F4_0, F4_0 => F4_0 | F4_0, F4_1 => F4_3 | F4_0, F4_2 => F4_0 | F4_0, F4_3 => F4_3
  | F4_1, F4_0 => F4_3 | F4_1, F4_1 => F4_0 | F4_1, F4_2 => F4_0 | F4_1, F4_3 => F4_3
  | F4_2, F4_0 => F4_3 | F4_2, F4_1 => F4_2 | F4_2, F4_2 => F4_1 | F4_2, F4_3 => F4_3
  | F4_3, F4_0 => F4_0 | F4_3, F4_1 => F4_1 | F4_3, F4_2 => F4_2 | F4_3, F4_3 => F4_0
  end.

#[local] Instance refa596_inst : Magma Fin4 := {| magma_op := refa596_op |}.

Lemma refa596_sat2472 : @Equation2472 Fin4 refa596_inst.
Proof. unfold Equation2472, magma_op, refa596_inst, refa596_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa596_not203 : ~ @Equation203 Fin4 refa596_inst.
Proof. unfold Equation203. intro H. specialize (H F4_2). unfold magma_op, refa596_inst, refa596_op in H. discriminate H. Qed.

Lemma refa596_not2238 : ~ @Equation2238 Fin4 refa596_inst.
Proof. unfold Equation2238. intro H. specialize (H F4_2). unfold magma_op, refa596_inst, refa596_op in H. discriminate H. Qed.

Lemma refa596_not2459 : ~ @Equation2459 Fin4 refa596_inst.
Proof. unfold Equation2459. intro H. specialize (H F4_1 F4_2). unfold magma_op, refa596_inst, refa596_op in H. discriminate H. Qed.

Lemma refa596_not3659 : ~ @Equation3659 Fin4 refa596_inst.
Proof. unfold Equation3659. intro H. specialize (H F4_2). unfold magma_op, refa596_inst, refa596_op in H. discriminate H. Qed.

Lemma refa596_not4065 : ~ @Equation4065 Fin4 refa596_inst.
Proof. unfold Equation4065. intro H. specialize (H F4_1). unfold magma_op, refa596_inst, refa596_op in H. discriminate H. Qed.

Lemma refa596_not4270 : ~ @Equation4270 Fin4 refa596_inst.
Proof. unfold Equation4270. intro H. specialize (H F4_0 F4_2). unfold magma_op, refa596_inst, refa596_op in H. discriminate H. Qed.

(** ---- refa597 (Fin4) ---- *)

Definition refa597_op (x y : Fin4) : Fin4 :=
  match x, y with
  | F4_0, F4_0 => F4_3 | F4_0, F4_1 => F4_3 | F4_0, F4_2 => F4_1 | F4_0, F4_3 => F4_3
  | F4_1, F4_0 => F4_3 | F4_1, F4_1 => F4_3 | F4_1, F4_2 => F4_1 | F4_1, F4_3 => F4_3
  | F4_2, F4_0 => F4_3 | F4_2, F4_1 => F4_0 | F4_2, F4_2 => F4_1 | F4_2, F4_3 => F4_3
  | F4_3, F4_0 => F4_3 | F4_3, F4_1 => F4_3 | F4_3, F4_2 => F4_1 | F4_3, F4_3 => F4_3
  end.

#[local] Instance refa597_inst : Magma Fin4 := {| magma_op := refa597_op |}.

Lemma refa597_sat4345 : @Equation4345 Fin4 refa597_inst.
Proof. unfold Equation4345, magma_op, refa597_inst, refa597_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa597_not4268 : ~ @Equation4268 Fin4 refa597_inst.
Proof. unfold Equation4268. intro H. specialize (H F4_2 F4_0). unfold magma_op, refa597_inst, refa597_op in H. discriminate H. Qed.

Lemma refa597_not4270 : ~ @Equation4270 Fin4 refa597_inst.
Proof. unfold Equation4270. intro H. specialize (H F4_2 F4_0). unfold magma_op, refa597_inst, refa597_op in H. discriminate H. Qed.

Lemma refa597_not4272 : ~ @Equation4272 Fin4 refa597_inst.
Proof. unfold Equation4272. intro H. specialize (H F4_2 F4_0). unfold magma_op, refa597_inst, refa597_op in H. discriminate H. Qed.

Lemma refa597_not4273 : ~ @Equation4273 Fin4 refa597_inst.
Proof. unfold Equation4273. intro H. specialize (H F4_0 F4_2). unfold magma_op, refa597_inst, refa597_op in H. discriminate H. Qed.

Lemma refa597_not4275 : ~ @Equation4275 Fin4 refa597_inst.
Proof. unfold Equation4275. intro H. specialize (H F4_2 F4_0). unfold magma_op, refa597_inst, refa597_op in H. discriminate H. Qed.

Lemma refa597_not4276 : ~ @Equation4276 Fin4 refa597_inst.
Proof. unfold Equation4276. intro H. specialize (H F4_0 F4_2). unfold magma_op, refa597_inst, refa597_op in H. discriminate H. Qed.

Lemma refa597_not4283 : ~ @Equation4283 Fin4 refa597_inst.
Proof. unfold Equation4283. intro H. specialize (H F4_2 F4_0). unfold magma_op, refa597_inst, refa597_op in H. discriminate H. Qed.

Lemma refa597_not4291 : ~ @Equation4291 Fin4 refa597_inst.
Proof. unfold Equation4291. intro H. specialize (H F4_0 F4_2). unfold magma_op, refa597_inst, refa597_op in H. discriminate H. Qed.

Lemma refa597_not4314 : ~ @Equation4314 Fin4 refa597_inst.
Proof. unfold Equation4314. intro H. specialize (H F4_2 F4_0). unfold magma_op, refa597_inst, refa597_op in H. discriminate H. Qed.

Lemma refa597_not4320 : ~ @Equation4320 Fin4 refa597_inst.
Proof. unfold Equation4320. intro H. specialize (H F4_2 F4_0). unfold magma_op, refa597_inst, refa597_op in H. discriminate H. Qed.

Lemma refa597_not4321 : ~ @Equation4321 Fin4 refa597_inst.
Proof. unfold Equation4321. intro H. specialize (H F4_0 F4_2). unfold magma_op, refa597_inst, refa597_op in H. discriminate H. Qed.

(** ---- refa598 (Fin4) ---- *)

Definition refa598_op (x y : Fin4) : Fin4 :=
  match x, y with
  | F4_0, F4_0 => F4_1 | F4_0, F4_1 => F4_2 | F4_0, F4_2 => F4_3 | F4_0, F4_3 => F4_3
  | F4_1, F4_0 => F4_2 | F4_1, F4_1 => F4_2 | F4_1, F4_2 => F4_2 | F4_1, F4_3 => F4_2
  | F4_2, F4_0 => F4_3 | F4_2, F4_1 => F4_3 | F4_2, F4_2 => F4_3 | F4_2, F4_3 => F4_3
  | F4_3, F4_0 => F4_3 | F4_3, F4_1 => F4_3 | F4_3, F4_2 => F4_3 | F4_3, F4_3 => F4_3
  end.

#[local] Instance refa598_inst : Magma Fin4 := {| magma_op := refa598_op |}.

Lemma refa598_sat4659 : @Equation4659 Fin4 refa598_inst.
Proof. unfold Equation4659, magma_op, refa598_inst, refa598_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa598_not4591 : ~ @Equation4591 Fin4 refa598_inst.
Proof. unfold Equation4591. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa598_inst, refa598_op in H. discriminate H. Qed.

Lemma refa598_not4598 : ~ @Equation4598 Fin4 refa598_inst.
Proof. unfold Equation4598. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa598_inst, refa598_op in H. discriminate H. Qed.

Lemma refa598_not4599 : ~ @Equation4599 Fin4 refa598_inst.
Proof. unfold Equation4599. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa598_inst, refa598_op in H. discriminate H. Qed.

Lemma refa598_not4605 : ~ @Equation4605 Fin4 refa598_inst.
Proof. unfold Equation4605. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa598_inst, refa598_op in H. discriminate H. Qed.

Lemma refa598_not4606 : ~ @Equation4606 Fin4 refa598_inst.
Proof. unfold Equation4606. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa598_inst, refa598_op in H. discriminate H. Qed.

Lemma refa598_not4608 : ~ @Equation4608 Fin4 refa598_inst.
Proof. unfold Equation4608. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa598_inst, refa598_op in H. discriminate H. Qed.

Lemma refa598_not4622 : ~ @Equation4622 Fin4 refa598_inst.
Proof. unfold Equation4622. intro H. specialize (H F4_0 F4_0 F4_1). unfold magma_op, refa598_inst, refa598_op in H. discriminate H. Qed.

Lemma refa598_not4631 : ~ @Equation4631 Fin4 refa598_inst.
Proof. unfold Equation4631. intro H. specialize (H F4_0 F4_0 F4_1). unfold magma_op, refa598_inst, refa598_op in H. discriminate H. Qed.

Lemma refa598_not4647 : ~ @Equation4647 Fin4 refa598_inst.
Proof. unfold Equation4647. intro H. specialize (H F4_0 F4_0 F4_1). unfold magma_op, refa598_inst, refa598_op in H. discriminate H. Qed.

Lemma refa598_not4656 : ~ @Equation4656 Fin4 refa598_inst.
Proof. unfold Equation4656. intro H. specialize (H F4_0 F4_0 F4_1). unfold magma_op, refa598_inst, refa598_op in H. discriminate H. Qed.

Lemma refa598_not4666 : ~ @Equation4666 Fin4 refa598_inst.
Proof. unfold Equation4666. intro H. specialize (H F4_0 F4_0 F4_1). unfold magma_op, refa598_inst, refa598_op in H. discriminate H. Qed.

(** ---- refa599 (Fin4) ---- *)

Definition refa599_op (x y : Fin4) : Fin4 :=
  match x, y with
  | F4_0, F4_0 => F4_3 | F4_0, F4_1 => F4_0 | F4_0, F4_2 => F4_1 | F4_0, F4_3 => F4_3
  | F4_1, F4_0 => F4_3 | F4_1, F4_1 => F4_3 | F4_1, F4_2 => F4_2 | F4_1, F4_3 => F4_3
  | F4_2, F4_0 => F4_0 | F4_2, F4_1 => F4_3 | F4_2, F4_2 => F4_3 | F4_2, F4_3 => F4_3
  | F4_3, F4_0 => F4_0 | F4_3, F4_1 => F4_1 | F4_3, F4_2 => F4_2 | F4_3, F4_3 => F4_3
  end.

#[local] Instance refa599_inst : Magma Fin4 := {| magma_op := refa599_op |}.

Lemma refa599_sat319 : @Equation319 Fin4 refa599_inst.
Proof. unfold Equation319, magma_op, refa599_inst, refa599_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa599_sat2623 : @Equation2623 Fin4 refa599_inst.
Proof. unfold Equation2623, magma_op, refa599_inst, refa599_op. intros x y z w. destruct x, y, z, w; reflexivity. Qed.

Lemma refa599_not2263 : ~ @Equation2263 Fin4 refa599_inst.
Proof. unfold Equation2263. intro H. specialize (H F4_2 F4_0). unfold magma_op, refa599_inst, refa599_op in H. discriminate H. Qed.

Lemma refa599_not2293 : ~ @Equation2293 Fin4 refa599_inst.
Proof. unfold Equation2293. intro H. specialize (H F4_0 F4_2). unfold magma_op, refa599_inst, refa599_op in H. discriminate H. Qed.

Lemma refa599_not2449 : ~ @Equation2449 Fin4 refa599_inst.
Proof. unfold Equation2449. intro H. specialize (H F4_0 F4_2). unfold magma_op, refa599_inst, refa599_op in H. discriminate H. Qed.

Lemma refa599_not3261 : ~ @Equation3261 Fin4 refa599_inst.
Proof. unfold Equation3261. intro H. specialize (H F4_2 F4_0). unfold magma_op, refa599_inst, refa599_op in H. discriminate H. Qed.

Lemma refa599_not3269 : ~ @Equation3269 Fin4 refa599_inst.
Proof. unfold Equation3269. intro H. specialize (H F4_0 F4_2). unfold magma_op, refa599_inst, refa599_op in H. discriminate H. Qed.

Lemma refa599_not3459 : ~ @Equation3459 Fin4 refa599_inst.
Proof. unfold Equation3459. intro H. specialize (H F4_0 F4_2). unfold magma_op, refa599_inst, refa599_op in H. discriminate H. Qed.

Lemma refa599_not3481 : ~ @Equation3481 Fin4 refa599_inst.
Proof. unfold Equation3481. intro H. specialize (H F4_2 F4_0). unfold magma_op, refa599_inst, refa599_op in H. discriminate H. Qed.

Lemma refa599_not3519 : ~ @Equation3519 Fin4 refa599_inst.
Proof. unfold Equation3519. intro H. specialize (H F4_0 F4_2). unfold magma_op, refa599_inst, refa599_op in H. discriminate H. Qed.

Lemma refa599_not3749 : ~ @Equation3749 Fin4 refa599_inst.
Proof. unfold Equation3749. intro H. specialize (H F4_0 F4_2). unfold magma_op, refa599_inst, refa599_op in H. discriminate H. Qed.

Lemma refa599_not4362 : ~ @Equation4362 Fin4 refa599_inst.
Proof. unfold Equation4362. intro H. specialize (H F4_0 F4_1 F4_2). unfold magma_op, refa599_inst, refa599_op in H. discriminate H. Qed.

Lemma refa599_not4606 : ~ @Equation4606 Fin4 refa599_inst.
Proof. unfold Equation4606. intro H. specialize (H F4_0 F4_2). unfold magma_op, refa599_inst, refa599_op in H. discriminate H. Qed.

Lemma refa599_not4631 : ~ @Equation4631 Fin4 refa599_inst.
Proof. unfold Equation4631. intro H. specialize (H F4_0 F4_0 F4_1). unfold magma_op, refa599_inst, refa599_op in H. discriminate H. Qed.

(** ---- refa6 (Fin8) ---- *)

Definition refa6_op (x y : Fin8) : Fin8 :=
  match x, y with
  | F8_0, F8_0 => F8_0 | F8_0, F8_1 => F8_3 | F8_0, F8_2 => F8_4 | F8_0, F8_3 => F8_6 | F8_0, F8_4 => F8_1 | F8_0, F8_5 => F8_2 | F8_0, F8_6 => F8_7 | F8_0, F8_7 => F8_5
  | F8_1, F8_0 => F8_4 | F8_1, F8_1 => F8_2 | F8_1, F8_2 => F8_0 | F8_1, F8_3 => F8_1 | F8_1, F8_4 => F8_6 | F8_1, F8_5 => F8_3 | F8_1, F8_6 => F8_5 | F8_1, F8_7 => F8_7
  | F8_2, F8_0 => F8_5 | F8_2, F8_1 => F8_6 | F8_2, F8_2 => F8_7 | F8_2, F8_3 => F8_3 | F8_2, F8_4 => F8_2 | F8_2, F8_5 => F8_1 | F8_2, F8_6 => F8_4 | F8_2, F8_7 => F8_0
  | F8_3, F8_0 => F8_1 | F8_3, F8_1 => F8_7 | F8_3, F8_2 => F8_6 | F8_3, F8_3 => F8_4 | F8_3, F8_4 => F8_0 | F8_3, F8_5 => F8_5 | F8_3, F8_6 => F8_3 | F8_3, F8_7 => F8_2
  | F8_4, F8_0 => F8_2 | F8_4, F8_1 => F8_4 | F8_4, F8_2 => F8_3 | F8_4, F8_3 => F8_7 | F8_4, F8_4 => F8_5 | F8_4, F8_5 => F8_0 | F8_4, F8_6 => F8_6 | F8_4, F8_7 => F8_1
  | F8_5, F8_0 => F8_7 | F8_5, F8_1 => F8_1 | F8_5, F8_2 => F8_5 | F8_5, F8_3 => F8_2 | F8_5, F8_4 => F8_3 | F8_5, F8_5 => F8_6 | F8_5, F8_6 => F8_0 | F8_5, F8_7 => F8_4
  | F8_6, F8_0 => F8_3 | F8_6, F8_1 => F8_0 | F8_6, F8_2 => F8_2 | F8_6, F8_3 => F8_5 | F8_6, F8_4 => F8_7 | F8_6, F8_5 => F8_4 | F8_6, F8_6 => F8_1 | F8_6, F8_7 => F8_6
  | F8_7, F8_0 => F8_6 | F8_7, F8_1 => F8_5 | F8_7, F8_2 => F8_1 | F8_7, F8_3 => F8_0 | F8_7, F8_4 => F8_4 | F8_7, F8_5 => F8_7 | F8_7, F8_6 => F8_2 | F8_7, F8_7 => F8_3
  end.

#[local] Instance refa6_inst : Magma Fin8 := {| magma_op := refa6_op |}.

Lemma refa6_sat1083 : @Equation1083 Fin8 refa6_inst.
Proof. unfold Equation1083, magma_op, refa6_inst, refa6_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa6_sat1085 : @Equation1085 Fin8 refa6_inst.
Proof. unfold Equation1085, magma_op, refa6_inst, refa6_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa6_not99 : ~ @Equation99 Fin8 refa6_inst.
Proof. unfold Equation99. intro H. specialize (H F8_1). unfold magma_op, refa6_inst, refa6_op in H. discriminate H. Qed.

Lemma refa6_not151 : ~ @Equation151 Fin8 refa6_inst.
Proof. unfold Equation151. intro H. specialize (H F8_1). unfold magma_op, refa6_inst, refa6_op in H. discriminate H. Qed.

Lemma refa6_not255 : ~ @Equation255 Fin8 refa6_inst.
Proof. unfold Equation255. intro H. specialize (H F8_1). unfold magma_op, refa6_inst, refa6_op in H. discriminate H. Qed.

Lemma refa6_not411 : ~ @Equation411 Fin8 refa6_inst.
Proof. unfold Equation411. intro H. specialize (H F8_1). unfold magma_op, refa6_inst, refa6_op in H. discriminate H. Qed.

Lemma refa6_not615 : ~ @Equation615 Fin8 refa6_inst.
Proof. unfold Equation615. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa6_inst, refa6_op in H. discriminate H. Qed.

Lemma refa6_not623 : ~ @Equation623 Fin8 refa6_inst.
Proof. unfold Equation623. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa6_inst, refa6_op in H. discriminate H. Qed.

Lemma refa6_not633 : ~ @Equation633 Fin8 refa6_inst.
Proof. unfold Equation633. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa6_inst, refa6_op in H. discriminate H. Qed.

Lemma refa6_not646 : ~ @Equation646 Fin8 refa6_inst.
Proof. unfold Equation646. intro H. specialize (H F8_0 F8_0 F8_1). unfold magma_op, refa6_inst, refa6_op in H. discriminate H. Qed.

Lemma refa6_not670 : ~ @Equation670 Fin8 refa6_inst.
Proof. unfold Equation670. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa6_inst, refa6_op in H. discriminate H. Qed.

Lemma refa6_not677 : ~ @Equation677 Fin8 refa6_inst.
Proof. unfold Equation677. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa6_inst, refa6_op in H. discriminate H. Qed.

Lemma refa6_not817 : ~ @Equation817 Fin8 refa6_inst.
Proof. unfold Equation817. intro H. specialize (H F8_1). unfold magma_op, refa6_inst, refa6_op in H. discriminate H. Qed.

Lemma refa6_not1021 : ~ @Equation1021 Fin8 refa6_inst.
Proof. unfold Equation1021. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa6_inst, refa6_op in H. discriminate H. Qed.

Lemma refa6_not1028 : ~ @Equation1028 Fin8 refa6_inst.
Proof. unfold Equation1028. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa6_inst, refa6_op in H. discriminate H. Qed.

Lemma refa6_not1029 : ~ @Equation1029 Fin8 refa6_inst.
Proof. unfold Equation1029. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa6_inst, refa6_op in H. discriminate H. Qed.

Lemma refa6_not1035 : ~ @Equation1035 Fin8 refa6_inst.
Proof. unfold Equation1035. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa6_inst, refa6_op in H. discriminate H. Qed.

Lemma refa6_not1036 : ~ @Equation1036 Fin8 refa6_inst.
Proof. unfold Equation1036. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa6_inst, refa6_op in H. discriminate H. Qed.

Lemma refa6_not1038 : ~ @Equation1038 Fin8 refa6_inst.
Proof. unfold Equation1038. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa6_inst, refa6_op in H. discriminate H. Qed.

Lemma refa6_not1039 : ~ @Equation1039 Fin8 refa6_inst.
Proof. unfold Equation1039. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa6_inst, refa6_op in H. discriminate H. Qed.

Lemma refa6_not1045 : ~ @Equation1045 Fin8 refa6_inst.
Proof. unfold Equation1045. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa6_inst, refa6_op in H. discriminate H. Qed.

Lemma refa6_not1049 : ~ @Equation1049 Fin8 refa6_inst.
Proof. unfold Equation1049. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa6_inst, refa6_op in H. discriminate H. Qed.

Lemma refa6_not1075 : ~ @Equation1075 Fin8 refa6_inst.
Proof. unfold Equation1075. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa6_inst, refa6_op in H. discriminate H. Qed.

Lemma refa6_not1076 : ~ @Equation1076 Fin8 refa6_inst.
Proof. unfold Equation1076. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa6_inst, refa6_op in H. discriminate H. Qed.

Lemma refa6_not1112 : ~ @Equation1112 Fin8 refa6_inst.
Proof. unfold Equation1112. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa6_inst, refa6_op in H. discriminate H. Qed.

Lemma refa6_not1223 : ~ @Equation1223 Fin8 refa6_inst.
Proof. unfold Equation1223. intro H. specialize (H F8_1). unfold magma_op, refa6_inst, refa6_op in H. discriminate H. Qed.

Lemma refa6_not1427 : ~ @Equation1427 Fin8 refa6_inst.
Proof. unfold Equation1427. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa6_inst, refa6_op in H. discriminate H. Qed.

Lemma refa6_not1435 : ~ @Equation1435 Fin8 refa6_inst.
Proof. unfold Equation1435. intro H. specialize (H F8_1 F8_0). unfold magma_op, refa6_inst, refa6_op in H. discriminate H. Qed.

Lemma refa6_not1445 : ~ @Equation1445 Fin8 refa6_inst.
Proof. unfold Equation1445. intro H. specialize (H F8_1 F8_0). unfold magma_op, refa6_inst, refa6_op in H. discriminate H. Qed.

Lemma refa6_not1486 : ~ @Equation1486 Fin8 refa6_inst.
Proof. unfold Equation1486. intro H. specialize (H F8_0 F8_0 F8_1). unfold magma_op, refa6_inst, refa6_op in H. discriminate H. Qed.

Lemma refa6_not1516 : ~ @Equation1516 Fin8 refa6_inst.
Proof. unfold Equation1516. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa6_inst, refa6_op in H. discriminate H. Qed.

Lemma refa6_not1629 : ~ @Equation1629 Fin8 refa6_inst.
Proof. unfold Equation1629. intro H. specialize (H F8_1). unfold magma_op, refa6_inst, refa6_op in H. discriminate H. Qed.

Lemma refa6_not1832 : ~ @Equation1832 Fin8 refa6_inst.
Proof. unfold Equation1832. intro H. specialize (H F8_1). unfold magma_op, refa6_inst, refa6_op in H. discriminate H. Qed.

Lemma refa6_not2035 : ~ @Equation2035 Fin8 refa6_inst.
Proof. unfold Equation2035. intro H. specialize (H F8_1). unfold magma_op, refa6_inst, refa6_op in H. discriminate H. Qed.

Lemma refa6_not2247 : ~ @Equation2247 Fin8 refa6_inst.
Proof. unfold Equation2247. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa6_inst, refa6_op in H. discriminate H. Qed.

Lemma refa6_not2257 : ~ @Equation2257 Fin8 refa6_inst.
Proof. unfold Equation2257. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa6_inst, refa6_op in H. discriminate H. Qed.

Lemma refa6_not2264 : ~ @Equation2264 Fin8 refa6_inst.
Proof. unfold Equation2264. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa6_inst, refa6_op in H. discriminate H. Qed.

Lemma refa6_not2301 : ~ @Equation2301 Fin8 refa6_inst.
Proof. unfold Equation2301. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa6_inst, refa6_op in H. discriminate H. Qed.

Lemma refa6_not2459 : ~ @Equation2459 Fin8 refa6_inst.
Proof. unfold Equation2459. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa6_inst, refa6_op in H. discriminate H. Qed.

Lemma refa6_not2460 : ~ @Equation2460 Fin8 refa6_inst.
Proof. unfold Equation2460. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa6_inst, refa6_op in H. discriminate H. Qed.

Lemma refa6_not2466 : ~ @Equation2466 Fin8 refa6_inst.
Proof. unfold Equation2466. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa6_inst, refa6_op in H. discriminate H. Qed.

Lemma refa6_not2497 : ~ @Equation2497 Fin8 refa6_inst.
Proof. unfold Equation2497. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa6_inst, refa6_op in H. discriminate H. Qed.

Lemma refa6_not2504 : ~ @Equation2504 Fin8 refa6_inst.
Proof. unfold Equation2504. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa6_inst, refa6_op in H. discriminate H. Qed.

Lemma refa6_not2506 : ~ @Equation2506 Fin8 refa6_inst.
Proof. unfold Equation2506. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa6_inst, refa6_op in H. discriminate H. Qed.

Lemma refa6_not2531 : ~ @Equation2531 Fin8 refa6_inst.
Proof. unfold Equation2531. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa6_inst, refa6_op in H. discriminate H. Qed.

Lemma refa6_not2646 : ~ @Equation2646 Fin8 refa6_inst.
Proof. unfold Equation2646. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa6_inst, refa6_op in H. discriminate H. Qed.

Lemma refa6_not2659 : ~ @Equation2659 Fin8 refa6_inst.
Proof. unfold Equation2659. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa6_inst, refa6_op in H. discriminate H. Qed.

Lemma refa6_not2670 : ~ @Equation2670 Fin8 refa6_inst.
Proof. unfold Equation2670. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa6_inst, refa6_op in H. discriminate H. Qed.

Lemma refa6_not2696 : ~ @Equation2696 Fin8 refa6_inst.
Proof. unfold Equation2696. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa6_inst, refa6_op in H. discriminate H. Qed.

Lemma refa6_not2700 : ~ @Equation2700 Fin8 refa6_inst.
Proof. unfold Equation2700. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa6_inst, refa6_op in H. discriminate H. Qed.

Lemma refa6_not2734 : ~ @Equation2734 Fin8 refa6_inst.
Proof. unfold Equation2734. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa6_inst, refa6_op in H. discriminate H. Qed.

Lemma refa6_not2849 : ~ @Equation2849 Fin8 refa6_inst.
Proof. unfold Equation2849. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa6_inst, refa6_op in H. discriminate H. Qed.

Lemma refa6_not2852 : ~ @Equation2852 Fin8 refa6_inst.
Proof. unfold Equation2852. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa6_inst, refa6_op in H. discriminate H. Qed.

Lemma refa6_not2873 : ~ @Equation2873 Fin8 refa6_inst.
Proof. unfold Equation2873. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa6_inst, refa6_op in H. discriminate H. Qed.

Lemma refa6_not2903 : ~ @Equation2903 Fin8 refa6_inst.
Proof. unfold Equation2903. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa6_inst, refa6_op in H. discriminate H. Qed.

Lemma refa6_not2910 : ~ @Equation2910 Fin8 refa6_inst.
Proof. unfold Equation2910. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa6_inst, refa6_op in H. discriminate H. Qed.

Lemma refa6_not2937 : ~ @Equation2937 Fin8 refa6_inst.
Proof. unfold Equation2937. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa6_inst, refa6_op in H. discriminate H. Qed.

Lemma refa6_not2946 : ~ @Equation2946 Fin8 refa6_inst.
Proof. unfold Equation2946. intro H. specialize (H F8_1 F8_0). unfold magma_op, refa6_inst, refa6_op in H. discriminate H. Qed.

Lemma refa6_not3055 : ~ @Equation3055 Fin8 refa6_inst.
Proof. unfold Equation3055. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa6_inst, refa6_op in H. discriminate H. Qed.

Lemma refa6_not3065 : ~ @Equation3065 Fin8 refa6_inst.
Proof. unfold Equation3065. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa6_inst, refa6_op in H. discriminate H. Qed.

Lemma refa6_not3076 : ~ @Equation3076 Fin8 refa6_inst.
Proof. unfold Equation3076. intro H. specialize (H F8_1 F8_0). unfold magma_op, refa6_inst, refa6_op in H. discriminate H. Qed.

Lemma refa6_not3149 : ~ @Equation3149 Fin8 refa6_inst.
Proof. unfold Equation3149. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa6_inst, refa6_op in H. discriminate H. Qed.

Lemma refa6_not3253 : ~ @Equation3253 Fin8 refa6_inst.
Proof. unfold Equation3253. intro H. specialize (H F8_1). unfold magma_op, refa6_inst, refa6_op in H. discriminate H. Qed.

Lemma refa6_not3457 : ~ @Equation3457 Fin8 refa6_inst.
Proof. unfold Equation3457. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa6_inst, refa6_op in H. discriminate H. Qed.

Lemma refa6_not3458 : ~ @Equation3458 Fin8 refa6_inst.
Proof. unfold Equation3458. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa6_inst, refa6_op in H. discriminate H. Qed.

Lemma refa6_not3461 : ~ @Equation3461 Fin8 refa6_inst.
Proof. unfold Equation3461. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa6_inst, refa6_op in H. discriminate H. Qed.

Lemma refa6_not3465 : ~ @Equation3465 Fin8 refa6_inst.
Proof. unfold Equation3465. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa6_inst, refa6_op in H. discriminate H. Qed.

Lemma refa6_not3475 : ~ @Equation3475 Fin8 refa6_inst.
Proof. unfold Equation3475. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa6_inst, refa6_op in H. discriminate H. Qed.

Lemma refa6_not3512 : ~ @Equation3512 Fin8 refa6_inst.
Proof. unfold Equation3512. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa6_inst, refa6_op in H. discriminate H. Qed.

Lemma refa6_not3519 : ~ @Equation3519 Fin8 refa6_inst.
Proof. unfold Equation3519. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa6_inst, refa6_op in H. discriminate H. Qed.

Lemma refa6_not3521 : ~ @Equation3521 Fin8 refa6_inst.
Proof. unfold Equation3521. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa6_inst, refa6_op in H. discriminate H. Qed.

Lemma refa6_not3555 : ~ @Equation3555 Fin8 refa6_inst.
Proof. unfold Equation3555. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa6_inst, refa6_op in H. discriminate H. Qed.

Lemma refa6_not3660 : ~ @Equation3660 Fin8 refa6_inst.
Proof. unfold Equation3660. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa6_inst, refa6_op in H. discriminate H. Qed.

Lemma refa6_not3662 : ~ @Equation3662 Fin8 refa6_inst.
Proof. unfold Equation3662. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa6_inst, refa6_op in H. discriminate H. Qed.

Lemma refa6_not3665 : ~ @Equation3665 Fin8 refa6_inst.
Proof. unfold Equation3665. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa6_inst, refa6_op in H. discriminate H. Qed.

Lemma refa6_not3668 : ~ @Equation3668 Fin8 refa6_inst.
Proof. unfold Equation3668. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa6_inst, refa6_op in H. discriminate H. Qed.

Lemma refa6_not3674 : ~ @Equation3674 Fin8 refa6_inst.
Proof. unfold Equation3674. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa6_inst, refa6_op in H. discriminate H. Qed.

Lemma refa6_not3677 : ~ @Equation3677 Fin8 refa6_inst.
Proof. unfold Equation3677. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa6_inst, refa6_op in H. discriminate H. Qed.

Lemma refa6_not3678 : ~ @Equation3678 Fin8 refa6_inst.
Proof. unfold Equation3678. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa6_inst, refa6_op in H. discriminate H. Qed.

Lemma refa6_not3684 : ~ @Equation3684 Fin8 refa6_inst.
Proof. unfold Equation3684. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa6_inst, refa6_op in H. discriminate H. Qed.

Lemma refa6_not3685 : ~ @Equation3685 Fin8 refa6_inst.
Proof. unfold Equation3685. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa6_inst, refa6_op in H. discriminate H. Qed.

Lemma refa6_not3714 : ~ @Equation3714 Fin8 refa6_inst.
Proof. unfold Equation3714. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa6_inst, refa6_op in H. discriminate H. Qed.

Lemma refa6_not3721 : ~ @Equation3721 Fin8 refa6_inst.
Proof. unfold Equation3721. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa6_inst, refa6_op in H. discriminate H. Qed.

Lemma refa6_not3724 : ~ @Equation3724 Fin8 refa6_inst.
Proof. unfold Equation3724. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa6_inst, refa6_op in H. discriminate H. Qed.

Lemma refa6_not3725 : ~ @Equation3725 Fin8 refa6_inst.
Proof. unfold Equation3725. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa6_inst, refa6_op in H. discriminate H. Qed.

Lemma refa6_not3749 : ~ @Equation3749 Fin8 refa6_inst.
Proof. unfold Equation3749. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa6_inst, refa6_op in H. discriminate H. Qed.

Lemma refa6_not3761 : ~ @Equation3761 Fin8 refa6_inst.
Proof. unfold Equation3761. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa6_inst, refa6_op in H. discriminate H. Qed.

Lemma refa6_not3862 : ~ @Equation3862 Fin8 refa6_inst.
Proof. unfold Equation3862. intro H. specialize (H F8_1). unfold magma_op, refa6_inst, refa6_op in H. discriminate H. Qed.

Lemma refa6_not4065 : ~ @Equation4065 Fin8 refa6_inst.
Proof. unfold Equation4065. intro H. specialize (H F8_1). unfold magma_op, refa6_inst, refa6_op in H. discriminate H. Qed.

Lemma refa6_not4268 : ~ @Equation4268 Fin8 refa6_inst.
Proof. unfold Equation4268. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa6_inst, refa6_op in H. discriminate H. Qed.

Lemma refa6_not4269 : ~ @Equation4269 Fin8 refa6_inst.
Proof. unfold Equation4269. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa6_inst, refa6_op in H. discriminate H. Qed.

Lemma refa6_not4270 : ~ @Equation4270 Fin8 refa6_inst.
Proof. unfold Equation4270. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa6_inst, refa6_op in H. discriminate H. Qed.

Lemma refa6_not4275 : ~ @Equation4275 Fin8 refa6_inst.
Proof. unfold Equation4275. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa6_inst, refa6_op in H. discriminate H. Qed.

Lemma refa6_not4284 : ~ @Equation4284 Fin8 refa6_inst.
Proof. unfold Equation4284. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa6_inst, refa6_op in H. discriminate H. Qed.

Lemma refa6_not4290 : ~ @Equation4290 Fin8 refa6_inst.
Proof. unfold Equation4290. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa6_inst, refa6_op in H. discriminate H. Qed.

Lemma refa6_not4303 : ~ @Equation4303 Fin8 refa6_inst.
Proof. unfold Equation4303. intro H. specialize (H F8_0 F8_0 F8_1). unfold magma_op, refa6_inst, refa6_op in H. discriminate H. Qed.

Lemma refa6_not4314 : ~ @Equation4314 Fin8 refa6_inst.
Proof. unfold Equation4314. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa6_inst, refa6_op in H. discriminate H. Qed.

Lemma refa6_not4320 : ~ @Equation4320 Fin8 refa6_inst.
Proof. unfold Equation4320. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa6_inst, refa6_op in H. discriminate H. Qed.

Lemma refa6_not4408 : ~ @Equation4408 Fin8 refa6_inst.
Proof. unfold Equation4408. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa6_inst, refa6_op in H. discriminate H. Qed.

Lemma refa6_not4436 : ~ @Equation4436 Fin8 refa6_inst.
Proof. unfold Equation4436. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa6_inst, refa6_op in H. discriminate H. Qed.

Lemma refa6_not4443 : ~ @Equation4443 Fin8 refa6_inst.
Proof. unfold Equation4443. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa6_inst, refa6_op in H. discriminate H. Qed.

Lemma refa6_not4472 : ~ @Equation4472 Fin8 refa6_inst.
Proof. unfold Equation4472. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa6_inst, refa6_op in H. discriminate H. Qed.

Lemma refa6_not4479 : ~ @Equation4479 Fin8 refa6_inst.
Proof. unfold Equation4479. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa6_inst, refa6_op in H. discriminate H. Qed.

Lemma refa6_not4583 : ~ @Equation4583 Fin8 refa6_inst.
Proof. unfold Equation4583. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa6_inst, refa6_op in H. discriminate H. Qed.

Lemma refa6_not4584 : ~ @Equation4584 Fin8 refa6_inst.
Proof. unfold Equation4584. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa6_inst, refa6_op in H. discriminate H. Qed.

Lemma refa6_not4587 : ~ @Equation4587 Fin8 refa6_inst.
Proof. unfold Equation4587. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa6_inst, refa6_op in H. discriminate H. Qed.

Lemma refa6_not4588 : ~ @Equation4588 Fin8 refa6_inst.
Proof. unfold Equation4588. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa6_inst, refa6_op in H. discriminate H. Qed.

Lemma refa6_not4590 : ~ @Equation4590 Fin8 refa6_inst.
Proof. unfold Equation4590. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa6_inst, refa6_op in H. discriminate H. Qed.

Lemma refa6_not4591 : ~ @Equation4591 Fin8 refa6_inst.
Proof. unfold Equation4591. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa6_inst, refa6_op in H. discriminate H. Qed.

Lemma refa6_not4598 : ~ @Equation4598 Fin8 refa6_inst.
Proof. unfold Equation4598. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa6_inst, refa6_op in H. discriminate H. Qed.

Lemma refa6_not4599 : ~ @Equation4599 Fin8 refa6_inst.
Proof. unfold Equation4599. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa6_inst, refa6_op in H. discriminate H. Qed.

Lemma refa6_not4606 : ~ @Equation4606 Fin8 refa6_inst.
Proof. unfold Equation4606. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa6_inst, refa6_op in H. discriminate H. Qed.

Lemma refa6_not4608 : ~ @Equation4608 Fin8 refa6_inst.
Proof. unfold Equation4608. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa6_inst, refa6_op in H. discriminate H. Qed.

Lemma refa6_not4629 : ~ @Equation4629 Fin8 refa6_inst.
Proof. unfold Equation4629. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa6_inst, refa6_op in H. discriminate H. Qed.

Lemma refa6_not4636 : ~ @Equation4636 Fin8 refa6_inst.
Proof. unfold Equation4636. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa6_inst, refa6_op in H. discriminate H. Qed.

Lemma refa6_not4658 : ~ @Equation4658 Fin8 refa6_inst.
Proof. unfold Equation4658. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa6_inst, refa6_op in H. discriminate H. Qed.

(** ---- refa60 (Fin3) ---- *)

Definition refa60_op (x y : Fin3) : Fin3 :=
  match x, y with
  | F3_0, F3_0 => F3_1 | F3_0, F3_1 => F3_0 | F3_0, F3_2 => F3_2
  | F3_1, F3_0 => F3_1 | F3_1, F3_1 => F3_0 | F3_1, F3_2 => F3_2
  | F3_2, F3_0 => F3_1 | F3_2, F3_1 => F3_0 | F3_2, F3_2 => F3_0
  end.

#[local] Instance refa60_inst : Magma Fin3 := {| magma_op := refa60_op |}.

Lemma refa60_sat1724 : @Equation1724 Fin3 refa60_inst.
Proof. unfold Equation1724, magma_op, refa60_inst, refa60_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa60_not3255 : ~ @Equation3255 Fin3 refa60_inst.
Proof. unfold Equation3255. intro H. specialize (H F3_2 F3_0). unfold magma_op, refa60_inst, refa60_op in H. discriminate H. Qed.

Lemma refa60_not3271 : ~ @Equation3271 Fin3 refa60_inst.
Proof. unfold Equation3271. intro H. specialize (H F3_2 F3_0). unfold magma_op, refa60_inst, refa60_op in H. discriminate H. Qed.

Lemma refa60_not4269 : ~ @Equation4269 Fin3 refa60_inst.
Proof. unfold Equation4269. intro H. specialize (H F3_2 F3_0). unfold magma_op, refa60_inst, refa60_op in H. discriminate H. Qed.

Lemma refa60_not4270 : ~ @Equation4270 Fin3 refa60_inst.
Proof. unfold Equation4270. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa60_inst, refa60_op in H. discriminate H. Qed.

Lemma refa60_not4314 : ~ @Equation4314 Fin3 refa60_inst.
Proof. unfold Equation4314. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa60_inst, refa60_op in H. discriminate H. Qed.

(** ---- refa600 (Fin4) ---- *)

Definition refa600_op (x y : Fin4) : Fin4 :=
  match x, y with
  | F4_0, F4_0 => F4_1 | F4_0, F4_1 => F4_1 | F4_0, F4_2 => F4_1 | F4_0, F4_3 => F4_3
  | F4_1, F4_0 => F4_3 | F4_1, F4_1 => F4_1 | F4_1, F4_2 => F4_2 | F4_1, F4_3 => F4_0
  | F4_2, F4_0 => F4_3 | F4_2, F4_1 => F4_1 | F4_2, F4_2 => F4_2 | F4_2, F4_3 => F4_0
  | F4_3, F4_0 => F4_0 | F4_3, F4_1 => F4_1 | F4_3, F4_2 => F4_1 | F4_3, F4_3 => F4_2
  end.

#[local] Instance refa600_inst : Magma Fin4 := {| magma_op := refa600_op |}.

Lemma refa600_sat3007 : @Equation3007 Fin4 refa600_inst.
Proof. unfold Equation3007, magma_op, refa600_inst, refa600_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa600_not3253 : ~ @Equation3253 Fin4 refa600_inst.
Proof. unfold Equation3253. intro H. specialize (H F4_3). unfold magma_op, refa600_inst, refa600_op in H. discriminate H. Qed.

Lemma refa600_not3664 : ~ @Equation3664 Fin4 refa600_inst.
Proof. unfold Equation3664. intro H. specialize (H F4_2 F4_0). unfold magma_op, refa600_inst, refa600_op in H. discriminate H. Qed.

Lemma refa600_not3674 : ~ @Equation3674 Fin4 refa600_inst.
Proof. unfold Equation3674. intro H. specialize (H F4_3 F4_0). unfold magma_op, refa600_inst, refa600_op in H. discriminate H. Qed.

Lemma refa600_not3677 : ~ @Equation3677 Fin4 refa600_inst.
Proof. unfold Equation3677. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa600_inst, refa600_op in H. discriminate H. Qed.

(** ---- refa601 (Fin4) ---- *)

Definition refa601_op (x y : Fin4) : Fin4 :=
  match x, y with
  | F4_0, F4_0 => F4_1 | F4_0, F4_1 => F4_1 | F4_0, F4_2 => F4_1 | F4_0, F4_3 => F4_1
  | F4_1, F4_0 => F4_2 | F4_1, F4_1 => F4_2 | F4_1, F4_2 => F4_2 | F4_1, F4_3 => F4_2
  | F4_2, F4_0 => F4_3 | F4_2, F4_1 => F4_3 | F4_2, F4_2 => F4_3 | F4_2, F4_3 => F4_3
  | F4_3, F4_0 => F4_0 | F4_3, F4_1 => F4_0 | F4_3, F4_2 => F4_0 | F4_3, F4_3 => F4_0
  end.

#[local] Instance refa601_inst : Magma Fin4 := {| magma_op := refa601_op |}.

Lemma refa601_sat3072 : @Equation3072 Fin4 refa601_inst.
Proof. unfold Equation3072, magma_op, refa601_inst, refa601_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa601_not151 : ~ @Equation151 Fin4 refa601_inst.
Proof. unfold Equation151. intro H. specialize (H F4_0). unfold magma_op, refa601_inst, refa601_op in H. discriminate H. Qed.

Lemma refa601_not203 : ~ @Equation203 Fin4 refa601_inst.
Proof. unfold Equation203. intro H. specialize (H F4_0). unfold magma_op, refa601_inst, refa601_op in H. discriminate H. Qed.

Lemma refa601_not1426 : ~ @Equation1426 Fin4 refa601_inst.
Proof. unfold Equation1426. intro H. specialize (H F4_0). unfold magma_op, refa601_inst, refa601_op in H. discriminate H. Qed.

Lemma refa601_not1629 : ~ @Equation1629 Fin4 refa601_inst.
Proof. unfold Equation1629. intro H. specialize (H F4_0). unfold magma_op, refa601_inst, refa601_op in H. discriminate H. Qed.

Lemma refa601_not1832 : ~ @Equation1832 Fin4 refa601_inst.
Proof. unfold Equation1832. intro H. specialize (H F4_0). unfold magma_op, refa601_inst, refa601_op in H. discriminate H. Qed.

Lemma refa601_not2238 : ~ @Equation2238 Fin4 refa601_inst.
Proof. unfold Equation2238. intro H. specialize (H F4_0). unfold magma_op, refa601_inst, refa601_op in H. discriminate H. Qed.

Lemma refa601_not2441 : ~ @Equation2441 Fin4 refa601_inst.
Proof. unfold Equation2441. intro H. specialize (H F4_0). unfold magma_op, refa601_inst, refa601_op in H. discriminate H. Qed.

Lemma refa601_not2644 : ~ @Equation2644 Fin4 refa601_inst.
Proof. unfold Equation2644. intro H. specialize (H F4_0). unfold magma_op, refa601_inst, refa601_op in H. discriminate H. Qed.

Lemma refa601_not3659 : ~ @Equation3659 Fin4 refa601_inst.
Proof. unfold Equation3659. intro H. specialize (H F4_0). unfold magma_op, refa601_inst, refa601_op in H. discriminate H. Qed.

Lemma refa601_not4065 : ~ @Equation4065 Fin4 refa601_inst.
Proof. unfold Equation4065. intro H. specialize (H F4_0). unfold magma_op, refa601_inst, refa601_op in H. discriminate H. Qed.

(** ---- refa602 (Fin4) ---- *)

Definition refa602_op (x y : Fin4) : Fin4 :=
  match x, y with
  | F4_0, F4_0 => F4_3 | F4_0, F4_1 => F4_1 | F4_0, F4_2 => F4_3 | F4_0, F4_3 => F4_1
  | F4_1, F4_0 => F4_3 | F4_1, F4_1 => F4_1 | F4_1, F4_2 => F4_3 | F4_1, F4_3 => F4_1
  | F4_2, F4_0 => F4_2 | F4_2, F4_1 => F4_0 | F4_2, F4_2 => F4_2 | F4_2, F4_3 => F4_0
  | F4_3, F4_0 => F4_2 | F4_3, F4_1 => F4_2 | F4_3, F4_2 => F4_2 | F4_3, F4_3 => F4_2
  end.

#[local] Instance refa602_inst : Magma Fin4 := {| magma_op := refa602_op |}.

Lemma refa602_sat2089 : @Equation2089 Fin4 refa602_inst.
Proof. unfold Equation2089, magma_op, refa602_inst, refa602_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa602_not151 : ~ @Equation151 Fin4 refa602_inst.
Proof. unfold Equation151. intro H. specialize (H F4_0). unfold magma_op, refa602_inst, refa602_op in H. discriminate H. Qed.

Lemma refa602_not1426 : ~ @Equation1426 Fin4 refa602_inst.
Proof. unfold Equation1426. intro H. specialize (H F4_0). unfold magma_op, refa602_inst, refa602_op in H. discriminate H. Qed.

Lemma refa602_not2050 : ~ @Equation2050 Fin4 refa602_inst.
Proof. unfold Equation2050. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa602_inst, refa602_op in H. discriminate H. Qed.

Lemma refa602_not2051 : ~ @Equation2051 Fin4 refa602_inst.
Proof. unfold Equation2051. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa602_inst, refa602_op in H. discriminate H. Qed.

Lemma refa602_not2124 : ~ @Equation2124 Fin4 refa602_inst.
Proof. unfold Equation2124. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa602_inst, refa602_op in H. discriminate H. Qed.

Lemma refa602_not2125 : ~ @Equation2125 Fin4 refa602_inst.
Proof. unfold Equation2125. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa602_inst, refa602_op in H. discriminate H. Qed.

Lemma refa602_not3862 : ~ @Equation3862 Fin4 refa602_inst.
Proof. unfold Equation3862. intro H. specialize (H F4_3). unfold magma_op, refa602_inst, refa602_op in H. discriminate H. Qed.

(** ---- refa603 (Fin4) ---- *)

Definition refa603_op (x y : Fin4) : Fin4 :=
  match x, y with
  | F4_0, F4_0 => F4_3 | F4_0, F4_1 => F4_1 | F4_0, F4_2 => F4_0 | F4_0, F4_3 => F4_1
  | F4_1, F4_0 => F4_2 | F4_1, F4_1 => F4_2 | F4_1, F4_2 => F4_1 | F4_1, F4_3 => F4_2
  | F4_2, F4_0 => F4_2 | F4_2, F4_1 => F4_2 | F4_2, F4_2 => F4_2 | F4_2, F4_3 => F4_2
  | F4_3, F4_0 => F4_2 | F4_3, F4_1 => F4_3 | F4_3, F4_2 => F4_3 | F4_3, F4_3 => F4_2
  end.

#[local] Instance refa603_inst : Magma Fin4 := {| magma_op := refa603_op |}.

Lemma refa603_sat1052 : @Equation1052 Fin4 refa603_inst.
Proof. unfold Equation1052, magma_op, refa603_inst, refa603_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa603_sat1243 : @Equation1243 Fin4 refa603_inst.
Proof. unfold Equation1243, magma_op, refa603_inst, refa603_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa603_sat1245 : @Equation1245 Fin4 refa603_inst.
Proof. unfold Equation1245, magma_op, refa603_inst, refa603_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa603_sat1255 : @Equation1255 Fin4 refa603_inst.
Proof. unfold Equation1255, magma_op, refa603_inst, refa603_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa603_sat1263 : @Equation1263 Fin4 refa603_inst.
Proof. unfold Equation1263, magma_op, refa603_inst, refa603_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa603_not107 : ~ @Equation107 Fin4 refa603_inst.
Proof. unfold Equation107. intro H. specialize (H F4_1 F4_0). unfold magma_op, refa603_inst, refa603_op in H. discriminate H. Qed.

Lemma refa603_not818 : ~ @Equation818 Fin4 refa603_inst.
Proof. unfold Equation818. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa603_inst, refa603_op in H. discriminate H. Qed.

Lemma refa603_not845 : ~ @Equation845 Fin4 refa603_inst.
Proof. unfold Equation845. intro H. specialize (H F4_1 F4_0). unfold magma_op, refa603_inst, refa603_op in H. discriminate H. Qed.

Lemma refa603_not1248 : ~ @Equation1248 Fin4 refa603_inst.
Proof. unfold Equation1248. intro H. specialize (H F4_1 F4_0). unfold magma_op, refa603_inst, refa603_op in H. discriminate H. Qed.

Lemma refa603_not3253 : ~ @Equation3253 Fin4 refa603_inst.
Proof. unfold Equation3253. intro H. specialize (H F4_0). unfold magma_op, refa603_inst, refa603_op in H. discriminate H. Qed.

Lemma refa603_not4065 : ~ @Equation4065 Fin4 refa603_inst.
Proof. unfold Equation4065. intro H. specialize (H F4_0). unfold magma_op, refa603_inst, refa603_op in H. discriminate H. Qed.

(** ---- refa604 (Fin4) ---- *)

Definition refa604_op (x y : Fin4) : Fin4 :=
  match x, y with
  | F4_0, F4_0 => F4_3 | F4_0, F4_1 => F4_2 | F4_0, F4_2 => F4_2 | F4_0, F4_3 => F4_3
  | F4_1, F4_0 => F4_3 | F4_1, F4_1 => F4_3 | F4_1, F4_2 => F4_2 | F4_1, F4_3 => F4_0
  | F4_2, F4_0 => F4_2 | F4_2, F4_1 => F4_2 | F4_2, F4_2 => F4_2 | F4_2, F4_3 => F4_0
  | F4_3, F4_0 => F4_3 | F4_3, F4_1 => F4_0 | F4_3, F4_2 => F4_0 | F4_3, F4_3 => F4_3
  end.

#[local] Instance refa604_inst : Magma Fin4 := {| magma_op := refa604_op |}.

Lemma refa604_sat3548 : @Equation3548 Fin4 refa604_inst.
Proof. unfold Equation3548, magma_op, refa604_inst, refa604_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa604_not4065 : ~ @Equation4065 Fin4 refa604_inst.
Proof. unfold Equation4065. intro H. specialize (H F4_1). unfold magma_op, refa604_inst, refa604_op in H. discriminate H. Qed.

(** ---- refa605 (Fin4) ---- *)

Definition refa605_op (x y : Fin4) : Fin4 :=
  match x, y with
  | F4_0, F4_0 => F4_1 | F4_0, F4_1 => F4_3 | F4_0, F4_2 => F4_1 | F4_0, F4_3 => F4_3
  | F4_1, F4_0 => F4_3 | F4_1, F4_1 => F4_3 | F4_1, F4_2 => F4_3 | F4_1, F4_3 => F4_3
  | F4_2, F4_0 => F4_3 | F4_2, F4_1 => F4_3 | F4_2, F4_2 => F4_1 | F4_2, F4_3 => F4_3
  | F4_3, F4_0 => F4_3 | F4_3, F4_1 => F4_3 | F4_3, F4_2 => F4_3 | F4_3, F4_3 => F4_3
  end.

#[local] Instance refa605_inst : Magma Fin4 := {| magma_op := refa605_op |}.

Lemma refa605_sat4526 : @Equation4526 Fin4 refa605_inst.
Proof. unfold Equation4526, magma_op, refa605_inst, refa605_op. intros x y z w. destruct x, y, z, w; reflexivity. Qed.

Lemma refa605_not43 : ~ @Equation43 Fin4 refa605_inst.
Proof. unfold Equation43. intro H. specialize (H F4_0 F4_2). unfold magma_op, refa605_inst, refa605_op in H. discriminate H. Qed.

(** ---- refa606 (Fin4) ---- *)

Definition refa606_op (x y : Fin4) : Fin4 :=
  match x, y with
  | F4_0, F4_0 => F4_1 | F4_0, F4_1 => F4_1 | F4_0, F4_2 => F4_2 | F4_0, F4_3 => F4_1
  | F4_1, F4_0 => F4_3 | F4_1, F4_1 => F4_3 | F4_1, F4_2 => F4_3 | F4_1, F4_3 => F4_3
  | F4_2, F4_0 => F4_3 | F4_2, F4_1 => F4_3 | F4_2, F4_2 => F4_1 | F4_2, F4_3 => F4_3
  | F4_3, F4_0 => F4_0 | F4_3, F4_1 => F4_0 | F4_3, F4_2 => F4_0 | F4_3, F4_3 => F4_0
  end.

#[local] Instance refa606_inst : Magma Fin4 := {| magma_op := refa606_op |}.

Lemma refa606_sat2878 : @Equation2878 Fin4 refa606_inst.
Proof. unfold Equation2878, magma_op, refa606_inst, refa606_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa606_not255 : ~ @Equation255 Fin4 refa606_inst.
Proof. unfold Equation255. intro H. specialize (H F4_2). unfold magma_op, refa606_inst, refa606_op in H. discriminate H. Qed.

Lemma refa606_not2035 : ~ @Equation2035 Fin4 refa606_inst.
Proof. unfold Equation2035. intro H. specialize (H F4_2). unfold magma_op, refa606_inst, refa606_op in H. discriminate H. Qed.

Lemma refa606_not2644 : ~ @Equation2644 Fin4 refa606_inst.
Proof. unfold Equation2644. intro H. specialize (H F4_2). unfold magma_op, refa606_inst, refa606_op in H. discriminate H. Qed.

Lemma refa606_not2855 : ~ @Equation2855 Fin4 refa606_inst.
Proof. unfold Equation2855. intro H. specialize (H F4_0 F4_2). unfold magma_op, refa606_inst, refa606_op in H. discriminate H. Qed.

Lemma refa606_not2865 : ~ @Equation2865 Fin4 refa606_inst.
Proof. unfold Equation2865. intro H. specialize (H F4_2 F4_0). unfold magma_op, refa606_inst, refa606_op in H. discriminate H. Qed.

Lemma refa606_not3253 : ~ @Equation3253 Fin4 refa606_inst.
Proof. unfold Equation3253. intro H. specialize (H F4_2). unfold magma_op, refa606_inst, refa606_op in H. discriminate H. Qed.

Lemma refa606_not3456 : ~ @Equation3456 Fin4 refa606_inst.
Proof. unfold Equation3456. intro H. specialize (H F4_2). unfold magma_op, refa606_inst, refa606_op in H. discriminate H. Qed.

Lemma refa606_not4269 : ~ @Equation4269 Fin4 refa606_inst.
Proof. unfold Equation4269. intro H. specialize (H F4_2 F4_0). unfold magma_op, refa606_inst, refa606_op in H. discriminate H. Qed.

Lemma refa606_not4284 : ~ @Equation4284 Fin4 refa606_inst.
Proof. unfold Equation4284. intro H. specialize (H F4_0 F4_2). unfold magma_op, refa606_inst, refa606_op in H. discriminate H. Qed.

Lemma refa606_not4599 : ~ @Equation4599 Fin4 refa606_inst.
Proof. unfold Equation4599. intro H. specialize (H F4_0 F4_2). unfold magma_op, refa606_inst, refa606_op in H. discriminate H. Qed.

Lemma refa606_not4631 : ~ @Equation4631 Fin4 refa606_inst.
Proof. unfold Equation4631. intro H. specialize (H F4_2 F4_0 F4_2). unfold magma_op, refa606_inst, refa606_op in H. discriminate H. Qed.

(** ---- refa607 (Fin4) ---- *)

Definition refa607_op (x y : Fin4) : Fin4 :=
  match x, y with
  | F4_0, F4_0 => F4_2 | F4_0, F4_1 => F4_0 | F4_0, F4_2 => F4_2 | F4_0, F4_3 => F4_3
  | F4_1, F4_0 => F4_3 | F4_1, F4_1 => F4_0 | F4_1, F4_2 => F4_2 | F4_1, F4_3 => F4_3
  | F4_2, F4_0 => F4_0 | F4_2, F4_1 => F4_1 | F4_2, F4_2 => F4_2 | F4_2, F4_3 => F4_3
  | F4_3, F4_0 => F4_1 | F4_3, F4_1 => F4_1 | F4_3, F4_2 => F4_2 | F4_3, F4_3 => F4_2
  end.

#[local] Instance refa607_inst : Magma Fin4 := {| magma_op := refa607_op |}.

Lemma refa607_sat2318 : @Equation2318 Fin4 refa607_inst.
Proof. unfold Equation2318, magma_op, refa607_inst, refa607_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa607_not2253 : ~ @Equation2253 Fin4 refa607_inst.
Proof. unfold Equation2253. intro H. specialize (H F4_1 F4_3). unfold magma_op, refa607_inst, refa607_op in H. discriminate H. Qed.

Lemma refa607_not2256 : ~ @Equation2256 Fin4 refa607_inst.
Proof. unfold Equation2256. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa607_inst, refa607_op in H. discriminate H. Qed.

Lemma refa607_not2266 : ~ @Equation2266 Fin4 refa607_inst.
Proof. unfold Equation2266. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa607_inst, refa607_op in H. discriminate H. Qed.

(** ---- refa608 (Fin4) ---- *)

Definition refa608_op (x y : Fin4) : Fin4 :=
  match x, y with
  | F4_0, F4_0 => F4_3 | F4_0, F4_1 => F4_3 | F4_0, F4_2 => F4_1 | F4_0, F4_3 => F4_3
  | F4_1, F4_0 => F4_3 | F4_1, F4_1 => F4_3 | F4_1, F4_2 => F4_3 | F4_1, F4_3 => F4_3
  | F4_2, F4_0 => F4_3 | F4_2, F4_1 => F4_3 | F4_2, F4_2 => F4_0 | F4_2, F4_3 => F4_3
  | F4_3, F4_0 => F4_3 | F4_3, F4_1 => F4_3 | F4_3, F4_2 => F4_0 | F4_3, F4_3 => F4_3
  end.

#[local] Instance refa608_inst : Magma Fin4 := {| magma_op := refa608_op |}.

Lemma refa608_sat3909 : @Equation3909 Fin4 refa608_inst.
Proof. unfold Equation3909, magma_op, refa608_inst, refa608_op. intros x y z w. destruct x, y, z, w; reflexivity. Qed.

Lemma refa608_not4065 : ~ @Equation4065 Fin4 refa608_inst.
Proof. unfold Equation4065. intro H. specialize (H F4_2). unfold magma_op, refa608_inst, refa608_op in H. discriminate H. Qed.

(** ---- refa609 (Fin4) ---- *)

Definition refa609_op (x y : Fin4) : Fin4 :=
  match x, y with
  | F4_0, F4_0 => F4_0 | F4_0, F4_1 => F4_0 | F4_0, F4_2 => F4_0 | F4_0, F4_3 => F4_0
  | F4_1, F4_0 => F4_2 | F4_1, F4_1 => F4_1 | F4_1, F4_2 => F4_1 | F4_1, F4_3 => F4_1
  | F4_2, F4_0 => F4_1 | F4_2, F4_1 => F4_3 | F4_2, F4_2 => F4_2 | F4_2, F4_3 => F4_2
  | F4_3, F4_0 => F4_1 | F4_3, F4_1 => F4_3 | F4_3, F4_2 => F4_3 | F4_3, F4_3 => F4_3
  end.

#[local] Instance refa609_inst : Magma Fin4 := {| magma_op := refa609_op |}.

Lemma refa609_sat1032 : @Equation1032 Fin4 refa609_inst.
Proof. unfold Equation1032, magma_op, refa609_inst, refa609_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa609_not1023 : ~ @Equation1023 Fin4 refa609_inst.
Proof. unfold Equation1023. intro H. specialize (H F4_2 F4_0). unfold magma_op, refa609_inst, refa609_op in H. discriminate H. Qed.

Lemma refa609_not1838 : ~ @Equation1838 Fin4 refa609_inst.
Proof. unfold Equation1838. intro H. specialize (H F4_2 F4_0). unfold magma_op, refa609_inst, refa609_op in H. discriminate H. Qed.

Lemma refa609_not4127 : ~ @Equation4127 Fin4 refa609_inst.
Proof. unfold Equation4127. intro H. specialize (H F4_1 F4_0). unfold magma_op, refa609_inst, refa609_op in H. discriminate H. Qed.

(** ---- refa61 (Fin3) ---- *)

Definition refa61_op (x y : Fin3) : Fin3 :=
  match x, y with
  | F3_0, F3_0 => F3_0 | F3_0, F3_1 => F3_0 | F3_0, F3_2 => F3_1
  | F3_1, F3_0 => F3_2 | F3_1, F3_1 => F3_1 | F3_1, F3_2 => F3_2
  | F3_2, F3_0 => F3_0 | F3_2, F3_1 => F3_0 | F3_2, F3_2 => F3_1
  end.

#[local] Instance refa61_inst : Magma Fin3 := {| magma_op := refa61_op |}.

Lemma refa61_sat3997 : @Equation3997 Fin3 refa61_inst.
Proof. unfold Equation3997, magma_op, refa61_inst, refa61_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa61_not3887 : ~ @Equation3887 Fin3 refa61_inst.
Proof. unfold Equation3887. intro H. specialize (H F3_1 F3_0). unfold magma_op, refa61_inst, refa61_op in H. discriminate H. Qed.

Lemma refa61_not3962 : ~ @Equation3962 Fin3 refa61_inst.
Proof. unfold Equation3962. intro H. specialize (H F3_1 F3_0). unfold magma_op, refa61_inst, refa61_op in H. discriminate H. Qed.

(** ---- refa610 (Fin4) ---- *)

Definition refa610_op (x y : Fin4) : Fin4 :=
  match x, y with
  | F4_0, F4_0 => F4_0 | F4_0, F4_1 => F4_3 | F4_0, F4_2 => F4_1 | F4_0, F4_3 => F4_3
  | F4_1, F4_0 => F4_3 | F4_1, F4_1 => F4_1 | F4_1, F4_2 => F4_2 | F4_1, F4_3 => F4_3
  | F4_2, F4_0 => F4_3 | F4_2, F4_1 => F4_1 | F4_2, F4_2 => F4_2 | F4_2, F4_3 => F4_3
  | F4_3, F4_0 => F4_0 | F4_3, F4_1 => F4_1 | F4_3, F4_2 => F4_1 | F4_3, F4_3 => F4_3
  end.

#[local] Instance refa610_inst : Magma Fin4 := {| magma_op := refa610_op |}.

Lemma refa610_sat2716 : @Equation2716 Fin4 refa610_inst.
Proof. unfold Equation2716, magma_op, refa610_inst, refa610_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa610_not2503 : ~ @Equation2503 Fin4 refa610_inst.
Proof. unfold Equation2503. intro H. specialize (H F4_2 F4_0). unfold magma_op, refa610_inst, refa610_op in H. discriminate H. Qed.

(** ---- refa611 (Fin4) ---- *)

Definition refa611_op (x y : Fin4) : Fin4 :=
  match x, y with
  | F4_0, F4_0 => F4_2 | F4_0, F4_1 => F4_1 | F4_0, F4_2 => F4_1 | F4_0, F4_3 => F4_1
  | F4_1, F4_0 => F4_3 | F4_1, F4_1 => F4_1 | F4_1, F4_2 => F4_0 | F4_1, F4_3 => F4_2
  | F4_2, F4_0 => F4_1 | F4_2, F4_1 => F4_1 | F4_2, F4_2 => F4_3 | F4_2, F4_3 => F4_1
  | F4_3, F4_0 => F4_1 | F4_3, F4_1 => F4_1 | F4_3, F4_2 => F4_1 | F4_3, F4_3 => F4_0
  end.

#[local] Instance refa611_inst : Magma Fin4 := {| magma_op := refa611_op |}.

Lemma refa611_sat1975 : @Equation1975 Fin4 refa611_inst.
Proof. unfold Equation1975, magma_op, refa611_inst, refa611_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa611_not151 : ~ @Equation151 Fin4 refa611_inst.
Proof. unfold Equation151. intro H. specialize (H F4_0). unfold magma_op, refa611_inst, refa611_op in H. discriminate H. Qed.

Lemma refa611_not1426 : ~ @Equation1426 Fin4 refa611_inst.
Proof. unfold Equation1426. intro H. specialize (H F4_0). unfold magma_op, refa611_inst, refa611_op in H. discriminate H. Qed.

Lemma refa611_not3862 : ~ @Equation3862 Fin4 refa611_inst.
Proof. unfold Equation3862. intro H. specialize (H F4_0). unfold magma_op, refa611_inst, refa611_op in H. discriminate H. Qed.

Lemma refa611_not4065 : ~ @Equation4065 Fin4 refa611_inst.
Proof. unfold Equation4065. intro H. specialize (H F4_0). unfold magma_op, refa611_inst, refa611_op in H. discriminate H. Qed.

Lemma refa611_not4606 : ~ @Equation4606 Fin4 refa611_inst.
Proof. unfold Equation4606. intro H. specialize (H F4_0 F4_2). unfold magma_op, refa611_inst, refa611_op in H. discriminate H. Qed.

(** ---- refa612 (Fin4) ---- *)

Definition refa612_op (x y : Fin4) : Fin4 :=
  match x, y with
  | F4_0, F4_0 => F4_3 | F4_0, F4_1 => F4_3 | F4_0, F4_2 => F4_2 | F4_0, F4_3 => F4_3
  | F4_1, F4_0 => F4_3 | F4_1, F4_1 => F4_3 | F4_1, F4_2 => F4_2 | F4_1, F4_3 => F4_3
  | F4_2, F4_0 => F4_1 | F4_2, F4_1 => F4_3 | F4_2, F4_2 => F4_2 | F4_2, F4_3 => F4_3
  | F4_3, F4_0 => F4_3 | F4_3, F4_1 => F4_3 | F4_3, F4_2 => F4_2 | F4_3, F4_3 => F4_3
  end.

#[local] Instance refa612_inst : Magma Fin4 := {| magma_op := refa612_op |}.

Lemma refa612_sat318 : @Equation318 Fin4 refa612_inst.
Proof. unfold Equation318, magma_op, refa612_inst, refa612_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa612_sat4569 : @Equation4569 Fin4 refa612_inst.
Proof. unfold Equation4569, magma_op, refa612_inst, refa612_op. intros x y z w. destruct x, y, z, w; reflexivity. Qed.

Lemma refa612_not4396 : ~ @Equation4396 Fin4 refa612_inst.
Proof. unfold Equation4396. intro H. specialize (H F4_2 F4_0). unfold magma_op, refa612_inst, refa612_op in H. discriminate H. Qed.

Lemma refa612_not4406 : ~ @Equation4406 Fin4 refa612_inst.
Proof. unfold Equation4406. intro H. specialize (H F4_2 F4_0). unfold magma_op, refa612_inst, refa612_op in H. discriminate H. Qed.

Lemma refa612_not4435 : ~ @Equation4435 Fin4 refa612_inst.
Proof. unfold Equation4435. intro H. specialize (H F4_0 F4_2). unfold magma_op, refa612_inst, refa612_op in H. discriminate H. Qed.

Lemma refa612_not4445 : ~ @Equation4445 Fin4 refa612_inst.
Proof. unfold Equation4445. intro H. specialize (H F4_0 F4_2). unfold magma_op, refa612_inst, refa612_op in H. discriminate H. Qed.

Lemma refa612_not4470 : ~ @Equation4470 Fin4 refa612_inst.
Proof. unfold Equation4470. intro H. specialize (H F4_2 F4_0). unfold magma_op, refa612_inst, refa612_op in H. discriminate H. Qed.

Lemma refa612_not4480 : ~ @Equation4480 Fin4 refa612_inst.
Proof. unfold Equation4480. intro H. specialize (H F4_2 F4_0). unfold magma_op, refa612_inst, refa612_op in H. discriminate H. Qed.

Lemma refa612_not4599 : ~ @Equation4599 Fin4 refa612_inst.
Proof. unfold Equation4599. intro H. specialize (H F4_2 F4_0). unfold magma_op, refa612_inst, refa612_op in H. discriminate H. Qed.

Lemma refa612_not4622 : ~ @Equation4622 Fin4 refa612_inst.
Proof. unfold Equation4622. intro H. specialize (H F4_0 F4_0 F4_2). unfold magma_op, refa612_inst, refa612_op in H. discriminate H. Qed.

Lemma refa612_not4631 : ~ @Equation4631 Fin4 refa612_inst.
Proof. unfold Equation4631. intro H. specialize (H F4_0 F4_0 F4_2). unfold magma_op, refa612_inst, refa612_op in H. discriminate H. Qed.

(** ---- refa613 (Fin4) ---- *)

Definition refa613_op (x y : Fin4) : Fin4 :=
  match x, y with
  | F4_0, F4_0 => F4_1 | F4_0, F4_1 => F4_0 | F4_0, F4_2 => F4_0 | F4_0, F4_3 => F4_3
  | F4_1, F4_0 => F4_1 | F4_1, F4_1 => F4_1 | F4_1, F4_2 => F4_1 | F4_1, F4_3 => F4_1
  | F4_2, F4_0 => F4_2 | F4_2, F4_1 => F4_2 | F4_2, F4_2 => F4_1 | F4_2, F4_3 => F4_1
  | F4_3, F4_0 => F4_2 | F4_3, F4_1 => F4_3 | F4_3, F4_2 => F4_0 | F4_3, F4_3 => F4_1
  end.

#[local] Instance refa613_inst : Magma Fin4 := {| magma_op := refa613_op |}.

Lemma refa613_sat1060 : @Equation1060 Fin4 refa613_inst.
Proof. unfold Equation1060, magma_op, refa613_inst, refa613_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa613_not1242 : ~ @Equation1242 Fin4 refa613_inst.
Proof. unfold Equation1242. intro H. specialize (H F4_3 F4_0). unfold magma_op, refa613_inst, refa613_op in H. discriminate H. Qed.

(** ---- refa614 (Fin4) ---- *)

Definition refa614_op (x y : Fin4) : Fin4 :=
  match x, y with
  | F4_0, F4_0 => F4_3 | F4_0, F4_1 => F4_0 | F4_0, F4_2 => F4_3 | F4_0, F4_3 => F4_1
  | F4_1, F4_0 => F4_3 | F4_1, F4_1 => F4_1 | F4_1, F4_2 => F4_0 | F4_1, F4_3 => F4_3
  | F4_2, F4_0 => F4_2 | F4_2, F4_1 => F4_0 | F4_2, F4_2 => F4_1 | F4_2, F4_3 => F4_0
  | F4_3, F4_0 => F4_0 | F4_3, F4_1 => F4_1 | F4_3, F4_2 => F4_2 | F4_3, F4_3 => F4_3
  end.

#[local] Instance refa614_inst : Magma Fin4 := {| magma_op := refa614_op |}.

Lemma refa614_sat3112 : @Equation3112 Fin4 refa614_inst.
Proof. unfold Equation3112, magma_op, refa614_inst, refa614_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa614_not1629 : ~ @Equation1629 Fin4 refa614_inst.
Proof. unfold Equation1629. intro H. specialize (H F4_2). unfold magma_op, refa614_inst, refa614_op in H. discriminate H. Qed.

Lemma refa614_not2441 : ~ @Equation2441 Fin4 refa614_inst.
Proof. unfold Equation2441. intro H. specialize (H F4_2). unfold magma_op, refa614_inst, refa614_op in H. discriminate H. Qed.

Lemma refa614_not2644 : ~ @Equation2644 Fin4 refa614_inst.
Proof. unfold Equation2644. intro H. specialize (H F4_2). unfold magma_op, refa614_inst, refa614_op in H. discriminate H. Qed.

Lemma refa614_not3068 : ~ @Equation3068 Fin4 refa614_inst.
Proof. unfold Equation3068. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa614_inst, refa614_op in H. discriminate H. Qed.

Lemma refa614_not3152 : ~ @Equation3152 Fin4 refa614_inst.
Proof. unfold Equation3152. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa614_inst, refa614_op in H. discriminate H. Qed.

Lemma refa614_not3253 : ~ @Equation3253 Fin4 refa614_inst.
Proof. unfold Equation3253. intro H. specialize (H F4_0). unfold magma_op, refa614_inst, refa614_op in H. discriminate H. Qed.

Lemma refa614_not3862 : ~ @Equation3862 Fin4 refa614_inst.
Proof. unfold Equation3862. intro H. specialize (H F4_2). unfold magma_op, refa614_inst, refa614_op in H. discriminate H. Qed.

Lemma refa614_not4320 : ~ @Equation4320 Fin4 refa614_inst.
Proof. unfold Equation4320. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa614_inst, refa614_op in H. discriminate H. Qed.

(** ---- refa615 (Fin4) ---- *)

Definition refa615_op (x y : Fin4) : Fin4 :=
  match x, y with
  | F4_0, F4_0 => F4_3 | F4_0, F4_1 => F4_1 | F4_0, F4_2 => F4_3 | F4_0, F4_3 => F4_1
  | F4_1, F4_0 => F4_3 | F4_1, F4_1 => F4_3 | F4_1, F4_2 => F4_1 | F4_1, F4_3 => F4_3
  | F4_2, F4_0 => F4_0 | F4_2, F4_1 => F4_0 | F4_2, F4_2 => F4_3 | F4_2, F4_3 => F4_0
  | F4_3, F4_0 => F4_3 | F4_3, F4_1 => F4_3 | F4_3, F4_2 => F4_1 | F4_3, F4_3 => F4_3
  end.

#[local] Instance refa615_inst : Magma Fin4 := {| magma_op := refa615_op |}.

Lemma refa615_sat3910 : @Equation3910 Fin4 refa615_inst.
Proof. unfold Equation3910, magma_op, refa615_inst, refa615_op. intros x y z w. destruct x, y, z, w; reflexivity. Qed.

Lemma refa615_not4065 : ~ @Equation4065 Fin4 refa615_inst.
Proof. unfold Equation4065. intro H. specialize (H F4_2). unfold magma_op, refa615_inst, refa615_op in H. discriminate H. Qed.

(** ---- refa616 (Fin4) ---- *)

Definition refa616_op (x y : Fin4) : Fin4 :=
  match x, y with
  | F4_0, F4_0 => F4_0 | F4_0, F4_1 => F4_0 | F4_0, F4_2 => F4_0 | F4_0, F4_3 => F4_1
  | F4_1, F4_0 => F4_1 | F4_1, F4_1 => F4_1 | F4_1, F4_2 => F4_0 | F4_1, F4_3 => F4_1
  | F4_2, F4_0 => F4_2 | F4_2, F4_1 => F4_2 | F4_2, F4_2 => F4_2 | F4_2, F4_3 => F4_0
  | F4_3, F4_0 => F4_2 | F4_3, F4_1 => F4_3 | F4_3, F4_2 => F4_1 | F4_3, F4_3 => F4_3
  end.

#[local] Instance refa616_inst : Magma Fin4 := {| magma_op := refa616_op |}.

Lemma refa616_sat48 : @Equation48 Fin4 refa616_inst.
Proof. unfold Equation48, magma_op, refa616_inst, refa616_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa616_not616 : ~ @Equation616 Fin4 refa616_inst.
Proof. unfold Equation616. intro H. specialize (H F4_3 F4_0). unfold magma_op, refa616_inst, refa616_op in H. discriminate H. Qed.

Lemma refa616_not617 : ~ @Equation617 Fin4 refa616_inst.
Proof. unfold Equation617. intro H. specialize (H F4_3 F4_2). unfold magma_op, refa616_inst, refa616_op in H. discriminate H. Qed.

Lemma refa616_not825 : ~ @Equation825 Fin4 refa616_inst.
Proof. unfold Equation825. intro H. specialize (H F4_3 F4_0). unfold magma_op, refa616_inst, refa616_op in H. discriminate H. Qed.

Lemma refa616_not826 : ~ @Equation826 Fin4 refa616_inst.
Proof. unfold Equation826. intro H. specialize (H F4_3 F4_0). unfold magma_op, refa616_inst, refa616_op in H. discriminate H. Qed.

Lemma refa616_not1026 : ~ @Equation1026 Fin4 refa616_inst.
Proof. unfold Equation1026. intro H. specialize (H F4_3 F4_0). unfold magma_op, refa616_inst, refa616_op in H. discriminate H. Qed.

Lemma refa616_not1029 : ~ @Equation1029 Fin4 refa616_inst.
Proof. unfold Equation1029. intro H. specialize (H F4_3 F4_0). unfold magma_op, refa616_inst, refa616_op in H. discriminate H. Qed.

Lemma refa616_not1226 : ~ @Equation1226 Fin4 refa616_inst.
Proof. unfold Equation1226. intro H. specialize (H F4_3 F4_0). unfold magma_op, refa616_inst, refa616_op in H. discriminate H. Qed.

Lemma refa616_not1632 : ~ @Equation1632 Fin4 refa616_inst.
Proof. unfold Equation1632. intro H. specialize (H F4_3 F4_0). unfold magma_op, refa616_inst, refa616_op in H. discriminate H. Qed.

Lemma refa616_not2449 : ~ @Equation2449 Fin4 refa616_inst.
Proof. unfold Equation2449. intro H. specialize (H F4_3 F4_0). unfold magma_op, refa616_inst, refa616_op in H. discriminate H. Qed.

Lemma refa616_not3318 : ~ @Equation3318 Fin4 refa616_inst.
Proof. unfold Equation3318. intro H. specialize (H F4_0 F4_3). unfold magma_op, refa616_inst, refa616_op in H. discriminate H. Qed.

Lemma refa616_not3459 : ~ @Equation3459 Fin4 refa616_inst.
Proof. unfold Equation3459. intro H. specialize (H F4_3 F4_0). unfold magma_op, refa616_inst, refa616_op in H. discriminate H. Qed.

Lemma refa616_not3918 : ~ @Equation3918 Fin4 refa616_inst.
Proof. unfold Equation3918. intro H. specialize (H F4_3 F4_0). unfold magma_op, refa616_inst, refa616_op in H. discriminate H. Qed.

Lemma refa616_not4131 : ~ @Equation4131 Fin4 refa616_inst.
Proof. unfold Equation4131. intro H. specialize (H F4_2 F4_3). unfold magma_op, refa616_inst, refa616_op in H. discriminate H. Qed.

(** ---- refa617 (Fin4) ---- *)

Definition refa617_op (x y : Fin4) : Fin4 :=
  match x, y with
  | F4_0, F4_0 => F4_1 | F4_0, F4_1 => F4_2 | F4_0, F4_2 => F4_2 | F4_0, F4_3 => F4_1
  | F4_1, F4_0 => F4_3 | F4_1, F4_1 => F4_3 | F4_1, F4_2 => F4_2 | F4_1, F4_3 => F4_2
  | F4_2, F4_0 => F4_3 | F4_2, F4_1 => F4_0 | F4_2, F4_2 => F4_2 | F4_2, F4_3 => F4_1
  | F4_3, F4_0 => F4_2 | F4_3, F4_1 => F4_0 | F4_3, F4_2 => F4_2 | F4_3, F4_3 => F4_0
  end.

#[local] Instance refa617_inst : Magma Fin4 := {| magma_op := refa617_op |}.

Lemma refa617_sat2040 : @Equation2040 Fin4 refa617_inst.
Proof. unfold Equation2040, magma_op, refa617_inst, refa617_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa617_not3253 : ~ @Equation3253 Fin4 refa617_inst.
Proof. unfold Equation3253. intro H. specialize (H F4_0). unfold magma_op, refa617_inst, refa617_op in H. discriminate H. Qed.

Lemma refa617_not4284 : ~ @Equation4284 Fin4 refa617_inst.
Proof. unfold Equation4284. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa617_inst, refa617_op in H. discriminate H. Qed.

(** ---- refa618 (Fin4) ---- *)

Definition refa618_op (x y : Fin4) : Fin4 :=
  match x, y with
  | F4_0, F4_0 => F4_3 | F4_0, F4_1 => F4_3 | F4_0, F4_2 => F4_2 | F4_0, F4_3 => F4_3
  | F4_1, F4_0 => F4_3 | F4_1, F4_1 => F4_2 | F4_1, F4_2 => F4_2 | F4_1, F4_3 => F4_3
  | F4_2, F4_0 => F4_2 | F4_2, F4_1 => F4_2 | F4_2, F4_2 => F4_2 | F4_2, F4_3 => F4_2
  | F4_3, F4_0 => F4_3 | F4_3, F4_1 => F4_3 | F4_3, F4_2 => F4_3 | F4_3, F4_3 => F4_3
  end.

#[local] Instance refa618_inst : Magma Fin4 := {| magma_op := refa618_op |}.

Lemma refa618_sat3919 : @Equation3919 Fin4 refa618_inst.
Proof. unfold Equation3919, magma_op, refa618_inst, refa618_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa618_sat3926 : @Equation3926 Fin4 refa618_inst.
Proof. unfold Equation3926, magma_op, refa618_inst, refa618_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa618_not3309 : ~ @Equation3309 Fin4 refa618_inst.
Proof. unfold Equation3309. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa618_inst, refa618_op in H. discriminate H. Qed.

Lemma refa618_not3315 : ~ @Equation3315 Fin4 refa618_inst.
Proof. unfold Equation3315. intro H. specialize (H F4_1 F4_0). unfold magma_op, refa618_inst, refa618_op in H. discriminate H. Qed.

Lemma refa618_not3319 : ~ @Equation3319 Fin4 refa618_inst.
Proof. unfold Equation3319. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa618_inst, refa618_op in H. discriminate H. Qed.

Lemma refa618_not3521 : ~ @Equation3521 Fin4 refa618_inst.
Proof. unfold Equation3521. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa618_inst, refa618_op in H. discriminate H. Qed.

Lemma refa618_not3522 : ~ @Equation3522 Fin4 refa618_inst.
Proof. unfold Equation3522. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa618_inst, refa618_op in H. discriminate H. Qed.

Lemma refa618_not3927 : ~ @Equation3927 Fin4 refa618_inst.
Proof. unfold Equation3927. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa618_inst, refa618_op in H. discriminate H. Qed.

Lemma refa618_not3928 : ~ @Equation3928 Fin4 refa618_inst.
Proof. unfold Equation3928. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa618_inst, refa618_op in H. discriminate H. Qed.

Lemma refa618_not4314 : ~ @Equation4314 Fin4 refa618_inst.
Proof. unfold Equation4314. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa618_inst, refa618_op in H. discriminate H. Qed.

Lemma refa618_not4472 : ~ @Equation4472 Fin4 refa618_inst.
Proof. unfold Equation4472. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa618_inst, refa618_op in H. discriminate H. Qed.

Lemma refa618_not4473 : ~ @Equation4473 Fin4 refa618_inst.
Proof. unfold Equation4473. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa618_inst, refa618_op in H. discriminate H. Qed.

(** ---- refa619 (Fin4) ---- *)

Definition refa619_op (x y : Fin4) : Fin4 :=
  match x, y with
  | F4_0, F4_0 => F4_1 | F4_0, F4_1 => F4_2 | F4_0, F4_2 => F4_2 | F4_0, F4_3 => F4_1
  | F4_1, F4_0 => F4_3 | F4_1, F4_1 => F4_3 | F4_1, F4_2 => F4_3 | F4_1, F4_3 => F4_3
  | F4_2, F4_0 => F4_3 | F4_2, F4_1 => F4_3 | F4_2, F4_2 => F4_3 | F4_2, F4_3 => F4_3
  | F4_3, F4_0 => F4_3 | F4_3, F4_1 => F4_3 | F4_3, F4_2 => F4_3 | F4_3, F4_3 => F4_3
  end.

#[local] Instance refa619_inst : Magma Fin4 := {| magma_op := refa619_op |}.

Lemma refa619_sat3470 : @Equation3470 Fin4 refa619_inst.
Proof. unfold Equation3470, magma_op, refa619_inst, refa619_op. intros x y z w. destruct x, y, z, w; reflexivity. Qed.

Lemma refa619_not3253 : ~ @Equation3253 Fin4 refa619_inst.
Proof. unfold Equation3253. intro H. specialize (H F4_0). unfold magma_op, refa619_inst, refa619_op in H. discriminate H. Qed.

Lemma refa619_not3509 : ~ @Equation3509 Fin4 refa619_inst.
Proof. unfold Equation3509. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa619_inst, refa619_op in H. discriminate H. Qed.

Lemma refa619_not3519 : ~ @Equation3519 Fin4 refa619_inst.
Proof. unfold Equation3519. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa619_inst, refa619_op in H. discriminate H. Qed.

Lemma refa619_not3521 : ~ @Equation3521 Fin4 refa619_inst.
Proof. unfold Equation3521. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa619_inst, refa619_op in H. discriminate H. Qed.

Lemma refa619_not3522 : ~ @Equation3522 Fin4 refa619_inst.
Proof. unfold Equation3522. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa619_inst, refa619_op in H. discriminate H. Qed.

Lemma refa619_not3659 : ~ @Equation3659 Fin4 refa619_inst.
Proof. unfold Equation3659. intro H. specialize (H F4_0). unfold magma_op, refa619_inst, refa619_op in H. discriminate H. Qed.

Lemma refa619_not4380 : ~ @Equation4380 Fin4 refa619_inst.
Proof. unfold Equation4380. intro H. specialize (H F4_0). unfold magma_op, refa619_inst, refa619_op in H. discriminate H. Qed.

(** ---- refa62 (Fin3) ---- *)

Definition refa62_op (x y : Fin3) : Fin3 :=
  match x, y with
  | F3_0, F3_0 => F3_0 | F3_0, F3_1 => F3_1 | F3_0, F3_2 => F3_1
  | F3_1, F3_0 => F3_0 | F3_1, F3_1 => F3_1 | F3_1, F3_2 => F3_2
  | F3_2, F3_0 => F3_0 | F3_2, F3_1 => F3_2 | F3_2, F3_2 => F3_1
  end.

#[local] Instance refa62_inst : Magma Fin3 := {| magma_op := refa62_op |}.

Lemma refa62_sat639 : @Equation639 Fin3 refa62_inst.
Proof. unfold Equation639, magma_op, refa62_inst, refa62_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa62_sat1481 : @Equation1481 Fin3 refa62_inst.
Proof. unfold Equation1481, magma_op, refa62_inst, refa62_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa62_sat3271 : @Equation3271 Fin3 refa62_inst.
Proof. unfold Equation3271, magma_op, refa62_inst, refa62_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa62_sat3481 : @Equation3481 Fin3 refa62_inst.
Proof. unfold Equation3481, magma_op, refa62_inst, refa62_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa62_sat4480 : @Equation4480 Fin3 refa62_inst.
Proof. unfold Equation4480, magma_op, refa62_inst, refa62_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa62_not622 : ~ @Equation622 Fin3 refa62_inst.
Proof. unfold Equation622. intro H. specialize (H F3_2 F3_0). unfold magma_op, refa62_inst, refa62_op in H. discriminate H. Qed.

Lemma refa62_not3261 : ~ @Equation3261 Fin3 refa62_inst.
Proof. unfold Equation3261. intro H. specialize (H F3_2 F3_0). unfold magma_op, refa62_inst, refa62_op in H. discriminate H. Qed.

Lemma refa62_not3464 : ~ @Equation3464 Fin3 refa62_inst.
Proof. unfold Equation3464. intro H. specialize (H F3_2 F3_0). unfold magma_op, refa62_inst, refa62_op in H. discriminate H. Qed.

Lemma refa62_not3820 : ~ @Equation3820 Fin3 refa62_inst.
Proof. unfold Equation3820. intro H. specialize (H F3_1 F3_2 F3_0). unfold magma_op, refa62_inst, refa62_op in H. discriminate H. Qed.

Lemma refa62_not3887 : ~ @Equation3887 Fin3 refa62_inst.
Proof. unfold Equation3887. intro H. specialize (H F3_2 F3_0). unfold magma_op, refa62_inst, refa62_op in H. discriminate H. Qed.

Lemma refa62_not4090 : ~ @Equation4090 Fin3 refa62_inst.
Proof. unfold Equation4090. intro H. specialize (H F3_2 F3_0). unfold magma_op, refa62_inst, refa62_op in H. discriminate H. Qed.

Lemma refa62_not4320 : ~ @Equation4320 Fin3 refa62_inst.
Proof. unfold Equation4320. intro H. specialize (H F3_2 F3_0). unfold magma_op, refa62_inst, refa62_op in H. discriminate H. Qed.

Lemma refa62_not4435 : ~ @Equation4435 Fin3 refa62_inst.
Proof. unfold Equation4435. intro H. specialize (H F3_2 F3_0). unfold magma_op, refa62_inst, refa62_op in H. discriminate H. Qed.

Lemma refa62_not4590 : ~ @Equation4590 Fin3 refa62_inst.
Proof. unfold Equation4590. intro H. specialize (H F3_2 F3_0). unfold magma_op, refa62_inst, refa62_op in H. discriminate H. Qed.

(** ---- refa620 (Fin4) ---- *)

Definition refa620_op (x y : Fin4) : Fin4 :=
  match x, y with
  | F4_0, F4_0 => F4_3 | F4_0, F4_1 => F4_2 | F4_0, F4_2 => F4_3 | F4_0, F4_3 => F4_3
  | F4_1, F4_0 => F4_2 | F4_1, F4_1 => F4_2 | F4_1, F4_2 => F4_2 | F4_1, F4_3 => F4_2
  | F4_2, F4_0 => F4_2 | F4_2, F4_1 => F4_2 | F4_2, F4_2 => F4_2 | F4_2, F4_3 => F4_2
  | F4_3, F4_0 => F4_3 | F4_3, F4_1 => F4_3 | F4_3, F4_2 => F4_3 | F4_3, F4_3 => F4_3
  end.

#[local] Instance refa620_inst : Magma Fin4 := {| magma_op := refa620_op |}.

Lemma refa620_sat3876 : @Equation3876 Fin4 refa620_inst.
Proof. unfold Equation3876, magma_op, refa620_inst, refa620_op. intros x y z w. destruct x, y, z, w; reflexivity. Qed.

Lemma refa620_not3665 : ~ @Equation3665 Fin4 refa620_inst.
Proof. unfold Equation3665. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa620_inst, refa620_op in H. discriminate H. Qed.

Lemma refa620_not3667 : ~ @Equation3667 Fin4 refa620_inst.
Proof. unfold Equation3667. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa620_inst, refa620_op in H. discriminate H. Qed.

Lemma refa620_not4070 : ~ @Equation4070 Fin4 refa620_inst.
Proof. unfold Equation4070. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa620_inst, refa620_op in H. discriminate H. Qed.

Lemma refa620_not4071 : ~ @Equation4071 Fin4 refa620_inst.
Proof. unfold Equation4071. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa620_inst, refa620_op in H. discriminate H. Qed.

Lemma refa620_not4073 : ~ @Equation4073 Fin4 refa620_inst.
Proof. unfold Equation4073. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa620_inst, refa620_op in H. discriminate H. Qed.

Lemma refa620_not4598 : ~ @Equation4598 Fin4 refa620_inst.
Proof. unfold Equation4598. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa620_inst, refa620_op in H. discriminate H. Qed.

(** ---- refa621 (Fin4) ---- *)

Definition refa621_op (x y : Fin4) : Fin4 :=
  match x, y with
  | F4_0, F4_0 => F4_2 | F4_0, F4_1 => F4_2 | F4_0, F4_2 => F4_0 | F4_0, F4_3 => F4_1
  | F4_1, F4_0 => F4_3 | F4_1, F4_1 => F4_0 | F4_1, F4_2 => F4_1 | F4_1, F4_3 => F4_0
  | F4_2, F4_0 => F4_2 | F4_2, F4_1 => F4_2 | F4_2, F4_2 => F4_2 | F4_2, F4_3 => F4_2
  | F4_3, F4_0 => F4_1 | F4_3, F4_1 => F4_2 | F4_3, F4_2 => F4_3 | F4_3, F4_3 => F4_2
  end.

#[local] Instance refa621_inst : Magma Fin4 := {| magma_op := refa621_op |}.

Lemma refa621_sat1052 : @Equation1052 Fin4 refa621_inst.
Proof. unfold Equation1052, magma_op, refa621_inst, refa621_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa621_not835 : ~ @Equation835 Fin4 refa621_inst.
Proof. unfold Equation835. intro H. specialize (H F4_0 F4_3). unfold magma_op, refa621_inst, refa621_op in H. discriminate H. Qed.

(** ---- refa622 (Fin4) ---- *)

Definition refa622_op (x y : Fin4) : Fin4 :=
  match x, y with
  | F4_0, F4_0 => F4_0 | F4_0, F4_1 => F4_0 | F4_0, F4_2 => F4_1 | F4_0, F4_3 => F4_0
  | F4_1, F4_0 => F4_1 | F4_1, F4_1 => F4_1 | F4_1, F4_2 => F4_1 | F4_1, F4_3 => F4_1
  | F4_2, F4_0 => F4_2 | F4_2, F4_1 => F4_2 | F4_2, F4_2 => F4_2 | F4_2, F4_3 => F4_0
  | F4_3, F4_0 => F4_1 | F4_3, F4_1 => F4_3 | F4_3, F4_2 => F4_3 | F4_3, F4_3 => F4_3
  end.

#[local] Instance refa622_inst : Magma Fin4 := {| magma_op := refa622_op |}.

Lemma refa622_sat1237 : @Equation1237 Fin4 refa622_inst.
Proof. unfold Equation1237, magma_op, refa622_inst, refa622_op. intros x y z w. destruct x, y, z, w; reflexivity. Qed.

Lemma refa622_not3316 : ~ @Equation3316 Fin4 refa622_inst.
Proof. unfold Equation3316. intro H. specialize (H F4_2 F4_3). unfold magma_op, refa622_inst, refa622_op in H. discriminate H. Qed.

Lemma refa622_not3721 : ~ @Equation3721 Fin4 refa622_inst.
Proof. unfold Equation3721. intro H. specialize (H F4_2 F4_3). unfold magma_op, refa622_inst, refa622_op in H. discriminate H. Qed.

Lemma refa622_not3927 : ~ @Equation3927 Fin4 refa622_inst.
Proof. unfold Equation3927. intro H. specialize (H F4_2 F4_3). unfold magma_op, refa622_inst, refa622_op in H. discriminate H. Qed.

Lemma refa622_not4120 : ~ @Equation4120 Fin4 refa622_inst.
Proof. unfold Equation4120. intro H. specialize (H F4_2 F4_3). unfold magma_op, refa622_inst, refa622_op in H. discriminate H. Qed.

Lemma refa622_not4127 : ~ @Equation4127 Fin4 refa622_inst.
Proof. unfold Equation4127. intro H. specialize (H F4_2 F4_3). unfold magma_op, refa622_inst, refa622_op in H. discriminate H. Qed.

Lemma refa622_not4472 : ~ @Equation4472 Fin4 refa622_inst.
Proof. unfold Equation4472. intro H. specialize (H F4_2 F4_3). unfold magma_op, refa622_inst, refa622_op in H. discriminate H. Qed.

Lemma refa622_not4598 : ~ @Equation4598 Fin4 refa622_inst.
Proof. unfold Equation4598. intro H. specialize (H F4_2 F4_3). unfold magma_op, refa622_inst, refa622_op in H. discriminate H. Qed.

(** ---- refa623 (Fin4) ---- *)

Definition refa623_op (x y : Fin4) : Fin4 :=
  match x, y with
  | F4_0, F4_0 => F4_2 | F4_0, F4_1 => F4_2 | F4_0, F4_2 => F4_0 | F4_0, F4_3 => F4_1
  | F4_1, F4_0 => F4_3 | F4_1, F4_1 => F4_3 | F4_1, F4_2 => F4_3 | F4_1, F4_3 => F4_2
  | F4_2, F4_0 => F4_2 | F4_2, F4_1 => F4_2 | F4_2, F4_2 => F4_2 | F4_2, F4_3 => F4_3
  | F4_3, F4_0 => F4_2 | F4_3, F4_1 => F4_1 | F4_3, F4_2 => F4_3 | F4_3, F4_3 => F4_2
  end.

#[local] Instance refa623_inst : Magma Fin4 := {| magma_op := refa623_op |}.

Lemma refa623_sat4071 : @Equation4071 Fin4 refa623_inst.
Proof. unfold Equation4071, magma_op, refa623_inst, refa623_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa623_not4068 : ~ @Equation4068 Fin4 refa623_inst.
Proof. unfold Equation4068. intro H. specialize (H F4_1 F4_0). unfold magma_op, refa623_inst, refa623_op in H. discriminate H. Qed.

Lemma refa623_not4073 : ~ @Equation4073 Fin4 refa623_inst.
Proof. unfold Equation4073. intro H. specialize (H F4_1 F4_0). unfold magma_op, refa623_inst, refa623_op in H. discriminate H. Qed.

Lemma refa623_not4270 : ~ @Equation4270 Fin4 refa623_inst.
Proof. unfold Equation4270. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa623_inst, refa623_op in H. discriminate H. Qed.

Lemma refa623_not4598 : ~ @Equation4598 Fin4 refa623_inst.
Proof. unfold Equation4598. intro H. specialize (H F4_1 F4_0). unfold magma_op, refa623_inst, refa623_op in H. discriminate H. Qed.

(** ---- refa624 (Fin4) ---- *)

Definition refa624_op (x y : Fin4) : Fin4 :=
  match x, y with
  | F4_0, F4_0 => F4_2 | F4_0, F4_1 => F4_2 | F4_0, F4_2 => F4_1 | F4_0, F4_3 => F4_1
  | F4_1, F4_0 => F4_3 | F4_1, F4_1 => F4_0 | F4_1, F4_2 => F4_3 | F4_1, F4_3 => F4_0
  | F4_2, F4_0 => F4_3 | F4_2, F4_1 => F4_0 | F4_2, F4_2 => F4_3 | F4_2, F4_3 => F4_0
  | F4_3, F4_0 => F4_2 | F4_3, F4_1 => F4_2 | F4_3, F4_2 => F4_1 | F4_3, F4_3 => F4_1
  end.

#[local] Instance refa624_inst : Magma Fin4 := {| magma_op := refa624_op |}.

Lemma refa624_sat1461 : @Equation1461 Fin4 refa624_inst.
Proof. unfold Equation1461, magma_op, refa624_inst, refa624_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa624_not1434 : ~ @Equation1434 Fin4 refa624_inst.
Proof. unfold Equation1434. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa624_inst, refa624_op in H. discriminate H. Qed.

Lemma refa624_not1454 : ~ @Equation1454 Fin4 refa624_inst.
Proof. unfold Equation1454. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa624_inst, refa624_op in H. discriminate H. Qed.

Lemma refa624_not4284 : ~ @Equation4284 Fin4 refa624_inst.
Proof. unfold Equation4284. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa624_inst, refa624_op in H. discriminate H. Qed.

(** ---- refa625 (Fin4) ---- *)

Definition refa625_op (x y : Fin4) : Fin4 :=
  match x, y with
  | F4_0, F4_0 => F4_3 | F4_0, F4_1 => F4_1 | F4_0, F4_2 => F4_0 | F4_0, F4_3 => F4_1
  | F4_1, F4_0 => F4_3 | F4_1, F4_1 => F4_2 | F4_1, F4_2 => F4_1 | F4_1, F4_3 => F4_0
  | F4_2, F4_0 => F4_2 | F4_2, F4_1 => F4_2 | F4_2, F4_2 => F4_2 | F4_2, F4_3 => F4_2
  | F4_3, F4_0 => F4_2 | F4_3, F4_1 => F4_2 | F4_3, F4_2 => F4_3 | F4_3, F4_3 => F4_2
  end.

#[local] Instance refa625_inst : Magma Fin4 := {| magma_op := refa625_op |}.

Lemma refa625_sat847 : @Equation847 Fin4 refa625_inst.
Proof. unfold Equation847, magma_op, refa625_inst, refa625_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa625_sat1263 : @Equation1263 Fin4 refa625_inst.
Proof. unfold Equation1263, magma_op, refa625_inst, refa625_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa625_not1020 : ~ @Equation1020 Fin4 refa625_inst.
Proof. unfold Equation1020. intro H. specialize (H F4_0). unfold magma_op, refa625_inst, refa625_op in H. discriminate H. Qed.

Lemma refa625_not1239 : ~ @Equation1239 Fin4 refa625_inst.
Proof. unfold Equation1239. intro H. specialize (H F4_3 F4_0). unfold magma_op, refa625_inst, refa625_op in H. discriminate H. Qed.

Lemma refa625_not3253 : ~ @Equation3253 Fin4 refa625_inst.
Proof. unfold Equation3253. intro H. specialize (H F4_0). unfold magma_op, refa625_inst, refa625_op in H. discriminate H. Qed.

(** ---- refa626 (Fin4) ---- *)

Definition refa626_op (x y : Fin4) : Fin4 :=
  match x, y with
  | F4_0, F4_0 => F4_3 | F4_0, F4_1 => F4_2 | F4_0, F4_2 => F4_0 | F4_0, F4_3 => F4_1
  | F4_1, F4_0 => F4_2 | F4_1, F4_1 => F4_1 | F4_1, F4_2 => F4_1 | F4_1, F4_3 => F4_2
  | F4_2, F4_0 => F4_2 | F4_2, F4_1 => F4_2 | F4_2, F4_2 => F4_2 | F4_2, F4_3 => F4_2
  | F4_3, F4_0 => F4_2 | F4_3, F4_1 => F4_0 | F4_3, F4_2 => F4_3 | F4_3, F4_3 => F4_1
  end.

#[local] Instance refa626_inst : Magma Fin4 := {| magma_op := refa626_op |}.

Lemma refa626_sat1240 : @Equation1240 Fin4 refa626_inst.
Proof. unfold Equation1240, magma_op, refa626_inst, refa626_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa626_not1020 : ~ @Equation1020 Fin4 refa626_inst.
Proof. unfold Equation1020. intro H. specialize (H F4_3). unfold magma_op, refa626_inst, refa626_op in H. discriminate H. Qed.

(** ---- refa627 (Fin4) ---- *)

Definition refa627_op (x y : Fin4) : Fin4 :=
  match x, y with
  | F4_0, F4_0 => F4_1 | F4_0, F4_1 => F4_2 | F4_0, F4_2 => F4_0 | F4_0, F4_3 => F4_3
  | F4_1, F4_0 => F4_3 | F4_1, F4_1 => F4_0 | F4_1, F4_2 => F4_2 | F4_1, F4_3 => F4_1
  | F4_2, F4_0 => F4_2 | F4_2, F4_1 => F4_1 | F4_2, F4_2 => F4_3 | F4_2, F4_3 => F4_0
  | F4_3, F4_0 => F4_0 | F4_3, F4_1 => F4_3 | F4_3, F4_2 => F4_1 | F4_3, F4_3 => F4_2
  end.

#[local] Instance refa627_inst : Magma Fin4 := {| magma_op := refa627_op |}.

Lemma refa627_sat53 : @Equation53 Fin4 refa627_inst.
Proof. unfold Equation53, magma_op, refa627_inst, refa627_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa627_sat273 : @Equation273 Fin4 refa627_inst.
Proof. unfold Equation273, magma_op, refa627_inst, refa627_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa627_sat281 : @Equation281 Fin4 refa627_inst.
Proof. unfold Equation281, magma_op, refa627_inst, refa627_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa627_sat1117 : @Equation1117 Fin4 refa627_inst.
Proof. unfold Equation1117, magma_op, refa627_inst, refa627_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa627_sat1152 : @Equation1152 Fin4 refa627_inst.
Proof. unfold Equation1152, magma_op, refa627_inst, refa627_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa627_sat1155 : @Equation1155 Fin4 refa627_inst.
Proof. unfold Equation1155, magma_op, refa627_inst, refa627_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa627_sat2538 : @Equation2538 Fin4 refa627_inst.
Proof. unfold Equation2538, magma_op, refa627_inst, refa627_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa627_not99 : ~ @Equation99 Fin4 refa627_inst.
Proof. unfold Equation99. intro H. specialize (H F4_0). unfold magma_op, refa627_inst, refa627_op in H. discriminate H. Qed.

Lemma refa627_not203 : ~ @Equation203 Fin4 refa627_inst.
Proof. unfold Equation203. intro H. specialize (H F4_0). unfold magma_op, refa627_inst, refa627_op in H. discriminate H. Qed.

Lemma refa627_not411 : ~ @Equation411 Fin4 refa627_inst.
Proof. unfold Equation411. intro H. specialize (H F4_0). unfold magma_op, refa627_inst, refa627_op in H. discriminate H. Qed.

Lemma refa627_not614 : ~ @Equation614 Fin4 refa627_inst.
Proof. unfold Equation614. intro H. specialize (H F4_0). unfold magma_op, refa627_inst, refa627_op in H. discriminate H. Qed.

Lemma refa627_not817 : ~ @Equation817 Fin4 refa627_inst.
Proof. unfold Equation817. intro H. specialize (H F4_0). unfold magma_op, refa627_inst, refa627_op in H. discriminate H. Qed.

Lemma refa627_not1028 : ~ @Equation1028 Fin4 refa627_inst.
Proof. unfold Equation1028. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa627_inst, refa627_op in H. discriminate H. Qed.

Lemma refa627_not1045 : ~ @Equation1045 Fin4 refa627_inst.
Proof. unfold Equation1045. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa627_inst, refa627_op in H. discriminate H. Qed.

Lemma refa627_not1629 : ~ @Equation1629 Fin4 refa627_inst.
Proof. unfold Equation1629. intro H. specialize (H F4_0). unfold magma_op, refa627_inst, refa627_op in H. discriminate H. Qed.

Lemma refa627_not1832 : ~ @Equation1832 Fin4 refa627_inst.
Proof. unfold Equation1832. intro H. specialize (H F4_0). unfold magma_op, refa627_inst, refa627_op in H. discriminate H. Qed.

Lemma refa627_not2449 : ~ @Equation2449 Fin4 refa627_inst.
Proof. unfold Equation2449. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa627_inst, refa627_op in H. discriminate H. Qed.

Lemma refa627_not2466 : ~ @Equation2466 Fin4 refa627_inst.
Proof. unfold Equation2466. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa627_inst, refa627_op in H. discriminate H. Qed.

Lemma refa627_not2506 : ~ @Equation2506 Fin4 refa627_inst.
Proof. unfold Equation2506. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa627_inst, refa627_op in H. discriminate H. Qed.

Lemma refa627_not3050 : ~ @Equation3050 Fin4 refa627_inst.
Proof. unfold Equation3050. intro H. specialize (H F4_0). unfold magma_op, refa627_inst, refa627_op in H. discriminate H. Qed.

Lemma refa627_not3253 : ~ @Equation3253 Fin4 refa627_inst.
Proof. unfold Equation3253. intro H. specialize (H F4_0). unfold magma_op, refa627_inst, refa627_op in H. discriminate H. Qed.

Lemma refa627_not3456 : ~ @Equation3456 Fin4 refa627_inst.
Proof. unfold Equation3456. intro H. specialize (H F4_0). unfold magma_op, refa627_inst, refa627_op in H. discriminate H. Qed.

Lemma refa627_not3659 : ~ @Equation3659 Fin4 refa627_inst.
Proof. unfold Equation3659. intro H. specialize (H F4_0). unfold magma_op, refa627_inst, refa627_op in H. discriminate H. Qed.

Lemma refa627_not3862 : ~ @Equation3862 Fin4 refa627_inst.
Proof. unfold Equation3862. intro H. specialize (H F4_0). unfold magma_op, refa627_inst, refa627_op in H. discriminate H. Qed.

Lemma refa627_not4065 : ~ @Equation4065 Fin4 refa627_inst.
Proof. unfold Equation4065. intro H. specialize (H F4_0). unfold magma_op, refa627_inst, refa627_op in H. discriminate H. Qed.

Lemma refa627_not4270 : ~ @Equation4270 Fin4 refa627_inst.
Proof. unfold Equation4270. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa627_inst, refa627_op in H. discriminate H. Qed.

Lemma refa627_not4275 : ~ @Equation4275 Fin4 refa627_inst.
Proof. unfold Equation4275. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa627_inst, refa627_op in H. discriminate H. Qed.

Lemma refa627_not4380 : ~ @Equation4380 Fin4 refa627_inst.
Proof. unfold Equation4380. intro H. specialize (H F4_0). unfold magma_op, refa627_inst, refa627_op in H. discriminate H. Qed.

Lemma refa627_not4656 : ~ @Equation4656 Fin4 refa627_inst.
Proof. unfold Equation4656. intro H. specialize (H F4_0 F4_0 F4_1). unfold magma_op, refa627_inst, refa627_op in H. discriminate H. Qed.

(** ---- refa628 (Fin4) ---- *)

Definition refa628_op (x y : Fin4) : Fin4 :=
  match x, y with
  | F4_0, F4_0 => F4_0 | F4_0, F4_1 => F4_3 | F4_0, F4_2 => F4_0 | F4_0, F4_3 => F4_3
  | F4_1, F4_0 => F4_2 | F4_1, F4_1 => F4_2 | F4_1, F4_2 => F4_1 | F4_1, F4_3 => F4_1
  | F4_2, F4_0 => F4_2 | F4_2, F4_1 => F4_2 | F4_2, F4_2 => F4_1 | F4_2, F4_3 => F4_1
  | F4_3, F4_0 => F4_0 | F4_3, F4_1 => F4_3 | F4_3, F4_2 => F4_0 | F4_3, F4_3 => F4_3
  end.

#[local] Instance refa628_inst : Magma Fin4 := {| magma_op := refa628_op |}.

Lemma refa628_sat162 : @Equation162 Fin4 refa628_inst.
Proof. unfold Equation162, magma_op, refa628_inst, refa628_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa628_sat450 : @Equation450 Fin4 refa628_inst.
Proof. unfold Equation450, magma_op, refa628_inst, refa628_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa628_sat2056 : @Equation2056 Fin4 refa628_inst.
Proof. unfold Equation2056, magma_op, refa628_inst, refa628_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa628_not419 : ~ @Equation419 Fin4 refa628_inst.
Proof. unfold Equation419. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa628_inst, refa628_op in H. discriminate H. Qed.

Lemma refa628_not436 : ~ @Equation436 Fin4 refa628_inst.
Proof. unfold Equation436. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa628_inst, refa628_op in H. discriminate H. Qed.

Lemma refa628_not3261 : ~ @Equation3261 Fin4 refa628_inst.
Proof. unfold Equation3261. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa628_inst, refa628_op in H. discriminate H. Qed.

Lemma refa628_not3309 : ~ @Equation3309 Fin4 refa628_inst.
Proof. unfold Equation3309. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa628_inst, refa628_op in H. discriminate H. Qed.

Lemma refa628_not4284 : ~ @Equation4284 Fin4 refa628_inst.
Proof. unfold Equation4284. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa628_inst, refa628_op in H. discriminate H. Qed.

(** ---- refa629 (Fin4) ---- *)

Definition refa629_op (x y : Fin4) : Fin4 :=
  match x, y with
  | F4_0, F4_0 => F4_1 | F4_0, F4_1 => F4_2 | F4_0, F4_2 => F4_1 | F4_0, F4_3 => F4_1
  | F4_1, F4_0 => F4_3 | F4_1, F4_1 => F4_3 | F4_1, F4_2 => F4_3 | F4_1, F4_3 => F4_2
  | F4_2, F4_0 => F4_0 | F4_2, F4_1 => F4_1 | F4_2, F4_2 => F4_2 | F4_2, F4_3 => F4_3
  | F4_3, F4_0 => F4_2 | F4_3, F4_1 => F4_0 | F4_3, F4_2 => F4_0 | F4_3, F4_3 => F4_0
  end.

#[local] Instance refa629_inst : Magma Fin4 := {| magma_op := refa629_op |}.

Lemma refa629_sat2044 : @Equation2044 Fin4 refa629_inst.
Proof. unfold Equation2044, magma_op, refa629_inst, refa629_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa629_not2060 : ~ @Equation2060 Fin4 refa629_inst.
Proof. unfold Equation2060. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa629_inst, refa629_op in H. discriminate H. Qed.

Lemma refa629_not2847 : ~ @Equation2847 Fin4 refa629_inst.
Proof. unfold Equation2847. intro H. specialize (H F4_0). unfold magma_op, refa629_inst, refa629_op in H. discriminate H. Qed.

Lemma refa629_not3319 : ~ @Equation3319 Fin4 refa629_inst.
Proof. unfold Equation3319. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa629_inst, refa629_op in H. discriminate H. Qed.

Lemma refa629_not3459 : ~ @Equation3459 Fin4 refa629_inst.
Proof. unfold Equation3459. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa629_inst, refa629_op in H. discriminate H. Qed.

Lemma refa629_not3518 : ~ @Equation3518 Fin4 refa629_inst.
Proof. unfold Equation3518. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa629_inst, refa629_op in H. discriminate H. Qed.

Lemma refa629_not3522 : ~ @Equation3522 Fin4 refa629_inst.
Proof. unfold Equation3522. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa629_inst, refa629_op in H. discriminate H. Qed.

Lemma refa629_not4585 : ~ @Equation4585 Fin4 refa629_inst.
Proof. unfold Equation4585. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa629_inst, refa629_op in H. discriminate H. Qed.

(** ---- refa63 (Fin3) ---- *)

Definition refa63_op (x y : Fin3) : Fin3 :=
  match x, y with
  | F3_0, F3_0 => F3_0 | F3_0, F3_1 => F3_1 | F3_0, F3_2 => F3_1
  | F3_1, F3_0 => F3_0 | F3_1, F3_1 => F3_1 | F3_1, F3_2 => F3_2
  | F3_2, F3_0 => F3_1 | F3_2, F3_1 => F3_1 | F3_2, F3_2 => F3_0
  end.

#[local] Instance refa63_inst : Magma Fin3 := {| magma_op := refa63_op |}.

Lemma refa63_sat2259 : @Equation2259 Fin3 refa63_inst.
Proof. unfold Equation2259, magma_op, refa63_inst, refa63_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa63_sat2277 : @Equation2277 Fin3 refa63_inst.
Proof. unfold Equation2277, magma_op, refa63_inst, refa63_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa63_sat2281 : @Equation2281 Fin3 refa63_inst.
Proof. unfold Equation2281, magma_op, refa63_inst, refa63_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa63_sat2296 : @Equation2296 Fin3 refa63_inst.
Proof. unfold Equation2296, magma_op, refa63_inst, refa63_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa63_sat2314 : @Equation2314 Fin3 refa63_inst.
Proof. unfold Equation2314, magma_op, refa63_inst, refa63_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa63_sat2318 : @Equation2318 Fin3 refa63_inst.
Proof. unfold Equation2318, magma_op, refa63_inst, refa63_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa63_sat2368 : @Equation2368 Fin3 refa63_inst.
Proof. unfold Equation2368, magma_op, refa63_inst, refa63_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa63_sat2372 : @Equation2372 Fin3 refa63_inst.
Proof. unfold Equation2372, magma_op, refa63_inst, refa63_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa63_sat2443 : @Equation2443 Fin3 refa63_inst.
Proof. unfold Equation2443, magma_op, refa63_inst, refa63_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa63_sat2449 : @Equation2449 Fin3 refa63_inst.
Proof. unfold Equation2449, magma_op, refa63_inst, refa63_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa63_sat2459 : @Equation2459 Fin3 refa63_inst.
Proof. unfold Equation2459, magma_op, refa63_inst, refa63_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa63_sat2469 : @Equation2469 Fin3 refa63_inst.
Proof. unfold Equation2469, magma_op, refa63_inst, refa63_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa63_sat2493 : @Equation2493 Fin3 refa63_inst.
Proof. unfold Equation2493, magma_op, refa63_inst, refa63_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa63_sat3664 : @Equation3664 Fin3 refa63_inst.
Proof. unfold Equation3664, magma_op, refa63_inst, refa63_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa63_sat3684 : @Equation3684 Fin3 refa63_inst.
Proof. unfold Equation3684, magma_op, refa63_inst, refa63_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa63_sat3712 : @Equation3712 Fin3 refa63_inst.
Proof. unfold Equation3712, magma_op, refa63_inst, refa63_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa63_sat3749 : @Equation3749 Fin3 refa63_inst.
Proof. unfold Equation3749, magma_op, refa63_inst, refa63_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa63_sat4380 : @Equation4380 Fin3 refa63_inst.
Proof. unfold Equation4380, magma_op, refa63_inst, refa63_op. intros x. destruct x; reflexivity. Qed.

Lemma refa63_not47 : ~ @Equation47 Fin3 refa63_inst.
Proof. unfold Equation47. intro H. specialize (H F3_2). unfold magma_op, refa63_inst, refa63_op in H. discriminate H. Qed.

Lemma refa63_not99 : ~ @Equation99 Fin3 refa63_inst.
Proof. unfold Equation99. intro H. specialize (H F3_2). unfold magma_op, refa63_inst, refa63_op in H. discriminate H. Qed.

Lemma refa63_not151 : ~ @Equation151 Fin3 refa63_inst.
Proof. unfold Equation151. intro H. specialize (H F3_2). unfold magma_op, refa63_inst, refa63_op in H. discriminate H. Qed.

Lemma refa63_not231 : ~ @Equation231 Fin3 refa63_inst.
Proof. unfold Equation231. intro H. specialize (H F3_2 F3_0). unfold magma_op, refa63_inst, refa63_op in H. discriminate H. Qed.

Lemma refa63_not264 : ~ @Equation264 Fin3 refa63_inst.
Proof. unfold Equation264. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa63_inst, refa63_op in H. discriminate H. Qed.

Lemma refa63_not273 : ~ @Equation273 Fin3 refa63_inst.
Proof. unfold Equation273. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa63_inst, refa63_op in H. discriminate H. Qed.

Lemma refa63_not280 : ~ @Equation280 Fin3 refa63_inst.
Proof. unfold Equation280. intro H. specialize (H F3_2 F3_1). unfold magma_op, refa63_inst, refa63_op in H. discriminate H. Qed.

Lemma refa63_not283 : ~ @Equation283 Fin3 refa63_inst.
Proof. unfold Equation283. intro H. specialize (H F3_2 F3_0). unfold magma_op, refa63_inst, refa63_op in H. discriminate H. Qed.

Lemma refa63_not411 : ~ @Equation411 Fin3 refa63_inst.
Proof. unfold Equation411. intro H. specialize (H F3_2). unfold magma_op, refa63_inst, refa63_op in H. discriminate H. Qed.

Lemma refa63_not614 : ~ @Equation614 Fin3 refa63_inst.
Proof. unfold Equation614. intro H. specialize (H F3_2). unfold magma_op, refa63_inst, refa63_op in H. discriminate H. Qed.

Lemma refa63_not817 : ~ @Equation817 Fin3 refa63_inst.
Proof. unfold Equation817. intro H. specialize (H F3_2). unfold magma_op, refa63_inst, refa63_op in H. discriminate H. Qed.

Lemma refa63_not1020 : ~ @Equation1020 Fin3 refa63_inst.
Proof. unfold Equation1020. intro H. specialize (H F3_2). unfold magma_op, refa63_inst, refa63_op in H. discriminate H. Qed.

Lemma refa63_not1223 : ~ @Equation1223 Fin3 refa63_inst.
Proof. unfold Equation1223. intro H. specialize (H F3_2). unfold magma_op, refa63_inst, refa63_op in H. discriminate H. Qed.

Lemma refa63_not1426 : ~ @Equation1426 Fin3 refa63_inst.
Proof. unfold Equation1426. intro H. specialize (H F3_2). unfold magma_op, refa63_inst, refa63_op in H. discriminate H. Qed.

Lemma refa63_not1629 : ~ @Equation1629 Fin3 refa63_inst.
Proof. unfold Equation1629. intro H. specialize (H F3_2). unfold magma_op, refa63_inst, refa63_op in H. discriminate H. Qed.

Lemma refa63_not1832 : ~ @Equation1832 Fin3 refa63_inst.
Proof. unfold Equation1832. intro H. specialize (H F3_2). unfold magma_op, refa63_inst, refa63_op in H. discriminate H. Qed.

Lemma refa63_not2035 : ~ @Equation2035 Fin3 refa63_inst.
Proof. unfold Equation2035. intro H. specialize (H F3_2). unfold magma_op, refa63_inst, refa63_op in H. discriminate H. Qed.

Lemma refa63_not2244 : ~ @Equation2244 Fin3 refa63_inst.
Proof. unfold Equation2244. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa63_inst, refa63_op in H. discriminate H. Qed.

Lemma refa63_not2247 : ~ @Equation2247 Fin3 refa63_inst.
Proof. unfold Equation2247. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa63_inst, refa63_op in H. discriminate H. Qed.

Lemma refa63_not2254 : ~ @Equation2254 Fin3 refa63_inst.
Proof. unfold Equation2254. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa63_inst, refa63_op in H. discriminate H. Qed.

Lemma refa63_not2300 : ~ @Equation2300 Fin3 refa63_inst.
Proof. unfold Equation2300. intro H. specialize (H F3_2 F3_1). unfold magma_op, refa63_inst, refa63_op in H. discriminate H. Qed.

Lemma refa63_not2340 : ~ @Equation2340 Fin3 refa63_inst.
Proof. unfold Equation2340. intro H. specialize (H F3_2 F3_0). unfold magma_op, refa63_inst, refa63_op in H. discriminate H. Qed.

Lemma refa63_not2444 : ~ @Equation2444 Fin3 refa63_inst.
Proof. unfold Equation2444. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa63_inst, refa63_op in H. discriminate H. Qed.

Lemma refa63_not2456 : ~ @Equation2456 Fin3 refa63_inst.
Proof. unfold Equation2456. intro H. specialize (H F3_2 F3_0). unfold magma_op, refa63_inst, refa63_op in H. discriminate H. Qed.

Lemma refa63_not2457 : ~ @Equation2457 Fin3 refa63_inst.
Proof. unfold Equation2457. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa63_inst, refa63_op in H. discriminate H. Qed.

Lemma refa63_not2460 : ~ @Equation2460 Fin3 refa63_inst.
Proof. unfold Equation2460. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa63_inst, refa63_op in H. discriminate H. Qed.

Lemma refa63_not2466 : ~ @Equation2466 Fin3 refa63_inst.
Proof. unfold Equation2466. intro H. specialize (H F3_2 F3_1). unfold magma_op, refa63_inst, refa63_op in H. discriminate H. Qed.

Lemma refa63_not2467 : ~ @Equation2467 Fin3 refa63_inst.
Proof. unfold Equation2467. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa63_inst, refa63_op in H. discriminate H. Qed.

Lemma refa63_not2496 : ~ @Equation2496 Fin3 refa63_inst.
Proof. unfold Equation2496. intro H. specialize (H F3_2 F3_0). unfold magma_op, refa63_inst, refa63_op in H. discriminate H. Qed.

Lemma refa63_not2506 : ~ @Equation2506 Fin3 refa63_inst.
Proof. unfold Equation2506. intro H. specialize (H F3_2 F3_0). unfold magma_op, refa63_inst, refa63_op in H. discriminate H. Qed.

Lemma refa63_not2530 : ~ @Equation2530 Fin3 refa63_inst.
Proof. unfold Equation2530. intro H. specialize (H F3_2 F3_1). unfold magma_op, refa63_inst, refa63_op in H. discriminate H. Qed.

Lemma refa63_not2533 : ~ @Equation2533 Fin3 refa63_inst.
Proof. unfold Equation2533. intro H. specialize (H F3_2 F3_0). unfold magma_op, refa63_inst, refa63_op in H. discriminate H. Qed.

Lemma refa63_not2540 : ~ @Equation2540 Fin3 refa63_inst.
Proof. unfold Equation2540. intro H. specialize (H F3_2 F3_1). unfold magma_op, refa63_inst, refa63_op in H. discriminate H. Qed.

Lemma refa63_not2543 : ~ @Equation2543 Fin3 refa63_inst.
Proof. unfold Equation2543. intro H. specialize (H F3_2 F3_0). unfold magma_op, refa63_inst, refa63_op in H. discriminate H. Qed.

Lemma refa63_not2644 : ~ @Equation2644 Fin3 refa63_inst.
Proof. unfold Equation2644. intro H. specialize (H F3_2). unfold magma_op, refa63_inst, refa63_op in H. discriminate H. Qed.

Lemma refa63_not2847 : ~ @Equation2847 Fin3 refa63_inst.
Proof. unfold Equation2847. intro H. specialize (H F3_2). unfold magma_op, refa63_inst, refa63_op in H. discriminate H. Qed.

Lemma refa63_not3050 : ~ @Equation3050 Fin3 refa63_inst.
Proof. unfold Equation3050. intro H. specialize (H F3_2). unfold magma_op, refa63_inst, refa63_op in H. discriminate H. Qed.

Lemma refa63_not3253 : ~ @Equation3253 Fin3 refa63_inst.
Proof. unfold Equation3253. intro H. specialize (H F3_2). unfold magma_op, refa63_inst, refa63_op in H. discriminate H. Qed.

Lemma refa63_not3456 : ~ @Equation3456 Fin3 refa63_inst.
Proof. unfold Equation3456. intro H. specialize (H F3_2). unfold magma_op, refa63_inst, refa63_op in H. discriminate H. Qed.

Lemma refa63_not3661 : ~ @Equation3661 Fin3 refa63_inst.
Proof. unfold Equation3661. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa63_inst, refa63_op in H. discriminate H. Qed.

Lemma refa63_not3662 : ~ @Equation3662 Fin3 refa63_inst.
Proof. unfold Equation3662. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa63_inst, refa63_op in H. discriminate H. Qed.

Lemma refa63_not3665 : ~ @Equation3665 Fin3 refa63_inst.
Proof. unfold Equation3665. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa63_inst, refa63_op in H. discriminate H. Qed.

Lemma refa63_not3667 : ~ @Equation3667 Fin3 refa63_inst.
Proof. unfold Equation3667. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa63_inst, refa63_op in H. discriminate H. Qed.

Lemma refa63_not3668 : ~ @Equation3668 Fin3 refa63_inst.
Proof. unfold Equation3668. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa63_inst, refa63_op in H. discriminate H. Qed.

Lemma refa63_not3674 : ~ @Equation3674 Fin3 refa63_inst.
Proof. unfold Equation3674. intro H. specialize (H F3_2 F3_1). unfold magma_op, refa63_inst, refa63_op in H. discriminate H. Qed.

Lemma refa63_not3677 : ~ @Equation3677 Fin3 refa63_inst.
Proof. unfold Equation3677. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa63_inst, refa63_op in H. discriminate H. Qed.

Lemma refa63_not3687 : ~ @Equation3687 Fin3 refa63_inst.
Proof. unfold Equation3687. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa63_inst, refa63_op in H. discriminate H. Qed.

Lemma refa63_not3722 : ~ @Equation3722 Fin3 refa63_inst.
Proof. unfold Equation3722. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa63_inst, refa63_op in H. discriminate H. Qed.

Lemma refa63_not3724 : ~ @Equation3724 Fin3 refa63_inst.
Proof. unfold Equation3724. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa63_inst, refa63_op in H. discriminate H. Qed.

Lemma refa63_not3725 : ~ @Equation3725 Fin3 refa63_inst.
Proof. unfold Equation3725. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa63_inst, refa63_op in H. discriminate H. Qed.

Lemma refa63_not3752 : ~ @Equation3752 Fin3 refa63_inst.
Proof. unfold Equation3752. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa63_inst, refa63_op in H. discriminate H. Qed.

Lemma refa63_not3759 : ~ @Equation3759 Fin3 refa63_inst.
Proof. unfold Equation3759. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa63_inst, refa63_op in H. discriminate H. Qed.

Lemma refa63_not3862 : ~ @Equation3862 Fin3 refa63_inst.
Proof. unfold Equation3862. intro H. specialize (H F3_2). unfold magma_op, refa63_inst, refa63_op in H. discriminate H. Qed.

Lemma refa63_not4065 : ~ @Equation4065 Fin3 refa63_inst.
Proof. unfold Equation4065. intro H. specialize (H F3_2). unfold magma_op, refa63_inst, refa63_op in H. discriminate H. Qed.

Lemma refa63_not4268 : ~ @Equation4268 Fin3 refa63_inst.
Proof. unfold Equation4268. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa63_inst, refa63_op in H. discriminate H. Qed.

Lemma refa63_not4269 : ~ @Equation4269 Fin3 refa63_inst.
Proof. unfold Equation4269. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa63_inst, refa63_op in H. discriminate H. Qed.

Lemma refa63_not4270 : ~ @Equation4270 Fin3 refa63_inst.
Proof. unfold Equation4270. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa63_inst, refa63_op in H. discriminate H. Qed.

Lemma refa63_not4272 : ~ @Equation4272 Fin3 refa63_inst.
Proof. unfold Equation4272. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa63_inst, refa63_op in H. discriminate H. Qed.

Lemma refa63_not4273 : ~ @Equation4273 Fin3 refa63_inst.
Proof. unfold Equation4273. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa63_inst, refa63_op in H. discriminate H. Qed.

Lemma refa63_not4275 : ~ @Equation4275 Fin3 refa63_inst.
Proof. unfold Equation4275. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa63_inst, refa63_op in H. discriminate H. Qed.

Lemma refa63_not4283 : ~ @Equation4283 Fin3 refa63_inst.
Proof. unfold Equation4283. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa63_inst, refa63_op in H. discriminate H. Qed.

Lemma refa63_not4284 : ~ @Equation4284 Fin3 refa63_inst.
Proof. unfold Equation4284. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa63_inst, refa63_op in H. discriminate H. Qed.

Lemma refa63_not4291 : ~ @Equation4291 Fin3 refa63_inst.
Proof. unfold Equation4291. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa63_inst, refa63_op in H. discriminate H. Qed.

Lemma refa63_not4314 : ~ @Equation4314 Fin3 refa63_inst.
Proof. unfold Equation4314. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa63_inst, refa63_op in H. discriminate H. Qed.

Lemma refa63_not4320 : ~ @Equation4320 Fin3 refa63_inst.
Proof. unfold Equation4320. intro H. specialize (H F3_2 F3_0). unfold magma_op, refa63_inst, refa63_op in H. discriminate H. Qed.

Lemma refa63_not4383 : ~ @Equation4383 Fin3 refa63_inst.
Proof. unfold Equation4383. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa63_inst, refa63_op in H. discriminate H. Qed.

Lemma refa63_not4396 : ~ @Equation4396 Fin3 refa63_inst.
Proof. unfold Equation4396. intro H. specialize (H F3_2 F3_0). unfold magma_op, refa63_inst, refa63_op in H. discriminate H. Qed.

Lemma refa63_not4398 : ~ @Equation4398 Fin3 refa63_inst.
Proof. unfold Equation4398. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa63_inst, refa63_op in H. discriminate H. Qed.

Lemma refa63_not4399 : ~ @Equation4399 Fin3 refa63_inst.
Proof. unfold Equation4399. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa63_inst, refa63_op in H. discriminate H. Qed.

Lemma refa63_not4406 : ~ @Equation4406 Fin3 refa63_inst.
Proof. unfold Equation4406. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa63_inst, refa63_op in H. discriminate H. Qed.

Lemma refa63_not4433 : ~ @Equation4433 Fin3 refa63_inst.
Proof. unfold Equation4433. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa63_inst, refa63_op in H. discriminate H. Qed.

Lemma refa63_not4435 : ~ @Equation4435 Fin3 refa63_inst.
Proof. unfold Equation4435. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa63_inst, refa63_op in H. discriminate H. Qed.

Lemma refa63_not4445 : ~ @Equation4445 Fin3 refa63_inst.
Proof. unfold Equation4445. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa63_inst, refa63_op in H. discriminate H. Qed.

Lemma refa63_not4470 : ~ @Equation4470 Fin3 refa63_inst.
Proof. unfold Equation4470. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa63_inst, refa63_op in H. discriminate H. Qed.

Lemma refa63_not4473 : ~ @Equation4473 Fin3 refa63_inst.
Proof. unfold Equation4473. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa63_inst, refa63_op in H. discriminate H. Qed.

Lemma refa63_not4583 : ~ @Equation4583 Fin3 refa63_inst.
Proof. unfold Equation4583. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa63_inst, refa63_op in H. discriminate H. Qed.

Lemma refa63_not4584 : ~ @Equation4584 Fin3 refa63_inst.
Proof. unfold Equation4584. intro H. specialize (H F3_2 F3_0). unfold magma_op, refa63_inst, refa63_op in H. discriminate H. Qed.

Lemma refa63_not4587 : ~ @Equation4587 Fin3 refa63_inst.
Proof. unfold Equation4587. intro H. specialize (H F3_2 F3_0). unfold magma_op, refa63_inst, refa63_op in H. discriminate H. Qed.

Lemma refa63_not4590 : ~ @Equation4590 Fin3 refa63_inst.
Proof. unfold Equation4590. intro H. specialize (H F3_2 F3_1). unfold magma_op, refa63_inst, refa63_op in H. discriminate H. Qed.

Lemma refa63_not4598 : ~ @Equation4598 Fin3 refa63_inst.
Proof. unfold Equation4598. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa63_inst, refa63_op in H. discriminate H. Qed.

Lemma refa63_not4599 : ~ @Equation4599 Fin3 refa63_inst.
Proof. unfold Equation4599. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa63_inst, refa63_op in H. discriminate H. Qed.

Lemma refa63_not4606 : ~ @Equation4606 Fin3 refa63_inst.
Proof. unfold Equation4606. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa63_inst, refa63_op in H. discriminate H. Qed.

Lemma refa63_not4629 : ~ @Equation4629 Fin3 refa63_inst.
Proof. unfold Equation4629. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa63_inst, refa63_op in H. discriminate H. Qed.

(** ---- refa630 (Fin4) ---- *)

Definition refa630_op (x y : Fin4) : Fin4 :=
  match x, y with
  | F4_0, F4_0 => F4_0 | F4_0, F4_1 => F4_2 | F4_0, F4_2 => F4_1 | F4_0, F4_3 => F4_3
  | F4_1, F4_0 => F4_2 | F4_1, F4_1 => F4_3 | F4_1, F4_2 => F4_1 | F4_1, F4_3 => F4_0
  | F4_2, F4_0 => F4_3 | F4_2, F4_1 => F4_0 | F4_2, F4_2 => F4_1 | F4_2, F4_3 => F4_2
  | F4_3, F4_0 => F4_1 | F4_3, F4_1 => F4_3 | F4_3, F4_2 => F4_0 | F4_3, F4_3 => F4_2
  end.

#[local] Instance refa630_inst : Magma Fin4 := {| magma_op := refa630_op |}.

Lemma refa630_sat420 : @Equation420 Fin4 refa630_inst.
Proof. unfold Equation420, magma_op, refa630_inst, refa630_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa630_sat501 : @Equation501 Fin4 refa630_inst.
Proof. unfold Equation501, magma_op, refa630_inst, refa630_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa630_sat1435 : @Equation1435 Fin4 refa630_inst.
Proof. unfold Equation1435, magma_op, refa630_inst, refa630_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa630_not151 : ~ @Equation151 Fin4 refa630_inst.
Proof. unfold Equation151. intro H. specialize (H F4_1). unfold magma_op, refa630_inst, refa630_op in H. discriminate H. Qed.

Lemma refa630_not203 : ~ @Equation203 Fin4 refa630_inst.
Proof. unfold Equation203. intro H. specialize (H F4_1). unfold magma_op, refa630_inst, refa630_op in H. discriminate H. Qed.

Lemma refa630_not1427 : ~ @Equation1427 Fin4 refa630_inst.
Proof. unfold Equation1427. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa630_inst, refa630_op in H. discriminate H. Qed.

Lemma refa630_not1428 : ~ @Equation1428 Fin4 refa630_inst.
Proof. unfold Equation1428. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa630_inst, refa630_op in H. discriminate H. Qed.

Lemma refa630_not1429 : ~ @Equation1429 Fin4 refa630_inst.
Proof. unfold Equation1429. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa630_inst, refa630_op in H. discriminate H. Qed.

Lemma refa630_not1444 : ~ @Equation1444 Fin4 refa630_inst.
Proof. unfold Equation1444. intro H. specialize (H F4_1 F4_0). unfold magma_op, refa630_inst, refa630_op in H. discriminate H. Qed.

Lemma refa630_not1445 : ~ @Equation1445 Fin4 refa630_inst.
Proof. unfold Equation1445. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa630_inst, refa630_op in H. discriminate H. Qed.

Lemma refa630_not1629 : ~ @Equation1629 Fin4 refa630_inst.
Proof. unfold Equation1629. intro H. specialize (H F4_1). unfold magma_op, refa630_inst, refa630_op in H. discriminate H. Qed.

Lemma refa630_not1832 : ~ @Equation1832 Fin4 refa630_inst.
Proof. unfold Equation1832. intro H. specialize (H F4_1). unfold magma_op, refa630_inst, refa630_op in H. discriminate H. Qed.

Lemma refa630_not3253 : ~ @Equation3253 Fin4 refa630_inst.
Proof. unfold Equation3253. intro H. specialize (H F4_1). unfold magma_op, refa630_inst, refa630_op in H. discriminate H. Qed.

Lemma refa630_not3456 : ~ @Equation3456 Fin4 refa630_inst.
Proof. unfold Equation3456. intro H. specialize (H F4_1). unfold magma_op, refa630_inst, refa630_op in H. discriminate H. Qed.

Lemma refa630_not4314 : ~ @Equation4314 Fin4 refa630_inst.
Proof. unfold Equation4314. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa630_inst, refa630_op in H. discriminate H. Qed.

(** ---- refa631 (Fin4) ---- *)

Definition refa631_op (x y : Fin4) : Fin4 :=
  match x, y with
  | F4_0, F4_0 => F4_0 | F4_0, F4_1 => F4_2 | F4_0, F4_2 => F4_1 | F4_0, F4_3 => F4_3
  | F4_1, F4_0 => F4_1 | F4_1, F4_1 => F4_0 | F4_1, F4_2 => F4_2 | F4_1, F4_3 => F4_3
  | F4_2, F4_0 => F4_2 | F4_2, F4_1 => F4_3 | F4_2, F4_2 => F4_0 | F4_2, F4_3 => F4_1
  | F4_3, F4_0 => F4_3 | F4_3, F4_1 => F4_1 | F4_3, F4_2 => F4_2 | F4_3, F4_3 => F4_0
  end.

#[local] Instance refa631_inst : Magma Fin4 := {| magma_op := refa631_op |}.

Lemma refa631_sat1929 : @Equation1929 Fin4 refa631_inst.
Proof. unfold Equation1929, magma_op, refa631_inst, refa631_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa631_not2441 : ~ @Equation2441 Fin4 refa631_inst.
Proof. unfold Equation2441. intro H. specialize (H F4_1). unfold magma_op, refa631_inst, refa631_op in H. discriminate H. Qed.

(** ---- refa632 (Fin4) ---- *)

Definition refa632_op (x y : Fin4) : Fin4 :=
  match x, y with
  | F4_0, F4_0 => F4_1 | F4_0, F4_1 => F4_0 | F4_0, F4_2 => F4_3 | F4_0, F4_3 => F4_1
  | F4_1, F4_0 => F4_1 | F4_1, F4_1 => F4_1 | F4_1, F4_2 => F4_1 | F4_1, F4_3 => F4_1
  | F4_2, F4_0 => F4_1 | F4_2, F4_1 => F4_2 | F4_2, F4_2 => F4_1 | F4_2, F4_3 => F4_2
  | F4_3, F4_0 => F4_1 | F4_3, F4_1 => F4_3 | F4_3, F4_2 => F4_3 | F4_3, F4_3 => F4_1
  end.

#[local] Instance refa632_inst : Magma Fin4 := {| magma_op := refa632_op |}.

Lemma refa632_sat434 : @Equation434 Fin4 refa632_inst.
Proof. unfold Equation434, magma_op, refa632_inst, refa632_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa632_not427 : ~ @Equation427 Fin4 refa632_inst.
Proof. unfold Equation427. intro H. specialize (H F4_0 F4_2). unfold magma_op, refa632_inst, refa632_op in H. discriminate H. Qed.

Lemma refa632_not439 : ~ @Equation439 Fin4 refa632_inst.
Proof. unfold Equation439. intro H. specialize (H F4_2 F4_0). unfold magma_op, refa632_inst, refa632_op in H. discriminate H. Qed.

Lemma refa632_not854 : ~ @Equation854 Fin4 refa632_inst.
Proof. unfold Equation854. intro H. specialize (H F4_0 F4_2 F4_3). unfold magma_op, refa632_inst, refa632_op in H. discriminate H. Qed.

Lemma refa632_not3318 : ~ @Equation3318 Fin4 refa632_inst.
Proof. unfold Equation3318. intro H. specialize (H F4_2 F4_0). unfold magma_op, refa632_inst, refa632_op in H. discriminate H. Qed.

(** ---- refa633 (Fin4) ---- *)

Definition refa633_op (x y : Fin4) : Fin4 :=
  match x, y with
  | F4_0, F4_0 => F4_2 | F4_0, F4_1 => F4_3 | F4_0, F4_2 => F4_1 | F4_0, F4_3 => F4_1
  | F4_1, F4_0 => F4_3 | F4_1, F4_1 => F4_3 | F4_1, F4_2 => F4_0 | F4_1, F4_3 => F4_1
  | F4_2, F4_0 => F4_3 | F4_2, F4_1 => F4_1 | F4_2, F4_2 => F4_0 | F4_2, F4_3 => F4_1
  | F4_3, F4_0 => F4_2 | F4_3, F4_1 => F4_3 | F4_3, F4_2 => F4_1 | F4_3, F4_3 => F4_1
  end.

#[local] Instance refa633_inst : Magma Fin4 := {| magma_op := refa633_op |}.

Lemma refa633_sat1921 : @Equation1921 Fin4 refa633_inst.
Proof. unfold Equation1921, magma_op, refa633_inst, refa633_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa633_not411 : ~ @Equation411 Fin4 refa633_inst.
Proof. unfold Equation411. intro H. specialize (H F4_0). unfold magma_op, refa633_inst, refa633_op in H. discriminate H. Qed.

Lemma refa633_not1020 : ~ @Equation1020 Fin4 refa633_inst.
Proof. unfold Equation1020. intro H. specialize (H F4_0). unfold magma_op, refa633_inst, refa633_op in H. discriminate H. Qed.

Lemma refa633_not1840 : ~ @Equation1840 Fin4 refa633_inst.
Proof. unfold Equation1840. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa633_inst, refa633_op in H. discriminate H. Qed.

Lemma refa633_not1850 : ~ @Equation1850 Fin4 refa633_inst.
Proof. unfold Equation1850. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa633_inst, refa633_op in H. discriminate H. Qed.

Lemma refa633_not1894 : ~ @Equation1894 Fin4 refa633_inst.
Proof. unfold Equation1894. intro H. specialize (H F4_0 F4_3). unfold magma_op, refa633_inst, refa633_op in H. discriminate H. Qed.

(** ---- refa634 (Fin4) ---- *)

Definition refa634_op (x y : Fin4) : Fin4 :=
  match x, y with
  | F4_0, F4_0 => F4_1 | F4_0, F4_1 => F4_0 | F4_0, F4_2 => F4_0 | F4_0, F4_3 => F4_1
  | F4_1, F4_0 => F4_1 | F4_1, F4_1 => F4_1 | F4_1, F4_2 => F4_1 | F4_1, F4_3 => F4_1
  | F4_2, F4_0 => F4_2 | F4_2, F4_1 => F4_2 | F4_2, F4_2 => F4_3 | F4_2, F4_3 => F4_1
  | F4_3, F4_0 => F4_0 | F4_3, F4_1 => F4_3 | F4_3, F4_2 => F4_3 | F4_3, F4_3 => F4_0
  end.

#[local] Instance refa634_inst : Magma Fin4 := {| magma_op := refa634_op |}.

Lemma refa634_sat836 : @Equation836 Fin4 refa634_inst.
Proof. unfold Equation836, magma_op, refa634_inst, refa634_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa634_not99 : ~ @Equation99 Fin4 refa634_inst.
Proof. unfold Equation99. intro H. specialize (H F4_2). unfold magma_op, refa634_inst, refa634_op in H. discriminate H. Qed.

Lemma refa634_not832 : ~ @Equation832 Fin4 refa634_inst.
Proof. unfold Equation832. intro H. specialize (H F4_0 F4_3). unfold magma_op, refa634_inst, refa634_op in H. discriminate H. Qed.

Lemma refa634_not833 : ~ @Equation833 Fin4 refa634_inst.
Proof. unfold Equation833. intro H. specialize (H F4_0 F4_3). unfold magma_op, refa634_inst, refa634_op in H. discriminate H. Qed.

Lemma refa634_not835 : ~ @Equation835 Fin4 refa634_inst.
Proof. unfold Equation835. intro H. specialize (H F4_0 F4_2). unfold magma_op, refa634_inst, refa634_op in H. discriminate H. Qed.

Lemma refa634_not846 : ~ @Equation846 Fin4 refa634_inst.
Proof. unfold Equation846. intro H. specialize (H F4_0 F4_2). unfold magma_op, refa634_inst, refa634_op in H. discriminate H. Qed.

Lemma refa634_not1223 : ~ @Equation1223 Fin4 refa634_inst.
Proof. unfold Equation1223. intro H. specialize (H F4_2). unfold magma_op, refa634_inst, refa634_op in H. discriminate H. Qed.

(** ---- refa635 (Fin4) ---- *)

Definition refa635_op (x y : Fin4) : Fin4 :=
  match x, y with
  | F4_0, F4_0 => F4_0 | F4_0, F4_1 => F4_2 | F4_0, F4_2 => F4_1 | F4_0, F4_3 => F4_3
  | F4_1, F4_0 => F4_0 | F4_1, F4_1 => F4_1 | F4_1, F4_2 => F4_2 | F4_1, F4_3 => F4_3
  | F4_2, F4_0 => F4_0 | F4_2, F4_1 => F4_1 | F4_2, F4_2 => F4_2 | F4_2, F4_3 => F4_3
  | F4_3, F4_0 => F4_1 | F4_3, F4_1 => F4_0 | F4_3, F4_2 => F4_2 | F4_3, F4_3 => F4_3
  end.

#[local] Instance refa635_inst : Magma Fin4 := {| magma_op := refa635_op |}.

Lemma refa635_sat2115 : @Equation2115 Fin4 refa635_inst.
Proof. unfold Equation2115, magma_op, refa635_inst, refa635_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa635_not2124 : ~ @Equation2124 Fin4 refa635_inst.
Proof. unfold Equation2124. intro H. specialize (H F4_1 F4_3). unfold magma_op, refa635_inst, refa635_op in H. discriminate H. Qed.

(** ---- refa636 (Fin4) ---- *)

Definition refa636_op (x y : Fin4) : Fin4 :=
  match x, y with
  | F4_0, F4_0 => F4_3 | F4_0, F4_1 => F4_3 | F4_0, F4_2 => F4_1 | F4_0, F4_3 => F4_3
  | F4_1, F4_0 => F4_3 | F4_1, F4_1 => F4_3 | F4_1, F4_2 => F4_1 | F4_1, F4_3 => F4_3
  | F4_2, F4_0 => F4_3 | F4_2, F4_1 => F4_3 | F4_2, F4_2 => F4_0 | F4_2, F4_3 => F4_3
  | F4_3, F4_0 => F4_0 | F4_3, F4_1 => F4_1 | F4_3, F4_2 => F4_2 | F4_3, F4_3 => F4_3
  end.

#[local] Instance refa636_inst : Magma Fin4 := {| magma_op := refa636_op |}.

Lemma refa636_sat2588 : @Equation2588 Fin4 refa636_inst.
Proof. unfold Equation2588, magma_op, refa636_inst, refa636_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa636_not4065 : ~ @Equation4065 Fin4 refa636_inst.
Proof. unfold Equation4065. intro H. specialize (H F4_2). unfold magma_op, refa636_inst, refa636_op in H. discriminate H. Qed.

(** ---- refa637 (Fin4) ---- *)

Definition refa637_op (x y : Fin4) : Fin4 :=
  match x, y with
  | F4_0, F4_0 => F4_3 | F4_0, F4_1 => F4_2 | F4_0, F4_2 => F4_3 | F4_0, F4_3 => F4_1
  | F4_1, F4_0 => F4_3 | F4_1, F4_1 => F4_1 | F4_1, F4_2 => F4_1 | F4_1, F4_3 => F4_3
  | F4_2, F4_0 => F4_1 | F4_2, F4_1 => F4_1 | F4_2, F4_2 => F4_2 | F4_2, F4_3 => F4_2
  | F4_3, F4_0 => F4_2 | F4_3, F4_1 => F4_3 | F4_3, F4_2 => F4_2 | F4_3, F4_3 => F4_3
  end.

#[local] Instance refa637_inst : Magma Fin4 := {| magma_op := refa637_op |}.

Lemma refa637_sat3961 : @Equation3961 Fin4 refa637_inst.
Proof. unfold Equation3961, magma_op, refa637_inst, refa637_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa637_not3253 : ~ @Equation3253 Fin4 refa637_inst.
Proof. unfold Equation3253. intro H. specialize (H F4_0). unfold magma_op, refa637_inst, refa637_op in H. discriminate H. Qed.

Lemma refa637_not3509 : ~ @Equation3509 Fin4 refa637_inst.
Proof. unfold Equation3509. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa637_inst, refa637_op in H. discriminate H. Qed.

Lemma refa637_not3512 : ~ @Equation3512 Fin4 refa637_inst.
Proof. unfold Equation3512. intro H. specialize (H F4_1 F4_0). unfold magma_op, refa637_inst, refa637_op in H. discriminate H. Qed.

Lemma refa637_not3518 : ~ @Equation3518 Fin4 refa637_inst.
Proof. unfold Equation3518. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa637_inst, refa637_op in H. discriminate H. Qed.

Lemma refa637_not3519 : ~ @Equation3519 Fin4 refa637_inst.
Proof. unfold Equation3519. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa637_inst, refa637_op in H. discriminate H. Qed.

Lemma refa637_not3521 : ~ @Equation3521 Fin4 refa637_inst.
Proof. unfold Equation3521. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa637_inst, refa637_op in H. discriminate H. Qed.

Lemma refa637_not3522 : ~ @Equation3522 Fin4 refa637_inst.
Proof. unfold Equation3522. intro H. specialize (H F4_1 F4_0). unfold magma_op, refa637_inst, refa637_op in H. discriminate H. Qed.

Lemma refa637_not3545 : ~ @Equation3545 Fin4 refa637_inst.
Proof. unfold Equation3545. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa637_inst, refa637_op in H. discriminate H. Qed.

Lemma refa637_not3546 : ~ @Equation3546 Fin4 refa637_inst.
Proof. unfold Equation3546. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa637_inst, refa637_op in H. discriminate H. Qed.

Lemma refa637_not3548 : ~ @Equation3548 Fin4 refa637_inst.
Proof. unfold Equation3548. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa637_inst, refa637_op in H. discriminate H. Qed.

Lemma refa637_not3549 : ~ @Equation3549 Fin4 refa637_inst.
Proof. unfold Equation3549. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa637_inst, refa637_op in H. discriminate H. Qed.

Lemma refa637_not3555 : ~ @Equation3555 Fin4 refa637_inst.
Proof. unfold Equation3555. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa637_inst, refa637_op in H. discriminate H. Qed.

Lemma refa637_not3558 : ~ @Equation3558 Fin4 refa637_inst.
Proof. unfold Equation3558. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa637_inst, refa637_op in H. discriminate H. Qed.

Lemma refa637_not3712 : ~ @Equation3712 Fin4 refa637_inst.
Proof. unfold Equation3712. intro H. specialize (H F4_0 F4_3). unfold magma_op, refa637_inst, refa637_op in H. discriminate H. Qed.

Lemma refa637_not3714 : ~ @Equation3714 Fin4 refa637_inst.
Proof. unfold Equation3714. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa637_inst, refa637_op in H. discriminate H. Qed.

Lemma refa637_not3721 : ~ @Equation3721 Fin4 refa637_inst.
Proof. unfold Equation3721. intro H. specialize (H F4_0 F4_3). unfold magma_op, refa637_inst, refa637_op in H. discriminate H. Qed.

Lemma refa637_not3724 : ~ @Equation3724 Fin4 refa637_inst.
Proof. unfold Equation3724. intro H. specialize (H F4_1 F4_0). unfold magma_op, refa637_inst, refa637_op in H. discriminate H. Qed.

Lemma refa637_not3725 : ~ @Equation3725 Fin4 refa637_inst.
Proof. unfold Equation3725. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa637_inst, refa637_op in H. discriminate H. Qed.

Lemma refa637_not3748 : ~ @Equation3748 Fin4 refa637_inst.
Proof. unfold Equation3748. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa637_inst, refa637_op in H. discriminate H. Qed.

Lemma refa637_not3749 : ~ @Equation3749 Fin4 refa637_inst.
Proof. unfold Equation3749. intro H. specialize (H F4_1 F4_0). unfold magma_op, refa637_inst, refa637_op in H. discriminate H. Qed.

Lemma refa637_not3752 : ~ @Equation3752 Fin4 refa637_inst.
Proof. unfold Equation3752. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa637_inst, refa637_op in H. discriminate H. Qed.

Lemma refa637_not3759 : ~ @Equation3759 Fin4 refa637_inst.
Proof. unfold Equation3759. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa637_inst, refa637_op in H. discriminate H. Qed.

Lemma refa637_not3761 : ~ @Equation3761 Fin4 refa637_inst.
Proof. unfold Equation3761. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa637_inst, refa637_op in H. discriminate H. Qed.

Lemma refa637_not3915 : ~ @Equation3915 Fin4 refa637_inst.
Proof. unfold Equation3915. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa637_inst, refa637_op in H. discriminate H. Qed.

Lemma refa637_not3918 : ~ @Equation3918 Fin4 refa637_inst.
Proof. unfold Equation3918. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa637_inst, refa637_op in H. discriminate H. Qed.

Lemma refa637_not3925 : ~ @Equation3925 Fin4 refa637_inst.
Proof. unfold Equation3925. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa637_inst, refa637_op in H. discriminate H. Qed.

Lemma refa637_not3927 : ~ @Equation3927 Fin4 refa637_inst.
Proof. unfold Equation3927. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa637_inst, refa637_op in H. discriminate H. Qed.

Lemma refa637_not3928 : ~ @Equation3928 Fin4 refa637_inst.
Proof. unfold Equation3928. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa637_inst, refa637_op in H. discriminate H. Qed.

Lemma refa637_not3951 : ~ @Equation3951 Fin4 refa637_inst.
Proof. unfold Equation3951. intro H. specialize (H F4_0 F4_2). unfold magma_op, refa637_inst, refa637_op in H. discriminate H. Qed.

Lemma refa637_not3952 : ~ @Equation3952 Fin4 refa637_inst.
Proof. unfold Equation3952. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa637_inst, refa637_op in H. discriminate H. Qed.

Lemma refa637_not3954 : ~ @Equation3954 Fin4 refa637_inst.
Proof. unfold Equation3954. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa637_inst, refa637_op in H. discriminate H. Qed.

Lemma refa637_not3955 : ~ @Equation3955 Fin4 refa637_inst.
Proof. unfold Equation3955. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa637_inst, refa637_op in H. discriminate H. Qed.

Lemma refa637_not3962 : ~ @Equation3962 Fin4 refa637_inst.
Proof. unfold Equation3962. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa637_inst, refa637_op in H. discriminate H. Qed.

Lemma refa637_not3964 : ~ @Equation3964 Fin4 refa637_inst.
Proof. unfold Equation3964. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa637_inst, refa637_op in H. discriminate H. Qed.

Lemma refa637_not4065 : ~ @Equation4065 Fin4 refa637_inst.
Proof. unfold Equation4065. intro H. specialize (H F4_0). unfold magma_op, refa637_inst, refa637_op in H. discriminate H. Qed.

Lemma refa637_not4283 : ~ @Equation4283 Fin4 refa637_inst.
Proof. unfold Equation4283. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa637_inst, refa637_op in H. discriminate H. Qed.

Lemma refa637_not4284 : ~ @Equation4284 Fin4 refa637_inst.
Proof. unfold Equation4284. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa637_inst, refa637_op in H. discriminate H. Qed.

Lemma refa637_not4290 : ~ @Equation4290 Fin4 refa637_inst.
Proof. unfold Equation4290. intro H. specialize (H F4_0 F4_2). unfold magma_op, refa637_inst, refa637_op in H. discriminate H. Qed.

Lemma refa637_not4291 : ~ @Equation4291 Fin4 refa637_inst.
Proof. unfold Equation4291. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa637_inst, refa637_op in H. discriminate H. Qed.

Lemma refa637_not4314 : ~ @Equation4314 Fin4 refa637_inst.
Proof. unfold Equation4314. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa637_inst, refa637_op in H. discriminate H. Qed.

Lemma refa637_not4320 : ~ @Equation4320 Fin4 refa637_inst.
Proof. unfold Equation4320. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa637_inst, refa637_op in H. discriminate H. Qed.

Lemma refa637_not4343 : ~ @Equation4343 Fin4 refa637_inst.
Proof. unfold Equation4343. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa637_inst, refa637_op in H. discriminate H. Qed.

Lemma refa637_not4380 : ~ @Equation4380 Fin4 refa637_inst.
Proof. unfold Equation4380. intro H. specialize (H F4_0). unfold magma_op, refa637_inst, refa637_op in H. discriminate H. Qed.

Lemma refa637_not4598 : ~ @Equation4598 Fin4 refa637_inst.
Proof. unfold Equation4598. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa637_inst, refa637_op in H. discriminate H. Qed.

Lemma refa637_not4599 : ~ @Equation4599 Fin4 refa637_inst.
Proof. unfold Equation4599. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa637_inst, refa637_op in H. discriminate H. Qed.

Lemma refa637_not4605 : ~ @Equation4605 Fin4 refa637_inst.
Proof. unfold Equation4605. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa637_inst, refa637_op in H. discriminate H. Qed.

Lemma refa637_not4606 : ~ @Equation4606 Fin4 refa637_inst.
Proof. unfold Equation4606. intro H. specialize (H F4_0 F4_2). unfold magma_op, refa637_inst, refa637_op in H. discriminate H. Qed.

Lemma refa637_not4608 : ~ @Equation4608 Fin4 refa637_inst.
Proof. unfold Equation4608. intro H. specialize (H F4_0 F4_2). unfold magma_op, refa637_inst, refa637_op in H. discriminate H. Qed.

Lemma refa637_not4629 : ~ @Equation4629 Fin4 refa637_inst.
Proof. unfold Equation4629. intro H. specialize (H F4_1 F4_0). unfold magma_op, refa637_inst, refa637_op in H. discriminate H. Qed.

Lemma refa637_not4635 : ~ @Equation4635 Fin4 refa637_inst.
Proof. unfold Equation4635. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa637_inst, refa637_op in H. discriminate H. Qed.

Lemma refa637_not4636 : ~ @Equation4636 Fin4 refa637_inst.
Proof. unfold Equation4636. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa637_inst, refa637_op in H. discriminate H. Qed.

Lemma refa637_not4658 : ~ @Equation4658 Fin4 refa637_inst.
Proof. unfold Equation4658. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa637_inst, refa637_op in H. discriminate H. Qed.

(** ---- refa638 (Fin4) ---- *)

Definition refa638_op (x y : Fin4) : Fin4 :=
  match x, y with
  | F4_0, F4_0 => F4_2 | F4_0, F4_1 => F4_2 | F4_0, F4_2 => F4_0 | F4_0, F4_3 => F4_1
  | F4_1, F4_0 => F4_3 | F4_1, F4_1 => F4_3 | F4_1, F4_2 => F4_0 | F4_1, F4_3 => F4_1
  | F4_2, F4_0 => F4_3 | F4_2, F4_1 => F4_2 | F4_2, F4_2 => F4_1 | F4_2, F4_3 => F4_1
  | F4_3, F4_0 => F4_3 | F4_3, F4_1 => F4_2 | F4_3, F4_2 => F4_0 | F4_3, F4_3 => F4_0
  end.

#[local] Instance refa638_inst : Magma Fin4 := {| magma_op := refa638_op |}.

Lemma refa638_sat1958 : @Equation1958 Fin4 refa638_inst.
Proof. unfold Equation1958, magma_op, refa638_inst, refa638_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa638_sat2093 : @Equation2093 Fin4 refa638_inst.
Proof. unfold Equation2093, magma_op, refa638_inst, refa638_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa638_not1025 : ~ @Equation1025 Fin4 refa638_inst.
Proof. unfold Equation1025. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa638_inst, refa638_op in H. discriminate H. Qed.

Lemma refa638_not1035 : ~ @Equation1035 Fin4 refa638_inst.
Proof. unfold Equation1035. intro H. specialize (H F4_0 F4_2). unfold magma_op, refa638_inst, refa638_op in H. discriminate H. Qed.

Lemma refa638_not1045 : ~ @Equation1045 Fin4 refa638_inst.
Proof. unfold Equation1045. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa638_inst, refa638_op in H. discriminate H. Qed.

Lemma refa638_not1629 : ~ @Equation1629 Fin4 refa638_inst.
Proof. unfold Equation1629. intro H. specialize (H F4_0). unfold magma_op, refa638_inst, refa638_op in H. discriminate H. Qed.

Lemma refa638_not1894 : ~ @Equation1894 Fin4 refa638_inst.
Proof. unfold Equation1894. intro H. specialize (H F4_0 F4_3). unfold magma_op, refa638_inst, refa638_op in H. discriminate H. Qed.

Lemma refa638_not2097 : ~ @Equation2097 Fin4 refa638_inst.
Proof. unfold Equation2097. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa638_inst, refa638_op in H. discriminate H. Qed.

Lemma refa638_not3306 : ~ @Equation3306 Fin4 refa638_inst.
Proof. unfold Equation3306. intro H. specialize (H F4_0 F4_3). unfold magma_op, refa638_inst, refa638_op in H. discriminate H. Qed.

Lemma refa638_not3346 : ~ @Equation3346 Fin4 refa638_inst.
Proof. unfold Equation3346. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa638_inst, refa638_op in H. discriminate H. Qed.

Lemma refa638_not3353 : ~ @Equation3353 Fin4 refa638_inst.
Proof. unfold Equation3353. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa638_inst, refa638_op in H. discriminate H. Qed.

Lemma refa638_not3867 : ~ @Equation3867 Fin4 refa638_inst.
Proof. unfold Equation3867. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa638_inst, refa638_op in H. discriminate H. Qed.

Lemma refa638_not3877 : ~ @Equation3877 Fin4 refa638_inst.
Proof. unfold Equation3877. intro H. specialize (H F4_0 F4_2). unfold magma_op, refa638_inst, refa638_op in H. discriminate H. Qed.

Lemma refa638_not3887 : ~ @Equation3887 Fin4 refa638_inst.
Proof. unfold Equation3887. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa638_inst, refa638_op in H. discriminate H. Qed.

Lemma refa638_not3925 : ~ @Equation3925 Fin4 refa638_inst.
Proof. unfold Equation3925. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa638_inst, refa638_op in H. discriminate H. Qed.

Lemma refa638_not4320 : ~ @Equation4320 Fin4 refa638_inst.
Proof. unfold Equation4320. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa638_inst, refa638_op in H. discriminate H. Qed.

(** ---- refa639 (Fin4) ---- *)

Definition refa639_op (x y : Fin4) : Fin4 :=
  match x, y with
  | F4_0, F4_0 => F4_3 | F4_0, F4_1 => F4_1 | F4_0, F4_2 => F4_3 | F4_0, F4_3 => F4_3
  | F4_1, F4_0 => F4_3 | F4_1, F4_1 => F4_2 | F4_1, F4_2 => F4_2 | F4_1, F4_3 => F4_2
  | F4_2, F4_0 => F4_1 | F4_2, F4_1 => F4_3 | F4_2, F4_2 => F4_3 | F4_2, F4_3 => F4_3
  | F4_3, F4_0 => F4_3 | F4_3, F4_1 => F4_3 | F4_3, F4_2 => F4_2 | F4_3, F4_3 => F4_2
  end.

#[local] Instance refa639_inst : Magma Fin4 := {| magma_op := refa639_op |}.

Lemma refa639_sat3469 : @Equation3469 Fin4 refa639_inst.
Proof. unfold Equation3469, magma_op, refa639_inst, refa639_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa639_not3464 : ~ @Equation3464 Fin4 refa639_inst.
Proof. unfold Equation3464. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa639_inst, refa639_op in H. discriminate H. Qed.

Lemma refa639_not4314 : ~ @Equation4314 Fin4 refa639_inst.
Proof. unfold Equation4314. intro H. specialize (H F4_0 F4_2). unfold magma_op, refa639_inst, refa639_op in H. discriminate H. Qed.
