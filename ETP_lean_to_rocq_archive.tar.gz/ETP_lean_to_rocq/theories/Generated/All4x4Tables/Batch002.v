(** * All4x4 counterexamples — batch 2
    Auto-generated from Lean4 All4x4 files. *)

From Stdlib Require Import Utf8.

From ETP Require Import Magma.
From ETP Require Import FinMagma.
From ETP.Equations Require Import All.

Open Scope magma_scope.

(** ---- refa143 (Fin3) ---- *)

Definition refa143_op (x y : Fin3) : Fin3 :=
  match x, y with
  | F3_0, F3_0 => F3_0 | F3_0, F3_1 => F3_0 | F3_0, F3_2 => F3_1
  | F3_1, F3_0 => F3_2 | F3_1, F3_1 => F3_2 | F3_1, F3_2 => F3_0
  | F3_2, F3_0 => F3_0 | F3_2, F3_1 => F3_0 | F3_2, F3_2 => F3_0
  end.

#[local] Instance refa143_inst : Magma Fin3 := {| magma_op := refa143_op |}.

Lemma refa143_sat3466 : @Equation3466 Fin3 refa143_inst.
Proof. unfold Equation3466, magma_op, refa143_inst, refa143_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa143_sat3469 : @Equation3469 Fin3 refa143_inst.
Proof. unfold Equation3469, magma_op, refa143_inst, refa143_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa143_not307 : ~ @Equation307 Fin3 refa143_inst.
Proof. unfold Equation307. intro H. specialize (H F3_1). unfold magma_op, refa143_inst, refa143_op in H. discriminate H. Qed.

Lemma refa143_not3255 : ~ @Equation3255 Fin3 refa143_inst.
Proof. unfold Equation3255. intro H. specialize (H F3_1 F3_0). unfold magma_op, refa143_inst, refa143_op in H. discriminate H. Qed.

Lemma refa143_not3256 : ~ @Equation3256 Fin3 refa143_inst.
Proof. unfold Equation3256. intro H. specialize (H F3_1 F3_0). unfold magma_op, refa143_inst, refa143_op in H. discriminate H. Qed.

Lemma refa143_not3458 : ~ @Equation3458 Fin3 refa143_inst.
Proof. unfold Equation3458. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa143_inst, refa143_op in H. discriminate H. Qed.

Lemma refa143_not3660 : ~ @Equation3660 Fin3 refa143_inst.
Proof. unfold Equation3660. intro H. specialize (H F3_1 F3_0). unfold magma_op, refa143_inst, refa143_op in H. discriminate H. Qed.

Lemma refa143_not3661 : ~ @Equation3661 Fin3 refa143_inst.
Proof. unfold Equation3661. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa143_inst, refa143_op in H. discriminate H. Qed.

Lemma refa143_not3662 : ~ @Equation3662 Fin3 refa143_inst.
Proof. unfold Equation3662. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa143_inst, refa143_op in H. discriminate H. Qed.

Lemma refa143_not3665 : ~ @Equation3665 Fin3 refa143_inst.
Proof. unfold Equation3665. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa143_inst, refa143_op in H. discriminate H. Qed.

Lemma refa143_not3667 : ~ @Equation3667 Fin3 refa143_inst.
Proof. unfold Equation3667. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa143_inst, refa143_op in H. discriminate H. Qed.

Lemma refa143_not3668 : ~ @Equation3668 Fin3 refa143_inst.
Proof. unfold Equation3668. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa143_inst, refa143_op in H. discriminate H. Qed.

Lemma refa143_not3862 : ~ @Equation3862 Fin3 refa143_inst.
Proof. unfold Equation3862. intro H. specialize (H F3_1). unfold magma_op, refa143_inst, refa143_op in H. discriminate H. Qed.

Lemma refa143_not4065 : ~ @Equation4065 Fin3 refa143_inst.
Proof. unfold Equation4065. intro H. specialize (H F3_1). unfold magma_op, refa143_inst, refa143_op in H. discriminate H. Qed.

Lemma refa143_not4268 : ~ @Equation4268 Fin3 refa143_inst.
Proof. unfold Equation4268. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa143_inst, refa143_op in H. discriminate H. Qed.

Lemma refa143_not4269 : ~ @Equation4269 Fin3 refa143_inst.
Proof. unfold Equation4269. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa143_inst, refa143_op in H. discriminate H. Qed.

Lemma refa143_not4270 : ~ @Equation4270 Fin3 refa143_inst.
Proof. unfold Equation4270. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa143_inst, refa143_op in H. discriminate H. Qed.

Lemma refa143_not4283 : ~ @Equation4283 Fin3 refa143_inst.
Proof. unfold Equation4283. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa143_inst, refa143_op in H. discriminate H. Qed.

Lemma refa143_not4284 : ~ @Equation4284 Fin3 refa143_inst.
Proof. unfold Equation4284. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa143_inst, refa143_op in H. discriminate H. Qed.

Lemma refa143_not4380 : ~ @Equation4380 Fin3 refa143_inst.
Proof. unfold Equation4380. intro H. specialize (H F3_2). unfold magma_op, refa143_inst, refa143_op in H. discriminate H. Qed.

Lemma refa143_not4583 : ~ @Equation4583 Fin3 refa143_inst.
Proof. unfold Equation4583. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa143_inst, refa143_op in H. discriminate H. Qed.

Lemma refa143_not4598 : ~ @Equation4598 Fin3 refa143_inst.
Proof. unfold Equation4598. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa143_inst, refa143_op in H. discriminate H. Qed.

Lemma refa143_not4631 : ~ @Equation4631 Fin3 refa143_inst.
Proof. unfold Equation4631. intro H. specialize (H F3_0 F3_0 F3_2). unfold magma_op, refa143_inst, refa143_op in H. discriminate H. Qed.

(** ---- refa144 (Fin3) ---- *)

Definition refa144_op (x y : Fin3) : Fin3 :=
  match x, y with
  | F3_0, F3_0 => F3_0 | F3_0, F3_1 => F3_2 | F3_0, F3_2 => F3_1
  | F3_1, F3_0 => F3_0 | F3_1, F3_1 => F3_2 | F3_1, F3_2 => F3_0
  | F3_2, F3_0 => F3_2 | F3_2, F3_1 => F3_1 | F3_2, F3_2 => F3_0
  end.

#[local] Instance refa144_inst : Magma Fin3 := {| magma_op := refa144_op |}.

Lemma refa144_sat1897 : @Equation1897 Fin3 refa144_inst.
Proof. unfold Equation1897, magma_op, refa144_inst, refa144_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa144_not99 : ~ @Equation99 Fin3 refa144_inst.
Proof. unfold Equation99. intro H. specialize (H F3_1). unfold magma_op, refa144_inst, refa144_op in H. discriminate H. Qed.

Lemma refa144_not151 : ~ @Equation151 Fin3 refa144_inst.
Proof. unfold Equation151. intro H. specialize (H F3_1). unfold magma_op, refa144_inst, refa144_op in H. discriminate H. Qed.

Lemma refa144_not359 : ~ @Equation359 Fin3 refa144_inst.
Proof. unfold Equation359. intro H. specialize (H F3_1). unfold magma_op, refa144_inst, refa144_op in H. discriminate H. Qed.

Lemma refa144_not411 : ~ @Equation411 Fin3 refa144_inst.
Proof. unfold Equation411. intro H. specialize (H F3_1). unfold magma_op, refa144_inst, refa144_op in H. discriminate H. Qed.

Lemma refa144_not1020 : ~ @Equation1020 Fin3 refa144_inst.
Proof. unfold Equation1020. intro H. specialize (H F3_1). unfold magma_op, refa144_inst, refa144_op in H. discriminate H. Qed.

Lemma refa144_not1223 : ~ @Equation1223 Fin3 refa144_inst.
Proof. unfold Equation1223. intro H. specialize (H F3_1). unfold magma_op, refa144_inst, refa144_op in H. discriminate H. Qed.

Lemma refa144_not1631 : ~ @Equation1631 Fin3 refa144_inst.
Proof. unfold Equation1631. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa144_inst, refa144_op in H. discriminate H. Qed.

Lemma refa144_not1634 : ~ @Equation1634 Fin3 refa144_inst.
Proof. unfold Equation1634. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa144_inst, refa144_op in H. discriminate H. Qed.

Lemma refa144_not1637 : ~ @Equation1637 Fin3 refa144_inst.
Proof. unfold Equation1637. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa144_inst, refa144_op in H. discriminate H. Qed.

Lemma refa144_not1644 : ~ @Equation1644 Fin3 refa144_inst.
Proof. unfold Equation1644. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa144_inst, refa144_op in H. discriminate H. Qed.

Lemma refa144_not1654 : ~ @Equation1654 Fin3 refa144_inst.
Proof. unfold Equation1654. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa144_inst, refa144_op in H. discriminate H. Qed.

Lemma refa144_not1657 : ~ @Equation1657 Fin3 refa144_inst.
Proof. unfold Equation1657. intro H. specialize (H F3_2 F3_0). unfold magma_op, refa144_inst, refa144_op in H. discriminate H. Qed.

Lemma refa144_not1681 : ~ @Equation1681 Fin3 refa144_inst.
Proof. unfold Equation1681. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa144_inst, refa144_op in H. discriminate H. Qed.

Lemma refa144_not1684 : ~ @Equation1684 Fin3 refa144_inst.
Proof. unfold Equation1684. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa144_inst, refa144_op in H. discriminate H. Qed.

Lemma refa144_not1691 : ~ @Equation1691 Fin3 refa144_inst.
Proof. unfold Equation1691. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa144_inst, refa144_op in H. discriminate H. Qed.

Lemma refa144_not1694 : ~ @Equation1694 Fin3 refa144_inst.
Proof. unfold Equation1694. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa144_inst, refa144_op in H. discriminate H. Qed.

Lemma refa144_not1721 : ~ @Equation1721 Fin3 refa144_inst.
Proof. unfold Equation1721. intro H. specialize (H F3_2 F3_0). unfold magma_op, refa144_inst, refa144_op in H. discriminate H. Qed.

Lemma refa144_not1728 : ~ @Equation1728 Fin3 refa144_inst.
Proof. unfold Equation1728. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa144_inst, refa144_op in H. discriminate H. Qed.

Lemma refa144_not1834 : ~ @Equation1834 Fin3 refa144_inst.
Proof. unfold Equation1834. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa144_inst, refa144_op in H. discriminate H. Qed.

Lemma refa144_not1837 : ~ @Equation1837 Fin3 refa144_inst.
Proof. unfold Equation1837. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa144_inst, refa144_op in H. discriminate H. Qed.

Lemma refa144_not1840 : ~ @Equation1840 Fin3 refa144_inst.
Proof. unfold Equation1840. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa144_inst, refa144_op in H. discriminate H. Qed.

Lemma refa144_not1847 : ~ @Equation1847 Fin3 refa144_inst.
Proof. unfold Equation1847. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa144_inst, refa144_op in H. discriminate H. Qed.

Lemma refa144_not1860 : ~ @Equation1860 Fin3 refa144_inst.
Proof. unfold Equation1860. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa144_inst, refa144_op in H. discriminate H. Qed.

Lemma refa144_not1921 : ~ @Equation1921 Fin3 refa144_inst.
Proof. unfold Equation1921. intro H. specialize (H F3_1 F3_0). unfold magma_op, refa144_inst, refa144_op in H. discriminate H. Qed.

Lemma refa144_not2035 : ~ @Equation2035 Fin3 refa144_inst.
Proof. unfold Equation2035. intro H. specialize (H F3_1). unfold magma_op, refa144_inst, refa144_op in H. discriminate H. Qed.

Lemma refa144_not3253 : ~ @Equation3253 Fin3 refa144_inst.
Proof. unfold Equation3253. intro H. specialize (H F3_1). unfold magma_op, refa144_inst, refa144_op in H. discriminate H. Qed.

Lemma refa144_not3867 : ~ @Equation3867 Fin3 refa144_inst.
Proof. unfold Equation3867. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa144_inst, refa144_op in H. discriminate H. Qed.

Lemma refa144_not3877 : ~ @Equation3877 Fin3 refa144_inst.
Proof. unfold Equation3877. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa144_inst, refa144_op in H. discriminate H. Qed.

Lemma refa144_not3887 : ~ @Equation3887 Fin3 refa144_inst.
Proof. unfold Equation3887. intro H. specialize (H F3_2 F3_1). unfold magma_op, refa144_inst, refa144_op in H. discriminate H. Qed.

Lemma refa144_not3915 : ~ @Equation3915 Fin3 refa144_inst.
Proof. unfold Equation3915. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa144_inst, refa144_op in H. discriminate H. Qed.

Lemma refa144_not3925 : ~ @Equation3925 Fin3 refa144_inst.
Proof. unfold Equation3925. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa144_inst, refa144_op in H. discriminate H. Qed.

Lemma refa144_not3952 : ~ @Equation3952 Fin3 refa144_inst.
Proof. unfold Equation3952. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa144_inst, refa144_op in H. discriminate H. Qed.

Lemma refa144_not3962 : ~ @Equation3962 Fin3 refa144_inst.
Proof. unfold Equation3962. intro H. specialize (H F3_2 F3_1). unfold magma_op, refa144_inst, refa144_op in H. discriminate H. Qed.

Lemma refa144_not4275 : ~ @Equation4275 Fin3 refa144_inst.
Proof. unfold Equation4275. intro H. specialize (H F3_1 F3_0). unfold magma_op, refa144_inst, refa144_op in H. discriminate H. Qed.

Lemma refa144_not4320 : ~ @Equation4320 Fin3 refa144_inst.
Proof. unfold Equation4320. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa144_inst, refa144_op in H. discriminate H. Qed.

Lemma refa144_not4587 : ~ @Equation4587 Fin3 refa144_inst.
Proof. unfold Equation4587. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa144_inst, refa144_op in H. discriminate H. Qed.

Lemma refa144_not4606 : ~ @Equation4606 Fin3 refa144_inst.
Proof. unfold Equation4606. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa144_inst, refa144_op in H. discriminate H. Qed.

(** ---- refa145 (Fin3) ---- *)

Definition refa145_op (x y : Fin3) : Fin3 :=
  match x, y with
  | F3_0, F3_0 => F3_0 | F3_0, F3_1 => F3_0 | F3_0, F3_2 => F3_1
  | F3_1, F3_0 => F3_1 | F3_1, F3_1 => F3_2 | F3_1, F3_2 => F3_2
  | F3_2, F3_0 => F3_1 | F3_2, F3_1 => F3_1 | F3_2, F3_2 => F3_1
  end.

#[local] Instance refa145_inst : Magma Fin3 := {| magma_op := refa145_op |}.

Lemma refa145_sat1839 : @Equation1839 Fin3 refa145_inst.
Proof. unfold Equation1839, magma_op, refa145_inst, refa145_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa145_not1632 : ~ @Equation1632 Fin3 refa145_inst.
Proof. unfold Equation1632. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa145_inst, refa145_op in H. discriminate H. Qed.

Lemma refa145_not2449 : ~ @Equation2449 Fin3 refa145_inst.
Proof. unfold Equation2449. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa145_inst, refa145_op in H. discriminate H. Qed.

Lemma refa145_not3459 : ~ @Equation3459 Fin3 refa145_inst.
Proof. unfold Equation3459. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa145_inst, refa145_op in H. discriminate H. Qed.

(** ---- refa146 (Fin3) ---- *)

Definition refa146_op (x y : Fin3) : Fin3 :=
  match x, y with
  | F3_0, F3_0 => F3_0 | F3_0, F3_1 => F3_0 | F3_0, F3_2 => F3_1
  | F3_1, F3_0 => F3_0 | F3_1, F3_1 => F3_0 | F3_1, F3_2 => F3_1
  | F3_2, F3_0 => F3_1 | F3_2, F3_1 => F3_0 | F3_2, F3_2 => F3_1
  end.

#[local] Instance refa146_inst : Magma Fin3 := {| magma_op := refa146_op |}.

Lemma refa146_sat3265 : @Equation3265 Fin3 refa146_inst.
Proof. unfold Equation3265, magma_op, refa146_inst, refa146_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa146_sat4324 : @Equation4324 Fin3 refa146_inst.
Proof. unfold Equation4324, magma_op, refa146_inst, refa146_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa146_not307 : ~ @Equation307 Fin3 refa146_inst.
Proof. unfold Equation307. intro H. specialize (H F3_2). unfold magma_op, refa146_inst, refa146_op in H. discriminate H. Qed.

Lemma refa146_not3256 : ~ @Equation3256 Fin3 refa146_inst.
Proof. unfold Equation3256. intro H. specialize (H F3_2 F3_0). unfold magma_op, refa146_inst, refa146_op in H. discriminate H. Qed.

Lemma refa146_not3306 : ~ @Equation3306 Fin3 refa146_inst.
Proof. unfold Equation3306. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa146_inst, refa146_op in H. discriminate H. Qed.

Lemma refa146_not3456 : ~ @Equation3456 Fin3 refa146_inst.
Proof. unfold Equation3456. intro H. specialize (H F3_2). unfold magma_op, refa146_inst, refa146_op in H. discriminate H. Qed.

Lemma refa146_not3659 : ~ @Equation3659 Fin3 refa146_inst.
Proof. unfold Equation3659. intro H. specialize (H F3_2). unfold magma_op, refa146_inst, refa146_op in H. discriminate H. Qed.

Lemma refa146_not4270 : ~ @Equation4270 Fin3 refa146_inst.
Proof. unfold Equation4270. intro H. specialize (H F3_2 F3_0). unfold magma_op, refa146_inst, refa146_op in H. discriminate H. Qed.

Lemma refa146_not4272 : ~ @Equation4272 Fin3 refa146_inst.
Proof. unfold Equation4272. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa146_inst, refa146_op in H. discriminate H. Qed.

Lemma refa146_not4314 : ~ @Equation4314 Fin3 refa146_inst.
Proof. unfold Equation4314. intro H. specialize (H F3_2 F3_0). unfold magma_op, refa146_inst, refa146_op in H. discriminate H. Qed.

Lemma refa146_not4320 : ~ @Equation4320 Fin3 refa146_inst.
Proof. unfold Equation4320. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa146_inst, refa146_op in H. discriminate H. Qed.

Lemma refa146_not4343 : ~ @Equation4343 Fin3 refa146_inst.
Proof. unfold Equation4343. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa146_inst, refa146_op in H. discriminate H. Qed.

Lemma refa146_not4658 : ~ @Equation4658 Fin3 refa146_inst.
Proof. unfold Equation4658. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa146_inst, refa146_op in H. discriminate H. Qed.

(** ---- refa147 (Fin3) ---- *)

Definition refa147_op (x y : Fin3) : Fin3 :=
  match x, y with
  | F3_0, F3_0 => F3_0 | F3_0, F3_1 => F3_0 | F3_0, F3_2 => F3_2
  | F3_1, F3_0 => F3_1 | F3_1, F3_1 => F3_1 | F3_1, F3_2 => F3_2
  | F3_2, F3_0 => F3_1 | F3_2, F3_1 => F3_0 | F3_2, F3_2 => F3_2
  end.

#[local] Instance refa147_inst : Magma Fin3 := {| magma_op := refa147_op |}.

Lemma refa147_sat10 : @Equation10 Fin3 refa147_inst.
Proof. unfold Equation10, magma_op, refa147_inst, refa147_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa147_sat446 : @Equation446 Fin3 refa147_inst.
Proof. unfold Equation446, magma_op, refa147_inst, refa147_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa147_sat649 : @Equation649 Fin3 refa147_inst.
Proof. unfold Equation649, magma_op, refa147_inst, refa147_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa147_sat1437 : @Equation1437 Fin3 refa147_inst.
Proof. unfold Equation1437, magma_op, refa147_inst, refa147_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa147_sat2037 : @Equation2037 Fin3 refa147_inst.
Proof. unfold Equation2037, magma_op, refa147_inst, refa147_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa147_sat2273 : @Equation2273 Fin3 refa147_inst.
Proof. unfold Equation2273, magma_op, refa147_inst, refa147_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa147_sat2862 : @Equation2862 Fin3 refa147_inst.
Proof. unfold Equation2862, magma_op, refa147_inst, refa147_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa147_sat4432 : @Equation4432 Fin3 refa147_inst.
Proof. unfold Equation4432, magma_op, refa147_inst, refa147_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa147_not414 : ~ @Equation414 Fin3 refa147_inst.
Proof. unfold Equation414. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa147_inst, refa147_op in H. discriminate H. Qed.

Lemma refa147_not427 : ~ @Equation427 Fin3 refa147_inst.
Proof. unfold Equation427. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa147_inst, refa147_op in H. discriminate H. Qed.

Lemma refa147_not430 : ~ @Equation430 Fin3 refa147_inst.
Proof. unfold Equation430. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa147_inst, refa147_op in H. discriminate H. Qed.

Lemma refa147_not437 : ~ @Equation437 Fin3 refa147_inst.
Proof. unfold Equation437. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa147_inst, refa147_op in H. discriminate H. Qed.

Lemma refa147_not440 : ~ @Equation440 Fin3 refa147_inst.
Proof. unfold Equation440. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa147_inst, refa147_op in H. discriminate H. Qed.

Lemma refa147_not630 : ~ @Equation630 Fin3 refa147_inst.
Proof. unfold Equation630. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa147_inst, refa147_op in H. discriminate H. Qed.

Lemma refa147_not633 : ~ @Equation633 Fin3 refa147_inst.
Proof. unfold Equation633. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa147_inst, refa147_op in H. discriminate H. Qed.

Lemma refa147_not640 : ~ @Equation640 Fin3 refa147_inst.
Proof. unfold Equation640. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa147_inst, refa147_op in H. discriminate H. Qed.

Lemma refa147_not643 : ~ @Equation643 Fin3 refa147_inst.
Proof. unfold Equation643. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa147_inst, refa147_op in H. discriminate H. Qed.

Lemma refa147_not818 : ~ @Equation818 Fin3 refa147_inst.
Proof. unfold Equation818. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa147_inst, refa147_op in H. discriminate H. Qed.

Lemma refa147_not820 : ~ @Equation820 Fin3 refa147_inst.
Proof. unfold Equation820. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa147_inst, refa147_op in H. discriminate H. Qed.

Lemma refa147_not823 : ~ @Equation823 Fin3 refa147_inst.
Proof. unfold Equation823. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa147_inst, refa147_op in H. discriminate H. Qed.

Lemma refa147_not833 : ~ @Equation833 Fin3 refa147_inst.
Proof. unfold Equation833. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa147_inst, refa147_op in H. discriminate H. Qed.

Lemma refa147_not836 : ~ @Equation836 Fin3 refa147_inst.
Proof. unfold Equation836. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa147_inst, refa147_op in H. discriminate H. Qed.

Lemma refa147_not843 : ~ @Equation843 Fin3 refa147_inst.
Proof. unfold Equation843. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa147_inst, refa147_op in H. discriminate H. Qed.

Lemma refa147_not846 : ~ @Equation846 Fin3 refa147_inst.
Proof. unfold Equation846. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa147_inst, refa147_op in H. discriminate H. Qed.

Lemma refa147_not1023 : ~ @Equation1023 Fin3 refa147_inst.
Proof. unfold Equation1023. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa147_inst, refa147_op in H. discriminate H. Qed.

Lemma refa147_not1036 : ~ @Equation1036 Fin3 refa147_inst.
Proof. unfold Equation1036. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa147_inst, refa147_op in H. discriminate H. Qed.

Lemma refa147_not1039 : ~ @Equation1039 Fin3 refa147_inst.
Proof. unfold Equation1039. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa147_inst, refa147_op in H. discriminate H. Qed.

Lemma refa147_not1046 : ~ @Equation1046 Fin3 refa147_inst.
Proof. unfold Equation1046. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa147_inst, refa147_op in H. discriminate H. Qed.

Lemma refa147_not1049 : ~ @Equation1049 Fin3 refa147_inst.
Proof. unfold Equation1049. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa147_inst, refa147_op in H. discriminate H. Qed.

Lemma refa147_not1224 : ~ @Equation1224 Fin3 refa147_inst.
Proof. unfold Equation1224. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa147_inst, refa147_op in H. discriminate H. Qed.

Lemma refa147_not1226 : ~ @Equation1226 Fin3 refa147_inst.
Proof. unfold Equation1226. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa147_inst, refa147_op in H. discriminate H. Qed.

Lemma refa147_not1229 : ~ @Equation1229 Fin3 refa147_inst.
Proof. unfold Equation1229. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa147_inst, refa147_op in H. discriminate H. Qed.

Lemma refa147_not1239 : ~ @Equation1239 Fin3 refa147_inst.
Proof. unfold Equation1239. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa147_inst, refa147_op in H. discriminate H. Qed.

Lemma refa147_not1242 : ~ @Equation1242 Fin3 refa147_inst.
Proof. unfold Equation1242. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa147_inst, refa147_op in H. discriminate H. Qed.

Lemma refa147_not1249 : ~ @Equation1249 Fin3 refa147_inst.
Proof. unfold Equation1249. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa147_inst, refa147_op in H. discriminate H. Qed.

Lemma refa147_not1252 : ~ @Equation1252 Fin3 refa147_inst.
Proof. unfold Equation1252. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa147_inst, refa147_op in H. discriminate H. Qed.

Lemma refa147_not1432 : ~ @Equation1432 Fin3 refa147_inst.
Proof. unfold Equation1432. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa147_inst, refa147_op in H. discriminate H. Qed.

Lemma refa147_not1435 : ~ @Equation1435 Fin3 refa147_inst.
Proof. unfold Equation1435. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa147_inst, refa147_op in H. discriminate H. Qed.

Lemma refa147_not1441 : ~ @Equation1441 Fin3 refa147_inst.
Proof. unfold Equation1441. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa147_inst, refa147_op in H. discriminate H. Qed.

Lemma refa147_not1444 : ~ @Equation1444 Fin3 refa147_inst.
Proof. unfold Equation1444. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa147_inst, refa147_op in H. discriminate H. Qed.

Lemma refa147_not1445 : ~ @Equation1445 Fin3 refa147_inst.
Proof. unfold Equation1445. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa147_inst, refa147_op in H. discriminate H. Qed.

Lemma refa147_not1452 : ~ @Equation1452 Fin3 refa147_inst.
Proof. unfold Equation1452. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa147_inst, refa147_op in H. discriminate H. Qed.

Lemma refa147_not1454 : ~ @Equation1454 Fin3 refa147_inst.
Proof. unfold Equation1454. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa147_inst, refa147_op in H. discriminate H. Qed.

Lemma refa147_not1638 : ~ @Equation1638 Fin3 refa147_inst.
Proof. unfold Equation1638. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa147_inst, refa147_op in H. discriminate H. Qed.

Lemma refa147_not1644 : ~ @Equation1644 Fin3 refa147_inst.
Proof. unfold Equation1644. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa147_inst, refa147_op in H. discriminate H. Qed.

Lemma refa147_not1648 : ~ @Equation1648 Fin3 refa147_inst.
Proof. unfold Equation1648. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa147_inst, refa147_op in H. discriminate H. Qed.

Lemma refa147_not1655 : ~ @Equation1655 Fin3 refa147_inst.
Proof. unfold Equation1655. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa147_inst, refa147_op in H. discriminate H. Qed.

Lemma refa147_not1837 : ~ @Equation1837 Fin3 refa147_inst.
Proof. unfold Equation1837. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa147_inst, refa147_op in H. discriminate H. Qed.

Lemma refa147_not1841 : ~ @Equation1841 Fin3 refa147_inst.
Proof. unfold Equation1841. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa147_inst, refa147_op in H. discriminate H. Qed.

Lemma refa147_not1851 : ~ @Equation1851 Fin3 refa147_inst.
Proof. unfold Equation1851. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa147_inst, refa147_op in H. discriminate H. Qed.

Lemma refa147_not1857 : ~ @Equation1857 Fin3 refa147_inst.
Proof. unfold Equation1857. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa147_inst, refa147_op in H. discriminate H. Qed.

Lemma refa147_not1858 : ~ @Equation1858 Fin3 refa147_inst.
Proof. unfold Equation1858. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa147_inst, refa147_op in H. discriminate H. Qed.

Lemma refa147_not1861 : ~ @Equation1861 Fin3 refa147_inst.
Proof. unfold Equation1861. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa147_inst, refa147_op in H. discriminate H. Qed.

Lemma refa147_not2038 : ~ @Equation2038 Fin3 refa147_inst.
Proof. unfold Equation2038. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa147_inst, refa147_op in H. discriminate H. Qed.

Lemma refa147_not2040 : ~ @Equation2040 Fin3 refa147_inst.
Proof. unfold Equation2040. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa147_inst, refa147_op in H. discriminate H. Qed.

Lemma refa147_not2041 : ~ @Equation2041 Fin3 refa147_inst.
Proof. unfold Equation2041. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa147_inst, refa147_op in H. discriminate H. Qed.

Lemma refa147_not2044 : ~ @Equation2044 Fin3 refa147_inst.
Proof. unfold Equation2044. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa147_inst, refa147_op in H. discriminate H. Qed.

Lemma refa147_not2050 : ~ @Equation2050 Fin3 refa147_inst.
Proof. unfold Equation2050. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa147_inst, refa147_op in H. discriminate H. Qed.

Lemma refa147_not2053 : ~ @Equation2053 Fin3 refa147_inst.
Proof. unfold Equation2053. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa147_inst, refa147_op in H. discriminate H. Qed.

Lemma refa147_not2054 : ~ @Equation2054 Fin3 refa147_inst.
Proof. unfold Equation2054. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa147_inst, refa147_op in H. discriminate H. Qed.

Lemma refa147_not2060 : ~ @Equation2060 Fin3 refa147_inst.
Proof. unfold Equation2060. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa147_inst, refa147_op in H. discriminate H. Qed.

Lemma refa147_not2061 : ~ @Equation2061 Fin3 refa147_inst.
Proof. unfold Equation2061. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa147_inst, refa147_op in H. discriminate H. Qed.

Lemma refa147_not2064 : ~ @Equation2064 Fin3 refa147_inst.
Proof. unfold Equation2064. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa147_inst, refa147_op in H. discriminate H. Qed.

Lemma refa147_not2241 : ~ @Equation2241 Fin3 refa147_inst.
Proof. unfold Equation2241. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa147_inst, refa147_op in H. discriminate H. Qed.

Lemma refa147_not2244 : ~ @Equation2244 Fin3 refa147_inst.
Proof. unfold Equation2244. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa147_inst, refa147_op in H. discriminate H. Qed.

Lemma refa147_not2247 : ~ @Equation2247 Fin3 refa147_inst.
Proof. unfold Equation2247. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa147_inst, refa147_op in H. discriminate H. Qed.

Lemma refa147_not2254 : ~ @Equation2254 Fin3 refa147_inst.
Proof. unfold Equation2254. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa147_inst, refa147_op in H. discriminate H. Qed.

Lemma refa147_not2256 : ~ @Equation2256 Fin3 refa147_inst.
Proof. unfold Equation2256. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa147_inst, refa147_op in H. discriminate H. Qed.

Lemma refa147_not2257 : ~ @Equation2257 Fin3 refa147_inst.
Proof. unfold Equation2257. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa147_inst, refa147_op in H. discriminate H. Qed.

Lemma refa147_not2264 : ~ @Equation2264 Fin3 refa147_inst.
Proof. unfold Equation2264. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa147_inst, refa147_op in H. discriminate H. Qed.

Lemma refa147_not2266 : ~ @Equation2266 Fin3 refa147_inst.
Proof. unfold Equation2266. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa147_inst, refa147_op in H. discriminate H. Qed.

Lemma refa147_not2267 : ~ @Equation2267 Fin3 refa147_inst.
Proof. unfold Equation2267. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa147_inst, refa147_op in H. discriminate H. Qed.

Lemma refa147_not2447 : ~ @Equation2447 Fin3 refa147_inst.
Proof. unfold Equation2447. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa147_inst, refa147_op in H. discriminate H. Qed.

Lemma refa147_not2450 : ~ @Equation2450 Fin3 refa147_inst.
Proof. unfold Equation2450. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa147_inst, refa147_op in H. discriminate H. Qed.

Lemma refa147_not2460 : ~ @Equation2460 Fin3 refa147_inst.
Proof. unfold Equation2460. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa147_inst, refa147_op in H. discriminate H. Qed.

Lemma refa147_not2467 : ~ @Equation2467 Fin3 refa147_inst.
Proof. unfold Equation2467. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa147_inst, refa147_op in H. discriminate H. Qed.

Lemma refa147_not2469 : ~ @Equation2469 Fin3 refa147_inst.
Proof. unfold Equation2469. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa147_inst, refa147_op in H. discriminate H. Qed.

Lemma refa147_not2650 : ~ @Equation2650 Fin3 refa147_inst.
Proof. unfold Equation2650. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa147_inst, refa147_op in H. discriminate H. Qed.

Lemma refa147_not2659 : ~ @Equation2659 Fin3 refa147_inst.
Proof. unfold Equation2659. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa147_inst, refa147_op in H. discriminate H. Qed.

Lemma refa147_not2660 : ~ @Equation2660 Fin3 refa147_inst.
Proof. unfold Equation2660. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa147_inst, refa147_op in H. discriminate H. Qed.

Lemma refa147_not2672 : ~ @Equation2672 Fin3 refa147_inst.
Proof. unfold Equation2672. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa147_inst, refa147_op in H. discriminate H. Qed.

Lemma refa147_not2849 : ~ @Equation2849 Fin3 refa147_inst.
Proof. unfold Equation2849. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa147_inst, refa147_op in H. discriminate H. Qed.

Lemma refa147_not2852 : ~ @Equation2852 Fin3 refa147_inst.
Proof. unfold Equation2852. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa147_inst, refa147_op in H. discriminate H. Qed.

Lemma refa147_not2853 : ~ @Equation2853 Fin3 refa147_inst.
Proof. unfold Equation2853. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa147_inst, refa147_op in H. discriminate H. Qed.

Lemma refa147_not2855 : ~ @Equation2855 Fin3 refa147_inst.
Proof. unfold Equation2855. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa147_inst, refa147_op in H. discriminate H. Qed.

Lemma refa147_not2856 : ~ @Equation2856 Fin3 refa147_inst.
Proof. unfold Equation2856. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa147_inst, refa147_op in H. discriminate H. Qed.

Lemma refa147_not2863 : ~ @Equation2863 Fin3 refa147_inst.
Proof. unfold Equation2863. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa147_inst, refa147_op in H. discriminate H. Qed.

Lemma refa147_not2865 : ~ @Equation2865 Fin3 refa147_inst.
Proof. unfold Equation2865. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa147_inst, refa147_op in H. discriminate H. Qed.

Lemma refa147_not2866 : ~ @Equation2866 Fin3 refa147_inst.
Proof. unfold Equation2866. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa147_inst, refa147_op in H. discriminate H. Qed.

Lemma refa147_not2872 : ~ @Equation2872 Fin3 refa147_inst.
Proof. unfold Equation2872. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa147_inst, refa147_op in H. discriminate H. Qed.

Lemma refa147_not2873 : ~ @Equation2873 Fin3 refa147_inst.
Proof. unfold Equation2873. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa147_inst, refa147_op in H. discriminate H. Qed.

Lemma refa147_not2875 : ~ @Equation2875 Fin3 refa147_inst.
Proof. unfold Equation2875. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa147_inst, refa147_op in H. discriminate H. Qed.

Lemma refa147_not3052 : ~ @Equation3052 Fin3 refa147_inst.
Proof. unfold Equation3052. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa147_inst, refa147_op in H. discriminate H. Qed.

Lemma refa147_not3055 : ~ @Equation3055 Fin3 refa147_inst.
Proof. unfold Equation3055. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa147_inst, refa147_op in H. discriminate H. Qed.

Lemma refa147_not3056 : ~ @Equation3056 Fin3 refa147_inst.
Proof. unfold Equation3056. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa147_inst, refa147_op in H. discriminate H. Qed.

Lemma refa147_not3065 : ~ @Equation3065 Fin3 refa147_inst.
Proof. unfold Equation3065. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa147_inst, refa147_op in H. discriminate H. Qed.

Lemma refa147_not3069 : ~ @Equation3069 Fin3 refa147_inst.
Proof. unfold Equation3069. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa147_inst, refa147_op in H. discriminate H. Qed.

Lemma refa147_not3076 : ~ @Equation3076 Fin3 refa147_inst.
Proof. unfold Equation3076. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa147_inst, refa147_op in H. discriminate H. Qed.

Lemma refa147_not3078 : ~ @Equation3078 Fin3 refa147_inst.
Proof. unfold Equation3078. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa147_inst, refa147_op in H. discriminate H. Qed.

Lemma refa147_not3256 : ~ @Equation3256 Fin3 refa147_inst.
Proof. unfold Equation3256. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa147_inst, refa147_op in H. discriminate H. Qed.

Lemma refa147_not3259 : ~ @Equation3259 Fin3 refa147_inst.
Proof. unfold Equation3259. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa147_inst, refa147_op in H. discriminate H. Qed.

Lemma refa147_not3262 : ~ @Equation3262 Fin3 refa147_inst.
Proof. unfold Equation3262. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa147_inst, refa147_op in H. discriminate H. Qed.

Lemma refa147_not3278 : ~ @Equation3278 Fin3 refa147_inst.
Proof. unfold Equation3278. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa147_inst, refa147_op in H. discriminate H. Qed.

Lemma refa147_not3279 : ~ @Equation3279 Fin3 refa147_inst.
Proof. unfold Equation3279. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa147_inst, refa147_op in H. discriminate H. Qed.

Lemma refa147_not3308 : ~ @Equation3308 Fin3 refa147_inst.
Proof. unfold Equation3308. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa147_inst, refa147_op in H. discriminate H. Qed.

Lemma refa147_not3309 : ~ @Equation3309 Fin3 refa147_inst.
Proof. unfold Equation3309. intro H. specialize (H F3_2 F3_0). unfold magma_op, refa147_inst, refa147_op in H. discriminate H. Qed.

Lemma refa147_not3315 : ~ @Equation3315 Fin3 refa147_inst.
Proof. unfold Equation3315. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa147_inst, refa147_op in H. discriminate H. Qed.

Lemma refa147_not3318 : ~ @Equation3318 Fin3 refa147_inst.
Proof. unfold Equation3318. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa147_inst, refa147_op in H. discriminate H. Qed.

Lemma refa147_not3326 : ~ @Equation3326 Fin3 refa147_inst.
Proof. unfold Equation3326. intro H. specialize (H F3_2 F3_0 F3_1). unfold magma_op, refa147_inst, refa147_op in H. discriminate H. Qed.

Lemma refa147_not3334 : ~ @Equation3334 Fin3 refa147_inst.
Proof. unfold Equation3334. intro H. specialize (H F3_2 F3_0 F3_1). unfold magma_op, refa147_inst, refa147_op in H. discriminate H. Qed.

Lemma refa147_not3465 : ~ @Equation3465 Fin3 refa147_inst.
Proof. unfold Equation3465. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa147_inst, refa147_op in H. discriminate H. Qed.

Lemma refa147_not3509 : ~ @Equation3509 Fin3 refa147_inst.
Proof. unfold Equation3509. intro H. specialize (H F3_2 F3_0). unfold magma_op, refa147_inst, refa147_op in H. discriminate H. Qed.

Lemma refa147_not3511 : ~ @Equation3511 Fin3 refa147_inst.
Proof. unfold Equation3511. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa147_inst, refa147_op in H. discriminate H. Qed.

Lemma refa147_not3512 : ~ @Equation3512 Fin3 refa147_inst.
Proof. unfold Equation3512. intro H. specialize (H F3_2 F3_0). unfold magma_op, refa147_inst, refa147_op in H. discriminate H. Qed.

Lemma refa147_not3519 : ~ @Equation3519 Fin3 refa147_inst.
Proof. unfold Equation3519. intro H. specialize (H F3_2 F3_0). unfold magma_op, refa147_inst, refa147_op in H. discriminate H. Qed.

Lemma refa147_not3660 : ~ @Equation3660 Fin3 refa147_inst.
Proof. unfold Equation3660. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa147_inst, refa147_op in H. discriminate H. Qed.

Lemma refa147_not3662 : ~ @Equation3662 Fin3 refa147_inst.
Proof. unfold Equation3662. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa147_inst, refa147_op in H. discriminate H. Qed.

Lemma refa147_not3664 : ~ @Equation3664 Fin3 refa147_inst.
Proof. unfold Equation3664. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa147_inst, refa147_op in H. discriminate H. Qed.

Lemma refa147_not3665 : ~ @Equation3665 Fin3 refa147_inst.
Proof. unfold Equation3665. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa147_inst, refa147_op in H. discriminate H. Qed.

Lemma refa147_not3668 : ~ @Equation3668 Fin3 refa147_inst.
Proof. unfold Equation3668. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa147_inst, refa147_op in H. discriminate H. Qed.

Lemma refa147_not3677 : ~ @Equation3677 Fin3 refa147_inst.
Proof. unfold Equation3677. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa147_inst, refa147_op in H. discriminate H. Qed.

Lemma refa147_not3684 : ~ @Equation3684 Fin3 refa147_inst.
Proof. unfold Equation3684. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa147_inst, refa147_op in H. discriminate H. Qed.

Lemma refa147_not3685 : ~ @Equation3685 Fin3 refa147_inst.
Proof. unfold Equation3685. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa147_inst, refa147_op in H. discriminate H. Qed.

Lemma refa147_not3687 : ~ @Equation3687 Fin3 refa147_inst.
Proof. unfold Equation3687. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa147_inst, refa147_op in H. discriminate H. Qed.

Lemma refa147_not3721 : ~ @Equation3721 Fin3 refa147_inst.
Proof. unfold Equation3721. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa147_inst, refa147_op in H. discriminate H. Qed.

Lemma refa147_not3724 : ~ @Equation3724 Fin3 refa147_inst.
Proof. unfold Equation3724. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa147_inst, refa147_op in H. discriminate H. Qed.

Lemma refa147_not3864 : ~ @Equation3864 Fin3 refa147_inst.
Proof. unfold Equation3864. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa147_inst, refa147_op in H. discriminate H. Qed.

Lemma refa147_not3865 : ~ @Equation3865 Fin3 refa147_inst.
Proof. unfold Equation3865. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa147_inst, refa147_op in H. discriminate H. Qed.

Lemma refa147_not3868 : ~ @Equation3868 Fin3 refa147_inst.
Proof. unfold Equation3868. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa147_inst, refa147_op in H. discriminate H. Qed.

Lemma refa147_not3870 : ~ @Equation3870 Fin3 refa147_inst.
Proof. unfold Equation3870. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa147_inst, refa147_op in H. discriminate H. Qed.

Lemma refa147_not3871 : ~ @Equation3871 Fin3 refa147_inst.
Proof. unfold Equation3871. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa147_inst, refa147_op in H. discriminate H. Qed.

Lemma refa147_not3878 : ~ @Equation3878 Fin3 refa147_inst.
Proof. unfold Equation3878. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa147_inst, refa147_op in H. discriminate H. Qed.

Lemma refa147_not3881 : ~ @Equation3881 Fin3 refa147_inst.
Proof. unfold Equation3881. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa147_inst, refa147_op in H. discriminate H. Qed.

Lemma refa147_not3887 : ~ @Equation3887 Fin3 refa147_inst.
Proof. unfold Equation3887. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa147_inst, refa147_op in H. discriminate H. Qed.

Lemma refa147_not3888 : ~ @Equation3888 Fin3 refa147_inst.
Proof. unfold Equation3888. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa147_inst, refa147_op in H. discriminate H. Qed.

Lemma refa147_not3917 : ~ @Equation3917 Fin3 refa147_inst.
Proof. unfold Equation3917. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa147_inst, refa147_op in H. discriminate H. Qed.

Lemma refa147_not3918 : ~ @Equation3918 Fin3 refa147_inst.
Proof. unfold Equation3918. intro H. specialize (H F3_2 F3_0). unfold magma_op, refa147_inst, refa147_op in H. discriminate H. Qed.

Lemma refa147_not4066 : ~ @Equation4066 Fin3 refa147_inst.
Proof. unfold Equation4066. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa147_inst, refa147_op in H. discriminate H. Qed.

Lemma refa147_not4067 : ~ @Equation4067 Fin3 refa147_inst.
Proof. unfold Equation4067. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa147_inst, refa147_op in H. discriminate H. Qed.

Lemma refa147_not4068 : ~ @Equation4068 Fin3 refa147_inst.
Proof. unfold Equation4068. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa147_inst, refa147_op in H. discriminate H. Qed.

Lemma refa147_not4070 : ~ @Equation4070 Fin3 refa147_inst.
Proof. unfold Equation4070. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa147_inst, refa147_op in H. discriminate H. Qed.

Lemma refa147_not4071 : ~ @Equation4071 Fin3 refa147_inst.
Proof. unfold Equation4071. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa147_inst, refa147_op in H. discriminate H. Qed.

Lemma refa147_not4073 : ~ @Equation4073 Fin3 refa147_inst.
Proof. unfold Equation4073. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa147_inst, refa147_op in H. discriminate H. Qed.

Lemma refa147_not4074 : ~ @Equation4074 Fin3 refa147_inst.
Proof. unfold Equation4074. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa147_inst, refa147_op in H. discriminate H. Qed.

Lemma refa147_not4081 : ~ @Equation4081 Fin3 refa147_inst.
Proof. unfold Equation4081. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa147_inst, refa147_op in H. discriminate H. Qed.

Lemma refa147_not4083 : ~ @Equation4083 Fin3 refa147_inst.
Proof. unfold Equation4083. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa147_inst, refa147_op in H. discriminate H. Qed.

Lemma refa147_not4084 : ~ @Equation4084 Fin3 refa147_inst.
Proof. unfold Equation4084. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa147_inst, refa147_op in H. discriminate H. Qed.

Lemma refa147_not4090 : ~ @Equation4090 Fin3 refa147_inst.
Proof. unfold Equation4090. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa147_inst, refa147_op in H. discriminate H. Qed.

Lemma refa147_not4091 : ~ @Equation4091 Fin3 refa147_inst.
Proof. unfold Equation4091. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa147_inst, refa147_op in H. discriminate H. Qed.

Lemma refa147_not4093 : ~ @Equation4093 Fin3 refa147_inst.
Proof. unfold Equation4093. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa147_inst, refa147_op in H. discriminate H. Qed.

Lemma refa147_not4270 : ~ @Equation4270 Fin3 refa147_inst.
Proof. unfold Equation4270. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa147_inst, refa147_op in H. discriminate H. Qed.

Lemma refa147_not4284 : ~ @Equation4284 Fin3 refa147_inst.
Proof. unfold Equation4284. intro H. specialize (H F3_2 F3_0). unfold magma_op, refa147_inst, refa147_op in H. discriminate H. Qed.

Lemma refa147_not4293 : ~ @Equation4293 Fin3 refa147_inst.
Proof. unfold Equation4293. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa147_inst, refa147_op in H. discriminate H. Qed.

Lemma refa147_not4314 : ~ @Equation4314 Fin3 refa147_inst.
Proof. unfold Equation4314. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa147_inst, refa147_op in H. discriminate H. Qed.

Lemma refa147_not4358 : ~ @Equation4358 Fin3 refa147_inst.
Proof. unfold Equation4358. intro H. specialize (H F3_0 F3_0 F3_2). unfold magma_op, refa147_inst, refa147_op in H. discriminate H. Qed.

Lemma refa147_not4396 : ~ @Equation4396 Fin3 refa147_inst.
Proof. unfold Equation4396. intro H. specialize (H F3_2 F3_0). unfold magma_op, refa147_inst, refa147_op in H. discriminate H. Qed.

Lemma refa147_not4398 : ~ @Equation4398 Fin3 refa147_inst.
Proof. unfold Equation4398. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa147_inst, refa147_op in H. discriminate H. Qed.

Lemma refa147_not4399 : ~ @Equation4399 Fin3 refa147_inst.
Proof. unfold Equation4399. intro H. specialize (H F3_2 F3_0). unfold magma_op, refa147_inst, refa147_op in H. discriminate H. Qed.

Lemma refa147_not4435 : ~ @Equation4435 Fin3 refa147_inst.
Proof. unfold Equation4435. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa147_inst, refa147_op in H. discriminate H. Qed.

Lemma refa147_not4583 : ~ @Equation4583 Fin3 refa147_inst.
Proof. unfold Equation4583. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa147_inst, refa147_op in H. discriminate H. Qed.

Lemma refa147_not4584 : ~ @Equation4584 Fin3 refa147_inst.
Proof. unfold Equation4584. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa147_inst, refa147_op in H. discriminate H. Qed.

Lemma refa147_not4585 : ~ @Equation4585 Fin3 refa147_inst.
Proof. unfold Equation4585. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa147_inst, refa147_op in H. discriminate H. Qed.

Lemma refa147_not4588 : ~ @Equation4588 Fin3 refa147_inst.
Proof. unfold Equation4588. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa147_inst, refa147_op in H. discriminate H. Qed.

Lemma refa147_not4590 : ~ @Equation4590 Fin3 refa147_inst.
Proof. unfold Equation4590. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa147_inst, refa147_op in H. discriminate H. Qed.

Lemma refa147_not4591 : ~ @Equation4591 Fin3 refa147_inst.
Proof. unfold Equation4591. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa147_inst, refa147_op in H. discriminate H. Qed.

Lemma refa147_not4598 : ~ @Equation4598 Fin3 refa147_inst.
Proof. unfold Equation4598. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa147_inst, refa147_op in H. discriminate H. Qed.

Lemma refa147_not4606 : ~ @Equation4606 Fin3 refa147_inst.
Proof. unfold Equation4606. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa147_inst, refa147_op in H. discriminate H. Qed.

Lemma refa147_not4608 : ~ @Equation4608 Fin3 refa147_inst.
Proof. unfold Equation4608. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa147_inst, refa147_op in H. discriminate H. Qed.

Lemma refa147_not4636 : ~ @Equation4636 Fin3 refa147_inst.
Proof. unfold Equation4636. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa147_inst, refa147_op in H. discriminate H. Qed.

(** ---- refa148 (Fin3) ---- *)

Definition refa148_op (x y : Fin3) : Fin3 :=
  match x, y with
  | F3_0, F3_0 => F3_0 | F3_0, F3_1 => F3_1 | F3_0, F3_2 => F3_2
  | F3_1, F3_0 => F3_2 | F3_1, F3_1 => F3_0 | F3_1, F3_2 => F3_2
  | F3_2, F3_0 => F3_1 | F3_2, F3_1 => F3_1 | F3_2, F3_2 => F3_0
  end.

#[local] Instance refa148_inst : Magma Fin3 := {| magma_op := refa148_op |}.

Lemma refa148_sat3105 : @Equation3105 Fin3 refa148_inst.
Proof. unfold Equation3105, magma_op, refa148_inst, refa148_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa148_not2530 : ~ @Equation2530 Fin3 refa148_inst.
Proof. unfold Equation2530. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa148_inst, refa148_op in H. discriminate H. Qed.

(** ---- refa149 (Fin3) ---- *)

Definition refa149_op (x y : Fin3) : Fin3 :=
  match x, y with
  | F3_0, F3_0 => F3_0 | F3_0, F3_1 => F3_0 | F3_0, F3_2 => F3_2
  | F3_1, F3_0 => F3_0 | F3_1, F3_1 => F3_2 | F3_1, F3_2 => F3_2
  | F3_2, F3_0 => F3_2 | F3_2, F3_1 => F3_2 | F3_2, F3_2 => F3_0
  end.

#[local] Instance refa149_inst : Magma Fin3 := {| magma_op := refa149_op |}.

Lemma refa149_sat3417 : @Equation3417 Fin3 refa149_inst.
Proof. unfold Equation3417, magma_op, refa149_inst, refa149_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa149_not3259 : ~ @Equation3259 Fin3 refa149_inst.
Proof. unfold Equation3259. intro H. specialize (H F3_1 F3_0). unfold magma_op, refa149_inst, refa149_op in H. discriminate H. Qed.

Lemma refa149_not3261 : ~ @Equation3261 Fin3 refa149_inst.
Proof. unfold Equation3261. intro H. specialize (H F3_1 F3_0). unfold magma_op, refa149_inst, refa149_op in H. discriminate H. Qed.

Lemma refa149_not3319 : ~ @Equation3319 Fin3 refa149_inst.
Proof. unfold Equation3319. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa149_inst, refa149_op in H. discriminate H. Qed.

Lemma refa149_not3342 : ~ @Equation3342 Fin3 refa149_inst.
Proof. unfold Equation3342. intro H. specialize (H F3_1 F3_0). unfold magma_op, refa149_inst, refa149_op in H. discriminate H. Qed.

Lemma refa149_not3459 : ~ @Equation3459 Fin3 refa149_inst.
Proof. unfold Equation3459. intro H. specialize (H F3_1 F3_0). unfold magma_op, refa149_inst, refa149_op in H. discriminate H. Qed.

Lemma refa149_not3462 : ~ @Equation3462 Fin3 refa149_inst.
Proof. unfold Equation3462. intro H. specialize (H F3_1 F3_0). unfold magma_op, refa149_inst, refa149_op in H. discriminate H. Qed.

Lemma refa149_not3522 : ~ @Equation3522 Fin3 refa149_inst.
Proof. unfold Equation3522. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa149_inst, refa149_op in H. discriminate H. Qed.

Lemma refa149_not3545 : ~ @Equation3545 Fin3 refa149_inst.
Proof. unfold Equation3545. intro H. specialize (H F3_1 F3_0). unfold magma_op, refa149_inst, refa149_op in H. discriminate H. Qed.

Lemma refa149_not3880 : ~ @Equation3880 Fin3 refa149_inst.
Proof. unfold Equation3880. intro H. specialize (H F3_1 F3_0). unfold magma_op, refa149_inst, refa149_op in H. discriminate H. Qed.

Lemma refa149_not3887 : ~ @Equation3887 Fin3 refa149_inst.
Proof. unfold Equation3887. intro H. specialize (H F3_1 F3_0). unfold magma_op, refa149_inst, refa149_op in H. discriminate H. Qed.

Lemma refa149_not3915 : ~ @Equation3915 Fin3 refa149_inst.
Proof. unfold Equation3915. intro H. specialize (H F3_1 F3_0). unfold magma_op, refa149_inst, refa149_op in H. discriminate H. Qed.

Lemma refa149_not3964 : ~ @Equation3964 Fin3 refa149_inst.
Proof. unfold Equation3964. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa149_inst, refa149_op in H. discriminate H. Qed.

Lemma refa149_not4073 : ~ @Equation4073 Fin3 refa149_inst.
Proof. unfold Equation4073. intro H. specialize (H F3_1 F3_0). unfold magma_op, refa149_inst, refa149_op in H. discriminate H. Qed.

Lemma refa149_not4083 : ~ @Equation4083 Fin3 refa149_inst.
Proof. unfold Equation4083. intro H. specialize (H F3_1 F3_0). unfold magma_op, refa149_inst, refa149_op in H. discriminate H. Qed.

Lemma refa149_not4118 : ~ @Equation4118 Fin3 refa149_inst.
Proof. unfold Equation4118. intro H. specialize (H F3_1 F3_0). unfold magma_op, refa149_inst, refa149_op in H. discriminate H. Qed.

Lemma refa149_not4167 : ~ @Equation4167 Fin3 refa149_inst.
Proof. unfold Equation4167. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa149_inst, refa149_op in H. discriminate H. Qed.

Lemma refa149_not4273 : ~ @Equation4273 Fin3 refa149_inst.
Proof. unfold Equation4273. intro H. specialize (H F3_1 F3_0). unfold magma_op, refa149_inst, refa149_op in H. discriminate H. Qed.

Lemma refa149_not4275 : ~ @Equation4275 Fin3 refa149_inst.
Proof. unfold Equation4275. intro H. specialize (H F3_1 F3_0). unfold magma_op, refa149_inst, refa149_op in H. discriminate H. Qed.

Lemma refa149_not4647 : ~ @Equation4647 Fin3 refa149_inst.
Proof. unfold Equation4647. intro H. specialize (H F3_0 F3_1 F3_1). unfold magma_op, refa149_inst, refa149_op in H. discriminate H. Qed.

Lemma refa149_not4656 : ~ @Equation4656 Fin3 refa149_inst.
Proof. unfold Equation4656. intro H. specialize (H F3_1 F3_0 F3_1). unfold magma_op, refa149_inst, refa149_op in H. discriminate H. Qed.

(** ---- refa15 (Fin7) ---- *)

Definition refa15_op (x y : Fin7) : Fin7 :=
  match x, y with
  | F7_0, F7_0 => F7_1 | F7_0, F7_1 => F7_2 | F7_0, F7_2 => F7_0 | F7_0, F7_3 => F7_3 | F7_0, F7_4 => F7_6 | F7_0, F7_5 => F7_4 | F7_0, F7_6 => F7_5
  | F7_1, F7_0 => F7_3 | F7_1, F7_1 => F7_1 | F7_1, F7_2 => F7_6 | F7_1, F7_3 => F7_5 | F7_1, F7_4 => F7_2 | F7_1, F7_5 => F7_0 | F7_1, F7_6 => F7_4
  | F7_2, F7_0 => F7_4 | F7_2, F7_1 => F7_5 | F7_2, F7_2 => F7_1 | F7_2, F7_3 => F7_0 | F7_2, F7_4 => F7_3 | F7_2, F7_5 => F7_2 | F7_2, F7_6 => F7_6
  | F7_3, F7_0 => F7_2 | F7_3, F7_1 => F7_6 | F7_3, F7_2 => F7_4 | F7_3, F7_3 => F7_1 | F7_3, F7_4 => F7_0 | F7_3, F7_5 => F7_5 | F7_3, F7_6 => F7_3
  | F7_4, F7_0 => F7_5 | F7_4, F7_1 => F7_3 | F7_4, F7_2 => F7_2 | F7_4, F7_3 => F7_4 | F7_4, F7_4 => F7_1 | F7_4, F7_5 => F7_6 | F7_4, F7_6 => F7_0
  | F7_5, F7_0 => F7_0 | F7_5, F7_1 => F7_4 | F7_5, F7_2 => F7_3 | F7_5, F7_3 => F7_6 | F7_5, F7_4 => F7_5 | F7_5, F7_5 => F7_1 | F7_5, F7_6 => F7_2
  | F7_6, F7_0 => F7_6 | F7_6, F7_1 => F7_0 | F7_6, F7_2 => F7_5 | F7_6, F7_3 => F7_2 | F7_6, F7_4 => F7_4 | F7_6, F7_5 => F7_3 | F7_6, F7_6 => F7_1
  end.

#[local] Instance refa15_inst : Magma Fin7 := {| magma_op := refa15_op |}.

Lemma refa15_sat1285 : @Equation1285 Fin7 refa15_inst.
Proof. unfold Equation1285, magma_op, refa15_inst, refa15_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa15_sat1313 : @Equation1313 Fin7 refa15_inst.
Proof. unfold Equation1313, magma_op, refa15_inst, refa15_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa15_not56 : ~ @Equation56 Fin7 refa15_inst.
Proof. unfold Equation56. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa15_inst, refa15_op in H. discriminate H. Qed.

Lemma refa15_not411 : ~ @Equation411 Fin7 refa15_inst.
Proof. unfold Equation411. intro H. specialize (H F7_0). unfold magma_op, refa15_inst, refa15_op in H. discriminate H. Qed.

Lemma refa15_not614 : ~ @Equation614 Fin7 refa15_inst.
Proof. unfold Equation614. intro H. specialize (H F7_0). unfold magma_op, refa15_inst, refa15_op in H. discriminate H. Qed.

Lemma refa15_not817 : ~ @Equation817 Fin7 refa15_inst.
Proof. unfold Equation817. intro H. specialize (H F7_0). unfold magma_op, refa15_inst, refa15_op in H. discriminate H. Qed.

Lemma refa15_not1020 : ~ @Equation1020 Fin7 refa15_inst.
Proof. unfold Equation1020. intro H. specialize (H F7_0). unfold magma_op, refa15_inst, refa15_op in H. discriminate H. Qed.

Lemma refa15_not1241 : ~ @Equation1241 Fin7 refa15_inst.
Proof. unfold Equation1241. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa15_inst, refa15_op in H. discriminate H. Qed.

Lemma refa15_not1426 : ~ @Equation1426 Fin7 refa15_inst.
Proof. unfold Equation1426. intro H. specialize (H F7_0). unfold magma_op, refa15_inst, refa15_op in H. discriminate H. Qed.

Lemma refa15_not1629 : ~ @Equation1629 Fin7 refa15_inst.
Proof. unfold Equation1629. intro H. specialize (H F7_0). unfold magma_op, refa15_inst, refa15_op in H. discriminate H. Qed.

Lemma refa15_not1832 : ~ @Equation1832 Fin7 refa15_inst.
Proof. unfold Equation1832. intro H. specialize (H F7_0). unfold magma_op, refa15_inst, refa15_op in H. discriminate H. Qed.

Lemma refa15_not2035 : ~ @Equation2035 Fin7 refa15_inst.
Proof. unfold Equation2035. intro H. specialize (H F7_0). unfold magma_op, refa15_inst, refa15_op in H. discriminate H. Qed.

Lemma refa15_not2238 : ~ @Equation2238 Fin7 refa15_inst.
Proof. unfold Equation2238. intro H. specialize (H F7_0). unfold magma_op, refa15_inst, refa15_op in H. discriminate H. Qed.

Lemma refa15_not2441 : ~ @Equation2441 Fin7 refa15_inst.
Proof. unfold Equation2441. intro H. specialize (H F7_0). unfold magma_op, refa15_inst, refa15_op in H. discriminate H. Qed.

Lemma refa15_not2847 : ~ @Equation2847 Fin7 refa15_inst.
Proof. unfold Equation2847. intro H. specialize (H F7_0). unfold magma_op, refa15_inst, refa15_op in H. discriminate H. Qed.

Lemma refa15_not3050 : ~ @Equation3050 Fin7 refa15_inst.
Proof. unfold Equation3050. intro H. specialize (H F7_0). unfold magma_op, refa15_inst, refa15_op in H. discriminate H. Qed.

Lemma refa15_not3253 : ~ @Equation3253 Fin7 refa15_inst.
Proof. unfold Equation3253. intro H. specialize (H F7_0). unfold magma_op, refa15_inst, refa15_op in H. discriminate H. Qed.

Lemma refa15_not3456 : ~ @Equation3456 Fin7 refa15_inst.
Proof. unfold Equation3456. intro H. specialize (H F7_0). unfold magma_op, refa15_inst, refa15_op in H. discriminate H. Qed.

Lemma refa15_not3862 : ~ @Equation3862 Fin7 refa15_inst.
Proof. unfold Equation3862. intro H. specialize (H F7_0). unfold magma_op, refa15_inst, refa15_op in H. discriminate H. Qed.

Lemma refa15_not4065 : ~ @Equation4065 Fin7 refa15_inst.
Proof. unfold Equation4065. intro H. specialize (H F7_0). unfold magma_op, refa15_inst, refa15_op in H. discriminate H. Qed.

Lemma refa15_not4275 : ~ @Equation4275 Fin7 refa15_inst.
Proof. unfold Equation4275. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa15_inst, refa15_op in H. discriminate H. Qed.

Lemma refa15_not4380 : ~ @Equation4380 Fin7 refa15_inst.
Proof. unfold Equation4380. intro H. specialize (H F7_0). unfold magma_op, refa15_inst, refa15_op in H. discriminate H. Qed.

Lemma refa15_not4635 : ~ @Equation4635 Fin7 refa15_inst.
Proof. unfold Equation4635. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa15_inst, refa15_op in H. discriminate H. Qed.

(** ---- refa150 (Fin3) ---- *)

Definition refa150_op (x y : Fin3) : Fin3 :=
  match x, y with
  | F3_0, F3_0 => F3_0 | F3_0, F3_1 => F3_1 | F3_0, F3_2 => F3_1
  | F3_1, F3_0 => F3_2 | F3_1, F3_1 => F3_1 | F3_1, F3_2 => F3_2
  | F3_2, F3_0 => F3_0 | F3_2, F3_1 => F3_0 | F3_2, F3_2 => F3_2
  end.

#[local] Instance refa150_inst : Magma Fin3 := {| magma_op := refa150_op |}.

Lemma refa150_sat1481 : @Equation1481 Fin3 refa150_inst.
Proof. unfold Equation1481, magma_op, refa150_inst, refa150_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa150_sat1489 : @Equation1489 Fin3 refa150_inst.
Proof. unfold Equation1489, magma_op, refa150_inst, refa150_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa150_sat2337 : @Equation2337 Fin3 refa150_inst.
Proof. unfold Equation2337, magma_op, refa150_inst, refa150_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa150_sat2533 : @Equation2533 Fin3 refa150_inst.
Proof. unfold Equation2533, magma_op, refa150_inst, refa150_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa150_sat2787 : @Equation2787 Fin3 refa150_inst.
Proof. unfold Equation2787, magma_op, refa150_inst, refa150_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa150_not264 : ~ @Equation264 Fin3 refa150_inst.
Proof. unfold Equation264. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa150_inst, refa150_op in H. discriminate H. Qed.

Lemma refa150_not283 : ~ @Equation283 Fin3 refa150_inst.
Proof. unfold Equation283. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa150_inst, refa150_op in H. discriminate H. Qed.

Lemma refa150_not1025 : ~ @Equation1025 Fin3 refa150_inst.
Proof. unfold Equation1025. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa150_inst, refa150_op in H. discriminate H. Qed.

Lemma refa150_not1516 : ~ @Equation1516 Fin3 refa150_inst.
Proof. unfold Equation1516. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa150_inst, refa150_op in H. discriminate H. Qed.

Lemma refa150_not1847 : ~ @Equation1847 Fin3 refa150_inst.
Proof. unfold Equation1847. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa150_inst, refa150_op in H. discriminate H. Qed.

Lemma refa150_not2243 : ~ @Equation2243 Fin3 refa150_inst.
Proof. unfold Equation2243. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa150_inst, refa150_op in H. discriminate H. Qed.

Lemma refa150_not2253 : ~ @Equation2253 Fin3 refa150_inst.
Proof. unfold Equation2253. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa150_inst, refa150_op in H. discriminate H. Qed.

Lemma refa150_not2263 : ~ @Equation2263 Fin3 refa150_inst.
Proof. unfold Equation2263. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa150_inst, refa150_op in H. discriminate H. Qed.

Lemma refa150_not2300 : ~ @Equation2300 Fin3 refa150_inst.
Proof. unfold Equation2300. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa150_inst, refa150_op in H. discriminate H. Qed.

Lemma refa150_not2446 : ~ @Equation2446 Fin3 refa150_inst.
Proof. unfold Equation2446. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa150_inst, refa150_op in H. discriminate H. Qed.

Lemma refa150_not2449 : ~ @Equation2449 Fin3 refa150_inst.
Proof. unfold Equation2449. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa150_inst, refa150_op in H. discriminate H. Qed.

Lemma refa150_not2466 : ~ @Equation2466 Fin3 refa150_inst.
Proof. unfold Equation2466. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa150_inst, refa150_op in H. discriminate H. Qed.

Lemma refa150_not2496 : ~ @Equation2496 Fin3 refa150_inst.
Proof. unfold Equation2496. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa150_inst, refa150_op in H. discriminate H. Qed.

Lemma refa150_not2543 : ~ @Equation2543 Fin3 refa150_inst.
Proof. unfold Equation2543. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa150_inst, refa150_op in H. discriminate H. Qed.

Lemma refa150_not2649 : ~ @Equation2649 Fin3 refa150_inst.
Proof. unfold Equation2649. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa150_inst, refa150_op in H. discriminate H. Qed.

Lemma refa150_not2709 : ~ @Equation2709 Fin3 refa150_inst.
Proof. unfold Equation2709. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa150_inst, refa150_op in H. discriminate H. Qed.

Lemma refa150_not2804 : ~ @Equation2804 Fin3 refa150_inst.
Proof. unfold Equation2804. intro H. specialize (H F3_0 F3_2 F3_1). unfold magma_op, refa150_inst, refa150_op in H. discriminate H. Qed.

Lemma refa150_not3058 : ~ @Equation3058 Fin3 refa150_inst.
Proof. unfold Equation3058. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa150_inst, refa150_op in H. discriminate H. Qed.

Lemma refa150_not3197 : ~ @Equation3197 Fin3 refa150_inst.
Proof. unfold Equation3197. intro H. specialize (H F3_0 F3_1 F3_0). unfold magma_op, refa150_inst, refa150_op in H. discriminate H. Qed.

Lemma refa150_not3316 : ~ @Equation3316 Fin3 refa150_inst.
Proof. unfold Equation3316. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa150_inst, refa150_op in H. discriminate H. Qed.

Lemma refa150_not3343 : ~ @Equation3343 Fin3 refa150_inst.
Proof. unfold Equation3343. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa150_inst, refa150_op in H. discriminate H. Qed.

Lemma refa150_not3346 : ~ @Equation3346 Fin3 refa150_inst.
Proof. unfold Equation3346. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa150_inst, refa150_op in H. discriminate H. Qed.

Lemma refa150_not3353 : ~ @Equation3353 Fin3 refa150_inst.
Proof. unfold Equation3353. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa150_inst, refa150_op in H. discriminate H. Qed.

Lemma refa150_not3519 : ~ @Equation3519 Fin3 refa150_inst.
Proof. unfold Equation3519. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa150_inst, refa150_op in H. discriminate H. Qed.

Lemma refa150_not3546 : ~ @Equation3546 Fin3 refa150_inst.
Proof. unfold Equation3546. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa150_inst, refa150_op in H. discriminate H. Qed.

Lemma refa150_not3556 : ~ @Equation3556 Fin3 refa150_inst.
Proof. unfold Equation3556. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa150_inst, refa150_op in H. discriminate H. Qed.

Lemma refa150_not3749 : ~ @Equation3749 Fin3 refa150_inst.
Proof. unfold Equation3749. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa150_inst, refa150_op in H. discriminate H. Qed.

Lemma refa150_not3752 : ~ @Equation3752 Fin3 refa150_inst.
Proof. unfold Equation3752. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa150_inst, refa150_op in H. discriminate H. Qed.

Lemma refa150_not3759 : ~ @Equation3759 Fin3 refa150_inst.
Proof. unfold Equation3759. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa150_inst, refa150_op in H. discriminate H. Qed.

Lemma refa150_not3867 : ~ @Equation3867 Fin3 refa150_inst.
Proof. unfold Equation3867. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa150_inst, refa150_op in H. discriminate H. Qed.

Lemma refa150_not3952 : ~ @Equation3952 Fin3 refa150_inst.
Proof. unfold Equation3952. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa150_inst, refa150_op in H. discriminate H. Qed.

Lemma refa150_not3962 : ~ @Equation3962 Fin3 refa150_inst.
Proof. unfold Equation3962. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa150_inst, refa150_op in H. discriminate H. Qed.

Lemma refa150_not4128 : ~ @Equation4128 Fin3 refa150_inst.
Proof. unfold Equation4128. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa150_inst, refa150_op in H. discriminate H. Qed.

Lemma refa150_not4165 : ~ @Equation4165 Fin3 refa150_inst.
Proof. unfold Equation4165. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa150_inst, refa150_op in H. discriminate H. Qed.

Lemma refa150_not4269 : ~ @Equation4269 Fin3 refa150_inst.
Proof. unfold Equation4269. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa150_inst, refa150_op in H. discriminate H. Qed.

Lemma refa150_not4291 : ~ @Equation4291 Fin3 refa150_inst.
Proof. unfold Equation4291. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa150_inst, refa150_op in H. discriminate H. Qed.

Lemma refa150_not4320 : ~ @Equation4320 Fin3 refa150_inst.
Proof. unfold Equation4320. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa150_inst, refa150_op in H. discriminate H. Qed.

Lemma refa150_not4406 : ~ @Equation4406 Fin3 refa150_inst.
Proof. unfold Equation4406. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa150_inst, refa150_op in H. discriminate H. Qed.

Lemma refa150_not4435 : ~ @Equation4435 Fin3 refa150_inst.
Proof. unfold Equation4435. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa150_inst, refa150_op in H. discriminate H. Qed.

Lemma refa150_not4445 : ~ @Equation4445 Fin3 refa150_inst.
Proof. unfold Equation4445. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa150_inst, refa150_op in H. discriminate H. Qed.

Lemma refa150_not4480 : ~ @Equation4480 Fin3 refa150_inst.
Proof. unfold Equation4480. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa150_inst, refa150_op in H. discriminate H. Qed.

Lemma refa150_not4606 : ~ @Equation4606 Fin3 refa150_inst.
Proof. unfold Equation4606. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa150_inst, refa150_op in H. discriminate H. Qed.

(** ---- refa151 (Fin3) ---- *)

Definition refa151_op (x y : Fin3) : Fin3 :=
  match x, y with
  | F3_0, F3_0 => F3_0 | F3_0, F3_1 => F3_1 | F3_0, F3_2 => F3_2
  | F3_1, F3_0 => F3_2 | F3_1, F3_1 => F3_1 | F3_1, F3_2 => F3_0
  | F3_2, F3_0 => F3_1 | F3_2, F3_1 => F3_0 | F3_2, F3_2 => F3_2
  end.

#[local] Instance refa151_inst : Magma Fin3 := {| magma_op := refa151_op |}.

Lemma refa151_sat72 : @Equation72 Fin3 refa151_inst.
Proof. unfold Equation72, magma_op, refa151_inst, refa151_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa151_sat179 : @Equation179 Fin3 refa151_inst.
Proof. unfold Equation179, magma_op, refa151_inst, refa151_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa151_sat845 : @Equation845 Fin3 refa151_inst.
Proof. unfold Equation845, magma_op, refa151_inst, refa151_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa151_sat916 : @Equation916 Fin3 refa151_inst.
Proof. unfold Equation916, magma_op, refa151_inst, refa151_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa151_sat1288 : @Equation1288 Fin3 refa151_inst.
Proof. unfold Equation1288, magma_op, refa151_inst, refa151_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa151_sat2063 : @Equation2063 Fin3 refa151_inst.
Proof. unfold Equation2063, magma_op, refa151_inst, refa151_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa151_not56 : ~ @Equation56 Fin3 refa151_inst.
Proof. unfold Equation56. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa151_inst, refa151_op in H. discriminate H. Qed.

Lemma refa151_not65 : ~ @Equation65 Fin3 refa151_inst.
Proof. unfold Equation65. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa151_inst, refa151_op in H. discriminate H. Qed.

Lemma refa151_not108 : ~ @Equation108 Fin3 refa151_inst.
Proof. unfold Equation108. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa151_inst, refa151_op in H. discriminate H. Qed.

Lemma refa151_not159 : ~ @Equation159 Fin3 refa151_inst.
Proof. unfold Equation159. intro H. specialize (H F3_1 F3_0). unfold magma_op, refa151_inst, refa151_op in H. discriminate H. Qed.

Lemma refa151_not160 : ~ @Equation160 Fin3 refa151_inst.
Proof. unfold Equation160. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa151_inst, refa151_op in H. discriminate H. Qed.

Lemma refa151_not206 : ~ @Equation206 Fin3 refa151_inst.
Proof. unfold Equation206. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa151_inst, refa151_op in H. discriminate H. Qed.

Lemma refa151_not209 : ~ @Equation209 Fin3 refa151_inst.
Proof. unfold Equation209. intro H. specialize (H F3_1 F3_0). unfold magma_op, refa151_inst, refa151_op in H. discriminate H. Qed.

Lemma refa151_not211 : ~ @Equation211 Fin3 refa151_inst.
Proof. unfold Equation211. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa151_inst, refa151_op in H. discriminate H. Qed.

Lemma refa151_not261 : ~ @Equation261 Fin3 refa151_inst.
Proof. unfold Equation261. intro H. specialize (H F3_1 F3_0). unfold magma_op, refa151_inst, refa151_op in H. discriminate H. Qed.

Lemma refa151_not263 : ~ @Equation263 Fin3 refa151_inst.
Proof. unfold Equation263. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa151_inst, refa151_op in H. discriminate H. Qed.

Lemma refa151_not264 : ~ @Equation264 Fin3 refa151_inst.
Proof. unfold Equation264. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa151_inst, refa151_op in H. discriminate H. Qed.

Lemma refa151_not323 : ~ @Equation323 Fin3 refa151_inst.
Proof. unfold Equation323. intro H. specialize (H F3_1 F3_0). unfold magma_op, refa151_inst, refa151_op in H. discriminate H. Qed.

Lemma refa151_not430 : ~ @Equation430 Fin3 refa151_inst.
Proof. unfold Equation430. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa151_inst, refa151_op in H. discriminate H. Qed.

Lemma refa151_not437 : ~ @Equation437 Fin3 refa151_inst.
Proof. unfold Equation437. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa151_inst, refa151_op in H. discriminate H. Qed.

Lemma refa151_not439 : ~ @Equation439 Fin3 refa151_inst.
Proof. unfold Equation439. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa151_inst, refa151_op in H. discriminate H. Qed.

Lemma refa151_not440 : ~ @Equation440 Fin3 refa151_inst.
Proof. unfold Equation440. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa151_inst, refa151_op in H. discriminate H. Qed.

Lemma refa151_not616 : ~ @Equation616 Fin3 refa151_inst.
Proof. unfold Equation616. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa151_inst, refa151_op in H. discriminate H. Qed.

Lemma refa151_not619 : ~ @Equation619 Fin3 refa151_inst.
Proof. unfold Equation619. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa151_inst, refa151_op in H. discriminate H. Qed.

Lemma refa151_not629 : ~ @Equation629 Fin3 refa151_inst.
Proof. unfold Equation629. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa151_inst, refa151_op in H. discriminate H. Qed.

Lemma refa151_not630 : ~ @Equation630 Fin3 refa151_inst.
Proof. unfold Equation630. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa151_inst, refa151_op in H. discriminate H. Qed.

Lemma refa151_not632 : ~ @Equation632 Fin3 refa151_inst.
Proof. unfold Equation632. intro H. specialize (H F3_1 F3_0). unfold magma_op, refa151_inst, refa151_op in H. discriminate H. Qed.

Lemma refa151_not633 : ~ @Equation633 Fin3 refa151_inst.
Proof. unfold Equation633. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa151_inst, refa151_op in H. discriminate H. Qed.

Lemma refa151_not639 : ~ @Equation639 Fin3 refa151_inst.
Proof. unfold Equation639. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa151_inst, refa151_op in H. discriminate H. Qed.

Lemma refa151_not640 : ~ @Equation640 Fin3 refa151_inst.
Proof. unfold Equation640. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa151_inst, refa151_op in H. discriminate H. Qed.

Lemma refa151_not643 : ~ @Equation643 Fin3 refa151_inst.
Proof. unfold Equation643. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa151_inst, refa151_op in H. discriminate H. Qed.

Lemma refa151_not669 : ~ @Equation669 Fin3 refa151_inst.
Proof. unfold Equation669. intro H. specialize (H F3_1 F3_0). unfold magma_op, refa151_inst, refa151_op in H. discriminate H. Qed.

Lemma refa151_not679 : ~ @Equation679 Fin3 refa151_inst.
Proof. unfold Equation679. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa151_inst, refa151_op in H. discriminate H. Qed.

Lemma refa151_not713 : ~ @Equation713 Fin3 refa151_inst.
Proof. unfold Equation713. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa151_inst, refa151_op in H. discriminate H. Qed.

Lemma refa151_not822 : ~ @Equation822 Fin3 refa151_inst.
Proof. unfold Equation822. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa151_inst, refa151_op in H. discriminate H. Qed.

Lemma refa151_not825 : ~ @Equation825 Fin3 refa151_inst.
Proof. unfold Equation825. intro H. specialize (H F3_1 F3_0). unfold magma_op, refa151_inst, refa151_op in H. discriminate H. Qed.

Lemma refa151_not832 : ~ @Equation832 Fin3 refa151_inst.
Proof. unfold Equation832. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa151_inst, refa151_op in H. discriminate H. Qed.

Lemma refa151_not835 : ~ @Equation835 Fin3 refa151_inst.
Proof. unfold Equation835. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa151_inst, refa151_op in H. discriminate H. Qed.

Lemma refa151_not842 : ~ @Equation842 Fin3 refa151_inst.
Proof. unfold Equation842. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa151_inst, refa151_op in H. discriminate H. Qed.

Lemma refa151_not843 : ~ @Equation843 Fin3 refa151_inst.
Proof. unfold Equation843. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa151_inst, refa151_op in H. discriminate H. Qed.

Lemma refa151_not846 : ~ @Equation846 Fin3 refa151_inst.
Proof. unfold Equation846. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa151_inst, refa151_op in H. discriminate H. Qed.

Lemma refa151_not872 : ~ @Equation872 Fin3 refa151_inst.
Proof. unfold Equation872. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa151_inst, refa151_op in H. discriminate H. Qed.

Lemma refa151_not879 : ~ @Equation879 Fin3 refa151_inst.
Proof. unfold Equation879. intro H. specialize (H F3_1 F3_0). unfold magma_op, refa151_inst, refa151_op in H. discriminate H. Qed.

Lemma refa151_not1039 : ~ @Equation1039 Fin3 refa151_inst.
Proof. unfold Equation1039. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa151_inst, refa151_op in H. discriminate H. Qed.

Lemma refa151_not1049 : ~ @Equation1049 Fin3 refa151_inst.
Proof. unfold Equation1049. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa151_inst, refa151_op in H. discriminate H. Qed.

Lemma refa151_not1238 : ~ @Equation1238 Fin3 refa151_inst.
Proof. unfold Equation1238. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa151_inst, refa151_op in H. discriminate H. Qed.

Lemma refa151_not1252 : ~ @Equation1252 Fin3 refa151_inst.
Proof. unfold Equation1252. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa151_inst, refa151_op in H. discriminate H. Qed.

Lemma refa151_not1278 : ~ @Equation1278 Fin3 refa151_inst.
Proof. unfold Equation1278. intro H. specialize (H F3_1 F3_0). unfold magma_op, refa151_inst, refa151_op in H. discriminate H. Qed.

Lemma refa151_not1432 : ~ @Equation1432 Fin3 refa151_inst.
Proof. unfold Equation1432. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa151_inst, refa151_op in H. discriminate H. Qed.

Lemma refa151_not1435 : ~ @Equation1435 Fin3 refa151_inst.
Proof. unfold Equation1435. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa151_inst, refa151_op in H. discriminate H. Qed.

Lemma refa151_not1437 : ~ @Equation1437 Fin3 refa151_inst.
Proof. unfold Equation1437. intro H. specialize (H F3_0 F3_0 F3_1). unfold magma_op, refa151_inst, refa151_op in H. discriminate H. Qed.

Lemma refa151_not1441 : ~ @Equation1441 Fin3 refa151_inst.
Proof. unfold Equation1441. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa151_inst, refa151_op in H. discriminate H. Qed.

Lemma refa151_not1444 : ~ @Equation1444 Fin3 refa151_inst.
Proof. unfold Equation1444. intro H. specialize (H F3_1 F3_0). unfold magma_op, refa151_inst, refa151_op in H. discriminate H. Qed.

Lemma refa151_not1445 : ~ @Equation1445 Fin3 refa151_inst.
Proof. unfold Equation1445. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa151_inst, refa151_op in H. discriminate H. Qed.

Lemma refa151_not1451 : ~ @Equation1451 Fin3 refa151_inst.
Proof. unfold Equation1451. intro H. specialize (H F3_1 F3_0). unfold magma_op, refa151_inst, refa151_op in H. discriminate H. Qed.

Lemma refa151_not1454 : ~ @Equation1454 Fin3 refa151_inst.
Proof. unfold Equation1454. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa151_inst, refa151_op in H. discriminate H. Qed.

Lemma refa151_not1478 : ~ @Equation1478 Fin3 refa151_inst.
Proof. unfold Equation1478. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa151_inst, refa151_op in H. discriminate H. Qed.

Lemma refa151_not1491 : ~ @Equation1491 Fin3 refa151_inst.
Proof. unfold Equation1491. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa151_inst, refa151_op in H. discriminate H. Qed.

Lemma refa151_not1518 : ~ @Equation1518 Fin3 refa151_inst.
Proof. unfold Equation1518. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa151_inst, refa151_op in H. discriminate H. Qed.

Lemma refa151_not1638 : ~ @Equation1638 Fin3 refa151_inst.
Proof. unfold Equation1638. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa151_inst, refa151_op in H. discriminate H. Qed.

Lemma refa151_not1644 : ~ @Equation1644 Fin3 refa151_inst.
Proof. unfold Equation1644. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa151_inst, refa151_op in H. discriminate H. Qed.

Lemma refa151_not1648 : ~ @Equation1648 Fin3 refa151_inst.
Proof. unfold Equation1648. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa151_inst, refa151_op in H. discriminate H. Qed.

Lemma refa151_not1655 : ~ @Equation1655 Fin3 refa151_inst.
Proof. unfold Equation1655. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa151_inst, refa151_op in H. discriminate H. Qed.

Lemma refa151_not1657 : ~ @Equation1657 Fin3 refa151_inst.
Proof. unfold Equation1657. intro H. specialize (H F3_1 F3_0). unfold magma_op, refa151_inst, refa151_op in H. discriminate H. Qed.

Lemma refa151_not1841 : ~ @Equation1841 Fin3 refa151_inst.
Proof. unfold Equation1841. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa151_inst, refa151_op in H. discriminate H. Qed.

Lemma refa151_not1851 : ~ @Equation1851 Fin3 refa151_inst.
Proof. unfold Equation1851. intro H. specialize (H F3_1 F3_0). unfold magma_op, refa151_inst, refa151_op in H. discriminate H. Qed.

Lemma refa151_not1858 : ~ @Equation1858 Fin3 refa151_inst.
Proof. unfold Equation1858. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa151_inst, refa151_op in H. discriminate H. Qed.

Lemma refa151_not1860 : ~ @Equation1860 Fin3 refa151_inst.
Proof. unfold Equation1860. intro H. specialize (H F3_1 F3_0). unfold magma_op, refa151_inst, refa151_op in H. discriminate H. Qed.

Lemma refa151_not1876 : ~ @Equation1876 Fin3 refa151_inst.
Proof. unfold Equation1876. intro H. specialize (H F3_0 F3_1 F3_1). unfold magma_op, refa151_inst, refa151_op in H. discriminate H. Qed.

Lemma refa151_not2038 : ~ @Equation2038 Fin3 refa151_inst.
Proof. unfold Equation2038. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa151_inst, refa151_op in H. discriminate H. Qed.

Lemma refa151_not2040 : ~ @Equation2040 Fin3 refa151_inst.
Proof. unfold Equation2040. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa151_inst, refa151_op in H. discriminate H. Qed.

Lemma refa151_not2041 : ~ @Equation2041 Fin3 refa151_inst.
Proof. unfold Equation2041. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa151_inst, refa151_op in H. discriminate H. Qed.

Lemma refa151_not2043 : ~ @Equation2043 Fin3 refa151_inst.
Proof. unfold Equation2043. intro H. specialize (H F3_1 F3_0). unfold magma_op, refa151_inst, refa151_op in H. discriminate H. Qed.

Lemma refa151_not2044 : ~ @Equation2044 Fin3 refa151_inst.
Proof. unfold Equation2044. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa151_inst, refa151_op in H. discriminate H. Qed.

Lemma refa151_not2050 : ~ @Equation2050 Fin3 refa151_inst.
Proof. unfold Equation2050. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa151_inst, refa151_op in H. discriminate H. Qed.

Lemma refa151_not2053 : ~ @Equation2053 Fin3 refa151_inst.
Proof. unfold Equation2053. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa151_inst, refa151_op in H. discriminate H. Qed.

Lemma refa151_not2054 : ~ @Equation2054 Fin3 refa151_inst.
Proof. unfold Equation2054. intro H. specialize (H F3_1 F3_0). unfold magma_op, refa151_inst, refa151_op in H. discriminate H. Qed.

Lemma refa151_not2060 : ~ @Equation2060 Fin3 refa151_inst.
Proof. unfold Equation2060. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa151_inst, refa151_op in H. discriminate H. Qed.

Lemma refa151_not2061 : ~ @Equation2061 Fin3 refa151_inst.
Proof. unfold Equation2061. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa151_inst, refa151_op in H. discriminate H. Qed.

Lemma refa151_not2064 : ~ @Equation2064 Fin3 refa151_inst.
Proof. unfold Equation2064. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa151_inst, refa151_op in H. discriminate H. Qed.

Lemma refa151_not2087 : ~ @Equation2087 Fin3 refa151_inst.
Proof. unfold Equation2087. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa151_inst, refa151_op in H. discriminate H. Qed.

Lemma refa151_not2100 : ~ @Equation2100 Fin3 refa151_inst.
Proof. unfold Equation2100. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa151_inst, refa151_op in H. discriminate H. Qed.

Lemma refa151_not2124 : ~ @Equation2124 Fin3 refa151_inst.
Proof. unfold Equation2124. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa151_inst, refa151_op in H. discriminate H. Qed.

Lemma refa151_not2241 : ~ @Equation2241 Fin3 refa151_inst.
Proof. unfold Equation2241. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa151_inst, refa151_op in H. discriminate H. Qed.

Lemma refa151_not2244 : ~ @Equation2244 Fin3 refa151_inst.
Proof. unfold Equation2244. intro H. specialize (H F3_1 F3_0). unfold magma_op, refa151_inst, refa151_op in H. discriminate H. Qed.

Lemma refa151_not2247 : ~ @Equation2247 Fin3 refa151_inst.
Proof. unfold Equation2247. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa151_inst, refa151_op in H. discriminate H. Qed.

Lemma refa151_not2254 : ~ @Equation2254 Fin3 refa151_inst.
Proof. unfold Equation2254. intro H. specialize (H F3_1 F3_0). unfold magma_op, refa151_inst, refa151_op in H. discriminate H. Qed.

Lemma refa151_not2256 : ~ @Equation2256 Fin3 refa151_inst.
Proof. unfold Equation2256. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa151_inst, refa151_op in H. discriminate H. Qed.

Lemma refa151_not2257 : ~ @Equation2257 Fin3 refa151_inst.
Proof. unfold Equation2257. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa151_inst, refa151_op in H. discriminate H. Qed.

Lemma refa151_not2264 : ~ @Equation2264 Fin3 refa151_inst.
Proof. unfold Equation2264. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa151_inst, refa151_op in H. discriminate H. Qed.

Lemma refa151_not2266 : ~ @Equation2266 Fin3 refa151_inst.
Proof. unfold Equation2266. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa151_inst, refa151_op in H. discriminate H. Qed.

Lemma refa151_not2267 : ~ @Equation2267 Fin3 refa151_inst.
Proof. unfold Equation2267. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa151_inst, refa151_op in H. discriminate H. Qed.

Lemma refa151_not2273 : ~ @Equation2273 Fin3 refa151_inst.
Proof. unfold Equation2273. intro H. specialize (H F3_0 F3_0 F3_1). unfold magma_op, refa151_inst, refa151_op in H. discriminate H. Qed.

Lemma refa151_not2447 : ~ @Equation2447 Fin3 refa151_inst.
Proof. unfold Equation2447. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa151_inst, refa151_op in H. discriminate H. Qed.

Lemma refa151_not2450 : ~ @Equation2450 Fin3 refa151_inst.
Proof. unfold Equation2450. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa151_inst, refa151_op in H. discriminate H. Qed.

Lemma refa151_not2460 : ~ @Equation2460 Fin3 refa151_inst.
Proof. unfold Equation2460. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa151_inst, refa151_op in H. discriminate H. Qed.

Lemma refa151_not2467 : ~ @Equation2467 Fin3 refa151_inst.
Proof. unfold Equation2467. intro H. specialize (H F3_1 F3_0). unfold magma_op, refa151_inst, refa151_op in H. discriminate H. Qed.

Lemma refa151_not2469 : ~ @Equation2469 Fin3 refa151_inst.
Proof. unfold Equation2469. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa151_inst, refa151_op in H. discriminate H. Qed.

Lemma refa151_not2650 : ~ @Equation2650 Fin3 refa151_inst.
Proof. unfold Equation2650. intro H. specialize (H F3_1 F3_0). unfold magma_op, refa151_inst, refa151_op in H. discriminate H. Qed.

Lemma refa151_not2659 : ~ @Equation2659 Fin3 refa151_inst.
Proof. unfold Equation2659. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa151_inst, refa151_op in H. discriminate H. Qed.

Lemma refa151_not2660 : ~ @Equation2660 Fin3 refa151_inst.
Proof. unfold Equation2660. intro H. specialize (H F3_1 F3_0). unfold magma_op, refa151_inst, refa151_op in H. discriminate H. Qed.

Lemma refa151_not2672 : ~ @Equation2672 Fin3 refa151_inst.
Proof. unfold Equation2672. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa151_inst, refa151_op in H. discriminate H. Qed.

Lemma refa151_not2849 : ~ @Equation2849 Fin3 refa151_inst.
Proof. unfold Equation2849. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa151_inst, refa151_op in H. discriminate H. Qed.

Lemma refa151_not2853 : ~ @Equation2853 Fin3 refa151_inst.
Proof. unfold Equation2853. intro H. specialize (H F3_1 F3_0). unfold magma_op, refa151_inst, refa151_op in H. discriminate H. Qed.

Lemma refa151_not2855 : ~ @Equation2855 Fin3 refa151_inst.
Proof. unfold Equation2855. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa151_inst, refa151_op in H. discriminate H. Qed.

Lemma refa151_not2856 : ~ @Equation2856 Fin3 refa151_inst.
Proof. unfold Equation2856. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa151_inst, refa151_op in H. discriminate H. Qed.

Lemma refa151_not2863 : ~ @Equation2863 Fin3 refa151_inst.
Proof. unfold Equation2863. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa151_inst, refa151_op in H. discriminate H. Qed.

Lemma refa151_not2865 : ~ @Equation2865 Fin3 refa151_inst.
Proof. unfold Equation2865. intro H. specialize (H F3_1 F3_0). unfold magma_op, refa151_inst, refa151_op in H. discriminate H. Qed.

Lemma refa151_not2866 : ~ @Equation2866 Fin3 refa151_inst.
Proof. unfold Equation2866. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa151_inst, refa151_op in H. discriminate H. Qed.

Lemma refa151_not2872 : ~ @Equation2872 Fin3 refa151_inst.
Proof. unfold Equation2872. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa151_inst, refa151_op in H. discriminate H. Qed.

Lemma refa151_not2873 : ~ @Equation2873 Fin3 refa151_inst.
Proof. unfold Equation2873. intro H. specialize (H F3_1 F3_0). unfold magma_op, refa151_inst, refa151_op in H. discriminate H. Qed.

Lemma refa151_not2875 : ~ @Equation2875 Fin3 refa151_inst.
Proof. unfold Equation2875. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa151_inst, refa151_op in H. discriminate H. Qed.

Lemma refa151_not3052 : ~ @Equation3052 Fin3 refa151_inst.
Proof. unfold Equation3052. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa151_inst, refa151_op in H. discriminate H. Qed.

Lemma refa151_not3055 : ~ @Equation3055 Fin3 refa151_inst.
Proof. unfold Equation3055. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa151_inst, refa151_op in H. discriminate H. Qed.

Lemma refa151_not3056 : ~ @Equation3056 Fin3 refa151_inst.
Proof. unfold Equation3056. intro H. specialize (H F3_1 F3_0). unfold magma_op, refa151_inst, refa151_op in H. discriminate H. Qed.

Lemma refa151_not3065 : ~ @Equation3065 Fin3 refa151_inst.
Proof. unfold Equation3065. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa151_inst, refa151_op in H. discriminate H. Qed.

Lemma refa151_not3069 : ~ @Equation3069 Fin3 refa151_inst.
Proof. unfold Equation3069. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa151_inst, refa151_op in H. discriminate H. Qed.

Lemma refa151_not3076 : ~ @Equation3076 Fin3 refa151_inst.
Proof. unfold Equation3076. intro H. specialize (H F3_1 F3_0). unfold magma_op, refa151_inst, refa151_op in H. discriminate H. Qed.

Lemma refa151_not3078 : ~ @Equation3078 Fin3 refa151_inst.
Proof. unfold Equation3078. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa151_inst, refa151_op in H. discriminate H. Qed.

Lemma refa151_not3259 : ~ @Equation3259 Fin3 refa151_inst.
Proof. unfold Equation3259. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa151_inst, refa151_op in H. discriminate H. Qed.

Lemma refa151_not3262 : ~ @Equation3262 Fin3 refa151_inst.
Proof. unfold Equation3262. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa151_inst, refa151_op in H. discriminate H. Qed.

Lemma refa151_not3279 : ~ @Equation3279 Fin3 refa151_inst.
Proof. unfold Equation3279. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa151_inst, refa151_op in H. discriminate H. Qed.

Lemma refa151_not3308 : ~ @Equation3308 Fin3 refa151_inst.
Proof. unfold Equation3308. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa151_inst, refa151_op in H. discriminate H. Qed.

Lemma refa151_not3465 : ~ @Equation3465 Fin3 refa151_inst.
Proof. unfold Equation3465. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa151_inst, refa151_op in H. discriminate H. Qed.

Lemma refa151_not3511 : ~ @Equation3511 Fin3 refa151_inst.
Proof. unfold Equation3511. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa151_inst, refa151_op in H. discriminate H. Qed.

Lemma refa151_not3512 : ~ @Equation3512 Fin3 refa151_inst.
Proof. unfold Equation3512. intro H. specialize (H F3_1 F3_0). unfold magma_op, refa151_inst, refa151_op in H. discriminate H. Qed.

Lemma refa151_not3529 : ~ @Equation3529 Fin3 refa151_inst.
Proof. unfold Equation3529. intro H. specialize (H F3_0 F3_0 F3_1). unfold magma_op, refa151_inst, refa151_op in H. discriminate H. Qed.

Lemma refa151_not3663 : ~ @Equation3663 Fin3 refa151_inst.
Proof. unfold Equation3663. intro H. specialize (H F3_0 F3_0 F3_1). unfold magma_op, refa151_inst, refa151_op in H. discriminate H. Qed.

Lemma refa151_not3664 : ~ @Equation3664 Fin3 refa151_inst.
Proof. unfold Equation3664. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa151_inst, refa151_op in H. discriminate H. Qed.

Lemma refa151_not3667 : ~ @Equation3667 Fin3 refa151_inst.
Proof. unfold Equation3667. intro H. specialize (H F3_1 F3_0). unfold magma_op, refa151_inst, refa151_op in H. discriminate H. Qed.

Lemma refa151_not3668 : ~ @Equation3668 Fin3 refa151_inst.
Proof. unfold Equation3668. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa151_inst, refa151_op in H. discriminate H. Qed.

Lemma refa151_not3685 : ~ @Equation3685 Fin3 refa151_inst.
Proof. unfold Equation3685. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa151_inst, refa151_op in H. discriminate H. Qed.

Lemma refa151_not3728 : ~ @Equation3728 Fin3 refa151_inst.
Proof. unfold Equation3728. intro H. specialize (H F3_0 F3_0 F3_1). unfold magma_op, refa151_inst, refa151_op in H. discriminate H. Qed.

Lemma refa151_not3729 : ~ @Equation3729 Fin3 refa151_inst.
Proof. unfold Equation3729. intro H. specialize (H F3_0 F3_0 F3_1). unfold magma_op, refa151_inst, refa151_op in H. discriminate H. Qed.

Lemma refa151_not3865 : ~ @Equation3865 Fin3 refa151_inst.
Proof. unfold Equation3865. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa151_inst, refa151_op in H. discriminate H. Qed.

Lemma refa151_not3867 : ~ @Equation3867 Fin3 refa151_inst.
Proof. unfold Equation3867. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa151_inst, refa151_op in H. discriminate H. Qed.

Lemma refa151_not3868 : ~ @Equation3868 Fin3 refa151_inst.
Proof. unfold Equation3868. intro H. specialize (H F3_1 F3_0). unfold magma_op, refa151_inst, refa151_op in H. discriminate H. Qed.

Lemma refa151_not3870 : ~ @Equation3870 Fin3 refa151_inst.
Proof. unfold Equation3870. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa151_inst, refa151_op in H. discriminate H. Qed.

Lemma refa151_not3871 : ~ @Equation3871 Fin3 refa151_inst.
Proof. unfold Equation3871. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa151_inst, refa151_op in H. discriminate H. Qed.

Lemma refa151_not3877 : ~ @Equation3877 Fin3 refa151_inst.
Proof. unfold Equation3877. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa151_inst, refa151_op in H. discriminate H. Qed.

Lemma refa151_not3880 : ~ @Equation3880 Fin3 refa151_inst.
Proof. unfold Equation3880. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa151_inst, refa151_op in H. discriminate H. Qed.

Lemma refa151_not3881 : ~ @Equation3881 Fin3 refa151_inst.
Proof. unfold Equation3881. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa151_inst, refa151_op in H. discriminate H. Qed.

Lemma refa151_not3888 : ~ @Equation3888 Fin3 refa151_inst.
Proof. unfold Equation3888. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa151_inst, refa151_op in H. discriminate H. Qed.

Lemma refa151_not3917 : ~ @Equation3917 Fin3 refa151_inst.
Proof. unfold Equation3917. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa151_inst, refa151_op in H. discriminate H. Qed.

Lemma refa151_not3925 : ~ @Equation3925 Fin3 refa151_inst.
Proof. unfold Equation3925. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa151_inst, refa151_op in H. discriminate H. Qed.

Lemma refa151_not3952 : ~ @Equation3952 Fin3 refa151_inst.
Proof. unfold Equation3952. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa151_inst, refa151_op in H. discriminate H. Qed.

Lemma refa151_not3955 : ~ @Equation3955 Fin3 refa151_inst.
Proof. unfold Equation3955. intro H. specialize (H F3_1 F3_0). unfold magma_op, refa151_inst, refa151_op in H. discriminate H. Qed.

Lemma refa151_not4066 : ~ @Equation4066 Fin3 refa151_inst.
Proof. unfold Equation4066. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa151_inst, refa151_op in H. discriminate H. Qed.

Lemma refa151_not4067 : ~ @Equation4067 Fin3 refa151_inst.
Proof. unfold Equation4067. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa151_inst, refa151_op in H. discriminate H. Qed.

Lemma refa151_not4068 : ~ @Equation4068 Fin3 refa151_inst.
Proof. unfold Equation4068. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa151_inst, refa151_op in H. discriminate H. Qed.

Lemma refa151_not4070 : ~ @Equation4070 Fin3 refa151_inst.
Proof. unfold Equation4070. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa151_inst, refa151_op in H. discriminate H. Qed.

Lemma refa151_not4071 : ~ @Equation4071 Fin3 refa151_inst.
Proof. unfold Equation4071. intro H. specialize (H F3_1 F3_0). unfold magma_op, refa151_inst, refa151_op in H. discriminate H. Qed.

Lemma refa151_not4073 : ~ @Equation4073 Fin3 refa151_inst.
Proof. unfold Equation4073. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa151_inst, refa151_op in H. discriminate H. Qed.

Lemma refa151_not4074 : ~ @Equation4074 Fin3 refa151_inst.
Proof. unfold Equation4074. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa151_inst, refa151_op in H. discriminate H. Qed.

Lemma refa151_not4080 : ~ @Equation4080 Fin3 refa151_inst.
Proof. unfold Equation4080. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa151_inst, refa151_op in H. discriminate H. Qed.

Lemma refa151_not4083 : ~ @Equation4083 Fin3 refa151_inst.
Proof. unfold Equation4083. intro H. specialize (H F3_1 F3_0). unfold magma_op, refa151_inst, refa151_op in H. discriminate H. Qed.

Lemma refa151_not4090 : ~ @Equation4090 Fin3 refa151_inst.
Proof. unfold Equation4090. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa151_inst, refa151_op in H. discriminate H. Qed.

Lemma refa151_not4128 : ~ @Equation4128 Fin3 refa151_inst.
Proof. unfold Equation4128. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa151_inst, refa151_op in H. discriminate H. Qed.

Lemma refa151_not4131 : ~ @Equation4131 Fin3 refa151_inst.
Proof. unfold Equation4131. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa151_inst, refa151_op in H. discriminate H. Qed.

Lemma refa151_not4158 : ~ @Equation4158 Fin3 refa151_inst.
Proof. unfold Equation4158. intro H. specialize (H F3_1 F3_0). unfold magma_op, refa151_inst, refa151_op in H. discriminate H. Qed.

Lemma refa151_not4165 : ~ @Equation4165 Fin3 refa151_inst.
Proof. unfold Equation4165. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa151_inst, refa151_op in H. discriminate H. Qed.

Lemma refa151_not4284 : ~ @Equation4284 Fin3 refa151_inst.
Proof. unfold Equation4284. intro H. specialize (H F3_1 F3_0). unfold magma_op, refa151_inst, refa151_op in H. discriminate H. Qed.

Lemma refa151_not4318 : ~ @Equation4318 Fin3 refa151_inst.
Proof. unfold Equation4318. intro H. specialize (H F3_0 F3_0 F3_1). unfold magma_op, refa151_inst, refa151_op in H. discriminate H. Qed.

Lemma refa151_not4320 : ~ @Equation4320 Fin3 refa151_inst.
Proof. unfold Equation4320. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa151_inst, refa151_op in H. discriminate H. Qed.

Lemma refa151_not4358 : ~ @Equation4358 Fin3 refa151_inst.
Proof. unfold Equation4358. intro H. specialize (H F3_0 F3_0 F3_1). unfold magma_op, refa151_inst, refa151_op in H. discriminate H. Qed.

Lemma refa151_not4396 : ~ @Equation4396 Fin3 refa151_inst.
Proof. unfold Equation4396. intro H. specialize (H F3_1 F3_0). unfold magma_op, refa151_inst, refa151_op in H. discriminate H. Qed.

Lemma refa151_not4398 : ~ @Equation4398 Fin3 refa151_inst.
Proof. unfold Equation4398. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa151_inst, refa151_op in H. discriminate H. Qed.

Lemma refa151_not4399 : ~ @Equation4399 Fin3 refa151_inst.
Proof. unfold Equation4399. intro H. specialize (H F3_1 F3_0). unfold magma_op, refa151_inst, refa151_op in H. discriminate H. Qed.

Lemma refa151_not4469 : ~ @Equation4469 Fin3 refa151_inst.
Proof. unfold Equation4469. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa151_inst, refa151_op in H. discriminate H. Qed.

Lemma refa151_not4583 : ~ @Equation4583 Fin3 refa151_inst.
Proof. unfold Equation4583. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa151_inst, refa151_op in H. discriminate H. Qed.

Lemma refa151_not4584 : ~ @Equation4584 Fin3 refa151_inst.
Proof. unfold Equation4584. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa151_inst, refa151_op in H. discriminate H. Qed.

Lemma refa151_not4585 : ~ @Equation4585 Fin3 refa151_inst.
Proof. unfold Equation4585. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa151_inst, refa151_op in H. discriminate H. Qed.

Lemma refa151_not4587 : ~ @Equation4587 Fin3 refa151_inst.
Proof. unfold Equation4587. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa151_inst, refa151_op in H. discriminate H. Qed.

Lemma refa151_not4606 : ~ @Equation4606 Fin3 refa151_inst.
Proof. unfold Equation4606. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa151_inst, refa151_op in H. discriminate H. Qed.

Lemma refa151_not4635 : ~ @Equation4635 Fin3 refa151_inst.
Proof. unfold Equation4635. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa151_inst, refa151_op in H. discriminate H. Qed.

(** ---- refa152 (Fin3) ---- *)

Definition refa152_op (x y : Fin3) : Fin3 :=
  match x, y with
  | F3_0, F3_0 => F3_0 | F3_0, F3_1 => F3_0 | F3_0, F3_2 => F3_0
  | F3_1, F3_0 => F3_1 | F3_1, F3_1 => F3_0 | F3_1, F3_2 => F3_1
  | F3_2, F3_0 => F3_2 | F3_2, F3_1 => F3_1 | F3_2, F3_2 => F3_1
  end.

#[local] Instance refa152_inst : Magma Fin3 := {| magma_op := refa152_op |}.

Lemma refa152_sat843 : @Equation843 Fin3 refa152_inst.
Proof. unfold Equation843, magma_op, refa152_inst, refa152_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa152_not1020 : ~ @Equation1020 Fin3 refa152_inst.
Proof. unfold Equation1020. intro H. specialize (H F3_2). unfold magma_op, refa152_inst, refa152_op in H. discriminate H. Qed.

(** ---- refa153 (Fin3) ---- *)

Definition refa153_op (x y : Fin3) : Fin3 :=
  match x, y with
  | F3_0, F3_0 => F3_0 | F3_0, F3_1 => F3_0 | F3_0, F3_2 => F3_0
  | F3_1, F3_0 => F3_0 | F3_1, F3_1 => F3_0 | F3_1, F3_2 => F3_0
  | F3_2, F3_0 => F3_0 | F3_2, F3_1 => F3_1 | F3_2, F3_2 => F3_0
  end.

#[local] Instance refa153_inst : Magma Fin3 := {| magma_op := refa153_op |}.

Lemma refa153_sat366 : @Equation366 Fin3 refa153_inst.
Proof. unfold Equation366, magma_op, refa153_inst, refa153_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa153_sat3480 : @Equation3480 Fin3 refa153_inst.
Proof. unfold Equation3480, magma_op, refa153_inst, refa153_op. intros x y z w. destruct x, y, z, w; reflexivity. Qed.

Lemma refa153_sat4444 : @Equation4444 Fin3 refa153_inst.
Proof. unfold Equation4444, magma_op, refa153_inst, refa153_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa153_sat4481 : @Equation4481 Fin3 refa153_inst.
Proof. unfold Equation4481, magma_op, refa153_inst, refa153_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa153_not3254 : ~ @Equation3254 Fin3 refa153_inst.
Proof. unfold Equation3254. intro H. specialize (H F3_2 F3_1). unfold magma_op, refa153_inst, refa153_op in H. discriminate H. Qed.

Lemma refa153_not3281 : ~ @Equation3281 Fin3 refa153_inst.
Proof. unfold Equation3281. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa153_inst, refa153_op in H. discriminate H. Qed.

Lemma refa153_not3308 : ~ @Equation3308 Fin3 refa153_inst.
Proof. unfold Equation3308. intro H. specialize (H F3_2 F3_1). unfold magma_op, refa153_inst, refa153_op in H. discriminate H. Qed.

Lemma refa153_not3309 : ~ @Equation3309 Fin3 refa153_inst.
Proof. unfold Equation3309. intro H. specialize (H F3_2 F3_1). unfold magma_op, refa153_inst, refa153_op in H. discriminate H. Qed.

Lemma refa153_not3315 : ~ @Equation3315 Fin3 refa153_inst.
Proof. unfold Equation3315. intro H. specialize (H F3_2 F3_1). unfold magma_op, refa153_inst, refa153_op in H. discriminate H. Qed.

Lemma refa153_not3316 : ~ @Equation3316 Fin3 refa153_inst.
Proof. unfold Equation3316. intro H. specialize (H F3_2 F3_1). unfold magma_op, refa153_inst, refa153_op in H. discriminate H. Qed.

Lemma refa153_not3318 : ~ @Equation3318 Fin3 refa153_inst.
Proof. unfold Equation3318. intro H. specialize (H F3_2 F3_1). unfold magma_op, refa153_inst, refa153_op in H. discriminate H. Qed.

Lemma refa153_not3319 : ~ @Equation3319 Fin3 refa153_inst.
Proof. unfold Equation3319. intro H. specialize (H F3_2 F3_1). unfold magma_op, refa153_inst, refa153_op in H. discriminate H. Qed.

Lemma refa153_not3342 : ~ @Equation3342 Fin3 refa153_inst.
Proof. unfold Equation3342. intro H. specialize (H F3_2 F3_1). unfold magma_op, refa153_inst, refa153_op in H. discriminate H. Qed.

Lemma refa153_not3343 : ~ @Equation3343 Fin3 refa153_inst.
Proof. unfold Equation3343. intro H. specialize (H F3_2 F3_1). unfold magma_op, refa153_inst, refa153_op in H. discriminate H. Qed.

Lemma refa153_not3345 : ~ @Equation3345 Fin3 refa153_inst.
Proof. unfold Equation3345. intro H. specialize (H F3_2 F3_1). unfold magma_op, refa153_inst, refa153_op in H. discriminate H. Qed.

Lemma refa153_not3346 : ~ @Equation3346 Fin3 refa153_inst.
Proof. unfold Equation3346. intro H. specialize (H F3_2 F3_1). unfold magma_op, refa153_inst, refa153_op in H. discriminate H. Qed.

Lemma refa153_not3352 : ~ @Equation3352 Fin3 refa153_inst.
Proof. unfold Equation3352. intro H. specialize (H F3_2 F3_1). unfold magma_op, refa153_inst, refa153_op in H. discriminate H. Qed.

Lemma refa153_not3353 : ~ @Equation3353 Fin3 refa153_inst.
Proof. unfold Equation3353. intro H. specialize (H F3_2 F3_1). unfold magma_op, refa153_inst, refa153_op in H. discriminate H. Qed.

Lemma refa153_not3355 : ~ @Equation3355 Fin3 refa153_inst.
Proof. unfold Equation3355. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa153_inst, refa153_op in H. discriminate H. Qed.

Lemma refa153_not3509 : ~ @Equation3509 Fin3 refa153_inst.
Proof. unfold Equation3509. intro H. specialize (H F3_2 F3_1). unfold magma_op, refa153_inst, refa153_op in H. discriminate H. Qed.

Lemma refa153_not3511 : ~ @Equation3511 Fin3 refa153_inst.
Proof. unfold Equation3511. intro H. specialize (H F3_2 F3_1). unfold magma_op, refa153_inst, refa153_op in H. discriminate H. Qed.

Lemma refa153_not3512 : ~ @Equation3512 Fin3 refa153_inst.
Proof. unfold Equation3512. intro H. specialize (H F3_2 F3_1). unfold magma_op, refa153_inst, refa153_op in H. discriminate H. Qed.

Lemma refa153_not3518 : ~ @Equation3518 Fin3 refa153_inst.
Proof. unfold Equation3518. intro H. specialize (H F3_2 F3_1). unfold magma_op, refa153_inst, refa153_op in H. discriminate H. Qed.

Lemma refa153_not3519 : ~ @Equation3519 Fin3 refa153_inst.
Proof. unfold Equation3519. intro H. specialize (H F3_2 F3_1). unfold magma_op, refa153_inst, refa153_op in H. discriminate H. Qed.

Lemma refa153_not3521 : ~ @Equation3521 Fin3 refa153_inst.
Proof. unfold Equation3521. intro H. specialize (H F3_2 F3_1). unfold magma_op, refa153_inst, refa153_op in H. discriminate H. Qed.

Lemma refa153_not3522 : ~ @Equation3522 Fin3 refa153_inst.
Proof. unfold Equation3522. intro H. specialize (H F3_2 F3_1). unfold magma_op, refa153_inst, refa153_op in H. discriminate H. Qed.

Lemma refa153_not3545 : ~ @Equation3545 Fin3 refa153_inst.
Proof. unfold Equation3545. intro H. specialize (H F3_2 F3_1). unfold magma_op, refa153_inst, refa153_op in H. discriminate H. Qed.

Lemma refa153_not3546 : ~ @Equation3546 Fin3 refa153_inst.
Proof. unfold Equation3546. intro H. specialize (H F3_2 F3_1). unfold magma_op, refa153_inst, refa153_op in H. discriminate H. Qed.

Lemma refa153_not3548 : ~ @Equation3548 Fin3 refa153_inst.
Proof. unfold Equation3548. intro H. specialize (H F3_2 F3_1). unfold magma_op, refa153_inst, refa153_op in H. discriminate H. Qed.

Lemma refa153_not3549 : ~ @Equation3549 Fin3 refa153_inst.
Proof. unfold Equation3549. intro H. specialize (H F3_2 F3_1). unfold magma_op, refa153_inst, refa153_op in H. discriminate H. Qed.

Lemma refa153_not3555 : ~ @Equation3555 Fin3 refa153_inst.
Proof. unfold Equation3555. intro H. specialize (H F3_2 F3_1). unfold magma_op, refa153_inst, refa153_op in H. discriminate H. Qed.

Lemma refa153_not3556 : ~ @Equation3556 Fin3 refa153_inst.
Proof. unfold Equation3556. intro H. specialize (H F3_2 F3_1). unfold magma_op, refa153_inst, refa153_op in H. discriminate H. Qed.

Lemma refa153_not3558 : ~ @Equation3558 Fin3 refa153_inst.
Proof. unfold Equation3558. intro H. specialize (H F3_2 F3_1). unfold magma_op, refa153_inst, refa153_op in H. discriminate H. Qed.

Lemma refa153_not3712 : ~ @Equation3712 Fin3 refa153_inst.
Proof. unfold Equation3712. intro H. specialize (H F3_2 F3_1). unfold magma_op, refa153_inst, refa153_op in H. discriminate H. Qed.

Lemma refa153_not3714 : ~ @Equation3714 Fin3 refa153_inst.
Proof. unfold Equation3714. intro H. specialize (H F3_2 F3_1). unfold magma_op, refa153_inst, refa153_op in H. discriminate H. Qed.

Lemma refa153_not3721 : ~ @Equation3721 Fin3 refa153_inst.
Proof. unfold Equation3721. intro H. specialize (H F3_2 F3_1). unfold magma_op, refa153_inst, refa153_op in H. discriminate H. Qed.

Lemma refa153_not3722 : ~ @Equation3722 Fin3 refa153_inst.
Proof. unfold Equation3722. intro H. specialize (H F3_2 F3_1). unfold magma_op, refa153_inst, refa153_op in H. discriminate H. Qed.

Lemma refa153_not3724 : ~ @Equation3724 Fin3 refa153_inst.
Proof. unfold Equation3724. intro H. specialize (H F3_2 F3_1). unfold magma_op, refa153_inst, refa153_op in H. discriminate H. Qed.

Lemma refa153_not3725 : ~ @Equation3725 Fin3 refa153_inst.
Proof. unfold Equation3725. intro H. specialize (H F3_2 F3_1). unfold magma_op, refa153_inst, refa153_op in H. discriminate H. Qed.

Lemma refa153_not3748 : ~ @Equation3748 Fin3 refa153_inst.
Proof. unfold Equation3748. intro H. specialize (H F3_2 F3_1). unfold magma_op, refa153_inst, refa153_op in H. discriminate H. Qed.

Lemma refa153_not3749 : ~ @Equation3749 Fin3 refa153_inst.
Proof. unfold Equation3749. intro H. specialize (H F3_2 F3_1). unfold magma_op, refa153_inst, refa153_op in H. discriminate H. Qed.

Lemma refa153_not3752 : ~ @Equation3752 Fin3 refa153_inst.
Proof. unfold Equation3752. intro H. specialize (H F3_2 F3_1). unfold magma_op, refa153_inst, refa153_op in H. discriminate H. Qed.

Lemma refa153_not3759 : ~ @Equation3759 Fin3 refa153_inst.
Proof. unfold Equation3759. intro H. specialize (H F3_2 F3_1). unfold magma_op, refa153_inst, refa153_op in H. discriminate H. Qed.

Lemma refa153_not3761 : ~ @Equation3761 Fin3 refa153_inst.
Proof. unfold Equation3761. intro H. specialize (H F3_2 F3_1). unfold magma_op, refa153_inst, refa153_op in H. discriminate H. Qed.

Lemma refa153_not3915 : ~ @Equation3915 Fin3 refa153_inst.
Proof. unfold Equation3915. intro H. specialize (H F3_2 F3_1). unfold magma_op, refa153_inst, refa153_op in H. discriminate H. Qed.

Lemma refa153_not3917 : ~ @Equation3917 Fin3 refa153_inst.
Proof. unfold Equation3917. intro H. specialize (H F3_2 F3_1). unfold magma_op, refa153_inst, refa153_op in H. discriminate H. Qed.

Lemma refa153_not3918 : ~ @Equation3918 Fin3 refa153_inst.
Proof. unfold Equation3918. intro H. specialize (H F3_2 F3_1). unfold magma_op, refa153_inst, refa153_op in H. discriminate H. Qed.

Lemma refa153_not3924 : ~ @Equation3924 Fin3 refa153_inst.
Proof. unfold Equation3924. intro H. specialize (H F3_2 F3_1). unfold magma_op, refa153_inst, refa153_op in H. discriminate H. Qed.

Lemma refa153_not3925 : ~ @Equation3925 Fin3 refa153_inst.
Proof. unfold Equation3925. intro H. specialize (H F3_2 F3_1). unfold magma_op, refa153_inst, refa153_op in H. discriminate H. Qed.

Lemma refa153_not3927 : ~ @Equation3927 Fin3 refa153_inst.
Proof. unfold Equation3927. intro H. specialize (H F3_2 F3_1). unfold magma_op, refa153_inst, refa153_op in H. discriminate H. Qed.

Lemma refa153_not3928 : ~ @Equation3928 Fin3 refa153_inst.
Proof. unfold Equation3928. intro H. specialize (H F3_2 F3_1). unfold magma_op, refa153_inst, refa153_op in H. discriminate H. Qed.

Lemma refa153_not3951 : ~ @Equation3951 Fin3 refa153_inst.
Proof. unfold Equation3951. intro H. specialize (H F3_2 F3_1). unfold magma_op, refa153_inst, refa153_op in H. discriminate H. Qed.

Lemma refa153_not3952 : ~ @Equation3952 Fin3 refa153_inst.
Proof. unfold Equation3952. intro H. specialize (H F3_2 F3_1). unfold magma_op, refa153_inst, refa153_op in H. discriminate H. Qed.

Lemma refa153_not3954 : ~ @Equation3954 Fin3 refa153_inst.
Proof. unfold Equation3954. intro H. specialize (H F3_2 F3_1). unfold magma_op, refa153_inst, refa153_op in H. discriminate H. Qed.

Lemma refa153_not3955 : ~ @Equation3955 Fin3 refa153_inst.
Proof. unfold Equation3955. intro H. specialize (H F3_2 F3_1). unfold magma_op, refa153_inst, refa153_op in H. discriminate H. Qed.

Lemma refa153_not3961 : ~ @Equation3961 Fin3 refa153_inst.
Proof. unfold Equation3961. intro H. specialize (H F3_2 F3_1). unfold magma_op, refa153_inst, refa153_op in H. discriminate H. Qed.

Lemma refa153_not3962 : ~ @Equation3962 Fin3 refa153_inst.
Proof. unfold Equation3962. intro H. specialize (H F3_2 F3_1). unfold magma_op, refa153_inst, refa153_op in H. discriminate H. Qed.

Lemma refa153_not3964 : ~ @Equation3964 Fin3 refa153_inst.
Proof. unfold Equation3964. intro H. specialize (H F3_2 F3_1). unfold magma_op, refa153_inst, refa153_op in H. discriminate H. Qed.

Lemma refa153_not4118 : ~ @Equation4118 Fin3 refa153_inst.
Proof. unfold Equation4118. intro H. specialize (H F3_2 F3_1). unfold magma_op, refa153_inst, refa153_op in H. discriminate H. Qed.

Lemma refa153_not4120 : ~ @Equation4120 Fin3 refa153_inst.
Proof. unfold Equation4120. intro H. specialize (H F3_2 F3_1). unfold magma_op, refa153_inst, refa153_op in H. discriminate H. Qed.

Lemma refa153_not4121 : ~ @Equation4121 Fin3 refa153_inst.
Proof. unfold Equation4121. intro H. specialize (H F3_2 F3_1). unfold magma_op, refa153_inst, refa153_op in H. discriminate H. Qed.

Lemma refa153_not4127 : ~ @Equation4127 Fin3 refa153_inst.
Proof. unfold Equation4127. intro H. specialize (H F3_2 F3_1). unfold magma_op, refa153_inst, refa153_op in H. discriminate H. Qed.

Lemma refa153_not4128 : ~ @Equation4128 Fin3 refa153_inst.
Proof. unfold Equation4128. intro H. specialize (H F3_2 F3_1). unfold magma_op, refa153_inst, refa153_op in H. discriminate H. Qed.

Lemma refa153_not4130 : ~ @Equation4130 Fin3 refa153_inst.
Proof. unfold Equation4130. intro H. specialize (H F3_2 F3_1). unfold magma_op, refa153_inst, refa153_op in H. discriminate H. Qed.

Lemma refa153_not4131 : ~ @Equation4131 Fin3 refa153_inst.
Proof. unfold Equation4131. intro H. specialize (H F3_2 F3_1). unfold magma_op, refa153_inst, refa153_op in H. discriminate H. Qed.

Lemma refa153_not4154 : ~ @Equation4154 Fin3 refa153_inst.
Proof. unfold Equation4154. intro H. specialize (H F3_2 F3_1). unfold magma_op, refa153_inst, refa153_op in H. discriminate H. Qed.

Lemma refa153_not4155 : ~ @Equation4155 Fin3 refa153_inst.
Proof. unfold Equation4155. intro H. specialize (H F3_2 F3_1). unfold magma_op, refa153_inst, refa153_op in H. discriminate H. Qed.

Lemma refa153_not4157 : ~ @Equation4157 Fin3 refa153_inst.
Proof. unfold Equation4157. intro H. specialize (H F3_2 F3_1). unfold magma_op, refa153_inst, refa153_op in H. discriminate H. Qed.

Lemma refa153_not4158 : ~ @Equation4158 Fin3 refa153_inst.
Proof. unfold Equation4158. intro H. specialize (H F3_2 F3_1). unfold magma_op, refa153_inst, refa153_op in H. discriminate H. Qed.

Lemma refa153_not4164 : ~ @Equation4164 Fin3 refa153_inst.
Proof. unfold Equation4164. intro H. specialize (H F3_2 F3_1). unfold magma_op, refa153_inst, refa153_op in H. discriminate H. Qed.

Lemma refa153_not4165 : ~ @Equation4165 Fin3 refa153_inst.
Proof. unfold Equation4165. intro H. specialize (H F3_2 F3_1). unfold magma_op, refa153_inst, refa153_op in H. discriminate H. Qed.

Lemma refa153_not4167 : ~ @Equation4167 Fin3 refa153_inst.
Proof. unfold Equation4167. intro H. specialize (H F3_2 F3_1). unfold magma_op, refa153_inst, refa153_op in H. discriminate H. Qed.

Lemma refa153_not4268 : ~ @Equation4268 Fin3 refa153_inst.
Proof. unfold Equation4268. intro H. specialize (H F3_2 F3_1). unfold magma_op, refa153_inst, refa153_op in H. discriminate H. Qed.

Lemma refa153_not4275 : ~ @Equation4275 Fin3 refa153_inst.
Proof. unfold Equation4275. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa153_inst, refa153_op in H. discriminate H. Qed.

Lemma refa153_not4283 : ~ @Equation4283 Fin3 refa153_inst.
Proof. unfold Equation4283. intro H. specialize (H F3_2 F3_1). unfold magma_op, refa153_inst, refa153_op in H. discriminate H. Qed.

Lemma refa153_not4284 : ~ @Equation4284 Fin3 refa153_inst.
Proof. unfold Equation4284. intro H. specialize (H F3_2 F3_1). unfold magma_op, refa153_inst, refa153_op in H. discriminate H. Qed.

Lemma refa153_not4290 : ~ @Equation4290 Fin3 refa153_inst.
Proof. unfold Equation4290. intro H. specialize (H F3_2 F3_1). unfold magma_op, refa153_inst, refa153_op in H. discriminate H. Qed.

Lemma refa153_not4291 : ~ @Equation4291 Fin3 refa153_inst.
Proof. unfold Equation4291. intro H. specialize (H F3_2 F3_1). unfold magma_op, refa153_inst, refa153_op in H. discriminate H. Qed.

Lemma refa153_not4293 : ~ @Equation4293 Fin3 refa153_inst.
Proof. unfold Equation4293. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa153_inst, refa153_op in H. discriminate H. Qed.

Lemma refa153_not4396 : ~ @Equation4396 Fin3 refa153_inst.
Proof. unfold Equation4396. intro H. specialize (H F3_2 F3_1). unfold magma_op, refa153_inst, refa153_op in H. discriminate H. Qed.

Lemma refa153_not4398 : ~ @Equation4398 Fin3 refa153_inst.
Proof. unfold Equation4398. intro H. specialize (H F3_2 F3_1). unfold magma_op, refa153_inst, refa153_op in H. discriminate H. Qed.

Lemma refa153_not4399 : ~ @Equation4399 Fin3 refa153_inst.
Proof. unfold Equation4399. intro H. specialize (H F3_2 F3_1). unfold magma_op, refa153_inst, refa153_op in H. discriminate H. Qed.

Lemma refa153_not4405 : ~ @Equation4405 Fin3 refa153_inst.
Proof. unfold Equation4405. intro H. specialize (H F3_2 F3_1). unfold magma_op, refa153_inst, refa153_op in H. discriminate H. Qed.

Lemma refa153_not4406 : ~ @Equation4406 Fin3 refa153_inst.
Proof. unfold Equation4406. intro H. specialize (H F3_2 F3_1). unfold magma_op, refa153_inst, refa153_op in H. discriminate H. Qed.

Lemma refa153_not4408 : ~ @Equation4408 Fin3 refa153_inst.
Proof. unfold Equation4408. intro H. specialize (H F3_2 F3_1). unfold magma_op, refa153_inst, refa153_op in H. discriminate H. Qed.

(** ---- refa154 (Fin3) ---- *)

Definition refa154_op (x y : Fin3) : Fin3 :=
  match x, y with
  | F3_0, F3_0 => F3_0 | F3_0, F3_1 => F3_1 | F3_0, F3_2 => F3_2
  | F3_1, F3_0 => F3_0 | F3_1, F3_1 => F3_1 | F3_1, F3_2 => F3_2
  | F3_2, F3_0 => F3_0 | F3_2, F3_1 => F3_2 | F3_2, F3_2 => F3_1
  end.

#[local] Instance refa154_inst : Magma Fin3 := {| magma_op := refa154_op |}.

Lemma refa154_sat1109 : @Equation1109 Fin3 refa154_inst.
Proof. unfold Equation1109, magma_op, refa154_inst, refa154_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa154_sat1780 : @Equation1780 Fin3 refa154_inst.
Proof. unfold Equation1780, magma_op, refa154_inst, refa154_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa154_sat1887 : @Equation1887 Fin3 refa154_inst.
Proof. unfold Equation1887, magma_op, refa154_inst, refa154_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa154_not1028 : ~ @Equation1028 Fin3 refa154_inst.
Proof. unfold Equation1028. intro H. specialize (H F3_2 F3_0). unfold magma_op, refa154_inst, refa154_op in H. discriminate H. Qed.

Lemma refa154_not1036 : ~ @Equation1036 Fin3 refa154_inst.
Proof. unfold Equation1036. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa154_inst, refa154_op in H. discriminate H. Qed.

Lemma refa154_not1038 : ~ @Equation1038 Fin3 refa154_inst.
Proof. unfold Equation1038. intro H. specialize (H F3_2 F3_0). unfold magma_op, refa154_inst, refa154_op in H. discriminate H. Qed.

Lemma refa154_not1049 : ~ @Equation1049 Fin3 refa154_inst.
Proof. unfold Equation1049. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa154_inst, refa154_op in H. discriminate H. Qed.

Lemma refa154_not1113 : ~ @Equation1113 Fin3 refa154_inst.
Proof. unfold Equation1113. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa154_inst, refa154_op in H. discriminate H. Qed.

Lemma refa154_not1635 : ~ @Equation1635 Fin3 refa154_inst.
Proof. unfold Equation1635. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa154_inst, refa154_op in H. discriminate H. Qed.

Lemma refa154_not1848 : ~ @Equation1848 Fin3 refa154_inst.
Proof. unfold Equation1848. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa154_inst, refa154_op in H. discriminate H. Qed.

Lemma refa154_not1861 : ~ @Equation1861 Fin3 refa154_inst.
Proof. unfold Equation1861. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa154_inst, refa154_op in H. discriminate H. Qed.

Lemma refa154_not2447 : ~ @Equation2447 Fin3 refa154_inst.
Proof. unfold Equation2447. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa154_inst, refa154_op in H. discriminate H. Qed.

Lemma refa154_not2470 : ~ @Equation2470 Fin3 refa154_inst.
Proof. unfold Equation2470. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa154_inst, refa154_op in H. discriminate H. Qed.

Lemma refa154_not2534 : ~ @Equation2534 Fin3 refa154_inst.
Proof. unfold Equation2534. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa154_inst, refa154_op in H. discriminate H. Qed.

Lemma refa154_not3878 : ~ @Equation3878 Fin3 refa154_inst.
Proof. unfold Equation3878. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa154_inst, refa154_op in H. discriminate H. Qed.

Lemma refa154_not3924 : ~ @Equation3924 Fin3 refa154_inst.
Proof. unfold Equation3924. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa154_inst, refa154_op in H. discriminate H. Qed.

Lemma refa154_not4647 : ~ @Equation4647 Fin3 refa154_inst.
Proof. unfold Equation4647. intro H. specialize (H F3_0 F3_0 F3_1). unfold magma_op, refa154_inst, refa154_op in H. discriminate H. Qed.

(** ---- refa155 (Fin3) ---- *)

Definition refa155_op (x y : Fin3) : Fin3 :=
  match x, y with
  | F3_0, F3_0 => F3_1 | F3_0, F3_1 => F3_0 | F3_0, F3_2 => F3_1
  | F3_1, F3_0 => F3_0 | F3_1, F3_1 => F3_2 | F3_1, F3_2 => F3_1
  | F3_2, F3_0 => F3_1 | F3_2, F3_1 => F3_1 | F3_2, F3_2 => F3_1
  end.

#[local] Instance refa155_inst : Magma Fin3 := {| magma_op := refa155_op |}.

Lemma refa155_sat1482 : @Equation1482 Fin3 refa155_inst.
Proof. unfold Equation1482, magma_op, refa155_inst, refa155_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa155_sat1694 : @Equation1694 Fin3 refa155_inst.
Proof. unfold Equation1694, magma_op, refa155_inst, refa155_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa155_sat1860 : @Equation1860 Fin3 refa155_inst.
Proof. unfold Equation1860, magma_op, refa155_inst, refa155_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa155_sat2053 : @Equation2053 Fin3 refa155_inst.
Proof. unfold Equation2053, magma_op, refa155_inst, refa155_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa155_sat2125 : @Equation2125 Fin3 refa155_inst.
Proof. unfold Equation2125, magma_op, refa155_inst, refa155_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa155_sat2127 : @Equation2127 Fin3 refa155_inst.
Proof. unfold Equation2127, magma_op, refa155_inst, refa155_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa155_not151 : ~ @Equation151 Fin3 refa155_inst.
Proof. unfold Equation151. intro H. specialize (H F3_0). unfold magma_op, refa155_inst, refa155_op in H. discriminate H. Qed.

Lemma refa155_not1427 : ~ @Equation1427 Fin3 refa155_inst.
Proof. unfold Equation1427. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa155_inst, refa155_op in H. discriminate H. Qed.

Lemma refa155_not1428 : ~ @Equation1428 Fin3 refa155_inst.
Proof. unfold Equation1428. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa155_inst, refa155_op in H. discriminate H. Qed.

Lemma refa155_not1429 : ~ @Equation1429 Fin3 refa155_inst.
Proof. unfold Equation1429. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa155_inst, refa155_op in H. discriminate H. Qed.

Lemma refa155_not1631 : ~ @Equation1631 Fin3 refa155_inst.
Proof. unfold Equation1631. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa155_inst, refa155_op in H. discriminate H. Qed.

Lemma refa155_not1634 : ~ @Equation1634 Fin3 refa155_inst.
Proof. unfold Equation1634. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa155_inst, refa155_op in H. discriminate H. Qed.

Lemma refa155_not1637 : ~ @Equation1637 Fin3 refa155_inst.
Proof. unfold Equation1637. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa155_inst, refa155_op in H. discriminate H. Qed.

Lemma refa155_not1837 : ~ @Equation1837 Fin3 refa155_inst.
Proof. unfold Equation1837. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa155_inst, refa155_op in H. discriminate H. Qed.

Lemma refa155_not1847 : ~ @Equation1847 Fin3 refa155_inst.
Proof. unfold Equation1847. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa155_inst, refa155_op in H. discriminate H. Qed.

Lemma refa155_not1857 : ~ @Equation1857 Fin3 refa155_inst.
Proof. unfold Equation1857. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa155_inst, refa155_op in H. discriminate H. Qed.

Lemma refa155_not1931 : ~ @Equation1931 Fin3 refa155_inst.
Proof. unfold Equation1931. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa155_inst, refa155_op in H. discriminate H. Qed.

Lemma refa155_not2050 : ~ @Equation2050 Fin3 refa155_inst.
Proof. unfold Equation2050. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa155_inst, refa155_op in H. discriminate H. Qed.

Lemma refa155_not2087 : ~ @Equation2087 Fin3 refa155_inst.
Proof. unfold Equation2087. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa155_inst, refa155_op in H. discriminate H. Qed.

Lemma refa155_not2124 : ~ @Equation2124 Fin3 refa155_inst.
Proof. unfold Equation2124. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa155_inst, refa155_op in H. discriminate H. Qed.

Lemma refa155_not2134 : ~ @Equation2134 Fin3 refa155_inst.
Proof. unfold Equation2134. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa155_inst, refa155_op in H. discriminate H. Qed.

Lemma refa155_not3258 : ~ @Equation3258 Fin3 refa155_inst.
Proof. unfold Equation3258. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa155_inst, refa155_op in H. discriminate H. Qed.

Lemma refa155_not3261 : ~ @Equation3261 Fin3 refa155_inst.
Proof. unfold Equation3261. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa155_inst, refa155_op in H. discriminate H. Qed.

Lemma refa155_not3309 : ~ @Equation3309 Fin3 refa155_inst.
Proof. unfold Equation3309. intro H. specialize (H F3_1 F3_0). unfold magma_op, refa155_inst, refa155_op in H. discriminate H. Qed.

Lemma refa155_not3457 : ~ @Equation3457 Fin3 refa155_inst.
Proof. unfold Equation3457. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa155_inst, refa155_op in H. discriminate H. Qed.

Lemma refa155_not3462 : ~ @Equation3462 Fin3 refa155_inst.
Proof. unfold Equation3462. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa155_inst, refa155_op in H. discriminate H. Qed.

Lemma refa155_not3521 : ~ @Equation3521 Fin3 refa155_inst.
Proof. unfold Equation3521. intro H. specialize (H F3_1 F3_0). unfold magma_op, refa155_inst, refa155_op in H. discriminate H. Qed.

Lemma refa155_not3877 : ~ @Equation3877 Fin3 refa155_inst.
Proof. unfold Equation3877. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa155_inst, refa155_op in H. discriminate H. Qed.

Lemma refa155_not3880 : ~ @Equation3880 Fin3 refa155_inst.
Proof. unfold Equation3880. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa155_inst, refa155_op in H. discriminate H. Qed.

Lemma refa155_not3887 : ~ @Equation3887 Fin3 refa155_inst.
Proof. unfold Equation3887. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa155_inst, refa155_op in H. discriminate H. Qed.

Lemma refa155_not3890 : ~ @Equation3890 Fin3 refa155_inst.
Proof. unfold Equation3890. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa155_inst, refa155_op in H. discriminate H. Qed.

Lemma refa155_not3952 : ~ @Equation3952 Fin3 refa155_inst.
Proof. unfold Equation3952. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa155_inst, refa155_op in H. discriminate H. Qed.

Lemma refa155_not4067 : ~ @Equation4067 Fin3 refa155_inst.
Proof. unfold Equation4067. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa155_inst, refa155_op in H. discriminate H. Qed.

Lemma refa155_not4083 : ~ @Equation4083 Fin3 refa155_inst.
Proof. unfold Equation4083. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa155_inst, refa155_op in H. discriminate H. Qed.

Lemma refa155_not4093 : ~ @Equation4093 Fin3 refa155_inst.
Proof. unfold Equation4093. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa155_inst, refa155_op in H. discriminate H. Qed.

Lemma refa155_not4121 : ~ @Equation4121 Fin3 refa155_inst.
Proof. unfold Equation4121. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa155_inst, refa155_op in H. discriminate H. Qed.

Lemma refa155_not4284 : ~ @Equation4284 Fin3 refa155_inst.
Proof. unfold Equation4284. intro H. specialize (H F3_1 F3_0). unfold magma_op, refa155_inst, refa155_op in H. discriminate H. Qed.

Lemma refa155_not4314 : ~ @Equation4314 Fin3 refa155_inst.
Proof. unfold Equation4314. intro H. specialize (H F3_1 F3_0). unfold magma_op, refa155_inst, refa155_op in H. discriminate H. Qed.

Lemma refa155_not4591 : ~ @Equation4591 Fin3 refa155_inst.
Proof. unfold Equation4591. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa155_inst, refa155_op in H. discriminate H. Qed.

Lemma refa155_not4599 : ~ @Equation4599 Fin3 refa155_inst.
Proof. unfold Equation4599. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa155_inst, refa155_op in H. discriminate H. Qed.

Lemma refa155_not4606 : ~ @Equation4606 Fin3 refa155_inst.
Proof. unfold Equation4606. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa155_inst, refa155_op in H. discriminate H. Qed.

(** ---- refa156 (Fin3) ---- *)

Definition refa156_op (x y : Fin3) : Fin3 :=
  match x, y with
  | F3_0, F3_0 => F3_0 | F3_0, F3_1 => F3_0 | F3_0, F3_2 => F3_0
  | F3_1, F3_0 => F3_1 | F3_1, F3_1 => F3_0 | F3_1, F3_2 => F3_2
  | F3_2, F3_0 => F3_2 | F3_2, F3_1 => F3_0 | F3_2, F3_2 => F3_2
  end.

#[local] Instance refa156_inst : Magma Fin3 := {| magma_op := refa156_op |}.

Lemma refa156_sat841 : @Equation841 Fin3 refa156_inst.
Proof. unfold Equation841, magma_op, refa156_inst, refa156_op. intros x y z w. destruct x, y, z, w; reflexivity. Qed.

Lemma refa156_not108 : ~ @Equation108 Fin3 refa156_inst.
Proof. unfold Equation108. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa156_inst, refa156_op in H. discriminate H. Qed.

Lemma refa156_not414 : ~ @Equation414 Fin3 refa156_inst.
Proof. unfold Equation414. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa156_inst, refa156_op in H. discriminate H. Qed.

Lemma refa156_not427 : ~ @Equation427 Fin3 refa156_inst.
Proof. unfold Equation427. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa156_inst, refa156_op in H. discriminate H. Qed.

Lemma refa156_not430 : ~ @Equation430 Fin3 refa156_inst.
Proof. unfold Equation430. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa156_inst, refa156_op in H. discriminate H. Qed.

Lemma refa156_not436 : ~ @Equation436 Fin3 refa156_inst.
Proof. unfold Equation436. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa156_inst, refa156_op in H. discriminate H. Qed.

Lemma refa156_not437 : ~ @Equation437 Fin3 refa156_inst.
Proof. unfold Equation437. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa156_inst, refa156_op in H. discriminate H. Qed.

Lemma refa156_not439 : ~ @Equation439 Fin3 refa156_inst.
Proof. unfold Equation439. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa156_inst, refa156_op in H. discriminate H. Qed.

Lemma refa156_not440 : ~ @Equation440 Fin3 refa156_inst.
Proof. unfold Equation440. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa156_inst, refa156_op in H. discriminate H. Qed.

Lemma refa156_not823 : ~ @Equation823 Fin3 refa156_inst.
Proof. unfold Equation823. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa156_inst, refa156_op in H. discriminate H. Qed.

Lemma refa156_not842 : ~ @Equation842 Fin3 refa156_inst.
Proof. unfold Equation842. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa156_inst, refa156_op in H. discriminate H. Qed.

Lemma refa156_not843 : ~ @Equation843 Fin3 refa156_inst.
Proof. unfold Equation843. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa156_inst, refa156_op in H. discriminate H. Qed.

Lemma refa156_not845 : ~ @Equation845 Fin3 refa156_inst.
Proof. unfold Equation845. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa156_inst, refa156_op in H. discriminate H. Qed.

Lemma refa156_not846 : ~ @Equation846 Fin3 refa156_inst.
Proof. unfold Equation846. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa156_inst, refa156_op in H. discriminate H. Qed.

Lemma refa156_not1023 : ~ @Equation1023 Fin3 refa156_inst.
Proof. unfold Equation1023. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa156_inst, refa156_op in H. discriminate H. Qed.

Lemma refa156_not1036 : ~ @Equation1036 Fin3 refa156_inst.
Proof. unfold Equation1036. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa156_inst, refa156_op in H. discriminate H. Qed.

Lemma refa156_not1039 : ~ @Equation1039 Fin3 refa156_inst.
Proof. unfold Equation1039. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa156_inst, refa156_op in H. discriminate H. Qed.

Lemma refa156_not1046 : ~ @Equation1046 Fin3 refa156_inst.
Proof. unfold Equation1046. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa156_inst, refa156_op in H. discriminate H. Qed.

Lemma refa156_not1049 : ~ @Equation1049 Fin3 refa156_inst.
Proof. unfold Equation1049. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa156_inst, refa156_op in H. discriminate H. Qed.

Lemma refa156_not1252 : ~ @Equation1252 Fin3 refa156_inst.
Proof. unfold Equation1252. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa156_inst, refa156_op in H. discriminate H. Qed.

Lemma refa156_not1851 : ~ @Equation1851 Fin3 refa156_inst.
Proof. unfold Equation1851. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa156_inst, refa156_op in H. discriminate H. Qed.

Lemma refa156_not1857 : ~ @Equation1857 Fin3 refa156_inst.
Proof. unfold Equation1857. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa156_inst, refa156_op in H. discriminate H. Qed.

Lemma refa156_not1860 : ~ @Equation1860 Fin3 refa156_inst.
Proof. unfold Equation1860. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa156_inst, refa156_op in H. discriminate H. Qed.

Lemma refa156_not1861 : ~ @Equation1861 Fin3 refa156_inst.
Proof. unfold Equation1861. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa156_inst, refa156_op in H. discriminate H. Qed.

Lemma refa156_not3256 : ~ @Equation3256 Fin3 refa156_inst.
Proof. unfold Equation3256. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa156_inst, refa156_op in H. discriminate H. Qed.

Lemma refa156_not3278 : ~ @Equation3278 Fin3 refa156_inst.
Proof. unfold Equation3278. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa156_inst, refa156_op in H. discriminate H. Qed.

Lemma refa156_not3279 : ~ @Equation3279 Fin3 refa156_inst.
Proof. unfold Equation3279. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa156_inst, refa156_op in H. discriminate H. Qed.

Lemma refa156_not3306 : ~ @Equation3306 Fin3 refa156_inst.
Proof. unfold Equation3306. intro H. specialize (H F3_2 F3_1). unfold magma_op, refa156_inst, refa156_op in H. discriminate H. Qed.

Lemma refa156_not3315 : ~ @Equation3315 Fin3 refa156_inst.
Proof. unfold Equation3315. intro H. specialize (H F3_2 F3_1). unfold magma_op, refa156_inst, refa156_op in H. discriminate H. Qed.

Lemma refa156_not3318 : ~ @Equation3318 Fin3 refa156_inst.
Proof. unfold Equation3318. intro H. specialize (H F3_2 F3_1). unfold magma_op, refa156_inst, refa156_op in H. discriminate H. Qed.

Lemma refa156_not3663 : ~ @Equation3663 Fin3 refa156_inst.
Proof. unfold Equation3663. intro H. specialize (H F3_2 F3_1 F3_0). unfold magma_op, refa156_inst, refa156_op in H. discriminate H. Qed.

Lemma refa156_not3665 : ~ @Equation3665 Fin3 refa156_inst.
Proof. unfold Equation3665. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa156_inst, refa156_op in H. discriminate H. Qed.

Lemma refa156_not3677 : ~ @Equation3677 Fin3 refa156_inst.
Proof. unfold Equation3677. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa156_inst, refa156_op in H. discriminate H. Qed.

Lemma refa156_not3684 : ~ @Equation3684 Fin3 refa156_inst.
Proof. unfold Equation3684. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa156_inst, refa156_op in H. discriminate H. Qed.

Lemma refa156_not3685 : ~ @Equation3685 Fin3 refa156_inst.
Proof. unfold Equation3685. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa156_inst, refa156_op in H. discriminate H. Qed.

Lemma refa156_not3687 : ~ @Equation3687 Fin3 refa156_inst.
Proof. unfold Equation3687. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa156_inst, refa156_op in H. discriminate H. Qed.

Lemma refa156_not3729 : ~ @Equation3729 Fin3 refa156_inst.
Proof. unfold Equation3729. intro H. specialize (H F3_1 F3_0 F3_2). unfold magma_op, refa156_inst, refa156_op in H. discriminate H. Qed.

Lemma refa156_not3865 : ~ @Equation3865 Fin3 refa156_inst.
Proof. unfold Equation3865. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa156_inst, refa156_op in H. discriminate H. Qed.

Lemma refa156_not3873 : ~ @Equation3873 Fin3 refa156_inst.
Proof. unfold Equation3873. intro H. specialize (H F3_2 F3_1 F3_0). unfold magma_op, refa156_inst, refa156_op in H. discriminate H. Qed.

Lemma refa156_not3878 : ~ @Equation3878 Fin3 refa156_inst.
Proof. unfold Equation3878. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa156_inst, refa156_op in H. discriminate H. Qed.

Lemma refa156_not3881 : ~ @Equation3881 Fin3 refa156_inst.
Proof. unfold Equation3881. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa156_inst, refa156_op in H. discriminate H. Qed.

Lemma refa156_not3887 : ~ @Equation3887 Fin3 refa156_inst.
Proof. unfold Equation3887. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa156_inst, refa156_op in H. discriminate H. Qed.

Lemma refa156_not3888 : ~ @Equation3888 Fin3 refa156_inst.
Proof. unfold Equation3888. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa156_inst, refa156_op in H. discriminate H. Qed.

Lemma refa156_not3943 : ~ @Equation3943 Fin3 refa156_inst.
Proof. unfold Equation3943. intro H. specialize (H F3_1 F3_0 F3_2). unfold magma_op, refa156_inst, refa156_op in H. discriminate H. Qed.

Lemma refa156_not4066 : ~ @Equation4066 Fin3 refa156_inst.
Proof. unfold Equation4066. intro H. specialize (H F3_2 F3_1). unfold magma_op, refa156_inst, refa156_op in H. discriminate H. Qed.

Lemma refa156_not4067 : ~ @Equation4067 Fin3 refa156_inst.
Proof. unfold Equation4067. intro H. specialize (H F3_2 F3_1). unfold magma_op, refa156_inst, refa156_op in H. discriminate H. Qed.

Lemma refa156_not4068 : ~ @Equation4068 Fin3 refa156_inst.
Proof. unfold Equation4068. intro H. specialize (H F3_2 F3_1). unfold magma_op, refa156_inst, refa156_op in H. discriminate H. Qed.

Lemma refa156_not4070 : ~ @Equation4070 Fin3 refa156_inst.
Proof. unfold Equation4070. intro H. specialize (H F3_2 F3_1). unfold magma_op, refa156_inst, refa156_op in H. discriminate H. Qed.

Lemma refa156_not4071 : ~ @Equation4071 Fin3 refa156_inst.
Proof. unfold Equation4071. intro H. specialize (H F3_2 F3_1). unfold magma_op, refa156_inst, refa156_op in H. discriminate H. Qed.

Lemma refa156_not4073 : ~ @Equation4073 Fin3 refa156_inst.
Proof. unfold Equation4073. intro H. specialize (H F3_2 F3_1). unfold magma_op, refa156_inst, refa156_op in H. discriminate H. Qed.

Lemma refa156_not4081 : ~ @Equation4081 Fin3 refa156_inst.
Proof. unfold Equation4081. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa156_inst, refa156_op in H. discriminate H. Qed.

Lemma refa156_not4083 : ~ @Equation4083 Fin3 refa156_inst.
Proof. unfold Equation4083. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa156_inst, refa156_op in H. discriminate H. Qed.

Lemma refa156_not4084 : ~ @Equation4084 Fin3 refa156_inst.
Proof. unfold Equation4084. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa156_inst, refa156_op in H. discriminate H. Qed.

Lemma refa156_not4090 : ~ @Equation4090 Fin3 refa156_inst.
Proof. unfold Equation4090. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa156_inst, refa156_op in H. discriminate H. Qed.

Lemma refa156_not4091 : ~ @Equation4091 Fin3 refa156_inst.
Proof. unfold Equation4091. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa156_inst, refa156_op in H. discriminate H. Qed.

Lemma refa156_not4093 : ~ @Equation4093 Fin3 refa156_inst.
Proof. unfold Equation4093. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa156_inst, refa156_op in H. discriminate H. Qed.

Lemma refa156_not4270 : ~ @Equation4270 Fin3 refa156_inst.
Proof. unfold Equation4270. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa156_inst, refa156_op in H. discriminate H. Qed.

Lemma refa156_not4293 : ~ @Equation4293 Fin3 refa156_inst.
Proof. unfold Equation4293. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa156_inst, refa156_op in H. discriminate H. Qed.

Lemma refa156_not4314 : ~ @Equation4314 Fin3 refa156_inst.
Proof. unfold Equation4314. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa156_inst, refa156_op in H. discriminate H. Qed.

Lemma refa156_not4583 : ~ @Equation4583 Fin3 refa156_inst.
Proof. unfold Equation4583. intro H. specialize (H F3_2 F3_1). unfold magma_op, refa156_inst, refa156_op in H. discriminate H. Qed.

Lemma refa156_not4591 : ~ @Equation4591 Fin3 refa156_inst.
Proof. unfold Equation4591. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa156_inst, refa156_op in H. discriminate H. Qed.

Lemma refa156_not4606 : ~ @Equation4606 Fin3 refa156_inst.
Proof. unfold Equation4606. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa156_inst, refa156_op in H. discriminate H. Qed.

Lemma refa156_not4608 : ~ @Equation4608 Fin3 refa156_inst.
Proof. unfold Equation4608. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa156_inst, refa156_op in H. discriminate H. Qed.

Lemma refa156_not4622 : ~ @Equation4622 Fin3 refa156_inst.
Proof. unfold Equation4622. intro H. specialize (H F3_0 F3_0 F3_2). unfold magma_op, refa156_inst, refa156_op in H. discriminate H. Qed.

Lemma refa156_not4631 : ~ @Equation4631 Fin3 refa156_inst.
Proof. unfold Equation4631. intro H. specialize (H F3_2 F3_0 F3_1). unfold magma_op, refa156_inst, refa156_op in H. discriminate H. Qed.

Lemma refa156_not4636 : ~ @Equation4636 Fin3 refa156_inst.
Proof. unfold Equation4636. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa156_inst, refa156_op in H. discriminate H. Qed.

Lemma refa156_not4647 : ~ @Equation4647 Fin3 refa156_inst.
Proof. unfold Equation4647. intro H. specialize (H F3_0 F3_0 F3_2). unfold magma_op, refa156_inst, refa156_op in H. discriminate H. Qed.

(** ---- refa157 (Fin3) ---- *)

Definition refa157_op (x y : Fin3) : Fin3 :=
  match x, y with
  | F3_0, F3_0 => F3_0 | F3_0, F3_1 => F3_0 | F3_0, F3_2 => F3_1
  | F3_1, F3_0 => F3_2 | F3_1, F3_1 => F3_2 | F3_1, F3_2 => F3_1
  | F3_2, F3_0 => F3_1 | F3_2, F3_1 => F3_1 | F3_2, F3_2 => F3_0
  end.

#[local] Instance refa157_inst : Magma Fin3 := {| magma_op := refa157_op |}.

Lemma refa157_sat1838 : @Equation1838 Fin3 refa157_inst.
Proof. unfold Equation1838, magma_op, refa157_inst, refa157_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa157_not3456 : ~ @Equation3456 Fin3 refa157_inst.
Proof. unfold Equation3456. intro H. specialize (H F3_2). unfold magma_op, refa157_inst, refa157_op in H. discriminate H. Qed.

Lemma refa157_not4065 : ~ @Equation4065 Fin3 refa157_inst.
Proof. unfold Equation4065. intro H. specialize (H F3_2). unfold magma_op, refa157_inst, refa157_op in H. discriminate H. Qed.

(** ---- refa158 (Fin3) ---- *)

Definition refa158_op (x y : Fin3) : Fin3 :=
  match x, y with
  | F3_0, F3_0 => F3_0 | F3_0, F3_1 => F3_0 | F3_0, F3_2 => F3_2
  | F3_1, F3_0 => F3_1 | F3_1, F3_1 => F3_0 | F3_1, F3_2 => F3_2
  | F3_2, F3_0 => F3_1 | F3_2, F3_1 => F3_1 | F3_2, F3_2 => F3_2
  end.

#[local] Instance refa158_inst : Magma Fin3 := {| magma_op := refa158_op |}.

Lemma refa158_sat1055 : @Equation1055 Fin3 refa158_inst.
Proof. unfold Equation1055, magma_op, refa158_inst, refa158_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa158_not1847 : ~ @Equation1847 Fin3 refa158_inst.
Proof. unfold Equation1847. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa158_inst, refa158_op in H. discriminate H. Qed.

Lemma refa158_not3935 : ~ @Equation3935 Fin3 refa158_inst.
Proof. unfold Equation3935. intro H. specialize (H F3_1 F3_0 F3_2). unfold magma_op, refa158_inst, refa158_op in H. discriminate H. Qed.

(** ---- refa159 (Fin3) ---- *)

Definition refa159_op (x y : Fin3) : Fin3 :=
  match x, y with
  | F3_0, F3_0 => F3_0 | F3_0, F3_1 => F3_0 | F3_0, F3_2 => F3_1
  | F3_1, F3_0 => F3_0 | F3_1, F3_1 => F3_2 | F3_1, F3_2 => F3_0
  | F3_2, F3_0 => F3_0 | F3_2, F3_1 => F3_0 | F3_2, F3_2 => F3_1
  end.

#[local] Instance refa159_inst : Magma Fin3 := {| magma_op := refa159_op |}.

Lemma refa159_sat4301 : @Equation4301 Fin3 refa159_inst.
Proof. unfold Equation4301, magma_op, refa159_inst, refa159_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa159_sat4425 : @Equation4425 Fin3 refa159_inst.
Proof. unfold Equation4425, magma_op, refa159_inst, refa159_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa159_sat4462 : @Equation4462 Fin3 refa159_inst.
Proof. unfold Equation4462, magma_op, refa159_inst, refa159_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa159_not4270 : ~ @Equation4270 Fin3 refa159_inst.
Proof. unfold Equation4270. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa159_inst, refa159_op in H. discriminate H. Qed.

Lemma refa159_not4272 : ~ @Equation4272 Fin3 refa159_inst.
Proof. unfold Equation4272. intro H. specialize (H F3_1 F3_0). unfold magma_op, refa159_inst, refa159_op in H. discriminate H. Qed.

Lemma refa159_not4284 : ~ @Equation4284 Fin3 refa159_inst.
Proof. unfold Equation4284. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa159_inst, refa159_op in H. discriminate H. Qed.

Lemma refa159_not4290 : ~ @Equation4290 Fin3 refa159_inst.
Proof. unfold Equation4290. intro H. specialize (H F3_1 F3_0). unfold magma_op, refa159_inst, refa159_op in H. discriminate H. Qed.

Lemma refa159_not4314 : ~ @Equation4314 Fin3 refa159_inst.
Proof. unfold Equation4314. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa159_inst, refa159_op in H. discriminate H. Qed.

Lemma refa159_not4320 : ~ @Equation4320 Fin3 refa159_inst.
Proof. unfold Equation4320. intro H. specialize (H F3_1 F3_0). unfold magma_op, refa159_inst, refa159_op in H. discriminate H. Qed.

Lemma refa159_not4343 : ~ @Equation4343 Fin3 refa159_inst.
Proof. unfold Equation4343. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa159_inst, refa159_op in H. discriminate H. Qed.

Lemma refa159_not4358 : ~ @Equation4358 Fin3 refa159_inst.
Proof. unfold Equation4358. intro H. specialize (H F3_1 F3_0 F3_2). unfold magma_op, refa159_inst, refa159_op in H. discriminate H. Qed.

Lemma refa159_not4396 : ~ @Equation4396 Fin3 refa159_inst.
Proof. unfold Equation4396. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa159_inst, refa159_op in H. discriminate H. Qed.

Lemma refa159_not4398 : ~ @Equation4398 Fin3 refa159_inst.
Proof. unfold Equation4398. intro H. specialize (H F3_2 F3_0). unfold magma_op, refa159_inst, refa159_op in H. discriminate H. Qed.

Lemma refa159_not4406 : ~ @Equation4406 Fin3 refa159_inst.
Proof. unfold Equation4406. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa159_inst, refa159_op in H. discriminate H. Qed.

Lemma refa159_not4408 : ~ @Equation4408 Fin3 refa159_inst.
Proof. unfold Equation4408. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa159_inst, refa159_op in H. discriminate H. Qed.

Lemma refa159_not4433 : ~ @Equation4433 Fin3 refa159_inst.
Proof. unfold Equation4433. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa159_inst, refa159_op in H. discriminate H. Qed.

Lemma refa159_not4435 : ~ @Equation4435 Fin3 refa159_inst.
Proof. unfold Equation4435. intro H. specialize (H F3_2 F3_0). unfold magma_op, refa159_inst, refa159_op in H. discriminate H. Qed.

Lemma refa159_not4443 : ~ @Equation4443 Fin3 refa159_inst.
Proof. unfold Equation4443. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa159_inst, refa159_op in H. discriminate H. Qed.

Lemma refa159_not4445 : ~ @Equation4445 Fin3 refa159_inst.
Proof. unfold Equation4445. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa159_inst, refa159_op in H. discriminate H. Qed.

Lemma refa159_not4470 : ~ @Equation4470 Fin3 refa159_inst.
Proof. unfold Equation4470. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa159_inst, refa159_op in H. discriminate H. Qed.

Lemma refa159_not4472 : ~ @Equation4472 Fin3 refa159_inst.
Proof. unfold Equation4472. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa159_inst, refa159_op in H. discriminate H. Qed.

Lemma refa159_not4473 : ~ @Equation4473 Fin3 refa159_inst.
Proof. unfold Equation4473. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa159_inst, refa159_op in H. discriminate H. Qed.

Lemma refa159_not4480 : ~ @Equation4480 Fin3 refa159_inst.
Proof. unfold Equation4480. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa159_inst, refa159_op in H. discriminate H. Qed.

Lemma refa159_not4482 : ~ @Equation4482 Fin3 refa159_inst.
Proof. unfold Equation4482. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa159_inst, refa159_op in H. discriminate H. Qed.

Lemma refa159_not4583 : ~ @Equation4583 Fin3 refa159_inst.
Proof. unfold Equation4583. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa159_inst, refa159_op in H. discriminate H. Qed.

Lemma refa159_not4598 : ~ @Equation4598 Fin3 refa159_inst.
Proof. unfold Equation4598. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa159_inst, refa159_op in H. discriminate H. Qed.

Lemma refa159_not4599 : ~ @Equation4599 Fin3 refa159_inst.
Proof. unfold Equation4599. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa159_inst, refa159_op in H. discriminate H. Qed.

Lemma refa159_not4606 : ~ @Equation4606 Fin3 refa159_inst.
Proof. unfold Equation4606. intro H. specialize (H F3_2 F3_1). unfold magma_op, refa159_inst, refa159_op in H. discriminate H. Qed.

Lemma refa159_not4608 : ~ @Equation4608 Fin3 refa159_inst.
Proof. unfold Equation4608. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa159_inst, refa159_op in H. discriminate H. Qed.

Lemma refa159_not4622 : ~ @Equation4622 Fin3 refa159_inst.
Proof. unfold Equation4622. intro H. specialize (H F3_0 F3_1 F3_2). unfold magma_op, refa159_inst, refa159_op in H. discriminate H. Qed.

Lemma refa159_not4631 : ~ @Equation4631 Fin3 refa159_inst.
Proof. unfold Equation4631. intro H. specialize (H F3_2 F3_0 F3_2). unfold magma_op, refa159_inst, refa159_op in H. discriminate H. Qed.

Lemma refa159_not4636 : ~ @Equation4636 Fin3 refa159_inst.
Proof. unfold Equation4636. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa159_inst, refa159_op in H. discriminate H. Qed.

Lemma refa159_not4647 : ~ @Equation4647 Fin3 refa159_inst.
Proof. unfold Equation4647. intro H. specialize (H F3_0 F3_0 F3_2). unfold magma_op, refa159_inst, refa159_op in H. discriminate H. Qed.

(** ---- refa16 (Fin7) ---- *)

Definition refa16_op (x y : Fin7) : Fin7 :=
  match x, y with
  | F7_0, F7_0 => F7_1 | F7_0, F7_1 => F7_2 | F7_0, F7_2 => F7_3 | F7_0, F7_3 => F7_4 | F7_0, F7_4 => F7_5 | F7_0, F7_5 => F7_0 | F7_0, F7_6 => F7_6
  | F7_1, F7_0 => F7_6 | F7_1, F7_1 => F7_3 | F7_1, F7_2 => F7_0 | F7_1, F7_3 => F7_2 | F7_1, F7_4 => F7_1 | F7_1, F7_5 => F7_5 | F7_1, F7_6 => F7_4
  | F7_2, F7_0 => F7_5 | F7_2, F7_1 => F7_4 | F7_2, F7_2 => F7_2 | F7_2, F7_3 => F7_6 | F7_2, F7_4 => F7_0 | F7_2, F7_5 => F7_3 | F7_2, F7_6 => F7_1
  | F7_3, F7_0 => F7_2 | F7_3, F7_1 => F7_5 | F7_3, F7_2 => F7_1 | F7_3, F7_3 => F7_0 | F7_3, F7_4 => F7_4 | F7_3, F7_5 => F7_6 | F7_3, F7_6 => F7_3
  | F7_4, F7_0 => F7_4 | F7_4, F7_1 => F7_0 | F7_4, F7_2 => F7_5 | F7_4, F7_3 => F7_3 | F7_4, F7_4 => F7_6 | F7_4, F7_5 => F7_1 | F7_4, F7_6 => F7_2
  | F7_5, F7_0 => F7_3 | F7_5, F7_1 => F7_1 | F7_5, F7_2 => F7_6 | F7_5, F7_3 => F7_5 | F7_5, F7_4 => F7_2 | F7_5, F7_5 => F7_4 | F7_5, F7_6 => F7_0
  | F7_6, F7_0 => F7_0 | F7_6, F7_1 => F7_6 | F7_6, F7_2 => F7_4 | F7_6, F7_3 => F7_1 | F7_6, F7_4 => F7_3 | F7_6, F7_5 => F7_2 | F7_6, F7_6 => F7_5
  end.

#[local] Instance refa16_inst : Magma Fin7 := {| magma_op := refa16_op |}.

Lemma refa16_sat1445 : @Equation1445 Fin7 refa16_inst.
Proof. unfold Equation1445, magma_op, refa16_inst, refa16_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa16_sat1489 : @Equation1489 Fin7 refa16_inst.
Proof. unfold Equation1489, magma_op, refa16_inst, refa16_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa16_sat1516 : @Equation1516 Fin7 refa16_inst.
Proof. unfold Equation1516, magma_op, refa16_inst, refa16_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa16_not614 : ~ @Equation614 Fin7 refa16_inst.
Proof. unfold Equation614. intro H. specialize (H F7_0). unfold magma_op, refa16_inst, refa16_op in H. discriminate H. Qed.

Lemma refa16_not817 : ~ @Equation817 Fin7 refa16_inst.
Proof. unfold Equation817. intro H. specialize (H F7_0). unfold magma_op, refa16_inst, refa16_op in H. discriminate H. Qed.

Lemma refa16_not1482 : ~ @Equation1482 Fin7 refa16_inst.
Proof. unfold Equation1482. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa16_inst, refa16_op in H. discriminate H. Qed.

Lemma refa16_not1832 : ~ @Equation1832 Fin7 refa16_inst.
Proof. unfold Equation1832. intro H. specialize (H F7_0). unfold magma_op, refa16_inst, refa16_op in H. discriminate H. Qed.

Lemma refa16_not3253 : ~ @Equation3253 Fin7 refa16_inst.
Proof. unfold Equation3253. intro H. specialize (H F7_0). unfold magma_op, refa16_inst, refa16_op in H. discriminate H. Qed.

Lemma refa16_not3456 : ~ @Equation3456 Fin7 refa16_inst.
Proof. unfold Equation3456. intro H. specialize (H F7_0). unfold magma_op, refa16_inst, refa16_op in H. discriminate H. Qed.

Lemma refa16_not4065 : ~ @Equation4065 Fin7 refa16_inst.
Proof. unfold Equation4065. intro H. specialize (H F7_0). unfold magma_op, refa16_inst, refa16_op in H. discriminate H. Qed.

Lemma refa16_not4283 : ~ @Equation4283 Fin7 refa16_inst.
Proof. unfold Equation4283. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa16_inst, refa16_op in H. discriminate H. Qed.

Lemma refa16_not4284 : ~ @Equation4284 Fin7 refa16_inst.
Proof. unfold Equation4284. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa16_inst, refa16_op in H. discriminate H. Qed.

Lemma refa16_not4293 : ~ @Equation4293 Fin7 refa16_inst.
Proof. unfold Equation4293. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa16_inst, refa16_op in H. discriminate H. Qed.

Lemma refa16_not4314 : ~ @Equation4314 Fin7 refa16_inst.
Proof. unfold Equation4314. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa16_inst, refa16_op in H. discriminate H. Qed.

Lemma refa16_not4591 : ~ @Equation4591 Fin7 refa16_inst.
Proof. unfold Equation4591. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa16_inst, refa16_op in H. discriminate H. Qed.

Lemma refa16_not4599 : ~ @Equation4599 Fin7 refa16_inst.
Proof. unfold Equation4599. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa16_inst, refa16_op in H. discriminate H. Qed.

(** ---- refa160 (Fin3) ---- *)

Definition refa160_op (x y : Fin3) : Fin3 :=
  match x, y with
  | F3_0, F3_0 => F3_0 | F3_0, F3_1 => F3_1 | F3_0, F3_2 => F3_1
  | F3_1, F3_0 => F3_0 | F3_1, F3_1 => F3_2 | F3_1, F3_2 => F3_1
  | F3_2, F3_0 => F3_1 | F3_2, F3_1 => F3_2 | F3_2, F3_2 => F3_1
  end.

#[local] Instance refa160_inst : Magma Fin3 := {| magma_op := refa160_op |}.

Lemma refa160_sat1701 : @Equation1701 Fin3 refa160_inst.
Proof. unfold Equation1701, magma_op, refa160_inst, refa160_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa160_not1045 : ~ @Equation1045 Fin3 refa160_inst.
Proof. unfold Equation1045. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa160_inst, refa160_op in H. discriminate H. Qed.

Lemma refa160_not1921 : ~ @Equation1921 Fin3 refa160_inst.
Proof. unfold Equation1921. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa160_inst, refa160_op in H. discriminate H. Qed.

Lemma refa160_not3309 : ~ @Equation3309 Fin3 refa160_inst.
Proof. unfold Equation3309. intro H. specialize (H F3_2 F3_0). unfold magma_op, refa160_inst, refa160_op in H. discriminate H. Qed.

Lemma refa160_not3887 : ~ @Equation3887 Fin3 refa160_inst.
Proof. unfold Equation3887. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa160_inst, refa160_op in H. discriminate H. Qed.

Lemma refa160_not4284 : ~ @Equation4284 Fin3 refa160_inst.
Proof. unfold Equation4284. intro H. specialize (H F3_2 F3_0). unfold magma_op, refa160_inst, refa160_op in H. discriminate H. Qed.

(** ---- refa161 (Fin3) ---- *)

Definition refa161_op (x y : Fin3) : Fin3 :=
  match x, y with
  | F3_0, F3_0 => F3_0 | F3_0, F3_1 => F3_0 | F3_0, F3_2 => F3_1
  | F3_1, F3_0 => F3_0 | F3_1, F3_1 => F3_0 | F3_1, F3_2 => F3_1
  | F3_2, F3_0 => F3_0 | F3_2, F3_1 => F3_0 | F3_2, F3_2 => F3_0
  end.

#[local] Instance refa161_inst : Magma Fin3 := {| magma_op := refa161_op |}.

Lemma refa161_sat314 : @Equation314 Fin3 refa161_inst.
Proof. unfold Equation314, magma_op, refa161_inst, refa161_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa161_not3862 : ~ @Equation3862 Fin3 refa161_inst.
Proof. unfold Equation3862. intro H. specialize (H F3_2). unfold magma_op, refa161_inst, refa161_op in H. discriminate H. Qed.

Lemma refa161_not4065 : ~ @Equation4065 Fin3 refa161_inst.
Proof. unfold Equation4065. intro H. specialize (H F3_2). unfold magma_op, refa161_inst, refa161_op in H. discriminate H. Qed.

Lemma refa161_not4380 : ~ @Equation4380 Fin3 refa161_inst.
Proof. unfold Equation4380. intro H. specialize (H F3_2). unfold magma_op, refa161_inst, refa161_op in H. discriminate H. Qed.

Lemma refa161_not4583 : ~ @Equation4583 Fin3 refa161_inst.
Proof. unfold Equation4583. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa161_inst, refa161_op in H. discriminate H. Qed.

Lemma refa161_not4591 : ~ @Equation4591 Fin3 refa161_inst.
Proof. unfold Equation4591. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa161_inst, refa161_op in H. discriminate H. Qed.

Lemma refa161_not4598 : ~ @Equation4598 Fin3 refa161_inst.
Proof. unfold Equation4598. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa161_inst, refa161_op in H. discriminate H. Qed.

Lemma refa161_not4608 : ~ @Equation4608 Fin3 refa161_inst.
Proof. unfold Equation4608. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa161_inst, refa161_op in H. discriminate H. Qed.

Lemma refa161_not4636 : ~ @Equation4636 Fin3 refa161_inst.
Proof. unfold Equation4636. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa161_inst, refa161_op in H. discriminate H. Qed.

Lemma refa161_not4647 : ~ @Equation4647 Fin3 refa161_inst.
Proof. unfold Equation4647. intro H. specialize (H F3_0 F3_0 F3_2). unfold magma_op, refa161_inst, refa161_op in H. discriminate H. Qed.

(** ---- refa162 (Fin3) ---- *)

Definition refa162_op (x y : Fin3) : Fin3 :=
  match x, y with
  | F3_0, F3_0 => F3_0 | F3_0, F3_1 => F3_0 | F3_0, F3_2 => F3_0
  | F3_1, F3_0 => F3_2 | F3_1, F3_1 => F3_0 | F3_1, F3_2 => F3_2
  | F3_2, F3_0 => F3_1 | F3_2, F3_1 => F3_1 | F3_2, F3_2 => F3_0
  end.

#[local] Instance refa162_inst : Magma Fin3 := {| magma_op := refa162_op |}.

Lemma refa162_sat1843 : @Equation1843 Fin3 refa162_inst.
Proof. unfold Equation1843, magma_op, refa162_inst, refa162_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa162_sat1845 : @Equation1845 Fin3 refa162_inst.
Proof. unfold Equation1845, magma_op, refa162_inst, refa162_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa162_sat1863 : @Equation1863 Fin3 refa162_inst.
Proof. unfold Equation1863, magma_op, refa162_inst, refa162_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa162_sat2462 : @Equation2462 Fin3 refa162_inst.
Proof. unfold Equation2462, magma_op, refa162_inst, refa162_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa162_sat2472 : @Equation2472 Fin3 refa162_inst.
Proof. unfold Equation2472, magma_op, refa162_inst, refa162_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa162_not151 : ~ @Equation151 Fin3 refa162_inst.
Proof. unfold Equation151. intro H. specialize (H F3_1). unfold magma_op, refa162_inst, refa162_op in H. discriminate H. Qed.

Lemma refa162_not1426 : ~ @Equation1426 Fin3 refa162_inst.
Proof. unfold Equation1426. intro H. specialize (H F3_1). unfold magma_op, refa162_inst, refa162_op in H. discriminate H. Qed.

Lemma refa162_not1629 : ~ @Equation1629 Fin3 refa162_inst.
Proof. unfold Equation1629. intro H. specialize (H F3_1). unfold magma_op, refa162_inst, refa162_op in H. discriminate H. Qed.

Lemma refa162_not1833 : ~ @Equation1833 Fin3 refa162_inst.
Proof. unfold Equation1833. intro H. specialize (H F3_1 F3_0). unfold magma_op, refa162_inst, refa162_op in H. discriminate H. Qed.

Lemma refa162_not1838 : ~ @Equation1838 Fin3 refa162_inst.
Proof. unfold Equation1838. intro H. specialize (H F3_1 F3_0). unfold magma_op, refa162_inst, refa162_op in H. discriminate H. Qed.

Lemma refa162_not1847 : ~ @Equation1847 Fin3 refa162_inst.
Proof. unfold Equation1847. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa162_inst, refa162_op in H. discriminate H. Qed.

Lemma refa162_not1848 : ~ @Equation1848 Fin3 refa162_inst.
Proof. unfold Equation1848. intro H. specialize (H F3_1 F3_0). unfold magma_op, refa162_inst, refa162_op in H. discriminate H. Qed.

Lemma refa162_not1851 : ~ @Equation1851 Fin3 refa162_inst.
Proof. unfold Equation1851. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa162_inst, refa162_op in H. discriminate H. Qed.

Lemma refa162_not1858 : ~ @Equation1858 Fin3 refa162_inst.
Proof. unfold Equation1858. intro H. specialize (H F3_1 F3_0). unfold magma_op, refa162_inst, refa162_op in H. discriminate H. Qed.

Lemma refa162_not2035 : ~ @Equation2035 Fin3 refa162_inst.
Proof. unfold Equation2035. intro H. specialize (H F3_1). unfold magma_op, refa162_inst, refa162_op in H. discriminate H. Qed.

Lemma refa162_not2244 : ~ @Equation2244 Fin3 refa162_inst.
Proof. unfold Equation2244. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa162_inst, refa162_op in H. discriminate H. Qed.

Lemma refa162_not2247 : ~ @Equation2247 Fin3 refa162_inst.
Proof. unfold Equation2247. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa162_inst, refa162_op in H. discriminate H. Qed.

Lemma refa162_not2253 : ~ @Equation2253 Fin3 refa162_inst.
Proof. unfold Equation2253. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa162_inst, refa162_op in H. discriminate H. Qed.

Lemma refa162_not2254 : ~ @Equation2254 Fin3 refa162_inst.
Proof. unfold Equation2254. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa162_inst, refa162_op in H. discriminate H. Qed.

Lemma refa162_not2257 : ~ @Equation2257 Fin3 refa162_inst.
Proof. unfold Equation2257. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa162_inst, refa162_op in H. discriminate H. Qed.

Lemma refa162_not2264 : ~ @Equation2264 Fin3 refa162_inst.
Proof. unfold Equation2264. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa162_inst, refa162_op in H. discriminate H. Qed.

Lemma refa162_not2266 : ~ @Equation2266 Fin3 refa162_inst.
Proof. unfold Equation2266. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa162_inst, refa162_op in H. discriminate H. Qed.

Lemma refa162_not2444 : ~ @Equation2444 Fin3 refa162_inst.
Proof. unfold Equation2444. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa162_inst, refa162_op in H. discriminate H. Qed.

Lemma refa162_not2449 : ~ @Equation2449 Fin3 refa162_inst.
Proof. unfold Equation2449. intro H. specialize (H F3_1 F3_0). unfold magma_op, refa162_inst, refa162_op in H. discriminate H. Qed.

Lemma refa162_not2457 : ~ @Equation2457 Fin3 refa162_inst.
Proof. unfold Equation2457. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa162_inst, refa162_op in H. discriminate H. Qed.

Lemma refa162_not2460 : ~ @Equation2460 Fin3 refa162_inst.
Proof. unfold Equation2460. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa162_inst, refa162_op in H. discriminate H. Qed.

Lemma refa162_not2467 : ~ @Equation2467 Fin3 refa162_inst.
Proof. unfold Equation2467. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa162_inst, refa162_op in H. discriminate H. Qed.

Lemma refa162_not2644 : ~ @Equation2644 Fin3 refa162_inst.
Proof. unfold Equation2644. intro H. specialize (H F3_1). unfold magma_op, refa162_inst, refa162_op in H. discriminate H. Qed.

Lemma refa162_not3050 : ~ @Equation3050 Fin3 refa162_inst.
Proof. unfold Equation3050. intro H. specialize (H F3_1). unfold magma_op, refa162_inst, refa162_op in H. discriminate H. Qed.

Lemma refa162_not3253 : ~ @Equation3253 Fin3 refa162_inst.
Proof. unfold Equation3253. intro H. specialize (H F3_1). unfold magma_op, refa162_inst, refa162_op in H. discriminate H. Qed.

Lemma refa162_not3456 : ~ @Equation3456 Fin3 refa162_inst.
Proof. unfold Equation3456. intro H. specialize (H F3_1). unfold magma_op, refa162_inst, refa162_op in H. discriminate H. Qed.

Lemma refa162_not3664 : ~ @Equation3664 Fin3 refa162_inst.
Proof. unfold Equation3664. intro H. specialize (H F3_1 F3_0). unfold magma_op, refa162_inst, refa162_op in H. discriminate H. Qed.

Lemma refa162_not3668 : ~ @Equation3668 Fin3 refa162_inst.
Proof. unfold Equation3668. intro H. specialize (H F3_1 F3_0). unfold magma_op, refa162_inst, refa162_op in H. discriminate H. Qed.

Lemma refa162_not3712 : ~ @Equation3712 Fin3 refa162_inst.
Proof. unfold Equation3712. intro H. specialize (H F3_1 F3_0). unfold magma_op, refa162_inst, refa162_op in H. discriminate H. Qed.

Lemma refa162_not3862 : ~ @Equation3862 Fin3 refa162_inst.
Proof. unfold Equation3862. intro H. specialize (H F3_1). unfold magma_op, refa162_inst, refa162_op in H. discriminate H. Qed.

Lemma refa162_not4071 : ~ @Equation4071 Fin3 refa162_inst.
Proof. unfold Equation4071. intro H. specialize (H F3_1 F3_0). unfold magma_op, refa162_inst, refa162_op in H. discriminate H. Qed.

Lemma refa162_not4074 : ~ @Equation4074 Fin3 refa162_inst.
Proof. unfold Equation4074. intro H. specialize (H F3_1 F3_0). unfold magma_op, refa162_inst, refa162_op in H. discriminate H. Qed.

Lemma refa162_not4118 : ~ @Equation4118 Fin3 refa162_inst.
Proof. unfold Equation4118. intro H. specialize (H F3_1 F3_0). unfold magma_op, refa162_inst, refa162_op in H. discriminate H. Qed.

Lemma refa162_not4120 : ~ @Equation4120 Fin3 refa162_inst.
Proof. unfold Equation4120. intro H. specialize (H F3_1 F3_0). unfold magma_op, refa162_inst, refa162_op in H. discriminate H. Qed.

Lemma refa162_not4121 : ~ @Equation4121 Fin3 refa162_inst.
Proof. unfold Equation4121. intro H. specialize (H F3_1 F3_0). unfold magma_op, refa162_inst, refa162_op in H. discriminate H. Qed.

Lemma refa162_not4127 : ~ @Equation4127 Fin3 refa162_inst.
Proof. unfold Equation4127. intro H. specialize (H F3_1 F3_0). unfold magma_op, refa162_inst, refa162_op in H. discriminate H. Qed.

Lemma refa162_not4130 : ~ @Equation4130 Fin3 refa162_inst.
Proof. unfold Equation4130. intro H. specialize (H F3_1 F3_0). unfold magma_op, refa162_inst, refa162_op in H. discriminate H. Qed.

Lemma refa162_not4131 : ~ @Equation4131 Fin3 refa162_inst.
Proof. unfold Equation4131. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa162_inst, refa162_op in H. discriminate H. Qed.

Lemma refa162_not4269 : ~ @Equation4269 Fin3 refa162_inst.
Proof. unfold Equation4269. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa162_inst, refa162_op in H. discriminate H. Qed.

Lemma refa162_not4283 : ~ @Equation4283 Fin3 refa162_inst.
Proof. unfold Equation4283. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa162_inst, refa162_op in H. discriminate H. Qed.

Lemma refa162_not4314 : ~ @Equation4314 Fin3 refa162_inst.
Proof. unfold Equation4314. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa162_inst, refa162_op in H. discriminate H. Qed.

Lemma refa162_not4380 : ~ @Equation4380 Fin3 refa162_inst.
Proof. unfold Equation4380. intro H. specialize (H F3_1). unfold magma_op, refa162_inst, refa162_op in H. discriminate H. Qed.

Lemma refa162_not4584 : ~ @Equation4584 Fin3 refa162_inst.
Proof. unfold Equation4584. intro H. specialize (H F3_1 F3_0). unfold magma_op, refa162_inst, refa162_op in H. discriminate H. Qed.

Lemma refa162_not4585 : ~ @Equation4585 Fin3 refa162_inst.
Proof. unfold Equation4585. intro H. specialize (H F3_1 F3_0). unfold magma_op, refa162_inst, refa162_op in H. discriminate H. Qed.

Lemma refa162_not4598 : ~ @Equation4598 Fin3 refa162_inst.
Proof. unfold Equation4598. intro H. specialize (H F3_1 F3_0). unfold magma_op, refa162_inst, refa162_op in H. discriminate H. Qed.

Lemma refa162_not4599 : ~ @Equation4599 Fin3 refa162_inst.
Proof. unfold Equation4599. intro H. specialize (H F3_1 F3_0). unfold magma_op, refa162_inst, refa162_op in H. discriminate H. Qed.

Lemma refa162_not4629 : ~ @Equation4629 Fin3 refa162_inst.
Proof. unfold Equation4629. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa162_inst, refa162_op in H. discriminate H. Qed.

(** ---- refa163 (Fin3) ---- *)

Definition refa163_op (x y : Fin3) : Fin3 :=
  match x, y with
  | F3_0, F3_0 => F3_0 | F3_0, F3_1 => F3_0 | F3_0, F3_2 => F3_2
  | F3_1, F3_0 => F3_0 | F3_1, F3_1 => F3_2 | F3_1, F3_2 => F3_0
  | F3_2, F3_0 => F3_0 | F3_2, F3_1 => F3_0 | F3_2, F3_2 => F3_2
  end.

#[local] Instance refa163_inst : Magma Fin3 := {| magma_op := refa163_op |}.

Lemma refa163_sat3837 : @Equation3837 Fin3 refa163_inst.
Proof. unfold Equation3837, magma_op, refa163_inst, refa163_op. intros x y z w. destruct x, y, z, w; reflexivity. Qed.

Lemma refa163_sat4391 : @Equation4391 Fin3 refa163_inst.
Proof. unfold Equation4391, magma_op, refa163_inst, refa163_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa163_not3253 : ~ @Equation3253 Fin3 refa163_inst.
Proof. unfold Equation3253. intro H. specialize (H F3_1). unfold magma_op, refa163_inst, refa163_op in H. discriminate H. Qed.

Lemma refa163_not3456 : ~ @Equation3456 Fin3 refa163_inst.
Proof. unfold Equation3456. intro H. specialize (H F3_1). unfold magma_op, refa163_inst, refa163_op in H. discriminate H. Qed.

Lemma refa163_not3661 : ~ @Equation3661 Fin3 refa163_inst.
Proof. unfold Equation3661. intro H. specialize (H F3_1 F3_0). unfold magma_op, refa163_inst, refa163_op in H. discriminate H. Qed.

Lemma refa163_not3667 : ~ @Equation3667 Fin3 refa163_inst.
Proof. unfold Equation3667. intro H. specialize (H F3_1 F3_0). unfold magma_op, refa163_inst, refa163_op in H. discriminate H. Qed.

Lemma refa163_not3677 : ~ @Equation3677 Fin3 refa163_inst.
Proof. unfold Equation3677. intro H. specialize (H F3_1 F3_0). unfold magma_op, refa163_inst, refa163_op in H. discriminate H. Qed.

Lemma refa163_not3752 : ~ @Equation3752 Fin3 refa163_inst.
Proof. unfold Equation3752. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa163_inst, refa163_op in H. discriminate H. Qed.

Lemma refa163_not3862 : ~ @Equation3862 Fin3 refa163_inst.
Proof. unfold Equation3862. intro H. specialize (H F3_1). unfold magma_op, refa163_inst, refa163_op in H. discriminate H. Qed.

Lemma refa163_not4065 : ~ @Equation4065 Fin3 refa163_inst.
Proof. unfold Equation4065. intro H. specialize (H F3_1). unfold magma_op, refa163_inst, refa163_op in H. discriminate H. Qed.

Lemma refa163_not4269 : ~ @Equation4269 Fin3 refa163_inst.
Proof. unfold Equation4269. intro H. specialize (H F3_2 F3_1). unfold magma_op, refa163_inst, refa163_op in H. discriminate H. Qed.

Lemma refa163_not4272 : ~ @Equation4272 Fin3 refa163_inst.
Proof. unfold Equation4272. intro H. specialize (H F3_1 F3_0). unfold magma_op, refa163_inst, refa163_op in H. discriminate H. Qed.

Lemma refa163_not4284 : ~ @Equation4284 Fin3 refa163_inst.
Proof. unfold Equation4284. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa163_inst, refa163_op in H. discriminate H. Qed.

Lemma refa163_not4320 : ~ @Equation4320 Fin3 refa163_inst.
Proof. unfold Equation4320. intro H. specialize (H F3_1 F3_0). unfold magma_op, refa163_inst, refa163_op in H. discriminate H. Qed.

(** ---- refa164 (Fin3) ---- *)

Definition refa164_op (x y : Fin3) : Fin3 :=
  match x, y with
  | F3_0, F3_0 => F3_0 | F3_0, F3_1 => F3_0 | F3_0, F3_2 => F3_0
  | F3_1, F3_0 => F3_1 | F3_1, F3_1 => F3_1 | F3_1, F3_2 => F3_0
  | F3_2, F3_0 => F3_1 | F3_2, F3_1 => F3_2 | F3_2, F3_2 => F3_0
  end.

#[local] Instance refa164_inst : Magma Fin3 := {| magma_op := refa164_op |}.

Lemma refa164_sat621 : @Equation621 Fin3 refa164_inst.
Proof. unfold Equation621, magma_op, refa164_inst, refa164_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa164_sat3928 : @Equation3928 Fin3 refa164_inst.
Proof. unfold Equation3928, magma_op, refa164_inst, refa164_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa164_not50 : ~ @Equation50 Fin3 refa164_inst.
Proof. unfold Equation50. intro H. specialize (H F3_2 F3_1). unfold magma_op, refa164_inst, refa164_op in H. discriminate H. Qed.

Lemma refa164_not56 : ~ @Equation56 Fin3 refa164_inst.
Proof. unfold Equation56. intro H. specialize (H F3_2 F3_0). unfold magma_op, refa164_inst, refa164_op in H. discriminate H. Qed.

Lemma refa164_not99 : ~ @Equation99 Fin3 refa164_inst.
Proof. unfold Equation99. intro H. specialize (H F3_2). unfold magma_op, refa164_inst, refa164_op in H. discriminate H. Qed.

Lemma refa164_not151 : ~ @Equation151 Fin3 refa164_inst.
Proof. unfold Equation151. intro H. specialize (H F3_2). unfold magma_op, refa164_inst, refa164_op in H. discriminate H. Qed.

Lemma refa164_not203 : ~ @Equation203 Fin3 refa164_inst.
Proof. unfold Equation203. intro H. specialize (H F3_2). unfold magma_op, refa164_inst, refa164_op in H. discriminate H. Qed.

Lemma refa164_not255 : ~ @Equation255 Fin3 refa164_inst.
Proof. unfold Equation255. intro H. specialize (H F3_2). unfold magma_op, refa164_inst, refa164_op in H. discriminate H. Qed.

Lemma refa164_not411 : ~ @Equation411 Fin3 refa164_inst.
Proof. unfold Equation411. intro H. specialize (H F3_2). unfold magma_op, refa164_inst, refa164_op in H. discriminate H. Qed.

Lemma refa164_not623 : ~ @Equation623 Fin3 refa164_inst.
Proof. unfold Equation623. intro H. specialize (H F3_2 F3_1). unfold magma_op, refa164_inst, refa164_op in H. discriminate H. Qed.

Lemma refa164_not629 : ~ @Equation629 Fin3 refa164_inst.
Proof. unfold Equation629. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa164_inst, refa164_op in H. discriminate H. Qed.

Lemma refa164_not630 : ~ @Equation630 Fin3 refa164_inst.
Proof. unfold Equation630. intro H. specialize (H F3_2 F3_0). unfold magma_op, refa164_inst, refa164_op in H. discriminate H. Qed.

Lemma refa164_not632 : ~ @Equation632 Fin3 refa164_inst.
Proof. unfold Equation632. intro H. specialize (H F3_2 F3_0). unfold magma_op, refa164_inst, refa164_op in H. discriminate H. Qed.

Lemma refa164_not633 : ~ @Equation633 Fin3 refa164_inst.
Proof. unfold Equation633. intro H. specialize (H F3_2 F3_0). unfold magma_op, refa164_inst, refa164_op in H. discriminate H. Qed.

Lemma refa164_not639 : ~ @Equation639 Fin3 refa164_inst.
Proof. unfold Equation639. intro H. specialize (H F3_2 F3_0). unfold magma_op, refa164_inst, refa164_op in H. discriminate H. Qed.

Lemma refa164_not640 : ~ @Equation640 Fin3 refa164_inst.
Proof. unfold Equation640. intro H. specialize (H F3_2 F3_0). unfold magma_op, refa164_inst, refa164_op in H. discriminate H. Qed.

Lemma refa164_not642 : ~ @Equation642 Fin3 refa164_inst.
Proof. unfold Equation642. intro H. specialize (H F3_2 F3_0). unfold magma_op, refa164_inst, refa164_op in H. discriminate H. Qed.

Lemma refa164_not643 : ~ @Equation643 Fin3 refa164_inst.
Proof. unfold Equation643. intro H. specialize (H F3_2 F3_0). unfold magma_op, refa164_inst, refa164_op in H. discriminate H. Qed.

Lemma refa164_not669 : ~ @Equation669 Fin3 refa164_inst.
Proof. unfold Equation669. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa164_inst, refa164_op in H. discriminate H. Qed.

Lemma refa164_not676 : ~ @Equation676 Fin3 refa164_inst.
Proof. unfold Equation676. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa164_inst, refa164_op in H. discriminate H. Qed.

Lemma refa164_not680 : ~ @Equation680 Fin3 refa164_inst.
Proof. unfold Equation680. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa164_inst, refa164_op in H. discriminate H. Qed.

Lemma refa164_not707 : ~ @Equation707 Fin3 refa164_inst.
Proof. unfold Equation707. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa164_inst, refa164_op in H. discriminate H. Qed.

Lemma refa164_not817 : ~ @Equation817 Fin3 refa164_inst.
Proof. unfold Equation817. intro H. specialize (H F3_2). unfold magma_op, refa164_inst, refa164_op in H. discriminate H. Qed.

Lemma refa164_not1020 : ~ @Equation1020 Fin3 refa164_inst.
Proof. unfold Equation1020. intro H. specialize (H F3_2). unfold magma_op, refa164_inst, refa164_op in H. discriminate H. Qed.

Lemma refa164_not1223 : ~ @Equation1223 Fin3 refa164_inst.
Proof. unfold Equation1223. intro H. specialize (H F3_2). unfold magma_op, refa164_inst, refa164_op in H. discriminate H. Qed.

Lemma refa164_not1426 : ~ @Equation1426 Fin3 refa164_inst.
Proof. unfold Equation1426. intro H. specialize (H F3_2). unfold magma_op, refa164_inst, refa164_op in H. discriminate H. Qed.

Lemma refa164_not1629 : ~ @Equation1629 Fin3 refa164_inst.
Proof. unfold Equation1629. intro H. specialize (H F3_2). unfold magma_op, refa164_inst, refa164_op in H. discriminate H. Qed.

Lemma refa164_not1832 : ~ @Equation1832 Fin3 refa164_inst.
Proof. unfold Equation1832. intro H. specialize (H F3_2). unfold magma_op, refa164_inst, refa164_op in H. discriminate H. Qed.

Lemma refa164_not2035 : ~ @Equation2035 Fin3 refa164_inst.
Proof. unfold Equation2035. intro H. specialize (H F3_2). unfold magma_op, refa164_inst, refa164_op in H. discriminate H. Qed.

Lemma refa164_not2238 : ~ @Equation2238 Fin3 refa164_inst.
Proof. unfold Equation2238. intro H. specialize (H F3_2). unfold magma_op, refa164_inst, refa164_op in H. discriminate H. Qed.

Lemma refa164_not2441 : ~ @Equation2441 Fin3 refa164_inst.
Proof. unfold Equation2441. intro H. specialize (H F3_2). unfold magma_op, refa164_inst, refa164_op in H. discriminate H. Qed.

Lemma refa164_not2644 : ~ @Equation2644 Fin3 refa164_inst.
Proof. unfold Equation2644. intro H. specialize (H F3_2). unfold magma_op, refa164_inst, refa164_op in H. discriminate H. Qed.

Lemma refa164_not2847 : ~ @Equation2847 Fin3 refa164_inst.
Proof. unfold Equation2847. intro H. specialize (H F3_2). unfold magma_op, refa164_inst, refa164_op in H. discriminate H. Qed.

Lemma refa164_not3050 : ~ @Equation3050 Fin3 refa164_inst.
Proof. unfold Equation3050. intro H. specialize (H F3_2). unfold magma_op, refa164_inst, refa164_op in H. discriminate H. Qed.

Lemma refa164_not3253 : ~ @Equation3253 Fin3 refa164_inst.
Proof. unfold Equation3253. intro H. specialize (H F3_2). unfold magma_op, refa164_inst, refa164_op in H. discriminate H. Qed.

Lemma refa164_not3456 : ~ @Equation3456 Fin3 refa164_inst.
Proof. unfold Equation3456. intro H. specialize (H F3_2). unfold magma_op, refa164_inst, refa164_op in H. discriminate H. Qed.

Lemma refa164_not3661 : ~ @Equation3661 Fin3 refa164_inst.
Proof. unfold Equation3661. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa164_inst, refa164_op in H. discriminate H. Qed.

Lemma refa164_not3664 : ~ @Equation3664 Fin3 refa164_inst.
Proof. unfold Equation3664. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa164_inst, refa164_op in H. discriminate H. Qed.

Lemma refa164_not3665 : ~ @Equation3665 Fin3 refa164_inst.
Proof. unfold Equation3665. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa164_inst, refa164_op in H. discriminate H. Qed.

Lemma refa164_not3667 : ~ @Equation3667 Fin3 refa164_inst.
Proof. unfold Equation3667. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa164_inst, refa164_op in H. discriminate H. Qed.

Lemma refa164_not3668 : ~ @Equation3668 Fin3 refa164_inst.
Proof. unfold Equation3668. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa164_inst, refa164_op in H. discriminate H. Qed.

Lemma refa164_not3712 : ~ @Equation3712 Fin3 refa164_inst.
Proof. unfold Equation3712. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa164_inst, refa164_op in H. discriminate H. Qed.

Lemma refa164_not3714 : ~ @Equation3714 Fin3 refa164_inst.
Proof. unfold Equation3714. intro H. specialize (H F3_2 F3_0). unfold magma_op, refa164_inst, refa164_op in H. discriminate H. Qed.

Lemma refa164_not3721 : ~ @Equation3721 Fin3 refa164_inst.
Proof. unfold Equation3721. intro H. specialize (H F3_2 F3_1). unfold magma_op, refa164_inst, refa164_op in H. discriminate H. Qed.

Lemma refa164_not3722 : ~ @Equation3722 Fin3 refa164_inst.
Proof. unfold Equation3722. intro H. specialize (H F3_2 F3_1). unfold magma_op, refa164_inst, refa164_op in H. discriminate H. Qed.

Lemma refa164_not3724 : ~ @Equation3724 Fin3 refa164_inst.
Proof. unfold Equation3724. intro H. specialize (H F3_2 F3_1). unfold magma_op, refa164_inst, refa164_op in H. discriminate H. Qed.

Lemma refa164_not3865 : ~ @Equation3865 Fin3 refa164_inst.
Proof. unfold Equation3865. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa164_inst, refa164_op in H. discriminate H. Qed.

Lemma refa164_not3867 : ~ @Equation3867 Fin3 refa164_inst.
Proof. unfold Equation3867. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa164_inst, refa164_op in H. discriminate H. Qed.

Lemma refa164_not3868 : ~ @Equation3868 Fin3 refa164_inst.
Proof. unfold Equation3868. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa164_inst, refa164_op in H. discriminate H. Qed.

Lemma refa164_not3871 : ~ @Equation3871 Fin3 refa164_inst.
Proof. unfold Equation3871. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa164_inst, refa164_op in H. discriminate H. Qed.

Lemma refa164_not3878 : ~ @Equation3878 Fin3 refa164_inst.
Proof. unfold Equation3878. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa164_inst, refa164_op in H. discriminate H. Qed.

Lemma refa164_not3880 : ~ @Equation3880 Fin3 refa164_inst.
Proof. unfold Equation3880. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa164_inst, refa164_op in H. discriminate H. Qed.

Lemma refa164_not3887 : ~ @Equation3887 Fin3 refa164_inst.
Proof. unfold Equation3887. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa164_inst, refa164_op in H. discriminate H. Qed.

Lemma refa164_not3915 : ~ @Equation3915 Fin3 refa164_inst.
Proof. unfold Equation3915. intro H. specialize (H F3_2 F3_1). unfold magma_op, refa164_inst, refa164_op in H. discriminate H. Qed.

Lemma refa164_not3917 : ~ @Equation3917 Fin3 refa164_inst.
Proof. unfold Equation3917. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa164_inst, refa164_op in H. discriminate H. Qed.

Lemma refa164_not3927 : ~ @Equation3927 Fin3 refa164_inst.
Proof. unfold Equation3927. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa164_inst, refa164_op in H. discriminate H. Qed.

Lemma refa164_not3955 : ~ @Equation3955 Fin3 refa164_inst.
Proof. unfold Equation3955. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa164_inst, refa164_op in H. discriminate H. Qed.

Lemma refa164_not3962 : ~ @Equation3962 Fin3 refa164_inst.
Proof. unfold Equation3962. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa164_inst, refa164_op in H. discriminate H. Qed.

Lemma refa164_not3964 : ~ @Equation3964 Fin3 refa164_inst.
Proof. unfold Equation3964. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa164_inst, refa164_op in H. discriminate H. Qed.

Lemma refa164_not4066 : ~ @Equation4066 Fin3 refa164_inst.
Proof. unfold Equation4066. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa164_inst, refa164_op in H. discriminate H. Qed.

Lemma refa164_not4067 : ~ @Equation4067 Fin3 refa164_inst.
Proof. unfold Equation4067. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa164_inst, refa164_op in H. discriminate H. Qed.

Lemma refa164_not4068 : ~ @Equation4068 Fin3 refa164_inst.
Proof. unfold Equation4068. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa164_inst, refa164_op in H. discriminate H. Qed.

Lemma refa164_not4070 : ~ @Equation4070 Fin3 refa164_inst.
Proof. unfold Equation4070. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa164_inst, refa164_op in H. discriminate H. Qed.

Lemma refa164_not4071 : ~ @Equation4071 Fin3 refa164_inst.
Proof. unfold Equation4071. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa164_inst, refa164_op in H. discriminate H. Qed.

Lemma refa164_not4073 : ~ @Equation4073 Fin3 refa164_inst.
Proof. unfold Equation4073. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa164_inst, refa164_op in H. discriminate H. Qed.

Lemma refa164_not4074 : ~ @Equation4074 Fin3 refa164_inst.
Proof. unfold Equation4074. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa164_inst, refa164_op in H. discriminate H. Qed.

Lemma refa164_not4120 : ~ @Equation4120 Fin3 refa164_inst.
Proof. unfold Equation4120. intro H. specialize (H F3_2 F3_0). unfold magma_op, refa164_inst, refa164_op in H. discriminate H. Qed.

Lemma refa164_not4127 : ~ @Equation4127 Fin3 refa164_inst.
Proof. unfold Equation4127. intro H. specialize (H F3_2 F3_0). unfold magma_op, refa164_inst, refa164_op in H. discriminate H. Qed.

Lemma refa164_not4130 : ~ @Equation4130 Fin3 refa164_inst.
Proof. unfold Equation4130. intro H. specialize (H F3_2 F3_0). unfold magma_op, refa164_inst, refa164_op in H. discriminate H. Qed.

Lemma refa164_not4268 : ~ @Equation4268 Fin3 refa164_inst.
Proof. unfold Equation4268. intro H. specialize (H F3_2 F3_0). unfold magma_op, refa164_inst, refa164_op in H. discriminate H. Qed.

Lemma refa164_not4269 : ~ @Equation4269 Fin3 refa164_inst.
Proof. unfold Equation4269. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa164_inst, refa164_op in H. discriminate H. Qed.

Lemma refa164_not4270 : ~ @Equation4270 Fin3 refa164_inst.
Proof. unfold Equation4270. intro H. specialize (H F3_2 F3_1). unfold magma_op, refa164_inst, refa164_op in H. discriminate H. Qed.

Lemma refa164_not4283 : ~ @Equation4283 Fin3 refa164_inst.
Proof. unfold Equation4283. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa164_inst, refa164_op in H. discriminate H. Qed.

Lemma refa164_not4284 : ~ @Equation4284 Fin3 refa164_inst.
Proof. unfold Equation4284. intro H. specialize (H F3_2 F3_0). unfold magma_op, refa164_inst, refa164_op in H. discriminate H. Qed.

Lemma refa164_not4314 : ~ @Equation4314 Fin3 refa164_inst.
Proof. unfold Equation4314. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa164_inst, refa164_op in H. discriminate H. Qed.

Lemma refa164_not4380 : ~ @Equation4380 Fin3 refa164_inst.
Proof. unfold Equation4380. intro H. specialize (H F3_2). unfold magma_op, refa164_inst, refa164_op in H. discriminate H. Qed.

Lemma refa164_not4583 : ~ @Equation4583 Fin3 refa164_inst.
Proof. unfold Equation4583. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa164_inst, refa164_op in H. discriminate H. Qed.

Lemma refa164_not4584 : ~ @Equation4584 Fin3 refa164_inst.
Proof. unfold Equation4584. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa164_inst, refa164_op in H. discriminate H. Qed.

Lemma refa164_not4585 : ~ @Equation4585 Fin3 refa164_inst.
Proof. unfold Equation4585. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa164_inst, refa164_op in H. discriminate H. Qed.

Lemma refa164_not4629 : ~ @Equation4629 Fin3 refa164_inst.
Proof. unfold Equation4629. intro H. specialize (H F3_2 F3_0). unfold magma_op, refa164_inst, refa164_op in H. discriminate H. Qed.

(** ---- refa165 (Fin3) ---- *)

Definition refa165_op (x y : Fin3) : Fin3 :=
  match x, y with
  | F3_0, F3_0 => F3_0 | F3_0, F3_1 => F3_0 | F3_0, F3_2 => F3_1
  | F3_1, F3_0 => F3_1 | F3_1, F3_1 => F3_0 | F3_1, F3_2 => F3_1
  | F3_2, F3_0 => F3_2 | F3_2, F3_1 => F3_2 | F3_2, F3_2 => F3_0
  end.

#[local] Instance refa165_inst : Magma Fin3 := {| magma_op := refa165_op |}.

Lemma refa165_sat844 : @Equation844 Fin3 refa165_inst.
Proof. unfold Equation844, magma_op, refa165_inst, refa165_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa165_not1023 : ~ @Equation1023 Fin3 refa165_inst.
Proof. unfold Equation1023. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa165_inst, refa165_op in H. discriminate H. Qed.

Lemma refa165_not1226 : ~ @Equation1226 Fin3 refa165_inst.
Proof. unfold Equation1226. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa165_inst, refa165_op in H. discriminate H. Qed.

Lemma refa165_not1252 : ~ @Equation1252 Fin3 refa165_inst.
Proof. unfold Equation1252. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa165_inst, refa165_op in H. discriminate H. Qed.

(** ---- refa166 (Fin3) ---- *)

Definition refa166_op (x y : Fin3) : Fin3 :=
  match x, y with
  | F3_0, F3_0 => F3_0 | F3_0, F3_1 => F3_0 | F3_0, F3_2 => F3_1
  | F3_1, F3_0 => F3_1 | F3_1, F3_1 => F3_0 | F3_1, F3_2 => F3_2
  | F3_2, F3_0 => F3_1 | F3_2, F3_1 => F3_2 | F3_2, F3_2 => F3_0
  end.

#[local] Instance refa166_inst : Magma Fin3 := {| magma_op := refa166_op |}.

Lemma refa166_sat107 : @Equation107 Fin3 refa166_inst.
Proof. unfold Equation107, magma_op, refa166_inst, refa166_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa166_not1020 : ~ @Equation1020 Fin3 refa166_inst.
Proof. unfold Equation1020. intro H. specialize (H F3_2). unfold magma_op, refa166_inst, refa166_op in H. discriminate H. Qed.

Lemma refa166_not1223 : ~ @Equation1223 Fin3 refa166_inst.
Proof. unfold Equation1223. intro H. specialize (H F3_2). unfold magma_op, refa166_inst, refa166_op in H. discriminate H. Qed.

Lemma refa166_not1832 : ~ @Equation1832 Fin3 refa166_inst.
Proof. unfold Equation1832. intro H. specialize (H F3_2). unfold magma_op, refa166_inst, refa166_op in H. discriminate H. Qed.

(** ---- refa167 (Fin3) ---- *)

Definition refa167_op (x y : Fin3) : Fin3 :=
  match x, y with
  | F3_0, F3_0 => F3_0 | F3_0, F3_1 => F3_0 | F3_0, F3_2 => F3_0
  | F3_1, F3_0 => F3_0 | F3_1, F3_1 => F3_0 | F3_1, F3_2 => F3_0
  | F3_2, F3_0 => F3_2 | F3_2, F3_1 => F3_0 | F3_2, F3_2 => F3_2
  end.

#[local] Instance refa167_inst : Magma Fin3 := {| magma_op := refa167_op |}.

Lemma refa167_sat311 : @Equation311 Fin3 refa167_inst.
Proof. unfold Equation311, magma_op, refa167_inst, refa167_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa167_not4584 : ~ @Equation4584 Fin3 refa167_inst.
Proof. unfold Equation4584. intro H. specialize (H F3_2 F3_1). unfold magma_op, refa167_inst, refa167_op in H. discriminate H. Qed.

(** ---- refa168 (Fin3) ---- *)

Definition refa168_op (x y : Fin3) : Fin3 :=
  match x, y with
  | F3_0, F3_0 => F3_0 | F3_0, F3_1 => F3_0 | F3_0, F3_2 => F3_1
  | F3_1, F3_0 => F3_1 | F3_1, F3_1 => F3_1 | F3_1, F3_2 => F3_0
  | F3_2, F3_0 => F3_1 | F3_2, F3_1 => F3_2 | F3_2, F3_2 => F3_2
  end.

#[local] Instance refa168_inst : Magma Fin3 := {| magma_op := refa168_op |}.

Lemma refa168_sat829 : @Equation829 Fin3 refa168_inst.
Proof. unfold Equation829, magma_op, refa168_inst, refa168_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa168_sat1236 : @Equation1236 Fin3 refa168_inst.
Proof. unfold Equation1236, magma_op, refa168_inst, refa168_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa168_not377 : ~ @Equation377 Fin3 refa168_inst.
Proof. unfold Equation377. intro H. specialize (H F3_2 F3_0). unfold magma_op, refa168_inst, refa168_op in H. discriminate H. Qed.

Lemma refa168_not378 : ~ @Equation378 Fin3 refa168_inst.
Proof. unfold Equation378. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa168_inst, refa168_op in H. discriminate H. Qed.

Lemma refa168_not822 : ~ @Equation822 Fin3 refa168_inst.
Proof. unfold Equation822. intro H. specialize (H F3_2 F3_0). unfold magma_op, refa168_inst, refa168_op in H. discriminate H. Qed.

Lemma refa168_not1025 : ~ @Equation1025 Fin3 refa168_inst.
Proof. unfold Equation1025. intro H. specialize (H F3_2 F3_1). unfold magma_op, refa168_inst, refa168_op in H. discriminate H. Qed.

Lemma refa168_not1028 : ~ @Equation1028 Fin3 refa168_inst.
Proof. unfold Equation1028. intro H. specialize (H F3_2 F3_0). unfold magma_op, refa168_inst, refa168_op in H. discriminate H. Qed.

Lemma refa168_not1225 : ~ @Equation1225 Fin3 refa168_inst.
Proof. unfold Equation1225. intro H. specialize (H F3_2 F3_0). unfold magma_op, refa168_inst, refa168_op in H. discriminate H. Qed.

Lemma refa168_not1229 : ~ @Equation1229 Fin3 refa168_inst.
Proof. unfold Equation1229. intro H. specialize (H F3_2 F3_0). unfold magma_op, refa168_inst, refa168_op in H. discriminate H. Qed.

Lemma refa168_not1231 : ~ @Equation1231 Fin3 refa168_inst.
Proof. unfold Equation1231. intro H. specialize (H F3_2 F3_0). unfold magma_op, refa168_inst, refa168_op in H. discriminate H. Qed.

Lemma refa168_not1631 : ~ @Equation1631 Fin3 refa168_inst.
Proof. unfold Equation1631. intro H. specialize (H F3_2 F3_0). unfold magma_op, refa168_inst, refa168_op in H. discriminate H. Qed.

Lemma refa168_not2446 : ~ @Equation2446 Fin3 refa168_inst.
Proof. unfold Equation2446. intro H. specialize (H F3_2 F3_0). unfold magma_op, refa168_inst, refa168_op in H. discriminate H. Qed.

Lemma refa168_not3315 : ~ @Equation3315 Fin3 refa168_inst.
Proof. unfold Equation3315. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa168_inst, refa168_op in H. discriminate H. Qed.

Lemma refa168_not3316 : ~ @Equation3316 Fin3 refa168_inst.
Proof. unfold Equation3316. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa168_inst, refa168_op in H. discriminate H. Qed.

Lemma refa168_not3458 : ~ @Equation3458 Fin3 refa168_inst.
Proof. unfold Equation3458. intro H. specialize (H F3_2 F3_0). unfold magma_op, refa168_inst, refa168_op in H. discriminate H. Qed.

Lemma refa168_not3518 : ~ @Equation3518 Fin3 refa168_inst.
Proof. unfold Equation3518. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa168_inst, refa168_op in H. discriminate H. Qed.

Lemma refa168_not3519 : ~ @Equation3519 Fin3 refa168_inst.
Proof. unfold Equation3519. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa168_inst, refa168_op in H. discriminate H. Qed.

Lemma refa168_not3521 : ~ @Equation3521 Fin3 refa168_inst.
Proof. unfold Equation3521. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa168_inst, refa168_op in H. discriminate H. Qed.

Lemma refa168_not3714 : ~ @Equation3714 Fin3 refa168_inst.
Proof. unfold Equation3714. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa168_inst, refa168_op in H. discriminate H. Qed.

Lemma refa168_not3721 : ~ @Equation3721 Fin3 refa168_inst.
Proof. unfold Equation3721. intro H. specialize (H F3_2 F3_0). unfold magma_op, refa168_inst, refa168_op in H. discriminate H. Qed.

Lemma refa168_not3724 : ~ @Equation3724 Fin3 refa168_inst.
Proof. unfold Equation3724. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa168_inst, refa168_op in H. discriminate H. Qed.

Lemma refa168_not3725 : ~ @Equation3725 Fin3 refa168_inst.
Proof. unfold Equation3725. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa168_inst, refa168_op in H. discriminate H. Qed.

Lemma refa168_not3924 : ~ @Equation3924 Fin3 refa168_inst.
Proof. unfold Equation3924. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa168_inst, refa168_op in H. discriminate H. Qed.

Lemma refa168_not3925 : ~ @Equation3925 Fin3 refa168_inst.
Proof. unfold Equation3925. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa168_inst, refa168_op in H. discriminate H. Qed.

Lemma refa168_not3927 : ~ @Equation3927 Fin3 refa168_inst.
Proof. unfold Equation3927. intro H. specialize (H F3_2 F3_0). unfold magma_op, refa168_inst, refa168_op in H. discriminate H. Qed.

Lemma refa168_not3928 : ~ @Equation3928 Fin3 refa168_inst.
Proof. unfold Equation3928. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa168_inst, refa168_op in H. discriminate H. Qed.

Lemma refa168_not4067 : ~ @Equation4067 Fin3 refa168_inst.
Proof. unfold Equation4067. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa168_inst, refa168_op in H. discriminate H. Qed.

Lemma refa168_not4120 : ~ @Equation4120 Fin3 refa168_inst.
Proof. unfold Equation4120. intro H. specialize (H F3_2 F3_0). unfold magma_op, refa168_inst, refa168_op in H. discriminate H. Qed.

Lemma refa168_not4121 : ~ @Equation4121 Fin3 refa168_inst.
Proof. unfold Equation4121. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa168_inst, refa168_op in H. discriminate H. Qed.

Lemma refa168_not4128 : ~ @Equation4128 Fin3 refa168_inst.
Proof. unfold Equation4128. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa168_inst, refa168_op in H. discriminate H. Qed.

Lemma refa168_not4130 : ~ @Equation4130 Fin3 refa168_inst.
Proof. unfold Equation4130. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa168_inst, refa168_op in H. discriminate H. Qed.

Lemma refa168_not4314 : ~ @Equation4314 Fin3 refa168_inst.
Proof. unfold Equation4314. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa168_inst, refa168_op in H. discriminate H. Qed.

Lemma refa168_not4433 : ~ @Equation4433 Fin3 refa168_inst.
Proof. unfold Equation4433. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa168_inst, refa168_op in H. discriminate H. Qed.

Lemma refa168_not4435 : ~ @Equation4435 Fin3 refa168_inst.
Proof. unfold Equation4435. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa168_inst, refa168_op in H. discriminate H. Qed.

Lemma refa168_not4436 : ~ @Equation4436 Fin3 refa168_inst.
Proof. unfold Equation4436. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa168_inst, refa168_op in H. discriminate H. Qed.

Lemma refa168_not4472 : ~ @Equation4472 Fin3 refa168_inst.
Proof. unfold Equation4472. intro H. specialize (H F3_2 F3_0). unfold magma_op, refa168_inst, refa168_op in H. discriminate H. Qed.

Lemma refa168_not4473 : ~ @Equation4473 Fin3 refa168_inst.
Proof. unfold Equation4473. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa168_inst, refa168_op in H. discriminate H. Qed.

Lemma refa168_not4598 : ~ @Equation4598 Fin3 refa168_inst.
Proof. unfold Equation4598. intro H. specialize (H F3_2 F3_0). unfold magma_op, refa168_inst, refa168_op in H. discriminate H. Qed.

Lemma refa168_not4599 : ~ @Equation4599 Fin3 refa168_inst.
Proof. unfold Equation4599. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa168_inst, refa168_op in H. discriminate H. Qed.

Lemma refa168_not4629 : ~ @Equation4629 Fin3 refa168_inst.
Proof. unfold Equation4629. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa168_inst, refa168_op in H. discriminate H. Qed.

(** ---- refa169 (Fin3) ---- *)

Definition refa169_op (x y : Fin3) : Fin3 :=
  match x, y with
  | F3_0, F3_0 => F3_0 | F3_0, F3_1 => F3_0 | F3_0, F3_2 => F3_1
  | F3_1, F3_0 => F3_1 | F3_1, F3_1 => F3_1 | F3_1, F3_2 => F3_0
  | F3_2, F3_0 => F3_0 | F3_2, F3_1 => F3_0 | F3_2, F3_2 => F3_1
  end.

#[local] Instance refa169_inst : Magma Fin3 := {| magma_op := refa169_op |}.

Lemma refa169_sat3947 : @Equation3947 Fin3 refa169_inst.
Proof. unfold Equation3947, magma_op, refa169_inst, refa169_op. intros x y z w. destruct x, y, z, w; reflexivity. Qed.

Lemma refa169_sat4143 : @Equation4143 Fin3 refa169_inst.
Proof. unfold Equation4143, magma_op, refa169_inst, refa169_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa169_sat4521 : @Equation4521 Fin3 refa169_inst.
Proof. unfold Equation4521, magma_op, refa169_inst, refa169_op. intros x y z w. destruct x, y, z, w; reflexivity. Qed.

Lemma refa169_not359 : ~ @Equation359 Fin3 refa169_inst.
Proof. unfold Equation359. intro H. specialize (H F3_2). unfold magma_op, refa169_inst, refa169_op in H. discriminate H. Qed.

Lemma refa169_not3253 : ~ @Equation3253 Fin3 refa169_inst.
Proof. unfold Equation3253. intro H. specialize (H F3_2). unfold magma_op, refa169_inst, refa169_op in H. discriminate H. Qed.

Lemma refa169_not3456 : ~ @Equation3456 Fin3 refa169_inst.
Proof. unfold Equation3456. intro H. specialize (H F3_2). unfold magma_op, refa169_inst, refa169_op in H. discriminate H. Qed.

Lemma refa169_not3665 : ~ @Equation3665 Fin3 refa169_inst.
Proof. unfold Equation3665. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa169_inst, refa169_op in H. discriminate H. Qed.

Lemma refa169_not3667 : ~ @Equation3667 Fin3 refa169_inst.
Proof. unfold Equation3667. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa169_inst, refa169_op in H. discriminate H. Qed.

Lemma refa169_not3712 : ~ @Equation3712 Fin3 refa169_inst.
Proof. unfold Equation3712. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa169_inst, refa169_op in H. discriminate H. Qed.

Lemma refa169_not3714 : ~ @Equation3714 Fin3 refa169_inst.
Proof. unfold Equation3714. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa169_inst, refa169_op in H. discriminate H. Qed.

Lemma refa169_not3865 : ~ @Equation3865 Fin3 refa169_inst.
Proof. unfold Equation3865. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa169_inst, refa169_op in H. discriminate H. Qed.

Lemma refa169_not3868 : ~ @Equation3868 Fin3 refa169_inst.
Proof. unfold Equation3868. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa169_inst, refa169_op in H. discriminate H. Qed.

Lemma refa169_not3917 : ~ @Equation3917 Fin3 refa169_inst.
Proof. unfold Equation3917. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa169_inst, refa169_op in H. discriminate H. Qed.

Lemma refa169_not4067 : ~ @Equation4067 Fin3 refa169_inst.
Proof. unfold Equation4067. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa169_inst, refa169_op in H. discriminate H. Qed.

Lemma refa169_not4070 : ~ @Equation4070 Fin3 refa169_inst.
Proof. unfold Equation4070. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa169_inst, refa169_op in H. discriminate H. Qed.

Lemma refa169_not4121 : ~ @Equation4121 Fin3 refa169_inst.
Proof. unfold Equation4121. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa169_inst, refa169_op in H. discriminate H. Qed.

Lemma refa169_not4128 : ~ @Equation4128 Fin3 refa169_inst.
Proof. unfold Equation4128. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa169_inst, refa169_op in H. discriminate H. Qed.

Lemma refa169_not4396 : ~ @Equation4396 Fin3 refa169_inst.
Proof. unfold Equation4396. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa169_inst, refa169_op in H. discriminate H. Qed.

Lemma refa169_not4398 : ~ @Equation4398 Fin3 refa169_inst.
Proof. unfold Equation4398. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa169_inst, refa169_op in H. discriminate H. Qed.

Lemma refa169_not4433 : ~ @Equation4433 Fin3 refa169_inst.
Proof. unfold Equation4433. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa169_inst, refa169_op in H. discriminate H. Qed.

Lemma refa169_not4435 : ~ @Equation4435 Fin3 refa169_inst.
Proof. unfold Equation4435. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa169_inst, refa169_op in H. discriminate H. Qed.

Lemma refa169_not4470 : ~ @Equation4470 Fin3 refa169_inst.
Proof. unfold Equation4470. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa169_inst, refa169_op in H. discriminate H. Qed.

Lemma refa169_not4472 : ~ @Equation4472 Fin3 refa169_inst.
Proof. unfold Equation4472. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa169_inst, refa169_op in H. discriminate H. Qed.

Lemma refa169_not4583 : ~ @Equation4583 Fin3 refa169_inst.
Proof. unfold Equation4583. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa169_inst, refa169_op in H. discriminate H. Qed.

Lemma refa169_not4599 : ~ @Equation4599 Fin3 refa169_inst.
Proof. unfold Equation4599. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa169_inst, refa169_op in H. discriminate H. Qed.

Lemma refa169_not4629 : ~ @Equation4629 Fin3 refa169_inst.
Proof. unfold Equation4629. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa169_inst, refa169_op in H. discriminate H. Qed.

Lemma refa169_not4631 : ~ @Equation4631 Fin3 refa169_inst.
Proof. unfold Equation4631. intro H. specialize (H F3_0 F3_0 F3_2). unfold magma_op, refa169_inst, refa169_op in H. discriminate H. Qed.

(** ---- refa17 (Fin7) ---- *)

Definition refa17_op (x y : Fin7) : Fin7 :=
  match x, y with
  | F7_0, F7_0 => F7_1 | F7_0, F7_1 => F7_2 | F7_0, F7_2 => F7_3 | F7_0, F7_3 => F7_4 | F7_0, F7_4 => F7_5 | F7_0, F7_5 => F7_6 | F7_0, F7_6 => F7_0
  | F7_1, F7_0 => F7_3 | F7_1, F7_1 => F7_4 | F7_1, F7_2 => F7_5 | F7_1, F7_3 => F7_6 | F7_1, F7_4 => F7_0 | F7_1, F7_5 => F7_1 | F7_1, F7_6 => F7_2
  | F7_2, F7_0 => F7_5 | F7_2, F7_1 => F7_6 | F7_2, F7_2 => F7_0 | F7_2, F7_3 => F7_1 | F7_2, F7_4 => F7_2 | F7_2, F7_5 => F7_3 | F7_2, F7_6 => F7_4
  | F7_3, F7_0 => F7_0 | F7_3, F7_1 => F7_1 | F7_3, F7_2 => F7_2 | F7_3, F7_3 => F7_3 | F7_3, F7_4 => F7_4 | F7_3, F7_5 => F7_5 | F7_3, F7_6 => F7_6
  | F7_4, F7_0 => F7_2 | F7_4, F7_1 => F7_3 | F7_4, F7_2 => F7_4 | F7_4, F7_3 => F7_5 | F7_4, F7_4 => F7_6 | F7_4, F7_5 => F7_0 | F7_4, F7_6 => F7_1
  | F7_5, F7_0 => F7_4 | F7_5, F7_1 => F7_5 | F7_5, F7_2 => F7_6 | F7_5, F7_3 => F7_0 | F7_5, F7_4 => F7_1 | F7_5, F7_5 => F7_2 | F7_5, F7_6 => F7_3
  | F7_6, F7_0 => F7_6 | F7_6, F7_1 => F7_0 | F7_6, F7_2 => F7_1 | F7_6, F7_3 => F7_2 | F7_6, F7_4 => F7_3 | F7_6, F7_5 => F7_4 | F7_6, F7_6 => F7_5
  end.

#[local] Instance refa17_inst : Magma Fin7 := {| magma_op := refa17_op |}.

Lemma refa17_sat2247 : @Equation2247 Fin7 refa17_inst.
Proof. unfold Equation2247, magma_op, refa17_inst, refa17_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa17_sat2257 : @Equation2257 Fin7 refa17_inst.
Proof. unfold Equation2257, magma_op, refa17_inst, refa17_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa17_sat2294 : @Equation2294 Fin7 refa17_inst.
Proof. unfold Equation2294, magma_op, refa17_inst, refa17_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa17_not47 : ~ @Equation47 Fin7 refa17_inst.
Proof. unfold Equation47. intro H. specialize (H F7_0). unfold magma_op, refa17_inst, refa17_op in H. discriminate H. Qed.

Lemma refa17_not99 : ~ @Equation99 Fin7 refa17_inst.
Proof. unfold Equation99. intro H. specialize (H F7_0). unfold magma_op, refa17_inst, refa17_op in H. discriminate H. Qed.

Lemma refa17_not151 : ~ @Equation151 Fin7 refa17_inst.
Proof. unfold Equation151. intro H. specialize (H F7_0). unfold magma_op, refa17_inst, refa17_op in H. discriminate H. Qed.

Lemma refa17_not203 : ~ @Equation203 Fin7 refa17_inst.
Proof. unfold Equation203. intro H. specialize (H F7_0). unfold magma_op, refa17_inst, refa17_op in H. discriminate H. Qed.

Lemma refa17_not261 : ~ @Equation261 Fin7 refa17_inst.
Proof. unfold Equation261. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa17_inst, refa17_op in H. discriminate H. Qed.

Lemma refa17_not411 : ~ @Equation411 Fin7 refa17_inst.
Proof. unfold Equation411. intro H. specialize (H F7_0). unfold magma_op, refa17_inst, refa17_op in H. discriminate H. Qed.

Lemma refa17_not614 : ~ @Equation614 Fin7 refa17_inst.
Proof. unfold Equation614. intro H. specialize (H F7_0). unfold magma_op, refa17_inst, refa17_op in H. discriminate H. Qed.

Lemma refa17_not817 : ~ @Equation817 Fin7 refa17_inst.
Proof. unfold Equation817. intro H. specialize (H F7_0). unfold magma_op, refa17_inst, refa17_op in H. discriminate H. Qed.

Lemma refa17_not1020 : ~ @Equation1020 Fin7 refa17_inst.
Proof. unfold Equation1020. intro H. specialize (H F7_0). unfold magma_op, refa17_inst, refa17_op in H. discriminate H. Qed.

Lemma refa17_not1223 : ~ @Equation1223 Fin7 refa17_inst.
Proof. unfold Equation1223. intro H. specialize (H F7_0). unfold magma_op, refa17_inst, refa17_op in H. discriminate H. Qed.

Lemma refa17_not1426 : ~ @Equation1426 Fin7 refa17_inst.
Proof. unfold Equation1426. intro H. specialize (H F7_0). unfold magma_op, refa17_inst, refa17_op in H. discriminate H. Qed.

Lemma refa17_not1629 : ~ @Equation1629 Fin7 refa17_inst.
Proof. unfold Equation1629. intro H. specialize (H F7_0). unfold magma_op, refa17_inst, refa17_op in H. discriminate H. Qed.

Lemma refa17_not1832 : ~ @Equation1832 Fin7 refa17_inst.
Proof. unfold Equation1832. intro H. specialize (H F7_0). unfold magma_op, refa17_inst, refa17_op in H. discriminate H. Qed.

Lemma refa17_not2035 : ~ @Equation2035 Fin7 refa17_inst.
Proof. unfold Equation2035. intro H. specialize (H F7_0). unfold magma_op, refa17_inst, refa17_op in H. discriminate H. Qed.

Lemma refa17_not2240 : ~ @Equation2240 Fin7 refa17_inst.
Proof. unfold Equation2240. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa17_inst, refa17_op in H. discriminate H. Qed.

Lemma refa17_not2244 : ~ @Equation2244 Fin7 refa17_inst.
Proof. unfold Equation2244. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa17_inst, refa17_op in H. discriminate H. Qed.

Lemma refa17_not2246 : ~ @Equation2246 Fin7 refa17_inst.
Proof. unfold Equation2246. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa17_inst, refa17_op in H. discriminate H. Qed.

Lemma refa17_not2254 : ~ @Equation2254 Fin7 refa17_inst.
Proof. unfold Equation2254. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa17_inst, refa17_op in H. discriminate H. Qed.

Lemma refa17_not2256 : ~ @Equation2256 Fin7 refa17_inst.
Proof. unfold Equation2256. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa17_inst, refa17_op in H. discriminate H. Qed.

Lemma refa17_not2264 : ~ @Equation2264 Fin7 refa17_inst.
Proof. unfold Equation2264. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa17_inst, refa17_op in H. discriminate H. Qed.

Lemma refa17_not2301 : ~ @Equation2301 Fin7 refa17_inst.
Proof. unfold Equation2301. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa17_inst, refa17_op in H. discriminate H. Qed.

Lemma refa17_not2441 : ~ @Equation2441 Fin7 refa17_inst.
Proof. unfold Equation2441. intro H. specialize (H F7_0). unfold magma_op, refa17_inst, refa17_op in H. discriminate H. Qed.

Lemma refa17_not2644 : ~ @Equation2644 Fin7 refa17_inst.
Proof. unfold Equation2644. intro H. specialize (H F7_0). unfold magma_op, refa17_inst, refa17_op in H. discriminate H. Qed.

Lemma refa17_not2847 : ~ @Equation2847 Fin7 refa17_inst.
Proof. unfold Equation2847. intro H. specialize (H F7_0). unfold magma_op, refa17_inst, refa17_op in H. discriminate H. Qed.

Lemma refa17_not3050 : ~ @Equation3050 Fin7 refa17_inst.
Proof. unfold Equation3050. intro H. specialize (H F7_0). unfold magma_op, refa17_inst, refa17_op in H. discriminate H. Qed.

Lemma refa17_not3253 : ~ @Equation3253 Fin7 refa17_inst.
Proof. unfold Equation3253. intro H. specialize (H F7_0). unfold magma_op, refa17_inst, refa17_op in H. discriminate H. Qed.

Lemma refa17_not3456 : ~ @Equation3456 Fin7 refa17_inst.
Proof. unfold Equation3456. intro H. specialize (H F7_0). unfold magma_op, refa17_inst, refa17_op in H. discriminate H. Qed.

Lemma refa17_not3659 : ~ @Equation3659 Fin7 refa17_inst.
Proof. unfold Equation3659. intro H. specialize (H F7_0). unfold magma_op, refa17_inst, refa17_op in H. discriminate H. Qed.

Lemma refa17_not3862 : ~ @Equation3862 Fin7 refa17_inst.
Proof. unfold Equation3862. intro H. specialize (H F7_0). unfold magma_op, refa17_inst, refa17_op in H. discriminate H. Qed.

Lemma refa17_not4065 : ~ @Equation4065 Fin7 refa17_inst.
Proof. unfold Equation4065. intro H. specialize (H F7_0). unfold magma_op, refa17_inst, refa17_op in H. discriminate H. Qed.

Lemma refa17_not4268 : ~ @Equation4268 Fin7 refa17_inst.
Proof. unfold Equation4268. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa17_inst, refa17_op in H. discriminate H. Qed.

Lemma refa17_not4283 : ~ @Equation4283 Fin7 refa17_inst.
Proof. unfold Equation4283. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa17_inst, refa17_op in H. discriminate H. Qed.

Lemma refa17_not4314 : ~ @Equation4314 Fin7 refa17_inst.
Proof. unfold Equation4314. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa17_inst, refa17_op in H. discriminate H. Qed.

Lemma refa17_not4343 : ~ @Equation4343 Fin7 refa17_inst.
Proof. unfold Equation4343. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa17_inst, refa17_op in H. discriminate H. Qed.

Lemma refa17_not4380 : ~ @Equation4380 Fin7 refa17_inst.
Proof. unfold Equation4380. intro H. specialize (H F7_0). unfold magma_op, refa17_inst, refa17_op in H. discriminate H. Qed.

Lemma refa17_not4585 : ~ @Equation4585 Fin7 refa17_inst.
Proof. unfold Equation4585. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa17_inst, refa17_op in H. discriminate H. Qed.

Lemma refa17_not4598 : ~ @Equation4598 Fin7 refa17_inst.
Proof. unfold Equation4598. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa17_inst, refa17_op in H. discriminate H. Qed.

Lemma refa17_not4608 : ~ @Equation4608 Fin7 refa17_inst.
Proof. unfold Equation4608. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa17_inst, refa17_op in H. discriminate H. Qed.

Lemma refa17_not4635 : ~ @Equation4635 Fin7 refa17_inst.
Proof. unfold Equation4635. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa17_inst, refa17_op in H. discriminate H. Qed.

(** ---- refa170 (Fin3) ---- *)

Definition refa170_op (x y : Fin3) : Fin3 :=
  match x, y with
  | F3_0, F3_0 => F3_0 | F3_0, F3_1 => F3_1 | F3_0, F3_2 => F3_1
  | F3_1, F3_0 => F3_0 | F3_1, F3_1 => F3_0 | F3_1, F3_2 => F3_1
  | F3_2, F3_0 => F3_1 | F3_2, F3_1 => F3_0 | F3_2, F3_2 => F3_0
  end.

#[local] Instance refa170_inst : Magma Fin3 := {| magma_op := refa170_op |}.

Lemma refa170_sat3492 : @Equation3492 Fin3 refa170_inst.
Proof. unfold Equation3492, magma_op, refa170_inst, refa170_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa170_not4321 : ~ @Equation4321 Fin3 refa170_inst.
Proof. unfold Equation4321. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa170_inst, refa170_op in H. discriminate H. Qed.

Lemma refa170_not4584 : ~ @Equation4584 Fin3 refa170_inst.
Proof. unfold Equation4584. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa170_inst, refa170_op in H. discriminate H. Qed.

Lemma refa170_not4606 : ~ @Equation4606 Fin3 refa170_inst.
Proof. unfold Equation4606. intro H. specialize (H F3_2 F3_1). unfold magma_op, refa170_inst, refa170_op in H. discriminate H. Qed.

(** ---- refa171 (Fin3) ---- *)

Definition refa171_op (x y : Fin3) : Fin3 :=
  match x, y with
  | F3_0, F3_0 => F3_0 | F3_0, F3_1 => F3_2 | F3_0, F3_2 => F3_1
  | F3_1, F3_0 => F3_0 | F3_1, F3_1 => F3_0 | F3_1, F3_2 => F3_1
  | F3_2, F3_0 => F3_0 | F3_2, F3_1 => F3_2 | F3_2, F3_2 => F3_0
  end.

#[local] Instance refa171_inst : Magma Fin3 := {| magma_op := refa171_op |}.

Lemma refa171_sat1041 : @Equation1041 Fin3 refa171_inst.
Proof. unfold Equation1041, magma_op, refa171_inst, refa171_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa171_sat1063 : @Equation1063 Fin3 refa171_inst.
Proof. unfold Equation1063, magma_op, refa171_inst, refa171_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa171_sat1664 : @Equation1664 Fin3 refa171_inst.
Proof. unfold Equation1664, magma_op, refa171_inst, refa171_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa171_sat1672 : @Equation1672 Fin3 refa171_inst.
Proof. unfold Equation1672, magma_op, refa171_inst, refa171_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa171_sat1738 : @Equation1738 Fin3 refa171_inst.
Proof. unfold Equation1738, magma_op, refa171_inst, refa171_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa171_sat3264 : @Equation3264 Fin3 refa171_inst.
Proof. unfold Equation3264, magma_op, refa171_inst, refa171_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa171_sat3285 : @Equation3285 Fin3 refa171_inst.
Proof. unfold Equation3285, magma_op, refa171_inst, refa171_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa171_sat3316 : @Equation3316 Fin3 refa171_inst.
Proof. unfold Equation3316, magma_op, refa171_inst, refa171_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa171_not105 : ~ @Equation105 Fin3 refa171_inst.
Proof. unfold Equation105. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa171_inst, refa171_op in H. discriminate H. Qed.

Lemma refa171_not108 : ~ @Equation108 Fin3 refa171_inst.
Proof. unfold Equation108. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa171_inst, refa171_op in H. discriminate H. Qed.

Lemma refa171_not151 : ~ @Equation151 Fin3 refa171_inst.
Proof. unfold Equation151. intro H. specialize (H F3_1). unfold magma_op, refa171_inst, refa171_op in H. discriminate H. Qed.

Lemma refa171_not411 : ~ @Equation411 Fin3 refa171_inst.
Proof. unfold Equation411. intro H. specialize (H F3_1). unfold magma_op, refa171_inst, refa171_op in H. discriminate H. Qed.

Lemma refa171_not817 : ~ @Equation817 Fin3 refa171_inst.
Proof. unfold Equation817. intro H. specialize (H F3_1). unfold magma_op, refa171_inst, refa171_op in H. discriminate H. Qed.

Lemma refa171_not1023 : ~ @Equation1023 Fin3 refa171_inst.
Proof. unfold Equation1023. intro H. specialize (H F3_1 F3_0). unfold magma_op, refa171_inst, refa171_op in H. discriminate H. Qed.

Lemma refa171_not1036 : ~ @Equation1036 Fin3 refa171_inst.
Proof. unfold Equation1036. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa171_inst, refa171_op in H. discriminate H. Qed.

Lemma refa171_not1039 : ~ @Equation1039 Fin3 refa171_inst.
Proof. unfold Equation1039. intro H. specialize (H F3_1 F3_0). unfold magma_op, refa171_inst, refa171_op in H. discriminate H. Qed.

Lemma refa171_not1045 : ~ @Equation1045 Fin3 refa171_inst.
Proof. unfold Equation1045. intro H. specialize (H F3_1 F3_0). unfold magma_op, refa171_inst, refa171_op in H. discriminate H. Qed.

Lemma refa171_not1046 : ~ @Equation1046 Fin3 refa171_inst.
Proof. unfold Equation1046. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa171_inst, refa171_op in H. discriminate H. Qed.

Lemma refa171_not1049 : ~ @Equation1049 Fin3 refa171_inst.
Proof. unfold Equation1049. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa171_inst, refa171_op in H. discriminate H. Qed.

Lemma refa171_not1075 : ~ @Equation1075 Fin3 refa171_inst.
Proof. unfold Equation1075. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa171_inst, refa171_op in H. discriminate H. Qed.

Lemma refa171_not1085 : ~ @Equation1085 Fin3 refa171_inst.
Proof. unfold Equation1085. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa171_inst, refa171_op in H. discriminate H. Qed.

Lemma refa171_not1109 : ~ @Equation1109 Fin3 refa171_inst.
Proof. unfold Equation1109. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa171_inst, refa171_op in H. discriminate H. Qed.

Lemma refa171_not1112 : ~ @Equation1112 Fin3 refa171_inst.
Proof. unfold Equation1112. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa171_inst, refa171_op in H. discriminate H. Qed.

Lemma refa171_not1224 : ~ @Equation1224 Fin3 refa171_inst.
Proof. unfold Equation1224. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa171_inst, refa171_op in H. discriminate H. Qed.

Lemma refa171_not1225 : ~ @Equation1225 Fin3 refa171_inst.
Proof. unfold Equation1225. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa171_inst, refa171_op in H. discriminate H. Qed.

Lemma refa171_not1229 : ~ @Equation1229 Fin3 refa171_inst.
Proof. unfold Equation1229. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa171_inst, refa171_op in H. discriminate H. Qed.

Lemma refa171_not1239 : ~ @Equation1239 Fin3 refa171_inst.
Proof. unfold Equation1239. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa171_inst, refa171_op in H. discriminate H. Qed.

Lemma refa171_not1242 : ~ @Equation1242 Fin3 refa171_inst.
Proof. unfold Equation1242. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa171_inst, refa171_op in H. discriminate H. Qed.

Lemma refa171_not1249 : ~ @Equation1249 Fin3 refa171_inst.
Proof. unfold Equation1249. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa171_inst, refa171_op in H. discriminate H. Qed.

Lemma refa171_not1251 : ~ @Equation1251 Fin3 refa171_inst.
Proof. unfold Equation1251. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa171_inst, refa171_op in H. discriminate H. Qed.

Lemma refa171_not1252 : ~ @Equation1252 Fin3 refa171_inst.
Proof. unfold Equation1252. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa171_inst, refa171_op in H. discriminate H. Qed.

Lemma refa171_not1278 : ~ @Equation1278 Fin3 refa171_inst.
Proof. unfold Equation1278. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa171_inst, refa171_op in H. discriminate H. Qed.

Lemma refa171_not1285 : ~ @Equation1285 Fin3 refa171_inst.
Proof. unfold Equation1285. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa171_inst, refa171_op in H. discriminate H. Qed.

Lemma refa171_not1288 : ~ @Equation1288 Fin3 refa171_inst.
Proof. unfold Equation1288. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa171_inst, refa171_op in H. discriminate H. Qed.

Lemma refa171_not1315 : ~ @Equation1315 Fin3 refa171_inst.
Proof. unfold Equation1315. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa171_inst, refa171_op in H. discriminate H. Qed.

Lemma refa171_not1322 : ~ @Equation1322 Fin3 refa171_inst.
Proof. unfold Equation1322. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa171_inst, refa171_op in H. discriminate H. Qed.

Lemma refa171_not1426 : ~ @Equation1426 Fin3 refa171_inst.
Proof. unfold Equation1426. intro H. specialize (H F3_1). unfold magma_op, refa171_inst, refa171_op in H. discriminate H. Qed.

Lemma refa171_not1631 : ~ @Equation1631 Fin3 refa171_inst.
Proof. unfold Equation1631. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa171_inst, refa171_op in H. discriminate H. Qed.

Lemma refa171_not1681 : ~ @Equation1681 Fin3 refa171_inst.
Proof. unfold Equation1681. intro H. specialize (H F3_1 F3_0). unfold magma_op, refa171_inst, refa171_op in H. discriminate H. Qed.

Lemma refa171_not1684 : ~ @Equation1684 Fin3 refa171_inst.
Proof. unfold Equation1684. intro H. specialize (H F3_1 F3_0). unfold magma_op, refa171_inst, refa171_op in H. discriminate H. Qed.

Lemma refa171_not1691 : ~ @Equation1691 Fin3 refa171_inst.
Proof. unfold Equation1691. intro H. specialize (H F3_1 F3_0). unfold magma_op, refa171_inst, refa171_op in H. discriminate H. Qed.

Lemma refa171_not1694 : ~ @Equation1694 Fin3 refa171_inst.
Proof. unfold Equation1694. intro H. specialize (H F3_1 F3_0). unfold magma_op, refa171_inst, refa171_op in H. discriminate H. Qed.

Lemma refa171_not1721 : ~ @Equation1721 Fin3 refa171_inst.
Proof. unfold Equation1721. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa171_inst, refa171_op in H. discriminate H. Qed.

Lemma refa171_not1832 : ~ @Equation1832 Fin3 refa171_inst.
Proof. unfold Equation1832. intro H. specialize (H F3_1). unfold magma_op, refa171_inst, refa171_op in H. discriminate H. Qed.

Lemma refa171_not2035 : ~ @Equation2035 Fin3 refa171_inst.
Proof. unfold Equation2035. intro H. specialize (H F3_1). unfold magma_op, refa171_inst, refa171_op in H. discriminate H. Qed.

Lemma refa171_not3281 : ~ @Equation3281 Fin3 refa171_inst.
Proof. unfold Equation3281. intro H. specialize (H F3_1 F3_0). unfold magma_op, refa171_inst, refa171_op in H. discriminate H. Qed.

Lemma refa171_not3306 : ~ @Equation3306 Fin3 refa171_inst.
Proof. unfold Equation3306. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa171_inst, refa171_op in H. discriminate H. Qed.

Lemma refa171_not3309 : ~ @Equation3309 Fin3 refa171_inst.
Proof. unfold Equation3309. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa171_inst, refa171_op in H. discriminate H. Qed.

Lemma refa171_not3315 : ~ @Equation3315 Fin3 refa171_inst.
Proof. unfold Equation3315. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa171_inst, refa171_op in H. discriminate H. Qed.

Lemma refa171_not3318 : ~ @Equation3318 Fin3 refa171_inst.
Proof. unfold Equation3318. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa171_inst, refa171_op in H. discriminate H. Qed.

Lemma refa171_not3319 : ~ @Equation3319 Fin3 refa171_inst.
Proof. unfold Equation3319. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa171_inst, refa171_op in H. discriminate H. Qed.

Lemma refa171_not3343 : ~ @Equation3343 Fin3 refa171_inst.
Proof. unfold Equation3343. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa171_inst, refa171_op in H. discriminate H. Qed.

Lemma refa171_not3456 : ~ @Equation3456 Fin3 refa171_inst.
Proof. unfold Equation3456. intro H. specialize (H F3_1). unfold magma_op, refa171_inst, refa171_op in H. discriminate H. Qed.

Lemma refa171_not3660 : ~ @Equation3660 Fin3 refa171_inst.
Proof. unfold Equation3660. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa171_inst, refa171_op in H. discriminate H. Qed.

Lemma refa171_not3661 : ~ @Equation3661 Fin3 refa171_inst.
Proof. unfold Equation3661. intro H. specialize (H F3_1 F3_0). unfold magma_op, refa171_inst, refa171_op in H. discriminate H. Qed.

Lemma refa171_not3721 : ~ @Equation3721 Fin3 refa171_inst.
Proof. unfold Equation3721. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa171_inst, refa171_op in H. discriminate H. Qed.

Lemma refa171_not3724 : ~ @Equation3724 Fin3 refa171_inst.
Proof. unfold Equation3724. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa171_inst, refa171_op in H. discriminate H. Qed.

Lemma refa171_not3725 : ~ @Equation3725 Fin3 refa171_inst.
Proof. unfold Equation3725. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa171_inst, refa171_op in H. discriminate H. Qed.

Lemma refa171_not3862 : ~ @Equation3862 Fin3 refa171_inst.
Proof. unfold Equation3862. intro H. specialize (H F3_1). unfold magma_op, refa171_inst, refa171_op in H. discriminate H. Qed.

Lemma refa171_not4065 : ~ @Equation4065 Fin3 refa171_inst.
Proof. unfold Equation4065. intro H. specialize (H F3_1). unfold magma_op, refa171_inst, refa171_op in H. discriminate H. Qed.

Lemma refa171_not4269 : ~ @Equation4269 Fin3 refa171_inst.
Proof. unfold Equation4269. intro H. specialize (H F3_1 F3_0). unfold magma_op, refa171_inst, refa171_op in H. discriminate H. Qed.

Lemma refa171_not4284 : ~ @Equation4284 Fin3 refa171_inst.
Proof. unfold Equation4284. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa171_inst, refa171_op in H. discriminate H. Qed.

Lemma refa171_not4314 : ~ @Equation4314 Fin3 refa171_inst.
Proof. unfold Equation4314. intro H. specialize (H F3_1 F3_0). unfold magma_op, refa171_inst, refa171_op in H. discriminate H. Qed.

Lemma refa171_not4583 : ~ @Equation4583 Fin3 refa171_inst.
Proof. unfold Equation4583. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa171_inst, refa171_op in H. discriminate H. Qed.

Lemma refa171_not4584 : ~ @Equation4584 Fin3 refa171_inst.
Proof. unfold Equation4584. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa171_inst, refa171_op in H. discriminate H. Qed.

Lemma refa171_not4598 : ~ @Equation4598 Fin3 refa171_inst.
Proof. unfold Equation4598. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa171_inst, refa171_op in H. discriminate H. Qed.

Lemma refa171_not4606 : ~ @Equation4606 Fin3 refa171_inst.
Proof. unfold Equation4606. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa171_inst, refa171_op in H. discriminate H. Qed.

(** ---- refa172 (Fin3) ---- *)

Definition refa172_op (x y : Fin3) : Fin3 :=
  match x, y with
  | F3_0, F3_0 => F3_0 | F3_0, F3_1 => F3_1 | F3_0, F3_2 => F3_1
  | F3_1, F3_0 => F3_0 | F3_1, F3_1 => F3_0 | F3_1, F3_2 => F3_0
  | F3_2, F3_0 => F3_0 | F3_2, F3_1 => F3_2 | F3_2, F3_2 => F3_0
  end.

#[local] Instance refa172_inst : Magma Fin3 := {| magma_op := refa172_op |}.

Lemma refa172_sat320 : @Equation320 Fin3 refa172_inst.
Proof. unfold Equation320, magma_op, refa172_inst, refa172_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa172_not3261 : ~ @Equation3261 Fin3 refa172_inst.
Proof. unfold Equation3261. intro H. specialize (H F3_2 F3_0). unfold magma_op, refa172_inst, refa172_op in H. discriminate H. Qed.

Lemma refa172_not3269 : ~ @Equation3269 Fin3 refa172_inst.
Proof. unfold Equation3269. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa172_inst, refa172_op in H. discriminate H. Qed.

Lemma refa172_not3271 : ~ @Equation3271 Fin3 refa172_inst.
Proof. unfold Equation3271. intro H. specialize (H F3_2 F3_0). unfold magma_op, refa172_inst, refa172_op in H. discriminate H. Qed.

Lemma refa172_not3306 : ~ @Equation3306 Fin3 refa172_inst.
Proof. unfold Equation3306. intro H. specialize (H F3_2 F3_1). unfold magma_op, refa172_inst, refa172_op in H. discriminate H. Qed.

Lemma refa172_not3456 : ~ @Equation3456 Fin3 refa172_inst.
Proof. unfold Equation3456. intro H. specialize (H F3_2). unfold magma_op, refa172_inst, refa172_op in H. discriminate H. Qed.

Lemma refa172_not3712 : ~ @Equation3712 Fin3 refa172_inst.
Proof. unfold Equation3712. intro H. specialize (H F3_2 F3_1). unfold magma_op, refa172_inst, refa172_op in H. discriminate H. Qed.

Lemma refa172_not4314 : ~ @Equation4314 Fin3 refa172_inst.
Proof. unfold Equation4314. intro H. specialize (H F3_2 F3_0). unfold magma_op, refa172_inst, refa172_op in H. discriminate H. Qed.

(** ---- refa173 (Fin3) ---- *)

Definition refa173_op (x y : Fin3) : Fin3 :=
  match x, y with
  | F3_0, F3_0 => F3_0 | F3_0, F3_1 => F3_0 | F3_0, F3_2 => F3_0
  | F3_1, F3_0 => F3_0 | F3_1, F3_1 => F3_0 | F3_1, F3_2 => F3_1
  | F3_2, F3_0 => F3_0 | F3_2, F3_1 => F3_1 | F3_2, F3_2 => F3_0
  end.

#[local] Instance refa173_inst : Magma Fin3 := {| magma_op := refa173_op |}.

Lemma refa173_sat3473 : @Equation3473 Fin3 refa173_inst.
Proof. unfold Equation3473, magma_op, refa173_inst, refa173_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa173_sat3683 : @Equation3683 Fin3 refa173_inst.
Proof. unfold Equation3683, magma_op, refa173_inst, refa173_op. intros x y z w. destruct x, y, z, w; reflexivity. Qed.

Lemma refa173_sat3879 : @Equation3879 Fin3 refa173_inst.
Proof. unfold Equation3879, magma_op, refa173_inst, refa173_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa173_sat4484 : @Equation4484 Fin3 refa173_inst.
Proof. unfold Equation4484, magma_op, refa173_inst, refa173_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa173_not378 : ~ @Equation378 Fin3 refa173_inst.
Proof. unfold Equation378. intro H. specialize (H F3_2 F3_1). unfold magma_op, refa173_inst, refa173_op in H. discriminate H. Qed.

Lemma refa173_not3254 : ~ @Equation3254 Fin3 refa173_inst.
Proof. unfold Equation3254. intro H. specialize (H F3_2 F3_1). unfold magma_op, refa173_inst, refa173_op in H. discriminate H. Qed.

Lemma refa173_not3255 : ~ @Equation3255 Fin3 refa173_inst.
Proof. unfold Equation3255. intro H. specialize (H F3_2 F3_1). unfold magma_op, refa173_inst, refa173_op in H. discriminate H. Qed.

Lemma refa173_not3279 : ~ @Equation3279 Fin3 refa173_inst.
Proof. unfold Equation3279. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa173_inst, refa173_op in H. discriminate H. Qed.

Lemma refa173_not3281 : ~ @Equation3281 Fin3 refa173_inst.
Proof. unfold Equation3281. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa173_inst, refa173_op in H. discriminate H. Qed.

Lemma refa173_not3458 : ~ @Equation3458 Fin3 refa173_inst.
Proof. unfold Equation3458. intro H. specialize (H F3_2 F3_1). unfold magma_op, refa173_inst, refa173_op in H. discriminate H. Qed.

Lemma refa173_not3469 : ~ @Equation3469 Fin3 refa173_inst.
Proof. unfold Equation3469. intro H. specialize (H F3_2 F3_1 F3_2). unfold magma_op, refa173_inst, refa173_op in H. discriminate H. Qed.

Lemma refa173_not3475 : ~ @Equation3475 Fin3 refa173_inst.
Proof. unfold Equation3475. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa173_inst, refa173_op in H. discriminate H. Qed.

Lemma refa173_not3482 : ~ @Equation3482 Fin3 refa173_inst.
Proof. unfold Equation3482. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa173_inst, refa173_op in H. discriminate H. Qed.

Lemma refa173_not3491 : ~ @Equation3491 Fin3 refa173_inst.
Proof. unfold Equation3491. intro H. specialize (H F3_2 F3_2 F3_1). unfold magma_op, refa173_inst, refa173_op in H. discriminate H. Qed.

Lemma refa173_not3495 : ~ @Equation3495 Fin3 refa173_inst.
Proof. unfold Equation3495. intro H. specialize (H F3_2 F3_2 F3_1). unfold magma_op, refa173_inst, refa173_op in H. discriminate H. Qed.

Lemma refa173_not3864 : ~ @Equation3864 Fin3 refa173_inst.
Proof. unfold Equation3864. intro H. specialize (H F3_2 F3_1). unfold magma_op, refa173_inst, refa173_op in H. discriminate H. Qed.

Lemma refa173_not3867 : ~ @Equation3867 Fin3 refa173_inst.
Proof. unfold Equation3867. intro H. specialize (H F3_2 F3_1). unfold magma_op, refa173_inst, refa173_op in H. discriminate H. Qed.

Lemma refa173_not3881 : ~ @Equation3881 Fin3 refa173_inst.
Proof. unfold Equation3881. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa173_inst, refa173_op in H. discriminate H. Qed.

Lemma refa173_not3888 : ~ @Equation3888 Fin3 refa173_inst.
Proof. unfold Equation3888. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa173_inst, refa173_op in H. discriminate H. Qed.

Lemma refa173_not4070 : ~ @Equation4070 Fin3 refa173_inst.
Proof. unfold Equation4070. intro H. specialize (H F3_2 F3_1). unfold magma_op, refa173_inst, refa173_op in H. discriminate H. Qed.

Lemma refa173_not4084 : ~ @Equation4084 Fin3 refa173_inst.
Proof. unfold Equation4084. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa173_inst, refa173_op in H. discriminate H. Qed.

Lemma refa173_not4269 : ~ @Equation4269 Fin3 refa173_inst.
Proof. unfold Equation4269. intro H. specialize (H F3_2 F3_1). unfold magma_op, refa173_inst, refa173_op in H. discriminate H. Qed.

Lemma refa173_not4273 : ~ @Equation4273 Fin3 refa173_inst.
Proof. unfold Equation4273. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa173_inst, refa173_op in H. discriminate H. Qed.

Lemma refa173_not4275 : ~ @Equation4275 Fin3 refa173_inst.
Proof. unfold Equation4275. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa173_inst, refa173_op in H. discriminate H. Qed.

Lemma refa173_not4284 : ~ @Equation4284 Fin3 refa173_inst.
Proof. unfold Equation4284. intro H. specialize (H F3_2 F3_1). unfold magma_op, refa173_inst, refa173_op in H. discriminate H. Qed.

Lemma refa173_not4291 : ~ @Equation4291 Fin3 refa173_inst.
Proof. unfold Equation4291. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa173_inst, refa173_op in H. discriminate H. Qed.

Lemma refa173_not4314 : ~ @Equation4314 Fin3 refa173_inst.
Proof. unfold Equation4314. intro H. specialize (H F3_2 F3_1). unfold magma_op, refa173_inst, refa173_op in H. discriminate H. Qed.

Lemma refa173_not4320 : ~ @Equation4320 Fin3 refa173_inst.
Proof. unfold Equation4320. intro H. specialize (H F3_2 F3_1). unfold magma_op, refa173_inst, refa173_op in H. discriminate H. Qed.

Lemma refa173_not4321 : ~ @Equation4321 Fin3 refa173_inst.
Proof. unfold Equation4321. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa173_inst, refa173_op in H. discriminate H. Qed.

Lemma refa173_not4396 : ~ @Equation4396 Fin3 refa173_inst.
Proof. unfold Equation4396. intro H. specialize (H F3_2 F3_1). unfold magma_op, refa173_inst, refa173_op in H. discriminate H. Qed.

Lemma refa173_not4406 : ~ @Equation4406 Fin3 refa173_inst.
Proof. unfold Equation4406. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa173_inst, refa173_op in H. discriminate H. Qed.

Lemma refa173_not4433 : ~ @Equation4433 Fin3 refa173_inst.
Proof. unfold Equation4433. intro H. specialize (H F3_2 F3_1). unfold magma_op, refa173_inst, refa173_op in H. discriminate H. Qed.

Lemma refa173_not4443 : ~ @Equation4443 Fin3 refa173_inst.
Proof. unfold Equation4443. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa173_inst, refa173_op in H. discriminate H. Qed.

Lemma refa173_not4445 : ~ @Equation4445 Fin3 refa173_inst.
Proof. unfold Equation4445. intro H. specialize (H F3_2 F3_1). unfold magma_op, refa173_inst, refa173_op in H. discriminate H. Qed.

Lemma refa173_not4472 : ~ @Equation4472 Fin3 refa173_inst.
Proof. unfold Equation4472. intro H. specialize (H F3_2 F3_1). unfold magma_op, refa173_inst, refa173_op in H. discriminate H. Qed.

Lemma refa173_not4480 : ~ @Equation4480 Fin3 refa173_inst.
Proof. unfold Equation4480. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa173_inst, refa173_op in H. discriminate H. Qed.

Lemma refa173_not4598 : ~ @Equation4598 Fin3 refa173_inst.
Proof. unfold Equation4598. intro H. specialize (H F3_2 F3_1). unfold magma_op, refa173_inst, refa173_op in H. discriminate H. Qed.

Lemma refa173_not4599 : ~ @Equation4599 Fin3 refa173_inst.
Proof. unfold Equation4599. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa173_inst, refa173_op in H. discriminate H. Qed.

Lemma refa173_not4606 : ~ @Equation4606 Fin3 refa173_inst.
Proof. unfold Equation4606. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa173_inst, refa173_op in H. discriminate H. Qed.

Lemma refa173_not4631 : ~ @Equation4631 Fin3 refa173_inst.
Proof. unfold Equation4631. intro H. specialize (H F3_2 F3_0 F3_1). unfold magma_op, refa173_inst, refa173_op in H. discriminate H. Qed.

Lemma refa173_not4636 : ~ @Equation4636 Fin3 refa173_inst.
Proof. unfold Equation4636. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa173_inst, refa173_op in H. discriminate H. Qed.

Lemma refa173_not4647 : ~ @Equation4647 Fin3 refa173_inst.
Proof. unfold Equation4647. intro H. specialize (H F3_0 F3_1 F3_2). unfold magma_op, refa173_inst, refa173_op in H. discriminate H. Qed.

(** ---- refa174 (Fin3) ---- *)

Definition refa174_op (x y : Fin3) : Fin3 :=
  match x, y with
  | F3_0, F3_0 => F3_1 | F3_0, F3_1 => F3_0 | F3_0, F3_2 => F3_2
  | F3_1, F3_0 => F3_2 | F3_1, F3_1 => F3_0 | F3_1, F3_2 => F3_0
  | F3_2, F3_0 => F3_0 | F3_2, F3_1 => F3_2 | F3_2, F3_2 => F3_1
  end.

#[local] Instance refa174_inst : Magma Fin3 := {| magma_op := refa174_op |}.

Lemma refa174_sat1685 : @Equation1685 Fin3 refa174_inst.
Proof. unfold Equation1685, magma_op, refa174_inst, refa174_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa174_sat1691 : @Equation1691 Fin3 refa174_inst.
Proof. unfold Equation1691, magma_op, refa174_inst, refa174_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa174_sat3345 : @Equation3345 Fin3 refa174_inst.
Proof. unfold Equation3345, magma_op, refa174_inst, refa174_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa174_sat3353 : @Equation3353 Fin3 refa174_inst.
Proof. unfold Equation3353, magma_op, refa174_inst, refa174_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa174_not255 : ~ @Equation255 Fin3 refa174_inst.
Proof. unfold Equation255. intro H. specialize (H F3_1). unfold magma_op, refa174_inst, refa174_op in H. discriminate H. Qed.

Lemma refa174_not411 : ~ @Equation411 Fin3 refa174_inst.
Proof. unfold Equation411. intro H. specialize (H F3_1). unfold magma_op, refa174_inst, refa174_op in H. discriminate H. Qed.

Lemma refa174_not817 : ~ @Equation817 Fin3 refa174_inst.
Proof. unfold Equation817. intro H. specialize (H F3_0). unfold magma_op, refa174_inst, refa174_op in H. discriminate H. Qed.

Lemma refa174_not1020 : ~ @Equation1020 Fin3 refa174_inst.
Proof. unfold Equation1020. intro H. specialize (H F3_1). unfold magma_op, refa174_inst, refa174_op in H. discriminate H. Qed.

Lemma refa174_not1635 : ~ @Equation1635 Fin3 refa174_inst.
Proof. unfold Equation1635. intro H. specialize (H F3_1 F3_0). unfold magma_op, refa174_inst, refa174_op in H. discriminate H. Qed.

Lemma refa174_not1637 : ~ @Equation1637 Fin3 refa174_inst.
Proof. unfold Equation1637. intro H. specialize (H F3_2 F3_1). unfold magma_op, refa174_inst, refa174_op in H. discriminate H. Qed.

Lemma refa174_not1731 : ~ @Equation1731 Fin3 refa174_inst.
Proof. unfold Equation1731. intro H. specialize (H F3_1 F3_0). unfold magma_op, refa174_inst, refa174_op in H. discriminate H. Qed.

Lemma refa174_not1832 : ~ @Equation1832 Fin3 refa174_inst.
Proof. unfold Equation1832. intro H. specialize (H F3_1). unfold magma_op, refa174_inst, refa174_op in H. discriminate H. Qed.

Lemma refa174_not2035 : ~ @Equation2035 Fin3 refa174_inst.
Proof. unfold Equation2035. intro H. specialize (H F3_0). unfold magma_op, refa174_inst, refa174_op in H. discriminate H. Qed.

Lemma refa174_not2441 : ~ @Equation2441 Fin3 refa174_inst.
Proof. unfold Equation2441. intro H. specialize (H F3_1). unfold magma_op, refa174_inst, refa174_op in H. discriminate H. Qed.

Lemma refa174_not3256 : ~ @Equation3256 Fin3 refa174_inst.
Proof. unfold Equation3256. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa174_inst, refa174_op in H. discriminate H. Qed.

Lemma refa174_not3278 : ~ @Equation3278 Fin3 refa174_inst.
Proof. unfold Equation3278. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa174_inst, refa174_op in H. discriminate H. Qed.

Lemma refa174_not3315 : ~ @Equation3315 Fin3 refa174_inst.
Proof. unfold Equation3315. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa174_inst, refa174_op in H. discriminate H. Qed.

Lemma refa174_not3319 : ~ @Equation3319 Fin3 refa174_inst.
Proof. unfold Equation3319. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa174_inst, refa174_op in H. discriminate H. Qed.

Lemma refa174_not3659 : ~ @Equation3659 Fin3 refa174_inst.
Proof. unfold Equation3659. intro H. specialize (H F3_0). unfold magma_op, refa174_inst, refa174_op in H. discriminate H. Qed.

Lemma refa174_not3862 : ~ @Equation3862 Fin3 refa174_inst.
Proof. unfold Equation3862. intro H. specialize (H F3_1). unfold magma_op, refa174_inst, refa174_op in H. discriminate H. Qed.

Lemma refa174_not4065 : ~ @Equation4065 Fin3 refa174_inst.
Proof. unfold Equation4065. intro H. specialize (H F3_0). unfold magma_op, refa174_inst, refa174_op in H. discriminate H. Qed.

Lemma refa174_not4270 : ~ @Equation4270 Fin3 refa174_inst.
Proof. unfold Equation4270. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa174_inst, refa174_op in H. discriminate H. Qed.

Lemma refa174_not4275 : ~ @Equation4275 Fin3 refa174_inst.
Proof. unfold Equation4275. intro H. specialize (H F3_1 F3_0). unfold magma_op, refa174_inst, refa174_op in H. discriminate H. Qed.

Lemma refa174_not4290 : ~ @Equation4290 Fin3 refa174_inst.
Proof. unfold Equation4290. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa174_inst, refa174_op in H. discriminate H. Qed.

Lemma refa174_not4598 : ~ @Equation4598 Fin3 refa174_inst.
Proof. unfold Equation4598. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa174_inst, refa174_op in H. discriminate H. Qed.

Lemma refa174_not4622 : ~ @Equation4622 Fin3 refa174_inst.
Proof. unfold Equation4622. intro H. specialize (H F3_0 F3_0 F3_1). unfold magma_op, refa174_inst, refa174_op in H. discriminate H. Qed.

Lemma refa174_not4647 : ~ @Equation4647 Fin3 refa174_inst.
Proof. unfold Equation4647. intro H. specialize (H F3_0 F3_1 F3_1). unfold magma_op, refa174_inst, refa174_op in H. discriminate H. Qed.

(** ---- refa175 (Fin3) ---- *)

Definition refa175_op (x y : Fin3) : Fin3 :=
  match x, y with
  | F3_0, F3_0 => F3_0 | F3_0, F3_1 => F3_1 | F3_0, F3_2 => F3_2
  | F3_1, F3_0 => F3_0 | F3_1, F3_1 => F3_0 | F3_1, F3_2 => F3_1
  | F3_2, F3_0 => F3_1 | F3_2, F3_1 => F3_0 | F3_2, F3_2 => F3_1
  end.

#[local] Instance refa175_inst : Magma Fin3 := {| magma_op := refa175_op |}.

Lemma refa175_sat2588 : @Equation2588 Fin3 refa175_inst.
Proof. unfold Equation2588, magma_op, refa175_inst, refa175_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa175_sat2812 : @Equation2812 Fin3 refa175_inst.
Proof. unfold Equation2812, magma_op, refa175_inst, refa175_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa175_not211 : ~ @Equation211 Fin3 refa175_inst.
Proof. unfold Equation211. intro H. specialize (H F3_2 F3_0). unfold magma_op, refa175_inst, refa175_op in H. discriminate H. Qed.

Lemma refa175_not221 : ~ @Equation221 Fin3 refa175_inst.
Proof. unfold Equation221. intro H. specialize (H F3_2 F3_0). unfold magma_op, refa175_inst, refa175_op in H. discriminate H. Qed.

Lemma refa175_not2238 : ~ @Equation2238 Fin3 refa175_inst.
Proof. unfold Equation2238. intro H. specialize (H F3_2). unfold magma_op, refa175_inst, refa175_op in H. discriminate H. Qed.

Lemma refa175_not2449 : ~ @Equation2449 Fin3 refa175_inst.
Proof. unfold Equation2449. intro H. specialize (H F3_2 F3_0). unfold magma_op, refa175_inst, refa175_op in H. discriminate H. Qed.

Lemma refa175_not2466 : ~ @Equation2466 Fin3 refa175_inst.
Proof. unfold Equation2466. intro H. specialize (H F3_2 F3_0). unfold magma_op, refa175_inst, refa175_op in H. discriminate H. Qed.

Lemma refa175_not2496 : ~ @Equation2496 Fin3 refa175_inst.
Proof. unfold Equation2496. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa175_inst, refa175_op in H. discriminate H. Qed.

Lemma refa175_not2533 : ~ @Equation2533 Fin3 refa175_inst.
Proof. unfold Equation2533. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa175_inst, refa175_op in H. discriminate H. Qed.

Lemma refa175_not2709 : ~ @Equation2709 Fin3 refa175_inst.
Proof. unfold Equation2709. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa175_inst, refa175_op in H. discriminate H. Qed.

Lemma refa175_not3115 : ~ @Equation3115 Fin3 refa175_inst.
Proof. unfold Equation3115. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa175_inst, refa175_op in H. discriminate H. Qed.

Lemma refa175_not3152 : ~ @Equation3152 Fin3 refa175_inst.
Proof. unfold Equation3152. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa175_inst, refa175_op in H. discriminate H. Qed.

Lemma refa175_not3659 : ~ @Equation3659 Fin3 refa175_inst.
Proof. unfold Equation3659. intro H. specialize (H F3_2). unfold magma_op, refa175_inst, refa175_op in H. discriminate H. Qed.

Lemma refa175_not4070 : ~ @Equation4070 Fin3 refa175_inst.
Proof. unfold Equation4070. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa175_inst, refa175_op in H. discriminate H. Qed.

Lemma refa175_not4090 : ~ @Equation4090 Fin3 refa175_inst.
Proof. unfold Equation4090. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa175_inst, refa175_op in H. discriminate H. Qed.

Lemma refa175_not4118 : ~ @Equation4118 Fin3 refa175_inst.
Proof. unfold Equation4118. intro H. specialize (H F3_2 F3_0). unfold magma_op, refa175_inst, refa175_op in H. discriminate H. Qed.

Lemma refa175_not4128 : ~ @Equation4128 Fin3 refa175_inst.
Proof. unfold Equation4128. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa175_inst, refa175_op in H. discriminate H. Qed.

Lemma refa175_not4155 : ~ @Equation4155 Fin3 refa175_inst.
Proof. unfold Equation4155. intro H. specialize (H F3_2 F3_0). unfold magma_op, refa175_inst, refa175_op in H. discriminate H. Qed.

Lemma refa175_not4320 : ~ @Equation4320 Fin3 refa175_inst.
Proof. unfold Equation4320. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa175_inst, refa175_op in H. discriminate H. Qed.

Lemma refa175_not4606 : ~ @Equation4606 Fin3 refa175_inst.
Proof. unfold Equation4606. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa175_inst, refa175_op in H. discriminate H. Qed.

(** ---- refa176 (Fin3) ---- *)

Definition refa176_op (x y : Fin3) : Fin3 :=
  match x, y with
  | F3_0, F3_0 => F3_0 | F3_0, F3_1 => F3_0 | F3_0, F3_2 => F3_1
  | F3_1, F3_0 => F3_2 | F3_1, F3_1 => F3_0 | F3_1, F3_2 => F3_2
  | F3_2, F3_0 => F3_0 | F3_2, F3_1 => F3_2 | F3_2, F3_2 => F3_1
  end.

#[local] Instance refa176_inst : Magma Fin3 := {| magma_op := refa176_op |}.

Lemma refa176_sat1479 : @Equation1479 Fin3 refa176_inst.
Proof. unfold Equation1479, magma_op, refa176_inst, refa176_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa176_not43 : ~ @Equation43 Fin3 refa176_inst.
Proof. unfold Equation43. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa176_inst, refa176_op in H. discriminate H. Qed.

Lemma refa176_not1429 : ~ @Equation1429 Fin3 refa176_inst.
Proof. unfold Equation1429. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa176_inst, refa176_op in H. discriminate H. Qed.

Lemma refa176_not1444 : ~ @Equation1444 Fin3 refa176_inst.
Proof. unfold Equation1444. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa176_inst, refa176_op in H. discriminate H. Qed.

Lemma refa176_not1629 : ~ @Equation1629 Fin3 refa176_inst.
Proof. unfold Equation1629. intro H. specialize (H F3_1). unfold magma_op, refa176_inst, refa176_op in H. discriminate H. Qed.

Lemma refa176_not1832 : ~ @Equation1832 Fin3 refa176_inst.
Proof. unfold Equation1832. intro H. specialize (H F3_1). unfold magma_op, refa176_inst, refa176_op in H. discriminate H. Qed.

Lemma refa176_not2035 : ~ @Equation2035 Fin3 refa176_inst.
Proof. unfold Equation2035. intro H. specialize (H F3_1). unfold magma_op, refa176_inst, refa176_op in H. discriminate H. Qed.

Lemma refa176_not3253 : ~ @Equation3253 Fin3 refa176_inst.
Proof. unfold Equation3253. intro H. specialize (H F3_1). unfold magma_op, refa176_inst, refa176_op in H. discriminate H. Qed.

Lemma refa176_not3456 : ~ @Equation3456 Fin3 refa176_inst.
Proof. unfold Equation3456. intro H. specialize (H F3_1). unfold magma_op, refa176_inst, refa176_op in H. discriminate H. Qed.

Lemma refa176_not3862 : ~ @Equation3862 Fin3 refa176_inst.
Proof. unfold Equation3862. intro H. specialize (H F3_1). unfold magma_op, refa176_inst, refa176_op in H. discriminate H. Qed.

(** ---- refa177 (Fin3) ---- *)

Definition refa177_op (x y : Fin3) : Fin3 :=
  match x, y with
  | F3_0, F3_0 => F3_0 | F3_0, F3_1 => F3_0 | F3_0, F3_2 => F3_1
  | F3_1, F3_0 => F3_1 | F3_1, F3_1 => F3_2 | F3_1, F3_2 => F3_1
  | F3_2, F3_0 => F3_0 | F3_2, F3_1 => F3_2 | F3_2, F3_2 => F3_2
  end.

#[local] Instance refa177_inst : Magma Fin3 := {| magma_op := refa177_op |}.

Lemma refa177_sat839 : @Equation839 Fin3 refa177_inst.
Proof. unfold Equation839, magma_op, refa177_inst, refa177_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa177_not105 : ~ @Equation105 Fin3 refa177_inst.
Proof. unfold Equation105. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa177_inst, refa177_op in H. discriminate H. Qed.

Lemma refa177_not818 : ~ @Equation818 Fin3 refa177_inst.
Proof. unfold Equation818. intro H. specialize (H F3_2 F3_0). unfold magma_op, refa177_inst, refa177_op in H. discriminate H. Qed.

Lemma refa177_not820 : ~ @Equation820 Fin3 refa177_inst.
Proof. unfold Equation820. intro H. specialize (H F3_2 F3_0). unfold magma_op, refa177_inst, refa177_op in H. discriminate H. Qed.

Lemma refa177_not832 : ~ @Equation832 Fin3 refa177_inst.
Proof. unfold Equation832. intro H. specialize (H F3_1 F3_0). unfold magma_op, refa177_inst, refa177_op in H. discriminate H. Qed.

Lemma refa177_not835 : ~ @Equation835 Fin3 refa177_inst.
Proof. unfold Equation835. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa177_inst, refa177_op in H. discriminate H. Qed.

Lemma refa177_not1224 : ~ @Equation1224 Fin3 refa177_inst.
Proof. unfold Equation1224. intro H. specialize (H F3_2 F3_0). unfold magma_op, refa177_inst, refa177_op in H. discriminate H. Qed.

Lemma refa177_not1226 : ~ @Equation1226 Fin3 refa177_inst.
Proof. unfold Equation1226. intro H. specialize (H F3_2 F3_0). unfold magma_op, refa177_inst, refa177_op in H. discriminate H. Qed.

Lemma refa177_not1239 : ~ @Equation1239 Fin3 refa177_inst.
Proof. unfold Equation1239. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa177_inst, refa177_op in H. discriminate H. Qed.

Lemma refa177_not1242 : ~ @Equation1242 Fin3 refa177_inst.
Proof. unfold Equation1242. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa177_inst, refa177_op in H. discriminate H. Qed.

Lemma refa177_not3864 : ~ @Equation3864 Fin3 refa177_inst.
Proof. unfold Equation3864. intro H. specialize (H F3_2 F3_0). unfold magma_op, refa177_inst, refa177_op in H. discriminate H. Qed.

Lemma refa177_not3870 : ~ @Equation3870 Fin3 refa177_inst.
Proof. unfold Equation3870. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa177_inst, refa177_op in H. discriminate H. Qed.

Lemma refa177_not3928 : ~ @Equation3928 Fin3 refa177_inst.
Proof. unfold Equation3928. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa177_inst, refa177_op in H. discriminate H. Qed.

(** ---- refa178 (Fin3) ---- *)

Definition refa178_op (x y : Fin3) : Fin3 :=
  match x, y with
  | F3_0, F3_0 => F3_0 | F3_0, F3_1 => F3_0 | F3_0, F3_2 => F3_0
  | F3_1, F3_0 => F3_1 | F3_1, F3_1 => F3_0 | F3_1, F3_2 => F3_2
  | F3_2, F3_0 => F3_2 | F3_2, F3_1 => F3_1 | F3_2, F3_2 => F3_0
  end.

#[local] Instance refa178_inst : Magma Fin3 := {| magma_op := refa178_op |}.

Lemma refa178_sat360 : @Equation360 Fin3 refa178_inst.
Proof. unfold Equation360, magma_op, refa178_inst, refa178_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa178_sat1060 : @Equation1060 Fin3 refa178_inst.
Proof. unfold Equation1060, magma_op, refa178_inst, refa178_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa178_sat1240 : @Equation1240 Fin3 refa178_inst.
Proof. unfold Equation1240, magma_op, refa178_inst, refa178_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa178_sat1263 : @Equation1263 Fin3 refa178_inst.
Proof. unfold Equation1263, magma_op, refa178_inst, refa178_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa178_sat1267 : @Equation1267 Fin3 refa178_inst.
Proof. unfold Equation1267, magma_op, refa178_inst, refa178_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa178_not105 : ~ @Equation105 Fin3 refa178_inst.
Proof. unfold Equation105. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa178_inst, refa178_op in H. discriminate H. Qed.

Lemma refa178_not378 : ~ @Equation378 Fin3 refa178_inst.
Proof. unfold Equation378. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa178_inst, refa178_op in H. discriminate H. Qed.

Lemma refa178_not413 : ~ @Equation413 Fin3 refa178_inst.
Proof. unfold Equation413. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa178_inst, refa178_op in H. discriminate H. Qed.

Lemma refa178_not437 : ~ @Equation437 Fin3 refa178_inst.
Proof. unfold Equation437. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa178_inst, refa178_op in H. discriminate H. Qed.

Lemma refa178_not1022 : ~ @Equation1022 Fin3 refa178_inst.
Proof. unfold Equation1022. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa178_inst, refa178_op in H. discriminate H. Qed.

Lemma refa178_not1046 : ~ @Equation1046 Fin3 refa178_inst.
Proof. unfold Equation1046. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa178_inst, refa178_op in H. discriminate H. Qed.

Lemma refa178_not1048 : ~ @Equation1048 Fin3 refa178_inst.
Proof. unfold Equation1048. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa178_inst, refa178_op in H. discriminate H. Qed.

Lemma refa178_not1229 : ~ @Equation1229 Fin3 refa178_inst.
Proof. unfold Equation1229. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa178_inst, refa178_op in H. discriminate H. Qed.

Lemma refa178_not1241 : ~ @Equation1241 Fin3 refa178_inst.
Proof. unfold Equation1241. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa178_inst, refa178_op in H. discriminate H. Qed.

Lemma refa178_not3255 : ~ @Equation3255 Fin3 refa178_inst.
Proof. unfold Equation3255. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa178_inst, refa178_op in H. discriminate H. Qed.

Lemma refa178_not3316 : ~ @Equation3316 Fin3 refa178_inst.
Proof. unfold Equation3316. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa178_inst, refa178_op in H. discriminate H. Qed.

Lemma refa178_not3724 : ~ @Equation3724 Fin3 refa178_inst.
Proof. unfold Equation3724. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa178_inst, refa178_op in H. discriminate H. Qed.

Lemma refa178_not3925 : ~ @Equation3925 Fin3 refa178_inst.
Proof. unfold Equation3925. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa178_inst, refa178_op in H. discriminate H. Qed.

Lemma refa178_not4314 : ~ @Equation4314 Fin3 refa178_inst.
Proof. unfold Equation4314. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa178_inst, refa178_op in H. discriminate H. Qed.

Lemma refa178_not4598 : ~ @Equation4598 Fin3 refa178_inst.
Proof. unfold Equation4598. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa178_inst, refa178_op in H. discriminate H. Qed.

(** ---- refa179 (Fin3) ---- *)

Definition refa179_op (x y : Fin3) : Fin3 :=
  match x, y with
  | F3_0, F3_0 => F3_0 | F3_0, F3_1 => F3_0 | F3_0, F3_2 => F3_0
  | F3_1, F3_0 => F3_0 | F3_1, F3_1 => F3_2 | F3_1, F3_2 => F3_0
  | F3_2, F3_0 => F3_1 | F3_2, F3_1 => F3_0 | F3_2, F3_2 => F3_1
  end.

#[local] Instance refa179_inst : Magma Fin3 := {| magma_op := refa179_op |}.

Lemma refa179_sat4393 : @Equation4393 Fin3 refa179_inst.
Proof. unfold Equation4393, magma_op, refa179_inst, refa179_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa179_sat4646 : @Equation4646 Fin3 refa179_inst.
Proof. unfold Equation4646, magma_op, refa179_inst, refa179_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa179_not4314 : ~ @Equation4314 Fin3 refa179_inst.
Proof. unfold Equation4314. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa179_inst, refa179_op in H. discriminate H. Qed.

Lemma refa179_not4316 : ~ @Equation4316 Fin3 refa179_inst.
Proof. unfold Equation4316. intro H. specialize (H F3_2 F3_0 F3_2). unfold magma_op, refa179_inst, refa179_op in H. discriminate H. Qed.

Lemma refa179_not4320 : ~ @Equation4320 Fin3 refa179_inst.
Proof. unfold Equation4320. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa179_inst, refa179_op in H. discriminate H. Qed.

Lemma refa179_not4321 : ~ @Equation4321 Fin3 refa179_inst.
Proof. unfold Equation4321. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa179_inst, refa179_op in H. discriminate H. Qed.

Lemma refa179_not4332 : ~ @Equation4332 Fin3 refa179_inst.
Proof. unfold Equation4332. intro H. specialize (H F3_0 F3_0 F3_2). unfold magma_op, refa179_inst, refa179_op in H. discriminate H. Qed.

Lemma refa179_not4583 : ~ @Equation4583 Fin3 refa179_inst.
Proof. unfold Equation4583. intro H. specialize (H F3_1 F3_0). unfold magma_op, refa179_inst, refa179_op in H. discriminate H. Qed.

Lemma refa179_not4598 : ~ @Equation4598 Fin3 refa179_inst.
Proof. unfold Equation4598. intro H. specialize (H F3_1 F3_0). unfold magma_op, refa179_inst, refa179_op in H. discriminate H. Qed.

Lemma refa179_not4599 : ~ @Equation4599 Fin3 refa179_inst.
Proof. unfold Equation4599. intro H. specialize (H F3_1 F3_0). unfold magma_op, refa179_inst, refa179_op in H. discriminate H. Qed.

Lemma refa179_not4605 : ~ @Equation4605 Fin3 refa179_inst.
Proof. unfold Equation4605. intro H. specialize (H F3_1 F3_0). unfold magma_op, refa179_inst, refa179_op in H. discriminate H. Qed.

Lemma refa179_not4606 : ~ @Equation4606 Fin3 refa179_inst.
Proof. unfold Equation4606. intro H. specialize (H F3_1 F3_0). unfold magma_op, refa179_inst, refa179_op in H. discriminate H. Qed.

Lemma refa179_not4608 : ~ @Equation4608 Fin3 refa179_inst.
Proof. unfold Equation4608. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa179_inst, refa179_op in H. discriminate H. Qed.

Lemma refa179_not4622 : ~ @Equation4622 Fin3 refa179_inst.
Proof. unfold Equation4622. intro H. specialize (H F3_0 F3_0 F3_1). unfold magma_op, refa179_inst, refa179_op in H. discriminate H. Qed.

Lemma refa179_not4677 : ~ @Equation4677 Fin3 refa179_inst.
Proof. unfold Equation4677. intro H. specialize (H F3_0 F3_2 F3_1). unfold magma_op, refa179_inst, refa179_op in H. discriminate H. Qed.

(** ---- refa18 (Fin7) ---- *)

Definition refa18_op (x y : Fin7) : Fin7 :=
  match x, y with
  | F7_0, F7_0 => F7_1 | F7_0, F7_1 => F7_2 | F7_0, F7_2 => F7_3 | F7_0, F7_3 => F7_4 | F7_0, F7_4 => F7_5 | F7_0, F7_5 => F7_0 | F7_0, F7_6 => F7_6
  | F7_1, F7_0 => F7_3 | F7_1, F7_1 => F7_1 | F7_1, F7_2 => F7_6 | F7_1, F7_3 => F7_5 | F7_1, F7_4 => F7_2 | F7_1, F7_5 => F7_4 | F7_1, F7_6 => F7_0
  | F7_2, F7_0 => F7_2 | F7_2, F7_1 => F7_5 | F7_2, F7_2 => F7_1 | F7_2, F7_3 => F7_0 | F7_2, F7_4 => F7_4 | F7_2, F7_5 => F7_6 | F7_2, F7_6 => F7_3
  | F7_3, F7_0 => F7_0 | F7_3, F7_1 => F7_6 | F7_3, F7_2 => F7_4 | F7_3, F7_3 => F7_1 | F7_3, F7_4 => F7_3 | F7_3, F7_5 => F7_2 | F7_3, F7_6 => F7_5
  | F7_4, F7_0 => F7_6 | F7_4, F7_1 => F7_3 | F7_4, F7_2 => F7_0 | F7_4, F7_3 => F7_2 | F7_4, F7_4 => F7_1 | F7_4, F7_5 => F7_5 | F7_4, F7_6 => F7_4
  | F7_5, F7_0 => F7_4 | F7_5, F7_1 => F7_0 | F7_5, F7_2 => F7_5 | F7_5, F7_3 => F7_3 | F7_5, F7_4 => F7_6 | F7_5, F7_5 => F7_1 | F7_5, F7_6 => F7_2
  | F7_6, F7_0 => F7_5 | F7_6, F7_1 => F7_4 | F7_6, F7_2 => F7_2 | F7_6, F7_3 => F7_6 | F7_6, F7_4 => F7_0 | F7_6, F7_5 => F7_3 | F7_6, F7_6 => F7_1
  end.

#[local] Instance refa18_inst : Magma Fin7 := {| magma_op := refa18_op |}.

Lemma refa18_sat2244 : @Equation2244 Fin7 refa18_inst.
Proof. unfold Equation2244, magma_op, refa18_inst, refa18_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa18_not1426 : ~ @Equation1426 Fin7 refa18_inst.
Proof. unfold Equation1426. intro H. specialize (H F7_0). unfold magma_op, refa18_inst, refa18_op in H. discriminate H. Qed.

Lemma refa18_not1629 : ~ @Equation1629 Fin7 refa18_inst.
Proof. unfold Equation1629. intro H. specialize (H F7_0). unfold magma_op, refa18_inst, refa18_op in H. discriminate H. Qed.

Lemma refa18_not1832 : ~ @Equation1832 Fin7 refa18_inst.
Proof. unfold Equation1832. intro H. specialize (H F7_0). unfold magma_op, refa18_inst, refa18_op in H. discriminate H. Qed.

Lemma refa18_not2256 : ~ @Equation2256 Fin7 refa18_inst.
Proof. unfold Equation2256. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa18_inst, refa18_op in H. discriminate H. Qed.

Lemma refa18_not2441 : ~ @Equation2441 Fin7 refa18_inst.
Proof. unfold Equation2441. intro H. specialize (H F7_0). unfold magma_op, refa18_inst, refa18_op in H. discriminate H. Qed.

Lemma refa18_not3050 : ~ @Equation3050 Fin7 refa18_inst.
Proof. unfold Equation3050. intro H. specialize (H F7_0). unfold magma_op, refa18_inst, refa18_op in H. discriminate H. Qed.

Lemma refa18_not3253 : ~ @Equation3253 Fin7 refa18_inst.
Proof. unfold Equation3253. intro H. specialize (H F7_0). unfold magma_op, refa18_inst, refa18_op in H. discriminate H. Qed.

Lemma refa18_not3456 : ~ @Equation3456 Fin7 refa18_inst.
Proof. unfold Equation3456. intro H. specialize (H F7_0). unfold magma_op, refa18_inst, refa18_op in H. discriminate H. Qed.

Lemma refa18_not4065 : ~ @Equation4065 Fin7 refa18_inst.
Proof. unfold Equation4065. intro H. specialize (H F7_0). unfold magma_op, refa18_inst, refa18_op in H. discriminate H. Qed.

Lemma refa18_not4283 : ~ @Equation4283 Fin7 refa18_inst.
Proof. unfold Equation4283. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa18_inst, refa18_op in H. discriminate H. Qed.

Lemma refa18_not4656 : ~ @Equation4656 Fin7 refa18_inst.
Proof. unfold Equation4656. intro H. specialize (H F7_0 F7_0 F7_1). unfold magma_op, refa18_inst, refa18_op in H. discriminate H. Qed.

(** ---- refa180 (Fin3) ---- *)

Definition refa180_op (x y : Fin3) : Fin3 :=
  match x, y with
  | F3_0, F3_0 => F3_0 | F3_0, F3_1 => F3_0 | F3_0, F3_2 => F3_1
  | F3_1, F3_0 => F3_1 | F3_1, F3_1 => F3_0 | F3_1, F3_2 => F3_0
  | F3_2, F3_0 => F3_2 | F3_2, F3_1 => F3_1 | F3_2, F3_2 => F3_1
  end.

#[local] Instance refa180_inst : Magma Fin3 := {| magma_op := refa180_op |}.

Lemma refa180_sat835 : @Equation835 Fin3 refa180_inst.
Proof. unfold Equation835, magma_op, refa180_inst, refa180_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa180_sat847 : @Equation847 Fin3 refa180_inst.
Proof. unfold Equation847, magma_op, refa180_inst, refa180_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa180_sat1052 : @Equation1052 Fin3 refa180_inst.
Proof. unfold Equation1052, magma_op, refa180_inst, refa180_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa180_sat4093 : @Equation4093 Fin3 refa180_inst.
Proof. unfold Equation4093, magma_op, refa180_inst, refa180_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa180_not105 : ~ @Equation105 Fin3 refa180_inst.
Proof. unfold Equation105. intro H. specialize (H F3_2 F3_0). unfold magma_op, refa180_inst, refa180_op in H. discriminate H. Qed.

Lemma refa180_not107 : ~ @Equation107 Fin3 refa180_inst.
Proof. unfold Equation107. intro H. specialize (H F3_2 F3_0). unfold magma_op, refa180_inst, refa180_op in H. discriminate H. Qed.

Lemma refa180_not359 : ~ @Equation359 Fin3 refa180_inst.
Proof. unfold Equation359. intro H. specialize (H F3_2). unfold magma_op, refa180_inst, refa180_op in H. discriminate H. Qed.

Lemma refa180_not411 : ~ @Equation411 Fin3 refa180_inst.
Proof. unfold Equation411. intro H. specialize (H F3_2). unfold magma_op, refa180_inst, refa180_op in H. discriminate H. Qed.

Lemma refa180_not819 : ~ @Equation819 Fin3 refa180_inst.
Proof. unfold Equation819. intro H. specialize (H F3_2 F3_1). unfold magma_op, refa180_inst, refa180_op in H. discriminate H. Qed.

Lemma refa180_not832 : ~ @Equation832 Fin3 refa180_inst.
Proof. unfold Equation832. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa180_inst, refa180_op in H. discriminate H. Qed.

Lemma refa180_not833 : ~ @Equation833 Fin3 refa180_inst.
Proof. unfold Equation833. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa180_inst, refa180_op in H. discriminate H. Qed.

Lemma refa180_not836 : ~ @Equation836 Fin3 refa180_inst.
Proof. unfold Equation836. intro H. specialize (H F3_2 F3_0). unfold magma_op, refa180_inst, refa180_op in H. discriminate H. Qed.

Lemma refa180_not842 : ~ @Equation842 Fin3 refa180_inst.
Proof. unfold Equation842. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa180_inst, refa180_op in H. discriminate H. Qed.

Lemma refa180_not843 : ~ @Equation843 Fin3 refa180_inst.
Proof. unfold Equation843. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa180_inst, refa180_op in H. discriminate H. Qed.

Lemma refa180_not1023 : ~ @Equation1023 Fin3 refa180_inst.
Proof. unfold Equation1023. intro H. specialize (H F3_2 F3_0). unfold magma_op, refa180_inst, refa180_op in H. discriminate H. Qed.

Lemma refa180_not1028 : ~ @Equation1028 Fin3 refa180_inst.
Proof. unfold Equation1028. intro H. specialize (H F3_2 F3_0). unfold magma_op, refa180_inst, refa180_op in H. discriminate H. Qed.

Lemma refa180_not1035 : ~ @Equation1035 Fin3 refa180_inst.
Proof. unfold Equation1035. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa180_inst, refa180_op in H. discriminate H. Qed.

Lemma refa180_not1036 : ~ @Equation1036 Fin3 refa180_inst.
Proof. unfold Equation1036. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa180_inst, refa180_op in H. discriminate H. Qed.

Lemma refa180_not1038 : ~ @Equation1038 Fin3 refa180_inst.
Proof. unfold Equation1038. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa180_inst, refa180_op in H. discriminate H. Qed.

Lemma refa180_not1039 : ~ @Equation1039 Fin3 refa180_inst.
Proof. unfold Equation1039. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa180_inst, refa180_op in H. discriminate H. Qed.

Lemma refa180_not1045 : ~ @Equation1045 Fin3 refa180_inst.
Proof. unfold Equation1045. intro H. specialize (H F3_2 F3_0). unfold magma_op, refa180_inst, refa180_op in H. discriminate H. Qed.

Lemma refa180_not1048 : ~ @Equation1048 Fin3 refa180_inst.
Proof. unfold Equation1048. intro H. specialize (H F3_2 F3_0). unfold magma_op, refa180_inst, refa180_op in H. discriminate H. Qed.

Lemma refa180_not1223 : ~ @Equation1223 Fin3 refa180_inst.
Proof. unfold Equation1223. intro H. specialize (H F3_2). unfold magma_op, refa180_inst, refa180_op in H. discriminate H. Qed.

Lemma refa180_not1832 : ~ @Equation1832 Fin3 refa180_inst.
Proof. unfold Equation1832. intro H. specialize (H F3_2). unfold magma_op, refa180_inst, refa180_op in H. discriminate H. Qed.

Lemma refa180_not3255 : ~ @Equation3255 Fin3 refa180_inst.
Proof. unfold Equation3255. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa180_inst, refa180_op in H. discriminate H. Qed.

Lemma refa180_not3256 : ~ @Equation3256 Fin3 refa180_inst.
Proof. unfold Equation3256. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa180_inst, refa180_op in H. discriminate H. Qed.

Lemma refa180_not3278 : ~ @Equation3278 Fin3 refa180_inst.
Proof. unfold Equation3278. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa180_inst, refa180_op in H. discriminate H. Qed.

Lemma refa180_not3279 : ~ @Equation3279 Fin3 refa180_inst.
Proof. unfold Equation3279. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa180_inst, refa180_op in H. discriminate H. Qed.

Lemma refa180_not3306 : ~ @Equation3306 Fin3 refa180_inst.
Proof. unfold Equation3306. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa180_inst, refa180_op in H. discriminate H. Qed.

Lemma refa180_not3315 : ~ @Equation3315 Fin3 refa180_inst.
Proof. unfold Equation3315. intro H. specialize (H F3_2 F3_1). unfold magma_op, refa180_inst, refa180_op in H. discriminate H. Qed.

Lemma refa180_not3316 : ~ @Equation3316 Fin3 refa180_inst.
Proof. unfold Equation3316. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa180_inst, refa180_op in H. discriminate H. Qed.

Lemma refa180_not3318 : ~ @Equation3318 Fin3 refa180_inst.
Proof. unfold Equation3318. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa180_inst, refa180_op in H. discriminate H. Qed.

Lemma refa180_not3319 : ~ @Equation3319 Fin3 refa180_inst.
Proof. unfold Equation3319. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa180_inst, refa180_op in H. discriminate H. Qed.

Lemma refa180_not3659 : ~ @Equation3659 Fin3 refa180_inst.
Proof. unfold Equation3659. intro H. specialize (H F3_2). unfold magma_op, refa180_inst, refa180_op in H. discriminate H. Qed.

Lemma refa180_not3862 : ~ @Equation3862 Fin3 refa180_inst.
Proof. unfold Equation3862. intro H. specialize (H F3_2). unfold magma_op, refa180_inst, refa180_op in H. discriminate H. Qed.

Lemma refa180_not4066 : ~ @Equation4066 Fin3 refa180_inst.
Proof. unfold Equation4066. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa180_inst, refa180_op in H. discriminate H. Qed.

Lemma refa180_not4067 : ~ @Equation4067 Fin3 refa180_inst.
Proof. unfold Equation4067. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa180_inst, refa180_op in H. discriminate H. Qed.

Lemma refa180_not4068 : ~ @Equation4068 Fin3 refa180_inst.
Proof. unfold Equation4068. intro H. specialize (H F3_2 F3_1). unfold magma_op, refa180_inst, refa180_op in H. discriminate H. Qed.

Lemma refa180_not4070 : ~ @Equation4070 Fin3 refa180_inst.
Proof. unfold Equation4070. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa180_inst, refa180_op in H. discriminate H. Qed.

Lemma refa180_not4071 : ~ @Equation4071 Fin3 refa180_inst.
Proof. unfold Equation4071. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa180_inst, refa180_op in H. discriminate H. Qed.

Lemma refa180_not4083 : ~ @Equation4083 Fin3 refa180_inst.
Proof. unfold Equation4083. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa180_inst, refa180_op in H. discriminate H. Qed.

Lemma refa180_not4084 : ~ @Equation4084 Fin3 refa180_inst.
Proof. unfold Equation4084. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa180_inst, refa180_op in H. discriminate H. Qed.

Lemma refa180_not4090 : ~ @Equation4090 Fin3 refa180_inst.
Proof. unfold Equation4090. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa180_inst, refa180_op in H. discriminate H. Qed.

Lemma refa180_not4091 : ~ @Equation4091 Fin3 refa180_inst.
Proof. unfold Equation4091. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa180_inst, refa180_op in H. discriminate H. Qed.

Lemma refa180_not4131 : ~ @Equation4131 Fin3 refa180_inst.
Proof. unfold Equation4131. intro H. specialize (H F3_2 F3_1). unfold magma_op, refa180_inst, refa180_op in H. discriminate H. Qed.

Lemma refa180_not4269 : ~ @Equation4269 Fin3 refa180_inst.
Proof. unfold Equation4269. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa180_inst, refa180_op in H. discriminate H. Qed.

Lemma refa180_not4270 : ~ @Equation4270 Fin3 refa180_inst.
Proof. unfold Equation4270. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa180_inst, refa180_op in H. discriminate H. Qed.

Lemma refa180_not4293 : ~ @Equation4293 Fin3 refa180_inst.
Proof. unfold Equation4293. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa180_inst, refa180_op in H. discriminate H. Qed.

Lemma refa180_not4314 : ~ @Equation4314 Fin3 refa180_inst.
Proof. unfold Equation4314. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa180_inst, refa180_op in H. discriminate H. Qed.

Lemma refa180_not4583 : ~ @Equation4583 Fin3 refa180_inst.
Proof. unfold Equation4583. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa180_inst, refa180_op in H. discriminate H. Qed.

Lemma refa180_not4588 : ~ @Equation4588 Fin3 refa180_inst.
Proof. unfold Equation4588. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa180_inst, refa180_op in H. discriminate H. Qed.

Lemma refa180_not4598 : ~ @Equation4598 Fin3 refa180_inst.
Proof. unfold Equation4598. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa180_inst, refa180_op in H. discriminate H. Qed.

Lemma refa180_not4606 : ~ @Equation4606 Fin3 refa180_inst.
Proof. unfold Equation4606. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa180_inst, refa180_op in H. discriminate H. Qed.

Lemma refa180_not4622 : ~ @Equation4622 Fin3 refa180_inst.
Proof. unfold Equation4622. intro H. specialize (H F3_0 F3_0 F3_2). unfold magma_op, refa180_inst, refa180_op in H. discriminate H. Qed.

Lemma refa180_not4631 : ~ @Equation4631 Fin3 refa180_inst.
Proof. unfold Equation4631. intro H. specialize (H F3_0 F3_0 F3_2). unfold magma_op, refa180_inst, refa180_op in H. discriminate H. Qed.

(** ---- refa181 (Fin3) ---- *)

Definition refa181_op (x y : Fin3) : Fin3 :=
  match x, y with
  | F3_0, F3_0 => F3_0 | F3_0, F3_1 => F3_0 | F3_0, F3_2 => F3_0
  | F3_1, F3_0 => F3_1 | F3_1, F3_1 => F3_1 | F3_1, F3_2 => F3_0
  | F3_2, F3_0 => F3_2 | F3_2, F3_1 => F3_0 | F3_2, F3_2 => F3_2
  end.

#[local] Instance refa181_inst : Magma Fin3 := {| magma_op := refa181_op |}.

Lemma refa181_sat1037 : @Equation1037 Fin3 refa181_inst.
Proof. unfold Equation1037, magma_op, refa181_inst, refa181_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa181_not53 : ~ @Equation53 Fin3 refa181_inst.
Proof. unfold Equation53. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa181_inst, refa181_op in H. discriminate H. Qed.

Lemma refa181_not55 : ~ @Equation55 Fin3 refa181_inst.
Proof. unfold Equation55. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa181_inst, refa181_op in H. discriminate H. Qed.

Lemma refa181_not56 : ~ @Equation56 Fin3 refa181_inst.
Proof. unfold Equation56. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa181_inst, refa181_op in H. discriminate H. Qed.

Lemma refa181_not108 : ~ @Equation108 Fin3 refa181_inst.
Proof. unfold Equation108. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa181_inst, refa181_op in H. discriminate H. Qed.

Lemma refa181_not159 : ~ @Equation159 Fin3 refa181_inst.
Proof. unfold Equation159. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa181_inst, refa181_op in H. discriminate H. Qed.

Lemma refa181_not160 : ~ @Equation160 Fin3 refa181_inst.
Proof. unfold Equation160. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa181_inst, refa181_op in H. discriminate H. Qed.

Lemma refa181_not206 : ~ @Equation206 Fin3 refa181_inst.
Proof. unfold Equation206. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa181_inst, refa181_op in H. discriminate H. Qed.

Lemma refa181_not209 : ~ @Equation209 Fin3 refa181_inst.
Proof. unfold Equation209. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa181_inst, refa181_op in H. discriminate H. Qed.

Lemma refa181_not211 : ~ @Equation211 Fin3 refa181_inst.
Proof. unfold Equation211. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa181_inst, refa181_op in H. discriminate H. Qed.

Lemma refa181_not261 : ~ @Equation261 Fin3 refa181_inst.
Proof. unfold Equation261. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa181_inst, refa181_op in H. discriminate H. Qed.

Lemma refa181_not263 : ~ @Equation263 Fin3 refa181_inst.
Proof. unfold Equation263. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa181_inst, refa181_op in H. discriminate H. Qed.

Lemma refa181_not264 : ~ @Equation264 Fin3 refa181_inst.
Proof. unfold Equation264. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa181_inst, refa181_op in H. discriminate H. Qed.

Lemma refa181_not430 : ~ @Equation430 Fin3 refa181_inst.
Proof. unfold Equation430. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa181_inst, refa181_op in H. discriminate H. Qed.

Lemma refa181_not436 : ~ @Equation436 Fin3 refa181_inst.
Proof. unfold Equation436. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa181_inst, refa181_op in H. discriminate H. Qed.

Lemma refa181_not437 : ~ @Equation437 Fin3 refa181_inst.
Proof. unfold Equation437. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa181_inst, refa181_op in H. discriminate H. Qed.

Lemma refa181_not439 : ~ @Equation439 Fin3 refa181_inst.
Proof. unfold Equation439. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa181_inst, refa181_op in H. discriminate H. Qed.

Lemma refa181_not440 : ~ @Equation440 Fin3 refa181_inst.
Proof. unfold Equation440. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa181_inst, refa181_op in H. discriminate H. Qed.

Lemma refa181_not630 : ~ @Equation630 Fin3 refa181_inst.
Proof. unfold Equation630. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa181_inst, refa181_op in H. discriminate H. Qed.

Lemma refa181_not632 : ~ @Equation632 Fin3 refa181_inst.
Proof. unfold Equation632. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa181_inst, refa181_op in H. discriminate H. Qed.

Lemma refa181_not633 : ~ @Equation633 Fin3 refa181_inst.
Proof. unfold Equation633. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa181_inst, refa181_op in H. discriminate H. Qed.

Lemma refa181_not639 : ~ @Equation639 Fin3 refa181_inst.
Proof. unfold Equation639. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa181_inst, refa181_op in H. discriminate H. Qed.

Lemma refa181_not640 : ~ @Equation640 Fin3 refa181_inst.
Proof. unfold Equation640. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa181_inst, refa181_op in H. discriminate H. Qed.

Lemma refa181_not642 : ~ @Equation642 Fin3 refa181_inst.
Proof. unfold Equation642. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa181_inst, refa181_op in H. discriminate H. Qed.

Lemma refa181_not643 : ~ @Equation643 Fin3 refa181_inst.
Proof. unfold Equation643. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa181_inst, refa181_op in H. discriminate H. Qed.

Lemma refa181_not843 : ~ @Equation843 Fin3 refa181_inst.
Proof. unfold Equation843. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa181_inst, refa181_op in H. discriminate H. Qed.

Lemma refa181_not845 : ~ @Equation845 Fin3 refa181_inst.
Proof. unfold Equation845. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa181_inst, refa181_op in H. discriminate H. Qed.

Lemma refa181_not846 : ~ @Equation846 Fin3 refa181_inst.
Proof. unfold Equation846. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa181_inst, refa181_op in H. discriminate H. Qed.

Lemma refa181_not1039 : ~ @Equation1039 Fin3 refa181_inst.
Proof. unfold Equation1039. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa181_inst, refa181_op in H. discriminate H. Qed.

Lemma refa181_not1046 : ~ @Equation1046 Fin3 refa181_inst.
Proof. unfold Equation1046. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa181_inst, refa181_op in H. discriminate H. Qed.

Lemma refa181_not1049 : ~ @Equation1049 Fin3 refa181_inst.
Proof. unfold Equation1049. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa181_inst, refa181_op in H. discriminate H. Qed.

Lemma refa181_not1252 : ~ @Equation1252 Fin3 refa181_inst.
Proof. unfold Equation1252. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa181_inst, refa181_op in H. discriminate H. Qed.

Lemma refa181_not1432 : ~ @Equation1432 Fin3 refa181_inst.
Proof. unfold Equation1432. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa181_inst, refa181_op in H. discriminate H. Qed.

Lemma refa181_not1434 : ~ @Equation1434 Fin3 refa181_inst.
Proof. unfold Equation1434. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa181_inst, refa181_op in H. discriminate H. Qed.

Lemma refa181_not1435 : ~ @Equation1435 Fin3 refa181_inst.
Proof. unfold Equation1435. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa181_inst, refa181_op in H. discriminate H. Qed.

Lemma refa181_not1441 : ~ @Equation1441 Fin3 refa181_inst.
Proof. unfold Equation1441. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa181_inst, refa181_op in H. discriminate H. Qed.

Lemma refa181_not1444 : ~ @Equation1444 Fin3 refa181_inst.
Proof. unfold Equation1444. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa181_inst, refa181_op in H. discriminate H. Qed.

Lemma refa181_not1445 : ~ @Equation1445 Fin3 refa181_inst.
Proof. unfold Equation1445. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa181_inst, refa181_op in H. discriminate H. Qed.

Lemma refa181_not1451 : ~ @Equation1451 Fin3 refa181_inst.
Proof. unfold Equation1451. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa181_inst, refa181_op in H. discriminate H. Qed.

Lemma refa181_not1454 : ~ @Equation1454 Fin3 refa181_inst.
Proof. unfold Equation1454. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa181_inst, refa181_op in H. discriminate H. Qed.

Lemma refa181_not1638 : ~ @Equation1638 Fin3 refa181_inst.
Proof. unfold Equation1638. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa181_inst, refa181_op in H. discriminate H. Qed.

Lemma refa181_not1644 : ~ @Equation1644 Fin3 refa181_inst.
Proof. unfold Equation1644. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa181_inst, refa181_op in H. discriminate H. Qed.

Lemma refa181_not1645 : ~ @Equation1645 Fin3 refa181_inst.
Proof. unfold Equation1645. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa181_inst, refa181_op in H. discriminate H. Qed.

Lemma refa181_not1648 : ~ @Equation1648 Fin3 refa181_inst.
Proof. unfold Equation1648. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa181_inst, refa181_op in H. discriminate H. Qed.

Lemma refa181_not1654 : ~ @Equation1654 Fin3 refa181_inst.
Proof. unfold Equation1654. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa181_inst, refa181_op in H. discriminate H. Qed.

Lemma refa181_not1655 : ~ @Equation1655 Fin3 refa181_inst.
Proof. unfold Equation1655. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa181_inst, refa181_op in H. discriminate H. Qed.

Lemma refa181_not1657 : ~ @Equation1657 Fin3 refa181_inst.
Proof. unfold Equation1657. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa181_inst, refa181_op in H. discriminate H. Qed.

Lemma refa181_not1841 : ~ @Equation1841 Fin3 refa181_inst.
Proof. unfold Equation1841. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa181_inst, refa181_op in H. discriminate H. Qed.

Lemma refa181_not1851 : ~ @Equation1851 Fin3 refa181_inst.
Proof. unfold Equation1851. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa181_inst, refa181_op in H. discriminate H. Qed.

Lemma refa181_not1857 : ~ @Equation1857 Fin3 refa181_inst.
Proof. unfold Equation1857. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa181_inst, refa181_op in H. discriminate H. Qed.

Lemma refa181_not1858 : ~ @Equation1858 Fin3 refa181_inst.
Proof. unfold Equation1858. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa181_inst, refa181_op in H. discriminate H. Qed.

Lemma refa181_not1860 : ~ @Equation1860 Fin3 refa181_inst.
Proof. unfold Equation1860. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa181_inst, refa181_op in H. discriminate H. Qed.

Lemma refa181_not1861 : ~ @Equation1861 Fin3 refa181_inst.
Proof. unfold Equation1861. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa181_inst, refa181_op in H. discriminate H. Qed.

Lemma refa181_not2038 : ~ @Equation2038 Fin3 refa181_inst.
Proof. unfold Equation2038. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa181_inst, refa181_op in H. discriminate H. Qed.

Lemma refa181_not2040 : ~ @Equation2040 Fin3 refa181_inst.
Proof. unfold Equation2040. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa181_inst, refa181_op in H. discriminate H. Qed.

Lemma refa181_not2041 : ~ @Equation2041 Fin3 refa181_inst.
Proof. unfold Equation2041. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa181_inst, refa181_op in H. discriminate H. Qed.

Lemma refa181_not2043 : ~ @Equation2043 Fin3 refa181_inst.
Proof. unfold Equation2043. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa181_inst, refa181_op in H. discriminate H. Qed.

Lemma refa181_not2044 : ~ @Equation2044 Fin3 refa181_inst.
Proof. unfold Equation2044. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa181_inst, refa181_op in H. discriminate H. Qed.

Lemma refa181_not2050 : ~ @Equation2050 Fin3 refa181_inst.
Proof. unfold Equation2050. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa181_inst, refa181_op in H. discriminate H. Qed.

Lemma refa181_not2053 : ~ @Equation2053 Fin3 refa181_inst.
Proof. unfold Equation2053. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa181_inst, refa181_op in H. discriminate H. Qed.

Lemma refa181_not2054 : ~ @Equation2054 Fin3 refa181_inst.
Proof. unfold Equation2054. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa181_inst, refa181_op in H. discriminate H. Qed.

Lemma refa181_not2060 : ~ @Equation2060 Fin3 refa181_inst.
Proof. unfold Equation2060. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa181_inst, refa181_op in H. discriminate H. Qed.

Lemma refa181_not2061 : ~ @Equation2061 Fin3 refa181_inst.
Proof. unfold Equation2061. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa181_inst, refa181_op in H. discriminate H. Qed.

Lemma refa181_not2063 : ~ @Equation2063 Fin3 refa181_inst.
Proof. unfold Equation2063. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa181_inst, refa181_op in H. discriminate H. Qed.

Lemma refa181_not2064 : ~ @Equation2064 Fin3 refa181_inst.
Proof. unfold Equation2064. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa181_inst, refa181_op in H. discriminate H. Qed.

Lemma refa181_not2241 : ~ @Equation2241 Fin3 refa181_inst.
Proof. unfold Equation2241. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa181_inst, refa181_op in H. discriminate H. Qed.

Lemma refa181_not2244 : ~ @Equation2244 Fin3 refa181_inst.
Proof. unfold Equation2244. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa181_inst, refa181_op in H. discriminate H. Qed.

Lemma refa181_not2247 : ~ @Equation2247 Fin3 refa181_inst.
Proof. unfold Equation2247. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa181_inst, refa181_op in H. discriminate H. Qed.

Lemma refa181_not2254 : ~ @Equation2254 Fin3 refa181_inst.
Proof. unfold Equation2254. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa181_inst, refa181_op in H. discriminate H. Qed.

Lemma refa181_not2256 : ~ @Equation2256 Fin3 refa181_inst.
Proof. unfold Equation2256. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa181_inst, refa181_op in H. discriminate H. Qed.

Lemma refa181_not2257 : ~ @Equation2257 Fin3 refa181_inst.
Proof. unfold Equation2257. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa181_inst, refa181_op in H. discriminate H. Qed.

Lemma refa181_not2263 : ~ @Equation2263 Fin3 refa181_inst.
Proof. unfold Equation2263. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa181_inst, refa181_op in H. discriminate H. Qed.

Lemma refa181_not2264 : ~ @Equation2264 Fin3 refa181_inst.
Proof. unfold Equation2264. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa181_inst, refa181_op in H. discriminate H. Qed.

Lemma refa181_not2266 : ~ @Equation2266 Fin3 refa181_inst.
Proof. unfold Equation2266. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa181_inst, refa181_op in H. discriminate H. Qed.

Lemma refa181_not2267 : ~ @Equation2267 Fin3 refa181_inst.
Proof. unfold Equation2267. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa181_inst, refa181_op in H. discriminate H. Qed.

Lemma refa181_not2444 : ~ @Equation2444 Fin3 refa181_inst.
Proof. unfold Equation2444. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa181_inst, refa181_op in H. discriminate H. Qed.

Lemma refa181_not2447 : ~ @Equation2447 Fin3 refa181_inst.
Proof. unfold Equation2447. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa181_inst, refa181_op in H. discriminate H. Qed.

Lemma refa181_not2450 : ~ @Equation2450 Fin3 refa181_inst.
Proof. unfold Equation2450. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa181_inst, refa181_op in H. discriminate H. Qed.

Lemma refa181_not2457 : ~ @Equation2457 Fin3 refa181_inst.
Proof. unfold Equation2457. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa181_inst, refa181_op in H. discriminate H. Qed.

Lemma refa181_not2460 : ~ @Equation2460 Fin3 refa181_inst.
Proof. unfold Equation2460. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa181_inst, refa181_op in H. discriminate H. Qed.

Lemma refa181_not2467 : ~ @Equation2467 Fin3 refa181_inst.
Proof. unfold Equation2467. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa181_inst, refa181_op in H. discriminate H. Qed.

Lemma refa181_not2469 : ~ @Equation2469 Fin3 refa181_inst.
Proof. unfold Equation2469. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa181_inst, refa181_op in H. discriminate H. Qed.

Lemma refa181_not2470 : ~ @Equation2470 Fin3 refa181_inst.
Proof. unfold Equation2470. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa181_inst, refa181_op in H. discriminate H. Qed.

Lemma refa181_not2647 : ~ @Equation2647 Fin3 refa181_inst.
Proof. unfold Equation2647. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa181_inst, refa181_op in H. discriminate H. Qed.

Lemma refa181_not2650 : ~ @Equation2650 Fin3 refa181_inst.
Proof. unfold Equation2650. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa181_inst, refa181_op in H. discriminate H. Qed.

Lemma refa181_not2652 : ~ @Equation2652 Fin3 refa181_inst.
Proof. unfold Equation2652. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa181_inst, refa181_op in H. discriminate H. Qed.

Lemma refa181_not2659 : ~ @Equation2659 Fin3 refa181_inst.
Proof. unfold Equation2659. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa181_inst, refa181_op in H. discriminate H. Qed.

Lemma refa181_not2660 : ~ @Equation2660 Fin3 refa181_inst.
Proof. unfold Equation2660. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa181_inst, refa181_op in H. discriminate H. Qed.

Lemma refa181_not2662 : ~ @Equation2662 Fin3 refa181_inst.
Proof. unfold Equation2662. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa181_inst, refa181_op in H. discriminate H. Qed.

Lemma refa181_not2669 : ~ @Equation2669 Fin3 refa181_inst.
Proof. unfold Equation2669. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa181_inst, refa181_op in H. discriminate H. Qed.

Lemma refa181_not2670 : ~ @Equation2670 Fin3 refa181_inst.
Proof. unfold Equation2670. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa181_inst, refa181_op in H. discriminate H. Qed.

Lemma refa181_not2672 : ~ @Equation2672 Fin3 refa181_inst.
Proof. unfold Equation2672. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa181_inst, refa181_op in H. discriminate H. Qed.

Lemma refa181_not2849 : ~ @Equation2849 Fin3 refa181_inst.
Proof. unfold Equation2849. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa181_inst, refa181_op in H. discriminate H. Qed.

Lemma refa181_not2853 : ~ @Equation2853 Fin3 refa181_inst.
Proof. unfold Equation2853. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa181_inst, refa181_op in H. discriminate H. Qed.

Lemma refa181_not2855 : ~ @Equation2855 Fin3 refa181_inst.
Proof. unfold Equation2855. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa181_inst, refa181_op in H. discriminate H. Qed.

Lemma refa181_not2856 : ~ @Equation2856 Fin3 refa181_inst.
Proof. unfold Equation2856. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa181_inst, refa181_op in H. discriminate H. Qed.

Lemma refa181_not2863 : ~ @Equation2863 Fin3 refa181_inst.
Proof. unfold Equation2863. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa181_inst, refa181_op in H. discriminate H. Qed.

Lemma refa181_not2865 : ~ @Equation2865 Fin3 refa181_inst.
Proof. unfold Equation2865. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa181_inst, refa181_op in H. discriminate H. Qed.

Lemma refa181_not2866 : ~ @Equation2866 Fin3 refa181_inst.
Proof. unfold Equation2866. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa181_inst, refa181_op in H. discriminate H. Qed.

Lemma refa181_not2872 : ~ @Equation2872 Fin3 refa181_inst.
Proof. unfold Equation2872. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa181_inst, refa181_op in H. discriminate H. Qed.

Lemma refa181_not2873 : ~ @Equation2873 Fin3 refa181_inst.
Proof. unfold Equation2873. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa181_inst, refa181_op in H. discriminate H. Qed.

Lemma refa181_not2875 : ~ @Equation2875 Fin3 refa181_inst.
Proof. unfold Equation2875. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa181_inst, refa181_op in H. discriminate H. Qed.

Lemma refa181_not3052 : ~ @Equation3052 Fin3 refa181_inst.
Proof. unfold Equation3052. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa181_inst, refa181_op in H. discriminate H. Qed.

Lemma refa181_not3055 : ~ @Equation3055 Fin3 refa181_inst.
Proof. unfold Equation3055. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa181_inst, refa181_op in H. discriminate H. Qed.

Lemma refa181_not3056 : ~ @Equation3056 Fin3 refa181_inst.
Proof. unfold Equation3056. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa181_inst, refa181_op in H. discriminate H. Qed.

Lemma refa181_not3058 : ~ @Equation3058 Fin3 refa181_inst.
Proof. unfold Equation3058. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa181_inst, refa181_op in H. discriminate H. Qed.

Lemma refa181_not3065 : ~ @Equation3065 Fin3 refa181_inst.
Proof. unfold Equation3065. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa181_inst, refa181_op in H. discriminate H. Qed.

Lemma refa181_not3066 : ~ @Equation3066 Fin3 refa181_inst.
Proof. unfold Equation3066. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa181_inst, refa181_op in H. discriminate H. Qed.

Lemma refa181_not3068 : ~ @Equation3068 Fin3 refa181_inst.
Proof. unfold Equation3068. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa181_inst, refa181_op in H. discriminate H. Qed.

Lemma refa181_not3069 : ~ @Equation3069 Fin3 refa181_inst.
Proof. unfold Equation3069. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa181_inst, refa181_op in H. discriminate H. Qed.

Lemma refa181_not3075 : ~ @Equation3075 Fin3 refa181_inst.
Proof. unfold Equation3075. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa181_inst, refa181_op in H. discriminate H. Qed.

Lemma refa181_not3076 : ~ @Equation3076 Fin3 refa181_inst.
Proof. unfold Equation3076. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa181_inst, refa181_op in H. discriminate H. Qed.

Lemma refa181_not3078 : ~ @Equation3078 Fin3 refa181_inst.
Proof. unfold Equation3078. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa181_inst, refa181_op in H. discriminate H. Qed.

Lemma refa181_not3079 : ~ @Equation3079 Fin3 refa181_inst.
Proof. unfold Equation3079. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa181_inst, refa181_op in H. discriminate H. Qed.

Lemma refa181_not3259 : ~ @Equation3259 Fin3 refa181_inst.
Proof. unfold Equation3259. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa181_inst, refa181_op in H. discriminate H. Qed.

Lemma refa181_not3261 : ~ @Equation3261 Fin3 refa181_inst.
Proof. unfold Equation3261. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa181_inst, refa181_op in H. discriminate H. Qed.

Lemma refa181_not3262 : ~ @Equation3262 Fin3 refa181_inst.
Proof. unfold Equation3262. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa181_inst, refa181_op in H. discriminate H. Qed.

Lemma refa181_not3306 : ~ @Equation3306 Fin3 refa181_inst.
Proof. unfold Equation3306. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa181_inst, refa181_op in H. discriminate H. Qed.

Lemma refa181_not3308 : ~ @Equation3308 Fin3 refa181_inst.
Proof. unfold Equation3308. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa181_inst, refa181_op in H. discriminate H. Qed.

Lemma refa181_not3309 : ~ @Equation3309 Fin3 refa181_inst.
Proof. unfold Equation3309. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa181_inst, refa181_op in H. discriminate H. Qed.

Lemma refa181_not3315 : ~ @Equation3315 Fin3 refa181_inst.
Proof. unfold Equation3315. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa181_inst, refa181_op in H. discriminate H. Qed.

Lemma refa181_not3465 : ~ @Equation3465 Fin3 refa181_inst.
Proof. unfold Equation3465. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa181_inst, refa181_op in H. discriminate H. Qed.

Lemma refa181_not3509 : ~ @Equation3509 Fin3 refa181_inst.
Proof. unfold Equation3509. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa181_inst, refa181_op in H. discriminate H. Qed.

Lemma refa181_not3511 : ~ @Equation3511 Fin3 refa181_inst.
Proof. unfold Equation3511. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa181_inst, refa181_op in H. discriminate H. Qed.

Lemma refa181_not3512 : ~ @Equation3512 Fin3 refa181_inst.
Proof. unfold Equation3512. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa181_inst, refa181_op in H. discriminate H. Qed.

Lemma refa181_not3518 : ~ @Equation3518 Fin3 refa181_inst.
Proof. unfold Equation3518. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa181_inst, refa181_op in H. discriminate H. Qed.

Lemma refa181_not3519 : ~ @Equation3519 Fin3 refa181_inst.
Proof. unfold Equation3519. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa181_inst, refa181_op in H. discriminate H. Qed.

Lemma refa181_not3521 : ~ @Equation3521 Fin3 refa181_inst.
Proof. unfold Equation3521. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa181_inst, refa181_op in H. discriminate H. Qed.

Lemma refa181_not3662 : ~ @Equation3662 Fin3 refa181_inst.
Proof. unfold Equation3662. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa181_inst, refa181_op in H. discriminate H. Qed.

Lemma refa181_not3664 : ~ @Equation3664 Fin3 refa181_inst.
Proof. unfold Equation3664. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa181_inst, refa181_op in H. discriminate H. Qed.

Lemma refa181_not3665 : ~ @Equation3665 Fin3 refa181_inst.
Proof. unfold Equation3665. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa181_inst, refa181_op in H. discriminate H. Qed.

Lemma refa181_not3667 : ~ @Equation3667 Fin3 refa181_inst.
Proof. unfold Equation3667. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa181_inst, refa181_op in H. discriminate H. Qed.

Lemma refa181_not3668 : ~ @Equation3668 Fin3 refa181_inst.
Proof. unfold Equation3668. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa181_inst, refa181_op in H. discriminate H. Qed.

Lemma refa181_not3712 : ~ @Equation3712 Fin3 refa181_inst.
Proof. unfold Equation3712. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa181_inst, refa181_op in H. discriminate H. Qed.

Lemma refa181_not3714 : ~ @Equation3714 Fin3 refa181_inst.
Proof. unfold Equation3714. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa181_inst, refa181_op in H. discriminate H. Qed.

Lemma refa181_not3728 : ~ @Equation3728 Fin3 refa181_inst.
Proof. unfold Equation3728. intro H. specialize (H F3_1 F3_0 F3_2). unfold magma_op, refa181_inst, refa181_op in H. discriminate H. Qed.

Lemma refa181_not3865 : ~ @Equation3865 Fin3 refa181_inst.
Proof. unfold Equation3865. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa181_inst, refa181_op in H. discriminate H. Qed.

Lemma refa181_not3868 : ~ @Equation3868 Fin3 refa181_inst.
Proof. unfold Equation3868. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa181_inst, refa181_op in H. discriminate H. Qed.

Lemma refa181_not3870 : ~ @Equation3870 Fin3 refa181_inst.
Proof. unfold Equation3870. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa181_inst, refa181_op in H. discriminate H. Qed.

Lemma refa181_not3871 : ~ @Equation3871 Fin3 refa181_inst.
Proof. unfold Equation3871. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa181_inst, refa181_op in H. discriminate H. Qed.

Lemma refa181_not3917 : ~ @Equation3917 Fin3 refa181_inst.
Proof. unfold Equation3917. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa181_inst, refa181_op in H. discriminate H. Qed.

Lemma refa181_not3924 : ~ @Equation3924 Fin3 refa181_inst.
Proof. unfold Equation3924. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa181_inst, refa181_op in H. discriminate H. Qed.

Lemma refa181_not3939 : ~ @Equation3939 Fin3 refa181_inst.
Proof. unfold Equation3939. intro H. specialize (H F3_1 F3_0 F3_2). unfold magma_op, refa181_inst, refa181_op in H. discriminate H. Qed.

Lemma refa181_not4066 : ~ @Equation4066 Fin3 refa181_inst.
Proof. unfold Equation4066. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa181_inst, refa181_op in H. discriminate H. Qed.

Lemma refa181_not4067 : ~ @Equation4067 Fin3 refa181_inst.
Proof. unfold Equation4067. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa181_inst, refa181_op in H. discriminate H. Qed.

Lemma refa181_not4068 : ~ @Equation4068 Fin3 refa181_inst.
Proof. unfold Equation4068. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa181_inst, refa181_op in H. discriminate H. Qed.

Lemma refa181_not4070 : ~ @Equation4070 Fin3 refa181_inst.
Proof. unfold Equation4070. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa181_inst, refa181_op in H. discriminate H. Qed.

Lemma refa181_not4071 : ~ @Equation4071 Fin3 refa181_inst.
Proof. unfold Equation4071. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa181_inst, refa181_op in H. discriminate H. Qed.

Lemma refa181_not4073 : ~ @Equation4073 Fin3 refa181_inst.
Proof. unfold Equation4073. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa181_inst, refa181_op in H. discriminate H. Qed.

Lemma refa181_not4074 : ~ @Equation4074 Fin3 refa181_inst.
Proof. unfold Equation4074. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa181_inst, refa181_op in H. discriminate H. Qed.

Lemma refa181_not4270 : ~ @Equation4270 Fin3 refa181_inst.
Proof. unfold Equation4270. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa181_inst, refa181_op in H. discriminate H. Qed.

Lemma refa181_not4284 : ~ @Equation4284 Fin3 refa181_inst.
Proof. unfold Equation4284. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa181_inst, refa181_op in H. discriminate H. Qed.

Lemma refa181_not4314 : ~ @Equation4314 Fin3 refa181_inst.
Proof. unfold Equation4314. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa181_inst, refa181_op in H. discriminate H. Qed.

Lemma refa181_not4358 : ~ @Equation4358 Fin3 refa181_inst.
Proof. unfold Equation4358. intro H. specialize (H F3_1 F3_0 F3_2). unfold magma_op, refa181_inst, refa181_op in H. discriminate H. Qed.

Lemma refa181_not4396 : ~ @Equation4396 Fin3 refa181_inst.
Proof. unfold Equation4396. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa181_inst, refa181_op in H. discriminate H. Qed.

Lemma refa181_not4398 : ~ @Equation4398 Fin3 refa181_inst.
Proof. unfold Equation4398. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa181_inst, refa181_op in H. discriminate H. Qed.

Lemma refa181_not4399 : ~ @Equation4399 Fin3 refa181_inst.
Proof. unfold Equation4399. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa181_inst, refa181_op in H. discriminate H. Qed.

Lemma refa181_not4433 : ~ @Equation4433 Fin3 refa181_inst.
Proof. unfold Equation4433. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa181_inst, refa181_op in H. discriminate H. Qed.

Lemma refa181_not4435 : ~ @Equation4435 Fin3 refa181_inst.
Proof. unfold Equation4435. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa181_inst, refa181_op in H. discriminate H. Qed.

Lemma refa181_not4436 : ~ @Equation4436 Fin3 refa181_inst.
Proof. unfold Equation4436. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa181_inst, refa181_op in H. discriminate H. Qed.

Lemma refa181_not4583 : ~ @Equation4583 Fin3 refa181_inst.
Proof. unfold Equation4583. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa181_inst, refa181_op in H. discriminate H. Qed.

Lemma refa181_not4584 : ~ @Equation4584 Fin3 refa181_inst.
Proof. unfold Equation4584. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa181_inst, refa181_op in H. discriminate H. Qed.

Lemma refa181_not4585 : ~ @Equation4585 Fin3 refa181_inst.
Proof. unfold Equation4585. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa181_inst, refa181_op in H. discriminate H. Qed.

(** ---- refa182 (Fin3) ---- *)

Definition refa182_op (x y : Fin3) : Fin3 :=
  match x, y with
  | F3_0, F3_0 => F3_0 | F3_0, F3_1 => F3_0 | F3_0, F3_2 => F3_1
  | F3_1, F3_0 => F3_2 | F3_1, F3_1 => F3_0 | F3_1, F3_2 => F3_1
  | F3_2, F3_0 => F3_0 | F3_2, F3_1 => F3_0 | F3_2, F3_2 => F3_1
  end.

#[local] Instance refa182_inst : Magma Fin3 := {| magma_op := refa182_op |}.

Lemma refa182_sat1484 : @Equation1484 Fin3 refa182_inst.
Proof. unfold Equation1484, magma_op, refa182_inst, refa182_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa182_sat3883 : @Equation3883 Fin3 refa182_inst.
Proof. unfold Equation3883, magma_op, refa182_inst, refa182_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa182_not47 : ~ @Equation47 Fin3 refa182_inst.
Proof. unfold Equation47. intro H. specialize (H F3_2). unfold magma_op, refa182_inst, refa182_op in H. discriminate H. Qed.

Lemma refa182_not307 : ~ @Equation307 Fin3 refa182_inst.
Proof. unfold Equation307. intro H. specialize (H F3_1). unfold magma_op, refa182_inst, refa182_op in H. discriminate H. Qed.

Lemma refa182_not3255 : ~ @Equation3255 Fin3 refa182_inst.
Proof. unfold Equation3255. intro H. specialize (H F3_1 F3_0). unfold magma_op, refa182_inst, refa182_op in H. discriminate H. Qed.

Lemma refa182_not3268 : ~ @Equation3268 Fin3 refa182_inst.
Proof. unfold Equation3268. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa182_inst, refa182_op in H. discriminate H. Qed.

Lemma refa182_not3271 : ~ @Equation3271 Fin3 refa182_inst.
Proof. unfold Equation3271. intro H. specialize (H F3_1 F3_0). unfold magma_op, refa182_inst, refa182_op in H. discriminate H. Qed.

Lemma refa182_not3278 : ~ @Equation3278 Fin3 refa182_inst.
Proof. unfold Equation3278. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa182_inst, refa182_op in H. discriminate H. Qed.

Lemma refa182_not3281 : ~ @Equation3281 Fin3 refa182_inst.
Proof. unfold Equation3281. intro H. specialize (H F3_1 F3_1). unfold magma_op, refa182_inst, refa182_op in H. discriminate H. Qed.

Lemma refa182_not3326 : ~ @Equation3326 Fin3 refa182_inst.
Proof. unfold Equation3326. intro H. specialize (H F3_0 F3_0 F3_1). unfold magma_op, refa182_inst, refa182_op in H. discriminate H. Qed.

Lemma refa182_not3334 : ~ @Equation3334 Fin3 refa182_inst.
Proof. unfold Equation3334. intro H. specialize (H F3_0 F3_1 F3_1). unfold magma_op, refa182_inst, refa182_op in H. discriminate H. Qed.

Lemma refa182_not3343 : ~ @Equation3343 Fin3 refa182_inst.
Proof. unfold Equation3343. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa182_inst, refa182_op in H. discriminate H. Qed.

Lemma refa182_not3346 : ~ @Equation3346 Fin3 refa182_inst.
Proof. unfold Equation3346. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa182_inst, refa182_op in H. discriminate H. Qed.

Lemma refa182_not3458 : ~ @Equation3458 Fin3 refa182_inst.
Proof. unfold Equation3458. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa182_inst, refa182_op in H. discriminate H. Qed.

Lemma refa182_not3461 : ~ @Equation3461 Fin3 refa182_inst.
Proof. unfold Equation3461. intro H. specialize (H F3_1 F3_0). unfold magma_op, refa182_inst, refa182_op in H. discriminate H. Qed.

Lemma refa182_not3464 : ~ @Equation3464 Fin3 refa182_inst.
Proof. unfold Equation3464. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa182_inst, refa182_op in H. discriminate H. Qed.

Lemma refa182_not3474 : ~ @Equation3474 Fin3 refa182_inst.
Proof. unfold Equation3474. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa182_inst, refa182_op in H. discriminate H. Qed.

Lemma refa182_not3481 : ~ @Equation3481 Fin3 refa182_inst.
Proof. unfold Equation3481. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa182_inst, refa182_op in H. discriminate H. Qed.

Lemma refa182_not3484 : ~ @Equation3484 Fin3 refa182_inst.
Proof. unfold Equation3484. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa182_inst, refa182_op in H. discriminate H. Qed.

Lemma refa182_not3509 : ~ @Equation3509 Fin3 refa182_inst.
Proof. unfold Equation3509. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa182_inst, refa182_op in H. discriminate H. Qed.

Lemma refa182_not3512 : ~ @Equation3512 Fin3 refa182_inst.
Proof. unfold Equation3512. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa182_inst, refa182_op in H. discriminate H. Qed.

Lemma refa182_not3519 : ~ @Equation3519 Fin3 refa182_inst.
Proof. unfold Equation3519. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa182_inst, refa182_op in H. discriminate H. Qed.

Lemma refa182_not3522 : ~ @Equation3522 Fin3 refa182_inst.
Proof. unfold Equation3522. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa182_inst, refa182_op in H. discriminate H. Qed.

Lemma refa182_not3659 : ~ @Equation3659 Fin3 refa182_inst.
Proof. unfold Equation3659. intro H. specialize (H F3_2). unfold magma_op, refa182_inst, refa182_op in H. discriminate H. Qed.

Lemma refa182_not3867 : ~ @Equation3867 Fin3 refa182_inst.
Proof. unfold Equation3867. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa182_inst, refa182_op in H. discriminate H. Qed.

Lemma refa182_not3887 : ~ @Equation3887 Fin3 refa182_inst.
Proof. unfold Equation3887. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa182_inst, refa182_op in H. discriminate H. Qed.

Lemma refa182_not3915 : ~ @Equation3915 Fin3 refa182_inst.
Proof. unfold Equation3915. intro H. specialize (H F3_1 F3_0). unfold magma_op, refa182_inst, refa182_op in H. discriminate H. Qed.

Lemma refa182_not3925 : ~ @Equation3925 Fin3 refa182_inst.
Proof. unfold Equation3925. intro H. specialize (H F3_1 F3_0). unfold magma_op, refa182_inst, refa182_op in H. discriminate H. Qed.

Lemma refa182_not3928 : ~ @Equation3928 Fin3 refa182_inst.
Proof. unfold Equation3928. intro H. specialize (H F3_1 F3_0). unfold magma_op, refa182_inst, refa182_op in H. discriminate H. Qed.

Lemma refa182_not3952 : ~ @Equation3952 Fin3 refa182_inst.
Proof. unfold Equation3952. intro H. specialize (H F3_1 F3_0). unfold magma_op, refa182_inst, refa182_op in H. discriminate H. Qed.

Lemma refa182_not3962 : ~ @Equation3962 Fin3 refa182_inst.
Proof. unfold Equation3962. intro H. specialize (H F3_1 F3_0). unfold magma_op, refa182_inst, refa182_op in H. discriminate H. Qed.

Lemma refa182_not4067 : ~ @Equation4067 Fin3 refa182_inst.
Proof. unfold Equation4067. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa182_inst, refa182_op in H. discriminate H. Qed.

Lemma refa182_not4073 : ~ @Equation4073 Fin3 refa182_inst.
Proof. unfold Equation4073. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa182_inst, refa182_op in H. discriminate H. Qed.

Lemma refa182_not4083 : ~ @Equation4083 Fin3 refa182_inst.
Proof. unfold Equation4083. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa182_inst, refa182_op in H. discriminate H. Qed.

Lemma refa182_not4093 : ~ @Equation4093 Fin3 refa182_inst.
Proof. unfold Equation4093. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa182_inst, refa182_op in H. discriminate H. Qed.

Lemma refa182_not4118 : ~ @Equation4118 Fin3 refa182_inst.
Proof. unfold Equation4118. intro H. specialize (H F3_1 F3_0). unfold magma_op, refa182_inst, refa182_op in H. discriminate H. Qed.

Lemma refa182_not4121 : ~ @Equation4121 Fin3 refa182_inst.
Proof. unfold Equation4121. intro H. specialize (H F3_1 F3_0). unfold magma_op, refa182_inst, refa182_op in H. discriminate H. Qed.

Lemma refa182_not4128 : ~ @Equation4128 Fin3 refa182_inst.
Proof. unfold Equation4128. intro H. specialize (H F3_1 F3_0). unfold magma_op, refa182_inst, refa182_op in H. discriminate H. Qed.

Lemma refa182_not4131 : ~ @Equation4131 Fin3 refa182_inst.
Proof. unfold Equation4131. intro H. specialize (H F3_1 F3_0). unfold magma_op, refa182_inst, refa182_op in H. discriminate H. Qed.

Lemma refa182_not4155 : ~ @Equation4155 Fin3 refa182_inst.
Proof. unfold Equation4155. intro H. specialize (H F3_1 F3_0). unfold magma_op, refa182_inst, refa182_op in H. discriminate H. Qed.

Lemma refa182_not4158 : ~ @Equation4158 Fin3 refa182_inst.
Proof. unfold Equation4158. intro H. specialize (H F3_1 F3_0). unfold magma_op, refa182_inst, refa182_op in H. discriminate H. Qed.

Lemma refa182_not4165 : ~ @Equation4165 Fin3 refa182_inst.
Proof. unfold Equation4165. intro H. specialize (H F3_1 F3_0). unfold magma_op, refa182_inst, refa182_op in H. discriminate H. Qed.

Lemma refa182_not4269 : ~ @Equation4269 Fin3 refa182_inst.
Proof. unfold Equation4269. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa182_inst, refa182_op in H. discriminate H. Qed.

Lemma refa182_not4272 : ~ @Equation4272 Fin3 refa182_inst.
Proof. unfold Equation4272. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa182_inst, refa182_op in H. discriminate H. Qed.

Lemma refa182_not4275 : ~ @Equation4275 Fin3 refa182_inst.
Proof. unfold Equation4275. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa182_inst, refa182_op in H. discriminate H. Qed.

Lemma refa182_not4284 : ~ @Equation4284 Fin3 refa182_inst.
Proof. unfold Equation4284. intro H. specialize (H F3_1 F3_0). unfold magma_op, refa182_inst, refa182_op in H. discriminate H. Qed.

Lemma refa182_not4291 : ~ @Equation4291 Fin3 refa182_inst.
Proof. unfold Equation4291. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa182_inst, refa182_op in H. discriminate H. Qed.

Lemma refa182_not4320 : ~ @Equation4320 Fin3 refa182_inst.
Proof. unfold Equation4320. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa182_inst, refa182_op in H. discriminate H. Qed.

Lemma refa182_not4380 : ~ @Equation4380 Fin3 refa182_inst.
Proof. unfold Equation4380. intro H. specialize (H F3_1). unfold magma_op, refa182_inst, refa182_op in H. discriminate H. Qed.

Lemma refa182_not4584 : ~ @Equation4584 Fin3 refa182_inst.
Proof. unfold Equation4584. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa182_inst, refa182_op in H. discriminate H. Qed.

Lemma refa182_not4599 : ~ @Equation4599 Fin3 refa182_inst.
Proof. unfold Equation4599. intro H. specialize (H F3_2 F3_0). unfold magma_op, refa182_inst, refa182_op in H. discriminate H. Qed.

Lemma refa182_not4635 : ~ @Equation4635 Fin3 refa182_inst.
Proof. unfold Equation4635. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa182_inst, refa182_op in H. discriminate H. Qed.

(** ---- refa183 (Fin3) ---- *)

Definition refa183_op (x y : Fin3) : Fin3 :=
  match x, y with
  | F3_0, F3_0 => F3_0 | F3_0, F3_1 => F3_2 | F3_0, F3_2 => F3_1
  | F3_1, F3_0 => F3_0 | F3_1, F3_1 => F3_2 | F3_1, F3_2 => F3_1
  | F3_2, F3_0 => F3_1 | F3_2, F3_1 => F3_1 | F3_2, F3_2 => F3_0
  end.

#[local] Instance refa183_inst : Magma Fin3 := {| magma_op := refa183_op |}.

Lemma refa183_sat1691 : @Equation1691 Fin3 refa183_inst.
Proof. unfold Equation1691, magma_op, refa183_inst, refa183_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa183_not3253 : ~ @Equation3253 Fin3 refa183_inst.
Proof. unfold Equation3253. intro H. specialize (H F3_2). unfold magma_op, refa183_inst, refa183_op in H. discriminate H. Qed.

(** ---- refa184 (Fin3) ---- *)

Definition refa184_op (x y : Fin3) : Fin3 :=
  match x, y with
  | F3_0, F3_0 => F3_0 | F3_0, F3_1 => F3_1 | F3_0, F3_2 => F3_2
  | F3_1, F3_0 => F3_1 | F3_1, F3_1 => F3_0 | F3_1, F3_2 => F3_0
  | F3_2, F3_0 => F3_2 | F3_2, F3_1 => F3_1 | F3_2, F3_2 => F3_1
  end.

#[local] Instance refa184_inst : Magma Fin3 := {| magma_op := refa184_op |}.

Lemma refa184_sat2949 : @Equation2949 Fin3 refa184_inst.
Proof. unfold Equation2949, magma_op, refa184_inst, refa184_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa184_not1629 : ~ @Equation1629 Fin3 refa184_inst.
Proof. unfold Equation1629. intro H. specialize (H F3_2). unfold magma_op, refa184_inst, refa184_op in H. discriminate H. Qed.

Lemma refa184_not2238 : ~ @Equation2238 Fin3 refa184_inst.
Proof. unfold Equation2238. intro H. specialize (H F3_2). unfold magma_op, refa184_inst, refa184_op in H. discriminate H. Qed.

Lemma refa184_not2441 : ~ @Equation2441 Fin3 refa184_inst.
Proof. unfold Equation2441. intro H. specialize (H F3_2). unfold magma_op, refa184_inst, refa184_op in H. discriminate H. Qed.

Lemma refa184_not2652 : ~ @Equation2652 Fin3 refa184_inst.
Proof. unfold Equation2652. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa184_inst, refa184_op in H. discriminate H. Qed.

Lemma refa184_not2662 : ~ @Equation2662 Fin3 refa184_inst.
Proof. unfold Equation2662. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa184_inst, refa184_op in H. discriminate H. Qed.

Lemma refa184_not2669 : ~ @Equation2669 Fin3 refa184_inst.
Proof. unfold Equation2669. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa184_inst, refa184_op in H. discriminate H. Qed.

Lemma refa184_not2673 : ~ @Equation2673 Fin3 refa184_inst.
Proof. unfold Equation2673. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa184_inst, refa184_op in H. discriminate H. Qed.

Lemma refa184_not2697 : ~ @Equation2697 Fin3 refa184_inst.
Proof. unfold Equation2697. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa184_inst, refa184_op in H. discriminate H. Qed.

Lemma refa184_not2699 : ~ @Equation2699 Fin3 refa184_inst.
Proof. unfold Equation2699. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa184_inst, refa184_op in H. discriminate H. Qed.

Lemma refa184_not2744 : ~ @Equation2744 Fin3 refa184_inst.
Proof. unfold Equation2744. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa184_inst, refa184_op in H. discriminate H. Qed.

Lemma refa184_not2855 : ~ @Equation2855 Fin3 refa184_inst.
Proof. unfold Equation2855. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa184_inst, refa184_op in H. discriminate H. Qed.

Lemma refa184_not2865 : ~ @Equation2865 Fin3 refa184_inst.
Proof. unfold Equation2865. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa184_inst, refa184_op in H. discriminate H. Qed.

Lemma refa184_not2872 : ~ @Equation2872 Fin3 refa184_inst.
Proof. unfold Equation2872. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa184_inst, refa184_op in H. discriminate H. Qed.

Lemma refa184_not2900 : ~ @Equation2900 Fin3 refa184_inst.
Proof. unfold Equation2900. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa184_inst, refa184_op in H. discriminate H. Qed.

Lemma refa184_not2902 : ~ @Equation2902 Fin3 refa184_inst.
Proof. unfold Equation2902. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa184_inst, refa184_op in H. discriminate H. Qed.

Lemma refa184_not2909 : ~ @Equation2909 Fin3 refa184_inst.
Proof. unfold Equation2909. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa184_inst, refa184_op in H. discriminate H. Qed.

Lemma refa184_not3050 : ~ @Equation3050 Fin3 refa184_inst.
Proof. unfold Equation3050. intro H. specialize (H F3_2). unfold magma_op, refa184_inst, refa184_op in H. discriminate H. Qed.

Lemma refa184_not3256 : ~ @Equation3256 Fin3 refa184_inst.
Proof. unfold Equation3256. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa184_inst, refa184_op in H. discriminate H. Qed.

Lemma refa184_not3259 : ~ @Equation3259 Fin3 refa184_inst.
Proof. unfold Equation3259. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa184_inst, refa184_op in H. discriminate H. Qed.

Lemma refa184_not3261 : ~ @Equation3261 Fin3 refa184_inst.
Proof. unfold Equation3261. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa184_inst, refa184_op in H. discriminate H. Qed.

Lemma refa184_not3271 : ~ @Equation3271 Fin3 refa184_inst.
Proof. unfold Equation3271. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa184_inst, refa184_op in H. discriminate H. Qed.

Lemma refa184_not3278 : ~ @Equation3278 Fin3 refa184_inst.
Proof. unfold Equation3278. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa184_inst, refa184_op in H. discriminate H. Qed.

Lemma refa184_not3306 : ~ @Equation3306 Fin3 refa184_inst.
Proof. unfold Equation3306. intro H. specialize (H F3_2 F3_0). unfold magma_op, refa184_inst, refa184_op in H. discriminate H. Qed.

Lemma refa184_not3308 : ~ @Equation3308 Fin3 refa184_inst.
Proof. unfold Equation3308. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa184_inst, refa184_op in H. discriminate H. Qed.

Lemma refa184_not3315 : ~ @Equation3315 Fin3 refa184_inst.
Proof. unfold Equation3315. intro H. specialize (H F3_2 F3_0). unfold magma_op, refa184_inst, refa184_op in H. discriminate H. Qed.

Lemma refa184_not3342 : ~ @Equation3342 Fin3 refa184_inst.
Proof. unfold Equation3342. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa184_inst, refa184_op in H. discriminate H. Qed.

Lemma refa184_not3456 : ~ @Equation3456 Fin3 refa184_inst.
Proof. unfold Equation3456. intro H. specialize (H F3_2). unfold magma_op, refa184_inst, refa184_op in H. discriminate H. Qed.

Lemma refa184_not3659 : ~ @Equation3659 Fin3 refa184_inst.
Proof. unfold Equation3659. intro H. specialize (H F3_2). unfold magma_op, refa184_inst, refa184_op in H. discriminate H. Qed.

Lemma refa184_not3862 : ~ @Equation3862 Fin3 refa184_inst.
Proof. unfold Equation3862. intro H. specialize (H F3_2). unfold magma_op, refa184_inst, refa184_op in H. discriminate H. Qed.

Lemma refa184_not4065 : ~ @Equation4065 Fin3 refa184_inst.
Proof. unfold Equation4065. intro H. specialize (H F3_2). unfold magma_op, refa184_inst, refa184_op in H. discriminate H. Qed.

Lemma refa184_not4270 : ~ @Equation4270 Fin3 refa184_inst.
Proof. unfold Equation4270. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa184_inst, refa184_op in H. discriminate H. Qed.

Lemma refa184_not4273 : ~ @Equation4273 Fin3 refa184_inst.
Proof. unfold Equation4273. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa184_inst, refa184_op in H. discriminate H. Qed.

Lemma refa184_not4283 : ~ @Equation4283 Fin3 refa184_inst.
Proof. unfold Equation4283. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa184_inst, refa184_op in H. discriminate H. Qed.

Lemma refa184_not4290 : ~ @Equation4290 Fin3 refa184_inst.
Proof. unfold Equation4290. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa184_inst, refa184_op in H. discriminate H. Qed.

Lemma refa184_not4320 : ~ @Equation4320 Fin3 refa184_inst.
Proof. unfold Equation4320. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa184_inst, refa184_op in H. discriminate H. Qed.

Lemma refa184_not4386 : ~ @Equation4386 Fin3 refa184_inst.
Proof. unfold Equation4386. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa184_inst, refa184_op in H. discriminate H. Qed.

Lemma refa184_not4396 : ~ @Equation4396 Fin3 refa184_inst.
Proof. unfold Equation4396. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa184_inst, refa184_op in H. discriminate H. Qed.

Lemma refa184_not4398 : ~ @Equation4398 Fin3 refa184_inst.
Proof. unfold Equation4398. intro H. specialize (H F3_2 F3_1). unfold magma_op, refa184_inst, refa184_op in H. discriminate H. Qed.

Lemma refa184_not4405 : ~ @Equation4405 Fin3 refa184_inst.
Proof. unfold Equation4405. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa184_inst, refa184_op in H. discriminate H. Qed.

Lemma refa184_not4409 : ~ @Equation4409 Fin3 refa184_inst.
Proof. unfold Equation4409. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa184_inst, refa184_op in H. discriminate H. Qed.

Lemma refa184_not4433 : ~ @Equation4433 Fin3 refa184_inst.
Proof. unfold Equation4433. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa184_inst, refa184_op in H. discriminate H. Qed.

Lemma refa184_not4435 : ~ @Equation4435 Fin3 refa184_inst.
Proof. unfold Equation4435. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa184_inst, refa184_op in H. discriminate H. Qed.

Lemma refa184_not4442 : ~ @Equation4442 Fin3 refa184_inst.
Proof. unfold Equation4442. intro H. specialize (H F3_2 F3_2). unfold magma_op, refa184_inst, refa184_op in H. discriminate H. Qed.

Lemma refa184_not4473 : ~ @Equation4473 Fin3 refa184_inst.
Proof. unfold Equation4473. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa184_inst, refa184_op in H. discriminate H. Qed.

Lemma refa184_not4480 : ~ @Equation4480 Fin3 refa184_inst.
Proof. unfold Equation4480. intro H. specialize (H F3_2 F3_1). unfold magma_op, refa184_inst, refa184_op in H. discriminate H. Qed.

Lemma refa184_not4482 : ~ @Equation4482 Fin3 refa184_inst.
Proof. unfold Equation4482. intro H. specialize (H F3_2 F3_2). unfold magma_op, refa184_inst, refa184_op in H. discriminate H. Qed.

Lemma refa184_not4598 : ~ @Equation4598 Fin3 refa184_inst.
Proof. unfold Equation4598. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa184_inst, refa184_op in H. discriminate H. Qed.

Lemma refa184_not4622 : ~ @Equation4622 Fin3 refa184_inst.
Proof. unfold Equation4622. intro H. specialize (H F3_0 F3_0 F3_2). unfold magma_op, refa184_inst, refa184_op in H. discriminate H. Qed.

Lemma refa184_not4635 : ~ @Equation4635 Fin3 refa184_inst.
Proof. unfold Equation4635. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa184_inst, refa184_op in H. discriminate H. Qed.

Lemma refa184_not4656 : ~ @Equation4656 Fin3 refa184_inst.
Proof. unfold Equation4656. intro H. specialize (H F3_0 F3_0 F3_2). unfold magma_op, refa184_inst, refa184_op in H. discriminate H. Qed.

(** ---- refa185 (Fin3) ---- *)

Definition refa185_op (x y : Fin3) : Fin3 :=
  match x, y with
  | F3_0, F3_0 => F3_0 | F3_0, F3_1 => F3_0 | F3_0, F3_2 => F3_2
  | F3_1, F3_0 => F3_0 | F3_1, F3_1 => F3_0 | F3_1, F3_2 => F3_1
  | F3_2, F3_0 => F3_1 | F3_2, F3_1 => F3_1 | F3_2, F3_2 => F3_1
  end.

#[local] Instance refa185_inst : Magma Fin3 := {| magma_op := refa185_op |}.

Lemma refa185_sat3469 : @Equation3469 Fin3 refa185_inst.
Proof. unfold Equation3469, magma_op, refa185_inst, refa185_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa185_sat4489 : @Equation4489 Fin3 refa185_inst.
Proof. unfold Equation4489, magma_op, refa185_inst, refa185_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa185_not3457 : ~ @Equation3457 Fin3 refa185_inst.
Proof. unfold Equation3457. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa185_inst, refa185_op in H. discriminate H. Qed.

Lemma refa185_not4472 : ~ @Equation4472 Fin3 refa185_inst.
Proof. unfold Equation4472. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa185_inst, refa185_op in H. discriminate H. Qed.

Lemma refa185_not4482 : ~ @Equation4482 Fin3 refa185_inst.
Proof. unfold Equation4482. intro H. specialize (H F3_2 F3_0). unfold magma_op, refa185_inst, refa185_op in H. discriminate H. Qed.

Lemma refa185_not4590 : ~ @Equation4590 Fin3 refa185_inst.
Proof. unfold Equation4590. intro H. specialize (H F3_2 F3_0). unfold magma_op, refa185_inst, refa185_op in H. discriminate H. Qed.

Lemma refa185_not4599 : ~ @Equation4599 Fin3 refa185_inst.
Proof. unfold Equation4599. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa185_inst, refa185_op in H. discriminate H. Qed.

Lemma refa185_not4606 : ~ @Equation4606 Fin3 refa185_inst.
Proof. unfold Equation4606. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa185_inst, refa185_op in H. discriminate H. Qed.

Lemma refa185_not4635 : ~ @Equation4635 Fin3 refa185_inst.
Proof. unfold Equation4635. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa185_inst, refa185_op in H. discriminate H. Qed.

(** ---- refa186 (Fin3) ---- *)

Definition refa186_op (x y : Fin3) : Fin3 :=
  match x, y with
  | F3_0, F3_0 => F3_0 | F3_0, F3_1 => F3_0 | F3_0, F3_2 => F3_0
  | F3_1, F3_0 => F3_2 | F3_1, F3_1 => F3_1 | F3_1, F3_2 => F3_2
  | F3_2, F3_0 => F3_1 | F3_2, F3_1 => F3_2 | F3_2, F3_2 => F3_1
  end.

#[local] Instance refa186_inst : Magma Fin3 := {| magma_op := refa186_op |}.

Lemma refa186_sat1645 : @Equation1645 Fin3 refa186_inst.
Proof. unfold Equation1645, magma_op, refa186_inst, refa186_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa186_sat2041 : @Equation2041 Fin3 refa186_inst.
Proof. unfold Equation2041, magma_op, refa186_inst, refa186_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa186_sat2241 : @Equation2241 Fin3 refa186_inst.
Proof. unfold Equation2241, magma_op, refa186_inst, refa186_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa186_sat2447 : @Equation2447 Fin3 refa186_inst.
Proof. unfold Equation2447, magma_op, refa186_inst, refa186_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa186_sat2485 : @Equation2485 Fin3 refa186_inst.
Proof. unfold Equation2485, magma_op, refa186_inst, refa186_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa186_sat2647 : @Equation2647 Fin3 refa186_inst.
Proof. unfold Equation2647, magma_op, refa186_inst, refa186_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa186_sat2850 : @Equation2850 Fin3 refa186_inst.
Proof. unfold Equation2850, magma_op, refa186_inst, refa186_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa186_sat2855 : @Equation2855 Fin3 refa186_inst.
Proof. unfold Equation2855, magma_op, refa186_inst, refa186_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa186_sat4143 : @Equation4143 Fin3 refa186_inst.
Proof. unfold Equation4143, magma_op, refa186_inst, refa186_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa186_not1432 : ~ @Equation1432 Fin3 refa186_inst.
Proof. unfold Equation1432. intro H. specialize (H F3_1 F3_0). unfold magma_op, refa186_inst, refa186_op in H. discriminate H. Qed.

Lemma refa186_not1434 : ~ @Equation1434 Fin3 refa186_inst.
Proof. unfold Equation1434. intro H. specialize (H F3_1 F3_0). unfold magma_op, refa186_inst, refa186_op in H. discriminate H. Qed.

Lemma refa186_not1635 : ~ @Equation1635 Fin3 refa186_inst.
Proof. unfold Equation1635. intro H. specialize (H F3_1 F3_0). unfold magma_op, refa186_inst, refa186_op in H. discriminate H. Qed.

Lemma refa186_not1637 : ~ @Equation1637 Fin3 refa186_inst.
Proof. unfold Equation1637. intro H. specialize (H F3_1 F3_0). unfold magma_op, refa186_inst, refa186_op in H. discriminate H. Qed.

Lemma refa186_not2038 : ~ @Equation2038 Fin3 refa186_inst.
Proof. unfold Equation2038. intro H. specialize (H F3_1 F3_0). unfold magma_op, refa186_inst, refa186_op in H. discriminate H. Qed.

Lemma refa186_not2043 : ~ @Equation2043 Fin3 refa186_inst.
Proof. unfold Equation2043. intro H. specialize (H F3_2 F3_0). unfold magma_op, refa186_inst, refa186_op in H. discriminate H. Qed.

Lemma refa186_not2459 : ~ @Equation2459 Fin3 refa186_inst.
Proof. unfold Equation2459. intro H. specialize (H F3_1 F3_0). unfold magma_op, refa186_inst, refa186_op in H. discriminate H. Qed.

Lemma refa186_not2466 : ~ @Equation2466 Fin3 refa186_inst.
Proof. unfold Equation2466. intro H. specialize (H F3_1 F3_0). unfold magma_op, refa186_inst, refa186_op in H. discriminate H. Qed.

Lemma refa186_not2652 : ~ @Equation2652 Fin3 refa186_inst.
Proof. unfold Equation2652. intro H. specialize (H F3_1 F3_0). unfold magma_op, refa186_inst, refa186_op in H. discriminate H. Qed.

Lemma refa186_not2865 : ~ @Equation2865 Fin3 refa186_inst.
Proof. unfold Equation2865. intro H. specialize (H F3_2 F3_0). unfold magma_op, refa186_inst, refa186_op in H. discriminate H. Qed.

Lemma refa186_not2872 : ~ @Equation2872 Fin3 refa186_inst.
Proof. unfold Equation2872. intro H. specialize (H F3_1 F3_0). unfold magma_op, refa186_inst, refa186_op in H. discriminate H. Qed.

Lemma refa186_not3259 : ~ @Equation3259 Fin3 refa186_inst.
Proof. unfold Equation3259. intro H. specialize (H F3_1 F3_0). unfold magma_op, refa186_inst, refa186_op in H. discriminate H. Qed.

Lemma refa186_not3261 : ~ @Equation3261 Fin3 refa186_inst.
Proof. unfold Equation3261. intro H. specialize (H F3_1 F3_0). unfold magma_op, refa186_inst, refa186_op in H. discriminate H. Qed.

Lemma refa186_not3308 : ~ @Equation3308 Fin3 refa186_inst.
Proof. unfold Equation3308. intro H. specialize (H F3_2 F3_0). unfold magma_op, refa186_inst, refa186_op in H. discriminate H. Qed.

Lemma refa186_not3462 : ~ @Equation3462 Fin3 refa186_inst.
Proof. unfold Equation3462. intro H. specialize (H F3_1 F3_0). unfold magma_op, refa186_inst, refa186_op in H. discriminate H. Qed.

Lemma refa186_not4270 : ~ @Equation4270 Fin3 refa186_inst.
Proof. unfold Equation4270. intro H. specialize (H F3_1 F3_0). unfold magma_op, refa186_inst, refa186_op in H. discriminate H. Qed.

Lemma refa186_not4283 : ~ @Equation4283 Fin3 refa186_inst.
Proof. unfold Equation4283. intro H. specialize (H F3_2 F3_0). unfold magma_op, refa186_inst, refa186_op in H. discriminate H. Qed.

(** ---- refa187 (Fin3) ---- *)

Definition refa187_op (x y : Fin3) : Fin3 :=
  match x, y with
  | F3_0, F3_0 => F3_0 | F3_0, F3_1 => F3_0 | F3_0, F3_2 => F3_1
  | F3_1, F3_0 => F3_0 | F3_1, F3_1 => F3_0 | F3_1, F3_2 => F3_1
  | F3_2, F3_0 => F3_2 | F3_2, F3_1 => F3_1 | F3_2, F3_2 => F3_1
  end.

#[local] Instance refa187_inst : Magma Fin3 := {| magma_op := refa187_op |}.

Lemma refa187_sat4423 : @Equation4423 Fin3 refa187_inst.
Proof. unfold Equation4423, magma_op, refa187_inst, refa187_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa187_not4270 : ~ @Equation4270 Fin3 refa187_inst.
Proof. unfold Equation4270. intro H. specialize (H F3_2 F3_0). unfold magma_op, refa187_inst, refa187_op in H. discriminate H. Qed.

Lemma refa187_not4272 : ~ @Equation4272 Fin3 refa187_inst.
Proof. unfold Equation4272. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa187_inst, refa187_op in H. discriminate H. Qed.

Lemma refa187_not4275 : ~ @Equation4275 Fin3 refa187_inst.
Proof. unfold Equation4275. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa187_inst, refa187_op in H. discriminate H. Qed.

Lemma refa187_not4276 : ~ @Equation4276 Fin3 refa187_inst.
Proof. unfold Equation4276. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa187_inst, refa187_op in H. discriminate H. Qed.

Lemma refa187_not4284 : ~ @Equation4284 Fin3 refa187_inst.
Proof. unfold Equation4284. intro H. specialize (H F3_2 F3_0). unfold magma_op, refa187_inst, refa187_op in H. discriminate H. Qed.

Lemma refa187_not4290 : ~ @Equation4290 Fin3 refa187_inst.
Proof. unfold Equation4290. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa187_inst, refa187_op in H. discriminate H. Qed.

Lemma refa187_not4293 : ~ @Equation4293 Fin3 refa187_inst.
Proof. unfold Equation4293. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa187_inst, refa187_op in H. discriminate H. Qed.

Lemma refa187_not4343 : ~ @Equation4343 Fin3 refa187_inst.
Proof. unfold Equation4343. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa187_inst, refa187_op in H. discriminate H. Qed.

Lemma refa187_not4358 : ~ @Equation4358 Fin3 refa187_inst.
Proof. unfold Equation4358. intro H. specialize (H F3_0 F3_0 F3_2). unfold magma_op, refa187_inst, refa187_op in H. discriminate H. Qed.

Lemma refa187_not4396 : ~ @Equation4396 Fin3 refa187_inst.
Proof. unfold Equation4396. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa187_inst, refa187_op in H. discriminate H. Qed.

Lemma refa187_not4406 : ~ @Equation4406 Fin3 refa187_inst.
Proof. unfold Equation4406. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa187_inst, refa187_op in H. discriminate H. Qed.

Lemma refa187_not4435 : ~ @Equation4435 Fin3 refa187_inst.
Proof. unfold Equation4435. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa187_inst, refa187_op in H. discriminate H. Qed.

Lemma refa187_not4445 : ~ @Equation4445 Fin3 refa187_inst.
Proof. unfold Equation4445. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa187_inst, refa187_op in H. discriminate H. Qed.

Lemma refa187_not4470 : ~ @Equation4470 Fin3 refa187_inst.
Proof. unfold Equation4470. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa187_inst, refa187_op in H. discriminate H. Qed.

Lemma refa187_not4472 : ~ @Equation4472 Fin3 refa187_inst.
Proof. unfold Equation4472. intro H. specialize (H F3_2 F3_0). unfold magma_op, refa187_inst, refa187_op in H. discriminate H. Qed.

Lemma refa187_not4480 : ~ @Equation4480 Fin3 refa187_inst.
Proof. unfold Equation4480. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa187_inst, refa187_op in H. discriminate H. Qed.

Lemma refa187_not4482 : ~ @Equation4482 Fin3 refa187_inst.
Proof. unfold Equation4482. intro H. specialize (H F3_2 F3_0). unfold magma_op, refa187_inst, refa187_op in H. discriminate H. Qed.

Lemma refa187_not4583 : ~ @Equation4583 Fin3 refa187_inst.
Proof. unfold Equation4583. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa187_inst, refa187_op in H. discriminate H. Qed.

Lemma refa187_not4591 : ~ @Equation4591 Fin3 refa187_inst.
Proof. unfold Equation4591. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa187_inst, refa187_op in H. discriminate H. Qed.

Lemma refa187_not4598 : ~ @Equation4598 Fin3 refa187_inst.
Proof. unfold Equation4598. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa187_inst, refa187_op in H. discriminate H. Qed.

Lemma refa187_not4608 : ~ @Equation4608 Fin3 refa187_inst.
Proof. unfold Equation4608. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa187_inst, refa187_op in H. discriminate H. Qed.

Lemma refa187_not4636 : ~ @Equation4636 Fin3 refa187_inst.
Proof. unfold Equation4636. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa187_inst, refa187_op in H. discriminate H. Qed.

Lemma refa187_not4647 : ~ @Equation4647 Fin3 refa187_inst.
Proof. unfold Equation4647. intro H. specialize (H F3_0 F3_0 F3_2). unfold magma_op, refa187_inst, refa187_op in H. discriminate H. Qed.

(** ---- refa188 (Fin3) ---- *)

Definition refa188_op (x y : Fin3) : Fin3 :=
  match x, y with
  | F3_0, F3_0 => F3_1 | F3_0, F3_1 => F3_0 | F3_0, F3_2 => F3_1
  | F3_1, F3_0 => F3_0 | F3_1, F3_1 => F3_2 | F3_1, F3_2 => F3_1
  | F3_2, F3_0 => F3_1 | F3_2, F3_1 => F3_0 | F3_2, F3_2 => F3_1
  end.

#[local] Instance refa188_inst : Magma Fin3 := {| magma_op := refa188_op |}.

Lemma refa188_sat1684 : @Equation1684 Fin3 refa188_inst.
Proof. unfold Equation1684, magma_op, refa188_inst, refa188_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa188_sat1694 : @Equation1694 Fin3 refa188_inst.
Proof. unfold Equation1694, magma_op, refa188_inst, refa188_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa188_sat2090 : @Equation2090 Fin3 refa188_inst.
Proof. unfold Equation2090, magma_op, refa188_inst, refa188_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa188_sat3877 : @Equation3877 Fin3 refa188_inst.
Proof. unfold Equation3877, magma_op, refa188_inst, refa188_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa188_not1647 : ~ @Equation1647 Fin3 refa188_inst.
Proof. unfold Equation1647. intro H. specialize (H F3_2 F3_1). unfold magma_op, refa188_inst, refa188_op in H. discriminate H. Qed.

Lemma refa188_not1654 : ~ @Equation1654 Fin3 refa188_inst.
Proof. unfold Equation1654. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa188_inst, refa188_op in H. discriminate H. Qed.

Lemma refa188_not1657 : ~ @Equation1657 Fin3 refa188_inst.
Proof. unfold Equation1657. intro H. specialize (H F3_2 F3_1). unfold magma_op, refa188_inst, refa188_op in H. discriminate H. Qed.

Lemma refa188_not1832 : ~ @Equation1832 Fin3 refa188_inst.
Proof. unfold Equation1832. intro H. specialize (H F3_2). unfold magma_op, refa188_inst, refa188_op in H. discriminate H. Qed.

Lemma refa188_not3880 : ~ @Equation3880 Fin3 refa188_inst.
Proof. unfold Equation3880. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa188_inst, refa188_op in H. discriminate H. Qed.

Lemma refa188_not4065 : ~ @Equation4065 Fin3 refa188_inst.
Proof. unfold Equation4065. intro H. specialize (H F3_1). unfold magma_op, refa188_inst, refa188_op in H. discriminate H. Qed.

Lemma refa188_not4606 : ~ @Equation4606 Fin3 refa188_inst.
Proof. unfold Equation4606. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa188_inst, refa188_op in H. discriminate H. Qed.

Lemma refa188_not4635 : ~ @Equation4635 Fin3 refa188_inst.
Proof. unfold Equation4635. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa188_inst, refa188_op in H. discriminate H. Qed.
