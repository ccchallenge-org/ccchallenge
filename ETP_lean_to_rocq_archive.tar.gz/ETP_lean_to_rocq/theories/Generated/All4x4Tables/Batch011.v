(** * All4x4 counterexamples — batch 11
    Auto-generated from Lean4 All4x4 files. *)

From Stdlib Require Import Utf8.

From ETP Require Import Magma.
From ETP Require Import FinMagma.
From ETP.Equations Require Import All.

Open Scope magma_scope.

(** ---- refa55 (Fin3) ---- *)

Definition refa55_op (x y : Fin3) : Fin3 :=
  match x, y with
  | F3_0, F3_0 => F3_0 | F3_0, F3_1 => F3_0 | F3_0, F3_2 => F3_1
  | F3_1, F3_0 => F3_1 | F3_1, F3_1 => F3_1 | F3_1, F3_2 => F3_2
  | F3_2, F3_0 => F3_1 | F3_2, F3_1 => F3_1 | F3_2, F3_2 => F3_2
  end.

#[local] Instance refa55_inst : Magma Fin3 := {| magma_op := refa55_op |}.

Lemma refa55_sat3 : @Equation3 Fin3 refa55_inst.
Proof. unfold Equation3, magma_op, refa55_inst, refa55_op. intros x. destruct x; reflexivity. Qed.

Lemma refa55_sat616 : @Equation616 Fin3 refa55_inst.
Proof. unfold Equation616, magma_op, refa55_inst, refa55_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa55_sat619 : @Equation619 Fin3 refa55_inst.
Proof. unfold Equation619, magma_op, refa55_inst, refa55_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa55_sat822 : @Equation822 Fin3 refa55_inst.
Proof. unfold Equation822, magma_op, refa55_inst, refa55_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa55_sat832 : @Equation832 Fin3 refa55_inst.
Proof. unfold Equation832, magma_op, refa55_inst, refa55_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa55_sat1035 : @Equation1035 Fin3 refa55_inst.
Proof. unfold Equation1035, magma_op, refa55_inst, refa55_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa55_sat1234 : @Equation1234 Fin3 refa55_inst.
Proof. unfold Equation1234, magma_op, refa55_inst, refa55_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa55_sat1244 : @Equation1244 Fin3 refa55_inst.
Proof. unfold Equation1244, magma_op, refa55_inst, refa55_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa55_sat2259 : @Equation2259 Fin3 refa55_inst.
Proof. unfold Equation2259, magma_op, refa55_inst, refa55_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa55_sat2273 : @Equation2273 Fin3 refa55_inst.
Proof. unfold Equation2273, magma_op, refa55_inst, refa55_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa55_sat3525 : @Equation3525 Fin3 refa55_inst.
Proof. unfold Equation3525, magma_op, refa55_inst, refa55_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa55_sat3533 : @Equation3533 Fin3 refa55_inst.
Proof. unfold Equation3533, magma_op, refa55_inst, refa55_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa55_sat3925 : @Equation3925 Fin3 refa55_inst.
Proof. unfold Equation3925, magma_op, refa55_inst, refa55_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa55_not55 : ~ @Equation55 Fin3 refa55_inst.
Proof. unfold Equation55. intro H. specialize (H F3_2 F3_0). unfold magma_op, refa55_inst, refa55_op in H. discriminate H. Qed.

Lemma refa55_not107 : ~ @Equation107 Fin3 refa55_inst.
Proof. unfold Equation107. intro H. specialize (H F3_2 F3_0). unfold magma_op, refa55_inst, refa55_op in H. discriminate H. Qed.

Lemma refa55_not211 : ~ @Equation211 Fin3 refa55_inst.
Proof. unfold Equation211. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa55_inst, refa55_op in H. discriminate H. Qed.

Lemma refa55_not413 : ~ @Equation413 Fin3 refa55_inst.
Proof. unfold Equation413. intro H. specialize (H F3_2 F3_0). unfold magma_op, refa55_inst, refa55_op in H. discriminate H. Qed.

Lemma refa55_not615 : ~ @Equation615 Fin3 refa55_inst.
Proof. unfold Equation615. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa55_inst, refa55_op in H. discriminate H. Qed.

Lemma refa55_not620 : ~ @Equation620 Fin3 refa55_inst.
Proof. unfold Equation620. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa55_inst, refa55_op in H. discriminate H. Qed.

Lemma refa55_not622 : ~ @Equation622 Fin3 refa55_inst.
Proof. unfold Equation622. intro H. specialize (H F3_2 F3_0). unfold magma_op, refa55_inst, refa55_op in H. discriminate H. Qed.

Lemma refa55_not629 : ~ @Equation629 Fin3 refa55_inst.
Proof. unfold Equation629. intro H. specialize (H F3_2 F3_0). unfold magma_op, refa55_inst, refa55_op in H. discriminate H. Qed.

Lemma refa55_not632 : ~ @Equation632 Fin3 refa55_inst.
Proof. unfold Equation632. intro H. specialize (H F3_2 F3_0). unfold magma_op, refa55_inst, refa55_op in H. discriminate H. Qed.

Lemma refa55_not639 : ~ @Equation639 Fin3 refa55_inst.
Proof. unfold Equation639. intro H. specialize (H F3_2 F3_0). unfold magma_op, refa55_inst, refa55_op in H. discriminate H. Qed.

Lemma refa55_not642 : ~ @Equation642 Fin3 refa55_inst.
Proof. unfold Equation642. intro H. specialize (H F3_2 F3_0). unfold magma_op, refa55_inst, refa55_op in H. discriminate H. Qed.

Lemma refa55_not819 : ~ @Equation819 Fin3 refa55_inst.
Proof. unfold Equation819. intro H. specialize (H F3_2 F3_0). unfold magma_op, refa55_inst, refa55_op in H. discriminate H. Qed.

Lemma refa55_not825 : ~ @Equation825 Fin3 refa55_inst.
Proof. unfold Equation825. intro H. specialize (H F3_2 F3_0). unfold magma_op, refa55_inst, refa55_op in H. discriminate H. Qed.

Lemma refa55_not835 : ~ @Equation835 Fin3 refa55_inst.
Proof. unfold Equation835. intro H. specialize (H F3_2 F3_0). unfold magma_op, refa55_inst, refa55_op in H. discriminate H. Qed.

Lemma refa55_not842 : ~ @Equation842 Fin3 refa55_inst.
Proof. unfold Equation842. intro H. specialize (H F3_2 F3_0). unfold magma_op, refa55_inst, refa55_op in H. discriminate H. Qed.

Lemma refa55_not845 : ~ @Equation845 Fin3 refa55_inst.
Proof. unfold Equation845. intro H. specialize (H F3_2 F3_0). unfold magma_op, refa55_inst, refa55_op in H. discriminate H. Qed.

Lemma refa55_not1038 : ~ @Equation1038 Fin3 refa55_inst.
Proof. unfold Equation1038. intro H. specialize (H F3_2 F3_0). unfold magma_op, refa55_inst, refa55_op in H. discriminate H. Qed.

Lemma refa55_not1045 : ~ @Equation1045 Fin3 refa55_inst.
Proof. unfold Equation1045. intro H. specialize (H F3_2 F3_0). unfold magma_op, refa55_inst, refa55_op in H. discriminate H. Qed.

Lemma refa55_not1048 : ~ @Equation1048 Fin3 refa55_inst.
Proof. unfold Equation1048. intro H. specialize (H F3_2 F3_0). unfold magma_op, refa55_inst, refa55_op in H. discriminate H. Qed.

Lemma refa55_not1251 : ~ @Equation1251 Fin3 refa55_inst.
Proof. unfold Equation1251. intro H. specialize (H F3_2 F3_0). unfold magma_op, refa55_inst, refa55_op in H. discriminate H. Qed.

Lemma refa55_not1428 : ~ @Equation1428 Fin3 refa55_inst.
Proof. unfold Equation1428. intro H. specialize (H F3_2 F3_0). unfold magma_op, refa55_inst, refa55_op in H. discriminate H. Qed.

Lemma refa55_not1431 : ~ @Equation1431 Fin3 refa55_inst.
Proof. unfold Equation1431. intro H. specialize (H F3_2 F3_0). unfold magma_op, refa55_inst, refa55_op in H. discriminate H. Qed.

Lemma refa55_not1434 : ~ @Equation1434 Fin3 refa55_inst.
Proof. unfold Equation1434. intro H. specialize (H F3_2 F3_0). unfold magma_op, refa55_inst, refa55_op in H. discriminate H. Qed.

Lemma refa55_not1441 : ~ @Equation1441 Fin3 refa55_inst.
Proof. unfold Equation1441. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa55_inst, refa55_op in H. discriminate H. Qed.

Lemma refa55_not1444 : ~ @Equation1444 Fin3 refa55_inst.
Proof. unfold Equation1444. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa55_inst, refa55_op in H. discriminate H. Qed.

Lemma refa55_not1451 : ~ @Equation1451 Fin3 refa55_inst.
Proof. unfold Equation1451. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa55_inst, refa55_op in H. discriminate H. Qed.

Lemma refa55_not1454 : ~ @Equation1454 Fin3 refa55_inst.
Proof. unfold Equation1454. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa55_inst, refa55_op in H. discriminate H. Qed.

Lemma refa55_not2266 : ~ @Equation2266 Fin3 refa55_inst.
Proof. unfold Equation2266. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa55_inst, refa55_op in H. discriminate H. Qed.

Lemma refa55_not2449 : ~ @Equation2449 Fin3 refa55_inst.
Proof. unfold Equation2449. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa55_inst, refa55_op in H. discriminate H. Qed.

Lemma refa55_not2459 : ~ @Equation2459 Fin3 refa55_inst.
Proof. unfold Equation2459. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa55_inst, refa55_op in H. discriminate H. Qed.

Lemma refa55_not2469 : ~ @Equation2469 Fin3 refa55_inst.
Proof. unfold Equation2469. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa55_inst, refa55_op in H. discriminate H. Qed.

Lemma refa55_not3255 : ~ @Equation3255 Fin3 refa55_inst.
Proof. unfold Equation3255. intro H. specialize (H F3_2 F3_0). unfold magma_op, refa55_inst, refa55_op in H. discriminate H. Qed.

Lemma refa55_not3279 : ~ @Equation3279 Fin3 refa55_inst.
Proof. unfold Equation3279. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa55_inst, refa55_op in H. discriminate H. Qed.

Lemma refa55_not3306 : ~ @Equation3306 Fin3 refa55_inst.
Proof. unfold Equation3306. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa55_inst, refa55_op in H. discriminate H. Qed.

Lemma refa55_not3308 : ~ @Equation3308 Fin3 refa55_inst.
Proof. unfold Equation3308. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa55_inst, refa55_op in H. discriminate H. Qed.

Lemma refa55_not3309 : ~ @Equation3309 Fin3 refa55_inst.
Proof. unfold Equation3309. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa55_inst, refa55_op in H. discriminate H. Qed.

Lemma refa55_not3315 : ~ @Equation3315 Fin3 refa55_inst.
Proof. unfold Equation3315. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa55_inst, refa55_op in H. discriminate H. Qed.

Lemma refa55_not3316 : ~ @Equation3316 Fin3 refa55_inst.
Proof. unfold Equation3316. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa55_inst, refa55_op in H. discriminate H. Qed.

Lemma refa55_not3318 : ~ @Equation3318 Fin3 refa55_inst.
Proof. unfold Equation3318. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa55_inst, refa55_op in H. discriminate H. Qed.

Lemma refa55_not3509 : ~ @Equation3509 Fin3 refa55_inst.
Proof. unfold Equation3509. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa55_inst, refa55_op in H. discriminate H. Qed.

Lemma refa55_not3511 : ~ @Equation3511 Fin3 refa55_inst.
Proof. unfold Equation3511. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa55_inst, refa55_op in H. discriminate H. Qed.

Lemma refa55_not3518 : ~ @Equation3518 Fin3 refa55_inst.
Proof. unfold Equation3518. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa55_inst, refa55_op in H. discriminate H. Qed.

Lemma refa55_not3521 : ~ @Equation3521 Fin3 refa55_inst.
Proof. unfold Equation3521. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa55_inst, refa55_op in H. discriminate H. Qed.

Lemma refa55_not3685 : ~ @Equation3685 Fin3 refa55_inst.
Proof. unfold Equation3685. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa55_inst, refa55_op in H. discriminate H. Qed.

Lemma refa55_not3712 : ~ @Equation3712 Fin3 refa55_inst.
Proof. unfold Equation3712. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa55_inst, refa55_op in H. discriminate H. Qed.

Lemma refa55_not3714 : ~ @Equation3714 Fin3 refa55_inst.
Proof. unfold Equation3714. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa55_inst, refa55_op in H. discriminate H. Qed.

Lemma refa55_not3721 : ~ @Equation3721 Fin3 refa55_inst.
Proof. unfold Equation3721. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa55_inst, refa55_op in H. discriminate H. Qed.

Lemma refa55_not3724 : ~ @Equation3724 Fin3 refa55_inst.
Proof. unfold Equation3724. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa55_inst, refa55_op in H. discriminate H. Qed.

Lemma refa55_not3725 : ~ @Equation3725 Fin3 refa55_inst.
Proof. unfold Equation3725. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa55_inst, refa55_op in H. discriminate H. Qed.

Lemma refa55_not3870 : ~ @Equation3870 Fin3 refa55_inst.
Proof. unfold Equation3870. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa55_inst, refa55_op in H. discriminate H. Qed.

Lemma refa55_not3881 : ~ @Equation3881 Fin3 refa55_inst.
Proof. unfold Equation3881. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa55_inst, refa55_op in H. discriminate H. Qed.

Lemma refa55_not3887 : ~ @Equation3887 Fin3 refa55_inst.
Proof. unfold Equation3887. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa55_inst, refa55_op in H. discriminate H. Qed.

Lemma refa55_not3888 : ~ @Equation3888 Fin3 refa55_inst.
Proof. unfold Equation3888. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa55_inst, refa55_op in H. discriminate H. Qed.

Lemma refa55_not3917 : ~ @Equation3917 Fin3 refa55_inst.
Proof. unfold Equation3917. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa55_inst, refa55_op in H. discriminate H. Qed.

Lemma refa55_not3924 : ~ @Equation3924 Fin3 refa55_inst.
Proof. unfold Equation3924. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa55_inst, refa55_op in H. discriminate H. Qed.

Lemma refa55_not3927 : ~ @Equation3927 Fin3 refa55_inst.
Proof. unfold Equation3927. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa55_inst, refa55_op in H. discriminate H. Qed.

Lemma refa55_not3928 : ~ @Equation3928 Fin3 refa55_inst.
Proof. unfold Equation3928. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa55_inst, refa55_op in H. discriminate H. Qed.

Lemma refa55_not4067 : ~ @Equation4067 Fin3 refa55_inst.
Proof. unfold Equation4067. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa55_inst, refa55_op in H. discriminate H. Qed.

Lemma refa55_not4070 : ~ @Equation4070 Fin3 refa55_inst.
Proof. unfold Equation4070. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa55_inst, refa55_op in H. discriminate H. Qed.

Lemma refa55_not4073 : ~ @Equation4073 Fin3 refa55_inst.
Proof. unfold Equation4073. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa55_inst, refa55_op in H. discriminate H. Qed.

Lemma refa55_not4083 : ~ @Equation4083 Fin3 refa55_inst.
Proof. unfold Equation4083. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa55_inst, refa55_op in H. discriminate H. Qed.

Lemma refa55_not4084 : ~ @Equation4084 Fin3 refa55_inst.
Proof. unfold Equation4084. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa55_inst, refa55_op in H. discriminate H. Qed.

Lemma refa55_not4090 : ~ @Equation4090 Fin3 refa55_inst.
Proof. unfold Equation4090. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa55_inst, refa55_op in H. discriminate H. Qed.

Lemma refa55_not4091 : ~ @Equation4091 Fin3 refa55_inst.
Proof. unfold Equation4091. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa55_inst, refa55_op in H. discriminate H. Qed.

Lemma refa55_not4093 : ~ @Equation4093 Fin3 refa55_inst.
Proof. unfold Equation4093. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa55_inst, refa55_op in H. discriminate H. Qed.

Lemma refa55_not4120 : ~ @Equation4120 Fin3 refa55_inst.
Proof. unfold Equation4120. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa55_inst, refa55_op in H. discriminate H. Qed.

Lemma refa55_not4121 : ~ @Equation4121 Fin3 refa55_inst.
Proof. unfold Equation4121. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa55_inst, refa55_op in H. discriminate H. Qed.

Lemma refa55_not4127 : ~ @Equation4127 Fin3 refa55_inst.
Proof. unfold Equation4127. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa55_inst, refa55_op in H. discriminate H. Qed.

Lemma refa55_not4128 : ~ @Equation4128 Fin3 refa55_inst.
Proof. unfold Equation4128. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa55_inst, refa55_op in H. discriminate H. Qed.

Lemma refa55_not4130 : ~ @Equation4130 Fin3 refa55_inst.
Proof. unfold Equation4130. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa55_inst, refa55_op in H. discriminate H. Qed.

Lemma refa55_not4131 : ~ @Equation4131 Fin3 refa55_inst.
Proof. unfold Equation4131. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa55_inst, refa55_op in H. discriminate H. Qed.

Lemma refa55_not4269 : ~ @Equation4269 Fin3 refa55_inst.
Proof. unfold Equation4269. intro H. specialize (H F3_2 F3_0). unfold magma_op, refa55_inst, refa55_op in H. discriminate H. Qed.

Lemma refa55_not4283 : ~ @Equation4283 Fin3 refa55_inst.
Proof. unfold Equation4283. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa55_inst, refa55_op in H. discriminate H. Qed.

Lemma refa55_not4284 : ~ @Equation4284 Fin3 refa55_inst.
Proof. unfold Equation4284. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa55_inst, refa55_op in H. discriminate H. Qed.

Lemma refa55_not4293 : ~ @Equation4293 Fin3 refa55_inst.
Proof. unfold Equation4293. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa55_inst, refa55_op in H. discriminate H. Qed.

Lemma refa55_not4314 : ~ @Equation4314 Fin3 refa55_inst.
Proof. unfold Equation4314. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa55_inst, refa55_op in H. discriminate H. Qed.

Lemma refa55_not4396 : ~ @Equation4396 Fin3 refa55_inst.
Proof. unfold Equation4396. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa55_inst, refa55_op in H. discriminate H. Qed.

Lemma refa55_not4398 : ~ @Equation4398 Fin3 refa55_inst.
Proof. unfold Equation4398. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa55_inst, refa55_op in H. discriminate H. Qed.

Lemma refa55_not4399 : ~ @Equation4399 Fin3 refa55_inst.
Proof. unfold Equation4399. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa55_inst, refa55_op in H. discriminate H. Qed.

Lemma refa55_not4433 : ~ @Equation4433 Fin3 refa55_inst.
Proof. unfold Equation4433. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa55_inst, refa55_op in H. discriminate H. Qed.

Lemma refa55_not4435 : ~ @Equation4435 Fin3 refa55_inst.
Proof. unfold Equation4435. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa55_inst, refa55_op in H. discriminate H. Qed.

Lemma refa55_not4436 : ~ @Equation4436 Fin3 refa55_inst.
Proof. unfold Equation4436. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa55_inst, refa55_op in H. discriminate H. Qed.

Lemma refa55_not4472 : ~ @Equation4472 Fin3 refa55_inst.
Proof. unfold Equation4472. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa55_inst, refa55_op in H. discriminate H. Qed.

Lemma refa55_not4473 : ~ @Equation4473 Fin3 refa55_inst.
Proof. unfold Equation4473. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa55_inst, refa55_op in H. discriminate H. Qed.

Lemma refa55_not4591 : ~ @Equation4591 Fin3 refa55_inst.
Proof. unfold Equation4591. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa55_inst, refa55_op in H. discriminate H. Qed.

Lemma refa55_not4598 : ~ @Equation4598 Fin3 refa55_inst.
Proof. unfold Equation4598. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa55_inst, refa55_op in H. discriminate H. Qed.

Lemma refa55_not4599 : ~ @Equation4599 Fin3 refa55_inst.
Proof. unfold Equation4599. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa55_inst, refa55_op in H. discriminate H. Qed.

Lemma refa55_not4606 : ~ @Equation4606 Fin3 refa55_inst.
Proof. unfold Equation4606. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa55_inst, refa55_op in H. discriminate H. Qed.

Lemma refa55_not4608 : ~ @Equation4608 Fin3 refa55_inst.
Proof. unfold Equation4608. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa55_inst, refa55_op in H. discriminate H. Qed.

Lemma refa55_not4622 : ~ @Equation4622 Fin3 refa55_inst.
Proof. unfold Equation4622. intro H. specialize (H F3_0 F3_0 F3_1). unfold magma_op, refa55_inst, refa55_op in H. discriminate H. Qed.

Lemma refa55_not4629 : ~ @Equation4629 Fin3 refa55_inst.
Proof. unfold Equation4629. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa55_inst, refa55_op in H. discriminate H. Qed.

Lemma refa55_not4631 : ~ @Equation4631 Fin3 refa55_inst.
Proof. unfold Equation4631. intro H. specialize (H F3_0 F3_0 F3_2). unfold magma_op, refa55_inst, refa55_op in H. discriminate H. Qed.

Lemma refa55_not4636 : ~ @Equation4636 Fin3 refa55_inst.
Proof. unfold Equation4636. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa55_inst, refa55_op in H. discriminate H. Qed.

(** ---- refa550 (Fin4) ---- *)

Definition refa550_op (x y : Fin4) : Fin4 :=
  match x, y with
  | F4_0, F4_0 => F4_2 | F4_0, F4_1 => F4_0 | F4_0, F4_2 => F4_1 | F4_0, F4_3 => F4_3
  | F4_1, F4_0 => F4_3 | F4_1, F4_1 => F4_1 | F4_1, F4_2 => F4_0 | F4_1, F4_3 => F4_2
  | F4_2, F4_0 => F4_1 | F4_2, F4_1 => F4_3 | F4_2, F4_2 => F4_2 | F4_2, F4_3 => F4_0
  | F4_3, F4_0 => F4_0 | F4_3, F4_1 => F4_2 | F4_3, F4_2 => F4_3 | F4_3, F4_3 => F4_1
  end.

#[local] Instance refa550_inst : Magma Fin4 := {| magma_op := refa550_op |}.

Lemma refa550_sat1876 : @Equation1876 Fin4 refa550_inst.
Proof. unfold Equation1876, magma_op, refa550_inst, refa550_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa550_sat2939 : @Equation2939 Fin4 refa550_inst.
Proof. unfold Equation2939, magma_op, refa550_inst, refa550_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa550_not159 : ~ @Equation159 Fin4 refa550_inst.
Proof. unfold Equation159. intro H. specialize (H F4_0 F4_0). unfold magma_op, refa550_inst, refa550_op in H. discriminate H. Qed.

Lemma refa550_not231 : ~ @Equation231 Fin4 refa550_inst.
Proof. unfold Equation231. intro H. specialize (H F4_0 F4_0). unfold magma_op, refa550_inst, refa550_op in H. discriminate H. Qed.

Lemma refa550_not411 : ~ @Equation411 Fin4 refa550_inst.
Proof. unfold Equation411. intro H. specialize (H F4_0). unfold magma_op, refa550_inst, refa550_op in H. discriminate H. Qed.

Lemma refa550_not1451 : ~ @Equation1451 Fin4 refa550_inst.
Proof. unfold Equation1451. intro H. specialize (H F4_0 F4_0). unfold magma_op, refa550_inst, refa550_op in H. discriminate H. Qed.

Lemma refa550_not1629 : ~ @Equation1629 Fin4 refa550_inst.
Proof. unfold Equation1629. intro H. specialize (H F4_0). unfold magma_op, refa550_inst, refa550_op in H. discriminate H. Qed.

Lemma refa550_not1857 : ~ @Equation1857 Fin4 refa550_inst.
Proof. unfold Equation1857. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa550_inst, refa550_op in H. discriminate H. Qed.

Lemma refa550_not2043 : ~ @Equation2043 Fin4 refa550_inst.
Proof. unfold Equation2043. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa550_inst, refa550_op in H. discriminate H. Qed.

Lemma refa550_not2070 : ~ @Equation2070 Fin4 refa550_inst.
Proof. unfold Equation2070. intro H. specialize (H F4_0 F4_0 F4_1). unfold magma_op, refa550_inst, refa550_op in H. discriminate H. Qed.

Lemma refa550_not2087 : ~ @Equation2087 Fin4 refa550_inst.
Proof. unfold Equation2087. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa550_inst, refa550_op in H. discriminate H. Qed.

Lemma refa550_not2124 : ~ @Equation2124 Fin4 refa550_inst.
Proof. unfold Equation2124. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa550_inst, refa550_op in H. discriminate H. Qed.

Lemma refa550_not2127 : ~ @Equation2127 Fin4 refa550_inst.
Proof. unfold Equation2127. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa550_inst, refa550_op in H. discriminate H. Qed.

Lemma refa550_not2134 : ~ @Equation2134 Fin4 refa550_inst.
Proof. unfold Equation2134. intro H. specialize (H F4_0 F4_2). unfold magma_op, refa550_inst, refa550_op in H. discriminate H. Qed.

Lemma refa550_not2243 : ~ @Equation2243 Fin4 refa550_inst.
Proof. unfold Equation2243. intro H. specialize (H F4_0 F4_0). unfold magma_op, refa550_inst, refa550_op in H. discriminate H. Qed.

Lemma refa550_not2246 : ~ @Equation2246 Fin4 refa550_inst.
Proof. unfold Equation2246. intro H. specialize (H F4_0 F4_0). unfold magma_op, refa550_inst, refa550_op in H. discriminate H. Qed.

Lemma refa550_not2253 : ~ @Equation2253 Fin4 refa550_inst.
Proof. unfold Equation2253. intro H. specialize (H F4_0 F4_0). unfold magma_op, refa550_inst, refa550_op in H. discriminate H. Qed.

Lemma refa550_not2266 : ~ @Equation2266 Fin4 refa550_inst.
Proof. unfold Equation2266. intro H. specialize (H F4_0 F4_0). unfold magma_op, refa550_inst, refa550_op in H. discriminate H. Qed.

Lemma refa550_not2290 : ~ @Equation2290 Fin4 refa550_inst.
Proof. unfold Equation2290. intro H. specialize (H F4_0 F4_0). unfold magma_op, refa550_inst, refa550_op in H. discriminate H. Qed.

Lemma refa550_not2300 : ~ @Equation2300 Fin4 refa550_inst.
Proof. unfold Equation2300. intro H. specialize (H F4_0 F4_0). unfold magma_op, refa550_inst, refa550_op in H. discriminate H. Qed.

Lemma refa550_not2330 : ~ @Equation2330 Fin4 refa550_inst.
Proof. unfold Equation2330. intro H. specialize (H F4_0 F4_0). unfold magma_op, refa550_inst, refa550_op in H. discriminate H. Qed.

Lemma refa550_not2340 : ~ @Equation2340 Fin4 refa550_inst.
Proof. unfold Equation2340. intro H. specialize (H F4_0 F4_0). unfold magma_op, refa550_inst, refa550_op in H. discriminate H. Qed.

Lemma refa550_not2441 : ~ @Equation2441 Fin4 refa550_inst.
Proof. unfold Equation2441. intro H. specialize (H F4_0). unfold magma_op, refa550_inst, refa550_op in H. discriminate H. Qed.

Lemma refa550_not2644 : ~ @Equation2644 Fin4 refa550_inst.
Proof. unfold Equation2644. intro H. specialize (H F4_0). unfold magma_op, refa550_inst, refa550_op in H. discriminate H. Qed.

Lemma refa550_not2849 : ~ @Equation2849 Fin4 refa550_inst.
Proof. unfold Equation2849. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa550_inst, refa550_op in H. discriminate H. Qed.

Lemma refa550_not2852 : ~ @Equation2852 Fin4 refa550_inst.
Proof. unfold Equation2852. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa550_inst, refa550_op in H. discriminate H. Qed.

Lemma refa550_not2855 : ~ @Equation2855 Fin4 refa550_inst.
Proof. unfold Equation2855. intro H. specialize (H F4_0 F4_2). unfold magma_op, refa550_inst, refa550_op in H. discriminate H. Qed.

Lemma refa550_not2862 : ~ @Equation2862 Fin4 refa550_inst.
Proof. unfold Equation2862. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa550_inst, refa550_op in H. discriminate H. Qed.

Lemma refa550_not2865 : ~ @Equation2865 Fin4 refa550_inst.
Proof. unfold Equation2865. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa550_inst, refa550_op in H. discriminate H. Qed.

Lemma refa550_not2872 : ~ @Equation2872 Fin4 refa550_inst.
Proof. unfold Equation2872. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa550_inst, refa550_op in H. discriminate H. Qed.

Lemma refa550_not2899 : ~ @Equation2899 Fin4 refa550_inst.
Proof. unfold Equation2899. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa550_inst, refa550_op in H. discriminate H. Qed.

Lemma refa550_not2909 : ~ @Equation2909 Fin4 refa550_inst.
Proof. unfold Equation2909. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa550_inst, refa550_op in H. discriminate H. Qed.

Lemma refa550_not2946 : ~ @Equation2946 Fin4 refa550_inst.
Proof. unfold Equation2946. intro H. specialize (H F4_0 F4_2). unfold magma_op, refa550_inst, refa550_op in H. discriminate H. Qed.

Lemma refa550_not2949 : ~ @Equation2949 Fin4 refa550_inst.
Proof. unfold Equation2949. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa550_inst, refa550_op in H. discriminate H. Qed.

Lemma refa550_not3052 : ~ @Equation3052 Fin4 refa550_inst.
Proof. unfold Equation3052. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa550_inst, refa550_op in H. discriminate H. Qed.

Lemma refa550_not3055 : ~ @Equation3055 Fin4 refa550_inst.
Proof. unfold Equation3055. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa550_inst, refa550_op in H. discriminate H. Qed.

Lemma refa550_not3065 : ~ @Equation3065 Fin4 refa550_inst.
Proof. unfold Equation3065. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa550_inst, refa550_op in H. discriminate H. Qed.

Lemma refa550_not3139 : ~ @Equation3139 Fin4 refa550_inst.
Proof. unfold Equation3139. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa550_inst, refa550_op in H. discriminate H. Qed.

Lemma refa550_not3149 : ~ @Equation3149 Fin4 refa550_inst.
Proof. unfold Equation3149. intro H. specialize (H F4_0 F4_2). unfold magma_op, refa550_inst, refa550_op in H. discriminate H. Qed.

Lemma refa550_not3152 : ~ @Equation3152 Fin4 refa550_inst.
Proof. unfold Equation3152. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa550_inst, refa550_op in H. discriminate H. Qed.

Lemma refa550_not3253 : ~ @Equation3253 Fin4 refa550_inst.
Proof. unfold Equation3253. intro H. specialize (H F4_0). unfold magma_op, refa550_inst, refa550_op in H. discriminate H. Qed.

Lemma refa550_not3458 : ~ @Equation3458 Fin4 refa550_inst.
Proof. unfold Equation3458. intro H. specialize (H F4_0 F4_0). unfold magma_op, refa550_inst, refa550_op in H. discriminate H. Qed.

Lemma refa550_not3461 : ~ @Equation3461 Fin4 refa550_inst.
Proof. unfold Equation3461. intro H. specialize (H F4_0 F4_0). unfold magma_op, refa550_inst, refa550_op in H. discriminate H. Qed.

Lemma refa550_not3464 : ~ @Equation3464 Fin4 refa550_inst.
Proof. unfold Equation3464. intro H. specialize (H F4_0 F4_0). unfold magma_op, refa550_inst, refa550_op in H. discriminate H. Qed.

Lemma refa550_not3481 : ~ @Equation3481 Fin4 refa550_inst.
Proof. unfold Equation3481. intro H. specialize (H F4_0 F4_0). unfold magma_op, refa550_inst, refa550_op in H. discriminate H. Qed.

Lemma refa550_not3509 : ~ @Equation3509 Fin4 refa550_inst.
Proof. unfold Equation3509. intro H. specialize (H F4_0 F4_0). unfold magma_op, refa550_inst, refa550_op in H. discriminate H. Qed.

Lemma refa550_not3512 : ~ @Equation3512 Fin4 refa550_inst.
Proof. unfold Equation3512. intro H. specialize (H F4_0 F4_0). unfold magma_op, refa550_inst, refa550_op in H. discriminate H. Qed.

Lemma refa550_not3519 : ~ @Equation3519 Fin4 refa550_inst.
Proof. unfold Equation3519. intro H. specialize (H F4_0 F4_0). unfold magma_op, refa550_inst, refa550_op in H. discriminate H. Qed.

Lemma refa550_not3546 : ~ @Equation3546 Fin4 refa550_inst.
Proof. unfold Equation3546. intro H. specialize (H F4_0 F4_0). unfold magma_op, refa550_inst, refa550_op in H. discriminate H. Qed.

Lemma refa550_not3661 : ~ @Equation3661 Fin4 refa550_inst.
Proof. unfold Equation3661. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa550_inst, refa550_op in H. discriminate H. Qed.

Lemma refa550_not3664 : ~ @Equation3664 Fin4 refa550_inst.
Proof. unfold Equation3664. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa550_inst, refa550_op in H. discriminate H. Qed.

Lemma refa550_not3667 : ~ @Equation3667 Fin4 refa550_inst.
Proof. unfold Equation3667. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa550_inst, refa550_op in H. discriminate H. Qed.

Lemma refa550_not3674 : ~ @Equation3674 Fin4 refa550_inst.
Proof. unfold Equation3674. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa550_inst, refa550_op in H. discriminate H. Qed.

Lemma refa550_not3677 : ~ @Equation3677 Fin4 refa550_inst.
Proof. unfold Equation3677. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa550_inst, refa550_op in H. discriminate H. Qed.

Lemma refa550_not3684 : ~ @Equation3684 Fin4 refa550_inst.
Proof. unfold Equation3684. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa550_inst, refa550_op in H. discriminate H. Qed.

Lemma refa550_not3712 : ~ @Equation3712 Fin4 refa550_inst.
Proof. unfold Equation3712. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa550_inst, refa550_op in H. discriminate H. Qed.

Lemma refa550_not3725 : ~ @Equation3725 Fin4 refa550_inst.
Proof. unfold Equation3725. intro H. specialize (H F4_0 F4_2). unfold magma_op, refa550_inst, refa550_op in H. discriminate H. Qed.

Lemma refa550_not3752 : ~ @Equation3752 Fin4 refa550_inst.
Proof. unfold Equation3752. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa550_inst, refa550_op in H. discriminate H. Qed.

Lemma refa550_not3759 : ~ @Equation3759 Fin4 refa550_inst.
Proof. unfold Equation3759. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa550_inst, refa550_op in H. discriminate H. Qed.

Lemma refa550_not3864 : ~ @Equation3864 Fin4 refa550_inst.
Proof. unfold Equation3864. intro H. specialize (H F4_0 F4_0). unfold magma_op, refa550_inst, refa550_op in H. discriminate H. Qed.

Lemma refa550_not3867 : ~ @Equation3867 Fin4 refa550_inst.
Proof. unfold Equation3867. intro H. specialize (H F4_0 F4_0). unfold magma_op, refa550_inst, refa550_op in H. discriminate H. Qed.

Lemma refa550_not3870 : ~ @Equation3870 Fin4 refa550_inst.
Proof. unfold Equation3870. intro H. specialize (H F4_0 F4_0). unfold magma_op, refa550_inst, refa550_op in H. discriminate H. Qed.

Lemma refa550_not3877 : ~ @Equation3877 Fin4 refa550_inst.
Proof. unfold Equation3877. intro H. specialize (H F4_0 F4_0). unfold magma_op, refa550_inst, refa550_op in H. discriminate H. Qed.

Lemma refa550_not3890 : ~ @Equation3890 Fin4 refa550_inst.
Proof. unfold Equation3890. intro H. specialize (H F4_0 F4_0). unfold magma_op, refa550_inst, refa550_op in H. discriminate H. Qed.

Lemma refa550_not3918 : ~ @Equation3918 Fin4 refa550_inst.
Proof. unfold Equation3918. intro H. specialize (H F4_0 F4_0). unfold magma_op, refa550_inst, refa550_op in H. discriminate H. Qed.

Lemma refa550_not3925 : ~ @Equation3925 Fin4 refa550_inst.
Proof. unfold Equation3925. intro H. specialize (H F4_0 F4_0). unfold magma_op, refa550_inst, refa550_op in H. discriminate H. Qed.

Lemma refa550_not3928 : ~ @Equation3928 Fin4 refa550_inst.
Proof. unfold Equation3928. intro H. specialize (H F4_0 F4_0). unfold magma_op, refa550_inst, refa550_op in H. discriminate H. Qed.

Lemma refa550_not3952 : ~ @Equation3952 Fin4 refa550_inst.
Proof. unfold Equation3952. intro H. specialize (H F4_0 F4_0). unfold magma_op, refa550_inst, refa550_op in H. discriminate H. Qed.

Lemma refa550_not4067 : ~ @Equation4067 Fin4 refa550_inst.
Proof. unfold Equation4067. intro H. specialize (H F4_0 F4_0). unfold magma_op, refa550_inst, refa550_op in H. discriminate H. Qed.

Lemma refa550_not4070 : ~ @Equation4070 Fin4 refa550_inst.
Proof. unfold Equation4070. intro H. specialize (H F4_0 F4_0). unfold magma_op, refa550_inst, refa550_op in H. discriminate H. Qed.

Lemma refa550_not4090 : ~ @Equation4090 Fin4 refa550_inst.
Proof. unfold Equation4090. intro H. specialize (H F4_0 F4_0). unfold magma_op, refa550_inst, refa550_op in H. discriminate H. Qed.

Lemma refa550_not4093 : ~ @Equation4093 Fin4 refa550_inst.
Proof. unfold Equation4093. intro H. specialize (H F4_0 F4_0). unfold magma_op, refa550_inst, refa550_op in H. discriminate H. Qed.

Lemma refa550_not4121 : ~ @Equation4121 Fin4 refa550_inst.
Proof. unfold Equation4121. intro H. specialize (H F4_0 F4_0). unfold magma_op, refa550_inst, refa550_op in H. discriminate H. Qed.

Lemma refa550_not4128 : ~ @Equation4128 Fin4 refa550_inst.
Proof. unfold Equation4128. intro H. specialize (H F4_0 F4_0). unfold magma_op, refa550_inst, refa550_op in H. discriminate H. Qed.

Lemma refa550_not4155 : ~ @Equation4155 Fin4 refa550_inst.
Proof. unfold Equation4155. intro H. specialize (H F4_0 F4_0). unfold magma_op, refa550_inst, refa550_op in H. discriminate H. Qed.

Lemma refa550_not4165 : ~ @Equation4165 Fin4 refa550_inst.
Proof. unfold Equation4165. intro H. specialize (H F4_0 F4_0). unfold magma_op, refa550_inst, refa550_op in H. discriminate H. Qed.

Lemma refa550_not4269 : ~ @Equation4269 Fin4 refa550_inst.
Proof. unfold Equation4269. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa550_inst, refa550_op in H. discriminate H. Qed.

Lemma refa550_not4270 : ~ @Equation4270 Fin4 refa550_inst.
Proof. unfold Equation4270. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa550_inst, refa550_op in H. discriminate H. Qed.

Lemma refa550_not4272 : ~ @Equation4272 Fin4 refa550_inst.
Proof. unfold Equation4272. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa550_inst, refa550_op in H. discriminate H. Qed.

Lemma refa550_not4284 : ~ @Equation4284 Fin4 refa550_inst.
Proof. unfold Equation4284. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa550_inst, refa550_op in H. discriminate H. Qed.

Lemma refa550_not4291 : ~ @Equation4291 Fin4 refa550_inst.
Proof. unfold Equation4291. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa550_inst, refa550_op in H. discriminate H. Qed.

Lemma refa550_not4320 : ~ @Equation4320 Fin4 refa550_inst.
Proof. unfold Equation4320. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa550_inst, refa550_op in H. discriminate H. Qed.

Lemma refa550_not4396 : ~ @Equation4396 Fin4 refa550_inst.
Proof. unfold Equation4396. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa550_inst, refa550_op in H. discriminate H. Qed.

Lemma refa550_not4399 : ~ @Equation4399 Fin4 refa550_inst.
Proof. unfold Equation4399. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa550_inst, refa550_op in H. discriminate H. Qed.

Lemma refa550_not4445 : ~ @Equation4445 Fin4 refa550_inst.
Proof. unfold Equation4445. intro H. specialize (H F4_0 F4_2). unfold magma_op, refa550_inst, refa550_op in H. discriminate H. Qed.

Lemma refa550_not4473 : ~ @Equation4473 Fin4 refa550_inst.
Proof. unfold Equation4473. intro H. specialize (H F4_0 F4_2). unfold magma_op, refa550_inst, refa550_op in H. discriminate H. Qed.

Lemma refa550_not4480 : ~ @Equation4480 Fin4 refa550_inst.
Proof. unfold Equation4480. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa550_inst, refa550_op in H. discriminate H. Qed.

Lemma refa550_not4584 : ~ @Equation4584 Fin4 refa550_inst.
Proof. unfold Equation4584. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa550_inst, refa550_op in H. discriminate H. Qed.

Lemma refa550_not4587 : ~ @Equation4587 Fin4 refa550_inst.
Proof. unfold Equation4587. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa550_inst, refa550_op in H. discriminate H. Qed.

Lemma refa550_not4590 : ~ @Equation4590 Fin4 refa550_inst.
Proof. unfold Equation4590. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa550_inst, refa550_op in H. discriminate H. Qed.

Lemma refa550_not4598 : ~ @Equation4598 Fin4 refa550_inst.
Proof. unfold Equation4598. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa550_inst, refa550_op in H. discriminate H. Qed.

Lemma refa550_not4599 : ~ @Equation4599 Fin4 refa550_inst.
Proof. unfold Equation4599. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa550_inst, refa550_op in H. discriminate H. Qed.

Lemma refa550_not4606 : ~ @Equation4606 Fin4 refa550_inst.
Proof. unfold Equation4606. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa550_inst, refa550_op in H. discriminate H. Qed.

(** ---- refa551 (Fin4) ---- *)

Definition refa551_op (x y : Fin4) : Fin4 :=
  match x, y with
  | F4_0, F4_0 => F4_3 | F4_0, F4_1 => F4_1 | F4_0, F4_2 => F4_3 | F4_0, F4_3 => F4_1
  | F4_1, F4_0 => F4_3 | F4_1, F4_1 => F4_1 | F4_1, F4_2 => F4_3 | F4_1, F4_3 => F4_1
  | F4_2, F4_0 => F4_2 | F4_2, F4_1 => F4_0 | F4_2, F4_2 => F4_2 | F4_2, F4_3 => F4_0
  | F4_3, F4_0 => F4_2 | F4_3, F4_1 => F4_0 | F4_3, F4_2 => F4_2 | F4_3, F4_3 => F4_0
  end.

#[local] Instance refa551_inst : Magma Fin4 := {| magma_op := refa551_op |}.

Lemma refa551_sat168 : @Equation168 Fin4 refa551_inst.
Proof. unfold Equation168, magma_op, refa551_inst, refa551_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa551_sat3532 : @Equation3532 Fin4 refa551_inst.
Proof. unfold Equation3532, magma_op, refa551_inst, refa551_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa551_sat4001 : @Equation4001 Fin4 refa551_inst.
Proof. unfold Equation4001, magma_op, refa551_inst, refa551_op. intros x y z w. destruct x, y, z, w; reflexivity. Qed.

Lemma refa551_not47 : ~ @Equation47 Fin4 refa551_inst.
Proof. unfold Equation47. intro H. specialize (H F4_0). unfold magma_op, refa551_inst, refa551_op in H. discriminate H. Qed.

Lemma refa551_not99 : ~ @Equation99 Fin4 refa551_inst.
Proof. unfold Equation99. intro H. specialize (H F4_0). unfold magma_op, refa551_inst, refa551_op in H. discriminate H. Qed.

Lemma refa551_not159 : ~ @Equation159 Fin4 refa551_inst.
Proof. unfold Equation159. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa551_inst, refa551_op in H. discriminate H. Qed.

Lemma refa551_not203 : ~ @Equation203 Fin4 refa551_inst.
Proof. unfold Equation203. intro H. specialize (H F4_0). unfold magma_op, refa551_inst, refa551_op in H. discriminate H. Qed.

Lemma refa551_not255 : ~ @Equation255 Fin4 refa551_inst.
Proof. unfold Equation255. intro H. specialize (H F4_0). unfold magma_op, refa551_inst, refa551_op in H. discriminate H. Qed.

Lemma refa551_not411 : ~ @Equation411 Fin4 refa551_inst.
Proof. unfold Equation411. intro H. specialize (H F4_0). unfold magma_op, refa551_inst, refa551_op in H. discriminate H. Qed.

Lemma refa551_not614 : ~ @Equation614 Fin4 refa551_inst.
Proof. unfold Equation614. intro H. specialize (H F4_0). unfold magma_op, refa551_inst, refa551_op in H. discriminate H. Qed.

Lemma refa551_not817 : ~ @Equation817 Fin4 refa551_inst.
Proof. unfold Equation817. intro H. specialize (H F4_0). unfold magma_op, refa551_inst, refa551_op in H. discriminate H. Qed.

Lemma refa551_not1020 : ~ @Equation1020 Fin4 refa551_inst.
Proof. unfold Equation1020. intro H. specialize (H F4_0). unfold magma_op, refa551_inst, refa551_op in H. discriminate H. Qed.

Lemma refa551_not1223 : ~ @Equation1223 Fin4 refa551_inst.
Proof. unfold Equation1223. intro H. specialize (H F4_0). unfold magma_op, refa551_inst, refa551_op in H. discriminate H. Qed.

Lemma refa551_not1431 : ~ @Equation1431 Fin4 refa551_inst.
Proof. unfold Equation1431. intro H. specialize (H F4_0 F4_2). unfold magma_op, refa551_inst, refa551_op in H. discriminate H. Qed.

Lemma refa551_not1434 : ~ @Equation1434 Fin4 refa551_inst.
Proof. unfold Equation1434. intro H. specialize (H F4_0 F4_2). unfold magma_op, refa551_inst, refa551_op in H. discriminate H. Qed.

Lemma refa551_not1435 : ~ @Equation1435 Fin4 refa551_inst.
Proof. unfold Equation1435. intro H. specialize (H F4_0 F4_2). unfold magma_op, refa551_inst, refa551_op in H. discriminate H. Qed.

Lemma refa551_not1441 : ~ @Equation1441 Fin4 refa551_inst.
Proof. unfold Equation1441. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa551_inst, refa551_op in H. discriminate H. Qed.

Lemma refa551_not1442 : ~ @Equation1442 Fin4 refa551_inst.
Proof. unfold Equation1442. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa551_inst, refa551_op in H. discriminate H. Qed.

Lemma refa551_not1445 : ~ @Equation1445 Fin4 refa551_inst.
Proof. unfold Equation1445. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa551_inst, refa551_op in H. discriminate H. Qed.

Lemma refa551_not1451 : ~ @Equation1451 Fin4 refa551_inst.
Proof. unfold Equation1451. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa551_inst, refa551_op in H. discriminate H. Qed.

Lemma refa551_not1454 : ~ @Equation1454 Fin4 refa551_inst.
Proof. unfold Equation1454. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa551_inst, refa551_op in H. discriminate H. Qed.

Lemma refa551_not1488 : ~ @Equation1488 Fin4 refa551_inst.
Proof. unfold Equation1488. intro H. specialize (H F4_0 F4_2). unfold magma_op, refa551_inst, refa551_op in H. discriminate H. Qed.

Lemma refa551_not1515 : ~ @Equation1515 Fin4 refa551_inst.
Proof. unfold Equation1515. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa551_inst, refa551_op in H. discriminate H. Qed.

Lemma refa551_not1516 : ~ @Equation1516 Fin4 refa551_inst.
Proof. unfold Equation1516. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa551_inst, refa551_op in H. discriminate H. Qed.

Lemma refa551_not1519 : ~ @Equation1519 Fin4 refa551_inst.
Proof. unfold Equation1519. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa551_inst, refa551_op in H. discriminate H. Qed.

Lemma refa551_not1525 : ~ @Equation1525 Fin4 refa551_inst.
Proof. unfold Equation1525. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa551_inst, refa551_op in H. discriminate H. Qed.

Lemma refa551_not1629 : ~ @Equation1629 Fin4 refa551_inst.
Proof. unfold Equation1629. intro H. specialize (H F4_0). unfold magma_op, refa551_inst, refa551_op in H. discriminate H. Qed.

Lemma refa551_not1832 : ~ @Equation1832 Fin4 refa551_inst.
Proof. unfold Equation1832. intro H. specialize (H F4_0). unfold magma_op, refa551_inst, refa551_op in H. discriminate H. Qed.

Lemma refa551_not2037 : ~ @Equation2037 Fin4 refa551_inst.
Proof. unfold Equation2037. intro H. specialize (H F4_0 F4_2). unfold magma_op, refa551_inst, refa551_op in H. discriminate H. Qed.

Lemma refa551_not2038 : ~ @Equation2038 Fin4 refa551_inst.
Proof. unfold Equation2038. intro H. specialize (H F4_0 F4_2). unfold magma_op, refa551_inst, refa551_op in H. discriminate H. Qed.

Lemma refa551_not2040 : ~ @Equation2040 Fin4 refa551_inst.
Proof. unfold Equation2040. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa551_inst, refa551_op in H. discriminate H. Qed.

Lemma refa551_not2041 : ~ @Equation2041 Fin4 refa551_inst.
Proof. unfold Equation2041. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa551_inst, refa551_op in H. discriminate H. Qed.

Lemma refa551_not2043 : ~ @Equation2043 Fin4 refa551_inst.
Proof. unfold Equation2043. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa551_inst, refa551_op in H. discriminate H. Qed.

Lemma refa551_not2044 : ~ @Equation2044 Fin4 refa551_inst.
Proof. unfold Equation2044. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa551_inst, refa551_op in H. discriminate H. Qed.

Lemma refa551_not2060 : ~ @Equation2060 Fin4 refa551_inst.
Proof. unfold Equation2060. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa551_inst, refa551_op in H. discriminate H. Qed.

Lemma refa551_not2063 : ~ @Equation2063 Fin4 refa551_inst.
Proof. unfold Equation2063. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa551_inst, refa551_op in H. discriminate H. Qed.

Lemma refa551_not2090 : ~ @Equation2090 Fin4 refa551_inst.
Proof. unfold Equation2090. intro H. specialize (H F4_0 F4_2). unfold magma_op, refa551_inst, refa551_op in H. discriminate H. Qed.

Lemma refa551_not2091 : ~ @Equation2091 Fin4 refa551_inst.
Proof. unfold Equation2091. intro H. specialize (H F4_0 F4_2). unfold magma_op, refa551_inst, refa551_op in H. discriminate H. Qed.

Lemma refa551_not2127 : ~ @Equation2127 Fin4 refa551_inst.
Proof. unfold Equation2127. intro H. specialize (H F4_0 F4_2). unfold magma_op, refa551_inst, refa551_op in H. discriminate H. Qed.

Lemma refa551_not2128 : ~ @Equation2128 Fin4 refa551_inst.
Proof. unfold Equation2128. intro H. specialize (H F4_0 F4_2). unfold magma_op, refa551_inst, refa551_op in H. discriminate H. Qed.

Lemma refa551_not2134 : ~ @Equation2134 Fin4 refa551_inst.
Proof. unfold Equation2134. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa551_inst, refa551_op in H. discriminate H. Qed.

Lemma refa551_not2238 : ~ @Equation2238 Fin4 refa551_inst.
Proof. unfold Equation2238. intro H. specialize (H F4_0). unfold magma_op, refa551_inst, refa551_op in H. discriminate H. Qed.

Lemma refa551_not2441 : ~ @Equation2441 Fin4 refa551_inst.
Proof. unfold Equation2441. intro H. specialize (H F4_0). unfold magma_op, refa551_inst, refa551_op in H. discriminate H. Qed.

Lemma refa551_not2644 : ~ @Equation2644 Fin4 refa551_inst.
Proof. unfold Equation2644. intro H. specialize (H F4_0). unfold magma_op, refa551_inst, refa551_op in H. discriminate H. Qed.

Lemma refa551_not2847 : ~ @Equation2847 Fin4 refa551_inst.
Proof. unfold Equation2847. intro H. specialize (H F4_0). unfold magma_op, refa551_inst, refa551_op in H. discriminate H. Qed.

Lemma refa551_not3050 : ~ @Equation3050 Fin4 refa551_inst.
Proof. unfold Equation3050. intro H. specialize (H F4_0). unfold magma_op, refa551_inst, refa551_op in H. discriminate H. Qed.

Lemma refa551_not3253 : ~ @Equation3253 Fin4 refa551_inst.
Proof. unfold Equation3253. intro H. specialize (H F4_0). unfold magma_op, refa551_inst, refa551_op in H. discriminate H. Qed.

Lemma refa551_not3458 : ~ @Equation3458 Fin4 refa551_inst.
Proof. unfold Equation3458. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa551_inst, refa551_op in H. discriminate H. Qed.

Lemma refa551_not3459 : ~ @Equation3459 Fin4 refa551_inst.
Proof. unfold Equation3459. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa551_inst, refa551_op in H. discriminate H. Qed.

Lemma refa551_not3464 : ~ @Equation3464 Fin4 refa551_inst.
Proof. unfold Equation3464. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa551_inst, refa551_op in H. discriminate H. Qed.

Lemma refa551_not3465 : ~ @Equation3465 Fin4 refa551_inst.
Proof. unfold Equation3465. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa551_inst, refa551_op in H. discriminate H. Qed.

Lemma refa551_not3472 : ~ @Equation3472 Fin4 refa551_inst.
Proof. unfold Equation3472. intro H. specialize (H F4_0 F4_2). unfold magma_op, refa551_inst, refa551_op in H. discriminate H. Qed.

Lemma refa551_not3474 : ~ @Equation3474 Fin4 refa551_inst.
Proof. unfold Equation3474. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa551_inst, refa551_op in H. discriminate H. Qed.

Lemma refa551_not3475 : ~ @Equation3475 Fin4 refa551_inst.
Proof. unfold Equation3475. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa551_inst, refa551_op in H. discriminate H. Qed.

Lemma refa551_not3481 : ~ @Equation3481 Fin4 refa551_inst.
Proof. unfold Equation3481. intro H. specialize (H F4_0 F4_2). unfold magma_op, refa551_inst, refa551_op in H. discriminate H. Qed.

Lemma refa551_not3482 : ~ @Equation3482 Fin4 refa551_inst.
Proof. unfold Equation3482. intro H. specialize (H F4_0 F4_2). unfold magma_op, refa551_inst, refa551_op in H. discriminate H. Qed.

Lemma refa551_not3484 : ~ @Equation3484 Fin4 refa551_inst.
Proof. unfold Equation3484. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa551_inst, refa551_op in H. discriminate H. Qed.

Lemma refa551_not3509 : ~ @Equation3509 Fin4 refa551_inst.
Proof. unfold Equation3509. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa551_inst, refa551_op in H. discriminate H. Qed.

Lemma refa551_not3518 : ~ @Equation3518 Fin4 refa551_inst.
Proof. unfold Equation3518. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa551_inst, refa551_op in H. discriminate H. Qed.

Lemma refa551_not3519 : ~ @Equation3519 Fin4 refa551_inst.
Proof. unfold Equation3519. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa551_inst, refa551_op in H. discriminate H. Qed.

Lemma refa551_not3545 : ~ @Equation3545 Fin4 refa551_inst.
Proof. unfold Equation3545. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa551_inst, refa551_op in H. discriminate H. Qed.

Lemma refa551_not3546 : ~ @Equation3546 Fin4 refa551_inst.
Proof. unfold Equation3546. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa551_inst, refa551_op in H. discriminate H. Qed.

Lemma refa551_not3548 : ~ @Equation3548 Fin4 refa551_inst.
Proof. unfold Equation3548. intro H. specialize (H F4_0 F4_2). unfold magma_op, refa551_inst, refa551_op in H. discriminate H. Qed.

Lemma refa551_not3549 : ~ @Equation3549 Fin4 refa551_inst.
Proof. unfold Equation3549. intro H. specialize (H F4_0 F4_2). unfold magma_op, refa551_inst, refa551_op in H. discriminate H. Qed.

Lemma refa551_not3555 : ~ @Equation3555 Fin4 refa551_inst.
Proof. unfold Equation3555. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa551_inst, refa551_op in H. discriminate H. Qed.

Lemma refa551_not3558 : ~ @Equation3558 Fin4 refa551_inst.
Proof. unfold Equation3558. intro H. specialize (H F4_0 F4_2). unfold magma_op, refa551_inst, refa551_op in H. discriminate H. Qed.

Lemma refa551_not3659 : ~ @Equation3659 Fin4 refa551_inst.
Proof. unfold Equation3659. intro H. specialize (H F4_0). unfold magma_op, refa551_inst, refa551_op in H. discriminate H. Qed.

Lemma refa551_not3865 : ~ @Equation3865 Fin4 refa551_inst.
Proof. unfold Equation3865. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa551_inst, refa551_op in H. discriminate H. Qed.

Lemma refa551_not3867 : ~ @Equation3867 Fin4 refa551_inst.
Proof. unfold Equation3867. intro H. specialize (H F4_0 F4_2). unfold magma_op, refa551_inst, refa551_op in H. discriminate H. Qed.

Lemma refa551_not3868 : ~ @Equation3868 Fin4 refa551_inst.
Proof. unfold Equation3868. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa551_inst, refa551_op in H. discriminate H. Qed.

Lemma refa551_not3870 : ~ @Equation3870 Fin4 refa551_inst.
Proof. unfold Equation3870. intro H. specialize (H F4_0 F4_2). unfold magma_op, refa551_inst, refa551_op in H. discriminate H. Qed.

Lemma refa551_not3871 : ~ @Equation3871 Fin4 refa551_inst.
Proof. unfold Equation3871. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa551_inst, refa551_op in H. discriminate H. Qed.

Lemma refa551_not3878 : ~ @Equation3878 Fin4 refa551_inst.
Proof. unfold Equation3878. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa551_inst, refa551_op in H. discriminate H. Qed.

Lemma refa551_not3881 : ~ @Equation3881 Fin4 refa551_inst.
Proof. unfold Equation3881. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa551_inst, refa551_op in H. discriminate H. Qed.

Lemma refa551_not3887 : ~ @Equation3887 Fin4 refa551_inst.
Proof. unfold Equation3887. intro H. specialize (H F4_0 F4_2). unfold magma_op, refa551_inst, refa551_op in H. discriminate H. Qed.

Lemma refa551_not3888 : ~ @Equation3888 Fin4 refa551_inst.
Proof. unfold Equation3888. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa551_inst, refa551_op in H. discriminate H. Qed.

Lemma refa551_not3890 : ~ @Equation3890 Fin4 refa551_inst.
Proof. unfold Equation3890. intro H. specialize (H F4_0 F4_2). unfold magma_op, refa551_inst, refa551_op in H. discriminate H. Qed.

Lemma refa551_not3917 : ~ @Equation3917 Fin4 refa551_inst.
Proof. unfold Equation3917. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa551_inst, refa551_op in H. discriminate H. Qed.

Lemma refa551_not3925 : ~ @Equation3925 Fin4 refa551_inst.
Proof. unfold Equation3925. intro H. specialize (H F4_0 F4_2). unfold magma_op, refa551_inst, refa551_op in H. discriminate H. Qed.

Lemma refa551_not3927 : ~ @Equation3927 Fin4 refa551_inst.
Proof. unfold Equation3927. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa551_inst, refa551_op in H. discriminate H. Qed.

Lemma refa551_not3928 : ~ @Equation3928 Fin4 refa551_inst.
Proof. unfold Equation3928. intro H. specialize (H F4_0 F4_2). unfold magma_op, refa551_inst, refa551_op in H. discriminate H. Qed.

Lemma refa551_not3951 : ~ @Equation3951 Fin4 refa551_inst.
Proof. unfold Equation3951. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa551_inst, refa551_op in H. discriminate H. Qed.

Lemma refa551_not3954 : ~ @Equation3954 Fin4 refa551_inst.
Proof. unfold Equation3954. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa551_inst, refa551_op in H. discriminate H. Qed.

Lemma refa551_not3961 : ~ @Equation3961 Fin4 refa551_inst.
Proof. unfold Equation3961. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa551_inst, refa551_op in H. discriminate H. Qed.

Lemma refa551_not3962 : ~ @Equation3962 Fin4 refa551_inst.
Proof. unfold Equation3962. intro H. specialize (H F4_0 F4_2). unfold magma_op, refa551_inst, refa551_op in H. discriminate H. Qed.

Lemma refa551_not3964 : ~ @Equation3964 Fin4 refa551_inst.
Proof. unfold Equation3964. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa551_inst, refa551_op in H. discriminate H. Qed.

Lemma refa551_not4065 : ~ @Equation4065 Fin4 refa551_inst.
Proof. unfold Equation4065. intro H. specialize (H F4_0). unfold magma_op, refa551_inst, refa551_op in H. discriminate H. Qed.

Lemma refa551_not4269 : ~ @Equation4269 Fin4 refa551_inst.
Proof. unfold Equation4269. intro H. specialize (H F4_0 F4_2). unfold magma_op, refa551_inst, refa551_op in H. discriminate H. Qed.

Lemma refa551_not4270 : ~ @Equation4270 Fin4 refa551_inst.
Proof. unfold Equation4270. intro H. specialize (H F4_0 F4_2). unfold magma_op, refa551_inst, refa551_op in H. discriminate H. Qed.

Lemma refa551_not4272 : ~ @Equation4272 Fin4 refa551_inst.
Proof. unfold Equation4272. intro H. specialize (H F4_0 F4_2). unfold magma_op, refa551_inst, refa551_op in H. discriminate H. Qed.

Lemma refa551_not4273 : ~ @Equation4273 Fin4 refa551_inst.
Proof. unfold Equation4273. intro H. specialize (H F4_0 F4_2). unfold magma_op, refa551_inst, refa551_op in H. discriminate H. Qed.

Lemma refa551_not4275 : ~ @Equation4275 Fin4 refa551_inst.
Proof. unfold Equation4275. intro H. specialize (H F4_0 F4_2). unfold magma_op, refa551_inst, refa551_op in H. discriminate H. Qed.

Lemma refa551_not4276 : ~ @Equation4276 Fin4 refa551_inst.
Proof. unfold Equation4276. intro H. specialize (H F4_0 F4_2). unfold magma_op, refa551_inst, refa551_op in H. discriminate H. Qed.

Lemma refa551_not4283 : ~ @Equation4283 Fin4 refa551_inst.
Proof. unfold Equation4283. intro H. specialize (H F4_0 F4_2). unfold magma_op, refa551_inst, refa551_op in H. discriminate H. Qed.

Lemma refa551_not4284 : ~ @Equation4284 Fin4 refa551_inst.
Proof. unfold Equation4284. intro H. specialize (H F4_0 F4_2). unfold magma_op, refa551_inst, refa551_op in H. discriminate H. Qed.

Lemma refa551_not4290 : ~ @Equation4290 Fin4 refa551_inst.
Proof. unfold Equation4290. intro H. specialize (H F4_0 F4_2). unfold magma_op, refa551_inst, refa551_op in H. discriminate H. Qed.

Lemma refa551_not4291 : ~ @Equation4291 Fin4 refa551_inst.
Proof. unfold Equation4291. intro H. specialize (H F4_0 F4_2). unfold magma_op, refa551_inst, refa551_op in H. discriminate H. Qed.

Lemma refa551_not4293 : ~ @Equation4293 Fin4 refa551_inst.
Proof. unfold Equation4293. intro H. specialize (H F4_0 F4_2). unfold magma_op, refa551_inst, refa551_op in H. discriminate H. Qed.

Lemma refa551_not4320 : ~ @Equation4320 Fin4 refa551_inst.
Proof. unfold Equation4320. intro H. specialize (H F4_0 F4_2). unfold magma_op, refa551_inst, refa551_op in H. discriminate H. Qed.

Lemma refa551_not4321 : ~ @Equation4321 Fin4 refa551_inst.
Proof. unfold Equation4321. intro H. specialize (H F4_0 F4_2). unfold magma_op, refa551_inst, refa551_op in H. discriminate H. Qed.

Lemma refa551_not4343 : ~ @Equation4343 Fin4 refa551_inst.
Proof. unfold Equation4343. intro H. specialize (H F4_0 F4_2). unfold magma_op, refa551_inst, refa551_op in H. discriminate H. Qed.

Lemma refa551_not4380 : ~ @Equation4380 Fin4 refa551_inst.
Proof. unfold Equation4380. intro H. specialize (H F4_0). unfold magma_op, refa551_inst, refa551_op in H. discriminate H. Qed.

Lemma refa551_not4583 : ~ @Equation4583 Fin4 refa551_inst.
Proof. unfold Equation4583. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa551_inst, refa551_op in H. discriminate H. Qed.

Lemma refa551_not4584 : ~ @Equation4584 Fin4 refa551_inst.
Proof. unfold Equation4584. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa551_inst, refa551_op in H. discriminate H. Qed.

Lemma refa551_not4585 : ~ @Equation4585 Fin4 refa551_inst.
Proof. unfold Equation4585. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa551_inst, refa551_op in H. discriminate H. Qed.

Lemma refa551_not4588 : ~ @Equation4588 Fin4 refa551_inst.
Proof. unfold Equation4588. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa551_inst, refa551_op in H. discriminate H. Qed.

Lemma refa551_not4590 : ~ @Equation4590 Fin4 refa551_inst.
Proof. unfold Equation4590. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa551_inst, refa551_op in H. discriminate H. Qed.

Lemma refa551_not4591 : ~ @Equation4591 Fin4 refa551_inst.
Proof. unfold Equation4591. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa551_inst, refa551_op in H. discriminate H. Qed.

Lemma refa551_not4598 : ~ @Equation4598 Fin4 refa551_inst.
Proof. unfold Equation4598. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa551_inst, refa551_op in H. discriminate H. Qed.

Lemma refa551_not4599 : ~ @Equation4599 Fin4 refa551_inst.
Proof. unfold Equation4599. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa551_inst, refa551_op in H. discriminate H. Qed.

Lemma refa551_not4605 : ~ @Equation4605 Fin4 refa551_inst.
Proof. unfold Equation4605. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa551_inst, refa551_op in H. discriminate H. Qed.

Lemma refa551_not4608 : ~ @Equation4608 Fin4 refa551_inst.
Proof. unfold Equation4608. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa551_inst, refa551_op in H. discriminate H. Qed.

Lemma refa551_not4629 : ~ @Equation4629 Fin4 refa551_inst.
Proof. unfold Equation4629. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa551_inst, refa551_op in H. discriminate H. Qed.

Lemma refa551_not4635 : ~ @Equation4635 Fin4 refa551_inst.
Proof. unfold Equation4635. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa551_inst, refa551_op in H. discriminate H. Qed.

Lemma refa551_not4636 : ~ @Equation4636 Fin4 refa551_inst.
Proof. unfold Equation4636. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa551_inst, refa551_op in H. discriminate H. Qed.

Lemma refa551_not4658 : ~ @Equation4658 Fin4 refa551_inst.
Proof. unfold Equation4658. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa551_inst, refa551_op in H. discriminate H. Qed.

(** ---- refa552 (Fin4) ---- *)

Definition refa552_op (x y : Fin4) : Fin4 :=
  match x, y with
  | F4_0, F4_0 => F4_1 | F4_0, F4_1 => F4_3 | F4_0, F4_2 => F4_0 | F4_0, F4_3 => F4_1
  | F4_1, F4_0 => F4_3 | F4_1, F4_1 => F4_1 | F4_1, F4_2 => F4_2 | F4_1, F4_3 => F4_3
  | F4_2, F4_0 => F4_0 | F4_2, F4_1 => F4_2 | F4_2, F4_2 => F4_1 | F4_2, F4_3 => F4_0
  | F4_3, F4_0 => F4_1 | F4_3, F4_1 => F4_3 | F4_3, F4_2 => F4_0 | F4_3, F4_3 => F4_1
  end.

#[local] Instance refa552_inst : Magma Fin4 := {| magma_op := refa552_op |}.

Lemma refa552_sat4229 : @Equation4229 Fin4 refa552_inst.
Proof. unfold Equation4229, magma_op, refa552_inst, refa552_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa552_not3306 : ~ @Equation3306 Fin4 refa552_inst.
Proof. unfold Equation3306. intro H. specialize (H F4_0 F4_2). unfold magma_op, refa552_inst, refa552_op in H. discriminate H. Qed.

Lemma refa552_not3308 : ~ @Equation3308 Fin4 refa552_inst.
Proof. unfold Equation3308. intro H. specialize (H F4_0 F4_2). unfold magma_op, refa552_inst, refa552_op in H. discriminate H. Qed.

Lemma refa552_not3353 : ~ @Equation3353 Fin4 refa552_inst.
Proof. unfold Equation3353. intro H. specialize (H F4_2 F4_0). unfold magma_op, refa552_inst, refa552_op in H. discriminate H. Qed.

Lemma refa552_not3355 : ~ @Equation3355 Fin4 refa552_inst.
Proof. unfold Equation3355. intro H. specialize (H F4_2 F4_0). unfold magma_op, refa552_inst, refa552_op in H. discriminate H. Qed.

Lemma refa552_not3511 : ~ @Equation3511 Fin4 refa552_inst.
Proof. unfold Equation3511. intro H. specialize (H F4_0 F4_2). unfold magma_op, refa552_inst, refa552_op in H. discriminate H. Qed.

Lemma refa552_not3518 : ~ @Equation3518 Fin4 refa552_inst.
Proof. unfold Equation3518. intro H. specialize (H F4_0 F4_2). unfold magma_op, refa552_inst, refa552_op in H. discriminate H. Qed.

Lemma refa552_not3549 : ~ @Equation3549 Fin4 refa552_inst.
Proof. unfold Equation3549. intro H. specialize (H F4_2 F4_0). unfold magma_op, refa552_inst, refa552_op in H. discriminate H. Qed.

Lemma refa552_not3556 : ~ @Equation3556 Fin4 refa552_inst.
Proof. unfold Equation3556. intro H. specialize (H F4_2 F4_0). unfold magma_op, refa552_inst, refa552_op in H. discriminate H. Qed.

Lemma refa552_not3917 : ~ @Equation3917 Fin4 refa552_inst.
Proof. unfold Equation3917. intro H. specialize (H F4_0 F4_2). unfold magma_op, refa552_inst, refa552_op in H. discriminate H. Qed.

Lemma refa552_not3924 : ~ @Equation3924 Fin4 refa552_inst.
Proof. unfold Equation3924. intro H. specialize (H F4_0 F4_2). unfold magma_op, refa552_inst, refa552_op in H. discriminate H. Qed.

Lemma refa552_not3955 : ~ @Equation3955 Fin4 refa552_inst.
Proof. unfold Equation3955. intro H. specialize (H F4_2 F4_0). unfold magma_op, refa552_inst, refa552_op in H. discriminate H. Qed.

Lemma refa552_not3962 : ~ @Equation3962 Fin4 refa552_inst.
Proof. unfold Equation3962. intro H. specialize (H F4_2 F4_0). unfold magma_op, refa552_inst, refa552_op in H. discriminate H. Qed.

Lemma refa552_not4127 : ~ @Equation4127 Fin4 refa552_inst.
Proof. unfold Equation4127. intro H. specialize (H F4_0 F4_2). unfold magma_op, refa552_inst, refa552_op in H. discriminate H. Qed.

Lemma refa552_not4131 : ~ @Equation4131 Fin4 refa552_inst.
Proof. unfold Equation4131. intro H. specialize (H F4_2 F4_0). unfold magma_op, refa552_inst, refa552_op in H. discriminate H. Qed.

Lemma refa552_not4154 : ~ @Equation4154 Fin4 refa552_inst.
Proof. unfold Equation4154. intro H. specialize (H F4_0 F4_2). unfold magma_op, refa552_inst, refa552_op in H. discriminate H. Qed.

Lemma refa552_not4158 : ~ @Equation4158 Fin4 refa552_inst.
Proof. unfold Equation4158. intro H. specialize (H F4_2 F4_0). unfold magma_op, refa552_inst, refa552_op in H. discriminate H. Qed.

(** ---- refa553 (Fin4) ---- *)

Definition refa553_op (x y : Fin4) : Fin4 :=
  match x, y with
  | F4_0, F4_0 => F4_1 | F4_0, F4_1 => F4_2 | F4_0, F4_2 => F4_3 | F4_0, F4_3 => F4_1
  | F4_1, F4_0 => F4_3 | F4_1, F4_1 => F4_3 | F4_1, F4_2 => F4_3 | F4_1, F4_3 => F4_0
  | F4_2, F4_0 => F4_3 | F4_2, F4_1 => F4_0 | F4_2, F4_2 => F4_0 | F4_2, F4_3 => F4_0
  | F4_3, F4_0 => F4_2 | F4_3, F4_1 => F4_0 | F4_3, F4_2 => F4_1 | F4_3, F4_3 => F4_2
  end.

#[local] Instance refa553_inst : Magma Fin4 := {| magma_op := refa553_op |}.

Lemma refa553_sat1833 : @Equation1833 Fin4 refa553_inst.
Proof. unfold Equation1833, magma_op, refa553_inst, refa553_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa553_not1629 : ~ @Equation1629 Fin4 refa553_inst.
Proof. unfold Equation1629. intro H. specialize (H F4_1). unfold magma_op, refa553_inst, refa553_op in H. discriminate H. Qed.

Lemma refa553_not1838 : ~ @Equation1838 Fin4 refa553_inst.
Proof. unfold Equation1838. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa553_inst, refa553_op in H. discriminate H. Qed.

Lemma refa553_not3459 : ~ @Equation3459 Fin4 refa553_inst.
Proof. unfold Equation3459. intro H. specialize (H F4_0 F4_2). unfold magma_op, refa553_inst, refa553_op in H. discriminate H. Qed.

Lemma refa553_not3518 : ~ @Equation3518 Fin4 refa553_inst.
Proof. unfold Equation3518. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa553_inst, refa553_op in H. discriminate H. Qed.

Lemma refa553_not4065 : ~ @Equation4065 Fin4 refa553_inst.
Proof. unfold Equation4065. intro H. specialize (H F4_0). unfold magma_op, refa553_inst, refa553_op in H. discriminate H. Qed.

(** ---- refa554 (Fin4) ---- *)

Definition refa554_op (x y : Fin4) : Fin4 :=
  match x, y with
  | F4_0, F4_0 => F4_2 | F4_0, F4_1 => F4_0 | F4_0, F4_2 => F4_1 | F4_0, F4_3 => F4_1
  | F4_1, F4_0 => F4_3 | F4_1, F4_1 => F4_1 | F4_1, F4_2 => F4_1 | F4_1, F4_3 => F4_1
  | F4_2, F4_0 => F4_3 | F4_2, F4_1 => F4_2 | F4_2, F4_2 => F4_2 | F4_2, F4_3 => F4_2
  | F4_3, F4_0 => F4_3 | F4_3, F4_1 => F4_3 | F4_3, F4_2 => F4_3 | F4_3, F4_3 => F4_3
  end.

#[local] Instance refa554_inst : Magma Fin4 := {| magma_op := refa554_op |}.

Lemma refa554_sat621 : @Equation621 Fin4 refa554_inst.
Proof. unfold Equation621, magma_op, refa554_inst, refa554_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa554_not3660 : ~ @Equation3660 Fin4 refa554_inst.
Proof. unfold Equation3660. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa554_inst, refa554_op in H. discriminate H. Qed.

Lemma refa554_not3862 : ~ @Equation3862 Fin4 refa554_inst.
Proof. unfold Equation3862. intro H. specialize (H F4_0). unfold magma_op, refa554_inst, refa554_op in H. discriminate H. Qed.

Lemma refa554_not4065 : ~ @Equation4065 Fin4 refa554_inst.
Proof. unfold Equation4065. intro H. specialize (H F4_0). unfold magma_op, refa554_inst, refa554_op in H. discriminate H. Qed.

Lemma refa554_not4598 : ~ @Equation4598 Fin4 refa554_inst.
Proof. unfold Equation4598. intro H. specialize (H F4_0 F4_2). unfold magma_op, refa554_inst, refa554_op in H. discriminate H. Qed.

Lemma refa554_not4599 : ~ @Equation4599 Fin4 refa554_inst.
Proof. unfold Equation4599. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa554_inst, refa554_op in H. discriminate H. Qed.

(** ---- refa555 (Fin4) ---- *)

Definition refa555_op (x y : Fin4) : Fin4 :=
  match x, y with
  | F4_0, F4_0 => F4_2 | F4_0, F4_1 => F4_2 | F4_0, F4_2 => F4_2 | F4_0, F4_3 => F4_3
  | F4_1, F4_0 => F4_3 | F4_1, F4_1 => F4_3 | F4_1, F4_2 => F4_3 | F4_1, F4_3 => F4_2
  | F4_2, F4_0 => F4_0 | F4_2, F4_1 => F4_1 | F4_2, F4_2 => F4_0 | F4_2, F4_3 => F4_0
  | F4_3, F4_0 => F4_1 | F4_3, F4_1 => F4_0 | F4_3, F4_2 => F4_1 | F4_3, F4_3 => F4_1
  end.

#[local] Instance refa555_inst : Magma Fin4 := {| magma_op := refa555_op |}.

Lemma refa555_sat1453 : @Equation1453 Fin4 refa555_inst.
Proof. unfold Equation1453, magma_op, refa555_inst, refa555_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa555_not1454 : ~ @Equation1454 Fin4 refa555_inst.
Proof. unfold Equation1454. intro H. specialize (H F4_0 F4_3). unfold magma_op, refa555_inst, refa555_op in H. discriminate H. Qed.

Lemma refa555_not2238 : ~ @Equation2238 Fin4 refa555_inst.
Proof. unfold Equation2238. intro H. specialize (H F4_1). unfold magma_op, refa555_inst, refa555_op in H. discriminate H. Qed.

Lemma refa555_not3518 : ~ @Equation3518 Fin4 refa555_inst.
Proof. unfold Equation3518. intro H. specialize (H F4_1 F4_2). unfold magma_op, refa555_inst, refa555_op in H. discriminate H. Qed.

Lemma refa555_not3519 : ~ @Equation3519 Fin4 refa555_inst.
Proof. unfold Equation3519. intro H. specialize (H F4_0 F4_3). unfold magma_op, refa555_inst, refa555_op in H. discriminate H. Qed.

Lemma refa555_not3522 : ~ @Equation3522 Fin4 refa555_inst.
Proof. unfold Equation3522. intro H. specialize (H F4_0 F4_3). unfold magma_op, refa555_inst, refa555_op in H. discriminate H. Qed.

(** ---- refa556 (Fin4) ---- *)

Definition refa556_op (x y : Fin4) : Fin4 :=
  match x, y with
  | F4_0, F4_0 => F4_3 | F4_0, F4_1 => F4_0 | F4_0, F4_2 => F4_3 | F4_0, F4_3 => F4_1
  | F4_1, F4_0 => F4_3 | F4_1, F4_1 => F4_0 | F4_1, F4_2 => F4_3 | F4_1, F4_3 => F4_1
  | F4_2, F4_0 => F4_3 | F4_2, F4_1 => F4_2 | F4_2, F4_2 => F4_3 | F4_2, F4_3 => F4_1
  | F4_3, F4_0 => F4_3 | F4_3, F4_1 => F4_2 | F4_3, F4_2 => F4_3 | F4_3, F4_3 => F4_1
  end.

#[local] Instance refa556_inst : Magma Fin4 := {| magma_op := refa556_op |}.

Lemma refa556_sat864 : @Equation864 Fin4 refa556_inst.
Proof. unfold Equation864, magma_op, refa556_inst, refa556_op. intros x y z w. destruct x, y, z, w; reflexivity. Qed.

Lemma refa556_not1426 : ~ @Equation1426 Fin4 refa556_inst.
Proof. unfold Equation1426. intro H. specialize (H F4_0). unfold magma_op, refa556_inst, refa556_op in H. discriminate H. Qed.

Lemma refa556_not3862 : ~ @Equation3862 Fin4 refa556_inst.
Proof. unfold Equation3862. intro H. specialize (H F4_1). unfold magma_op, refa556_inst, refa556_op in H. discriminate H. Qed.

Lemma refa556_not4073 : ~ @Equation4073 Fin4 refa556_inst.
Proof. unfold Equation4073. intro H. specialize (H F4_1 F4_0). unfold magma_op, refa556_inst, refa556_op in H. discriminate H. Qed.

Lemma refa556_not4118 : ~ @Equation4118 Fin4 refa556_inst.
Proof. unfold Equation4118. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa556_inst, refa556_op in H. discriminate H. Qed.

Lemma refa556_not4121 : ~ @Equation4121 Fin4 refa556_inst.
Proof. unfold Equation4121. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa556_inst, refa556_op in H. discriminate H. Qed.

Lemma refa556_not4128 : ~ @Equation4128 Fin4 refa556_inst.
Proof. unfold Equation4128. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa556_inst, refa556_op in H. discriminate H. Qed.

Lemma refa556_not4599 : ~ @Equation4599 Fin4 refa556_inst.
Proof. unfold Equation4599. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa556_inst, refa556_op in H. discriminate H. Qed.

(** ---- refa557 (Fin4) ---- *)

Definition refa557_op (x y : Fin4) : Fin4 :=
  match x, y with
  | F4_0, F4_0 => F4_0 | F4_0, F4_1 => F4_2 | F4_0, F4_2 => F4_0 | F4_0, F4_3 => F4_0
  | F4_1, F4_0 => F4_1 | F4_1, F4_1 => F4_1 | F4_1, F4_2 => F4_1 | F4_1, F4_3 => F4_0
  | F4_2, F4_0 => F4_2 | F4_2, F4_1 => F4_3 | F4_2, F4_2 => F4_2 | F4_2, F4_3 => F4_2
  | F4_3, F4_0 => F4_2 | F4_3, F4_1 => F4_3 | F4_3, F4_2 => F4_3 | F4_3, F4_3 => F4_3
  end.

#[local] Instance refa557_inst : Magma Fin4 := {| magma_op := refa557_op |}.

Lemma refa557_sat1030 : @Equation1030 Fin4 refa557_inst.
Proof. unfold Equation1030, magma_op, refa557_inst, refa557_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa557_not1228 : ~ @Equation1228 Fin4 refa557_inst.
Proof. unfold Equation1228. intro H. specialize (H F4_1 F4_3). unfold magma_op, refa557_inst, refa557_op in H. discriminate H. Qed.

Lemma refa557_not3315 : ~ @Equation3315 Fin4 refa557_inst.
Proof. unfold Equation3315. intro H. specialize (H F4_1 F4_2). unfold magma_op, refa557_inst, refa557_op in H. discriminate H. Qed.

Lemma refa557_not3316 : ~ @Equation3316 Fin4 refa557_inst.
Proof. unfold Equation3316. intro H. specialize (H F4_1 F4_2). unfold magma_op, refa557_inst, refa557_op in H. discriminate H. Qed.

Lemma refa557_not3518 : ~ @Equation3518 Fin4 refa557_inst.
Proof. unfold Equation3518. intro H. specialize (H F4_1 F4_0). unfold magma_op, refa557_inst, refa557_op in H. discriminate H. Qed.

Lemma refa557_not3519 : ~ @Equation3519 Fin4 refa557_inst.
Proof. unfold Equation3519. intro H. specialize (H F4_1 F4_2). unfold magma_op, refa557_inst, refa557_op in H. discriminate H. Qed.

Lemma refa557_not3521 : ~ @Equation3521 Fin4 refa557_inst.
Proof. unfold Equation3521. intro H. specialize (H F4_1 F4_2). unfold magma_op, refa557_inst, refa557_op in H. discriminate H. Qed.

Lemma refa557_not3714 : ~ @Equation3714 Fin4 refa557_inst.
Proof. unfold Equation3714. intro H. specialize (H F4_1 F4_2). unfold magma_op, refa557_inst, refa557_op in H. discriminate H. Qed.

Lemma refa557_not3721 : ~ @Equation3721 Fin4 refa557_inst.
Proof. unfold Equation3721. intro H. specialize (H F4_1 F4_3). unfold magma_op, refa557_inst, refa557_op in H. discriminate H. Qed.

Lemma refa557_not3724 : ~ @Equation3724 Fin4 refa557_inst.
Proof. unfold Equation3724. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa557_inst, refa557_op in H. discriminate H. Qed.

Lemma refa557_not3725 : ~ @Equation3725 Fin4 refa557_inst.
Proof. unfold Equation3725. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa557_inst, refa557_op in H. discriminate H. Qed.

Lemma refa557_not3924 : ~ @Equation3924 Fin4 refa557_inst.
Proof. unfold Equation3924. intro H. specialize (H F4_1 F4_2). unfold magma_op, refa557_inst, refa557_op in H. discriminate H. Qed.

Lemma refa557_not3925 : ~ @Equation3925 Fin4 refa557_inst.
Proof. unfold Equation3925. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa557_inst, refa557_op in H. discriminate H. Qed.

Lemma refa557_not3927 : ~ @Equation3927 Fin4 refa557_inst.
Proof. unfold Equation3927. intro H. specialize (H F4_1 F4_3). unfold magma_op, refa557_inst, refa557_op in H. discriminate H. Qed.

Lemma refa557_not3928 : ~ @Equation3928 Fin4 refa557_inst.
Proof. unfold Equation3928. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa557_inst, refa557_op in H. discriminate H. Qed.

Lemma refa557_not4120 : ~ @Equation4120 Fin4 refa557_inst.
Proof. unfold Equation4120. intro H. specialize (H F4_1 F4_3). unfold magma_op, refa557_inst, refa557_op in H. discriminate H. Qed.

Lemma refa557_not4121 : ~ @Equation4121 Fin4 refa557_inst.
Proof. unfold Equation4121. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa557_inst, refa557_op in H. discriminate H. Qed.

Lemma refa557_not4127 : ~ @Equation4127 Fin4 refa557_inst.
Proof. unfold Equation4127. intro H. specialize (H F4_1 F4_3). unfold magma_op, refa557_inst, refa557_op in H. discriminate H. Qed.

Lemma refa557_not4128 : ~ @Equation4128 Fin4 refa557_inst.
Proof. unfold Equation4128. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa557_inst, refa557_op in H. discriminate H. Qed.

Lemma refa557_not4130 : ~ @Equation4130 Fin4 refa557_inst.
Proof. unfold Equation4130. intro H. specialize (H F4_1 F4_3). unfold magma_op, refa557_inst, refa557_op in H. discriminate H. Qed.

Lemma refa557_not4131 : ~ @Equation4131 Fin4 refa557_inst.
Proof. unfold Equation4131. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa557_inst, refa557_op in H. discriminate H. Qed.

Lemma refa557_not4314 : ~ @Equation4314 Fin4 refa557_inst.
Proof. unfold Equation4314. intro H. specialize (H F4_1 F4_2). unfold magma_op, refa557_inst, refa557_op in H. discriminate H. Qed.

Lemma refa557_not4433 : ~ @Equation4433 Fin4 refa557_inst.
Proof. unfold Equation4433. intro H. specialize (H F4_1 F4_2). unfold magma_op, refa557_inst, refa557_op in H. discriminate H. Qed.

Lemma refa557_not4435 : ~ @Equation4435 Fin4 refa557_inst.
Proof. unfold Equation4435. intro H. specialize (H F4_1 F4_2). unfold magma_op, refa557_inst, refa557_op in H. discriminate H. Qed.

Lemma refa557_not4436 : ~ @Equation4436 Fin4 refa557_inst.
Proof. unfold Equation4436. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa557_inst, refa557_op in H. discriminate H. Qed.

Lemma refa557_not4472 : ~ @Equation4472 Fin4 refa557_inst.
Proof. unfold Equation4472. intro H. specialize (H F4_1 F4_3). unfold magma_op, refa557_inst, refa557_op in H. discriminate H. Qed.

Lemma refa557_not4473 : ~ @Equation4473 Fin4 refa557_inst.
Proof. unfold Equation4473. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa557_inst, refa557_op in H. discriminate H. Qed.

Lemma refa557_not4598 : ~ @Equation4598 Fin4 refa557_inst.
Proof. unfold Equation4598. intro H. specialize (H F4_1 F4_3). unfold magma_op, refa557_inst, refa557_op in H. discriminate H. Qed.

Lemma refa557_not4599 : ~ @Equation4599 Fin4 refa557_inst.
Proof. unfold Equation4599. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa557_inst, refa557_op in H. discriminate H. Qed.

Lemma refa557_not4629 : ~ @Equation4629 Fin4 refa557_inst.
Proof. unfold Equation4629. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa557_inst, refa557_op in H. discriminate H. Qed.

(** ---- refa558 (Fin4) ---- *)

Definition refa558_op (x y : Fin4) : Fin4 :=
  match x, y with
  | F4_0, F4_0 => F4_0 | F4_0, F4_1 => F4_2 | F4_0, F4_2 => F4_0 | F4_0, F4_3 => F4_1
  | F4_1, F4_0 => F4_2 | F4_1, F4_1 => F4_3 | F4_1, F4_2 => F4_1 | F4_1, F4_3 => F4_1
  | F4_2, F4_0 => F4_2 | F4_2, F4_1 => F4_1 | F4_2, F4_2 => F4_2 | F4_2, F4_3 => F4_2
  | F4_3, F4_0 => F4_1 | F4_3, F4_1 => F4_3 | F4_3, F4_2 => F4_0 | F4_3, F4_3 => F4_2
  end.

#[local] Instance refa558_inst : Magma Fin4 := {| magma_op := refa558_op |}.

Lemma refa558_sat427 : @Equation427 Fin4 refa558_inst.
Proof. unfold Equation427, magma_op, refa558_inst, refa558_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa558_not1832 : ~ @Equation1832 Fin4 refa558_inst.
Proof. unfold Equation1832. intro H. specialize (H F4_3). unfold magma_op, refa558_inst, refa558_op in H. discriminate H. Qed.

(** ---- refa559 (Fin4) ---- *)

Definition refa559_op (x y : Fin4) : Fin4 :=
  match x, y with
  | F4_0, F4_0 => F4_3 | F4_0, F4_1 => F4_2 | F4_0, F4_2 => F4_0 | F4_0, F4_3 => F4_1
  | F4_1, F4_0 => F4_3 | F4_1, F4_1 => F4_2 | F4_1, F4_2 => F4_1 | F4_1, F4_3 => F4_0
  | F4_2, F4_0 => F4_3 | F4_2, F4_1 => F4_2 | F4_2, F4_2 => F4_1 | F4_2, F4_3 => F4_0
  | F4_3, F4_0 => F4_3 | F4_3, F4_1 => F4_1 | F4_3, F4_2 => F4_2 | F4_3, F4_3 => F4_0
  end.

#[local] Instance refa559_inst : Magma Fin4 := {| magma_op := refa559_op |}.

Lemma refa559_sat473 : @Equation473 Fin4 refa559_inst.
Proof. unfold Equation473, magma_op, refa559_inst, refa559_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa559_not429 : ~ @Equation429 Fin4 refa559_inst.
Proof. unfold Equation429. intro H. specialize (H F4_0 F4_3). unfold magma_op, refa559_inst, refa559_op in H. discriminate H. Qed.

Lemma refa559_not466 : ~ @Equation466 Fin4 refa559_inst.
Proof. unfold Equation466. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa559_inst, refa559_op in H. discriminate H. Qed.

(** ---- refa56 (Fin3) ---- *)

Definition refa56_op (x y : Fin3) : Fin3 :=
  match x, y with
  | F3_0, F3_0 => F3_0 | F3_0, F3_1 => F3_1 | F3_0, F3_2 => F3_2
  | F3_1, F3_0 => F3_1 | F3_1, F3_1 => F3_0 | F3_1, F3_2 => F3_1
  | F3_2, F3_0 => F3_1 | F3_2, F3_1 => F3_2 | F3_2, F3_2 => F3_0
  end.

#[local] Instance refa56_inst : Magma Fin3 := {| magma_op := refa56_op |}.

Lemma refa56_sat31 : @Equation31 Fin3 refa56_inst.
Proof. unfold Equation31, magma_op, refa56_inst, refa56_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa56_sat1023 : @Equation1023 Fin3 refa56_inst.
Proof. unfold Equation1023, magma_op, refa56_inst, refa56_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa56_sat1028 : @Equation1028 Fin3 refa56_inst.
Proof. unfold Equation1028, magma_op, refa56_inst, refa56_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa56_sat3485 : @Equation3485 Fin3 refa56_inst.
Proof. unfold Equation3485, magma_op, refa56_inst, refa56_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa56_sat4098 : @Equation4098 Fin3 refa56_inst.
Proof. unfold Equation4098, magma_op, refa56_inst, refa56_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa56_not1832 : ~ @Equation1832 Fin3 refa56_inst.
Proof. unfold Equation1832. intro H. specialize (H F3_2). unfold magma_op, refa56_inst, refa56_op in H. discriminate H. Qed.

Lemma refa56_not2449 : ~ @Equation2449 Fin3 refa56_inst.
Proof. unfold Equation2449. intro H. specialize (H F3_2 F3_0). unfold magma_op, refa56_inst, refa56_op in H. discriminate H. Qed.

Lemma refa56_not2530 : ~ @Equation2530 Fin3 refa56_inst.
Proof. unfold Equation2530. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa56_inst, refa56_op in H. discriminate H. Qed.

Lemma refa56_not2699 : ~ @Equation2699 Fin3 refa56_inst.
Proof. unfold Equation2699. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa56_inst, refa56_op in H. discriminate H. Qed.

Lemma refa56_not3068 : ~ @Equation3068 Fin3 refa56_inst.
Proof. unfold Equation3068. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa56_inst, refa56_op in H. discriminate H. Qed.

Lemma refa56_not3105 : ~ @Equation3105 Fin3 refa56_inst.
Proof. unfold Equation3105. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa56_inst, refa56_op in H. discriminate H. Qed.

Lemma refa56_not3253 : ~ @Equation3253 Fin3 refa56_inst.
Proof. unfold Equation3253. intro H. specialize (H F3_2). unfold magma_op, refa56_inst, refa56_op in H. discriminate H. Qed.

Lemma refa56_not3459 : ~ @Equation3459 Fin3 refa56_inst.
Proof. unfold Equation3459. intro H. specialize (H F3_2 F3_0). unfold magma_op, refa56_inst, refa56_op in H. discriminate H. Qed.

Lemma refa56_not3481 : ~ @Equation3481 Fin3 refa56_inst.
Proof. unfold Equation3481. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa56_inst, refa56_op in H. discriminate H. Qed.

Lemma refa56_not4070 : ~ @Equation4070 Fin3 refa56_inst.
Proof. unfold Equation4070. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa56_inst, refa56_op in H. discriminate H. Qed.

Lemma refa56_not4084 : ~ @Equation4084 Fin3 refa56_inst.
Proof. unfold Equation4084. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa56_inst, refa56_op in H. discriminate H. Qed.

Lemma refa56_not4273 : ~ @Equation4273 Fin3 refa56_inst.
Proof. unfold Equation4273. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa56_inst, refa56_op in H. discriminate H. Qed.

Lemma refa56_not4314 : ~ @Equation4314 Fin3 refa56_inst.
Proof. unfold Equation4314. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa56_inst, refa56_op in H. discriminate H. Qed.

Lemma refa56_not4320 : ~ @Equation4320 Fin3 refa56_inst.
Proof. unfold Equation4320. intro H. specialize (H F3_2 F3_1). unfold magma_op, refa56_inst, refa56_op in H. discriminate H. Qed.

(** ---- refa560 (Fin4) ---- *)

Definition refa560_op (x y : Fin4) : Fin4 :=
  match x, y with
  | F4_0, F4_0 => F4_2 | F4_0, F4_1 => F4_3 | F4_0, F4_2 => F4_3 | F4_0, F4_3 => F4_3
  | F4_1, F4_0 => F4_3 | F4_1, F4_1 => F4_2 | F4_1, F4_2 => F4_2 | F4_1, F4_3 => F4_2
  | F4_2, F4_0 => F4_1 | F4_2, F4_1 => F4_1 | F4_2, F4_2 => F4_1 | F4_2, F4_3 => F4_0
  | F4_3, F4_0 => F4_0 | F4_3, F4_1 => F4_0 | F4_3, F4_2 => F4_0 | F4_3, F4_3 => F4_1
  end.

#[local] Instance refa560_inst : Magma Fin4 := {| magma_op := refa560_op |}.

Lemma refa560_sat1453 : @Equation1453 Fin4 refa560_inst.
Proof. unfold Equation1453, magma_op, refa560_inst, refa560_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa560_sat1456 : @Equation1456 Fin4 refa560_inst.
Proof. unfold Equation1456, magma_op, refa560_inst, refa560_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa560_not151 : ~ @Equation151 Fin4 refa560_inst.
Proof. unfold Equation151. intro H. specialize (H F4_0). unfold magma_op, refa560_inst, refa560_op in H. discriminate H. Qed.

Lemma refa560_not1428 : ~ @Equation1428 Fin4 refa560_inst.
Proof. unfold Equation1428. intro H. specialize (H F4_0 F4_3). unfold magma_op, refa560_inst, refa560_op in H. discriminate H. Qed.

Lemma refa560_not2257 : ~ @Equation2257 Fin4 refa560_inst.
Proof. unfold Equation2257. intro H. specialize (H F4_0 F4_2). unfold magma_op, refa560_inst, refa560_op in H. discriminate H. Qed.

Lemma refa560_not3058 : ~ @Equation3058 Fin4 refa560_inst.
Proof. unfold Equation3058. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa560_inst, refa560_op in H. discriminate H. Qed.

Lemma refa560_not3066 : ~ @Equation3066 Fin4 refa560_inst.
Proof. unfold Equation3066. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa560_inst, refa560_op in H. discriminate H. Qed.

Lemma refa560_not3075 : ~ @Equation3075 Fin4 refa560_inst.
Proof. unfold Equation3075. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa560_inst, refa560_op in H. discriminate H. Qed.

Lemma refa560_not3456 : ~ @Equation3456 Fin4 refa560_inst.
Proof. unfold Equation3456. intro H. specialize (H F4_0). unfold magma_op, refa560_inst, refa560_op in H. discriminate H. Qed.

Lemma refa560_not4314 : ~ @Equation4314 Fin4 refa560_inst.
Proof. unfold Equation4314. intro H. specialize (H F4_0 F4_3). unfold magma_op, refa560_inst, refa560_op in H. discriminate H. Qed.

Lemma refa560_not4598 : ~ @Equation4598 Fin4 refa560_inst.
Proof. unfold Equation4598. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa560_inst, refa560_op in H. discriminate H. Qed.

Lemma refa560_not4656 : ~ @Equation4656 Fin4 refa560_inst.
Proof. unfold Equation4656. intro H. specialize (H F4_0 F4_0 F4_1). unfold magma_op, refa560_inst, refa560_op in H. discriminate H. Qed.

(** ---- refa561 (Fin4) ---- *)

Definition refa561_op (x y : Fin4) : Fin4 :=
  match x, y with
  | F4_0, F4_0 => F4_0 | F4_0, F4_1 => F4_3 | F4_0, F4_2 => F4_2 | F4_0, F4_3 => F4_1
  | F4_1, F4_0 => F4_3 | F4_1, F4_1 => F4_0 | F4_1, F4_2 => F4_1 | F4_1, F4_3 => F4_2
  | F4_2, F4_0 => F4_2 | F4_2, F4_1 => F4_1 | F4_2, F4_2 => F4_0 | F4_2, F4_3 => F4_3
  | F4_3, F4_0 => F4_1 | F4_3, F4_1 => F4_2 | F4_3, F4_2 => F4_3 | F4_3, F4_3 => F4_0
  end.

#[local] Instance refa561_inst : Magma Fin4 := {| magma_op := refa561_op |}.

Lemma refa561_sat775 : @Equation775 Fin4 refa561_inst.
Proof. unfold Equation775, magma_op, refa561_inst, refa561_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa561_sat1710 : @Equation1710 Fin4 refa561_inst.
Proof. unfold Equation1710, magma_op, refa561_inst, refa561_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa561_not99 : ~ @Equation99 Fin4 refa561_inst.
Proof. unfold Equation99. intro H. specialize (H F4_1). unfold magma_op, refa561_inst, refa561_op in H. discriminate H. Qed.

Lemma refa561_not417 : ~ @Equation417 Fin4 refa561_inst.
Proof. unfold Equation417. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa561_inst, refa561_op in H. discriminate H. Qed.

Lemma refa561_not419 : ~ @Equation419 Fin4 refa561_inst.
Proof. unfold Equation419. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa561_inst, refa561_op in H. discriminate H. Qed.

Lemma refa561_not436 : ~ @Equation436 Fin4 refa561_inst.
Proof. unfold Equation436. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa561_inst, refa561_op in H. discriminate H. Qed.

Lemma refa561_not440 : ~ @Equation440 Fin4 refa561_inst.
Proof. unfold Equation440. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa561_inst, refa561_op in H. discriminate H. Qed.

Lemma refa561_not466 : ~ @Equation466 Fin4 refa561_inst.
Proof. unfold Equation466. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa561_inst, refa561_op in H. discriminate H. Qed.

Lemma refa561_not504 : ~ @Equation504 Fin4 refa561_inst.
Proof. unfold Equation504. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa561_inst, refa561_op in H. discriminate H. Qed.

Lemma refa561_not620 : ~ @Equation620 Fin4 refa561_inst.
Proof. unfold Equation620. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa561_inst, refa561_op in H. discriminate H. Qed.

Lemma refa561_not630 : ~ @Equation630 Fin4 refa561_inst.
Proof. unfold Equation630. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa561_inst, refa561_op in H. discriminate H. Qed.

Lemma refa561_not643 : ~ @Equation643 Fin4 refa561_inst.
Proof. unfold Equation643. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa561_inst, refa561_op in H. discriminate H. Qed.

Lemma refa561_not669 : ~ @Equation669 Fin4 refa561_inst.
Proof. unfold Equation669. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa561_inst, refa561_op in H. discriminate H. Qed.

Lemma refa561_not676 : ~ @Equation676 Fin4 refa561_inst.
Proof. unfold Equation676. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa561_inst, refa561_op in H. discriminate H. Qed.

Lemma refa561_not817 : ~ @Equation817 Fin4 refa561_inst.
Proof. unfold Equation817. intro H. specialize (H F4_1). unfold magma_op, refa561_inst, refa561_op in H. discriminate H. Qed.

Lemma refa561_not1036 : ~ @Equation1036 Fin4 refa561_inst.
Proof. unfold Equation1036. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa561_inst, refa561_op in H. discriminate H. Qed.

Lemma refa561_not1038 : ~ @Equation1038 Fin4 refa561_inst.
Proof. unfold Equation1038. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa561_inst, refa561_op in H. discriminate H. Qed.

Lemma refa561_not1045 : ~ @Equation1045 Fin4 refa561_inst.
Proof. unfold Equation1045. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa561_inst, refa561_op in H. discriminate H. Qed.

Lemma refa561_not1049 : ~ @Equation1049 Fin4 refa561_inst.
Proof. unfold Equation1049. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa561_inst, refa561_op in H. discriminate H. Qed.

Lemma refa561_not1075 : ~ @Equation1075 Fin4 refa561_inst.
Proof. unfold Equation1075. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa561_inst, refa561_op in H. discriminate H. Qed.

Lemma refa561_not1082 : ~ @Equation1082 Fin4 refa561_inst.
Proof. unfold Equation1082. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa561_inst, refa561_op in H. discriminate H. Qed.

Lemma refa561_not1086 : ~ @Equation1086 Fin4 refa561_inst.
Proof. unfold Equation1086. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa561_inst, refa561_op in H. discriminate H. Qed.

Lemma refa561_not1241 : ~ @Equation1241 Fin4 refa561_inst.
Proof. unfold Equation1241. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa561_inst, refa561_op in H. discriminate H. Qed.

Lemma refa561_not1252 : ~ @Equation1252 Fin4 refa561_inst.
Proof. unfold Equation1252. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa561_inst, refa561_op in H. discriminate H. Qed.

Lemma refa561_not1276 : ~ @Equation1276 Fin4 refa561_inst.
Proof. unfold Equation1276. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa561_inst, refa561_op in H. discriminate H. Qed.

Lemma refa561_not1285 : ~ @Equation1285 Fin4 refa561_inst.
Proof. unfold Equation1285. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa561_inst, refa561_op in H. discriminate H. Qed.

Lemma refa561_not1434 : ~ @Equation1434 Fin4 refa561_inst.
Proof. unfold Equation1434. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa561_inst, refa561_op in H. discriminate H. Qed.

Lemma refa561_not1479 : ~ @Equation1479 Fin4 refa561_inst.
Proof. unfold Equation1479. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa561_inst, refa561_op in H. discriminate H. Qed.

Lemma refa561_not1632 : ~ @Equation1632 Fin4 refa561_inst.
Proof. unfold Equation1632. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa561_inst, refa561_op in H. discriminate H. Qed.

Lemma refa561_not1635 : ~ @Equation1635 Fin4 refa561_inst.
Proof. unfold Equation1635. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa561_inst, refa561_op in H. discriminate H. Qed.

Lemma refa561_not1654 : ~ @Equation1654 Fin4 refa561_inst.
Proof. unfold Equation1654. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa561_inst, refa561_op in H. discriminate H. Qed.

Lemma refa561_not1684 : ~ @Equation1684 Fin4 refa561_inst.
Proof. unfold Equation1684. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa561_inst, refa561_op in H. discriminate H. Qed.

Lemma refa561_not1691 : ~ @Equation1691 Fin4 refa561_inst.
Proof. unfold Equation1691. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa561_inst, refa561_op in H. discriminate H. Qed.

Lemma refa561_not1722 : ~ @Equation1722 Fin4 refa561_inst.
Proof. unfold Equation1722. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa561_inst, refa561_op in H. discriminate H. Qed.

Lemma refa561_not1838 : ~ @Equation1838 Fin4 refa561_inst.
Proof. unfold Equation1838. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa561_inst, refa561_op in H. discriminate H. Qed.

Lemma refa561_not1840 : ~ @Equation1840 Fin4 refa561_inst.
Proof. unfold Equation1840. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa561_inst, refa561_op in H. discriminate H. Qed.

Lemma refa561_not1848 : ~ @Equation1848 Fin4 refa561_inst.
Proof. unfold Equation1848. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa561_inst, refa561_op in H. discriminate H. Qed.

Lemma refa561_not1894 : ~ @Equation1894 Fin4 refa561_inst.
Proof. unfold Equation1894. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa561_inst, refa561_op in H. discriminate H. Qed.

Lemma refa561_not1921 : ~ @Equation1921 Fin4 refa561_inst.
Proof. unfold Equation1921. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa561_inst, refa561_op in H. discriminate H. Qed.

Lemma refa561_not1925 : ~ @Equation1925 Fin4 refa561_inst.
Proof. unfold Equation1925. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa561_inst, refa561_op in H. discriminate H. Qed.

Lemma refa561_not2060 : ~ @Equation2060 Fin4 refa561_inst.
Proof. unfold Equation2060. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa561_inst, refa561_op in H. discriminate H. Qed.

Lemma refa561_not2088 : ~ @Equation2088 Fin4 refa561_inst.
Proof. unfold Equation2088. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa561_inst, refa561_op in H. discriminate H. Qed.

Lemma refa561_not2244 : ~ @Equation2244 Fin4 refa561_inst.
Proof. unfold Equation2244. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa561_inst, refa561_op in H. discriminate H. Qed.

Lemma refa561_not2256 : ~ @Equation2256 Fin4 refa561_inst.
Proof. unfold Equation2256. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa561_inst, refa561_op in H. discriminate H. Qed.

Lemma refa561_not2291 : ~ @Equation2291 Fin4 refa561_inst.
Proof. unfold Equation2291. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa561_inst, refa561_op in H. discriminate H. Qed.

Lemma refa561_not2340 : ~ @Equation2340 Fin4 refa561_inst.
Proof. unfold Equation2340. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa561_inst, refa561_op in H. discriminate H. Qed.

Lemma refa561_not2447 : ~ @Equation2447 Fin4 refa561_inst.
Proof. unfold Equation2447. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa561_inst, refa561_op in H. discriminate H. Qed.

Lemma refa561_not2449 : ~ @Equation2449 Fin4 refa561_inst.
Proof. unfold Equation2449. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa561_inst, refa561_op in H. discriminate H. Qed.

Lemma refa561_not2457 : ~ @Equation2457 Fin4 refa561_inst.
Proof. unfold Equation2457. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa561_inst, refa561_op in H. discriminate H. Qed.

Lemma refa561_not2459 : ~ @Equation2459 Fin4 refa561_inst.
Proof. unfold Equation2459. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa561_inst, refa561_op in H. discriminate H. Qed.

Lemma refa561_not2496 : ~ @Equation2496 Fin4 refa561_inst.
Proof. unfold Equation2496. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa561_inst, refa561_op in H. discriminate H. Qed.

Lemma refa561_not2541 : ~ @Equation2541 Fin4 refa561_inst.
Proof. unfold Equation2541. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa561_inst, refa561_op in H. discriminate H. Qed.

Lemma refa561_not2543 : ~ @Equation2543 Fin4 refa561_inst.
Proof. unfold Equation2543. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa561_inst, refa561_op in H. discriminate H. Qed.

Lemma refa561_not2644 : ~ @Equation2644 Fin4 refa561_inst.
Proof. unfold Equation2644. intro H. specialize (H F4_1). unfold magma_op, refa561_inst, refa561_op in H. discriminate H. Qed.

Lemma refa561_not2853 : ~ @Equation2853 Fin4 refa561_inst.
Proof. unfold Equation2853. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa561_inst, refa561_op in H. discriminate H. Qed.

Lemma refa561_not2863 : ~ @Equation2863 Fin4 refa561_inst.
Proof. unfold Equation2863. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa561_inst, refa561_op in H. discriminate H. Qed.

Lemma refa561_not2902 : ~ @Equation2902 Fin4 refa561_inst.
Proof. unfold Equation2902. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa561_inst, refa561_op in H. discriminate H. Qed.

Lemma refa561_not2909 : ~ @Equation2909 Fin4 refa561_inst.
Proof. unfold Equation2909. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa561_inst, refa561_op in H. discriminate H. Qed.

Lemma refa561_not2949 : ~ @Equation2949 Fin4 refa561_inst.
Proof. unfold Equation2949. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa561_inst, refa561_op in H. discriminate H. Qed.

Lemma refa561_not3058 : ~ @Equation3058 Fin4 refa561_inst.
Proof. unfold Equation3058. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa561_inst, refa561_op in H. discriminate H. Qed.

Lemma refa561_not3066 : ~ @Equation3066 Fin4 refa561_inst.
Proof. unfold Equation3066. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa561_inst, refa561_op in H. discriminate H. Qed.

Lemma refa561_not3075 : ~ @Equation3075 Fin4 refa561_inst.
Proof. unfold Equation3075. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa561_inst, refa561_op in H. discriminate H. Qed.

Lemma refa561_not3112 : ~ @Equation3112 Fin4 refa561_inst.
Proof. unfold Equation3112. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa561_inst, refa561_op in H. discriminate H. Qed.

Lemma refa561_not3143 : ~ @Equation3143 Fin4 refa561_inst.
Proof. unfold Equation3143. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa561_inst, refa561_op in H. discriminate H. Qed.

Lemma refa561_not3152 : ~ @Equation3152 Fin4 refa561_inst.
Proof. unfold Equation3152. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa561_inst, refa561_op in H. discriminate H. Qed.

Lemma refa561_not3253 : ~ @Equation3253 Fin4 refa561_inst.
Proof. unfold Equation3253. intro H. specialize (H F4_1). unfold magma_op, refa561_inst, refa561_op in H. discriminate H. Qed.

Lemma refa561_not3456 : ~ @Equation3456 Fin4 refa561_inst.
Proof. unfold Equation3456. intro H. specialize (H F4_1). unfold magma_op, refa561_inst, refa561_op in H. discriminate H. Qed.

Lemma refa561_not3712 : ~ @Equation3712 Fin4 refa561_inst.
Proof. unfold Equation3712. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa561_inst, refa561_op in H. discriminate H. Qed.

Lemma refa561_not3714 : ~ @Equation3714 Fin4 refa561_inst.
Proof. unfold Equation3714. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa561_inst, refa561_op in H. discriminate H. Qed.

Lemma refa561_not3721 : ~ @Equation3721 Fin4 refa561_inst.
Proof. unfold Equation3721. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa561_inst, refa561_op in H. discriminate H. Qed.

Lemma refa561_not3725 : ~ @Equation3725 Fin4 refa561_inst.
Proof. unfold Equation3725. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa561_inst, refa561_op in H. discriminate H. Qed.

Lemma refa561_not3748 : ~ @Equation3748 Fin4 refa561_inst.
Proof. unfold Equation3748. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa561_inst, refa561_op in H. discriminate H. Qed.

Lemma refa561_not3752 : ~ @Equation3752 Fin4 refa561_inst.
Proof. unfold Equation3752. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa561_inst, refa561_op in H. discriminate H. Qed.

Lemma refa561_not3759 : ~ @Equation3759 Fin4 refa561_inst.
Proof. unfold Equation3759. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa561_inst, refa561_op in H. discriminate H. Qed.

Lemma refa561_not3761 : ~ @Equation3761 Fin4 refa561_inst.
Proof. unfold Equation3761. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa561_inst, refa561_op in H. discriminate H. Qed.

Lemma refa561_not3862 : ~ @Equation3862 Fin4 refa561_inst.
Proof. unfold Equation3862. intro H. specialize (H F4_1). unfold magma_op, refa561_inst, refa561_op in H. discriminate H. Qed.

Lemma refa561_not4065 : ~ @Equation4065 Fin4 refa561_inst.
Proof. unfold Equation4065. intro H. specialize (H F4_1). unfold magma_op, refa561_inst, refa561_op in H. discriminate H. Qed.

Lemma refa561_not4273 : ~ @Equation4273 Fin4 refa561_inst.
Proof. unfold Equation4273. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa561_inst, refa561_op in H. discriminate H. Qed.

Lemma refa561_not4275 : ~ @Equation4275 Fin4 refa561_inst.
Proof. unfold Equation4275. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa561_inst, refa561_op in H. discriminate H. Qed.

Lemma refa561_not4290 : ~ @Equation4290 Fin4 refa561_inst.
Proof. unfold Equation4290. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa561_inst, refa561_op in H. discriminate H. Qed.

Lemma refa561_not4320 : ~ @Equation4320 Fin4 refa561_inst.
Proof. unfold Equation4320. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa561_inst, refa561_op in H. discriminate H. Qed.

Lemma refa561_not4396 : ~ @Equation4396 Fin4 refa561_inst.
Proof. unfold Equation4396. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa561_inst, refa561_op in H. discriminate H. Qed.

Lemma refa561_not4433 : ~ @Equation4433 Fin4 refa561_inst.
Proof. unfold Equation4433. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa561_inst, refa561_op in H. discriminate H. Qed.

Lemma refa561_not4473 : ~ @Equation4473 Fin4 refa561_inst.
Proof. unfold Equation4473. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa561_inst, refa561_op in H. discriminate H. Qed.

Lemma refa561_not4480 : ~ @Equation4480 Fin4 refa561_inst.
Proof. unfold Equation4480. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa561_inst, refa561_op in H. discriminate H. Qed.

Lemma refa561_not4585 : ~ @Equation4585 Fin4 refa561_inst.
Proof. unfold Equation4585. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa561_inst, refa561_op in H. discriminate H. Qed.

Lemma refa561_not4588 : ~ @Equation4588 Fin4 refa561_inst.
Proof. unfold Equation4588. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa561_inst, refa561_op in H. discriminate H. Qed.

Lemma refa561_not4598 : ~ @Equation4598 Fin4 refa561_inst.
Proof. unfold Equation4598. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa561_inst, refa561_op in H. discriminate H. Qed.

Lemma refa561_not4605 : ~ @Equation4605 Fin4 refa561_inst.
Proof. unfold Equation4605. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa561_inst, refa561_op in H. discriminate H. Qed.

(** ---- refa562 (Fin4) ---- *)

Definition refa562_op (x y : Fin4) : Fin4 :=
  match x, y with
  | F4_0, F4_0 => F4_0 | F4_0, F4_1 => F4_1 | F4_0, F4_2 => F4_0 | F4_0, F4_3 => F4_1
  | F4_1, F4_0 => F4_2 | F4_1, F4_1 => F4_1 | F4_1, F4_2 => F4_2 | F4_1, F4_3 => F4_1
  | F4_2, F4_0 => F4_2 | F4_2, F4_1 => F4_3 | F4_2, F4_2 => F4_2 | F4_2, F4_3 => F4_3
  | F4_3, F4_0 => F4_0 | F4_3, F4_1 => F4_3 | F4_3, F4_2 => F4_0 | F4_3, F4_3 => F4_3
  end.

#[local] Instance refa562_inst : Magma Fin4 := {| magma_op := refa562_op |}.

Lemma refa562_sat3718 : @Equation3718 Fin4 refa562_inst.
Proof. unfold Equation3718, magma_op, refa562_inst, refa562_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa562_not4128 : ~ @Equation4128 Fin4 refa562_inst.
Proof. unfold Equation4128. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa562_inst, refa562_op in H. discriminate H. Qed.

(** ---- refa563 (Fin4) ---- *)

Definition refa563_op (x y : Fin4) : Fin4 :=
  match x, y with
  | F4_0, F4_0 => F4_2 | F4_0, F4_1 => F4_3 | F4_0, F4_2 => F4_1 | F4_0, F4_3 => F4_1
  | F4_1, F4_0 => F4_2 | F4_1, F4_1 => F4_0 | F4_1, F4_2 => F4_3 | F4_1, F4_3 => F4_2
  | F4_2, F4_0 => F4_1 | F4_2, F4_1 => F4_0 | F4_2, F4_2 => F4_3 | F4_2, F4_3 => F4_1
  | F4_3, F4_0 => F4_2 | F4_3, F4_1 => F4_0 | F4_3, F4_2 => F4_0 | F4_3, F4_3 => F4_1
  end.

#[local] Instance refa563_inst : Magma Fin4 := {| magma_op := refa563_op |}.

Lemma refa563_sat1681 : @Equation1681 Fin4 refa563_inst.
Proof. unfold Equation1681, magma_op, refa563_inst, refa563_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa563_not1832 : ~ @Equation1832 Fin4 refa563_inst.
Proof. unfold Equation1832. intro H. specialize (H F4_0). unfold magma_op, refa563_inst, refa563_op in H. discriminate H. Qed.

Lemma refa563_not2035 : ~ @Equation2035 Fin4 refa563_inst.
Proof. unfold Equation2035. intro H. specialize (H F4_0). unfold magma_op, refa563_inst, refa563_op in H. discriminate H. Qed.

Lemma refa563_not3253 : ~ @Equation3253 Fin4 refa563_inst.
Proof. unfold Equation3253. intro H. specialize (H F4_0). unfold magma_op, refa563_inst, refa563_op in H. discriminate H. Qed.

Lemma refa563_not4065 : ~ @Equation4065 Fin4 refa563_inst.
Proof. unfold Equation4065. intro H. specialize (H F4_2). unfold magma_op, refa563_inst, refa563_op in H. discriminate H. Qed.

(** ---- refa564 (Fin4) ---- *)

Definition refa564_op (x y : Fin4) : Fin4 :=
  match x, y with
  | F4_0, F4_0 => F4_0 | F4_0, F4_1 => F4_1 | F4_0, F4_2 => F4_1 | F4_0, F4_3 => F4_3
  | F4_1, F4_0 => F4_3 | F4_1, F4_1 => F4_1 | F4_1, F4_2 => F4_2 | F4_1, F4_3 => F4_1
  | F4_2, F4_0 => F4_2 | F4_2, F4_1 => F4_0 | F4_2, F4_2 => F4_2 | F4_2, F4_3 => F4_0
  | F4_3, F4_0 => F4_2 | F4_3, F4_1 => F4_0 | F4_3, F4_2 => F4_3 | F4_3, F4_3 => F4_1
  end.

#[local] Instance refa564_inst : Magma Fin4 := {| magma_op := refa564_op |}.

Lemma refa564_sat1482 : @Equation1482 Fin4 refa564_inst.
Proof. unfold Equation1482, magma_op, refa564_inst, refa564_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa564_not1479 : ~ @Equation1479 Fin4 refa564_inst.
Proof. unfold Equation1479. intro H. specialize (H F4_2 F4_3). unfold magma_op, refa564_inst, refa564_op in H. discriminate H. Qed.

Lemma refa564_not2035 : ~ @Equation2035 Fin4 refa564_inst.
Proof. unfold Equation2035. intro H. specialize (H F4_3). unfold magma_op, refa564_inst, refa564_op in H. discriminate H. Qed.

Lemma refa564_not3456 : ~ @Equation3456 Fin4 refa564_inst.
Proof. unfold Equation3456. intro H. specialize (H F4_3). unfold magma_op, refa564_inst, refa564_op in H. discriminate H. Qed.

Lemma refa564_not3862 : ~ @Equation3862 Fin4 refa564_inst.
Proof. unfold Equation3862. intro H. specialize (H F4_3). unfold magma_op, refa564_inst, refa564_op in H. discriminate H. Qed.

(** ---- refa565 (Fin4) ---- *)

Definition refa565_op (x y : Fin4) : Fin4 :=
  match x, y with
  | F4_0, F4_0 => F4_3 | F4_0, F4_1 => F4_2 | F4_0, F4_2 => F4_0 | F4_0, F4_3 => F4_1
  | F4_1, F4_0 => F4_3 | F4_1, F4_1 => F4_1 | F4_1, F4_2 => F4_1 | F4_1, F4_3 => F4_2
  | F4_2, F4_0 => F4_1 | F4_2, F4_1 => F4_2 | F4_2, F4_2 => F4_0 | F4_2, F4_3 => F4_0
  | F4_3, F4_0 => F4_1 | F4_3, F4_1 => F4_3 | F4_3, F4_2 => F4_2 | F4_3, F4_3 => F4_2
  end.

#[local] Instance refa565_inst : Magma Fin4 := {| magma_op := refa565_op |}.

Lemma refa565_sat640 : @Equation640 Fin4 refa565_inst.
Proof. unfold Equation640, magma_op, refa565_inst, refa565_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa565_not47 : ~ @Equation47 Fin4 refa565_inst.
Proof. unfold Equation47. intro H. specialize (H F4_0). unfold magma_op, refa565_inst, refa565_op in H. discriminate H. Qed.

Lemma refa565_not630 : ~ @Equation630 Fin4 refa565_inst.
Proof. unfold Equation630. intro H. specialize (H F4_0 F4_2). unfold magma_op, refa565_inst, refa565_op in H. discriminate H. Qed.

Lemma refa565_not643 : ~ @Equation643 Fin4 refa565_inst.
Proof. unfold Equation643. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa565_inst, refa565_op in H. discriminate H. Qed.

Lemma refa565_not817 : ~ @Equation817 Fin4 refa565_inst.
Proof. unfold Equation817. intro H. specialize (H F4_2). unfold magma_op, refa565_inst, refa565_op in H. discriminate H. Qed.

Lemma refa565_not4065 : ~ @Equation4065 Fin4 refa565_inst.
Proof. unfold Equation4065. intro H. specialize (H F4_3). unfold magma_op, refa565_inst, refa565_op in H. discriminate H. Qed.

(** ---- refa566 (Fin4) ---- *)

Definition refa566_op (x y : Fin4) : Fin4 :=
  match x, y with
  | F4_0, F4_0 => F4_2 | F4_0, F4_1 => F4_1 | F4_0, F4_2 => F4_0 | F4_0, F4_3 => F4_1
  | F4_1, F4_0 => F4_3 | F4_1, F4_1 => F4_1 | F4_1, F4_2 => F4_0 | F4_1, F4_3 => F4_2
  | F4_2, F4_0 => F4_1 | F4_2, F4_1 => F4_0 | F4_2, F4_2 => F4_3 | F4_2, F4_3 => F4_2
  | F4_3, F4_0 => F4_0 | F4_3, F4_1 => F4_3 | F4_3, F4_2 => F4_1 | F4_3, F4_3 => F4_0
  end.

#[local] Instance refa566_inst : Magma Fin4 := {| magma_op := refa566_op |}.

Lemma refa566_sat2134 : @Equation2134 Fin4 refa566_inst.
Proof. unfold Equation2134, magma_op, refa566_inst, refa566_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa566_not1832 : ~ @Equation1832 Fin4 refa566_inst.
Proof. unfold Equation1832. intro H. specialize (H F4_3). unfold magma_op, refa566_inst, refa566_op in H. discriminate H. Qed.

Lemma refa566_not2050 : ~ @Equation2050 Fin4 refa566_inst.
Proof. unfold Equation2050. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa566_inst, refa566_op in H. discriminate H. Qed.

Lemma refa566_not2053 : ~ @Equation2053 Fin4 refa566_inst.
Proof. unfold Equation2053. intro H. specialize (H F4_1 F4_0). unfold magma_op, refa566_inst, refa566_op in H. discriminate H. Qed.

Lemma refa566_not2087 : ~ @Equation2087 Fin4 refa566_inst.
Proof. unfold Equation2087. intro H. specialize (H F4_0 F4_2). unfold magma_op, refa566_inst, refa566_op in H. discriminate H. Qed.

Lemma refa566_not2124 : ~ @Equation2124 Fin4 refa566_inst.
Proof. unfold Equation2124. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa566_inst, refa566_op in H. discriminate H. Qed.

Lemma refa566_not2127 : ~ @Equation2127 Fin4 refa566_inst.
Proof. unfold Equation2127. intro H. specialize (H F4_0 F4_2). unfold magma_op, refa566_inst, refa566_op in H. discriminate H. Qed.

Lemma refa566_not3258 : ~ @Equation3258 Fin4 refa566_inst.
Proof. unfold Equation3258. intro H. specialize (H F4_0 F4_2). unfold magma_op, refa566_inst, refa566_op in H. discriminate H. Qed.

Lemma refa566_not3261 : ~ @Equation3261 Fin4 refa566_inst.
Proof. unfold Equation3261. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa566_inst, refa566_op in H. discriminate H. Qed.

Lemma refa566_not3306 : ~ @Equation3306 Fin4 refa566_inst.
Proof. unfold Equation3306. intro H. specialize (H F4_1 F4_0). unfold magma_op, refa566_inst, refa566_op in H. discriminate H. Qed.

Lemma refa566_not3309 : ~ @Equation3309 Fin4 refa566_inst.
Proof. unfold Equation3309. intro H. specialize (H F4_0 F4_2). unfold magma_op, refa566_inst, refa566_op in H. discriminate H. Qed.

Lemma refa566_not3353 : ~ @Equation3353 Fin4 refa566_inst.
Proof. unfold Equation3353. intro H. specialize (H F4_0 F4_3). unfold magma_op, refa566_inst, refa566_op in H. discriminate H. Qed.

Lemma refa566_not3456 : ~ @Equation3456 Fin4 refa566_inst.
Proof. unfold Equation3456. intro H. specialize (H F4_0). unfold magma_op, refa566_inst, refa566_op in H. discriminate H. Qed.

Lemma refa566_not3877 : ~ @Equation3877 Fin4 refa566_inst.
Proof. unfold Equation3877. intro H. specialize (H F4_0 F4_2). unfold magma_op, refa566_inst, refa566_op in H. discriminate H. Qed.

Lemma refa566_not3887 : ~ @Equation3887 Fin4 refa566_inst.
Proof. unfold Equation3887. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa566_inst, refa566_op in H. discriminate H. Qed.

Lemma refa566_not3955 : ~ @Equation3955 Fin4 refa566_inst.
Proof. unfold Equation3955. intro H. specialize (H F4_0 F4_3). unfold magma_op, refa566_inst, refa566_op in H. discriminate H. Qed.

Lemma refa566_not3962 : ~ @Equation3962 Fin4 refa566_inst.
Proof. unfold Equation3962. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa566_inst, refa566_op in H. discriminate H. Qed.

Lemma refa566_not4067 : ~ @Equation4067 Fin4 refa566_inst.
Proof. unfold Equation4067. intro H. specialize (H F4_0 F4_0). unfold magma_op, refa566_inst, refa566_op in H. discriminate H. Qed.

Lemma refa566_not4083 : ~ @Equation4083 Fin4 refa566_inst.
Proof. unfold Equation4083. intro H. specialize (H F4_0 F4_0). unfold magma_op, refa566_inst, refa566_op in H. discriminate H. Qed.

Lemma refa566_not4121 : ~ @Equation4121 Fin4 refa566_inst.
Proof. unfold Equation4121. intro H. specialize (H F4_0 F4_0). unfold magma_op, refa566_inst, refa566_op in H. discriminate H. Qed.

Lemma refa566_not4158 : ~ @Equation4158 Fin4 refa566_inst.
Proof. unfold Equation4158. intro H. specialize (H F4_0 F4_0). unfold magma_op, refa566_inst, refa566_op in H. discriminate H. Qed.

Lemma refa566_not4284 : ~ @Equation4284 Fin4 refa566_inst.
Proof. unfold Equation4284. intro H. specialize (H F4_0 F4_2). unfold magma_op, refa566_inst, refa566_op in H. discriminate H. Qed.

Lemma refa566_not4380 : ~ @Equation4380 Fin4 refa566_inst.
Proof. unfold Equation4380. intro H. specialize (H F4_0). unfold magma_op, refa566_inst, refa566_op in H. discriminate H. Qed.

Lemma refa566_not4599 : ~ @Equation4599 Fin4 refa566_inst.
Proof. unfold Equation4599. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa566_inst, refa566_op in H. discriminate H. Qed.

Lemma refa566_not4635 : ~ @Equation4635 Fin4 refa566_inst.
Proof. unfold Equation4635. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa566_inst, refa566_op in H. discriminate H. Qed.

(** ---- refa567 (Fin4) ---- *)

Definition refa567_op (x y : Fin4) : Fin4 :=
  match x, y with
  | F4_0, F4_0 => F4_0 | F4_0, F4_1 => F4_2 | F4_0, F4_2 => F4_3 | F4_0, F4_3 => F4_3
  | F4_1, F4_0 => F4_3 | F4_1, F4_1 => F4_1 | F4_1, F4_2 => F4_2 | F4_1, F4_3 => F4_0
  | F4_2, F4_0 => F4_0 | F4_2, F4_1 => F4_2 | F4_2, F4_2 => F4_1 | F4_2, F4_3 => F4_3
  | F4_3, F4_0 => F4_3 | F4_3, F4_1 => F4_1 | F4_3, F4_2 => F4_2 | F4_3, F4_3 => F4_0
  end.

#[local] Instance refa567_inst : Magma Fin4 := {| magma_op := refa567_op |}.

Lemma refa567_sat1488 : @Equation1488 Fin4 refa567_inst.
Proof. unfold Equation1488, magma_op, refa567_inst, refa567_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa567_not639 : ~ @Equation639 Fin4 refa567_inst.
Proof. unfold Equation639. intro H. specialize (H F4_1 F4_0). unfold magma_op, refa567_inst, refa567_op in H. discriminate H. Qed.

Lemma refa567_not676 : ~ @Equation676 Fin4 refa567_inst.
Proof. unfold Equation676. intro H. specialize (H F4_1 F4_0). unfold magma_op, refa567_inst, refa567_op in H. discriminate H. Qed.

Lemma refa567_not703 : ~ @Equation703 Fin4 refa567_inst.
Proof. unfold Equation703. intro H. specialize (H F4_1 F4_0). unfold magma_op, refa567_inst, refa567_op in H. discriminate H. Qed.

(** ---- refa568 (Fin4) ---- *)

Definition refa568_op (x y : Fin4) : Fin4 :=
  match x, y with
  | F4_0, F4_0 => F4_3 | F4_0, F4_1 => F4_0 | F4_0, F4_2 => F4_1 | F4_0, F4_3 => F4_3
  | F4_1, F4_0 => F4_3 | F4_1, F4_1 => F4_3 | F4_1, F4_2 => F4_0 | F4_1, F4_3 => F4_3
  | F4_2, F4_0 => F4_2 | F4_2, F4_1 => F4_2 | F4_2, F4_2 => F4_3 | F4_2, F4_3 => F4_3
  | F4_3, F4_0 => F4_3 | F4_3, F4_1 => F4_3 | F4_3, F4_2 => F4_3 | F4_3, F4_3 => F4_3
  end.

#[local] Instance refa568_inst : Magma Fin4 := {| magma_op := refa568_op |}.

Lemma refa568_sat3283 : @Equation3283 Fin4 refa568_inst.
Proof. unfold Equation3283, magma_op, refa568_inst, refa568_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa568_not3255 : ~ @Equation3255 Fin4 refa568_inst.
Proof. unfold Equation3255. intro H. specialize (H F4_0 F4_2). unfold magma_op, refa568_inst, refa568_op in H. discriminate H. Qed.

Lemma refa568_not3279 : ~ @Equation3279 Fin4 refa568_inst.
Proof. unfold Equation3279. intro H. specialize (H F4_2 F4_0). unfold magma_op, refa568_inst, refa568_op in H. discriminate H. Qed.

(** ---- refa569 (Fin4) ---- *)

Definition refa569_op (x y : Fin4) : Fin4 :=
  match x, y with
  | F4_0, F4_0 => F4_2 | F4_0, F4_1 => F4_0 | F4_0, F4_2 => F4_1 | F4_0, F4_3 => F4_1
  | F4_1, F4_0 => F4_3 | F4_1, F4_1 => F4_0 | F4_1, F4_2 => F4_3 | F4_1, F4_3 => F4_1
  | F4_2, F4_0 => F4_2 | F4_2, F4_1 => F4_0 | F4_2, F4_2 => F4_3 | F4_2, F4_3 => F4_0
  | F4_3, F4_0 => F4_2 | F4_3, F4_1 => F4_2 | F4_3, F4_2 => F4_3 | F4_3, F4_3 => F4_1
  end.

#[local] Instance refa569_inst : Magma Fin4 := {| magma_op := refa569_op |}.

Lemma refa569_sat1447 : @Equation1447 Fin4 refa569_inst.
Proof. unfold Equation1447, magma_op, refa569_inst, refa569_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa569_not4118 : ~ @Equation4118 Fin4 refa569_inst.
Proof. unfold Equation4118. intro H. specialize (H F4_0 F4_2). unfold magma_op, refa569_inst, refa569_op in H. discriminate H. Qed.

Lemma refa569_not4128 : ~ @Equation4128 Fin4 refa569_inst.
Proof. unfold Equation4128. intro H. specialize (H F4_0 F4_2). unfold magma_op, refa569_inst, refa569_op in H. discriminate H. Qed.

Lemma refa569_not4131 : ~ @Equation4131 Fin4 refa569_inst.
Proof. unfold Equation4131. intro H. specialize (H F4_0 F4_2). unfold magma_op, refa569_inst, refa569_op in H. discriminate H. Qed.

Lemma refa569_not4284 : ~ @Equation4284 Fin4 refa569_inst.
Proof. unfold Equation4284. intro H. specialize (H F4_0 F4_2). unfold magma_op, refa569_inst, refa569_op in H. discriminate H. Qed.

(** ---- refa57 (Fin3) ---- *)

Definition refa57_op (x y : Fin3) : Fin3 :=
  match x, y with
  | F3_0, F3_0 => F3_0 | F3_0, F3_1 => F3_1 | F3_0, F3_2 => F3_2
  | F3_1, F3_0 => F3_1 | F3_1, F3_1 => F3_0 | F3_1, F3_2 => F3_0
  | F3_2, F3_0 => F3_2 | F3_2, F3_1 => F3_2 | F3_2, F3_2 => F3_0
  end.

#[local] Instance refa57_inst : Magma Fin3 := {| magma_op := refa57_op |}.

Lemma refa57_sat647 : @Equation647 Fin3 refa57_inst.
Proof. unfold Equation647, magma_op, refa57_inst, refa57_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa57_sat658 : @Equation658 Fin3 refa57_inst.
Proof. unfold Equation658, magma_op, refa57_inst, refa57_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa57_sat1023 : @Equation1023 Fin3 refa57_inst.
Proof. unfold Equation1023, magma_op, refa57_inst, refa57_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa57_sat1256 : @Equation1256 Fin3 refa57_inst.
Proof. unfold Equation1256, magma_op, refa57_inst, refa57_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa57_sat1519 : @Equation1519 Fin3 refa57_inst.
Proof. unfold Equation1519, magma_op, refa57_inst, refa57_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa57_sat2051 : @Equation2051 Fin3 refa57_inst.
Proof. unfold Equation2051, magma_op, refa57_inst, refa57_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa57_sat2128 : @Equation2128 Fin3 refa57_inst.
Proof. unfold Equation2128, magma_op, refa57_inst, refa57_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa57_sat2355 : @Equation2355 Fin3 refa57_inst.
Proof. unfold Equation2355, magma_op, refa57_inst, refa57_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa57_sat3489 : @Equation3489 Fin3 refa57_inst.
Proof. unfold Equation3489, magma_op, refa57_inst, refa57_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa57_sat4398 : @Equation4398 Fin3 refa57_inst.
Proof. unfold Equation4398, magma_op, refa57_inst, refa57_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa57_sat4497 : @Equation4497 Fin3 refa57_inst.
Proof. unfold Equation4497, magma_op, refa57_inst, refa57_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa57_not417 : ~ @Equation417 Fin3 refa57_inst.
Proof. unfold Equation417. intro H. specialize (H F3_2 F3_1). unfold magma_op, refa57_inst, refa57_op in H. discriminate H. Qed.

Lemma refa57_not419 : ~ @Equation419 Fin3 refa57_inst.
Proof. unfold Equation419. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa57_inst, refa57_op in H. discriminate H. Qed.

Lemma refa57_not427 : ~ @Equation427 Fin3 refa57_inst.
Proof. unfold Equation427. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa57_inst, refa57_op in H. discriminate H. Qed.

Lemma refa57_not429 : ~ @Equation429 Fin3 refa57_inst.
Proof. unfold Equation429. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa57_inst, refa57_op in H. discriminate H. Qed.

Lemma refa57_not430 : ~ @Equation430 Fin3 refa57_inst.
Proof. unfold Equation430. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa57_inst, refa57_op in H. discriminate H. Qed.

Lemma refa57_not437 : ~ @Equation437 Fin3 refa57_inst.
Proof. unfold Equation437. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa57_inst, refa57_op in H. discriminate H. Qed.

Lemma refa57_not439 : ~ @Equation439 Fin3 refa57_inst.
Proof. unfold Equation439. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa57_inst, refa57_op in H. discriminate H. Qed.

Lemma refa57_not620 : ~ @Equation620 Fin3 refa57_inst.
Proof. unfold Equation620. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa57_inst, refa57_op in H. discriminate H. Qed.

Lemma refa57_not632 : ~ @Equation632 Fin3 refa57_inst.
Proof. unfold Equation632. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa57_inst, refa57_op in H. discriminate H. Qed.

Lemma refa57_not669 : ~ @Equation669 Fin3 refa57_inst.
Proof. unfold Equation669. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa57_inst, refa57_op in H. discriminate H. Qed.

Lemma refa57_not676 : ~ @Equation676 Fin3 refa57_inst.
Proof. unfold Equation676. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa57_inst, refa57_op in H. discriminate H. Qed.

Lemma refa57_not680 : ~ @Equation680 Fin3 refa57_inst.
Proof. unfold Equation680. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa57_inst, refa57_op in H. discriminate H. Qed.

Lemma refa57_not707 : ~ @Equation707 Fin3 refa57_inst.
Proof. unfold Equation707. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa57_inst, refa57_op in H. discriminate H. Qed.

Lemma refa57_not716 : ~ @Equation716 Fin3 refa57_inst.
Proof. unfold Equation716. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa57_inst, refa57_op in H. discriminate H. Qed.

Lemma refa57_not818 : ~ @Equation818 Fin3 refa57_inst.
Proof. unfold Equation818. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa57_inst, refa57_op in H. discriminate H. Qed.

Lemma refa57_not819 : ~ @Equation819 Fin3 refa57_inst.
Proof. unfold Equation819. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa57_inst, refa57_op in H. discriminate H. Qed.

Lemma refa57_not825 : ~ @Equation825 Fin3 refa57_inst.
Proof. unfold Equation825. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa57_inst, refa57_op in H. discriminate H. Qed.

Lemma refa57_not832 : ~ @Equation832 Fin3 refa57_inst.
Proof. unfold Equation832. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa57_inst, refa57_op in H. discriminate H. Qed.

Lemma refa57_not833 : ~ @Equation833 Fin3 refa57_inst.
Proof. unfold Equation833. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa57_inst, refa57_op in H. discriminate H. Qed.

Lemma refa57_not836 : ~ @Equation836 Fin3 refa57_inst.
Proof. unfold Equation836. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa57_inst, refa57_op in H. discriminate H. Qed.

Lemma refa57_not843 : ~ @Equation843 Fin3 refa57_inst.
Proof. unfold Equation843. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa57_inst, refa57_op in H. discriminate H. Qed.

Lemma refa57_not845 : ~ @Equation845 Fin3 refa57_inst.
Proof. unfold Equation845. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa57_inst, refa57_op in H. discriminate H. Qed.

Lemma refa57_not1022 : ~ @Equation1022 Fin3 refa57_inst.
Proof. unfold Equation1022. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa57_inst, refa57_op in H. discriminate H. Qed.

Lemma refa57_not1025 : ~ @Equation1025 Fin3 refa57_inst.
Proof. unfold Equation1025. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa57_inst, refa57_op in H. discriminate H. Qed.

Lemma refa57_not1026 : ~ @Equation1026 Fin3 refa57_inst.
Proof. unfold Equation1026. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa57_inst, refa57_op in H. discriminate H. Qed.

Lemma refa57_not1035 : ~ @Equation1035 Fin3 refa57_inst.
Proof. unfold Equation1035. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa57_inst, refa57_op in H. discriminate H. Qed.

Lemma refa57_not1038 : ~ @Equation1038 Fin3 refa57_inst.
Proof. unfold Equation1038. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa57_inst, refa57_op in H. discriminate H. Qed.

Lemma refa57_not1039 : ~ @Equation1039 Fin3 refa57_inst.
Proof. unfold Equation1039. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa57_inst, refa57_op in H. discriminate H. Qed.

Lemma refa57_not1045 : ~ @Equation1045 Fin3 refa57_inst.
Proof. unfold Equation1045. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa57_inst, refa57_op in H. discriminate H. Qed.

Lemma refa57_not1046 : ~ @Equation1046 Fin3 refa57_inst.
Proof. unfold Equation1046. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa57_inst, refa57_op in H. discriminate H. Qed.

Lemma refa57_not1048 : ~ @Equation1048 Fin3 refa57_inst.
Proof. unfold Equation1048. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa57_inst, refa57_op in H. discriminate H. Qed.

Lemma refa57_not1113 : ~ @Equation1113 Fin3 refa57_inst.
Proof. unfold Equation1113. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa57_inst, refa57_op in H. discriminate H. Qed.

Lemma refa57_not1224 : ~ @Equation1224 Fin3 refa57_inst.
Proof. unfold Equation1224. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa57_inst, refa57_op in H. discriminate H. Qed.

Lemma refa57_not1225 : ~ @Equation1225 Fin3 refa57_inst.
Proof. unfold Equation1225. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa57_inst, refa57_op in H. discriminate H. Qed.

Lemma refa57_not1228 : ~ @Equation1228 Fin3 refa57_inst.
Proof. unfold Equation1228. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa57_inst, refa57_op in H. discriminate H. Qed.

Lemma refa57_not1231 : ~ @Equation1231 Fin3 refa57_inst.
Proof. unfold Equation1231. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa57_inst, refa57_op in H. discriminate H. Qed.

Lemma refa57_not1238 : ~ @Equation1238 Fin3 refa57_inst.
Proof. unfold Equation1238. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa57_inst, refa57_op in H. discriminate H. Qed.

Lemma refa57_not1239 : ~ @Equation1239 Fin3 refa57_inst.
Proof. unfold Equation1239. intro H. specialize (H F3_2 F3_1). unfold magma_op, refa57_inst, refa57_op in H. discriminate H. Qed.

Lemma refa57_not1241 : ~ @Equation1241 Fin3 refa57_inst.
Proof. unfold Equation1241. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa57_inst, refa57_op in H. discriminate H. Qed.

Lemma refa57_not1242 : ~ @Equation1242 Fin3 refa57_inst.
Proof. unfold Equation1242. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa57_inst, refa57_op in H. discriminate H. Qed.

Lemma refa57_not1249 : ~ @Equation1249 Fin3 refa57_inst.
Proof. unfold Equation1249. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa57_inst, refa57_op in H. discriminate H. Qed.

Lemma refa57_not1251 : ~ @Equation1251 Fin3 refa57_inst.
Proof. unfold Equation1251. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa57_inst, refa57_op in H. discriminate H. Qed.

Lemma refa57_not1289 : ~ @Equation1289 Fin3 refa57_inst.
Proof. unfold Equation1289. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa57_inst, refa57_op in H. discriminate H. Qed.

Lemma refa57_not1479 : ~ @Equation1479 Fin3 refa57_inst.
Proof. unfold Equation1479. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa57_inst, refa57_op in H. discriminate H. Qed.

Lemma refa57_not1632 : ~ @Equation1632 Fin3 refa57_inst.
Proof. unfold Equation1632. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa57_inst, refa57_op in H. discriminate H. Qed.

Lemma refa57_not1635 : ~ @Equation1635 Fin3 refa57_inst.
Proof. unfold Equation1635. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa57_inst, refa57_op in H. discriminate H. Qed.

Lemma refa57_not1654 : ~ @Equation1654 Fin3 refa57_inst.
Proof. unfold Equation1654. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa57_inst, refa57_op in H. discriminate H. Qed.

Lemma refa57_not1684 : ~ @Equation1684 Fin3 refa57_inst.
Proof. unfold Equation1684. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa57_inst, refa57_op in H. discriminate H. Qed.

Lemma refa57_not1691 : ~ @Equation1691 Fin3 refa57_inst.
Proof. unfold Equation1691. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa57_inst, refa57_op in H. discriminate H. Qed.

Lemma refa57_not1834 : ~ @Equation1834 Fin3 refa57_inst.
Proof. unfold Equation1834. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa57_inst, refa57_op in H. discriminate H. Qed.

Lemma refa57_not1840 : ~ @Equation1840 Fin3 refa57_inst.
Proof. unfold Equation1840. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa57_inst, refa57_op in H. discriminate H. Qed.

Lemma refa57_not1847 : ~ @Equation1847 Fin3 refa57_inst.
Proof. unfold Equation1847. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa57_inst, refa57_op in H. discriminate H. Qed.

Lemma refa57_not1848 : ~ @Equation1848 Fin3 refa57_inst.
Proof. unfold Equation1848. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa57_inst, refa57_op in H. discriminate H. Qed.

Lemma refa57_not1850 : ~ @Equation1850 Fin3 refa57_inst.
Proof. unfold Equation1850. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa57_inst, refa57_op in H. discriminate H. Qed.

Lemma refa57_not1851 : ~ @Equation1851 Fin3 refa57_inst.
Proof. unfold Equation1851. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa57_inst, refa57_op in H. discriminate H. Qed.

Lemma refa57_not1860 : ~ @Equation1860 Fin3 refa57_inst.
Proof. unfold Equation1860. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa57_inst, refa57_op in H. discriminate H. Qed.

Lemma refa57_not1894 : ~ @Equation1894 Fin3 refa57_inst.
Proof. unfold Equation1894. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa57_inst, refa57_op in H. discriminate H. Qed.

Lemma refa57_not1921 : ~ @Equation1921 Fin3 refa57_inst.
Proof. unfold Equation1921. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa57_inst, refa57_op in H. discriminate H. Qed.

Lemma refa57_not1934 : ~ @Equation1934 Fin3 refa57_inst.
Proof. unfold Equation1934. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa57_inst, refa57_op in H. discriminate H. Qed.

Lemma refa57_not2053 : ~ @Equation2053 Fin3 refa57_inst.
Proof. unfold Equation2053. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa57_inst, refa57_op in H. discriminate H. Qed.

Lemma refa57_not2060 : ~ @Equation2060 Fin3 refa57_inst.
Proof. unfold Equation2060. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa57_inst, refa57_op in H. discriminate H. Qed.

Lemma refa57_not2088 : ~ @Equation2088 Fin3 refa57_inst.
Proof. unfold Equation2088. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa57_inst, refa57_op in H. discriminate H. Qed.

Lemma refa57_not2090 : ~ @Equation2090 Fin3 refa57_inst.
Proof. unfold Equation2090. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa57_inst, refa57_op in H. discriminate H. Qed.

Lemma refa57_not2097 : ~ @Equation2097 Fin3 refa57_inst.
Proof. unfold Equation2097. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa57_inst, refa57_op in H. discriminate H. Qed.

Lemma refa57_not2137 : ~ @Equation2137 Fin3 refa57_inst.
Proof. unfold Equation2137. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa57_inst, refa57_op in H. discriminate H. Qed.

Lemma refa57_not2241 : ~ @Equation2241 Fin3 refa57_inst.
Proof. unfold Equation2241. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa57_inst, refa57_op in H. discriminate H. Qed.

Lemma refa57_not2244 : ~ @Equation2244 Fin3 refa57_inst.
Proof. unfold Equation2244. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa57_inst, refa57_op in H. discriminate H. Qed.

Lemma refa57_not2256 : ~ @Equation2256 Fin3 refa57_inst.
Proof. unfold Equation2256. intro H. specialize (H F3_2 F3_1). unfold magma_op, refa57_inst, refa57_op in H. discriminate H. Qed.

Lemma refa57_not2263 : ~ @Equation2263 Fin3 refa57_inst.
Proof. unfold Equation2263. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa57_inst, refa57_op in H. discriminate H. Qed.

Lemma refa57_not2267 : ~ @Equation2267 Fin3 refa57_inst.
Proof. unfold Equation2267. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa57_inst, refa57_op in H. discriminate H. Qed.

Lemma refa57_not2291 : ~ @Equation2291 Fin3 refa57_inst.
Proof. unfold Equation2291. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa57_inst, refa57_op in H. discriminate H. Qed.

Lemma refa57_not2293 : ~ @Equation2293 Fin3 refa57_inst.
Proof. unfold Equation2293. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa57_inst, refa57_op in H. discriminate H. Qed.

Lemma refa57_not2300 : ~ @Equation2300 Fin3 refa57_inst.
Proof. unfold Equation2300. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa57_inst, refa57_op in H. discriminate H. Qed.

Lemma refa57_not2338 : ~ @Equation2338 Fin3 refa57_inst.
Proof. unfold Equation2338. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa57_inst, refa57_op in H. discriminate H. Qed.

Lemma refa57_not2447 : ~ @Equation2447 Fin3 refa57_inst.
Proof. unfold Equation2447. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa57_inst, refa57_op in H. discriminate H. Qed.

Lemma refa57_not2457 : ~ @Equation2457 Fin3 refa57_inst.
Proof. unfold Equation2457. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa57_inst, refa57_op in H. discriminate H. Qed.

Lemma refa57_not2470 : ~ @Equation2470 Fin3 refa57_inst.
Proof. unfold Equation2470. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa57_inst, refa57_op in H. discriminate H. Qed.

Lemma refa57_not2534 : ~ @Equation2534 Fin3 refa57_inst.
Proof. unfold Equation2534. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa57_inst, refa57_op in H. discriminate H. Qed.

Lemma refa57_not2853 : ~ @Equation2853 Fin3 refa57_inst.
Proof. unfold Equation2853. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa57_inst, refa57_op in H. discriminate H. Qed.

Lemma refa57_not2863 : ~ @Equation2863 Fin3 refa57_inst.
Proof. unfold Equation2863. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa57_inst, refa57_op in H. discriminate H. Qed.

Lemma refa57_not2909 : ~ @Equation2909 Fin3 refa57_inst.
Proof. unfold Equation2909. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa57_inst, refa57_op in H. discriminate H. Qed.

Lemma refa57_not2936 : ~ @Equation2936 Fin3 refa57_inst.
Proof. unfold Equation2936. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa57_inst, refa57_op in H. discriminate H. Qed.

Lemma refa57_not2940 : ~ @Equation2940 Fin3 refa57_inst.
Proof. unfold Equation2940. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa57_inst, refa57_op in H. discriminate H. Qed.

Lemma refa57_not2947 : ~ @Equation2947 Fin3 refa57_inst.
Proof. unfold Equation2947. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa57_inst, refa57_op in H. discriminate H. Qed.

Lemma refa57_not3103 : ~ @Equation3103 Fin3 refa57_inst.
Proof. unfold Equation3103. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa57_inst, refa57_op in H. discriminate H. Qed.

Lemma refa57_not3112 : ~ @Equation3112 Fin3 refa57_inst.
Proof. unfold Equation3112. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa57_inst, refa57_op in H. discriminate H. Qed.

Lemma refa57_not3116 : ~ @Equation3116 Fin3 refa57_inst.
Proof. unfold Equation3116. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa57_inst, refa57_op in H. discriminate H. Qed.

Lemma refa57_not3150 : ~ @Equation3150 Fin3 refa57_inst.
Proof. unfold Equation3150. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa57_inst, refa57_op in H. discriminate H. Qed.

Lemma refa57_not3255 : ~ @Equation3255 Fin3 refa57_inst.
Proof. unfold Equation3255. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa57_inst, refa57_op in H. discriminate H. Qed.

Lemma refa57_not3259 : ~ @Equation3259 Fin3 refa57_inst.
Proof. unfold Equation3259. intro H. specialize (H F3_2 F3_1). unfold magma_op, refa57_inst, refa57_op in H. discriminate H. Qed.

Lemma refa57_not3261 : ~ @Equation3261 Fin3 refa57_inst.
Proof. unfold Equation3261. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa57_inst, refa57_op in H. discriminate H. Qed.

Lemma refa57_not3269 : ~ @Equation3269 Fin3 refa57_inst.
Proof. unfold Equation3269. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa57_inst, refa57_op in H. discriminate H. Qed.

Lemma refa57_not3308 : ~ @Equation3308 Fin3 refa57_inst.
Proof. unfold Equation3308. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa57_inst, refa57_op in H. discriminate H. Qed.

Lemma refa57_not3316 : ~ @Equation3316 Fin3 refa57_inst.
Proof. unfold Equation3316. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa57_inst, refa57_op in H. discriminate H. Qed.

Lemma refa57_not3318 : ~ @Equation3318 Fin3 refa57_inst.
Proof. unfold Equation3318. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa57_inst, refa57_op in H. discriminate H. Qed.

Lemma refa57_not3342 : ~ @Equation3342 Fin3 refa57_inst.
Proof. unfold Equation3342. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa57_inst, refa57_op in H. discriminate H. Qed.

Lemma refa57_not3353 : ~ @Equation3353 Fin3 refa57_inst.
Proof. unfold Equation3353. intro H. specialize (H F3_2 F3_1). unfold magma_op, refa57_inst, refa57_op in H. discriminate H. Qed.

Lemma refa57_not3462 : ~ @Equation3462 Fin3 refa57_inst.
Proof. unfold Equation3462. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa57_inst, refa57_op in H. discriminate H. Qed.

Lemma refa57_not3518 : ~ @Equation3518 Fin3 refa57_inst.
Proof. unfold Equation3518. intro H. specialize (H F3_2 F3_1). unfold magma_op, refa57_inst, refa57_op in H. discriminate H. Qed.

Lemma refa57_not3545 : ~ @Equation3545 Fin3 refa57_inst.
Proof. unfold Equation3545. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa57_inst, refa57_op in H. discriminate H. Qed.

Lemma refa57_not3549 : ~ @Equation3549 Fin3 refa57_inst.
Proof. unfold Equation3549. intro H. specialize (H F3_2 F3_1). unfold magma_op, refa57_inst, refa57_op in H. discriminate H. Qed.

Lemma refa57_not3556 : ~ @Equation3556 Fin3 refa57_inst.
Proof. unfold Equation3556. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa57_inst, refa57_op in H. discriminate H. Qed.

Lemma refa57_not3660 : ~ @Equation3660 Fin3 refa57_inst.
Proof. unfold Equation3660. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa57_inst, refa57_op in H. discriminate H. Qed.

Lemma refa57_not3661 : ~ @Equation3661 Fin3 refa57_inst.
Proof. unfold Equation3661. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa57_inst, refa57_op in H. discriminate H. Qed.

Lemma refa57_not3667 : ~ @Equation3667 Fin3 refa57_inst.
Proof. unfold Equation3667. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa57_inst, refa57_op in H. discriminate H. Qed.

Lemma refa57_not3675 : ~ @Equation3675 Fin3 refa57_inst.
Proof. unfold Equation3675. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa57_inst, refa57_op in H. discriminate H. Qed.

Lemma refa57_not3724 : ~ @Equation3724 Fin3 refa57_inst.
Proof. unfold Equation3724. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa57_inst, refa57_op in H. discriminate H. Qed.

Lemma refa57_not3864 : ~ @Equation3864 Fin3 refa57_inst.
Proof. unfold Equation3864. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa57_inst, refa57_op in H. discriminate H. Qed.

Lemma refa57_not3865 : ~ @Equation3865 Fin3 refa57_inst.
Proof. unfold Equation3865. intro H. specialize (H F3_2 F3_1). unfold magma_op, refa57_inst, refa57_op in H. discriminate H. Qed.

Lemma refa57_not3868 : ~ @Equation3868 Fin3 refa57_inst.
Proof. unfold Equation3868. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa57_inst, refa57_op in H. discriminate H. Qed.

Lemma refa57_not3880 : ~ @Equation3880 Fin3 refa57_inst.
Proof. unfold Equation3880. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa57_inst, refa57_op in H. discriminate H. Qed.

Lemma refa57_not3887 : ~ @Equation3887 Fin3 refa57_inst.
Proof. unfold Equation3887. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa57_inst, refa57_op in H. discriminate H. Qed.

Lemma refa57_not3925 : ~ @Equation3925 Fin3 refa57_inst.
Proof. unfold Equation3925. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa57_inst, refa57_op in H. discriminate H. Qed.

Lemma refa57_not3964 : ~ @Equation3964 Fin3 refa57_inst.
Proof. unfold Equation3964. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa57_inst, refa57_op in H. discriminate H. Qed.

Lemma refa57_not3994 : ~ @Equation3994 Fin3 refa57_inst.
Proof. unfold Equation3994. intro H. specialize (H F3_0 F3_1 F3_2). unfold magma_op, refa57_inst, refa57_op in H. discriminate H. Qed.

Lemma refa57_not4071 : ~ @Equation4071 Fin3 refa57_inst.
Proof. unfold Equation4071. intro H. specialize (H F3_2 F3_1). unfold magma_op, refa57_inst, refa57_op in H. discriminate H. Qed.

Lemma refa57_not4073 : ~ @Equation4073 Fin3 refa57_inst.
Proof. unfold Equation4073. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa57_inst, refa57_op in H. discriminate H. Qed.

Lemma refa57_not4081 : ~ @Equation4081 Fin3 refa57_inst.
Proof. unfold Equation4081. intro H. specialize (H F3_2 F3_1). unfold magma_op, refa57_inst, refa57_op in H. discriminate H. Qed.

Lemma refa57_not4083 : ~ @Equation4083 Fin3 refa57_inst.
Proof. unfold Equation4083. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa57_inst, refa57_op in H. discriminate H. Qed.

Lemma refa57_not4135 : ~ @Equation4135 Fin3 refa57_inst.
Proof. unfold Equation4135. intro H. specialize (H F3_0 F3_1 F3_2). unfold magma_op, refa57_inst, refa57_op in H. discriminate H. Qed.

Lemma refa57_not4158 : ~ @Equation4158 Fin3 refa57_inst.
Proof. unfold Equation4158. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa57_inst, refa57_op in H. discriminate H. Qed.

Lemma refa57_not4167 : ~ @Equation4167 Fin3 refa57_inst.
Proof. unfold Equation4167. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa57_inst, refa57_op in H. discriminate H. Qed.

Lemma refa57_not4273 : ~ @Equation4273 Fin3 refa57_inst.
Proof. unfold Equation4273. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa57_inst, refa57_op in H. discriminate H. Qed.

Lemma refa57_not4275 : ~ @Equation4275 Fin3 refa57_inst.
Proof. unfold Equation4275. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa57_inst, refa57_op in H. discriminate H. Qed.

Lemma refa57_not4283 : ~ @Equation4283 Fin3 refa57_inst.
Proof. unfold Equation4283. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa57_inst, refa57_op in H. discriminate H. Qed.

Lemma refa57_not4290 : ~ @Equation4290 Fin3 refa57_inst.
Proof. unfold Equation4290. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa57_inst, refa57_op in H. discriminate H. Qed.

Lemma refa57_not4320 : ~ @Equation4320 Fin3 refa57_inst.
Proof. unfold Equation4320. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa57_inst, refa57_op in H. discriminate H. Qed.

Lemma refa57_not4383 : ~ @Equation4383 Fin3 refa57_inst.
Proof. unfold Equation4383. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa57_inst, refa57_op in H. discriminate H. Qed.

Lemma refa57_not4396 : ~ @Equation4396 Fin3 refa57_inst.
Proof. unfold Equation4396. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa57_inst, refa57_op in H. discriminate H. Qed.

Lemma refa57_not4405 : ~ @Equation4405 Fin3 refa57_inst.
Proof. unfold Equation4405. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa57_inst, refa57_op in H. discriminate H. Qed.

Lemma refa57_not4435 : ~ @Equation4435 Fin3 refa57_inst.
Proof. unfold Equation4435. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa57_inst, refa57_op in H. discriminate H. Qed.

Lemma refa57_not4442 : ~ @Equation4442 Fin3 refa57_inst.
Proof. unfold Equation4442. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa57_inst, refa57_op in H. discriminate H. Qed.

Lemma refa57_not4588 : ~ @Equation4588 Fin3 refa57_inst.
Proof. unfold Equation4588. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa57_inst, refa57_op in H. discriminate H. Qed.

Lemma refa57_not4598 : ~ @Equation4598 Fin3 refa57_inst.
Proof. unfold Equation4598. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa57_inst, refa57_op in H. discriminate H. Qed.

Lemma refa57_not4635 : ~ @Equation4635 Fin3 refa57_inst.
Proof. unfold Equation4635. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa57_inst, refa57_op in H. discriminate H. Qed.

(** ---- refa570 (Fin4) ---- *)

Definition refa570_op (x y : Fin4) : Fin4 :=
  match x, y with
  | F4_0, F4_0 => F4_3 | F4_0, F4_1 => F4_2 | F4_0, F4_2 => F4_3 | F4_0, F4_3 => F4_3
  | F4_1, F4_0 => F4_3 | F4_1, F4_1 => F4_3 | F4_1, F4_2 => F4_3 | F4_1, F4_3 => F4_3
  | F4_2, F4_0 => F4_3 | F4_2, F4_1 => F4_3 | F4_2, F4_2 => F4_0 | F4_2, F4_3 => F4_3
  | F4_3, F4_0 => F4_3 | F4_3, F4_1 => F4_3 | F4_3, F4_2 => F4_3 | F4_3, F4_3 => F4_3
  end.

#[local] Instance refa570_inst : Magma Fin4 := {| magma_op := refa570_op |}.

Lemma refa570_sat4495 : @Equation4495 Fin4 refa570_inst.
Proof. unfold Equation4495, magma_op, refa570_inst, refa570_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa570_sat4504 : @Equation4504 Fin4 refa570_inst.
Proof. unfold Equation4504, magma_op, refa570_inst, refa570_op. intros x y z w. destruct x, y, z, w; reflexivity. Qed.

Lemma refa570_not4470 : ~ @Equation4470 Fin4 refa570_inst.
Proof. unfold Equation4470. intro H. specialize (H F4_2 F4_1). unfold magma_op, refa570_inst, refa570_op in H. discriminate H. Qed.

Lemma refa570_not4482 : ~ @Equation4482 Fin4 refa570_inst.
Proof. unfold Equation4482. intro H. specialize (H F4_1 F4_2). unfold magma_op, refa570_inst, refa570_op in H. discriminate H. Qed.

Lemma refa570_not4583 : ~ @Equation4583 Fin4 refa570_inst.
Proof. unfold Equation4583. intro H. specialize (H F4_2 F4_1). unfold magma_op, refa570_inst, refa570_op in H. discriminate H. Qed.

Lemma refa570_not4598 : ~ @Equation4598 Fin4 refa570_inst.
Proof. unfold Equation4598. intro H. specialize (H F4_2 F4_1). unfold magma_op, refa570_inst, refa570_op in H. discriminate H. Qed.

Lemma refa570_not4599 : ~ @Equation4599 Fin4 refa570_inst.
Proof. unfold Equation4599. intro H. specialize (H F4_2 F4_1). unfold magma_op, refa570_inst, refa570_op in H. discriminate H. Qed.

Lemma refa570_not4605 : ~ @Equation4605 Fin4 refa570_inst.
Proof. unfold Equation4605. intro H. specialize (H F4_2 F4_1). unfold magma_op, refa570_inst, refa570_op in H. discriminate H. Qed.

Lemma refa570_not4606 : ~ @Equation4606 Fin4 refa570_inst.
Proof. unfold Equation4606. intro H. specialize (H F4_2 F4_1). unfold magma_op, refa570_inst, refa570_op in H. discriminate H. Qed.

Lemma refa570_not4608 : ~ @Equation4608 Fin4 refa570_inst.
Proof. unfold Equation4608. intro H. specialize (H F4_1 F4_2). unfold magma_op, refa570_inst, refa570_op in H. discriminate H. Qed.

Lemma refa570_not4622 : ~ @Equation4622 Fin4 refa570_inst.
Proof. unfold Equation4622. intro H. specialize (H F4_0 F4_1 F4_2). unfold magma_op, refa570_inst, refa570_op in H. discriminate H. Qed.

(** ---- refa571 (Fin4) ---- *)

Definition refa571_op (x y : Fin4) : Fin4 :=
  match x, y with
  | F4_0, F4_0 => F4_0 | F4_0, F4_1 => F4_3 | F4_0, F4_2 => F4_1 | F4_0, F4_3 => F4_3
  | F4_1, F4_0 => F4_1 | F4_1, F4_1 => F4_1 | F4_1, F4_2 => F4_0 | F4_1, F4_3 => F4_1
  | F4_2, F4_0 => F4_2 | F4_2, F4_1 => F4_3 | F4_2, F4_2 => F4_2 | F4_2, F4_3 => F4_2
  | F4_3, F4_0 => F4_0 | F4_3, F4_1 => F4_0 | F4_3, F4_2 => F4_3 | F4_3, F4_3 => F4_3
  end.

#[local] Instance refa571_inst : Magma Fin4 := {| magma_op := refa571_op |}.

Lemma refa571_sat2452 : @Equation2452 Fin4 refa571_inst.
Proof. unfold Equation2452, magma_op, refa571_inst, refa571_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa571_not3458 : ~ @Equation3458 Fin4 refa571_inst.
Proof. unfold Equation3458. intro H. specialize (H F4_0 F4_2). unfold magma_op, refa571_inst, refa571_op in H. discriminate H. Qed.

Lemma refa571_not3519 : ~ @Equation3519 Fin4 refa571_inst.
Proof. unfold Equation3519. intro H. specialize (H F4_1 F4_2). unfold magma_op, refa571_inst, refa571_op in H. discriminate H. Qed.

(** ---- refa572 (Fin4) ---- *)

Definition refa572_op (x y : Fin4) : Fin4 :=
  match x, y with
  | F4_0, F4_0 => F4_0 | F4_0, F4_1 => F4_0 | F4_0, F4_2 => F4_2 | F4_0, F4_3 => F4_3
  | F4_1, F4_0 => F4_2 | F4_1, F4_1 => F4_3 | F4_1, F4_2 => F4_2 | F4_1, F4_3 => F4_3
  | F4_2, F4_0 => F4_0 | F4_2, F4_1 => F4_1 | F4_2, F4_2 => F4_2 | F4_2, F4_3 => F4_3
  | F4_3, F4_0 => F4_0 | F4_3, F4_1 => F4_1 | F4_3, F4_2 => F4_2 | F4_3, F4_3 => F4_3
  end.

#[local] Instance refa572_inst : Magma Fin4 := {| magma_op := refa572_op |}.

Lemma refa572_sat224 : @Equation224 Fin4 refa572_inst.
Proof. unfold Equation224, magma_op, refa572_inst, refa572_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa572_not3461 : ~ @Equation3461 Fin4 refa572_inst.
Proof. unfold Equation3461. intro H. specialize (H F4_1 F4_0). unfold magma_op, refa572_inst, refa572_op in H. discriminate H. Qed.

Lemma refa572_not3464 : ~ @Equation3464 Fin4 refa572_inst.
Proof. unfold Equation3464. intro H. specialize (H F4_1 F4_0). unfold magma_op, refa572_inst, refa572_op in H. discriminate H. Qed.

Lemma refa572_not4320 : ~ @Equation4320 Fin4 refa572_inst.
Proof. unfold Equation4320. intro H. specialize (H F4_1 F4_0). unfold magma_op, refa572_inst, refa572_op in H. discriminate H. Qed.

(** ---- refa573 (Fin4) ---- *)

Definition refa573_op (x y : Fin4) : Fin4 :=
  match x, y with
  | F4_0, F4_0 => F4_0 | F4_0, F4_1 => F4_0 | F4_0, F4_2 => F4_3 | F4_0, F4_3 => F4_3
  | F4_1, F4_0 => F4_1 | F4_1, F4_1 => F4_1 | F4_1, F4_2 => F4_1 | F4_1, F4_3 => F4_3
  | F4_2, F4_0 => F4_0 | F4_2, F4_1 => F4_2 | F4_2, F4_2 => F4_2 | F4_2, F4_3 => F4_2
  | F4_3, F4_0 => F4_1 | F4_3, F4_1 => F4_1 | F4_3, F4_2 => F4_3 | F4_3, F4_3 => F4_3
  end.

#[local] Instance refa573_inst : Magma Fin4 := {| magma_op := refa573_op |}.

Lemma refa573_sat645 : @Equation645 Fin4 refa573_inst.
Proof. unfold Equation645, magma_op, refa573_inst, refa573_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa573_not632 : ~ @Equation632 Fin4 refa573_inst.
Proof. unfold Equation632. intro H. specialize (H F4_0 F4_2). unfold magma_op, refa573_inst, refa573_op in H. discriminate H. Qed.

Lemma refa573_not856 : ~ @Equation856 Fin4 refa573_inst.
Proof. unfold Equation856. intro H. specialize (H F4_1 F4_2 F4_0). unfold magma_op, refa573_inst, refa573_op in H. discriminate H. Qed.

Lemma refa573_not1441 : ~ @Equation1441 Fin4 refa573_inst.
Proof. unfold Equation1441. intro H. specialize (H F4_0 F4_2). unfold magma_op, refa573_inst, refa573_op in H. discriminate H. Qed.

Lemma refa573_not1451 : ~ @Equation1451 Fin4 refa573_inst.
Proof. unfold Equation1451. intro H. specialize (H F4_0 F4_2). unfold magma_op, refa573_inst, refa573_op in H. discriminate H. Qed.

Lemma refa573_not1454 : ~ @Equation1454 Fin4 refa573_inst.
Proof. unfold Equation1454. intro H. specialize (H F4_0 F4_2). unfold magma_op, refa573_inst, refa573_op in H. discriminate H. Qed.

Lemma refa573_not3864 : ~ @Equation3864 Fin4 refa573_inst.
Proof. unfold Equation3864. intro H. specialize (H F4_0 F4_2). unfold magma_op, refa573_inst, refa573_op in H. discriminate H. Qed.

Lemma refa573_not3870 : ~ @Equation3870 Fin4 refa573_inst.
Proof. unfold Equation3870. intro H. specialize (H F4_0 F4_2). unfold magma_op, refa573_inst, refa573_op in H. discriminate H. Qed.

Lemma refa573_not4067 : ~ @Equation4067 Fin4 refa573_inst.
Proof. unfold Equation4067. intro H. specialize (H F4_0 F4_2). unfold magma_op, refa573_inst, refa573_op in H. discriminate H. Qed.

Lemma refa573_not4070 : ~ @Equation4070 Fin4 refa573_inst.
Proof. unfold Equation4070. intro H. specialize (H F4_0 F4_2). unfold magma_op, refa573_inst, refa573_op in H. discriminate H. Qed.

Lemma refa573_not4073 : ~ @Equation4073 Fin4 refa573_inst.
Proof. unfold Equation4073. intro H. specialize (H F4_0 F4_2). unfold magma_op, refa573_inst, refa573_op in H. discriminate H. Qed.

Lemma refa573_not4584 : ~ @Equation4584 Fin4 refa573_inst.
Proof. unfold Equation4584. intro H. specialize (H F4_0 F4_2). unfold magma_op, refa573_inst, refa573_op in H. discriminate H. Qed.

(** ---- refa574 (Fin4) ---- *)

Definition refa574_op (x y : Fin4) : Fin4 :=
  match x, y with
  | F4_0, F4_0 => F4_3 | F4_0, F4_1 => F4_3 | F4_0, F4_2 => F4_1 | F4_0, F4_3 => F4_3
  | F4_1, F4_0 => F4_3 | F4_1, F4_1 => F4_3 | F4_1, F4_2 => F4_3 | F4_1, F4_3 => F4_3
  | F4_2, F4_0 => F4_3 | F4_2, F4_1 => F4_0 | F4_2, F4_2 => F4_3 | F4_2, F4_3 => F4_0
  | F4_3, F4_0 => F4_3 | F4_3, F4_1 => F4_3 | F4_3, F4_2 => F4_3 | F4_3, F4_3 => F4_3
  end.

#[local] Instance refa574_inst : Magma Fin4 := {| magma_op := refa574_op |}.

Lemma refa574_sat4089 : @Equation4089 Fin4 refa574_inst.
Proof. unfold Equation4089, magma_op, refa574_inst, refa574_op. intros x y z w. destruct x, y, z, w; reflexivity. Qed.

Lemma refa574_not3862 : ~ @Equation3862 Fin4 refa574_inst.
Proof. unfold Equation3862. intro H. specialize (H F4_2). unfold magma_op, refa574_inst, refa574_op in H. discriminate H. Qed.

Lemma refa574_not4272 : ~ @Equation4272 Fin4 refa574_inst.
Proof. unfold Equation4272. intro H. specialize (H F4_0 F4_2). unfold magma_op, refa574_inst, refa574_op in H. discriminate H. Qed.

(** ---- refa575 (Fin4) ---- *)

Definition refa575_op (x y : Fin4) : Fin4 :=
  match x, y with
  | F4_0, F4_0 => F4_1 | F4_0, F4_1 => F4_1 | F4_0, F4_2 => F4_1 | F4_0, F4_3 => F4_1
  | F4_1, F4_0 => F4_2 | F4_1, F4_1 => F4_2 | F4_1, F4_2 => F4_3 | F4_1, F4_3 => F4_2
  | F4_2, F4_0 => F4_3 | F4_2, F4_1 => F4_3 | F4_2, F4_2 => F4_2 | F4_2, F4_3 => F4_3
  | F4_3, F4_0 => F4_3 | F4_3, F4_1 => F4_3 | F4_3, F4_2 => F4_2 | F4_3, F4_3 => F4_3
  end.

#[local] Instance refa575_inst : Magma Fin4 := {| magma_op := refa575_op |}.

Lemma refa575_sat3515 : @Equation3515 Fin4 refa575_inst.
Proof. unfold Equation3515, magma_op, refa575_inst, refa575_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa575_not3519 : ~ @Equation3519 Fin4 refa575_inst.
Proof. unfold Equation3519. intro H. specialize (H F4_1 F4_0). unfold magma_op, refa575_inst, refa575_op in H. discriminate H. Qed.

Lemma refa575_not3522 : ~ @Equation3522 Fin4 refa575_inst.
Proof. unfold Equation3522. intro H. specialize (H F4_1 F4_0). unfold magma_op, refa575_inst, refa575_op in H. discriminate H. Qed.

Lemma refa575_not3659 : ~ @Equation3659 Fin4 refa575_inst.
Proof. unfold Equation3659. intro H. specialize (H F4_0). unfold magma_op, refa575_inst, refa575_op in H. discriminate H. Qed.

(** ---- refa576 (Fin4) ---- *)

Definition refa576_op (x y : Fin4) : Fin4 :=
  match x, y with
  | F4_0, F4_0 => F4_3 | F4_0, F4_1 => F4_3 | F4_0, F4_2 => F4_2 | F4_0, F4_3 => F4_3
  | F4_1, F4_0 => F4_3 | F4_1, F4_1 => F4_3 | F4_1, F4_2 => F4_3 | F4_1, F4_3 => F4_3
  | F4_2, F4_0 => F4_1 | F4_2, F4_1 => F4_1 | F4_2, F4_2 => F4_1 | F4_2, F4_3 => F4_0
  | F4_3, F4_0 => F4_0 | F4_3, F4_1 => F4_1 | F4_3, F4_2 => F4_0 | F4_3, F4_3 => F4_1
  end.

#[local] Instance refa576_inst : Magma Fin4 := {| magma_op := refa576_op |}.

Lemma refa576_sat3055 : @Equation3055 Fin4 refa576_inst.
Proof. unfold Equation3055, magma_op, refa576_inst, refa576_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa576_not3456 : ~ @Equation3456 Fin4 refa576_inst.
Proof. unfold Equation3456. intro H. specialize (H F4_2). unfold magma_op, refa576_inst, refa576_op in H. discriminate H. Qed.

(** ---- refa577 (Fin4) ---- *)

Definition refa577_op (x y : Fin4) : Fin4 :=
  match x, y with
  | F4_0, F4_0 => F4_3 | F4_0, F4_1 => F4_0 | F4_0, F4_2 => F4_3 | F4_0, F4_3 => F4_3
  | F4_1, F4_0 => F4_3 | F4_1, F4_1 => F4_3 | F4_1, F4_2 => F4_3 | F4_1, F4_3 => F4_0
  | F4_2, F4_0 => F4_2 | F4_2, F4_1 => F4_0 | F4_2, F4_2 => F4_3 | F4_2, F4_3 => F4_3
  | F4_3, F4_0 => F4_3 | F4_3, F4_1 => F4_0 | F4_3, F4_2 => F4_3 | F4_3, F4_3 => F4_3
  end.

#[local] Instance refa577_inst : Magma Fin4 := {| magma_op := refa577_op |}.

Lemma refa577_sat3681 : @Equation3681 Fin4 refa577_inst.
Proof. unfold Equation3681, magma_op, refa577_inst, refa577_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa577_sat3696 : @Equation3696 Fin4 refa577_inst.
Proof. unfold Equation3696, magma_op, refa577_inst, refa577_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa577_not3666 : ~ @Equation3666 Fin4 refa577_inst.
Proof. unfold Equation3666. intro H. specialize (H F4_2 F4_0 F4_1). unfold magma_op, refa577_inst, refa577_op in H. discriminate H. Qed.

Lemma refa577_not3669 : ~ @Equation3669 Fin4 refa577_inst.
Proof. unfold Equation3669. intro H. specialize (H F4_2 F4_0 F4_1). unfold magma_op, refa577_inst, refa577_op in H. discriminate H. Qed.

Lemma refa577_not3698 : ~ @Equation3698 Fin4 refa577_inst.
Proof. unfold Equation3698. intro H. specialize (H F4_1 F4_2 F4_0). unfold magma_op, refa577_inst, refa577_op in H. discriminate H. Qed.

(** ---- refa578 (Fin4) ---- *)

Definition refa578_op (x y : Fin4) : Fin4 :=
  match x, y with
  | F4_0, F4_0 => F4_3 | F4_0, F4_1 => F4_2 | F4_0, F4_2 => F4_0 | F4_0, F4_3 => F4_1
  | F4_1, F4_0 => F4_3 | F4_1, F4_1 => F4_3 | F4_1, F4_2 => F4_0 | F4_1, F4_3 => F4_1
  | F4_2, F4_0 => F4_3 | F4_2, F4_1 => F4_2 | F4_2, F4_2 => F4_1 | F4_2, F4_3 => F4_1
  | F4_3, F4_0 => F4_3 | F4_3, F4_1 => F4_3 | F4_3, F4_2 => F4_1 | F4_3, F4_3 => F4_1
  end.

#[local] Instance refa578_inst : Magma Fin4 := {| magma_op := refa578_op |}.

Lemma refa578_sat422 : @Equation422 Fin4 refa578_inst.
Proof. unfold Equation422, magma_op, refa578_inst, refa578_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa578_not99 : ~ @Equation99 Fin4 refa578_inst.
Proof. unfold Equation99. intro H. specialize (H F4_0). unfold magma_op, refa578_inst, refa578_op in H. discriminate H. Qed.

Lemma refa578_not151 : ~ @Equation151 Fin4 refa578_inst.
Proof. unfold Equation151. intro H. specialize (H F4_0). unfold magma_op, refa578_inst, refa578_op in H. discriminate H. Qed.

Lemma refa578_not426 : ~ @Equation426 Fin4 refa578_inst.
Proof. unfold Equation426. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa578_inst, refa578_op in H. discriminate H. Qed.

Lemma refa578_not429 : ~ @Equation429 Fin4 refa578_inst.
Proof. unfold Equation429. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa578_inst, refa578_op in H. discriminate H. Qed.

Lemma refa578_not436 : ~ @Equation436 Fin4 refa578_inst.
Proof. unfold Equation436. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa578_inst, refa578_op in H. discriminate H. Qed.

Lemma refa578_not1020 : ~ @Equation1020 Fin4 refa578_inst.
Proof. unfold Equation1020. intro H. specialize (H F4_0). unfold magma_op, refa578_inst, refa578_op in H. discriminate H. Qed.

Lemma refa578_not1223 : ~ @Equation1223 Fin4 refa578_inst.
Proof. unfold Equation1223. intro H. specialize (H F4_0). unfold magma_op, refa578_inst, refa578_op in H. discriminate H. Qed.

Lemma refa578_not1629 : ~ @Equation1629 Fin4 refa578_inst.
Proof. unfold Equation1629. intro H. specialize (H F4_0). unfold magma_op, refa578_inst, refa578_op in H. discriminate H. Qed.

Lemma refa578_not1832 : ~ @Equation1832 Fin4 refa578_inst.
Proof. unfold Equation1832. intro H. specialize (H F4_0). unfold magma_op, refa578_inst, refa578_op in H. discriminate H. Qed.

Lemma refa578_not2035 : ~ @Equation2035 Fin4 refa578_inst.
Proof. unfold Equation2035. intro H. specialize (H F4_0). unfold magma_op, refa578_inst, refa578_op in H. discriminate H. Qed.

Lemma refa578_not3253 : ~ @Equation3253 Fin4 refa578_inst.
Proof. unfold Equation3253. intro H. specialize (H F4_0). unfold magma_op, refa578_inst, refa578_op in H. discriminate H. Qed.

Lemma refa578_not3864 : ~ @Equation3864 Fin4 refa578_inst.
Proof. unfold Equation3864. intro H. specialize (H F4_2 F4_0). unfold magma_op, refa578_inst, refa578_op in H. discriminate H. Qed.

Lemma refa578_not3867 : ~ @Equation3867 Fin4 refa578_inst.
Proof. unfold Equation3867. intro H. specialize (H F4_1 F4_0). unfold magma_op, refa578_inst, refa578_op in H. discriminate H. Qed.

Lemma refa578_not3870 : ~ @Equation3870 Fin4 refa578_inst.
Proof. unfold Equation3870. intro H. specialize (H F4_2 F4_0). unfold magma_op, refa578_inst, refa578_op in H. discriminate H. Qed.

Lemma refa578_not3915 : ~ @Equation3915 Fin4 refa578_inst.
Proof. unfold Equation3915. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa578_inst, refa578_op in H. discriminate H. Qed.

Lemma refa578_not3918 : ~ @Equation3918 Fin4 refa578_inst.
Proof. unfold Equation3918. intro H. specialize (H F4_0 F4_2). unfold magma_op, refa578_inst, refa578_op in H. discriminate H. Qed.

Lemma refa578_not3925 : ~ @Equation3925 Fin4 refa578_inst.
Proof. unfold Equation3925. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa578_inst, refa578_op in H. discriminate H. Qed.

Lemma refa578_not3928 : ~ @Equation3928 Fin4 refa578_inst.
Proof. unfold Equation3928. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa578_inst, refa578_op in H. discriminate H. Qed.

Lemma refa578_not4065 : ~ @Equation4065 Fin4 refa578_inst.
Proof. unfold Equation4065. intro H. specialize (H F4_2). unfold magma_op, refa578_inst, refa578_op in H. discriminate H. Qed.

Lemma refa578_not4269 : ~ @Equation4269 Fin4 refa578_inst.
Proof. unfold Equation4269. intro H. specialize (H F4_1 F4_0). unfold magma_op, refa578_inst, refa578_op in H. discriminate H. Qed.

Lemma refa578_not4284 : ~ @Equation4284 Fin4 refa578_inst.
Proof. unfold Equation4284. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa578_inst, refa578_op in H. discriminate H. Qed.

Lemma refa578_not4599 : ~ @Equation4599 Fin4 refa578_inst.
Proof. unfold Equation4599. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa578_inst, refa578_op in H. discriminate H. Qed.

Lemma refa578_not4631 : ~ @Equation4631 Fin4 refa578_inst.
Proof. unfold Equation4631. intro H. specialize (H F4_1 F4_0 F4_2). unfold magma_op, refa578_inst, refa578_op in H. discriminate H. Qed.

(** ---- refa579 (Fin4) ---- *)

Definition refa579_op (x y : Fin4) : Fin4 :=
  match x, y with
  | F4_0, F4_0 => F4_1 | F4_0, F4_1 => F4_1 | F4_0, F4_2 => F4_2 | F4_0, F4_3 => F4_3
  | F4_1, F4_0 => F4_1 | F4_1, F4_1 => F4_1 | F4_1, F4_2 => F4_2 | F4_1, F4_3 => F4_3
  | F4_2, F4_0 => F4_0 | F4_2, F4_1 => F4_0 | F4_2, F4_2 => F4_2 | F4_2, F4_3 => F4_3
  | F4_3, F4_0 => F4_2 | F4_3, F4_1 => F4_1 | F4_3, F4_2 => F4_2 | F4_3, F4_3 => F4_3
  end.

#[local] Instance refa579_inst : Magma Fin4 := {| magma_op := refa579_op |}.

Lemma refa579_sat4209 : @Equation4209 Fin4 refa579_inst.
Proof. unfold Equation4209, magma_op, refa579_inst, refa579_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa579_not3887 : ~ @Equation3887 Fin4 refa579_inst.
Proof. unfold Equation3887. intro H. specialize (H F4_0 F4_3). unfold magma_op, refa579_inst, refa579_op in H. discriminate H. Qed.

(** ---- refa58 (Fin3) ---- *)

Definition refa58_op (x y : Fin3) : Fin3 :=
  match x, y with
  | F3_0, F3_0 => F3_0 | F3_0, F3_1 => F3_0 | F3_0, F3_2 => F3_2
  | F3_1, F3_0 => F3_1 | F3_1, F3_1 => F3_2 | F3_1, F3_2 => F3_1
  | F3_2, F3_0 => F3_2 | F3_2, F3_1 => F3_2 | F3_2, F3_2 => F3_0
  end.

#[local] Instance refa58_inst : Magma Fin3 := {| magma_op := refa58_op |}.

Lemma refa58_sat427 : @Equation427 Fin3 refa58_inst.
Proof. unfold Equation427, magma_op, refa58_inst, refa58_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa58_sat823 : @Equation823 Fin3 refa58_inst.
Proof. unfold Equation823, magma_op, refa58_inst, refa58_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa58_sat1023 : @Equation1023 Fin3 refa58_inst.
Proof. unfold Equation1023, magma_op, refa58_inst, refa58_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa58_sat1038 : @Equation1038 Fin3 refa58_inst.
Proof. unfold Equation1038, magma_op, refa58_inst, refa58_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa58_sat1229 : @Equation1229 Fin3 refa58_inst.
Proof. unfold Equation1229, magma_op, refa58_inst, refa58_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa58_sat1231 : @Equation1231 Fin3 refa58_inst.
Proof. unfold Equation1231, magma_op, refa58_inst, refa58_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa58_sat1850 : @Equation1850 Fin3 refa58_inst.
Proof. unfold Equation1850, magma_op, refa58_inst, refa58_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa58_sat1861 : @Equation1861 Fin3 refa58_inst.
Proof. unfold Equation1861, magma_op, refa58_inst, refa58_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa58_sat4068 : @Equation4068 Fin3 refa58_inst.
Proof. unfold Equation4068, magma_op, refa58_inst, refa58_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa58_not820 : ~ @Equation820 Fin3 refa58_inst.
Proof. unfold Equation820. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa58_inst, refa58_op in H. discriminate H. Qed.

Lemma refa58_not1028 : ~ @Equation1028 Fin3 refa58_inst.
Proof. unfold Equation1028. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa58_inst, refa58_op in H. discriminate H. Qed.

Lemma refa58_not1035 : ~ @Equation1035 Fin3 refa58_inst.
Proof. unfold Equation1035. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa58_inst, refa58_op in H. discriminate H. Qed.

Lemma refa58_not1039 : ~ @Equation1039 Fin3 refa58_inst.
Proof. unfold Equation1039. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa58_inst, refa58_op in H. discriminate H. Qed.

Lemma refa58_not1045 : ~ @Equation1045 Fin3 refa58_inst.
Proof. unfold Equation1045. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa58_inst, refa58_op in H. discriminate H. Qed.

Lemma refa58_not1046 : ~ @Equation1046 Fin3 refa58_inst.
Proof. unfold Equation1046. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa58_inst, refa58_op in H. discriminate H. Qed.

Lemma refa58_not1225 : ~ @Equation1225 Fin3 refa58_inst.
Proof. unfold Equation1225. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa58_inst, refa58_op in H. discriminate H. Qed.

Lemma refa58_not1228 : ~ @Equation1228 Fin3 refa58_inst.
Proof. unfold Equation1228. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa58_inst, refa58_op in H. discriminate H. Qed.

Lemma refa58_not1239 : ~ @Equation1239 Fin3 refa58_inst.
Proof. unfold Equation1239. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa58_inst, refa58_op in H. discriminate H. Qed.

Lemma refa58_not1241 : ~ @Equation1241 Fin3 refa58_inst.
Proof. unfold Equation1241. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa58_inst, refa58_op in H. discriminate H. Qed.

Lemma refa58_not1249 : ~ @Equation1249 Fin3 refa58_inst.
Proof. unfold Equation1249. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa58_inst, refa58_op in H. discriminate H. Qed.

Lemma refa58_not1834 : ~ @Equation1834 Fin3 refa58_inst.
Proof. unfold Equation1834. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa58_inst, refa58_op in H. discriminate H. Qed.

Lemma refa58_not1847 : ~ @Equation1847 Fin3 refa58_inst.
Proof. unfold Equation1847. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa58_inst, refa58_op in H. discriminate H. Qed.

Lemma refa58_not1851 : ~ @Equation1851 Fin3 refa58_inst.
Proof. unfold Equation1851. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa58_inst, refa58_op in H. discriminate H. Qed.

Lemma refa58_not1857 : ~ @Equation1857 Fin3 refa58_inst.
Proof. unfold Equation1857. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa58_inst, refa58_op in H. discriminate H. Qed.

Lemma refa58_not1860 : ~ @Equation1860 Fin3 refa58_inst.
Proof. unfold Equation1860. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa58_inst, refa58_op in H. discriminate H. Qed.

Lemma refa58_not3255 : ~ @Equation3255 Fin3 refa58_inst.
Proof. unfold Equation3255. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa58_inst, refa58_op in H. discriminate H. Qed.

Lemma refa58_not3256 : ~ @Equation3256 Fin3 refa58_inst.
Proof. unfold Equation3256. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa58_inst, refa58_op in H. discriminate H. Qed.

Lemma refa58_not3316 : ~ @Equation3316 Fin3 refa58_inst.
Proof. unfold Equation3316. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa58_inst, refa58_op in H. discriminate H. Qed.

Lemma refa58_not3318 : ~ @Equation3318 Fin3 refa58_inst.
Proof. unfold Equation3318. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa58_inst, refa58_op in H. discriminate H. Qed.

Lemma refa58_not3659 : ~ @Equation3659 Fin3 refa58_inst.
Proof. unfold Equation3659. intro H. specialize (H F3_1). unfold magma_op, refa58_inst, refa58_op in H. discriminate H. Qed.

Lemma refa58_not3864 : ~ @Equation3864 Fin3 refa58_inst.
Proof. unfold Equation3864. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa58_inst, refa58_op in H. discriminate H. Qed.

Lemma refa58_not3865 : ~ @Equation3865 Fin3 refa58_inst.
Proof. unfold Equation3865. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa58_inst, refa58_op in H. discriminate H. Qed.

Lemma refa58_not3867 : ~ @Equation3867 Fin3 refa58_inst.
Proof. unfold Equation3867. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa58_inst, refa58_op in H. discriminate H. Qed.

Lemma refa58_not3870 : ~ @Equation3870 Fin3 refa58_inst.
Proof. unfold Equation3870. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa58_inst, refa58_op in H. discriminate H. Qed.

Lemma refa58_not3887 : ~ @Equation3887 Fin3 refa58_inst.
Proof. unfold Equation3887. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa58_inst, refa58_op in H. discriminate H. Qed.

Lemma refa58_not3925 : ~ @Equation3925 Fin3 refa58_inst.
Proof. unfold Equation3925. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa58_inst, refa58_op in H. discriminate H. Qed.

Lemma refa58_not3928 : ~ @Equation3928 Fin3 refa58_inst.
Proof. unfold Equation3928. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa58_inst, refa58_op in H. discriminate H. Qed.

Lemma refa58_not4066 : ~ @Equation4066 Fin3 refa58_inst.
Proof. unfold Equation4066. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa58_inst, refa58_op in H. discriminate H. Qed.

Lemma refa58_not4067 : ~ @Equation4067 Fin3 refa58_inst.
Proof. unfold Equation4067. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa58_inst, refa58_op in H. discriminate H. Qed.

Lemma refa58_not4070 : ~ @Equation4070 Fin3 refa58_inst.
Proof. unfold Equation4070. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa58_inst, refa58_op in H. discriminate H. Qed.

Lemma refa58_not4071 : ~ @Equation4071 Fin3 refa58_inst.
Proof. unfold Equation4071. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa58_inst, refa58_op in H. discriminate H. Qed.

Lemma refa58_not4269 : ~ @Equation4269 Fin3 refa58_inst.
Proof. unfold Equation4269. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa58_inst, refa58_op in H. discriminate H. Qed.

Lemma refa58_not4270 : ~ @Equation4270 Fin3 refa58_inst.
Proof. unfold Equation4270. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa58_inst, refa58_op in H. discriminate H. Qed.

Lemma refa58_not4314 : ~ @Equation4314 Fin3 refa58_inst.
Proof. unfold Equation4314. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa58_inst, refa58_op in H. discriminate H. Qed.

Lemma refa58_not4583 : ~ @Equation4583 Fin3 refa58_inst.
Proof. unfold Equation4583. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa58_inst, refa58_op in H. discriminate H. Qed.

Lemma refa58_not4598 : ~ @Equation4598 Fin3 refa58_inst.
Proof. unfold Equation4598. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa58_inst, refa58_op in H. discriminate H. Qed.

Lemma refa58_not4631 : ~ @Equation4631 Fin3 refa58_inst.
Proof. unfold Equation4631. intro H. specialize (H F3_0 F3_0 F3_2). unfold magma_op, refa58_inst, refa58_op in H. discriminate H. Qed.

(** ---- refa580 (Fin4) ---- *)

Definition refa580_op (x y : Fin4) : Fin4 :=
  match x, y with
  | F4_0, F4_0 => F4_2 | F4_0, F4_1 => F4_2 | F4_0, F4_2 => F4_2 | F4_0, F4_3 => F4_3
  | F4_1, F4_0 => F4_3 | F4_1, F4_1 => F4_3 | F4_1, F4_2 => F4_3 | F4_1, F4_3 => F4_2
  | F4_2, F4_0 => F4_3 | F4_2, F4_1 => F4_3 | F4_2, F4_2 => F4_2 | F4_2, F4_3 => F4_0
  | F4_3, F4_0 => F4_0 | F4_3, F4_1 => F4_1 | F4_3, F4_2 => F4_2 | F4_3, F4_3 => F4_2
  end.

#[local] Instance refa580_inst : Magma Fin4 := {| magma_op := refa580_op |}.

Lemma refa580_sat2946 : @Equation2946 Fin4 refa580_inst.
Proof. unfold Equation2946, magma_op, refa580_inst, refa580_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa580_not255 : ~ @Equation255 Fin4 refa580_inst.
Proof. unfold Equation255. intro H. specialize (H F4_1). unfold magma_op, refa580_inst, refa580_op in H. discriminate H. Qed.

Lemma refa580_not307 : ~ @Equation307 Fin4 refa580_inst.
Proof. unfold Equation307. intro H. specialize (H F4_1). unfold magma_op, refa580_inst, refa580_op in H. discriminate H. Qed.

Lemma refa580_not2872 : ~ @Equation2872 Fin4 refa580_inst.
Proof. unfold Equation2872. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa580_inst, refa580_op in H. discriminate H. Qed.

Lemma refa580_not2909 : ~ @Equation2909 Fin4 refa580_inst.
Proof. unfold Equation2909. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa580_inst, refa580_op in H. discriminate H. Qed.

Lemma refa580_not3258 : ~ @Equation3258 Fin4 refa580_inst.
Proof. unfold Equation3258. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa580_inst, refa580_op in H. discriminate H. Qed.

Lemma refa580_not3268 : ~ @Equation3268 Fin4 refa580_inst.
Proof. unfold Equation3268. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa580_inst, refa580_op in H. discriminate H. Qed.

Lemma refa580_not3278 : ~ @Equation3278 Fin4 refa580_inst.
Proof. unfold Equation3278. intro H. specialize (H F4_1 F4_3). unfold magma_op, refa580_inst, refa580_op in H. discriminate H. Qed.

Lemma refa580_not3659 : ~ @Equation3659 Fin4 refa580_inst.
Proof. unfold Equation3659. intro H. specialize (H F4_1). unfold magma_op, refa580_inst, refa580_op in H. discriminate H. Qed.

Lemma refa580_not4351 : ~ @Equation4351 Fin4 refa580_inst.
Proof. unfold Equation4351. intro H. specialize (H F4_0 F4_0 F4_1). unfold magma_op, refa580_inst, refa580_op in H. discriminate H. Qed.

Lemma refa580_not4622 : ~ @Equation4622 Fin4 refa580_inst.
Proof. unfold Equation4622. intro H. specialize (H F4_0 F4_0 F4_1). unfold magma_op, refa580_inst, refa580_op in H. discriminate H. Qed.

(** ---- refa581 (Fin4) ---- *)

Definition refa581_op (x y : Fin4) : Fin4 :=
  match x, y with
  | F4_0, F4_0 => F4_2 | F4_0, F4_1 => F4_1 | F4_0, F4_2 => F4_0 | F4_0, F4_3 => F4_1
  | F4_1, F4_0 => F4_2 | F4_1, F4_1 => F4_3 | F4_1, F4_2 => F4_1 | F4_1, F4_3 => F4_1
  | F4_2, F4_0 => F4_2 | F4_2, F4_1 => F4_3 | F4_2, F4_2 => F4_0 | F4_2, F4_3 => F4_2
  | F4_3, F4_0 => F4_0 | F4_3, F4_1 => F4_3 | F4_3, F4_2 => F4_0 | F4_3, F4_3 => F4_1
  end.

#[local] Instance refa581_inst : Magma Fin4 := {| magma_op := refa581_op |}.

Lemma refa581_sat1687 : @Equation1687 Fin4 refa581_inst.
Proof. unfold Equation1687, magma_op, refa581_inst, refa581_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa581_not1038 : ~ @Equation1038 Fin4 refa581_inst.
Proof. unfold Equation1038. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa581_inst, refa581_op in H. discriminate H. Qed.

Lemma refa581_not1055 : ~ @Equation1055 Fin4 refa581_inst.
Proof. unfold Equation1055. intro H. specialize (H F4_2 F4_0 F4_1). unfold magma_op, refa581_inst, refa581_op in H. discriminate H. Qed.

Lemma refa581_not1225 : ~ @Equation1225 Fin4 refa581_inst.
Proof. unfold Equation1225. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa581_inst, refa581_op in H. discriminate H. Qed.

Lemma refa581_not1238 : ~ @Equation1238 Fin4 refa581_inst.
Proof. unfold Equation1238. intro H. specialize (H F4_2 F4_1). unfold magma_op, refa581_inst, refa581_op in H. discriminate H. Qed.

Lemma refa581_not1248 : ~ @Equation1248 Fin4 refa581_inst.
Proof. unfold Equation1248. intro H. specialize (H F4_2 F4_3). unfold magma_op, refa581_inst, refa581_op in H. discriminate H. Qed.

Lemma refa581_not1634 : ~ @Equation1634 Fin4 refa581_inst.
Proof. unfold Equation1634. intro H. specialize (H F4_2 F4_1). unfold magma_op, refa581_inst, refa581_op in H. discriminate H. Qed.

Lemma refa581_not1644 : ~ @Equation1644 Fin4 refa581_inst.
Proof. unfold Equation1644. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa581_inst, refa581_op in H. discriminate H. Qed.

Lemma refa581_not1654 : ~ @Equation1654 Fin4 refa581_inst.
Proof. unfold Equation1654. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa581_inst, refa581_op in H. discriminate H. Qed.

Lemma refa581_not1691 : ~ @Equation1691 Fin4 refa581_inst.
Proof. unfold Equation1691. intro H. specialize (H F4_2 F4_1). unfold magma_op, refa581_inst, refa581_op in H. discriminate H. Qed.

Lemma refa581_not1837 : ~ @Equation1837 Fin4 refa581_inst.
Proof. unfold Equation1837. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa581_inst, refa581_op in H. discriminate H. Qed.

Lemma refa581_not1847 : ~ @Equation1847 Fin4 refa581_inst.
Proof. unfold Equation1847. intro H. specialize (H F4_2 F4_1). unfold magma_op, refa581_inst, refa581_op in H. discriminate H. Qed.

Lemma refa581_not1857 : ~ @Equation1857 Fin4 refa581_inst.
Proof. unfold Equation1857. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa581_inst, refa581_op in H. discriminate H. Qed.

Lemma refa581_not1884 : ~ @Equation1884 Fin4 refa581_inst.
Proof. unfold Equation1884. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa581_inst, refa581_op in H. discriminate H. Qed.

Lemma refa581_not1921 : ~ @Equation1921 Fin4 refa581_inst.
Proof. unfold Equation1921. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa581_inst, refa581_op in H. discriminate H. Qed.

Lemma refa581_not3306 : ~ @Equation3306 Fin4 refa581_inst.
Proof. unfold Equation3306. intro H. specialize (H F4_1 F4_0). unfold magma_op, refa581_inst, refa581_op in H. discriminate H. Qed.

Lemma refa581_not3309 : ~ @Equation3309 Fin4 refa581_inst.
Proof. unfold Equation3309. intro H. specialize (H F4_1 F4_0). unfold magma_op, refa581_inst, refa581_op in H. discriminate H. Qed.

Lemma refa581_not3343 : ~ @Equation3343 Fin4 refa581_inst.
Proof. unfold Equation3343. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa581_inst, refa581_op in H. discriminate H. Qed.

Lemma refa581_not3346 : ~ @Equation3346 Fin4 refa581_inst.
Proof. unfold Equation3346. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa581_inst, refa581_op in H. discriminate H. Qed.

Lemma refa581_not3353 : ~ @Equation3353 Fin4 refa581_inst.
Proof. unfold Equation3353. intro H. specialize (H F4_1 F4_2). unfold magma_op, refa581_inst, refa581_op in H. discriminate H. Qed.

Lemma refa581_not3880 : ~ @Equation3880 Fin4 refa581_inst.
Proof. unfold Equation3880. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa581_inst, refa581_op in H. discriminate H. Qed.

Lemma refa581_not3897 : ~ @Equation3897 Fin4 refa581_inst.
Proof. unfold Equation3897. intro H. specialize (H F4_2 F4_0 F4_1). unfold magma_op, refa581_inst, refa581_op in H. discriminate H. Qed.

Lemma refa581_not4067 : ~ @Equation4067 Fin4 refa581_inst.
Proof. unfold Equation4067. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa581_inst, refa581_op in H. discriminate H. Qed.

Lemma refa581_not4080 : ~ @Equation4080 Fin4 refa581_inst.
Proof. unfold Equation4080. intro H. specialize (H F4_2 F4_1). unfold magma_op, refa581_inst, refa581_op in H. discriminate H. Qed.

Lemma refa581_not4090 : ~ @Equation4090 Fin4 refa581_inst.
Proof. unfold Equation4090. intro H. specialize (H F4_2 F4_3). unfold magma_op, refa581_inst, refa581_op in H. discriminate H. Qed.

Lemma refa581_not4118 : ~ @Equation4118 Fin4 refa581_inst.
Proof. unfold Equation4118. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa581_inst, refa581_op in H. discriminate H. Qed.

Lemma refa581_not4128 : ~ @Equation4128 Fin4 refa581_inst.
Proof. unfold Equation4128. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa581_inst, refa581_op in H. discriminate H. Qed.

Lemma refa581_not4155 : ~ @Equation4155 Fin4 refa581_inst.
Proof. unfold Equation4155. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa581_inst, refa581_op in H. discriminate H. Qed.

Lemma refa581_not4284 : ~ @Equation4284 Fin4 refa581_inst.
Proof. unfold Equation4284. intro H. specialize (H F4_1 F4_2). unfold magma_op, refa581_inst, refa581_op in H. discriminate H. Qed.

Lemma refa581_not4291 : ~ @Equation4291 Fin4 refa581_inst.
Proof. unfold Equation4291. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa581_inst, refa581_op in H. discriminate H. Qed.

Lemma refa581_not4320 : ~ @Equation4320 Fin4 refa581_inst.
Proof. unfold Equation4320. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa581_inst, refa581_op in H. discriminate H. Qed.

Lemma refa581_not4635 : ~ @Equation4635 Fin4 refa581_inst.
Proof. unfold Equation4635. intro H. specialize (H F4_2 F4_1). unfold magma_op, refa581_inst, refa581_op in H. discriminate H. Qed.

Lemma refa581_not4666 : ~ @Equation4666 Fin4 refa581_inst.
Proof. unfold Equation4666. intro H. specialize (H F4_0 F4_2 F4_1). unfold magma_op, refa581_inst, refa581_op in H. discriminate H. Qed.

(** ---- refa582 (Fin4) ---- *)

Definition refa582_op (x y : Fin4) : Fin4 :=
  match x, y with
  | F4_0, F4_0 => F4_0 | F4_0, F4_1 => F4_0 | F4_0, F4_2 => F4_1 | F4_0, F4_3 => F4_0
  | F4_1, F4_0 => F4_3 | F4_1, F4_1 => F4_1 | F4_1, F4_2 => F4_3 | F4_1, F4_3 => F4_1
  | F4_2, F4_0 => F4_2 | F4_2, F4_1 => F4_2 | F4_2, F4_2 => F4_2 | F4_2, F4_3 => F4_2
  | F4_3, F4_0 => F4_1 | F4_3, F4_1 => F4_3 | F4_3, F4_2 => F4_0 | F4_3, F4_3 => F4_3
  end.

#[local] Instance refa582_inst : Magma Fin4 := {| magma_op := refa582_op |}.

Lemma refa582_sat3317 : @Equation3317 Fin4 refa582_inst.
Proof. unfold Equation3317, magma_op, refa582_inst, refa582_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa582_not3459 : ~ @Equation3459 Fin4 refa582_inst.
Proof. unfold Equation3459. intro H. specialize (H F4_1 F4_2). unfold magma_op, refa582_inst, refa582_op in H. discriminate H. Qed.

(** ---- refa583 (Fin4) ---- *)

Definition refa583_op (x y : Fin4) : Fin4 :=
  match x, y with
  | F4_0, F4_0 => F4_0 | F4_0, F4_1 => F4_2 | F4_0, F4_2 => F4_0 | F4_0, F4_3 => F4_1
  | F4_1, F4_0 => F4_1 | F4_1, F4_1 => F4_2 | F4_1, F4_2 => F4_1 | F4_1, F4_3 => F4_1
  | F4_2, F4_0 => F4_2 | F4_2, F4_1 => F4_1 | F4_2, F4_2 => F4_2 | F4_2, F4_3 => F4_2
  | F4_3, F4_0 => F4_3 | F4_3, F4_1 => F4_2 | F4_3, F4_2 => F4_3 | F4_3, F4_3 => F4_0
  end.

#[local] Instance refa583_inst : Magma Fin4 := {| magma_op := refa583_op |}.

Lemma refa583_sat647 : @Equation647 Fin4 refa583_inst.
Proof. unfold Equation647, magma_op, refa583_inst, refa583_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa583_not1223 : ~ @Equation1223 Fin4 refa583_inst.
Proof. unfold Equation1223. intro H. specialize (H F4_3). unfold magma_op, refa583_inst, refa583_op in H. discriminate H. Qed.

Lemma refa583_not3456 : ~ @Equation3456 Fin4 refa583_inst.
Proof. unfold Equation3456. intro H. specialize (H F4_3). unfold magma_op, refa583_inst, refa583_op in H. discriminate H. Qed.

Lemma refa583_not4065 : ~ @Equation4065 Fin4 refa583_inst.
Proof. unfold Equation4065. intro H. specialize (H F4_3). unfold magma_op, refa583_inst, refa583_op in H. discriminate H. Qed.

(** ---- refa584 (Fin4) ---- *)

Definition refa584_op (x y : Fin4) : Fin4 :=
  match x, y with
  | F4_0, F4_0 => F4_3 | F4_0, F4_1 => F4_0 | F4_0, F4_2 => F4_3 | F4_0, F4_3 => F4_3
  | F4_1, F4_0 => F4_1 | F4_1, F4_1 => F4_2 | F4_1, F4_2 => F4_2 | F4_1, F4_3 => F4_1
  | F4_2, F4_0 => F4_2 | F4_2, F4_1 => F4_1 | F4_2, F4_2 => F4_1 | F4_2, F4_3 => F4_2
  | F4_3, F4_0 => F4_0 | F4_3, F4_1 => F4_3 | F4_3, F4_2 => F4_0 | F4_3, F4_3 => F4_0
  end.

#[local] Instance refa584_inst : Magma Fin4 := {| magma_op := refa584_op |}.

Lemma refa584_sat2260 : @Equation2260 Fin4 refa584_inst.
Proof. unfold Equation2260, magma_op, refa584_inst, refa584_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa584_sat3317 : @Equation3317 Fin4 refa584_inst.
Proof. unfold Equation3317, magma_op, refa584_inst, refa584_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa584_not160 : ~ @Equation160 Fin4 refa584_inst.
Proof. unfold Equation160. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa584_inst, refa584_op in H. discriminate H. Qed.

Lemma refa584_not359 : ~ @Equation359 Fin4 refa584_inst.
Proof. unfold Equation359. intro H. specialize (H F4_0). unfold magma_op, refa584_inst, refa584_op in H. discriminate H. Qed.

Lemma refa584_not1454 : ~ @Equation1454 Fin4 refa584_inst.
Proof. unfold Equation1454. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa584_inst, refa584_op in H. discriminate H. Qed.

Lemma refa584_not1455 : ~ @Equation1455 Fin4 refa584_inst.
Proof. unfold Equation1455. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa584_inst, refa584_op in H. discriminate H. Qed.

Lemma refa584_not2264 : ~ @Equation2264 Fin4 refa584_inst.
Proof. unfold Equation2264. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa584_inst, refa584_op in H. discriminate H. Qed.

Lemma refa584_not3318 : ~ @Equation3318 Fin4 refa584_inst.
Proof. unfold Equation3318. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa584_inst, refa584_op in H. discriminate H. Qed.

Lemma refa584_not3319 : ~ @Equation3319 Fin4 refa584_inst.
Proof. unfold Equation3319. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa584_inst, refa584_op in H. discriminate H. Qed.

Lemma refa584_not3519 : ~ @Equation3519 Fin4 refa584_inst.
Proof. unfold Equation3519. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa584_inst, refa584_op in H. discriminate H. Qed.

Lemma refa584_not3521 : ~ @Equation3521 Fin4 refa584_inst.
Proof. unfold Equation3521. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa584_inst, refa584_op in H. discriminate H. Qed.

Lemma refa584_not3659 : ~ @Equation3659 Fin4 refa584_inst.
Proof. unfold Equation3659. intro H. specialize (H F4_0). unfold magma_op, refa584_inst, refa584_op in H. discriminate H. Qed.

Lemma refa584_not3862 : ~ @Equation3862 Fin4 refa584_inst.
Proof. unfold Equation3862. intro H. specialize (H F4_0). unfold magma_op, refa584_inst, refa584_op in H. discriminate H. Qed.

Lemma refa584_not4314 : ~ @Equation4314 Fin4 refa584_inst.
Proof. unfold Equation4314. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa584_inst, refa584_op in H. discriminate H. Qed.

(** ---- refa585 (Fin4) ---- *)

Definition refa585_op (x y : Fin4) : Fin4 :=
  match x, y with
  | F4_0, F4_0 => F4_3 | F4_0, F4_1 => F4_1 | F4_0, F4_2 => F4_0 | F4_0, F4_3 => F4_3
  | F4_1, F4_0 => F4_3 | F4_1, F4_1 => F4_1 | F4_1, F4_2 => F4_1 | F4_1, F4_3 => F4_1
  | F4_2, F4_0 => F4_2 | F4_2, F4_1 => F4_2 | F4_2, F4_2 => F4_2 | F4_2, F4_3 => F4_2
  | F4_3, F4_0 => F4_2 | F4_3, F4_1 => F4_3 | F4_3, F4_2 => F4_3 | F4_3, F4_3 => F4_3
  end.

#[local] Instance refa585_inst : Magma Fin4 := {| magma_op := refa585_op |}.

Lemma refa585_sat1240 : @Equation1240 Fin4 refa585_inst.
Proof. unfold Equation1240, magma_op, refa585_inst, refa585_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa585_not1242 : ~ @Equation1242 Fin4 refa585_inst.
Proof. unfold Equation1242. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa585_inst, refa585_op in H. discriminate H. Qed.

Lemma refa585_not1251 : ~ @Equation1251 Fin4 refa585_inst.
Proof. unfold Equation1251. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa585_inst, refa585_op in H. discriminate H. Qed.

(** ---- refa586 (Fin4) ---- *)

Definition refa586_op (x y : Fin4) : Fin4 :=
  match x, y with
  | F4_0, F4_0 => F4_0 | F4_0, F4_1 => F4_2 | F4_0, F4_2 => F4_1 | F4_0, F4_3 => F4_3
  | F4_1, F4_0 => F4_3 | F4_1, F4_1 => F4_0 | F4_1, F4_2 => F4_0 | F4_1, F4_3 => F4_1
  | F4_2, F4_0 => F4_3 | F4_2, F4_1 => F4_0 | F4_2, F4_2 => F4_2 | F4_2, F4_3 => F4_2
  | F4_3, F4_0 => F4_2 | F4_3, F4_1 => F4_3 | F4_3, F4_2 => F4_3 | F4_3, F4_3 => F4_0
  end.

#[local] Instance refa586_inst : Magma Fin4 := {| magma_op := refa586_op |}.

Lemma refa586_sat53 : @Equation53 Fin4 refa586_inst.
Proof. unfold Equation53, magma_op, refa586_inst, refa586_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa586_not50 : ~ @Equation50 Fin4 refa586_inst.
Proof. unfold Equation50. intro H. specialize (H F4_0 F4_2). unfold magma_op, refa586_inst, refa586_op in H. discriminate H. Qed.

Lemma refa586_not1023 : ~ @Equation1023 Fin4 refa586_inst.
Proof. unfold Equation1023. intro H. specialize (H F4_0 F4_2). unfold magma_op, refa586_inst, refa586_op in H. discriminate H. Qed.

Lemma refa586_not1028 : ~ @Equation1028 Fin4 refa586_inst.
Proof. unfold Equation1028. intro H. specialize (H F4_0 F4_2). unfold magma_op, refa586_inst, refa586_op in H. discriminate H. Qed.

Lemma refa586_not1046 : ~ @Equation1046 Fin4 refa586_inst.
Proof. unfold Equation1046. intro H. specialize (H F4_0 F4_2). unfold magma_op, refa586_inst, refa586_op in H. discriminate H. Qed.

Lemma refa586_not1632 : ~ @Equation1632 Fin4 refa586_inst.
Proof. unfold Equation1632. intro H. specialize (H F4_1 F4_2). unfold magma_op, refa586_inst, refa586_op in H. discriminate H. Qed.

Lemma refa586_not1637 : ~ @Equation1637 Fin4 refa586_inst.
Proof. unfold Equation1637. intro H. specialize (H F4_0 F4_2). unfold magma_op, refa586_inst, refa586_op in H. discriminate H. Qed.

Lemma refa586_not1654 : ~ @Equation1654 Fin4 refa586_inst.
Proof. unfold Equation1654. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa586_inst, refa586_op in H. discriminate H. Qed.

Lemma refa586_not1832 : ~ @Equation1832 Fin4 refa586_inst.
Proof. unfold Equation1832. intro H. specialize (H F4_1). unfold magma_op, refa586_inst, refa586_op in H. discriminate H. Qed.

Lemma refa586_not2441 : ~ @Equation2441 Fin4 refa586_inst.
Proof. unfold Equation2441. intro H. specialize (H F4_1). unfold magma_op, refa586_inst, refa586_op in H. discriminate H. Qed.

Lemma refa586_not2644 : ~ @Equation2644 Fin4 refa586_inst.
Proof. unfold Equation2644. intro H. specialize (H F4_1). unfold magma_op, refa586_inst, refa586_op in H. discriminate H. Qed.

Lemma refa586_not3050 : ~ @Equation3050 Fin4 refa586_inst.
Proof. unfold Equation3050. intro H. specialize (H F4_1). unfold magma_op, refa586_inst, refa586_op in H. discriminate H. Qed.

Lemma refa586_not3464 : ~ @Equation3464 Fin4 refa586_inst.
Proof. unfold Equation3464. intro H. specialize (H F4_0 F4_2). unfold magma_op, refa586_inst, refa586_op in H. discriminate H. Qed.

Lemma refa586_not3509 : ~ @Equation3509 Fin4 refa586_inst.
Proof. unfold Equation3509. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa586_inst, refa586_op in H. discriminate H. Qed.

Lemma refa586_not3518 : ~ @Equation3518 Fin4 refa586_inst.
Proof. unfold Equation3518. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa586_inst, refa586_op in H. discriminate H. Qed.

Lemma refa586_not3522 : ~ @Equation3522 Fin4 refa586_inst.
Proof. unfold Equation3522. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa586_inst, refa586_op in H. discriminate H. Qed.

Lemma refa586_not3662 : ~ @Equation3662 Fin4 refa586_inst.
Proof. unfold Equation3662. intro H. specialize (H F4_0 F4_2). unfold magma_op, refa586_inst, refa586_op in H. discriminate H. Qed.

Lemma refa586_not3665 : ~ @Equation3665 Fin4 refa586_inst.
Proof. unfold Equation3665. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa586_inst, refa586_op in H. discriminate H. Qed.

Lemma refa586_not3712 : ~ @Equation3712 Fin4 refa586_inst.
Proof. unfold Equation3712. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa586_inst, refa586_op in H. discriminate H. Qed.

Lemma refa586_not4118 : ~ @Equation4118 Fin4 refa586_inst.
Proof. unfold Equation4118. intro H. specialize (H F4_1 F4_2). unfold magma_op, refa586_inst, refa586_op in H. discriminate H. Qed.

Lemma refa586_not4127 : ~ @Equation4127 Fin4 refa586_inst.
Proof. unfold Equation4127. intro H. specialize (H F4_0 F4_2). unfold magma_op, refa586_inst, refa586_op in H. discriminate H. Qed.

Lemma refa586_not4270 : ~ @Equation4270 Fin4 refa586_inst.
Proof. unfold Equation4270. intro H. specialize (H F4_0 F4_2). unfold magma_op, refa586_inst, refa586_op in H. discriminate H. Qed.

Lemma refa586_not4656 : ~ @Equation4656 Fin4 refa586_inst.
Proof. unfold Equation4656. intro H. specialize (H F4_1 F4_0 F4_2). unfold magma_op, refa586_inst, refa586_op in H. discriminate H. Qed.

(** ---- refa587 (Fin4) ---- *)

Definition refa587_op (x y : Fin4) : Fin4 :=
  match x, y with
  | F4_0, F4_0 => F4_2 | F4_0, F4_1 => F4_1 | F4_0, F4_2 => F4_0 | F4_0, F4_3 => F4_3
  | F4_1, F4_0 => F4_3 | F4_1, F4_1 => F4_0 | F4_1, F4_2 => F4_1 | F4_1, F4_3 => F4_2
  | F4_2, F4_0 => F4_0 | F4_2, F4_1 => F4_3 | F4_2, F4_2 => F4_2 | F4_2, F4_3 => F4_1
  | F4_3, F4_0 => F4_1 | F4_3, F4_1 => F4_2 | F4_3, F4_2 => F4_3 | F4_3, F4_3 => F4_0
  end.

#[local] Instance refa587_inst : Magma Fin4 := {| magma_op := refa587_op |}.

Lemma refa587_sat546 : @Equation546 Fin4 refa587_inst.
Proof. unfold Equation546, magma_op, refa587_inst, refa587_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa587_sat861 : @Equation861 Fin4 refa587_inst.
Proof. unfold Equation861, magma_op, refa587_inst, refa587_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa587_sat1061 : @Equation1061 Fin4 refa587_inst.
Proof. unfold Equation1061, magma_op, refa587_inst, refa587_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa587_not419 : ~ @Equation419 Fin4 refa587_inst.
Proof. unfold Equation419. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa587_inst, refa587_op in H. discriminate H. Qed.

Lemma refa587_not427 : ~ @Equation427 Fin4 refa587_inst.
Proof. unfold Equation427. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa587_inst, refa587_op in H. discriminate H. Qed.

Lemma refa587_not436 : ~ @Equation436 Fin4 refa587_inst.
Proof. unfold Equation436. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa587_inst, refa587_op in H. discriminate H. Qed.

Lemma refa587_not466 : ~ @Equation466 Fin4 refa587_inst.
Proof. unfold Equation466. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa587_inst, refa587_op in H. discriminate H. Qed.

Lemma refa587_not477 : ~ @Equation477 Fin4 refa587_inst.
Proof. unfold Equation477. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa587_inst, refa587_op in H. discriminate H. Qed.

Lemma refa587_not511 : ~ @Equation511 Fin4 refa587_inst.
Proof. unfold Equation511. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa587_inst, refa587_op in H. discriminate H. Qed.

Lemma refa587_not614 : ~ @Equation614 Fin4 refa587_inst.
Proof. unfold Equation614. intro H. specialize (H F4_1). unfold magma_op, refa587_inst, refa587_op in H. discriminate H. Qed.

Lemma refa587_not835 : ~ @Equation835 Fin4 refa587_inst.
Proof. unfold Equation835. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa587_inst, refa587_op in H. discriminate H. Qed.

Lemma refa587_not842 : ~ @Equation842 Fin4 refa587_inst.
Proof. unfold Equation842. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa587_inst, refa587_op in H. discriminate H. Qed.

Lemma refa587_not870 : ~ @Equation870 Fin4 refa587_inst.
Proof. unfold Equation870. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa587_inst, refa587_op in H. discriminate H. Qed.

Lemma refa587_not883 : ~ @Equation883 Fin4 refa587_inst.
Proof. unfold Equation883. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa587_inst, refa587_op in H. discriminate H. Qed.

Lemma refa587_not906 : ~ @Equation906 Fin4 refa587_inst.
Proof. unfold Equation906. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa587_inst, refa587_op in H. discriminate H. Qed.

Lemma refa587_not1023 : ~ @Equation1023 Fin4 refa587_inst.
Proof. unfold Equation1023. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa587_inst, refa587_op in H. discriminate H. Qed.

Lemma refa587_not1028 : ~ @Equation1028 Fin4 refa587_inst.
Proof. unfold Equation1028. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa587_inst, refa587_op in H. discriminate H. Qed.

Lemma refa587_not1036 : ~ @Equation1036 Fin4 refa587_inst.
Proof. unfold Equation1036. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa587_inst, refa587_op in H. discriminate H. Qed.

Lemma refa587_not1045 : ~ @Equation1045 Fin4 refa587_inst.
Proof. unfold Equation1045. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa587_inst, refa587_op in H. discriminate H. Qed.

Lemma refa587_not1075 : ~ @Equation1075 Fin4 refa587_inst.
Proof. unfold Equation1075. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa587_inst, refa587_op in H. discriminate H. Qed.

Lemma refa587_not1086 : ~ @Equation1086 Fin4 refa587_inst.
Proof. unfold Equation1086. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa587_inst, refa587_op in H. discriminate H. Qed.

Lemma refa587_not1109 : ~ @Equation1109 Fin4 refa587_inst.
Proof. unfold Equation1109. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa587_inst, refa587_op in H. discriminate H. Qed.

Lemma refa587_not1223 : ~ @Equation1223 Fin4 refa587_inst.
Proof. unfold Equation1223. intro H. specialize (H F4_1). unfold magma_op, refa587_inst, refa587_op in H. discriminate H. Qed.

Lemma refa587_not1426 : ~ @Equation1426 Fin4 refa587_inst.
Proof. unfold Equation1426. intro H. specialize (H F4_1). unfold magma_op, refa587_inst, refa587_op in H. discriminate H. Qed.

Lemma refa587_not1635 : ~ @Equation1635 Fin4 refa587_inst.
Proof. unfold Equation1635. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa587_inst, refa587_op in H. discriminate H. Qed.

Lemma refa587_not1637 : ~ @Equation1637 Fin4 refa587_inst.
Proof. unfold Equation1637. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa587_inst, refa587_op in H. discriminate H. Qed.

Lemma refa587_not1645 : ~ @Equation1645 Fin4 refa587_inst.
Proof. unfold Equation1645. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa587_inst, refa587_op in H. discriminate H. Qed.

Lemma refa587_not1691 : ~ @Equation1691 Fin4 refa587_inst.
Proof. unfold Equation1691. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa587_inst, refa587_op in H. discriminate H. Qed.

Lemma refa587_not1722 : ~ @Equation1722 Fin4 refa587_inst.
Proof. unfold Equation1722. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa587_inst, refa587_op in H. discriminate H. Qed.

Lemma refa587_not1840 : ~ @Equation1840 Fin4 refa587_inst.
Proof. unfold Equation1840. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa587_inst, refa587_op in H. discriminate H. Qed.

Lemma refa587_not1848 : ~ @Equation1848 Fin4 refa587_inst.
Proof. unfold Equation1848. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa587_inst, refa587_op in H. discriminate H. Qed.

Lemma refa587_not1857 : ~ @Equation1857 Fin4 refa587_inst.
Proof. unfold Equation1857. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa587_inst, refa587_op in H. discriminate H. Qed.

Lemma refa587_not1887 : ~ @Equation1887 Fin4 refa587_inst.
Proof. unfold Equation1887. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa587_inst, refa587_op in H. discriminate H. Qed.

Lemma refa587_not1921 : ~ @Equation1921 Fin4 refa587_inst.
Proof. unfold Equation1921. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa587_inst, refa587_op in H. discriminate H. Qed.

Lemma refa587_not2035 : ~ @Equation2035 Fin4 refa587_inst.
Proof. unfold Equation2035. intro H. specialize (H F4_1). unfold magma_op, refa587_inst, refa587_op in H. discriminate H. Qed.

Lemma refa587_not2238 : ~ @Equation2238 Fin4 refa587_inst.
Proof. unfold Equation2238. intro H. specialize (H F4_1). unfold magma_op, refa587_inst, refa587_op in H. discriminate H. Qed.

Lemma refa587_not2444 : ~ @Equation2444 Fin4 refa587_inst.
Proof. unfold Equation2444. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa587_inst, refa587_op in H. discriminate H. Qed.

Lemma refa587_not2447 : ~ @Equation2447 Fin4 refa587_inst.
Proof. unfold Equation2447. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa587_inst, refa587_op in H. discriminate H. Qed.

Lemma refa587_not2459 : ~ @Equation2459 Fin4 refa587_inst.
Proof. unfold Equation2459. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa587_inst, refa587_op in H. discriminate H. Qed.

Lemma refa587_not2466 : ~ @Equation2466 Fin4 refa587_inst.
Proof. unfold Equation2466. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa587_inst, refa587_op in H. discriminate H. Qed.

Lemma refa587_not2530 : ~ @Equation2530 Fin4 refa587_inst.
Proof. unfold Equation2530. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa587_inst, refa587_op in H. discriminate H. Qed.

Lemma refa587_not2543 : ~ @Equation2543 Fin4 refa587_inst.
Proof. unfold Equation2543. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa587_inst, refa587_op in H. discriminate H. Qed.

Lemma refa587_not2647 : ~ @Equation2647 Fin4 refa587_inst.
Proof. unfold Equation2647. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa587_inst, refa587_op in H. discriminate H. Qed.

Lemma refa587_not2650 : ~ @Equation2650 Fin4 refa587_inst.
Proof. unfold Equation2650. intro H. specialize (H F4_1 F4_0). unfold magma_op, refa587_inst, refa587_op in H. discriminate H. Qed.

Lemma refa587_not2652 : ~ @Equation2652 Fin4 refa587_inst.
Proof. unfold Equation2652. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa587_inst, refa587_op in H. discriminate H. Qed.

Lemma refa587_not2660 : ~ @Equation2660 Fin4 refa587_inst.
Proof. unfold Equation2660. intro H. specialize (H F4_1 F4_0). unfold magma_op, refa587_inst, refa587_op in H. discriminate H. Qed.

Lemma refa587_not2662 : ~ @Equation2662 Fin4 refa587_inst.
Proof. unfold Equation2662. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa587_inst, refa587_op in H. discriminate H. Qed.

Lemma refa587_not2669 : ~ @Equation2669 Fin4 refa587_inst.
Proof. unfold Equation2669. intro H. specialize (H F4_1 F4_0). unfold magma_op, refa587_inst, refa587_op in H. discriminate H. Qed.

Lemma refa587_not2697 : ~ @Equation2697 Fin4 refa587_inst.
Proof. unfold Equation2697. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa587_inst, refa587_op in H. discriminate H. Qed.

Lemma refa587_not2699 : ~ @Equation2699 Fin4 refa587_inst.
Proof. unfold Equation2699. intro H. specialize (H F4_1 F4_0). unfold magma_op, refa587_inst, refa587_op in H. discriminate H. Qed.

Lemma refa587_not2706 : ~ @Equation2706 Fin4 refa587_inst.
Proof. unfold Equation2706. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa587_inst, refa587_op in H. discriminate H. Qed.

Lemma refa587_not2710 : ~ @Equation2710 Fin4 refa587_inst.
Proof. unfold Equation2710. intro H. specialize (H F4_1 F4_0). unfold magma_op, refa587_inst, refa587_op in H. discriminate H. Qed.

Lemma refa587_not2733 : ~ @Equation2733 Fin4 refa587_inst.
Proof. unfold Equation2733. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa587_inst, refa587_op in H. discriminate H. Qed.

Lemma refa587_not2744 : ~ @Equation2744 Fin4 refa587_inst.
Proof. unfold Equation2744. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa587_inst, refa587_op in H. discriminate H. Qed.

Lemma refa587_not2746 : ~ @Equation2746 Fin4 refa587_inst.
Proof. unfold Equation2746. intro H. specialize (H F4_1 F4_0). unfold magma_op, refa587_inst, refa587_op in H. discriminate H. Qed.

Lemma refa587_not2847 : ~ @Equation2847 Fin4 refa587_inst.
Proof. unfold Equation2847. intro H. specialize (H F4_1). unfold magma_op, refa587_inst, refa587_op in H. discriminate H. Qed.

Lemma refa587_not3105 : ~ @Equation3105 Fin4 refa587_inst.
Proof. unfold Equation3105. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa587_inst, refa587_op in H. discriminate H. Qed.

Lemma refa587_not3112 : ~ @Equation3112 Fin4 refa587_inst.
Proof. unfold Equation3112. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa587_inst, refa587_op in H. discriminate H. Qed.

Lemma refa587_not3116 : ~ @Equation3116 Fin4 refa587_inst.
Proof. unfold Equation3116. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa587_inst, refa587_op in H. discriminate H. Qed.

Lemma refa587_not3143 : ~ @Equation3143 Fin4 refa587_inst.
Proof. unfold Equation3143. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa587_inst, refa587_op in H. discriminate H. Qed.

Lemma refa587_not3150 : ~ @Equation3150 Fin4 refa587_inst.
Proof. unfold Equation3150. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa587_inst, refa587_op in H. discriminate H. Qed.

Lemma refa587_not3152 : ~ @Equation3152 Fin4 refa587_inst.
Proof. unfold Equation3152. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa587_inst, refa587_op in H. discriminate H. Qed.

Lemma refa587_not3253 : ~ @Equation3253 Fin4 refa587_inst.
Proof. unfold Equation3253. intro H. specialize (H F4_1). unfold magma_op, refa587_inst, refa587_op in H. discriminate H. Qed.

Lemma refa587_not3462 : ~ @Equation3462 Fin4 refa587_inst.
Proof. unfold Equation3462. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa587_inst, refa587_op in H. discriminate H. Qed.

Lemma refa587_not3464 : ~ @Equation3464 Fin4 refa587_inst.
Proof. unfold Equation3464. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa587_inst, refa587_op in H. discriminate H. Qed.

Lemma refa587_not3481 : ~ @Equation3481 Fin4 refa587_inst.
Proof. unfold Equation3481. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa587_inst, refa587_op in H. discriminate H. Qed.

Lemma refa587_not3509 : ~ @Equation3509 Fin4 refa587_inst.
Proof. unfold Equation3509. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa587_inst, refa587_op in H. discriminate H. Qed.

Lemma refa587_not3511 : ~ @Equation3511 Fin4 refa587_inst.
Proof. unfold Equation3511. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa587_inst, refa587_op in H. discriminate H. Qed.

Lemma refa587_not3545 : ~ @Equation3545 Fin4 refa587_inst.
Proof. unfold Equation3545. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa587_inst, refa587_op in H. discriminate H. Qed.

Lemma refa587_not3549 : ~ @Equation3549 Fin4 refa587_inst.
Proof. unfold Equation3549. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa587_inst, refa587_op in H. discriminate H. Qed.

Lemma refa587_not3659 : ~ @Equation3659 Fin4 refa587_inst.
Proof. unfold Equation3659. intro H. specialize (H F4_1). unfold magma_op, refa587_inst, refa587_op in H. discriminate H. Qed.

Lemma refa587_not3862 : ~ @Equation3862 Fin4 refa587_inst.
Proof. unfold Equation3862. intro H. specialize (H F4_1). unfold magma_op, refa587_inst, refa587_op in H. discriminate H. Qed.

Lemma refa587_not4083 : ~ @Equation4083 Fin4 refa587_inst.
Proof. unfold Equation4083. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa587_inst, refa587_op in H. discriminate H. Qed.

Lemma refa587_not4090 : ~ @Equation4090 Fin4 refa587_inst.
Proof. unfold Equation4090. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa587_inst, refa587_op in H. discriminate H. Qed.

Lemma refa587_not4158 : ~ @Equation4158 Fin4 refa587_inst.
Proof. unfold Equation4158. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa587_inst, refa587_op in H. discriminate H. Qed.

Lemma refa587_not4165 : ~ @Equation4165 Fin4 refa587_inst.
Proof. unfold Equation4165. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa587_inst, refa587_op in H. discriminate H. Qed.

Lemma refa587_not4167 : ~ @Equation4167 Fin4 refa587_inst.
Proof. unfold Equation4167. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa587_inst, refa587_op in H. discriminate H. Qed.

Lemma refa587_not4270 : ~ @Equation4270 Fin4 refa587_inst.
Proof. unfold Equation4270. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa587_inst, refa587_op in H. discriminate H. Qed.

Lemma refa587_not4275 : ~ @Equation4275 Fin4 refa587_inst.
Proof. unfold Equation4275. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa587_inst, refa587_op in H. discriminate H. Qed.

Lemma refa587_not4283 : ~ @Equation4283 Fin4 refa587_inst.
Proof. unfold Equation4283. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa587_inst, refa587_op in H. discriminate H. Qed.

Lemma refa587_not4320 : ~ @Equation4320 Fin4 refa587_inst.
Proof. unfold Equation4320. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa587_inst, refa587_op in H. discriminate H. Qed.

Lemma refa587_not4380 : ~ @Equation4380 Fin4 refa587_inst.
Proof. unfold Equation4380. intro H. specialize (H F4_1). unfold magma_op, refa587_inst, refa587_op in H. discriminate H. Qed.

Lemma refa587_not4588 : ~ @Equation4588 Fin4 refa587_inst.
Proof. unfold Equation4588. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa587_inst, refa587_op in H. discriminate H. Qed.

Lemma refa587_not4590 : ~ @Equation4590 Fin4 refa587_inst.
Proof. unfold Equation4590. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa587_inst, refa587_op in H. discriminate H. Qed.

Lemma refa587_not4605 : ~ @Equation4605 Fin4 refa587_inst.
Proof. unfold Equation4605. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa587_inst, refa587_op in H. discriminate H. Qed.

Lemma refa587_not4635 : ~ @Equation4635 Fin4 refa587_inst.
Proof. unfold Equation4635. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa587_inst, refa587_op in H. discriminate H. Qed.

(** ---- refa588 (Fin4) ---- *)

Definition refa588_op (x y : Fin4) : Fin4 :=
  match x, y with
  | F4_0, F4_0 => F4_3 | F4_0, F4_1 => F4_3 | F4_0, F4_2 => F4_1 | F4_0, F4_3 => F4_1
  | F4_1, F4_0 => F4_3 | F4_1, F4_1 => F4_3 | F4_1, F4_2 => F4_3 | F4_1, F4_3 => F4_2
  | F4_2, F4_0 => F4_3 | F4_2, F4_1 => F4_3 | F4_2, F4_2 => F4_2 | F4_2, F4_3 => F4_0
  | F4_3, F4_0 => F4_2 | F4_3, F4_1 => F4_0 | F4_3, F4_2 => F4_1 | F4_3, F4_3 => F4_1
  end.

#[local] Instance refa588_inst : Magma Fin4 := {| magma_op := refa588_op |}.

Lemma refa588_sat2125 : @Equation2125 Fin4 refa588_inst.
Proof. unfold Equation2125, magma_op, refa588_inst, refa588_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa588_not3456 : ~ @Equation3456 Fin4 refa588_inst.
Proof. unfold Equation3456. intro H. specialize (H F4_0). unfold magma_op, refa588_inst, refa588_op in H. discriminate H. Qed.

(** ---- refa589 (Fin4) ---- *)

Definition refa589_op (x y : Fin4) : Fin4 :=
  match x, y with
  | F4_0, F4_0 => F4_3 | F4_0, F4_1 => F4_3 | F4_0, F4_2 => F4_1 | F4_0, F4_3 => F4_3
  | F4_1, F4_0 => F4_3 | F4_1, F4_1 => F4_3 | F4_1, F4_2 => F4_0 | F4_1, F4_3 => F4_3
  | F4_2, F4_0 => F4_0 | F4_2, F4_1 => F4_1 | F4_2, F4_2 => F4_3 | F4_2, F4_3 => F4_3
  | F4_3, F4_0 => F4_3 | F4_3, F4_1 => F4_3 | F4_3, F4_2 => F4_3 | F4_3, F4_3 => F4_3
  end.

#[local] Instance refa589_inst : Magma Fin4 := {| magma_op := refa589_op |}.

Lemma refa589_sat4544 : @Equation4544 Fin4 refa589_inst.
Proof. unfold Equation4544, magma_op, refa589_inst, refa589_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa589_not4283 : ~ @Equation4283 Fin4 refa589_inst.
Proof. unfold Equation4283. intro H. specialize (H F4_2 F4_0). unfold magma_op, refa589_inst, refa589_op in H. discriminate H. Qed.

Lemma refa589_not4290 : ~ @Equation4290 Fin4 refa589_inst.
Proof. unfold Equation4290. intro H. specialize (H F4_2 F4_0). unfold magma_op, refa589_inst, refa589_op in H. discriminate H. Qed.

Lemma refa589_not4320 : ~ @Equation4320 Fin4 refa589_inst.
Proof. unfold Equation4320. intro H. specialize (H F4_2 F4_0). unfold magma_op, refa589_inst, refa589_op in H. discriminate H. Qed.

Lemma refa589_not4396 : ~ @Equation4396 Fin4 refa589_inst.
Proof. unfold Equation4396. intro H. specialize (H F4_2 F4_0). unfold magma_op, refa589_inst, refa589_op in H. discriminate H. Qed.

Lemma refa589_not4398 : ~ @Equation4398 Fin4 refa589_inst.
Proof. unfold Equation4398. intro H. specialize (H F4_2 F4_0). unfold magma_op, refa589_inst, refa589_op in H. discriminate H. Qed.

Lemma refa589_not4433 : ~ @Equation4433 Fin4 refa589_inst.
Proof. unfold Equation4433. intro H. specialize (H F4_2 F4_0). unfold magma_op, refa589_inst, refa589_op in H. discriminate H. Qed.

Lemma refa589_not4442 : ~ @Equation4442 Fin4 refa589_inst.
Proof. unfold Equation4442. intro H. specialize (H F4_2 F4_0). unfold magma_op, refa589_inst, refa589_op in H. discriminate H. Qed.

Lemma refa589_not4473 : ~ @Equation4473 Fin4 refa589_inst.
Proof. unfold Equation4473. intro H. specialize (H F4_0 F4_2). unfold magma_op, refa589_inst, refa589_op in H. discriminate H. Qed.

Lemma refa589_not4480 : ~ @Equation4480 Fin4 refa589_inst.
Proof. unfold Equation4480. intro H. specialize (H F4_0 F4_2). unfold magma_op, refa589_inst, refa589_op in H. discriminate H. Qed.

Lemma refa589_not4598 : ~ @Equation4598 Fin4 refa589_inst.
Proof. unfold Equation4598. intro H. specialize (H F4_2 F4_0). unfold magma_op, refa589_inst, refa589_op in H. discriminate H. Qed.

Lemma refa589_not4605 : ~ @Equation4605 Fin4 refa589_inst.
Proof. unfold Equation4605. intro H. specialize (H F4_2 F4_0). unfold magma_op, refa589_inst, refa589_op in H. discriminate H. Qed.

Lemma refa589_not4635 : ~ @Equation4635 Fin4 refa589_inst.
Proof. unfold Equation4635. intro H. specialize (H F4_2 F4_0). unfold magma_op, refa589_inst, refa589_op in H. discriminate H. Qed.

(** ---- refa59 (Fin3) ---- *)

Definition refa59_op (x y : Fin3) : Fin3 :=
  match x, y with
  | F3_0, F3_0 => F3_0 | F3_0, F3_1 => F3_1 | F3_0, F3_2 => F3_2
  | F3_1, F3_0 => F3_0 | F3_1, F3_1 => F3_0 | F3_1, F3_2 => F3_2
  | F3_2, F3_0 => F3_1 | F3_2, F3_1 => F3_1 | F3_2, F3_2 => F3_0
  end.

#[local] Instance refa59_inst : Magma Fin3 := {| magma_op := refa59_op |}.

Lemma refa59_sat2273 : @Equation2273 Fin3 refa59_inst.
Proof. unfold Equation2273, magma_op, refa59_inst, refa59_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa59_sat2571 : @Equation2571 Fin3 refa59_inst.
Proof. unfold Equation2571, magma_op, refa59_inst, refa59_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa59_sat3197 : @Equation3197 Fin3 refa59_inst.
Proof. unfold Equation3197, magma_op, refa59_inst, refa59_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa59_sat3519 : @Equation3519 Fin3 refa59_inst.
Proof. unfold Equation3519, magma_op, refa59_inst, refa59_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa59_sat3749 : @Equation3749 Fin3 refa59_inst.
Proof. unfold Equation3749, magma_op, refa59_inst, refa59_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa59_sat4105 : @Equation4105 Fin3 refa59_inst.
Proof. unfold Equation4105, magma_op, refa59_inst, refa59_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa59_sat4128 : @Equation4128 Fin3 refa59_inst.
Proof. unfold Equation4128, magma_op, refa59_inst, refa59_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa59_not231 : ~ @Equation231 Fin3 refa59_inst.
Proof. unfold Equation231. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa59_inst, refa59_op in H. discriminate H. Qed.

Lemma refa59_not1631 : ~ @Equation1631 Fin3 refa59_inst.
Proof. unfold Equation1631. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa59_inst, refa59_op in H. discriminate H. Qed.

Lemma refa59_not1644 : ~ @Equation1644 Fin3 refa59_inst.
Proof. unfold Equation1644. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa59_inst, refa59_op in H. discriminate H. Qed.

Lemma refa59_not1657 : ~ @Equation1657 Fin3 refa59_inst.
Proof. unfold Equation1657. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa59_inst, refa59_op in H. discriminate H. Qed.

Lemma refa59_not1721 : ~ @Equation1721 Fin3 refa59_inst.
Proof. unfold Equation1721. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa59_inst, refa59_op in H. discriminate H. Qed.

Lemma refa59_not2240 : ~ @Equation2240 Fin3 refa59_inst.
Proof. unfold Equation2240. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa59_inst, refa59_op in H. discriminate H. Qed.

Lemma refa59_not2290 : ~ @Equation2290 Fin3 refa59_inst.
Proof. unfold Equation2290. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa59_inst, refa59_op in H. discriminate H. Qed.

Lemma refa59_not2300 : ~ @Equation2300 Fin3 refa59_inst.
Proof. unfold Equation2300. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa59_inst, refa59_op in H. discriminate H. Qed.

Lemma refa59_not2303 : ~ @Equation2303 Fin3 refa59_inst.
Proof. unfold Equation2303. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa59_inst, refa59_op in H. discriminate H. Qed.

Lemma refa59_not2327 : ~ @Equation2327 Fin3 refa59_inst.
Proof. unfold Equation2327. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa59_inst, refa59_op in H. discriminate H. Qed.

Lemma refa59_not2330 : ~ @Equation2330 Fin3 refa59_inst.
Proof. unfold Equation2330. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa59_inst, refa59_op in H. discriminate H. Qed.

Lemma refa59_not2340 : ~ @Equation2340 Fin3 refa59_inst.
Proof. unfold Equation2340. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa59_inst, refa59_op in H. discriminate H. Qed.

Lemma refa59_not2443 : ~ @Equation2443 Fin3 refa59_inst.
Proof. unfold Equation2443. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa59_inst, refa59_op in H. discriminate H. Qed.

Lemma refa59_not2459 : ~ @Equation2459 Fin3 refa59_inst.
Proof. unfold Equation2459. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa59_inst, refa59_op in H. discriminate H. Qed.

Lemma refa59_not2469 : ~ @Equation2469 Fin3 refa59_inst.
Proof. unfold Equation2469. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa59_inst, refa59_op in H. discriminate H. Qed.

Lemma refa59_not2506 : ~ @Equation2506 Fin3 refa59_inst.
Proof. unfold Equation2506. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa59_inst, refa59_op in H. discriminate H. Qed.

Lemma refa59_not2530 : ~ @Equation2530 Fin3 refa59_inst.
Proof. unfold Equation2530. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa59_inst, refa59_op in H. discriminate H. Qed.

Lemma refa59_not2646 : ~ @Equation2646 Fin3 refa59_inst.
Proof. unfold Equation2646. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa59_inst, refa59_op in H. discriminate H. Qed.

Lemma refa59_not2659 : ~ @Equation2659 Fin3 refa59_inst.
Proof. unfold Equation2659. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa59_inst, refa59_op in H. discriminate H. Qed.

Lemma refa59_not2672 : ~ @Equation2672 Fin3 refa59_inst.
Proof. unfold Equation2672. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa59_inst, refa59_op in H. discriminate H. Qed.

Lemma refa59_not2699 : ~ @Equation2699 Fin3 refa59_inst.
Proof. unfold Equation2699. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa59_inst, refa59_op in H. discriminate H. Qed.

Lemma refa59_not2736 : ~ @Equation2736 Fin3 refa59_inst.
Proof. unfold Equation2736. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa59_inst, refa59_op in H. discriminate H. Qed.

Lemma refa59_not3052 : ~ @Equation3052 Fin3 refa59_inst.
Proof. unfold Equation3052. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa59_inst, refa59_op in H. discriminate H. Qed.

Lemma refa59_not3068 : ~ @Equation3068 Fin3 refa59_inst.
Proof. unfold Equation3068. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa59_inst, refa59_op in H. discriminate H. Qed.

Lemma refa59_not3105 : ~ @Equation3105 Fin3 refa59_inst.
Proof. unfold Equation3105. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa59_inst, refa59_op in H. discriminate H. Qed.

Lemma refa59_not3142 : ~ @Equation3142 Fin3 refa59_inst.
Proof. unfold Equation3142. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa59_inst, refa59_op in H. discriminate H. Qed.

Lemma refa59_not3253 : ~ @Equation3253 Fin3 refa59_inst.
Proof. unfold Equation3253. intro H. specialize (H F3_2). unfold magma_op, refa59_inst, refa59_op in H. discriminate H. Qed.

Lemma refa59_not3458 : ~ @Equation3458 Fin3 refa59_inst.
Proof. unfold Equation3458. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa59_inst, refa59_op in H. discriminate H. Qed.

Lemma refa59_not3459 : ~ @Equation3459 Fin3 refa59_inst.
Proof. unfold Equation3459. intro H. specialize (H F3_2 F3_0). unfold magma_op, refa59_inst, refa59_op in H. discriminate H. Qed.

Lemma refa59_not3461 : ~ @Equation3461 Fin3 refa59_inst.
Proof. unfold Equation3461. intro H. specialize (H F3_2 F3_0). unfold magma_op, refa59_inst, refa59_op in H. discriminate H. Qed.

Lemma refa59_not3481 : ~ @Equation3481 Fin3 refa59_inst.
Proof. unfold Equation3481. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa59_inst, refa59_op in H. discriminate H. Qed.

Lemma refa59_not3664 : ~ @Equation3664 Fin3 refa59_inst.
Proof. unfold Equation3664. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa59_inst, refa59_op in H. discriminate H. Qed.

Lemma refa59_not3668 : ~ @Equation3668 Fin3 refa59_inst.
Proof. unfold Equation3668. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa59_inst, refa59_op in H. discriminate H. Qed.

Lemma refa59_not3674 : ~ @Equation3674 Fin3 refa59_inst.
Proof. unfold Equation3674. intro H. specialize (H F3_2 F3_0). unfold magma_op, refa59_inst, refa59_op in H. discriminate H. Qed.

Lemma refa59_not4131 : ~ @Equation4131 Fin3 refa59_inst.
Proof. unfold Equation4131. intro H. specialize (H F3_2 F3_0). unfold magma_op, refa59_inst, refa59_op in H. discriminate H. Qed.

Lemma refa59_not4138 : ~ @Equation4138 Fin3 refa59_inst.
Proof. unfold Equation4138. intro H. specialize (H F3_0 F3_1 F3_2). unfold magma_op, refa59_inst, refa59_op in H. discriminate H. Qed.

Lemma refa59_not4155 : ~ @Equation4155 Fin3 refa59_inst.
Proof. unfold Equation4155. intro H. specialize (H F3_2 F3_0). unfold magma_op, refa59_inst, refa59_op in H. discriminate H. Qed.

Lemma refa59_not4269 : ~ @Equation4269 Fin3 refa59_inst.
Proof. unfold Equation4269. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa59_inst, refa59_op in H. discriminate H. Qed.

Lemma refa59_not4272 : ~ @Equation4272 Fin3 refa59_inst.
Proof. unfold Equation4272. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa59_inst, refa59_op in H. discriminate H. Qed.

Lemma refa59_not4314 : ~ @Equation4314 Fin3 refa59_inst.
Proof. unfold Equation4314. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa59_inst, refa59_op in H. discriminate H. Qed.

Lemma refa59_not4320 : ~ @Equation4320 Fin3 refa59_inst.
Proof. unfold Equation4320. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa59_inst, refa59_op in H. discriminate H. Qed.

Lemma refa59_not4606 : ~ @Equation4606 Fin3 refa59_inst.
Proof. unfold Equation4606. intro H. specialize (H F3_2 F3_0). unfold magma_op, refa59_inst, refa59_op in H. discriminate H. Qed.

Lemma refa59_not4631 : ~ @Equation4631 Fin3 refa59_inst.
Proof. unfold Equation4631. intro H. specialize (H F3_0 F3_0 F3_2). unfold magma_op, refa59_inst, refa59_op in H. discriminate H. Qed.

(** ---- refa590 (Fin4) ---- *)

Definition refa590_op (x y : Fin4) : Fin4 :=
  match x, y with
  | F4_0, F4_0 => F4_3 | F4_0, F4_1 => F4_2 | F4_0, F4_2 => F4_2 | F4_0, F4_3 => F4_3
  | F4_1, F4_0 => F4_3 | F4_1, F4_1 => F4_2 | F4_1, F4_2 => F4_0 | F4_1, F4_3 => F4_3
  | F4_2, F4_0 => F4_3 | F4_2, F4_1 => F4_0 | F4_2, F4_2 => F4_3 | F4_2, F4_3 => F4_3
  | F4_3, F4_0 => F4_0 | F4_3, F4_1 => F4_1 | F4_3, F4_2 => F4_2 | F4_3, F4_3 => F4_3
  end.

#[local] Instance refa590_inst : Magma Fin4 := {| magma_op := refa590_op |}.

Lemma refa590_sat2330 : @Equation2330 Fin4 refa590_inst.
Proof. unfold Equation2330, magma_op, refa590_inst, refa590_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa590_not203 : ~ @Equation203 Fin4 refa590_inst.
Proof. unfold Equation203. intro H. specialize (H F4_1). unfold magma_op, refa590_inst, refa590_op in H. discriminate H. Qed.

Lemma refa590_not2240 : ~ @Equation2240 Fin4 refa590_inst.
Proof. unfold Equation2240. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa590_inst, refa590_op in H. discriminate H. Qed.

Lemma refa590_not2246 : ~ @Equation2246 Fin4 refa590_inst.
Proof. unfold Equation2246. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa590_inst, refa590_op in H. discriminate H. Qed.

Lemma refa590_not2293 : ~ @Equation2293 Fin4 refa590_inst.
Proof. unfold Equation2293. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa590_inst, refa590_op in H. discriminate H. Qed.

Lemma refa590_not2303 : ~ @Equation2303 Fin4 refa590_inst.
Proof. unfold Equation2303. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa590_inst, refa590_op in H. discriminate H. Qed.

(** ---- refa591 (Fin4) ---- *)

Definition refa591_op (x y : Fin4) : Fin4 :=
  match x, y with
  | F4_0, F4_0 => F4_1 | F4_0, F4_1 => F4_0 | F4_0, F4_2 => F4_0 | F4_0, F4_3 => F4_3
  | F4_1, F4_0 => F4_0 | F4_1, F4_1 => F4_3 | F4_1, F4_2 => F4_3 | F4_1, F4_3 => F4_1
  | F4_2, F4_0 => F4_0 | F4_2, F4_1 => F4_3 | F4_2, F4_2 => F4_3 | F4_2, F4_3 => F4_2
  | F4_3, F4_0 => F4_3 | F4_3, F4_1 => F4_1 | F4_3, F4_2 => F4_0 | F4_3, F4_3 => F4_0
  end.

#[local] Instance refa591_inst : Magma Fin4 := {| magma_op := refa591_op |}.

Lemma refa591_sat430 : @Equation430 Fin4 refa591_inst.
Proof. unfold Equation430, magma_op, refa591_inst, refa591_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa591_not1038 : ~ @Equation1038 Fin4 refa591_inst.
Proof. unfold Equation1038. intro H. specialize (H F4_2 F4_3). unfold magma_op, refa591_inst, refa591_op in H. discriminate H. Qed.

Lemma refa591_not1223 : ~ @Equation1223 Fin4 refa591_inst.
Proof. unfold Equation1223. intro H. specialize (H F4_2). unfold magma_op, refa591_inst, refa591_op in H. discriminate H. Qed.

Lemma refa591_not4065 : ~ @Equation4065 Fin4 refa591_inst.
Proof. unfold Equation4065. intro H. specialize (H F4_2). unfold magma_op, refa591_inst, refa591_op in H. discriminate H. Qed.

(** ---- refa592 (Fin4) ---- *)

Definition refa592_op (x y : Fin4) : Fin4 :=
  match x, y with
  | F4_0, F4_0 => F4_3 | F4_0, F4_1 => F4_1 | F4_0, F4_2 => F4_0 | F4_0, F4_3 => F4_1
  | F4_1, F4_0 => F4_3 | F4_1, F4_1 => F4_2 | F4_1, F4_2 => F4_1 | F4_1, F4_3 => F4_1
  | F4_2, F4_0 => F4_2 | F4_2, F4_1 => F4_2 | F4_2, F4_2 => F4_2 | F4_2, F4_3 => F4_2
  | F4_3, F4_0 => F4_2 | F4_3, F4_1 => F4_2 | F4_3, F4_2 => F4_3 | F4_3, F4_3 => F4_3
  end.

#[local] Instance refa592_inst : Magma Fin4 := {| magma_op := refa592_op |}.

Lemma refa592_sat1243 : @Equation1243 Fin4 refa592_inst.
Proof. unfold Equation1243, magma_op, refa592_inst, refa592_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa592_sat1245 : @Equation1245 Fin4 refa592_inst.
Proof. unfold Equation1245, magma_op, refa592_inst, refa592_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa592_sat1259 : @Equation1259 Fin4 refa592_inst.
Proof. unfold Equation1259, magma_op, refa592_inst, refa592_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa592_not1020 : ~ @Equation1020 Fin4 refa592_inst.
Proof. unfold Equation1020. intro H. specialize (H F4_0). unfold magma_op, refa592_inst, refa592_op in H. discriminate H. Qed.

Lemma refa592_not1252 : ~ @Equation1252 Fin4 refa592_inst.
Proof. unfold Equation1252. intro H. specialize (H F4_0 F4_3). unfold magma_op, refa592_inst, refa592_op in H. discriminate H. Qed.

(** ---- refa593 (Fin4) ---- *)

Definition refa593_op (x y : Fin4) : Fin4 :=
  match x, y with
  | F4_0, F4_0 => F4_3 | F4_0, F4_1 => F4_2 | F4_0, F4_2 => F4_0 | F4_0, F4_3 => F4_1
  | F4_1, F4_0 => F4_3 | F4_1, F4_1 => F4_3 | F4_1, F4_2 => F4_0 | F4_1, F4_3 => F4_2
  | F4_2, F4_0 => F4_1 | F4_2, F4_1 => F4_3 | F4_2, F4_2 => F4_3 | F4_2, F4_3 => F4_2
  | F4_3, F4_0 => F4_0 | F4_3, F4_1 => F4_1 | F4_3, F4_2 => F4_2 | F4_3, F4_3 => F4_3
  end.

#[local] Instance refa593_inst : Magma Fin4 := {| magma_op := refa593_op |}.

Lemma refa593_sat2998 : @Equation2998 Fin4 refa593_inst.
Proof. unfold Equation2998, magma_op, refa593_inst, refa593_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa593_not2238 : ~ @Equation2238 Fin4 refa593_inst.
Proof. unfold Equation2238. intro H. specialize (H F4_0). unfold magma_op, refa593_inst, refa593_op in H. discriminate H. Qed.

Lemma refa593_not2449 : ~ @Equation2449 Fin4 refa593_inst.
Proof. unfold Equation2449. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa593_inst, refa593_op in H. discriminate H. Qed.

Lemma refa593_not2459 : ~ @Equation2459 Fin4 refa593_inst.
Proof. unfold Equation2459. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa593_inst, refa593_op in H. discriminate H. Qed.

Lemma refa593_not2503 : ~ @Equation2503 Fin4 refa593_inst.
Proof. unfold Equation2503. intro H. specialize (H F4_0 F4_2). unfold magma_op, refa593_inst, refa593_op in H. discriminate H. Qed.

Lemma refa593_not2530 : ~ @Equation2530 Fin4 refa593_inst.
Proof. unfold Equation2530. intro H. specialize (H F4_0 F4_2). unfold magma_op, refa593_inst, refa593_op in H. discriminate H. Qed.

Lemma refa593_not2669 : ~ @Equation2669 Fin4 refa593_inst.
Proof. unfold Equation2669. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa593_inst, refa593_op in H. discriminate H. Qed.

Lemma refa593_not2699 : ~ @Equation2699 Fin4 refa593_inst.
Proof. unfold Equation2699. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa593_inst, refa593_op in H. discriminate H. Qed.

Lemma refa593_not2855 : ~ @Equation2855 Fin4 refa593_inst.
Proof. unfold Equation2855. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa593_inst, refa593_op in H. discriminate H. Qed.

Lemma refa593_not2936 : ~ @Equation2936 Fin4 refa593_inst.
Proof. unfold Equation2936. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa593_inst, refa593_op in H. discriminate H. Qed.

Lemma refa593_not3068 : ~ @Equation3068 Fin4 refa593_inst.
Proof. unfold Equation3068. intro H. specialize (H F4_0 F4_2). unfold magma_op, refa593_inst, refa593_op in H. discriminate H. Qed.

Lemma refa593_not3075 : ~ @Equation3075 Fin4 refa593_inst.
Proof. unfold Equation3075. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa593_inst, refa593_op in H. discriminate H. Qed.

Lemma refa593_not3105 : ~ @Equation3105 Fin4 refa593_inst.
Proof. unfold Equation3105. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa593_inst, refa593_op in H. discriminate H. Qed.

Lemma refa593_not3112 : ~ @Equation3112 Fin4 refa593_inst.
Proof. unfold Equation3112. intro H. specialize (H F4_2 F4_0). unfold magma_op, refa593_inst, refa593_op in H. discriminate H. Qed.

Lemma refa593_not3474 : ~ @Equation3474 Fin4 refa593_inst.
Proof. unfold Equation3474. intro H. specialize (H F4_0 F4_2). unfold magma_op, refa593_inst, refa593_op in H. discriminate H. Qed.

Lemma refa593_not3667 : ~ @Equation3667 Fin4 refa593_inst.
Proof. unfold Equation3667. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa593_inst, refa593_op in H. discriminate H. Qed.

Lemma refa593_not4320 : ~ @Equation4320 Fin4 refa593_inst.
Proof. unfold Equation4320. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa593_inst, refa593_op in H. discriminate H. Qed.

(** ---- refa594 (Fin4) ---- *)

Definition refa594_op (x y : Fin4) : Fin4 :=
  match x, y with
  | F4_0, F4_0 => F4_3 | F4_0, F4_1 => F4_1 | F4_0, F4_2 => F4_3 | F4_0, F4_3 => F4_1
  | F4_1, F4_0 => F4_3 | F4_1, F4_1 => F4_1 | F4_1, F4_2 => F4_3 | F4_1, F4_3 => F4_1
  | F4_2, F4_0 => F4_2 | F4_2, F4_1 => F4_0 | F4_2, F4_2 => F4_2 | F4_2, F4_3 => F4_0
  | F4_3, F4_0 => F4_2 | F4_3, F4_1 => F4_0 | F4_3, F4_2 => F4_2 | F4_3, F4_3 => F4_1
  end.

#[local] Instance refa594_inst : Magma Fin4 := {| magma_op := refa594_op |}.

Lemma refa594_sat1480 : @Equation1480 Fin4 refa594_inst.
Proof. unfold Equation1480, magma_op, refa594_inst, refa594_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa594_not151 : ~ @Equation151 Fin4 refa594_inst.
Proof. unfold Equation151. intro H. specialize (H F4_0). unfold magma_op, refa594_inst, refa594_op in H. discriminate H. Qed.

Lemma refa594_not1428 : ~ @Equation1428 Fin4 refa594_inst.
Proof. unfold Equation1428. intro H. specialize (H F4_0 F4_2). unfold magma_op, refa594_inst, refa594_op in H. discriminate H. Qed.

Lemma refa594_not1429 : ~ @Equation1429 Fin4 refa594_inst.
Proof. unfold Equation1429. intro H. specialize (H F4_0 F4_2). unfold magma_op, refa594_inst, refa594_op in H. discriminate H. Qed.

Lemma refa594_not3456 : ~ @Equation3456 Fin4 refa594_inst.
Proof. unfold Equation3456. intro H. specialize (H F4_3). unfold magma_op, refa594_inst, refa594_op in H. discriminate H. Qed.
