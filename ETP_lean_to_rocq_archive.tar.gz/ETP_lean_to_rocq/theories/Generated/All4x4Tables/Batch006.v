(** * All4x4 counterexamples — batch 6
    Auto-generated from Lean4 All4x4 files. *)

From Stdlib Require Import Utf8.

From ETP Require Import Magma.
From ETP Require Import FinMagma.
From ETP.Equations Require Import All.

Open Scope magma_scope.

(** ---- refa323 (Fin4) ---- *)

Definition refa323_op (x y : Fin4) : Fin4 :=
  match x, y with
  | F4_0, F4_0 => F4_3 | F4_0, F4_1 => F4_1 | F4_0, F4_2 => F4_1 | F4_0, F4_3 => F4_1
  | F4_1, F4_0 => F4_3 | F4_1, F4_1 => F4_3 | F4_1, F4_2 => F4_0 | F4_1, F4_3 => F4_0
  | F4_2, F4_0 => F4_2 | F4_2, F4_1 => F4_2 | F4_2, F4_2 => F4_2 | F4_2, F4_3 => F4_0
  | F4_3, F4_0 => F4_2 | F4_3, F4_1 => F4_1 | F4_3, F4_2 => F4_1 | F4_3, F4_3 => F4_1
  end.

#[local] Instance refa323_inst : Magma Fin4 := {| magma_op := refa323_op |}.

Lemma refa323_sat1843 : @Equation1843 Fin4 refa323_inst.
Proof. unfold Equation1843, magma_op, refa323_inst, refa323_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa323_not4065 : ~ @Equation4065 Fin4 refa323_inst.
Proof. unfold Equation4065. intro H. specialize (H F4_0). unfold magma_op, refa323_inst, refa323_op in H. discriminate H. Qed.

(** ---- refa324 (Fin4) ---- *)

Definition refa324_op (x y : Fin4) : Fin4 :=
  match x, y with
  | F4_0, F4_0 => F4_1 | F4_0, F4_1 => F4_0 | F4_0, F4_2 => F4_0 | F4_0, F4_3 => F4_3
  | F4_1, F4_0 => F4_1 | F4_1, F4_1 => F4_3 | F4_1, F4_2 => F4_1 | F4_1, F4_3 => F4_0
  | F4_2, F4_0 => F4_2 | F4_2, F4_1 => F4_0 | F4_2, F4_2 => F4_1 | F4_2, F4_3 => F4_0
  | F4_3, F4_0 => F4_1 | F4_3, F4_1 => F4_0 | F4_3, F4_2 => F4_0 | F4_3, F4_3 => F4_3
  end.

#[local] Instance refa324_inst : Magma Fin4 := {| magma_op := refa324_op |}.

Lemma refa324_sat1063 : @Equation1063 Fin4 refa324_inst.
Proof. unfold Equation1063, magma_op, refa324_inst, refa324_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa324_not99 : ~ @Equation99 Fin4 refa324_inst.
Proof. unfold Equation99. intro H. specialize (H F4_2). unfold magma_op, refa324_inst, refa324_op in H. discriminate H. Qed.

Lemma refa324_not1038 : ~ @Equation1038 Fin4 refa324_inst.
Proof. unfold Equation1038. intro H. specialize (H F4_1 F4_3). unfold magma_op, refa324_inst, refa324_op in H. discriminate H. Qed.

Lemma refa324_not1223 : ~ @Equation1223 Fin4 refa324_inst.
Proof. unfold Equation1223. intro H. specialize (H F4_2). unfold magma_op, refa324_inst, refa324_op in H. discriminate H. Qed.

Lemma refa324_not3253 : ~ @Equation3253 Fin4 refa324_inst.
Proof. unfold Equation3253. intro H. specialize (H F4_1). unfold magma_op, refa324_inst, refa324_op in H. discriminate H. Qed.

Lemma refa324_not3659 : ~ @Equation3659 Fin4 refa324_inst.
Proof. unfold Equation3659. intro H. specialize (H F4_0). unfold magma_op, refa324_inst, refa324_op in H. discriminate H. Qed.

Lemma refa324_not4270 : ~ @Equation4270 Fin4 refa324_inst.
Proof. unfold Equation4270. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa324_inst, refa324_op in H. discriminate H. Qed.

(** ---- refa325 (Fin4) ---- *)

Definition refa325_op (x y : Fin4) : Fin4 :=
  match x, y with
  | F4_0, F4_0 => F4_2 | F4_0, F4_1 => F4_2 | F4_0, F4_2 => F4_0 | F4_0, F4_3 => F4_3
  | F4_1, F4_0 => F4_2 | F4_1, F4_1 => F4_2 | F4_1, F4_2 => F4_3 | F4_1, F4_3 => F4_3
  | F4_2, F4_0 => F4_0 | F4_2, F4_1 => F4_1 | F4_2, F4_2 => F4_3 | F4_2, F4_3 => F4_2
  | F4_3, F4_0 => F4_3 | F4_3, F4_1 => F4_3 | F4_3, F4_2 => F4_2 | F4_3, F4_3 => F4_0
  end.

#[local] Instance refa325_inst : Magma Fin4 := {| magma_op := refa325_op |}.

Lemma refa325_sat3142 : @Equation3142 Fin4 refa325_inst.
Proof. unfold Equation3142, magma_op, refa325_inst, refa325_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa325_not2238 : ~ @Equation2238 Fin4 refa325_inst.
Proof. unfold Equation2238. intro H. specialize (H F4_1). unfold magma_op, refa325_inst, refa325_op in H. discriminate H. Qed.

Lemma refa325_not2459 : ~ @Equation2459 Fin4 refa325_inst.
Proof. unfold Equation2459. intro H. specialize (H F4_1 F4_2). unfold magma_op, refa325_inst, refa325_op in H. discriminate H. Qed.

Lemma refa325_not2496 : ~ @Equation2496 Fin4 refa325_inst.
Proof. unfold Equation2496. intro H. specialize (H F4_3 F4_1). unfold magma_op, refa325_inst, refa325_op in H. discriminate H. Qed.

Lemma refa325_not3253 : ~ @Equation3253 Fin4 refa325_inst.
Proof. unfold Equation3253. intro H. specialize (H F4_1). unfold magma_op, refa325_inst, refa325_op in H. discriminate H. Qed.

(** ---- refa326 (Fin4) ---- *)

Definition refa326_op (x y : Fin4) : Fin4 :=
  match x, y with
  | F4_0, F4_0 => F4_1 | F4_0, F4_1 => F4_0 | F4_0, F4_2 => F4_3 | F4_0, F4_3 => F4_3
  | F4_1, F4_0 => F4_3 | F4_1, F4_1 => F4_2 | F4_1, F4_2 => F4_1 | F4_1, F4_3 => F4_3
  | F4_2, F4_0 => F4_2 | F4_2, F4_1 => F4_3 | F4_2, F4_2 => F4_0 | F4_2, F4_3 => F4_3
  | F4_3, F4_0 => F4_0 | F4_3, F4_1 => F4_1 | F4_3, F4_2 => F4_2 | F4_3, F4_3 => F4_3
  end.

#[local] Instance refa326_inst : Magma Fin4 := {| magma_op := refa326_op |}.

Lemma refa326_sat2609 : @Equation2609 Fin4 refa326_inst.
Proof. unfold Equation2609, magma_op, refa326_inst, refa326_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa326_not151 : ~ @Equation151 Fin4 refa326_inst.
Proof. unfold Equation151. intro H. specialize (H F4_0). unfold magma_op, refa326_inst, refa326_op in H. discriminate H. Qed.

Lemma refa326_not203 : ~ @Equation203 Fin4 refa326_inst.
Proof. unfold Equation203. intro H. specialize (H F4_0). unfold magma_op, refa326_inst, refa326_op in H. discriminate H. Qed.

Lemma refa326_not2238 : ~ @Equation2238 Fin4 refa326_inst.
Proof. unfold Equation2238. intro H. specialize (H F4_0). unfold magma_op, refa326_inst, refa326_op in H. discriminate H. Qed.

Lemma refa326_not2449 : ~ @Equation2449 Fin4 refa326_inst.
Proof. unfold Equation2449. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa326_inst, refa326_op in H. discriminate H. Qed.

Lemma refa326_not2459 : ~ @Equation2459 Fin4 refa326_inst.
Proof. unfold Equation2459. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa326_inst, refa326_op in H. discriminate H. Qed.

Lemma refa326_not2496 : ~ @Equation2496 Fin4 refa326_inst.
Proof. unfold Equation2496. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa326_inst, refa326_op in H. discriminate H. Qed.

Lemma refa326_not4380 : ~ @Equation4380 Fin4 refa326_inst.
Proof. unfold Equation4380. intro H. specialize (H F4_0). unfold magma_op, refa326_inst, refa326_op in H. discriminate H. Qed.

(** ---- refa327 (Fin4) ---- *)

Definition refa327_op (x y : Fin4) : Fin4 :=
  match x, y with
  | F4_0, F4_0 => F4_3 | F4_0, F4_1 => F4_0 | F4_0, F4_2 => F4_1 | F4_0, F4_3 => F4_1
  | F4_1, F4_0 => F4_1 | F4_1, F4_1 => F4_1 | F4_1, F4_2 => F4_1 | F4_1, F4_3 => F4_1
  | F4_2, F4_0 => F4_1 | F4_2, F4_1 => F4_2 | F4_2, F4_2 => F4_0 | F4_2, F4_3 => F4_1
  | F4_3, F4_0 => F4_0 | F4_3, F4_1 => F4_3 | F4_3, F4_2 => F4_1 | F4_3, F4_3 => F4_2
  end.

#[local] Instance refa327_inst : Magma Fin4 := {| magma_op := refa327_op |}.

Lemma refa327_sat1050 : @Equation1050 Fin4 refa327_inst.
Proof. unfold Equation1050, magma_op, refa327_inst, refa327_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa327_not99 : ~ @Equation99 Fin4 refa327_inst.
Proof. unfold Equation99. intro H. specialize (H F4_0). unfold magma_op, refa327_inst, refa327_op in H. discriminate H. Qed.

Lemma refa327_not151 : ~ @Equation151 Fin4 refa327_inst.
Proof. unfold Equation151. intro H. specialize (H F4_0). unfold magma_op, refa327_inst, refa327_op in H. discriminate H. Qed.

Lemma refa327_not1036 : ~ @Equation1036 Fin4 refa327_inst.
Proof. unfold Equation1036. intro H. specialize (H F4_2 F4_0). unfold magma_op, refa327_inst, refa327_op in H. discriminate H. Qed.

Lemma refa327_not1038 : ~ @Equation1038 Fin4 refa327_inst.
Proof. unfold Equation1038. intro H. specialize (H F4_0 F4_3). unfold magma_op, refa327_inst, refa327_op in H. discriminate H. Qed.

Lemma refa327_not1045 : ~ @Equation1045 Fin4 refa327_inst.
Proof. unfold Equation1045. intro H. specialize (H F4_0 F4_3). unfold magma_op, refa327_inst, refa327_op in H. discriminate H. Qed.

Lemma refa327_not1223 : ~ @Equation1223 Fin4 refa327_inst.
Proof. unfold Equation1223. intro H. specialize (H F4_0). unfold magma_op, refa327_inst, refa327_op in H. discriminate H. Qed.

Lemma refa327_not4380 : ~ @Equation4380 Fin4 refa327_inst.
Proof. unfold Equation4380. intro H. specialize (H F4_0). unfold magma_op, refa327_inst, refa327_op in H. discriminate H. Qed.

(** ---- refa328 (Fin4) ---- *)

Definition refa328_op (x y : Fin4) : Fin4 :=
  match x, y with
  | F4_0, F4_0 => F4_0 | F4_0, F4_1 => F4_3 | F4_0, F4_2 => F4_2 | F4_0, F4_3 => F4_3
  | F4_1, F4_0 => F4_3 | F4_1, F4_1 => F4_0 | F4_1, F4_2 => F4_2 | F4_1, F4_3 => F4_2
  | F4_2, F4_0 => F4_2 | F4_2, F4_1 => F4_1 | F4_2, F4_2 => F4_0 | F4_2, F4_3 => F4_1
  | F4_3, F4_0 => F4_0 | F4_3, F4_1 => F4_2 | F4_3, F4_2 => F4_2 | F4_3, F4_3 => F4_3
  end.

#[local] Instance refa328_inst : Magma Fin4 := {| magma_op := refa328_op |}.

Lemma refa328_sat3105 : @Equation3105 Fin4 refa328_inst.
Proof. unfold Equation3105, magma_op, refa328_inst, refa328_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa328_not1629 : ~ @Equation1629 Fin4 refa328_inst.
Proof. unfold Equation1629. intro H. specialize (H F4_1). unfold magma_op, refa328_inst, refa328_op in H. discriminate H. Qed.

(** ---- refa329 (Fin4) ---- *)

Definition refa329_op (x y : Fin4) : Fin4 :=
  match x, y with
  | F4_0, F4_0 => F4_3 | F4_0, F4_1 => F4_0 | F4_0, F4_2 => F4_0 | F4_0, F4_3 => F4_1
  | F4_1, F4_0 => F4_3 | F4_1, F4_1 => F4_1 | F4_1, F4_2 => F4_1 | F4_1, F4_3 => F4_2
  | F4_2, F4_0 => F4_1 | F4_2, F4_1 => F4_2 | F4_2, F4_2 => F4_2 | F4_2, F4_3 => F4_2
  | F4_3, F4_0 => F4_2 | F4_3, F4_1 => F4_2 | F4_3, F4_2 => F4_3 | F4_3, F4_3 => F4_2
  end.

#[local] Instance refa329_inst : Magma Fin4 := {| magma_op := refa329_op |}.

Lemma refa329_sat818 : @Equation818 Fin4 refa329_inst.
Proof. unfold Equation818, magma_op, refa329_inst, refa329_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa329_sat836 : @Equation836 Fin4 refa329_inst.
Proof. unfold Equation836, magma_op, refa329_inst, refa329_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa329_sat1242 : @Equation1242 Fin4 refa329_inst.
Proof. unfold Equation1242, magma_op, refa329_inst, refa329_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa329_not1020 : ~ @Equation1020 Fin4 refa329_inst.
Proof. unfold Equation1020. intro H. specialize (H F4_0). unfold magma_op, refa329_inst, refa329_op in H. discriminate H. Qed.

Lemma refa329_not1224 : ~ @Equation1224 Fin4 refa329_inst.
Proof. unfold Equation1224. intro H. specialize (H F4_1 F4_0). unfold magma_op, refa329_inst, refa329_op in H. discriminate H. Qed.

Lemma refa329_not1238 : ~ @Equation1238 Fin4 refa329_inst.
Proof. unfold Equation1238. intro H. specialize (H F4_0 F4_3). unfold magma_op, refa329_inst, refa329_op in H. discriminate H. Qed.

Lemma refa329_not1239 : ~ @Equation1239 Fin4 refa329_inst.
Proof. unfold Equation1239. intro H. specialize (H F4_0 F4_2). unfold magma_op, refa329_inst, refa329_op in H. discriminate H. Qed.

Lemma refa329_not1241 : ~ @Equation1241 Fin4 refa329_inst.
Proof. unfold Equation1241. intro H. specialize (H F4_0 F4_2). unfold magma_op, refa329_inst, refa329_op in H. discriminate H. Qed.

Lemma refa329_not1248 : ~ @Equation1248 Fin4 refa329_inst.
Proof. unfold Equation1248. intro H. specialize (H F4_0 F4_2). unfold magma_op, refa329_inst, refa329_op in H. discriminate H. Qed.

Lemma refa329_not1249 : ~ @Equation1249 Fin4 refa329_inst.
Proof. unfold Equation1249. intro H. specialize (H F4_3 F4_0). unfold magma_op, refa329_inst, refa329_op in H. discriminate H. Qed.

Lemma refa329_not1251 : ~ @Equation1251 Fin4 refa329_inst.
Proof. unfold Equation1251. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa329_inst, refa329_op in H. discriminate H. Qed.

Lemma refa329_not1252 : ~ @Equation1252 Fin4 refa329_inst.
Proof. unfold Equation1252. intro H. specialize (H F4_3 F4_0). unfold magma_op, refa329_inst, refa329_op in H. discriminate H. Qed.

Lemma refa329_not3253 : ~ @Equation3253 Fin4 refa329_inst.
Proof. unfold Equation3253. intro H. specialize (H F4_0). unfold magma_op, refa329_inst, refa329_op in H. discriminate H. Qed.

Lemma refa329_not4065 : ~ @Equation4065 Fin4 refa329_inst.
Proof. unfold Equation4065. intro H. specialize (H F4_0). unfold magma_op, refa329_inst, refa329_op in H. discriminate H. Qed.

Lemma refa329_not4591 : ~ @Equation4591 Fin4 refa329_inst.
Proof. unfold Equation4591. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa329_inst, refa329_op in H. discriminate H. Qed.

Lemma refa329_not4598 : ~ @Equation4598 Fin4 refa329_inst.
Proof. unfold Equation4598. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa329_inst, refa329_op in H. discriminate H. Qed.

(** ---- refa33 (Fin7) ---- *)

Definition refa33_op (x y : Fin7) : Fin7 :=
  match x, y with
  | F7_0, F7_0 => F7_1 | F7_0, F7_1 => F7_2 | F7_0, F7_2 => F7_5 | F7_0, F7_3 => F7_6 | F7_0, F7_4 => F7_0 | F7_0, F7_5 => F7_3 | F7_0, F7_6 => F7_4
  | F7_1, F7_0 => F7_4 | F7_1, F7_1 => F7_0 | F7_1, F7_2 => F7_1 | F7_1, F7_3 => F7_5 | F7_1, F7_4 => F7_6 | F7_1, F7_5 => F7_2 | F7_1, F7_6 => F7_3
  | F7_2, F7_0 => F7_3 | F7_2, F7_1 => F7_6 | F7_2, F7_2 => F7_4 | F7_2, F7_3 => F7_1 | F7_2, F7_4 => F7_5 | F7_2, F7_5 => F7_0 | F7_2, F7_6 => F7_2
  | F7_3, F7_0 => F7_0 | F7_3, F7_1 => F7_1 | F7_3, F7_2 => F7_2 | F7_3, F7_3 => F7_3 | F7_3, F7_4 => F7_4 | F7_3, F7_5 => F7_5 | F7_3, F7_6 => F7_6
  | F7_4, F7_0 => F7_5 | F7_4, F7_1 => F7_3 | F7_4, F7_2 => F7_6 | F7_4, F7_3 => F7_0 | F7_4, F7_4 => F7_2 | F7_4, F7_5 => F7_4 | F7_4, F7_6 => F7_1
  | F7_5, F7_0 => F7_2 | F7_5, F7_1 => F7_5 | F7_5, F7_2 => F7_3 | F7_5, F7_3 => F7_4 | F7_5, F7_4 => F7_1 | F7_5, F7_5 => F7_6 | F7_5, F7_6 => F7_0
  | F7_6, F7_0 => F7_6 | F7_6, F7_1 => F7_4 | F7_6, F7_2 => F7_0 | F7_6, F7_3 => F7_2 | F7_6, F7_4 => F7_3 | F7_6, F7_5 => F7_1 | F7_6, F7_6 => F7_5
  end.

#[local] Instance refa33_inst : Magma Fin7 := {| magma_op := refa33_op |}.

Lemma refa33_sat2900 : @Equation2900 Fin7 refa33_inst.
Proof. unfold Equation2900, magma_op, refa33_inst, refa33_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa33_not411 : ~ @Equation411 Fin7 refa33_inst.
Proof. unfold Equation411. intro H. specialize (H F7_0). unfold magma_op, refa33_inst, refa33_op in H. discriminate H. Qed.

Lemma refa33_not614 : ~ @Equation614 Fin7 refa33_inst.
Proof. unfold Equation614. intro H. specialize (H F7_0). unfold magma_op, refa33_inst, refa33_op in H. discriminate H. Qed.

Lemma refa33_not1020 : ~ @Equation1020 Fin7 refa33_inst.
Proof. unfold Equation1020. intro H. specialize (H F7_0). unfold magma_op, refa33_inst, refa33_op in H. discriminate H. Qed.

Lemma refa33_not1223 : ~ @Equation1223 Fin7 refa33_inst.
Proof. unfold Equation1223. intro H. specialize (H F7_0). unfold magma_op, refa33_inst, refa33_op in H. discriminate H. Qed.

Lemma refa33_not1426 : ~ @Equation1426 Fin7 refa33_inst.
Proof. unfold Equation1426. intro H. specialize (H F7_0). unfold magma_op, refa33_inst, refa33_op in H. discriminate H. Qed.

Lemma refa33_not1629 : ~ @Equation1629 Fin7 refa33_inst.
Proof. unfold Equation1629. intro H. specialize (H F7_0). unfold magma_op, refa33_inst, refa33_op in H. discriminate H. Qed.

Lemma refa33_not1832 : ~ @Equation1832 Fin7 refa33_inst.
Proof. unfold Equation1832. intro H. specialize (H F7_0). unfold magma_op, refa33_inst, refa33_op in H. discriminate H. Qed.

Lemma refa33_not2035 : ~ @Equation2035 Fin7 refa33_inst.
Proof. unfold Equation2035. intro H. specialize (H F7_0). unfold magma_op, refa33_inst, refa33_op in H. discriminate H. Qed.

Lemma refa33_not2238 : ~ @Equation2238 Fin7 refa33_inst.
Proof. unfold Equation2238. intro H. specialize (H F7_0). unfold magma_op, refa33_inst, refa33_op in H. discriminate H. Qed.

Lemma refa33_not2441 : ~ @Equation2441 Fin7 refa33_inst.
Proof. unfold Equation2441. intro H. specialize (H F7_0). unfold magma_op, refa33_inst, refa33_op in H. discriminate H. Qed.

Lemma refa33_not3050 : ~ @Equation3050 Fin7 refa33_inst.
Proof. unfold Equation3050. intro H. specialize (H F7_0). unfold magma_op, refa33_inst, refa33_op in H. discriminate H. Qed.

Lemma refa33_not3659 : ~ @Equation3659 Fin7 refa33_inst.
Proof. unfold Equation3659. intro H. specialize (H F7_0). unfold magma_op, refa33_inst, refa33_op in H. discriminate H. Qed.

Lemma refa33_not4380 : ~ @Equation4380 Fin7 refa33_inst.
Proof. unfold Equation4380. intro H. specialize (H F7_0). unfold magma_op, refa33_inst, refa33_op in H. discriminate H. Qed.

(** ---- refa330 (Fin4) ---- *)

Definition refa330_op (x y : Fin4) : Fin4 :=
  match x, y with
  | F4_0, F4_0 => F4_2 | F4_0, F4_1 => F4_0 | F4_0, F4_2 => F4_0 | F4_0, F4_3 => F4_3
  | F4_1, F4_0 => F4_3 | F4_1, F4_1 => F4_0 | F4_1, F4_2 => F4_2 | F4_1, F4_3 => F4_0
  | F4_2, F4_0 => F4_0 | F4_2, F4_1 => F4_3 | F4_2, F4_2 => F4_3 | F4_2, F4_3 => F4_2
  | F4_3, F4_0 => F4_3 | F4_3, F4_1 => F4_1 | F4_3, F4_2 => F4_2 | F4_3, F4_3 => F4_0
  end.

#[local] Instance refa330_inst : Magma Fin4 := {| magma_op := refa330_op |}.

Lemma refa330_sat2540 : @Equation2540 Fin4 refa330_inst.
Proof. unfold Equation2540, magma_op, refa330_inst, refa330_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa330_not1629 : ~ @Equation1629 Fin4 refa330_inst.
Proof. unfold Equation1629. intro H. specialize (H F4_1). unfold magma_op, refa330_inst, refa330_op in H. discriminate H. Qed.

Lemma refa330_not1832 : ~ @Equation1832 Fin4 refa330_inst.
Proof. unfold Equation1832. intro H. specialize (H F4_1). unfold magma_op, refa330_inst, refa330_op in H. discriminate H. Qed.

Lemma refa330_not2449 : ~ @Equation2449 Fin4 refa330_inst.
Proof. unfold Equation2449. intro H. specialize (H F4_1 F4_0). unfold magma_op, refa330_inst, refa330_op in H. discriminate H. Qed.

Lemma refa330_not3050 : ~ @Equation3050 Fin4 refa330_inst.
Proof. unfold Equation3050. intro H. specialize (H F4_1). unfold magma_op, refa330_inst, refa330_op in H. discriminate H. Qed.

Lemma refa330_not3456 : ~ @Equation3456 Fin4 refa330_inst.
Proof. unfold Equation3456. intro H. specialize (H F4_1). unfold magma_op, refa330_inst, refa330_op in H. discriminate H. Qed.

Lemma refa330_not4073 : ~ @Equation4073 Fin4 refa330_inst.
Proof. unfold Equation4073. intro H. specialize (H F4_1 F4_0). unfold magma_op, refa330_inst, refa330_op in H. discriminate H. Qed.

Lemma refa330_not4118 : ~ @Equation4118 Fin4 refa330_inst.
Proof. unfold Equation4118. intro H. specialize (H F4_1 F4_0). unfold magma_op, refa330_inst, refa330_op in H. discriminate H. Qed.

Lemma refa330_not4131 : ~ @Equation4131 Fin4 refa330_inst.
Proof. unfold Equation4131. intro H. specialize (H F4_2 F4_1). unfold magma_op, refa330_inst, refa330_op in H. discriminate H. Qed.

(** ---- refa331 (Fin4) ---- *)

Definition refa331_op (x y : Fin4) : Fin4 :=
  match x, y with
  | F4_0, F4_0 => F4_2 | F4_0, F4_1 => F4_0 | F4_0, F4_2 => F4_3 | F4_0, F4_3 => F4_1
  | F4_1, F4_0 => F4_3 | F4_1, F4_1 => F4_2 | F4_1, F4_2 => F4_1 | F4_1, F4_3 => F4_0
  | F4_2, F4_0 => F4_0 | F4_2, F4_1 => F4_1 | F4_2, F4_2 => F4_2 | F4_2, F4_3 => F4_3
  | F4_3, F4_0 => F4_1 | F4_3, F4_1 => F4_3 | F4_3, F4_2 => F4_0 | F4_3, F4_3 => F4_2
  end.

#[local] Instance refa331_inst : Magma Fin4 := {| magma_op := refa331_op |}.

Lemma refa331_sat414 : @Equation414 Fin4 refa331_inst.
Proof. unfold Equation414, magma_op, refa331_inst, refa331_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa331_sat417 : @Equation417 Fin4 refa331_inst.
Proof. unfold Equation417, magma_op, refa331_inst, refa331_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa331_sat427 : @Equation427 Fin4 refa331_inst.
Proof. unfold Equation427, magma_op, refa331_inst, refa331_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa331_sat464 : @Equation464 Fin4 refa331_inst.
Proof. unfold Equation464, magma_op, refa331_inst, refa331_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa331_not99 : ~ @Equation99 Fin4 refa331_inst.
Proof. unfold Equation99. intro H. specialize (H F4_0). unfold magma_op, refa331_inst, refa331_op in H. discriminate H. Qed.

Lemma refa331_not359 : ~ @Equation359 Fin4 refa331_inst.
Proof. unfold Equation359. intro H. specialize (H F4_0). unfold magma_op, refa331_inst, refa331_op in H. discriminate H. Qed.

Lemma refa331_not413 : ~ @Equation413 Fin4 refa331_inst.
Proof. unfold Equation413. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa331_inst, refa331_op in H. discriminate H. Qed.

Lemma refa331_not426 : ~ @Equation426 Fin4 refa331_inst.
Proof. unfold Equation426. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa331_inst, refa331_op in H. discriminate H. Qed.

Lemma refa331_not429 : ~ @Equation429 Fin4 refa331_inst.
Proof. unfold Equation429. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa331_inst, refa331_op in H. discriminate H. Qed.

Lemma refa331_not436 : ~ @Equation436 Fin4 refa331_inst.
Proof. unfold Equation436. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa331_inst, refa331_op in H. discriminate H. Qed.

Lemma refa331_not440 : ~ @Equation440 Fin4 refa331_inst.
Proof. unfold Equation440. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa331_inst, refa331_op in H. discriminate H. Qed.

Lemma refa331_not466 : ~ @Equation466 Fin4 refa331_inst.
Proof. unfold Equation466. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa331_inst, refa331_op in H. discriminate H. Qed.

Lemma refa331_not614 : ~ @Equation614 Fin4 refa331_inst.
Proof. unfold Equation614. intro H. specialize (H F4_0). unfold magma_op, refa331_inst, refa331_op in H. discriminate H. Qed.

Lemma refa331_not817 : ~ @Equation817 Fin4 refa331_inst.
Proof. unfold Equation817. intro H. specialize (H F4_0). unfold magma_op, refa331_inst, refa331_op in H. discriminate H. Qed.

Lemma refa331_not1036 : ~ @Equation1036 Fin4 refa331_inst.
Proof. unfold Equation1036. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa331_inst, refa331_op in H. discriminate H. Qed.

Lemma refa331_not1049 : ~ @Equation1049 Fin4 refa331_inst.
Proof. unfold Equation1049. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa331_inst, refa331_op in H. discriminate H. Qed.

Lemma refa331_not1075 : ~ @Equation1075 Fin4 refa331_inst.
Proof. unfold Equation1075. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa331_inst, refa331_op in H. discriminate H. Qed.

Lemma refa331_not1223 : ~ @Equation1223 Fin4 refa331_inst.
Proof. unfold Equation1223. intro H. specialize (H F4_0). unfold magma_op, refa331_inst, refa331_op in H. discriminate H. Qed.

Lemma refa331_not1426 : ~ @Equation1426 Fin4 refa331_inst.
Proof. unfold Equation1426. intro H. specialize (H F4_0). unfold magma_op, refa331_inst, refa331_op in H. discriminate H. Qed.

Lemma refa331_not2035 : ~ @Equation2035 Fin4 refa331_inst.
Proof. unfold Equation2035. intro H. specialize (H F4_0). unfold magma_op, refa331_inst, refa331_op in H. discriminate H. Qed.

Lemma refa331_not2238 : ~ @Equation2238 Fin4 refa331_inst.
Proof. unfold Equation2238. intro H. specialize (H F4_0). unfold magma_op, refa331_inst, refa331_op in H. discriminate H. Qed.

Lemma refa331_not2447 : ~ @Equation2447 Fin4 refa331_inst.
Proof. unfold Equation2447. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa331_inst, refa331_op in H. discriminate H. Qed.

Lemma refa331_not2847 : ~ @Equation2847 Fin4 refa331_inst.
Proof. unfold Equation2847. intro H. specialize (H F4_0). unfold magma_op, refa331_inst, refa331_op in H. discriminate H. Qed.

Lemma refa331_not3253 : ~ @Equation3253 Fin4 refa331_inst.
Proof. unfold Equation3253. intro H. specialize (H F4_0). unfold magma_op, refa331_inst, refa331_op in H. discriminate H. Qed.

Lemma refa331_not3545 : ~ @Equation3545 Fin4 refa331_inst.
Proof. unfold Equation3545. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa331_inst, refa331_op in H. discriminate H. Qed.

Lemma refa331_not3721 : ~ @Equation3721 Fin4 refa331_inst.
Proof. unfold Equation3721. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa331_inst, refa331_op in H. discriminate H. Qed.

Lemma refa331_not3725 : ~ @Equation3725 Fin4 refa331_inst.
Proof. unfold Equation3725. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa331_inst, refa331_op in H. discriminate H. Qed.

Lemma refa331_not3862 : ~ @Equation3862 Fin4 refa331_inst.
Proof. unfold Equation3862. intro H. specialize (H F4_0). unfold magma_op, refa331_inst, refa331_op in H. discriminate H. Qed.

Lemma refa331_not4167 : ~ @Equation4167 Fin4 refa331_inst.
Proof. unfold Equation4167. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa331_inst, refa331_op in H. discriminate H. Qed.

Lemma refa331_not4283 : ~ @Equation4283 Fin4 refa331_inst.
Proof. unfold Equation4283. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa331_inst, refa331_op in H. discriminate H. Qed.

Lemma refa331_not4380 : ~ @Equation4380 Fin4 refa331_inst.
Proof. unfold Equation4380. intro H. specialize (H F4_0). unfold magma_op, refa331_inst, refa331_op in H. discriminate H. Qed.

Lemma refa331_not4635 : ~ @Equation4635 Fin4 refa331_inst.
Proof. unfold Equation4635. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa331_inst, refa331_op in H. discriminate H. Qed.

(** ---- refa332 (Fin4) ---- *)

Definition refa332_op (x y : Fin4) : Fin4 :=
  match x, y with
  | F4_0, F4_0 => F4_3 | F4_0, F4_1 => F4_3 | F4_0, F4_2 => F4_1 | F4_0, F4_3 => F4_3
  | F4_1, F4_0 => F4_3 | F4_1, F4_1 => F4_3 | F4_1, F4_2 => F4_3 | F4_1, F4_3 => F4_3
  | F4_2, F4_0 => F4_0 | F4_2, F4_1 => F4_0 | F4_2, F4_2 => F4_0 | F4_2, F4_3 => F4_0
  | F4_3, F4_0 => F4_3 | F4_3, F4_1 => F4_3 | F4_3, F4_2 => F4_3 | F4_3, F4_3 => F4_3
  end.

#[local] Instance refa332_inst : Magma Fin4 := {| magma_op := refa332_op |}.

Lemma refa332_sat4610 : @Equation4610 Fin4 refa332_inst.
Proof. unfold Equation4610, magma_op, refa332_inst, refa332_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa332_not4583 : ~ @Equation4583 Fin4 refa332_inst.
Proof. unfold Equation4583. intro H. specialize (H F4_2 F4_0). unfold magma_op, refa332_inst, refa332_op in H. discriminate H. Qed.

Lemma refa332_not4591 : ~ @Equation4591 Fin4 refa332_inst.
Proof. unfold Equation4591. intro H. specialize (H F4_0 F4_2). unfold magma_op, refa332_inst, refa332_op in H. discriminate H. Qed.

Lemma refa332_not4598 : ~ @Equation4598 Fin4 refa332_inst.
Proof. unfold Equation4598. intro H. specialize (H F4_2 F4_0). unfold magma_op, refa332_inst, refa332_op in H. discriminate H. Qed.

Lemma refa332_not4606 : ~ @Equation4606 Fin4 refa332_inst.
Proof. unfold Equation4606. intro H. specialize (H F4_0 F4_2). unfold magma_op, refa332_inst, refa332_op in H. discriminate H. Qed.

Lemma refa332_not4622 : ~ @Equation4622 Fin4 refa332_inst.
Proof. unfold Equation4622. intro H. specialize (H F4_0 F4_2 F4_2). unfold magma_op, refa332_inst, refa332_op in H. discriminate H. Qed.

Lemma refa332_not4629 : ~ @Equation4629 Fin4 refa332_inst.
Proof. unfold Equation4629. intro H. specialize (H F4_2 F4_0). unfold magma_op, refa332_inst, refa332_op in H. discriminate H. Qed.

Lemma refa332_not4635 : ~ @Equation4635 Fin4 refa332_inst.
Proof. unfold Equation4635. intro H. specialize (H F4_2 F4_0). unfold magma_op, refa332_inst, refa332_op in H. discriminate H. Qed.

Lemma refa332_not4636 : ~ @Equation4636 Fin4 refa332_inst.
Proof. unfold Equation4636. intro H. specialize (H F4_0 F4_2). unfold magma_op, refa332_inst, refa332_op in H. discriminate H. Qed.

Lemma refa332_not4647 : ~ @Equation4647 Fin4 refa332_inst.
Proof. unfold Equation4647. intro H. specialize (H F4_0 F4_0 F4_2). unfold magma_op, refa332_inst, refa332_op in H. discriminate H. Qed.

Lemma refa332_not4656 : ~ @Equation4656 Fin4 refa332_inst.
Proof. unfold Equation4656. intro H. specialize (H F4_2 F4_0 F4_2). unfold magma_op, refa332_inst, refa332_op in H. discriminate H. Qed.

Lemma refa332_not4666 : ~ @Equation4666 Fin4 refa332_inst.
Proof. unfold Equation4666. intro H. specialize (H F4_0 F4_2 F4_2). unfold magma_op, refa332_inst, refa332_op in H. discriminate H. Qed.

(** ---- refa333 (Fin4) ---- *)

Definition refa333_op (x y : Fin4) : Fin4 :=
  match x, y with
  | F4_0, F4_0 => F4_1 | F4_0, F4_1 => F4_0 | F4_0, F4_2 => F4_0 | F4_0, F4_3 => F4_3
  | F4_1, F4_0 => F4_1 | F4_1, F4_1 => F4_2 | F4_1, F4_2 => F4_1 | F4_1, F4_3 => F4_1
  | F4_2, F4_0 => F4_3 | F4_2, F4_1 => F4_2 | F4_2, F4_2 => F4_3 | F4_2, F4_3 => F4_2
  | F4_3, F4_0 => F4_1 | F4_3, F4_1 => F4_3 | F4_3, F4_2 => F4_3 | F4_3, F4_3 => F4_3
  end.

#[local] Instance refa333_inst : Magma Fin4 := {| magma_op := refa333_op |}.

Lemma refa333_sat1230 : @Equation1230 Fin4 refa333_inst.
Proof. unfold Equation1230, magma_op, refa333_inst, refa333_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa333_not1225 : ~ @Equation1225 Fin4 refa333_inst.
Proof. unfold Equation1225. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa333_inst, refa333_op in H. discriminate H. Qed.

Lemma refa333_not1226 : ~ @Equation1226 Fin4 refa333_inst.
Proof. unfold Equation1226. intro H. specialize (H F4_1 F4_0). unfold magma_op, refa333_inst, refa333_op in H. discriminate H. Qed.

Lemma refa333_not3659 : ~ @Equation3659 Fin4 refa333_inst.
Proof. unfold Equation3659. intro H. specialize (H F4_0). unfold magma_op, refa333_inst, refa333_op in H. discriminate H. Qed.

Lemma refa333_not3928 : ~ @Equation3928 Fin4 refa333_inst.
Proof. unfold Equation3928. intro H. specialize (H F4_0 F4_2). unfold magma_op, refa333_inst, refa333_op in H. discriminate H. Qed.

Lemma refa333_not4598 : ~ @Equation4598 Fin4 refa333_inst.
Proof. unfold Equation4598. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa333_inst, refa333_op in H. discriminate H. Qed.

(** ---- refa334 (Fin4) ---- *)

Definition refa334_op (x y : Fin4) : Fin4 :=
  match x, y with
  | F4_0, F4_0 => F4_2 | F4_0, F4_1 => F4_2 | F4_0, F4_2 => F4_2 | F4_0, F4_3 => F4_3
  | F4_1, F4_0 => F4_3 | F4_1, F4_1 => F4_2 | F4_1, F4_2 => F4_2 | F4_1, F4_3 => F4_3
  | F4_2, F4_0 => F4_2 | F4_2, F4_1 => F4_2 | F4_2, F4_2 => F4_2 | F4_2, F4_3 => F4_3
  | F4_3, F4_0 => F4_3 | F4_3, F4_1 => F4_2 | F4_3, F4_2 => F4_2 | F4_3, F4_3 => F4_3
  end.

#[local] Instance refa334_inst : Magma Fin4 := {| magma_op := refa334_op |}.

Lemma refa334_sat3587 : @Equation3587 Fin4 refa334_inst.
Proof. unfold Equation3587, magma_op, refa334_inst, refa334_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa334_not4128 : ~ @Equation4128 Fin4 refa334_inst.
Proof. unfold Equation4128. intro H. specialize (H F4_1 F4_0). unfold magma_op, refa334_inst, refa334_op in H. discriminate H. Qed.

(** ---- refa335 (Fin4) ---- *)

Definition refa335_op (x y : Fin4) : Fin4 :=
  match x, y with
  | F4_0, F4_0 => F4_2 | F4_0, F4_1 => F4_0 | F4_0, F4_2 => F4_0 | F4_0, F4_3 => F4_1
  | F4_1, F4_0 => F4_3 | F4_1, F4_1 => F4_1 | F4_1, F4_2 => F4_1 | F4_1, F4_3 => F4_0
  | F4_2, F4_0 => F4_0 | F4_2, F4_1 => F4_2 | F4_2, F4_2 => F4_2 | F4_2, F4_3 => F4_3
  | F4_3, F4_0 => F4_1 | F4_3, F4_1 => F4_3 | F4_3, F4_2 => F4_3 | F4_3, F4_3 => F4_2
  end.

#[local] Instance refa335_inst : Magma Fin4 := {| magma_op := refa335_op |}.

Lemma refa335_sat455 : @Equation455 Fin4 refa335_inst.
Proof. unfold Equation455, magma_op, refa335_inst, refa335_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa335_sat658 : @Equation658 Fin4 refa335_inst.
Proof. unfold Equation658, magma_op, refa335_inst, refa335_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa335_sat2688 : @Equation2688 Fin4 refa335_inst.
Proof. unfold Equation2688, magma_op, refa335_inst, refa335_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa335_not2647 : ~ @Equation2647 Fin4 refa335_inst.
Proof. unfold Equation2647. intro H. specialize (H F4_0 F4_3). unfold magma_op, refa335_inst, refa335_op in H. discriminate H. Qed.

Lemma refa335_not2662 : ~ @Equation2662 Fin4 refa335_inst.
Proof. unfold Equation2662. intro H. specialize (H F4_0 F4_3). unfold magma_op, refa335_inst, refa335_op in H. discriminate H. Qed.

Lemma refa335_not2853 : ~ @Equation2853 Fin4 refa335_inst.
Proof. unfold Equation2853. intro H. specialize (H F4_0 F4_3). unfold magma_op, refa335_inst, refa335_op in H. discriminate H. Qed.

Lemma refa335_not3261 : ~ @Equation3261 Fin4 refa335_inst.
Proof. unfold Equation3261. intro H. specialize (H F4_0 F4_3). unfold magma_op, refa335_inst, refa335_op in H. discriminate H. Qed.

Lemma refa335_not3306 : ~ @Equation3306 Fin4 refa335_inst.
Proof. unfold Equation3306. intro H. specialize (H F4_0 F4_3). unfold magma_op, refa335_inst, refa335_op in H. discriminate H. Qed.

Lemma refa335_not3464 : ~ @Equation3464 Fin4 refa335_inst.
Proof. unfold Equation3464. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa335_inst, refa335_op in H. discriminate H. Qed.

Lemma refa335_not3509 : ~ @Equation3509 Fin4 refa335_inst.
Proof. unfold Equation3509. intro H. specialize (H F4_1 F4_0). unfold magma_op, refa335_inst, refa335_op in H. discriminate H. Qed.

Lemma refa335_not3511 : ~ @Equation3511 Fin4 refa335_inst.
Proof. unfold Equation3511. intro H. specialize (H F4_1 F4_0). unfold magma_op, refa335_inst, refa335_op in H. discriminate H. Qed.

Lemma refa335_not3665 : ~ @Equation3665 Fin4 refa335_inst.
Proof. unfold Equation3665. intro H. specialize (H F4_0 F4_3). unfold magma_op, refa335_inst, refa335_op in H. discriminate H. Qed.

Lemma refa335_not3865 : ~ @Equation3865 Fin4 refa335_inst.
Proof. unfold Equation3865. intro H. specialize (H F4_0 F4_3). unfold magma_op, refa335_inst, refa335_op in H. discriminate H. Qed.

(** ---- refa336 (Fin4) ---- *)

Definition refa336_op (x y : Fin4) : Fin4 :=
  match x, y with
  | F4_0, F4_0 => F4_3 | F4_0, F4_1 => F4_2 | F4_0, F4_2 => F4_3 | F4_0, F4_3 => F4_1
  | F4_1, F4_0 => F4_3 | F4_1, F4_1 => F4_1 | F4_1, F4_2 => F4_3 | F4_1, F4_3 => F4_2
  | F4_2, F4_0 => F4_1 | F4_2, F4_1 => F4_2 | F4_2, F4_2 => F4_1 | F4_2, F4_3 => F4_3
  | F4_3, F4_0 => F4_1 | F4_3, F4_1 => F4_3 | F4_3, F4_2 => F4_1 | F4_3, F4_3 => F4_1
  end.

#[local] Instance refa336_inst : Magma Fin4 := {| magma_op := refa336_op |}.

Lemma refa336_sat3865 : @Equation3865 Fin4 refa336_inst.
Proof. unfold Equation3865, magma_op, refa336_inst, refa336_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa336_not3659 : ~ @Equation3659 Fin4 refa336_inst.
Proof. unfold Equation3659. intro H. specialize (H F4_0). unfold magma_op, refa336_inst, refa336_op in H. discriminate H. Qed.

Lemma refa336_not3870 : ~ @Equation3870 Fin4 refa336_inst.
Proof. unfold Equation3870. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa336_inst, refa336_op in H. discriminate H. Qed.

Lemma refa336_not4065 : ~ @Equation4065 Fin4 refa336_inst.
Proof. unfold Equation4065. intro H. specialize (H F4_3). unfold magma_op, refa336_inst, refa336_op in H. discriminate H. Qed.

Lemma refa336_not4270 : ~ @Equation4270 Fin4 refa336_inst.
Proof. unfold Equation4270. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa336_inst, refa336_op in H. discriminate H. Qed.

Lemma refa336_not4598 : ~ @Equation4598 Fin4 refa336_inst.
Proof. unfold Equation4598. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa336_inst, refa336_op in H. discriminate H. Qed.

(** ---- refa337 (Fin4) ---- *)

Definition refa337_op (x y : Fin4) : Fin4 :=
  match x, y with
  | F4_0, F4_0 => F4_1 | F4_0, F4_1 => F4_1 | F4_0, F4_2 => F4_2 | F4_0, F4_3 => F4_1
  | F4_1, F4_0 => F4_3 | F4_1, F4_1 => F4_3 | F4_1, F4_2 => F4_3 | F4_1, F4_3 => F4_3
  | F4_2, F4_0 => F4_1 | F4_2, F4_1 => F4_1 | F4_2, F4_2 => F4_1 | F4_2, F4_3 => F4_1
  | F4_3, F4_0 => F4_0 | F4_3, F4_1 => F4_2 | F4_3, F4_2 => F4_2 | F4_3, F4_3 => F4_2
  end.

#[local] Instance refa337_inst : Magma Fin4 := {| magma_op := refa337_op |}.

Lemma refa337_sat2868 : @Equation2868 Fin4 refa337_inst.
Proof. unfold Equation2868, magma_op, refa337_inst, refa337_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa337_not263 : ~ @Equation263 Fin4 refa337_inst.
Proof. unfold Equation263. intro H. specialize (H F4_0 F4_2). unfold magma_op, refa337_inst, refa337_op in H. discriminate H. Qed.

Lemma refa337_not2035 : ~ @Equation2035 Fin4 refa337_inst.
Proof. unfold Equation2035. intro H. specialize (H F4_0). unfold magma_op, refa337_inst, refa337_op in H. discriminate H. Qed.

Lemma refa337_not2659 : ~ @Equation2659 Fin4 refa337_inst.
Proof. unfold Equation2659. intro H. specialize (H F4_0 F4_2). unfold magma_op, refa337_inst, refa337_op in H. discriminate H. Qed.

Lemma refa337_not2662 : ~ @Equation2662 Fin4 refa337_inst.
Proof. unfold Equation2662. intro H. specialize (H F4_0 F4_2). unfold magma_op, refa337_inst, refa337_op in H. discriminate H. Qed.

Lemma refa337_not2669 : ~ @Equation2669 Fin4 refa337_inst.
Proof. unfold Equation2669. intro H. specialize (H F4_0 F4_2). unfold magma_op, refa337_inst, refa337_op in H. discriminate H. Qed.

Lemma refa337_not2672 : ~ @Equation2672 Fin4 refa337_inst.
Proof. unfold Equation2672. intro H. specialize (H F4_0 F4_2). unfold magma_op, refa337_inst, refa337_op in H. discriminate H. Qed.

Lemma refa337_not2852 : ~ @Equation2852 Fin4 refa337_inst.
Proof. unfold Equation2852. intro H. specialize (H F4_0 F4_2). unfold magma_op, refa337_inst, refa337_op in H. discriminate H. Qed.

Lemma refa337_not2855 : ~ @Equation2855 Fin4 refa337_inst.
Proof. unfold Equation2855. intro H. specialize (H F4_0 F4_2). unfold magma_op, refa337_inst, refa337_op in H. discriminate H. Qed.

Lemma refa337_not2872 : ~ @Equation2872 Fin4 refa337_inst.
Proof. unfold Equation2872. intro H. specialize (H F4_0 F4_3). unfold magma_op, refa337_inst, refa337_op in H. discriminate H. Qed.

Lemma refa337_not2875 : ~ @Equation2875 Fin4 refa337_inst.
Proof. unfold Equation2875. intro H. specialize (H F4_0 F4_3). unfold magma_op, refa337_inst, refa337_op in H. discriminate H. Qed.

Lemma refa337_not3258 : ~ @Equation3258 Fin4 refa337_inst.
Proof. unfold Equation3258. intro H. specialize (H F4_0 F4_3). unfold magma_op, refa337_inst, refa337_op in H. discriminate H. Qed.

Lemma refa337_not3309 : ~ @Equation3309 Fin4 refa337_inst.
Proof. unfold Equation3309. intro H. specialize (H F4_0 F4_2). unfold magma_op, refa337_inst, refa337_op in H. discriminate H. Qed.

Lemma refa337_not3316 : ~ @Equation3316 Fin4 refa337_inst.
Proof. unfold Equation3316. intro H. specialize (H F4_0 F4_2). unfold magma_op, refa337_inst, refa337_op in H. discriminate H. Qed.

Lemma refa337_not3319 : ~ @Equation3319 Fin4 refa337_inst.
Proof. unfold Equation3319. intro H. specialize (H F4_0 F4_2). unfold magma_op, refa337_inst, refa337_op in H. discriminate H. Qed.

Lemma refa337_not3509 : ~ @Equation3509 Fin4 refa337_inst.
Proof. unfold Equation3509. intro H. specialize (H F4_0 F4_2). unfold magma_op, refa337_inst, refa337_op in H. discriminate H. Qed.

Lemma refa337_not3512 : ~ @Equation3512 Fin4 refa337_inst.
Proof. unfold Equation3512. intro H. specialize (H F4_0 F4_2). unfold magma_op, refa337_inst, refa337_op in H. discriminate H. Qed.

Lemma refa337_not3519 : ~ @Equation3519 Fin4 refa337_inst.
Proof. unfold Equation3519. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa337_inst, refa337_op in H. discriminate H. Qed.

Lemma refa337_not3522 : ~ @Equation3522 Fin4 refa337_inst.
Proof. unfold Equation3522. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa337_inst, refa337_op in H. discriminate H. Qed.

Lemma refa337_not4284 : ~ @Equation4284 Fin4 refa337_inst.
Proof. unfold Equation4284. intro H. specialize (H F4_0 F4_2). unfold magma_op, refa337_inst, refa337_op in H. discriminate H. Qed.

Lemma refa337_not4599 : ~ @Equation4599 Fin4 refa337_inst.
Proof. unfold Equation4599. intro H. specialize (H F4_0 F4_2). unfold magma_op, refa337_inst, refa337_op in H. discriminate H. Qed.

Lemma refa337_not4631 : ~ @Equation4631 Fin4 refa337_inst.
Proof. unfold Equation4631. intro H. specialize (H F4_0 F4_0 F4_2). unfold magma_op, refa337_inst, refa337_op in H. discriminate H. Qed.

(** ---- refa338 (Fin4) ---- *)

Definition refa338_op (x y : Fin4) : Fin4 :=
  match x, y with
  | F4_0, F4_0 => F4_3 | F4_0, F4_1 => F4_0 | F4_0, F4_2 => F4_3 | F4_0, F4_3 => F4_3
  | F4_1, F4_0 => F4_3 | F4_1, F4_1 => F4_3 | F4_1, F4_2 => F4_0 | F4_1, F4_3 => F4_3
  | F4_2, F4_0 => F4_2 | F4_2, F4_1 => F4_0 | F4_2, F4_2 => F4_3 | F4_2, F4_3 => F4_3
  | F4_3, F4_0 => F4_3 | F4_3, F4_1 => F4_0 | F4_3, F4_2 => F4_3 | F4_3, F4_3 => F4_3
  end.

#[local] Instance refa338_inst : Magma Fin4 := {| magma_op := refa338_op |}.

Lemma refa338_sat3280 : @Equation3280 Fin4 refa338_inst.
Proof. unfold Equation3280, magma_op, refa338_inst, refa338_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa338_not359 : ~ @Equation359 Fin4 refa338_inst.
Proof. unfold Equation359. intro H. specialize (H F4_1). unfold magma_op, refa338_inst, refa338_op in H. discriminate H. Qed.

Lemma refa338_not3259 : ~ @Equation3259 Fin4 refa338_inst.
Proof. unfold Equation3259. intro H. specialize (H F4_1 F4_2). unfold magma_op, refa338_inst, refa338_op in H. discriminate H. Qed.

Lemma refa338_not3261 : ~ @Equation3261 Fin4 refa338_inst.
Proof. unfold Equation3261. intro H. specialize (H F4_1 F4_2). unfold magma_op, refa338_inst, refa338_op in H. discriminate H. Qed.

Lemma refa338_not3269 : ~ @Equation3269 Fin4 refa338_inst.
Proof. unfold Equation3269. intro H. specialize (H F4_2 F4_1). unfold magma_op, refa338_inst, refa338_op in H. discriminate H. Qed.

Lemma refa338_not3271 : ~ @Equation3271 Fin4 refa338_inst.
Proof. unfold Equation3271. intro H. specialize (H F4_2 F4_1). unfold magma_op, refa338_inst, refa338_op in H. discriminate H. Qed.

Lemma refa338_not4268 : ~ @Equation4268 Fin4 refa338_inst.
Proof. unfold Equation4268. intro H. specialize (H F4_2 F4_1). unfold magma_op, refa338_inst, refa338_op in H. discriminate H. Qed.

Lemma refa338_not4269 : ~ @Equation4269 Fin4 refa338_inst.
Proof. unfold Equation4269. intro H. specialize (H F4_2 F4_1). unfold magma_op, refa338_inst, refa338_op in H. discriminate H. Qed.

Lemma refa338_not4275 : ~ @Equation4275 Fin4 refa338_inst.
Proof. unfold Equation4275. intro H. specialize (H F4_1 F4_2). unfold magma_op, refa338_inst, refa338_op in H. discriminate H. Qed.

Lemma refa338_not4284 : ~ @Equation4284 Fin4 refa338_inst.
Proof. unfold Equation4284. intro H. specialize (H F4_2 F4_1). unfold magma_op, refa338_inst, refa338_op in H. discriminate H. Qed.

Lemma refa338_not4290 : ~ @Equation4290 Fin4 refa338_inst.
Proof. unfold Equation4290. intro H. specialize (H F4_2 F4_1). unfold magma_op, refa338_inst, refa338_op in H. discriminate H. Qed.

Lemma refa338_not4291 : ~ @Equation4291 Fin4 refa338_inst.
Proof. unfold Equation4291. intro H. specialize (H F4_1 F4_2). unfold magma_op, refa338_inst, refa338_op in H. discriminate H. Qed.

Lemma refa338_not4293 : ~ @Equation4293 Fin4 refa338_inst.
Proof. unfold Equation4293. intro H. specialize (H F4_1 F4_2). unfold magma_op, refa338_inst, refa338_op in H. discriminate H. Qed.

Lemma refa338_not4320 : ~ @Equation4320 Fin4 refa338_inst.
Proof. unfold Equation4320. intro H. specialize (H F4_2 F4_1). unfold magma_op, refa338_inst, refa338_op in H. discriminate H. Qed.

(** ---- refa339 (Fin4) ---- *)

Definition refa339_op (x y : Fin4) : Fin4 :=
  match x, y with
  | F4_0, F4_0 => F4_0 | F4_0, F4_1 => F4_3 | F4_0, F4_2 => F4_1 | F4_0, F4_3 => F4_3
  | F4_1, F4_0 => F4_3 | F4_1, F4_1 => F4_1 | F4_1, F4_2 => F4_2 | F4_1, F4_3 => F4_3
  | F4_2, F4_0 => F4_3 | F4_2, F4_1 => F4_1 | F4_2, F4_2 => F4_2 | F4_2, F4_3 => F4_3
  | F4_3, F4_0 => F4_0 | F4_3, F4_1 => F4_1 | F4_3, F4_2 => F4_2 | F4_3, F4_3 => F4_3
  end.

#[local] Instance refa339_inst : Magma Fin4 := {| magma_op := refa339_op |}.

Lemma refa339_sat2296 : @Equation2296 Fin4 refa339_inst.
Proof. unfold Equation2296, magma_op, refa339_inst, refa339_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa339_not2266 : ~ @Equation2266 Fin4 refa339_inst.
Proof. unfold Equation2266. intro H. specialize (H F4_0 F4_2). unfold magma_op, refa339_inst, refa339_op in H. discriminate H. Qed.

Lemma refa339_not2330 : ~ @Equation2330 Fin4 refa339_inst.
Proof. unfold Equation2330. intro H. specialize (H F4_0 F4_2). unfold magma_op, refa339_inst, refa339_op in H. discriminate H. Qed.

Lemma refa339_not2449 : ~ @Equation2449 Fin4 refa339_inst.
Proof. unfold Equation2449. intro H. specialize (H F4_0 F4_2). unfold magma_op, refa339_inst, refa339_op in H. discriminate H. Qed.

Lemma refa339_not2459 : ~ @Equation2459 Fin4 refa339_inst.
Proof. unfold Equation2459. intro H. specialize (H F4_0 F4_2). unfold magma_op, refa339_inst, refa339_op in H. discriminate H. Qed.

(** ---- refa34 (Fin6) ---- *)

Definition refa34_op (x y : Fin6) : Fin6 :=
  match x, y with
  | F6_0, F6_0 => F6_1 | F6_0, F6_1 => F6_0 | F6_0, F6_2 => F6_3 | F6_0, F6_3 => F6_2 | F6_0, F6_4 => F6_5 | F6_0, F6_5 => F6_4
  | F6_1, F6_0 => F6_2 | F6_1, F6_1 => F6_3 | F6_1, F6_2 => F6_4 | F6_1, F6_3 => F6_5 | F6_1, F6_4 => F6_0 | F6_1, F6_5 => F6_1
  | F6_2, F6_0 => F6_5 | F6_2, F6_1 => F6_4 | F6_2, F6_2 => F6_1 | F6_2, F6_3 => F6_0 | F6_2, F6_4 => F6_3 | F6_2, F6_5 => F6_2
  | F6_3, F6_0 => F6_0 | F6_3, F6_1 => F6_1 | F6_3, F6_2 => F6_2 | F6_3, F6_3 => F6_3 | F6_3, F6_4 => F6_4 | F6_3, F6_5 => F6_5
  | F6_4, F6_0 => F6_3 | F6_4, F6_1 => F6_2 | F6_4, F6_2 => F6_5 | F6_4, F6_3 => F6_4 | F6_4, F6_4 => F6_1 | F6_4, F6_5 => F6_0
  | F6_5, F6_0 => F6_4 | F6_5, F6_1 => F6_5 | F6_5, F6_2 => F6_0 | F6_5, F6_3 => F6_1 | F6_5, F6_4 => F6_2 | F6_5, F6_5 => F6_3
  end.

#[local] Instance refa34_inst : Magma Fin6 := {| magma_op := refa34_op |}.

Lemma refa34_sat1898 : @Equation1898 Fin6 refa34_inst.
Proof. unfold Equation1898, magma_op, refa34_inst, refa34_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa34_sat2710 : @Equation2710 Fin6 refa34_inst.
Proof. unfold Equation2710, magma_op, refa34_inst, refa34_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa34_not1629 : ~ @Equation1629 Fin6 refa34_inst.
Proof. unfold Equation1629. intro H. specialize (H F6_0). unfold magma_op, refa34_inst, refa34_op in H. discriminate H. Qed.

Lemma refa34_not2124 : ~ @Equation2124 Fin6 refa34_inst.
Proof. unfold Equation2124. intro H. specialize (H F6_0 F6_0). unfold magma_op, refa34_inst, refa34_op in H. discriminate H. Qed.

Lemma refa34_not2541 : ~ @Equation2541 Fin6 refa34_inst.
Proof. unfold Equation2541. intro H. specialize (H F6_0 F6_1). unfold magma_op, refa34_inst, refa34_op in H. discriminate H. Qed.

Lemma refa34_not2744 : ~ @Equation2744 Fin6 refa34_inst.
Proof. unfold Equation2744. intro H. specialize (H F6_0 F6_1). unfold magma_op, refa34_inst, refa34_op in H. discriminate H. Qed.

Lemma refa34_not2949 : ~ @Equation2949 Fin6 refa34_inst.
Proof. unfold Equation2949. intro H. specialize (H F6_0 F6_0). unfold magma_op, refa34_inst, refa34_op in H. discriminate H. Qed.

Lemma refa34_not3050 : ~ @Equation3050 Fin6 refa34_inst.
Proof. unfold Equation3050. intro H. specialize (H F6_0). unfold magma_op, refa34_inst, refa34_op in H. discriminate H. Qed.

Lemma refa34_not3271 : ~ @Equation3271 Fin6 refa34_inst.
Proof. unfold Equation3271. intro H. specialize (H F6_0 F6_1). unfold magma_op, refa34_inst, refa34_op in H. discriminate H. Qed.

Lemma refa34_not3464 : ~ @Equation3464 Fin6 refa34_inst.
Proof. unfold Equation3464. intro H. specialize (H F6_0 F6_0). unfold magma_op, refa34_inst, refa34_op in H. discriminate H. Qed.

Lemma refa34_not3509 : ~ @Equation3509 Fin6 refa34_inst.
Proof. unfold Equation3509. intro H. specialize (H F6_0 F6_0). unfold magma_op, refa34_inst, refa34_op in H. discriminate H. Qed.

Lemma refa34_not4480 : ~ @Equation4480 Fin6 refa34_inst.
Proof. unfold Equation4480. intro H. specialize (H F6_0 F6_0). unfold magma_op, refa34_inst, refa34_op in H. discriminate H. Qed.

(** ---- refa340 (Fin4) ---- *)

Definition refa340_op (x y : Fin4) : Fin4 :=
  match x, y with
  | F4_0, F4_0 => F4_0 | F4_0, F4_1 => F4_1 | F4_0, F4_2 => F4_2 | F4_0, F4_3 => F4_3
  | F4_1, F4_0 => F4_2 | F4_1, F4_1 => F4_3 | F4_1, F4_2 => F4_3 | F4_1, F4_3 => F4_2
  | F4_2, F4_0 => F4_3 | F4_2, F4_1 => F4_3 | F4_2, F4_2 => F4_1 | F4_2, F4_3 => F4_1
  | F4_3, F4_0 => F4_1 | F4_3, F4_1 => F4_2 | F4_3, F4_2 => F4_1 | F4_3, F4_3 => F4_2
  end.

#[local] Instance refa340_inst : Magma Fin4 := {| magma_op := refa340_op |}.

Lemma refa340_sat4154 : @Equation4154 Fin4 refa340_inst.
Proof. unfold Equation4154, magma_op, refa340_inst, refa340_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa340_not3308 : ~ @Equation3308 Fin4 refa340_inst.
Proof. unfold Equation3308. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa340_inst, refa340_op in H. discriminate H. Qed.

Lemma refa340_not3315 : ~ @Equation3315 Fin4 refa340_inst.
Proof. unfold Equation3315. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa340_inst, refa340_op in H. discriminate H. Qed.

Lemma refa340_not3319 : ~ @Equation3319 Fin4 refa340_inst.
Proof. unfold Equation3319. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa340_inst, refa340_op in H. discriminate H. Qed.

Lemma refa340_not3342 : ~ @Equation3342 Fin4 refa340_inst.
Proof. unfold Equation3342. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa340_inst, refa340_op in H. discriminate H. Qed.

Lemma refa340_not3346 : ~ @Equation3346 Fin4 refa340_inst.
Proof. unfold Equation3346. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa340_inst, refa340_op in H. discriminate H. Qed.

Lemma refa340_not3353 : ~ @Equation3353 Fin4 refa340_inst.
Proof. unfold Equation3353. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa340_inst, refa340_op in H. discriminate H. Qed.

Lemma refa340_not3355 : ~ @Equation3355 Fin4 refa340_inst.
Proof. unfold Equation3355. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa340_inst, refa340_op in H. discriminate H. Qed.

Lemma refa340_not3509 : ~ @Equation3509 Fin4 refa340_inst.
Proof. unfold Equation3509. intro H. specialize (H F4_1 F4_0). unfold magma_op, refa340_inst, refa340_op in H. discriminate H. Qed.

Lemma refa340_not3511 : ~ @Equation3511 Fin4 refa340_inst.
Proof. unfold Equation3511. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa340_inst, refa340_op in H. discriminate H. Qed.

Lemma refa340_not3518 : ~ @Equation3518 Fin4 refa340_inst.
Proof. unfold Equation3518. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa340_inst, refa340_op in H. discriminate H. Qed.

Lemma refa340_not3522 : ~ @Equation3522 Fin4 refa340_inst.
Proof. unfold Equation3522. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa340_inst, refa340_op in H. discriminate H. Qed.

Lemma refa340_not3545 : ~ @Equation3545 Fin4 refa340_inst.
Proof. unfold Equation3545. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa340_inst, refa340_op in H. discriminate H. Qed.

Lemma refa340_not3549 : ~ @Equation3549 Fin4 refa340_inst.
Proof. unfold Equation3549. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa340_inst, refa340_op in H. discriminate H. Qed.

Lemma refa340_not3556 : ~ @Equation3556 Fin4 refa340_inst.
Proof. unfold Equation3556. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa340_inst, refa340_op in H. discriminate H. Qed.

Lemma refa340_not3558 : ~ @Equation3558 Fin4 refa340_inst.
Proof. unfold Equation3558. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa340_inst, refa340_op in H. discriminate H. Qed.

Lemma refa340_not3659 : ~ @Equation3659 Fin4 refa340_inst.
Proof. unfold Equation3659. intro H. specialize (H F4_1). unfold magma_op, refa340_inst, refa340_op in H. discriminate H. Qed.

Lemma refa340_not3915 : ~ @Equation3915 Fin4 refa340_inst.
Proof. unfold Equation3915. intro H. specialize (H F4_1 F4_0). unfold magma_op, refa340_inst, refa340_op in H. discriminate H. Qed.

Lemma refa340_not3917 : ~ @Equation3917 Fin4 refa340_inst.
Proof. unfold Equation3917. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa340_inst, refa340_op in H. discriminate H. Qed.

Lemma refa340_not3924 : ~ @Equation3924 Fin4 refa340_inst.
Proof. unfold Equation3924. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa340_inst, refa340_op in H. discriminate H. Qed.

Lemma refa340_not3928 : ~ @Equation3928 Fin4 refa340_inst.
Proof. unfold Equation3928. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa340_inst, refa340_op in H. discriminate H. Qed.

Lemma refa340_not3951 : ~ @Equation3951 Fin4 refa340_inst.
Proof. unfold Equation3951. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa340_inst, refa340_op in H. discriminate H. Qed.

Lemma refa340_not3955 : ~ @Equation3955 Fin4 refa340_inst.
Proof. unfold Equation3955. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa340_inst, refa340_op in H. discriminate H. Qed.

Lemma refa340_not3962 : ~ @Equation3962 Fin4 refa340_inst.
Proof. unfold Equation3962. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa340_inst, refa340_op in H. discriminate H. Qed.

Lemma refa340_not3964 : ~ @Equation3964 Fin4 refa340_inst.
Proof. unfold Equation3964. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa340_inst, refa340_op in H. discriminate H. Qed.

Lemma refa340_not4118 : ~ @Equation4118 Fin4 refa340_inst.
Proof. unfold Equation4118. intro H. specialize (H F4_1 F4_0). unfold magma_op, refa340_inst, refa340_op in H. discriminate H. Qed.

Lemma refa340_not4120 : ~ @Equation4120 Fin4 refa340_inst.
Proof. unfold Equation4120. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa340_inst, refa340_op in H. discriminate H. Qed.

Lemma refa340_not4127 : ~ @Equation4127 Fin4 refa340_inst.
Proof. unfold Equation4127. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa340_inst, refa340_op in H. discriminate H. Qed.

Lemma refa340_not4158 : ~ @Equation4158 Fin4 refa340_inst.
Proof. unfold Equation4158. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa340_inst, refa340_op in H. discriminate H. Qed.

Lemma refa340_not4165 : ~ @Equation4165 Fin4 refa340_inst.
Proof. unfold Equation4165. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa340_inst, refa340_op in H. discriminate H. Qed.

Lemma refa340_not4167 : ~ @Equation4167 Fin4 refa340_inst.
Proof. unfold Equation4167. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa340_inst, refa340_op in H. discriminate H. Qed.

Lemma refa340_not4283 : ~ @Equation4283 Fin4 refa340_inst.
Proof. unfold Equation4283. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa340_inst, refa340_op in H. discriminate H. Qed.

Lemma refa340_not4290 : ~ @Equation4290 Fin4 refa340_inst.
Proof. unfold Equation4290. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa340_inst, refa340_op in H. discriminate H. Qed.

Lemma refa340_not4320 : ~ @Equation4320 Fin4 refa340_inst.
Proof. unfold Equation4320. intro H. specialize (H F4_1 F4_2). unfold magma_op, refa340_inst, refa340_op in H. discriminate H. Qed.

Lemma refa340_not4396 : ~ @Equation4396 Fin4 refa340_inst.
Proof. unfold Equation4396. intro H. specialize (H F4_1 F4_0). unfold magma_op, refa340_inst, refa340_op in H. discriminate H. Qed.

Lemma refa340_not4398 : ~ @Equation4398 Fin4 refa340_inst.
Proof. unfold Equation4398. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa340_inst, refa340_op in H. discriminate H. Qed.

Lemma refa340_not4405 : ~ @Equation4405 Fin4 refa340_inst.
Proof. unfold Equation4405. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa340_inst, refa340_op in H. discriminate H. Qed.

Lemma refa340_not4433 : ~ @Equation4433 Fin4 refa340_inst.
Proof. unfold Equation4433. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa340_inst, refa340_op in H. discriminate H. Qed.

Lemma refa340_not4442 : ~ @Equation4442 Fin4 refa340_inst.
Proof. unfold Equation4442. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa340_inst, refa340_op in H. discriminate H. Qed.

Lemma refa340_not4473 : ~ @Equation4473 Fin4 refa340_inst.
Proof. unfold Equation4473. intro H. specialize (H F4_1 F4_0). unfold magma_op, refa340_inst, refa340_op in H. discriminate H. Qed.

Lemma refa340_not4480 : ~ @Equation4480 Fin4 refa340_inst.
Proof. unfold Equation4480. intro H. specialize (H F4_1 F4_2). unfold magma_op, refa340_inst, refa340_op in H. discriminate H. Qed.

Lemma refa340_not4482 : ~ @Equation4482 Fin4 refa340_inst.
Proof. unfold Equation4482. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa340_inst, refa340_op in H. discriminate H. Qed.

Lemma refa340_not4598 : ~ @Equation4598 Fin4 refa340_inst.
Proof. unfold Equation4598. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa340_inst, refa340_op in H. discriminate H. Qed.

Lemma refa340_not4605 : ~ @Equation4605 Fin4 refa340_inst.
Proof. unfold Equation4605. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa340_inst, refa340_op in H. discriminate H. Qed.

Lemma refa340_not4635 : ~ @Equation4635 Fin4 refa340_inst.
Proof. unfold Equation4635. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa340_inst, refa340_op in H. discriminate H. Qed.

(** ---- refa341 (Fin4) ---- *)

Definition refa341_op (x y : Fin4) : Fin4 :=
  match x, y with
  | F4_0, F4_0 => F4_0 | F4_0, F4_1 => F4_0 | F4_0, F4_2 => F4_0 | F4_0, F4_3 => F4_1
  | F4_1, F4_0 => F4_1 | F4_1, F4_1 => F4_1 | F4_1, F4_2 => F4_1 | F4_1, F4_3 => F4_0
  | F4_2, F4_0 => F4_1 | F4_2, F4_1 => F4_2 | F4_2, F4_2 => F4_2 | F4_2, F4_3 => F4_2
  | F4_3, F4_0 => F4_3 | F4_3, F4_1 => F4_0 | F4_3, F4_2 => F4_0 | F4_3, F4_3 => F4_3
  end.

#[local] Instance refa341_inst : Magma Fin4 := {| magma_op := refa341_op |}.

Lemma refa341_sat1236 : @Equation1236 Fin4 refa341_inst.
Proof. unfold Equation1236, magma_op, refa341_inst, refa341_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa341_not1026 : ~ @Equation1026 Fin4 refa341_inst.
Proof. unfold Equation1026. intro H. specialize (H F4_2 F4_3). unfold magma_op, refa341_inst, refa341_op in H. discriminate H. Qed.

(** ---- refa342 (Fin4) ---- *)

Definition refa342_op (x y : Fin4) : Fin4 :=
  match x, y with
  | F4_0, F4_0 => F4_2 | F4_0, F4_1 => F4_0 | F4_0, F4_2 => F4_1 | F4_0, F4_3 => F4_3
  | F4_1, F4_0 => F4_3 | F4_1, F4_1 => F4_0 | F4_1, F4_2 => F4_2 | F4_1, F4_3 => F4_1
  | F4_2, F4_0 => F4_2 | F4_2, F4_1 => F4_1 | F4_2, F4_2 => F4_3 | F4_2, F4_3 => F4_0
  | F4_3, F4_0 => F4_0 | F4_3, F4_1 => F4_2 | F4_3, F4_2 => F4_3 | F4_3, F4_3 => F4_1
  end.

#[local] Instance refa342_inst : Magma Fin4 := {| magma_op := refa342_op |}.

Lemma refa342_sat2743 : @Equation2743 Fin4 refa342_inst.
Proof. unfold Equation2743, magma_op, refa342_inst, refa342_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa342_not23 : ~ @Equation23 Fin4 refa342_inst.
Proof. unfold Equation23. intro H. specialize (H F4_0). unfold magma_op, refa342_inst, refa342_op in H. discriminate H. Qed.

Lemma refa342_not99 : ~ @Equation99 Fin4 refa342_inst.
Proof. unfold Equation99. intro H. specialize (H F4_0). unfold magma_op, refa342_inst, refa342_op in H. discriminate H. Qed.

Lemma refa342_not159 : ~ @Equation159 Fin4 refa342_inst.
Proof. unfold Equation159. intro H. specialize (H F4_0 F4_0). unfold magma_op, refa342_inst, refa342_op in H. discriminate H. Qed.

Lemma refa342_not211 : ~ @Equation211 Fin4 refa342_inst.
Proof. unfold Equation211. intro H. specialize (H F4_0 F4_0). unfold magma_op, refa342_inst, refa342_op in H. discriminate H. Qed.

Lemma refa342_not231 : ~ @Equation231 Fin4 refa342_inst.
Proof. unfold Equation231. intro H. specialize (H F4_0 F4_0). unfold magma_op, refa342_inst, refa342_op in H. discriminate H. Qed.

Lemma refa342_not280 : ~ @Equation280 Fin4 refa342_inst.
Proof. unfold Equation280. intro H. specialize (H F4_0 F4_0). unfold magma_op, refa342_inst, refa342_op in H. discriminate H. Qed.

Lemma refa342_not283 : ~ @Equation283 Fin4 refa342_inst.
Proof. unfold Equation283. intro H. specialize (H F4_0 F4_0). unfold magma_op, refa342_inst, refa342_op in H. discriminate H. Qed.

Lemma refa342_not323 : ~ @Equation323 Fin4 refa342_inst.
Proof. unfold Equation323. intro H. specialize (H F4_0 F4_0). unfold magma_op, refa342_inst, refa342_op in H. discriminate H. Qed.

Lemma refa342_not333 : ~ @Equation333 Fin4 refa342_inst.
Proof. unfold Equation333. intro H. specialize (H F4_0 F4_0). unfold magma_op, refa342_inst, refa342_op in H. discriminate H. Qed.

Lemma refa342_not378 : ~ @Equation378 Fin4 refa342_inst.
Proof. unfold Equation378. intro H. specialize (H F4_0 F4_2). unfold magma_op, refa342_inst, refa342_op in H. discriminate H. Qed.

Lemma refa342_not411 : ~ @Equation411 Fin4 refa342_inst.
Proof. unfold Equation411. intro H. specialize (H F4_0). unfold magma_op, refa342_inst, refa342_op in H. discriminate H. Qed.

Lemma refa342_not616 : ~ @Equation616 Fin4 refa342_inst.
Proof. unfold Equation616. intro H. specialize (H F4_0 F4_2). unfold magma_op, refa342_inst, refa342_op in H. discriminate H. Qed.

Lemma refa342_not619 : ~ @Equation619 Fin4 refa342_inst.
Proof. unfold Equation619. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa342_inst, refa342_op in H. discriminate H. Qed.

Lemma refa342_not622 : ~ @Equation622 Fin4 refa342_inst.
Proof. unfold Equation622. intro H. specialize (H F4_0 F4_2). unfold magma_op, refa342_inst, refa342_op in H. discriminate H. Qed.

Lemma refa342_not629 : ~ @Equation629 Fin4 refa342_inst.
Proof. unfold Equation629. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa342_inst, refa342_op in H. discriminate H. Qed.

Lemma refa342_not632 : ~ @Equation632 Fin4 refa342_inst.
Proof. unfold Equation632. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa342_inst, refa342_op in H. discriminate H. Qed.

Lemma refa342_not639 : ~ @Equation639 Fin4 refa342_inst.
Proof. unfold Equation639. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa342_inst, refa342_op in H. discriminate H. Qed.

Lemma refa342_not679 : ~ @Equation679 Fin4 refa342_inst.
Proof. unfold Equation679. intro H. specialize (H F4_0 F4_2). unfold magma_op, refa342_inst, refa342_op in H. discriminate H. Qed.

Lemma refa342_not706 : ~ @Equation706 Fin4 refa342_inst.
Proof. unfold Equation706. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa342_inst, refa342_op in H. discriminate H. Qed.

Lemma refa342_not713 : ~ @Equation713 Fin4 refa342_inst.
Proof. unfold Equation713. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa342_inst, refa342_op in H. discriminate H. Qed.

Lemma refa342_not819 : ~ @Equation819 Fin4 refa342_inst.
Proof. unfold Equation819. intro H. specialize (H F4_0 F4_0). unfold magma_op, refa342_inst, refa342_op in H. discriminate H. Qed.

Lemma refa342_not822 : ~ @Equation822 Fin4 refa342_inst.
Proof. unfold Equation822. intro H. specialize (H F4_0 F4_0). unfold magma_op, refa342_inst, refa342_op in H. discriminate H. Qed.

Lemma refa342_not832 : ~ @Equation832 Fin4 refa342_inst.
Proof. unfold Equation832. intro H. specialize (H F4_0 F4_0). unfold magma_op, refa342_inst, refa342_op in H. discriminate H. Qed.

Lemma refa342_not835 : ~ @Equation835 Fin4 refa342_inst.
Proof. unfold Equation835. intro H. specialize (H F4_0 F4_0). unfold magma_op, refa342_inst, refa342_op in H. discriminate H. Qed.

Lemma refa342_not842 : ~ @Equation842 Fin4 refa342_inst.
Proof. unfold Equation842. intro H. specialize (H F4_0 F4_0). unfold magma_op, refa342_inst, refa342_op in H. discriminate H. Qed.

Lemma refa342_not872 : ~ @Equation872 Fin4 refa342_inst.
Proof. unfold Equation872. intro H. specialize (H F4_0 F4_0). unfold magma_op, refa342_inst, refa342_op in H. discriminate H. Qed.

Lemma refa342_not879 : ~ @Equation879 Fin4 refa342_inst.
Proof. unfold Equation879. intro H. specialize (H F4_0 F4_0). unfold magma_op, refa342_inst, refa342_op in H. discriminate H. Qed.

Lemma refa342_not906 : ~ @Equation906 Fin4 refa342_inst.
Proof. unfold Equation906. intro H. specialize (H F4_0 F4_0). unfold magma_op, refa342_inst, refa342_op in H. discriminate H. Qed.

Lemma refa342_not1028 : ~ @Equation1028 Fin4 refa342_inst.
Proof. unfold Equation1028. intro H. specialize (H F4_0 F4_0). unfold magma_op, refa342_inst, refa342_op in H. discriminate H. Qed.

Lemma refa342_not1035 : ~ @Equation1035 Fin4 refa342_inst.
Proof. unfold Equation1035. intro H. specialize (H F4_0 F4_0). unfold magma_op, refa342_inst, refa342_op in H. discriminate H. Qed.

Lemma refa342_not1048 : ~ @Equation1048 Fin4 refa342_inst.
Proof. unfold Equation1048. intro H. specialize (H F4_0 F4_0). unfold magma_op, refa342_inst, refa342_op in H. discriminate H. Qed.

Lemma refa342_not1085 : ~ @Equation1085 Fin4 refa342_inst.
Proof. unfold Equation1085. intro H. specialize (H F4_0 F4_0). unfold magma_op, refa342_inst, refa342_op in H. discriminate H. Qed.

Lemma refa342_not1109 : ~ @Equation1109 Fin4 refa342_inst.
Proof. unfold Equation1109. intro H. specialize (H F4_0 F4_0). unfold magma_op, refa342_inst, refa342_op in H. discriminate H. Qed.

Lemma refa342_not1238 : ~ @Equation1238 Fin4 refa342_inst.
Proof. unfold Equation1238. intro H. specialize (H F4_0 F4_0). unfold magma_op, refa342_inst, refa342_op in H. discriminate H. Qed.

Lemma refa342_not1248 : ~ @Equation1248 Fin4 refa342_inst.
Proof. unfold Equation1248. intro H. specialize (H F4_0 F4_0). unfold magma_op, refa342_inst, refa342_op in H. discriminate H. Qed.

Lemma refa342_not1251 : ~ @Equation1251 Fin4 refa342_inst.
Proof. unfold Equation1251. intro H. specialize (H F4_0 F4_0). unfold magma_op, refa342_inst, refa342_op in H. discriminate H. Qed.

Lemma refa342_not1278 : ~ @Equation1278 Fin4 refa342_inst.
Proof. unfold Equation1278. intro H. specialize (H F4_0 F4_0). unfold magma_op, refa342_inst, refa342_op in H. discriminate H. Qed.

Lemma refa342_not1288 : ~ @Equation1288 Fin4 refa342_inst.
Proof. unfold Equation1288. intro H. specialize (H F4_0 F4_0). unfold magma_op, refa342_inst, refa342_op in H. discriminate H. Qed.

Lemma refa342_not1322 : ~ @Equation1322 Fin4 refa342_inst.
Proof. unfold Equation1322. intro H. specialize (H F4_0 F4_0). unfold magma_op, refa342_inst, refa342_op in H. discriminate H. Qed.

Lemma refa342_not1428 : ~ @Equation1428 Fin4 refa342_inst.
Proof. unfold Equation1428. intro H. specialize (H F4_0 F4_0). unfold magma_op, refa342_inst, refa342_op in H. discriminate H. Qed.

Lemma refa342_not1431 : ~ @Equation1431 Fin4 refa342_inst.
Proof. unfold Equation1431. intro H. specialize (H F4_0 F4_0). unfold magma_op, refa342_inst, refa342_op in H. discriminate H. Qed.

Lemma refa342_not1441 : ~ @Equation1441 Fin4 refa342_inst.
Proof. unfold Equation1441. intro H. specialize (H F4_0 F4_0). unfold magma_op, refa342_inst, refa342_op in H. discriminate H. Qed.

Lemma refa342_not1451 : ~ @Equation1451 Fin4 refa342_inst.
Proof. unfold Equation1451. intro H. specialize (H F4_0 F4_0). unfold magma_op, refa342_inst, refa342_op in H. discriminate H. Qed.

Lemma refa342_not1454 : ~ @Equation1454 Fin4 refa342_inst.
Proof. unfold Equation1454. intro H. specialize (H F4_0 F4_0). unfold magma_op, refa342_inst, refa342_op in H. discriminate H. Qed.

Lemma refa342_not1478 : ~ @Equation1478 Fin4 refa342_inst.
Proof. unfold Equation1478. intro H. specialize (H F4_0 F4_0). unfold magma_op, refa342_inst, refa342_op in H. discriminate H. Qed.

Lemma refa342_not1488 : ~ @Equation1488 Fin4 refa342_inst.
Proof. unfold Equation1488. intro H. specialize (H F4_0 F4_0). unfold magma_op, refa342_inst, refa342_op in H. discriminate H. Qed.

Lemma refa342_not1491 : ~ @Equation1491 Fin4 refa342_inst.
Proof. unfold Equation1491. intro H. specialize (H F4_0 F4_0). unfold magma_op, refa342_inst, refa342_op in H. discriminate H. Qed.

Lemma refa342_not1515 : ~ @Equation1515 Fin4 refa342_inst.
Proof. unfold Equation1515. intro H. specialize (H F4_0 F4_0). unfold magma_op, refa342_inst, refa342_op in H. discriminate H. Qed.

Lemma refa342_not1518 : ~ @Equation1518 Fin4 refa342_inst.
Proof. unfold Equation1518. intro H. specialize (H F4_0 F4_0). unfold magma_op, refa342_inst, refa342_op in H. discriminate H. Qed.

Lemma refa342_not1631 : ~ @Equation1631 Fin4 refa342_inst.
Proof. unfold Equation1631. intro H. specialize (H F4_0 F4_0). unfold magma_op, refa342_inst, refa342_op in H. discriminate H. Qed.

Lemma refa342_not1634 : ~ @Equation1634 Fin4 refa342_inst.
Proof. unfold Equation1634. intro H. specialize (H F4_0 F4_0). unfold magma_op, refa342_inst, refa342_op in H. discriminate H. Qed.

Lemma refa342_not1637 : ~ @Equation1637 Fin4 refa342_inst.
Proof. unfold Equation1637. intro H. specialize (H F4_0 F4_0). unfold magma_op, refa342_inst, refa342_op in H. discriminate H. Qed.

Lemma refa342_not1644 : ~ @Equation1644 Fin4 refa342_inst.
Proof. unfold Equation1644. intro H. specialize (H F4_0 F4_0). unfold magma_op, refa342_inst, refa342_op in H. discriminate H. Qed.

Lemma refa342_not1681 : ~ @Equation1681 Fin4 refa342_inst.
Proof. unfold Equation1681. intro H. specialize (H F4_0 F4_0). unfold magma_op, refa342_inst, refa342_op in H. discriminate H. Qed.

Lemma refa342_not1721 : ~ @Equation1721 Fin4 refa342_inst.
Proof. unfold Equation1721. intro H. specialize (H F4_0 F4_0). unfold magma_op, refa342_inst, refa342_op in H. discriminate H. Qed.

Lemma refa342_not1728 : ~ @Equation1728 Fin4 refa342_inst.
Proof. unfold Equation1728. intro H. specialize (H F4_0 F4_0). unfold magma_op, refa342_inst, refa342_op in H. discriminate H. Qed.

Lemma refa342_not1834 : ~ @Equation1834 Fin4 refa342_inst.
Proof. unfold Equation1834. intro H. specialize (H F4_0 F4_0). unfold magma_op, refa342_inst, refa342_op in H. discriminate H. Qed.

Lemma refa342_not1837 : ~ @Equation1837 Fin4 refa342_inst.
Proof. unfold Equation1837. intro H. specialize (H F4_0 F4_0). unfold magma_op, refa342_inst, refa342_op in H. discriminate H. Qed.

Lemma refa342_not1847 : ~ @Equation1847 Fin4 refa342_inst.
Proof. unfold Equation1847. intro H. specialize (H F4_0 F4_0). unfold magma_op, refa342_inst, refa342_op in H. discriminate H. Qed.

Lemma refa342_not1857 : ~ @Equation1857 Fin4 refa342_inst.
Proof. unfold Equation1857. intro H. specialize (H F4_0 F4_0). unfold magma_op, refa342_inst, refa342_op in H. discriminate H. Qed.

Lemma refa342_not1887 : ~ @Equation1887 Fin4 refa342_inst.
Proof. unfold Equation1887. intro H. specialize (H F4_0 F4_0). unfold magma_op, refa342_inst, refa342_op in H. discriminate H. Qed.

Lemma refa342_not1897 : ~ @Equation1897 Fin4 refa342_inst.
Proof. unfold Equation1897. intro H. specialize (H F4_0 F4_0). unfold magma_op, refa342_inst, refa342_op in H. discriminate H. Qed.

Lemma refa342_not1924 : ~ @Equation1924 Fin4 refa342_inst.
Proof. unfold Equation1924. intro H. specialize (H F4_0 F4_0). unfold magma_op, refa342_inst, refa342_op in H. discriminate H. Qed.

Lemma refa342_not1931 : ~ @Equation1931 Fin4 refa342_inst.
Proof. unfold Equation1931. intro H. specialize (H F4_0 F4_0). unfold magma_op, refa342_inst, refa342_op in H. discriminate H. Qed.

Lemma refa342_not2035 : ~ @Equation2035 Fin4 refa342_inst.
Proof. unfold Equation2035. intro H. specialize (H F4_0). unfold magma_op, refa342_inst, refa342_op in H. discriminate H. Qed.

Lemma refa342_not2240 : ~ @Equation2240 Fin4 refa342_inst.
Proof. unfold Equation2240. intro H. specialize (H F4_0 F4_0). unfold magma_op, refa342_inst, refa342_op in H. discriminate H. Qed.

Lemma refa342_not2243 : ~ @Equation2243 Fin4 refa342_inst.
Proof. unfold Equation2243. intro H. specialize (H F4_0 F4_0). unfold magma_op, refa342_inst, refa342_op in H. discriminate H. Qed.

Lemma refa342_not2246 : ~ @Equation2246 Fin4 refa342_inst.
Proof. unfold Equation2246. intro H. specialize (H F4_0 F4_0). unfold magma_op, refa342_inst, refa342_op in H. discriminate H. Qed.

Lemma refa342_not2253 : ~ @Equation2253 Fin4 refa342_inst.
Proof. unfold Equation2253. intro H. specialize (H F4_0 F4_0). unfold magma_op, refa342_inst, refa342_op in H. discriminate H. Qed.

Lemma refa342_not2266 : ~ @Equation2266 Fin4 refa342_inst.
Proof. unfold Equation2266. intro H. specialize (H F4_0 F4_0). unfold magma_op, refa342_inst, refa342_op in H. discriminate H. Qed.

Lemma refa342_not2290 : ~ @Equation2290 Fin4 refa342_inst.
Proof. unfold Equation2290. intro H. specialize (H F4_0 F4_0). unfold magma_op, refa342_inst, refa342_op in H. discriminate H. Qed.

Lemma refa342_not2300 : ~ @Equation2300 Fin4 refa342_inst.
Proof. unfold Equation2300. intro H. specialize (H F4_0 F4_0). unfold magma_op, refa342_inst, refa342_op in H. discriminate H. Qed.

Lemma refa342_not2330 : ~ @Equation2330 Fin4 refa342_inst.
Proof. unfold Equation2330. intro H. specialize (H F4_0 F4_0). unfold magma_op, refa342_inst, refa342_op in H. discriminate H. Qed.

Lemma refa342_not2340 : ~ @Equation2340 Fin4 refa342_inst.
Proof. unfold Equation2340. intro H. specialize (H F4_0 F4_0). unfold magma_op, refa342_inst, refa342_op in H. discriminate H. Qed.

Lemma refa342_not2443 : ~ @Equation2443 Fin4 refa342_inst.
Proof. unfold Equation2443. intro H. specialize (H F4_0 F4_0). unfold magma_op, refa342_inst, refa342_op in H. discriminate H. Qed.

Lemma refa342_not2456 : ~ @Equation2456 Fin4 refa342_inst.
Proof. unfold Equation2456. intro H. specialize (H F4_0 F4_0). unfold magma_op, refa342_inst, refa342_op in H. discriminate H. Qed.

Lemma refa342_not2466 : ~ @Equation2466 Fin4 refa342_inst.
Proof. unfold Equation2466. intro H. specialize (H F4_0 F4_0). unfold magma_op, refa342_inst, refa342_op in H. discriminate H. Qed.

Lemma refa342_not2469 : ~ @Equation2469 Fin4 refa342_inst.
Proof. unfold Equation2469. intro H. specialize (H F4_0 F4_0). unfold magma_op, refa342_inst, refa342_op in H. discriminate H. Qed.

Lemma refa342_not2493 : ~ @Equation2493 Fin4 refa342_inst.
Proof. unfold Equation2493. intro H. specialize (H F4_0 F4_0). unfold magma_op, refa342_inst, refa342_op in H. discriminate H. Qed.

Lemma refa342_not2503 : ~ @Equation2503 Fin4 refa342_inst.
Proof. unfold Equation2503. intro H. specialize (H F4_0 F4_0). unfold magma_op, refa342_inst, refa342_op in H. discriminate H. Qed.

Lemma refa342_not2506 : ~ @Equation2506 Fin4 refa342_inst.
Proof. unfold Equation2506. intro H. specialize (H F4_0 F4_0). unfold magma_op, refa342_inst, refa342_op in H. discriminate H. Qed.

Lemma refa342_not2530 : ~ @Equation2530 Fin4 refa342_inst.
Proof. unfold Equation2530. intro H. specialize (H F4_0 F4_0). unfold magma_op, refa342_inst, refa342_op in H. discriminate H. Qed.

Lemma refa342_not2533 : ~ @Equation2533 Fin4 refa342_inst.
Proof. unfold Equation2533. intro H. specialize (H F4_0 F4_0). unfold magma_op, refa342_inst, refa342_op in H. discriminate H. Qed.

Lemma refa342_not2543 : ~ @Equation2543 Fin4 refa342_inst.
Proof. unfold Equation2543. intro H. specialize (H F4_0 F4_0). unfold magma_op, refa342_inst, refa342_op in H. discriminate H. Qed.

Lemma refa342_not2646 : ~ @Equation2646 Fin4 refa342_inst.
Proof. unfold Equation2646. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa342_inst, refa342_op in H. discriminate H. Qed.

Lemma refa342_not2649 : ~ @Equation2649 Fin4 refa342_inst.
Proof. unfold Equation2649. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa342_inst, refa342_op in H. discriminate H. Qed.

Lemma refa342_not2652 : ~ @Equation2652 Fin4 refa342_inst.
Proof. unfold Equation2652. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa342_inst, refa342_op in H. discriminate H. Qed.

Lemma refa342_not2659 : ~ @Equation2659 Fin4 refa342_inst.
Proof. unfold Equation2659. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa342_inst, refa342_op in H. discriminate H. Qed.

Lemma refa342_not2662 : ~ @Equation2662 Fin4 refa342_inst.
Proof. unfold Equation2662. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa342_inst, refa342_op in H. discriminate H. Qed.

Lemma refa342_not2669 : ~ @Equation2669 Fin4 refa342_inst.
Proof. unfold Equation2669. intro H. specialize (H F4_0 F4_2). unfold magma_op, refa342_inst, refa342_op in H. discriminate H. Qed.

Lemma refa342_not2696 : ~ @Equation2696 Fin4 refa342_inst.
Proof. unfold Equation2696. intro H. specialize (H F4_0 F4_3). unfold magma_op, refa342_inst, refa342_op in H. discriminate H. Qed.

Lemma refa342_not2699 : ~ @Equation2699 Fin4 refa342_inst.
Proof. unfold Equation2699. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa342_inst, refa342_op in H. discriminate H. Qed.

Lemma refa342_not2746 : ~ @Equation2746 Fin4 refa342_inst.
Proof. unfold Equation2746. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa342_inst, refa342_op in H. discriminate H. Qed.

Lemma refa342_not2849 : ~ @Equation2849 Fin4 refa342_inst.
Proof. unfold Equation2849. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa342_inst, refa342_op in H. discriminate H. Qed.

Lemma refa342_not2852 : ~ @Equation2852 Fin4 refa342_inst.
Proof. unfold Equation2852. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa342_inst, refa342_op in H. discriminate H. Qed.

Lemma refa342_not2855 : ~ @Equation2855 Fin4 refa342_inst.
Proof. unfold Equation2855. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa342_inst, refa342_op in H. discriminate H. Qed.

Lemma refa342_not2862 : ~ @Equation2862 Fin4 refa342_inst.
Proof. unfold Equation2862. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa342_inst, refa342_op in H. discriminate H. Qed.

Lemma refa342_not2865 : ~ @Equation2865 Fin4 refa342_inst.
Proof. unfold Equation2865. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa342_inst, refa342_op in H. discriminate H. Qed.

Lemma refa342_not2872 : ~ @Equation2872 Fin4 refa342_inst.
Proof. unfold Equation2872. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa342_inst, refa342_op in H. discriminate H. Qed.

Lemma refa342_not2899 : ~ @Equation2899 Fin4 refa342_inst.
Proof. unfold Equation2899. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa342_inst, refa342_op in H. discriminate H. Qed.

Lemma refa342_not2909 : ~ @Equation2909 Fin4 refa342_inst.
Proof. unfold Equation2909. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa342_inst, refa342_op in H. discriminate H. Qed.

Lemma refa342_not2912 : ~ @Equation2912 Fin4 refa342_inst.
Proof. unfold Equation2912. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa342_inst, refa342_op in H. discriminate H. Qed.

Lemma refa342_not2939 : ~ @Equation2939 Fin4 refa342_inst.
Proof. unfold Equation2939. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa342_inst, refa342_op in H. discriminate H. Qed.

Lemma refa342_not2946 : ~ @Equation2946 Fin4 refa342_inst.
Proof. unfold Equation2946. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa342_inst, refa342_op in H. discriminate H. Qed.

Lemma refa342_not2949 : ~ @Equation2949 Fin4 refa342_inst.
Proof. unfold Equation2949. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa342_inst, refa342_op in H. discriminate H. Qed.

Lemma refa342_not3052 : ~ @Equation3052 Fin4 refa342_inst.
Proof. unfold Equation3052. intro H. specialize (H F4_0 F4_0). unfold magma_op, refa342_inst, refa342_op in H. discriminate H. Qed.

Lemma refa342_not3055 : ~ @Equation3055 Fin4 refa342_inst.
Proof. unfold Equation3055. intro H. specialize (H F4_0 F4_0). unfold magma_op, refa342_inst, refa342_op in H. discriminate H. Qed.

Lemma refa342_not3065 : ~ @Equation3065 Fin4 refa342_inst.
Proof. unfold Equation3065. intro H. specialize (H F4_0 F4_0). unfold magma_op, refa342_inst, refa342_op in H. discriminate H. Qed.

Lemma refa342_not3068 : ~ @Equation3068 Fin4 refa342_inst.
Proof. unfold Equation3068. intro H. specialize (H F4_0 F4_0). unfold magma_op, refa342_inst, refa342_op in H. discriminate H. Qed.

Lemma refa342_not3078 : ~ @Equation3078 Fin4 refa342_inst.
Proof. unfold Equation3078. intro H. specialize (H F4_0 F4_0). unfold magma_op, refa342_inst, refa342_op in H. discriminate H. Qed.

Lemma refa342_not3105 : ~ @Equation3105 Fin4 refa342_inst.
Proof. unfold Equation3105. intro H. specialize (H F4_0 F4_0). unfold magma_op, refa342_inst, refa342_op in H. discriminate H. Qed.

Lemma refa342_not3115 : ~ @Equation3115 Fin4 refa342_inst.
Proof. unfold Equation3115. intro H. specialize (H F4_0 F4_0). unfold magma_op, refa342_inst, refa342_op in H. discriminate H. Qed.

Lemma refa342_not3139 : ~ @Equation3139 Fin4 refa342_inst.
Proof. unfold Equation3139. intro H. specialize (H F4_0 F4_0). unfold magma_op, refa342_inst, refa342_op in H. discriminate H. Qed.

Lemma refa342_not3149 : ~ @Equation3149 Fin4 refa342_inst.
Proof. unfold Equation3149. intro H. specialize (H F4_0 F4_0). unfold magma_op, refa342_inst, refa342_op in H. discriminate H. Qed.

Lemma refa342_not3255 : ~ @Equation3255 Fin4 refa342_inst.
Proof. unfold Equation3255. intro H. specialize (H F4_0 F4_0). unfold magma_op, refa342_inst, refa342_op in H. discriminate H. Qed.

Lemma refa342_not3258 : ~ @Equation3258 Fin4 refa342_inst.
Proof. unfold Equation3258. intro H. specialize (H F4_0 F4_0). unfold magma_op, refa342_inst, refa342_op in H. discriminate H. Qed.

Lemma refa342_not3268 : ~ @Equation3268 Fin4 refa342_inst.
Proof. unfold Equation3268. intro H. specialize (H F4_0 F4_0). unfold magma_op, refa342_inst, refa342_op in H. discriminate H. Qed.

Lemma refa342_not3309 : ~ @Equation3309 Fin4 refa342_inst.
Proof. unfold Equation3309. intro H. specialize (H F4_0 F4_0). unfold magma_op, refa342_inst, refa342_op in H. discriminate H. Qed.

Lemma refa342_not3316 : ~ @Equation3316 Fin4 refa342_inst.
Proof. unfold Equation3316. intro H. specialize (H F4_0 F4_0). unfold magma_op, refa342_inst, refa342_op in H. discriminate H. Qed.

Lemma refa342_not3343 : ~ @Equation3343 Fin4 refa342_inst.
Proof. unfold Equation3343. intro H. specialize (H F4_0 F4_0). unfold magma_op, refa342_inst, refa342_op in H. discriminate H. Qed.

Lemma refa342_not3458 : ~ @Equation3458 Fin4 refa342_inst.
Proof. unfold Equation3458. intro H. specialize (H F4_0 F4_0). unfold magma_op, refa342_inst, refa342_op in H. discriminate H. Qed.

Lemma refa342_not3461 : ~ @Equation3461 Fin4 refa342_inst.
Proof. unfold Equation3461. intro H. specialize (H F4_0 F4_0). unfold magma_op, refa342_inst, refa342_op in H. discriminate H. Qed.

Lemma refa342_not3464 : ~ @Equation3464 Fin4 refa342_inst.
Proof. unfold Equation3464. intro H. specialize (H F4_0 F4_0). unfold magma_op, refa342_inst, refa342_op in H. discriminate H. Qed.

Lemma refa342_not3481 : ~ @Equation3481 Fin4 refa342_inst.
Proof. unfold Equation3481. intro H. specialize (H F4_0 F4_0). unfold magma_op, refa342_inst, refa342_op in H. discriminate H. Qed.

Lemma refa342_not3509 : ~ @Equation3509 Fin4 refa342_inst.
Proof. unfold Equation3509. intro H. specialize (H F4_0 F4_0). unfold magma_op, refa342_inst, refa342_op in H. discriminate H. Qed.

Lemma refa342_not3512 : ~ @Equation3512 Fin4 refa342_inst.
Proof. unfold Equation3512. intro H. specialize (H F4_0 F4_0). unfold magma_op, refa342_inst, refa342_op in H. discriminate H. Qed.

Lemma refa342_not3519 : ~ @Equation3519 Fin4 refa342_inst.
Proof. unfold Equation3519. intro H. specialize (H F4_0 F4_0). unfold magma_op, refa342_inst, refa342_op in H. discriminate H. Qed.

Lemma refa342_not3546 : ~ @Equation3546 Fin4 refa342_inst.
Proof. unfold Equation3546. intro H. specialize (H F4_0 F4_0). unfold magma_op, refa342_inst, refa342_op in H. discriminate H. Qed.

Lemma refa342_not3661 : ~ @Equation3661 Fin4 refa342_inst.
Proof. unfold Equation3661. intro H. specialize (H F4_0 F4_0). unfold magma_op, refa342_inst, refa342_op in H. discriminate H. Qed.

Lemma refa342_not3664 : ~ @Equation3664 Fin4 refa342_inst.
Proof. unfold Equation3664. intro H. specialize (H F4_0 F4_0). unfold magma_op, refa342_inst, refa342_op in H. discriminate H. Qed.

Lemma refa342_not3667 : ~ @Equation3667 Fin4 refa342_inst.
Proof. unfold Equation3667. intro H. specialize (H F4_0 F4_0). unfold magma_op, refa342_inst, refa342_op in H. discriminate H. Qed.

Lemma refa342_not3674 : ~ @Equation3674 Fin4 refa342_inst.
Proof. unfold Equation3674. intro H. specialize (H F4_0 F4_0). unfold magma_op, refa342_inst, refa342_op in H. discriminate H. Qed.

Lemma refa342_not3677 : ~ @Equation3677 Fin4 refa342_inst.
Proof. unfold Equation3677. intro H. specialize (H F4_0 F4_0). unfold magma_op, refa342_inst, refa342_op in H. discriminate H. Qed.

Lemma refa342_not3684 : ~ @Equation3684 Fin4 refa342_inst.
Proof. unfold Equation3684. intro H. specialize (H F4_0 F4_0). unfold magma_op, refa342_inst, refa342_op in H. discriminate H. Qed.

Lemma refa342_not3712 : ~ @Equation3712 Fin4 refa342_inst.
Proof. unfold Equation3712. intro H. specialize (H F4_0 F4_0). unfold magma_op, refa342_inst, refa342_op in H. discriminate H. Qed.

Lemma refa342_not3725 : ~ @Equation3725 Fin4 refa342_inst.
Proof. unfold Equation3725. intro H. specialize (H F4_0 F4_0). unfold magma_op, refa342_inst, refa342_op in H. discriminate H. Qed.

Lemma refa342_not3752 : ~ @Equation3752 Fin4 refa342_inst.
Proof. unfold Equation3752. intro H. specialize (H F4_0 F4_0). unfold magma_op, refa342_inst, refa342_op in H. discriminate H. Qed.

Lemma refa342_not3759 : ~ @Equation3759 Fin4 refa342_inst.
Proof. unfold Equation3759. intro H. specialize (H F4_0 F4_0). unfold magma_op, refa342_inst, refa342_op in H. discriminate H. Qed.

Lemma refa342_not3864 : ~ @Equation3864 Fin4 refa342_inst.
Proof. unfold Equation3864. intro H. specialize (H F4_0 F4_0). unfold magma_op, refa342_inst, refa342_op in H. discriminate H. Qed.

Lemma refa342_not3867 : ~ @Equation3867 Fin4 refa342_inst.
Proof. unfold Equation3867. intro H. specialize (H F4_0 F4_0). unfold magma_op, refa342_inst, refa342_op in H. discriminate H. Qed.

Lemma refa342_not3870 : ~ @Equation3870 Fin4 refa342_inst.
Proof. unfold Equation3870. intro H. specialize (H F4_0 F4_0). unfold magma_op, refa342_inst, refa342_op in H. discriminate H. Qed.

Lemma refa342_not3877 : ~ @Equation3877 Fin4 refa342_inst.
Proof. unfold Equation3877. intro H. specialize (H F4_0 F4_0). unfold magma_op, refa342_inst, refa342_op in H. discriminate H. Qed.

Lemma refa342_not3890 : ~ @Equation3890 Fin4 refa342_inst.
Proof. unfold Equation3890. intro H. specialize (H F4_0 F4_0). unfold magma_op, refa342_inst, refa342_op in H. discriminate H. Qed.

Lemma refa342_not3918 : ~ @Equation3918 Fin4 refa342_inst.
Proof. unfold Equation3918. intro H. specialize (H F4_0 F4_0). unfold magma_op, refa342_inst, refa342_op in H. discriminate H. Qed.

Lemma refa342_not3925 : ~ @Equation3925 Fin4 refa342_inst.
Proof. unfold Equation3925. intro H. specialize (H F4_0 F4_0). unfold magma_op, refa342_inst, refa342_op in H. discriminate H. Qed.

Lemma refa342_not3928 : ~ @Equation3928 Fin4 refa342_inst.
Proof. unfold Equation3928. intro H. specialize (H F4_0 F4_0). unfold magma_op, refa342_inst, refa342_op in H. discriminate H. Qed.

Lemma refa342_not3952 : ~ @Equation3952 Fin4 refa342_inst.
Proof. unfold Equation3952. intro H. specialize (H F4_0 F4_0). unfold magma_op, refa342_inst, refa342_op in H. discriminate H. Qed.

Lemma refa342_not4067 : ~ @Equation4067 Fin4 refa342_inst.
Proof. unfold Equation4067. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa342_inst, refa342_op in H. discriminate H. Qed.

Lemma refa342_not4070 : ~ @Equation4070 Fin4 refa342_inst.
Proof. unfold Equation4070. intro H. specialize (H F4_0 F4_2). unfold magma_op, refa342_inst, refa342_op in H. discriminate H. Qed.

Lemma refa342_not4090 : ~ @Equation4090 Fin4 refa342_inst.
Proof. unfold Equation4090. intro H. specialize (H F4_0 F4_3). unfold magma_op, refa342_inst, refa342_op in H. discriminate H. Qed.

Lemma refa342_not4093 : ~ @Equation4093 Fin4 refa342_inst.
Proof. unfold Equation4093. intro H. specialize (H F4_0 F4_2). unfold magma_op, refa342_inst, refa342_op in H. discriminate H. Qed.

Lemma refa342_not4121 : ~ @Equation4121 Fin4 refa342_inst.
Proof. unfold Equation4121. intro H. specialize (H F4_0 F4_2). unfold magma_op, refa342_inst, refa342_op in H. discriminate H. Qed.

Lemma refa342_not4128 : ~ @Equation4128 Fin4 refa342_inst.
Proof. unfold Equation4128. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa342_inst, refa342_op in H. discriminate H. Qed.

Lemma refa342_not4155 : ~ @Equation4155 Fin4 refa342_inst.
Proof. unfold Equation4155. intro H. specialize (H F4_0 F4_2). unfold magma_op, refa342_inst, refa342_op in H. discriminate H. Qed.

Lemma refa342_not4165 : ~ @Equation4165 Fin4 refa342_inst.
Proof. unfold Equation4165. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa342_inst, refa342_op in H. discriminate H. Qed.

Lemma refa342_not4269 : ~ @Equation4269 Fin4 refa342_inst.
Proof. unfold Equation4269. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa342_inst, refa342_op in H. discriminate H. Qed.

Lemma refa342_not4272 : ~ @Equation4272 Fin4 refa342_inst.
Proof. unfold Equation4272. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa342_inst, refa342_op in H. discriminate H. Qed.

Lemma refa342_not4284 : ~ @Equation4284 Fin4 refa342_inst.
Proof. unfold Equation4284. intro H. specialize (H F4_0 F4_2). unfold magma_op, refa342_inst, refa342_op in H. discriminate H. Qed.

Lemma refa342_not4291 : ~ @Equation4291 Fin4 refa342_inst.
Proof. unfold Equation4291. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa342_inst, refa342_op in H. discriminate H. Qed.

Lemma refa342_not4396 : ~ @Equation4396 Fin4 refa342_inst.
Proof. unfold Equation4396. intro H. specialize (H F4_0 F4_0). unfold magma_op, refa342_inst, refa342_op in H. discriminate H. Qed.

Lemma refa342_not4399 : ~ @Equation4399 Fin4 refa342_inst.
Proof. unfold Equation4399. intro H. specialize (H F4_0 F4_0). unfold magma_op, refa342_inst, refa342_op in H. discriminate H. Qed.

Lemma refa342_not4406 : ~ @Equation4406 Fin4 refa342_inst.
Proof. unfold Equation4406. intro H. specialize (H F4_0 F4_0). unfold magma_op, refa342_inst, refa342_op in H. discriminate H. Qed.

Lemma refa342_not4445 : ~ @Equation4445 Fin4 refa342_inst.
Proof. unfold Equation4445. intro H. specialize (H F4_0 F4_0). unfold magma_op, refa342_inst, refa342_op in H. discriminate H. Qed.

Lemma refa342_not4473 : ~ @Equation4473 Fin4 refa342_inst.
Proof. unfold Equation4473. intro H. specialize (H F4_0 F4_0). unfold magma_op, refa342_inst, refa342_op in H. discriminate H. Qed.

Lemma refa342_not4480 : ~ @Equation4480 Fin4 refa342_inst.
Proof. unfold Equation4480. intro H. specialize (H F4_0 F4_0). unfold magma_op, refa342_inst, refa342_op in H. discriminate H. Qed.

Lemma refa342_not4584 : ~ @Equation4584 Fin4 refa342_inst.
Proof. unfold Equation4584. intro H. specialize (H F4_0 F4_2). unfold magma_op, refa342_inst, refa342_op in H. discriminate H. Qed.

Lemma refa342_not4587 : ~ @Equation4587 Fin4 refa342_inst.
Proof. unfold Equation4587. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa342_inst, refa342_op in H. discriminate H. Qed.

Lemma refa342_not4590 : ~ @Equation4590 Fin4 refa342_inst.
Proof. unfold Equation4590. intro H. specialize (H F4_0 F4_2). unfold magma_op, refa342_inst, refa342_op in H. discriminate H. Qed.

Lemma refa342_not4599 : ~ @Equation4599 Fin4 refa342_inst.
Proof. unfold Equation4599. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa342_inst, refa342_op in H. discriminate H. Qed.

Lemma refa342_not4606 : ~ @Equation4606 Fin4 refa342_inst.
Proof. unfold Equation4606. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa342_inst, refa342_op in H. discriminate H. Qed.

(** ---- refa343 (Fin4) ---- *)

Definition refa343_op (x y : Fin4) : Fin4 :=
  match x, y with
  | F4_0, F4_0 => F4_1 | F4_0, F4_1 => F4_3 | F4_0, F4_2 => F4_0 | F4_0, F4_3 => F4_1
  | F4_1, F4_0 => F4_3 | F4_1, F4_1 => F4_2 | F4_1, F4_2 => F4_1 | F4_1, F4_3 => F4_0
  | F4_2, F4_0 => F4_0 | F4_2, F4_1 => F4_1 | F4_2, F4_2 => F4_2 | F4_2, F4_3 => F4_3
  | F4_3, F4_0 => F4_2 | F4_3, F4_1 => F4_0 | F4_3, F4_2 => F4_3 | F4_3, F4_3 => F4_2
  end.

#[local] Instance refa343_inst : Magma Fin4 := {| magma_op := refa343_op |}.

Lemma refa343_sat2737 : @Equation2737 Fin4 refa343_inst.
Proof. unfold Equation2737, magma_op, refa343_inst, refa343_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa343_sat3152 : @Equation3152 Fin4 refa343_inst.
Proof. unfold Equation3152, magma_op, refa343_inst, refa343_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa343_not1898 : ~ @Equation1898 Fin4 refa343_inst.
Proof. unfold Equation1898. intro H. specialize (H F4_1 F4_0). unfold magma_op, refa343_inst, refa343_op in H. discriminate H. Qed.

Lemma refa343_not1934 : ~ @Equation1934 Fin4 refa343_inst.
Proof. unfold Equation1934. intro H. specialize (H F4_0 F4_3). unfold magma_op, refa343_inst, refa343_op in H. discriminate H. Qed.

Lemma refa343_not2441 : ~ @Equation2441 Fin4 refa343_inst.
Proof. unfold Equation2441. intro H. specialize (H F4_0). unfold magma_op, refa343_inst, refa343_op in H. discriminate H. Qed.

Lemma refa343_not2710 : ~ @Equation2710 Fin4 refa343_inst.
Proof. unfold Equation2710. intro H. specialize (H F4_0 F4_3). unfold magma_op, refa343_inst, refa343_op in H. discriminate H. Qed.

Lemma refa343_not4684 : ~ @Equation4684 Fin4 refa343_inst.
Proof. unfold Equation4684. intro H. specialize (H F4_0 F4_1 F4_3). unfold magma_op, refa343_inst, refa343_op in H. discriminate H. Qed.

(** ---- refa344 (Fin4) ---- *)

Definition refa344_op (x y : Fin4) : Fin4 :=
  match x, y with
  | F4_0, F4_0 => F4_1 | F4_0, F4_1 => F4_1 | F4_0, F4_2 => F4_3 | F4_0, F4_3 => F4_3
  | F4_1, F4_0 => F4_3 | F4_1, F4_1 => F4_2 | F4_1, F4_2 => F4_2 | F4_1, F4_3 => F4_2
  | F4_2, F4_0 => F4_0 | F4_2, F4_1 => F4_3 | F4_2, F4_2 => F4_0 | F4_2, F4_3 => F4_0
  | F4_3, F4_0 => F4_0 | F4_3, F4_1 => F4_1 | F4_3, F4_2 => F4_2 | F4_3, F4_3 => F4_3
  end.

#[local] Instance refa344_inst : Magma Fin4 := {| magma_op := refa344_op |}.

Lemma refa344_sat2902 : @Equation2902 Fin4 refa344_inst.
Proof. unfold Equation2902, magma_op, refa344_inst, refa344_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa344_sat2912 : @Equation2912 Fin4 refa344_inst.
Proof. unfold Equation2912, magma_op, refa344_inst, refa344_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa344_not40 : ~ @Equation40 Fin4 refa344_inst.
Proof. unfold Equation40. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa344_inst, refa344_op in H. discriminate H. Qed.

Lemma refa344_not47 : ~ @Equation47 Fin4 refa344_inst.
Proof. unfold Equation47. intro H. specialize (H F4_0). unfold magma_op, refa344_inst, refa344_op in H. discriminate H. Qed.

Lemma refa344_not99 : ~ @Equation99 Fin4 refa344_inst.
Proof. unfold Equation99. intro H. specialize (H F4_0). unfold magma_op, refa344_inst, refa344_op in H. discriminate H. Qed.

Lemma refa344_not151 : ~ @Equation151 Fin4 refa344_inst.
Proof. unfold Equation151. intro H. specialize (H F4_0). unfold magma_op, refa344_inst, refa344_op in H. discriminate H. Qed.

Lemma refa344_not203 : ~ @Equation203 Fin4 refa344_inst.
Proof. unfold Equation203. intro H. specialize (H F4_0). unfold magma_op, refa344_inst, refa344_op in H. discriminate H. Qed.

Lemma refa344_not1629 : ~ @Equation1629 Fin4 refa344_inst.
Proof. unfold Equation1629. intro H. specialize (H F4_0). unfold magma_op, refa344_inst, refa344_op in H. discriminate H. Qed.

Lemma refa344_not2238 : ~ @Equation2238 Fin4 refa344_inst.
Proof. unfold Equation2238. intro H. specialize (H F4_0). unfold magma_op, refa344_inst, refa344_op in H. discriminate H. Qed.

Lemma refa344_not2441 : ~ @Equation2441 Fin4 refa344_inst.
Proof. unfold Equation2441. intro H. specialize (H F4_1). unfold magma_op, refa344_inst, refa344_op in H. discriminate H. Qed.

Lemma refa344_not2909 : ~ @Equation2909 Fin4 refa344_inst.
Proof. unfold Equation2909. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa344_inst, refa344_op in H. discriminate H. Qed.

Lemma refa344_not3050 : ~ @Equation3050 Fin4 refa344_inst.
Proof. unfold Equation3050. intro H. specialize (H F4_0). unfold magma_op, refa344_inst, refa344_op in H. discriminate H. Qed.

Lemma refa344_not3456 : ~ @Equation3456 Fin4 refa344_inst.
Proof. unfold Equation3456. intro H. specialize (H F4_0). unfold magma_op, refa344_inst, refa344_op in H. discriminate H. Qed.

Lemma refa344_not3862 : ~ @Equation3862 Fin4 refa344_inst.
Proof. unfold Equation3862. intro H. specialize (H F4_0). unfold magma_op, refa344_inst, refa344_op in H. discriminate H. Qed.

Lemma refa344_not4065 : ~ @Equation4065 Fin4 refa344_inst.
Proof. unfold Equation4065. intro H. specialize (H F4_0). unfold magma_op, refa344_inst, refa344_op in H. discriminate H. Qed.

(** ---- refa345 (Fin4) ---- *)

Definition refa345_op (x y : Fin4) : Fin4 :=
  match x, y with
  | F4_0, F4_0 => F4_2 | F4_0, F4_1 => F4_2 | F4_0, F4_2 => F4_2 | F4_0, F4_3 => F4_3
  | F4_1, F4_0 => F4_2 | F4_1, F4_1 => F4_3 | F4_1, F4_2 => F4_2 | F4_1, F4_3 => F4_3
  | F4_2, F4_0 => F4_0 | F4_2, F4_1 => F4_1 | F4_2, F4_2 => F4_2 | F4_2, F4_3 => F4_3
  | F4_3, F4_0 => F4_0 | F4_3, F4_1 => F4_1 | F4_3, F4_2 => F4_2 | F4_3, F4_3 => F4_3
  end.

#[local] Instance refa345_inst : Magma Fin4 := {| magma_op := refa345_op |}.

Lemma refa345_sat2420 : @Equation2420 Fin4 refa345_inst.
Proof. unfold Equation2420, magma_op, refa345_inst, refa345_op. intros x y z w. destruct x, y, z, w; reflexivity. Qed.

Lemma refa345_sat2536 : @Equation2536 Fin4 refa345_inst.
Proof. unfold Equation2536, magma_op, refa345_inst, refa345_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa345_not3261 : ~ @Equation3261 Fin4 refa345_inst.
Proof. unfold Equation3261. intro H. specialize (H F4_1 F4_0). unfold magma_op, refa345_inst, refa345_op in H. discriminate H. Qed.

Lemma refa345_not3481 : ~ @Equation3481 Fin4 refa345_inst.
Proof. unfold Equation3481. intro H. specialize (H F4_1 F4_0). unfold magma_op, refa345_inst, refa345_op in H. discriminate H. Qed.

Lemma refa345_not3677 : ~ @Equation3677 Fin4 refa345_inst.
Proof. unfold Equation3677. intro H. specialize (H F4_1 F4_0). unfold magma_op, refa345_inst, refa345_op in H. discriminate H. Qed.

Lemma refa345_not4131 : ~ @Equation4131 Fin4 refa345_inst.
Proof. unfold Equation4131. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa345_inst, refa345_op in H. discriminate H. Qed.

Lemma refa345_not4269 : ~ @Equation4269 Fin4 refa345_inst.
Proof. unfold Equation4269. intro H. specialize (H F4_1 F4_0). unfold magma_op, refa345_inst, refa345_op in H. discriminate H. Qed.

Lemma refa345_not4320 : ~ @Equation4320 Fin4 refa345_inst.
Proof. unfold Equation4320. intro H. specialize (H F4_1 F4_0). unfold magma_op, refa345_inst, refa345_op in H. discriminate H. Qed.

(** ---- refa346 (Fin4) ---- *)

Definition refa346_op (x y : Fin4) : Fin4 :=
  match x, y with
  | F4_0, F4_0 => F4_1 | F4_0, F4_1 => F4_1 | F4_0, F4_2 => F4_2 | F4_0, F4_3 => F4_1
  | F4_1, F4_0 => F4_3 | F4_1, F4_1 => F4_3 | F4_1, F4_2 => F4_2 | F4_1, F4_3 => F4_3
  | F4_2, F4_0 => F4_3 | F4_2, F4_1 => F4_0 | F4_2, F4_2 => F4_2 | F4_2, F4_3 => F4_1
  | F4_3, F4_0 => F4_0 | F4_3, F4_1 => F4_0 | F4_3, F4_2 => F4_2 | F4_3, F4_3 => F4_0
  end.

#[local] Instance refa346_inst : Magma Fin4 := {| magma_op := refa346_op |}.

Lemma refa346_sat2056 : @Equation2056 Fin4 refa346_inst.
Proof. unfold Equation2056, magma_op, refa346_inst, refa346_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa346_sat3309 : @Equation3309 Fin4 refa346_inst.
Proof. unfold Equation3309, magma_op, refa346_inst, refa346_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa346_not3306 : ~ @Equation3306 Fin4 refa346_inst.
Proof. unfold Equation3306. intro H. specialize (H F4_2 F4_0). unfold magma_op, refa346_inst, refa346_op in H. discriminate H. Qed.

Lemma refa346_not3308 : ~ @Equation3308 Fin4 refa346_inst.
Proof. unfold Equation3308. intro H. specialize (H F4_0 F4_2). unfold magma_op, refa346_inst, refa346_op in H. discriminate H. Qed.

Lemma refa346_not3316 : ~ @Equation3316 Fin4 refa346_inst.
Proof. unfold Equation3316. intro H. specialize (H F4_2 F4_0). unfold magma_op, refa346_inst, refa346_op in H. discriminate H. Qed.

Lemma refa346_not3319 : ~ @Equation3319 Fin4 refa346_inst.
Proof. unfold Equation3319. intro H. specialize (H F4_2 F4_0). unfold magma_op, refa346_inst, refa346_op in H. discriminate H. Qed.

Lemma refa346_not3862 : ~ @Equation3862 Fin4 refa346_inst.
Proof. unfold Equation3862. intro H. specialize (H F4_0). unfold magma_op, refa346_inst, refa346_op in H. discriminate H. Qed.

Lemma refa346_not4065 : ~ @Equation4065 Fin4 refa346_inst.
Proof. unfold Equation4065. intro H. specialize (H F4_0). unfold magma_op, refa346_inst, refa346_op in H. discriminate H. Qed.

Lemma refa346_not4284 : ~ @Equation4284 Fin4 refa346_inst.
Proof. unfold Equation4284. intro H. specialize (H F4_2 F4_0). unfold magma_op, refa346_inst, refa346_op in H. discriminate H. Qed.

Lemma refa346_not4599 : ~ @Equation4599 Fin4 refa346_inst.
Proof. unfold Equation4599. intro H. specialize (H F4_2 F4_0). unfold magma_op, refa346_inst, refa346_op in H. discriminate H. Qed.

(** ---- refa347 (Fin4) ---- *)

Definition refa347_op (x y : Fin4) : Fin4 :=
  match x, y with
  | F4_0, F4_0 => F4_3 | F4_0, F4_1 => F4_1 | F4_0, F4_2 => F4_1 | F4_0, F4_3 => F4_3
  | F4_1, F4_0 => F4_3 | F4_1, F4_1 => F4_3 | F4_1, F4_2 => F4_2 | F4_1, F4_3 => F4_3
  | F4_2, F4_0 => F4_2 | F4_2, F4_1 => F4_1 | F4_2, F4_2 => F4_3 | F4_2, F4_3 => F4_3
  | F4_3, F4_0 => F4_0 | F4_3, F4_1 => F4_1 | F4_3, F4_2 => F4_2 | F4_3, F4_3 => F4_3
  end.

#[local] Instance refa347_inst : Magma Fin4 := {| magma_op := refa347_op |}.

Lemma refa347_sat2554 : @Equation2554 Fin4 refa347_inst.
Proof. unfold Equation2554, magma_op, refa347_inst, refa347_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa347_not2330 : ~ @Equation2330 Fin4 refa347_inst.
Proof. unfold Equation2330. intro H. specialize (H F4_0 F4_2). unfold magma_op, refa347_inst, refa347_op in H. discriminate H. Qed.

(** ---- refa348 (Fin4) ---- *)

Definition refa348_op (x y : Fin4) : Fin4 :=
  match x, y with
  | F4_0, F4_0 => F4_3 | F4_0, F4_1 => F4_0 | F4_0, F4_2 => F4_0 | F4_0, F4_3 => F4_1
  | F4_1, F4_0 => F4_3 | F4_1, F4_1 => F4_0 | F4_1, F4_2 => F4_1 | F4_1, F4_3 => F4_1
  | F4_2, F4_0 => F4_2 | F4_2, F4_1 => F4_2 | F4_2, F4_2 => F4_2 | F4_2, F4_3 => F4_2
  | F4_3, F4_0 => F4_3 | F4_3, F4_1 => F4_0 | F4_3, F4_2 => F4_3 | F4_3, F4_3 => F4_1
  end.

#[local] Instance refa348_inst : Magma Fin4 := {| magma_op := refa348_op |}.

Lemma refa348_sat635 : @Equation635 Fin4 refa348_inst.
Proof. unfold Equation635, magma_op, refa348_inst, refa348_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa348_sat645 : @Equation645 Fin4 refa348_inst.
Proof. unfold Equation645, magma_op, refa348_inst, refa348_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa348_sat856 : @Equation856 Fin4 refa348_inst.
Proof. unfold Equation856, magma_op, refa348_inst, refa348_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa348_not619 : ~ @Equation619 Fin4 refa348_inst.
Proof. unfold Equation619. intro H. specialize (H F4_0 F4_2). unfold magma_op, refa348_inst, refa348_op in H. discriminate H. Qed.

Lemma refa348_not622 : ~ @Equation622 Fin4 refa348_inst.
Proof. unfold Equation622. intro H. specialize (H F4_0 F4_2). unfold magma_op, refa348_inst, refa348_op in H. discriminate H. Qed.

Lemma refa348_not819 : ~ @Equation819 Fin4 refa348_inst.
Proof. unfold Equation819. intro H. specialize (H F4_0 F4_2). unfold magma_op, refa348_inst, refa348_op in H. discriminate H. Qed.

Lemma refa348_not825 : ~ @Equation825 Fin4 refa348_inst.
Proof. unfold Equation825. intro H. specialize (H F4_0 F4_2). unfold magma_op, refa348_inst, refa348_op in H. discriminate H. Qed.

Lemma refa348_not1428 : ~ @Equation1428 Fin4 refa348_inst.
Proof. unfold Equation1428. intro H. specialize (H F4_0 F4_2). unfold magma_op, refa348_inst, refa348_op in H. discriminate H. Qed.

Lemma refa348_not1431 : ~ @Equation1431 Fin4 refa348_inst.
Proof. unfold Equation1431. intro H. specialize (H F4_0 F4_2). unfold magma_op, refa348_inst, refa348_op in H. discriminate H. Qed.

Lemma refa348_not1434 : ~ @Equation1434 Fin4 refa348_inst.
Proof. unfold Equation1434. intro H. specialize (H F4_0 F4_2). unfold magma_op, refa348_inst, refa348_op in H. discriminate H. Qed.

Lemma refa348_not1444 : ~ @Equation1444 Fin4 refa348_inst.
Proof. unfold Equation1444. intro H. specialize (H F4_0 F4_2). unfold magma_op, refa348_inst, refa348_op in H. discriminate H. Qed.

Lemma refa348_not3915 : ~ @Equation3915 Fin4 refa348_inst.
Proof. unfold Equation3915. intro H. specialize (H F4_0 F4_2). unfold magma_op, refa348_inst, refa348_op in H. discriminate H. Qed.

Lemma refa348_not3918 : ~ @Equation3918 Fin4 refa348_inst.
Proof. unfold Equation3918. intro H. specialize (H F4_0 F4_2). unfold magma_op, refa348_inst, refa348_op in H. discriminate H. Qed.

Lemma refa348_not4118 : ~ @Equation4118 Fin4 refa348_inst.
Proof. unfold Equation4118. intro H. specialize (H F4_0 F4_2). unfold magma_op, refa348_inst, refa348_op in H. discriminate H. Qed.

Lemma refa348_not4121 : ~ @Equation4121 Fin4 refa348_inst.
Proof. unfold Equation4121. intro H. specialize (H F4_0 F4_2). unfold magma_op, refa348_inst, refa348_op in H. discriminate H. Qed.

Lemma refa348_not4128 : ~ @Equation4128 Fin4 refa348_inst.
Proof. unfold Equation4128. intro H. specialize (H F4_0 F4_2). unfold magma_op, refa348_inst, refa348_op in H. discriminate H. Qed.

Lemma refa348_not4269 : ~ @Equation4269 Fin4 refa348_inst.
Proof. unfold Equation4269. intro H. specialize (H F4_0 F4_2). unfold magma_op, refa348_inst, refa348_op in H. discriminate H. Qed.

Lemma refa348_not4284 : ~ @Equation4284 Fin4 refa348_inst.
Proof. unfold Equation4284. intro H. specialize (H F4_0 F4_2). unfold magma_op, refa348_inst, refa348_op in H. discriminate H. Qed.

Lemma refa348_not4599 : ~ @Equation4599 Fin4 refa348_inst.
Proof. unfold Equation4599. intro H. specialize (H F4_0 F4_2). unfold magma_op, refa348_inst, refa348_op in H. discriminate H. Qed.

(** ---- refa349 (Fin4) ---- *)

Definition refa349_op (x y : Fin4) : Fin4 :=
  match x, y with
  | F4_0, F4_0 => F4_1 | F4_0, F4_1 => F4_0 | F4_0, F4_2 => F4_0 | F4_0, F4_3 => F4_3
  | F4_1, F4_0 => F4_1 | F4_1, F4_1 => F4_1 | F4_1, F4_2 => F4_1 | F4_1, F4_3 => F4_1
  | F4_2, F4_0 => F4_2 | F4_2, F4_1 => F4_2 | F4_2, F4_2 => F4_2 | F4_2, F4_3 => F4_2
  | F4_3, F4_0 => F4_2 | F4_3, F4_1 => F4_3 | F4_3, F4_2 => F4_3 | F4_3, F4_3 => F4_3
  end.

#[local] Instance refa349_inst : Magma Fin4 := {| magma_op := refa349_op |}.

Lemma refa349_sat841 : @Equation841 Fin4 refa349_inst.
Proof. unfold Equation841, magma_op, refa349_inst, refa349_op. intros x y z w. destruct x, y, z, w; reflexivity. Qed.

Lemma refa349_not3864 : ~ @Equation3864 Fin4 refa349_inst.
Proof. unfold Equation3864. intro H. specialize (H F4_0 F4_3). unfold magma_op, refa349_inst, refa349_op in H. discriminate H. Qed.

Lemma refa349_not4598 : ~ @Equation4598 Fin4 refa349_inst.
Proof. unfold Equation4598. intro H. specialize (H F4_0 F4_3). unfold magma_op, refa349_inst, refa349_op in H. discriminate H. Qed.

(** ---- refa35 (Fin6) ---- *)

Definition refa35_op (x y : Fin6) : Fin6 :=
  match x, y with
  | F6_0, F6_0 => F6_1 | F6_0, F6_1 => F6_2 | F6_0, F6_2 => F6_3 | F6_0, F6_3 => F6_4 | F6_0, F6_4 => F6_5 | F6_0, F6_5 => F6_0
  | F6_1, F6_0 => F6_0 | F6_1, F6_1 => F6_5 | F6_1, F6_2 => F6_4 | F6_1, F6_3 => F6_3 | F6_1, F6_4 => F6_2 | F6_1, F6_5 => F6_1
  | F6_2, F6_0 => F6_5 | F6_2, F6_1 => F6_4 | F6_2, F6_2 => F6_1 | F6_2, F6_3 => F6_0 | F6_2, F6_4 => F6_3 | F6_2, F6_5 => F6_2
  | F6_3, F6_0 => F6_4 | F6_3, F6_1 => F6_1 | F6_3, F6_2 => F6_2 | F6_3, F6_3 => F6_5 | F6_3, F6_4 => F6_0 | F6_3, F6_5 => F6_3
  | F6_4, F6_0 => F6_3 | F6_4, F6_1 => F6_0 | F6_4, F6_2 => F6_5 | F6_4, F6_3 => F6_2 | F6_4, F6_4 => F6_1 | F6_4, F6_5 => F6_4
  | F6_5, F6_0 => F6_2 | F6_5, F6_1 => F6_3 | F6_5, F6_2 => F6_0 | F6_5, F6_3 => F6_1 | F6_5, F6_4 => F6_4 | F6_5, F6_5 => F6_5
  end.

#[local] Instance refa35_inst : Magma Fin6 := {| magma_op := refa35_op |}.

Lemma refa35_sat917 : @Equation917 Fin6 refa35_inst.
Proof. unfold Equation917, magma_op, refa35_inst, refa35_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa35_sat1729 : @Equation1729 Fin6 refa35_inst.
Proof. unfold Equation1729, magma_op, refa35_inst, refa35_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa35_not411 : ~ @Equation411 Fin6 refa35_inst.
Proof. unfold Equation411. intro H. specialize (H F6_0). unfold magma_op, refa35_inst, refa35_op in H. discriminate H. Qed.

Lemma refa35_not1832 : ~ @Equation1832 Fin6 refa35_inst.
Proof. unfold Equation1832. intro H. specialize (H F6_0). unfold magma_op, refa35_inst, refa35_op in H. discriminate H. Qed.

(** ---- refa350 (Fin4) ---- *)

Definition refa350_op (x y : Fin4) : Fin4 :=
  match x, y with
  | F4_0, F4_0 => F4_3 | F4_0, F4_1 => F4_3 | F4_0, F4_2 => F4_1 | F4_0, F4_3 => F4_1
  | F4_1, F4_0 => F4_3 | F4_1, F4_1 => F4_3 | F4_1, F4_2 => F4_1 | F4_1, F4_3 => F4_2
  | F4_2, F4_0 => F4_3 | F4_2, F4_1 => F4_3 | F4_2, F4_2 => F4_1 | F4_2, F4_3 => F4_2
  | F4_3, F4_0 => F4_3 | F4_3, F4_1 => F4_0 | F4_3, F4_2 => F4_1 | F4_3, F4_3 => F4_1
  end.

#[local] Instance refa350_inst : Magma Fin4 := {| magma_op := refa350_op |}.

Lemma refa350_sat1484 : @Equation1484 Fin4 refa350_inst.
Proof. unfold Equation1484, magma_op, refa350_inst, refa350_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa350_not3864 : ~ @Equation3864 Fin4 refa350_inst.
Proof. unfold Equation3864. intro H. specialize (H F4_1 F4_2). unfold magma_op, refa350_inst, refa350_op in H. discriminate H. Qed.

Lemma refa350_not3880 : ~ @Equation3880 Fin4 refa350_inst.
Proof. unfold Equation3880. intro H. specialize (H F4_1 F4_2). unfold magma_op, refa350_inst, refa350_op in H. discriminate H. Qed.

Lemma refa350_not4587 : ~ @Equation4587 Fin4 refa350_inst.
Proof. unfold Equation4587. intro H. specialize (H F4_1 F4_3). unfold magma_op, refa350_inst, refa350_op in H. discriminate H. Qed.

(** ---- refa351 (Fin4) ---- *)

Definition refa351_op (x y : Fin4) : Fin4 :=
  match x, y with
  | F4_0, F4_0 => F4_2 | F4_0, F4_1 => F4_0 | F4_0, F4_2 => F4_1 | F4_0, F4_3 => F4_3
  | F4_1, F4_0 => F4_3 | F4_1, F4_1 => F4_1 | F4_1, F4_2 => F4_0 | F4_1, F4_3 => F4_2
  | F4_2, F4_0 => F4_0 | F4_2, F4_1 => F4_2 | F4_2, F4_2 => F4_3 | F4_2, F4_3 => F4_1
  | F4_3, F4_0 => F4_1 | F4_3, F4_1 => F4_3 | F4_3, F4_2 => F4_2 | F4_3, F4_3 => F4_0
  end.

#[local] Instance refa351_inst : Magma Fin4 := {| magma_op := refa351_op |}.

Lemma refa351_sat63 : @Equation63 Fin4 refa351_inst.
Proof. unfold Equation63, magma_op, refa351_inst, refa351_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa351_sat1692 : @Equation1692 Fin4 refa351_inst.
Proof. unfold Equation1692, magma_op, refa351_inst, refa351_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa351_sat1694 : @Equation1694 Fin4 refa351_inst.
Proof. unfold Equation1694, magma_op, refa351_inst, refa351_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa351_sat1719 : @Equation1719 Fin4 refa351_inst.
Proof. unfold Equation1719, magma_op, refa351_inst, refa351_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa351_sat1721 : @Equation1721 Fin4 refa351_inst.
Proof. unfold Equation1721, magma_op, refa351_inst, refa351_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa351_sat1888 : @Equation1888 Fin4 refa351_inst.
Proof. unfold Equation1888, magma_op, refa351_inst, refa351_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa351_sat1931 : @Equation1931 Fin4 refa351_inst.
Proof. unfold Equation1931, magma_op, refa351_inst, refa351_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa351_sat2497 : @Equation2497 Fin4 refa351_inst.
Proof. unfold Equation2497, magma_op, refa351_inst, refa351_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa351_sat2504 : @Equation2504 Fin4 refa351_inst.
Proof. unfold Equation2504, magma_op, refa351_inst, refa351_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa351_sat2533 : @Equation2533 Fin4 refa351_inst.
Proof. unfold Equation2533, magma_op, refa351_inst, refa351_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa351_sat2540 : @Equation2540 Fin4 refa351_inst.
Proof. unfold Equation2540, magma_op, refa351_inst, refa351_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa351_sat3482 : @Equation3482 Fin4 refa351_inst.
Proof. unfold Equation3482, magma_op, refa351_inst, refa351_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa351_sat3484 : @Equation3484 Fin4 refa351_inst.
Proof. unfold Equation3484, magma_op, refa351_inst, refa351_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa351_sat3546 : @Equation3546 Fin4 refa351_inst.
Proof. unfold Equation3546, magma_op, refa351_inst, refa351_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa351_sat3548 : @Equation3548 Fin4 refa351_inst.
Proof. unfold Equation3548, magma_op, refa351_inst, refa351_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa351_not65 : ~ @Equation65 Fin4 refa351_inst.
Proof. unfold Equation65. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa351_inst, refa351_op in H. discriminate H. Qed.

Lemma refa351_not73 : ~ @Equation73 Fin4 refa351_inst.
Proof. unfold Equation73. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa351_inst, refa351_op in H. discriminate H. Qed.

Lemma refa351_not99 : ~ @Equation99 Fin4 refa351_inst.
Proof. unfold Equation99. intro H. specialize (H F4_0). unfold magma_op, refa351_inst, refa351_op in H. discriminate H. Qed.

Lemma refa351_not151 : ~ @Equation151 Fin4 refa351_inst.
Proof. unfold Equation151. intro H. specialize (H F4_0). unfold magma_op, refa351_inst, refa351_op in H. discriminate H. Qed.

Lemma refa351_not203 : ~ @Equation203 Fin4 refa351_inst.
Proof. unfold Equation203. intro H. specialize (H F4_0). unfold magma_op, refa351_inst, refa351_op in H. discriminate H. Qed.

Lemma refa351_not255 : ~ @Equation255 Fin4 refa351_inst.
Proof. unfold Equation255. intro H. specialize (H F4_0). unfold magma_op, refa351_inst, refa351_op in H. discriminate H. Qed.

Lemma refa351_not359 : ~ @Equation359 Fin4 refa351_inst.
Proof. unfold Equation359. intro H. specialize (H F4_0). unfold magma_op, refa351_inst, refa351_op in H. discriminate H. Qed.

Lemma refa351_not411 : ~ @Equation411 Fin4 refa351_inst.
Proof. unfold Equation411. intro H. specialize (H F4_0). unfold magma_op, refa351_inst, refa351_op in H. discriminate H. Qed.

Lemma refa351_not614 : ~ @Equation614 Fin4 refa351_inst.
Proof. unfold Equation614. intro H. specialize (H F4_0). unfold magma_op, refa351_inst, refa351_op in H. discriminate H. Qed.

Lemma refa351_not817 : ~ @Equation817 Fin4 refa351_inst.
Proof. unfold Equation817. intro H. specialize (H F4_0). unfold magma_op, refa351_inst, refa351_op in H. discriminate H. Qed.

Lemma refa351_not1020 : ~ @Equation1020 Fin4 refa351_inst.
Proof. unfold Equation1020. intro H. specialize (H F4_0). unfold magma_op, refa351_inst, refa351_op in H. discriminate H. Qed.

Lemma refa351_not1223 : ~ @Equation1223 Fin4 refa351_inst.
Proof. unfold Equation1223. intro H. specialize (H F4_0). unfold magma_op, refa351_inst, refa351_op in H. discriminate H. Qed.

Lemma refa351_not1426 : ~ @Equation1426 Fin4 refa351_inst.
Proof. unfold Equation1426. intro H. specialize (H F4_0). unfold magma_op, refa351_inst, refa351_op in H. discriminate H. Qed.

Lemma refa351_not1635 : ~ @Equation1635 Fin4 refa351_inst.
Proof. unfold Equation1635. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa351_inst, refa351_op in H. discriminate H. Qed.

Lemma refa351_not1637 : ~ @Equation1637 Fin4 refa351_inst.
Proof. unfold Equation1637. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa351_inst, refa351_op in H. discriminate H. Qed.

Lemma refa351_not1645 : ~ @Equation1645 Fin4 refa351_inst.
Proof. unfold Equation1645. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa351_inst, refa351_op in H. discriminate H. Qed.

Lemma refa351_not1657 : ~ @Equation1657 Fin4 refa351_inst.
Proof. unfold Equation1657. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa351_inst, refa351_op in H. discriminate H. Qed.

Lemma refa351_not1684 : ~ @Equation1684 Fin4 refa351_inst.
Proof. unfold Equation1684. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa351_inst, refa351_op in H. discriminate H. Qed.

Lemma refa351_not1691 : ~ @Equation1691 Fin4 refa351_inst.
Proof. unfold Equation1691. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa351_inst, refa351_op in H. discriminate H. Qed.

Lemma refa351_not1722 : ~ @Equation1722 Fin4 refa351_inst.
Proof. unfold Equation1722. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa351_inst, refa351_op in H. discriminate H. Qed.

Lemma refa351_not1731 : ~ @Equation1731 Fin4 refa351_inst.
Proof. unfold Equation1731. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa351_inst, refa351_op in H. discriminate H. Qed.

Lemma refa351_not1840 : ~ @Equation1840 Fin4 refa351_inst.
Proof. unfold Equation1840. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa351_inst, refa351_op in H. discriminate H. Qed.

Lemma refa351_not1848 : ~ @Equation1848 Fin4 refa351_inst.
Proof. unfold Equation1848. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa351_inst, refa351_op in H. discriminate H. Qed.

Lemma refa351_not1857 : ~ @Equation1857 Fin4 refa351_inst.
Proof. unfold Equation1857. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa351_inst, refa351_op in H. discriminate H. Qed.

Lemma refa351_not1894 : ~ @Equation1894 Fin4 refa351_inst.
Proof. unfold Equation1894. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa351_inst, refa351_op in H. discriminate H. Qed.

Lemma refa351_not1921 : ~ @Equation1921 Fin4 refa351_inst.
Proof. unfold Equation1921. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa351_inst, refa351_op in H. discriminate H. Qed.

Lemma refa351_not2035 : ~ @Equation2035 Fin4 refa351_inst.
Proof. unfold Equation2035. intro H. specialize (H F4_0). unfold magma_op, refa351_inst, refa351_op in H. discriminate H. Qed.

Lemma refa351_not2238 : ~ @Equation2238 Fin4 refa351_inst.
Proof. unfold Equation2238. intro H. specialize (H F4_0). unfold magma_op, refa351_inst, refa351_op in H. discriminate H. Qed.

Lemma refa351_not2444 : ~ @Equation2444 Fin4 refa351_inst.
Proof. unfold Equation2444. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa351_inst, refa351_op in H. discriminate H. Qed.

Lemma refa351_not2447 : ~ @Equation2447 Fin4 refa351_inst.
Proof. unfold Equation2447. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa351_inst, refa351_op in H. discriminate H. Qed.

Lemma refa351_not2459 : ~ @Equation2459 Fin4 refa351_inst.
Proof. unfold Equation2459. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa351_inst, refa351_op in H. discriminate H. Qed.

Lemma refa351_not2466 : ~ @Equation2466 Fin4 refa351_inst.
Proof. unfold Equation2466. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa351_inst, refa351_op in H. discriminate H. Qed.

Lemma refa351_not2496 : ~ @Equation2496 Fin4 refa351_inst.
Proof. unfold Equation2496. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa351_inst, refa351_op in H. discriminate H. Qed.

Lemma refa351_not2506 : ~ @Equation2506 Fin4 refa351_inst.
Proof. unfold Equation2506. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa351_inst, refa351_op in H. discriminate H. Qed.

Lemma refa351_not2530 : ~ @Equation2530 Fin4 refa351_inst.
Proof. unfold Equation2530. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa351_inst, refa351_op in H. discriminate H. Qed.

Lemma refa351_not2534 : ~ @Equation2534 Fin4 refa351_inst.
Proof. unfold Equation2534. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa351_inst, refa351_op in H. discriminate H. Qed.

Lemma refa351_not2543 : ~ @Equation2543 Fin4 refa351_inst.
Proof. unfold Equation2543. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa351_inst, refa351_op in H. discriminate H. Qed.

Lemma refa351_not2644 : ~ @Equation2644 Fin4 refa351_inst.
Proof. unfold Equation2644. intro H. specialize (H F4_0). unfold magma_op, refa351_inst, refa351_op in H. discriminate H. Qed.

Lemma refa351_not2847 : ~ @Equation2847 Fin4 refa351_inst.
Proof. unfold Equation2847. intro H. specialize (H F4_0). unfold magma_op, refa351_inst, refa351_op in H. discriminate H. Qed.

Lemma refa351_not3076 : ~ @Equation3076 Fin4 refa351_inst.
Proof. unfold Equation3076. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa351_inst, refa351_op in H. discriminate H. Qed.

Lemma refa351_not3105 : ~ @Equation3105 Fin4 refa351_inst.
Proof. unfold Equation3105. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa351_inst, refa351_op in H. discriminate H. Qed.

Lemma refa351_not3112 : ~ @Equation3112 Fin4 refa351_inst.
Proof. unfold Equation3112. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa351_inst, refa351_op in H. discriminate H. Qed.

Lemma refa351_not3113 : ~ @Equation3113 Fin4 refa351_inst.
Proof. unfold Equation3113. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa351_inst, refa351_op in H. discriminate H. Qed.

Lemma refa351_not3115 : ~ @Equation3115 Fin4 refa351_inst.
Proof. unfold Equation3115. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa351_inst, refa351_op in H. discriminate H. Qed.

Lemma refa351_not3116 : ~ @Equation3116 Fin4 refa351_inst.
Proof. unfold Equation3116. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa351_inst, refa351_op in H. discriminate H. Qed.

Lemma refa351_not3142 : ~ @Equation3142 Fin4 refa351_inst.
Proof. unfold Equation3142. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa351_inst, refa351_op in H. discriminate H. Qed.

Lemma refa351_not3143 : ~ @Equation3143 Fin4 refa351_inst.
Proof. unfold Equation3143. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa351_inst, refa351_op in H. discriminate H. Qed.

Lemma refa351_not3150 : ~ @Equation3150 Fin4 refa351_inst.
Proof. unfold Equation3150. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa351_inst, refa351_op in H. discriminate H. Qed.

Lemma refa351_not3152 : ~ @Equation3152 Fin4 refa351_inst.
Proof. unfold Equation3152. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa351_inst, refa351_op in H. discriminate H. Qed.

Lemma refa351_not3253 : ~ @Equation3253 Fin4 refa351_inst.
Proof. unfold Equation3253. intro H. specialize (H F4_0). unfold magma_op, refa351_inst, refa351_op in H. discriminate H. Qed.

Lemma refa351_not3458 : ~ @Equation3458 Fin4 refa351_inst.
Proof. unfold Equation3458. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa351_inst, refa351_op in H. discriminate H. Qed.

Lemma refa351_not3461 : ~ @Equation3461 Fin4 refa351_inst.
Proof. unfold Equation3461. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa351_inst, refa351_op in H. discriminate H. Qed.

Lemma refa351_not3462 : ~ @Equation3462 Fin4 refa351_inst.
Proof. unfold Equation3462. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa351_inst, refa351_op in H. discriminate H. Qed.

Lemma refa351_not3464 : ~ @Equation3464 Fin4 refa351_inst.
Proof. unfold Equation3464. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa351_inst, refa351_op in H. discriminate H. Qed.

Lemma refa351_not3472 : ~ @Equation3472 Fin4 refa351_inst.
Proof. unfold Equation3472. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa351_inst, refa351_op in H. discriminate H. Qed.

Lemma refa351_not3475 : ~ @Equation3475 Fin4 refa351_inst.
Proof. unfold Equation3475. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa351_inst, refa351_op in H. discriminate H. Qed.

Lemma refa351_not3481 : ~ @Equation3481 Fin4 refa351_inst.
Proof. unfold Equation3481. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa351_inst, refa351_op in H. discriminate H. Qed.

Lemma refa351_not3509 : ~ @Equation3509 Fin4 refa351_inst.
Proof. unfold Equation3509. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa351_inst, refa351_op in H. discriminate H. Qed.

Lemma refa351_not3511 : ~ @Equation3511 Fin4 refa351_inst.
Proof. unfold Equation3511. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa351_inst, refa351_op in H. discriminate H. Qed.

Lemma refa351_not3545 : ~ @Equation3545 Fin4 refa351_inst.
Proof. unfold Equation3545. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa351_inst, refa351_op in H. discriminate H. Qed.

Lemma refa351_not3549 : ~ @Equation3549 Fin4 refa351_inst.
Proof. unfold Equation3549. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa351_inst, refa351_op in H. discriminate H. Qed.

Lemma refa351_not3555 : ~ @Equation3555 Fin4 refa351_inst.
Proof. unfold Equation3555. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa351_inst, refa351_op in H. discriminate H. Qed.

Lemma refa351_not3556 : ~ @Equation3556 Fin4 refa351_inst.
Proof. unfold Equation3556. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa351_inst, refa351_op in H. discriminate H. Qed.

Lemma refa351_not3659 : ~ @Equation3659 Fin4 refa351_inst.
Proof. unfold Equation3659. intro H. specialize (H F4_0). unfold magma_op, refa351_inst, refa351_op in H. discriminate H. Qed.

Lemma refa351_not3862 : ~ @Equation3862 Fin4 refa351_inst.
Proof. unfold Equation3862. intro H. specialize (H F4_0). unfold magma_op, refa351_inst, refa351_op in H. discriminate H. Qed.

Lemma refa351_not4083 : ~ @Equation4083 Fin4 refa351_inst.
Proof. unfold Equation4083. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa351_inst, refa351_op in H. discriminate H. Qed.

Lemma refa351_not4084 : ~ @Equation4084 Fin4 refa351_inst.
Proof. unfold Equation4084. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa351_inst, refa351_op in H. discriminate H. Qed.

Lemma refa351_not4090 : ~ @Equation4090 Fin4 refa351_inst.
Proof. unfold Equation4090. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa351_inst, refa351_op in H. discriminate H. Qed.

Lemma refa351_not4091 : ~ @Equation4091 Fin4 refa351_inst.
Proof. unfold Equation4091. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa351_inst, refa351_op in H. discriminate H. Qed.

Lemma refa351_not4093 : ~ @Equation4093 Fin4 refa351_inst.
Proof. unfold Equation4093. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa351_inst, refa351_op in H. discriminate H. Qed.

Lemma refa351_not4121 : ~ @Equation4121 Fin4 refa351_inst.
Proof. unfold Equation4121. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa351_inst, refa351_op in H. discriminate H. Qed.

Lemma refa351_not4157 : ~ @Equation4157 Fin4 refa351_inst.
Proof. unfold Equation4157. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa351_inst, refa351_op in H. discriminate H. Qed.

Lemma refa351_not4158 : ~ @Equation4158 Fin4 refa351_inst.
Proof. unfold Equation4158. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa351_inst, refa351_op in H. discriminate H. Qed.

Lemma refa351_not4165 : ~ @Equation4165 Fin4 refa351_inst.
Proof. unfold Equation4165. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa351_inst, refa351_op in H. discriminate H. Qed.

Lemma refa351_not4167 : ~ @Equation4167 Fin4 refa351_inst.
Proof. unfold Equation4167. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa351_inst, refa351_op in H. discriminate H. Qed.

Lemma refa351_not4270 : ~ @Equation4270 Fin4 refa351_inst.
Proof. unfold Equation4270. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa351_inst, refa351_op in H. discriminate H. Qed.

Lemma refa351_not4273 : ~ @Equation4273 Fin4 refa351_inst.
Proof. unfold Equation4273. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa351_inst, refa351_op in H. discriminate H. Qed.

Lemma refa351_not4275 : ~ @Equation4275 Fin4 refa351_inst.
Proof. unfold Equation4275. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa351_inst, refa351_op in H. discriminate H. Qed.

Lemma refa351_not4283 : ~ @Equation4283 Fin4 refa351_inst.
Proof. unfold Equation4283. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa351_inst, refa351_op in H. discriminate H. Qed.

Lemma refa351_not4284 : ~ @Equation4284 Fin4 refa351_inst.
Proof. unfold Equation4284. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa351_inst, refa351_op in H. discriminate H. Qed.

Lemma refa351_not4320 : ~ @Equation4320 Fin4 refa351_inst.
Proof. unfold Equation4320. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa351_inst, refa351_op in H. discriminate H. Qed.

Lemma refa351_not4380 : ~ @Equation4380 Fin4 refa351_inst.
Proof. unfold Equation4380. intro H. specialize (H F4_0). unfold magma_op, refa351_inst, refa351_op in H. discriminate H. Qed.

Lemma refa351_not4588 : ~ @Equation4588 Fin4 refa351_inst.
Proof. unfold Equation4588. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa351_inst, refa351_op in H. discriminate H. Qed.

Lemma refa351_not4590 : ~ @Equation4590 Fin4 refa351_inst.
Proof. unfold Equation4590. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa351_inst, refa351_op in H. discriminate H. Qed.

Lemma refa351_not4599 : ~ @Equation4599 Fin4 refa351_inst.
Proof. unfold Equation4599. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa351_inst, refa351_op in H. discriminate H. Qed.

Lemma refa351_not4605 : ~ @Equation4605 Fin4 refa351_inst.
Proof. unfold Equation4605. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa351_inst, refa351_op in H. discriminate H. Qed.

Lemma refa351_not4606 : ~ @Equation4606 Fin4 refa351_inst.
Proof. unfold Equation4606. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa351_inst, refa351_op in H. discriminate H. Qed.

Lemma refa351_not4608 : ~ @Equation4608 Fin4 refa351_inst.
Proof. unfold Equation4608. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa351_inst, refa351_op in H. discriminate H. Qed.

Lemma refa351_not4635 : ~ @Equation4635 Fin4 refa351_inst.
Proof. unfold Equation4635. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa351_inst, refa351_op in H. discriminate H. Qed.

Lemma refa351_not4636 : ~ @Equation4636 Fin4 refa351_inst.
Proof. unfold Equation4636. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa351_inst, refa351_op in H. discriminate H. Qed.

(** ---- refa352 (Fin4) ---- *)

Definition refa352_op (x y : Fin4) : Fin4 :=
  match x, y with
  | F4_0, F4_0 => F4_0 | F4_0, F4_1 => F4_0 | F4_0, F4_2 => F4_0 | F4_0, F4_3 => F4_1
  | F4_1, F4_0 => F4_1 | F4_1, F4_1 => F4_1 | F4_1, F4_2 => F4_1 | F4_1, F4_3 => F4_0
  | F4_2, F4_0 => F4_3 | F4_2, F4_1 => F4_3 | F4_2, F4_2 => F4_2 | F4_2, F4_3 => F4_2
  | F4_3, F4_0 => F4_2 | F4_3, F4_1 => F4_2 | F4_3, F4_2 => F4_3 | F4_3, F4_3 => F4_3
  end.

#[local] Instance refa352_inst : Magma Fin4 := {| magma_op := refa352_op |}.

Lemma refa352_sat2666 : @Equation2666 Fin4 refa352_inst.
Proof. unfold Equation2666, magma_op, refa352_inst, refa352_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa352_not2043 : ~ @Equation2043 Fin4 refa352_inst.
Proof. unfold Equation2043. intro H. specialize (H F4_0 F4_2). unfold magma_op, refa352_inst, refa352_op in H. discriminate H. Qed.

Lemma refa352_not2650 : ~ @Equation2650 Fin4 refa352_inst.
Proof. unfold Equation2650. intro H. specialize (H F4_0 F4_2). unfold magma_op, refa352_inst, refa352_op in H. discriminate H. Qed.

Lemma refa352_not2669 : ~ @Equation2669 Fin4 refa352_inst.
Proof. unfold Equation2669. intro H. specialize (H F4_0 F4_2). unfold magma_op, refa352_inst, refa352_op in H. discriminate H. Qed.

Lemma refa352_not2865 : ~ @Equation2865 Fin4 refa352_inst.
Proof. unfold Equation2865. intro H. specialize (H F4_0 F4_2). unfold magma_op, refa352_inst, refa352_op in H. discriminate H. Qed.

Lemma refa352_not3315 : ~ @Equation3315 Fin4 refa352_inst.
Proof. unfold Equation3315. intro H. specialize (H F4_0 F4_2). unfold magma_op, refa352_inst, refa352_op in H. discriminate H. Qed.

Lemma refa352_not3316 : ~ @Equation3316 Fin4 refa352_inst.
Proof. unfold Equation3316. intro H. specialize (H F4_0 F4_2). unfold magma_op, refa352_inst, refa352_op in H. discriminate H. Qed.

Lemma refa352_not3519 : ~ @Equation3519 Fin4 refa352_inst.
Proof. unfold Equation3519. intro H. specialize (H F4_0 F4_2). unfold magma_op, refa352_inst, refa352_op in H. discriminate H. Qed.

Lemma refa352_not3521 : ~ @Equation3521 Fin4 refa352_inst.
Proof. unfold Equation3521. intro H. specialize (H F4_0 F4_2). unfold magma_op, refa352_inst, refa352_op in H. discriminate H. Qed.

Lemma refa352_not4314 : ~ @Equation4314 Fin4 refa352_inst.
Proof. unfold Equation4314. intro H. specialize (H F4_0 F4_2). unfold magma_op, refa352_inst, refa352_op in H. discriminate H. Qed.

(** ---- refa353 (Fin4) ---- *)

Definition refa353_op (x y : Fin4) : Fin4 :=
  match x, y with
  | F4_0, F4_0 => F4_0 | F4_0, F4_1 => F4_0 | F4_0, F4_2 => F4_3 | F4_0, F4_3 => F4_3
  | F4_1, F4_0 => F4_2 | F4_1, F4_1 => F4_3 | F4_1, F4_2 => F4_2 | F4_1, F4_3 => F4_2
  | F4_2, F4_0 => F4_1 | F4_2, F4_1 => F4_1 | F4_2, F4_2 => F4_2 | F4_2, F4_3 => F4_3
  | F4_3, F4_0 => F4_0 | F4_3, F4_1 => F4_0 | F4_3, F4_2 => F4_2 | F4_3, F4_3 => F4_0
  end.

#[local] Instance refa353_inst : Magma Fin4 := {| magma_op := refa353_op |}.

Lemma refa353_sat2462 : @Equation2462 Fin4 refa353_inst.
Proof. unfold Equation2462, magma_op, refa353_inst, refa353_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa353_not4065 : ~ @Equation4065 Fin4 refa353_inst.
Proof. unfold Equation4065. intro H. specialize (H F4_1). unfold magma_op, refa353_inst, refa353_op in H. discriminate H. Qed.

(** ---- refa354 (Fin4) ---- *)

Definition refa354_op (x y : Fin4) : Fin4 :=
  match x, y with
  | F4_0, F4_0 => F4_0 | F4_0, F4_1 => F4_2 | F4_0, F4_2 => F4_1 | F4_0, F4_3 => F4_3
  | F4_1, F4_0 => F4_2 | F4_1, F4_1 => F4_0 | F4_1, F4_2 => F4_3 | F4_1, F4_3 => F4_1
  | F4_2, F4_0 => F4_3 | F4_2, F4_1 => F4_1 | F4_2, F4_2 => F4_2 | F4_2, F4_3 => F4_0
  | F4_3, F4_0 => F4_1 | F4_3, F4_1 => F4_3 | F4_3, F4_2 => F4_0 | F4_3, F4_3 => F4_2
  end.

#[local] Instance refa354_inst : Magma Fin4 := {| magma_op := refa354_op |}.

Lemma refa354_sat429 : @Equation429 Fin4 refa354_inst.
Proof. unfold Equation429, magma_op, refa354_inst, refa354_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa354_sat633 : @Equation633 Fin4 refa354_inst.
Proof. unfold Equation633, magma_op, refa354_inst, refa354_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa354_sat1452 : @Equation1452 Fin4 refa354_inst.
Proof. unfold Equation1452, magma_op, refa354_inst, refa354_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa354_sat1793 : @Equation1793 Fin4 refa354_inst.
Proof. unfold Equation1793, magma_op, refa354_inst, refa354_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa354_not47 : ~ @Equation47 Fin4 refa354_inst.
Proof. unfold Equation47. intro H. specialize (H F4_1). unfold magma_op, refa354_inst, refa354_op in H. discriminate H. Qed.

Lemma refa354_not99 : ~ @Equation99 Fin4 refa354_inst.
Proof. unfold Equation99. intro H. specialize (H F4_1). unfold magma_op, refa354_inst, refa354_op in H. discriminate H. Qed.

Lemma refa354_not151 : ~ @Equation151 Fin4 refa354_inst.
Proof. unfold Equation151. intro H. specialize (H F4_1). unfold magma_op, refa354_inst, refa354_op in H. discriminate H. Qed.

Lemma refa354_not211 : ~ @Equation211 Fin4 refa354_inst.
Proof. unfold Equation211. intro H. specialize (H F4_0 F4_2). unfold magma_op, refa354_inst, refa354_op in H. discriminate H. Qed.

Lemma refa354_not261 : ~ @Equation261 Fin4 refa354_inst.
Proof. unfold Equation261. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa354_inst, refa354_op in H. discriminate H. Qed.

Lemma refa354_not413 : ~ @Equation413 Fin4 refa354_inst.
Proof. unfold Equation413. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa354_inst, refa354_op in H. discriminate H. Qed.

Lemma refa354_not414 : ~ @Equation414 Fin4 refa354_inst.
Proof. unfold Equation414. intro H. specialize (H F4_0 F4_2). unfold magma_op, refa354_inst, refa354_op in H. discriminate H. Qed.

Lemma refa354_not416 : ~ @Equation416 Fin4 refa354_inst.
Proof. unfold Equation416. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa354_inst, refa354_op in H. discriminate H. Qed.

Lemma refa354_not417 : ~ @Equation417 Fin4 refa354_inst.
Proof. unfold Equation417. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa354_inst, refa354_op in H. discriminate H. Qed.

Lemma refa354_not419 : ~ @Equation419 Fin4 refa354_inst.
Proof. unfold Equation419. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa354_inst, refa354_op in H. discriminate H. Qed.

Lemma refa354_not420 : ~ @Equation420 Fin4 refa354_inst.
Proof. unfold Equation420. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa354_inst, refa354_op in H. discriminate H. Qed.

Lemma refa354_not426 : ~ @Equation426 Fin4 refa354_inst.
Proof. unfold Equation426. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa354_inst, refa354_op in H. discriminate H. Qed.

Lemma refa354_not436 : ~ @Equation436 Fin4 refa354_inst.
Proof. unfold Equation436. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa354_inst, refa354_op in H. discriminate H. Qed.

Lemma refa354_not437 : ~ @Equation437 Fin4 refa354_inst.
Proof. unfold Equation437. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa354_inst, refa354_op in H. discriminate H. Qed.

Lemma refa354_not440 : ~ @Equation440 Fin4 refa354_inst.
Proof. unfold Equation440. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa354_inst, refa354_op in H. discriminate H. Qed.

Lemma refa354_not619 : ~ @Equation619 Fin4 refa354_inst.
Proof. unfold Equation619. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa354_inst, refa354_op in H. discriminate H. Qed.

Lemma refa354_not620 : ~ @Equation620 Fin4 refa354_inst.
Proof. unfold Equation620. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa354_inst, refa354_op in H. discriminate H. Qed.

Lemma refa354_not622 : ~ @Equation622 Fin4 refa354_inst.
Proof. unfold Equation622. intro H. specialize (H F4_0 F4_2). unfold magma_op, refa354_inst, refa354_op in H. discriminate H. Qed.

Lemma refa354_not623 : ~ @Equation623 Fin4 refa354_inst.
Proof. unfold Equation623. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa354_inst, refa354_op in H. discriminate H. Qed.

Lemma refa354_not629 : ~ @Equation629 Fin4 refa354_inst.
Proof. unfold Equation629. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa354_inst, refa354_op in H. discriminate H. Qed.

Lemma refa354_not630 : ~ @Equation630 Fin4 refa354_inst.
Proof. unfold Equation630. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa354_inst, refa354_op in H. discriminate H. Qed.

Lemma refa354_not632 : ~ @Equation632 Fin4 refa354_inst.
Proof. unfold Equation632. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa354_inst, refa354_op in H. discriminate H. Qed.

Lemma refa354_not639 : ~ @Equation639 Fin4 refa354_inst.
Proof. unfold Equation639. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa354_inst, refa354_op in H. discriminate H. Qed.

Lemma refa354_not640 : ~ @Equation640 Fin4 refa354_inst.
Proof. unfold Equation640. intro H. specialize (H F4_0 F4_2). unfold magma_op, refa354_inst, refa354_op in H. discriminate H. Qed.

Lemma refa354_not642 : ~ @Equation642 Fin4 refa354_inst.
Proof. unfold Equation642. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa354_inst, refa354_op in H. discriminate H. Qed.

Lemma refa354_not643 : ~ @Equation643 Fin4 refa354_inst.
Proof. unfold Equation643. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa354_inst, refa354_op in H. discriminate H. Qed.

Lemma refa354_not817 : ~ @Equation817 Fin4 refa354_inst.
Proof. unfold Equation817. intro H. specialize (H F4_1). unfold magma_op, refa354_inst, refa354_op in H. discriminate H. Qed.

Lemma refa354_not1020 : ~ @Equation1020 Fin4 refa354_inst.
Proof. unfold Equation1020. intro H. specialize (H F4_1). unfold magma_op, refa354_inst, refa354_op in H. discriminate H. Qed.

Lemma refa354_not1223 : ~ @Equation1223 Fin4 refa354_inst.
Proof. unfold Equation1223. intro H. specialize (H F4_1). unfold magma_op, refa354_inst, refa354_op in H. discriminate H. Qed.

Lemma refa354_not1427 : ~ @Equation1427 Fin4 refa354_inst.
Proof. unfold Equation1427. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa354_inst, refa354_op in H. discriminate H. Qed.

Lemma refa354_not1428 : ~ @Equation1428 Fin4 refa354_inst.
Proof. unfold Equation1428. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa354_inst, refa354_op in H. discriminate H. Qed.

Lemma refa354_not1429 : ~ @Equation1429 Fin4 refa354_inst.
Proof. unfold Equation1429. intro H. specialize (H F4_0 F4_2). unfold magma_op, refa354_inst, refa354_op in H. discriminate H. Qed.

Lemma refa354_not1431 : ~ @Equation1431 Fin4 refa354_inst.
Proof. unfold Equation1431. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa354_inst, refa354_op in H. discriminate H. Qed.

Lemma refa354_not1434 : ~ @Equation1434 Fin4 refa354_inst.
Proof. unfold Equation1434. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa354_inst, refa354_op in H. discriminate H. Qed.

Lemma refa354_not1435 : ~ @Equation1435 Fin4 refa354_inst.
Proof. unfold Equation1435. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa354_inst, refa354_op in H. discriminate H. Qed.

Lemma refa354_not1441 : ~ @Equation1441 Fin4 refa354_inst.
Proof. unfold Equation1441. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa354_inst, refa354_op in H. discriminate H. Qed.

Lemma refa354_not1445 : ~ @Equation1445 Fin4 refa354_inst.
Proof. unfold Equation1445. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa354_inst, refa354_op in H. discriminate H. Qed.

Lemma refa354_not1451 : ~ @Equation1451 Fin4 refa354_inst.
Proof. unfold Equation1451. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa354_inst, refa354_op in H. discriminate H. Qed.

Lemma refa354_not1454 : ~ @Equation1454 Fin4 refa354_inst.
Proof. unfold Equation1454. intro H. specialize (H F4_0 F4_2). unfold magma_op, refa354_inst, refa354_op in H. discriminate H. Qed.

Lemma refa354_not1631 : ~ @Equation1631 Fin4 refa354_inst.
Proof. unfold Equation1631. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa354_inst, refa354_op in H. discriminate H. Qed.

Lemma refa354_not1632 : ~ @Equation1632 Fin4 refa354_inst.
Proof. unfold Equation1632. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa354_inst, refa354_op in H. discriminate H. Qed.

Lemma refa354_not1634 : ~ @Equation1634 Fin4 refa354_inst.
Proof. unfold Equation1634. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa354_inst, refa354_op in H. discriminate H. Qed.

Lemma refa354_not1635 : ~ @Equation1635 Fin4 refa354_inst.
Proof. unfold Equation1635. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa354_inst, refa354_op in H. discriminate H. Qed.

Lemma refa354_not1637 : ~ @Equation1637 Fin4 refa354_inst.
Proof. unfold Equation1637. intro H. specialize (H F4_0 F4_2). unfold magma_op, refa354_inst, refa354_op in H. discriminate H. Qed.

Lemma refa354_not1638 : ~ @Equation1638 Fin4 refa354_inst.
Proof. unfold Equation1638. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa354_inst, refa354_op in H. discriminate H. Qed.

Lemma refa354_not1644 : ~ @Equation1644 Fin4 refa354_inst.
Proof. unfold Equation1644. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa354_inst, refa354_op in H. discriminate H. Qed.

Lemma refa354_not1648 : ~ @Equation1648 Fin4 refa354_inst.
Proof. unfold Equation1648. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa354_inst, refa354_op in H. discriminate H. Qed.

Lemma refa354_not1655 : ~ @Equation1655 Fin4 refa354_inst.
Proof. unfold Equation1655. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa354_inst, refa354_op in H. discriminate H. Qed.

Lemma refa354_not1657 : ~ @Equation1657 Fin4 refa354_inst.
Proof. unfold Equation1657. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa354_inst, refa354_op in H. discriminate H. Qed.

Lemma refa354_not1832 : ~ @Equation1832 Fin4 refa354_inst.
Proof. unfold Equation1832. intro H. specialize (H F4_1). unfold magma_op, refa354_inst, refa354_op in H. discriminate H. Qed.

Lemma refa354_not2035 : ~ @Equation2035 Fin4 refa354_inst.
Proof. unfold Equation2035. intro H. specialize (H F4_1). unfold magma_op, refa354_inst, refa354_op in H. discriminate H. Qed.

Lemma refa354_not2238 : ~ @Equation2238 Fin4 refa354_inst.
Proof. unfold Equation2238. intro H. specialize (H F4_1). unfold magma_op, refa354_inst, refa354_op in H. discriminate H. Qed.

Lemma refa354_not2441 : ~ @Equation2441 Fin4 refa354_inst.
Proof. unfold Equation2441. intro H. specialize (H F4_1). unfold magma_op, refa354_inst, refa354_op in H. discriminate H. Qed.

Lemma refa354_not2644 : ~ @Equation2644 Fin4 refa354_inst.
Proof. unfold Equation2644. intro H. specialize (H F4_1). unfold magma_op, refa354_inst, refa354_op in H. discriminate H. Qed.

Lemma refa354_not2847 : ~ @Equation2847 Fin4 refa354_inst.
Proof. unfold Equation2847. intro H. specialize (H F4_1). unfold magma_op, refa354_inst, refa354_op in H. discriminate H. Qed.

Lemma refa354_not3050 : ~ @Equation3050 Fin4 refa354_inst.
Proof. unfold Equation3050. intro H. specialize (H F4_1). unfold magma_op, refa354_inst, refa354_op in H. discriminate H. Qed.

Lemma refa354_not3253 : ~ @Equation3253 Fin4 refa354_inst.
Proof. unfold Equation3253. intro H. specialize (H F4_1). unfold magma_op, refa354_inst, refa354_op in H. discriminate H. Qed.

Lemma refa354_not3456 : ~ @Equation3456 Fin4 refa354_inst.
Proof. unfold Equation3456. intro H. specialize (H F4_1). unfold magma_op, refa354_inst, refa354_op in H. discriminate H. Qed.

Lemma refa354_not3660 : ~ @Equation3660 Fin4 refa354_inst.
Proof. unfold Equation3660. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa354_inst, refa354_op in H. discriminate H. Qed.

Lemma refa354_not3661 : ~ @Equation3661 Fin4 refa354_inst.
Proof. unfold Equation3661. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa354_inst, refa354_op in H. discriminate H. Qed.

Lemma refa354_not3662 : ~ @Equation3662 Fin4 refa354_inst.
Proof. unfold Equation3662. intro H. specialize (H F4_0 F4_2). unfold magma_op, refa354_inst, refa354_op in H. discriminate H. Qed.

Lemma refa354_not3664 : ~ @Equation3664 Fin4 refa354_inst.
Proof. unfold Equation3664. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa354_inst, refa354_op in H. discriminate H. Qed.

Lemma refa354_not3665 : ~ @Equation3665 Fin4 refa354_inst.
Proof. unfold Equation3665. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa354_inst, refa354_op in H. discriminate H. Qed.

Lemma refa354_not3667 : ~ @Equation3667 Fin4 refa354_inst.
Proof. unfold Equation3667. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa354_inst, refa354_op in H. discriminate H. Qed.

Lemma refa354_not3668 : ~ @Equation3668 Fin4 refa354_inst.
Proof. unfold Equation3668. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa354_inst, refa354_op in H. discriminate H. Qed.

Lemma refa354_not3712 : ~ @Equation3712 Fin4 refa354_inst.
Proof. unfold Equation3712. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa354_inst, refa354_op in H. discriminate H. Qed.

Lemma refa354_not3714 : ~ @Equation3714 Fin4 refa354_inst.
Proof. unfold Equation3714. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa354_inst, refa354_op in H. discriminate H. Qed.

Lemma refa354_not3721 : ~ @Equation3721 Fin4 refa354_inst.
Proof. unfold Equation3721. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa354_inst, refa354_op in H. discriminate H. Qed.

Lemma refa354_not3722 : ~ @Equation3722 Fin4 refa354_inst.
Proof. unfold Equation3722. intro H. specialize (H F4_0 F4_2). unfold magma_op, refa354_inst, refa354_op in H. discriminate H. Qed.

Lemma refa354_not3862 : ~ @Equation3862 Fin4 refa354_inst.
Proof. unfold Equation3862. intro H. specialize (H F4_1). unfold magma_op, refa354_inst, refa354_op in H. discriminate H. Qed.

Lemma refa354_not4065 : ~ @Equation4065 Fin4 refa354_inst.
Proof. unfold Equation4065. intro H. specialize (H F4_1). unfold magma_op, refa354_inst, refa354_op in H. discriminate H. Qed.

Lemma refa354_not4320 : ~ @Equation4320 Fin4 refa354_inst.
Proof. unfold Equation4320. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa354_inst, refa354_op in H. discriminate H. Qed.

Lemma refa354_not4399 : ~ @Equation4399 Fin4 refa354_inst.
Proof. unfold Equation4399. intro H. specialize (H F4_0 F4_2). unfold magma_op, refa354_inst, refa354_op in H. discriminate H. Qed.

Lemma refa354_not4435 : ~ @Equation4435 Fin4 refa354_inst.
Proof. unfold Equation4435. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa354_inst, refa354_op in H. discriminate H. Qed.

Lemma refa354_not4470 : ~ @Equation4470 Fin4 refa354_inst.
Proof. unfold Equation4470. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa354_inst, refa354_op in H. discriminate H. Qed.

Lemma refa354_not4590 : ~ @Equation4590 Fin4 refa354_inst.
Proof. unfold Equation4590. intro H. specialize (H F4_0 F4_2). unfold magma_op, refa354_inst, refa354_op in H. discriminate H. Qed.

(** ---- refa355 (Fin4) ---- *)

Definition refa355_op (x y : Fin4) : Fin4 :=
  match x, y with
  | F4_0, F4_0 => F4_1 | F4_0, F4_1 => F4_3 | F4_0, F4_2 => F4_0 | F4_0, F4_3 => F4_1
  | F4_1, F4_0 => F4_3 | F4_1, F4_1 => F4_3 | F4_1, F4_2 => F4_1 | F4_1, F4_3 => F4_0
  | F4_2, F4_0 => F4_3 | F4_2, F4_1 => F4_0 | F4_2, F4_2 => F4_2 | F4_2, F4_3 => F4_1
  | F4_3, F4_0 => F4_1 | F4_3, F4_1 => F4_0 | F4_3, F4_2 => F4_3 | F4_3, F4_3 => F4_0
  end.

#[local] Instance refa355_inst : Magma Fin4 := {| magma_op := refa355_op |}.

Lemma refa355_sat3355 : @Equation3355 Fin4 refa355_inst.
Proof. unfold Equation3355, magma_op, refa355_inst, refa355_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa355_not3306 : ~ @Equation3306 Fin4 refa355_inst.
Proof. unfold Equation3306. intro H. specialize (H F4_0 F4_2). unfold magma_op, refa355_inst, refa355_op in H. discriminate H. Qed.

Lemma refa355_not3308 : ~ @Equation3308 Fin4 refa355_inst.
Proof. unfold Equation3308. intro H. specialize (H F4_0 F4_2). unfold magma_op, refa355_inst, refa355_op in H. discriminate H. Qed.

Lemma refa355_not3315 : ~ @Equation3315 Fin4 refa355_inst.
Proof. unfold Equation3315. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa355_inst, refa355_op in H. discriminate H. Qed.

Lemma refa355_not3319 : ~ @Equation3319 Fin4 refa355_inst.
Proof. unfold Equation3319. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa355_inst, refa355_op in H. discriminate H. Qed.

Lemma refa355_not3342 : ~ @Equation3342 Fin4 refa355_inst.
Proof. unfold Equation3342. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa355_inst, refa355_op in H. discriminate H. Qed.

Lemma refa355_not3346 : ~ @Equation3346 Fin4 refa355_inst.
Proof. unfold Equation3346. intro H. specialize (H F4_0 F4_2). unfold magma_op, refa355_inst, refa355_op in H. discriminate H. Qed.

Lemma refa355_not3353 : ~ @Equation3353 Fin4 refa355_inst.
Proof. unfold Equation3353. intro H. specialize (H F4_0 F4_2). unfold magma_op, refa355_inst, refa355_op in H. discriminate H. Qed.

Lemma refa355_not3509 : ~ @Equation3509 Fin4 refa355_inst.
Proof. unfold Equation3509. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa355_inst, refa355_op in H. discriminate H. Qed.

Lemma refa355_not3511 : ~ @Equation3511 Fin4 refa355_inst.
Proof. unfold Equation3511. intro H. specialize (H F4_0 F4_2). unfold magma_op, refa355_inst, refa355_op in H. discriminate H. Qed.

Lemma refa355_not3518 : ~ @Equation3518 Fin4 refa355_inst.
Proof. unfold Equation3518. intro H. specialize (H F4_0 F4_2). unfold magma_op, refa355_inst, refa355_op in H. discriminate H. Qed.

Lemma refa355_not3522 : ~ @Equation3522 Fin4 refa355_inst.
Proof. unfold Equation3522. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa355_inst, refa355_op in H. discriminate H. Qed.

Lemma refa355_not3545 : ~ @Equation3545 Fin4 refa355_inst.
Proof. unfold Equation3545. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa355_inst, refa355_op in H. discriminate H. Qed.

Lemma refa355_not3549 : ~ @Equation3549 Fin4 refa355_inst.
Proof. unfold Equation3549. intro H. specialize (H F4_0 F4_2). unfold magma_op, refa355_inst, refa355_op in H. discriminate H. Qed.

Lemma refa355_not3556 : ~ @Equation3556 Fin4 refa355_inst.
Proof. unfold Equation3556. intro H. specialize (H F4_0 F4_2). unfold magma_op, refa355_inst, refa355_op in H. discriminate H. Qed.

Lemma refa355_not3558 : ~ @Equation3558 Fin4 refa355_inst.
Proof. unfold Equation3558. intro H. specialize (H F4_0 F4_2). unfold magma_op, refa355_inst, refa355_op in H. discriminate H. Qed.

Lemma refa355_not3659 : ~ @Equation3659 Fin4 refa355_inst.
Proof. unfold Equation3659. intro H. specialize (H F4_0). unfold magma_op, refa355_inst, refa355_op in H. discriminate H. Qed.

Lemma refa355_not3915 : ~ @Equation3915 Fin4 refa355_inst.
Proof. unfold Equation3915. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa355_inst, refa355_op in H. discriminate H. Qed.

Lemma refa355_not3917 : ~ @Equation3917 Fin4 refa355_inst.
Proof. unfold Equation3917. intro H. specialize (H F4_0 F4_2). unfold magma_op, refa355_inst, refa355_op in H. discriminate H. Qed.

Lemma refa355_not3924 : ~ @Equation3924 Fin4 refa355_inst.
Proof. unfold Equation3924. intro H. specialize (H F4_0 F4_2). unfold magma_op, refa355_inst, refa355_op in H. discriminate H. Qed.

Lemma refa355_not3928 : ~ @Equation3928 Fin4 refa355_inst.
Proof. unfold Equation3928. intro H. specialize (H F4_0 F4_3). unfold magma_op, refa355_inst, refa355_op in H. discriminate H. Qed.

Lemma refa355_not3951 : ~ @Equation3951 Fin4 refa355_inst.
Proof. unfold Equation3951. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa355_inst, refa355_op in H. discriminate H. Qed.

Lemma refa355_not3955 : ~ @Equation3955 Fin4 refa355_inst.
Proof. unfold Equation3955. intro H. specialize (H F4_0 F4_2). unfold magma_op, refa355_inst, refa355_op in H. discriminate H. Qed.

Lemma refa355_not3962 : ~ @Equation3962 Fin4 refa355_inst.
Proof. unfold Equation3962. intro H. specialize (H F4_0 F4_2). unfold magma_op, refa355_inst, refa355_op in H. discriminate H. Qed.

Lemma refa355_not3964 : ~ @Equation3964 Fin4 refa355_inst.
Proof. unfold Equation3964. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa355_inst, refa355_op in H. discriminate H. Qed.

Lemma refa355_not4118 : ~ @Equation4118 Fin4 refa355_inst.
Proof. unfold Equation4118. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa355_inst, refa355_op in H. discriminate H. Qed.

Lemma refa355_not4120 : ~ @Equation4120 Fin4 refa355_inst.
Proof. unfold Equation4120. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa355_inst, refa355_op in H. discriminate H. Qed.

Lemma refa355_not4127 : ~ @Equation4127 Fin4 refa355_inst.
Proof. unfold Equation4127. intro H. specialize (H F4_0 F4_2). unfold magma_op, refa355_inst, refa355_op in H. discriminate H. Qed.

Lemma refa355_not4154 : ~ @Equation4154 Fin4 refa355_inst.
Proof. unfold Equation4154. intro H. specialize (H F4_0 F4_2). unfold magma_op, refa355_inst, refa355_op in H. discriminate H. Qed.

Lemma refa355_not4158 : ~ @Equation4158 Fin4 refa355_inst.
Proof. unfold Equation4158. intro H. specialize (H F4_0 F4_2). unfold magma_op, refa355_inst, refa355_op in H. discriminate H. Qed.

Lemma refa355_not4165 : ~ @Equation4165 Fin4 refa355_inst.
Proof. unfold Equation4165. intro H. specialize (H F4_0 F4_2). unfold magma_op, refa355_inst, refa355_op in H. discriminate H. Qed.

Lemma refa355_not4167 : ~ @Equation4167 Fin4 refa355_inst.
Proof. unfold Equation4167. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa355_inst, refa355_op in H. discriminate H. Qed.

Lemma refa355_not4283 : ~ @Equation4283 Fin4 refa355_inst.
Proof. unfold Equation4283. intro H. specialize (H F4_2 F4_0). unfold magma_op, refa355_inst, refa355_op in H. discriminate H. Qed.

Lemma refa355_not4290 : ~ @Equation4290 Fin4 refa355_inst.
Proof. unfold Equation4290. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa355_inst, refa355_op in H. discriminate H. Qed.

Lemma refa355_not4320 : ~ @Equation4320 Fin4 refa355_inst.
Proof. unfold Equation4320. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa355_inst, refa355_op in H. discriminate H. Qed.

Lemma refa355_not4396 : ~ @Equation4396 Fin4 refa355_inst.
Proof. unfold Equation4396. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa355_inst, refa355_op in H. discriminate H. Qed.

Lemma refa355_not4398 : ~ @Equation4398 Fin4 refa355_inst.
Proof. unfold Equation4398. intro H. specialize (H F4_2 F4_0). unfold magma_op, refa355_inst, refa355_op in H. discriminate H. Qed.

Lemma refa355_not4405 : ~ @Equation4405 Fin4 refa355_inst.
Proof. unfold Equation4405. intro H. specialize (H F4_2 F4_0). unfold magma_op, refa355_inst, refa355_op in H. discriminate H. Qed.

Lemma refa355_not4433 : ~ @Equation4433 Fin4 refa355_inst.
Proof. unfold Equation4433. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa355_inst, refa355_op in H. discriminate H. Qed.

Lemma refa355_not4442 : ~ @Equation4442 Fin4 refa355_inst.
Proof. unfold Equation4442. intro H. specialize (H F4_2 F4_0). unfold magma_op, refa355_inst, refa355_op in H. discriminate H. Qed.

Lemma refa355_not4473 : ~ @Equation4473 Fin4 refa355_inst.
Proof. unfold Equation4473. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa355_inst, refa355_op in H. discriminate H. Qed.

Lemma refa355_not4480 : ~ @Equation4480 Fin4 refa355_inst.
Proof. unfold Equation4480. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa355_inst, refa355_op in H. discriminate H. Qed.

Lemma refa355_not4482 : ~ @Equation4482 Fin4 refa355_inst.
Proof. unfold Equation4482. intro H. specialize (H F4_0 F4_2). unfold magma_op, refa355_inst, refa355_op in H. discriminate H. Qed.

Lemma refa355_not4598 : ~ @Equation4598 Fin4 refa355_inst.
Proof. unfold Equation4598. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa355_inst, refa355_op in H. discriminate H. Qed.

Lemma refa355_not4605 : ~ @Equation4605 Fin4 refa355_inst.
Proof. unfold Equation4605. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa355_inst, refa355_op in H. discriminate H. Qed.

Lemma refa355_not4635 : ~ @Equation4635 Fin4 refa355_inst.
Proof. unfold Equation4635. intro H. specialize (H F4_2 F4_0). unfold magma_op, refa355_inst, refa355_op in H. discriminate H. Qed.

(** ---- refa356 (Fin4) ---- *)

Definition refa356_op (x y : Fin4) : Fin4 :=
  match x, y with
  | F4_0, F4_0 => F4_3 | F4_0, F4_1 => F4_0 | F4_0, F4_2 => F4_0 | F4_0, F4_3 => F4_1
  | F4_1, F4_0 => F4_2 | F4_1, F4_1 => F4_0 | F4_1, F4_2 => F4_1 | F4_1, F4_3 => F4_1
  | F4_2, F4_0 => F4_2 | F4_2, F4_1 => F4_3 | F4_2, F4_2 => F4_1 | F4_2, F4_3 => F4_2
  | F4_3, F4_0 => F4_3 | F4_3, F4_1 => F4_3 | F4_3, F4_2 => F4_0 | F4_3, F4_3 => F4_2
  end.

#[local] Instance refa356_inst : Magma Fin4 := {| magma_op := refa356_op |}.

Lemma refa356_sat52 : @Equation52 Fin4 refa356_inst.
Proof. unfold Equation52, magma_op, refa356_inst, refa356_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa356_sat55 : @Equation55 Fin4 refa356_inst.
Proof. unfold Equation55, magma_op, refa356_inst, refa356_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa356_not616 : ~ @Equation616 Fin4 refa356_inst.
Proof. unfold Equation616. intro H. specialize (H F4_0 F4_3). unfold magma_op, refa356_inst, refa356_op in H. discriminate H. Qed.

Lemma refa356_not642 : ~ @Equation642 Fin4 refa356_inst.
Proof. unfold Equation642. intro H. specialize (H F4_0 F4_3). unfold magma_op, refa356_inst, refa356_op in H. discriminate H. Qed.

Lemma refa356_not845 : ~ @Equation845 Fin4 refa356_inst.
Proof. unfold Equation845. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa356_inst, refa356_op in H. discriminate H. Qed.

Lemma refa356_not1426 : ~ @Equation1426 Fin4 refa356_inst.
Proof. unfold Equation1426. intro H. specialize (H F4_0). unfold magma_op, refa356_inst, refa356_op in H. discriminate H. Qed.

Lemma refa356_not3862 : ~ @Equation3862 Fin4 refa356_inst.
Proof. unfold Equation3862. intro H. specialize (H F4_0). unfold magma_op, refa356_inst, refa356_op in H. discriminate H. Qed.

Lemma refa356_not4118 : ~ @Equation4118 Fin4 refa356_inst.
Proof. unfold Equation4118. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa356_inst, refa356_op in H. discriminate H. Qed.

Lemma refa356_not4590 : ~ @Equation4590 Fin4 refa356_inst.
Proof. unfold Equation4590. intro H. specialize (H F4_0 F4_2). unfold magma_op, refa356_inst, refa356_op in H. discriminate H. Qed.

(** ---- refa357 (Fin4) ---- *)

Definition refa357_op (x y : Fin4) : Fin4 :=
  match x, y with
  | F4_0, F4_0 => F4_2 | F4_0, F4_1 => F4_0 | F4_0, F4_2 => F4_1 | F4_0, F4_3 => F4_1
  | F4_1, F4_0 => F4_3 | F4_1, F4_1 => F4_1 | F4_1, F4_2 => F4_3 | F4_1, F4_3 => F4_2
  | F4_2, F4_0 => F4_1 | F4_2, F4_1 => F4_2 | F4_2, F4_2 => F4_0 | F4_2, F4_3 => F4_3
  | F4_3, F4_0 => F4_0 | F4_3, F4_1 => F4_3 | F4_3, F4_2 => F4_2 | F4_3, F4_3 => F4_0
  end.

#[local] Instance refa357_inst : Magma Fin4 := {| magma_op := refa357_op |}.

Lemma refa357_sat3106 : @Equation3106 Fin4 refa357_inst.
Proof. unfold Equation3106, magma_op, refa357_inst, refa357_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa357_sat3149 : @Equation3149 Fin4 refa357_inst.
Proof. unfold Equation3149, magma_op, refa357_inst, refa357_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa357_not47 : ~ @Equation47 Fin4 refa357_inst.
Proof. unfold Equation47. intro H. specialize (H F4_3). unfold magma_op, refa357_inst, refa357_op in H. discriminate H. Qed.

Lemma refa357_not105 : ~ @Equation105 Fin4 refa357_inst.
Proof. unfold Equation105. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa357_inst, refa357_op in H. discriminate H. Qed.

Lemma refa357_not107 : ~ @Equation107 Fin4 refa357_inst.
Proof. unfold Equation107. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa357_inst, refa357_op in H. discriminate H. Qed.

Lemma refa357_not151 : ~ @Equation151 Fin4 refa357_inst.
Proof. unfold Equation151. intro H. specialize (H F4_3). unfold magma_op, refa357_inst, refa357_op in H. discriminate H. Qed.

Lemma refa357_not203 : ~ @Equation203 Fin4 refa357_inst.
Proof. unfold Equation203. intro H. specialize (H F4_0). unfold magma_op, refa357_inst, refa357_op in H. discriminate H. Qed.

Lemma refa357_not255 : ~ @Equation255 Fin4 refa357_inst.
Proof. unfold Equation255. intro H. specialize (H F4_0). unfold magma_op, refa357_inst, refa357_op in H. discriminate H. Qed.

Lemma refa357_not411 : ~ @Equation411 Fin4 refa357_inst.
Proof. unfold Equation411. intro H. specialize (H F4_0). unfold magma_op, refa357_inst, refa357_op in H. discriminate H. Qed.

Lemma refa357_not614 : ~ @Equation614 Fin4 refa357_inst.
Proof. unfold Equation614. intro H. specialize (H F4_0). unfold magma_op, refa357_inst, refa357_op in H. discriminate H. Qed.

Lemma refa357_not817 : ~ @Equation817 Fin4 refa357_inst.
Proof. unfold Equation817. intro H. specialize (H F4_0). unfold magma_op, refa357_inst, refa357_op in H. discriminate H. Qed.

Lemma refa357_not1020 : ~ @Equation1020 Fin4 refa357_inst.
Proof. unfold Equation1020. intro H. specialize (H F4_0). unfold magma_op, refa357_inst, refa357_op in H. discriminate H. Qed.

Lemma refa357_not1223 : ~ @Equation1223 Fin4 refa357_inst.
Proof. unfold Equation1223. intro H. specialize (H F4_0). unfold magma_op, refa357_inst, refa357_op in H. discriminate H. Qed.

Lemma refa357_not1426 : ~ @Equation1426 Fin4 refa357_inst.
Proof. unfold Equation1426. intro H. specialize (H F4_0). unfold magma_op, refa357_inst, refa357_op in H. discriminate H. Qed.

Lemma refa357_not1629 : ~ @Equation1629 Fin4 refa357_inst.
Proof. unfold Equation1629. intro H. specialize (H F4_0). unfold magma_op, refa357_inst, refa357_op in H. discriminate H. Qed.

Lemma refa357_not1832 : ~ @Equation1832 Fin4 refa357_inst.
Proof. unfold Equation1832. intro H. specialize (H F4_0). unfold magma_op, refa357_inst, refa357_op in H. discriminate H. Qed.

Lemma refa357_not2035 : ~ @Equation2035 Fin4 refa357_inst.
Proof. unfold Equation2035. intro H. specialize (H F4_0). unfold magma_op, refa357_inst, refa357_op in H. discriminate H. Qed.

Lemma refa357_not2238 : ~ @Equation2238 Fin4 refa357_inst.
Proof. unfold Equation2238. intro H. specialize (H F4_0). unfold magma_op, refa357_inst, refa357_op in H. discriminate H. Qed.

Lemma refa357_not2441 : ~ @Equation2441 Fin4 refa357_inst.
Proof. unfold Equation2441. intro H. specialize (H F4_0). unfold magma_op, refa357_inst, refa357_op in H. discriminate H. Qed.

Lemma refa357_not2644 : ~ @Equation2644 Fin4 refa357_inst.
Proof. unfold Equation2644. intro H. specialize (H F4_0). unfold magma_op, refa357_inst, refa357_op in H. discriminate H. Qed.

Lemma refa357_not2847 : ~ @Equation2847 Fin4 refa357_inst.
Proof. unfold Equation2847. intro H. specialize (H F4_3). unfold magma_op, refa357_inst, refa357_op in H. discriminate H. Qed.

Lemma refa357_not3052 : ~ @Equation3052 Fin4 refa357_inst.
Proof. unfold Equation3052. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa357_inst, refa357_op in H. discriminate H. Qed.

Lemma refa357_not3055 : ~ @Equation3055 Fin4 refa357_inst.
Proof. unfold Equation3055. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa357_inst, refa357_op in H. discriminate H. Qed.

Lemma refa357_not3058 : ~ @Equation3058 Fin4 refa357_inst.
Proof. unfold Equation3058. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa357_inst, refa357_op in H. discriminate H. Qed.

Lemma refa357_not3065 : ~ @Equation3065 Fin4 refa357_inst.
Proof. unfold Equation3065. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa357_inst, refa357_op in H. discriminate H. Qed.

Lemma refa357_not3066 : ~ @Equation3066 Fin4 refa357_inst.
Proof. unfold Equation3066. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa357_inst, refa357_op in H. discriminate H. Qed.

Lemma refa357_not3068 : ~ @Equation3068 Fin4 refa357_inst.
Proof. unfold Equation3068. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa357_inst, refa357_op in H. discriminate H. Qed.

Lemma refa357_not3075 : ~ @Equation3075 Fin4 refa357_inst.
Proof. unfold Equation3075. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa357_inst, refa357_op in H. discriminate H. Qed.

Lemma refa357_not3112 : ~ @Equation3112 Fin4 refa357_inst.
Proof. unfold Equation3112. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa357_inst, refa357_op in H. discriminate H. Qed.

Lemma refa357_not3115 : ~ @Equation3115 Fin4 refa357_inst.
Proof. unfold Equation3115. intro H. specialize (H F4_0 F4_2). unfold magma_op, refa357_inst, refa357_op in H. discriminate H. Qed.

Lemma refa357_not3150 : ~ @Equation3150 Fin4 refa357_inst.
Proof. unfold Equation3150. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa357_inst, refa357_op in H. discriminate H. Qed.

Lemma refa357_not3152 : ~ @Equation3152 Fin4 refa357_inst.
Proof. unfold Equation3152. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa357_inst, refa357_op in H. discriminate H. Qed.

Lemma refa357_not3253 : ~ @Equation3253 Fin4 refa357_inst.
Proof. unfold Equation3253. intro H. specialize (H F4_0). unfold magma_op, refa357_inst, refa357_op in H. discriminate H. Qed.

Lemma refa357_not3456 : ~ @Equation3456 Fin4 refa357_inst.
Proof. unfold Equation3456. intro H. specialize (H F4_0). unfold magma_op, refa357_inst, refa357_op in H. discriminate H. Qed.

Lemma refa357_not3659 : ~ @Equation3659 Fin4 refa357_inst.
Proof. unfold Equation3659. intro H. specialize (H F4_0). unfold magma_op, refa357_inst, refa357_op in H. discriminate H. Qed.

Lemma refa357_not3862 : ~ @Equation3862 Fin4 refa357_inst.
Proof. unfold Equation3862. intro H. specialize (H F4_0). unfold magma_op, refa357_inst, refa357_op in H. discriminate H. Qed.

Lemma refa357_not4065 : ~ @Equation4065 Fin4 refa357_inst.
Proof. unfold Equation4065. intro H. specialize (H F4_0). unfold magma_op, refa357_inst, refa357_op in H. discriminate H. Qed.

Lemma refa357_not4269 : ~ @Equation4269 Fin4 refa357_inst.
Proof. unfold Equation4269. intro H. specialize (H F4_0 F4_2). unfold magma_op, refa357_inst, refa357_op in H. discriminate H. Qed.

Lemma refa357_not4272 : ~ @Equation4272 Fin4 refa357_inst.
Proof. unfold Equation4272. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa357_inst, refa357_op in H. discriminate H. Qed.

Lemma refa357_not4273 : ~ @Equation4273 Fin4 refa357_inst.
Proof. unfold Equation4273. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa357_inst, refa357_op in H. discriminate H. Qed.

Lemma refa357_not4275 : ~ @Equation4275 Fin4 refa357_inst.
Proof. unfold Equation4275. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa357_inst, refa357_op in H. discriminate H. Qed.

Lemma refa357_not4284 : ~ @Equation4284 Fin4 refa357_inst.
Proof. unfold Equation4284. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa357_inst, refa357_op in H. discriminate H. Qed.

Lemma refa357_not4290 : ~ @Equation4290 Fin4 refa357_inst.
Proof. unfold Equation4290. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa357_inst, refa357_op in H. discriminate H. Qed.

Lemma refa357_not4291 : ~ @Equation4291 Fin4 refa357_inst.
Proof. unfold Equation4291. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa357_inst, refa357_op in H. discriminate H. Qed.

Lemma refa357_not4320 : ~ @Equation4320 Fin4 refa357_inst.
Proof. unfold Equation4320. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa357_inst, refa357_op in H. discriminate H. Qed.

Lemma refa357_not4380 : ~ @Equation4380 Fin4 refa357_inst.
Proof. unfold Equation4380. intro H. specialize (H F4_3). unfold magma_op, refa357_inst, refa357_op in H. discriminate H. Qed.

Lemma refa357_not4584 : ~ @Equation4584 Fin4 refa357_inst.
Proof. unfold Equation4584. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa357_inst, refa357_op in H. discriminate H. Qed.

Lemma refa357_not4587 : ~ @Equation4587 Fin4 refa357_inst.
Proof. unfold Equation4587. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa357_inst, refa357_op in H. discriminate H. Qed.

Lemma refa357_not4588 : ~ @Equation4588 Fin4 refa357_inst.
Proof. unfold Equation4588. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa357_inst, refa357_op in H. discriminate H. Qed.

Lemma refa357_not4590 : ~ @Equation4590 Fin4 refa357_inst.
Proof. unfold Equation4590. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa357_inst, refa357_op in H. discriminate H. Qed.

Lemma refa357_not4599 : ~ @Equation4599 Fin4 refa357_inst.
Proof. unfold Equation4599. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa357_inst, refa357_op in H. discriminate H. Qed.

Lemma refa357_not4605 : ~ @Equation4605 Fin4 refa357_inst.
Proof. unfold Equation4605. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa357_inst, refa357_op in H. discriminate H. Qed.

Lemma refa357_not4606 : ~ @Equation4606 Fin4 refa357_inst.
Proof. unfold Equation4606. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa357_inst, refa357_op in H. discriminate H. Qed.

Lemma refa357_not4635 : ~ @Equation4635 Fin4 refa357_inst.
Proof. unfold Equation4635. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa357_inst, refa357_op in H. discriminate H. Qed.

(** ---- refa358 (Fin4) ---- *)

Definition refa358_op (x y : Fin4) : Fin4 :=
  match x, y with
  | F4_0, F4_0 => F4_2 | F4_0, F4_1 => F4_3 | F4_0, F4_2 => F4_0 | F4_0, F4_3 => F4_1
  | F4_1, F4_0 => F4_3 | F4_1, F4_1 => F4_2 | F4_1, F4_2 => F4_1 | F4_1, F4_3 => F4_0
  | F4_2, F4_0 => F4_0 | F4_2, F4_1 => F4_1 | F4_2, F4_2 => F4_3 | F4_2, F4_3 => F4_2
  | F4_3, F4_0 => F4_1 | F4_3, F4_1 => F4_0 | F4_3, F4_2 => F4_3 | F4_3, F4_3 => F4_2
  end.

#[local] Instance refa358_inst : Magma Fin4 := {| magma_op := refa358_op |}.

Lemma refa358_sat1312 : @Equation1312 Fin4 refa358_inst.
Proof. unfold Equation1312, magma_op, refa358_inst, refa358_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa358_not4118 : ~ @Equation4118 Fin4 refa358_inst.
Proof. unfold Equation4118. intro H. specialize (H F4_2 F4_0). unfold magma_op, refa358_inst, refa358_op in H. discriminate H. Qed.

(** ---- refa359 (Fin4) ---- *)

Definition refa359_op (x y : Fin4) : Fin4 :=
  match x, y with
  | F4_0, F4_0 => F4_2 | F4_0, F4_1 => F4_0 | F4_0, F4_2 => F4_0 | F4_0, F4_3 => F4_1
  | F4_1, F4_0 => F4_2 | F4_1, F4_1 => F4_2 | F4_1, F4_2 => F4_1 | F4_1, F4_3 => F4_1
  | F4_2, F4_0 => F4_2 | F4_2, F4_1 => F4_2 | F4_2, F4_2 => F4_2 | F4_2, F4_3 => F4_2
  | F4_3, F4_0 => F4_0 | F4_3, F4_1 => F4_2 | F4_3, F4_2 => F4_3 | F4_3, F4_3 => F4_2
  end.

#[local] Instance refa359_inst : Magma Fin4 := {| magma_op := refa359_op |}.

Lemma refa359_sat1060 : @Equation1060 Fin4 refa359_inst.
Proof. unfold Equation1060, magma_op, refa359_inst, refa359_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa359_sat1243 : @Equation1243 Fin4 refa359_inst.
Proof. unfold Equation1243, magma_op, refa359_inst, refa359_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa359_sat1245 : @Equation1245 Fin4 refa359_inst.
Proof. unfold Equation1245, magma_op, refa359_inst, refa359_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa359_not1228 : ~ @Equation1228 Fin4 refa359_inst.
Proof. unfold Equation1228. intro H. specialize (H F4_3 F4_0). unfold magma_op, refa359_inst, refa359_op in H. discriminate H. Qed.

(** ---- refa36 (Fin11) ---- *)

Definition refa36_op (x y : Fin11) : Fin11 :=
  match x, y with
  | F11_0, F11_0 => F11_2 | F11_0, F11_1 => F11_1 | F11_0, F11_2 => F11_2 | F11_0, F11_3 => F11_2 | F11_0, F11_4 => F11_4 | F11_0, F11_5 => F11_2 | F11_0, F11_6 => F11_6 | F11_0, F11_7 => F11_4 | F11_0, F11_8 => F11_8 | F11_0, F11_9 => F11_2 | F11_0, F11_10 => F11_2
  | F11_1, F11_0 => F11_3 | F11_1, F11_1 => F11_5 | F11_1, F11_2 => F11_9 | F11_1, F11_3 => F11_3 | F11_1, F11_4 => F11_5 | F11_1, F11_5 => F11_5 | F11_1, F11_6 => F11_5 | F11_1, F11_7 => F11_3 | F11_1, F11_8 => F11_9 | F11_1, F11_9 => F11_9 | F11_1, F11_10 => F11_9
  | F11_2, F11_0 => F11_0 | F11_2, F11_1 => F11_6 | F11_2, F11_2 => F11_6 | F11_2, F11_3 => F11_3 | F11_2, F11_4 => F11_4 | F11_2, F11_5 => F11_5 | F11_2, F11_6 => F11_6 | F11_2, F11_7 => F11_7 | F11_2, F11_8 => F11_6 | F11_2, F11_9 => F11_9 | F11_2, F11_10 => F11_9
  | F11_3, F11_0 => F11_4 | F11_3, F11_1 => F11_1 | F11_3, F11_2 => F11_2 | F11_3, F11_3 => F11_2 | F11_3, F11_4 => F11_4 | F11_3, F11_5 => F11_2 | F11_3, F11_6 => F11_6 | F11_3, F11_7 => F11_4 | F11_3, F11_8 => F11_8 | F11_3, F11_9 => F11_2 | F11_3, F11_10 => F11_2
  | F11_4, F11_0 => F11_0 | F11_4, F11_1 => F11_8 | F11_4, F11_2 => F11_2 | F11_4, F11_3 => F11_3 | F11_4, F11_4 => F11_8 | F11_4, F11_5 => F11_5 | F11_4, F11_6 => F11_8 | F11_4, F11_7 => F11_5 | F11_4, F11_8 => F11_8 | F11_4, F11_9 => F11_9 | F11_4, F11_10 => F11_10
  | F11_5, F11_0 => F11_10 | F11_5, F11_1 => F11_1 | F11_5, F11_2 => F11_2 | F11_5, F11_3 => F11_9 | F11_5, F11_4 => F11_4 | F11_5, F11_5 => F11_9 | F11_5, F11_6 => F11_6 | F11_5, F11_7 => F11_4 | F11_5, F11_8 => F11_8 | F11_5, F11_9 => F11_9 | F11_5, F11_10 => F11_10
  | F11_6, F11_0 => F11_0 | F11_6, F11_1 => F11_8 | F11_6, F11_2 => F11_2 | F11_6, F11_3 => F11_3 | F11_6, F11_4 => F11_5 | F11_6, F11_5 => F11_5 | F11_6, F11_6 => F11_5 | F11_6, F11_7 => F11_5 | F11_6, F11_8 => F11_8 | F11_6, F11_9 => F11_9 | F11_6, F11_10 => F11_10
  | F11_7, F11_0 => F11_10 | F11_7, F11_1 => F11_8 | F11_7, F11_2 => F11_2 | F11_7, F11_3 => F11_9 | F11_7, F11_4 => F11_8 | F11_7, F11_5 => F11_2 | F11_7, F11_6 => F11_8 | F11_7, F11_7 => F11_8 | F11_7, F11_8 => F11_8 | F11_7, F11_9 => F11_9 | F11_7, F11_10 => F11_10
  | F11_8, F11_0 => F11_0 | F11_8, F11_1 => F11_6 | F11_8, F11_2 => F11_9 | F11_8, F11_3 => F11_3 | F11_8, F11_4 => F11_4 | F11_8, F11_5 => F11_5 | F11_8, F11_6 => F11_6 | F11_8, F11_7 => F11_7 | F11_8, F11_8 => F11_9 | F11_8, F11_9 => F11_9 | F11_8, F11_10 => F11_9
  | F11_9, F11_0 => F11_7 | F11_9, F11_1 => F11_1 | F11_9, F11_2 => F11_2 | F11_9, F11_3 => F11_7 | F11_9, F11_4 => F11_4 | F11_9, F11_5 => F11_5 | F11_9, F11_6 => F11_6 | F11_9, F11_7 => F11_7 | F11_9, F11_8 => F11_8 | F11_9, F11_9 => F11_4 | F11_9, F11_10 => F11_2
  | F11_10, F11_0 => F11_7 | F11_10, F11_1 => F11_6 | F11_10, F11_2 => F11_6 | F11_10, F11_3 => F11_7 | F11_10, F11_4 => F11_4 | F11_10, F11_5 => F11_5 | F11_10, F11_6 => F11_6 | F11_10, F11_7 => F11_7 | F11_10, F11_8 => F11_6 | F11_10, F11_9 => F11_4 | F11_10, F11_10 => F11_6
  end.

#[local] Instance refa36_inst : Magma Fin11 := {| magma_op := refa36_op |}.

Lemma refa36_sat2712 : @Equation2712 Fin11 refa36_inst.
Proof. unfold Equation2712, magma_op, refa36_inst, refa36_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa36_not221 : ~ @Equation221 Fin11 refa36_inst.
Proof. unfold Equation221. intro H. specialize (H F11_0 F11_1). unfold magma_op, refa36_inst, refa36_op in H. discriminate H. Qed.

Lemma refa36_not231 : ~ @Equation231 Fin11 refa36_inst.
Proof. unfold Equation231. intro H. specialize (H F11_0 F11_1). unfold magma_op, refa36_inst, refa36_op in H. discriminate H. Qed.

Lemma refa36_not1631 : ~ @Equation1631 Fin11 refa36_inst.
Proof. unfold Equation1631. intro H. specialize (H F11_0 F11_1). unfold magma_op, refa36_inst, refa36_op in H. discriminate H. Qed.

Lemma refa36_not1637 : ~ @Equation1637 Fin11 refa36_inst.
Proof. unfold Equation1637. intro H. specialize (H F11_0 F11_1). unfold magma_op, refa36_inst, refa36_op in H. discriminate H. Qed.

Lemma refa36_not1644 : ~ @Equation1644 Fin11 refa36_inst.
Proof. unfold Equation1644. intro H. specialize (H F11_0 F11_1). unfold magma_op, refa36_inst, refa36_op in H. discriminate H. Qed.

Lemma refa36_not1647 : ~ @Equation1647 Fin11 refa36_inst.
Proof. unfold Equation1647. intro H. specialize (H F11_0 F11_1). unfold magma_op, refa36_inst, refa36_op in H. discriminate H. Qed.

Lemma refa36_not1657 : ~ @Equation1657 Fin11 refa36_inst.
Proof. unfold Equation1657. intro H. specialize (H F11_0 F11_1). unfold magma_op, refa36_inst, refa36_op in H. discriminate H. Qed.

Lemma refa36_not1721 : ~ @Equation1721 Fin11 refa36_inst.
Proof. unfold Equation1721. intro H. specialize (H F11_0 F11_1). unfold magma_op, refa36_inst, refa36_op in H. discriminate H. Qed.

Lemma refa36_not1731 : ~ @Equation1731 Fin11 refa36_inst.
Proof. unfold Equation1731. intro H. specialize (H F11_0 F11_1). unfold magma_op, refa36_inst, refa36_op in H. discriminate H. Qed.

Lemma refa36_not2240 : ~ @Equation2240 Fin11 refa36_inst.
Proof. unfold Equation2240. intro H. specialize (H F11_0 F11_1). unfold magma_op, refa36_inst, refa36_op in H. discriminate H. Qed.

Lemma refa36_not2290 : ~ @Equation2290 Fin11 refa36_inst.
Proof. unfold Equation2290. intro H. specialize (H F11_0 F11_1). unfold magma_op, refa36_inst, refa36_op in H. discriminate H. Qed.

Lemma refa36_not2293 : ~ @Equation2293 Fin11 refa36_inst.
Proof. unfold Equation2293. intro H. specialize (H F11_0 F11_1). unfold magma_op, refa36_inst, refa36_op in H. discriminate H. Qed.

Lemma refa36_not2300 : ~ @Equation2300 Fin11 refa36_inst.
Proof. unfold Equation2300. intro H. specialize (H F11_0 F11_1). unfold magma_op, refa36_inst, refa36_op in H. discriminate H. Qed.

Lemma refa36_not2303 : ~ @Equation2303 Fin11 refa36_inst.
Proof. unfold Equation2303. intro H. specialize (H F11_0 F11_1). unfold magma_op, refa36_inst, refa36_op in H. discriminate H. Qed.

Lemma refa36_not2327 : ~ @Equation2327 Fin11 refa36_inst.
Proof. unfold Equation2327. intro H. specialize (H F11_0 F11_1). unfold magma_op, refa36_inst, refa36_op in H. discriminate H. Qed.

Lemma refa36_not2330 : ~ @Equation2330 Fin11 refa36_inst.
Proof. unfold Equation2330. intro H. specialize (H F11_0 F11_1). unfold magma_op, refa36_inst, refa36_op in H. discriminate H. Qed.

Lemma refa36_not2340 : ~ @Equation2340 Fin11 refa36_inst.
Proof. unfold Equation2340. intro H. specialize (H F11_0 F11_1). unfold magma_op, refa36_inst, refa36_op in H. discriminate H. Qed.

Lemma refa36_not2459 : ~ @Equation2459 Fin11 refa36_inst.
Proof. unfold Equation2459. intro H. specialize (H F11_0 F11_1). unfold magma_op, refa36_inst, refa36_op in H. discriminate H. Qed.

Lemma refa36_not2469 : ~ @Equation2469 Fin11 refa36_inst.
Proof. unfold Equation2469. intro H. specialize (H F11_0 F11_1). unfold magma_op, refa36_inst, refa36_op in H. discriminate H. Qed.

Lemma refa36_not2496 : ~ @Equation2496 Fin11 refa36_inst.
Proof. unfold Equation2496. intro H. specialize (H F11_0 F11_1). unfold magma_op, refa36_inst, refa36_op in H. discriminate H. Qed.

Lemma refa36_not2506 : ~ @Equation2506 Fin11 refa36_inst.
Proof. unfold Equation2506. intro H. specialize (H F11_0 F11_1). unfold magma_op, refa36_inst, refa36_op in H. discriminate H. Qed.

Lemma refa36_not2530 : ~ @Equation2530 Fin11 refa36_inst.
Proof. unfold Equation2530. intro H. specialize (H F11_0 F11_1). unfold magma_op, refa36_inst, refa36_op in H. discriminate H. Qed.

Lemma refa36_not2533 : ~ @Equation2533 Fin11 refa36_inst.
Proof. unfold Equation2533. intro H. specialize (H F11_0 F11_1). unfold magma_op, refa36_inst, refa36_op in H. discriminate H. Qed.

Lemma refa36_not2543 : ~ @Equation2543 Fin11 refa36_inst.
Proof. unfold Equation2543. intro H. specialize (H F11_0 F11_1). unfold magma_op, refa36_inst, refa36_op in H. discriminate H. Qed.

Lemma refa36_not2652 : ~ @Equation2652 Fin11 refa36_inst.
Proof. unfold Equation2652. intro H. specialize (H F11_0 F11_1). unfold magma_op, refa36_inst, refa36_op in H. discriminate H. Qed.

Lemma refa36_not2659 : ~ @Equation2659 Fin11 refa36_inst.
Proof. unfold Equation2659. intro H. specialize (H F11_0 F11_1). unfold magma_op, refa36_inst, refa36_op in H. discriminate H. Qed.

Lemma refa36_not2662 : ~ @Equation2662 Fin11 refa36_inst.
Proof. unfold Equation2662. intro H. specialize (H F11_0 F11_1). unfold magma_op, refa36_inst, refa36_op in H. discriminate H. Qed.

Lemma refa36_not2672 : ~ @Equation2672 Fin11 refa36_inst.
Proof. unfold Equation2672. intro H. specialize (H F11_0 F11_1). unfold magma_op, refa36_inst, refa36_op in H. discriminate H. Qed.

Lemma refa36_not2699 : ~ @Equation2699 Fin11 refa36_inst.
Proof. unfold Equation2699. intro H. specialize (H F11_0 F11_1). unfold magma_op, refa36_inst, refa36_op in H. discriminate H. Qed.

Lemma refa36_not2733 : ~ @Equation2733 Fin11 refa36_inst.
Proof. unfold Equation2733. intro H. specialize (H F11_0 F11_4). unfold magma_op, refa36_inst, refa36_op in H. discriminate H. Qed.

Lemma refa36_not2736 : ~ @Equation2736 Fin11 refa36_inst.
Proof. unfold Equation2736. intro H. specialize (H F11_0 F11_1). unfold magma_op, refa36_inst, refa36_op in H. discriminate H. Qed.

Lemma refa36_not2746 : ~ @Equation2746 Fin11 refa36_inst.
Proof. unfold Equation2746. intro H. specialize (H F11_0 F11_1). unfold magma_op, refa36_inst, refa36_op in H. discriminate H. Qed.

Lemma refa36_not3052 : ~ @Equation3052 Fin11 refa36_inst.
Proof. unfold Equation3052. intro H. specialize (H F11_0 F11_1). unfold magma_op, refa36_inst, refa36_op in H. discriminate H. Qed.

Lemma refa36_not3058 : ~ @Equation3058 Fin11 refa36_inst.
Proof. unfold Equation3058. intro H. specialize (H F11_0 F11_5). unfold magma_op, refa36_inst, refa36_op in H. discriminate H. Qed.

Lemma refa36_not3068 : ~ @Equation3068 Fin11 refa36_inst.
Proof. unfold Equation3068. intro H. specialize (H F11_0 F11_1). unfold magma_op, refa36_inst, refa36_op in H. discriminate H. Qed.

Lemma refa36_not3078 : ~ @Equation3078 Fin11 refa36_inst.
Proof. unfold Equation3078. intro H. specialize (H F11_0 F11_1). unfold magma_op, refa36_inst, refa36_op in H. discriminate H. Qed.

Lemma refa36_not3105 : ~ @Equation3105 Fin11 refa36_inst.
Proof. unfold Equation3105. intro H. specialize (H F11_1 F11_0). unfold magma_op, refa36_inst, refa36_op in H. discriminate H. Qed.

Lemma refa36_not3115 : ~ @Equation3115 Fin11 refa36_inst.
Proof. unfold Equation3115. intro H. specialize (H F11_0 F11_1). unfold magma_op, refa36_inst, refa36_op in H. discriminate H. Qed.

Lemma refa36_not3152 : ~ @Equation3152 Fin11 refa36_inst.
Proof. unfold Equation3152. intro H. specialize (H F11_0 F11_1). unfold magma_op, refa36_inst, refa36_op in H. discriminate H. Qed.

Lemma refa36_not3255 : ~ @Equation3255 Fin11 refa36_inst.
Proof. unfold Equation3255. intro H. specialize (H F11_0 F11_3). unfold magma_op, refa36_inst, refa36_op in H. discriminate H. Qed.

Lemma refa36_not3258 : ~ @Equation3258 Fin11 refa36_inst.
Proof. unfold Equation3258. intro H. specialize (H F11_0 F11_2). unfold magma_op, refa36_inst, refa36_op in H. discriminate H. Qed.

Lemma refa36_not3261 : ~ @Equation3261 Fin11 refa36_inst.
Proof. unfold Equation3261. intro H. specialize (H F11_0 F11_3). unfold magma_op, refa36_inst, refa36_op in H. discriminate H. Qed.

Lemma refa36_not3268 : ~ @Equation3268 Fin11 refa36_inst.
Proof. unfold Equation3268. intro H. specialize (H F11_0 F11_1). unfold magma_op, refa36_inst, refa36_op in H. discriminate H. Qed.

Lemma refa36_not3271 : ~ @Equation3271 Fin11 refa36_inst.
Proof. unfold Equation3271. intro H. specialize (H F11_0 F11_1). unfold magma_op, refa36_inst, refa36_op in H. discriminate H. Qed.

Lemma refa36_not3278 : ~ @Equation3278 Fin11 refa36_inst.
Proof. unfold Equation3278. intro H. specialize (H F11_0 F11_1). unfold magma_op, refa36_inst, refa36_op in H. discriminate H. Qed.

Lemma refa36_not3461 : ~ @Equation3461 Fin11 refa36_inst.
Proof. unfold Equation3461. intro H. specialize (H F11_0 F11_1). unfold magma_op, refa36_inst, refa36_op in H. discriminate H. Qed.

Lemma refa36_not3464 : ~ @Equation3464 Fin11 refa36_inst.
Proof. unfold Equation3464. intro H. specialize (H F11_0 F11_5). unfold magma_op, refa36_inst, refa36_op in H. discriminate H. Qed.

Lemma refa36_not3481 : ~ @Equation3481 Fin11 refa36_inst.
Proof. unfold Equation3481. intro H. specialize (H F11_0 F11_1). unfold magma_op, refa36_inst, refa36_op in H. discriminate H. Qed.

Lemma refa36_not3509 : ~ @Equation3509 Fin11 refa36_inst.
Proof. unfold Equation3509. intro H. specialize (H F11_0 F11_1). unfold magma_op, refa36_inst, refa36_op in H. discriminate H. Qed.

Lemma refa36_not3525 : ~ @Equation3525 Fin11 refa36_inst.
Proof. unfold Equation3525. intro H. specialize (H F11_2 F11_0 F11_1). unfold magma_op, refa36_inst, refa36_op in H. discriminate H. Qed.

Lemma refa36_not3659 : ~ @Equation3659 Fin11 refa36_inst.
Proof. unfold Equation3659. intro H. specialize (H F11_0). unfold magma_op, refa36_inst, refa36_op in H. discriminate H. Qed.

Lemma refa36_not4070 : ~ @Equation4070 Fin11 refa36_inst.
Proof. unfold Equation4070. intro H. specialize (H F11_0 F11_1). unfold magma_op, refa36_inst, refa36_op in H. discriminate H. Qed.

Lemma refa36_not4090 : ~ @Equation4090 Fin11 refa36_inst.
Proof. unfold Equation4090. intro H. specialize (H F11_0 F11_1). unfold magma_op, refa36_inst, refa36_op in H. discriminate H. Qed.

Lemma refa36_not4131 : ~ @Equation4131 Fin11 refa36_inst.
Proof. unfold Equation4131. intro H. specialize (H F11_0 F11_5). unfold magma_op, refa36_inst, refa36_op in H. discriminate H. Qed.

Lemma refa36_not4155 : ~ @Equation4155 Fin11 refa36_inst.
Proof. unfold Equation4155. intro H. specialize (H F11_0 F11_1). unfold magma_op, refa36_inst, refa36_op in H. discriminate H. Qed.

Lemma refa36_not4165 : ~ @Equation4165 Fin11 refa36_inst.
Proof. unfold Equation4165. intro H. specialize (H F11_0 F11_1). unfold magma_op, refa36_inst, refa36_op in H. discriminate H. Qed.

Lemma refa36_not4269 : ~ @Equation4269 Fin11 refa36_inst.
Proof. unfold Equation4269. intro H. specialize (H F11_0 F11_3). unfold magma_op, refa36_inst, refa36_op in H. discriminate H. Qed.

Lemma refa36_not4272 : ~ @Equation4272 Fin11 refa36_inst.
Proof. unfold Equation4272. intro H. specialize (H F11_0 F11_1). unfold magma_op, refa36_inst, refa36_op in H. discriminate H. Qed.

Lemma refa36_not4320 : ~ @Equation4320 Fin11 refa36_inst.
Proof. unfold Equation4320. intro H. specialize (H F11_0 F11_1). unfold magma_op, refa36_inst, refa36_op in H. discriminate H. Qed.

Lemma refa36_not4606 : ~ @Equation4606 Fin11 refa36_inst.
Proof. unfold Equation4606. intro H. specialize (H F11_0 F11_1). unfold magma_op, refa36_inst, refa36_op in H. discriminate H. Qed.

Lemma refa36_not4622 : ~ @Equation4622 Fin11 refa36_inst.
Proof. unfold Equation4622. intro H. specialize (H F11_0 F11_0 F11_1). unfold magma_op, refa36_inst, refa36_op in H. discriminate H. Qed.

Lemma refa36_not4631 : ~ @Equation4631 Fin11 refa36_inst.
Proof. unfold Equation4631. intro H. specialize (H F11_0 F11_0 F11_1). unfold magma_op, refa36_inst, refa36_op in H. discriminate H. Qed.

(** ---- refa360 (Fin4) ---- *)

Definition refa360_op (x y : Fin4) : Fin4 :=
  match x, y with
  | F4_0, F4_0 => F4_2 | F4_0, F4_1 => F4_1 | F4_0, F4_2 => F4_3 | F4_0, F4_3 => F4_1
  | F4_1, F4_0 => F4_3 | F4_1, F4_1 => F4_1 | F4_1, F4_2 => F4_2 | F4_1, F4_3 => F4_3
  | F4_2, F4_0 => F4_0 | F4_2, F4_1 => F4_1 | F4_2, F4_2 => F4_3 | F4_2, F4_3 => F4_1
  | F4_3, F4_0 => F4_0 | F4_3, F4_1 => F4_1 | F4_3, F4_2 => F4_2 | F4_3, F4_3 => F4_1
  end.

#[local] Instance refa360_inst : Magma Fin4 := {| magma_op := refa360_op |}.

Lemma refa360_sat2770 : @Equation2770 Fin4 refa360_inst.
Proof. unfold Equation2770, magma_op, refa360_inst, refa360_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa360_not2238 : ~ @Equation2238 Fin4 refa360_inst.
Proof. unfold Equation2238. intro H. specialize (H F4_0). unfold magma_op, refa360_inst, refa360_op in H. discriminate H. Qed.

Lemma refa360_not2466 : ~ @Equation2466 Fin4 refa360_inst.
Proof. unfold Equation2466. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa360_inst, refa360_op in H. discriminate H. Qed.

Lemma refa360_not3509 : ~ @Equation3509 Fin4 refa360_inst.
Proof. unfold Equation3509. intro H. specialize (H F4_0 F4_2). unfold magma_op, refa360_inst, refa360_op in H. discriminate H. Qed.

(** ---- refa361 (Fin4) ---- *)

Definition refa361_op (x y : Fin4) : Fin4 :=
  match x, y with
  | F4_0, F4_0 => F4_2 | F4_0, F4_1 => F4_0 | F4_0, F4_2 => F4_3 | F4_0, F4_3 => F4_1
  | F4_1, F4_0 => F4_2 | F4_1, F4_1 => F4_3 | F4_1, F4_2 => F4_0 | F4_1, F4_3 => F4_2
  | F4_2, F4_0 => F4_0 | F4_2, F4_1 => F4_1 | F4_2, F4_2 => F4_2 | F4_2, F4_3 => F4_3
  | F4_3, F4_0 => F4_0 | F4_3, F4_1 => F4_1 | F4_3, F4_2 => F4_2 | F4_3, F4_3 => F4_3
  end.

#[local] Instance refa361_inst : Magma Fin4 := {| magma_op := refa361_op |}.

Lemma refa361_sat2588 : @Equation2588 Fin4 refa361_inst.
Proof. unfold Equation2588, magma_op, refa361_inst, refa361_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa361_not2672 : ~ @Equation2672 Fin4 refa361_inst.
Proof. unfold Equation2672. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa361_inst, refa361_op in H. discriminate H. Qed.

Lemma refa361_not2696 : ~ @Equation2696 Fin4 refa361_inst.
Proof. unfold Equation2696. intro H. specialize (H F4_1 F4_0). unfold magma_op, refa361_inst, refa361_op in H. discriminate H. Qed.

(** ---- refa362 (Fin4) ---- *)

Definition refa362_op (x y : Fin4) : Fin4 :=
  match x, y with
  | F4_0, F4_0 => F4_3 | F4_0, F4_1 => F4_3 | F4_0, F4_2 => F4_1 | F4_0, F4_3 => F4_3
  | F4_1, F4_0 => F4_3 | F4_1, F4_1 => F4_3 | F4_1, F4_2 => F4_3 | F4_1, F4_3 => F4_2
  | F4_2, F4_0 => F4_0 | F4_2, F4_1 => F4_0 | F4_2, F4_2 => F4_3 | F4_2, F4_3 => F4_3
  | F4_3, F4_0 => F4_3 | F4_3, F4_1 => F4_3 | F4_3, F4_2 => F4_3 | F4_3, F4_3 => F4_3
  end.

#[local] Instance refa362_inst : Magma Fin4 := {| magma_op := refa362_op |}.

Lemma refa362_sat372 : @Equation372 Fin4 refa362_inst.
Proof. unfold Equation372, magma_op, refa362_inst, refa362_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa362_sat4114 : @Equation4114 Fin4 refa362_inst.
Proof. unfold Equation4114, magma_op, refa362_inst, refa362_op. intros x y z w. destruct x, y, z, w; reflexivity. Qed.

Lemma refa362_not3862 : ~ @Equation3862 Fin4 refa362_inst.
Proof. unfold Equation3862. intro H. specialize (H F4_1). unfold magma_op, refa362_inst, refa362_op in H. discriminate H. Qed.

Lemma refa362_not4076 : ~ @Equation4076 Fin4 refa362_inst.
Proof. unfold Equation4076. intro H. specialize (H F4_0 F4_2 F4_3). unfold magma_op, refa362_inst, refa362_op in H. discriminate H. Qed.

Lemma refa362_not4104 : ~ @Equation4104 Fin4 refa362_inst.
Proof. unfold Equation4104. intro H. specialize (H F4_2 F4_1 F4_3). unfold magma_op, refa362_inst, refa362_op in H. discriminate H. Qed.

Lemma refa362_not4272 : ~ @Equation4272 Fin4 refa362_inst.
Proof. unfold Equation4272. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa362_inst, refa362_op in H. discriminate H. Qed.

Lemma refa362_not4316 : ~ @Equation4316 Fin4 refa362_inst.
Proof. unfold Equation4316. intro H. specialize (H F4_1 F4_0 F4_2). unfold magma_op, refa362_inst, refa362_op in H. discriminate H. Qed.

Lemma refa362_not4320 : ~ @Equation4320 Fin4 refa362_inst.
Proof. unfold Equation4320. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa362_inst, refa362_op in H. discriminate H. Qed.

Lemma refa362_not4615 : ~ @Equation4615 Fin4 refa362_inst.
Proof. unfold Equation4615. intro H. specialize (H F4_0 F4_2 F4_2). unfold magma_op, refa362_inst, refa362_op in H. discriminate H. Qed.

Lemma refa362_not4635 : ~ @Equation4635 Fin4 refa362_inst.
Proof. unfold Equation4635. intro H. specialize (H F4_1 F4_3). unfold magma_op, refa362_inst, refa362_op in H. discriminate H. Qed.

(** ---- refa363 (Fin4) ---- *)

Definition refa363_op (x y : Fin4) : Fin4 :=
  match x, y with
  | F4_0, F4_0 => F4_3 | F4_0, F4_1 => F4_0 | F4_0, F4_2 => F4_1 | F4_0, F4_3 => F4_3
  | F4_1, F4_0 => F4_3 | F4_1, F4_1 => F4_3 | F4_1, F4_2 => F4_3 | F4_1, F4_3 => F4_2
  | F4_2, F4_0 => F4_1 | F4_2, F4_1 => F4_0 | F4_2, F4_2 => F4_3 | F4_2, F4_3 => F4_3
  | F4_3, F4_0 => F4_3 | F4_3, F4_1 => F4_0 | F4_3, F4_2 => F4_3 | F4_3, F4_3 => F4_3
  end.

#[local] Instance refa363_inst : Magma Fin4 := {| magma_op := refa363_op |}.

Lemma refa363_sat3496 : @Equation3496 Fin4 refa363_inst.
Proof. unfold Equation3496, magma_op, refa363_inst, refa363_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa363_not3664 : ~ @Equation3664 Fin4 refa363_inst.
Proof. unfold Equation3664. intro H. specialize (H F4_0 F4_2). unfold magma_op, refa363_inst, refa363_op in H. discriminate H. Qed.

Lemma refa363_not3668 : ~ @Equation3668 Fin4 refa363_inst.
Proof. unfold Equation3668. intro H. specialize (H F4_0 F4_2). unfold magma_op, refa363_inst, refa363_op in H. discriminate H. Qed.

Lemma refa363_not3674 : ~ @Equation3674 Fin4 refa363_inst.
Proof. unfold Equation3674. intro H. specialize (H F4_0 F4_2). unfold magma_op, refa363_inst, refa363_op in H. discriminate H. Qed.

Lemma refa363_not3678 : ~ @Equation3678 Fin4 refa363_inst.
Proof. unfold Equation3678. intro H. specialize (H F4_0 F4_2). unfold magma_op, refa363_inst, refa363_op in H. discriminate H. Qed.

(** ---- refa364 (Fin4) ---- *)

Definition refa364_op (x y : Fin4) : Fin4 :=
  match x, y with
  | F4_0, F4_0 => F4_0 | F4_0, F4_1 => F4_2 | F4_0, F4_2 => F4_0 | F4_0, F4_3 => F4_1
  | F4_1, F4_0 => F4_3 | F4_1, F4_1 => F4_2 | F4_1, F4_2 => F4_1 | F4_1, F4_3 => F4_1
  | F4_2, F4_0 => F4_2 | F4_2, F4_1 => F4_2 | F4_2, F4_2 => F4_2 | F4_2, F4_3 => F4_2
  | F4_3, F4_0 => F4_2 | F4_3, F4_1 => F4_2 | F4_3, F4_2 => F4_3 | F4_3, F4_3 => F4_3
  end.

#[local] Instance refa364_inst : Magma Fin4 := {| magma_op := refa364_op |}.

Lemma refa364_sat1259 : @Equation1259 Fin4 refa364_inst.
Proof. unfold Equation1259, magma_op, refa364_inst, refa364_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa364_not1225 : ~ @Equation1225 Fin4 refa364_inst.
Proof. unfold Equation1225. intro H. specialize (H F4_0 F4_3). unfold magma_op, refa364_inst, refa364_op in H. discriminate H. Qed.

Lemma refa364_not1248 : ~ @Equation1248 Fin4 refa364_inst.
Proof. unfold Equation1248. intro H. specialize (H F4_3 F4_0). unfold magma_op, refa364_inst, refa364_op in H. discriminate H. Qed.

(** ---- refa365 (Fin4) ---- *)

Definition refa365_op (x y : Fin4) : Fin4 :=
  match x, y with
  | F4_0, F4_0 => F4_1 | F4_0, F4_1 => F4_0 | F4_0, F4_2 => F4_0 | F4_0, F4_3 => F4_1
  | F4_1, F4_0 => F4_1 | F4_1, F4_1 => F4_1 | F4_1, F4_2 => F4_1 | F4_1, F4_3 => F4_1
  | F4_2, F4_0 => F4_2 | F4_2, F4_1 => F4_2 | F4_2, F4_2 => F4_1 | F4_2, F4_3 => F4_0
  | F4_3, F4_0 => F4_3 | F4_3, F4_1 => F4_3 | F4_3, F4_2 => F4_2 | F4_3, F4_3 => F4_2
  end.

#[local] Instance refa365_inst : Magma Fin4 := {| magma_op := refa365_op |}.

Lemma refa365_sat837 : @Equation837 Fin4 refa365_inst.
Proof. unfold Equation837, magma_op, refa365_inst, refa365_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa365_sat1051 : @Equation1051 Fin4 refa365_inst.
Proof. unfold Equation1051, magma_op, refa365_inst, refa365_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa365_not108 : ~ @Equation108 Fin4 refa365_inst.
Proof. unfold Equation108. intro H. specialize (H F4_0 F4_3). unfold magma_op, refa365_inst, refa365_op in H. discriminate H. Qed.

Lemma refa365_not845 : ~ @Equation845 Fin4 refa365_inst.
Proof. unfold Equation845. intro H. specialize (H F4_0 F4_3). unfold magma_op, refa365_inst, refa365_op in H. discriminate H. Qed.

Lemma refa365_not1238 : ~ @Equation1238 Fin4 refa365_inst.
Proof. unfold Equation1238. intro H. specialize (H F4_0 F4_3). unfold magma_op, refa365_inst, refa365_op in H. discriminate H. Qed.

Lemma refa365_not1242 : ~ @Equation1242 Fin4 refa365_inst.
Proof. unfold Equation1242. intro H. specialize (H F4_0 F4_3). unfold magma_op, refa365_inst, refa365_op in H. discriminate H. Qed.

Lemma refa365_not1249 : ~ @Equation1249 Fin4 refa365_inst.
Proof. unfold Equation1249. intro H. specialize (H F4_0 F4_3). unfold magma_op, refa365_inst, refa365_op in H. discriminate H. Qed.

Lemma refa365_not3319 : ~ @Equation3319 Fin4 refa365_inst.
Proof. unfold Equation3319. intro H. specialize (H F4_0 F4_3). unfold magma_op, refa365_inst, refa365_op in H. discriminate H. Qed.

Lemma refa365_not4598 : ~ @Equation4598 Fin4 refa365_inst.
Proof. unfold Equation4598. intro H. specialize (H F4_2 F4_3). unfold magma_op, refa365_inst, refa365_op in H. discriminate H. Qed.

(** ---- refa366 (Fin4) ---- *)

Definition refa366_op (x y : Fin4) : Fin4 :=
  match x, y with
  | F4_0, F4_0 => F4_2 | F4_0, F4_1 => F4_0 | F4_0, F4_2 => F4_2 | F4_0, F4_3 => F4_3
  | F4_1, F4_0 => F4_3 | F4_1, F4_1 => F4_0 | F4_1, F4_2 => F4_3 | F4_1, F4_3 => F4_2
  | F4_2, F4_0 => F4_0 | F4_2, F4_1 => F4_1 | F4_2, F4_2 => F4_2 | F4_2, F4_3 => F4_3
  | F4_3, F4_0 => F4_0 | F4_3, F4_1 => F4_1 | F4_3, F4_2 => F4_2 | F4_3, F4_3 => F4_2
  end.

#[local] Instance refa366_inst : Magma Fin4 := {| magma_op := refa366_op |}.

Lemma refa366_sat2484 : @Equation2484 Fin4 refa366_inst.
Proof. unfold Equation2484, magma_op, refa366_inst, refa366_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa366_sat2778 : @Equation2778 Fin4 refa366_inst.
Proof. unfold Equation2778, magma_op, refa366_inst, refa366_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa366_not231 : ~ @Equation231 Fin4 refa366_inst.
Proof. unfold Equation231. intro H. specialize (H F4_3 F4_1). unfold magma_op, refa366_inst, refa366_op in H. discriminate H. Qed.

Lemma refa366_not2240 : ~ @Equation2240 Fin4 refa366_inst.
Proof. unfold Equation2240. intro H. specialize (H F4_2 F4_1). unfold magma_op, refa366_inst, refa366_op in H. discriminate H. Qed.

Lemma refa366_not2290 : ~ @Equation2290 Fin4 refa366_inst.
Proof. unfold Equation2290. intro H. specialize (H F4_3 F4_1). unfold magma_op, refa366_inst, refa366_op in H. discriminate H. Qed.

Lemma refa366_not2303 : ~ @Equation2303 Fin4 refa366_inst.
Proof. unfold Equation2303. intro H. specialize (H F4_3 F4_1). unfold magma_op, refa366_inst, refa366_op in H. discriminate H. Qed.

Lemma refa366_not2330 : ~ @Equation2330 Fin4 refa366_inst.
Proof. unfold Equation2330. intro H. specialize (H F4_3 F4_1). unfold magma_op, refa366_inst, refa366_op in H. discriminate H. Qed.

Lemma refa366_not2506 : ~ @Equation2506 Fin4 refa366_inst.
Proof. unfold Equation2506. intro H. specialize (H F4_3 F4_1). unfold magma_op, refa366_inst, refa366_op in H. discriminate H. Qed.

Lemma refa366_not2543 : ~ @Equation2543 Fin4 refa366_inst.
Proof. unfold Equation2543. intro H. specialize (H F4_3 F4_1). unfold magma_op, refa366_inst, refa366_op in H. discriminate H. Qed.

Lemma refa366_not2672 : ~ @Equation2672 Fin4 refa366_inst.
Proof. unfold Equation2672. intro H. specialize (H F4_3 F4_1). unfold magma_op, refa366_inst, refa366_op in H. discriminate H. Qed.

Lemma refa366_not4118 : ~ @Equation4118 Fin4 refa366_inst.
Proof. unfold Equation4118. intro H. specialize (H F4_1 F4_0). unfold magma_op, refa366_inst, refa366_op in H. discriminate H. Qed.

Lemma refa366_not4320 : ~ @Equation4320 Fin4 refa366_inst.
Proof. unfold Equation4320. intro H. specialize (H F4_1 F4_0). unfold magma_op, refa366_inst, refa366_op in H. discriminate H. Qed.

(** ---- refa367 (Fin4) ---- *)

Definition refa367_op (x y : Fin4) : Fin4 :=
  match x, y with
  | F4_0, F4_0 => F4_3 | F4_0, F4_1 => F4_0 | F4_0, F4_2 => F4_3 | F4_0, F4_3 => F4_1
  | F4_1, F4_0 => F4_3 | F4_1, F4_1 => F4_3 | F4_1, F4_2 => F4_1 | F4_1, F4_3 => F4_2
  | F4_2, F4_0 => F4_2 | F4_2, F4_1 => F4_3 | F4_2, F4_2 => F4_3 | F4_2, F4_3 => F4_0
  | F4_3, F4_0 => F4_3 | F4_3, F4_1 => F4_3 | F4_3, F4_2 => F4_3 | F4_3, F4_3 => F4_3
  end.

#[local] Instance refa367_inst : Magma Fin4 := {| magma_op := refa367_op |}.

Lemma refa367_sat371 : @Equation371 Fin4 refa367_inst.
Proof. unfold Equation371, magma_op, refa367_inst, refa367_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa367_sat626 : @Equation626 Fin4 refa367_inst.
Proof. unfold Equation626, magma_op, refa367_inst, refa367_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa367_not56 : ~ @Equation56 Fin4 refa367_inst.
Proof. unfold Equation56. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa367_inst, refa367_op in H. discriminate H. Qed.

Lemma refa367_not99 : ~ @Equation99 Fin4 refa367_inst.
Proof. unfold Equation99. intro H. specialize (H F4_0). unfold magma_op, refa367_inst, refa367_op in H. discriminate H. Qed.

Lemma refa367_not151 : ~ @Equation151 Fin4 refa367_inst.
Proof. unfold Equation151. intro H. specialize (H F4_0). unfold magma_op, refa367_inst, refa367_op in H. discriminate H. Qed.

Lemma refa367_not203 : ~ @Equation203 Fin4 refa367_inst.
Proof. unfold Equation203. intro H. specialize (H F4_0). unfold magma_op, refa367_inst, refa367_op in H. discriminate H. Qed.

Lemma refa367_not255 : ~ @Equation255 Fin4 refa367_inst.
Proof. unfold Equation255. intro H. specialize (H F4_0). unfold magma_op, refa367_inst, refa367_op in H. discriminate H. Qed.

Lemma refa367_not411 : ~ @Equation411 Fin4 refa367_inst.
Proof. unfold Equation411. intro H. specialize (H F4_0). unfold magma_op, refa367_inst, refa367_op in H. discriminate H. Qed.

Lemma refa367_not619 : ~ @Equation619 Fin4 refa367_inst.
Proof. unfold Equation619. intro H. specialize (H F4_0 F4_2). unfold magma_op, refa367_inst, refa367_op in H. discriminate H. Qed.

Lemma refa367_not629 : ~ @Equation629 Fin4 refa367_inst.
Proof. unfold Equation629. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa367_inst, refa367_op in H. discriminate H. Qed.

Lemma refa367_not630 : ~ @Equation630 Fin4 refa367_inst.
Proof. unfold Equation630. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa367_inst, refa367_op in H. discriminate H. Qed.

Lemma refa367_not632 : ~ @Equation632 Fin4 refa367_inst.
Proof. unfold Equation632. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa367_inst, refa367_op in H. discriminate H. Qed.

Lemma refa367_not633 : ~ @Equation633 Fin4 refa367_inst.
Proof. unfold Equation633. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa367_inst, refa367_op in H. discriminate H. Qed.

Lemma refa367_not639 : ~ @Equation639 Fin4 refa367_inst.
Proof. unfold Equation639. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa367_inst, refa367_op in H. discriminate H. Qed.

Lemma refa367_not640 : ~ @Equation640 Fin4 refa367_inst.
Proof. unfold Equation640. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa367_inst, refa367_op in H. discriminate H. Qed.

Lemma refa367_not642 : ~ @Equation642 Fin4 refa367_inst.
Proof. unfold Equation642. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa367_inst, refa367_op in H. discriminate H. Qed.

Lemma refa367_not643 : ~ @Equation643 Fin4 refa367_inst.
Proof. unfold Equation643. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa367_inst, refa367_op in H. discriminate H. Qed.

Lemma refa367_not817 : ~ @Equation817 Fin4 refa367_inst.
Proof. unfold Equation817. intro H. specialize (H F4_0). unfold magma_op, refa367_inst, refa367_op in H. discriminate H. Qed.

Lemma refa367_not1020 : ~ @Equation1020 Fin4 refa367_inst.
Proof. unfold Equation1020. intro H. specialize (H F4_0). unfold magma_op, refa367_inst, refa367_op in H. discriminate H. Qed.

Lemma refa367_not1223 : ~ @Equation1223 Fin4 refa367_inst.
Proof. unfold Equation1223. intro H. specialize (H F4_0). unfold magma_op, refa367_inst, refa367_op in H. discriminate H. Qed.

Lemma refa367_not1426 : ~ @Equation1426 Fin4 refa367_inst.
Proof. unfold Equation1426. intro H. specialize (H F4_0). unfold magma_op, refa367_inst, refa367_op in H. discriminate H. Qed.

Lemma refa367_not1629 : ~ @Equation1629 Fin4 refa367_inst.
Proof. unfold Equation1629. intro H. specialize (H F4_0). unfold magma_op, refa367_inst, refa367_op in H. discriminate H. Qed.

Lemma refa367_not1832 : ~ @Equation1832 Fin4 refa367_inst.
Proof. unfold Equation1832. intro H. specialize (H F4_0). unfold magma_op, refa367_inst, refa367_op in H. discriminate H. Qed.

Lemma refa367_not2035 : ~ @Equation2035 Fin4 refa367_inst.
Proof. unfold Equation2035. intro H. specialize (H F4_0). unfold magma_op, refa367_inst, refa367_op in H. discriminate H. Qed.

Lemma refa367_not2238 : ~ @Equation2238 Fin4 refa367_inst.
Proof. unfold Equation2238. intro H. specialize (H F4_0). unfold magma_op, refa367_inst, refa367_op in H. discriminate H. Qed.

Lemma refa367_not2441 : ~ @Equation2441 Fin4 refa367_inst.
Proof. unfold Equation2441. intro H. specialize (H F4_0). unfold magma_op, refa367_inst, refa367_op in H. discriminate H. Qed.

Lemma refa367_not2644 : ~ @Equation2644 Fin4 refa367_inst.
Proof. unfold Equation2644. intro H. specialize (H F4_0). unfold magma_op, refa367_inst, refa367_op in H. discriminate H. Qed.

Lemma refa367_not2847 : ~ @Equation2847 Fin4 refa367_inst.
Proof. unfold Equation2847. intro H. specialize (H F4_0). unfold magma_op, refa367_inst, refa367_op in H. discriminate H. Qed.

Lemma refa367_not3050 : ~ @Equation3050 Fin4 refa367_inst.
Proof. unfold Equation3050. intro H. specialize (H F4_0). unfold magma_op, refa367_inst, refa367_op in H. discriminate H. Qed.

Lemma refa367_not3253 : ~ @Equation3253 Fin4 refa367_inst.
Proof. unfold Equation3253. intro H. specialize (H F4_0). unfold magma_op, refa367_inst, refa367_op in H. discriminate H. Qed.

Lemma refa367_not3456 : ~ @Equation3456 Fin4 refa367_inst.
Proof. unfold Equation3456. intro H. specialize (H F4_0). unfold magma_op, refa367_inst, refa367_op in H. discriminate H. Qed.

Lemma refa367_not3714 : ~ @Equation3714 Fin4 refa367_inst.
Proof. unfold Equation3714. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa367_inst, refa367_op in H. discriminate H. Qed.

Lemma refa367_not3721 : ~ @Equation3721 Fin4 refa367_inst.
Proof. unfold Equation3721. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa367_inst, refa367_op in H. discriminate H. Qed.

Lemma refa367_not3722 : ~ @Equation3722 Fin4 refa367_inst.
Proof. unfold Equation3722. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa367_inst, refa367_op in H. discriminate H. Qed.

Lemma refa367_not3724 : ~ @Equation3724 Fin4 refa367_inst.
Proof. unfold Equation3724. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa367_inst, refa367_op in H. discriminate H. Qed.

Lemma refa367_not3725 : ~ @Equation3725 Fin4 refa367_inst.
Proof. unfold Equation3725. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa367_inst, refa367_op in H. discriminate H. Qed.

Lemma refa367_not3915 : ~ @Equation3915 Fin4 refa367_inst.
Proof. unfold Equation3915. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa367_inst, refa367_op in H. discriminate H. Qed.

Lemma refa367_not3918 : ~ @Equation3918 Fin4 refa367_inst.
Proof. unfold Equation3918. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa367_inst, refa367_op in H. discriminate H. Qed.

Lemma refa367_not3925 : ~ @Equation3925 Fin4 refa367_inst.
Proof. unfold Equation3925. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa367_inst, refa367_op in H. discriminate H. Qed.

Lemma refa367_not3927 : ~ @Equation3927 Fin4 refa367_inst.
Proof. unfold Equation3927. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa367_inst, refa367_op in H. discriminate H. Qed.

Lemma refa367_not3928 : ~ @Equation3928 Fin4 refa367_inst.
Proof. unfold Equation3928. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa367_inst, refa367_op in H. discriminate H. Qed.

Lemma refa367_not4073 : ~ @Equation4073 Fin4 refa367_inst.
Proof. unfold Equation4073. intro H. specialize (H F4_0 F4_3). unfold magma_op, refa367_inst, refa367_op in H. discriminate H. Qed.

Lemma refa367_not4081 : ~ @Equation4081 Fin4 refa367_inst.
Proof. unfold Equation4081. intro H. specialize (H F4_3 F4_0). unfold magma_op, refa367_inst, refa367_op in H. discriminate H. Qed.

Lemma refa367_not4118 : ~ @Equation4118 Fin4 refa367_inst.
Proof. unfold Equation4118. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa367_inst, refa367_op in H. discriminate H. Qed.

Lemma refa367_not4120 : ~ @Equation4120 Fin4 refa367_inst.
Proof. unfold Equation4120. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa367_inst, refa367_op in H. discriminate H. Qed.

Lemma refa367_not4121 : ~ @Equation4121 Fin4 refa367_inst.
Proof. unfold Equation4121. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa367_inst, refa367_op in H. discriminate H. Qed.

Lemma refa367_not4127 : ~ @Equation4127 Fin4 refa367_inst.
Proof. unfold Equation4127. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa367_inst, refa367_op in H. discriminate H. Qed.

Lemma refa367_not4128 : ~ @Equation4128 Fin4 refa367_inst.
Proof. unfold Equation4128. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa367_inst, refa367_op in H. discriminate H. Qed.

Lemma refa367_not4130 : ~ @Equation4130 Fin4 refa367_inst.
Proof. unfold Equation4130. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa367_inst, refa367_op in H. discriminate H. Qed.

Lemma refa367_not4131 : ~ @Equation4131 Fin4 refa367_inst.
Proof. unfold Equation4131. intro H. specialize (H F4_0 F4_3). unfold magma_op, refa367_inst, refa367_op in H. discriminate H. Qed.

Lemma refa367_not4268 : ~ @Equation4268 Fin4 refa367_inst.
Proof. unfold Equation4268. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa367_inst, refa367_op in H. discriminate H. Qed.

Lemma refa367_not4269 : ~ @Equation4269 Fin4 refa367_inst.
Proof. unfold Equation4269. intro H. specialize (H F4_0 F4_2). unfold magma_op, refa367_inst, refa367_op in H. discriminate H. Qed.

Lemma refa367_not4314 : ~ @Equation4314 Fin4 refa367_inst.
Proof. unfold Equation4314. intro H. specialize (H F4_0 F4_2). unfold magma_op, refa367_inst, refa367_op in H. discriminate H. Qed.

Lemma refa367_not4380 : ~ @Equation4380 Fin4 refa367_inst.
Proof. unfold Equation4380. intro H. specialize (H F4_0). unfold magma_op, refa367_inst, refa367_op in H. discriminate H. Qed.

Lemma refa367_not4599 : ~ @Equation4599 Fin4 refa367_inst.
Proof. unfold Equation4599. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa367_inst, refa367_op in H. discriminate H. Qed.

Lemma refa367_not4629 : ~ @Equation4629 Fin4 refa367_inst.
Proof. unfold Equation4629. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa367_inst, refa367_op in H. discriminate H. Qed.

Lemma refa367_not4673 : ~ @Equation4673 Fin4 refa367_inst.
Proof. unfold Equation4673. intro H. specialize (H F4_0 F4_1 F4_3). unfold magma_op, refa367_inst, refa367_op in H. discriminate H. Qed.

(** ---- refa368 (Fin4) ---- *)

Definition refa368_op (x y : Fin4) : Fin4 :=
  match x, y with
  | F4_0, F4_0 => F4_0 | F4_0, F4_1 => F4_2 | F4_0, F4_2 => F4_2 | F4_0, F4_3 => F4_3
  | F4_1, F4_0 => F4_3 | F4_1, F4_1 => F4_0 | F4_1, F4_2 => F4_3 | F4_1, F4_3 => F4_0
  | F4_2, F4_0 => F4_0 | F4_2, F4_1 => F4_1 | F4_2, F4_2 => F4_2 | F4_2, F4_3 => F4_3
  | F4_3, F4_0 => F4_0 | F4_3, F4_1 => F4_2 | F4_3, F4_2 => F4_2 | F4_3, F4_3 => F4_3
  end.

#[local] Instance refa368_inst : Magma Fin4 := {| magma_op := refa368_op |}.

Lemma refa368_sat2919 : @Equation2919 Fin4 refa368_inst.
Proof. unfold Equation2919, magma_op, refa368_inst, refa368_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa368_not307 : ~ @Equation307 Fin4 refa368_inst.
Proof. unfold Equation307. intro H. specialize (H F4_1). unfold magma_op, refa368_inst, refa368_op in H. discriminate H. Qed.

Lemma refa368_not2035 : ~ @Equation2035 Fin4 refa368_inst.
Proof. unfold Equation2035. intro H. specialize (H F4_1). unfold magma_op, refa368_inst, refa368_op in H. discriminate H. Qed.

Lemma refa368_not2644 : ~ @Equation2644 Fin4 refa368_inst.
Proof. unfold Equation2644. intro H. specialize (H F4_1). unfold magma_op, refa368_inst, refa368_op in H. discriminate H. Qed.

Lemma refa368_not3258 : ~ @Equation3258 Fin4 refa368_inst.
Proof. unfold Equation3258. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa368_inst, refa368_op in H. discriminate H. Qed.

Lemma refa368_not3268 : ~ @Equation3268 Fin4 refa368_inst.
Proof. unfold Equation3268. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa368_inst, refa368_op in H. discriminate H. Qed.

Lemma refa368_not3278 : ~ @Equation3278 Fin4 refa368_inst.
Proof. unfold Equation3278. intro H. specialize (H F4_2 F4_1). unfold magma_op, refa368_inst, refa368_op in H. discriminate H. Qed.

Lemma refa368_not3309 : ~ @Equation3309 Fin4 refa368_inst.
Proof. unfold Equation3309. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa368_inst, refa368_op in H. discriminate H. Qed.

Lemma refa368_not3316 : ~ @Equation3316 Fin4 refa368_inst.
Proof. unfold Equation3316. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa368_inst, refa368_op in H. discriminate H. Qed.

Lemma refa368_not3319 : ~ @Equation3319 Fin4 refa368_inst.
Proof. unfold Equation3319. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa368_inst, refa368_op in H. discriminate H. Qed.

Lemma refa368_not3456 : ~ @Equation3456 Fin4 refa368_inst.
Proof. unfold Equation3456. intro H. specialize (H F4_1). unfold magma_op, refa368_inst, refa368_op in H. discriminate H. Qed.

Lemma refa368_not3664 : ~ @Equation3664 Fin4 refa368_inst.
Proof. unfold Equation3664. intro H. specialize (H F4_2 F4_1). unfold magma_op, refa368_inst, refa368_op in H. discriminate H. Qed.

Lemma refa368_not3674 : ~ @Equation3674 Fin4 refa368_inst.
Proof. unfold Equation3674. intro H. specialize (H F4_1 F4_2). unfold magma_op, refa368_inst, refa368_op in H. discriminate H. Qed.

Lemma refa368_not3749 : ~ @Equation3749 Fin4 refa368_inst.
Proof. unfold Equation3749. intro H. specialize (H F4_1 F4_2). unfold magma_op, refa368_inst, refa368_op in H. discriminate H. Qed.

Lemma refa368_not4272 : ~ @Equation4272 Fin4 refa368_inst.
Proof. unfold Equation4272. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa368_inst, refa368_op in H. discriminate H. Qed.

Lemma refa368_not4284 : ~ @Equation4284 Fin4 refa368_inst.
Proof. unfold Equation4284. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa368_inst, refa368_op in H. discriminate H. Qed.

Lemma refa368_not4320 : ~ @Equation4320 Fin4 refa368_inst.
Proof. unfold Equation4320. intro H. specialize (H F4_1 F4_0). unfold magma_op, refa368_inst, refa368_op in H. discriminate H. Qed.

Lemma refa368_not4606 : ~ @Equation4606 Fin4 refa368_inst.
Proof. unfold Equation4606. intro H. specialize (H F4_1 F4_2). unfold magma_op, refa368_inst, refa368_op in H. discriminate H. Qed.
