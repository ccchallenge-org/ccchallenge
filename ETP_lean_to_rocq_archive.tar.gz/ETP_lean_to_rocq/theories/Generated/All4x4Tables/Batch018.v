(** * All4x4 counterexamples — batch 18
    Auto-generated from Lean4 All4x4 files. *)

From Stdlib Require Import Utf8.

From ETP Require Import Magma.
From ETP Require Import FinMagma.
From ETP.Equations Require Import All.

Open Scope magma_scope.

(** ---- refa865 (Fin5) ---- *)

Definition refa865_op (x y : Fin5) : Fin5 :=
  match x, y with
  | F5_0, F5_0 => F5_0 | F5_0, F5_1 => F5_2 | F5_0, F5_2 => F5_0 | F5_0, F5_3 => F5_0 | F5_0, F5_4 => F5_2
  | F5_1, F5_0 => F5_1 | F5_1, F5_1 => F5_1 | F5_1, F5_2 => F5_1 | F5_1, F5_3 => F5_4 | F5_1, F5_4 => F5_1
  | F5_2, F5_0 => F5_2 | F5_2, F5_1 => F5_3 | F5_2, F5_2 => F5_2 | F5_2, F5_3 => F5_2 | F5_2, F5_4 => F5_2
  | F5_3, F5_0 => F5_4 | F5_3, F5_1 => F5_3 | F5_3, F5_2 => F5_3 | F5_3, F5_3 => F5_3 | F5_3, F5_4 => F5_3
  | F5_4, F5_0 => F5_1 | F5_4, F5_1 => F5_4 | F5_4, F5_2 => F5_4 | F5_4, F5_3 => F5_4 | F5_4, F5_4 => F5_4
  end.

#[local] Instance refa865_inst : Magma Fin5 := {| magma_op := refa865_op |}.

Lemma refa865_sat1235 : @Equation1235 Fin5 refa865_inst.
Proof. unfold Equation1235, magma_op, refa865_inst, refa865_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa865_not1231 : ~ @Equation1231 Fin5 refa865_inst.
Proof. unfold Equation1231. intro H. specialize (H F5_0 F5_1). unfold magma_op, refa865_inst, refa865_op in H. discriminate H. Qed.

(** ---- refa866 (Fin8) ---- *)

Definition refa866_op (x y : Fin8) : Fin8 :=
  match x, y with
  | F8_0, F8_0 => F8_1 | F8_0, F8_1 => F8_2 | F8_0, F8_2 => F8_4 | F8_0, F8_3 => F8_4 | F8_0, F8_4 => F8_0 | F8_0, F8_5 => F8_0 | F8_0, F8_6 => F8_0 | F8_0, F8_7 => F8_2
  | F8_1, F8_0 => F8_4 | F8_1, F8_1 => F8_6 | F8_1, F8_2 => F8_4 | F8_1, F8_3 => F8_1 | F8_1, F8_4 => F8_6 | F8_1, F8_5 => F8_1 | F8_1, F8_6 => F8_1 | F8_1, F8_7 => F8_1
  | F8_2, F8_0 => F8_1 | F8_2, F8_1 => F8_3 | F8_2, F8_2 => F8_2 | F8_2, F8_3 => F8_2 | F8_2, F8_4 => F8_7 | F8_2, F8_5 => F8_2 | F8_2, F8_6 => F8_3 | F8_2, F8_7 => F8_3
  | F8_3, F8_0 => F8_1 | F8_3, F8_1 => F8_3 | F8_3, F8_2 => F8_3 | F8_3, F8_3 => F8_3 | F8_3, F8_4 => F8_7 | F8_3, F8_5 => F8_3 | F8_3, F8_6 => F8_3 | F8_3, F8_7 => F8_3
  | F8_4, F8_0 => F8_4 | F8_4, F8_1 => F8_5 | F8_4, F8_2 => F8_5 | F8_4, F8_3 => F8_2 | F8_4, F8_4 => F8_4 | F8_4, F8_5 => F8_4 | F8_4, F8_6 => F8_4 | F8_4, F8_7 => F8_2
  | F8_5, F8_0 => F8_5 | F8_5, F8_1 => F8_5 | F8_5, F8_2 => F8_5 | F8_5, F8_3 => F8_5 | F8_5, F8_4 => F8_5 | F8_5, F8_5 => F8_0 | F8_5, F8_6 => F8_7 | F8_5, F8_7 => F8_3
  | F8_6, F8_0 => F8_6 | F8_6, F8_1 => F8_6 | F8_6, F8_2 => F8_4 | F8_6, F8_3 => F8_6 | F8_6, F8_4 => F8_6 | F8_6, F8_5 => F8_0 | F8_6, F8_6 => F8_6 | F8_6, F8_7 => F8_6
  | F8_7, F8_0 => F8_1 | F8_7, F8_1 => F8_7 | F8_7, F8_2 => F8_4 | F8_7, F8_3 => F8_7 | F8_7, F8_4 => F8_6 | F8_7, F8_5 => F8_4 | F8_7, F8_6 => F8_7 | F8_7, F8_7 => F8_7
  end.

#[local] Instance refa866_inst : Magma Fin8 := {| magma_op := refa866_op |}.

Lemma refa866_sat834 : @Equation834 Fin8 refa866_inst.
Proof. unfold Equation834, magma_op, refa866_inst, refa866_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa866_not1020 : ~ @Equation1020 Fin8 refa866_inst.
Proof. unfold Equation1020. intro H. specialize (H F8_0). unfold magma_op, refa866_inst, refa866_op in H. discriminate H. Qed.

Lemma refa866_not1224 : ~ @Equation1224 Fin8 refa866_inst.
Proof. unfold Equation1224. intro H. specialize (H F8_0 F8_3). unfold magma_op, refa866_inst, refa866_op in H. discriminate H. Qed.

Lemma refa866_not1225 : ~ @Equation1225 Fin8 refa866_inst.
Proof. unfold Equation1225. intro H. specialize (H F8_1 F8_5). unfold magma_op, refa866_inst, refa866_op in H. discriminate H. Qed.

Lemma refa866_not1229 : ~ @Equation1229 Fin8 refa866_inst.
Proof. unfold Equation1229. intro H. specialize (H F8_0 F8_3). unfold magma_op, refa866_inst, refa866_op in H. discriminate H. Qed.

Lemma refa866_not1239 : ~ @Equation1239 Fin8 refa866_inst.
Proof. unfold Equation1239. intro H. specialize (H F8_0 F8_3). unfold magma_op, refa866_inst, refa866_op in H. discriminate H. Qed.

Lemma refa866_not1241 : ~ @Equation1241 Fin8 refa866_inst.
Proof. unfold Equation1241. intro H. specialize (H F8_0 F8_5). unfold magma_op, refa866_inst, refa866_op in H. discriminate H. Qed.

Lemma refa866_not1242 : ~ @Equation1242 Fin8 refa866_inst.
Proof. unfold Equation1242. intro H. specialize (H F8_0 F8_3). unfold magma_op, refa866_inst, refa866_op in H. discriminate H. Qed.

Lemma refa866_not1249 : ~ @Equation1249 Fin8 refa866_inst.
Proof. unfold Equation1249. intro H. specialize (H F8_0 F8_3). unfold magma_op, refa866_inst, refa866_op in H. discriminate H. Qed.

Lemma refa866_not1251 : ~ @Equation1251 Fin8 refa866_inst.
Proof. unfold Equation1251. intro H. specialize (H F8_0 F8_2). unfold magma_op, refa866_inst, refa866_op in H. discriminate H. Qed.

Lemma refa866_not1252 : ~ @Equation1252 Fin8 refa866_inst.
Proof. unfold Equation1252. intro H. specialize (H F8_0 F8_2). unfold magma_op, refa866_inst, refa866_op in H. discriminate H. Qed.

Lemma refa866_not1832 : ~ @Equation1832 Fin8 refa866_inst.
Proof. unfold Equation1832. intro H. specialize (H F8_0). unfold magma_op, refa866_inst, refa866_op in H. discriminate H. Qed.

Lemma refa866_not3253 : ~ @Equation3253 Fin8 refa866_inst.
Proof. unfold Equation3253. intro H. specialize (H F8_0). unfold magma_op, refa866_inst, refa866_op in H. discriminate H. Qed.

Lemma refa866_not3659 : ~ @Equation3659 Fin8 refa866_inst.
Proof. unfold Equation3659. intro H. specialize (H F8_0). unfold magma_op, refa866_inst, refa866_op in H. discriminate H. Qed.

Lemma refa866_not3864 : ~ @Equation3864 Fin8 refa866_inst.
Proof. unfold Equation3864. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa866_inst, refa866_op in H. discriminate H. Qed.

Lemma refa866_not3865 : ~ @Equation3865 Fin8 refa866_inst.
Proof. unfold Equation3865. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa866_inst, refa866_op in H. discriminate H. Qed.

Lemma refa866_not3867 : ~ @Equation3867 Fin8 refa866_inst.
Proof. unfold Equation3867. intro H. specialize (H F8_1 F8_0). unfold magma_op, refa866_inst, refa866_op in H. discriminate H. Qed.

Lemma refa866_not3870 : ~ @Equation3870 Fin8 refa866_inst.
Proof. unfold Equation3870. intro H. specialize (H F8_0 F8_2). unfold magma_op, refa866_inst, refa866_op in H. discriminate H. Qed.

Lemma refa866_not3878 : ~ @Equation3878 Fin8 refa866_inst.
Proof. unfold Equation3878. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa866_inst, refa866_op in H. discriminate H. Qed.

Lemma refa866_not3881 : ~ @Equation3881 Fin8 refa866_inst.
Proof. unfold Equation3881. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa866_inst, refa866_op in H. discriminate H. Qed.

Lemma refa866_not3887 : ~ @Equation3887 Fin8 refa866_inst.
Proof. unfold Equation3887. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa866_inst, refa866_op in H. discriminate H. Qed.

Lemma refa866_not3888 : ~ @Equation3888 Fin8 refa866_inst.
Proof. unfold Equation3888. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa866_inst, refa866_op in H. discriminate H. Qed.

Lemma refa866_not3915 : ~ @Equation3915 Fin8 refa866_inst.
Proof. unfold Equation3915. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa866_inst, refa866_op in H. discriminate H. Qed.

Lemma refa866_not3925 : ~ @Equation3925 Fin8 refa866_inst.
Proof. unfold Equation3925. intro H. specialize (H F8_0 F8_2). unfold magma_op, refa866_inst, refa866_op in H. discriminate H. Qed.

Lemma refa866_not3928 : ~ @Equation3928 Fin8 refa866_inst.
Proof. unfold Equation3928. intro H. specialize (H F8_0 F8_2). unfold magma_op, refa866_inst, refa866_op in H. discriminate H. Qed.

Lemma refa866_not4065 : ~ @Equation4065 Fin8 refa866_inst.
Proof. unfold Equation4065. intro H. specialize (H F8_0). unfold magma_op, refa866_inst, refa866_op in H. discriminate H. Qed.

Lemma refa866_not4269 : ~ @Equation4269 Fin8 refa866_inst.
Proof. unfold Equation4269. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa866_inst, refa866_op in H. discriminate H. Qed.

Lemma refa866_not4270 : ~ @Equation4270 Fin8 refa866_inst.
Proof. unfold Equation4270. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa866_inst, refa866_op in H. discriminate H. Qed.

Lemma refa866_not4293 : ~ @Equation4293 Fin8 refa866_inst.
Proof. unfold Equation4293. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa866_inst, refa866_op in H. discriminate H. Qed.

Lemma refa866_not4314 : ~ @Equation4314 Fin8 refa866_inst.
Proof. unfold Equation4314. intro H. specialize (H F8_0 F8_2). unfold magma_op, refa866_inst, refa866_op in H. discriminate H. Qed.

Lemma refa866_not4583 : ~ @Equation4583 Fin8 refa866_inst.
Proof. unfold Equation4583. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa866_inst, refa866_op in H. discriminate H. Qed.

Lemma refa866_not4591 : ~ @Equation4591 Fin8 refa866_inst.
Proof. unfold Equation4591. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa866_inst, refa866_op in H. discriminate H. Qed.

Lemma refa866_not4598 : ~ @Equation4598 Fin8 refa866_inst.
Proof. unfold Equation4598. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa866_inst, refa866_op in H. discriminate H. Qed.

Lemma refa866_not4606 : ~ @Equation4606 Fin8 refa866_inst.
Proof. unfold Equation4606. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa866_inst, refa866_op in H. discriminate H. Qed.

Lemma refa866_not4608 : ~ @Equation4608 Fin8 refa866_inst.
Proof. unfold Equation4608. intro H. specialize (H F8_0 F8_2). unfold magma_op, refa866_inst, refa866_op in H. discriminate H. Qed.

Lemma refa866_not4622 : ~ @Equation4622 Fin8 refa866_inst.
Proof. unfold Equation4622. intro H. specialize (H F8_0 F8_0 F8_1). unfold magma_op, refa866_inst, refa866_op in H. discriminate H. Qed.

Lemma refa866_not4631 : ~ @Equation4631 Fin8 refa866_inst.
Proof. unfold Equation4631. intro H. specialize (H F8_0 F8_0 F8_1). unfold magma_op, refa866_inst, refa866_op in H. discriminate H. Qed.

Lemma refa866_not4636 : ~ @Equation4636 Fin8 refa866_inst.
Proof. unfold Equation4636. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa866_inst, refa866_op in H. discriminate H. Qed.

Lemma refa866_not4647 : ~ @Equation4647 Fin8 refa866_inst.
Proof. unfold Equation4647. intro H. specialize (H F8_0 F8_0 F8_1). unfold magma_op, refa866_inst, refa866_op in H. discriminate H. Qed.

(** ---- refa867 (Fin6) ---- *)

Definition refa867_op (x y : Fin6) : Fin6 :=
  match x, y with
  | F6_0, F6_0 => F6_2 | F6_0, F6_1 => F6_0 | F6_0, F6_2 => F6_3 | F6_0, F6_3 => F6_0 | F6_0, F6_4 => F6_0 | F6_0, F6_5 => F6_2
  | F6_1, F6_0 => F6_1 | F6_1, F6_1 => F6_0 | F6_1, F6_2 => F6_1 | F6_1, F6_3 => F6_1 | F6_1, F6_4 => F6_5 | F6_1, F6_5 => F6_0
  | F6_2, F6_0 => F6_3 | F6_2, F6_1 => F6_2 | F6_2, F6_2 => F6_3 | F6_2, F6_3 => F6_4 | F6_2, F6_4 => F6_2 | F6_2, F6_5 => F6_2
  | F6_3, F6_0 => F6_3 | F6_3, F6_1 => F6_3 | F6_3, F6_2 => F6_4 | F6_3, F6_3 => F6_4 | F6_3, F6_4 => F6_1 | F6_3, F6_5 => F6_3
  | F6_4, F6_0 => F6_4 | F6_4, F6_1 => F6_5 | F6_4, F6_2 => F6_4 | F6_4, F6_3 => F6_1 | F6_4, F6_4 => F6_5 | F6_4, F6_5 => F6_4
  | F6_5, F6_0 => F6_2 | F6_5, F6_1 => F6_0 | F6_5, F6_2 => F6_5 | F6_5, F6_3 => F6_5 | F6_5, F6_4 => F6_5 | F6_5, F6_5 => F6_0
  end.

#[local] Instance refa867_inst : Magma Fin6 := {| magma_op := refa867_op |}.

Lemma refa867_sat834 : @Equation834 Fin6 refa867_inst.
Proof. unfold Equation834, magma_op, refa867_inst, refa867_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa867_not40 : ~ @Equation40 Fin6 refa867_inst.
Proof. unfold Equation40. intro H. specialize (H F6_0 F6_1). unfold magma_op, refa867_inst, refa867_op in H. discriminate H. Qed.

Lemma refa867_not105 : ~ @Equation105 Fin6 refa867_inst.
Proof. unfold Equation105. intro H. specialize (H F6_0 F6_1). unfold magma_op, refa867_inst, refa867_op in H. discriminate H. Qed.

Lemma refa867_not107 : ~ @Equation107 Fin6 refa867_inst.
Proof. unfold Equation107. intro H. specialize (H F6_0 F6_1). unfold magma_op, refa867_inst, refa867_op in H. discriminate H. Qed.

Lemma refa867_not108 : ~ @Equation108 Fin6 refa867_inst.
Proof. unfold Equation108. intro H. specialize (H F6_0 F6_1). unfold magma_op, refa867_inst, refa867_op in H. discriminate H. Qed.

Lemma refa867_not359 : ~ @Equation359 Fin6 refa867_inst.
Proof. unfold Equation359. intro H. specialize (H F6_0). unfold magma_op, refa867_inst, refa867_op in H. discriminate H. Qed.

Lemma refa867_not411 : ~ @Equation411 Fin6 refa867_inst.
Proof. unfold Equation411. intro H. specialize (H F6_0). unfold magma_op, refa867_inst, refa867_op in H. discriminate H. Qed.

Lemma refa867_not819 : ~ @Equation819 Fin6 refa867_inst.
Proof. unfold Equation819. intro H. specialize (H F6_0 F6_1). unfold magma_op, refa867_inst, refa867_op in H. discriminate H. Qed.

Lemma refa867_not835 : ~ @Equation835 Fin6 refa867_inst.
Proof. unfold Equation835. intro H. specialize (H F6_0 F6_1). unfold magma_op, refa867_inst, refa867_op in H. discriminate H. Qed.

Lemma refa867_not836 : ~ @Equation836 Fin6 refa867_inst.
Proof. unfold Equation836. intro H. specialize (H F6_1 F6_2). unfold magma_op, refa867_inst, refa867_op in H. discriminate H. Qed.

Lemma refa867_not842 : ~ @Equation842 Fin6 refa867_inst.
Proof. unfold Equation842. intro H. specialize (H F6_0 F6_4). unfold magma_op, refa867_inst, refa867_op in H. discriminate H. Qed.

Lemma refa867_not843 : ~ @Equation843 Fin6 refa867_inst.
Proof. unfold Equation843. intro H. specialize (H F6_0 F6_1). unfold magma_op, refa867_inst, refa867_op in H. discriminate H. Qed.

Lemma refa867_not845 : ~ @Equation845 Fin6 refa867_inst.
Proof. unfold Equation845. intro H. specialize (H F6_0 F6_1). unfold magma_op, refa867_inst, refa867_op in H. discriminate H. Qed.

Lemma refa867_not846 : ~ @Equation846 Fin6 refa867_inst.
Proof. unfold Equation846. intro H. specialize (H F6_0 F6_1). unfold magma_op, refa867_inst, refa867_op in H. discriminate H. Qed.

Lemma refa867_not3862 : ~ @Equation3862 Fin6 refa867_inst.
Proof. unfold Equation3862. intro H. specialize (H F6_0). unfold magma_op, refa867_inst, refa867_op in H. discriminate H. Qed.

(** ---- refa868 (Fin5) ---- *)

Definition refa868_op (x y : Fin5) : Fin5 :=
  match x, y with
  | F5_0, F5_0 => F5_1 | F5_0, F5_1 => F5_2 | F5_0, F5_2 => F5_1 | F5_0, F5_3 => F5_1 | F5_0, F5_4 => F5_0
  | F5_1, F5_0 => F5_4 | F5_1, F5_1 => F5_4 | F5_1, F5_2 => F5_4 | F5_1, F5_3 => F5_1 | F5_1, F5_4 => F5_1
  | F5_2, F5_0 => F5_3 | F5_2, F5_1 => F5_3 | F5_2, F5_2 => F5_3 | F5_2, F5_3 => F5_3 | F5_2, F5_4 => F5_2
  | F5_3, F5_0 => F5_4 | F5_3, F5_1 => F5_3 | F5_3, F5_2 => F5_4 | F5_3, F5_3 => F5_4 | F5_3, F5_4 => F5_3
  | F5_4, F5_0 => F5_4 | F5_4, F5_1 => F5_4 | F5_4, F5_2 => F5_4 | F5_4, F5_3 => F5_4 | F5_4, F5_4 => F5_4
  end.

#[local] Instance refa868_inst : Magma Fin5 := {| magma_op := refa868_op |}.

Lemma refa868_sat837 : @Equation837 Fin5 refa868_inst.
Proof. unfold Equation837, magma_op, refa868_inst, refa868_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa868_not1020 : ~ @Equation1020 Fin5 refa868_inst.
Proof. unfold Equation1020. intro H. specialize (H F5_0). unfold magma_op, refa868_inst, refa868_op in H. discriminate H. Qed.

(** ---- refa869 (Fin7) ---- *)

Definition refa869_op (x y : Fin7) : Fin7 :=
  match x, y with
  | F7_0, F7_0 => F7_1 | F7_0, F7_1 => F7_1 | F7_0, F7_2 => F7_0 | F7_0, F7_3 => F7_4 | F7_0, F7_4 => F7_1 | F7_0, F7_5 => F7_0 | F7_0, F7_6 => F7_0
  | F7_1, F7_0 => F7_2 | F7_1, F7_1 => F7_6 | F7_1, F7_2 => F7_1 | F7_1, F7_3 => F7_6 | F7_1, F7_4 => F7_2 | F7_1, F7_5 => F7_1 | F7_1, F7_6 => F7_1
  | F7_2, F7_0 => F7_3 | F7_2, F7_1 => F7_2 | F7_2, F7_2 => F7_5 | F7_2, F7_3 => F7_5 | F7_2, F7_4 => F7_2 | F7_2, F7_5 => F7_5 | F7_2, F7_6 => F7_2
  | F7_3, F7_0 => F7_3 | F7_3, F7_1 => F7_2 | F7_3, F7_2 => F7_5 | F7_3, F7_3 => F7_5 | F7_3, F7_4 => F7_2 | F7_3, F7_5 => F7_5 | F7_3, F7_6 => F7_3
  | F7_4, F7_0 => F7_6 | F7_4, F7_1 => F7_6 | F7_4, F7_2 => F7_4 | F7_4, F7_3 => F7_6 | F7_4, F7_4 => F7_6 | F7_4, F7_5 => F7_4 | F7_4, F7_6 => F7_4
  | F7_5, F7_0 => F7_5 | F7_5, F7_1 => F7_5 | F7_5, F7_2 => F7_6 | F7_5, F7_3 => F7_6 | F7_5, F7_4 => F7_5 | F7_5, F7_5 => F7_6 | F7_5, F7_6 => F7_5
  | F7_6, F7_0 => F7_6 | F7_6, F7_1 => F7_6 | F7_6, F7_2 => F7_6 | F7_6, F7_3 => F7_6 | F7_6, F7_4 => F7_6 | F7_6, F7_5 => F7_6 | F7_6, F7_6 => F7_6
  end.

#[local] Instance refa869_inst : Magma Fin7 := {| magma_op := refa869_op |}.

Lemma refa869_sat837 : @Equation837 Fin7 refa869_inst.
Proof. unfold Equation837, magma_op, refa869_inst, refa869_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa869_not1223 : ~ @Equation1223 Fin7 refa869_inst.
Proof. unfold Equation1223. intro H. specialize (H F7_0). unfold magma_op, refa869_inst, refa869_op in H. discriminate H. Qed.

(** ---- refa87 (Fin3) ---- *)

Definition refa87_op (x y : Fin3) : Fin3 :=
  match x, y with
  | F3_0, F3_0 => F3_0 | F3_0, F3_1 => F3_0 | F3_0, F3_2 => F3_1
  | F3_1, F3_0 => F3_2 | F3_1, F3_1 => F3_2 | F3_1, F3_2 => F3_2
  | F3_2, F3_0 => F3_0 | F3_2, F3_1 => F3_0 | F3_2, F3_2 => F3_2
  end.

#[local] Instance refa87_inst : Magma Fin3 := {| magma_op := refa87_op |}.

Lemma refa87_sat2087 : @Equation2087 Fin3 refa87_inst.
Proof. unfold Equation2087, magma_op, refa87_inst, refa87_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa87_sat2124 : @Equation2124 Fin3 refa87_inst.
Proof. unfold Equation2124, magma_op, refa87_inst, refa87_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa87_not3862 : ~ @Equation3862 Fin3 refa87_inst.
Proof. unfold Equation3862. intro H. specialize (H F3_1). unfold magma_op, refa87_inst, refa87_op in H. discriminate H. Qed.

Lemma refa87_not4073 : ~ @Equation4073 Fin3 refa87_inst.
Proof. unfold Equation4073. intro H. specialize (H F3_1 F3_0). unfold magma_op, refa87_inst, refa87_op in H. discriminate H. Qed.

Lemma refa87_not4083 : ~ @Equation4083 Fin3 refa87_inst.
Proof. unfold Equation4083. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa87_inst, refa87_op in H. discriminate H. Qed.

Lemma refa87_not4093 : ~ @Equation4093 Fin3 refa87_inst.
Proof. unfold Equation4093. intro H. specialize (H F3_1 F3_0). unfold magma_op, refa87_inst, refa87_op in H. discriminate H. Qed.

Lemma refa87_not4131 : ~ @Equation4131 Fin3 refa87_inst.
Proof. unfold Equation4131. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa87_inst, refa87_op in H. discriminate H. Qed.

Lemma refa87_not4158 : ~ @Equation4158 Fin3 refa87_inst.
Proof. unfold Equation4158. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa87_inst, refa87_op in H. discriminate H. Qed.

Lemma refa87_not4380 : ~ @Equation4380 Fin3 refa87_inst.
Proof. unfold Equation4380. intro H. specialize (H F3_1). unfold magma_op, refa87_inst, refa87_op in H. discriminate H. Qed.

Lemma refa87_not4606 : ~ @Equation4606 Fin3 refa87_inst.
Proof. unfold Equation4606. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa87_inst, refa87_op in H. discriminate H. Qed.

Lemma refa87_not4635 : ~ @Equation4635 Fin3 refa87_inst.
Proof. unfold Equation4635. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa87_inst, refa87_op in H. discriminate H. Qed.

(** ---- refa870 (Fin11) ---- *)

Definition refa870_op (x y : Fin11) : Fin11 :=
  match x, y with
  | F11_0, F11_0 => F11_2 | F11_0, F11_1 => F11_3 | F11_0, F11_2 => F11_0 | F11_0, F11_3 => F11_4 | F11_0, F11_4 => F11_0 | F11_0, F11_5 => F11_10 | F11_0, F11_6 => F11_0 | F11_0, F11_7 => F11_10 | F11_0, F11_8 => F11_0 | F11_0, F11_9 => F11_7 | F11_0, F11_10 => F11_7
  | F11_1, F11_0 => F11_1 | F11_1, F11_1 => F11_5 | F11_1, F11_2 => F11_6 | F11_1, F11_3 => F11_1 | F11_1, F11_4 => F11_8 | F11_1, F11_5 => F11_1 | F11_1, F11_6 => F11_8 | F11_1, F11_7 => F11_8 | F11_1, F11_8 => F11_6 | F11_1, F11_9 => F11_1 | F11_1, F11_10 => F11_6
  | F11_2, F11_0 => F11_2 | F11_2, F11_1 => F11_9 | F11_2, F11_2 => F11_6 | F11_2, F11_3 => F11_2 | F11_2, F11_4 => F11_2 | F11_2, F11_5 => F11_2 | F11_2, F11_6 => F11_2 | F11_2, F11_7 => F11_2 | F11_2, F11_8 => F11_9 | F11_2, F11_9 => F11_2 | F11_2, F11_10 => F11_6
  | F11_3, F11_0 => F11_2 | F11_3, F11_1 => F11_3 | F11_3, F11_2 => F11_3 | F11_3, F11_3 => F11_2 | F11_3, F11_4 => F11_3 | F11_3, F11_5 => F11_9 | F11_3, F11_6 => F11_3 | F11_3, F11_7 => F11_9 | F11_3, F11_8 => F11_3 | F11_3, F11_9 => F11_7 | F11_3, F11_10 => F11_7
  | F11_4, F11_0 => F11_4 | F11_4, F11_1 => F11_5 | F11_4, F11_2 => F11_4 | F11_4, F11_3 => F11_4 | F11_4, F11_4 => F11_8 | F11_4, F11_5 => F11_4 | F11_4, F11_6 => F11_5 | F11_4, F11_7 => F11_8 | F11_4, F11_8 => F11_4 | F11_4, F11_9 => F11_4 | F11_4, F11_10 => F11_4
  | F11_5, F11_0 => F11_2 | F11_5, F11_1 => F11_5 | F11_5, F11_2 => F11_5 | F11_5, F11_3 => F11_2 | F11_5, F11_4 => F11_5 | F11_5, F11_5 => F11_9 | F11_5, F11_6 => F11_5 | F11_5, F11_7 => F11_2 | F11_5, F11_8 => F11_5 | F11_5, F11_9 => F11_5 | F11_5, F11_10 => F11_5
  | F11_6, F11_0 => F11_6 | F11_6, F11_1 => F11_5 | F11_6, F11_2 => F11_6 | F11_6, F11_3 => F11_6 | F11_6, F11_4 => F11_8 | F11_6, F11_5 => F11_6 | F11_6, F11_6 => F11_5 | F11_6, F11_7 => F11_8 | F11_6, F11_8 => F11_6 | F11_6, F11_9 => F11_6 | F11_6, F11_10 => F11_6
  | F11_7, F11_0 => F11_4 | F11_7, F11_1 => F11_3 | F11_7, F11_2 => F11_7 | F11_7, F11_3 => F11_4 | F11_7, F11_4 => F11_5 | F11_7, F11_5 => F11_4 | F11_7, F11_6 => F11_5 | F11_7, F11_7 => F11_8 | F11_7, F11_8 => F11_7 | F11_7, F11_9 => F11_7 | F11_7, F11_10 => F11_7
  | F11_8, F11_0 => F11_8 | F11_8, F11_1 => F11_9 | F11_8, F11_2 => F11_6 | F11_8, F11_3 => F11_8 | F11_8, F11_4 => F11_8 | F11_8, F11_5 => F11_8 | F11_8, F11_6 => F11_8 | F11_8, F11_7 => F11_8 | F11_8, F11_8 => F11_9 | F11_8, F11_9 => F11_8 | F11_8, F11_10 => F11_6
  | F11_9, F11_0 => F11_2 | F11_9, F11_1 => F11_9 | F11_9, F11_2 => F11_9 | F11_9, F11_3 => F11_2 | F11_9, F11_4 => F11_9 | F11_9, F11_5 => F11_9 | F11_9, F11_6 => F11_9 | F11_9, F11_7 => F11_9 | F11_9, F11_8 => F11_9 | F11_9, F11_9 => F11_4 | F11_9, F11_10 => F11_4
  | F11_10, F11_0 => F11_2 | F11_10, F11_1 => F11_9 | F11_10, F11_2 => F11_9 | F11_10, F11_3 => F11_2 | F11_10, F11_4 => F11_10 | F11_10, F11_5 => F11_10 | F11_10, F11_6 => F11_10 | F11_10, F11_7 => F11_10 | F11_10, F11_8 => F11_9 | F11_10, F11_9 => F11_2 | F11_10, F11_10 => F11_6
  end.

#[local] Instance refa870_inst : Magma Fin11 := {| magma_op := refa870_op |}.

Lemma refa870_sat854 : @Equation854 Fin11 refa870_inst.
Proof. unfold Equation854, magma_op, refa870_inst, refa870_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa870_not40 : ~ @Equation40 Fin11 refa870_inst.
Proof. unfold Equation40. intro H. specialize (H F11_0 F11_1). unfold magma_op, refa870_inst, refa870_op in H. discriminate H. Qed.

Lemma refa870_not105 : ~ @Equation105 Fin11 refa870_inst.
Proof. unfold Equation105. intro H. specialize (H F11_0 F11_1). unfold magma_op, refa870_inst, refa870_op in H. discriminate H. Qed.

Lemma refa870_not108 : ~ @Equation108 Fin11 refa870_inst.
Proof. unfold Equation108. intro H. specialize (H F11_0 F11_1). unfold magma_op, refa870_inst, refa870_op in H. discriminate H. Qed.

Lemma refa870_not360 : ~ @Equation360 Fin11 refa870_inst.
Proof. unfold Equation360. intro H. specialize (H F11_0 F11_1). unfold magma_op, refa870_inst, refa870_op in H. discriminate H. Qed.

Lemma refa870_not361 : ~ @Equation361 Fin11 refa870_inst.
Proof. unfold Equation361. intro H. specialize (H F11_0 F11_3). unfold magma_op, refa870_inst, refa870_op in H. discriminate H. Qed.

Lemma refa870_not365 : ~ @Equation365 Fin11 refa870_inst.
Proof. unfold Equation365. intro H. specialize (H F11_0 F11_1). unfold magma_op, refa870_inst, refa870_op in H. discriminate H. Qed.

Lemma refa870_not367 : ~ @Equation367 Fin11 refa870_inst.
Proof. unfold Equation367. intro H. specialize (H F11_0 F11_2). unfold magma_op, refa870_inst, refa870_op in H. discriminate H. Qed.

Lemma refa870_not414 : ~ @Equation414 Fin11 refa870_inst.
Proof. unfold Equation414. intro H. specialize (H F11_0 F11_1). unfold magma_op, refa870_inst, refa870_op in H. discriminate H. Qed.

Lemma refa870_not426 : ~ @Equation426 Fin11 refa870_inst.
Proof. unfold Equation426. intro H. specialize (H F11_0 F11_1). unfold magma_op, refa870_inst, refa870_op in H. discriminate H. Qed.

Lemma refa870_not427 : ~ @Equation427 Fin11 refa870_inst.
Proof. unfold Equation427. intro H. specialize (H F11_1 F11_0). unfold magma_op, refa870_inst, refa870_op in H. discriminate H. Qed.

Lemma refa870_not429 : ~ @Equation429 Fin11 refa870_inst.
Proof. unfold Equation429. intro H. specialize (H F11_0 F11_1). unfold magma_op, refa870_inst, refa870_op in H. discriminate H. Qed.

Lemma refa870_not436 : ~ @Equation436 Fin11 refa870_inst.
Proof. unfold Equation436. intro H. specialize (H F11_0 F11_5). unfold magma_op, refa870_inst, refa870_op in H. discriminate H. Qed.

Lemma refa870_not437 : ~ @Equation437 Fin11 refa870_inst.
Proof. unfold Equation437. intro H. specialize (H F11_0 F11_1). unfold magma_op, refa870_inst, refa870_op in H. discriminate H. Qed.

Lemma refa870_not439 : ~ @Equation439 Fin11 refa870_inst.
Proof. unfold Equation439. intro H. specialize (H F11_0 F11_1). unfold magma_op, refa870_inst, refa870_op in H. discriminate H. Qed.

Lemma refa870_not440 : ~ @Equation440 Fin11 refa870_inst.
Proof. unfold Equation440. intro H. specialize (H F11_0 F11_1). unfold magma_op, refa870_inst, refa870_op in H. discriminate H. Qed.

Lemma refa870_not819 : ~ @Equation819 Fin11 refa870_inst.
Proof. unfold Equation819. intro H. specialize (H F11_0 F11_1). unfold magma_op, refa870_inst, refa870_op in H. discriminate H. Qed.

Lemma refa870_not820 : ~ @Equation820 Fin11 refa870_inst.
Proof. unfold Equation820. intro H. specialize (H F11_0 F11_4). unfold magma_op, refa870_inst, refa870_op in H. discriminate H. Qed.

Lemma refa870_not846 : ~ @Equation846 Fin11 refa870_inst.
Proof. unfold Equation846. intro H. specialize (H F11_0 F11_1). unfold magma_op, refa870_inst, refa870_op in H. discriminate H. Qed.

Lemma refa870_not1023 : ~ @Equation1023 Fin11 refa870_inst.
Proof. unfold Equation1023. intro H. specialize (H F11_0 F11_1). unfold magma_op, refa870_inst, refa870_op in H. discriminate H. Qed.

Lemma refa870_not1038 : ~ @Equation1038 Fin11 refa870_inst.
Proof. unfold Equation1038. intro H. specialize (H F11_0 F11_1). unfold magma_op, refa870_inst, refa870_op in H. discriminate H. Qed.

Lemma refa870_not1048 : ~ @Equation1048 Fin11 refa870_inst.
Proof. unfold Equation1048. intro H. specialize (H F11_0 F11_1). unfold magma_op, refa870_inst, refa870_op in H. discriminate H. Qed.

Lemma refa870_not1238 : ~ @Equation1238 Fin11 refa870_inst.
Proof. unfold Equation1238. intro H. specialize (H F11_0 F11_1). unfold magma_op, refa870_inst, refa870_op in H. discriminate H. Qed.

Lemma refa870_not1834 : ~ @Equation1834 Fin11 refa870_inst.
Proof. unfold Equation1834. intro H. specialize (H F11_0 F11_1). unfold magma_op, refa870_inst, refa870_op in H. discriminate H. Qed.

Lemma refa870_not1847 : ~ @Equation1847 Fin11 refa870_inst.
Proof. unfold Equation1847. intro H. specialize (H F11_0 F11_1). unfold magma_op, refa870_inst, refa870_op in H. discriminate H. Qed.

Lemma refa870_not1850 : ~ @Equation1850 Fin11 refa870_inst.
Proof. unfold Equation1850. intro H. specialize (H F11_0 F11_1). unfold magma_op, refa870_inst, refa870_op in H. discriminate H. Qed.

Lemma refa870_not3255 : ~ @Equation3255 Fin11 refa870_inst.
Proof. unfold Equation3255. intro H. specialize (H F11_0 F11_1). unfold magma_op, refa870_inst, refa870_op in H. discriminate H. Qed.

Lemma refa870_not3935 : ~ @Equation3935 Fin11 refa870_inst.
Proof. unfold Equation3935. intro H. specialize (H F11_0 F11_2 F11_1). unfold magma_op, refa870_inst, refa870_op in H. discriminate H. Qed.

Lemma refa870_not4269 : ~ @Equation4269 Fin11 refa870_inst.
Proof. unfold Equation4269. intro H. specialize (H F11_0 F11_1). unfold magma_op, refa870_inst, refa870_op in H. discriminate H. Qed.

(** ---- refa871 (Fin5) ---- *)

Definition refa871_op (x y : Fin5) : Fin5 :=
  match x, y with
  | F5_0, F5_0 => F5_4 | F5_0, F5_1 => F5_1 | F5_0, F5_2 => F5_0 | F5_0, F5_3 => F5_0 | F5_0, F5_4 => F5_3
  | F5_1, F5_0 => F5_2 | F5_1, F5_1 => F5_1 | F5_1, F5_2 => F5_2 | F5_1, F5_3 => F5_2 | F5_1, F5_4 => F5_2
  | F5_2, F5_0 => F5_2 | F5_2, F5_1 => F5_1 | F5_2, F5_2 => F5_2 | F5_2, F5_3 => F5_2 | F5_2, F5_4 => F5_2
  | F5_3, F5_0 => F5_4 | F5_3, F5_1 => F5_1 | F5_3, F5_2 => F5_3 | F5_3, F5_3 => F5_0 | F5_3, F5_4 => F5_3
  | F5_4, F5_0 => F5_4 | F5_4, F5_1 => F5_1 | F5_4, F5_2 => F5_4 | F5_4, F5_3 => F5_0 | F5_4, F5_4 => F5_3
  end.

#[local] Instance refa871_inst : Magma Fin5 := {| magma_op := refa871_op |}.

Lemma refa871_sat856 : @Equation856 Fin5 refa871_inst.
Proof. unfold Equation856, magma_op, refa871_inst, refa871_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa871_not616 : ~ @Equation616 Fin5 refa871_inst.
Proof. unfold Equation616. intro H. specialize (H F5_0 F5_1). unfold magma_op, refa871_inst, refa871_op in H. discriminate H. Qed.

Lemma refa871_not1451 : ~ @Equation1451 Fin5 refa871_inst.
Proof. unfold Equation1451. intro H. specialize (H F5_0 F5_1). unfold magma_op, refa871_inst, refa871_op in H. discriminate H. Qed.

(** ---- refa872 (Fin7) ---- *)

Definition refa872_op (x y : Fin7) : Fin7 :=
  match x, y with
  | F7_0, F7_0 => F7_0 | F7_0, F7_1 => F7_4 | F7_0, F7_2 => F7_4 | F7_0, F7_3 => F7_0 | F7_0, F7_4 => F7_4 | F7_0, F7_5 => F7_0 | F7_0, F7_6 => F7_0
  | F7_1, F7_0 => F7_2 | F7_1, F7_1 => F7_2 | F7_1, F7_2 => F7_3 | F7_1, F7_3 => F7_1 | F7_1, F7_4 => F7_1 | F7_1, F7_5 => F7_3 | F7_1, F7_6 => F7_2
  | F7_2, F7_0 => F7_3 | F7_2, F7_1 => F7_2 | F7_2, F7_2 => F7_3 | F7_2, F7_3 => F7_6 | F7_2, F7_4 => F7_2 | F7_2, F7_5 => F7_3 | F7_2, F7_6 => F7_2
  | F7_3, F7_0 => F7_3 | F7_3, F7_1 => F7_2 | F7_3, F7_2 => F7_3 | F7_3, F7_3 => F7_6 | F7_3, F7_4 => F7_3 | F7_3, F7_5 => F7_3 | F7_3, F7_6 => F7_5
  | F7_4, F7_0 => F7_0 | F7_4, F7_1 => F7_4 | F7_4, F7_2 => F7_4 | F7_4, F7_3 => F7_4 | F7_4, F7_4 => F7_4 | F7_4, F7_5 => F7_4 | F7_4, F7_6 => F7_4
  | F7_5, F7_0 => F7_5 | F7_5, F7_1 => F7_5 | F7_5, F7_2 => F7_3 | F7_5, F7_3 => F7_6 | F7_5, F7_4 => F7_5 | F7_5, F7_5 => F7_3 | F7_5, F7_6 => F7_5
  | F7_6, F7_0 => F7_6 | F7_6, F7_1 => F7_5 | F7_6, F7_2 => F7_3 | F7_6, F7_3 => F7_6 | F7_6, F7_4 => F7_6 | F7_6, F7_5 => F7_3 | F7_6, F7_6 => F7_5
  end.

#[local] Instance refa872_inst : Magma Fin7 := {| magma_op := refa872_op |}.

Lemma refa872_sat856 : @Equation856 Fin7 refa872_inst.
Proof. unfold Equation856, magma_op, refa872_inst, refa872_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa872_not639 : ~ @Equation639 Fin7 refa872_inst.
Proof. unfold Equation639. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa872_inst, refa872_op in H. discriminate H. Qed.

Lemma refa872_not642 : ~ @Equation642 Fin7 refa872_inst.
Proof. unfold Equation642. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa872_inst, refa872_op in H. discriminate H. Qed.

Lemma refa872_not842 : ~ @Equation842 Fin7 refa872_inst.
Proof. unfold Equation842. intro H. specialize (H F7_2 F7_0). unfold magma_op, refa872_inst, refa872_op in H. discriminate H. Qed.

Lemma refa872_not1426 : ~ @Equation1426 Fin7 refa872_inst.
Proof. unfold Equation1426. intro H. specialize (H F7_1). unfold magma_op, refa872_inst, refa872_op in H. discriminate H. Qed.

Lemma refa872_not4131 : ~ @Equation4131 Fin7 refa872_inst.
Proof. unfold Equation4131. intro H. specialize (H F7_1 F7_0). unfold magma_op, refa872_inst, refa872_op in H. discriminate H. Qed.

(** ---- refa873 (Fin6) ---- *)

Definition refa873_op (x y : Fin6) : Fin6 :=
  match x, y with
  | F6_0, F6_0 => F6_0 | F6_0, F6_1 => F6_2 | F6_0, F6_2 => F6_2 | F6_0, F6_3 => F6_0 | F6_0, F6_4 => F6_0 | F6_0, F6_5 => F6_0
  | F6_1, F6_0 => F6_1 | F6_1, F6_1 => F6_4 | F6_1, F6_2 => F6_1 | F6_1, F6_3 => F6_4 | F6_1, F6_4 => F6_5 | F6_1, F6_5 => F6_1
  | F6_2, F6_0 => F6_0 | F6_2, F6_1 => F6_0 | F6_2, F6_2 => F6_2 | F6_2, F6_3 => F6_2 | F6_2, F6_4 => F6_2 | F6_2, F6_5 => F6_2
  | F6_3, F6_0 => F6_3 | F6_3, F6_1 => F6_4 | F6_3, F6_2 => F6_3 | F6_3, F6_3 => F6_4 | F6_3, F6_4 => F6_5 | F6_3, F6_5 => F6_3
  | F6_4, F6_0 => F6_4 | F6_4, F6_1 => F6_4 | F6_4, F6_2 => F6_4 | F6_4, F6_3 => F6_4 | F6_4, F6_4 => F6_5 | F6_4, F6_5 => F6_3
  | F6_5, F6_0 => F6_5 | F6_5, F6_1 => F6_4 | F6_5, F6_2 => F6_5 | F6_5, F6_3 => F6_4 | F6_5, F6_4 => F6_5 | F6_5, F6_5 => F6_3
  end.

#[local] Instance refa873_inst : Magma Fin6 := {| magma_op := refa873_op |}.

Lemma refa873_sat856 : @Equation856 Fin6 refa873_inst.
Proof. unfold Equation856, magma_op, refa873_inst, refa873_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa873_not378 : ~ @Equation378 Fin6 refa873_inst.
Proof. unfold Equation378. intro H. specialize (H F6_0 F6_1). unfold magma_op, refa873_inst, refa873_op in H. discriminate H. Qed.

Lemma refa873_not629 : ~ @Equation629 Fin6 refa873_inst.
Proof. unfold Equation629. intro H. specialize (H F6_0 F6_1). unfold magma_op, refa873_inst, refa873_op in H. discriminate H. Qed.

Lemma refa873_not632 : ~ @Equation632 Fin6 refa873_inst.
Proof. unfold Equation632. intro H. specialize (H F6_0 F6_1). unfold magma_op, refa873_inst, refa873_op in H. discriminate H. Qed.

Lemma refa873_not832 : ~ @Equation832 Fin6 refa873_inst.
Proof. unfold Equation832. intro H. specialize (H F6_0 F6_1). unfold magma_op, refa873_inst, refa873_op in H. discriminate H. Qed.

(** ---- refa874 (Fin6) ---- *)

Definition refa874_op (x y : Fin6) : Fin6 :=
  match x, y with
  | F6_0, F6_0 => F6_1 | F6_0, F6_1 => F6_3 | F6_0, F6_2 => F6_4 | F6_0, F6_3 => F6_0 | F6_0, F6_4 => F6_5 | F6_0, F6_5 => F6_2
  | F6_1, F6_0 => F6_2 | F6_1, F6_1 => F6_3 | F6_1, F6_2 => F6_4 | F6_1, F6_3 => F6_5 | F6_1, F6_4 => F6_0 | F6_1, F6_5 => F6_1
  | F6_2, F6_0 => F6_2 | F6_2, F6_1 => F6_3 | F6_2, F6_2 => F6_4 | F6_2, F6_3 => F6_5 | F6_2, F6_4 => F6_0 | F6_2, F6_5 => F6_1
  | F6_3, F6_0 => F6_1 | F6_3, F6_1 => F6_4 | F6_3, F6_2 => F6_3 | F6_3, F6_3 => F6_5 | F6_3, F6_4 => F6_0 | F6_3, F6_5 => F6_2
  | F6_4, F6_0 => F6_1 | F6_4, F6_1 => F6_4 | F6_4, F6_2 => F6_3 | F6_4, F6_3 => F6_5 | F6_4, F6_4 => F6_0 | F6_4, F6_5 => F6_2
  | F6_5, F6_0 => F6_1 | F6_5, F6_1 => F6_3 | F6_5, F6_2 => F6_4 | F6_5, F6_3 => F6_0 | F6_5, F6_4 => F6_5 | F6_5, F6_5 => F6_2
  end.

#[local] Instance refa874_inst : Magma Fin6 := {| magma_op := refa874_op |}.

Lemma refa874_sat860 : @Equation860 Fin6 refa874_inst.
Proof. unfold Equation860, magma_op, refa874_inst, refa874_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa874_not1426 : ~ @Equation1426 Fin6 refa874_inst.
Proof. unfold Equation1426. intro H. specialize (H F6_0). unfold magma_op, refa874_inst, refa874_op in H. discriminate H. Qed.

Lemma refa874_not4065 : ~ @Equation4065 Fin6 refa874_inst.
Proof. unfold Equation4065. intro H. specialize (H F6_0). unfold magma_op, refa874_inst, refa874_op in H. discriminate H. Qed.

(** ---- refa875 (Fin7) ---- *)

Definition refa875_op (x y : Fin7) : Fin7 :=
  match x, y with
  | F7_0, F7_0 => F7_1 | F7_0, F7_1 => F7_5 | F7_0, F7_2 => F7_6 | F7_0, F7_3 => F7_3 | F7_0, F7_4 => F7_0 | F7_0, F7_5 => F7_2 | F7_0, F7_6 => F7_4
  | F7_1, F7_0 => F7_2 | F7_1, F7_1 => F7_4 | F7_1, F7_2 => F7_3 | F7_1, F7_3 => F7_1 | F7_1, F7_4 => F7_6 | F7_1, F7_5 => F7_5 | F7_1, F7_6 => F7_0
  | F7_2, F7_0 => F7_3 | F7_2, F7_1 => F7_2 | F7_2, F7_2 => F7_0 | F7_2, F7_3 => F7_6 | F7_2, F7_4 => F7_4 | F7_2, F7_5 => F7_1 | F7_2, F7_6 => F7_5
  | F7_3, F7_0 => F7_4 | F7_3, F7_1 => F7_6 | F7_3, F7_2 => F7_2 | F7_3, F7_3 => F7_5 | F7_3, F7_4 => F7_1 | F7_3, F7_5 => F7_0 | F7_3, F7_6 => F7_3
  | F7_4, F7_0 => F7_5 | F7_4, F7_1 => F7_0 | F7_4, F7_2 => F7_1 | F7_4, F7_3 => F7_2 | F7_4, F7_4 => F7_3 | F7_4, F7_5 => F7_4 | F7_4, F7_6 => F7_6
  | F7_5, F7_0 => F7_0 | F7_5, F7_1 => F7_3 | F7_5, F7_2 => F7_5 | F7_5, F7_3 => F7_4 | F7_5, F7_4 => F7_2 | F7_5, F7_5 => F7_6 | F7_5, F7_6 => F7_1
  | F7_6, F7_0 => F7_6 | F7_6, F7_1 => F7_1 | F7_6, F7_2 => F7_4 | F7_6, F7_3 => F7_0 | F7_6, F7_4 => F7_5 | F7_6, F7_5 => F7_3 | F7_6, F7_6 => F7_2
  end.

#[local] Instance refa875_inst : Magma Fin7 := {| magma_op := refa875_op |}.

Lemma refa875_sat880 : @Equation880 Fin7 refa875_inst.
Proof. unfold Equation880, magma_op, refa875_inst, refa875_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa875_not1223 : ~ @Equation1223 Fin7 refa875_inst.
Proof. unfold Equation1223. intro H. specialize (H F7_0). unfold magma_op, refa875_inst, refa875_op in H. discriminate H. Qed.

(** ---- refa876 (Fin5) ---- *)

Definition refa876_op (x y : Fin5) : Fin5 :=
  match x, y with
  | F5_0, F5_0 => F5_2 | F5_0, F5_1 => F5_1 | F5_0, F5_2 => F5_3 | F5_0, F5_3 => F5_0 | F5_0, F5_4 => F5_4
  | F5_1, F5_0 => F5_2 | F5_1, F5_1 => F5_1 | F5_1, F5_2 => F5_3 | F5_1, F5_3 => F5_0 | F5_1, F5_4 => F5_4
  | F5_2, F5_0 => F5_2 | F5_2, F5_1 => F5_4 | F5_2, F5_2 => F5_3 | F5_2, F5_3 => F5_0 | F5_2, F5_4 => F5_1
  | F5_3, F5_0 => F5_2 | F5_3, F5_1 => F5_4 | F5_3, F5_2 => F5_3 | F5_3, F5_3 => F5_0 | F5_3, F5_4 => F5_1
  | F5_4, F5_0 => F5_2 | F5_4, F5_1 => F5_4 | F5_4, F5_2 => F5_3 | F5_4, F5_3 => F5_0 | F5_4, F5_4 => F5_1
  end.

#[local] Instance refa876_inst : Magma Fin5 := {| magma_op := refa876_op |}.

Lemma refa876_sat906 : @Equation906 Fin5 refa876_inst.
Proof. unfold Equation906, magma_op, refa876_inst, refa876_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa876_not3915 : ~ @Equation3915 Fin5 refa876_inst.
Proof. unfold Equation3915. intro H. specialize (H F5_0 F5_1). unfold magma_op, refa876_inst, refa876_op in H. discriminate H. Qed.

(** ---- refa877 (Fin7) ---- *)

Definition refa877_op (x y : Fin7) : Fin7 :=
  match x, y with
  | F7_0, F7_0 => F7_5 | F7_0, F7_1 => F7_6 | F7_0, F7_2 => F7_3 | F7_0, F7_3 => F7_2 | F7_0, F7_4 => F7_4 | F7_0, F7_5 => F7_0 | F7_0, F7_6 => F7_1
  | F7_1, F7_0 => F7_3 | F7_1, F7_1 => F7_2 | F7_1, F7_2 => F7_6 | F7_1, F7_3 => F7_4 | F7_1, F7_4 => F7_0 | F7_1, F7_5 => F7_1 | F7_1, F7_6 => F7_5
  | F7_2, F7_0 => F7_6 | F7_2, F7_1 => F7_1 | F7_2, F7_2 => F7_5 | F7_2, F7_3 => F7_3 | F7_2, F7_4 => F7_4 | F7_2, F7_5 => F7_2 | F7_2, F7_6 => F7_0
  | F7_3, F7_0 => F7_0 | F7_3, F7_1 => F7_1 | F7_3, F7_2 => F7_4 | F7_3, F7_3 => F7_5 | F7_3, F7_4 => F7_2 | F7_3, F7_5 => F7_3 | F7_3, F7_6 => F7_6
  | F7_4, F7_0 => F7_2 | F7_4, F7_1 => F7_3 | F7_4, F7_2 => F7_0 | F7_4, F7_3 => F7_1 | F7_4, F7_4 => F7_5 | F7_4, F7_5 => F7_4 | F7_4, F7_6 => F7_6
  | F7_5, F7_0 => F7_0 | F7_5, F7_1 => F7_1 | F7_5, F7_2 => F7_2 | F7_5, F7_3 => F7_3 | F7_5, F7_4 => F7_6 | F7_5, F7_5 => F7_5 | F7_5, F7_6 => F7_4
  | F7_6, F7_0 => F7_3 | F7_6, F7_1 => F7_5 | F7_6, F7_2 => F7_1 | F7_6, F7_3 => F7_4 | F7_6, F7_4 => F7_0 | F7_6, F7_5 => F7_6 | F7_6, F7_6 => F7_2
  end.

#[local] Instance refa877_inst : Magma Fin7 := {| magma_op := refa877_op |}.

Lemma refa877_sat910 : @Equation910 Fin7 refa877_inst.
Proof. unfold Equation910, magma_op, refa877_inst, refa877_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa877_not513 : ~ @Equation513 Fin7 refa877_inst.
Proof. unfold Equation513. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa877_inst, refa877_op in H. discriminate H. Qed.

Lemma refa877_not917 : ~ @Equation917 Fin7 refa877_inst.
Proof. unfold Equation917. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa877_inst, refa877_op in H. discriminate H. Qed.

Lemma refa877_not1861 : ~ @Equation1861 Fin7 refa877_inst.
Proof. unfold Equation1861. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa877_inst, refa877_op in H. discriminate H. Qed.

Lemma refa877_not2441 : ~ @Equation2441 Fin7 refa877_inst.
Proof. unfold Equation2441. intro H. specialize (H F7_4). unfold magma_op, refa877_inst, refa877_op in H. discriminate H. Qed.

Lemma refa877_not4290 : ~ @Equation4290 Fin7 refa877_inst.
Proof. unfold Equation4290. intro H. specialize (H F7_1 F7_0). unfold magma_op, refa877_inst, refa877_op in H. discriminate H. Qed.

(** ---- refa878 (Fin7) ---- *)

Definition refa878_op (x y : Fin7) : Fin7 :=
  match x, y with
  | F7_0, F7_0 => F7_0 | F7_0, F7_1 => F7_2 | F7_0, F7_2 => F7_5 | F7_0, F7_3 => F7_6 | F7_0, F7_4 => F7_3 | F7_0, F7_5 => F7_1 | F7_0, F7_6 => F7_4
  | F7_1, F7_0 => F7_2 | F7_1, F7_1 => F7_1 | F7_1, F7_2 => F7_3 | F7_1, F7_3 => F7_0 | F7_1, F7_4 => F7_6 | F7_1, F7_5 => F7_4 | F7_1, F7_6 => F7_5
  | F7_2, F7_0 => F7_5 | F7_2, F7_1 => F7_3 | F7_2, F7_2 => F7_2 | F7_2, F7_3 => F7_4 | F7_2, F7_4 => F7_1 | F7_2, F7_5 => F7_6 | F7_2, F7_6 => F7_0
  | F7_3, F7_0 => F7_6 | F7_3, F7_1 => F7_0 | F7_3, F7_2 => F7_4 | F7_3, F7_3 => F7_3 | F7_3, F7_4 => F7_5 | F7_3, F7_5 => F7_2 | F7_3, F7_6 => F7_1
  | F7_4, F7_0 => F7_3 | F7_4, F7_1 => F7_6 | F7_4, F7_2 => F7_1 | F7_4, F7_3 => F7_5 | F7_4, F7_4 => F7_4 | F7_4, F7_5 => F7_0 | F7_4, F7_6 => F7_2
  | F7_5, F7_0 => F7_1 | F7_5, F7_1 => F7_4 | F7_5, F7_2 => F7_6 | F7_5, F7_3 => F7_2 | F7_5, F7_4 => F7_0 | F7_5, F7_5 => F7_5 | F7_5, F7_6 => F7_3
  | F7_6, F7_0 => F7_4 | F7_6, F7_1 => F7_5 | F7_6, F7_2 => F7_0 | F7_6, F7_3 => F7_1 | F7_6, F7_4 => F7_2 | F7_6, F7_5 => F7_3 | F7_6, F7_6 => F7_6
  end.

#[local] Instance refa878_inst : Magma Fin7 := {| magma_op := refa878_op |}.

Lemma refa878_sat704 : @Equation704 Fin7 refa878_inst.
Proof. unfold Equation704, magma_op, refa878_inst, refa878_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa878_sat1110 : @Equation1110 Fin7 refa878_inst.
Proof. unfold Equation1110, magma_op, refa878_inst, refa878_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa878_sat1279 : @Equation1279 Fin7 refa878_inst.
Proof. unfold Equation1279, magma_op, refa878_inst, refa878_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa878_sat2328 : @Equation2328 Fin7 refa878_inst.
Proof. unfold Equation2328, magma_op, refa878_inst, refa878_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa878_sat2497 : @Equation2497 Fin7 refa878_inst.
Proof. unfold Equation2497, magma_op, refa878_inst, refa878_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa878_sat2737 : @Equation2737 Fin7 refa878_inst.
Proof. unfold Equation2737, magma_op, refa878_inst, refa878_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa878_sat2903 : @Equation2903 Fin7 refa878_inst.
Proof. unfold Equation2903, magma_op, refa878_inst, refa878_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa878_sat3475 : @Equation3475 Fin7 refa878_inst.
Proof. unfold Equation3475, magma_op, refa878_inst, refa878_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa878_sat3888 : @Equation3888 Fin7 refa878_inst.
Proof. unfold Equation3888, magma_op, refa878_inst, refa878_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa878_not56 : ~ @Equation56 Fin7 refa878_inst.
Proof. unfold Equation56. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa878_inst, refa878_op in H. discriminate H. Qed.

Lemma refa878_not108 : ~ @Equation108 Fin7 refa878_inst.
Proof. unfold Equation108. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa878_inst, refa878_op in H. discriminate H. Qed.

Lemma refa878_not115 : ~ @Equation115 Fin7 refa878_inst.
Proof. unfold Equation115. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa878_inst, refa878_op in H. discriminate H. Qed.

Lemma refa878_not117 : ~ @Equation117 Fin7 refa878_inst.
Proof. unfold Equation117. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa878_inst, refa878_op in H. discriminate H. Qed.

Lemma refa878_not159 : ~ @Equation159 Fin7 refa878_inst.
Proof. unfold Equation159. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa878_inst, refa878_op in H. discriminate H. Qed.

Lemma refa878_not231 : ~ @Equation231 Fin7 refa878_inst.
Proof. unfold Equation231. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa878_inst, refa878_op in H. discriminate H. Qed.

Lemma refa878_not417 : ~ @Equation417 Fin7 refa878_inst.
Proof. unfold Equation417. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa878_inst, refa878_op in H. discriminate H. Qed.

Lemma refa878_not429 : ~ @Equation429 Fin7 refa878_inst.
Proof. unfold Equation429. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa878_inst, refa878_op in H. discriminate H. Qed.

Lemma refa878_not440 : ~ @Equation440 Fin7 refa878_inst.
Proof. unfold Equation440. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa878_inst, refa878_op in H. discriminate H. Qed.

Lemma refa878_not467 : ~ @Equation467 Fin7 refa878_inst.
Proof. unfold Equation467. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa878_inst, refa878_op in H. discriminate H. Qed.

Lemma refa878_not473 : ~ @Equation473 Fin7 refa878_inst.
Proof. unfold Equation473. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa878_inst, refa878_op in H. discriminate H. Qed.

Lemma refa878_not476 : ~ @Equation476 Fin7 refa878_inst.
Proof. unfold Equation476. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa878_inst, refa878_op in H. discriminate H. Qed.

Lemma refa878_not513 : ~ @Equation513 Fin7 refa878_inst.
Proof. unfold Equation513. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa878_inst, refa878_op in H. discriminate H. Qed.

Lemma refa878_not676 : ~ @Equation676 Fin7 refa878_inst.
Proof. unfold Equation676. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa878_inst, refa878_op in H. discriminate H. Qed.

Lemma refa878_not825 : ~ @Equation825 Fin7 refa878_inst.
Proof. unfold Equation825. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa878_inst, refa878_op in H. discriminate H. Qed.

Lemma refa878_not1082 : ~ @Equation1082 Fin7 refa878_inst.
Proof. unfold Equation1082. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa878_inst, refa878_op in H. discriminate H. Qed.

Lemma refa878_not1239 : ~ @Equation1239 Fin7 refa878_inst.
Proof. unfold Equation1239. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa878_inst, refa878_op in H. discriminate H. Qed.

Lemma refa878_not1285 : ~ @Equation1285 Fin7 refa878_inst.
Proof. unfold Equation1285. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa878_inst, refa878_op in H. discriminate H. Qed.

Lemma refa878_not1451 : ~ @Equation1451 Fin7 refa878_inst.
Proof. unfold Equation1451. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa878_inst, refa878_op in H. discriminate H. Qed.

Lemma refa878_not1479 : ~ @Equation1479 Fin7 refa878_inst.
Proof. unfold Equation1479. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa878_inst, refa878_op in H. discriminate H. Qed.

Lemma refa878_not1525 : ~ @Equation1525 Fin7 refa878_inst.
Proof. unfold Equation1525. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa878_inst, refa878_op in H. discriminate H. Qed.

Lemma refa878_not1657 : ~ @Equation1657 Fin7 refa878_inst.
Proof. unfold Equation1657. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa878_inst, refa878_op in H. discriminate H. Qed.

Lemma refa878_not1685 : ~ @Equation1685 Fin7 refa878_inst.
Proof. unfold Equation1685. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa878_inst, refa878_op in H. discriminate H. Qed.

Lemma refa878_not1692 : ~ @Equation1692 Fin7 refa878_inst.
Proof. unfold Equation1692. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa878_inst, refa878_op in H. discriminate H. Qed.

Lemma refa878_not1731 : ~ @Equation1731 Fin7 refa878_inst.
Proof. unfold Equation1731. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa878_inst, refa878_op in H. discriminate H. Qed.

Lemma refa878_not1860 : ~ @Equation1860 Fin7 refa878_inst.
Proof. unfold Equation1860. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa878_inst, refa878_op in H. discriminate H. Qed.

Lemma refa878_not1861 : ~ @Equation1861 Fin7 refa878_inst.
Proof. unfold Equation1861. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa878_inst, refa878_op in H. discriminate H. Qed.

Lemma refa878_not1895 : ~ @Equation1895 Fin7 refa878_inst.
Proof. unfold Equation1895. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa878_inst, refa878_op in H. discriminate H. Qed.

Lemma refa878_not1922 : ~ @Equation1922 Fin7 refa878_inst.
Proof. unfold Equation1922. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa878_inst, refa878_op in H. discriminate H. Qed.

Lemma refa878_not2043 : ~ @Equation2043 Fin7 refa878_inst.
Proof. unfold Equation2043. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa878_inst, refa878_op in H. discriminate H. Qed.

Lemma refa878_not2044 : ~ @Equation2044 Fin7 refa878_inst.
Proof. unfold Equation2044. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa878_inst, refa878_op in H. discriminate H. Qed.

Lemma refa878_not2088 : ~ @Equation2088 Fin7 refa878_inst.
Proof. unfold Equation2088. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa878_inst, refa878_op in H. discriminate H. Qed.

Lemma refa878_not2091 : ~ @Equation2091 Fin7 refa878_inst.
Proof. unfold Equation2091. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa878_inst, refa878_op in H. discriminate H. Qed.

Lemma refa878_not2098 : ~ @Equation2098 Fin7 refa878_inst.
Proof. unfold Equation2098. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa878_inst, refa878_op in H. discriminate H. Qed.

Lemma refa878_not2137 : ~ @Equation2137 Fin7 refa878_inst.
Proof. unfold Equation2137. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa878_inst, refa878_op in H. discriminate H. Qed.

Lemma refa878_not2241 : ~ @Equation2241 Fin7 refa878_inst.
Proof. unfold Equation2241. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa878_inst, refa878_op in H. discriminate H. Qed.

Lemma refa878_not2267 : ~ @Equation2267 Fin7 refa878_inst.
Proof. unfold Equation2267. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa878_inst, refa878_op in H. discriminate H. Qed.

Lemma refa878_not2293 : ~ @Equation2293 Fin7 refa878_inst.
Proof. unfold Equation2293. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa878_inst, refa878_op in H. discriminate H. Qed.

Lemma refa878_not2450 : ~ @Equation2450 Fin7 refa878_inst.
Proof. unfold Equation2450. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa878_inst, refa878_op in H. discriminate H. Qed.

Lemma refa878_not2669 : ~ @Equation2669 Fin7 refa878_inst.
Proof. unfold Equation2669. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa878_inst, refa878_op in H. discriminate H. Qed.

Lemma refa878_not2697 : ~ @Equation2697 Fin7 refa878_inst.
Proof. unfold Equation2697. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa878_inst, refa878_op in H. discriminate H. Qed.

Lemma refa878_not2746 : ~ @Equation2746 Fin7 refa878_inst.
Proof. unfold Equation2746. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa878_inst, refa878_op in H. discriminate H. Qed.

Lemma refa878_not2866 : ~ @Equation2866 Fin7 refa878_inst.
Proof. unfold Equation2866. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa878_inst, refa878_op in H. discriminate H. Qed.

Lemma refa878_not2900 : ~ @Equation2900 Fin7 refa878_inst.
Proof. unfold Equation2900. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa878_inst, refa878_op in H. discriminate H. Qed.

Lemma refa878_not3069 : ~ @Equation3069 Fin7 refa878_inst.
Proof. unfold Equation3069. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa878_inst, refa878_op in H. discriminate H. Qed.

Lemma refa878_not3079 : ~ @Equation3079 Fin7 refa878_inst.
Proof. unfold Equation3079. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa878_inst, refa878_op in H. discriminate H. Qed.

Lemma refa878_not3105 : ~ @Equation3105 Fin7 refa878_inst.
Proof. unfold Equation3105. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa878_inst, refa878_op in H. discriminate H. Qed.

Lemma refa878_not3140 : ~ @Equation3140 Fin7 refa878_inst.
Proof. unfold Equation3140. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa878_inst, refa878_op in H. discriminate H. Qed.

Lemma refa878_not3152 : ~ @Equation3152 Fin7 refa878_inst.
Proof. unfold Equation3152. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa878_inst, refa878_op in H. discriminate H. Qed.

Lemma refa878_not3345 : ~ @Equation3345 Fin7 refa878_inst.
Proof. unfold Equation3345. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa878_inst, refa878_op in H. discriminate H. Qed.

Lemma refa878_not3458 : ~ @Equation3458 Fin7 refa878_inst.
Proof. unfold Equation3458. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa878_inst, refa878_op in H. discriminate H. Qed.

Lemma refa878_not3461 : ~ @Equation3461 Fin7 refa878_inst.
Proof. unfold Equation3461. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa878_inst, refa878_op in H. discriminate H. Qed.

Lemma refa878_not3464 : ~ @Equation3464 Fin7 refa878_inst.
Proof. unfold Equation3464. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa878_inst, refa878_op in H. discriminate H. Qed.

Lemma refa878_not3472 : ~ @Equation3472 Fin7 refa878_inst.
Proof. unfold Equation3472. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa878_inst, refa878_op in H. discriminate H. Qed.

Lemma refa878_not3548 : ~ @Equation3548 Fin7 refa878_inst.
Proof. unfold Equation3548. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa878_inst, refa878_op in H. discriminate H. Qed.

Lemma refa878_not3660 : ~ @Equation3660 Fin7 refa878_inst.
Proof. unfold Equation3660. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa878_inst, refa878_op in H. discriminate H. Qed.

Lemma refa878_not3661 : ~ @Equation3661 Fin7 refa878_inst.
Proof. unfold Equation3661. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa878_inst, refa878_op in H. discriminate H. Qed.

Lemma refa878_not3662 : ~ @Equation3662 Fin7 refa878_inst.
Proof. unfold Equation3662. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa878_inst, refa878_op in H. discriminate H. Qed.

Lemma refa878_not3665 : ~ @Equation3665 Fin7 refa878_inst.
Proof. unfold Equation3665. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa878_inst, refa878_op in H. discriminate H. Qed.

Lemma refa878_not3667 : ~ @Equation3667 Fin7 refa878_inst.
Proof. unfold Equation3667. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa878_inst, refa878_op in H. discriminate H. Qed.

Lemma refa878_not3677 : ~ @Equation3677 Fin7 refa878_inst.
Proof. unfold Equation3677. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa878_inst, refa878_op in H. discriminate H. Qed.

Lemma refa878_not3684 : ~ @Equation3684 Fin7 refa878_inst.
Proof. unfold Equation3684. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa878_inst, refa878_op in H. discriminate H. Qed.

Lemma refa878_not3685 : ~ @Equation3685 Fin7 refa878_inst.
Proof. unfold Equation3685. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa878_inst, refa878_op in H. discriminate H. Qed.

Lemma refa878_not3687 : ~ @Equation3687 Fin7 refa878_inst.
Proof. unfold Equation3687. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa878_inst, refa878_op in H. discriminate H. Qed.

Lemma refa878_not3721 : ~ @Equation3721 Fin7 refa878_inst.
Proof. unfold Equation3721. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa878_inst, refa878_op in H. discriminate H. Qed.

Lemma refa878_not3725 : ~ @Equation3725 Fin7 refa878_inst.
Proof. unfold Equation3725. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa878_inst, refa878_op in H. discriminate H. Qed.

Lemma refa878_not3864 : ~ @Equation3864 Fin7 refa878_inst.
Proof. unfold Equation3864. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa878_inst, refa878_op in H. discriminate H. Qed.

Lemma refa878_not3867 : ~ @Equation3867 Fin7 refa878_inst.
Proof. unfold Equation3867. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa878_inst, refa878_op in H. discriminate H. Qed.

Lemma refa878_not3870 : ~ @Equation3870 Fin7 refa878_inst.
Proof. unfold Equation3870. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa878_inst, refa878_op in H. discriminate H. Qed.

Lemma refa878_not3878 : ~ @Equation3878 Fin7 refa878_inst.
Proof. unfold Equation3878. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa878_inst, refa878_op in H. discriminate H. Qed.

Lemma refa878_not3961 : ~ @Equation3961 Fin7 refa878_inst.
Proof. unfold Equation3961. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa878_inst, refa878_op in H. discriminate H. Qed.

Lemma refa878_not4081 : ~ @Equation4081 Fin7 refa878_inst.
Proof. unfold Equation4081. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa878_inst, refa878_op in H. discriminate H. Qed.

Lemma refa878_not4154 : ~ @Equation4154 Fin7 refa878_inst.
Proof. unfold Equation4154. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa878_inst, refa878_op in H. discriminate H. Qed.

Lemma refa878_not4270 : ~ @Equation4270 Fin7 refa878_inst.
Proof. unfold Equation4270. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa878_inst, refa878_op in H. discriminate H. Qed.

Lemma refa878_not4276 : ~ @Equation4276 Fin7 refa878_inst.
Proof. unfold Equation4276. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa878_inst, refa878_op in H. discriminate H. Qed.

Lemma refa878_not4320 : ~ @Equation4320 Fin7 refa878_inst.
Proof. unfold Equation4320. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa878_inst, refa878_op in H. discriminate H. Qed.

Lemma refa878_not4321 : ~ @Equation4321 Fin7 refa878_inst.
Proof. unfold Equation4321. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa878_inst, refa878_op in H. discriminate H. Qed.

Lemma refa878_not4399 : ~ @Equation4399 Fin7 refa878_inst.
Proof. unfold Equation4399. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa878_inst, refa878_op in H. discriminate H. Qed.

Lemma refa878_not4591 : ~ @Equation4591 Fin7 refa878_inst.
Proof. unfold Equation4591. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa878_inst, refa878_op in H. discriminate H. Qed.

Lemma refa878_not4598 : ~ @Equation4598 Fin7 refa878_inst.
Proof. unfold Equation4598. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa878_inst, refa878_op in H. discriminate H. Qed.

Lemma refa878_not4605 : ~ @Equation4605 Fin7 refa878_inst.
Proof. unfold Equation4605. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa878_inst, refa878_op in H. discriminate H. Qed.

Lemma refa878_not4622 : ~ @Equation4622 Fin7 refa878_inst.
Proof. unfold Equation4622. intro H. specialize (H F7_0 F7_0 F7_1). unfold magma_op, refa878_inst, refa878_op in H. discriminate H. Qed.

Lemma refa878_not4636 : ~ @Equation4636 Fin7 refa878_inst.
Proof. unfold Equation4636. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa878_inst, refa878_op in H. discriminate H. Qed.

(** ---- refa879 (Fin7) ---- *)

Definition refa879_op (x y : Fin7) : Fin7 :=
  match x, y with
  | F7_0, F7_0 => F7_2 | F7_0, F7_1 => F7_6 | F7_0, F7_2 => F7_5 | F7_0, F7_3 => F7_4 | F7_0, F7_4 => F7_1 | F7_0, F7_5 => F7_0 | F7_0, F7_6 => F7_3
  | F7_1, F7_0 => F7_2 | F7_1, F7_1 => F7_6 | F7_1, F7_2 => F7_3 | F7_1, F7_3 => F7_5 | F7_1, F7_4 => F7_1 | F7_1, F7_5 => F7_0 | F7_1, F7_6 => F7_4
  | F7_2, F7_0 => F7_2 | F7_2, F7_1 => F7_3 | F7_2, F7_2 => F7_5 | F7_2, F7_3 => F7_6 | F7_2, F7_4 => F7_1 | F7_2, F7_5 => F7_0 | F7_2, F7_6 => F7_4
  | F7_3, F7_0 => F7_4 | F7_3, F7_1 => F7_0 | F7_3, F7_2 => F7_1 | F7_3, F7_3 => F7_3 | F7_3, F7_4 => F7_5 | F7_3, F7_5 => F7_6 | F7_3, F7_6 => F7_2
  | F7_4, F7_0 => F7_2 | F7_4, F7_1 => F7_6 | F7_4, F7_2 => F7_5 | F7_4, F7_3 => F7_0 | F7_4, F7_4 => F7_1 | F7_4, F7_5 => F7_3 | F7_4, F7_6 => F7_4
  | F7_5, F7_0 => F7_2 | F7_5, F7_1 => F7_6 | F7_5, F7_2 => F7_5 | F7_5, F7_3 => F7_1 | F7_5, F7_4 => F7_3 | F7_5, F7_5 => F7_0 | F7_5, F7_6 => F7_4
  | F7_6, F7_0 => F7_3 | F7_6, F7_1 => F7_6 | F7_6, F7_2 => F7_5 | F7_6, F7_3 => F7_2 | F7_6, F7_4 => F7_1 | F7_6, F7_5 => F7_0 | F7_6, F7_6 => F7_4
  end.

#[local] Instance refa879_inst : Magma Fin7 := {| magma_op := refa879_op |}.

Lemma refa879_sat916 : @Equation916 Fin7 refa879_inst.
Proof. unfold Equation916, magma_op, refa879_inst, refa879_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa879_not3887 : ~ @Equation3887 Fin7 refa879_inst.
Proof. unfold Equation3887. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa879_inst, refa879_op in H. discriminate H. Qed.

Lemma refa879_not3915 : ~ @Equation3915 Fin7 refa879_inst.
Proof. unfold Equation3915. intro H. specialize (H F7_0 F7_3). unfold magma_op, refa879_inst, refa879_op in H. discriminate H. Qed.

Lemma refa879_not3962 : ~ @Equation3962 Fin7 refa879_inst.
Proof. unfold Equation3962. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa879_inst, refa879_op in H. discriminate H. Qed.

Lemma refa879_not4275 : ~ @Equation4275 Fin7 refa879_inst.
Proof. unfold Equation4275. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa879_inst, refa879_op in H. discriminate H. Qed.

(** ---- refa88 (Fin3) ---- *)

Definition refa88_op (x y : Fin3) : Fin3 :=
  match x, y with
  | F3_0, F3_0 => F3_0 | F3_0, F3_1 => F3_0 | F3_0, F3_2 => F3_2
  | F3_1, F3_0 => F3_2 | F3_1, F3_1 => F3_2 | F3_1, F3_2 => F3_1
  | F3_2, F3_0 => F3_1 | F3_2, F3_1 => F3_0 | F3_2, F3_2 => F3_1
  end.

#[local] Instance refa88_inst : Magma Fin3 := {| magma_op := refa88_op |}.

Lemma refa88_sat1655 : @Equation1655 Fin3 refa88_inst.
Proof. unfold Equation1655, magma_op, refa88_inst, refa88_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa88_sat3261 : @Equation3261 Fin3 refa88_inst.
Proof. unfold Equation3261, magma_op, refa88_inst, refa88_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa88_not1832 : ~ @Equation1832 Fin3 refa88_inst.
Proof. unfold Equation1832. intro H. specialize (H F3_2). unfold magma_op, refa88_inst, refa88_op in H. discriminate H. Qed.

Lemma refa88_not2238 : ~ @Equation2238 Fin3 refa88_inst.
Proof. unfold Equation2238. intro H. specialize (H F3_1). unfold magma_op, refa88_inst, refa88_op in H. discriminate H. Qed.

Lemma refa88_not2441 : ~ @Equation2441 Fin3 refa88_inst.
Proof. unfold Equation2441. intro H. specialize (H F3_1). unfold magma_op, refa88_inst, refa88_op in H. discriminate H. Qed.

Lemma refa88_not3050 : ~ @Equation3050 Fin3 refa88_inst.
Proof. unfold Equation3050. intro H. specialize (H F3_1). unfold magma_op, refa88_inst, refa88_op in H. discriminate H. Qed.

Lemma refa88_not3254 : ~ @Equation3254 Fin3 refa88_inst.
Proof. unfold Equation3254. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa88_inst, refa88_op in H. discriminate H. Qed.

Lemma refa88_not3255 : ~ @Equation3255 Fin3 refa88_inst.
Proof. unfold Equation3255. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa88_inst, refa88_op in H. discriminate H. Qed.

Lemma refa88_not3256 : ~ @Equation3256 Fin3 refa88_inst.
Proof. unfold Equation3256. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa88_inst, refa88_op in H. discriminate H. Qed.

Lemma refa88_not3259 : ~ @Equation3259 Fin3 refa88_inst.
Proof. unfold Equation3259. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa88_inst, refa88_op in H. discriminate H. Qed.

Lemma refa88_not3308 : ~ @Equation3308 Fin3 refa88_inst.
Proof. unfold Equation3308. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa88_inst, refa88_op in H. discriminate H. Qed.

Lemma refa88_not3315 : ~ @Equation3315 Fin3 refa88_inst.
Proof. unfold Equation3315. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa88_inst, refa88_op in H. discriminate H. Qed.

Lemma refa88_not3316 : ~ @Equation3316 Fin3 refa88_inst.
Proof. unfold Equation3316. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa88_inst, refa88_op in H. discriminate H. Qed.

Lemma refa88_not3318 : ~ @Equation3318 Fin3 refa88_inst.
Proof. unfold Equation3318. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa88_inst, refa88_op in H. discriminate H. Qed.

Lemma refa88_not3319 : ~ @Equation3319 Fin3 refa88_inst.
Proof. unfold Equation3319. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa88_inst, refa88_op in H. discriminate H. Qed.

Lemma refa88_not3456 : ~ @Equation3456 Fin3 refa88_inst.
Proof. unfold Equation3456. intro H. specialize (H F3_2). unfold magma_op, refa88_inst, refa88_op in H. discriminate H. Qed.

Lemma refa88_not4065 : ~ @Equation4065 Fin3 refa88_inst.
Proof. unfold Equation4065. intro H. specialize (H F3_1). unfold magma_op, refa88_inst, refa88_op in H. discriminate H. Qed.

Lemma refa88_not4268 : ~ @Equation4268 Fin3 refa88_inst.
Proof. unfold Equation4268. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa88_inst, refa88_op in H. discriminate H. Qed.

Lemma refa88_not4283 : ~ @Equation4283 Fin3 refa88_inst.
Proof. unfold Equation4283. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa88_inst, refa88_op in H. discriminate H. Qed.

Lemma refa88_not4314 : ~ @Equation4314 Fin3 refa88_inst.
Proof. unfold Equation4314. intro H. specialize (H F3_2 F3_1). unfold magma_op, refa88_inst, refa88_op in H. discriminate H. Qed.

Lemma refa88_not4585 : ~ @Equation4585 Fin3 refa88_inst.
Proof. unfold Equation4585. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa88_inst, refa88_op in H. discriminate H. Qed.

(** ---- refa880 (Fin5) ---- *)

Definition refa880_op (x y : Fin5) : Fin5 :=
  match x, y with
  | F5_0, F5_0 => F5_0 | F5_0, F5_1 => F5_2 | F5_0, F5_2 => F5_3 | F5_0, F5_3 => F5_1 | F5_0, F5_4 => F5_4
  | F5_1, F5_0 => F5_0 | F5_1, F5_1 => F5_2 | F5_1, F5_2 => F5_3 | F5_1, F5_3 => F5_1 | F5_1, F5_4 => F5_4
  | F5_2, F5_0 => F5_4 | F5_2, F5_1 => F5_2 | F5_2, F5_2 => F5_3 | F5_2, F5_3 => F5_1 | F5_2, F5_4 => F5_0
  | F5_3, F5_0 => F5_0 | F5_3, F5_1 => F5_2 | F5_3, F5_2 => F5_3 | F5_3, F5_3 => F5_1 | F5_3, F5_4 => F5_4
  | F5_4, F5_0 => F5_0 | F5_4, F5_1 => F5_2 | F5_4, F5_2 => F5_3 | F5_4, F5_3 => F5_1 | F5_4, F5_4 => F5_4
  end.

#[local] Instance refa880_inst : Magma Fin5 := {| magma_op := refa880_op |}.

Lemma refa880_sat947 : @Equation947 Fin5 refa880_inst.
Proof. unfold Equation947, magma_op, refa880_inst, refa880_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa880_not632 : ~ @Equation632 Fin5 refa880_inst.
Proof. unfold Equation632. intro H. specialize (H F5_0 F5_1). unfold magma_op, refa880_inst, refa880_op in H. discriminate H. Qed.

Lemma refa880_not642 : ~ @Equation642 Fin5 refa880_inst.
Proof. unfold Equation642. intro H. specialize (H F5_0 F5_1). unfold magma_op, refa880_inst, refa880_op in H. discriminate H. Qed.

Lemma refa880_not669 : ~ @Equation669 Fin5 refa880_inst.
Proof. unfold Equation669. intro H. specialize (H F5_0 F5_1). unfold magma_op, refa880_inst, refa880_op in H. discriminate H. Qed.

Lemma refa880_not679 : ~ @Equation679 Fin5 refa880_inst.
Proof. unfold Equation679. intro H. specialize (H F5_0 F5_1). unfold magma_op, refa880_inst, refa880_op in H. discriminate H. Qed.

Lemma refa880_not825 : ~ @Equation825 Fin5 refa880_inst.
Proof. unfold Equation825. intro H. specialize (H F5_0 F5_1). unfold magma_op, refa880_inst, refa880_op in H. discriminate H. Qed.

Lemma refa880_not845 : ~ @Equation845 Fin5 refa880_inst.
Proof. unfold Equation845. intro H. specialize (H F5_0 F5_1). unfold magma_op, refa880_inst, refa880_op in H. discriminate H. Qed.

Lemma refa880_not879 : ~ @Equation879 Fin5 refa880_inst.
Proof. unfold Equation879. intro H. specialize (H F5_0 F5_1). unfold magma_op, refa880_inst, refa880_op in H. discriminate H. Qed.

Lemma refa880_not1444 : ~ @Equation1444 Fin5 refa880_inst.
Proof. unfold Equation1444. intro H. specialize (H F5_0 F5_1). unfold magma_op, refa880_inst, refa880_op in H. discriminate H. Qed.

Lemma refa880_not1451 : ~ @Equation1451 Fin5 refa880_inst.
Proof. unfold Equation1451. intro H. specialize (H F5_0 F5_1). unfold magma_op, refa880_inst, refa880_op in H. discriminate H. Qed.

Lemma refa880_not1518 : ~ @Equation1518 Fin5 refa880_inst.
Proof. unfold Equation1518. intro H. specialize (H F5_0 F5_1). unfold magma_op, refa880_inst, refa880_op in H. discriminate H. Qed.

Lemma refa880_not1525 : ~ @Equation1525 Fin5 refa880_inst.
Proof. unfold Equation1525. intro H. specialize (H F5_0 F5_1). unfold magma_op, refa880_inst, refa880_op in H. discriminate H. Qed.

Lemma refa880_not3915 : ~ @Equation3915 Fin5 refa880_inst.
Proof. unfold Equation3915. intro H. specialize (H F5_2 F5_0). unfold magma_op, refa880_inst, refa880_op in H. discriminate H. Qed.

Lemma refa880_not3925 : ~ @Equation3925 Fin5 refa880_inst.
Proof. unfold Equation3925. intro H. specialize (H F5_2 F5_0). unfold magma_op, refa880_inst, refa880_op in H. discriminate H. Qed.

Lemma refa880_not3952 : ~ @Equation3952 Fin5 refa880_inst.
Proof. unfold Equation3952. intro H. specialize (H F5_2 F5_0). unfold magma_op, refa880_inst, refa880_op in H. discriminate H. Qed.

Lemma refa880_not3962 : ~ @Equation3962 Fin5 refa880_inst.
Proof. unfold Equation3962. intro H. specialize (H F5_2 F5_0). unfold magma_op, refa880_inst, refa880_op in H. discriminate H. Qed.

Lemma refa880_not4118 : ~ @Equation4118 Fin5 refa880_inst.
Proof. unfold Equation4118. intro H. specialize (H F5_1 F5_0). unfold magma_op, refa880_inst, refa880_op in H. discriminate H. Qed.

Lemma refa880_not4128 : ~ @Equation4128 Fin5 refa880_inst.
Proof. unfold Equation4128. intro H. specialize (H F5_1 F5_0). unfold magma_op, refa880_inst, refa880_op in H. discriminate H. Qed.

Lemma refa880_not4155 : ~ @Equation4155 Fin5 refa880_inst.
Proof. unfold Equation4155. intro H. specialize (H F5_1 F5_0). unfold magma_op, refa880_inst, refa880_op in H. discriminate H. Qed.

Lemma refa880_not4165 : ~ @Equation4165 Fin5 refa880_inst.
Proof. unfold Equation4165. intro H. specialize (H F5_1 F5_0). unfold magma_op, refa880_inst, refa880_op in H. discriminate H. Qed.

(** ---- refa881 (Fin5) ---- *)

Definition refa881_op (x y : Fin5) : Fin5 :=
  match x, y with
  | F5_0, F5_0 => F5_0 | F5_0, F5_1 => F5_1 | F5_0, F5_2 => F5_2 | F5_0, F5_3 => F5_4 | F5_0, F5_4 => F5_3
  | F5_1, F5_0 => F5_0 | F5_1, F5_1 => F5_1 | F5_1, F5_2 => F5_3 | F5_1, F5_3 => F5_2 | F5_1, F5_4 => F5_4
  | F5_2, F5_0 => F5_1 | F5_2, F5_1 => F5_0 | F5_2, F5_2 => F5_2 | F5_2, F5_3 => F5_3 | F5_2, F5_4 => F5_4
  | F5_3, F5_0 => F5_1 | F5_3, F5_1 => F5_0 | F5_3, F5_2 => F5_2 | F5_3, F5_3 => F5_3 | F5_3, F5_4 => F5_4
  | F5_4, F5_0 => F5_1 | F5_4, F5_1 => F5_0 | F5_4, F5_2 => F5_2 | F5_4, F5_3 => F5_3 | F5_4, F5_4 => F5_4
  end.

#[local] Instance refa881_inst : Magma Fin5 := {| magma_op := refa881_op |}.

Lemma refa881_sat947 : @Equation947 Fin5 refa881_inst.
Proof. unfold Equation947, magma_op, refa881_inst, refa881_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa881_not4362 : ~ @Equation4362 Fin5 refa881_inst.
Proof. unfold Equation4362. intro H. specialize (H F5_0 F5_1 F5_2). unfold magma_op, refa881_inst, refa881_op in H. discriminate H. Qed.

Lemma refa881_not4606 : ~ @Equation4606 Fin5 refa881_inst.
Proof. unfold Equation4606. intro H. specialize (H F5_0 F5_2). unfold magma_op, refa881_inst, refa881_op in H. discriminate H. Qed.

(** ---- refa882 (Fin6) ---- *)

Definition refa882_op (x y : Fin6) : Fin6 :=
  match x, y with
  | F6_0, F6_0 => F6_2 | F6_0, F6_1 => F6_3 | F6_0, F6_2 => F6_4 | F6_0, F6_3 => F6_5 | F6_0, F6_4 => F6_0 | F6_0, F6_5 => F6_1
  | F6_1, F6_0 => F6_2 | F6_1, F6_1 => F6_3 | F6_1, F6_2 => F6_0 | F6_1, F6_3 => F6_5 | F6_1, F6_4 => F6_4 | F6_1, F6_5 => F6_1
  | F6_2, F6_0 => F6_2 | F6_2, F6_1 => F6_3 | F6_2, F6_2 => F6_4 | F6_2, F6_3 => F6_5 | F6_2, F6_4 => F6_0 | F6_2, F6_5 => F6_1
  | F6_3, F6_0 => F6_4 | F6_3, F6_1 => F6_3 | F6_3, F6_2 => F6_2 | F6_3, F6_3 => F6_5 | F6_3, F6_4 => F6_0 | F6_3, F6_5 => F6_1
  | F6_4, F6_0 => F6_2 | F6_4, F6_1 => F6_3 | F6_4, F6_2 => F6_4 | F6_4, F6_3 => F6_5 | F6_4, F6_4 => F6_0 | F6_4, F6_5 => F6_1
  | F6_5, F6_0 => F6_0 | F6_5, F6_1 => F6_3 | F6_5, F6_2 => F6_4 | F6_5, F6_3 => F6_5 | F6_5, F6_4 => F6_2 | F6_5, F6_5 => F6_1
  end.

#[local] Instance refa882_inst : Magma Fin6 := {| magma_op := refa882_op |}.

Lemma refa882_sat960 : @Equation960 Fin6 refa882_inst.
Proof. unfold Equation960, magma_op, refa882_inst, refa882_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa882_not55 : ~ @Equation55 Fin6 refa882_inst.
Proof. unfold Equation55. intro H. specialize (H F6_0 F6_1). unfold magma_op, refa882_inst, refa882_op in H. discriminate H. Qed.

Lemma refa882_not65 : ~ @Equation65 Fin6 refa882_inst.
Proof. unfold Equation65. intro H. specialize (H F6_0 F6_1). unfold magma_op, refa882_inst, refa882_op in H. discriminate H. Qed.

Lemma refa882_not669 : ~ @Equation669 Fin6 refa882_inst.
Proof. unfold Equation669. intro H. specialize (H F6_0 F6_1). unfold magma_op, refa882_inst, refa882_op in H. discriminate H. Qed.

Lemma refa882_not676 : ~ @Equation676 Fin6 refa882_inst.
Proof. unfold Equation676. intro H. specialize (H F6_0 F6_1). unfold magma_op, refa882_inst, refa882_op in H. discriminate H. Qed.

Lemma refa882_not679 : ~ @Equation679 Fin6 refa882_inst.
Proof. unfold Equation679. intro H. specialize (H F6_0 F6_1). unfold magma_op, refa882_inst, refa882_op in H. discriminate H. Qed.

Lemma refa882_not713 : ~ @Equation713 Fin6 refa882_inst.
Proof. unfold Equation713. intro H. specialize (H F6_0 F6_1). unfold magma_op, refa882_inst, refa882_op in H. discriminate H. Qed.

Lemma refa882_not825 : ~ @Equation825 Fin6 refa882_inst.
Proof. unfold Equation825. intro H. specialize (H F6_0 F6_1). unfold magma_op, refa882_inst, refa882_op in H. discriminate H. Qed.

Lemma refa882_not845 : ~ @Equation845 Fin6 refa882_inst.
Proof. unfold Equation845. intro H. specialize (H F6_0 F6_1). unfold magma_op, refa882_inst, refa882_op in H. discriminate H. Qed.

Lemma refa882_not872 : ~ @Equation872 Fin6 refa882_inst.
Proof. unfold Equation872. intro H. specialize (H F6_0 F6_1). unfold magma_op, refa882_inst, refa882_op in H. discriminate H. Qed.

Lemma refa882_not882 : ~ @Equation882 Fin6 refa882_inst.
Proof. unfold Equation882. intro H. specialize (H F6_0 F6_3). unfold magma_op, refa882_inst, refa882_op in H. discriminate H. Qed.

Lemma refa882_not1434 : ~ @Equation1434 Fin6 refa882_inst.
Proof. unfold Equation1434. intro H. specialize (H F6_0 F6_1). unfold magma_op, refa882_inst, refa882_op in H. discriminate H. Qed.

Lemma refa882_not1451 : ~ @Equation1451 Fin6 refa882_inst.
Proof. unfold Equation1451. intro H. specialize (H F6_0 F6_1). unfold magma_op, refa882_inst, refa882_op in H. discriminate H. Qed.

Lemma refa882_not1491 : ~ @Equation1491 Fin6 refa882_inst.
Proof. unfold Equation1491. intro H. specialize (H F6_0 F6_1). unfold magma_op, refa882_inst, refa882_op in H. discriminate H. Qed.

Lemma refa882_not1525 : ~ @Equation1525 Fin6 refa882_inst.
Proof. unfold Equation1525. intro H. specialize (H F6_0 F6_1). unfold magma_op, refa882_inst, refa882_op in H. discriminate H. Qed.

Lemma refa882_not3915 : ~ @Equation3915 Fin6 refa882_inst.
Proof. unfold Equation3915. intro H. specialize (H F6_1 F6_0). unfold magma_op, refa882_inst, refa882_op in H. discriminate H. Qed.

Lemma refa882_not3925 : ~ @Equation3925 Fin6 refa882_inst.
Proof. unfold Equation3925. intro H. specialize (H F6_1 F6_0). unfold magma_op, refa882_inst, refa882_op in H. discriminate H. Qed.

Lemma refa882_not3952 : ~ @Equation3952 Fin6 refa882_inst.
Proof. unfold Equation3952. intro H. specialize (H F6_1 F6_0). unfold magma_op, refa882_inst, refa882_op in H. discriminate H. Qed.

Lemma refa882_not3962 : ~ @Equation3962 Fin6 refa882_inst.
Proof. unfold Equation3962. intro H. specialize (H F6_1 F6_0). unfold magma_op, refa882_inst, refa882_op in H. discriminate H. Qed.

Lemma refa882_not4118 : ~ @Equation4118 Fin6 refa882_inst.
Proof. unfold Equation4118. intro H. specialize (H F6_1 F6_0). unfold magma_op, refa882_inst, refa882_op in H. discriminate H. Qed.

Lemma refa882_not4128 : ~ @Equation4128 Fin6 refa882_inst.
Proof. unfold Equation4128. intro H. specialize (H F6_1 F6_0). unfold magma_op, refa882_inst, refa882_op in H. discriminate H. Qed.

Lemma refa882_not4155 : ~ @Equation4155 Fin6 refa882_inst.
Proof. unfold Equation4155. intro H. specialize (H F6_1 F6_0). unfold magma_op, refa882_inst, refa882_op in H. discriminate H. Qed.

Lemma refa882_not4165 : ~ @Equation4165 Fin6 refa882_inst.
Proof. unfold Equation4165. intro H. specialize (H F6_1 F6_0). unfold magma_op, refa882_inst, refa882_op in H. discriminate H. Qed.

Lemma refa882_not4275 : ~ @Equation4275 Fin6 refa882_inst.
Proof. unfold Equation4275. intro H. specialize (H F6_0 F6_1). unfold magma_op, refa882_inst, refa882_op in H. discriminate H. Qed.

Lemma refa882_not4320 : ~ @Equation4320 Fin6 refa882_inst.
Proof. unfold Equation4320. intro H. specialize (H F6_0 F6_1). unfold magma_op, refa882_inst, refa882_op in H. discriminate H. Qed.

(** ---- refa883 (Fin8) ---- *)

Definition refa883_op (x y : Fin8) : Fin8 :=
  match x, y with
  | F8_0, F8_0 => F8_5 | F8_0, F8_1 => F8_3 | F8_0, F8_2 => F8_1 | F8_0, F8_3 => F8_2 | F8_0, F8_4 => F8_7 | F8_0, F8_5 => F8_0 | F8_0, F8_6 => F8_6 | F8_0, F8_7 => F8_4
  | F8_1, F8_0 => F8_2 | F8_1, F8_1 => F8_5 | F8_1, F8_2 => F8_4 | F8_1, F8_3 => F8_3 | F8_1, F8_4 => F8_0 | F8_1, F8_5 => F8_1 | F8_1, F8_6 => F8_7 | F8_1, F8_7 => F8_6
  | F8_2, F8_0 => F8_4 | F8_2, F8_1 => F8_7 | F8_2, F8_2 => F8_5 | F8_2, F8_3 => F8_1 | F8_2, F8_4 => F8_6 | F8_2, F8_5 => F8_2 | F8_2, F8_6 => F8_0 | F8_2, F8_7 => F8_3
  | F8_3, F8_0 => F8_6 | F8_3, F8_1 => F8_4 | F8_3, F8_2 => F8_0 | F8_3, F8_3 => F8_5 | F8_3, F8_4 => F8_1 | F8_3, F8_5 => F8_3 | F8_3, F8_6 => F8_2 | F8_3, F8_7 => F8_7
  | F8_4, F8_0 => F8_0 | F8_4, F8_1 => F8_2 | F8_4, F8_2 => F8_7 | F8_4, F8_3 => F8_6 | F8_4, F8_4 => F8_5 | F8_4, F8_5 => F8_4 | F8_4, F8_6 => F8_3 | F8_4, F8_7 => F8_1
  | F8_5, F8_0 => F8_7 | F8_5, F8_1 => F8_6 | F8_5, F8_2 => F8_2 | F8_5, F8_3 => F8_4 | F8_5, F8_4 => F8_3 | F8_5, F8_5 => F8_5 | F8_5, F8_6 => F8_1 | F8_5, F8_7 => F8_0
  | F8_6, F8_0 => F8_1 | F8_6, F8_1 => F8_0 | F8_6, F8_2 => F8_3 | F8_6, F8_3 => F8_7 | F8_6, F8_4 => F8_4 | F8_6, F8_5 => F8_6 | F8_6, F8_6 => F8_5 | F8_6, F8_7 => F8_2
  | F8_7, F8_0 => F8_3 | F8_7, F8_1 => F8_1 | F8_7, F8_2 => F8_6 | F8_7, F8_3 => F8_0 | F8_7, F8_4 => F8_2 | F8_7, F8_5 => F8_7 | F8_7, F8_6 => F8_4 | F8_7, F8_7 => F8_5
  end.

#[local] Instance refa883_inst : Magma Fin8 := {| magma_op := refa883_op |}.

Lemma refa883_sat978 : @Equation978 Fin8 refa883_inst.
Proof. unfold Equation978, magma_op, refa883_inst, refa883_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa883_not466 : ~ @Equation466 Fin8 refa883_inst.
Proof. unfold Equation466. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa883_inst, refa883_op in H. discriminate H. Qed.

Lemma refa883_not1848 : ~ @Equation1848 Fin8 refa883_inst.
Proof. unfold Equation1848. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa883_inst, refa883_op in H. discriminate H. Qed.

(** ---- refa884 (Fin7) ---- *)

Definition refa884_op (x y : Fin7) : Fin7 :=
  match x, y with
  | F7_0, F7_0 => F7_1 | F7_0, F7_1 => F7_1 | F7_0, F7_2 => F7_0 | F7_0, F7_3 => F7_1 | F7_0, F7_4 => F7_2 | F7_0, F7_5 => F7_2 | F7_0, F7_6 => F7_1
  | F7_1, F7_0 => F7_2 | F7_1, F7_1 => F7_5 | F7_1, F7_2 => F7_1 | F7_1, F7_3 => F7_5 | F7_1, F7_4 => F7_2 | F7_1, F7_5 => F7_5 | F7_1, F7_6 => F7_5
  | F7_2, F7_0 => F7_1 | F7_2, F7_1 => F7_5 | F7_2, F7_2 => F7_4 | F7_2, F7_3 => F7_4 | F7_2, F7_4 => F7_3 | F7_2, F7_5 => F7_0 | F7_2, F7_6 => F7_3
  | F7_3, F7_0 => F7_0 | F7_3, F7_1 => F7_1 | F7_3, F7_2 => F7_4 | F7_3, F7_3 => F7_6 | F7_3, F7_4 => F7_2 | F7_3, F7_5 => F7_5 | F7_3, F7_6 => F7_3
  | F7_4, F7_0 => F7_3 | F7_4, F7_1 => F7_3 | F7_4, F7_2 => F7_3 | F7_4, F7_3 => F7_2 | F7_4, F7_4 => F7_2 | F7_4, F7_5 => F7_3 | F7_4, F7_6 => F7_3
  | F7_5, F7_0 => F7_0 | F7_5, F7_1 => F7_2 | F7_5, F7_2 => F7_5 | F7_5, F7_3 => F7_0 | F7_5, F7_4 => F7_2 | F7_5, F7_5 => F7_0 | F7_5, F7_6 => F7_0
  | F7_6, F7_0 => F7_0 | F7_6, F7_1 => F7_1 | F7_6, F7_2 => F7_3 | F7_6, F7_3 => F7_3 | F7_6, F7_4 => F7_3 | F7_6, F7_5 => F7_5 | F7_6, F7_6 => F7_3
  end.

#[local] Instance refa884_inst : Magma Fin7 := {| magma_op := refa884_op |}.

Lemma refa884_sat4164 : @Equation4164 Fin7 refa884_inst.
Proof. unfold Equation4164, magma_op, refa884_inst, refa884_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa884_not3456 : ~ @Equation3456 Fin7 refa884_inst.
Proof. unfold Equation3456. intro H. specialize (H F7_0). unfold magma_op, refa884_inst, refa884_op in H. discriminate H. Qed.

Lemma refa884_not3862 : ~ @Equation3862 Fin7 refa884_inst.
Proof. unfold Equation3862. intro H. specialize (H F7_0). unfold magma_op, refa884_inst, refa884_op in H. discriminate H. Qed.

Lemma refa884_not4158 : ~ @Equation4158 Fin7 refa884_inst.
Proof. unfold Equation4158. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa884_inst, refa884_op in H. discriminate H. Qed.

Lemma refa884_not4380 : ~ @Equation4380 Fin7 refa884_inst.
Proof. unfold Equation4380. intro H. specialize (H F7_0). unfold magma_op, refa884_inst, refa884_op in H. discriminate H. Qed.

(** ---- refa885 (Fin6) ---- *)

Definition refa885_op (x y : Fin6) : Fin6 :=
  match x, y with
  | F6_0, F6_0 => F6_3 | F6_0, F6_1 => F6_3 | F6_0, F6_2 => F6_3 | F6_0, F6_3 => F6_0 | F6_0, F6_4 => F6_0 | F6_0, F6_5 => F6_3
  | F6_1, F6_0 => F6_2 | F6_1, F6_1 => F6_5 | F6_1, F6_2 => F6_5 | F6_1, F6_3 => F6_5 | F6_1, F6_4 => F6_2 | F6_1, F6_5 => F6_2
  | F6_2, F6_0 => F6_3 | F6_2, F6_1 => F6_5 | F6_2, F6_2 => F6_4 | F6_2, F6_3 => F6_0 | F6_2, F6_4 => F6_2 | F6_2, F6_5 => F6_1
  | F6_3, F6_0 => F6_0 | F6_3, F6_1 => F6_5 | F6_3, F6_2 => F6_0 | F6_3, F6_3 => F6_0 | F6_3, F6_4 => F6_0 | F6_3, F6_5 => F6_1
  | F6_4, F6_0 => F6_0 | F6_4, F6_1 => F6_2 | F6_4, F6_2 => F6_2 | F6_4, F6_3 => F6_0 | F6_4, F6_4 => F6_2 | F6_4, F6_5 => F6_2
  | F6_5, F6_0 => F6_2 | F6_5, F6_1 => F6_2 | F6_5, F6_2 => F6_1 | F6_5, F6_3 => F6_1 | F6_5, F6_4 => F6_2 | F6_5, F6_5 => F6_1
  end.

#[local] Instance refa885_inst : Magma Fin6 := {| magma_op := refa885_op |}.

Lemma refa885_sat4164 : @Equation4164 Fin6 refa885_inst.
Proof. unfold Equation4164, magma_op, refa885_inst, refa885_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa885_not3308 : ~ @Equation3308 Fin6 refa885_inst.
Proof. unfold Equation3308. intro H. specialize (H F6_0 F6_1). unfold magma_op, refa885_inst, refa885_op in H. discriminate H. Qed.

Lemma refa885_not3352 : ~ @Equation3352 Fin6 refa885_inst.
Proof. unfold Equation3352. intro H. specialize (H F6_0 F6_1). unfold magma_op, refa885_inst, refa885_op in H. discriminate H. Qed.

(** ---- refa886 (Fin6) ---- *)

Definition refa886_op (x y : Fin6) : Fin6 :=
  match x, y with
  | F6_0, F6_0 => F6_1 | F6_0, F6_1 => F6_4 | F6_0, F6_2 => F6_4 | F6_0, F6_3 => F6_4 | F6_0, F6_4 => F6_3 | F6_0, F6_5 => F6_2
  | F6_1, F6_0 => F6_0 | F6_1, F6_1 => F6_2 | F6_1, F6_2 => F6_4 | F6_1, F6_3 => F6_2 | F6_1, F6_4 => F6_4 | F6_1, F6_5 => F6_5
  | F6_2, F6_0 => F6_0 | F6_2, F6_1 => F6_3 | F6_2, F6_2 => F6_2 | F6_2, F6_3 => F6_2 | F6_2, F6_4 => F6_2 | F6_2, F6_5 => F6_5
  | F6_3, F6_0 => F6_5 | F6_3, F6_1 => F6_2 | F6_3, F6_2 => F6_2 | F6_3, F6_3 => F6_2 | F6_3, F6_4 => F6_1 | F6_3, F6_5 => F6_0
  | F6_4, F6_0 => F6_5 | F6_4, F6_1 => F6_1 | F6_4, F6_2 => F6_1 | F6_4, F6_3 => F6_1 | F6_4, F6_4 => F6_2 | F6_4, F6_5 => F6_0
  | F6_5, F6_0 => F6_2 | F6_5, F6_1 => F6_4 | F6_5, F6_2 => F6_4 | F6_5, F6_3 => F6_4 | F6_5, F6_4 => F6_3 | F6_5, F6_5 => F6_1
  end.

#[local] Instance refa886_inst : Magma Fin6 := {| magma_op := refa886_op |}.

Lemma refa886_sat4084 : @Equation4084 Fin6 refa886_inst.
Proof. unfold Equation4084, magma_op, refa886_inst, refa886_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa886_not3253 : ~ @Equation3253 Fin6 refa886_inst.
Proof. unfold Equation3253. intro H. specialize (H F6_0). unfold magma_op, refa886_inst, refa886_op in H. discriminate H. Qed.

Lemma refa886_not3659 : ~ @Equation3659 Fin6 refa886_inst.
Proof. unfold Equation3659. intro H. specialize (H F6_0). unfold magma_op, refa886_inst, refa886_op in H. discriminate H. Qed.

Lemma refa886_not4068 : ~ @Equation4068 Fin6 refa886_inst.
Proof. unfold Equation4068. intro H. specialize (H F6_0 F6_1). unfold magma_op, refa886_inst, refa886_op in H. discriminate H. Qed.

Lemma refa886_not4070 : ~ @Equation4070 Fin6 refa886_inst.
Proof. unfold Equation4070. intro H. specialize (H F6_0 F6_1). unfold magma_op, refa886_inst, refa886_op in H. discriminate H. Qed.

Lemma refa886_not4090 : ~ @Equation4090 Fin6 refa886_inst.
Proof. unfold Equation4090. intro H. specialize (H F6_1 F6_0). unfold magma_op, refa886_inst, refa886_op in H. discriminate H. Qed.

Lemma refa886_not4131 : ~ @Equation4131 Fin6 refa886_inst.
Proof. unfold Equation4131. intro H. specialize (H F6_0 F6_1). unfold magma_op, refa886_inst, refa886_op in H. discriminate H. Qed.

Lemma refa886_not4269 : ~ @Equation4269 Fin6 refa886_inst.
Proof. unfold Equation4269. intro H. specialize (H F6_0 F6_1). unfold magma_op, refa886_inst, refa886_op in H. discriminate H. Qed.

Lemma refa886_not4270 : ~ @Equation4270 Fin6 refa886_inst.
Proof. unfold Equation4270. intro H. specialize (H F6_1 F6_0). unfold magma_op, refa886_inst, refa886_op in H. discriminate H. Qed.

Lemma refa886_not4314 : ~ @Equation4314 Fin6 refa886_inst.
Proof. unfold Equation4314. intro H. specialize (H F6_0 F6_1). unfold magma_op, refa886_inst, refa886_op in H. discriminate H. Qed.

Lemma refa886_not4606 : ~ @Equation4606 Fin6 refa886_inst.
Proof. unfold Equation4606. intro H. specialize (H F6_0 F6_1). unfold magma_op, refa886_inst, refa886_op in H. discriminate H. Qed.

Lemma refa886_not4622 : ~ @Equation4622 Fin6 refa886_inst.
Proof. unfold Equation4622. intro H. specialize (H F6_0 F6_1 F6_1). unfold magma_op, refa886_inst, refa886_op in H. discriminate H. Qed.

Lemma refa886_not4631 : ~ @Equation4631 Fin6 refa886_inst.
Proof. unfold Equation4631. intro H. specialize (H F6_0 F6_0 F6_1). unfold magma_op, refa886_inst, refa886_op in H. discriminate H. Qed.

(** ---- refa887 (Fin7) ---- *)

Definition refa887_op (x y : Fin7) : Fin7 :=
  match x, y with
  | F7_0, F7_0 => F7_1 | F7_0, F7_1 => F7_5 | F7_0, F7_2 => F7_4 | F7_0, F7_3 => F7_1 | F7_0, F7_4 => F7_3 | F7_0, F7_5 => F7_6 | F7_0, F7_6 => F7_2
  | F7_1, F7_0 => F7_3 | F7_1, F7_1 => F7_0 | F7_1, F7_2 => F7_5 | F7_1, F7_3 => F7_6 | F7_1, F7_4 => F7_2 | F7_1, F7_5 => F7_0 | F7_1, F7_6 => F7_4
  | F7_2, F7_0 => F7_6 | F7_2, F7_1 => F7_4 | F7_2, F7_2 => F7_0 | F7_2, F7_3 => F7_5 | F7_2, F7_4 => F7_0 | F7_2, F7_5 => F7_1 | F7_2, F7_6 => F7_3
  | F7_3, F7_0 => F7_4 | F7_3, F7_1 => F7_0 | F7_3, F7_2 => F7_6 | F7_3, F7_3 => F7_0 | F7_3, F7_4 => F7_5 | F7_3, F7_5 => F7_2 | F7_3, F7_6 => F7_1
  | F7_4, F7_0 => F7_2 | F7_4, F7_1 => F7_6 | F7_4, F7_2 => F7_1 | F7_4, F7_3 => F7_0 | F7_4, F7_4 => F7_2 | F7_4, F7_5 => F7_3 | F7_4, F7_6 => F7_5
  | F7_5, F7_0 => F7_1 | F7_5, F7_1 => F7_2 | F7_5, F7_2 => F7_3 | F7_5, F7_3 => F7_4 | F7_5, F7_4 => F7_6 | F7_5, F7_5 => F7_1 | F7_5, F7_6 => F7_0
  | F7_6, F7_0 => F7_5 | F7_6, F7_1 => F7_3 | F7_6, F7_2 => F7_0 | F7_6, F7_3 => F7_2 | F7_6, F7_4 => F7_1 | F7_6, F7_5 => F7_4 | F7_6, F7_6 => F7_5
  end.

#[local] Instance refa887_inst : Magma Fin7 := {| magma_op := refa887_op |}.

Lemma refa887_sat3961 : @Equation3961 Fin7 refa887_inst.
Proof. unfold Equation3961, magma_op, refa887_inst, refa887_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa887_not3659 : ~ @Equation3659 Fin7 refa887_inst.
Proof. unfold Equation3659. intro H. specialize (H F7_0). unfold magma_op, refa887_inst, refa887_op in H. discriminate H. Qed.

Lemma refa887_not4321 : ~ @Equation4321 Fin7 refa887_inst.
Proof. unfold Equation4321. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa887_inst, refa887_op in H. discriminate H. Qed.

(** ---- refa888 (Fin7) ---- *)

Definition refa888_op (x y : Fin7) : Fin7 :=
  match x, y with
  | F7_0, F7_0 => F7_1 | F7_0, F7_1 => F7_6 | F7_0, F7_2 => F7_3 | F7_0, F7_3 => F7_4 | F7_0, F7_4 => F7_5 | F7_0, F7_5 => F7_3 | F7_0, F7_6 => F7_2
  | F7_1, F7_0 => F7_2 | F7_1, F7_1 => F7_1 | F7_1, F7_2 => F7_2 | F7_1, F7_3 => F7_1 | F7_1, F7_4 => F7_1 | F7_1, F7_5 => F7_5 | F7_1, F7_6 => F7_1
  | F7_2, F7_0 => F7_6 | F7_2, F7_1 => F7_2 | F7_2, F7_2 => F7_2 | F7_2, F7_3 => F7_2 | F7_2, F7_4 => F7_5 | F7_2, F7_5 => F7_6 | F7_2, F7_6 => F7_4
  | F7_3, F7_0 => F7_5 | F7_3, F7_1 => F7_1 | F7_3, F7_2 => F7_2 | F7_3, F7_3 => F7_3 | F7_3, F7_4 => F7_3 | F7_3, F7_5 => F7_5 | F7_3, F7_6 => F7_1
  | F7_4, F7_0 => F7_3 | F7_4, F7_1 => F7_1 | F7_4, F7_2 => F7_6 | F7_4, F7_3 => F7_3 | F7_4, F7_4 => F7_4 | F7_4, F7_5 => F7_4 | F7_4, F7_6 => F7_6
  | F7_5, F7_0 => F7_4 | F7_5, F7_1 => F7_5 | F7_5, F7_2 => F7_4 | F7_5, F7_3 => F7_5 | F7_5, F7_4 => F7_4 | F7_5, F7_5 => F7_5 | F7_5, F7_6 => F7_5
  | F7_6, F7_0 => F7_1 | F7_6, F7_1 => F7_1 | F7_6, F7_2 => F7_5 | F7_6, F7_3 => F7_1 | F7_6, F7_4 => F7_6 | F7_6, F7_5 => F7_5 | F7_6, F7_6 => F7_6
  end.

#[local] Instance refa888_inst : Magma Fin7 := {| magma_op := refa888_op |}.

Lemma refa888_sat3961 : @Equation3961 Fin7 refa888_inst.
Proof. unfold Equation3961, magma_op, refa888_inst, refa888_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa888_not3456 : ~ @Equation3456 Fin7 refa888_inst.
Proof. unfold Equation3456. intro H. specialize (H F7_0). unfold magma_op, refa888_inst, refa888_op in H. discriminate H. Qed.

Lemma refa888_not3917 : ~ @Equation3917 Fin7 refa888_inst.
Proof. unfold Equation3917. intro H. specialize (H F7_0 F7_6). unfold magma_op, refa888_inst, refa888_op in H. discriminate H. Qed.

Lemma refa888_not4293 : ~ @Equation4293 Fin7 refa888_inst.
Proof. unfold Equation4293. intro H. specialize (H F7_0 F7_6). unfold magma_op, refa888_inst, refa888_op in H. discriminate H. Qed.

(** ---- refa889 (Fin6) ---- *)

Definition refa889_op (x y : Fin6) : Fin6 :=
  match x, y with
  | F6_0, F6_0 => F6_1 | F6_0, F6_1 => F6_4 | F6_0, F6_2 => F6_1 | F6_0, F6_3 => F6_4 | F6_0, F6_4 => F6_3 | F6_0, F6_5 => F6_2
  | F6_1, F6_0 => F6_2 | F6_1, F6_1 => F6_5 | F6_1, F6_2 => F6_4 | F6_1, F6_3 => F6_1 | F6_1, F6_4 => F6_4 | F6_1, F6_5 => F6_1
  | F6_2, F6_0 => F6_3 | F6_2, F6_1 => F6_4 | F6_2, F6_2 => F6_3 | F6_2, F6_3 => F6_2 | F6_2, F6_4 => F6_1 | F6_2, F6_5 => F6_2
  | F6_3, F6_0 => F6_4 | F6_3, F6_1 => F6_1 | F6_3, F6_2 => F6_2 | F6_3, F6_3 => F6_3 | F6_3, F6_4 => F6_4 | F6_3, F6_5 => F6_5
  | F6_4, F6_0 => F6_3 | F6_4, F6_1 => F6_4 | F6_4, F6_2 => F6_1 | F6_4, F6_3 => F6_4 | F6_4, F6_4 => F6_3 | F6_4, F6_5 => F6_2
  | F6_5, F6_0 => F6_4 | F6_5, F6_1 => F6_1 | F6_5, F6_2 => F6_2 | F6_5, F6_3 => F6_5 | F6_5, F6_4 => F6_2 | F6_5, F6_5 => F6_3
  end.

#[local] Instance refa889_inst : Magma Fin6 := {| magma_op := refa889_op |}.

Lemma refa889_sat3558 : @Equation3558 Fin6 refa889_inst.
Proof. unfold Equation3558, magma_op, refa889_inst, refa889_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa889_not4065 : ~ @Equation4065 Fin6 refa889_inst.
Proof. unfold Equation4065. intro H. specialize (H F6_0). unfold magma_op, refa889_inst, refa889_op in H. discriminate H. Qed.

(** ---- refa89 (Fin3) ---- *)

Definition refa89_op (x y : Fin3) : Fin3 :=
  match x, y with
  | F3_0, F3_0 => F3_0 | F3_0, F3_1 => F3_0 | F3_0, F3_2 => F3_2
  | F3_1, F3_0 => F3_0 | F3_1, F3_1 => F3_2 | F3_1, F3_2 => F3_2
  | F3_2, F3_0 => F3_0 | F3_2, F3_1 => F3_1 | F3_2, F3_2 => F3_2
  end.

#[local] Instance refa89_inst : Magma Fin3 := {| magma_op := refa89_op |}.

Lemma refa89_sat2364 : @Equation2364 Fin3 refa89_inst.
Proof. unfold Equation2364, magma_op, refa89_inst, refa89_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa89_not2263 : ~ @Equation2263 Fin3 refa89_inst.
Proof. unfold Equation2263. intro H. specialize (H F3_1 F3_0). unfold magma_op, refa89_inst, refa89_op in H. discriminate H. Qed.

Lemma refa89_not2300 : ~ @Equation2300 Fin3 refa89_inst.
Proof. unfold Equation2300. intro H. specialize (H F3_1 F3_0). unfold magma_op, refa89_inst, refa89_op in H. discriminate H. Qed.

Lemma refa89_not2466 : ~ @Equation2466 Fin3 refa89_inst.
Proof. unfold Equation2466. intro H. specialize (H F3_1 F3_0). unfold magma_op, refa89_inst, refa89_op in H. discriminate H. Qed.

Lemma refa89_not2530 : ~ @Equation2530 Fin3 refa89_inst.
Proof. unfold Equation2530. intro H. specialize (H F3_1 F3_0). unfold magma_op, refa89_inst, refa89_op in H. discriminate H. Qed.

Lemma refa89_not2662 : ~ @Equation2662 Fin3 refa89_inst.
Proof. unfold Equation2662. intro H. specialize (H F3_1 F3_0). unfold magma_op, refa89_inst, refa89_op in H. discriminate H. Qed.

Lemma refa89_not2706 : ~ @Equation2706 Fin3 refa89_inst.
Proof. unfold Equation2706. intro H. specialize (H F3_1 F3_0). unfold magma_op, refa89_inst, refa89_op in H. discriminate H. Qed.

Lemma refa89_not3139 : ~ @Equation3139 Fin3 refa89_inst.
Proof. unfold Equation3139. intro H. specialize (H F3_1 F3_0). unfold magma_op, refa89_inst, refa89_op in H. discriminate H. Qed.

Lemma refa89_not3464 : ~ @Equation3464 Fin3 refa89_inst.
Proof. unfold Equation3464. intro H. specialize (H F3_1 F3_0). unfold magma_op, refa89_inst, refa89_op in H. discriminate H. Qed.

Lemma refa89_not4090 : ~ @Equation4090 Fin3 refa89_inst.
Proof. unfold Equation4090. intro H. specialize (H F3_1 F3_0). unfold magma_op, refa89_inst, refa89_op in H. discriminate H. Qed.

(** ---- refa890 (Fin7) ---- *)

Definition refa890_op (x y : Fin7) : Fin7 :=
  match x, y with
  | F7_0, F7_0 => F7_1 | F7_0, F7_1 => F7_4 | F7_0, F7_2 => F7_1 | F7_0, F7_3 => F7_5 | F7_0, F7_4 => F7_3 | F7_0, F7_5 => F7_6 | F7_0, F7_6 => F7_2
  | F7_1, F7_0 => F7_2 | F7_1, F7_1 => F7_0 | F7_1, F7_2 => F7_5 | F7_1, F7_3 => F7_6 | F7_1, F7_4 => F7_0 | F7_1, F7_5 => F7_3 | F7_1, F7_6 => F7_4
  | F7_2, F7_0 => F7_6 | F7_2, F7_1 => F7_0 | F7_2, F7_2 => F7_2 | F7_2, F7_3 => F7_4 | F7_2, F7_4 => F7_5 | F7_2, F7_5 => F7_1 | F7_2, F7_6 => F7_3
  | F7_3, F7_0 => F7_4 | F7_3, F7_1 => F7_5 | F7_3, F7_2 => F7_6 | F7_3, F7_3 => F7_3 | F7_3, F7_4 => F7_2 | F7_3, F7_5 => F7_0 | F7_3, F7_6 => F7_1
  | F7_4, F7_0 => F7_1 | F7_4, F7_1 => F7_6 | F7_4, F7_2 => F7_3 | F7_4, F7_3 => F7_0 | F7_4, F7_4 => F7_2 | F7_4, F7_5 => F7_2 | F7_4, F7_6 => F7_5
  | F7_5, F7_0 => F7_3 | F7_5, F7_1 => F7_2 | F7_5, F7_2 => F7_4 | F7_5, F7_3 => F7_1 | F7_5, F7_4 => F7_6 | F7_5, F7_5 => F7_0 | F7_5, F7_6 => F7_0
  | F7_6, F7_0 => F7_5 | F7_6, F7_1 => F7_3 | F7_6, F7_2 => F7_0 | F7_6, F7_3 => F7_2 | F7_6, F7_4 => F7_1 | F7_6, F7_5 => F7_4 | F7_6, F7_6 => F7_0
  end.

#[local] Instance refa890_inst : Magma Fin7 := {| magma_op := refa890_op |}.

Lemma refa890_sat3555 : @Equation3555 Fin7 refa890_inst.
Proof. unfold Equation3555, magma_op, refa890_inst, refa890_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa890_not3659 : ~ @Equation3659 Fin7 refa890_inst.
Proof. unfold Equation3659. intro H. specialize (H F7_0). unfold magma_op, refa890_inst, refa890_op in H. discriminate H. Qed.

(** ---- refa891 (Fin6) ---- *)

Definition refa891_op (x y : Fin6) : Fin6 :=
  match x, y with
  | F6_0, F6_0 => F6_1 | F6_0, F6_1 => F6_0 | F6_0, F6_2 => F6_0 | F6_0, F6_3 => F6_4 | F6_0, F6_4 => F6_2 | F6_0, F6_5 => F6_0
  | F6_1, F6_0 => F6_3 | F6_1, F6_1 => F6_2 | F6_1, F6_2 => F6_1 | F6_1, F6_3 => F6_1 | F6_1, F6_4 => F6_5 | F6_1, F6_5 => F6_2
  | F6_2, F6_0 => F6_3 | F6_2, F6_1 => F6_2 | F6_2, F6_2 => F6_2 | F6_2, F6_3 => F6_1 | F6_2, F6_4 => F6_5 | F6_2, F6_5 => F6_1
  | F6_3, F6_0 => F6_3 | F6_3, F6_1 => F6_3 | F6_3, F6_2 => F6_2 | F6_3, F6_3 => F6_2 | F6_3, F6_4 => F6_5 | F6_3, F6_5 => F6_1
  | F6_4, F6_0 => F6_2 | F6_4, F6_1 => F6_1 | F6_4, F6_2 => F6_4 | F6_4, F6_3 => F6_4 | F6_4, F6_4 => F6_1 | F6_4, F6_5 => F6_0
  | F6_5, F6_0 => F6_3 | F6_5, F6_1 => F6_2 | F6_5, F6_2 => F6_2 | F6_5, F6_3 => F6_1 | F6_5, F6_4 => F6_5 | F6_5, F6_5 => F6_2
  end.

#[local] Instance refa891_inst : Magma Fin6 := {| magma_op := refa891_op |}.

Lemma refa891_sat3279 : @Equation3279 Fin6 refa891_inst.
Proof. unfold Equation3279, magma_op, refa891_inst, refa891_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa891_not3255 : ~ @Equation3255 Fin6 refa891_inst.
Proof. unfold Equation3255. intro H. specialize (H F6_0 F6_1). unfold magma_op, refa891_inst, refa891_op in H. discriminate H. Qed.

Lemma refa891_not3256 : ~ @Equation3256 Fin6 refa891_inst.
Proof. unfold Equation3256. intro H. specialize (H F6_1 F6_0). unfold magma_op, refa891_inst, refa891_op in H. discriminate H. Qed.

Lemma refa891_not3278 : ~ @Equation3278 Fin6 refa891_inst.
Proof. unfold Equation3278. intro H. specialize (H F6_0 F6_2). unfold magma_op, refa891_inst, refa891_op in H. discriminate H. Qed.

Lemma refa891_not3306 : ~ @Equation3306 Fin6 refa891_inst.
Proof. unfold Equation3306. intro H. specialize (H F6_0 F6_3). unfold magma_op, refa891_inst, refa891_op in H. discriminate H. Qed.

Lemma refa891_not3659 : ~ @Equation3659 Fin6 refa891_inst.
Proof. unfold Equation3659. intro H. specialize (H F6_0). unfold magma_op, refa891_inst, refa891_op in H. discriminate H. Qed.

Lemma refa891_not4065 : ~ @Equation4065 Fin6 refa891_inst.
Proof. unfold Equation4065. intro H. specialize (H F6_0). unfold magma_op, refa891_inst, refa891_op in H. discriminate H. Qed.

Lemma refa891_not4269 : ~ @Equation4269 Fin6 refa891_inst.
Proof. unfold Equation4269. intro H. specialize (H F6_0 F6_1). unfold magma_op, refa891_inst, refa891_op in H. discriminate H. Qed.

Lemma refa891_not4270 : ~ @Equation4270 Fin6 refa891_inst.
Proof. unfold Equation4270. intro H. specialize (H F6_1 F6_0). unfold magma_op, refa891_inst, refa891_op in H. discriminate H. Qed.

Lemma refa891_not4314 : ~ @Equation4314 Fin6 refa891_inst.
Proof. unfold Equation4314. intro H. specialize (H F6_0 F6_1). unfold magma_op, refa891_inst, refa891_op in H. discriminate H. Qed.

Lemma refa891_not4606 : ~ @Equation4606 Fin6 refa891_inst.
Proof. unfold Equation4606. intro H. specialize (H F6_0 F6_1). unfold magma_op, refa891_inst, refa891_op in H. discriminate H. Qed.

Lemma refa891_not4622 : ~ @Equation4622 Fin6 refa891_inst.
Proof. unfold Equation4622. intro H. specialize (H F6_0 F6_2 F6_1). unfold magma_op, refa891_inst, refa891_op in H. discriminate H. Qed.

Lemma refa891_not4631 : ~ @Equation4631 Fin6 refa891_inst.
Proof. unfold Equation4631. intro H. specialize (H F6_0 F6_0 F6_1). unfold magma_op, refa891_inst, refa891_op in H. discriminate H. Qed.

(** ---- refa892 (Fin7) ---- *)

Definition refa892_op (x y : Fin7) : Fin7 :=
  match x, y with
  | F7_0, F7_0 => F7_0 | F7_0, F7_1 => F7_0 | F7_0, F7_2 => F7_6 | F7_0, F7_3 => F7_4 | F7_0, F7_4 => F7_0 | F7_0, F7_5 => F7_6 | F7_0, F7_6 => F7_0
  | F7_1, F7_0 => F7_2 | F7_1, F7_1 => F7_2 | F7_1, F7_2 => F7_2 | F7_1, F7_3 => F7_2 | F7_1, F7_4 => F7_2 | F7_1, F7_5 => F7_2 | F7_1, F7_6 => F7_2
  | F7_2, F7_0 => F7_3 | F7_2, F7_1 => F7_3 | F7_2, F7_2 => F7_3 | F7_2, F7_3 => F7_3 | F7_2, F7_4 => F7_3 | F7_2, F7_5 => F7_3 | F7_2, F7_6 => F7_3
  | F7_3, F7_0 => F7_5 | F7_3, F7_1 => F7_5 | F7_3, F7_2 => F7_5 | F7_3, F7_3 => F7_5 | F7_3, F7_4 => F7_5 | F7_3, F7_5 => F7_5 | F7_3, F7_6 => F7_5
  | F7_4, F7_0 => F7_4 | F7_4, F7_1 => F7_4 | F7_4, F7_2 => F7_0 | F7_4, F7_3 => F7_6 | F7_4, F7_4 => F7_4 | F7_4, F7_5 => F7_0 | F7_4, F7_6 => F7_4
  | F7_5, F7_0 => F7_1 | F7_5, F7_1 => F7_1 | F7_5, F7_2 => F7_1 | F7_5, F7_3 => F7_1 | F7_5, F7_4 => F7_1 | F7_5, F7_5 => F7_1 | F7_5, F7_6 => F7_1
  | F7_6, F7_0 => F7_6 | F7_6, F7_1 => F7_6 | F7_6, F7_2 => F7_4 | F7_6, F7_3 => F7_0 | F7_6, F7_4 => F7_6 | F7_6, F7_5 => F7_4 | F7_6, F7_6 => F7_6
  end.

#[local] Instance refa892_inst : Magma Fin7 := {| magma_op := refa892_op |}.

Lemma refa892_sat3059 : @Equation3059 Fin7 refa892_inst.
Proof. unfold Equation3059, magma_op, refa892_inst, refa892_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa892_sat3069 : @Equation3069 Fin7 refa892_inst.
Proof. unfold Equation3069, magma_op, refa892_inst, refa892_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa892_sat3076 : @Equation3076 Fin7 refa892_inst.
Proof. unfold Equation3076, magma_op, refa892_inst, refa892_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa892_not3522 : ~ @Equation3522 Fin7 refa892_inst.
Proof. unfold Equation3522. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa892_inst, refa892_op in H. discriminate H. Qed.

(** ---- refa893 (Fin8) ---- *)

Definition refa893_op (x y : Fin8) : Fin8 :=
  match x, y with
  | F8_0, F8_0 => F8_1 | F8_0, F8_1 => F8_5 | F8_0, F8_2 => F8_3 | F8_0, F8_3 => F8_7 | F8_0, F8_4 => F8_2 | F8_0, F8_5 => F8_4 | F8_0, F8_6 => F8_6 | F8_0, F8_7 => F8_0
  | F8_1, F8_0 => F8_2 | F8_1, F8_1 => F8_0 | F8_1, F8_2 => F8_7 | F8_1, F8_3 => F8_3 | F8_1, F8_4 => F8_1 | F8_1, F8_5 => F8_6 | F8_1, F8_6 => F8_4 | F8_1, F8_7 => F8_5
  | F8_2, F8_0 => F8_4 | F8_2, F8_1 => F8_3 | F8_2, F8_2 => F8_5 | F8_2, F8_3 => F8_0 | F8_2, F8_4 => F8_6 | F8_2, F8_5 => F8_1 | F8_2, F8_6 => F8_2 | F8_2, F8_7 => F8_7
  | F8_3, F8_0 => F8_5 | F8_3, F8_1 => F8_1 | F8_3, F8_2 => F8_4 | F8_3, F8_3 => F8_6 | F8_3, F8_4 => F8_0 | F8_3, F8_5 => F8_3 | F8_3, F8_6 => F8_7 | F8_3, F8_7 => F8_2
  | F8_4, F8_0 => F8_3 | F8_4, F8_1 => F8_4 | F8_4, F8_2 => F8_1 | F8_4, F8_3 => F8_2 | F8_4, F8_4 => F8_7 | F8_4, F8_5 => F8_5 | F8_4, F8_6 => F8_0 | F8_4, F8_7 => F8_6
  | F8_5, F8_0 => F8_6 | F8_5, F8_1 => F8_7 | F8_5, F8_2 => F8_0 | F8_5, F8_3 => F8_5 | F8_5, F8_4 => F8_4 | F8_5, F8_5 => F8_2 | F8_5, F8_6 => F8_1 | F8_5, F8_7 => F8_3
  | F8_6, F8_0 => F8_0 | F8_6, F8_1 => F8_2 | F8_6, F8_2 => F8_6 | F8_6, F8_3 => F8_4 | F8_6, F8_4 => F8_5 | F8_6, F8_5 => F8_7 | F8_6, F8_6 => F8_3 | F8_6, F8_7 => F8_1
  | F8_7, F8_0 => F8_7 | F8_7, F8_1 => F8_6 | F8_7, F8_2 => F8_2 | F8_7, F8_3 => F8_1 | F8_7, F8_4 => F8_3 | F8_7, F8_5 => F8_0 | F8_7, F8_6 => F8_5 | F8_7, F8_7 => F8_4
  end.

#[local] Instance refa893_inst : Magma Fin8 := {| magma_op := refa893_op |}.

Lemma refa893_sat2866 : @Equation2866 Fin8 refa893_inst.
Proof. unfold Equation2866, magma_op, refa893_inst, refa893_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa893_not255 : ~ @Equation255 Fin8 refa893_inst.
Proof. unfold Equation255. intro H. specialize (H F8_0). unfold magma_op, refa893_inst, refa893_op in H. discriminate H. Qed.

Lemma refa893_not2035 : ~ @Equation2035 Fin8 refa893_inst.
Proof. unfold Equation2035. intro H. specialize (H F8_0). unfold magma_op, refa893_inst, refa893_op in H. discriminate H. Qed.

Lemma refa893_not2644 : ~ @Equation2644 Fin8 refa893_inst.
Proof. unfold Equation2644. intro H. specialize (H F8_0). unfold magma_op, refa893_inst, refa893_op in H. discriminate H. Qed.

Lemma refa893_not2852 : ~ @Equation2852 Fin8 refa893_inst.
Proof. unfold Equation2852. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa893_inst, refa893_op in H. discriminate H. Qed.

Lemma refa893_not3253 : ~ @Equation3253 Fin8 refa893_inst.
Proof. unfold Equation3253. intro H. specialize (H F8_0). unfold magma_op, refa893_inst, refa893_op in H. discriminate H. Qed.

Lemma refa893_not3456 : ~ @Equation3456 Fin8 refa893_inst.
Proof. unfold Equation3456. intro H. specialize (H F8_0). unfold magma_op, refa893_inst, refa893_op in H. discriminate H. Qed.

Lemma refa893_not4268 : ~ @Equation4268 Fin8 refa893_inst.
Proof. unfold Equation4268. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa893_inst, refa893_op in H. discriminate H. Qed.

Lemma refa893_not4314 : ~ @Equation4314 Fin8 refa893_inst.
Proof. unfold Equation4314. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa893_inst, refa893_op in H. discriminate H. Qed.

Lemma refa893_not4598 : ~ @Equation4598 Fin8 refa893_inst.
Proof. unfold Equation4598. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa893_inst, refa893_op in H. discriminate H. Qed.

(** ---- refa894 (Fin8) ---- *)

Definition refa894_op (x y : Fin8) : Fin8 :=
  match x, y with
  | F8_0, F8_0 => F8_1 | F8_0, F8_1 => F8_2 | F8_0, F8_2 => F8_3 | F8_0, F8_3 => F8_6 | F8_0, F8_4 => F8_3 | F8_0, F8_5 => F8_6 | F8_0, F8_6 => F8_1 | F8_0, F8_7 => F8_2
  | F8_1, F8_0 => F8_2 | F8_1, F8_1 => F8_5 | F8_1, F8_2 => F8_6 | F8_1, F8_3 => F8_5 | F8_1, F8_4 => F8_6 | F8_1, F8_5 => F8_3 | F8_1, F8_6 => F8_2 | F8_1, F8_7 => F8_3
  | F8_2, F8_0 => F8_7 | F8_2, F8_1 => F8_4 | F8_2, F8_2 => F8_5 | F8_2, F8_3 => F8_0 | F8_2, F8_4 => F8_5 | F8_2, F8_5 => F8_0 | F8_2, F8_6 => F8_7 | F8_2, F8_7 => F8_4
  | F8_3, F8_0 => F8_6 | F8_3, F8_1 => F8_7 | F8_3, F8_2 => F8_2 | F8_3, F8_3 => F8_7 | F8_3, F8_4 => F8_2 | F8_3, F8_5 => F8_1 | F8_3, F8_6 => F8_6 | F8_3, F8_7 => F8_1
  | F8_4, F8_0 => F8_3 | F8_4, F8_1 => F8_6 | F8_4, F8_2 => F8_1 | F8_4, F8_3 => F8_2 | F8_4, F8_4 => F8_1 | F8_4, F8_5 => F8_2 | F8_4, F8_6 => F8_3 | F8_4, F8_7 => F8_6
  | F8_5, F8_0 => F8_4 | F8_5, F8_1 => F8_3 | F8_5, F8_2 => F8_0 | F8_5, F8_3 => F8_3 | F8_5, F8_4 => F8_0 | F8_5, F8_5 => F8_5 | F8_5, F8_6 => F8_4 | F8_5, F8_7 => F8_7
  | F8_6, F8_0 => F8_5 | F8_6, F8_1 => F8_0 | F8_6, F8_2 => F8_7 | F8_6, F8_3 => F8_4 | F8_6, F8_4 => F8_7 | F8_6, F8_5 => F8_4 | F8_6, F8_6 => F8_5 | F8_6, F8_7 => F8_0
  | F8_7, F8_0 => F8_0 | F8_7, F8_1 => F8_1 | F8_7, F8_2 => F8_4 | F8_7, F8_3 => F8_1 | F8_7, F8_4 => F8_4 | F8_7, F8_5 => F8_7 | F8_7, F8_6 => F8_0 | F8_7, F8_7 => F8_5
  end.

#[local] Instance refa894_inst : Magma Fin8 := {| magma_op := refa894_op |}.

Lemma refa894_sat2853 : @Equation2853 Fin8 refa894_inst.
Proof. unfold Equation2853, magma_op, refa894_inst, refa894_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa894_not2035 : ~ @Equation2035 Fin8 refa894_inst.
Proof. unfold Equation2035. intro H. specialize (H F8_0). unfold magma_op, refa894_inst, refa894_op in H. discriminate H. Qed.

Lemma refa894_not2644 : ~ @Equation2644 Fin8 refa894_inst.
Proof. unfold Equation2644. intro H. specialize (H F8_0). unfold magma_op, refa894_inst, refa894_op in H. discriminate H. Qed.

Lemma refa894_not2855 : ~ @Equation2855 Fin8 refa894_inst.
Proof. unfold Equation2855. intro H. specialize (H F8_0 F8_3). unfold magma_op, refa894_inst, refa894_op in H. discriminate H. Qed.

Lemma refa894_not2863 : ~ @Equation2863 Fin8 refa894_inst.
Proof. unfold Equation2863. intro H. specialize (H F8_0 F8_2). unfold magma_op, refa894_inst, refa894_op in H. discriminate H. Qed.

Lemma refa894_not2865 : ~ @Equation2865 Fin8 refa894_inst.
Proof. unfold Equation2865. intro H. specialize (H F8_0 F8_2). unfold magma_op, refa894_inst, refa894_op in H. discriminate H. Qed.

Lemma refa894_not2872 : ~ @Equation2872 Fin8 refa894_inst.
Proof. unfold Equation2872. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa894_inst, refa894_op in H. discriminate H. Qed.

Lemma refa894_not3253 : ~ @Equation3253 Fin8 refa894_inst.
Proof. unfold Equation3253. intro H. specialize (H F8_0). unfold magma_op, refa894_inst, refa894_op in H. discriminate H. Qed.

Lemma refa894_not3456 : ~ @Equation3456 Fin8 refa894_inst.
Proof. unfold Equation3456. intro H. specialize (H F8_0). unfold magma_op, refa894_inst, refa894_op in H. discriminate H. Qed.

Lemma refa894_not4270 : ~ @Equation4270 Fin8 refa894_inst.
Proof. unfold Equation4270. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa894_inst, refa894_op in H. discriminate H. Qed.

Lemma refa894_not4283 : ~ @Equation4283 Fin8 refa894_inst.
Proof. unfold Equation4283. intro H. specialize (H F8_0 F8_2). unfold magma_op, refa894_inst, refa894_op in H. discriminate H. Qed.

Lemma refa894_not4598 : ~ @Equation4598 Fin8 refa894_inst.
Proof. unfold Equation4598. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa894_inst, refa894_op in H. discriminate H. Qed.

Lemma refa894_not4656 : ~ @Equation4656 Fin8 refa894_inst.
Proof. unfold Equation4656. intro H. specialize (H F8_0 F8_0 F8_1). unfold magma_op, refa894_inst, refa894_op in H. discriminate H. Qed.

(** ---- refa895 (Fin8) ---- *)

Definition refa895_op (x y : Fin8) : Fin8 :=
  match x, y with
  | F8_0, F8_0 => F8_2 | F8_0, F8_1 => F8_3 | F8_0, F8_2 => F8_1 | F8_0, F8_3 => F8_6 | F8_0, F8_4 => F8_0 | F8_0, F8_5 => F8_4 | F8_0, F8_6 => F8_5 | F8_0, F8_7 => F8_7
  | F8_1, F8_0 => F8_7 | F8_1, F8_1 => F8_0 | F8_1, F8_2 => F8_6 | F8_1, F8_3 => F8_2 | F8_1, F8_4 => F8_4 | F8_1, F8_5 => F8_3 | F8_1, F8_6 => F8_1 | F8_1, F8_7 => F8_5
  | F8_2, F8_0 => F8_3 | F8_2, F8_1 => F8_1 | F8_2, F8_2 => F8_5 | F8_2, F8_3 => F8_7 | F8_2, F8_4 => F8_2 | F8_2, F8_5 => F8_0 | F8_2, F8_6 => F8_4 | F8_2, F8_7 => F8_6
  | F8_3, F8_0 => F8_1 | F8_3, F8_1 => F8_7 | F8_3, F8_2 => F8_3 | F8_3, F8_3 => F8_4 | F8_3, F8_4 => F8_6 | F8_3, F8_5 => F8_5 | F8_3, F8_6 => F8_0 | F8_3, F8_7 => F8_2
  | F8_4, F8_0 => F8_5 | F8_4, F8_1 => F8_2 | F8_4, F8_2 => F8_4 | F8_4, F8_3 => F8_0 | F8_4, F8_4 => F8_7 | F8_4, F8_5 => F8_1 | F8_4, F8_6 => F8_6 | F8_4, F8_7 => F8_3
  | F8_5, F8_0 => F8_0 | F8_5, F8_1 => F8_5 | F8_5, F8_2 => F8_7 | F8_5, F8_3 => F8_1 | F8_5, F8_4 => F8_3 | F8_5, F8_5 => F8_6 | F8_5, F8_6 => F8_2 | F8_5, F8_7 => F8_4
  | F8_6, F8_0 => F8_4 | F8_6, F8_1 => F8_6 | F8_6, F8_2 => F8_2 | F8_6, F8_3 => F8_5 | F8_6, F8_4 => F8_1 | F8_6, F8_5 => F8_7 | F8_6, F8_6 => F8_3 | F8_6, F8_7 => F8_0
  | F8_7, F8_0 => F8_6 | F8_7, F8_1 => F8_4 | F8_7, F8_2 => F8_0 | F8_7, F8_3 => F8_3 | F8_7, F8_4 => F8_5 | F8_7, F8_5 => F8_2 | F8_7, F8_6 => F8_7 | F8_7, F8_7 => F8_1
  end.

#[local] Instance refa895_inst : Magma Fin8 := {| magma_op := refa895_op |}.

Lemma refa895_sat2734 : @Equation2734 Fin8 refa895_inst.
Proof. unfold Equation2734, magma_op, refa895_inst, refa895_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa895_not99 : ~ @Equation99 Fin8 refa895_inst.
Proof. unfold Equation99. intro H. specialize (H F8_0). unfold magma_op, refa895_inst, refa895_op in H. discriminate H. Qed.

Lemma refa895_not411 : ~ @Equation411 Fin8 refa895_inst.
Proof. unfold Equation411. intro H. specialize (H F8_0). unfold magma_op, refa895_inst, refa895_op in H. discriminate H. Qed.

Lemma refa895_not2035 : ~ @Equation2035 Fin8 refa895_inst.
Proof. unfold Equation2035. intro H. specialize (H F8_0). unfold magma_op, refa895_inst, refa895_op in H. discriminate H. Qed.

Lemma refa895_not2743 : ~ @Equation2743 Fin8 refa895_inst.
Proof. unfold Equation2743. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa895_inst, refa895_op in H. discriminate H. Qed.

Lemma refa895_not2847 : ~ @Equation2847 Fin8 refa895_inst.
Proof. unfold Equation2847. intro H. specialize (H F8_0). unfold magma_op, refa895_inst, refa895_op in H. discriminate H. Qed.

Lemma refa895_not4332 : ~ @Equation4332 Fin8 refa895_inst.
Proof. unfold Equation4332. intro H. specialize (H F8_0 F8_0 F8_1). unfold magma_op, refa895_inst, refa895_op in H. discriminate H. Qed.

Lemma refa895_not4343 : ~ @Equation4343 Fin8 refa895_inst.
Proof. unfold Equation4343. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa895_inst, refa895_op in H. discriminate H. Qed.

(** ---- refa896 (Fin8) ---- *)

Definition refa896_op (x y : Fin8) : Fin8 :=
  match x, y with
  | F8_0, F8_0 => F8_1 | F8_0, F8_1 => F8_5 | F8_0, F8_2 => F8_6 | F8_0, F8_3 => F8_3 | F8_0, F8_4 => F8_7 | F8_0, F8_5 => F8_2 | F8_0, F8_6 => F8_4 | F8_0, F8_7 => F8_0
  | F8_1, F8_0 => F8_2 | F8_1, F8_1 => F8_4 | F8_1, F8_2 => F8_3 | F8_1, F8_3 => F8_6 | F8_1, F8_4 => F8_0 | F8_1, F8_5 => F8_1 | F8_1, F8_6 => F8_5 | F8_1, F8_7 => F8_7
  | F8_2, F8_0 => F8_3 | F8_2, F8_1 => F8_7 | F8_2, F8_2 => F8_2 | F8_2, F8_3 => F8_1 | F8_2, F8_4 => F8_5 | F8_2, F8_5 => F8_6 | F8_2, F8_6 => F8_0 | F8_2, F8_7 => F8_4
  | F8_3, F8_0 => F8_5 | F8_3, F8_1 => F8_1 | F8_3, F8_2 => F8_0 | F8_3, F8_3 => F8_7 | F8_3, F8_4 => F8_3 | F8_3, F8_5 => F8_4 | F8_3, F8_6 => F8_2 | F8_3, F8_7 => F8_6
  | F8_4, F8_0 => F8_4 | F8_4, F8_1 => F8_2 | F8_4, F8_2 => F8_7 | F8_4, F8_3 => F8_0 | F8_4, F8_4 => F8_6 | F8_4, F8_5 => F8_5 | F8_4, F8_6 => F8_1 | F8_4, F8_7 => F8_3
  | F8_5, F8_0 => F8_7 | F8_5, F8_1 => F8_3 | F8_5, F8_2 => F8_4 | F8_5, F8_3 => F8_5 | F8_5, F8_4 => F8_1 | F8_5, F8_5 => F8_0 | F8_5, F8_6 => F8_6 | F8_5, F8_7 => F8_2
  | F8_6, F8_0 => F8_0 | F8_6, F8_1 => F8_6 | F8_6, F8_2 => F8_5 | F8_6, F8_3 => F8_4 | F8_6, F8_4 => F8_2 | F8_6, F8_5 => F8_7 | F8_6, F8_6 => F8_3 | F8_6, F8_7 => F8_1
  | F8_7, F8_0 => F8_6 | F8_7, F8_1 => F8_0 | F8_7, F8_2 => F8_1 | F8_7, F8_3 => F8_2 | F8_7, F8_4 => F8_4 | F8_7, F8_5 => F8_3 | F8_7, F8_6 => F8_7 | F8_7, F8_7 => F8_5
  end.

#[local] Instance refa896_inst : Magma Fin8 := {| magma_op := refa896_op |}.

Lemma refa896_sat2504 : @Equation2504 Fin8 refa896_inst.
Proof. unfold Equation2504, magma_op, refa896_inst, refa896_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa896_not40 : ~ @Equation40 Fin8 refa896_inst.
Proof. unfold Equation40. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa896_inst, refa896_op in H. discriminate H. Qed.

Lemma refa896_not47 : ~ @Equation47 Fin8 refa896_inst.
Proof. unfold Equation47. intro H. specialize (H F8_0). unfold magma_op, refa896_inst, refa896_op in H. discriminate H. Qed.

Lemma refa896_not1629 : ~ @Equation1629 Fin8 refa896_inst.
Proof. unfold Equation1629. intro H. specialize (H F8_0). unfold magma_op, refa896_inst, refa896_op in H. discriminate H. Qed.

Lemma refa896_not1832 : ~ @Equation1832 Fin8 refa896_inst.
Proof. unfold Equation1832. intro H. specialize (H F8_0). unfold magma_op, refa896_inst, refa896_op in H. discriminate H. Qed.

Lemma refa896_not2449 : ~ @Equation2449 Fin8 refa896_inst.
Proof. unfold Equation2449. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa896_inst, refa896_op in H. discriminate H. Qed.

Lemma refa896_not2457 : ~ @Equation2457 Fin8 refa896_inst.
Proof. unfold Equation2457. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa896_inst, refa896_op in H. discriminate H. Qed.

Lemma refa896_not3050 : ~ @Equation3050 Fin8 refa896_inst.
Proof. unfold Equation3050. intro H. specialize (H F8_0). unfold magma_op, refa896_inst, refa896_op in H. discriminate H. Qed.

Lemma refa896_not3456 : ~ @Equation3456 Fin8 refa896_inst.
Proof. unfold Equation3456. intro H. specialize (H F8_0). unfold magma_op, refa896_inst, refa896_op in H. discriminate H. Qed.

Lemma refa896_not4065 : ~ @Equation4065 Fin8 refa896_inst.
Proof. unfold Equation4065. intro H. specialize (H F8_0). unfold magma_op, refa896_inst, refa896_op in H. discriminate H. Qed.

Lemma refa896_not4293 : ~ @Equation4293 Fin8 refa896_inst.
Proof. unfold Equation4293. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa896_inst, refa896_op in H. discriminate H. Qed.

Lemma refa896_not4656 : ~ @Equation4656 Fin8 refa896_inst.
Proof. unfold Equation4656. intro H. specialize (H F8_0 F8_0 F8_1). unfold magma_op, refa896_inst, refa896_op in H. discriminate H. Qed.

(** ---- refa897 (Fin7) ---- *)

Definition refa897_op (x y : Fin7) : Fin7 :=
  match x, y with
  | F7_0, F7_0 => F7_1 | F7_0, F7_1 => F7_6 | F7_0, F7_2 => F7_2 | F7_0, F7_3 => F7_0 | F7_0, F7_4 => F7_5 | F7_0, F7_5 => F7_3 | F7_0, F7_6 => F7_4
  | F7_1, F7_0 => F7_2 | F7_1, F7_1 => F7_4 | F7_1, F7_2 => F7_5 | F7_1, F7_3 => F7_3 | F7_1, F7_4 => F7_0 | F7_1, F7_5 => F7_6 | F7_1, F7_6 => F7_1
  | F7_2, F7_0 => F7_0 | F7_2, F7_1 => F7_2 | F7_2, F7_2 => F7_3 | F7_2, F7_3 => F7_4 | F7_2, F7_4 => F7_6 | F7_2, F7_5 => F7_1 | F7_2, F7_6 => F7_5
  | F7_3, F7_0 => F7_5 | F7_3, F7_1 => F7_1 | F7_3, F7_2 => F7_0 | F7_3, F7_3 => F7_6 | F7_3, F7_4 => F7_3 | F7_3, F7_5 => F7_4 | F7_3, F7_6 => F7_2
  | F7_4, F7_0 => F7_4 | F7_4, F7_1 => F7_3 | F7_4, F7_2 => F7_1 | F7_4, F7_3 => F7_5 | F7_4, F7_4 => F7_2 | F7_4, F7_5 => F7_0 | F7_4, F7_6 => F7_6
  | F7_5, F7_0 => F7_6 | F7_5, F7_1 => F7_0 | F7_5, F7_2 => F7_4 | F7_5, F7_3 => F7_2 | F7_5, F7_4 => F7_1 | F7_5, F7_5 => F7_5 | F7_5, F7_6 => F7_3
  | F7_6, F7_0 => F7_3 | F7_6, F7_1 => F7_5 | F7_6, F7_2 => F7_6 | F7_6, F7_3 => F7_1 | F7_6, F7_4 => F7_4 | F7_6, F7_5 => F7_2 | F7_6, F7_6 => F7_0
  end.

#[local] Instance refa897_inst : Magma Fin7 := {| magma_op := refa897_op |}.

Lemma refa897_sat2467 : @Equation2467 Fin7 refa897_inst.
Proof. unfold Equation2467, magma_op, refa897_inst, refa897_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa897_not151 : ~ @Equation151 Fin7 refa897_inst.
Proof. unfold Equation151. intro H. specialize (H F7_0). unfold magma_op, refa897_inst, refa897_op in H. discriminate H. Qed.

Lemma refa897_not203 : ~ @Equation203 Fin7 refa897_inst.
Proof. unfold Equation203. intro H. specialize (H F7_0). unfold magma_op, refa897_inst, refa897_op in H. discriminate H. Qed.

Lemma refa897_not1426 : ~ @Equation1426 Fin7 refa897_inst.
Proof. unfold Equation1426. intro H. specialize (H F7_0). unfold magma_op, refa897_inst, refa897_op in H. discriminate H. Qed.

Lemma refa897_not1629 : ~ @Equation1629 Fin7 refa897_inst.
Proof. unfold Equation1629. intro H. specialize (H F7_0). unfold magma_op, refa897_inst, refa897_op in H. discriminate H. Qed.

Lemma refa897_not1832 : ~ @Equation1832 Fin7 refa897_inst.
Proof. unfold Equation1832. intro H. specialize (H F7_0). unfold magma_op, refa897_inst, refa897_op in H. discriminate H. Qed.

Lemma refa897_not2238 : ~ @Equation2238 Fin7 refa897_inst.
Proof. unfold Equation2238. intro H. specialize (H F7_0). unfold magma_op, refa897_inst, refa897_op in H. discriminate H. Qed.

Lemma refa897_not2443 : ~ @Equation2443 Fin7 refa897_inst.
Proof. unfold Equation2443. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa897_inst, refa897_op in H. discriminate H. Qed.

Lemma refa897_not2449 : ~ @Equation2449 Fin7 refa897_inst.
Proof. unfold Equation2449. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa897_inst, refa897_op in H. discriminate H. Qed.

Lemma refa897_not2457 : ~ @Equation2457 Fin7 refa897_inst.
Proof. unfold Equation2457. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa897_inst, refa897_op in H. discriminate H. Qed.

Lemma refa897_not2460 : ~ @Equation2460 Fin7 refa897_inst.
Proof. unfold Equation2460. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa897_inst, refa897_op in H. discriminate H. Qed.

Lemma refa897_not3050 : ~ @Equation3050 Fin7 refa897_inst.
Proof. unfold Equation3050. intro H. specialize (H F7_0). unfold magma_op, refa897_inst, refa897_op in H. discriminate H. Qed.

Lemma refa897_not3253 : ~ @Equation3253 Fin7 refa897_inst.
Proof. unfold Equation3253. intro H. specialize (H F7_0). unfold magma_op, refa897_inst, refa897_op in H. discriminate H. Qed.

Lemma refa897_not3456 : ~ @Equation3456 Fin7 refa897_inst.
Proof. unfold Equation3456. intro H. specialize (H F7_0). unfold magma_op, refa897_inst, refa897_op in H. discriminate H. Qed.

Lemma refa897_not4065 : ~ @Equation4065 Fin7 refa897_inst.
Proof. unfold Equation4065. intro H. specialize (H F7_0). unfold magma_op, refa897_inst, refa897_op in H. discriminate H. Qed.

Lemma refa897_not4268 : ~ @Equation4268 Fin7 refa897_inst.
Proof. unfold Equation4268. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa897_inst, refa897_op in H. discriminate H. Qed.

Lemma refa897_not4314 : ~ @Equation4314 Fin7 refa897_inst.
Proof. unfold Equation4314. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa897_inst, refa897_op in H. discriminate H. Qed.

Lemma refa897_not4585 : ~ @Equation4585 Fin7 refa897_inst.
Proof. unfold Equation4585. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa897_inst, refa897_op in H. discriminate H. Qed.

Lemma refa897_not4598 : ~ @Equation4598 Fin7 refa897_inst.
Proof. unfold Equation4598. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa897_inst, refa897_op in H. discriminate H. Qed.

(** ---- refa898 (Fin5) ---- *)

Definition refa898_op (x y : Fin5) : Fin5 :=
  match x, y with
  | F5_0, F5_0 => F5_3 | F5_0, F5_1 => F5_2 | F5_0, F5_2 => F5_3 | F5_0, F5_3 => F5_3 | F5_0, F5_4 => F5_3
  | F5_1, F5_0 => F5_1 | F5_1, F5_1 => F5_4 | F5_1, F5_2 => F5_1 | F5_1, F5_3 => F5_1 | F5_1, F5_4 => F5_4
  | F5_2, F5_0 => F5_2 | F5_2, F5_1 => F5_3 | F5_2, F5_2 => F5_2 | F5_2, F5_3 => F5_2 | F5_2, F5_4 => F5_0
  | F5_3, F5_0 => F5_0 | F5_3, F5_1 => F5_0 | F5_3, F5_2 => F5_0 | F5_3, F5_3 => F5_0 | F5_3, F5_4 => F5_2
  | F5_4, F5_0 => F5_4 | F5_4, F5_1 => F5_1 | F5_4, F5_2 => F5_4 | F5_4, F5_3 => F5_4 | F5_4, F5_4 => F5_1
  end.

#[local] Instance refa898_inst : Magma Fin5 := {| magma_op := refa898_op |}.

Lemma refa898_sat2460 : @Equation2460 Fin5 refa898_inst.
Proof. unfold Equation2460, magma_op, refa898_inst, refa898_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa898_not26 : ~ @Equation26 Fin5 refa898_inst.
Proof. unfold Equation26. intro H. specialize (H F5_0 F5_1). unfold magma_op, refa898_inst, refa898_op in H. discriminate H. Qed.

(** ---- refa899 (Fin9) ---- *)

Definition refa899_op (x y : Fin9) : Fin9 :=
  match x, y with
  | F9_0, F9_0 => F9_2 | F9_0, F9_1 => F9_8 | F9_0, F9_2 => F9_7 | F9_0, F9_3 => F9_2 | F9_0, F9_4 => F9_8 | F9_0, F9_5 => F9_8 | F9_0, F9_6 => F9_2 | F9_0, F9_7 => F9_7 | F9_0, F9_8 => F9_7
  | F9_1, F9_0 => F9_1 | F9_1, F9_1 => F9_1 | F9_1, F9_2 => F9_0 | F9_1, F9_3 => F9_6 | F9_1, F9_4 => F9_6 | F9_1, F9_5 => F9_6 | F9_1, F9_6 => F9_1 | F9_1, F9_7 => F9_0 | F9_1, F9_8 => F9_0
  | F9_2, F9_0 => F9_3 | F9_2, F9_1 => F9_3 | F9_2, F9_2 => F9_0 | F9_2, F9_3 => F9_6 | F9_2, F9_4 => F9_6 | F9_2, F9_5 => F9_6 | F9_2, F9_6 => F9_3 | F9_2, F9_7 => F9_0 | F9_2, F9_8 => F9_0
  | F9_3, F9_0 => F9_1 | F9_3, F9_1 => F9_1 | F9_3, F9_2 => F9_0 | F9_3, F9_3 => F9_6 | F9_3, F9_4 => F9_6 | F9_3, F9_5 => F9_6 | F9_3, F9_6 => F9_1 | F9_3, F9_7 => F9_0 | F9_3, F9_8 => F9_0
  | F9_4, F9_0 => F9_3 | F9_4, F9_1 => F9_3 | F9_4, F9_2 => F9_5 | F9_4, F9_3 => F9_4 | F9_4, F9_4 => F9_4 | F9_4, F9_5 => F9_4 | F9_4, F9_6 => F9_3 | F9_4, F9_7 => F9_5 | F9_4, F9_8 => F9_5
  | F9_5, F9_0 => F9_2 | F9_5, F9_1 => F9_8 | F9_5, F9_2 => F9_7 | F9_5, F9_3 => F9_2 | F9_5, F9_4 => F9_8 | F9_5, F9_5 => F9_8 | F9_5, F9_6 => F9_2 | F9_5, F9_7 => F9_7 | F9_5, F9_8 => F9_7
  | F9_6, F9_0 => F9_3 | F9_6, F9_1 => F9_3 | F9_6, F9_2 => F9_5 | F9_6, F9_3 => F9_4 | F9_6, F9_4 => F9_4 | F9_6, F9_5 => F9_4 | F9_6, F9_6 => F9_3 | F9_6, F9_7 => F9_5 | F9_6, F9_8 => F9_5
  | F9_7, F9_0 => F9_2 | F9_7, F9_1 => F9_8 | F9_7, F9_2 => F9_7 | F9_7, F9_3 => F9_2 | F9_7, F9_4 => F9_8 | F9_7, F9_5 => F9_8 | F9_7, F9_6 => F9_2 | F9_7, F9_7 => F9_7 | F9_7, F9_8 => F9_7
  | F9_8, F9_0 => F9_1 | F9_8, F9_1 => F9_1 | F9_8, F9_2 => F9_5 | F9_8, F9_3 => F9_4 | F9_8, F9_4 => F9_4 | F9_8, F9_5 => F9_4 | F9_8, F9_6 => F9_1 | F9_8, F9_7 => F9_5 | F9_8, F9_8 => F9_5
  end.

#[local] Instance refa899_inst : Magma Fin9 := {| magma_op := refa899_op |}.

Lemma refa899_sat168 : @Equation168 Fin9 refa899_inst.
Proof. unfold Equation168, magma_op, refa899_inst, refa899_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa899_not3461 : ~ @Equation3461 Fin9 refa899_inst.
Proof. unfold Equation3461. intro H. specialize (H F9_0 F9_1). unfold magma_op, refa899_inst, refa899_op in H. discriminate H. Qed.

Lemma refa899_not3462 : ~ @Equation3462 Fin9 refa899_inst.
Proof. unfold Equation3462. intro H. specialize (H F9_0 F9_1). unfold magma_op, refa899_inst, refa899_op in H. discriminate H. Qed.

Lemma refa899_not3521 : ~ @Equation3521 Fin9 refa899_inst.
Proof. unfold Equation3521. intro H. specialize (H F9_0 F9_4). unfold magma_op, refa899_inst, refa899_op in H. discriminate H. Qed.

Lemma refa899_not3522 : ~ @Equation3522 Fin9 refa899_inst.
Proof. unfold Equation3522. intro H. specialize (H F9_0 F9_3). unfold magma_op, refa899_inst, refa899_op in H. discriminate H. Qed.

Lemma refa899_not3864 : ~ @Equation3864 Fin9 refa899_inst.
Proof. unfold Equation3864. intro H. specialize (H F9_2 F9_0). unfold magma_op, refa899_inst, refa899_op in H. discriminate H. Qed.

Lemma refa899_not3880 : ~ @Equation3880 Fin9 refa899_inst.
Proof. unfold Equation3880. intro H. specialize (H F9_1 F9_5). unfold magma_op, refa899_inst, refa899_op in H. discriminate H. Qed.

Lemma refa899_not3915 : ~ @Equation3915 Fin9 refa899_inst.
Proof. unfold Equation3915. intro H. specialize (H F9_2 F9_0). unfold magma_op, refa899_inst, refa899_op in H. discriminate H. Qed.

Lemma refa899_not3952 : ~ @Equation3952 Fin9 refa899_inst.
Proof. unfold Equation3952. intro H. specialize (H F9_1 F9_5). unfold magma_op, refa899_inst, refa899_op in H. discriminate H. Qed.

Lemma refa899_not4268 : ~ @Equation4268 Fin9 refa899_inst.
Proof. unfold Equation4268. intro H. specialize (H F9_2 F9_0). unfold magma_op, refa899_inst, refa899_op in H. discriminate H. Qed.

Lemma refa899_not4314 : ~ @Equation4314 Fin9 refa899_inst.
Proof. unfold Equation4314. intro H. specialize (H F9_0 F9_3). unfold magma_op, refa899_inst, refa899_op in H. discriminate H. Qed.

Lemma refa899_not4606 : ~ @Equation4606 Fin9 refa899_inst.
Proof. unfold Equation4606. intro H. specialize (H F9_0 F9_1). unfold magma_op, refa899_inst, refa899_op in H. discriminate H. Qed.

Lemma refa899_not4666 : ~ @Equation4666 Fin9 refa899_inst.
Proof. unfold Equation4666. intro H. specialize (H F9_0 F9_0 F9_1). unfold magma_op, refa899_inst, refa899_op in H. discriminate H. Qed.

(** ---- refa9 (Fin6) ---- *)

Definition refa9_op (x y : Fin6) : Fin6 :=
  match x, y with
  | F6_0, F6_0 => F6_1 | F6_0, F6_1 => F6_2 | F6_0, F6_2 => F6_3 | F6_0, F6_3 => F6_4 | F6_0, F6_4 => F6_5 | F6_0, F6_5 => F6_0
  | F6_1, F6_0 => F6_4 | F6_1, F6_1 => F6_1 | F6_1, F6_2 => F6_2 | F6_1, F6_3 => F6_5 | F6_1, F6_4 => F6_0 | F6_1, F6_5 => F6_3
  | F6_2, F6_0 => F6_3 | F6_2, F6_1 => F6_0 | F6_2, F6_2 => F6_5 | F6_2, F6_3 => F6_2 | F6_2, F6_4 => F6_1 | F6_2, F6_5 => F6_4
  | F6_3, F6_0 => F6_0 | F6_3, F6_1 => F6_5 | F6_3, F6_2 => F6_4 | F6_3, F6_3 => F6_3 | F6_3, F6_4 => F6_2 | F6_3, F6_5 => F6_1
  | F6_4, F6_0 => F6_5 | F6_4, F6_1 => F6_4 | F6_4, F6_2 => F6_1 | F6_4, F6_3 => F6_0 | F6_4, F6_4 => F6_3 | F6_4, F6_5 => F6_2
  | F6_5, F6_0 => F6_2 | F6_5, F6_1 => F6_3 | F6_5, F6_2 => F6_0 | F6_5, F6_3 => F6_1 | F6_5, F6_4 => F6_4 | F6_5, F6_5 => F6_5
  end.

#[local] Instance refa9_inst : Magma Fin6 := {| magma_op := refa9_op |}.

Lemma refa9_sat1316 : @Equation1316 Fin6 refa9_inst.
Proof. unfold Equation1316, magma_op, refa9_inst, refa9_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa9_sat2863 : @Equation2863 Fin6 refa9_inst.
Proof. unfold Equation2863, magma_op, refa9_inst, refa9_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa9_not411 : ~ @Equation411 Fin6 refa9_inst.
Proof. unfold Equation411. intro H. specialize (H F6_0). unfold magma_op, refa9_inst, refa9_op in H. discriminate H. Qed.

Lemma refa9_not680 : ~ @Equation680 Fin6 refa9_inst.
Proof. unfold Equation680. intro H. specialize (H F6_0 F6_1). unfold magma_op, refa9_inst, refa9_op in H. discriminate H. Qed.

Lemma refa9_not817 : ~ @Equation817 Fin6 refa9_inst.
Proof. unfold Equation817. intro H. specialize (H F6_0). unfold magma_op, refa9_inst, refa9_op in H. discriminate H. Qed.

Lemma refa9_not1020 : ~ @Equation1020 Fin6 refa9_inst.
Proof. unfold Equation1020. intro H. specialize (H F6_0). unfold magma_op, refa9_inst, refa9_op in H. discriminate H. Qed.

Lemma refa9_not1426 : ~ @Equation1426 Fin6 refa9_inst.
Proof. unfold Equation1426. intro H. specialize (H F6_0). unfold magma_op, refa9_inst, refa9_op in H. discriminate H. Qed.

Lemma refa9_not2035 : ~ @Equation2035 Fin6 refa9_inst.
Proof. unfold Equation2035. intro H. specialize (H F6_0). unfold magma_op, refa9_inst, refa9_op in H. discriminate H. Qed.

Lemma refa9_not2441 : ~ @Equation2441 Fin6 refa9_inst.
Proof. unfold Equation2441. intro H. specialize (H F6_0). unfold magma_op, refa9_inst, refa9_op in H. discriminate H. Qed.

Lemma refa9_not2644 : ~ @Equation2644 Fin6 refa9_inst.
Proof. unfold Equation2644. intro H. specialize (H F6_0). unfold magma_op, refa9_inst, refa9_op in H. discriminate H. Qed.

Lemma refa9_not2853 : ~ @Equation2853 Fin6 refa9_inst.
Proof. unfold Equation2853. intro H. specialize (H F6_0 F6_1). unfold magma_op, refa9_inst, refa9_op in H. discriminate H. Qed.

Lemma refa9_not2855 : ~ @Equation2855 Fin6 refa9_inst.
Proof. unfold Equation2855. intro H. specialize (H F6_0 F6_1). unfold magma_op, refa9_inst, refa9_op in H. discriminate H. Qed.

Lemma refa9_not2865 : ~ @Equation2865 Fin6 refa9_inst.
Proof. unfold Equation2865. intro H. specialize (H F6_0 F6_2). unfold magma_op, refa9_inst, refa9_op in H. discriminate H. Qed.

Lemma refa9_not2872 : ~ @Equation2872 Fin6 refa9_inst.
Proof. unfold Equation2872. intro H. specialize (H F6_0 F6_2). unfold magma_op, refa9_inst, refa9_op in H. discriminate H. Qed.

Lemma refa9_not2947 : ~ @Equation2947 Fin6 refa9_inst.
Proof. unfold Equation2947. intro H. specialize (H F6_0 F6_1). unfold magma_op, refa9_inst, refa9_op in H. discriminate H. Qed.

Lemma refa9_not3050 : ~ @Equation3050 Fin6 refa9_inst.
Proof. unfold Equation3050. intro H. specialize (H F6_0). unfold magma_op, refa9_inst, refa9_op in H. discriminate H. Qed.

Lemma refa9_not3253 : ~ @Equation3253 Fin6 refa9_inst.
Proof. unfold Equation3253. intro H. specialize (H F6_0). unfold magma_op, refa9_inst, refa9_op in H. discriminate H. Qed.

Lemma refa9_not3456 : ~ @Equation3456 Fin6 refa9_inst.
Proof. unfold Equation3456. intro H. specialize (H F6_0). unfold magma_op, refa9_inst, refa9_op in H. discriminate H. Qed.

Lemma refa9_not4270 : ~ @Equation4270 Fin6 refa9_inst.
Proof. unfold Equation4270. intro H. specialize (H F6_0 F6_2). unfold magma_op, refa9_inst, refa9_op in H. discriminate H. Qed.

Lemma refa9_not4283 : ~ @Equation4283 Fin6 refa9_inst.
Proof. unfold Equation4283. intro H. specialize (H F6_0 F6_1). unfold magma_op, refa9_inst, refa9_op in H. discriminate H. Qed.

Lemma refa9_not4290 : ~ @Equation4290 Fin6 refa9_inst.
Proof. unfold Equation4290. intro H. specialize (H F6_0 F6_1). unfold magma_op, refa9_inst, refa9_op in H. discriminate H. Qed.

Lemma refa9_not4380 : ~ @Equation4380 Fin6 refa9_inst.
Proof. unfold Equation4380. intro H. specialize (H F6_0). unfold magma_op, refa9_inst, refa9_op in H. discriminate H. Qed.

Lemma refa9_not4598 : ~ @Equation4598 Fin6 refa9_inst.
Proof. unfold Equation4598. intro H. specialize (H F6_0 F6_1). unfold magma_op, refa9_inst, refa9_op in H. discriminate H. Qed.

Lemma refa9_not4605 : ~ @Equation4605 Fin6 refa9_inst.
Proof. unfold Equation4605. intro H. specialize (H F6_0 F6_1). unfold magma_op, refa9_inst, refa9_op in H. discriminate H. Qed.

Lemma refa9_not4656 : ~ @Equation4656 Fin6 refa9_inst.
Proof. unfold Equation4656. intro H. specialize (H F6_0 F6_0 F6_1). unfold magma_op, refa9_inst, refa9_op in H. discriminate H. Qed.

(** ---- refa90 (Fin3) ---- *)

Definition refa90_op (x y : Fin3) : Fin3 :=
  match x, y with
  | F3_0, F3_0 => F3_0 | F3_0, F3_1 => F3_0 | F3_0, F3_2 => F3_0
  | F3_1, F3_0 => F3_0 | F3_1, F3_1 => F3_1 | F3_1, F3_2 => F3_1
  | F3_2, F3_0 => F3_1 | F3_2, F3_1 => F3_0 | F3_2, F3_2 => F3_2
  end.

#[local] Instance refa90_inst : Magma Fin3 := {| magma_op := refa90_op |}.

Lemma refa90_sat3 : @Equation3 Fin3 refa90_inst.
Proof. unfold Equation3, magma_op, refa90_inst, refa90_op. intros x. destruct x; reflexivity. Qed.

Lemma refa90_sat377 : @Equation377 Fin3 refa90_inst.
Proof. unfold Equation377, magma_op, refa90_inst, refa90_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa90_sat3318 : @Equation3318 Fin3 refa90_inst.
Proof. unfold Equation3318, magma_op, refa90_inst, refa90_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa90_not3315 : ~ @Equation3315 Fin3 refa90_inst.
Proof. unfold Equation3315. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa90_inst, refa90_op in H. discriminate H. Qed.

Lemma refa90_not3316 : ~ @Equation3316 Fin3 refa90_inst.
Proof. unfold Equation3316. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa90_inst, refa90_op in H. discriminate H. Qed.

Lemma refa90_not3519 : ~ @Equation3519 Fin3 refa90_inst.
Proof. unfold Equation3519. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa90_inst, refa90_op in H. discriminate H. Qed.

Lemma refa90_not3724 : ~ @Equation3724 Fin3 refa90_inst.
Proof. unfold Equation3724. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa90_inst, refa90_op in H. discriminate H. Qed.

Lemma refa90_not3918 : ~ @Equation3918 Fin3 refa90_inst.
Proof. unfold Equation3918. intro H. specialize (H F3_2 F3_0). unfold magma_op, refa90_inst, refa90_op in H. discriminate H. Qed.

Lemma refa90_not3925 : ~ @Equation3925 Fin3 refa90_inst.
Proof. unfold Equation3925. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa90_inst, refa90_op in H. discriminate H. Qed.

Lemma refa90_not4128 : ~ @Equation4128 Fin3 refa90_inst.
Proof. unfold Equation4128. intro H. specialize (H F3_2 F3_0). unfold magma_op, refa90_inst, refa90_op in H. discriminate H. Qed.

Lemma refa90_not4130 : ~ @Equation4130 Fin3 refa90_inst.
Proof. unfold Equation4130. intro H. specialize (H F3_2 F3_0). unfold magma_op, refa90_inst, refa90_op in H. discriminate H. Qed.

Lemma refa90_not4131 : ~ @Equation4131 Fin3 refa90_inst.
Proof. unfold Equation4131. intro H. specialize (H F3_2 F3_0). unfold magma_op, refa90_inst, refa90_op in H. discriminate H. Qed.

Lemma refa90_not4629 : ~ @Equation4629 Fin3 refa90_inst.
Proof. unfold Equation4629. intro H. specialize (H F3_2 F3_0). unfold magma_op, refa90_inst, refa90_op in H. discriminate H. Qed.

(** ---- refa900 (Fin5) ---- *)

Definition refa900_op (x y : Fin5) : Fin5 :=
  match x, y with
  | F5_0, F5_0 => F5_2 | F5_0, F5_1 => F5_1 | F5_0, F5_2 => F5_3 | F5_0, F5_3 => F5_1 | F5_0, F5_4 => F5_2
  | F5_1, F5_0 => F5_3 | F5_1, F5_1 => F5_1 | F5_1, F5_2 => F5_3 | F5_1, F5_3 => F5_1 | F5_1, F5_4 => F5_3
  | F5_2, F5_0 => F5_4 | F5_2, F5_1 => F5_0 | F5_2, F5_2 => F5_0 | F5_2, F5_3 => F5_0 | F5_2, F5_4 => F5_4
  | F5_3, F5_0 => F5_2 | F5_3, F5_1 => F5_0 | F5_3, F5_2 => F5_0 | F5_3, F5_3 => F5_0 | F5_3, F5_4 => F5_2
  | F5_4, F5_0 => F5_4 | F5_4, F5_1 => F5_0 | F5_4, F5_2 => F5_0 | F5_4, F5_3 => F5_0 | F5_4, F5_4 => F5_4
  end.

#[local] Instance refa900_inst : Magma Fin5 := {| magma_op := refa900_op |}.

Lemma refa900_sat2089 : @Equation2089 Fin5 refa900_inst.
Proof. unfold Equation2089, magma_op, refa900_inst, refa900_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa900_not4282 : ~ @Equation4282 Fin5 refa900_inst.
Proof. unfold Equation4282. intro H. specialize (H F5_0 F5_0 F5_1). unfold magma_op, refa900_inst, refa900_op in H. discriminate H. Qed.

(** ---- refa901 (Fin5) ---- *)

Definition refa901_op (x y : Fin5) : Fin5 :=
  match x, y with
  | F5_0, F5_0 => F5_0 | F5_0, F5_1 => F5_0 | F5_0, F5_2 => F5_3 | F5_0, F5_3 => F5_0 | F5_0, F5_4 => F5_0
  | F5_1, F5_0 => F5_2 | F5_1, F5_1 => F5_1 | F5_1, F5_2 => F5_1 | F5_1, F5_3 => F5_2 | F5_1, F5_4 => F5_2
  | F5_2, F5_0 => F5_0 | F5_2, F5_1 => F5_4 | F5_2, F5_2 => F5_4 | F5_2, F5_3 => F5_0 | F5_2, F5_4 => F5_4
  | F5_3, F5_0 => F5_2 | F5_3, F5_1 => F5_2 | F5_3, F5_2 => F5_2 | F5_3, F5_3 => F5_2 | F5_3, F5_4 => F5_2
  | F5_4, F5_0 => F5_1 | F5_4, F5_1 => F5_1 | F5_4, F5_2 => F5_1 | F5_4, F5_3 => F5_1 | F5_4, F5_4 => F5_1
  end.

#[local] Instance refa901_inst : Magma Fin5 := {| magma_op := refa901_op |}.

Lemma refa901_sat2052 : @Equation2052 Fin5 refa901_inst.
Proof. unfold Equation2052, magma_op, refa901_inst, refa901_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa901_not4314 : ~ @Equation4314 Fin5 refa901_inst.
Proof. unfold Equation4314. intro H. specialize (H F5_0 F5_1). unfold magma_op, refa901_inst, refa901_op in H. discriminate H. Qed.

(** ---- refa902 (Fin6) ---- *)

Definition refa902_op (x y : Fin6) : Fin6 :=
  match x, y with
  | F6_0, F6_0 => F6_1 | F6_0, F6_1 => F6_3 | F6_0, F6_2 => F6_5 | F6_0, F6_3 => F6_1 | F6_0, F6_4 => F6_2 | F6_0, F6_5 => F6_2
  | F6_1, F6_0 => F6_2 | F6_1, F6_1 => F6_4 | F6_1, F6_2 => F6_1 | F6_1, F6_3 => F6_0 | F6_1, F6_4 => F6_5 | F6_1, F6_5 => F6_1
  | F6_2, F6_0 => F6_3 | F6_2, F6_1 => F6_2 | F6_2, F6_2 => F6_4 | F6_2, F6_3 => F6_2 | F6_2, F6_4 => F6_3 | F6_2, F6_5 => F6_0
  | F6_3, F6_0 => F6_5 | F6_3, F6_1 => F6_0 | F6_3, F6_2 => F6_3 | F6_3, F6_3 => F6_4 | F6_3, F6_4 => F6_2 | F6_3, F6_5 => F6_3
  | F6_4, F6_0 => F6_5 | F6_4, F6_1 => F6_1 | F6_4, F6_2 => F6_2 | F6_4, F6_3 => F6_3 | F6_4, F6_4 => F6_5 | F6_4, F6_5 => F6_5
  | F6_5, F6_0 => F6_1 | F6_5, F6_1 => F6_5 | F6_5, F6_2 => F6_0 | F6_5, F6_3 => F6_5 | F6_5, F6_4 => F6_1 | F6_5, F6_5 => F6_4
  end.

#[local] Instance refa902_inst : Magma Fin6 := {| magma_op := refa902_op |}.

Lemma refa902_sat1922 : @Equation1922 Fin6 refa902_inst.
Proof. unfold Equation1922, magma_op, refa902_inst, refa902_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa902_not1838 : ~ @Equation1838 Fin6 refa902_inst.
Proof. unfold Equation1838. intro H. specialize (H F6_1 F6_3). unfold magma_op, refa902_inst, refa902_op in H. discriminate H. Qed.

Lemma refa902_not4065 : ~ @Equation4065 Fin6 refa902_inst.
Proof. unfold Equation4065. intro H. specialize (H F6_0). unfold magma_op, refa902_inst, refa902_op in H. discriminate H. Qed.

Lemma refa902_not4293 : ~ @Equation4293 Fin6 refa902_inst.
Proof. unfold Equation4293. intro H. specialize (H F6_1 F6_3). unfold magma_op, refa902_inst, refa902_op in H. discriminate H. Qed.

Lemma refa902_not4636 : ~ @Equation4636 Fin6 refa902_inst.
Proof. unfold Equation4636. intro H. specialize (H F6_0 F6_1). unfold magma_op, refa902_inst, refa902_op in H. discriminate H. Qed.

(** ---- refa903 (Fin6) ---- *)

Definition refa903_op (x y : Fin6) : Fin6 :=
  match x, y with
  | F6_0, F6_0 => F6_1 | F6_0, F6_1 => F6_2 | F6_0, F6_2 => F6_3 | F6_0, F6_3 => F6_1 | F6_0, F6_4 => F6_3 | F6_0, F6_5 => F6_2
  | F6_1, F6_0 => F6_5 | F6_1, F6_1 => F6_5 | F6_1, F6_2 => F6_0 | F6_1, F6_3 => F6_4 | F6_1, F6_4 => F6_0 | F6_1, F6_5 => F6_4
  | F6_2, F6_0 => F6_0 | F6_2, F6_1 => F6_0 | F6_2, F6_2 => F6_4 | F6_2, F6_3 => F6_5 | F6_2, F6_4 => F6_4 | F6_2, F6_5 => F6_5
  | F6_3, F6_0 => F6_4 | F6_3, F6_1 => F6_4 | F6_3, F6_2 => F6_5 | F6_3, F6_3 => F6_0 | F6_3, F6_4 => F6_5 | F6_3, F6_5 => F6_0
  | F6_4, F6_0 => F6_3 | F6_4, F6_1 => F6_1 | F6_4, F6_2 => F6_2 | F6_4, F6_3 => F6_3 | F6_4, F6_4 => F6_2 | F6_4, F6_5 => F6_1
  | F6_5, F6_0 => F6_2 | F6_5, F6_1 => F6_3 | F6_5, F6_2 => F6_1 | F6_5, F6_3 => F6_2 | F6_5, F6_4 => F6_1 | F6_5, F6_5 => F6_3
  end.

#[local] Instance refa903_inst : Magma Fin6 := {| magma_op := refa903_op |}.

Lemma refa903_sat1841 : @Equation1841 Fin6 refa903_inst.
Proof. unfold Equation1841, magma_op, refa903_inst, refa903_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa903_not2238 : ~ @Equation2238 Fin6 refa903_inst.
Proof. unfold Equation2238. intro H. specialize (H F6_0). unfold magma_op, refa903_inst, refa903_op in H. discriminate H. Qed.

(** ---- refa904 (Fin6) ---- *)

Definition refa904_op (x y : Fin6) : Fin6 :=
  match x, y with
  | F6_0, F6_0 => F6_1 | F6_0, F6_1 => F6_2 | F6_0, F6_2 => F6_3 | F6_0, F6_3 => F6_2 | F6_0, F6_4 => F6_2 | F6_0, F6_5 => F6_4
  | F6_1, F6_0 => F6_5 | F6_1, F6_1 => F6_1 | F6_1, F6_2 => F6_2 | F6_1, F6_3 => F6_3 | F6_1, F6_4 => F6_3 | F6_1, F6_5 => F6_0
  | F6_2, F6_0 => F6_3 | F6_2, F6_1 => F6_0 | F6_2, F6_2 => F6_4 | F6_2, F6_3 => F6_0 | F6_2, F6_4 => F6_0 | F6_2, F6_5 => F6_1
  | F6_3, F6_0 => F6_2 | F6_3, F6_1 => F6_3 | F6_3, F6_2 => F6_0 | F6_3, F6_3 => F6_1 | F6_3, F6_4 => F6_1 | F6_3, F6_5 => F6_5
  | F6_4, F6_0 => F6_0 | F6_4, F6_1 => F6_4 | F6_4, F6_2 => F6_5 | F6_4, F6_3 => F6_4 | F6_4, F6_4 => F6_4 | F6_4, F6_5 => F6_2
  | F6_5, F6_0 => F6_4 | F6_5, F6_1 => F6_5 | F6_5, F6_2 => F6_1 | F6_5, F6_3 => F6_5 | F6_5, F6_4 => F6_5 | F6_5, F6_5 => F6_3
  end.

#[local] Instance refa904_inst : Magma Fin6 := {| magma_op := refa904_op |}.

Lemma refa904_sat2447 : @Equation2447 Fin6 refa904_inst.
Proof. unfold Equation2447, magma_op, refa904_inst, refa904_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa904_not2470 : ~ @Equation2470 Fin6 refa904_inst.
Proof. unfold Equation2470. intro H. specialize (H F6_0 F6_2). unfold magma_op, refa904_inst, refa904_op in H. discriminate H. Qed.

Lemma refa904_not3253 : ~ @Equation3253 Fin6 refa904_inst.
Proof. unfold Equation3253. intro H. specialize (H F6_0). unfold magma_op, refa904_inst, refa904_op in H. discriminate H. Qed.

(** ---- refa905 (Fin6) ---- *)

Definition refa905_op (x y : Fin6) : Fin6 :=
  match x, y with
  | F6_0, F6_0 => F6_1 | F6_0, F6_1 => F6_2 | F6_0, F6_2 => F6_3 | F6_0, F6_3 => F6_5 | F6_0, F6_4 => F6_1 | F6_0, F6_5 => F6_1
  | F6_1, F6_0 => F6_3 | F6_1, F6_1 => F6_4 | F6_1, F6_2 => F6_2 | F6_1, F6_3 => F6_0 | F6_1, F6_4 => F6_1 | F6_1, F6_5 => F6_5
  | F6_2, F6_0 => F6_5 | F6_2, F6_1 => F6_1 | F6_2, F6_2 => F6_4 | F6_2, F6_3 => F6_3 | F6_2, F6_4 => F6_2 | F6_2, F6_5 => F6_0
  | F6_3, F6_0 => F6_1 | F6_3, F6_1 => F6_0 | F6_3, F6_2 => F6_2 | F6_3, F6_3 => F6_4 | F6_3, F6_4 => F6_3 | F6_3, F6_5 => F6_5
  | F6_4, F6_0 => F6_3 | F6_4, F6_1 => F6_2 | F6_4, F6_2 => F6_1 | F6_4, F6_3 => F6_5 | F6_4, F6_4 => F6_2 | F6_4, F6_5 => F6_3
  | F6_5, F6_0 => F6_2 | F6_5, F6_1 => F6_1 | F6_5, F6_2 => F6_0 | F6_5, F6_3 => F6_3 | F6_5, F6_4 => F6_5 | F6_5, F6_5 => F6_4
  end.

#[local] Instance refa905_inst : Magma Fin6 := {| magma_op := refa905_op |}.

Lemma refa905_sat1685 : @Equation1685 Fin6 refa905_inst.
Proof. unfold Equation1685, magma_op, refa905_inst, refa905_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa905_not1691 : ~ @Equation1691 Fin6 refa905_inst.
Proof. unfold Equation1691. intro H. specialize (H F6_1 F6_3). unfold magma_op, refa905_inst, refa905_op in H. discriminate H. Qed.

Lemma refa905_not3253 : ~ @Equation3253 Fin6 refa905_inst.
Proof. unfold Equation3253. intro H. specialize (H F6_0). unfold magma_op, refa905_inst, refa905_op in H. discriminate H. Qed.

Lemma refa905_not4321 : ~ @Equation4321 Fin6 refa905_inst.
Proof. unfold Equation4321. intro H. specialize (H F6_0 F6_1). unfold magma_op, refa905_inst, refa905_op in H. discriminate H. Qed.

Lemma refa905_not4658 : ~ @Equation4658 Fin6 refa905_inst.
Proof. unfold Equation4658. intro H. specialize (H F6_1 F6_3). unfold magma_op, refa905_inst, refa905_op in H. discriminate H. Qed.

(** ---- refa906 (Fin5) ---- *)

Definition refa906_op (x y : Fin5) : Fin5 :=
  match x, y with
  | F5_0, F5_0 => F5_1 | F5_0, F5_1 => F5_2 | F5_0, F5_2 => F5_4 | F5_0, F5_3 => F5_0 | F5_0, F5_4 => F5_3
  | F5_1, F5_0 => F5_0 | F5_1, F5_1 => F5_3 | F5_1, F5_2 => F5_4 | F5_1, F5_3 => F5_1 | F5_1, F5_4 => F5_3
  | F5_2, F5_0 => F5_3 | F5_2, F5_1 => F5_2 | F5_2, F5_2 => F5_2 | F5_2, F5_3 => F5_0 | F5_2, F5_4 => F5_1
  | F5_3, F5_0 => F5_4 | F5_3, F5_1 => F5_1 | F5_3, F5_2 => F5_4 | F5_3, F5_3 => F5_3 | F5_3, F5_4 => F5_0
  | F5_4, F5_0 => F5_2 | F5_4, F5_1 => F5_0 | F5_4, F5_2 => F5_2 | F5_4, F5_3 => F5_2 | F5_4, F5_4 => F5_4
  end.

#[local] Instance refa906_inst : Magma Fin5 := {| magma_op := refa906_op |}.

Lemma refa906_sat1682 : @Equation1682 Fin5 refa906_inst.
Proof. unfold Equation1682, magma_op, refa906_inst, refa906_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa906_not411 : ~ @Equation411 Fin5 refa906_inst.
Proof. unfold Equation411. intro H. specialize (H F5_0). unfold magma_op, refa906_inst, refa906_op in H. discriminate H. Qed.

Lemma refa906_not614 : ~ @Equation614 Fin5 refa906_inst.
Proof. unfold Equation614. intro H. specialize (H F5_0). unfold magma_op, refa906_inst, refa906_op in H. discriminate H. Qed.

Lemma refa906_not1426 : ~ @Equation1426 Fin5 refa906_inst.
Proof. unfold Equation1426. intro H. specialize (H F5_0). unfold magma_op, refa906_inst, refa906_op in H. discriminate H. Qed.

Lemma refa906_not1832 : ~ @Equation1832 Fin5 refa906_inst.
Proof. unfold Equation1832. intro H. specialize (H F5_0). unfold magma_op, refa906_inst, refa906_op in H. discriminate H. Qed.

Lemma refa906_not2035 : ~ @Equation2035 Fin5 refa906_inst.
Proof. unfold Equation2035. intro H. specialize (H F5_0). unfold magma_op, refa906_inst, refa906_op in H. discriminate H. Qed.

Lemma refa906_not2847 : ~ @Equation2847 Fin5 refa906_inst.
Proof. unfold Equation2847. intro H. specialize (H F5_0). unfold magma_op, refa906_inst, refa906_op in H. discriminate H. Qed.

Lemma refa906_not3659 : ~ @Equation3659 Fin5 refa906_inst.
Proof. unfold Equation3659. intro H. specialize (H F5_0). unfold magma_op, refa906_inst, refa906_op in H. discriminate H. Qed.

Lemma refa906_not4380 : ~ @Equation4380 Fin5 refa906_inst.
Proof. unfold Equation4380. intro H. specialize (H F5_0). unfold magma_op, refa906_inst, refa906_op in H. discriminate H. Qed.

(** ---- refa907 (Fin8) ---- *)

Definition refa907_op (x y : Fin8) : Fin8 :=
  match x, y with
  | F8_0, F8_0 => F8_1 | F8_0, F8_1 => F8_5 | F8_0, F8_2 => F8_5 | F8_0, F8_3 => F8_1 | F8_0, F8_4 => F8_1 | F8_0, F8_5 => F8_1 | F8_0, F8_6 => F8_5 | F8_0, F8_7 => F8_5
  | F8_1, F8_0 => F8_2 | F8_1, F8_1 => F8_0 | F8_1, F8_2 => F8_0 | F8_1, F8_3 => F8_2 | F8_1, F8_4 => F8_2 | F8_1, F8_5 => F8_2 | F8_1, F8_6 => F8_0 | F8_1, F8_7 => F8_0
  | F8_2, F8_0 => F8_3 | F8_2, F8_1 => F8_1 | F8_2, F8_2 => F8_1 | F8_2, F8_3 => F8_3 | F8_2, F8_4 => F8_3 | F8_2, F8_5 => F8_3 | F8_2, F8_6 => F8_1 | F8_2, F8_7 => F8_1
  | F8_3, F8_0 => F8_4 | F8_3, F8_1 => F8_2 | F8_3, F8_2 => F8_2 | F8_3, F8_3 => F8_4 | F8_3, F8_4 => F8_4 | F8_3, F8_5 => F8_4 | F8_3, F8_6 => F8_2 | F8_3, F8_7 => F8_2
  | F8_4, F8_0 => F8_7 | F8_4, F8_1 => F8_3 | F8_4, F8_2 => F8_3 | F8_4, F8_3 => F8_7 | F8_4, F8_4 => F8_7 | F8_4, F8_5 => F8_7 | F8_4, F8_6 => F8_3 | F8_4, F8_7 => F8_3
  | F8_5, F8_0 => F8_0 | F8_5, F8_1 => F8_6 | F8_5, F8_2 => F8_6 | F8_5, F8_3 => F8_0 | F8_5, F8_4 => F8_0 | F8_5, F8_5 => F8_0 | F8_5, F8_6 => F8_6 | F8_5, F8_7 => F8_6
  | F8_6, F8_0 => F8_5 | F8_6, F8_1 => F8_7 | F8_6, F8_2 => F8_7 | F8_6, F8_3 => F8_5 | F8_6, F8_4 => F8_5 | F8_6, F8_5 => F8_5 | F8_6, F8_6 => F8_7 | F8_6, F8_7 => F8_7
  | F8_7, F8_0 => F8_6 | F8_7, F8_1 => F8_4 | F8_7, F8_2 => F8_4 | F8_7, F8_3 => F8_6 | F8_7, F8_4 => F8_6 | F8_7, F8_5 => F8_6 | F8_7, F8_6 => F8_4 | F8_7, F8_7 => F8_4
  end.

#[local] Instance refa907_inst : Magma Fin8 := {| magma_op := refa907_op |}.

Lemma refa907_sat2485 : @Equation2485 Fin8 refa907_inst.
Proof. unfold Equation2485, magma_op, refa907_inst, refa907_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa907_not3050 : ~ @Equation3050 Fin8 refa907_inst.
Proof. unfold Equation3050. intro H. specialize (H F8_0). unfold magma_op, refa907_inst, refa907_op in H. discriminate H. Qed.

Lemma refa907_not4585 : ~ @Equation4585 Fin8 refa907_inst.
Proof. unfold Equation4585. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa907_inst, refa907_op in H. discriminate H. Qed.

(** ---- refa908 (Fin8) ---- *)

Definition refa908_op (x y : Fin8) : Fin8 :=
  match x, y with
  | F8_0, F8_0 => F8_2 | F8_0, F8_1 => F8_4 | F8_0, F8_2 => F8_0 | F8_0, F8_3 => F8_2 | F8_0, F8_4 => F8_5 | F8_0, F8_5 => F8_0 | F8_0, F8_6 => F8_5 | F8_0, F8_7 => F8_4
  | F8_1, F8_0 => F8_0 | F8_1, F8_1 => F8_3 | F8_1, F8_2 => F8_0 | F8_1, F8_3 => F8_3 | F8_1, F8_4 => F8_0 | F8_1, F8_5 => F8_0 | F8_1, F8_6 => F8_3 | F8_1, F8_7 => F8_3
  | F8_2, F8_0 => F8_0 | F8_2, F8_1 => F8_3 | F8_2, F8_2 => F8_0 | F8_2, F8_3 => F8_3 | F8_2, F8_4 => F8_0 | F8_2, F8_5 => F8_0 | F8_2, F8_6 => F8_3 | F8_2, F8_7 => F8_3
  | F8_3, F8_0 => F8_1 | F8_3, F8_1 => F8_3 | F8_3, F8_2 => F8_6 | F8_3, F8_3 => F8_1 | F8_3, F8_4 => F8_7 | F8_3, F8_5 => F8_6 | F8_3, F8_6 => F8_7 | F8_3, F8_7 => F8_3
  | F8_4, F8_0 => F8_1 | F8_4, F8_1 => F8_3 | F8_4, F8_2 => F8_0 | F8_4, F8_3 => F8_1 | F8_4, F8_4 => F8_7 | F8_4, F8_5 => F8_0 | F8_4, F8_6 => F8_7 | F8_4, F8_7 => F8_3
  | F8_5, F8_0 => F8_4 | F8_5, F8_1 => F8_4 | F8_5, F8_2 => F8_6 | F8_5, F8_3 => F8_4 | F8_5, F8_4 => F8_6 | F8_5, F8_5 => F8_6 | F8_5, F8_6 => F8_6 | F8_5, F8_7 => F8_4
  | F8_6, F8_0 => F8_2 | F8_6, F8_1 => F8_4 | F8_6, F8_2 => F8_6 | F8_6, F8_3 => F8_2 | F8_6, F8_4 => F8_5 | F8_6, F8_5 => F8_6 | F8_6, F8_6 => F8_5 | F8_6, F8_7 => F8_4
  | F8_7, F8_0 => F8_4 | F8_7, F8_1 => F8_4 | F8_7, F8_2 => F8_6 | F8_7, F8_3 => F8_4 | F8_7, F8_4 => F8_6 | F8_7, F8_5 => F8_6 | F8_7, F8_6 => F8_6 | F8_7, F8_7 => F8_4
  end.

#[local] Instance refa908_inst : Magma Fin8 := {| magma_op := refa908_op |}.

Lemma refa908_sat2162 : @Equation2162 Fin8 refa908_inst.
Proof. unfold Equation2162, magma_op, refa908_inst, refa908_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa908_not3462 : ~ @Equation3462 Fin8 refa908_inst.
Proof. unfold Equation3462. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa908_inst, refa908_op in H. discriminate H. Qed.

Lemma refa908_not3521 : ~ @Equation3521 Fin8 refa908_inst.
Proof. unfold Equation3521. intro H. specialize (H F8_1 F8_0). unfold magma_op, refa908_inst, refa908_op in H. discriminate H. Qed.

Lemma refa908_not3880 : ~ @Equation3880 Fin8 refa908_inst.
Proof. unfold Equation3880. intro H. specialize (H F8_0 F8_5). unfold magma_op, refa908_inst, refa908_op in H. discriminate H. Qed.

Lemma refa908_not3952 : ~ @Equation3952 Fin8 refa908_inst.
Proof. unfold Equation3952. intro H. specialize (H F8_0 F8_5). unfold magma_op, refa908_inst, refa908_op in H. discriminate H. Qed.

Lemma refa908_not4314 : ~ @Equation4314 Fin8 refa908_inst.
Proof. unfold Equation4314. intro H. specialize (H F8_1 F8_2). unfold magma_op, refa908_inst, refa908_op in H. discriminate H. Qed.

Lemma refa908_not4606 : ~ @Equation4606 Fin8 refa908_inst.
Proof. unfold Equation4606. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa908_inst, refa908_op in H. discriminate H. Qed.

(** ---- refa909 (Fin8) ---- *)

Definition refa909_op (x y : Fin8) : Fin8 :=
  match x, y with
  | F8_0, F8_0 => F8_2 | F8_0, F8_1 => F8_2 | F8_0, F8_2 => F8_6 | F8_0, F8_3 => F8_2 | F8_0, F8_4 => F8_2 | F8_0, F8_5 => F8_6 | F8_0, F8_6 => F8_6 | F8_0, F8_7 => F8_6
  | F8_1, F8_0 => F8_3 | F8_1, F8_1 => F8_2 | F8_1, F8_2 => F8_3 | F8_1, F8_3 => F8_3 | F8_1, F8_4 => F8_2 | F8_1, F8_5 => F8_2 | F8_1, F8_6 => F8_3 | F8_1, F8_7 => F8_2
  | F8_2, F8_0 => F8_3 | F8_2, F8_1 => F8_7 | F8_2, F8_2 => F8_4 | F8_2, F8_3 => F8_1 | F8_2, F8_4 => F8_2 | F8_2, F8_5 => F8_6 | F8_2, F8_6 => F8_0 | F8_2, F8_7 => F8_5
  | F8_3, F8_0 => F8_3 | F8_3, F8_1 => F8_2 | F8_3, F8_2 => F8_0 | F8_3, F8_3 => F8_3 | F8_3, F8_4 => F8_2 | F8_3, F8_5 => F8_6 | F8_3, F8_6 => F8_0 | F8_3, F8_7 => F8_6
  | F8_4, F8_0 => F8_2 | F8_4, F8_1 => F8_2 | F8_4, F8_2 => F8_2 | F8_4, F8_3 => F8_2 | F8_4, F8_4 => F8_2 | F8_4, F8_5 => F8_2 | F8_4, F8_6 => F8_2 | F8_4, F8_7 => F8_2
  | F8_5, F8_0 => F8_2 | F8_5, F8_1 => F8_7 | F8_5, F8_2 => F8_7 | F8_5, F8_3 => F8_7 | F8_5, F8_4 => F8_2 | F8_5, F8_5 => F8_2 | F8_5, F8_6 => F8_2 | F8_5, F8_7 => F8_7
  | F8_6, F8_0 => F8_2 | F8_6, F8_1 => F8_7 | F8_6, F8_2 => F8_5 | F8_6, F8_3 => F8_7 | F8_6, F8_4 => F8_2 | F8_6, F8_5 => F8_6 | F8_6, F8_6 => F8_6 | F8_6, F8_7 => F8_5
  | F8_7, F8_0 => F8_3 | F8_7, F8_1 => F8_7 | F8_7, F8_2 => F8_1 | F8_7, F8_3 => F8_1 | F8_7, F8_4 => F8_2 | F8_7, F8_5 => F8_2 | F8_7, F8_6 => F8_3 | F8_7, F8_7 => F8_7
  end.

#[local] Instance refa909_inst : Magma Fin8 := {| magma_op := refa909_op |}.

Lemma refa909_sat2163 : @Equation2163 Fin8 refa909_inst.
Proof. unfold Equation2163, magma_op, refa909_inst, refa909_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa909_not151 : ~ @Equation151 Fin8 refa909_inst.
Proof. unfold Equation151. intro H. specialize (H F8_0). unfold magma_op, refa909_inst, refa909_op in H. discriminate H. Qed.

Lemma refa909_not1428 : ~ @Equation1428 Fin8 refa909_inst.
Proof. unfold Equation1428. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa909_inst, refa909_op in H. discriminate H. Qed.

Lemma refa909_not1429 : ~ @Equation1429 Fin8 refa909_inst.
Proof. unfold Equation1429. intro H. specialize (H F8_0 F8_2). unfold magma_op, refa909_inst, refa909_op in H. discriminate H. Qed.

Lemma refa909_not1479 : ~ @Equation1479 Fin8 refa909_inst.
Proof. unfold Equation1479. intro H. specialize (H F8_2 F8_0). unfold magma_op, refa909_inst, refa909_op in H. discriminate H. Qed.

Lemma refa909_not2050 : ~ @Equation2050 Fin8 refa909_inst.
Proof. unfold Equation2050. intro H. specialize (H F8_0 F8_2). unfold magma_op, refa909_inst, refa909_op in H. discriminate H. Qed.

Lemma refa909_not2088 : ~ @Equation2088 Fin8 refa909_inst.
Proof. unfold Equation2088. intro H. specialize (H F8_2 F8_0). unfold magma_op, refa909_inst, refa909_op in H. discriminate H. Qed.

Lemma refa909_not2124 : ~ @Equation2124 Fin8 refa909_inst.
Proof. unfold Equation2124. intro H. specialize (H F8_0 F8_2). unfold magma_op, refa909_inst, refa909_op in H. discriminate H. Qed.

Lemma refa909_not3457 : ~ @Equation3457 Fin8 refa909_inst.
Proof. unfold Equation3457. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa909_inst, refa909_op in H. discriminate H. Qed.

Lemma refa909_not3462 : ~ @Equation3462 Fin8 refa909_inst.
Proof. unfold Equation3462. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa909_inst, refa909_op in H. discriminate H. Qed.

Lemma refa909_not3521 : ~ @Equation3521 Fin8 refa909_inst.
Proof. unfold Equation3521. intro H. specialize (H F8_0 F8_5). unfold magma_op, refa909_inst, refa909_op in H. discriminate H. Qed.

Lemma refa909_not3877 : ~ @Equation3877 Fin8 refa909_inst.
Proof. unfold Equation3877. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa909_inst, refa909_op in H. discriminate H. Qed.

Lemma refa909_not3880 : ~ @Equation3880 Fin8 refa909_inst.
Proof. unfold Equation3880. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa909_inst, refa909_op in H. discriminate H. Qed.

Lemma refa909_not3952 : ~ @Equation3952 Fin8 refa909_inst.
Proof. unfold Equation3952. intro H. specialize (H F8_0 F8_2). unfold magma_op, refa909_inst, refa909_op in H. discriminate H. Qed.

Lemma refa909_not4314 : ~ @Equation4314 Fin8 refa909_inst.
Proof. unfold Equation4314. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa909_inst, refa909_op in H. discriminate H. Qed.

Lemma refa909_not4606 : ~ @Equation4606 Fin8 refa909_inst.
Proof. unfold Equation4606. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa909_inst, refa909_op in H. discriminate H. Qed.
