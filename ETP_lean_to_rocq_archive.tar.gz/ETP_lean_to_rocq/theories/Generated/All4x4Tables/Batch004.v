(** * All4x4 counterexamples — batch 4
    Auto-generated from Lean4 All4x4 files. *)

From Stdlib Require Import Utf8.

From ETP Require Import Magma.
From ETP Require Import FinMagma.
From ETP.Equations Require Import All.

Open Scope magma_scope.

(** ---- refa233 (Fin3) ---- *)

Definition refa233_op (x y : Fin3) : Fin3 :=
  match x, y with
  | F3_0, F3_0 => F3_1 | F3_0, F3_1 => F3_0 | F3_0, F3_2 => F3_2
  | F3_1, F3_0 => F3_2 | F3_1, F3_1 => F3_0 | F3_1, F3_2 => F3_1
  | F3_2, F3_0 => F3_1 | F3_2, F3_1 => F3_2 | F3_2, F3_2 => F3_0
  end.

#[local] Instance refa233_inst : Magma Fin3 := {| magma_op := refa233_op |}.

Lemma refa233_sat1122 : @Equation1122 Fin3 refa233_inst.
Proof. unfold Equation1122, magma_op, refa233_inst, refa233_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa233_not1629 : ~ @Equation1629 Fin3 refa233_inst.
Proof. unfold Equation1629. intro H. specialize (H F3_0). unfold magma_op, refa233_inst, refa233_op in H. discriminate H. Qed.

(** ---- refa234 (Fin3) ---- *)

Definition refa234_op (x y : Fin3) : Fin3 :=
  match x, y with
  | F3_0, F3_0 => F3_0 | F3_0, F3_1 => F3_0 | F3_0, F3_2 => F3_1
  | F3_1, F3_0 => F3_0 | F3_1, F3_1 => F3_2 | F3_1, F3_2 => F3_1
  | F3_2, F3_0 => F3_0 | F3_2, F3_1 => F3_0 | F3_2, F3_2 => F3_1
  end.

#[local] Instance refa234_inst : Magma Fin3 := {| magma_op := refa234_op |}.

Lemma refa234_sat166 : @Equation166 Fin3 refa234_inst.
Proof. unfold Equation166, magma_op, refa234_inst, refa234_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa234_sat3993 : @Equation3993 Fin3 refa234_inst.
Proof. unfold Equation3993, magma_op, refa234_inst, refa234_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa234_not1832 : ~ @Equation1832 Fin3 refa234_inst.
Proof. unfold Equation1832. intro H. specialize (H F3_2). unfold magma_op, refa234_inst, refa234_op in H. discriminate H. Qed.

Lemma refa234_not2090 : ~ @Equation2090 Fin3 refa234_inst.
Proof. unfold Equation2090. intro H. specialize (H F3_1 F3_0). unfold magma_op, refa234_inst, refa234_op in H. discriminate H. Qed.

Lemma refa234_not2127 : ~ @Equation2127 Fin3 refa234_inst.
Proof. unfold Equation2127. intro H. specialize (H F3_1 F3_0). unfold magma_op, refa234_inst, refa234_op in H. discriminate H. Qed.

Lemma refa234_not2134 : ~ @Equation2134 Fin3 refa234_inst.
Proof. unfold Equation2134. intro H. specialize (H F3_2 F3_0). unfold magma_op, refa234_inst, refa234_op in H. discriminate H. Qed.

Lemma refa234_not3253 : ~ @Equation3253 Fin3 refa234_inst.
Proof. unfold Equation3253. intro H. specialize (H F3_2). unfold magma_op, refa234_inst, refa234_op in H. discriminate H. Qed.

Lemma refa234_not3456 : ~ @Equation3456 Fin3 refa234_inst.
Proof. unfold Equation3456. intro H. specialize (H F3_1). unfold magma_op, refa234_inst, refa234_op in H. discriminate H. Qed.

Lemma refa234_not3864 : ~ @Equation3864 Fin3 refa234_inst.
Proof. unfold Equation3864. intro H. specialize (H F3_1 F3_0). unfold magma_op, refa234_inst, refa234_op in H. discriminate H. Qed.

Lemma refa234_not3870 : ~ @Equation3870 Fin3 refa234_inst.
Proof. unfold Equation3870. intro H. specialize (H F3_1 F3_0). unfold magma_op, refa234_inst, refa234_op in H. discriminate H. Qed.

Lemma refa234_not3880 : ~ @Equation3880 Fin3 refa234_inst.
Proof. unfold Equation3880. intro H. specialize (H F3_1 F3_0). unfold magma_op, refa234_inst, refa234_op in H. discriminate H. Qed.

Lemma refa234_not3887 : ~ @Equation3887 Fin3 refa234_inst.
Proof. unfold Equation3887. intro H. specialize (H F3_1 F3_0). unfold magma_op, refa234_inst, refa234_op in H. discriminate H. Qed.

Lemma refa234_not3890 : ~ @Equation3890 Fin3 refa234_inst.
Proof. unfold Equation3890. intro H. specialize (H F3_1 F3_0). unfold magma_op, refa234_inst, refa234_op in H. discriminate H. Qed.

Lemma refa234_not4065 : ~ @Equation4065 Fin3 refa234_inst.
Proof. unfold Equation4065. intro H. specialize (H F3_1). unfold magma_op, refa234_inst, refa234_op in H. discriminate H. Qed.

(** ---- refa235 (Fin3) ---- *)

Definition refa235_op (x y : Fin3) : Fin3 :=
  match x, y with
  | F3_0, F3_0 => F3_0 | F3_0, F3_1 => F3_0 | F3_0, F3_2 => F3_0
  | F3_1, F3_0 => F3_1 | F3_1, F3_1 => F3_2 | F3_1, F3_2 => F3_0
  | F3_2, F3_0 => F3_1 | F3_2, F3_1 => F3_2 | F3_2, F3_2 => F3_2
  end.

#[local] Instance refa235_inst : Magma Fin3 := {| magma_op := refa235_op |}.

Lemma refa235_sat1021 : @Equation1021 Fin3 refa235_inst.
Proof. unfold Equation1021, magma_op, refa235_inst, refa235_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa235_not99 : ~ @Equation99 Fin3 refa235_inst.
Proof. unfold Equation99. intro H. specialize (H F3_1). unfold magma_op, refa235_inst, refa235_op in H. discriminate H. Qed.

Lemma refa235_not151 : ~ @Equation151 Fin3 refa235_inst.
Proof. unfold Equation151. intro H. specialize (H F3_1). unfold magma_op, refa235_inst, refa235_op in H. discriminate H. Qed.

Lemma refa235_not1223 : ~ @Equation1223 Fin3 refa235_inst.
Proof. unfold Equation1223. intro H. specialize (H F3_1). unfold magma_op, refa235_inst, refa235_op in H. discriminate H. Qed.

Lemma refa235_not4380 : ~ @Equation4380 Fin3 refa235_inst.
Proof. unfold Equation4380. intro H. specialize (H F3_1). unfold magma_op, refa235_inst, refa235_op in H. discriminate H. Qed.

(** ---- refa236 (Fin3) ---- *)

Definition refa236_op (x y : Fin3) : Fin3 :=
  match x, y with
  | F3_0, F3_0 => F3_0 | F3_0, F3_1 => F3_0 | F3_0, F3_2 => F3_0
  | F3_1, F3_0 => F3_1 | F3_1, F3_1 => F3_0 | F3_1, F3_2 => F3_1
  | F3_2, F3_0 => F3_2 | F3_2, F3_1 => F3_1 | F3_2, F3_2 => F3_0
  end.

#[local] Instance refa236_inst : Magma Fin3 := {| magma_op := refa236_op |}.

Lemma refa236_sat368 : @Equation368 Fin3 refa236_inst.
Proof. unfold Equation368, magma_op, refa236_inst, refa236_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa236_sat1257 : @Equation1257 Fin3 refa236_inst.
Proof. unfold Equation1257, magma_op, refa236_inst, refa236_op. intros x y z w. destruct x, y, z, w; reflexivity. Qed.

Lemma refa236_not1025 : ~ @Equation1025 Fin3 refa236_inst.
Proof. unfold Equation1025. intro H. specialize (H F3_2 F3_1). unfold magma_op, refa236_inst, refa236_op in H. discriminate H. Qed.

Lemma refa236_not1039 : ~ @Equation1039 Fin3 refa236_inst.
Proof. unfold Equation1039. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa236_inst, refa236_op in H. discriminate H. Qed.

Lemma refa236_not1228 : ~ @Equation1228 Fin3 refa236_inst.
Proof. unfold Equation1228. intro H. specialize (H F3_2 F3_1). unfold magma_op, refa236_inst, refa236_op in H. discriminate H. Qed.

Lemma refa236_not1242 : ~ @Equation1242 Fin3 refa236_inst.
Proof. unfold Equation1242. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa236_inst, refa236_op in H. discriminate H. Qed.

Lemma refa236_not4070 : ~ @Equation4070 Fin3 refa236_inst.
Proof. unfold Equation4070. intro H. specialize (H F3_2 F3_1). unfold magma_op, refa236_inst, refa236_op in H. discriminate H. Qed.

Lemma refa236_not4084 : ~ @Equation4084 Fin3 refa236_inst.
Proof. unfold Equation4084. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa236_inst, refa236_op in H. discriminate H. Qed.

(** ---- refa237 (Fin3) ---- *)

Definition refa237_op (x y : Fin3) : Fin3 :=
  match x, y with
  | F3_0, F3_0 => F3_0 | F3_0, F3_1 => F3_0 | F3_0, F3_2 => F3_2
  | F3_1, F3_0 => F3_2 | F3_1, F3_1 => F3_2 | F3_1, F3_2 => F3_0
  | F3_2, F3_0 => F3_0 | F3_2, F3_1 => F3_1 | F3_2, F3_2 => F3_0
  end.

#[local] Instance refa237_inst : Magma Fin3 := {| magma_op := refa237_op |}.

Lemma refa237_sat2266 : @Equation2266 Fin3 refa237_inst.
Proof. unfold Equation2266, magma_op, refa237_inst, refa237_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa237_sat2443 : @Equation2443 Fin3 refa237_inst.
Proof. unfold Equation2443, magma_op, refa237_inst, refa237_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa237_sat2446 : @Equation2446 Fin3 refa237_inst.
Proof. unfold Equation2446, magma_op, refa237_inst, refa237_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa237_not203 : ~ @Equation203 Fin3 refa237_inst.
Proof. unfold Equation203. intro H. specialize (H F3_1). unfold magma_op, refa237_inst, refa237_op in H. discriminate H. Qed.

Lemma refa237_not307 : ~ @Equation307 Fin3 refa237_inst.
Proof. unfold Equation307. intro H. specialize (H F3_1). unfold magma_op, refa237_inst, refa237_op in H. discriminate H. Qed.

Lemma refa237_not1631 : ~ @Equation1631 Fin3 refa237_inst.
Proof. unfold Equation1631. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa237_inst, refa237_op in H. discriminate H. Qed.

Lemma refa237_not2240 : ~ @Equation2240 Fin3 refa237_inst.
Proof. unfold Equation2240. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa237_inst, refa237_op in H. discriminate H. Qed.

Lemma refa237_not2246 : ~ @Equation2246 Fin3 refa237_inst.
Proof. unfold Equation2246. intro H. specialize (H F3_1 F3_0). unfold magma_op, refa237_inst, refa237_op in H. discriminate H. Qed.

Lemma refa237_not2256 : ~ @Equation2256 Fin3 refa237_inst.
Proof. unfold Equation2256. intro H. specialize (H F3_1 F3_0). unfold magma_op, refa237_inst, refa237_op in H. discriminate H. Qed.

Lemma refa237_not2449 : ~ @Equation2449 Fin3 refa237_inst.
Proof. unfold Equation2449. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa237_inst, refa237_op in H. discriminate H. Qed.

Lemma refa237_not2469 : ~ @Equation2469 Fin3 refa237_inst.
Proof. unfold Equation2469. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa237_inst, refa237_op in H. discriminate H. Qed.

Lemma refa237_not2644 : ~ @Equation2644 Fin3 refa237_inst.
Proof. unfold Equation2644. intro H. specialize (H F3_1). unfold magma_op, refa237_inst, refa237_op in H. discriminate H. Qed.

Lemma refa237_not3519 : ~ @Equation3519 Fin3 refa237_inst.
Proof. unfold Equation3519. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa237_inst, refa237_op in H. discriminate H. Qed.

Lemma refa237_not3659 : ~ @Equation3659 Fin3 refa237_inst.
Proof. unfold Equation3659. intro H. specialize (H F3_1). unfold magma_op, refa237_inst, refa237_op in H. discriminate H. Qed.

Lemma refa237_not4128 : ~ @Equation4128 Fin3 refa237_inst.
Proof. unfold Equation4128. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa237_inst, refa237_op in H. discriminate H. Qed.

(** ---- refa238 (Fin3) ---- *)

Definition refa238_op (x y : Fin3) : Fin3 :=
  match x, y with
  | F3_0, F3_0 => F3_0 | F3_0, F3_1 => F3_0 | F3_0, F3_2 => F3_0
  | F3_1, F3_0 => F3_0 | F3_1, F3_1 => F3_0 | F3_1, F3_2 => F3_0
  | F3_2, F3_0 => F3_1 | F3_2, F3_1 => F3_1 | F3_2, F3_2 => F3_0
  end.

#[local] Instance refa238_inst : Magma Fin3 := {| magma_op := refa238_op |}.

Lemma refa238_sat366 : @Equation366 Fin3 refa238_inst.
Proof. unfold Equation366, magma_op, refa238_inst, refa238_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa238_sat4271 : @Equation4271 Fin3 refa238_inst.
Proof. unfold Equation4271, magma_op, refa238_inst, refa238_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa238_not3253 : ~ @Equation3253 Fin3 refa238_inst.
Proof. unfold Equation3253. intro H. specialize (H F3_2). unfold magma_op, refa238_inst, refa238_op in H. discriminate H. Qed.

Lemma refa238_not3456 : ~ @Equation3456 Fin3 refa238_inst.
Proof. unfold Equation3456. intro H. specialize (H F3_2). unfold magma_op, refa238_inst, refa238_op in H. discriminate H. Qed.

Lemma refa238_not3712 : ~ @Equation3712 Fin3 refa238_inst.
Proof. unfold Equation3712. intro H. specialize (H F3_2 F3_0). unfold magma_op, refa238_inst, refa238_op in H. discriminate H. Qed.

Lemma refa238_not3714 : ~ @Equation3714 Fin3 refa238_inst.
Proof. unfold Equation3714. intro H. specialize (H F3_2 F3_0). unfold magma_op, refa238_inst, refa238_op in H. discriminate H. Qed.

Lemma refa238_not3721 : ~ @Equation3721 Fin3 refa238_inst.
Proof. unfold Equation3721. intro H. specialize (H F3_2 F3_0). unfold magma_op, refa238_inst, refa238_op in H. discriminate H. Qed.

Lemma refa238_not3725 : ~ @Equation3725 Fin3 refa238_inst.
Proof. unfold Equation3725. intro H. specialize (H F3_2 F3_0). unfold magma_op, refa238_inst, refa238_op in H. discriminate H. Qed.

Lemma refa238_not3748 : ~ @Equation3748 Fin3 refa238_inst.
Proof. unfold Equation3748. intro H. specialize (H F3_2 F3_0). unfold magma_op, refa238_inst, refa238_op in H. discriminate H. Qed.

Lemma refa238_not3752 : ~ @Equation3752 Fin3 refa238_inst.
Proof. unfold Equation3752. intro H. specialize (H F3_2 F3_0). unfold magma_op, refa238_inst, refa238_op in H. discriminate H. Qed.

Lemma refa238_not3759 : ~ @Equation3759 Fin3 refa238_inst.
Proof. unfold Equation3759. intro H. specialize (H F3_2 F3_0). unfold magma_op, refa238_inst, refa238_op in H. discriminate H. Qed.

Lemma refa238_not3761 : ~ @Equation3761 Fin3 refa238_inst.
Proof. unfold Equation3761. intro H. specialize (H F3_2 F3_0). unfold magma_op, refa238_inst, refa238_op in H. discriminate H. Qed.

Lemma refa238_not3915 : ~ @Equation3915 Fin3 refa238_inst.
Proof. unfold Equation3915. intro H. specialize (H F3_2 F3_0). unfold magma_op, refa238_inst, refa238_op in H. discriminate H. Qed.

Lemma refa238_not3928 : ~ @Equation3928 Fin3 refa238_inst.
Proof. unfold Equation3928. intro H. specialize (H F3_2 F3_0). unfold magma_op, refa238_inst, refa238_op in H. discriminate H. Qed.

Lemma refa238_not4131 : ~ @Equation4131 Fin3 refa238_inst.
Proof. unfold Equation4131. intro H. specialize (H F3_2 F3_0). unfold magma_op, refa238_inst, refa238_op in H. discriminate H. Qed.

Lemma refa238_not4272 : ~ @Equation4272 Fin3 refa238_inst.
Proof. unfold Equation4272. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa238_inst, refa238_op in H. discriminate H. Qed.

Lemma refa238_not4273 : ~ @Equation4273 Fin3 refa238_inst.
Proof. unfold Equation4273. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa238_inst, refa238_op in H. discriminate H. Qed.

Lemma refa238_not4275 : ~ @Equation4275 Fin3 refa238_inst.
Proof. unfold Equation4275. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa238_inst, refa238_op in H. discriminate H. Qed.

Lemma refa238_not4276 : ~ @Equation4276 Fin3 refa238_inst.
Proof. unfold Equation4276. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa238_inst, refa238_op in H. discriminate H. Qed.

Lemma refa238_not4290 : ~ @Equation4290 Fin3 refa238_inst.
Proof. unfold Equation4290. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa238_inst, refa238_op in H. discriminate H. Qed.

Lemma refa238_not4291 : ~ @Equation4291 Fin3 refa238_inst.
Proof. unfold Equation4291. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa238_inst, refa238_op in H. discriminate H. Qed.

Lemma refa238_not4293 : ~ @Equation4293 Fin3 refa238_inst.
Proof. unfold Equation4293. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa238_inst, refa238_op in H. discriminate H. Qed.

Lemma refa238_not4320 : ~ @Equation4320 Fin3 refa238_inst.
Proof. unfold Equation4320. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa238_inst, refa238_op in H. discriminate H. Qed.

Lemma refa238_not4321 : ~ @Equation4321 Fin3 refa238_inst.
Proof. unfold Equation4321. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa238_inst, refa238_op in H. discriminate H. Qed.

Lemma refa238_not4343 : ~ @Equation4343 Fin3 refa238_inst.
Proof. unfold Equation4343. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa238_inst, refa238_op in H. discriminate H. Qed.

Lemma refa238_not4380 : ~ @Equation4380 Fin3 refa238_inst.
Proof. unfold Equation4380. intro H. specialize (H F3_2). unfold magma_op, refa238_inst, refa238_op in H. discriminate H. Qed.

(** ---- refa239 (Fin3) ---- *)

Definition refa239_op (x y : Fin3) : Fin3 :=
  match x, y with
  | F3_0, F3_0 => F3_0 | F3_0, F3_1 => F3_0 | F3_0, F3_2 => F3_0
  | F3_1, F3_0 => F3_1 | F3_1, F3_1 => F3_2 | F3_1, F3_2 => F3_2
  | F3_2, F3_0 => F3_1 | F3_2, F3_1 => F3_1 | F3_2, F3_2 => F3_2
  end.

#[local] Instance refa239_inst : Magma Fin3 := {| magma_op := refa239_op |}.

Lemma refa239_sat2452 : @Equation2452 Fin3 refa239_inst.
Proof. unfold Equation2452, magma_op, refa239_inst, refa239_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa239_not1631 : ~ @Equation1631 Fin3 refa239_inst.
Proof. unfold Equation1631. intro H. specialize (H F3_1 F3_0). unfold magma_op, refa239_inst, refa239_op in H. discriminate H. Qed.

Lemma refa239_not2646 : ~ @Equation2646 Fin3 refa239_inst.
Proof. unfold Equation2646. intro H. specialize (H F3_1 F3_0). unfold magma_op, refa239_inst, refa239_op in H. discriminate H. Qed.

Lemma refa239_not3459 : ~ @Equation3459 Fin3 refa239_inst.
Proof. unfold Equation3459. intro H. specialize (H F3_2 F3_0). unfold magma_op, refa239_inst, refa239_op in H. discriminate H. Qed.

Lemma refa239_not3525 : ~ @Equation3525 Fin3 refa239_inst.
Proof. unfold Equation3525. intro H. specialize (H F3_2 F3_1 F3_0). unfold magma_op, refa239_inst, refa239_op in H. discriminate H. Qed.

(** ---- refa24 (Fin8) ---- *)

Definition refa24_op (x y : Fin8) : Fin8 :=
  match x, y with
  | F8_0, F8_0 => F8_1 | F8_0, F8_1 => F8_2 | F8_0, F8_2 => F8_4 | F8_0, F8_3 => F8_0 | F8_0, F8_4 => F8_5 | F8_0, F8_5 => F8_6 | F8_0, F8_6 => F8_3 | F8_0, F8_7 => F8_7
  | F8_1, F8_0 => F8_7 | F8_1, F8_1 => F8_3 | F8_1, F8_2 => F8_5 | F8_1, F8_3 => F8_6 | F8_1, F8_4 => F8_4 | F8_1, F8_5 => F8_0 | F8_1, F8_6 => F8_2 | F8_1, F8_7 => F8_1
  | F8_2, F8_0 => F8_2 | F8_2, F8_1 => F8_1 | F8_2, F8_2 => F8_6 | F8_2, F8_3 => F8_5 | F8_2, F8_4 => F8_0 | F8_2, F8_5 => F8_4 | F8_2, F8_6 => F8_7 | F8_2, F8_7 => F8_3
  | F8_3, F8_0 => F8_6 | F8_3, F8_1 => F8_4 | F8_3, F8_2 => F8_2 | F8_3, F8_3 => F8_7 | F8_3, F8_4 => F8_3 | F8_3, F8_5 => F8_1 | F8_3, F8_6 => F8_5 | F8_3, F8_7 => F8_0
  | F8_4, F8_0 => F8_0 | F8_4, F8_1 => F8_5 | F8_4, F8_2 => F8_3 | F8_4, F8_3 => F8_1 | F8_4, F8_4 => F8_2 | F8_4, F8_5 => F8_7 | F8_4, F8_6 => F8_4 | F8_4, F8_7 => F8_6
  | F8_5, F8_0 => F8_3 | F8_5, F8_1 => F8_7 | F8_5, F8_2 => F8_0 | F8_5, F8_3 => F8_4 | F8_5, F8_4 => F8_6 | F8_5, F8_5 => F8_5 | F8_5, F8_6 => F8_1 | F8_5, F8_7 => F8_2
  | F8_6, F8_0 => F8_4 | F8_6, F8_1 => F8_6 | F8_6, F8_2 => F8_1 | F8_6, F8_3 => F8_3 | F8_6, F8_4 => F8_7 | F8_6, F8_5 => F8_2 | F8_6, F8_6 => F8_0 | F8_6, F8_7 => F8_5
  | F8_7, F8_0 => F8_5 | F8_7, F8_1 => F8_0 | F8_7, F8_2 => F8_7 | F8_7, F8_3 => F8_2 | F8_7, F8_4 => F8_1 | F8_7, F8_5 => F8_3 | F8_7, F8_6 => F8_6 | F8_7, F8_7 => F8_4
  end.

#[local] Instance refa24_inst : Magma Fin8 := {| magma_op := refa24_op |}.

Lemma refa24_sat898 : @Equation898 Fin8 refa24_inst.
Proof. unfold Equation898, magma_op, refa24_inst, refa24_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa24_not411 : ~ @Equation411 Fin8 refa24_inst.
Proof. unfold Equation411. intro H. specialize (H F8_0). unfold magma_op, refa24_inst, refa24_op in H. discriminate H. Qed.

Lemma refa24_not614 : ~ @Equation614 Fin8 refa24_inst.
Proof. unfold Equation614. intro H. specialize (H F8_0). unfold magma_op, refa24_inst, refa24_op in H. discriminate H. Qed.

Lemma refa24_not833 : ~ @Equation833 Fin8 refa24_inst.
Proof. unfold Equation833. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa24_inst, refa24_op in H. discriminate H. Qed.

Lemma refa24_not835 : ~ @Equation835 Fin8 refa24_inst.
Proof. unfold Equation835. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa24_inst, refa24_op in H. discriminate H. Qed.

Lemma refa24_not842 : ~ @Equation842 Fin8 refa24_inst.
Proof. unfold Equation842. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa24_inst, refa24_op in H. discriminate H. Qed.

Lemma refa24_not846 : ~ @Equation846 Fin8 refa24_inst.
Proof. unfold Equation846. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa24_inst, refa24_op in H. discriminate H. Qed.

Lemma refa24_not872 : ~ @Equation872 Fin8 refa24_inst.
Proof. unfold Equation872. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa24_inst, refa24_op in H. discriminate H. Qed.

Lemma refa24_not879 : ~ @Equation879 Fin8 refa24_inst.
Proof. unfold Equation879. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa24_inst, refa24_op in H. discriminate H. Qed.

Lemma refa24_not906 : ~ @Equation906 Fin8 refa24_inst.
Proof. unfold Equation906. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa24_inst, refa24_op in H. discriminate H. Qed.

Lemma refa24_not917 : ~ @Equation917 Fin8 refa24_inst.
Proof. unfold Equation917. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa24_inst, refa24_op in H. discriminate H. Qed.

Lemma refa24_not1020 : ~ @Equation1020 Fin8 refa24_inst.
Proof. unfold Equation1020. intro H. specialize (H F8_0). unfold magma_op, refa24_inst, refa24_op in H. discriminate H. Qed.

Lemma refa24_not1223 : ~ @Equation1223 Fin8 refa24_inst.
Proof. unfold Equation1223. intro H. specialize (H F8_0). unfold magma_op, refa24_inst, refa24_op in H. discriminate H. Qed.

Lemma refa24_not1426 : ~ @Equation1426 Fin8 refa24_inst.
Proof. unfold Equation1426. intro H. specialize (H F8_0). unfold magma_op, refa24_inst, refa24_op in H. discriminate H. Qed.

Lemma refa24_not1629 : ~ @Equation1629 Fin8 refa24_inst.
Proof. unfold Equation1629. intro H. specialize (H F8_0). unfold magma_op, refa24_inst, refa24_op in H. discriminate H. Qed.

Lemma refa24_not1832 : ~ @Equation1832 Fin8 refa24_inst.
Proof. unfold Equation1832. intro H. specialize (H F8_0). unfold magma_op, refa24_inst, refa24_op in H. discriminate H. Qed.

Lemma refa24_not2038 : ~ @Equation2038 Fin8 refa24_inst.
Proof. unfold Equation2038. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa24_inst, refa24_op in H. discriminate H. Qed.

Lemma refa24_not2041 : ~ @Equation2041 Fin8 refa24_inst.
Proof. unfold Equation2041. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa24_inst, refa24_op in H. discriminate H. Qed.

Lemma refa24_not2060 : ~ @Equation2060 Fin8 refa24_inst.
Proof. unfold Equation2060. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa24_inst, refa24_op in H. discriminate H. Qed.

Lemma refa24_not2124 : ~ @Equation2124 Fin8 refa24_inst.
Proof. unfold Equation2124. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa24_inst, refa24_op in H. discriminate H. Qed.

Lemma refa24_not2128 : ~ @Equation2128 Fin8 refa24_inst.
Proof. unfold Equation2128. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa24_inst, refa24_op in H. discriminate H. Qed.

Lemma refa24_not2246 : ~ @Equation2246 Fin8 refa24_inst.
Proof. unfold Equation2246. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa24_inst, refa24_op in H. discriminate H. Qed.

Lemma refa24_not2254 : ~ @Equation2254 Fin8 refa24_inst.
Proof. unfold Equation2254. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa24_inst, refa24_op in H. discriminate H. Qed.

Lemma refa24_not2256 : ~ @Equation2256 Fin8 refa24_inst.
Proof. unfold Equation2256. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa24_inst, refa24_op in H. discriminate H. Qed.

Lemma refa24_not2291 : ~ @Equation2291 Fin8 refa24_inst.
Proof. unfold Equation2291. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa24_inst, refa24_op in H. discriminate H. Qed.

Lemma refa24_not2300 : ~ @Equation2300 Fin8 refa24_inst.
Proof. unfold Equation2300. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa24_inst, refa24_op in H. discriminate H. Qed.

Lemma refa24_not2340 : ~ @Equation2340 Fin8 refa24_inst.
Proof. unfold Equation2340. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa24_inst, refa24_op in H. discriminate H. Qed.

Lemma refa24_not2441 : ~ @Equation2441 Fin8 refa24_inst.
Proof. unfold Equation2441. intro H. specialize (H F8_0). unfold magma_op, refa24_inst, refa24_op in H. discriminate H. Qed.

Lemma refa24_not2644 : ~ @Equation2644 Fin8 refa24_inst.
Proof. unfold Equation2644. intro H. specialize (H F8_0). unfold magma_op, refa24_inst, refa24_op in H. discriminate H. Qed.

Lemma refa24_not2847 : ~ @Equation2847 Fin8 refa24_inst.
Proof. unfold Equation2847. intro H. specialize (H F8_0). unfold magma_op, refa24_inst, refa24_op in H. discriminate H. Qed.

Lemma refa24_not3050 : ~ @Equation3050 Fin8 refa24_inst.
Proof. unfold Equation3050. intro H. specialize (H F8_0). unfold magma_op, refa24_inst, refa24_op in H. discriminate H. Qed.

Lemma refa24_not3253 : ~ @Equation3253 Fin8 refa24_inst.
Proof. unfold Equation3253. intro H. specialize (H F8_0). unfold magma_op, refa24_inst, refa24_op in H. discriminate H. Qed.

Lemma refa24_not3456 : ~ @Equation3456 Fin8 refa24_inst.
Proof. unfold Equation3456. intro H. specialize (H F8_0). unfold magma_op, refa24_inst, refa24_op in H. discriminate H. Qed.

Lemma refa24_not3659 : ~ @Equation3659 Fin8 refa24_inst.
Proof. unfold Equation3659. intro H. specialize (H F8_0). unfold magma_op, refa24_inst, refa24_op in H. discriminate H. Qed.

Lemma refa24_not3862 : ~ @Equation3862 Fin8 refa24_inst.
Proof. unfold Equation3862. intro H. specialize (H F8_0). unfold magma_op, refa24_inst, refa24_op in H. discriminate H. Qed.

Lemma refa24_not4065 : ~ @Equation4065 Fin8 refa24_inst.
Proof. unfold Equation4065. intro H. specialize (H F8_0). unfold magma_op, refa24_inst, refa24_op in H. discriminate H. Qed.

Lemma refa24_not4270 : ~ @Equation4270 Fin8 refa24_inst.
Proof. unfold Equation4270. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa24_inst, refa24_op in H. discriminate H. Qed.

Lemma refa24_not4273 : ~ @Equation4273 Fin8 refa24_inst.
Proof. unfold Equation4273. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa24_inst, refa24_op in H. discriminate H. Qed.

Lemma refa24_not4275 : ~ @Equation4275 Fin8 refa24_inst.
Proof. unfold Equation4275. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa24_inst, refa24_op in H. discriminate H. Qed.

Lemma refa24_not4283 : ~ @Equation4283 Fin8 refa24_inst.
Proof. unfold Equation4283. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa24_inst, refa24_op in H. discriminate H. Qed.

Lemma refa24_not4290 : ~ @Equation4290 Fin8 refa24_inst.
Proof. unfold Equation4290. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa24_inst, refa24_op in H. discriminate H. Qed.

Lemma refa24_not4320 : ~ @Equation4320 Fin8 refa24_inst.
Proof. unfold Equation4320. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa24_inst, refa24_op in H. discriminate H. Qed.

Lemma refa24_not4380 : ~ @Equation4380 Fin8 refa24_inst.
Proof. unfold Equation4380. intro H. specialize (H F8_0). unfold magma_op, refa24_inst, refa24_op in H. discriminate H. Qed.

Lemma refa24_not4585 : ~ @Equation4585 Fin8 refa24_inst.
Proof. unfold Equation4585. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa24_inst, refa24_op in H. discriminate H. Qed.

Lemma refa24_not4588 : ~ @Equation4588 Fin8 refa24_inst.
Proof. unfold Equation4588. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa24_inst, refa24_op in H. discriminate H. Qed.

Lemma refa24_not4590 : ~ @Equation4590 Fin8 refa24_inst.
Proof. unfold Equation4590. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa24_inst, refa24_op in H. discriminate H. Qed.

Lemma refa24_not4598 : ~ @Equation4598 Fin8 refa24_inst.
Proof. unfold Equation4598. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa24_inst, refa24_op in H. discriminate H. Qed.

Lemma refa24_not4605 : ~ @Equation4605 Fin8 refa24_inst.
Proof. unfold Equation4605. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa24_inst, refa24_op in H. discriminate H. Qed.

Lemma refa24_not4635 : ~ @Equation4635 Fin8 refa24_inst.
Proof. unfold Equation4635. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa24_inst, refa24_op in H. discriminate H. Qed.

(** ---- refa240 (Fin3) ---- *)

Definition refa240_op (x y : Fin3) : Fin3 :=
  match x, y with
  | F3_0, F3_0 => F3_0 | F3_0, F3_1 => F3_2 | F3_0, F3_2 => F3_1
  | F3_1, F3_0 => F3_1 | F3_1, F3_1 => F3_2 | F3_1, F3_2 => F3_0
  | F3_2, F3_0 => F3_2 | F3_2, F3_1 => F3_0 | F3_2, F3_2 => F3_1
  end.

#[local] Instance refa240_inst : Magma Fin3 := {| magma_op := refa240_op |}.

Lemma refa240_sat56 : @Equation56 Fin3 refa240_inst.
Proof. unfold Equation56, magma_op, refa240_inst, refa240_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa240_sat1894 : @Equation1894 Fin3 refa240_inst.
Proof. unfold Equation1894, magma_op, refa240_inst, refa240_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa240_sat1931 : @Equation1931 Fin3 refa240_inst.
Proof. unfold Equation1931, magma_op, refa240_inst, refa240_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa240_sat2100 : @Equation2100 Fin3 refa240_inst.
Proof. unfold Equation2100, magma_op, refa240_inst, refa240_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa240_sat3890 : @Equation3890 Fin3 refa240_inst.
Proof. unfold Equation3890, magma_op, refa240_inst, refa240_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa240_not107 : ~ @Equation107 Fin3 refa240_inst.
Proof. unfold Equation107. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa240_inst, refa240_op in H. discriminate H. Qed.

Lemma refa240_not1020 : ~ @Equation1020 Fin3 refa240_inst.
Proof. unfold Equation1020. intro H. specialize (H F3_1). unfold magma_op, refa240_inst, refa240_op in H. discriminate H. Qed.

Lemma refa240_not1223 : ~ @Equation1223 Fin3 refa240_inst.
Proof. unfold Equation1223. intro H. specialize (H F3_1). unfold magma_op, refa240_inst, refa240_op in H. discriminate H. Qed.

Lemma refa240_not1629 : ~ @Equation1629 Fin3 refa240_inst.
Proof. unfold Equation1629. intro H. specialize (H F3_1). unfold magma_op, refa240_inst, refa240_op in H. discriminate H. Qed.

Lemma refa240_not1837 : ~ @Equation1837 Fin3 refa240_inst.
Proof. unfold Equation1837. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa240_inst, refa240_op in H. discriminate H. Qed.

Lemma refa240_not1847 : ~ @Equation1847 Fin3 refa240_inst.
Proof. unfold Equation1847. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa240_inst, refa240_op in H. discriminate H. Qed.

Lemma refa240_not1857 : ~ @Equation1857 Fin3 refa240_inst.
Proof. unfold Equation1857. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa240_inst, refa240_op in H. discriminate H. Qed.

Lemma refa240_not2050 : ~ @Equation2050 Fin3 refa240_inst.
Proof. unfold Equation2050. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa240_inst, refa240_op in H. discriminate H. Qed.

Lemma refa240_not2063 : ~ @Equation2063 Fin3 refa240_inst.
Proof. unfold Equation2063. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa240_inst, refa240_op in H. discriminate H. Qed.

Lemma refa240_not2087 : ~ @Equation2087 Fin3 refa240_inst.
Proof. unfold Equation2087. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa240_inst, refa240_op in H. discriminate H. Qed.

Lemma refa240_not2124 : ~ @Equation2124 Fin3 refa240_inst.
Proof. unfold Equation2124. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa240_inst, refa240_op in H. discriminate H. Qed.

Lemma refa240_not3258 : ~ @Equation3258 Fin3 refa240_inst.
Proof. unfold Equation3258. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa240_inst, refa240_op in H. discriminate H. Qed.

Lemma refa240_not3456 : ~ @Equation3456 Fin3 refa240_inst.
Proof. unfold Equation3456. intro H. specialize (H F3_1). unfold magma_op, refa240_inst, refa240_op in H. discriminate H. Qed.

Lemma refa240_not3877 : ~ @Equation3877 Fin3 refa240_inst.
Proof. unfold Equation3877. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa240_inst, refa240_op in H. discriminate H. Qed.

Lemma refa240_not3880 : ~ @Equation3880 Fin3 refa240_inst.
Proof. unfold Equation3880. intro H. specialize (H F3_1 F3_0). unfold magma_op, refa240_inst, refa240_op in H. discriminate H. Qed.

Lemma refa240_not4067 : ~ @Equation4067 Fin3 refa240_inst.
Proof. unfold Equation4067. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa240_inst, refa240_op in H. discriminate H. Qed.

Lemma refa240_not4083 : ~ @Equation4083 Fin3 refa240_inst.
Proof. unfold Equation4083. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa240_inst, refa240_op in H. discriminate H. Qed.

Lemma refa240_not4090 : ~ @Equation4090 Fin3 refa240_inst.
Proof. unfold Equation4090. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa240_inst, refa240_op in H. discriminate H. Qed.

Lemma refa240_not4121 : ~ @Equation4121 Fin3 refa240_inst.
Proof. unfold Equation4121. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa240_inst, refa240_op in H. discriminate H. Qed.

Lemma refa240_not4320 : ~ @Equation4320 Fin3 refa240_inst.
Proof. unfold Equation4320. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa240_inst, refa240_op in H. discriminate H. Qed.

Lemma refa240_not4396 : ~ @Equation4396 Fin3 refa240_inst.
Proof. unfold Equation4396. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa240_inst, refa240_op in H. discriminate H. Qed.

Lemma refa240_not4435 : ~ @Equation4435 Fin3 refa240_inst.
Proof. unfold Equation4435. intro H. specialize (H F3_1 F3_0). unfold magma_op, refa240_inst, refa240_op in H. discriminate H. Qed.

Lemma refa240_not4445 : ~ @Equation4445 Fin3 refa240_inst.
Proof. unfold Equation4445. intro H. specialize (H F3_1 F3_0). unfold magma_op, refa240_inst, refa240_op in H. discriminate H. Qed.

Lemma refa240_not4599 : ~ @Equation4599 Fin3 refa240_inst.
Proof. unfold Equation4599. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa240_inst, refa240_op in H. discriminate H. Qed.

Lemma refa240_not4622 : ~ @Equation4622 Fin3 refa240_inst.
Proof. unfold Equation4622. intro H. specialize (H F3_0 F3_0 F3_1). unfold magma_op, refa240_inst, refa240_op in H. discriminate H. Qed.

(** ---- refa241 (Fin3) ---- *)

Definition refa241_op (x y : Fin3) : Fin3 :=
  match x, y with
  | F3_0, F3_0 => F3_0 | F3_0, F3_1 => F3_0 | F3_0, F3_2 => F3_1
  | F3_1, F3_0 => F3_2 | F3_1, F3_1 => F3_2 | F3_1, F3_2 => F3_1
  | F3_2, F3_0 => F3_0 | F3_2, F3_1 => F3_2 | F3_2, F3_2 => F3_1
  end.

#[local] Instance refa241_inst : Magma Fin3 := {| magma_op := refa241_op |}.

Lemma refa241_sat1681 : @Equation1681 Fin3 refa241_inst.
Proof. unfold Equation1681, magma_op, refa241_inst, refa241_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa241_not1691 : ~ @Equation1691 Fin3 refa241_inst.
Proof. unfold Equation1691. intro H. specialize (H F3_1 F3_0). unfold magma_op, refa241_inst, refa241_op in H. discriminate H. Qed.

Lemma refa241_not3306 : ~ @Equation3306 Fin3 refa241_inst.
Proof. unfold Equation3306. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa241_inst, refa241_op in H. discriminate H. Qed.

Lemma refa241_not3353 : ~ @Equation3353 Fin3 refa241_inst.
Proof. unfold Equation3353. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa241_inst, refa241_op in H. discriminate H. Qed.

Lemma refa241_not3887 : ~ @Equation3887 Fin3 refa241_inst.
Proof. unfold Equation3887. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa241_inst, refa241_op in H. discriminate H. Qed.

Lemma refa241_not3962 : ~ @Equation3962 Fin3 refa241_inst.
Proof. unfold Equation3962. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa241_inst, refa241_op in H. discriminate H. Qed.

(** ---- refa242 (Fin3) ---- *)

Definition refa242_op (x y : Fin3) : Fin3 :=
  match x, y with
  | F3_0, F3_0 => F3_0 | F3_0, F3_1 => F3_0 | F3_0, F3_2 => F3_0
  | F3_1, F3_0 => F3_0 | F3_1, F3_1 => F3_0 | F3_1, F3_2 => F3_0
  | F3_2, F3_0 => F3_0 | F3_2, F3_1 => F3_1 | F3_2, F3_2 => F3_2
  end.

#[local] Instance refa242_inst : Magma Fin3 := {| magma_op := refa242_op |}.

Lemma refa242_sat4443 : @Equation4443 Fin3 refa242_inst.
Proof. unfold Equation4443, magma_op, refa242_inst, refa242_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa242_not4482 : ~ @Equation4482 Fin3 refa242_inst.
Proof. unfold Equation4482. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa242_inst, refa242_op in H. discriminate H. Qed.

(** ---- refa243 (Fin3) ---- *)

Definition refa243_op (x y : Fin3) : Fin3 :=
  match x, y with
  | F3_0, F3_0 => F3_0 | F3_0, F3_1 => F3_1 | F3_0, F3_2 => F3_2
  | F3_1, F3_0 => F3_0 | F3_1, F3_1 => F3_1 | F3_1, F3_2 => F3_2
  | F3_2, F3_0 => F3_1 | F3_2, F3_1 => F3_0 | F3_2, F3_2 => F3_0
  end.

#[local] Instance refa243_inst : Magma Fin3 := {| magma_op := refa243_op |}.

Lemma refa243_sat2420 : @Equation2420 Fin3 refa243_inst.
Proof. unfold Equation2420, magma_op, refa243_inst, refa243_op. intros x y z w. destruct x, y, z, w; reflexivity. Qed.

Lemma refa243_not3519 : ~ @Equation3519 Fin3 refa243_inst.
Proof. unfold Equation3519. intro H. specialize (H F3_2 F3_0). unfold magma_op, refa243_inst, refa243_op in H. discriminate H. Qed.

Lemma refa243_not3749 : ~ @Equation3749 Fin3 refa243_inst.
Proof. unfold Equation3749. intro H. specialize (H F3_2 F3_0). unfold magma_op, refa243_inst, refa243_op in H. discriminate H. Qed.

(** ---- refa244 (Fin3) ---- *)

Definition refa244_op (x y : Fin3) : Fin3 :=
  match x, y with
  | F3_0, F3_0 => F3_0 | F3_0, F3_1 => F3_0 | F3_0, F3_2 => F3_0
  | F3_1, F3_0 => F3_0 | F3_1, F3_1 => F3_0 | F3_1, F3_2 => F3_2
  | F3_2, F3_0 => F3_0 | F3_2, F3_1 => F3_2 | F3_2, F3_2 => F3_2
  end.

#[local] Instance refa244_inst : Magma Fin3 := {| magma_op := refa244_op |}.

Lemma refa244_sat325 : @Equation325 Fin3 refa244_inst.
Proof. unfold Equation325, magma_op, refa244_inst, refa244_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa244_sat333 : @Equation333 Fin3 refa244_inst.
Proof. unfold Equation333, magma_op, refa244_inst, refa244_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa244_sat335 : @Equation335 Fin3 refa244_inst.
Proof. unfold Equation335, magma_op, refa244_inst, refa244_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa244_sat377 : @Equation377 Fin3 refa244_inst.
Proof. unfold Equation377, magma_op, refa244_inst, refa244_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa244_sat384 : @Equation384 Fin3 refa244_inst.
Proof. unfold Equation384, magma_op, refa244_inst, refa244_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa244_sat385 : @Equation385 Fin3 refa244_inst.
Proof. unfold Equation385, magma_op, refa244_inst, refa244_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa244_sat3318 : @Equation3318 Fin3 refa244_inst.
Proof. unfold Equation3318, magma_op, refa244_inst, refa244_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa244_sat3519 : @Equation3519 Fin3 refa244_inst.
Proof. unfold Equation3519, magma_op, refa244_inst, refa244_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa244_sat3751 : @Equation3751 Fin3 refa244_inst.
Proof. unfold Equation3751, magma_op, refa244_inst, refa244_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa244_not3315 : ~ @Equation3315 Fin3 refa244_inst.
Proof. unfold Equation3315. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa244_inst, refa244_op in H. discriminate H. Qed.

Lemma refa244_not3319 : ~ @Equation3319 Fin3 refa244_inst.
Proof. unfold Equation3319. intro H. specialize (H F3_2 F3_1). unfold magma_op, refa244_inst, refa244_op in H. discriminate H. Qed.

Lemma refa244_not3352 : ~ @Equation3352 Fin3 refa244_inst.
Proof. unfold Equation3352. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa244_inst, refa244_op in H. discriminate H. Qed.

Lemma refa244_not3521 : ~ @Equation3521 Fin3 refa244_inst.
Proof. unfold Equation3521. intro H. specialize (H F3_2 F3_1). unfold magma_op, refa244_inst, refa244_op in H. discriminate H. Qed.

Lemma refa244_not3522 : ~ @Equation3522 Fin3 refa244_inst.
Proof. unfold Equation3522. intro H. specialize (H F3_2 F3_1). unfold magma_op, refa244_inst, refa244_op in H. discriminate H. Qed.

Lemma refa244_not3546 : ~ @Equation3546 Fin3 refa244_inst.
Proof. unfold Equation3546. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa244_inst, refa244_op in H. discriminate H. Qed.

Lemma refa244_not3558 : ~ @Equation3558 Fin3 refa244_inst.
Proof. unfold Equation3558. intro H. specialize (H F3_2 F3_1). unfold magma_op, refa244_inst, refa244_op in H. discriminate H. Qed.

Lemma refa244_not3712 : ~ @Equation3712 Fin3 refa244_inst.
Proof. unfold Equation3712. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa244_inst, refa244_op in H. discriminate H. Qed.

Lemma refa244_not3714 : ~ @Equation3714 Fin3 refa244_inst.
Proof. unfold Equation3714. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa244_inst, refa244_op in H. discriminate H. Qed.

Lemma refa244_not3721 : ~ @Equation3721 Fin3 refa244_inst.
Proof. unfold Equation3721. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa244_inst, refa244_op in H. discriminate H. Qed.

Lemma refa244_not3725 : ~ @Equation3725 Fin3 refa244_inst.
Proof. unfold Equation3725. intro H. specialize (H F3_2 F3_1). unfold magma_op, refa244_inst, refa244_op in H. discriminate H. Qed.

Lemma refa244_not3748 : ~ @Equation3748 Fin3 refa244_inst.
Proof. unfold Equation3748. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa244_inst, refa244_op in H. discriminate H. Qed.

Lemma refa244_not3752 : ~ @Equation3752 Fin3 refa244_inst.
Proof. unfold Equation3752. intro H. specialize (H F3_2 F3_1). unfold magma_op, refa244_inst, refa244_op in H. discriminate H. Qed.

Lemma refa244_not3759 : ~ @Equation3759 Fin3 refa244_inst.
Proof. unfold Equation3759. intro H. specialize (H F3_2 F3_1). unfold magma_op, refa244_inst, refa244_op in H. discriminate H. Qed.

Lemma refa244_not3761 : ~ @Equation3761 Fin3 refa244_inst.
Proof. unfold Equation3761. intro H. specialize (H F3_2 F3_1). unfold magma_op, refa244_inst, refa244_op in H. discriminate H. Qed.

Lemma refa244_not3915 : ~ @Equation3915 Fin3 refa244_inst.
Proof. unfold Equation3915. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa244_inst, refa244_op in H. discriminate H. Qed.

Lemma refa244_not3927 : ~ @Equation3927 Fin3 refa244_inst.
Proof. unfold Equation3927. intro H. specialize (H F3_2 F3_1). unfold magma_op, refa244_inst, refa244_op in H. discriminate H. Qed.

Lemma refa244_not3951 : ~ @Equation3951 Fin3 refa244_inst.
Proof. unfold Equation3951. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa244_inst, refa244_op in H. discriminate H. Qed.

Lemma refa244_not3952 : ~ @Equation3952 Fin3 refa244_inst.
Proof. unfold Equation3952. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa244_inst, refa244_op in H. discriminate H. Qed.

Lemma refa244_not4118 : ~ @Equation4118 Fin3 refa244_inst.
Proof. unfold Equation4118. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa244_inst, refa244_op in H. discriminate H. Qed.

Lemma refa244_not4164 : ~ @Equation4164 Fin3 refa244_inst.
Proof. unfold Equation4164. intro H. specialize (H F3_2 F3_1). unfold magma_op, refa244_inst, refa244_op in H. discriminate H. Qed.

Lemma refa244_not4165 : ~ @Equation4165 Fin3 refa244_inst.
Proof. unfold Equation4165. intro H. specialize (H F3_2 F3_1). unfold magma_op, refa244_inst, refa244_op in H. discriminate H. Qed.

Lemma refa244_not4284 : ~ @Equation4284 Fin3 refa244_inst.
Proof. unfold Equation4284. intro H. specialize (H F3_2 F3_1). unfold magma_op, refa244_inst, refa244_op in H. discriminate H. Qed.

Lemma refa244_not4290 : ~ @Equation4290 Fin3 refa244_inst.
Proof. unfold Equation4290. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa244_inst, refa244_op in H. discriminate H. Qed.

Lemma refa244_not4314 : ~ @Equation4314 Fin3 refa244_inst.
Proof. unfold Equation4314. intro H. specialize (H F3_2 F3_1). unfold magma_op, refa244_inst, refa244_op in H. discriminate H. Qed.

Lemma refa244_not4320 : ~ @Equation4320 Fin3 refa244_inst.
Proof. unfold Equation4320. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa244_inst, refa244_op in H. discriminate H. Qed.

Lemma refa244_not4396 : ~ @Equation4396 Fin3 refa244_inst.
Proof. unfold Equation4396. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa244_inst, refa244_op in H. discriminate H. Qed.

Lemma refa244_not4408 : ~ @Equation4408 Fin3 refa244_inst.
Proof. unfold Equation4408. intro H. specialize (H F3_2 F3_1). unfold magma_op, refa244_inst, refa244_op in H. discriminate H. Qed.

Lemma refa244_not4433 : ~ @Equation4433 Fin3 refa244_inst.
Proof. unfold Equation4433. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa244_inst, refa244_op in H. discriminate H. Qed.

Lemma refa244_not4445 : ~ @Equation4445 Fin3 refa244_inst.
Proof. unfold Equation4445. intro H. specialize (H F3_2 F3_1). unfold magma_op, refa244_inst, refa244_op in H. discriminate H. Qed.

Lemma refa244_not4470 : ~ @Equation4470 Fin3 refa244_inst.
Proof. unfold Equation4470. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa244_inst, refa244_op in H. discriminate H. Qed.

Lemma refa244_not4472 : ~ @Equation4472 Fin3 refa244_inst.
Proof. unfold Equation4472. intro H. specialize (H F3_2 F3_1). unfold magma_op, refa244_inst, refa244_op in H. discriminate H. Qed.

Lemma refa244_not4473 : ~ @Equation4473 Fin3 refa244_inst.
Proof. unfold Equation4473. intro H. specialize (H F3_2 F3_1). unfold magma_op, refa244_inst, refa244_op in H. discriminate H. Qed.

Lemma refa244_not4479 : ~ @Equation4479 Fin3 refa244_inst.
Proof. unfold Equation4479. intro H. specialize (H F3_2 F3_1). unfold magma_op, refa244_inst, refa244_op in H. discriminate H. Qed.

Lemma refa244_not4480 : ~ @Equation4480 Fin3 refa244_inst.
Proof. unfold Equation4480. intro H. specialize (H F3_2 F3_1). unfold magma_op, refa244_inst, refa244_op in H. discriminate H. Qed.

Lemma refa244_not4598 : ~ @Equation4598 Fin3 refa244_inst.
Proof. unfold Equation4598. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa244_inst, refa244_op in H. discriminate H. Qed.

Lemma refa244_not4599 : ~ @Equation4599 Fin3 refa244_inst.
Proof. unfold Equation4599. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa244_inst, refa244_op in H. discriminate H. Qed.

Lemma refa244_not4605 : ~ @Equation4605 Fin3 refa244_inst.
Proof. unfold Equation4605. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa244_inst, refa244_op in H. discriminate H. Qed.

Lemma refa244_not4606 : ~ @Equation4606 Fin3 refa244_inst.
Proof. unfold Equation4606. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa244_inst, refa244_op in H. discriminate H. Qed.

Lemma refa244_not4608 : ~ @Equation4608 Fin3 refa244_inst.
Proof. unfold Equation4608. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa244_inst, refa244_op in H. discriminate H. Qed.

(** ---- refa245 (Fin3) ---- *)

Definition refa245_op (x y : Fin3) : Fin3 :=
  match x, y with
  | F3_0, F3_0 => F3_0 | F3_0, F3_1 => F3_0 | F3_0, F3_2 => F3_0
  | F3_1, F3_0 => F3_2 | F3_1, F3_1 => F3_0 | F3_1, F3_2 => F3_2
  | F3_2, F3_0 => F3_1 | F3_2, F3_1 => F3_1 | F3_2, F3_2 => F3_1
  end.

#[local] Instance refa245_inst : Magma Fin3 := {| magma_op := refa245_op |}.

Lemma refa245_sat4066 : @Equation4066 Fin3 refa245_inst.
Proof. unfold Equation4066, magma_op, refa245_inst, refa245_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa245_not4067 : ~ @Equation4067 Fin3 refa245_inst.
Proof. unfold Equation4067. intro H. specialize (H F3_2 F3_1). unfold magma_op, refa245_inst, refa245_op in H. discriminate H. Qed.

Lemma refa245_not4068 : ~ @Equation4068 Fin3 refa245_inst.
Proof. unfold Equation4068. intro H. specialize (H F3_2 F3_1). unfold magma_op, refa245_inst, refa245_op in H. discriminate H. Qed.

Lemma refa245_not4583 : ~ @Equation4583 Fin3 refa245_inst.
Proof. unfold Equation4583. intro H. specialize (H F3_2 F3_1). unfold magma_op, refa245_inst, refa245_op in H. discriminate H. Qed.

(** ---- refa246 (Fin3) ---- *)

Definition refa246_op (x y : Fin3) : Fin3 :=
  match x, y with
  | F3_0, F3_0 => F3_0 | F3_0, F3_1 => F3_1 | F3_0, F3_2 => F3_2
  | F3_1, F3_0 => F3_1 | F3_1, F3_1 => F3_0 | F3_1, F3_2 => F3_0
  | F3_2, F3_0 => F3_1 | F3_2, F3_1 => F3_1 | F3_2, F3_2 => F3_0
  end.

#[local] Instance refa246_inst : Magma Fin3 := {| magma_op := refa246_op |}.

Lemma refa246_sat3011 : @Equation3011 Fin3 refa246_inst.
Proof. unfold Equation3011, magma_op, refa246_inst, refa246_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa246_not2238 : ~ @Equation2238 Fin3 refa246_inst.
Proof. unfold Equation2238. intro H. specialize (H F3_2). unfold magma_op, refa246_inst, refa246_op in H. discriminate H. Qed.

Lemma refa246_not2449 : ~ @Equation2449 Fin3 refa246_inst.
Proof. unfold Equation2449. intro H. specialize (H F3_2 F3_0). unfold magma_op, refa246_inst, refa246_op in H. discriminate H. Qed.

Lemma refa246_not2459 : ~ @Equation2459 Fin3 refa246_inst.
Proof. unfold Equation2459. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa246_inst, refa246_op in H. discriminate H. Qed.

Lemma refa246_not2503 : ~ @Equation2503 Fin3 refa246_inst.
Proof. unfold Equation2503. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa246_inst, refa246_op in H. discriminate H. Qed.

Lemma refa246_not2530 : ~ @Equation2530 Fin3 refa246_inst.
Proof. unfold Equation2530. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa246_inst, refa246_op in H. discriminate H. Qed.

Lemma refa246_not2699 : ~ @Equation2699 Fin3 refa246_inst.
Proof. unfold Equation2699. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa246_inst, refa246_op in H. discriminate H. Qed.

Lemma refa246_not3075 : ~ @Equation3075 Fin3 refa246_inst.
Proof. unfold Equation3075. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa246_inst, refa246_op in H. discriminate H. Qed.

Lemma refa246_not3105 : ~ @Equation3105 Fin3 refa246_inst.
Proof. unfold Equation3105. intro H. specialize (H F3_2 F3_1). unfold magma_op, refa246_inst, refa246_op in H. discriminate H. Qed.

Lemma refa246_not3253 : ~ @Equation3253 Fin3 refa246_inst.
Proof. unfold Equation3253. intro H. specialize (H F3_2). unfold magma_op, refa246_inst, refa246_op in H. discriminate H. Qed.

Lemma refa246_not3459 : ~ @Equation3459 Fin3 refa246_inst.
Proof. unfold Equation3459. intro H. specialize (H F3_2 F3_0). unfold magma_op, refa246_inst, refa246_op in H. discriminate H. Qed.

Lemma refa246_not3481 : ~ @Equation3481 Fin3 refa246_inst.
Proof. unfold Equation3481. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa246_inst, refa246_op in H. discriminate H. Qed.

Lemma refa246_not3511 : ~ @Equation3511 Fin3 refa246_inst.
Proof. unfold Equation3511. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa246_inst, refa246_op in H. discriminate H. Qed.

Lemma refa246_not3518 : ~ @Equation3518 Fin3 refa246_inst.
Proof. unfold Equation3518. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa246_inst, refa246_op in H. discriminate H. Qed.

Lemma refa246_not3545 : ~ @Equation3545 Fin3 refa246_inst.
Proof. unfold Equation3545. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa246_inst, refa246_op in H. discriminate H. Qed.

Lemma refa246_not3549 : ~ @Equation3549 Fin3 refa246_inst.
Proof. unfold Equation3549. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa246_inst, refa246_op in H. discriminate H. Qed.

Lemma refa246_not3556 : ~ @Equation3556 Fin3 refa246_inst.
Proof. unfold Equation3556. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa246_inst, refa246_op in H. discriminate H. Qed.

Lemma refa246_not3880 : ~ @Equation3880 Fin3 refa246_inst.
Proof. unfold Equation3880. intro H. specialize (H F3_2 F3_1). unfold magma_op, refa246_inst, refa246_op in H. discriminate H. Qed.

Lemma refa246_not3887 : ~ @Equation3887 Fin3 refa246_inst.
Proof. unfold Equation3887. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa246_inst, refa246_op in H. discriminate H. Qed.

Lemma refa246_not3915 : ~ @Equation3915 Fin3 refa246_inst.
Proof. unfold Equation3915. intro H. specialize (H F3_2 F3_1). unfold magma_op, refa246_inst, refa246_op in H. discriminate H. Qed.

Lemma refa246_not3917 : ~ @Equation3917 Fin3 refa246_inst.
Proof. unfold Equation3917. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa246_inst, refa246_op in H. discriminate H. Qed.

Lemma refa246_not3962 : ~ @Equation3962 Fin3 refa246_inst.
Proof. unfold Equation3962. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa246_inst, refa246_op in H. discriminate H. Qed.

Lemma refa246_not3964 : ~ @Equation3964 Fin3 refa246_inst.
Proof. unfold Equation3964. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa246_inst, refa246_op in H. discriminate H. Qed.

Lemma refa246_not4073 : ~ @Equation4073 Fin3 refa246_inst.
Proof. unfold Equation4073. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa246_inst, refa246_op in H. discriminate H. Qed.

Lemma refa246_not4083 : ~ @Equation4083 Fin3 refa246_inst.
Proof. unfold Equation4083. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa246_inst, refa246_op in H. discriminate H. Qed.

Lemma refa246_not4127 : ~ @Equation4127 Fin3 refa246_inst.
Proof. unfold Equation4127. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa246_inst, refa246_op in H. discriminate H. Qed.

Lemma refa246_not4158 : ~ @Equation4158 Fin3 refa246_inst.
Proof. unfold Equation4158. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa246_inst, refa246_op in H. discriminate H. Qed.

Lemma refa246_not4167 : ~ @Equation4167 Fin3 refa246_inst.
Proof. unfold Equation4167. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa246_inst, refa246_op in H. discriminate H. Qed.

Lemma refa246_not4273 : ~ @Equation4273 Fin3 refa246_inst.
Proof. unfold Equation4273. intro H. specialize (H F3_2 F3_1). unfold magma_op, refa246_inst, refa246_op in H. discriminate H. Qed.

Lemma refa246_not4380 : ~ @Equation4380 Fin3 refa246_inst.
Proof. unfold Equation4380. intro H. specialize (H F3_2). unfold magma_op, refa246_inst, refa246_op in H. discriminate H. Qed.

Lemma refa246_not4635 : ~ @Equation4635 Fin3 refa246_inst.
Proof. unfold Equation4635. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa246_inst, refa246_op in H. discriminate H. Qed.

Lemma refa246_not4656 : ~ @Equation4656 Fin3 refa246_inst.
Proof. unfold Equation4656. intro H. specialize (H F3_1 F3_0 F3_2). unfold magma_op, refa246_inst, refa246_op in H. discriminate H. Qed.

(** ---- refa247 (Fin3) ---- *)

Definition refa247_op (x y : Fin3) : Fin3 :=
  match x, y with
  | F3_0, F3_0 => F3_0 | F3_0, F3_1 => F3_2 | F3_0, F3_2 => F3_1
  | F3_1, F3_0 => F3_1 | F3_1, F3_1 => F3_0 | F3_1, F3_2 => F3_0
  | F3_2, F3_0 => F3_2 | F3_2, F3_1 => F3_0 | F3_2, F3_2 => F3_0
  end.

#[local] Instance refa247_inst : Magma Fin3 := {| magma_op := refa247_op |}.

Lemma refa247_sat452 : @Equation452 Fin3 refa247_inst.
Proof. unfold Equation452, magma_op, refa247_inst, refa247_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa247_sat455 : @Equation455 Fin3 refa247_inst.
Proof. unfold Equation455, magma_op, refa247_inst, refa247_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa247_not4598 : ~ @Equation4598 Fin3 refa247_inst.
Proof. unfold Equation4598. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa247_inst, refa247_op in H. discriminate H. Qed.

Lemma refa247_not4647 : ~ @Equation4647 Fin3 refa247_inst.
Proof. unfold Equation4647. intro H. specialize (H F3_0 F3_1 F3_2). unfold magma_op, refa247_inst, refa247_op in H. discriminate H. Qed.

(** ---- refa248 (Fin3) ---- *)

Definition refa248_op (x y : Fin3) : Fin3 :=
  match x, y with
  | F3_0, F3_0 => F3_0 | F3_0, F3_1 => F3_0 | F3_0, F3_2 => F3_0
  | F3_1, F3_0 => F3_2 | F3_1, F3_1 => F3_0 | F3_1, F3_2 => F3_1
  | F3_2, F3_0 => F3_1 | F3_2, F3_1 => F3_2 | F3_2, F3_2 => F3_0
  end.

#[local] Instance refa248_inst : Magma Fin3 := {| magma_op := refa248_op |}.

Lemma refa248_sat620 : @Equation620 Fin3 refa248_inst.
Proof. unfold Equation620, magma_op, refa248_inst, refa248_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa248_sat624 : @Equation624 Fin3 refa248_inst.
Proof. unfold Equation624, magma_op, refa248_inst, refa248_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa248_not56 : ~ @Equation56 Fin3 refa248_inst.
Proof. unfold Equation56. intro H. specialize (H F3_1 F3_0). unfold magma_op, refa248_inst, refa248_op in H. discriminate H. Qed.

Lemma refa248_not99 : ~ @Equation99 Fin3 refa248_inst.
Proof. unfold Equation99. intro H. specialize (H F3_1). unfold magma_op, refa248_inst, refa248_op in H. discriminate H. Qed.

Lemma refa248_not151 : ~ @Equation151 Fin3 refa248_inst.
Proof. unfold Equation151. intro H. specialize (H F3_1). unfold magma_op, refa248_inst, refa248_op in H. discriminate H. Qed.

Lemma refa248_not203 : ~ @Equation203 Fin3 refa248_inst.
Proof. unfold Equation203. intro H. specialize (H F3_1). unfold magma_op, refa248_inst, refa248_op in H. discriminate H. Qed.

Lemma refa248_not255 : ~ @Equation255 Fin3 refa248_inst.
Proof. unfold Equation255. intro H. specialize (H F3_1). unfold magma_op, refa248_inst, refa248_op in H. discriminate H. Qed.

Lemma refa248_not378 : ~ @Equation378 Fin3 refa248_inst.
Proof. unfold Equation378. intro H. specialize (H F3_1 F3_0). unfold magma_op, refa248_inst, refa248_op in H. discriminate H. Qed.

Lemma refa248_not411 : ~ @Equation411 Fin3 refa248_inst.
Proof. unfold Equation411. intro H. specialize (H F3_1). unfold magma_op, refa248_inst, refa248_op in H. discriminate H. Qed.

Lemma refa248_not616 : ~ @Equation616 Fin3 refa248_inst.
Proof. unfold Equation616. intro H. specialize (H F3_1 F3_0). unfold magma_op, refa248_inst, refa248_op in H. discriminate H. Qed.

Lemma refa248_not619 : ~ @Equation619 Fin3 refa248_inst.
Proof. unfold Equation619. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa248_inst, refa248_op in H. discriminate H. Qed.

Lemma refa248_not629 : ~ @Equation629 Fin3 refa248_inst.
Proof. unfold Equation629. intro H. specialize (H F3_1 F3_0). unfold magma_op, refa248_inst, refa248_op in H. discriminate H. Qed.

Lemma refa248_not630 : ~ @Equation630 Fin3 refa248_inst.
Proof. unfold Equation630. intro H. specialize (H F3_1 F3_0). unfold magma_op, refa248_inst, refa248_op in H. discriminate H. Qed.

Lemma refa248_not632 : ~ @Equation632 Fin3 refa248_inst.
Proof. unfold Equation632. intro H. specialize (H F3_1 F3_0). unfold magma_op, refa248_inst, refa248_op in H. discriminate H. Qed.

Lemma refa248_not633 : ~ @Equation633 Fin3 refa248_inst.
Proof. unfold Equation633. intro H. specialize (H F3_1 F3_0). unfold magma_op, refa248_inst, refa248_op in H. discriminate H. Qed.

Lemma refa248_not639 : ~ @Equation639 Fin3 refa248_inst.
Proof. unfold Equation639. intro H. specialize (H F3_1 F3_0). unfold magma_op, refa248_inst, refa248_op in H. discriminate H. Qed.

Lemma refa248_not640 : ~ @Equation640 Fin3 refa248_inst.
Proof. unfold Equation640. intro H. specialize (H F3_1 F3_0). unfold magma_op, refa248_inst, refa248_op in H. discriminate H. Qed.

Lemma refa248_not642 : ~ @Equation642 Fin3 refa248_inst.
Proof. unfold Equation642. intro H. specialize (H F3_1 F3_0). unfold magma_op, refa248_inst, refa248_op in H. discriminate H. Qed.

Lemma refa248_not643 : ~ @Equation643 Fin3 refa248_inst.
Proof. unfold Equation643. intro H. specialize (H F3_1 F3_0). unfold magma_op, refa248_inst, refa248_op in H. discriminate H. Qed.

Lemma refa248_not817 : ~ @Equation817 Fin3 refa248_inst.
Proof. unfold Equation817. intro H. specialize (H F3_1). unfold magma_op, refa248_inst, refa248_op in H. discriminate H. Qed.

Lemma refa248_not1021 : ~ @Equation1021 Fin3 refa248_inst.
Proof. unfold Equation1021. intro H. specialize (H F3_1 F3_0). unfold magma_op, refa248_inst, refa248_op in H. discriminate H. Qed.

Lemma refa248_not1023 : ~ @Equation1023 Fin3 refa248_inst.
Proof. unfold Equation1023. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa248_inst, refa248_op in H. discriminate H. Qed.

Lemma refa248_not1029 : ~ @Equation1029 Fin3 refa248_inst.
Proof. unfold Equation1029. intro H. specialize (H F3_1 F3_0). unfold magma_op, refa248_inst, refa248_op in H. discriminate H. Qed.

Lemma refa248_not1035 : ~ @Equation1035 Fin3 refa248_inst.
Proof. unfold Equation1035. intro H. specialize (H F3_1 F3_0). unfold magma_op, refa248_inst, refa248_op in H. discriminate H. Qed.

Lemma refa248_not1036 : ~ @Equation1036 Fin3 refa248_inst.
Proof. unfold Equation1036. intro H. specialize (H F3_1 F3_0). unfold magma_op, refa248_inst, refa248_op in H. discriminate H. Qed.

Lemma refa248_not1038 : ~ @Equation1038 Fin3 refa248_inst.
Proof. unfold Equation1038. intro H. specialize (H F3_1 F3_0). unfold magma_op, refa248_inst, refa248_op in H. discriminate H. Qed.

Lemma refa248_not1039 : ~ @Equation1039 Fin3 refa248_inst.
Proof. unfold Equation1039. intro H. specialize (H F3_1 F3_0). unfold magma_op, refa248_inst, refa248_op in H. discriminate H. Qed.

Lemma refa248_not1045 : ~ @Equation1045 Fin3 refa248_inst.
Proof. unfold Equation1045. intro H. specialize (H F3_1 F3_0). unfold magma_op, refa248_inst, refa248_op in H. discriminate H. Qed.

Lemma refa248_not1046 : ~ @Equation1046 Fin3 refa248_inst.
Proof. unfold Equation1046. intro H. specialize (H F3_1 F3_0). unfold magma_op, refa248_inst, refa248_op in H. discriminate H. Qed.

Lemma refa248_not1048 : ~ @Equation1048 Fin3 refa248_inst.
Proof. unfold Equation1048. intro H. specialize (H F3_1 F3_0). unfold magma_op, refa248_inst, refa248_op in H. discriminate H. Qed.

Lemma refa248_not1049 : ~ @Equation1049 Fin3 refa248_inst.
Proof. unfold Equation1049. intro H. specialize (H F3_1 F3_0). unfold magma_op, refa248_inst, refa248_op in H. discriminate H. Qed.

Lemma refa248_not1223 : ~ @Equation1223 Fin3 refa248_inst.
Proof. unfold Equation1223. intro H. specialize (H F3_1). unfold magma_op, refa248_inst, refa248_op in H. discriminate H. Qed.

Lemma refa248_not1426 : ~ @Equation1426 Fin3 refa248_inst.
Proof. unfold Equation1426. intro H. specialize (H F3_1). unfold magma_op, refa248_inst, refa248_op in H. discriminate H. Qed.

Lemma refa248_not1629 : ~ @Equation1629 Fin3 refa248_inst.
Proof. unfold Equation1629. intro H. specialize (H F3_1). unfold magma_op, refa248_inst, refa248_op in H. discriminate H. Qed.

Lemma refa248_not1833 : ~ @Equation1833 Fin3 refa248_inst.
Proof. unfold Equation1833. intro H. specialize (H F3_1 F3_0). unfold magma_op, refa248_inst, refa248_op in H. discriminate H. Qed.

Lemma refa248_not1834 : ~ @Equation1834 Fin3 refa248_inst.
Proof. unfold Equation1834. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa248_inst, refa248_op in H. discriminate H. Qed.

Lemma refa248_not1837 : ~ @Equation1837 Fin3 refa248_inst.
Proof. unfold Equation1837. intro H. specialize (H F3_1 F3_0). unfold magma_op, refa248_inst, refa248_op in H. discriminate H. Qed.

Lemma refa248_not1838 : ~ @Equation1838 Fin3 refa248_inst.
Proof. unfold Equation1838. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa248_inst, refa248_op in H. discriminate H. Qed.

Lemma refa248_not1840 : ~ @Equation1840 Fin3 refa248_inst.
Proof. unfold Equation1840. intro H. specialize (H F3_1 F3_0). unfold magma_op, refa248_inst, refa248_op in H. discriminate H. Qed.

Lemma refa248_not1841 : ~ @Equation1841 Fin3 refa248_inst.
Proof. unfold Equation1841. intro H. specialize (H F3_1 F3_0). unfold magma_op, refa248_inst, refa248_op in H. discriminate H. Qed.

Lemma refa248_not1847 : ~ @Equation1847 Fin3 refa248_inst.
Proof. unfold Equation1847. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa248_inst, refa248_op in H. discriminate H. Qed.

Lemma refa248_not1848 : ~ @Equation1848 Fin3 refa248_inst.
Proof. unfold Equation1848. intro H. specialize (H F3_1 F3_0). unfold magma_op, refa248_inst, refa248_op in H. discriminate H. Qed.

Lemma refa248_not1851 : ~ @Equation1851 Fin3 refa248_inst.
Proof. unfold Equation1851. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa248_inst, refa248_op in H. discriminate H. Qed.

Lemma refa248_not1858 : ~ @Equation1858 Fin3 refa248_inst.
Proof. unfold Equation1858. intro H. specialize (H F3_1 F3_0). unfold magma_op, refa248_inst, refa248_op in H. discriminate H. Qed.

Lemma refa248_not1860 : ~ @Equation1860 Fin3 refa248_inst.
Proof. unfold Equation1860. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa248_inst, refa248_op in H. discriminate H. Qed.

Lemma refa248_not2035 : ~ @Equation2035 Fin3 refa248_inst.
Proof. unfold Equation2035. intro H. specialize (H F3_1). unfold magma_op, refa248_inst, refa248_op in H. discriminate H. Qed.

Lemma refa248_not2238 : ~ @Equation2238 Fin3 refa248_inst.
Proof. unfold Equation2238. intro H. specialize (H F3_1). unfold magma_op, refa248_inst, refa248_op in H. discriminate H. Qed.

Lemma refa248_not2441 : ~ @Equation2441 Fin3 refa248_inst.
Proof. unfold Equation2441. intro H. specialize (H F3_1). unfold magma_op, refa248_inst, refa248_op in H. discriminate H. Qed.

Lemma refa248_not2644 : ~ @Equation2644 Fin3 refa248_inst.
Proof. unfold Equation2644. intro H. specialize (H F3_1). unfold magma_op, refa248_inst, refa248_op in H. discriminate H. Qed.

Lemma refa248_not2847 : ~ @Equation2847 Fin3 refa248_inst.
Proof. unfold Equation2847. intro H. specialize (H F3_1). unfold magma_op, refa248_inst, refa248_op in H. discriminate H. Qed.

Lemma refa248_not3050 : ~ @Equation3050 Fin3 refa248_inst.
Proof. unfold Equation3050. intro H. specialize (H F3_1). unfold magma_op, refa248_inst, refa248_op in H. discriminate H. Qed.

Lemma refa248_not3253 : ~ @Equation3253 Fin3 refa248_inst.
Proof. unfold Equation3253. intro H. specialize (H F3_1). unfold magma_op, refa248_inst, refa248_op in H. discriminate H. Qed.

Lemma refa248_not3456 : ~ @Equation3456 Fin3 refa248_inst.
Proof. unfold Equation3456. intro H. specialize (H F3_1). unfold magma_op, refa248_inst, refa248_op in H. discriminate H. Qed.

Lemma refa248_not3664 : ~ @Equation3664 Fin3 refa248_inst.
Proof. unfold Equation3664. intro H. specialize (H F3_1 F3_0). unfold magma_op, refa248_inst, refa248_op in H. discriminate H. Qed.

Lemma refa248_not3667 : ~ @Equation3667 Fin3 refa248_inst.
Proof. unfold Equation3667. intro H. specialize (H F3_1 F3_0). unfold magma_op, refa248_inst, refa248_op in H. discriminate H. Qed.

Lemma refa248_not3668 : ~ @Equation3668 Fin3 refa248_inst.
Proof. unfold Equation3668. intro H. specialize (H F3_1 F3_0). unfold magma_op, refa248_inst, refa248_op in H. discriminate H. Qed.

Lemma refa248_not3712 : ~ @Equation3712 Fin3 refa248_inst.
Proof. unfold Equation3712. intro H. specialize (H F3_1 F3_0). unfold magma_op, refa248_inst, refa248_op in H. discriminate H. Qed.

Lemma refa248_not3714 : ~ @Equation3714 Fin3 refa248_inst.
Proof. unfold Equation3714. intro H. specialize (H F3_1 F3_0). unfold magma_op, refa248_inst, refa248_op in H. discriminate H. Qed.

Lemma refa248_not3721 : ~ @Equation3721 Fin3 refa248_inst.
Proof. unfold Equation3721. intro H. specialize (H F3_1 F3_0). unfold magma_op, refa248_inst, refa248_op in H. discriminate H. Qed.

Lemma refa248_not3722 : ~ @Equation3722 Fin3 refa248_inst.
Proof. unfold Equation3722. intro H. specialize (H F3_1 F3_0). unfold magma_op, refa248_inst, refa248_op in H. discriminate H. Qed.

Lemma refa248_not3724 : ~ @Equation3724 Fin3 refa248_inst.
Proof. unfold Equation3724. intro H. specialize (H F3_1 F3_0). unfold magma_op, refa248_inst, refa248_op in H. discriminate H. Qed.

Lemma refa248_not3725 : ~ @Equation3725 Fin3 refa248_inst.
Proof. unfold Equation3725. intro H. specialize (H F3_1 F3_0). unfold magma_op, refa248_inst, refa248_op in H. discriminate H. Qed.

Lemma refa248_not3862 : ~ @Equation3862 Fin3 refa248_inst.
Proof. unfold Equation3862. intro H. specialize (H F3_1). unfold magma_op, refa248_inst, refa248_op in H. discriminate H. Qed.

Lemma refa248_not4070 : ~ @Equation4070 Fin3 refa248_inst.
Proof. unfold Equation4070. intro H. specialize (H F3_1 F3_0). unfold magma_op, refa248_inst, refa248_op in H. discriminate H. Qed.

Lemma refa248_not4071 : ~ @Equation4071 Fin3 refa248_inst.
Proof. unfold Equation4071. intro H. specialize (H F3_1 F3_0). unfold magma_op, refa248_inst, refa248_op in H. discriminate H. Qed.

Lemma refa248_not4074 : ~ @Equation4074 Fin3 refa248_inst.
Proof. unfold Equation4074. intro H. specialize (H F3_1 F3_0). unfold magma_op, refa248_inst, refa248_op in H. discriminate H. Qed.

Lemma refa248_not4118 : ~ @Equation4118 Fin3 refa248_inst.
Proof. unfold Equation4118. intro H. specialize (H F3_1 F3_0). unfold magma_op, refa248_inst, refa248_op in H. discriminate H. Qed.

Lemma refa248_not4120 : ~ @Equation4120 Fin3 refa248_inst.
Proof. unfold Equation4120. intro H. specialize (H F3_1 F3_0). unfold magma_op, refa248_inst, refa248_op in H. discriminate H. Qed.

Lemma refa248_not4121 : ~ @Equation4121 Fin3 refa248_inst.
Proof. unfold Equation4121. intro H. specialize (H F3_1 F3_0). unfold magma_op, refa248_inst, refa248_op in H. discriminate H. Qed.

Lemma refa248_not4127 : ~ @Equation4127 Fin3 refa248_inst.
Proof. unfold Equation4127. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa248_inst, refa248_op in H. discriminate H. Qed.

Lemma refa248_not4128 : ~ @Equation4128 Fin3 refa248_inst.
Proof. unfold Equation4128. intro H. specialize (H F3_1 F3_0). unfold magma_op, refa248_inst, refa248_op in H. discriminate H. Qed.

Lemma refa248_not4130 : ~ @Equation4130 Fin3 refa248_inst.
Proof. unfold Equation4130. intro H. specialize (H F3_1 F3_0). unfold magma_op, refa248_inst, refa248_op in H. discriminate H. Qed.

Lemma refa248_not4268 : ~ @Equation4268 Fin3 refa248_inst.
Proof. unfold Equation4268. intro H. specialize (H F3_1 F3_0). unfold magma_op, refa248_inst, refa248_op in H. discriminate H. Qed.

Lemma refa248_not4283 : ~ @Equation4283 Fin3 refa248_inst.
Proof. unfold Equation4283. intro H. specialize (H F3_1 F3_0). unfold magma_op, refa248_inst, refa248_op in H. discriminate H. Qed.

Lemma refa248_not4284 : ~ @Equation4284 Fin3 refa248_inst.
Proof. unfold Equation4284. intro H. specialize (H F3_1 F3_0). unfold magma_op, refa248_inst, refa248_op in H. discriminate H. Qed.

Lemma refa248_not4314 : ~ @Equation4314 Fin3 refa248_inst.
Proof. unfold Equation4314. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa248_inst, refa248_op in H. discriminate H. Qed.

Lemma refa248_not4380 : ~ @Equation4380 Fin3 refa248_inst.
Proof. unfold Equation4380. intro H. specialize (H F3_1). unfold magma_op, refa248_inst, refa248_op in H. discriminate H. Qed.

Lemma refa248_not4584 : ~ @Equation4584 Fin3 refa248_inst.
Proof. unfold Equation4584. intro H. specialize (H F3_1 F3_0). unfold magma_op, refa248_inst, refa248_op in H. discriminate H. Qed.

Lemma refa248_not4585 : ~ @Equation4585 Fin3 refa248_inst.
Proof. unfold Equation4585. intro H. specialize (H F3_1 F3_0). unfold magma_op, refa248_inst, refa248_op in H. discriminate H. Qed.

Lemma refa248_not4598 : ~ @Equation4598 Fin3 refa248_inst.
Proof. unfold Equation4598. intro H. specialize (H F3_1 F3_0). unfold magma_op, refa248_inst, refa248_op in H. discriminate H. Qed.

Lemma refa248_not4599 : ~ @Equation4599 Fin3 refa248_inst.
Proof. unfold Equation4599. intro H. specialize (H F3_1 F3_0). unfold magma_op, refa248_inst, refa248_op in H. discriminate H. Qed.

Lemma refa248_not4629 : ~ @Equation4629 Fin3 refa248_inst.
Proof. unfold Equation4629. intro H. specialize (H F3_1 F3_0). unfold magma_op, refa248_inst, refa248_op in H. discriminate H. Qed.

(** ---- refa249 (Fin3) ---- *)

Definition refa249_op (x y : Fin3) : Fin3 :=
  match x, y with
  | F3_0, F3_0 => F3_0 | F3_0, F3_1 => F3_1 | F3_0, F3_2 => F3_2
  | F3_1, F3_0 => F3_1 | F3_1, F3_1 => F3_0 | F3_1, F3_2 => F3_0
  | F3_2, F3_0 => F3_1 | F3_2, F3_1 => F3_0 | F3_2, F3_2 => F3_0
  end.

#[local] Instance refa249_inst : Magma Fin3 := {| magma_op := refa249_op |}.

Lemma refa249_sat2592 : @Equation2592 Fin3 refa249_inst.
Proof. unfold Equation2592, magma_op, refa249_inst, refa249_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa249_sat2808 : @Equation2808 Fin3 refa249_inst.
Proof. unfold Equation2808, magma_op, refa249_inst, refa249_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa249_sat2964 : @Equation2964 Fin3 refa249_inst.
Proof. unfold Equation2964, magma_op, refa249_inst, refa249_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa249_sat2998 : @Equation2998 Fin3 refa249_inst.
Proof. unfold Equation2998, magma_op, refa249_inst, refa249_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa249_sat3214 : @Equation3214 Fin3 refa249_inst.
Proof. unfold Equation3214, magma_op, refa249_inst, refa249_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa249_not411 : ~ @Equation411 Fin3 refa249_inst.
Proof. unfold Equation411. intro H. specialize (H F3_2). unfold magma_op, refa249_inst, refa249_op in H. discriminate H. Qed.

Lemma refa249_not614 : ~ @Equation614 Fin3 refa249_inst.
Proof. unfold Equation614. intro H. specialize (H F3_2). unfold magma_op, refa249_inst, refa249_op in H. discriminate H. Qed.

Lemma refa249_not817 : ~ @Equation817 Fin3 refa249_inst.
Proof. unfold Equation817. intro H. specialize (H F3_2). unfold magma_op, refa249_inst, refa249_op in H. discriminate H. Qed.

Lemma refa249_not1020 : ~ @Equation1020 Fin3 refa249_inst.
Proof. unfold Equation1020. intro H. specialize (H F3_2). unfold magma_op, refa249_inst, refa249_op in H. discriminate H. Qed.

Lemma refa249_not1223 : ~ @Equation1223 Fin3 refa249_inst.
Proof. unfold Equation1223. intro H. specialize (H F3_2). unfold magma_op, refa249_inst, refa249_op in H. discriminate H. Qed.

Lemma refa249_not1426 : ~ @Equation1426 Fin3 refa249_inst.
Proof. unfold Equation1426. intro H. specialize (H F3_2). unfold magma_op, refa249_inst, refa249_op in H. discriminate H. Qed.

Lemma refa249_not1632 : ~ @Equation1632 Fin3 refa249_inst.
Proof. unfold Equation1632. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa249_inst, refa249_op in H. discriminate H. Qed.

Lemma refa249_not1635 : ~ @Equation1635 Fin3 refa249_inst.
Proof. unfold Equation1635. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa249_inst, refa249_op in H. discriminate H. Qed.

Lemma refa249_not1645 : ~ @Equation1645 Fin3 refa249_inst.
Proof. unfold Equation1645. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa249_inst, refa249_op in H. discriminate H. Qed.

Lemma refa249_not1647 : ~ @Equation1647 Fin3 refa249_inst.
Proof. unfold Equation1647. intro H. specialize (H F3_2 F3_0). unfold magma_op, refa249_inst, refa249_op in H. discriminate H. Qed.

Lemma refa249_not1654 : ~ @Equation1654 Fin3 refa249_inst.
Proof. unfold Equation1654. intro H. specialize (H F3_2 F3_0). unfold magma_op, refa249_inst, refa249_op in H. discriminate H. Qed.

Lemma refa249_not1682 : ~ @Equation1682 Fin3 refa249_inst.
Proof. unfold Equation1682. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa249_inst, refa249_op in H. discriminate H. Qed.

Lemma refa249_not1684 : ~ @Equation1684 Fin3 refa249_inst.
Proof. unfold Equation1684. intro H. specialize (H F3_2 F3_0). unfold magma_op, refa249_inst, refa249_op in H. discriminate H. Qed.

Lemma refa249_not1691 : ~ @Equation1691 Fin3 refa249_inst.
Proof. unfold Equation1691. intro H. specialize (H F3_2 F3_0). unfold magma_op, refa249_inst, refa249_op in H. discriminate H. Qed.

Lemma refa249_not1722 : ~ @Equation1722 Fin3 refa249_inst.
Proof. unfold Equation1722. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa249_inst, refa249_op in H. discriminate H. Qed.

Lemma refa249_not1832 : ~ @Equation1832 Fin3 refa249_inst.
Proof. unfold Equation1832. intro H. specialize (H F3_2). unfold magma_op, refa249_inst, refa249_op in H. discriminate H. Qed.

Lemma refa249_not2035 : ~ @Equation2035 Fin3 refa249_inst.
Proof. unfold Equation2035. intro H. specialize (H F3_2). unfold magma_op, refa249_inst, refa249_op in H. discriminate H. Qed.

Lemma refa249_not2244 : ~ @Equation2244 Fin3 refa249_inst.
Proof. unfold Equation2244. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa249_inst, refa249_op in H. discriminate H. Qed.

Lemma refa249_not2254 : ~ @Equation2254 Fin3 refa249_inst.
Proof. unfold Equation2254. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa249_inst, refa249_op in H. discriminate H. Qed.

Lemma refa249_not2291 : ~ @Equation2291 Fin3 refa249_inst.
Proof. unfold Equation2291. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa249_inst, refa249_op in H. discriminate H. Qed.

Lemma refa249_not2444 : ~ @Equation2444 Fin3 refa249_inst.
Proof. unfold Equation2444. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa249_inst, refa249_op in H. discriminate H. Qed.

Lemma refa249_not2447 : ~ @Equation2447 Fin3 refa249_inst.
Proof. unfold Equation2447. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa249_inst, refa249_op in H. discriminate H. Qed.

Lemma refa249_not2457 : ~ @Equation2457 Fin3 refa249_inst.
Proof. unfold Equation2457. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa249_inst, refa249_op in H. discriminate H. Qed.

Lemma refa249_not2470 : ~ @Equation2470 Fin3 refa249_inst.
Proof. unfold Equation2470. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa249_inst, refa249_op in H. discriminate H. Qed.

Lemma refa249_not2534 : ~ @Equation2534 Fin3 refa249_inst.
Proof. unfold Equation2534. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa249_inst, refa249_op in H. discriminate H. Qed.

Lemma refa249_not2541 : ~ @Equation2541 Fin3 refa249_inst.
Proof. unfold Equation2541. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa249_inst, refa249_op in H. discriminate H. Qed.

Lemma refa249_not2647 : ~ @Equation2647 Fin3 refa249_inst.
Proof. unfold Equation2647. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa249_inst, refa249_op in H. discriminate H. Qed.

Lemma refa249_not2650 : ~ @Equation2650 Fin3 refa249_inst.
Proof. unfold Equation2650. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa249_inst, refa249_op in H. discriminate H. Qed.

Lemma refa249_not2660 : ~ @Equation2660 Fin3 refa249_inst.
Proof. unfold Equation2660. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa249_inst, refa249_op in H. discriminate H. Qed.

Lemma refa249_not2710 : ~ @Equation2710 Fin3 refa249_inst.
Proof. unfold Equation2710. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa249_inst, refa249_op in H. discriminate H. Qed.

Lemma refa249_not2853 : ~ @Equation2853 Fin3 refa249_inst.
Proof. unfold Equation2853. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa249_inst, refa249_op in H. discriminate H. Qed.

Lemma refa249_not2863 : ~ @Equation2863 Fin3 refa249_inst.
Proof. unfold Equation2863. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa249_inst, refa249_op in H. discriminate H. Qed.

Lemma refa249_not2940 : ~ @Equation2940 Fin3 refa249_inst.
Proof. unfold Equation2940. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa249_inst, refa249_op in H. discriminate H. Qed.

Lemma refa249_not2947 : ~ @Equation2947 Fin3 refa249_inst.
Proof. unfold Equation2947. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa249_inst, refa249_op in H. discriminate H. Qed.

Lemma refa249_not3056 : ~ @Equation3056 Fin3 refa249_inst.
Proof. unfold Equation3056. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa249_inst, refa249_op in H. discriminate H. Qed.

Lemma refa249_not3066 : ~ @Equation3066 Fin3 refa249_inst.
Proof. unfold Equation3066. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa249_inst, refa249_op in H. discriminate H. Qed.

Lemma refa249_not3079 : ~ @Equation3079 Fin3 refa249_inst.
Proof. unfold Equation3079. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa249_inst, refa249_op in H. discriminate H. Qed.

Lemma refa249_not3116 : ~ @Equation3116 Fin3 refa249_inst.
Proof. unfold Equation3116. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa249_inst, refa249_op in H. discriminate H. Qed.

Lemma refa249_not3143 : ~ @Equation3143 Fin3 refa249_inst.
Proof. unfold Equation3143. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa249_inst, refa249_op in H. discriminate H. Qed.

Lemma refa249_not3150 : ~ @Equation3150 Fin3 refa249_inst.
Proof. unfold Equation3150. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa249_inst, refa249_op in H. discriminate H. Qed.

Lemma refa249_not3319 : ~ @Equation3319 Fin3 refa249_inst.
Proof. unfold Equation3319. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa249_inst, refa249_op in H. discriminate H. Qed.

Lemma refa249_not3346 : ~ @Equation3346 Fin3 refa249_inst.
Proof. unfold Equation3346. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa249_inst, refa249_op in H. discriminate H. Qed.

Lemma refa249_not3353 : ~ @Equation3353 Fin3 refa249_inst.
Proof. unfold Equation3353. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa249_inst, refa249_op in H. discriminate H. Qed.

Lemma refa249_not3549 : ~ @Equation3549 Fin3 refa249_inst.
Proof. unfold Equation3549. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa249_inst, refa249_op in H. discriminate H. Qed.

Lemma refa249_not3556 : ~ @Equation3556 Fin3 refa249_inst.
Proof. unfold Equation3556. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa249_inst, refa249_op in H. discriminate H. Qed.

Lemma refa249_not3725 : ~ @Equation3725 Fin3 refa249_inst.
Proof. unfold Equation3725. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa249_inst, refa249_op in H. discriminate H. Qed.

Lemma refa249_not3752 : ~ @Equation3752 Fin3 refa249_inst.
Proof. unfold Equation3752. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa249_inst, refa249_op in H. discriminate H. Qed.

Lemma refa249_not3924 : ~ @Equation3924 Fin3 refa249_inst.
Proof. unfold Equation3924. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa249_inst, refa249_op in H. discriminate H. Qed.

Lemma refa249_not3951 : ~ @Equation3951 Fin3 refa249_inst.
Proof. unfold Equation3951. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa249_inst, refa249_op in H. discriminate H. Qed.

Lemma refa249_not4275 : ~ @Equation4275 Fin3 refa249_inst.
Proof. unfold Equation4275. intro H. specialize (H F3_2 F3_0). unfold magma_op, refa249_inst, refa249_op in H. discriminate H. Qed.

Lemma refa249_not4380 : ~ @Equation4380 Fin3 refa249_inst.
Proof. unfold Equation4380. intro H. specialize (H F3_2). unfold magma_op, refa249_inst, refa249_op in H. discriminate H. Qed.

Lemma refa249_not4588 : ~ @Equation4588 Fin3 refa249_inst.
Proof. unfold Equation4588. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa249_inst, refa249_op in H. discriminate H. Qed.

Lemma refa249_not4605 : ~ @Equation4605 Fin3 refa249_inst.
Proof. unfold Equation4605. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa249_inst, refa249_op in H. discriminate H. Qed.

(** ---- refa25 (Fin8) ---- *)

Definition refa25_op (x y : Fin8) : Fin8 :=
  match x, y with
  | F8_0, F8_0 => F8_1 | F8_0, F8_1 => F8_2 | F8_0, F8_2 => F8_5 | F8_0, F8_3 => F8_6 | F8_0, F8_4 => F8_4 | F8_0, F8_5 => F8_3 | F8_0, F8_6 => F8_7 | F8_0, F8_7 => F8_0
  | F8_1, F8_0 => F8_4 | F8_1, F8_1 => F8_3 | F8_1, F8_2 => F8_0 | F8_1, F8_3 => F8_7 | F8_1, F8_4 => F8_1 | F8_1, F8_5 => F8_2 | F8_1, F8_6 => F8_6 | F8_1, F8_7 => F8_5
  | F8_2, F8_0 => F8_2 | F8_2, F8_1 => F8_1 | F8_2, F8_2 => F8_7 | F8_2, F8_3 => F8_0 | F8_2, F8_4 => F8_3 | F8_2, F8_5 => F8_4 | F8_2, F8_6 => F8_5 | F8_2, F8_7 => F8_6
  | F8_3, F8_0 => F8_0 | F8_3, F8_1 => F8_6 | F8_3, F8_2 => F8_4 | F8_3, F8_3 => F8_2 | F8_3, F8_4 => F8_5 | F8_3, F8_5 => F8_7 | F8_3, F8_6 => F8_3 | F8_3, F8_7 => F8_1
  | F8_4, F8_0 => F8_7 | F8_4, F8_1 => F8_5 | F8_4, F8_2 => F8_2 | F8_4, F8_3 => F8_4 | F8_4, F8_4 => F8_6 | F8_4, F8_5 => F8_0 | F8_4, F8_6 => F8_1 | F8_4, F8_7 => F8_3
  | F8_5, F8_0 => F8_6 | F8_5, F8_1 => F8_0 | F8_5, F8_2 => F8_3 | F8_5, F8_3 => F8_1 | F8_5, F8_4 => F8_7 | F8_5, F8_5 => F8_5 | F8_5, F8_6 => F8_4 | F8_5, F8_7 => F8_2
  | F8_6, F8_0 => F8_3 | F8_6, F8_1 => F8_4 | F8_6, F8_2 => F8_6 | F8_6, F8_3 => F8_5 | F8_6, F8_4 => F8_2 | F8_6, F8_5 => F8_1 | F8_6, F8_6 => F8_0 | F8_6, F8_7 => F8_7
  | F8_7, F8_0 => F8_5 | F8_7, F8_1 => F8_7 | F8_7, F8_2 => F8_1 | F8_7, F8_3 => F8_3 | F8_7, F8_4 => F8_0 | F8_7, F8_5 => F8_6 | F8_7, F8_6 => F8_2 | F8_7, F8_7 => F8_4
  end.

#[local] Instance refa25_inst : Magma Fin8 := {| magma_op := refa25_op |}.

Lemma refa25_sat1587 : @Equation1587 Fin8 refa25_inst.
Proof. unfold Equation1587, magma_op, refa25_inst, refa25_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa25_not411 : ~ @Equation411 Fin8 refa25_inst.
Proof. unfold Equation411. intro H. specialize (H F8_0). unfold magma_op, refa25_inst, refa25_op in H. discriminate H. Qed.

Lemma refa25_not614 : ~ @Equation614 Fin8 refa25_inst.
Proof. unfold Equation614. intro H. specialize (H F8_0). unfold magma_op, refa25_inst, refa25_op in H. discriminate H. Qed.

Lemma refa25_not817 : ~ @Equation817 Fin8 refa25_inst.
Proof. unfold Equation817. intro H. specialize (H F8_0). unfold magma_op, refa25_inst, refa25_op in H. discriminate H. Qed.

Lemma refa25_not1020 : ~ @Equation1020 Fin8 refa25_inst.
Proof. unfold Equation1020. intro H. specialize (H F8_0). unfold magma_op, refa25_inst, refa25_op in H. discriminate H. Qed.

Lemma refa25_not1229 : ~ @Equation1229 Fin8 refa25_inst.
Proof. unfold Equation1229. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa25_inst, refa25_op in H. discriminate H. Qed.

Lemma refa25_not1241 : ~ @Equation1241 Fin8 refa25_inst.
Proof. unfold Equation1241. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa25_inst, refa25_op in H. discriminate H. Qed.

Lemma refa25_not1248 : ~ @Equation1248 Fin8 refa25_inst.
Proof. unfold Equation1248. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa25_inst, refa25_op in H. discriminate H. Qed.

Lemma refa25_not1252 : ~ @Equation1252 Fin8 refa25_inst.
Proof. unfold Equation1252. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa25_inst, refa25_op in H. discriminate H. Qed.

Lemma refa25_not1276 : ~ @Equation1276 Fin8 refa25_inst.
Proof. unfold Equation1276. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa25_inst, refa25_op in H. discriminate H. Qed.

Lemma refa25_not1278 : ~ @Equation1278 Fin8 refa25_inst.
Proof. unfold Equation1278. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa25_inst, refa25_op in H. discriminate H. Qed.

Lemma refa25_not1429 : ~ @Equation1429 Fin8 refa25_inst.
Proof. unfold Equation1429. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa25_inst, refa25_op in H. discriminate H. Qed.

Lemma refa25_not1434 : ~ @Equation1434 Fin8 refa25_inst.
Proof. unfold Equation1434. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa25_inst, refa25_op in H. discriminate H. Qed.

Lemma refa25_not1488 : ~ @Equation1488 Fin8 refa25_inst.
Proof. unfold Equation1488. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa25_inst, refa25_op in H. discriminate H. Qed.

Lemma refa25_not1515 : ~ @Equation1515 Fin8 refa25_inst.
Proof. unfold Equation1515. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa25_inst, refa25_op in H. discriminate H. Qed.

Lemma refa25_not1519 : ~ @Equation1519 Fin8 refa25_inst.
Proof. unfold Equation1519. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa25_inst, refa25_op in H. discriminate H. Qed.

Lemma refa25_not1629 : ~ @Equation1629 Fin8 refa25_inst.
Proof. unfold Equation1629. intro H. specialize (H F8_0). unfold magma_op, refa25_inst, refa25_op in H. discriminate H. Qed.

Lemma refa25_not1832 : ~ @Equation1832 Fin8 refa25_inst.
Proof. unfold Equation1832. intro H. specialize (H F8_0). unfold magma_op, refa25_inst, refa25_op in H. discriminate H. Qed.

Lemma refa25_not2035 : ~ @Equation2035 Fin8 refa25_inst.
Proof. unfold Equation2035. intro H. specialize (H F8_0). unfold magma_op, refa25_inst, refa25_op in H. discriminate H. Qed.

Lemma refa25_not2238 : ~ @Equation2238 Fin8 refa25_inst.
Proof. unfold Equation2238. intro H. specialize (H F8_0). unfold magma_op, refa25_inst, refa25_op in H. discriminate H. Qed.

Lemma refa25_not2441 : ~ @Equation2441 Fin8 refa25_inst.
Proof. unfold Equation2441. intro H. specialize (H F8_0). unfold magma_op, refa25_inst, refa25_op in H. discriminate H. Qed.

Lemma refa25_not2647 : ~ @Equation2647 Fin8 refa25_inst.
Proof. unfold Equation2647. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa25_inst, refa25_op in H. discriminate H. Qed.

Lemma refa25_not2650 : ~ @Equation2650 Fin8 refa25_inst.
Proof. unfold Equation2650. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa25_inst, refa25_op in H. discriminate H. Qed.

Lemma refa25_not2652 : ~ @Equation2652 Fin8 refa25_inst.
Proof. unfold Equation2652. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa25_inst, refa25_op in H. discriminate H. Qed.

Lemma refa25_not2660 : ~ @Equation2660 Fin8 refa25_inst.
Proof. unfold Equation2660. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa25_inst, refa25_op in H. discriminate H. Qed.

Lemma refa25_not2662 : ~ @Equation2662 Fin8 refa25_inst.
Proof. unfold Equation2662. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa25_inst, refa25_op in H. discriminate H. Qed.

Lemma refa25_not2699 : ~ @Equation2699 Fin8 refa25_inst.
Proof. unfold Equation2699. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa25_inst, refa25_op in H. discriminate H. Qed.

Lemma refa25_not2710 : ~ @Equation2710 Fin8 refa25_inst.
Proof. unfold Equation2710. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa25_inst, refa25_op in H. discriminate H. Qed.

Lemma refa25_not2746 : ~ @Equation2746 Fin8 refa25_inst.
Proof. unfold Equation2746. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa25_inst, refa25_op in H. discriminate H. Qed.

Lemma refa25_not2847 : ~ @Equation2847 Fin8 refa25_inst.
Proof. unfold Equation2847. intro H. specialize (H F8_0). unfold magma_op, refa25_inst, refa25_op in H. discriminate H. Qed.

Lemma refa25_not3050 : ~ @Equation3050 Fin8 refa25_inst.
Proof. unfold Equation3050. intro H. specialize (H F8_0). unfold magma_op, refa25_inst, refa25_op in H. discriminate H. Qed.

Lemma refa25_not3253 : ~ @Equation3253 Fin8 refa25_inst.
Proof. unfold Equation3253. intro H. specialize (H F8_0). unfold magma_op, refa25_inst, refa25_op in H. discriminate H. Qed.

Lemma refa25_not3456 : ~ @Equation3456 Fin8 refa25_inst.
Proof. unfold Equation3456. intro H. specialize (H F8_0). unfold magma_op, refa25_inst, refa25_op in H. discriminate H. Qed.

Lemma refa25_not3659 : ~ @Equation3659 Fin8 refa25_inst.
Proof. unfold Equation3659. intro H. specialize (H F8_0). unfold magma_op, refa25_inst, refa25_op in H. discriminate H. Qed.

Lemma refa25_not3862 : ~ @Equation3862 Fin8 refa25_inst.
Proof. unfold Equation3862. intro H. specialize (H F8_0). unfold magma_op, refa25_inst, refa25_op in H. discriminate H. Qed.

Lemma refa25_not4065 : ~ @Equation4065 Fin8 refa25_inst.
Proof. unfold Equation4065. intro H. specialize (H F8_0). unfold magma_op, refa25_inst, refa25_op in H. discriminate H. Qed.

Lemma refa25_not4270 : ~ @Equation4270 Fin8 refa25_inst.
Proof. unfold Equation4270. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa25_inst, refa25_op in H. discriminate H. Qed.

Lemma refa25_not4273 : ~ @Equation4273 Fin8 refa25_inst.
Proof. unfold Equation4273. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa25_inst, refa25_op in H. discriminate H. Qed.

Lemma refa25_not4275 : ~ @Equation4275 Fin8 refa25_inst.
Proof. unfold Equation4275. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa25_inst, refa25_op in H. discriminate H. Qed.

Lemma refa25_not4283 : ~ @Equation4283 Fin8 refa25_inst.
Proof. unfold Equation4283. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa25_inst, refa25_op in H. discriminate H. Qed.

Lemma refa25_not4290 : ~ @Equation4290 Fin8 refa25_inst.
Proof. unfold Equation4290. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa25_inst, refa25_op in H. discriminate H. Qed.

Lemma refa25_not4320 : ~ @Equation4320 Fin8 refa25_inst.
Proof. unfold Equation4320. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa25_inst, refa25_op in H. discriminate H. Qed.

Lemma refa25_not4380 : ~ @Equation4380 Fin8 refa25_inst.
Proof. unfold Equation4380. intro H. specialize (H F8_0). unfold magma_op, refa25_inst, refa25_op in H. discriminate H. Qed.

Lemma refa25_not4585 : ~ @Equation4585 Fin8 refa25_inst.
Proof. unfold Equation4585. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa25_inst, refa25_op in H. discriminate H. Qed.

Lemma refa25_not4588 : ~ @Equation4588 Fin8 refa25_inst.
Proof. unfold Equation4588. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa25_inst, refa25_op in H. discriminate H. Qed.

Lemma refa25_not4590 : ~ @Equation4590 Fin8 refa25_inst.
Proof. unfold Equation4590. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa25_inst, refa25_op in H. discriminate H. Qed.

Lemma refa25_not4598 : ~ @Equation4598 Fin8 refa25_inst.
Proof. unfold Equation4598. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa25_inst, refa25_op in H. discriminate H. Qed.

Lemma refa25_not4605 : ~ @Equation4605 Fin8 refa25_inst.
Proof. unfold Equation4605. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa25_inst, refa25_op in H. discriminate H. Qed.

Lemma refa25_not4635 : ~ @Equation4635 Fin8 refa25_inst.
Proof. unfold Equation4635. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa25_inst, refa25_op in H. discriminate H. Qed.

(** ---- refa250 (Fin3) ---- *)

Definition refa250_op (x y : Fin3) : Fin3 :=
  match x, y with
  | F3_0, F3_0 => F3_0 | F3_0, F3_1 => F3_0 | F3_0, F3_2 => F3_1
  | F3_1, F3_0 => F3_0 | F3_1, F3_1 => F3_0 | F3_1, F3_2 => F3_1
  | F3_2, F3_0 => F3_1 | F3_2, F3_1 => F3_1 | F3_2, F3_2 => F3_2
  end.

#[local] Instance refa250_inst : Magma Fin3 := {| magma_op := refa250_op |}.

Lemma refa250_sat387 : @Equation387 Fin3 refa250_inst.
Proof. unfold Equation387, magma_op, refa250_inst, refa250_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa250_not3306 : ~ @Equation3306 Fin3 refa250_inst.
Proof. unfold Equation3306. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa250_inst, refa250_op in H. discriminate H. Qed.

Lemma refa250_not3308 : ~ @Equation3308 Fin3 refa250_inst.
Proof. unfold Equation3308. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa250_inst, refa250_op in H. discriminate H. Qed.

Lemma refa250_not3343 : ~ @Equation3343 Fin3 refa250_inst.
Proof. unfold Equation3343. intro H. specialize (H F3_2 F3_0). unfold magma_op, refa250_inst, refa250_op in H. discriminate H. Qed.

Lemma refa250_not3345 : ~ @Equation3345 Fin3 refa250_inst.
Proof. unfold Equation3345. intro H. specialize (H F3_2 F3_0). unfold magma_op, refa250_inst, refa250_op in H. discriminate H. Qed.

Lemma refa250_not3346 : ~ @Equation3346 Fin3 refa250_inst.
Proof. unfold Equation3346. intro H. specialize (H F3_2 F3_0). unfold magma_op, refa250_inst, refa250_op in H. discriminate H. Qed.

Lemma refa250_not3352 : ~ @Equation3352 Fin3 refa250_inst.
Proof. unfold Equation3352. intro H. specialize (H F3_2 F3_0). unfold magma_op, refa250_inst, refa250_op in H. discriminate H. Qed.

Lemma refa250_not3353 : ~ @Equation3353 Fin3 refa250_inst.
Proof. unfold Equation3353. intro H. specialize (H F3_2 F3_0). unfold magma_op, refa250_inst, refa250_op in H. discriminate H. Qed.

Lemma refa250_not3355 : ~ @Equation3355 Fin3 refa250_inst.
Proof. unfold Equation3355. intro H. specialize (H F3_2 F3_0). unfold magma_op, refa250_inst, refa250_op in H. discriminate H. Qed.

Lemma refa250_not3511 : ~ @Equation3511 Fin3 refa250_inst.
Proof. unfold Equation3511. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa250_inst, refa250_op in H. discriminate H. Qed.

Lemma refa250_not3518 : ~ @Equation3518 Fin3 refa250_inst.
Proof. unfold Equation3518. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa250_inst, refa250_op in H. discriminate H. Qed.

Lemma refa250_not3546 : ~ @Equation3546 Fin3 refa250_inst.
Proof. unfold Equation3546. intro H. specialize (H F3_2 F3_0). unfold magma_op, refa250_inst, refa250_op in H. discriminate H. Qed.

Lemma refa250_not3548 : ~ @Equation3548 Fin3 refa250_inst.
Proof. unfold Equation3548. intro H. specialize (H F3_2 F3_0). unfold magma_op, refa250_inst, refa250_op in H. discriminate H. Qed.

Lemma refa250_not3549 : ~ @Equation3549 Fin3 refa250_inst.
Proof. unfold Equation3549. intro H. specialize (H F3_2 F3_0). unfold magma_op, refa250_inst, refa250_op in H. discriminate H. Qed.

Lemma refa250_not3555 : ~ @Equation3555 Fin3 refa250_inst.
Proof. unfold Equation3555. intro H. specialize (H F3_2 F3_0). unfold magma_op, refa250_inst, refa250_op in H. discriminate H. Qed.

Lemma refa250_not3556 : ~ @Equation3556 Fin3 refa250_inst.
Proof. unfold Equation3556. intro H. specialize (H F3_2 F3_0). unfold magma_op, refa250_inst, refa250_op in H. discriminate H. Qed.

Lemma refa250_not3558 : ~ @Equation3558 Fin3 refa250_inst.
Proof. unfold Equation3558. intro H. specialize (H F3_2 F3_0). unfold magma_op, refa250_inst, refa250_op in H. discriminate H. Qed.

Lemma refa250_not3722 : ~ @Equation3722 Fin3 refa250_inst.
Proof. unfold Equation3722. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa250_inst, refa250_op in H. discriminate H. Qed.

Lemma refa250_not3724 : ~ @Equation3724 Fin3 refa250_inst.
Proof. unfold Equation3724. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa250_inst, refa250_op in H. discriminate H. Qed.

Lemma refa250_not3748 : ~ @Equation3748 Fin3 refa250_inst.
Proof. unfold Equation3748. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa250_inst, refa250_op in H. discriminate H. Qed.

Lemma refa250_not3749 : ~ @Equation3749 Fin3 refa250_inst.
Proof. unfold Equation3749. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa250_inst, refa250_op in H. discriminate H. Qed.

Lemma refa250_not3752 : ~ @Equation3752 Fin3 refa250_inst.
Proof. unfold Equation3752. intro H. specialize (H F3_2 F3_0). unfold magma_op, refa250_inst, refa250_op in H. discriminate H. Qed.

Lemma refa250_not3759 : ~ @Equation3759 Fin3 refa250_inst.
Proof. unfold Equation3759. intro H. specialize (H F3_2 F3_0). unfold magma_op, refa250_inst, refa250_op in H. discriminate H. Qed.

Lemma refa250_not3761 : ~ @Equation3761 Fin3 refa250_inst.
Proof. unfold Equation3761. intro H. specialize (H F3_2 F3_0). unfold magma_op, refa250_inst, refa250_op in H. discriminate H. Qed.

Lemma refa250_not3917 : ~ @Equation3917 Fin3 refa250_inst.
Proof. unfold Equation3917. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa250_inst, refa250_op in H. discriminate H. Qed.

Lemma refa250_not3924 : ~ @Equation3924 Fin3 refa250_inst.
Proof. unfold Equation3924. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa250_inst, refa250_op in H. discriminate H. Qed.

Lemma refa250_not3951 : ~ @Equation3951 Fin3 refa250_inst.
Proof. unfold Equation3951. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa250_inst, refa250_op in H. discriminate H. Qed.

Lemma refa250_not3952 : ~ @Equation3952 Fin3 refa250_inst.
Proof. unfold Equation3952. intro H. specialize (H F3_2 F3_0). unfold magma_op, refa250_inst, refa250_op in H. discriminate H. Qed.

Lemma refa250_not3954 : ~ @Equation3954 Fin3 refa250_inst.
Proof. unfold Equation3954. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa250_inst, refa250_op in H. discriminate H. Qed.

Lemma refa250_not3955 : ~ @Equation3955 Fin3 refa250_inst.
Proof. unfold Equation3955. intro H. specialize (H F3_2 F3_0). unfold magma_op, refa250_inst, refa250_op in H. discriminate H. Qed.

Lemma refa250_not3961 : ~ @Equation3961 Fin3 refa250_inst.
Proof. unfold Equation3961. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa250_inst, refa250_op in H. discriminate H. Qed.

Lemma refa250_not3962 : ~ @Equation3962 Fin3 refa250_inst.
Proof. unfold Equation3962. intro H. specialize (H F3_2 F3_0). unfold magma_op, refa250_inst, refa250_op in H. discriminate H. Qed.

Lemma refa250_not4127 : ~ @Equation4127 Fin3 refa250_inst.
Proof. unfold Equation4127. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa250_inst, refa250_op in H. discriminate H. Qed.

Lemma refa250_not4131 : ~ @Equation4131 Fin3 refa250_inst.
Proof. unfold Equation4131. intro H. specialize (H F3_2 F3_0). unfold magma_op, refa250_inst, refa250_op in H. discriminate H. Qed.

Lemma refa250_not4154 : ~ @Equation4154 Fin3 refa250_inst.
Proof. unfold Equation4154. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa250_inst, refa250_op in H. discriminate H. Qed.

Lemma refa250_not4157 : ~ @Equation4157 Fin3 refa250_inst.
Proof. unfold Equation4157. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa250_inst, refa250_op in H. discriminate H. Qed.

Lemma refa250_not4158 : ~ @Equation4158 Fin3 refa250_inst.
Proof. unfold Equation4158. intro H. specialize (H F3_2 F3_0). unfold magma_op, refa250_inst, refa250_op in H. discriminate H. Qed.

Lemma refa250_not4164 : ~ @Equation4164 Fin3 refa250_inst.
Proof. unfold Equation4164. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa250_inst, refa250_op in H. discriminate H. Qed.

Lemma refa250_not4165 : ~ @Equation4165 Fin3 refa250_inst.
Proof. unfold Equation4165. intro H. specialize (H F3_2 F3_0). unfold magma_op, refa250_inst, refa250_op in H. discriminate H. Qed.

Lemma refa250_not4291 : ~ @Equation4291 Fin3 refa250_inst.
Proof. unfold Equation4291. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa250_inst, refa250_op in H. discriminate H. Qed.

Lemma refa250_not4293 : ~ @Equation4293 Fin3 refa250_inst.
Proof. unfold Equation4293. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa250_inst, refa250_op in H. discriminate H. Qed.

Lemma refa250_not4399 : ~ @Equation4399 Fin3 refa250_inst.
Proof. unfold Equation4399. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa250_inst, refa250_op in H. discriminate H. Qed.

Lemma refa250_not4406 : ~ @Equation4406 Fin3 refa250_inst.
Proof. unfold Equation4406. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa250_inst, refa250_op in H. discriminate H. Qed.

Lemma refa250_not4408 : ~ @Equation4408 Fin3 refa250_inst.
Proof. unfold Equation4408. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa250_inst, refa250_op in H. discriminate H. Qed.

Lemma refa250_not4443 : ~ @Equation4443 Fin3 refa250_inst.
Proof. unfold Equation4443. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa250_inst, refa250_op in H. discriminate H. Qed.

Lemma refa250_not4445 : ~ @Equation4445 Fin3 refa250_inst.
Proof. unfold Equation4445. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa250_inst, refa250_op in H. discriminate H. Qed.

Lemma refa250_not4479 : ~ @Equation4479 Fin3 refa250_inst.
Proof. unfold Equation4479. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa250_inst, refa250_op in H. discriminate H. Qed.

Lemma refa250_not4606 : ~ @Equation4606 Fin3 refa250_inst.
Proof. unfold Equation4606. intro H. specialize (H F3_2 F3_0). unfold magma_op, refa250_inst, refa250_op in H. discriminate H. Qed.

Lemma refa250_not4636 : ~ @Equation4636 Fin3 refa250_inst.
Proof. unfold Equation4636. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa250_inst, refa250_op in H. discriminate H. Qed.

Lemma refa250_not4658 : ~ @Equation4658 Fin3 refa250_inst.
Proof. unfold Equation4658. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa250_inst, refa250_op in H. discriminate H. Qed.

(** ---- refa251 (Fin3) ---- *)

Definition refa251_op (x y : Fin3) : Fin3 :=
  match x, y with
  | F3_0, F3_0 => F3_0 | F3_0, F3_1 => F3_1 | F3_0, F3_2 => F3_1
  | F3_1, F3_0 => F3_0 | F3_1, F3_1 => F3_1 | F3_1, F3_2 => F3_2
  | F3_2, F3_0 => F3_0 | F3_2, F3_1 => F3_0 | F3_2, F3_2 => F3_1
  end.

#[local] Instance refa251_inst : Magma Fin3 := {| magma_op := refa251_op |}.

Lemma refa251_sat2669 : @Equation2669 Fin3 refa251_inst.
Proof. unfold Equation2669, magma_op, refa251_inst, refa251_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa251_sat2872 : @Equation2872 Fin3 refa251_inst.
Proof. unfold Equation2872, magma_op, refa251_inst, refa251_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa251_not3253 : ~ @Equation3253 Fin3 refa251_inst.
Proof. unfold Equation3253. intro H. specialize (H F3_2). unfold magma_op, refa251_inst, refa251_op in H. discriminate H. Qed.

Lemma refa251_not4270 : ~ @Equation4270 Fin3 refa251_inst.
Proof. unfold Equation4270. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa251_inst, refa251_op in H. discriminate H. Qed.

(** ---- refa252 (Fin3) ---- *)

Definition refa252_op (x y : Fin3) : Fin3 :=
  match x, y with
  | F3_0, F3_0 => F3_1 | F3_0, F3_1 => F3_0 | F3_0, F3_2 => F3_1
  | F3_1, F3_0 => F3_2 | F3_1, F3_1 => F3_2 | F3_1, F3_2 => F3_1
  | F3_2, F3_0 => F3_2 | F3_2, F3_1 => F3_0 | F3_2, F3_2 => F3_0
  end.

#[local] Instance refa252_inst : Magma Fin3 := {| magma_op := refa252_op |}.

Lemma refa252_sat416 : @Equation416 Fin3 refa252_inst.
Proof. unfold Equation416, magma_op, refa252_inst, refa252_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa252_sat1884 : @Equation1884 Fin3 refa252_inst.
Proof. unfold Equation1884, magma_op, refa252_inst, refa252_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa252_sat1894 : @Equation1894 Fin3 refa252_inst.
Proof. unfold Equation1894, magma_op, refa252_inst, refa252_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa252_sat2093 : @Equation2093 Fin3 refa252_inst.
Proof. unfold Equation2093, magma_op, refa252_inst, refa252_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa252_sat2097 : @Equation2097 Fin3 refa252_inst.
Proof. unfold Equation2097, magma_op, refa252_inst, refa252_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa252_sat3952 : @Equation3952 Fin3 refa252_inst.
Proof. unfold Equation3952, magma_op, refa252_inst, refa252_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa252_not99 : ~ @Equation99 Fin3 refa252_inst.
Proof. unfold Equation99. intro H. specialize (H F3_0). unfold magma_op, refa252_inst, refa252_op in H. discriminate H. Qed.

Lemma refa252_not151 : ~ @Equation151 Fin3 refa252_inst.
Proof. unfold Equation151. intro H. specialize (H F3_0). unfold magma_op, refa252_inst, refa252_op in H. discriminate H. Qed.

Lemma refa252_not413 : ~ @Equation413 Fin3 refa252_inst.
Proof. unfold Equation413. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa252_inst, refa252_op in H. discriminate H. Qed.

Lemma refa252_not419 : ~ @Equation419 Fin3 refa252_inst.
Proof. unfold Equation419. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa252_inst, refa252_op in H. discriminate H. Qed.

Lemma refa252_not426 : ~ @Equation426 Fin3 refa252_inst.
Proof. unfold Equation426. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa252_inst, refa252_op in H. discriminate H. Qed.

Lemma refa252_not429 : ~ @Equation429 Fin3 refa252_inst.
Proof. unfold Equation429. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa252_inst, refa252_op in H. discriminate H. Qed.

Lemma refa252_not436 : ~ @Equation436 Fin3 refa252_inst.
Proof. unfold Equation436. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa252_inst, refa252_op in H. discriminate H. Qed.

Lemma refa252_not466 : ~ @Equation466 Fin3 refa252_inst.
Proof. unfold Equation466. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa252_inst, refa252_op in H. discriminate H. Qed.

Lemma refa252_not473 : ~ @Equation473 Fin3 refa252_inst.
Proof. unfold Equation473. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa252_inst, refa252_op in H. discriminate H. Qed.

Lemma refa252_not476 : ~ @Equation476 Fin3 refa252_inst.
Proof. unfold Equation476. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa252_inst, refa252_op in H. discriminate H. Qed.

Lemma refa252_not503 : ~ @Equation503 Fin3 refa252_inst.
Proof. unfold Equation503. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa252_inst, refa252_op in H. discriminate H. Qed.

Lemma refa252_not513 : ~ @Equation513 Fin3 refa252_inst.
Proof. unfold Equation513. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa252_inst, refa252_op in H. discriminate H. Qed.

Lemma refa252_not1025 : ~ @Equation1025 Fin3 refa252_inst.
Proof. unfold Equation1025. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa252_inst, refa252_op in H. discriminate H. Qed.

Lemma refa252_not1028 : ~ @Equation1028 Fin3 refa252_inst.
Proof. unfold Equation1028. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa252_inst, refa252_op in H. discriminate H. Qed.

Lemma refa252_not1035 : ~ @Equation1035 Fin3 refa252_inst.
Proof. unfold Equation1035. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa252_inst, refa252_op in H. discriminate H. Qed.

Lemma refa252_not1038 : ~ @Equation1038 Fin3 refa252_inst.
Proof. unfold Equation1038. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa252_inst, refa252_op in H. discriminate H. Qed.

Lemma refa252_not1045 : ~ @Equation1045 Fin3 refa252_inst.
Proof. unfold Equation1045. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa252_inst, refa252_op in H. discriminate H. Qed.

Lemma refa252_not1048 : ~ @Equation1048 Fin3 refa252_inst.
Proof. unfold Equation1048. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa252_inst, refa252_op in H. discriminate H. Qed.

Lemma refa252_not1075 : ~ @Equation1075 Fin3 refa252_inst.
Proof. unfold Equation1075. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa252_inst, refa252_op in H. discriminate H. Qed.

Lemma refa252_not1082 : ~ @Equation1082 Fin3 refa252_inst.
Proof. unfold Equation1082. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa252_inst, refa252_op in H. discriminate H. Qed.

Lemma refa252_not1085 : ~ @Equation1085 Fin3 refa252_inst.
Proof. unfold Equation1085. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa252_inst, refa252_op in H. discriminate H. Qed.

Lemma refa252_not1109 : ~ @Equation1109 Fin3 refa252_inst.
Proof. unfold Equation1109. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa252_inst, refa252_op in H. discriminate H. Qed.

Lemma refa252_not1112 : ~ @Equation1112 Fin3 refa252_inst.
Proof. unfold Equation1112. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa252_inst, refa252_op in H. discriminate H. Qed.

Lemma refa252_not1122 : ~ @Equation1122 Fin3 refa252_inst.
Proof. unfold Equation1122. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa252_inst, refa252_op in H. discriminate H. Qed.

Lemma refa252_not1223 : ~ @Equation1223 Fin3 refa252_inst.
Proof. unfold Equation1223. intro H. specialize (H F3_0). unfold magma_op, refa252_inst, refa252_op in H. discriminate H. Qed.

Lemma refa252_not1426 : ~ @Equation1426 Fin3 refa252_inst.
Proof. unfold Equation1426. intro H. specialize (H F3_0). unfold magma_op, refa252_inst, refa252_op in H. discriminate H. Qed.

Lemma refa252_not1629 : ~ @Equation1629 Fin3 refa252_inst.
Proof. unfold Equation1629. intro H. specialize (H F3_0). unfold magma_op, refa252_inst, refa252_op in H. discriminate H. Qed.

Lemma refa252_not1834 : ~ @Equation1834 Fin3 refa252_inst.
Proof. unfold Equation1834. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa252_inst, refa252_op in H. discriminate H. Qed.

Lemma refa252_not1837 : ~ @Equation1837 Fin3 refa252_inst.
Proof. unfold Equation1837. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa252_inst, refa252_op in H. discriminate H. Qed.

Lemma refa252_not1840 : ~ @Equation1840 Fin3 refa252_inst.
Proof. unfold Equation1840. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa252_inst, refa252_op in H. discriminate H. Qed.

Lemma refa252_not1847 : ~ @Equation1847 Fin3 refa252_inst.
Proof. unfold Equation1847. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa252_inst, refa252_op in H. discriminate H. Qed.

Lemma refa252_not1857 : ~ @Equation1857 Fin3 refa252_inst.
Proof. unfold Equation1857. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa252_inst, refa252_op in H. discriminate H. Qed.

Lemma refa252_not1860 : ~ @Equation1860 Fin3 refa252_inst.
Proof. unfold Equation1860. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa252_inst, refa252_op in H. discriminate H. Qed.

Lemma refa252_not1887 : ~ @Equation1887 Fin3 refa252_inst.
Proof. unfold Equation1887. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa252_inst, refa252_op in H. discriminate H. Qed.

Lemma refa252_not1897 : ~ @Equation1897 Fin3 refa252_inst.
Proof. unfold Equation1897. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa252_inst, refa252_op in H. discriminate H. Qed.

Lemma refa252_not1921 : ~ @Equation1921 Fin3 refa252_inst.
Proof. unfold Equation1921. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa252_inst, refa252_op in H. discriminate H. Qed.

Lemma refa252_not1924 : ~ @Equation1924 Fin3 refa252_inst.
Proof. unfold Equation1924. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa252_inst, refa252_op in H. discriminate H. Qed.

Lemma refa252_not1931 : ~ @Equation1931 Fin3 refa252_inst.
Proof. unfold Equation1931. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa252_inst, refa252_op in H. discriminate H. Qed.

Lemma refa252_not2040 : ~ @Equation2040 Fin3 refa252_inst.
Proof. unfold Equation2040. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa252_inst, refa252_op in H. discriminate H. Qed.

Lemma refa252_not2043 : ~ @Equation2043 Fin3 refa252_inst.
Proof. unfold Equation2043. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa252_inst, refa252_op in H. discriminate H. Qed.

Lemma refa252_not2050 : ~ @Equation2050 Fin3 refa252_inst.
Proof. unfold Equation2050. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa252_inst, refa252_op in H. discriminate H. Qed.

Lemma refa252_not2053 : ~ @Equation2053 Fin3 refa252_inst.
Proof. unfold Equation2053. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa252_inst, refa252_op in H. discriminate H. Qed.

Lemma refa252_not2060 : ~ @Equation2060 Fin3 refa252_inst.
Proof. unfold Equation2060. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa252_inst, refa252_op in H. discriminate H. Qed.

Lemma refa252_not2063 : ~ @Equation2063 Fin3 refa252_inst.
Proof. unfold Equation2063. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa252_inst, refa252_op in H. discriminate H. Qed.

Lemma refa252_not2124 : ~ @Equation2124 Fin3 refa252_inst.
Proof. unfold Equation2124. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa252_inst, refa252_op in H. discriminate H. Qed.

Lemma refa252_not2127 : ~ @Equation2127 Fin3 refa252_inst.
Proof. unfold Equation2127. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa252_inst, refa252_op in H. discriminate H. Qed.

Lemma refa252_not2134 : ~ @Equation2134 Fin3 refa252_inst.
Proof. unfold Equation2134. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa252_inst, refa252_op in H. discriminate H. Qed.

Lemma refa252_not3255 : ~ @Equation3255 Fin3 refa252_inst.
Proof. unfold Equation3255. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa252_inst, refa252_op in H. discriminate H. Qed.

Lemma refa252_not3261 : ~ @Equation3261 Fin3 refa252_inst.
Proof. unfold Equation3261. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa252_inst, refa252_op in H. discriminate H. Qed.

Lemma refa252_not3268 : ~ @Equation3268 Fin3 refa252_inst.
Proof. unfold Equation3268. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa252_inst, refa252_op in H. discriminate H. Qed.

Lemma refa252_not3271 : ~ @Equation3271 Fin3 refa252_inst.
Proof. unfold Equation3271. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa252_inst, refa252_op in H. discriminate H. Qed.

Lemma refa252_not3278 : ~ @Equation3278 Fin3 refa252_inst.
Proof. unfold Equation3278. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa252_inst, refa252_op in H. discriminate H. Qed.

Lemma refa252_not3281 : ~ @Equation3281 Fin3 refa252_inst.
Proof. unfold Equation3281. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa252_inst, refa252_op in H. discriminate H. Qed.

Lemma refa252_not3309 : ~ @Equation3309 Fin3 refa252_inst.
Proof. unfold Equation3309. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa252_inst, refa252_op in H. discriminate H. Qed.

Lemma refa252_not3316 : ~ @Equation3316 Fin3 refa252_inst.
Proof. unfold Equation3316. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa252_inst, refa252_op in H. discriminate H. Qed.

Lemma refa252_not3343 : ~ @Equation3343 Fin3 refa252_inst.
Proof. unfold Equation3343. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa252_inst, refa252_op in H. discriminate H. Qed.

Lemma refa252_not3346 : ~ @Equation3346 Fin3 refa252_inst.
Proof. unfold Equation3346. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa252_inst, refa252_op in H. discriminate H. Qed.

Lemma refa252_not3353 : ~ @Equation3353 Fin3 refa252_inst.
Proof. unfold Equation3353. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa252_inst, refa252_op in H. discriminate H. Qed.

Lemma refa252_not3864 : ~ @Equation3864 Fin3 refa252_inst.
Proof. unfold Equation3864. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa252_inst, refa252_op in H. discriminate H. Qed.

Lemma refa252_not3867 : ~ @Equation3867 Fin3 refa252_inst.
Proof. unfold Equation3867. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa252_inst, refa252_op in H. discriminate H. Qed.

Lemma refa252_not3870 : ~ @Equation3870 Fin3 refa252_inst.
Proof. unfold Equation3870. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa252_inst, refa252_op in H. discriminate H. Qed.

Lemma refa252_not3877 : ~ @Equation3877 Fin3 refa252_inst.
Proof. unfold Equation3877. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa252_inst, refa252_op in H. discriminate H. Qed.

Lemma refa252_not3880 : ~ @Equation3880 Fin3 refa252_inst.
Proof. unfold Equation3880. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa252_inst, refa252_op in H. discriminate H. Qed.

Lemma refa252_not3887 : ~ @Equation3887 Fin3 refa252_inst.
Proof. unfold Equation3887. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa252_inst, refa252_op in H. discriminate H. Qed.

Lemma refa252_not3890 : ~ @Equation3890 Fin3 refa252_inst.
Proof. unfold Equation3890. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa252_inst, refa252_op in H. discriminate H. Qed.

Lemma refa252_not3918 : ~ @Equation3918 Fin3 refa252_inst.
Proof. unfold Equation3918. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa252_inst, refa252_op in H. discriminate H. Qed.

Lemma refa252_not3928 : ~ @Equation3928 Fin3 refa252_inst.
Proof. unfold Equation3928. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa252_inst, refa252_op in H. discriminate H. Qed.

Lemma refa252_not3962 : ~ @Equation3962 Fin3 refa252_inst.
Proof. unfold Equation3962. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa252_inst, refa252_op in H. discriminate H. Qed.

Lemma refa252_not4065 : ~ @Equation4065 Fin3 refa252_inst.
Proof. unfold Equation4065. intro H. specialize (H F3_0). unfold magma_op, refa252_inst, refa252_op in H. discriminate H. Qed.

Lemma refa252_not4269 : ~ @Equation4269 Fin3 refa252_inst.
Proof. unfold Equation4269. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa252_inst, refa252_op in H. discriminate H. Qed.

Lemma refa252_not4272 : ~ @Equation4272 Fin3 refa252_inst.
Proof. unfold Equation4272. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa252_inst, refa252_op in H. discriminate H. Qed.

Lemma refa252_not4275 : ~ @Equation4275 Fin3 refa252_inst.
Proof. unfold Equation4275. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa252_inst, refa252_op in H. discriminate H. Qed.

Lemma refa252_not4284 : ~ @Equation4284 Fin3 refa252_inst.
Proof. unfold Equation4284. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa252_inst, refa252_op in H. discriminate H. Qed.

Lemma refa252_not4291 : ~ @Equation4291 Fin3 refa252_inst.
Proof. unfold Equation4291. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa252_inst, refa252_op in H. discriminate H. Qed.

Lemma refa252_not4320 : ~ @Equation4320 Fin3 refa252_inst.
Proof. unfold Equation4320. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa252_inst, refa252_op in H. discriminate H. Qed.

Lemma refa252_not4584 : ~ @Equation4584 Fin3 refa252_inst.
Proof. unfold Equation4584. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa252_inst, refa252_op in H. discriminate H. Qed.

Lemma refa252_not4590 : ~ @Equation4590 Fin3 refa252_inst.
Proof. unfold Equation4590. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa252_inst, refa252_op in H. discriminate H. Qed.

Lemma refa252_not4599 : ~ @Equation4599 Fin3 refa252_inst.
Proof. unfold Equation4599. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa252_inst, refa252_op in H. discriminate H. Qed.

Lemma refa252_not4606 : ~ @Equation4606 Fin3 refa252_inst.
Proof. unfold Equation4606. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa252_inst, refa252_op in H. discriminate H. Qed.

Lemma refa252_not4635 : ~ @Equation4635 Fin3 refa252_inst.
Proof. unfold Equation4635. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa252_inst, refa252_op in H. discriminate H. Qed.

(** ---- refa253 (Fin3) ---- *)

Definition refa253_op (x y : Fin3) : Fin3 :=
  match x, y with
  | F3_0, F3_0 => F3_1 | F3_0, F3_1 => F3_0 | F3_0, F3_2 => F3_0
  | F3_1, F3_0 => F3_0 | F3_1, F3_1 => F3_2 | F3_1, F3_2 => F3_0
  | F3_2, F3_0 => F3_1 | F3_2, F3_1 => F3_1 | F3_2, F3_2 => F3_1
  end.

#[local] Instance refa253_inst : Magma Fin3 := {| magma_op := refa253_op |}.

Lemma refa253_sat1442 : @Equation1442 Fin3 refa253_inst.
Proof. unfold Equation1442, magma_op, refa253_inst, refa253_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa253_not4065 : ~ @Equation4065 Fin3 refa253_inst.
Proof. unfold Equation4065. intro H. specialize (H F3_2). unfold magma_op, refa253_inst, refa253_op in H. discriminate H. Qed.

(** ---- refa254 (Fin3) ---- *)

Definition refa254_op (x y : Fin3) : Fin3 :=
  match x, y with
  | F3_0, F3_0 => F3_1 | F3_0, F3_1 => F3_0 | F3_0, F3_2 => F3_2
  | F3_1, F3_0 => F3_0 | F3_1, F3_1 => F3_2 | F3_1, F3_2 => F3_1
  | F3_2, F3_0 => F3_2 | F3_2, F3_1 => F3_1 | F3_2, F3_2 => F3_0
  end.

#[local] Instance refa254_inst : Magma Fin3 := {| magma_op := refa254_op |}.

Lemma refa254_sat430 : @Equation430 Fin3 refa254_inst.
Proof. unfold Equation430, magma_op, refa254_inst, refa254_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa254_sat522 : @Equation522 Fin3 refa254_inst.
Proof. unfold Equation522, magma_op, refa254_inst, refa254_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa254_sat642 : @Equation642 Fin3 refa254_inst.
Proof. unfold Equation642, magma_op, refa254_inst, refa254_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa254_sat1029 : @Equation1029 Fin3 refa254_inst.
Proof. unfold Equation1029, magma_op, refa254_inst, refa254_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa254_sat1249 : @Equation1249 Fin3 refa254_inst.
Proof. unfold Equation1249, magma_op, refa254_inst, refa254_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa254_sat1525 : @Equation1525 Fin3 refa254_inst.
Proof. unfold Equation1525, magma_op, refa254_inst, refa254_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa254_sat1719 : @Equation1719 Fin3 refa254_inst.
Proof. unfold Equation1719, magma_op, refa254_inst, refa254_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa254_sat1888 : @Equation1888 Fin3 refa254_inst.
Proof. unfold Equation1888, magma_op, refa254_inst, refa254_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa254_sat2044 : @Equation2044 Fin3 refa254_inst.
Proof. unfold Equation2044, magma_op, refa254_inst, refa254_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa254_sat2303 : @Equation2303 Fin3 refa254_inst.
Proof. unfold Equation2303, magma_op, refa254_inst, refa254_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa254_sat2540 : @Equation2540 Fin3 refa254_inst.
Proof. unfold Equation2540, magma_op, refa254_inst, refa254_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa254_sat2875 : @Equation2875 Fin3 refa254_inst.
Proof. unfold Equation2875, magma_op, refa254_inst, refa254_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa254_sat3142 : @Equation3142 Fin3 refa254_inst.
Proof. unfold Equation3142, magma_op, refa254_inst, refa254_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa254_sat3272 : @Equation3272 Fin3 refa254_inst.
Proof. unfold Equation3272, magma_op, refa254_inst, refa254_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa254_sat3484 : @Equation3484 Fin3 refa254_inst.
Proof. unfold Equation3484, magma_op, refa254_inst, refa254_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa254_sat3871 : @Equation3871 Fin3 refa254_inst.
Proof. unfold Equation3871, magma_op, refa254_inst, refa254_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa254_sat4091 : @Equation4091 Fin3 refa254_inst.
Proof. unfold Equation4091, magma_op, refa254_inst, refa254_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa254_not47 : ~ @Equation47 Fin3 refa254_inst.
Proof. unfold Equation47. intro H. specialize (H F3_0). unfold magma_op, refa254_inst, refa254_op in H. discriminate H. Qed.

Lemma refa254_not99 : ~ @Equation99 Fin3 refa254_inst.
Proof. unfold Equation99. intro H. specialize (H F3_0). unfold magma_op, refa254_inst, refa254_op in H. discriminate H. Qed.

Lemma refa254_not151 : ~ @Equation151 Fin3 refa254_inst.
Proof. unfold Equation151. intro H. specialize (H F3_0). unfold magma_op, refa254_inst, refa254_op in H. discriminate H. Qed.

Lemma refa254_not203 : ~ @Equation203 Fin3 refa254_inst.
Proof. unfold Equation203. intro H. specialize (H F3_0). unfold magma_op, refa254_inst, refa254_op in H. discriminate H. Qed.

Lemma refa254_not255 : ~ @Equation255 Fin3 refa254_inst.
Proof. unfold Equation255. intro H. specialize (H F3_0). unfold magma_op, refa254_inst, refa254_op in H. discriminate H. Qed.

Lemma refa254_not307 : ~ @Equation307 Fin3 refa254_inst.
Proof. unfold Equation307. intro H. specialize (H F3_0). unfold magma_op, refa254_inst, refa254_op in H. discriminate H. Qed.

Lemma refa254_not359 : ~ @Equation359 Fin3 refa254_inst.
Proof. unfold Equation359. intro H. specialize (H F3_0). unfold magma_op, refa254_inst, refa254_op in H. discriminate H. Qed.

Lemma refa254_not413 : ~ @Equation413 Fin3 refa254_inst.
Proof. unfold Equation413. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa254_inst, refa254_op in H. discriminate H. Qed.

Lemma refa254_not416 : ~ @Equation416 Fin3 refa254_inst.
Proof. unfold Equation416. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa254_inst, refa254_op in H. discriminate H. Qed.

Lemma refa254_not420 : ~ @Equation420 Fin3 refa254_inst.
Proof. unfold Equation420. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa254_inst, refa254_op in H. discriminate H. Qed.

Lemma refa254_not426 : ~ @Equation426 Fin3 refa254_inst.
Proof. unfold Equation426. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa254_inst, refa254_op in H. discriminate H. Qed.

Lemma refa254_not427 : ~ @Equation427 Fin3 refa254_inst.
Proof. unfold Equation427. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa254_inst, refa254_op in H. discriminate H. Qed.

Lemma refa254_not429 : ~ @Equation429 Fin3 refa254_inst.
Proof. unfold Equation429. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa254_inst, refa254_op in H. discriminate H. Qed.

Lemma refa254_not437 : ~ @Equation437 Fin3 refa254_inst.
Proof. unfold Equation437. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa254_inst, refa254_op in H. discriminate H. Qed.

Lemma refa254_not440 : ~ @Equation440 Fin3 refa254_inst.
Proof. unfold Equation440. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa254_inst, refa254_op in H. discriminate H. Qed.

Lemma refa254_not467 : ~ @Equation467 Fin3 refa254_inst.
Proof. unfold Equation467. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa254_inst, refa254_op in H. discriminate H. Qed.

Lemma refa254_not473 : ~ @Equation473 Fin3 refa254_inst.
Proof. unfold Equation473. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa254_inst, refa254_op in H. discriminate H. Qed.

Lemma refa254_not474 : ~ @Equation474 Fin3 refa254_inst.
Proof. unfold Equation474. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa254_inst, refa254_op in H. discriminate H. Qed.

Lemma refa254_not476 : ~ @Equation476 Fin3 refa254_inst.
Proof. unfold Equation476. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa254_inst, refa254_op in H. discriminate H. Qed.

Lemma refa254_not501 : ~ @Equation501 Fin3 refa254_inst.
Proof. unfold Equation501. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa254_inst, refa254_op in H. discriminate H. Qed.

Lemma refa254_not503 : ~ @Equation503 Fin3 refa254_inst.
Proof. unfold Equation503. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa254_inst, refa254_op in H. discriminate H. Qed.

Lemma refa254_not504 : ~ @Equation504 Fin3 refa254_inst.
Proof. unfold Equation504. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa254_inst, refa254_op in H. discriminate H. Qed.

Lemma refa254_not619 : ~ @Equation619 Fin3 refa254_inst.
Proof. unfold Equation619. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa254_inst, refa254_op in H. discriminate H. Qed.

Lemma refa254_not622 : ~ @Equation622 Fin3 refa254_inst.
Proof. unfold Equation622. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa254_inst, refa254_op in H. discriminate H. Qed.

Lemma refa254_not623 : ~ @Equation623 Fin3 refa254_inst.
Proof. unfold Equation623. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa254_inst, refa254_op in H. discriminate H. Qed.

Lemma refa254_not629 : ~ @Equation629 Fin3 refa254_inst.
Proof. unfold Equation629. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa254_inst, refa254_op in H. discriminate H. Qed.

Lemma refa254_not632 : ~ @Equation632 Fin3 refa254_inst.
Proof. unfold Equation632. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa254_inst, refa254_op in H. discriminate H. Qed.

Lemma refa254_not633 : ~ @Equation633 Fin3 refa254_inst.
Proof. unfold Equation633. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa254_inst, refa254_op in H. discriminate H. Qed.

Lemma refa254_not639 : ~ @Equation639 Fin3 refa254_inst.
Proof. unfold Equation639. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa254_inst, refa254_op in H. discriminate H. Qed.

Lemma refa254_not640 : ~ @Equation640 Fin3 refa254_inst.
Proof. unfold Equation640. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa254_inst, refa254_op in H. discriminate H. Qed.

Lemma refa254_not643 : ~ @Equation643 Fin3 refa254_inst.
Proof. unfold Equation643. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa254_inst, refa254_op in H. discriminate H. Qed.

Lemma refa254_not667 : ~ @Equation667 Fin3 refa254_inst.
Proof. unfold Equation667. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa254_inst, refa254_op in H. discriminate H. Qed.

Lemma refa254_not670 : ~ @Equation670 Fin3 refa254_inst.
Proof. unfold Equation670. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa254_inst, refa254_op in H. discriminate H. Qed.

Lemma refa254_not679 : ~ @Equation679 Fin3 refa254_inst.
Proof. unfold Equation679. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa254_inst, refa254_op in H. discriminate H. Qed.

Lemma refa254_not817 : ~ @Equation817 Fin3 refa254_inst.
Proof. unfold Equation817. intro H. specialize (H F3_0). unfold magma_op, refa254_inst, refa254_op in H. discriminate H. Qed.

Lemma refa254_not1023 : ~ @Equation1023 Fin3 refa254_inst.
Proof. unfold Equation1023. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa254_inst, refa254_op in H. discriminate H. Qed.

Lemma refa254_not1025 : ~ @Equation1025 Fin3 refa254_inst.
Proof. unfold Equation1025. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa254_inst, refa254_op in H. discriminate H. Qed.

Lemma refa254_not1026 : ~ @Equation1026 Fin3 refa254_inst.
Proof. unfold Equation1026. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa254_inst, refa254_op in H. discriminate H. Qed.

Lemma refa254_not1028 : ~ @Equation1028 Fin3 refa254_inst.
Proof. unfold Equation1028. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa254_inst, refa254_op in H. discriminate H. Qed.

Lemma refa254_not1035 : ~ @Equation1035 Fin3 refa254_inst.
Proof. unfold Equation1035. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa254_inst, refa254_op in H. discriminate H. Qed.

Lemma refa254_not1039 : ~ @Equation1039 Fin3 refa254_inst.
Proof. unfold Equation1039. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa254_inst, refa254_op in H. discriminate H. Qed.

Lemma refa254_not1046 : ~ @Equation1046 Fin3 refa254_inst.
Proof. unfold Equation1046. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa254_inst, refa254_op in H. discriminate H. Qed.

Lemma refa254_not1048 : ~ @Equation1048 Fin3 refa254_inst.
Proof. unfold Equation1048. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa254_inst, refa254_op in H. discriminate H. Qed.

Lemma refa254_not1049 : ~ @Equation1049 Fin3 refa254_inst.
Proof. unfold Equation1049. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa254_inst, refa254_op in H. discriminate H. Qed.

Lemma refa254_not1076 : ~ @Equation1076 Fin3 refa254_inst.
Proof. unfold Equation1076. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa254_inst, refa254_op in H. discriminate H. Qed.

Lemma refa254_not1083 : ~ @Equation1083 Fin3 refa254_inst.
Proof. unfold Equation1083. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa254_inst, refa254_op in H. discriminate H. Qed.

Lemma refa254_not1085 : ~ @Equation1085 Fin3 refa254_inst.
Proof. unfold Equation1085. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa254_inst, refa254_op in H. discriminate H. Qed.

Lemma refa254_not1086 : ~ @Equation1086 Fin3 refa254_inst.
Proof. unfold Equation1086. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa254_inst, refa254_op in H. discriminate H. Qed.

Lemma refa254_not1109 : ~ @Equation1109 Fin3 refa254_inst.
Proof. unfold Equation1109. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa254_inst, refa254_op in H. discriminate H. Qed.

Lemma refa254_not1110 : ~ @Equation1110 Fin3 refa254_inst.
Proof. unfold Equation1110. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa254_inst, refa254_op in H. discriminate H. Qed.

Lemma refa254_not1112 : ~ @Equation1112 Fin3 refa254_inst.
Proof. unfold Equation1112. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa254_inst, refa254_op in H. discriminate H. Qed.

Lemma refa254_not1229 : ~ @Equation1229 Fin3 refa254_inst.
Proof. unfold Equation1229. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa254_inst, refa254_op in H. discriminate H. Qed.

Lemma refa254_not1238 : ~ @Equation1238 Fin3 refa254_inst.
Proof. unfold Equation1238. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa254_inst, refa254_op in H. discriminate H. Qed.

Lemma refa254_not1239 : ~ @Equation1239 Fin3 refa254_inst.
Proof. unfold Equation1239. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa254_inst, refa254_op in H. discriminate H. Qed.

Lemma refa254_not1242 : ~ @Equation1242 Fin3 refa254_inst.
Proof. unfold Equation1242. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa254_inst, refa254_op in H. discriminate H. Qed.

Lemma refa254_not1248 : ~ @Equation1248 Fin3 refa254_inst.
Proof. unfold Equation1248. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa254_inst, refa254_op in H. discriminate H. Qed.

Lemma refa254_not1251 : ~ @Equation1251 Fin3 refa254_inst.
Proof. unfold Equation1251. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa254_inst, refa254_op in H. discriminate H. Qed.

Lemma refa254_not1252 : ~ @Equation1252 Fin3 refa254_inst.
Proof. unfold Equation1252. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa254_inst, refa254_op in H. discriminate H. Qed.

Lemma refa254_not1278 : ~ @Equation1278 Fin3 refa254_inst.
Proof. unfold Equation1278. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa254_inst, refa254_op in H. discriminate H. Qed.

Lemma refa254_not1279 : ~ @Equation1279 Fin3 refa254_inst.
Proof. unfold Equation1279. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa254_inst, refa254_op in H. discriminate H. Qed.

Lemma refa254_not1286 : ~ @Equation1286 Fin3 refa254_inst.
Proof. unfold Equation1286. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa254_inst, refa254_op in H. discriminate H. Qed.

Lemma refa254_not1288 : ~ @Equation1288 Fin3 refa254_inst.
Proof. unfold Equation1288. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa254_inst, refa254_op in H. discriminate H. Qed.

Lemma refa254_not1315 : ~ @Equation1315 Fin3 refa254_inst.
Proof. unfold Equation1315. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa254_inst, refa254_op in H. discriminate H. Qed.

Lemma refa254_not1322 : ~ @Equation1322 Fin3 refa254_inst.
Proof. unfold Equation1322. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa254_inst, refa254_op in H. discriminate H. Qed.

Lemma refa254_not1427 : ~ @Equation1427 Fin3 refa254_inst.
Proof. unfold Equation1427. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa254_inst, refa254_op in H. discriminate H. Qed.

Lemma refa254_not1428 : ~ @Equation1428 Fin3 refa254_inst.
Proof. unfold Equation1428. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa254_inst, refa254_op in H. discriminate H. Qed.

Lemma refa254_not1429 : ~ @Equation1429 Fin3 refa254_inst.
Proof. unfold Equation1429. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa254_inst, refa254_op in H. discriminate H. Qed.

Lemma refa254_not1431 : ~ @Equation1431 Fin3 refa254_inst.
Proof. unfold Equation1431. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa254_inst, refa254_op in H. discriminate H. Qed.

Lemma refa254_not1435 : ~ @Equation1435 Fin3 refa254_inst.
Proof. unfold Equation1435. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa254_inst, refa254_op in H. discriminate H. Qed.

Lemma refa254_not1441 : ~ @Equation1441 Fin3 refa254_inst.
Proof. unfold Equation1441. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa254_inst, refa254_op in H. discriminate H. Qed.

Lemma refa254_not1445 : ~ @Equation1445 Fin3 refa254_inst.
Proof. unfold Equation1445. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa254_inst, refa254_op in H. discriminate H. Qed.

Lemma refa254_not1451 : ~ @Equation1451 Fin3 refa254_inst.
Proof. unfold Equation1451. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa254_inst, refa254_op in H. discriminate H. Qed.

Lemma refa254_not1454 : ~ @Equation1454 Fin3 refa254_inst.
Proof. unfold Equation1454. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa254_inst, refa254_op in H. discriminate H. Qed.

Lemma refa254_not1478 : ~ @Equation1478 Fin3 refa254_inst.
Proof. unfold Equation1478. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa254_inst, refa254_op in H. discriminate H. Qed.

Lemma refa254_not1482 : ~ @Equation1482 Fin3 refa254_inst.
Proof. unfold Equation1482. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa254_inst, refa254_op in H. discriminate H. Qed.

Lemma refa254_not1488 : ~ @Equation1488 Fin3 refa254_inst.
Proof. unfold Equation1488. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa254_inst, refa254_op in H. discriminate H. Qed.

Lemma refa254_not1515 : ~ @Equation1515 Fin3 refa254_inst.
Proof. unfold Equation1515. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa254_inst, refa254_op in H. discriminate H. Qed.

Lemma refa254_not1516 : ~ @Equation1516 Fin3 refa254_inst.
Proof. unfold Equation1516. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa254_inst, refa254_op in H. discriminate H. Qed.

Lemma refa254_not1630 : ~ @Equation1630 Fin3 refa254_inst.
Proof. unfold Equation1630. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa254_inst, refa254_op in H. discriminate H. Qed.

Lemma refa254_not1631 : ~ @Equation1631 Fin3 refa254_inst.
Proof. unfold Equation1631. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa254_inst, refa254_op in H. discriminate H. Qed.

Lemma refa254_not1634 : ~ @Equation1634 Fin3 refa254_inst.
Proof. unfold Equation1634. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa254_inst, refa254_op in H. discriminate H. Qed.

Lemma refa254_not1637 : ~ @Equation1637 Fin3 refa254_inst.
Proof. unfold Equation1637. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa254_inst, refa254_op in H. discriminate H. Qed.

Lemma refa254_not1638 : ~ @Equation1638 Fin3 refa254_inst.
Proof. unfold Equation1638. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa254_inst, refa254_op in H. discriminate H. Qed.

Lemma refa254_not1644 : ~ @Equation1644 Fin3 refa254_inst.
Proof. unfold Equation1644. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa254_inst, refa254_op in H. discriminate H. Qed.

Lemma refa254_not1645 : ~ @Equation1645 Fin3 refa254_inst.
Proof. unfold Equation1645. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa254_inst, refa254_op in H. discriminate H. Qed.

Lemma refa254_not1648 : ~ @Equation1648 Fin3 refa254_inst.
Proof. unfold Equation1648. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa254_inst, refa254_op in H. discriminate H. Qed.

Lemma refa254_not1655 : ~ @Equation1655 Fin3 refa254_inst.
Proof. unfold Equation1655. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa254_inst, refa254_op in H. discriminate H. Qed.

Lemma refa254_not1657 : ~ @Equation1657 Fin3 refa254_inst.
Proof. unfold Equation1657. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa254_inst, refa254_op in H. discriminate H. Qed.

Lemma refa254_not1681 : ~ @Equation1681 Fin3 refa254_inst.
Proof. unfold Equation1681. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa254_inst, refa254_op in H. discriminate H. Qed.

Lemma refa254_not1682 : ~ @Equation1682 Fin3 refa254_inst.
Proof. unfold Equation1682. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa254_inst, refa254_op in H. discriminate H. Qed.

Lemma refa254_not1685 : ~ @Equation1685 Fin3 refa254_inst.
Proof. unfold Equation1685. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa254_inst, refa254_op in H. discriminate H. Qed.

Lemma refa254_not1692 : ~ @Equation1692 Fin3 refa254_inst.
Proof. unfold Equation1692. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa254_inst, refa254_op in H. discriminate H. Qed.

Lemma refa254_not1694 : ~ @Equation1694 Fin3 refa254_inst.
Proof. unfold Equation1694. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa254_inst, refa254_op in H. discriminate H. Qed.

Lemma refa254_not1721 : ~ @Equation1721 Fin3 refa254_inst.
Proof. unfold Equation1721. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa254_inst, refa254_op in H. discriminate H. Qed.

Lemma refa254_not1722 : ~ @Equation1722 Fin3 refa254_inst.
Proof. unfold Equation1722. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa254_inst, refa254_op in H. discriminate H. Qed.

Lemma refa254_not1728 : ~ @Equation1728 Fin3 refa254_inst.
Proof. unfold Equation1728. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa254_inst, refa254_op in H. discriminate H. Qed.

Lemma refa254_not1833 : ~ @Equation1833 Fin3 refa254_inst.
Proof. unfold Equation1833. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa254_inst, refa254_op in H. discriminate H. Qed.

Lemma refa254_not1834 : ~ @Equation1834 Fin3 refa254_inst.
Proof. unfold Equation1834. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa254_inst, refa254_op in H. discriminate H. Qed.

Lemma refa254_not1837 : ~ @Equation1837 Fin3 refa254_inst.
Proof. unfold Equation1837. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa254_inst, refa254_op in H. discriminate H. Qed.

Lemma refa254_not1841 : ~ @Equation1841 Fin3 refa254_inst.
Proof. unfold Equation1841. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa254_inst, refa254_op in H. discriminate H. Qed.

Lemma refa254_not1847 : ~ @Equation1847 Fin3 refa254_inst.
Proof. unfold Equation1847. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa254_inst, refa254_op in H. discriminate H. Qed.

Lemma refa254_not1851 : ~ @Equation1851 Fin3 refa254_inst.
Proof. unfold Equation1851. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa254_inst, refa254_op in H. discriminate H. Qed.

Lemma refa254_not1857 : ~ @Equation1857 Fin3 refa254_inst.
Proof. unfold Equation1857. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa254_inst, refa254_op in H. discriminate H. Qed.

Lemma refa254_not1858 : ~ @Equation1858 Fin3 refa254_inst.
Proof. unfold Equation1858. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa254_inst, refa254_op in H. discriminate H. Qed.

Lemma refa254_not1860 : ~ @Equation1860 Fin3 refa254_inst.
Proof. unfold Equation1860. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa254_inst, refa254_op in H. discriminate H. Qed.

Lemma refa254_not1884 : ~ @Equation1884 Fin3 refa254_inst.
Proof. unfold Equation1884. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa254_inst, refa254_op in H. discriminate H. Qed.

Lemma refa254_not1885 : ~ @Equation1885 Fin3 refa254_inst.
Proof. unfold Equation1885. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa254_inst, refa254_op in H. discriminate H. Qed.

Lemma refa254_not1887 : ~ @Equation1887 Fin3 refa254_inst.
Proof. unfold Equation1887. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa254_inst, refa254_op in H. discriminate H. Qed.

Lemma refa254_not1895 : ~ @Equation1895 Fin3 refa254_inst.
Proof. unfold Equation1895. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa254_inst, refa254_op in H. discriminate H. Qed.

Lemma refa254_not1897 : ~ @Equation1897 Fin3 refa254_inst.
Proof. unfold Equation1897. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa254_inst, refa254_op in H. discriminate H. Qed.

Lemma refa254_not1922 : ~ @Equation1922 Fin3 refa254_inst.
Proof. unfold Equation1922. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa254_inst, refa254_op in H. discriminate H. Qed.

Lemma refa254_not1924 : ~ @Equation1924 Fin3 refa254_inst.
Proof. unfold Equation1924. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa254_inst, refa254_op in H. discriminate H. Qed.

Lemma refa254_not1925 : ~ @Equation1925 Fin3 refa254_inst.
Proof. unfold Equation1925. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa254_inst, refa254_op in H. discriminate H. Qed.

Lemma refa254_not1931 : ~ @Equation1931 Fin3 refa254_inst.
Proof. unfold Equation1931. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa254_inst, refa254_op in H. discriminate H. Qed.

Lemma refa254_not2036 : ~ @Equation2036 Fin3 refa254_inst.
Proof. unfold Equation2036. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa254_inst, refa254_op in H. discriminate H. Qed.

Lemma refa254_not2037 : ~ @Equation2037 Fin3 refa254_inst.
Proof. unfold Equation2037. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa254_inst, refa254_op in H. discriminate H. Qed.

Lemma refa254_not2038 : ~ @Equation2038 Fin3 refa254_inst.
Proof. unfold Equation2038. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa254_inst, refa254_op in H. discriminate H. Qed.

Lemma refa254_not2040 : ~ @Equation2040 Fin3 refa254_inst.
Proof. unfold Equation2040. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa254_inst, refa254_op in H. discriminate H. Qed.

Lemma refa254_not2041 : ~ @Equation2041 Fin3 refa254_inst.
Proof. unfold Equation2041. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa254_inst, refa254_op in H. discriminate H. Qed.

Lemma refa254_not2043 : ~ @Equation2043 Fin3 refa254_inst.
Proof. unfold Equation2043. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa254_inst, refa254_op in H. discriminate H. Qed.

Lemma refa254_not2050 : ~ @Equation2050 Fin3 refa254_inst.
Proof. unfold Equation2050. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa254_inst, refa254_op in H. discriminate H. Qed.

Lemma refa254_not2063 : ~ @Equation2063 Fin3 refa254_inst.
Proof. unfold Equation2063. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa254_inst, refa254_op in H. discriminate H. Qed.

Lemma refa254_not2087 : ~ @Equation2087 Fin3 refa254_inst.
Proof. unfold Equation2087. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa254_inst, refa254_op in H. discriminate H. Qed.

Lemma refa254_not2091 : ~ @Equation2091 Fin3 refa254_inst.
Proof. unfold Equation2091. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa254_inst, refa254_op in H. discriminate H. Qed.

Lemma refa254_not2124 : ~ @Equation2124 Fin3 refa254_inst.
Proof. unfold Equation2124. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa254_inst, refa254_op in H. discriminate H. Qed.

Lemma refa254_not2125 : ~ @Equation2125 Fin3 refa254_inst.
Proof. unfold Equation2125. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa254_inst, refa254_op in H. discriminate H. Qed.

Lemma refa254_not2134 : ~ @Equation2134 Fin3 refa254_inst.
Proof. unfold Equation2134. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa254_inst, refa254_op in H. discriminate H. Qed.

Lemma refa254_not2240 : ~ @Equation2240 Fin3 refa254_inst.
Proof. unfold Equation2240. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa254_inst, refa254_op in H. discriminate H. Qed.

Lemma refa254_not2246 : ~ @Equation2246 Fin3 refa254_inst.
Proof. unfold Equation2246. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa254_inst, refa254_op in H. discriminate H. Qed.

Lemma refa254_not2247 : ~ @Equation2247 Fin3 refa254_inst.
Proof. unfold Equation2247. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa254_inst, refa254_op in H. discriminate H. Qed.

Lemma refa254_not2254 : ~ @Equation2254 Fin3 refa254_inst.
Proof. unfold Equation2254. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa254_inst, refa254_op in H. discriminate H. Qed.

Lemma refa254_not2257 : ~ @Equation2257 Fin3 refa254_inst.
Proof. unfold Equation2257. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa254_inst, refa254_op in H. discriminate H. Qed.

Lemma refa254_not2264 : ~ @Equation2264 Fin3 refa254_inst.
Proof. unfold Equation2264. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa254_inst, refa254_op in H. discriminate H. Qed.

Lemma refa254_not2266 : ~ @Equation2266 Fin3 refa254_inst.
Proof. unfold Equation2266. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa254_inst, refa254_op in H. discriminate H. Qed.

Lemma refa254_not2293 : ~ @Equation2293 Fin3 refa254_inst.
Proof. unfold Equation2293. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa254_inst, refa254_op in H. discriminate H. Qed.

Lemma refa254_not2300 : ~ @Equation2300 Fin3 refa254_inst.
Proof. unfold Equation2300. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa254_inst, refa254_op in H. discriminate H. Qed.

Lemma refa254_not2301 : ~ @Equation2301 Fin3 refa254_inst.
Proof. unfold Equation2301. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa254_inst, refa254_op in H. discriminate H. Qed.

Lemma refa254_not2330 : ~ @Equation2330 Fin3 refa254_inst.
Proof. unfold Equation2330. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa254_inst, refa254_op in H. discriminate H. Qed.

Lemma refa254_not2340 : ~ @Equation2340 Fin3 refa254_inst.
Proof. unfold Equation2340. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa254_inst, refa254_op in H. discriminate H. Qed.

Lemma refa254_not2443 : ~ @Equation2443 Fin3 refa254_inst.
Proof. unfold Equation2443. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa254_inst, refa254_op in H. discriminate H. Qed.

Lemma refa254_not2444 : ~ @Equation2444 Fin3 refa254_inst.
Proof. unfold Equation2444. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa254_inst, refa254_op in H. discriminate H. Qed.

Lemma refa254_not2446 : ~ @Equation2446 Fin3 refa254_inst.
Proof. unfold Equation2446. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa254_inst, refa254_op in H. discriminate H. Qed.

Lemma refa254_not2460 : ~ @Equation2460 Fin3 refa254_inst.
Proof. unfold Equation2460. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa254_inst, refa254_op in H. discriminate H. Qed.

Lemma refa254_not2466 : ~ @Equation2466 Fin3 refa254_inst.
Proof. unfold Equation2466. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa254_inst, refa254_op in H. discriminate H. Qed.

Lemma refa254_not2467 : ~ @Equation2467 Fin3 refa254_inst.
Proof. unfold Equation2467. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa254_inst, refa254_op in H. discriminate H. Qed.

Lemma refa254_not2469 : ~ @Equation2469 Fin3 refa254_inst.
Proof. unfold Equation2469. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa254_inst, refa254_op in H. discriminate H. Qed.

Lemma refa254_not2497 : ~ @Equation2497 Fin3 refa254_inst.
Proof. unfold Equation2497. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa254_inst, refa254_op in H. discriminate H. Qed.

Lemma refa254_not2503 : ~ @Equation2503 Fin3 refa254_inst.
Proof. unfold Equation2503. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa254_inst, refa254_op in H. discriminate H. Qed.

Lemma refa254_not2504 : ~ @Equation2504 Fin3 refa254_inst.
Proof. unfold Equation2504. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa254_inst, refa254_op in H. discriminate H. Qed.

Lemma refa254_not2506 : ~ @Equation2506 Fin3 refa254_inst.
Proof. unfold Equation2506. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa254_inst, refa254_op in H. discriminate H. Qed.

Lemma refa254_not2530 : ~ @Equation2530 Fin3 refa254_inst.
Proof. unfold Equation2530. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa254_inst, refa254_op in H. discriminate H. Qed.

Lemma refa254_not2531 : ~ @Equation2531 Fin3 refa254_inst.
Proof. unfold Equation2531. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa254_inst, refa254_op in H. discriminate H. Qed.

Lemma refa254_not2533 : ~ @Equation2533 Fin3 refa254_inst.
Proof. unfold Equation2533. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa254_inst, refa254_op in H. discriminate H. Qed.

Lemma refa254_not2541 : ~ @Equation2541 Fin3 refa254_inst.
Proof. unfold Equation2541. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa254_inst, refa254_op in H. discriminate H. Qed.

Lemma refa254_not2543 : ~ @Equation2543 Fin3 refa254_inst.
Proof. unfold Equation2543. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa254_inst, refa254_op in H. discriminate H. Qed.

Lemma refa254_not2644 : ~ @Equation2644 Fin3 refa254_inst.
Proof. unfold Equation2644. intro H. specialize (H F3_0). unfold magma_op, refa254_inst, refa254_op in H. discriminate H. Qed.

Lemma refa254_not2849 : ~ @Equation2849 Fin3 refa254_inst.
Proof. unfold Equation2849. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa254_inst, refa254_op in H. discriminate H. Qed.

Lemma refa254_not2852 : ~ @Equation2852 Fin3 refa254_inst.
Proof. unfold Equation2852. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa254_inst, refa254_op in H. discriminate H. Qed.

Lemma refa254_not2855 : ~ @Equation2855 Fin3 refa254_inst.
Proof. unfold Equation2855. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa254_inst, refa254_op in H. discriminate H. Qed.

Lemma refa254_not2865 : ~ @Equation2865 Fin3 refa254_inst.
Proof. unfold Equation2865. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa254_inst, refa254_op in H. discriminate H. Qed.

Lemma refa254_not2866 : ~ @Equation2866 Fin3 refa254_inst.
Proof. unfold Equation2866. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa254_inst, refa254_op in H. discriminate H. Qed.

Lemma refa254_not2872 : ~ @Equation2872 Fin3 refa254_inst.
Proof. unfold Equation2872. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa254_inst, refa254_op in H. discriminate H. Qed.

Lemma refa254_not2873 : ~ @Equation2873 Fin3 refa254_inst.
Proof. unfold Equation2873. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa254_inst, refa254_op in H. discriminate H. Qed.

Lemma refa254_not2900 : ~ @Equation2900 Fin3 refa254_inst.
Proof. unfold Equation2900. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa254_inst, refa254_op in H. discriminate H. Qed.

Lemma refa254_not2903 : ~ @Equation2903 Fin3 refa254_inst.
Proof. unfold Equation2903. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa254_inst, refa254_op in H. discriminate H. Qed.

Lemma refa254_not2910 : ~ @Equation2910 Fin3 refa254_inst.
Proof. unfold Equation2910. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa254_inst, refa254_op in H. discriminate H. Qed.

Lemma refa254_not2912 : ~ @Equation2912 Fin3 refa254_inst.
Proof. unfold Equation2912. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa254_inst, refa254_op in H. discriminate H. Qed.

Lemma refa254_not2937 : ~ @Equation2937 Fin3 refa254_inst.
Proof. unfold Equation2937. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa254_inst, refa254_op in H. discriminate H. Qed.

Lemma refa254_not2939 : ~ @Equation2939 Fin3 refa254_inst.
Proof. unfold Equation2939. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa254_inst, refa254_op in H. discriminate H. Qed.

Lemma refa254_not2946 : ~ @Equation2946 Fin3 refa254_inst.
Proof. unfold Equation2946. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa254_inst, refa254_op in H. discriminate H. Qed.

Lemma refa254_not2949 : ~ @Equation2949 Fin3 refa254_inst.
Proof. unfold Equation2949. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa254_inst, refa254_op in H. discriminate H. Qed.

Lemma refa254_not3052 : ~ @Equation3052 Fin3 refa254_inst.
Proof. unfold Equation3052. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa254_inst, refa254_op in H. discriminate H. Qed.

Lemma refa254_not3055 : ~ @Equation3055 Fin3 refa254_inst.
Proof. unfold Equation3055. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa254_inst, refa254_op in H. discriminate H. Qed.

Lemma refa254_not3056 : ~ @Equation3056 Fin3 refa254_inst.
Proof. unfold Equation3056. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa254_inst, refa254_op in H. discriminate H. Qed.

Lemma refa254_not3065 : ~ @Equation3065 Fin3 refa254_inst.
Proof. unfold Equation3065. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa254_inst, refa254_op in H. discriminate H. Qed.

Lemma refa254_not3068 : ~ @Equation3068 Fin3 refa254_inst.
Proof. unfold Equation3068. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa254_inst, refa254_op in H. discriminate H. Qed.

Lemma refa254_not3069 : ~ @Equation3069 Fin3 refa254_inst.
Proof. unfold Equation3069. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa254_inst, refa254_op in H. discriminate H. Qed.

Lemma refa254_not3076 : ~ @Equation3076 Fin3 refa254_inst.
Proof. unfold Equation3076. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa254_inst, refa254_op in H. discriminate H. Qed.

Lemma refa254_not3105 : ~ @Equation3105 Fin3 refa254_inst.
Proof. unfold Equation3105. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa254_inst, refa254_op in H. discriminate H. Qed.

Lemma refa254_not3106 : ~ @Equation3106 Fin3 refa254_inst.
Proof. unfold Equation3106. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa254_inst, refa254_op in H. discriminate H. Qed.

Lemma refa254_not3113 : ~ @Equation3113 Fin3 refa254_inst.
Proof. unfold Equation3113. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa254_inst, refa254_op in H. discriminate H. Qed.

Lemma refa254_not3115 : ~ @Equation3115 Fin3 refa254_inst.
Proof. unfold Equation3115. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa254_inst, refa254_op in H. discriminate H. Qed.

Lemma refa254_not3140 : ~ @Equation3140 Fin3 refa254_inst.
Proof. unfold Equation3140. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa254_inst, refa254_op in H. discriminate H. Qed.

Lemma refa254_not3143 : ~ @Equation3143 Fin3 refa254_inst.
Proof. unfold Equation3143. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa254_inst, refa254_op in H. discriminate H. Qed.

Lemma refa254_not3149 : ~ @Equation3149 Fin3 refa254_inst.
Proof. unfold Equation3149. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa254_inst, refa254_op in H. discriminate H. Qed.

Lemma refa254_not3152 : ~ @Equation3152 Fin3 refa254_inst.
Proof. unfold Equation3152. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa254_inst, refa254_op in H. discriminate H. Qed.

Lemma refa254_not3255 : ~ @Equation3255 Fin3 refa254_inst.
Proof. unfold Equation3255. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa254_inst, refa254_op in H. discriminate H. Qed.

Lemma refa254_not3256 : ~ @Equation3256 Fin3 refa254_inst.
Proof. unfold Equation3256. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa254_inst, refa254_op in H. discriminate H. Qed.

Lemma refa254_not3258 : ~ @Equation3258 Fin3 refa254_inst.
Proof. unfold Equation3258. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa254_inst, refa254_op in H. discriminate H. Qed.

Lemma refa254_not3262 : ~ @Equation3262 Fin3 refa254_inst.
Proof. unfold Equation3262. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa254_inst, refa254_op in H. discriminate H. Qed.

Lemma refa254_not3268 : ~ @Equation3268 Fin3 refa254_inst.
Proof. unfold Equation3268. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa254_inst, refa254_op in H. discriminate H. Qed.

Lemma refa254_not3271 : ~ @Equation3271 Fin3 refa254_inst.
Proof. unfold Equation3271. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa254_inst, refa254_op in H. discriminate H. Qed.

Lemma refa254_not3281 : ~ @Equation3281 Fin3 refa254_inst.
Proof. unfold Equation3281. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa254_inst, refa254_op in H. discriminate H. Qed.

Lemma refa254_not3309 : ~ @Equation3309 Fin3 refa254_inst.
Proof. unfold Equation3309. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa254_inst, refa254_op in H. discriminate H. Qed.

Lemma refa254_not3315 : ~ @Equation3315 Fin3 refa254_inst.
Proof. unfold Equation3315. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa254_inst, refa254_op in H. discriminate H. Qed.

Lemma refa254_not3316 : ~ @Equation3316 Fin3 refa254_inst.
Proof. unfold Equation3316. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa254_inst, refa254_op in H. discriminate H. Qed.

Lemma refa254_not3318 : ~ @Equation3318 Fin3 refa254_inst.
Proof. unfold Equation3318. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa254_inst, refa254_op in H. discriminate H. Qed.

Lemma refa254_not3343 : ~ @Equation3343 Fin3 refa254_inst.
Proof. unfold Equation3343. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa254_inst, refa254_op in H. discriminate H. Qed.

Lemma refa254_not3346 : ~ @Equation3346 Fin3 refa254_inst.
Proof. unfold Equation3346. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa254_inst, refa254_op in H. discriminate H. Qed.

Lemma refa254_not3352 : ~ @Equation3352 Fin3 refa254_inst.
Proof. unfold Equation3352. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa254_inst, refa254_op in H. discriminate H. Qed.

Lemma refa254_not3457 : ~ @Equation3457 Fin3 refa254_inst.
Proof. unfold Equation3457. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa254_inst, refa254_op in H. discriminate H. Qed.

Lemma refa254_not3458 : ~ @Equation3458 Fin3 refa254_inst.
Proof. unfold Equation3458. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa254_inst, refa254_op in H. discriminate H. Qed.

Lemma refa254_not3461 : ~ @Equation3461 Fin3 refa254_inst.
Proof. unfold Equation3461. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa254_inst, refa254_op in H. discriminate H. Qed.

Lemma refa254_not3464 : ~ @Equation3464 Fin3 refa254_inst.
Proof. unfold Equation3464. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa254_inst, refa254_op in H. discriminate H. Qed.

Lemma refa254_not3465 : ~ @Equation3465 Fin3 refa254_inst.
Proof. unfold Equation3465. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa254_inst, refa254_op in H. discriminate H. Qed.

Lemma refa254_not3474 : ~ @Equation3474 Fin3 refa254_inst.
Proof. unfold Equation3474. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa254_inst, refa254_op in H. discriminate H. Qed.

Lemma refa254_not3481 : ~ @Equation3481 Fin3 refa254_inst.
Proof. unfold Equation3481. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa254_inst, refa254_op in H. discriminate H. Qed.

Lemma refa254_not3509 : ~ @Equation3509 Fin3 refa254_inst.
Proof. unfold Equation3509. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa254_inst, refa254_op in H. discriminate H. Qed.

Lemma refa254_not3512 : ~ @Equation3512 Fin3 refa254_inst.
Proof. unfold Equation3512. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa254_inst, refa254_op in H. discriminate H. Qed.

Lemma refa254_not3519 : ~ @Equation3519 Fin3 refa254_inst.
Proof. unfold Equation3519. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa254_inst, refa254_op in H. discriminate H. Qed.

Lemma refa254_not3521 : ~ @Equation3521 Fin3 refa254_inst.
Proof. unfold Equation3521. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa254_inst, refa254_op in H. discriminate H. Qed.

Lemma refa254_not3546 : ~ @Equation3546 Fin3 refa254_inst.
Proof. unfold Equation3546. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa254_inst, refa254_op in H. discriminate H. Qed.

Lemma refa254_not3548 : ~ @Equation3548 Fin3 refa254_inst.
Proof. unfold Equation3548. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa254_inst, refa254_op in H. discriminate H. Qed.

Lemma refa254_not3555 : ~ @Equation3555 Fin3 refa254_inst.
Proof. unfold Equation3555. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa254_inst, refa254_op in H. discriminate H. Qed.

Lemma refa254_not3558 : ~ @Equation3558 Fin3 refa254_inst.
Proof. unfold Equation3558. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa254_inst, refa254_op in H. discriminate H. Qed.

Lemma refa254_not3659 : ~ @Equation3659 Fin3 refa254_inst.
Proof. unfold Equation3659. intro H. specialize (H F3_0). unfold magma_op, refa254_inst, refa254_op in H. discriminate H. Qed.

Lemma refa254_not3864 : ~ @Equation3864 Fin3 refa254_inst.
Proof. unfold Equation3864. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa254_inst, refa254_op in H. discriminate H. Qed.

Lemma refa254_not3865 : ~ @Equation3865 Fin3 refa254_inst.
Proof. unfold Equation3865. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa254_inst, refa254_op in H. discriminate H. Qed.

Lemma refa254_not3867 : ~ @Equation3867 Fin3 refa254_inst.
Proof. unfold Equation3867. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa254_inst, refa254_op in H. discriminate H. Qed.

Lemma refa254_not3868 : ~ @Equation3868 Fin3 refa254_inst.
Proof. unfold Equation3868. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa254_inst, refa254_op in H. discriminate H. Qed.

Lemma refa254_not3870 : ~ @Equation3870 Fin3 refa254_inst.
Proof. unfold Equation3870. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa254_inst, refa254_op in H. discriminate H. Qed.

Lemma refa254_not3877 : ~ @Equation3877 Fin3 refa254_inst.
Proof. unfold Equation3877. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa254_inst, refa254_op in H. discriminate H. Qed.

Lemma refa254_not3881 : ~ @Equation3881 Fin3 refa254_inst.
Proof. unfold Equation3881. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa254_inst, refa254_op in H. discriminate H. Qed.

Lemma refa254_not3888 : ~ @Equation3888 Fin3 refa254_inst.
Proof. unfold Equation3888. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa254_inst, refa254_op in H. discriminate H. Qed.

Lemma refa254_not3918 : ~ @Equation3918 Fin3 refa254_inst.
Proof. unfold Equation3918. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa254_inst, refa254_op in H. discriminate H. Qed.

Lemma refa254_not3925 : ~ @Equation3925 Fin3 refa254_inst.
Proof. unfold Equation3925. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa254_inst, refa254_op in H. discriminate H. Qed.

Lemma refa254_not3927 : ~ @Equation3927 Fin3 refa254_inst.
Proof. unfold Equation3927. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa254_inst, refa254_op in H. discriminate H. Qed.

Lemma refa254_not3928 : ~ @Equation3928 Fin3 refa254_inst.
Proof. unfold Equation3928. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa254_inst, refa254_op in H. discriminate H. Qed.

Lemma refa254_not3951 : ~ @Equation3951 Fin3 refa254_inst.
Proof. unfold Equation3951. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa254_inst, refa254_op in H. discriminate H. Qed.

Lemma refa254_not3954 : ~ @Equation3954 Fin3 refa254_inst.
Proof. unfold Equation3954. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa254_inst, refa254_op in H. discriminate H. Qed.

Lemma refa254_not3961 : ~ @Equation3961 Fin3 refa254_inst.
Proof. unfold Equation3961. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa254_inst, refa254_op in H. discriminate H. Qed.

Lemma refa254_not4066 : ~ @Equation4066 Fin3 refa254_inst.
Proof. unfold Equation4066. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa254_inst, refa254_op in H. discriminate H. Qed.

Lemma refa254_not4067 : ~ @Equation4067 Fin3 refa254_inst.
Proof. unfold Equation4067. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa254_inst, refa254_op in H. discriminate H. Qed.

Lemma refa254_not4070 : ~ @Equation4070 Fin3 refa254_inst.
Proof. unfold Equation4070. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa254_inst, refa254_op in H. discriminate H. Qed.

Lemma refa254_not4071 : ~ @Equation4071 Fin3 refa254_inst.
Proof. unfold Equation4071. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa254_inst, refa254_op in H. discriminate H. Qed.

Lemma refa254_not4074 : ~ @Equation4074 Fin3 refa254_inst.
Proof. unfold Equation4074. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa254_inst, refa254_op in H. discriminate H. Qed.

Lemma refa254_not4090 : ~ @Equation4090 Fin3 refa254_inst.
Proof. unfold Equation4090. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa254_inst, refa254_op in H. discriminate H. Qed.

Lemma refa254_not4120 : ~ @Equation4120 Fin3 refa254_inst.
Proof. unfold Equation4120. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa254_inst, refa254_op in H. discriminate H. Qed.

Lemma refa254_not4121 : ~ @Equation4121 Fin3 refa254_inst.
Proof. unfold Equation4121. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa254_inst, refa254_op in H. discriminate H. Qed.

Lemma refa254_not4128 : ~ @Equation4128 Fin3 refa254_inst.
Proof. unfold Equation4128. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa254_inst, refa254_op in H. discriminate H. Qed.

Lemma refa254_not4130 : ~ @Equation4130 Fin3 refa254_inst.
Proof. unfold Equation4130. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa254_inst, refa254_op in H. discriminate H. Qed.

Lemma refa254_not4155 : ~ @Equation4155 Fin3 refa254_inst.
Proof. unfold Equation4155. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa254_inst, refa254_op in H. discriminate H. Qed.

Lemma refa254_not4164 : ~ @Equation4164 Fin3 refa254_inst.
Proof. unfold Equation4164. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa254_inst, refa254_op in H. discriminate H. Qed.

Lemma refa254_not4165 : ~ @Equation4165 Fin3 refa254_inst.
Proof. unfold Equation4165. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa254_inst, refa254_op in H. discriminate H. Qed.

Lemma refa254_not4268 : ~ @Equation4268 Fin3 refa254_inst.
Proof. unfold Equation4268. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa254_inst, refa254_op in H. discriminate H. Qed.

Lemma refa254_not4269 : ~ @Equation4269 Fin3 refa254_inst.
Proof. unfold Equation4269. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa254_inst, refa254_op in H. discriminate H. Qed.

Lemma refa254_not4270 : ~ @Equation4270 Fin3 refa254_inst.
Proof. unfold Equation4270. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa254_inst, refa254_op in H. discriminate H. Qed.

Lemma refa254_not4272 : ~ @Equation4272 Fin3 refa254_inst.
Proof. unfold Equation4272. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa254_inst, refa254_op in H. discriminate H. Qed.

Lemma refa254_not4284 : ~ @Equation4284 Fin3 refa254_inst.
Proof. unfold Equation4284. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa254_inst, refa254_op in H. discriminate H. Qed.

Lemma refa254_not4290 : ~ @Equation4290 Fin3 refa254_inst.
Proof. unfold Equation4290. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa254_inst, refa254_op in H. discriminate H. Qed.

Lemma refa254_not4291 : ~ @Equation4291 Fin3 refa254_inst.
Proof. unfold Equation4291. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa254_inst, refa254_op in H. discriminate H. Qed.

Lemma refa254_not4293 : ~ @Equation4293 Fin3 refa254_inst.
Proof. unfold Equation4293. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa254_inst, refa254_op in H. discriminate H. Qed.

Lemma refa254_not4314 : ~ @Equation4314 Fin3 refa254_inst.
Proof. unfold Equation4314. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa254_inst, refa254_op in H. discriminate H. Qed.

Lemma refa254_not4320 : ~ @Equation4320 Fin3 refa254_inst.
Proof. unfold Equation4320. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa254_inst, refa254_op in H. discriminate H. Qed.

Lemma refa254_not4396 : ~ @Equation4396 Fin3 refa254_inst.
Proof. unfold Equation4396. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa254_inst, refa254_op in H. discriminate H. Qed.

Lemma refa254_not4399 : ~ @Equation4399 Fin3 refa254_inst.
Proof. unfold Equation4399. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa254_inst, refa254_op in H. discriminate H. Qed.

Lemma refa254_not4406 : ~ @Equation4406 Fin3 refa254_inst.
Proof. unfold Equation4406. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa254_inst, refa254_op in H. discriminate H. Qed.

Lemma refa254_not4408 : ~ @Equation4408 Fin3 refa254_inst.
Proof. unfold Equation4408. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa254_inst, refa254_op in H. discriminate H. Qed.

Lemma refa254_not4433 : ~ @Equation4433 Fin3 refa254_inst.
Proof. unfold Equation4433. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa254_inst, refa254_op in H. discriminate H. Qed.

Lemma refa254_not4436 : ~ @Equation4436 Fin3 refa254_inst.
Proof. unfold Equation4436. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa254_inst, refa254_op in H. discriminate H. Qed.

Lemma refa254_not4443 : ~ @Equation4443 Fin3 refa254_inst.
Proof. unfold Equation4443. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa254_inst, refa254_op in H. discriminate H. Qed.

Lemma refa254_not4445 : ~ @Equation4445 Fin3 refa254_inst.
Proof. unfold Equation4445. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa254_inst, refa254_op in H. discriminate H. Qed.

Lemma refa254_not4472 : ~ @Equation4472 Fin3 refa254_inst.
Proof. unfold Equation4472. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa254_inst, refa254_op in H. discriminate H. Qed.

Lemma refa254_not4473 : ~ @Equation4473 Fin3 refa254_inst.
Proof. unfold Equation4473. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa254_inst, refa254_op in H. discriminate H. Qed.

Lemma refa254_not4479 : ~ @Equation4479 Fin3 refa254_inst.
Proof. unfold Equation4479. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa254_inst, refa254_op in H. discriminate H. Qed.

Lemma refa254_not4480 : ~ @Equation4480 Fin3 refa254_inst.
Proof. unfold Equation4480. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa254_inst, refa254_op in H. discriminate H. Qed.

Lemma refa254_not4583 : ~ @Equation4583 Fin3 refa254_inst.
Proof. unfold Equation4583. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa254_inst, refa254_op in H. discriminate H. Qed.

Lemma refa254_not4584 : ~ @Equation4584 Fin3 refa254_inst.
Proof. unfold Equation4584. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa254_inst, refa254_op in H. discriminate H. Qed.

Lemma refa254_not4587 : ~ @Equation4587 Fin3 refa254_inst.
Proof. unfold Equation4587. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa254_inst, refa254_op in H. discriminate H. Qed.

Lemma refa254_not4590 : ~ @Equation4590 Fin3 refa254_inst.
Proof. unfold Equation4590. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa254_inst, refa254_op in H. discriminate H. Qed.

Lemma refa254_not4591 : ~ @Equation4591 Fin3 refa254_inst.
Proof. unfold Equation4591. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa254_inst, refa254_op in H. discriminate H. Qed.

Lemma refa254_not4598 : ~ @Equation4598 Fin3 refa254_inst.
Proof. unfold Equation4598. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa254_inst, refa254_op in H. discriminate H. Qed.

Lemma refa254_not4599 : ~ @Equation4599 Fin3 refa254_inst.
Proof. unfold Equation4599. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa254_inst, refa254_op in H. discriminate H. Qed.

Lemma refa254_not4605 : ~ @Equation4605 Fin3 refa254_inst.
Proof. unfold Equation4605. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa254_inst, refa254_op in H. discriminate H. Qed.

Lemma refa254_not4629 : ~ @Equation4629 Fin3 refa254_inst.
Proof. unfold Equation4629. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa254_inst, refa254_op in H. discriminate H. Qed.

Lemma refa254_not4636 : ~ @Equation4636 Fin3 refa254_inst.
Proof. unfold Equation4636. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa254_inst, refa254_op in H. discriminate H. Qed.

Lemma refa254_not4658 : ~ @Equation4658 Fin3 refa254_inst.
Proof. unfold Equation4658. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa254_inst, refa254_op in H. discriminate H. Qed.

(** ---- refa255 (Fin3) ---- *)

Definition refa255_op (x y : Fin3) : Fin3 :=
  match x, y with
  | F3_0, F3_0 => F3_0 | F3_0, F3_1 => F3_0 | F3_0, F3_2 => F3_2
  | F3_1, F3_0 => F3_2 | F3_1, F3_1 => F3_2 | F3_1, F3_2 => F3_1
  | F3_2, F3_0 => F3_1 | F3_2, F3_1 => F3_0 | F3_2, F3_2 => F3_2
  end.

#[local] Instance refa255_inst : Magma Fin3 := {| magma_op := refa255_op |}.

Lemma refa255_sat429 : @Equation429 Fin3 refa255_inst.
Proof. unfold Equation429, magma_op, refa255_inst, refa255_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa255_sat1655 : @Equation1655 Fin3 refa255_inst.
Proof. unfold Equation1655, magma_op, refa255_inst, refa255_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa255_not23 : ~ @Equation23 Fin3 refa255_inst.
Proof. unfold Equation23. intro H. specialize (H F3_1). unfold magma_op, refa255_inst, refa255_op in H. discriminate H. Qed.

Lemma refa255_not151 : ~ @Equation151 Fin3 refa255_inst.
Proof. unfold Equation151. intro H. specialize (H F3_1). unfold magma_op, refa255_inst, refa255_op in H. discriminate H. Qed.

Lemma refa255_not203 : ~ @Equation203 Fin3 refa255_inst.
Proof. unfold Equation203. intro H. specialize (H F3_1). unfold magma_op, refa255_inst, refa255_op in H. discriminate H. Qed.

Lemma refa255_not307 : ~ @Equation307 Fin3 refa255_inst.
Proof. unfold Equation307. intro H. specialize (H F3_1). unfold magma_op, refa255_inst, refa255_op in H. discriminate H. Qed.

Lemma refa255_not1223 : ~ @Equation1223 Fin3 refa255_inst.
Proof. unfold Equation1223. intro H. specialize (H F3_1). unfold magma_op, refa255_inst, refa255_op in H. discriminate H. Qed.

Lemma refa255_not1426 : ~ @Equation1426 Fin3 refa255_inst.
Proof. unfold Equation1426. intro H. specialize (H F3_1). unfold magma_op, refa255_inst, refa255_op in H. discriminate H. Qed.

Lemma refa255_not1631 : ~ @Equation1631 Fin3 refa255_inst.
Proof. unfold Equation1631. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa255_inst, refa255_op in H. discriminate H. Qed.

Lemma refa255_not1632 : ~ @Equation1632 Fin3 refa255_inst.
Proof. unfold Equation1632. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa255_inst, refa255_op in H. discriminate H. Qed.

Lemma refa255_not1634 : ~ @Equation1634 Fin3 refa255_inst.
Proof. unfold Equation1634. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa255_inst, refa255_op in H. discriminate H. Qed.

Lemma refa255_not1635 : ~ @Equation1635 Fin3 refa255_inst.
Proof. unfold Equation1635. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa255_inst, refa255_op in H. discriminate H. Qed.

Lemma refa255_not1638 : ~ @Equation1638 Fin3 refa255_inst.
Proof. unfold Equation1638. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa255_inst, refa255_op in H. discriminate H. Qed.

Lemma refa255_not1644 : ~ @Equation1644 Fin3 refa255_inst.
Proof. unfold Equation1644. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa255_inst, refa255_op in H. discriminate H. Qed.

Lemma refa255_not1645 : ~ @Equation1645 Fin3 refa255_inst.
Proof. unfold Equation1645. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa255_inst, refa255_op in H. discriminate H. Qed.

Lemma refa255_not1648 : ~ @Equation1648 Fin3 refa255_inst.
Proof. unfold Equation1648. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa255_inst, refa255_op in H. discriminate H. Qed.

Lemma refa255_not1654 : ~ @Equation1654 Fin3 refa255_inst.
Proof. unfold Equation1654. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa255_inst, refa255_op in H. discriminate H. Qed.

Lemma refa255_not1657 : ~ @Equation1657 Fin3 refa255_inst.
Proof. unfold Equation1657. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa255_inst, refa255_op in H. discriminate H. Qed.

Lemma refa255_not1658 : ~ @Equation1658 Fin3 refa255_inst.
Proof. unfold Equation1658. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa255_inst, refa255_op in H. discriminate H. Qed.

Lemma refa255_not3662 : ~ @Equation3662 Fin3 refa255_inst.
Proof. unfold Equation3662. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa255_inst, refa255_op in H. discriminate H. Qed.

Lemma refa255_not4598 : ~ @Equation4598 Fin3 refa255_inst.
Proof. unfold Equation4598. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa255_inst, refa255_op in H. discriminate H. Qed.

(** ---- refa256 (Fin3) ---- *)

Definition refa256_op (x y : Fin3) : Fin3 :=
  match x, y with
  | F3_0, F3_0 => F3_0 | F3_0, F3_1 => F3_1 | F3_0, F3_2 => F3_2
  | F3_1, F3_0 => F3_0 | F3_1, F3_1 => F3_0 | F3_1, F3_2 => F3_2
  | F3_2, F3_0 => F3_0 | F3_2, F3_1 => F3_1 | F3_2, F3_2 => F3_1
  end.

#[local] Instance refa256_inst : Magma Fin3 := {| magma_op := refa256_op |}.

Lemma refa256_sat2306 : @Equation2306 Fin3 refa256_inst.
Proof. unfold Equation2306, magma_op, refa256_inst, refa256_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa256_sat2739 : @Equation2739 Fin3 refa256_inst.
Proof. unfold Equation2739, magma_op, refa256_inst, refa256_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa256_sat3180 : @Equation3180 Fin3 refa256_inst.
Proof. unfold Equation3180, magma_op, refa256_inst, refa256_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa256_not221 : ~ @Equation221 Fin3 refa256_inst.
Proof. unfold Equation221. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa256_inst, refa256_op in H. discriminate H. Qed.

Lemma refa256_not231 : ~ @Equation231 Fin3 refa256_inst.
Proof. unfold Equation231. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa256_inst, refa256_op in H. discriminate H. Qed.

Lemma refa256_not1637 : ~ @Equation1637 Fin3 refa256_inst.
Proof. unfold Equation1637. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa256_inst, refa256_op in H. discriminate H. Qed.

Lemma refa256_not1657 : ~ @Equation1657 Fin3 refa256_inst.
Proof. unfold Equation1657. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa256_inst, refa256_op in H. discriminate H. Qed.

Lemma refa256_not1721 : ~ @Equation1721 Fin3 refa256_inst.
Proof. unfold Equation1721. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa256_inst, refa256_op in H. discriminate H. Qed.

Lemma refa256_not1731 : ~ @Equation1731 Fin3 refa256_inst.
Proof. unfold Equation1731. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa256_inst, refa256_op in H. discriminate H. Qed.

Lemma refa256_not2293 : ~ @Equation2293 Fin3 refa256_inst.
Proof. unfold Equation2293. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa256_inst, refa256_op in H. discriminate H. Qed.

Lemma refa256_not2330 : ~ @Equation2330 Fin3 refa256_inst.
Proof. unfold Equation2330. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa256_inst, refa256_op in H. discriminate H. Qed.

Lemma refa256_not2340 : ~ @Equation2340 Fin3 refa256_inst.
Proof. unfold Equation2340. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa256_inst, refa256_op in H. discriminate H. Qed.

Lemma refa256_not2496 : ~ @Equation2496 Fin3 refa256_inst.
Proof. unfold Equation2496. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa256_inst, refa256_op in H. discriminate H. Qed.

Lemma refa256_not2506 : ~ @Equation2506 Fin3 refa256_inst.
Proof. unfold Equation2506. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa256_inst, refa256_op in H. discriminate H. Qed.

Lemma refa256_not2533 : ~ @Equation2533 Fin3 refa256_inst.
Proof. unfold Equation2533. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa256_inst, refa256_op in H. discriminate H. Qed.

Lemma refa256_not2543 : ~ @Equation2543 Fin3 refa256_inst.
Proof. unfold Equation2543. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa256_inst, refa256_op in H. discriminate H. Qed.

Lemma refa256_not2652 : ~ @Equation2652 Fin3 refa256_inst.
Proof. unfold Equation2652. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa256_inst, refa256_op in H. discriminate H. Qed.

Lemma refa256_not2662 : ~ @Equation2662 Fin3 refa256_inst.
Proof. unfold Equation2662. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa256_inst, refa256_op in H. discriminate H. Qed.

Lemma refa256_not2672 : ~ @Equation2672 Fin3 refa256_inst.
Proof. unfold Equation2672. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa256_inst, refa256_op in H. discriminate H. Qed.

Lemma refa256_not3058 : ~ @Equation3058 Fin3 refa256_inst.
Proof. unfold Equation3058. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa256_inst, refa256_op in H. discriminate H. Qed.

Lemma refa256_not3115 : ~ @Equation3115 Fin3 refa256_inst.
Proof. unfold Equation3115. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa256_inst, refa256_op in H. discriminate H. Qed.

Lemma refa256_not3152 : ~ @Equation3152 Fin3 refa256_inst.
Proof. unfold Equation3152. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa256_inst, refa256_op in H. discriminate H. Qed.

Lemma refa256_not3258 : ~ @Equation3258 Fin3 refa256_inst.
Proof. unfold Equation3258. intro H. specialize (H F3_2 F3_1). unfold magma_op, refa256_inst, refa256_op in H. discriminate H. Qed.

Lemma refa256_not3268 : ~ @Equation3268 Fin3 refa256_inst.
Proof. unfold Equation3268. intro H. specialize (H F3_2 F3_1). unfold magma_op, refa256_inst, refa256_op in H. discriminate H. Qed.

Lemma refa256_not3271 : ~ @Equation3271 Fin3 refa256_inst.
Proof. unfold Equation3271. intro H. specialize (H F3_2 F3_1). unfold magma_op, refa256_inst, refa256_op in H. discriminate H. Qed.

Lemma refa256_not3278 : ~ @Equation3278 Fin3 refa256_inst.
Proof. unfold Equation3278. intro H. specialize (H F3_2 F3_1). unfold magma_op, refa256_inst, refa256_op in H. discriminate H. Qed.

Lemma refa256_not3481 : ~ @Equation3481 Fin3 refa256_inst.
Proof. unfold Equation3481. intro H. specialize (H F3_2 F3_1). unfold magma_op, refa256_inst, refa256_op in H. discriminate H. Qed.

Lemma refa256_not3509 : ~ @Equation3509 Fin3 refa256_inst.
Proof. unfold Equation3509. intro H. specialize (H F3_2 F3_1). unfold magma_op, refa256_inst, refa256_op in H. discriminate H. Qed.

Lemma refa256_not3659 : ~ @Equation3659 Fin3 refa256_inst.
Proof. unfold Equation3659. intro H. specialize (H F3_2). unfold magma_op, refa256_inst, refa256_op in H. discriminate H. Qed.

Lemma refa256_not4090 : ~ @Equation4090 Fin3 refa256_inst.
Proof. unfold Equation4090. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa256_inst, refa256_op in H. discriminate H. Qed.

Lemma refa256_not4155 : ~ @Equation4155 Fin3 refa256_inst.
Proof. unfold Equation4155. intro H. specialize (H F3_2 F3_1). unfold magma_op, refa256_inst, refa256_op in H. discriminate H. Qed.

Lemma refa256_not4272 : ~ @Equation4272 Fin3 refa256_inst.
Proof. unfold Equation4272. intro H. specialize (H F3_2 F3_1). unfold magma_op, refa256_inst, refa256_op in H. discriminate H. Qed.

Lemma refa256_not4320 : ~ @Equation4320 Fin3 refa256_inst.
Proof. unfold Equation4320. intro H. specialize (H F3_2 F3_1). unfold magma_op, refa256_inst, refa256_op in H. discriminate H. Qed.

Lemma refa256_not4606 : ~ @Equation4606 Fin3 refa256_inst.
Proof. unfold Equation4606. intro H. specialize (H F3_2 F3_1). unfold magma_op, refa256_inst, refa256_op in H. discriminate H. Qed.

Lemma refa256_not4622 : ~ @Equation4622 Fin3 refa256_inst.
Proof. unfold Equation4622. intro H. specialize (H F3_0 F3_1 F3_2). unfold magma_op, refa256_inst, refa256_op in H. discriminate H. Qed.

(** ---- refa257 (Fin3) ---- *)

Definition refa257_op (x y : Fin3) : Fin3 :=
  match x, y with
  | F3_0, F3_0 => F3_0 | F3_0, F3_1 => F3_0 | F3_0, F3_2 => F3_1
  | F3_1, F3_0 => F3_2 | F3_1, F3_1 => F3_2 | F3_1, F3_2 => F3_1
  | F3_2, F3_0 => F3_2 | F3_2, F3_1 => F3_0 | F3_2, F3_2 => F3_0
  end.

#[local] Instance refa257_inst : Magma Fin3 := {| magma_op := refa257_op |}.

Lemma refa257_sat2097 : @Equation2097 Fin3 refa257_inst.
Proof. unfold Equation2097, magma_op, refa257_inst, refa257_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa257_not1894 : ~ @Equation1894 Fin3 refa257_inst.
Proof. unfold Equation1894. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa257_inst, refa257_op in H. discriminate H. Qed.

Lemma refa257_not2090 : ~ @Equation2090 Fin3 refa257_inst.
Proof. unfold Equation2090. intro H. specialize (H F3_1 F3_0). unfold magma_op, refa257_inst, refa257_op in H. discriminate H. Qed.

Lemma refa257_not3306 : ~ @Equation3306 Fin3 refa257_inst.
Proof. unfold Equation3306. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa257_inst, refa257_op in H. discriminate H. Qed.

(** ---- refa258 (Fin3) ---- *)

Definition refa258_op (x y : Fin3) : Fin3 :=
  match x, y with
  | F3_0, F3_0 => F3_0 | F3_0, F3_1 => F3_0 | F3_0, F3_2 => F3_0
  | F3_1, F3_0 => F3_1 | F3_1, F3_1 => F3_1 | F3_1, F3_2 => F3_0
  | F3_2, F3_0 => F3_2 | F3_2, F3_1 => F3_0 | F3_2, F3_2 => F3_1
  end.

#[local] Instance refa258_inst : Magma Fin3 := {| magma_op := refa258_op |}.

Lemma refa258_sat1245 : @Equation1245 Fin3 refa258_inst.
Proof. unfold Equation1245, magma_op, refa258_inst, refa258_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa258_sat1250 : @Equation1250 Fin3 refa258_inst.
Proof. unfold Equation1250, magma_op, refa258_inst, refa258_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa258_sat1259 : @Equation1259 Fin3 refa258_inst.
Proof. unfold Equation1259, magma_op, refa258_inst, refa258_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa258_not817 : ~ @Equation817 Fin3 refa258_inst.
Proof. unfold Equation817. intro H. specialize (H F3_2). unfold magma_op, refa258_inst, refa258_op in H. discriminate H. Qed.

(** ---- refa259 (Fin3) ---- *)

Definition refa259_op (x y : Fin3) : Fin3 :=
  match x, y with
  | F3_0, F3_0 => F3_0 | F3_0, F3_1 => F3_1 | F3_0, F3_2 => F3_2
  | F3_1, F3_0 => F3_0 | F3_1, F3_1 => F3_2 | F3_1, F3_2 => F3_1
  | F3_2, F3_0 => F3_2 | F3_2, F3_1 => F3_1 | F3_2, F3_2 => F3_0
  end.

#[local] Instance refa259_inst : Magma Fin3 := {| magma_op := refa259_op |}.

Lemma refa259_sat1278 : @Equation1278 Fin3 refa259_inst.
Proof. unfold Equation1278, magma_op, refa259_inst, refa259_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa259_not1248 : ~ @Equation1248 Fin3 refa259_inst.
Proof. unfold Equation1248. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa259_inst, refa259_op in H. discriminate H. Qed.

Lemma refa259_not2124 : ~ @Equation2124 Fin3 refa259_inst.
Proof. unfold Equation2124. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa259_inst, refa259_op in H. discriminate H. Qed.

(** ---- refa26 (Fin9) ---- *)

Definition refa26_op (x y : Fin9) : Fin9 :=
  match x, y with
  | F9_0, F9_0 => F9_0 | F9_0, F9_1 => F9_2 | F9_0, F9_2 => F9_3 | F9_0, F9_3 => F9_4 | F9_0, F9_4 => F9_5 | F9_0, F9_5 => F9_6 | F9_0, F9_6 => F9_1 | F9_0, F9_7 => F9_8 | F9_0, F9_8 => F9_7
  | F9_1, F9_0 => F9_2 | F9_1, F9_1 => F9_1 | F9_1, F9_2 => F9_7 | F9_1, F9_3 => F9_5 | F9_1, F9_4 => F9_0 | F9_1, F9_5 => F9_3 | F9_1, F9_6 => F9_8 | F9_1, F9_7 => F9_6 | F9_1, F9_8 => F9_4
  | F9_2, F9_0 => F9_3 | F9_2, F9_1 => F9_7 | F9_2, F9_2 => F9_2 | F9_2, F9_3 => F9_8 | F9_2, F9_4 => F9_6 | F9_2, F9_5 => F9_0 | F9_2, F9_6 => F9_4 | F9_2, F9_7 => F9_5 | F9_2, F9_8 => F9_1
  | F9_3, F9_0 => F9_4 | F9_3, F9_1 => F9_5 | F9_3, F9_2 => F9_8 | F9_3, F9_3 => F9_3 | F9_3, F9_4 => F9_7 | F9_3, F9_5 => F9_1 | F9_3, F9_6 => F9_0 | F9_3, F9_7 => F9_2 | F9_3, F9_8 => F9_6
  | F9_4, F9_0 => F9_5 | F9_4, F9_1 => F9_0 | F9_4, F9_2 => F9_6 | F9_4, F9_3 => F9_7 | F9_4, F9_4 => F9_4 | F9_4, F9_5 => F9_8 | F9_4, F9_6 => F9_2 | F9_4, F9_7 => F9_1 | F9_4, F9_8 => F9_3
  | F9_5, F9_0 => F9_6 | F9_5, F9_1 => F9_3 | F9_5, F9_2 => F9_0 | F9_5, F9_3 => F9_1 | F9_5, F9_4 => F9_8 | F9_5, F9_5 => F9_5 | F9_5, F9_6 => F9_7 | F9_5, F9_7 => F9_4 | F9_5, F9_8 => F9_2
  | F9_6, F9_0 => F9_1 | F9_6, F9_1 => F9_8 | F9_6, F9_2 => F9_4 | F9_6, F9_3 => F9_0 | F9_6, F9_4 => F9_2 | F9_6, F9_5 => F9_7 | F9_6, F9_6 => F9_6 | F9_6, F9_7 => F9_3 | F9_6, F9_8 => F9_5
  | F9_7, F9_0 => F9_8 | F9_7, F9_1 => F9_6 | F9_7, F9_2 => F9_5 | F9_7, F9_3 => F9_2 | F9_7, F9_4 => F9_1 | F9_7, F9_5 => F9_4 | F9_7, F9_6 => F9_3 | F9_7, F9_7 => F9_7 | F9_7, F9_8 => F9_0
  | F9_8, F9_0 => F9_7 | F9_8, F9_1 => F9_4 | F9_8, F9_2 => F9_1 | F9_8, F9_3 => F9_6 | F9_8, F9_4 => F9_3 | F9_8, F9_5 => F9_2 | F9_8, F9_6 => F9_5 | F9_8, F9_7 => F9_0 | F9_8, F9_8 => F9_8
  end.

#[local] Instance refa26_inst : Magma Fin9 := {| magma_op := refa26_op |}.

Lemma refa26_sat464 : @Equation464 Fin9 refa26_inst.
Proof. unfold Equation464, magma_op, refa26_inst, refa26_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa26_sat3103 : @Equation3103 Fin9 refa26_inst.
Proof. unfold Equation3103, magma_op, refa26_inst, refa26_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa26_not414 : ~ @Equation414 Fin9 refa26_inst.
Proof. unfold Equation414. intro H. specialize (H F9_0 F9_1). unfold magma_op, refa26_inst, refa26_op in H. discriminate H. Qed.

Lemma refa26_not417 : ~ @Equation417 Fin9 refa26_inst.
Proof. unfold Equation417. intro H. specialize (H F9_0 F9_1). unfold magma_op, refa26_inst, refa26_op in H. discriminate H. Qed.

Lemma refa26_not419 : ~ @Equation419 Fin9 refa26_inst.
Proof. unfold Equation419. intro H. specialize (H F9_0 F9_1). unfold magma_op, refa26_inst, refa26_op in H. discriminate H. Qed.

Lemma refa26_not427 : ~ @Equation427 Fin9 refa26_inst.
Proof. unfold Equation427. intro H. specialize (H F9_0 F9_1). unfold magma_op, refa26_inst, refa26_op in H. discriminate H. Qed.

Lemma refa26_not436 : ~ @Equation436 Fin9 refa26_inst.
Proof. unfold Equation436. intro H. specialize (H F9_0 F9_1). unfold magma_op, refa26_inst, refa26_op in H. discriminate H. Qed.

Lemma refa26_not473 : ~ @Equation473 Fin9 refa26_inst.
Proof. unfold Equation473. intro H. specialize (H F9_0 F9_1). unfold magma_op, refa26_inst, refa26_op in H. discriminate H. Qed.

Lemma refa26_not477 : ~ @Equation477 Fin9 refa26_inst.
Proof. unfold Equation477. intro H. specialize (H F9_0 F9_1). unfold magma_op, refa26_inst, refa26_op in H. discriminate H. Qed.

Lemma refa26_not504 : ~ @Equation504 Fin9 refa26_inst.
Proof. unfold Equation504. intro H. specialize (H F9_0 F9_1). unfold magma_op, refa26_inst, refa26_op in H. discriminate H. Qed.

Lemma refa26_not511 : ~ @Equation511 Fin9 refa26_inst.
Proof. unfold Equation511. intro H. specialize (H F9_0 F9_1). unfold magma_op, refa26_inst, refa26_op in H. discriminate H. Qed.

Lemma refa26_not513 : ~ @Equation513 Fin9 refa26_inst.
Proof. unfold Equation513. intro H. specialize (H F9_0 F9_1). unfold magma_op, refa26_inst, refa26_op in H. discriminate H. Qed.

Lemma refa26_not617 : ~ @Equation617 Fin9 refa26_inst.
Proof. unfold Equation617. intro H. specialize (H F9_0 F9_1). unfold magma_op, refa26_inst, refa26_op in H. discriminate H. Qed.

Lemma refa26_not630 : ~ @Equation630 Fin9 refa26_inst.
Proof. unfold Equation630. intro H. specialize (H F9_0 F9_1). unfold magma_op, refa26_inst, refa26_op in H. discriminate H. Qed.

Lemma refa26_not632 : ~ @Equation632 Fin9 refa26_inst.
Proof. unfold Equation632. intro H. specialize (H F9_0 F9_1). unfold magma_op, refa26_inst, refa26_op in H. discriminate H. Qed.

Lemma refa26_not639 : ~ @Equation639 Fin9 refa26_inst.
Proof. unfold Equation639. intro H. specialize (H F9_0 F9_1). unfold magma_op, refa26_inst, refa26_op in H. discriminate H. Qed.

Lemma refa26_not643 : ~ @Equation643 Fin9 refa26_inst.
Proof. unfold Equation643. intro H. specialize (H F9_0 F9_1). unfold magma_op, refa26_inst, refa26_op in H. discriminate H. Qed.

Lemma refa26_not667 : ~ @Equation667 Fin9 refa26_inst.
Proof. unfold Equation667. intro H. specialize (H F9_0 F9_1). unfold magma_op, refa26_inst, refa26_op in H. discriminate H. Qed.

Lemma refa26_not680 : ~ @Equation680 Fin9 refa26_inst.
Proof. unfold Equation680. intro H. specialize (H F9_0 F9_1). unfold magma_op, refa26_inst, refa26_op in H. discriminate H. Qed.

Lemma refa26_not707 : ~ @Equation707 Fin9 refa26_inst.
Proof. unfold Equation707. intro H. specialize (H F9_0 F9_1). unfold magma_op, refa26_inst, refa26_op in H. discriminate H. Qed.

Lemma refa26_not716 : ~ @Equation716 Fin9 refa26_inst.
Proof. unfold Equation716. intro H. specialize (H F9_0 F9_1). unfold magma_op, refa26_inst, refa26_op in H. discriminate H. Qed.

Lemma refa26_not861 : ~ @Equation861 Fin9 refa26_inst.
Proof. unfold Equation861. intro H. specialize (H F9_0 F9_0 F9_1). unfold magma_op, refa26_inst, refa26_op in H. discriminate H. Qed.

Lemma refa26_not870 : ~ @Equation870 Fin9 refa26_inst.
Proof. unfold Equation870. intro H. specialize (H F9_0 F9_1). unfold magma_op, refa26_inst, refa26_op in H. discriminate H. Qed.

Lemma refa26_not872 : ~ @Equation872 Fin9 refa26_inst.
Proof. unfold Equation872. intro H. specialize (H F9_0 F9_1). unfold magma_op, refa26_inst, refa26_op in H. discriminate H. Qed.

Lemma refa26_not879 : ~ @Equation879 Fin9 refa26_inst.
Proof. unfold Equation879. intro H. specialize (H F9_0 F9_1). unfold magma_op, refa26_inst, refa26_op in H. discriminate H. Qed.

Lemma refa26_not883 : ~ @Equation883 Fin9 refa26_inst.
Proof. unfold Equation883. intro H. specialize (H F9_0 F9_1). unfold magma_op, refa26_inst, refa26_op in H. discriminate H. Qed.

Lemma refa26_not906 : ~ @Equation906 Fin9 refa26_inst.
Proof. unfold Equation906. intro H. specialize (H F9_0 F9_1). unfold magma_op, refa26_inst, refa26_op in H. discriminate H. Qed.

Lemma refa26_not917 : ~ @Equation917 Fin9 refa26_inst.
Proof. unfold Equation917. intro H. specialize (H F9_0 F9_1). unfold magma_op, refa26_inst, refa26_op in H. discriminate H. Qed.

Lemma refa26_not1023 : ~ @Equation1023 Fin9 refa26_inst.
Proof. unfold Equation1023. intro H. specialize (H F9_0 F9_1). unfold magma_op, refa26_inst, refa26_op in H. discriminate H. Qed.

Lemma refa26_not1026 : ~ @Equation1026 Fin9 refa26_inst.
Proof. unfold Equation1026. intro H. specialize (H F9_0 F9_1). unfold magma_op, refa26_inst, refa26_op in H. discriminate H. Qed.

Lemma refa26_not1028 : ~ @Equation1028 Fin9 refa26_inst.
Proof. unfold Equation1028. intro H. specialize (H F9_0 F9_1). unfold magma_op, refa26_inst, refa26_op in H. discriminate H. Qed.

Lemma refa26_not1036 : ~ @Equation1036 Fin9 refa26_inst.
Proof. unfold Equation1036. intro H. specialize (H F9_0 F9_1). unfold magma_op, refa26_inst, refa26_op in H. discriminate H. Qed.

Lemma refa26_not1038 : ~ @Equation1038 Fin9 refa26_inst.
Proof. unfold Equation1038. intro H. specialize (H F9_0 F9_1). unfold magma_op, refa26_inst, refa26_op in H. discriminate H. Qed.

Lemma refa26_not1045 : ~ @Equation1045 Fin9 refa26_inst.
Proof. unfold Equation1045. intro H. specialize (H F9_0 F9_1). unfold magma_op, refa26_inst, refa26_op in H. discriminate H. Qed.

Lemma refa26_not1086 : ~ @Equation1086 Fin9 refa26_inst.
Proof. unfold Equation1086. intro H. specialize (H F9_0 F9_1). unfold magma_op, refa26_inst, refa26_op in H. discriminate H. Qed.

Lemma refa26_not1109 : ~ @Equation1109 Fin9 refa26_inst.
Proof. unfold Equation1109. intro H. specialize (H F9_0 F9_1). unfold magma_op, refa26_inst, refa26_op in H. discriminate H. Qed.

Lemma refa26_not1113 : ~ @Equation1113 Fin9 refa26_inst.
Proof. unfold Equation1113. intro H. specialize (H F9_0 F9_1). unfold magma_op, refa26_inst, refa26_op in H. discriminate H. Qed.

Lemma refa26_not1122 : ~ @Equation1122 Fin9 refa26_inst.
Proof. unfold Equation1122. intro H. specialize (H F9_0 F9_1). unfold magma_op, refa26_inst, refa26_op in H. discriminate H. Qed.

Lemma refa26_not1231 : ~ @Equation1231 Fin9 refa26_inst.
Proof. unfold Equation1231. intro H. specialize (H F9_0 F9_1). unfold magma_op, refa26_inst, refa26_op in H. discriminate H. Qed.

Lemma refa26_not1239 : ~ @Equation1239 Fin9 refa26_inst.
Proof. unfold Equation1239. intro H. specialize (H F9_0 F9_1). unfold magma_op, refa26_inst, refa26_op in H. discriminate H. Qed.

Lemma refa26_not1241 : ~ @Equation1241 Fin9 refa26_inst.
Proof. unfold Equation1241. intro H. specialize (H F9_0 F9_1). unfold magma_op, refa26_inst, refa26_op in H. discriminate H. Qed.

Lemma refa26_not1276 : ~ @Equation1276 Fin9 refa26_inst.
Proof. unfold Equation1276. intro H. specialize (H F9_0 F9_1). unfold magma_op, refa26_inst, refa26_op in H. discriminate H. Qed.

Lemma refa26_not1278 : ~ @Equation1278 Fin9 refa26_inst.
Proof. unfold Equation1278. intro H. specialize (H F9_0 F9_1). unfold magma_op, refa26_inst, refa26_op in H. discriminate H. Qed.

Lemma refa26_not1289 : ~ @Equation1289 Fin9 refa26_inst.
Proof. unfold Equation1289. intro H. specialize (H F9_0 F9_1). unfold magma_op, refa26_inst, refa26_op in H. discriminate H. Qed.

Lemma refa26_not1429 : ~ @Equation1429 Fin9 refa26_inst.
Proof. unfold Equation1429. intro H. specialize (H F9_0 F9_1). unfold magma_op, refa26_inst, refa26_op in H. discriminate H. Qed.

Lemma refa26_not1432 : ~ @Equation1432 Fin9 refa26_inst.
Proof. unfold Equation1432. intro H. specialize (H F9_0 F9_1). unfold magma_op, refa26_inst, refa26_op in H. discriminate H. Qed.

Lemma refa26_not1434 : ~ @Equation1434 Fin9 refa26_inst.
Proof. unfold Equation1434. intro H. specialize (H F9_0 F9_1). unfold magma_op, refa26_inst, refa26_op in H. discriminate H. Qed.

Lemma refa26_not1444 : ~ @Equation1444 Fin9 refa26_inst.
Proof. unfold Equation1444. intro H. specialize (H F9_0 F9_1). unfold magma_op, refa26_inst, refa26_op in H. discriminate H. Qed.

Lemma refa26_not1451 : ~ @Equation1451 Fin9 refa26_inst.
Proof. unfold Equation1451. intro H. specialize (H F9_0 F9_1). unfold magma_op, refa26_inst, refa26_op in H. discriminate H. Qed.

Lemma refa26_not1479 : ~ @Equation1479 Fin9 refa26_inst.
Proof. unfold Equation1479. intro H. specialize (H F9_0 F9_1). unfold magma_op, refa26_inst, refa26_op in H. discriminate H. Qed.

Lemma refa26_not1488 : ~ @Equation1488 Fin9 refa26_inst.
Proof. unfold Equation1488. intro H. specialize (H F9_0 F9_1). unfold magma_op, refa26_inst, refa26_op in H. discriminate H. Qed.

Lemma refa26_not1515 : ~ @Equation1515 Fin9 refa26_inst.
Proof. unfold Equation1515. intro H. specialize (H F9_0 F9_1). unfold magma_op, refa26_inst, refa26_op in H. discriminate H. Qed.

Lemma refa26_not1519 : ~ @Equation1519 Fin9 refa26_inst.
Proof. unfold Equation1519. intro H. specialize (H F9_0 F9_1). unfold magma_op, refa26_inst, refa26_op in H. discriminate H. Qed.

Lemma refa26_not1526 : ~ @Equation1526 Fin9 refa26_inst.
Proof. unfold Equation1526. intro H. specialize (H F9_0 F9_1). unfold magma_op, refa26_inst, refa26_op in H. discriminate H. Qed.

Lemma refa26_not1632 : ~ @Equation1632 Fin9 refa26_inst.
Proof. unfold Equation1632. intro H. specialize (H F9_0 F9_1). unfold magma_op, refa26_inst, refa26_op in H. discriminate H. Qed.

Lemma refa26_not1635 : ~ @Equation1635 Fin9 refa26_inst.
Proof. unfold Equation1635. intro H. specialize (H F9_0 F9_1). unfold magma_op, refa26_inst, refa26_op in H. discriminate H. Qed.

Lemma refa26_not1637 : ~ @Equation1637 Fin9 refa26_inst.
Proof. unfold Equation1637. intro H. specialize (H F9_0 F9_1). unfold magma_op, refa26_inst, refa26_op in H. discriminate H. Qed.

Lemma refa26_not1645 : ~ @Equation1645 Fin9 refa26_inst.
Proof. unfold Equation1645. intro H. specialize (H F9_0 F9_1). unfold magma_op, refa26_inst, refa26_op in H. discriminate H. Qed.

Lemma refa26_not1654 : ~ @Equation1654 Fin9 refa26_inst.
Proof. unfold Equation1654. intro H. specialize (H F9_0 F9_1). unfold magma_op, refa26_inst, refa26_op in H. discriminate H. Qed.

Lemma refa26_not1682 : ~ @Equation1682 Fin9 refa26_inst.
Proof. unfold Equation1682. intro H. specialize (H F9_0 F9_1). unfold magma_op, refa26_inst, refa26_op in H. discriminate H. Qed.

Lemma refa26_not1684 : ~ @Equation1684 Fin9 refa26_inst.
Proof. unfold Equation1684. intro H. specialize (H F9_0 F9_1). unfold magma_op, refa26_inst, refa26_op in H. discriminate H. Qed.

Lemma refa26_not1691 : ~ @Equation1691 Fin9 refa26_inst.
Proof. unfold Equation1691. intro H. specialize (H F9_0 F9_1). unfold magma_op, refa26_inst, refa26_op in H. discriminate H. Qed.

Lemma refa26_not1722 : ~ @Equation1722 Fin9 refa26_inst.
Proof. unfold Equation1722. intro H. specialize (H F9_0 F9_1). unfold magma_op, refa26_inst, refa26_op in H. discriminate H. Qed.

Lemma refa26_not1731 : ~ @Equation1731 Fin9 refa26_inst.
Proof. unfold Equation1731. intro H. specialize (H F9_0 F9_1). unfold magma_op, refa26_inst, refa26_op in H. discriminate H. Qed.

Lemma refa26_not1838 : ~ @Equation1838 Fin9 refa26_inst.
Proof. unfold Equation1838. intro H. specialize (H F9_0 F9_1). unfold magma_op, refa26_inst, refa26_op in H. discriminate H. Qed.

Lemma refa26_not1840 : ~ @Equation1840 Fin9 refa26_inst.
Proof. unfold Equation1840. intro H. specialize (H F9_0 F9_1). unfold magma_op, refa26_inst, refa26_op in H. discriminate H. Qed.

Lemma refa26_not1848 : ~ @Equation1848 Fin9 refa26_inst.
Proof. unfold Equation1848. intro H. specialize (H F9_0 F9_1). unfold magma_op, refa26_inst, refa26_op in H. discriminate H. Qed.

Lemma refa26_not1857 : ~ @Equation1857 Fin9 refa26_inst.
Proof. unfold Equation1857. intro H. specialize (H F9_0 F9_1). unfold magma_op, refa26_inst, refa26_op in H. discriminate H. Qed.

Lemma refa26_not1861 : ~ @Equation1861 Fin9 refa26_inst.
Proof. unfold Equation1861. intro H. specialize (H F9_0 F9_1). unfold magma_op, refa26_inst, refa26_op in H. discriminate H. Qed.

Lemma refa26_not1885 : ~ @Equation1885 Fin9 refa26_inst.
Proof. unfold Equation1885. intro H. specialize (H F9_0 F9_1). unfold magma_op, refa26_inst, refa26_op in H. discriminate H. Qed.

Lemma refa26_not1887 : ~ @Equation1887 Fin9 refa26_inst.
Proof. unfold Equation1887. intro H. specialize (H F9_0 F9_1). unfold magma_op, refa26_inst, refa26_op in H. discriminate H. Qed.

Lemma refa26_not1894 : ~ @Equation1894 Fin9 refa26_inst.
Proof. unfold Equation1894. intro H. specialize (H F9_0 F9_1). unfold magma_op, refa26_inst, refa26_op in H. discriminate H. Qed.

Lemma refa26_not1921 : ~ @Equation1921 Fin9 refa26_inst.
Proof. unfold Equation1921. intro H. specialize (H F9_0 F9_1). unfold magma_op, refa26_inst, refa26_op in H. discriminate H. Qed.

Lemma refa26_not1925 : ~ @Equation1925 Fin9 refa26_inst.
Proof. unfold Equation1925. intro H. specialize (H F9_0 F9_1). unfold magma_op, refa26_inst, refa26_op in H. discriminate H. Qed.

Lemma refa26_not2038 : ~ @Equation2038 Fin9 refa26_inst.
Proof. unfold Equation2038. intro H. specialize (H F9_0 F9_1). unfold magma_op, refa26_inst, refa26_op in H. discriminate H. Qed.

Lemma refa26_not2041 : ~ @Equation2041 Fin9 refa26_inst.
Proof. unfold Equation2041. intro H. specialize (H F9_0 F9_1). unfold magma_op, refa26_inst, refa26_op in H. discriminate H. Qed.

Lemma refa26_not2043 : ~ @Equation2043 Fin9 refa26_inst.
Proof. unfold Equation2043. intro H. specialize (H F9_0 F9_1). unfold magma_op, refa26_inst, refa26_op in H. discriminate H. Qed.

Lemma refa26_not2053 : ~ @Equation2053 Fin9 refa26_inst.
Proof. unfold Equation2053. intro H. specialize (H F9_0 F9_1). unfold magma_op, refa26_inst, refa26_op in H. discriminate H. Qed.

Lemma refa26_not2060 : ~ @Equation2060 Fin9 refa26_inst.
Proof. unfold Equation2060. intro H. specialize (H F9_0 F9_1). unfold magma_op, refa26_inst, refa26_op in H. discriminate H. Qed.

Lemma refa26_not2064 : ~ @Equation2064 Fin9 refa26_inst.
Proof. unfold Equation2064. intro H. specialize (H F9_0 F9_1). unfold magma_op, refa26_inst, refa26_op in H. discriminate H. Qed.

Lemma refa26_not2088 : ~ @Equation2088 Fin9 refa26_inst.
Proof. unfold Equation2088. intro H. specialize (H F9_0 F9_1). unfold magma_op, refa26_inst, refa26_op in H. discriminate H. Qed.

Lemma refa26_not2097 : ~ @Equation2097 Fin9 refa26_inst.
Proof. unfold Equation2097. intro H. specialize (H F9_0 F9_1). unfold magma_op, refa26_inst, refa26_op in H. discriminate H. Qed.

Lemma refa26_not2101 : ~ @Equation2101 Fin9 refa26_inst.
Proof. unfold Equation2101. intro H. specialize (H F9_0 F9_1). unfold magma_op, refa26_inst, refa26_op in H. discriminate H. Qed.

Lemma refa26_not2124 : ~ @Equation2124 Fin9 refa26_inst.
Proof. unfold Equation2124. intro H. specialize (H F9_0 F9_1). unfold magma_op, refa26_inst, refa26_op in H. discriminate H. Qed.

Lemma refa26_not2128 : ~ @Equation2128 Fin9 refa26_inst.
Proof. unfold Equation2128. intro H. specialize (H F9_0 F9_1). unfold magma_op, refa26_inst, refa26_op in H. discriminate H. Qed.

Lemma refa26_not2137 : ~ @Equation2137 Fin9 refa26_inst.
Proof. unfold Equation2137. intro H. specialize (H F9_0 F9_1). unfold magma_op, refa26_inst, refa26_op in H. discriminate H. Qed.

Lemma refa26_not2246 : ~ @Equation2246 Fin9 refa26_inst.
Proof. unfold Equation2246. intro H. specialize (H F9_0 F9_1). unfold magma_op, refa26_inst, refa26_op in H. discriminate H. Qed.

Lemma refa26_not2254 : ~ @Equation2254 Fin9 refa26_inst.
Proof. unfold Equation2254. intro H. specialize (H F9_0 F9_1). unfold magma_op, refa26_inst, refa26_op in H. discriminate H. Qed.

Lemma refa26_not2256 : ~ @Equation2256 Fin9 refa26_inst.
Proof. unfold Equation2256. intro H. specialize (H F9_0 F9_1). unfold magma_op, refa26_inst, refa26_op in H. discriminate H. Qed.

Lemma refa26_not2263 : ~ @Equation2263 Fin9 refa26_inst.
Proof. unfold Equation2263. intro H. specialize (H F9_0 F9_1). unfold magma_op, refa26_inst, refa26_op in H. discriminate H. Qed.

Lemma refa26_not2267 : ~ @Equation2267 Fin9 refa26_inst.
Proof. unfold Equation2267. intro H. specialize (H F9_0 F9_1). unfold magma_op, refa26_inst, refa26_op in H. discriminate H. Qed.

Lemma refa26_not2291 : ~ @Equation2291 Fin9 refa26_inst.
Proof. unfold Equation2291. intro H. specialize (H F9_0 F9_1). unfold magma_op, refa26_inst, refa26_op in H. discriminate H. Qed.

Lemma refa26_not2293 : ~ @Equation2293 Fin9 refa26_inst.
Proof. unfold Equation2293. intro H. specialize (H F9_0 F9_1). unfold magma_op, refa26_inst, refa26_op in H. discriminate H. Qed.

Lemma refa26_not2300 : ~ @Equation2300 Fin9 refa26_inst.
Proof. unfold Equation2300. intro H. specialize (H F9_0 F9_1). unfold magma_op, refa26_inst, refa26_op in H. discriminate H. Qed.

Lemma refa26_not2327 : ~ @Equation2327 Fin9 refa26_inst.
Proof. unfold Equation2327. intro H. specialize (H F9_0 F9_1). unfold magma_op, refa26_inst, refa26_op in H. discriminate H. Qed.

Lemma refa26_not2338 : ~ @Equation2338 Fin9 refa26_inst.
Proof. unfold Equation2338. intro H. specialize (H F9_0 F9_1). unfold magma_op, refa26_inst, refa26_op in H. discriminate H. Qed.

Lemma refa26_not2340 : ~ @Equation2340 Fin9 refa26_inst.
Proof. unfold Equation2340. intro H. specialize (H F9_0 F9_1). unfold magma_op, refa26_inst, refa26_op in H. discriminate H. Qed.

Lemma refa26_not2444 : ~ @Equation2444 Fin9 refa26_inst.
Proof. unfold Equation2444. intro H. specialize (H F9_0 F9_1). unfold magma_op, refa26_inst, refa26_op in H. discriminate H. Qed.

Lemma refa26_not2449 : ~ @Equation2449 Fin9 refa26_inst.
Proof. unfold Equation2449. intro H. specialize (H F9_0 F9_1). unfold magma_op, refa26_inst, refa26_op in H. discriminate H. Qed.

Lemma refa26_not2459 : ~ @Equation2459 Fin9 refa26_inst.
Proof. unfold Equation2459. intro H. specialize (H F9_0 F9_1). unfold magma_op, refa26_inst, refa26_op in H. discriminate H. Qed.

Lemma refa26_not2466 : ~ @Equation2466 Fin9 refa26_inst.
Proof. unfold Equation2466. intro H. specialize (H F9_0 F9_1). unfold magma_op, refa26_inst, refa26_op in H. discriminate H. Qed.

Lemma refa26_not2470 : ~ @Equation2470 Fin9 refa26_inst.
Proof. unfold Equation2470. intro H. specialize (H F9_0 F9_1). unfold magma_op, refa26_inst, refa26_op in H. discriminate H. Qed.

Lemma refa26_not2496 : ~ @Equation2496 Fin9 refa26_inst.
Proof. unfold Equation2496. intro H. specialize (H F9_0 F9_1). unfold magma_op, refa26_inst, refa26_op in H. discriminate H. Qed.

Lemma refa26_not2503 : ~ @Equation2503 Fin9 refa26_inst.
Proof. unfold Equation2503. intro H. specialize (H F9_0 F9_1). unfold magma_op, refa26_inst, refa26_op in H. discriminate H. Qed.

Lemma refa26_not2530 : ~ @Equation2530 Fin9 refa26_inst.
Proof. unfold Equation2530. intro H. specialize (H F9_0 F9_1). unfold magma_op, refa26_inst, refa26_op in H. discriminate H. Qed.

Lemma refa26_not2534 : ~ @Equation2534 Fin9 refa26_inst.
Proof. unfold Equation2534. intro H. specialize (H F9_0 F9_1). unfold magma_op, refa26_inst, refa26_op in H. discriminate H. Qed.

Lemma refa26_not2541 : ~ @Equation2541 Fin9 refa26_inst.
Proof. unfold Equation2541. intro H. specialize (H F9_0 F9_1). unfold magma_op, refa26_inst, refa26_op in H. discriminate H. Qed.

Lemma refa26_not2543 : ~ @Equation2543 Fin9 refa26_inst.
Proof. unfold Equation2543. intro H. specialize (H F9_0 F9_1). unfold magma_op, refa26_inst, refa26_op in H. discriminate H. Qed.

Lemma refa26_not2647 : ~ @Equation2647 Fin9 refa26_inst.
Proof. unfold Equation2647. intro H. specialize (H F9_0 F9_1). unfold magma_op, refa26_inst, refa26_op in H. discriminate H. Qed.

Lemma refa26_not2650 : ~ @Equation2650 Fin9 refa26_inst.
Proof. unfold Equation2650. intro H. specialize (H F9_0 F9_1). unfold magma_op, refa26_inst, refa26_op in H. discriminate H. Qed.

Lemma refa26_not2652 : ~ @Equation2652 Fin9 refa26_inst.
Proof. unfold Equation2652. intro H. specialize (H F9_0 F9_1). unfold magma_op, refa26_inst, refa26_op in H. discriminate H. Qed.

Lemma refa26_not2660 : ~ @Equation2660 Fin9 refa26_inst.
Proof. unfold Equation2660. intro H. specialize (H F9_0 F9_1). unfold magma_op, refa26_inst, refa26_op in H. discriminate H. Qed.

Lemma refa26_not2662 : ~ @Equation2662 Fin9 refa26_inst.
Proof. unfold Equation2662. intro H. specialize (H F9_0 F9_1). unfold magma_op, refa26_inst, refa26_op in H. discriminate H. Qed.

Lemma refa26_not2669 : ~ @Equation2669 Fin9 refa26_inst.
Proof. unfold Equation2669. intro H. specialize (H F9_0 F9_1). unfold magma_op, refa26_inst, refa26_op in H. discriminate H. Qed.

Lemma refa26_not2697 : ~ @Equation2697 Fin9 refa26_inst.
Proof. unfold Equation2697. intro H. specialize (H F9_0 F9_1). unfold magma_op, refa26_inst, refa26_op in H. discriminate H. Qed.

Lemma refa26_not2699 : ~ @Equation2699 Fin9 refa26_inst.
Proof. unfold Equation2699. intro H. specialize (H F9_0 F9_1). unfold magma_op, refa26_inst, refa26_op in H. discriminate H. Qed.

Lemma refa26_not2706 : ~ @Equation2706 Fin9 refa26_inst.
Proof. unfold Equation2706. intro H. specialize (H F9_0 F9_1). unfold magma_op, refa26_inst, refa26_op in H. discriminate H. Qed.

Lemma refa26_not2710 : ~ @Equation2710 Fin9 refa26_inst.
Proof. unfold Equation2710. intro H. specialize (H F9_0 F9_1). unfold magma_op, refa26_inst, refa26_op in H. discriminate H. Qed.

Lemma refa26_not2733 : ~ @Equation2733 Fin9 refa26_inst.
Proof. unfold Equation2733. intro H. specialize (H F9_0 F9_1). unfold magma_op, refa26_inst, refa26_op in H. discriminate H. Qed.

Lemma refa26_not2744 : ~ @Equation2744 Fin9 refa26_inst.
Proof. unfold Equation2744. intro H. specialize (H F9_0 F9_1). unfold magma_op, refa26_inst, refa26_op in H. discriminate H. Qed.

Lemma refa26_not2746 : ~ @Equation2746 Fin9 refa26_inst.
Proof. unfold Equation2746. intro H. specialize (H F9_0 F9_1). unfold magma_op, refa26_inst, refa26_op in H. discriminate H. Qed.

Lemma refa26_not2855 : ~ @Equation2855 Fin9 refa26_inst.
Proof. unfold Equation2855. intro H. specialize (H F9_0 F9_1). unfold magma_op, refa26_inst, refa26_op in H. discriminate H. Qed.

Lemma refa26_not2865 : ~ @Equation2865 Fin9 refa26_inst.
Proof. unfold Equation2865. intro H. specialize (H F9_0 F9_1). unfold magma_op, refa26_inst, refa26_op in H. discriminate H. Qed.

Lemma refa26_not2872 : ~ @Equation2872 Fin9 refa26_inst.
Proof. unfold Equation2872. intro H. specialize (H F9_0 F9_1). unfold magma_op, refa26_inst, refa26_op in H. discriminate H. Qed.

Lemma refa26_not2900 : ~ @Equation2900 Fin9 refa26_inst.
Proof. unfold Equation2900. intro H. specialize (H F9_0 F9_1). unfold magma_op, refa26_inst, refa26_op in H. discriminate H. Qed.

Lemma refa26_not2902 : ~ @Equation2902 Fin9 refa26_inst.
Proof. unfold Equation2902. intro H. specialize (H F9_0 F9_1). unfold magma_op, refa26_inst, refa26_op in H. discriminate H. Qed.

Lemma refa26_not2909 : ~ @Equation2909 Fin9 refa26_inst.
Proof. unfold Equation2909. intro H. specialize (H F9_0 F9_1). unfold magma_op, refa26_inst, refa26_op in H. discriminate H. Qed.

Lemma refa26_not2936 : ~ @Equation2936 Fin9 refa26_inst.
Proof. unfold Equation2936. intro H. specialize (H F9_0 F9_1). unfold magma_op, refa26_inst, refa26_op in H. discriminate H. Qed.

Lemma refa26_not2940 : ~ @Equation2940 Fin9 refa26_inst.
Proof. unfold Equation2940. intro H. specialize (H F9_0 F9_1). unfold magma_op, refa26_inst, refa26_op in H. discriminate H. Qed.

Lemma refa26_not2947 : ~ @Equation2947 Fin9 refa26_inst.
Proof. unfold Equation2947. intro H. specialize (H F9_0 F9_1). unfold magma_op, refa26_inst, refa26_op in H. discriminate H. Qed.

Lemma refa26_not2949 : ~ @Equation2949 Fin9 refa26_inst.
Proof. unfold Equation2949. intro H. specialize (H F9_0 F9_1). unfold magma_op, refa26_inst, refa26_op in H. discriminate H. Qed.

Lemma refa26_not3056 : ~ @Equation3056 Fin9 refa26_inst.
Proof. unfold Equation3056. intro H. specialize (H F9_0 F9_1). unfold magma_op, refa26_inst, refa26_op in H. discriminate H. Qed.

Lemma refa26_not3058 : ~ @Equation3058 Fin9 refa26_inst.
Proof. unfold Equation3058. intro H. specialize (H F9_0 F9_1). unfold magma_op, refa26_inst, refa26_op in H. discriminate H. Qed.

Lemma refa26_not3068 : ~ @Equation3068 Fin9 refa26_inst.
Proof. unfold Equation3068. intro H. specialize (H F9_0 F9_1). unfold magma_op, refa26_inst, refa26_op in H. discriminate H. Qed.

Lemma refa26_not3075 : ~ @Equation3075 Fin9 refa26_inst.
Proof. unfold Equation3075. intro H. specialize (H F9_0 F9_1). unfold magma_op, refa26_inst, refa26_op in H. discriminate H. Qed.

Lemma refa26_not3079 : ~ @Equation3079 Fin9 refa26_inst.
Proof. unfold Equation3079. intro H. specialize (H F9_0 F9_1). unfold magma_op, refa26_inst, refa26_op in H. discriminate H. Qed.

Lemma refa26_not3105 : ~ @Equation3105 Fin9 refa26_inst.
Proof. unfold Equation3105. intro H. specialize (H F9_0 F9_1). unfold magma_op, refa26_inst, refa26_op in H. discriminate H. Qed.

Lemma refa26_not3112 : ~ @Equation3112 Fin9 refa26_inst.
Proof. unfold Equation3112. intro H. specialize (H F9_0 F9_1). unfold magma_op, refa26_inst, refa26_op in H. discriminate H. Qed.

Lemma refa26_not3116 : ~ @Equation3116 Fin9 refa26_inst.
Proof. unfold Equation3116. intro H. specialize (H F9_0 F9_1). unfold magma_op, refa26_inst, refa26_op in H. discriminate H. Qed.

Lemma refa26_not3139 : ~ @Equation3139 Fin9 refa26_inst.
Proof. unfold Equation3139. intro H. specialize (H F9_0 F9_1). unfold magma_op, refa26_inst, refa26_op in H. discriminate H. Qed.

Lemma refa26_not3143 : ~ @Equation3143 Fin9 refa26_inst.
Proof. unfold Equation3143. intro H. specialize (H F9_0 F9_1). unfold magma_op, refa26_inst, refa26_op in H. discriminate H. Qed.

Lemma refa26_not3150 : ~ @Equation3150 Fin9 refa26_inst.
Proof. unfold Equation3150. intro H. specialize (H F9_0 F9_1). unfold magma_op, refa26_inst, refa26_op in H. discriminate H. Qed.

Lemma refa26_not3152 : ~ @Equation3152 Fin9 refa26_inst.
Proof. unfold Equation3152. intro H. specialize (H F9_0 F9_1). unfold magma_op, refa26_inst, refa26_op in H. discriminate H. Qed.

Lemma refa26_not3259 : ~ @Equation3259 Fin9 refa26_inst.
Proof. unfold Equation3259. intro H. specialize (H F9_0 F9_1). unfold magma_op, refa26_inst, refa26_op in H. discriminate H. Qed.

Lemma refa26_not3261 : ~ @Equation3261 Fin9 refa26_inst.
Proof. unfold Equation3261. intro H. specialize (H F9_0 F9_1). unfold magma_op, refa26_inst, refa26_op in H. discriminate H. Qed.

Lemma refa26_not3269 : ~ @Equation3269 Fin9 refa26_inst.
Proof. unfold Equation3269. intro H. specialize (H F9_0 F9_1). unfold magma_op, refa26_inst, refa26_op in H. discriminate H. Qed.

Lemma refa26_not3271 : ~ @Equation3271 Fin9 refa26_inst.
Proof. unfold Equation3271. intro H. specialize (H F9_0 F9_1). unfold magma_op, refa26_inst, refa26_op in H. discriminate H. Qed.

Lemma refa26_not3278 : ~ @Equation3278 Fin9 refa26_inst.
Proof. unfold Equation3278. intro H. specialize (H F9_0 F9_1). unfold magma_op, refa26_inst, refa26_op in H. discriminate H. Qed.

Lemma refa26_not3306 : ~ @Equation3306 Fin9 refa26_inst.
Proof. unfold Equation3306. intro H. specialize (H F9_0 F9_1). unfold magma_op, refa26_inst, refa26_op in H. discriminate H. Qed.

Lemma refa26_not3308 : ~ @Equation3308 Fin9 refa26_inst.
Proof. unfold Equation3308. intro H. specialize (H F9_0 F9_1). unfold magma_op, refa26_inst, refa26_op in H. discriminate H. Qed.

Lemma refa26_not3346 : ~ @Equation3346 Fin9 refa26_inst.
Proof. unfold Equation3346. intro H. specialize (H F9_0 F9_1). unfold magma_op, refa26_inst, refa26_op in H. discriminate H. Qed.

Lemma refa26_not3353 : ~ @Equation3353 Fin9 refa26_inst.
Proof. unfold Equation3353. intro H. specialize (H F9_0 F9_1). unfold magma_op, refa26_inst, refa26_op in H. discriminate H. Qed.

Lemma refa26_not3355 : ~ @Equation3355 Fin9 refa26_inst.
Proof. unfold Equation3355. intro H. specialize (H F9_0 F9_1). unfold magma_op, refa26_inst, refa26_op in H. discriminate H. Qed.

Lemma refa26_not3459 : ~ @Equation3459 Fin9 refa26_inst.
Proof. unfold Equation3459. intro H. specialize (H F9_0 F9_1). unfold magma_op, refa26_inst, refa26_op in H. discriminate H. Qed.

Lemma refa26_not3462 : ~ @Equation3462 Fin9 refa26_inst.
Proof. unfold Equation3462. intro H. specialize (H F9_0 F9_1). unfold magma_op, refa26_inst, refa26_op in H. discriminate H. Qed.

Lemma refa26_not3464 : ~ @Equation3464 Fin9 refa26_inst.
Proof. unfold Equation3464. intro H. specialize (H F9_0 F9_1). unfold magma_op, refa26_inst, refa26_op in H. discriminate H. Qed.

Lemma refa26_not3472 : ~ @Equation3472 Fin9 refa26_inst.
Proof. unfold Equation3472. intro H. specialize (H F9_0 F9_1). unfold magma_op, refa26_inst, refa26_op in H. discriminate H. Qed.

Lemma refa26_not3474 : ~ @Equation3474 Fin9 refa26_inst.
Proof. unfold Equation3474. intro H. specialize (H F9_0 F9_1). unfold magma_op, refa26_inst, refa26_op in H. discriminate H. Qed.

Lemma refa26_not3481 : ~ @Equation3481 Fin9 refa26_inst.
Proof. unfold Equation3481. intro H. specialize (H F9_0 F9_1). unfold magma_op, refa26_inst, refa26_op in H. discriminate H. Qed.

Lemma refa26_not3509 : ~ @Equation3509 Fin9 refa26_inst.
Proof. unfold Equation3509. intro H. specialize (H F9_0 F9_1). unfold magma_op, refa26_inst, refa26_op in H. discriminate H. Qed.

Lemma refa26_not3511 : ~ @Equation3511 Fin9 refa26_inst.
Proof. unfold Equation3511. intro H. specialize (H F9_0 F9_1). unfold magma_op, refa26_inst, refa26_op in H. discriminate H. Qed.

Lemma refa26_not3518 : ~ @Equation3518 Fin9 refa26_inst.
Proof. unfold Equation3518. intro H. specialize (H F9_0 F9_1). unfold magma_op, refa26_inst, refa26_op in H. discriminate H. Qed.

Lemma refa26_not3549 : ~ @Equation3549 Fin9 refa26_inst.
Proof. unfold Equation3549. intro H. specialize (H F9_0 F9_1). unfold magma_op, refa26_inst, refa26_op in H. discriminate H. Qed.

Lemma refa26_not3556 : ~ @Equation3556 Fin9 refa26_inst.
Proof. unfold Equation3556. intro H. specialize (H F9_0 F9_1). unfold magma_op, refa26_inst, refa26_op in H. discriminate H. Qed.

Lemma refa26_not3558 : ~ @Equation3558 Fin9 refa26_inst.
Proof. unfold Equation3558. intro H. specialize (H F9_0 F9_1). unfold magma_op, refa26_inst, refa26_op in H. discriminate H. Qed.

Lemma refa26_not3662 : ~ @Equation3662 Fin9 refa26_inst.
Proof. unfold Equation3662. intro H. specialize (H F9_0 F9_1). unfold magma_op, refa26_inst, refa26_op in H. discriminate H. Qed.

Lemma refa26_not3665 : ~ @Equation3665 Fin9 refa26_inst.
Proof. unfold Equation3665. intro H. specialize (H F9_0 F9_1). unfold magma_op, refa26_inst, refa26_op in H. discriminate H. Qed.

Lemma refa26_not3667 : ~ @Equation3667 Fin9 refa26_inst.
Proof. unfold Equation3667. intro H. specialize (H F9_0 F9_1). unfold magma_op, refa26_inst, refa26_op in H. discriminate H. Qed.

Lemma refa26_not3675 : ~ @Equation3675 Fin9 refa26_inst.
Proof. unfold Equation3675. intro H. specialize (H F9_0 F9_1). unfold magma_op, refa26_inst, refa26_op in H. discriminate H. Qed.

Lemma refa26_not3677 : ~ @Equation3677 Fin9 refa26_inst.
Proof. unfold Equation3677. intro H. specialize (H F9_0 F9_1). unfold magma_op, refa26_inst, refa26_op in H. discriminate H. Qed.

Lemma refa26_not3684 : ~ @Equation3684 Fin9 refa26_inst.
Proof. unfold Equation3684. intro H. specialize (H F9_0 F9_1). unfold magma_op, refa26_inst, refa26_op in H. discriminate H. Qed.

Lemma refa26_not3712 : ~ @Equation3712 Fin9 refa26_inst.
Proof. unfold Equation3712. intro H. specialize (H F9_0 F9_1). unfold magma_op, refa26_inst, refa26_op in H. discriminate H. Qed.

Lemma refa26_not3714 : ~ @Equation3714 Fin9 refa26_inst.
Proof. unfold Equation3714. intro H. specialize (H F9_0 F9_1). unfold magma_op, refa26_inst, refa26_op in H. discriminate H. Qed.

Lemma refa26_not3748 : ~ @Equation3748 Fin9 refa26_inst.
Proof. unfold Equation3748. intro H. specialize (H F9_0 F9_1). unfold magma_op, refa26_inst, refa26_op in H. discriminate H. Qed.

Lemma refa26_not3752 : ~ @Equation3752 Fin9 refa26_inst.
Proof. unfold Equation3752. intro H. specialize (H F9_0 F9_1). unfold magma_op, refa26_inst, refa26_op in H. discriminate H. Qed.

Lemma refa26_not3759 : ~ @Equation3759 Fin9 refa26_inst.
Proof. unfold Equation3759. intro H. specialize (H F9_0 F9_1). unfold magma_op, refa26_inst, refa26_op in H. discriminate H. Qed.

Lemma refa26_not3761 : ~ @Equation3761 Fin9 refa26_inst.
Proof. unfold Equation3761. intro H. specialize (H F9_0 F9_1). unfold magma_op, refa26_inst, refa26_op in H. discriminate H. Qed.

Lemma refa26_not3865 : ~ @Equation3865 Fin9 refa26_inst.
Proof. unfold Equation3865. intro H. specialize (H F9_0 F9_1). unfold magma_op, refa26_inst, refa26_op in H. discriminate H. Qed.

Lemma refa26_not3868 : ~ @Equation3868 Fin9 refa26_inst.
Proof. unfold Equation3868. intro H. specialize (H F9_0 F9_1). unfold magma_op, refa26_inst, refa26_op in H. discriminate H. Qed.

Lemma refa26_not3870 : ~ @Equation3870 Fin9 refa26_inst.
Proof. unfold Equation3870. intro H. specialize (H F9_0 F9_1). unfold magma_op, refa26_inst, refa26_op in H. discriminate H. Qed.

Lemma refa26_not3878 : ~ @Equation3878 Fin9 refa26_inst.
Proof. unfold Equation3878. intro H. specialize (H F9_0 F9_1). unfold magma_op, refa26_inst, refa26_op in H. discriminate H. Qed.

Lemma refa26_not3880 : ~ @Equation3880 Fin9 refa26_inst.
Proof. unfold Equation3880. intro H. specialize (H F9_0 F9_1). unfold magma_op, refa26_inst, refa26_op in H. discriminate H. Qed.

Lemma refa26_not3887 : ~ @Equation3887 Fin9 refa26_inst.
Proof. unfold Equation3887. intro H. specialize (H F9_0 F9_1). unfold magma_op, refa26_inst, refa26_op in H. discriminate H. Qed.

Lemma refa26_not3917 : ~ @Equation3917 Fin9 refa26_inst.
Proof. unfold Equation3917. intro H. specialize (H F9_0 F9_1). unfold magma_op, refa26_inst, refa26_op in H. discriminate H. Qed.

Lemma refa26_not3924 : ~ @Equation3924 Fin9 refa26_inst.
Proof. unfold Equation3924. intro H. specialize (H F9_0 F9_1). unfold magma_op, refa26_inst, refa26_op in H. discriminate H. Qed.

Lemma refa26_not3951 : ~ @Equation3951 Fin9 refa26_inst.
Proof. unfold Equation3951. intro H. specialize (H F9_0 F9_1). unfold magma_op, refa26_inst, refa26_op in H. discriminate H. Qed.

Lemma refa26_not3955 : ~ @Equation3955 Fin9 refa26_inst.
Proof. unfold Equation3955. intro H. specialize (H F9_0 F9_1). unfold magma_op, refa26_inst, refa26_op in H. discriminate H. Qed.

Lemma refa26_not3962 : ~ @Equation3962 Fin9 refa26_inst.
Proof. unfold Equation3962. intro H. specialize (H F9_0 F9_1). unfold magma_op, refa26_inst, refa26_op in H. discriminate H. Qed.

Lemma refa26_not4068 : ~ @Equation4068 Fin9 refa26_inst.
Proof. unfold Equation4068. intro H. specialize (H F9_0 F9_1). unfold magma_op, refa26_inst, refa26_op in H. discriminate H. Qed.

Lemma refa26_not4071 : ~ @Equation4071 Fin9 refa26_inst.
Proof. unfold Equation4071. intro H. specialize (H F9_0 F9_1). unfold magma_op, refa26_inst, refa26_op in H. discriminate H. Qed.

Lemma refa26_not4073 : ~ @Equation4073 Fin9 refa26_inst.
Proof. unfold Equation4073. intro H. specialize (H F9_0 F9_1). unfold magma_op, refa26_inst, refa26_op in H. discriminate H. Qed.

Lemma refa26_not4081 : ~ @Equation4081 Fin9 refa26_inst.
Proof. unfold Equation4081. intro H. specialize (H F9_0 F9_1). unfold magma_op, refa26_inst, refa26_op in H. discriminate H. Qed.

Lemma refa26_not4083 : ~ @Equation4083 Fin9 refa26_inst.
Proof. unfold Equation4083. intro H. specialize (H F9_0 F9_1). unfold magma_op, refa26_inst, refa26_op in H. discriminate H. Qed.

Lemma refa26_not4090 : ~ @Equation4090 Fin9 refa26_inst.
Proof. unfold Equation4090. intro H. specialize (H F9_0 F9_1). unfold magma_op, refa26_inst, refa26_op in H. discriminate H. Qed.

Lemma refa26_not4120 : ~ @Equation4120 Fin9 refa26_inst.
Proof. unfold Equation4120. intro H. specialize (H F9_0 F9_1). unfold magma_op, refa26_inst, refa26_op in H. discriminate H. Qed.

Lemma refa26_not4127 : ~ @Equation4127 Fin9 refa26_inst.
Proof. unfold Equation4127. intro H. specialize (H F9_0 F9_1). unfold magma_op, refa26_inst, refa26_op in H. discriminate H. Qed.

Lemma refa26_not4131 : ~ @Equation4131 Fin9 refa26_inst.
Proof. unfold Equation4131. intro H. specialize (H F9_0 F9_1). unfold magma_op, refa26_inst, refa26_op in H. discriminate H. Qed.

Lemma refa26_not4154 : ~ @Equation4154 Fin9 refa26_inst.
Proof. unfold Equation4154. intro H. specialize (H F9_0 F9_1). unfold magma_op, refa26_inst, refa26_op in H. discriminate H. Qed.

Lemma refa26_not4158 : ~ @Equation4158 Fin9 refa26_inst.
Proof. unfold Equation4158. intro H. specialize (H F9_0 F9_1). unfold magma_op, refa26_inst, refa26_op in H. discriminate H. Qed.

Lemma refa26_not4165 : ~ @Equation4165 Fin9 refa26_inst.
Proof. unfold Equation4165. intro H. specialize (H F9_0 F9_1). unfold magma_op, refa26_inst, refa26_op in H. discriminate H. Qed.

Lemma refa26_not4270 : ~ @Equation4270 Fin9 refa26_inst.
Proof. unfold Equation4270. intro H. specialize (H F9_0 F9_1). unfold magma_op, refa26_inst, refa26_op in H. discriminate H. Qed.

Lemma refa26_not4273 : ~ @Equation4273 Fin9 refa26_inst.
Proof. unfold Equation4273. intro H. specialize (H F9_0 F9_1). unfold magma_op, refa26_inst, refa26_op in H. discriminate H. Qed.

Lemma refa26_not4275 : ~ @Equation4275 Fin9 refa26_inst.
Proof. unfold Equation4275. intro H. specialize (H F9_0 F9_1). unfold magma_op, refa26_inst, refa26_op in H. discriminate H. Qed.

Lemma refa26_not4290 : ~ @Equation4290 Fin9 refa26_inst.
Proof. unfold Equation4290. intro H. specialize (H F9_0 F9_1). unfold magma_op, refa26_inst, refa26_op in H. discriminate H. Qed.

Lemma refa26_not4320 : ~ @Equation4320 Fin9 refa26_inst.
Proof. unfold Equation4320. intro H. specialize (H F9_0 F9_1). unfold magma_op, refa26_inst, refa26_op in H. discriminate H. Qed.

Lemma refa26_not4396 : ~ @Equation4396 Fin9 refa26_inst.
Proof. unfold Equation4396. intro H. specialize (H F9_0 F9_1). unfold magma_op, refa26_inst, refa26_op in H. discriminate H. Qed.

Lemma refa26_not4433 : ~ @Equation4433 Fin9 refa26_inst.
Proof. unfold Equation4433. intro H. specialize (H F9_0 F9_1). unfold magma_op, refa26_inst, refa26_op in H. discriminate H. Qed.

Lemma refa26_not4473 : ~ @Equation4473 Fin9 refa26_inst.
Proof. unfold Equation4473. intro H. specialize (H F9_0 F9_1). unfold magma_op, refa26_inst, refa26_op in H. discriminate H. Qed.

Lemma refa26_not4480 : ~ @Equation4480 Fin9 refa26_inst.
Proof. unfold Equation4480. intro H. specialize (H F9_0 F9_1). unfold magma_op, refa26_inst, refa26_op in H. discriminate H. Qed.

Lemma refa26_not4585 : ~ @Equation4585 Fin9 refa26_inst.
Proof. unfold Equation4585. intro H. specialize (H F9_0 F9_1). unfold magma_op, refa26_inst, refa26_op in H. discriminate H. Qed.

Lemma refa26_not4588 : ~ @Equation4588 Fin9 refa26_inst.
Proof. unfold Equation4588. intro H. specialize (H F9_0 F9_1). unfold magma_op, refa26_inst, refa26_op in H. discriminate H. Qed.

Lemma refa26_not4590 : ~ @Equation4590 Fin9 refa26_inst.
Proof. unfold Equation4590. intro H. specialize (H F9_0 F9_1). unfold magma_op, refa26_inst, refa26_op in H. discriminate H. Qed.

Lemma refa26_not4598 : ~ @Equation4598 Fin9 refa26_inst.
Proof. unfold Equation4598. intro H. specialize (H F9_0 F9_1). unfold magma_op, refa26_inst, refa26_op in H. discriminate H. Qed.

Lemma refa26_not4605 : ~ @Equation4605 Fin9 refa26_inst.
Proof. unfold Equation4605. intro H. specialize (H F9_0 F9_1). unfold magma_op, refa26_inst, refa26_op in H. discriminate H. Qed.

(** ---- refa260 (Fin3) ---- *)

Definition refa260_op (x y : Fin3) : Fin3 :=
  match x, y with
  | F3_0, F3_0 => F3_1 | F3_0, F3_1 => F3_1 | F3_0, F3_2 => F3_1
  | F3_1, F3_0 => F3_2 | F3_1, F3_1 => F3_0 | F3_1, F3_2 => F3_1
  | F3_2, F3_0 => F3_2 | F3_2, F3_1 => F3_0 | F3_2, F3_2 => F3_1
  end.

#[local] Instance refa260_inst : Magma Fin3 := {| magma_op := refa260_op |}.

Lemma refa260_sat1478 : @Equation1478 Fin3 refa260_inst.
Proof. unfold Equation1478, magma_op, refa260_inst, refa260_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa260_not3862 : ~ @Equation3862 Fin3 refa260_inst.
Proof. unfold Equation3862. intro H. specialize (H F3_0). unfold magma_op, refa260_inst, refa260_op in H. discriminate H. Qed.

Lemma refa260_not4065 : ~ @Equation4065 Fin3 refa260_inst.
Proof. unfold Equation4065. intro H. specialize (H F3_0). unfold magma_op, refa260_inst, refa260_op in H. discriminate H. Qed.

(** ---- refa261 (Fin3) ---- *)

Definition refa261_op (x y : Fin3) : Fin3 :=
  match x, y with
  | F3_0, F3_0 => F3_0 | F3_0, F3_1 => F3_1 | F3_0, F3_2 => F3_2
  | F3_1, F3_0 => F3_2 | F3_1, F3_1 => F3_2 | F3_1, F3_2 => F3_0
  | F3_2, F3_0 => F3_1 | F3_2, F3_1 => F3_0 | F3_2, F3_2 => F3_1
  end.

#[local] Instance refa261_inst : Magma Fin3 := {| magma_op := refa261_op |}.

Lemma refa261_sat1435 : @Equation1435 Fin3 refa261_inst.
Proof. unfold Equation1435, magma_op, refa261_inst, refa261_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa261_sat1452 : @Equation1452 Fin3 refa261_inst.
Proof. unfold Equation1452, magma_op, refa261_inst, refa261_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa261_sat1635 : @Equation1635 Fin3 refa261_inst.
Proof. unfold Equation1635, magma_op, refa261_inst, refa261_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa261_sat3465 : @Equation3465 Fin3 refa261_inst.
Proof. unfold Equation3465, magma_op, refa261_inst, refa261_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa261_not211 : ~ @Equation211 Fin3 refa261_inst.
Proof. unfold Equation211. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa261_inst, refa261_op in H. discriminate H. Qed.

Lemma refa261_not1429 : ~ @Equation1429 Fin3 refa261_inst.
Proof. unfold Equation1429. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa261_inst, refa261_op in H. discriminate H. Qed.

Lemma refa261_not1454 : ~ @Equation1454 Fin3 refa261_inst.
Proof. unfold Equation1454. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa261_inst, refa261_op in H. discriminate H. Qed.

Lemma refa261_not2238 : ~ @Equation2238 Fin3 refa261_inst.
Proof. unfold Equation2238. intro H. specialize (H F3_1). unfold magma_op, refa261_inst, refa261_op in H. discriminate H. Qed.

Lemma refa261_not2441 : ~ @Equation2441 Fin3 refa261_inst.
Proof. unfold Equation2441. intro H. specialize (H F3_1). unfold magma_op, refa261_inst, refa261_op in H. discriminate H. Qed.

Lemma refa261_not3462 : ~ @Equation3462 Fin3 refa261_inst.
Proof. unfold Equation3462. intro H. specialize (H F3_1 F3_0). unfold magma_op, refa261_inst, refa261_op in H. discriminate H. Qed.

Lemma refa261_not3518 : ~ @Equation3518 Fin3 refa261_inst.
Proof. unfold Equation3518. intro H. specialize (H F3_1 F3_0). unfold magma_op, refa261_inst, refa261_op in H. discriminate H. Qed.

Lemma refa261_not4065 : ~ @Equation4065 Fin3 refa261_inst.
Proof. unfold Equation4065. intro H. specialize (H F3_1). unfold magma_op, refa261_inst, refa261_op in H. discriminate H. Qed.

Lemma refa261_not4283 : ~ @Equation4283 Fin3 refa261_inst.
Proof. unfold Equation4283. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa261_inst, refa261_op in H. discriminate H. Qed.

Lemma refa261_not4284 : ~ @Equation4284 Fin3 refa261_inst.
Proof. unfold Equation4284. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa261_inst, refa261_op in H. discriminate H. Qed.

Lemma refa261_not4599 : ~ @Equation4599 Fin3 refa261_inst.
Proof. unfold Equation4599. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa261_inst, refa261_op in H. discriminate H. Qed.

(** ---- refa262 (Fin3) ---- *)

Definition refa262_op (x y : Fin3) : Fin3 :=
  match x, y with
  | F3_0, F3_0 => F3_1 | F3_0, F3_1 => F3_1 | F3_0, F3_2 => F3_2
  | F3_1, F3_0 => F3_2 | F3_1, F3_1 => F3_0 | F3_1, F3_2 => F3_1
  | F3_2, F3_0 => F3_1 | F3_2, F3_1 => F3_2 | F3_2, F3_2 => F3_0
  end.

#[local] Instance refa262_inst : Magma Fin3 := {| magma_op := refa262_op |}.

Lemma refa262_sat1922 : @Equation1922 Fin3 refa262_inst.
Proof. unfold Equation1922, magma_op, refa262_inst, refa262_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa262_sat4157 : @Equation4157 Fin3 refa262_inst.
Proof. unfold Equation4157, magma_op, refa262_inst, refa262_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa262_sat4293 : @Equation4293 Fin3 refa262_inst.
Proof. unfold Equation4293, magma_op, refa262_inst, refa262_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa262_not47 : ~ @Equation47 Fin3 refa262_inst.
Proof. unfold Equation47. intro H. specialize (H F3_0). unfold magma_op, refa262_inst, refa262_op in H. discriminate H. Qed.

Lemma refa262_not1020 : ~ @Equation1020 Fin3 refa262_inst.
Proof. unfold Equation1020. intro H. specialize (H F3_0). unfold magma_op, refa262_inst, refa262_op in H. discriminate H. Qed.

Lemma refa262_not1629 : ~ @Equation1629 Fin3 refa262_inst.
Proof. unfold Equation1629. intro H. specialize (H F3_0). unfold magma_op, refa262_inst, refa262_op in H. discriminate H. Qed.

Lemma refa262_not1857 : ~ @Equation1857 Fin3 refa262_inst.
Proof. unfold Equation1857. intro H. specialize (H F3_2 F3_0). unfold magma_op, refa262_inst, refa262_op in H. discriminate H. Qed.

Lemma refa262_not1861 : ~ @Equation1861 Fin3 refa262_inst.
Proof. unfold Equation1861. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa262_inst, refa262_op in H. discriminate H. Qed.

Lemma refa262_not1894 : ~ @Equation1894 Fin3 refa262_inst.
Proof. unfold Equation1894. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa262_inst, refa262_op in H. discriminate H. Qed.

Lemma refa262_not2441 : ~ @Equation2441 Fin3 refa262_inst.
Proof. unfold Equation2441. intro H. specialize (H F3_0). unfold magma_op, refa262_inst, refa262_op in H. discriminate H. Qed.

Lemma refa262_not2644 : ~ @Equation2644 Fin3 refa262_inst.
Proof. unfold Equation2644. intro H. specialize (H F3_0). unfold magma_op, refa262_inst, refa262_op in H. discriminate H. Qed.

Lemma refa262_not3050 : ~ @Equation3050 Fin3 refa262_inst.
Proof. unfold Equation3050. intro H. specialize (H F3_0). unfold magma_op, refa262_inst, refa262_op in H. discriminate H. Qed.

Lemma refa262_not3456 : ~ @Equation3456 Fin3 refa262_inst.
Proof. unfold Equation3456. intro H. specialize (H F3_0). unfold magma_op, refa262_inst, refa262_op in H. discriminate H. Qed.

Lemma refa262_not3659 : ~ @Equation3659 Fin3 refa262_inst.
Proof. unfold Equation3659. intro H. specialize (H F3_0). unfold magma_op, refa262_inst, refa262_op in H. discriminate H. Qed.

Lemma refa262_not4068 : ~ @Equation4068 Fin3 refa262_inst.
Proof. unfold Equation4068. intro H. specialize (H F3_1 F3_0). unfold magma_op, refa262_inst, refa262_op in H. discriminate H. Qed.

Lemma refa262_not4090 : ~ @Equation4090 Fin3 refa262_inst.
Proof. unfold Equation4090. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa262_inst, refa262_op in H. discriminate H. Qed.

Lemma refa262_not4118 : ~ @Equation4118 Fin3 refa262_inst.
Proof. unfold Equation4118. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa262_inst, refa262_op in H. discriminate H. Qed.

Lemma refa262_not4165 : ~ @Equation4165 Fin3 refa262_inst.
Proof. unfold Equation4165. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa262_inst, refa262_op in H. discriminate H. Qed.

Lemma refa262_not4270 : ~ @Equation4270 Fin3 refa262_inst.
Proof. unfold Equation4270. intro H. specialize (H F3_1 F3_0). unfold magma_op, refa262_inst, refa262_op in H. discriminate H. Qed.

Lemma refa262_not4273 : ~ @Equation4273 Fin3 refa262_inst.
Proof. unfold Equation4273. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa262_inst, refa262_op in H. discriminate H. Qed.

Lemma refa262_not4320 : ~ @Equation4320 Fin3 refa262_inst.
Proof. unfold Equation4320. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa262_inst, refa262_op in H. discriminate H. Qed.

Lemma refa262_not4605 : ~ @Equation4605 Fin3 refa262_inst.
Proof. unfold Equation4605. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa262_inst, refa262_op in H. discriminate H. Qed.

Lemma refa262_not4622 : ~ @Equation4622 Fin3 refa262_inst.
Proof. unfold Equation4622. intro H. specialize (H F3_0 F3_0 F3_1). unfold magma_op, refa262_inst, refa262_op in H. discriminate H. Qed.

Lemma refa262_not4656 : ~ @Equation4656 Fin3 refa262_inst.
Proof. unfold Equation4656. intro H. specialize (H F3_0 F3_0 F3_1). unfold magma_op, refa262_inst, refa262_op in H. discriminate H. Qed.

(** ---- refa263 (Fin3) ---- *)

Definition refa263_op (x y : Fin3) : Fin3 :=
  match x, y with
  | F3_0, F3_0 => F3_0 | F3_0, F3_1 => F3_0 | F3_0, F3_2 => F3_0
  | F3_1, F3_0 => F3_0 | F3_1, F3_1 => F3_2 | F3_1, F3_2 => F3_0
  | F3_2, F3_0 => F3_0 | F3_2, F3_1 => F3_0 | F3_2, F3_2 => F3_1
  end.

#[local] Instance refa263_inst : Magma Fin3 := {| magma_op := refa263_op |}.

Lemma refa263_sat4417 : @Equation4417 Fin3 refa263_inst.
Proof. unfold Equation4417, magma_op, refa263_inst, refa263_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa263_sat4430 : @Equation4430 Fin3 refa263_inst.
Proof. unfold Equation4430, magma_op, refa263_inst, refa263_op. intros x y z w. destruct x, y, z, w; reflexivity. Qed.

Lemma refa263_sat4449 : @Equation4449 Fin3 refa263_inst.
Proof. unfold Equation4449, magma_op, refa263_inst, refa263_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa263_sat4457 : @Equation4457 Fin3 refa263_inst.
Proof. unfold Equation4457, magma_op, refa263_inst, refa263_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa263_not4270 : ~ @Equation4270 Fin3 refa263_inst.
Proof. unfold Equation4270. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa263_inst, refa263_op in H. discriminate H. Qed.

Lemma refa263_not4272 : ~ @Equation4272 Fin3 refa263_inst.
Proof. unfold Equation4272. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa263_inst, refa263_op in H. discriminate H. Qed.

Lemma refa263_not4284 : ~ @Equation4284 Fin3 refa263_inst.
Proof. unfold Equation4284. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa263_inst, refa263_op in H. discriminate H. Qed.

Lemma refa263_not4290 : ~ @Equation4290 Fin3 refa263_inst.
Proof. unfold Equation4290. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa263_inst, refa263_op in H. discriminate H. Qed.

Lemma refa263_not4314 : ~ @Equation4314 Fin3 refa263_inst.
Proof. unfold Equation4314. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa263_inst, refa263_op in H. discriminate H. Qed.

Lemma refa263_not4320 : ~ @Equation4320 Fin3 refa263_inst.
Proof. unfold Equation4320. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa263_inst, refa263_op in H. discriminate H. Qed.

Lemma refa263_not4343 : ~ @Equation4343 Fin3 refa263_inst.
Proof. unfold Equation4343. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa263_inst, refa263_op in H. discriminate H. Qed.

Lemma refa263_not4396 : ~ @Equation4396 Fin3 refa263_inst.
Proof. unfold Equation4396. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa263_inst, refa263_op in H. discriminate H. Qed.

Lemma refa263_not4408 : ~ @Equation4408 Fin3 refa263_inst.
Proof. unfold Equation4408. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa263_inst, refa263_op in H. discriminate H. Qed.

Lemma refa263_not4433 : ~ @Equation4433 Fin3 refa263_inst.
Proof. unfold Equation4433. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa263_inst, refa263_op in H. discriminate H. Qed.

Lemma refa263_not4445 : ~ @Equation4445 Fin3 refa263_inst.
Proof. unfold Equation4445. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa263_inst, refa263_op in H. discriminate H. Qed.

Lemma refa263_not4470 : ~ @Equation4470 Fin3 refa263_inst.
Proof. unfold Equation4470. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa263_inst, refa263_op in H. discriminate H. Qed.

Lemma refa263_not4472 : ~ @Equation4472 Fin3 refa263_inst.
Proof. unfold Equation4472. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa263_inst, refa263_op in H. discriminate H. Qed.

Lemma refa263_not4473 : ~ @Equation4473 Fin3 refa263_inst.
Proof. unfold Equation4473. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa263_inst, refa263_op in H. discriminate H. Qed.

Lemma refa263_not4479 : ~ @Equation4479 Fin3 refa263_inst.
Proof. unfold Equation4479. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa263_inst, refa263_op in H. discriminate H. Qed.

Lemma refa263_not4480 : ~ @Equation4480 Fin3 refa263_inst.
Proof. unfold Equation4480. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa263_inst, refa263_op in H. discriminate H. Qed.

Lemma refa263_not4583 : ~ @Equation4583 Fin3 refa263_inst.
Proof. unfold Equation4583. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa263_inst, refa263_op in H. discriminate H. Qed.

Lemma refa263_not4590 : ~ @Equation4590 Fin3 refa263_inst.
Proof. unfold Equation4590. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa263_inst, refa263_op in H. discriminate H. Qed.

Lemma refa263_not4598 : ~ @Equation4598 Fin3 refa263_inst.
Proof. unfold Equation4598. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa263_inst, refa263_op in H. discriminate H. Qed.

Lemma refa263_not4599 : ~ @Equation4599 Fin3 refa263_inst.
Proof. unfold Equation4599. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa263_inst, refa263_op in H. discriminate H. Qed.

Lemma refa263_not4605 : ~ @Equation4605 Fin3 refa263_inst.
Proof. unfold Equation4605. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa263_inst, refa263_op in H. discriminate H. Qed.

Lemma refa263_not4606 : ~ @Equation4606 Fin3 refa263_inst.
Proof. unfold Equation4606. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa263_inst, refa263_op in H. discriminate H. Qed.

Lemma refa263_not4608 : ~ @Equation4608 Fin3 refa263_inst.
Proof. unfold Equation4608. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa263_inst, refa263_op in H. discriminate H. Qed.

(** ---- refa264 (Fin3) ---- *)

Definition refa264_op (x y : Fin3) : Fin3 :=
  match x, y with
  | F3_0, F3_0 => F3_0 | F3_0, F3_1 => F3_0 | F3_0, F3_2 => F3_0
  | F3_1, F3_0 => F3_2 | F3_1, F3_1 => F3_2 | F3_1, F3_2 => F3_0
  | F3_2, F3_0 => F3_1 | F3_2, F3_1 => F3_0 | F3_2, F3_2 => F3_1
  end.

#[local] Instance refa264_inst : Magma Fin3 := {| magma_op := refa264_op |}.

Lemma refa264_sat3460 : @Equation3460 Fin3 refa264_inst.
Proof. unfold Equation3460, magma_op, refa264_inst, refa264_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa264_sat3463 : @Equation3463 Fin3 refa264_inst.
Proof. unfold Equation3463, magma_op, refa264_inst, refa264_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa264_sat4392 : @Equation4392 Fin3 refa264_inst.
Proof. unfold Equation4392, magma_op, refa264_inst, refa264_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa264_not307 : ~ @Equation307 Fin3 refa264_inst.
Proof. unfold Equation307. intro H. specialize (H F3_1). unfold magma_op, refa264_inst, refa264_op in H. discriminate H. Qed.

Lemma refa264_not3255 : ~ @Equation3255 Fin3 refa264_inst.
Proof. unfold Equation3255. intro H. specialize (H F3_1 F3_0). unfold magma_op, refa264_inst, refa264_op in H. discriminate H. Qed.

Lemma refa264_not3256 : ~ @Equation3256 Fin3 refa264_inst.
Proof. unfold Equation3256. intro H. specialize (H F3_1 F3_0). unfold magma_op, refa264_inst, refa264_op in H. discriminate H. Qed.

Lemma refa264_not3464 : ~ @Equation3464 Fin3 refa264_inst.
Proof. unfold Equation3464. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa264_inst, refa264_op in H. discriminate H. Qed.

Lemma refa264_not3469 : ~ @Equation3469 Fin3 refa264_inst.
Proof. unfold Equation3469. intro H. specialize (H F3_1 F3_2 F3_0). unfold magma_op, refa264_inst, refa264_op in H. discriminate H. Qed.

Lemma refa264_not3522 : ~ @Equation3522 Fin3 refa264_inst.
Proof. unfold Equation3522. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa264_inst, refa264_op in H. discriminate H. Qed.

Lemma refa264_not3659 : ~ @Equation3659 Fin3 refa264_inst.
Proof. unfold Equation3659. intro H. specialize (H F3_1). unfold magma_op, refa264_inst, refa264_op in H. discriminate H. Qed.

Lemma refa264_not3862 : ~ @Equation3862 Fin3 refa264_inst.
Proof. unfold Equation3862. intro H. specialize (H F3_1). unfold magma_op, refa264_inst, refa264_op in H. discriminate H. Qed.

Lemma refa264_not4065 : ~ @Equation4065 Fin3 refa264_inst.
Proof. unfold Equation4065. intro H. specialize (H F3_1). unfold magma_op, refa264_inst, refa264_op in H. discriminate H. Qed.

Lemma refa264_not4268 : ~ @Equation4268 Fin3 refa264_inst.
Proof. unfold Equation4268. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa264_inst, refa264_op in H. discriminate H. Qed.

Lemma refa264_not4269 : ~ @Equation4269 Fin3 refa264_inst.
Proof. unfold Equation4269. intro H. specialize (H F3_1 F3_0). unfold magma_op, refa264_inst, refa264_op in H. discriminate H. Qed.

Lemma refa264_not4270 : ~ @Equation4270 Fin3 refa264_inst.
Proof. unfold Equation4270. intro H. specialize (H F3_1 F3_0). unfold magma_op, refa264_inst, refa264_op in H. discriminate H. Qed.

Lemma refa264_not4272 : ~ @Equation4272 Fin3 refa264_inst.
Proof. unfold Equation4272. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa264_inst, refa264_op in H. discriminate H. Qed.

Lemma refa264_not4273 : ~ @Equation4273 Fin3 refa264_inst.
Proof. unfold Equation4273. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa264_inst, refa264_op in H. discriminate H. Qed.

Lemma refa264_not4275 : ~ @Equation4275 Fin3 refa264_inst.
Proof. unfold Equation4275. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa264_inst, refa264_op in H. discriminate H. Qed.

Lemma refa264_not4283 : ~ @Equation4283 Fin3 refa264_inst.
Proof. unfold Equation4283. intro H. specialize (H F3_1 F3_0). unfold magma_op, refa264_inst, refa264_op in H. discriminate H. Qed.

Lemma refa264_not4284 : ~ @Equation4284 Fin3 refa264_inst.
Proof. unfold Equation4284. intro H. specialize (H F3_1 F3_0). unfold magma_op, refa264_inst, refa264_op in H. discriminate H. Qed.

Lemma refa264_not4293 : ~ @Equation4293 Fin3 refa264_inst.
Proof. unfold Equation4293. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa264_inst, refa264_op in H. discriminate H. Qed.

Lemma refa264_not4320 : ~ @Equation4320 Fin3 refa264_inst.
Proof. unfold Equation4320. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa264_inst, refa264_op in H. discriminate H. Qed.

Lemma refa264_not4321 : ~ @Equation4321 Fin3 refa264_inst.
Proof. unfold Equation4321. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa264_inst, refa264_op in H. discriminate H. Qed.

Lemma refa264_not4343 : ~ @Equation4343 Fin3 refa264_inst.
Proof. unfold Equation4343. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa264_inst, refa264_op in H. discriminate H. Qed.

Lemma refa264_not4398 : ~ @Equation4398 Fin3 refa264_inst.
Proof. unfold Equation4398. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa264_inst, refa264_op in H. discriminate H. Qed.

Lemma refa264_not4433 : ~ @Equation4433 Fin3 refa264_inst.
Proof. unfold Equation4433. intro H. specialize (H F3_1 F3_0). unfold magma_op, refa264_inst, refa264_op in H. discriminate H. Qed.

Lemma refa264_not4435 : ~ @Equation4435 Fin3 refa264_inst.
Proof. unfold Equation4435. intro H. specialize (H F3_1 F3_0). unfold magma_op, refa264_inst, refa264_op in H. discriminate H. Qed.

Lemma refa264_not4443 : ~ @Equation4443 Fin3 refa264_inst.
Proof. unfold Equation4443. intro H. specialize (H F3_1 F3_0). unfold magma_op, refa264_inst, refa264_op in H. discriminate H. Qed.

Lemma refa264_not4445 : ~ @Equation4445 Fin3 refa264_inst.
Proof. unfold Equation4445. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa264_inst, refa264_op in H. discriminate H. Qed.

Lemma refa264_not4470 : ~ @Equation4470 Fin3 refa264_inst.
Proof. unfold Equation4470. intro H. specialize (H F3_1 F3_0). unfold magma_op, refa264_inst, refa264_op in H. discriminate H. Qed.

Lemma refa264_not4472 : ~ @Equation4472 Fin3 refa264_inst.
Proof. unfold Equation4472. intro H. specialize (H F3_1 F3_0). unfold magma_op, refa264_inst, refa264_op in H. discriminate H. Qed.

Lemma refa264_not4480 : ~ @Equation4480 Fin3 refa264_inst.
Proof. unfold Equation4480. intro H. specialize (H F3_1 F3_0). unfold magma_op, refa264_inst, refa264_op in H. discriminate H. Qed.

Lemma refa264_not4482 : ~ @Equation4482 Fin3 refa264_inst.
Proof. unfold Equation4482. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa264_inst, refa264_op in H. discriminate H. Qed.

Lemma refa264_not4583 : ~ @Equation4583 Fin3 refa264_inst.
Proof. unfold Equation4583. intro H. specialize (H F3_1 F3_0). unfold magma_op, refa264_inst, refa264_op in H. discriminate H. Qed.

Lemma refa264_not4598 : ~ @Equation4598 Fin3 refa264_inst.
Proof. unfold Equation4598. intro H. specialize (H F3_1 F3_0). unfold magma_op, refa264_inst, refa264_op in H. discriminate H. Qed.

Lemma refa264_not4606 : ~ @Equation4606 Fin3 refa264_inst.
Proof. unfold Equation4606. intro H. specialize (H F3_1 F3_0). unfold magma_op, refa264_inst, refa264_op in H. discriminate H. Qed.

Lemma refa264_not4608 : ~ @Equation4608 Fin3 refa264_inst.
Proof. unfold Equation4608. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa264_inst, refa264_op in H. discriminate H. Qed.

Lemma refa264_not4622 : ~ @Equation4622 Fin3 refa264_inst.
Proof. unfold Equation4622. intro H. specialize (H F3_0 F3_0 F3_1). unfold magma_op, refa264_inst, refa264_op in H. discriminate H. Qed.

(** ---- refa265 (Fin3) ---- *)

Definition refa265_op (x y : Fin3) : Fin3 :=
  match x, y with
  | F3_0, F3_0 => F3_0 | F3_0, F3_1 => F3_0 | F3_0, F3_2 => F3_2
  | F3_1, F3_0 => F3_0 | F3_1, F3_1 => F3_0 | F3_1, F3_2 => F3_2
  | F3_2, F3_0 => F3_2 | F3_2, F3_1 => F3_2 | F3_2, F3_2 => F3_1
  end.

#[local] Instance refa265_inst : Magma Fin3 := {| magma_op := refa265_op |}.

Lemma refa265_sat3553 : @Equation3553 Fin3 refa265_inst.
Proof. unfold Equation3553, magma_op, refa265_inst, refa265_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa265_sat4229 : @Equation4229 Fin3 refa265_inst.
Proof. unfold Equation4229, magma_op, refa265_inst, refa265_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa265_not3278 : ~ @Equation3278 Fin3 refa265_inst.
Proof. unfold Equation3278. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa265_inst, refa265_op in H. discriminate H. Qed.

Lemma refa265_not3472 : ~ @Equation3472 Fin3 refa265_inst.
Proof. unfold Equation3472. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa265_inst, refa265_op in H. discriminate H. Qed.

Lemma refa265_not3659 : ~ @Equation3659 Fin3 refa265_inst.
Proof. unfold Equation3659. intro H. specialize (H F3_2). unfold magma_op, refa265_inst, refa265_op in H. discriminate H. Qed.

Lemma refa265_not3878 : ~ @Equation3878 Fin3 refa265_inst.
Proof. unfold Equation3878. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa265_inst, refa265_op in H. discriminate H. Qed.

Lemma refa265_not4068 : ~ @Equation4068 Fin3 refa265_inst.
Proof. unfold Equation4068. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa265_inst, refa265_op in H. discriminate H. Qed.

Lemma refa265_not4273 : ~ @Equation4273 Fin3 refa265_inst.
Proof. unfold Equation4273. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa265_inst, refa265_op in H. discriminate H. Qed.

Lemma refa265_not4275 : ~ @Equation4275 Fin3 refa265_inst.
Proof. unfold Equation4275. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa265_inst, refa265_op in H. discriminate H. Qed.

Lemma refa265_not4647 : ~ @Equation4647 Fin3 refa265_inst.
Proof. unfold Equation4647. intro H. specialize (H F3_0 F3_0 F3_2). unfold magma_op, refa265_inst, refa265_op in H. discriminate H. Qed.

Lemma refa265_not4656 : ~ @Equation4656 Fin3 refa265_inst.
Proof. unfold Equation4656. intro H. specialize (H F3_0 F3_0 F3_2). unfold magma_op, refa265_inst, refa265_op in H. discriminate H. Qed.

(** ---- refa266 (Fin3) ---- *)

Definition refa266_op (x y : Fin3) : Fin3 :=
  match x, y with
  | F3_0, F3_0 => F3_0 | F3_0, F3_1 => F3_0 | F3_0, F3_2 => F3_1
  | F3_1, F3_0 => F3_2 | F3_1, F3_1 => F3_0 | F3_1, F3_2 => F3_2
  | F3_2, F3_0 => F3_0 | F3_2, F3_1 => F3_0 | F3_2, F3_2 => F3_1
  end.

#[local] Instance refa266_inst : Magma Fin3 := {| magma_op := refa266_op |}.

Lemma refa266_sat1427 : @Equation1427 Fin3 refa266_inst.
Proof. unfold Equation1427, magma_op, refa266_inst, refa266_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa266_sat3893 : @Equation3893 Fin3 refa266_inst.
Proof. unfold Equation3893, magma_op, refa266_inst, refa266_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa266_sat3905 : @Equation3905 Fin3 refa266_inst.
Proof. unfold Equation3905, magma_op, refa266_inst, refa266_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa266_not359 : ~ @Equation359 Fin3 refa266_inst.
Proof. unfold Equation359. intro H. specialize (H F3_2). unfold magma_op, refa266_inst, refa266_op in H. discriminate H. Qed.

Lemma refa266_not3253 : ~ @Equation3253 Fin3 refa266_inst.
Proof. unfold Equation3253. intro H. specialize (H F3_1). unfold magma_op, refa266_inst, refa266_op in H. discriminate H. Qed.

Lemma refa266_not3456 : ~ @Equation3456 Fin3 refa266_inst.
Proof. unfold Equation3456. intro H. specialize (H F3_1). unfold magma_op, refa266_inst, refa266_op in H. discriminate H. Qed.

Lemma refa266_not3867 : ~ @Equation3867 Fin3 refa266_inst.
Proof. unfold Equation3867. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa266_inst, refa266_op in H. discriminate H. Qed.

Lemma refa266_not4067 : ~ @Equation4067 Fin3 refa266_inst.
Proof. unfold Equation4067. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa266_inst, refa266_op in H. discriminate H. Qed.

Lemma refa266_not4070 : ~ @Equation4070 Fin3 refa266_inst.
Proof. unfold Equation4070. intro H. specialize (H F3_2 F3_0). unfold magma_op, refa266_inst, refa266_op in H. discriminate H. Qed.

Lemma refa266_not4083 : ~ @Equation4083 Fin3 refa266_inst.
Proof. unfold Equation4083. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa266_inst, refa266_op in H. discriminate H. Qed.

Lemma refa266_not4090 : ~ @Equation4090 Fin3 refa266_inst.
Proof. unfold Equation4090. intro H. specialize (H F3_2 F3_0). unfold magma_op, refa266_inst, refa266_op in H. discriminate H. Qed.

Lemma refa266_not4131 : ~ @Equation4131 Fin3 refa266_inst.
Proof. unfold Equation4131. intro H. specialize (H F3_1 F3_0). unfold magma_op, refa266_inst, refa266_op in H. discriminate H. Qed.

Lemma refa266_not4269 : ~ @Equation4269 Fin3 refa266_inst.
Proof. unfold Equation4269. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa266_inst, refa266_op in H. discriminate H. Qed.

Lemma refa266_not4272 : ~ @Equation4272 Fin3 refa266_inst.
Proof. unfold Equation4272. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa266_inst, refa266_op in H. discriminate H. Qed.

Lemma refa266_not4275 : ~ @Equation4275 Fin3 refa266_inst.
Proof. unfold Equation4275. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa266_inst, refa266_op in H. discriminate H. Qed.

Lemma refa266_not4284 : ~ @Equation4284 Fin3 refa266_inst.
Proof. unfold Equation4284. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa266_inst, refa266_op in H. discriminate H. Qed.

Lemma refa266_not4291 : ~ @Equation4291 Fin3 refa266_inst.
Proof. unfold Equation4291. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa266_inst, refa266_op in H. discriminate H. Qed.

Lemma refa266_not4320 : ~ @Equation4320 Fin3 refa266_inst.
Proof. unfold Equation4320. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa266_inst, refa266_op in H. discriminate H. Qed.

Lemma refa266_not4622 : ~ @Equation4622 Fin3 refa266_inst.
Proof. unfold Equation4622. intro H. specialize (H F3_0 F3_0 F3_2). unfold magma_op, refa266_inst, refa266_op in H. discriminate H. Qed.

Lemma refa266_not4631 : ~ @Equation4631 Fin3 refa266_inst.
Proof. unfold Equation4631. intro H. specialize (H F3_0 F3_0 F3_2). unfold magma_op, refa266_inst, refa266_op in H. discriminate H. Qed.

(** ---- refa267 (Fin3) ---- *)

Definition refa267_op (x y : Fin3) : Fin3 :=
  match x, y with
  | F3_0, F3_0 => F3_1 | F3_0, F3_1 => F3_1 | F3_0, F3_2 => F3_2
  | F3_1, F3_0 => F3_0 | F3_1, F3_1 => F3_2 | F3_1, F3_2 => F3_2
  | F3_2, F3_0 => F3_0 | F3_2, F3_1 => F3_1 | F3_2, F3_2 => F3_0
  end.

#[local] Instance refa267_inst : Magma Fin3 := {| magma_op := refa267_op |}.

Lemma refa267_sat3180 : @Equation3180 Fin3 refa267_inst.
Proof. unfold Equation3180, magma_op, refa267_inst, refa267_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa267_not2746 : ~ @Equation2746 Fin3 refa267_inst.
Proof. unfold Equation2746. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa267_inst, refa267_op in H. discriminate H. Qed.

(** ---- refa268 (Fin3) ---- *)

Definition refa268_op (x y : Fin3) : Fin3 :=
  match x, y with
  | F3_0, F3_0 => F3_0 | F3_0, F3_1 => F3_0 | F3_0, F3_2 => F3_0
  | F3_1, F3_0 => F3_2 | F3_1, F3_1 => F3_0 | F3_1, F3_2 => F3_1
  | F3_2, F3_0 => F3_1 | F3_2, F3_1 => F3_2 | F3_2, F3_2 => F3_2
  end.

#[local] Instance refa268_inst : Magma Fin3 := {| magma_op := refa268_op |}.

Lemma refa268_sat615 : @Equation615 Fin3 refa268_inst.
Proof. unfold Equation615, magma_op, refa268_inst, refa268_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa268_not620 : ~ @Equation620 Fin3 refa268_inst.
Proof. unfold Equation620. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa268_inst, refa268_op in H. discriminate H. Qed.

Lemma refa268_not622 : ~ @Equation622 Fin3 refa268_inst.
Proof. unfold Equation622. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa268_inst, refa268_op in H. discriminate H. Qed.

Lemma refa268_not3662 : ~ @Equation3662 Fin3 refa268_inst.
Proof. unfold Equation3662. intro H. specialize (H F3_2 F3_0). unfold magma_op, refa268_inst, refa268_op in H. discriminate H. Qed.

(** ---- refa269 (Fin3) ---- *)

Definition refa269_op (x y : Fin3) : Fin3 :=
  match x, y with
  | F3_0, F3_0 => F3_0 | F3_0, F3_1 => F3_0 | F3_0, F3_2 => F3_0
  | F3_1, F3_0 => F3_1 | F3_1, F3_1 => F3_0 | F3_1, F3_2 => F3_0
  | F3_2, F3_0 => F3_2 | F3_2, F3_1 => F3_1 | F3_2, F3_2 => F3_1
  end.

#[local] Instance refa269_inst : Magma Fin3 := {| magma_op := refa269_op |}.

Lemma refa269_sat837 : @Equation837 Fin3 refa269_inst.
Proof. unfold Equation837, magma_op, refa269_inst, refa269_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa269_sat1051 : @Equation1051 Fin3 refa269_inst.
Proof. unfold Equation1051, magma_op, refa269_inst, refa269_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa269_not411 : ~ @Equation411 Fin3 refa269_inst.
Proof. unfold Equation411. intro H. specialize (H F3_2). unfold magma_op, refa269_inst, refa269_op in H. discriminate H. Qed.

Lemma refa269_not819 : ~ @Equation819 Fin3 refa269_inst.
Proof. unfold Equation819. intro H. specialize (H F3_2 F3_0). unfold magma_op, refa269_inst, refa269_op in H. discriminate H. Qed.

Lemma refa269_not832 : ~ @Equation832 Fin3 refa269_inst.
Proof. unfold Equation832. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa269_inst, refa269_op in H. discriminate H. Qed.

Lemma refa269_not833 : ~ @Equation833 Fin3 refa269_inst.
Proof. unfold Equation833. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa269_inst, refa269_op in H. discriminate H. Qed.

Lemma refa269_not842 : ~ @Equation842 Fin3 refa269_inst.
Proof. unfold Equation842. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa269_inst, refa269_op in H. discriminate H. Qed.

Lemma refa269_not843 : ~ @Equation843 Fin3 refa269_inst.
Proof. unfold Equation843. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa269_inst, refa269_op in H. discriminate H. Qed.

Lemma refa269_not1028 : ~ @Equation1028 Fin3 refa269_inst.
Proof. unfold Equation1028. intro H. specialize (H F3_2 F3_0). unfold magma_op, refa269_inst, refa269_op in H. discriminate H. Qed.

Lemma refa269_not1035 : ~ @Equation1035 Fin3 refa269_inst.
Proof. unfold Equation1035. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa269_inst, refa269_op in H. discriminate H. Qed.

Lemma refa269_not1038 : ~ @Equation1038 Fin3 refa269_inst.
Proof. unfold Equation1038. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa269_inst, refa269_op in H. discriminate H. Qed.

Lemma refa269_not1229 : ~ @Equation1229 Fin3 refa269_inst.
Proof. unfold Equation1229. intro H. specialize (H F3_2 F3_0). unfold magma_op, refa269_inst, refa269_op in H. discriminate H. Qed.

Lemma refa269_not1832 : ~ @Equation1832 Fin3 refa269_inst.
Proof. unfold Equation1832. intro H. specialize (H F3_2). unfold magma_op, refa269_inst, refa269_op in H. discriminate H. Qed.

Lemma refa269_not3255 : ~ @Equation3255 Fin3 refa269_inst.
Proof. unfold Equation3255. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa269_inst, refa269_op in H. discriminate H. Qed.

Lemma refa269_not3278 : ~ @Equation3278 Fin3 refa269_inst.
Proof. unfold Equation3278. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa269_inst, refa269_op in H. discriminate H. Qed.

Lemma refa269_not3306 : ~ @Equation3306 Fin3 refa269_inst.
Proof. unfold Equation3306. intro H. specialize (H F3_2 F3_0). unfold magma_op, refa269_inst, refa269_op in H. discriminate H. Qed.

Lemma refa269_not3316 : ~ @Equation3316 Fin3 refa269_inst.
Proof. unfold Equation3316. intro H. specialize (H F3_2 F3_1). unfold magma_op, refa269_inst, refa269_op in H. discriminate H. Qed.

Lemma refa269_not3659 : ~ @Equation3659 Fin3 refa269_inst.
Proof. unfold Equation3659. intro H. specialize (H F3_2). unfold magma_op, refa269_inst, refa269_op in H. discriminate H. Qed.

Lemma refa269_not3862 : ~ @Equation3862 Fin3 refa269_inst.
Proof. unfold Equation3862. intro H. specialize (H F3_2). unfold magma_op, refa269_inst, refa269_op in H. discriminate H. Qed.

Lemma refa269_not4065 : ~ @Equation4065 Fin3 refa269_inst.
Proof. unfold Equation4065. intro H. specialize (H F3_2). unfold magma_op, refa269_inst, refa269_op in H. discriminate H. Qed.

Lemma refa269_not4269 : ~ @Equation4269 Fin3 refa269_inst.
Proof. unfold Equation4269. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa269_inst, refa269_op in H. discriminate H. Qed.

Lemma refa269_not4606 : ~ @Equation4606 Fin3 refa269_inst.
Proof. unfold Equation4606. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa269_inst, refa269_op in H. discriminate H. Qed.

Lemma refa269_not4622 : ~ @Equation4622 Fin3 refa269_inst.
Proof. unfold Equation4622. intro H. specialize (H F3_0 F3_0 F3_2). unfold magma_op, refa269_inst, refa269_op in H. discriminate H. Qed.

Lemma refa269_not4631 : ~ @Equation4631 Fin3 refa269_inst.
Proof. unfold Equation4631. intro H. specialize (H F3_2 F3_0 F3_1). unfold magma_op, refa269_inst, refa269_op in H. discriminate H. Qed.

(** ---- refa27 (Fin9) ---- *)

Definition refa27_op (x y : Fin9) : Fin9 :=
  match x, y with
  | F9_0, F9_0 => F9_0 | F9_0, F9_1 => F9_2 | F9_0, F9_2 => F9_3 | F9_0, F9_3 => F9_4 | F9_0, F9_4 => F9_1 | F9_0, F9_5 => F9_6 | F9_0, F9_6 => F9_7 | F9_0, F9_7 => F9_8 | F9_0, F9_8 => F9_5
  | F9_1, F9_0 => F9_5 | F9_1, F9_1 => F9_1 | F9_1, F9_2 => F9_7 | F9_1, F9_3 => F9_8 | F9_1, F9_4 => F9_2 | F9_1, F9_5 => F9_3 | F9_1, F9_6 => F9_4 | F9_1, F9_7 => F9_6 | F9_1, F9_8 => F9_0
  | F9_2, F9_0 => F9_8 | F9_2, F9_1 => F9_3 | F9_2, F9_2 => F9_2 | F9_2, F9_3 => F9_6 | F9_2, F9_4 => F9_7 | F9_2, F9_5 => F9_1 | F9_2, F9_6 => F9_5 | F9_2, F9_7 => F9_0 | F9_2, F9_8 => F9_4
  | F9_3, F9_0 => F9_7 | F9_3, F9_1 => F9_6 | F9_3, F9_2 => F9_4 | F9_3, F9_3 => F9_3 | F9_3, F9_4 => F9_5 | F9_3, F9_5 => F9_8 | F9_3, F9_6 => F9_0 | F9_3, F9_7 => F9_1 | F9_3, F9_8 => F9_2
  | F9_4, F9_0 => F9_6 | F9_4, F9_1 => F9_8 | F9_4, F9_2 => F9_5 | F9_4, F9_3 => F9_1 | F9_4, F9_4 => F9_4 | F9_4, F9_5 => F9_0 | F9_4, F9_6 => F9_2 | F9_4, F9_7 => F9_3 | F9_4, F9_8 => F9_7
  | F9_5, F9_0 => F9_3 | F9_5, F9_1 => F9_4 | F9_5, F9_2 => F9_0 | F9_5, F9_3 => F9_7 | F9_5, F9_4 => F9_8 | F9_5, F9_5 => F9_5 | F9_5, F9_6 => F9_1 | F9_5, F9_7 => F9_2 | F9_5, F9_8 => F9_6
  | F9_6, F9_0 => F9_2 | F9_6, F9_1 => F9_0 | F9_6, F9_2 => F9_8 | F9_6, F9_3 => F9_5 | F9_6, F9_4 => F9_3 | F9_6, F9_5 => F9_7 | F9_6, F9_6 => F9_6 | F9_6, F9_7 => F9_4 | F9_6, F9_8 => F9_1
  | F9_7, F9_0 => F9_1 | F9_7, F9_1 => F9_5 | F9_7, F9_2 => F9_6 | F9_7, F9_3 => F9_2 | F9_7, F9_4 => F9_0 | F9_7, F9_5 => F9_4 | F9_7, F9_6 => F9_8 | F9_7, F9_7 => F9_7 | F9_7, F9_8 => F9_3
  | F9_8, F9_0 => F9_4 | F9_8, F9_1 => F9_7 | F9_8, F9_2 => F9_1 | F9_8, F9_3 => F9_0 | F9_8, F9_4 => F9_6 | F9_8, F9_5 => F9_2 | F9_8, F9_6 => F9_3 | F9_8, F9_7 => F9_5 | F9_8, F9_8 => F9_8
  end.

#[local] Instance refa27_inst : Magma Fin9 := {| magma_op := refa27_op |}.

Lemma refa27_sat474 : @Equation474 Fin9 refa27_inst.
Proof. unfold Equation474, magma_op, refa27_inst, refa27_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa27_sat3113 : @Equation3113 Fin9 refa27_inst.
Proof. unfold Equation3113, magma_op, refa27_inst, refa27_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa27_not436 : ~ @Equation436 Fin9 refa27_inst.
Proof. unfold Equation436. intro H. specialize (H F9_0 F9_1). unfold magma_op, refa27_inst, refa27_op in H. discriminate H. Qed.

Lemma refa27_not440 : ~ @Equation440 Fin9 refa27_inst.
Proof. unfold Equation440. intro H. specialize (H F9_0 F9_1). unfold magma_op, refa27_inst, refa27_op in H. discriminate H. Qed.

Lemma refa27_not464 : ~ @Equation464 Fin9 refa27_inst.
Proof. unfold Equation464. intro H. specialize (H F9_0 F9_1). unfold magma_op, refa27_inst, refa27_op in H. discriminate H. Qed.

Lemma refa27_not466 : ~ @Equation466 Fin9 refa27_inst.
Proof. unfold Equation466. intro H. specialize (H F9_0 F9_1). unfold magma_op, refa27_inst, refa27_op in H. discriminate H. Qed.

Lemma refa27_not467 : ~ @Equation467 Fin9 refa27_inst.
Proof. unfold Equation467. intro H. specialize (H F9_0 F9_1). unfold magma_op, refa27_inst, refa27_op in H. discriminate H. Qed.

Lemma refa27_not477 : ~ @Equation477 Fin9 refa27_inst.
Proof. unfold Equation477. intro H. specialize (H F9_0 F9_1). unfold magma_op, refa27_inst, refa27_op in H. discriminate H. Qed.

Lemma refa27_not504 : ~ @Equation504 Fin9 refa27_inst.
Proof. unfold Equation504. intro H. specialize (H F9_0 F9_1). unfold magma_op, refa27_inst, refa27_op in H. discriminate H. Qed.

Lemma refa27_not511 : ~ @Equation511 Fin9 refa27_inst.
Proof. unfold Equation511. intro H. specialize (H F9_0 F9_1). unfold magma_op, refa27_inst, refa27_op in H. discriminate H. Qed.

Lemma refa27_not615 : ~ @Equation615 Fin9 refa27_inst.
Proof. unfold Equation615. intro H. specialize (H F9_0 F9_1). unfold magma_op, refa27_inst, refa27_op in H. discriminate H. Qed.

Lemma refa27_not623 : ~ @Equation623 Fin9 refa27_inst.
Proof. unfold Equation623. intro H. specialize (H F9_0 F9_1). unfold magma_op, refa27_inst, refa27_op in H. discriminate H. Qed.

Lemma refa27_not633 : ~ @Equation633 Fin9 refa27_inst.
Proof. unfold Equation633. intro H. specialize (H F9_0 F9_1). unfold magma_op, refa27_inst, refa27_op in H. discriminate H. Qed.

Lemma refa27_not646 : ~ @Equation646 Fin9 refa27_inst.
Proof. unfold Equation646. intro H. specialize (H F9_0 F9_0 F9_1). unfold magma_op, refa27_inst, refa27_op in H. discriminate H. Qed.

Lemma refa27_not667 : ~ @Equation667 Fin9 refa27_inst.
Proof. unfold Equation667. intro H. specialize (H F9_0 F9_1). unfold magma_op, refa27_inst, refa27_op in H. discriminate H. Qed.

Lemma refa27_not670 : ~ @Equation670 Fin9 refa27_inst.
Proof. unfold Equation670. intro H. specialize (H F9_0 F9_1). unfold magma_op, refa27_inst, refa27_op in H. discriminate H. Qed.

Lemma refa27_not677 : ~ @Equation677 Fin9 refa27_inst.
Proof. unfold Equation677. intro H. specialize (H F9_0 F9_1). unfold magma_op, refa27_inst, refa27_op in H. discriminate H. Qed.

Lemma refa27_not680 : ~ @Equation680 Fin9 refa27_inst.
Proof. unfold Equation680. intro H. specialize (H F9_0 F9_1). unfold magma_op, refa27_inst, refa27_op in H. discriminate H. Qed.

Lemma refa27_not818 : ~ @Equation818 Fin9 refa27_inst.
Proof. unfold Equation818. intro H. specialize (H F9_0 F9_1). unfold magma_op, refa27_inst, refa27_op in H. discriminate H. Qed.

Lemma refa27_not820 : ~ @Equation820 Fin9 refa27_inst.
Proof. unfold Equation820. intro H. specialize (H F9_0 F9_1). unfold magma_op, refa27_inst, refa27_op in H. discriminate H. Qed.

Lemma refa27_not823 : ~ @Equation823 Fin9 refa27_inst.
Proof. unfold Equation823. intro H. specialize (H F9_0 F9_1). unfold magma_op, refa27_inst, refa27_op in H. discriminate H. Qed.

Lemma refa27_not826 : ~ @Equation826 Fin9 refa27_inst.
Proof. unfold Equation826. intro H. specialize (H F9_0 F9_1). unfold magma_op, refa27_inst, refa27_op in H. discriminate H. Qed.

Lemma refa27_not835 : ~ @Equation835 Fin9 refa27_inst.
Proof. unfold Equation835. intro H. specialize (H F9_0 F9_1). unfold magma_op, refa27_inst, refa27_op in H. discriminate H. Qed.

Lemma refa27_not836 : ~ @Equation836 Fin9 refa27_inst.
Proof. unfold Equation836. intro H. specialize (H F9_0 F9_1). unfold magma_op, refa27_inst, refa27_op in H. discriminate H. Qed.

Lemma refa27_not842 : ~ @Equation842 Fin9 refa27_inst.
Proof. unfold Equation842. intro H. specialize (H F9_0 F9_1). unfold magma_op, refa27_inst, refa27_op in H. discriminate H. Qed.

Lemma refa27_not843 : ~ @Equation843 Fin9 refa27_inst.
Proof. unfold Equation843. intro H. specialize (H F9_0 F9_1). unfold magma_op, refa27_inst, refa27_op in H. discriminate H. Qed.

Lemma refa27_not846 : ~ @Equation846 Fin9 refa27_inst.
Proof. unfold Equation846. intro H. specialize (H F9_0 F9_1). unfold magma_op, refa27_inst, refa27_op in H. discriminate H. Qed.

Lemma refa27_not870 : ~ @Equation870 Fin9 refa27_inst.
Proof. unfold Equation870. intro H. specialize (H F9_0 F9_1). unfold magma_op, refa27_inst, refa27_op in H. discriminate H. Qed.

Lemma refa27_not873 : ~ @Equation873 Fin9 refa27_inst.
Proof. unfold Equation873. intro H. specialize (H F9_0 F9_1). unfold magma_op, refa27_inst, refa27_op in H. discriminate H. Qed.

Lemma refa27_not882 : ~ @Equation882 Fin9 refa27_inst.
Proof. unfold Equation882. intro H. specialize (H F9_0 F9_1). unfold magma_op, refa27_inst, refa27_op in H. discriminate H. Qed.

Lemma refa27_not883 : ~ @Equation883 Fin9 refa27_inst.
Proof. unfold Equation883. intro H. specialize (H F9_0 F9_1). unfold magma_op, refa27_inst, refa27_op in H. discriminate H. Qed.

Lemma refa27_not906 : ~ @Equation906 Fin9 refa27_inst.
Proof. unfold Equation906. intro H. specialize (H F9_0 F9_1). unfold magma_op, refa27_inst, refa27_op in H. discriminate H. Qed.

Lemma refa27_not907 : ~ @Equation907 Fin9 refa27_inst.
Proof. unfold Equation907. intro H. specialize (H F9_0 F9_1). unfold magma_op, refa27_inst, refa27_op in H. discriminate H. Qed.

Lemma refa27_not917 : ~ @Equation917 Fin9 refa27_inst.
Proof. unfold Equation917. intro H. specialize (H F9_0 F9_1). unfold magma_op, refa27_inst, refa27_op in H. discriminate H. Qed.

Lemma refa27_not1021 : ~ @Equation1021 Fin9 refa27_inst.
Proof. unfold Equation1021. intro H. specialize (H F9_0 F9_1). unfold magma_op, refa27_inst, refa27_op in H. discriminate H. Qed.

Lemma refa27_not1023 : ~ @Equation1023 Fin9 refa27_inst.
Proof. unfold Equation1023. intro H. specialize (H F9_0 F9_1). unfold magma_op, refa27_inst, refa27_op in H. discriminate H. Qed.

Lemma refa27_not1028 : ~ @Equation1028 Fin9 refa27_inst.
Proof. unfold Equation1028. intro H. specialize (H F9_0 F9_1). unfold magma_op, refa27_inst, refa27_op in H. discriminate H. Qed.

Lemma refa27_not1029 : ~ @Equation1029 Fin9 refa27_inst.
Proof. unfold Equation1029. intro H. specialize (H F9_0 F9_1). unfold magma_op, refa27_inst, refa27_op in H. discriminate H. Qed.

Lemma refa27_not1036 : ~ @Equation1036 Fin9 refa27_inst.
Proof. unfold Equation1036. intro H. specialize (H F9_0 F9_1). unfold magma_op, refa27_inst, refa27_op in H. discriminate H. Qed.

Lemma refa27_not1039 : ~ @Equation1039 Fin9 refa27_inst.
Proof. unfold Equation1039. intro H. specialize (H F9_0 F9_1). unfold magma_op, refa27_inst, refa27_op in H. discriminate H. Qed.

Lemma refa27_not1045 : ~ @Equation1045 Fin9 refa27_inst.
Proof. unfold Equation1045. intro H. specialize (H F9_0 F9_1). unfold magma_op, refa27_inst, refa27_op in H. discriminate H. Qed.

Lemma refa27_not1049 : ~ @Equation1049 Fin9 refa27_inst.
Proof. unfold Equation1049. intro H. specialize (H F9_0 F9_1). unfold magma_op, refa27_inst, refa27_op in H. discriminate H. Qed.

Lemma refa27_not1075 : ~ @Equation1075 Fin9 refa27_inst.
Proof. unfold Equation1075. intro H. specialize (H F9_0 F9_1). unfold magma_op, refa27_inst, refa27_op in H. discriminate H. Qed.

Lemma refa27_not1076 : ~ @Equation1076 Fin9 refa27_inst.
Proof. unfold Equation1076. intro H. specialize (H F9_0 F9_1). unfold magma_op, refa27_inst, refa27_op in H. discriminate H. Qed.

Lemma refa27_not1083 : ~ @Equation1083 Fin9 refa27_inst.
Proof. unfold Equation1083. intro H. specialize (H F9_0 F9_1). unfold magma_op, refa27_inst, refa27_op in H. discriminate H. Qed.

Lemma refa27_not1086 : ~ @Equation1086 Fin9 refa27_inst.
Proof. unfold Equation1086. intro H. specialize (H F9_0 F9_1). unfold magma_op, refa27_inst, refa27_op in H. discriminate H. Qed.

Lemma refa27_not1109 : ~ @Equation1109 Fin9 refa27_inst.
Proof. unfold Equation1109. intro H. specialize (H F9_0 F9_1). unfold magma_op, refa27_inst, refa27_op in H. discriminate H. Qed.

Lemma refa27_not1113 : ~ @Equation1113 Fin9 refa27_inst.
Proof. unfold Equation1113. intro H. specialize (H F9_0 F9_1). unfold magma_op, refa27_inst, refa27_op in H. discriminate H. Qed.

Lemma refa27_not1122 : ~ @Equation1122 Fin9 refa27_inst.
Proof. unfold Equation1122. intro H. specialize (H F9_0 F9_1). unfold magma_op, refa27_inst, refa27_op in H. discriminate H. Qed.

Lemma refa27_not1224 : ~ @Equation1224 Fin9 refa27_inst.
Proof. unfold Equation1224. intro H. specialize (H F9_0 F9_1). unfold magma_op, refa27_inst, refa27_op in H. discriminate H. Qed.

Lemma refa27_not1232 : ~ @Equation1232 Fin9 refa27_inst.
Proof. unfold Equation1232. intro H. specialize (H F9_0 F9_1). unfold magma_op, refa27_inst, refa27_op in H. discriminate H. Qed.

Lemma refa27_not1242 : ~ @Equation1242 Fin9 refa27_inst.
Proof. unfold Equation1242. intro H. specialize (H F9_0 F9_1). unfold magma_op, refa27_inst, refa27_op in H. discriminate H. Qed.

Lemma refa27_not1249 : ~ @Equation1249 Fin9 refa27_inst.
Proof. unfold Equation1249. intro H. specialize (H F9_0 F9_1). unfold magma_op, refa27_inst, refa27_op in H. discriminate H. Qed.

Lemma refa27_not1279 : ~ @Equation1279 Fin9 refa27_inst.
Proof. unfold Equation1279. intro H. specialize (H F9_0 F9_1). unfold magma_op, refa27_inst, refa27_op in H. discriminate H. Qed.

Lemma refa27_not1286 : ~ @Equation1286 Fin9 refa27_inst.
Proof. unfold Equation1286. intro H. specialize (H F9_0 F9_1). unfold magma_op, refa27_inst, refa27_op in H. discriminate H. Qed.

Lemma refa27_not1289 : ~ @Equation1289 Fin9 refa27_inst.
Proof. unfold Equation1289. intro H. specialize (H F9_0 F9_1). unfold magma_op, refa27_inst, refa27_op in H. discriminate H. Qed.

Lemma refa27_not1313 : ~ @Equation1313 Fin9 refa27_inst.
Proof. unfold Equation1313. intro H. specialize (H F9_0 F9_1). unfold magma_op, refa27_inst, refa27_op in H. discriminate H. Qed.

Lemma refa27_not1427 : ~ @Equation1427 Fin9 refa27_inst.
Proof. unfold Equation1427. intro H. specialize (H F9_0 F9_1). unfold magma_op, refa27_inst, refa27_op in H. discriminate H. Qed.

Lemma refa27_not1435 : ~ @Equation1435 Fin9 refa27_inst.
Proof. unfold Equation1435. intro H. specialize (H F9_0 F9_1). unfold magma_op, refa27_inst, refa27_op in H. discriminate H. Qed.

Lemma refa27_not1445 : ~ @Equation1445 Fin9 refa27_inst.
Proof. unfold Equation1445. intro H. specialize (H F9_0 F9_1). unfold magma_op, refa27_inst, refa27_op in H. discriminate H. Qed.

Lemma refa27_not1455 : ~ @Equation1455 Fin9 refa27_inst.
Proof. unfold Equation1455. intro H. specialize (H F9_0 F9_1). unfold magma_op, refa27_inst, refa27_op in H. discriminate H. Qed.

Lemma refa27_not1486 : ~ @Equation1486 Fin9 refa27_inst.
Proof. unfold Equation1486. intro H. specialize (H F9_0 F9_0 F9_1). unfold magma_op, refa27_inst, refa27_op in H. discriminate H. Qed.

Lemma refa27_not1489 : ~ @Equation1489 Fin9 refa27_inst.
Proof. unfold Equation1489. intro H. specialize (H F9_0 F9_1). unfold magma_op, refa27_inst, refa27_op in H. discriminate H. Qed.

Lemma refa27_not1516 : ~ @Equation1516 Fin9 refa27_inst.
Proof. unfold Equation1516. intro H. specialize (H F9_0 F9_1). unfold magma_op, refa27_inst, refa27_op in H. discriminate H. Qed.

Lemma refa27_not1630 : ~ @Equation1630 Fin9 refa27_inst.
Proof. unfold Equation1630. intro H. specialize (H F9_0 F9_1). unfold magma_op, refa27_inst, refa27_op in H. discriminate H. Qed.

Lemma refa27_not1635 : ~ @Equation1635 Fin9 refa27_inst.
Proof. unfold Equation1635. intro H. specialize (H F9_0 F9_1). unfold magma_op, refa27_inst, refa27_op in H. discriminate H. Qed.

Lemma refa27_not1637 : ~ @Equation1637 Fin9 refa27_inst.
Proof. unfold Equation1637. intro H. specialize (H F9_0 F9_1). unfold magma_op, refa27_inst, refa27_op in H. discriminate H. Qed.

Lemma refa27_not1638 : ~ @Equation1638 Fin9 refa27_inst.
Proof. unfold Equation1638. intro H. specialize (H F9_0 F9_1). unfold magma_op, refa27_inst, refa27_op in H. discriminate H. Qed.

Lemma refa27_not1645 : ~ @Equation1645 Fin9 refa27_inst.
Proof. unfold Equation1645. intro H. specialize (H F9_0 F9_1). unfold magma_op, refa27_inst, refa27_op in H. discriminate H. Qed.

Lemma refa27_not1648 : ~ @Equation1648 Fin9 refa27_inst.
Proof. unfold Equation1648. intro H. specialize (H F9_0 F9_1). unfold magma_op, refa27_inst, refa27_op in H. discriminate H. Qed.

Lemma refa27_not1655 : ~ @Equation1655 Fin9 refa27_inst.
Proof. unfold Equation1655. intro H. specialize (H F9_0 F9_1). unfold magma_op, refa27_inst, refa27_op in H. discriminate H. Qed.

Lemma refa27_not1658 : ~ @Equation1658 Fin9 refa27_inst.
Proof. unfold Equation1658. intro H. specialize (H F9_0 F9_1). unfold magma_op, refa27_inst, refa27_op in H. discriminate H. Qed.

Lemma refa27_not1685 : ~ @Equation1685 Fin9 refa27_inst.
Proof. unfold Equation1685. intro H. specialize (H F9_0 F9_1). unfold magma_op, refa27_inst, refa27_op in H. discriminate H. Qed.

Lemma refa27_not1691 : ~ @Equation1691 Fin9 refa27_inst.
Proof. unfold Equation1691. intro H. specialize (H F9_0 F9_1). unfold magma_op, refa27_inst, refa27_op in H. discriminate H. Qed.

Lemma refa27_not1692 : ~ @Equation1692 Fin9 refa27_inst.
Proof. unfold Equation1692. intro H. specialize (H F9_0 F9_1). unfold magma_op, refa27_inst, refa27_op in H. discriminate H. Qed.

Lemma refa27_not1719 : ~ @Equation1719 Fin9 refa27_inst.
Proof. unfold Equation1719. intro H. specialize (H F9_0 F9_1). unfold magma_op, refa27_inst, refa27_op in H. discriminate H. Qed.

Lemma refa27_not1731 : ~ @Equation1731 Fin9 refa27_inst.
Proof. unfold Equation1731. intro H. specialize (H F9_0 F9_1). unfold magma_op, refa27_inst, refa27_op in H. discriminate H. Qed.

Lemma refa27_not1833 : ~ @Equation1833 Fin9 refa27_inst.
Proof. unfold Equation1833. intro H. specialize (H F9_0 F9_1). unfold magma_op, refa27_inst, refa27_op in H. discriminate H. Qed.

Lemma refa27_not1840 : ~ @Equation1840 Fin9 refa27_inst.
Proof. unfold Equation1840. intro H. specialize (H F9_0 F9_1). unfold magma_op, refa27_inst, refa27_op in H. discriminate H. Qed.

Lemma refa27_not1841 : ~ @Equation1841 Fin9 refa27_inst.
Proof. unfold Equation1841. intro H. specialize (H F9_0 F9_1). unfold magma_op, refa27_inst, refa27_op in H. discriminate H. Qed.

Lemma refa27_not1848 : ~ @Equation1848 Fin9 refa27_inst.
Proof. unfold Equation1848. intro H. specialize (H F9_0 F9_1). unfold magma_op, refa27_inst, refa27_op in H. discriminate H. Qed.

Lemma refa27_not1857 : ~ @Equation1857 Fin9 refa27_inst.
Proof. unfold Equation1857. intro H. specialize (H F9_0 F9_1). unfold magma_op, refa27_inst, refa27_op in H. discriminate H. Qed.

Lemma refa27_not1858 : ~ @Equation1858 Fin9 refa27_inst.
Proof. unfold Equation1858. intro H. specialize (H F9_0 F9_1). unfold magma_op, refa27_inst, refa27_op in H. discriminate H. Qed.

Lemma refa27_not1861 : ~ @Equation1861 Fin9 refa27_inst.
Proof. unfold Equation1861. intro H. specialize (H F9_0 F9_1). unfold magma_op, refa27_inst, refa27_op in H. discriminate H. Qed.

Lemma refa27_not1887 : ~ @Equation1887 Fin9 refa27_inst.
Proof. unfold Equation1887. intro H. specialize (H F9_0 F9_1). unfold magma_op, refa27_inst, refa27_op in H. discriminate H. Qed.

Lemma refa27_not1888 : ~ @Equation1888 Fin9 refa27_inst.
Proof. unfold Equation1888. intro H. specialize (H F9_0 F9_1). unfold magma_op, refa27_inst, refa27_op in H. discriminate H. Qed.

Lemma refa27_not1895 : ~ @Equation1895 Fin9 refa27_inst.
Proof. unfold Equation1895. intro H. specialize (H F9_0 F9_1). unfold magma_op, refa27_inst, refa27_op in H. discriminate H. Qed.

Lemma refa27_not1921 : ~ @Equation1921 Fin9 refa27_inst.
Proof. unfold Equation1921. intro H. specialize (H F9_0 F9_1). unfold magma_op, refa27_inst, refa27_op in H. discriminate H. Qed.

Lemma refa27_not1922 : ~ @Equation1922 Fin9 refa27_inst.
Proof. unfold Equation1922. intro H. specialize (H F9_0 F9_1). unfold magma_op, refa27_inst, refa27_op in H. discriminate H. Qed.

Lemma refa27_not1925 : ~ @Equation1925 Fin9 refa27_inst.
Proof. unfold Equation1925. intro H. specialize (H F9_0 F9_1). unfold magma_op, refa27_inst, refa27_op in H. discriminate H. Qed.

Lemma refa27_not2036 : ~ @Equation2036 Fin9 refa27_inst.
Proof. unfold Equation2036. intro H. specialize (H F9_0 F9_1). unfold magma_op, refa27_inst, refa27_op in H. discriminate H. Qed.

Lemma refa27_not2044 : ~ @Equation2044 Fin9 refa27_inst.
Proof. unfold Equation2044. intro H. specialize (H F9_0 F9_1). unfold magma_op, refa27_inst, refa27_op in H. discriminate H. Qed.

Lemma refa27_not2054 : ~ @Equation2054 Fin9 refa27_inst.
Proof. unfold Equation2054. intro H. specialize (H F9_0 F9_1). unfold magma_op, refa27_inst, refa27_op in H. discriminate H. Qed.

Lemma refa27_not2061 : ~ @Equation2061 Fin9 refa27_inst.
Proof. unfold Equation2061. intro H. specialize (H F9_0 F9_1). unfold magma_op, refa27_inst, refa27_op in H. discriminate H. Qed.

Lemma refa27_not2088 : ~ @Equation2088 Fin9 refa27_inst.
Proof. unfold Equation2088. intro H. specialize (H F9_0 F9_1). unfold magma_op, refa27_inst, refa27_op in H. discriminate H. Qed.

Lemma refa27_not2244 : ~ @Equation2244 Fin9 refa27_inst.
Proof. unfold Equation2244. intro H. specialize (H F9_0 F9_1). unfold magma_op, refa27_inst, refa27_op in H. discriminate H. Qed.

Lemma refa27_not2247 : ~ @Equation2247 Fin9 refa27_inst.
Proof. unfold Equation2247. intro H. specialize (H F9_0 F9_1). unfold magma_op, refa27_inst, refa27_op in H. discriminate H. Qed.

Lemma refa27_not2257 : ~ @Equation2257 Fin9 refa27_inst.
Proof. unfold Equation2257. intro H. specialize (H F9_0 F9_1). unfold magma_op, refa27_inst, refa27_op in H. discriminate H. Qed.

Lemma refa27_not2264 : ~ @Equation2264 Fin9 refa27_inst.
Proof. unfold Equation2264. intro H. specialize (H F9_0 F9_1). unfold magma_op, refa27_inst, refa27_op in H. discriminate H. Qed.

Lemma refa27_not2294 : ~ @Equation2294 Fin9 refa27_inst.
Proof. unfold Equation2294. intro H. specialize (H F9_0 F9_1). unfold magma_op, refa27_inst, refa27_op in H. discriminate H. Qed.

Lemma refa27_not2301 : ~ @Equation2301 Fin9 refa27_inst.
Proof. unfold Equation2301. intro H. specialize (H F9_0 F9_1). unfold magma_op, refa27_inst, refa27_op in H. discriminate H. Qed.

Lemma refa27_not2338 : ~ @Equation2338 Fin9 refa27_inst.
Proof. unfold Equation2338. intro H. specialize (H F9_0 F9_1). unfold magma_op, refa27_inst, refa27_op in H. discriminate H. Qed.

Lemma refa27_not2444 : ~ @Equation2444 Fin9 refa27_inst.
Proof. unfold Equation2444. intro H. specialize (H F9_0 F9_1). unfold magma_op, refa27_inst, refa27_op in H. discriminate H. Qed.

Lemma refa27_not2447 : ~ @Equation2447 Fin9 refa27_inst.
Proof. unfold Equation2447. intro H. specialize (H F9_0 F9_1). unfold magma_op, refa27_inst, refa27_op in H. discriminate H. Qed.

Lemma refa27_not2459 : ~ @Equation2459 Fin9 refa27_inst.
Proof. unfold Equation2459. intro H. specialize (H F9_0 F9_1). unfold magma_op, refa27_inst, refa27_op in H. discriminate H. Qed.

Lemma refa27_not2460 : ~ @Equation2460 Fin9 refa27_inst.
Proof. unfold Equation2460. intro H. specialize (H F9_0 F9_1). unfold magma_op, refa27_inst, refa27_op in H. discriminate H. Qed.

Lemma refa27_not2466 : ~ @Equation2466 Fin9 refa27_inst.
Proof. unfold Equation2466. intro H. specialize (H F9_0 F9_1). unfold magma_op, refa27_inst, refa27_op in H. discriminate H. Qed.

Lemma refa27_not2497 : ~ @Equation2497 Fin9 refa27_inst.
Proof. unfold Equation2497. intro H. specialize (H F9_0 F9_1). unfold magma_op, refa27_inst, refa27_op in H. discriminate H. Qed.

Lemma refa27_not2504 : ~ @Equation2504 Fin9 refa27_inst.
Proof. unfold Equation2504. intro H. specialize (H F9_0 F9_1). unfold magma_op, refa27_inst, refa27_op in H. discriminate H. Qed.

Lemma refa27_not2506 : ~ @Equation2506 Fin9 refa27_inst.
Proof. unfold Equation2506. intro H. specialize (H F9_0 F9_1). unfold magma_op, refa27_inst, refa27_op in H. discriminate H. Qed.

Lemma refa27_not2530 : ~ @Equation2530 Fin9 refa27_inst.
Proof. unfold Equation2530. intro H. specialize (H F9_0 F9_1). unfold magma_op, refa27_inst, refa27_op in H. discriminate H. Qed.

Lemma refa27_not2531 : ~ @Equation2531 Fin9 refa27_inst.
Proof. unfold Equation2531. intro H. specialize (H F9_0 F9_1). unfold magma_op, refa27_inst, refa27_op in H. discriminate H. Qed.

Lemma refa27_not2534 : ~ @Equation2534 Fin9 refa27_inst.
Proof. unfold Equation2534. intro H. specialize (H F9_0 F9_1). unfold magma_op, refa27_inst, refa27_op in H. discriminate H. Qed.

Lemma refa27_not2541 : ~ @Equation2541 Fin9 refa27_inst.
Proof. unfold Equation2541. intro H. specialize (H F9_0 F9_1). unfold magma_op, refa27_inst, refa27_op in H. discriminate H. Qed.

Lemma refa27_not2646 : ~ @Equation2646 Fin9 refa27_inst.
Proof. unfold Equation2646. intro H. specialize (H F9_0 F9_1). unfold magma_op, refa27_inst, refa27_op in H. discriminate H. Qed.

Lemma refa27_not2649 : ~ @Equation2649 Fin9 refa27_inst.
Proof. unfold Equation2649. intro H. specialize (H F9_0 F9_1). unfold magma_op, refa27_inst, refa27_op in H. discriminate H. Qed.

Lemma refa27_not2653 : ~ @Equation2653 Fin9 refa27_inst.
Proof. unfold Equation2653. intro H. specialize (H F9_0 F9_1). unfold magma_op, refa27_inst, refa27_op in H. discriminate H. Qed.

Lemma refa27_not2659 : ~ @Equation2659 Fin9 refa27_inst.
Proof. unfold Equation2659. intro H. specialize (H F9_0 F9_1). unfold magma_op, refa27_inst, refa27_op in H. discriminate H. Qed.

Lemma refa27_not2670 : ~ @Equation2670 Fin9 refa27_inst.
Proof. unfold Equation2670. intro H. specialize (H F9_0 F9_1). unfold magma_op, refa27_inst, refa27_op in H. discriminate H. Qed.

Lemma refa27_not2696 : ~ @Equation2696 Fin9 refa27_inst.
Proof. unfold Equation2696. intro H. specialize (H F9_0 F9_1). unfold magma_op, refa27_inst, refa27_op in H. discriminate H. Qed.

Lemma refa27_not2700 : ~ @Equation2700 Fin9 refa27_inst.
Proof. unfold Equation2700. intro H. specialize (H F9_0 F9_1). unfold magma_op, refa27_inst, refa27_op in H. discriminate H. Qed.

Lemma refa27_not2734 : ~ @Equation2734 Fin9 refa27_inst.
Proof. unfold Equation2734. intro H. specialize (H F9_0 F9_1). unfold magma_op, refa27_inst, refa27_op in H. discriminate H. Qed.

Lemma refa27_not2849 : ~ @Equation2849 Fin9 refa27_inst.
Proof. unfold Equation2849. intro H. specialize (H F9_0 F9_1). unfold magma_op, refa27_inst, refa27_op in H. discriminate H. Qed.

Lemma refa27_not2852 : ~ @Equation2852 Fin9 refa27_inst.
Proof. unfold Equation2852. intro H. specialize (H F9_0 F9_1). unfold magma_op, refa27_inst, refa27_op in H. discriminate H. Qed.

Lemma refa27_not2853 : ~ @Equation2853 Fin9 refa27_inst.
Proof. unfold Equation2853. intro H. specialize (H F9_0 F9_1). unfold magma_op, refa27_inst, refa27_op in H. discriminate H. Qed.

Lemma refa27_not2862 : ~ @Equation2862 Fin9 refa27_inst.
Proof. unfold Equation2862. intro H. specialize (H F9_0 F9_1). unfold magma_op, refa27_inst, refa27_op in H. discriminate H. Qed.

Lemma refa27_not2873 : ~ @Equation2873 Fin9 refa27_inst.
Proof. unfold Equation2873. intro H. specialize (H F9_0 F9_1). unfold magma_op, refa27_inst, refa27_op in H. discriminate H. Qed.

Lemma refa27_not2899 : ~ @Equation2899 Fin9 refa27_inst.
Proof. unfold Equation2899. intro H. specialize (H F9_0 F9_1). unfold magma_op, refa27_inst, refa27_op in H. discriminate H. Qed.

Lemma refa27_not2903 : ~ @Equation2903 Fin9 refa27_inst.
Proof. unfold Equation2903. intro H. specialize (H F9_0 F9_1). unfold magma_op, refa27_inst, refa27_op in H. discriminate H. Qed.

Lemma refa27_not2910 : ~ @Equation2910 Fin9 refa27_inst.
Proof. unfold Equation2910. intro H. specialize (H F9_0 F9_1). unfold magma_op, refa27_inst, refa27_op in H. discriminate H. Qed.

Lemma refa27_not2937 : ~ @Equation2937 Fin9 refa27_inst.
Proof. unfold Equation2937. intro H. specialize (H F9_0 F9_1). unfold magma_op, refa27_inst, refa27_op in H. discriminate H. Qed.

Lemma refa27_not2946 : ~ @Equation2946 Fin9 refa27_inst.
Proof. unfold Equation2946. intro H. specialize (H F9_0 F9_1). unfold magma_op, refa27_inst, refa27_op in H. discriminate H. Qed.

Lemma refa27_not3055 : ~ @Equation3055 Fin9 refa27_inst.
Proof. unfold Equation3055. intro H. specialize (H F9_0 F9_1). unfold magma_op, refa27_inst, refa27_op in H. discriminate H. Qed.

Lemma refa27_not3056 : ~ @Equation3056 Fin9 refa27_inst.
Proof. unfold Equation3056. intro H. specialize (H F9_0 F9_1). unfold magma_op, refa27_inst, refa27_op in H. discriminate H. Qed.

Lemma refa27_not3058 : ~ @Equation3058 Fin9 refa27_inst.
Proof. unfold Equation3058. intro H. specialize (H F9_0 F9_1). unfold magma_op, refa27_inst, refa27_op in H. discriminate H. Qed.

Lemma refa27_not3059 : ~ @Equation3059 Fin9 refa27_inst.
Proof. unfold Equation3059. intro H. specialize (H F9_0 F9_1). unfold magma_op, refa27_inst, refa27_op in H. discriminate H. Qed.

Lemma refa27_not3065 : ~ @Equation3065 Fin9 refa27_inst.
Proof. unfold Equation3065. intro H. specialize (H F9_0 F9_1). unfold magma_op, refa27_inst, refa27_op in H. discriminate H. Qed.

Lemma refa27_not3066 : ~ @Equation3066 Fin9 refa27_inst.
Proof. unfold Equation3066. intro H. specialize (H F9_0 F9_1). unfold magma_op, refa27_inst, refa27_op in H. discriminate H. Qed.

Lemma refa27_not3075 : ~ @Equation3075 Fin9 refa27_inst.
Proof. unfold Equation3075. intro H. specialize (H F9_0 F9_1). unfold magma_op, refa27_inst, refa27_op in H. discriminate H. Qed.

Lemma refa27_not3076 : ~ @Equation3076 Fin9 refa27_inst.
Proof. unfold Equation3076. intro H. specialize (H F9_0 F9_1). unfold magma_op, refa27_inst, refa27_op in H. discriminate H. Qed.

Lemma refa27_not3102 : ~ @Equation3102 Fin9 refa27_inst.
Proof. unfold Equation3102. intro H. specialize (H F9_0 F9_1). unfold magma_op, refa27_inst, refa27_op in H. discriminate H. Qed.

Lemma refa27_not3103 : ~ @Equation3103 Fin9 refa27_inst.
Proof. unfold Equation3103. intro H. specialize (H F9_0 F9_1). unfold magma_op, refa27_inst, refa27_op in H. discriminate H. Qed.

Lemma refa27_not3105 : ~ @Equation3105 Fin9 refa27_inst.
Proof. unfold Equation3105. intro H. specialize (H F9_0 F9_1). unfold magma_op, refa27_inst, refa27_op in H. discriminate H. Qed.

Lemma refa27_not3116 : ~ @Equation3116 Fin9 refa27_inst.
Proof. unfold Equation3116. intro H. specialize (H F9_0 F9_1). unfold magma_op, refa27_inst, refa27_op in H. discriminate H. Qed.

Lemma refa27_not3139 : ~ @Equation3139 Fin9 refa27_inst.
Proof. unfold Equation3139. intro H. specialize (H F9_0 F9_1). unfold magma_op, refa27_inst, refa27_op in H. discriminate H. Qed.

Lemma refa27_not3143 : ~ @Equation3143 Fin9 refa27_inst.
Proof. unfold Equation3143. intro H. specialize (H F9_0 F9_1). unfold magma_op, refa27_inst, refa27_op in H. discriminate H. Qed.

Lemma refa27_not3149 : ~ @Equation3149 Fin9 refa27_inst.
Proof. unfold Equation3149. intro H. specialize (H F9_0 F9_1). unfold magma_op, refa27_inst, refa27_op in H. discriminate H. Qed.

Lemma refa27_not3152 : ~ @Equation3152 Fin9 refa27_inst.
Proof. unfold Equation3152. intro H. specialize (H F9_0 F9_1). unfold magma_op, refa27_inst, refa27_op in H. discriminate H. Qed.

Lemma refa27_not3254 : ~ @Equation3254 Fin9 refa27_inst.
Proof. unfold Equation3254. intro H. specialize (H F9_0 F9_1). unfold magma_op, refa27_inst, refa27_op in H. discriminate H. Qed.

Lemma refa27_not3255 : ~ @Equation3255 Fin9 refa27_inst.
Proof. unfold Equation3255. intro H. specialize (H F9_0 F9_1). unfold magma_op, refa27_inst, refa27_op in H. discriminate H. Qed.

Lemma refa27_not3256 : ~ @Equation3256 Fin9 refa27_inst.
Proof. unfold Equation3256. intro H. specialize (H F9_0 F9_1). unfold magma_op, refa27_inst, refa27_op in H. discriminate H. Qed.

Lemma refa27_not3258 : ~ @Equation3258 Fin9 refa27_inst.
Proof. unfold Equation3258. intro H. specialize (H F9_0 F9_1). unfold magma_op, refa27_inst, refa27_op in H. discriminate H. Qed.

Lemma refa27_not3261 : ~ @Equation3261 Fin9 refa27_inst.
Proof. unfold Equation3261. intro H. specialize (H F9_0 F9_1). unfold magma_op, refa27_inst, refa27_op in H. discriminate H. Qed.

Lemma refa27_not3262 : ~ @Equation3262 Fin9 refa27_inst.
Proof. unfold Equation3262. intro H. specialize (H F9_0 F9_1). unfold magma_op, refa27_inst, refa27_op in H. discriminate H. Qed.

Lemma refa27_not3269 : ~ @Equation3269 Fin9 refa27_inst.
Proof. unfold Equation3269. intro H. specialize (H F9_0 F9_1). unfold magma_op, refa27_inst, refa27_op in H. discriminate H. Qed.

Lemma refa27_not3272 : ~ @Equation3272 Fin9 refa27_inst.
Proof. unfold Equation3272. intro H. specialize (H F9_0 F9_1). unfold magma_op, refa27_inst, refa27_op in H. discriminate H. Qed.

Lemma refa27_not3278 : ~ @Equation3278 Fin9 refa27_inst.
Proof. unfold Equation3278. intro H. specialize (H F9_0 F9_1). unfold magma_op, refa27_inst, refa27_op in H. discriminate H. Qed.

Lemma refa27_not3306 : ~ @Equation3306 Fin9 refa27_inst.
Proof. unfold Equation3306. intro H. specialize (H F9_0 F9_1). unfold magma_op, refa27_inst, refa27_op in H. discriminate H. Qed.

Lemma refa27_not3309 : ~ @Equation3309 Fin9 refa27_inst.
Proof. unfold Equation3309. intro H. specialize (H F9_0 F9_1). unfold magma_op, refa27_inst, refa27_op in H. discriminate H. Qed.

Lemma refa27_not3315 : ~ @Equation3315 Fin9 refa27_inst.
Proof. unfold Equation3315. intro H. specialize (H F9_0 F9_1). unfold magma_op, refa27_inst, refa27_op in H. discriminate H. Qed.

Lemma refa27_not3316 : ~ @Equation3316 Fin9 refa27_inst.
Proof. unfold Equation3316. intro H. specialize (H F9_0 F9_1). unfold magma_op, refa27_inst, refa27_op in H. discriminate H. Qed.

Lemma refa27_not3318 : ~ @Equation3318 Fin9 refa27_inst.
Proof. unfold Equation3318. intro H. specialize (H F9_0 F9_1). unfold magma_op, refa27_inst, refa27_op in H. discriminate H. Qed.

Lemma refa27_not3342 : ~ @Equation3342 Fin9 refa27_inst.
Proof. unfold Equation3342. intro H. specialize (H F9_0 F9_1). unfold magma_op, refa27_inst, refa27_op in H. discriminate H. Qed.

Lemma refa27_not3345 : ~ @Equation3345 Fin9 refa27_inst.
Proof. unfold Equation3345. intro H. specialize (H F9_0 F9_1). unfold magma_op, refa27_inst, refa27_op in H. discriminate H. Qed.

Lemma refa27_not3352 : ~ @Equation3352 Fin9 refa27_inst.
Proof. unfold Equation3352. intro H. specialize (H F9_0 F9_1). unfold magma_op, refa27_inst, refa27_op in H. discriminate H. Qed.

Lemma refa27_not3353 : ~ @Equation3353 Fin9 refa27_inst.
Proof. unfold Equation3353. intro H. specialize (H F9_0 F9_1). unfold magma_op, refa27_inst, refa27_op in H. discriminate H. Qed.

Lemma refa27_not3355 : ~ @Equation3355 Fin9 refa27_inst.
Proof. unfold Equation3355. intro H. specialize (H F9_0 F9_1). unfold magma_op, refa27_inst, refa27_op in H. discriminate H. Qed.

Lemma refa27_not3457 : ~ @Equation3457 Fin9 refa27_inst.
Proof. unfold Equation3457. intro H. specialize (H F9_0 F9_1). unfold magma_op, refa27_inst, refa27_op in H. discriminate H. Qed.

Lemma refa27_not3458 : ~ @Equation3458 Fin9 refa27_inst.
Proof. unfold Equation3458. intro H. specialize (H F9_0 F9_1). unfold magma_op, refa27_inst, refa27_op in H. discriminate H. Qed.

Lemma refa27_not3459 : ~ @Equation3459 Fin9 refa27_inst.
Proof. unfold Equation3459. intro H. specialize (H F9_0 F9_1). unfold magma_op, refa27_inst, refa27_op in H. discriminate H. Qed.

Lemma refa27_not3461 : ~ @Equation3461 Fin9 refa27_inst.
Proof. unfold Equation3461. intro H. specialize (H F9_0 F9_1). unfold magma_op, refa27_inst, refa27_op in H. discriminate H. Qed.

Lemma refa27_not3464 : ~ @Equation3464 Fin9 refa27_inst.
Proof. unfold Equation3464. intro H. specialize (H F9_0 F9_1). unfold magma_op, refa27_inst, refa27_op in H. discriminate H. Qed.

Lemma refa27_not3465 : ~ @Equation3465 Fin9 refa27_inst.
Proof. unfold Equation3465. intro H. specialize (H F9_0 F9_1). unfold magma_op, refa27_inst, refa27_op in H. discriminate H. Qed.

Lemma refa27_not3475 : ~ @Equation3475 Fin9 refa27_inst.
Proof. unfold Equation3475. intro H. specialize (H F9_0 F9_1). unfold magma_op, refa27_inst, refa27_op in H. discriminate H. Qed.

Lemma refa27_not3481 : ~ @Equation3481 Fin9 refa27_inst.
Proof. unfold Equation3481. intro H. specialize (H F9_0 F9_1). unfold magma_op, refa27_inst, refa27_op in H. discriminate H. Qed.

Lemma refa27_not3509 : ~ @Equation3509 Fin9 refa27_inst.
Proof. unfold Equation3509. intro H. specialize (H F9_0 F9_1). unfold magma_op, refa27_inst, refa27_op in H. discriminate H. Qed.

Lemma refa27_not3512 : ~ @Equation3512 Fin9 refa27_inst.
Proof. unfold Equation3512. intro H. specialize (H F9_0 F9_1). unfold magma_op, refa27_inst, refa27_op in H. discriminate H. Qed.

Lemma refa27_not3518 : ~ @Equation3518 Fin9 refa27_inst.
Proof. unfold Equation3518. intro H. specialize (H F9_0 F9_1). unfold magma_op, refa27_inst, refa27_op in H. discriminate H. Qed.

Lemma refa27_not3519 : ~ @Equation3519 Fin9 refa27_inst.
Proof. unfold Equation3519. intro H. specialize (H F9_0 F9_1). unfold magma_op, refa27_inst, refa27_op in H. discriminate H. Qed.

Lemma refa27_not3521 : ~ @Equation3521 Fin9 refa27_inst.
Proof. unfold Equation3521. intro H. specialize (H F9_0 F9_1). unfold magma_op, refa27_inst, refa27_op in H. discriminate H. Qed.

Lemma refa27_not3545 : ~ @Equation3545 Fin9 refa27_inst.
Proof. unfold Equation3545. intro H. specialize (H F9_0 F9_1). unfold magma_op, refa27_inst, refa27_op in H. discriminate H. Qed.

Lemma refa27_not3548 : ~ @Equation3548 Fin9 refa27_inst.
Proof. unfold Equation3548. intro H. specialize (H F9_0 F9_1). unfold magma_op, refa27_inst, refa27_op in H. discriminate H. Qed.

Lemma refa27_not3555 : ~ @Equation3555 Fin9 refa27_inst.
Proof. unfold Equation3555. intro H. specialize (H F9_0 F9_1). unfold magma_op, refa27_inst, refa27_op in H. discriminate H. Qed.

Lemma refa27_not3660 : ~ @Equation3660 Fin9 refa27_inst.
Proof. unfold Equation3660. intro H. specialize (H F9_0 F9_1). unfold magma_op, refa27_inst, refa27_op in H. discriminate H. Qed.

Lemma refa27_not3662 : ~ @Equation3662 Fin9 refa27_inst.
Proof. unfold Equation3662. intro H. specialize (H F9_0 F9_1). unfold magma_op, refa27_inst, refa27_op in H. discriminate H. Qed.

Lemma refa27_not3665 : ~ @Equation3665 Fin9 refa27_inst.
Proof. unfold Equation3665. intro H. specialize (H F9_0 F9_1). unfold magma_op, refa27_inst, refa27_op in H. discriminate H. Qed.

Lemma refa27_not3668 : ~ @Equation3668 Fin9 refa27_inst.
Proof. unfold Equation3668. intro H. specialize (H F9_0 F9_1). unfold magma_op, refa27_inst, refa27_op in H. discriminate H. Qed.

Lemma refa27_not3674 : ~ @Equation3674 Fin9 refa27_inst.
Proof. unfold Equation3674. intro H. specialize (H F9_0 F9_1). unfold magma_op, refa27_inst, refa27_op in H. discriminate H. Qed.

Lemma refa27_not3677 : ~ @Equation3677 Fin9 refa27_inst.
Proof. unfold Equation3677. intro H. specialize (H F9_0 F9_1). unfold magma_op, refa27_inst, refa27_op in H. discriminate H. Qed.

Lemma refa27_not3678 : ~ @Equation3678 Fin9 refa27_inst.
Proof. unfold Equation3678. intro H. specialize (H F9_0 F9_1). unfold magma_op, refa27_inst, refa27_op in H. discriminate H. Qed.

Lemma refa27_not3684 : ~ @Equation3684 Fin9 refa27_inst.
Proof. unfold Equation3684. intro H. specialize (H F9_0 F9_1). unfold magma_op, refa27_inst, refa27_op in H. discriminate H. Qed.

Lemma refa27_not3685 : ~ @Equation3685 Fin9 refa27_inst.
Proof. unfold Equation3685. intro H. specialize (H F9_0 F9_1). unfold magma_op, refa27_inst, refa27_op in H. discriminate H. Qed.

Lemma refa27_not3712 : ~ @Equation3712 Fin9 refa27_inst.
Proof. unfold Equation3712. intro H. specialize (H F9_0 F9_1). unfold magma_op, refa27_inst, refa27_op in H. discriminate H. Qed.

Lemma refa27_not3714 : ~ @Equation3714 Fin9 refa27_inst.
Proof. unfold Equation3714. intro H. specialize (H F9_0 F9_1). unfold magma_op, refa27_inst, refa27_op in H. discriminate H. Qed.

Lemma refa27_not3721 : ~ @Equation3721 Fin9 refa27_inst.
Proof. unfold Equation3721. intro H. specialize (H F9_0 F9_1). unfold magma_op, refa27_inst, refa27_op in H. discriminate H. Qed.

Lemma refa27_not3724 : ~ @Equation3724 Fin9 refa27_inst.
Proof. unfold Equation3724. intro H. specialize (H F9_0 F9_1). unfold magma_op, refa27_inst, refa27_op in H. discriminate H. Qed.

Lemma refa27_not3725 : ~ @Equation3725 Fin9 refa27_inst.
Proof. unfold Equation3725. intro H. specialize (H F9_0 F9_1). unfold magma_op, refa27_inst, refa27_op in H. discriminate H. Qed.

Lemma refa27_not3748 : ~ @Equation3748 Fin9 refa27_inst.
Proof. unfold Equation3748. intro H. specialize (H F9_0 F9_1). unfold magma_op, refa27_inst, refa27_op in H. discriminate H. Qed.

Lemma refa27_not3749 : ~ @Equation3749 Fin9 refa27_inst.
Proof. unfold Equation3749. intro H. specialize (H F9_0 F9_1). unfold magma_op, refa27_inst, refa27_op in H. discriminate H. Qed.

Lemma refa27_not3752 : ~ @Equation3752 Fin9 refa27_inst.
Proof. unfold Equation3752. intro H. specialize (H F9_0 F9_1). unfold magma_op, refa27_inst, refa27_op in H. discriminate H. Qed.

Lemma refa27_not3759 : ~ @Equation3759 Fin9 refa27_inst.
Proof. unfold Equation3759. intro H. specialize (H F9_0 F9_1). unfold magma_op, refa27_inst, refa27_op in H. discriminate H. Qed.

Lemma refa27_not3761 : ~ @Equation3761 Fin9 refa27_inst.
Proof. unfold Equation3761. intro H. specialize (H F9_0 F9_1). unfold magma_op, refa27_inst, refa27_op in H. discriminate H. Qed.

Lemma refa27_not3865 : ~ @Equation3865 Fin9 refa27_inst.
Proof. unfold Equation3865. intro H. specialize (H F9_0 F9_1). unfold magma_op, refa27_inst, refa27_op in H. discriminate H. Qed.

Lemma refa27_not3870 : ~ @Equation3870 Fin9 refa27_inst.
Proof. unfold Equation3870. intro H. specialize (H F9_0 F9_1). unfold magma_op, refa27_inst, refa27_op in H. discriminate H. Qed.

Lemma refa27_not3871 : ~ @Equation3871 Fin9 refa27_inst.
Proof. unfold Equation3871. intro H. specialize (H F9_0 F9_1). unfold magma_op, refa27_inst, refa27_op in H. discriminate H. Qed.

Lemma refa27_not3877 : ~ @Equation3877 Fin9 refa27_inst.
Proof. unfold Equation3877. intro H. specialize (H F9_0 F9_1). unfold magma_op, refa27_inst, refa27_op in H. discriminate H. Qed.

Lemma refa27_not3878 : ~ @Equation3878 Fin9 refa27_inst.
Proof. unfold Equation3878. intro H. specialize (H F9_0 F9_1). unfold magma_op, refa27_inst, refa27_op in H. discriminate H. Qed.

Lemma refa27_not3881 : ~ @Equation3881 Fin9 refa27_inst.
Proof. unfold Equation3881. intro H. specialize (H F9_0 F9_1). unfold magma_op, refa27_inst, refa27_op in H. discriminate H. Qed.

Lemma refa27_not3887 : ~ @Equation3887 Fin9 refa27_inst.
Proof. unfold Equation3887. intro H. specialize (H F9_0 F9_1). unfold magma_op, refa27_inst, refa27_op in H. discriminate H. Qed.

Lemma refa27_not3918 : ~ @Equation3918 Fin9 refa27_inst.
Proof. unfold Equation3918. intro H. specialize (H F9_0 F9_1). unfold magma_op, refa27_inst, refa27_op in H. discriminate H. Qed.

Lemma refa27_not3925 : ~ @Equation3925 Fin9 refa27_inst.
Proof. unfold Equation3925. intro H. specialize (H F9_0 F9_1). unfold magma_op, refa27_inst, refa27_op in H. discriminate H. Qed.

Lemma refa27_not3927 : ~ @Equation3927 Fin9 refa27_inst.
Proof. unfold Equation3927. intro H. specialize (H F9_0 F9_1). unfold magma_op, refa27_inst, refa27_op in H. discriminate H. Qed.

Lemma refa27_not3928 : ~ @Equation3928 Fin9 refa27_inst.
Proof. unfold Equation3928. intro H. specialize (H F9_0 F9_1). unfold magma_op, refa27_inst, refa27_op in H. discriminate H. Qed.

Lemma refa27_not3954 : ~ @Equation3954 Fin9 refa27_inst.
Proof. unfold Equation3954. intro H. specialize (H F9_0 F9_1). unfold magma_op, refa27_inst, refa27_op in H. discriminate H. Qed.

Lemma refa27_not3962 : ~ @Equation3962 Fin9 refa27_inst.
Proof. unfold Equation3962. intro H. specialize (H F9_0 F9_1). unfold magma_op, refa27_inst, refa27_op in H. discriminate H. Qed.

Lemma refa27_not3964 : ~ @Equation3964 Fin9 refa27_inst.
Proof. unfold Equation3964. intro H. specialize (H F9_0 F9_1). unfold magma_op, refa27_inst, refa27_op in H. discriminate H. Qed.

Lemma refa27_not4066 : ~ @Equation4066 Fin9 refa27_inst.
Proof. unfold Equation4066. intro H. specialize (H F9_0 F9_1). unfold magma_op, refa27_inst, refa27_op in H. discriminate H. Qed.

Lemma refa27_not4068 : ~ @Equation4068 Fin9 refa27_inst.
Proof. unfold Equation4068. intro H. specialize (H F9_0 F9_1). unfold magma_op, refa27_inst, refa27_op in H. discriminate H. Qed.

Lemma refa27_not4070 : ~ @Equation4070 Fin9 refa27_inst.
Proof. unfold Equation4070. intro H. specialize (H F9_0 F9_1). unfold magma_op, refa27_inst, refa27_op in H. discriminate H. Qed.

Lemma refa27_not4073 : ~ @Equation4073 Fin9 refa27_inst.
Proof. unfold Equation4073. intro H. specialize (H F9_0 F9_1). unfold magma_op, refa27_inst, refa27_op in H. discriminate H. Qed.

Lemma refa27_not4074 : ~ @Equation4074 Fin9 refa27_inst.
Proof. unfold Equation4074. intro H. specialize (H F9_0 F9_1). unfold magma_op, refa27_inst, refa27_op in H. discriminate H. Qed.

Lemma refa27_not4080 : ~ @Equation4080 Fin9 refa27_inst.
Proof. unfold Equation4080. intro H. specialize (H F9_0 F9_1). unfold magma_op, refa27_inst, refa27_op in H. discriminate H. Qed.

Lemma refa27_not4081 : ~ @Equation4081 Fin9 refa27_inst.
Proof. unfold Equation4081. intro H. specialize (H F9_0 F9_1). unfold magma_op, refa27_inst, refa27_op in H. discriminate H. Qed.

Lemma refa27_not4084 : ~ @Equation4084 Fin9 refa27_inst.
Proof. unfold Equation4084. intro H. specialize (H F9_0 F9_1). unfold magma_op, refa27_inst, refa27_op in H. discriminate H. Qed.

Lemma refa27_not4090 : ~ @Equation4090 Fin9 refa27_inst.
Proof. unfold Equation4090. intro H. specialize (H F9_0 F9_1). unfold magma_op, refa27_inst, refa27_op in H. discriminate H. Qed.

Lemma refa27_not4091 : ~ @Equation4091 Fin9 refa27_inst.
Proof. unfold Equation4091. intro H. specialize (H F9_0 F9_1). unfold magma_op, refa27_inst, refa27_op in H. discriminate H. Qed.

Lemma refa27_not4121 : ~ @Equation4121 Fin9 refa27_inst.
Proof. unfold Equation4121. intro H. specialize (H F9_0 F9_1). unfold magma_op, refa27_inst, refa27_op in H. discriminate H. Qed.

Lemma refa27_not4127 : ~ @Equation4127 Fin9 refa27_inst.
Proof. unfold Equation4127. intro H. specialize (H F9_0 F9_1). unfold magma_op, refa27_inst, refa27_op in H. discriminate H. Qed.

Lemma refa27_not4128 : ~ @Equation4128 Fin9 refa27_inst.
Proof. unfold Equation4128. intro H. specialize (H F9_0 F9_1). unfold magma_op, refa27_inst, refa27_op in H. discriminate H. Qed.

Lemma refa27_not4130 : ~ @Equation4130 Fin9 refa27_inst.
Proof. unfold Equation4130. intro H. specialize (H F9_0 F9_1). unfold magma_op, refa27_inst, refa27_op in H. discriminate H. Qed.

Lemma refa27_not4131 : ~ @Equation4131 Fin9 refa27_inst.
Proof. unfold Equation4131. intro H. specialize (H F9_0 F9_1). unfold magma_op, refa27_inst, refa27_op in H. discriminate H. Qed.

Lemma refa27_not4155 : ~ @Equation4155 Fin9 refa27_inst.
Proof. unfold Equation4155. intro H. specialize (H F9_0 F9_1). unfold magma_op, refa27_inst, refa27_op in H. discriminate H. Qed.

Lemma refa27_not4157 : ~ @Equation4157 Fin9 refa27_inst.
Proof. unfold Equation4157. intro H. specialize (H F9_0 F9_1). unfold magma_op, refa27_inst, refa27_op in H. discriminate H. Qed.

Lemma refa27_not4164 : ~ @Equation4164 Fin9 refa27_inst.
Proof. unfold Equation4164. intro H. specialize (H F9_0 F9_1). unfold magma_op, refa27_inst, refa27_op in H. discriminate H. Qed.

Lemma refa27_not4165 : ~ @Equation4165 Fin9 refa27_inst.
Proof. unfold Equation4165. intro H. specialize (H F9_0 F9_1). unfold magma_op, refa27_inst, refa27_op in H. discriminate H. Qed.

Lemma refa27_not4167 : ~ @Equation4167 Fin9 refa27_inst.
Proof. unfold Equation4167. intro H. specialize (H F9_0 F9_1). unfold magma_op, refa27_inst, refa27_op in H. discriminate H. Qed.

Lemma refa27_not4268 : ~ @Equation4268 Fin9 refa27_inst.
Proof. unfold Equation4268. intro H. specialize (H F9_0 F9_1). unfold magma_op, refa27_inst, refa27_op in H. discriminate H. Qed.

Lemma refa27_not4269 : ~ @Equation4269 Fin9 refa27_inst.
Proof. unfold Equation4269. intro H. specialize (H F9_0 F9_1). unfold magma_op, refa27_inst, refa27_op in H. discriminate H. Qed.

Lemma refa27_not4270 : ~ @Equation4270 Fin9 refa27_inst.
Proof. unfold Equation4270. intro H. specialize (H F9_0 F9_1). unfold magma_op, refa27_inst, refa27_op in H. discriminate H. Qed.

Lemma refa27_not4275 : ~ @Equation4275 Fin9 refa27_inst.
Proof. unfold Equation4275. intro H. specialize (H F9_0 F9_1). unfold magma_op, refa27_inst, refa27_op in H. discriminate H. Qed.

Lemma refa27_not4276 : ~ @Equation4276 Fin9 refa27_inst.
Proof. unfold Equation4276. intro H. specialize (H F9_0 F9_1). unfold magma_op, refa27_inst, refa27_op in H. discriminate H. Qed.

Lemma refa27_not4284 : ~ @Equation4284 Fin9 refa27_inst.
Proof. unfold Equation4284. intro H. specialize (H F9_0 F9_1). unfold magma_op, refa27_inst, refa27_op in H. discriminate H. Qed.

Lemma refa27_not4290 : ~ @Equation4290 Fin9 refa27_inst.
Proof. unfold Equation4290. intro H. specialize (H F9_0 F9_1). unfold magma_op, refa27_inst, refa27_op in H. discriminate H. Qed.

Lemma refa27_not4314 : ~ @Equation4314 Fin9 refa27_inst.
Proof. unfold Equation4314. intro H. specialize (H F9_0 F9_1). unfold magma_op, refa27_inst, refa27_op in H. discriminate H. Qed.

Lemma refa27_not4320 : ~ @Equation4320 Fin9 refa27_inst.
Proof. unfold Equation4320. intro H. specialize (H F9_0 F9_1). unfold magma_op, refa27_inst, refa27_op in H. discriminate H. Qed.

Lemma refa27_not4321 : ~ @Equation4321 Fin9 refa27_inst.
Proof. unfold Equation4321. intro H. specialize (H F9_0 F9_1). unfold magma_op, refa27_inst, refa27_op in H. discriminate H. Qed.

Lemma refa27_not4343 : ~ @Equation4343 Fin9 refa27_inst.
Proof. unfold Equation4343. intro H. specialize (H F9_0 F9_1). unfold magma_op, refa27_inst, refa27_op in H. discriminate H. Qed.

Lemma refa27_not4398 : ~ @Equation4398 Fin9 refa27_inst.
Proof. unfold Equation4398. intro H. specialize (H F9_0 F9_1). unfold magma_op, refa27_inst, refa27_op in H. discriminate H. Qed.

Lemma refa27_not4408 : ~ @Equation4408 Fin9 refa27_inst.
Proof. unfold Equation4408. intro H. specialize (H F9_0 F9_1). unfold magma_op, refa27_inst, refa27_op in H. discriminate H. Qed.

Lemma refa27_not4436 : ~ @Equation4436 Fin9 refa27_inst.
Proof. unfold Equation4436. intro H. specialize (H F9_0 F9_1). unfold magma_op, refa27_inst, refa27_op in H. discriminate H. Qed.

Lemma refa27_not4443 : ~ @Equation4443 Fin9 refa27_inst.
Proof. unfold Equation4443. intro H. specialize (H F9_0 F9_1). unfold magma_op, refa27_inst, refa27_op in H. discriminate H. Qed.

Lemma refa27_not4472 : ~ @Equation4472 Fin9 refa27_inst.
Proof. unfold Equation4472. intro H. specialize (H F9_0 F9_1). unfold magma_op, refa27_inst, refa27_op in H. discriminate H. Qed.

Lemma refa27_not4479 : ~ @Equation4479 Fin9 refa27_inst.
Proof. unfold Equation4479. intro H. specialize (H F9_0 F9_1). unfold magma_op, refa27_inst, refa27_op in H. discriminate H. Qed.

Lemma refa27_not4482 : ~ @Equation4482 Fin9 refa27_inst.
Proof. unfold Equation4482. intro H. specialize (H F9_0 F9_1). unfold magma_op, refa27_inst, refa27_op in H. discriminate H. Qed.

Lemma refa27_not4583 : ~ @Equation4583 Fin9 refa27_inst.
Proof. unfold Equation4583. intro H. specialize (H F9_0 F9_1). unfold magma_op, refa27_inst, refa27_op in H. discriminate H. Qed.

Lemma refa27_not4584 : ~ @Equation4584 Fin9 refa27_inst.
Proof. unfold Equation4584. intro H. specialize (H F9_0 F9_1). unfold magma_op, refa27_inst, refa27_op in H. discriminate H. Qed.

Lemma refa27_not4585 : ~ @Equation4585 Fin9 refa27_inst.
Proof. unfold Equation4585. intro H. specialize (H F9_0 F9_1). unfold magma_op, refa27_inst, refa27_op in H. discriminate H. Qed.

Lemma refa27_not4587 : ~ @Equation4587 Fin9 refa27_inst.
Proof. unfold Equation4587. intro H. specialize (H F9_0 F9_1). unfold magma_op, refa27_inst, refa27_op in H. discriminate H. Qed.

Lemma refa27_not4588 : ~ @Equation4588 Fin9 refa27_inst.
Proof. unfold Equation4588. intro H. specialize (H F9_0 F9_1). unfold magma_op, refa27_inst, refa27_op in H. discriminate H. Qed.

Lemma refa27_not4590 : ~ @Equation4590 Fin9 refa27_inst.
Proof. unfold Equation4590. intro H. specialize (H F9_0 F9_1). unfold magma_op, refa27_inst, refa27_op in H. discriminate H. Qed.

Lemma refa27_not4591 : ~ @Equation4591 Fin9 refa27_inst.
Proof. unfold Equation4591. intro H. specialize (H F9_0 F9_1). unfold magma_op, refa27_inst, refa27_op in H. discriminate H. Qed.

Lemma refa27_not4598 : ~ @Equation4598 Fin9 refa27_inst.
Proof. unfold Equation4598. intro H. specialize (H F9_0 F9_1). unfold magma_op, refa27_inst, refa27_op in H. discriminate H. Qed.

Lemma refa27_not4599 : ~ @Equation4599 Fin9 refa27_inst.
Proof. unfold Equation4599. intro H. specialize (H F9_0 F9_1). unfold magma_op, refa27_inst, refa27_op in H. discriminate H. Qed.

Lemma refa27_not4605 : ~ @Equation4605 Fin9 refa27_inst.
Proof. unfold Equation4605. intro H. specialize (H F9_0 F9_1). unfold magma_op, refa27_inst, refa27_op in H. discriminate H. Qed.

Lemma refa27_not4608 : ~ @Equation4608 Fin9 refa27_inst.
Proof. unfold Equation4608. intro H. specialize (H F9_0 F9_1). unfold magma_op, refa27_inst, refa27_op in H. discriminate H. Qed.

Lemma refa27_not4629 : ~ @Equation4629 Fin9 refa27_inst.
Proof. unfold Equation4629. intro H. specialize (H F9_0 F9_1). unfold magma_op, refa27_inst, refa27_op in H. discriminate H. Qed.

Lemma refa27_not4636 : ~ @Equation4636 Fin9 refa27_inst.
Proof. unfold Equation4636. intro H. specialize (H F9_0 F9_1). unfold magma_op, refa27_inst, refa27_op in H. discriminate H. Qed.

(** ---- refa270 (Fin3) ---- *)

Definition refa270_op (x y : Fin3) : Fin3 :=
  match x, y with
  | F3_0, F3_0 => F3_0 | F3_0, F3_1 => F3_0 | F3_0, F3_2 => F3_1
  | F3_1, F3_0 => F3_1 | F3_1, F3_1 => F3_1 | F3_1, F3_2 => F3_0
  | F3_2, F3_0 => F3_2 | F3_2, F3_1 => F3_2 | F3_2, F3_2 => F3_0
  end.

#[local] Instance refa270_inst : Magma Fin3 := {| magma_op := refa270_op |}.

Lemma refa270_sat1271 : @Equation1271 Fin3 refa270_inst.
Proof. unfold Equation1271, magma_op, refa270_inst, refa270_op. intros x y z w. destruct x, y, z, w; reflexivity. Qed.

Lemma refa270_not3724 : ~ @Equation3724 Fin3 refa270_inst.
Proof. unfold Equation3724. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa270_inst, refa270_op in H. discriminate H. Qed.

Lemma refa270_not3925 : ~ @Equation3925 Fin3 refa270_inst.
Proof. unfold Equation3925. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa270_inst, refa270_op in H. discriminate H. Qed.

(** ---- refa271 (Fin3) ---- *)

Definition refa271_op (x y : Fin3) : Fin3 :=
  match x, y with
  | F3_0, F3_0 => F3_0 | F3_0, F3_1 => F3_0 | F3_0, F3_2 => F3_0
  | F3_1, F3_0 => F3_0 | F3_1, F3_1 => F3_0 | F3_1, F3_2 => F3_2
  | F3_2, F3_0 => F3_0 | F3_2, F3_1 => F3_1 | F3_2, F3_2 => F3_0
  end.

#[local] Instance refa271_inst : Magma Fin3 := {| magma_op := refa271_op |}.

Lemma refa271_sat385 : @Equation385 Fin3 refa271_inst.
Proof. unfold Equation385, magma_op, refa271_inst, refa271_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa271_sat3479 : @Equation3479 Fin3 refa271_inst.
Proof. unfold Equation3479, magma_op, refa271_inst, refa271_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa271_sat3483 : @Equation3483 Fin3 refa271_inst.
Proof. unfold Equation3483, magma_op, refa271_inst, refa271_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa271_sat3679 : @Equation3679 Fin3 refa271_inst.
Proof. unfold Equation3679, magma_op, refa271_inst, refa271_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa271_sat3696 : @Equation3696 Fin3 refa271_inst.
Proof. unfold Equation3696, magma_op, refa271_inst, refa271_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa271_sat3882 : @Equation3882 Fin3 refa271_inst.
Proof. unfold Equation3882, magma_op, refa271_inst, refa271_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa271_sat3885 : @Equation3885 Fin3 refa271_inst.
Proof. unfold Equation3885, magma_op, refa271_inst, refa271_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa271_sat4331 : @Equation4331 Fin3 refa271_inst.
Proof. unfold Equation4331, magma_op, refa271_inst, refa271_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa271_sat4447 : @Equation4447 Fin3 refa271_inst.
Proof. unfold Equation4447, magma_op, refa271_inst, refa271_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa271_sat4457 : @Equation4457 Fin3 refa271_inst.
Proof. unfold Equation4457, magma_op, refa271_inst, refa271_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa271_sat4484 : @Equation4484 Fin3 refa271_inst.
Proof. unfold Equation4484, magma_op, refa271_inst, refa271_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa271_sat4487 : @Equation4487 Fin3 refa271_inst.
Proof. unfold Equation4487, magma_op, refa271_inst, refa271_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa271_not3462 : ~ @Equation3462 Fin3 refa271_inst.
Proof. unfold Equation3462. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa271_inst, refa271_op in H. discriminate H. Qed.

Lemma refa271_not3474 : ~ @Equation3474 Fin3 refa271_inst.
Proof. unfold Equation3474. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa271_inst, refa271_op in H. discriminate H. Qed.

Lemma refa271_not3667 : ~ @Equation3667 Fin3 refa271_inst.
Proof. unfold Equation3667. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa271_inst, refa271_op in H. discriminate H. Qed.

Lemma refa271_not3675 : ~ @Equation3675 Fin3 refa271_inst.
Proof. unfold Equation3675. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa271_inst, refa271_op in H. discriminate H. Qed.

Lemma refa271_not3864 : ~ @Equation3864 Fin3 refa271_inst.
Proof. unfold Equation3864. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa271_inst, refa271_op in H. discriminate H. Qed.

Lemma refa271_not3888 : ~ @Equation3888 Fin3 refa271_inst.
Proof. unfold Equation3888. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa271_inst, refa271_op in H. discriminate H. Qed.

Lemma refa271_not3925 : ~ @Equation3925 Fin3 refa271_inst.
Proof. unfold Equation3925. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa271_inst, refa271_op in H. discriminate H. Qed.

Lemma refa271_not4071 : ~ @Equation4071 Fin3 refa271_inst.
Proof. unfold Equation4071. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa271_inst, refa271_op in H. discriminate H. Qed.

Lemma refa271_not4083 : ~ @Equation4083 Fin3 refa271_inst.
Proof. unfold Equation4083. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa271_inst, refa271_op in H. discriminate H. Qed.

Lemma refa271_not4131 : ~ @Equation4131 Fin3 refa271_inst.
Proof. unfold Equation4131. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa271_inst, refa271_op in H. discriminate H. Qed.

Lemma refa271_not4155 : ~ @Equation4155 Fin3 refa271_inst.
Proof. unfold Equation4155. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa271_inst, refa271_op in H. discriminate H. Qed.

Lemma refa271_not4291 : ~ @Equation4291 Fin3 refa271_inst.
Proof. unfold Equation4291. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa271_inst, refa271_op in H. discriminate H. Qed.

Lemma refa271_not4396 : ~ @Equation4396 Fin3 refa271_inst.
Proof. unfold Equation4396. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa271_inst, refa271_op in H. discriminate H. Qed.

Lemma refa271_not4398 : ~ @Equation4398 Fin3 refa271_inst.
Proof. unfold Equation4398. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa271_inst, refa271_op in H. discriminate H. Qed.

Lemma refa271_not4409 : ~ @Equation4409 Fin3 refa271_inst.
Proof. unfold Equation4409. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa271_inst, refa271_op in H. discriminate H. Qed.

Lemma refa271_not4435 : ~ @Equation4435 Fin3 refa271_inst.
Proof. unfold Equation4435. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa271_inst, refa271_op in H. discriminate H. Qed.

Lemma refa271_not4443 : ~ @Equation4443 Fin3 refa271_inst.
Proof. unfold Equation4443. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa271_inst, refa271_op in H. discriminate H. Qed.

Lemma refa271_not4472 : ~ @Equation4472 Fin3 refa271_inst.
Proof. unfold Equation4472. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa271_inst, refa271_op in H. discriminate H. Qed.

Lemma refa271_not4480 : ~ @Equation4480 Fin3 refa271_inst.
Proof. unfold Equation4480. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa271_inst, refa271_op in H. discriminate H. Qed.

Lemma refa271_not4598 : ~ @Equation4598 Fin3 refa271_inst.
Proof. unfold Equation4598. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa271_inst, refa271_op in H. discriminate H. Qed.

Lemma refa271_not4606 : ~ @Equation4606 Fin3 refa271_inst.
Proof. unfold Equation4606. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa271_inst, refa271_op in H. discriminate H. Qed.

Lemma refa271_not4629 : ~ @Equation4629 Fin3 refa271_inst.
Proof. unfold Equation4629. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa271_inst, refa271_op in H. discriminate H. Qed.

Lemma refa271_not4631 : ~ @Equation4631 Fin3 refa271_inst.
Proof. unfold Equation4631. intro H. specialize (H F3_1 F3_0 F3_2). unfold magma_op, refa271_inst, refa271_op in H. discriminate H. Qed.

Lemma refa271_not4635 : ~ @Equation4635 Fin3 refa271_inst.
Proof. unfold Equation4635. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa271_inst, refa271_op in H. discriminate H. Qed.

Lemma refa271_not4636 : ~ @Equation4636 Fin3 refa271_inst.
Proof. unfold Equation4636. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa271_inst, refa271_op in H. discriminate H. Qed.

Lemma refa271_not4647 : ~ @Equation4647 Fin3 refa271_inst.
Proof. unfold Equation4647. intro H. specialize (H F3_0 F3_1 F3_2). unfold magma_op, refa271_inst, refa271_op in H. discriminate H. Qed.

(** ---- refa272 (Fin3) ---- *)

Definition refa272_op (x y : Fin3) : Fin3 :=
  match x, y with
  | F3_0, F3_0 => F3_0 | F3_0, F3_1 => F3_0 | F3_0, F3_2 => F3_0
  | F3_1, F3_0 => F3_2 | F3_1, F3_1 => F3_1 | F3_1, F3_2 => F3_1
  | F3_2, F3_0 => F3_1 | F3_2, F3_1 => F3_2 | F3_2, F3_2 => F3_2
  end.

#[local] Instance refa272_inst : Magma Fin3 := {| magma_op := refa272_op |}.

Lemma refa272_sat362 : @Equation362 Fin3 refa272_inst.
Proof. unfold Equation362, magma_op, refa272_inst, refa272_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa272_sat1237 : @Equation1237 Fin3 refa272_inst.
Proof. unfold Equation1237, magma_op, refa272_inst, refa272_op. intros x y z w. destruct x, y, z, w; reflexivity. Qed.

Lemma refa272_sat1457 : @Equation1457 Fin3 refa272_inst.
Proof. unfold Equation1457, magma_op, refa272_inst, refa272_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa272_sat2045 : @Equation2045 Fin3 refa272_inst.
Proof. unfold Equation2045, magma_op, refa272_inst, refa272_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa272_sat2055 : @Equation2055 Fin3 refa272_inst.
Proof. unfold Equation2055, magma_op, refa272_inst, refa272_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa272_sat2463 : @Equation2463 Fin3 refa272_inst.
Proof. unfold Equation2463, magma_op, refa272_inst, refa272_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa272_sat2666 : @Equation2666 Fin3 refa272_inst.
Proof. unfold Equation2666, magma_op, refa272_inst, refa272_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa272_sat2883 : @Equation2883 Fin3 refa272_inst.
Proof. unfold Equation2883, magma_op, refa272_inst, refa272_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa272_sat3669 : @Equation3669 Fin3 refa272_inst.
Proof. unfold Equation3669, magma_op, refa272_inst, refa272_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa272_sat3716 : @Equation3716 Fin3 refa272_inst.
Proof. unfold Equation3716, magma_op, refa272_inst, refa272_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa272_sat3874 : @Equation3874 Fin3 refa272_inst.
Proof. unfold Equation3874, magma_op, refa272_inst, refa272_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa272_sat3930 : @Equation3930 Fin3 refa272_inst.
Proof. unfold Equation3930, magma_op, refa272_inst, refa272_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa272_sat4403 : @Equation4403 Fin3 refa272_inst.
Proof. unfold Equation4403, magma_op, refa272_inst, refa272_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa272_not206 : ~ @Equation206 Fin3 refa272_inst.
Proof. unfold Equation206. intro H. specialize (H F3_1 F3_0). unfold magma_op, refa272_inst, refa272_op in H. discriminate H. Qed.

Lemma refa272_not211 : ~ @Equation211 Fin3 refa272_inst.
Proof. unfold Equation211. intro H. specialize (H F3_1 F3_0). unfold magma_op, refa272_inst, refa272_op in H. discriminate H. Qed.

Lemma refa272_not264 : ~ @Equation264 Fin3 refa272_inst.
Proof. unfold Equation264. intro H. specialize (H F3_1 F3_0). unfold magma_op, refa272_inst, refa272_op in H. discriminate H. Qed.

Lemma refa272_not378 : ~ @Equation378 Fin3 refa272_inst.
Proof. unfold Equation378. intro H. specialize (H F3_1 F3_0). unfold magma_op, refa272_inst, refa272_op in H. discriminate H. Qed.

Lemma refa272_not1431 : ~ @Equation1431 Fin3 refa272_inst.
Proof. unfold Equation1431. intro H. specialize (H F3_1 F3_0). unfold magma_op, refa272_inst, refa272_op in H. discriminate H. Qed.

Lemma refa272_not1432 : ~ @Equation1432 Fin3 refa272_inst.
Proof. unfold Equation1432. intro H. specialize (H F3_1 F3_0). unfold magma_op, refa272_inst, refa272_op in H. discriminate H. Qed.

Lemma refa272_not1434 : ~ @Equation1434 Fin3 refa272_inst.
Proof. unfold Equation1434. intro H. specialize (H F3_1 F3_0). unfold magma_op, refa272_inst, refa272_op in H. discriminate H. Qed.

Lemma refa272_not1435 : ~ @Equation1435 Fin3 refa272_inst.
Proof. unfold Equation1435. intro H. specialize (H F3_1 F3_0). unfold magma_op, refa272_inst, refa272_op in H. discriminate H. Qed.

Lemma refa272_not1441 : ~ @Equation1441 Fin3 refa272_inst.
Proof. unfold Equation1441. intro H. specialize (H F3_1 F3_0). unfold magma_op, refa272_inst, refa272_op in H. discriminate H. Qed.

Lemma refa272_not1444 : ~ @Equation1444 Fin3 refa272_inst.
Proof. unfold Equation1444. intro H. specialize (H F3_1 F3_0). unfold magma_op, refa272_inst, refa272_op in H. discriminate H. Qed.

Lemma refa272_not1445 : ~ @Equation1445 Fin3 refa272_inst.
Proof. unfold Equation1445. intro H. specialize (H F3_1 F3_0). unfold magma_op, refa272_inst, refa272_op in H. discriminate H. Qed.

Lemma refa272_not1634 : ~ @Equation1634 Fin3 refa272_inst.
Proof. unfold Equation1634. intro H. specialize (H F3_1 F3_0). unfold magma_op, refa272_inst, refa272_op in H. discriminate H. Qed.

Lemma refa272_not1635 : ~ @Equation1635 Fin3 refa272_inst.
Proof. unfold Equation1635. intro H. specialize (H F3_1 F3_0). unfold magma_op, refa272_inst, refa272_op in H. discriminate H. Qed.

Lemma refa272_not1637 : ~ @Equation1637 Fin3 refa272_inst.
Proof. unfold Equation1637. intro H. specialize (H F3_1 F3_0). unfold magma_op, refa272_inst, refa272_op in H. discriminate H. Qed.

Lemma refa272_not1638 : ~ @Equation1638 Fin3 refa272_inst.
Proof. unfold Equation1638. intro H. specialize (H F3_1 F3_0). unfold magma_op, refa272_inst, refa272_op in H. discriminate H. Qed.

Lemma refa272_not1644 : ~ @Equation1644 Fin3 refa272_inst.
Proof. unfold Equation1644. intro H. specialize (H F3_1 F3_0). unfold magma_op, refa272_inst, refa272_op in H. discriminate H. Qed.

Lemma refa272_not1645 : ~ @Equation1645 Fin3 refa272_inst.
Proof. unfold Equation1645. intro H. specialize (H F3_1 F3_0). unfold magma_op, refa272_inst, refa272_op in H. discriminate H. Qed.

Lemma refa272_not1648 : ~ @Equation1648 Fin3 refa272_inst.
Proof. unfold Equation1648. intro H. specialize (H F3_1 F3_0). unfold magma_op, refa272_inst, refa272_op in H. discriminate H. Qed.

Lemma refa272_not1834 : ~ @Equation1834 Fin3 refa272_inst.
Proof. unfold Equation1834. intro H. specialize (H F3_1 F3_0). unfold magma_op, refa272_inst, refa272_op in H. discriminate H. Qed.

Lemma refa272_not1840 : ~ @Equation1840 Fin3 refa272_inst.
Proof. unfold Equation1840. intro H. specialize (H F3_1 F3_0). unfold magma_op, refa272_inst, refa272_op in H. discriminate H. Qed.

Lemma refa272_not1841 : ~ @Equation1841 Fin3 refa272_inst.
Proof. unfold Equation1841. intro H. specialize (H F3_1 F3_0). unfold magma_op, refa272_inst, refa272_op in H. discriminate H. Qed.

Lemma refa272_not1847 : ~ @Equation1847 Fin3 refa272_inst.
Proof. unfold Equation1847. intro H. specialize (H F3_1 F3_0). unfold magma_op, refa272_inst, refa272_op in H. discriminate H. Qed.

Lemma refa272_not1848 : ~ @Equation1848 Fin3 refa272_inst.
Proof. unfold Equation1848. intro H. specialize (H F3_1 F3_0). unfold magma_op, refa272_inst, refa272_op in H. discriminate H. Qed.

Lemma refa272_not1857 : ~ @Equation1857 Fin3 refa272_inst.
Proof. unfold Equation1857. intro H. specialize (H F3_1 F3_0). unfold magma_op, refa272_inst, refa272_op in H. discriminate H. Qed.

Lemma refa272_not1858 : ~ @Equation1858 Fin3 refa272_inst.
Proof. unfold Equation1858. intro H. specialize (H F3_1 F3_0). unfold magma_op, refa272_inst, refa272_op in H. discriminate H. Qed.

Lemma refa272_not2037 : ~ @Equation2037 Fin3 refa272_inst.
Proof. unfold Equation2037. intro H. specialize (H F3_1 F3_0). unfold magma_op, refa272_inst, refa272_op in H. discriminate H. Qed.

Lemma refa272_not2038 : ~ @Equation2038 Fin3 refa272_inst.
Proof. unfold Equation2038. intro H. specialize (H F3_1 F3_0). unfold magma_op, refa272_inst, refa272_op in H. discriminate H. Qed.

Lemma refa272_not2040 : ~ @Equation2040 Fin3 refa272_inst.
Proof. unfold Equation2040. intro H. specialize (H F3_1 F3_0). unfold magma_op, refa272_inst, refa272_op in H. discriminate H. Qed.

Lemma refa272_not2041 : ~ @Equation2041 Fin3 refa272_inst.
Proof. unfold Equation2041. intro H. specialize (H F3_1 F3_0). unfold magma_op, refa272_inst, refa272_op in H. discriminate H. Qed.

Lemma refa272_not2050 : ~ @Equation2050 Fin3 refa272_inst.
Proof. unfold Equation2050. intro H. specialize (H F3_1 F3_0). unfold magma_op, refa272_inst, refa272_op in H. discriminate H. Qed.

Lemma refa272_not2063 : ~ @Equation2063 Fin3 refa272_inst.
Proof. unfold Equation2063. intro H. specialize (H F3_1 F3_0). unfold magma_op, refa272_inst, refa272_op in H. discriminate H. Qed.

Lemma refa272_not2064 : ~ @Equation2064 Fin3 refa272_inst.
Proof. unfold Equation2064. intro H. specialize (H F3_1 F3_0). unfold magma_op, refa272_inst, refa272_op in H. discriminate H. Qed.

Lemma refa272_not2241 : ~ @Equation2241 Fin3 refa272_inst.
Proof. unfold Equation2241. intro H. specialize (H F3_1 F3_0). unfold magma_op, refa272_inst, refa272_op in H. discriminate H. Qed.

Lemma refa272_not2244 : ~ @Equation2244 Fin3 refa272_inst.
Proof. unfold Equation2244. intro H. specialize (H F3_1 F3_0). unfold magma_op, refa272_inst, refa272_op in H. discriminate H. Qed.

Lemma refa272_not2247 : ~ @Equation2247 Fin3 refa272_inst.
Proof. unfold Equation2247. intro H. specialize (H F3_1 F3_0). unfold magma_op, refa272_inst, refa272_op in H. discriminate H. Qed.

Lemma refa272_not2253 : ~ @Equation2253 Fin3 refa272_inst.
Proof. unfold Equation2253. intro H. specialize (H F3_1 F3_0). unfold magma_op, refa272_inst, refa272_op in H. discriminate H. Qed.

Lemma refa272_not2256 : ~ @Equation2256 Fin3 refa272_inst.
Proof. unfold Equation2256. intro H. specialize (H F3_1 F3_0). unfold magma_op, refa272_inst, refa272_op in H. discriminate H. Qed.

Lemma refa272_not2263 : ~ @Equation2263 Fin3 refa272_inst.
Proof. unfold Equation2263. intro H. specialize (H F3_1 F3_0). unfold magma_op, refa272_inst, refa272_op in H. discriminate H. Qed.

Lemma refa272_not2266 : ~ @Equation2266 Fin3 refa272_inst.
Proof. unfold Equation2266. intro H. specialize (H F3_1 F3_0). unfold magma_op, refa272_inst, refa272_op in H. discriminate H. Qed.

Lemma refa272_not2444 : ~ @Equation2444 Fin3 refa272_inst.
Proof. unfold Equation2444. intro H. specialize (H F3_1 F3_0). unfold magma_op, refa272_inst, refa272_op in H. discriminate H. Qed.

Lemma refa272_not2447 : ~ @Equation2447 Fin3 refa272_inst.
Proof. unfold Equation2447. intro H. specialize (H F3_1 F3_0). unfold magma_op, refa272_inst, refa272_op in H. discriminate H. Qed.

Lemma refa272_not2450 : ~ @Equation2450 Fin3 refa272_inst.
Proof. unfold Equation2450. intro H. specialize (H F3_1 F3_0). unfold magma_op, refa272_inst, refa272_op in H. discriminate H. Qed.

Lemma refa272_not2456 : ~ @Equation2456 Fin3 refa272_inst.
Proof. unfold Equation2456. intro H. specialize (H F3_1 F3_0). unfold magma_op, refa272_inst, refa272_op in H. discriminate H. Qed.

Lemma refa272_not2459 : ~ @Equation2459 Fin3 refa272_inst.
Proof. unfold Equation2459. intro H. specialize (H F3_1 F3_0). unfold magma_op, refa272_inst, refa272_op in H. discriminate H. Qed.

Lemma refa272_not2466 : ~ @Equation2466 Fin3 refa272_inst.
Proof. unfold Equation2466. intro H. specialize (H F3_1 F3_0). unfold magma_op, refa272_inst, refa272_op in H. discriminate H. Qed.

Lemma refa272_not2469 : ~ @Equation2469 Fin3 refa272_inst.
Proof. unfold Equation2469. intro H. specialize (H F3_1 F3_0). unfold magma_op, refa272_inst, refa272_op in H. discriminate H. Qed.

Lemma refa272_not2647 : ~ @Equation2647 Fin3 refa272_inst.
Proof. unfold Equation2647. intro H. specialize (H F3_1 F3_0). unfold magma_op, refa272_inst, refa272_op in H. discriminate H. Qed.

Lemma refa272_not2649 : ~ @Equation2649 Fin3 refa272_inst.
Proof. unfold Equation2649. intro H. specialize (H F3_1 F3_0). unfold magma_op, refa272_inst, refa272_op in H. discriminate H. Qed.

Lemma refa272_not2652 : ~ @Equation2652 Fin3 refa272_inst.
Proof. unfold Equation2652. intro H. specialize (H F3_1 F3_0). unfold magma_op, refa272_inst, refa272_op in H. discriminate H. Qed.

Lemma refa272_not2659 : ~ @Equation2659 Fin3 refa272_inst.
Proof. unfold Equation2659. intro H. specialize (H F3_1 F3_0). unfold magma_op, refa272_inst, refa272_op in H. discriminate H. Qed.

Lemma refa272_not2662 : ~ @Equation2662 Fin3 refa272_inst.
Proof. unfold Equation2662. intro H. specialize (H F3_1 F3_0). unfold magma_op, refa272_inst, refa272_op in H. discriminate H. Qed.

Lemma refa272_not2670 : ~ @Equation2670 Fin3 refa272_inst.
Proof. unfold Equation2670. intro H. specialize (H F3_1 F3_0). unfold magma_op, refa272_inst, refa272_op in H. discriminate H. Qed.

Lemma refa272_not2849 : ~ @Equation2849 Fin3 refa272_inst.
Proof. unfold Equation2849. intro H. specialize (H F3_1 F3_0). unfold magma_op, refa272_inst, refa272_op in H. discriminate H. Qed.

Lemma refa272_not2853 : ~ @Equation2853 Fin3 refa272_inst.
Proof. unfold Equation2853. intro H. specialize (H F3_1 F3_0). unfold magma_op, refa272_inst, refa272_op in H. discriminate H. Qed.

Lemma refa272_not2855 : ~ @Equation2855 Fin3 refa272_inst.
Proof. unfold Equation2855. intro H. specialize (H F3_1 F3_0). unfold magma_op, refa272_inst, refa272_op in H. discriminate H. Qed.

Lemma refa272_not2862 : ~ @Equation2862 Fin3 refa272_inst.
Proof. unfold Equation2862. intro H. specialize (H F3_1 F3_0). unfold magma_op, refa272_inst, refa272_op in H. discriminate H. Qed.

Lemma refa272_not2866 : ~ @Equation2866 Fin3 refa272_inst.
Proof. unfold Equation2866. intro H. specialize (H F3_1 F3_0). unfold magma_op, refa272_inst, refa272_op in H. discriminate H. Qed.

Lemma refa272_not2872 : ~ @Equation2872 Fin3 refa272_inst.
Proof. unfold Equation2872. intro H. specialize (H F3_1 F3_0). unfold magma_op, refa272_inst, refa272_op in H. discriminate H. Qed.

Lemma refa272_not3052 : ~ @Equation3052 Fin3 refa272_inst.
Proof. unfold Equation3052. intro H. specialize (H F3_1 F3_0). unfold magma_op, refa272_inst, refa272_op in H. discriminate H. Qed.

Lemma refa272_not3055 : ~ @Equation3055 Fin3 refa272_inst.
Proof. unfold Equation3055. intro H. specialize (H F3_1 F3_0). unfold magma_op, refa272_inst, refa272_op in H. discriminate H. Qed.

Lemma refa272_not3065 : ~ @Equation3065 Fin3 refa272_inst.
Proof. unfold Equation3065. intro H. specialize (H F3_1 F3_0). unfold magma_op, refa272_inst, refa272_op in H. discriminate H. Qed.

Lemma refa272_not3069 : ~ @Equation3069 Fin3 refa272_inst.
Proof. unfold Equation3069. intro H. specialize (H F3_1 F3_0). unfold magma_op, refa272_inst, refa272_op in H. discriminate H. Qed.

Lemma refa272_not3076 : ~ @Equation3076 Fin3 refa272_inst.
Proof. unfold Equation3076. intro H. specialize (H F3_1 F3_0). unfold magma_op, refa272_inst, refa272_op in H. discriminate H. Qed.

Lemma refa272_not3078 : ~ @Equation3078 Fin3 refa272_inst.
Proof. unfold Equation3078. intro H. specialize (H F3_1 F3_0). unfold magma_op, refa272_inst, refa272_op in H. discriminate H. Qed.

Lemma refa272_not3258 : ~ @Equation3258 Fin3 refa272_inst.
Proof. unfold Equation3258. intro H. specialize (H F3_1 F3_0). unfold magma_op, refa272_inst, refa272_op in H. discriminate H. Qed.

Lemma refa272_not3259 : ~ @Equation3259 Fin3 refa272_inst.
Proof. unfold Equation3259. intro H. specialize (H F3_1 F3_0). unfold magma_op, refa272_inst, refa272_op in H. discriminate H. Qed.

Lemma refa272_not3261 : ~ @Equation3261 Fin3 refa272_inst.
Proof. unfold Equation3261. intro H. specialize (H F3_1 F3_0). unfold magma_op, refa272_inst, refa272_op in H. discriminate H. Qed.

Lemma refa272_not3262 : ~ @Equation3262 Fin3 refa272_inst.
Proof. unfold Equation3262. intro H. specialize (H F3_1 F3_0). unfold magma_op, refa272_inst, refa272_op in H. discriminate H. Qed.

Lemma refa272_not3306 : ~ @Equation3306 Fin3 refa272_inst.
Proof. unfold Equation3306. intro H. specialize (H F3_1 F3_0). unfold magma_op, refa272_inst, refa272_op in H. discriminate H. Qed.

Lemma refa272_not3308 : ~ @Equation3308 Fin3 refa272_inst.
Proof. unfold Equation3308. intro H. specialize (H F3_1 F3_0). unfold magma_op, refa272_inst, refa272_op in H. discriminate H. Qed.

Lemma refa272_not3309 : ~ @Equation3309 Fin3 refa272_inst.
Proof. unfold Equation3309. intro H. specialize (H F3_1 F3_0). unfold magma_op, refa272_inst, refa272_op in H. discriminate H. Qed.

Lemma refa272_not3461 : ~ @Equation3461 Fin3 refa272_inst.
Proof. unfold Equation3461. intro H. specialize (H F3_1 F3_0). unfold magma_op, refa272_inst, refa272_op in H. discriminate H. Qed.

Lemma refa272_not3462 : ~ @Equation3462 Fin3 refa272_inst.
Proof. unfold Equation3462. intro H. specialize (H F3_1 F3_0). unfold magma_op, refa272_inst, refa272_op in H. discriminate H. Qed.

Lemma refa272_not3464 : ~ @Equation3464 Fin3 refa272_inst.
Proof. unfold Equation3464. intro H. specialize (H F3_1 F3_0). unfold magma_op, refa272_inst, refa272_op in H. discriminate H. Qed.

Lemma refa272_not3465 : ~ @Equation3465 Fin3 refa272_inst.
Proof. unfold Equation3465. intro H. specialize (H F3_1 F3_0). unfold magma_op, refa272_inst, refa272_op in H. discriminate H. Qed.

Lemma refa272_not3509 : ~ @Equation3509 Fin3 refa272_inst.
Proof. unfold Equation3509. intro H. specialize (H F3_1 F3_0). unfold magma_op, refa272_inst, refa272_op in H. discriminate H. Qed.

Lemma refa272_not3511 : ~ @Equation3511 Fin3 refa272_inst.
Proof. unfold Equation3511. intro H. specialize (H F3_1 F3_0). unfold magma_op, refa272_inst, refa272_op in H. discriminate H. Qed.

Lemma refa272_not3512 : ~ @Equation3512 Fin3 refa272_inst.
Proof. unfold Equation3512. intro H. specialize (H F3_1 F3_0). unfold magma_op, refa272_inst, refa272_op in H. discriminate H. Qed.

Lemma refa272_not3661 : ~ @Equation3661 Fin3 refa272_inst.
Proof. unfold Equation3661. intro H. specialize (H F3_1 F3_0). unfold magma_op, refa272_inst, refa272_op in H. discriminate H. Qed.

Lemma refa272_not3662 : ~ @Equation3662 Fin3 refa272_inst.
Proof. unfold Equation3662. intro H. specialize (H F3_1 F3_0). unfold magma_op, refa272_inst, refa272_op in H. discriminate H. Qed.

Lemma refa272_not3664 : ~ @Equation3664 Fin3 refa272_inst.
Proof. unfold Equation3664. intro H. specialize (H F3_1 F3_0). unfold magma_op, refa272_inst, refa272_op in H. discriminate H. Qed.

Lemma refa272_not3665 : ~ @Equation3665 Fin3 refa272_inst.
Proof. unfold Equation3665. intro H. specialize (H F3_1 F3_0). unfold magma_op, refa272_inst, refa272_op in H. discriminate H. Qed.

Lemma refa272_not3724 : ~ @Equation3724 Fin3 refa272_inst.
Proof. unfold Equation3724. intro H. specialize (H F3_1 F3_0). unfold magma_op, refa272_inst, refa272_op in H. discriminate H. Qed.

Lemma refa272_not3725 : ~ @Equation3725 Fin3 refa272_inst.
Proof. unfold Equation3725. intro H. specialize (H F3_1 F3_0). unfold magma_op, refa272_inst, refa272_op in H. discriminate H. Qed.

Lemma refa272_not3867 : ~ @Equation3867 Fin3 refa272_inst.
Proof. unfold Equation3867. intro H. specialize (H F3_1 F3_0). unfold magma_op, refa272_inst, refa272_op in H. discriminate H. Qed.

Lemma refa272_not3870 : ~ @Equation3870 Fin3 refa272_inst.
Proof. unfold Equation3870. intro H. specialize (H F3_1 F3_0). unfold magma_op, refa272_inst, refa272_op in H. discriminate H. Qed.

Lemma refa272_not3925 : ~ @Equation3925 Fin3 refa272_inst.
Proof. unfold Equation3925. intro H. specialize (H F3_1 F3_0). unfold magma_op, refa272_inst, refa272_op in H. discriminate H. Qed.

Lemma refa272_not3928 : ~ @Equation3928 Fin3 refa272_inst.
Proof. unfold Equation3928. intro H. specialize (H F3_1 F3_0). unfold magma_op, refa272_inst, refa272_op in H. discriminate H. Qed.

Lemma refa272_not4066 : ~ @Equation4066 Fin3 refa272_inst.
Proof. unfold Equation4066. intro H. specialize (H F3_1 F3_0). unfold magma_op, refa272_inst, refa272_op in H. discriminate H. Qed.

Lemma refa272_not4067 : ~ @Equation4067 Fin3 refa272_inst.
Proof. unfold Equation4067. intro H. specialize (H F3_1 F3_0). unfold magma_op, refa272_inst, refa272_op in H. discriminate H. Qed.

Lemma refa272_not4070 : ~ @Equation4070 Fin3 refa272_inst.
Proof. unfold Equation4070. intro H. specialize (H F3_1 F3_0). unfold magma_op, refa272_inst, refa272_op in H. discriminate H. Qed.

Lemma refa272_not4074 : ~ @Equation4074 Fin3 refa272_inst.
Proof. unfold Equation4074. intro H. specialize (H F3_1 F3_0). unfold magma_op, refa272_inst, refa272_op in H. discriminate H. Qed.

Lemma refa272_not4121 : ~ @Equation4121 Fin3 refa272_inst.
Proof. unfold Equation4121. intro H. specialize (H F3_1 F3_0). unfold magma_op, refa272_inst, refa272_op in H. discriminate H. Qed.

Lemma refa272_not4128 : ~ @Equation4128 Fin3 refa272_inst.
Proof. unfold Equation4128. intro H. specialize (H F3_1 F3_0). unfold magma_op, refa272_inst, refa272_op in H. discriminate H. Qed.

Lemma refa272_not4130 : ~ @Equation4130 Fin3 refa272_inst.
Proof. unfold Equation4130. intro H. specialize (H F3_1 F3_0). unfold magma_op, refa272_inst, refa272_op in H. discriminate H. Qed.

Lemma refa272_not4269 : ~ @Equation4269 Fin3 refa272_inst.
Proof. unfold Equation4269. intro H. specialize (H F3_1 F3_0). unfold magma_op, refa272_inst, refa272_op in H. discriminate H. Qed.

Lemma refa272_not4270 : ~ @Equation4270 Fin3 refa272_inst.
Proof. unfold Equation4270. intro H. specialize (H F3_1 F3_0). unfold magma_op, refa272_inst, refa272_op in H. discriminate H. Qed.

Lemma refa272_not4283 : ~ @Equation4283 Fin3 refa272_inst.
Proof. unfold Equation4283. intro H. specialize (H F3_1 F3_0). unfold magma_op, refa272_inst, refa272_op in H. discriminate H. Qed.

Lemma refa272_not4284 : ~ @Equation4284 Fin3 refa272_inst.
Proof. unfold Equation4284. intro H. specialize (H F3_1 F3_0). unfold magma_op, refa272_inst, refa272_op in H. discriminate H. Qed.

Lemma refa272_not4398 : ~ @Equation4398 Fin3 refa272_inst.
Proof. unfold Equation4398. intro H. specialize (H F3_1 F3_0). unfold magma_op, refa272_inst, refa272_op in H. discriminate H. Qed.

Lemma refa272_not4436 : ~ @Equation4436 Fin3 refa272_inst.
Proof. unfold Equation4436. intro H. specialize (H F3_1 F3_0). unfold magma_op, refa272_inst, refa272_op in H. discriminate H. Qed.

Lemma refa272_not4473 : ~ @Equation4473 Fin3 refa272_inst.
Proof. unfold Equation4473. intro H. specialize (H F3_1 F3_0). unfold magma_op, refa272_inst, refa272_op in H. discriminate H. Qed.

Lemma refa272_not4583 : ~ @Equation4583 Fin3 refa272_inst.
Proof. unfold Equation4583. intro H. specialize (H F3_1 F3_0). unfold magma_op, refa272_inst, refa272_op in H. discriminate H. Qed.

Lemma refa272_not4584 : ~ @Equation4584 Fin3 refa272_inst.
Proof. unfold Equation4584. intro H. specialize (H F3_1 F3_0). unfold magma_op, refa272_inst, refa272_op in H. discriminate H. Qed.

Lemma refa272_not4599 : ~ @Equation4599 Fin3 refa272_inst.
Proof. unfold Equation4599. intro H. specialize (H F3_1 F3_0). unfold magma_op, refa272_inst, refa272_op in H. discriminate H. Qed.

Lemma refa272_not4629 : ~ @Equation4629 Fin3 refa272_inst.
Proof. unfold Equation4629. intro H. specialize (H F3_1 F3_0). unfold magma_op, refa272_inst, refa272_op in H. discriminate H. Qed.

(** ---- refa273 (Fin3) ---- *)

Definition refa273_op (x y : Fin3) : Fin3 :=
  match x, y with
  | F3_0, F3_0 => F3_1 | F3_0, F3_1 => F3_1 | F3_0, F3_2 => F3_1
  | F3_1, F3_0 => F3_0 | F3_1, F3_1 => F3_2 | F3_1, F3_2 => F3_0
  | F3_2, F3_0 => F3_1 | F3_2, F3_1 => F3_1 | F3_2, F3_2 => F3_1
  end.

#[local] Instance refa273_inst : Magma Fin3 := {| magma_op := refa273_op |}.

Lemma refa273_sat3527 : @Equation3527 Fin3 refa273_inst.
Proof. unfold Equation3527, magma_op, refa273_inst, refa273_op. intros x y z w. destruct x, y, z, w; reflexivity. Qed.

Lemma refa273_not359 : ~ @Equation359 Fin3 refa273_inst.
Proof. unfold Equation359. intro H. specialize (H F3_0). unfold magma_op, refa273_inst, refa273_op in H. discriminate H. Qed.

Lemma refa273_not3253 : ~ @Equation3253 Fin3 refa273_inst.
Proof. unfold Equation3253. intro H. specialize (H F3_1). unfold magma_op, refa273_inst, refa273_op in H. discriminate H. Qed.

Lemma refa273_not3461 : ~ @Equation3461 Fin3 refa273_inst.
Proof. unfold Equation3461. intro H. specialize (H F3_1 F3_0). unfold magma_op, refa273_inst, refa273_op in H. discriminate H. Qed.

Lemma refa273_not3462 : ~ @Equation3462 Fin3 refa273_inst.
Proof. unfold Equation3462. intro H. specialize (H F3_1 F3_0). unfold magma_op, refa273_inst, refa273_op in H. discriminate H. Qed.

Lemma refa273_not3464 : ~ @Equation3464 Fin3 refa273_inst.
Proof. unfold Equation3464. intro H. specialize (H F3_1 F3_0). unfold magma_op, refa273_inst, refa273_op in H. discriminate H. Qed.

Lemma refa273_not3465 : ~ @Equation3465 Fin3 refa273_inst.
Proof. unfold Equation3465. intro H. specialize (H F3_1 F3_0). unfold magma_op, refa273_inst, refa273_op in H. discriminate H. Qed.

Lemma refa273_not3509 : ~ @Equation3509 Fin3 refa273_inst.
Proof. unfold Equation3509. intro H. specialize (H F3_1 F3_0). unfold magma_op, refa273_inst, refa273_op in H. discriminate H. Qed.

Lemma refa273_not3659 : ~ @Equation3659 Fin3 refa273_inst.
Proof. unfold Equation3659. intro H. specialize (H F3_0). unfold magma_op, refa273_inst, refa273_op in H. discriminate H. Qed.

Lemma refa273_not3862 : ~ @Equation3862 Fin3 refa273_inst.
Proof. unfold Equation3862. intro H. specialize (H F3_0). unfold magma_op, refa273_inst, refa273_op in H. discriminate H. Qed.

Lemma refa273_not4269 : ~ @Equation4269 Fin3 refa273_inst.
Proof. unfold Equation4269. intro H. specialize (H F3_1 F3_0). unfold magma_op, refa273_inst, refa273_op in H. discriminate H. Qed.

Lemma refa273_not4380 : ~ @Equation4380 Fin3 refa273_inst.
Proof. unfold Equation4380. intro H. specialize (H F3_0). unfold magma_op, refa273_inst, refa273_op in H. discriminate H. Qed.

Lemma refa273_not4598 : ~ @Equation4598 Fin3 refa273_inst.
Proof. unfold Equation4598. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa273_inst, refa273_op in H. discriminate H. Qed.

Lemma refa273_not4629 : ~ @Equation4629 Fin3 refa273_inst.
Proof. unfold Equation4629. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa273_inst, refa273_op in H. discriminate H. Qed.

(** ---- refa274 (Fin3) ---- *)

Definition refa274_op (x y : Fin3) : Fin3 :=
  match x, y with
  | F3_0, F3_0 => F3_0 | F3_0, F3_1 => F3_2 | F3_0, F3_2 => F3_1
  | F3_1, F3_0 => F3_0 | F3_1, F3_1 => F3_2 | F3_1, F3_2 => F3_0
  | F3_2, F3_0 => F3_0 | F3_2, F3_1 => F3_0 | F3_2, F3_2 => F3_1
  end.

#[local] Instance refa274_inst : Magma Fin3 := {| magma_op := refa274_op |}.

Lemma refa274_sat166 : @Equation166 Fin3 refa274_inst.
Proof. unfold Equation166, magma_op, refa274_inst, refa274_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa274_sat1867 : @Equation1867 Fin3 refa274_inst.
Proof. unfold Equation1867, magma_op, refa274_inst, refa274_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa274_sat1975 : @Equation1975 Fin3 refa274_inst.
Proof. unfold Equation1975, magma_op, refa274_inst, refa274_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa274_sat3883 : @Equation3883 Fin3 refa274_inst.
Proof. unfold Equation3883, magma_op, refa274_inst, refa274_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa274_sat3897 : @Equation3897 Fin3 refa274_inst.
Proof. unfold Equation3897, magma_op, refa274_inst, refa274_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa274_sat3901 : @Equation3901 Fin3 refa274_inst.
Proof. unfold Equation3901, magma_op, refa274_inst, refa274_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa274_not99 : ~ @Equation99 Fin3 refa274_inst.
Proof. unfold Equation99. intro H. specialize (H F3_1). unfold magma_op, refa274_inst, refa274_op in H. discriminate H. Qed.

Lemma refa274_not159 : ~ @Equation159 Fin3 refa274_inst.
Proof. unfold Equation159. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa274_inst, refa274_op in H. discriminate H. Qed.

Lemma refa274_not359 : ~ @Equation359 Fin3 refa274_inst.
Proof. unfold Equation359. intro H. specialize (H F3_1). unfold magma_op, refa274_inst, refa274_op in H. discriminate H. Qed.

Lemma refa274_not411 : ~ @Equation411 Fin3 refa274_inst.
Proof. unfold Equation411. intro H. specialize (H F3_1). unfold magma_op, refa274_inst, refa274_op in H. discriminate H. Qed.

Lemma refa274_not1020 : ~ @Equation1020 Fin3 refa274_inst.
Proof. unfold Equation1020. intro H. specialize (H F3_1). unfold magma_op, refa274_inst, refa274_op in H. discriminate H. Qed.

Lemma refa274_not1223 : ~ @Equation1223 Fin3 refa274_inst.
Proof. unfold Equation1223. intro H. specialize (H F3_1). unfold magma_op, refa274_inst, refa274_op in H. discriminate H. Qed.

Lemma refa274_not1629 : ~ @Equation1629 Fin3 refa274_inst.
Proof. unfold Equation1629. intro H. specialize (H F3_1). unfold magma_op, refa274_inst, refa274_op in H. discriminate H. Qed.

Lemma refa274_not1834 : ~ @Equation1834 Fin3 refa274_inst.
Proof. unfold Equation1834. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa274_inst, refa274_op in H. discriminate H. Qed.

Lemma refa274_not1840 : ~ @Equation1840 Fin3 refa274_inst.
Proof. unfold Equation1840. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa274_inst, refa274_op in H. discriminate H. Qed.

Lemma refa274_not1850 : ~ @Equation1850 Fin3 refa274_inst.
Proof. unfold Equation1850. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa274_inst, refa274_op in H. discriminate H. Qed.

Lemma refa274_not1860 : ~ @Equation1860 Fin3 refa274_inst.
Proof. unfold Equation1860. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa274_inst, refa274_op in H. discriminate H. Qed.

Lemma refa274_not1897 : ~ @Equation1897 Fin3 refa274_inst.
Proof. unfold Equation1897. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa274_inst, refa274_op in H. discriminate H. Qed.

Lemma refa274_not1921 : ~ @Equation1921 Fin3 refa274_inst.
Proof. unfold Equation1921. intro H. specialize (H F3_1 F3_0). unfold magma_op, refa274_inst, refa274_op in H. discriminate H. Qed.

Lemma refa274_not1924 : ~ @Equation1924 Fin3 refa274_inst.
Proof. unfold Equation1924. intro H. specialize (H F3_1 F3_0). unfold magma_op, refa274_inst, refa274_op in H. discriminate H. Qed.

Lemma refa274_not2037 : ~ @Equation2037 Fin3 refa274_inst.
Proof. unfold Equation2037. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa274_inst, refa274_op in H. discriminate H. Qed.

Lemma refa274_not2040 : ~ @Equation2040 Fin3 refa274_inst.
Proof. unfold Equation2040. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa274_inst, refa274_op in H. discriminate H. Qed.

Lemma refa274_not2043 : ~ @Equation2043 Fin3 refa274_inst.
Proof. unfold Equation2043. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa274_inst, refa274_op in H. discriminate H. Qed.

Lemma refa274_not2060 : ~ @Equation2060 Fin3 refa274_inst.
Proof. unfold Equation2060. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa274_inst, refa274_op in H. discriminate H. Qed.

Lemma refa274_not2063 : ~ @Equation2063 Fin3 refa274_inst.
Proof. unfold Equation2063. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa274_inst, refa274_op in H. discriminate H. Qed.

Lemma refa274_not2127 : ~ @Equation2127 Fin3 refa274_inst.
Proof. unfold Equation2127. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa274_inst, refa274_op in H. discriminate H. Qed.

Lemma refa274_not3253 : ~ @Equation3253 Fin3 refa274_inst.
Proof. unfold Equation3253. intro H. specialize (H F3_1). unfold magma_op, refa274_inst, refa274_op in H. discriminate H. Qed.

Lemma refa274_not3659 : ~ @Equation3659 Fin3 refa274_inst.
Proof. unfold Equation3659. intro H. specialize (H F3_1). unfold magma_op, refa274_inst, refa274_op in H. discriminate H. Qed.

Lemma refa274_not3865 : ~ @Equation3865 Fin3 refa274_inst.
Proof. unfold Equation3865. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa274_inst, refa274_op in H. discriminate H. Qed.

Lemma refa274_not3870 : ~ @Equation3870 Fin3 refa274_inst.
Proof. unfold Equation3870. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa274_inst, refa274_op in H. discriminate H. Qed.

Lemma refa274_not3893 : ~ @Equation3893 Fin3 refa274_inst.
Proof. unfold Equation3893. intro H. specialize (H F3_1 F3_0 F3_2). unfold magma_op, refa274_inst, refa274_op in H. discriminate H. Qed.

Lemma refa274_not3915 : ~ @Equation3915 Fin3 refa274_inst.
Proof. unfold Equation3915. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa274_inst, refa274_op in H. discriminate H. Qed.

Lemma refa274_not3918 : ~ @Equation3918 Fin3 refa274_inst.
Proof. unfold Equation3918. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa274_inst, refa274_op in H. discriminate H. Qed.

Lemma refa274_not3925 : ~ @Equation3925 Fin3 refa274_inst.
Proof. unfold Equation3925. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa274_inst, refa274_op in H. discriminate H. Qed.

Lemma refa274_not3928 : ~ @Equation3928 Fin3 refa274_inst.
Proof. unfold Equation3928. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa274_inst, refa274_op in H. discriminate H. Qed.

Lemma refa274_not3955 : ~ @Equation3955 Fin3 refa274_inst.
Proof. unfold Equation3955. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa274_inst, refa274_op in H. discriminate H. Qed.

Lemma refa274_not3962 : ~ @Equation3962 Fin3 refa274_inst.
Proof. unfold Equation3962. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa274_inst, refa274_op in H. discriminate H. Qed.

Lemma refa274_not4070 : ~ @Equation4070 Fin3 refa274_inst.
Proof. unfold Equation4070. intro H. specialize (H F3_1 F3_0). unfold magma_op, refa274_inst, refa274_op in H. discriminate H. Qed.

Lemma refa274_not4090 : ~ @Equation4090 Fin3 refa274_inst.
Proof. unfold Equation4090. intro H. specialize (H F3_1 F3_0). unfold magma_op, refa274_inst, refa274_op in H. discriminate H. Qed.

Lemma refa274_not4118 : ~ @Equation4118 Fin3 refa274_inst.
Proof. unfold Equation4118. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa274_inst, refa274_op in H. discriminate H. Qed.

Lemma refa274_not4121 : ~ @Equation4121 Fin3 refa274_inst.
Proof. unfold Equation4121. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa274_inst, refa274_op in H. discriminate H. Qed.

Lemma refa274_not4128 : ~ @Equation4128 Fin3 refa274_inst.
Proof. unfold Equation4128. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa274_inst, refa274_op in H. discriminate H. Qed.

Lemma refa274_not4155 : ~ @Equation4155 Fin3 refa274_inst.
Proof. unfold Equation4155. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa274_inst, refa274_op in H. discriminate H. Qed.

Lemma refa274_not4158 : ~ @Equation4158 Fin3 refa274_inst.
Proof. unfold Equation4158. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa274_inst, refa274_op in H. discriminate H. Qed.

Lemma refa274_not4165 : ~ @Equation4165 Fin3 refa274_inst.
Proof. unfold Equation4165. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa274_inst, refa274_op in H. discriminate H. Qed.

Lemma refa274_not4272 : ~ @Equation4272 Fin3 refa274_inst.
Proof. unfold Equation4272. intro H. specialize (H F3_1 F3_0). unfold magma_op, refa274_inst, refa274_op in H. discriminate H. Qed.

Lemma refa274_not4275 : ~ @Equation4275 Fin3 refa274_inst.
Proof. unfold Equation4275. intro H. specialize (H F3_1 F3_0). unfold magma_op, refa274_inst, refa274_op in H. discriminate H. Qed.

Lemma refa274_not4284 : ~ @Equation4284 Fin3 refa274_inst.
Proof. unfold Equation4284. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa274_inst, refa274_op in H. discriminate H. Qed.

Lemma refa274_not4291 : ~ @Equation4291 Fin3 refa274_inst.
Proof. unfold Equation4291. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa274_inst, refa274_op in H. discriminate H. Qed.

Lemma refa274_not4314 : ~ @Equation4314 Fin3 refa274_inst.
Proof. unfold Equation4314. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa274_inst, refa274_op in H. discriminate H. Qed.

Lemma refa274_not4320 : ~ @Equation4320 Fin3 refa274_inst.
Proof. unfold Equation4320. intro H. specialize (H F3_1 F3_0). unfold magma_op, refa274_inst, refa274_op in H. discriminate H. Qed.

Lemma refa274_not4584 : ~ @Equation4584 Fin3 refa274_inst.
Proof. unfold Equation4584. intro H. specialize (H F3_1 F3_0). unfold magma_op, refa274_inst, refa274_op in H. discriminate H. Qed.

Lemma refa274_not4587 : ~ @Equation4587 Fin3 refa274_inst.
Proof. unfold Equation4587. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa274_inst, refa274_op in H. discriminate H. Qed.

Lemma refa274_not4590 : ~ @Equation4590 Fin3 refa274_inst.
Proof. unfold Equation4590. intro H. specialize (H F3_1 F3_0). unfold magma_op, refa274_inst, refa274_op in H. discriminate H. Qed.

Lemma refa274_not4599 : ~ @Equation4599 Fin3 refa274_inst.
Proof. unfold Equation4599. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa274_inst, refa274_op in H. discriminate H. Qed.

Lemma refa274_not4635 : ~ @Equation4635 Fin3 refa274_inst.
Proof. unfold Equation4635. intro H. specialize (H F3_1 F3_0). unfold magma_op, refa274_inst, refa274_op in H. discriminate H. Qed.

(** ---- refa275 (Fin3) ---- *)

Definition refa275_op (x y : Fin3) : Fin3 :=
  match x, y with
  | F3_0, F3_0 => F3_0 | F3_0, F3_1 => F3_0 | F3_0, F3_2 => F3_0
  | F3_1, F3_0 => F3_0 | F3_1, F3_1 => F3_0 | F3_1, F3_2 => F3_0
  | F3_2, F3_0 => F3_1 | F3_2, F3_1 => F3_0 | F3_2, F3_2 => F3_1
  end.

#[local] Instance refa275_inst : Magma Fin3 := {| magma_op := refa275_op |}.

Lemma refa275_sat3470 : @Equation3470 Fin3 refa275_inst.
Proof. unfold Equation3470, magma_op, refa275_inst, refa275_op. intros x y z w. destruct x, y, z, w; reflexivity. Qed.

Lemma refa275_sat4387 : @Equation4387 Fin3 refa275_inst.
Proof. unfold Equation4387, magma_op, refa275_inst, refa275_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa275_not307 : ~ @Equation307 Fin3 refa275_inst.
Proof. unfold Equation307. intro H. specialize (H F3_2). unfold magma_op, refa275_inst, refa275_op in H. discriminate H. Qed.

Lemma refa275_not3255 : ~ @Equation3255 Fin3 refa275_inst.
Proof. unfold Equation3255. intro H. specialize (H F3_2 F3_0). unfold magma_op, refa275_inst, refa275_op in H. discriminate H. Qed.

Lemma refa275_not3256 : ~ @Equation3256 Fin3 refa275_inst.
Proof. unfold Equation3256. intro H. specialize (H F3_2 F3_0). unfold magma_op, refa275_inst, refa275_op in H. discriminate H. Qed.

Lemma refa275_not3660 : ~ @Equation3660 Fin3 refa275_inst.
Proof. unfold Equation3660. intro H. specialize (H F3_2 F3_0). unfold magma_op, refa275_inst, refa275_op in H. discriminate H. Qed.

Lemma refa275_not3661 : ~ @Equation3661 Fin3 refa275_inst.
Proof. unfold Equation3661. intro H. specialize (H F3_2 F3_0). unfold magma_op, refa275_inst, refa275_op in H. discriminate H. Qed.

Lemma refa275_not3662 : ~ @Equation3662 Fin3 refa275_inst.
Proof. unfold Equation3662. intro H. specialize (H F3_2 F3_0). unfold magma_op, refa275_inst, refa275_op in H. discriminate H. Qed.

Lemma refa275_not3665 : ~ @Equation3665 Fin3 refa275_inst.
Proof. unfold Equation3665. intro H. specialize (H F3_2 F3_0). unfold magma_op, refa275_inst, refa275_op in H. discriminate H. Qed.

Lemma refa275_not3667 : ~ @Equation3667 Fin3 refa275_inst.
Proof. unfold Equation3667. intro H. specialize (H F3_2 F3_0). unfold magma_op, refa275_inst, refa275_op in H. discriminate H. Qed.

Lemma refa275_not3668 : ~ @Equation3668 Fin3 refa275_inst.
Proof. unfold Equation3668. intro H. specialize (H F3_2 F3_0). unfold magma_op, refa275_inst, refa275_op in H. discriminate H. Qed.

Lemma refa275_not3862 : ~ @Equation3862 Fin3 refa275_inst.
Proof. unfold Equation3862. intro H. specialize (H F3_2). unfold magma_op, refa275_inst, refa275_op in H. discriminate H. Qed.

Lemma refa275_not4065 : ~ @Equation4065 Fin3 refa275_inst.
Proof. unfold Equation4065. intro H. specialize (H F3_2). unfold magma_op, refa275_inst, refa275_op in H. discriminate H. Qed.

Lemma refa275_not4268 : ~ @Equation4268 Fin3 refa275_inst.
Proof. unfold Equation4268. intro H. specialize (H F3_2 F3_1). unfold magma_op, refa275_inst, refa275_op in H. discriminate H. Qed.

Lemma refa275_not4269 : ~ @Equation4269 Fin3 refa275_inst.
Proof. unfold Equation4269. intro H. specialize (H F3_2 F3_0). unfold magma_op, refa275_inst, refa275_op in H. discriminate H. Qed.

Lemma refa275_not4270 : ~ @Equation4270 Fin3 refa275_inst.
Proof. unfold Equation4270. intro H. specialize (H F3_2 F3_0). unfold magma_op, refa275_inst, refa275_op in H. discriminate H. Qed.

Lemma refa275_not4272 : ~ @Equation4272 Fin3 refa275_inst.
Proof. unfold Equation4272. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa275_inst, refa275_op in H. discriminate H. Qed.

Lemma refa275_not4273 : ~ @Equation4273 Fin3 refa275_inst.
Proof. unfold Equation4273. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa275_inst, refa275_op in H. discriminate H. Qed.

Lemma refa275_not4283 : ~ @Equation4283 Fin3 refa275_inst.
Proof. unfold Equation4283. intro H. specialize (H F3_2 F3_0). unfold magma_op, refa275_inst, refa275_op in H. discriminate H. Qed.

Lemma refa275_not4284 : ~ @Equation4284 Fin3 refa275_inst.
Proof. unfold Equation4284. intro H. specialize (H F3_2 F3_0). unfold magma_op, refa275_inst, refa275_op in H. discriminate H. Qed.

Lemma refa275_not4293 : ~ @Equation4293 Fin3 refa275_inst.
Proof. unfold Equation4293. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa275_inst, refa275_op in H. discriminate H. Qed.

Lemma refa275_not4320 : ~ @Equation4320 Fin3 refa275_inst.
Proof. unfold Equation4320. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa275_inst, refa275_op in H. discriminate H. Qed.

Lemma refa275_not4343 : ~ @Equation4343 Fin3 refa275_inst.
Proof. unfold Equation4343. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa275_inst, refa275_op in H. discriminate H. Qed.

Lemma refa275_not4396 : ~ @Equation4396 Fin3 refa275_inst.
Proof. unfold Equation4396. intro H. specialize (H F3_2 F3_1). unfold magma_op, refa275_inst, refa275_op in H. discriminate H. Qed.

Lemma refa275_not4398 : ~ @Equation4398 Fin3 refa275_inst.
Proof. unfold Equation4398. intro H. specialize (H F3_2 F3_1). unfold magma_op, refa275_inst, refa275_op in H. discriminate H. Qed.

Lemma refa275_not4433 : ~ @Equation4433 Fin3 refa275_inst.
Proof. unfold Equation4433. intro H. specialize (H F3_2 F3_0). unfold magma_op, refa275_inst, refa275_op in H. discriminate H. Qed.

Lemma refa275_not4435 : ~ @Equation4435 Fin3 refa275_inst.
Proof. unfold Equation4435. intro H. specialize (H F3_2 F3_0). unfold magma_op, refa275_inst, refa275_op in H. discriminate H. Qed.

Lemma refa275_not4436 : ~ @Equation4436 Fin3 refa275_inst.
Proof. unfold Equation4436. intro H. specialize (H F3_2 F3_0). unfold magma_op, refa275_inst, refa275_op in H. discriminate H. Qed.

Lemma refa275_not4442 : ~ @Equation4442 Fin3 refa275_inst.
Proof. unfold Equation4442. intro H. specialize (H F3_2 F3_0). unfold magma_op, refa275_inst, refa275_op in H. discriminate H. Qed.

Lemma refa275_not4443 : ~ @Equation4443 Fin3 refa275_inst.
Proof. unfold Equation4443. intro H. specialize (H F3_2 F3_0). unfold magma_op, refa275_inst, refa275_op in H. discriminate H. Qed.

Lemma refa275_not4445 : ~ @Equation4445 Fin3 refa275_inst.
Proof. unfold Equation4445. intro H. specialize (H F3_2 F3_0). unfold magma_op, refa275_inst, refa275_op in H. discriminate H. Qed.

Lemma refa275_not4470 : ~ @Equation4470 Fin3 refa275_inst.
Proof. unfold Equation4470. intro H. specialize (H F3_2 F3_0). unfold magma_op, refa275_inst, refa275_op in H. discriminate H. Qed.

Lemma refa275_not4472 : ~ @Equation4472 Fin3 refa275_inst.
Proof. unfold Equation4472. intro H. specialize (H F3_2 F3_0). unfold magma_op, refa275_inst, refa275_op in H. discriminate H. Qed.

Lemma refa275_not4473 : ~ @Equation4473 Fin3 refa275_inst.
Proof. unfold Equation4473. intro H. specialize (H F3_2 F3_0). unfold magma_op, refa275_inst, refa275_op in H. discriminate H. Qed.

Lemma refa275_not4479 : ~ @Equation4479 Fin3 refa275_inst.
Proof. unfold Equation4479. intro H. specialize (H F3_2 F3_0). unfold magma_op, refa275_inst, refa275_op in H. discriminate H. Qed.

Lemma refa275_not4480 : ~ @Equation4480 Fin3 refa275_inst.
Proof. unfold Equation4480. intro H. specialize (H F3_2 F3_0). unfold magma_op, refa275_inst, refa275_op in H. discriminate H. Qed.

Lemma refa275_not4482 : ~ @Equation4482 Fin3 refa275_inst.
Proof. unfold Equation4482. intro H. specialize (H F3_2 F3_0). unfold magma_op, refa275_inst, refa275_op in H. discriminate H. Qed.

(** ---- refa276 (Fin3) ---- *)

Definition refa276_op (x y : Fin3) : Fin3 :=
  match x, y with
  | F3_0, F3_0 => F3_1 | F3_0, F3_1 => F3_0 | F3_0, F3_2 => F3_0
  | F3_1, F3_0 => F3_1 | F3_1, F3_1 => F3_2 | F3_1, F3_2 => F3_1
  | F3_2, F3_0 => F3_2 | F3_2, F3_1 => F3_2 | F3_2, F3_2 => F3_0
  end.

#[local] Instance refa276_inst : Magma Fin3 := {| magma_op := refa276_op |}.

Lemma refa276_sat100 : @Equation100 Fin3 refa276_inst.
Proof. unfold Equation100, magma_op, refa276_inst, refa276_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa276_sat361 : @Equation361 Fin3 refa276_inst.
Proof. unfold Equation361, magma_op, refa276_inst, refa276_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa276_sat433 : @Equation433 Fin3 refa276_inst.
Proof. unfold Equation433, magma_op, refa276_inst, refa276_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa276_sat839 : @Equation839 Fin3 refa276_inst.
Proof. unfold Equation839, magma_op, refa276_inst, refa276_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa276_not105 : ~ @Equation105 Fin3 refa276_inst.
Proof. unfold Equation105. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa276_inst, refa276_op in H. discriminate H. Qed.

Lemma refa276_not108 : ~ @Equation108 Fin3 refa276_inst.
Proof. unfold Equation108. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa276_inst, refa276_op in H. discriminate H. Qed.

Lemma refa276_not436 : ~ @Equation436 Fin3 refa276_inst.
Proof. unfold Equation436. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa276_inst, refa276_op in H. discriminate H. Qed.

Lemma refa276_not437 : ~ @Equation437 Fin3 refa276_inst.
Proof. unfold Equation437. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa276_inst, refa276_op in H. discriminate H. Qed.

Lemma refa276_not440 : ~ @Equation440 Fin3 refa276_inst.
Proof. unfold Equation440. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa276_inst, refa276_op in H. discriminate H. Qed.

Lemma refa276_not835 : ~ @Equation835 Fin3 refa276_inst.
Proof. unfold Equation835. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa276_inst, refa276_op in H. discriminate H. Qed.

Lemma refa276_not840 : ~ @Equation840 Fin3 refa276_inst.
Proof. unfold Equation840. intro H. specialize (H F3_0 F3_2 F3_1). unfold magma_op, refa276_inst, refa276_op in H. discriminate H. Qed.

Lemma refa276_not842 : ~ @Equation842 Fin3 refa276_inst.
Proof. unfold Equation842. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa276_inst, refa276_op in H. discriminate H. Qed.

Lemma refa276_not845 : ~ @Equation845 Fin3 refa276_inst.
Proof. unfold Equation845. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa276_inst, refa276_op in H. discriminate H. Qed.

Lemma refa276_not846 : ~ @Equation846 Fin3 refa276_inst.
Proof. unfold Equation846. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa276_inst, refa276_op in H. discriminate H. Qed.

Lemma refa276_not1036 : ~ @Equation1036 Fin3 refa276_inst.
Proof. unfold Equation1036. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa276_inst, refa276_op in H. discriminate H. Qed.

Lemma refa276_not1039 : ~ @Equation1039 Fin3 refa276_inst.
Proof. unfold Equation1039. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa276_inst, refa276_op in H. discriminate H. Qed.

Lemma refa276_not1046 : ~ @Equation1046 Fin3 refa276_inst.
Proof. unfold Equation1046. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa276_inst, refa276_op in H. discriminate H. Qed.

Lemma refa276_not1049 : ~ @Equation1049 Fin3 refa276_inst.
Proof. unfold Equation1049. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa276_inst, refa276_op in H. discriminate H. Qed.

Lemma refa276_not1227 : ~ @Equation1227 Fin3 refa276_inst.
Proof. unfold Equation1227. intro H. specialize (H F3_0 F3_1 F3_2). unfold magma_op, refa276_inst, refa276_op in H. discriminate H. Qed.

Lemma refa276_not1239 : ~ @Equation1239 Fin3 refa276_inst.
Proof. unfold Equation1239. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa276_inst, refa276_op in H. discriminate H. Qed.

Lemma refa276_not1242 : ~ @Equation1242 Fin3 refa276_inst.
Proof. unfold Equation1242. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa276_inst, refa276_op in H. discriminate H. Qed.

Lemma refa276_not1250 : ~ @Equation1250 Fin3 refa276_inst.
Proof. unfold Equation1250. intro H. specialize (H F3_0 F3_1 F3_2). unfold magma_op, refa276_inst, refa276_op in H. discriminate H. Qed.

Lemma refa276_not1252 : ~ @Equation1252 Fin3 refa276_inst.
Proof. unfold Equation1252. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa276_inst, refa276_op in H. discriminate H. Qed.

Lemma refa276_not1851 : ~ @Equation1851 Fin3 refa276_inst.
Proof. unfold Equation1851. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa276_inst, refa276_op in H. discriminate H. Qed.

Lemma refa276_not1857 : ~ @Equation1857 Fin3 refa276_inst.
Proof. unfold Equation1857. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa276_inst, refa276_op in H. discriminate H. Qed.

Lemma refa276_not1860 : ~ @Equation1860 Fin3 refa276_inst.
Proof. unfold Equation1860. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa276_inst, refa276_op in H. discriminate H. Qed.

Lemma refa276_not1861 : ~ @Equation1861 Fin3 refa276_inst.
Proof. unfold Equation1861. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa276_inst, refa276_op in H. discriminate H. Qed.

Lemma refa276_not3256 : ~ @Equation3256 Fin3 refa276_inst.
Proof. unfold Equation3256. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa276_inst, refa276_op in H. discriminate H. Qed.

Lemma refa276_not3278 : ~ @Equation3278 Fin3 refa276_inst.
Proof. unfold Equation3278. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa276_inst, refa276_op in H. discriminate H. Qed.

Lemma refa276_not3279 : ~ @Equation3279 Fin3 refa276_inst.
Proof. unfold Equation3279. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa276_inst, refa276_op in H. discriminate H. Qed.

Lemma refa276_not3318 : ~ @Equation3318 Fin3 refa276_inst.
Proof. unfold Equation3318. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa276_inst, refa276_op in H. discriminate H. Qed.

Lemma refa276_not3659 : ~ @Equation3659 Fin3 refa276_inst.
Proof. unfold Equation3659. intro H. specialize (H F3_0). unfold magma_op, refa276_inst, refa276_op in H. discriminate H. Qed.

Lemma refa276_not3865 : ~ @Equation3865 Fin3 refa276_inst.
Proof. unfold Equation3865. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa276_inst, refa276_op in H. discriminate H. Qed.

Lemma refa276_not3878 : ~ @Equation3878 Fin3 refa276_inst.
Proof. unfold Equation3878. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa276_inst, refa276_op in H. discriminate H. Qed.

Lemma refa276_not3881 : ~ @Equation3881 Fin3 refa276_inst.
Proof. unfold Equation3881. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa276_inst, refa276_op in H. discriminate H. Qed.

Lemma refa276_not3887 : ~ @Equation3887 Fin3 refa276_inst.
Proof. unfold Equation3887. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa276_inst, refa276_op in H. discriminate H. Qed.

Lemma refa276_not3888 : ~ @Equation3888 Fin3 refa276_inst.
Proof. unfold Equation3888. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa276_inst, refa276_op in H. discriminate H. Qed.

Lemma refa276_not3928 : ~ @Equation3928 Fin3 refa276_inst.
Proof. unfold Equation3928. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa276_inst, refa276_op in H. discriminate H. Qed.

Lemma refa276_not4066 : ~ @Equation4066 Fin3 refa276_inst.
Proof. unfold Equation4066. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa276_inst, refa276_op in H. discriminate H. Qed.

Lemma refa276_not4067 : ~ @Equation4067 Fin3 refa276_inst.
Proof. unfold Equation4067. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa276_inst, refa276_op in H. discriminate H. Qed.

Lemma refa276_not4068 : ~ @Equation4068 Fin3 refa276_inst.
Proof. unfold Equation4068. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa276_inst, refa276_op in H. discriminate H. Qed.

Lemma refa276_not4071 : ~ @Equation4071 Fin3 refa276_inst.
Proof. unfold Equation4071. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa276_inst, refa276_op in H. discriminate H. Qed.

Lemma refa276_not4083 : ~ @Equation4083 Fin3 refa276_inst.
Proof. unfold Equation4083. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa276_inst, refa276_op in H. discriminate H. Qed.

Lemma refa276_not4084 : ~ @Equation4084 Fin3 refa276_inst.
Proof. unfold Equation4084. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa276_inst, refa276_op in H. discriminate H. Qed.

Lemma refa276_not4090 : ~ @Equation4090 Fin3 refa276_inst.
Proof. unfold Equation4090. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa276_inst, refa276_op in H. discriminate H. Qed.

Lemma refa276_not4091 : ~ @Equation4091 Fin3 refa276_inst.
Proof. unfold Equation4091. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa276_inst, refa276_op in H. discriminate H. Qed.

Lemma refa276_not4093 : ~ @Equation4093 Fin3 refa276_inst.
Proof. unfold Equation4093. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa276_inst, refa276_op in H. discriminate H. Qed.

Lemma refa276_not4270 : ~ @Equation4270 Fin3 refa276_inst.
Proof. unfold Equation4270. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa276_inst, refa276_op in H. discriminate H. Qed.

Lemma refa276_not4293 : ~ @Equation4293 Fin3 refa276_inst.
Proof. unfold Equation4293. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa276_inst, refa276_op in H. discriminate H. Qed.

Lemma refa276_not4314 : ~ @Equation4314 Fin3 refa276_inst.
Proof. unfold Equation4314. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa276_inst, refa276_op in H. discriminate H. Qed.

Lemma refa276_not4583 : ~ @Equation4583 Fin3 refa276_inst.
Proof. unfold Equation4583. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa276_inst, refa276_op in H. discriminate H. Qed.

Lemma refa276_not4591 : ~ @Equation4591 Fin3 refa276_inst.
Proof. unfold Equation4591. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa276_inst, refa276_op in H. discriminate H. Qed.

Lemma refa276_not4598 : ~ @Equation4598 Fin3 refa276_inst.
Proof. unfold Equation4598. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa276_inst, refa276_op in H. discriminate H. Qed.

Lemma refa276_not4606 : ~ @Equation4606 Fin3 refa276_inst.
Proof. unfold Equation4606. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa276_inst, refa276_op in H. discriminate H. Qed.

Lemma refa276_not4622 : ~ @Equation4622 Fin3 refa276_inst.
Proof. unfold Equation4622. intro H. specialize (H F3_0 F3_0 F3_1). unfold magma_op, refa276_inst, refa276_op in H. discriminate H. Qed.

Lemma refa276_not4636 : ~ @Equation4636 Fin3 refa276_inst.
Proof. unfold Equation4636. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa276_inst, refa276_op in H. discriminate H. Qed.

Lemma refa276_not4647 : ~ @Equation4647 Fin3 refa276_inst.
Proof. unfold Equation4647. intro H. specialize (H F3_0 F3_0 F3_1). unfold magma_op, refa276_inst, refa276_op in H. discriminate H. Qed.

(** ---- refa277 (Fin3) ---- *)

Definition refa277_op (x y : Fin3) : Fin3 :=
  match x, y with
  | F3_0, F3_0 => F3_0 | F3_0, F3_1 => F3_1 | F3_0, F3_2 => F3_2
  | F3_1, F3_0 => F3_1 | F3_1, F3_1 => F3_2 | F3_1, F3_2 => F3_0
  | F3_2, F3_0 => F3_2 | F3_2, F3_1 => F3_0 | F3_2, F3_2 => F3_1
  end.

#[local] Instance refa277_inst : Magma Fin3 := {| magma_op := refa277_op |}.

Lemma refa277_sat75 : @Equation75 Fin3 refa277_inst.
Proof. unfold Equation75, magma_op, refa277_inst, refa277_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa277_sat108 : @Equation108 Fin3 refa277_inst.
Proof. unfold Equation108, magma_op, refa277_inst, refa277_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa277_sat125 : @Equation125 Fin3 refa277_inst.
Proof. unfold Equation125, magma_op, refa277_inst, refa277_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa277_sat160 : @Equation160 Fin3 refa277_inst.
Proof. unfold Equation160, magma_op, refa277_inst, refa277_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa277_sat179 : @Equation179 Fin3 refa277_inst.
Proof. unfold Equation179, magma_op, refa277_inst, refa277_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa277_sat222 : @Equation222 Fin3 refa277_inst.
Proof. unfold Equation222, magma_op, refa277_inst, refa277_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa277_sat231 : @Equation231 Fin3 refa277_inst.
Proof. unfold Equation231, magma_op, refa277_inst, refa277_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa277_sat264 : @Equation264 Fin3 refa277_inst.
Proof. unfold Equation264, magma_op, refa277_inst, refa277_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa277_sat281 : @Equation281 Fin3 refa277_inst.
Proof. unfold Equation281, magma_op, refa277_inst, refa277_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa277_sat283 : @Equation283 Fin3 refa277_inst.
Proof. unfold Equation283, magma_op, refa277_inst, refa277_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa277_sat4364 : @Equation4364 Fin3 refa277_inst.
Proof. unfold Equation4364, magma_op, refa277_inst, refa277_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa277_sat4369 : @Equation4369 Fin3 refa277_inst.
Proof. unfold Equation4369, magma_op, refa277_inst, refa277_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa277_not65 : ~ @Equation65 Fin3 refa277_inst.
Proof. unfold Equation65. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa277_inst, refa277_op in H. discriminate H. Qed.

Lemma refa277_not105 : ~ @Equation105 Fin3 refa277_inst.
Proof. unfold Equation105. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa277_inst, refa277_op in H. discriminate H. Qed.

Lemma refa277_not107 : ~ @Equation107 Fin3 refa277_inst.
Proof. unfold Equation107. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa277_inst, refa277_op in H. discriminate H. Qed.

Lemma refa277_not159 : ~ @Equation159 Fin3 refa277_inst.
Proof. unfold Equation159. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa277_inst, refa277_op in H. discriminate H. Qed.

Lemma refa277_not167 : ~ @Equation167 Fin3 refa277_inst.
Proof. unfold Equation167. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa277_inst, refa277_op in H. discriminate H. Qed.

Lemma refa277_not211 : ~ @Equation211 Fin3 refa277_inst.
Proof. unfold Equation211. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa277_inst, refa277_op in H. discriminate H. Qed.

Lemma refa277_not221 : ~ @Equation221 Fin3 refa277_inst.
Proof. unfold Equation221. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa277_inst, refa277_op in H. discriminate H. Qed.

Lemma refa277_not261 : ~ @Equation261 Fin3 refa277_inst.
Proof. unfold Equation261. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa277_inst, refa277_op in H. discriminate H. Qed.

Lemma refa277_not411 : ~ @Equation411 Fin3 refa277_inst.
Proof. unfold Equation411. intro H. specialize (H F3_1). unfold magma_op, refa277_inst, refa277_op in H. discriminate H. Qed.

Lemma refa277_not614 : ~ @Equation614 Fin3 refa277_inst.
Proof. unfold Equation614. intro H. specialize (H F3_1). unfold magma_op, refa277_inst, refa277_op in H. discriminate H. Qed.

Lemma refa277_not817 : ~ @Equation817 Fin3 refa277_inst.
Proof. unfold Equation817. intro H. specialize (H F3_1). unfold magma_op, refa277_inst, refa277_op in H. discriminate H. Qed.

Lemma refa277_not1020 : ~ @Equation1020 Fin3 refa277_inst.
Proof. unfold Equation1020. intro H. specialize (H F3_1). unfold magma_op, refa277_inst, refa277_op in H. discriminate H. Qed.

Lemma refa277_not1223 : ~ @Equation1223 Fin3 refa277_inst.
Proof. unfold Equation1223. intro H. specialize (H F3_1). unfold magma_op, refa277_inst, refa277_op in H. discriminate H. Qed.

Lemma refa277_not1426 : ~ @Equation1426 Fin3 refa277_inst.
Proof. unfold Equation1426. intro H. specialize (H F3_1). unfold magma_op, refa277_inst, refa277_op in H. discriminate H. Qed.

Lemma refa277_not1629 : ~ @Equation1629 Fin3 refa277_inst.
Proof. unfold Equation1629. intro H. specialize (H F3_1). unfold magma_op, refa277_inst, refa277_op in H. discriminate H. Qed.

Lemma refa277_not1832 : ~ @Equation1832 Fin3 refa277_inst.
Proof. unfold Equation1832. intro H. specialize (H F3_1). unfold magma_op, refa277_inst, refa277_op in H. discriminate H. Qed.

Lemma refa277_not2035 : ~ @Equation2035 Fin3 refa277_inst.
Proof. unfold Equation2035. intro H. specialize (H F3_1). unfold magma_op, refa277_inst, refa277_op in H. discriminate H. Qed.

Lemma refa277_not2238 : ~ @Equation2238 Fin3 refa277_inst.
Proof. unfold Equation2238. intro H. specialize (H F3_1). unfold magma_op, refa277_inst, refa277_op in H. discriminate H. Qed.

Lemma refa277_not2441 : ~ @Equation2441 Fin3 refa277_inst.
Proof. unfold Equation2441. intro H. specialize (H F3_1). unfold magma_op, refa277_inst, refa277_op in H. discriminate H. Qed.

Lemma refa277_not2644 : ~ @Equation2644 Fin3 refa277_inst.
Proof. unfold Equation2644. intro H. specialize (H F3_1). unfold magma_op, refa277_inst, refa277_op in H. discriminate H. Qed.

Lemma refa277_not2847 : ~ @Equation2847 Fin3 refa277_inst.
Proof. unfold Equation2847. intro H. specialize (H F3_1). unfold magma_op, refa277_inst, refa277_op in H. discriminate H. Qed.

Lemma refa277_not3050 : ~ @Equation3050 Fin3 refa277_inst.
Proof. unfold Equation3050. intro H. specialize (H F3_1). unfold magma_op, refa277_inst, refa277_op in H. discriminate H. Qed.

Lemma refa277_not3253 : ~ @Equation3253 Fin3 refa277_inst.
Proof. unfold Equation3253. intro H. specialize (H F3_1). unfold magma_op, refa277_inst, refa277_op in H. discriminate H. Qed.

Lemma refa277_not3456 : ~ @Equation3456 Fin3 refa277_inst.
Proof. unfold Equation3456. intro H. specialize (H F3_1). unfold magma_op, refa277_inst, refa277_op in H. discriminate H. Qed.

Lemma refa277_not3659 : ~ @Equation3659 Fin3 refa277_inst.
Proof. unfold Equation3659. intro H. specialize (H F3_1). unfold magma_op, refa277_inst, refa277_op in H. discriminate H. Qed.

Lemma refa277_not3862 : ~ @Equation3862 Fin3 refa277_inst.
Proof. unfold Equation3862. intro H. specialize (H F3_1). unfold magma_op, refa277_inst, refa277_op in H. discriminate H. Qed.

Lemma refa277_not4065 : ~ @Equation4065 Fin3 refa277_inst.
Proof. unfold Equation4065. intro H. specialize (H F3_1). unfold magma_op, refa277_inst, refa277_op in H. discriminate H. Qed.

Lemma refa277_not4268 : ~ @Equation4268 Fin3 refa277_inst.
Proof. unfold Equation4268. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa277_inst, refa277_op in H. discriminate H. Qed.

Lemma refa277_not4269 : ~ @Equation4269 Fin3 refa277_inst.
Proof. unfold Equation4269. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa277_inst, refa277_op in H. discriminate H. Qed.

Lemma refa277_not4270 : ~ @Equation4270 Fin3 refa277_inst.
Proof. unfold Equation4270. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa277_inst, refa277_op in H. discriminate H. Qed.

Lemma refa277_not4272 : ~ @Equation4272 Fin3 refa277_inst.
Proof. unfold Equation4272. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa277_inst, refa277_op in H. discriminate H. Qed.

Lemma refa277_not4273 : ~ @Equation4273 Fin3 refa277_inst.
Proof. unfold Equation4273. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa277_inst, refa277_op in H. discriminate H. Qed.

Lemma refa277_not4275 : ~ @Equation4275 Fin3 refa277_inst.
Proof. unfold Equation4275. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa277_inst, refa277_op in H. discriminate H. Qed.

Lemma refa277_not4284 : ~ @Equation4284 Fin3 refa277_inst.
Proof. unfold Equation4284. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa277_inst, refa277_op in H. discriminate H. Qed.

Lemma refa277_not4291 : ~ @Equation4291 Fin3 refa277_inst.
Proof. unfold Equation4291. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa277_inst, refa277_op in H. discriminate H. Qed.

Lemma refa277_not4293 : ~ @Equation4293 Fin3 refa277_inst.
Proof. unfold Equation4293. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa277_inst, refa277_op in H. discriminate H. Qed.

Lemma refa277_not4314 : ~ @Equation4314 Fin3 refa277_inst.
Proof. unfold Equation4314. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa277_inst, refa277_op in H. discriminate H. Qed.

Lemma refa277_not4321 : ~ @Equation4321 Fin3 refa277_inst.
Proof. unfold Equation4321. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa277_inst, refa277_op in H. discriminate H. Qed.

Lemma refa277_not4343 : ~ @Equation4343 Fin3 refa277_inst.
Proof. unfold Equation4343. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa277_inst, refa277_op in H. discriminate H. Qed.

Lemma refa277_not4399 : ~ @Equation4399 Fin3 refa277_inst.
Proof. unfold Equation4399. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa277_inst, refa277_op in H. discriminate H. Qed.

Lemma refa277_not4406 : ~ @Equation4406 Fin3 refa277_inst.
Proof. unfold Equation4406. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa277_inst, refa277_op in H. discriminate H. Qed.

Lemma refa277_not4408 : ~ @Equation4408 Fin3 refa277_inst.
Proof. unfold Equation4408. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa277_inst, refa277_op in H. discriminate H. Qed.

Lemma refa277_not4436 : ~ @Equation4436 Fin3 refa277_inst.
Proof. unfold Equation4436. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa277_inst, refa277_op in H. discriminate H. Qed.

Lemma refa277_not4443 : ~ @Equation4443 Fin3 refa277_inst.
Proof. unfold Equation4443. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa277_inst, refa277_op in H. discriminate H. Qed.

Lemma refa277_not4445 : ~ @Equation4445 Fin3 refa277_inst.
Proof. unfold Equation4445. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa277_inst, refa277_op in H. discriminate H. Qed.

Lemma refa277_not4470 : ~ @Equation4470 Fin3 refa277_inst.
Proof. unfold Equation4470. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa277_inst, refa277_op in H. discriminate H. Qed.

Lemma refa277_not4472 : ~ @Equation4472 Fin3 refa277_inst.
Proof. unfold Equation4472. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa277_inst, refa277_op in H. discriminate H. Qed.

Lemma refa277_not4479 : ~ @Equation4479 Fin3 refa277_inst.
Proof. unfold Equation4479. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa277_inst, refa277_op in H. discriminate H. Qed.

Lemma refa277_not4583 : ~ @Equation4583 Fin3 refa277_inst.
Proof. unfold Equation4583. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa277_inst, refa277_op in H. discriminate H. Qed.

Lemma refa277_not4584 : ~ @Equation4584 Fin3 refa277_inst.
Proof. unfold Equation4584. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa277_inst, refa277_op in H. discriminate H. Qed.

Lemma refa277_not4585 : ~ @Equation4585 Fin3 refa277_inst.
Proof. unfold Equation4585. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa277_inst, refa277_op in H. discriminate H. Qed.

Lemma refa277_not4587 : ~ @Equation4587 Fin3 refa277_inst.
Proof. unfold Equation4587. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa277_inst, refa277_op in H. discriminate H. Qed.

Lemma refa277_not4588 : ~ @Equation4588 Fin3 refa277_inst.
Proof. unfold Equation4588. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa277_inst, refa277_op in H. discriminate H. Qed.

Lemma refa277_not4590 : ~ @Equation4590 Fin3 refa277_inst.
Proof. unfold Equation4590. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa277_inst, refa277_op in H. discriminate H. Qed.

Lemma refa277_not4599 : ~ @Equation4599 Fin3 refa277_inst.
Proof. unfold Equation4599. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa277_inst, refa277_op in H. discriminate H. Qed.

Lemma refa277_not4606 : ~ @Equation4606 Fin3 refa277_inst.
Proof. unfold Equation4606. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa277_inst, refa277_op in H. discriminate H. Qed.

Lemma refa277_not4608 : ~ @Equation4608 Fin3 refa277_inst.
Proof. unfold Equation4608. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa277_inst, refa277_op in H. discriminate H. Qed.

Lemma refa277_not4629 : ~ @Equation4629 Fin3 refa277_inst.
Proof. unfold Equation4629. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa277_inst, refa277_op in H. discriminate H. Qed.

Lemma refa277_not4636 : ~ @Equation4636 Fin3 refa277_inst.
Proof. unfold Equation4636. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa277_inst, refa277_op in H. discriminate H. Qed.

Lemma refa277_not4658 : ~ @Equation4658 Fin3 refa277_inst.
Proof. unfold Equation4658. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa277_inst, refa277_op in H. discriminate H. Qed.

(** ---- refa278 (Fin3) ---- *)

Definition refa278_op (x y : Fin3) : Fin3 :=
  match x, y with
  | F3_0, F3_0 => F3_0 | F3_0, F3_1 => F3_1 | F3_0, F3_2 => F3_2
  | F3_1, F3_0 => F3_1 | F3_1, F3_1 => F3_0 | F3_1, F3_2 => F3_2
  | F3_2, F3_0 => F3_1 | F3_2, F3_1 => F3_0 | F3_2, F3_2 => F3_2
  end.

#[local] Instance refa278_inst : Magma Fin3 := {| magma_op := refa278_op |}.

Lemma refa278_sat1488 : @Equation1488 Fin3 refa278_inst.
Proof. unfold Equation1488, magma_op, refa278_inst, refa278_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa278_sat2706 : @Equation2706 Fin3 refa278_inst.
Proof. unfold Equation2706, magma_op, refa278_inst, refa278_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa278_sat3388 : @Equation3388 Fin3 refa278_inst.
Proof. unfold Equation3388, magma_op, refa278_inst, refa278_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa278_not622 : ~ @Equation622 Fin3 refa278_inst.
Proof. unfold Equation622. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa278_inst, refa278_op in H. discriminate H. Qed.

Lemma refa278_not632 : ~ @Equation632 Fin3 refa278_inst.
Proof. unfold Equation632. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa278_inst, refa278_op in H. discriminate H. Qed.

Lemma refa278_not669 : ~ @Equation669 Fin3 refa278_inst.
Proof. unfold Equation669. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa278_inst, refa278_op in H. discriminate H. Qed.

Lemma refa278_not716 : ~ @Equation716 Fin3 refa278_inst.
Proof. unfold Equation716. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa278_inst, refa278_op in H. discriminate H. Qed.

Lemma refa278_not1451 : ~ @Equation1451 Fin3 refa278_inst.
Proof. unfold Equation1451. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa278_inst, refa278_op in H. discriminate H. Qed.

Lemma refa278_not1515 : ~ @Equation1515 Fin3 refa278_inst.
Proof. unfold Equation1515. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa278_inst, refa278_op in H. discriminate H. Qed.

Lemma refa278_not2733 : ~ @Equation2733 Fin3 refa278_inst.
Proof. unfold Equation2733. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa278_inst, refa278_op in H. discriminate H. Qed.

Lemma refa278_not3139 : ~ @Equation3139 Fin3 refa278_inst.
Proof. unfold Equation3139. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa278_inst, refa278_op in H. discriminate H. Qed.

Lemma refa278_not3509 : ~ @Equation3509 Fin3 refa278_inst.
Proof. unfold Equation3509. intro H. specialize (H F3_2 F3_0). unfold magma_op, refa278_inst, refa278_op in H. discriminate H. Qed.

Lemma refa278_not4590 : ~ @Equation4590 Fin3 refa278_inst.
Proof. unfold Equation4590. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa278_inst, refa278_op in H. discriminate H. Qed.

Lemma refa278_not4635 : ~ @Equation4635 Fin3 refa278_inst.
Proof. unfold Equation4635. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa278_inst, refa278_op in H. discriminate H. Qed.
