(** * All4x4 counterexamples — batch 16
    Auto-generated from Lean4 All4x4 files. *)

From Stdlib Require Import Utf8.

From ETP Require Import Magma.
From ETP Require Import FinMagma.
From ETP.Equations Require Import All.

Open Scope magma_scope.

(** ---- refa775 (Fin5) ---- *)

Definition refa775_op (x y : Fin5) : Fin5 :=
  match x, y with
  | F5_0, F5_0 => F5_0 | F5_0, F5_1 => F5_2 | F5_0, F5_2 => F5_0 | F5_0, F5_3 => F5_4 | F5_0, F5_4 => F5_0
  | F5_1, F5_0 => F5_3 | F5_1, F5_1 => F5_3 | F5_1, F5_2 => F5_3 | F5_1, F5_3 => F5_3 | F5_1, F5_4 => F5_3
  | F5_2, F5_0 => F5_2 | F5_2, F5_1 => F5_4 | F5_2, F5_2 => F5_2 | F5_2, F5_3 => F5_0 | F5_2, F5_4 => F5_2
  | F5_3, F5_0 => F5_1 | F5_3, F5_1 => F5_1 | F5_3, F5_2 => F5_1 | F5_3, F5_3 => F5_1 | F5_3, F5_4 => F5_1
  | F5_4, F5_0 => F5_4 | F5_4, F5_1 => F5_0 | F5_4, F5_2 => F5_4 | F5_4, F5_3 => F5_2 | F5_4, F5_4 => F5_4
  end.

#[local] Instance refa775_inst : Magma Fin5 := {| magma_op := refa775_op |}.

Lemma refa775_sat3059 : @Equation3059 Fin5 refa775_inst.
Proof. unfold Equation3059, magma_op, refa775_inst, refa775_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa775_sat3069 : @Equation3069 Fin5 refa775_inst.
Proof. unfold Equation3069, magma_op, refa775_inst, refa775_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa775_sat3076 : @Equation3076 Fin5 refa775_inst.
Proof. unfold Equation3076, magma_op, refa775_inst, refa775_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa775_not3066 : ~ @Equation3066 Fin5 refa775_inst.
Proof. unfold Equation3066. intro H. specialize (H F5_0 F5_1). unfold magma_op, refa775_inst, refa775_op in H. discriminate H. Qed.

Lemma refa775_not3259 : ~ @Equation3259 Fin5 refa775_inst.
Proof. unfold Equation3259. intro H. specialize (H F5_0 F5_1). unfold magma_op, refa775_inst, refa775_op in H. discriminate H. Qed.

Lemma refa775_not3308 : ~ @Equation3308 Fin5 refa775_inst.
Proof. unfold Equation3308. intro H. specialize (H F5_0 F5_1). unfold magma_op, refa775_inst, refa775_op in H. discriminate H. Qed.

Lemma refa775_not3319 : ~ @Equation3319 Fin5 refa775_inst.
Proof. unfold Equation3319. intro H. specialize (H F5_0 F5_1). unfold magma_op, refa775_inst, refa775_op in H. discriminate H. Qed.

Lemma refa775_not3462 : ~ @Equation3462 Fin5 refa775_inst.
Proof. unfold Equation3462. intro H. specialize (H F5_0 F5_1). unfold magma_op, refa775_inst, refa775_op in H. discriminate H. Qed.

Lemma refa775_not3511 : ~ @Equation3511 Fin5 refa775_inst.
Proof. unfold Equation3511. intro H. specialize (H F5_0 F5_1). unfold magma_op, refa775_inst, refa775_op in H. discriminate H. Qed.

(** ---- refa776 (Fin5) ---- *)

Definition refa776_op (x y : Fin5) : Fin5 :=
  match x, y with
  | F5_0, F5_0 => F5_1 | F5_0, F5_1 => F5_1 | F5_0, F5_2 => F5_3 | F5_0, F5_3 => F5_3 | F5_0, F5_4 => F5_3
  | F5_1, F5_0 => F5_2 | F5_1, F5_1 => F5_2 | F5_1, F5_2 => F5_2 | F5_1, F5_3 => F5_2 | F5_1, F5_4 => F5_2
  | F5_2, F5_0 => F5_4 | F5_2, F5_1 => F5_4 | F5_2, F5_2 => F5_4 | F5_2, F5_3 => F5_4 | F5_2, F5_4 => F5_4
  | F5_3, F5_0 => F5_2 | F5_3, F5_1 => F5_2 | F5_3, F5_2 => F5_2 | F5_3, F5_3 => F5_2 | F5_3, F5_4 => F5_2
  | F5_4, F5_0 => F5_0 | F5_4, F5_1 => F5_0 | F5_4, F5_2 => F5_0 | F5_4, F5_3 => F5_0 | F5_4, F5_4 => F5_0
  end.

#[local] Instance refa776_inst : Magma Fin5 := {| magma_op := refa776_op |}.

Lemma refa776_sat3081 : @Equation3081 Fin5 refa776_inst.
Proof. unfold Equation3081, magma_op, refa776_inst, refa776_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa776_not3456 : ~ @Equation3456 Fin5 refa776_inst.
Proof. unfold Equation3456. intro H. specialize (H F5_0). unfold magma_op, refa776_inst, refa776_op in H. discriminate H. Qed.

(** ---- refa777 (Fin6) ---- *)

Definition refa777_op (x y : Fin6) : Fin6 :=
  match x, y with
  | F6_0, F6_0 => F6_3 | F6_0, F6_1 => F6_3 | F6_0, F6_2 => F6_4 | F6_0, F6_3 => F6_3 | F6_0, F6_4 => F6_4 | F6_0, F6_5 => F6_4
  | F6_1, F6_0 => F6_0 | F6_1, F6_1 => F6_0 | F6_1, F6_2 => F6_0 | F6_1, F6_3 => F6_0 | F6_1, F6_4 => F6_0 | F6_1, F6_5 => F6_0
  | F6_2, F6_0 => F6_1 | F6_2, F6_1 => F6_1 | F6_2, F6_2 => F6_1 | F6_2, F6_3 => F6_1 | F6_2, F6_4 => F6_1 | F6_2, F6_5 => F6_1
  | F6_3, F6_0 => F6_2 | F6_3, F6_1 => F6_5 | F6_3, F6_2 => F6_2 | F6_3, F6_3 => F6_5 | F6_3, F6_4 => F6_5 | F6_3, F6_5 => F6_5
  | F6_4, F6_0 => F6_5 | F6_4, F6_1 => F6_5 | F6_4, F6_2 => F6_2 | F6_4, F6_3 => F6_5 | F6_4, F6_4 => F6_5 | F6_4, F6_5 => F6_5
  | F6_5, F6_0 => F6_1 | F6_5, F6_1 => F6_1 | F6_5, F6_2 => F6_1 | F6_5, F6_3 => F6_1 | F6_5, F6_4 => F6_1 | F6_5, F6_5 => F6_1
  end.

#[local] Instance refa777_inst : Magma Fin6 := {| magma_op := refa777_op |}.

Lemma refa777_sat3081 : @Equation3081 Fin6 refa777_inst.
Proof. unfold Equation3081, magma_op, refa777_inst, refa777_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa777_not4584 : ~ @Equation4584 Fin6 refa777_inst.
Proof. unfold Equation4584. intro H. specialize (H F6_0 F6_2). unfold magma_op, refa777_inst, refa777_op in H. discriminate H. Qed.

(** ---- refa778 (Fin5) ---- *)

Definition refa778_op (x y : Fin5) : Fin5 :=
  match x, y with
  | F5_0, F5_0 => F5_0 | F5_0, F5_1 => F5_2 | F5_0, F5_2 => F5_1 | F5_0, F5_3 => F5_4 | F5_0, F5_4 => F5_1
  | F5_1, F5_0 => F5_2 | F5_1, F5_1 => F5_1 | F5_1, F5_2 => F5_2 | F5_1, F5_3 => F5_4 | F5_1, F5_4 => F5_4
  | F5_2, F5_0 => F5_3 | F5_2, F5_1 => F5_1 | F5_2, F5_2 => F5_2 | F5_2, F5_3 => F5_4 | F5_2, F5_4 => F5_1
  | F5_3, F5_0 => F5_4 | F5_3, F5_1 => F5_2 | F5_3, F5_2 => F5_0 | F5_3, F5_3 => F5_3 | F5_3, F5_4 => F5_4
  | F5_4, F5_0 => F5_0 | F5_4, F5_1 => F5_2 | F5_4, F5_2 => F5_1 | F5_4, F5_3 => F5_3 | F5_4, F5_4 => F5_4
  end.

#[local] Instance refa778_inst : Magma Fin5 := {| magma_op := refa778_op |}.

Lemma refa778_sat3102 : @Equation3102 Fin5 refa778_inst.
Proof. unfold Equation3102, magma_op, refa778_inst, refa778_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa778_not1238 : ~ @Equation1238 Fin5 refa778_inst.
Proof. unfold Equation1238. intro H. specialize (H F5_0 F5_1). unfold magma_op, refa778_inst, refa778_op in H. discriminate H. Qed.

Lemma refa778_not2087 : ~ @Equation2087 Fin5 refa778_inst.
Proof. unfold Equation2087. intro H. specialize (H F5_0 F5_1). unfold magma_op, refa778_inst, refa778_op in H. discriminate H. Qed.

Lemma refa778_not2456 : ~ @Equation2456 Fin5 refa778_inst.
Proof. unfold Equation2456. intro H. specialize (H F5_0 F5_2). unfold magma_op, refa778_inst, refa778_op in H. discriminate H. Qed.

Lemma refa778_not2530 : ~ @Equation2530 Fin5 refa778_inst.
Proof. unfold Equation2530. intro H. specialize (H F5_0 F5_2). unfold magma_op, refa778_inst, refa778_op in H. discriminate H. Qed.

Lemma refa778_not2669 : ~ @Equation2669 Fin5 refa778_inst.
Proof. unfold Equation2669. intro H. specialize (H F5_0 F5_1). unfold magma_op, refa778_inst, refa778_op in H. discriminate H. Qed.

Lemma refa778_not2696 : ~ @Equation2696 Fin5 refa778_inst.
Proof. unfold Equation2696. intro H. specialize (H F5_0 F5_1). unfold magma_op, refa778_inst, refa778_op in H. discriminate H. Qed.

Lemma refa778_not2862 : ~ @Equation2862 Fin5 refa778_inst.
Proof. unfold Equation2862. intro H. specialize (H F5_0 F5_1). unfold magma_op, refa778_inst, refa778_op in H. discriminate H. Qed.

Lemma refa778_not2899 : ~ @Equation2899 Fin5 refa778_inst.
Proof. unfold Equation2899. intro H. specialize (H F5_0 F5_1). unfold magma_op, refa778_inst, refa778_op in H. discriminate H. Qed.

Lemma refa778_not2936 : ~ @Equation2936 Fin5 refa778_inst.
Proof. unfold Equation2936. intro H. specialize (H F5_0 F5_1). unfold magma_op, refa778_inst, refa778_op in H. discriminate H. Qed.

Lemma refa778_not3065 : ~ @Equation3065 Fin5 refa778_inst.
Proof. unfold Equation3065. intro H. specialize (H F5_0 F5_2). unfold magma_op, refa778_inst, refa778_op in H. discriminate H. Qed.

Lemma refa778_not3139 : ~ @Equation3139 Fin5 refa778_inst.
Proof. unfold Equation3139. intro H. specialize (H F5_0 F5_1). unfold magma_op, refa778_inst, refa778_op in H. discriminate H. Qed.

Lemma refa778_not4080 : ~ @Equation4080 Fin5 refa778_inst.
Proof. unfold Equation4080. intro H. specialize (H F5_0 F5_1). unfold magma_op, refa778_inst, refa778_op in H. discriminate H. Qed.

(** ---- refa779 (Fin5) ---- *)

Definition refa779_op (x y : Fin5) : Fin5 :=
  match x, y with
  | F5_0, F5_0 => F5_0 | F5_0, F5_1 => F5_3 | F5_0, F5_2 => F5_4 | F5_0, F5_3 => F5_3 | F5_0, F5_4 => F5_4
  | F5_1, F5_0 => F5_3 | F5_1, F5_1 => F5_1 | F5_1, F5_2 => F5_2 | F5_1, F5_3 => F5_3 | F5_1, F5_4 => F5_4
  | F5_2, F5_0 => F5_4 | F5_2, F5_1 => F5_1 | F5_2, F5_2 => F5_2 | F5_2, F5_3 => F5_1 | F5_2, F5_4 => F5_4
  | F5_3, F5_0 => F5_0 | F5_3, F5_1 => F5_1 | F5_3, F5_2 => F5_1 | F5_3, F5_3 => F5_3 | F5_3, F5_4 => F5_1
  | F5_4, F5_0 => F5_0 | F5_4, F5_1 => F5_1 | F5_4, F5_2 => F5_2 | F5_4, F5_3 => F5_1 | F5_4, F5_4 => F5_4
  end.

#[local] Instance refa779_inst : Magma Fin5 := {| magma_op := refa779_op |}.

Lemma refa779_sat3108 : @Equation3108 Fin5 refa779_inst.
Proof. unfold Equation3108, magma_op, refa779_inst, refa779_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa779_not2716 : ~ @Equation2716 Fin5 refa779_inst.
Proof. unfold Equation2716. intro H. specialize (H F5_0 F5_1 F5_2). unfold magma_op, refa779_inst, refa779_op in H. discriminate H. Qed.

Lemma refa779_not3803 : ~ @Equation3803 Fin5 refa779_inst.
Proof. unfold Equation3803. intro H. specialize (H F5_1 F5_0 F5_2). unfold magma_op, refa779_inst, refa779_op in H. discriminate H. Qed.

(** ---- refa78 (Fin3) ---- *)

Definition refa78_op (x y : Fin3) : Fin3 :=
  match x, y with
  | F3_0, F3_0 => F3_1 | F3_0, F3_1 => F3_0 | F3_0, F3_2 => F3_0
  | F3_1, F3_0 => F3_1 | F3_1, F3_1 => F3_0 | F3_1, F3_2 => F3_0
  | F3_2, F3_0 => F3_1 | F3_2, F3_1 => F3_1 | F3_2, F3_2 => F3_0
  end.

#[local] Instance refa78_inst : Magma Fin3 := {| magma_op := refa78_op |}.

Lemma refa78_sat370 : @Equation370 Fin3 refa78_inst.
Proof. unfold Equation370, magma_op, refa78_inst, refa78_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa78_not4269 : ~ @Equation4269 Fin3 refa78_inst.
Proof. unfold Equation4269. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa78_inst, refa78_op in H. discriminate H. Qed.

Lemma refa78_not4272 : ~ @Equation4272 Fin3 refa78_inst.
Proof. unfold Equation4272. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa78_inst, refa78_op in H. discriminate H. Qed.

Lemma refa78_not4275 : ~ @Equation4275 Fin3 refa78_inst.
Proof. unfold Equation4275. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa78_inst, refa78_op in H. discriminate H. Qed.

Lemma refa78_not4320 : ~ @Equation4320 Fin3 refa78_inst.
Proof. unfold Equation4320. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa78_inst, refa78_op in H. discriminate H. Qed.

(** ---- refa780 (Fin5) ---- *)

Definition refa780_op (x y : Fin5) : Fin5 :=
  match x, y with
  | F5_0, F5_0 => F5_0 | F5_0, F5_1 => F5_1 | F5_0, F5_2 => F5_4 | F5_0, F5_3 => F5_3 | F5_0, F5_4 => F5_4
  | F5_1, F5_0 => F5_0 | F5_1, F5_1 => F5_1 | F5_1, F5_2 => F5_3 | F5_1, F5_3 => F5_3 | F5_1, F5_4 => F5_4
  | F5_2, F5_0 => F5_3 | F5_2, F5_1 => F5_4 | F5_2, F5_2 => F5_2 | F5_2, F5_3 => F5_3 | F5_2, F5_4 => F5_4
  | F5_3, F5_0 => F5_0 | F5_3, F5_1 => F5_1 | F5_3, F5_2 => F5_2 | F5_3, F5_3 => F5_3 | F5_3, F5_4 => F5_2
  | F5_4, F5_0 => F5_0 | F5_4, F5_1 => F5_1 | F5_4, F5_2 => F5_2 | F5_4, F5_3 => F5_2 | F5_4, F5_4 => F5_4
  end.

#[local] Instance refa780_inst : Magma Fin5 := {| magma_op := refa780_op |}.

Lemma refa780_sat3108 : @Equation3108 Fin5 refa780_inst.
Proof. unfold Equation3108, magma_op, refa780_inst, refa780_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa780_not2778 : ~ @Equation2778 Fin5 refa780_inst.
Proof. unfold Equation2778. intro H. specialize (H F5_0 F5_1 F5_2). unfold magma_op, refa780_inst, refa780_op in H. discriminate H. Qed.

(** ---- refa781 (Fin5) ---- *)

Definition refa781_op (x y : Fin5) : Fin5 :=
  match x, y with
  | F5_0, F5_0 => F5_0 | F5_0, F5_1 => F5_4 | F5_0, F5_2 => F5_2 | F5_0, F5_3 => F5_3 | F5_0, F5_4 => F5_4
  | F5_1, F5_0 => F5_2 | F5_1, F5_1 => F5_1 | F5_1, F5_2 => F5_2 | F5_1, F5_3 => F5_2 | F5_1, F5_4 => F5_3
  | F5_2, F5_0 => F5_3 | F5_2, F5_1 => F5_4 | F5_2, F5_2 => F5_2 | F5_2, F5_3 => F5_0 | F5_2, F5_4 => F5_0
  | F5_3, F5_0 => F5_0 | F5_3, F5_1 => F5_4 | F5_3, F5_2 => F5_0 | F5_3, F5_3 => F5_3 | F5_3, F5_4 => F5_4
  | F5_4, F5_0 => F5_3 | F5_4, F5_1 => F5_1 | F5_4, F5_2 => F5_1 | F5_4, F5_3 => F5_3 | F5_4, F5_4 => F5_4
  end.

#[local] Instance refa781_inst : Magma Fin5 := {| magma_op := refa781_op |}.

Lemma refa781_sat3122 : @Equation3122 Fin5 refa781_inst.
Proof. unfold Equation3122, magma_op, refa781_inst, refa781_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa781_not280 : ~ @Equation280 Fin5 refa781_inst.
Proof. unfold Equation280. intro H. specialize (H F5_0 F5_1). unfold magma_op, refa781_inst, refa781_op in H. discriminate H. Qed.

Lemma refa781_not619 : ~ @Equation619 Fin5 refa781_inst.
Proof. unfold Equation619. intro H. specialize (H F5_0 F5_1). unfold magma_op, refa781_inst, refa781_op in H. discriminate H. Qed.

Lemma refa781_not832 : ~ @Equation832 Fin5 refa781_inst.
Proof. unfold Equation832. intro H. specialize (H F5_0 F5_1). unfold magma_op, refa781_inst, refa781_op in H. discriminate H. Qed.

Lemma refa781_not1025 : ~ @Equation1025 Fin5 refa781_inst.
Proof. unfold Equation1025. intro H. specialize (H F5_0 F5_1). unfold magma_op, refa781_inst, refa781_op in H. discriminate H. Qed.

Lemma refa781_not1035 : ~ @Equation1035 Fin5 refa781_inst.
Proof. unfold Equation1035. intro H. specialize (H F5_0 F5_1). unfold magma_op, refa781_inst, refa781_op in H. discriminate H. Qed.

Lemma refa781_not1045 : ~ @Equation1045 Fin5 refa781_inst.
Proof. unfold Equation1045. intro H. specialize (H F5_0 F5_1). unfold magma_op, refa781_inst, refa781_op in H. discriminate H. Qed.

Lemma refa781_not1248 : ~ @Equation1248 Fin5 refa781_inst.
Proof. unfold Equation1248. intro H. specialize (H F5_0 F5_1). unfold magma_op, refa781_inst, refa781_op in H. discriminate H. Qed.

Lemma refa781_not1478 : ~ @Equation1478 Fin5 refa781_inst.
Proof. unfold Equation1478. intro H. specialize (H F5_0 F5_1). unfold magma_op, refa781_inst, refa781_op in H. discriminate H. Qed.

Lemma refa781_not1634 : ~ @Equation1634 Fin5 refa781_inst.
Proof. unfold Equation1634. intro H. specialize (H F5_0 F5_1). unfold magma_op, refa781_inst, refa781_op in H. discriminate H. Qed.

Lemma refa781_not1681 : ~ @Equation1681 Fin5 refa781_inst.
Proof. unfold Equation1681. intro H. specialize (H F5_0 F5_1). unfold magma_op, refa781_inst, refa781_op in H. discriminate H. Qed.

Lemma refa781_not1847 : ~ @Equation1847 Fin5 refa781_inst.
Proof. unfold Equation1847. intro H. specialize (H F5_0 F5_1). unfold magma_op, refa781_inst, refa781_op in H. discriminate H. Qed.

Lemma refa781_not1884 : ~ @Equation1884 Fin5 refa781_inst.
Proof. unfold Equation1884. intro H. specialize (H F5_0 F5_1). unfold magma_op, refa781_inst, refa781_op in H. discriminate H. Qed.

Lemma refa781_not1921 : ~ @Equation1921 Fin5 refa781_inst.
Proof. unfold Equation1921. intro H. specialize (H F5_0 F5_1). unfold magma_op, refa781_inst, refa781_op in H. discriminate H. Qed.

Lemma refa781_not2124 : ~ @Equation2124 Fin5 refa781_inst.
Proof. unfold Equation2124. intro H. specialize (H F5_0 F5_1). unfold magma_op, refa781_inst, refa781_op in H. discriminate H. Qed.

Lemma refa781_not2243 : ~ @Equation2243 Fin5 refa781_inst.
Proof. unfold Equation2243. intro H. specialize (H F5_0 F5_1). unfold magma_op, refa781_inst, refa781_op in H. discriminate H. Qed.

Lemma refa781_not2253 : ~ @Equation2253 Fin5 refa781_inst.
Proof. unfold Equation2253. intro H. specialize (H F5_0 F5_1). unfold magma_op, refa781_inst, refa781_op in H. discriminate H. Qed.

Lemma refa781_not2263 : ~ @Equation2263 Fin5 refa781_inst.
Proof. unfold Equation2263. intro H. specialize (H F5_0 F5_1). unfold magma_op, refa781_inst, refa781_op in H. discriminate H. Qed.

Lemma refa781_not2290 : ~ @Equation2290 Fin5 refa781_inst.
Proof. unfold Equation2290. intro H. specialize (H F5_0 F5_1). unfold magma_op, refa781_inst, refa781_op in H. discriminate H. Qed.

Lemma refa781_not2300 : ~ @Equation2300 Fin5 refa781_inst.
Proof. unfold Equation2300. intro H. specialize (H F5_0 F5_1). unfold magma_op, refa781_inst, refa781_op in H. discriminate H. Qed.

Lemma refa781_not2327 : ~ @Equation2327 Fin5 refa781_inst.
Proof. unfold Equation2327. intro H. specialize (H F5_0 F5_1). unfold magma_op, refa781_inst, refa781_op in H. discriminate H. Qed.

Lemma refa781_not2337 : ~ @Equation2337 Fin5 refa781_inst.
Proof. unfold Equation2337. intro H. specialize (H F5_0 F5_1). unfold magma_op, refa781_inst, refa781_op in H. discriminate H. Qed.

Lemma refa781_not2446 : ~ @Equation2446 Fin5 refa781_inst.
Proof. unfold Equation2446. intro H. specialize (H F5_1 F5_0). unfold magma_op, refa781_inst, refa781_op in H. discriminate H. Qed.

Lemma refa781_not2466 : ~ @Equation2466 Fin5 refa781_inst.
Proof. unfold Equation2466. intro H. specialize (H F5_0 F5_1). unfold magma_op, refa781_inst, refa781_op in H. discriminate H. Qed.

Lemma refa781_not2493 : ~ @Equation2493 Fin5 refa781_inst.
Proof. unfold Equation2493. intro H. specialize (H F5_0 F5_1). unfold magma_op, refa781_inst, refa781_op in H. discriminate H. Qed.

Lemma refa781_not2503 : ~ @Equation2503 Fin5 refa781_inst.
Proof. unfold Equation2503. intro H. specialize (H F5_0 F5_1). unfold magma_op, refa781_inst, refa781_op in H. discriminate H. Qed.

Lemma refa781_not2530 : ~ @Equation2530 Fin5 refa781_inst.
Proof. unfold Equation2530. intro H. specialize (H F5_0 F5_1). unfold magma_op, refa781_inst, refa781_op in H. discriminate H. Qed.

Lemma refa781_not2540 : ~ @Equation2540 Fin5 refa781_inst.
Proof. unfold Equation2540. intro H. specialize (H F5_0 F5_1). unfold magma_op, refa781_inst, refa781_op in H. discriminate H. Qed.

Lemma refa781_not2649 : ~ @Equation2649 Fin5 refa781_inst.
Proof. unfold Equation2649. intro H. specialize (H F5_0 F5_1). unfold magma_op, refa781_inst, refa781_op in H. discriminate H. Qed.

Lemma refa781_not2669 : ~ @Equation2669 Fin5 refa781_inst.
Proof. unfold Equation2669. intro H. specialize (H F5_0 F5_1). unfold magma_op, refa781_inst, refa781_op in H. discriminate H. Qed.

Lemma refa781_not2706 : ~ @Equation2706 Fin5 refa781_inst.
Proof. unfold Equation2706. intro H. specialize (H F5_0 F5_1). unfold magma_op, refa781_inst, refa781_op in H. discriminate H. Qed.

Lemma refa781_not2733 : ~ @Equation2733 Fin5 refa781_inst.
Proof. unfold Equation2733. intro H. specialize (H F5_0 F5_1). unfold magma_op, refa781_inst, refa781_op in H. discriminate H. Qed.

Lemma refa781_not2743 : ~ @Equation2743 Fin5 refa781_inst.
Proof. unfold Equation2743. intro H. specialize (H F5_0 F5_1). unfold magma_op, refa781_inst, refa781_op in H. discriminate H. Qed.

Lemma refa781_not2919 : ~ @Equation2919 Fin5 refa781_inst.
Proof. unfold Equation2919. intro H. specialize (H F5_0 F5_4 F5_2). unfold magma_op, refa781_inst, refa781_op in H. discriminate H. Qed.

Lemma refa781_not2946 : ~ @Equation2946 Fin5 refa781_inst.
Proof. unfold Equation2946. intro H. specialize (H F5_0 F5_1). unfold magma_op, refa781_inst, refa781_op in H. discriminate H. Qed.

Lemma refa781_not2973 : ~ @Equation2973 Fin5 refa781_inst.
Proof. unfold Equation2973. intro H. specialize (H F5_0 F5_4 F5_1). unfold magma_op, refa781_inst, refa781_op in H. discriminate H. Qed.

Lemma refa781_not3075 : ~ @Equation3075 Fin5 refa781_inst.
Proof. unfold Equation3075. intro H. specialize (H F5_0 F5_1). unfold magma_op, refa781_inst, refa781_op in H. discriminate H. Qed.

Lemma refa781_not3149 : ~ @Equation3149 Fin5 refa781_inst.
Proof. unfold Equation3149. intro H. specialize (H F5_0 F5_1). unfold magma_op, refa781_inst, refa781_op in H. discriminate H. Qed.

Lemma refa781_not3306 : ~ @Equation3306 Fin5 refa781_inst.
Proof. unfold Equation3306. intro H. specialize (H F5_1 F5_4). unfold magma_op, refa781_inst, refa781_op in H. discriminate H. Qed.

Lemma refa781_not3309 : ~ @Equation3309 Fin5 refa781_inst.
Proof. unfold Equation3309. intro H. specialize (H F5_1 F5_4). unfold magma_op, refa781_inst, refa781_op in H. discriminate H. Qed.

Lemma refa781_not3316 : ~ @Equation3316 Fin5 refa781_inst.
Proof. unfold Equation3316. intro H. specialize (H F5_0 F5_1). unfold magma_op, refa781_inst, refa781_op in H. discriminate H. Qed.

Lemma refa781_not3343 : ~ @Equation3343 Fin5 refa781_inst.
Proof. unfold Equation3343. intro H. specialize (H F5_0 F5_1). unfold magma_op, refa781_inst, refa781_op in H. discriminate H. Qed.

Lemma refa781_not3346 : ~ @Equation3346 Fin5 refa781_inst.
Proof. unfold Equation3346. intro H. specialize (H F5_0 F5_1). unfold magma_op, refa781_inst, refa781_op in H. discriminate H. Qed.

Lemma refa781_not3353 : ~ @Equation3353 Fin5 refa781_inst.
Proof. unfold Equation3353. intro H. specialize (H F5_0 F5_1). unfold magma_op, refa781_inst, refa781_op in H. discriminate H. Qed.

Lemma refa781_not3461 : ~ @Equation3461 Fin5 refa781_inst.
Proof. unfold Equation3461. intro H. specialize (H F5_0 F5_1). unfold magma_op, refa781_inst, refa781_op in H. discriminate H. Qed.

Lemma refa781_not3509 : ~ @Equation3509 Fin5 refa781_inst.
Proof. unfold Equation3509. intro H. specialize (H F5_1 F5_4). unfold magma_op, refa781_inst, refa781_op in H. discriminate H. Qed.

Lemma refa781_not3519 : ~ @Equation3519 Fin5 refa781_inst.
Proof. unfold Equation3519. intro H. specialize (H F5_0 F5_2). unfold magma_op, refa781_inst, refa781_op in H. discriminate H. Qed.

Lemma refa781_not3546 : ~ @Equation3546 Fin5 refa781_inst.
Proof. unfold Equation3546. intro H. specialize (H F5_0 F5_1). unfold magma_op, refa781_inst, refa781_op in H. discriminate H. Qed.

Lemma refa781_not3556 : ~ @Equation3556 Fin5 refa781_inst.
Proof. unfold Equation3556. intro H. specialize (H F5_0 F5_1). unfold magma_op, refa781_inst, refa781_op in H. discriminate H. Qed.

Lemma refa781_not3674 : ~ @Equation3674 Fin5 refa781_inst.
Proof. unfold Equation3674. intro H. specialize (H F5_0 F5_1). unfold magma_op, refa781_inst, refa781_op in H. discriminate H. Qed.

Lemma refa781_not3712 : ~ @Equation3712 Fin5 refa781_inst.
Proof. unfold Equation3712. intro H. specialize (H F5_1 F5_4). unfold magma_op, refa781_inst, refa781_op in H. discriminate H. Qed.

Lemma refa781_not3749 : ~ @Equation3749 Fin5 refa781_inst.
Proof. unfold Equation3749. intro H. specialize (H F5_0 F5_1). unfold magma_op, refa781_inst, refa781_op in H. discriminate H. Qed.

Lemma refa781_not3752 : ~ @Equation3752 Fin5 refa781_inst.
Proof. unfold Equation3752. intro H. specialize (H F5_0 F5_2). unfold magma_op, refa781_inst, refa781_op in H. discriminate H. Qed.

Lemma refa781_not3759 : ~ @Equation3759 Fin5 refa781_inst.
Proof. unfold Equation3759. intro H. specialize (H F5_0 F5_1). unfold magma_op, refa781_inst, refa781_op in H. discriminate H. Qed.

Lemma refa781_not3867 : ~ @Equation3867 Fin5 refa781_inst.
Proof. unfold Equation3867. intro H. specialize (H F5_0 F5_1). unfold magma_op, refa781_inst, refa781_op in H. discriminate H. Qed.

Lemma refa781_not3877 : ~ @Equation3877 Fin5 refa781_inst.
Proof. unfold Equation3877. intro H. specialize (H F5_0 F5_1). unfold magma_op, refa781_inst, refa781_op in H. discriminate H. Qed.

Lemma refa781_not3887 : ~ @Equation3887 Fin5 refa781_inst.
Proof. unfold Equation3887. intro H. specialize (H F5_0 F5_1). unfold magma_op, refa781_inst, refa781_op in H. discriminate H. Qed.

Lemma refa781_not3925 : ~ @Equation3925 Fin5 refa781_inst.
Proof. unfold Equation3925. intro H. specialize (H F5_0 F5_2). unfold magma_op, refa781_inst, refa781_op in H. discriminate H. Qed.

Lemma refa781_not3952 : ~ @Equation3952 Fin5 refa781_inst.
Proof. unfold Equation3952. intro H. specialize (H F5_0 F5_2). unfold magma_op, refa781_inst, refa781_op in H. discriminate H. Qed.

Lemma refa781_not3962 : ~ @Equation3962 Fin5 refa781_inst.
Proof. unfold Equation3962. intro H. specialize (H F5_1 F5_0). unfold magma_op, refa781_inst, refa781_op in H. discriminate H. Qed.

Lemma refa781_not4090 : ~ @Equation4090 Fin5 refa781_inst.
Proof. unfold Equation4090. intro H. specialize (H F5_0 F5_1). unfold magma_op, refa781_inst, refa781_op in H. discriminate H. Qed.

Lemma refa781_not4128 : ~ @Equation4128 Fin5 refa781_inst.
Proof. unfold Equation4128. intro H. specialize (H F5_0 F5_2). unfold magma_op, refa781_inst, refa781_op in H. discriminate H. Qed.

Lemma refa781_not4165 : ~ @Equation4165 Fin5 refa781_inst.
Proof. unfold Equation4165. intro H. specialize (H F5_0 F5_2). unfold magma_op, refa781_inst, refa781_op in H. discriminate H. Qed.

Lemma refa781_not4192 : ~ @Equation4192 Fin5 refa781_inst.
Proof. unfold Equation4192. intro H. specialize (H F5_0 F5_2 F5_1). unfold magma_op, refa781_inst, refa781_op in H. discriminate H. Qed.

Lemma refa781_not4284 : ~ @Equation4284 Fin5 refa781_inst.
Proof. unfold Equation4284. intro H. specialize (H F5_1 F5_4). unfold magma_op, refa781_inst, refa781_op in H. discriminate H. Qed.

Lemma refa781_not4291 : ~ @Equation4291 Fin5 refa781_inst.
Proof. unfold Equation4291. intro H. specialize (H F5_0 F5_1). unfold magma_op, refa781_inst, refa781_op in H. discriminate H. Qed.

Lemma refa781_not4320 : ~ @Equation4320 Fin5 refa781_inst.
Proof. unfold Equation4320. intro H. specialize (H F5_1 F5_0). unfold magma_op, refa781_inst, refa781_op in H. discriminate H. Qed.

Lemma refa781_not4396 : ~ @Equation4396 Fin5 refa781_inst.
Proof. unfold Equation4396. intro H. specialize (H F5_1 F5_4). unfold magma_op, refa781_inst, refa781_op in H. discriminate H. Qed.

Lemma refa781_not4406 : ~ @Equation4406 Fin5 refa781_inst.
Proof. unfold Equation4406. intro H. specialize (H F5_0 F5_2). unfold magma_op, refa781_inst, refa781_op in H. discriminate H. Qed.

Lemma refa781_not4435 : ~ @Equation4435 Fin5 refa781_inst.
Proof. unfold Equation4435. intro H. specialize (H F5_0 F5_1). unfold magma_op, refa781_inst, refa781_op in H. discriminate H. Qed.

Lemma refa781_not4445 : ~ @Equation4445 Fin5 refa781_inst.
Proof. unfold Equation4445. intro H. specialize (H F5_1 F5_0). unfold magma_op, refa781_inst, refa781_op in H. discriminate H. Qed.

Lemma refa781_not4480 : ~ @Equation4480 Fin5 refa781_inst.
Proof. unfold Equation4480. intro H. specialize (H F5_0 F5_2). unfold magma_op, refa781_inst, refa781_op in H. discriminate H. Qed.

Lemma refa781_not4606 : ~ @Equation4606 Fin5 refa781_inst.
Proof. unfold Equation4606. intro H. specialize (H F5_0 F5_2). unfold magma_op, refa781_inst, refa781_op in H. discriminate H. Qed.

Lemma refa781_not4666 : ~ @Equation4666 Fin5 refa781_inst.
Proof. unfold Equation4666. intro H. specialize (H F5_0 F5_0 F5_1). unfold magma_op, refa781_inst, refa781_op in H. discriminate H. Qed.

(** ---- refa782 (Fin5) ---- *)

Definition refa782_op (x y : Fin5) : Fin5 :=
  match x, y with
  | F5_0, F5_0 => F5_0 | F5_0, F5_1 => F5_3 | F5_0, F5_2 => F5_3 | F5_0, F5_3 => F5_2 | F5_0, F5_4 => F5_2
  | F5_1, F5_0 => F5_2 | F5_1, F5_1 => F5_1 | F5_1, F5_2 => F5_2 | F5_1, F5_3 => F5_2 | F5_1, F5_4 => F5_4
  | F5_2, F5_0 => F5_4 | F5_2, F5_1 => F5_3 | F5_2, F5_2 => F5_2 | F5_2, F5_3 => F5_3 | F5_2, F5_4 => F5_4
  | F5_3, F5_0 => F5_4 | F5_3, F5_1 => F5_1 | F5_3, F5_2 => F5_2 | F5_3, F5_3 => F5_3 | F5_3, F5_4 => F5_2
  | F5_4, F5_0 => F5_0 | F5_4, F5_1 => F5_3 | F5_4, F5_2 => F5_2 | F5_4, F5_3 => F5_3 | F5_4, F5_4 => F5_4
  end.

#[local] Instance refa782_inst : Magma Fin5 := {| magma_op := refa782_op |}.

Lemma refa782_sat3122 : @Equation3122 Fin5 refa782_inst.
Proof. unfold Equation3122, magma_op, refa782_inst, refa782_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa782_not1691 : ~ @Equation1691 Fin5 refa782_inst.
Proof. unfold Equation1691. intro H. specialize (H F5_0 F5_1). unfold magma_op, refa782_inst, refa782_op in H. discriminate H. Qed.

Lemma refa782_not2456 : ~ @Equation2456 Fin5 refa782_inst.
Proof. unfold Equation2456. intro H. specialize (H F5_0 F5_1). unfold magma_op, refa782_inst, refa782_op in H. discriminate H. Qed.

Lemma refa782_not3512 : ~ @Equation3512 Fin5 refa782_inst.
Proof. unfold Equation3512. intro H. specialize (H F5_1 F5_0). unfold magma_op, refa782_inst, refa782_op in H. discriminate H. Qed.

(** ---- refa783 (Fin5) ---- *)

Definition refa783_op (x y : Fin5) : Fin5 :=
  match x, y with
  | F5_0, F5_0 => F5_0 | F5_0, F5_1 => F5_2 | F5_0, F5_2 => F5_2 | F5_0, F5_3 => F5_3 | F5_0, F5_4 => F5_3
  | F5_1, F5_0 => F5_2 | F5_1, F5_1 => F5_1 | F5_1, F5_2 => F5_2 | F5_1, F5_3 => F5_3 | F5_1, F5_4 => F5_3
  | F5_2, F5_0 => F5_3 | F5_2, F5_1 => F5_4 | F5_2, F5_2 => F5_2 | F5_2, F5_3 => F5_3 | F5_2, F5_4 => F5_4
  | F5_3, F5_0 => F5_0 | F5_3, F5_1 => F5_4 | F5_3, F5_2 => F5_0 | F5_3, F5_3 => F5_3 | F5_3, F5_4 => F5_4
  | F5_4, F5_0 => F5_3 | F5_4, F5_1 => F5_1 | F5_4, F5_2 => F5_1 | F5_4, F5_3 => F5_1 | F5_4, F5_4 => F5_4
  end.

#[local] Instance refa783_inst : Magma Fin5 := {| magma_op := refa783_op |}.

Lemma refa783_sat3122 : @Equation3122 Fin5 refa783_inst.
Proof. unfold Equation3122, magma_op, refa783_inst, refa783_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa783_not2909 : ~ @Equation2909 Fin5 refa783_inst.
Proof. unfold Equation2909. intro H. specialize (H F5_0 F5_4). unfold magma_op, refa783_inst, refa783_op in H. discriminate H. Qed.

Lemma refa783_not2936 : ~ @Equation2936 Fin5 refa783_inst.
Proof. unfold Equation2936. intro H. specialize (H F5_0 F5_4). unfold magma_op, refa783_inst, refa783_op in H. discriminate H. Qed.

Lemma refa783_not4155 : ~ @Equation4155 Fin5 refa783_inst.
Proof. unfold Equation4155. intro H. specialize (H F5_0 F5_1). unfold magma_op, refa783_inst, refa783_op in H. discriminate H. Qed.

(** ---- refa784 (Fin6) ---- *)

Definition refa784_op (x y : Fin6) : Fin6 :=
  match x, y with
  | F6_0, F6_0 => F6_0 | F6_0, F6_1 => F6_5 | F6_0, F6_2 => F6_3 | F6_0, F6_3 => F6_2 | F6_0, F6_4 => F6_4 | F6_0, F6_5 => F6_2
  | F6_1, F6_0 => F6_5 | F6_1, F6_1 => F6_2 | F6_1, F6_2 => F6_2 | F6_1, F6_3 => F6_4 | F6_1, F6_4 => F6_3 | F6_1, F6_5 => F6_0
  | F6_2, F6_0 => F6_3 | F6_2, F6_1 => F6_1 | F6_2, F6_2 => F6_2 | F6_2, F6_3 => F6_0 | F6_2, F6_4 => F6_3 | F6_2, F6_5 => F6_0
  | F6_3, F6_0 => F6_2 | F6_3, F6_1 => F6_4 | F6_3, F6_2 => F6_0 | F6_3, F6_3 => F6_3 | F6_3, F6_4 => F6_2 | F6_3, F6_5 => F6_5
  | F6_4, F6_0 => F6_0 | F6_4, F6_1 => F6_5 | F6_4, F6_2 => F6_3 | F6_4, F6_3 => F6_2 | F6_4, F6_4 => F6_0 | F6_4, F6_5 => F6_2
  | F6_5, F6_0 => F6_2 | F6_5, F6_1 => F6_4 | F6_5, F6_2 => F6_0 | F6_5, F6_3 => F6_3 | F6_5, F6_4 => F6_2 | F6_5, F6_5 => F6_3
  end.

#[local] Instance refa784_inst : Magma Fin6 := {| magma_op := refa784_op |}.

Lemma refa784_sat313 : @Equation313 Fin6 refa784_inst.
Proof. unfold Equation313, magma_op, refa784_inst, refa784_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa784_not3272 : ~ @Equation3272 Fin6 refa784_inst.
Proof. unfold Equation3272. intro H. specialize (H F6_0 F6_1). unfold magma_op, refa784_inst, refa784_op in H. discriminate H. Qed.

(** ---- refa785 (Fin5) ---- *)

Definition refa785_op (x y : Fin5) : Fin5 :=
  match x, y with
  | F5_0, F5_0 => F5_4 | F5_0, F5_1 => F5_4 | F5_0, F5_2 => F5_4 | F5_0, F5_3 => F5_4 | F5_0, F5_4 => F5_4
  | F5_1, F5_0 => F5_2 | F5_1, F5_1 => F5_4 | F5_1, F5_2 => F5_2 | F5_1, F5_3 => F5_3 | F5_1, F5_4 => F5_4
  | F5_2, F5_0 => F5_3 | F5_2, F5_1 => F5_1 | F5_2, F5_2 => F5_4 | F5_2, F5_3 => F5_3 | F5_2, F5_4 => F5_4
  | F5_3, F5_0 => F5_4 | F5_3, F5_1 => F5_1 | F5_3, F5_2 => F5_2 | F5_3, F5_3 => F5_4 | F5_3, F5_4 => F5_4
  | F5_4, F5_0 => F5_0 | F5_4, F5_1 => F5_1 | F5_4, F5_2 => F5_2 | F5_4, F5_3 => F5_3 | F5_4, F5_4 => F5_4
  end.

#[local] Instance refa785_inst : Magma Fin5 := {| magma_op := refa785_op |}.

Lemma refa785_sat3145 : @Equation3145 Fin5 refa785_inst.
Proof. unfold Equation3145, magma_op, refa785_inst, refa785_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa785_not2530 : ~ @Equation2530 Fin5 refa785_inst.
Proof. unfold Equation2530. intro H. specialize (H F5_0 F5_1). unfold magma_op, refa785_inst, refa785_op in H. discriminate H. Qed.

Lemma refa785_not2712 : ~ @Equation2712 Fin5 refa785_inst.
Proof. unfold Equation2712. intro H. specialize (H F5_0 F5_1 F5_3). unfold magma_op, refa785_inst, refa785_op in H. discriminate H. Qed.

Lemma refa785_not3078 : ~ @Equation3078 Fin5 refa785_inst.
Proof. unfold Equation3078. intro H. specialize (H F5_2 F5_0). unfold magma_op, refa785_inst, refa785_op in H. discriminate H. Qed.

Lemma refa785_not3105 : ~ @Equation3105 Fin5 refa785_inst.
Proof. unfold Equation3105. intro H. specialize (H F5_0 F5_1). unfold magma_op, refa785_inst, refa785_op in H. discriminate H. Qed.

(** ---- refa786 (Fin5) ---- *)

Definition refa786_op (x y : Fin5) : Fin5 :=
  match x, y with
  | F5_0, F5_0 => F5_2 | F5_0, F5_1 => F5_1 | F5_0, F5_2 => F5_2 | F5_0, F5_3 => F5_2 | F5_0, F5_4 => F5_4
  | F5_1, F5_0 => F5_0 | F5_1, F5_1 => F5_4 | F5_1, F5_2 => F5_3 | F5_1, F5_3 => F5_3 | F5_1, F5_4 => F5_4
  | F5_2, F5_0 => F5_0 | F5_2, F5_1 => F5_4 | F5_2, F5_2 => F5_4 | F5_2, F5_3 => F5_3 | F5_2, F5_4 => F5_4
  | F5_3, F5_0 => F5_4 | F5_3, F5_1 => F5_1 | F5_3, F5_2 => F5_2 | F5_3, F5_3 => F5_4 | F5_3, F5_4 => F5_4
  | F5_4, F5_0 => F5_0 | F5_4, F5_1 => F5_1 | F5_4, F5_2 => F5_2 | F5_4, F5_3 => F5_3 | F5_4, F5_4 => F5_4
  end.

#[local] Instance refa786_inst : Magma Fin5 := {| magma_op := refa786_op |}.

Lemma refa786_sat3180 : @Equation3180 Fin5 refa786_inst.
Proof. unfold Equation3180, magma_op, refa786_inst, refa786_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa786_not2290 : ~ @Equation2290 Fin5 refa786_inst.
Proof. unfold Equation2290. intro H. specialize (H F5_0 F5_1). unfold magma_op, refa786_inst, refa786_op in H. discriminate H. Qed.

Lemma refa786_not2300 : ~ @Equation2300 Fin5 refa786_inst.
Proof. unfold Equation2300. intro H. specialize (H F5_0 F5_1). unfold magma_op, refa786_inst, refa786_op in H. discriminate H. Qed.

Lemma refa786_not2303 : ~ @Equation2303 Fin5 refa786_inst.
Proof. unfold Equation2303. intro H. specialize (H F5_1 F5_0). unfold magma_op, refa786_inst, refa786_op in H. discriminate H. Qed.

Lemma refa786_not2327 : ~ @Equation2327 Fin5 refa786_inst.
Proof. unfold Equation2327. intro H. specialize (H F5_0 F5_1). unfold magma_op, refa786_inst, refa786_op in H. discriminate H. Qed.

Lemma refa786_not2530 : ~ @Equation2530 Fin5 refa786_inst.
Proof. unfold Equation2530. intro H. specialize (H F5_0 F5_1). unfold magma_op, refa786_inst, refa786_op in H. discriminate H. Qed.

Lemma refa786_not2659 : ~ @Equation2659 Fin5 refa786_inst.
Proof. unfold Equation2659. intro H. specialize (H F5_0 F5_1). unfold magma_op, refa786_inst, refa786_op in H. discriminate H. Qed.

Lemma refa786_not3255 : ~ @Equation3255 Fin5 refa786_inst.
Proof. unfold Equation3255. intro H. specialize (H F5_0 F5_3). unfold magma_op, refa786_inst, refa786_op in H. discriminate H. Qed.

Lemma refa786_not3261 : ~ @Equation3261 Fin5 refa786_inst.
Proof. unfold Equation3261. intro H. specialize (H F5_0 F5_3). unfold magma_op, refa786_inst, refa786_op in H. discriminate H. Qed.

Lemma refa786_not3467 : ~ @Equation3467 Fin5 refa786_inst.
Proof. unfold Equation3467. intro H. specialize (H F5_0 F5_1 F5_2). unfold magma_op, refa786_inst, refa786_op in H. discriminate H. Qed.

Lemma refa786_not4131 : ~ @Equation4131 Fin5 refa786_inst.
Proof. unfold Equation4131. intro H. specialize (H F5_0 F5_3). unfold magma_op, refa786_inst, refa786_op in H. discriminate H. Qed.

Lemma refa786_not4269 : ~ @Equation4269 Fin5 refa786_inst.
Proof. unfold Equation4269. intro H. specialize (H F5_0 F5_3). unfold magma_op, refa786_inst, refa786_op in H. discriminate H. Qed.

(** ---- refa787 (Fin6) ---- *)

Definition refa787_op (x y : Fin6) : Fin6 :=
  match x, y with
  | F6_0, F6_0 => F6_3 | F6_0, F6_1 => F6_3 | F6_0, F6_2 => F6_3 | F6_0, F6_3 => F6_3 | F6_0, F6_4 => F6_3 | F6_0, F6_5 => F6_5
  | F6_1, F6_0 => F6_2 | F6_1, F6_1 => F6_5 | F6_1, F6_2 => F6_2 | F6_1, F6_3 => F6_2 | F6_1, F6_4 => F6_2 | F6_1, F6_5 => F6_5
  | F6_2, F6_0 => F6_1 | F6_2, F6_1 => F6_1 | F6_2, F6_2 => F6_5 | F6_2, F6_3 => F6_1 | F6_2, F6_4 => F6_1 | F6_2, F6_5 => F6_5
  | F6_3, F6_0 => F6_0 | F6_3, F6_1 => F6_4 | F6_3, F6_2 => F6_4 | F6_3, F6_3 => F6_5 | F6_3, F6_4 => F6_4 | F6_3, F6_5 => F6_5
  | F6_4, F6_0 => F6_5 | F6_4, F6_1 => F6_3 | F6_4, F6_2 => F6_3 | F6_4, F6_3 => F6_3 | F6_4, F6_4 => F6_5 | F6_4, F6_5 => F6_5
  | F6_5, F6_0 => F6_0 | F6_5, F6_1 => F6_1 | F6_5, F6_2 => F6_2 | F6_5, F6_3 => F6_3 | F6_5, F6_4 => F6_4 | F6_5, F6_5 => F6_5
  end.

#[local] Instance refa787_inst : Magma Fin6 := {| magma_op := refa787_op |}.

Lemma refa787_sat3180 : @Equation3180 Fin6 refa787_inst.
Proof. unfold Equation3180, magma_op, refa787_inst, refa787_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa787_not2696 : ~ @Equation2696 Fin6 refa787_inst.
Proof. unfold Equation2696. intro H. specialize (H F6_0 F6_1). unfold magma_op, refa787_inst, refa787_op in H. discriminate H. Qed.

Lemma refa787_not2699 : ~ @Equation2699 Fin6 refa787_inst.
Proof. unfold Equation2699. intro H. specialize (H F6_0 F6_1). unfold magma_op, refa787_inst, refa787_op in H. discriminate H. Qed.

Lemma refa787_not2736 : ~ @Equation2736 Fin6 refa787_inst.
Proof. unfold Equation2736. intro H. specialize (H F6_1 F6_0). unfold magma_op, refa787_inst, refa787_op in H. discriminate H. Qed.

Lemma refa787_not3461 : ~ @Equation3461 Fin6 refa787_inst.
Proof. unfold Equation3461. intro H. specialize (H F6_1 F6_0). unfold magma_op, refa787_inst, refa787_op in H. discriminate H. Qed.

Lemma refa787_not3464 : ~ @Equation3464 Fin6 refa787_inst.
Proof. unfold Equation3464. intro H. specialize (H F6_1 F6_0). unfold magma_op, refa787_inst, refa787_op in H. discriminate H. Qed.

Lemma refa787_not4165 : ~ @Equation4165 Fin6 refa787_inst.
Proof. unfold Equation4165. intro H. specialize (H F6_1 F6_0). unfold magma_op, refa787_inst, refa787_op in H. discriminate H. Qed.

(** ---- refa788 (Fin6) ---- *)

Definition refa788_op (x y : Fin6) : Fin6 :=
  match x, y with
  | F6_0, F6_0 => F6_3 | F6_0, F6_1 => F6_3 | F6_0, F6_2 => F6_2 | F6_0, F6_3 => F6_3 | F6_0, F6_4 => F6_5 | F6_0, F6_5 => F6_5
  | F6_1, F6_0 => F6_4 | F6_1, F6_1 => F6_2 | F6_1, F6_2 => F6_2 | F6_1, F6_3 => F6_3 | F6_1, F6_4 => F6_4 | F6_1, F6_5 => F6_5
  | F6_2, F6_0 => F6_0 | F6_2, F6_1 => F6_1 | F6_2, F6_2 => F6_5 | F6_2, F6_3 => F6_4 | F6_2, F6_4 => F6_4 | F6_2, F6_5 => F6_5
  | F6_3, F6_0 => F6_0 | F6_3, F6_1 => F6_1 | F6_3, F6_2 => F6_5 | F6_3, F6_3 => F6_5 | F6_3, F6_4 => F6_4 | F6_3, F6_5 => F6_5
  | F6_4, F6_0 => F6_1 | F6_4, F6_1 => F6_1 | F6_4, F6_2 => F6_2 | F6_4, F6_3 => F6_3 | F6_4, F6_4 => F6_5 | F6_4, F6_5 => F6_5
  | F6_5, F6_0 => F6_0 | F6_5, F6_1 => F6_1 | F6_5, F6_2 => F6_2 | F6_5, F6_3 => F6_3 | F6_5, F6_4 => F6_4 | F6_5, F6_5 => F6_5
  end.

#[local] Instance refa788_inst : Magma Fin6 := {| magma_op := refa788_op |}.

Lemma refa788_sat3180 : @Equation3180 Fin6 refa788_inst.
Proof. unfold Equation3180, magma_op, refa788_inst, refa788_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa788_not2733 : ~ @Equation2733 Fin6 refa788_inst.
Proof. unfold Equation2733. intro H. specialize (H F6_0 F6_1). unfold magma_op, refa788_inst, refa788_op in H. discriminate H. Qed.

(** ---- refa789 (Fin5) ---- *)

Definition refa789_op (x y : Fin5) : Fin5 :=
  match x, y with
  | F5_0, F5_0 => F5_2 | F5_0, F5_1 => F5_2 | F5_0, F5_2 => F5_2 | F5_0, F5_3 => F5_2 | F5_0, F5_4 => F5_2
  | F5_1, F5_0 => F5_3 | F5_1, F5_1 => F5_3 | F5_1, F5_2 => F5_2 | F5_1, F5_3 => F5_3 | F5_1, F5_4 => F5_2
  | F5_2, F5_0 => F5_0 | F5_2, F5_1 => F5_1 | F5_2, F5_2 => F5_2 | F5_2, F5_3 => F5_3 | F5_2, F5_4 => F5_4
  | F5_3, F5_0 => F5_4 | F5_3, F5_1 => F5_1 | F5_3, F5_2 => F5_2 | F5_3, F5_3 => F5_2 | F5_3, F5_4 => F5_4
  | F5_4, F5_0 => F5_3 | F5_4, F5_1 => F5_2 | F5_4, F5_2 => F5_2 | F5_4, F5_3 => F5_3 | F5_4, F5_4 => F5_2
  end.

#[local] Instance refa789_inst : Magma Fin5 := {| magma_op := refa789_op |}.

Lemma refa789_sat3180 : @Equation3180 Fin5 refa789_inst.
Proof. unfold Equation3180, magma_op, refa789_inst, refa789_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa789_not3078 : ~ @Equation3078 Fin5 refa789_inst.
Proof. unfold Equation3078. intro H. specialize (H F5_0 F5_1). unfold magma_op, refa789_inst, refa789_op in H. discriminate H. Qed.

(** ---- refa79 (Fin3) ---- *)

Definition refa79_op (x y : Fin3) : Fin3 :=
  match x, y with
  | F3_0, F3_0 => F3_0 | F3_0, F3_1 => F3_1 | F3_0, F3_2 => F3_1
  | F3_1, F3_0 => F3_2 | F3_1, F3_1 => F3_0 | F3_1, F3_2 => F3_2
  | F3_2, F3_0 => F3_0 | F3_2, F3_1 => F3_0 | F3_2, F3_2 => F3_1
  end.

#[local] Instance refa79_inst : Magma Fin3 := {| magma_op := refa79_op |}.

Lemma refa79_sat1432 : @Equation1432 Fin3 refa79_inst.
Proof. unfold Equation1432, magma_op, refa79_inst, refa79_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa79_not1635 : ~ @Equation1635 Fin3 refa79_inst.
Proof. unfold Equation1635. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa79_inst, refa79_op in H. discriminate H. Qed.

Lemma refa79_not4131 : ~ @Equation4131 Fin3 refa79_inst.
Proof. unfold Equation4131. intro H. specialize (H F3_1 F3_0). unfold magma_op, refa79_inst, refa79_op in H. discriminate H. Qed.

(** ---- refa790 (Fin5) ---- *)

Definition refa790_op (x y : Fin5) : Fin5 :=
  match x, y with
  | F5_0, F5_0 => F5_1 | F5_0, F5_1 => F5_3 | F5_0, F5_2 => F5_3 | F5_0, F5_3 => F5_1 | F5_0, F5_4 => F5_3
  | F5_1, F5_0 => F5_4 | F5_1, F5_1 => F5_0 | F5_1, F5_2 => F5_4 | F5_1, F5_3 => F5_0 | F5_1, F5_4 => F5_4
  | F5_2, F5_0 => F5_0 | F5_2, F5_1 => F5_1 | F5_2, F5_2 => F5_2 | F5_2, F5_3 => F5_3 | F5_2, F5_4 => F5_4
  | F5_3, F5_0 => F5_4 | F5_3, F5_1 => F5_2 | F5_3, F5_2 => F5_2 | F5_3, F5_3 => F5_2 | F5_3, F5_4 => F5_4
  | F5_4, F5_0 => F5_2 | F5_4, F5_1 => F5_3 | F5_4, F5_2 => F5_2 | F5_4, F5_3 => F5_3 | F5_4, F5_4 => F5_2
  end.

#[local] Instance refa790_inst : Magma Fin5 := {| magma_op := refa790_op |}.

Lemma refa790_sat3197 : @Equation3197 Fin5 refa790_inst.
Proof. unfold Equation3197, magma_op, refa790_inst, refa790_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa790_not2644 : ~ @Equation2644 Fin5 refa790_inst.
Proof. unfold Equation2644. intro H. specialize (H F5_0). unfold magma_op, refa790_inst, refa790_op in H. discriminate H. Qed.

Lemma refa790_not3456 : ~ @Equation3456 Fin5 refa790_inst.
Proof. unfold Equation3456. intro H. specialize (H F5_0). unfold magma_op, refa790_inst, refa790_op in H. discriminate H. Qed.

(** ---- refa791 (Fin5) ---- *)

Definition refa791_op (x y : Fin5) : Fin5 :=
  match x, y with
  | F5_0, F5_0 => F5_1 | F5_0, F5_1 => F5_1 | F5_0, F5_2 => F5_3 | F5_0, F5_3 => F5_4 | F5_0, F5_4 => F5_1
  | F5_1, F5_0 => F5_2 | F5_1, F5_1 => F5_1 | F5_1, F5_2 => F5_1 | F5_1, F5_3 => F5_1 | F5_1, F5_4 => F5_1
  | F5_2, F5_0 => F5_2 | F5_2, F5_1 => F5_1 | F5_2, F5_2 => F5_1 | F5_2, F5_3 => F5_1 | F5_2, F5_4 => F5_1
  | F5_3, F5_0 => F5_1 | F5_3, F5_1 => F5_1 | F5_3, F5_2 => F5_1 | F5_3, F5_3 => F5_1 | F5_3, F5_4 => F5_1
  | F5_4, F5_0 => F5_4 | F5_4, F5_1 => F5_1 | F5_4, F5_2 => F5_1 | F5_4, F5_3 => F5_1 | F5_4, F5_4 => F5_1
  end.

#[local] Instance refa791_inst : Magma Fin5 := {| magma_op := refa791_op |}.

Lemma refa791_sat3295 : @Equation3295 Fin5 refa791_inst.
Proof. unfold Equation3295, magma_op, refa791_inst, refa791_op. intros x y z w. destruct x, y, z, w; reflexivity. Qed.

Lemma refa791_sat3299 : @Equation3299 Fin5 refa791_inst.
Proof. unfold Equation3299, magma_op, refa791_inst, refa791_op. intros x y z w. destruct x, y, z, w; reflexivity. Qed.

Lemma refa791_not3255 : ~ @Equation3255 Fin5 refa791_inst.
Proof. unfold Equation3255. intro H. specialize (H F5_0 F5_1). unfold magma_op, refa791_inst, refa791_op in H. discriminate H. Qed.

Lemma refa791_not3279 : ~ @Equation3279 Fin5 refa791_inst.
Proof. unfold Equation3279. intro H. specialize (H F5_1 F5_0). unfold magma_op, refa791_inst, refa791_op in H. discriminate H. Qed.

Lemma refa791_not4065 : ~ @Equation4065 Fin5 refa791_inst.
Proof. unfold Equation4065. intro H. specialize (H F5_0). unfold magma_op, refa791_inst, refa791_op in H. discriminate H. Qed.

Lemma refa791_not4269 : ~ @Equation4269 Fin5 refa791_inst.
Proof. unfold Equation4269. intro H. specialize (H F5_0 F5_1). unfold magma_op, refa791_inst, refa791_op in H. discriminate H. Qed.

Lemma refa791_not4275 : ~ @Equation4275 Fin5 refa791_inst.
Proof. unfold Equation4275. intro H. specialize (H F5_2 F5_0). unfold magma_op, refa791_inst, refa791_op in H. discriminate H. Qed.

Lemma refa791_not4284 : ~ @Equation4284 Fin5 refa791_inst.
Proof. unfold Equation4284. intro H. specialize (H F5_0 F5_2). unfold magma_op, refa791_inst, refa791_op in H. discriminate H. Qed.

Lemma refa791_not4291 : ~ @Equation4291 Fin5 refa791_inst.
Proof. unfold Equation4291. intro H. specialize (H F5_0 F5_2). unfold magma_op, refa791_inst, refa791_op in H. discriminate H. Qed.

Lemma refa791_not4320 : ~ @Equation4320 Fin5 refa791_inst.
Proof. unfold Equation4320. intro H. specialize (H F5_0 F5_1). unfold magma_op, refa791_inst, refa791_op in H. discriminate H. Qed.

Lemma refa791_not4584 : ~ @Equation4584 Fin5 refa791_inst.
Proof. unfold Equation4584. intro H. specialize (H F5_0 F5_2). unfold magma_op, refa791_inst, refa791_op in H. discriminate H. Qed.

Lemma refa791_not4606 : ~ @Equation4606 Fin5 refa791_inst.
Proof. unfold Equation4606. intro H. specialize (H F5_2 F5_0). unfold magma_op, refa791_inst, refa791_op in H. discriminate H. Qed.

(** ---- refa792 (Fin5) ---- *)

Definition refa792_op (x y : Fin5) : Fin5 :=
  match x, y with
  | F5_0, F5_0 => F5_1 | F5_0, F5_1 => F5_1 | F5_0, F5_2 => F5_4 | F5_0, F5_3 => F5_4 | F5_0, F5_4 => F5_1
  | F5_1, F5_0 => F5_2 | F5_1, F5_1 => F5_1 | F5_1, F5_2 => F5_3 | F5_1, F5_3 => F5_1 | F5_1, F5_4 => F5_1
  | F5_2, F5_0 => F5_1 | F5_2, F5_1 => F5_1 | F5_2, F5_2 => F5_1 | F5_2, F5_3 => F5_1 | F5_2, F5_4 => F5_1
  | F5_3, F5_0 => F5_1 | F5_3, F5_1 => F5_1 | F5_3, F5_2 => F5_1 | F5_3, F5_3 => F5_1 | F5_3, F5_4 => F5_0
  | F5_4, F5_0 => F5_1 | F5_4, F5_1 => F5_1 | F5_4, F5_2 => F5_1 | F5_4, F5_3 => F5_1 | F5_4, F5_4 => F5_1
  end.

#[local] Instance refa792_inst : Magma Fin5 := {| magma_op := refa792_op |}.

Lemma refa792_sat3273 : @Equation3273 Fin5 refa792_inst.
Proof. unfold Equation3273, magma_op, refa792_inst, refa792_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa792_not3261 : ~ @Equation3261 Fin5 refa792_inst.
Proof. unfold Equation3261. intro H. specialize (H F5_0 F5_1). unfold magma_op, refa792_inst, refa792_op in H. discriminate H. Qed.

Lemma refa792_not3269 : ~ @Equation3269 Fin5 refa792_inst.
Proof. unfold Equation3269. intro H. specialize (H F5_1 F5_0). unfold magma_op, refa792_inst, refa792_op in H. discriminate H. Qed.

(** ---- refa793 (Fin5) ---- *)

Definition refa793_op (x y : Fin5) : Fin5 :=
  match x, y with
  | F5_0, F5_0 => F5_2 | F5_0, F5_1 => F5_3 | F5_0, F5_2 => F5_2 | F5_0, F5_3 => F5_0 | F5_0, F5_4 => F5_0
  | F5_1, F5_0 => F5_4 | F5_1, F5_1 => F5_1 | F5_1, F5_2 => F5_1 | F5_1, F5_3 => F5_4 | F5_1, F5_4 => F5_1
  | F5_2, F5_0 => F5_2 | F5_2, F5_1 => F5_4 | F5_2, F5_2 => F5_2 | F5_2, F5_3 => F5_2 | F5_2, F5_4 => F5_2
  | F5_3, F5_0 => F5_4 | F5_3, F5_1 => F5_3 | F5_3, F5_2 => F5_4 | F5_3, F5_3 => F5_3 | F5_3, F5_4 => F5_3
  | F5_4, F5_0 => F5_4 | F5_4, F5_1 => F5_4 | F5_4, F5_2 => F5_4 | F5_4, F5_3 => F5_4 | F5_4, F5_4 => F5_4
  end.

#[local] Instance refa793_inst : Magma Fin5 := {| magma_op := refa793_op |}.

Lemma refa793_sat3321 : @Equation3321 Fin5 refa793_inst.
Proof. unfold Equation3321, magma_op, refa793_inst, refa793_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa793_not3256 : ~ @Equation3256 Fin5 refa793_inst.
Proof. unfold Equation3256. intro H. specialize (H F5_0 F5_1). unfold magma_op, refa793_inst, refa793_op in H. discriminate H. Qed.

Lemma refa793_not3306 : ~ @Equation3306 Fin5 refa793_inst.
Proof. unfold Equation3306. intro H. specialize (H F5_0 F5_1). unfold magma_op, refa793_inst, refa793_op in H. discriminate H. Qed.

Lemma refa793_not3316 : ~ @Equation3316 Fin5 refa793_inst.
Proof. unfold Equation3316. intro H. specialize (H F5_0 F5_1). unfold magma_op, refa793_inst, refa793_op in H. discriminate H. Qed.

Lemma refa793_not3319 : ~ @Equation3319 Fin5 refa793_inst.
Proof. unfold Equation3319. intro H. specialize (H F5_1 F5_0). unfold magma_op, refa793_inst, refa793_op in H. discriminate H. Qed.

Lemma refa793_not4269 : ~ @Equation4269 Fin5 refa793_inst.
Proof. unfold Equation4269. intro H. specialize (H F5_0 F5_1). unfold magma_op, refa793_inst, refa793_op in H. discriminate H. Qed.

Lemma refa793_not4270 : ~ @Equation4270 Fin5 refa793_inst.
Proof. unfold Equation4270. intro H. specialize (H F5_0 F5_1). unfold magma_op, refa793_inst, refa793_op in H. discriminate H. Qed.

Lemma refa793_not4314 : ~ @Equation4314 Fin5 refa793_inst.
Proof. unfold Equation4314. intro H. specialize (H F5_0 F5_1). unfold magma_op, refa793_inst, refa793_op in H. discriminate H. Qed.

Lemma refa793_not4583 : ~ @Equation4583 Fin5 refa793_inst.
Proof. unfold Equation4583. intro H. specialize (H F5_0 F5_1). unfold magma_op, refa793_inst, refa793_op in H. discriminate H. Qed.

Lemma refa793_not4631 : ~ @Equation4631 Fin5 refa793_inst.
Proof. unfold Equation4631. intro H. specialize (H F5_0 F5_0 F5_1). unfold magma_op, refa793_inst, refa793_op in H. discriminate H. Qed.

(** ---- refa794 (Fin6) ---- *)

Definition refa794_op (x y : Fin6) : Fin6 :=
  match x, y with
  | F6_0, F6_0 => F6_5 | F6_0, F6_1 => F6_1 | F6_0, F6_2 => F6_2 | F6_0, F6_3 => F6_0 | F6_0, F6_4 => F6_5 | F6_0, F6_5 => F6_4
  | F6_1, F6_0 => F6_2 | F6_1, F6_1 => F6_0 | F6_1, F6_2 => F6_0 | F6_1, F6_3 => F6_3 | F6_1, F6_4 => F6_1 | F6_1, F6_5 => F6_5
  | F6_2, F6_0 => F6_1 | F6_2, F6_1 => F6_0 | F6_2, F6_2 => F6_0 | F6_2, F6_3 => F6_5 | F6_2, F6_4 => F6_2 | F6_2, F6_5 => F6_3
  | F6_3, F6_0 => F6_4 | F6_3, F6_1 => F6_5 | F6_3, F6_2 => F6_3 | F6_3, F6_3 => F6_1 | F6_3, F6_4 => F6_0 | F6_3, F6_5 => F6_1
  | F6_4, F6_0 => F6_5 | F6_4, F6_1 => F6_2 | F6_4, F6_2 => F6_1 | F6_4, F6_3 => F6_4 | F6_4, F6_4 => F6_5 | F6_4, F6_5 => F6_0
  | F6_5, F6_0 => F6_0 | F6_5, F6_1 => F6_3 | F6_5, F6_2 => F6_5 | F6_5, F6_3 => F6_1 | F6_5, F6_4 => F6_4 | F6_5, F6_5 => F6_1
  end.

#[local] Instance refa794_inst : Magma Fin6 := {| magma_op := refa794_op |}.

Lemma refa794_sat3342 : @Equation3342 Fin6 refa794_inst.
Proof. unfold Equation3342, magma_op, refa794_inst, refa794_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa794_sat3964 : @Equation3964 Fin6 refa794_inst.
Proof. unfold Equation3964, magma_op, refa794_inst, refa794_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa794_not3306 : ~ @Equation3306 Fin6 refa794_inst.
Proof. unfold Equation3306. intro H. specialize (H F6_0 F6_3). unfold magma_op, refa794_inst, refa794_op in H. discriminate H. Qed.

Lemma refa794_not3308 : ~ @Equation3308 Fin6 refa794_inst.
Proof. unfold Equation3308. intro H. specialize (H F6_0 F6_1). unfold magma_op, refa794_inst, refa794_op in H. discriminate H. Qed.

Lemma refa794_not3315 : ~ @Equation3315 Fin6 refa794_inst.
Proof. unfold Equation3315. intro H. specialize (H F6_0 F6_1). unfold magma_op, refa794_inst, refa794_op in H. discriminate H. Qed.

Lemma refa794_not3319 : ~ @Equation3319 Fin6 refa794_inst.
Proof. unfold Equation3319. intro H. specialize (H F6_0 F6_1). unfold magma_op, refa794_inst, refa794_op in H. discriminate H. Qed.

Lemma refa794_not3346 : ~ @Equation3346 Fin6 refa794_inst.
Proof. unfold Equation3346. intro H. specialize (H F6_0 F6_1). unfold magma_op, refa794_inst, refa794_op in H. discriminate H. Qed.

Lemma refa794_not3353 : ~ @Equation3353 Fin6 refa794_inst.
Proof. unfold Equation3353. intro H. specialize (H F6_0 F6_1). unfold magma_op, refa794_inst, refa794_op in H. discriminate H. Qed.

Lemma refa794_not3509 : ~ @Equation3509 Fin6 refa794_inst.
Proof. unfold Equation3509. intro H. specialize (H F6_0 F6_1). unfold magma_op, refa794_inst, refa794_op in H. discriminate H. Qed.

Lemma refa794_not3511 : ~ @Equation3511 Fin6 refa794_inst.
Proof. unfold Equation3511. intro H. specialize (H F6_0 F6_1). unfold magma_op, refa794_inst, refa794_op in H. discriminate H. Qed.

Lemma refa794_not3518 : ~ @Equation3518 Fin6 refa794_inst.
Proof. unfold Equation3518. intro H. specialize (H F6_0 F6_3). unfold magma_op, refa794_inst, refa794_op in H. discriminate H. Qed.

Lemma refa794_not3545 : ~ @Equation3545 Fin6 refa794_inst.
Proof. unfold Equation3545. intro H. specialize (H F6_0 F6_1). unfold magma_op, refa794_inst, refa794_op in H. discriminate H. Qed.

Lemma refa794_not3549 : ~ @Equation3549 Fin6 refa794_inst.
Proof. unfold Equation3549. intro H. specialize (H F6_0 F6_1). unfold magma_op, refa794_inst, refa794_op in H. discriminate H. Qed.

Lemma refa794_not3556 : ~ @Equation3556 Fin6 refa794_inst.
Proof. unfold Equation3556. intro H. specialize (H F6_0 F6_1). unfold magma_op, refa794_inst, refa794_op in H. discriminate H. Qed.

Lemma refa794_not3558 : ~ @Equation3558 Fin6 refa794_inst.
Proof. unfold Equation3558. intro H. specialize (H F6_0 F6_1). unfold magma_op, refa794_inst, refa794_op in H. discriminate H. Qed.

Lemma refa794_not3659 : ~ @Equation3659 Fin6 refa794_inst.
Proof. unfold Equation3659. intro H. specialize (H F6_0). unfold magma_op, refa794_inst, refa794_op in H. discriminate H. Qed.

Lemma refa794_not3915 : ~ @Equation3915 Fin6 refa794_inst.
Proof. unfold Equation3915. intro H. specialize (H F6_0 F6_1). unfold magma_op, refa794_inst, refa794_op in H. discriminate H. Qed.

Lemma refa794_not3917 : ~ @Equation3917 Fin6 refa794_inst.
Proof. unfold Equation3917. intro H. specialize (H F6_0 F6_1). unfold magma_op, refa794_inst, refa794_op in H. discriminate H. Qed.

Lemma refa794_not3924 : ~ @Equation3924 Fin6 refa794_inst.
Proof. unfold Equation3924. intro H. specialize (H F6_0 F6_5). unfold magma_op, refa794_inst, refa794_op in H. discriminate H. Qed.

Lemma refa794_not3928 : ~ @Equation3928 Fin6 refa794_inst.
Proof. unfold Equation3928. intro H. specialize (H F6_0 F6_1). unfold magma_op, refa794_inst, refa794_op in H. discriminate H. Qed.

Lemma refa794_not3951 : ~ @Equation3951 Fin6 refa794_inst.
Proof. unfold Equation3951. intro H. specialize (H F6_0 F6_1). unfold magma_op, refa794_inst, refa794_op in H. discriminate H. Qed.

Lemma refa794_not3955 : ~ @Equation3955 Fin6 refa794_inst.
Proof. unfold Equation3955. intro H. specialize (H F6_0 F6_3). unfold magma_op, refa794_inst, refa794_op in H. discriminate H. Qed.

Lemma refa794_not3962 : ~ @Equation3962 Fin6 refa794_inst.
Proof. unfold Equation3962. intro H. specialize (H F6_2 F6_3). unfold magma_op, refa794_inst, refa794_op in H. discriminate H. Qed.

Lemma refa794_not4120 : ~ @Equation4120 Fin6 refa794_inst.
Proof. unfold Equation4120. intro H. specialize (H F6_0 F6_1). unfold magma_op, refa794_inst, refa794_op in H. discriminate H. Qed.

Lemma refa794_not4127 : ~ @Equation4127 Fin6 refa794_inst.
Proof. unfold Equation4127. intro H. specialize (H F6_0 F6_5). unfold magma_op, refa794_inst, refa794_op in H. discriminate H. Qed.

Lemma refa794_not4131 : ~ @Equation4131 Fin6 refa794_inst.
Proof. unfold Equation4131. intro H. specialize (H F6_2 F6_3). unfold magma_op, refa794_inst, refa794_op in H. discriminate H. Qed.

Lemma refa794_not4158 : ~ @Equation4158 Fin6 refa794_inst.
Proof. unfold Equation4158. intro H. specialize (H F6_0 F6_3). unfold magma_op, refa794_inst, refa794_op in H. discriminate H. Qed.

Lemma refa794_not4165 : ~ @Equation4165 Fin6 refa794_inst.
Proof. unfold Equation4165. intro H. specialize (H F6_0 F6_1). unfold magma_op, refa794_inst, refa794_op in H. discriminate H. Qed.

Lemma refa794_not4167 : ~ @Equation4167 Fin6 refa794_inst.
Proof. unfold Equation4167. intro H. specialize (H F6_0 F6_1). unfold magma_op, refa794_inst, refa794_op in H. discriminate H. Qed.

Lemma refa794_not4283 : ~ @Equation4283 Fin6 refa794_inst.
Proof. unfold Equation4283. intro H. specialize (H F6_0 F6_1). unfold magma_op, refa794_inst, refa794_op in H. discriminate H. Qed.

Lemma refa794_not4290 : ~ @Equation4290 Fin6 refa794_inst.
Proof. unfold Equation4290. intro H. specialize (H F6_0 F6_1). unfold magma_op, refa794_inst, refa794_op in H. discriminate H. Qed.

Lemma refa794_not4320 : ~ @Equation4320 Fin6 refa794_inst.
Proof. unfold Equation4320. intro H. specialize (H F6_0 F6_1). unfold magma_op, refa794_inst, refa794_op in H. discriminate H. Qed.

Lemma refa794_not4380 : ~ @Equation4380 Fin6 refa794_inst.
Proof. unfold Equation4380. intro H. specialize (H F6_0). unfold magma_op, refa794_inst, refa794_op in H. discriminate H. Qed.

Lemma refa794_not4598 : ~ @Equation4598 Fin6 refa794_inst.
Proof. unfold Equation4598. intro H. specialize (H F6_0 F6_1). unfold magma_op, refa794_inst, refa794_op in H. discriminate H. Qed.

Lemma refa794_not4605 : ~ @Equation4605 Fin6 refa794_inst.
Proof. unfold Equation4605. intro H. specialize (H F6_0 F6_1). unfold magma_op, refa794_inst, refa794_op in H. discriminate H. Qed.

Lemma refa794_not4635 : ~ @Equation4635 Fin6 refa794_inst.
Proof. unfold Equation4635. intro H. specialize (H F6_0 F6_1). unfold magma_op, refa794_inst, refa794_op in H. discriminate H. Qed.

(** ---- refa795 (Fin9) ---- *)

Definition refa795_op (x y : Fin9) : Fin9 :=
  match x, y with
  | F9_0, F9_0 => F9_1 | F9_0, F9_1 => F9_2 | F9_0, F9_2 => F9_1 | F9_0, F9_3 => F9_0 | F9_0, F9_4 => F9_6 | F9_0, F9_5 => F9_4 | F9_0, F9_6 => F9_5 | F9_0, F9_7 => F9_8 | F9_0, F9_8 => F9_3
  | F9_1, F9_0 => F9_0 | F9_1, F9_1 => F9_4 | F9_1, F9_2 => F9_2 | F9_1, F9_3 => F9_4 | F9_1, F9_4 => F9_3 | F9_1, F9_5 => F9_1 | F9_1, F9_6 => F9_7 | F9_1, F9_7 => F9_7 | F9_1, F9_8 => F9_8
  | F9_2, F9_0 => F9_3 | F9_2, F9_1 => F9_8 | F9_2, F9_2 => F9_1 | F9_2, F9_3 => F9_2 | F9_2, F9_4 => F9_5 | F9_2, F9_5 => F9_6 | F9_2, F9_6 => F9_4 | F9_2, F9_7 => F9_0 | F9_2, F9_8 => F9_1
  | F9_3, F9_0 => F9_8 | F9_3, F9_1 => F9_7 | F9_3, F9_2 => F9_0 | F9_3, F9_3 => F9_4 | F9_3, F9_4 => F9_7 | F9_3, F9_5 => F9_3 | F9_3, F9_6 => F9_1 | F9_3, F9_7 => F9_4 | F9_3, F9_8 => F9_2
  | F9_4, F9_0 => F9_4 | F9_4, F9_1 => F9_1 | F9_4, F9_2 => F9_6 | F9_4, F9_3 => F9_3 | F9_4, F9_4 => F9_8 | F9_4, F9_5 => F9_8 | F9_4, F9_6 => F9_4 | F9_4, F9_7 => F9_7 | F9_4, F9_8 => F9_5
  | F9_5, F9_0 => F9_5 | F9_5, F9_1 => F9_7 | F9_5, F9_2 => F9_4 | F9_5, F9_3 => F9_1 | F9_5, F9_4 => F9_4 | F9_5, F9_5 => F9_8 | F9_5, F9_6 => F9_8 | F9_5, F9_7 => F9_3 | F9_5, F9_8 => F9_6
  | F9_6, F9_0 => F9_6 | F9_6, F9_1 => F9_3 | F9_6, F9_2 => F9_5 | F9_6, F9_3 => F9_7 | F9_6, F9_4 => F9_8 | F9_6, F9_5 => F9_4 | F9_6, F9_6 => F9_8 | F9_6, F9_7 => F9_1 | F9_6, F9_8 => F9_4
  | F9_7, F9_0 => F9_2 | F9_7, F9_1 => F9_4 | F9_7, F9_2 => F9_8 | F9_7, F9_3 => F9_7 | F9_7, F9_4 => F9_1 | F9_7, F9_5 => F9_7 | F9_7, F9_6 => F9_3 | F9_7, F9_7 => F9_4 | F9_7, F9_8 => F9_0
  | F9_8, F9_0 => F9_1 | F9_8, F9_1 => F9_0 | F9_8, F9_2 => F9_3 | F9_8, F9_3 => F9_8 | F9_8, F9_4 => F9_4 | F9_8, F9_5 => F9_5 | F9_8, F9_6 => F9_6 | F9_8, F9_7 => F9_2 | F9_8, F9_8 => F9_1
  end.

#[local] Instance refa795_inst : Magma Fin9 := {| magma_op := refa795_op |}.

Lemma refa795_sat3342 : @Equation3342 Fin9 refa795_inst.
Proof. unfold Equation3342, magma_op, refa795_inst, refa795_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa795_not3862 : ~ @Equation3862 Fin9 refa795_inst.
Proof. unfold Equation3862. intro H. specialize (H F9_0). unfold magma_op, refa795_inst, refa795_op in H. discriminate H. Qed.

(** ---- refa796 (Fin7) ---- *)

Definition refa796_op (x y : Fin7) : Fin7 :=
  match x, y with
  | F7_0, F7_0 => F7_1 | F7_0, F7_1 => F7_2 | F7_0, F7_2 => F7_1 | F7_0, F7_3 => F7_0 | F7_0, F7_4 => F7_3 | F7_0, F7_5 => F7_0 | F7_0, F7_6 => F7_0
  | F7_1, F7_0 => F7_1 | F7_1, F7_1 => F7_5 | F7_1, F7_2 => F7_5 | F7_1, F7_3 => F7_1 | F7_1, F7_4 => F7_3 | F7_1, F7_5 => F7_2 | F7_1, F7_6 => F7_1
  | F7_2, F7_0 => F7_0 | F7_2, F7_1 => F7_1 | F7_2, F7_2 => F7_4 | F7_2, F7_3 => F7_4 | F7_2, F7_4 => F7_3 | F7_2, F7_5 => F7_5 | F7_2, F7_6 => F7_3
  | F7_3, F7_0 => F7_1 | F7_3, F7_1 => F7_5 | F7_3, F7_2 => F7_4 | F7_3, F7_3 => F7_6 | F7_3, F7_4 => F7_2 | F7_3, F7_5 => F7_0 | F7_3, F7_6 => F7_3
  | F7_4, F7_0 => F7_2 | F7_4, F7_1 => F7_2 | F7_4, F7_2 => F7_3 | F7_4, F7_3 => F7_2 | F7_4, F7_4 => F7_2 | F7_4, F7_5 => F7_2 | F7_4, F7_6 => F7_3
  | F7_5, F7_0 => F7_2 | F7_5, F7_1 => F7_5 | F7_5, F7_2 => F7_0 | F7_5, F7_3 => F7_5 | F7_5, F7_4 => F7_3 | F7_5, F7_5 => F7_0 | F7_5, F7_6 => F7_5
  | F7_6, F7_0 => F7_1 | F7_6, F7_1 => F7_5 | F7_6, F7_2 => F7_3 | F7_6, F7_3 => F7_3 | F7_6, F7_4 => F7_3 | F7_6, F7_5 => F7_0 | F7_6, F7_6 => F7_3
  end.

#[local] Instance refa796_inst : Magma Fin7 := {| magma_op := refa796_op |}.

Lemma refa796_sat3352 : @Equation3352 Fin7 refa796_inst.
Proof. unfold Equation3352, magma_op, refa796_inst, refa796_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa796_not3308 : ~ @Equation3308 Fin7 refa796_inst.
Proof. unfold Equation3308. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa796_inst, refa796_op in H. discriminate H. Qed.

Lemma refa796_not3456 : ~ @Equation3456 Fin7 refa796_inst.
Proof. unfold Equation3456. intro H. specialize (H F7_0). unfold magma_op, refa796_inst, refa796_op in H. discriminate H. Qed.

Lemma refa796_not3862 : ~ @Equation3862 Fin7 refa796_inst.
Proof. unfold Equation3862. intro H. specialize (H F7_0). unfold magma_op, refa796_inst, refa796_op in H. discriminate H. Qed.

(** ---- refa797 (Fin5) ---- *)

Definition refa797_op (x y : Fin5) : Fin5 :=
  match x, y with
  | F5_0, F5_0 => F5_0 | F5_0, F5_1 => F5_2 | F5_0, F5_2 => F5_4 | F5_0, F5_3 => F5_4 | F5_0, F5_4 => F5_1
  | F5_1, F5_0 => F5_4 | F5_1, F5_1 => F5_1 | F5_1, F5_2 => F5_0 | F5_1, F5_3 => F5_0 | F5_1, F5_4 => F5_2
  | F5_2, F5_0 => F5_1 | F5_2, F5_1 => F5_4 | F5_2, F5_2 => F5_3 | F5_2, F5_3 => F5_3 | F5_2, F5_4 => F5_0
  | F5_3, F5_0 => F5_1 | F5_3, F5_1 => F5_4 | F5_3, F5_2 => F5_3 | F5_3, F5_3 => F5_3 | F5_3, F5_4 => F5_0
  | F5_4, F5_0 => F5_2 | F5_4, F5_1 => F5_0 | F5_4, F5_2 => F5_1 | F5_4, F5_3 => F5_1 | F5_4, F5_4 => F5_4
  end.

#[local] Instance refa797_inst : Magma Fin5 := {| magma_op := refa797_op |}.

Lemma refa797_sat335 : @Equation335 Fin5 refa797_inst.
Proof. unfold Equation335, magma_op, refa797_inst, refa797_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa797_sat384 : @Equation384 Fin5 refa797_inst.
Proof. unfold Equation384, magma_op, refa797_inst, refa797_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa797_not3722 : ~ @Equation3722 Fin5 refa797_inst.
Proof. unfold Equation3722. intro H. specialize (H F5_0 F5_1). unfold magma_op, refa797_inst, refa797_op in H. discriminate H. Qed.

(** ---- refa798 (Fin5) ---- *)

Definition refa798_op (x y : Fin5) : Fin5 :=
  match x, y with
  | F5_0, F5_0 => F5_2 | F5_0, F5_1 => F5_4 | F5_0, F5_2 => F5_4 | F5_0, F5_3 => F5_4 | F5_0, F5_4 => F5_4
  | F5_1, F5_0 => F5_0 | F5_1, F5_1 => F5_3 | F5_1, F5_2 => F5_3 | F5_1, F5_3 => F5_3 | F5_1, F5_4 => F5_3
  | F5_2, F5_0 => F5_0 | F5_2, F5_1 => F5_0 | F5_2, F5_2 => F5_0 | F5_2, F5_3 => F5_0 | F5_2, F5_4 => F5_0
  | F5_3, F5_0 => F5_3 | F5_3, F5_1 => F5_3 | F5_3, F5_2 => F5_3 | F5_3, F5_3 => F5_3 | F5_3, F5_4 => F5_3
  | F5_4, F5_0 => F5_0 | F5_4, F5_1 => F5_0 | F5_4, F5_2 => F5_0 | F5_4, F5_3 => F5_0 | F5_4, F5_4 => F5_0
  end.

#[local] Instance refa798_inst : Magma Fin5 := {| magma_op := refa798_op |}.

Lemma refa798_sat3527 : @Equation3527 Fin5 refa798_inst.
Proof. unfold Equation3527, magma_op, refa798_inst, refa798_op. intros x y z w. destruct x, y, z, w; reflexivity. Qed.

Lemma refa798_not4314 : ~ @Equation4314 Fin5 refa798_inst.
Proof. unfold Equation4314. intro H. specialize (H F5_0 F5_1). unfold magma_op, refa798_inst, refa798_op in H. discriminate H. Qed.

(** ---- refa799 (Fin5) ---- *)

Definition refa799_op (x y : Fin5) : Fin5 :=
  match x, y with
  | F5_0, F5_0 => F5_2 | F5_0, F5_1 => F5_3 | F5_0, F5_2 => F5_3 | F5_0, F5_3 => F5_2 | F5_0, F5_4 => F5_2
  | F5_1, F5_0 => F5_2 | F5_1, F5_1 => F5_1 | F5_1, F5_2 => F5_1 | F5_1, F5_3 => F5_2 | F5_1, F5_4 => F5_2
  | F5_2, F5_0 => F5_4 | F5_2, F5_1 => F5_3 | F5_2, F5_2 => F5_3 | F5_2, F5_3 => F5_4 | F5_2, F5_4 => F5_4
  | F5_3, F5_0 => F5_2 | F5_3, F5_1 => F5_1 | F5_3, F5_2 => F5_1 | F5_3, F5_3 => F5_2 | F5_3, F5_4 => F5_2
  | F5_4, F5_0 => F5_4 | F5_4, F5_1 => F5_3 | F5_4, F5_2 => F5_3 | F5_4, F5_3 => F5_4 | F5_4, F5_4 => F5_4
  end.

#[local] Instance refa799_inst : Magma Fin5 := {| magma_op := refa799_op |}.

Lemma refa799_sat3532 : @Equation3532 Fin5 refa799_inst.
Proof. unfold Equation3532, magma_op, refa799_inst, refa799_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa799_not4282 : ~ @Equation4282 Fin5 refa799_inst.
Proof. unfold Equation4282. intro H. specialize (H F5_0 F5_0 F5_1). unfold magma_op, refa799_inst, refa799_op in H. discriminate H. Qed.

Lemma refa799_not4314 : ~ @Equation4314 Fin5 refa799_inst.
Proof. unfold Equation4314. intro H. specialize (H F5_1 F5_0). unfold magma_op, refa799_inst, refa799_op in H. discriminate H. Qed.

(** ---- refa8 (Fin6) ---- *)

Definition refa8_op (x y : Fin6) : Fin6 :=
  match x, y with
  | F6_0, F6_0 => F6_1 | F6_0, F6_1 => F6_2 | F6_0, F6_2 => F6_3 | F6_0, F6_3 => F6_0 | F6_0, F6_4 => F6_5 | F6_0, F6_5 => F6_4
  | F6_1, F6_0 => F6_2 | F6_1, F6_1 => F6_1 | F6_1, F6_2 => F6_4 | F6_1, F6_3 => F6_5 | F6_1, F6_4 => F6_0 | F6_1, F6_5 => F6_3
  | F6_2, F6_0 => F6_5 | F6_2, F6_1 => F6_4 | F6_2, F6_2 => F6_1 | F6_2, F6_3 => F6_2 | F6_2, F6_4 => F6_3 | F6_2, F6_5 => F6_0
  | F6_3, F6_0 => F6_4 | F6_3, F6_1 => F6_5 | F6_3, F6_2 => F6_0 | F6_3, F6_3 => F6_3 | F6_3, F6_4 => F6_2 | F6_3, F6_5 => F6_1
  | F6_4, F6_0 => F6_3 | F6_4, F6_1 => F6_0 | F6_4, F6_2 => F6_5 | F6_4, F6_3 => F6_4 | F6_4, F6_4 => F6_1 | F6_4, F6_5 => F6_2
  | F6_5, F6_0 => F6_0 | F6_5, F6_1 => F6_3 | F6_5, F6_2 => F6_2 | F6_5, F6_3 => F6_1 | F6_5, F6_4 => F6_4 | F6_5, F6_5 => F6_5
  end.

#[local] Instance refa8_inst : Magma Fin6 := {| magma_op := refa8_op |}.

Lemma refa8_sat669 : @Equation669 Fin6 refa8_inst.
Proof. unfold Equation669, magma_op, refa8_inst, refa8_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa8_not1426 : ~ @Equation1426 Fin6 refa8_inst.
Proof. unfold Equation1426. intro H. specialize (H F6_0). unfold magma_op, refa8_inst, refa8_op in H. discriminate H. Qed.

Lemma refa8_not2128 : ~ @Equation2128 Fin6 refa8_inst.
Proof. unfold Equation2128. intro H. specialize (H F6_0 F6_0). unfold magma_op, refa8_inst, refa8_op in H. discriminate H. Qed.

Lemma refa8_not2291 : ~ @Equation2291 Fin6 refa8_inst.
Proof. unfold Equation2291. intro H. specialize (H F6_0 F6_0). unfold magma_op, refa8_inst, refa8_op in H. discriminate H. Qed.

Lemma refa8_not2534 : ~ @Equation2534 Fin6 refa8_inst.
Proof. unfold Equation2534. intro H. specialize (H F6_0 F6_0). unfold magma_op, refa8_inst, refa8_op in H. discriminate H. Qed.

Lemma refa8_not2940 : ~ @Equation2940 Fin6 refa8_inst.
Proof. unfold Equation2940. intro H. specialize (H F6_0 F6_1). unfold magma_op, refa8_inst, refa8_op in H. discriminate H. Qed.

Lemma refa8_not2947 : ~ @Equation2947 Fin6 refa8_inst.
Proof. unfold Equation2947. intro H. specialize (H F6_0 F6_1). unfold magma_op, refa8_inst, refa8_op in H. discriminate H. Qed.

Lemma refa8_not3150 : ~ @Equation3150 Fin6 refa8_inst.
Proof. unfold Equation3150. intro H. specialize (H F6_0 F6_1). unfold magma_op, refa8_inst, refa8_op in H. discriminate H. Qed.

Lemma refa8_not3472 : ~ @Equation3472 Fin6 refa8_inst.
Proof. unfold Equation3472. intro H. specialize (H F6_0 F6_0). unfold magma_op, refa8_inst, refa8_op in H. discriminate H. Qed.

Lemma refa8_not3862 : ~ @Equation3862 Fin6 refa8_inst.
Proof. unfold Equation3862. intro H. specialize (H F6_0). unfold magma_op, refa8_inst, refa8_op in H. discriminate H. Qed.

Lemma refa8_not4065 : ~ @Equation4065 Fin6 refa8_inst.
Proof. unfold Equation4065. intro H. specialize (H F6_0). unfold magma_op, refa8_inst, refa8_op in H. discriminate H. Qed.

Lemma refa8_not4273 : ~ @Equation4273 Fin6 refa8_inst.
Proof. unfold Equation4273. intro H. specialize (H F6_0 F6_1). unfold magma_op, refa8_inst, refa8_op in H. discriminate H. Qed.

Lemma refa8_not4647 : ~ @Equation4647 Fin6 refa8_inst.
Proof. unfold Equation4647. intro H. specialize (H F6_0 F6_0 F6_1). unfold magma_op, refa8_inst, refa8_op in H. discriminate H. Qed.

(** ---- refa80 (Fin3) ---- *)

Definition refa80_op (x y : Fin3) : Fin3 :=
  match x, y with
  | F3_0, F3_0 => F3_0 | F3_0, F3_1 => F3_0 | F3_0, F3_2 => F3_0
  | F3_1, F3_0 => F3_2 | F3_1, F3_1 => F3_2 | F3_1, F3_2 => F3_1
  | F3_2, F3_0 => F3_1 | F3_2, F3_1 => F3_2 | F3_2, F3_2 => F3_1
  end.

#[local] Instance refa80_inst : Magma Fin3 := {| magma_op := refa80_op |}.

Lemma refa80_sat2056 : @Equation2056 Fin3 refa80_inst.
Proof. unfold Equation2056, magma_op, refa80_inst, refa80_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa80_sat2070 : @Equation2070 Fin3 refa80_inst.
Proof. unfold Equation2070, magma_op, refa80_inst, refa80_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa80_not2043 : ~ @Equation2043 Fin3 refa80_inst.
Proof. unfold Equation2043. intro H. specialize (H F3_1 F3_0). unfold magma_op, refa80_inst, refa80_op in H. discriminate H. Qed.

Lemma refa80_not2097 : ~ @Equation2097 Fin3 refa80_inst.
Proof. unfold Equation2097. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa80_inst, refa80_op in H. discriminate H. Qed.

Lemma refa80_not2644 : ~ @Equation2644 Fin3 refa80_inst.
Proof. unfold Equation2644. intro H. specialize (H F3_1). unfold magma_op, refa80_inst, refa80_op in H. discriminate H. Qed.

Lemma refa80_not2847 : ~ @Equation2847 Fin3 refa80_inst.
Proof. unfold Equation2847. intro H. specialize (H F3_1). unfold magma_op, refa80_inst, refa80_op in H. discriminate H. Qed.

Lemma refa80_not3255 : ~ @Equation3255 Fin3 refa80_inst.
Proof. unfold Equation3255. intro H. specialize (H F3_1 F3_0). unfold magma_op, refa80_inst, refa80_op in H. discriminate H. Qed.

Lemma refa80_not3271 : ~ @Equation3271 Fin3 refa80_inst.
Proof. unfold Equation3271. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa80_inst, refa80_op in H. discriminate H. Qed.

Lemma refa80_not3278 : ~ @Equation3278 Fin3 refa80_inst.
Proof. unfold Equation3278. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa80_inst, refa80_op in H. discriminate H. Qed.

Lemma refa80_not3309 : ~ @Equation3309 Fin3 refa80_inst.
Proof. unfold Equation3309. intro H. specialize (H F3_1 F3_0). unfold magma_op, refa80_inst, refa80_op in H. discriminate H. Qed.

Lemma refa80_not3326 : ~ @Equation3326 Fin3 refa80_inst.
Proof. unfold Equation3326. intro H. specialize (H F3_1 F3_2 F3_0). unfold magma_op, refa80_inst, refa80_op in H. discriminate H. Qed.

Lemma refa80_not3334 : ~ @Equation3334 Fin3 refa80_inst.
Proof. unfold Equation3334. intro H. specialize (H F3_1 F3_0 F3_2). unfold magma_op, refa80_inst, refa80_op in H. discriminate H. Qed.

Lemma refa80_not3346 : ~ @Equation3346 Fin3 refa80_inst.
Proof. unfold Equation3346. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa80_inst, refa80_op in H. discriminate H. Qed.

Lemma refa80_not3353 : ~ @Equation3353 Fin3 refa80_inst.
Proof. unfold Equation3353. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa80_inst, refa80_op in H. discriminate H. Qed.

Lemma refa80_not3456 : ~ @Equation3456 Fin3 refa80_inst.
Proof. unfold Equation3456. intro H. specialize (H F3_1). unfold magma_op, refa80_inst, refa80_op in H. discriminate H. Qed.

Lemma refa80_not3887 : ~ @Equation3887 Fin3 refa80_inst.
Proof. unfold Equation3887. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa80_inst, refa80_op in H. discriminate H. Qed.

Lemma refa80_not3955 : ~ @Equation3955 Fin3 refa80_inst.
Proof. unfold Equation3955. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa80_inst, refa80_op in H. discriminate H. Qed.

Lemma refa80_not3962 : ~ @Equation3962 Fin3 refa80_inst.
Proof. unfold Equation3962. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa80_inst, refa80_op in H. discriminate H. Qed.

Lemma refa80_not4090 : ~ @Equation4090 Fin3 refa80_inst.
Proof. unfold Equation4090. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa80_inst, refa80_op in H. discriminate H. Qed.

Lemma refa80_not4165 : ~ @Equation4165 Fin3 refa80_inst.
Proof. unfold Equation4165. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa80_inst, refa80_op in H. discriminate H. Qed.

Lemma refa80_not4269 : ~ @Equation4269 Fin3 refa80_inst.
Proof. unfold Equation4269. intro H. specialize (H F3_1 F3_0). unfold magma_op, refa80_inst, refa80_op in H. discriminate H. Qed.

Lemma refa80_not4275 : ~ @Equation4275 Fin3 refa80_inst.
Proof. unfold Equation4275. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa80_inst, refa80_op in H. discriminate H. Qed.

Lemma refa80_not4284 : ~ @Equation4284 Fin3 refa80_inst.
Proof. unfold Equation4284. intro H. specialize (H F3_1 F3_0). unfold magma_op, refa80_inst, refa80_op in H. discriminate H. Qed.

Lemma refa80_not4320 : ~ @Equation4320 Fin3 refa80_inst.
Proof. unfold Equation4320. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa80_inst, refa80_op in H. discriminate H. Qed.

(** ---- refa800 (Fin9) ---- *)

Definition refa800_op (x y : Fin9) : Fin9 :=
  match x, y with
  | F9_0, F9_0 => F9_1 | F9_0, F9_1 => F9_2 | F9_0, F9_2 => F9_0 | F9_0, F9_3 => F9_5 | F9_0, F9_4 => F9_1 | F9_0, F9_5 => F9_7 | F9_0, F9_6 => F9_0 | F9_0, F9_7 => F9_3 | F9_0, F9_8 => F9_4
  | F9_1, F9_0 => F9_4 | F9_1, F9_1 => F9_5 | F9_1, F9_2 => F9_0 | F9_1, F9_3 => F9_1 | F9_1, F9_4 => F9_2 | F9_1, F9_5 => F9_6 | F9_1, F9_6 => F9_5 | F9_1, F9_7 => F9_8 | F9_1, F9_8 => F9_5
  | F9_2, F9_0 => F9_1 | F9_2, F9_1 => F9_4 | F9_2, F9_2 => F9_1 | F9_2, F9_3 => F9_7 | F9_2, F9_4 => F9_0 | F9_2, F9_5 => F9_3 | F9_2, F9_6 => F9_2 | F9_2, F9_7 => F9_5 | F9_2, F9_8 => F9_0
  | F9_3, F9_0 => F9_7 | F9_3, F9_1 => F9_6 | F9_3, F9_2 => F9_3 | F9_3, F9_3 => F9_0 | F9_3, F9_4 => F9_5 | F9_3, F9_5 => F9_0 | F9_3, F9_6 => F9_8 | F9_3, F9_7 => F9_7 | F9_3, F9_8 => F9_1
  | F9_4, F9_0 => F9_0 | F9_4, F9_1 => F9_0 | F9_4, F9_2 => F9_1 | F9_4, F9_3 => F9_3 | F9_4, F9_4 => F9_1 | F9_4, F9_5 => F9_5 | F9_4, F9_6 => F9_4 | F9_4, F9_7 => F9_7 | F9_4, F9_8 => F9_2
  | F9_5, F9_0 => F9_3 | F9_5, F9_1 => F9_8 | F9_5, F9_2 => F9_5 | F9_5, F9_3 => F9_7 | F9_5, F9_4 => F9_7 | F9_5, F9_5 => F9_0 | F9_5, F9_6 => F9_1 | F9_5, F9_7 => F9_0 | F9_5, F9_8 => F9_6
  | F9_6, F9_0 => F9_2 | F9_6, F9_1 => F9_5 | F9_6, F9_2 => F9_4 | F9_6, F9_3 => F9_6 | F9_6, F9_4 => F9_0 | F9_6, F9_5 => F9_8 | F9_6, F9_6 => F9_5 | F9_6, F9_7 => F9_1 | F9_6, F9_8 => F9_5
  | F9_7, F9_0 => F9_5 | F9_7, F9_1 => F9_1 | F9_7, F9_2 => F9_7 | F9_7, F9_3 => F9_0 | F9_7, F9_4 => F9_3 | F9_7, F9_5 => F9_7 | F9_7, F9_6 => F9_6 | F9_7, F9_7 => F9_0 | F9_7, F9_8 => F9_8
  | F9_8, F9_0 => F9_0 | F9_8, F9_1 => F9_5 | F9_8, F9_2 => F9_2 | F9_8, F9_3 => F9_8 | F9_8, F9_4 => F9_4 | F9_8, F9_5 => F9_1 | F9_8, F9_6 => F9_5 | F9_8, F9_7 => F9_6 | F9_8, F9_8 => F9_5
  end.

#[local] Instance refa800_inst : Magma Fin9 := {| magma_op := refa800_op |}.

Lemma refa800_sat3545 : @Equation3545 Fin9 refa800_inst.
Proof. unfold Equation3545, magma_op, refa800_inst, refa800_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa800_sat3964 : @Equation3964 Fin9 refa800_inst.
Proof. unfold Equation3964, magma_op, refa800_inst, refa800_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa800_not3253 : ~ @Equation3253 Fin9 refa800_inst.
Proof. unfold Equation3253. intro H. specialize (H F9_0). unfold magma_op, refa800_inst, refa800_op in H. discriminate H. Qed.

Lemma refa800_not3509 : ~ @Equation3509 Fin9 refa800_inst.
Proof. unfold Equation3509. intro H. specialize (H F9_0 F9_1). unfold magma_op, refa800_inst, refa800_op in H. discriminate H. Qed.

Lemma refa800_not3511 : ~ @Equation3511 Fin9 refa800_inst.
Proof. unfold Equation3511. intro H. specialize (H F9_0 F9_2). unfold magma_op, refa800_inst, refa800_op in H. discriminate H. Qed.

Lemma refa800_not3518 : ~ @Equation3518 Fin9 refa800_inst.
Proof. unfold Equation3518. intro H. specialize (H F9_0 F9_1). unfold magma_op, refa800_inst, refa800_op in H. discriminate H. Qed.

Lemma refa800_not3522 : ~ @Equation3522 Fin9 refa800_inst.
Proof. unfold Equation3522. intro H. specialize (H F9_0 F9_1). unfold magma_op, refa800_inst, refa800_op in H. discriminate H. Qed.

Lemma refa800_not3549 : ~ @Equation3549 Fin9 refa800_inst.
Proof. unfold Equation3549. intro H. specialize (H F9_0 F9_2). unfold magma_op, refa800_inst, refa800_op in H. discriminate H. Qed.

Lemma refa800_not3558 : ~ @Equation3558 Fin9 refa800_inst.
Proof. unfold Equation3558. intro H. specialize (H F9_0 F9_1). unfold magma_op, refa800_inst, refa800_op in H. discriminate H. Qed.

Lemma refa800_not3659 : ~ @Equation3659 Fin9 refa800_inst.
Proof. unfold Equation3659. intro H. specialize (H F9_0). unfold magma_op, refa800_inst, refa800_op in H. discriminate H. Qed.

Lemma refa800_not4065 : ~ @Equation4065 Fin9 refa800_inst.
Proof. unfold Equation4065. intro H. specialize (H F9_0). unfold magma_op, refa800_inst, refa800_op in H. discriminate H. Qed.

(** ---- refa801 (Fin6) ---- *)

Definition refa801_op (x y : Fin6) : Fin6 :=
  match x, y with
  | F6_0, F6_0 => F6_4 | F6_0, F6_1 => F6_1 | F6_0, F6_2 => F6_4 | F6_0, F6_3 => F6_3 | F6_0, F6_4 => F6_0 | F6_0, F6_5 => F6_2
  | F6_1, F6_0 => F6_3 | F6_1, F6_1 => F6_2 | F6_1, F6_2 => F6_1 | F6_1, F6_3 => F6_2 | F6_1, F6_4 => F6_4 | F6_1, F6_5 => F6_5
  | F6_2, F6_0 => F6_4 | F6_2, F6_1 => F6_3 | F6_2, F6_2 => F6_4 | F6_2, F6_3 => F6_1 | F6_2, F6_4 => F6_2 | F6_2, F6_5 => F6_0
  | F6_3, F6_0 => F6_1 | F6_3, F6_1 => F6_2 | F6_3, F6_2 => F6_3 | F6_3, F6_3 => F6_2 | F6_3, F6_4 => F6_5 | F6_3, F6_5 => F6_4
  | F6_4, F6_0 => F6_2 | F6_4, F6_1 => F6_5 | F6_4, F6_2 => F6_0 | F6_4, F6_3 => F6_4 | F6_4, F6_4 => F6_3 | F6_4, F6_5 => F6_3
  | F6_5, F6_0 => F6_0 | F6_5, F6_1 => F6_4 | F6_5, F6_2 => F6_2 | F6_5, F6_3 => F6_5 | F6_5, F6_4 => F6_3 | F6_5, F6_5 => F6_3
  end.

#[local] Instance refa801_inst : Magma Fin6 := {| magma_op := refa801_op |}.

Lemma refa801_sat3545 : @Equation3545 Fin6 refa801_inst.
Proof. unfold Equation3545, magma_op, refa801_inst, refa801_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa801_sat4167 : @Equation4167 Fin6 refa801_inst.
Proof. unfold Equation4167, magma_op, refa801_inst, refa801_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa801_not3306 : ~ @Equation3306 Fin6 refa801_inst.
Proof. unfold Equation3306. intro H. specialize (H F6_0 F6_5). unfold magma_op, refa801_inst, refa801_op in H. discriminate H. Qed.

Lemma refa801_not3308 : ~ @Equation3308 Fin6 refa801_inst.
Proof. unfold Equation3308. intro H. specialize (H F6_0 F6_1). unfold magma_op, refa801_inst, refa801_op in H. discriminate H. Qed.

Lemma refa801_not3315 : ~ @Equation3315 Fin6 refa801_inst.
Proof. unfold Equation3315. intro H. specialize (H F6_0 F6_1). unfold magma_op, refa801_inst, refa801_op in H. discriminate H. Qed.

Lemma refa801_not3342 : ~ @Equation3342 Fin6 refa801_inst.
Proof. unfold Equation3342. intro H. specialize (H F6_0 F6_1). unfold magma_op, refa801_inst, refa801_op in H. discriminate H. Qed.

Lemma refa801_not3346 : ~ @Equation3346 Fin6 refa801_inst.
Proof. unfold Equation3346. intro H. specialize (H F6_0 F6_1). unfold magma_op, refa801_inst, refa801_op in H. discriminate H. Qed.

Lemma refa801_not3353 : ~ @Equation3353 Fin6 refa801_inst.
Proof. unfold Equation3353. intro H. specialize (H F6_2 F6_1). unfold magma_op, refa801_inst, refa801_op in H. discriminate H. Qed.

Lemma refa801_not3509 : ~ @Equation3509 Fin6 refa801_inst.
Proof. unfold Equation3509. intro H. specialize (H F6_0 F6_1). unfold magma_op, refa801_inst, refa801_op in H. discriminate H. Qed.

Lemma refa801_not3511 : ~ @Equation3511 Fin6 refa801_inst.
Proof. unfold Equation3511. intro H. specialize (H F6_0 F6_1). unfold magma_op, refa801_inst, refa801_op in H. discriminate H. Qed.

Lemma refa801_not3518 : ~ @Equation3518 Fin6 refa801_inst.
Proof. unfold Equation3518. intro H. specialize (H F6_0 F6_5). unfold magma_op, refa801_inst, refa801_op in H. discriminate H. Qed.

Lemma refa801_not3522 : ~ @Equation3522 Fin6 refa801_inst.
Proof. unfold Equation3522. intro H. specialize (H F6_0 F6_1). unfold magma_op, refa801_inst, refa801_op in H. discriminate H. Qed.

Lemma refa801_not3549 : ~ @Equation3549 Fin6 refa801_inst.
Proof. unfold Equation3549. intro H. specialize (H F6_0 F6_4). unfold magma_op, refa801_inst, refa801_op in H. discriminate H. Qed.

Lemma refa801_not3556 : ~ @Equation3556 Fin6 refa801_inst.
Proof. unfold Equation3556. intro H. specialize (H F6_2 F6_1). unfold magma_op, refa801_inst, refa801_op in H. discriminate H. Qed.

Lemma refa801_not3558 : ~ @Equation3558 Fin6 refa801_inst.
Proof. unfold Equation3558. intro H. specialize (H F6_0 F6_1). unfold magma_op, refa801_inst, refa801_op in H. discriminate H. Qed.

Lemma refa801_not3659 : ~ @Equation3659 Fin6 refa801_inst.
Proof. unfold Equation3659. intro H. specialize (H F6_0). unfold magma_op, refa801_inst, refa801_op in H. discriminate H. Qed.

Lemma refa801_not3917 : ~ @Equation3917 Fin6 refa801_inst.
Proof. unfold Equation3917. intro H. specialize (H F6_0 F6_1). unfold magma_op, refa801_inst, refa801_op in H. discriminate H. Qed.

Lemma refa801_not3924 : ~ @Equation3924 Fin6 refa801_inst.
Proof. unfold Equation3924. intro H. specialize (H F6_0 F6_4). unfold magma_op, refa801_inst, refa801_op in H. discriminate H. Qed.

Lemma refa801_not3928 : ~ @Equation3928 Fin6 refa801_inst.
Proof. unfold Equation3928. intro H. specialize (H F6_0 F6_1). unfold magma_op, refa801_inst, refa801_op in H. discriminate H. Qed.

Lemma refa801_not3951 : ~ @Equation3951 Fin6 refa801_inst.
Proof. unfold Equation3951. intro H. specialize (H F6_0 F6_1). unfold magma_op, refa801_inst, refa801_op in H. discriminate H. Qed.

Lemma refa801_not3955 : ~ @Equation3955 Fin6 refa801_inst.
Proof. unfold Equation3955. intro H. specialize (H F6_0 F6_1). unfold magma_op, refa801_inst, refa801_op in H. discriminate H. Qed.

Lemma refa801_not3962 : ~ @Equation3962 Fin6 refa801_inst.
Proof. unfold Equation3962. intro H. specialize (H F6_0 F6_1). unfold magma_op, refa801_inst, refa801_op in H. discriminate H. Qed.

Lemma refa801_not3964 : ~ @Equation3964 Fin6 refa801_inst.
Proof. unfold Equation3964. intro H. specialize (H F6_0 F6_1). unfold magma_op, refa801_inst, refa801_op in H. discriminate H. Qed.

Lemma refa801_not4118 : ~ @Equation4118 Fin6 refa801_inst.
Proof. unfold Equation4118. intro H. specialize (H F6_0 F6_1). unfold magma_op, refa801_inst, refa801_op in H. discriminate H. Qed.

Lemma refa801_not4120 : ~ @Equation4120 Fin6 refa801_inst.
Proof. unfold Equation4120. intro H. specialize (H F6_0 F6_1). unfold magma_op, refa801_inst, refa801_op in H. discriminate H. Qed.

Lemma refa801_not4127 : ~ @Equation4127 Fin6 refa801_inst.
Proof. unfold Equation4127. intro H. specialize (H F6_0 F6_4). unfold magma_op, refa801_inst, refa801_op in H. discriminate H. Qed.

Lemma refa801_not4131 : ~ @Equation4131 Fin6 refa801_inst.
Proof. unfold Equation4131. intro H. specialize (H F6_0 F6_1). unfold magma_op, refa801_inst, refa801_op in H. discriminate H. Qed.

Lemma refa801_not4158 : ~ @Equation4158 Fin6 refa801_inst.
Proof. unfold Equation4158. intro H. specialize (H F6_0 F6_1). unfold magma_op, refa801_inst, refa801_op in H. discriminate H. Qed.

Lemma refa801_not4165 : ~ @Equation4165 Fin6 refa801_inst.
Proof. unfold Equation4165. intro H. specialize (H F6_0 F6_1). unfold magma_op, refa801_inst, refa801_op in H. discriminate H. Qed.

Lemma refa801_not4283 : ~ @Equation4283 Fin6 refa801_inst.
Proof. unfold Equation4283. intro H. specialize (H F6_0 F6_1). unfold magma_op, refa801_inst, refa801_op in H. discriminate H. Qed.

Lemma refa801_not4290 : ~ @Equation4290 Fin6 refa801_inst.
Proof. unfold Equation4290. intro H. specialize (H F6_0 F6_1). unfold magma_op, refa801_inst, refa801_op in H. discriminate H. Qed.

Lemma refa801_not4320 : ~ @Equation4320 Fin6 refa801_inst.
Proof. unfold Equation4320. intro H. specialize (H F6_0 F6_1). unfold magma_op, refa801_inst, refa801_op in H. discriminate H. Qed.

Lemma refa801_not4380 : ~ @Equation4380 Fin6 refa801_inst.
Proof. unfold Equation4380. intro H. specialize (H F6_0). unfold magma_op, refa801_inst, refa801_op in H. discriminate H. Qed.

Lemma refa801_not4598 : ~ @Equation4598 Fin6 refa801_inst.
Proof. unfold Equation4598. intro H. specialize (H F6_0 F6_1). unfold magma_op, refa801_inst, refa801_op in H. discriminate H. Qed.

Lemma refa801_not4605 : ~ @Equation4605 Fin6 refa801_inst.
Proof. unfold Equation4605. intro H. specialize (H F6_0 F6_1). unfold magma_op, refa801_inst, refa801_op in H. discriminate H. Qed.

Lemma refa801_not4635 : ~ @Equation4635 Fin6 refa801_inst.
Proof. unfold Equation4635. intro H. specialize (H F6_0 F6_1). unfold magma_op, refa801_inst, refa801_op in H. discriminate H. Qed.

(** ---- refa802 (Fin5) ---- *)

Definition refa802_op (x y : Fin5) : Fin5 :=
  match x, y with
  | F5_0, F5_0 => F5_1 | F5_0, F5_1 => F5_2 | F5_0, F5_2 => F5_1 | F5_0, F5_3 => F5_1 | F5_0, F5_4 => F5_2
  | F5_1, F5_0 => F5_2 | F5_1, F5_1 => F5_3 | F5_1, F5_2 => F5_3 | F5_1, F5_3 => F5_2 | F5_1, F5_4 => F5_4
  | F5_2, F5_0 => F5_2 | F5_2, F5_1 => F5_3 | F5_2, F5_2 => F5_4 | F5_2, F5_3 => F5_1 | F5_2, F5_4 => F5_4
  | F5_3, F5_0 => F5_1 | F5_3, F5_1 => F5_2 | F5_3, F5_2 => F5_1 | F5_3, F5_3 => F5_1 | F5_3, F5_4 => F5_2
  | F5_4, F5_0 => F5_1 | F5_4, F5_1 => F5_2 | F5_4, F5_2 => F5_4 | F5_4, F5_3 => F5_2 | F5_4, F5_4 => F5_2
  end.

#[local] Instance refa802_inst : Magma Fin5 := {| magma_op := refa802_op |}.

Lemma refa802_sat3546 : @Equation3546 Fin5 refa802_inst.
Proof. unfold Equation3546, magma_op, refa802_inst, refa802_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa802_not4065 : ~ @Equation4065 Fin5 refa802_inst.
Proof. unfold Equation4065. intro H. specialize (H F5_0). unfold magma_op, refa802_inst, refa802_op in H. discriminate H. Qed.

(** ---- refa803 (Fin5) ---- *)

Definition refa803_op (x y : Fin5) : Fin5 :=
  match x, y with
  | F5_0, F5_0 => F5_4 | F5_0, F5_1 => F5_2 | F5_0, F5_2 => F5_2 | F5_0, F5_3 => F5_3 | F5_0, F5_4 => F5_4
  | F5_1, F5_0 => F5_2 | F5_1, F5_1 => F5_3 | F5_1, F5_2 => F5_2 | F5_1, F5_3 => F5_3 | F5_1, F5_4 => F5_4
  | F5_2, F5_0 => F5_3 | F5_2, F5_1 => F5_3 | F5_2, F5_2 => F5_2 | F5_2, F5_3 => F5_3 | F5_2, F5_4 => F5_4
  | F5_3, F5_0 => F5_2 | F5_3, F5_1 => F5_3 | F5_3, F5_2 => F5_2 | F5_3, F5_3 => F5_3 | F5_3, F5_4 => F5_4
  | F5_4, F5_0 => F5_4 | F5_4, F5_1 => F5_2 | F5_4, F5_2 => F5_2 | F5_4, F5_3 => F5_3 | F5_4, F5_4 => F5_4
  end.

#[local] Instance refa803_inst : Magma Fin5 := {| magma_op := refa803_op |}.

Lemma refa803_sat3583 : @Equation3583 Fin5 refa803_inst.
Proof. unfold Equation3583, magma_op, refa803_inst, refa803_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa803_not4128 : ~ @Equation4128 Fin5 refa803_inst.
Proof. unfold Equation4128. intro H. specialize (H F5_0 F5_1). unfold magma_op, refa803_inst, refa803_op in H. discriminate H. Qed.

(** ---- refa804 (Fin5) ---- *)

Definition refa804_op (x y : Fin5) : Fin5 :=
  match x, y with
  | F5_0, F5_0 => F5_4 | F5_0, F5_1 => F5_2 | F5_0, F5_2 => F5_2 | F5_0, F5_3 => F5_3 | F5_0, F5_4 => F5_4
  | F5_1, F5_0 => F5_3 | F5_1, F5_1 => F5_4 | F5_1, F5_2 => F5_2 | F5_1, F5_3 => F5_3 | F5_1, F5_4 => F5_4
  | F5_2, F5_0 => F5_3 | F5_2, F5_1 => F5_3 | F5_2, F5_2 => F5_2 | F5_2, F5_3 => F5_3 | F5_2, F5_4 => F5_4
  | F5_3, F5_0 => F5_4 | F5_3, F5_1 => F5_2 | F5_3, F5_2 => F5_2 | F5_3, F5_3 => F5_3 | F5_3, F5_4 => F5_4
  | F5_4, F5_0 => F5_4 | F5_4, F5_1 => F5_4 | F5_4, F5_2 => F5_2 | F5_4, F5_3 => F5_3 | F5_4, F5_4 => F5_4
  end.

#[local] Instance refa804_inst : Magma Fin5 := {| magma_op := refa804_op |}.

Lemma refa804_sat3600 : @Equation3600 Fin5 refa804_inst.
Proof. unfold Equation3600, magma_op, refa804_inst, refa804_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa804_not4155 : ~ @Equation4155 Fin5 refa804_inst.
Proof. unfold Equation4155. intro H. specialize (H F5_0 F5_1). unfold magma_op, refa804_inst, refa804_op in H. discriminate H. Qed.

(** ---- refa805 (Fin6) ---- *)

Definition refa805_op (x y : Fin6) : Fin6 :=
  match x, y with
  | F6_0, F6_0 => F6_2 | F6_0, F6_1 => F6_4 | F6_0, F6_2 => F6_2 | F6_0, F6_3 => F6_4 | F6_0, F6_4 => F6_3 | F6_0, F6_5 => F6_3
  | F6_1, F6_0 => F6_5 | F6_1, F6_1 => F6_3 | F6_1, F6_2 => F6_5 | F6_1, F6_3 => F6_3 | F6_1, F6_4 => F6_0 | F6_1, F6_5 => F6_2
  | F6_2, F6_0 => F6_2 | F6_2, F6_1 => F6_4 | F6_2, F6_2 => F6_2 | F6_2, F6_3 => F6_4 | F6_2, F6_4 => F6_3 | F6_2, F6_5 => F6_3
  | F6_3, F6_0 => F6_4 | F6_3, F6_1 => F6_3 | F6_3, F6_2 => F6_4 | F6_3, F6_3 => F6_3 | F6_3, F6_4 => F6_2 | F6_3, F6_5 => F6_0
  | F6_4, F6_0 => F6_3 | F6_4, F6_1 => F6_0 | F6_4, F6_2 => F6_3 | F6_4, F6_3 => F6_2 | F6_4, F6_4 => F6_4 | F6_4, F6_5 => F6_4
  | F6_5, F6_0 => F6_1 | F6_5, F6_1 => F6_2 | F6_5, F6_2 => F6_1 | F6_5, F6_3 => F6_0 | F6_5, F6_4 => F6_5 | F6_5, F6_5 => F6_4
  end.

#[local] Instance refa805_inst : Magma Fin6 := {| magma_op := refa805_op |}.

Lemma refa805_sat365 : @Equation365 Fin6 refa805_inst.
Proof. unfold Equation365, magma_op, refa805_inst, refa805_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa805_not4091 : ~ @Equation4091 Fin6 refa805_inst.
Proof. unfold Equation4091. intro H. specialize (H F6_0 F6_1). unfold magma_op, refa805_inst, refa805_op in H. discriminate H. Qed.

(** ---- refa806 (Fin5) ---- *)

Definition refa806_op (x y : Fin5) : Fin5 :=
  match x, y with
  | F5_0, F5_0 => F5_2 | F5_0, F5_1 => F5_3 | F5_0, F5_2 => F5_2 | F5_0, F5_3 => F5_2 | F5_0, F5_4 => F5_2
  | F5_1, F5_0 => F5_4 | F5_1, F5_1 => F5_4 | F5_1, F5_2 => F5_4 | F5_1, F5_3 => F5_4 | F5_1, F5_4 => F5_4
  | F5_2, F5_0 => F5_2 | F5_2, F5_1 => F5_3 | F5_2, F5_2 => F5_2 | F5_2, F5_3 => F5_0 | F5_2, F5_4 => F5_2
  | F5_3, F5_0 => F5_2 | F5_3, F5_1 => F5_3 | F5_3, F5_2 => F5_2 | F5_3, F5_3 => F5_2 | F5_3, F5_4 => F5_2
  | F5_4, F5_0 => F5_4 | F5_4, F5_1 => F5_4 | F5_4, F5_2 => F5_4 | F5_4, F5_3 => F5_4 | F5_4, F5_4 => F5_4
  end.

#[local] Instance refa806_inst : Magma Fin5 := {| magma_op := refa806_op |}.

Lemma refa806_sat3671 : @Equation3671 Fin5 refa806_inst.
Proof. unfold Equation3671, magma_op, refa806_inst, refa806_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa806_not3660 : ~ @Equation3660 Fin5 refa806_inst.
Proof. unfold Equation3660. intro H. specialize (H F5_0 F5_1). unfold magma_op, refa806_inst, refa806_op in H. discriminate H. Qed.

(** ---- refa807 (Fin5) ---- *)

Definition refa807_op (x y : Fin5) : Fin5 :=
  match x, y with
  | F5_0, F5_0 => F5_2 | F5_0, F5_1 => F5_3 | F5_0, F5_2 => F5_2 | F5_0, F5_3 => F5_2 | F5_0, F5_4 => F5_2
  | F5_1, F5_0 => F5_4 | F5_1, F5_1 => F5_4 | F5_1, F5_2 => F5_4 | F5_1, F5_3 => F5_4 | F5_1, F5_4 => F5_4
  | F5_2, F5_0 => F5_2 | F5_2, F5_1 => F5_0 | F5_2, F5_2 => F5_2 | F5_2, F5_3 => F5_2 | F5_2, F5_4 => F5_2
  | F5_3, F5_0 => F5_2 | F5_3, F5_1 => F5_3 | F5_3, F5_2 => F5_0 | F5_3, F5_3 => F5_2 | F5_3, F5_4 => F5_2
  | F5_4, F5_0 => F5_4 | F5_4, F5_1 => F5_4 | F5_4, F5_2 => F5_4 | F5_4, F5_3 => F5_4 | F5_4, F5_4 => F5_4
  end.

#[local] Instance refa807_inst : Magma Fin5 := {| magma_op := refa807_op |}.

Lemma refa807_sat3671 : @Equation3671 Fin5 refa807_inst.
Proof. unfold Equation3671, magma_op, refa807_inst, refa807_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa807_not3664 : ~ @Equation3664 Fin5 refa807_inst.
Proof. unfold Equation3664. intro H. specialize (H F5_0 F5_1). unfold magma_op, refa807_inst, refa807_op in H. discriminate H. Qed.

Lemma refa807_not4341 : ~ @Equation4341 Fin5 refa807_inst.
Proof. unfold Equation4341. intro H. specialize (H F5_3 F5_0 F5_1). unfold magma_op, refa807_inst, refa807_op in H. discriminate H. Qed.

(** ---- refa808 (Fin5) ---- *)

Definition refa808_op (x y : Fin5) : Fin5 :=
  match x, y with
  | F5_0, F5_0 => F5_2 | F5_0, F5_1 => F5_4 | F5_0, F5_2 => F5_2 | F5_0, F5_3 => F5_2 | F5_0, F5_4 => F5_4
  | F5_1, F5_0 => F5_3 | F5_1, F5_1 => F5_4 | F5_1, F5_2 => F5_3 | F5_1, F5_3 => F5_0 | F5_1, F5_4 => F5_4
  | F5_2, F5_0 => F5_2 | F5_2, F5_1 => F5_4 | F5_2, F5_2 => F5_2 | F5_2, F5_3 => F5_0 | F5_2, F5_4 => F5_4
  | F5_3, F5_0 => F5_2 | F5_3, F5_1 => F5_4 | F5_3, F5_2 => F5_2 | F5_3, F5_3 => F5_2 | F5_3, F5_4 => F5_4
  | F5_4, F5_0 => F5_2 | F5_4, F5_1 => F5_4 | F5_4, F5_2 => F5_2 | F5_4, F5_3 => F5_2 | F5_4, F5_4 => F5_4
  end.

#[local] Instance refa808_inst : Magma Fin5 := {| magma_op := refa808_op |}.

Lemma refa808_sat3698 : @Equation3698 Fin5 refa808_inst.
Proof. unfold Equation3698, magma_op, refa808_inst, refa808_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa808_not3661 : ~ @Equation3661 Fin5 refa808_inst.
Proof. unfold Equation3661. intro H. specialize (H F5_0 F5_1). unfold magma_op, refa808_inst, refa808_op in H. discriminate H. Qed.

Lemma refa808_not4590 : ~ @Equation4590 Fin5 refa808_inst.
Proof. unfold Equation4590. intro H. specialize (H F5_3 F5_1). unfold magma_op, refa808_inst, refa808_op in H. discriminate H. Qed.

(** ---- refa809 (Fin5) ---- *)

Definition refa809_op (x y : Fin5) : Fin5 :=
  match x, y with
  | F5_0, F5_0 => F5_2 | F5_0, F5_1 => F5_4 | F5_0, F5_2 => F5_3 | F5_0, F5_3 => F5_2 | F5_0, F5_4 => F5_4
  | F5_1, F5_0 => F5_0 | F5_1, F5_1 => F5_4 | F5_1, F5_2 => F5_3 | F5_1, F5_3 => F5_0 | F5_1, F5_4 => F5_4
  | F5_2, F5_0 => F5_2 | F5_2, F5_1 => F5_4 | F5_2, F5_2 => F5_2 | F5_2, F5_3 => F5_2 | F5_2, F5_4 => F5_4
  | F5_3, F5_0 => F5_2 | F5_3, F5_1 => F5_4 | F5_3, F5_2 => F5_2 | F5_3, F5_3 => F5_2 | F5_3, F5_4 => F5_4
  | F5_4, F5_0 => F5_2 | F5_4, F5_1 => F5_4 | F5_4, F5_2 => F5_2 | F5_4, F5_3 => F5_2 | F5_4, F5_4 => F5_4
  end.

#[local] Instance refa809_inst : Magma Fin5 := {| magma_op := refa809_op |}.

Lemma refa809_sat3698 : @Equation3698 Fin5 refa809_inst.
Proof. unfold Equation3698, magma_op, refa809_inst, refa809_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa809_not3674 : ~ @Equation3674 Fin5 refa809_inst.
Proof. unfold Equation3674. intro H. specialize (H F5_0 F5_1). unfold magma_op, refa809_inst, refa809_op in H. discriminate H. Qed.

(** ---- refa81 (Fin3) ---- *)

Definition refa81_op (x y : Fin3) : Fin3 :=
  match x, y with
  | F3_0, F3_0 => F3_0 | F3_0, F3_1 => F3_2 | F3_0, F3_2 => F3_1
  | F3_1, F3_0 => F3_0 | F3_1, F3_1 => F3_0 | F3_1, F3_2 => F3_1
  | F3_2, F3_0 => F3_1 | F3_2, F3_1 => F3_2 | F3_2, F3_2 => F3_0
  end.

#[local] Instance refa81_inst : Magma Fin3 := {| magma_op := refa81_op |}.

Lemma refa81_sat1738 : @Equation1738 Fin3 refa81_inst.
Proof. unfold Equation1738, magma_op, refa81_inst, refa81_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa81_not3253 : ~ @Equation3253 Fin3 refa81_inst.
Proof. unfold Equation3253. intro H. specialize (H F3_2). unfold magma_op, refa81_inst, refa81_op in H. discriminate H. Qed.

Lemma refa81_not3456 : ~ @Equation3456 Fin3 refa81_inst.
Proof. unfold Equation3456. intro H. specialize (H F3_1). unfold magma_op, refa81_inst, refa81_op in H. discriminate H. Qed.

Lemma refa81_not3862 : ~ @Equation3862 Fin3 refa81_inst.
Proof. unfold Equation3862. intro H. specialize (H F3_1). unfold magma_op, refa81_inst, refa81_op in H. discriminate H. Qed.

Lemma refa81_not4065 : ~ @Equation4065 Fin3 refa81_inst.
Proof. unfold Equation4065. intro H. specialize (H F3_1). unfold magma_op, refa81_inst, refa81_op in H. discriminate H. Qed.

Lemma refa81_not4269 : ~ @Equation4269 Fin3 refa81_inst.
Proof. unfold Equation4269. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa81_inst, refa81_op in H. discriminate H. Qed.

Lemma refa81_not4272 : ~ @Equation4272 Fin3 refa81_inst.
Proof. unfold Equation4272. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa81_inst, refa81_op in H. discriminate H. Qed.

Lemma refa81_not4275 : ~ @Equation4275 Fin3 refa81_inst.
Proof. unfold Equation4275. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa81_inst, refa81_op in H. discriminate H. Qed.

Lemma refa81_not4283 : ~ @Equation4283 Fin3 refa81_inst.
Proof. unfold Equation4283. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa81_inst, refa81_op in H. discriminate H. Qed.

Lemma refa81_not4284 : ~ @Equation4284 Fin3 refa81_inst.
Proof. unfold Equation4284. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa81_inst, refa81_op in H. discriminate H. Qed.

Lemma refa81_not4291 : ~ @Equation4291 Fin3 refa81_inst.
Proof. unfold Equation4291. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa81_inst, refa81_op in H. discriminate H. Qed.

Lemma refa81_not4314 : ~ @Equation4314 Fin3 refa81_inst.
Proof. unfold Equation4314. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa81_inst, refa81_op in H. discriminate H. Qed.

Lemma refa81_not4320 : ~ @Equation4320 Fin3 refa81_inst.
Proof. unfold Equation4320. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa81_inst, refa81_op in H. discriminate H. Qed.

Lemma refa81_not4380 : ~ @Equation4380 Fin3 refa81_inst.
Proof. unfold Equation4380. intro H. specialize (H F3_1). unfold magma_op, refa81_inst, refa81_op in H. discriminate H. Qed.

Lemma refa81_not4606 : ~ @Equation4606 Fin3 refa81_inst.
Proof. unfold Equation4606. intro H. specialize (H F3_1 F3_0). unfold magma_op, refa81_inst, refa81_op in H. discriminate H. Qed.

Lemma refa81_not4631 : ~ @Equation4631 Fin3 refa81_inst.
Proof. unfold Equation4631. intro H. specialize (H F3_0 F3_0 F3_1). unfold magma_op, refa81_inst, refa81_op in H. discriminate H. Qed.

Lemma refa81_not4635 : ~ @Equation4635 Fin3 refa81_inst.
Proof. unfold Equation4635. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa81_inst, refa81_op in H. discriminate H. Qed.

(** ---- refa810 (Fin5) ---- *)

Definition refa810_op (x y : Fin5) : Fin5 :=
  match x, y with
  | F5_0, F5_0 => F5_4 | F5_0, F5_1 => F5_2 | F5_0, F5_2 => F5_4 | F5_0, F5_3 => F5_2 | F5_0, F5_4 => F5_4
  | F5_1, F5_0 => F5_3 | F5_1, F5_1 => F5_4 | F5_1, F5_2 => F5_3 | F5_1, F5_3 => F5_4 | F5_1, F5_4 => F5_4
  | F5_2, F5_0 => F5_2 | F5_2, F5_1 => F5_2 | F5_2, F5_2 => F5_2 | F5_2, F5_3 => F5_2 | F5_2, F5_4 => F5_2
  | F5_3, F5_0 => F5_3 | F5_3, F5_1 => F5_3 | F5_3, F5_2 => F5_3 | F5_3, F5_3 => F5_3 | F5_3, F5_4 => F5_3
  | F5_4, F5_0 => F5_4 | F5_4, F5_1 => F5_4 | F5_4, F5_2 => F5_4 | F5_4, F5_3 => F5_4 | F5_4, F5_4 => F5_4
  end.

#[local] Instance refa810_inst : Magma Fin5 := {| magma_op := refa810_op |}.

Lemma refa810_sat3926 : @Equation3926 Fin5 refa810_inst.
Proof. unfold Equation3926, magma_op, refa810_inst, refa810_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa810_not3318 : ~ @Equation3318 Fin5 refa810_inst.
Proof. unfold Equation3318. intro H. specialize (H F5_0 F5_1). unfold magma_op, refa810_inst, refa810_op in H. discriminate H. Qed.

(** ---- refa811 (Fin5) ---- *)

Definition refa811_op (x y : Fin5) : Fin5 :=
  match x, y with
  | F5_0, F5_0 => F5_1 | F5_0, F5_1 => F5_2 | F5_0, F5_2 => F5_2 | F5_0, F5_3 => F5_1 | F5_0, F5_4 => F5_1
  | F5_1, F5_0 => F5_2 | F5_1, F5_1 => F5_3 | F5_1, F5_2 => F5_3 | F5_1, F5_3 => F5_2 | F5_1, F5_4 => F5_2
  | F5_2, F5_0 => F5_1 | F5_2, F5_1 => F5_3 | F5_2, F5_2 => F5_4 | F5_2, F5_3 => F5_1 | F5_2, F5_4 => F5_2
  | F5_3, F5_0 => F5_1 | F5_3, F5_1 => F5_2 | F5_3, F5_2 => F5_1 | F5_3, F5_3 => F5_1 | F5_3, F5_4 => F5_2
  | F5_4, F5_0 => F5_2 | F5_4, F5_1 => F5_2 | F5_4, F5_2 => F5_2 | F5_4, F5_3 => F5_2 | F5_4, F5_4 => F5_2
  end.

#[local] Instance refa811_inst : Magma Fin5 := {| magma_op := refa811_op |}.

Lemma refa811_sat3927 : @Equation3927 Fin5 refa811_inst.
Proof. unfold Equation3927, magma_op, refa811_inst, refa811_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa811_not3253 : ~ @Equation3253 Fin5 refa811_inst.
Proof. unfold Equation3253. intro H. specialize (H F5_0). unfold magma_op, refa811_inst, refa811_op in H. discriminate H. Qed.

Lemma refa811_not3917 : ~ @Equation3917 Fin5 refa811_inst.
Proof. unfold Equation3917. intro H. specialize (H F5_0 F5_1). unfold magma_op, refa811_inst, refa811_op in H. discriminate H. Qed.

(** ---- refa812 (Fin5) ---- *)

Definition refa812_op (x y : Fin5) : Fin5 :=
  match x, y with
  | F5_0, F5_0 => F5_2 | F5_0, F5_1 => F5_2 | F5_0, F5_2 => F5_2 | F5_0, F5_3 => F5_4 | F5_0, F5_4 => F5_2
  | F5_1, F5_0 => F5_3 | F5_1, F5_1 => F5_4 | F5_1, F5_2 => F5_3 | F5_1, F5_3 => F5_2 | F5_1, F5_4 => F5_4
  | F5_2, F5_0 => F5_2 | F5_2, F5_1 => F5_2 | F5_2, F5_2 => F5_2 | F5_2, F5_3 => F5_2 | F5_2, F5_4 => F5_2
  | F5_3, F5_0 => F5_3 | F5_3, F5_1 => F5_3 | F5_3, F5_2 => F5_3 | F5_3, F5_3 => F5_3 | F5_3, F5_4 => F5_3
  | F5_4, F5_0 => F5_4 | F5_4, F5_1 => F5_4 | F5_4, F5_2 => F5_4 | F5_4, F5_3 => F5_4 | F5_4, F5_4 => F5_4
  end.

#[local] Instance refa812_inst : Magma Fin5 := {| magma_op := refa812_op |}.

Lemma refa812_sat3929 : @Equation3929 Fin5 refa812_inst.
Proof. unfold Equation3929, magma_op, refa812_inst, refa812_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa812_not3316 : ~ @Equation3316 Fin5 refa812_inst.
Proof. unfold Equation3316. intro H. specialize (H F5_0 F5_1). unfold magma_op, refa812_inst, refa812_op in H. discriminate H. Qed.

(** ---- refa813 (Fin6) ---- *)

Definition refa813_op (x y : Fin6) : Fin6 :=
  match x, y with
  | F6_0, F6_0 => F6_1 | F6_0, F6_1 => F6_2 | F6_0, F6_2 => F6_3 | F6_0, F6_3 => F6_5 | F6_0, F6_4 => F6_2 | F6_0, F6_5 => F6_1
  | F6_1, F6_0 => F6_5 | F6_1, F6_1 => F6_4 | F6_1, F6_2 => F6_5 | F6_1, F6_3 => F6_1 | F6_1, F6_4 => F6_4 | F6_1, F6_5 => F6_2
  | F6_2, F6_0 => F6_1 | F6_2, F6_1 => F6_5 | F6_2, F6_2 => F6_3 | F6_2, F6_3 => F6_2 | F6_2, F6_4 => F6_2 | F6_2, F6_5 => F6_1
  | F6_3, F6_0 => F6_5 | F6_3, F6_1 => F6_1 | F6_3, F6_2 => F6_2 | F6_3, F6_3 => F6_3 | F6_3, F6_4 => F6_3 | F6_3, F6_5 => F6_5
  | F6_4, F6_0 => F6_2 | F6_4, F6_1 => F6_4 | F6_4, F6_2 => F6_2 | F6_4, F6_3 => F6_3 | F6_4, F6_4 => F6_4 | F6_4, F6_5 => F6_5
  | F6_5, F6_0 => F6_3 | F6_5, F6_1 => F6_2 | F6_5, F6_2 => F6_1 | F6_5, F6_3 => F6_5 | F6_5, F6_4 => F6_5 | F6_5, F6_5 => F6_3
  end.

#[local] Instance refa813_inst : Magma Fin6 := {| magma_op := refa813_op |}.

Lemma refa813_sat3951 : @Equation3951 Fin6 refa813_inst.
Proof. unfold Equation3951, magma_op, refa813_inst, refa813_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa813_not3253 : ~ @Equation3253 Fin6 refa813_inst.
Proof. unfold Equation3253. intro H. specialize (H F6_0). unfold magma_op, refa813_inst, refa813_op in H. discriminate H. Qed.

Lemma refa813_not3915 : ~ @Equation3915 Fin6 refa813_inst.
Proof. unfold Equation3915. intro H. specialize (H F6_0 F6_1). unfold magma_op, refa813_inst, refa813_op in H. discriminate H. Qed.

Lemma refa813_not4605 : ~ @Equation4605 Fin6 refa813_inst.
Proof. unfold Equation4605. intro H. specialize (H F6_0 F6_1). unfold magma_op, refa813_inst, refa813_op in H. discriminate H. Qed.

(** ---- refa814 (Fin5) ---- *)

Definition refa814_op (x y : Fin5) : Fin5 :=
  match x, y with
  | F5_0, F5_0 => F5_1 | F5_0, F5_1 => F5_3 | F5_0, F5_2 => F5_1 | F5_0, F5_3 => F5_3 | F5_0, F5_4 => F5_1
  | F5_1, F5_0 => F5_2 | F5_1, F5_1 => F5_2 | F5_1, F5_2 => F5_4 | F5_1, F5_3 => F5_2 | F5_1, F5_4 => F5_4
  | F5_2, F5_0 => F5_1 | F5_2, F5_1 => F5_3 | F5_2, F5_2 => F5_1 | F5_2, F5_3 => F5_3 | F5_2, F5_4 => F5_1
  | F5_3, F5_0 => F5_1 | F5_3, F5_1 => F5_3 | F5_3, F5_2 => F5_1 | F5_3, F5_3 => F5_3 | F5_3, F5_4 => F5_1
  | F5_4, F5_0 => F5_2 | F5_4, F5_1 => F5_2 | F5_4, F5_2 => F5_4 | F5_4, F5_3 => F5_2 | F5_4, F5_4 => F5_4
  end.

#[local] Instance refa814_inst : Magma Fin5 := {| magma_op := refa814_op |}.

Lemma refa814_sat4001 : @Equation4001 Fin5 refa814_inst.
Proof. unfold Equation4001, magma_op, refa814_inst, refa814_op. intros x y z w. destruct x, y, z, w; reflexivity. Qed.

Lemma refa814_not4587 : ~ @Equation4587 Fin5 refa814_inst.
Proof. unfold Equation4587. intro H. specialize (H F5_0 F5_1). unfold magma_op, refa814_inst, refa814_op in H. discriminate H. Qed.

Lemma refa814_not4606 : ~ @Equation4606 Fin5 refa814_inst.
Proof. unfold Equation4606. intro H. specialize (H F5_0 F5_1). unfold magma_op, refa814_inst, refa814_op in H. discriminate H. Qed.

(** ---- refa815 (Fin5) ---- *)

Definition refa815_op (x y : Fin5) : Fin5 :=
  match x, y with
  | F5_0, F5_0 => F5_2 | F5_0, F5_1 => F5_3 | F5_0, F5_2 => F5_2 | F5_0, F5_3 => F5_1 | F5_0, F5_4 => F5_1
  | F5_1, F5_0 => F5_1 | F5_1, F5_1 => F5_4 | F5_1, F5_2 => F5_2 | F5_1, F5_3 => F5_1 | F5_1, F5_4 => F5_1
  | F5_2, F5_0 => F5_2 | F5_2, F5_1 => F5_3 | F5_2, F5_2 => F5_2 | F5_2, F5_3 => F5_1 | F5_2, F5_4 => F5_1
  | F5_3, F5_0 => F5_2 | F5_3, F5_1 => F5_3 | F5_3, F5_2 => F5_2 | F5_3, F5_3 => F5_1 | F5_3, F5_4 => F5_1
  | F5_4, F5_0 => F5_2 | F5_4, F5_1 => F5_3 | F5_4, F5_2 => F5_2 | F5_4, F5_3 => F5_1 | F5_4, F5_4 => F5_1
  end.

#[local] Instance refa815_inst : Magma Fin5 := {| magma_op := refa815_op |}.

Lemma refa815_sat4040 : @Equation4040 Fin5 refa815_inst.
Proof. unfold Equation4040, magma_op, refa815_inst, refa815_op. intros x y z w. destruct x, y, z, w; reflexivity. Qed.

Lemma refa815_not4606 : ~ @Equation4606 Fin5 refa815_inst.
Proof. unfold Equation4606. intro H. specialize (H F5_0 F5_1). unfold magma_op, refa815_inst, refa815_op in H. discriminate H. Qed.

(** ---- refa816 (Fin5) ---- *)

Definition refa816_op (x y : Fin5) : Fin5 :=
  match x, y with
  | F5_0, F5_0 => F5_0 | F5_0, F5_1 => F5_0 | F5_0, F5_2 => F5_0 | F5_0, F5_3 => F5_0 | F5_0, F5_4 => F5_0
  | F5_1, F5_0 => F5_2 | F5_1, F5_1 => F5_0 | F5_1, F5_2 => F5_0 | F5_1, F5_3 => F5_0 | F5_1, F5_4 => F5_0
  | F5_2, F5_0 => F5_4 | F5_2, F5_1 => F5_3 | F5_2, F5_2 => F5_0 | F5_2, F5_3 => F5_1 | F5_2, F5_4 => F5_4
  | F5_3, F5_0 => F5_0 | F5_3, F5_1 => F5_4 | F5_3, F5_2 => F5_0 | F5_3, F5_3 => F5_0 | F5_3, F5_4 => F5_4
  | F5_4, F5_0 => F5_0 | F5_4, F5_1 => F5_0 | F5_4, F5_2 => F5_0 | F5_4, F5_3 => F5_0 | F5_4, F5_4 => F5_0
  end.

#[local] Instance refa816_inst : Magma Fin5 := {| magma_op := refa816_op |}.

Lemma refa816_sat4082 : @Equation4082 Fin5 refa816_inst.
Proof. unfold Equation4082, magma_op, refa816_inst, refa816_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa816_not4070 : ~ @Equation4070 Fin5 refa816_inst.
Proof. unfold Equation4070. intro H. specialize (H F5_1 F5_0). unfold magma_op, refa816_inst, refa816_op in H. discriminate H. Qed.

Lemma refa816_not4084 : ~ @Equation4084 Fin5 refa816_inst.
Proof. unfold Equation4084. intro H. specialize (H F5_0 F5_1). unfold magma_op, refa816_inst, refa816_op in H. discriminate H. Qed.

Lemma refa816_not4585 : ~ @Equation4585 Fin5 refa816_inst.
Proof. unfold Equation4585. intro H. specialize (H F5_1 F5_0). unfold magma_op, refa816_inst, refa816_op in H. discriminate H. Qed.

Lemma refa816_not4599 : ~ @Equation4599 Fin5 refa816_inst.
Proof. unfold Equation4599. intro H. specialize (H F5_1 F5_0). unfold magma_op, refa816_inst, refa816_op in H. discriminate H. Qed.

(** ---- refa817 (Fin5) ---- *)

Definition refa817_op (x y : Fin5) : Fin5 :=
  match x, y with
  | F5_0, F5_0 => F5_0 | F5_0, F5_1 => F5_0 | F5_0, F5_2 => F5_0 | F5_0, F5_3 => F5_0 | F5_0, F5_4 => F5_0
  | F5_1, F5_0 => F5_2 | F5_1, F5_1 => F5_0 | F5_1, F5_2 => F5_0 | F5_1, F5_3 => F5_0 | F5_1, F5_4 => F5_4
  | F5_2, F5_0 => F5_0 | F5_2, F5_1 => F5_3 | F5_2, F5_2 => F5_0 | F5_2, F5_3 => F5_0 | F5_2, F5_4 => F5_4
  | F5_3, F5_0 => F5_0 | F5_3, F5_1 => F5_4 | F5_3, F5_2 => F5_0 | F5_3, F5_3 => F5_0 | F5_3, F5_4 => F5_0
  | F5_4, F5_0 => F5_0 | F5_4, F5_1 => F5_0 | F5_4, F5_2 => F5_0 | F5_4, F5_3 => F5_0 | F5_4, F5_4 => F5_0
  end.

#[local] Instance refa817_inst : Magma Fin5 := {| magma_op := refa817_op |}.

Lemma refa817_sat4114 : @Equation4114 Fin5 refa817_inst.
Proof. unfold Equation4114, magma_op, refa817_inst, refa817_op. intros x y z w. destruct x, y, z, w; reflexivity. Qed.

Lemma refa817_not4070 : ~ @Equation4070 Fin5 refa817_inst.
Proof. unfold Equation4070. intro H. specialize (H F5_1 F5_0). unfold magma_op, refa817_inst, refa817_op in H. discriminate H. Qed.

Lemma refa817_not4084 : ~ @Equation4084 Fin5 refa817_inst.
Proof. unfold Equation4084. intro H. specialize (H F5_0 F5_1). unfold magma_op, refa817_inst, refa817_op in H. discriminate H. Qed.

Lemma refa817_not4269 : ~ @Equation4269 Fin5 refa817_inst.
Proof. unfold Equation4269. intro H. specialize (H F5_1 F5_2). unfold magma_op, refa817_inst, refa817_op in H. discriminate H. Qed.

Lemma refa817_not4314 : ~ @Equation4314 Fin5 refa817_inst.
Proof. unfold Equation4314. intro H. specialize (H F5_1 F5_2). unfold magma_op, refa817_inst, refa817_op in H. discriminate H. Qed.

Lemma refa817_not4598 : ~ @Equation4598 Fin5 refa817_inst.
Proof. unfold Equation4598. intro H. specialize (H F5_1 F5_0). unfold magma_op, refa817_inst, refa817_op in H. discriminate H. Qed.

Lemma refa817_not4599 : ~ @Equation4599 Fin5 refa817_inst.
Proof. unfold Equation4599. intro H. specialize (H F5_2 F5_1). unfold magma_op, refa817_inst, refa817_op in H. discriminate H. Qed.

Lemma refa817_not4629 : ~ @Equation4629 Fin5 refa817_inst.
Proof. unfold Equation4629. intro H. specialize (H F5_1 F5_0). unfold magma_op, refa817_inst, refa817_op in H. discriminate H. Qed.

Lemma refa817_not4631 : ~ @Equation4631 Fin5 refa817_inst.
Proof. unfold Equation4631. intro H. specialize (H F5_1 F5_0 F5_1). unfold magma_op, refa817_inst, refa817_op in H. discriminate H. Qed.

Lemma refa817_not4656 : ~ @Equation4656 Fin5 refa817_inst.
Proof. unfold Equation4656. intro H. specialize (H F5_2 F5_0 F5_1). unfold magma_op, refa817_inst, refa817_op in H. discriminate H. Qed.

(** ---- refa818 (Fin5) ---- *)

Definition refa818_op (x y : Fin5) : Fin5 :=
  match x, y with
  | F5_0, F5_0 => F5_2 | F5_0, F5_1 => F5_3 | F5_0, F5_2 => F5_2 | F5_0, F5_3 => F5_2 | F5_0, F5_4 => F5_2
  | F5_1, F5_0 => F5_4 | F5_1, F5_1 => F5_2 | F5_1, F5_2 => F5_2 | F5_1, F5_3 => F5_2 | F5_1, F5_4 => F5_4
  | F5_2, F5_0 => F5_2 | F5_2, F5_1 => F5_2 | F5_2, F5_2 => F5_2 | F5_2, F5_3 => F5_2 | F5_2, F5_4 => F5_2
  | F5_3, F5_0 => F5_2 | F5_3, F5_1 => F5_1 | F5_3, F5_2 => F5_2 | F5_3, F5_3 => F5_2 | F5_3, F5_4 => F5_2
  | F5_4, F5_0 => F5_2 | F5_4, F5_1 => F5_2 | F5_4, F5_2 => F5_2 | F5_4, F5_3 => F5_2 | F5_4, F5_4 => F5_2
  end.

#[local] Instance refa818_inst : Magma Fin5 := {| magma_op := refa818_op |}.

Lemma refa818_sat4114 : @Equation4114 Fin5 refa818_inst.
Proof. unfold Equation4114, magma_op, refa818_inst, refa818_op. intros x y z w. destruct x, y, z, w; reflexivity. Qed.

Lemma refa818_not4073 : ~ @Equation4073 Fin5 refa818_inst.
Proof. unfold Equation4073. intro H. specialize (H F5_0 F5_1). unfold magma_op, refa818_inst, refa818_op in H. discriminate H. Qed.

Lemma refa818_not4081 : ~ @Equation4081 Fin5 refa818_inst.
Proof. unfold Equation4081. intro H. specialize (H F5_1 F5_0). unfold magma_op, refa818_inst, refa818_op in H. discriminate H. Qed.

(** ---- refa819 (Fin5) ---- *)

Definition refa819_op (x y : Fin5) : Fin5 :=
  match x, y with
  | F5_0, F5_0 => F5_0 | F5_0, F5_1 => F5_2 | F5_0, F5_2 => F5_3 | F5_0, F5_3 => F5_4 | F5_0, F5_4 => F5_0
  | F5_1, F5_0 => F5_1 | F5_1, F5_1 => F5_1 | F5_1, F5_2 => F5_1 | F5_1, F5_3 => F5_1 | F5_1, F5_4 => F5_3
  | F5_2, F5_0 => F5_4 | F5_2, F5_1 => F5_4 | F5_2, F5_2 => F5_2 | F5_2, F5_3 => F5_4 | F5_2, F5_4 => F5_2
  | F5_3, F5_0 => F5_3 | F5_3, F5_1 => F5_0 | F5_3, F5_2 => F5_0 | F5_3, F5_3 => F5_3 | F5_3, F5_4 => F5_3
  | F5_4, F5_0 => F5_1 | F5_4, F5_1 => F5_4 | F5_4, F5_2 => F5_1 | F5_4, F5_3 => F5_4 | F5_4, F5_4 => F5_4
  end.

#[local] Instance refa819_inst : Magma Fin5 := {| magma_op := refa819_op |}.

Lemma refa819_sat412 : @Equation412 Fin5 refa819_inst.
Proof. unfold Equation412, magma_op, refa819_inst, refa819_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa819_not102 : ~ @Equation102 Fin5 refa819_inst.
Proof. unfold Equation102. intro H. specialize (H F5_2 F5_0). unfold magma_op, refa819_inst, refa819_op in H. discriminate H. Qed.

Lemma refa819_not413 : ~ @Equation413 Fin5 refa819_inst.
Proof. unfold Equation413. intro H. specialize (H F5_0 F5_1). unfold magma_op, refa819_inst, refa819_op in H. discriminate H. Qed.

Lemma refa819_not414 : ~ @Equation414 Fin5 refa819_inst.
Proof. unfold Equation414. intro H. specialize (H F5_0 F5_1). unfold magma_op, refa819_inst, refa819_op in H. discriminate H. Qed.

Lemma refa819_not615 : ~ @Equation615 Fin5 refa819_inst.
Proof. unfold Equation615. intro H. specialize (H F5_0 F5_1). unfold magma_op, refa819_inst, refa819_op in H. discriminate H. Qed.

Lemma refa819_not616 : ~ @Equation616 Fin5 refa819_inst.
Proof. unfold Equation616. intro H. specialize (H F5_0 F5_3). unfold magma_op, refa819_inst, refa819_op in H. discriminate H. Qed.

Lemma refa819_not818 : ~ @Equation818 Fin5 refa819_inst.
Proof. unfold Equation818. intro H. specialize (H F5_0 F5_1). unfold magma_op, refa819_inst, refa819_op in H. discriminate H. Qed.

Lemma refa819_not1427 : ~ @Equation1427 Fin5 refa819_inst.
Proof. unfold Equation1427. intro H. specialize (H F5_0 F5_1). unfold magma_op, refa819_inst, refa819_op in H. discriminate H. Qed.

Lemma refa819_not2240 : ~ @Equation2240 Fin5 refa819_inst.
Proof. unfold Equation2240. intro H. specialize (H F5_0 F5_1). unfold magma_op, refa819_inst, refa819_op in H. discriminate H. Qed.

Lemma refa819_not3254 : ~ @Equation3254 Fin5 refa819_inst.
Proof. unfold Equation3254. intro H. specialize (H F5_0 F5_1). unfold magma_op, refa819_inst, refa819_op in H. discriminate H. Qed.
