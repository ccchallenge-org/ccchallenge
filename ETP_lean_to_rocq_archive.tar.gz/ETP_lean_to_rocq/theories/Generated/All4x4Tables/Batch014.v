(** * All4x4 counterexamples — batch 14
    Auto-generated from Lean4 All4x4 files. *)

From Stdlib Require Import Utf8.

From ETP Require Import Magma.
From ETP Require Import FinMagma.
From ETP.Equations Require Import All.

Open Scope magma_scope.

(** ---- refa685 (Fin5) ---- *)

Definition refa685_op (x y : Fin5) : Fin5 :=
  match x, y with
  | F5_0, F5_0 => F5_2 | F5_0, F5_1 => F5_2 | F5_0, F5_2 => F5_2 | F5_0, F5_3 => F5_4 | F5_0, F5_4 => F5_2
  | F5_1, F5_0 => F5_4 | F5_1, F5_1 => F5_3 | F5_1, F5_2 => F5_3 | F5_1, F5_3 => F5_3 | F5_1, F5_4 => F5_3
  | F5_2, F5_0 => F5_0 | F5_2, F5_1 => F5_4 | F5_2, F5_2 => F5_0 | F5_2, F5_3 => F5_0 | F5_2, F5_4 => F5_0
  | F5_3, F5_0 => F5_1 | F5_3, F5_1 => F5_1 | F5_3, F5_2 => F5_4 | F5_3, F5_3 => F5_1 | F5_3, F5_4 => F5_1
  | F5_4, F5_0 => F5_4 | F5_4, F5_1 => F5_4 | F5_4, F5_2 => F5_4 | F5_4, F5_3 => F5_4 | F5_4, F5_4 => F5_4
  end.

#[local] Instance refa685_inst : Magma Fin5 := {| magma_op := refa685_op |}.

Lemma refa685_sat1636 : @Equation1636 Fin5 refa685_inst.
Proof. unfold Equation1636, magma_op, refa685_inst, refa685_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa685_not1637 : ~ @Equation1637 Fin5 refa685_inst.
Proof. unfold Equation1637. intro H. specialize (H F5_0 F5_1). unfold magma_op, refa685_inst, refa685_op in H. discriminate H. Qed.

Lemma refa685_not1834 : ~ @Equation1834 Fin5 refa685_inst.
Proof. unfold Equation1834. intro H. specialize (H F5_0 F5_3). unfold magma_op, refa685_inst, refa685_op in H. discriminate H. Qed.

Lemma refa685_not1840 : ~ @Equation1840 Fin5 refa685_inst.
Proof. unfold Equation1840. intro H. specialize (H F5_0 F5_3). unfold magma_op, refa685_inst, refa685_op in H. discriminate H. Qed.

Lemma refa685_not2253 : ~ @Equation2253 Fin5 refa685_inst.
Proof. unfold Equation2253. intro H. specialize (H F5_0 F5_1). unfold magma_op, refa685_inst, refa685_op in H. discriminate H. Qed.

Lemma refa685_not2459 : ~ @Equation2459 Fin5 refa685_inst.
Proof. unfold Equation2459. intro H. specialize (H F5_0 F5_3). unfold magma_op, refa685_inst, refa685_op in H. discriminate H. Qed.

Lemma refa685_not3258 : ~ @Equation3258 Fin5 refa685_inst.
Proof. unfold Equation3258. intro H. specialize (H F5_0 F5_1). unfold magma_op, refa685_inst, refa685_op in H. discriminate H. Qed.

Lemma refa685_not3316 : ~ @Equation3316 Fin5 refa685_inst.
Proof. unfold Equation3316. intro H. specialize (H F5_0 F5_1). unfold magma_op, refa685_inst, refa685_op in H. discriminate H. Qed.

Lemma refa685_not3318 : ~ @Equation3318 Fin5 refa685_inst.
Proof. unfold Equation3318. intro H. specialize (H F5_0 F5_1). unfold magma_op, refa685_inst, refa685_op in H. discriminate H. Qed.

Lemma refa685_not3319 : ~ @Equation3319 Fin5 refa685_inst.
Proof. unfold Equation3319. intro H. specialize (H F5_0 F5_1). unfold magma_op, refa685_inst, refa685_op in H. discriminate H. Qed.

Lemma refa685_not3462 : ~ @Equation3462 Fin5 refa685_inst.
Proof. unfold Equation3462. intro H. specialize (H F5_0 F5_3). unfold magma_op, refa685_inst, refa685_op in H. discriminate H. Qed.

Lemma refa685_not4120 : ~ @Equation4120 Fin5 refa685_inst.
Proof. unfold Equation4120. intro H. specialize (H F5_0 F5_1). unfold magma_op, refa685_inst, refa685_op in H. discriminate H. Qed.

Lemma refa685_not4121 : ~ @Equation4121 Fin5 refa685_inst.
Proof. unfold Equation4121. intro H. specialize (H F5_0 F5_1). unfold magma_op, refa685_inst, refa685_op in H. discriminate H. Qed.

Lemma refa685_not4130 : ~ @Equation4130 Fin5 refa685_inst.
Proof. unfold Equation4130. intro H. specialize (H F5_0 F5_1). unfold magma_op, refa685_inst, refa685_op in H. discriminate H. Qed.

Lemma refa685_not4131 : ~ @Equation4131 Fin5 refa685_inst.
Proof. unfold Equation4131. intro H. specialize (H F5_0 F5_1). unfold magma_op, refa685_inst, refa685_op in H. discriminate H. Qed.

Lemma refa685_not4598 : ~ @Equation4598 Fin5 refa685_inst.
Proof. unfold Equation4598. intro H. specialize (H F5_0 F5_1). unfold magma_op, refa685_inst, refa685_op in H. discriminate H. Qed.

Lemma refa685_not4599 : ~ @Equation4599 Fin5 refa685_inst.
Proof. unfold Equation4599. intro H. specialize (H F5_0 F5_3). unfold magma_op, refa685_inst, refa685_op in H. discriminate H. Qed.

Lemma refa685_not4629 : ~ @Equation4629 Fin5 refa685_inst.
Proof. unfold Equation4629. intro H. specialize (H F5_0 F5_1). unfold magma_op, refa685_inst, refa685_op in H. discriminate H. Qed.

(** ---- refa686 (Fin6) ---- *)

Definition refa686_op (x y : Fin6) : Fin6 :=
  match x, y with
  | F6_0, F6_0 => F6_0 | F6_0, F6_1 => F6_2 | F6_0, F6_2 => F6_3 | F6_0, F6_3 => F6_5 | F6_0, F6_4 => F6_5 | F6_0, F6_5 => F6_2
  | F6_1, F6_0 => F6_4 | F6_1, F6_1 => F6_4 | F6_1, F6_2 => F6_4 | F6_1, F6_3 => F6_4 | F6_1, F6_4 => F6_4 | F6_1, F6_5 => F6_4
  | F6_2, F6_0 => F6_5 | F6_2, F6_1 => F6_3 | F6_2, F6_2 => F6_2 | F6_2, F6_3 => F6_0 | F6_2, F6_4 => F6_0 | F6_2, F6_5 => F6_3
  | F6_3, F6_0 => F6_2 | F6_3, F6_1 => F6_0 | F6_3, F6_2 => F6_5 | F6_3, F6_3 => F6_3 | F6_3, F6_4 => F6_3 | F6_3, F6_5 => F6_0
  | F6_4, F6_0 => F6_1 | F6_4, F6_1 => F6_1 | F6_4, F6_2 => F6_1 | F6_4, F6_3 => F6_1 | F6_4, F6_4 => F6_1 | F6_4, F6_5 => F6_1
  | F6_5, F6_0 => F6_3 | F6_5, F6_1 => F6_5 | F6_5, F6_2 => F6_0 | F6_5, F6_3 => F6_2 | F6_5, F6_4 => F6_2 | F6_5, F6_5 => F6_5
  end.

#[local] Instance refa686_inst : Magma Fin6 := {| magma_op := refa686_op |}.

Lemma refa686_sat206 : @Equation206 Fin6 refa686_inst.
Proof. unfold Equation206, magma_op, refa686_inst, refa686_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa686_sat1648 : @Equation1648 Fin6 refa686_inst.
Proof. unfold Equation1648, magma_op, refa686_inst, refa686_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa686_not159 : ~ @Equation159 Fin6 refa686_inst.
Proof. unfold Equation159. intro H. specialize (H F6_0 F6_4). unfold magma_op, refa686_inst, refa686_op in H. discriminate H. Qed.

Lemma refa686_not1432 : ~ @Equation1432 Fin6 refa686_inst.
Proof. unfold Equation1432. intro H. specialize (H F6_0 F6_1). unfold magma_op, refa686_inst, refa686_op in H. discriminate H. Qed.

Lemma refa686_not1451 : ~ @Equation1451 Fin6 refa686_inst.
Proof. unfold Equation1451. intro H. specialize (H F6_0 F6_4). unfold magma_op, refa686_inst, refa686_op in H. discriminate H. Qed.

Lemma refa686_not1635 : ~ @Equation1635 Fin6 refa686_inst.
Proof. unfold Equation1635. intro H. specialize (H F6_0 F6_1). unfold magma_op, refa686_inst, refa686_op in H. discriminate H. Qed.

Lemma refa686_not1657 : ~ @Equation1657 Fin6 refa686_inst.
Proof. unfold Equation1657. intro H. specialize (H F6_0 F6_1). unfold magma_op, refa686_inst, refa686_op in H. discriminate H. Qed.

Lemma refa686_not1841 : ~ @Equation1841 Fin6 refa686_inst.
Proof. unfold Equation1841. intro H. specialize (H F6_0 F6_1). unfold magma_op, refa686_inst, refa686_op in H. discriminate H. Qed.

Lemma refa686_not1848 : ~ @Equation1848 Fin6 refa686_inst.
Proof. unfold Equation1848. intro H. specialize (H F6_0 F6_4). unfold magma_op, refa686_inst, refa686_op in H. discriminate H. Qed.

Lemma refa686_not1860 : ~ @Equation1860 Fin6 refa686_inst.
Proof. unfold Equation1860. intro H. specialize (H F6_0 F6_1). unfold magma_op, refa686_inst, refa686_op in H. discriminate H. Qed.

Lemma refa686_not2247 : ~ @Equation2247 Fin6 refa686_inst.
Proof. unfold Equation2247. intro H. specialize (H F6_0 F6_1). unfold magma_op, refa686_inst, refa686_op in H. discriminate H. Qed.

Lemma refa686_not2256 : ~ @Equation2256 Fin6 refa686_inst.
Proof. unfold Equation2256. intro H. specialize (H F6_0 F6_1). unfold magma_op, refa686_inst, refa686_op in H. discriminate H. Qed.

Lemma refa686_not2264 : ~ @Equation2264 Fin6 refa686_inst.
Proof. unfold Equation2264. intro H. specialize (H F6_0 F6_1). unfold magma_op, refa686_inst, refa686_op in H. discriminate H. Qed.

Lemma refa686_not2457 : ~ @Equation2457 Fin6 refa686_inst.
Proof. unfold Equation2457. intro H. specialize (H F6_0 F6_1). unfold magma_op, refa686_inst, refa686_op in H. discriminate H. Qed.

Lemma refa686_not2459 : ~ @Equation2459 Fin6 refa686_inst.
Proof. unfold Equation2459. intro H. specialize (H F6_0 F6_1). unfold magma_op, refa686_inst, refa686_op in H. discriminate H. Qed.

Lemma refa686_not3259 : ~ @Equation3259 Fin6 refa686_inst.
Proof. unfold Equation3259. intro H. specialize (H F6_0 F6_1). unfold magma_op, refa686_inst, refa686_op in H. discriminate H. Qed.

Lemma refa686_not3308 : ~ @Equation3308 Fin6 refa686_inst.
Proof. unfold Equation3308. intro H. specialize (H F6_0 F6_4). unfold magma_op, refa686_inst, refa686_op in H. discriminate H. Qed.

Lemma refa686_not3319 : ~ @Equation3319 Fin6 refa686_inst.
Proof. unfold Equation3319. intro H. specialize (H F6_0 F6_1). unfold magma_op, refa686_inst, refa686_op in H. discriminate H. Qed.

Lemma refa686_not3462 : ~ @Equation3462 Fin6 refa686_inst.
Proof. unfold Equation3462. intro H. specialize (H F6_0 F6_1). unfold magma_op, refa686_inst, refa686_op in H. discriminate H. Qed.

(** ---- refa687 (Fin5) ---- *)

Definition refa687_op (x y : Fin5) : Fin5 :=
  match x, y with
  | F5_0, F5_0 => F5_1 | F5_0, F5_1 => F5_2 | F5_0, F5_2 => F5_2 | F5_0, F5_3 => F5_1 | F5_0, F5_4 => F5_2
  | F5_1, F5_0 => F5_3 | F5_1, F5_1 => F5_3 | F5_1, F5_2 => F5_4 | F5_1, F5_3 => F5_0 | F5_1, F5_4 => F5_4
  | F5_2, F5_0 => F5_3 | F5_2, F5_1 => F5_3 | F5_2, F5_2 => F5_3 | F5_2, F5_3 => F5_0 | F5_2, F5_4 => F5_3
  | F5_3, F5_0 => F5_3 | F5_3, F5_1 => F5_3 | F5_3, F5_2 => F5_2 | F5_3, F5_3 => F5_1 | F5_3, F5_4 => F5_2
  | F5_4, F5_0 => F5_1 | F5_4, F5_1 => F5_1 | F5_4, F5_2 => F5_1 | F5_4, F5_3 => F5_1 | F5_4, F5_4 => F5_1
  end.

#[local] Instance refa687_inst : Magma Fin5 := {| magma_op := refa687_op |}.

Lemma refa687_sat1672 : @Equation1672 Fin5 refa687_inst.
Proof. unfold Equation1672, magma_op, refa687_inst, refa687_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa687_not3253 : ~ @Equation3253 Fin5 refa687_inst.
Proof. unfold Equation3253. intro H. specialize (H F5_0). unfold magma_op, refa687_inst, refa687_op in H. discriminate H. Qed.

(** ---- refa688 (Fin5) ---- *)

Definition refa688_op (x y : Fin5) : Fin5 :=
  match x, y with
  | F5_0, F5_0 => F5_0 | F5_0, F5_1 => F5_3 | F5_0, F5_2 => F5_3 | F5_0, F5_3 => F5_2 | F5_0, F5_4 => F5_2
  | F5_1, F5_0 => F5_2 | F5_1, F5_1 => F5_4 | F5_1, F5_2 => F5_1 | F5_1, F5_3 => F5_2 | F5_1, F5_4 => F5_1
  | F5_2, F5_0 => F5_0 | F5_2, F5_1 => F5_4 | F5_2, F5_2 => F5_3 | F5_2, F5_3 => F5_2 | F5_2, F5_4 => F5_4
  | F5_3, F5_0 => F5_0 | F5_3, F5_1 => F5_3 | F5_3, F5_2 => F5_3 | F5_3, F5_3 => F5_2 | F5_3, F5_4 => F5_1
  | F5_4, F5_0 => F5_3 | F5_4, F5_1 => F5_4 | F5_4, F5_2 => F5_3 | F5_4, F5_3 => F5_3 | F5_4, F5_4 => F5_1
  end.

#[local] Instance refa688_inst : Magma Fin5 := {| magma_op := refa688_op |}.

Lemma refa688_sat1687 : @Equation1687 Fin5 refa688_inst.
Proof. unfold Equation1687, magma_op, refa688_inst, refa688_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa688_not1045 : ~ @Equation1045 Fin5 refa688_inst.
Proof. unfold Equation1045. intro H. specialize (H F5_0 F5_1). unfold magma_op, refa688_inst, refa688_op in H. discriminate H. Qed.

Lemma refa688_not3887 : ~ @Equation3887 Fin5 refa688_inst.
Proof. unfold Equation3887. intro H. specialize (H F5_0 F5_1). unfold magma_op, refa688_inst, refa688_op in H. discriminate H. Qed.

(** ---- refa689 (Fin6) ---- *)

Definition refa689_op (x y : Fin6) : Fin6 :=
  match x, y with
  | F6_0, F6_0 => F6_3 | F6_0, F6_1 => F6_2 | F6_0, F6_2 => F6_1 | F6_0, F6_3 => F6_4 | F6_0, F6_4 => F6_3 | F6_0, F6_5 => F6_4
  | F6_1, F6_0 => F6_2 | F6_1, F6_1 => F6_2 | F6_1, F6_2 => F6_0 | F6_1, F6_3 => F6_0 | F6_1, F6_4 => F6_5 | F6_1, F6_5 => F6_4
  | F6_2, F6_0 => F6_3 | F6_2, F6_1 => F6_2 | F6_2, F6_2 => F6_1 | F6_2, F6_3 => F6_0 | F6_2, F6_4 => F6_5 | F6_2, F6_5 => F6_4
  | F6_3, F6_0 => F6_2 | F6_3, F6_1 => F6_2 | F6_3, F6_2 => F6_0 | F6_3, F6_3 => F6_0 | F6_3, F6_4 => F6_5 | F6_3, F6_5 => F6_4
  | F6_4, F6_0 => F6_3 | F6_4, F6_1 => F6_2 | F6_4, F6_2 => F6_1 | F6_4, F6_3 => F6_0 | F6_4, F6_4 => F6_5 | F6_4, F6_5 => F6_4
  | F6_5, F6_0 => F6_3 | F6_5, F6_1 => F6_2 | F6_5, F6_2 => F6_1 | F6_5, F6_3 => F6_4 | F6_5, F6_4 => F6_3 | F6_5, F6_5 => F6_4
  end.

#[local] Instance refa689_inst : Magma Fin6 := {| magma_op := refa689_op |}.

Lemma refa689_sat1697 : @Equation1697 Fin6 refa689_inst.
Proof. unfold Equation1697, magma_op, refa689_inst, refa689_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa689_not1931 : ~ @Equation1931 Fin6 refa689_inst.
Proof. unfold Equation1931. intro H. specialize (H F6_0 F6_1). unfold magma_op, refa689_inst, refa689_op in H. discriminate H. Qed.

Lemma refa689_not2134 : ~ @Equation2134 Fin6 refa689_inst.
Proof. unfold Equation2134. intro H. specialize (H F6_0 F6_2). unfold magma_op, refa689_inst, refa689_op in H. discriminate H. Qed.

Lemma refa689_not3880 : ~ @Equation3880 Fin6 refa689_inst.
Proof. unfold Equation3880. intro H. specialize (H F6_0 F6_5). unfold magma_op, refa689_inst, refa689_op in H. discriminate H. Qed.

Lemma refa689_not3890 : ~ @Equation3890 Fin6 refa689_inst.
Proof. unfold Equation3890. intro H. specialize (H F6_0 F6_5). unfold magma_op, refa689_inst, refa689_op in H. discriminate H. Qed.

Lemma refa689_not3952 : ~ @Equation3952 Fin6 refa689_inst.
Proof. unfold Equation3952. intro H. specialize (H F6_1 F6_3). unfold magma_op, refa689_inst, refa689_op in H. discriminate H. Qed.

Lemma refa689_not3962 : ~ @Equation3962 Fin6 refa689_inst.
Proof. unfold Equation3962. intro H. specialize (H F6_1 F6_3). unfold magma_op, refa689_inst, refa689_op in H. discriminate H. Qed.

Lemma refa689_not4073 : ~ @Equation4073 Fin6 refa689_inst.
Proof. unfold Equation4073. intro H. specialize (H F6_2 F6_4). unfold magma_op, refa689_inst, refa689_op in H. discriminate H. Qed.

Lemma refa689_not4093 : ~ @Equation4093 Fin6 refa689_inst.
Proof. unfold Equation4093. intro H. specialize (H F6_0 F6_4). unfold magma_op, refa689_inst, refa689_op in H. discriminate H. Qed.

Lemma refa689_not4606 : ~ @Equation4606 Fin6 refa689_inst.
Proof. unfold Equation4606. intro H. specialize (H F6_2 F6_3). unfold magma_op, refa689_inst, refa689_op in H. discriminate H. Qed.

(** ---- refa69 (Fin3) ---- *)

Definition refa69_op (x y : Fin3) : Fin3 :=
  match x, y with
  | F3_0, F3_0 => F3_0 | F3_0, F3_1 => F3_0 | F3_0, F3_2 => F3_0
  | F3_1, F3_0 => F3_1 | F3_1, F3_1 => F3_1 | F3_1, F3_2 => F3_2
  | F3_2, F3_0 => F3_1 | F3_2, F3_1 => F3_1 | F3_2, F3_2 => F3_0
  end.

#[local] Instance refa69_inst : Magma Fin3 := {| magma_op := refa69_op |}.

Lemma refa69_sat359 : @Equation359 Fin3 refa69_inst.
Proof. unfold Equation359, magma_op, refa69_inst, refa69_op. intros x. destruct x; reflexivity. Qed.

Lemma refa69_sat2462 : @Equation2462 Fin3 refa69_inst.
Proof. unfold Equation2462, magma_op, refa69_inst, refa69_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa69_not2466 : ~ @Equation2466 Fin3 refa69_inst.
Proof. unfold Equation2466. intro H. specialize (H F3_2 F3_1). unfold magma_op, refa69_inst, refa69_op in H. discriminate H. Qed.

Lemma refa69_not2646 : ~ @Equation2646 Fin3 refa69_inst.
Proof. unfold Equation2646. intro H. specialize (H F3_2 F3_0). unfold magma_op, refa69_inst, refa69_op in H. discriminate H. Qed.

Lemma refa69_not3862 : ~ @Equation3862 Fin3 refa69_inst.
Proof. unfold Equation3862. intro H. specialize (H F3_2). unfold magma_op, refa69_inst, refa69_op in H. discriminate H. Qed.

(** ---- refa690 (Fin5) ---- *)

Definition refa690_op (x y : Fin5) : Fin5 :=
  match x, y with
  | F5_0, F5_0 => F5_1 | F5_0, F5_1 => F5_2 | F5_0, F5_2 => F5_1 | F5_0, F5_3 => F5_4 | F5_0, F5_4 => F5_3
  | F5_1, F5_0 => F5_3 | F5_1, F5_1 => F5_2 | F5_1, F5_2 => F5_1 | F5_1, F5_3 => F5_0 | F5_1, F5_4 => F5_0
  | F5_2, F5_0 => F5_1 | F5_2, F5_1 => F5_2 | F5_2, F5_2 => F5_1 | F5_2, F5_3 => F5_4 | F5_2, F5_4 => F5_3
  | F5_3, F5_0 => F5_4 | F5_3, F5_1 => F5_0 | F5_3, F5_2 => F5_1 | F5_3, F5_3 => F5_4 | F5_3, F5_4 => F5_0
  | F5_4, F5_0 => F5_3 | F5_4, F5_1 => F5_0 | F5_4, F5_2 => F5_1 | F5_4, F5_3 => F5_0 | F5_4, F5_4 => F5_3
  end.

#[local] Instance refa690_inst : Magma Fin5 := {| magma_op := refa690_op |}.

Lemma refa690_sat2169 : @Equation2169 Fin5 refa690_inst.
Proof. unfold Equation2169, magma_op, refa690_inst, refa690_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa690_not151 : ~ @Equation151 Fin5 refa690_inst.
Proof. unfold Equation151. intro H. specialize (H F5_0). unfold magma_op, refa690_inst, refa690_op in H. discriminate H. Qed.

Lemma refa690_not1426 : ~ @Equation1426 Fin5 refa690_inst.
Proof. unfold Equation1426. intro H. specialize (H F5_0). unfold magma_op, refa690_inst, refa690_op in H. discriminate H. Qed.

Lemma refa690_not1631 : ~ @Equation1631 Fin5 refa690_inst.
Proof. unfold Equation1631. intro H. specialize (H F5_0 F5_1). unfold magma_op, refa690_inst, refa690_op in H. discriminate H. Qed.

Lemma refa690_not1637 : ~ @Equation1637 Fin5 refa690_inst.
Proof. unfold Equation1637. intro H. specialize (H F5_0 F5_1). unfold magma_op, refa690_inst, refa690_op in H. discriminate H. Qed.

Lemma refa690_not1654 : ~ @Equation1654 Fin5 refa690_inst.
Proof. unfold Equation1654. intro H. specialize (H F5_0 F5_1). unfold magma_op, refa690_inst, refa690_op in H. discriminate H. Qed.

Lemma refa690_not1657 : ~ @Equation1657 Fin5 refa690_inst.
Proof. unfold Equation1657. intro H. specialize (H F5_0 F5_1). unfold magma_op, refa690_inst, refa690_op in H. discriminate H. Qed.

Lemma refa690_not1832 : ~ @Equation1832 Fin5 refa690_inst.
Proof. unfold Equation1832. intro H. specialize (H F5_0). unfold magma_op, refa690_inst, refa690_op in H. discriminate H. Qed.

Lemma refa690_not2050 : ~ @Equation2050 Fin5 refa690_inst.
Proof. unfold Equation2050. intro H. specialize (H F5_0 F5_1). unfold magma_op, refa690_inst, refa690_op in H. discriminate H. Qed.

Lemma refa690_not2124 : ~ @Equation2124 Fin5 refa690_inst.
Proof. unfold Equation2124. intro H. specialize (H F5_0 F5_1). unfold magma_op, refa690_inst, refa690_op in H. discriminate H. Qed.

Lemma refa690_not2134 : ~ @Equation2134 Fin5 refa690_inst.
Proof. unfold Equation2134. intro H. specialize (H F5_0 F5_1). unfold magma_op, refa690_inst, refa690_op in H. discriminate H. Qed.

Lemma refa690_not3261 : ~ @Equation3261 Fin5 refa690_inst.
Proof. unfold Equation3261. intro H. specialize (H F5_1 F5_3). unfold magma_op, refa690_inst, refa690_op in H. discriminate H. Qed.

Lemma refa690_not3306 : ~ @Equation3306 Fin5 refa690_inst.
Proof. unfold Equation3306. intro H. specialize (H F5_3 F5_2). unfold magma_op, refa690_inst, refa690_op in H. discriminate H. Qed.

Lemma refa690_not3309 : ~ @Equation3309 Fin5 refa690_inst.
Proof. unfold Equation3309. intro H. specialize (H F5_1 F5_0). unfold magma_op, refa690_inst, refa690_op in H. discriminate H. Qed.

Lemma refa690_not3456 : ~ @Equation3456 Fin5 refa690_inst.
Proof. unfold Equation3456. intro H. specialize (H F5_0). unfold magma_op, refa690_inst, refa690_op in H. discriminate H. Qed.

Lemma refa690_not3880 : ~ @Equation3880 Fin5 refa690_inst.
Proof. unfold Equation3880. intro H. specialize (H F5_0 F5_1). unfold magma_op, refa690_inst, refa690_op in H. discriminate H. Qed.

Lemma refa690_not3887 : ~ @Equation3887 Fin5 refa690_inst.
Proof. unfold Equation3887. intro H. specialize (H F5_1 F5_3). unfold magma_op, refa690_inst, refa690_op in H. discriminate H. Qed.

Lemma refa690_not3890 : ~ @Equation3890 Fin5 refa690_inst.
Proof. unfold Equation3890. intro H. specialize (H F5_0 F5_1). unfold magma_op, refa690_inst, refa690_op in H. discriminate H. Qed.

Lemma refa690_not3952 : ~ @Equation3952 Fin5 refa690_inst.
Proof. unfold Equation3952. intro H. specialize (H F5_3 F5_1). unfold magma_op, refa690_inst, refa690_op in H. discriminate H. Qed.

Lemma refa690_not4065 : ~ @Equation4065 Fin5 refa690_inst.
Proof. unfold Equation4065. intro H. specialize (H F5_0). unfold magma_op, refa690_inst, refa690_op in H. discriminate H. Qed.

Lemma refa690_not4284 : ~ @Equation4284 Fin5 refa690_inst.
Proof. unfold Equation4284. intro H. specialize (H F5_1 F5_0). unfold magma_op, refa690_inst, refa690_op in H. discriminate H. Qed.

Lemma refa690_not4380 : ~ @Equation4380 Fin5 refa690_inst.
Proof. unfold Equation4380. intro H. specialize (H F5_0). unfold magma_op, refa690_inst, refa690_op in H. discriminate H. Qed.

Lemma refa690_not4599 : ~ @Equation4599 Fin5 refa690_inst.
Proof. unfold Equation4599. intro H. specialize (H F5_1 F5_0). unfold magma_op, refa690_inst, refa690_op in H. discriminate H. Qed.

Lemma refa690_not4606 : ~ @Equation4606 Fin5 refa690_inst.
Proof. unfold Equation4606. intro H. specialize (H F5_0 F5_1). unfold magma_op, refa690_inst, refa690_op in H. discriminate H. Qed.

Lemma refa690_not4635 : ~ @Equation4635 Fin5 refa690_inst.
Proof. unfold Equation4635. intro H. specialize (H F5_0 F5_1). unfold magma_op, refa690_inst, refa690_op in H. discriminate H. Qed.

(** ---- refa691 (Fin5) ---- *)

Definition refa691_op (x y : Fin5) : Fin5 :=
  match x, y with
  | F5_0, F5_0 => F5_1 | F5_0, F5_1 => F5_0 | F5_0, F5_2 => F5_3 | F5_0, F5_3 => F5_2 | F5_0, F5_4 => F5_1
  | F5_1, F5_0 => F5_2 | F5_1, F5_1 => F5_4 | F5_1, F5_2 => F5_0 | F5_1, F5_3 => F5_4 | F5_1, F5_4 => F5_1
  | F5_2, F5_0 => F5_2 | F5_2, F5_1 => F5_0 | F5_2, F5_2 => F5_0 | F5_2, F5_3 => F5_4 | F5_2, F5_4 => F5_3
  | F5_3, F5_0 => F5_2 | F5_3, F5_1 => F5_4 | F5_3, F5_2 => F5_3 | F5_3, F5_3 => F5_2 | F5_3, F5_4 => F5_1
  | F5_4, F5_0 => F5_1 | F5_4, F5_1 => F5_0 | F5_4, F5_2 => F5_3 | F5_4, F5_3 => F5_4 | F5_4, F5_4 => F5_3
  end.

#[local] Instance refa691_inst : Magma Fin5 := {| magma_op := refa691_op |}.

Lemma refa691_sat2093 : @Equation2093 Fin5 refa691_inst.
Proof. unfold Equation2093, magma_op, refa691_inst, refa691_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa691_not3952 : ~ @Equation3952 Fin5 refa691_inst.
Proof. unfold Equation3952. intro H. specialize (H F5_0 F5_3). unfold magma_op, refa691_inst, refa691_op in H. discriminate H. Qed.

(** ---- refa692 (Fin6) ---- *)

Definition refa692_op (x y : Fin6) : Fin6 :=
  match x, y with
  | F6_0, F6_0 => F6_2 | F6_0, F6_1 => F6_3 | F6_0, F6_2 => F6_4 | F6_0, F6_3 => F6_1 | F6_0, F6_4 => F6_2 | F6_0, F6_5 => F6_4
  | F6_1, F6_0 => F6_2 | F6_1, F6_1 => F6_3 | F6_1, F6_2 => F6_3 | F6_1, F6_3 => F6_1 | F6_1, F6_4 => F6_0 | F6_1, F6_5 => F6_4
  | F6_2, F6_0 => F6_4 | F6_2, F6_1 => F6_3 | F6_2, F6_2 => F6_0 | F6_2, F6_3 => F6_1 | F6_2, F6_4 => F6_0 | F6_2, F6_5 => F6_4
  | F6_3, F6_0 => F6_2 | F6_3, F6_1 => F6_3 | F6_3, F6_2 => F6_4 | F6_3, F6_3 => F6_1 | F6_3, F6_4 => F6_2 | F6_3, F6_5 => F6_4
  | F6_4, F6_0 => F6_2 | F6_4, F6_1 => F6_3 | F6_4, F6_2 => F6_0 | F6_4, F6_3 => F6_2 | F6_4, F6_4 => F6_5 | F6_4, F6_5 => F6_4
  | F6_5, F6_0 => F6_4 | F6_5, F6_1 => F6_3 | F6_5, F6_2 => F6_4 | F6_5, F6_3 => F6_1 | F6_5, F6_4 => F6_0 | F6_5, F6_5 => F6_4
  end.

#[local] Instance refa692_inst : Magma Fin6 := {| magma_op := refa692_op |}.

Lemma refa692_sat2169 : @Equation2169 Fin6 refa692_inst.
Proof. unfold Equation2169, magma_op, refa692_inst, refa692_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa692_not3258 : ~ @Equation3258 Fin6 refa692_inst.
Proof. unfold Equation3258. intro H. specialize (H F6_0 F6_1). unfold magma_op, refa692_inst, refa692_op in H. discriminate H. Qed.

Lemma refa692_not3962 : ~ @Equation3962 Fin6 refa692_inst.
Proof. unfold Equation3962. intro H. specialize (H F6_0 F6_3). unfold magma_op, refa692_inst, refa692_op in H. discriminate H. Qed.

(** ---- refa693 (Fin6) ---- *)

Definition refa693_op (x y : Fin6) : Fin6 :=
  match x, y with
  | F6_0, F6_0 => F6_2 | F6_0, F6_1 => F6_3 | F6_0, F6_2 => F6_5 | F6_0, F6_3 => F6_1 | F6_0, F6_4 => F6_5 | F6_0, F6_5 => F6_2
  | F6_1, F6_0 => F6_5 | F6_1, F6_1 => F6_3 | F6_1, F6_2 => F6_3 | F6_1, F6_3 => F6_1 | F6_1, F6_4 => F6_5 | F6_1, F6_5 => F6_0
  | F6_2, F6_0 => F6_5 | F6_2, F6_1 => F6_3 | F6_2, F6_2 => F6_0 | F6_2, F6_3 => F6_1 | F6_2, F6_4 => F6_5 | F6_2, F6_5 => F6_0
  | F6_3, F6_0 => F6_1 | F6_3, F6_1 => F6_3 | F6_3, F6_2 => F6_5 | F6_3, F6_3 => F6_1 | F6_3, F6_4 => F6_5 | F6_3, F6_5 => F6_2
  | F6_4, F6_0 => F6_5 | F6_4, F6_1 => F6_3 | F6_4, F6_2 => F6_5 | F6_4, F6_3 => F6_1 | F6_4, F6_4 => F6_5 | F6_4, F6_5 => F6_0
  | F6_5, F6_0 => F6_2 | F6_5, F6_1 => F6_0 | F6_5, F6_2 => F6_0 | F6_5, F6_3 => F6_2 | F6_5, F6_4 => F6_5 | F6_5, F6_5 => F6_4
  end.

#[local] Instance refa693_inst : Magma Fin6 := {| magma_op := refa693_op |}.

Lemma refa693_sat2169 : @Equation2169 Fin6 refa693_inst.
Proof. unfold Equation2169, magma_op, refa693_inst, refa693_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa693_not3877 : ~ @Equation3877 Fin6 refa693_inst.
Proof. unfold Equation3877. intro H. specialize (H F6_0 F6_1). unfold magma_op, refa693_inst, refa693_op in H. discriminate H. Qed.

(** ---- refa694 (Fin5) ---- *)

Definition refa694_op (x y : Fin5) : Fin5 :=
  match x, y with
  | F5_0, F5_0 => F5_1 | F5_0, F5_1 => F5_2 | F5_0, F5_2 => F5_0 | F5_0, F5_3 => F5_4 | F5_0, F5_4 => F5_3
  | F5_1, F5_0 => F5_0 | F5_1, F5_1 => F5_4 | F5_1, F5_2 => F5_3 | F5_1, F5_3 => F5_1 | F5_1, F5_4 => F5_2
  | F5_2, F5_0 => F5_4 | F5_2, F5_1 => F5_3 | F5_2, F5_2 => F5_2 | F5_2, F5_3 => F5_0 | F5_2, F5_4 => F5_1
  | F5_3, F5_0 => F5_2 | F5_3, F5_1 => F5_0 | F5_3, F5_2 => F5_1 | F5_3, F5_3 => F5_3 | F5_3, F5_4 => F5_4
  | F5_4, F5_0 => F5_3 | F5_4, F5_1 => F5_1 | F5_4, F5_2 => F5_4 | F5_4, F5_3 => F5_2 | F5_4, F5_4 => F5_0
  end.

#[local] Instance refa694_inst : Magma Fin5 := {| magma_op := refa694_op |}.

Lemma refa694_sat1719 : @Equation1719 Fin5 refa694_inst.
Proof. unfold Equation1719, magma_op, refa694_inst, refa694_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa694_not1832 : ~ @Equation1832 Fin5 refa694_inst.
Proof. unfold Equation1832. intro H. specialize (H F5_0). unfold magma_op, refa694_inst, refa694_op in H. discriminate H. Qed.

(** ---- refa695 (Fin5) ---- *)

Definition refa695_op (x y : Fin5) : Fin5 :=
  match x, y with
  | F5_0, F5_0 => F5_3 | F5_0, F5_1 => F5_2 | F5_0, F5_2 => F5_2 | F5_0, F5_3 => F5_3 | F5_0, F5_4 => F5_3
  | F5_1, F5_0 => F5_0 | F5_1, F5_1 => F5_3 | F5_1, F5_2 => F5_3 | F5_1, F5_3 => F5_3 | F5_1, F5_4 => F5_0
  | F5_2, F5_0 => F5_4 | F5_2, F5_1 => F5_3 | F5_2, F5_2 => F5_3 | F5_2, F5_3 => F5_3 | F5_2, F5_4 => F5_4
  | F5_3, F5_0 => F5_4 | F5_3, F5_1 => F5_2 | F5_3, F5_2 => F5_1 | F5_3, F5_3 => F5_3 | F5_3, F5_4 => F5_0
  | F5_4, F5_0 => F5_3 | F5_4, F5_1 => F5_1 | F5_4, F5_2 => F5_1 | F5_4, F5_3 => F5_3 | F5_4, F5_4 => F5_3
  end.

#[local] Instance refa695_inst : Magma Fin5 := {| magma_op := refa695_op |}.

Lemma refa695_sat1724 : @Equation1724 Fin5 refa695_inst.
Proof. unfold Equation1724, magma_op, refa695_inst, refa695_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa695_not1644 : ~ @Equation1644 Fin5 refa695_inst.
Proof. unfold Equation1644. intro H. specialize (H F5_0 F5_1). unfold magma_op, refa695_inst, refa695_op in H. discriminate H. Qed.

Lemma refa695_not1647 : ~ @Equation1647 Fin5 refa695_inst.
Proof. unfold Equation1647. intro H. specialize (H F5_0 F5_1). unfold magma_op, refa695_inst, refa695_op in H. discriminate H. Qed.

Lemma refa695_not1657 : ~ @Equation1657 Fin5 refa695_inst.
Proof. unfold Equation1657. intro H. specialize (H F5_0 F5_1). unfold magma_op, refa695_inst, refa695_op in H. discriminate H. Qed.

Lemma refa695_not4118 : ~ @Equation4118 Fin5 refa695_inst.
Proof. unfold Equation4118. intro H. specialize (H F5_0 F5_1). unfold magma_op, refa695_inst, refa695_op in H. discriminate H. Qed.

Lemma refa695_not4128 : ~ @Equation4128 Fin5 refa695_inst.
Proof. unfold Equation4128. intro H. specialize (H F5_0 F5_1). unfold magma_op, refa695_inst, refa695_op in H. discriminate H. Qed.

Lemma refa695_not4155 : ~ @Equation4155 Fin5 refa695_inst.
Proof. unfold Equation4155. intro H. specialize (H F5_0 F5_2). unfold magma_op, refa695_inst, refa695_op in H. discriminate H. Qed.

Lemma refa695_not4165 : ~ @Equation4165 Fin5 refa695_inst.
Proof. unfold Equation4165. intro H. specialize (H F5_0 F5_1). unfold magma_op, refa695_inst, refa695_op in H. discriminate H. Qed.

(** ---- refa696 (Fin5) ---- *)

Definition refa696_op (x y : Fin5) : Fin5 :=
  match x, y with
  | F5_0, F5_0 => F5_3 | F5_0, F5_1 => F5_2 | F5_0, F5_2 => F5_3 | F5_0, F5_3 => F5_3 | F5_0, F5_4 => F5_2
  | F5_1, F5_0 => F5_4 | F5_1, F5_1 => F5_3 | F5_1, F5_2 => F5_4 | F5_1, F5_3 => F5_3 | F5_1, F5_4 => F5_3
  | F5_2, F5_0 => F5_1 | F5_2, F5_1 => F5_1 | F5_2, F5_2 => F5_3 | F5_2, F5_3 => F5_3 | F5_2, F5_4 => F5_3
  | F5_3, F5_0 => F5_1 | F5_3, F5_1 => F5_0 | F5_3, F5_2 => F5_4 | F5_3, F5_3 => F5_3 | F5_3, F5_4 => F5_2
  | F5_4, F5_0 => F5_3 | F5_4, F5_1 => F5_0 | F5_4, F5_2 => F5_3 | F5_4, F5_3 => F5_3 | F5_4, F5_4 => F5_3
  end.

#[local] Instance refa696_inst : Magma Fin5 := {| magma_op := refa696_op |}.

Lemma refa696_sat1724 : @Equation1724 Fin5 refa696_inst.
Proof. unfold Equation1724, magma_op, refa696_inst, refa696_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa696_not3306 : ~ @Equation3306 Fin5 refa696_inst.
Proof. unfold Equation3306. intro H. specialize (H F5_0 F5_1). unfold magma_op, refa696_inst, refa696_op in H. discriminate H. Qed.

Lemma refa696_not4065 : ~ @Equation4065 Fin5 refa696_inst.
Proof. unfold Equation4065. intro H. specialize (H F5_0). unfold magma_op, refa696_inst, refa696_op in H. discriminate H. Qed.

(** ---- refa697 (Fin6) ---- *)

Definition refa697_op (x y : Fin6) : Fin6 :=
  match x, y with
  | F6_0, F6_0 => F6_1 | F6_0, F6_1 => F6_5 | F6_0, F6_2 => F6_0 | F6_0, F6_3 => F6_4 | F6_0, F6_4 => F6_3 | F6_0, F6_5 => F6_2
  | F6_1, F6_0 => F6_2 | F6_1, F6_1 => F6_5 | F6_1, F6_2 => F6_0 | F6_1, F6_3 => F6_4 | F6_1, F6_4 => F6_1 | F6_1, F6_5 => F6_3
  | F6_2, F6_0 => F6_3 | F6_2, F6_1 => F6_0 | F6_2, F6_2 => F6_4 | F6_2, F6_3 => F6_5 | F6_2, F6_4 => F6_2 | F6_2, F6_5 => F6_1
  | F6_3, F6_0 => F6_1 | F6_3, F6_1 => F6_4 | F6_3, F6_2 => F6_5 | F6_3, F6_3 => F6_0 | F6_3, F6_4 => F6_3 | F6_3, F6_5 => F6_2
  | F6_4, F6_0 => F6_3 | F6_4, F6_1 => F6_0 | F6_4, F6_2 => F6_4 | F6_4, F6_3 => F6_5 | F6_4, F6_4 => F6_2 | F6_4, F6_5 => F6_1
  | F6_5, F6_0 => F6_2 | F6_5, F6_1 => F6_4 | F6_5, F6_2 => F6_5 | F6_5, F6_3 => F6_0 | F6_5, F6_4 => F6_1 | F6_5, F6_5 => F6_3
  end.

#[local] Instance refa697_inst : Magma Fin6 := {| magma_op := refa697_op |}.

Lemma refa697_sat1728 : @Equation1728 Fin6 refa697_inst.
Proof. unfold Equation1728, magma_op, refa697_inst, refa697_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa697_not1223 : ~ @Equation1223 Fin6 refa697_inst.
Proof. unfold Equation1223. intro H. specialize (H F6_0). unfold magma_op, refa697_inst, refa697_op in H. discriminate H. Qed.

Lemma refa697_not1657 : ~ @Equation1657 Fin6 refa697_inst.
Proof. unfold Equation1657. intro H. specialize (H F6_0 F6_1). unfold magma_op, refa697_inst, refa697_op in H. discriminate H. Qed.

Lemma refa697_not3253 : ~ @Equation3253 Fin6 refa697_inst.
Proof. unfold Equation3253. intro H. specialize (H F6_0). unfold magma_op, refa697_inst, refa697_op in H. discriminate H. Qed.

(** ---- refa698 (Fin5) ---- *)

Definition refa698_op (x y : Fin5) : Fin5 :=
  match x, y with
  | F5_0, F5_0 => F5_1 | F5_0, F5_1 => F5_2 | F5_0, F5_2 => F5_1 | F5_0, F5_3 => F5_0 | F5_0, F5_4 => F5_2
  | F5_1, F5_0 => F5_3 | F5_1, F5_1 => F5_1 | F5_1, F5_2 => F5_4 | F5_1, F5_3 => F5_0 | F5_1, F5_4 => F5_2
  | F5_2, F5_0 => F5_1 | F5_2, F5_1 => F5_1 | F5_2, F5_2 => F5_1 | F5_2, F5_3 => F5_0 | F5_2, F5_4 => F5_2
  | F5_3, F5_0 => F5_3 | F5_3, F5_1 => F5_2 | F5_3, F5_2 => F5_1 | F5_3, F5_3 => F5_1 | F5_3, F5_4 => F5_1
  | F5_4, F5_0 => F5_3 | F5_4, F5_1 => F5_1 | F5_4, F5_2 => F5_4 | F5_4, F5_3 => F5_0 | F5_4, F5_4 => F5_1
  end.

#[local] Instance refa698_inst : Magma Fin5 := {| magma_op := refa698_op |}.

Lemma refa698_sat1738 : @Equation1738 Fin5 refa698_inst.
Proof. unfold Equation1738, magma_op, refa698_inst, refa698_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa698_not1020 : ~ @Equation1020 Fin5 refa698_inst.
Proof. unfold Equation1020. intro H. specialize (H F5_0). unfold magma_op, refa698_inst, refa698_op in H. discriminate H. Qed.

Lemma refa698_not1241 : ~ @Equation1241 Fin5 refa698_inst.
Proof. unfold Equation1241. intro H. specialize (H F5_0 F5_1). unfold magma_op, refa698_inst, refa698_op in H. discriminate H. Qed.

Lemma refa698_not1644 : ~ @Equation1644 Fin5 refa698_inst.
Proof. unfold Equation1644. intro H. specialize (H F5_1 F5_0). unfold magma_op, refa698_inst, refa698_op in H. discriminate H. Qed.

Lemma refa698_not1654 : ~ @Equation1654 Fin5 refa698_inst.
Proof. unfold Equation1654. intro H. specialize (H F5_1 F5_0). unfold magma_op, refa698_inst, refa698_op in H. discriminate H. Qed.

Lemma refa698_not1657 : ~ @Equation1657 Fin5 refa698_inst.
Proof. unfold Equation1657. intro H. specialize (H F5_1 F5_0). unfold magma_op, refa698_inst, refa698_op in H. discriminate H. Qed.

(** ---- refa699 (Fin5) ---- *)

Definition refa699_op (x y : Fin5) : Fin5 :=
  match x, y with
  | F5_0, F5_0 => F5_1 | F5_0, F5_1 => F5_4 | F5_0, F5_2 => F5_1 | F5_0, F5_3 => F5_4 | F5_0, F5_4 => F5_4
  | F5_1, F5_0 => F5_2 | F5_1, F5_1 => F5_1 | F5_1, F5_2 => F5_1 | F5_1, F5_3 => F5_2 | F5_1, F5_4 => F5_1
  | F5_2, F5_0 => F5_3 | F5_2, F5_1 => F5_3 | F5_2, F5_2 => F5_1 | F5_2, F5_3 => F5_3 | F5_2, F5_4 => F5_0
  | F5_3, F5_0 => F5_2 | F5_3, F5_1 => F5_2 | F5_3, F5_2 => F5_2 | F5_3, F5_3 => F5_1 | F5_3, F5_4 => F5_2
  | F5_4, F5_0 => F5_0 | F5_4, F5_1 => F5_0 | F5_4, F5_2 => F5_1 | F5_4, F5_3 => F5_1 | F5_4, F5_4 => F5_1
  end.

#[local] Instance refa699_inst : Magma Fin5 := {| magma_op := refa699_op |}.

Lemma refa699_sat1845 : @Equation1845 Fin5 refa699_inst.
Proof. unfold Equation1845, magma_op, refa699_inst, refa699_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa699_not2441 : ~ @Equation2441 Fin5 refa699_inst.
Proof. unfold Equation2441. intro H. specialize (H F5_0). unfold magma_op, refa699_inst, refa699_op in H. discriminate H. Qed.

(** ---- refa7 (Fin9) ---- *)

Definition refa7_op (x y : Fin9) : Fin9 :=
  match x, y with
  | F9_0, F9_0 => F9_0 | F9_0, F9_1 => F9_1 | F9_0, F9_2 => F9_2 | F9_0, F9_3 => F9_3 | F9_0, F9_4 => F9_4 | F9_0, F9_5 => F9_5 | F9_0, F9_6 => F9_6 | F9_0, F9_7 => F9_7 | F9_0, F9_8 => F9_8
  | F9_1, F9_0 => F9_3 | F9_1, F9_1 => F9_2 | F9_1, F9_2 => F9_5 | F9_1, F9_3 => F9_8 | F9_1, F9_4 => F9_6 | F9_1, F9_5 => F9_1 | F9_1, F9_6 => F9_7 | F9_1, F9_7 => F9_4 | F9_1, F9_8 => F9_0
  | F9_2, F9_0 => F9_1 | F9_2, F9_1 => F9_4 | F9_2, F9_2 => F9_6 | F9_2, F9_3 => F9_2 | F9_2, F9_4 => F9_0 | F9_2, F9_5 => F9_7 | F9_2, F9_6 => F9_3 | F9_2, F9_7 => F9_8 | F9_2, F9_8 => F9_5
  | F9_3, F9_0 => F9_5 | F9_3, F9_1 => F9_7 | F9_3, F9_2 => F9_4 | F9_3, F9_3 => F9_1 | F9_3, F9_4 => F9_8 | F9_3, F9_5 => F9_6 | F9_3, F9_6 => F9_0 | F9_3, F9_7 => F9_3 | F9_3, F9_8 => F9_2
  | F9_4, F9_0 => F9_8 | F9_4, F9_1 => F9_5 | F9_4, F9_2 => F9_1 | F9_4, F9_3 => F9_0 | F9_4, F9_4 => F9_7 | F9_4, F9_5 => F9_2 | F9_4, F9_6 => F9_4 | F9_4, F9_7 => F9_6 | F9_4, F9_8 => F9_3
  | F9_5, F9_0 => F9_7 | F9_5, F9_1 => F9_8 | F9_5, F9_2 => F9_0 | F9_5, F9_3 => F9_4 | F9_5, F9_4 => F9_5 | F9_5, F9_5 => F9_3 | F9_5, F9_6 => F9_1 | F9_5, F9_7 => F9_2 | F9_5, F9_8 => F9_6
  | F9_6, F9_0 => F9_2 | F9_6, F9_1 => F9_6 | F9_6, F9_2 => F9_7 | F9_6, F9_3 => F9_5 | F9_6, F9_4 => F9_3 | F9_6, F9_5 => F9_4 | F9_6, F9_6 => F9_8 | F9_6, F9_7 => F9_0 | F9_6, F9_8 => F9_1
  | F9_7, F9_0 => F9_4 | F9_7, F9_1 => F9_0 | F9_7, F9_2 => F9_3 | F9_7, F9_3 => F9_6 | F9_7, F9_4 => F9_1 | F9_7, F9_5 => F9_8 | F9_7, F9_6 => F9_2 | F9_7, F9_7 => F9_5 | F9_7, F9_8 => F9_7
  | F9_8, F9_0 => F9_6 | F9_8, F9_1 => F9_3 | F9_8, F9_2 => F9_8 | F9_8, F9_3 => F9_7 | F9_8, F9_4 => F9_2 | F9_8, F9_5 => F9_0 | F9_8, F9_6 => F9_5 | F9_8, F9_7 => F9_1 | F9_8, F9_8 => F9_4
  end.

#[local] Instance refa7_inst : Magma Fin9 := {| magma_op := refa7_op |}.

Lemma refa7_sat2091 : @Equation2091 Fin9 refa7_inst.
Proof. unfold Equation2091, magma_op, refa7_inst, refa7_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa7_sat2098 : @Equation2098 Fin9 refa7_inst.
Proof. unfold Equation2098, magma_op, refa7_inst, refa7_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa7_not2644 : ~ @Equation2644 Fin9 refa7_inst.
Proof. unfold Equation2644. intro H. specialize (H F9_1). unfold magma_op, refa7_inst, refa7_op in H. discriminate H. Qed.

Lemma refa7_not2847 : ~ @Equation2847 Fin9 refa7_inst.
Proof. unfold Equation2847. intro H. specialize (H F9_1). unfold magma_op, refa7_inst, refa7_op in H. discriminate H. Qed.

Lemma refa7_not3050 : ~ @Equation3050 Fin9 refa7_inst.
Proof. unfold Equation3050. intro H. specialize (H F9_1). unfold magma_op, refa7_inst, refa7_op in H. discriminate H. Qed.

Lemma refa7_not3253 : ~ @Equation3253 Fin9 refa7_inst.
Proof. unfold Equation3253. intro H. specialize (H F9_1). unfold magma_op, refa7_inst, refa7_op in H. discriminate H. Qed.

Lemma refa7_not3456 : ~ @Equation3456 Fin9 refa7_inst.
Proof. unfold Equation3456. intro H. specialize (H F9_1). unfold magma_op, refa7_inst, refa7_op in H. discriminate H. Qed.

Lemma refa7_not3659 : ~ @Equation3659 Fin9 refa7_inst.
Proof. unfold Equation3659. intro H. specialize (H F9_1). unfold magma_op, refa7_inst, refa7_op in H. discriminate H. Qed.

Lemma refa7_not3862 : ~ @Equation3862 Fin9 refa7_inst.
Proof. unfold Equation3862. intro H. specialize (H F9_1). unfold magma_op, refa7_inst, refa7_op in H. discriminate H. Qed.

Lemma refa7_not4065 : ~ @Equation4065 Fin9 refa7_inst.
Proof. unfold Equation4065. intro H. specialize (H F9_1). unfold magma_op, refa7_inst, refa7_op in H. discriminate H. Qed.

Lemma refa7_not4268 : ~ @Equation4268 Fin9 refa7_inst.
Proof. unfold Equation4268. intro H. specialize (H F9_0 F9_1). unfold magma_op, refa7_inst, refa7_op in H. discriminate H. Qed.

Lemma refa7_not4269 : ~ @Equation4269 Fin9 refa7_inst.
Proof. unfold Equation4269. intro H. specialize (H F9_0 F9_1). unfold magma_op, refa7_inst, refa7_op in H. discriminate H. Qed.

Lemma refa7_not4270 : ~ @Equation4270 Fin9 refa7_inst.
Proof. unfold Equation4270. intro H. specialize (H F9_0 F9_1). unfold magma_op, refa7_inst, refa7_op in H. discriminate H. Qed.

Lemma refa7_not4272 : ~ @Equation4272 Fin9 refa7_inst.
Proof. unfold Equation4272. intro H. specialize (H F9_0 F9_1). unfold magma_op, refa7_inst, refa7_op in H. discriminate H. Qed.

Lemma refa7_not4273 : ~ @Equation4273 Fin9 refa7_inst.
Proof. unfold Equation4273. intro H. specialize (H F9_0 F9_1). unfold magma_op, refa7_inst, refa7_op in H. discriminate H. Qed.

Lemma refa7_not4275 : ~ @Equation4275 Fin9 refa7_inst.
Proof. unfold Equation4275. intro H. specialize (H F9_0 F9_1). unfold magma_op, refa7_inst, refa7_op in H. discriminate H. Qed.

Lemma refa7_not4276 : ~ @Equation4276 Fin9 refa7_inst.
Proof. unfold Equation4276. intro H. specialize (H F9_0 F9_1). unfold magma_op, refa7_inst, refa7_op in H. discriminate H. Qed.

Lemma refa7_not4283 : ~ @Equation4283 Fin9 refa7_inst.
Proof. unfold Equation4283. intro H. specialize (H F9_0 F9_1). unfold magma_op, refa7_inst, refa7_op in H. discriminate H. Qed.

Lemma refa7_not4284 : ~ @Equation4284 Fin9 refa7_inst.
Proof. unfold Equation4284. intro H. specialize (H F9_0 F9_1). unfold magma_op, refa7_inst, refa7_op in H. discriminate H. Qed.

Lemma refa7_not4290 : ~ @Equation4290 Fin9 refa7_inst.
Proof. unfold Equation4290. intro H. specialize (H F9_0 F9_1). unfold magma_op, refa7_inst, refa7_op in H. discriminate H. Qed.

Lemma refa7_not4291 : ~ @Equation4291 Fin9 refa7_inst.
Proof. unfold Equation4291. intro H. specialize (H F9_0 F9_1). unfold magma_op, refa7_inst, refa7_op in H. discriminate H. Qed.

Lemma refa7_not4293 : ~ @Equation4293 Fin9 refa7_inst.
Proof. unfold Equation4293. intro H. specialize (H F9_0 F9_1). unfold magma_op, refa7_inst, refa7_op in H. discriminate H. Qed.

Lemma refa7_not4314 : ~ @Equation4314 Fin9 refa7_inst.
Proof. unfold Equation4314. intro H. specialize (H F9_0 F9_1). unfold magma_op, refa7_inst, refa7_op in H. discriminate H. Qed.

Lemma refa7_not4321 : ~ @Equation4321 Fin9 refa7_inst.
Proof. unfold Equation4321. intro H. specialize (H F9_0 F9_1). unfold magma_op, refa7_inst, refa7_op in H. discriminate H. Qed.

Lemma refa7_not4343 : ~ @Equation4343 Fin9 refa7_inst.
Proof. unfold Equation4343. intro H. specialize (H F9_0 F9_1). unfold magma_op, refa7_inst, refa7_op in H. discriminate H. Qed.

Lemma refa7_not4380 : ~ @Equation4380 Fin9 refa7_inst.
Proof. unfold Equation4380. intro H. specialize (H F9_1). unfold magma_op, refa7_inst, refa7_op in H. discriminate H. Qed.

Lemma refa7_not4583 : ~ @Equation4583 Fin9 refa7_inst.
Proof. unfold Equation4583. intro H. specialize (H F9_0 F9_1). unfold magma_op, refa7_inst, refa7_op in H. discriminate H. Qed.

Lemma refa7_not4584 : ~ @Equation4584 Fin9 refa7_inst.
Proof. unfold Equation4584. intro H. specialize (H F9_0 F9_1). unfold magma_op, refa7_inst, refa7_op in H. discriminate H. Qed.

Lemma refa7_not4585 : ~ @Equation4585 Fin9 refa7_inst.
Proof. unfold Equation4585. intro H. specialize (H F9_0 F9_1). unfold magma_op, refa7_inst, refa7_op in H. discriminate H. Qed.

Lemma refa7_not4587 : ~ @Equation4587 Fin9 refa7_inst.
Proof. unfold Equation4587. intro H. specialize (H F9_0 F9_1). unfold magma_op, refa7_inst, refa7_op in H. discriminate H. Qed.

Lemma refa7_not4588 : ~ @Equation4588 Fin9 refa7_inst.
Proof. unfold Equation4588. intro H. specialize (H F9_0 F9_1). unfold magma_op, refa7_inst, refa7_op in H. discriminate H. Qed.

Lemma refa7_not4590 : ~ @Equation4590 Fin9 refa7_inst.
Proof. unfold Equation4590. intro H. specialize (H F9_0 F9_1). unfold magma_op, refa7_inst, refa7_op in H. discriminate H. Qed.

Lemma refa7_not4591 : ~ @Equation4591 Fin9 refa7_inst.
Proof. unfold Equation4591. intro H. specialize (H F9_0 F9_1). unfold magma_op, refa7_inst, refa7_op in H. discriminate H. Qed.

Lemma refa7_not4599 : ~ @Equation4599 Fin9 refa7_inst.
Proof. unfold Equation4599. intro H. specialize (H F9_0 F9_1). unfold magma_op, refa7_inst, refa7_op in H. discriminate H. Qed.

Lemma refa7_not4605 : ~ @Equation4605 Fin9 refa7_inst.
Proof. unfold Equation4605. intro H. specialize (H F9_0 F9_1). unfold magma_op, refa7_inst, refa7_op in H. discriminate H. Qed.

Lemma refa7_not4606 : ~ @Equation4606 Fin9 refa7_inst.
Proof. unfold Equation4606. intro H. specialize (H F9_0 F9_1). unfold magma_op, refa7_inst, refa7_op in H. discriminate H. Qed.

Lemma refa7_not4629 : ~ @Equation4629 Fin9 refa7_inst.
Proof. unfold Equation4629. intro H. specialize (H F9_0 F9_1). unfold magma_op, refa7_inst, refa7_op in H. discriminate H. Qed.

Lemma refa7_not4635 : ~ @Equation4635 Fin9 refa7_inst.
Proof. unfold Equation4635. intro H. specialize (H F9_0 F9_1). unfold magma_op, refa7_inst, refa7_op in H. discriminate H. Qed.

Lemma refa7_not4636 : ~ @Equation4636 Fin9 refa7_inst.
Proof. unfold Equation4636. intro H. specialize (H F9_0 F9_1). unfold magma_op, refa7_inst, refa7_op in H. discriminate H. Qed.

Lemma refa7_not4658 : ~ @Equation4658 Fin9 refa7_inst.
Proof. unfold Equation4658. intro H. specialize (H F9_0 F9_1). unfold magma_op, refa7_inst, refa7_op in H. discriminate H. Qed.

(** ---- refa70 (Fin3) ---- *)

Definition refa70_op (x y : Fin3) : Fin3 :=
  match x, y with
  | F3_0, F3_0 => F3_0 | F3_0, F3_1 => F3_0 | F3_0, F3_2 => F3_0
  | F3_1, F3_0 => F3_1 | F3_1, F3_1 => F3_1 | F3_1, F3_2 => F3_1
  | F3_2, F3_0 => F3_1 | F3_2, F3_1 => F3_0 | F3_2, F3_2 => F3_0
  end.

#[local] Instance refa70_inst : Magma Fin3 := {| magma_op := refa70_op |}.

Lemma refa70_sat379 : @Equation379 Fin3 refa70_inst.
Proof. unfold Equation379, magma_op, refa70_inst, refa70_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa70_not307 : ~ @Equation307 Fin3 refa70_inst.
Proof. unfold Equation307. intro H. specialize (H F3_2). unfold magma_op, refa70_inst, refa70_op in H. discriminate H. Qed.

Lemma refa70_not3255 : ~ @Equation3255 Fin3 refa70_inst.
Proof. unfold Equation3255. intro H. specialize (H F3_2 F3_1). unfold magma_op, refa70_inst, refa70_op in H. discriminate H. Qed.

Lemma refa70_not3256 : ~ @Equation3256 Fin3 refa70_inst.
Proof. unfold Equation3256. intro H. specialize (H F3_2 F3_1). unfold magma_op, refa70_inst, refa70_op in H. discriminate H. Qed.

Lemma refa70_not3258 : ~ @Equation3258 Fin3 refa70_inst.
Proof. unfold Equation3258. intro H. specialize (H F3_2 F3_0). unfold magma_op, refa70_inst, refa70_op in H. discriminate H. Qed.

Lemma refa70_not3259 : ~ @Equation3259 Fin3 refa70_inst.
Proof. unfold Equation3259. intro H. specialize (H F3_2 F3_0). unfold magma_op, refa70_inst, refa70_op in H. discriminate H. Qed.

Lemma refa70_not3261 : ~ @Equation3261 Fin3 refa70_inst.
Proof. unfold Equation3261. intro H. specialize (H F3_2 F3_0). unfold magma_op, refa70_inst, refa70_op in H. discriminate H. Qed.

Lemma refa70_not3262 : ~ @Equation3262 Fin3 refa70_inst.
Proof. unfold Equation3262. intro H. specialize (H F3_2 F3_0). unfold magma_op, refa70_inst, refa70_op in H. discriminate H. Qed.

Lemma refa70_not3308 : ~ @Equation3308 Fin3 refa70_inst.
Proof. unfold Equation3308. intro H. specialize (H F3_2 F3_0). unfold magma_op, refa70_inst, refa70_op in H. discriminate H. Qed.

Lemma refa70_not3309 : ~ @Equation3309 Fin3 refa70_inst.
Proof. unfold Equation3309. intro H. specialize (H F3_2 F3_0). unfold magma_op, refa70_inst, refa70_op in H. discriminate H. Qed.

Lemma refa70_not3456 : ~ @Equation3456 Fin3 refa70_inst.
Proof. unfold Equation3456. intro H. specialize (H F3_2). unfold magma_op, refa70_inst, refa70_op in H. discriminate H. Qed.

Lemma refa70_not3664 : ~ @Equation3664 Fin3 refa70_inst.
Proof. unfold Equation3664. intro H. specialize (H F3_2 F3_0). unfold magma_op, refa70_inst, refa70_op in H. discriminate H. Qed.

Lemma refa70_not3665 : ~ @Equation3665 Fin3 refa70_inst.
Proof. unfold Equation3665. intro H. specialize (H F3_2 F3_0). unfold magma_op, refa70_inst, refa70_op in H. discriminate H. Qed.

Lemma refa70_not3667 : ~ @Equation3667 Fin3 refa70_inst.
Proof. unfold Equation3667. intro H. specialize (H F3_2 F3_0). unfold magma_op, refa70_inst, refa70_op in H. discriminate H. Qed.

Lemma refa70_not3668 : ~ @Equation3668 Fin3 refa70_inst.
Proof. unfold Equation3668. intro H. specialize (H F3_2 F3_0). unfold magma_op, refa70_inst, refa70_op in H. discriminate H. Qed.

Lemma refa70_not3712 : ~ @Equation3712 Fin3 refa70_inst.
Proof. unfold Equation3712. intro H. specialize (H F3_2 F3_0). unfold magma_op, refa70_inst, refa70_op in H. discriminate H. Qed.

Lemma refa70_not3714 : ~ @Equation3714 Fin3 refa70_inst.
Proof. unfold Equation3714. intro H. specialize (H F3_2 F3_0). unfold magma_op, refa70_inst, refa70_op in H. discriminate H. Qed.

Lemma refa70_not3862 : ~ @Equation3862 Fin3 refa70_inst.
Proof. unfold Equation3862. intro H. specialize (H F3_2). unfold magma_op, refa70_inst, refa70_op in H. discriminate H. Qed.

Lemma refa70_not4070 : ~ @Equation4070 Fin3 refa70_inst.
Proof. unfold Equation4070. intro H. specialize (H F3_2 F3_0). unfold magma_op, refa70_inst, refa70_op in H. discriminate H. Qed.

Lemma refa70_not4071 : ~ @Equation4071 Fin3 refa70_inst.
Proof. unfold Equation4071. intro H. specialize (H F3_2 F3_0). unfold magma_op, refa70_inst, refa70_op in H. discriminate H. Qed.

Lemma refa70_not4073 : ~ @Equation4073 Fin3 refa70_inst.
Proof. unfold Equation4073. intro H. specialize (H F3_2 F3_0). unfold magma_op, refa70_inst, refa70_op in H. discriminate H. Qed.

Lemma refa70_not4074 : ~ @Equation4074 Fin3 refa70_inst.
Proof. unfold Equation4074. intro H. specialize (H F3_2 F3_0). unfold magma_op, refa70_inst, refa70_op in H. discriminate H. Qed.

Lemma refa70_not4118 : ~ @Equation4118 Fin3 refa70_inst.
Proof. unfold Equation4118. intro H. specialize (H F3_2 F3_0). unfold magma_op, refa70_inst, refa70_op in H. discriminate H. Qed.

Lemma refa70_not4120 : ~ @Equation4120 Fin3 refa70_inst.
Proof. unfold Equation4120. intro H. specialize (H F3_2 F3_0). unfold magma_op, refa70_inst, refa70_op in H. discriminate H. Qed.

Lemma refa70_not4121 : ~ @Equation4121 Fin3 refa70_inst.
Proof. unfold Equation4121. intro H. specialize (H F3_2 F3_0). unfold magma_op, refa70_inst, refa70_op in H. discriminate H. Qed.

Lemma refa70_not4268 : ~ @Equation4268 Fin3 refa70_inst.
Proof. unfold Equation4268. intro H. specialize (H F3_2 F3_0). unfold magma_op, refa70_inst, refa70_op in H. discriminate H. Qed.

Lemma refa70_not4269 : ~ @Equation4269 Fin3 refa70_inst.
Proof. unfold Equation4269. intro H. specialize (H F3_2 F3_1). unfold magma_op, refa70_inst, refa70_op in H. discriminate H. Qed.

Lemma refa70_not4270 : ~ @Equation4270 Fin3 refa70_inst.
Proof. unfold Equation4270. intro H. specialize (H F3_2 F3_1). unfold magma_op, refa70_inst, refa70_op in H. discriminate H. Qed.

Lemma refa70_not4283 : ~ @Equation4283 Fin3 refa70_inst.
Proof. unfold Equation4283. intro H. specialize (H F3_2 F3_0). unfold magma_op, refa70_inst, refa70_op in H. discriminate H. Qed.

Lemma refa70_not4284 : ~ @Equation4284 Fin3 refa70_inst.
Proof. unfold Equation4284. intro H. specialize (H F3_2 F3_0). unfold magma_op, refa70_inst, refa70_op in H. discriminate H. Qed.

Lemma refa70_not4380 : ~ @Equation4380 Fin3 refa70_inst.
Proof. unfold Equation4380. intro H. specialize (H F3_2). unfold magma_op, refa70_inst, refa70_op in H. discriminate H. Qed.

Lemma refa70_not4584 : ~ @Equation4584 Fin3 refa70_inst.
Proof. unfold Equation4584. intro H. specialize (H F3_2 F3_0). unfold magma_op, refa70_inst, refa70_op in H. discriminate H. Qed.

Lemma refa70_not4585 : ~ @Equation4585 Fin3 refa70_inst.
Proof. unfold Equation4585. intro H. specialize (H F3_2 F3_0). unfold magma_op, refa70_inst, refa70_op in H. discriminate H. Qed.

Lemma refa70_not4598 : ~ @Equation4598 Fin3 refa70_inst.
Proof. unfold Equation4598. intro H. specialize (H F3_2 F3_0). unfold magma_op, refa70_inst, refa70_op in H. discriminate H. Qed.

Lemma refa70_not4599 : ~ @Equation4599 Fin3 refa70_inst.
Proof. unfold Equation4599. intro H. specialize (H F3_2 F3_0). unfold magma_op, refa70_inst, refa70_op in H. discriminate H. Qed.

(** ---- refa700 (Fin5) ---- *)

Definition refa700_op (x y : Fin5) : Fin5 :=
  match x, y with
  | F5_0, F5_0 => F5_0 | F5_0, F5_1 => F5_2 | F5_0, F5_2 => F5_0 | F5_0, F5_3 => F5_0 | F5_0, F5_4 => F5_3
  | F5_1, F5_0 => F5_3 | F5_1, F5_1 => F5_4 | F5_1, F5_2 => F5_4 | F5_1, F5_3 => F5_1 | F5_1, F5_4 => F5_4
  | F5_2, F5_0 => F5_3 | F5_2, F5_1 => F5_1 | F5_2, F5_2 => F5_3 | F5_2, F5_3 => F5_3 | F5_2, F5_4 => F5_3
  | F5_3, F5_0 => F5_2 | F5_3, F5_1 => F5_2 | F5_3, F5_2 => F5_2 | F5_3, F5_3 => F5_2 | F5_3, F5_4 => F5_3
  | F5_4, F5_0 => F5_2 | F5_4, F5_1 => F5_1 | F5_4, F5_2 => F5_4 | F5_4, F5_3 => F5_1 | F5_4, F5_4 => F5_1
  end.

#[local] Instance refa700_inst : Magma Fin5 := {| magma_op := refa700_op |}.

Lemma refa700_sat1849 : @Equation1849 Fin5 refa700_inst.
Proof. unfold Equation1849, magma_op, refa700_inst, refa700_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa700_not2449 : ~ @Equation2449 Fin5 refa700_inst.
Proof. unfold Equation2449. intro H. specialize (H F5_0 F5_1). unfold magma_op, refa700_inst, refa700_op in H. discriminate H. Qed.

Lemma refa700_not3459 : ~ @Equation3459 Fin5 refa700_inst.
Proof. unfold Equation3459. intro H. specialize (H F5_0 F5_1). unfold magma_op, refa700_inst, refa700_op in H. discriminate H. Qed.

(** ---- refa701 (Fin5) ---- *)

Definition refa701_op (x y : Fin5) : Fin5 :=
  match x, y with
  | F5_0, F5_0 => F5_2 | F5_0, F5_1 => F5_3 | F5_0, F5_2 => F5_3 | F5_0, F5_3 => F5_2 | F5_0, F5_4 => F5_0
  | F5_1, F5_0 => F5_1 | F5_1, F5_1 => F5_2 | F5_1, F5_2 => F5_4 | F5_1, F5_3 => F5_4 | F5_1, F5_4 => F5_2
  | F5_2, F5_0 => F5_2 | F5_2, F5_1 => F5_2 | F5_2, F5_2 => F5_2 | F5_2, F5_3 => F5_2 | F5_2, F5_4 => F5_2
  | F5_3, F5_0 => F5_2 | F5_3, F5_1 => F5_3 | F5_3, F5_2 => F5_0 | F5_3, F5_3 => F5_2 | F5_3, F5_4 => F5_0
  | F5_4, F5_0 => F5_1 | F5_4, F5_1 => F5_3 | F5_4, F5_2 => F5_1 | F5_4, F5_3 => F5_4 | F5_4, F5_4 => F5_2
  end.

#[local] Instance refa701_inst : Magma Fin5 := {| magma_op := refa701_op |}.

Lemma refa701_sat1855 : @Equation1855 Fin5 refa701_inst.
Proof. unfold Equation1855, magma_op, refa701_inst, refa701_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa701_not1834 : ~ @Equation1834 Fin5 refa701_inst.
Proof. unfold Equation1834. intro H. specialize (H F5_0 F5_1). unfold magma_op, refa701_inst, refa701_op in H. discriminate H. Qed.

Lemma refa701_not1850 : ~ @Equation1850 Fin5 refa701_inst.
Proof. unfold Equation1850. intro H. specialize (H F5_0 F5_1). unfold magma_op, refa701_inst, refa701_op in H. discriminate H. Qed.

Lemma refa701_not1860 : ~ @Equation1860 Fin5 refa701_inst.
Proof. unfold Equation1860. intro H. specialize (H F5_0 F5_1). unfold magma_op, refa701_inst, refa701_op in H. discriminate H. Qed.

Lemma refa701_not3253 : ~ @Equation3253 Fin5 refa701_inst.
Proof. unfold Equation3253. intro H. specialize (H F5_4). unfold magma_op, refa701_inst, refa701_op in H. discriminate H. Qed.

Lemma refa701_not4070 : ~ @Equation4070 Fin5 refa701_inst.
Proof. unfold Equation4070. intro H. specialize (H F5_1 F5_2). unfold magma_op, refa701_inst, refa701_op in H. discriminate H. Qed.

Lemma refa701_not4071 : ~ @Equation4071 Fin5 refa701_inst.
Proof. unfold Equation4071. intro H. specialize (H F5_1 F5_2). unfold magma_op, refa701_inst, refa701_op in H. discriminate H. Qed.

Lemma refa701_not4073 : ~ @Equation4073 Fin5 refa701_inst.
Proof. unfold Equation4073. intro H. specialize (H F5_1 F5_3). unfold magma_op, refa701_inst, refa701_op in H. discriminate H. Qed.

Lemma refa701_not4598 : ~ @Equation4598 Fin5 refa701_inst.
Proof. unfold Equation4598. intro H. specialize (H F5_1 F5_2). unfold magma_op, refa701_inst, refa701_op in H. discriminate H. Qed.

Lemma refa701_not4631 : ~ @Equation4631 Fin5 refa701_inst.
Proof. unfold Equation4631. intro H. specialize (H F5_1 F5_0 F5_2). unfold magma_op, refa701_inst, refa701_op in H. discriminate H. Qed.

(** ---- refa702 (Fin5) ---- *)

Definition refa702_op (x y : Fin5) : Fin5 :=
  match x, y with
  | F5_0, F5_0 => F5_2 | F5_0, F5_1 => F5_2 | F5_0, F5_2 => F5_1 | F5_0, F5_3 => F5_1 | F5_0, F5_4 => F5_0
  | F5_1, F5_0 => F5_3 | F5_1, F5_1 => F5_2 | F5_1, F5_2 => F5_0 | F5_1, F5_3 => F5_1 | F5_1, F5_4 => F5_0
  | F5_2, F5_0 => F5_2 | F5_2, F5_1 => F5_2 | F5_2, F5_2 => F5_2 | F5_2, F5_3 => F5_2 | F5_2, F5_4 => F5_2
  | F5_3, F5_0 => F5_3 | F5_3, F5_1 => F5_4 | F5_3, F5_2 => F5_4 | F5_3, F5_3 => F5_2 | F5_3, F5_4 => F5_2
  | F5_4, F5_0 => F5_3 | F5_4, F5_1 => F5_2 | F5_4, F5_2 => F5_3 | F5_4, F5_3 => F5_2 | F5_4, F5_4 => F5_2
  end.

#[local] Instance refa702_inst : Magma Fin5 := {| magma_op := refa702_op |}.

Lemma refa702_sat1855 : @Equation1855 Fin5 refa702_inst.
Proof. unfold Equation1855, magma_op, refa702_inst, refa702_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa702_not4131 : ~ @Equation4131 Fin5 refa702_inst.
Proof. unfold Equation4131. intro H. specialize (H F5_3 F5_1). unfold magma_op, refa702_inst, refa702_op in H. discriminate H. Qed.

(** ---- refa703 (Fin5) ---- *)

Definition refa703_op (x y : Fin5) : Fin5 :=
  match x, y with
  | F5_0, F5_0 => F5_1 | F5_0, F5_1 => F5_4 | F5_0, F5_2 => F5_4 | F5_0, F5_3 => F5_1 | F5_0, F5_4 => F5_4
  | F5_1, F5_0 => F5_2 | F5_1, F5_1 => F5_4 | F5_1, F5_2 => F5_4 | F5_1, F5_3 => F5_1 | F5_1, F5_4 => F5_4
  | F5_2, F5_0 => F5_2 | F5_2, F5_1 => F5_3 | F5_2, F5_2 => F5_2 | F5_2, F5_3 => F5_1 | F5_2, F5_4 => F5_2
  | F5_3, F5_0 => F5_2 | F5_3, F5_1 => F5_3 | F5_3, F5_2 => F5_2 | F5_3, F5_3 => F5_1 | F5_3, F5_4 => F5_2
  | F5_4, F5_0 => F5_1 | F5_4, F5_1 => F5_0 | F5_4, F5_2 => F5_0 | F5_4, F5_3 => F5_1 | F5_4, F5_4 => F5_1
  end.

#[local] Instance refa703_inst : Magma Fin5 := {| magma_op := refa703_op |}.

Lemma refa703_sat1863 : @Equation1863 Fin5 refa703_inst.
Proof. unfold Equation1863, magma_op, refa703_inst, refa703_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa703_not4065 : ~ @Equation4065 Fin5 refa703_inst.
Proof. unfold Equation4065. intro H. specialize (H F5_0). unfold magma_op, refa703_inst, refa703_op in H. discriminate H. Qed.

(** ---- refa704 (Fin5) ---- *)

Definition refa704_op (x y : Fin5) : Fin5 :=
  match x, y with
  | F5_0, F5_0 => F5_1 | F5_0, F5_1 => F5_2 | F5_0, F5_2 => F5_3 | F5_0, F5_3 => F5_2 | F5_0, F5_4 => F5_1
  | F5_1, F5_0 => F5_0 | F5_1, F5_1 => F5_4 | F5_1, F5_2 => F5_0 | F5_1, F5_3 => F5_0 | F5_1, F5_4 => F5_0
  | F5_2, F5_0 => F5_3 | F5_2, F5_1 => F5_0 | F5_2, F5_2 => F5_3 | F5_2, F5_3 => F5_0 | F5_2, F5_4 => F5_3
  | F5_3, F5_0 => F5_2 | F5_3, F5_1 => F5_0 | F5_3, F5_2 => F5_0 | F5_3, F5_3 => F5_2 | F5_3, F5_4 => F5_2
  | F5_4, F5_0 => F5_1 | F5_4, F5_1 => F5_1 | F5_4, F5_2 => F5_1 | F5_4, F5_3 => F5_1 | F5_4, F5_4 => F5_1
  end.

#[local] Instance refa704_inst : Magma Fin5 := {| magma_op := refa704_op |}.

Lemma refa704_sat1868 : @Equation1868 Fin5 refa704_inst.
Proof. unfold Equation1868, magma_op, refa704_inst, refa704_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa704_not151 : ~ @Equation151 Fin5 refa704_inst.
Proof. unfold Equation151. intro H. specialize (H F5_0). unfold magma_op, refa704_inst, refa704_op in H. discriminate H. Qed.

Lemma refa704_not1428 : ~ @Equation1428 Fin5 refa704_inst.
Proof. unfold Equation1428. intro H. specialize (H F5_0 F5_1). unfold magma_op, refa704_inst, refa704_op in H. discriminate H. Qed.

Lemma refa704_not1429 : ~ @Equation1429 Fin5 refa704_inst.
Proof. unfold Equation1429. intro H. specialize (H F5_0 F5_1). unfold magma_op, refa704_inst, refa704_op in H. discriminate H. Qed.

Lemma refa704_not1435 : ~ @Equation1435 Fin5 refa704_inst.
Proof. unfold Equation1435. intro H. specialize (H F5_0 F5_4). unfold magma_op, refa704_inst, refa704_op in H. discriminate H. Qed.

Lemma refa704_not1629 : ~ @Equation1629 Fin5 refa704_inst.
Proof. unfold Equation1629. intro H. specialize (H F5_4). unfold magma_op, refa704_inst, refa704_op in H. discriminate H. Qed.

Lemma refa704_not1840 : ~ @Equation1840 Fin5 refa704_inst.
Proof. unfold Equation1840. intro H. specialize (H F5_0 F5_1). unfold magma_op, refa704_inst, refa704_op in H. discriminate H. Qed.

Lemma refa704_not1847 : ~ @Equation1847 Fin5 refa704_inst.
Proof. unfold Equation1847. intro H. specialize (H F5_0 F5_1). unfold magma_op, refa704_inst, refa704_op in H. discriminate H. Qed.

Lemma refa704_not1857 : ~ @Equation1857 Fin5 refa704_inst.
Proof. unfold Equation1857. intro H. specialize (H F5_0 F5_1). unfold magma_op, refa704_inst, refa704_op in H. discriminate H. Qed.

Lemma refa704_not1860 : ~ @Equation1860 Fin5 refa704_inst.
Proof. unfold Equation1860. intro H. specialize (H F5_3 F5_4). unfold magma_op, refa704_inst, refa704_op in H. discriminate H. Qed.

Lemma refa704_not2035 : ~ @Equation2035 Fin5 refa704_inst.
Proof. unfold Equation2035. intro H. specialize (H F5_0). unfold magma_op, refa704_inst, refa704_op in H. discriminate H. Qed.

Lemma refa704_not3253 : ~ @Equation3253 Fin5 refa704_inst.
Proof. unfold Equation3253. intro H. specialize (H F5_0). unfold magma_op, refa704_inst, refa704_op in H. discriminate H. Qed.

Lemma refa704_not3459 : ~ @Equation3459 Fin5 refa704_inst.
Proof. unfold Equation3459. intro H. specialize (H F5_1 F5_2). unfold magma_op, refa704_inst, refa704_op in H. discriminate H. Qed.

Lemma refa704_not3462 : ~ @Equation3462 Fin5 refa704_inst.
Proof. unfold Equation3462. intro H. specialize (H F5_0 F5_1). unfold magma_op, refa704_inst, refa704_op in H. discriminate H. Qed.

Lemma refa704_not3465 : ~ @Equation3465 Fin5 refa704_inst.
Proof. unfold Equation3465. intro H. specialize (H F5_0 F5_1). unfold magma_op, refa704_inst, refa704_op in H. discriminate H. Qed.

Lemma refa704_not3862 : ~ @Equation3862 Fin5 refa704_inst.
Proof. unfold Equation3862. intro H. specialize (H F5_0). unfold magma_op, refa704_inst, refa704_op in H. discriminate H. Qed.

Lemma refa704_not4073 : ~ @Equation4073 Fin5 refa704_inst.
Proof. unfold Equation4073. intro H. specialize (H F5_1 F5_2). unfold magma_op, refa704_inst, refa704_op in H. discriminate H. Qed.

Lemma refa704_not4121 : ~ @Equation4121 Fin5 refa704_inst.
Proof. unfold Equation4121. intro H. specialize (H F5_0 F5_1). unfold magma_op, refa704_inst, refa704_op in H. discriminate H. Qed.

Lemma refa704_not4131 : ~ @Equation4131 Fin5 refa704_inst.
Proof. unfold Equation4131. intro H. specialize (H F5_4 F5_2). unfold magma_op, refa704_inst, refa704_op in H. discriminate H. Qed.

Lemma refa704_not4283 : ~ @Equation4283 Fin5 refa704_inst.
Proof. unfold Equation4283. intro H. specialize (H F5_0 F5_1). unfold magma_op, refa704_inst, refa704_op in H. discriminate H. Qed.

Lemma refa704_not4284 : ~ @Equation4284 Fin5 refa704_inst.
Proof. unfold Equation4284. intro H. specialize (H F5_0 F5_1). unfold magma_op, refa704_inst, refa704_op in H. discriminate H. Qed.

Lemma refa704_not4314 : ~ @Equation4314 Fin5 refa704_inst.
Proof. unfold Equation4314. intro H. specialize (H F5_1 F5_0). unfold magma_op, refa704_inst, refa704_op in H. discriminate H. Qed.

Lemma refa704_not4380 : ~ @Equation4380 Fin5 refa704_inst.
Proof. unfold Equation4380. intro H. specialize (H F5_0). unfold magma_op, refa704_inst, refa704_op in H. discriminate H. Qed.

Lemma refa704_not4599 : ~ @Equation4599 Fin5 refa704_inst.
Proof. unfold Equation4599. intro H. specialize (H F5_0 F5_1). unfold magma_op, refa704_inst, refa704_op in H. discriminate H. Qed.

(** ---- refa705 (Fin6) ---- *)

Definition refa705_op (x y : Fin6) : Fin6 :=
  match x, y with
  | F6_0, F6_0 => F6_1 | F6_0, F6_1 => F6_3 | F6_0, F6_2 => F6_3 | F6_0, F6_3 => F6_3 | F6_0, F6_4 => F6_1 | F6_0, F6_5 => F6_3
  | F6_1, F6_0 => F6_4 | F6_1, F6_1 => F6_2 | F6_1, F6_2 => F6_4 | F6_1, F6_3 => F6_0 | F6_1, F6_4 => F6_2 | F6_1, F6_5 => F6_4
  | F6_2, F6_0 => F6_1 | F6_2, F6_1 => F6_4 | F6_2, F6_2 => F6_1 | F6_2, F6_3 => F6_1 | F6_2, F6_4 => F6_1 | F6_2, F6_5 => F6_4
  | F6_3, F6_0 => F6_5 | F6_3, F6_1 => F6_0 | F6_3, F6_2 => F6_5 | F6_3, F6_3 => F6_0 | F6_3, F6_4 => F6_5 | F6_3, F6_5 => F6_5
  | F6_4, F6_0 => F6_1 | F6_4, F6_1 => F6_2 | F6_4, F6_2 => F6_1 | F6_4, F6_3 => F6_5 | F6_4, F6_4 => F6_5 | F6_4, F6_5 => F6_1
  | F6_5, F6_0 => F6_3 | F6_5, F6_1 => F6_4 | F6_5, F6_2 => F6_4 | F6_5, F6_3 => F6_4 | F6_5, F6_4 => F6_4 | F6_5, F6_5 => F6_3
  end.

#[local] Instance refa705_inst : Magma Fin6 := {| magma_op := refa705_op |}.

Lemma refa705_sat1868 : @Equation1868 Fin6 refa705_inst.
Proof. unfold Equation1868, magma_op, refa705_inst, refa705_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa705_not3457 : ~ @Equation3457 Fin6 refa705_inst.
Proof. unfold Equation3457. intro H. specialize (H F6_0 F6_1). unfold magma_op, refa705_inst, refa705_op in H. discriminate H. Qed.

Lemma refa705_not3518 : ~ @Equation3518 Fin6 refa705_inst.
Proof. unfold Equation3518. intro H. specialize (H F6_0 F6_2). unfold magma_op, refa705_inst, refa705_op in H. discriminate H. Qed.

Lemma refa705_not3521 : ~ @Equation3521 Fin6 refa705_inst.
Proof. unfold Equation3521. intro H. specialize (H F6_0 F6_2). unfold magma_op, refa705_inst, refa705_op in H. discriminate H. Qed.

Lemma refa705_not4067 : ~ @Equation4067 Fin6 refa705_inst.
Proof. unfold Equation4067. intro H. specialize (H F6_2 F6_3). unfold magma_op, refa705_inst, refa705_op in H. discriminate H. Qed.

(** ---- refa706 (Fin6) ---- *)

Definition refa706_op (x y : Fin6) : Fin6 :=
  match x, y with
  | F6_0, F6_0 => F6_2 | F6_0, F6_1 => F6_2 | F6_0, F6_2 => F6_2 | F6_0, F6_3 => F6_2 | F6_0, F6_4 => F6_2 | F6_0, F6_5 => F6_2
  | F6_1, F6_0 => F6_3 | F6_1, F6_1 => F6_3 | F6_1, F6_2 => F6_3 | F6_1, F6_3 => F6_4 | F6_1, F6_4 => F6_3 | F6_1, F6_5 => F6_4
  | F6_2, F6_0 => F6_5 | F6_2, F6_1 => F6_0 | F6_2, F6_2 => F6_0 | F6_2, F6_3 => F6_0 | F6_2, F6_4 => F6_5 | F6_2, F6_5 => F6_0
  | F6_3, F6_0 => F6_1 | F6_3, F6_1 => F6_1 | F6_3, F6_2 => F6_1 | F6_3, F6_3 => F6_1 | F6_3, F6_4 => F6_1 | F6_3, F6_5 => F6_1
  | F6_4, F6_0 => F6_5 | F6_4, F6_1 => F6_5 | F6_4, F6_2 => F6_5 | F6_4, F6_3 => F6_1 | F6_4, F6_4 => F6_5 | F6_4, F6_5 => F6_1
  | F6_5, F6_0 => F6_2 | F6_5, F6_1 => F6_4 | F6_5, F6_2 => F6_4 | F6_5, F6_3 => F6_4 | F6_5, F6_4 => F6_2 | F6_5, F6_5 => F6_4
  end.

#[local] Instance refa706_inst : Magma Fin6 := {| magma_op := refa706_op |}.

Lemma refa706_sat1448 : @Equation1448 Fin6 refa706_inst.
Proof. unfold Equation1448, magma_op, refa706_inst, refa706_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa706_not1435 : ~ @Equation1435 Fin6 refa706_inst.
Proof. unfold Equation1435. intro H. specialize (H F6_0 F6_1). unfold magma_op, refa706_inst, refa706_op in H. discriminate H. Qed.

Lemma refa706_not1638 : ~ @Equation1638 Fin6 refa706_inst.
Proof. unfold Equation1638. intro H. specialize (H F6_0 F6_3). unfold magma_op, refa706_inst, refa706_op in H. discriminate H. Qed.

Lemma refa706_not3261 : ~ @Equation3261 Fin6 refa706_inst.
Proof. unfold Equation3261. intro H. specialize (H F6_1 F6_2). unfold magma_op, refa706_inst, refa706_op in H. discriminate H. Qed.

Lemma refa706_not3262 : ~ @Equation3262 Fin6 refa706_inst.
Proof. unfold Equation3262. intro H. specialize (H F6_1 F6_2). unfold magma_op, refa706_inst, refa706_op in H. discriminate H. Qed.

Lemma refa706_not3462 : ~ @Equation3462 Fin6 refa706_inst.
Proof. unfold Equation3462. intro H. specialize (H F6_1 F6_0). unfold magma_op, refa706_inst, refa706_op in H. discriminate H. Qed.

Lemma refa706_not3465 : ~ @Equation3465 Fin6 refa706_inst.
Proof. unfold Equation3465. intro H. specialize (H F6_1 F6_0). unfold magma_op, refa706_inst, refa706_op in H. discriminate H. Qed.

Lemma refa706_not3518 : ~ @Equation3518 Fin6 refa706_inst.
Proof. unfold Equation3518. intro H. specialize (H F6_4 F6_0). unfold magma_op, refa706_inst, refa706_op in H. discriminate H. Qed.

Lemma refa706_not3521 : ~ @Equation3521 Fin6 refa706_inst.
Proof. unfold Equation3521. intro H. specialize (H F6_4 F6_0). unfold magma_op, refa706_inst, refa706_op in H. discriminate H. Qed.

Lemma refa706_not4314 : ~ @Equation4314 Fin6 refa706_inst.
Proof. unfold Equation4314. intro H. specialize (H F6_4 F6_2). unfold magma_op, refa706_inst, refa706_op in H. discriminate H. Qed.

(** ---- refa707 (Fin5) ---- *)

Definition refa707_op (x y : Fin5) : Fin5 :=
  match x, y with
  | F5_0, F5_0 => F5_1 | F5_0, F5_1 => F5_2 | F5_0, F5_2 => F5_0 | F5_0, F5_3 => F5_4 | F5_0, F5_4 => F5_3
  | F5_1, F5_0 => F5_2 | F5_1, F5_1 => F5_4 | F5_1, F5_2 => F5_3 | F5_1, F5_3 => F5_0 | F5_1, F5_4 => F5_1
  | F5_2, F5_0 => F5_3 | F5_2, F5_1 => F5_0 | F5_2, F5_2 => F5_2 | F5_2, F5_3 => F5_1 | F5_2, F5_4 => F5_4
  | F5_3, F5_0 => F5_0 | F5_3, F5_1 => F5_1 | F5_3, F5_2 => F5_4 | F5_3, F5_3 => F5_3 | F5_3, F5_4 => F5_2
  | F5_4, F5_0 => F5_4 | F5_4, F5_1 => F5_3 | F5_4, F5_2 => F5_1 | F5_4, F5_3 => F5_2 | F5_4, F5_4 => F5_0
  end.

#[local] Instance refa707_inst : Magma Fin5 := {| magma_op := refa707_op |}.

Lemma refa707_sat1888 : @Equation1888 Fin5 refa707_inst.
Proof. unfold Equation1888, magma_op, refa707_inst, refa707_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa707_not1629 : ~ @Equation1629 Fin5 refa707_inst.
Proof. unfold Equation1629. intro H. specialize (H F5_0). unfold magma_op, refa707_inst, refa707_op in H. discriminate H. Qed.

(** ---- refa708 (Fin5) ---- *)

Definition refa708_op (x y : Fin5) : Fin5 :=
  match x, y with
  | F5_0, F5_0 => F5_4 | F5_0, F5_1 => F5_2 | F5_0, F5_2 => F5_3 | F5_0, F5_3 => F5_3 | F5_0, F5_4 => F5_0
  | F5_1, F5_0 => F5_3 | F5_1, F5_1 => F5_2 | F5_1, F5_2 => F5_1 | F5_1, F5_3 => F5_3 | F5_1, F5_4 => F5_0
  | F5_2, F5_0 => F5_4 | F5_2, F5_1 => F5_2 | F5_2, F5_2 => F5_1 | F5_2, F5_3 => F5_3 | F5_2, F5_4 => F5_3
  | F5_3, F5_0 => F5_4 | F5_3, F5_1 => F5_2 | F5_3, F5_2 => F5_1 | F5_3, F5_3 => F5_3 | F5_3, F5_4 => F5_0
  | F5_4, F5_0 => F5_4 | F5_4, F5_1 => F5_3 | F5_4, F5_2 => F5_1 | F5_4, F5_3 => F5_3 | F5_4, F5_4 => F5_0
  end.

#[local] Instance refa708_inst : Magma Fin5 := {| magma_op := refa708_op |}.

Lemma refa708_sat1904 : @Equation1904 Fin5 refa708_inst.
Proof. unfold Equation1904, magma_op, refa708_inst, refa708_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa708_not1038 : ~ @Equation1038 Fin5 refa708_inst.
Proof. unfold Equation1038. intro H. specialize (H F5_0 F5_1). unfold magma_op, refa708_inst, refa708_op in H. discriminate H. Qed.

Lemma refa708_not1225 : ~ @Equation1225 Fin5 refa708_inst.
Proof. unfold Equation1225. intro H. specialize (H F5_0 F5_2). unfold magma_op, refa708_inst, refa708_op in H. discriminate H. Qed.

Lemma refa708_not1644 : ~ @Equation1644 Fin5 refa708_inst.
Proof. unfold Equation1644. intro H. specialize (H F5_0 F5_1). unfold magma_op, refa708_inst, refa708_op in H. discriminate H. Qed.

Lemma refa708_not1654 : ~ @Equation1654 Fin5 refa708_inst.
Proof. unfold Equation1654. intro H. specialize (H F5_0 F5_1). unfold magma_op, refa708_inst, refa708_op in H. discriminate H. Qed.

Lemma refa708_not1857 : ~ @Equation1857 Fin5 refa708_inst.
Proof. unfold Equation1857. intro H. specialize (H F5_0 F5_2). unfold magma_op, refa708_inst, refa708_op in H. discriminate H. Qed.

Lemma refa708_not3306 : ~ @Equation3306 Fin5 refa708_inst.
Proof. unfold Equation3306. intro H. specialize (H F5_0 F5_1). unfold magma_op, refa708_inst, refa708_op in H. discriminate H. Qed.

Lemma refa708_not3309 : ~ @Equation3309 Fin5 refa708_inst.
Proof. unfold Equation3309. intro H. specialize (H F5_0 F5_1). unfold magma_op, refa708_inst, refa708_op in H. discriminate H. Qed.

Lemma refa708_not3343 : ~ @Equation3343 Fin5 refa708_inst.
Proof. unfold Equation3343. intro H. specialize (H F5_0 F5_1). unfold magma_op, refa708_inst, refa708_op in H. discriminate H. Qed.

Lemma refa708_not3346 : ~ @Equation3346 Fin5 refa708_inst.
Proof. unfold Equation3346. intro H. specialize (H F5_0 F5_1). unfold magma_op, refa708_inst, refa708_op in H. discriminate H. Qed.

Lemma refa708_not3880 : ~ @Equation3880 Fin5 refa708_inst.
Proof. unfold Equation3880. intro H. specialize (H F5_0 F5_1). unfold magma_op, refa708_inst, refa708_op in H. discriminate H. Qed.

Lemma refa708_not4067 : ~ @Equation4067 Fin5 refa708_inst.
Proof. unfold Equation4067. intro H. specialize (H F5_0 F5_2). unfold magma_op, refa708_inst, refa708_op in H. discriminate H. Qed.

Lemma refa708_not4118 : ~ @Equation4118 Fin5 refa708_inst.
Proof. unfold Equation4118. intro H. specialize (H F5_0 F5_1). unfold magma_op, refa708_inst, refa708_op in H. discriminate H. Qed.

Lemma refa708_not4128 : ~ @Equation4128 Fin5 refa708_inst.
Proof. unfold Equation4128. intro H. specialize (H F5_0 F5_1). unfold magma_op, refa708_inst, refa708_op in H. discriminate H. Qed.

Lemma refa708_not4155 : ~ @Equation4155 Fin5 refa708_inst.
Proof. unfold Equation4155. intro H. specialize (H F5_0 F5_1). unfold magma_op, refa708_inst, refa708_op in H. discriminate H. Qed.

Lemma refa708_not4284 : ~ @Equation4284 Fin5 refa708_inst.
Proof. unfold Equation4284. intro H. specialize (H F5_0 F5_2). unfold magma_op, refa708_inst, refa708_op in H. discriminate H. Qed.

Lemma refa708_not4291 : ~ @Equation4291 Fin5 refa708_inst.
Proof. unfold Equation4291. intro H. specialize (H F5_0 F5_1). unfold magma_op, refa708_inst, refa708_op in H. discriminate H. Qed.

Lemma refa708_not4320 : ~ @Equation4320 Fin5 refa708_inst.
Proof. unfold Equation4320. intro H. specialize (H F5_0 F5_1). unfold magma_op, refa708_inst, refa708_op in H. discriminate H. Qed.

(** ---- refa709 (Fin5) ---- *)

Definition refa709_op (x y : Fin5) : Fin5 :=
  match x, y with
  | F5_0, F5_0 => F5_1 | F5_0, F5_1 => F5_2 | F5_0, F5_2 => F5_4 | F5_0, F5_3 => F5_3 | F5_0, F5_4 => F5_0
  | F5_1, F5_0 => F5_2 | F5_1, F5_1 => F5_1 | F5_1, F5_2 => F5_0 | F5_1, F5_3 => F5_4 | F5_1, F5_4 => F5_3
  | F5_2, F5_0 => F5_3 | F5_2, F5_1 => F5_0 | F5_2, F5_2 => F5_1 | F5_2, F5_3 => F5_2 | F5_2, F5_4 => F5_4
  | F5_3, F5_0 => F5_0 | F5_3, F5_1 => F5_4 | F5_3, F5_2 => F5_3 | F5_3, F5_3 => F5_1 | F5_3, F5_4 => F5_2
  | F5_4, F5_0 => F5_4 | F5_4, F5_1 => F5_3 | F5_4, F5_2 => F5_2 | F5_4, F5_3 => F5_0 | F5_4, F5_4 => F5_1
  end.

#[local] Instance refa709_inst : Magma Fin5 := {| magma_op := refa709_op |}.

Lemma refa709_sat3008 : @Equation3008 Fin5 refa709_inst.
Proof. unfold Equation3008, magma_op, refa709_inst, refa709_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa709_not429 : ~ @Equation429 Fin5 refa709_inst.
Proof. unfold Equation429. intro H. specialize (H F5_0 F5_1). unfold magma_op, refa709_inst, refa709_op in H. discriminate H. Qed.

Lemma refa709_not511 : ~ @Equation511 Fin5 refa709_inst.
Proof. unfold Equation511. intro H. specialize (H F5_0 F5_2). unfold magma_op, refa709_inst, refa709_op in H. discriminate H. Qed.

Lemma refa709_not632 : ~ @Equation632 Fin5 refa709_inst.
Proof. unfold Equation632. intro H. specialize (H F5_0 F5_3). unfold magma_op, refa709_inst, refa709_op in H. discriminate H. Qed.

Lemma refa709_not707 : ~ @Equation707 Fin5 refa709_inst.
Proof. unfold Equation707. intro H. specialize (H F5_0 F5_3). unfold magma_op, refa709_inst, refa709_op in H. discriminate H. Qed.

Lemma refa709_not817 : ~ @Equation817 Fin5 refa709_inst.
Proof. unfold Equation817. intro H. specialize (H F5_0). unfold magma_op, refa709_inst, refa709_op in H. discriminate H. Qed.

Lemma refa709_not1020 : ~ @Equation1020 Fin5 refa709_inst.
Proof. unfold Equation1020. intro H. specialize (H F5_0). unfold magma_op, refa709_inst, refa709_op in H. discriminate H. Qed.

Lemma refa709_not1223 : ~ @Equation1223 Fin5 refa709_inst.
Proof. unfold Equation1223. intro H. specialize (H F5_0). unfold magma_op, refa709_inst, refa709_op in H. discriminate H. Qed.

Lemma refa709_not2238 : ~ @Equation2238 Fin5 refa709_inst.
Proof. unfold Equation2238. intro H. specialize (H F5_0). unfold magma_op, refa709_inst, refa709_op in H. discriminate H. Qed.

Lemma refa709_not2441 : ~ @Equation2441 Fin5 refa709_inst.
Proof. unfold Equation2441. intro H. specialize (H F5_0). unfold magma_op, refa709_inst, refa709_op in H. discriminate H. Qed.

Lemma refa709_not2644 : ~ @Equation2644 Fin5 refa709_inst.
Proof. unfold Equation2644. intro H. specialize (H F5_0). unfold magma_op, refa709_inst, refa709_op in H. discriminate H. Qed.

Lemma refa709_not2865 : ~ @Equation2865 Fin5 refa709_inst.
Proof. unfold Equation2865. intro H. specialize (H F5_0 F5_3). unfold magma_op, refa709_inst, refa709_op in H. discriminate H. Qed.

Lemma refa709_not2940 : ~ @Equation2940 Fin5 refa709_inst.
Proof. unfold Equation2940. intro H. specialize (H F5_0 F5_3). unfold magma_op, refa709_inst, refa709_op in H. discriminate H. Qed.

Lemma refa709_not3068 : ~ @Equation3068 Fin5 refa709_inst.
Proof. unfold Equation3068. intro H. specialize (H F5_0 F5_1). unfold magma_op, refa709_inst, refa709_op in H. discriminate H. Qed.

Lemma refa709_not4290 : ~ @Equation4290 Fin5 refa709_inst.
Proof. unfold Equation4290. intro H. specialize (H F5_0 F5_1). unfold magma_op, refa709_inst, refa709_op in H. discriminate H. Qed.

Lemma refa709_not4435 : ~ @Equation4435 Fin5 refa709_inst.
Proof. unfold Equation4435. intro H. specialize (H F5_0 F5_1). unfold magma_op, refa709_inst, refa709_op in H. discriminate H. Qed.

Lemma refa709_not4605 : ~ @Equation4605 Fin5 refa709_inst.
Proof. unfold Equation4605. intro H. specialize (H F5_0 F5_1). unfold magma_op, refa709_inst, refa709_op in H. discriminate H. Qed.

(** ---- refa71 (Fin3) ---- *)

Definition refa71_op (x y : Fin3) : Fin3 :=
  match x, y with
  | F3_0, F3_0 => F3_0 | F3_0, F3_1 => F3_1 | F3_0, F3_2 => F3_2
  | F3_1, F3_0 => F3_0 | F3_1, F3_1 => F3_2 | F3_1, F3_2 => F3_0
  | F3_2, F3_0 => F3_0 | F3_2, F3_1 => F3_0 | F3_2, F3_2 => F3_1
  end.

#[local] Instance refa71_inst : Magma Fin3 := {| magma_op := refa71_op |}.

Lemma refa71_sat2296 : @Equation2296 Fin3 refa71_inst.
Proof. unfold Equation2296, magma_op, refa71_inst, refa71_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa71_sat2351 : @Equation2351 Fin3 refa71_inst.
Proof. unfold Equation2351, magma_op, refa71_inst, refa71_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa71_sat2372 : @Equation2372 Fin3 refa71_inst.
Proof. unfold Equation2372, magma_op, refa71_inst, refa71_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa71_sat2496 : @Equation2496 Fin3 refa71_inst.
Proof. unfold Equation2496, magma_op, refa71_inst, refa71_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa71_sat2609 : @Equation2609 Fin3 refa71_inst.
Proof. unfold Equation2609, magma_op, refa71_inst, refa71_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa71_sat4389 : @Equation4389 Fin3 refa71_inst.
Proof. unfold Equation4389, magma_op, refa71_inst, refa71_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa71_sat4473 : @Equation4473 Fin3 refa71_inst.
Proof. unfold Equation4473, magma_op, refa71_inst, refa71_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa71_not47 : ~ @Equation47 Fin3 refa71_inst.
Proof. unfold Equation47. intro H. specialize (H F3_1). unfold magma_op, refa71_inst, refa71_op in H. discriminate H. Qed.

Lemma refa71_not99 : ~ @Equation99 Fin3 refa71_inst.
Proof. unfold Equation99. intro H. specialize (H F3_1). unfold magma_op, refa71_inst, refa71_op in H. discriminate H. Qed.

Lemma refa71_not159 : ~ @Equation159 Fin3 refa71_inst.
Proof. unfold Equation159. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa71_inst, refa71_op in H. discriminate H. Qed.

Lemma refa71_not211 : ~ @Equation211 Fin3 refa71_inst.
Proof. unfold Equation211. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa71_inst, refa71_op in H. discriminate H. Qed.

Lemma refa71_not273 : ~ @Equation273 Fin3 refa71_inst.
Proof. unfold Equation273. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa71_inst, refa71_op in H. discriminate H. Qed.

Lemma refa71_not411 : ~ @Equation411 Fin3 refa71_inst.
Proof. unfold Equation411. intro H. specialize (H F3_1). unfold magma_op, refa71_inst, refa71_op in H. discriminate H. Qed.

Lemma refa71_not614 : ~ @Equation614 Fin3 refa71_inst.
Proof. unfold Equation614. intro H. specialize (H F3_1). unfold magma_op, refa71_inst, refa71_op in H. discriminate H. Qed.

Lemma refa71_not817 : ~ @Equation817 Fin3 refa71_inst.
Proof. unfold Equation817. intro H. specialize (H F3_1). unfold magma_op, refa71_inst, refa71_op in H. discriminate H. Qed.

Lemma refa71_not1020 : ~ @Equation1020 Fin3 refa71_inst.
Proof. unfold Equation1020. intro H. specialize (H F3_1). unfold magma_op, refa71_inst, refa71_op in H. discriminate H. Qed.

Lemma refa71_not1223 : ~ @Equation1223 Fin3 refa71_inst.
Proof. unfold Equation1223. intro H. specialize (H F3_1). unfold magma_op, refa71_inst, refa71_op in H. discriminate H. Qed.

Lemma refa71_not1426 : ~ @Equation1426 Fin3 refa71_inst.
Proof. unfold Equation1426. intro H. specialize (H F3_1). unfold magma_op, refa71_inst, refa71_op in H. discriminate H. Qed.

Lemma refa71_not1629 : ~ @Equation1629 Fin3 refa71_inst.
Proof. unfold Equation1629. intro H. specialize (H F3_1). unfold magma_op, refa71_inst, refa71_op in H. discriminate H. Qed.

Lemma refa71_not1832 : ~ @Equation1832 Fin3 refa71_inst.
Proof. unfold Equation1832. intro H. specialize (H F3_1). unfold magma_op, refa71_inst, refa71_op in H. discriminate H. Qed.

Lemma refa71_not2035 : ~ @Equation2035 Fin3 refa71_inst.
Proof. unfold Equation2035. intro H. specialize (H F3_1). unfold magma_op, refa71_inst, refa71_op in H. discriminate H. Qed.

Lemma refa71_not2253 : ~ @Equation2253 Fin3 refa71_inst.
Proof. unfold Equation2253. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa71_inst, refa71_op in H. discriminate H. Qed.

Lemma refa71_not2300 : ~ @Equation2300 Fin3 refa71_inst.
Proof. unfold Equation2300. intro H. specialize (H F3_1 F3_0). unfold magma_op, refa71_inst, refa71_op in H. discriminate H. Qed.

Lemma refa71_not2303 : ~ @Equation2303 Fin3 refa71_inst.
Proof. unfold Equation2303. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa71_inst, refa71_op in H. discriminate H. Qed.

Lemma refa71_not2443 : ~ @Equation2443 Fin3 refa71_inst.
Proof. unfold Equation2443. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa71_inst, refa71_op in H. discriminate H. Qed.

Lemma refa71_not2456 : ~ @Equation2456 Fin3 refa71_inst.
Proof. unfold Equation2456. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa71_inst, refa71_op in H. discriminate H. Qed.

Lemma refa71_not2466 : ~ @Equation2466 Fin3 refa71_inst.
Proof. unfold Equation2466. intro H. specialize (H F3_1 F3_0). unfold magma_op, refa71_inst, refa71_op in H. discriminate H. Qed.

Lemma refa71_not2506 : ~ @Equation2506 Fin3 refa71_inst.
Proof. unfold Equation2506. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa71_inst, refa71_op in H. discriminate H. Qed.

Lemma refa71_not2530 : ~ @Equation2530 Fin3 refa71_inst.
Proof. unfold Equation2530. intro H. specialize (H F3_1 F3_0). unfold magma_op, refa71_inst, refa71_op in H. discriminate H. Qed.

Lemma refa71_not2533 : ~ @Equation2533 Fin3 refa71_inst.
Proof. unfold Equation2533. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa71_inst, refa71_op in H. discriminate H. Qed.

Lemma refa71_not2540 : ~ @Equation2540 Fin3 refa71_inst.
Proof. unfold Equation2540. intro H. specialize (H F3_1 F3_0). unfold magma_op, refa71_inst, refa71_op in H. discriminate H. Qed.

Lemma refa71_not2644 : ~ @Equation2644 Fin3 refa71_inst.
Proof. unfold Equation2644. intro H. specialize (H F3_1). unfold magma_op, refa71_inst, refa71_op in H. discriminate H. Qed.

Lemma refa71_not2847 : ~ @Equation2847 Fin3 refa71_inst.
Proof. unfold Equation2847. intro H. specialize (H F3_1). unfold magma_op, refa71_inst, refa71_op in H. discriminate H. Qed.

Lemma refa71_not3050 : ~ @Equation3050 Fin3 refa71_inst.
Proof. unfold Equation3050. intro H. specialize (H F3_1). unfold magma_op, refa71_inst, refa71_op in H. discriminate H. Qed.

Lemma refa71_not3253 : ~ @Equation3253 Fin3 refa71_inst.
Proof. unfold Equation3253. intro H. specialize (H F3_1). unfold magma_op, refa71_inst, refa71_op in H. discriminate H. Qed.

Lemma refa71_not3456 : ~ @Equation3456 Fin3 refa71_inst.
Proof. unfold Equation3456. intro H. specialize (H F3_1). unfold magma_op, refa71_inst, refa71_op in H. discriminate H. Qed.

Lemma refa71_not3659 : ~ @Equation3659 Fin3 refa71_inst.
Proof. unfold Equation3659. intro H. specialize (H F3_1). unfold magma_op, refa71_inst, refa71_op in H. discriminate H. Qed.

Lemma refa71_not3862 : ~ @Equation3862 Fin3 refa71_inst.
Proof. unfold Equation3862. intro H. specialize (H F3_1). unfold magma_op, refa71_inst, refa71_op in H. discriminate H. Qed.

Lemma refa71_not4065 : ~ @Equation4065 Fin3 refa71_inst.
Proof. unfold Equation4065. intro H. specialize (H F3_1). unfold magma_op, refa71_inst, refa71_op in H. discriminate H. Qed.

Lemma refa71_not4269 : ~ @Equation4269 Fin3 refa71_inst.
Proof. unfold Equation4269. intro H. specialize (H F3_1 F3_0). unfold magma_op, refa71_inst, refa71_op in H. discriminate H. Qed.

Lemma refa71_not4270 : ~ @Equation4270 Fin3 refa71_inst.
Proof. unfold Equation4270. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa71_inst, refa71_op in H. discriminate H. Qed.

Lemma refa71_not4272 : ~ @Equation4272 Fin3 refa71_inst.
Proof. unfold Equation4272. intro H. specialize (H F3_1 F3_0). unfold magma_op, refa71_inst, refa71_op in H. discriminate H. Qed.

Lemma refa71_not4273 : ~ @Equation4273 Fin3 refa71_inst.
Proof. unfold Equation4273. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa71_inst, refa71_op in H. discriminate H. Qed.

Lemma refa71_not4275 : ~ @Equation4275 Fin3 refa71_inst.
Proof. unfold Equation4275. intro H. specialize (H F3_1 F3_0). unfold magma_op, refa71_inst, refa71_op in H. discriminate H. Qed.

Lemma refa71_not4283 : ~ @Equation4283 Fin3 refa71_inst.
Proof. unfold Equation4283. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa71_inst, refa71_op in H. discriminate H. Qed.

Lemma refa71_not4284 : ~ @Equation4284 Fin3 refa71_inst.
Proof. unfold Equation4284. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa71_inst, refa71_op in H. discriminate H. Qed.

Lemma refa71_not4291 : ~ @Equation4291 Fin3 refa71_inst.
Proof. unfold Equation4291. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa71_inst, refa71_op in H. discriminate H. Qed.

Lemma refa71_not4314 : ~ @Equation4314 Fin3 refa71_inst.
Proof. unfold Equation4314. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa71_inst, refa71_op in H. discriminate H. Qed.

Lemma refa71_not4320 : ~ @Equation4320 Fin3 refa71_inst.
Proof. unfold Equation4320. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa71_inst, refa71_op in H. discriminate H. Qed.

Lemma refa71_not4396 : ~ @Equation4396 Fin3 refa71_inst.
Proof. unfold Equation4396. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa71_inst, refa71_op in H. discriminate H. Qed.

Lemma refa71_not4398 : ~ @Equation4398 Fin3 refa71_inst.
Proof. unfold Equation4398. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa71_inst, refa71_op in H. discriminate H. Qed.

Lemma refa71_not4399 : ~ @Equation4399 Fin3 refa71_inst.
Proof. unfold Equation4399. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa71_inst, refa71_op in H. discriminate H. Qed.

Lemma refa71_not4406 : ~ @Equation4406 Fin3 refa71_inst.
Proof. unfold Equation4406. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa71_inst, refa71_op in H. discriminate H. Qed.

Lemma refa71_not4408 : ~ @Equation4408 Fin3 refa71_inst.
Proof. unfold Equation4408. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa71_inst, refa71_op in H. discriminate H. Qed.

Lemma refa71_not4433 : ~ @Equation4433 Fin3 refa71_inst.
Proof. unfold Equation4433. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa71_inst, refa71_op in H. discriminate H. Qed.

Lemma refa71_not4435 : ~ @Equation4435 Fin3 refa71_inst.
Proof. unfold Equation4435. intro H. specialize (H F3_1 F3_0). unfold magma_op, refa71_inst, refa71_op in H. discriminate H. Qed.

Lemma refa71_not4442 : ~ @Equation4442 Fin3 refa71_inst.
Proof. unfold Equation4442. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa71_inst, refa71_op in H. discriminate H. Qed.

Lemma refa71_not4445 : ~ @Equation4445 Fin3 refa71_inst.
Proof. unfold Equation4445. intro H. specialize (H F3_1 F3_0). unfold magma_op, refa71_inst, refa71_op in H. discriminate H. Qed.

Lemma refa71_not4470 : ~ @Equation4470 Fin3 refa71_inst.
Proof. unfold Equation4470. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa71_inst, refa71_op in H. discriminate H. Qed.

Lemma refa71_not4472 : ~ @Equation4472 Fin3 refa71_inst.
Proof. unfold Equation4472. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa71_inst, refa71_op in H. discriminate H. Qed.

Lemma refa71_not4480 : ~ @Equation4480 Fin3 refa71_inst.
Proof. unfold Equation4480. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa71_inst, refa71_op in H. discriminate H. Qed.

Lemma refa71_not4482 : ~ @Equation4482 Fin3 refa71_inst.
Proof. unfold Equation4482. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa71_inst, refa71_op in H. discriminate H. Qed.

Lemma refa71_not4584 : ~ @Equation4584 Fin3 refa71_inst.
Proof. unfold Equation4584. intro H. specialize (H F3_1 F3_0). unfold magma_op, refa71_inst, refa71_op in H. discriminate H. Qed.

Lemma refa71_not4585 : ~ @Equation4585 Fin3 refa71_inst.
Proof. unfold Equation4585. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa71_inst, refa71_op in H. discriminate H. Qed.

Lemma refa71_not4587 : ~ @Equation4587 Fin3 refa71_inst.
Proof. unfold Equation4587. intro H. specialize (H F3_1 F3_0). unfold magma_op, refa71_inst, refa71_op in H. discriminate H. Qed.

Lemma refa71_not4590 : ~ @Equation4590 Fin3 refa71_inst.
Proof. unfold Equation4590. intro H. specialize (H F3_1 F3_0). unfold magma_op, refa71_inst, refa71_op in H. discriminate H. Qed.

Lemma refa71_not4598 : ~ @Equation4598 Fin3 refa71_inst.
Proof. unfold Equation4598. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa71_inst, refa71_op in H. discriminate H. Qed.

Lemma refa71_not4599 : ~ @Equation4599 Fin3 refa71_inst.
Proof. unfold Equation4599. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa71_inst, refa71_op in H. discriminate H. Qed.

Lemma refa71_not4606 : ~ @Equation4606 Fin3 refa71_inst.
Proof. unfold Equation4606. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa71_inst, refa71_op in H. discriminate H. Qed.

Lemma refa71_not4635 : ~ @Equation4635 Fin3 refa71_inst.
Proof. unfold Equation4635. intro H. specialize (H F3_1 F3_0). unfold magma_op, refa71_inst, refa71_op in H. discriminate H. Qed.

(** ---- refa710 (Fin6) ---- *)

Definition refa710_op (x y : Fin6) : Fin6 :=
  match x, y with
  | F6_0, F6_0 => F6_1 | F6_0, F6_1 => F6_1 | F6_0, F6_2 => F6_5 | F6_0, F6_3 => F6_1 | F6_0, F6_4 => F6_5 | F6_0, F6_5 => F6_1
  | F6_1, F6_0 => F6_2 | F6_1, F6_1 => F6_4 | F6_1, F6_2 => F6_4 | F6_1, F6_3 => F6_2 | F6_1, F6_4 => F6_4 | F6_1, F6_5 => F6_4
  | F6_2, F6_0 => F6_3 | F6_2, F6_1 => F6_0 | F6_2, F6_2 => F6_3 | F6_2, F6_3 => F6_3 | F6_2, F6_4 => F6_3 | F6_2, F6_5 => F6_0
  | F6_3, F6_0 => F6_5 | F6_3, F6_1 => F6_5 | F6_3, F6_2 => F6_1 | F6_3, F6_3 => F6_5 | F6_3, F6_4 => F6_1 | F6_3, F6_5 => F6_5
  | F6_4, F6_0 => F6_0 | F6_4, F6_1 => F6_3 | F6_4, F6_2 => F6_0 | F6_4, F6_3 => F6_0 | F6_4, F6_4 => F6_0 | F6_4, F6_5 => F6_3
  | F6_5, F6_0 => F6_4 | F6_5, F6_1 => F6_2 | F6_5, F6_2 => F6_2 | F6_5, F6_3 => F6_4 | F6_5, F6_4 => F6_2 | F6_5, F6_5 => F6_2
  end.

#[local] Instance refa710_inst : Magma Fin6 := {| magma_op := refa710_op |}.

Lemma refa710_sat2045 : @Equation2045 Fin6 refa710_inst.
Proof. unfold Equation2045, magma_op, refa710_inst, refa710_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa710_sat2675 : @Equation2675 Fin6 refa710_inst.
Proof. unfold Equation2675, magma_op, refa710_inst, refa710_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa710_not255 : ~ @Equation255 Fin6 refa710_inst.
Proof. unfold Equation255. intro H. specialize (H F6_0). unfold magma_op, refa710_inst, refa710_op in H. discriminate H. Qed.

Lemma refa710_not2037 : ~ @Equation2037 Fin6 refa710_inst.
Proof. unfold Equation2037. intro H. specialize (H F6_0 F6_1). unfold magma_op, refa710_inst, refa710_op in H. discriminate H. Qed.

Lemma refa710_not2040 : ~ @Equation2040 Fin6 refa710_inst.
Proof. unfold Equation2040. intro H. specialize (H F6_0 F6_1). unfold magma_op, refa710_inst, refa710_op in H. discriminate H. Qed.

Lemma refa710_not2050 : ~ @Equation2050 Fin6 refa710_inst.
Proof. unfold Equation2050. intro H. specialize (H F6_0 F6_2). unfold magma_op, refa710_inst, refa710_op in H. discriminate H. Qed.

Lemma refa710_not2053 : ~ @Equation2053 Fin6 refa710_inst.
Proof. unfold Equation2053. intro H. specialize (H F6_0 F6_1). unfold magma_op, refa710_inst, refa710_op in H. discriminate H. Qed.

Lemma refa710_not2054 : ~ @Equation2054 Fin6 refa710_inst.
Proof. unfold Equation2054. intro H. specialize (H F6_0 F6_1). unfold magma_op, refa710_inst, refa710_op in H. discriminate H. Qed.

Lemma refa710_not2060 : ~ @Equation2060 Fin6 refa710_inst.
Proof. unfold Equation2060. intro H. specialize (H F6_0 F6_1). unfold magma_op, refa710_inst, refa710_op in H. discriminate H. Qed.

Lemma refa710_not2063 : ~ @Equation2063 Fin6 refa710_inst.
Proof. unfold Equation2063. intro H. specialize (H F6_0 F6_2). unfold magma_op, refa710_inst, refa710_op in H. discriminate H. Qed.

Lemma refa710_not2650 : ~ @Equation2650 Fin6 refa710_inst.
Proof. unfold Equation2650. intro H. specialize (H F6_0 F6_1). unfold magma_op, refa710_inst, refa710_op in H. discriminate H. Qed.

Lemma refa710_not2652 : ~ @Equation2652 Fin6 refa710_inst.
Proof. unfold Equation2652. intro H. specialize (H F6_0 F6_2). unfold magma_op, refa710_inst, refa710_op in H. discriminate H. Qed.

Lemma refa710_not2659 : ~ @Equation2659 Fin6 refa710_inst.
Proof. unfold Equation2659. intro H. specialize (H F6_0 F6_2). unfold magma_op, refa710_inst, refa710_op in H. discriminate H. Qed.

Lemma refa710_not2660 : ~ @Equation2660 Fin6 refa710_inst.
Proof. unfold Equation2660. intro H. specialize (H F6_0 F6_1). unfold magma_op, refa710_inst, refa710_op in H. discriminate H. Qed.

Lemma refa710_not2662 : ~ @Equation2662 Fin6 refa710_inst.
Proof. unfold Equation2662. intro H. specialize (H F6_0 F6_2). unfold magma_op, refa710_inst, refa710_op in H. discriminate H. Qed.

Lemma refa710_not2847 : ~ @Equation2847 Fin6 refa710_inst.
Proof. unfold Equation2847. intro H. specialize (H F6_0). unfold magma_op, refa710_inst, refa710_op in H. discriminate H. Qed.

Lemma refa710_not3258 : ~ @Equation3258 Fin6 refa710_inst.
Proof. unfold Equation3258. intro H. specialize (H F6_0 F6_1). unfold magma_op, refa710_inst, refa710_op in H. discriminate H. Qed.

Lemma refa710_not3261 : ~ @Equation3261 Fin6 refa710_inst.
Proof. unfold Equation3261. intro H. specialize (H F6_0 F6_1). unfold magma_op, refa710_inst, refa710_op in H. discriminate H. Qed.

Lemma refa710_not3306 : ~ @Equation3306 Fin6 refa710_inst.
Proof. unfold Equation3306. intro H. specialize (H F6_0 F6_2). unfold magma_op, refa710_inst, refa710_op in H. discriminate H. Qed.

Lemma refa710_not3309 : ~ @Equation3309 Fin6 refa710_inst.
Proof. unfold Equation3309. intro H. specialize (H F6_0 F6_2). unfold magma_op, refa710_inst, refa710_op in H. discriminate H. Qed.

Lemma refa710_not3315 : ~ @Equation3315 Fin6 refa710_inst.
Proof. unfold Equation3315. intro H. specialize (H F6_0 F6_1). unfold magma_op, refa710_inst, refa710_op in H. discriminate H. Qed.

Lemma refa710_not3316 : ~ @Equation3316 Fin6 refa710_inst.
Proof. unfold Equation3316. intro H. specialize (H F6_0 F6_1). unfold magma_op, refa710_inst, refa710_op in H. discriminate H. Qed.

Lemma refa710_not3318 : ~ @Equation3318 Fin6 refa710_inst.
Proof. unfold Equation3318. intro H. specialize (H F6_0 F6_1). unfold magma_op, refa710_inst, refa710_op in H. discriminate H. Qed.

Lemma refa710_not3319 : ~ @Equation3319 Fin6 refa710_inst.
Proof. unfold Equation3319. intro H. specialize (H F6_0 F6_1). unfold magma_op, refa710_inst, refa710_op in H. discriminate H. Qed.

Lemma refa710_not3456 : ~ @Equation3456 Fin6 refa710_inst.
Proof. unfold Equation3456. intro H. specialize (H F6_0). unfold magma_op, refa710_inst, refa710_op in H. discriminate H. Qed.

Lemma refa710_not4269 : ~ @Equation4269 Fin6 refa710_inst.
Proof. unfold Equation4269. intro H. specialize (H F6_0 F6_1). unfold magma_op, refa710_inst, refa710_op in H. discriminate H. Qed.

Lemma refa710_not4284 : ~ @Equation4284 Fin6 refa710_inst.
Proof. unfold Equation4284. intro H. specialize (H F6_0 F6_1). unfold magma_op, refa710_inst, refa710_op in H. discriminate H. Qed.

Lemma refa710_not4598 : ~ @Equation4598 Fin6 refa710_inst.
Proof. unfold Equation4598. intro H. specialize (H F6_0 F6_1). unfold magma_op, refa710_inst, refa710_op in H. discriminate H. Qed.

Lemma refa710_not4599 : ~ @Equation4599 Fin6 refa710_inst.
Proof. unfold Equation4599. intro H. specialize (H F6_0 F6_2). unfold magma_op, refa710_inst, refa710_op in H. discriminate H. Qed.

Lemma refa710_not4631 : ~ @Equation4631 Fin6 refa710_inst.
Proof. unfold Equation4631. intro H. specialize (H F6_0 F6_0 F6_2). unfold magma_op, refa710_inst, refa710_op in H. discriminate H. Qed.

Lemma refa710_not4656 : ~ @Equation4656 Fin6 refa710_inst.
Proof. unfold Equation4656. intro H. specialize (H F6_0 F6_0 F6_1). unfold magma_op, refa710_inst, refa710_op in H. discriminate H. Qed.

(** ---- refa711 (Fin6) ---- *)

Definition refa711_op (x y : Fin6) : Fin6 :=
  match x, y with
  | F6_0, F6_0 => F6_1 | F6_0, F6_1 => F6_4 | F6_0, F6_2 => F6_1 | F6_0, F6_3 => F6_1 | F6_0, F6_4 => F6_4 | F6_0, F6_5 => F6_1
  | F6_1, F6_0 => F6_2 | F6_1, F6_1 => F6_2 | F6_1, F6_2 => F6_5 | F6_1, F6_3 => F6_2 | F6_1, F6_4 => F6_2 | F6_1, F6_5 => F6_5
  | F6_2, F6_0 => F6_3 | F6_2, F6_1 => F6_0 | F6_2, F6_2 => F6_0 | F6_2, F6_3 => F6_3 | F6_2, F6_4 => F6_0 | F6_2, F6_5 => F6_0
  | F6_3, F6_0 => F6_4 | F6_3, F6_1 => F6_1 | F6_3, F6_2 => F6_4 | F6_3, F6_3 => F6_4 | F6_3, F6_4 => F6_1 | F6_3, F6_5 => F6_4
  | F6_4, F6_0 => F6_5 | F6_4, F6_1 => F6_5 | F6_4, F6_2 => F6_2 | F6_4, F6_3 => F6_5 | F6_4, F6_4 => F6_5 | F6_4, F6_5 => F6_2
  | F6_5, F6_0 => F6_0 | F6_5, F6_1 => F6_3 | F6_5, F6_2 => F6_3 | F6_5, F6_3 => F6_0 | F6_5, F6_4 => F6_3 | F6_5, F6_5 => F6_3
  end.

#[local] Instance refa711_inst : Magma Fin6 := {| magma_op := refa711_op |}.

Lemma refa711_sat2045 : @Equation2045 Fin6 refa711_inst.
Proof. unfold Equation2045, magma_op, refa711_inst, refa711_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa711_sat2883 : @Equation2883 Fin6 refa711_inst.
Proof. unfold Equation2883, magma_op, refa711_inst, refa711_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa711_not255 : ~ @Equation255 Fin6 refa711_inst.
Proof. unfold Equation255. intro H. specialize (H F6_0). unfold magma_op, refa711_inst, refa711_op in H. discriminate H. Qed.

Lemma refa711_not2060 : ~ @Equation2060 Fin6 refa711_inst.
Proof. unfold Equation2060. intro H. specialize (H F6_0 F6_1). unfold magma_op, refa711_inst, refa711_op in H. discriminate H. Qed.

Lemma refa711_not2644 : ~ @Equation2644 Fin6 refa711_inst.
Proof. unfold Equation2644. intro H. specialize (H F6_0). unfold magma_op, refa711_inst, refa711_op in H. discriminate H. Qed.

Lemma refa711_not2865 : ~ @Equation2865 Fin6 refa711_inst.
Proof. unfold Equation2865. intro H. specialize (H F6_0 F6_1). unfold magma_op, refa711_inst, refa711_op in H. discriminate H. Qed.

Lemma refa711_not2875 : ~ @Equation2875 Fin6 refa711_inst.
Proof. unfold Equation2875. intro H. specialize (H F6_0 F6_1). unfold magma_op, refa711_inst, refa711_op in H. discriminate H. Qed.

Lemma refa711_not3253 : ~ @Equation3253 Fin6 refa711_inst.
Proof. unfold Equation3253. intro H. specialize (H F6_0). unfold magma_op, refa711_inst, refa711_op in H. discriminate H. Qed.

Lemma refa711_not3518 : ~ @Equation3518 Fin6 refa711_inst.
Proof. unfold Equation3518. intro H. specialize (H F6_0 F6_1). unfold magma_op, refa711_inst, refa711_op in H. discriminate H. Qed.

Lemma refa711_not3519 : ~ @Equation3519 Fin6 refa711_inst.
Proof. unfold Equation3519. intro H. specialize (H F6_0 F6_1). unfold magma_op, refa711_inst, refa711_op in H. discriminate H. Qed.

Lemma refa711_not3521 : ~ @Equation3521 Fin6 refa711_inst.
Proof. unfold Equation3521. intro H. specialize (H F6_0 F6_1). unfold magma_op, refa711_inst, refa711_op in H. discriminate H. Qed.

Lemma refa711_not3522 : ~ @Equation3522 Fin6 refa711_inst.
Proof. unfold Equation3522. intro H. specialize (H F6_0 F6_1). unfold magma_op, refa711_inst, refa711_op in H. discriminate H. Qed.

Lemma refa711_not4598 : ~ @Equation4598 Fin6 refa711_inst.
Proof. unfold Equation4598. intro H. specialize (H F6_0 F6_1). unfold magma_op, refa711_inst, refa711_op in H. discriminate H. Qed.

Lemma refa711_not4656 : ~ @Equation4656 Fin6 refa711_inst.
Proof. unfold Equation4656. intro H. specialize (H F6_0 F6_0 F6_1). unfold magma_op, refa711_inst, refa711_op in H. discriminate H. Qed.

(** ---- refa712 (Fin7) ---- *)

Definition refa712_op (x y : Fin7) : Fin7 :=
  match x, y with
  | F7_0, F7_0 => F7_3 | F7_0, F7_1 => F7_2 | F7_0, F7_2 => F7_3 | F7_0, F7_3 => F7_3 | F7_0, F7_4 => F7_3 | F7_0, F7_5 => F7_3 | F7_0, F7_6 => F7_3
  | F7_1, F7_0 => F7_1 | F7_1, F7_1 => F7_1 | F7_1, F7_2 => F7_1 | F7_1, F7_3 => F7_1 | F7_1, F7_4 => F7_1 | F7_1, F7_5 => F7_1 | F7_1, F7_6 => F7_1
  | F7_2, F7_0 => F7_6 | F7_2, F7_1 => F7_4 | F7_2, F7_2 => F7_2 | F7_2, F7_3 => F7_2 | F7_2, F7_4 => F7_5 | F7_2, F7_5 => F7_2 | F7_2, F7_6 => F7_2
  | F7_3, F7_0 => F7_4 | F7_3, F7_1 => F7_6 | F7_3, F7_2 => F7_4 | F7_3, F7_3 => F7_4 | F7_3, F7_4 => F7_4 | F7_3, F7_5 => F7_4 | F7_3, F7_6 => F7_4
  | F7_4, F7_0 => F7_0 | F7_4, F7_1 => F7_5 | F7_4, F7_2 => F7_0 | F7_4, F7_3 => F7_0 | F7_4, F7_4 => F7_0 | F7_4, F7_5 => F7_0 | F7_4, F7_6 => F7_0
  | F7_5, F7_0 => F7_5 | F7_5, F7_1 => F7_3 | F7_5, F7_2 => F7_5 | F7_5, F7_3 => F7_6 | F7_5, F7_4 => F7_2 | F7_5, F7_5 => F7_5 | F7_5, F7_6 => F7_5
  | F7_6, F7_0 => F7_2 | F7_6, F7_1 => F7_0 | F7_6, F7_2 => F7_6 | F7_6, F7_3 => F7_5 | F7_6, F7_4 => F7_6 | F7_6, F7_5 => F7_6 | F7_6, F7_6 => F7_6
  end.

#[local] Instance refa712_inst : Magma Fin7 := {| magma_op := refa712_op |}.

Lemma refa712_sat261 : @Equation261 Fin7 refa712_inst.
Proof. unfold Equation261, magma_op, refa712_inst, refa712_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa712_sat2061 : @Equation2061 Fin7 refa712_inst.
Proof. unfold Equation2061, magma_op, refa712_inst, refa712_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa712_not2660 : ~ @Equation2660 Fin7 refa712_inst.
Proof. unfold Equation2660. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa712_inst, refa712_op in H. discriminate H. Qed.

Lemma refa712_not2669 : ~ @Equation2669 Fin7 refa712_inst.
Proof. unfold Equation2669. intro H. specialize (H F7_2 F7_0). unfold magma_op, refa712_inst, refa712_op in H. discriminate H. Qed.

Lemma refa712_not2852 : ~ @Equation2852 Fin7 refa712_inst.
Proof. unfold Equation2852. intro H. specialize (H F7_2 F7_1). unfold magma_op, refa712_inst, refa712_op in H. discriminate H. Qed.

Lemma refa712_not2856 : ~ @Equation2856 Fin7 refa712_inst.
Proof. unfold Equation2856. intro H. specialize (H F7_2 F7_1). unfold magma_op, refa712_inst, refa712_op in H. discriminate H. Qed.

Lemma refa712_not2865 : ~ @Equation2865 Fin7 refa712_inst.
Proof. unfold Equation2865. intro H. specialize (H F7_2 F7_0). unfold magma_op, refa712_inst, refa712_op in H. discriminate H. Qed.

Lemma refa712_not2873 : ~ @Equation2873 Fin7 refa712_inst.
Proof. unfold Equation2873. intro H. specialize (H F7_2 F7_0). unfold magma_op, refa712_inst, refa712_op in H. discriminate H. Qed.

Lemma refa712_not3255 : ~ @Equation3255 Fin7 refa712_inst.
Proof. unfold Equation3255. intro H. specialize (H F7_2 F7_1). unfold magma_op, refa712_inst, refa712_op in H. discriminate H. Qed.

Lemma refa712_not3256 : ~ @Equation3256 Fin7 refa712_inst.
Proof. unfold Equation3256. intro H. specialize (H F7_2 F7_1). unfold magma_op, refa712_inst, refa712_op in H. discriminate H. Qed.

Lemma refa712_not3315 : ~ @Equation3315 Fin7 refa712_inst.
Proof. unfold Equation3315. intro H. specialize (H F7_2 F7_0). unfold magma_op, refa712_inst, refa712_op in H. discriminate H. Qed.

Lemma refa712_not3316 : ~ @Equation3316 Fin7 refa712_inst.
Proof. unfold Equation3316. intro H. specialize (H F7_2 F7_0). unfold magma_op, refa712_inst, refa712_op in H. discriminate H. Qed.

Lemma refa712_not3318 : ~ @Equation3318 Fin7 refa712_inst.
Proof. unfold Equation3318. intro H. specialize (H F7_2 F7_0). unfold magma_op, refa712_inst, refa712_op in H. discriminate H. Qed.

Lemma refa712_not3457 : ~ @Equation3457 Fin7 refa712_inst.
Proof. unfold Equation3457. intro H. specialize (H F7_2 F7_1). unfold magma_op, refa712_inst, refa712_op in H. discriminate H. Qed.

Lemma refa712_not3458 : ~ @Equation3458 Fin7 refa712_inst.
Proof. unfold Equation3458. intro H. specialize (H F7_2 F7_1). unfold magma_op, refa712_inst, refa712_op in H. discriminate H. Qed.

Lemma refa712_not3519 : ~ @Equation3519 Fin7 refa712_inst.
Proof. unfold Equation3519. intro H. specialize (H F7_2 F7_0). unfold magma_op, refa712_inst, refa712_op in H. discriminate H. Qed.

Lemma refa712_not3521 : ~ @Equation3521 Fin7 refa712_inst.
Proof. unfold Equation3521. intro H. specialize (H F7_2 F7_0). unfold magma_op, refa712_inst, refa712_op in H. discriminate H. Qed.

Lemma refa712_not4268 : ~ @Equation4268 Fin7 refa712_inst.
Proof. unfold Equation4268. intro H. specialize (H F7_2 F7_1). unfold magma_op, refa712_inst, refa712_op in H. discriminate H. Qed.

Lemma refa712_not4598 : ~ @Equation4598 Fin7 refa712_inst.
Proof. unfold Equation4598. intro H. specialize (H F7_2 F7_1). unfold magma_op, refa712_inst, refa712_op in H. discriminate H. Qed.

Lemma refa712_not4656 : ~ @Equation4656 Fin7 refa712_inst.
Proof. unfold Equation4656. intro H. specialize (H F7_2 F7_0 F7_1). unfold magma_op, refa712_inst, refa712_op in H. discriminate H. Qed.

(** ---- refa713 (Fin7) ---- *)

Definition refa713_op (x y : Fin7) : Fin7 :=
  match x, y with
  | F7_0, F7_0 => F7_2 | F7_0, F7_1 => F7_4 | F7_0, F7_2 => F7_2 | F7_0, F7_3 => F7_4 | F7_0, F7_4 => F7_5 | F7_0, F7_5 => F7_1 | F7_0, F7_6 => F7_4
  | F7_1, F7_0 => F7_5 | F7_1, F7_1 => F7_1 | F7_1, F7_2 => F7_6 | F7_1, F7_3 => F7_2 | F7_1, F7_4 => F7_0 | F7_1, F7_5 => F7_4 | F7_1, F7_6 => F7_3
  | F7_2, F7_0 => F7_0 | F7_2, F7_1 => F7_3 | F7_2, F7_2 => F7_0 | F7_2, F7_3 => F7_6 | F7_2, F7_4 => F7_3 | F7_2, F7_5 => F7_3 | F7_2, F7_6 => F7_1
  | F7_3, F7_0 => F7_3 | F7_3, F7_1 => F7_6 | F7_3, F7_2 => F7_1 | F7_3, F7_3 => F7_3 | F7_3, F7_4 => F7_6 | F7_3, F7_5 => F7_6 | F7_3, F7_6 => F7_2
  | F7_4, F7_0 => F7_1 | F7_4, F7_1 => F7_5 | F7_4, F7_2 => F7_4 | F7_4, F7_3 => F7_5 | F7_4, F7_4 => F7_4 | F7_4, F7_5 => F7_0 | F7_4, F7_6 => F7_5
  | F7_5, F7_0 => F7_4 | F7_5, F7_1 => F7_0 | F7_5, F7_2 => F7_5 | F7_5, F7_3 => F7_0 | F7_5, F7_4 => F7_1 | F7_5, F7_5 => F7_5 | F7_5, F7_6 => F7_0
  | F7_6, F7_0 => F7_6 | F7_6, F7_1 => F7_2 | F7_6, F7_2 => F7_3 | F7_6, F7_3 => F7_1 | F7_6, F7_4 => F7_2 | F7_6, F7_5 => F7_2 | F7_6, F7_6 => F7_6
  end.

#[local] Instance refa713_inst : Magma Fin7 := {| magma_op := refa713_op |}.

Lemma refa713_sat206 : @Equation206 Fin7 refa713_inst.
Proof. unfold Equation206, magma_op, refa713_inst, refa713_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa713_sat1648 : @Equation1648 Fin7 refa713_inst.
Proof. unfold Equation1648, magma_op, refa713_inst, refa713_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa713_not2444 : ~ @Equation2444 Fin7 refa713_inst.
Proof. unfold Equation2444. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa713_inst, refa713_op in H. discriminate H. Qed.

Lemma refa713_not3078 : ~ @Equation3078 Fin7 refa713_inst.
Proof. unfold Equation3078. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa713_inst, refa713_op in H. discriminate H. Qed.

Lemma refa713_not4074 : ~ @Equation4074 Fin7 refa713_inst.
Proof. unfold Equation4074. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa713_inst, refa713_op in H. discriminate H. Qed.

(** ---- refa714 (Fin6) ---- *)

Definition refa714_op (x y : Fin6) : Fin6 :=
  match x, y with
  | F6_0, F6_0 => F6_2 | F6_0, F6_1 => F6_4 | F6_0, F6_2 => F6_0 | F6_0, F6_3 => F6_2 | F6_0, F6_4 => F6_4 | F6_0, F6_5 => F6_0
  | F6_1, F6_0 => F6_2 | F6_1, F6_1 => F6_1 | F6_1, F6_2 => F6_3 | F6_1, F6_3 => F6_2 | F6_1, F6_4 => F6_1 | F6_1, F6_5 => F6_3
  | F6_2, F6_0 => F6_2 | F6_2, F6_1 => F6_1 | F6_2, F6_2 => F6_0 | F6_2, F6_3 => F6_2 | F6_2, F6_4 => F6_1 | F6_2, F6_5 => F6_0
  | F6_3, F6_0 => F6_5 | F6_3, F6_1 => F6_1 | F6_3, F6_2 => F6_3 | F6_3, F6_3 => F6_5 | F6_3, F6_4 => F6_1 | F6_3, F6_5 => F6_3
  | F6_4, F6_0 => F6_5 | F6_4, F6_1 => F6_4 | F6_4, F6_2 => F6_0 | F6_4, F6_3 => F6_5 | F6_4, F6_4 => F6_4 | F6_4, F6_5 => F6_0
  | F6_5, F6_0 => F6_5 | F6_5, F6_1 => F6_4 | F6_5, F6_2 => F6_3 | F6_5, F6_3 => F6_5 | F6_5, F6_4 => F6_4 | F6_5, F6_5 => F6_3
  end.

#[local] Instance refa714_inst : Magma Fin6 := {| magma_op := refa714_op |}.

Lemma refa714_sat2066 : @Equation2066 Fin6 refa714_inst.
Proof. unfold Equation2066, magma_op, refa714_inst, refa714_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa714_not2040 : ~ @Equation2040 Fin6 refa714_inst.
Proof. unfold Equation2040. intro H. specialize (H F6_0 F6_1). unfold magma_op, refa714_inst, refa714_op in H. discriminate H. Qed.

Lemma refa714_not2043 : ~ @Equation2043 Fin6 refa714_inst.
Proof. unfold Equation2043. intro H. specialize (H F6_0 F6_1). unfold magma_op, refa714_inst, refa714_op in H. discriminate H. Qed.

Lemma refa714_not2050 : ~ @Equation2050 Fin6 refa714_inst.
Proof. unfold Equation2050. intro H. specialize (H F6_0 F6_1). unfold magma_op, refa714_inst, refa714_op in H. discriminate H. Qed.

Lemma refa714_not2053 : ~ @Equation2053 Fin6 refa714_inst.
Proof. unfold Equation2053. intro H. specialize (H F6_0 F6_1). unfold magma_op, refa714_inst, refa714_op in H. discriminate H. Qed.

Lemma refa714_not4599 : ~ @Equation4599 Fin6 refa714_inst.
Proof. unfold Equation4599. intro H. specialize (H F6_0 F6_1). unfold magma_op, refa714_inst, refa714_op in H. discriminate H. Qed.

Lemma refa714_not4631 : ~ @Equation4631 Fin6 refa714_inst.
Proof. unfold Equation4631. intro H. specialize (H F6_0 F6_0 F6_1). unfold magma_op, refa714_inst, refa714_op in H. discriminate H. Qed.

(** ---- refa715 (Fin6) ---- *)

Definition refa715_op (x y : Fin6) : Fin6 :=
  match x, y with
  | F6_0, F6_0 => F6_1 | F6_0, F6_1 => F6_2 | F6_0, F6_2 => F6_2 | F6_0, F6_3 => F6_2 | F6_0, F6_4 => F6_1 | F6_0, F6_5 => F6_2
  | F6_1, F6_0 => F6_4 | F6_1, F6_1 => F6_4 | F6_1, F6_2 => F6_4 | F6_1, F6_3 => F6_3 | F6_1, F6_4 => F6_4 | F6_1, F6_5 => F6_3
  | F6_2, F6_0 => F6_4 | F6_2, F6_1 => F6_4 | F6_2, F6_2 => F6_3 | F6_2, F6_3 => F6_3 | F6_2, F6_4 => F6_3 | F6_2, F6_5 => F6_3
  | F6_3, F6_0 => F6_0 | F6_3, F6_1 => F6_0 | F6_3, F6_2 => F6_5 | F6_3, F6_3 => F6_5 | F6_3, F6_4 => F6_0 | F6_3, F6_5 => F6_0
  | F6_4, F6_0 => F6_0 | F6_4, F6_1 => F6_0 | F6_4, F6_2 => F6_5 | F6_4, F6_3 => F6_0 | F6_4, F6_4 => F6_0 | F6_4, F6_5 => F6_0
  | F6_5, F6_0 => F6_1 | F6_5, F6_1 => F6_2 | F6_5, F6_2 => F6_2 | F6_5, F6_3 => F6_2 | F6_5, F6_4 => F6_1 | F6_5, F6_5 => F6_2
  end.

#[local] Instance refa715_inst : Magma Fin6 := {| magma_op := refa715_op |}.

Lemma refa715_sat2070 : @Equation2070 Fin6 refa715_inst.
Proof. unfold Equation2070, magma_op, refa715_inst, refa715_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa715_not3253 : ~ @Equation3253 Fin6 refa715_inst.
Proof. unfold Equation3253. intro H. specialize (H F6_0). unfold magma_op, refa715_inst, refa715_op in H. discriminate H. Qed.

(** ---- refa716 (Fin6) ---- *)

Definition refa716_op (x y : Fin6) : Fin6 :=
  match x, y with
  | F6_0, F6_0 => F6_2 | F6_0, F6_1 => F6_1 | F6_0, F6_2 => F6_2 | F6_0, F6_3 => F6_1 | F6_0, F6_4 => F6_1 | F6_0, F6_5 => F6_2
  | F6_1, F6_0 => F6_3 | F6_1, F6_1 => F6_3 | F6_1, F6_2 => F6_5 | F6_1, F6_3 => F6_5 | F6_1, F6_4 => F6_5 | F6_1, F6_5 => F6_3
  | F6_2, F6_0 => F6_3 | F6_2, F6_1 => F6_3 | F6_2, F6_2 => F6_5 | F6_2, F6_3 => F6_5 | F6_2, F6_4 => F6_5 | F6_2, F6_5 => F6_3
  | F6_3, F6_0 => F6_0 | F6_3, F6_1 => F6_4 | F6_3, F6_2 => F6_0 | F6_3, F6_3 => F6_0 | F6_3, F6_4 => F6_4 | F6_3, F6_5 => F6_4
  | F6_4, F6_0 => F6_2 | F6_4, F6_1 => F6_1 | F6_4, F6_2 => F6_2 | F6_4, F6_3 => F6_1 | F6_4, F6_4 => F6_1 | F6_4, F6_5 => F6_2
  | F6_5, F6_0 => F6_0 | F6_5, F6_1 => F6_4 | F6_5, F6_2 => F6_0 | F6_5, F6_3 => F6_0 | F6_5, F6_4 => F6_4 | F6_5, F6_5 => F6_4
  end.

#[local] Instance refa716_inst : Magma Fin6 := {| magma_op := refa716_op |}.

Lemma refa716_sat2074 : @Equation2074 Fin6 refa716_inst.
Proof. unfold Equation2074, magma_op, refa716_inst, refa716_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa716_not3255 : ~ @Equation3255 Fin6 refa716_inst.
Proof. unfold Equation3255. intro H. specialize (H F6_0 F6_1). unfold magma_op, refa716_inst, refa716_op in H. discriminate H. Qed.

Lemma refa716_not3261 : ~ @Equation3261 Fin6 refa716_inst.
Proof. unfold Equation3261. intro H. specialize (H F6_1 F6_3). unfold magma_op, refa716_inst, refa716_op in H. discriminate H. Qed.

Lemma refa716_not3309 : ~ @Equation3309 Fin6 refa716_inst.
Proof. unfold Equation3309. intro H. specialize (H F6_0 F6_3). unfold magma_op, refa716_inst, refa716_op in H. discriminate H. Qed.

Lemma refa716_not3319 : ~ @Equation3319 Fin6 refa716_inst.
Proof. unfold Equation3319. intro H. specialize (H F6_0 F6_1). unfold magma_op, refa716_inst, refa716_op in H. discriminate H. Qed.

Lemma refa716_not4269 : ~ @Equation4269 Fin6 refa716_inst.
Proof. unfold Equation4269. intro H. specialize (H F6_0 F6_1). unfold magma_op, refa716_inst, refa716_op in H. discriminate H. Qed.

Lemma refa716_not4284 : ~ @Equation4284 Fin6 refa716_inst.
Proof. unfold Equation4284. intro H. specialize (H F6_0 F6_3). unfold magma_op, refa716_inst, refa716_op in H. discriminate H. Qed.

(** ---- refa717 (Fin6) ---- *)

Definition refa717_op (x y : Fin6) : Fin6 :=
  match x, y with
  | F6_0, F6_0 => F6_1 | F6_0, F6_1 => F6_2 | F6_0, F6_2 => F6_3 | F6_0, F6_3 => F6_4 | F6_0, F6_4 => F6_5 | F6_0, F6_5 => F6_0
  | F6_1, F6_0 => F6_5 | F6_1, F6_1 => F6_0 | F6_1, F6_2 => F6_1 | F6_1, F6_3 => F6_2 | F6_1, F6_4 => F6_3 | F6_1, F6_5 => F6_4
  | F6_2, F6_0 => F6_1 | F6_2, F6_1 => F6_2 | F6_2, F6_2 => F6_3 | F6_2, F6_3 => F6_4 | F6_2, F6_4 => F6_5 | F6_2, F6_5 => F6_0
  | F6_3, F6_0 => F6_5 | F6_3, F6_1 => F6_0 | F6_3, F6_2 => F6_1 | F6_3, F6_3 => F6_2 | F6_3, F6_4 => F6_3 | F6_3, F6_5 => F6_4
  | F6_4, F6_0 => F6_1 | F6_4, F6_1 => F6_2 | F6_4, F6_2 => F6_3 | F6_4, F6_3 => F6_4 | F6_4, F6_4 => F6_5 | F6_4, F6_5 => F6_0
  | F6_5, F6_0 => F6_5 | F6_5, F6_1 => F6_0 | F6_5, F6_2 => F6_1 | F6_5, F6_3 => F6_2 | F6_5, F6_4 => F6_3 | F6_5, F6_5 => F6_4
  end.

#[local] Instance refa717_inst : Magma Fin6 := {| magma_op := refa717_op |}.

Lemma refa717_sat194 : @Equation194 Fin6 refa717_inst.
Proof. unfold Equation194, magma_op, refa717_inst, refa717_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa717_not411 : ~ @Equation411 Fin6 refa717_inst.
Proof. unfold Equation411. intro H. specialize (H F6_0). unfold magma_op, refa717_inst, refa717_op in H. discriminate H. Qed.

Lemma refa717_not4275 : ~ @Equation4275 Fin6 refa717_inst.
Proof. unfold Equation4275. intro H. specialize (H F6_0 F6_1). unfold magma_op, refa717_inst, refa717_op in H. discriminate H. Qed.

(** ---- refa718 (Fin6) ---- *)

Definition refa718_op (x y : Fin6) : Fin6 :=
  match x, y with
  | F6_0, F6_0 => F6_1 | F6_0, F6_1 => F6_2 | F6_0, F6_2 => F6_4 | F6_0, F6_3 => F6_1 | F6_0, F6_4 => F6_4 | F6_0, F6_5 => F6_4
  | F6_1, F6_0 => F6_3 | F6_1, F6_1 => F6_0 | F6_1, F6_2 => F6_3 | F6_1, F6_3 => F6_3 | F6_1, F6_4 => F6_0 | F6_1, F6_5 => F6_3
  | F6_2, F6_0 => F6_5 | F6_2, F6_1 => F6_5 | F6_2, F6_2 => F6_5 | F6_2, F6_3 => F6_0 | F6_2, F6_4 => F6_5 | F6_2, F6_5 => F6_5
  | F6_3, F6_0 => F6_4 | F6_3, F6_1 => F6_1 | F6_3, F6_2 => F6_1 | F6_3, F6_3 => F6_4 | F6_3, F6_4 => F6_1 | F6_3, F6_5 => F6_1
  | F6_4, F6_0 => F6_0 | F6_4, F6_1 => F6_3 | F6_4, F6_2 => F6_0 | F6_4, F6_3 => F6_5 | F6_4, F6_4 => F6_3 | F6_4, F6_5 => F6_0
  | F6_5, F6_0 => F6_2 | F6_5, F6_1 => F6_4 | F6_5, F6_2 => F6_2 | F6_5, F6_3 => F6_2 | F6_5, F6_4 => F6_2 | F6_5, F6_5 => F6_2
  end.

#[local] Instance refa718_inst : Magma Fin6 := {| magma_op := refa718_op |}.

Lemma refa718_sat2260 : @Equation2260 Fin6 refa718_inst.
Proof. unfold Equation2260, magma_op, refa718_inst, refa718_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa718_not203 : ~ @Equation203 Fin6 refa718_inst.
Proof. unfold Equation203. intro H. specialize (H F6_0). unfold magma_op, refa718_inst, refa718_op in H. discriminate H. Qed.

Lemma refa718_not1426 : ~ @Equation1426 Fin6 refa718_inst.
Proof. unfold Equation1426. intro H. specialize (H F6_0). unfold magma_op, refa718_inst, refa718_op in H. discriminate H. Qed.

Lemma refa718_not3050 : ~ @Equation3050 Fin6 refa718_inst.
Proof. unfold Equation3050. intro H. specialize (H F6_1). unfold magma_op, refa718_inst, refa718_op in H. discriminate H. Qed.

Lemma refa718_not3456 : ~ @Equation3456 Fin6 refa718_inst.
Proof. unfold Equation3456. intro H. specialize (H F6_1). unfold magma_op, refa718_inst, refa718_op in H. discriminate H. Qed.

Lemma refa718_not4656 : ~ @Equation4656 Fin6 refa718_inst.
Proof. unfold Equation4656. intro H. specialize (H F6_0 F6_0 F6_1). unfold magma_op, refa718_inst, refa718_op in H. discriminate H. Qed.

(** ---- refa719 (Fin6) ---- *)

Definition refa719_op (x y : Fin6) : Fin6 :=
  match x, y with
  | F6_0, F6_0 => F6_1 | F6_0, F6_1 => F6_2 | F6_0, F6_2 => F6_5 | F6_0, F6_3 => F6_1 | F6_0, F6_4 => F6_5 | F6_0, F6_5 => F6_5
  | F6_1, F6_0 => F6_4 | F6_1, F6_1 => F6_4 | F6_1, F6_2 => F6_0 | F6_1, F6_3 => F6_4 | F6_1, F6_4 => F6_4 | F6_1, F6_5 => F6_0
  | F6_2, F6_0 => F6_3 | F6_2, F6_1 => F6_3 | F6_2, F6_2 => F6_4 | F6_2, F6_3 => F6_3 | F6_2, F6_4 => F6_0 | F6_2, F6_5 => F6_4
  | F6_3, F6_0 => F6_5 | F6_3, F6_1 => F6_5 | F6_3, F6_2 => F6_2 | F6_3, F6_3 => F6_5 | F6_3, F6_4 => F6_2 | F6_3, F6_5 => F6_2
  | F6_4, F6_0 => F6_2 | F6_4, F6_1 => F6_1 | F6_4, F6_2 => F6_1 | F6_4, F6_3 => F6_2 | F6_4, F6_4 => F6_1 | F6_4, F6_5 => F6_1
  | F6_5, F6_0 => F6_0 | F6_5, F6_1 => F6_0 | F6_5, F6_2 => F6_3 | F6_5, F6_3 => F6_0 | F6_5, F6_4 => F6_3 | F6_5, F6_5 => F6_3
  end.

#[local] Instance refa719_inst : Magma Fin6 := {| magma_op := refa719_op |}.

Lemma refa719_sat1456 : @Equation1456 Fin6 refa719_inst.
Proof. unfold Equation1456, magma_op, refa719_inst, refa719_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa719_not203 : ~ @Equation203 Fin6 refa719_inst.
Proof. unfold Equation203. intro H. specialize (H F6_0). unfold magma_op, refa719_inst, refa719_op in H. discriminate H. Qed.

Lemma refa719_not1429 : ~ @Equation1429 Fin6 refa719_inst.
Proof. unfold Equation1429. intro H. specialize (H F6_0 F6_5). unfold magma_op, refa719_inst, refa719_op in H. discriminate H. Qed.

Lemma refa719_not1451 : ~ @Equation1451 Fin6 refa719_inst.
Proof. unfold Equation1451. intro H. specialize (H F6_3 F6_1). unfold magma_op, refa719_inst, refa719_op in H. discriminate H. Qed.

Lemma refa719_not2246 : ~ @Equation2246 Fin6 refa719_inst.
Proof. unfold Equation2246. intro H. specialize (H F6_0 F6_5). unfold magma_op, refa719_inst, refa719_op in H. discriminate H. Qed.

Lemma refa719_not2254 : ~ @Equation2254 Fin6 refa719_inst.
Proof. unfold Equation2254. intro H. specialize (H F6_3 F6_1). unfold magma_op, refa719_inst, refa719_op in H. discriminate H. Qed.

Lemma refa719_not3050 : ~ @Equation3050 Fin6 refa719_inst.
Proof. unfold Equation3050. intro H. specialize (H F6_0). unfold magma_op, refa719_inst, refa719_op in H. discriminate H. Qed.

Lemma refa719_not4268 : ~ @Equation4268 Fin6 refa719_inst.
Proof. unfold Equation4268. intro H. specialize (H F6_0 F6_1). unfold magma_op, refa719_inst, refa719_op in H. discriminate H. Qed.

(** ---- refa72 (Fin3) ---- *)

Definition refa72_op (x y : Fin3) : Fin3 :=
  match x, y with
  | F3_0, F3_0 => F3_0 | F3_0, F3_1 => F3_0 | F3_0, F3_2 => F3_2
  | F3_1, F3_0 => F3_1 | F3_1, F3_1 => F3_2 | F3_1, F3_2 => F3_2
  | F3_2, F3_0 => F3_1 | F3_2, F3_1 => F3_0 | F3_2, F3_2 => F3_1
  end.

#[local] Instance refa72_inst : Magma Fin3 := {| magma_op := refa72_op |}.

Lemma refa72_sat159 : @Equation159 Fin3 refa72_inst.
Proof. unfold Equation159, magma_op, refa72_inst, refa72_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa72_sat1640 : @Equation1640 Fin3 refa72_inst.
Proof. unfold Equation1640, magma_op, refa72_inst, refa72_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa72_not1426 : ~ @Equation1426 Fin3 refa72_inst.
Proof. unfold Equation1426. intro H. specialize (H F3_2). unfold magma_op, refa72_inst, refa72_op in H. discriminate H. Qed.

Lemma refa72_not1644 : ~ @Equation1644 Fin3 refa72_inst.
Proof. unfold Equation1644. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa72_inst, refa72_op in H. discriminate H. Qed.

Lemma refa72_not1654 : ~ @Equation1654 Fin3 refa72_inst.
Proof. unfold Equation1654. intro H. specialize (H F3_2 F3_1). unfold magma_op, refa72_inst, refa72_op in H. discriminate H. Qed.

Lemma refa72_not1657 : ~ @Equation1657 Fin3 refa72_inst.
Proof. unfold Equation1657. intro H. specialize (H F3_2 F3_1). unfold magma_op, refa72_inst, refa72_op in H. discriminate H. Qed.

Lemma refa72_not1832 : ~ @Equation1832 Fin3 refa72_inst.
Proof. unfold Equation1832. intro H. specialize (H F3_2). unfold magma_op, refa72_inst, refa72_op in H. discriminate H. Qed.

Lemma refa72_not2035 : ~ @Equation2035 Fin3 refa72_inst.
Proof. unfold Equation2035. intro H. specialize (H F3_1). unfold magma_op, refa72_inst, refa72_op in H. discriminate H. Qed.

Lemma refa72_not3255 : ~ @Equation3255 Fin3 refa72_inst.
Proof. unfold Equation3255. intro H. specialize (H F3_2 F3_0). unfold magma_op, refa72_inst, refa72_op in H. discriminate H. Qed.

Lemma refa72_not3261 : ~ @Equation3261 Fin3 refa72_inst.
Proof. unfold Equation3261. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa72_inst, refa72_op in H. discriminate H. Qed.

Lemma refa72_not3306 : ~ @Equation3306 Fin3 refa72_inst.
Proof. unfold Equation3306. intro H. specialize (H F3_1 F3_0). unfold magma_op, refa72_inst, refa72_op in H. discriminate H. Qed.

Lemma refa72_not3309 : ~ @Equation3309 Fin3 refa72_inst.
Proof. unfold Equation3309. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa72_inst, refa72_op in H. discriminate H. Qed.

Lemma refa72_not3316 : ~ @Equation3316 Fin3 refa72_inst.
Proof. unfold Equation3316. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa72_inst, refa72_op in H. discriminate H. Qed.

Lemma refa72_not3319 : ~ @Equation3319 Fin3 refa72_inst.
Proof. unfold Equation3319. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa72_inst, refa72_op in H. discriminate H. Qed.

Lemma refa72_not3456 : ~ @Equation3456 Fin3 refa72_inst.
Proof. unfold Equation3456. intro H. specialize (H F3_1). unfold magma_op, refa72_inst, refa72_op in H. discriminate H. Qed.

Lemma refa72_not3862 : ~ @Equation3862 Fin3 refa72_inst.
Proof. unfold Equation3862. intro H. specialize (H F3_1). unfold magma_op, refa72_inst, refa72_op in H. discriminate H. Qed.

Lemma refa72_not4065 : ~ @Equation4065 Fin3 refa72_inst.
Proof. unfold Equation4065. intro H. specialize (H F3_1). unfold magma_op, refa72_inst, refa72_op in H. discriminate H. Qed.

Lemma refa72_not4269 : ~ @Equation4269 Fin3 refa72_inst.
Proof. unfold Equation4269. intro H. specialize (H F3_1 F3_0). unfold magma_op, refa72_inst, refa72_op in H. discriminate H. Qed.

Lemma refa72_not4284 : ~ @Equation4284 Fin3 refa72_inst.
Proof. unfold Equation4284. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa72_inst, refa72_op in H. discriminate H. Qed.

Lemma refa72_not4380 : ~ @Equation4380 Fin3 refa72_inst.
Proof. unfold Equation4380. intro H. specialize (H F3_1). unfold magma_op, refa72_inst, refa72_op in H. discriminate H. Qed.

Lemma refa72_not4599 : ~ @Equation4599 Fin3 refa72_inst.
Proof. unfold Equation4599. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa72_inst, refa72_op in H. discriminate H. Qed.

Lemma refa72_not4631 : ~ @Equation4631 Fin3 refa72_inst.
Proof. unfold Equation4631. intro H. specialize (H F3_0 F3_0 F3_2). unfold magma_op, refa72_inst, refa72_op in H. discriminate H. Qed.

(** ---- refa720 (Fin5) ---- *)

Definition refa720_op (x y : Fin5) : Fin5 :=
  match x, y with
  | F5_0, F5_0 => F5_2 | F5_0, F5_1 => F5_2 | F5_0, F5_2 => F5_4 | F5_0, F5_3 => F5_3 | F5_0, F5_4 => F5_3
  | F5_1, F5_0 => F5_4 | F5_1, F5_1 => F5_2 | F5_1, F5_2 => F5_3 | F5_1, F5_3 => F5_2 | F5_1, F5_4 => F5_3
  | F5_2, F5_0 => F5_4 | F5_2, F5_1 => F5_1 | F5_2, F5_2 => F5_2 | F5_2, F5_3 => F5_3 | F5_2, F5_4 => F5_4
  | F5_3, F5_0 => F5_0 | F5_3, F5_1 => F5_1 | F5_3, F5_2 => F5_2 | F5_3, F5_3 => F5_3 | F5_3, F5_4 => F5_4
  | F5_4, F5_0 => F5_0 | F5_4, F5_1 => F5_2 | F5_4, F5_2 => F5_2 | F5_4, F5_3 => F5_3 | F5_4, F5_4 => F5_4
  end.

#[local] Instance refa720_inst : Magma Fin5 := {| magma_op := refa720_op |}.

Lemma refa720_sat2314 : @Equation2314 Fin5 refa720_inst.
Proof. unfold Equation2314, magma_op, refa720_inst, refa720_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa720_not2330 : ~ @Equation2330 Fin5 refa720_inst.
Proof. unfold Equation2330. intro H. specialize (H F5_0 F5_1). unfold magma_op, refa720_inst, refa720_op in H. discriminate H. Qed.

(** ---- refa721 (Fin5) ---- *)

Definition refa721_op (x y : Fin5) : Fin5 :=
  match x, y with
  | F5_0, F5_0 => F5_0 | F5_0, F5_1 => F5_2 | F5_0, F5_2 => F5_2 | F5_0, F5_3 => F5_4 | F5_0, F5_4 => F5_3
  | F5_1, F5_0 => F5_3 | F5_1, F5_1 => F5_1 | F5_1, F5_2 => F5_3 | F5_1, F5_3 => F5_3 | F5_1, F5_4 => F5_4
  | F5_2, F5_0 => F5_0 | F5_2, F5_1 => F5_1 | F5_2, F5_2 => F5_2 | F5_2, F5_3 => F5_4 | F5_2, F5_4 => F5_3
  | F5_3, F5_0 => F5_0 | F5_3, F5_1 => F5_1 | F5_3, F5_2 => F5_2 | F5_3, F5_3 => F5_3 | F5_3, F5_4 => F5_4
  | F5_4, F5_0 => F5_2 | F5_4, F5_1 => F5_1 | F5_4, F5_2 => F5_3 | F5_4, F5_3 => F5_3 | F5_4, F5_4 => F5_4
  end.

#[local] Instance refa721_inst : Magma Fin5 := {| magma_op := refa721_op |}.

Lemma refa721_sat2347 : @Equation2347 Fin5 refa721_inst.
Proof. unfold Equation2347, magma_op, refa721_inst, refa721_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa721_not2669 : ~ @Equation2669 Fin5 refa721_inst.
Proof. unfold Equation2669. intro H. specialize (H F5_0 F5_1). unfold magma_op, refa721_inst, refa721_op in H. discriminate H. Qed.

Lemma refa721_not3306 : ~ @Equation3306 Fin5 refa721_inst.
Proof. unfold Equation3306. intro H. specialize (H F5_4 F5_0). unfold magma_op, refa721_inst, refa721_op in H. discriminate H. Qed.

Lemma refa721_not3353 : ~ @Equation3353 Fin5 refa721_inst.
Proof. unfold Equation3353. intro H. specialize (H F5_0 F5_1). unfold magma_op, refa721_inst, refa721_op in H. discriminate H. Qed.

(** ---- refa722 (Fin6) ---- *)

Definition refa722_op (x y : Fin6) : Fin6 :=
  match x, y with
  | F6_0, F6_0 => F6_0 | F6_0, F6_1 => F6_1 | F6_0, F6_2 => F6_1 | F6_0, F6_3 => F6_3 | F6_0, F6_4 => F6_4 | F6_0, F6_5 => F6_5
  | F6_1, F6_0 => F6_5 | F6_1, F6_1 => F6_1 | F6_1, F6_2 => F6_2 | F6_1, F6_3 => F6_4 | F6_1, F6_4 => F6_5 | F6_1, F6_5 => F6_5
  | F6_2, F6_0 => F6_3 | F6_2, F6_1 => F6_1 | F6_2, F6_2 => F6_2 | F6_2, F6_3 => F6_5 | F6_2, F6_4 => F6_5 | F6_2, F6_5 => F6_0
  | F6_3, F6_0 => F6_0 | F6_3, F6_1 => F6_1 | F6_3, F6_2 => F6_1 | F6_3, F6_3 => F6_3 | F6_3, F6_4 => F6_4 | F6_3, F6_5 => F6_5
  | F6_4, F6_0 => F6_5 | F6_4, F6_1 => F6_2 | F6_4, F6_2 => F6_1 | F6_4, F6_3 => F6_3 | F6_4, F6_4 => F6_4 | F6_4, F6_5 => F6_5
  | F6_5, F6_0 => F6_0 | F6_5, F6_1 => F6_2 | F6_5, F6_2 => F6_1 | F6_5, F6_3 => F6_3 | F6_5, F6_4 => F6_4 | F6_5, F6_5 => F6_5
  end.

#[local] Instance refa722_inst : Magma Fin6 := {| magma_op := refa722_op |}.

Lemma refa722_sat2381 : @Equation2381 Fin6 refa722_inst.
Proof. unfold Equation2381, magma_op, refa722_inst, refa722_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa722_not323 : ~ @Equation323 Fin6 refa722_inst.
Proof. unfold Equation323. intro H. specialize (H F6_1 F6_3). unfold magma_op, refa722_inst, refa722_op in H. discriminate H. Qed.

Lemma refa722_not1055 : ~ @Equation1055 Fin6 refa722_inst.
Proof. unfold Equation1055. intro H. specialize (H F6_0 F6_1 F6_2). unfold magma_op, refa722_inst, refa722_op in H. discriminate H. Qed.

Lemma refa722_not1958 : ~ @Equation1958 Fin6 refa722_inst.
Proof. unfold Equation1958. intro H. specialize (H F6_0 F6_1 F6_2). unfold magma_op, refa722_inst, refa722_op in H. discriminate H. Qed.

Lemma refa722_not2364 : ~ @Equation2364 Fin6 refa722_inst.
Proof. unfold Equation2364. intro H. specialize (H F6_0 F6_1 F6_2). unfold magma_op, refa722_inst, refa722_op in H. discriminate H. Qed.

Lemma refa722_not2584 : ~ @Equation2584 Fin6 refa722_inst.
Proof. unfold Equation2584. intro H. specialize (H F6_0 F6_1 F6_4). unfold magma_op, refa722_inst, refa722_op in H. discriminate H. Qed.

Lemma refa722_not2669 : ~ @Equation2669 Fin6 refa722_inst.
Proof. unfold Equation2669. intro H. specialize (H F6_0 F6_2). unfold magma_op, refa722_inst, refa722_op in H. discriminate H. Qed.

Lemma refa722_not3897 : ~ @Equation3897 Fin6 refa722_inst.
Proof. unfold Equation3897. intro H. specialize (H F6_0 F6_1 F6_2). unfold magma_op, refa722_inst, refa722_op in H. discriminate H. Qed.

(** ---- refa723 (Fin6) ---- *)

Definition refa723_op (x y : Fin6) : Fin6 :=
  match x, y with
  | F6_0, F6_0 => F6_0 | F6_0, F6_1 => F6_2 | F6_0, F6_2 => F6_5 | F6_0, F6_3 => F6_5 | F6_0, F6_4 => F6_5 | F6_0, F6_5 => F6_5
  | F6_1, F6_0 => F6_5 | F6_1, F6_1 => F6_1 | F6_1, F6_2 => F6_5 | F6_1, F6_3 => F6_4 | F6_1, F6_4 => F6_5 | F6_1, F6_5 => F6_5
  | F6_2, F6_0 => F6_3 | F6_2, F6_1 => F6_1 | F6_2, F6_2 => F6_2 | F6_2, F6_3 => F6_5 | F6_2, F6_4 => F6_5 | F6_2, F6_5 => F6_5
  | F6_3, F6_0 => F6_0 | F6_3, F6_1 => F6_1 | F6_3, F6_2 => F6_5 | F6_3, F6_3 => F6_3 | F6_3, F6_4 => F6_5 | F6_3, F6_5 => F6_5
  | F6_4, F6_0 => F6_5 | F6_4, F6_1 => F6_1 | F6_4, F6_2 => F6_5 | F6_4, F6_3 => F6_3 | F6_4, F6_4 => F6_4 | F6_4, F6_5 => F6_5
  | F6_5, F6_0 => F6_0 | F6_5, F6_1 => F6_1 | F6_5, F6_2 => F6_2 | F6_5, F6_3 => F6_3 | F6_5, F6_4 => F6_4 | F6_5, F6_5 => F6_5
  end.

#[local] Instance refa723_inst : Magma Fin6 := {| magma_op := refa723_op |}.

Lemma refa723_sat2381 : @Equation2381 Fin6 refa723_inst.
Proof. unfold Equation2381, magma_op, refa723_inst, refa723_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa723_sat2398 : @Equation2398 Fin6 refa723_inst.
Proof. unfold Equation2398, magma_op, refa723_inst, refa723_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa723_not2503 : ~ @Equation2503 Fin6 refa723_inst.
Proof. unfold Equation2503. intro H. specialize (H F6_0 F6_1). unfold magma_op, refa723_inst, refa723_op in H. discriminate H. Qed.

Lemma refa723_not3306 : ~ @Equation3306 Fin6 refa723_inst.
Proof. unfold Equation3306. intro H. specialize (H F6_0 F6_1). unfold magma_op, refa723_inst, refa723_op in H. discriminate H. Qed.

Lemma refa723_not3309 : ~ @Equation3309 Fin6 refa723_inst.
Proof. unfold Equation3309. intro H. specialize (H F6_0 F6_1). unfold magma_op, refa723_inst, refa723_op in H. discriminate H. Qed.

Lemma refa723_not3316 : ~ @Equation3316 Fin6 refa723_inst.
Proof. unfold Equation3316. intro H. specialize (H F6_0 F6_1). unfold magma_op, refa723_inst, refa723_op in H. discriminate H. Qed.

Lemma refa723_not3343 : ~ @Equation3343 Fin6 refa723_inst.
Proof. unfold Equation3343. intro H. specialize (H F6_0 F6_1). unfold magma_op, refa723_inst, refa723_op in H. discriminate H. Qed.

Lemma refa723_not3346 : ~ @Equation3346 Fin6 refa723_inst.
Proof. unfold Equation3346. intro H. specialize (H F6_0 F6_1). unfold magma_op, refa723_inst, refa723_op in H. discriminate H. Qed.

Lemma refa723_not3353 : ~ @Equation3353 Fin6 refa723_inst.
Proof. unfold Equation3353. intro H. specialize (H F6_0 F6_1). unfold magma_op, refa723_inst, refa723_op in H. discriminate H. Qed.

Lemma refa723_not3509 : ~ @Equation3509 Fin6 refa723_inst.
Proof. unfold Equation3509. intro H. specialize (H F6_0 F6_1). unfold magma_op, refa723_inst, refa723_op in H. discriminate H. Qed.

Lemma refa723_not3519 : ~ @Equation3519 Fin6 refa723_inst.
Proof. unfold Equation3519. intro H. specialize (H F6_1 F6_0). unfold magma_op, refa723_inst, refa723_op in H. discriminate H. Qed.

Lemma refa723_not3546 : ~ @Equation3546 Fin6 refa723_inst.
Proof. unfold Equation3546. intro H. specialize (H F6_0 F6_1). unfold magma_op, refa723_inst, refa723_op in H. discriminate H. Qed.

Lemma refa723_not3556 : ~ @Equation3556 Fin6 refa723_inst.
Proof. unfold Equation3556. intro H. specialize (H F6_0 F6_1). unfold magma_op, refa723_inst, refa723_op in H. discriminate H. Qed.

Lemma refa723_not3712 : ~ @Equation3712 Fin6 refa723_inst.
Proof. unfold Equation3712. intro H. specialize (H F6_0 F6_1). unfold magma_op, refa723_inst, refa723_op in H. discriminate H. Qed.

Lemma refa723_not3749 : ~ @Equation3749 Fin6 refa723_inst.
Proof. unfold Equation3749. intro H. specialize (H F6_1 F6_3). unfold magma_op, refa723_inst, refa723_op in H. discriminate H. Qed.

Lemma refa723_not3752 : ~ @Equation3752 Fin6 refa723_inst.
Proof. unfold Equation3752. intro H. specialize (H F6_0 F6_1). unfold magma_op, refa723_inst, refa723_op in H. discriminate H. Qed.

Lemma refa723_not3759 : ~ @Equation3759 Fin6 refa723_inst.
Proof. unfold Equation3759. intro H. specialize (H F6_0 F6_1). unfold magma_op, refa723_inst, refa723_op in H. discriminate H. Qed.

Lemma refa723_not3897 : ~ @Equation3897 Fin6 refa723_inst.
Proof. unfold Equation3897. intro H. specialize (H F6_0 F6_1 F6_2). unfold magma_op, refa723_inst, refa723_op in H. discriminate H. Qed.

Lemma refa723_not3925 : ~ @Equation3925 Fin6 refa723_inst.
Proof. unfold Equation3925. intro H. specialize (H F6_0 F6_1). unfold magma_op, refa723_inst, refa723_op in H. discriminate H. Qed.

Lemma refa723_not3952 : ~ @Equation3952 Fin6 refa723_inst.
Proof. unfold Equation3952. intro H. specialize (H F6_0 F6_1). unfold magma_op, refa723_inst, refa723_op in H. discriminate H. Qed.

Lemma refa723_not3962 : ~ @Equation3962 Fin6 refa723_inst.
Proof. unfold Equation3962. intro H. specialize (H F6_0 F6_1). unfold magma_op, refa723_inst, refa723_op in H. discriminate H. Qed.

Lemma refa723_not4128 : ~ @Equation4128 Fin6 refa723_inst.
Proof. unfold Equation4128. intro H. specialize (H F6_0 F6_1). unfold magma_op, refa723_inst, refa723_op in H. discriminate H. Qed.

Lemma refa723_not4165 : ~ @Equation4165 Fin6 refa723_inst.
Proof. unfold Equation4165. intro H. specialize (H F6_0 F6_1). unfold magma_op, refa723_inst, refa723_op in H. discriminate H. Qed.

Lemma refa723_not4284 : ~ @Equation4284 Fin6 refa723_inst.
Proof. unfold Equation4284. intro H. specialize (H F6_0 F6_1). unfold magma_op, refa723_inst, refa723_op in H. discriminate H. Qed.

Lemma refa723_not4320 : ~ @Equation4320 Fin6 refa723_inst.
Proof. unfold Equation4320. intro H. specialize (H F6_0 F6_2). unfold magma_op, refa723_inst, refa723_op in H. discriminate H. Qed.

Lemma refa723_not4396 : ~ @Equation4396 Fin6 refa723_inst.
Proof. unfold Equation4396. intro H. specialize (H F6_0 F6_1). unfold magma_op, refa723_inst, refa723_op in H. discriminate H. Qed.

Lemma refa723_not4406 : ~ @Equation4406 Fin6 refa723_inst.
Proof. unfold Equation4406. intro H. specialize (H F6_0 F6_1). unfold magma_op, refa723_inst, refa723_op in H. discriminate H. Qed.

Lemma refa723_not4435 : ~ @Equation4435 Fin6 refa723_inst.
Proof. unfold Equation4435. intro H. specialize (H F6_0 F6_1). unfold magma_op, refa723_inst, refa723_op in H. discriminate H. Qed.

Lemma refa723_not4445 : ~ @Equation4445 Fin6 refa723_inst.
Proof. unfold Equation4445. intro H. specialize (H F6_0 F6_2). unfold magma_op, refa723_inst, refa723_op in H. discriminate H. Qed.

Lemma refa723_not4480 : ~ @Equation4480 Fin6 refa723_inst.
Proof. unfold Equation4480. intro H. specialize (H F6_0 F6_1). unfold magma_op, refa723_inst, refa723_op in H. discriminate H. Qed.

Lemma refa723_not4606 : ~ @Equation4606 Fin6 refa723_inst.
Proof. unfold Equation4606. intro H. specialize (H F6_0 F6_1). unfold magma_op, refa723_inst, refa723_op in H. discriminate H. Qed.

(** ---- refa724 (Fin5) ---- *)

Definition refa724_op (x y : Fin5) : Fin5 :=
  match x, y with
  | F5_0, F5_0 => F5_0 | F5_0, F5_1 => F5_1 | F5_0, F5_2 => F5_3 | F5_0, F5_3 => F5_4 | F5_0, F5_4 => F5_4
  | F5_1, F5_0 => F5_2 | F5_1, F5_1 => F5_1 | F5_1, F5_2 => F5_2 | F5_1, F5_3 => F5_4 | F5_1, F5_4 => F5_4
  | F5_2, F5_0 => F5_0 | F5_2, F5_1 => F5_1 | F5_2, F5_2 => F5_2 | F5_2, F5_3 => F5_4 | F5_2, F5_4 => F5_4
  | F5_3, F5_0 => F5_0 | F5_3, F5_1 => F5_1 | F5_3, F5_2 => F5_2 | F5_3, F5_3 => F5_3 | F5_3, F5_4 => F5_4
  | F5_4, F5_0 => F5_2 | F5_4, F5_1 => F5_1 | F5_4, F5_2 => F5_2 | F5_4, F5_3 => F5_3 | F5_4, F5_4 => F5_4
  end.

#[local] Instance refa724_inst : Magma Fin5 := {| magma_op := refa724_op |}.

Lemma refa724_sat2398 : @Equation2398 Fin5 refa724_inst.
Proof. unfold Equation2398, magma_op, refa724_inst, refa724_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa724_sat2753 : @Equation2753 Fin5 refa724_inst.
Proof. unfold Equation2753, magma_op, refa724_inst, refa724_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa724_not2300 : ~ @Equation2300 Fin5 refa724_inst.
Proof. unfold Equation2300. intro H. specialize (H F5_0 F5_1). unfold magma_op, refa724_inst, refa724_op in H. discriminate H. Qed.

Lemma refa724_not2347 : ~ @Equation2347 Fin5 refa724_inst.
Proof. unfold Equation2347. intro H. specialize (H F5_0 F5_0 F5_1). unfold magma_op, refa724_inst, refa724_op in H. discriminate H. Qed.

Lemma refa724_not4291 : ~ @Equation4291 Fin5 refa724_inst.
Proof. unfold Equation4291. intro H. specialize (H F5_1 F5_0). unfold magma_op, refa724_inst, refa724_op in H. discriminate H. Qed.

(** ---- refa725 (Fin5) ---- *)

Definition refa725_op (x y : Fin5) : Fin5 :=
  match x, y with
  | F5_0, F5_0 => F5_0 | F5_0, F5_1 => F5_1 | F5_0, F5_2 => F5_2 | F5_0, F5_3 => F5_4 | F5_0, F5_4 => F5_4
  | F5_1, F5_0 => F5_2 | F5_1, F5_1 => F5_1 | F5_1, F5_2 => F5_3 | F5_1, F5_3 => F5_4 | F5_1, F5_4 => F5_4
  | F5_2, F5_0 => F5_0 | F5_2, F5_1 => F5_1 | F5_2, F5_2 => F5_2 | F5_2, F5_3 => F5_3 | F5_2, F5_4 => F5_4
  | F5_3, F5_0 => F5_0 | F5_3, F5_1 => F5_1 | F5_3, F5_2 => F5_2 | F5_3, F5_3 => F5_3 | F5_3, F5_4 => F5_4
  | F5_4, F5_0 => F5_2 | F5_4, F5_1 => F5_0 | F5_4, F5_2 => F5_2 | F5_4, F5_3 => F5_3 | F5_4, F5_4 => F5_4
  end.

#[local] Instance refa725_inst : Magma Fin5 := {| magma_op := refa725_op |}.

Lemma refa725_sat2753 : @Equation2753 Fin5 refa725_inst.
Proof. unfold Equation2753, magma_op, refa725_inst, refa725_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa725_not2263 : ~ @Equation2263 Fin5 refa725_inst.
Proof. unfold Equation2263. intro H. specialize (H F5_0 F5_1). unfold magma_op, refa725_inst, refa725_op in H. discriminate H. Qed.

Lemma refa725_not2337 : ~ @Equation2337 Fin5 refa725_inst.
Proof. unfold Equation2337. intro H. specialize (H F5_0 F5_1). unfold magma_op, refa725_inst, refa725_op in H. discriminate H. Qed.

(** ---- refa726 (Fin5) ---- *)

Definition refa726_op (x y : Fin5) : Fin5 :=
  match x, y with
  | F5_0, F5_0 => F5_0 | F5_0, F5_1 => F5_2 | F5_0, F5_2 => F5_3 | F5_0, F5_3 => F5_2 | F5_0, F5_4 => F5_2
  | F5_1, F5_0 => F5_2 | F5_1, F5_1 => F5_1 | F5_1, F5_2 => F5_4 | F5_1, F5_3 => F5_2 | F5_1, F5_4 => F5_4
  | F5_2, F5_0 => F5_0 | F5_2, F5_1 => F5_1 | F5_2, F5_2 => F5_2 | F5_2, F5_3 => F5_3 | F5_2, F5_4 => F5_4
  | F5_3, F5_0 => F5_4 | F5_3, F5_1 => F5_1 | F5_3, F5_2 => F5_2 | F5_3, F5_3 => F5_3 | F5_3, F5_4 => F5_4
  | F5_4, F5_0 => F5_0 | F5_4, F5_1 => F5_3 | F5_4, F5_2 => F5_2 | F5_4, F5_3 => F5_3 | F5_4, F5_4 => F5_4
  end.

#[local] Instance refa726_inst : Magma Fin5 := {| magma_op := refa726_op |}.

Lemma refa726_sat2398 : @Equation2398 Fin5 refa726_inst.
Proof. unfold Equation2398, magma_op, refa726_inst, refa726_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa726_sat2513 : @Equation2513 Fin5 refa726_inst.
Proof. unfold Equation2513, magma_op, refa726_inst, refa726_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa726_sat2550 : @Equation2550 Fin5 refa726_inst.
Proof. unfold Equation2550, magma_op, refa726_inst, refa726_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa726_not323 : ~ @Equation323 Fin5 refa726_inst.
Proof. unfold Equation323. intro H. specialize (H F5_0 F5_1). unfold magma_op, refa726_inst, refa726_op in H. discriminate H. Qed.

Lemma refa726_not333 : ~ @Equation333 Fin5 refa726_inst.
Proof. unfold Equation333. intro H. specialize (H F5_0 F5_1). unfold magma_op, refa726_inst, refa726_op in H. discriminate H. Qed.

Lemma refa726_not385 : ~ @Equation385 Fin5 refa726_inst.
Proof. unfold Equation385. intro H. specialize (H F5_0 F5_1). unfold magma_op, refa726_inst, refa726_op in H. discriminate H. Qed.

Lemma refa726_not1025 : ~ @Equation1025 Fin5 refa726_inst.
Proof. unfold Equation1025. intro H. specialize (H F5_0 F5_1). unfold magma_op, refa726_inst, refa726_op in H. discriminate H. Qed.

Lemma refa726_not1847 : ~ @Equation1847 Fin5 refa726_inst.
Proof. unfold Equation1847. intro H. specialize (H F5_0 F5_1). unfold magma_op, refa726_inst, refa726_op in H. discriminate H. Qed.

Lemma refa726_not2243 : ~ @Equation2243 Fin5 refa726_inst.
Proof. unfold Equation2243. intro H. specialize (H F5_0 F5_3). unfold magma_op, refa726_inst, refa726_op in H. discriminate H. Qed.

Lemma refa726_not2253 : ~ @Equation2253 Fin5 refa726_inst.
Proof. unfold Equation2253. intro H. specialize (H F5_0 F5_1). unfold magma_op, refa726_inst, refa726_op in H. discriminate H. Qed.

Lemma refa726_not2466 : ~ @Equation2466 Fin5 refa726_inst.
Proof. unfold Equation2466. intro H. specialize (H F5_0 F5_1). unfold magma_op, refa726_inst, refa726_op in H. discriminate H. Qed.

Lemma refa726_not2649 : ~ @Equation2649 Fin5 refa726_inst.
Proof. unfold Equation2649. intro H. specialize (H F5_0 F5_1). unfold magma_op, refa726_inst, refa726_op in H. discriminate H. Qed.

Lemma refa726_not3867 : ~ @Equation3867 Fin5 refa726_inst.
Proof. unfold Equation3867. intro H. specialize (H F5_0 F5_1). unfold magma_op, refa726_inst, refa726_op in H. discriminate H. Qed.

(** ---- refa727 (Fin5) ---- *)

Definition refa727_op (x y : Fin5) : Fin5 :=
  match x, y with
  | F5_0, F5_0 => F5_0 | F5_0, F5_1 => F5_1 | F5_0, F5_2 => F5_3 | F5_0, F5_3 => F5_2 | F5_0, F5_4 => F5_4
  | F5_1, F5_0 => F5_2 | F5_1, F5_1 => F5_1 | F5_1, F5_2 => F5_4 | F5_1, F5_3 => F5_3 | F5_1, F5_4 => F5_2
  | F5_2, F5_0 => F5_0 | F5_2, F5_1 => F5_1 | F5_2, F5_2 => F5_2 | F5_2, F5_3 => F5_3 | F5_2, F5_4 => F5_4
  | F5_3, F5_0 => F5_4 | F5_3, F5_1 => F5_1 | F5_3, F5_2 => F5_2 | F5_3, F5_3 => F5_3 | F5_3, F5_4 => F5_4
  | F5_4, F5_0 => F5_0 | F5_4, F5_1 => F5_1 | F5_4, F5_2 => F5_2 | F5_4, F5_3 => F5_3 | F5_4, F5_4 => F5_4
  end.

#[local] Instance refa727_inst : Magma Fin5 := {| magma_op := refa727_op |}.

Lemma refa727_sat2398 : @Equation2398 Fin5 refa727_inst.
Proof. unfold Equation2398, magma_op, refa727_inst, refa727_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa727_not2446 : ~ @Equation2446 Fin5 refa727_inst.
Proof. unfold Equation2446. intro H. specialize (H F5_0 F5_1). unfold magma_op, refa727_inst, refa727_op in H. discriminate H. Qed.

(** ---- refa728 (Fin5) ---- *)

Definition refa728_op (x y : Fin5) : Fin5 :=
  match x, y with
  | F5_0, F5_0 => F5_0 | F5_0, F5_1 => F5_2 | F5_0, F5_2 => F5_2 | F5_0, F5_3 => F5_3 | F5_0, F5_4 => F5_4
  | F5_1, F5_0 => F5_3 | F5_1, F5_1 => F5_1 | F5_1, F5_2 => F5_3 | F5_1, F5_3 => F5_0 | F5_1, F5_4 => F5_0
  | F5_2, F5_0 => F5_0 | F5_2, F5_1 => F5_1 | F5_2, F5_2 => F5_2 | F5_2, F5_3 => F5_4 | F5_2, F5_4 => F5_3
  | F5_3, F5_0 => F5_0 | F5_3, F5_1 => F5_1 | F5_3, F5_2 => F5_2 | F5_3, F5_3 => F5_3 | F5_3, F5_4 => F5_4
  | F5_4, F5_0 => F5_2 | F5_4, F5_1 => F5_2 | F5_4, F5_2 => F5_2 | F5_4, F5_3 => F5_3 | F5_4, F5_4 => F5_4
  end.

#[local] Instance refa728_inst : Magma Fin5 := {| magma_op := refa728_op |}.

Lemma refa728_sat2398 : @Equation2398 Fin5 refa728_inst.
Proof. unfold Equation2398, magma_op, refa728_inst, refa728_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa728_sat2787 : @Equation2787 Fin5 refa728_inst.
Proof. unfold Equation2787, magma_op, refa728_inst, refa728_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa728_not2669 : ~ @Equation2669 Fin5 refa728_inst.
Proof. unfold Equation2669. intro H. specialize (H F5_0 F5_1). unfold magma_op, refa728_inst, refa728_op in H. discriminate H. Qed.

(** ---- refa729 (Fin6) ---- *)

Definition refa729_op (x y : Fin6) : Fin6 :=
  match x, y with
  | F6_0, F6_0 => F6_0 | F6_0, F6_1 => F6_2 | F6_0, F6_2 => F6_5 | F6_0, F6_3 => F6_4 | F6_0, F6_4 => F6_3 | F6_0, F6_5 => F6_2
  | F6_1, F6_0 => F6_1 | F6_1, F6_1 => F6_1 | F6_1, F6_2 => F6_1 | F6_1, F6_3 => F6_1 | F6_1, F6_4 => F6_1 | F6_1, F6_5 => F6_1
  | F6_2, F6_0 => F6_4 | F6_2, F6_1 => F6_3 | F6_2, F6_2 => F6_2 | F6_2, F6_3 => F6_5 | F6_2, F6_4 => F6_0 | F6_2, F6_5 => F6_3
  | F6_3, F6_0 => F6_2 | F6_3, F6_1 => F6_4 | F6_3, F6_2 => F6_0 | F6_3, F6_3 => F6_3 | F6_3, F6_4 => F6_5 | F6_3, F6_5 => F6_4
  | F6_4, F6_0 => F6_5 | F6_4, F6_1 => F6_0 | F6_4, F6_2 => F6_3 | F6_4, F6_3 => F6_2 | F6_4, F6_4 => F6_4 | F6_4, F6_5 => F6_0
  | F6_5, F6_0 => F6_3 | F6_5, F6_1 => F6_5 | F6_5, F6_2 => F6_4 | F6_5, F6_3 => F6_0 | F6_5, F6_4 => F6_2 | F6_5, F6_5 => F6_5
  end.

#[local] Instance refa729_inst : Magma Fin6 := {| magma_op := refa729_op |}.

Lemma refa729_sat261 : @Equation261 Fin6 refa729_inst.
Proof. unfold Equation261, magma_op, refa729_inst, refa729_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa729_sat2054 : @Equation2054 Fin6 refa729_inst.
Proof. unfold Equation2054, magma_op, refa729_inst, refa729_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa729_sat2061 : @Equation2061 Fin6 refa729_inst.
Proof. unfold Equation2061, magma_op, refa729_inst, refa729_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa729_sat2450 : @Equation2450 Fin6 refa729_inst.
Proof. unfold Equation2450, magma_op, refa729_inst, refa729_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa729_sat2873 : @Equation2873 Fin6 refa729_inst.
Proof. unfold Equation2873, magma_op, refa729_inst, refa729_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa729_not156 : ~ @Equation156 Fin6 refa729_inst.
Proof. unfold Equation156. intro H. specialize (H F6_0 F6_1). unfold magma_op, refa729_inst, refa729_op in H. discriminate H. Qed.

Lemma refa729_not159 : ~ @Equation159 Fin6 refa729_inst.
Proof. unfold Equation159. intro H. specialize (H F6_0 F6_1). unfold magma_op, refa729_inst, refa729_op in H. discriminate H. Qed.

Lemma refa729_not160 : ~ @Equation160 Fin6 refa729_inst.
Proof. unfold Equation160. intro H. specialize (H F6_0 F6_1). unfold magma_op, refa729_inst, refa729_op in H. discriminate H. Qed.

Lemma refa729_not205 : ~ @Equation205 Fin6 refa729_inst.
Proof. unfold Equation205. intro H. specialize (H F6_0 F6_1). unfold magma_op, refa729_inst, refa729_op in H. discriminate H. Qed.

Lemma refa729_not206 : ~ @Equation206 Fin6 refa729_inst.
Proof. unfold Equation206. intro H. specialize (H F6_0 F6_1). unfold magma_op, refa729_inst, refa729_op in H. discriminate H. Qed.

Lemma refa729_not208 : ~ @Equation208 Fin6 refa729_inst.
Proof. unfold Equation208. intro H. specialize (H F6_0 F6_1). unfold magma_op, refa729_inst, refa729_op in H. discriminate H. Qed.

Lemma refa729_not209 : ~ @Equation209 Fin6 refa729_inst.
Proof. unfold Equation209. intro H. specialize (H F6_0 F6_1). unfold magma_op, refa729_inst, refa729_op in H. discriminate H. Qed.

Lemma refa729_not211 : ~ @Equation211 Fin6 refa729_inst.
Proof. unfold Equation211. intro H. specialize (H F6_0 F6_1). unfold magma_op, refa729_inst, refa729_op in H. discriminate H. Qed.

Lemma refa729_not263 : ~ @Equation263 Fin6 refa729_inst.
Proof. unfold Equation263. intro H. specialize (H F6_0 F6_1). unfold magma_op, refa729_inst, refa729_op in H. discriminate H. Qed.

Lemma refa729_not323 : ~ @Equation323 Fin6 refa729_inst.
Proof. unfold Equation323. intro H. specialize (H F6_0 F6_1). unfold magma_op, refa729_inst, refa729_op in H. discriminate H. Qed.

Lemma refa729_not1427 : ~ @Equation1427 Fin6 refa729_inst.
Proof. unfold Equation1427. intro H. specialize (H F6_0 F6_1). unfold magma_op, refa729_inst, refa729_op in H. discriminate H. Qed.

Lemma refa729_not1428 : ~ @Equation1428 Fin6 refa729_inst.
Proof. unfold Equation1428. intro H. specialize (H F6_0 F6_1). unfold magma_op, refa729_inst, refa729_op in H. discriminate H. Qed.

Lemma refa729_not1429 : ~ @Equation1429 Fin6 refa729_inst.
Proof. unfold Equation1429. intro H. specialize (H F6_0 F6_1). unfold magma_op, refa729_inst, refa729_op in H. discriminate H. Qed.

Lemma refa729_not1431 : ~ @Equation1431 Fin6 refa729_inst.
Proof. unfold Equation1431. intro H. specialize (H F6_0 F6_1). unfold magma_op, refa729_inst, refa729_op in H. discriminate H. Qed.

Lemma refa729_not1432 : ~ @Equation1432 Fin6 refa729_inst.
Proof. unfold Equation1432. intro H. specialize (H F6_0 F6_1). unfold magma_op, refa729_inst, refa729_op in H. discriminate H. Qed.

Lemma refa729_not1434 : ~ @Equation1434 Fin6 refa729_inst.
Proof. unfold Equation1434. intro H. specialize (H F6_0 F6_1). unfold magma_op, refa729_inst, refa729_op in H. discriminate H. Qed.

Lemma refa729_not1435 : ~ @Equation1435 Fin6 refa729_inst.
Proof. unfold Equation1435. intro H. specialize (H F6_0 F6_1). unfold magma_op, refa729_inst, refa729_op in H. discriminate H. Qed.

Lemma refa729_not1441 : ~ @Equation1441 Fin6 refa729_inst.
Proof. unfold Equation1441. intro H. specialize (H F6_0 F6_1). unfold magma_op, refa729_inst, refa729_op in H. discriminate H. Qed.

Lemma refa729_not1444 : ~ @Equation1444 Fin6 refa729_inst.
Proof. unfold Equation1444. intro H. specialize (H F6_0 F6_1). unfold magma_op, refa729_inst, refa729_op in H. discriminate H. Qed.

Lemma refa729_not1445 : ~ @Equation1445 Fin6 refa729_inst.
Proof. unfold Equation1445. intro H. specialize (H F6_0 F6_1). unfold magma_op, refa729_inst, refa729_op in H. discriminate H. Qed.

Lemma refa729_not1451 : ~ @Equation1451 Fin6 refa729_inst.
Proof. unfold Equation1451. intro H. specialize (H F6_0 F6_1). unfold magma_op, refa729_inst, refa729_op in H. discriminate H. Qed.

Lemma refa729_not1454 : ~ @Equation1454 Fin6 refa729_inst.
Proof. unfold Equation1454. intro H. specialize (H F6_0 F6_1). unfold magma_op, refa729_inst, refa729_op in H. discriminate H. Qed.

Lemma refa729_not1455 : ~ @Equation1455 Fin6 refa729_inst.
Proof. unfold Equation1455. intro H. specialize (H F6_0 F6_1). unfold magma_op, refa729_inst, refa729_op in H. discriminate H. Qed.

Lemma refa729_not1630 : ~ @Equation1630 Fin6 refa729_inst.
Proof. unfold Equation1630. intro H. specialize (H F6_0 F6_1). unfold magma_op, refa729_inst, refa729_op in H. discriminate H. Qed.

Lemma refa729_not1631 : ~ @Equation1631 Fin6 refa729_inst.
Proof. unfold Equation1631. intro H. specialize (H F6_0 F6_1). unfold magma_op, refa729_inst, refa729_op in H. discriminate H. Qed.

Lemma refa729_not1632 : ~ @Equation1632 Fin6 refa729_inst.
Proof. unfold Equation1632. intro H. specialize (H F6_0 F6_1). unfold magma_op, refa729_inst, refa729_op in H. discriminate H. Qed.

Lemma refa729_not1634 : ~ @Equation1634 Fin6 refa729_inst.
Proof. unfold Equation1634. intro H. specialize (H F6_0 F6_1). unfold magma_op, refa729_inst, refa729_op in H. discriminate H. Qed.

Lemma refa729_not1635 : ~ @Equation1635 Fin6 refa729_inst.
Proof. unfold Equation1635. intro H. specialize (H F6_0 F6_1). unfold magma_op, refa729_inst, refa729_op in H. discriminate H. Qed.

Lemma refa729_not1637 : ~ @Equation1637 Fin6 refa729_inst.
Proof. unfold Equation1637. intro H. specialize (H F6_0 F6_1). unfold magma_op, refa729_inst, refa729_op in H. discriminate H. Qed.

Lemma refa729_not1638 : ~ @Equation1638 Fin6 refa729_inst.
Proof. unfold Equation1638. intro H. specialize (H F6_0 F6_1). unfold magma_op, refa729_inst, refa729_op in H. discriminate H. Qed.

Lemma refa729_not1644 : ~ @Equation1644 Fin6 refa729_inst.
Proof. unfold Equation1644. intro H. specialize (H F6_0 F6_1). unfold magma_op, refa729_inst, refa729_op in H. discriminate H. Qed.

Lemma refa729_not1645 : ~ @Equation1645 Fin6 refa729_inst.
Proof. unfold Equation1645. intro H. specialize (H F6_0 F6_1). unfold magma_op, refa729_inst, refa729_op in H. discriminate H. Qed.

Lemma refa729_not1848 : ~ @Equation1848 Fin6 refa729_inst.
Proof. unfold Equation1848. intro H. specialize (H F6_0 F6_1). unfold magma_op, refa729_inst, refa729_op in H. discriminate H. Qed.

Lemma refa729_not2036 : ~ @Equation2036 Fin6 refa729_inst.
Proof. unfold Equation2036. intro H. specialize (H F6_0 F6_1). unfold magma_op, refa729_inst, refa729_op in H. discriminate H. Qed.

Lemma refa729_not2043 : ~ @Equation2043 Fin6 refa729_inst.
Proof. unfold Equation2043. intro H. specialize (H F6_0 F6_1). unfold magma_op, refa729_inst, refa729_op in H. discriminate H. Qed.

Lemma refa729_not2044 : ~ @Equation2044 Fin6 refa729_inst.
Proof. unfold Equation2044. intro H. specialize (H F6_0 F6_1). unfold magma_op, refa729_inst, refa729_op in H. discriminate H. Qed.

Lemma refa729_not2053 : ~ @Equation2053 Fin6 refa729_inst.
Proof. unfold Equation2053. intro H. specialize (H F6_0 F6_2). unfold magma_op, refa729_inst, refa729_op in H. discriminate H. Qed.

Lemma refa729_not2060 : ~ @Equation2060 Fin6 refa729_inst.
Proof. unfold Equation2060. intro H. specialize (H F6_0 F6_1). unfold magma_op, refa729_inst, refa729_op in H. discriminate H. Qed.

Lemma refa729_not2256 : ~ @Equation2256 Fin6 refa729_inst.
Proof. unfold Equation2256. intro H. specialize (H F6_0 F6_1). unfold magma_op, refa729_inst, refa729_op in H. discriminate H. Qed.

Lemma refa729_not2457 : ~ @Equation2457 Fin6 refa729_inst.
Proof. unfold Equation2457. intro H. specialize (H F6_0 F6_1). unfold magma_op, refa729_inst, refa729_op in H. discriminate H. Qed.

Lemma refa729_not2459 : ~ @Equation2459 Fin6 refa729_inst.
Proof. unfold Equation2459. intro H. specialize (H F6_0 F6_1). unfold magma_op, refa729_inst, refa729_op in H. discriminate H. Qed.

Lemma refa729_not2646 : ~ @Equation2646 Fin6 refa729_inst.
Proof. unfold Equation2646. intro H. specialize (H F6_0 F6_1). unfold magma_op, refa729_inst, refa729_op in H. discriminate H. Qed.

Lemma refa729_not2650 : ~ @Equation2650 Fin6 refa729_inst.
Proof. unfold Equation2650. intro H. specialize (H F6_0 F6_1). unfold magma_op, refa729_inst, refa729_op in H. discriminate H. Qed.

Lemma refa729_not2669 : ~ @Equation2669 Fin6 refa729_inst.
Proof. unfold Equation2669. intro H. specialize (H F6_0 F6_1). unfold magma_op, refa729_inst, refa729_op in H. discriminate H. Qed.

Lemma refa729_not2672 : ~ @Equation2672 Fin6 refa729_inst.
Proof. unfold Equation2672. intro H. specialize (H F6_0 F6_1). unfold magma_op, refa729_inst, refa729_op in H. discriminate H. Qed.

Lemma refa729_not2852 : ~ @Equation2852 Fin6 refa729_inst.
Proof. unfold Equation2852. intro H. specialize (H F6_0 F6_1). unfold magma_op, refa729_inst, refa729_op in H. discriminate H. Qed.

Lemma refa729_not2856 : ~ @Equation2856 Fin6 refa729_inst.
Proof. unfold Equation2856. intro H. specialize (H F6_0 F6_1). unfold magma_op, refa729_inst, refa729_op in H. discriminate H. Qed.

Lemma refa729_not2863 : ~ @Equation2863 Fin6 refa729_inst.
Proof. unfold Equation2863. intro H. specialize (H F6_0 F6_2). unfold magma_op, refa729_inst, refa729_op in H. discriminate H. Qed.

Lemma refa729_not2865 : ~ @Equation2865 Fin6 refa729_inst.
Proof. unfold Equation2865. intro H. specialize (H F6_0 F6_1). unfold magma_op, refa729_inst, refa729_op in H. discriminate H. Qed.

Lemma refa729_not2875 : ~ @Equation2875 Fin6 refa729_inst.
Proof. unfold Equation2875. intro H. specialize (H F6_0 F6_1). unfold magma_op, refa729_inst, refa729_op in H. discriminate H. Qed.

Lemma refa729_not3066 : ~ @Equation3066 Fin6 refa729_inst.
Proof. unfold Equation3066. intro H. specialize (H F6_0 F6_1). unfold magma_op, refa729_inst, refa729_op in H. discriminate H. Qed.

Lemma refa729_not3254 : ~ @Equation3254 Fin6 refa729_inst.
Proof. unfold Equation3254. intro H. specialize (H F6_0 F6_1). unfold magma_op, refa729_inst, refa729_op in H. discriminate H. Qed.

Lemma refa729_not3255 : ~ @Equation3255 Fin6 refa729_inst.
Proof. unfold Equation3255. intro H. specialize (H F6_0 F6_1). unfold magma_op, refa729_inst, refa729_op in H. discriminate H. Qed.

Lemma refa729_not3256 : ~ @Equation3256 Fin6 refa729_inst.
Proof. unfold Equation3256. intro H. specialize (H F6_0 F6_1). unfold magma_op, refa729_inst, refa729_op in H. discriminate H. Qed.

Lemma refa729_not3259 : ~ @Equation3259 Fin6 refa729_inst.
Proof. unfold Equation3259. intro H. specialize (H F6_0 F6_1). unfold magma_op, refa729_inst, refa729_op in H. discriminate H. Qed.

Lemma refa729_not3308 : ~ @Equation3308 Fin6 refa729_inst.
Proof. unfold Equation3308. intro H. specialize (H F6_0 F6_1). unfold magma_op, refa729_inst, refa729_op in H. discriminate H. Qed.

Lemma refa729_not3315 : ~ @Equation3315 Fin6 refa729_inst.
Proof. unfold Equation3315. intro H. specialize (H F6_0 F6_2). unfold magma_op, refa729_inst, refa729_op in H. discriminate H. Qed.

Lemma refa729_not3316 : ~ @Equation3316 Fin6 refa729_inst.
Proof. unfold Equation3316. intro H. specialize (H F6_0 F6_2). unfold magma_op, refa729_inst, refa729_op in H. discriminate H. Qed.

Lemma refa729_not3318 : ~ @Equation3318 Fin6 refa729_inst.
Proof. unfold Equation3318. intro H. specialize (H F6_0 F6_2). unfold magma_op, refa729_inst, refa729_op in H. discriminate H. Qed.

Lemma refa729_not3457 : ~ @Equation3457 Fin6 refa729_inst.
Proof. unfold Equation3457. intro H. specialize (H F6_0 F6_1). unfold magma_op, refa729_inst, refa729_op in H. discriminate H. Qed.

Lemma refa729_not3458 : ~ @Equation3458 Fin6 refa729_inst.
Proof. unfold Equation3458. intro H. specialize (H F6_0 F6_1). unfold magma_op, refa729_inst, refa729_op in H. discriminate H. Qed.

Lemma refa729_not3459 : ~ @Equation3459 Fin6 refa729_inst.
Proof. unfold Equation3459. intro H. specialize (H F6_0 F6_1). unfold magma_op, refa729_inst, refa729_op in H. discriminate H. Qed.

Lemma refa729_not3462 : ~ @Equation3462 Fin6 refa729_inst.
Proof. unfold Equation3462. intro H. specialize (H F6_0 F6_1). unfold magma_op, refa729_inst, refa729_op in H. discriminate H. Qed.

Lemma refa729_not3511 : ~ @Equation3511 Fin6 refa729_inst.
Proof. unfold Equation3511. intro H. specialize (H F6_0 F6_1). unfold magma_op, refa729_inst, refa729_op in H. discriminate H. Qed.

Lemma refa729_not3518 : ~ @Equation3518 Fin6 refa729_inst.
Proof. unfold Equation3518. intro H. specialize (H F6_0 F6_2). unfold magma_op, refa729_inst, refa729_op in H. discriminate H. Qed.

Lemma refa729_not3519 : ~ @Equation3519 Fin6 refa729_inst.
Proof. unfold Equation3519. intro H. specialize (H F6_0 F6_2). unfold magma_op, refa729_inst, refa729_op in H. discriminate H. Qed.

Lemma refa729_not3521 : ~ @Equation3521 Fin6 refa729_inst.
Proof. unfold Equation3521. intro H. specialize (H F6_0 F6_2). unfold magma_op, refa729_inst, refa729_op in H. discriminate H. Qed.

Lemma refa729_not4268 : ~ @Equation4268 Fin6 refa729_inst.
Proof. unfold Equation4268. intro H. specialize (H F6_0 F6_1). unfold magma_op, refa729_inst, refa729_op in H. discriminate H. Qed.

Lemma refa729_not4314 : ~ @Equation4314 Fin6 refa729_inst.
Proof. unfold Equation4314. intro H. specialize (H F6_0 F6_2). unfold magma_op, refa729_inst, refa729_op in H. discriminate H. Qed.

Lemma refa729_not4598 : ~ @Equation4598 Fin6 refa729_inst.
Proof. unfold Equation4598. intro H. specialize (H F6_0 F6_1). unfold magma_op, refa729_inst, refa729_op in H. discriminate H. Qed.

Lemma refa729_not4656 : ~ @Equation4656 Fin6 refa729_inst.
Proof. unfold Equation4656. intro H. specialize (H F6_0 F6_0 F6_1). unfold magma_op, refa729_inst, refa729_op in H. discriminate H. Qed.
