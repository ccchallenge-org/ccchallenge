(** * All4x4 counterexamples — batch 5
    Auto-generated from Lean4 All4x4 files. *)

From Stdlib Require Import Utf8.

From ETP Require Import Magma.
From ETP Require Import FinMagma.
From ETP.Equations Require Import All.

Open Scope magma_scope.

(** ---- refa279 (Fin3) ---- *)

Definition refa279_op (x y : Fin3) : Fin3 :=
  match x, y with
  | F3_0, F3_0 => F3_1 | F3_0, F3_1 => F3_0 | F3_0, F3_2 => F3_1
  | F3_1, F3_0 => F3_1 | F3_1, F3_1 => F3_2 | F3_1, F3_2 => F3_0
  | F3_2, F3_0 => F3_0 | F3_2, F3_1 => F3_2 | F3_2, F3_2 => F3_0
  end.

#[local] Instance refa279_inst : Magma Fin3 := {| magma_op := refa279_op |}.

Lemma refa279_sat1048 : @Equation1048 Fin3 refa279_inst.
Proof. unfold Equation1048, magma_op, refa279_inst, refa279_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa279_not99 : ~ @Equation99 Fin3 refa279_inst.
Proof. unfold Equation99. intro H. specialize (H F3_1). unfold magma_op, refa279_inst, refa279_op in H. discriminate H. Qed.

Lemma refa279_not817 : ~ @Equation817 Fin3 refa279_inst.
Proof. unfold Equation817. intro H. specialize (H F3_0). unfold magma_op, refa279_inst, refa279_op in H. discriminate H. Qed.

Lemma refa279_not1035 : ~ @Equation1035 Fin3 refa279_inst.
Proof. unfold Equation1035. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa279_inst, refa279_op in H. discriminate H. Qed.

Lemma refa279_not1038 : ~ @Equation1038 Fin3 refa279_inst.
Proof. unfold Equation1038. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa279_inst, refa279_op in H. discriminate H. Qed.

Lemma refa279_not1045 : ~ @Equation1045 Fin3 refa279_inst.
Proof. unfold Equation1045. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa279_inst, refa279_op in H. discriminate H. Qed.

Lemma refa279_not1049 : ~ @Equation1049 Fin3 refa279_inst.
Proof. unfold Equation1049. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa279_inst, refa279_op in H. discriminate H. Qed.

Lemma refa279_not1223 : ~ @Equation1223 Fin3 refa279_inst.
Proof. unfold Equation1223. intro H. specialize (H F3_1). unfold magma_op, refa279_inst, refa279_op in H. discriminate H. Qed.

Lemma refa279_not4591 : ~ @Equation4591 Fin3 refa279_inst.
Proof. unfold Equation4591. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa279_inst, refa279_op in H. discriminate H. Qed.

Lemma refa279_not4598 : ~ @Equation4598 Fin3 refa279_inst.
Proof. unfold Equation4598. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa279_inst, refa279_op in H. discriminate H. Qed.

(** ---- refa28 (Fin9) ---- *)

Definition refa28_op (x y : Fin9) : Fin9 :=
  match x, y with
  | F9_0, F9_0 => F9_0 | F9_0, F9_1 => F9_2 | F9_0, F9_2 => F9_4 | F9_0, F9_3 => F9_8 | F9_0, F9_4 => F9_3 | F9_0, F9_5 => F9_7 | F9_0, F9_6 => F9_1 | F9_0, F9_7 => F9_5 | F9_0, F9_8 => F9_6
  | F9_1, F9_0 => F9_3 | F9_1, F9_1 => F9_1 | F9_1, F9_2 => F9_5 | F9_1, F9_3 => F9_7 | F9_1, F9_4 => F9_8 | F9_1, F9_5 => F9_6 | F9_1, F9_6 => F9_0 | F9_1, F9_7 => F9_2 | F9_1, F9_8 => F9_4
  | F9_2, F9_0 => F9_8 | F9_2, F9_1 => F9_0 | F9_2, F9_2 => F9_2 | F9_2, F9_3 => F9_6 | F9_2, F9_4 => F9_7 | F9_2, F9_5 => F9_4 | F9_2, F9_6 => F9_3 | F9_2, F9_7 => F9_1 | F9_2, F9_8 => F9_5
  | F9_3, F9_0 => F9_1 | F9_3, F9_1 => F9_5 | F9_3, F9_2 => F9_6 | F9_3, F9_3 => F9_3 | F9_3, F9_4 => F9_0 | F9_3, F9_5 => F9_8 | F9_3, F9_6 => F9_2 | F9_3, F9_7 => F9_4 | F9_3, F9_8 => F9_7
  | F9_4, F9_0 => F9_6 | F9_4, F9_1 => F9_8 | F9_4, F9_2 => F9_0 | F9_4, F9_3 => F9_5 | F9_4, F9_4 => F9_4 | F9_4, F9_5 => F9_2 | F9_4, F9_6 => F9_7 | F9_4, F9_7 => F9_3 | F9_4, F9_8 => F9_1
  | F9_5, F9_0 => F9_7 | F9_5, F9_1 => F9_3 | F9_5, F9_2 => F9_1 | F9_5, F9_3 => F9_4 | F9_5, F9_4 => F9_6 | F9_5, F9_5 => F9_5 | F9_5, F9_6 => F9_8 | F9_5, F9_7 => F9_0 | F9_5, F9_8 => F9_2
  | F9_6, F9_0 => F9_4 | F9_6, F9_1 => F9_7 | F9_6, F9_2 => F9_3 | F9_6, F9_3 => F9_2 | F9_6, F9_4 => F9_5 | F9_6, F9_5 => F9_1 | F9_6, F9_6 => F9_6 | F9_6, F9_7 => F9_8 | F9_6, F9_8 => F9_0
  | F9_7, F9_0 => F9_5 | F9_7, F9_1 => F9_6 | F9_7, F9_2 => F9_8 | F9_7, F9_3 => F9_1 | F9_7, F9_4 => F9_2 | F9_7, F9_5 => F9_0 | F9_7, F9_6 => F9_4 | F9_7, F9_7 => F9_7 | F9_7, F9_8 => F9_3
  | F9_8, F9_0 => F9_2 | F9_8, F9_1 => F9_4 | F9_8, F9_2 => F9_7 | F9_8, F9_3 => F9_0 | F9_8, F9_4 => F9_1 | F9_8, F9_5 => F9_3 | F9_8, F9_6 => F9_5 | F9_8, F9_7 => F9_6 | F9_8, F9_8 => F9_8
  end.

#[local] Instance refa28_inst : Magma Fin9 := {| magma_op := refa28_op |}.

Lemma refa28_sat907 : @Equation907 Fin9 refa28_inst.
Proof. unfold Equation907, magma_op, refa28_inst, refa28_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa28_sat1120 : @Equation1120 Fin9 refa28_inst.
Proof. unfold Equation1120, magma_op, refa28_inst, refa28_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa28_not429 : ~ @Equation429 Fin9 refa28_inst.
Proof. unfold Equation429. intro H. specialize (H F9_0 F9_1). unfold magma_op, refa28_inst, refa28_op in H. discriminate H. Qed.

Lemma refa28_not440 : ~ @Equation440 Fin9 refa28_inst.
Proof. unfold Equation440. intro H. specialize (H F9_0 F9_1). unfold magma_op, refa28_inst, refa28_op in H. discriminate H. Qed.

Lemma refa28_not464 : ~ @Equation464 Fin9 refa28_inst.
Proof. unfold Equation464. intro H. specialize (H F9_0 F9_1). unfold magma_op, refa28_inst, refa28_op in H. discriminate H. Qed.

Lemma refa28_not473 : ~ @Equation473 Fin9 refa28_inst.
Proof. unfold Equation473. intro H. specialize (H F9_0 F9_1). unfold magma_op, refa28_inst, refa28_op in H. discriminate H. Qed.

Lemma refa28_not477 : ~ @Equation477 Fin9 refa28_inst.
Proof. unfold Equation477. intro H. specialize (H F9_0 F9_1). unfold magma_op, refa28_inst, refa28_op in H. discriminate H. Qed.

Lemma refa28_not504 : ~ @Equation504 Fin9 refa28_inst.
Proof. unfold Equation504. intro H. specialize (H F9_0 F9_1). unfold magma_op, refa28_inst, refa28_op in H. discriminate H. Qed.

Lemma refa28_not513 : ~ @Equation513 Fin9 refa28_inst.
Proof. unfold Equation513. intro H. specialize (H F9_0 F9_1). unfold magma_op, refa28_inst, refa28_op in H. discriminate H. Qed.

Lemma refa28_not632 : ~ @Equation632 Fin9 refa28_inst.
Proof. unfold Equation632. intro H. specialize (H F9_0 F9_1). unfold magma_op, refa28_inst, refa28_op in H. discriminate H. Qed.

Lemma refa28_not643 : ~ @Equation643 Fin9 refa28_inst.
Proof. unfold Equation643. intro H. specialize (H F9_0 F9_1). unfold magma_op, refa28_inst, refa28_op in H. discriminate H. Qed.

Lemma refa28_not667 : ~ @Equation667 Fin9 refa28_inst.
Proof. unfold Equation667. intro H. specialize (H F9_0 F9_1). unfold magma_op, refa28_inst, refa28_op in H. discriminate H. Qed.

Lemma refa28_not676 : ~ @Equation676 Fin9 refa28_inst.
Proof. unfold Equation676. intro H. specialize (H F9_0 F9_1). unfold magma_op, refa28_inst, refa28_op in H. discriminate H. Qed.

Lemma refa28_not680 : ~ @Equation680 Fin9 refa28_inst.
Proof. unfold Equation680. intro H. specialize (H F9_0 F9_1). unfold magma_op, refa28_inst, refa28_op in H. discriminate H. Qed.

Lemma refa28_not707 : ~ @Equation707 Fin9 refa28_inst.
Proof. unfold Equation707. intro H. specialize (H F9_0 F9_1). unfold magma_op, refa28_inst, refa28_op in H. discriminate H. Qed.

Lemma refa28_not716 : ~ @Equation716 Fin9 refa28_inst.
Proof. unfold Equation716. intro H. specialize (H F9_0 F9_1). unfold magma_op, refa28_inst, refa28_op in H. discriminate H. Qed.

Lemma refa28_not836 : ~ @Equation836 Fin9 refa28_inst.
Proof. unfold Equation836. intro H. specialize (H F9_0 F9_1). unfold magma_op, refa28_inst, refa28_op in H. discriminate H. Qed.

Lemma refa28_not843 : ~ @Equation843 Fin9 refa28_inst.
Proof. unfold Equation843. intro H. specialize (H F9_0 F9_1). unfold magma_op, refa28_inst, refa28_op in H. discriminate H. Qed.

Lemma refa28_not1082 : ~ @Equation1082 Fin9 refa28_inst.
Proof. unfold Equation1082. intro H. specialize (H F9_0 F9_1). unfold magma_op, refa28_inst, refa28_op in H. discriminate H. Qed.

Lemma refa28_not1113 : ~ @Equation1113 Fin9 refa28_inst.
Proof. unfold Equation1113. intro H. specialize (H F9_0 F9_1). unfold magma_op, refa28_inst, refa28_op in H. discriminate H. Qed.

Lemma refa28_not1122 : ~ @Equation1122 Fin9 refa28_inst.
Proof. unfold Equation1122. intro H. specialize (H F9_0 F9_1). unfold magma_op, refa28_inst, refa28_op in H. discriminate H. Qed.

Lemma refa28_not1285 : ~ @Equation1285 Fin9 refa28_inst.
Proof. unfold Equation1285. intro H. specialize (H F9_0 F9_1). unfold magma_op, refa28_inst, refa28_op in H. discriminate H. Qed.

Lemma refa28_not1289 : ~ @Equation1289 Fin9 refa28_inst.
Proof. unfold Equation1289. intro H. specialize (H F9_0 F9_1). unfold magma_op, refa28_inst, refa28_op in H. discriminate H. Qed.

Lemma refa28_not1312 : ~ @Equation1312 Fin9 refa28_inst.
Proof. unfold Equation1312. intro H. specialize (H F9_0 F9_1). unfold magma_op, refa28_inst, refa28_op in H. discriminate H. Qed.

Lemma refa28_not1434 : ~ @Equation1434 Fin9 refa28_inst.
Proof. unfold Equation1434. intro H. specialize (H F9_0 F9_1). unfold magma_op, refa28_inst, refa28_op in H. discriminate H. Qed.

Lemma refa28_not1444 : ~ @Equation1444 Fin9 refa28_inst.
Proof. unfold Equation1444. intro H. specialize (H F9_0 F9_1). unfold magma_op, refa28_inst, refa28_op in H. discriminate H. Qed.

Lemma refa28_not1482 : ~ @Equation1482 Fin9 refa28_inst.
Proof. unfold Equation1482. intro H. specialize (H F9_0 F9_1). unfold magma_op, refa28_inst, refa28_op in H. discriminate H. Qed.

Lemma refa28_not1489 : ~ @Equation1489 Fin9 refa28_inst.
Proof. unfold Equation1489. intro H. specialize (H F9_0 F9_1). unfold magma_op, refa28_inst, refa28_op in H. discriminate H. Qed.

Lemma refa28_not1516 : ~ @Equation1516 Fin9 refa28_inst.
Proof. unfold Equation1516. intro H. specialize (H F9_0 F9_1). unfold magma_op, refa28_inst, refa28_op in H. discriminate H. Qed.

Lemma refa28_not1519 : ~ @Equation1519 Fin9 refa28_inst.
Proof. unfold Equation1519. intro H. specialize (H F9_0 F9_1). unfold magma_op, refa28_inst, refa28_op in H. discriminate H. Qed.

Lemma refa28_not1731 : ~ @Equation1731 Fin9 refa28_inst.
Proof. unfold Equation1731. intro H. specialize (H F9_0 F9_1). unfold magma_op, refa28_inst, refa28_op in H. discriminate H. Qed.

Lemma refa28_not2088 : ~ @Equation2088 Fin9 refa28_inst.
Proof. unfold Equation2088. intro H. specialize (H F9_0 F9_1). unfold magma_op, refa28_inst, refa28_op in H. discriminate H. Qed.

Lemma refa28_not2128 : ~ @Equation2128 Fin9 refa28_inst.
Proof. unfold Equation2128. intro H. specialize (H F9_0 F9_1). unfold magma_op, refa28_inst, refa28_op in H. discriminate H. Qed.

Lemma refa28_not2137 : ~ @Equation2137 Fin9 refa28_inst.
Proof. unfold Equation2137. intro H. specialize (H F9_0 F9_1). unfold magma_op, refa28_inst, refa28_op in H. discriminate H. Qed.

Lemma refa28_not2241 : ~ @Equation2241 Fin9 refa28_inst.
Proof. unfold Equation2241. intro H. specialize (H F9_0 F9_1). unfold magma_op, refa28_inst, refa28_op in H. discriminate H. Qed.

Lemma refa28_not2244 : ~ @Equation2244 Fin9 refa28_inst.
Proof. unfold Equation2244. intro H. specialize (H F9_0 F9_1). unfold magma_op, refa28_inst, refa28_op in H. discriminate H. Qed.

Lemma refa28_not2263 : ~ @Equation2263 Fin9 refa28_inst.
Proof. unfold Equation2263. intro H. specialize (H F9_0 F9_1). unfold magma_op, refa28_inst, refa28_op in H. discriminate H. Qed.

Lemma refa28_not2327 : ~ @Equation2327 Fin9 refa28_inst.
Proof. unfold Equation2327. intro H. specialize (H F9_0 F9_1). unfold magma_op, refa28_inst, refa28_op in H. discriminate H. Qed.

Lemma refa28_not2534 : ~ @Equation2534 Fin9 refa28_inst.
Proof. unfold Equation2534. intro H. specialize (H F9_0 F9_1). unfold magma_op, refa28_inst, refa28_op in H. discriminate H. Qed.

Lemma refa28_not2853 : ~ @Equation2853 Fin9 refa28_inst.
Proof. unfold Equation2853. intro H. specialize (H F9_0 F9_1). unfold magma_op, refa28_inst, refa28_op in H. discriminate H. Qed.

Lemma refa28_not2936 : ~ @Equation2936 Fin9 refa28_inst.
Proof. unfold Equation2936. intro H. specialize (H F9_0 F9_1). unfold magma_op, refa28_inst, refa28_op in H. discriminate H. Qed.

Lemma refa28_not2940 : ~ @Equation2940 Fin9 refa28_inst.
Proof. unfold Equation2940. intro H. specialize (H F9_0 F9_1). unfold magma_op, refa28_inst, refa28_op in H. discriminate H. Qed.

Lemma refa28_not2947 : ~ @Equation2947 Fin9 refa28_inst.
Proof. unfold Equation2947. intro H. specialize (H F9_0 F9_1). unfold magma_op, refa28_inst, refa28_op in H. discriminate H. Qed.

Lemma refa28_not3103 : ~ @Equation3103 Fin9 refa28_inst.
Proof. unfold Equation3103. intro H. specialize (H F9_0 F9_1). unfold magma_op, refa28_inst, refa28_op in H. discriminate H. Qed.

Lemma refa28_not3116 : ~ @Equation3116 Fin9 refa28_inst.
Proof. unfold Equation3116. intro H. specialize (H F9_0 F9_1). unfold magma_op, refa28_inst, refa28_op in H. discriminate H. Qed.

Lemma refa28_not3150 : ~ @Equation3150 Fin9 refa28_inst.
Proof. unfold Equation3150. intro H. specialize (H F9_0 F9_1). unfold magma_op, refa28_inst, refa28_op in H. discriminate H. Qed.

Lemma refa28_not3342 : ~ @Equation3342 Fin9 refa28_inst.
Proof. unfold Equation3342. intro H. specialize (H F9_0 F9_1). unfold magma_op, refa28_inst, refa28_op in H. discriminate H. Qed.

Lemma refa28_not3545 : ~ @Equation3545 Fin9 refa28_inst.
Proof. unfold Equation3545. intro H. specialize (H F9_0 F9_1). unfold magma_op, refa28_inst, refa28_op in H. discriminate H. Qed.

Lemma refa28_not3556 : ~ @Equation3556 Fin9 refa28_inst.
Proof. unfold Equation3556. intro H. specialize (H F9_0 F9_1). unfold magma_op, refa28_inst, refa28_op in H. discriminate H. Qed.

Lemma refa28_not3964 : ~ @Equation3964 Fin9 refa28_inst.
Proof. unfold Equation3964. intro H. specialize (H F9_0 F9_1). unfold magma_op, refa28_inst, refa28_op in H. discriminate H. Qed.

Lemma refa28_not4154 : ~ @Equation4154 Fin9 refa28_inst.
Proof. unfold Equation4154. intro H. specialize (H F9_0 F9_1). unfold magma_op, refa28_inst, refa28_op in H. discriminate H. Qed.

Lemma refa28_not4167 : ~ @Equation4167 Fin9 refa28_inst.
Proof. unfold Equation4167. intro H. specialize (H F9_0 F9_1). unfold magma_op, refa28_inst, refa28_op in H. discriminate H. Qed.

Lemma refa28_not4283 : ~ @Equation4283 Fin9 refa28_inst.
Proof. unfold Equation4283. intro H. specialize (H F9_0 F9_1). unfold magma_op, refa28_inst, refa28_op in H. discriminate H. Qed.

Lemma refa28_not4293 : ~ @Equation4293 Fin9 refa28_inst.
Proof. unfold Equation4293. intro H. specialize (H F9_0 F9_1). unfold magma_op, refa28_inst, refa28_op in H. discriminate H. Qed.

Lemma refa28_not4398 : ~ @Equation4398 Fin9 refa28_inst.
Proof. unfold Equation4398. intro H. specialize (H F9_0 F9_1). unfold magma_op, refa28_inst, refa28_op in H. discriminate H. Qed.

Lemma refa28_not4405 : ~ @Equation4405 Fin9 refa28_inst.
Proof. unfold Equation4405. intro H. specialize (H F9_0 F9_1). unfold magma_op, refa28_inst, refa28_op in H. discriminate H. Qed.

Lemma refa28_not4409 : ~ @Equation4409 Fin9 refa28_inst.
Proof. unfold Equation4409. intro H. specialize (H F9_0 F9_1). unfold magma_op, refa28_inst, refa28_op in H. discriminate H. Qed.

Lemma refa28_not4442 : ~ @Equation4442 Fin9 refa28_inst.
Proof. unfold Equation4442. intro H. specialize (H F9_0 F9_1). unfold magma_op, refa28_inst, refa28_op in H. discriminate H. Qed.

Lemma refa28_not4482 : ~ @Equation4482 Fin9 refa28_inst.
Proof. unfold Equation4482. intro H. specialize (H F9_0 F9_1). unfold magma_op, refa28_inst, refa28_op in H. discriminate H. Qed.

Lemma refa28_not4635 : ~ @Equation4635 Fin9 refa28_inst.
Proof. unfold Equation4635. intro H. specialize (H F9_0 F9_1). unfold magma_op, refa28_inst, refa28_op in H. discriminate H. Qed.

(** ---- refa280 (Fin3) ---- *)

Definition refa280_op (x y : Fin3) : Fin3 :=
  match x, y with
  | F3_0, F3_0 => F3_0 | F3_0, F3_1 => F3_0 | F3_0, F3_2 => F3_1
  | F3_1, F3_0 => F3_2 | F3_1, F3_1 => F3_0 | F3_1, F3_2 => F3_2
  | F3_2, F3_0 => F3_1 | F3_2, F3_1 => F3_1 | F3_2, F3_2 => F3_0
  end.

#[local] Instance refa280_inst : Magma Fin3 := {| magma_op := refa280_op |}.

Lemma refa280_sat1845 : @Equation1845 Fin3 refa280_inst.
Proof. unfold Equation1845, magma_op, refa280_inst, refa280_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa280_not1834 : ~ @Equation1834 Fin3 refa280_inst.
Proof. unfold Equation1834. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa280_inst, refa280_op in H. discriminate H. Qed.

Lemma refa280_not1840 : ~ @Equation1840 Fin3 refa280_inst.
Proof. unfold Equation1840. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa280_inst, refa280_op in H. discriminate H. Qed.

Lemma refa280_not1860 : ~ @Equation1860 Fin3 refa280_inst.
Proof. unfold Equation1860. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa280_inst, refa280_op in H. discriminate H. Qed.

Lemma refa280_not2256 : ~ @Equation2256 Fin3 refa280_inst.
Proof. unfold Equation2256. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa280_inst, refa280_op in H. discriminate H. Qed.

Lemma refa280_not2443 : ~ @Equation2443 Fin3 refa280_inst.
Proof. unfold Equation2443. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa280_inst, refa280_op in H. discriminate H. Qed.

Lemma refa280_not2456 : ~ @Equation2456 Fin3 refa280_inst.
Proof. unfold Equation2456. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa280_inst, refa280_op in H. discriminate H. Qed.

Lemma refa280_not2459 : ~ @Equation2459 Fin3 refa280_inst.
Proof. unfold Equation2459. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa280_inst, refa280_op in H. discriminate H. Qed.

Lemma refa280_not2469 : ~ @Equation2469 Fin3 refa280_inst.
Proof. unfold Equation2469. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa280_inst, refa280_op in H. discriminate H. Qed.

Lemma refa280_not4065 : ~ @Equation4065 Fin3 refa280_inst.
Proof. unfold Equation4065. intro H. specialize (H F3_2). unfold magma_op, refa280_inst, refa280_op in H. discriminate H. Qed.

Lemma refa280_not4583 : ~ @Equation4583 Fin3 refa280_inst.
Proof. unfold Equation4583. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa280_inst, refa280_op in H. discriminate H. Qed.

(** ---- refa281 (Fin3) ---- *)

Definition refa281_op (x y : Fin3) : Fin3 :=
  match x, y with
  | F3_0, F3_0 => F3_0 | F3_0, F3_1 => F3_0 | F3_0, F3_2 => F3_0
  | F3_1, F3_0 => F3_0 | F3_1, F3_1 => F3_2 | F3_1, F3_2 => F3_0
  | F3_2, F3_0 => F3_2 | F3_2, F3_1 => F3_2 | F3_2, F3_2 => F3_2
  end.

#[local] Instance refa281_inst : Magma Fin3 := {| magma_op := refa281_op |}.

Lemma refa281_sat379 : @Equation379 Fin3 refa281_inst.
Proof. unfold Equation379, magma_op, refa281_inst, refa281_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa281_not3253 : ~ @Equation3253 Fin3 refa281_inst.
Proof. unfold Equation3253. intro H. specialize (H F3_1). unfold magma_op, refa281_inst, refa281_op in H. discriminate H. Qed.

(** ---- refa282 (Fin3) ---- *)

Definition refa282_op (x y : Fin3) : Fin3 :=
  match x, y with
  | F3_0, F3_0 => F3_0 | F3_0, F3_1 => F3_2 | F3_0, F3_2 => F3_1
  | F3_1, F3_0 => F3_0 | F3_1, F3_1 => F3_2 | F3_1, F3_2 => F3_1
  | F3_2, F3_0 => F3_2 | F3_2, F3_1 => F3_0 | F3_2, F3_2 => F3_1
  end.

#[local] Instance refa282_inst : Magma Fin3 := {| magma_op := refa282_op |}.

Lemma refa282_sat1975 : @Equation1975 Fin3 refa282_inst.
Proof. unfold Equation1975, magma_op, refa282_inst, refa282_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa282_sat3901 : @Equation3901 Fin3 refa282_inst.
Proof. unfold Equation3901, magma_op, refa282_inst, refa282_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa282_sat3972 : @Equation3972 Fin3 refa282_inst.
Proof. unfold Equation3972, magma_op, refa282_inst, refa282_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa282_not1837 : ~ @Equation1837 Fin3 refa282_inst.
Proof. unfold Equation1837. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa282_inst, refa282_op in H. discriminate H. Qed.

Lemma refa282_not1857 : ~ @Equation1857 Fin3 refa282_inst.
Proof. unfold Equation1857. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa282_inst, refa282_op in H. discriminate H. Qed.

Lemma refa282_not2050 : ~ @Equation2050 Fin3 refa282_inst.
Proof. unfold Equation2050. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa282_inst, refa282_op in H. discriminate H. Qed.

Lemma refa282_not2087 : ~ @Equation2087 Fin3 refa282_inst.
Proof. unfold Equation2087. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa282_inst, refa282_op in H. discriminate H. Qed.

Lemma refa282_not2124 : ~ @Equation2124 Fin3 refa282_inst.
Proof. unfold Equation2124. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa282_inst, refa282_op in H. discriminate H. Qed.

Lemma refa282_not3864 : ~ @Equation3864 Fin3 refa282_inst.
Proof. unfold Equation3864. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa282_inst, refa282_op in H. discriminate H. Qed.

Lemma refa282_not3877 : ~ @Equation3877 Fin3 refa282_inst.
Proof. unfold Equation3877. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa282_inst, refa282_op in H. discriminate H. Qed.

Lemma refa282_not3887 : ~ @Equation3887 Fin3 refa282_inst.
Proof. unfold Equation3887. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa282_inst, refa282_op in H. discriminate H. Qed.

Lemma refa282_not3915 : ~ @Equation3915 Fin3 refa282_inst.
Proof. unfold Equation3915. intro H. specialize (H F3_2 F3_0). unfold magma_op, refa282_inst, refa282_op in H. discriminate H. Qed.

Lemma refa282_not3925 : ~ @Equation3925 Fin3 refa282_inst.
Proof. unfold Equation3925. intro H. specialize (H F3_2 F3_0). unfold magma_op, refa282_inst, refa282_op in H. discriminate H. Qed.

Lemma refa282_not4067 : ~ @Equation4067 Fin3 refa282_inst.
Proof. unfold Equation4067. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa282_inst, refa282_op in H. discriminate H. Qed.

Lemma refa282_not4083 : ~ @Equation4083 Fin3 refa282_inst.
Proof. unfold Equation4083. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa282_inst, refa282_op in H. discriminate H. Qed.

Lemma refa282_not4269 : ~ @Equation4269 Fin3 refa282_inst.
Proof. unfold Equation4269. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa282_inst, refa282_op in H. discriminate H. Qed.

Lemma refa282_not4284 : ~ @Equation4284 Fin3 refa282_inst.
Proof. unfold Equation4284. intro H. specialize (H F3_2 F3_0). unfold magma_op, refa282_inst, refa282_op in H. discriminate H. Qed.

Lemma refa282_not4666 : ~ @Equation4666 Fin3 refa282_inst.
Proof. unfold Equation4666. intro H. specialize (H F3_0 F3_0 F3_2). unfold magma_op, refa282_inst, refa282_op in H. discriminate H. Qed.

(** ---- refa283 (Fin3) ---- *)

Definition refa283_op (x y : Fin3) : Fin3 :=
  match x, y with
  | F3_0, F3_0 => F3_0 | F3_0, F3_1 => F3_0 | F3_0, F3_2 => F3_1
  | F3_1, F3_0 => F3_0 | F3_1, F3_1 => F3_0 | F3_1, F3_2 => F3_0
  | F3_2, F3_0 => F3_1 | F3_2, F3_1 => F3_1 | F3_2, F3_2 => F3_0
  end.

#[local] Instance refa283_inst : Magma Fin3 := {| magma_op := refa283_op |}.

Lemma refa283_sat4548 : @Equation4548 Fin3 refa283_inst.
Proof. unfold Equation4548, magma_op, refa283_inst, refa283_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa283_not4398 : ~ @Equation4398 Fin3 refa283_inst.
Proof. unfold Equation4398. intro H. specialize (H F3_2 F3_0). unfold magma_op, refa283_inst, refa283_op in H. discriminate H. Qed.

Lemma refa283_not4435 : ~ @Equation4435 Fin3 refa283_inst.
Proof. unfold Equation4435. intro H. specialize (H F3_2 F3_0). unfold magma_op, refa283_inst, refa283_op in H. discriminate H. Qed.

Lemma refa283_not4472 : ~ @Equation4472 Fin3 refa283_inst.
Proof. unfold Equation4472. intro H. specialize (H F3_2 F3_0). unfold magma_op, refa283_inst, refa283_op in H. discriminate H. Qed.

Lemma refa283_not4584 : ~ @Equation4584 Fin3 refa283_inst.
Proof. unfold Equation4584. intro H. specialize (H F3_2 F3_0). unfold magma_op, refa283_inst, refa283_op in H. discriminate H. Qed.

Lemma refa283_not4606 : ~ @Equation4606 Fin3 refa283_inst.
Proof. unfold Equation4606. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa283_inst, refa283_op in H. discriminate H. Qed.

(** ---- refa284 (Fin3) ---- *)

Definition refa284_op (x y : Fin3) : Fin3 :=
  match x, y with
  | F3_0, F3_0 => F3_0 | F3_0, F3_1 => F3_0 | F3_0, F3_2 => F3_2
  | F3_1, F3_0 => F3_2 | F3_1, F3_1 => F3_2 | F3_1, F3_2 => F3_0
  | F3_2, F3_0 => F3_0 | F3_2, F3_1 => F3_0 | F3_2, F3_2 => F3_2
  end.

#[local] Instance refa284_inst : Magma Fin3 := {| magma_op := refa284_op |}.

Lemma refa284_sat3388 : @Equation3388 Fin3 refa284_inst.
Proof. unfold Equation3388, magma_op, refa284_inst, refa284_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa284_sat3541 : @Equation3541 Fin3 refa284_inst.
Proof. unfold Equation3541, magma_op, refa284_inst, refa284_op. intros x y z w. destruct x, y, z, w; reflexivity. Qed.

Lemma refa284_sat3837 : @Equation3837 Fin3 refa284_inst.
Proof. unfold Equation3837, magma_op, refa284_inst, refa284_op. intros x y z w. destruct x, y, z, w; reflexivity. Qed.

Lemma refa284_sat4428 : @Equation4428 Fin3 refa284_inst.
Proof. unfold Equation4428, magma_op, refa284_inst, refa284_op. intros x y z w. destruct x, y, z, w; reflexivity. Qed.

Lemma refa284_not307 : ~ @Equation307 Fin3 refa284_inst.
Proof. unfold Equation307. intro H. specialize (H F3_1). unfold magma_op, refa284_inst, refa284_op in H. discriminate H. Qed.

Lemma refa284_not3255 : ~ @Equation3255 Fin3 refa284_inst.
Proof. unfold Equation3255. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa284_inst, refa284_op in H. discriminate H. Qed.

Lemma refa284_not3256 : ~ @Equation3256 Fin3 refa284_inst.
Proof. unfold Equation3256. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa284_inst, refa284_op in H. discriminate H. Qed.

Lemma refa284_not3258 : ~ @Equation3258 Fin3 refa284_inst.
Proof. unfold Equation3258. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa284_inst, refa284_op in H. discriminate H. Qed.

Lemma refa284_not3259 : ~ @Equation3259 Fin3 refa284_inst.
Proof. unfold Equation3259. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa284_inst, refa284_op in H. discriminate H. Qed.

Lemma refa284_not3262 : ~ @Equation3262 Fin3 refa284_inst.
Proof. unfold Equation3262. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa284_inst, refa284_op in H. discriminate H. Qed.

Lemma refa284_not3309 : ~ @Equation3309 Fin3 refa284_inst.
Proof. unfold Equation3309. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa284_inst, refa284_op in H. discriminate H. Qed.

Lemma refa284_not3316 : ~ @Equation3316 Fin3 refa284_inst.
Proof. unfold Equation3316. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa284_inst, refa284_op in H. discriminate H. Qed.

Lemma refa284_not3459 : ~ @Equation3459 Fin3 refa284_inst.
Proof. unfold Equation3459. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa284_inst, refa284_op in H. discriminate H. Qed.

Lemma refa284_not3511 : ~ @Equation3511 Fin3 refa284_inst.
Proof. unfold Equation3511. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa284_inst, refa284_op in H. discriminate H. Qed.

Lemma refa284_not3521 : ~ @Equation3521 Fin3 refa284_inst.
Proof. unfold Equation3521. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa284_inst, refa284_op in H. discriminate H. Qed.

Lemma refa284_not3662 : ~ @Equation3662 Fin3 refa284_inst.
Proof. unfold Equation3662. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa284_inst, refa284_op in H. discriminate H. Qed.

Lemma refa284_not3665 : ~ @Equation3665 Fin3 refa284_inst.
Proof. unfold Equation3665. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa284_inst, refa284_op in H. discriminate H. Qed.

Lemma refa284_not3668 : ~ @Equation3668 Fin3 refa284_inst.
Proof. unfold Equation3668. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa284_inst, refa284_op in H. discriminate H. Qed.

Lemma refa284_not3725 : ~ @Equation3725 Fin3 refa284_inst.
Proof. unfold Equation3725. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa284_inst, refa284_op in H. discriminate H. Qed.

Lemma refa284_not3862 : ~ @Equation3862 Fin3 refa284_inst.
Proof. unfold Equation3862. intro H. specialize (H F3_1). unfold magma_op, refa284_inst, refa284_op in H. discriminate H. Qed.

Lemma refa284_not4065 : ~ @Equation4065 Fin3 refa284_inst.
Proof. unfold Equation4065. intro H. specialize (H F3_1). unfold magma_op, refa284_inst, refa284_op in H. discriminate H. Qed.

Lemma refa284_not4269 : ~ @Equation4269 Fin3 refa284_inst.
Proof. unfold Equation4269. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa284_inst, refa284_op in H. discriminate H. Qed.

Lemma refa284_not4270 : ~ @Equation4270 Fin3 refa284_inst.
Proof. unfold Equation4270. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa284_inst, refa284_op in H. discriminate H. Qed.

Lemma refa284_not4272 : ~ @Equation4272 Fin3 refa284_inst.
Proof. unfold Equation4272. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa284_inst, refa284_op in H. discriminate H. Qed.

Lemma refa284_not4284 : ~ @Equation4284 Fin3 refa284_inst.
Proof. unfold Equation4284. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa284_inst, refa284_op in H. discriminate H. Qed.

Lemma refa284_not4291 : ~ @Equation4291 Fin3 refa284_inst.
Proof. unfold Equation4291. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa284_inst, refa284_op in H. discriminate H. Qed.

Lemma refa284_not4314 : ~ @Equation4314 Fin3 refa284_inst.
Proof. unfold Equation4314. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa284_inst, refa284_op in H. discriminate H. Qed.

Lemma refa284_not4435 : ~ @Equation4435 Fin3 refa284_inst.
Proof. unfold Equation4435. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa284_inst, refa284_op in H. discriminate H. Qed.

Lemma refa284_not4442 : ~ @Equation4442 Fin3 refa284_inst.
Proof. unfold Equation4442. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa284_inst, refa284_op in H. discriminate H. Qed.

Lemma refa284_not4470 : ~ @Equation4470 Fin3 refa284_inst.
Proof. unfold Equation4470. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa284_inst, refa284_op in H. discriminate H. Qed.

Lemma refa284_not4473 : ~ @Equation4473 Fin3 refa284_inst.
Proof. unfold Equation4473. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa284_inst, refa284_op in H. discriminate H. Qed.

Lemma refa284_not4480 : ~ @Equation4480 Fin3 refa284_inst.
Proof. unfold Equation4480. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa284_inst, refa284_op in H. discriminate H. Qed.

(** ---- refa285 (Fin3) ---- *)

Definition refa285_op (x y : Fin3) : Fin3 :=
  match x, y with
  | F3_0, F3_0 => F3_0 | F3_0, F3_1 => F3_2 | F3_0, F3_2 => F3_1
  | F3_1, F3_0 => F3_2 | F3_1, F3_1 => F3_1 | F3_1, F3_2 => F3_0
  | F3_2, F3_0 => F3_1 | F3_2, F3_1 => F3_0 | F3_2, F3_2 => F3_2
  end.

#[local] Instance refa285_inst : Magma Fin3 := {| magma_op := refa285_op |}.

Lemma refa285_sat102 : @Equation102 Fin3 refa285_inst.
Proof. unfold Equation102, magma_op, refa285_inst, refa285_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa285_sat221 : @Equation221 Fin3 refa285_inst.
Proof. unfold Equation221, magma_op, refa285_inst, refa285_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa285_sat228 : @Equation228 Fin3 refa285_inst.
Proof. unfold Equation228, magma_op, refa285_inst, refa285_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa285_sat258 : @Equation258 Fin3 refa285_inst.
Proof. unfold Equation258, magma_op, refa285_inst, refa285_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa285_sat273 : @Equation273 Fin3 refa285_inst.
Proof. unfold Equation273, magma_op, refa285_inst, refa285_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa285_sat281 : @Equation281 Fin3 refa285_inst.
Proof. unfold Equation281, magma_op, refa285_inst, refa285_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa285_sat313 : @Equation313 Fin3 refa285_inst.
Proof. unfold Equation313, magma_op, refa285_inst, refa285_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa285_sat315 : @Equation315 Fin3 refa285_inst.
Proof. unfold Equation315, magma_op, refa285_inst, refa285_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa285_sat365 : @Equation365 Fin3 refa285_inst.
Proof. unfold Equation365, magma_op, refa285_inst, refa285_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa285_sat387 : @Equation387 Fin3 refa285_inst.
Proof. unfold Equation387, magma_op, refa285_inst, refa285_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa285_sat430 : @Equation430 Fin3 refa285_inst.
Proof. unfold Equation430, magma_op, refa285_inst, refa285_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa285_sat880 : @Equation880 Fin3 refa285_inst.
Proof. unfold Equation880, magma_op, refa285_inst, refa285_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa285_sat882 : @Equation882 Fin3 refa285_inst.
Proof. unfold Equation882, magma_op, refa285_inst, refa285_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa285_sat907 : @Equation907 Fin3 refa285_inst.
Proof. unfold Equation907, magma_op, refa285_inst, refa285_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa285_sat909 : @Equation909 Fin3 refa285_inst.
Proof. unfold Equation909, magma_op, refa285_inst, refa285_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa285_sat916 : @Equation916 Fin3 refa285_inst.
Proof. unfold Equation916, magma_op, refa285_inst, refa285_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa285_sat1525 : @Equation1525 Fin3 refa285_inst.
Proof. unfold Equation1525, magma_op, refa285_inst, refa285_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa285_sat1719 : @Equation1719 Fin3 refa285_inst.
Proof. unfold Equation1719, magma_op, refa285_inst, refa285_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa285_sat1888 : @Equation1888 Fin3 refa285_inst.
Proof. unfold Equation1888, magma_op, refa285_inst, refa285_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa285_sat2653 : @Equation2653 Fin3 refa285_inst.
Proof. unfold Equation2653, magma_op, refa285_inst, refa285_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa285_sat2670 : @Equation2670 Fin3 refa285_inst.
Proof. unfold Equation2670, magma_op, refa285_inst, refa285_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa285_sat2700 : @Equation2700 Fin3 refa285_inst.
Proof. unfold Equation2700, magma_op, refa285_inst, refa285_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa285_sat2707 : @Equation2707 Fin3 refa285_inst.
Proof. unfold Equation2707, magma_op, refa285_inst, refa285_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa285_sat2709 : @Equation2709 Fin3 refa285_inst.
Proof. unfold Equation2709, magma_op, refa285_inst, refa285_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa285_sat3687 : @Equation3687 Fin3 refa285_inst.
Proof. unfold Equation3687, magma_op, refa285_inst, refa285_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa285_sat3751 : @Equation3751 Fin3 refa285_inst.
Proof. unfold Equation3751, magma_op, refa285_inst, refa285_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa285_not50 : ~ @Equation50 Fin3 refa285_inst.
Proof. unfold Equation50. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa285_inst, refa285_op in H. discriminate H. Qed.

Lemma refa285_not56 : ~ @Equation56 Fin3 refa285_inst.
Proof. unfold Equation56. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa285_inst, refa285_op in H. discriminate H. Qed.

Lemma refa285_not63 : ~ @Equation63 Fin3 refa285_inst.
Proof. unfold Equation63. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa285_inst, refa285_op in H. discriminate H. Qed.

Lemma refa285_not65 : ~ @Equation65 Fin3 refa285_inst.
Proof. unfold Equation65. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa285_inst, refa285_op in H. discriminate H. Qed.

Lemma refa285_not73 : ~ @Equation73 Fin3 refa285_inst.
Proof. unfold Equation73. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa285_inst, refa285_op in H. discriminate H. Qed.

Lemma refa285_not75 : ~ @Equation75 Fin3 refa285_inst.
Proof. unfold Equation75. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa285_inst, refa285_op in H. discriminate H. Qed.

Lemma refa285_not107 : ~ @Equation107 Fin3 refa285_inst.
Proof. unfold Equation107. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa285_inst, refa285_op in H. discriminate H. Qed.

Lemma refa285_not108 : ~ @Equation108 Fin3 refa285_inst.
Proof. unfold Equation108. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa285_inst, refa285_op in H. discriminate H. Qed.

Lemma refa285_not117 : ~ @Equation117 Fin3 refa285_inst.
Proof. unfold Equation117. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa285_inst, refa285_op in H. discriminate H. Qed.

Lemma refa285_not118 : ~ @Equation118 Fin3 refa285_inst.
Proof. unfold Equation118. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa285_inst, refa285_op in H. discriminate H. Qed.

Lemma refa285_not124 : ~ @Equation124 Fin3 refa285_inst.
Proof. unfold Equation124. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa285_inst, refa285_op in H. discriminate H. Qed.

Lemma refa285_not159 : ~ @Equation159 Fin3 refa285_inst.
Proof. unfold Equation159. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa285_inst, refa285_op in H. discriminate H. Qed.

Lemma refa285_not167 : ~ @Equation167 Fin3 refa285_inst.
Proof. unfold Equation167. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa285_inst, refa285_op in H. discriminate H. Qed.

Lemma refa285_not206 : ~ @Equation206 Fin3 refa285_inst.
Proof. unfold Equation206. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa285_inst, refa285_op in H. discriminate H. Qed.

Lemma refa285_not209 : ~ @Equation209 Fin3 refa285_inst.
Proof. unfold Equation209. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa285_inst, refa285_op in H. discriminate H. Qed.

Lemma refa285_not211 : ~ @Equation211 Fin3 refa285_inst.
Proof. unfold Equation211. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa285_inst, refa285_op in H. discriminate H. Qed.

Lemma refa285_not229 : ~ @Equation229 Fin3 refa285_inst.
Proof. unfold Equation229. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa285_inst, refa285_op in H. discriminate H. Qed.

Lemma refa285_not231 : ~ @Equation231 Fin3 refa285_inst.
Proof. unfold Equation231. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa285_inst, refa285_op in H. discriminate H. Qed.

Lemma refa285_not261 : ~ @Equation261 Fin3 refa285_inst.
Proof. unfold Equation261. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa285_inst, refa285_op in H. discriminate H. Qed.

Lemma refa285_not264 : ~ @Equation264 Fin3 refa285_inst.
Proof. unfold Equation264. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa285_inst, refa285_op in H. discriminate H. Qed.

Lemma refa285_not274 : ~ @Equation274 Fin3 refa285_inst.
Proof. unfold Equation274. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa285_inst, refa285_op in H. discriminate H. Qed.

Lemma refa285_not280 : ~ @Equation280 Fin3 refa285_inst.
Proof. unfold Equation280. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa285_inst, refa285_op in H. discriminate H. Qed.

Lemma refa285_not283 : ~ @Equation283 Fin3 refa285_inst.
Proof. unfold Equation283. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa285_inst, refa285_op in H. discriminate H. Qed.

Lemma refa285_not323 : ~ @Equation323 Fin3 refa285_inst.
Proof. unfold Equation323. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa285_inst, refa285_op in H. discriminate H. Qed.

Lemma refa285_not333 : ~ @Equation333 Fin3 refa285_inst.
Proof. unfold Equation333. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa285_inst, refa285_op in H. discriminate H. Qed.

Lemma refa285_not377 : ~ @Equation377 Fin3 refa285_inst.
Proof. unfold Equation377. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa285_inst, refa285_op in H. discriminate H. Qed.

Lemma refa285_not378 : ~ @Equation378 Fin3 refa285_inst.
Proof. unfold Equation378. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa285_inst, refa285_op in H. discriminate H. Qed.

Lemma refa285_not412 : ~ @Equation412 Fin3 refa285_inst.
Proof. unfold Equation412. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa285_inst, refa285_op in H. discriminate H. Qed.

Lemma refa285_not413 : ~ @Equation413 Fin3 refa285_inst.
Proof. unfold Equation413. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa285_inst, refa285_op in H. discriminate H. Qed.

Lemma refa285_not414 : ~ @Equation414 Fin3 refa285_inst.
Proof. unfold Equation414. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa285_inst, refa285_op in H. discriminate H. Qed.

Lemma refa285_not416 : ~ @Equation416 Fin3 refa285_inst.
Proof. unfold Equation416. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa285_inst, refa285_op in H. discriminate H. Qed.

Lemma refa285_not420 : ~ @Equation420 Fin3 refa285_inst.
Proof. unfold Equation420. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa285_inst, refa285_op in H. discriminate H. Qed.

Lemma refa285_not426 : ~ @Equation426 Fin3 refa285_inst.
Proof. unfold Equation426. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa285_inst, refa285_op in H. discriminate H. Qed.

Lemma refa285_not429 : ~ @Equation429 Fin3 refa285_inst.
Proof. unfold Equation429. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa285_inst, refa285_op in H. discriminate H. Qed.

Lemma refa285_not437 : ~ @Equation437 Fin3 refa285_inst.
Proof. unfold Equation437. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa285_inst, refa285_op in H. discriminate H. Qed.

Lemma refa285_not440 : ~ @Equation440 Fin3 refa285_inst.
Proof. unfold Equation440. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa285_inst, refa285_op in H. discriminate H. Qed.

Lemma refa285_not467 : ~ @Equation467 Fin3 refa285_inst.
Proof. unfold Equation467. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa285_inst, refa285_op in H. discriminate H. Qed.

Lemma refa285_not473 : ~ @Equation473 Fin3 refa285_inst.
Proof. unfold Equation473. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa285_inst, refa285_op in H. discriminate H. Qed.

Lemma refa285_not474 : ~ @Equation474 Fin3 refa285_inst.
Proof. unfold Equation474. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa285_inst, refa285_op in H. discriminate H. Qed.

Lemma refa285_not476 : ~ @Equation476 Fin3 refa285_inst.
Proof. unfold Equation476. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa285_inst, refa285_op in H. discriminate H. Qed.

Lemma refa285_not501 : ~ @Equation501 Fin3 refa285_inst.
Proof. unfold Equation501. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa285_inst, refa285_op in H. discriminate H. Qed.

Lemma refa285_not503 : ~ @Equation503 Fin3 refa285_inst.
Proof. unfold Equation503. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa285_inst, refa285_op in H. discriminate H. Qed.

Lemma refa285_not504 : ~ @Equation504 Fin3 refa285_inst.
Proof. unfold Equation504. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa285_inst, refa285_op in H. discriminate H. Qed.

Lemma refa285_not615 : ~ @Equation615 Fin3 refa285_inst.
Proof. unfold Equation615. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa285_inst, refa285_op in H. discriminate H. Qed.

Lemma refa285_not616 : ~ @Equation616 Fin3 refa285_inst.
Proof. unfold Equation616. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa285_inst, refa285_op in H. discriminate H. Qed.

Lemma refa285_not619 : ~ @Equation619 Fin3 refa285_inst.
Proof. unfold Equation619. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa285_inst, refa285_op in H. discriminate H. Qed.

Lemma refa285_not622 : ~ @Equation622 Fin3 refa285_inst.
Proof. unfold Equation622. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa285_inst, refa285_op in H. discriminate H. Qed.

Lemma refa285_not623 : ~ @Equation623 Fin3 refa285_inst.
Proof. unfold Equation623. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa285_inst, refa285_op in H. discriminate H. Qed.

Lemma refa285_not629 : ~ @Equation629 Fin3 refa285_inst.
Proof. unfold Equation629. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa285_inst, refa285_op in H. discriminate H. Qed.

Lemma refa285_not632 : ~ @Equation632 Fin3 refa285_inst.
Proof. unfold Equation632. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa285_inst, refa285_op in H. discriminate H. Qed.

Lemma refa285_not633 : ~ @Equation633 Fin3 refa285_inst.
Proof. unfold Equation633. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa285_inst, refa285_op in H. discriminate H. Qed.

Lemma refa285_not639 : ~ @Equation639 Fin3 refa285_inst.
Proof. unfold Equation639. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa285_inst, refa285_op in H. discriminate H. Qed.

Lemma refa285_not640 : ~ @Equation640 Fin3 refa285_inst.
Proof. unfold Equation640. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa285_inst, refa285_op in H. discriminate H. Qed.

Lemma refa285_not643 : ~ @Equation643 Fin3 refa285_inst.
Proof. unfold Equation643. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa285_inst, refa285_op in H. discriminate H. Qed.

Lemma refa285_not670 : ~ @Equation670 Fin3 refa285_inst.
Proof. unfold Equation670. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa285_inst, refa285_op in H. discriminate H. Qed.

Lemma refa285_not677 : ~ @Equation677 Fin3 refa285_inst.
Proof. unfold Equation677. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa285_inst, refa285_op in H. discriminate H. Qed.

Lemma refa285_not679 : ~ @Equation679 Fin3 refa285_inst.
Proof. unfold Equation679. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa285_inst, refa285_op in H. discriminate H. Qed.

Lemma refa285_not704 : ~ @Equation704 Fin3 refa285_inst.
Proof. unfold Equation704. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa285_inst, refa285_op in H. discriminate H. Qed.

Lemma refa285_not706 : ~ @Equation706 Fin3 refa285_inst.
Proof. unfold Equation706. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa285_inst, refa285_op in H. discriminate H. Qed.

Lemma refa285_not713 : ~ @Equation713 Fin3 refa285_inst.
Proof. unfold Equation713. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa285_inst, refa285_op in H. discriminate H. Qed.

Lemma refa285_not716 : ~ @Equation716 Fin3 refa285_inst.
Proof. unfold Equation716. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa285_inst, refa285_op in H. discriminate H. Qed.

Lemma refa285_not818 : ~ @Equation818 Fin3 refa285_inst.
Proof. unfold Equation818. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa285_inst, refa285_op in H. discriminate H. Qed.

Lemma refa285_not819 : ~ @Equation819 Fin3 refa285_inst.
Proof. unfold Equation819. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa285_inst, refa285_op in H. discriminate H. Qed.

Lemma refa285_not820 : ~ @Equation820 Fin3 refa285_inst.
Proof. unfold Equation820. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa285_inst, refa285_op in H. discriminate H. Qed.

Lemma refa285_not822 : ~ @Equation822 Fin3 refa285_inst.
Proof. unfold Equation822. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa285_inst, refa285_op in H. discriminate H. Qed.

Lemma refa285_not823 : ~ @Equation823 Fin3 refa285_inst.
Proof. unfold Equation823. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa285_inst, refa285_op in H. discriminate H. Qed.

Lemma refa285_not825 : ~ @Equation825 Fin3 refa285_inst.
Proof. unfold Equation825. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa285_inst, refa285_op in H. discriminate H. Qed.

Lemma refa285_not832 : ~ @Equation832 Fin3 refa285_inst.
Proof. unfold Equation832. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa285_inst, refa285_op in H. discriminate H. Qed.

Lemma refa285_not835 : ~ @Equation835 Fin3 refa285_inst.
Proof. unfold Equation835. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa285_inst, refa285_op in H. discriminate H. Qed.

Lemma refa285_not842 : ~ @Equation842 Fin3 refa285_inst.
Proof. unfold Equation842. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa285_inst, refa285_op in H. discriminate H. Qed.

Lemma refa285_not872 : ~ @Equation872 Fin3 refa285_inst.
Proof. unfold Equation872. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa285_inst, refa285_op in H. discriminate H. Qed.

Lemma refa285_not879 : ~ @Equation879 Fin3 refa285_inst.
Proof. unfold Equation879. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa285_inst, refa285_op in H. discriminate H. Qed.

Lemma refa285_not883 : ~ @Equation883 Fin3 refa285_inst.
Proof. unfold Equation883. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa285_inst, refa285_op in H. discriminate H. Qed.

Lemma refa285_not906 : ~ @Equation906 Fin3 refa285_inst.
Proof. unfold Equation906. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa285_inst, refa285_op in H. discriminate H. Qed.

Lemma refa285_not917 : ~ @Equation917 Fin3 refa285_inst.
Proof. unfold Equation917. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa285_inst, refa285_op in H. discriminate H. Qed.

Lemma refa285_not1021 : ~ @Equation1021 Fin3 refa285_inst.
Proof. unfold Equation1021. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa285_inst, refa285_op in H. discriminate H. Qed.

Lemma refa285_not1022 : ~ @Equation1022 Fin3 refa285_inst.
Proof. unfold Equation1022. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa285_inst, refa285_op in H. discriminate H. Qed.

Lemma refa285_not1023 : ~ @Equation1023 Fin3 refa285_inst.
Proof. unfold Equation1023. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa285_inst, refa285_op in H. discriminate H. Qed.

Lemma refa285_not1025 : ~ @Equation1025 Fin3 refa285_inst.
Proof. unfold Equation1025. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa285_inst, refa285_op in H. discriminate H. Qed.

Lemma refa285_not1026 : ~ @Equation1026 Fin3 refa285_inst.
Proof. unfold Equation1026. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa285_inst, refa285_op in H. discriminate H. Qed.

Lemma refa285_not1028 : ~ @Equation1028 Fin3 refa285_inst.
Proof. unfold Equation1028. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa285_inst, refa285_op in H. discriminate H. Qed.

Lemma refa285_not1035 : ~ @Equation1035 Fin3 refa285_inst.
Proof. unfold Equation1035. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa285_inst, refa285_op in H. discriminate H. Qed.

Lemma refa285_not1039 : ~ @Equation1039 Fin3 refa285_inst.
Proof. unfold Equation1039. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa285_inst, refa285_op in H. discriminate H. Qed.

Lemma refa285_not1046 : ~ @Equation1046 Fin3 refa285_inst.
Proof. unfold Equation1046. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa285_inst, refa285_op in H. discriminate H. Qed.

Lemma refa285_not1048 : ~ @Equation1048 Fin3 refa285_inst.
Proof. unfold Equation1048. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa285_inst, refa285_op in H. discriminate H. Qed.

Lemma refa285_not1076 : ~ @Equation1076 Fin3 refa285_inst.
Proof. unfold Equation1076. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa285_inst, refa285_op in H. discriminate H. Qed.

Lemma refa285_not1085 : ~ @Equation1085 Fin3 refa285_inst.
Proof. unfold Equation1085. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa285_inst, refa285_op in H. discriminate H. Qed.

Lemma refa285_not1086 : ~ @Equation1086 Fin3 refa285_inst.
Proof. unfold Equation1086. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa285_inst, refa285_op in H. discriminate H. Qed.

Lemma refa285_not1109 : ~ @Equation1109 Fin3 refa285_inst.
Proof. unfold Equation1109. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa285_inst, refa285_op in H. discriminate H. Qed.

Lemma refa285_not1110 : ~ @Equation1110 Fin3 refa285_inst.
Proof. unfold Equation1110. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa285_inst, refa285_op in H. discriminate H. Qed.

Lemma refa285_not1119 : ~ @Equation1119 Fin3 refa285_inst.
Proof. unfold Equation1119. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa285_inst, refa285_op in H. discriminate H. Qed.

Lemma refa285_not1224 : ~ @Equation1224 Fin3 refa285_inst.
Proof. unfold Equation1224. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa285_inst, refa285_op in H. discriminate H. Qed.

Lemma refa285_not1225 : ~ @Equation1225 Fin3 refa285_inst.
Proof. unfold Equation1225. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa285_inst, refa285_op in H. discriminate H. Qed.

Lemma refa285_not1228 : ~ @Equation1228 Fin3 refa285_inst.
Proof. unfold Equation1228. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa285_inst, refa285_op in H. discriminate H. Qed.

Lemma refa285_not1229 : ~ @Equation1229 Fin3 refa285_inst.
Proof. unfold Equation1229. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa285_inst, refa285_op in H. discriminate H. Qed.

Lemma refa285_not1232 : ~ @Equation1232 Fin3 refa285_inst.
Proof. unfold Equation1232. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa285_inst, refa285_op in H. discriminate H. Qed.

Lemma refa285_not1238 : ~ @Equation1238 Fin3 refa285_inst.
Proof. unfold Equation1238. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa285_inst, refa285_op in H. discriminate H. Qed.

Lemma refa285_not1239 : ~ @Equation1239 Fin3 refa285_inst.
Proof. unfold Equation1239. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa285_inst, refa285_op in H. discriminate H. Qed.

Lemma refa285_not1242 : ~ @Equation1242 Fin3 refa285_inst.
Proof. unfold Equation1242. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa285_inst, refa285_op in H. discriminate H. Qed.

Lemma refa285_not1248 : ~ @Equation1248 Fin3 refa285_inst.
Proof. unfold Equation1248. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa285_inst, refa285_op in H. discriminate H. Qed.

Lemma refa285_not1251 : ~ @Equation1251 Fin3 refa285_inst.
Proof. unfold Equation1251. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa285_inst, refa285_op in H. discriminate H. Qed.

Lemma refa285_not1252 : ~ @Equation1252 Fin3 refa285_inst.
Proof. unfold Equation1252. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa285_inst, refa285_op in H. discriminate H. Qed.

Lemma refa285_not1278 : ~ @Equation1278 Fin3 refa285_inst.
Proof. unfold Equation1278. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa285_inst, refa285_op in H. discriminate H. Qed.

Lemma refa285_not1279 : ~ @Equation1279 Fin3 refa285_inst.
Proof. unfold Equation1279. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa285_inst, refa285_op in H. discriminate H. Qed.

Lemma refa285_not1288 : ~ @Equation1288 Fin3 refa285_inst.
Proof. unfold Equation1288. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa285_inst, refa285_op in H. discriminate H. Qed.

Lemma refa285_not1313 : ~ @Equation1313 Fin3 refa285_inst.
Proof. unfold Equation1313. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa285_inst, refa285_op in H. discriminate H. Qed.

Lemma refa285_not1322 : ~ @Equation1322 Fin3 refa285_inst.
Proof. unfold Equation1322. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa285_inst, refa285_op in H. discriminate H. Qed.

Lemma refa285_not1427 : ~ @Equation1427 Fin3 refa285_inst.
Proof. unfold Equation1427. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa285_inst, refa285_op in H. discriminate H. Qed.

Lemma refa285_not1428 : ~ @Equation1428 Fin3 refa285_inst.
Proof. unfold Equation1428. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa285_inst, refa285_op in H. discriminate H. Qed.

Lemma refa285_not1429 : ~ @Equation1429 Fin3 refa285_inst.
Proof. unfold Equation1429. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa285_inst, refa285_op in H. discriminate H. Qed.

Lemma refa285_not1431 : ~ @Equation1431 Fin3 refa285_inst.
Proof. unfold Equation1431. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa285_inst, refa285_op in H. discriminate H. Qed.

Lemma refa285_not1435 : ~ @Equation1435 Fin3 refa285_inst.
Proof. unfold Equation1435. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa285_inst, refa285_op in H. discriminate H. Qed.

Lemma refa285_not1441 : ~ @Equation1441 Fin3 refa285_inst.
Proof. unfold Equation1441. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa285_inst, refa285_op in H. discriminate H. Qed.

Lemma refa285_not1445 : ~ @Equation1445 Fin3 refa285_inst.
Proof. unfold Equation1445. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa285_inst, refa285_op in H. discriminate H. Qed.

Lemma refa285_not1451 : ~ @Equation1451 Fin3 refa285_inst.
Proof. unfold Equation1451. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa285_inst, refa285_op in H. discriminate H. Qed.

Lemma refa285_not1454 : ~ @Equation1454 Fin3 refa285_inst.
Proof. unfold Equation1454. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa285_inst, refa285_op in H. discriminate H. Qed.

Lemma refa285_not1478 : ~ @Equation1478 Fin3 refa285_inst.
Proof. unfold Equation1478. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa285_inst, refa285_op in H. discriminate H. Qed.

Lemma refa285_not1482 : ~ @Equation1482 Fin3 refa285_inst.
Proof. unfold Equation1482. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa285_inst, refa285_op in H. discriminate H. Qed.

Lemma refa285_not1488 : ~ @Equation1488 Fin3 refa285_inst.
Proof. unfold Equation1488. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa285_inst, refa285_op in H. discriminate H. Qed.

Lemma refa285_not1491 : ~ @Equation1491 Fin3 refa285_inst.
Proof. unfold Equation1491. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa285_inst, refa285_op in H. discriminate H. Qed.

Lemma refa285_not1515 : ~ @Equation1515 Fin3 refa285_inst.
Proof. unfold Equation1515. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa285_inst, refa285_op in H. discriminate H. Qed.

Lemma refa285_not1518 : ~ @Equation1518 Fin3 refa285_inst.
Proof. unfold Equation1518. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa285_inst, refa285_op in H. discriminate H. Qed.

Lemma refa285_not1526 : ~ @Equation1526 Fin3 refa285_inst.
Proof. unfold Equation1526. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa285_inst, refa285_op in H. discriminate H. Qed.

Lemma refa285_not1630 : ~ @Equation1630 Fin3 refa285_inst.
Proof. unfold Equation1630. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa285_inst, refa285_op in H. discriminate H. Qed.

Lemma refa285_not1631 : ~ @Equation1631 Fin3 refa285_inst.
Proof. unfold Equation1631. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa285_inst, refa285_op in H. discriminate H. Qed.

Lemma refa285_not1634 : ~ @Equation1634 Fin3 refa285_inst.
Proof. unfold Equation1634. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa285_inst, refa285_op in H. discriminate H. Qed.

Lemma refa285_not1637 : ~ @Equation1637 Fin3 refa285_inst.
Proof. unfold Equation1637. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa285_inst, refa285_op in H. discriminate H. Qed.

Lemma refa285_not1638 : ~ @Equation1638 Fin3 refa285_inst.
Proof. unfold Equation1638. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa285_inst, refa285_op in H. discriminate H. Qed.

Lemma refa285_not1644 : ~ @Equation1644 Fin3 refa285_inst.
Proof. unfold Equation1644. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa285_inst, refa285_op in H. discriminate H. Qed.

Lemma refa285_not1645 : ~ @Equation1645 Fin3 refa285_inst.
Proof. unfold Equation1645. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa285_inst, refa285_op in H. discriminate H. Qed.

Lemma refa285_not1648 : ~ @Equation1648 Fin3 refa285_inst.
Proof. unfold Equation1648. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa285_inst, refa285_op in H. discriminate H. Qed.

Lemma refa285_not1655 : ~ @Equation1655 Fin3 refa285_inst.
Proof. unfold Equation1655. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa285_inst, refa285_op in H. discriminate H. Qed.

Lemma refa285_not1681 : ~ @Equation1681 Fin3 refa285_inst.
Proof. unfold Equation1681. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa285_inst, refa285_op in H. discriminate H. Qed.

Lemma refa285_not1682 : ~ @Equation1682 Fin3 refa285_inst.
Proof. unfold Equation1682. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa285_inst, refa285_op in H. discriminate H. Qed.

Lemma refa285_not1685 : ~ @Equation1685 Fin3 refa285_inst.
Proof. unfold Equation1685. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa285_inst, refa285_op in H. discriminate H. Qed.

Lemma refa285_not1721 : ~ @Equation1721 Fin3 refa285_inst.
Proof. unfold Equation1721. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa285_inst, refa285_op in H. discriminate H. Qed.

Lemma refa285_not1722 : ~ @Equation1722 Fin3 refa285_inst.
Proof. unfold Equation1722. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa285_inst, refa285_op in H. discriminate H. Qed.

Lemma refa285_not1728 : ~ @Equation1728 Fin3 refa285_inst.
Proof. unfold Equation1728. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa285_inst, refa285_op in H. discriminate H. Qed.

Lemma refa285_not1833 : ~ @Equation1833 Fin3 refa285_inst.
Proof. unfold Equation1833. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa285_inst, refa285_op in H. discriminate H. Qed.

Lemma refa285_not1834 : ~ @Equation1834 Fin3 refa285_inst.
Proof. unfold Equation1834. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa285_inst, refa285_op in H. discriminate H. Qed.

Lemma refa285_not1837 : ~ @Equation1837 Fin3 refa285_inst.
Proof. unfold Equation1837. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa285_inst, refa285_op in H. discriminate H. Qed.

Lemma refa285_not1841 : ~ @Equation1841 Fin3 refa285_inst.
Proof. unfold Equation1841. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa285_inst, refa285_op in H. discriminate H. Qed.

Lemma refa285_not1847 : ~ @Equation1847 Fin3 refa285_inst.
Proof. unfold Equation1847. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa285_inst, refa285_op in H. discriminate H. Qed.

Lemma refa285_not1851 : ~ @Equation1851 Fin3 refa285_inst.
Proof. unfold Equation1851. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa285_inst, refa285_op in H. discriminate H. Qed.

Lemma refa285_not1857 : ~ @Equation1857 Fin3 refa285_inst.
Proof. unfold Equation1857. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa285_inst, refa285_op in H. discriminate H. Qed.

Lemma refa285_not1858 : ~ @Equation1858 Fin3 refa285_inst.
Proof. unfold Equation1858. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa285_inst, refa285_op in H. discriminate H. Qed.

Lemma refa285_not1884 : ~ @Equation1884 Fin3 refa285_inst.
Proof. unfold Equation1884. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa285_inst, refa285_op in H. discriminate H. Qed.

Lemma refa285_not1885 : ~ @Equation1885 Fin3 refa285_inst.
Proof. unfold Equation1885. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa285_inst, refa285_op in H. discriminate H. Qed.

Lemma refa285_not1887 : ~ @Equation1887 Fin3 refa285_inst.
Proof. unfold Equation1887. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa285_inst, refa285_op in H. discriminate H. Qed.

Lemma refa285_not1895 : ~ @Equation1895 Fin3 refa285_inst.
Proof. unfold Equation1895. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa285_inst, refa285_op in H. discriminate H. Qed.

Lemma refa285_not1897 : ~ @Equation1897 Fin3 refa285_inst.
Proof. unfold Equation1897. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa285_inst, refa285_op in H. discriminate H. Qed.

Lemma refa285_not1924 : ~ @Equation1924 Fin3 refa285_inst.
Proof. unfold Equation1924. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa285_inst, refa285_op in H. discriminate H. Qed.

Lemma refa285_not1925 : ~ @Equation1925 Fin3 refa285_inst.
Proof. unfold Equation1925. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa285_inst, refa285_op in H. discriminate H. Qed.

Lemma refa285_not1931 : ~ @Equation1931 Fin3 refa285_inst.
Proof. unfold Equation1931. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa285_inst, refa285_op in H. discriminate H. Qed.

Lemma refa285_not2036 : ~ @Equation2036 Fin3 refa285_inst.
Proof. unfold Equation2036. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa285_inst, refa285_op in H. discriminate H. Qed.

Lemma refa285_not2037 : ~ @Equation2037 Fin3 refa285_inst.
Proof. unfold Equation2037. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa285_inst, refa285_op in H. discriminate H. Qed.

Lemma refa285_not2038 : ~ @Equation2038 Fin3 refa285_inst.
Proof. unfold Equation2038. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa285_inst, refa285_op in H. discriminate H. Qed.

Lemma refa285_not2040 : ~ @Equation2040 Fin3 refa285_inst.
Proof. unfold Equation2040. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa285_inst, refa285_op in H. discriminate H. Qed.

Lemma refa285_not2041 : ~ @Equation2041 Fin3 refa285_inst.
Proof. unfold Equation2041. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa285_inst, refa285_op in H. discriminate H. Qed.

Lemma refa285_not2043 : ~ @Equation2043 Fin3 refa285_inst.
Proof. unfold Equation2043. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa285_inst, refa285_op in H. discriminate H. Qed.

Lemma refa285_not2050 : ~ @Equation2050 Fin3 refa285_inst.
Proof. unfold Equation2050. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa285_inst, refa285_op in H. discriminate H. Qed.

Lemma refa285_not2054 : ~ @Equation2054 Fin3 refa285_inst.
Proof. unfold Equation2054. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa285_inst, refa285_op in H. discriminate H. Qed.

Lemma refa285_not2061 : ~ @Equation2061 Fin3 refa285_inst.
Proof. unfold Equation2061. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa285_inst, refa285_op in H. discriminate H. Qed.

Lemma refa285_not2063 : ~ @Equation2063 Fin3 refa285_inst.
Proof. unfold Equation2063. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa285_inst, refa285_op in H. discriminate H. Qed.

Lemma refa285_not2064 : ~ @Equation2064 Fin3 refa285_inst.
Proof. unfold Equation2064. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa285_inst, refa285_op in H. discriminate H. Qed.

Lemma refa285_not2087 : ~ @Equation2087 Fin3 refa285_inst.
Proof. unfold Equation2087. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa285_inst, refa285_op in H. discriminate H. Qed.

Lemma refa285_not2091 : ~ @Equation2091 Fin3 refa285_inst.
Proof. unfold Equation2091. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa285_inst, refa285_op in H. discriminate H. Qed.

Lemma refa285_not2098 : ~ @Equation2098 Fin3 refa285_inst.
Proof. unfold Equation2098. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa285_inst, refa285_op in H. discriminate H. Qed.

Lemma refa285_not2101 : ~ @Equation2101 Fin3 refa285_inst.
Proof. unfold Equation2101. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa285_inst, refa285_op in H. discriminate H. Qed.

Lemma refa285_not2124 : ~ @Equation2124 Fin3 refa285_inst.
Proof. unfold Equation2124. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa285_inst, refa285_op in H. discriminate H. Qed.

Lemma refa285_not2125 : ~ @Equation2125 Fin3 refa285_inst.
Proof. unfold Equation2125. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa285_inst, refa285_op in H. discriminate H. Qed.

Lemma refa285_not2127 : ~ @Equation2127 Fin3 refa285_inst.
Proof. unfold Equation2127. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa285_inst, refa285_op in H. discriminate H. Qed.

Lemma refa285_not2134 : ~ @Equation2134 Fin3 refa285_inst.
Proof. unfold Equation2134. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa285_inst, refa285_op in H. discriminate H. Qed.

Lemma refa285_not2240 : ~ @Equation2240 Fin3 refa285_inst.
Proof. unfold Equation2240. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa285_inst, refa285_op in H. discriminate H. Qed.

Lemma refa285_not2243 : ~ @Equation2243 Fin3 refa285_inst.
Proof. unfold Equation2243. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa285_inst, refa285_op in H. discriminate H. Qed.

Lemma refa285_not2246 : ~ @Equation2246 Fin3 refa285_inst.
Proof. unfold Equation2246. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa285_inst, refa285_op in H. discriminate H. Qed.

Lemma refa285_not2247 : ~ @Equation2247 Fin3 refa285_inst.
Proof. unfold Equation2247. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa285_inst, refa285_op in H. discriminate H. Qed.

Lemma refa285_not2253 : ~ @Equation2253 Fin3 refa285_inst.
Proof. unfold Equation2253. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa285_inst, refa285_op in H. discriminate H. Qed.

Lemma refa285_not2254 : ~ @Equation2254 Fin3 refa285_inst.
Proof. unfold Equation2254. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa285_inst, refa285_op in H. discriminate H. Qed.

Lemma refa285_not2257 : ~ @Equation2257 Fin3 refa285_inst.
Proof. unfold Equation2257. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa285_inst, refa285_op in H. discriminate H. Qed.

Lemma refa285_not2264 : ~ @Equation2264 Fin3 refa285_inst.
Proof. unfold Equation2264. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa285_inst, refa285_op in H. discriminate H. Qed.

Lemma refa285_not2266 : ~ @Equation2266 Fin3 refa285_inst.
Proof. unfold Equation2266. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa285_inst, refa285_op in H. discriminate H. Qed.

Lemma refa285_not2290 : ~ @Equation2290 Fin3 refa285_inst.
Proof. unfold Equation2290. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa285_inst, refa285_op in H. discriminate H. Qed.

Lemma refa285_not2293 : ~ @Equation2293 Fin3 refa285_inst.
Proof. unfold Equation2293. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa285_inst, refa285_op in H. discriminate H. Qed.

Lemma refa285_not2294 : ~ @Equation2294 Fin3 refa285_inst.
Proof. unfold Equation2294. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa285_inst, refa285_op in H. discriminate H. Qed.

Lemma refa285_not2300 : ~ @Equation2300 Fin3 refa285_inst.
Proof. unfold Equation2300. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa285_inst, refa285_op in H. discriminate H. Qed.

Lemma refa285_not2328 : ~ @Equation2328 Fin3 refa285_inst.
Proof. unfold Equation2328. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa285_inst, refa285_op in H. discriminate H. Qed.

Lemma refa285_not2330 : ~ @Equation2330 Fin3 refa285_inst.
Proof. unfold Equation2330. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa285_inst, refa285_op in H. discriminate H. Qed.

Lemma refa285_not2337 : ~ @Equation2337 Fin3 refa285_inst.
Proof. unfold Equation2337. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa285_inst, refa285_op in H. discriminate H. Qed.

Lemma refa285_not2340 : ~ @Equation2340 Fin3 refa285_inst.
Proof. unfold Equation2340. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa285_inst, refa285_op in H. discriminate H. Qed.

Lemma refa285_not2443 : ~ @Equation2443 Fin3 refa285_inst.
Proof. unfold Equation2443. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa285_inst, refa285_op in H. discriminate H. Qed.

Lemma refa285_not2444 : ~ @Equation2444 Fin3 refa285_inst.
Proof. unfold Equation2444. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa285_inst, refa285_op in H. discriminate H. Qed.

Lemma refa285_not2446 : ~ @Equation2446 Fin3 refa285_inst.
Proof. unfold Equation2446. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa285_inst, refa285_op in H. discriminate H. Qed.

Lemma refa285_not2450 : ~ @Equation2450 Fin3 refa285_inst.
Proof. unfold Equation2450. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa285_inst, refa285_op in H. discriminate H. Qed.

Lemma refa285_not2456 : ~ @Equation2456 Fin3 refa285_inst.
Proof. unfold Equation2456. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa285_inst, refa285_op in H. discriminate H. Qed.

Lemma refa285_not2460 : ~ @Equation2460 Fin3 refa285_inst.
Proof. unfold Equation2460. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa285_inst, refa285_op in H. discriminate H. Qed.

Lemma refa285_not2466 : ~ @Equation2466 Fin3 refa285_inst.
Proof. unfold Equation2466. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa285_inst, refa285_op in H. discriminate H. Qed.

Lemma refa285_not2467 : ~ @Equation2467 Fin3 refa285_inst.
Proof. unfold Equation2467. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa285_inst, refa285_op in H. discriminate H. Qed.

Lemma refa285_not2469 : ~ @Equation2469 Fin3 refa285_inst.
Proof. unfold Equation2469. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa285_inst, refa285_op in H. discriminate H. Qed.

Lemma refa285_not2493 : ~ @Equation2493 Fin3 refa285_inst.
Proof. unfold Equation2493. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa285_inst, refa285_op in H. discriminate H. Qed.

Lemma refa285_not2497 : ~ @Equation2497 Fin3 refa285_inst.
Proof. unfold Equation2497. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa285_inst, refa285_op in H. discriminate H. Qed.

Lemma refa285_not2503 : ~ @Equation2503 Fin3 refa285_inst.
Proof. unfold Equation2503. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa285_inst, refa285_op in H. discriminate H. Qed.

Lemma refa285_not2506 : ~ @Equation2506 Fin3 refa285_inst.
Proof. unfold Equation2506. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa285_inst, refa285_op in H. discriminate H. Qed.

Lemma refa285_not2530 : ~ @Equation2530 Fin3 refa285_inst.
Proof. unfold Equation2530. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa285_inst, refa285_op in H. discriminate H. Qed.

Lemma refa285_not2531 : ~ @Equation2531 Fin3 refa285_inst.
Proof. unfold Equation2531. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa285_inst, refa285_op in H. discriminate H. Qed.

Lemma refa285_not2533 : ~ @Equation2533 Fin3 refa285_inst.
Proof. unfold Equation2533. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa285_inst, refa285_op in H. discriminate H. Qed.

Lemma refa285_not2541 : ~ @Equation2541 Fin3 refa285_inst.
Proof. unfold Equation2541. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa285_inst, refa285_op in H. discriminate H. Qed.

Lemma refa285_not2543 : ~ @Equation2543 Fin3 refa285_inst.
Proof. unfold Equation2543. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa285_inst, refa285_op in H. discriminate H. Qed.

Lemma refa285_not2646 : ~ @Equation2646 Fin3 refa285_inst.
Proof. unfold Equation2646. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa285_inst, refa285_op in H. discriminate H. Qed.

Lemma refa285_not2647 : ~ @Equation2647 Fin3 refa285_inst.
Proof. unfold Equation2647. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa285_inst, refa285_op in H. discriminate H. Qed.

Lemma refa285_not2649 : ~ @Equation2649 Fin3 refa285_inst.
Proof. unfold Equation2649. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa285_inst, refa285_op in H. discriminate H. Qed.

Lemma refa285_not2650 : ~ @Equation2650 Fin3 refa285_inst.
Proof. unfold Equation2650. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa285_inst, refa285_op in H. discriminate H. Qed.

Lemma refa285_not2652 : ~ @Equation2652 Fin3 refa285_inst.
Proof. unfold Equation2652. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa285_inst, refa285_op in H. discriminate H. Qed.

Lemma refa285_not2659 : ~ @Equation2659 Fin3 refa285_inst.
Proof. unfold Equation2659. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa285_inst, refa285_op in H. discriminate H. Qed.

Lemma refa285_not2660 : ~ @Equation2660 Fin3 refa285_inst.
Proof. unfold Equation2660. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa285_inst, refa285_op in H. discriminate H. Qed.

Lemma refa285_not2662 : ~ @Equation2662 Fin3 refa285_inst.
Proof. unfold Equation2662. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa285_inst, refa285_op in H. discriminate H. Qed.

Lemma refa285_not2669 : ~ @Equation2669 Fin3 refa285_inst.
Proof. unfold Equation2669. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa285_inst, refa285_op in H. discriminate H. Qed.

Lemma refa285_not2696 : ~ @Equation2696 Fin3 refa285_inst.
Proof. unfold Equation2696. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa285_inst, refa285_op in H. discriminate H. Qed.

Lemma refa285_not2697 : ~ @Equation2697 Fin3 refa285_inst.
Proof. unfold Equation2697. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa285_inst, refa285_op in H. discriminate H. Qed.

Lemma refa285_not2699 : ~ @Equation2699 Fin3 refa285_inst.
Proof. unfold Equation2699. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa285_inst, refa285_op in H. discriminate H. Qed.

Lemma refa285_not2706 : ~ @Equation2706 Fin3 refa285_inst.
Proof. unfold Equation2706. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa285_inst, refa285_op in H. discriminate H. Qed.

Lemma refa285_not2710 : ~ @Equation2710 Fin3 refa285_inst.
Proof. unfold Equation2710. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa285_inst, refa285_op in H. discriminate H. Qed.

Lemma refa285_not2733 : ~ @Equation2733 Fin3 refa285_inst.
Proof. unfold Equation2733. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa285_inst, refa285_op in H. discriminate H. Qed.

Lemma refa285_not2744 : ~ @Equation2744 Fin3 refa285_inst.
Proof. unfold Equation2744. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa285_inst, refa285_op in H. discriminate H. Qed.

Lemma refa285_not2746 : ~ @Equation2746 Fin3 refa285_inst.
Proof. unfold Equation2746. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa285_inst, refa285_op in H. discriminate H. Qed.

Lemma refa285_not2849 : ~ @Equation2849 Fin3 refa285_inst.
Proof. unfold Equation2849. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa285_inst, refa285_op in H. discriminate H. Qed.

Lemma refa285_not2852 : ~ @Equation2852 Fin3 refa285_inst.
Proof. unfold Equation2852. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa285_inst, refa285_op in H. discriminate H. Qed.

Lemma refa285_not2855 : ~ @Equation2855 Fin3 refa285_inst.
Proof. unfold Equation2855. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa285_inst, refa285_op in H. discriminate H. Qed.

Lemma refa285_not2856 : ~ @Equation2856 Fin3 refa285_inst.
Proof. unfold Equation2856. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa285_inst, refa285_op in H. discriminate H. Qed.

Lemma refa285_not2862 : ~ @Equation2862 Fin3 refa285_inst.
Proof. unfold Equation2862. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa285_inst, refa285_op in H. discriminate H. Qed.

Lemma refa285_not2865 : ~ @Equation2865 Fin3 refa285_inst.
Proof. unfold Equation2865. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa285_inst, refa285_op in H. discriminate H. Qed.

Lemma refa285_not2866 : ~ @Equation2866 Fin3 refa285_inst.
Proof. unfold Equation2866. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa285_inst, refa285_op in H. discriminate H. Qed.

Lemma refa285_not2872 : ~ @Equation2872 Fin3 refa285_inst.
Proof. unfold Equation2872. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa285_inst, refa285_op in H. discriminate H. Qed.

Lemma refa285_not2873 : ~ @Equation2873 Fin3 refa285_inst.
Proof. unfold Equation2873. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa285_inst, refa285_op in H. discriminate H. Qed.

Lemma refa285_not2899 : ~ @Equation2899 Fin3 refa285_inst.
Proof. unfold Equation2899. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa285_inst, refa285_op in H. discriminate H. Qed.

Lemma refa285_not2900 : ~ @Equation2900 Fin3 refa285_inst.
Proof. unfold Equation2900. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa285_inst, refa285_op in H. discriminate H. Qed.

Lemma refa285_not2903 : ~ @Equation2903 Fin3 refa285_inst.
Proof. unfold Equation2903. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa285_inst, refa285_op in H. discriminate H. Qed.

Lemma refa285_not2910 : ~ @Equation2910 Fin3 refa285_inst.
Proof. unfold Equation2910. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa285_inst, refa285_op in H. discriminate H. Qed.

Lemma refa285_not2912 : ~ @Equation2912 Fin3 refa285_inst.
Proof. unfold Equation2912. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa285_inst, refa285_op in H. discriminate H. Qed.

Lemma refa285_not2937 : ~ @Equation2937 Fin3 refa285_inst.
Proof. unfold Equation2937. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa285_inst, refa285_op in H. discriminate H. Qed.

Lemma refa285_not2939 : ~ @Equation2939 Fin3 refa285_inst.
Proof. unfold Equation2939. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa285_inst, refa285_op in H. discriminate H. Qed.

Lemma refa285_not2946 : ~ @Equation2946 Fin3 refa285_inst.
Proof. unfold Equation2946. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa285_inst, refa285_op in H. discriminate H. Qed.

Lemma refa285_not2949 : ~ @Equation2949 Fin3 refa285_inst.
Proof. unfold Equation2949. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa285_inst, refa285_op in H. discriminate H. Qed.

Lemma refa285_not3052 : ~ @Equation3052 Fin3 refa285_inst.
Proof. unfold Equation3052. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa285_inst, refa285_op in H. discriminate H. Qed.

Lemma refa285_not3055 : ~ @Equation3055 Fin3 refa285_inst.
Proof. unfold Equation3055. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa285_inst, refa285_op in H. discriminate H. Qed.

Lemma refa285_not3056 : ~ @Equation3056 Fin3 refa285_inst.
Proof. unfold Equation3056. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa285_inst, refa285_op in H. discriminate H. Qed.

Lemma refa285_not3065 : ~ @Equation3065 Fin3 refa285_inst.
Proof. unfold Equation3065. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa285_inst, refa285_op in H. discriminate H. Qed.

Lemma refa285_not3068 : ~ @Equation3068 Fin3 refa285_inst.
Proof. unfold Equation3068. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa285_inst, refa285_op in H. discriminate H. Qed.

Lemma refa285_not3069 : ~ @Equation3069 Fin3 refa285_inst.
Proof. unfold Equation3069. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa285_inst, refa285_op in H. discriminate H. Qed.

Lemma refa285_not3076 : ~ @Equation3076 Fin3 refa285_inst.
Proof. unfold Equation3076. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa285_inst, refa285_op in H. discriminate H. Qed.

Lemma refa285_not3078 : ~ @Equation3078 Fin3 refa285_inst.
Proof. unfold Equation3078. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa285_inst, refa285_op in H. discriminate H. Qed.

Lemma refa285_not3102 : ~ @Equation3102 Fin3 refa285_inst.
Proof. unfold Equation3102. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa285_inst, refa285_op in H. discriminate H. Qed.

Lemma refa285_not3105 : ~ @Equation3105 Fin3 refa285_inst.
Proof. unfold Equation3105. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa285_inst, refa285_op in H. discriminate H. Qed.

Lemma refa285_not3106 : ~ @Equation3106 Fin3 refa285_inst.
Proof. unfold Equation3106. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa285_inst, refa285_op in H. discriminate H. Qed.

Lemma refa285_not3113 : ~ @Equation3113 Fin3 refa285_inst.
Proof. unfold Equation3113. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa285_inst, refa285_op in H. discriminate H. Qed.

Lemma refa285_not3115 : ~ @Equation3115 Fin3 refa285_inst.
Proof. unfold Equation3115. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa285_inst, refa285_op in H. discriminate H. Qed.

Lemma refa285_not3139 : ~ @Equation3139 Fin3 refa285_inst.
Proof. unfold Equation3139. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa285_inst, refa285_op in H. discriminate H. Qed.

Lemma refa285_not3140 : ~ @Equation3140 Fin3 refa285_inst.
Proof. unfold Equation3140. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa285_inst, refa285_op in H. discriminate H. Qed.

Lemma refa285_not3143 : ~ @Equation3143 Fin3 refa285_inst.
Proof. unfold Equation3143. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa285_inst, refa285_op in H. discriminate H. Qed.

Lemma refa285_not3149 : ~ @Equation3149 Fin3 refa285_inst.
Proof. unfold Equation3149. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa285_inst, refa285_op in H. discriminate H. Qed.

Lemma refa285_not3152 : ~ @Equation3152 Fin3 refa285_inst.
Proof. unfold Equation3152. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa285_inst, refa285_op in H. discriminate H. Qed.

Lemma refa285_not3254 : ~ @Equation3254 Fin3 refa285_inst.
Proof. unfold Equation3254. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa285_inst, refa285_op in H. discriminate H. Qed.

Lemma refa285_not3255 : ~ @Equation3255 Fin3 refa285_inst.
Proof. unfold Equation3255. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa285_inst, refa285_op in H. discriminate H. Qed.

Lemma refa285_not3256 : ~ @Equation3256 Fin3 refa285_inst.
Proof. unfold Equation3256. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa285_inst, refa285_op in H. discriminate H. Qed.

Lemma refa285_not3258 : ~ @Equation3258 Fin3 refa285_inst.
Proof. unfold Equation3258. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa285_inst, refa285_op in H. discriminate H. Qed.

Lemma refa285_not3262 : ~ @Equation3262 Fin3 refa285_inst.
Proof. unfold Equation3262. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa285_inst, refa285_op in H. discriminate H. Qed.

Lemma refa285_not3268 : ~ @Equation3268 Fin3 refa285_inst.
Proof. unfold Equation3268. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa285_inst, refa285_op in H. discriminate H. Qed.

Lemma refa285_not3269 : ~ @Equation3269 Fin3 refa285_inst.
Proof. unfold Equation3269. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa285_inst, refa285_op in H. discriminate H. Qed.

Lemma refa285_not3271 : ~ @Equation3271 Fin3 refa285_inst.
Proof. unfold Equation3271. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa285_inst, refa285_op in H. discriminate H. Qed.

Lemma refa285_not3279 : ~ @Equation3279 Fin3 refa285_inst.
Proof. unfold Equation3279. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa285_inst, refa285_op in H. discriminate H. Qed.

Lemma refa285_not3281 : ~ @Equation3281 Fin3 refa285_inst.
Proof. unfold Equation3281. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa285_inst, refa285_op in H. discriminate H. Qed.

Lemma refa285_not3309 : ~ @Equation3309 Fin3 refa285_inst.
Proof. unfold Equation3309. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa285_inst, refa285_op in H. discriminate H. Qed.

Lemma refa285_not3315 : ~ @Equation3315 Fin3 refa285_inst.
Proof. unfold Equation3315. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa285_inst, refa285_op in H. discriminate H. Qed.

Lemma refa285_not3316 : ~ @Equation3316 Fin3 refa285_inst.
Proof. unfold Equation3316. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa285_inst, refa285_op in H. discriminate H. Qed.

Lemma refa285_not3318 : ~ @Equation3318 Fin3 refa285_inst.
Proof. unfold Equation3318. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa285_inst, refa285_op in H. discriminate H. Qed.

Lemma refa285_not3343 : ~ @Equation3343 Fin3 refa285_inst.
Proof. unfold Equation3343. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa285_inst, refa285_op in H. discriminate H. Qed.

Lemma refa285_not3346 : ~ @Equation3346 Fin3 refa285_inst.
Proof. unfold Equation3346. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa285_inst, refa285_op in H. discriminate H. Qed.

Lemma refa285_not3352 : ~ @Equation3352 Fin3 refa285_inst.
Proof. unfold Equation3352. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa285_inst, refa285_op in H. discriminate H. Qed.

Lemma refa285_not3457 : ~ @Equation3457 Fin3 refa285_inst.
Proof. unfold Equation3457. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa285_inst, refa285_op in H. discriminate H. Qed.

Lemma refa285_not3458 : ~ @Equation3458 Fin3 refa285_inst.
Proof. unfold Equation3458. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa285_inst, refa285_op in H. discriminate H. Qed.

Lemma refa285_not3461 : ~ @Equation3461 Fin3 refa285_inst.
Proof. unfold Equation3461. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa285_inst, refa285_op in H. discriminate H. Qed.

Lemma refa285_not3464 : ~ @Equation3464 Fin3 refa285_inst.
Proof. unfold Equation3464. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa285_inst, refa285_op in H. discriminate H. Qed.

Lemma refa285_not3465 : ~ @Equation3465 Fin3 refa285_inst.
Proof. unfold Equation3465. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa285_inst, refa285_op in H. discriminate H. Qed.

Lemma refa285_not3475 : ~ @Equation3475 Fin3 refa285_inst.
Proof. unfold Equation3475. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa285_inst, refa285_op in H. discriminate H. Qed.

Lemma refa285_not3481 : ~ @Equation3481 Fin3 refa285_inst.
Proof. unfold Equation3481. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa285_inst, refa285_op in H. discriminate H. Qed.

Lemma refa285_not3482 : ~ @Equation3482 Fin3 refa285_inst.
Proof. unfold Equation3482. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa285_inst, refa285_op in H. discriminate H. Qed.

Lemma refa285_not3509 : ~ @Equation3509 Fin3 refa285_inst.
Proof. unfold Equation3509. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa285_inst, refa285_op in H. discriminate H. Qed.

Lemma refa285_not3512 : ~ @Equation3512 Fin3 refa285_inst.
Proof. unfold Equation3512. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa285_inst, refa285_op in H. discriminate H. Qed.

Lemma refa285_not3519 : ~ @Equation3519 Fin3 refa285_inst.
Proof. unfold Equation3519. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa285_inst, refa285_op in H. discriminate H. Qed.

Lemma refa285_not3521 : ~ @Equation3521 Fin3 refa285_inst.
Proof. unfold Equation3521. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa285_inst, refa285_op in H. discriminate H. Qed.

Lemma refa285_not3546 : ~ @Equation3546 Fin3 refa285_inst.
Proof. unfold Equation3546. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa285_inst, refa285_op in H. discriminate H. Qed.

Lemma refa285_not3555 : ~ @Equation3555 Fin3 refa285_inst.
Proof. unfold Equation3555. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa285_inst, refa285_op in H. discriminate H. Qed.

Lemma refa285_not3558 : ~ @Equation3558 Fin3 refa285_inst.
Proof. unfold Equation3558. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa285_inst, refa285_op in H. discriminate H. Qed.

Lemma refa285_not3660 : ~ @Equation3660 Fin3 refa285_inst.
Proof. unfold Equation3660. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa285_inst, refa285_op in H. discriminate H. Qed.

Lemma refa285_not3661 : ~ @Equation3661 Fin3 refa285_inst.
Proof. unfold Equation3661. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa285_inst, refa285_op in H. discriminate H. Qed.

Lemma refa285_not3662 : ~ @Equation3662 Fin3 refa285_inst.
Proof. unfold Equation3662. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa285_inst, refa285_op in H. discriminate H. Qed.

Lemma refa285_not3664 : ~ @Equation3664 Fin3 refa285_inst.
Proof. unfold Equation3664. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa285_inst, refa285_op in H. discriminate H. Qed.

Lemma refa285_not3665 : ~ @Equation3665 Fin3 refa285_inst.
Proof. unfold Equation3665. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa285_inst, refa285_op in H. discriminate H. Qed.

Lemma refa285_not3667 : ~ @Equation3667 Fin3 refa285_inst.
Proof. unfold Equation3667. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa285_inst, refa285_op in H. discriminate H. Qed.

Lemma refa285_not3674 : ~ @Equation3674 Fin3 refa285_inst.
Proof. unfold Equation3674. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa285_inst, refa285_op in H. discriminate H. Qed.

Lemma refa285_not3675 : ~ @Equation3675 Fin3 refa285_inst.
Proof. unfold Equation3675. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa285_inst, refa285_op in H. discriminate H. Qed.

Lemma refa285_not3677 : ~ @Equation3677 Fin3 refa285_inst.
Proof. unfold Equation3677. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa285_inst, refa285_op in H. discriminate H. Qed.

Lemma refa285_not3684 : ~ @Equation3684 Fin3 refa285_inst.
Proof. unfold Equation3684. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa285_inst, refa285_op in H. discriminate H. Qed.

Lemma refa285_not3712 : ~ @Equation3712 Fin3 refa285_inst.
Proof. unfold Equation3712. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa285_inst, refa285_op in H. discriminate H. Qed.

Lemma refa285_not3714 : ~ @Equation3714 Fin3 refa285_inst.
Proof. unfold Equation3714. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa285_inst, refa285_op in H. discriminate H. Qed.

Lemma refa285_not3721 : ~ @Equation3721 Fin3 refa285_inst.
Proof. unfold Equation3721. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa285_inst, refa285_op in H. discriminate H. Qed.

Lemma refa285_not3725 : ~ @Equation3725 Fin3 refa285_inst.
Proof. unfold Equation3725. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa285_inst, refa285_op in H. discriminate H. Qed.

Lemma refa285_not3748 : ~ @Equation3748 Fin3 refa285_inst.
Proof. unfold Equation3748. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa285_inst, refa285_op in H. discriminate H. Qed.

Lemma refa285_not3752 : ~ @Equation3752 Fin3 refa285_inst.
Proof. unfold Equation3752. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa285_inst, refa285_op in H. discriminate H. Qed.

Lemma refa285_not3759 : ~ @Equation3759 Fin3 refa285_inst.
Proof. unfold Equation3759. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa285_inst, refa285_op in H. discriminate H. Qed.

Lemma refa285_not3761 : ~ @Equation3761 Fin3 refa285_inst.
Proof. unfold Equation3761. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa285_inst, refa285_op in H. discriminate H. Qed.

Lemma refa285_not3864 : ~ @Equation3864 Fin3 refa285_inst.
Proof. unfold Equation3864. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa285_inst, refa285_op in H. discriminate H. Qed.

Lemma refa285_not3865 : ~ @Equation3865 Fin3 refa285_inst.
Proof. unfold Equation3865. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa285_inst, refa285_op in H. discriminate H. Qed.

Lemma refa285_not3867 : ~ @Equation3867 Fin3 refa285_inst.
Proof. unfold Equation3867. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa285_inst, refa285_op in H. discriminate H. Qed.

Lemma refa285_not3868 : ~ @Equation3868 Fin3 refa285_inst.
Proof. unfold Equation3868. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa285_inst, refa285_op in H. discriminate H. Qed.

Lemma refa285_not3870 : ~ @Equation3870 Fin3 refa285_inst.
Proof. unfold Equation3870. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa285_inst, refa285_op in H. discriminate H. Qed.

Lemma refa285_not3877 : ~ @Equation3877 Fin3 refa285_inst.
Proof. unfold Equation3877. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa285_inst, refa285_op in H. discriminate H. Qed.

Lemma refa285_not3881 : ~ @Equation3881 Fin3 refa285_inst.
Proof. unfold Equation3881. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa285_inst, refa285_op in H. discriminate H. Qed.

Lemma refa285_not3888 : ~ @Equation3888 Fin3 refa285_inst.
Proof. unfold Equation3888. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa285_inst, refa285_op in H. discriminate H. Qed.

Lemma refa285_not3890 : ~ @Equation3890 Fin3 refa285_inst.
Proof. unfold Equation3890. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa285_inst, refa285_op in H. discriminate H. Qed.

Lemma refa285_not3918 : ~ @Equation3918 Fin3 refa285_inst.
Proof. unfold Equation3918. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa285_inst, refa285_op in H. discriminate H. Qed.

Lemma refa285_not3925 : ~ @Equation3925 Fin3 refa285_inst.
Proof. unfold Equation3925. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa285_inst, refa285_op in H. discriminate H. Qed.

Lemma refa285_not3927 : ~ @Equation3927 Fin3 refa285_inst.
Proof. unfold Equation3927. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa285_inst, refa285_op in H. discriminate H. Qed.

Lemma refa285_not3928 : ~ @Equation3928 Fin3 refa285_inst.
Proof. unfold Equation3928. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa285_inst, refa285_op in H. discriminate H. Qed.

Lemma refa285_not3951 : ~ @Equation3951 Fin3 refa285_inst.
Proof. unfold Equation3951. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa285_inst, refa285_op in H. discriminate H. Qed.

Lemma refa285_not3952 : ~ @Equation3952 Fin3 refa285_inst.
Proof. unfold Equation3952. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa285_inst, refa285_op in H. discriminate H. Qed.

Lemma refa285_not3954 : ~ @Equation3954 Fin3 refa285_inst.
Proof. unfold Equation3954. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa285_inst, refa285_op in H. discriminate H. Qed.

Lemma refa285_not3961 : ~ @Equation3961 Fin3 refa285_inst.
Proof. unfold Equation3961. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa285_inst, refa285_op in H. discriminate H. Qed.

Lemma refa285_not4066 : ~ @Equation4066 Fin3 refa285_inst.
Proof. unfold Equation4066. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa285_inst, refa285_op in H. discriminate H. Qed.

Lemma refa285_not4067 : ~ @Equation4067 Fin3 refa285_inst.
Proof. unfold Equation4067. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa285_inst, refa285_op in H. discriminate H. Qed.

Lemma refa285_not4070 : ~ @Equation4070 Fin3 refa285_inst.
Proof. unfold Equation4070. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa285_inst, refa285_op in H. discriminate H. Qed.

Lemma refa285_not4074 : ~ @Equation4074 Fin3 refa285_inst.
Proof. unfold Equation4074. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa285_inst, refa285_op in H. discriminate H. Qed.

Lemma refa285_not4080 : ~ @Equation4080 Fin3 refa285_inst.
Proof. unfold Equation4080. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa285_inst, refa285_op in H. discriminate H. Qed.

Lemma refa285_not4081 : ~ @Equation4081 Fin3 refa285_inst.
Proof. unfold Equation4081. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa285_inst, refa285_op in H. discriminate H. Qed.

Lemma refa285_not4084 : ~ @Equation4084 Fin3 refa285_inst.
Proof. unfold Equation4084. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa285_inst, refa285_op in H. discriminate H. Qed.

Lemma refa285_not4090 : ~ @Equation4090 Fin3 refa285_inst.
Proof. unfold Equation4090. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa285_inst, refa285_op in H. discriminate H. Qed.

Lemma refa285_not4093 : ~ @Equation4093 Fin3 refa285_inst.
Proof. unfold Equation4093. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa285_inst, refa285_op in H. discriminate H. Qed.

Lemma refa285_not4120 : ~ @Equation4120 Fin3 refa285_inst.
Proof. unfold Equation4120. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa285_inst, refa285_op in H. discriminate H. Qed.

Lemma refa285_not4121 : ~ @Equation4121 Fin3 refa285_inst.
Proof. unfold Equation4121. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa285_inst, refa285_op in H. discriminate H. Qed.

Lemma refa285_not4128 : ~ @Equation4128 Fin3 refa285_inst.
Proof. unfold Equation4128. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa285_inst, refa285_op in H. discriminate H. Qed.

Lemma refa285_not4130 : ~ @Equation4130 Fin3 refa285_inst.
Proof. unfold Equation4130. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa285_inst, refa285_op in H. discriminate H. Qed.

Lemma refa285_not4155 : ~ @Equation4155 Fin3 refa285_inst.
Proof. unfold Equation4155. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa285_inst, refa285_op in H. discriminate H. Qed.

Lemma refa285_not4157 : ~ @Equation4157 Fin3 refa285_inst.
Proof. unfold Equation4157. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa285_inst, refa285_op in H. discriminate H. Qed.

Lemma refa285_not4164 : ~ @Equation4164 Fin3 refa285_inst.
Proof. unfold Equation4164. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa285_inst, refa285_op in H. discriminate H. Qed.

Lemma refa285_not4165 : ~ @Equation4165 Fin3 refa285_inst.
Proof. unfold Equation4165. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa285_inst, refa285_op in H. discriminate H. Qed.

Lemma refa285_not4268 : ~ @Equation4268 Fin3 refa285_inst.
Proof. unfold Equation4268. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa285_inst, refa285_op in H. discriminate H. Qed.

Lemma refa285_not4269 : ~ @Equation4269 Fin3 refa285_inst.
Proof. unfold Equation4269. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa285_inst, refa285_op in H. discriminate H. Qed.

Lemma refa285_not4270 : ~ @Equation4270 Fin3 refa285_inst.
Proof. unfold Equation4270. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa285_inst, refa285_op in H. discriminate H. Qed.

Lemma refa285_not4272 : ~ @Equation4272 Fin3 refa285_inst.
Proof. unfold Equation4272. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa285_inst, refa285_op in H. discriminate H. Qed.

Lemma refa285_not4276 : ~ @Equation4276 Fin3 refa285_inst.
Proof. unfold Equation4276. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa285_inst, refa285_op in H. discriminate H. Qed.

Lemma refa285_not4284 : ~ @Equation4284 Fin3 refa285_inst.
Proof. unfold Equation4284. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa285_inst, refa285_op in H. discriminate H. Qed.

Lemma refa285_not4290 : ~ @Equation4290 Fin3 refa285_inst.
Proof. unfold Equation4290. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa285_inst, refa285_op in H. discriminate H. Qed.

Lemma refa285_not4291 : ~ @Equation4291 Fin3 refa285_inst.
Proof. unfold Equation4291. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa285_inst, refa285_op in H. discriminate H. Qed.

Lemma refa285_not4293 : ~ @Equation4293 Fin3 refa285_inst.
Proof. unfold Equation4293. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa285_inst, refa285_op in H. discriminate H. Qed.

Lemma refa285_not4314 : ~ @Equation4314 Fin3 refa285_inst.
Proof. unfold Equation4314. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa285_inst, refa285_op in H. discriminate H. Qed.

Lemma refa285_not4320 : ~ @Equation4320 Fin3 refa285_inst.
Proof. unfold Equation4320. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa285_inst, refa285_op in H. discriminate H. Qed.

Lemma refa285_not4321 : ~ @Equation4321 Fin3 refa285_inst.
Proof. unfold Equation4321. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa285_inst, refa285_op in H. discriminate H. Qed.

Lemma refa285_not4396 : ~ @Equation4396 Fin3 refa285_inst.
Proof. unfold Equation4396. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa285_inst, refa285_op in H. discriminate H. Qed.

Lemma refa285_not4399 : ~ @Equation4399 Fin3 refa285_inst.
Proof. unfold Equation4399. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa285_inst, refa285_op in H. discriminate H. Qed.

Lemma refa285_not4406 : ~ @Equation4406 Fin3 refa285_inst.
Proof. unfold Equation4406. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa285_inst, refa285_op in H. discriminate H. Qed.

Lemma refa285_not4408 : ~ @Equation4408 Fin3 refa285_inst.
Proof. unfold Equation4408. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa285_inst, refa285_op in H. discriminate H. Qed.

Lemma refa285_not4433 : ~ @Equation4433 Fin3 refa285_inst.
Proof. unfold Equation4433. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa285_inst, refa285_op in H. discriminate H. Qed.

Lemma refa285_not4436 : ~ @Equation4436 Fin3 refa285_inst.
Proof. unfold Equation4436. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa285_inst, refa285_op in H. discriminate H. Qed.

Lemma refa285_not4443 : ~ @Equation4443 Fin3 refa285_inst.
Proof. unfold Equation4443. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa285_inst, refa285_op in H. discriminate H. Qed.

Lemma refa285_not4445 : ~ @Equation4445 Fin3 refa285_inst.
Proof. unfold Equation4445. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa285_inst, refa285_op in H. discriminate H. Qed.

Lemma refa285_not4472 : ~ @Equation4472 Fin3 refa285_inst.
Proof. unfold Equation4472. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa285_inst, refa285_op in H. discriminate H. Qed.

Lemma refa285_not4473 : ~ @Equation4473 Fin3 refa285_inst.
Proof. unfold Equation4473. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa285_inst, refa285_op in H. discriminate H. Qed.

Lemma refa285_not4479 : ~ @Equation4479 Fin3 refa285_inst.
Proof. unfold Equation4479. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa285_inst, refa285_op in H. discriminate H. Qed.

Lemma refa285_not4480 : ~ @Equation4480 Fin3 refa285_inst.
Proof. unfold Equation4480. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa285_inst, refa285_op in H. discriminate H. Qed.

Lemma refa285_not4583 : ~ @Equation4583 Fin3 refa285_inst.
Proof. unfold Equation4583. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa285_inst, refa285_op in H. discriminate H. Qed.

Lemma refa285_not4584 : ~ @Equation4584 Fin3 refa285_inst.
Proof. unfold Equation4584. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa285_inst, refa285_op in H. discriminate H. Qed.

Lemma refa285_not4587 : ~ @Equation4587 Fin3 refa285_inst.
Proof. unfold Equation4587. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa285_inst, refa285_op in H. discriminate H. Qed.

Lemma refa285_not4590 : ~ @Equation4590 Fin3 refa285_inst.
Proof. unfold Equation4590. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa285_inst, refa285_op in H. discriminate H. Qed.

Lemma refa285_not4591 : ~ @Equation4591 Fin3 refa285_inst.
Proof. unfold Equation4591. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa285_inst, refa285_op in H. discriminate H. Qed.

Lemma refa285_not4598 : ~ @Equation4598 Fin3 refa285_inst.
Proof. unfold Equation4598. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa285_inst, refa285_op in H. discriminate H. Qed.

Lemma refa285_not4599 : ~ @Equation4599 Fin3 refa285_inst.
Proof. unfold Equation4599. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa285_inst, refa285_op in H. discriminate H. Qed.

Lemma refa285_not4605 : ~ @Equation4605 Fin3 refa285_inst.
Proof. unfold Equation4605. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa285_inst, refa285_op in H. discriminate H. Qed.

Lemma refa285_not4606 : ~ @Equation4606 Fin3 refa285_inst.
Proof. unfold Equation4606. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa285_inst, refa285_op in H. discriminate H. Qed.

Lemma refa285_not4629 : ~ @Equation4629 Fin3 refa285_inst.
Proof. unfold Equation4629. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa285_inst, refa285_op in H. discriminate H. Qed.

Lemma refa285_not4636 : ~ @Equation4636 Fin3 refa285_inst.
Proof. unfold Equation4636. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa285_inst, refa285_op in H. discriminate H. Qed.

Lemma refa285_not4658 : ~ @Equation4658 Fin3 refa285_inst.
Proof. unfold Equation4658. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa285_inst, refa285_op in H. discriminate H. Qed.

(** ---- refa286 (Fin3) ---- *)

Definition refa286_op (x y : Fin3) : Fin3 :=
  match x, y with
  | F3_0, F3_0 => F3_0 | F3_0, F3_1 => F3_1 | F3_0, F3_2 => F3_1
  | F3_1, F3_0 => F3_0 | F3_1, F3_1 => F3_1 | F3_1, F3_2 => F3_2
  | F3_2, F3_0 => F3_2 | F3_2, F3_1 => F3_1 | F3_2, F3_2 => F3_1
  end.

#[local] Instance refa286_inst : Magma Fin3 := {| magma_op := refa286_op |}.

Lemma refa286_sat2314 : @Equation2314 Fin3 refa286_inst.
Proof. unfold Equation2314, magma_op, refa286_inst, refa286_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa286_sat2368 : @Equation2368 Fin3 refa286_inst.
Proof. unfold Equation2368, magma_op, refa286_inst, refa286_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa286_not211 : ~ @Equation211 Fin3 refa286_inst.
Proof. unfold Equation211. intro H. specialize (H F3_2 F3_0). unfold magma_op, refa286_inst, refa286_op in H. discriminate H. Qed.

Lemma refa286_not2266 : ~ @Equation2266 Fin3 refa286_inst.
Proof. unfold Equation2266. intro H. specialize (H F3_2 F3_0). unfold magma_op, refa286_inst, refa286_op in H. discriminate H. Qed.

Lemma refa286_not2290 : ~ @Equation2290 Fin3 refa286_inst.
Proof. unfold Equation2290. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa286_inst, refa286_op in H. discriminate H. Qed.

Lemma refa286_not2459 : ~ @Equation2459 Fin3 refa286_inst.
Proof. unfold Equation2459. intro H. specialize (H F3_2 F3_0). unfold magma_op, refa286_inst, refa286_op in H. discriminate H. Qed.

(** ---- refa287 (Fin3) ---- *)

Definition refa287_op (x y : Fin3) : Fin3 :=
  match x, y with
  | F3_0, F3_0 => F3_0 | F3_0, F3_1 => F3_1 | F3_0, F3_2 => F3_2
  | F3_1, F3_0 => F3_0 | F3_1, F3_1 => F3_1 | F3_1, F3_2 => F3_2
  | F3_2, F3_0 => F3_1 | F3_2, F3_1 => F3_0 | F3_2, F3_2 => F3_2
  end.

#[local] Instance refa287_inst : Magma Fin3 := {| magma_op := refa287_op |}.

Lemma refa287_sat690 : @Equation690 Fin3 refa287_inst.
Proof. unfold Equation690, magma_op, refa287_inst, refa287_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa287_sat947 : @Equation947 Fin3 refa287_inst.
Proof. unfold Equation947, magma_op, refa287_inst, refa287_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa287_sat1560 : @Equation1560 Fin3 refa287_inst.
Proof. unfold Equation1560, magma_op, refa287_inst, refa287_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa287_sat1586 : @Equation1586 Fin3 refa287_inst.
Proof. unfold Equation1586, magma_op, refa287_inst, refa287_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa287_sat1797 : @Equation1797 Fin3 refa287_inst.
Proof. unfold Equation1797, magma_op, refa287_inst, refa287_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa287_sat2078 : @Equation2078 Fin3 refa287_inst.
Proof. unfold Equation2078, magma_op, refa287_inst, refa287_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa287_sat2415 : @Equation2415 Fin3 refa287_inst.
Proof. unfold Equation2415, magma_op, refa287_inst, refa287_op. intros x y z w. destruct x, y, z, w; reflexivity. Qed.

Lemma refa287_sat3495 : @Equation3495 Fin3 refa287_inst.
Proof. unfold Equation3495, magma_op, refa287_inst, refa287_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa287_sat3566 : @Equation3566 Fin3 refa287_inst.
Proof. unfold Equation3566, magma_op, refa287_inst, refa287_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa287_sat3702 : @Equation3702 Fin3 refa287_inst.
Proof. unfold Equation3702, magma_op, refa287_inst, refa287_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa287_sat3790 : @Equation3790 Fin3 refa287_inst.
Proof. unfold Equation3790, magma_op, refa287_inst, refa287_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa287_sat4420 : @Equation4420 Fin3 refa287_inst.
Proof. unfold Equation4420, magma_op, refa287_inst, refa287_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa287_not75 : ~ @Equation75 Fin3 refa287_inst.
Proof. unfold Equation75. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa287_inst, refa287_op in H. discriminate H. Qed.

Lemma refa287_not107 : ~ @Equation107 Fin3 refa287_inst.
Proof. unfold Equation107. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa287_inst, refa287_op in H. discriminate H. Qed.

Lemma refa287_not124 : ~ @Equation124 Fin3 refa287_inst.
Proof. unfold Equation124. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa287_inst, refa287_op in H. discriminate H. Qed.

Lemma refa287_not323 : ~ @Equation323 Fin3 refa287_inst.
Proof. unfold Equation323. intro H. specialize (H F3_2 F3_0). unfold magma_op, refa287_inst, refa287_op in H. discriminate H. Qed.

Lemma refa287_not413 : ~ @Equation413 Fin3 refa287_inst.
Proof. unfold Equation413. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa287_inst, refa287_op in H. discriminate H. Qed.

Lemma refa287_not416 : ~ @Equation416 Fin3 refa287_inst.
Proof. unfold Equation416. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa287_inst, refa287_op in H. discriminate H. Qed.

Lemma refa287_not426 : ~ @Equation426 Fin3 refa287_inst.
Proof. unfold Equation426. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa287_inst, refa287_op in H. discriminate H. Qed.

Lemma refa287_not439 : ~ @Equation439 Fin3 refa287_inst.
Proof. unfold Equation439. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa287_inst, refa287_op in H. discriminate H. Qed.

Lemma refa287_not476 : ~ @Equation476 Fin3 refa287_inst.
Proof. unfold Equation476. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa287_inst, refa287_op in H. discriminate H. Qed.

Lemma refa287_not503 : ~ @Equation503 Fin3 refa287_inst.
Proof. unfold Equation503. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa287_inst, refa287_op in H. discriminate H. Qed.

Lemma refa287_not616 : ~ @Equation616 Fin3 refa287_inst.
Proof. unfold Equation616. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa287_inst, refa287_op in H. discriminate H. Qed.

Lemma refa287_not622 : ~ @Equation622 Fin3 refa287_inst.
Proof. unfold Equation622. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa287_inst, refa287_op in H. discriminate H. Qed.

Lemma refa287_not629 : ~ @Equation629 Fin3 refa287_inst.
Proof. unfold Equation629. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa287_inst, refa287_op in H. discriminate H. Qed.

Lemma refa287_not639 : ~ @Equation639 Fin3 refa287_inst.
Proof. unfold Equation639. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa287_inst, refa287_op in H. discriminate H. Qed.

Lemma refa287_not676 : ~ @Equation676 Fin3 refa287_inst.
Proof. unfold Equation676. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa287_inst, refa287_op in H. discriminate H. Qed.

Lemma refa287_not706 : ~ @Equation706 Fin3 refa287_inst.
Proof. unfold Equation706. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa287_inst, refa287_op in H. discriminate H. Qed.

Lemma refa287_not716 : ~ @Equation716 Fin3 refa287_inst.
Proof. unfold Equation716. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa287_inst, refa287_op in H. discriminate H. Qed.

Lemma refa287_not819 : ~ @Equation819 Fin3 refa287_inst.
Proof. unfold Equation819. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa287_inst, refa287_op in H. discriminate H. Qed.

Lemma refa287_not822 : ~ @Equation822 Fin3 refa287_inst.
Proof. unfold Equation822. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa287_inst, refa287_op in H. discriminate H. Qed.

Lemma refa287_not835 : ~ @Equation835 Fin3 refa287_inst.
Proof. unfold Equation835. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa287_inst, refa287_op in H. discriminate H. Qed.

Lemma refa287_not842 : ~ @Equation842 Fin3 refa287_inst.
Proof. unfold Equation842. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa287_inst, refa287_op in H. discriminate H. Qed.

Lemma refa287_not882 : ~ @Equation882 Fin3 refa287_inst.
Proof. unfold Equation882. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa287_inst, refa287_op in H. discriminate H. Qed.

Lemma refa287_not906 : ~ @Equation906 Fin3 refa287_inst.
Proof. unfold Equation906. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa287_inst, refa287_op in H. discriminate H. Qed.

Lemma refa287_not1022 : ~ @Equation1022 Fin3 refa287_inst.
Proof. unfold Equation1022. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa287_inst, refa287_op in H. discriminate H. Qed.

Lemma refa287_not1028 : ~ @Equation1028 Fin3 refa287_inst.
Proof. unfold Equation1028. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa287_inst, refa287_op in H. discriminate H. Qed.

Lemma refa287_not1038 : ~ @Equation1038 Fin3 refa287_inst.
Proof. unfold Equation1038. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa287_inst, refa287_op in H. discriminate H. Qed.

Lemma refa287_not1048 : ~ @Equation1048 Fin3 refa287_inst.
Proof. unfold Equation1048. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa287_inst, refa287_op in H. discriminate H. Qed.

Lemma refa287_not1082 : ~ @Equation1082 Fin3 refa287_inst.
Proof. unfold Equation1082. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa287_inst, refa287_op in H. discriminate H. Qed.

Lemma refa287_not1109 : ~ @Equation1109 Fin3 refa287_inst.
Proof. unfold Equation1109. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa287_inst, refa287_op in H. discriminate H. Qed.

Lemma refa287_not1119 : ~ @Equation1119 Fin3 refa287_inst.
Proof. unfold Equation1119. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa287_inst, refa287_op in H. discriminate H. Qed.

Lemma refa287_not1225 : ~ @Equation1225 Fin3 refa287_inst.
Proof. unfold Equation1225. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa287_inst, refa287_op in H. discriminate H. Qed.

Lemma refa287_not1231 : ~ @Equation1231 Fin3 refa287_inst.
Proof. unfold Equation1231. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa287_inst, refa287_op in H. discriminate H. Qed.

Lemma refa287_not1241 : ~ @Equation1241 Fin3 refa287_inst.
Proof. unfold Equation1241. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa287_inst, refa287_op in H. discriminate H. Qed.

Lemma refa287_not1251 : ~ @Equation1251 Fin3 refa287_inst.
Proof. unfold Equation1251. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa287_inst, refa287_op in H. discriminate H. Qed.

Lemma refa287_not1285 : ~ @Equation1285 Fin3 refa287_inst.
Proof. unfold Equation1285. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa287_inst, refa287_op in H. discriminate H. Qed.

Lemma refa287_not1312 : ~ @Equation1312 Fin3 refa287_inst.
Proof. unfold Equation1312. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa287_inst, refa287_op in H. discriminate H. Qed.

Lemma refa287_not1322 : ~ @Equation1322 Fin3 refa287_inst.
Proof. unfold Equation1322. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa287_inst, refa287_op in H. discriminate H. Qed.

Lemma refa287_not1428 : ~ @Equation1428 Fin3 refa287_inst.
Proof. unfold Equation1428. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa287_inst, refa287_op in H. discriminate H. Qed.

Lemma refa287_not1431 : ~ @Equation1431 Fin3 refa287_inst.
Proof. unfold Equation1431. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa287_inst, refa287_op in H. discriminate H. Qed.

Lemma refa287_not1441 : ~ @Equation1441 Fin3 refa287_inst.
Proof. unfold Equation1441. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa287_inst, refa287_op in H. discriminate H. Qed.

Lemma refa287_not1454 : ~ @Equation1454 Fin3 refa287_inst.
Proof. unfold Equation1454. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa287_inst, refa287_op in H. discriminate H. Qed.

Lemma refa287_not1488 : ~ @Equation1488 Fin3 refa287_inst.
Proof. unfold Equation1488. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa287_inst, refa287_op in H. discriminate H. Qed.

Lemma refa287_not1515 : ~ @Equation1515 Fin3 refa287_inst.
Proof. unfold Equation1515. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa287_inst, refa287_op in H. discriminate H. Qed.

Lemma refa287_not1631 : ~ @Equation1631 Fin3 refa287_inst.
Proof. unfold Equation1631. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa287_inst, refa287_op in H. discriminate H. Qed.

Lemma refa287_not1637 : ~ @Equation1637 Fin3 refa287_inst.
Proof. unfold Equation1637. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa287_inst, refa287_op in H. discriminate H. Qed.

Lemma refa287_not1644 : ~ @Equation1644 Fin3 refa287_inst.
Proof. unfold Equation1644. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa287_inst, refa287_op in H. discriminate H. Qed.

Lemma refa287_not1654 : ~ @Equation1654 Fin3 refa287_inst.
Proof. unfold Equation1654. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa287_inst, refa287_op in H. discriminate H. Qed.

Lemma refa287_not1684 : ~ @Equation1684 Fin3 refa287_inst.
Proof. unfold Equation1684. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa287_inst, refa287_op in H. discriminate H. Qed.

Lemma refa287_not1694 : ~ @Equation1694 Fin3 refa287_inst.
Proof. unfold Equation1694. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa287_inst, refa287_op in H. discriminate H. Qed.

Lemma refa287_not1728 : ~ @Equation1728 Fin3 refa287_inst.
Proof. unfold Equation1728. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa287_inst, refa287_op in H. discriminate H. Qed.

Lemma refa287_not1834 : ~ @Equation1834 Fin3 refa287_inst.
Proof. unfold Equation1834. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa287_inst, refa287_op in H. discriminate H. Qed.

Lemma refa287_not1837 : ~ @Equation1837 Fin3 refa287_inst.
Proof. unfold Equation1837. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa287_inst, refa287_op in H. discriminate H. Qed.

Lemma refa287_not1857 : ~ @Equation1857 Fin3 refa287_inst.
Proof. unfold Equation1857. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa287_inst, refa287_op in H. discriminate H. Qed.

Lemma refa287_not1887 : ~ @Equation1887 Fin3 refa287_inst.
Proof. unfold Equation1887. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa287_inst, refa287_op in H. discriminate H. Qed.

Lemma refa287_not1894 : ~ @Equation1894 Fin3 refa287_inst.
Proof. unfold Equation1894. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa287_inst, refa287_op in H. discriminate H. Qed.

Lemma refa287_not1924 : ~ @Equation1924 Fin3 refa287_inst.
Proof. unfold Equation1924. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa287_inst, refa287_op in H. discriminate H. Qed.

Lemma refa287_not1931 : ~ @Equation1931 Fin3 refa287_inst.
Proof. unfold Equation1931. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa287_inst, refa287_op in H. discriminate H. Qed.

Lemma refa287_not2037 : ~ @Equation2037 Fin3 refa287_inst.
Proof. unfold Equation2037. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa287_inst, refa287_op in H. discriminate H. Qed.

Lemma refa287_not2040 : ~ @Equation2040 Fin3 refa287_inst.
Proof. unfold Equation2040. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa287_inst, refa287_op in H. discriminate H. Qed.

Lemma refa287_not2053 : ~ @Equation2053 Fin3 refa287_inst.
Proof. unfold Equation2053. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa287_inst, refa287_op in H. discriminate H. Qed.

Lemma refa287_not2060 : ~ @Equation2060 Fin3 refa287_inst.
Proof. unfold Equation2060. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa287_inst, refa287_op in H. discriminate H. Qed.

Lemma refa287_not2097 : ~ @Equation2097 Fin3 refa287_inst.
Proof. unfold Equation2097. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa287_inst, refa287_op in H. discriminate H. Qed.

Lemma refa287_not2127 : ~ @Equation2127 Fin3 refa287_inst.
Proof. unfold Equation2127. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa287_inst, refa287_op in H. discriminate H. Qed.

Lemma refa287_not2134 : ~ @Equation2134 Fin3 refa287_inst.
Proof. unfold Equation2134. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa287_inst, refa287_op in H. discriminate H. Qed.

Lemma refa287_not3255 : ~ @Equation3255 Fin3 refa287_inst.
Proof. unfold Equation3255. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa287_inst, refa287_op in H. discriminate H. Qed.

Lemma refa287_not3258 : ~ @Equation3258 Fin3 refa287_inst.
Proof. unfold Equation3258. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa287_inst, refa287_op in H. discriminate H. Qed.

Lemma refa287_not3268 : ~ @Equation3268 Fin3 refa287_inst.
Proof. unfold Equation3268. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa287_inst, refa287_op in H. discriminate H. Qed.

Lemma refa287_not3281 : ~ @Equation3281 Fin3 refa287_inst.
Proof. unfold Equation3281. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa287_inst, refa287_op in H. discriminate H. Qed.

Lemma refa287_not3309 : ~ @Equation3309 Fin3 refa287_inst.
Proof. unfold Equation3309. intro H. specialize (H F3_2 F3_0). unfold magma_op, refa287_inst, refa287_op in H. discriminate H. Qed.

Lemma refa287_not3316 : ~ @Equation3316 Fin3 refa287_inst.
Proof. unfold Equation3316. intro H. specialize (H F3_2 F3_0). unfold magma_op, refa287_inst, refa287_op in H. discriminate H. Qed.

Lemma refa287_not3343 : ~ @Equation3343 Fin3 refa287_inst.
Proof. unfold Equation3343. intro H. specialize (H F3_2 F3_0). unfold magma_op, refa287_inst, refa287_op in H. discriminate H. Qed.

Lemma refa287_not3458 : ~ @Equation3458 Fin3 refa287_inst.
Proof. unfold Equation3458. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa287_inst, refa287_op in H. discriminate H. Qed.

Lemma refa287_not3464 : ~ @Equation3464 Fin3 refa287_inst.
Proof. unfold Equation3464. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa287_inst, refa287_op in H. discriminate H. Qed.

Lemma refa287_not3481 : ~ @Equation3481 Fin3 refa287_inst.
Proof. unfold Equation3481. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa287_inst, refa287_op in H. discriminate H. Qed.

Lemma refa287_not3509 : ~ @Equation3509 Fin3 refa287_inst.
Proof. unfold Equation3509. intro H. specialize (H F3_2 F3_0). unfold magma_op, refa287_inst, refa287_op in H. discriminate H. Qed.

Lemma refa287_not3519 : ~ @Equation3519 Fin3 refa287_inst.
Proof. unfold Equation3519. intro H. specialize (H F3_2 F3_0). unfold magma_op, refa287_inst, refa287_op in H. discriminate H. Qed.

Lemma refa287_not3661 : ~ @Equation3661 Fin3 refa287_inst.
Proof. unfold Equation3661. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa287_inst, refa287_op in H. discriminate H. Qed.

Lemma refa287_not3664 : ~ @Equation3664 Fin3 refa287_inst.
Proof. unfold Equation3664. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa287_inst, refa287_op in H. discriminate H. Qed.

Lemma refa287_not3677 : ~ @Equation3677 Fin3 refa287_inst.
Proof. unfold Equation3677. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa287_inst, refa287_op in H. discriminate H. Qed.

Lemma refa287_not3684 : ~ @Equation3684 Fin3 refa287_inst.
Proof. unfold Equation3684. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa287_inst, refa287_op in H. discriminate H. Qed.

Lemma refa287_not3712 : ~ @Equation3712 Fin3 refa287_inst.
Proof. unfold Equation3712. intro H. specialize (H F3_2 F3_0). unfold magma_op, refa287_inst, refa287_op in H. discriminate H. Qed.

Lemma refa287_not3725 : ~ @Equation3725 Fin3 refa287_inst.
Proof. unfold Equation3725. intro H. specialize (H F3_2 F3_0). unfold magma_op, refa287_inst, refa287_op in H. discriminate H. Qed.

Lemma refa287_not3749 : ~ @Equation3749 Fin3 refa287_inst.
Proof. unfold Equation3749. intro H. specialize (H F3_2 F3_0). unfold magma_op, refa287_inst, refa287_op in H. discriminate H. Qed.

Lemma refa287_not3864 : ~ @Equation3864 Fin3 refa287_inst.
Proof. unfold Equation3864. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa287_inst, refa287_op in H. discriminate H. Qed.

Lemma refa287_not3870 : ~ @Equation3870 Fin3 refa287_inst.
Proof. unfold Equation3870. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa287_inst, refa287_op in H. discriminate H. Qed.

Lemma refa287_not3880 : ~ @Equation3880 Fin3 refa287_inst.
Proof. unfold Equation3880. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa287_inst, refa287_op in H. discriminate H. Qed.

Lemma refa287_not3890 : ~ @Equation3890 Fin3 refa287_inst.
Proof. unfold Equation3890. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa287_inst, refa287_op in H. discriminate H. Qed.

Lemma refa287_not3918 : ~ @Equation3918 Fin3 refa287_inst.
Proof. unfold Equation3918. intro H. specialize (H F3_2 F3_0). unfold magma_op, refa287_inst, refa287_op in H. discriminate H. Qed.

Lemma refa287_not3928 : ~ @Equation3928 Fin3 refa287_inst.
Proof. unfold Equation3928. intro H. specialize (H F3_2 F3_0). unfold magma_op, refa287_inst, refa287_op in H. discriminate H. Qed.

Lemma refa287_not3955 : ~ @Equation3955 Fin3 refa287_inst.
Proof. unfold Equation3955. intro H. specialize (H F3_2 F3_0). unfold magma_op, refa287_inst, refa287_op in H. discriminate H. Qed.

Lemma refa287_not4067 : ~ @Equation4067 Fin3 refa287_inst.
Proof. unfold Equation4067. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa287_inst, refa287_op in H. discriminate H. Qed.

Lemma refa287_not4073 : ~ @Equation4073 Fin3 refa287_inst.
Proof. unfold Equation4073. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa287_inst, refa287_op in H. discriminate H. Qed.

Lemma refa287_not4083 : ~ @Equation4083 Fin3 refa287_inst.
Proof. unfold Equation4083. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa287_inst, refa287_op in H. discriminate H. Qed.

Lemma refa287_not4093 : ~ @Equation4093 Fin3 refa287_inst.
Proof. unfold Equation4093. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa287_inst, refa287_op in H. discriminate H. Qed.

Lemma refa287_not4121 : ~ @Equation4121 Fin3 refa287_inst.
Proof. unfold Equation4121. intro H. specialize (H F3_2 F3_0). unfold magma_op, refa287_inst, refa287_op in H. discriminate H. Qed.

Lemma refa287_not4131 : ~ @Equation4131 Fin3 refa287_inst.
Proof. unfold Equation4131. intro H. specialize (H F3_2 F3_0). unfold magma_op, refa287_inst, refa287_op in H. discriminate H. Qed.

Lemma refa287_not4158 : ~ @Equation4158 Fin3 refa287_inst.
Proof. unfold Equation4158. intro H. specialize (H F3_2 F3_0). unfold magma_op, refa287_inst, refa287_op in H. discriminate H. Qed.

Lemma refa287_not4269 : ~ @Equation4269 Fin3 refa287_inst.
Proof. unfold Equation4269. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa287_inst, refa287_op in H. discriminate H. Qed.

Lemma refa287_not4272 : ~ @Equation4272 Fin3 refa287_inst.
Proof. unfold Equation4272. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa287_inst, refa287_op in H. discriminate H. Qed.

Lemma refa287_not4284 : ~ @Equation4284 Fin3 refa287_inst.
Proof. unfold Equation4284. intro H. specialize (H F3_2 F3_0). unfold magma_op, refa287_inst, refa287_op in H. discriminate H. Qed.

Lemma refa287_not4291 : ~ @Equation4291 Fin3 refa287_inst.
Proof. unfold Equation4291. intro H. specialize (H F3_2 F3_0). unfold magma_op, refa287_inst, refa287_op in H. discriminate H. Qed.

Lemma refa287_not4396 : ~ @Equation4396 Fin3 refa287_inst.
Proof. unfold Equation4396. intro H. specialize (H F3_2 F3_0). unfold magma_op, refa287_inst, refa287_op in H. discriminate H. Qed.

Lemma refa287_not4406 : ~ @Equation4406 Fin3 refa287_inst.
Proof. unfold Equation4406. intro H. specialize (H F3_2 F3_0). unfold magma_op, refa287_inst, refa287_op in H. discriminate H. Qed.

Lemma refa287_not4584 : ~ @Equation4584 Fin3 refa287_inst.
Proof. unfold Equation4584. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa287_inst, refa287_op in H. discriminate H. Qed.

Lemma refa287_not4590 : ~ @Equation4590 Fin3 refa287_inst.
Proof. unfold Equation4590. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa287_inst, refa287_op in H. discriminate H. Qed.

Lemma refa287_not4599 : ~ @Equation4599 Fin3 refa287_inst.
Proof. unfold Equation4599. intro H. specialize (H F3_2 F3_0). unfold magma_op, refa287_inst, refa287_op in H. discriminate H. Qed.

Lemma refa287_not4635 : ~ @Equation4635 Fin3 refa287_inst.
Proof. unfold Equation4635. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa287_inst, refa287_op in H. discriminate H. Qed.

(** ---- refa288 (Fin3) ---- *)

Definition refa288_op (x y : Fin3) : Fin3 :=
  match x, y with
  | F3_0, F3_0 => F3_1 | F3_0, F3_1 => F3_0 | F3_0, F3_2 => F3_0
  | F3_1, F3_0 => F3_1 | F3_1, F3_1 => F3_0 | F3_1, F3_2 => F3_0
  | F3_2, F3_0 => F3_2 | F3_2, F3_1 => F3_0 | F3_2, F3_2 => F3_0
  end.

#[local] Instance refa288_inst : Magma Fin3 := {| magma_op := refa288_op |}.

Lemma refa288_sat458 : @Equation458 Fin3 refa288_inst.
Proof. unfold Equation458, magma_op, refa288_inst, refa288_op. intros x y z w. destruct x, y, z, w; reflexivity. Qed.

Lemma refa288_not1629 : ~ @Equation1629 Fin3 refa288_inst.
Proof. unfold Equation1629. intro H. specialize (H F3_2). unfold magma_op, refa288_inst, refa288_op in H. discriminate H. Qed.

Lemma refa288_not1840 : ~ @Equation1840 Fin3 refa288_inst.
Proof. unfold Equation1840. intro H. specialize (H F3_2 F3_0). unfold magma_op, refa288_inst, refa288_op in H. discriminate H. Qed.

Lemma refa288_not2035 : ~ @Equation2035 Fin3 refa288_inst.
Proof. unfold Equation2035. intro H. specialize (H F3_2). unfold magma_op, refa288_inst, refa288_op in H. discriminate H. Qed.

Lemma refa288_not4118 : ~ @Equation4118 Fin3 refa288_inst.
Proof. unfold Equation4118. intro H. specialize (H F3_2 F3_0). unfold magma_op, refa288_inst, refa288_op in H. discriminate H. Qed.

Lemma refa288_not4121 : ~ @Equation4121 Fin3 refa288_inst.
Proof. unfold Equation4121. intro H. specialize (H F3_2 F3_0). unfold magma_op, refa288_inst, refa288_op in H. discriminate H. Qed.

Lemma refa288_not4128 : ~ @Equation4128 Fin3 refa288_inst.
Proof. unfold Equation4128. intro H. specialize (H F3_2 F3_0). unfold magma_op, refa288_inst, refa288_op in H. discriminate H. Qed.

Lemma refa288_not4599 : ~ @Equation4599 Fin3 refa288_inst.
Proof. unfold Equation4599. intro H. specialize (H F3_2 F3_0). unfold magma_op, refa288_inst, refa288_op in H. discriminate H. Qed.

(** ---- refa289 (Fin3) ---- *)

Definition refa289_op (x y : Fin3) : Fin3 :=
  match x, y with
  | F3_0, F3_0 => F3_0 | F3_0, F3_1 => F3_0 | F3_0, F3_2 => F3_0
  | F3_1, F3_0 => F3_0 | F3_1, F3_1 => F3_0 | F3_1, F3_2 => F3_1
  | F3_2, F3_0 => F3_0 | F3_2, F3_1 => F3_2 | F3_2, F3_2 => F3_0
  end.

#[local] Instance refa289_inst : Magma Fin3 := {| magma_op := refa289_op |}.

Lemma refa289_sat325 : @Equation325 Fin3 refa289_inst.
Proof. unfold Equation325, magma_op, refa289_inst, refa289_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa289_sat3483 : @Equation3483 Fin3 refa289_inst.
Proof. unfold Equation3483, magma_op, refa289_inst, refa289_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa289_sat3493 : @Equation3493 Fin3 refa289_inst.
Proof. unfold Equation3493, magma_op, refa289_inst, refa289_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa289_sat3885 : @Equation3885 Fin3 refa289_inst.
Proof. unfold Equation3885, magma_op, refa289_inst, refa289_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa289_sat3889 : @Equation3889 Fin3 refa289_inst.
Proof. unfold Equation3889, magma_op, refa289_inst, refa289_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa289_sat4410 : @Equation4410 Fin3 refa289_inst.
Proof. unfold Equation4410, magma_op, refa289_inst, refa289_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa289_sat4417 : @Equation4417 Fin3 refa289_inst.
Proof. unfold Equation4417, magma_op, refa289_inst, refa289_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa289_sat4495 : @Equation4495 Fin3 refa289_inst.
Proof. unfold Equation4495, magma_op, refa289_inst, refa289_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa289_sat4616 : @Equation4616 Fin3 refa289_inst.
Proof. unfold Equation4616, magma_op, refa289_inst, refa289_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa289_not3259 : ~ @Equation3259 Fin3 refa289_inst.
Proof. unfold Equation3259. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa289_inst, refa289_op in H. discriminate H. Qed.

Lemma refa289_not3271 : ~ @Equation3271 Fin3 refa289_inst.
Proof. unfold Equation3271. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa289_inst, refa289_op in H. discriminate H. Qed.

Lemma refa289_not3318 : ~ @Equation3318 Fin3 refa289_inst.
Proof. unfold Equation3318. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa289_inst, refa289_op in H. discriminate H. Qed.

Lemma refa289_not3461 : ~ @Equation3461 Fin3 refa289_inst.
Proof. unfold Equation3461. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa289_inst, refa289_op in H. discriminate H. Qed.

Lemma refa289_not3475 : ~ @Equation3475 Fin3 refa289_inst.
Proof. unfold Equation3475. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa289_inst, refa289_op in H. discriminate H. Qed.

Lemma refa289_not3519 : ~ @Equation3519 Fin3 refa289_inst.
Proof. unfold Equation3519. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa289_inst, refa289_op in H. discriminate H. Qed.

Lemma refa289_not3667 : ~ @Equation3667 Fin3 refa289_inst.
Proof. unfold Equation3667. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa289_inst, refa289_op in H. discriminate H. Qed.

Lemma refa289_not3675 : ~ @Equation3675 Fin3 refa289_inst.
Proof. unfold Equation3675. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa289_inst, refa289_op in H. discriminate H. Qed.

Lemma refa289_not3868 : ~ @Equation3868 Fin3 refa289_inst.
Proof. unfold Equation3868. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa289_inst, refa289_op in H. discriminate H. Qed.

Lemma refa289_not3880 : ~ @Equation3880 Fin3 refa289_inst.
Proof. unfold Equation3880. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa289_inst, refa289_op in H. discriminate H. Qed.

Lemma refa289_not4269 : ~ @Equation4269 Fin3 refa289_inst.
Proof. unfold Equation4269. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa289_inst, refa289_op in H. discriminate H. Qed.

Lemma refa289_not4273 : ~ @Equation4273 Fin3 refa289_inst.
Proof. unfold Equation4273. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa289_inst, refa289_op in H. discriminate H. Qed.

Lemma refa289_not4283 : ~ @Equation4283 Fin3 refa289_inst.
Proof. unfold Equation4283. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa289_inst, refa289_op in H. discriminate H. Qed.

Lemma refa289_not4291 : ~ @Equation4291 Fin3 refa289_inst.
Proof. unfold Equation4291. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa289_inst, refa289_op in H. discriminate H. Qed.

Lemma refa289_not4314 : ~ @Equation4314 Fin3 refa289_inst.
Proof. unfold Equation4314. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa289_inst, refa289_op in H. discriminate H. Qed.

Lemma refa289_not4320 : ~ @Equation4320 Fin3 refa289_inst.
Proof. unfold Equation4320. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa289_inst, refa289_op in H. discriminate H. Qed.

Lemma refa289_not4321 : ~ @Equation4321 Fin3 refa289_inst.
Proof. unfold Equation4321. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa289_inst, refa289_op in H. discriminate H. Qed.

Lemma refa289_not4433 : ~ @Equation4433 Fin3 refa289_inst.
Proof. unfold Equation4433. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa289_inst, refa289_op in H. discriminate H. Qed.

Lemma refa289_not4435 : ~ @Equation4435 Fin3 refa289_inst.
Proof. unfold Equation4435. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa289_inst, refa289_op in H. discriminate H. Qed.

Lemma refa289_not4443 : ~ @Equation4443 Fin3 refa289_inst.
Proof. unfold Equation4443. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa289_inst, refa289_op in H. discriminate H. Qed.

Lemma refa289_not4445 : ~ @Equation4445 Fin3 refa289_inst.
Proof. unfold Equation4445. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa289_inst, refa289_op in H. discriminate H. Qed.

Lemma refa289_not4629 : ~ @Equation4629 Fin3 refa289_inst.
Proof. unfold Equation4629. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa289_inst, refa289_op in H. discriminate H. Qed.

(** ---- refa29 (Fin9) ---- *)

Definition refa29_op (x y : Fin9) : Fin9 :=
  match x, y with
  | F9_0, F9_0 => F9_1 | F9_0, F9_1 => F9_2 | F9_0, F9_2 => F9_3 | F9_0, F9_3 => F9_4 | F9_0, F9_4 => F9_5 | F9_0, F9_5 => F9_0 | F9_0, F9_6 => F9_6 | F9_0, F9_7 => F9_8 | F9_0, F9_8 => F9_7
  | F9_1, F9_0 => F9_4 | F9_1, F9_1 => F9_6 | F9_1, F9_2 => F9_2 | F9_1, F9_3 => F9_7 | F9_1, F9_4 => F9_0 | F9_1, F9_5 => F9_8 | F9_1, F9_6 => F9_5 | F9_1, F9_7 => F9_1 | F9_1, F9_8 => F9_3
  | F9_2, F9_0 => F9_3 | F9_2, F9_1 => F9_0 | F9_2, F9_2 => F9_5 | F9_2, F9_3 => F9_2 | F9_2, F9_4 => F9_1 | F9_2, F9_5 => F9_4 | F9_2, F9_6 => F9_8 | F9_2, F9_7 => F9_7 | F9_2, F9_8 => F9_6
  | F9_3, F9_0 => F9_0 | F9_3, F9_1 => F9_7 | F9_3, F9_2 => F9_4 | F9_3, F9_3 => F9_8 | F9_3, F9_4 => F9_2 | F9_3, F9_5 => F9_6 | F9_3, F9_6 => F9_3 | F9_3, F9_7 => F9_5 | F9_3, F9_8 => F9_1
  | F9_4, F9_0 => F9_5 | F9_4, F9_1 => F9_4 | F9_4, F9_2 => F9_1 | F9_4, F9_3 => F9_0 | F9_4, F9_4 => F9_3 | F9_4, F9_5 => F9_2 | F9_4, F9_6 => F9_7 | F9_4, F9_7 => F9_6 | F9_4, F9_8 => F9_8
  | F9_5, F9_0 => F9_2 | F9_5, F9_1 => F9_8 | F9_5, F9_2 => F9_0 | F9_5, F9_3 => F9_6 | F9_5, F9_4 => F9_4 | F9_5, F9_5 => F9_7 | F9_5, F9_6 => F9_1 | F9_5, F9_7 => F9_3 | F9_5, F9_8 => F9_5
  | F9_6, F9_0 => F9_8 | F9_6, F9_1 => F9_3 | F9_6, F9_2 => F9_7 | F9_6, F9_3 => F9_1 | F9_6, F9_4 => F9_6 | F9_6, F9_5 => F9_5 | F9_6, F9_6 => F9_2 | F9_6, F9_7 => F9_0 | F9_6, F9_8 => F9_4
  | F9_7, F9_0 => F9_7 | F9_7, F9_1 => F9_5 | F9_7, F9_2 => F9_6 | F9_7, F9_3 => F9_3 | F9_7, F9_4 => F9_8 | F9_7, F9_5 => F9_1 | F9_7, F9_6 => F9_0 | F9_7, F9_7 => F9_4 | F9_7, F9_8 => F9_2
  | F9_8, F9_0 => F9_6 | F9_8, F9_1 => F9_1 | F9_8, F9_2 => F9_8 | F9_8, F9_3 => F9_5 | F9_8, F9_4 => F9_7 | F9_8, F9_5 => F9_3 | F9_8, F9_6 => F9_4 | F9_8, F9_7 => F9_2 | F9_8, F9_8 => F9_0
  end.

#[local] Instance refa29_inst : Magma Fin9 := {| magma_op := refa29_op |}.

Lemma refa29_sat2979 : @Equation2979 Fin9 refa29_inst.
Proof. unfold Equation2979, magma_op, refa29_inst, refa29_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa29_not411 : ~ @Equation411 Fin9 refa29_inst.
Proof. unfold Equation411. intro H. specialize (H F9_0). unfold magma_op, refa29_inst, refa29_op in H. discriminate H. Qed.

Lemma refa29_not622 : ~ @Equation622 Fin9 refa29_inst.
Proof. unfold Equation622. intro H. specialize (H F9_0 F9_1). unfold magma_op, refa29_inst, refa29_op in H. discriminate H. Qed.

Lemma refa29_not632 : ~ @Equation632 Fin9 refa29_inst.
Proof. unfold Equation632. intro H. specialize (H F9_0 F9_1). unfold magma_op, refa29_inst, refa29_op in H. discriminate H. Qed.

Lemma refa29_not639 : ~ @Equation639 Fin9 refa29_inst.
Proof. unfold Equation639. intro H. specialize (H F9_0 F9_1). unfold magma_op, refa29_inst, refa29_op in H. discriminate H. Qed.

Lemma refa29_not643 : ~ @Equation643 Fin9 refa29_inst.
Proof. unfold Equation643. intro H. specialize (H F9_0 F9_1). unfold magma_op, refa29_inst, refa29_op in H. discriminate H. Qed.

Lemma refa29_not667 : ~ @Equation667 Fin9 refa29_inst.
Proof. unfold Equation667. intro H. specialize (H F9_0 F9_1). unfold magma_op, refa29_inst, refa29_op in H. discriminate H. Qed.

Lemma refa29_not676 : ~ @Equation676 Fin9 refa29_inst.
Proof. unfold Equation676. intro H. specialize (H F9_0 F9_1). unfold magma_op, refa29_inst, refa29_op in H. discriminate H. Qed.

Lemma refa29_not817 : ~ @Equation817 Fin9 refa29_inst.
Proof. unfold Equation817. intro H. specialize (H F9_0). unfold magma_op, refa29_inst, refa29_op in H. discriminate H. Qed.

Lemma refa29_not1020 : ~ @Equation1020 Fin9 refa29_inst.
Proof. unfold Equation1020. intro H. specialize (H F9_0). unfold magma_op, refa29_inst, refa29_op in H. discriminate H. Qed.

Lemma refa29_not1229 : ~ @Equation1229 Fin9 refa29_inst.
Proof. unfold Equation1229. intro H. specialize (H F9_0 F9_1). unfold magma_op, refa29_inst, refa29_op in H. discriminate H. Qed.

Lemma refa29_not1239 : ~ @Equation1239 Fin9 refa29_inst.
Proof. unfold Equation1239. intro H. specialize (H F9_0 F9_1). unfold magma_op, refa29_inst, refa29_op in H. discriminate H. Qed.

Lemma refa29_not1248 : ~ @Equation1248 Fin9 refa29_inst.
Proof. unfold Equation1248. intro H. specialize (H F9_0 F9_1). unfold magma_op, refa29_inst, refa29_op in H. discriminate H. Qed.

Lemma refa29_not1252 : ~ @Equation1252 Fin9 refa29_inst.
Proof. unfold Equation1252. intro H. specialize (H F9_0 F9_1). unfold magma_op, refa29_inst, refa29_op in H. discriminate H. Qed.

Lemma refa29_not1278 : ~ @Equation1278 Fin9 refa29_inst.
Proof. unfold Equation1278. intro H. specialize (H F9_0 F9_1). unfold magma_op, refa29_inst, refa29_op in H. discriminate H. Qed.

Lemma refa29_not1285 : ~ @Equation1285 Fin9 refa29_inst.
Proof. unfold Equation1285. intro H. specialize (H F9_0 F9_1). unfold magma_op, refa29_inst, refa29_op in H. discriminate H. Qed.

Lemma refa29_not1426 : ~ @Equation1426 Fin9 refa29_inst.
Proof. unfold Equation1426. intro H. specialize (H F9_0). unfold magma_op, refa29_inst, refa29_op in H. discriminate H. Qed.

Lemma refa29_not1632 : ~ @Equation1632 Fin9 refa29_inst.
Proof. unfold Equation1632. intro H. specialize (H F9_0 F9_1). unfold magma_op, refa29_inst, refa29_op in H. discriminate H. Qed.

Lemma refa29_not1637 : ~ @Equation1637 Fin9 refa29_inst.
Proof. unfold Equation1637. intro H. specialize (H F9_0 F9_1). unfold magma_op, refa29_inst, refa29_op in H. discriminate H. Qed.

Lemma refa29_not1654 : ~ @Equation1654 Fin9 refa29_inst.
Proof. unfold Equation1654. intro H. specialize (H F9_0 F9_1). unfold magma_op, refa29_inst, refa29_op in H. discriminate H. Qed.

Lemma refa29_not1691 : ~ @Equation1691 Fin9 refa29_inst.
Proof. unfold Equation1691. intro H. specialize (H F9_0 F9_1). unfold magma_op, refa29_inst, refa29_op in H. discriminate H. Qed.

Lemma refa29_not1722 : ~ @Equation1722 Fin9 refa29_inst.
Proof. unfold Equation1722. intro H. specialize (H F9_0 F9_1). unfold magma_op, refa29_inst, refa29_op in H. discriminate H. Qed.

Lemma refa29_not1731 : ~ @Equation1731 Fin9 refa29_inst.
Proof. unfold Equation1731. intro H. specialize (H F9_0 F9_1). unfold magma_op, refa29_inst, refa29_op in H. discriminate H. Qed.

Lemma refa29_not1838 : ~ @Equation1838 Fin9 refa29_inst.
Proof. unfold Equation1838. intro H. specialize (H F9_0 F9_1). unfold magma_op, refa29_inst, refa29_op in H. discriminate H. Qed.

Lemma refa29_not1840 : ~ @Equation1840 Fin9 refa29_inst.
Proof. unfold Equation1840. intro H. specialize (H F9_0 F9_1). unfold magma_op, refa29_inst, refa29_op in H. discriminate H. Qed.

Lemma refa29_not1857 : ~ @Equation1857 Fin9 refa29_inst.
Proof. unfold Equation1857. intro H. specialize (H F9_0 F9_1). unfold magma_op, refa29_inst, refa29_op in H. discriminate H. Qed.

Lemma refa29_not1861 : ~ @Equation1861 Fin9 refa29_inst.
Proof. unfold Equation1861. intro H. specialize (H F9_0 F9_1). unfold magma_op, refa29_inst, refa29_op in H. discriminate H. Qed.

Lemma refa29_not1921 : ~ @Equation1921 Fin9 refa29_inst.
Proof. unfold Equation1921. intro H. specialize (H F9_0 F9_1). unfold magma_op, refa29_inst, refa29_op in H. discriminate H. Qed.

Lemma refa29_not1925 : ~ @Equation1925 Fin9 refa29_inst.
Proof. unfold Equation1925. intro H. specialize (H F9_0 F9_1). unfold magma_op, refa29_inst, refa29_op in H. discriminate H. Qed.

Lemma refa29_not2035 : ~ @Equation2035 Fin9 refa29_inst.
Proof. unfold Equation2035. intro H. specialize (H F9_0). unfold magma_op, refa29_inst, refa29_op in H. discriminate H. Qed.

Lemma refa29_not2244 : ~ @Equation2244 Fin9 refa29_inst.
Proof. unfold Equation2244. intro H. specialize (H F9_0 F9_1). unfold magma_op, refa29_inst, refa29_op in H. discriminate H. Qed.

Lemma refa29_not2246 : ~ @Equation2246 Fin9 refa29_inst.
Proof. unfold Equation2246. intro H. specialize (H F9_0 F9_1). unfold magma_op, refa29_inst, refa29_op in H. discriminate H. Qed.

Lemma refa29_not2254 : ~ @Equation2254 Fin9 refa29_inst.
Proof. unfold Equation2254. intro H. specialize (H F9_0 F9_1). unfold magma_op, refa29_inst, refa29_op in H. discriminate H. Qed.

Lemma refa29_not2293 : ~ @Equation2293 Fin9 refa29_inst.
Proof. unfold Equation2293. intro H. specialize (H F9_0 F9_1). unfold magma_op, refa29_inst, refa29_op in H. discriminate H. Qed.

Lemma refa29_not2300 : ~ @Equation2300 Fin9 refa29_inst.
Proof. unfold Equation2300. intro H. specialize (H F9_0 F9_1). unfold magma_op, refa29_inst, refa29_op in H. discriminate H. Qed.

Lemma refa29_not2340 : ~ @Equation2340 Fin9 refa29_inst.
Proof. unfold Equation2340. intro H. specialize (H F9_0 F9_1). unfold magma_op, refa29_inst, refa29_op in H. discriminate H. Qed.

Lemma refa29_not2441 : ~ @Equation2441 Fin9 refa29_inst.
Proof. unfold Equation2441. intro H. specialize (H F9_0). unfold magma_op, refa29_inst, refa29_op in H. discriminate H. Qed.

Lemma refa29_not2644 : ~ @Equation2644 Fin9 refa29_inst.
Proof. unfold Equation2644. intro H. specialize (H F9_0). unfold magma_op, refa29_inst, refa29_op in H. discriminate H. Qed.

Lemma refa29_not2853 : ~ @Equation2853 Fin9 refa29_inst.
Proof. unfold Equation2853. intro H. specialize (H F9_0 F9_1). unfold magma_op, refa29_inst, refa29_op in H. discriminate H. Qed.

Lemma refa29_not2855 : ~ @Equation2855 Fin9 refa29_inst.
Proof. unfold Equation2855. intro H. specialize (H F9_0 F9_1). unfold magma_op, refa29_inst, refa29_op in H. discriminate H. Qed.

Lemma refa29_not2865 : ~ @Equation2865 Fin9 refa29_inst.
Proof. unfold Equation2865. intro H. specialize (H F9_0 F9_1). unfold magma_op, refa29_inst, refa29_op in H. discriminate H. Qed.

Lemma refa29_not2872 : ~ @Equation2872 Fin9 refa29_inst.
Proof. unfold Equation2872. intro H. specialize (H F9_0 F9_1). unfold magma_op, refa29_inst, refa29_op in H. discriminate H. Qed.

Lemma refa29_not2900 : ~ @Equation2900 Fin9 refa29_inst.
Proof. unfold Equation2900. intro H. specialize (H F9_0 F9_1). unfold magma_op, refa29_inst, refa29_op in H. discriminate H. Qed.

Lemma refa29_not2949 : ~ @Equation2949 Fin9 refa29_inst.
Proof. unfold Equation2949. intro H. specialize (H F9_0 F9_1). unfold magma_op, refa29_inst, refa29_op in H. discriminate H. Qed.

Lemma refa29_not3050 : ~ @Equation3050 Fin9 refa29_inst.
Proof. unfold Equation3050. intro H. specialize (H F9_0). unfold magma_op, refa29_inst, refa29_op in H. discriminate H. Qed.

Lemma refa29_not3253 : ~ @Equation3253 Fin9 refa29_inst.
Proof. unfold Equation3253. intro H. specialize (H F9_0). unfold magma_op, refa29_inst, refa29_op in H. discriminate H. Qed.

Lemma refa29_not3456 : ~ @Equation3456 Fin9 refa29_inst.
Proof. unfold Equation3456. intro H. specialize (H F9_0). unfold magma_op, refa29_inst, refa29_op in H. discriminate H. Qed.

Lemma refa29_not3659 : ~ @Equation3659 Fin9 refa29_inst.
Proof. unfold Equation3659. intro H. specialize (H F9_0). unfold magma_op, refa29_inst, refa29_op in H. discriminate H. Qed.

Lemma refa29_not3862 : ~ @Equation3862 Fin9 refa29_inst.
Proof. unfold Equation3862. intro H. specialize (H F9_0). unfold magma_op, refa29_inst, refa29_op in H. discriminate H. Qed.

Lemma refa29_not4065 : ~ @Equation4065 Fin9 refa29_inst.
Proof. unfold Equation4065. intro H. specialize (H F9_0). unfold magma_op, refa29_inst, refa29_op in H. discriminate H. Qed.

Lemma refa29_not4270 : ~ @Equation4270 Fin9 refa29_inst.
Proof. unfold Equation4270. intro H. specialize (H F9_0 F9_1). unfold magma_op, refa29_inst, refa29_op in H. discriminate H. Qed.

Lemma refa29_not4275 : ~ @Equation4275 Fin9 refa29_inst.
Proof. unfold Equation4275. intro H. specialize (H F9_0 F9_1). unfold magma_op, refa29_inst, refa29_op in H. discriminate H. Qed.

Lemma refa29_not4283 : ~ @Equation4283 Fin9 refa29_inst.
Proof. unfold Equation4283. intro H. specialize (H F9_0 F9_1). unfold magma_op, refa29_inst, refa29_op in H. discriminate H. Qed.

Lemma refa29_not4290 : ~ @Equation4290 Fin9 refa29_inst.
Proof. unfold Equation4290. intro H. specialize (H F9_0 F9_1). unfold magma_op, refa29_inst, refa29_op in H. discriminate H. Qed.

Lemma refa29_not4320 : ~ @Equation4320 Fin9 refa29_inst.
Proof. unfold Equation4320. intro H. specialize (H F9_0 F9_1). unfold magma_op, refa29_inst, refa29_op in H. discriminate H. Qed.

Lemma refa29_not4380 : ~ @Equation4380 Fin9 refa29_inst.
Proof. unfold Equation4380. intro H. specialize (H F9_0). unfold magma_op, refa29_inst, refa29_op in H. discriminate H. Qed.

Lemma refa29_not4585 : ~ @Equation4585 Fin9 refa29_inst.
Proof. unfold Equation4585. intro H. specialize (H F9_0 F9_1). unfold magma_op, refa29_inst, refa29_op in H. discriminate H. Qed.

Lemma refa29_not4590 : ~ @Equation4590 Fin9 refa29_inst.
Proof. unfold Equation4590. intro H. specialize (H F9_0 F9_1). unfold magma_op, refa29_inst, refa29_op in H. discriminate H. Qed.

Lemma refa29_not4598 : ~ @Equation4598 Fin9 refa29_inst.
Proof. unfold Equation4598. intro H. specialize (H F9_0 F9_1). unfold magma_op, refa29_inst, refa29_op in H. discriminate H. Qed.

Lemma refa29_not4605 : ~ @Equation4605 Fin9 refa29_inst.
Proof. unfold Equation4605. intro H. specialize (H F9_0 F9_1). unfold magma_op, refa29_inst, refa29_op in H. discriminate H. Qed.

Lemma refa29_not4635 : ~ @Equation4635 Fin9 refa29_inst.
Proof. unfold Equation4635. intro H. specialize (H F9_0 F9_1). unfold magma_op, refa29_inst, refa29_op in H. discriminate H. Qed.

(** ---- refa290 (Fin3) ---- *)

Definition refa290_op (x y : Fin3) : Fin3 :=
  match x, y with
  | F3_0, F3_0 => F3_0 | F3_0, F3_1 => F3_1 | F3_0, F3_2 => F3_2
  | F3_1, F3_0 => F3_0 | F3_1, F3_1 => F3_0 | F3_1, F3_2 => F3_0
  | F3_2, F3_0 => F3_0 | F3_2, F3_1 => F3_0 | F3_2, F3_2 => F3_1
  end.

#[local] Instance refa290_inst : Magma Fin3 := {| magma_op := refa290_op |}.

Lemma refa290_sat2646 : @Equation2646 Fin3 refa290_inst.
Proof. unfold Equation2646, magma_op, refa290_inst, refa290_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa290_sat2699 : @Equation2699 Fin3 refa290_inst.
Proof. unfold Equation2699, magma_op, refa290_inst, refa290_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa290_not2652 : ~ @Equation2652 Fin3 refa290_inst.
Proof. unfold Equation2652. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa290_inst, refa290_op in H. discriminate H. Qed.

Lemma refa290_not2659 : ~ @Equation2659 Fin3 refa290_inst.
Proof. unfold Equation2659. intro H. specialize (H F3_2 F3_0). unfold magma_op, refa290_inst, refa290_op in H. discriminate H. Qed.

Lemma refa290_not3253 : ~ @Equation3253 Fin3 refa290_inst.
Proof. unfold Equation3253. intro H. specialize (H F3_2). unfold magma_op, refa290_inst, refa290_op in H. discriminate H. Qed.

Lemma refa290_not3456 : ~ @Equation3456 Fin3 refa290_inst.
Proof. unfold Equation3456. intro H. specialize (H F3_2). unfold magma_op, refa290_inst, refa290_op in H. discriminate H. Qed.

Lemma refa290_not4314 : ~ @Equation4314 Fin3 refa290_inst.
Proof. unfold Equation4314. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa290_inst, refa290_op in H. discriminate H. Qed.

(** ---- refa291 (Fin3) ---- *)

Definition refa291_op (x y : Fin3) : Fin3 :=
  match x, y with
  | F3_0, F3_0 => F3_0 | F3_0, F3_1 => F3_0 | F3_0, F3_2 => F3_0
  | F3_1, F3_0 => F3_1 | F3_1, F3_1 => F3_0 | F3_1, F3_2 => F3_1
  | F3_2, F3_0 => F3_1 | F3_2, F3_1 => F3_0 | F3_2, F3_2 => F3_0
  end.

#[local] Instance refa291_inst : Magma Fin3 := {| magma_op := refa291_op |}.

Lemma refa291_sat4097 : @Equation4097 Fin3 refa291_inst.
Proof. unfold Equation4097, magma_op, refa291_inst, refa291_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa291_not4073 : ~ @Equation4073 Fin3 refa291_inst.
Proof. unfold Equation4073. intro H. specialize (H F3_2 F3_0). unfold magma_op, refa291_inst, refa291_op in H. discriminate H. Qed.

Lemma refa291_not4081 : ~ @Equation4081 Fin3 refa291_inst.
Proof. unfold Equation4081. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa291_inst, refa291_op in H. discriminate H. Qed.

(** ---- refa292 (Fin3) ---- *)

Definition refa292_op (x y : Fin3) : Fin3 :=
  match x, y with
  | F3_0, F3_0 => F3_0 | F3_0, F3_1 => F3_1 | F3_0, F3_2 => F3_1
  | F3_1, F3_0 => F3_0 | F3_1, F3_1 => F3_0 | F3_1, F3_2 => F3_1
  | F3_2, F3_0 => F3_0 | F3_2, F3_1 => F3_2 | F3_2, F3_2 => F3_1
  end.

#[local] Instance refa292_inst : Magma Fin3 := {| magma_op := refa292_op |}.

Lemma refa292_sat3268 : @Equation3268 Fin3 refa292_inst.
Proof. unfold Equation3268, magma_op, refa292_inst, refa292_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa292_not3258 : ~ @Equation3258 Fin3 refa292_inst.
Proof. unfold Equation3258. intro H. specialize (H F3_2 F3_0). unfold magma_op, refa292_inst, refa292_op in H. discriminate H. Qed.

Lemma refa292_not3261 : ~ @Equation3261 Fin3 refa292_inst.
Proof. unfold Equation3261. intro H. specialize (H F3_2 F3_0). unfold magma_op, refa292_inst, refa292_op in H. discriminate H. Qed.

Lemma refa292_not3278 : ~ @Equation3278 Fin3 refa292_inst.
Proof. unfold Equation3278. intro H. specialize (H F3_2 F3_1). unfold magma_op, refa292_inst, refa292_op in H. discriminate H. Qed.

Lemma refa292_not3306 : ~ @Equation3306 Fin3 refa292_inst.
Proof. unfold Equation3306. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa292_inst, refa292_op in H. discriminate H. Qed.

Lemma refa292_not4272 : ~ @Equation4272 Fin3 refa292_inst.
Proof. unfold Equation4272. intro H. specialize (H F3_2 F3_0). unfold magma_op, refa292_inst, refa292_op in H. discriminate H. Qed.

(** ---- refa293 (Fin3) ---- *)

Definition refa293_op (x y : Fin3) : Fin3 :=
  match x, y with
  | F3_0, F3_0 => F3_0 | F3_0, F3_1 => F3_0 | F3_0, F3_2 => F3_1
  | F3_1, F3_0 => F3_0 | F3_1, F3_1 => F3_0 | F3_1, F3_2 => F3_2
  | F3_2, F3_0 => F3_0 | F3_2, F3_1 => F3_1 | F3_2, F3_2 => F3_0
  end.

#[local] Instance refa293_inst : Magma Fin3 := {| magma_op := refa293_op |}.

Lemma refa293_sat3294 : @Equation3294 Fin3 refa293_inst.
Proof. unfold Equation3294, magma_op, refa293_inst, refa293_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa293_not3456 : ~ @Equation3456 Fin3 refa293_inst.
Proof. unfold Equation3456. intro H. specialize (H F3_2). unfold magma_op, refa293_inst, refa293_op in H. discriminate H. Qed.

Lemma refa293_not4320 : ~ @Equation4320 Fin3 refa293_inst.
Proof. unfold Equation4320. intro H. specialize (H F3_2 F3_0). unfold magma_op, refa293_inst, refa293_op in H. discriminate H. Qed.

Lemma refa293_not4332 : ~ @Equation4332 Fin3 refa293_inst.
Proof. unfold Equation4332. intro H. specialize (H F3_0 F3_0 F3_2). unfold magma_op, refa293_inst, refa293_op in H. discriminate H. Qed.

(** ---- refa294 (Fin3) ---- *)

Definition refa294_op (x y : Fin3) : Fin3 :=
  match x, y with
  | F3_0, F3_0 => F3_0 | F3_0, F3_1 => F3_0 | F3_0, F3_2 => F3_0
  | F3_1, F3_0 => F3_1 | F3_1, F3_1 => F3_0 | F3_1, F3_2 => F3_1
  | F3_2, F3_0 => F3_2 | F3_2, F3_1 => F3_2 | F3_2, F3_2 => F3_1
  end.

#[local] Instance refa294_inst : Magma Fin3 := {| magma_op := refa294_op |}.

Lemma refa294_sat840 : @Equation840 Fin3 refa294_inst.
Proof. unfold Equation840, magma_op, refa294_inst, refa294_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa294_sat1227 : @Equation1227 Fin3 refa294_inst.
Proof. unfold Equation1227, magma_op, refa294_inst, refa294_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa294_not3659 : ~ @Equation3659 Fin3 refa294_inst.
Proof. unfold Equation3659. intro H. specialize (H F3_2). unfold magma_op, refa294_inst, refa294_op in H. discriminate H. Qed.

Lemma refa294_not3928 : ~ @Equation3928 Fin3 refa294_inst.
Proof. unfold Equation3928. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa294_inst, refa294_op in H. discriminate H. Qed.

Lemma refa294_not4598 : ~ @Equation4598 Fin3 refa294_inst.
Proof. unfold Equation4598. intro H. specialize (H F3_2 F3_1). unfold magma_op, refa294_inst, refa294_op in H. discriminate H. Qed.

(** ---- refa295 (Fin3) ---- *)

Definition refa295_op (x y : Fin3) : Fin3 :=
  match x, y with
  | F3_0, F3_0 => F3_0 | F3_0, F3_1 => F3_0 | F3_0, F3_2 => F3_0
  | F3_1, F3_0 => F3_1 | F3_1, F3_1 => F3_0 | F3_1, F3_2 => F3_0
  | F3_2, F3_0 => F3_2 | F3_2, F3_1 => F3_2 | F3_2, F3_2 => F3_1
  end.

#[local] Instance refa295_inst : Magma Fin3 := {| magma_op := refa295_op |}.

Lemma refa295_sat847 : @Equation847 Fin3 refa295_inst.
Proof. unfold Equation847, magma_op, refa295_inst, refa295_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa295_not835 : ~ @Equation835 Fin3 refa295_inst.
Proof. unfold Equation835. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa295_inst, refa295_op in H. discriminate H. Qed.

Lemma refa295_not1049 : ~ @Equation1049 Fin3 refa295_inst.
Proof. unfold Equation1049. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa295_inst, refa295_op in H. discriminate H. Qed.

Lemma refa295_not4065 : ~ @Equation4065 Fin3 refa295_inst.
Proof. unfold Equation4065. intro H. specialize (H F3_2). unfold magma_op, refa295_inst, refa295_op in H. discriminate H. Qed.

(** ---- refa296 (Fin3) ---- *)

Definition refa296_op (x y : Fin3) : Fin3 :=
  match x, y with
  | F3_0, F3_0 => F3_0 | F3_0, F3_1 => F3_0 | F3_0, F3_2 => F3_1
  | F3_1, F3_0 => F3_0 | F3_1, F3_1 => F3_0 | F3_1, F3_2 => F3_0
  | F3_2, F3_0 => F3_0 | F3_2, F3_1 => F3_0 | F3_2, F3_2 => F3_1
  end.

#[local] Instance refa296_inst : Magma Fin3 := {| magma_op := refa296_op |}.

Lemma refa296_sat3909 : @Equation3909 Fin3 refa296_inst.
Proof. unfold Equation3909, magma_op, refa296_inst, refa296_op. intros x y z w. destruct x, y, z, w; reflexivity. Qed.

Lemma refa296_sat4528 : @Equation4528 Fin3 refa296_inst.
Proof. unfold Equation4528, magma_op, refa296_inst, refa296_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa296_not359 : ~ @Equation359 Fin3 refa296_inst.
Proof. unfold Equation359. intro H. specialize (H F3_2). unfold magma_op, refa296_inst, refa296_op in H. discriminate H. Qed.

Lemma refa296_not3253 : ~ @Equation3253 Fin3 refa296_inst.
Proof. unfold Equation3253. intro H. specialize (H F3_2). unfold magma_op, refa296_inst, refa296_op in H. discriminate H. Qed.

Lemma refa296_not3456 : ~ @Equation3456 Fin3 refa296_inst.
Proof. unfold Equation3456. intro H. specialize (H F3_2). unfold magma_op, refa296_inst, refa296_op in H. discriminate H. Qed.

Lemma refa296_not3659 : ~ @Equation3659 Fin3 refa296_inst.
Proof. unfold Equation3659. intro H. specialize (H F3_2). unfold magma_op, refa296_inst, refa296_op in H. discriminate H. Qed.

Lemma refa296_not4070 : ~ @Equation4070 Fin3 refa296_inst.
Proof. unfold Equation4070. intro H. specialize (H F3_2 F3_0). unfold magma_op, refa296_inst, refa296_op in H. discriminate H. Qed.

Lemma refa296_not4090 : ~ @Equation4090 Fin3 refa296_inst.
Proof. unfold Equation4090. intro H. specialize (H F3_2 F3_0). unfold magma_op, refa296_inst, refa296_op in H. discriminate H. Qed.

Lemma refa296_not4396 : ~ @Equation4396 Fin3 refa296_inst.
Proof. unfold Equation4396. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa296_inst, refa296_op in H. discriminate H. Qed.

Lemma refa296_not4398 : ~ @Equation4398 Fin3 refa296_inst.
Proof. unfold Equation4398. intro H. specialize (H F3_2 F3_0). unfold magma_op, refa296_inst, refa296_op in H. discriminate H. Qed.

Lemma refa296_not4406 : ~ @Equation4406 Fin3 refa296_inst.
Proof. unfold Equation4406. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa296_inst, refa296_op in H. discriminate H. Qed.

Lemma refa296_not4408 : ~ @Equation4408 Fin3 refa296_inst.
Proof. unfold Equation4408. intro H. specialize (H F3_2 F3_0). unfold magma_op, refa296_inst, refa296_op in H. discriminate H. Qed.

Lemma refa296_not4433 : ~ @Equation4433 Fin3 refa296_inst.
Proof. unfold Equation4433. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa296_inst, refa296_op in H. discriminate H. Qed.

Lemma refa296_not4435 : ~ @Equation4435 Fin3 refa296_inst.
Proof. unfold Equation4435. intro H. specialize (H F3_2 F3_0). unfold magma_op, refa296_inst, refa296_op in H. discriminate H. Qed.

Lemma refa296_not4443 : ~ @Equation4443 Fin3 refa296_inst.
Proof. unfold Equation4443. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa296_inst, refa296_op in H. discriminate H. Qed.

Lemma refa296_not4445 : ~ @Equation4445 Fin3 refa296_inst.
Proof. unfold Equation4445. intro H. specialize (H F3_2 F3_0). unfold magma_op, refa296_inst, refa296_op in H. discriminate H. Qed.

Lemma refa296_not4470 : ~ @Equation4470 Fin3 refa296_inst.
Proof. unfold Equation4470. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa296_inst, refa296_op in H. discriminate H. Qed.

Lemma refa296_not4472 : ~ @Equation4472 Fin3 refa296_inst.
Proof. unfold Equation4472. intro H. specialize (H F3_2 F3_0). unfold magma_op, refa296_inst, refa296_op in H. discriminate H. Qed.

Lemma refa296_not4480 : ~ @Equation4480 Fin3 refa296_inst.
Proof. unfold Equation4480. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa296_inst, refa296_op in H. discriminate H. Qed.

Lemma refa296_not4482 : ~ @Equation4482 Fin3 refa296_inst.
Proof. unfold Equation4482. intro H. specialize (H F3_2 F3_0). unfold magma_op, refa296_inst, refa296_op in H. discriminate H. Qed.

Lemma refa296_not4583 : ~ @Equation4583 Fin3 refa296_inst.
Proof. unfold Equation4583. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa296_inst, refa296_op in H. discriminate H. Qed.

Lemma refa296_not4584 : ~ @Equation4584 Fin3 refa296_inst.
Proof. unfold Equation4584. intro H. specialize (H F3_2 F3_0). unfold magma_op, refa296_inst, refa296_op in H. discriminate H. Qed.

Lemma refa296_not4588 : ~ @Equation4588 Fin3 refa296_inst.
Proof. unfold Equation4588. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa296_inst, refa296_op in H. discriminate H. Qed.

Lemma refa296_not4590 : ~ @Equation4590 Fin3 refa296_inst.
Proof. unfold Equation4590. intro H. specialize (H F3_2 F3_0). unfold magma_op, refa296_inst, refa296_op in H. discriminate H. Qed.

Lemma refa296_not4598 : ~ @Equation4598 Fin3 refa296_inst.
Proof. unfold Equation4598. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa296_inst, refa296_op in H. discriminate H. Qed.

Lemma refa296_not4608 : ~ @Equation4608 Fin3 refa296_inst.
Proof. unfold Equation4608. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa296_inst, refa296_op in H. discriminate H. Qed.

Lemma refa296_not4636 : ~ @Equation4636 Fin3 refa296_inst.
Proof. unfold Equation4636. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa296_inst, refa296_op in H. discriminate H. Qed.

(** ---- refa297 (Fin4) ---- *)

Definition refa297_op (x y : Fin4) : Fin4 :=
  match x, y with
  | F4_0, F4_0 => F4_0 | F4_0, F4_1 => F4_1 | F4_0, F4_2 => F4_3 | F4_0, F4_3 => F4_3
  | F4_1, F4_0 => F4_3 | F4_1, F4_1 => F4_3 | F4_1, F4_2 => F4_0 | F4_1, F4_3 => F4_2
  | F4_2, F4_0 => F4_1 | F4_2, F4_1 => F4_0 | F4_2, F4_2 => F4_1 | F4_2, F4_3 => F4_0
  | F4_3, F4_0 => F4_0 | F4_3, F4_1 => F4_3 | F4_3, F4_2 => F4_2 | F4_3, F4_3 => F4_2
  end.

#[local] Instance refa297_inst : Magma Fin4 := {| magma_op := refa297_op |}.

Lemma refa297_sat2912 : @Equation2912 Fin4 refa297_inst.
Proof. unfold Equation2912, magma_op, refa297_inst, refa297_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa297_not255 : ~ @Equation255 Fin4 refa297_inst.
Proof. unfold Equation255. intro H. specialize (H F4_1). unfold magma_op, refa297_inst, refa297_op in H. discriminate H. Qed.

Lemma refa297_not359 : ~ @Equation359 Fin4 refa297_inst.
Proof. unfold Equation359. intro H. specialize (H F4_2). unfold magma_op, refa297_inst, refa297_op in H. discriminate H. Qed.

Lemma refa297_not411 : ~ @Equation411 Fin4 refa297_inst.
Proof. unfold Equation411. intro H. specialize (H F4_1). unfold magma_op, refa297_inst, refa297_op in H. discriminate H. Qed.

Lemma refa297_not614 : ~ @Equation614 Fin4 refa297_inst.
Proof. unfold Equation614. intro H. specialize (H F4_1). unfold magma_op, refa297_inst, refa297_op in H. discriminate H. Qed.

Lemma refa297_not817 : ~ @Equation817 Fin4 refa297_inst.
Proof. unfold Equation817. intro H. specialize (H F4_1). unfold magma_op, refa297_inst, refa297_op in H. discriminate H. Qed.

Lemma refa297_not1020 : ~ @Equation1020 Fin4 refa297_inst.
Proof. unfold Equation1020. intro H. specialize (H F4_1). unfold magma_op, refa297_inst, refa297_op in H. discriminate H. Qed.

Lemma refa297_not1223 : ~ @Equation1223 Fin4 refa297_inst.
Proof. unfold Equation1223. intro H. specialize (H F4_1). unfold magma_op, refa297_inst, refa297_op in H. discriminate H. Qed.

Lemma refa297_not1426 : ~ @Equation1426 Fin4 refa297_inst.
Proof. unfold Equation1426. intro H. specialize (H F4_1). unfold magma_op, refa297_inst, refa297_op in H. discriminate H. Qed.

Lemma refa297_not1631 : ~ @Equation1631 Fin4 refa297_inst.
Proof. unfold Equation1631. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa297_inst, refa297_op in H. discriminate H. Qed.

Lemma refa297_not1634 : ~ @Equation1634 Fin4 refa297_inst.
Proof. unfold Equation1634. intro H. specialize (H F4_0 F4_2). unfold magma_op, refa297_inst, refa297_op in H. discriminate H. Qed.

Lemma refa297_not1644 : ~ @Equation1644 Fin4 refa297_inst.
Proof. unfold Equation1644. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa297_inst, refa297_op in H. discriminate H. Qed.

Lemma refa297_not1654 : ~ @Equation1654 Fin4 refa297_inst.
Proof. unfold Equation1654. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa297_inst, refa297_op in H. discriminate H. Qed.

Lemma refa297_not1657 : ~ @Equation1657 Fin4 refa297_inst.
Proof. unfold Equation1657. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa297_inst, refa297_op in H. discriminate H. Qed.

Lemma refa297_not1681 : ~ @Equation1681 Fin4 refa297_inst.
Proof. unfold Equation1681. intro H. specialize (H F4_0 F4_2). unfold magma_op, refa297_inst, refa297_op in H. discriminate H. Qed.

Lemma refa297_not1684 : ~ @Equation1684 Fin4 refa297_inst.
Proof. unfold Equation1684. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa297_inst, refa297_op in H. discriminate H. Qed.

Lemma refa297_not1691 : ~ @Equation1691 Fin4 refa297_inst.
Proof. unfold Equation1691. intro H. specialize (H F4_0 F4_2). unfold magma_op, refa297_inst, refa297_op in H. discriminate H. Qed.

Lemma refa297_not1694 : ~ @Equation1694 Fin4 refa297_inst.
Proof. unfold Equation1694. intro H. specialize (H F4_0 F4_2). unfold magma_op, refa297_inst, refa297_op in H. discriminate H. Qed.

Lemma refa297_not1721 : ~ @Equation1721 Fin4 refa297_inst.
Proof. unfold Equation1721. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa297_inst, refa297_op in H. discriminate H. Qed.

Lemma refa297_not1728 : ~ @Equation1728 Fin4 refa297_inst.
Proof. unfold Equation1728. intro H. specialize (H F4_0 F4_2). unfold magma_op, refa297_inst, refa297_op in H. discriminate H. Qed.

Lemma refa297_not1832 : ~ @Equation1832 Fin4 refa297_inst.
Proof. unfold Equation1832. intro H. specialize (H F4_1). unfold magma_op, refa297_inst, refa297_op in H. discriminate H. Qed.

Lemma refa297_not2035 : ~ @Equation2035 Fin4 refa297_inst.
Proof. unfold Equation2035. intro H. specialize (H F4_1). unfold magma_op, refa297_inst, refa297_op in H. discriminate H. Qed.

Lemma refa297_not2240 : ~ @Equation2240 Fin4 refa297_inst.
Proof. unfold Equation2240. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa297_inst, refa297_op in H. discriminate H. Qed.

Lemma refa297_not2243 : ~ @Equation2243 Fin4 refa297_inst.
Proof. unfold Equation2243. intro H. specialize (H F4_0 F4_2). unfold magma_op, refa297_inst, refa297_op in H. discriminate H. Qed.

Lemma refa297_not2253 : ~ @Equation2253 Fin4 refa297_inst.
Proof. unfold Equation2253. intro H. specialize (H F4_0 F4_2). unfold magma_op, refa297_inst, refa297_op in H. discriminate H. Qed.

Lemma refa297_not2266 : ~ @Equation2266 Fin4 refa297_inst.
Proof. unfold Equation2266. intro H. specialize (H F4_1 F4_0). unfold magma_op, refa297_inst, refa297_op in H. discriminate H. Qed.

Lemma refa297_not2290 : ~ @Equation2290 Fin4 refa297_inst.
Proof. unfold Equation2290. intro H. specialize (H F4_0 F4_2). unfold magma_op, refa297_inst, refa297_op in H. discriminate H. Qed.

Lemma refa297_not2303 : ~ @Equation2303 Fin4 refa297_inst.
Proof. unfold Equation2303. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa297_inst, refa297_op in H. discriminate H. Qed.

Lemma refa297_not2330 : ~ @Equation2330 Fin4 refa297_inst.
Proof. unfold Equation2330. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa297_inst, refa297_op in H. discriminate H. Qed.

Lemma refa297_not2443 : ~ @Equation2443 Fin4 refa297_inst.
Proof. unfold Equation2443. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa297_inst, refa297_op in H. discriminate H. Qed.

Lemma refa297_not2446 : ~ @Equation2446 Fin4 refa297_inst.
Proof. unfold Equation2446. intro H. specialize (H F4_1 F4_0). unfold magma_op, refa297_inst, refa297_op in H. discriminate H. Qed.

Lemma refa297_not2456 : ~ @Equation2456 Fin4 refa297_inst.
Proof. unfold Equation2456. intro H. specialize (H F4_1 F4_0). unfold magma_op, refa297_inst, refa297_op in H. discriminate H. Qed.

Lemma refa297_not2469 : ~ @Equation2469 Fin4 refa297_inst.
Proof. unfold Equation2469. intro H. specialize (H F4_1 F4_0). unfold magma_op, refa297_inst, refa297_op in H. discriminate H. Qed.

Lemma refa297_not2506 : ~ @Equation2506 Fin4 refa297_inst.
Proof. unfold Equation2506. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa297_inst, refa297_op in H. discriminate H. Qed.

Lemma refa297_not2533 : ~ @Equation2533 Fin4 refa297_inst.
Proof. unfold Equation2533. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa297_inst, refa297_op in H. discriminate H. Qed.

Lemma refa297_not2540 : ~ @Equation2540 Fin4 refa297_inst.
Proof. unfold Equation2540. intro H. specialize (H F4_1 F4_0). unfold magma_op, refa297_inst, refa297_op in H. discriminate H. Qed.

Lemma refa297_not2644 : ~ @Equation2644 Fin4 refa297_inst.
Proof. unfold Equation2644. intro H. specialize (H F4_1). unfold magma_op, refa297_inst, refa297_op in H. discriminate H. Qed.

Lemma refa297_not2849 : ~ @Equation2849 Fin4 refa297_inst.
Proof. unfold Equation2849. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa297_inst, refa297_op in H. discriminate H. Qed.

Lemma refa297_not2852 : ~ @Equation2852 Fin4 refa297_inst.
Proof. unfold Equation2852. intro H. specialize (H F4_1 F4_2). unfold magma_op, refa297_inst, refa297_op in H. discriminate H. Qed.

Lemma refa297_not2855 : ~ @Equation2855 Fin4 refa297_inst.
Proof. unfold Equation2855. intro H. specialize (H F4_0 F4_2). unfold magma_op, refa297_inst, refa297_op in H. discriminate H. Qed.

Lemma refa297_not2865 : ~ @Equation2865 Fin4 refa297_inst.
Proof. unfold Equation2865. intro H. specialize (H F4_1 F4_2). unfold magma_op, refa297_inst, refa297_op in H. discriminate H. Qed.

Lemma refa297_not2872 : ~ @Equation2872 Fin4 refa297_inst.
Proof. unfold Equation2872. intro H. specialize (H F4_1 F4_0). unfold magma_op, refa297_inst, refa297_op in H. discriminate H. Qed.

Lemma refa297_not2875 : ~ @Equation2875 Fin4 refa297_inst.
Proof. unfold Equation2875. intro H. specialize (H F4_0 F4_3). unfold magma_op, refa297_inst, refa297_op in H. discriminate H. Qed.

Lemma refa297_not2902 : ~ @Equation2902 Fin4 refa297_inst.
Proof. unfold Equation2902. intro H. specialize (H F4_1 F4_2). unfold magma_op, refa297_inst, refa297_op in H. discriminate H. Qed.

Lemma refa297_not2939 : ~ @Equation2939 Fin4 refa297_inst.
Proof. unfold Equation2939. intro H. specialize (H F4_1 F4_0). unfold magma_op, refa297_inst, refa297_op in H. discriminate H. Qed.

Lemma refa297_not2946 : ~ @Equation2946 Fin4 refa297_inst.
Proof. unfold Equation2946. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa297_inst, refa297_op in H. discriminate H. Qed.

Lemma refa297_not2949 : ~ @Equation2949 Fin4 refa297_inst.
Proof. unfold Equation2949. intro H. specialize (H F4_1 F4_2). unfold magma_op, refa297_inst, refa297_op in H. discriminate H. Qed.

Lemma refa297_not3052 : ~ @Equation3052 Fin4 refa297_inst.
Proof. unfold Equation3052. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa297_inst, refa297_op in H. discriminate H. Qed.

Lemma refa297_not3055 : ~ @Equation3055 Fin4 refa297_inst.
Proof. unfold Equation3055. intro H. specialize (H F4_1 F4_0). unfold magma_op, refa297_inst, refa297_op in H. discriminate H. Qed.

Lemma refa297_not3065 : ~ @Equation3065 Fin4 refa297_inst.
Proof. unfold Equation3065. intro H. specialize (H F4_1 F4_0). unfold magma_op, refa297_inst, refa297_op in H. discriminate H. Qed.

Lemma refa297_not3068 : ~ @Equation3068 Fin4 refa297_inst.
Proof. unfold Equation3068. intro H. specialize (H F4_1 F4_1). unfold magma_op, refa297_inst, refa297_op in H. discriminate H. Qed.

Lemma refa297_not3105 : ~ @Equation3105 Fin4 refa297_inst.
Proof. unfold Equation3105. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa297_inst, refa297_op in H. discriminate H. Qed.

Lemma refa297_not3115 : ~ @Equation3115 Fin4 refa297_inst.
Proof. unfold Equation3115. intro H. specialize (H F4_0 F4_3). unfold magma_op, refa297_inst, refa297_op in H. discriminate H. Qed.

Lemma refa297_not3142 : ~ @Equation3142 Fin4 refa297_inst.
Proof. unfold Equation3142. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa297_inst, refa297_op in H. discriminate H. Qed.

Lemma refa297_not3149 : ~ @Equation3149 Fin4 refa297_inst.
Proof. unfold Equation3149. intro H. specialize (H F4_1 F4_0). unfold magma_op, refa297_inst, refa297_op in H. discriminate H. Qed.

Lemma refa297_not3152 : ~ @Equation3152 Fin4 refa297_inst.
Proof. unfold Equation3152. intro H. specialize (H F4_1 F4_1). unfold magma_op, refa297_inst, refa297_op in H. discriminate H. Qed.

Lemma refa297_not3253 : ~ @Equation3253 Fin4 refa297_inst.
Proof. unfold Equation3253. intro H. specialize (H F4_1). unfold magma_op, refa297_inst, refa297_op in H. discriminate H. Qed.

Lemma refa297_not3458 : ~ @Equation3458 Fin4 refa297_inst.
Proof. unfold Equation3458. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa297_inst, refa297_op in H. discriminate H. Qed.

Lemma refa297_not3461 : ~ @Equation3461 Fin4 refa297_inst.
Proof. unfold Equation3461. intro H. specialize (H F4_0 F4_2). unfold magma_op, refa297_inst, refa297_op in H. discriminate H. Qed.

Lemma refa297_not3464 : ~ @Equation3464 Fin4 refa297_inst.
Proof. unfold Equation3464. intro H. specialize (H F4_0 F4_2). unfold magma_op, refa297_inst, refa297_op in H. discriminate H. Qed.

Lemma refa297_not3474 : ~ @Equation3474 Fin4 refa297_inst.
Proof. unfold Equation3474. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa297_inst, refa297_op in H. discriminate H. Qed.

Lemma refa297_not3481 : ~ @Equation3481 Fin4 refa297_inst.
Proof. unfold Equation3481. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa297_inst, refa297_op in H. discriminate H. Qed.

Lemma refa297_not3484 : ~ @Equation3484 Fin4 refa297_inst.
Proof. unfold Equation3484. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa297_inst, refa297_op in H. discriminate H. Qed.

Lemma refa297_not3509 : ~ @Equation3509 Fin4 refa297_inst.
Proof. unfold Equation3509. intro H. specialize (H F4_1 F4_1). unfold magma_op, refa297_inst, refa297_op in H. discriminate H. Qed.

Lemma refa297_not3512 : ~ @Equation3512 Fin4 refa297_inst.
Proof. unfold Equation3512. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa297_inst, refa297_op in H. discriminate H. Qed.

Lemma refa297_not3519 : ~ @Equation3519 Fin4 refa297_inst.
Proof. unfold Equation3519. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa297_inst, refa297_op in H. discriminate H. Qed.

Lemma refa297_not3546 : ~ @Equation3546 Fin4 refa297_inst.
Proof. unfold Equation3546. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa297_inst, refa297_op in H. discriminate H. Qed.

Lemma refa297_not3549 : ~ @Equation3549 Fin4 refa297_inst.
Proof. unfold Equation3549. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa297_inst, refa297_op in H. discriminate H. Qed.

Lemma refa297_not3556 : ~ @Equation3556 Fin4 refa297_inst.
Proof. unfold Equation3556. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa297_inst, refa297_op in H. discriminate H. Qed.

Lemma refa297_not3659 : ~ @Equation3659 Fin4 refa297_inst.
Proof. unfold Equation3659. intro H. specialize (H F4_1). unfold magma_op, refa297_inst, refa297_op in H. discriminate H. Qed.

Lemma refa297_not3864 : ~ @Equation3864 Fin4 refa297_inst.
Proof. unfold Equation3864. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa297_inst, refa297_op in H. discriminate H. Qed.

Lemma refa297_not3867 : ~ @Equation3867 Fin4 refa297_inst.
Proof. unfold Equation3867. intro H. specialize (H F4_0 F4_2). unfold magma_op, refa297_inst, refa297_op in H. discriminate H. Qed.

Lemma refa297_not3870 : ~ @Equation3870 Fin4 refa297_inst.
Proof. unfold Equation3870. intro H. specialize (H F4_0 F4_2). unfold magma_op, refa297_inst, refa297_op in H. discriminate H. Qed.

Lemma refa297_not3877 : ~ @Equation3877 Fin4 refa297_inst.
Proof. unfold Equation3877. intro H. specialize (H F4_0 F4_2). unfold magma_op, refa297_inst, refa297_op in H. discriminate H. Qed.

Lemma refa297_not3880 : ~ @Equation3880 Fin4 refa297_inst.
Proof. unfold Equation3880. intro H. specialize (H F4_0 F4_3). unfold magma_op, refa297_inst, refa297_op in H. discriminate H. Qed.

Lemma refa297_not3887 : ~ @Equation3887 Fin4 refa297_inst.
Proof. unfold Equation3887. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa297_inst, refa297_op in H. discriminate H. Qed.

Lemma refa297_not3890 : ~ @Equation3890 Fin4 refa297_inst.
Proof. unfold Equation3890. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa297_inst, refa297_op in H. discriminate H. Qed.

Lemma refa297_not3915 : ~ @Equation3915 Fin4 refa297_inst.
Proof. unfold Equation3915. intro H. specialize (H F4_1 F4_0). unfold magma_op, refa297_inst, refa297_op in H. discriminate H. Qed.

Lemma refa297_not3918 : ~ @Equation3918 Fin4 refa297_inst.
Proof. unfold Equation3918. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa297_inst, refa297_op in H. discriminate H. Qed.

Lemma refa297_not3925 : ~ @Equation3925 Fin4 refa297_inst.
Proof. unfold Equation3925. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa297_inst, refa297_op in H. discriminate H. Qed.

Lemma refa297_not3928 : ~ @Equation3928 Fin4 refa297_inst.
Proof. unfold Equation3928. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa297_inst, refa297_op in H. discriminate H. Qed.

Lemma refa297_not3952 : ~ @Equation3952 Fin4 refa297_inst.
Proof. unfold Equation3952. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa297_inst, refa297_op in H. discriminate H. Qed.

Lemma refa297_not3962 : ~ @Equation3962 Fin4 refa297_inst.
Proof. unfold Equation3962. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa297_inst, refa297_op in H. discriminate H. Qed.

Lemma refa297_not4067 : ~ @Equation4067 Fin4 refa297_inst.
Proof. unfold Equation4067. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa297_inst, refa297_op in H. discriminate H. Qed.

Lemma refa297_not4070 : ~ @Equation4070 Fin4 refa297_inst.
Proof. unfold Equation4070. intro H. specialize (H F4_1 F4_3). unfold magma_op, refa297_inst, refa297_op in H. discriminate H. Qed.

Lemma refa297_not4073 : ~ @Equation4073 Fin4 refa297_inst.
Proof. unfold Equation4073. intro H. specialize (H F4_0 F4_2). unfold magma_op, refa297_inst, refa297_op in H. discriminate H. Qed.

Lemma refa297_not4083 : ~ @Equation4083 Fin4 refa297_inst.
Proof. unfold Equation4083. intro H. specialize (H F4_1 F4_3). unfold magma_op, refa297_inst, refa297_op in H. discriminate H. Qed.

Lemma refa297_not4090 : ~ @Equation4090 Fin4 refa297_inst.
Proof. unfold Equation4090. intro H. specialize (H F4_0 F4_3). unfold magma_op, refa297_inst, refa297_op in H. discriminate H. Qed.

Lemma refa297_not4093 : ~ @Equation4093 Fin4 refa297_inst.
Proof. unfold Equation4093. intro H. specialize (H F4_1 F4_0). unfold magma_op, refa297_inst, refa297_op in H. discriminate H. Qed.

Lemma refa297_not4121 : ~ @Equation4121 Fin4 refa297_inst.
Proof. unfold Equation4121. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa297_inst, refa297_op in H. discriminate H. Qed.

Lemma refa297_not4128 : ~ @Equation4128 Fin4 refa297_inst.
Proof. unfold Equation4128. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa297_inst, refa297_op in H. discriminate H. Qed.

Lemma refa297_not4155 : ~ @Equation4155 Fin4 refa297_inst.
Proof. unfold Equation4155. intro H. specialize (H F4_0 F4_2). unfold magma_op, refa297_inst, refa297_op in H. discriminate H. Qed.

Lemma refa297_not4158 : ~ @Equation4158 Fin4 refa297_inst.
Proof. unfold Equation4158. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa297_inst, refa297_op in H. discriminate H. Qed.

Lemma refa297_not4165 : ~ @Equation4165 Fin4 refa297_inst.
Proof. unfold Equation4165. intro H. specialize (H F4_0 F4_2). unfold magma_op, refa297_inst, refa297_op in H. discriminate H. Qed.

Lemma refa297_not4269 : ~ @Equation4269 Fin4 refa297_inst.
Proof. unfold Equation4269. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa297_inst, refa297_op in H. discriminate H. Qed.

Lemma refa297_not4272 : ~ @Equation4272 Fin4 refa297_inst.
Proof. unfold Equation4272. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa297_inst, refa297_op in H. discriminate H. Qed.

Lemma refa297_not4275 : ~ @Equation4275 Fin4 refa297_inst.
Proof. unfold Equation4275. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa297_inst, refa297_op in H. discriminate H. Qed.

Lemma refa297_not4284 : ~ @Equation4284 Fin4 refa297_inst.
Proof. unfold Equation4284. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa297_inst, refa297_op in H. discriminate H. Qed.

Lemma refa297_not4291 : ~ @Equation4291 Fin4 refa297_inst.
Proof. unfold Equation4291. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa297_inst, refa297_op in H. discriminate H. Qed.

Lemma refa297_not4320 : ~ @Equation4320 Fin4 refa297_inst.
Proof. unfold Equation4320. intro H. specialize (H F4_1 F4_2). unfold magma_op, refa297_inst, refa297_op in H. discriminate H. Qed.

Lemma refa297_not4380 : ~ @Equation4380 Fin4 refa297_inst.
Proof. unfold Equation4380. intro H. specialize (H F4_1). unfold magma_op, refa297_inst, refa297_op in H. discriminate H. Qed.

Lemma refa297_not4584 : ~ @Equation4584 Fin4 refa297_inst.
Proof. unfold Equation4584. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa297_inst, refa297_op in H. discriminate H. Qed.

Lemma refa297_not4587 : ~ @Equation4587 Fin4 refa297_inst.
Proof. unfold Equation4587. intro H. specialize (H F4_0 F4_2). unfold magma_op, refa297_inst, refa297_op in H. discriminate H. Qed.

Lemma refa297_not4590 : ~ @Equation4590 Fin4 refa297_inst.
Proof. unfold Equation4590. intro H. specialize (H F4_0 F4_2). unfold magma_op, refa297_inst, refa297_op in H. discriminate H. Qed.

Lemma refa297_not4599 : ~ @Equation4599 Fin4 refa297_inst.
Proof. unfold Equation4599. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa297_inst, refa297_op in H. discriminate H. Qed.

Lemma refa297_not4606 : ~ @Equation4606 Fin4 refa297_inst.
Proof. unfold Equation4606. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa297_inst, refa297_op in H. discriminate H. Qed.

Lemma refa297_not4635 : ~ @Equation4635 Fin4 refa297_inst.
Proof. unfold Equation4635. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa297_inst, refa297_op in H. discriminate H. Qed.

(** ---- refa298 (Fin4) ---- *)

Definition refa298_op (x y : Fin4) : Fin4 :=
  match x, y with
  | F4_0, F4_0 => F4_2 | F4_0, F4_1 => F4_3 | F4_0, F4_2 => F4_2 | F4_0, F4_3 => F4_3
  | F4_1, F4_0 => F4_3 | F4_1, F4_1 => F4_2 | F4_1, F4_2 => F4_3 | F4_1, F4_3 => F4_2
  | F4_2, F4_0 => F4_1 | F4_2, F4_1 => F4_0 | F4_2, F4_2 => F4_1 | F4_2, F4_3 => F4_0
  | F4_3, F4_0 => F4_0 | F4_3, F4_1 => F4_1 | F4_3, F4_2 => F4_0 | F4_3, F4_3 => F4_1
  end.

#[local] Instance refa298_inst : Magma Fin4 := {| magma_op := refa298_op |}.

Lemma refa298_sat1670 : @Equation1670 Fin4 refa298_inst.
Proof. unfold Equation1670, magma_op, refa298_inst, refa298_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa298_sat1673 : @Equation1673 Fin4 refa298_inst.
Proof. unfold Equation1673, magma_op, refa298_inst, refa298_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa298_sat2485 : @Equation2485 Fin4 refa298_inst.
Proof. unfold Equation2485, magma_op, refa298_inst, refa298_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa298_sat3083 : @Equation3083 Fin4 refa298_inst.
Proof. unfold Equation3083, magma_op, refa298_inst, refa298_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa298_sat3091 : @Equation3091 Fin4 refa298_inst.
Proof. unfold Equation3091, magma_op, refa298_inst, refa298_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa298_not1426 : ~ @Equation1426 Fin4 refa298_inst.
Proof. unfold Equation1426. intro H. specialize (H F4_0). unfold magma_op, refa298_inst, refa298_op in H. discriminate H. Qed.

Lemma refa298_not1731 : ~ @Equation1731 Fin4 refa298_inst.
Proof. unfold Equation1731. intro H. specialize (H F4_0 F4_2). unfold magma_op, refa298_inst, refa298_op in H. discriminate H. Qed.

Lemma refa298_not1832 : ~ @Equation1832 Fin4 refa298_inst.
Proof. unfold Equation1832. intro H. specialize (H F4_0). unfold magma_op, refa298_inst, refa298_op in H. discriminate H. Qed.

Lemma refa298_not2238 : ~ @Equation2238 Fin4 refa298_inst.
Proof. unfold Equation2238. intro H. specialize (H F4_0). unfold magma_op, refa298_inst, refa298_op in H. discriminate H. Qed.

Lemma refa298_not2496 : ~ @Equation2496 Fin4 refa298_inst.
Proof. unfold Equation2496. intro H. specialize (H F4_0 F4_2). unfold magma_op, refa298_inst, refa298_op in H. discriminate H. Qed.

Lemma refa298_not2530 : ~ @Equation2530 Fin4 refa298_inst.
Proof. unfold Equation2530. intro H. specialize (H F4_0 F4_2). unfold magma_op, refa298_inst, refa298_op in H. discriminate H. Qed.

Lemma refa298_not2543 : ~ @Equation2543 Fin4 refa298_inst.
Proof. unfold Equation2543. intro H. specialize (H F4_0 F4_2). unfold magma_op, refa298_inst, refa298_op in H. discriminate H. Qed.

Lemma refa298_not2644 : ~ @Equation2644 Fin4 refa298_inst.
Proof. unfold Equation2644. intro H. specialize (H F4_0). unfold magma_op, refa298_inst, refa298_op in H. discriminate H. Qed.

Lemma refa298_not3105 : ~ @Equation3105 Fin4 refa298_inst.
Proof. unfold Equation3105. intro H. specialize (H F4_0 F4_2). unfold magma_op, refa298_inst, refa298_op in H. discriminate H. Qed.

Lemma refa298_not3139 : ~ @Equation3139 Fin4 refa298_inst.
Proof. unfold Equation3139. intro H. specialize (H F4_0 F4_2). unfold magma_op, refa298_inst, refa298_op in H. discriminate H. Qed.

Lemma refa298_not3152 : ~ @Equation3152 Fin4 refa298_inst.
Proof. unfold Equation3152. intro H. specialize (H F4_0 F4_2). unfold magma_op, refa298_inst, refa298_op in H. discriminate H. Qed.

Lemma refa298_not3269 : ~ @Equation3269 Fin4 refa298_inst.
Proof. unfold Equation3269. intro H. specialize (H F4_0 F4_2). unfold magma_op, refa298_inst, refa298_op in H. discriminate H. Qed.

Lemma refa298_not3271 : ~ @Equation3271 Fin4 refa298_inst.
Proof. unfold Equation3271. intro H. specialize (H F4_0 F4_2). unfold magma_op, refa298_inst, refa298_op in H. discriminate H. Qed.

Lemma refa298_not3278 : ~ @Equation3278 Fin4 refa298_inst.
Proof. unfold Equation3278. intro H. specialize (H F4_0 F4_2). unfold magma_op, refa298_inst, refa298_op in H. discriminate H. Qed.

Lemma refa298_not3456 : ~ @Equation3456 Fin4 refa298_inst.
Proof. unfold Equation3456. intro H. specialize (H F4_0). unfold magma_op, refa298_inst, refa298_op in H. discriminate H. Qed.

Lemma refa298_not3662 : ~ @Equation3662 Fin4 refa298_inst.
Proof. unfold Equation3662. intro H. specialize (H F4_0 F4_0). unfold magma_op, refa298_inst, refa298_op in H. discriminate H. Qed.

Lemma refa298_not3665 : ~ @Equation3665 Fin4 refa298_inst.
Proof. unfold Equation3665. intro H. specialize (H F4_0 F4_0). unfold magma_op, refa298_inst, refa298_op in H. discriminate H. Qed.

Lemma refa298_not3677 : ~ @Equation3677 Fin4 refa298_inst.
Proof. unfold Equation3677. intro H. specialize (H F4_0 F4_0). unfold magma_op, refa298_inst, refa298_op in H. discriminate H. Qed.

Lemma refa298_not3759 : ~ @Equation3759 Fin4 refa298_inst.
Proof. unfold Equation3759. intro H. specialize (H F4_0 F4_0). unfold magma_op, refa298_inst, refa298_op in H. discriminate H. Qed.

Lemma refa298_not4065 : ~ @Equation4065 Fin4 refa298_inst.
Proof. unfold Equation4065. intro H. specialize (H F4_0). unfold magma_op, refa298_inst, refa298_op in H. discriminate H. Qed.

Lemma refa298_not4270 : ~ @Equation4270 Fin4 refa298_inst.
Proof. unfold Equation4270. intro H. specialize (H F4_0 F4_2). unfold magma_op, refa298_inst, refa298_op in H. discriminate H. Qed.

Lemma refa298_not4273 : ~ @Equation4273 Fin4 refa298_inst.
Proof. unfold Equation4273. intro H. specialize (H F4_0 F4_2). unfold magma_op, refa298_inst, refa298_op in H. discriminate H. Qed.

Lemma refa298_not4320 : ~ @Equation4320 Fin4 refa298_inst.
Proof. unfold Equation4320. intro H. specialize (H F4_0 F4_2). unfold magma_op, refa298_inst, refa298_op in H. discriminate H. Qed.

Lemma refa298_not4622 : ~ @Equation4622 Fin4 refa298_inst.
Proof. unfold Equation4622. intro H. specialize (H F4_0 F4_0 F4_2). unfold magma_op, refa298_inst, refa298_op in H. discriminate H. Qed.

(** ---- refa299 (Fin4) ---- *)

Definition refa299_op (x y : Fin4) : Fin4 :=
  match x, y with
  | F4_0, F4_0 => F4_0 | F4_0, F4_1 => F4_1 | F4_0, F4_2 => F4_0 | F4_0, F4_3 => F4_1
  | F4_1, F4_0 => F4_0 | F4_1, F4_1 => F4_3 | F4_1, F4_2 => F4_2 | F4_1, F4_3 => F4_3
  | F4_2, F4_0 => F4_0 | F4_2, F4_1 => F4_1 | F4_2, F4_2 => F4_0 | F4_2, F4_3 => F4_3
  | F4_3, F4_0 => F4_0 | F4_3, F4_1 => F4_3 | F4_3, F4_2 => F4_2 | F4_3, F4_3 => F4_3
  end.

#[local] Instance refa299_inst : Magma Fin4 := {| magma_op := refa299_op |}.

Lemma refa299_sat4209 : @Equation4209 Fin4 refa299_inst.
Proof. unfold Equation4209, magma_op, refa299_inst, refa299_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa299_not3915 : ~ @Equation3915 Fin4 refa299_inst.
Proof. unfold Equation3915. intro H. specialize (H F4_2 F4_3). unfold magma_op, refa299_inst, refa299_op in H. discriminate H. Qed.

Lemma refa299_not3925 : ~ @Equation3925 Fin4 refa299_inst.
Proof. unfold Equation3925. intro H. specialize (H F4_2 F4_3). unfold magma_op, refa299_inst, refa299_op in H. discriminate H. Qed.

Lemma refa299_not3952 : ~ @Equation3952 Fin4 refa299_inst.
Proof. unfold Equation3952. intro H. specialize (H F4_2 F4_3). unfold magma_op, refa299_inst, refa299_op in H. discriminate H. Qed.

Lemma refa299_not4118 : ~ @Equation4118 Fin4 refa299_inst.
Proof. unfold Equation4118. intro H. specialize (H F4_2 F4_3). unfold magma_op, refa299_inst, refa299_op in H. discriminate H. Qed.

Lemma refa299_not4155 : ~ @Equation4155 Fin4 refa299_inst.
Proof. unfold Equation4155. intro H. specialize (H F4_2 F4_3). unfold magma_op, refa299_inst, refa299_op in H. discriminate H. Qed.

Lemma refa299_not4360 : ~ @Equation4360 Fin4 refa299_inst.
Proof. unfold Equation4360. intro H. specialize (H F4_1 F4_0 F4_2 F4_1). unfold magma_op, refa299_inst, refa299_op in H. discriminate H. Qed.

Lemma refa299_not4606 : ~ @Equation4606 Fin4 refa299_inst.
Proof. unfold Equation4606. intro H. specialize (H F4_2 F4_3). unfold magma_op, refa299_inst, refa299_op in H. discriminate H. Qed.

(** ---- refa3 (Fin7) ---- *)

Definition refa3_op (x y : Fin7) : Fin7 :=
  match x, y with
  | F7_0, F7_0 => F7_0 | F7_0, F7_1 => F7_2 | F7_0, F7_2 => F7_3 | F7_0, F7_3 => F7_4 | F7_0, F7_4 => F7_5 | F7_0, F7_5 => F7_6 | F7_0, F7_6 => F7_1
  | F7_1, F7_0 => F7_6 | F7_1, F7_1 => F7_1 | F7_1, F7_2 => F7_0 | F7_1, F7_3 => F7_5 | F7_1, F7_4 => F7_3 | F7_1, F7_5 => F7_2 | F7_1, F7_6 => F7_4
  | F7_2, F7_0 => F7_1 | F7_2, F7_1 => F7_5 | F7_2, F7_2 => F7_2 | F7_2, F7_3 => F7_0 | F7_2, F7_4 => F7_6 | F7_2, F7_5 => F7_4 | F7_2, F7_6 => F7_3
  | F7_3, F7_0 => F7_2 | F7_3, F7_1 => F7_4 | F7_3, F7_2 => F7_6 | F7_3, F7_3 => F7_3 | F7_3, F7_4 => F7_0 | F7_3, F7_5 => F7_1 | F7_3, F7_6 => F7_5
  | F7_4, F7_0 => F7_3 | F7_4, F7_1 => F7_6 | F7_4, F7_2 => F7_5 | F7_4, F7_3 => F7_1 | F7_4, F7_4 => F7_4 | F7_4, F7_5 => F7_0 | F7_4, F7_6 => F7_2
  | F7_5, F7_0 => F7_4 | F7_5, F7_1 => F7_3 | F7_5, F7_2 => F7_1 | F7_5, F7_3 => F7_6 | F7_5, F7_4 => F7_2 | F7_5, F7_5 => F7_5 | F7_5, F7_6 => F7_0
  | F7_6, F7_0 => F7_5 | F7_6, F7_1 => F7_0 | F7_6, F7_2 => F7_4 | F7_6, F7_3 => F7_2 | F7_6, F7_4 => F7_1 | F7_6, F7_5 => F7_3 | F7_6, F7_6 => F7_6
  end.

#[local] Instance refa3_inst : Magma Fin7 := {| magma_op := refa3_op |}.

Lemma refa3_sat713 : @Equation713 Fin7 refa3_inst.
Proof. unfold Equation713, magma_op, refa3_inst, refa3_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa3_sat2450 : @Equation2450 Fin7 refa3_inst.
Proof. unfold Equation2450, magma_op, refa3_inst, refa3_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa3_not55 : ~ @Equation55 Fin7 refa3_inst.
Proof. unfold Equation55. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa3_inst, refa3_op in H. discriminate H. Qed.

Lemma refa3_not65 : ~ @Equation65 Fin7 refa3_inst.
Proof. unfold Equation65. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa3_inst, refa3_op in H. discriminate H. Qed.

Lemma refa3_not619 : ~ @Equation619 Fin7 refa3_inst.
Proof. unfold Equation619. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa3_inst, refa3_op in H. discriminate H. Qed.

Lemma refa3_not632 : ~ @Equation632 Fin7 refa3_inst.
Proof. unfold Equation632. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa3_inst, refa3_op in H. discriminate H. Qed.

Lemma refa3_not679 : ~ @Equation679 Fin7 refa3_inst.
Proof. unfold Equation679. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa3_inst, refa3_op in H. discriminate H. Qed.

Lemma refa3_not825 : ~ @Equation825 Fin7 refa3_inst.
Proof. unfold Equation825. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa3_inst, refa3_op in H. discriminate H. Qed.

Lemma refa3_not832 : ~ @Equation832 Fin7 refa3_inst.
Proof. unfold Equation832. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa3_inst, refa3_op in H. discriminate H. Qed.

Lemma refa3_not872 : ~ @Equation872 Fin7 refa3_inst.
Proof. unfold Equation872. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa3_inst, refa3_op in H. discriminate H. Qed.

Lemma refa3_not879 : ~ @Equation879 Fin7 refa3_inst.
Proof. unfold Equation879. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa3_inst, refa3_op in H. discriminate H. Qed.

Lemma refa3_not1434 : ~ @Equation1434 Fin7 refa3_inst.
Proof. unfold Equation1434. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa3_inst, refa3_op in H. discriminate H. Qed.

Lemma refa3_not1444 : ~ @Equation1444 Fin7 refa3_inst.
Proof. unfold Equation1444. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa3_inst, refa3_op in H. discriminate H. Qed.

Lemma refa3_not1451 : ~ @Equation1451 Fin7 refa3_inst.
Proof. unfold Equation1451. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa3_inst, refa3_op in H. discriminate H. Qed.

Lemma refa3_not1478 : ~ @Equation1478 Fin7 refa3_inst.
Proof. unfold Equation1478. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa3_inst, refa3_op in H. discriminate H. Qed.

Lemma refa3_not1491 : ~ @Equation1491 Fin7 refa3_inst.
Proof. unfold Equation1491. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa3_inst, refa3_op in H. discriminate H. Qed.

Lemma refa3_not1518 : ~ @Equation1518 Fin7 refa3_inst.
Proof. unfold Equation1518. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa3_inst, refa3_op in H. discriminate H. Qed.

Lemma refa3_not1648 : ~ @Equation1648 Fin7 refa3_inst.
Proof. unfold Equation1648. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa3_inst, refa3_op in H. discriminate H. Qed.

Lemma refa3_not1654 : ~ @Equation1654 Fin7 refa3_inst.
Proof. unfold Equation1654. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa3_inst, refa3_op in H. discriminate H. Qed.

Lemma refa3_not1655 : ~ @Equation1655 Fin7 refa3_inst.
Proof. unfold Equation1655. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa3_inst, refa3_op in H. discriminate H. Qed.

Lemma refa3_not1657 : ~ @Equation1657 Fin7 refa3_inst.
Proof. unfold Equation1657. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa3_inst, refa3_op in H. discriminate H. Qed.

Lemma refa3_not1833 : ~ @Equation1833 Fin7 refa3_inst.
Proof. unfold Equation1833. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa3_inst, refa3_op in H. discriminate H. Qed.

Lemma refa3_not1834 : ~ @Equation1834 Fin7 refa3_inst.
Proof. unfold Equation1834. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa3_inst, refa3_op in H. discriminate H. Qed.

Lemma refa3_not1837 : ~ @Equation1837 Fin7 refa3_inst.
Proof. unfold Equation1837. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa3_inst, refa3_op in H. discriminate H. Qed.

Lemma refa3_not1838 : ~ @Equation1838 Fin7 refa3_inst.
Proof. unfold Equation1838. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa3_inst, refa3_op in H. discriminate H. Qed.

Lemma refa3_not1840 : ~ @Equation1840 Fin7 refa3_inst.
Proof. unfold Equation1840. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa3_inst, refa3_op in H. discriminate H. Qed.

Lemma refa3_not1841 : ~ @Equation1841 Fin7 refa3_inst.
Proof. unfold Equation1841. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa3_inst, refa3_op in H. discriminate H. Qed.

Lemma refa3_not1847 : ~ @Equation1847 Fin7 refa3_inst.
Proof. unfold Equation1847. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa3_inst, refa3_op in H. discriminate H. Qed.

Lemma refa3_not1851 : ~ @Equation1851 Fin7 refa3_inst.
Proof. unfold Equation1851. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa3_inst, refa3_op in H. discriminate H. Qed.

Lemma refa3_not1857 : ~ @Equation1857 Fin7 refa3_inst.
Proof. unfold Equation1857. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa3_inst, refa3_op in H. discriminate H. Qed.

Lemma refa3_not1858 : ~ @Equation1858 Fin7 refa3_inst.
Proof. unfold Equation1858. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa3_inst, refa3_op in H. discriminate H. Qed.

Lemma refa3_not1860 : ~ @Equation1860 Fin7 refa3_inst.
Proof. unfold Equation1860. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa3_inst, refa3_op in H. discriminate H. Qed.

Lemma refa3_not1861 : ~ @Equation1861 Fin7 refa3_inst.
Proof. unfold Equation1861. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa3_inst, refa3_op in H. discriminate H. Qed.

Lemma refa3_not2240 : ~ @Equation2240 Fin7 refa3_inst.
Proof. unfold Equation2240. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa3_inst, refa3_op in H. discriminate H. Qed.

Lemma refa3_not2241 : ~ @Equation2241 Fin7 refa3_inst.
Proof. unfold Equation2241. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa3_inst, refa3_op in H. discriminate H. Qed.

Lemma refa3_not2243 : ~ @Equation2243 Fin7 refa3_inst.
Proof. unfold Equation2243. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa3_inst, refa3_op in H. discriminate H. Qed.

Lemma refa3_not2244 : ~ @Equation2244 Fin7 refa3_inst.
Proof. unfold Equation2244. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa3_inst, refa3_op in H. discriminate H. Qed.

Lemma refa3_not2246 : ~ @Equation2246 Fin7 refa3_inst.
Proof. unfold Equation2246. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa3_inst, refa3_op in H. discriminate H. Qed.

Lemma refa3_not2247 : ~ @Equation2247 Fin7 refa3_inst.
Proof. unfold Equation2247. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa3_inst, refa3_op in H. discriminate H. Qed.

Lemma refa3_not2253 : ~ @Equation2253 Fin7 refa3_inst.
Proof. unfold Equation2253. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa3_inst, refa3_op in H. discriminate H. Qed.

Lemma refa3_not2254 : ~ @Equation2254 Fin7 refa3_inst.
Proof. unfold Equation2254. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa3_inst, refa3_op in H. discriminate H. Qed.

Lemma refa3_not2257 : ~ @Equation2257 Fin7 refa3_inst.
Proof. unfold Equation2257. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa3_inst, refa3_op in H. discriminate H. Qed.

Lemma refa3_not2263 : ~ @Equation2263 Fin7 refa3_inst.
Proof. unfold Equation2263. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa3_inst, refa3_op in H. discriminate H. Qed.

Lemma refa3_not2264 : ~ @Equation2264 Fin7 refa3_inst.
Proof. unfold Equation2264. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa3_inst, refa3_op in H. discriminate H. Qed.

Lemma refa3_not2266 : ~ @Equation2266 Fin7 refa3_inst.
Proof. unfold Equation2266. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa3_inst, refa3_op in H. discriminate H. Qed.

Lemma refa3_not2267 : ~ @Equation2267 Fin7 refa3_inst.
Proof. unfold Equation2267. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa3_inst, refa3_op in H. discriminate H. Qed.

Lemma refa3_not2443 : ~ @Equation2443 Fin7 refa3_inst.
Proof. unfold Equation2443. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa3_inst, refa3_op in H. discriminate H. Qed.

Lemma refa3_not2444 : ~ @Equation2444 Fin7 refa3_inst.
Proof. unfold Equation2444. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa3_inst, refa3_op in H. discriminate H. Qed.

Lemma refa3_not2446 : ~ @Equation2446 Fin7 refa3_inst.
Proof. unfold Equation2446. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa3_inst, refa3_op in H. discriminate H. Qed.

Lemma refa3_not2447 : ~ @Equation2447 Fin7 refa3_inst.
Proof. unfold Equation2447. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa3_inst, refa3_op in H. discriminate H. Qed.

Lemma refa3_not2449 : ~ @Equation2449 Fin7 refa3_inst.
Proof. unfold Equation2449. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa3_inst, refa3_op in H. discriminate H. Qed.

Lemma refa3_not2456 : ~ @Equation2456 Fin7 refa3_inst.
Proof. unfold Equation2456. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa3_inst, refa3_op in H. discriminate H. Qed.

Lemma refa3_not2460 : ~ @Equation2460 Fin7 refa3_inst.
Proof. unfold Equation2460. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa3_inst, refa3_op in H. discriminate H. Qed.

Lemma refa3_not2466 : ~ @Equation2466 Fin7 refa3_inst.
Proof. unfold Equation2466. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa3_inst, refa3_op in H. discriminate H. Qed.

Lemma refa3_not2467 : ~ @Equation2467 Fin7 refa3_inst.
Proof. unfold Equation2467. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa3_inst, refa3_op in H. discriminate H. Qed.

Lemma refa3_not2469 : ~ @Equation2469 Fin7 refa3_inst.
Proof. unfold Equation2469. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa3_inst, refa3_op in H. discriminate H. Qed.

Lemma refa3_not2470 : ~ @Equation2470 Fin7 refa3_inst.
Proof. unfold Equation2470. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa3_inst, refa3_op in H. discriminate H. Qed.

Lemma refa3_not3052 : ~ @Equation3052 Fin7 refa3_inst.
Proof. unfold Equation3052. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa3_inst, refa3_op in H. discriminate H. Qed.

Lemma refa3_not3055 : ~ @Equation3055 Fin7 refa3_inst.
Proof. unfold Equation3055. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa3_inst, refa3_op in H. discriminate H. Qed.

Lemma refa3_not3056 : ~ @Equation3056 Fin7 refa3_inst.
Proof. unfold Equation3056. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa3_inst, refa3_op in H. discriminate H. Qed.

Lemma refa3_not3058 : ~ @Equation3058 Fin7 refa3_inst.
Proof. unfold Equation3058. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa3_inst, refa3_op in H. discriminate H. Qed.

Lemma refa3_not3065 : ~ @Equation3065 Fin7 refa3_inst.
Proof. unfold Equation3065. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa3_inst, refa3_op in H. discriminate H. Qed.

Lemma refa3_not3068 : ~ @Equation3068 Fin7 refa3_inst.
Proof. unfold Equation3068. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa3_inst, refa3_op in H. discriminate H. Qed.

Lemma refa3_not3069 : ~ @Equation3069 Fin7 refa3_inst.
Proof. unfold Equation3069. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa3_inst, refa3_op in H. discriminate H. Qed.

Lemma refa3_not3075 : ~ @Equation3075 Fin7 refa3_inst.
Proof. unfold Equation3075. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa3_inst, refa3_op in H. discriminate H. Qed.

Lemma refa3_not3076 : ~ @Equation3076 Fin7 refa3_inst.
Proof. unfold Equation3076. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa3_inst, refa3_op in H. discriminate H. Qed.

Lemma refa3_not3078 : ~ @Equation3078 Fin7 refa3_inst.
Proof. unfold Equation3078. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa3_inst, refa3_op in H. discriminate H. Qed.

Lemma refa3_not3079 : ~ @Equation3079 Fin7 refa3_inst.
Proof. unfold Equation3079. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa3_inst, refa3_op in H. discriminate H. Qed.

Lemma refa3_not3258 : ~ @Equation3258 Fin7 refa3_inst.
Proof. unfold Equation3258. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa3_inst, refa3_op in H. discriminate H. Qed.

Lemma refa3_not3261 : ~ @Equation3261 Fin7 refa3_inst.
Proof. unfold Equation3261. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa3_inst, refa3_op in H. discriminate H. Qed.

Lemma refa3_not3262 : ~ @Equation3262 Fin7 refa3_inst.
Proof. unfold Equation3262. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa3_inst, refa3_op in H. discriminate H. Qed.

Lemma refa3_not3306 : ~ @Equation3306 Fin7 refa3_inst.
Proof. unfold Equation3306. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa3_inst, refa3_op in H. discriminate H. Qed.

Lemma refa3_not3309 : ~ @Equation3309 Fin7 refa3_inst.
Proof. unfold Equation3309. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa3_inst, refa3_op in H. discriminate H. Qed.

Lemma refa3_not3461 : ~ @Equation3461 Fin7 refa3_inst.
Proof. unfold Equation3461. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa3_inst, refa3_op in H. discriminate H. Qed.

Lemma refa3_not3464 : ~ @Equation3464 Fin7 refa3_inst.
Proof. unfold Equation3464. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa3_inst, refa3_op in H. discriminate H. Qed.

Lemma refa3_not3465 : ~ @Equation3465 Fin7 refa3_inst.
Proof. unfold Equation3465. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa3_inst, refa3_op in H. discriminate H. Qed.

Lemma refa3_not3509 : ~ @Equation3509 Fin7 refa3_inst.
Proof. unfold Equation3509. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa3_inst, refa3_op in H. discriminate H. Qed.

Lemma refa3_not3512 : ~ @Equation3512 Fin7 refa3_inst.
Proof. unfold Equation3512. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa3_inst, refa3_op in H. discriminate H. Qed.

Lemma refa3_not3867 : ~ @Equation3867 Fin7 refa3_inst.
Proof. unfold Equation3867. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa3_inst, refa3_op in H. discriminate H. Qed.

Lemma refa3_not3877 : ~ @Equation3877 Fin7 refa3_inst.
Proof. unfold Equation3877. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa3_inst, refa3_op in H. discriminate H. Qed.

Lemma refa3_not3887 : ~ @Equation3887 Fin7 refa3_inst.
Proof. unfold Equation3887. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa3_inst, refa3_op in H. discriminate H. Qed.

Lemma refa3_not3925 : ~ @Equation3925 Fin7 refa3_inst.
Proof. unfold Equation3925. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa3_inst, refa3_op in H. discriminate H. Qed.

Lemma refa3_not3952 : ~ @Equation3952 Fin7 refa3_inst.
Proof. unfold Equation3952. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa3_inst, refa3_op in H. discriminate H. Qed.

Lemma refa3_not4066 : ~ @Equation4066 Fin7 refa3_inst.
Proof. unfold Equation4066. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa3_inst, refa3_op in H. discriminate H. Qed.

Lemma refa3_not4067 : ~ @Equation4067 Fin7 refa3_inst.
Proof. unfold Equation4067. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa3_inst, refa3_op in H. discriminate H. Qed.

Lemma refa3_not4068 : ~ @Equation4068 Fin7 refa3_inst.
Proof. unfold Equation4068. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa3_inst, refa3_op in H. discriminate H. Qed.

Lemma refa3_not4070 : ~ @Equation4070 Fin7 refa3_inst.
Proof. unfold Equation4070. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa3_inst, refa3_op in H. discriminate H. Qed.

Lemma refa3_not4071 : ~ @Equation4071 Fin7 refa3_inst.
Proof. unfold Equation4071. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa3_inst, refa3_op in H. discriminate H. Qed.

Lemma refa3_not4073 : ~ @Equation4073 Fin7 refa3_inst.
Proof. unfold Equation4073. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa3_inst, refa3_op in H. discriminate H. Qed.

Lemma refa3_not4074 : ~ @Equation4074 Fin7 refa3_inst.
Proof. unfold Equation4074. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa3_inst, refa3_op in H. discriminate H. Qed.

Lemma refa3_not4080 : ~ @Equation4080 Fin7 refa3_inst.
Proof. unfold Equation4080. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa3_inst, refa3_op in H. discriminate H. Qed.

Lemma refa3_not4090 : ~ @Equation4090 Fin7 refa3_inst.
Proof. unfold Equation4090. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa3_inst, refa3_op in H. discriminate H. Qed.

Lemma refa3_not4120 : ~ @Equation4120 Fin7 refa3_inst.
Proof. unfold Equation4120. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa3_inst, refa3_op in H. discriminate H. Qed.

Lemma refa3_not4121 : ~ @Equation4121 Fin7 refa3_inst.
Proof. unfold Equation4121. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa3_inst, refa3_op in H. discriminate H. Qed.

Lemma refa3_not4127 : ~ @Equation4127 Fin7 refa3_inst.
Proof. unfold Equation4127. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa3_inst, refa3_op in H. discriminate H. Qed.

Lemma refa3_not4128 : ~ @Equation4128 Fin7 refa3_inst.
Proof. unfold Equation4128. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa3_inst, refa3_op in H. discriminate H. Qed.

Lemma refa3_not4130 : ~ @Equation4130 Fin7 refa3_inst.
Proof. unfold Equation4130. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa3_inst, refa3_op in H. discriminate H. Qed.

Lemma refa3_not4131 : ~ @Equation4131 Fin7 refa3_inst.
Proof. unfold Equation4131. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa3_inst, refa3_op in H. discriminate H. Qed.

Lemma refa3_not4165 : ~ @Equation4165 Fin7 refa3_inst.
Proof. unfold Equation4165. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa3_inst, refa3_op in H. discriminate H. Qed.

Lemma refa3_not4269 : ~ @Equation4269 Fin7 refa3_inst.
Proof. unfold Equation4269. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa3_inst, refa3_op in H. discriminate H. Qed.

Lemma refa3_not4270 : ~ @Equation4270 Fin7 refa3_inst.
Proof. unfold Equation4270. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa3_inst, refa3_op in H. discriminate H. Qed.

Lemma refa3_not4275 : ~ @Equation4275 Fin7 refa3_inst.
Proof. unfold Equation4275. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa3_inst, refa3_op in H. discriminate H. Qed.

Lemma refa3_not4283 : ~ @Equation4283 Fin7 refa3_inst.
Proof. unfold Equation4283. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa3_inst, refa3_op in H. discriminate H. Qed.

Lemma refa3_not4284 : ~ @Equation4284 Fin7 refa3_inst.
Proof. unfold Equation4284. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa3_inst, refa3_op in H. discriminate H. Qed.

Lemma refa3_not4320 : ~ @Equation4320 Fin7 refa3_inst.
Proof. unfold Equation4320. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa3_inst, refa3_op in H. discriminate H. Qed.

Lemma refa3_not4583 : ~ @Equation4583 Fin7 refa3_inst.
Proof. unfold Equation4583. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa3_inst, refa3_op in H. discriminate H. Qed.

Lemma refa3_not4584 : ~ @Equation4584 Fin7 refa3_inst.
Proof. unfold Equation4584. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa3_inst, refa3_op in H. discriminate H. Qed.

Lemma refa3_not4587 : ~ @Equation4587 Fin7 refa3_inst.
Proof. unfold Equation4587. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa3_inst, refa3_op in H. discriminate H. Qed.

Lemma refa3_not4599 : ~ @Equation4599 Fin7 refa3_inst.
Proof. unfold Equation4599. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa3_inst, refa3_op in H. discriminate H. Qed.

Lemma refa3_not4606 : ~ @Equation4606 Fin7 refa3_inst.
Proof. unfold Equation4606. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa3_inst, refa3_op in H. discriminate H. Qed.

Lemma refa3_not4629 : ~ @Equation4629 Fin7 refa3_inst.
Proof. unfold Equation4629. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa3_inst, refa3_op in H. discriminate H. Qed.

(** ---- refa30 (Fin9) ---- *)

Definition refa30_op (x y : Fin9) : Fin9 :=
  match x, y with
  | F9_0, F9_0 => F9_0 | F9_0, F9_1 => F9_2 | F9_0, F9_2 => F9_1 | F9_0, F9_3 => F9_4 | F9_0, F9_4 => F9_3 | F9_0, F9_5 => F9_6 | F9_0, F9_6 => F9_5 | F9_0, F9_7 => F9_8 | F9_0, F9_8 => F9_7
  | F9_1, F9_0 => F9_3 | F9_1, F9_1 => F9_1 | F9_1, F9_2 => F9_5 | F9_1, F9_3 => F9_0 | F9_1, F9_4 => F9_7 | F9_1, F9_5 => F9_2 | F9_1, F9_6 => F9_8 | F9_1, F9_7 => F9_4 | F9_1, F9_8 => F9_6
  | F9_2, F9_0 => F9_4 | F9_2, F9_1 => F9_6 | F9_2, F9_2 => F9_8 | F9_2, F9_3 => F9_3 | F9_2, F9_4 => F9_0 | F9_2, F9_5 => F9_7 | F9_2, F9_6 => F9_1 | F9_2, F9_7 => F9_5 | F9_2, F9_8 => F9_2
  | F9_3, F9_0 => F9_7 | F9_3, F9_1 => F9_5 | F9_3, F9_2 => F9_3 | F9_3, F9_3 => F9_2 | F9_3, F9_4 => F9_6 | F9_3, F9_5 => F9_1 | F9_3, F9_6 => F9_4 | F9_3, F9_7 => F9_0 | F9_3, F9_8 => F9_8
  | F9_4, F9_0 => F9_8 | F9_4, F9_1 => F9_7 | F9_4, F9_2 => F9_6 | F9_4, F9_3 => F9_5 | F9_4, F9_4 => F9_4 | F9_4, F9_5 => F9_3 | F9_4, F9_6 => F9_2 | F9_4, F9_7 => F9_1 | F9_4, F9_8 => F9_0
  | F9_5, F9_0 => F9_6 | F9_5, F9_1 => F9_8 | F9_5, F9_2 => F9_4 | F9_5, F9_3 => F9_7 | F9_5, F9_4 => F9_2 | F9_5, F9_5 => F9_5 | F9_5, F9_6 => F9_0 | F9_5, F9_7 => F9_3 | F9_5, F9_8 => F9_1
  | F9_6, F9_0 => F9_5 | F9_6, F9_1 => F9_3 | F9_6, F9_2 => F9_7 | F9_6, F9_3 => F9_1 | F9_6, F9_4 => F9_8 | F9_6, F9_5 => F9_0 | F9_6, F9_6 => F9_6 | F9_6, F9_7 => F9_2 | F9_6, F9_8 => F9_4
  | F9_7, F9_0 => F9_2 | F9_7, F9_1 => F9_4 | F9_7, F9_2 => F9_0 | F9_7, F9_3 => F9_6 | F9_7, F9_4 => F9_1 | F9_7, F9_5 => F9_8 | F9_7, F9_6 => F9_3 | F9_7, F9_7 => F9_7 | F9_7, F9_8 => F9_5
  | F9_8, F9_0 => F9_1 | F9_8, F9_1 => F9_0 | F9_8, F9_2 => F9_2 | F9_8, F9_3 => F9_8 | F9_8, F9_4 => F9_5 | F9_8, F9_5 => F9_4 | F9_8, F9_6 => F9_7 | F9_8, F9_7 => F9_6 | F9_8, F9_8 => F9_3
  end.

#[local] Instance refa30_inst : Magma Fin9 := {| magma_op := refa30_op |}.

Lemma refa30_sat2913 : @Equation2913 Fin9 refa30_inst.
Proof. unfold Equation2913, magma_op, refa30_inst, refa30_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa30_not440 : ~ @Equation440 Fin9 refa30_inst.
Proof. unfold Equation440. intro H. specialize (H F9_0 F9_1). unfold magma_op, refa30_inst, refa30_op in H. discriminate H. Qed.

Lemma refa30_not464 : ~ @Equation464 Fin9 refa30_inst.
Proof. unfold Equation464. intro H. specialize (H F9_0 F9_1). unfold magma_op, refa30_inst, refa30_op in H. discriminate H. Qed.

Lemma refa30_not477 : ~ @Equation477 Fin9 refa30_inst.
Proof. unfold Equation477. intro H. specialize (H F9_0 F9_1). unfold magma_op, refa30_inst, refa30_op in H. discriminate H. Qed.

Lemma refa30_not504 : ~ @Equation504 Fin9 refa30_inst.
Proof. unfold Equation504. intro H. specialize (H F9_0 F9_1). unfold magma_op, refa30_inst, refa30_op in H. discriminate H. Qed.

Lemma refa30_not511 : ~ @Equation511 Fin9 refa30_inst.
Proof. unfold Equation511. intro H. specialize (H F9_0 F9_1). unfold magma_op, refa30_inst, refa30_op in H. discriminate H. Qed.

Lemma refa30_not643 : ~ @Equation643 Fin9 refa30_inst.
Proof. unfold Equation643. intro H. specialize (H F9_0 F9_1). unfold magma_op, refa30_inst, refa30_op in H. discriminate H. Qed.

Lemma refa30_not667 : ~ @Equation667 Fin9 refa30_inst.
Proof. unfold Equation667. intro H. specialize (H F9_0 F9_1). unfold magma_op, refa30_inst, refa30_op in H. discriminate H. Qed.

Lemma refa30_not680 : ~ @Equation680 Fin9 refa30_inst.
Proof. unfold Equation680. intro H. specialize (H F9_0 F9_1). unfold magma_op, refa30_inst, refa30_op in H. discriminate H. Qed.

Lemma refa30_not707 : ~ @Equation707 Fin9 refa30_inst.
Proof. unfold Equation707. intro H. specialize (H F9_0 F9_1). unfold magma_op, refa30_inst, refa30_op in H. discriminate H. Qed.

Lemma refa30_not817 : ~ @Equation817 Fin9 refa30_inst.
Proof. unfold Equation817. intro H. specialize (H F9_2). unfold magma_op, refa30_inst, refa30_op in H. discriminate H. Qed.

Lemma refa30_not1049 : ~ @Equation1049 Fin9 refa30_inst.
Proof. unfold Equation1049. intro H. specialize (H F9_0 F9_1). unfold magma_op, refa30_inst, refa30_op in H. discriminate H. Qed.

Lemma refa30_not1086 : ~ @Equation1086 Fin9 refa30_inst.
Proof. unfold Equation1086. intro H. specialize (H F9_0 F9_1). unfold magma_op, refa30_inst, refa30_op in H. discriminate H. Qed.

Lemma refa30_not1113 : ~ @Equation1113 Fin9 refa30_inst.
Proof. unfold Equation1113. intro H. specialize (H F9_0 F9_1). unfold magma_op, refa30_inst, refa30_op in H. discriminate H. Qed.

Lemma refa30_not1171 : ~ @Equation1171 Fin9 refa30_inst.
Proof. unfold Equation1171. intro H. specialize (H F9_0 F9_0 F9_1). unfold magma_op, refa30_inst, refa30_op in H. discriminate H. Qed.

Lemma refa30_not1248 : ~ @Equation1248 Fin9 refa30_inst.
Proof. unfold Equation1248. intro H. specialize (H F9_0 F9_1). unfold magma_op, refa30_inst, refa30_op in H. discriminate H. Qed.

Lemma refa30_not1252 : ~ @Equation1252 Fin9 refa30_inst.
Proof. unfold Equation1252. intro H. specialize (H F9_0 F9_1). unfold magma_op, refa30_inst, refa30_op in H. discriminate H. Qed.

Lemma refa30_not1278 : ~ @Equation1278 Fin9 refa30_inst.
Proof. unfold Equation1278. intro H. specialize (H F9_0 F9_1). unfold magma_op, refa30_inst, refa30_op in H. discriminate H. Qed.

Lemma refa30_not1285 : ~ @Equation1285 Fin9 refa30_inst.
Proof. unfold Equation1285. intro H. specialize (H F9_0 F9_1). unfold magma_op, refa30_inst, refa30_op in H. discriminate H. Qed.

Lemma refa30_not1312 : ~ @Equation1312 Fin9 refa30_inst.
Proof. unfold Equation1312. intro H. specialize (H F9_0 F9_1). unfold magma_op, refa30_inst, refa30_op in H. discriminate H. Qed.

Lemma refa30_not1429 : ~ @Equation1429 Fin9 refa30_inst.
Proof. unfold Equation1429. intro H. specialize (H F9_0 F9_1). unfold magma_op, refa30_inst, refa30_op in H. discriminate H. Qed.

Lemma refa30_not1519 : ~ @Equation1519 Fin9 refa30_inst.
Proof. unfold Equation1519. intro H. specialize (H F9_0 F9_1). unfold magma_op, refa30_inst, refa30_op in H. discriminate H. Qed.

Lemma refa30_not1658 : ~ @Equation1658 Fin9 refa30_inst.
Proof. unfold Equation1658. intro H. specialize (H F9_0 F9_1). unfold magma_op, refa30_inst, refa30_op in H. discriminate H. Qed.

Lemma refa30_not1722 : ~ @Equation1722 Fin9 refa30_inst.
Proof. unfold Equation1722. intro H. specialize (H F9_0 F9_1). unfold magma_op, refa30_inst, refa30_op in H. discriminate H. Qed.

Lemma refa30_not1793 : ~ @Equation1793 Fin9 refa30_inst.
Proof. unfold Equation1793. intro H. specialize (H F9_0 F9_0 F9_1). unfold magma_op, refa30_inst, refa30_op in H. discriminate H. Qed.

Lemma refa30_not1861 : ~ @Equation1861 Fin9 refa30_inst.
Proof. unfold Equation1861. intro H. specialize (H F9_0 F9_1). unfold magma_op, refa30_inst, refa30_op in H. discriminate H. Qed.

Lemma refa30_not1925 : ~ @Equation1925 Fin9 refa30_inst.
Proof. unfold Equation1925. intro H. specialize (H F9_0 F9_1). unfold magma_op, refa30_inst, refa30_op in H. discriminate H. Qed.

Lemma refa30_not2124 : ~ @Equation2124 Fin9 refa30_inst.
Proof. unfold Equation2124. intro H. specialize (H F9_0 F9_1). unfold magma_op, refa30_inst, refa30_op in H. discriminate H. Qed.

Lemma refa30_not2128 : ~ @Equation2128 Fin9 refa30_inst.
Proof. unfold Equation2128. intro H. specialize (H F9_0 F9_1). unfold magma_op, refa30_inst, refa30_op in H. discriminate H. Qed.

Lemma refa30_not2241 : ~ @Equation2241 Fin9 refa30_inst.
Proof. unfold Equation2241. intro H. specialize (H F9_0 F9_1). unfold magma_op, refa30_inst, refa30_op in H. discriminate H. Qed.

Lemma refa30_not2246 : ~ @Equation2246 Fin9 refa30_inst.
Proof. unfold Equation2246. intro H. specialize (H F9_0 F9_1). unfold magma_op, refa30_inst, refa30_op in H. discriminate H. Qed.

Lemma refa30_not2254 : ~ @Equation2254 Fin9 refa30_inst.
Proof. unfold Equation2254. intro H. specialize (H F9_0 F9_1). unfold magma_op, refa30_inst, refa30_op in H. discriminate H. Qed.

Lemma refa30_not2267 : ~ @Equation2267 Fin9 refa30_inst.
Proof. unfold Equation2267. intro H. specialize (H F9_0 F9_1). unfold magma_op, refa30_inst, refa30_op in H. discriminate H. Qed.

Lemma refa30_not2338 : ~ @Equation2338 Fin9 refa30_inst.
Proof. unfold Equation2338. intro H. specialize (H F9_0 F9_1). unfold magma_op, refa30_inst, refa30_op in H. discriminate H. Qed.

Lemma refa30_not2340 : ~ @Equation2340 Fin9 refa30_inst.
Proof. unfold Equation2340. intro H. specialize (H F9_0 F9_1). unfold magma_op, refa30_inst, refa30_op in H. discriminate H. Qed.

Lemma refa30_not2534 : ~ @Equation2534 Fin9 refa30_inst.
Proof. unfold Equation2534. intro H. specialize (H F9_0 F9_1). unfold magma_op, refa30_inst, refa30_op in H. discriminate H. Qed.

Lemma refa30_not2541 : ~ @Equation2541 Fin9 refa30_inst.
Proof. unfold Equation2541. intro H. specialize (H F9_0 F9_1). unfold magma_op, refa30_inst, refa30_op in H. discriminate H. Qed.

Lemma refa30_not2543 : ~ @Equation2543 Fin9 refa30_inst.
Proof. unfold Equation2543. intro H. specialize (H F9_0 F9_1). unfold magma_op, refa30_inst, refa30_op in H. discriminate H. Qed.

Lemma refa30_not2644 : ~ @Equation2644 Fin9 refa30_inst.
Proof. unfold Equation2644. intro H. specialize (H F9_2). unfold magma_op, refa30_inst, refa30_op in H. discriminate H. Qed.

Lemma refa30_not2853 : ~ @Equation2853 Fin9 refa30_inst.
Proof. unfold Equation2853. intro H. specialize (H F9_0 F9_1). unfold magma_op, refa30_inst, refa30_op in H. discriminate H. Qed.

Lemma refa30_not2940 : ~ @Equation2940 Fin9 refa30_inst.
Proof. unfold Equation2940. intro H. specialize (H F9_0 F9_1). unfold magma_op, refa30_inst, refa30_op in H. discriminate H. Qed.

Lemma refa30_not2947 : ~ @Equation2947 Fin9 refa30_inst.
Proof. unfold Equation2947. intro H. specialize (H F9_0 F9_1). unfold magma_op, refa30_inst, refa30_op in H. discriminate H. Qed.

Lemma refa30_not2949 : ~ @Equation2949 Fin9 refa30_inst.
Proof. unfold Equation2949. intro H. specialize (H F9_0 F9_1). unfold magma_op, refa30_inst, refa30_op in H. discriminate H. Qed.

Lemma refa30_not3056 : ~ @Equation3056 Fin9 refa30_inst.
Proof. unfold Equation3056. intro H. specialize (H F9_0 F9_1). unfold magma_op, refa30_inst, refa30_op in H. discriminate H. Qed.

Lemma refa30_not3068 : ~ @Equation3068 Fin9 refa30_inst.
Proof. unfold Equation3068. intro H. specialize (H F9_0 F9_1). unfold magma_op, refa30_inst, refa30_op in H. discriminate H. Qed.

Lemma refa30_not3079 : ~ @Equation3079 Fin9 refa30_inst.
Proof. unfold Equation3079. intro H. specialize (H F9_0 F9_1). unfold magma_op, refa30_inst, refa30_op in H. discriminate H. Qed.

Lemma refa30_not3103 : ~ @Equation3103 Fin9 refa30_inst.
Proof. unfold Equation3103. intro H. specialize (H F9_0 F9_1). unfold magma_op, refa30_inst, refa30_op in H. discriminate H. Qed.

Lemma refa30_not3143 : ~ @Equation3143 Fin9 refa30_inst.
Proof. unfold Equation3143. intro H. specialize (H F9_0 F9_1). unfold magma_op, refa30_inst, refa30_op in H. discriminate H. Qed.

Lemma refa30_not3150 : ~ @Equation3150 Fin9 refa30_inst.
Proof. unfold Equation3150. intro H. specialize (H F9_0 F9_1). unfold magma_op, refa30_inst, refa30_op in H. discriminate H. Qed.

Lemma refa30_not3152 : ~ @Equation3152 Fin9 refa30_inst.
Proof. unfold Equation3152. intro H. specialize (H F9_0 F9_1). unfold magma_op, refa30_inst, refa30_op in H. discriminate H. Qed.

Lemma refa30_not3271 : ~ @Equation3271 Fin9 refa30_inst.
Proof. unfold Equation3271. intro H. specialize (H F9_0 F9_1). unfold magma_op, refa30_inst, refa30_op in H. discriminate H. Qed.

Lemma refa30_not3342 : ~ @Equation3342 Fin9 refa30_inst.
Proof. unfold Equation3342. intro H. specialize (H F9_0 F9_1). unfold magma_op, refa30_inst, refa30_op in H. discriminate H. Qed.

Lemma refa30_not3346 : ~ @Equation3346 Fin9 refa30_inst.
Proof. unfold Equation3346. intro H. specialize (H F9_0 F9_1). unfold magma_op, refa30_inst, refa30_op in H. discriminate H. Qed.

Lemma refa30_not3464 : ~ @Equation3464 Fin9 refa30_inst.
Proof. unfold Equation3464. intro H. specialize (H F9_0 F9_1). unfold magma_op, refa30_inst, refa30_op in H. discriminate H. Qed.

Lemma refa30_not3509 : ~ @Equation3509 Fin9 refa30_inst.
Proof. unfold Equation3509. intro H. specialize (H F9_0 F9_1). unfold magma_op, refa30_inst, refa30_op in H. discriminate H. Qed.

Lemma refa30_not3545 : ~ @Equation3545 Fin9 refa30_inst.
Proof. unfold Equation3545. intro H. specialize (H F9_0 F9_1). unfold magma_op, refa30_inst, refa30_op in H. discriminate H. Qed.

Lemma refa30_not3601 : ~ @Equation3601 Fin9 refa30_inst.
Proof. unfold Equation3601. intro H. specialize (H F9_0 F9_0 F9_1). unfold magma_op, refa30_inst, refa30_op in H. discriminate H. Qed.

Lemma refa30_not3964 : ~ @Equation3964 Fin9 refa30_inst.
Proof. unfold Equation3964. intro H. specialize (H F9_0 F9_1). unfold magma_op, refa30_inst, refa30_op in H. discriminate H. Qed.

Lemma refa30_not4071 : ~ @Equation4071 Fin9 refa30_inst.
Proof. unfold Equation4071. intro H. specialize (H F9_0 F9_1). unfold magma_op, refa30_inst, refa30_op in H. discriminate H. Qed.

Lemma refa30_not4120 : ~ @Equation4120 Fin9 refa30_inst.
Proof. unfold Equation4120. intro H. specialize (H F9_0 F9_1). unfold magma_op, refa30_inst, refa30_op in H. discriminate H. Qed.

Lemma refa30_not4167 : ~ @Equation4167 Fin9 refa30_inst.
Proof. unfold Equation4167. intro H. specialize (H F9_0 F9_1). unfold magma_op, refa30_inst, refa30_op in H. discriminate H. Qed.

Lemma refa30_not4283 : ~ @Equation4283 Fin9 refa30_inst.
Proof. unfold Equation4283. intro H. specialize (H F9_0 F9_1). unfold magma_op, refa30_inst, refa30_op in H. discriminate H. Qed.

Lemma refa30_not4290 : ~ @Equation4290 Fin9 refa30_inst.
Proof. unfold Equation4290. intro H. specialize (H F9_0 F9_1). unfold magma_op, refa30_inst, refa30_op in H. discriminate H. Qed.

Lemma refa30_not4320 : ~ @Equation4320 Fin9 refa30_inst.
Proof. unfold Equation4320. intro H. specialize (H F9_0 F9_1). unfold magma_op, refa30_inst, refa30_op in H. discriminate H. Qed.

Lemma refa30_not4396 : ~ @Equation4396 Fin9 refa30_inst.
Proof. unfold Equation4396. intro H. specialize (H F9_0 F9_1). unfold magma_op, refa30_inst, refa30_op in H. discriminate H. Qed.

Lemma refa30_not4398 : ~ @Equation4398 Fin9 refa30_inst.
Proof. unfold Equation4398. intro H. specialize (H F9_0 F9_1). unfold magma_op, refa30_inst, refa30_op in H. discriminate H. Qed.

Lemma refa30_not4405 : ~ @Equation4405 Fin9 refa30_inst.
Proof. unfold Equation4405. intro H. specialize (H F9_0 F9_1). unfold magma_op, refa30_inst, refa30_op in H. discriminate H. Qed.

Lemma refa30_not4433 : ~ @Equation4433 Fin9 refa30_inst.
Proof. unfold Equation4433. intro H. specialize (H F9_0 F9_1). unfold magma_op, refa30_inst, refa30_op in H. discriminate H. Qed.

Lemma refa30_not4442 : ~ @Equation4442 Fin9 refa30_inst.
Proof. unfold Equation4442. intro H. specialize (H F9_0 F9_1). unfold magma_op, refa30_inst, refa30_op in H. discriminate H. Qed.

Lemma refa30_not4473 : ~ @Equation4473 Fin9 refa30_inst.
Proof. unfold Equation4473. intro H. specialize (H F9_0 F9_1). unfold magma_op, refa30_inst, refa30_op in H. discriminate H. Qed.

Lemma refa30_not4480 : ~ @Equation4480 Fin9 refa30_inst.
Proof. unfold Equation4480. intro H. specialize (H F9_0 F9_1). unfold magma_op, refa30_inst, refa30_op in H. discriminate H. Qed.

Lemma refa30_not4482 : ~ @Equation4482 Fin9 refa30_inst.
Proof. unfold Equation4482. intro H. specialize (H F9_0 F9_1). unfold magma_op, refa30_inst, refa30_op in H. discriminate H. Qed.

Lemma refa30_not4598 : ~ @Equation4598 Fin9 refa30_inst.
Proof. unfold Equation4598. intro H. specialize (H F9_0 F9_1). unfold magma_op, refa30_inst, refa30_op in H. discriminate H. Qed.

Lemma refa30_not4605 : ~ @Equation4605 Fin9 refa30_inst.
Proof. unfold Equation4605. intro H. specialize (H F9_0 F9_1). unfold magma_op, refa30_inst, refa30_op in H. discriminate H. Qed.

Lemma refa30_not4635 : ~ @Equation4635 Fin9 refa30_inst.
Proof. unfold Equation4635. intro H. specialize (H F9_0 F9_1). unfold magma_op, refa30_inst, refa30_op in H. discriminate H. Qed.

(** ---- refa300 (Fin4) ---- *)

Definition refa300_op (x y : Fin4) : Fin4 :=
  match x, y with
  | F4_0, F4_0 => F4_3 | F4_0, F4_1 => F4_3 | F4_0, F4_2 => F4_1 | F4_0, F4_3 => F4_1
  | F4_1, F4_0 => F4_3 | F4_1, F4_1 => F4_3 | F4_1, F4_2 => F4_1 | F4_1, F4_3 => F4_1
  | F4_2, F4_0 => F4_3 | F4_2, F4_1 => F4_1 | F4_2, F4_2 => F4_1 | F4_2, F4_3 => F4_1
  | F4_3, F4_0 => F4_1 | F4_3, F4_1 => F4_1 | F4_3, F4_2 => F4_1 | F4_3, F4_3 => F4_1
  end.

#[local] Instance refa300_inst : Magma Fin4 := {| magma_op := refa300_op |}.

Lemma refa300_sat4531 : @Equation4531 Fin4 refa300_inst.
Proof. unfold Equation4531, magma_op, refa300_inst, refa300_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa300_not4283 : ~ @Equation4283 Fin4 refa300_inst.
Proof. unfold Equation4283. intro H. specialize (H F4_0 F4_2). unfold magma_op, refa300_inst, refa300_op in H. discriminate H. Qed.

Lemma refa300_not4290 : ~ @Equation4290 Fin4 refa300_inst.
Proof. unfold Equation4290. intro H. specialize (H F4_0 F4_2). unfold magma_op, refa300_inst, refa300_op in H. discriminate H. Qed.

Lemma refa300_not4320 : ~ @Equation4320 Fin4 refa300_inst.
Proof. unfold Equation4320. intro H. specialize (H F4_0 F4_3). unfold magma_op, refa300_inst, refa300_op in H. discriminate H. Qed.

Lemma refa300_not4396 : ~ @Equation4396 Fin4 refa300_inst.
Proof. unfold Equation4396. intro H. specialize (H F4_0 F4_2). unfold magma_op, refa300_inst, refa300_op in H. discriminate H. Qed.

Lemma refa300_not4405 : ~ @Equation4405 Fin4 refa300_inst.
Proof. unfold Equation4405. intro H. specialize (H F4_0 F4_2). unfold magma_op, refa300_inst, refa300_op in H. discriminate H. Qed.

Lemma refa300_not4433 : ~ @Equation4433 Fin4 refa300_inst.
Proof. unfold Equation4433. intro H. specialize (H F4_0 F4_3). unfold magma_op, refa300_inst, refa300_op in H. discriminate H. Qed.

Lemma refa300_not4435 : ~ @Equation4435 Fin4 refa300_inst.
Proof. unfold Equation4435. intro H. specialize (H F4_0 F4_2). unfold magma_op, refa300_inst, refa300_op in H. discriminate H. Qed.

Lemma refa300_not4473 : ~ @Equation4473 Fin4 refa300_inst.
Proof. unfold Equation4473. intro H. specialize (H F4_0 F4_2). unfold magma_op, refa300_inst, refa300_op in H. discriminate H. Qed.

Lemma refa300_not4480 : ~ @Equation4480 Fin4 refa300_inst.
Proof. unfold Equation4480. intro H. specialize (H F4_0 F4_2). unfold magma_op, refa300_inst, refa300_op in H. discriminate H. Qed.

Lemma refa300_not4598 : ~ @Equation4598 Fin4 refa300_inst.
Proof. unfold Equation4598. intro H. specialize (H F4_0 F4_2). unfold magma_op, refa300_inst, refa300_op in H. discriminate H. Qed.

Lemma refa300_not4605 : ~ @Equation4605 Fin4 refa300_inst.
Proof. unfold Equation4605. intro H. specialize (H F4_0 F4_3). unfold magma_op, refa300_inst, refa300_op in H. discriminate H. Qed.

Lemma refa300_not4635 : ~ @Equation4635 Fin4 refa300_inst.
Proof. unfold Equation4635. intro H. specialize (H F4_0 F4_2). unfold magma_op, refa300_inst, refa300_op in H. discriminate H. Qed.

(** ---- refa301 (Fin4) ---- *)

Definition refa301_op (x y : Fin4) : Fin4 :=
  match x, y with
  | F4_0, F4_0 => F4_2 | F4_0, F4_1 => F4_0 | F4_0, F4_2 => F4_0 | F4_0, F4_3 => F4_3
  | F4_1, F4_0 => F4_3 | F4_1, F4_1 => F4_2 | F4_1, F4_2 => F4_1 | F4_1, F4_3 => F4_2
  | F4_2, F4_0 => F4_1 | F4_2, F4_1 => F4_2 | F4_2, F4_2 => F4_2 | F4_2, F4_3 => F4_2
  | F4_3, F4_0 => F4_2 | F4_3, F4_1 => F4_2 | F4_3, F4_2 => F4_3 | F4_3, F4_3 => F4_2
  end.

#[local] Instance refa301_inst : Magma Fin4 := {| magma_op := refa301_op |}.

Lemma refa301_sat101 : @Equation101 Fin4 refa301_inst.
Proof. unfold Equation101, magma_op, refa301_inst, refa301_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa301_sat1042 : @Equation1042 Fin4 refa301_inst.
Proof. unfold Equation1042, magma_op, refa301_inst, refa301_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa301_not1223 : ~ @Equation1223 Fin4 refa301_inst.
Proof. unfold Equation1223. intro H. specialize (H F4_0). unfold magma_op, refa301_inst, refa301_op in H. discriminate H. Qed.

Lemma refa301_not3316 : ~ @Equation3316 Fin4 refa301_inst.
Proof. unfold Equation3316. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa301_inst, refa301_op in H. discriminate H. Qed.

Lemma refa301_not3925 : ~ @Equation3925 Fin4 refa301_inst.
Proof. unfold Equation3925. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa301_inst, refa301_op in H. discriminate H. Qed.

Lemma refa301_not4065 : ~ @Equation4065 Fin4 refa301_inst.
Proof. unfold Equation4065. intro H. specialize (H F4_0). unfold magma_op, refa301_inst, refa301_op in H. discriminate H. Qed.

(** ---- refa302 (Fin4) ---- *)

Definition refa302_op (x y : Fin4) : Fin4 :=
  match x, y with
  | F4_0, F4_0 => F4_0 | F4_0, F4_1 => F4_3 | F4_0, F4_2 => F4_1 | F4_0, F4_3 => F4_3
  | F4_1, F4_0 => F4_3 | F4_1, F4_1 => F4_1 | F4_1, F4_2 => F4_2 | F4_1, F4_3 => F4_3
  | F4_2, F4_0 => F4_0 | F4_2, F4_1 => F4_1 | F4_2, F4_2 => F4_2 | F4_2, F4_3 => F4_0
  | F4_3, F4_0 => F4_0 | F4_3, F4_1 => F4_1 | F4_3, F4_2 => F4_2 | F4_3, F4_3 => F4_3
  end.

#[local] Instance refa302_inst : Magma Fin4 := {| magma_op := refa302_op |}.

Lemma refa302_sat2513 : @Equation2513 Fin4 refa302_inst.
Proof. unfold Equation2513, magma_op, refa302_inst, refa302_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa302_sat2716 : @Equation2716 Fin4 refa302_inst.
Proof. unfold Equation2716, magma_op, refa302_inst, refa302_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa302_not2263 : ~ @Equation2263 Fin4 refa302_inst.
Proof. unfold Equation2263. intro H. specialize (H F4_2 F4_0). unfold magma_op, refa302_inst, refa302_op in H. discriminate H. Qed.

Lemma refa302_not2310 : ~ @Equation2310 Fin4 refa302_inst.
Proof. unfold Equation2310. intro H. specialize (H F4_1 F4_2 F4_0). unfold magma_op, refa302_inst, refa302_op in H. discriminate H. Qed.

Lemma refa302_not2347 : ~ @Equation2347 Fin4 refa302_inst.
Proof. unfold Equation2347. intro H. specialize (H F4_1 F4_2 F4_0). unfold magma_op, refa302_inst, refa302_op in H. discriminate H. Qed.

Lemma refa302_not2364 : ~ @Equation2364 Fin4 refa302_inst.
Proof. unfold Equation2364. intro H. specialize (H F4_1 F4_2 F4_0). unfold magma_op, refa302_inst, refa302_op in H. discriminate H. Qed.

Lemma refa302_not2381 : ~ @Equation2381 Fin4 refa302_inst.
Proof. unfold Equation2381. intro H. specialize (H F4_1 F4_0 F4_2). unfold magma_op, refa302_inst, refa302_op in H. discriminate H. Qed.

Lemma refa302_not2550 : ~ @Equation2550 Fin4 refa302_inst.
Proof. unfold Equation2550. intro H. specialize (H F4_1 F4_2 F4_0). unfold magma_op, refa302_inst, refa302_op in H. discriminate H. Qed.

Lemma refa302_not2679 : ~ @Equation2679 Fin4 refa302_inst.
Proof. unfold Equation2679. intro H. specialize (H F4_1 F4_2 F4_0). unfold magma_op, refa302_inst, refa302_op in H. discriminate H. Qed.

Lemma refa302_not3309 : ~ @Equation3309 Fin4 refa302_inst.
Proof. unfold Equation3309. intro H. specialize (H F4_0 F4_2). unfold magma_op, refa302_inst, refa302_op in H. discriminate H. Qed.

Lemma refa302_not3316 : ~ @Equation3316 Fin4 refa302_inst.
Proof. unfold Equation3316. intro H. specialize (H F4_0 F4_2). unfold magma_op, refa302_inst, refa302_op in H. discriminate H. Qed.

Lemma refa302_not3343 : ~ @Equation3343 Fin4 refa302_inst.
Proof. unfold Equation3343. intro H. specialize (H F4_0 F4_2). unfold magma_op, refa302_inst, refa302_op in H. discriminate H. Qed.

Lemma refa302_not3509 : ~ @Equation3509 Fin4 refa302_inst.
Proof. unfold Equation3509. intro H. specialize (H F4_0 F4_2). unfold magma_op, refa302_inst, refa302_op in H. discriminate H. Qed.

Lemma refa302_not3519 : ~ @Equation3519 Fin4 refa302_inst.
Proof. unfold Equation3519. intro H. specialize (H F4_0 F4_2). unfold magma_op, refa302_inst, refa302_op in H. discriminate H. Qed.

Lemma refa302_not3556 : ~ @Equation3556 Fin4 refa302_inst.
Proof. unfold Equation3556. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa302_inst, refa302_op in H. discriminate H. Qed.

Lemma refa302_not3712 : ~ @Equation3712 Fin4 refa302_inst.
Proof. unfold Equation3712. intro H. specialize (H F4_0 F4_2). unfold magma_op, refa302_inst, refa302_op in H. discriminate H. Qed.

Lemma refa302_not3749 : ~ @Equation3749 Fin4 refa302_inst.
Proof. unfold Equation3749. intro H. specialize (H F4_0 F4_2). unfold magma_op, refa302_inst, refa302_op in H. discriminate H. Qed.

Lemma refa302_not3752 : ~ @Equation3752 Fin4 refa302_inst.
Proof. unfold Equation3752. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa302_inst, refa302_op in H. discriminate H. Qed.

Lemma refa302_not3897 : ~ @Equation3897 Fin4 refa302_inst.
Proof. unfold Equation3897. intro H. specialize (H F4_1 F4_2 F4_0). unfold magma_op, refa302_inst, refa302_op in H. discriminate H. Qed.

Lemma refa302_not3925 : ~ @Equation3925 Fin4 refa302_inst.
Proof. unfold Equation3925. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa302_inst, refa302_op in H. discriminate H. Qed.

Lemma refa302_not3952 : ~ @Equation3952 Fin4 refa302_inst.
Proof. unfold Equation3952. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa302_inst, refa302_op in H. discriminate H. Qed.

Lemma refa302_not3962 : ~ @Equation3962 Fin4 refa302_inst.
Proof. unfold Equation3962. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa302_inst, refa302_op in H. discriminate H. Qed.

Lemma refa302_not4128 : ~ @Equation4128 Fin4 refa302_inst.
Proof. unfold Equation4128. intro H. specialize (H F4_0 F4_2). unfold magma_op, refa302_inst, refa302_op in H. discriminate H. Qed.

Lemma refa302_not4165 : ~ @Equation4165 Fin4 refa302_inst.
Proof. unfold Equation4165. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa302_inst, refa302_op in H. discriminate H. Qed.

Lemma refa302_not4284 : ~ @Equation4284 Fin4 refa302_inst.
Proof. unfold Equation4284. intro H. specialize (H F4_0 F4_2). unfold magma_op, refa302_inst, refa302_op in H. discriminate H. Qed.

Lemma refa302_not4291 : ~ @Equation4291 Fin4 refa302_inst.
Proof. unfold Equation4291. intro H. specialize (H F4_0 F4_2). unfold magma_op, refa302_inst, refa302_op in H. discriminate H. Qed.

Lemma refa302_not4362 : ~ @Equation4362 Fin4 refa302_inst.
Proof. unfold Equation4362. intro H. specialize (H F4_0 F4_2 F4_1). unfold magma_op, refa302_inst, refa302_op in H. discriminate H. Qed.

Lemma refa302_not4396 : ~ @Equation4396 Fin4 refa302_inst.
Proof. unfold Equation4396. intro H. specialize (H F4_0 F4_2). unfold magma_op, refa302_inst, refa302_op in H. discriminate H. Qed.

Lemma refa302_not4406 : ~ @Equation4406 Fin4 refa302_inst.
Proof. unfold Equation4406. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa302_inst, refa302_op in H. discriminate H. Qed.

Lemma refa302_not4435 : ~ @Equation4435 Fin4 refa302_inst.
Proof. unfold Equation4435. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa302_inst, refa302_op in H. discriminate H. Qed.

Lemma refa302_not4480 : ~ @Equation4480 Fin4 refa302_inst.
Proof. unfold Equation4480. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa302_inst, refa302_op in H. discriminate H. Qed.

Lemma refa302_not4606 : ~ @Equation4606 Fin4 refa302_inst.
Proof. unfold Equation4606. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa302_inst, refa302_op in H. discriminate H. Qed.

(** ---- refa303 (Fin4) ---- *)

Definition refa303_op (x y : Fin4) : Fin4 :=
  match x, y with
  | F4_0, F4_0 => F4_0 | F4_0, F4_1 => F4_1 | F4_0, F4_2 => F4_3 | F4_0, F4_3 => F4_1
  | F4_1, F4_0 => F4_2 | F4_1, F4_1 => F4_1 | F4_1, F4_2 => F4_2 | F4_1, F4_3 => F4_3
  | F4_2, F4_0 => F4_0 | F4_2, F4_1 => F4_1 | F4_2, F4_2 => F4_2 | F4_2, F4_3 => F4_1
  | F4_3, F4_0 => F4_0 | F4_3, F4_1 => F4_1 | F4_3, F4_2 => F4_1 | F4_3, F4_3 => F4_3
  end.

#[local] Instance refa303_inst : Magma Fin4 := {| magma_op := refa303_op |}.

Lemma refa303_sat2337 : @Equation2337 Fin4 refa303_inst.
Proof. unfold Equation2337, magma_op, refa303_inst, refa303_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa303_sat2804 : @Equation2804 Fin4 refa303_inst.
Proof. unfold Equation2804, magma_op, refa303_inst, refa303_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa303_sat2973 : @Equation2973 Fin4 refa303_inst.
Proof. unfold Equation2973, magma_op, refa303_inst, refa303_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa303_not280 : ~ @Equation280 Fin4 refa303_inst.
Proof. unfold Equation280. intro H. specialize (H F4_2 F4_0). unfold magma_op, refa303_inst, refa303_op in H. discriminate H. Qed.

Lemma refa303_not619 : ~ @Equation619 Fin4 refa303_inst.
Proof. unfold Equation619. intro H. specialize (H F4_2 F4_0). unfold magma_op, refa303_inst, refa303_op in H. discriminate H. Qed.

Lemma refa303_not832 : ~ @Equation832 Fin4 refa303_inst.
Proof. unfold Equation832. intro H. specialize (H F4_2 F4_0). unfold magma_op, refa303_inst, refa303_op in H. discriminate H. Qed.

Lemma refa303_not1035 : ~ @Equation1035 Fin4 refa303_inst.
Proof. unfold Equation1035. intro H. specialize (H F4_2 F4_0). unfold magma_op, refa303_inst, refa303_op in H. discriminate H. Qed.

Lemma refa303_not1228 : ~ @Equation1228 Fin4 refa303_inst.
Proof. unfold Equation1228. intro H. specialize (H F4_2 F4_0). unfold magma_op, refa303_inst, refa303_op in H. discriminate H. Qed.

Lemma refa303_not1248 : ~ @Equation1248 Fin4 refa303_inst.
Proof. unfold Equation1248. intro H. specialize (H F4_2 F4_0). unfold magma_op, refa303_inst, refa303_op in H. discriminate H. Qed.

Lemma refa303_not1478 : ~ @Equation1478 Fin4 refa303_inst.
Proof. unfold Equation1478. intro H. specialize (H F4_2 F4_0). unfold magma_op, refa303_inst, refa303_op in H. discriminate H. Qed.

Lemma refa303_not1634 : ~ @Equation1634 Fin4 refa303_inst.
Proof. unfold Equation1634. intro H. specialize (H F4_2 F4_0). unfold magma_op, refa303_inst, refa303_op in H. discriminate H. Qed.

Lemma refa303_not1681 : ~ @Equation1681 Fin4 refa303_inst.
Proof. unfold Equation1681. intro H. specialize (H F4_2 F4_0). unfold magma_op, refa303_inst, refa303_op in H. discriminate H. Qed.

Lemma refa303_not1691 : ~ @Equation1691 Fin4 refa303_inst.
Proof. unfold Equation1691. intro H. specialize (H F4_2 F4_0). unfold magma_op, refa303_inst, refa303_op in H. discriminate H. Qed.

Lemma refa303_not1884 : ~ @Equation1884 Fin4 refa303_inst.
Proof. unfold Equation1884. intro H. specialize (H F4_2 F4_0). unfold magma_op, refa303_inst, refa303_op in H. discriminate H. Qed.

Lemma refa303_not2050 : ~ @Equation2050 Fin4 refa303_inst.
Proof. unfold Equation2050. intro H. specialize (H F4_2 F4_0). unfold magma_op, refa303_inst, refa303_op in H. discriminate H. Qed.

Lemma refa303_not2124 : ~ @Equation2124 Fin4 refa303_inst.
Proof. unfold Equation2124. intro H. specialize (H F4_2 F4_0). unfold magma_op, refa303_inst, refa303_op in H. discriminate H. Qed.

Lemma refa303_not2243 : ~ @Equation2243 Fin4 refa303_inst.
Proof. unfold Equation2243. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa303_inst, refa303_op in H. discriminate H. Qed.

Lemma refa303_not2290 : ~ @Equation2290 Fin4 refa303_inst.
Proof. unfold Equation2290. intro H. specialize (H F4_2 F4_0). unfold magma_op, refa303_inst, refa303_op in H. discriminate H. Qed.

Lemma refa303_not2493 : ~ @Equation2493 Fin4 refa303_inst.
Proof. unfold Equation2493. intro H. specialize (H F4_2 F4_0). unfold magma_op, refa303_inst, refa303_op in H. discriminate H. Qed.

Lemma refa303_not2503 : ~ @Equation2503 Fin4 refa303_inst.
Proof. unfold Equation2503. intro H. specialize (H F4_0 F4_3). unfold magma_op, refa303_inst, refa303_op in H. discriminate H. Qed.

Lemma refa303_not2659 : ~ @Equation2659 Fin4 refa303_inst.
Proof. unfold Equation2659. intro H. specialize (H F4_2 F4_0). unfold magma_op, refa303_inst, refa303_op in H. discriminate H. Qed.

Lemma refa303_not2706 : ~ @Equation2706 Fin4 refa303_inst.
Proof. unfold Equation2706. intro H. specialize (H F4_2 F4_0). unfold magma_op, refa303_inst, refa303_op in H. discriminate H. Qed.

Lemma refa303_not2733 : ~ @Equation2733 Fin4 refa303_inst.
Proof. unfold Equation2733. intro H. specialize (H F4_2 F4_0). unfold magma_op, refa303_inst, refa303_op in H. discriminate H. Qed.

Lemma refa303_not2852 : ~ @Equation2852 Fin4 refa303_inst.
Proof. unfold Equation2852. intro H. specialize (H F4_2 F4_0). unfold magma_op, refa303_inst, refa303_op in H. discriminate H. Qed.

Lemma refa303_not2872 : ~ @Equation2872 Fin4 refa303_inst.
Proof. unfold Equation2872. intro H. specialize (H F4_2 F4_0). unfold magma_op, refa303_inst, refa303_op in H. discriminate H. Qed.

Lemma refa303_not2909 : ~ @Equation2909 Fin4 refa303_inst.
Proof. unfold Equation2909. intro H. specialize (H F4_2 F4_0). unfold magma_op, refa303_inst, refa303_op in H. discriminate H. Qed.

Lemma refa303_not2946 : ~ @Equation2946 Fin4 refa303_inst.
Proof. unfold Equation2946. intro H. specialize (H F4_2 F4_0). unfold magma_op, refa303_inst, refa303_op in H. discriminate H. Qed.

Lemma refa303_not3055 : ~ @Equation3055 Fin4 refa303_inst.
Proof. unfold Equation3055. intro H. specialize (H F4_2 F4_0). unfold magma_op, refa303_inst, refa303_op in H. discriminate H. Qed.

Lemma refa303_not3075 : ~ @Equation3075 Fin4 refa303_inst.
Proof. unfold Equation3075. intro H. specialize (H F4_2 F4_0). unfold magma_op, refa303_inst, refa303_op in H. discriminate H. Qed.

Lemma refa303_not3112 : ~ @Equation3112 Fin4 refa303_inst.
Proof. unfold Equation3112. intro H. specialize (H F4_2 F4_0). unfold magma_op, refa303_inst, refa303_op in H. discriminate H. Qed.

Lemma refa303_not3149 : ~ @Equation3149 Fin4 refa303_inst.
Proof. unfold Equation3149. intro H. specialize (H F4_2 F4_0). unfold magma_op, refa303_inst, refa303_op in H. discriminate H. Qed.

Lemma refa303_not3306 : ~ @Equation3306 Fin4 refa303_inst.
Proof. unfold Equation3306. intro H. specialize (H F4_0 F4_2). unfold magma_op, refa303_inst, refa303_op in H. discriminate H. Qed.

Lemma refa303_not3309 : ~ @Equation3309 Fin4 refa303_inst.
Proof. unfold Equation3309. intro H. specialize (H F4_0 F4_2). unfold magma_op, refa303_inst, refa303_op in H. discriminate H. Qed.

Lemma refa303_not3353 : ~ @Equation3353 Fin4 refa303_inst.
Proof. unfold Equation3353. intro H. specialize (H F4_0 F4_2). unfold magma_op, refa303_inst, refa303_op in H. discriminate H. Qed.

Lemma refa303_not3461 : ~ @Equation3461 Fin4 refa303_inst.
Proof. unfold Equation3461. intro H. specialize (H F4_2 F4_0). unfold magma_op, refa303_inst, refa303_op in H. discriminate H. Qed.

Lemma refa303_not3509 : ~ @Equation3509 Fin4 refa303_inst.
Proof. unfold Equation3509. intro H. specialize (H F4_0 F4_2). unfold magma_op, refa303_inst, refa303_op in H. discriminate H. Qed.

Lemma refa303_not3512 : ~ @Equation3512 Fin4 refa303_inst.
Proof. unfold Equation3512. intro H. specialize (H F4_0 F4_2). unfold magma_op, refa303_inst, refa303_op in H. discriminate H. Qed.

Lemma refa303_not3674 : ~ @Equation3674 Fin4 refa303_inst.
Proof. unfold Equation3674. intro H. specialize (H F4_2 F4_0). unfold magma_op, refa303_inst, refa303_op in H. discriminate H. Qed.

Lemma refa303_not3712 : ~ @Equation3712 Fin4 refa303_inst.
Proof. unfold Equation3712. intro H. specialize (H F4_0 F4_2). unfold magma_op, refa303_inst, refa303_op in H. discriminate H. Qed.

Lemma refa303_not3877 : ~ @Equation3877 Fin4 refa303_inst.
Proof. unfold Equation3877. intro H. specialize (H F4_2 F4_0). unfold magma_op, refa303_inst, refa303_op in H. discriminate H. Qed.

Lemma refa303_not3925 : ~ @Equation3925 Fin4 refa303_inst.
Proof. unfold Equation3925. intro H. specialize (H F4_2 F4_0). unfold magma_op, refa303_inst, refa303_op in H. discriminate H. Qed.

Lemma refa303_not4070 : ~ @Equation4070 Fin4 refa303_inst.
Proof. unfold Equation4070. intro H. specialize (H F4_2 F4_0). unfold magma_op, refa303_inst, refa303_op in H. discriminate H. Qed.

Lemma refa303_not4090 : ~ @Equation4090 Fin4 refa303_inst.
Proof. unfold Equation4090. intro H. specialize (H F4_2 F4_0). unfold magma_op, refa303_inst, refa303_op in H. discriminate H. Qed.

Lemma refa303_not4128 : ~ @Equation4128 Fin4 refa303_inst.
Proof. unfold Equation4128. intro H. specialize (H F4_3 F4_0). unfold magma_op, refa303_inst, refa303_op in H. discriminate H. Qed.

Lemma refa303_not4155 : ~ @Equation4155 Fin4 refa303_inst.
Proof. unfold Equation4155. intro H. specialize (H F4_2 F4_0). unfold magma_op, refa303_inst, refa303_op in H. discriminate H. Qed.

Lemma refa303_not4284 : ~ @Equation4284 Fin4 refa303_inst.
Proof. unfold Equation4284. intro H. specialize (H F4_0 F4_2). unfold magma_op, refa303_inst, refa303_op in H. discriminate H. Qed.

Lemma refa303_not4396 : ~ @Equation4396 Fin4 refa303_inst.
Proof. unfold Equation4396. intro H. specialize (H F4_0 F4_2). unfold magma_op, refa303_inst, refa303_op in H. discriminate H. Qed.

Lemma refa303_not4666 : ~ @Equation4666 Fin4 refa303_inst.
Proof. unfold Equation4666. intro H. specialize (H F4_0 F4_2 F4_1). unfold magma_op, refa303_inst, refa303_op in H. discriminate H. Qed.

(** ---- refa304 (Fin4) ---- *)

Definition refa304_op (x y : Fin4) : Fin4 :=
  match x, y with
  | F4_0, F4_0 => F4_2 | F4_0, F4_1 => F4_0 | F4_0, F4_2 => F4_3 | F4_0, F4_3 => F4_1
  | F4_1, F4_0 => F4_3 | F4_1, F4_1 => F4_1 | F4_1, F4_2 => F4_1 | F4_1, F4_3 => F4_3
  | F4_2, F4_0 => F4_3 | F4_2, F4_1 => F4_2 | F4_2, F4_2 => F4_2 | F4_2, F4_3 => F4_3
  | F4_3, F4_0 => F4_0 | F4_3, F4_1 => F4_3 | F4_3, F4_2 => F4_1 | F4_3, F4_3 => F4_1
  end.

#[local] Instance refa304_inst : Magma Fin4 := {| magma_op := refa304_op |}.

Lemma refa304_sat417 : @Equation417 Fin4 refa304_inst.
Proof. unfold Equation417, magma_op, refa304_inst, refa304_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa304_not1020 : ~ @Equation1020 Fin4 refa304_inst.
Proof. unfold Equation1020. intro H. specialize (H F4_0). unfold magma_op, refa304_inst, refa304_op in H. discriminate H. Qed.

Lemma refa304_not1832 : ~ @Equation1832 Fin4 refa304_inst.
Proof. unfold Equation1832. intro H. specialize (H F4_0). unfold magma_op, refa304_inst, refa304_op in H. discriminate H. Qed.

Lemma refa304_not3259 : ~ @Equation3259 Fin4 refa304_inst.
Proof. unfold Equation3259. intro H. specialize (H F4_0 F4_0). unfold magma_op, refa304_inst, refa304_op in H. discriminate H. Qed.

Lemma refa304_not3456 : ~ @Equation3456 Fin4 refa304_inst.
Proof. unfold Equation3456. intro H. specialize (H F4_0). unfold magma_op, refa304_inst, refa304_op in H. discriminate H. Qed.

(** ---- refa305 (Fin4) ---- *)

Definition refa305_op (x y : Fin4) : Fin4 :=
  match x, y with
  | F4_0, F4_0 => F4_3 | F4_0, F4_1 => F4_2 | F4_0, F4_2 => F4_0 | F4_0, F4_3 => F4_1
  | F4_1, F4_0 => F4_3 | F4_1, F4_1 => F4_0 | F4_1, F4_2 => F4_1 | F4_1, F4_3 => F4_2
  | F4_2, F4_0 => F4_3 | F4_2, F4_1 => F4_0 | F4_2, F4_2 => F4_2 | F4_2, F4_3 => F4_1
  | F4_3, F4_0 => F4_2 | F4_3, F4_1 => F4_0 | F4_3, F4_2 => F4_3 | F4_3, F4_3 => F4_1
  end.

#[local] Instance refa305_inst : Magma Fin4 := {| magma_op := refa305_op |}.

Lemma refa305_sat440 : @Equation440 Fin4 refa305_inst.
Proof. unfold Equation440, magma_op, refa305_inst, refa305_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa305_sat1525 : @Equation1525 Fin4 refa305_inst.
Proof. unfold Equation1525, magma_op, refa305_inst, refa305_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa305_not614 : ~ @Equation614 Fin4 refa305_inst.
Proof. unfold Equation614. intro H. specialize (H F4_0). unfold magma_op, refa305_inst, refa305_op in H. discriminate H. Qed.

Lemma refa305_not817 : ~ @Equation817 Fin4 refa305_inst.
Proof. unfold Equation817. intro H. specialize (H F4_0). unfold magma_op, refa305_inst, refa305_op in H. discriminate H. Qed.

Lemma refa305_not1023 : ~ @Equation1023 Fin4 refa305_inst.
Proof. unfold Equation1023. intro H. specialize (H F4_0 F4_0). unfold magma_op, refa305_inst, refa305_op in H. discriminate H. Qed.

Lemma refa305_not1036 : ~ @Equation1036 Fin4 refa305_inst.
Proof. unfold Equation1036. intro H. specialize (H F4_0 F4_0). unfold magma_op, refa305_inst, refa305_op in H. discriminate H. Qed.

Lemma refa305_not1049 : ~ @Equation1049 Fin4 refa305_inst.
Proof. unfold Equation1049. intro H. specialize (H F4_0 F4_0). unfold magma_op, refa305_inst, refa305_op in H. discriminate H. Qed.

Lemma refa305_not1226 : ~ @Equation1226 Fin4 refa305_inst.
Proof. unfold Equation1226. intro H. specialize (H F4_0 F4_0). unfold magma_op, refa305_inst, refa305_op in H. discriminate H. Qed.

Lemma refa305_not1229 : ~ @Equation1229 Fin4 refa305_inst.
Proof. unfold Equation1229. intro H. specialize (H F4_0 F4_0). unfold magma_op, refa305_inst, refa305_op in H. discriminate H. Qed.

Lemma refa305_not1239 : ~ @Equation1239 Fin4 refa305_inst.
Proof. unfold Equation1239. intro H. specialize (H F4_0 F4_0). unfold magma_op, refa305_inst, refa305_op in H. discriminate H. Qed.

Lemma refa305_not1252 : ~ @Equation1252 Fin4 refa305_inst.
Proof. unfold Equation1252. intro H. specialize (H F4_0 F4_0). unfold magma_op, refa305_inst, refa305_op in H. discriminate H. Qed.

Lemma refa305_not1434 : ~ @Equation1434 Fin4 refa305_inst.
Proof. unfold Equation1434. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa305_inst, refa305_op in H. discriminate H. Qed.

Lemma refa305_not1444 : ~ @Equation1444 Fin4 refa305_inst.
Proof. unfold Equation1444. intro H. specialize (H F4_0 F4_2). unfold magma_op, refa305_inst, refa305_op in H. discriminate H. Qed.

Lemma refa305_not1861 : ~ @Equation1861 Fin4 refa305_inst.
Proof. unfold Equation1861. intro H. specialize (H F4_0 F4_0). unfold magma_op, refa305_inst, refa305_op in H. discriminate H. Qed.

Lemma refa305_not3256 : ~ @Equation3256 Fin4 refa305_inst.
Proof. unfold Equation3256. intro H. specialize (H F4_0 F4_0). unfold magma_op, refa305_inst, refa305_op in H. discriminate H. Qed.

Lemma refa305_not3315 : ~ @Equation3315 Fin4 refa305_inst.
Proof. unfold Equation3315. intro H. specialize (H F4_0 F4_0). unfold magma_op, refa305_inst, refa305_op in H. discriminate H. Qed.

Lemma refa305_not3665 : ~ @Equation3665 Fin4 refa305_inst.
Proof. unfold Equation3665. intro H. specialize (H F4_0 F4_0). unfold magma_op, refa305_inst, refa305_op in H. discriminate H. Qed.

Lemma refa305_not3677 : ~ @Equation3677 Fin4 refa305_inst.
Proof. unfold Equation3677. intro H. specialize (H F4_0 F4_0). unfold magma_op, refa305_inst, refa305_op in H. discriminate H. Qed.

Lemma refa305_not3684 : ~ @Equation3684 Fin4 refa305_inst.
Proof. unfold Equation3684. intro H. specialize (H F4_0 F4_0). unfold magma_op, refa305_inst, refa305_op in H. discriminate H. Qed.

Lemma refa305_not3721 : ~ @Equation3721 Fin4 refa305_inst.
Proof. unfold Equation3721. intro H. specialize (H F4_0 F4_0). unfold magma_op, refa305_inst, refa305_op in H. discriminate H. Qed.

Lemma refa305_not3865 : ~ @Equation3865 Fin4 refa305_inst.
Proof. unfold Equation3865. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa305_inst, refa305_op in H. discriminate H. Qed.

Lemma refa305_not3870 : ~ @Equation3870 Fin4 refa305_inst.
Proof. unfold Equation3870. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa305_inst, refa305_op in H. discriminate H. Qed.

Lemma refa305_not3878 : ~ @Equation3878 Fin4 refa305_inst.
Proof. unfold Equation3878. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa305_inst, refa305_op in H. discriminate H. Qed.

Lemma refa305_not3880 : ~ @Equation3880 Fin4 refa305_inst.
Proof. unfold Equation3880. intro H. specialize (H F4_0 F4_2). unfold magma_op, refa305_inst, refa305_op in H. discriminate H. Qed.

Lemma refa305_not3887 : ~ @Equation3887 Fin4 refa305_inst.
Proof. unfold Equation3887. intro H. specialize (H F4_0 F4_3). unfold magma_op, refa305_inst, refa305_op in H. discriminate H. Qed.

Lemma refa305_not3928 : ~ @Equation3928 Fin4 refa305_inst.
Proof. unfold Equation3928. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa305_inst, refa305_op in H. discriminate H. Qed.

Lemma refa305_not3955 : ~ @Equation3955 Fin4 refa305_inst.
Proof. unfold Equation3955. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa305_inst, refa305_op in H. discriminate H. Qed.

Lemma refa305_not3962 : ~ @Equation3962 Fin4 refa305_inst.
Proof. unfold Equation3962. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa305_inst, refa305_op in H. discriminate H. Qed.

Lemma refa305_not4068 : ~ @Equation4068 Fin4 refa305_inst.
Proof. unfold Equation4068. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa305_inst, refa305_op in H. discriminate H. Qed.

Lemma refa305_not4071 : ~ @Equation4071 Fin4 refa305_inst.
Proof. unfold Equation4071. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa305_inst, refa305_op in H. discriminate H. Qed.

Lemma refa305_not4081 : ~ @Equation4081 Fin4 refa305_inst.
Proof. unfold Equation4081. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa305_inst, refa305_op in H. discriminate H. Qed.

Lemma refa305_not4083 : ~ @Equation4083 Fin4 refa305_inst.
Proof. unfold Equation4083. intro H. specialize (H F4_0 F4_2). unfold magma_op, refa305_inst, refa305_op in H. discriminate H. Qed.

Lemma refa305_not4158 : ~ @Equation4158 Fin4 refa305_inst.
Proof. unfold Equation4158. intro H. specialize (H F4_0 F4_2). unfold magma_op, refa305_inst, refa305_op in H. discriminate H. Qed.

Lemma refa305_not4270 : ~ @Equation4270 Fin4 refa305_inst.
Proof. unfold Equation4270. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa305_inst, refa305_op in H. discriminate H. Qed.

Lemma refa305_not4598 : ~ @Equation4598 Fin4 refa305_inst.
Proof. unfold Equation4598. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa305_inst, refa305_op in H. discriminate H. Qed.

Lemma refa305_not4635 : ~ @Equation4635 Fin4 refa305_inst.
Proof. unfold Equation4635. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa305_inst, refa305_op in H. discriminate H. Qed.

Lemma refa305_not4647 : ~ @Equation4647 Fin4 refa305_inst.
Proof. unfold Equation4647. intro H. specialize (H F4_0 F4_0 F4_1). unfold magma_op, refa305_inst, refa305_op in H. discriminate H. Qed.

(** ---- refa306 (Fin4) ---- *)

Definition refa306_op (x y : Fin4) : Fin4 :=
  match x, y with
  | F4_0, F4_0 => F4_0 | F4_0, F4_1 => F4_1 | F4_0, F4_2 => F4_3 | F4_0, F4_3 => F4_1
  | F4_1, F4_0 => F4_2 | F4_1, F4_1 => F4_1 | F4_1, F4_2 => F4_2 | F4_1, F4_3 => F4_3
  | F4_2, F4_0 => F4_0 | F4_2, F4_1 => F4_1 | F4_2, F4_2 => F4_2 | F4_2, F4_3 => F4_1
  | F4_3, F4_0 => F4_0 | F4_3, F4_1 => F4_1 | F4_3, F4_2 => F4_2 | F4_3, F4_3 => F4_3
  end.

#[local] Instance refa306_inst : Magma Fin4 := {| magma_op := refa306_op |}.

Lemma refa306_sat2381 : @Equation2381 Fin4 refa306_inst.
Proof. unfold Equation2381, magma_op, refa306_inst, refa306_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa306_sat2753 : @Equation2753 Fin4 refa306_inst.
Proof. unfold Equation2753, magma_op, refa306_inst, refa306_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa306_not2243 : ~ @Equation2243 Fin4 refa306_inst.
Proof. unfold Equation2243. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa306_inst, refa306_op in H. discriminate H. Qed.

Lemma refa306_not3306 : ~ @Equation3306 Fin4 refa306_inst.
Proof. unfold Equation3306. intro H. specialize (H F4_0 F4_2). unfold magma_op, refa306_inst, refa306_op in H. discriminate H. Qed.

Lemma refa306_not3309 : ~ @Equation3309 Fin4 refa306_inst.
Proof. unfold Equation3309. intro H. specialize (H F4_0 F4_2). unfold magma_op, refa306_inst, refa306_op in H. discriminate H. Qed.

Lemma refa306_not3316 : ~ @Equation3316 Fin4 refa306_inst.
Proof. unfold Equation3316. intro H. specialize (H F4_0 F4_2). unfold magma_op, refa306_inst, refa306_op in H. discriminate H. Qed.

Lemma refa306_not3343 : ~ @Equation3343 Fin4 refa306_inst.
Proof. unfold Equation3343. intro H. specialize (H F4_0 F4_2). unfold magma_op, refa306_inst, refa306_op in H. discriminate H. Qed.

Lemma refa306_not3346 : ~ @Equation3346 Fin4 refa306_inst.
Proof. unfold Equation3346. intro H. specialize (H F4_0 F4_2). unfold magma_op, refa306_inst, refa306_op in H. discriminate H. Qed.

Lemma refa306_not3353 : ~ @Equation3353 Fin4 refa306_inst.
Proof. unfold Equation3353. intro H. specialize (H F4_0 F4_2). unfold magma_op, refa306_inst, refa306_op in H. discriminate H. Qed.

Lemma refa306_not3509 : ~ @Equation3509 Fin4 refa306_inst.
Proof. unfold Equation3509. intro H. specialize (H F4_0 F4_2). unfold magma_op, refa306_inst, refa306_op in H. discriminate H. Qed.

Lemma refa306_not3519 : ~ @Equation3519 Fin4 refa306_inst.
Proof. unfold Equation3519. intro H. specialize (H F4_0 F4_2). unfold magma_op, refa306_inst, refa306_op in H. discriminate H. Qed.

Lemma refa306_not3546 : ~ @Equation3546 Fin4 refa306_inst.
Proof. unfold Equation3546. intro H. specialize (H F4_0 F4_2). unfold magma_op, refa306_inst, refa306_op in H. discriminate H. Qed.

Lemma refa306_not3556 : ~ @Equation3556 Fin4 refa306_inst.
Proof. unfold Equation3556. intro H. specialize (H F4_0 F4_2). unfold magma_op, refa306_inst, refa306_op in H. discriminate H. Qed.

Lemma refa306_not3712 : ~ @Equation3712 Fin4 refa306_inst.
Proof. unfold Equation3712. intro H. specialize (H F4_0 F4_2). unfold magma_op, refa306_inst, refa306_op in H. discriminate H. Qed.

Lemma refa306_not3749 : ~ @Equation3749 Fin4 refa306_inst.
Proof. unfold Equation3749. intro H. specialize (H F4_0 F4_2). unfold magma_op, refa306_inst, refa306_op in H. discriminate H. Qed.

Lemma refa306_not3752 : ~ @Equation3752 Fin4 refa306_inst.
Proof. unfold Equation3752. intro H. specialize (H F4_3 F4_0). unfold magma_op, refa306_inst, refa306_op in H. discriminate H. Qed.

Lemma refa306_not3759 : ~ @Equation3759 Fin4 refa306_inst.
Proof. unfold Equation3759. intro H. specialize (H F4_0 F4_2). unfold magma_op, refa306_inst, refa306_op in H. discriminate H. Qed.

Lemma refa306_not3925 : ~ @Equation3925 Fin4 refa306_inst.
Proof. unfold Equation3925. intro H. specialize (H F4_2 F4_0). unfold magma_op, refa306_inst, refa306_op in H. discriminate H. Qed.

Lemma refa306_not3952 : ~ @Equation3952 Fin4 refa306_inst.
Proof. unfold Equation3952. intro H. specialize (H F4_3 F4_0). unfold magma_op, refa306_inst, refa306_op in H. discriminate H. Qed.

Lemma refa306_not3962 : ~ @Equation3962 Fin4 refa306_inst.
Proof. unfold Equation3962. intro H. specialize (H F4_2 F4_0). unfold magma_op, refa306_inst, refa306_op in H. discriminate H. Qed.

Lemma refa306_not4128 : ~ @Equation4128 Fin4 refa306_inst.
Proof. unfold Equation4128. intro H. specialize (H F4_3 F4_0). unfold magma_op, refa306_inst, refa306_op in H. discriminate H. Qed.

Lemma refa306_not4165 : ~ @Equation4165 Fin4 refa306_inst.
Proof. unfold Equation4165. intro H. specialize (H F4_3 F4_0). unfold magma_op, refa306_inst, refa306_op in H. discriminate H. Qed.

Lemma refa306_not4284 : ~ @Equation4284 Fin4 refa306_inst.
Proof. unfold Equation4284. intro H. specialize (H F4_0 F4_2). unfold magma_op, refa306_inst, refa306_op in H. discriminate H. Qed.

Lemma refa306_not4291 : ~ @Equation4291 Fin4 refa306_inst.
Proof. unfold Equation4291. intro H. specialize (H F4_1 F4_0). unfold magma_op, refa306_inst, refa306_op in H. discriminate H. Qed.

Lemma refa306_not4320 : ~ @Equation4320 Fin4 refa306_inst.
Proof. unfold Equation4320. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa306_inst, refa306_op in H. discriminate H. Qed.

Lemma refa306_not4396 : ~ @Equation4396 Fin4 refa306_inst.
Proof. unfold Equation4396. intro H. specialize (H F4_0 F4_2). unfold magma_op, refa306_inst, refa306_op in H. discriminate H. Qed.

Lemma refa306_not4406 : ~ @Equation4406 Fin4 refa306_inst.
Proof. unfold Equation4406. intro H. specialize (H F4_0 F4_2). unfold magma_op, refa306_inst, refa306_op in H. discriminate H. Qed.

Lemma refa306_not4435 : ~ @Equation4435 Fin4 refa306_inst.
Proof. unfold Equation4435. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa306_inst, refa306_op in H. discriminate H. Qed.

Lemma refa306_not4445 : ~ @Equation4445 Fin4 refa306_inst.
Proof. unfold Equation4445. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa306_inst, refa306_op in H. discriminate H. Qed.

Lemma refa306_not4480 : ~ @Equation4480 Fin4 refa306_inst.
Proof. unfold Equation4480. intro H. specialize (H F4_3 F4_0). unfold magma_op, refa306_inst, refa306_op in H. discriminate H. Qed.

Lemma refa306_not4606 : ~ @Equation4606 Fin4 refa306_inst.
Proof. unfold Equation4606. intro H. specialize (H F4_3 F4_0). unfold magma_op, refa306_inst, refa306_op in H. discriminate H. Qed.

(** ---- refa307 (Fin4) ---- *)

Definition refa307_op (x y : Fin4) : Fin4 :=
  match x, y with
  | F4_0, F4_0 => F4_0 | F4_0, F4_1 => F4_3 | F4_0, F4_2 => F4_1 | F4_0, F4_3 => F4_3
  | F4_1, F4_0 => F4_3 | F4_1, F4_1 => F4_3 | F4_1, F4_2 => F4_0 | F4_1, F4_3 => F4_3
  | F4_2, F4_0 => F4_1 | F4_2, F4_1 => F4_3 | F4_2, F4_2 => F4_1 | F4_2, F4_3 => F4_3
  | F4_3, F4_0 => F4_0 | F4_3, F4_1 => F4_3 | F4_3, F4_2 => F4_1 | F4_3, F4_3 => F4_3
  end.

#[local] Instance refa307_inst : Magma Fin4 := {| magma_op := refa307_op |}.

Lemma refa307_sat3893 : @Equation3893 Fin4 refa307_inst.
Proof. unfold Equation3893, magma_op, refa307_inst, refa307_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa307_not3870 : ~ @Equation3870 Fin4 refa307_inst.
Proof. unfold Equation3870. intro H. specialize (H F4_2 F4_0). unfold magma_op, refa307_inst, refa307_op in H. discriminate H. Qed.

Lemma refa307_not3877 : ~ @Equation3877 Fin4 refa307_inst.
Proof. unfold Equation3877. intro H. specialize (H F4_0 F4_2). unfold magma_op, refa307_inst, refa307_op in H. discriminate H. Qed.

Lemma refa307_not4606 : ~ @Equation4606 Fin4 refa307_inst.
Proof. unfold Equation4606. intro H. specialize (H F4_0 F4_2). unfold magma_op, refa307_inst, refa307_op in H. discriminate H. Qed.

(** ---- refa308 (Fin4) ---- *)

Definition refa308_op (x y : Fin4) : Fin4 :=
  match x, y with
  | F4_0, F4_0 => F4_2 | F4_0, F4_1 => F4_3 | F4_0, F4_2 => F4_0 | F4_0, F4_3 => F4_1
  | F4_1, F4_0 => F4_1 | F4_1, F4_1 => F4_0 | F4_1, F4_2 => F4_3 | F4_1, F4_3 => F4_2
  | F4_2, F4_0 => F4_1 | F4_2, F4_1 => F4_0 | F4_2, F4_2 => F4_3 | F4_2, F4_3 => F4_2
  | F4_3, F4_0 => F4_2 | F4_3, F4_1 => F4_3 | F4_3, F4_2 => F4_0 | F4_3, F4_3 => F4_1
  end.

#[local] Instance refa308_inst : Magma Fin4 := {| magma_op := refa308_op |}.

Lemma refa308_sat1797 : @Equation1797 Fin4 refa308_inst.
Proof. unfold Equation1797, magma_op, refa308_inst, refa308_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa308_not99 : ~ @Equation99 Fin4 refa308_inst.
Proof. unfold Equation99. intro H. specialize (H F4_0). unfold magma_op, refa308_inst, refa308_op in H. discriminate H. Qed.

Lemma refa308_not151 : ~ @Equation151 Fin4 refa308_inst.
Proof. unfold Equation151. intro H. specialize (H F4_0). unfold magma_op, refa308_inst, refa308_op in H. discriminate H. Qed.

Lemma refa308_not817 : ~ @Equation817 Fin4 refa308_inst.
Proof. unfold Equation817. intro H. specialize (H F4_0). unfold magma_op, refa308_inst, refa308_op in H. discriminate H. Qed.

Lemma refa308_not1223 : ~ @Equation1223 Fin4 refa308_inst.
Proof. unfold Equation1223. intro H. specialize (H F4_0). unfold magma_op, refa308_inst, refa308_op in H. discriminate H. Qed.

Lemma refa308_not1426 : ~ @Equation1426 Fin4 refa308_inst.
Proof. unfold Equation1426. intro H. specialize (H F4_0). unfold magma_op, refa308_inst, refa308_op in H. discriminate H. Qed.

Lemma refa308_not1638 : ~ @Equation1638 Fin4 refa308_inst.
Proof. unfold Equation1638. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa308_inst, refa308_op in H. discriminate H. Qed.

Lemma refa308_not1838 : ~ @Equation1838 Fin4 refa308_inst.
Proof. unfold Equation1838. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa308_inst, refa308_op in H. discriminate H. Qed.

Lemma refa308_not1848 : ~ @Equation1848 Fin4 refa308_inst.
Proof. unfold Equation1848. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa308_inst, refa308_op in H. discriminate H. Qed.

Lemma refa308_not1858 : ~ @Equation1858 Fin4 refa308_inst.
Proof. unfold Equation1858. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa308_inst, refa308_op in H. discriminate H. Qed.

Lemma refa308_not2035 : ~ @Equation2035 Fin4 refa308_inst.
Proof. unfold Equation2035. intro H. specialize (H F4_0). unfold magma_op, refa308_inst, refa308_op in H. discriminate H. Qed.

Lemma refa308_not3259 : ~ @Equation3259 Fin4 refa308_inst.
Proof. unfold Equation3259. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa308_inst, refa308_op in H. discriminate H. Qed.

Lemma refa308_not3262 : ~ @Equation3262 Fin4 refa308_inst.
Proof. unfold Equation3262. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa308_inst, refa308_op in H. discriminate H. Qed.

Lemma refa308_not3308 : ~ @Equation3308 Fin4 refa308_inst.
Proof. unfold Equation3308. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa308_inst, refa308_op in H. discriminate H. Qed.

Lemma refa308_not3456 : ~ @Equation3456 Fin4 refa308_inst.
Proof. unfold Equation3456. intro H. specialize (H F4_0). unfold magma_op, refa308_inst, refa308_op in H. discriminate H. Qed.

Lemma refa308_not3659 : ~ @Equation3659 Fin4 refa308_inst.
Proof. unfold Equation3659. intro H. specialize (H F4_0). unfold magma_op, refa308_inst, refa308_op in H. discriminate H. Qed.

Lemma refa308_not4065 : ~ @Equation4065 Fin4 refa308_inst.
Proof. unfold Equation4065. intro H. specialize (H F4_0). unfold magma_op, refa308_inst, refa308_op in H. discriminate H. Qed.

Lemma refa308_not4283 : ~ @Equation4283 Fin4 refa308_inst.
Proof. unfold Equation4283. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa308_inst, refa308_op in H. discriminate H. Qed.

Lemma refa308_not4314 : ~ @Equation4314 Fin4 refa308_inst.
Proof. unfold Equation4314. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa308_inst, refa308_op in H. discriminate H. Qed.

(** ---- refa309 (Fin4) ---- *)

Definition refa309_op (x y : Fin4) : Fin4 :=
  match x, y with
  | F4_0, F4_0 => F4_3 | F4_0, F4_1 => F4_3 | F4_0, F4_2 => F4_1 | F4_0, F4_3 => F4_1
  | F4_1, F4_0 => F4_3 | F4_1, F4_1 => F4_3 | F4_1, F4_2 => F4_3 | F4_1, F4_3 => F4_3
  | F4_2, F4_0 => F4_2 | F4_2, F4_1 => F4_3 | F4_2, F4_2 => F4_3 | F4_2, F4_3 => F4_1
  | F4_3, F4_0 => F4_3 | F4_3, F4_1 => F4_3 | F4_3, F4_2 => F4_3 | F4_3, F4_3 => F4_3
  end.

#[local] Instance refa309_inst : Magma Fin4 := {| magma_op := refa309_op |}.

Lemma refa309_sat3913 : @Equation3913 Fin4 refa309_inst.
Proof. unfold Equation3913, magma_op, refa309_inst, refa309_op. intros x y z w u. destruct x, y, z, w, u; reflexivity. Qed.

Lemma refa309_not3664 : ~ @Equation3664 Fin4 refa309_inst.
Proof. unfold Equation3664. intro H. specialize (H F4_2 F4_0). unfold magma_op, refa309_inst, refa309_op in H. discriminate H. Qed.

Lemma refa309_not3668 : ~ @Equation3668 Fin4 refa309_inst.
Proof. unfold Equation3668. intro H. specialize (H F4_2 F4_0). unfold magma_op, refa309_inst, refa309_op in H. discriminate H. Qed.

Lemma refa309_not3674 : ~ @Equation3674 Fin4 refa309_inst.
Proof. unfold Equation3674. intro H. specialize (H F4_0 F4_2). unfold magma_op, refa309_inst, refa309_op in H. discriminate H. Qed.

Lemma refa309_not3678 : ~ @Equation3678 Fin4 refa309_inst.
Proof. unfold Equation3678. intro H. specialize (H F4_0 F4_2). unfold magma_op, refa309_inst, refa309_op in H. discriminate H. Qed.

Lemma refa309_not4268 : ~ @Equation4268 Fin4 refa309_inst.
Proof. unfold Equation4268. intro H. specialize (H F4_0 F4_2). unfold magma_op, refa309_inst, refa309_op in H. discriminate H. Qed.

Lemma refa309_not4269 : ~ @Equation4269 Fin4 refa309_inst.
Proof. unfold Equation4269. intro H. specialize (H F4_2 F4_0). unfold magma_op, refa309_inst, refa309_op in H. discriminate H. Qed.

Lemma refa309_not4283 : ~ @Equation4283 Fin4 refa309_inst.
Proof. unfold Equation4283. intro H. specialize (H F4_0 F4_2). unfold magma_op, refa309_inst, refa309_op in H. discriminate H. Qed.

Lemma refa309_not4284 : ~ @Equation4284 Fin4 refa309_inst.
Proof. unfold Equation4284. intro H. specialize (H F4_0 F4_2). unfold magma_op, refa309_inst, refa309_op in H. discriminate H. Qed.

Lemma refa309_not4314 : ~ @Equation4314 Fin4 refa309_inst.
Proof. unfold Equation4314. intro H. specialize (H F4_2 F4_0). unfold magma_op, refa309_inst, refa309_op in H. discriminate H. Qed.

Lemma refa309_not4673 : ~ @Equation4673 Fin4 refa309_inst.
Proof. unfold Equation4673. intro H. specialize (H F4_2 F4_0 F4_3). unfold magma_op, refa309_inst, refa309_op in H. discriminate H. Qed.

(** ---- refa31 (Fin9) ---- *)

Definition refa31_op (x y : Fin9) : Fin9 :=
  match x, y with
  | F9_0, F9_0 => F9_0 | F9_0, F9_1 => F9_2 | F9_0, F9_2 => F9_1 | F9_0, F9_3 => F9_4 | F9_0, F9_4 => F9_3 | F9_0, F9_5 => F9_6 | F9_0, F9_6 => F9_5 | F9_0, F9_7 => F9_8 | F9_0, F9_8 => F9_7
  | F9_1, F9_0 => F9_3 | F9_1, F9_1 => F9_1 | F9_1, F9_2 => F9_5 | F9_1, F9_3 => F9_0 | F9_1, F9_4 => F9_7 | F9_1, F9_5 => F9_2 | F9_1, F9_6 => F9_8 | F9_1, F9_7 => F9_4 | F9_1, F9_8 => F9_6
  | F9_2, F9_0 => F9_4 | F9_2, F9_1 => F9_6 | F9_2, F9_2 => F9_2 | F9_2, F9_3 => F9_8 | F9_2, F9_4 => F9_0 | F9_2, F9_5 => F9_7 | F9_2, F9_6 => F9_1 | F9_2, F9_7 => F9_5 | F9_2, F9_8 => F9_3
  | F9_3, F9_0 => F9_7 | F9_3, F9_1 => F9_5 | F9_3, F9_2 => F9_8 | F9_3, F9_3 => F9_3 | F9_3, F9_4 => F9_6 | F9_3, F9_5 => F9_1 | F9_3, F9_6 => F9_4 | F9_3, F9_7 => F9_0 | F9_3, F9_8 => F9_2
  | F9_4, F9_0 => F9_8 | F9_4, F9_1 => F9_7 | F9_4, F9_2 => F9_6 | F9_4, F9_3 => F9_5 | F9_4, F9_4 => F9_4 | F9_4, F9_5 => F9_3 | F9_4, F9_6 => F9_2 | F9_4, F9_7 => F9_1 | F9_4, F9_8 => F9_0
  | F9_5, F9_0 => F9_6 | F9_5, F9_1 => F9_8 | F9_5, F9_2 => F9_4 | F9_5, F9_3 => F9_7 | F9_5, F9_4 => F9_2 | F9_5, F9_5 => F9_5 | F9_5, F9_6 => F9_0 | F9_5, F9_7 => F9_3 | F9_5, F9_8 => F9_1
  | F9_6, F9_0 => F9_5 | F9_6, F9_1 => F9_3 | F9_6, F9_2 => F9_7 | F9_6, F9_3 => F9_1 | F9_6, F9_4 => F9_8 | F9_6, F9_5 => F9_0 | F9_6, F9_6 => F9_6 | F9_6, F9_7 => F9_2 | F9_6, F9_8 => F9_4
  | F9_7, F9_0 => F9_2 | F9_7, F9_1 => F9_4 | F9_7, F9_2 => F9_0 | F9_7, F9_3 => F9_6 | F9_7, F9_4 => F9_1 | F9_7, F9_5 => F9_8 | F9_7, F9_6 => F9_3 | F9_7, F9_7 => F9_7 | F9_7, F9_8 => F9_5
  | F9_8, F9_0 => F9_1 | F9_8, F9_1 => F9_0 | F9_8, F9_2 => F9_3 | F9_8, F9_3 => F9_2 | F9_8, F9_4 => F9_5 | F9_8, F9_5 => F9_4 | F9_8, F9_6 => F9_7 | F9_8, F9_7 => F9_6 | F9_8, F9_8 => F9_8
  end.

#[local] Instance refa31_inst : Magma Fin9 := {| magma_op := refa31_op |}.

Lemma refa31_sat2700 : @Equation2700 Fin9 refa31_inst.
Proof. unfold Equation2700, magma_op, refa31_inst, refa31_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa31_not2709 : ~ @Equation2709 Fin9 refa31_inst.
Proof. unfold Equation2709. intro H. specialize (H F9_0 F9_1). unfold magma_op, refa31_inst, refa31_op in H. discriminate H. Qed.

Lemma refa31_not2736 : ~ @Equation2736 Fin9 refa31_inst.
Proof. unfold Equation2736. intro H. specialize (H F9_0 F9_1). unfold magma_op, refa31_inst, refa31_op in H. discriminate H. Qed.

Lemma refa31_not2910 : ~ @Equation2910 Fin9 refa31_inst.
Proof. unfold Equation2910. intro H. specialize (H F9_0 F9_1). unfold magma_op, refa31_inst, refa31_op in H. discriminate H. Qed.

Lemma refa31_not2912 : ~ @Equation2912 Fin9 refa31_inst.
Proof. unfold Equation2912. intro H. specialize (H F9_0 F9_1). unfold magma_op, refa31_inst, refa31_op in H. discriminate H. Qed.

Lemma refa31_not4658 : ~ @Equation4658 Fin9 refa31_inst.
Proof. unfold Equation4658. intro H. specialize (H F9_0 F9_1). unfold magma_op, refa31_inst, refa31_op in H. discriminate H. Qed.

(** ---- refa310 (Fin4) ---- *)

Definition refa310_op (x y : Fin4) : Fin4 :=
  match x, y with
  | F4_0, F4_0 => F4_0 | F4_0, F4_1 => F4_1 | F4_0, F4_2 => F4_2 | F4_0, F4_3 => F4_3
  | F4_1, F4_0 => F4_1 | F4_1, F4_1 => F4_0 | F4_1, F4_2 => F4_0 | F4_1, F4_3 => F4_1
  | F4_2, F4_0 => F4_1 | F4_2, F4_1 => F4_0 | F4_2, F4_2 => F4_3 | F4_2, F4_3 => F4_2
  | F4_3, F4_0 => F4_3 | F4_3, F4_1 => F4_1 | F4_3, F4_2 => F4_1 | F4_3, F4_3 => F4_0
  end.

#[local] Instance refa310_inst : Magma Fin4 := {| magma_op := refa310_op |}.

Lemma refa310_sat2503 : @Equation2503 Fin4 refa310_inst.
Proof. unfold Equation2503, magma_op, refa310_inst, refa310_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa310_sat3068 : @Equation3068 Fin4 refa310_inst.
Proof. unfold Equation3068, magma_op, refa310_inst, refa310_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa310_sat3152 : @Equation3152 Fin4 refa310_inst.
Proof. unfold Equation3152, magma_op, refa310_inst, refa310_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa310_not1629 : ~ @Equation1629 Fin4 refa310_inst.
Proof. unfold Equation1629. intro H. specialize (H F4_2). unfold magma_op, refa310_inst, refa310_op in H. discriminate H. Qed.

Lemma refa310_not2238 : ~ @Equation2238 Fin4 refa310_inst.
Proof. unfold Equation2238. intro H. specialize (H F4_2). unfold magma_op, refa310_inst, refa310_op in H. discriminate H. Qed.

Lemma refa310_not2449 : ~ @Equation2449 Fin4 refa310_inst.
Proof. unfold Equation2449. intro H. specialize (H F4_0 F4_2). unfold magma_op, refa310_inst, refa310_op in H. discriminate H. Qed.

Lemma refa310_not2459 : ~ @Equation2459 Fin4 refa310_inst.
Proof. unfold Equation2459. intro H. specialize (H F4_3 F4_1). unfold magma_op, refa310_inst, refa310_op in H. discriminate H. Qed.

Lemma refa310_not2466 : ~ @Equation2466 Fin4 refa310_inst.
Proof. unfold Equation2466. intro H. specialize (H F4_0 F4_2). unfold magma_op, refa310_inst, refa310_op in H. discriminate H. Qed.

Lemma refa310_not3058 : ~ @Equation3058 Fin4 refa310_inst.
Proof. unfold Equation3058. intro H. specialize (H F4_0 F4_2). unfold magma_op, refa310_inst, refa310_op in H. discriminate H. Qed.

Lemma refa310_not3271 : ~ @Equation3271 Fin4 refa310_inst.
Proof. unfold Equation3271. intro H. specialize (H F4_1 F4_3). unfold magma_op, refa310_inst, refa310_op in H. discriminate H. Qed.

Lemma refa310_not4320 : ~ @Equation4320 Fin4 refa310_inst.
Proof. unfold Equation4320. intro H. specialize (H F4_1 F4_3). unfold magma_op, refa310_inst, refa310_op in H. discriminate H. Qed.

(** ---- refa311 (Fin4) ---- *)

Definition refa311_op (x y : Fin4) : Fin4 :=
  match x, y with
  | F4_0, F4_0 => F4_3 | F4_0, F4_1 => F4_1 | F4_0, F4_2 => F4_3 | F4_0, F4_3 => F4_1
  | F4_1, F4_0 => F4_3 | F4_1, F4_1 => F4_3 | F4_1, F4_2 => F4_0 | F4_1, F4_3 => F4_3
  | F4_2, F4_0 => F4_1 | F4_2, F4_1 => F4_3 | F4_2, F4_2 => F4_3 | F4_2, F4_3 => F4_3
  | F4_3, F4_0 => F4_1 | F4_3, F4_1 => F4_3 | F4_3, F4_2 => F4_3 | F4_3, F4_3 => F4_3
  end.

#[local] Instance refa311_inst : Magma Fin4 := {| magma_op := refa311_op |}.

Lemma refa311_sat3894 : @Equation3894 Fin4 refa311_inst.
Proof. unfold Equation3894, magma_op, refa311_inst, refa311_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa311_not3660 : ~ @Equation3660 Fin4 refa311_inst.
Proof. unfold Equation3660. intro H. specialize (H F4_1 F4_2). unfold magma_op, refa311_inst, refa311_op in H. discriminate H. Qed.

Lemma refa311_not3661 : ~ @Equation3661 Fin4 refa311_inst.
Proof. unfold Equation3661. intro H. specialize (H F4_2 F4_1). unfold magma_op, refa311_inst, refa311_op in H. discriminate H. Qed.

Lemma refa311_not3685 : ~ @Equation3685 Fin4 refa311_inst.
Proof. unfold Equation3685. intro H. specialize (H F4_1 F4_2). unfold magma_op, refa311_inst, refa311_op in H. discriminate H. Qed.

Lemma refa311_not3687 : ~ @Equation3687 Fin4 refa311_inst.
Proof. unfold Equation3687. intro H. specialize (H F4_2 F4_1). unfold magma_op, refa311_inst, refa311_op in H. discriminate H. Qed.

Lemma refa311_not3721 : ~ @Equation3721 Fin4 refa311_inst.
Proof. unfold Equation3721. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa311_inst, refa311_op in H. discriminate H. Qed.

Lemma refa311_not3725 : ~ @Equation3725 Fin4 refa311_inst.
Proof. unfold Equation3725. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa311_inst, refa311_op in H. discriminate H. Qed.

Lemma refa311_not3867 : ~ @Equation3867 Fin4 refa311_inst.
Proof. unfold Equation3867. intro H. specialize (H F4_2 F4_1). unfold magma_op, refa311_inst, refa311_op in H. discriminate H. Qed.

Lemma refa311_not3881 : ~ @Equation3881 Fin4 refa311_inst.
Proof. unfold Equation3881. intro H. specialize (H F4_1 F4_2). unfold magma_op, refa311_inst, refa311_op in H. discriminate H. Qed.

(** ---- refa312 (Fin4) ---- *)

Definition refa312_op (x y : Fin4) : Fin4 :=
  match x, y with
  | F4_0, F4_0 => F4_1 | F4_0, F4_1 => F4_1 | F4_0, F4_2 => F4_1 | F4_0, F4_3 => F4_1
  | F4_1, F4_0 => F4_2 | F4_1, F4_1 => F4_2 | F4_1, F4_2 => F4_2 | F4_1, F4_3 => F4_2
  | F4_2, F4_0 => F4_0 | F4_2, F4_1 => F4_0 | F4_2, F4_2 => F4_3 | F4_2, F4_3 => F4_3
  | F4_3, F4_0 => F4_1 | F4_3, F4_1 => F4_1 | F4_3, F4_2 => F4_1 | F4_3, F4_3 => F4_1
  end.

#[local] Instance refa312_inst : Magma Fin4 := {| magma_op := refa312_op |}.

Lemma refa312_sat2691 : @Equation2691 Fin4 refa312_inst.
Proof. unfold Equation2691, magma_op, refa312_inst, refa312_op. intros x y z w. destruct x, y, z, w; reflexivity. Qed.

Lemma refa312_not2035 : ~ @Equation2035 Fin4 refa312_inst.
Proof. unfold Equation2035. intro H. specialize (H F4_3). unfold magma_op, refa312_inst, refa312_op in H. discriminate H. Qed.

Lemma refa312_not3309 : ~ @Equation3309 Fin4 refa312_inst.
Proof. unfold Equation3309. intro H. specialize (H F4_2 F4_1). unfold magma_op, refa312_inst, refa312_op in H. discriminate H. Qed.

Lemma refa312_not3316 : ~ @Equation3316 Fin4 refa312_inst.
Proof. unfold Equation3316. intro H. specialize (H F4_2 F4_1). unfold magma_op, refa312_inst, refa312_op in H. discriminate H. Qed.

Lemma refa312_not3319 : ~ @Equation3319 Fin4 refa312_inst.
Proof. unfold Equation3319. intro H. specialize (H F4_2 F4_1). unfold magma_op, refa312_inst, refa312_op in H. discriminate H. Qed.

Lemma refa312_not3456 : ~ @Equation3456 Fin4 refa312_inst.
Proof. unfold Equation3456. intro H. specialize (H F4_2). unfold magma_op, refa312_inst, refa312_op in H. discriminate H. Qed.

Lemma refa312_not4284 : ~ @Equation4284 Fin4 refa312_inst.
Proof. unfold Equation4284. intro H. specialize (H F4_2 F4_1). unfold magma_op, refa312_inst, refa312_op in H. discriminate H. Qed.

(** ---- refa313 (Fin4) ---- *)

Definition refa313_op (x y : Fin4) : Fin4 :=
  match x, y with
  | F4_0, F4_0 => F4_0 | F4_0, F4_1 => F4_0 | F4_0, F4_2 => F4_1 | F4_0, F4_3 => F4_3
  | F4_1, F4_0 => F4_3 | F4_1, F4_1 => F4_1 | F4_1, F4_2 => F4_3 | F4_1, F4_3 => F4_1
  | F4_2, F4_0 => F4_3 | F4_2, F4_1 => F4_1 | F4_2, F4_2 => F4_0 | F4_2, F4_3 => F4_2
  | F4_3, F4_0 => F4_1 | F4_3, F4_1 => F4_3 | F4_3, F4_2 => F4_1 | F4_3, F4_3 => F4_3
  end.

#[local] Instance refa313_inst : Magma Fin4 := {| magma_op := refa313_op |}.

Lemma refa313_sat1229 : @Equation1229 Fin4 refa313_inst.
Proof. unfold Equation1229, magma_op, refa313_inst, refa313_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa313_not411 : ~ @Equation411 Fin4 refa313_inst.
Proof. unfold Equation411. intro H. specialize (H F4_2). unfold magma_op, refa313_inst, refa313_op in H. discriminate H. Qed.

Lemma refa313_not818 : ~ @Equation818 Fin4 refa313_inst.
Proof. unfold Equation818. intro H. specialize (H F4_0 F4_3). unfold magma_op, refa313_inst, refa313_op in H. discriminate H. Qed.

Lemma refa313_not819 : ~ @Equation819 Fin4 refa313_inst.
Proof. unfold Equation819. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa313_inst, refa313_op in H. discriminate H. Qed.

Lemma refa313_not832 : ~ @Equation832 Fin4 refa313_inst.
Proof. unfold Equation832. intro H. specialize (H F4_0 F4_3). unfold magma_op, refa313_inst, refa313_op in H. discriminate H. Qed.

Lemma refa313_not836 : ~ @Equation836 Fin4 refa313_inst.
Proof. unfold Equation836. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa313_inst, refa313_op in H. discriminate H. Qed.

Lemma refa313_not843 : ~ @Equation843 Fin4 refa313_inst.
Proof. unfold Equation843. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa313_inst, refa313_op in H. discriminate H. Qed.

Lemma refa313_not845 : ~ @Equation845 Fin4 refa313_inst.
Proof. unfold Equation845. intro H. specialize (H F4_0 F4_2). unfold magma_op, refa313_inst, refa313_op in H. discriminate H. Qed.

Lemma refa313_not1020 : ~ @Equation1020 Fin4 refa313_inst.
Proof. unfold Equation1020. intro H. specialize (H F4_2). unfold magma_op, refa313_inst, refa313_op in H. discriminate H. Qed.

Lemma refa313_not1224 : ~ @Equation1224 Fin4 refa313_inst.
Proof. unfold Equation1224. intro H. specialize (H F4_0 F4_3). unfold magma_op, refa313_inst, refa313_op in H. discriminate H. Qed.

Lemma refa313_not1238 : ~ @Equation1238 Fin4 refa313_inst.
Proof. unfold Equation1238. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa313_inst, refa313_op in H. discriminate H. Qed.

Lemma refa313_not1242 : ~ @Equation1242 Fin4 refa313_inst.
Proof. unfold Equation1242. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa313_inst, refa313_op in H. discriminate H. Qed.

Lemma refa313_not1248 : ~ @Equation1248 Fin4 refa313_inst.
Proof. unfold Equation1248. intro H. specialize (H F4_0 F4_3). unfold magma_op, refa313_inst, refa313_op in H. discriminate H. Qed.

Lemma refa313_not1251 : ~ @Equation1251 Fin4 refa313_inst.
Proof. unfold Equation1251. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa313_inst, refa313_op in H. discriminate H. Qed.

Lemma refa313_not1832 : ~ @Equation1832 Fin4 refa313_inst.
Proof. unfold Equation1832. intro H. specialize (H F4_2). unfold magma_op, refa313_inst, refa313_op in H. discriminate H. Qed.

(** ---- refa314 (Fin4) ---- *)

Definition refa314_op (x y : Fin4) : Fin4 :=
  match x, y with
  | F4_0, F4_0 => F4_2 | F4_0, F4_1 => F4_1 | F4_0, F4_2 => F4_0 | F4_0, F4_3 => F4_1
  | F4_1, F4_0 => F4_2 | F4_1, F4_1 => F4_2 | F4_1, F4_2 => F4_1 | F4_1, F4_3 => F4_2
  | F4_2, F4_0 => F4_2 | F4_2, F4_1 => F4_2 | F4_2, F4_2 => F4_2 | F4_2, F4_3 => F4_2
  | F4_3, F4_0 => F4_0 | F4_3, F4_1 => F4_0 | F4_3, F4_2 => F4_3 | F4_3, F4_3 => F4_2
  end.

#[local] Instance refa314_inst : Magma Fin4 := {| magma_op := refa314_op |}.

Lemma refa314_sat1257 : @Equation1257 Fin4 refa314_inst.
Proof. unfold Equation1257, magma_op, refa314_inst, refa314_op. intros x y z w. destruct x, y, z, w; reflexivity. Qed.

Lemma refa314_sat1264 : @Equation1264 Fin4 refa314_inst.
Proof. unfold Equation1264, magma_op, refa314_inst, refa314_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa314_sat1267 : @Equation1267 Fin4 refa314_inst.
Proof. unfold Equation1267, magma_op, refa314_inst, refa314_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa314_not1023 : ~ @Equation1023 Fin4 refa314_inst.
Proof. unfold Equation1023. intro H. specialize (H F4_3 F4_1). unfold magma_op, refa314_inst, refa314_op in H. discriminate H. Qed.

Lemma refa314_not1025 : ~ @Equation1025 Fin4 refa314_inst.
Proof. unfold Equation1025. intro H. specialize (H F4_3 F4_0). unfold magma_op, refa314_inst, refa314_op in H. discriminate H. Qed.

Lemma refa314_not1039 : ~ @Equation1039 Fin4 refa314_inst.
Proof. unfold Equation1039. intro H. specialize (H F4_0 F4_3). unfold magma_op, refa314_inst, refa314_op in H. discriminate H. Qed.

Lemma refa314_not1045 : ~ @Equation1045 Fin4 refa314_inst.
Proof. unfold Equation1045. intro H. specialize (H F4_1 F4_3). unfold magma_op, refa314_inst, refa314_op in H. discriminate H. Qed.

Lemma refa314_not4598 : ~ @Equation4598 Fin4 refa314_inst.
Proof. unfold Equation4598. intro H. specialize (H F4_3 F4_0). unfold magma_op, refa314_inst, refa314_op in H. discriminate H. Qed.

(** ---- refa315 (Fin4) ---- *)

Definition refa315_op (x y : Fin4) : Fin4 :=
  match x, y with
  | F4_0, F4_0 => F4_3 | F4_0, F4_1 => F4_3 | F4_0, F4_2 => F4_2 | F4_0, F4_3 => F4_3
  | F4_1, F4_0 => F4_3 | F4_1, F4_1 => F4_2 | F4_1, F4_2 => F4_2 | F4_1, F4_3 => F4_3
  | F4_2, F4_0 => F4_2 | F4_2, F4_1 => F4_2 | F4_2, F4_2 => F4_2 | F4_2, F4_3 => F4_3
  | F4_3, F4_0 => F4_3 | F4_3, F4_1 => F4_3 | F4_3, F4_2 => F4_2 | F4_3, F4_3 => F4_3
  end.

#[local] Instance refa315_inst : Magma Fin4 := {| magma_op := refa315_op |}.

Lemma refa315_sat3587 : @Equation3587 Fin4 refa315_inst.
Proof. unfold Equation3587, magma_op, refa315_inst, refa315_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa315_sat3600 : @Equation3600 Fin4 refa315_inst.
Proof. unfold Equation3600, magma_op, refa315_inst, refa315_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa315_not3509 : ~ @Equation3509 Fin4 refa315_inst.
Proof. unfold Equation3509. intro H. specialize (H F4_1 F4_0). unfold magma_op, refa315_inst, refa315_op in H. discriminate H. Qed.

Lemma refa315_not3546 : ~ @Equation3546 Fin4 refa315_inst.
Proof. unfold Equation3546. intro H. specialize (H F4_1 F4_0). unfold magma_op, refa315_inst, refa315_op in H. discriminate H. Qed.

Lemma refa315_not3915 : ~ @Equation3915 Fin4 refa315_inst.
Proof. unfold Equation3915. intro H. specialize (H F4_1 F4_0). unfold magma_op, refa315_inst, refa315_op in H. discriminate H. Qed.

Lemma refa315_not3952 : ~ @Equation3952 Fin4 refa315_inst.
Proof. unfold Equation3952. intro H. specialize (H F4_1 F4_0). unfold magma_op, refa315_inst, refa315_op in H. discriminate H. Qed.

Lemma refa315_not4118 : ~ @Equation4118 Fin4 refa315_inst.
Proof. unfold Equation4118. intro H. specialize (H F4_1 F4_0). unfold magma_op, refa315_inst, refa315_op in H. discriminate H. Qed.

Lemma refa315_not4121 : ~ @Equation4121 Fin4 refa315_inst.
Proof. unfold Equation4121. intro H. specialize (H F4_1 F4_0). unfold magma_op, refa315_inst, refa315_op in H. discriminate H. Qed.

Lemma refa315_not4165 : ~ @Equation4165 Fin4 refa315_inst.
Proof. unfold Equation4165. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa315_inst, refa315_op in H. discriminate H. Qed.

Lemma refa315_not4396 : ~ @Equation4396 Fin4 refa315_inst.
Proof. unfold Equation4396. intro H. specialize (H F4_1 F4_0). unfold magma_op, refa315_inst, refa315_op in H. discriminate H. Qed.

Lemma refa315_not4445 : ~ @Equation4445 Fin4 refa315_inst.
Proof. unfold Equation4445. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa315_inst, refa315_op in H. discriminate H. Qed.

Lemma refa315_not4599 : ~ @Equation4599 Fin4 refa315_inst.
Proof. unfold Equation4599. intro H. specialize (H F4_1 F4_0). unfold magma_op, refa315_inst, refa315_op in H. discriminate H. Qed.

Lemma refa315_not4606 : ~ @Equation4606 Fin4 refa315_inst.
Proof. unfold Equation4606. intro H. specialize (H F4_1 F4_0). unfold magma_op, refa315_inst, refa315_op in H. discriminate H. Qed.

(** ---- refa316 (Fin4) ---- *)

Definition refa316_op (x y : Fin4) : Fin4 :=
  match x, y with
  | F4_0, F4_0 => F4_2 | F4_0, F4_1 => F4_3 | F4_0, F4_2 => F4_0 | F4_0, F4_3 => F4_1
  | F4_1, F4_0 => F4_3 | F4_1, F4_1 => F4_0 | F4_1, F4_2 => F4_1 | F4_1, F4_3 => F4_2
  | F4_2, F4_0 => F4_0 | F4_2, F4_1 => F4_1 | F4_2, F4_2 => F4_2 | F4_2, F4_3 => F4_3
  | F4_3, F4_0 => F4_1 | F4_3, F4_1 => F4_2 | F4_3, F4_2 => F4_3 | F4_3, F4_3 => F4_0
  end.

#[local] Instance refa316_inst : Magma Fin4 := {| magma_op := refa316_op |}.

Lemma refa316_sat440 : @Equation440 Fin4 refa316_inst.
Proof. unfold Equation440, magma_op, refa316_inst, refa316_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa316_sat513 : @Equation513 Fin4 refa316_inst.
Proof. unfold Equation513, magma_op, refa316_inst, refa316_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa316_sat714 : @Equation714 Fin4 refa316_inst.
Proof. unfold Equation714, magma_op, refa316_inst, refa316_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa316_sat883 : @Equation883 Fin4 refa316_inst.
Proof. unfold Equation883, magma_op, refa316_inst, refa316_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa316_sat910 : @Equation910 Fin4 refa316_inst.
Proof. unfold Equation910, magma_op, refa316_inst, refa316_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa316_sat917 : @Equation917 Fin4 refa316_inst.
Proof. unfold Equation917, magma_op, refa316_inst, refa316_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa316_sat1323 : @Equation1323 Fin4 refa316_inst.
Proof. unfold Equation1323, magma_op, refa316_inst, refa316_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa316_sat1492 : @Equation1492 Fin4 refa316_inst.
Proof. unfold Equation1492, magma_op, refa316_inst, refa316_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa316_sat1528 : @Equation1528 Fin4 refa316_inst.
Proof. unfold Equation1528, magma_op, refa316_inst, refa316_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa316_sat1729 : @Equation1729 Fin4 refa316_inst.
Proof. unfold Equation1729, magma_op, refa316_inst, refa316_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa316_sat1898 : @Equation1898 Fin4 refa316_inst.
Proof. unfold Equation1898, magma_op, refa316_inst, refa316_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa316_sat1932 : @Equation1932 Fin4 refa316_inst.
Proof. unfold Equation1932, magma_op, refa316_inst, refa316_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa316_sat2064 : @Equation2064 Fin4 refa316_inst.
Proof. unfold Equation2064, magma_op, refa316_inst, refa316_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa316_sat2304 : @Equation2304 Fin4 refa316_inst.
Proof. unfold Equation2304, magma_op, refa316_inst, refa316_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa316_sat2331 : @Equation2331 Fin4 refa316_inst.
Proof. unfold Equation2331, magma_op, refa316_inst, refa316_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa316_sat2507 : @Equation2507 Fin4 refa316_inst.
Proof. unfold Equation2507, magma_op, refa316_inst, refa316_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa316_sat2710 : @Equation2710 Fin4 refa316_inst.
Proof. unfold Equation2710, magma_op, refa316_inst, refa316_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa316_sat2737 : @Equation2737 Fin4 refa316_inst.
Proof. unfold Equation2737, magma_op, refa316_inst, refa316_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa316_sat2744 : @Equation2744 Fin4 refa316_inst.
Proof. unfold Equation2744, magma_op, refa316_inst, refa316_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa316_sat3079 : @Equation3079 Fin4 refa316_inst.
Proof. unfold Equation3079, magma_op, refa316_inst, refa316_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa316_sat3152 : @Equation3152 Fin4 refa316_inst.
Proof. unfold Equation3152, magma_op, refa316_inst, refa316_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa316_not417 : ~ @Equation417 Fin4 refa316_inst.
Proof. unfold Equation417. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa316_inst, refa316_op in H. discriminate H. Qed.

Lemma refa316_not419 : ~ @Equation419 Fin4 refa316_inst.
Proof. unfold Equation419. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa316_inst, refa316_op in H. discriminate H. Qed.

Lemma refa316_not427 : ~ @Equation427 Fin4 refa316_inst.
Proof. unfold Equation427. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa316_inst, refa316_op in H. discriminate H. Qed.

Lemma refa316_not429 : ~ @Equation429 Fin4 refa316_inst.
Proof. unfold Equation429. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa316_inst, refa316_op in H. discriminate H. Qed.

Lemma refa316_not436 : ~ @Equation436 Fin4 refa316_inst.
Proof. unfold Equation436. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa316_inst, refa316_op in H. discriminate H. Qed.

Lemma refa316_not466 : ~ @Equation466 Fin4 refa316_inst.
Proof. unfold Equation466. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa316_inst, refa316_op in H. discriminate H. Qed.

Lemma refa316_not473 : ~ @Equation473 Fin4 refa316_inst.
Proof. unfold Equation473. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa316_inst, refa316_op in H. discriminate H. Qed.

Lemma refa316_not620 : ~ @Equation620 Fin4 refa316_inst.
Proof. unfold Equation620. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa316_inst, refa316_op in H. discriminate H. Qed.

Lemma refa316_not622 : ~ @Equation622 Fin4 refa316_inst.
Proof. unfold Equation622. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa316_inst, refa316_op in H. discriminate H. Qed.

Lemma refa316_not630 : ~ @Equation630 Fin4 refa316_inst.
Proof. unfold Equation630. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa316_inst, refa316_op in H. discriminate H. Qed.

Lemma refa316_not632 : ~ @Equation632 Fin4 refa316_inst.
Proof. unfold Equation632. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa316_inst, refa316_op in H. discriminate H. Qed.

Lemma refa316_not639 : ~ @Equation639 Fin4 refa316_inst.
Proof. unfold Equation639. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa316_inst, refa316_op in H. discriminate H. Qed.

Lemma refa316_not669 : ~ @Equation669 Fin4 refa316_inst.
Proof. unfold Equation669. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa316_inst, refa316_op in H. discriminate H. Qed.

Lemma refa316_not676 : ~ @Equation676 Fin4 refa316_inst.
Proof. unfold Equation676. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa316_inst, refa316_op in H. discriminate H. Qed.

Lemma refa316_not825 : ~ @Equation825 Fin4 refa316_inst.
Proof. unfold Equation825. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa316_inst, refa316_op in H. discriminate H. Qed.

Lemma refa316_not833 : ~ @Equation833 Fin4 refa316_inst.
Proof. unfold Equation833. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa316_inst, refa316_op in H. discriminate H. Qed.

Lemma refa316_not835 : ~ @Equation835 Fin4 refa316_inst.
Proof. unfold Equation835. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa316_inst, refa316_op in H. discriminate H. Qed.

Lemma refa316_not842 : ~ @Equation842 Fin4 refa316_inst.
Proof. unfold Equation842. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa316_inst, refa316_op in H. discriminate H. Qed.

Lemma refa316_not870 : ~ @Equation870 Fin4 refa316_inst.
Proof. unfold Equation870. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa316_inst, refa316_op in H. discriminate H. Qed.

Lemma refa316_not872 : ~ @Equation872 Fin4 refa316_inst.
Proof. unfold Equation872. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa316_inst, refa316_op in H. discriminate H. Qed.

Lemma refa316_not879 : ~ @Equation879 Fin4 refa316_inst.
Proof. unfold Equation879. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa316_inst, refa316_op in H. discriminate H. Qed.

Lemma refa316_not906 : ~ @Equation906 Fin4 refa316_inst.
Proof. unfold Equation906. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa316_inst, refa316_op in H. discriminate H. Qed.

Lemma refa316_not1023 : ~ @Equation1023 Fin4 refa316_inst.
Proof. unfold Equation1023. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa316_inst, refa316_op in H. discriminate H. Qed.

Lemma refa316_not1026 : ~ @Equation1026 Fin4 refa316_inst.
Proof. unfold Equation1026. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa316_inst, refa316_op in H. discriminate H. Qed.

Lemma refa316_not1028 : ~ @Equation1028 Fin4 refa316_inst.
Proof. unfold Equation1028. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa316_inst, refa316_op in H. discriminate H. Qed.

Lemma refa316_not1036 : ~ @Equation1036 Fin4 refa316_inst.
Proof. unfold Equation1036. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa316_inst, refa316_op in H. discriminate H. Qed.

Lemma refa316_not1038 : ~ @Equation1038 Fin4 refa316_inst.
Proof. unfold Equation1038. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa316_inst, refa316_op in H. discriminate H. Qed.

Lemma refa316_not1045 : ~ @Equation1045 Fin4 refa316_inst.
Proof. unfold Equation1045. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa316_inst, refa316_op in H. discriminate H. Qed.

Lemma refa316_not1075 : ~ @Equation1075 Fin4 refa316_inst.
Proof. unfold Equation1075. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa316_inst, refa316_op in H. discriminate H. Qed.

Lemma refa316_not1082 : ~ @Equation1082 Fin4 refa316_inst.
Proof. unfold Equation1082. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa316_inst, refa316_op in H. discriminate H. Qed.

Lemma refa316_not1109 : ~ @Equation1109 Fin4 refa316_inst.
Proof. unfold Equation1109. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa316_inst, refa316_op in H. discriminate H. Qed.

Lemma refa316_not1229 : ~ @Equation1229 Fin4 refa316_inst.
Proof. unfold Equation1229. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa316_inst, refa316_op in H. discriminate H. Qed.

Lemma refa316_not1239 : ~ @Equation1239 Fin4 refa316_inst.
Proof. unfold Equation1239. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa316_inst, refa316_op in H. discriminate H. Qed.

Lemma refa316_not1241 : ~ @Equation1241 Fin4 refa316_inst.
Proof. unfold Equation1241. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa316_inst, refa316_op in H. discriminate H. Qed.

Lemma refa316_not1276 : ~ @Equation1276 Fin4 refa316_inst.
Proof. unfold Equation1276. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa316_inst, refa316_op in H. discriminate H. Qed.

Lemma refa316_not1434 : ~ @Equation1434 Fin4 refa316_inst.
Proof. unfold Equation1434. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa316_inst, refa316_op in H. discriminate H. Qed.

Lemma refa316_not1451 : ~ @Equation1451 Fin4 refa316_inst.
Proof. unfold Equation1451. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa316_inst, refa316_op in H. discriminate H. Qed.

Lemma refa316_not1479 : ~ @Equation1479 Fin4 refa316_inst.
Proof. unfold Equation1479. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa316_inst, refa316_op in H. discriminate H. Qed.

Lemma refa316_not1488 : ~ @Equation1488 Fin4 refa316_inst.
Proof. unfold Equation1488. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa316_inst, refa316_op in H. discriminate H. Qed.

Lemma refa316_not1515 : ~ @Equation1515 Fin4 refa316_inst.
Proof. unfold Equation1515. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa316_inst, refa316_op in H. discriminate H. Qed.

Lemma refa316_not1632 : ~ @Equation1632 Fin4 refa316_inst.
Proof. unfold Equation1632. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa316_inst, refa316_op in H. discriminate H. Qed.

Lemma refa316_not1635 : ~ @Equation1635 Fin4 refa316_inst.
Proof. unfold Equation1635. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa316_inst, refa316_op in H. discriminate H. Qed.

Lemma refa316_not1637 : ~ @Equation1637 Fin4 refa316_inst.
Proof. unfold Equation1637. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa316_inst, refa316_op in H. discriminate H. Qed.

Lemma refa316_not1645 : ~ @Equation1645 Fin4 refa316_inst.
Proof. unfold Equation1645. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa316_inst, refa316_op in H. discriminate H. Qed.

Lemma refa316_not1654 : ~ @Equation1654 Fin4 refa316_inst.
Proof. unfold Equation1654. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa316_inst, refa316_op in H. discriminate H. Qed.

Lemma refa316_not1682 : ~ @Equation1682 Fin4 refa316_inst.
Proof. unfold Equation1682. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa316_inst, refa316_op in H. discriminate H. Qed.

Lemma refa316_not1684 : ~ @Equation1684 Fin4 refa316_inst.
Proof. unfold Equation1684. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa316_inst, refa316_op in H. discriminate H. Qed.

Lemma refa316_not1691 : ~ @Equation1691 Fin4 refa316_inst.
Proof. unfold Equation1691. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa316_inst, refa316_op in H. discriminate H. Qed.

Lemma refa316_not1838 : ~ @Equation1838 Fin4 refa316_inst.
Proof. unfold Equation1838. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa316_inst, refa316_op in H. discriminate H. Qed.

Lemma refa316_not1840 : ~ @Equation1840 Fin4 refa316_inst.
Proof. unfold Equation1840. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa316_inst, refa316_op in H. discriminate H. Qed.

Lemma refa316_not1848 : ~ @Equation1848 Fin4 refa316_inst.
Proof. unfold Equation1848. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa316_inst, refa316_op in H. discriminate H. Qed.

Lemma refa316_not1857 : ~ @Equation1857 Fin4 refa316_inst.
Proof. unfold Equation1857. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa316_inst, refa316_op in H. discriminate H. Qed.

Lemma refa316_not1885 : ~ @Equation1885 Fin4 refa316_inst.
Proof. unfold Equation1885. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa316_inst, refa316_op in H. discriminate H. Qed.

Lemma refa316_not1887 : ~ @Equation1887 Fin4 refa316_inst.
Proof. unfold Equation1887. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa316_inst, refa316_op in H. discriminate H. Qed.

Lemma refa316_not1894 : ~ @Equation1894 Fin4 refa316_inst.
Proof. unfold Equation1894. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa316_inst, refa316_op in H. discriminate H. Qed.

Lemma refa316_not1921 : ~ @Equation1921 Fin4 refa316_inst.
Proof. unfold Equation1921. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa316_inst, refa316_op in H. discriminate H. Qed.

Lemma refa316_not2038 : ~ @Equation2038 Fin4 refa316_inst.
Proof. unfold Equation2038. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa316_inst, refa316_op in H. discriminate H. Qed.

Lemma refa316_not2041 : ~ @Equation2041 Fin4 refa316_inst.
Proof. unfold Equation2041. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa316_inst, refa316_op in H. discriminate H. Qed.

Lemma refa316_not2043 : ~ @Equation2043 Fin4 refa316_inst.
Proof. unfold Equation2043. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa316_inst, refa316_op in H. discriminate H. Qed.

Lemma refa316_not2060 : ~ @Equation2060 Fin4 refa316_inst.
Proof. unfold Equation2060. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa316_inst, refa316_op in H. discriminate H. Qed.

Lemma refa316_not2088 : ~ @Equation2088 Fin4 refa316_inst.
Proof. unfold Equation2088. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa316_inst, refa316_op in H. discriminate H. Qed.

Lemma refa316_not2244 : ~ @Equation2244 Fin4 refa316_inst.
Proof. unfold Equation2244. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa316_inst, refa316_op in H. discriminate H. Qed.

Lemma refa316_not2256 : ~ @Equation2256 Fin4 refa316_inst.
Proof. unfold Equation2256. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa316_inst, refa316_op in H. discriminate H. Qed.

Lemma refa316_not2291 : ~ @Equation2291 Fin4 refa316_inst.
Proof. unfold Equation2291. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa316_inst, refa316_op in H. discriminate H. Qed.

Lemma refa316_not2293 : ~ @Equation2293 Fin4 refa316_inst.
Proof. unfold Equation2293. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa316_inst, refa316_op in H. discriminate H. Qed.

Lemma refa316_not2300 : ~ @Equation2300 Fin4 refa316_inst.
Proof. unfold Equation2300. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa316_inst, refa316_op in H. discriminate H. Qed.

Lemma refa316_not2444 : ~ @Equation2444 Fin4 refa316_inst.
Proof. unfold Equation2444. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa316_inst, refa316_op in H. discriminate H. Qed.

Lemma refa316_not2447 : ~ @Equation2447 Fin4 refa316_inst.
Proof. unfold Equation2447. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa316_inst, refa316_op in H. discriminate H. Qed.

Lemma refa316_not2449 : ~ @Equation2449 Fin4 refa316_inst.
Proof. unfold Equation2449. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa316_inst, refa316_op in H. discriminate H. Qed.

Lemma refa316_not2457 : ~ @Equation2457 Fin4 refa316_inst.
Proof. unfold Equation2457. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa316_inst, refa316_op in H. discriminate H. Qed.

Lemma refa316_not2459 : ~ @Equation2459 Fin4 refa316_inst.
Proof. unfold Equation2459. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa316_inst, refa316_op in H. discriminate H. Qed.

Lemma refa316_not2466 : ~ @Equation2466 Fin4 refa316_inst.
Proof. unfold Equation2466. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa316_inst, refa316_op in H. discriminate H. Qed.

Lemma refa316_not2496 : ~ @Equation2496 Fin4 refa316_inst.
Proof. unfold Equation2496. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa316_inst, refa316_op in H. discriminate H. Qed.

Lemma refa316_not2503 : ~ @Equation2503 Fin4 refa316_inst.
Proof. unfold Equation2503. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa316_inst, refa316_op in H. discriminate H. Qed.

Lemma refa316_not2530 : ~ @Equation2530 Fin4 refa316_inst.
Proof. unfold Equation2530. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa316_inst, refa316_op in H. discriminate H. Qed.

Lemma refa316_not2647 : ~ @Equation2647 Fin4 refa316_inst.
Proof. unfold Equation2647. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa316_inst, refa316_op in H. discriminate H. Qed.

Lemma refa316_not2650 : ~ @Equation2650 Fin4 refa316_inst.
Proof. unfold Equation2650. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa316_inst, refa316_op in H. discriminate H. Qed.

Lemma refa316_not2652 : ~ @Equation2652 Fin4 refa316_inst.
Proof. unfold Equation2652. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa316_inst, refa316_op in H. discriminate H. Qed.

Lemma refa316_not2660 : ~ @Equation2660 Fin4 refa316_inst.
Proof. unfold Equation2660. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa316_inst, refa316_op in H. discriminate H. Qed.

Lemma refa316_not2662 : ~ @Equation2662 Fin4 refa316_inst.
Proof. unfold Equation2662. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa316_inst, refa316_op in H. discriminate H. Qed.

Lemma refa316_not2669 : ~ @Equation2669 Fin4 refa316_inst.
Proof. unfold Equation2669. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa316_inst, refa316_op in H. discriminate H. Qed.

Lemma refa316_not2697 : ~ @Equation2697 Fin4 refa316_inst.
Proof. unfold Equation2697. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa316_inst, refa316_op in H. discriminate H. Qed.

Lemma refa316_not2699 : ~ @Equation2699 Fin4 refa316_inst.
Proof. unfold Equation2699. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa316_inst, refa316_op in H. discriminate H. Qed.

Lemma refa316_not2853 : ~ @Equation2853 Fin4 refa316_inst.
Proof. unfold Equation2853. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa316_inst, refa316_op in H. discriminate H. Qed.

Lemma refa316_not2855 : ~ @Equation2855 Fin4 refa316_inst.
Proof. unfold Equation2855. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa316_inst, refa316_op in H. discriminate H. Qed.

Lemma refa316_not2863 : ~ @Equation2863 Fin4 refa316_inst.
Proof. unfold Equation2863. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa316_inst, refa316_op in H. discriminate H. Qed.

Lemma refa316_not2865 : ~ @Equation2865 Fin4 refa316_inst.
Proof. unfold Equation2865. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa316_inst, refa316_op in H. discriminate H. Qed.

Lemma refa316_not2872 : ~ @Equation2872 Fin4 refa316_inst.
Proof. unfold Equation2872. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa316_inst, refa316_op in H. discriminate H. Qed.

Lemma refa316_not2900 : ~ @Equation2900 Fin4 refa316_inst.
Proof. unfold Equation2900. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa316_inst, refa316_op in H. discriminate H. Qed.

Lemma refa316_not2902 : ~ @Equation2902 Fin4 refa316_inst.
Proof. unfold Equation2902. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa316_inst, refa316_op in H. discriminate H. Qed.

Lemma refa316_not2909 : ~ @Equation2909 Fin4 refa316_inst.
Proof. unfold Equation2909. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa316_inst, refa316_op in H. discriminate H. Qed.

Lemma refa316_not3056 : ~ @Equation3056 Fin4 refa316_inst.
Proof. unfold Equation3056. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa316_inst, refa316_op in H. discriminate H. Qed.

Lemma refa316_not3058 : ~ @Equation3058 Fin4 refa316_inst.
Proof. unfold Equation3058. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa316_inst, refa316_op in H. discriminate H. Qed.

Lemma refa316_not3066 : ~ @Equation3066 Fin4 refa316_inst.
Proof. unfold Equation3066. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa316_inst, refa316_op in H. discriminate H. Qed.

Lemma refa316_not3068 : ~ @Equation3068 Fin4 refa316_inst.
Proof. unfold Equation3068. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa316_inst, refa316_op in H. discriminate H. Qed.

Lemma refa316_not3075 : ~ @Equation3075 Fin4 refa316_inst.
Proof. unfold Equation3075. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa316_inst, refa316_op in H. discriminate H. Qed.

Lemma refa316_not3105 : ~ @Equation3105 Fin4 refa316_inst.
Proof. unfold Equation3105. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa316_inst, refa316_op in H. discriminate H. Qed.

Lemma refa316_not3112 : ~ @Equation3112 Fin4 refa316_inst.
Proof. unfold Equation3112. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa316_inst, refa316_op in H. discriminate H. Qed.

Lemma refa316_not3253 : ~ @Equation3253 Fin4 refa316_inst.
Proof. unfold Equation3253. intro H. specialize (H F4_1). unfold magma_op, refa316_inst, refa316_op in H. discriminate H. Qed.

Lemma refa316_not3456 : ~ @Equation3456 Fin4 refa316_inst.
Proof. unfold Equation3456. intro H. specialize (H F4_1). unfold magma_op, refa316_inst, refa316_op in H. discriminate H. Qed.

Lemma refa316_not3659 : ~ @Equation3659 Fin4 refa316_inst.
Proof. unfold Equation3659. intro H. specialize (H F4_1). unfold magma_op, refa316_inst, refa316_op in H. discriminate H. Qed.

Lemma refa316_not3862 : ~ @Equation3862 Fin4 refa316_inst.
Proof. unfold Equation3862. intro H. specialize (H F4_1). unfold magma_op, refa316_inst, refa316_op in H. discriminate H. Qed.

Lemma refa316_not4065 : ~ @Equation4065 Fin4 refa316_inst.
Proof. unfold Equation4065. intro H. specialize (H F4_1). unfold magma_op, refa316_inst, refa316_op in H. discriminate H. Qed.

Lemma refa316_not4270 : ~ @Equation4270 Fin4 refa316_inst.
Proof. unfold Equation4270. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa316_inst, refa316_op in H. discriminate H. Qed.

Lemma refa316_not4273 : ~ @Equation4273 Fin4 refa316_inst.
Proof. unfold Equation4273. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa316_inst, refa316_op in H. discriminate H. Qed.

Lemma refa316_not4275 : ~ @Equation4275 Fin4 refa316_inst.
Proof. unfold Equation4275. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa316_inst, refa316_op in H. discriminate H. Qed.

Lemma refa316_not4585 : ~ @Equation4585 Fin4 refa316_inst.
Proof. unfold Equation4585. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa316_inst, refa316_op in H. discriminate H. Qed.

Lemma refa316_not4588 : ~ @Equation4588 Fin4 refa316_inst.
Proof. unfold Equation4588. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa316_inst, refa316_op in H. discriminate H. Qed.

Lemma refa316_not4590 : ~ @Equation4590 Fin4 refa316_inst.
Proof. unfold Equation4590. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa316_inst, refa316_op in H. discriminate H. Qed.

(** ---- refa317 (Fin4) ---- *)

Definition refa317_op (x y : Fin4) : Fin4 :=
  match x, y with
  | F4_0, F4_0 => F4_0 | F4_0, F4_1 => F4_2 | F4_0, F4_2 => F4_3 | F4_0, F4_3 => F4_1
  | F4_1, F4_0 => F4_3 | F4_1, F4_1 => F4_1 | F4_1, F4_2 => F4_0 | F4_1, F4_3 => F4_2
  | F4_2, F4_0 => F4_1 | F4_2, F4_1 => F4_3 | F4_2, F4_2 => F4_2 | F4_2, F4_3 => F4_0
  | F4_3, F4_0 => F4_2 | F4_3, F4_1 => F4_0 | F4_3, F4_2 => F4_1 | F4_3, F4_3 => F4_3
  end.

#[local] Instance refa317_inst : Magma Fin4 := {| magma_op := refa317_op |}.

Lemma refa317_sat14 : @Equation14 Fin4 refa317_inst.
Proof. unfold Equation14, magma_op, refa317_inst, refa317_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa317_sat66 : @Equation66 Fin4 refa317_inst.
Proof. unfold Equation66, magma_op, refa317_inst, refa317_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa317_sat75 : @Equation75 Fin4 refa317_inst.
Proof. unfold Equation75, magma_op, refa317_inst, refa317_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa317_sat124 : @Equation124 Fin4 refa317_inst.
Proof. unfold Equation124, magma_op, refa317_inst, refa317_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa317_sat206 : @Equation206 Fin4 refa317_inst.
Proof. unfold Equation206, magma_op, refa317_inst, refa317_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa317_sat264 : @Equation264 Fin4 refa317_inst.
Proof. unfold Equation264, magma_op, refa317_inst, refa317_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa317_sat313 : @Equation313 Fin4 refa317_inst.
Proof. unfold Equation313, magma_op, refa317_inst, refa317_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa317_sat335 : @Equation335 Fin4 refa317_inst.
Proof. unfold Equation335, magma_op, refa317_inst, refa317_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa317_sat365 : @Equation365 Fin4 refa317_inst.
Proof. unfold Equation365, magma_op, refa317_inst, refa317_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa317_sat384 : @Equation384 Fin4 refa317_inst.
Proof. unfold Equation384, magma_op, refa317_inst, refa317_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa317_sat430 : @Equation430 Fin4 refa317_inst.
Proof. unfold Equation430, magma_op, refa317_inst, refa317_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa317_sat501 : @Equation501 Fin4 refa317_inst.
Proof. unfold Equation501, magma_op, refa317_inst, refa317_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa317_sat510 : @Equation510 Fin4 refa317_inst.
Proof. unfold Equation510, magma_op, refa317_inst, refa317_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa317_sat1117 : @Equation1117 Fin4 refa317_inst.
Proof. unfold Equation1117, magma_op, refa317_inst, refa317_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa317_sat1232 : @Equation1232 Fin4 refa317_inst.
Proof. unfold Equation1232, magma_op, refa317_inst, refa317_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa317_sat1322 : @Equation1322 Fin4 refa317_inst.
Proof. unfold Equation1322, magma_op, refa317_inst, refa317_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa317_sat1590 : @Equation1590 Fin4 refa317_inst.
Proof. unfold Equation1590, magma_op, refa317_inst, refa317_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa317_sat1648 : @Equation1648 Fin4 refa317_inst.
Proof. unfold Equation1648, magma_op, refa317_inst, refa317_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa317_sat1728 : @Equation1728 Fin4 refa317_inst.
Proof. unfold Equation1728, magma_op, refa317_inst, refa317_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa317_sat1841 : @Equation1841 Fin4 refa317_inst.
Proof. unfold Equation1841, magma_op, refa317_inst, refa317_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa317_sat1924 : @Equation1924 Fin4 refa317_inst.
Proof. unfold Equation1924, magma_op, refa317_inst, refa317_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa317_sat2079 : @Equation2079 Fin4 refa317_inst.
Proof. unfold Equation2079, magma_op, refa317_inst, refa317_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa317_sat2247 : @Equation2247 Fin4 refa317_inst.
Proof. unfold Equation2247, magma_op, refa317_inst, refa317_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa317_sat2337 : @Equation2337 Fin4 refa317_inst.
Proof. unfold Equation2337, magma_op, refa317_inst, refa317_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa317_sat2538 : @Equation2538 Fin4 refa317_inst.
Proof. unfold Equation2538, magma_op, refa317_inst, refa317_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa317_sat3059 : @Equation3059 Fin4 refa317_inst.
Proof. unfold Equation3059, magma_op, refa317_inst, refa317_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa317_sat3106 : @Equation3106 Fin4 refa317_inst.
Proof. unfold Equation3106, magma_op, refa317_inst, refa317_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa317_sat3142 : @Equation3142 Fin4 refa317_inst.
Proof. unfold Equation3142, magma_op, refa317_inst, refa317_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa317_sat3272 : @Equation3272 Fin4 refa317_inst.
Proof. unfold Equation3272, magma_op, refa317_inst, refa317_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa317_sat3281 : @Equation3281 Fin4 refa317_inst.
Proof. unfold Equation3281, magma_op, refa317_inst, refa317_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa317_sat3352 : @Equation3352 Fin4 refa317_inst.
Proof. unfold Equation3352, magma_op, refa317_inst, refa317_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa317_sat3620 : @Equation3620 Fin4 refa317_inst.
Proof. unfold Equation3620, magma_op, refa317_inst, refa317_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa317_sat4074 : @Equation4074 Fin4 refa317_inst.
Proof. unfold Equation4074, magma_op, refa317_inst, refa317_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa317_sat4091 : @Equation4091 Fin4 refa317_inst.
Proof. unfold Equation4091, magma_op, refa317_inst, refa317_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa317_sat4164 : @Equation4164 Fin4 refa317_inst.
Proof. unfold Equation4164, magma_op, refa317_inst, refa317_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa317_not50 : ~ @Equation50 Fin4 refa317_inst.
Proof. unfold Equation50. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa317_inst, refa317_op in H. discriminate H. Qed.

Lemma refa317_not55 : ~ @Equation55 Fin4 refa317_inst.
Proof. unfold Equation55. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa317_inst, refa317_op in H. discriminate H. Qed.

Lemma refa317_not56 : ~ @Equation56 Fin4 refa317_inst.
Proof. unfold Equation56. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa317_inst, refa317_op in H. discriminate H. Qed.

Lemma refa317_not65 : ~ @Equation65 Fin4 refa317_inst.
Proof. unfold Equation65. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa317_inst, refa317_op in H. discriminate H. Qed.

Lemma refa317_not73 : ~ @Equation73 Fin4 refa317_inst.
Proof. unfold Equation73. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa317_inst, refa317_op in H. discriminate H. Qed.

Lemma refa317_not107 : ~ @Equation107 Fin4 refa317_inst.
Proof. unfold Equation107. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa317_inst, refa317_op in H. discriminate H. Qed.

Lemma refa317_not108 : ~ @Equation108 Fin4 refa317_inst.
Proof. unfold Equation108. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa317_inst, refa317_op in H. discriminate H. Qed.

Lemma refa317_not117 : ~ @Equation117 Fin4 refa317_inst.
Proof. unfold Equation117. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa317_inst, refa317_op in H. discriminate H. Qed.

Lemma refa317_not118 : ~ @Equation118 Fin4 refa317_inst.
Proof. unfold Equation118. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa317_inst, refa317_op in H. discriminate H. Qed.

Lemma refa317_not127 : ~ @Equation127 Fin4 refa317_inst.
Proof. unfold Equation127. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa317_inst, refa317_op in H. discriminate H. Qed.

Lemma refa317_not160 : ~ @Equation160 Fin4 refa317_inst.
Proof. unfold Equation160. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa317_inst, refa317_op in H. discriminate H. Qed.

Lemma refa317_not167 : ~ @Equation167 Fin4 refa317_inst.
Proof. unfold Equation167. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa317_inst, refa317_op in H. discriminate H. Qed.

Lemma refa317_not209 : ~ @Equation209 Fin4 refa317_inst.
Proof. unfold Equation209. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa317_inst, refa317_op in H. discriminate H. Qed.

Lemma refa317_not211 : ~ @Equation211 Fin4 refa317_inst.
Proof. unfold Equation211. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa317_inst, refa317_op in H. discriminate H. Qed.

Lemma refa317_not229 : ~ @Equation229 Fin4 refa317_inst.
Proof. unfold Equation229. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa317_inst, refa317_op in H. discriminate H. Qed.

Lemma refa317_not231 : ~ @Equation231 Fin4 refa317_inst.
Proof. unfold Equation231. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa317_inst, refa317_op in H. discriminate H. Qed.

Lemma refa317_not261 : ~ @Equation261 Fin4 refa317_inst.
Proof. unfold Equation261. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa317_inst, refa317_op in H. discriminate H. Qed.

Lemma refa317_not263 : ~ @Equation263 Fin4 refa317_inst.
Proof. unfold Equation263. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa317_inst, refa317_op in H. discriminate H. Qed.

Lemma refa317_not274 : ~ @Equation274 Fin4 refa317_inst.
Proof. unfold Equation274. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa317_inst, refa317_op in H. discriminate H. Qed.

Lemma refa317_not280 : ~ @Equation280 Fin4 refa317_inst.
Proof. unfold Equation280. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa317_inst, refa317_op in H. discriminate H. Qed.

Lemma refa317_not283 : ~ @Equation283 Fin4 refa317_inst.
Proof. unfold Equation283. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa317_inst, refa317_op in H. discriminate H. Qed.

Lemma refa317_not412 : ~ @Equation412 Fin4 refa317_inst.
Proof. unfold Equation412. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa317_inst, refa317_op in H. discriminate H. Qed.

Lemma refa317_not413 : ~ @Equation413 Fin4 refa317_inst.
Proof. unfold Equation413. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa317_inst, refa317_op in H. discriminate H. Qed.

Lemma refa317_not414 : ~ @Equation414 Fin4 refa317_inst.
Proof. unfold Equation414. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa317_inst, refa317_op in H. discriminate H. Qed.

Lemma refa317_not416 : ~ @Equation416 Fin4 refa317_inst.
Proof. unfold Equation416. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa317_inst, refa317_op in H. discriminate H. Qed.

Lemma refa317_not419 : ~ @Equation419 Fin4 refa317_inst.
Proof. unfold Equation419. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa317_inst, refa317_op in H. discriminate H. Qed.

Lemma refa317_not420 : ~ @Equation420 Fin4 refa317_inst.
Proof. unfold Equation420. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa317_inst, refa317_op in H. discriminate H. Qed.

Lemma refa317_not426 : ~ @Equation426 Fin4 refa317_inst.
Proof. unfold Equation426. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa317_inst, refa317_op in H. discriminate H. Qed.

Lemma refa317_not427 : ~ @Equation427 Fin4 refa317_inst.
Proof. unfold Equation427. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa317_inst, refa317_op in H. discriminate H. Qed.

Lemma refa317_not429 : ~ @Equation429 Fin4 refa317_inst.
Proof. unfold Equation429. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa317_inst, refa317_op in H. discriminate H. Qed.

Lemma refa317_not436 : ~ @Equation436 Fin4 refa317_inst.
Proof. unfold Equation436. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa317_inst, refa317_op in H. discriminate H. Qed.

Lemma refa317_not437 : ~ @Equation437 Fin4 refa317_inst.
Proof. unfold Equation437. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa317_inst, refa317_op in H. discriminate H. Qed.

Lemma refa317_not440 : ~ @Equation440 Fin4 refa317_inst.
Proof. unfold Equation440. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa317_inst, refa317_op in H. discriminate H. Qed.

Lemma refa317_not464 : ~ @Equation464 Fin4 refa317_inst.
Proof. unfold Equation464. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa317_inst, refa317_op in H. discriminate H. Qed.

Lemma refa317_not467 : ~ @Equation467 Fin4 refa317_inst.
Proof. unfold Equation467. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa317_inst, refa317_op in H. discriminate H. Qed.

Lemma refa317_not473 : ~ @Equation473 Fin4 refa317_inst.
Proof. unfold Equation473. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa317_inst, refa317_op in H. discriminate H. Qed.

Lemma refa317_not474 : ~ @Equation474 Fin4 refa317_inst.
Proof. unfold Equation474. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa317_inst, refa317_op in H. discriminate H. Qed.

Lemma refa317_not476 : ~ @Equation476 Fin4 refa317_inst.
Proof. unfold Equation476. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa317_inst, refa317_op in H. discriminate H. Qed.

Lemma refa317_not503 : ~ @Equation503 Fin4 refa317_inst.
Proof. unfold Equation503. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa317_inst, refa317_op in H. discriminate H. Qed.

Lemma refa317_not504 : ~ @Equation504 Fin4 refa317_inst.
Proof. unfold Equation504. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa317_inst, refa317_op in H. discriminate H. Qed.

Lemma refa317_not511 : ~ @Equation511 Fin4 refa317_inst.
Proof. unfold Equation511. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa317_inst, refa317_op in H. discriminate H. Qed.

Lemma refa317_not513 : ~ @Equation513 Fin4 refa317_inst.
Proof. unfold Equation513. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa317_inst, refa317_op in H. discriminate H. Qed.

Lemma refa317_not615 : ~ @Equation615 Fin4 refa317_inst.
Proof. unfold Equation615. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa317_inst, refa317_op in H. discriminate H. Qed.

Lemma refa317_not616 : ~ @Equation616 Fin4 refa317_inst.
Proof. unfold Equation616. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa317_inst, refa317_op in H. discriminate H. Qed.

Lemma refa317_not617 : ~ @Equation617 Fin4 refa317_inst.
Proof. unfold Equation617. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa317_inst, refa317_op in H. discriminate H. Qed.

Lemma refa317_not619 : ~ @Equation619 Fin4 refa317_inst.
Proof. unfold Equation619. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa317_inst, refa317_op in H. discriminate H. Qed.

Lemma refa317_not622 : ~ @Equation622 Fin4 refa317_inst.
Proof. unfold Equation622. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa317_inst, refa317_op in H. discriminate H. Qed.

Lemma refa317_not623 : ~ @Equation623 Fin4 refa317_inst.
Proof. unfold Equation623. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa317_inst, refa317_op in H. discriminate H. Qed.

Lemma refa317_not629 : ~ @Equation629 Fin4 refa317_inst.
Proof. unfold Equation629. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa317_inst, refa317_op in H. discriminate H. Qed.

Lemma refa317_not632 : ~ @Equation632 Fin4 refa317_inst.
Proof. unfold Equation632. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa317_inst, refa317_op in H. discriminate H. Qed.

Lemma refa317_not633 : ~ @Equation633 Fin4 refa317_inst.
Proof. unfold Equation633. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa317_inst, refa317_op in H. discriminate H. Qed.

Lemma refa317_not640 : ~ @Equation640 Fin4 refa317_inst.
Proof. unfold Equation640. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa317_inst, refa317_op in H. discriminate H. Qed.

Lemma refa317_not642 : ~ @Equation642 Fin4 refa317_inst.
Proof. unfold Equation642. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa317_inst, refa317_op in H. discriminate H. Qed.

Lemma refa317_not643 : ~ @Equation643 Fin4 refa317_inst.
Proof. unfold Equation643. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa317_inst, refa317_op in H. discriminate H. Qed.

Lemma refa317_not667 : ~ @Equation667 Fin4 refa317_inst.
Proof. unfold Equation667. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa317_inst, refa317_op in H. discriminate H. Qed.

Lemma refa317_not670 : ~ @Equation670 Fin4 refa317_inst.
Proof. unfold Equation670. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa317_inst, refa317_op in H. discriminate H. Qed.

Lemma refa317_not676 : ~ @Equation676 Fin4 refa317_inst.
Proof. unfold Equation676. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa317_inst, refa317_op in H. discriminate H. Qed.

Lemma refa317_not677 : ~ @Equation677 Fin4 refa317_inst.
Proof. unfold Equation677. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa317_inst, refa317_op in H. discriminate H. Qed.

Lemma refa317_not679 : ~ @Equation679 Fin4 refa317_inst.
Proof. unfold Equation679. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa317_inst, refa317_op in H. discriminate H. Qed.

Lemma refa317_not704 : ~ @Equation704 Fin4 refa317_inst.
Proof. unfold Equation704. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa317_inst, refa317_op in H. discriminate H. Qed.

Lemma refa317_not706 : ~ @Equation706 Fin4 refa317_inst.
Proof. unfold Equation706. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa317_inst, refa317_op in H. discriminate H. Qed.

Lemma refa317_not713 : ~ @Equation713 Fin4 refa317_inst.
Proof. unfold Equation713. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa317_inst, refa317_op in H. discriminate H. Qed.

Lemma refa317_not818 : ~ @Equation818 Fin4 refa317_inst.
Proof. unfold Equation818. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa317_inst, refa317_op in H. discriminate H. Qed.

Lemma refa317_not819 : ~ @Equation819 Fin4 refa317_inst.
Proof. unfold Equation819. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa317_inst, refa317_op in H. discriminate H. Qed.

Lemma refa317_not820 : ~ @Equation820 Fin4 refa317_inst.
Proof. unfold Equation820. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa317_inst, refa317_op in H. discriminate H. Qed.

Lemma refa317_not822 : ~ @Equation822 Fin4 refa317_inst.
Proof. unfold Equation822. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa317_inst, refa317_op in H. discriminate H. Qed.

Lemma refa317_not823 : ~ @Equation823 Fin4 refa317_inst.
Proof. unfold Equation823. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa317_inst, refa317_op in H. discriminate H. Qed.

Lemma refa317_not826 : ~ @Equation826 Fin4 refa317_inst.
Proof. unfold Equation826. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa317_inst, refa317_op in H. discriminate H. Qed.

Lemma refa317_not832 : ~ @Equation832 Fin4 refa317_inst.
Proof. unfold Equation832. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa317_inst, refa317_op in H. discriminate H. Qed.

Lemma refa317_not833 : ~ @Equation833 Fin4 refa317_inst.
Proof. unfold Equation833. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa317_inst, refa317_op in H. discriminate H. Qed.

Lemma refa317_not835 : ~ @Equation835 Fin4 refa317_inst.
Proof. unfold Equation835. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa317_inst, refa317_op in H. discriminate H. Qed.

Lemma refa317_not842 : ~ @Equation842 Fin4 refa317_inst.
Proof. unfold Equation842. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa317_inst, refa317_op in H. discriminate H. Qed.

Lemma refa317_not845 : ~ @Equation845 Fin4 refa317_inst.
Proof. unfold Equation845. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa317_inst, refa317_op in H. discriminate H. Qed.

Lemma refa317_not846 : ~ @Equation846 Fin4 refa317_inst.
Proof. unfold Equation846. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa317_inst, refa317_op in H. discriminate H. Qed.

Lemma refa317_not870 : ~ @Equation870 Fin4 refa317_inst.
Proof. unfold Equation870. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa317_inst, refa317_op in H. discriminate H. Qed.

Lemma refa317_not872 : ~ @Equation872 Fin4 refa317_inst.
Proof. unfold Equation872. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa317_inst, refa317_op in H. discriminate H. Qed.

Lemma refa317_not879 : ~ @Equation879 Fin4 refa317_inst.
Proof. unfold Equation879. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa317_inst, refa317_op in H. discriminate H. Qed.

Lemma refa317_not882 : ~ @Equation882 Fin4 refa317_inst.
Proof. unfold Equation882. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa317_inst, refa317_op in H. discriminate H. Qed.

Lemma refa317_not883 : ~ @Equation883 Fin4 refa317_inst.
Proof. unfold Equation883. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa317_inst, refa317_op in H. discriminate H. Qed.

Lemma refa317_not907 : ~ @Equation907 Fin4 refa317_inst.
Proof. unfold Equation907. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa317_inst, refa317_op in H. discriminate H. Qed.

Lemma refa317_not917 : ~ @Equation917 Fin4 refa317_inst.
Proof. unfold Equation917. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa317_inst, refa317_op in H. discriminate H. Qed.

Lemma refa317_not1021 : ~ @Equation1021 Fin4 refa317_inst.
Proof. unfold Equation1021. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa317_inst, refa317_op in H. discriminate H. Qed.

Lemma refa317_not1022 : ~ @Equation1022 Fin4 refa317_inst.
Proof. unfold Equation1022. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa317_inst, refa317_op in H. discriminate H. Qed.

Lemma refa317_not1025 : ~ @Equation1025 Fin4 refa317_inst.
Proof. unfold Equation1025. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa317_inst, refa317_op in H. discriminate H. Qed.

Lemma refa317_not1026 : ~ @Equation1026 Fin4 refa317_inst.
Proof. unfold Equation1026. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa317_inst, refa317_op in H. discriminate H. Qed.

Lemma refa317_not1028 : ~ @Equation1028 Fin4 refa317_inst.
Proof. unfold Equation1028. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa317_inst, refa317_op in H. discriminate H. Qed.

Lemma refa317_not1029 : ~ @Equation1029 Fin4 refa317_inst.
Proof. unfold Equation1029. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa317_inst, refa317_op in H. discriminate H. Qed.

Lemma refa317_not1035 : ~ @Equation1035 Fin4 refa317_inst.
Proof. unfold Equation1035. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa317_inst, refa317_op in H. discriminate H. Qed.

Lemma refa317_not1039 : ~ @Equation1039 Fin4 refa317_inst.
Proof. unfold Equation1039. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa317_inst, refa317_op in H. discriminate H. Qed.

Lemma refa317_not1045 : ~ @Equation1045 Fin4 refa317_inst.
Proof. unfold Equation1045. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa317_inst, refa317_op in H. discriminate H. Qed.

Lemma refa317_not1046 : ~ @Equation1046 Fin4 refa317_inst.
Proof. unfold Equation1046. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa317_inst, refa317_op in H. discriminate H. Qed.

Lemma refa317_not1048 : ~ @Equation1048 Fin4 refa317_inst.
Proof. unfold Equation1048. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa317_inst, refa317_op in H. discriminate H. Qed.

Lemma refa317_not1049 : ~ @Equation1049 Fin4 refa317_inst.
Proof. unfold Equation1049. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa317_inst, refa317_op in H. discriminate H. Qed.

Lemma refa317_not1076 : ~ @Equation1076 Fin4 refa317_inst.
Proof. unfold Equation1076. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa317_inst, refa317_op in H. discriminate H. Qed.

Lemma refa317_not1082 : ~ @Equation1082 Fin4 refa317_inst.
Proof. unfold Equation1082. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa317_inst, refa317_op in H. discriminate H. Qed.

Lemma refa317_not1083 : ~ @Equation1083 Fin4 refa317_inst.
Proof. unfold Equation1083. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa317_inst, refa317_op in H. discriminate H. Qed.

Lemma refa317_not1085 : ~ @Equation1085 Fin4 refa317_inst.
Proof. unfold Equation1085. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa317_inst, refa317_op in H. discriminate H. Qed.

Lemma refa317_not1086 : ~ @Equation1086 Fin4 refa317_inst.
Proof. unfold Equation1086. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa317_inst, refa317_op in H. discriminate H. Qed.

Lemma refa317_not1110 : ~ @Equation1110 Fin4 refa317_inst.
Proof. unfold Equation1110. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa317_inst, refa317_op in H. discriminate H. Qed.

Lemma refa317_not1112 : ~ @Equation1112 Fin4 refa317_inst.
Proof. unfold Equation1112. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa317_inst, refa317_op in H. discriminate H. Qed.

Lemma refa317_not1119 : ~ @Equation1119 Fin4 refa317_inst.
Proof. unfold Equation1119. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa317_inst, refa317_op in H. discriminate H. Qed.

Lemma refa317_not1122 : ~ @Equation1122 Fin4 refa317_inst.
Proof. unfold Equation1122. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa317_inst, refa317_op in H. discriminate H. Qed.

Lemma refa317_not1224 : ~ @Equation1224 Fin4 refa317_inst.
Proof. unfold Equation1224. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa317_inst, refa317_op in H. discriminate H. Qed.

Lemma refa317_not1225 : ~ @Equation1225 Fin4 refa317_inst.
Proof. unfold Equation1225. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa317_inst, refa317_op in H. discriminate H. Qed.

Lemma refa317_not1226 : ~ @Equation1226 Fin4 refa317_inst.
Proof. unfold Equation1226. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa317_inst, refa317_op in H. discriminate H. Qed.

Lemma refa317_not1228 : ~ @Equation1228 Fin4 refa317_inst.
Proof. unfold Equation1228. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa317_inst, refa317_op in H. discriminate H. Qed.

Lemma refa317_not1229 : ~ @Equation1229 Fin4 refa317_inst.
Proof. unfold Equation1229. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa317_inst, refa317_op in H. discriminate H. Qed.

Lemma refa317_not1231 : ~ @Equation1231 Fin4 refa317_inst.
Proof. unfold Equation1231. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa317_inst, refa317_op in H. discriminate H. Qed.

Lemma refa317_not1238 : ~ @Equation1238 Fin4 refa317_inst.
Proof. unfold Equation1238. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa317_inst, refa317_op in H. discriminate H. Qed.

Lemma refa317_not1239 : ~ @Equation1239 Fin4 refa317_inst.
Proof. unfold Equation1239. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa317_inst, refa317_op in H. discriminate H. Qed.

Lemma refa317_not1242 : ~ @Equation1242 Fin4 refa317_inst.
Proof. unfold Equation1242. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa317_inst, refa317_op in H. discriminate H. Qed.

Lemma refa317_not1248 : ~ @Equation1248 Fin4 refa317_inst.
Proof. unfold Equation1248. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa317_inst, refa317_op in H. discriminate H. Qed.

Lemma refa317_not1251 : ~ @Equation1251 Fin4 refa317_inst.
Proof. unfold Equation1251. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa317_inst, refa317_op in H. discriminate H. Qed.

Lemma refa317_not1252 : ~ @Equation1252 Fin4 refa317_inst.
Proof. unfold Equation1252. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa317_inst, refa317_op in H. discriminate H. Qed.

Lemma refa317_not1278 : ~ @Equation1278 Fin4 refa317_inst.
Proof. unfold Equation1278. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa317_inst, refa317_op in H. discriminate H. Qed.

Lemma refa317_not1279 : ~ @Equation1279 Fin4 refa317_inst.
Proof. unfold Equation1279. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa317_inst, refa317_op in H. discriminate H. Qed.

Lemma refa317_not1285 : ~ @Equation1285 Fin4 refa317_inst.
Proof. unfold Equation1285. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa317_inst, refa317_op in H. discriminate H. Qed.

Lemma refa317_not1286 : ~ @Equation1286 Fin4 refa317_inst.
Proof. unfold Equation1286. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa317_inst, refa317_op in H. discriminate H. Qed.

Lemma refa317_not1289 : ~ @Equation1289 Fin4 refa317_inst.
Proof. unfold Equation1289. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa317_inst, refa317_op in H. discriminate H. Qed.

Lemma refa317_not1312 : ~ @Equation1312 Fin4 refa317_inst.
Proof. unfold Equation1312. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa317_inst, refa317_op in H. discriminate H. Qed.

Lemma refa317_not1313 : ~ @Equation1313 Fin4 refa317_inst.
Proof. unfold Equation1313. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa317_inst, refa317_op in H. discriminate H. Qed.

Lemma refa317_not1315 : ~ @Equation1315 Fin4 refa317_inst.
Proof. unfold Equation1315. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa317_inst, refa317_op in H. discriminate H. Qed.

Lemma refa317_not1325 : ~ @Equation1325 Fin4 refa317_inst.
Proof. unfold Equation1325. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa317_inst, refa317_op in H. discriminate H. Qed.

Lemma refa317_not1427 : ~ @Equation1427 Fin4 refa317_inst.
Proof. unfold Equation1427. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa317_inst, refa317_op in H. discriminate H. Qed.

Lemma refa317_not1428 : ~ @Equation1428 Fin4 refa317_inst.
Proof. unfold Equation1428. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa317_inst, refa317_op in H. discriminate H. Qed.

Lemma refa317_not1429 : ~ @Equation1429 Fin4 refa317_inst.
Proof. unfold Equation1429. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa317_inst, refa317_op in H. discriminate H. Qed.

Lemma refa317_not1431 : ~ @Equation1431 Fin4 refa317_inst.
Proof. unfold Equation1431. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa317_inst, refa317_op in H. discriminate H. Qed.

Lemma refa317_not1434 : ~ @Equation1434 Fin4 refa317_inst.
Proof. unfold Equation1434. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa317_inst, refa317_op in H. discriminate H. Qed.

Lemma refa317_not1435 : ~ @Equation1435 Fin4 refa317_inst.
Proof. unfold Equation1435. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa317_inst, refa317_op in H. discriminate H. Qed.

Lemma refa317_not1441 : ~ @Equation1441 Fin4 refa317_inst.
Proof. unfold Equation1441. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa317_inst, refa317_op in H. discriminate H. Qed.

Lemma refa317_not1444 : ~ @Equation1444 Fin4 refa317_inst.
Proof. unfold Equation1444. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa317_inst, refa317_op in H. discriminate H. Qed.

Lemma refa317_not1445 : ~ @Equation1445 Fin4 refa317_inst.
Proof. unfold Equation1445. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa317_inst, refa317_op in H. discriminate H. Qed.

Lemma refa317_not1454 : ~ @Equation1454 Fin4 refa317_inst.
Proof. unfold Equation1454. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa317_inst, refa317_op in H. discriminate H. Qed.

Lemma refa317_not1455 : ~ @Equation1455 Fin4 refa317_inst.
Proof. unfold Equation1455. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa317_inst, refa317_op in H. discriminate H. Qed.

Lemma refa317_not1478 : ~ @Equation1478 Fin4 refa317_inst.
Proof. unfold Equation1478. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa317_inst, refa317_op in H. discriminate H. Qed.

Lemma refa317_not1479 : ~ @Equation1479 Fin4 refa317_inst.
Proof. unfold Equation1479. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa317_inst, refa317_op in H. discriminate H. Qed.

Lemma refa317_not1482 : ~ @Equation1482 Fin4 refa317_inst.
Proof. unfold Equation1482. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa317_inst, refa317_op in H. discriminate H. Qed.

Lemma refa317_not1488 : ~ @Equation1488 Fin4 refa317_inst.
Proof. unfold Equation1488. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa317_inst, refa317_op in H. discriminate H. Qed.

Lemma refa317_not1489 : ~ @Equation1489 Fin4 refa317_inst.
Proof. unfold Equation1489. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa317_inst, refa317_op in H. discriminate H. Qed.

Lemma refa317_not1491 : ~ @Equation1491 Fin4 refa317_inst.
Proof. unfold Equation1491. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa317_inst, refa317_op in H. discriminate H. Qed.

Lemma refa317_not1515 : ~ @Equation1515 Fin4 refa317_inst.
Proof. unfold Equation1515. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa317_inst, refa317_op in H. discriminate H. Qed.

Lemma refa317_not1516 : ~ @Equation1516 Fin4 refa317_inst.
Proof. unfold Equation1516. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa317_inst, refa317_op in H. discriminate H. Qed.

Lemma refa317_not1518 : ~ @Equation1518 Fin4 refa317_inst.
Proof. unfold Equation1518. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa317_inst, refa317_op in H. discriminate H. Qed.

Lemma refa317_not1525 : ~ @Equation1525 Fin4 refa317_inst.
Proof. unfold Equation1525. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa317_inst, refa317_op in H. discriminate H. Qed.

Lemma refa317_not1526 : ~ @Equation1526 Fin4 refa317_inst.
Proof. unfold Equation1526. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa317_inst, refa317_op in H. discriminate H. Qed.

Lemma refa317_not1630 : ~ @Equation1630 Fin4 refa317_inst.
Proof. unfold Equation1630. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa317_inst, refa317_op in H. discriminate H. Qed.

Lemma refa317_not1631 : ~ @Equation1631 Fin4 refa317_inst.
Proof. unfold Equation1631. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa317_inst, refa317_op in H. discriminate H. Qed.

Lemma refa317_not1632 : ~ @Equation1632 Fin4 refa317_inst.
Proof. unfold Equation1632. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa317_inst, refa317_op in H. discriminate H. Qed.

Lemma refa317_not1634 : ~ @Equation1634 Fin4 refa317_inst.
Proof. unfold Equation1634. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa317_inst, refa317_op in H. discriminate H. Qed.

Lemma refa317_not1637 : ~ @Equation1637 Fin4 refa317_inst.
Proof. unfold Equation1637. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa317_inst, refa317_op in H. discriminate H. Qed.

Lemma refa317_not1638 : ~ @Equation1638 Fin4 refa317_inst.
Proof. unfold Equation1638. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa317_inst, refa317_op in H. discriminate H. Qed.

Lemma refa317_not1644 : ~ @Equation1644 Fin4 refa317_inst.
Proof. unfold Equation1644. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa317_inst, refa317_op in H. discriminate H. Qed.

Lemma refa317_not1645 : ~ @Equation1645 Fin4 refa317_inst.
Proof. unfold Equation1645. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa317_inst, refa317_op in H. discriminate H. Qed.

Lemma refa317_not1654 : ~ @Equation1654 Fin4 refa317_inst.
Proof. unfold Equation1654. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa317_inst, refa317_op in H. discriminate H. Qed.

Lemma refa317_not1655 : ~ @Equation1655 Fin4 refa317_inst.
Proof. unfold Equation1655. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa317_inst, refa317_op in H. discriminate H. Qed.

Lemma refa317_not1658 : ~ @Equation1658 Fin4 refa317_inst.
Proof. unfold Equation1658. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa317_inst, refa317_op in H. discriminate H. Qed.

Lemma refa317_not1681 : ~ @Equation1681 Fin4 refa317_inst.
Proof. unfold Equation1681. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa317_inst, refa317_op in H. discriminate H. Qed.

Lemma refa317_not1682 : ~ @Equation1682 Fin4 refa317_inst.
Proof. unfold Equation1682. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa317_inst, refa317_op in H. discriminate H. Qed.

Lemma refa317_not1685 : ~ @Equation1685 Fin4 refa317_inst.
Proof. unfold Equation1685. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa317_inst, refa317_op in H. discriminate H. Qed.

Lemma refa317_not1691 : ~ @Equation1691 Fin4 refa317_inst.
Proof. unfold Equation1691. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa317_inst, refa317_op in H. discriminate H. Qed.

Lemma refa317_not1692 : ~ @Equation1692 Fin4 refa317_inst.
Proof. unfold Equation1692. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa317_inst, refa317_op in H. discriminate H. Qed.

Lemma refa317_not1694 : ~ @Equation1694 Fin4 refa317_inst.
Proof. unfold Equation1694. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa317_inst, refa317_op in H. discriminate H. Qed.

Lemma refa317_not1721 : ~ @Equation1721 Fin4 refa317_inst.
Proof. unfold Equation1721. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa317_inst, refa317_op in H. discriminate H. Qed.

Lemma refa317_not1722 : ~ @Equation1722 Fin4 refa317_inst.
Proof. unfold Equation1722. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa317_inst, refa317_op in H. discriminate H. Qed.

Lemma refa317_not1731 : ~ @Equation1731 Fin4 refa317_inst.
Proof. unfold Equation1731. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa317_inst, refa317_op in H. discriminate H. Qed.

Lemma refa317_not1833 : ~ @Equation1833 Fin4 refa317_inst.
Proof. unfold Equation1833. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa317_inst, refa317_op in H. discriminate H. Qed.

Lemma refa317_not1834 : ~ @Equation1834 Fin4 refa317_inst.
Proof. unfold Equation1834. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa317_inst, refa317_op in H. discriminate H. Qed.

Lemma refa317_not1837 : ~ @Equation1837 Fin4 refa317_inst.
Proof. unfold Equation1837. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa317_inst, refa317_op in H. discriminate H. Qed.

Lemma refa317_not1838 : ~ @Equation1838 Fin4 refa317_inst.
Proof. unfold Equation1838. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa317_inst, refa317_op in H. discriminate H. Qed.

Lemma refa317_not1840 : ~ @Equation1840 Fin4 refa317_inst.
Proof. unfold Equation1840. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa317_inst, refa317_op in H. discriminate H. Qed.

Lemma refa317_not1847 : ~ @Equation1847 Fin4 refa317_inst.
Proof. unfold Equation1847. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa317_inst, refa317_op in H. discriminate H. Qed.

Lemma refa317_not1851 : ~ @Equation1851 Fin4 refa317_inst.
Proof. unfold Equation1851. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa317_inst, refa317_op in H. discriminate H. Qed.

Lemma refa317_not1857 : ~ @Equation1857 Fin4 refa317_inst.
Proof. unfold Equation1857. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa317_inst, refa317_op in H. discriminate H. Qed.

Lemma refa317_not1858 : ~ @Equation1858 Fin4 refa317_inst.
Proof. unfold Equation1858. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa317_inst, refa317_op in H. discriminate H. Qed.

Lemma refa317_not1861 : ~ @Equation1861 Fin4 refa317_inst.
Proof. unfold Equation1861. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa317_inst, refa317_op in H. discriminate H. Qed.

Lemma refa317_not1884 : ~ @Equation1884 Fin4 refa317_inst.
Proof. unfold Equation1884. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa317_inst, refa317_op in H. discriminate H. Qed.

Lemma refa317_not1885 : ~ @Equation1885 Fin4 refa317_inst.
Proof. unfold Equation1885. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa317_inst, refa317_op in H. discriminate H. Qed.

Lemma refa317_not1887 : ~ @Equation1887 Fin4 refa317_inst.
Proof. unfold Equation1887. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa317_inst, refa317_op in H. discriminate H. Qed.

Lemma refa317_not1895 : ~ @Equation1895 Fin4 refa317_inst.
Proof. unfold Equation1895. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa317_inst, refa317_op in H. discriminate H. Qed.

Lemma refa317_not1897 : ~ @Equation1897 Fin4 refa317_inst.
Proof. unfold Equation1897. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa317_inst, refa317_op in H. discriminate H. Qed.

Lemma refa317_not1921 : ~ @Equation1921 Fin4 refa317_inst.
Proof. unfold Equation1921. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa317_inst, refa317_op in H. discriminate H. Qed.

Lemma refa317_not1922 : ~ @Equation1922 Fin4 refa317_inst.
Proof. unfold Equation1922. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa317_inst, refa317_op in H. discriminate H. Qed.

Lemma refa317_not1925 : ~ @Equation1925 Fin4 refa317_inst.
Proof. unfold Equation1925. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa317_inst, refa317_op in H. discriminate H. Qed.

Lemma refa317_not1931 : ~ @Equation1931 Fin4 refa317_inst.
Proof. unfold Equation1931. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa317_inst, refa317_op in H. discriminate H. Qed.

Lemma refa317_not2036 : ~ @Equation2036 Fin4 refa317_inst.
Proof. unfold Equation2036. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa317_inst, refa317_op in H. discriminate H. Qed.

Lemma refa317_not2037 : ~ @Equation2037 Fin4 refa317_inst.
Proof. unfold Equation2037. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa317_inst, refa317_op in H. discriminate H. Qed.

Lemma refa317_not2038 : ~ @Equation2038 Fin4 refa317_inst.
Proof. unfold Equation2038. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa317_inst, refa317_op in H. discriminate H. Qed.

Lemma refa317_not2040 : ~ @Equation2040 Fin4 refa317_inst.
Proof. unfold Equation2040. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa317_inst, refa317_op in H. discriminate H. Qed.

Lemma refa317_not2041 : ~ @Equation2041 Fin4 refa317_inst.
Proof. unfold Equation2041. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa317_inst, refa317_op in H. discriminate H. Qed.

Lemma refa317_not2044 : ~ @Equation2044 Fin4 refa317_inst.
Proof. unfold Equation2044. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa317_inst, refa317_op in H. discriminate H. Qed.

Lemma refa317_not2050 : ~ @Equation2050 Fin4 refa317_inst.
Proof. unfold Equation2050. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa317_inst, refa317_op in H. discriminate H. Qed.

Lemma refa317_not2053 : ~ @Equation2053 Fin4 refa317_inst.
Proof. unfold Equation2053. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa317_inst, refa317_op in H. discriminate H. Qed.

Lemma refa317_not2054 : ~ @Equation2054 Fin4 refa317_inst.
Proof. unfold Equation2054. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa317_inst, refa317_op in H. discriminate H. Qed.

Lemma refa317_not2060 : ~ @Equation2060 Fin4 refa317_inst.
Proof. unfold Equation2060. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa317_inst, refa317_op in H. discriminate H. Qed.

Lemma refa317_not2061 : ~ @Equation2061 Fin4 refa317_inst.
Proof. unfold Equation2061. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa317_inst, refa317_op in H. discriminate H. Qed.

Lemma refa317_not2063 : ~ @Equation2063 Fin4 refa317_inst.
Proof. unfold Equation2063. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa317_inst, refa317_op in H. discriminate H. Qed.

Lemma refa317_not2087 : ~ @Equation2087 Fin4 refa317_inst.
Proof. unfold Equation2087. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa317_inst, refa317_op in H. discriminate H. Qed.

Lemma refa317_not2088 : ~ @Equation2088 Fin4 refa317_inst.
Proof. unfold Equation2088. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa317_inst, refa317_op in H. discriminate H. Qed.

Lemma refa317_not2091 : ~ @Equation2091 Fin4 refa317_inst.
Proof. unfold Equation2091. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa317_inst, refa317_op in H. discriminate H. Qed.

Lemma refa317_not2098 : ~ @Equation2098 Fin4 refa317_inst.
Proof. unfold Equation2098. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa317_inst, refa317_op in H. discriminate H. Qed.

Lemma refa317_not2101 : ~ @Equation2101 Fin4 refa317_inst.
Proof. unfold Equation2101. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa317_inst, refa317_op in H. discriminate H. Qed.

Lemma refa317_not2124 : ~ @Equation2124 Fin4 refa317_inst.
Proof. unfold Equation2124. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa317_inst, refa317_op in H. discriminate H. Qed.

Lemma refa317_not2125 : ~ @Equation2125 Fin4 refa317_inst.
Proof. unfold Equation2125. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa317_inst, refa317_op in H. discriminate H. Qed.

Lemma refa317_not2127 : ~ @Equation2127 Fin4 refa317_inst.
Proof. unfold Equation2127. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa317_inst, refa317_op in H. discriminate H. Qed.

Lemma refa317_not2134 : ~ @Equation2134 Fin4 refa317_inst.
Proof. unfold Equation2134. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa317_inst, refa317_op in H. discriminate H. Qed.

Lemma refa317_not2240 : ~ @Equation2240 Fin4 refa317_inst.
Proof. unfold Equation2240. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa317_inst, refa317_op in H. discriminate H. Qed.

Lemma refa317_not2241 : ~ @Equation2241 Fin4 refa317_inst.
Proof. unfold Equation2241. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa317_inst, refa317_op in H. discriminate H. Qed.

Lemma refa317_not2243 : ~ @Equation2243 Fin4 refa317_inst.
Proof. unfold Equation2243. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa317_inst, refa317_op in H. discriminate H. Qed.

Lemma refa317_not2244 : ~ @Equation2244 Fin4 refa317_inst.
Proof. unfold Equation2244. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa317_inst, refa317_op in H. discriminate H. Qed.

Lemma refa317_not2246 : ~ @Equation2246 Fin4 refa317_inst.
Proof. unfold Equation2246. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa317_inst, refa317_op in H. discriminate H. Qed.

Lemma refa317_not2253 : ~ @Equation2253 Fin4 refa317_inst.
Proof. unfold Equation2253. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa317_inst, refa317_op in H. discriminate H. Qed.

Lemma refa317_not2254 : ~ @Equation2254 Fin4 refa317_inst.
Proof. unfold Equation2254. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa317_inst, refa317_op in H. discriminate H. Qed.

Lemma refa317_not2257 : ~ @Equation2257 Fin4 refa317_inst.
Proof. unfold Equation2257. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa317_inst, refa317_op in H. discriminate H. Qed.

Lemma refa317_not2263 : ~ @Equation2263 Fin4 refa317_inst.
Proof. unfold Equation2263. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa317_inst, refa317_op in H. discriminate H. Qed.

Lemma refa317_not2266 : ~ @Equation2266 Fin4 refa317_inst.
Proof. unfold Equation2266. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa317_inst, refa317_op in H. discriminate H. Qed.

Lemma refa317_not2290 : ~ @Equation2290 Fin4 refa317_inst.
Proof. unfold Equation2290. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa317_inst, refa317_op in H. discriminate H. Qed.

Lemma refa317_not2293 : ~ @Equation2293 Fin4 refa317_inst.
Proof. unfold Equation2293. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa317_inst, refa317_op in H. discriminate H. Qed.

Lemma refa317_not2294 : ~ @Equation2294 Fin4 refa317_inst.
Proof. unfold Equation2294. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa317_inst, refa317_op in H. discriminate H. Qed.

Lemma refa317_not2300 : ~ @Equation2300 Fin4 refa317_inst.
Proof. unfold Equation2300. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa317_inst, refa317_op in H. discriminate H. Qed.

Lemma refa317_not2301 : ~ @Equation2301 Fin4 refa317_inst.
Proof. unfold Equation2301. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa317_inst, refa317_op in H. discriminate H. Qed.

Lemma refa317_not2327 : ~ @Equation2327 Fin4 refa317_inst.
Proof. unfold Equation2327. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa317_inst, refa317_op in H. discriminate H. Qed.

Lemma refa317_not2328 : ~ @Equation2328 Fin4 refa317_inst.
Proof. unfold Equation2328. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa317_inst, refa317_op in H. discriminate H. Qed.

Lemma refa317_not2330 : ~ @Equation2330 Fin4 refa317_inst.
Proof. unfold Equation2330. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa317_inst, refa317_op in H. discriminate H. Qed.

Lemma refa317_not2338 : ~ @Equation2338 Fin4 refa317_inst.
Proof. unfold Equation2338. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa317_inst, refa317_op in H. discriminate H. Qed.

Lemma refa317_not2340 : ~ @Equation2340 Fin4 refa317_inst.
Proof. unfold Equation2340. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa317_inst, refa317_op in H. discriminate H. Qed.

Lemma refa317_not2443 : ~ @Equation2443 Fin4 refa317_inst.
Proof. unfold Equation2443. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa317_inst, refa317_op in H. discriminate H. Qed.

Lemma refa317_not2446 : ~ @Equation2446 Fin4 refa317_inst.
Proof. unfold Equation2446. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa317_inst, refa317_op in H. discriminate H. Qed.

Lemma refa317_not2447 : ~ @Equation2447 Fin4 refa317_inst.
Proof. unfold Equation2447. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa317_inst, refa317_op in H. discriminate H. Qed.

Lemma refa317_not2449 : ~ @Equation2449 Fin4 refa317_inst.
Proof. unfold Equation2449. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa317_inst, refa317_op in H. discriminate H. Qed.

Lemma refa317_not2450 : ~ @Equation2450 Fin4 refa317_inst.
Proof. unfold Equation2450. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa317_inst, refa317_op in H. discriminate H. Qed.

Lemma refa317_not2456 : ~ @Equation2456 Fin4 refa317_inst.
Proof. unfold Equation2456. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa317_inst, refa317_op in H. discriminate H. Qed.

Lemma refa317_not2460 : ~ @Equation2460 Fin4 refa317_inst.
Proof. unfold Equation2460. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa317_inst, refa317_op in H. discriminate H. Qed.

Lemma refa317_not2466 : ~ @Equation2466 Fin4 refa317_inst.
Proof. unfold Equation2466. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa317_inst, refa317_op in H. discriminate H. Qed.

Lemma refa317_not2467 : ~ @Equation2467 Fin4 refa317_inst.
Proof. unfold Equation2467. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa317_inst, refa317_op in H. discriminate H. Qed.

Lemma refa317_not2469 : ~ @Equation2469 Fin4 refa317_inst.
Proof. unfold Equation2469. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa317_inst, refa317_op in H. discriminate H. Qed.

Lemma refa317_not2493 : ~ @Equation2493 Fin4 refa317_inst.
Proof. unfold Equation2493. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa317_inst, refa317_op in H. discriminate H. Qed.

Lemma refa317_not2497 : ~ @Equation2497 Fin4 refa317_inst.
Proof. unfold Equation2497. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa317_inst, refa317_op in H. discriminate H. Qed.

Lemma refa317_not2503 : ~ @Equation2503 Fin4 refa317_inst.
Proof. unfold Equation2503. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa317_inst, refa317_op in H. discriminate H. Qed.

Lemma refa317_not2504 : ~ @Equation2504 Fin4 refa317_inst.
Proof. unfold Equation2504. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa317_inst, refa317_op in H. discriminate H. Qed.

Lemma refa317_not2506 : ~ @Equation2506 Fin4 refa317_inst.
Proof. unfold Equation2506. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa317_inst, refa317_op in H. discriminate H. Qed.

Lemma refa317_not2531 : ~ @Equation2531 Fin4 refa317_inst.
Proof. unfold Equation2531. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa317_inst, refa317_op in H. discriminate H. Qed.

Lemma refa317_not2533 : ~ @Equation2533 Fin4 refa317_inst.
Proof. unfold Equation2533. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa317_inst, refa317_op in H. discriminate H. Qed.

Lemma refa317_not2540 : ~ @Equation2540 Fin4 refa317_inst.
Proof. unfold Equation2540. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa317_inst, refa317_op in H. discriminate H. Qed.

Lemma refa317_not2541 : ~ @Equation2541 Fin4 refa317_inst.
Proof. unfold Equation2541. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa317_inst, refa317_op in H. discriminate H. Qed.

Lemma refa317_not2543 : ~ @Equation2543 Fin4 refa317_inst.
Proof. unfold Equation2543. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa317_inst, refa317_op in H. discriminate H. Qed.

Lemma refa317_not2646 : ~ @Equation2646 Fin4 refa317_inst.
Proof. unfold Equation2646. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa317_inst, refa317_op in H. discriminate H. Qed.

Lemma refa317_not2649 : ~ @Equation2649 Fin4 refa317_inst.
Proof. unfold Equation2649. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa317_inst, refa317_op in H. discriminate H. Qed.

Lemma refa317_not2650 : ~ @Equation2650 Fin4 refa317_inst.
Proof. unfold Equation2650. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa317_inst, refa317_op in H. discriminate H. Qed.

Lemma refa317_not2652 : ~ @Equation2652 Fin4 refa317_inst.
Proof. unfold Equation2652. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa317_inst, refa317_op in H. discriminate H. Qed.

Lemma refa317_not2659 : ~ @Equation2659 Fin4 refa317_inst.
Proof. unfold Equation2659. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa317_inst, refa317_op in H. discriminate H. Qed.

Lemma refa317_not2660 : ~ @Equation2660 Fin4 refa317_inst.
Proof. unfold Equation2660. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa317_inst, refa317_op in H. discriminate H. Qed.

Lemma refa317_not2662 : ~ @Equation2662 Fin4 refa317_inst.
Proof. unfold Equation2662. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa317_inst, refa317_op in H. discriminate H. Qed.

Lemma refa317_not2670 : ~ @Equation2670 Fin4 refa317_inst.
Proof. unfold Equation2670. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa317_inst, refa317_op in H. discriminate H. Qed.

Lemma refa317_not2672 : ~ @Equation2672 Fin4 refa317_inst.
Proof. unfold Equation2672. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa317_inst, refa317_op in H. discriminate H. Qed.

Lemma refa317_not2696 : ~ @Equation2696 Fin4 refa317_inst.
Proof. unfold Equation2696. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa317_inst, refa317_op in H. discriminate H. Qed.

Lemma refa317_not2697 : ~ @Equation2697 Fin4 refa317_inst.
Proof. unfold Equation2697. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa317_inst, refa317_op in H. discriminate H. Qed.

Lemma refa317_not2699 : ~ @Equation2699 Fin4 refa317_inst.
Proof. unfold Equation2699. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa317_inst, refa317_op in H. discriminate H. Qed.

Lemma refa317_not2700 : ~ @Equation2700 Fin4 refa317_inst.
Proof. unfold Equation2700. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa317_inst, refa317_op in H. discriminate H. Qed.

Lemma refa317_not2706 : ~ @Equation2706 Fin4 refa317_inst.
Proof. unfold Equation2706. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa317_inst, refa317_op in H. discriminate H. Qed.

Lemma refa317_not2710 : ~ @Equation2710 Fin4 refa317_inst.
Proof. unfold Equation2710. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa317_inst, refa317_op in H. discriminate H. Qed.

Lemma refa317_not2733 : ~ @Equation2733 Fin4 refa317_inst.
Proof. unfold Equation2733. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa317_inst, refa317_op in H. discriminate H. Qed.

Lemma refa317_not2743 : ~ @Equation2743 Fin4 refa317_inst.
Proof. unfold Equation2743. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa317_inst, refa317_op in H. discriminate H. Qed.

Lemma refa317_not2744 : ~ @Equation2744 Fin4 refa317_inst.
Proof. unfold Equation2744. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa317_inst, refa317_op in H. discriminate H. Qed.

Lemma refa317_not2746 : ~ @Equation2746 Fin4 refa317_inst.
Proof. unfold Equation2746. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa317_inst, refa317_op in H. discriminate H. Qed.

Lemma refa317_not2849 : ~ @Equation2849 Fin4 refa317_inst.
Proof. unfold Equation2849. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa317_inst, refa317_op in H. discriminate H. Qed.

Lemma refa317_not2852 : ~ @Equation2852 Fin4 refa317_inst.
Proof. unfold Equation2852. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa317_inst, refa317_op in H. discriminate H. Qed.

Lemma refa317_not2853 : ~ @Equation2853 Fin4 refa317_inst.
Proof. unfold Equation2853. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa317_inst, refa317_op in H. discriminate H. Qed.

Lemma refa317_not2856 : ~ @Equation2856 Fin4 refa317_inst.
Proof. unfold Equation2856. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa317_inst, refa317_op in H. discriminate H. Qed.

Lemma refa317_not2862 : ~ @Equation2862 Fin4 refa317_inst.
Proof. unfold Equation2862. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa317_inst, refa317_op in H. discriminate H. Qed.

Lemma refa317_not2865 : ~ @Equation2865 Fin4 refa317_inst.
Proof. unfold Equation2865. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa317_inst, refa317_op in H. discriminate H. Qed.

Lemma refa317_not2866 : ~ @Equation2866 Fin4 refa317_inst.
Proof. unfold Equation2866. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa317_inst, refa317_op in H. discriminate H. Qed.

Lemma refa317_not2872 : ~ @Equation2872 Fin4 refa317_inst.
Proof. unfold Equation2872. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa317_inst, refa317_op in H. discriminate H. Qed.

Lemma refa317_not2873 : ~ @Equation2873 Fin4 refa317_inst.
Proof. unfold Equation2873. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa317_inst, refa317_op in H. discriminate H. Qed.

Lemma refa317_not2875 : ~ @Equation2875 Fin4 refa317_inst.
Proof. unfold Equation2875. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa317_inst, refa317_op in H. discriminate H. Qed.

Lemma refa317_not2899 : ~ @Equation2899 Fin4 refa317_inst.
Proof. unfold Equation2899. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa317_inst, refa317_op in H. discriminate H. Qed.

Lemma refa317_not2900 : ~ @Equation2900 Fin4 refa317_inst.
Proof. unfold Equation2900. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa317_inst, refa317_op in H. discriminate H. Qed.

Lemma refa317_not2903 : ~ @Equation2903 Fin4 refa317_inst.
Proof. unfold Equation2903. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa317_inst, refa317_op in H. discriminate H. Qed.

Lemma refa317_not2910 : ~ @Equation2910 Fin4 refa317_inst.
Proof. unfold Equation2910. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa317_inst, refa317_op in H. discriminate H. Qed.

Lemma refa317_not2912 : ~ @Equation2912 Fin4 refa317_inst.
Proof. unfold Equation2912. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa317_inst, refa317_op in H. discriminate H. Qed.

Lemma refa317_not2936 : ~ @Equation2936 Fin4 refa317_inst.
Proof. unfold Equation2936. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa317_inst, refa317_op in H. discriminate H. Qed.

Lemma refa317_not2937 : ~ @Equation2937 Fin4 refa317_inst.
Proof. unfold Equation2937. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa317_inst, refa317_op in H. discriminate H. Qed.

Lemma refa317_not2939 : ~ @Equation2939 Fin4 refa317_inst.
Proof. unfold Equation2939. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa317_inst, refa317_op in H. discriminate H. Qed.

Lemma refa317_not2946 : ~ @Equation2946 Fin4 refa317_inst.
Proof. unfold Equation2946. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa317_inst, refa317_op in H. discriminate H. Qed.

Lemma refa317_not2949 : ~ @Equation2949 Fin4 refa317_inst.
Proof. unfold Equation2949. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa317_inst, refa317_op in H. discriminate H. Qed.

Lemma refa317_not3052 : ~ @Equation3052 Fin4 refa317_inst.
Proof. unfold Equation3052. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa317_inst, refa317_op in H. discriminate H. Qed.

Lemma refa317_not3055 : ~ @Equation3055 Fin4 refa317_inst.
Proof. unfold Equation3055. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa317_inst, refa317_op in H. discriminate H. Qed.

Lemma refa317_not3056 : ~ @Equation3056 Fin4 refa317_inst.
Proof. unfold Equation3056. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa317_inst, refa317_op in H. discriminate H. Qed.

Lemma refa317_not3058 : ~ @Equation3058 Fin4 refa317_inst.
Proof. unfold Equation3058. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa317_inst, refa317_op in H. discriminate H. Qed.

Lemma refa317_not3065 : ~ @Equation3065 Fin4 refa317_inst.
Proof. unfold Equation3065. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa317_inst, refa317_op in H. discriminate H. Qed.

Lemma refa317_not3068 : ~ @Equation3068 Fin4 refa317_inst.
Proof. unfold Equation3068. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa317_inst, refa317_op in H. discriminate H. Qed.

Lemma refa317_not3069 : ~ @Equation3069 Fin4 refa317_inst.
Proof. unfold Equation3069. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa317_inst, refa317_op in H. discriminate H. Qed.

Lemma refa317_not3075 : ~ @Equation3075 Fin4 refa317_inst.
Proof. unfold Equation3075. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa317_inst, refa317_op in H. discriminate H. Qed.

Lemma refa317_not3076 : ~ @Equation3076 Fin4 refa317_inst.
Proof. unfold Equation3076. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa317_inst, refa317_op in H. discriminate H. Qed.

Lemma refa317_not3079 : ~ @Equation3079 Fin4 refa317_inst.
Proof. unfold Equation3079. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa317_inst, refa317_op in H. discriminate H. Qed.

Lemma refa317_not3102 : ~ @Equation3102 Fin4 refa317_inst.
Proof. unfold Equation3102. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa317_inst, refa317_op in H. discriminate H. Qed.

Lemma refa317_not3103 : ~ @Equation3103 Fin4 refa317_inst.
Proof. unfold Equation3103. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa317_inst, refa317_op in H. discriminate H. Qed.

Lemma refa317_not3105 : ~ @Equation3105 Fin4 refa317_inst.
Proof. unfold Equation3105. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa317_inst, refa317_op in H. discriminate H. Qed.

Lemma refa317_not3113 : ~ @Equation3113 Fin4 refa317_inst.
Proof. unfold Equation3113. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa317_inst, refa317_op in H. discriminate H. Qed.

Lemma refa317_not3115 : ~ @Equation3115 Fin4 refa317_inst.
Proof. unfold Equation3115. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa317_inst, refa317_op in H. discriminate H. Qed.

Lemma refa317_not3116 : ~ @Equation3116 Fin4 refa317_inst.
Proof. unfold Equation3116. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa317_inst, refa317_op in H. discriminate H. Qed.

Lemma refa317_not3139 : ~ @Equation3139 Fin4 refa317_inst.
Proof. unfold Equation3139. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa317_inst, refa317_op in H. discriminate H. Qed.

Lemma refa317_not3140 : ~ @Equation3140 Fin4 refa317_inst.
Proof. unfold Equation3140. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa317_inst, refa317_op in H. discriminate H. Qed.

Lemma refa317_not3143 : ~ @Equation3143 Fin4 refa317_inst.
Proof. unfold Equation3143. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa317_inst, refa317_op in H. discriminate H. Qed.

Lemma refa317_not3149 : ~ @Equation3149 Fin4 refa317_inst.
Proof. unfold Equation3149. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa317_inst, refa317_op in H. discriminate H. Qed.

Lemma refa317_not3152 : ~ @Equation3152 Fin4 refa317_inst.
Proof. unfold Equation3152. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa317_inst, refa317_op in H. discriminate H. Qed.

Lemma refa317_not3254 : ~ @Equation3254 Fin4 refa317_inst.
Proof. unfold Equation3254. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa317_inst, refa317_op in H. discriminate H. Qed.

Lemma refa317_not3255 : ~ @Equation3255 Fin4 refa317_inst.
Proof. unfold Equation3255. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa317_inst, refa317_op in H. discriminate H. Qed.

Lemma refa317_not3256 : ~ @Equation3256 Fin4 refa317_inst.
Proof. unfold Equation3256. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa317_inst, refa317_op in H. discriminate H. Qed.

Lemma refa317_not3258 : ~ @Equation3258 Fin4 refa317_inst.
Proof. unfold Equation3258. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa317_inst, refa317_op in H. discriminate H. Qed.

Lemma refa317_not3261 : ~ @Equation3261 Fin4 refa317_inst.
Proof. unfold Equation3261. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa317_inst, refa317_op in H. discriminate H. Qed.

Lemma refa317_not3262 : ~ @Equation3262 Fin4 refa317_inst.
Proof. unfold Equation3262. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa317_inst, refa317_op in H. discriminate H. Qed.

Lemma refa317_not3268 : ~ @Equation3268 Fin4 refa317_inst.
Proof. unfold Equation3268. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa317_inst, refa317_op in H. discriminate H. Qed.

Lemma refa317_not3269 : ~ @Equation3269 Fin4 refa317_inst.
Proof. unfold Equation3269. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa317_inst, refa317_op in H. discriminate H. Qed.

Lemma refa317_not3271 : ~ @Equation3271 Fin4 refa317_inst.
Proof. unfold Equation3271. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa317_inst, refa317_op in H. discriminate H. Qed.

Lemma refa317_not3278 : ~ @Equation3278 Fin4 refa317_inst.
Proof. unfold Equation3278. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa317_inst, refa317_op in H. discriminate H. Qed.

Lemma refa317_not3279 : ~ @Equation3279 Fin4 refa317_inst.
Proof. unfold Equation3279. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa317_inst, refa317_op in H. discriminate H. Qed.

Lemma refa317_not3306 : ~ @Equation3306 Fin4 refa317_inst.
Proof. unfold Equation3306. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa317_inst, refa317_op in H. discriminate H. Qed.

Lemma refa317_not3309 : ~ @Equation3309 Fin4 refa317_inst.
Proof. unfold Equation3309. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa317_inst, refa317_op in H. discriminate H. Qed.

Lemma refa317_not3315 : ~ @Equation3315 Fin4 refa317_inst.
Proof. unfold Equation3315. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa317_inst, refa317_op in H. discriminate H. Qed.

Lemma refa317_not3316 : ~ @Equation3316 Fin4 refa317_inst.
Proof. unfold Equation3316. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa317_inst, refa317_op in H. discriminate H. Qed.

Lemma refa317_not3318 : ~ @Equation3318 Fin4 refa317_inst.
Proof. unfold Equation3318. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa317_inst, refa317_op in H. discriminate H. Qed.

Lemma refa317_not3342 : ~ @Equation3342 Fin4 refa317_inst.
Proof. unfold Equation3342. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa317_inst, refa317_op in H. discriminate H. Qed.

Lemma refa317_not3345 : ~ @Equation3345 Fin4 refa317_inst.
Proof. unfold Equation3345. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa317_inst, refa317_op in H. discriminate H. Qed.

Lemma refa317_not3346 : ~ @Equation3346 Fin4 refa317_inst.
Proof. unfold Equation3346. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa317_inst, refa317_op in H. discriminate H. Qed.

Lemma refa317_not3353 : ~ @Equation3353 Fin4 refa317_inst.
Proof. unfold Equation3353. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa317_inst, refa317_op in H. discriminate H. Qed.

Lemma refa317_not3355 : ~ @Equation3355 Fin4 refa317_inst.
Proof. unfold Equation3355. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa317_inst, refa317_op in H. discriminate H. Qed.

Lemma refa317_not3457 : ~ @Equation3457 Fin4 refa317_inst.
Proof. unfold Equation3457. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa317_inst, refa317_op in H. discriminate H. Qed.

Lemma refa317_not3458 : ~ @Equation3458 Fin4 refa317_inst.
Proof. unfold Equation3458. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa317_inst, refa317_op in H. discriminate H. Qed.

Lemma refa317_not3459 : ~ @Equation3459 Fin4 refa317_inst.
Proof. unfold Equation3459. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa317_inst, refa317_op in H. discriminate H. Qed.

Lemma refa317_not3461 : ~ @Equation3461 Fin4 refa317_inst.
Proof. unfold Equation3461. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa317_inst, refa317_op in H. discriminate H. Qed.

Lemma refa317_not3464 : ~ @Equation3464 Fin4 refa317_inst.
Proof. unfold Equation3464. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa317_inst, refa317_op in H. discriminate H. Qed.

Lemma refa317_not3465 : ~ @Equation3465 Fin4 refa317_inst.
Proof. unfold Equation3465. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa317_inst, refa317_op in H. discriminate H. Qed.

Lemma refa317_not3474 : ~ @Equation3474 Fin4 refa317_inst.
Proof. unfold Equation3474. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa317_inst, refa317_op in H. discriminate H. Qed.

Lemma refa317_not3475 : ~ @Equation3475 Fin4 refa317_inst.
Proof. unfold Equation3475. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa317_inst, refa317_op in H. discriminate H. Qed.

Lemma refa317_not3482 : ~ @Equation3482 Fin4 refa317_inst.
Proof. unfold Equation3482. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa317_inst, refa317_op in H. discriminate H. Qed.

Lemma refa317_not3484 : ~ @Equation3484 Fin4 refa317_inst.
Proof. unfold Equation3484. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa317_inst, refa317_op in H. discriminate H. Qed.

Lemma refa317_not3509 : ~ @Equation3509 Fin4 refa317_inst.
Proof. unfold Equation3509. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa317_inst, refa317_op in H. discriminate H. Qed.

Lemma refa317_not3512 : ~ @Equation3512 Fin4 refa317_inst.
Proof. unfold Equation3512. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa317_inst, refa317_op in H. discriminate H. Qed.

Lemma refa317_not3518 : ~ @Equation3518 Fin4 refa317_inst.
Proof. unfold Equation3518. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa317_inst, refa317_op in H. discriminate H. Qed.

Lemma refa317_not3519 : ~ @Equation3519 Fin4 refa317_inst.
Proof. unfold Equation3519. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa317_inst, refa317_op in H. discriminate H. Qed.

Lemma refa317_not3521 : ~ @Equation3521 Fin4 refa317_inst.
Proof. unfold Equation3521. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa317_inst, refa317_op in H. discriminate H. Qed.

Lemma refa317_not3545 : ~ @Equation3545 Fin4 refa317_inst.
Proof. unfold Equation3545. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa317_inst, refa317_op in H. discriminate H. Qed.

Lemma refa317_not3546 : ~ @Equation3546 Fin4 refa317_inst.
Proof. unfold Equation3546. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa317_inst, refa317_op in H. discriminate H. Qed.

Lemma refa317_not3548 : ~ @Equation3548 Fin4 refa317_inst.
Proof. unfold Equation3548. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa317_inst, refa317_op in H. discriminate H. Qed.

Lemma refa317_not3555 : ~ @Equation3555 Fin4 refa317_inst.
Proof. unfold Equation3555. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa317_inst, refa317_op in H. discriminate H. Qed.

Lemma refa317_not3556 : ~ @Equation3556 Fin4 refa317_inst.
Proof. unfold Equation3556. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa317_inst, refa317_op in H. discriminate H. Qed.

Lemma refa317_not3660 : ~ @Equation3660 Fin4 refa317_inst.
Proof. unfold Equation3660. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa317_inst, refa317_op in H. discriminate H. Qed.

Lemma refa317_not3661 : ~ @Equation3661 Fin4 refa317_inst.
Proof. unfold Equation3661. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa317_inst, refa317_op in H. discriminate H. Qed.

Lemma refa317_not3662 : ~ @Equation3662 Fin4 refa317_inst.
Proof. unfold Equation3662. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa317_inst, refa317_op in H. discriminate H. Qed.

Lemma refa317_not3664 : ~ @Equation3664 Fin4 refa317_inst.
Proof. unfold Equation3664. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa317_inst, refa317_op in H. discriminate H. Qed.

Lemma refa317_not3665 : ~ @Equation3665 Fin4 refa317_inst.
Proof. unfold Equation3665. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa317_inst, refa317_op in H. discriminate H. Qed.

Lemma refa317_not3668 : ~ @Equation3668 Fin4 refa317_inst.
Proof. unfold Equation3668. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa317_inst, refa317_op in H. discriminate H. Qed.

Lemma refa317_not3674 : ~ @Equation3674 Fin4 refa317_inst.
Proof. unfold Equation3674. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa317_inst, refa317_op in H. discriminate H. Qed.

Lemma refa317_not3675 : ~ @Equation3675 Fin4 refa317_inst.
Proof. unfold Equation3675. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa317_inst, refa317_op in H. discriminate H. Qed.

Lemma refa317_not3677 : ~ @Equation3677 Fin4 refa317_inst.
Proof. unfold Equation3677. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa317_inst, refa317_op in H. discriminate H. Qed.

Lemma refa317_not3684 : ~ @Equation3684 Fin4 refa317_inst.
Proof. unfold Equation3684. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa317_inst, refa317_op in H. discriminate H. Qed.

Lemma refa317_not3687 : ~ @Equation3687 Fin4 refa317_inst.
Proof. unfold Equation3687. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa317_inst, refa317_op in H. discriminate H. Qed.

Lemma refa317_not3712 : ~ @Equation3712 Fin4 refa317_inst.
Proof. unfold Equation3712. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa317_inst, refa317_op in H. discriminate H. Qed.

Lemma refa317_not3714 : ~ @Equation3714 Fin4 refa317_inst.
Proof. unfold Equation3714. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa317_inst, refa317_op in H. discriminate H. Qed.

Lemma refa317_not3721 : ~ @Equation3721 Fin4 refa317_inst.
Proof. unfold Equation3721. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa317_inst, refa317_op in H. discriminate H. Qed.

Lemma refa317_not3724 : ~ @Equation3724 Fin4 refa317_inst.
Proof. unfold Equation3724. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa317_inst, refa317_op in H. discriminate H. Qed.

Lemma refa317_not3725 : ~ @Equation3725 Fin4 refa317_inst.
Proof. unfold Equation3725. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa317_inst, refa317_op in H. discriminate H. Qed.

Lemma refa317_not3749 : ~ @Equation3749 Fin4 refa317_inst.
Proof. unfold Equation3749. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa317_inst, refa317_op in H. discriminate H. Qed.

Lemma refa317_not3752 : ~ @Equation3752 Fin4 refa317_inst.
Proof. unfold Equation3752. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa317_inst, refa317_op in H. discriminate H. Qed.

Lemma refa317_not3759 : ~ @Equation3759 Fin4 refa317_inst.
Proof. unfold Equation3759. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa317_inst, refa317_op in H. discriminate H. Qed.

Lemma refa317_not3864 : ~ @Equation3864 Fin4 refa317_inst.
Proof. unfold Equation3864. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa317_inst, refa317_op in H. discriminate H. Qed.

Lemma refa317_not3867 : ~ @Equation3867 Fin4 refa317_inst.
Proof. unfold Equation3867. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa317_inst, refa317_op in H. discriminate H. Qed.

Lemma refa317_not3868 : ~ @Equation3868 Fin4 refa317_inst.
Proof. unfold Equation3868. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa317_inst, refa317_op in H. discriminate H. Qed.

Lemma refa317_not3870 : ~ @Equation3870 Fin4 refa317_inst.
Proof. unfold Equation3870. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa317_inst, refa317_op in H. discriminate H. Qed.

Lemma refa317_not3871 : ~ @Equation3871 Fin4 refa317_inst.
Proof. unfold Equation3871. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa317_inst, refa317_op in H. discriminate H. Qed.

Lemma refa317_not3877 : ~ @Equation3877 Fin4 refa317_inst.
Proof. unfold Equation3877. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa317_inst, refa317_op in H. discriminate H. Qed.

Lemma refa317_not3881 : ~ @Equation3881 Fin4 refa317_inst.
Proof. unfold Equation3881. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa317_inst, refa317_op in H. discriminate H. Qed.

Lemma refa317_not3887 : ~ @Equation3887 Fin4 refa317_inst.
Proof. unfold Equation3887. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa317_inst, refa317_op in H. discriminate H. Qed.

Lemma refa317_not3888 : ~ @Equation3888 Fin4 refa317_inst.
Proof. unfold Equation3888. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa317_inst, refa317_op in H. discriminate H. Qed.

Lemma refa317_not3890 : ~ @Equation3890 Fin4 refa317_inst.
Proof. unfold Equation3890. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa317_inst, refa317_op in H. discriminate H. Qed.

Lemma refa317_not3918 : ~ @Equation3918 Fin4 refa317_inst.
Proof. unfold Equation3918. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa317_inst, refa317_op in H. discriminate H. Qed.

Lemma refa317_not3924 : ~ @Equation3924 Fin4 refa317_inst.
Proof. unfold Equation3924. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa317_inst, refa317_op in H. discriminate H. Qed.

Lemma refa317_not3925 : ~ @Equation3925 Fin4 refa317_inst.
Proof. unfold Equation3925. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa317_inst, refa317_op in H. discriminate H. Qed.

Lemma refa317_not3927 : ~ @Equation3927 Fin4 refa317_inst.
Proof. unfold Equation3927. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa317_inst, refa317_op in H. discriminate H. Qed.

Lemma refa317_not3928 : ~ @Equation3928 Fin4 refa317_inst.
Proof. unfold Equation3928. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa317_inst, refa317_op in H. discriminate H. Qed.

Lemma refa317_not3952 : ~ @Equation3952 Fin4 refa317_inst.
Proof. unfold Equation3952. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa317_inst, refa317_op in H. discriminate H. Qed.

Lemma refa317_not3954 : ~ @Equation3954 Fin4 refa317_inst.
Proof. unfold Equation3954. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa317_inst, refa317_op in H. discriminate H. Qed.

Lemma refa317_not3961 : ~ @Equation3961 Fin4 refa317_inst.
Proof. unfold Equation3961. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa317_inst, refa317_op in H. discriminate H. Qed.

Lemma refa317_not3962 : ~ @Equation3962 Fin4 refa317_inst.
Proof. unfold Equation3962. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa317_inst, refa317_op in H. discriminate H. Qed.

Lemma refa317_not3964 : ~ @Equation3964 Fin4 refa317_inst.
Proof. unfold Equation3964. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa317_inst, refa317_op in H. discriminate H. Qed.

Lemma refa317_not4066 : ~ @Equation4066 Fin4 refa317_inst.
Proof. unfold Equation4066. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa317_inst, refa317_op in H. discriminate H. Qed.

Lemma refa317_not4067 : ~ @Equation4067 Fin4 refa317_inst.
Proof. unfold Equation4067. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa317_inst, refa317_op in H. discriminate H. Qed.

Lemma refa317_not4068 : ~ @Equation4068 Fin4 refa317_inst.
Proof. unfold Equation4068. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa317_inst, refa317_op in H. discriminate H. Qed.

Lemma refa317_not4070 : ~ @Equation4070 Fin4 refa317_inst.
Proof. unfold Equation4070. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa317_inst, refa317_op in H. discriminate H. Qed.

Lemma refa317_not4071 : ~ @Equation4071 Fin4 refa317_inst.
Proof. unfold Equation4071. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa317_inst, refa317_op in H. discriminate H. Qed.

Lemma refa317_not4073 : ~ @Equation4073 Fin4 refa317_inst.
Proof. unfold Equation4073. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa317_inst, refa317_op in H. discriminate H. Qed.

Lemma refa317_not4080 : ~ @Equation4080 Fin4 refa317_inst.
Proof. unfold Equation4080. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa317_inst, refa317_op in H. discriminate H. Qed.

Lemma refa317_not4081 : ~ @Equation4081 Fin4 refa317_inst.
Proof. unfold Equation4081. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa317_inst, refa317_op in H. discriminate H. Qed.

Lemma refa317_not4084 : ~ @Equation4084 Fin4 refa317_inst.
Proof. unfold Equation4084. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa317_inst, refa317_op in H. discriminate H. Qed.

Lemma refa317_not4090 : ~ @Equation4090 Fin4 refa317_inst.
Proof. unfold Equation4090. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa317_inst, refa317_op in H. discriminate H. Qed.

Lemma refa317_not4093 : ~ @Equation4093 Fin4 refa317_inst.
Proof. unfold Equation4093. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa317_inst, refa317_op in H. discriminate H. Qed.

Lemma refa317_not4120 : ~ @Equation4120 Fin4 refa317_inst.
Proof. unfold Equation4120. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa317_inst, refa317_op in H. discriminate H. Qed.

Lemma refa317_not4121 : ~ @Equation4121 Fin4 refa317_inst.
Proof. unfold Equation4121. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa317_inst, refa317_op in H. discriminate H. Qed.

Lemma refa317_not4127 : ~ @Equation4127 Fin4 refa317_inst.
Proof. unfold Equation4127. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa317_inst, refa317_op in H. discriminate H. Qed.

Lemma refa317_not4128 : ~ @Equation4128 Fin4 refa317_inst.
Proof. unfold Equation4128. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa317_inst, refa317_op in H. discriminate H. Qed.

Lemma refa317_not4131 : ~ @Equation4131 Fin4 refa317_inst.
Proof. unfold Equation4131. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa317_inst, refa317_op in H. discriminate H. Qed.

Lemma refa317_not4154 : ~ @Equation4154 Fin4 refa317_inst.
Proof. unfold Equation4154. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa317_inst, refa317_op in H. discriminate H. Qed.

Lemma refa317_not4155 : ~ @Equation4155 Fin4 refa317_inst.
Proof. unfold Equation4155. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa317_inst, refa317_op in H. discriminate H. Qed.

Lemma refa317_not4157 : ~ @Equation4157 Fin4 refa317_inst.
Proof. unfold Equation4157. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa317_inst, refa317_op in H. discriminate H. Qed.

Lemma refa317_not4165 : ~ @Equation4165 Fin4 refa317_inst.
Proof. unfold Equation4165. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa317_inst, refa317_op in H. discriminate H. Qed.

Lemma refa317_not4167 : ~ @Equation4167 Fin4 refa317_inst.
Proof. unfold Equation4167. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa317_inst, refa317_op in H. discriminate H. Qed.

Lemma refa317_not4268 : ~ @Equation4268 Fin4 refa317_inst.
Proof. unfold Equation4268. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa317_inst, refa317_op in H. discriminate H. Qed.

Lemma refa317_not4269 : ~ @Equation4269 Fin4 refa317_inst.
Proof. unfold Equation4269. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa317_inst, refa317_op in H. discriminate H. Qed.

Lemma refa317_not4270 : ~ @Equation4270 Fin4 refa317_inst.
Proof. unfold Equation4270. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa317_inst, refa317_op in H. discriminate H. Qed.

Lemma refa317_not4272 : ~ @Equation4272 Fin4 refa317_inst.
Proof. unfold Equation4272. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa317_inst, refa317_op in H. discriminate H. Qed.

Lemma refa317_not4275 : ~ @Equation4275 Fin4 refa317_inst.
Proof. unfold Equation4275. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa317_inst, refa317_op in H. discriminate H. Qed.

Lemma refa317_not4276 : ~ @Equation4276 Fin4 refa317_inst.
Proof. unfold Equation4276. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa317_inst, refa317_op in H. discriminate H. Qed.

Lemma refa317_not4283 : ~ @Equation4283 Fin4 refa317_inst.
Proof. unfold Equation4283. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa317_inst, refa317_op in H. discriminate H. Qed.

Lemma refa317_not4284 : ~ @Equation4284 Fin4 refa317_inst.
Proof. unfold Equation4284. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa317_inst, refa317_op in H. discriminate H. Qed.

Lemma refa317_not4291 : ~ @Equation4291 Fin4 refa317_inst.
Proof. unfold Equation4291. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa317_inst, refa317_op in H. discriminate H. Qed.

Lemma refa317_not4293 : ~ @Equation4293 Fin4 refa317_inst.
Proof. unfold Equation4293. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa317_inst, refa317_op in H. discriminate H. Qed.

Lemma refa317_not4314 : ~ @Equation4314 Fin4 refa317_inst.
Proof. unfold Equation4314. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa317_inst, refa317_op in H. discriminate H. Qed.

Lemma refa317_not4320 : ~ @Equation4320 Fin4 refa317_inst.
Proof. unfold Equation4320. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa317_inst, refa317_op in H. discriminate H. Qed.

Lemma refa317_not4321 : ~ @Equation4321 Fin4 refa317_inst.
Proof. unfold Equation4321. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa317_inst, refa317_op in H. discriminate H. Qed.

Lemma refa317_not4343 : ~ @Equation4343 Fin4 refa317_inst.
Proof. unfold Equation4343. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa317_inst, refa317_op in H. discriminate H. Qed.

Lemma refa317_not4396 : ~ @Equation4396 Fin4 refa317_inst.
Proof. unfold Equation4396. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa317_inst, refa317_op in H. discriminate H. Qed.

Lemma refa317_not4398 : ~ @Equation4398 Fin4 refa317_inst.
Proof. unfold Equation4398. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa317_inst, refa317_op in H. discriminate H. Qed.

Lemma refa317_not4405 : ~ @Equation4405 Fin4 refa317_inst.
Proof. unfold Equation4405. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa317_inst, refa317_op in H. discriminate H. Qed.

Lemma refa317_not4406 : ~ @Equation4406 Fin4 refa317_inst.
Proof. unfold Equation4406. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa317_inst, refa317_op in H. discriminate H. Qed.

Lemma refa317_not4433 : ~ @Equation4433 Fin4 refa317_inst.
Proof. unfold Equation4433. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa317_inst, refa317_op in H. discriminate H. Qed.

Lemma refa317_not4436 : ~ @Equation4436 Fin4 refa317_inst.
Proof. unfold Equation4436. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa317_inst, refa317_op in H. discriminate H. Qed.

Lemma refa317_not4442 : ~ @Equation4442 Fin4 refa317_inst.
Proof. unfold Equation4442. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa317_inst, refa317_op in H. discriminate H. Qed.

Lemma refa317_not4443 : ~ @Equation4443 Fin4 refa317_inst.
Proof. unfold Equation4443. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa317_inst, refa317_op in H. discriminate H. Qed.

Lemma refa317_not4445 : ~ @Equation4445 Fin4 refa317_inst.
Proof. unfold Equation4445. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa317_inst, refa317_op in H. discriminate H. Qed.

Lemma refa317_not4472 : ~ @Equation4472 Fin4 refa317_inst.
Proof. unfold Equation4472. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa317_inst, refa317_op in H. discriminate H. Qed.

Lemma refa317_not4473 : ~ @Equation4473 Fin4 refa317_inst.
Proof. unfold Equation4473. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa317_inst, refa317_op in H. discriminate H. Qed.

Lemma refa317_not4480 : ~ @Equation4480 Fin4 refa317_inst.
Proof. unfold Equation4480. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa317_inst, refa317_op in H. discriminate H. Qed.

Lemma refa317_not4482 : ~ @Equation4482 Fin4 refa317_inst.
Proof. unfold Equation4482. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa317_inst, refa317_op in H. discriminate H. Qed.

Lemma refa317_not4583 : ~ @Equation4583 Fin4 refa317_inst.
Proof. unfold Equation4583. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa317_inst, refa317_op in H. discriminate H. Qed.

Lemma refa317_not4584 : ~ @Equation4584 Fin4 refa317_inst.
Proof. unfold Equation4584. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa317_inst, refa317_op in H. discriminate H. Qed.

Lemma refa317_not4585 : ~ @Equation4585 Fin4 refa317_inst.
Proof. unfold Equation4585. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa317_inst, refa317_op in H. discriminate H. Qed.

Lemma refa317_not4587 : ~ @Equation4587 Fin4 refa317_inst.
Proof. unfold Equation4587. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa317_inst, refa317_op in H. discriminate H. Qed.

Lemma refa317_not4590 : ~ @Equation4590 Fin4 refa317_inst.
Proof. unfold Equation4590. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa317_inst, refa317_op in H. discriminate H. Qed.

Lemma refa317_not4591 : ~ @Equation4591 Fin4 refa317_inst.
Proof. unfold Equation4591. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa317_inst, refa317_op in H. discriminate H. Qed.

Lemma refa317_not4598 : ~ @Equation4598 Fin4 refa317_inst.
Proof. unfold Equation4598. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa317_inst, refa317_op in H. discriminate H. Qed.

Lemma refa317_not4599 : ~ @Equation4599 Fin4 refa317_inst.
Proof. unfold Equation4599. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa317_inst, refa317_op in H. discriminate H. Qed.

Lemma refa317_not4606 : ~ @Equation4606 Fin4 refa317_inst.
Proof. unfold Equation4606. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa317_inst, refa317_op in H. discriminate H. Qed.

Lemma refa317_not4608 : ~ @Equation4608 Fin4 refa317_inst.
Proof. unfold Equation4608. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa317_inst, refa317_op in H. discriminate H. Qed.

Lemma refa317_not4629 : ~ @Equation4629 Fin4 refa317_inst.
Proof. unfold Equation4629. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa317_inst, refa317_op in H. discriminate H. Qed.

Lemma refa317_not4635 : ~ @Equation4635 Fin4 refa317_inst.
Proof. unfold Equation4635. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa317_inst, refa317_op in H. discriminate H. Qed.

Lemma refa317_not4636 : ~ @Equation4636 Fin4 refa317_inst.
Proof. unfold Equation4636. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa317_inst, refa317_op in H. discriminate H. Qed.

Lemma refa317_not4658 : ~ @Equation4658 Fin4 refa317_inst.
Proof. unfold Equation4658. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa317_inst, refa317_op in H. discriminate H. Qed.

(** ---- refa318 (Fin4) ---- *)

Definition refa318_op (x y : Fin4) : Fin4 :=
  match x, y with
  | F4_0, F4_0 => F4_2 | F4_0, F4_1 => F4_0 | F4_0, F4_2 => F4_3 | F4_0, F4_3 => F4_1
  | F4_1, F4_0 => F4_3 | F4_1, F4_1 => F4_1 | F4_1, F4_2 => F4_1 | F4_1, F4_3 => F4_3
  | F4_2, F4_0 => F4_3 | F4_2, F4_1 => F4_2 | F4_2, F4_2 => F4_2 | F4_2, F4_3 => F4_3
  | F4_3, F4_0 => F4_1 | F4_3, F4_1 => F4_3 | F4_3, F4_2 => F4_3 | F4_3, F4_3 => F4_1
  end.

#[local] Instance refa318_inst : Magma Fin4 := {| magma_op := refa318_op |}.

Lemma refa318_sat419 : @Equation419 Fin4 refa318_inst.
Proof. unfold Equation419, magma_op, refa318_inst, refa318_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa318_sat1026 : @Equation1026 Fin4 refa318_inst.
Proof. unfold Equation1026, magma_op, refa318_inst, refa318_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa318_not1832 : ~ @Equation1832 Fin4 refa318_inst.
Proof. unfold Equation1832. intro H. specialize (H F4_0). unfold magma_op, refa318_inst, refa318_op in H. discriminate H. Qed.

Lemma refa318_not3862 : ~ @Equation3862 Fin4 refa318_inst.
Proof. unfold Equation3862. intro H. specialize (H F4_0). unfold magma_op, refa318_inst, refa318_op in H. discriminate H. Qed.

Lemma refa318_not4598 : ~ @Equation4598 Fin4 refa318_inst.
Proof. unfold Equation4598. intro H. specialize (H F4_0 F4_2). unfold magma_op, refa318_inst, refa318_op in H. discriminate H. Qed.

(** ---- refa319 (Fin4) ---- *)

Definition refa319_op (x y : Fin4) : Fin4 :=
  match x, y with
  | F4_0, F4_0 => F4_0 | F4_0, F4_1 => F4_3 | F4_0, F4_2 => F4_0 | F4_0, F4_3 => F4_3
  | F4_1, F4_0 => F4_2 | F4_1, F4_1 => F4_2 | F4_1, F4_2 => F4_1 | F4_1, F4_3 => F4_2
  | F4_2, F4_0 => F4_1 | F4_2, F4_1 => F4_1 | F4_2, F4_2 => F4_2 | F4_2, F4_3 => F4_1
  | F4_3, F4_0 => F4_3 | F4_3, F4_1 => F4_2 | F4_3, F4_2 => F4_3 | F4_3, F4_3 => F4_0
  end.

#[local] Instance refa319_inst : Magma Fin4 := {| magma_op := refa319_op |}.

Lemma refa319_sat2041 : @Equation2041 Fin4 refa319_inst.
Proof. unfold Equation2041, magma_op, refa319_inst, refa319_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa319_not2855 : ~ @Equation2855 Fin4 refa319_inst.
Proof. unfold Equation2855. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa319_inst, refa319_op in H. discriminate H. Qed.

(** ---- refa32 (Fin7) ---- *)

Definition refa32_op (x y : Fin7) : Fin7 :=
  match x, y with
  | F7_0, F7_0 => F7_1 | F7_0, F7_1 => F7_2 | F7_0, F7_2 => F7_3 | F7_0, F7_3 => F7_4 | F7_0, F7_4 => F7_5 | F7_0, F7_5 => F7_0 | F7_0, F7_6 => F7_6
  | F7_1, F7_0 => F7_5 | F7_1, F7_1 => F7_3 | F7_1, F7_2 => F7_2 | F7_1, F7_3 => F7_0 | F7_1, F7_4 => F7_1 | F7_1, F7_5 => F7_6 | F7_1, F7_6 => F7_4
  | F7_2, F7_0 => F7_6 | F7_2, F7_1 => F7_5 | F7_2, F7_2 => F7_0 | F7_2, F7_3 => F7_2 | F7_2, F7_4 => F7_4 | F7_2, F7_5 => F7_3 | F7_2, F7_6 => F7_1
  | F7_3, F7_0 => F7_0 | F7_3, F7_1 => F7_4 | F7_3, F7_2 => F7_6 | F7_3, F7_3 => F7_5 | F7_3, F7_4 => F7_2 | F7_3, F7_5 => F7_1 | F7_3, F7_6 => F7_3
  | F7_4, F7_0 => F7_4 | F7_4, F7_1 => F7_0 | F7_4, F7_2 => F7_1 | F7_4, F7_3 => F7_3 | F7_4, F7_4 => F7_6 | F7_4, F7_5 => F7_2 | F7_4, F7_6 => F7_5
  | F7_5, F7_0 => F7_2 | F7_5, F7_1 => F7_1 | F7_5, F7_2 => F7_5 | F7_5, F7_3 => F7_6 | F7_5, F7_4 => F7_3 | F7_5, F7_5 => F7_4 | F7_5, F7_6 => F7_0
  | F7_6, F7_0 => F7_3 | F7_6, F7_1 => F7_6 | F7_6, F7_2 => F7_4 | F7_6, F7_3 => F7_1 | F7_6, F7_4 => F7_0 | F7_6, F7_5 => F7_5 | F7_6, F7_6 => F7_2
  end.

#[local] Instance refa32_inst : Magma Fin7 := {| magma_op := refa32_op |}.

Lemma refa32_sat2707 : @Equation2707 Fin7 refa32_inst.
Proof. unfold Equation2707, magma_op, refa32_inst, refa32_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa32_not411 : ~ @Equation411 Fin7 refa32_inst.
Proof. unfold Equation411. intro H. specialize (H F7_0). unfold magma_op, refa32_inst, refa32_op in H. discriminate H. Qed.

Lemma refa32_not614 : ~ @Equation614 Fin7 refa32_inst.
Proof. unfold Equation614. intro H. specialize (H F7_0). unfold magma_op, refa32_inst, refa32_op in H. discriminate H. Qed.

Lemma refa32_not817 : ~ @Equation817 Fin7 refa32_inst.
Proof. unfold Equation817. intro H. specialize (H F7_0). unfold magma_op, refa32_inst, refa32_op in H. discriminate H. Qed.

Lemma refa32_not1020 : ~ @Equation1020 Fin7 refa32_inst.
Proof. unfold Equation1020. intro H. specialize (H F7_0). unfold magma_op, refa32_inst, refa32_op in H. discriminate H. Qed.

Lemma refa32_not1223 : ~ @Equation1223 Fin7 refa32_inst.
Proof. unfold Equation1223. intro H. specialize (H F7_0). unfold magma_op, refa32_inst, refa32_op in H. discriminate H. Qed.

Lemma refa32_not1426 : ~ @Equation1426 Fin7 refa32_inst.
Proof. unfold Equation1426. intro H. specialize (H F7_0). unfold magma_op, refa32_inst, refa32_op in H. discriminate H. Qed.

Lemma refa32_not1629 : ~ @Equation1629 Fin7 refa32_inst.
Proof. unfold Equation1629. intro H. specialize (H F7_0). unfold magma_op, refa32_inst, refa32_op in H. discriminate H. Qed.

Lemma refa32_not1832 : ~ @Equation1832 Fin7 refa32_inst.
Proof. unfold Equation1832. intro H. specialize (H F7_0). unfold magma_op, refa32_inst, refa32_op in H. discriminate H. Qed.

Lemma refa32_not2035 : ~ @Equation2035 Fin7 refa32_inst.
Proof. unfold Equation2035. intro H. specialize (H F7_0). unfold magma_op, refa32_inst, refa32_op in H. discriminate H. Qed.

Lemma refa32_not2243 : ~ @Equation2243 Fin7 refa32_inst.
Proof. unfold Equation2243. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa32_inst, refa32_op in H. discriminate H. Qed.

Lemma refa32_not2244 : ~ @Equation2244 Fin7 refa32_inst.
Proof. unfold Equation2244. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa32_inst, refa32_op in H. discriminate H. Qed.

Lemma refa32_not2246 : ~ @Equation2246 Fin7 refa32_inst.
Proof. unfold Equation2246. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa32_inst, refa32_op in H. discriminate H. Qed.

Lemma refa32_not2247 : ~ @Equation2247 Fin7 refa32_inst.
Proof. unfold Equation2247. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa32_inst, refa32_op in H. discriminate H. Qed.

Lemma refa32_not2253 : ~ @Equation2253 Fin7 refa32_inst.
Proof. unfold Equation2253. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa32_inst, refa32_op in H. discriminate H. Qed.

Lemma refa32_not2254 : ~ @Equation2254 Fin7 refa32_inst.
Proof. unfold Equation2254. intro H. specialize (H F7_0 F7_2). unfold magma_op, refa32_inst, refa32_op in H. discriminate H. Qed.

Lemma refa32_not2257 : ~ @Equation2257 Fin7 refa32_inst.
Proof. unfold Equation2257. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa32_inst, refa32_op in H. discriminate H. Qed.

Lemma refa32_not2264 : ~ @Equation2264 Fin7 refa32_inst.
Proof. unfold Equation2264. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa32_inst, refa32_op in H. discriminate H. Qed.

Lemma refa32_not2266 : ~ @Equation2266 Fin7 refa32_inst.
Proof. unfold Equation2266. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa32_inst, refa32_op in H. discriminate H. Qed.

Lemma refa32_not2290 : ~ @Equation2290 Fin7 refa32_inst.
Proof. unfold Equation2290. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa32_inst, refa32_op in H. discriminate H. Qed.

Lemma refa32_not2291 : ~ @Equation2291 Fin7 refa32_inst.
Proof. unfold Equation2291. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa32_inst, refa32_op in H. discriminate H. Qed.

Lemma refa32_not2293 : ~ @Equation2293 Fin7 refa32_inst.
Proof. unfold Equation2293. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa32_inst, refa32_op in H. discriminate H. Qed.

Lemma refa32_not2294 : ~ @Equation2294 Fin7 refa32_inst.
Proof. unfold Equation2294. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa32_inst, refa32_op in H. discriminate H. Qed.

Lemma refa32_not2300 : ~ @Equation2300 Fin7 refa32_inst.
Proof. unfold Equation2300. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa32_inst, refa32_op in H. discriminate H. Qed.

Lemma refa32_not2301 : ~ @Equation2301 Fin7 refa32_inst.
Proof. unfold Equation2301. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa32_inst, refa32_op in H. discriminate H. Qed.

Lemma refa32_not2303 : ~ @Equation2303 Fin7 refa32_inst.
Proof. unfold Equation2303. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa32_inst, refa32_op in H. discriminate H. Qed.

Lemma refa32_not2328 : ~ @Equation2328 Fin7 refa32_inst.
Proof. unfold Equation2328. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa32_inst, refa32_op in H. discriminate H. Qed.

Lemma refa32_not2330 : ~ @Equation2330 Fin7 refa32_inst.
Proof. unfold Equation2330. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa32_inst, refa32_op in H. discriminate H. Qed.

Lemma refa32_not2340 : ~ @Equation2340 Fin7 refa32_inst.
Proof. unfold Equation2340. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa32_inst, refa32_op in H. discriminate H. Qed.

Lemma refa32_not2441 : ~ @Equation2441 Fin7 refa32_inst.
Proof. unfold Equation2441. intro H. specialize (H F7_0). unfold magma_op, refa32_inst, refa32_op in H. discriminate H. Qed.

Lemma refa32_not2646 : ~ @Equation2646 Fin7 refa32_inst.
Proof. unfold Equation2646. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa32_inst, refa32_op in H. discriminate H. Qed.

Lemma refa32_not2647 : ~ @Equation2647 Fin7 refa32_inst.
Proof. unfold Equation2647. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa32_inst, refa32_op in H. discriminate H. Qed.

Lemma refa32_not2649 : ~ @Equation2649 Fin7 refa32_inst.
Proof. unfold Equation2649. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa32_inst, refa32_op in H. discriminate H. Qed.

Lemma refa32_not2650 : ~ @Equation2650 Fin7 refa32_inst.
Proof. unfold Equation2650. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa32_inst, refa32_op in H. discriminate H. Qed.

Lemma refa32_not2652 : ~ @Equation2652 Fin7 refa32_inst.
Proof. unfold Equation2652. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa32_inst, refa32_op in H. discriminate H. Qed.

Lemma refa32_not2659 : ~ @Equation2659 Fin7 refa32_inst.
Proof. unfold Equation2659. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa32_inst, refa32_op in H. discriminate H. Qed.

Lemma refa32_not2660 : ~ @Equation2660 Fin7 refa32_inst.
Proof. unfold Equation2660. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa32_inst, refa32_op in H. discriminate H. Qed.

Lemma refa32_not2662 : ~ @Equation2662 Fin7 refa32_inst.
Proof. unfold Equation2662. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa32_inst, refa32_op in H. discriminate H. Qed.

Lemma refa32_not2669 : ~ @Equation2669 Fin7 refa32_inst.
Proof. unfold Equation2669. intro H. specialize (H F7_0 F7_3). unfold magma_op, refa32_inst, refa32_op in H. discriminate H. Qed.

Lemma refa32_not2670 : ~ @Equation2670 Fin7 refa32_inst.
Proof. unfold Equation2670. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa32_inst, refa32_op in H. discriminate H. Qed.

Lemma refa32_not2672 : ~ @Equation2672 Fin7 refa32_inst.
Proof. unfold Equation2672. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa32_inst, refa32_op in H. discriminate H. Qed.

Lemma refa32_not2696 : ~ @Equation2696 Fin7 refa32_inst.
Proof. unfold Equation2696. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa32_inst, refa32_op in H. discriminate H. Qed.

Lemma refa32_not2697 : ~ @Equation2697 Fin7 refa32_inst.
Proof. unfold Equation2697. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa32_inst, refa32_op in H. discriminate H. Qed.

Lemma refa32_not2699 : ~ @Equation2699 Fin7 refa32_inst.
Proof. unfold Equation2699. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa32_inst, refa32_op in H. discriminate H. Qed.

Lemma refa32_not2700 : ~ @Equation2700 Fin7 refa32_inst.
Proof. unfold Equation2700. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa32_inst, refa32_op in H. discriminate H. Qed.

Lemma refa32_not2709 : ~ @Equation2709 Fin7 refa32_inst.
Proof. unfold Equation2709. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa32_inst, refa32_op in H. discriminate H. Qed.

Lemma refa32_not2710 : ~ @Equation2710 Fin7 refa32_inst.
Proof. unfold Equation2710. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa32_inst, refa32_op in H. discriminate H. Qed.

Lemma refa32_not2736 : ~ @Equation2736 Fin7 refa32_inst.
Proof. unfold Equation2736. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa32_inst, refa32_op in H. discriminate H. Qed.

Lemma refa32_not2743 : ~ @Equation2743 Fin7 refa32_inst.
Proof. unfold Equation2743. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa32_inst, refa32_op in H. discriminate H. Qed.

Lemma refa32_not2744 : ~ @Equation2744 Fin7 refa32_inst.
Proof. unfold Equation2744. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa32_inst, refa32_op in H. discriminate H. Qed.

Lemma refa32_not2746 : ~ @Equation2746 Fin7 refa32_inst.
Proof. unfold Equation2746. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa32_inst, refa32_op in H. discriminate H. Qed.

Lemma refa32_not2847 : ~ @Equation2847 Fin7 refa32_inst.
Proof. unfold Equation2847. intro H. specialize (H F7_0). unfold magma_op, refa32_inst, refa32_op in H. discriminate H. Qed.

Lemma refa32_not3050 : ~ @Equation3050 Fin7 refa32_inst.
Proof. unfold Equation3050. intro H. specialize (H F7_0). unfold magma_op, refa32_inst, refa32_op in H. discriminate H. Qed.

Lemma refa32_not3253 : ~ @Equation3253 Fin7 refa32_inst.
Proof. unfold Equation3253. intro H. specialize (H F7_0). unfold magma_op, refa32_inst, refa32_op in H. discriminate H. Qed.

Lemma refa32_not3456 : ~ @Equation3456 Fin7 refa32_inst.
Proof. unfold Equation3456. intro H. specialize (H F7_0). unfold magma_op, refa32_inst, refa32_op in H. discriminate H. Qed.

Lemma refa32_not3659 : ~ @Equation3659 Fin7 refa32_inst.
Proof. unfold Equation3659. intro H. specialize (H F7_0). unfold magma_op, refa32_inst, refa32_op in H. discriminate H. Qed.

Lemma refa32_not3862 : ~ @Equation3862 Fin7 refa32_inst.
Proof. unfold Equation3862. intro H. specialize (H F7_0). unfold magma_op, refa32_inst, refa32_op in H. discriminate H. Qed.

Lemma refa32_not4065 : ~ @Equation4065 Fin7 refa32_inst.
Proof. unfold Equation4065. intro H. specialize (H F7_0). unfold magma_op, refa32_inst, refa32_op in H. discriminate H. Qed.

Lemma refa32_not4268 : ~ @Equation4268 Fin7 refa32_inst.
Proof. unfold Equation4268. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa32_inst, refa32_op in H. discriminate H. Qed.

Lemma refa32_not4269 : ~ @Equation4269 Fin7 refa32_inst.
Proof. unfold Equation4269. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa32_inst, refa32_op in H. discriminate H. Qed.

Lemma refa32_not4270 : ~ @Equation4270 Fin7 refa32_inst.
Proof. unfold Equation4270. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa32_inst, refa32_op in H. discriminate H. Qed.

Lemma refa32_not4272 : ~ @Equation4272 Fin7 refa32_inst.
Proof. unfold Equation4272. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa32_inst, refa32_op in H. discriminate H. Qed.

Lemma refa32_not4275 : ~ @Equation4275 Fin7 refa32_inst.
Proof. unfold Equation4275. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa32_inst, refa32_op in H. discriminate H. Qed.

Lemma refa32_not4283 : ~ @Equation4283 Fin7 refa32_inst.
Proof. unfold Equation4283. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa32_inst, refa32_op in H. discriminate H. Qed.

Lemma refa32_not4284 : ~ @Equation4284 Fin7 refa32_inst.
Proof. unfold Equation4284. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa32_inst, refa32_op in H. discriminate H. Qed.

Lemma refa32_not4291 : ~ @Equation4291 Fin7 refa32_inst.
Proof. unfold Equation4291. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa32_inst, refa32_op in H. discriminate H. Qed.

Lemma refa32_not4293 : ~ @Equation4293 Fin7 refa32_inst.
Proof. unfold Equation4293. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa32_inst, refa32_op in H. discriminate H. Qed.

Lemma refa32_not4321 : ~ @Equation4321 Fin7 refa32_inst.
Proof. unfold Equation4321. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa32_inst, refa32_op in H. discriminate H. Qed.

Lemma refa32_not4343 : ~ @Equation4343 Fin7 refa32_inst.
Proof. unfold Equation4343. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa32_inst, refa32_op in H. discriminate H. Qed.

Lemma refa32_not4380 : ~ @Equation4380 Fin7 refa32_inst.
Proof. unfold Equation4380. intro H. specialize (H F7_0). unfold magma_op, refa32_inst, refa32_op in H. discriminate H. Qed.

Lemma refa32_not4583 : ~ @Equation4583 Fin7 refa32_inst.
Proof. unfold Equation4583. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa32_inst, refa32_op in H. discriminate H. Qed.

Lemma refa32_not4584 : ~ @Equation4584 Fin7 refa32_inst.
Proof. unfold Equation4584. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa32_inst, refa32_op in H. discriminate H. Qed.

Lemma refa32_not4585 : ~ @Equation4585 Fin7 refa32_inst.
Proof. unfold Equation4585. intro H. specialize (H F7_0 F7_2). unfold magma_op, refa32_inst, refa32_op in H. discriminate H. Qed.

Lemma refa32_not4587 : ~ @Equation4587 Fin7 refa32_inst.
Proof. unfold Equation4587. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa32_inst, refa32_op in H. discriminate H. Qed.

Lemma refa32_not4588 : ~ @Equation4588 Fin7 refa32_inst.
Proof. unfold Equation4588. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa32_inst, refa32_op in H. discriminate H. Qed.

Lemma refa32_not4590 : ~ @Equation4590 Fin7 refa32_inst.
Proof. unfold Equation4590. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa32_inst, refa32_op in H. discriminate H. Qed.

Lemma refa32_not4606 : ~ @Equation4606 Fin7 refa32_inst.
Proof. unfold Equation4606. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa32_inst, refa32_op in H. discriminate H. Qed.

Lemma refa32_not4608 : ~ @Equation4608 Fin7 refa32_inst.
Proof. unfold Equation4608. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa32_inst, refa32_op in H. discriminate H. Qed.

Lemma refa32_not4635 : ~ @Equation4635 Fin7 refa32_inst.
Proof. unfold Equation4635. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa32_inst, refa32_op in H. discriminate H. Qed.

Lemma refa32_not4636 : ~ @Equation4636 Fin7 refa32_inst.
Proof. unfold Equation4636. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa32_inst, refa32_op in H. discriminate H. Qed.

Lemma refa32_not4658 : ~ @Equation4658 Fin7 refa32_inst.
Proof. unfold Equation4658. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa32_inst, refa32_op in H. discriminate H. Qed.

(** ---- refa320 (Fin4) ---- *)

Definition refa320_op (x y : Fin4) : Fin4 :=
  match x, y with
  | F4_0, F4_0 => F4_2 | F4_0, F4_1 => F4_2 | F4_0, F4_2 => F4_0 | F4_0, F4_3 => F4_3
  | F4_1, F4_0 => F4_2 | F4_1, F4_1 => F4_2 | F4_1, F4_2 => F4_1 | F4_1, F4_3 => F4_0
  | F4_2, F4_0 => F4_2 | F4_2, F4_1 => F4_2 | F4_2, F4_2 => F4_0 | F4_2, F4_3 => F4_3
  | F4_3, F4_0 => F4_2 | F4_3, F4_1 => F4_3 | F4_3, F4_2 => F4_1 | F4_3, F4_3 => F4_0
  end.

#[local] Instance refa320_inst : Magma Fin4 := {| magma_op := refa320_op |}.

Lemma refa320_sat416 : @Equation416 Fin4 refa320_inst.
Proof. unfold Equation416, magma_op, refa320_inst, refa320_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa320_not359 : ~ @Equation359 Fin4 refa320_inst.
Proof. unfold Equation359. intro H. specialize (H F4_3). unfold magma_op, refa320_inst, refa320_op in H. discriminate H. Qed.

Lemma refa320_not1020 : ~ @Equation1020 Fin4 refa320_inst.
Proof. unfold Equation1020. intro H. specialize (H F4_3). unfold magma_op, refa320_inst, refa320_op in H. discriminate H. Qed.

Lemma refa320_not1832 : ~ @Equation1832 Fin4 refa320_inst.
Proof. unfold Equation1832. intro H. specialize (H F4_3). unfold magma_op, refa320_inst, refa320_op in H. discriminate H. Qed.

Lemma refa320_not2035 : ~ @Equation2035 Fin4 refa320_inst.
Proof. unfold Equation2035. intro H. specialize (H F4_1). unfold magma_op, refa320_inst, refa320_op in H. discriminate H. Qed.

Lemma refa320_not3253 : ~ @Equation3253 Fin4 refa320_inst.
Proof. unfold Equation3253. intro H. specialize (H F4_3). unfold magma_op, refa320_inst, refa320_op in H. discriminate H. Qed.

Lemma refa320_not3862 : ~ @Equation3862 Fin4 refa320_inst.
Proof. unfold Equation3862. intro H. specialize (H F4_3). unfold magma_op, refa320_inst, refa320_op in H. discriminate H. Qed.

(** ---- refa321 (Fin4) ---- *)

Definition refa321_op (x y : Fin4) : Fin4 :=
  match x, y with
  | F4_0, F4_0 => F4_3 | F4_0, F4_1 => F4_2 | F4_0, F4_2 => F4_2 | F4_0, F4_3 => F4_3
  | F4_1, F4_0 => F4_3 | F4_1, F4_1 => F4_2 | F4_1, F4_2 => F4_2 | F4_1, F4_3 => F4_3
  | F4_2, F4_0 => F4_1 | F4_2, F4_1 => F4_0 | F4_2, F4_2 => F4_1 | F4_2, F4_3 => F4_0
  | F4_3, F4_0 => F4_1 | F4_3, F4_1 => F4_0 | F4_3, F4_2 => F4_1 | F4_3, F4_3 => F4_0
  end.

#[local] Instance refa321_inst : Magma Fin4 := {| magma_op := refa321_op |}.

Lemma refa321_sat162 : @Equation162 Fin4 refa321_inst.
Proof. unfold Equation162, magma_op, refa321_inst, refa321_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa321_not3255 : ~ @Equation3255 Fin4 refa321_inst.
Proof. unfold Equation3255. intro H. specialize (H F4_0 F4_2). unfold magma_op, refa321_inst, refa321_op in H. discriminate H. Qed.

Lemma refa321_not3319 : ~ @Equation3319 Fin4 refa321_inst.
Proof. unfold Equation3319. intro H. specialize (H F4_0 F4_2). unfold magma_op, refa321_inst, refa321_op in H. discriminate H. Qed.

Lemma refa321_not4269 : ~ @Equation4269 Fin4 refa321_inst.
Proof. unfold Equation4269. intro H. specialize (H F4_0 F4_2). unfold magma_op, refa321_inst, refa321_op in H. discriminate H. Qed.

(** ---- refa322 (Fin4) ---- *)

Definition refa322_op (x y : Fin4) : Fin4 :=
  match x, y with
  | F4_0, F4_0 => F4_2 | F4_0, F4_1 => F4_2 | F4_0, F4_2 => F4_0 | F4_0, F4_3 => F4_3
  | F4_1, F4_0 => F4_2 | F4_1, F4_1 => F4_2 | F4_1, F4_2 => F4_0 | F4_1, F4_3 => F4_1
  | F4_2, F4_0 => F4_2 | F4_2, F4_1 => F4_3 | F4_2, F4_2 => F4_2 | F4_2, F4_3 => F4_2
  | F4_3, F4_0 => F4_2 | F4_3, F4_1 => F4_3 | F4_3, F4_2 => F4_3 | F4_3, F4_3 => F4_2
  end.

#[local] Instance refa322_inst : Magma Fin4 := {| magma_op := refa322_op |}.

Lemma refa322_sat104 : @Equation104 Fin4 refa322_inst.
Proof. unfold Equation104, magma_op, refa322_inst, refa322_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa322_sat1254 : @Equation1254 Fin4 refa322_inst.
Proof. unfold Equation1254, magma_op, refa322_inst, refa322_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa322_sat1262 : @Equation1262 Fin4 refa322_inst.
Proof. unfold Equation1262, magma_op, refa322_inst, refa322_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa322_not1020 : ~ @Equation1020 Fin4 refa322_inst.
Proof. unfold Equation1020. intro H. specialize (H F4_1). unfold magma_op, refa322_inst, refa322_op in H. discriminate H. Qed.

Lemma refa322_not1244 : ~ @Equation1244 Fin4 refa322_inst.
Proof. unfold Equation1244. intro H. specialize (H F4_3 F4_1 F4_2). unfold magma_op, refa322_inst, refa322_op in H. discriminate H. Qed.

Lemma refa322_not1832 : ~ @Equation1832 Fin4 refa322_inst.
Proof. unfold Equation1832. intro H. specialize (H F4_1). unfold magma_op, refa322_inst, refa322_op in H. discriminate H. Qed.

Lemma refa322_not4591 : ~ @Equation4591 Fin4 refa322_inst.
Proof. unfold Equation4591. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa322_inst, refa322_op in H. discriminate H. Qed.
