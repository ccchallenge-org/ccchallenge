(** * All4x4 counterexamples — batch 10
    Auto-generated from Lean4 All4x4 files. *)

From Stdlib Require Import Utf8.

From ETP Require Import Magma.
From ETP Require Import FinMagma.
From ETP.Equations Require Import All.

Open Scope magma_scope.

(** ---- refa504 (Fin4) ---- *)

Definition refa504_op (x y : Fin4) : Fin4 :=
  match x, y with
  | F4_0, F4_0 => F4_2 | F4_0, F4_1 => F4_2 | F4_0, F4_2 => F4_2 | F4_0, F4_3 => F4_3
  | F4_1, F4_0 => F4_3 | F4_1, F4_1 => F4_2 | F4_1, F4_2 => F4_0 | F4_1, F4_3 => F4_3
  | F4_2, F4_0 => F4_2 | F4_2, F4_1 => F4_0 | F4_2, F4_2 => F4_2 | F4_2, F4_3 => F4_0
  | F4_3, F4_0 => F4_3 | F4_3, F4_1 => F4_3 | F4_3, F4_2 => F4_0 | F4_3, F4_3 => F4_3
  end.

#[local] Instance refa504_inst : Magma Fin4 := {| magma_op := refa504_op |}.

Lemma refa504_sat3954 : @Equation3954 Fin4 refa504_inst.
Proof. unfold Equation3954, magma_op, refa504_inst, refa504_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa504_not3253 : ~ @Equation3253 Fin4 refa504_inst.
Proof. unfold Equation3253. intro H. specialize (H F4_1). unfold magma_op, refa504_inst, refa504_op in H. discriminate H. Qed.

Lemma refa504_not3714 : ~ @Equation3714 Fin4 refa504_inst.
Proof. unfold Equation3714. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa504_inst, refa504_op in H. discriminate H. Qed.

Lemma refa504_not3721 : ~ @Equation3721 Fin4 refa504_inst.
Proof. unfold Equation3721. intro H. specialize (H F4_0 F4_3). unfold magma_op, refa504_inst, refa504_op in H. discriminate H. Qed.

Lemma refa504_not3725 : ~ @Equation3725 Fin4 refa504_inst.
Proof. unfold Equation3725. intro H. specialize (H F4_1 F4_0). unfold magma_op, refa504_inst, refa504_op in H. discriminate H. Qed.

Lemma refa504_not3749 : ~ @Equation3749 Fin4 refa504_inst.
Proof. unfold Equation3749. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa504_inst, refa504_op in H. discriminate H. Qed.

Lemma refa504_not3761 : ~ @Equation3761 Fin4 refa504_inst.
Proof. unfold Equation3761. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa504_inst, refa504_op in H. discriminate H. Qed.

Lemma refa504_not3915 : ~ @Equation3915 Fin4 refa504_inst.
Proof. unfold Equation3915. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa504_inst, refa504_op in H. discriminate H. Qed.

Lemma refa504_not3928 : ~ @Equation3928 Fin4 refa504_inst.
Proof. unfold Equation3928. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa504_inst, refa504_op in H. discriminate H. Qed.

Lemma refa504_not3962 : ~ @Equation3962 Fin4 refa504_inst.
Proof. unfold Equation3962. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa504_inst, refa504_op in H. discriminate H. Qed.

Lemma refa504_not4290 : ~ @Equation4290 Fin4 refa504_inst.
Proof. unfold Equation4290. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa504_inst, refa504_op in H. discriminate H. Qed.

Lemma refa504_not4658 : ~ @Equation4658 Fin4 refa504_inst.
Proof. unfold Equation4658. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa504_inst, refa504_op in H. discriminate H. Qed.

(** ---- refa505 (Fin4) ---- *)

Definition refa505_op (x y : Fin4) : Fin4 :=
  match x, y with
  | F4_0, F4_0 => F4_3 | F4_0, F4_1 => F4_1 | F4_0, F4_2 => F4_3 | F4_0, F4_3 => F4_3
  | F4_1, F4_0 => F4_3 | F4_1, F4_1 => F4_3 | F4_1, F4_2 => F4_0 | F4_1, F4_3 => F4_3
  | F4_2, F4_0 => F4_3 | F4_2, F4_1 => F4_0 | F4_2, F4_2 => F4_3 | F4_2, F4_3 => F4_3
  | F4_3, F4_0 => F4_3 | F4_3, F4_1 => F4_3 | F4_3, F4_2 => F4_3 | F4_3, F4_3 => F4_3
  end.

#[local] Instance refa505_inst : Magma Fin4 := {| magma_op := refa505_op |}.

Lemma refa505_sat3701 : @Equation3701 Fin4 refa505_inst.
Proof. unfold Equation3701, magma_op, refa505_inst, refa505_op. intros x y z w. destruct x, y, z, w; reflexivity. Qed.

Lemma refa505_sat4115 : @Equation4115 Fin4 refa505_inst.
Proof. unfold Equation4115, magma_op, refa505_inst, refa505_op. intros x y z w. destruct x, y, z, w; reflexivity. Qed.

Lemma refa505_not3671 : ~ @Equation3671 Fin4 refa505_inst.
Proof. unfold Equation3671. intro H. specialize (H F4_2 F4_1 F4_0). unfold magma_op, refa505_inst, refa505_op in H. discriminate H. Qed.

Lemma refa505_not3680 : ~ @Equation3680 Fin4 refa505_inst.
Proof. unfold Equation3680. intro H. specialize (H F4_1 F4_2 F4_0). unfold magma_op, refa505_inst, refa505_op in H. discriminate H. Qed.

Lemma refa505_not4073 : ~ @Equation4073 Fin4 refa505_inst.
Proof. unfold Equation4073. intro H. specialize (H F4_2 F4_1). unfold magma_op, refa505_inst, refa505_op in H. discriminate H. Qed.

Lemma refa505_not4081 : ~ @Equation4081 Fin4 refa505_inst.
Proof. unfold Equation4081. intro H. specialize (H F4_1 F4_2). unfold magma_op, refa505_inst, refa505_op in H. discriminate H. Qed.

Lemma refa505_not4599 : ~ @Equation4599 Fin4 refa505_inst.
Proof. unfold Equation4599. intro H. specialize (H F4_2 F4_1). unfold magma_op, refa505_inst, refa505_op in H. discriminate H. Qed.

Lemma refa505_not4656 : ~ @Equation4656 Fin4 refa505_inst.
Proof. unfold Equation4656. intro H. specialize (H F4_2 F4_0 F4_1). unfold magma_op, refa505_inst, refa505_op in H. discriminate H. Qed.

(** ---- refa506 (Fin4) ---- *)

Definition refa506_op (x y : Fin4) : Fin4 :=
  match x, y with
  | F4_0, F4_0 => F4_3 | F4_0, F4_1 => F4_0 | F4_0, F4_2 => F4_3 | F4_0, F4_3 => F4_3
  | F4_1, F4_0 => F4_3 | F4_1, F4_1 => F4_3 | F4_1, F4_2 => F4_0 | F4_1, F4_3 => F4_3
  | F4_2, F4_0 => F4_3 | F4_2, F4_1 => F4_1 | F4_2, F4_2 => F4_3 | F4_2, F4_3 => F4_3
  | F4_3, F4_0 => F4_3 | F4_3, F4_1 => F4_0 | F4_3, F4_2 => F4_3 | F4_3, F4_3 => F4_3
  end.

#[local] Instance refa506_inst : Magma Fin4 := {| magma_op := refa506_op |}.

Lemma refa506_sat3494 : @Equation3494 Fin4 refa506_inst.
Proof. unfold Equation3494, magma_op, refa506_inst, refa506_op. intros x y z w. destruct x, y, z, w; reflexivity. Qed.

Lemma refa506_not3660 : ~ @Equation3660 Fin4 refa506_inst.
Proof. unfold Equation3660. intro H. specialize (H F4_2 F4_1). unfold magma_op, refa506_inst, refa506_op in H. discriminate H. Qed.

Lemma refa506_not3661 : ~ @Equation3661 Fin4 refa506_inst.
Proof. unfold Equation3661. intro H. specialize (H F4_1 F4_2). unfold magma_op, refa506_inst, refa506_op in H. discriminate H. Qed.

Lemma refa506_not3667 : ~ @Equation3667 Fin4 refa506_inst.
Proof. unfold Equation3667. intro H. specialize (H F4_1 F4_2). unfold magma_op, refa506_inst, refa506_op in H. discriminate H. Qed.

Lemma refa506_not3675 : ~ @Equation3675 Fin4 refa506_inst.
Proof. unfold Equation3675. intro H. specialize (H F4_2 F4_1). unfold magma_op, refa506_inst, refa506_op in H. discriminate H. Qed.

Lemma refa506_not3685 : ~ @Equation3685 Fin4 refa506_inst.
Proof. unfold Equation3685. intro H. specialize (H F4_2 F4_1). unfold magma_op, refa506_inst, refa506_op in H. discriminate H. Qed.

Lemma refa506_not3687 : ~ @Equation3687 Fin4 refa506_inst.
Proof. unfold Equation3687. intro H. specialize (H F4_1 F4_2). unfold magma_op, refa506_inst, refa506_op in H. discriminate H. Qed.

Lemma refa506_not4606 : ~ @Equation4606 Fin4 refa506_inst.
Proof. unfold Equation4606. intro H. specialize (H F4_1 F4_2). unfold magma_op, refa506_inst, refa506_op in H. discriminate H. Qed.

Lemma refa506_not4631 : ~ @Equation4631 Fin4 refa506_inst.
Proof. unfold Equation4631. intro H. specialize (H F4_2 F4_0 F4_1). unfold magma_op, refa506_inst, refa506_op in H. discriminate H. Qed.

(** ---- refa507 (Fin4) ---- *)

Definition refa507_op (x y : Fin4) : Fin4 :=
  match x, y with
  | F4_0, F4_0 => F4_3 | F4_0, F4_1 => F4_3 | F4_0, F4_2 => F4_1 | F4_0, F4_3 => F4_3
  | F4_1, F4_0 => F4_3 | F4_1, F4_1 => F4_3 | F4_1, F4_2 => F4_3 | F4_1, F4_3 => F4_3
  | F4_2, F4_0 => F4_2 | F4_2, F4_1 => F4_1 | F4_2, F4_2 => F4_3 | F4_2, F4_3 => F4_3
  | F4_3, F4_0 => F4_3 | F4_3, F4_1 => F4_3 | F4_3, F4_2 => F4_3 | F4_3, F4_3 => F4_3
  end.

#[local] Instance refa507_inst : Magma Fin4 := {| magma_op := refa507_op |}.

Lemma refa507_sat3913 : @Equation3913 Fin4 refa507_inst.
Proof. unfold Equation3913, magma_op, refa507_inst, refa507_op. intros x y z w u. destruct x, y, z, w, u; reflexivity. Qed.

Lemma refa507_not3667 : ~ @Equation3667 Fin4 refa507_inst.
Proof. unfold Equation3667. intro H. specialize (H F4_2 F4_0). unfold magma_op, refa507_inst, refa507_op in H. discriminate H. Qed.

Lemma refa507_not3675 : ~ @Equation3675 Fin4 refa507_inst.
Proof. unfold Equation3675. intro H. specialize (H F4_0 F4_2). unfold magma_op, refa507_inst, refa507_op in H. discriminate H. Qed.

(** ---- refa508 (Fin4) ---- *)

Definition refa508_op (x y : Fin4) : Fin4 :=
  match x, y with
  | F4_0, F4_0 => F4_0 | F4_0, F4_1 => F4_1 | F4_0, F4_2 => F4_2 | F4_0, F4_3 => F4_3
  | F4_1, F4_0 => F4_2 | F4_1, F4_1 => F4_1 | F4_1, F4_2 => F4_0 | F4_1, F4_3 => F4_3
  | F4_2, F4_0 => F4_3 | F4_2, F4_1 => F4_1 | F4_2, F4_2 => F4_2 | F4_2, F4_3 => F4_0
  | F4_3, F4_0 => F4_1 | F4_3, F4_1 => F4_0 | F4_3, F4_2 => F4_2 | F4_3, F4_3 => F4_3
  end.

#[local] Instance refa508_inst : Magma Fin4 := {| magma_op := refa508_op |}.

Lemma refa508_sat879 : @Equation879 Fin4 refa508_inst.
Proof. unfold Equation879, magma_op, refa508_inst, refa508_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa508_not872 : ~ @Equation872 Fin4 refa508_inst.
Proof. unfold Equation872. intro H. specialize (H F4_1 F4_3). unfold magma_op, refa508_inst, refa508_op in H. discriminate H. Qed.

Lemma refa508_not4073 : ~ @Equation4073 Fin4 refa508_inst.
Proof. unfold Equation4073. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa508_inst, refa508_op in H. discriminate H. Qed.

Lemma refa508_not4131 : ~ @Equation4131 Fin4 refa508_inst.
Proof. unfold Equation4131. intro H. specialize (H F4_1 F4_0). unfold magma_op, refa508_inst, refa508_op in H. discriminate H. Qed.

(** ---- refa509 (Fin4) ---- *)

Definition refa509_op (x y : Fin4) : Fin4 :=
  match x, y with
  | F4_0, F4_0 => F4_0 | F4_0, F4_1 => F4_0 | F4_0, F4_2 => F4_0 | F4_0, F4_3 => F4_1
  | F4_1, F4_0 => F4_1 | F4_1, F4_1 => F4_1 | F4_1, F4_2 => F4_0 | F4_1, F4_3 => F4_0
  | F4_2, F4_0 => F4_2 | F4_2, F4_1 => F4_3 | F4_2, F4_2 => F4_2 | F4_2, F4_3 => F4_2
  | F4_3, F4_0 => F4_3 | F4_3, F4_1 => F4_0 | F4_3, F4_2 => F4_0 | F4_3, F4_3 => F4_3
  end.

#[local] Instance refa509_inst : Magma Fin4 := {| magma_op := refa509_op |}.

Lemma refa509_sat1236 : @Equation1236 Fin4 refa509_inst.
Proof. unfold Equation1236, magma_op, refa509_inst, refa509_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa509_not829 : ~ @Equation829 Fin4 refa509_inst.
Proof. unfold Equation829. intro H. specialize (H F4_3 F4_1 F4_2). unfold magma_op, refa509_inst, refa509_op in H. discriminate H. Qed.

Lemma refa509_not4127 : ~ @Equation4127 Fin4 refa509_inst.
Proof. unfold Equation4127. intro H. specialize (H F4_2 F4_1). unfold magma_op, refa509_inst, refa509_op in H. discriminate H. Qed.

Lemma refa509_not4131 : ~ @Equation4131 Fin4 refa509_inst.
Proof. unfold Equation4131. intro H. specialize (H F4_2 F4_1). unfold magma_op, refa509_inst, refa509_op in H. discriminate H. Qed.

(** ---- refa51 (Fin2) ---- *)

Definition refa51_op (x y : Fin2) : Fin2 :=
  match x, y with
  | F2_0, F2_0 => F2_1 | F2_0, F2_1 => F2_0
  | F2_1, F2_0 => F2_0 | F2_1, F2_1 => F2_0
  end.

#[local] Instance refa51_inst : Magma Fin2 := {| magma_op := refa51_op |}.

Lemma refa51_sat43 : @Equation43 Fin2 refa51_inst.
Proof. unfold Equation43, magma_op, refa51_inst, refa51_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa51_sat1435 : @Equation1435 Fin2 refa51_inst.
Proof. unfold Equation1435, magma_op, refa51_inst, refa51_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa51_sat1638 : @Equation1638 Fin2 refa51_inst.
Proof. unfold Equation1638, magma_op, refa51_inst, refa51_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa51_sat1660 : @Equation1660 Fin2 refa51_inst.
Proof. unfold Equation1660, magma_op, refa51_inst, refa51_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa51_sat1668 : @Equation1668 Fin2 refa51_inst.
Proof. unfold Equation1668, magma_op, refa51_inst, refa51_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa51_sat1869 : @Equation1869 Fin2 refa51_inst.
Proof. unfold Equation1869, magma_op, refa51_inst, refa51_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa51_sat1931 : @Equation1931 Fin2 refa51_inst.
Proof. unfold Equation1931, magma_op, refa51_inst, refa51_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa51_sat2134 : @Equation2134 Fin2 refa51_inst.
Proof. unfold Equation2134, magma_op, refa51_inst, refa51_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa51_sat2162 : @Equation2162 Fin2 refa51_inst.
Proof. unfold Equation2162, magma_op, refa51_inst, refa51_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa51_sat2163 : @Equation2163 Fin2 refa51_inst.
Proof. unfold Equation2163, magma_op, refa51_inst, refa51_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa51_sat2165 : @Equation2165 Fin2 refa51_inst.
Proof. unfold Equation2165, magma_op, refa51_inst, refa51_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa51_sat3262 : @Equation3262 Fin2 refa51_inst.
Proof. unfold Equation3262, magma_op, refa51_inst, refa51_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa51_sat3308 : @Equation3308 Fin2 refa51_inst.
Proof. unfold Equation3308, magma_op, refa51_inst, refa51_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa51_sat3309 : @Equation3309 Fin2 refa51_inst.
Proof. unfold Equation3309, magma_op, refa51_inst, refa51_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa51_sat3352 : @Equation3352 Fin2 refa51_inst.
Proof. unfold Equation3352, magma_op, refa51_inst, refa51_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa51_sat3465 : @Equation3465 Fin2 refa51_inst.
Proof. unfold Equation3465, magma_op, refa51_inst, refa51_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa51_sat3518 : @Equation3518 Fin2 refa51_inst.
Proof. unfold Equation3518, magma_op, refa51_inst, refa51_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa51_sat3521 : @Equation3521 Fin2 refa51_inst.
Proof. unfold Equation3521, magma_op, refa51_inst, refa51_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa51_sat3546 : @Equation3546 Fin2 refa51_inst.
Proof. unfold Equation3546, magma_op, refa51_inst, refa51_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa51_sat3549 : @Equation3549 Fin2 refa51_inst.
Proof. unfold Equation3549, magma_op, refa51_inst, refa51_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa51_sat3556 : @Equation3556 Fin2 refa51_inst.
Proof. unfold Equation3556, magma_op, refa51_inst, refa51_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa51_sat3890 : @Equation3890 Fin2 refa51_inst.
Proof. unfold Equation3890, magma_op, refa51_inst, refa51_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa51_sat3917 : @Equation3917 Fin2 refa51_inst.
Proof. unfold Equation3917, magma_op, refa51_inst, refa51_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa51_sat3924 : @Equation3924 Fin2 refa51_inst.
Proof. unfold Equation3924, magma_op, refa51_inst, refa51_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa51_sat3927 : @Equation3927 Fin2 refa51_inst.
Proof. unfold Equation3927, magma_op, refa51_inst, refa51_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa51_sat3952 : @Equation3952 Fin2 refa51_inst.
Proof. unfold Equation3952, magma_op, refa51_inst, refa51_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa51_sat3962 : @Equation3962 Fin2 refa51_inst.
Proof. unfold Equation3962, magma_op, refa51_inst, refa51_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa51_sat4073 : @Equation4073 Fin2 refa51_inst.
Proof. unfold Equation4073, magma_op, refa51_inst, refa51_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa51_sat4093 : @Equation4093 Fin2 refa51_inst.
Proof. unfold Equation4093, magma_op, refa51_inst, refa51_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa51_sat4121 : @Equation4121 Fin2 refa51_inst.
Proof. unfold Equation4121, magma_op, refa51_inst, refa51_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa51_sat4158 : @Equation4158 Fin2 refa51_inst.
Proof. unfold Equation4158, magma_op, refa51_inst, refa51_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa51_sat4164 : @Equation4164 Fin2 refa51_inst.
Proof. unfold Equation4164, magma_op, refa51_inst, refa51_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa51_sat4284 : @Equation4284 Fin2 refa51_inst.
Proof. unfold Equation4284, magma_op, refa51_inst, refa51_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa51_sat4314 : @Equation4314 Fin2 refa51_inst.
Proof. unfold Equation4314, magma_op, refa51_inst, refa51_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa51_sat4389 : @Equation4389 Fin2 refa51_inst.
Proof. unfold Equation4389, magma_op, refa51_inst, refa51_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa51_sat4408 : @Equation4408 Fin2 refa51_inst.
Proof. unfold Equation4408, magma_op, refa51_inst, refa51_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa51_sat4445 : @Equation4445 Fin2 refa51_inst.
Proof. unfold Equation4445, magma_op, refa51_inst, refa51_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa51_sat4472 : @Equation4472 Fin2 refa51_inst.
Proof. unfold Equation4472, magma_op, refa51_inst, refa51_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa51_sat4479 : @Equation4479 Fin2 refa51_inst.
Proof. unfold Equation4479, magma_op, refa51_inst, refa51_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa51_sat4599 : @Equation4599 Fin2 refa51_inst.
Proof. unfold Equation4599, magma_op, refa51_inst, refa51_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa51_not47 : ~ @Equation47 Fin2 refa51_inst.
Proof. unfold Equation47. intro H. specialize (H F2_0). unfold magma_op, refa51_inst, refa51_op in H. discriminate H. Qed.

Lemma refa51_not99 : ~ @Equation99 Fin2 refa51_inst.
Proof. unfold Equation99. intro H. specialize (H F2_0). unfold magma_op, refa51_inst, refa51_op in H. discriminate H. Qed.

Lemma refa51_not159 : ~ @Equation159 Fin2 refa51_inst.
Proof. unfold Equation159. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa51_inst, refa51_op in H. discriminate H. Qed.

Lemma refa51_not167 : ~ @Equation167 Fin2 refa51_inst.
Proof. unfold Equation167. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa51_inst, refa51_op in H. discriminate H. Qed.

Lemma refa51_not203 : ~ @Equation203 Fin2 refa51_inst.
Proof. unfold Equation203. intro H. specialize (H F2_0). unfold magma_op, refa51_inst, refa51_op in H. discriminate H. Qed.

Lemma refa51_not255 : ~ @Equation255 Fin2 refa51_inst.
Proof. unfold Equation255. intro H. specialize (H F2_0). unfold magma_op, refa51_inst, refa51_op in H. discriminate H. Qed.

Lemma refa51_not307 : ~ @Equation307 Fin2 refa51_inst.
Proof. unfold Equation307. intro H. specialize (H F2_0). unfold magma_op, refa51_inst, refa51_op in H. discriminate H. Qed.

Lemma refa51_not359 : ~ @Equation359 Fin2 refa51_inst.
Proof. unfold Equation359. intro H. specialize (H F2_0). unfold magma_op, refa51_inst, refa51_op in H. discriminate H. Qed.

Lemma refa51_not411 : ~ @Equation411 Fin2 refa51_inst.
Proof. unfold Equation411. intro H. specialize (H F2_1). unfold magma_op, refa51_inst, refa51_op in H. discriminate H. Qed.

Lemma refa51_not614 : ~ @Equation614 Fin2 refa51_inst.
Proof. unfold Equation614. intro H. specialize (H F2_1). unfold magma_op, refa51_inst, refa51_op in H. discriminate H. Qed.

Lemma refa51_not817 : ~ @Equation817 Fin2 refa51_inst.
Proof. unfold Equation817. intro H. specialize (H F2_0). unfold magma_op, refa51_inst, refa51_op in H. discriminate H. Qed.

Lemma refa51_not1020 : ~ @Equation1020 Fin2 refa51_inst.
Proof. unfold Equation1020. intro H. specialize (H F2_1). unfold magma_op, refa51_inst, refa51_op in H. discriminate H. Qed.

Lemma refa51_not1223 : ~ @Equation1223 Fin2 refa51_inst.
Proof. unfold Equation1223. intro H. specialize (H F2_1). unfold magma_op, refa51_inst, refa51_op in H. discriminate H. Qed.

Lemma refa51_not1431 : ~ @Equation1431 Fin2 refa51_inst.
Proof. unfold Equation1431. intro H. specialize (H F2_1 F2_0). unfold magma_op, refa51_inst, refa51_op in H. discriminate H. Qed.

Lemma refa51_not1434 : ~ @Equation1434 Fin2 refa51_inst.
Proof. unfold Equation1434. intro H. specialize (H F2_1 F2_0). unfold magma_op, refa51_inst, refa51_op in H. discriminate H. Qed.

Lemma refa51_not1441 : ~ @Equation1441 Fin2 refa51_inst.
Proof. unfold Equation1441. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa51_inst, refa51_op in H. discriminate H. Qed.

Lemma refa51_not1451 : ~ @Equation1451 Fin2 refa51_inst.
Proof. unfold Equation1451. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa51_inst, refa51_op in H. discriminate H. Qed.

Lemma refa51_not1454 : ~ @Equation1454 Fin2 refa51_inst.
Proof. unfold Equation1454. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa51_inst, refa51_op in H. discriminate H. Qed.

Lemma refa51_not1478 : ~ @Equation1478 Fin2 refa51_inst.
Proof. unfold Equation1478. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa51_inst, refa51_op in H. discriminate H. Qed.

Lemma refa51_not1488 : ~ @Equation1488 Fin2 refa51_inst.
Proof. unfold Equation1488. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa51_inst, refa51_op in H. discriminate H. Qed.

Lemma refa51_not1515 : ~ @Equation1515 Fin2 refa51_inst.
Proof. unfold Equation1515. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa51_inst, refa51_op in H. discriminate H. Qed.

Lemma refa51_not1519 : ~ @Equation1519 Fin2 refa51_inst.
Proof. unfold Equation1519. intro H. specialize (H F2_1 F2_0). unfold magma_op, refa51_inst, refa51_op in H. discriminate H. Qed.

Lemma refa51_not1525 : ~ @Equation1525 Fin2 refa51_inst.
Proof. unfold Equation1525. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa51_inst, refa51_op in H. discriminate H. Qed.

Lemma refa51_not1632 : ~ @Equation1632 Fin2 refa51_inst.
Proof. unfold Equation1632. intro H. specialize (H F2_1 F2_0). unfold magma_op, refa51_inst, refa51_op in H. discriminate H. Qed.

Lemma refa51_not1635 : ~ @Equation1635 Fin2 refa51_inst.
Proof. unfold Equation1635. intro H. specialize (H F2_1 F2_0). unfold magma_op, refa51_inst, refa51_op in H. discriminate H. Qed.

Lemma refa51_not1644 : ~ @Equation1644 Fin2 refa51_inst.
Proof. unfold Equation1644. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa51_inst, refa51_op in H. discriminate H. Qed.

Lemma refa51_not1648 : ~ @Equation1648 Fin2 refa51_inst.
Proof. unfold Equation1648. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa51_inst, refa51_op in H. discriminate H. Qed.

Lemma refa51_not1655 : ~ @Equation1655 Fin2 refa51_inst.
Proof. unfold Equation1655. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa51_inst, refa51_op in H. discriminate H. Qed.

Lemma refa51_not1681 : ~ @Equation1681 Fin2 refa51_inst.
Proof. unfold Equation1681. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa51_inst, refa51_op in H. discriminate H. Qed.

Lemma refa51_not1721 : ~ @Equation1721 Fin2 refa51_inst.
Proof. unfold Equation1721. intro H. specialize (H F2_1 F2_0). unfold magma_op, refa51_inst, refa51_op in H. discriminate H. Qed.

Lemma refa51_not1722 : ~ @Equation1722 Fin2 refa51_inst.
Proof. unfold Equation1722. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa51_inst, refa51_op in H. discriminate H. Qed.

Lemma refa51_not1728 : ~ @Equation1728 Fin2 refa51_inst.
Proof. unfold Equation1728. intro H. specialize (H F2_1 F2_0). unfold magma_op, refa51_inst, refa51_op in H. discriminate H. Qed.

Lemma refa51_not1731 : ~ @Equation1731 Fin2 refa51_inst.
Proof. unfold Equation1731. intro H. specialize (H F2_1 F2_0). unfold magma_op, refa51_inst, refa51_op in H. discriminate H. Qed.

Lemma refa51_not1833 : ~ @Equation1833 Fin2 refa51_inst.
Proof. unfold Equation1833. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa51_inst, refa51_op in H. discriminate H. Qed.

Lemma refa51_not1834 : ~ @Equation1834 Fin2 refa51_inst.
Proof. unfold Equation1834. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa51_inst, refa51_op in H. discriminate H. Qed.

Lemma refa51_not1841 : ~ @Equation1841 Fin2 refa51_inst.
Proof. unfold Equation1841. intro H. specialize (H F2_1 F2_0). unfold magma_op, refa51_inst, refa51_op in H. discriminate H. Qed.

Lemma refa51_not1851 : ~ @Equation1851 Fin2 refa51_inst.
Proof. unfold Equation1851. intro H. specialize (H F2_1 F2_0). unfold magma_op, refa51_inst, refa51_op in H. discriminate H. Qed.

Lemma refa51_not1861 : ~ @Equation1861 Fin2 refa51_inst.
Proof. unfold Equation1861. intro H. specialize (H F2_1 F2_0). unfold magma_op, refa51_inst, refa51_op in H. discriminate H. Qed.

Lemma refa51_not1894 : ~ @Equation1894 Fin2 refa51_inst.
Proof. unfold Equation1894. intro H. specialize (H F2_1 F2_0). unfold magma_op, refa51_inst, refa51_op in H. discriminate H. Qed.

Lemma refa51_not1897 : ~ @Equation1897 Fin2 refa51_inst.
Proof. unfold Equation1897. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa51_inst, refa51_op in H. discriminate H. Qed.

Lemma refa51_not1921 : ~ @Equation1921 Fin2 refa51_inst.
Proof. unfold Equation1921. intro H. specialize (H F2_1 F2_0). unfold magma_op, refa51_inst, refa51_op in H. discriminate H. Qed.

Lemma refa51_not1924 : ~ @Equation1924 Fin2 refa51_inst.
Proof. unfold Equation1924. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa51_inst, refa51_op in H. discriminate H. Qed.

Lemma refa51_not1925 : ~ @Equation1925 Fin2 refa51_inst.
Proof. unfold Equation1925. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa51_inst, refa51_op in H. discriminate H. Qed.

Lemma refa51_not2036 : ~ @Equation2036 Fin2 refa51_inst.
Proof. unfold Equation2036. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa51_inst, refa51_op in H. discriminate H. Qed.

Lemma refa51_not2037 : ~ @Equation2037 Fin2 refa51_inst.
Proof. unfold Equation2037. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa51_inst, refa51_op in H. discriminate H. Qed.

Lemma refa51_not2038 : ~ @Equation2038 Fin2 refa51_inst.
Proof. unfold Equation2038. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa51_inst, refa51_op in H. discriminate H. Qed.

Lemma refa51_not2040 : ~ @Equation2040 Fin2 refa51_inst.
Proof. unfold Equation2040. intro H. specialize (H F2_1 F2_0). unfold magma_op, refa51_inst, refa51_op in H. discriminate H. Qed.

Lemma refa51_not2041 : ~ @Equation2041 Fin2 refa51_inst.
Proof. unfold Equation2041. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa51_inst, refa51_op in H. discriminate H. Qed.

Lemma refa51_not2043 : ~ @Equation2043 Fin2 refa51_inst.
Proof. unfold Equation2043. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa51_inst, refa51_op in H. discriminate H. Qed.

Lemma refa51_not2044 : ~ @Equation2044 Fin2 refa51_inst.
Proof. unfold Equation2044. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa51_inst, refa51_op in H. discriminate H. Qed.

Lemma refa51_not2060 : ~ @Equation2060 Fin2 refa51_inst.
Proof. unfold Equation2060. intro H. specialize (H F2_1 F2_0). unfold magma_op, refa51_inst, refa51_op in H. discriminate H. Qed.

Lemma refa51_not2063 : ~ @Equation2063 Fin2 refa51_inst.
Proof. unfold Equation2063. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa51_inst, refa51_op in H. discriminate H. Qed.

Lemma refa51_not2128 : ~ @Equation2128 Fin2 refa51_inst.
Proof. unfold Equation2128. intro H. specialize (H F2_1 F2_0). unfold magma_op, refa51_inst, refa51_op in H. discriminate H. Qed.

Lemma refa51_not2238 : ~ @Equation2238 Fin2 refa51_inst.
Proof. unfold Equation2238. intro H. specialize (H F2_1). unfold magma_op, refa51_inst, refa51_op in H. discriminate H. Qed.

Lemma refa51_not2441 : ~ @Equation2441 Fin2 refa51_inst.
Proof. unfold Equation2441. intro H. specialize (H F2_1). unfold magma_op, refa51_inst, refa51_op in H. discriminate H. Qed.

Lemma refa51_not2644 : ~ @Equation2644 Fin2 refa51_inst.
Proof. unfold Equation2644. intro H. specialize (H F2_0). unfold magma_op, refa51_inst, refa51_op in H. discriminate H. Qed.

Lemma refa51_not2847 : ~ @Equation2847 Fin2 refa51_inst.
Proof. unfold Equation2847. intro H. specialize (H F2_1). unfold magma_op, refa51_inst, refa51_op in H. discriminate H. Qed.

Lemma refa51_not3050 : ~ @Equation3050 Fin2 refa51_inst.
Proof. unfold Equation3050. intro H. specialize (H F2_1). unfold magma_op, refa51_inst, refa51_op in H. discriminate H. Qed.

Lemma refa51_not3255 : ~ @Equation3255 Fin2 refa51_inst.
Proof. unfold Equation3255. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa51_inst, refa51_op in H. discriminate H. Qed.

Lemma refa51_not3256 : ~ @Equation3256 Fin2 refa51_inst.
Proof. unfold Equation3256. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa51_inst, refa51_op in H. discriminate H. Qed.

Lemma refa51_not3268 : ~ @Equation3268 Fin2 refa51_inst.
Proof. unfold Equation3268. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa51_inst, refa51_op in H. discriminate H. Qed.

Lemma refa51_not3271 : ~ @Equation3271 Fin2 refa51_inst.
Proof. unfold Equation3271. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa51_inst, refa51_op in H. discriminate H. Qed.

Lemma refa51_not3272 : ~ @Equation3272 Fin2 refa51_inst.
Proof. unfold Equation3272. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa51_inst, refa51_op in H. discriminate H. Qed.

Lemma refa51_not3278 : ~ @Equation3278 Fin2 refa51_inst.
Proof. unfold Equation3278. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa51_inst, refa51_op in H. discriminate H. Qed.

Lemma refa51_not3279 : ~ @Equation3279 Fin2 refa51_inst.
Proof. unfold Equation3279. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa51_inst, refa51_op in H. discriminate H. Qed.

Lemma refa51_not3281 : ~ @Equation3281 Fin2 refa51_inst.
Proof. unfold Equation3281. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa51_inst, refa51_op in H. discriminate H. Qed.

Lemma refa51_not3315 : ~ @Equation3315 Fin2 refa51_inst.
Proof. unfold Equation3315. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa51_inst, refa51_op in H. discriminate H. Qed.

Lemma refa51_not3316 : ~ @Equation3316 Fin2 refa51_inst.
Proof. unfold Equation3316. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa51_inst, refa51_op in H. discriminate H. Qed.

Lemma refa51_not3318 : ~ @Equation3318 Fin2 refa51_inst.
Proof. unfold Equation3318. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa51_inst, refa51_op in H. discriminate H. Qed.

Lemma refa51_not3319 : ~ @Equation3319 Fin2 refa51_inst.
Proof. unfold Equation3319. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa51_inst, refa51_op in H. discriminate H. Qed.

Lemma refa51_not3342 : ~ @Equation3342 Fin2 refa51_inst.
Proof. unfold Equation3342. intro H. specialize (H F2_1 F2_0). unfold magma_op, refa51_inst, refa51_op in H. discriminate H. Qed.

Lemma refa51_not3343 : ~ @Equation3343 Fin2 refa51_inst.
Proof. unfold Equation3343. intro H. specialize (H F2_1 F2_0). unfold magma_op, refa51_inst, refa51_op in H. discriminate H. Qed.

Lemma refa51_not3346 : ~ @Equation3346 Fin2 refa51_inst.
Proof. unfold Equation3346. intro H. specialize (H F2_1 F2_0). unfold magma_op, refa51_inst, refa51_op in H. discriminate H. Qed.

Lemma refa51_not3458 : ~ @Equation3458 Fin2 refa51_inst.
Proof. unfold Equation3458. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa51_inst, refa51_op in H. discriminate H. Qed.

Lemma refa51_not3461 : ~ @Equation3461 Fin2 refa51_inst.
Proof. unfold Equation3461. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa51_inst, refa51_op in H. discriminate H. Qed.

Lemma refa51_not3464 : ~ @Equation3464 Fin2 refa51_inst.
Proof. unfold Equation3464. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa51_inst, refa51_op in H. discriminate H. Qed.

Lemma refa51_not3472 : ~ @Equation3472 Fin2 refa51_inst.
Proof. unfold Equation3472. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa51_inst, refa51_op in H. discriminate H. Qed.

Lemma refa51_not3474 : ~ @Equation3474 Fin2 refa51_inst.
Proof. unfold Equation3474. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa51_inst, refa51_op in H. discriminate H. Qed.

Lemma refa51_not3475 : ~ @Equation3475 Fin2 refa51_inst.
Proof. unfold Equation3475. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa51_inst, refa51_op in H. discriminate H. Qed.

Lemma refa51_not3481 : ~ @Equation3481 Fin2 refa51_inst.
Proof. unfold Equation3481. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa51_inst, refa51_op in H. discriminate H. Qed.

Lemma refa51_not3482 : ~ @Equation3482 Fin2 refa51_inst.
Proof. unfold Equation3482. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa51_inst, refa51_op in H. discriminate H. Qed.

Lemma refa51_not3484 : ~ @Equation3484 Fin2 refa51_inst.
Proof. unfold Equation3484. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa51_inst, refa51_op in H. discriminate H. Qed.

Lemma refa51_not3509 : ~ @Equation3509 Fin2 refa51_inst.
Proof. unfold Equation3509. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa51_inst, refa51_op in H. discriminate H. Qed.

Lemma refa51_not3512 : ~ @Equation3512 Fin2 refa51_inst.
Proof. unfold Equation3512. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa51_inst, refa51_op in H. discriminate H. Qed.

Lemma refa51_not3519 : ~ @Equation3519 Fin2 refa51_inst.
Proof. unfold Equation3519. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa51_inst, refa51_op in H. discriminate H. Qed.

Lemma refa51_not3522 : ~ @Equation3522 Fin2 refa51_inst.
Proof. unfold Equation3522. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa51_inst, refa51_op in H. discriminate H. Qed.

Lemma refa51_not3545 : ~ @Equation3545 Fin2 refa51_inst.
Proof. unfold Equation3545. intro H. specialize (H F2_1 F2_0). unfold magma_op, refa51_inst, refa51_op in H. discriminate H. Qed.

Lemma refa51_not3558 : ~ @Equation3558 Fin2 refa51_inst.
Proof. unfold Equation3558. intro H. specialize (H F2_1 F2_0). unfold magma_op, refa51_inst, refa51_op in H. discriminate H. Qed.

Lemma refa51_not3659 : ~ @Equation3659 Fin2 refa51_inst.
Proof. unfold Equation3659. intro H. specialize (H F2_0). unfold magma_op, refa51_inst, refa51_op in H. discriminate H. Qed.

Lemma refa51_not3864 : ~ @Equation3864 Fin2 refa51_inst.
Proof. unfold Equation3864. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa51_inst, refa51_op in H. discriminate H. Qed.

Lemma refa51_not3865 : ~ @Equation3865 Fin2 refa51_inst.
Proof. unfold Equation3865. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa51_inst, refa51_op in H. discriminate H. Qed.

Lemma refa51_not3867 : ~ @Equation3867 Fin2 refa51_inst.
Proof. unfold Equation3867. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa51_inst, refa51_op in H. discriminate H. Qed.

Lemma refa51_not3868 : ~ @Equation3868 Fin2 refa51_inst.
Proof. unfold Equation3868. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa51_inst, refa51_op in H. discriminate H. Qed.

Lemma refa51_not3870 : ~ @Equation3870 Fin2 refa51_inst.
Proof. unfold Equation3870. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa51_inst, refa51_op in H. discriminate H. Qed.

Lemma refa51_not3871 : ~ @Equation3871 Fin2 refa51_inst.
Proof. unfold Equation3871. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa51_inst, refa51_op in H. discriminate H. Qed.

Lemma refa51_not3878 : ~ @Equation3878 Fin2 refa51_inst.
Proof. unfold Equation3878. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa51_inst, refa51_op in H. discriminate H. Qed.

Lemma refa51_not3881 : ~ @Equation3881 Fin2 refa51_inst.
Proof. unfold Equation3881. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa51_inst, refa51_op in H. discriminate H. Qed.

Lemma refa51_not3888 : ~ @Equation3888 Fin2 refa51_inst.
Proof. unfold Equation3888. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa51_inst, refa51_op in H. discriminate H. Qed.

Lemma refa51_not3915 : ~ @Equation3915 Fin2 refa51_inst.
Proof. unfold Equation3915. intro H. specialize (H F2_1 F2_0). unfold magma_op, refa51_inst, refa51_op in H. discriminate H. Qed.

Lemma refa51_not3918 : ~ @Equation3918 Fin2 refa51_inst.
Proof. unfold Equation3918. intro H. specialize (H F2_1 F2_0). unfold magma_op, refa51_inst, refa51_op in H. discriminate H. Qed.

Lemma refa51_not3925 : ~ @Equation3925 Fin2 refa51_inst.
Proof. unfold Equation3925. intro H. specialize (H F2_1 F2_0). unfold magma_op, refa51_inst, refa51_op in H. discriminate H. Qed.

Lemma refa51_not3928 : ~ @Equation3928 Fin2 refa51_inst.
Proof. unfold Equation3928. intro H. specialize (H F2_1 F2_0). unfold magma_op, refa51_inst, refa51_op in H. discriminate H. Qed.

Lemma refa51_not3951 : ~ @Equation3951 Fin2 refa51_inst.
Proof. unfold Equation3951. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa51_inst, refa51_op in H. discriminate H. Qed.

Lemma refa51_not3964 : ~ @Equation3964 Fin2 refa51_inst.
Proof. unfold Equation3964. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa51_inst, refa51_op in H. discriminate H. Qed.

Lemma refa51_not4066 : ~ @Equation4066 Fin2 refa51_inst.
Proof. unfold Equation4066. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa51_inst, refa51_op in H. discriminate H. Qed.

Lemma refa51_not4068 : ~ @Equation4068 Fin2 refa51_inst.
Proof. unfold Equation4068. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa51_inst, refa51_op in H. discriminate H. Qed.

Lemma refa51_not4070 : ~ @Equation4070 Fin2 refa51_inst.
Proof. unfold Equation4070. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa51_inst, refa51_op in H. discriminate H. Qed.

Lemma refa51_not4071 : ~ @Equation4071 Fin2 refa51_inst.
Proof. unfold Equation4071. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa51_inst, refa51_op in H. discriminate H. Qed.

Lemma refa51_not4074 : ~ @Equation4074 Fin2 refa51_inst.
Proof. unfold Equation4074. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa51_inst, refa51_op in H. discriminate H. Qed.

Lemma refa51_not4084 : ~ @Equation4084 Fin2 refa51_inst.
Proof. unfold Equation4084. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa51_inst, refa51_op in H. discriminate H. Qed.

Lemma refa51_not4090 : ~ @Equation4090 Fin2 refa51_inst.
Proof. unfold Equation4090. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa51_inst, refa51_op in H. discriminate H. Qed.

Lemma refa51_not4091 : ~ @Equation4091 Fin2 refa51_inst.
Proof. unfold Equation4091. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa51_inst, refa51_op in H. discriminate H. Qed.

Lemma refa51_not4118 : ~ @Equation4118 Fin2 refa51_inst.
Proof. unfold Equation4118. intro H. specialize (H F2_1 F2_0). unfold magma_op, refa51_inst, refa51_op in H. discriminate H. Qed.

Lemma refa51_not4120 : ~ @Equation4120 Fin2 refa51_inst.
Proof. unfold Equation4120. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa51_inst, refa51_op in H. discriminate H. Qed.

Lemma refa51_not4128 : ~ @Equation4128 Fin2 refa51_inst.
Proof. unfold Equation4128. intro H. specialize (H F2_1 F2_0). unfold magma_op, refa51_inst, refa51_op in H. discriminate H. Qed.

Lemma refa51_not4130 : ~ @Equation4130 Fin2 refa51_inst.
Proof. unfold Equation4130. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa51_inst, refa51_op in H. discriminate H. Qed.

Lemma refa51_not4155 : ~ @Equation4155 Fin2 refa51_inst.
Proof. unfold Equation4155. intro H. specialize (H F2_1 F2_0). unfold magma_op, refa51_inst, refa51_op in H. discriminate H. Qed.

Lemma refa51_not4165 : ~ @Equation4165 Fin2 refa51_inst.
Proof. unfold Equation4165. intro H. specialize (H F2_1 F2_0). unfold magma_op, refa51_inst, refa51_op in H. discriminate H. Qed.

Lemma refa51_not4167 : ~ @Equation4167 Fin2 refa51_inst.
Proof. unfold Equation4167. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa51_inst, refa51_op in H. discriminate H. Qed.

Lemma refa51_not4268 : ~ @Equation4268 Fin2 refa51_inst.
Proof. unfold Equation4268. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa51_inst, refa51_op in H. discriminate H. Qed.

Lemma refa51_not4269 : ~ @Equation4269 Fin2 refa51_inst.
Proof. unfold Equation4269. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa51_inst, refa51_op in H. discriminate H. Qed.

Lemma refa51_not4270 : ~ @Equation4270 Fin2 refa51_inst.
Proof. unfold Equation4270. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa51_inst, refa51_op in H. discriminate H. Qed.

Lemma refa51_not4272 : ~ @Equation4272 Fin2 refa51_inst.
Proof. unfold Equation4272. intro H. specialize (H F2_1 F2_0). unfold magma_op, refa51_inst, refa51_op in H. discriminate H. Qed.

Lemma refa51_not4273 : ~ @Equation4273 Fin2 refa51_inst.
Proof. unfold Equation4273. intro H. specialize (H F2_1 F2_0). unfold magma_op, refa51_inst, refa51_op in H. discriminate H. Qed.

Lemma refa51_not4275 : ~ @Equation4275 Fin2 refa51_inst.
Proof. unfold Equation4275. intro H. specialize (H F2_1 F2_0). unfold magma_op, refa51_inst, refa51_op in H. discriminate H. Qed.

Lemma refa51_not4290 : ~ @Equation4290 Fin2 refa51_inst.
Proof. unfold Equation4290. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa51_inst, refa51_op in H. discriminate H. Qed.

Lemma refa51_not4291 : ~ @Equation4291 Fin2 refa51_inst.
Proof. unfold Equation4291. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa51_inst, refa51_op in H. discriminate H. Qed.

Lemma refa51_not4293 : ~ @Equation4293 Fin2 refa51_inst.
Proof. unfold Equation4293. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa51_inst, refa51_op in H. discriminate H. Qed.

Lemma refa51_not4320 : ~ @Equation4320 Fin2 refa51_inst.
Proof. unfold Equation4320. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa51_inst, refa51_op in H. discriminate H. Qed.

Lemma refa51_not4321 : ~ @Equation4321 Fin2 refa51_inst.
Proof. unfold Equation4321. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa51_inst, refa51_op in H. discriminate H. Qed.

Lemma refa51_not4343 : ~ @Equation4343 Fin2 refa51_inst.
Proof. unfold Equation4343. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa51_inst, refa51_op in H. discriminate H. Qed.

Lemma refa51_not4396 : ~ @Equation4396 Fin2 refa51_inst.
Proof. unfold Equation4396. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa51_inst, refa51_op in H. discriminate H. Qed.

Lemma refa51_not4399 : ~ @Equation4399 Fin2 refa51_inst.
Proof. unfold Equation4399. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa51_inst, refa51_op in H. discriminate H. Qed.

Lemma refa51_not4406 : ~ @Equation4406 Fin2 refa51_inst.
Proof. unfold Equation4406. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa51_inst, refa51_op in H. discriminate H. Qed.

Lemma refa51_not4433 : ~ @Equation4433 Fin2 refa51_inst.
Proof. unfold Equation4433. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa51_inst, refa51_op in H. discriminate H. Qed.

Lemma refa51_not4436 : ~ @Equation4436 Fin2 refa51_inst.
Proof. unfold Equation4436. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa51_inst, refa51_op in H. discriminate H. Qed.

Lemma refa51_not4443 : ~ @Equation4443 Fin2 refa51_inst.
Proof. unfold Equation4443. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa51_inst, refa51_op in H. discriminate H. Qed.

Lemma refa51_not4470 : ~ @Equation4470 Fin2 refa51_inst.
Proof. unfold Equation4470. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa51_inst, refa51_op in H. discriminate H. Qed.

Lemma refa51_not4473 : ~ @Equation4473 Fin2 refa51_inst.
Proof. unfold Equation4473. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa51_inst, refa51_op in H. discriminate H. Qed.

Lemma refa51_not4480 : ~ @Equation4480 Fin2 refa51_inst.
Proof. unfold Equation4480. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa51_inst, refa51_op in H. discriminate H. Qed.

Lemma refa51_not4583 : ~ @Equation4583 Fin2 refa51_inst.
Proof. unfold Equation4583. intro H. specialize (H F2_1 F2_0). unfold magma_op, refa51_inst, refa51_op in H. discriminate H. Qed.

Lemma refa51_not4584 : ~ @Equation4584 Fin2 refa51_inst.
Proof. unfold Equation4584. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa51_inst, refa51_op in H. discriminate H. Qed.

Lemma refa51_not4585 : ~ @Equation4585 Fin2 refa51_inst.
Proof. unfold Equation4585. intro H. specialize (H F2_1 F2_0). unfold magma_op, refa51_inst, refa51_op in H. discriminate H. Qed.

Lemma refa51_not4587 : ~ @Equation4587 Fin2 refa51_inst.
Proof. unfold Equation4587. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa51_inst, refa51_op in H. discriminate H. Qed.

Lemma refa51_not4588 : ~ @Equation4588 Fin2 refa51_inst.
Proof. unfold Equation4588. intro H. specialize (H F2_1 F2_0). unfold magma_op, refa51_inst, refa51_op in H. discriminate H. Qed.

Lemma refa51_not4590 : ~ @Equation4590 Fin2 refa51_inst.
Proof. unfold Equation4590. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa51_inst, refa51_op in H. discriminate H. Qed.

Lemma refa51_not4598 : ~ @Equation4598 Fin2 refa51_inst.
Proof. unfold Equation4598. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa51_inst, refa51_op in H. discriminate H. Qed.

Lemma refa51_not4605 : ~ @Equation4605 Fin2 refa51_inst.
Proof. unfold Equation4605. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa51_inst, refa51_op in H. discriminate H. Qed.

Lemma refa51_not4608 : ~ @Equation4608 Fin2 refa51_inst.
Proof. unfold Equation4608. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa51_inst, refa51_op in H. discriminate H. Qed.

Lemma refa51_not4629 : ~ @Equation4629 Fin2 refa51_inst.
Proof. unfold Equation4629. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa51_inst, refa51_op in H. discriminate H. Qed.

Lemma refa51_not4636 : ~ @Equation4636 Fin2 refa51_inst.
Proof. unfold Equation4636. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa51_inst, refa51_op in H. discriminate H. Qed.

Lemma refa51_not4658 : ~ @Equation4658 Fin2 refa51_inst.
Proof. unfold Equation4658. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa51_inst, refa51_op in H. discriminate H. Qed.

(** ---- refa510 (Fin4) ---- *)

Definition refa510_op (x y : Fin4) : Fin4 :=
  match x, y with
  | F4_0, F4_0 => F4_0 | F4_0, F4_1 => F4_3 | F4_0, F4_2 => F4_0 | F4_0, F4_3 => F4_3
  | F4_1, F4_0 => F4_2 | F4_1, F4_1 => F4_2 | F4_1, F4_2 => F4_0 | F4_1, F4_3 => F4_0
  | F4_2, F4_0 => F4_0 | F4_2, F4_1 => F4_2 | F4_2, F4_2 => F4_0 | F4_2, F4_3 => F4_3
  | F4_3, F4_0 => F4_0 | F4_3, F4_1 => F4_2 | F4_3, F4_2 => F4_2 | F4_3, F4_3 => F4_0
  end.

#[local] Instance refa510_inst : Magma Fin4 := {| magma_op := refa510_op |}.

Lemma refa510_sat3265 : @Equation3265 Fin4 refa510_inst.
Proof. unfold Equation3265, magma_op, refa510_inst, refa510_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa510_not3258 : ~ @Equation3258 Fin4 refa510_inst.
Proof. unfold Equation3258. intro H. specialize (H F4_1 F4_3). unfold magma_op, refa510_inst, refa510_op in H. discriminate H. Qed.

Lemma refa510_not3261 : ~ @Equation3261 Fin4 refa510_inst.
Proof. unfold Equation3261. intro H. specialize (H F4_1 F4_0). unfold magma_op, refa510_inst, refa510_op in H. discriminate H. Qed.

(** ---- refa511 (Fin4) ---- *)

Definition refa511_op (x y : Fin4) : Fin4 :=
  match x, y with
  | F4_0, F4_0 => F4_3 | F4_0, F4_1 => F4_2 | F4_0, F4_2 => F4_0 | F4_0, F4_3 => F4_1
  | F4_1, F4_0 => F4_2 | F4_1, F4_1 => F4_3 | F4_1, F4_2 => F4_1 | F4_1, F4_3 => F4_0
  | F4_2, F4_0 => F4_2 | F4_2, F4_1 => F4_3 | F4_2, F4_2 => F4_1 | F4_2, F4_3 => F4_0
  | F4_3, F4_0 => F4_3 | F4_3, F4_1 => F4_2 | F4_3, F4_2 => F4_0 | F4_3, F4_3 => F4_1
  end.

#[local] Instance refa511_inst : Magma Fin4 := {| magma_op := refa511_op |}.

Lemma refa511_sat528 : @Equation528 Fin4 refa511_inst.
Proof. unfold Equation528, magma_op, refa511_inst, refa511_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa511_sat1171 : @Equation1171 Fin4 refa511_inst.
Proof. unfold Equation1171, magma_op, refa511_inst, refa511_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa511_sat1184 : @Equation1184 Fin4 refa511_inst.
Proof. unfold Equation1184, magma_op, refa511_inst, refa511_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa511_sat1996 : @Equation1996 Fin4 refa511_inst.
Proof. unfold Equation1996, magma_op, refa511_inst, refa511_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa511_not43 : ~ @Equation43 Fin4 refa511_inst.
Proof. unfold Equation43. intro H. specialize (H F4_0 F4_2). unfold magma_op, refa511_inst, refa511_op in H. discriminate H. Qed.

Lemma refa511_not417 : ~ @Equation417 Fin4 refa511_inst.
Proof. unfold Equation417. intro H. specialize (H F4_0 F4_2). unfold magma_op, refa511_inst, refa511_op in H. discriminate H. Qed.

Lemma refa511_not427 : ~ @Equation427 Fin4 refa511_inst.
Proof. unfold Equation427. intro H. specialize (H F4_0 F4_2). unfold magma_op, refa511_inst, refa511_op in H. discriminate H. Qed.

Lemma refa511_not440 : ~ @Equation440 Fin4 refa511_inst.
Proof. unfold Equation440. intro H. specialize (H F4_0 F4_2). unfold magma_op, refa511_inst, refa511_op in H. discriminate H. Qed.

Lemma refa511_not477 : ~ @Equation477 Fin4 refa511_inst.
Proof. unfold Equation477. intro H. specialize (H F4_0 F4_2). unfold magma_op, refa511_inst, refa511_op in H. discriminate H. Qed.

Lemma refa511_not504 : ~ @Equation504 Fin4 refa511_inst.
Proof. unfold Equation504. intro H. specialize (H F4_0 F4_2). unfold magma_op, refa511_inst, refa511_op in H. discriminate H. Qed.

Lemma refa511_not511 : ~ @Equation511 Fin4 refa511_inst.
Proof. unfold Equation511. intro H. specialize (H F4_0 F4_2). unfold magma_op, refa511_inst, refa511_op in H. discriminate H. Qed.

Lemma refa511_not614 : ~ @Equation614 Fin4 refa511_inst.
Proof. unfold Equation614. intro H. specialize (H F4_0). unfold magma_op, refa511_inst, refa511_op in H. discriminate H. Qed.

Lemma refa511_not817 : ~ @Equation817 Fin4 refa511_inst.
Proof. unfold Equation817. intro H. specialize (H F4_0). unfold magma_op, refa511_inst, refa511_op in H. discriminate H. Qed.

Lemma refa511_not1023 : ~ @Equation1023 Fin4 refa511_inst.
Proof. unfold Equation1023. intro H. specialize (H F4_0 F4_2). unfold magma_op, refa511_inst, refa511_op in H. discriminate H. Qed.

Lemma refa511_not1026 : ~ @Equation1026 Fin4 refa511_inst.
Proof. unfold Equation1026. intro H. specialize (H F4_0 F4_2). unfold magma_op, refa511_inst, refa511_op in H. discriminate H. Qed.

Lemma refa511_not1036 : ~ @Equation1036 Fin4 refa511_inst.
Proof. unfold Equation1036. intro H. specialize (H F4_0 F4_2). unfold magma_op, refa511_inst, refa511_op in H. discriminate H. Qed.

Lemma refa511_not1049 : ~ @Equation1049 Fin4 refa511_inst.
Proof. unfold Equation1049. intro H. specialize (H F4_0 F4_2). unfold magma_op, refa511_inst, refa511_op in H. discriminate H. Qed.

Lemma refa511_not1086 : ~ @Equation1086 Fin4 refa511_inst.
Proof. unfold Equation1086. intro H. specialize (H F4_0 F4_2). unfold magma_op, refa511_inst, refa511_op in H. discriminate H. Qed.

Lemma refa511_not1113 : ~ @Equation1113 Fin4 refa511_inst.
Proof. unfold Equation1113. intro H. specialize (H F4_0 F4_2). unfold magma_op, refa511_inst, refa511_op in H. discriminate H. Qed.

Lemma refa511_not1223 : ~ @Equation1223 Fin4 refa511_inst.
Proof. unfold Equation1223. intro H. specialize (H F4_0). unfold magma_op, refa511_inst, refa511_op in H. discriminate H. Qed.

Lemma refa511_not1426 : ~ @Equation1426 Fin4 refa511_inst.
Proof. unfold Equation1426. intro H. specialize (H F4_0). unfold magma_op, refa511_inst, refa511_op in H. discriminate H. Qed.

Lemma refa511_not1629 : ~ @Equation1629 Fin4 refa511_inst.
Proof. unfold Equation1629. intro H. specialize (H F4_0). unfold magma_op, refa511_inst, refa511_op in H. discriminate H. Qed.

Lemma refa511_not1838 : ~ @Equation1838 Fin4 refa511_inst.
Proof. unfold Equation1838. intro H. specialize (H F4_0 F4_2). unfold magma_op, refa511_inst, refa511_op in H. discriminate H. Qed.

Lemma refa511_not1848 : ~ @Equation1848 Fin4 refa511_inst.
Proof. unfold Equation1848. intro H. specialize (H F4_0 F4_2). unfold magma_op, refa511_inst, refa511_op in H. discriminate H. Qed.

Lemma refa511_not1861 : ~ @Equation1861 Fin4 refa511_inst.
Proof. unfold Equation1861. intro H. specialize (H F4_0 F4_2). unfold magma_op, refa511_inst, refa511_op in H. discriminate H. Qed.

Lemma refa511_not1885 : ~ @Equation1885 Fin4 refa511_inst.
Proof. unfold Equation1885. intro H. specialize (H F4_0 F4_2). unfold magma_op, refa511_inst, refa511_op in H. discriminate H. Qed.

Lemma refa511_not1925 : ~ @Equation1925 Fin4 refa511_inst.
Proof. unfold Equation1925. intro H. specialize (H F4_0 F4_2). unfold magma_op, refa511_inst, refa511_op in H. discriminate H. Qed.

Lemma refa511_not2035 : ~ @Equation2035 Fin4 refa511_inst.
Proof. unfold Equation2035. intro H. specialize (H F4_0). unfold magma_op, refa511_inst, refa511_op in H. discriminate H. Qed.

Lemma refa511_not2238 : ~ @Equation2238 Fin4 refa511_inst.
Proof. unfold Equation2238. intro H. specialize (H F4_0). unfold magma_op, refa511_inst, refa511_op in H. discriminate H. Qed.

Lemma refa511_not2441 : ~ @Equation2441 Fin4 refa511_inst.
Proof. unfold Equation2441. intro H. specialize (H F4_0). unfold magma_op, refa511_inst, refa511_op in H. discriminate H. Qed.

Lemma refa511_not2644 : ~ @Equation2644 Fin4 refa511_inst.
Proof. unfold Equation2644. intro H. specialize (H F4_0). unfold magma_op, refa511_inst, refa511_op in H. discriminate H. Qed.

Lemma refa511_not2847 : ~ @Equation2847 Fin4 refa511_inst.
Proof. unfold Equation2847. intro H. specialize (H F4_0). unfold magma_op, refa511_inst, refa511_op in H. discriminate H. Qed.

Lemma refa511_not3050 : ~ @Equation3050 Fin4 refa511_inst.
Proof. unfold Equation3050. intro H. specialize (H F4_0). unfold magma_op, refa511_inst, refa511_op in H. discriminate H. Qed.

Lemma refa511_not3253 : ~ @Equation3253 Fin4 refa511_inst.
Proof. unfold Equation3253. intro H. specialize (H F4_0). unfold magma_op, refa511_inst, refa511_op in H. discriminate H. Qed.

Lemma refa511_not3456 : ~ @Equation3456 Fin4 refa511_inst.
Proof. unfold Equation3456. intro H. specialize (H F4_0). unfold magma_op, refa511_inst, refa511_op in H. discriminate H. Qed.

Lemma refa511_not3659 : ~ @Equation3659 Fin4 refa511_inst.
Proof. unfold Equation3659. intro H. specialize (H F4_0). unfold magma_op, refa511_inst, refa511_op in H. discriminate H. Qed.

Lemma refa511_not3862 : ~ @Equation3862 Fin4 refa511_inst.
Proof. unfold Equation3862. intro H. specialize (H F4_0). unfold magma_op, refa511_inst, refa511_op in H. discriminate H. Qed.

Lemma refa511_not4590 : ~ @Equation4590 Fin4 refa511_inst.
Proof. unfold Equation4590. intro H. specialize (H F4_0 F4_2). unfold magma_op, refa511_inst, refa511_op in H. discriminate H. Qed.

(** ---- refa512 (Fin4) ---- *)

Definition refa512_op (x y : Fin4) : Fin4 :=
  match x, y with
  | F4_0, F4_0 => F4_2 | F4_0, F4_1 => F4_1 | F4_0, F4_2 => F4_1 | F4_0, F4_3 => F4_3
  | F4_1, F4_0 => F4_3 | F4_1, F4_1 => F4_3 | F4_1, F4_2 => F4_3 | F4_1, F4_3 => F4_1
  | F4_2, F4_0 => F4_0 | F4_2, F4_1 => F4_1 | F4_2, F4_2 => F4_2 | F4_2, F4_3 => F4_3
  | F4_3, F4_0 => F4_0 | F4_3, F4_1 => F4_1 | F4_3, F4_2 => F4_2 | F4_3, F4_3 => F4_3
  end.

#[local] Instance refa512_inst : Magma Fin4 := {| magma_op := refa512_op |}.

Lemma refa512_sat2964 : @Equation2964 Fin4 refa512_inst.
Proof. unfold Equation2964, magma_op, refa512_inst, refa512_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa512_not2238 : ~ @Equation2238 Fin4 refa512_inst.
Proof. unfold Equation2238. intro H. specialize (H F4_0). unfold magma_op, refa512_inst, refa512_op in H. discriminate H. Qed.

Lemma refa512_not2459 : ~ @Equation2459 Fin4 refa512_inst.
Proof. unfold Equation2459. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa512_inst, refa512_op in H. discriminate H. Qed.

Lemma refa512_not2503 : ~ @Equation2503 Fin4 refa512_inst.
Proof. unfold Equation2503. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa512_inst, refa512_op in H. discriminate H. Qed.

Lemma refa512_not2872 : ~ @Equation2872 Fin4 refa512_inst.
Proof. unfold Equation2872. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa512_inst, refa512_op in H. discriminate H. Qed.

Lemma refa512_not2902 : ~ @Equation2902 Fin4 refa512_inst.
Proof. unfold Equation2902. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa512_inst, refa512_op in H. discriminate H. Qed.

Lemma refa512_not2909 : ~ @Equation2909 Fin4 refa512_inst.
Proof. unfold Equation2909. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa512_inst, refa512_op in H. discriminate H. Qed.

Lemma refa512_not3075 : ~ @Equation3075 Fin4 refa512_inst.
Proof. unfold Equation3075. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa512_inst, refa512_op in H. discriminate H. Qed.

Lemma refa512_not3112 : ~ @Equation3112 Fin4 refa512_inst.
Proof. unfold Equation3112. intro H. specialize (H F4_0 F4_3). unfold magma_op, refa512_inst, refa512_op in H. discriminate H. Qed.

Lemma refa512_not3253 : ~ @Equation3253 Fin4 refa512_inst.
Proof. unfold Equation3253. intro H. specialize (H F4_0). unfold magma_op, refa512_inst, refa512_op in H. discriminate H. Qed.

Lemma refa512_not3677 : ~ @Equation3677 Fin4 refa512_inst.
Proof. unfold Equation3677. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa512_inst, refa512_op in H. discriminate H. Qed.

Lemma refa512_not3862 : ~ @Equation3862 Fin4 refa512_inst.
Proof. unfold Equation3862. intro H. specialize (H F4_0). unfold magma_op, refa512_inst, refa512_op in H. discriminate H. Qed.

(** ---- refa513 (Fin4) ---- *)

Definition refa513_op (x y : Fin4) : Fin4 :=
  match x, y with
  | F4_0, F4_0 => F4_0 | F4_0, F4_1 => F4_1 | F4_0, F4_2 => F4_1 | F4_0, F4_3 => F4_3
  | F4_1, F4_0 => F4_3 | F4_1, F4_1 => F4_3 | F4_1, F4_2 => F4_1 | F4_1, F4_3 => F4_3
  | F4_2, F4_0 => F4_3 | F4_2, F4_1 => F4_0 | F4_2, F4_2 => F4_0 | F4_2, F4_3 => F4_3
  | F4_3, F4_0 => F4_0 | F4_3, F4_1 => F4_1 | F4_3, F4_2 => F4_2 | F4_3, F4_3 => F4_3
  end.

#[local] Instance refa513_inst : Magma Fin4 := {| magma_op := refa513_op |}.

Lemma refa513_sat2277 : @Equation2277 Fin4 refa513_inst.
Proof. unfold Equation2277, magma_op, refa513_inst, refa513_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa513_sat2281 : @Equation2281 Fin4 refa513_inst.
Proof. unfold Equation2281, magma_op, refa513_inst, refa513_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa513_sat2314 : @Equation2314 Fin4 refa513_inst.
Proof. unfold Equation2314, magma_op, refa513_inst, refa513_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa513_sat2318 : @Equation2318 Fin4 refa513_inst.
Proof. unfold Equation2318, magma_op, refa513_inst, refa513_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa513_not2441 : ~ @Equation2441 Fin4 refa513_inst.
Proof. unfold Equation2441. intro H. specialize (H F4_2). unfold magma_op, refa513_inst, refa513_op in H. discriminate H. Qed.

Lemma refa513_not3749 : ~ @Equation3749 Fin4 refa513_inst.
Proof. unfold Equation3749. intro H. specialize (H F4_2 F4_1). unfold magma_op, refa513_inst, refa513_op in H. discriminate H. Qed.

(** ---- refa514 (Fin4) ---- *)

Definition refa514_op (x y : Fin4) : Fin4 :=
  match x, y with
  | F4_0, F4_0 => F4_3 | F4_0, F4_1 => F4_0 | F4_0, F4_2 => F4_1 | F4_0, F4_3 => F4_3
  | F4_1, F4_0 => F4_3 | F4_1, F4_1 => F4_3 | F4_1, F4_2 => F4_1 | F4_1, F4_3 => F4_3
  | F4_2, F4_0 => F4_0 | F4_2, F4_1 => F4_3 | F4_2, F4_2 => F4_3 | F4_2, F4_3 => F4_0
  | F4_3, F4_0 => F4_0 | F4_3, F4_1 => F4_1 | F4_3, F4_2 => F4_2 | F4_3, F4_3 => F4_3
  end.

#[local] Instance refa514_inst : Magma Fin4 := {| magma_op := refa514_op |}.

Lemma refa514_sat2517 : @Equation2517 Fin4 refa514_inst.
Proof. unfold Equation2517, magma_op, refa514_inst, refa514_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa514_not2238 : ~ @Equation2238 Fin4 refa514_inst.
Proof. unfold Equation2238. intro H. specialize (H F4_2). unfold magma_op, refa514_inst, refa514_op in H. discriminate H. Qed.

Lemma refa514_not2530 : ~ @Equation2530 Fin4 refa514_inst.
Proof. unfold Equation2530. intro H. specialize (H F4_0 F4_2). unfold magma_op, refa514_inst, refa514_op in H. discriminate H. Qed.

(** ---- refa515 (Fin4) ---- *)

Definition refa515_op (x y : Fin4) : Fin4 :=
  match x, y with
  | F4_0, F4_0 => F4_0 | F4_0, F4_1 => F4_2 | F4_0, F4_2 => F4_2 | F4_0, F4_3 => F4_3
  | F4_1, F4_0 => F4_2 | F4_1, F4_1 => F4_1 | F4_1, F4_2 => F4_2 | F4_1, F4_3 => F4_3
  | F4_2, F4_0 => F4_0 | F4_2, F4_1 => F4_1 | F4_2, F4_2 => F4_2 | F4_2, F4_3 => F4_0
  | F4_3, F4_0 => F4_0 | F4_3, F4_1 => F4_1 | F4_3, F4_2 => F4_1 | F4_3, F4_3 => F4_3
  end.

#[local] Instance refa515_inst : Magma Fin4 := {| magma_op := refa515_op |}.

Lemma refa515_sat2716 : @Equation2716 Fin4 refa515_inst.
Proof. unfold Equation2716, magma_op, refa515_inst, refa515_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa515_sat3108 : @Equation3108 Fin4 refa515_inst.
Proof. unfold Equation3108, magma_op, refa515_inst, refa515_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa515_not1041 : ~ @Equation1041 Fin4 refa515_inst.
Proof. unfold Equation1041. intro H. specialize (H F4_0 F4_3 F4_1). unfold magma_op, refa515_inst, refa515_op in H. discriminate H. Qed.

Lemma refa515_not1055 : ~ @Equation1055 Fin4 refa515_inst.
Proof. unfold Equation1055. intro H. specialize (H F4_0 F4_3 F4_1). unfold magma_op, refa515_inst, refa515_op in H. discriminate H. Qed.

Lemma refa515_not1958 : ~ @Equation1958 Fin4 refa515_inst.
Proof. unfold Equation1958. intro H. specialize (H F4_0 F4_3 F4_1). unfold magma_op, refa515_inst, refa515_op in H. discriminate H. Qed.

Lemma refa515_not2296 : ~ @Equation2296 Fin4 refa515_inst.
Proof. unfold Equation2296. intro H. specialize (H F4_0 F4_3 F4_1). unfold magma_op, refa515_inst, refa515_op in H. discriminate H. Qed.

Lemma refa515_not2310 : ~ @Equation2310 Fin4 refa515_inst.
Proof. unfold Equation2310. intro H. specialize (H F4_0 F4_3 F4_1). unfold magma_op, refa515_inst, refa515_op in H. discriminate H. Qed.

Lemma refa515_not2314 : ~ @Equation2314 Fin4 refa515_inst.
Proof. unfold Equation2314. intro H. specialize (H F4_3 F4_0 F4_1). unfold magma_op, refa515_inst, refa515_op in H. discriminate H. Qed.

Lemma refa515_not2318 : ~ @Equation2318 Fin4 refa515_inst.
Proof. unfold Equation2318. intro H. specialize (H F4_0 F4_3 F4_1). unfold magma_op, refa515_inst, refa515_op in H. discriminate H. Qed.

Lemma refa515_not2347 : ~ @Equation2347 Fin4 refa515_inst.
Proof. unfold Equation2347. intro H. specialize (H F4_0 F4_3 F4_1). unfold magma_op, refa515_inst, refa515_op in H. discriminate H. Qed.

Lemma refa515_not2364 : ~ @Equation2364 Fin4 refa515_inst.
Proof. unfold Equation2364. intro H. specialize (H F4_0 F4_3 F4_1). unfold magma_op, refa515_inst, refa515_op in H. discriminate H. Qed.

Lemma refa515_not2368 : ~ @Equation2368 Fin4 refa515_inst.
Proof. unfold Equation2368. intro H. specialize (H F4_0 F4_1 F4_3). unfold magma_op, refa515_inst, refa515_op in H. discriminate H. Qed.

Lemma refa515_not2372 : ~ @Equation2372 Fin4 refa515_inst.
Proof. unfold Equation2372. intro H. specialize (H F4_0 F4_3 F4_1). unfold magma_op, refa515_inst, refa515_op in H. discriminate H. Qed.

Lemma refa515_not2381 : ~ @Equation2381 Fin4 refa515_inst.
Proof. unfold Equation2381. intro H. specialize (H F4_0 F4_1 F4_3). unfold magma_op, refa515_inst, refa515_op in H. discriminate H. Qed.

Lemma refa515_not2398 : ~ @Equation2398 Fin4 refa515_inst.
Proof. unfold Equation2398. intro H. specialize (H F4_0 F4_3 F4_1). unfold magma_op, refa515_inst, refa515_op in H. discriminate H. Qed.

Lemma refa515_not2584 : ~ @Equation2584 Fin4 refa515_inst.
Proof. unfold Equation2584. intro H. specialize (H F4_3 F4_1 F4_0). unfold magma_op, refa515_inst, refa515_op in H. discriminate H. Qed.

Lemma refa515_not2665 : ~ @Equation2665 Fin4 refa515_inst.
Proof. unfold Equation2665. intro H. specialize (H F4_0 F4_3 F4_1). unfold magma_op, refa515_inst, refa515_op in H. discriminate H. Qed.

Lemma refa515_not2669 : ~ @Equation2669 Fin4 refa515_inst.
Proof. unfold Equation2669. intro H. specialize (H F4_3 F4_2). unfold magma_op, refa515_inst, refa515_op in H. discriminate H. Qed.

Lemma refa515_not2699 : ~ @Equation2699 Fin4 refa515_inst.
Proof. unfold Equation2699. intro H. specialize (H F4_3 F4_2). unfold magma_op, refa515_inst, refa515_op in H. discriminate H. Qed.

Lemma refa515_not2739 : ~ @Equation2739 Fin4 refa515_inst.
Proof. unfold Equation2739. intro H. specialize (H F4_0 F4_3 F4_1). unfold magma_op, refa515_inst, refa515_op in H. discriminate H. Qed.

Lemma refa515_not3529 : ~ @Equation3529 Fin4 refa515_inst.
Proof. unfold Equation3529. intro H. specialize (H F4_0 F4_3 F4_1). unfold magma_op, refa515_inst, refa515_op in H. discriminate H. Qed.

Lemma refa515_not3749 : ~ @Equation3749 Fin4 refa515_inst.
Proof. unfold Equation3749. intro H. specialize (H F4_2 F4_3). unfold magma_op, refa515_inst, refa515_op in H. discriminate H. Qed.

Lemma refa515_not3883 : ~ @Equation3883 Fin4 refa515_inst.
Proof. unfold Equation3883. intro H. specialize (H F4_0 F4_3 F4_1). unfold magma_op, refa515_inst, refa515_op in H. discriminate H. Qed.

Lemma refa515_not3897 : ~ @Equation3897 Fin4 refa515_inst.
Proof. unfold Equation3897. intro H. specialize (H F4_0 F4_3 F4_1). unfold magma_op, refa515_inst, refa515_op in H. discriminate H. Qed.

Lemma refa515_not4362 : ~ @Equation4362 Fin4 refa515_inst.
Proof. unfold Equation4362. intro H. specialize (H F4_0 F4_3 F4_1). unfold magma_op, refa515_inst, refa515_op in H. discriminate H. Qed.

(** ---- refa516 (Fin4) ---- *)

Definition refa516_op (x y : Fin4) : Fin4 :=
  match x, y with
  | F4_0, F4_0 => F4_3 | F4_0, F4_1 => F4_2 | F4_0, F4_2 => F4_3 | F4_0, F4_3 => F4_3
  | F4_1, F4_0 => F4_3 | F4_1, F4_1 => F4_3 | F4_1, F4_2 => F4_0 | F4_1, F4_3 => F4_3
  | F4_2, F4_0 => F4_3 | F4_2, F4_1 => F4_3 | F4_2, F4_2 => F4_3 | F4_2, F4_3 => F4_3
  | F4_3, F4_0 => F4_3 | F4_3, F4_1 => F4_3 | F4_3, F4_2 => F4_3 | F4_3, F4_3 => F4_3
  end.

#[local] Instance refa516_inst : Magma Fin4 := {| magma_op := refa516_op |}.

Lemma refa516_sat3277 : @Equation3277 Fin4 refa516_inst.
Proof. unfold Equation3277, magma_op, refa516_inst, refa516_op. intros x y z w. destruct x, y, z, w; reflexivity. Qed.

Lemma refa516_sat3476 : @Equation3476 Fin4 refa516_inst.
Proof. unfold Equation3476, magma_op, refa516_inst, refa516_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa516_sat3479 : @Equation3479 Fin4 refa516_inst.
Proof. unfold Equation3479, magma_op, refa516_inst, refa516_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa516_sat3889 : @Equation3889 Fin4 refa516_inst.
Proof. unfold Equation3889, magma_op, refa516_inst, refa516_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa516_sat3899 : @Equation3899 Fin4 refa516_inst.
Proof. unfold Equation3899, magma_op, refa516_inst, refa516_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa516_sat4079 : @Equation4079 Fin4 refa516_inst.
Proof. unfold Equation4079, magma_op, refa516_inst, refa516_op. intros x y z w. destruct x, y, z, w; reflexivity. Qed.

Lemma refa516_sat4430 : @Equation4430 Fin4 refa516_inst.
Proof. unfold Equation4430, magma_op, refa516_inst, refa516_op. intros x y z w. destruct x, y, z, w; reflexivity. Qed.

Lemma refa516_not3458 : ~ @Equation3458 Fin4 refa516_inst.
Proof. unfold Equation3458. intro H. specialize (H F4_1 F4_2). unfold magma_op, refa516_inst, refa516_op in H. discriminate H. Qed.

Lemma refa516_not3482 : ~ @Equation3482 Fin4 refa516_inst.
Proof. unfold Equation3482. intro H. specialize (H F4_2 F4_1). unfold magma_op, refa516_inst, refa516_op in H. discriminate H. Qed.

Lemma refa516_not3867 : ~ @Equation3867 Fin4 refa516_inst.
Proof. unfold Equation3867. intro H. specialize (H F4_1 F4_0). unfold magma_op, refa516_inst, refa516_op in H. discriminate H. Qed.

Lemma refa516_not3881 : ~ @Equation3881 Fin4 refa516_inst.
Proof. unfold Equation3881. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa516_inst, refa516_op in H. discriminate H. Qed.

Lemma refa516_not4269 : ~ @Equation4269 Fin4 refa516_inst.
Proof. unfold Equation4269. intro H. specialize (H F4_1 F4_0). unfold magma_op, refa516_inst, refa516_op in H. discriminate H. Qed.

Lemma refa516_not4273 : ~ @Equation4273 Fin4 refa516_inst.
Proof. unfold Equation4273. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa516_inst, refa516_op in H. discriminate H. Qed.

Lemma refa516_not4283 : ~ @Equation4283 Fin4 refa516_inst.
Proof. unfold Equation4283. intro H. specialize (H F4_1 F4_0). unfold magma_op, refa516_inst, refa516_op in H. discriminate H. Qed.

Lemma refa516_not4291 : ~ @Equation4291 Fin4 refa516_inst.
Proof. unfold Equation4291. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa516_inst, refa516_op in H. discriminate H. Qed.

Lemma refa516_not4314 : ~ @Equation4314 Fin4 refa516_inst.
Proof. unfold Equation4314. intro H. specialize (H F4_1 F4_0). unfold magma_op, refa516_inst, refa516_op in H. discriminate H. Qed.

Lemma refa516_not4321 : ~ @Equation4321 Fin4 refa516_inst.
Proof. unfold Equation4321. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa516_inst, refa516_op in H. discriminate H. Qed.

Lemma refa516_not4398 : ~ @Equation4398 Fin4 refa516_inst.
Proof. unfold Equation4398. intro H. specialize (H F4_1 F4_2). unfold magma_op, refa516_inst, refa516_op in H. discriminate H. Qed.

Lemma refa516_not4406 : ~ @Equation4406 Fin4 refa516_inst.
Proof. unfold Equation4406. intro H. specialize (H F4_2 F4_1). unfold magma_op, refa516_inst, refa516_op in H. discriminate H. Qed.

Lemma refa516_not4435 : ~ @Equation4435 Fin4 refa516_inst.
Proof. unfold Equation4435. intro H. specialize (H F4_1 F4_0). unfold magma_op, refa516_inst, refa516_op in H. discriminate H. Qed.

Lemma refa516_not4436 : ~ @Equation4436 Fin4 refa516_inst.
Proof. unfold Equation4436. intro H. specialize (H F4_1 F4_0). unfold magma_op, refa516_inst, refa516_op in H. discriminate H. Qed.

Lemma refa516_not4442 : ~ @Equation4442 Fin4 refa516_inst.
Proof. unfold Equation4442. intro H. specialize (H F4_1 F4_0). unfold magma_op, refa516_inst, refa516_op in H. discriminate H. Qed.

Lemma refa516_not4443 : ~ @Equation4443 Fin4 refa516_inst.
Proof. unfold Equation4443. intro H. specialize (H F4_1 F4_0). unfold magma_op, refa516_inst, refa516_op in H. discriminate H. Qed.

Lemma refa516_not4606 : ~ @Equation4606 Fin4 refa516_inst.
Proof. unfold Equation4606. intro H. specialize (H F4_2 F4_1). unfold magma_op, refa516_inst, refa516_op in H. discriminate H. Qed.

Lemma refa516_not4629 : ~ @Equation4629 Fin4 refa516_inst.
Proof. unfold Equation4629. intro H. specialize (H F4_1 F4_2). unfold magma_op, refa516_inst, refa516_op in H. discriminate H. Qed.

Lemma refa516_not4631 : ~ @Equation4631 Fin4 refa516_inst.
Proof. unfold Equation4631. intro H. specialize (H F4_1 F4_0 F4_2). unfold magma_op, refa516_inst, refa516_op in H. discriminate H. Qed.

Lemma refa516_not4635 : ~ @Equation4635 Fin4 refa516_inst.
Proof. unfold Equation4635. intro H. specialize (H F4_1 F4_2). unfold magma_op, refa516_inst, refa516_op in H. discriminate H. Qed.

Lemma refa516_not4636 : ~ @Equation4636 Fin4 refa516_inst.
Proof. unfold Equation4636. intro H. specialize (H F4_1 F4_2). unfold magma_op, refa516_inst, refa516_op in H. discriminate H. Qed.

Lemma refa516_not4647 : ~ @Equation4647 Fin4 refa516_inst.
Proof. unfold Equation4647. intro H. specialize (H F4_0 F4_2 F4_1). unfold magma_op, refa516_inst, refa516_op in H. discriminate H. Qed.

(** ---- refa517 (Fin4) ---- *)

Definition refa517_op (x y : Fin4) : Fin4 :=
  match x, y with
  | F4_0, F4_0 => F4_0 | F4_0, F4_1 => F4_3 | F4_0, F4_2 => F4_2 | F4_0, F4_3 => F4_1
  | F4_1, F4_0 => F4_0 | F4_1, F4_1 => F4_3 | F4_1, F4_2 => F4_2 | F4_1, F4_3 => F4_1
  | F4_2, F4_0 => F4_2 | F4_2, F4_1 => F4_1 | F4_2, F4_2 => F4_0 | F4_2, F4_3 => F4_3
  | F4_3, F4_0 => F4_2 | F4_3, F4_1 => F4_1 | F4_3, F4_2 => F4_0 | F4_3, F4_3 => F4_3
  end.

#[local] Instance refa517_inst : Magma Fin4 := {| magma_op := refa517_op |}.

Lemma refa517_sat1340 : @Equation1340 Fin4 refa517_inst.
Proof. unfold Equation1340, magma_op, refa517_inst, refa517_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa517_not1241 : ~ @Equation1241 Fin4 refa517_inst.
Proof. unfold Equation1241. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa517_inst, refa517_op in H. discriminate H. Qed.

Lemma refa517_not1285 : ~ @Equation1285 Fin4 refa517_inst.
Proof. unfold Equation1285. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa517_inst, refa517_op in H. discriminate H. Qed.

Lemma refa517_not1654 : ~ @Equation1654 Fin4 refa517_inst.
Proof. unfold Equation1654. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa517_inst, refa517_op in H. discriminate H. Qed.

Lemma refa517_not1684 : ~ @Equation1684 Fin4 refa517_inst.
Proof. unfold Equation1684. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa517_inst, refa517_op in H. discriminate H. Qed.

Lemma refa517_not2053 : ~ @Equation2053 Fin4 refa517_inst.
Proof. unfold Equation2053. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa517_inst, refa517_op in H. discriminate H. Qed.

Lemma refa517_not2097 : ~ @Equation2097 Fin4 refa517_inst.
Proof. unfold Equation2097. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa517_inst, refa517_op in H. discriminate H. Qed.

Lemma refa517_not4083 : ~ @Equation4083 Fin4 refa517_inst.
Proof. unfold Equation4083. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa517_inst, refa517_op in H. discriminate H. Qed.

Lemma refa517_not4158 : ~ @Equation4158 Fin4 refa517_inst.
Proof. unfold Equation4158. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa517_inst, refa517_op in H. discriminate H. Qed.

Lemma refa517_not4635 : ~ @Equation4635 Fin4 refa517_inst.
Proof. unfold Equation4635. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa517_inst, refa517_op in H. discriminate H. Qed.

(** ---- refa518 (Fin4) ---- *)

Definition refa518_op (x y : Fin4) : Fin4 :=
  match x, y with
  | F4_0, F4_0 => F4_0 | F4_0, F4_1 => F4_0 | F4_0, F4_2 => F4_0 | F4_0, F4_3 => F4_1
  | F4_1, F4_0 => F4_1 | F4_1, F4_1 => F4_1 | F4_1, F4_2 => F4_0 | F4_1, F4_3 => F4_1
  | F4_2, F4_0 => F4_2 | F4_2, F4_1 => F4_0 | F4_2, F4_2 => F4_2 | F4_2, F4_3 => F4_2
  | F4_3, F4_0 => F4_2 | F4_3, F4_1 => F4_3 | F4_3, F4_2 => F4_3 | F4_3, F4_3 => F4_3
  end.

#[local] Instance refa518_inst : Magma Fin4 := {| magma_op := refa518_op |}.

Lemma refa518_sat428 : @Equation428 Fin4 refa518_inst.
Proof. unfold Equation428, magma_op, refa518_inst, refa518_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa518_not825 : ~ @Equation825 Fin4 refa518_inst.
Proof. unfold Equation825. intro H. specialize (H F4_3 F4_0). unfold magma_op, refa518_inst, refa518_op in H. discriminate H. Qed.

Lemma refa518_not833 : ~ @Equation833 Fin4 refa518_inst.
Proof. unfold Equation833. intro H. specialize (H F4_3 F4_0). unfold magma_op, refa518_inst, refa518_op in H. discriminate H. Qed.

Lemma refa518_not838 : ~ @Equation838 Fin4 refa518_inst.
Proof. unfold Equation838. intro H. specialize (H F4_1 F4_3 F4_0). unfold magma_op, refa518_inst, refa518_op in H. discriminate H. Qed.

Lemma refa518_not840 : ~ @Equation840 Fin4 refa518_inst.
Proof. unfold Equation840. intro H. specialize (H F4_1 F4_3 F4_0). unfold magma_op, refa518_inst, refa518_op in H. discriminate H. Qed.

Lemma refa518_not1032 : ~ @Equation1032 Fin4 refa518_inst.
Proof. unfold Equation1032. intro H. specialize (H F4_3 F4_1 F4_2). unfold magma_op, refa518_inst, refa518_op in H. discriminate H. Qed.

Lemma refa518_not1227 : ~ @Equation1227 Fin4 refa518_inst.
Proof. unfold Equation1227. intro H. specialize (H F4_2 F4_1 F4_3). unfold magma_op, refa518_inst, refa518_op in H. discriminate H. Qed.

Lemma refa518_not1230 : ~ @Equation1230 Fin4 refa518_inst.
Proof. unfold Equation1230. intro H. specialize (H F4_2 F4_1 F4_3). unfold magma_op, refa518_inst, refa518_op in H. discriminate H. Qed.

Lemma refa518_not1233 : ~ @Equation1233 Fin4 refa518_inst.
Proof. unfold Equation1233. intro H. specialize (H F4_2 F4_1 F4_3). unfold magma_op, refa518_inst, refa518_op in H. discriminate H. Qed.

Lemma refa518_not1235 : ~ @Equation1235 Fin4 refa518_inst.
Proof. unfold Equation1235. intro H. specialize (H F4_2 F4_1 F4_3). unfold magma_op, refa518_inst, refa518_op in H. discriminate H. Qed.

Lemma refa518_not1236 : ~ @Equation1236 Fin4 refa518_inst.
Proof. unfold Equation1236. intro H. specialize (H F4_2 F4_1 F4_3). unfold magma_op, refa518_inst, refa518_op in H. discriminate H. Qed.

Lemma refa518_not1240 : ~ @Equation1240 Fin4 refa518_inst.
Proof. unfold Equation1240. intro H. specialize (H F4_1 F4_3 F4_0). unfold magma_op, refa518_inst, refa518_op in H. discriminate H. Qed.

Lemma refa518_not1243 : ~ @Equation1243 Fin4 refa518_inst.
Proof. unfold Equation1243. intro H. specialize (H F4_1 F4_3 F4_0). unfold magma_op, refa518_inst, refa518_op in H. discriminate H. Qed.

Lemma refa518_not1245 : ~ @Equation1245 Fin4 refa518_inst.
Proof. unfold Equation1245. intro H. specialize (H F4_1 F4_3 F4_0). unfold magma_op, refa518_inst, refa518_op in H. discriminate H. Qed.

Lemma refa518_not1250 : ~ @Equation1250 Fin4 refa518_inst.
Proof. unfold Equation1250. intro H. specialize (H F4_1 F4_3 F4_0). unfold magma_op, refa518_inst, refa518_op in H. discriminate H. Qed.

Lemma refa518_not1259 : ~ @Equation1259 Fin4 refa518_inst.
Proof. unfold Equation1259. intro H. specialize (H F4_3 F4_2 F4_1). unfold magma_op, refa518_inst, refa518_op in H. discriminate H. Qed.

Lemma refa518_not1633 : ~ @Equation1633 Fin4 refa518_inst.
Proof. unfold Equation1633. intro H. specialize (H F4_2 F4_1 F4_3). unfold magma_op, refa518_inst, refa518_op in H. discriminate H. Qed.

Lemma refa518_not2452 : ~ @Equation2452 Fin4 refa518_inst.
Proof. unfold Equation2452. intro H. specialize (H F4_2 F4_1 F4_3). unfold magma_op, refa518_inst, refa518_op in H. discriminate H. Qed.

Lemma refa518_not2462 : ~ @Equation2462 Fin4 refa518_inst.
Proof. unfold Equation2462. intro H. specialize (H F4_1 F4_3 F4_0). unfold magma_op, refa518_inst, refa518_op in H. discriminate H. Qed.

Lemma refa518_not3460 : ~ @Equation3460 Fin4 refa518_inst.
Proof. unfold Equation3460. intro H. specialize (H F4_2 F4_1 F4_3). unfold magma_op, refa518_inst, refa518_op in H. discriminate H. Qed.

Lemma refa518_not3463 : ~ @Equation3463 Fin4 refa518_inst.
Proof. unfold Equation3463. intro H. specialize (H F4_1 F4_3 F4_0). unfold magma_op, refa518_inst, refa518_op in H. discriminate H. Qed.

Lemma refa518_not3724 : ~ @Equation3724 Fin4 refa518_inst.
Proof. unfold Equation3724. intro H. specialize (H F4_0 F4_3). unfold magma_op, refa518_inst, refa518_op in H. discriminate H. Qed.

Lemma refa518_not3931 : ~ @Equation3931 Fin4 refa518_inst.
Proof. unfold Equation3931. intro H. specialize (H F4_2 F4_0 F4_3). unfold magma_op, refa518_inst, refa518_op in H. discriminate H. Qed.

Lemma refa518_not4673 : ~ @Equation4673 Fin4 refa518_inst.
Proof. unfold Equation4673. intro H. specialize (H F4_0 F4_2 F4_3). unfold magma_op, refa518_inst, refa518_op in H. discriminate H. Qed.

(** ---- refa519 (Fin4) ---- *)

Definition refa519_op (x y : Fin4) : Fin4 :=
  match x, y with
  | F4_0, F4_0 => F4_2 | F4_0, F4_1 => F4_2 | F4_0, F4_2 => F4_0 | F4_0, F4_3 => F4_1
  | F4_1, F4_0 => F4_2 | F4_1, F4_1 => F4_1 | F4_1, F4_2 => F4_1 | F4_1, F4_3 => F4_1
  | F4_2, F4_0 => F4_2 | F4_2, F4_1 => F4_2 | F4_2, F4_2 => F4_2 | F4_2, F4_3 => F4_2
  | F4_3, F4_0 => F4_2 | F4_3, F4_1 => F4_3 | F4_3, F4_2 => F4_3 | F4_3, F4_3 => F4_1
  end.

#[local] Instance refa519_inst : Magma Fin4 := {| magma_op := refa519_op |}.

Lemma refa519_sat841 : @Equation841 Fin4 refa519_inst.
Proof. unfold Equation841, magma_op, refa519_inst, refa519_op. intros x y z w. destruct x, y, z, w; reflexivity. Qed.

Lemma refa519_not3928 : ~ @Equation3928 Fin4 refa519_inst.
Proof. unfold Equation3928. intro H. specialize (H F4_0 F4_3). unfold magma_op, refa519_inst, refa519_op in H. discriminate H. Qed.

(** ---- refa52 (Fin2) ---- *)

Definition refa52_op (x y : Fin2) : Fin2 :=
  match x, y with
  | F2_0, F2_0 => F2_1 | F2_0, F2_1 => F2_1
  | F2_1, F2_0 => F2_0 | F2_1, F2_1 => F2_0
  end.

#[local] Instance refa52_inst : Magma Fin2 := {| magma_op := refa52_op |}.

Lemma refa52_sat24 : @Equation24 Fin2 refa52_inst.
Proof. unfold Equation24, magma_op, refa52_inst, refa52_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa52_not47 : ~ @Equation47 Fin2 refa52_inst.
Proof. unfold Equation47. intro H. specialize (H F2_0). unfold magma_op, refa52_inst, refa52_op in H. discriminate H. Qed.

Lemma refa52_not99 : ~ @Equation99 Fin2 refa52_inst.
Proof. unfold Equation99. intro H. specialize (H F2_0). unfold magma_op, refa52_inst, refa52_op in H. discriminate H. Qed.

Lemma refa52_not255 : ~ @Equation255 Fin2 refa52_inst.
Proof. unfold Equation255. intro H. specialize (H F2_0). unfold magma_op, refa52_inst, refa52_op in H. discriminate H. Qed.

Lemma refa52_not359 : ~ @Equation359 Fin2 refa52_inst.
Proof. unfold Equation359. intro H. specialize (H F2_0). unfold magma_op, refa52_inst, refa52_op in H. discriminate H. Qed.

Lemma refa52_not411 : ~ @Equation411 Fin2 refa52_inst.
Proof. unfold Equation411. intro H. specialize (H F2_0). unfold magma_op, refa52_inst, refa52_op in H. discriminate H. Qed.

Lemma refa52_not614 : ~ @Equation614 Fin2 refa52_inst.
Proof. unfold Equation614. intro H. specialize (H F2_0). unfold magma_op, refa52_inst, refa52_op in H. discriminate H. Qed.

Lemma refa52_not817 : ~ @Equation817 Fin2 refa52_inst.
Proof. unfold Equation817. intro H. specialize (H F2_0). unfold magma_op, refa52_inst, refa52_op in H. discriminate H. Qed.

Lemma refa52_not1020 : ~ @Equation1020 Fin2 refa52_inst.
Proof. unfold Equation1020. intro H. specialize (H F2_0). unfold magma_op, refa52_inst, refa52_op in H. discriminate H. Qed.

Lemma refa52_not1223 : ~ @Equation1223 Fin2 refa52_inst.
Proof. unfold Equation1223. intro H. specialize (H F2_0). unfold magma_op, refa52_inst, refa52_op in H. discriminate H. Qed.

Lemma refa52_not1479 : ~ @Equation1479 Fin2 refa52_inst.
Proof. unfold Equation1479. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa52_inst, refa52_op in H. discriminate H. Qed.

Lemma refa52_not1488 : ~ @Equation1488 Fin2 refa52_inst.
Proof. unfold Equation1488. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa52_inst, refa52_op in H. discriminate H. Qed.

Lemma refa52_not1515 : ~ @Equation1515 Fin2 refa52_inst.
Proof. unfold Equation1515. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa52_inst, refa52_op in H. discriminate H. Qed.

Lemma refa52_not1519 : ~ @Equation1519 Fin2 refa52_inst.
Proof. unfold Equation1519. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa52_inst, refa52_op in H. discriminate H. Qed.

Lemma refa52_not1682 : ~ @Equation1682 Fin2 refa52_inst.
Proof. unfold Equation1682. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa52_inst, refa52_op in H. discriminate H. Qed.

Lemma refa52_not1684 : ~ @Equation1684 Fin2 refa52_inst.
Proof. unfold Equation1684. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa52_inst, refa52_op in H. discriminate H. Qed.

Lemma refa52_not1691 : ~ @Equation1691 Fin2 refa52_inst.
Proof. unfold Equation1691. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa52_inst, refa52_op in H. discriminate H. Qed.

Lemma refa52_not1722 : ~ @Equation1722 Fin2 refa52_inst.
Proof. unfold Equation1722. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa52_inst, refa52_op in H. discriminate H. Qed.

Lemma refa52_not1731 : ~ @Equation1731 Fin2 refa52_inst.
Proof. unfold Equation1731. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa52_inst, refa52_op in H. discriminate H. Qed.

Lemma refa52_not1894 : ~ @Equation1894 Fin2 refa52_inst.
Proof. unfold Equation1894. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa52_inst, refa52_op in H. discriminate H. Qed.

Lemma refa52_not1921 : ~ @Equation1921 Fin2 refa52_inst.
Proof. unfold Equation1921. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa52_inst, refa52_op in H. discriminate H. Qed.

Lemma refa52_not1925 : ~ @Equation1925 Fin2 refa52_inst.
Proof. unfold Equation1925. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa52_inst, refa52_op in H. discriminate H. Qed.

Lemma refa52_not2035 : ~ @Equation2035 Fin2 refa52_inst.
Proof. unfold Equation2035. intro H. specialize (H F2_0). unfold magma_op, refa52_inst, refa52_op in H. discriminate H. Qed.

Lemma refa52_not2291 : ~ @Equation2291 Fin2 refa52_inst.
Proof. unfold Equation2291. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa52_inst, refa52_op in H. discriminate H. Qed.

Lemma refa52_not2293 : ~ @Equation2293 Fin2 refa52_inst.
Proof. unfold Equation2293. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa52_inst, refa52_op in H. discriminate H. Qed.

Lemma refa52_not2300 : ~ @Equation2300 Fin2 refa52_inst.
Proof. unfold Equation2300. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa52_inst, refa52_op in H. discriminate H. Qed.

Lemma refa52_not2327 : ~ @Equation2327 Fin2 refa52_inst.
Proof. unfold Equation2327. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa52_inst, refa52_op in H. discriminate H. Qed.

Lemma refa52_not2340 : ~ @Equation2340 Fin2 refa52_inst.
Proof. unfold Equation2340. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa52_inst, refa52_op in H. discriminate H. Qed.

Lemma refa52_not2496 : ~ @Equation2496 Fin2 refa52_inst.
Proof. unfold Equation2496. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa52_inst, refa52_op in H. discriminate H. Qed.

Lemma refa52_not2503 : ~ @Equation2503 Fin2 refa52_inst.
Proof. unfold Equation2503. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa52_inst, refa52_op in H. discriminate H. Qed.

Lemma refa52_not2530 : ~ @Equation2530 Fin2 refa52_inst.
Proof. unfold Equation2530. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa52_inst, refa52_op in H. discriminate H. Qed.

Lemma refa52_not2534 : ~ @Equation2534 Fin2 refa52_inst.
Proof. unfold Equation2534. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa52_inst, refa52_op in H. discriminate H. Qed.

Lemma refa52_not2541 : ~ @Equation2541 Fin2 refa52_inst.
Proof. unfold Equation2541. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa52_inst, refa52_op in H. discriminate H. Qed.

Lemma refa52_not2543 : ~ @Equation2543 Fin2 refa52_inst.
Proof. unfold Equation2543. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa52_inst, refa52_op in H. discriminate H. Qed.

Lemma refa52_not2644 : ~ @Equation2644 Fin2 refa52_inst.
Proof. unfold Equation2644. intro H. specialize (H F2_0). unfold magma_op, refa52_inst, refa52_op in H. discriminate H. Qed.

Lemma refa52_not2847 : ~ @Equation2847 Fin2 refa52_inst.
Proof. unfold Equation2847. intro H. specialize (H F2_0). unfold magma_op, refa52_inst, refa52_op in H. discriminate H. Qed.

Lemma refa52_not3105 : ~ @Equation3105 Fin2 refa52_inst.
Proof. unfold Equation3105. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa52_inst, refa52_op in H. discriminate H. Qed.

Lemma refa52_not3112 : ~ @Equation3112 Fin2 refa52_inst.
Proof. unfold Equation3112. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa52_inst, refa52_op in H. discriminate H. Qed.

Lemma refa52_not3116 : ~ @Equation3116 Fin2 refa52_inst.
Proof. unfold Equation3116. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa52_inst, refa52_op in H. discriminate H. Qed.

Lemma refa52_not3143 : ~ @Equation3143 Fin2 refa52_inst.
Proof. unfold Equation3143. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa52_inst, refa52_op in H. discriminate H. Qed.

Lemma refa52_not3150 : ~ @Equation3150 Fin2 refa52_inst.
Proof. unfold Equation3150. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa52_inst, refa52_op in H. discriminate H. Qed.

Lemma refa52_not3152 : ~ @Equation3152 Fin2 refa52_inst.
Proof. unfold Equation3152. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa52_inst, refa52_op in H. discriminate H. Qed.

Lemma refa52_not3271 : ~ @Equation3271 Fin2 refa52_inst.
Proof. unfold Equation3271. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa52_inst, refa52_op in H. discriminate H. Qed.

Lemma refa52_not3278 : ~ @Equation3278 Fin2 refa52_inst.
Proof. unfold Equation3278. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa52_inst, refa52_op in H. discriminate H. Qed.

Lemma refa52_not3279 : ~ @Equation3279 Fin2 refa52_inst.
Proof. unfold Equation3279. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa52_inst, refa52_op in H. discriminate H. Qed.

Lemma refa52_not3342 : ~ @Equation3342 Fin2 refa52_inst.
Proof. unfold Equation3342. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa52_inst, refa52_op in H. discriminate H. Qed.

Lemma refa52_not3346 : ~ @Equation3346 Fin2 refa52_inst.
Proof. unfold Equation3346. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa52_inst, refa52_op in H. discriminate H. Qed.

Lemma refa52_not3353 : ~ @Equation3353 Fin2 refa52_inst.
Proof. unfold Equation3353. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa52_inst, refa52_op in H. discriminate H. Qed.

Lemma refa52_not3472 : ~ @Equation3472 Fin2 refa52_inst.
Proof. unfold Equation3472. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa52_inst, refa52_op in H. discriminate H. Qed.

Lemma refa52_not3474 : ~ @Equation3474 Fin2 refa52_inst.
Proof. unfold Equation3474. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa52_inst, refa52_op in H. discriminate H. Qed.

Lemma refa52_not3481 : ~ @Equation3481 Fin2 refa52_inst.
Proof. unfold Equation3481. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa52_inst, refa52_op in H. discriminate H. Qed.

Lemma refa52_not3545 : ~ @Equation3545 Fin2 refa52_inst.
Proof. unfold Equation3545. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa52_inst, refa52_op in H. discriminate H. Qed.

Lemma refa52_not3549 : ~ @Equation3549 Fin2 refa52_inst.
Proof. unfold Equation3549. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa52_inst, refa52_op in H. discriminate H. Qed.

Lemma refa52_not3556 : ~ @Equation3556 Fin2 refa52_inst.
Proof. unfold Equation3556. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa52_inst, refa52_op in H. discriminate H. Qed.

Lemma refa52_not3558 : ~ @Equation3558 Fin2 refa52_inst.
Proof. unfold Equation3558. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa52_inst, refa52_op in H. discriminate H. Qed.

Lemma refa52_not3659 : ~ @Equation3659 Fin2 refa52_inst.
Proof. unfold Equation3659. intro H. specialize (H F2_0). unfold magma_op, refa52_inst, refa52_op in H. discriminate H. Qed.

Lemma refa52_not3862 : ~ @Equation3862 Fin2 refa52_inst.
Proof. unfold Equation3862. intro H. specialize (H F2_0). unfold magma_op, refa52_inst, refa52_op in H. discriminate H. Qed.

Lemma refa52_not4083 : ~ @Equation4083 Fin2 refa52_inst.
Proof. unfold Equation4083. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa52_inst, refa52_op in H. discriminate H. Qed.

Lemma refa52_not4084 : ~ @Equation4084 Fin2 refa52_inst.
Proof. unfold Equation4084. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa52_inst, refa52_op in H. discriminate H. Qed.

Lemma refa52_not4090 : ~ @Equation4090 Fin2 refa52_inst.
Proof. unfold Equation4090. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa52_inst, refa52_op in H. discriminate H. Qed.

Lemma refa52_not4091 : ~ @Equation4091 Fin2 refa52_inst.
Proof. unfold Equation4091. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa52_inst, refa52_op in H. discriminate H. Qed.

Lemma refa52_not4093 : ~ @Equation4093 Fin2 refa52_inst.
Proof. unfold Equation4093. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa52_inst, refa52_op in H. discriminate H. Qed.

Lemma refa52_not4158 : ~ @Equation4158 Fin2 refa52_inst.
Proof. unfold Equation4158. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa52_inst, refa52_op in H. discriminate H. Qed.

Lemma refa52_not4165 : ~ @Equation4165 Fin2 refa52_inst.
Proof. unfold Equation4165. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa52_inst, refa52_op in H. discriminate H. Qed.

Lemma refa52_not4167 : ~ @Equation4167 Fin2 refa52_inst.
Proof. unfold Equation4167. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa52_inst, refa52_op in H. discriminate H. Qed.

Lemma refa52_not4273 : ~ @Equation4273 Fin2 refa52_inst.
Proof. unfold Equation4273. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa52_inst, refa52_op in H. discriminate H. Qed.

Lemma refa52_not4275 : ~ @Equation4275 Fin2 refa52_inst.
Proof. unfold Equation4275. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa52_inst, refa52_op in H. discriminate H. Qed.

Lemma refa52_not4290 : ~ @Equation4290 Fin2 refa52_inst.
Proof. unfold Equation4290. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa52_inst, refa52_op in H. discriminate H. Qed.

Lemma refa52_not4293 : ~ @Equation4293 Fin2 refa52_inst.
Proof. unfold Equation4293. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa52_inst, refa52_op in H. discriminate H. Qed.

Lemma refa52_not4320 : ~ @Equation4320 Fin2 refa52_inst.
Proof. unfold Equation4320. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa52_inst, refa52_op in H. discriminate H. Qed.

Lemma refa52_not4380 : ~ @Equation4380 Fin2 refa52_inst.
Proof. unfold Equation4380. intro H. specialize (H F2_0). unfold magma_op, refa52_inst, refa52_op in H. discriminate H. Qed.

Lemma refa52_not4588 : ~ @Equation4588 Fin2 refa52_inst.
Proof. unfold Equation4588. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa52_inst, refa52_op in H. discriminate H. Qed.

Lemma refa52_not4590 : ~ @Equation4590 Fin2 refa52_inst.
Proof. unfold Equation4590. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa52_inst, refa52_op in H. discriminate H. Qed.

Lemma refa52_not4591 : ~ @Equation4591 Fin2 refa52_inst.
Proof. unfold Equation4591. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa52_inst, refa52_op in H. discriminate H. Qed.

Lemma refa52_not4605 : ~ @Equation4605 Fin2 refa52_inst.
Proof. unfold Equation4605. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa52_inst, refa52_op in H. discriminate H. Qed.

Lemma refa52_not4606 : ~ @Equation4606 Fin2 refa52_inst.
Proof. unfold Equation4606. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa52_inst, refa52_op in H. discriminate H. Qed.

Lemma refa52_not4608 : ~ @Equation4608 Fin2 refa52_inst.
Proof. unfold Equation4608. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa52_inst, refa52_op in H. discriminate H. Qed.

Lemma refa52_not4635 : ~ @Equation4635 Fin2 refa52_inst.
Proof. unfold Equation4635. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa52_inst, refa52_op in H. discriminate H. Qed.

Lemma refa52_not4636 : ~ @Equation4636 Fin2 refa52_inst.
Proof. unfold Equation4636. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa52_inst, refa52_op in H. discriminate H. Qed.

(** ---- refa520 (Fin4) ---- *)

Definition refa520_op (x y : Fin4) : Fin4 :=
  match x, y with
  | F4_0, F4_0 => F4_3 | F4_0, F4_1 => F4_1 | F4_0, F4_2 => F4_3 | F4_0, F4_3 => F4_3
  | F4_1, F4_0 => F4_3 | F4_1, F4_1 => F4_3 | F4_1, F4_2 => F4_0 | F4_1, F4_3 => F4_3
  | F4_2, F4_0 => F4_0 | F4_2, F4_1 => F4_3 | F4_2, F4_2 => F4_1 | F4_2, F4_3 => F4_3
  | F4_3, F4_0 => F4_0 | F4_3, F4_1 => F4_1 | F4_3, F4_2 => F4_2 | F4_3, F4_3 => F4_3
  end.

#[local] Instance refa520_inst : Magma Fin4 := {| magma_op := refa520_op |}.

Lemma refa520_sat2368 : @Equation2368 Fin4 refa520_inst.
Proof. unfold Equation2368, magma_op, refa520_inst, refa520_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa520_sat2372 : @Equation2372 Fin4 refa520_inst.
Proof. unfold Equation2372, magma_op, refa520_inst, refa520_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa520_sat2385 : @Equation2385 Fin4 refa520_inst.
Proof. unfold Equation2385, magma_op, refa520_inst, refa520_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa520_not211 : ~ @Equation211 Fin4 refa520_inst.
Proof. unfold Equation211. intro H. specialize (H F4_0 F4_2). unfold magma_op, refa520_inst, refa520_op in H. discriminate H. Qed.

Lemma refa520_not2243 : ~ @Equation2243 Fin4 refa520_inst.
Proof. unfold Equation2243. intro H. specialize (H F4_2 F4_1). unfold magma_op, refa520_inst, refa520_op in H. discriminate H. Qed.

Lemma refa520_not2246 : ~ @Equation2246 Fin4 refa520_inst.
Proof. unfold Equation2246. intro H. specialize (H F4_0 F4_2). unfold magma_op, refa520_inst, refa520_op in H. discriminate H. Qed.

Lemma refa520_not2441 : ~ @Equation2441 Fin4 refa520_inst.
Proof. unfold Equation2441. intro H. specialize (H F4_2). unfold magma_op, refa520_inst, refa520_op in H. discriminate H. Qed.

Lemma refa520_not3659 : ~ @Equation3659 Fin4 refa520_inst.
Proof. unfold Equation3659. intro H. specialize (H F4_2). unfold magma_op, refa520_inst, refa520_op in H. discriminate H. Qed.

Lemma refa520_not4065 : ~ @Equation4065 Fin4 refa520_inst.
Proof. unfold Equation4065. intro H. specialize (H F4_2). unfold magma_op, refa520_inst, refa520_op in H. discriminate H. Qed.

(** ---- refa521 (Fin4) ---- *)

Definition refa521_op (x y : Fin4) : Fin4 :=
  match x, y with
  | F4_0, F4_0 => F4_2 | F4_0, F4_1 => F4_2 | F4_0, F4_2 => F4_3 | F4_0, F4_3 => F4_3
  | F4_1, F4_0 => F4_3 | F4_1, F4_1 => F4_3 | F4_1, F4_2 => F4_2 | F4_1, F4_3 => F4_2
  | F4_2, F4_0 => F4_0 | F4_2, F4_1 => F4_0 | F4_2, F4_2 => F4_1 | F4_2, F4_3 => F4_1
  | F4_3, F4_0 => F4_1 | F4_3, F4_1 => F4_1 | F4_3, F4_2 => F4_0 | F4_3, F4_3 => F4_0
  end.

#[local] Instance refa521_inst : Magma Fin4 := {| magma_op := refa521_op |}.

Lemma refa521_sat2463 : @Equation2463 Fin4 refa521_inst.
Proof. unfold Equation2463, magma_op, refa521_inst, refa521_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa521_not151 : ~ @Equation151 Fin4 refa521_inst.
Proof. unfold Equation151. intro H. specialize (H F4_0). unfold magma_op, refa521_inst, refa521_op in H. discriminate H. Qed.

Lemma refa521_not203 : ~ @Equation203 Fin4 refa521_inst.
Proof. unfold Equation203. intro H. specialize (H F4_0). unfold magma_op, refa521_inst, refa521_op in H. discriminate H. Qed.

Lemma refa521_not1426 : ~ @Equation1426 Fin4 refa521_inst.
Proof. unfold Equation1426. intro H. specialize (H F4_0). unfold magma_op, refa521_inst, refa521_op in H. discriminate H. Qed.

Lemma refa521_not2035 : ~ @Equation2035 Fin4 refa521_inst.
Proof. unfold Equation2035. intro H. specialize (H F4_0). unfold magma_op, refa521_inst, refa521_op in H. discriminate H. Qed.

Lemma refa521_not2238 : ~ @Equation2238 Fin4 refa521_inst.
Proof. unfold Equation2238. intro H. specialize (H F4_0). unfold magma_op, refa521_inst, refa521_op in H. discriminate H. Qed.

Lemma refa521_not2644 : ~ @Equation2644 Fin4 refa521_inst.
Proof. unfold Equation2644. intro H. specialize (H F4_0). unfold magma_op, refa521_inst, refa521_op in H. discriminate H. Qed.

Lemma refa521_not3253 : ~ @Equation3253 Fin4 refa521_inst.
Proof. unfold Equation3253. intro H. specialize (H F4_0). unfold magma_op, refa521_inst, refa521_op in H. discriminate H. Qed.

Lemma refa521_not3659 : ~ @Equation3659 Fin4 refa521_inst.
Proof. unfold Equation3659. intro H. specialize (H F4_0). unfold magma_op, refa521_inst, refa521_op in H. discriminate H. Qed.

Lemma refa521_not3862 : ~ @Equation3862 Fin4 refa521_inst.
Proof. unfold Equation3862. intro H. specialize (H F4_0). unfold magma_op, refa521_inst, refa521_op in H. discriminate H. Qed.

(** ---- refa522 (Fin4) ---- *)

Definition refa522_op (x y : Fin4) : Fin4 :=
  match x, y with
  | F4_0, F4_0 => F4_2 | F4_0, F4_1 => F4_3 | F4_0, F4_2 => F4_1 | F4_0, F4_3 => F4_1
  | F4_1, F4_0 => F4_3 | F4_1, F4_1 => F4_0 | F4_1, F4_2 => F4_0 | F4_1, F4_3 => F4_0
  | F4_2, F4_0 => F4_0 | F4_2, F4_1 => F4_0 | F4_2, F4_2 => F4_0 | F4_2, F4_3 => F4_0
  | F4_3, F4_0 => F4_1 | F4_3, F4_1 => F4_3 | F4_3, F4_2 => F4_0 | F4_3, F4_3 => F4_0
  end.

#[local] Instance refa522_inst : Magma Fin4 := {| magma_op := refa522_op |}.

Lemma refa522_sat1445 : @Equation1445 Fin4 refa522_inst.
Proof. unfold Equation1445, magma_op, refa522_inst, refa522_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa522_not1442 : ~ @Equation1442 Fin4 refa522_inst.
Proof. unfold Equation1442. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa522_inst, refa522_op in H. discriminate H. Qed.

Lemma refa522_not1444 : ~ @Equation1444 Fin4 refa522_inst.
Proof. unfold Equation1444. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa522_inst, refa522_op in H. discriminate H. Qed.

(** ---- refa523 (Fin4) ---- *)

Definition refa523_op (x y : Fin4) : Fin4 :=
  match x, y with
  | F4_0, F4_0 => F4_3 | F4_0, F4_1 => F4_1 | F4_0, F4_2 => F4_0 | F4_0, F4_3 => F4_3
  | F4_1, F4_0 => F4_3 | F4_1, F4_1 => F4_3 | F4_1, F4_2 => F4_2 | F4_1, F4_3 => F4_3
  | F4_2, F4_0 => F4_3 | F4_2, F4_1 => F4_0 | F4_2, F4_2 => F4_3 | F4_2, F4_3 => F4_1
  | F4_3, F4_0 => F4_0 | F4_3, F4_1 => F4_1 | F4_3, F4_2 => F4_2 | F4_3, F4_3 => F4_3
  end.

#[local] Instance refa523_inst : Magma Fin4 := {| magma_op := refa523_op |}.

Lemma refa523_sat2476 : @Equation2476 Fin4 refa523_inst.
Proof. unfold Equation2476, magma_op, refa523_inst, refa523_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa523_sat2571 : @Equation2571 Fin4 refa523_inst.
Proof. unfold Equation2571, magma_op, refa523_inst, refa523_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa523_not2238 : ~ @Equation2238 Fin4 refa523_inst.
Proof. unfold Equation2238. intro H. specialize (H F4_2). unfold magma_op, refa523_inst, refa523_op in H. discriminate H. Qed.

Lemma refa523_not2449 : ~ @Equation2449 Fin4 refa523_inst.
Proof. unfold Equation2449. intro H. specialize (H F4_2 F4_1). unfold magma_op, refa523_inst, refa523_op in H. discriminate H. Qed.

Lemma refa523_not3065 : ~ @Equation3065 Fin4 refa523_inst.
Proof. unfold Equation3065. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa523_inst, refa523_op in H. discriminate H. Qed.

Lemma refa523_not3519 : ~ @Equation3519 Fin4 refa523_inst.
Proof. unfold Equation3519. intro H. specialize (H F4_1 F4_2). unfold magma_op, refa523_inst, refa523_op in H. discriminate H. Qed.

(** ---- refa524 (Fin4) ---- *)

Definition refa524_op (x y : Fin4) : Fin4 :=
  match x, y with
  | F4_0, F4_0 => F4_1 | F4_0, F4_1 => F4_0 | F4_0, F4_2 => F4_0 | F4_0, F4_3 => F4_1
  | F4_1, F4_0 => F4_3 | F4_1, F4_1 => F4_1 | F4_1, F4_2 => F4_2 | F4_1, F4_3 => F4_3
  | F4_2, F4_0 => F4_0 | F4_2, F4_1 => F4_2 | F4_2, F4_2 => F4_1 | F4_2, F4_3 => F4_2
  | F4_3, F4_0 => F4_2 | F4_3, F4_1 => F4_3 | F4_3, F4_2 => F4_2 | F4_3, F4_3 => F4_1
  end.

#[local] Instance refa524_inst : Magma Fin4 := {| magma_op := refa524_op |}.

Lemma refa524_sat3139 : @Equation3139 Fin4 refa524_inst.
Proof. unfold Equation3139, magma_op, refa524_inst, refa524_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa524_not1629 : ~ @Equation1629 Fin4 refa524_inst.
Proof. unfold Equation1629. intro H. specialize (H F4_0). unfold magma_op, refa524_inst, refa524_op in H. discriminate H. Qed.

Lemma refa524_not2238 : ~ @Equation2238 Fin4 refa524_inst.
Proof. unfold Equation2238. intro H. specialize (H F4_0). unfold magma_op, refa524_inst, refa524_op in H. discriminate H. Qed.

Lemma refa524_not2441 : ~ @Equation2441 Fin4 refa524_inst.
Proof. unfold Equation2441. intro H. specialize (H F4_0). unfold magma_op, refa524_inst, refa524_op in H. discriminate H. Qed.

Lemma refa524_not3068 : ~ @Equation3068 Fin4 refa524_inst.
Proof. unfold Equation3068. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa524_inst, refa524_op in H. discriminate H. Qed.

(** ---- refa525 (Fin4) ---- *)

Definition refa525_op (x y : Fin4) : Fin4 :=
  match x, y with
  | F4_0, F4_0 => F4_0 | F4_0, F4_1 => F4_1 | F4_0, F4_2 => F4_2 | F4_0, F4_3 => F4_3
  | F4_1, F4_0 => F4_2 | F4_1, F4_1 => F4_3 | F4_1, F4_2 => F4_0 | F4_1, F4_3 => F4_1
  | F4_2, F4_0 => F4_3 | F4_2, F4_1 => F4_2 | F4_2, F4_2 => F4_1 | F4_2, F4_3 => F4_0
  | F4_3, F4_0 => F4_1 | F4_3, F4_1 => F4_0 | F4_3, F4_2 => F4_3 | F4_3, F4_3 => F4_2
  end.

#[local] Instance refa525_inst : Magma Fin4 := {| magma_op := refa525_op |}.

Lemma refa525_sat271 : @Equation271 Fin4 refa525_inst.
Proof. unfold Equation271, magma_op, refa525_inst, refa525_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa525_sat283 : @Equation283 Fin4 refa525_inst.
Proof. unfold Equation283, magma_op, refa525_inst, refa525_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa525_sat1029 : @Equation1029 Fin4 refa525_inst.
Proof. unfold Equation1029, magma_op, refa525_inst, refa525_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa525_sat1039 : @Equation1039 Fin4 refa525_inst.
Proof. unfold Equation1039, magma_op, refa525_inst, refa525_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa525_sat1083 : @Equation1083 Fin4 refa525_inst.
Proof. unfold Equation1083, magma_op, refa525_inst, refa525_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa525_sat1110 : @Equation1110 Fin4 refa525_inst.
Proof. unfold Equation1110, magma_op, refa525_inst, refa525_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa525_sat1638 : @Equation1638 Fin4 refa525_inst.
Proof. unfold Equation1638, magma_op, refa525_inst, refa525_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa525_sat1719 : @Equation1719 Fin4 refa525_inst.
Proof. unfold Equation1719, magma_op, refa525_inst, refa525_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa525_sat1851 : @Equation1851 Fin4 refa525_inst.
Proof. unfold Equation1851, magma_op, refa525_inst, refa525_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa525_sat1858 : @Equation1858 Fin4 refa525_inst.
Proof. unfold Equation1858, magma_op, refa525_inst, refa525_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa525_sat1888 : @Equation1888 Fin4 refa525_inst.
Proof. unfold Equation1888, magma_op, refa525_inst, refa525_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa525_sat1895 : @Equation1895 Fin4 refa525_inst.
Proof. unfold Equation1895, magma_op, refa525_inst, refa525_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa525_sat3871 : @Equation3871 Fin4 refa525_inst.
Proof. unfold Equation3871, magma_op, refa525_inst, refa525_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa525_sat3881 : @Equation3881 Fin4 refa525_inst.
Proof. unfold Equation3881, magma_op, refa525_inst, refa525_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa525_sat3927 : @Equation3927 Fin4 refa525_inst.
Proof. unfold Equation3927, magma_op, refa525_inst, refa525_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa525_sat3954 : @Equation3954 Fin4 refa525_inst.
Proof. unfold Equation3954, magma_op, refa525_inst, refa525_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa525_not47 : ~ @Equation47 Fin4 refa525_inst.
Proof. unfold Equation47. intro H. specialize (H F4_1). unfold magma_op, refa525_inst, refa525_op in H. discriminate H. Qed.

Lemma refa525_not99 : ~ @Equation99 Fin4 refa525_inst.
Proof. unfold Equation99. intro H. specialize (H F4_1). unfold magma_op, refa525_inst, refa525_op in H. discriminate H. Qed.

Lemma refa525_not151 : ~ @Equation151 Fin4 refa525_inst.
Proof. unfold Equation151. intro H. specialize (H F4_1). unfold magma_op, refa525_inst, refa525_op in H. discriminate H. Qed.

Lemma refa525_not203 : ~ @Equation203 Fin4 refa525_inst.
Proof. unfold Equation203. intro H. specialize (H F4_1). unfold magma_op, refa525_inst, refa525_op in H. discriminate H. Qed.

Lemma refa525_not261 : ~ @Equation261 Fin4 refa525_inst.
Proof. unfold Equation261. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa525_inst, refa525_op in H. discriminate H. Qed.

Lemma refa525_not307 : ~ @Equation307 Fin4 refa525_inst.
Proof. unfold Equation307. intro H. specialize (H F4_1). unfold magma_op, refa525_inst, refa525_op in H. discriminate H. Qed.

Lemma refa525_not437 : ~ @Equation437 Fin4 refa525_inst.
Proof. unfold Equation437. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa525_inst, refa525_op in H. discriminate H. Qed.

Lemma refa525_not504 : ~ @Equation504 Fin4 refa525_inst.
Proof. unfold Equation504. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa525_inst, refa525_op in H. discriminate H. Qed.

Lemma refa525_not614 : ~ @Equation614 Fin4 refa525_inst.
Proof. unfold Equation614. intro H. specialize (H F4_1). unfold magma_op, refa525_inst, refa525_op in H. discriminate H. Qed.

Lemma refa525_not817 : ~ @Equation817 Fin4 refa525_inst.
Proof. unfold Equation817. intro H. specialize (H F4_1). unfold magma_op, refa525_inst, refa525_op in H. discriminate H. Qed.

Lemma refa525_not1023 : ~ @Equation1023 Fin4 refa525_inst.
Proof. unfold Equation1023. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa525_inst, refa525_op in H. discriminate H. Qed.

Lemma refa525_not1046 : ~ @Equation1046 Fin4 refa525_inst.
Proof. unfold Equation1046. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa525_inst, refa525_op in H. discriminate H. Qed.

Lemma refa525_not1109 : ~ @Equation1109 Fin4 refa525_inst.
Proof. unfold Equation1109. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa525_inst, refa525_op in H. discriminate H. Qed.

Lemma refa525_not1113 : ~ @Equation1113 Fin4 refa525_inst.
Proof. unfold Equation1113. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa525_inst, refa525_op in H. discriminate H. Qed.

Lemma refa525_not1223 : ~ @Equation1223 Fin4 refa525_inst.
Proof. unfold Equation1223. intro H. specialize (H F4_1). unfold magma_op, refa525_inst, refa525_op in H. discriminate H. Qed.

Lemma refa525_not1426 : ~ @Equation1426 Fin4 refa525_inst.
Proof. unfold Equation1426. intro H. specialize (H F4_1). unfold magma_op, refa525_inst, refa525_op in H. discriminate H. Qed.

Lemma refa525_not1631 : ~ @Equation1631 Fin4 refa525_inst.
Proof. unfold Equation1631. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa525_inst, refa525_op in H. discriminate H. Qed.

Lemma refa525_not1632 : ~ @Equation1632 Fin4 refa525_inst.
Proof. unfold Equation1632. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa525_inst, refa525_op in H. discriminate H. Qed.

Lemma refa525_not1634 : ~ @Equation1634 Fin4 refa525_inst.
Proof. unfold Equation1634. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa525_inst, refa525_op in H. discriminate H. Qed.

Lemma refa525_not1637 : ~ @Equation1637 Fin4 refa525_inst.
Proof. unfold Equation1637. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa525_inst, refa525_op in H. discriminate H. Qed.

Lemma refa525_not1654 : ~ @Equation1654 Fin4 refa525_inst.
Proof. unfold Equation1654. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa525_inst, refa525_op in H. discriminate H. Qed.

Lemma refa525_not1838 : ~ @Equation1838 Fin4 refa525_inst.
Proof. unfold Equation1838. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa525_inst, refa525_op in H. discriminate H. Qed.

Lemma refa525_not1848 : ~ @Equation1848 Fin4 refa525_inst.
Proof. unfold Equation1848. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa525_inst, refa525_op in H. discriminate H. Qed.

Lemma refa525_not1860 : ~ @Equation1860 Fin4 refa525_inst.
Proof. unfold Equation1860. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa525_inst, refa525_op in H. discriminate H. Qed.

Lemma refa525_not1861 : ~ @Equation1861 Fin4 refa525_inst.
Proof. unfold Equation1861. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa525_inst, refa525_op in H. discriminate H. Qed.

Lemma refa525_not1925 : ~ @Equation1925 Fin4 refa525_inst.
Proof. unfold Equation1925. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa525_inst, refa525_op in H. discriminate H. Qed.

Lemma refa525_not2035 : ~ @Equation2035 Fin4 refa525_inst.
Proof. unfold Equation2035. intro H. specialize (H F4_1). unfold magma_op, refa525_inst, refa525_op in H. discriminate H. Qed.

Lemma refa525_not2238 : ~ @Equation2238 Fin4 refa525_inst.
Proof. unfold Equation2238. intro H. specialize (H F4_1). unfold magma_op, refa525_inst, refa525_op in H. discriminate H. Qed.

Lemma refa525_not2441 : ~ @Equation2441 Fin4 refa525_inst.
Proof. unfold Equation2441. intro H. specialize (H F4_1). unfold magma_op, refa525_inst, refa525_op in H. discriminate H. Qed.

Lemma refa525_not2644 : ~ @Equation2644 Fin4 refa525_inst.
Proof. unfold Equation2644. intro H. specialize (H F4_1). unfold magma_op, refa525_inst, refa525_op in H. discriminate H. Qed.

Lemma refa525_not2847 : ~ @Equation2847 Fin4 refa525_inst.
Proof. unfold Equation2847. intro H. specialize (H F4_1). unfold magma_op, refa525_inst, refa525_op in H. discriminate H. Qed.

Lemma refa525_not3050 : ~ @Equation3050 Fin4 refa525_inst.
Proof. unfold Equation3050. intro H. specialize (H F4_1). unfold magma_op, refa525_inst, refa525_op in H. discriminate H. Qed.

Lemma refa525_not3279 : ~ @Equation3279 Fin4 refa525_inst.
Proof. unfold Equation3279. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa525_inst, refa525_op in H. discriminate H. Qed.

Lemma refa525_not3345 : ~ @Equation3345 Fin4 refa525_inst.
Proof. unfold Equation3345. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa525_inst, refa525_op in H. discriminate H. Qed.

Lemma refa525_not3456 : ~ @Equation3456 Fin4 refa525_inst.
Proof. unfold Equation3456. intro H. specialize (H F4_1). unfold magma_op, refa525_inst, refa525_op in H. discriminate H. Qed.

Lemma refa525_not3659 : ~ @Equation3659 Fin4 refa525_inst.
Proof. unfold Equation3659. intro H. specialize (H F4_1). unfold magma_op, refa525_inst, refa525_op in H. discriminate H. Qed.

Lemma refa525_not3864 : ~ @Equation3864 Fin4 refa525_inst.
Proof. unfold Equation3864. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa525_inst, refa525_op in H. discriminate H. Qed.

Lemma refa525_not3867 : ~ @Equation3867 Fin4 refa525_inst.
Proof. unfold Equation3867. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa525_inst, refa525_op in H. discriminate H. Qed.

Lemma refa525_not3870 : ~ @Equation3870 Fin4 refa525_inst.
Proof. unfold Equation3870. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa525_inst, refa525_op in H. discriminate H. Qed.

Lemma refa525_not3878 : ~ @Equation3878 Fin4 refa525_inst.
Proof. unfold Equation3878. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa525_inst, refa525_op in H. discriminate H. Qed.

Lemma refa525_not3888 : ~ @Equation3888 Fin4 refa525_inst.
Proof. unfold Equation3888. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa525_inst, refa525_op in H. discriminate H. Qed.

Lemma refa525_not4065 : ~ @Equation4065 Fin4 refa525_inst.
Proof. unfold Equation4065. intro H. specialize (H F4_1). unfold magma_op, refa525_inst, refa525_op in H. discriminate H. Qed.

Lemma refa525_not4269 : ~ @Equation4269 Fin4 refa525_inst.
Proof. unfold Equation4269. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa525_inst, refa525_op in H. discriminate H. Qed.

Lemma refa525_not4270 : ~ @Equation4270 Fin4 refa525_inst.
Proof. unfold Equation4270. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa525_inst, refa525_op in H. discriminate H. Qed.

Lemma refa525_not4283 : ~ @Equation4283 Fin4 refa525_inst.
Proof. unfold Equation4283. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa525_inst, refa525_op in H. discriminate H. Qed.

Lemma refa525_not4284 : ~ @Equation4284 Fin4 refa525_inst.
Proof. unfold Equation4284. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa525_inst, refa525_op in H. discriminate H. Qed.

Lemma refa525_not4314 : ~ @Equation4314 Fin4 refa525_inst.
Proof. unfold Equation4314. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa525_inst, refa525_op in H. discriminate H. Qed.

Lemma refa525_not4321 : ~ @Equation4321 Fin4 refa525_inst.
Proof. unfold Equation4321. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa525_inst, refa525_op in H. discriminate H. Qed.

Lemma refa525_not4343 : ~ @Equation4343 Fin4 refa525_inst.
Proof. unfold Equation4343. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa525_inst, refa525_op in H. discriminate H. Qed.

Lemma refa525_not4380 : ~ @Equation4380 Fin4 refa525_inst.
Proof. unfold Equation4380. intro H. specialize (H F4_1). unfold magma_op, refa525_inst, refa525_op in H. discriminate H. Qed.

Lemma refa525_not4583 : ~ @Equation4583 Fin4 refa525_inst.
Proof. unfold Equation4583. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa525_inst, refa525_op in H. discriminate H. Qed.

Lemma refa525_not4584 : ~ @Equation4584 Fin4 refa525_inst.
Proof. unfold Equation4584. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa525_inst, refa525_op in H. discriminate H. Qed.

Lemma refa525_not4585 : ~ @Equation4585 Fin4 refa525_inst.
Proof. unfold Equation4585. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa525_inst, refa525_op in H. discriminate H. Qed.

Lemma refa525_not4588 : ~ @Equation4588 Fin4 refa525_inst.
Proof. unfold Equation4588. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa525_inst, refa525_op in H. discriminate H. Qed.

Lemma refa525_not4590 : ~ @Equation4590 Fin4 refa525_inst.
Proof. unfold Equation4590. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa525_inst, refa525_op in H. discriminate H. Qed.

Lemma refa525_not4598 : ~ @Equation4598 Fin4 refa525_inst.
Proof. unfold Equation4598. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa525_inst, refa525_op in H. discriminate H. Qed.

Lemma refa525_not4599 : ~ @Equation4599 Fin4 refa525_inst.
Proof. unfold Equation4599. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa525_inst, refa525_op in H. discriminate H. Qed.

(** ---- refa526 (Fin4) ---- *)

Definition refa526_op (x y : Fin4) : Fin4 :=
  match x, y with
  | F4_0, F4_0 => F4_1 | F4_0, F4_1 => F4_0 | F4_0, F4_2 => F4_0 | F4_0, F4_3 => F4_2
  | F4_1, F4_0 => F4_3 | F4_1, F4_1 => F4_1 | F4_1, F4_2 => F4_1 | F4_1, F4_3 => F4_1
  | F4_2, F4_0 => F4_1 | F4_2, F4_1 => F4_2 | F4_2, F4_2 => F4_2 | F4_2, F4_3 => F4_2
  | F4_3, F4_0 => F4_3 | F4_3, F4_1 => F4_3 | F4_3, F4_2 => F4_3 | F4_3, F4_3 => F4_2
  end.

#[local] Instance refa526_inst : Magma Fin4 := {| magma_op := refa526_op |}.

Lemma refa526_sat1056 : @Equation1056 Fin4 refa526_inst.
Proof. unfold Equation1056, magma_op, refa526_inst, refa526_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa526_not1223 : ~ @Equation1223 Fin4 refa526_inst.
Proof. unfold Equation1223. intro H. specialize (H F4_0). unfold magma_op, refa526_inst, refa526_op in H. discriminate H. Qed.

(** ---- refa527 (Fin4) ---- *)

Definition refa527_op (x y : Fin4) : Fin4 :=
  match x, y with
  | F4_0, F4_0 => F4_3 | F4_0, F4_1 => F4_2 | F4_0, F4_2 => F4_1 | F4_0, F4_3 => F4_3
  | F4_1, F4_0 => F4_3 | F4_1, F4_1 => F4_3 | F4_1, F4_2 => F4_2 | F4_1, F4_3 => F4_0
  | F4_2, F4_0 => F4_3 | F4_2, F4_1 => F4_3 | F4_2, F4_2 => F4_3 | F4_2, F4_3 => F4_3
  | F4_3, F4_0 => F4_3 | F4_3, F4_1 => F4_3 | F4_3, F4_2 => F4_3 | F4_3, F4_3 => F4_3
  end.

#[local] Instance refa527_inst : Magma Fin4 := {| magma_op := refa527_op |}.

Lemma refa527_sat4107 : @Equation4107 Fin4 refa527_inst.
Proof. unfold Equation4107, magma_op, refa527_inst, refa527_op. intros x y z w. destruct x, y, z, w; reflexivity. Qed.

Lemma refa527_not3862 : ~ @Equation3862 Fin4 refa527_inst.
Proof. unfold Equation3862. intro H. specialize (H F4_1). unfold magma_op, refa527_inst, refa527_op in H. discriminate H. Qed.

(** ---- refa528 (Fin4) ---- *)

Definition refa528_op (x y : Fin4) : Fin4 :=
  match x, y with
  | F4_0, F4_0 => F4_0 | F4_0, F4_1 => F4_0 | F4_0, F4_2 => F4_3 | F4_0, F4_3 => F4_3
  | F4_1, F4_0 => F4_2 | F4_1, F4_1 => F4_2 | F4_1, F4_2 => F4_1 | F4_1, F4_3 => F4_1
  | F4_2, F4_0 => F4_1 | F4_2, F4_1 => F4_1 | F4_2, F4_2 => F4_2 | F4_2, F4_3 => F4_2
  | F4_3, F4_0 => F4_3 | F4_3, F4_1 => F4_3 | F4_3, F4_2 => F4_0 | F4_3, F4_3 => F4_0
  end.

#[local] Instance refa528_inst : Magma Fin4 := {| magma_op := refa528_op |}.

Lemma refa528_sat1470 : @Equation1470 Fin4 refa528_inst.
Proof. unfold Equation1470, magma_op, refa528_inst, refa528_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa528_not1432 : ~ @Equation1432 Fin4 refa528_inst.
Proof. unfold Equation1432. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa528_inst, refa528_op in H. discriminate H. Qed.

Lemma refa528_not1444 : ~ @Equation1444 Fin4 refa528_inst.
Proof. unfold Equation1444. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa528_inst, refa528_op in H. discriminate H. Qed.

Lemma refa528_not1840 : ~ @Equation1840 Fin4 refa528_inst.
Proof. unfold Equation1840. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa528_inst, refa528_op in H. discriminate H. Qed.

Lemma refa528_not1848 : ~ @Equation1848 Fin4 refa528_inst.
Proof. unfold Equation1848. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa528_inst, refa528_op in H. discriminate H. Qed.

Lemma refa528_not2244 : ~ @Equation2244 Fin4 refa528_inst.
Proof. unfold Equation2244. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa528_inst, refa528_op in H. discriminate H. Qed.

Lemma refa528_not2256 : ~ @Equation2256 Fin4 refa528_inst.
Proof. unfold Equation2256. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa528_inst, refa528_op in H. discriminate H. Qed.

Lemma refa528_not3259 : ~ @Equation3259 Fin4 refa528_inst.
Proof. unfold Equation3259. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa528_inst, refa528_op in H. discriminate H. Qed.

Lemma refa528_not3308 : ~ @Equation3308 Fin4 refa528_inst.
Proof. unfold Equation3308. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa528_inst, refa528_op in H. discriminate H. Qed.

Lemma refa528_not4283 : ~ @Equation4283 Fin4 refa528_inst.
Proof. unfold Equation4283. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa528_inst, refa528_op in H. discriminate H. Qed.

(** ---- refa529 (Fin4) ---- *)

Definition refa529_op (x y : Fin4) : Fin4 :=
  match x, y with
  | F4_0, F4_0 => F4_0 | F4_0, F4_1 => F4_1 | F4_0, F4_2 => F4_1 | F4_0, F4_3 => F4_3
  | F4_1, F4_0 => F4_3 | F4_1, F4_1 => F4_0 | F4_1, F4_2 => F4_3 | F4_1, F4_3 => F4_0
  | F4_2, F4_0 => F4_3 | F4_2, F4_1 => F4_0 | F4_2, F4_2 => F4_3 | F4_2, F4_3 => F4_0
  | F4_3, F4_0 => F4_3 | F4_3, F4_1 => F4_3 | F4_3, F4_2 => F4_0 | F4_3, F4_3 => F4_0
  end.

#[local] Instance refa529_inst : Magma Fin4 := {| magma_op := refa529_op |}.

Lemma refa529_sat3481 : @Equation3481 Fin4 refa529_inst.
Proof. unfold Equation3481, magma_op, refa529_inst, refa529_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa529_not3659 : ~ @Equation3659 Fin4 refa529_inst.
Proof. unfold Equation3659. intro H. specialize (H F4_2). unfold magma_op, refa529_inst, refa529_op in H. discriminate H. Qed.

Lemma refa529_not4065 : ~ @Equation4065 Fin4 refa529_inst.
Proof. unfold Equation4065. intro H. specialize (H F4_2). unfold magma_op, refa529_inst, refa529_op in H. discriminate H. Qed.

(** ---- refa53 (Fin2) ---- *)

Definition refa53_op (x y : Fin2) : Fin2 :=
  match x, y with
  | F2_0, F2_0 => F2_1 | F2_0, F2_1 => F2_0
  | F2_1, F2_0 => F2_1 | F2_1, F2_1 => F2_0
  end.

#[local] Instance refa53_inst : Magma Fin2 := {| magma_op := refa53_op |}.

Lemma refa53_sat13 : @Equation13 Fin2 refa53_inst.
Proof. unfold Equation13, magma_op, refa53_inst, refa53_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa53_not47 : ~ @Equation47 Fin2 refa53_inst.
Proof. unfold Equation47. intro H. specialize (H F2_0). unfold magma_op, refa53_inst, refa53_op in H. discriminate H. Qed.

Lemma refa53_not105 : ~ @Equation105 Fin2 refa53_inst.
Proof. unfold Equation105. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa53_inst, refa53_op in H. discriminate H. Qed.

Lemma refa53_not108 : ~ @Equation108 Fin2 refa53_inst.
Proof. unfold Equation108. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa53_inst, refa53_op in H. discriminate H. Qed.

Lemma refa53_not203 : ~ @Equation203 Fin2 refa53_inst.
Proof. unfold Equation203. intro H. specialize (H F2_0). unfold magma_op, refa53_inst, refa53_op in H. discriminate H. Qed.

Lemma refa53_not255 : ~ @Equation255 Fin2 refa53_inst.
Proof. unfold Equation255. intro H. specialize (H F2_0). unfold magma_op, refa53_inst, refa53_op in H. discriminate H. Qed.

Lemma refa53_not307 : ~ @Equation307 Fin2 refa53_inst.
Proof. unfold Equation307. intro H. specialize (H F2_0). unfold magma_op, refa53_inst, refa53_op in H. discriminate H. Qed.

Lemma refa53_not417 : ~ @Equation417 Fin2 refa53_inst.
Proof. unfold Equation417. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa53_inst, refa53_op in H. discriminate H. Qed.

Lemma refa53_not420 : ~ @Equation420 Fin2 refa53_inst.
Proof. unfold Equation420. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa53_inst, refa53_op in H. discriminate H. Qed.

Lemma refa53_not427 : ~ @Equation427 Fin2 refa53_inst.
Proof. unfold Equation427. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa53_inst, refa53_op in H. discriminate H. Qed.

Lemma refa53_not430 : ~ @Equation430 Fin2 refa53_inst.
Proof. unfold Equation430. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa53_inst, refa53_op in H. discriminate H. Qed.

Lemma refa53_not437 : ~ @Equation437 Fin2 refa53_inst.
Proof. unfold Equation437. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa53_inst, refa53_op in H. discriminate H. Qed.

Lemma refa53_not440 : ~ @Equation440 Fin2 refa53_inst.
Proof. unfold Equation440. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa53_inst, refa53_op in H. discriminate H. Qed.

Lemma refa53_not614 : ~ @Equation614 Fin2 refa53_inst.
Proof. unfold Equation614. intro H. specialize (H F2_0). unfold magma_op, refa53_inst, refa53_op in H. discriminate H. Qed.

Lemma refa53_not817 : ~ @Equation817 Fin2 refa53_inst.
Proof. unfold Equation817. intro H. specialize (H F2_0). unfold magma_op, refa53_inst, refa53_op in H. discriminate H. Qed.

Lemma refa53_not1023 : ~ @Equation1023 Fin2 refa53_inst.
Proof. unfold Equation1023. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa53_inst, refa53_op in H. discriminate H. Qed.

Lemma refa53_not1026 : ~ @Equation1026 Fin2 refa53_inst.
Proof. unfold Equation1026. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa53_inst, refa53_op in H. discriminate H. Qed.

Lemma refa53_not1029 : ~ @Equation1029 Fin2 refa53_inst.
Proof. unfold Equation1029. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa53_inst, refa53_op in H. discriminate H. Qed.

Lemma refa53_not1036 : ~ @Equation1036 Fin2 refa53_inst.
Proof. unfold Equation1036. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa53_inst, refa53_op in H. discriminate H. Qed.

Lemma refa53_not1039 : ~ @Equation1039 Fin2 refa53_inst.
Proof. unfold Equation1039. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa53_inst, refa53_op in H. discriminate H. Qed.

Lemma refa53_not1046 : ~ @Equation1046 Fin2 refa53_inst.
Proof. unfold Equation1046. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa53_inst, refa53_op in H. discriminate H. Qed.

Lemma refa53_not1049 : ~ @Equation1049 Fin2 refa53_inst.
Proof. unfold Equation1049. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa53_inst, refa53_op in H. discriminate H. Qed.

Lemma refa53_not1086 : ~ @Equation1086 Fin2 refa53_inst.
Proof. unfold Equation1086. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa53_inst, refa53_op in H. discriminate H. Qed.

Lemma refa53_not1113 : ~ @Equation1113 Fin2 refa53_inst.
Proof. unfold Equation1113. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa53_inst, refa53_op in H. discriminate H. Qed.

Lemma refa53_not1224 : ~ @Equation1224 Fin2 refa53_inst.
Proof. unfold Equation1224. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa53_inst, refa53_op in H. discriminate H. Qed.

Lemma refa53_not1226 : ~ @Equation1226 Fin2 refa53_inst.
Proof. unfold Equation1226. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa53_inst, refa53_op in H. discriminate H. Qed.

Lemma refa53_not1229 : ~ @Equation1229 Fin2 refa53_inst.
Proof. unfold Equation1229. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa53_inst, refa53_op in H. discriminate H. Qed.

Lemma refa53_not1239 : ~ @Equation1239 Fin2 refa53_inst.
Proof. unfold Equation1239. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa53_inst, refa53_op in H. discriminate H. Qed.

Lemma refa53_not1242 : ~ @Equation1242 Fin2 refa53_inst.
Proof. unfold Equation1242. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa53_inst, refa53_op in H. discriminate H. Qed.

Lemma refa53_not1249 : ~ @Equation1249 Fin2 refa53_inst.
Proof. unfold Equation1249. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa53_inst, refa53_op in H. discriminate H. Qed.

Lemma refa53_not1252 : ~ @Equation1252 Fin2 refa53_inst.
Proof. unfold Equation1252. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa53_inst, refa53_op in H. discriminate H. Qed.

Lemma refa53_not1426 : ~ @Equation1426 Fin2 refa53_inst.
Proof. unfold Equation1426. intro H. specialize (H F2_0). unfold magma_op, refa53_inst, refa53_op in H. discriminate H. Qed.

Lemma refa53_not1632 : ~ @Equation1632 Fin2 refa53_inst.
Proof. unfold Equation1632. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa53_inst, refa53_op in H. discriminate H. Qed.

Lemma refa53_not1635 : ~ @Equation1635 Fin2 refa53_inst.
Proof. unfold Equation1635. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa53_inst, refa53_op in H. discriminate H. Qed.

Lemma refa53_not1638 : ~ @Equation1638 Fin2 refa53_inst.
Proof. unfold Equation1638. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa53_inst, refa53_op in H. discriminate H. Qed.

Lemma refa53_not1648 : ~ @Equation1648 Fin2 refa53_inst.
Proof. unfold Equation1648. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa53_inst, refa53_op in H. discriminate H. Qed.

Lemma refa53_not1655 : ~ @Equation1655 Fin2 refa53_inst.
Proof. unfold Equation1655. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa53_inst, refa53_op in H. discriminate H. Qed.

Lemma refa53_not1722 : ~ @Equation1722 Fin2 refa53_inst.
Proof. unfold Equation1722. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa53_inst, refa53_op in H. discriminate H. Qed.

Lemma refa53_not1833 : ~ @Equation1833 Fin2 refa53_inst.
Proof. unfold Equation1833. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa53_inst, refa53_op in H. discriminate H. Qed.

Lemma refa53_not1838 : ~ @Equation1838 Fin2 refa53_inst.
Proof. unfold Equation1838. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa53_inst, refa53_op in H. discriminate H. Qed.

Lemma refa53_not1841 : ~ @Equation1841 Fin2 refa53_inst.
Proof. unfold Equation1841. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa53_inst, refa53_op in H. discriminate H. Qed.

Lemma refa53_not1848 : ~ @Equation1848 Fin2 refa53_inst.
Proof. unfold Equation1848. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa53_inst, refa53_op in H. discriminate H. Qed.

Lemma refa53_not1851 : ~ @Equation1851 Fin2 refa53_inst.
Proof. unfold Equation1851. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa53_inst, refa53_op in H. discriminate H. Qed.

Lemma refa53_not1858 : ~ @Equation1858 Fin2 refa53_inst.
Proof. unfold Equation1858. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa53_inst, refa53_op in H. discriminate H. Qed.

Lemma refa53_not1861 : ~ @Equation1861 Fin2 refa53_inst.
Proof. unfold Equation1861. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa53_inst, refa53_op in H. discriminate H. Qed.

Lemma refa53_not2036 : ~ @Equation2036 Fin2 refa53_inst.
Proof. unfold Equation2036. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa53_inst, refa53_op in H. discriminate H. Qed.

Lemma refa53_not2038 : ~ @Equation2038 Fin2 refa53_inst.
Proof. unfold Equation2038. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa53_inst, refa53_op in H. discriminate H. Qed.

Lemma refa53_not2041 : ~ @Equation2041 Fin2 refa53_inst.
Proof. unfold Equation2041. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa53_inst, refa53_op in H. discriminate H. Qed.

Lemma refa53_not2044 : ~ @Equation2044 Fin2 refa53_inst.
Proof. unfold Equation2044. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa53_inst, refa53_op in H. discriminate H. Qed.

Lemma refa53_not2238 : ~ @Equation2238 Fin2 refa53_inst.
Proof. unfold Equation2238. intro H. specialize (H F2_0). unfold magma_op, refa53_inst, refa53_op in H. discriminate H. Qed.

Lemma refa53_not2441 : ~ @Equation2441 Fin2 refa53_inst.
Proof. unfold Equation2441. intro H. specialize (H F2_0). unfold magma_op, refa53_inst, refa53_op in H. discriminate H. Qed.

Lemma refa53_not2644 : ~ @Equation2644 Fin2 refa53_inst.
Proof. unfold Equation2644. intro H. specialize (H F2_0). unfold magma_op, refa53_inst, refa53_op in H. discriminate H. Qed.

Lemma refa53_not2847 : ~ @Equation2847 Fin2 refa53_inst.
Proof. unfold Equation2847. intro H. specialize (H F2_0). unfold magma_op, refa53_inst, refa53_op in H. discriminate H. Qed.

Lemma refa53_not3050 : ~ @Equation3050 Fin2 refa53_inst.
Proof. unfold Equation3050. intro H. specialize (H F2_0). unfold magma_op, refa53_inst, refa53_op in H. discriminate H. Qed.

Lemma refa53_not3256 : ~ @Equation3256 Fin2 refa53_inst.
Proof. unfold Equation3256. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa53_inst, refa53_op in H. discriminate H. Qed.

Lemma refa53_not3259 : ~ @Equation3259 Fin2 refa53_inst.
Proof. unfold Equation3259. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa53_inst, refa53_op in H. discriminate H. Qed.

Lemma refa53_not3262 : ~ @Equation3262 Fin2 refa53_inst.
Proof. unfold Equation3262. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa53_inst, refa53_op in H. discriminate H. Qed.

Lemma refa53_not3308 : ~ @Equation3308 Fin2 refa53_inst.
Proof. unfold Equation3308. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa53_inst, refa53_op in H. discriminate H. Qed.

Lemma refa53_not3315 : ~ @Equation3315 Fin2 refa53_inst.
Proof. unfold Equation3315. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa53_inst, refa53_op in H. discriminate H. Qed.

Lemma refa53_not3318 : ~ @Equation3318 Fin2 refa53_inst.
Proof. unfold Equation3318. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa53_inst, refa53_op in H. discriminate H. Qed.

Lemma refa53_not3456 : ~ @Equation3456 Fin2 refa53_inst.
Proof. unfold Equation3456. intro H. specialize (H F2_0). unfold magma_op, refa53_inst, refa53_op in H. discriminate H. Qed.

Lemma refa53_not3659 : ~ @Equation3659 Fin2 refa53_inst.
Proof. unfold Equation3659. intro H. specialize (H F2_0). unfold magma_op, refa53_inst, refa53_op in H. discriminate H. Qed.

Lemma refa53_not3865 : ~ @Equation3865 Fin2 refa53_inst.
Proof. unfold Equation3865. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa53_inst, refa53_op in H. discriminate H. Qed.

Lemma refa53_not3868 : ~ @Equation3868 Fin2 refa53_inst.
Proof. unfold Equation3868. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa53_inst, refa53_op in H. discriminate H. Qed.

Lemma refa53_not3871 : ~ @Equation3871 Fin2 refa53_inst.
Proof. unfold Equation3871. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa53_inst, refa53_op in H. discriminate H. Qed.

Lemma refa53_not3878 : ~ @Equation3878 Fin2 refa53_inst.
Proof. unfold Equation3878. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa53_inst, refa53_op in H. discriminate H. Qed.

Lemma refa53_not3917 : ~ @Equation3917 Fin2 refa53_inst.
Proof. unfold Equation3917. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa53_inst, refa53_op in H. discriminate H. Qed.

Lemma refa53_not3924 : ~ @Equation3924 Fin2 refa53_inst.
Proof. unfold Equation3924. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa53_inst, refa53_op in H. discriminate H. Qed.

Lemma refa53_not3927 : ~ @Equation3927 Fin2 refa53_inst.
Proof. unfold Equation3927. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa53_inst, refa53_op in H. discriminate H. Qed.

Lemma refa53_not4066 : ~ @Equation4066 Fin2 refa53_inst.
Proof. unfold Equation4066. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa53_inst, refa53_op in H. discriminate H. Qed.

Lemma refa53_not4068 : ~ @Equation4068 Fin2 refa53_inst.
Proof. unfold Equation4068. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa53_inst, refa53_op in H. discriminate H. Qed.

Lemma refa53_not4071 : ~ @Equation4071 Fin2 refa53_inst.
Proof. unfold Equation4071. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa53_inst, refa53_op in H. discriminate H. Qed.

Lemma refa53_not4074 : ~ @Equation4074 Fin2 refa53_inst.
Proof. unfold Equation4074. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa53_inst, refa53_op in H. discriminate H. Qed.

Lemma refa53_not4120 : ~ @Equation4120 Fin2 refa53_inst.
Proof. unfold Equation4120. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa53_inst, refa53_op in H. discriminate H. Qed.

Lemma refa53_not4127 : ~ @Equation4127 Fin2 refa53_inst.
Proof. unfold Equation4127. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa53_inst, refa53_op in H. discriminate H. Qed.

Lemma refa53_not4130 : ~ @Equation4130 Fin2 refa53_inst.
Proof. unfold Equation4130. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa53_inst, refa53_op in H. discriminate H. Qed.

Lemma refa53_not4268 : ~ @Equation4268 Fin2 refa53_inst.
Proof. unfold Equation4268. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa53_inst, refa53_op in H. discriminate H. Qed.

Lemma refa53_not4270 : ~ @Equation4270 Fin2 refa53_inst.
Proof. unfold Equation4270. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa53_inst, refa53_op in H. discriminate H. Qed.

Lemma refa53_not4273 : ~ @Equation4273 Fin2 refa53_inst.
Proof. unfold Equation4273. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa53_inst, refa53_op in H. discriminate H. Qed.

Lemma refa53_not4283 : ~ @Equation4283 Fin2 refa53_inst.
Proof. unfold Equation4283. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa53_inst, refa53_op in H. discriminate H. Qed.

Lemma refa53_not4314 : ~ @Equation4314 Fin2 refa53_inst.
Proof. unfold Equation4314. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa53_inst, refa53_op in H. discriminate H. Qed.

Lemma refa53_not4380 : ~ @Equation4380 Fin2 refa53_inst.
Proof. unfold Equation4380. intro H. specialize (H F2_0). unfold magma_op, refa53_inst, refa53_op in H. discriminate H. Qed.

Lemma refa53_not4583 : ~ @Equation4583 Fin2 refa53_inst.
Proof. unfold Equation4583. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa53_inst, refa53_op in H. discriminate H. Qed.

Lemma refa53_not4585 : ~ @Equation4585 Fin2 refa53_inst.
Proof. unfold Equation4585. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa53_inst, refa53_op in H. discriminate H. Qed.

Lemma refa53_not4591 : ~ @Equation4591 Fin2 refa53_inst.
Proof. unfold Equation4591. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa53_inst, refa53_op in H. discriminate H. Qed.

Lemma refa53_not4598 : ~ @Equation4598 Fin2 refa53_inst.
Proof. unfold Equation4598. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa53_inst, refa53_op in H. discriminate H. Qed.

Lemma refa53_not4605 : ~ @Equation4605 Fin2 refa53_inst.
Proof. unfold Equation4605. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa53_inst, refa53_op in H. discriminate H. Qed.

Lemma refa53_not4629 : ~ @Equation4629 Fin2 refa53_inst.
Proof. unfold Equation4629. intro H. specialize (H F2_0 F2_1). unfold magma_op, refa53_inst, refa53_op in H. discriminate H. Qed.

(** ---- refa530 (Fin4) ---- *)

Definition refa530_op (x y : Fin4) : Fin4 :=
  match x, y with
  | F4_0, F4_0 => F4_0 | F4_0, F4_1 => F4_3 | F4_0, F4_2 => F4_1 | F4_0, F4_3 => F4_3
  | F4_1, F4_0 => F4_3 | F4_1, F4_1 => F4_0 | F4_1, F4_2 => F4_3 | F4_1, F4_3 => F4_1
  | F4_2, F4_0 => F4_2 | F4_2, F4_1 => F4_2 | F4_2, F4_2 => F4_3 | F4_2, F4_3 => F4_1
  | F4_3, F4_0 => F4_0 | F4_3, F4_1 => F4_3 | F4_3, F4_2 => F4_0 | F4_3, F4_3 => F4_3
  end.

#[local] Instance refa530_inst : Magma Fin4 := {| magma_op := refa530_op |}.

Lemma refa530_sat1262 : @Equation1262 Fin4 refa530_inst.
Proof. unfold Equation1262, magma_op, refa530_inst, refa530_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa530_not1225 : ~ @Equation1225 Fin4 refa530_inst.
Proof. unfold Equation1225. intro H. specialize (H F4_0 F4_2). unfold magma_op, refa530_inst, refa530_op in H. discriminate H. Qed.

Lemma refa530_not1248 : ~ @Equation1248 Fin4 refa530_inst.
Proof. unfold Equation1248. intro H. specialize (H F4_2 F4_0). unfold magma_op, refa530_inst, refa530_op in H. discriminate H. Qed.

(** ---- refa531 (Fin4) ---- *)

Definition refa531_op (x y : Fin4) : Fin4 :=
  match x, y with
  | F4_0, F4_0 => F4_3 | F4_0, F4_1 => F4_1 | F4_0, F4_2 => F4_3 | F4_0, F4_3 => F4_1
  | F4_1, F4_0 => F4_3 | F4_1, F4_1 => F4_1 | F4_1, F4_2 => F4_3 | F4_1, F4_3 => F4_1
  | F4_2, F4_0 => F4_2 | F4_2, F4_1 => F4_0 | F4_2, F4_2 => F4_2 | F4_2, F4_3 => F4_0
  | F4_3, F4_0 => F4_2 | F4_3, F4_1 => F4_2 | F4_3, F4_2 => F4_2 | F4_3, F4_3 => F4_0
  end.

#[local] Instance refa531_inst : Magma Fin4 := {| magma_op := refa531_op |}.

Lemma refa531_sat2089 : @Equation2089 Fin4 refa531_inst.
Proof. unfold Equation2089, magma_op, refa531_inst, refa531_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa531_not3456 : ~ @Equation3456 Fin4 refa531_inst.
Proof. unfold Equation3456. intro H. specialize (H F4_3). unfold magma_op, refa531_inst, refa531_op in H. discriminate H. Qed.

Lemma refa531_not3877 : ~ @Equation3877 Fin4 refa531_inst.
Proof. unfold Equation3877. intro H. specialize (H F4_1 F4_3). unfold magma_op, refa531_inst, refa531_op in H. discriminate H. Qed.

Lemma refa531_not3880 : ~ @Equation3880 Fin4 refa531_inst.
Proof. unfold Equation3880. intro H. specialize (H F4_0 F4_3). unfold magma_op, refa531_inst, refa531_op in H. discriminate H. Qed.

Lemma refa531_not3915 : ~ @Equation3915 Fin4 refa531_inst.
Proof. unfold Equation3915. intro H. specialize (H F4_3 F4_1). unfold magma_op, refa531_inst, refa531_op in H. discriminate H. Qed.

Lemma refa531_not3918 : ~ @Equation3918 Fin4 refa531_inst.
Proof. unfold Equation3918. intro H. specialize (H F4_3 F4_1). unfold magma_op, refa531_inst, refa531_op in H. discriminate H. Qed.

Lemma refa531_not3952 : ~ @Equation3952 Fin4 refa531_inst.
Proof. unfold Equation3952. intro H. specialize (H F4_1 F4_3). unfold magma_op, refa531_inst, refa531_op in H. discriminate H. Qed.

Lemma refa531_not3955 : ~ @Equation3955 Fin4 refa531_inst.
Proof. unfold Equation3955. intro H. specialize (H F4_0 F4_3). unfold magma_op, refa531_inst, refa531_op in H. discriminate H. Qed.

Lemma refa531_not4314 : ~ @Equation4314 Fin4 refa531_inst.
Proof. unfold Equation4314. intro H. specialize (H F4_3 F4_0). unfold magma_op, refa531_inst, refa531_op in H. discriminate H. Qed.

Lemma refa531_not4606 : ~ @Equation4606 Fin4 refa531_inst.
Proof. unfold Equation4606. intro H. specialize (H F4_1 F4_3). unfold magma_op, refa531_inst, refa531_op in H. discriminate H. Qed.

Lemma refa531_not4666 : ~ @Equation4666 Fin4 refa531_inst.
Proof. unfold Equation4666. intro H. specialize (H F4_0 F4_1 F4_3). unfold magma_op, refa531_inst, refa531_op in H. discriminate H. Qed.

(** ---- refa532 (Fin4) ---- *)

Definition refa532_op (x y : Fin4) : Fin4 :=
  match x, y with
  | F4_0, F4_0 => F4_3 | F4_0, F4_1 => F4_2 | F4_0, F4_2 => F4_0 | F4_0, F4_3 => F4_3
  | F4_1, F4_0 => F4_3 | F4_1, F4_1 => F4_2 | F4_1, F4_2 => F4_1 | F4_1, F4_3 => F4_1
  | F4_2, F4_0 => F4_2 | F4_2, F4_1 => F4_1 | F4_2, F4_2 => F4_2 | F4_2, F4_3 => F4_2
  | F4_3, F4_0 => F4_1 | F4_3, F4_1 => F4_2 | F4_3, F4_2 => F4_3 | F4_3, F4_3 => F4_1
  end.

#[local] Instance refa532_inst : Magma Fin4 := {| magma_op := refa532_op |}.

Lemma refa532_sat643 : @Equation643 Fin4 refa532_inst.
Proof. unfold Equation643, magma_op, refa532_inst, refa532_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa532_not817 : ~ @Equation817 Fin4 refa532_inst.
Proof. unfold Equation817. intro H. specialize (H F4_0). unfold magma_op, refa532_inst, refa532_op in H. discriminate H. Qed.

Lemma refa532_not2441 : ~ @Equation2441 Fin4 refa532_inst.
Proof. unfold Equation2441. intro H. specialize (H F4_0). unfold magma_op, refa532_inst, refa532_op in H. discriminate H. Qed.

Lemma refa532_not2644 : ~ @Equation2644 Fin4 refa532_inst.
Proof. unfold Equation2644. intro H. specialize (H F4_0). unfold magma_op, refa532_inst, refa532_op in H. discriminate H. Qed.

(** ---- refa533 (Fin4) ---- *)

Definition refa533_op (x y : Fin4) : Fin4 :=
  match x, y with
  | F4_0, F4_0 => F4_1 | F4_0, F4_1 => F4_3 | F4_0, F4_2 => F4_0 | F4_0, F4_3 => F4_3
  | F4_1, F4_0 => F4_3 | F4_1, F4_1 => F4_2 | F4_1, F4_2 => F4_1 | F4_1, F4_3 => F4_2
  | F4_2, F4_0 => F4_2 | F4_2, F4_1 => F4_2 | F4_2, F4_2 => F4_2 | F4_2, F4_3 => F4_2
  | F4_3, F4_0 => F4_2 | F4_3, F4_1 => F4_1 | F4_3, F4_2 => F4_3 | F4_3, F4_3 => F4_1
  end.

#[local] Instance refa533_inst : Magma Fin4 := {| magma_op := refa533_op |}.

Lemma refa533_sat1242 : @Equation1242 Fin4 refa533_inst.
Proof. unfold Equation1242, magma_op, refa533_inst, refa533_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa533_not99 : ~ @Equation99 Fin4 refa533_inst.
Proof. unfold Equation99. intro H. specialize (H F4_0). unfold magma_op, refa533_inst, refa533_op in H. discriminate H. Qed.

(** ---- refa534 (Fin4) ---- *)

Definition refa534_op (x y : Fin4) : Fin4 :=
  match x, y with
  | F4_0, F4_0 => F4_2 | F4_0, F4_1 => F4_1 | F4_0, F4_2 => F4_0 | F4_0, F4_3 => F4_1
  | F4_1, F4_0 => F4_2 | F4_1, F4_1 => F4_2 | F4_1, F4_2 => F4_1 | F4_1, F4_3 => F4_1
  | F4_2, F4_0 => F4_2 | F4_2, F4_1 => F4_2 | F4_2, F4_2 => F4_2 | F4_2, F4_3 => F4_2
  | F4_3, F4_0 => F4_2 | F4_3, F4_1 => F4_2 | F4_3, F4_2 => F4_3 | F4_3, F4_3 => F4_2
  end.

#[local] Instance refa534_inst : Magma Fin4 := {| magma_op := refa534_op |}.

Lemma refa534_sat1271 : @Equation1271 Fin4 refa534_inst.
Proof. unfold Equation1271, magma_op, refa534_inst, refa534_op. intros x y z w. destruct x, y, z, w; reflexivity. Qed.

Lemma refa534_not1023 : ~ @Equation1023 Fin4 refa534_inst.
Proof. unfold Equation1023. intro H. specialize (H F4_0 F4_3). unfold magma_op, refa534_inst, refa534_op in H. discriminate H. Qed.

Lemma refa534_not1045 : ~ @Equation1045 Fin4 refa534_inst.
Proof. unfold Equation1045. intro H. specialize (H F4_3 F4_0). unfold magma_op, refa534_inst, refa534_op in H. discriminate H. Qed.

(** ---- refa535 (Fin4) ---- *)

Definition refa535_op (x y : Fin4) : Fin4 :=
  match x, y with
  | F4_0, F4_0 => F4_2 | F4_0, F4_1 => F4_3 | F4_0, F4_2 => F4_0 | F4_0, F4_3 => F4_0
  | F4_1, F4_0 => F4_3 | F4_1, F4_1 => F4_2 | F4_1, F4_2 => F4_1 | F4_1, F4_3 => F4_1
  | F4_2, F4_0 => F4_2 | F4_2, F4_1 => F4_2 | F4_2, F4_2 => F4_2 | F4_2, F4_3 => F4_2
  | F4_3, F4_0 => F4_3 | F4_3, F4_1 => F4_3 | F4_3, F4_2 => F4_3 | F4_3, F4_3 => F4_2
  end.

#[local] Instance refa535_inst : Magma Fin4 := {| magma_op := refa535_op |}.

Lemma refa535_sat434 : @Equation434 Fin4 refa535_inst.
Proof. unfold Equation434, magma_op, refa535_inst, refa535_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa535_not838 : ~ @Equation838 Fin4 refa535_inst.
Proof. unfold Equation838. intro H. specialize (H F4_3 F4_0 F4_1). unfold magma_op, refa535_inst, refa535_op in H. discriminate H. Qed.

Lemma refa535_not1053 : ~ @Equation1053 Fin4 refa535_inst.
Proof. unfold Equation1053. intro H. specialize (H F4_3 F4_0 F4_1). unfold magma_op, refa535_inst, refa535_op in H. discriminate H. Qed.

Lemma refa535_not1056 : ~ @Equation1056 Fin4 refa535_inst.
Proof. unfold Equation1056. intro H. specialize (H F4_3 F4_0 F4_1). unfold magma_op, refa535_inst, refa535_op in H. discriminate H. Qed.

Lemma refa535_not1240 : ~ @Equation1240 Fin4 refa535_inst.
Proof. unfold Equation1240. intro H. specialize (H F4_3 F4_0 F4_1). unfold magma_op, refa535_inst, refa535_op in H. discriminate H. Qed.

Lemma refa535_not1245 : ~ @Equation1245 Fin4 refa535_inst.
Proof. unfold Equation1245. intro H. specialize (H F4_3 F4_0 F4_1). unfold magma_op, refa535_inst, refa535_op in H. discriminate H. Qed.

Lemma refa535_not1263 : ~ @Equation1263 Fin4 refa535_inst.
Proof. unfold Equation1263. intro H. specialize (H F4_3 F4_0 F4_1). unfold magma_op, refa535_inst, refa535_op in H. discriminate H. Qed.

Lemma refa535_not1264 : ~ @Equation1264 Fin4 refa535_inst.
Proof. unfold Equation1264. intro H. specialize (H F4_3 F4_0 F4_1). unfold magma_op, refa535_inst, refa535_op in H. discriminate H. Qed.

Lemma refa535_not1267 : ~ @Equation1267 Fin4 refa535_inst.
Proof. unfold Equation1267. intro H. specialize (H F4_3 F4_0 F4_1). unfold magma_op, refa535_inst, refa535_op in H. discriminate H. Qed.

Lemma refa535_not3306 : ~ @Equation3306 Fin4 refa535_inst.
Proof. unfold Equation3306. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa535_inst, refa535_op in H. discriminate H. Qed.

Lemma refa535_not3321 : ~ @Equation3321 Fin4 refa535_inst.
Proof. unfold Equation3321. intro H. specialize (H F4_3 F4_0 F4_1). unfold magma_op, refa535_inst, refa535_op in H. discriminate H. Qed.

Lemma refa535_not3724 : ~ @Equation3724 Fin4 refa535_inst.
Proof. unfold Equation3724. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa535_inst, refa535_op in H. discriminate H. Qed.

Lemma refa535_not3931 : ~ @Equation3931 Fin4 refa535_inst.
Proof. unfold Equation3931. intro H. specialize (H F4_3 F4_0 F4_1). unfold magma_op, refa535_inst, refa535_op in H. discriminate H. Qed.

(** ---- refa536 (Fin4) ---- *)

Definition refa536_op (x y : Fin4) : Fin4 :=
  match x, y with
  | F4_0, F4_0 => F4_1 | F4_0, F4_1 => F4_0 | F4_0, F4_2 => F4_2 | F4_0, F4_3 => F4_1
  | F4_1, F4_0 => F4_3 | F4_1, F4_1 => F4_2 | F4_1, F4_2 => F4_1 | F4_1, F4_3 => F4_2
  | F4_2, F4_0 => F4_2 | F4_2, F4_1 => F4_1 | F4_2, F4_2 => F4_0 | F4_2, F4_3 => F4_3
  | F4_3, F4_0 => F4_3 | F4_3, F4_1 => F4_0 | F4_3, F4_2 => F4_1 | F4_3, F4_3 => F4_0
  end.

#[local] Instance refa536_inst : Magma Fin4 := {| magma_op := refa536_op |}.

Lemma refa536_sat2097 : @Equation2097 Fin4 refa536_inst.
Proof. unfold Equation2097, magma_op, refa536_inst, refa536_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa536_not3955 : ~ @Equation3955 Fin4 refa536_inst.
Proof. unfold Equation3955. intro H. specialize (H F4_2 F4_3). unfold magma_op, refa536_inst, refa536_op in H. discriminate H. Qed.

(** ---- refa537 (Fin4) ---- *)

Definition refa537_op (x y : Fin4) : Fin4 :=
  match x, y with
  | F4_0, F4_0 => F4_0 | F4_0, F4_1 => F4_0 | F4_0, F4_2 => F4_0 | F4_0, F4_3 => F4_0
  | F4_1, F4_0 => F4_2 | F4_1, F4_1 => F4_1 | F4_1, F4_2 => F4_1 | F4_1, F4_3 => F4_1
  | F4_2, F4_0 => F4_3 | F4_2, F4_1 => F4_2 | F4_2, F4_2 => F4_2 | F4_2, F4_3 => F4_2
  | F4_3, F4_0 => F4_1 | F4_3, F4_1 => F4_3 | F4_3, F4_2 => F4_3 | F4_3, F4_3 => F4_3
  end.

#[local] Instance refa537_inst : Magma Fin4 := {| magma_op := refa537_op |}.

Lemma refa537_sat1237 : @Equation1237 Fin4 refa537_inst.
Proof. unfold Equation1237, magma_op, refa537_inst, refa537_op. intros x y z w. destruct x, y, z, w; reflexivity. Qed.

Lemma refa537_sat2887 : @Equation2887 Fin4 refa537_inst.
Proof. unfold Equation2887, magma_op, refa537_inst, refa537_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa537_sat3069 : @Equation3069 Fin4 refa537_inst.
Proof. unfold Equation3069, magma_op, refa537_inst, refa537_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa537_sat3076 : @Equation3076 Fin4 refa537_inst.
Proof. unfold Equation3076, magma_op, refa537_inst, refa537_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa537_sat3716 : @Equation3716 Fin4 refa537_inst.
Proof. unfold Equation3716, magma_op, refa537_inst, refa537_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa537_sat3930 : @Equation3930 Fin4 refa537_inst.
Proof. unfold Equation3930, magma_op, refa537_inst, refa537_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa537_not261 : ~ @Equation261 Fin4 refa537_inst.
Proof. unfold Equation261. intro H. specialize (H F4_1 F4_0). unfold magma_op, refa537_inst, refa537_op in H. discriminate H. Qed.

Lemma refa537_not263 : ~ @Equation263 Fin4 refa537_inst.
Proof. unfold Equation263. intro H. specialize (H F4_1 F4_0). unfold magma_op, refa537_inst, refa537_op in H. discriminate H. Qed.

Lemma refa537_not2037 : ~ @Equation2037 Fin4 refa537_inst.
Proof. unfold Equation2037. intro H. specialize (H F4_1 F4_0). unfold magma_op, refa537_inst, refa537_op in H. discriminate H. Qed.

Lemma refa537_not2038 : ~ @Equation2038 Fin4 refa537_inst.
Proof. unfold Equation2038. intro H. specialize (H F4_1 F4_0). unfold magma_op, refa537_inst, refa537_op in H. discriminate H. Qed.

Lemma refa537_not2040 : ~ @Equation2040 Fin4 refa537_inst.
Proof. unfold Equation2040. intro H. specialize (H F4_1 F4_0). unfold magma_op, refa537_inst, refa537_op in H. discriminate H. Qed.

Lemma refa537_not2041 : ~ @Equation2041 Fin4 refa537_inst.
Proof. unfold Equation2041. intro H. specialize (H F4_1 F4_0). unfold magma_op, refa537_inst, refa537_op in H. discriminate H. Qed.

Lemma refa537_not2043 : ~ @Equation2043 Fin4 refa537_inst.
Proof. unfold Equation2043. intro H. specialize (H F4_1 F4_0). unfold magma_op, refa537_inst, refa537_op in H. discriminate H. Qed.

Lemma refa537_not2044 : ~ @Equation2044 Fin4 refa537_inst.
Proof. unfold Equation2044. intro H. specialize (H F4_1 F4_0). unfold magma_op, refa537_inst, refa537_op in H. discriminate H. Qed.

Lemma refa537_not2050 : ~ @Equation2050 Fin4 refa537_inst.
Proof. unfold Equation2050. intro H. specialize (H F4_1 F4_0). unfold magma_op, refa537_inst, refa537_op in H. discriminate H. Qed.

Lemma refa537_not2053 : ~ @Equation2053 Fin4 refa537_inst.
Proof. unfold Equation2053. intro H. specialize (H F4_1 F4_0). unfold magma_op, refa537_inst, refa537_op in H. discriminate H. Qed.

Lemma refa537_not2054 : ~ @Equation2054 Fin4 refa537_inst.
Proof. unfold Equation2054. intro H. specialize (H F4_1 F4_0). unfold magma_op, refa537_inst, refa537_op in H. discriminate H. Qed.

Lemma refa537_not2060 : ~ @Equation2060 Fin4 refa537_inst.
Proof. unfold Equation2060. intro H. specialize (H F4_1 F4_0). unfold magma_op, refa537_inst, refa537_op in H. discriminate H. Qed.

Lemma refa537_not2061 : ~ @Equation2061 Fin4 refa537_inst.
Proof. unfold Equation2061. intro H. specialize (H F4_1 F4_0). unfold magma_op, refa537_inst, refa537_op in H. discriminate H. Qed.

Lemma refa537_not2647 : ~ @Equation2647 Fin4 refa537_inst.
Proof. unfold Equation2647. intro H. specialize (H F4_1 F4_0). unfold magma_op, refa537_inst, refa537_op in H. discriminate H. Qed.

Lemma refa537_not2649 : ~ @Equation2649 Fin4 refa537_inst.
Proof. unfold Equation2649. intro H. specialize (H F4_1 F4_0). unfold magma_op, refa537_inst, refa537_op in H. discriminate H. Qed.

Lemma refa537_not2650 : ~ @Equation2650 Fin4 refa537_inst.
Proof. unfold Equation2650. intro H. specialize (H F4_1 F4_0). unfold magma_op, refa537_inst, refa537_op in H. discriminate H. Qed.

Lemma refa537_not2652 : ~ @Equation2652 Fin4 refa537_inst.
Proof. unfold Equation2652. intro H. specialize (H F4_1 F4_0). unfold magma_op, refa537_inst, refa537_op in H. discriminate H. Qed.

Lemma refa537_not2659 : ~ @Equation2659 Fin4 refa537_inst.
Proof. unfold Equation2659. intro H. specialize (H F4_1 F4_0). unfold magma_op, refa537_inst, refa537_op in H. discriminate H. Qed.

Lemma refa537_not2660 : ~ @Equation2660 Fin4 refa537_inst.
Proof. unfold Equation2660. intro H. specialize (H F4_1 F4_0). unfold magma_op, refa537_inst, refa537_op in H. discriminate H. Qed.

Lemma refa537_not2662 : ~ @Equation2662 Fin4 refa537_inst.
Proof. unfold Equation2662. intro H. specialize (H F4_1 F4_0). unfold magma_op, refa537_inst, refa537_op in H. discriminate H. Qed.

Lemma refa537_not2669 : ~ @Equation2669 Fin4 refa537_inst.
Proof. unfold Equation2669. intro H. specialize (H F4_1 F4_0). unfold magma_op, refa537_inst, refa537_op in H. discriminate H. Qed.

Lemma refa537_not2672 : ~ @Equation2672 Fin4 refa537_inst.
Proof. unfold Equation2672. intro H. specialize (H F4_1 F4_0). unfold magma_op, refa537_inst, refa537_op in H. discriminate H. Qed.

Lemma refa537_not2849 : ~ @Equation2849 Fin4 refa537_inst.
Proof. unfold Equation2849. intro H. specialize (H F4_1 F4_0). unfold magma_op, refa537_inst, refa537_op in H. discriminate H. Qed.

Lemma refa537_not2853 : ~ @Equation2853 Fin4 refa537_inst.
Proof. unfold Equation2853. intro H. specialize (H F4_1 F4_0). unfold magma_op, refa537_inst, refa537_op in H. discriminate H. Qed.

Lemma refa537_not2855 : ~ @Equation2855 Fin4 refa537_inst.
Proof. unfold Equation2855. intro H. specialize (H F4_1 F4_0). unfold magma_op, refa537_inst, refa537_op in H. discriminate H. Qed.

Lemma refa537_not2856 : ~ @Equation2856 Fin4 refa537_inst.
Proof. unfold Equation2856. intro H. specialize (H F4_1 F4_0). unfold magma_op, refa537_inst, refa537_op in H. discriminate H. Qed.

Lemma refa537_not2862 : ~ @Equation2862 Fin4 refa537_inst.
Proof. unfold Equation2862. intro H. specialize (H F4_1 F4_0). unfold magma_op, refa537_inst, refa537_op in H. discriminate H. Qed.

Lemma refa537_not2863 : ~ @Equation2863 Fin4 refa537_inst.
Proof. unfold Equation2863. intro H. specialize (H F4_1 F4_0). unfold magma_op, refa537_inst, refa537_op in H. discriminate H. Qed.

Lemma refa537_not2865 : ~ @Equation2865 Fin4 refa537_inst.
Proof. unfold Equation2865. intro H. specialize (H F4_1 F4_0). unfold magma_op, refa537_inst, refa537_op in H. discriminate H. Qed.

Lemma refa537_not2872 : ~ @Equation2872 Fin4 refa537_inst.
Proof. unfold Equation2872. intro H. specialize (H F4_1 F4_0). unfold magma_op, refa537_inst, refa537_op in H. discriminate H. Qed.

Lemma refa537_not2873 : ~ @Equation2873 Fin4 refa537_inst.
Proof. unfold Equation2873. intro H. specialize (H F4_1 F4_0). unfold magma_op, refa537_inst, refa537_op in H. discriminate H. Qed.

Lemma refa537_not2875 : ~ @Equation2875 Fin4 refa537_inst.
Proof. unfold Equation2875. intro H. specialize (H F4_1 F4_0). unfold magma_op, refa537_inst, refa537_op in H. discriminate H. Qed.

Lemma refa537_not3258 : ~ @Equation3258 Fin4 refa537_inst.
Proof. unfold Equation3258. intro H. specialize (H F4_1 F4_0). unfold magma_op, refa537_inst, refa537_op in H. discriminate H. Qed.

Lemma refa537_not3259 : ~ @Equation3259 Fin4 refa537_inst.
Proof. unfold Equation3259. intro H. specialize (H F4_1 F4_0). unfold magma_op, refa537_inst, refa537_op in H. discriminate H. Qed.

Lemma refa537_not3261 : ~ @Equation3261 Fin4 refa537_inst.
Proof. unfold Equation3261. intro H. specialize (H F4_1 F4_0). unfold magma_op, refa537_inst, refa537_op in H. discriminate H. Qed.

Lemma refa537_not3262 : ~ @Equation3262 Fin4 refa537_inst.
Proof. unfold Equation3262. intro H. specialize (H F4_1 F4_0). unfold magma_op, refa537_inst, refa537_op in H. discriminate H. Qed.

Lemma refa537_not3306 : ~ @Equation3306 Fin4 refa537_inst.
Proof. unfold Equation3306. intro H. specialize (H F4_1 F4_0). unfold magma_op, refa537_inst, refa537_op in H. discriminate H. Qed.

Lemma refa537_not3308 : ~ @Equation3308 Fin4 refa537_inst.
Proof. unfold Equation3308. intro H. specialize (H F4_1 F4_0). unfold magma_op, refa537_inst, refa537_op in H. discriminate H. Qed.

Lemma refa537_not3309 : ~ @Equation3309 Fin4 refa537_inst.
Proof. unfold Equation3309. intro H. specialize (H F4_1 F4_0). unfold magma_op, refa537_inst, refa537_op in H. discriminate H. Qed.

Lemma refa537_not3461 : ~ @Equation3461 Fin4 refa537_inst.
Proof. unfold Equation3461. intro H. specialize (H F4_1 F4_0). unfold magma_op, refa537_inst, refa537_op in H. discriminate H. Qed.

Lemma refa537_not3462 : ~ @Equation3462 Fin4 refa537_inst.
Proof. unfold Equation3462. intro H. specialize (H F4_1 F4_0). unfold magma_op, refa537_inst, refa537_op in H. discriminate H. Qed.

Lemma refa537_not3464 : ~ @Equation3464 Fin4 refa537_inst.
Proof. unfold Equation3464. intro H. specialize (H F4_1 F4_0). unfold magma_op, refa537_inst, refa537_op in H. discriminate H. Qed.

Lemma refa537_not3465 : ~ @Equation3465 Fin4 refa537_inst.
Proof. unfold Equation3465. intro H. specialize (H F4_1 F4_0). unfold magma_op, refa537_inst, refa537_op in H. discriminate H. Qed.

Lemma refa537_not3509 : ~ @Equation3509 Fin4 refa537_inst.
Proof. unfold Equation3509. intro H. specialize (H F4_1 F4_0). unfold magma_op, refa537_inst, refa537_op in H. discriminate H. Qed.

Lemma refa537_not3511 : ~ @Equation3511 Fin4 refa537_inst.
Proof. unfold Equation3511. intro H. specialize (H F4_1 F4_0). unfold magma_op, refa537_inst, refa537_op in H. discriminate H. Qed.

Lemma refa537_not3512 : ~ @Equation3512 Fin4 refa537_inst.
Proof. unfold Equation3512. intro H. specialize (H F4_1 F4_0). unfold magma_op, refa537_inst, refa537_op in H. discriminate H. Qed.

Lemma refa537_not4131 : ~ @Equation4131 Fin4 refa537_inst.
Proof. unfold Equation4131. intro H. specialize (H F4_1 F4_0). unfold magma_op, refa537_inst, refa537_op in H. discriminate H. Qed.

Lemma refa537_not4269 : ~ @Equation4269 Fin4 refa537_inst.
Proof. unfold Equation4269. intro H. specialize (H F4_1 F4_0). unfold magma_op, refa537_inst, refa537_op in H. discriminate H. Qed.

Lemma refa537_not4270 : ~ @Equation4270 Fin4 refa537_inst.
Proof. unfold Equation4270. intro H. specialize (H F4_1 F4_0). unfold magma_op, refa537_inst, refa537_op in H. discriminate H. Qed.

Lemma refa537_not4283 : ~ @Equation4283 Fin4 refa537_inst.
Proof. unfold Equation4283. intro H. specialize (H F4_1 F4_0). unfold magma_op, refa537_inst, refa537_op in H. discriminate H. Qed.

Lemma refa537_not4284 : ~ @Equation4284 Fin4 refa537_inst.
Proof. unfold Equation4284. intro H. specialize (H F4_1 F4_0). unfold magma_op, refa537_inst, refa537_op in H. discriminate H. Qed.

Lemma refa537_not4597 : ~ @Equation4597 Fin4 refa537_inst.
Proof. unfold Equation4597. intro H. specialize (H F4_1 F4_0 F4_1). unfold magma_op, refa537_inst, refa537_op in H. discriminate H. Qed.

Lemma refa537_not4599 : ~ @Equation4599 Fin4 refa537_inst.
Proof. unfold Equation4599. intro H. specialize (H F4_1 F4_0). unfold magma_op, refa537_inst, refa537_op in H. discriminate H. Qed.

Lemma refa537_not4629 : ~ @Equation4629 Fin4 refa537_inst.
Proof. unfold Equation4629. intro H. specialize (H F4_1 F4_0). unfold magma_op, refa537_inst, refa537_op in H. discriminate H. Qed.

Lemma refa537_not4631 : ~ @Equation4631 Fin4 refa537_inst.
Proof. unfold Equation4631. intro H. specialize (H F4_1 F4_0 F4_1). unfold magma_op, refa537_inst, refa537_op in H. discriminate H. Qed.

Lemma refa537_not4656 : ~ @Equation4656 Fin4 refa537_inst.
Proof. unfold Equation4656. intro H. specialize (H F4_1 F4_0 F4_1). unfold magma_op, refa537_inst, refa537_op in H. discriminate H. Qed.

(** ---- refa538 (Fin4) ---- *)

Definition refa538_op (x y : Fin4) : Fin4 :=
  match x, y with
  | F4_0, F4_0 => F4_3 | F4_0, F4_1 => F4_1 | F4_0, F4_2 => F4_1 | F4_0, F4_3 => F4_3
  | F4_1, F4_0 => F4_3 | F4_1, F4_1 => F4_2 | F4_1, F4_2 => F4_3 | F4_1, F4_3 => F4_3
  | F4_2, F4_0 => F4_0 | F4_2, F4_1 => F4_3 | F4_2, F4_2 => F4_3 | F4_2, F4_3 => F4_3
  | F4_3, F4_0 => F4_0 | F4_3, F4_1 => F4_1 | F4_3, F4_2 => F4_2 | F4_3, F4_3 => F4_3
  end.

#[local] Instance refa538_inst : Magma Fin4 := {| magma_op := refa538_op |}.

Lemma refa538_sat2314 : @Equation2314 Fin4 refa538_inst.
Proof. unfold Equation2314, magma_op, refa538_inst, refa538_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa538_sat2351 : @Equation2351 Fin4 refa538_inst.
Proof. unfold Equation2351, magma_op, refa538_inst, refa538_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa538_not2246 : ~ @Equation2246 Fin4 refa538_inst.
Proof. unfold Equation2246. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa538_inst, refa538_op in H. discriminate H. Qed.

Lemma refa538_not2253 : ~ @Equation2253 Fin4 refa538_inst.
Proof. unfold Equation2253. intro H. specialize (H F4_1 F4_0). unfold magma_op, refa538_inst, refa538_op in H. discriminate H. Qed.

Lemma refa538_not2256 : ~ @Equation2256 Fin4 refa538_inst.
Proof. unfold Equation2256. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa538_inst, refa538_op in H. discriminate H. Qed.

Lemma refa538_not3659 : ~ @Equation3659 Fin4 refa538_inst.
Proof. unfold Equation3659. intro H. specialize (H F4_1). unfold magma_op, refa538_inst, refa538_op in H. discriminate H. Qed.

(** ---- refa539 (Fin4) ---- *)

Definition refa539_op (x y : Fin4) : Fin4 :=
  match x, y with
  | F4_0, F4_0 => F4_3 | F4_0, F4_1 => F4_3 | F4_0, F4_2 => F4_1 | F4_0, F4_3 => F4_1
  | F4_1, F4_0 => F4_2 | F4_1, F4_1 => F4_3 | F4_1, F4_2 => F4_0 | F4_1, F4_3 => F4_0
  | F4_2, F4_0 => F4_2 | F4_2, F4_1 => F4_2 | F4_2, F4_2 => F4_3 | F4_2, F4_3 => F4_2
  | F4_3, F4_0 => F4_3 | F4_3, F4_1 => F4_3 | F4_3, F4_2 => F4_3 | F4_3, F4_3 => F4_3
  end.

#[local] Instance refa539_inst : Magma Fin4 := {| magma_op := refa539_op |}.

Lemma refa539_sat1853 : @Equation1853 Fin4 refa539_inst.
Proof. unfold Equation1853, magma_op, refa539_inst, refa539_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa539_not3253 : ~ @Equation3253 Fin4 refa539_inst.
Proof. unfold Equation3253. intro H. specialize (H F4_1). unfold magma_op, refa539_inst, refa539_op in H. discriminate H. Qed.

(** ---- refa54 (Fin3) ---- *)

Definition refa54_op (x y : Fin3) : Fin3 :=
  match x, y with
  | F3_0, F3_0 => F3_1 | F3_0, F3_1 => F3_2 | F3_0, F3_2 => F3_2
  | F3_1, F3_0 => F3_0 | F3_1, F3_1 => F3_2 | F3_1, F3_2 => F3_0
  | F3_2, F3_0 => F3_1 | F3_2, F3_1 => F3_1 | F3_2, F3_2 => F3_0
  end.

#[local] Instance refa54_inst : Magma Fin3 := {| magma_op := refa54_op |}.

Lemma refa54_sat1432 : @Equation1432 Fin3 refa54_inst.
Proof. unfold Equation1432, magma_op, refa54_inst, refa54_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa54_sat1443 : @Equation1443 Fin3 refa54_inst.
Proof. unfold Equation1443, magma_op, refa54_inst, refa54_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa54_sat1630 : @Equation1630 Fin3 refa54_inst.
Proof. unfold Equation1630, magma_op, refa54_inst, refa54_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa54_sat1635 : @Equation1635 Fin3 refa54_inst.
Proof. unfold Equation1635, magma_op, refa54_inst, refa54_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa54_sat2852 : @Equation2852 Fin3 refa54_inst.
Proof. unfold Equation2852, magma_op, refa54_inst, refa54_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa54_sat2909 : @Equation2909 Fin3 refa54_inst.
Proof. unfold Equation2909, magma_op, refa54_inst, refa54_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa54_sat3055 : @Equation3055 Fin3 refa54_inst.
Proof. unfold Equation3055, magma_op, refa54_inst, refa54_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa54_sat3521 : @Equation3521 Fin3 refa54_inst.
Proof. unfold Equation3521, magma_op, refa54_inst, refa54_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa54_sat3880 : @Equation3880 Fin3 refa54_inst.
Proof. unfold Equation3880, magma_op, refa54_inst, refa54_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa54_sat3955 : @Equation3955 Fin3 refa54_inst.
Proof. unfold Equation3955, magma_op, refa54_inst, refa54_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa54_sat4067 : @Equation4067 Fin3 refa54_inst.
Proof. unfold Equation4067, magma_op, refa54_inst, refa54_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa54_sat4083 : @Equation4083 Fin3 refa54_inst.
Proof. unfold Equation4083, magma_op, refa54_inst, refa54_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa54_sat4131 : @Equation4131 Fin3 refa54_inst.
Proof. unfold Equation4131, magma_op, refa54_inst, refa54_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa54_sat4155 : @Equation4155 Fin3 refa54_inst.
Proof. unfold Equation4155, magma_op, refa54_inst, refa54_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa54_sat4268 : @Equation4268 Fin3 refa54_inst.
Proof. unfold Equation4268, magma_op, refa54_inst, refa54_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa54_sat4343 : @Equation4343 Fin3 refa54_inst.
Proof. unfold Equation4343, magma_op, refa54_inst, refa54_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa54_sat4606 : @Equation4606 Fin3 refa54_inst.
Proof. unfold Equation4606, magma_op, refa54_inst, refa54_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa54_sat4658 : @Equation4658 Fin3 refa54_inst.
Proof. unfold Equation4658, magma_op, refa54_inst, refa54_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa54_not151 : ~ @Equation151 Fin3 refa54_inst.
Proof. unfold Equation151. intro H. specialize (H F3_0). unfold magma_op, refa54_inst, refa54_op in H. discriminate H. Qed.

Lemma refa54_not203 : ~ @Equation203 Fin3 refa54_inst.
Proof. unfold Equation203. intro H. specialize (H F3_0). unfold magma_op, refa54_inst, refa54_op in H. discriminate H. Qed.

Lemma refa54_not255 : ~ @Equation255 Fin3 refa54_inst.
Proof. unfold Equation255. intro H. specialize (H F3_0). unfold magma_op, refa54_inst, refa54_op in H. discriminate H. Qed.

Lemma refa54_not359 : ~ @Equation359 Fin3 refa54_inst.
Proof. unfold Equation359. intro H. specialize (H F3_0). unfold magma_op, refa54_inst, refa54_op in H. discriminate H. Qed.

Lemma refa54_not1428 : ~ @Equation1428 Fin3 refa54_inst.
Proof. unfold Equation1428. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa54_inst, refa54_op in H. discriminate H. Qed.

Lemma refa54_not1429 : ~ @Equation1429 Fin3 refa54_inst.
Proof. unfold Equation1429. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa54_inst, refa54_op in H. discriminate H. Qed.

Lemma refa54_not1431 : ~ @Equation1431 Fin3 refa54_inst.
Proof. unfold Equation1431. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa54_inst, refa54_op in H. discriminate H. Qed.

Lemma refa54_not1434 : ~ @Equation1434 Fin3 refa54_inst.
Proof. unfold Equation1434. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa54_inst, refa54_op in H. discriminate H. Qed.

Lemma refa54_not1435 : ~ @Equation1435 Fin3 refa54_inst.
Proof. unfold Equation1435. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa54_inst, refa54_op in H. discriminate H. Qed.

Lemma refa54_not1444 : ~ @Equation1444 Fin3 refa54_inst.
Proof. unfold Equation1444. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa54_inst, refa54_op in H. discriminate H. Qed.

Lemma refa54_not1445 : ~ @Equation1445 Fin3 refa54_inst.
Proof. unfold Equation1445. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa54_inst, refa54_op in H. discriminate H. Qed.

Lemma refa54_not1451 : ~ @Equation1451 Fin3 refa54_inst.
Proof. unfold Equation1451. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa54_inst, refa54_op in H. discriminate H. Qed.

Lemma refa54_not1454 : ~ @Equation1454 Fin3 refa54_inst.
Proof. unfold Equation1454. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa54_inst, refa54_op in H. discriminate H. Qed.

Lemma refa54_not1631 : ~ @Equation1631 Fin3 refa54_inst.
Proof. unfold Equation1631. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa54_inst, refa54_op in H. discriminate H. Qed.

Lemma refa54_not1632 : ~ @Equation1632 Fin3 refa54_inst.
Proof. unfold Equation1632. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa54_inst, refa54_op in H. discriminate H. Qed.

Lemma refa54_not1634 : ~ @Equation1634 Fin3 refa54_inst.
Proof. unfold Equation1634. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa54_inst, refa54_op in H. discriminate H. Qed.

Lemma refa54_not1637 : ~ @Equation1637 Fin3 refa54_inst.
Proof. unfold Equation1637. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa54_inst, refa54_op in H. discriminate H. Qed.

Lemma refa54_not1638 : ~ @Equation1638 Fin3 refa54_inst.
Proof. unfold Equation1638. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa54_inst, refa54_op in H. discriminate H. Qed.

Lemma refa54_not1644 : ~ @Equation1644 Fin3 refa54_inst.
Proof. unfold Equation1644. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa54_inst, refa54_op in H. discriminate H. Qed.

Lemma refa54_not1645 : ~ @Equation1645 Fin3 refa54_inst.
Proof. unfold Equation1645. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa54_inst, refa54_op in H. discriminate H. Qed.

Lemma refa54_not1648 : ~ @Equation1648 Fin3 refa54_inst.
Proof. unfold Equation1648. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa54_inst, refa54_op in H. discriminate H. Qed.

Lemma refa54_not1654 : ~ @Equation1654 Fin3 refa54_inst.
Proof. unfold Equation1654. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa54_inst, refa54_op in H. discriminate H. Qed.

Lemma refa54_not1655 : ~ @Equation1655 Fin3 refa54_inst.
Proof. unfold Equation1655. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa54_inst, refa54_op in H. discriminate H. Qed.

Lemma refa54_not1657 : ~ @Equation1657 Fin3 refa54_inst.
Proof. unfold Equation1657. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa54_inst, refa54_op in H. discriminate H. Qed.

Lemma refa54_not1832 : ~ @Equation1832 Fin3 refa54_inst.
Proof. unfold Equation1832. intro H. specialize (H F3_0). unfold magma_op, refa54_inst, refa54_op in H. discriminate H. Qed.

Lemma refa54_not2035 : ~ @Equation2035 Fin3 refa54_inst.
Proof. unfold Equation2035. intro H. specialize (H F3_0). unfold magma_op, refa54_inst, refa54_op in H. discriminate H. Qed.

Lemma refa54_not2238 : ~ @Equation2238 Fin3 refa54_inst.
Proof. unfold Equation2238. intro H. specialize (H F3_0). unfold magma_op, refa54_inst, refa54_op in H. discriminate H. Qed.

Lemma refa54_not2443 : ~ @Equation2443 Fin3 refa54_inst.
Proof. unfold Equation2443. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa54_inst, refa54_op in H. discriminate H. Qed.

Lemma refa54_not2444 : ~ @Equation2444 Fin3 refa54_inst.
Proof. unfold Equation2444. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa54_inst, refa54_op in H. discriminate H. Qed.

Lemma refa54_not2446 : ~ @Equation2446 Fin3 refa54_inst.
Proof. unfold Equation2446. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa54_inst, refa54_op in H. discriminate H. Qed.

Lemma refa54_not2447 : ~ @Equation2447 Fin3 refa54_inst.
Proof. unfold Equation2447. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa54_inst, refa54_op in H. discriminate H. Qed.

Lemma refa54_not2449 : ~ @Equation2449 Fin3 refa54_inst.
Proof. unfold Equation2449. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa54_inst, refa54_op in H. discriminate H. Qed.

Lemma refa54_not2457 : ~ @Equation2457 Fin3 refa54_inst.
Proof. unfold Equation2457. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa54_inst, refa54_op in H. discriminate H. Qed.

Lemma refa54_not2459 : ~ @Equation2459 Fin3 refa54_inst.
Proof. unfold Equation2459. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa54_inst, refa54_op in H. discriminate H. Qed.

Lemma refa54_not2460 : ~ @Equation2460 Fin3 refa54_inst.
Proof. unfold Equation2460. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa54_inst, refa54_op in H. discriminate H. Qed.

Lemma refa54_not2466 : ~ @Equation2466 Fin3 refa54_inst.
Proof. unfold Equation2466. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa54_inst, refa54_op in H. discriminate H. Qed.

Lemma refa54_not2467 : ~ @Equation2467 Fin3 refa54_inst.
Proof. unfold Equation2467. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa54_inst, refa54_op in H. discriminate H. Qed.

Lemma refa54_not2469 : ~ @Equation2469 Fin3 refa54_inst.
Proof. unfold Equation2469. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa54_inst, refa54_op in H. discriminate H. Qed.

Lemma refa54_not2470 : ~ @Equation2470 Fin3 refa54_inst.
Proof. unfold Equation2470. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa54_inst, refa54_op in H. discriminate H. Qed.

Lemma refa54_not2644 : ~ @Equation2644 Fin3 refa54_inst.
Proof. unfold Equation2644. intro H. specialize (H F3_0). unfold magma_op, refa54_inst, refa54_op in H. discriminate H. Qed.

Lemma refa54_not2849 : ~ @Equation2849 Fin3 refa54_inst.
Proof. unfold Equation2849. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa54_inst, refa54_op in H. discriminate H. Qed.

Lemma refa54_not2853 : ~ @Equation2853 Fin3 refa54_inst.
Proof. unfold Equation2853. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa54_inst, refa54_op in H. discriminate H. Qed.

Lemma refa54_not2855 : ~ @Equation2855 Fin3 refa54_inst.
Proof. unfold Equation2855. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa54_inst, refa54_op in H. discriminate H. Qed.

Lemma refa54_not2863 : ~ @Equation2863 Fin3 refa54_inst.
Proof. unfold Equation2863. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa54_inst, refa54_op in H. discriminate H. Qed.

Lemma refa54_not2865 : ~ @Equation2865 Fin3 refa54_inst.
Proof. unfold Equation2865. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa54_inst, refa54_op in H. discriminate H. Qed.

Lemma refa54_not2872 : ~ @Equation2872 Fin3 refa54_inst.
Proof. unfold Equation2872. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa54_inst, refa54_op in H. discriminate H. Qed.

Lemma refa54_not2875 : ~ @Equation2875 Fin3 refa54_inst.
Proof. unfold Equation2875. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa54_inst, refa54_op in H. discriminate H. Qed.

Lemma refa54_not2902 : ~ @Equation2902 Fin3 refa54_inst.
Proof. unfold Equation2902. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa54_inst, refa54_op in H. discriminate H. Qed.

Lemma refa54_not2936 : ~ @Equation2936 Fin3 refa54_inst.
Proof. unfold Equation2936. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa54_inst, refa54_op in H. discriminate H. Qed.

Lemma refa54_not2949 : ~ @Equation2949 Fin3 refa54_inst.
Proof. unfold Equation2949. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa54_inst, refa54_op in H. discriminate H. Qed.

Lemma refa54_not3052 : ~ @Equation3052 Fin3 refa54_inst.
Proof. unfold Equation3052. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa54_inst, refa54_op in H. discriminate H. Qed.

Lemma refa54_not3056 : ~ @Equation3056 Fin3 refa54_inst.
Proof. unfold Equation3056. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa54_inst, refa54_op in H. discriminate H. Qed.

Lemma refa54_not3058 : ~ @Equation3058 Fin3 refa54_inst.
Proof. unfold Equation3058. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa54_inst, refa54_op in H. discriminate H. Qed.

Lemma refa54_not3065 : ~ @Equation3065 Fin3 refa54_inst.
Proof. unfold Equation3065. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa54_inst, refa54_op in H. discriminate H. Qed.

Lemma refa54_not3066 : ~ @Equation3066 Fin3 refa54_inst.
Proof. unfold Equation3066. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa54_inst, refa54_op in H. discriminate H. Qed.

Lemma refa54_not3068 : ~ @Equation3068 Fin3 refa54_inst.
Proof. unfold Equation3068. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa54_inst, refa54_op in H. discriminate H. Qed.

Lemma refa54_not3069 : ~ @Equation3069 Fin3 refa54_inst.
Proof. unfold Equation3069. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa54_inst, refa54_op in H. discriminate H. Qed.

Lemma refa54_not3075 : ~ @Equation3075 Fin3 refa54_inst.
Proof. unfold Equation3075. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa54_inst, refa54_op in H. discriminate H. Qed.

Lemma refa54_not3076 : ~ @Equation3076 Fin3 refa54_inst.
Proof. unfold Equation3076. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa54_inst, refa54_op in H. discriminate H. Qed.

Lemma refa54_not3079 : ~ @Equation3079 Fin3 refa54_inst.
Proof. unfold Equation3079. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa54_inst, refa54_op in H. discriminate H. Qed.

Lemma refa54_not3105 : ~ @Equation3105 Fin3 refa54_inst.
Proof. unfold Equation3105. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa54_inst, refa54_op in H. discriminate H. Qed.

Lemma refa54_not3152 : ~ @Equation3152 Fin3 refa54_inst.
Proof. unfold Equation3152. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa54_inst, refa54_op in H. discriminate H. Qed.

Lemma refa54_not3253 : ~ @Equation3253 Fin3 refa54_inst.
Proof. unfold Equation3253. intro H. specialize (H F3_0). unfold magma_op, refa54_inst, refa54_op in H. discriminate H. Qed.

Lemma refa54_not3457 : ~ @Equation3457 Fin3 refa54_inst.
Proof. unfold Equation3457. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa54_inst, refa54_op in H. discriminate H. Qed.

Lemma refa54_not3458 : ~ @Equation3458 Fin3 refa54_inst.
Proof. unfold Equation3458. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa54_inst, refa54_op in H. discriminate H. Qed.

Lemma refa54_not3459 : ~ @Equation3459 Fin3 refa54_inst.
Proof. unfold Equation3459. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa54_inst, refa54_op in H. discriminate H. Qed.

Lemma refa54_not3461 : ~ @Equation3461 Fin3 refa54_inst.
Proof. unfold Equation3461. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa54_inst, refa54_op in H. discriminate H. Qed.

Lemma refa54_not3462 : ~ @Equation3462 Fin3 refa54_inst.
Proof. unfold Equation3462. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa54_inst, refa54_op in H. discriminate H. Qed.

Lemma refa54_not3464 : ~ @Equation3464 Fin3 refa54_inst.
Proof. unfold Equation3464. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa54_inst, refa54_op in H. discriminate H. Qed.

Lemma refa54_not3465 : ~ @Equation3465 Fin3 refa54_inst.
Proof. unfold Equation3465. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa54_inst, refa54_op in H. discriminate H. Qed.

Lemma refa54_not3472 : ~ @Equation3472 Fin3 refa54_inst.
Proof. unfold Equation3472. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa54_inst, refa54_op in H. discriminate H. Qed.

Lemma refa54_not3474 : ~ @Equation3474 Fin3 refa54_inst.
Proof. unfold Equation3474. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa54_inst, refa54_op in H. discriminate H. Qed.

Lemma refa54_not3481 : ~ @Equation3481 Fin3 refa54_inst.
Proof. unfold Equation3481. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa54_inst, refa54_op in H. discriminate H. Qed.

Lemma refa54_not3509 : ~ @Equation3509 Fin3 refa54_inst.
Proof. unfold Equation3509. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa54_inst, refa54_op in H. discriminate H. Qed.

Lemma refa54_not3512 : ~ @Equation3512 Fin3 refa54_inst.
Proof. unfold Equation3512. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa54_inst, refa54_op in H. discriminate H. Qed.

Lemma refa54_not3518 : ~ @Equation3518 Fin3 refa54_inst.
Proof. unfold Equation3518. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa54_inst, refa54_op in H. discriminate H. Qed.

Lemma refa54_not3519 : ~ @Equation3519 Fin3 refa54_inst.
Proof. unfold Equation3519. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa54_inst, refa54_op in H. discriminate H. Qed.

Lemma refa54_not3549 : ~ @Equation3549 Fin3 refa54_inst.
Proof. unfold Equation3549. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa54_inst, refa54_op in H. discriminate H. Qed.

Lemma refa54_not3556 : ~ @Equation3556 Fin3 refa54_inst.
Proof. unfold Equation3556. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa54_inst, refa54_op in H. discriminate H. Qed.

Lemma refa54_not3659 : ~ @Equation3659 Fin3 refa54_inst.
Proof. unfold Equation3659. intro H. specialize (H F3_0). unfold magma_op, refa54_inst, refa54_op in H. discriminate H. Qed.

Lemma refa54_not3865 : ~ @Equation3865 Fin3 refa54_inst.
Proof. unfold Equation3865. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa54_inst, refa54_op in H. discriminate H. Qed.

Lemma refa54_not3867 : ~ @Equation3867 Fin3 refa54_inst.
Proof. unfold Equation3867. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa54_inst, refa54_op in H. discriminate H. Qed.

Lemma refa54_not3868 : ~ @Equation3868 Fin3 refa54_inst.
Proof. unfold Equation3868. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa54_inst, refa54_op in H. discriminate H. Qed.

Lemma refa54_not3870 : ~ @Equation3870 Fin3 refa54_inst.
Proof. unfold Equation3870. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa54_inst, refa54_op in H. discriminate H. Qed.

Lemma refa54_not3871 : ~ @Equation3871 Fin3 refa54_inst.
Proof. unfold Equation3871. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa54_inst, refa54_op in H. discriminate H. Qed.

Lemma refa54_not3887 : ~ @Equation3887 Fin3 refa54_inst.
Proof. unfold Equation3887. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa54_inst, refa54_op in H. discriminate H. Qed.

Lemma refa54_not3915 : ~ @Equation3915 Fin3 refa54_inst.
Proof. unfold Equation3915. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa54_inst, refa54_op in H. discriminate H. Qed.

Lemma refa54_not3917 : ~ @Equation3917 Fin3 refa54_inst.
Proof. unfold Equation3917. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa54_inst, refa54_op in H. discriminate H. Qed.

Lemma refa54_not3918 : ~ @Equation3918 Fin3 refa54_inst.
Proof. unfold Equation3918. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa54_inst, refa54_op in H. discriminate H. Qed.

Lemma refa54_not3925 : ~ @Equation3925 Fin3 refa54_inst.
Proof. unfold Equation3925. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa54_inst, refa54_op in H. discriminate H. Qed.

Lemma refa54_not3928 : ~ @Equation3928 Fin3 refa54_inst.
Proof. unfold Equation3928. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa54_inst, refa54_op in H. discriminate H. Qed.

Lemma refa54_not3962 : ~ @Equation3962 Fin3 refa54_inst.
Proof. unfold Equation3962. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa54_inst, refa54_op in H. discriminate H. Qed.

Lemma refa54_not4066 : ~ @Equation4066 Fin3 refa54_inst.
Proof. unfold Equation4066. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa54_inst, refa54_op in H. discriminate H. Qed.

Lemma refa54_not4068 : ~ @Equation4068 Fin3 refa54_inst.
Proof. unfold Equation4068. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa54_inst, refa54_op in H. discriminate H. Qed.

Lemma refa54_not4070 : ~ @Equation4070 Fin3 refa54_inst.
Proof. unfold Equation4070. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa54_inst, refa54_op in H. discriminate H. Qed.

Lemma refa54_not4071 : ~ @Equation4071 Fin3 refa54_inst.
Proof. unfold Equation4071. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa54_inst, refa54_op in H. discriminate H. Qed.

Lemma refa54_not4073 : ~ @Equation4073 Fin3 refa54_inst.
Proof. unfold Equation4073. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa54_inst, refa54_op in H. discriminate H. Qed.

Lemma refa54_not4074 : ~ @Equation4074 Fin3 refa54_inst.
Proof. unfold Equation4074. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa54_inst, refa54_op in H. discriminate H. Qed.

Lemma refa54_not4090 : ~ @Equation4090 Fin3 refa54_inst.
Proof. unfold Equation4090. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa54_inst, refa54_op in H. discriminate H. Qed.

Lemma refa54_not4120 : ~ @Equation4120 Fin3 refa54_inst.
Proof. unfold Equation4120. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa54_inst, refa54_op in H. discriminate H. Qed.

Lemma refa54_not4121 : ~ @Equation4121 Fin3 refa54_inst.
Proof. unfold Equation4121. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa54_inst, refa54_op in H. discriminate H. Qed.

Lemma refa54_not4127 : ~ @Equation4127 Fin3 refa54_inst.
Proof. unfold Equation4127. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa54_inst, refa54_op in H. discriminate H. Qed.

Lemma refa54_not4128 : ~ @Equation4128 Fin3 refa54_inst.
Proof. unfold Equation4128. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa54_inst, refa54_op in H. discriminate H. Qed.

Lemma refa54_not4130 : ~ @Equation4130 Fin3 refa54_inst.
Proof. unfold Equation4130. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa54_inst, refa54_op in H. discriminate H. Qed.

Lemma refa54_not4158 : ~ @Equation4158 Fin3 refa54_inst.
Proof. unfold Equation4158. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa54_inst, refa54_op in H. discriminate H. Qed.

Lemma refa54_not4165 : ~ @Equation4165 Fin3 refa54_inst.
Proof. unfold Equation4165. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa54_inst, refa54_op in H. discriminate H. Qed.

Lemma refa54_not4269 : ~ @Equation4269 Fin3 refa54_inst.
Proof. unfold Equation4269. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa54_inst, refa54_op in H. discriminate H. Qed.

Lemma refa54_not4270 : ~ @Equation4270 Fin3 refa54_inst.
Proof. unfold Equation4270. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa54_inst, refa54_op in H. discriminate H. Qed.

Lemma refa54_not4272 : ~ @Equation4272 Fin3 refa54_inst.
Proof. unfold Equation4272. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa54_inst, refa54_op in H. discriminate H. Qed.

Lemma refa54_not4273 : ~ @Equation4273 Fin3 refa54_inst.
Proof. unfold Equation4273. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa54_inst, refa54_op in H. discriminate H. Qed.

Lemma refa54_not4283 : ~ @Equation4283 Fin3 refa54_inst.
Proof. unfold Equation4283. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa54_inst, refa54_op in H. discriminate H. Qed.

Lemma refa54_not4284 : ~ @Equation4284 Fin3 refa54_inst.
Proof. unfold Equation4284. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa54_inst, refa54_op in H. discriminate H. Qed.

Lemma refa54_not4314 : ~ @Equation4314 Fin3 refa54_inst.
Proof. unfold Equation4314. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa54_inst, refa54_op in H. discriminate H. Qed.

Lemma refa54_not4320 : ~ @Equation4320 Fin3 refa54_inst.
Proof. unfold Equation4320. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa54_inst, refa54_op in H. discriminate H. Qed.

Lemma refa54_not4321 : ~ @Equation4321 Fin3 refa54_inst.
Proof. unfold Equation4321. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa54_inst, refa54_op in H. discriminate H. Qed.

Lemma refa54_not4380 : ~ @Equation4380 Fin3 refa54_inst.
Proof. unfold Equation4380. intro H. specialize (H F3_0). unfold magma_op, refa54_inst, refa54_op in H. discriminate H. Qed.

Lemma refa54_not4583 : ~ @Equation4583 Fin3 refa54_inst.
Proof. unfold Equation4583. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa54_inst, refa54_op in H. discriminate H. Qed.

Lemma refa54_not4584 : ~ @Equation4584 Fin3 refa54_inst.
Proof. unfold Equation4584. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa54_inst, refa54_op in H. discriminate H. Qed.

Lemma refa54_not4585 : ~ @Equation4585 Fin3 refa54_inst.
Proof. unfold Equation4585. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa54_inst, refa54_op in H. discriminate H. Qed.

Lemma refa54_not4590 : ~ @Equation4590 Fin3 refa54_inst.
Proof. unfold Equation4590. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa54_inst, refa54_op in H. discriminate H. Qed.

Lemma refa54_not4598 : ~ @Equation4598 Fin3 refa54_inst.
Proof. unfold Equation4598. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa54_inst, refa54_op in H. discriminate H. Qed.

Lemma refa54_not4599 : ~ @Equation4599 Fin3 refa54_inst.
Proof. unfold Equation4599. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa54_inst, refa54_op in H. discriminate H. Qed.

Lemma refa54_not4629 : ~ @Equation4629 Fin3 refa54_inst.
Proof. unfold Equation4629. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa54_inst, refa54_op in H. discriminate H. Qed.

Lemma refa54_not4635 : ~ @Equation4635 Fin3 refa54_inst.
Proof. unfold Equation4635. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa54_inst, refa54_op in H. discriminate H. Qed.

(** ---- refa540 (Fin4) ---- *)

Definition refa540_op (x y : Fin4) : Fin4 :=
  match x, y with
  | F4_0, F4_0 => F4_2 | F4_0, F4_1 => F4_3 | F4_0, F4_2 => F4_1 | F4_0, F4_3 => F4_3
  | F4_1, F4_0 => F4_3 | F4_1, F4_1 => F4_0 | F4_1, F4_2 => F4_2 | F4_1, F4_3 => F4_2
  | F4_2, F4_0 => F4_1 | F4_2, F4_1 => F4_1 | F4_2, F4_2 => F4_3 | F4_2, F4_3 => F4_0
  | F4_3, F4_0 => F4_0 | F4_3, F4_1 => F4_2 | F4_3, F4_2 => F4_0 | F4_3, F4_3 => F4_1
  end.

#[local] Instance refa540_inst : Magma Fin4 := {| magma_op := refa540_op |}.

Lemma refa540_sat2240 : @Equation2240 Fin4 refa540_inst.
Proof. unfold Equation2240, magma_op, refa540_inst, refa540_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa540_sat2254 : @Equation2254 Fin4 refa540_inst.
Proof. unfold Equation2254, magma_op, refa540_inst, refa540_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa540_sat2264 : @Equation2264 Fin4 refa540_inst.
Proof. unfold Equation2264, magma_op, refa540_inst, refa540_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa540_sat2937 : @Equation2937 Fin4 refa540_inst.
Proof. unfold Equation2937, magma_op, refa540_inst, refa540_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa540_not43 : ~ @Equation43 Fin4 refa540_inst.
Proof. unfold Equation43. intro H. specialize (H F4_0 F4_3). unfold magma_op, refa540_inst, refa540_op in H. discriminate H. Qed.

Lemma refa540_not47 : ~ @Equation47 Fin4 refa540_inst.
Proof. unfold Equation47. intro H. specialize (H F4_0). unfold magma_op, refa540_inst, refa540_op in H. discriminate H. Qed.

Lemma refa540_not99 : ~ @Equation99 Fin4 refa540_inst.
Proof. unfold Equation99. intro H. specialize (H F4_0). unfold magma_op, refa540_inst, refa540_op in H. discriminate H. Qed.

Lemma refa540_not151 : ~ @Equation151 Fin4 refa540_inst.
Proof. unfold Equation151. intro H. specialize (H F4_0). unfold magma_op, refa540_inst, refa540_op in H. discriminate H. Qed.

Lemma refa540_not203 : ~ @Equation203 Fin4 refa540_inst.
Proof. unfold Equation203. intro H. specialize (H F4_0). unfold magma_op, refa540_inst, refa540_op in H. discriminate H. Qed.

Lemma refa540_not255 : ~ @Equation255 Fin4 refa540_inst.
Proof. unfold Equation255. intro H. specialize (H F4_0). unfold magma_op, refa540_inst, refa540_op in H. discriminate H. Qed.

Lemma refa540_not307 : ~ @Equation307 Fin4 refa540_inst.
Proof. unfold Equation307. intro H. specialize (H F4_0). unfold magma_op, refa540_inst, refa540_op in H. discriminate H. Qed.

Lemma refa540_not359 : ~ @Equation359 Fin4 refa540_inst.
Proof. unfold Equation359. intro H. specialize (H F4_0). unfold magma_op, refa540_inst, refa540_op in H. discriminate H. Qed.

Lemma refa540_not411 : ~ @Equation411 Fin4 refa540_inst.
Proof. unfold Equation411. intro H. specialize (H F4_0). unfold magma_op, refa540_inst, refa540_op in H. discriminate H. Qed.

Lemma refa540_not614 : ~ @Equation614 Fin4 refa540_inst.
Proof. unfold Equation614. intro H. specialize (H F4_0). unfold magma_op, refa540_inst, refa540_op in H. discriminate H. Qed.

Lemma refa540_not817 : ~ @Equation817 Fin4 refa540_inst.
Proof. unfold Equation817. intro H. specialize (H F4_0). unfold magma_op, refa540_inst, refa540_op in H. discriminate H. Qed.

Lemma refa540_not1020 : ~ @Equation1020 Fin4 refa540_inst.
Proof. unfold Equation1020. intro H. specialize (H F4_0). unfold magma_op, refa540_inst, refa540_op in H. discriminate H. Qed.

Lemma refa540_not1223 : ~ @Equation1223 Fin4 refa540_inst.
Proof. unfold Equation1223. intro H. specialize (H F4_0). unfold magma_op, refa540_inst, refa540_op in H. discriminate H. Qed.

Lemma refa540_not1426 : ~ @Equation1426 Fin4 refa540_inst.
Proof. unfold Equation1426. intro H. specialize (H F4_0). unfold magma_op, refa540_inst, refa540_op in H. discriminate H. Qed.

Lemma refa540_not1629 : ~ @Equation1629 Fin4 refa540_inst.
Proof. unfold Equation1629. intro H. specialize (H F4_0). unfold magma_op, refa540_inst, refa540_op in H. discriminate H. Qed.

Lemma refa540_not1832 : ~ @Equation1832 Fin4 refa540_inst.
Proof. unfold Equation1832. intro H. specialize (H F4_0). unfold magma_op, refa540_inst, refa540_op in H. discriminate H. Qed.

Lemma refa540_not2035 : ~ @Equation2035 Fin4 refa540_inst.
Proof. unfold Equation2035. intro H. specialize (H F4_0). unfold magma_op, refa540_inst, refa540_op in H. discriminate H. Qed.

Lemma refa540_not2246 : ~ @Equation2246 Fin4 refa540_inst.
Proof. unfold Equation2246. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa540_inst, refa540_op in H. discriminate H. Qed.

Lemma refa540_not2247 : ~ @Equation2247 Fin4 refa540_inst.
Proof. unfold Equation2247. intro H. specialize (H F4_0 F4_3). unfold magma_op, refa540_inst, refa540_op in H. discriminate H. Qed.

Lemma refa540_not2256 : ~ @Equation2256 Fin4 refa540_inst.
Proof. unfold Equation2256. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa540_inst, refa540_op in H. discriminate H. Qed.

Lemma refa540_not2257 : ~ @Equation2257 Fin4 refa540_inst.
Proof. unfold Equation2257. intro H. specialize (H F4_0 F4_3). unfold magma_op, refa540_inst, refa540_op in H. discriminate H. Qed.

Lemma refa540_not2266 : ~ @Equation2266 Fin4 refa540_inst.
Proof. unfold Equation2266. intro H. specialize (H F4_0 F4_2). unfold magma_op, refa540_inst, refa540_op in H. discriminate H. Qed.

Lemma refa540_not2300 : ~ @Equation2300 Fin4 refa540_inst.
Proof. unfold Equation2300. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa540_inst, refa540_op in H. discriminate H. Qed.

Lemma refa540_not2328 : ~ @Equation2328 Fin4 refa540_inst.
Proof. unfold Equation2328. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa540_inst, refa540_op in H. discriminate H. Qed.

Lemma refa540_not2330 : ~ @Equation2330 Fin4 refa540_inst.
Proof. unfold Equation2330. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa540_inst, refa540_op in H. discriminate H. Qed.

Lemma refa540_not2340 : ~ @Equation2340 Fin4 refa540_inst.
Proof. unfold Equation2340. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa540_inst, refa540_op in H. discriminate H. Qed.

Lemma refa540_not2443 : ~ @Equation2443 Fin4 refa540_inst.
Proof. unfold Equation2443. intro H. specialize (H F4_0 F4_3). unfold magma_op, refa540_inst, refa540_op in H. discriminate H. Qed.

Lemma refa540_not2444 : ~ @Equation2444 Fin4 refa540_inst.
Proof. unfold Equation2444. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa540_inst, refa540_op in H. discriminate H. Qed.

Lemma refa540_not2460 : ~ @Equation2460 Fin4 refa540_inst.
Proof. unfold Equation2460. intro H. specialize (H F4_0 F4_2). unfold magma_op, refa540_inst, refa540_op in H. discriminate H. Qed.

Lemma refa540_not2466 : ~ @Equation2466 Fin4 refa540_inst.
Proof. unfold Equation2466. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa540_inst, refa540_op in H. discriminate H. Qed.

Lemma refa540_not2467 : ~ @Equation2467 Fin4 refa540_inst.
Proof. unfold Equation2467. intro H. specialize (H F4_0 F4_2). unfold magma_op, refa540_inst, refa540_op in H. discriminate H. Qed.

Lemma refa540_not2469 : ~ @Equation2469 Fin4 refa540_inst.
Proof. unfold Equation2469. intro H. specialize (H F4_0 F4_2). unfold magma_op, refa540_inst, refa540_op in H. discriminate H. Qed.

Lemma refa540_not2503 : ~ @Equation2503 Fin4 refa540_inst.
Proof. unfold Equation2503. intro H. specialize (H F4_0 F4_2). unfold magma_op, refa540_inst, refa540_op in H. discriminate H. Qed.

Lemma refa540_not2530 : ~ @Equation2530 Fin4 refa540_inst.
Proof. unfold Equation2530. intro H. specialize (H F4_0 F4_2). unfold magma_op, refa540_inst, refa540_op in H. discriminate H. Qed.

Lemma refa540_not2531 : ~ @Equation2531 Fin4 refa540_inst.
Proof. unfold Equation2531. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa540_inst, refa540_op in H. discriminate H. Qed.

Lemma refa540_not2533 : ~ @Equation2533 Fin4 refa540_inst.
Proof. unfold Equation2533. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa540_inst, refa540_op in H. discriminate H. Qed.

Lemma refa540_not2541 : ~ @Equation2541 Fin4 refa540_inst.
Proof. unfold Equation2541. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa540_inst, refa540_op in H. discriminate H. Qed.

Lemma refa540_not2543 : ~ @Equation2543 Fin4 refa540_inst.
Proof. unfold Equation2543. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa540_inst, refa540_op in H. discriminate H. Qed.

Lemma refa540_not2646 : ~ @Equation2646 Fin4 refa540_inst.
Proof. unfold Equation2646. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa540_inst, refa540_op in H. discriminate H. Qed.

Lemma refa540_not2647 : ~ @Equation2647 Fin4 refa540_inst.
Proof. unfold Equation2647. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa540_inst, refa540_op in H. discriminate H. Qed.

Lemma refa540_not2650 : ~ @Equation2650 Fin4 refa540_inst.
Proof. unfold Equation2650. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa540_inst, refa540_op in H. discriminate H. Qed.

Lemma refa540_not2652 : ~ @Equation2652 Fin4 refa540_inst.
Proof. unfold Equation2652. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa540_inst, refa540_op in H. discriminate H. Qed.

Lemma refa540_not2659 : ~ @Equation2659 Fin4 refa540_inst.
Proof. unfold Equation2659. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa540_inst, refa540_op in H. discriminate H. Qed.

Lemma refa540_not2660 : ~ @Equation2660 Fin4 refa540_inst.
Proof. unfold Equation2660. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa540_inst, refa540_op in H. discriminate H. Qed.

Lemma refa540_not2662 : ~ @Equation2662 Fin4 refa540_inst.
Proof. unfold Equation2662. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa540_inst, refa540_op in H. discriminate H. Qed.

Lemma refa540_not2669 : ~ @Equation2669 Fin4 refa540_inst.
Proof. unfold Equation2669. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa540_inst, refa540_op in H. discriminate H. Qed.

Lemma refa540_not2697 : ~ @Equation2697 Fin4 refa540_inst.
Proof. unfold Equation2697. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa540_inst, refa540_op in H. discriminate H. Qed.

Lemma refa540_not2699 : ~ @Equation2699 Fin4 refa540_inst.
Proof. unfold Equation2699. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa540_inst, refa540_op in H. discriminate H. Qed.

Lemma refa540_not2734 : ~ @Equation2734 Fin4 refa540_inst.
Proof. unfold Equation2734. intro H. specialize (H F4_0 F4_2). unfold magma_op, refa540_inst, refa540_op in H. discriminate H. Qed.

Lemma refa540_not2743 : ~ @Equation2743 Fin4 refa540_inst.
Proof. unfold Equation2743. intro H. specialize (H F4_0 F4_2). unfold magma_op, refa540_inst, refa540_op in H. discriminate H. Qed.

Lemma refa540_not2744 : ~ @Equation2744 Fin4 refa540_inst.
Proof. unfold Equation2744. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa540_inst, refa540_op in H. discriminate H. Qed.

Lemma refa540_not2746 : ~ @Equation2746 Fin4 refa540_inst.
Proof. unfold Equation2746. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa540_inst, refa540_op in H. discriminate H. Qed.

Lemma refa540_not2849 : ~ @Equation2849 Fin4 refa540_inst.
Proof. unfold Equation2849. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa540_inst, refa540_op in H. discriminate H. Qed.

Lemma refa540_not2852 : ~ @Equation2852 Fin4 refa540_inst.
Proof. unfold Equation2852. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa540_inst, refa540_op in H. discriminate H. Qed.

Lemma refa540_not2855 : ~ @Equation2855 Fin4 refa540_inst.
Proof. unfold Equation2855. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa540_inst, refa540_op in H. discriminate H. Qed.

Lemma refa540_not2865 : ~ @Equation2865 Fin4 refa540_inst.
Proof. unfold Equation2865. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa540_inst, refa540_op in H. discriminate H. Qed.

Lemma refa540_not2866 : ~ @Equation2866 Fin4 refa540_inst.
Proof. unfold Equation2866. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa540_inst, refa540_op in H. discriminate H. Qed.

Lemma refa540_not2872 : ~ @Equation2872 Fin4 refa540_inst.
Proof. unfold Equation2872. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa540_inst, refa540_op in H. discriminate H. Qed.

Lemma refa540_not2873 : ~ @Equation2873 Fin4 refa540_inst.
Proof. unfold Equation2873. intro H. specialize (H F4_0 F4_2). unfold magma_op, refa540_inst, refa540_op in H. discriminate H. Qed.

Lemma refa540_not2900 : ~ @Equation2900 Fin4 refa540_inst.
Proof. unfold Equation2900. intro H. specialize (H F4_0 F4_2). unfold magma_op, refa540_inst, refa540_op in H. discriminate H. Qed.

Lemma refa540_not2903 : ~ @Equation2903 Fin4 refa540_inst.
Proof. unfold Equation2903. intro H. specialize (H F4_0 F4_2). unfold magma_op, refa540_inst, refa540_op in H. discriminate H. Qed.

Lemma refa540_not2909 : ~ @Equation2909 Fin4 refa540_inst.
Proof. unfold Equation2909. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa540_inst, refa540_op in H. discriminate H. Qed.

Lemma refa540_not2910 : ~ @Equation2910 Fin4 refa540_inst.
Proof. unfold Equation2910. intro H. specialize (H F4_0 F4_3). unfold magma_op, refa540_inst, refa540_op in H. discriminate H. Qed.

Lemma refa540_not2939 : ~ @Equation2939 Fin4 refa540_inst.
Proof. unfold Equation2939. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa540_inst, refa540_op in H. discriminate H. Qed.

Lemma refa540_not2946 : ~ @Equation2946 Fin4 refa540_inst.
Proof. unfold Equation2946. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa540_inst, refa540_op in H. discriminate H. Qed.

Lemma refa540_not2949 : ~ @Equation2949 Fin4 refa540_inst.
Proof. unfold Equation2949. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa540_inst, refa540_op in H. discriminate H. Qed.

Lemma refa540_not3052 : ~ @Equation3052 Fin4 refa540_inst.
Proof. unfold Equation3052. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa540_inst, refa540_op in H. discriminate H. Qed.

Lemma refa540_not3055 : ~ @Equation3055 Fin4 refa540_inst.
Proof. unfold Equation3055. intro H. specialize (H F4_0 F4_2). unfold magma_op, refa540_inst, refa540_op in H. discriminate H. Qed.

Lemma refa540_not3056 : ~ @Equation3056 Fin4 refa540_inst.
Proof. unfold Equation3056. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa540_inst, refa540_op in H. discriminate H. Qed.

Lemma refa540_not3065 : ~ @Equation3065 Fin4 refa540_inst.
Proof. unfold Equation3065. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa540_inst, refa540_op in H. discriminate H. Qed.

Lemma refa540_not3068 : ~ @Equation3068 Fin4 refa540_inst.
Proof. unfold Equation3068. intro H. specialize (H F4_0 F4_2). unfold magma_op, refa540_inst, refa540_op in H. discriminate H. Qed.

Lemma refa540_not3069 : ~ @Equation3069 Fin4 refa540_inst.
Proof. unfold Equation3069. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa540_inst, refa540_op in H. discriminate H. Qed.

Lemma refa540_not3105 : ~ @Equation3105 Fin4 refa540_inst.
Proof. unfold Equation3105. intro H. specialize (H F4_0 F4_2). unfold magma_op, refa540_inst, refa540_op in H. discriminate H. Qed.

Lemma refa540_not3106 : ~ @Equation3106 Fin4 refa540_inst.
Proof. unfold Equation3106. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa540_inst, refa540_op in H. discriminate H. Qed.

Lemma refa540_not3139 : ~ @Equation3139 Fin4 refa540_inst.
Proof. unfold Equation3139. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa540_inst, refa540_op in H. discriminate H. Qed.

Lemma refa540_not3140 : ~ @Equation3140 Fin4 refa540_inst.
Proof. unfold Equation3140. intro H. specialize (H F4_0 F4_2). unfold magma_op, refa540_inst, refa540_op in H. discriminate H. Qed.

Lemma refa540_not3149 : ~ @Equation3149 Fin4 refa540_inst.
Proof. unfold Equation3149. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa540_inst, refa540_op in H. discriminate H. Qed.

Lemma refa540_not3152 : ~ @Equation3152 Fin4 refa540_inst.
Proof. unfold Equation3152. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa540_inst, refa540_op in H. discriminate H. Qed.

Lemma refa540_not3255 : ~ @Equation3255 Fin4 refa540_inst.
Proof. unfold Equation3255. intro H. specialize (H F4_0 F4_0). unfold magma_op, refa540_inst, refa540_op in H. discriminate H. Qed.

Lemma refa540_not3256 : ~ @Equation3256 Fin4 refa540_inst.
Proof. unfold Equation3256. intro H. specialize (H F4_0 F4_0). unfold magma_op, refa540_inst, refa540_op in H. discriminate H. Qed.

Lemma refa540_not3258 : ~ @Equation3258 Fin4 refa540_inst.
Proof. unfold Equation3258. intro H. specialize (H F4_0 F4_0). unfold magma_op, refa540_inst, refa540_op in H. discriminate H. Qed.

Lemma refa540_not3262 : ~ @Equation3262 Fin4 refa540_inst.
Proof. unfold Equation3262. intro H. specialize (H F4_0 F4_0). unfold magma_op, refa540_inst, refa540_op in H. discriminate H. Qed.

Lemma refa540_not3268 : ~ @Equation3268 Fin4 refa540_inst.
Proof. unfold Equation3268. intro H. specialize (H F4_0 F4_0). unfold magma_op, refa540_inst, refa540_op in H. discriminate H. Qed.

Lemma refa540_not3271 : ~ @Equation3271 Fin4 refa540_inst.
Proof. unfold Equation3271. intro H. specialize (H F4_0 F4_0). unfold magma_op, refa540_inst, refa540_op in H. discriminate H. Qed.

Lemma refa540_not3279 : ~ @Equation3279 Fin4 refa540_inst.
Proof. unfold Equation3279. intro H. specialize (H F4_0 F4_0). unfold magma_op, refa540_inst, refa540_op in H. discriminate H. Qed.

Lemma refa540_not3309 : ~ @Equation3309 Fin4 refa540_inst.
Proof. unfold Equation3309. intro H. specialize (H F4_0 F4_0). unfold magma_op, refa540_inst, refa540_op in H. discriminate H. Qed.

Lemma refa540_not3315 : ~ @Equation3315 Fin4 refa540_inst.
Proof. unfold Equation3315. intro H. specialize (H F4_0 F4_0). unfold magma_op, refa540_inst, refa540_op in H. discriminate H. Qed.

Lemma refa540_not3316 : ~ @Equation3316 Fin4 refa540_inst.
Proof. unfold Equation3316. intro H. specialize (H F4_0 F4_0). unfold magma_op, refa540_inst, refa540_op in H. discriminate H. Qed.

Lemma refa540_not3318 : ~ @Equation3318 Fin4 refa540_inst.
Proof. unfold Equation3318. intro H. specialize (H F4_0 F4_0). unfold magma_op, refa540_inst, refa540_op in H. discriminate H. Qed.

Lemma refa540_not3343 : ~ @Equation3343 Fin4 refa540_inst.
Proof. unfold Equation3343. intro H. specialize (H F4_0 F4_0). unfold magma_op, refa540_inst, refa540_op in H. discriminate H. Qed.

Lemma refa540_not3346 : ~ @Equation3346 Fin4 refa540_inst.
Proof. unfold Equation3346. intro H. specialize (H F4_0 F4_0). unfold magma_op, refa540_inst, refa540_op in H. discriminate H. Qed.

Lemma refa540_not3352 : ~ @Equation3352 Fin4 refa540_inst.
Proof. unfold Equation3352. intro H. specialize (H F4_0 F4_0). unfold magma_op, refa540_inst, refa540_op in H. discriminate H. Qed.

Lemma refa540_not3457 : ~ @Equation3457 Fin4 refa540_inst.
Proof. unfold Equation3457. intro H. specialize (H F4_0 F4_0). unfold magma_op, refa540_inst, refa540_op in H. discriminate H. Qed.

Lemma refa540_not3458 : ~ @Equation3458 Fin4 refa540_inst.
Proof. unfold Equation3458. intro H. specialize (H F4_0 F4_0). unfold magma_op, refa540_inst, refa540_op in H. discriminate H. Qed.

Lemma refa540_not3461 : ~ @Equation3461 Fin4 refa540_inst.
Proof. unfold Equation3461. intro H. specialize (H F4_0 F4_0). unfold magma_op, refa540_inst, refa540_op in H. discriminate H. Qed.

Lemma refa540_not3464 : ~ @Equation3464 Fin4 refa540_inst.
Proof. unfold Equation3464. intro H. specialize (H F4_0 F4_0). unfold magma_op, refa540_inst, refa540_op in H. discriminate H. Qed.

Lemma refa540_not3465 : ~ @Equation3465 Fin4 refa540_inst.
Proof. unfold Equation3465. intro H. specialize (H F4_0 F4_0). unfold magma_op, refa540_inst, refa540_op in H. discriminate H. Qed.

Lemma refa540_not3481 : ~ @Equation3481 Fin4 refa540_inst.
Proof. unfold Equation3481. intro H. specialize (H F4_0 F4_0). unfold magma_op, refa540_inst, refa540_op in H. discriminate H. Qed.

Lemma refa540_not3482 : ~ @Equation3482 Fin4 refa540_inst.
Proof. unfold Equation3482. intro H. specialize (H F4_0 F4_0). unfold magma_op, refa540_inst, refa540_op in H. discriminate H. Qed.

Lemma refa540_not3509 : ~ @Equation3509 Fin4 refa540_inst.
Proof. unfold Equation3509. intro H. specialize (H F4_0 F4_0). unfold magma_op, refa540_inst, refa540_op in H. discriminate H. Qed.

Lemma refa540_not3512 : ~ @Equation3512 Fin4 refa540_inst.
Proof. unfold Equation3512. intro H. specialize (H F4_0 F4_0). unfold magma_op, refa540_inst, refa540_op in H. discriminate H. Qed.

Lemma refa540_not3519 : ~ @Equation3519 Fin4 refa540_inst.
Proof. unfold Equation3519. intro H. specialize (H F4_0 F4_0). unfold magma_op, refa540_inst, refa540_op in H. discriminate H. Qed.

Lemma refa540_not3521 : ~ @Equation3521 Fin4 refa540_inst.
Proof. unfold Equation3521. intro H. specialize (H F4_0 F4_0). unfold magma_op, refa540_inst, refa540_op in H. discriminate H. Qed.

Lemma refa540_not3546 : ~ @Equation3546 Fin4 refa540_inst.
Proof. unfold Equation3546. intro H. specialize (H F4_0 F4_0). unfold magma_op, refa540_inst, refa540_op in H. discriminate H. Qed.

Lemma refa540_not3558 : ~ @Equation3558 Fin4 refa540_inst.
Proof. unfold Equation3558. intro H. specialize (H F4_0 F4_0). unfold magma_op, refa540_inst, refa540_op in H. discriminate H. Qed.

Lemma refa540_not3660 : ~ @Equation3660 Fin4 refa540_inst.
Proof. unfold Equation3660. intro H. specialize (H F4_0 F4_0). unfold magma_op, refa540_inst, refa540_op in H. discriminate H. Qed.

Lemma refa540_not3661 : ~ @Equation3661 Fin4 refa540_inst.
Proof. unfold Equation3661. intro H. specialize (H F4_0 F4_0). unfold magma_op, refa540_inst, refa540_op in H. discriminate H. Qed.

Lemma refa540_not3662 : ~ @Equation3662 Fin4 refa540_inst.
Proof. unfold Equation3662. intro H. specialize (H F4_0 F4_0). unfold magma_op, refa540_inst, refa540_op in H. discriminate H. Qed.

Lemma refa540_not3664 : ~ @Equation3664 Fin4 refa540_inst.
Proof. unfold Equation3664. intro H. specialize (H F4_0 F4_0). unfold magma_op, refa540_inst, refa540_op in H. discriminate H. Qed.

Lemma refa540_not3665 : ~ @Equation3665 Fin4 refa540_inst.
Proof. unfold Equation3665. intro H. specialize (H F4_0 F4_0). unfold magma_op, refa540_inst, refa540_op in H. discriminate H. Qed.

Lemma refa540_not3667 : ~ @Equation3667 Fin4 refa540_inst.
Proof. unfold Equation3667. intro H. specialize (H F4_0 F4_0). unfold magma_op, refa540_inst, refa540_op in H. discriminate H. Qed.

Lemma refa540_not3674 : ~ @Equation3674 Fin4 refa540_inst.
Proof. unfold Equation3674. intro H. specialize (H F4_0 F4_0). unfold magma_op, refa540_inst, refa540_op in H. discriminate H. Qed.

Lemma refa540_not3675 : ~ @Equation3675 Fin4 refa540_inst.
Proof. unfold Equation3675. intro H. specialize (H F4_0 F4_0). unfold magma_op, refa540_inst, refa540_op in H. discriminate H. Qed.

Lemma refa540_not3677 : ~ @Equation3677 Fin4 refa540_inst.
Proof. unfold Equation3677. intro H. specialize (H F4_0 F4_0). unfold magma_op, refa540_inst, refa540_op in H. discriminate H. Qed.

Lemma refa540_not3684 : ~ @Equation3684 Fin4 refa540_inst.
Proof. unfold Equation3684. intro H. specialize (H F4_0 F4_0). unfold magma_op, refa540_inst, refa540_op in H. discriminate H. Qed.

Lemma refa540_not3712 : ~ @Equation3712 Fin4 refa540_inst.
Proof. unfold Equation3712. intro H. specialize (H F4_0 F4_0). unfold magma_op, refa540_inst, refa540_op in H. discriminate H. Qed.

Lemma refa540_not3714 : ~ @Equation3714 Fin4 refa540_inst.
Proof. unfold Equation3714. intro H. specialize (H F4_0 F4_0). unfold magma_op, refa540_inst, refa540_op in H. discriminate H. Qed.

Lemma refa540_not3721 : ~ @Equation3721 Fin4 refa540_inst.
Proof. unfold Equation3721. intro H. specialize (H F4_0 F4_0). unfold magma_op, refa540_inst, refa540_op in H. discriminate H. Qed.

Lemma refa540_not3725 : ~ @Equation3725 Fin4 refa540_inst.
Proof. unfold Equation3725. intro H. specialize (H F4_0 F4_0). unfold magma_op, refa540_inst, refa540_op in H. discriminate H. Qed.

Lemma refa540_not3748 : ~ @Equation3748 Fin4 refa540_inst.
Proof. unfold Equation3748. intro H. specialize (H F4_0 F4_0). unfold magma_op, refa540_inst, refa540_op in H. discriminate H. Qed.

Lemma refa540_not3752 : ~ @Equation3752 Fin4 refa540_inst.
Proof. unfold Equation3752. intro H. specialize (H F4_0 F4_0). unfold magma_op, refa540_inst, refa540_op in H. discriminate H. Qed.

Lemma refa540_not3759 : ~ @Equation3759 Fin4 refa540_inst.
Proof. unfold Equation3759. intro H. specialize (H F4_0 F4_0). unfold magma_op, refa540_inst, refa540_op in H. discriminate H. Qed.

Lemma refa540_not3761 : ~ @Equation3761 Fin4 refa540_inst.
Proof. unfold Equation3761. intro H. specialize (H F4_0 F4_0). unfold magma_op, refa540_inst, refa540_op in H. discriminate H. Qed.

Lemma refa540_not3864 : ~ @Equation3864 Fin4 refa540_inst.
Proof. unfold Equation3864. intro H. specialize (H F4_0 F4_0). unfold magma_op, refa540_inst, refa540_op in H. discriminate H. Qed.

Lemma refa540_not3865 : ~ @Equation3865 Fin4 refa540_inst.
Proof. unfold Equation3865. intro H. specialize (H F4_0 F4_0). unfold magma_op, refa540_inst, refa540_op in H. discriminate H. Qed.

Lemma refa540_not3867 : ~ @Equation3867 Fin4 refa540_inst.
Proof. unfold Equation3867. intro H. specialize (H F4_0 F4_0). unfold magma_op, refa540_inst, refa540_op in H. discriminate H. Qed.

Lemma refa540_not3868 : ~ @Equation3868 Fin4 refa540_inst.
Proof. unfold Equation3868. intro H. specialize (H F4_0 F4_0). unfold magma_op, refa540_inst, refa540_op in H. discriminate H. Qed.

Lemma refa540_not3870 : ~ @Equation3870 Fin4 refa540_inst.
Proof. unfold Equation3870. intro H. specialize (H F4_0 F4_0). unfold magma_op, refa540_inst, refa540_op in H. discriminate H. Qed.

Lemma refa540_not3877 : ~ @Equation3877 Fin4 refa540_inst.
Proof. unfold Equation3877. intro H. specialize (H F4_0 F4_0). unfold magma_op, refa540_inst, refa540_op in H. discriminate H. Qed.

Lemma refa540_not3888 : ~ @Equation3888 Fin4 refa540_inst.
Proof. unfold Equation3888. intro H. specialize (H F4_0 F4_0). unfold magma_op, refa540_inst, refa540_op in H. discriminate H. Qed.

Lemma refa540_not3890 : ~ @Equation3890 Fin4 refa540_inst.
Proof. unfold Equation3890. intro H. specialize (H F4_0 F4_0). unfold magma_op, refa540_inst, refa540_op in H. discriminate H. Qed.

Lemma refa540_not3918 : ~ @Equation3918 Fin4 refa540_inst.
Proof. unfold Equation3918. intro H. specialize (H F4_0 F4_0). unfold magma_op, refa540_inst, refa540_op in H. discriminate H. Qed.

Lemma refa540_not3925 : ~ @Equation3925 Fin4 refa540_inst.
Proof. unfold Equation3925. intro H. specialize (H F4_0 F4_0). unfold magma_op, refa540_inst, refa540_op in H. discriminate H. Qed.

Lemma refa540_not3927 : ~ @Equation3927 Fin4 refa540_inst.
Proof. unfold Equation3927. intro H. specialize (H F4_0 F4_0). unfold magma_op, refa540_inst, refa540_op in H. discriminate H. Qed.

Lemma refa540_not3928 : ~ @Equation3928 Fin4 refa540_inst.
Proof. unfold Equation3928. intro H. specialize (H F4_0 F4_0). unfold magma_op, refa540_inst, refa540_op in H. discriminate H. Qed.

Lemma refa540_not3951 : ~ @Equation3951 Fin4 refa540_inst.
Proof. unfold Equation3951. intro H. specialize (H F4_0 F4_0). unfold magma_op, refa540_inst, refa540_op in H. discriminate H. Qed.

Lemma refa540_not3952 : ~ @Equation3952 Fin4 refa540_inst.
Proof. unfold Equation3952. intro H. specialize (H F4_0 F4_0). unfold magma_op, refa540_inst, refa540_op in H. discriminate H. Qed.

Lemma refa540_not3961 : ~ @Equation3961 Fin4 refa540_inst.
Proof. unfold Equation3961. intro H. specialize (H F4_0 F4_0). unfold magma_op, refa540_inst, refa540_op in H. discriminate H. Qed.

Lemma refa540_not4066 : ~ @Equation4066 Fin4 refa540_inst.
Proof. unfold Equation4066. intro H. specialize (H F4_0 F4_0). unfold magma_op, refa540_inst, refa540_op in H. discriminate H. Qed.

Lemma refa540_not4067 : ~ @Equation4067 Fin4 refa540_inst.
Proof. unfold Equation4067. intro H. specialize (H F4_0 F4_0). unfold magma_op, refa540_inst, refa540_op in H. discriminate H. Qed.

Lemma refa540_not4070 : ~ @Equation4070 Fin4 refa540_inst.
Proof. unfold Equation4070. intro H. specialize (H F4_0 F4_0). unfold magma_op, refa540_inst, refa540_op in H. discriminate H. Qed.

Lemma refa540_not4074 : ~ @Equation4074 Fin4 refa540_inst.
Proof. unfold Equation4074. intro H. specialize (H F4_0 F4_0). unfold magma_op, refa540_inst, refa540_op in H. discriminate H. Qed.

Lemma refa540_not4081 : ~ @Equation4081 Fin4 refa540_inst.
Proof. unfold Equation4081. intro H. specialize (H F4_0 F4_0). unfold magma_op, refa540_inst, refa540_op in H. discriminate H. Qed.

Lemma refa540_not4090 : ~ @Equation4090 Fin4 refa540_inst.
Proof. unfold Equation4090. intro H. specialize (H F4_0 F4_0). unfold magma_op, refa540_inst, refa540_op in H. discriminate H. Qed.

Lemma refa540_not4093 : ~ @Equation4093 Fin4 refa540_inst.
Proof. unfold Equation4093. intro H. specialize (H F4_0 F4_0). unfold magma_op, refa540_inst, refa540_op in H. discriminate H. Qed.

Lemma refa540_not4120 : ~ @Equation4120 Fin4 refa540_inst.
Proof. unfold Equation4120. intro H. specialize (H F4_0 F4_0). unfold magma_op, refa540_inst, refa540_op in H. discriminate H. Qed.

Lemma refa540_not4121 : ~ @Equation4121 Fin4 refa540_inst.
Proof. unfold Equation4121. intro H. specialize (H F4_0 F4_0). unfold magma_op, refa540_inst, refa540_op in H. discriminate H. Qed.

Lemma refa540_not4128 : ~ @Equation4128 Fin4 refa540_inst.
Proof. unfold Equation4128. intro H. specialize (H F4_0 F4_0). unfold magma_op, refa540_inst, refa540_op in H. discriminate H. Qed.

Lemma refa540_not4130 : ~ @Equation4130 Fin4 refa540_inst.
Proof. unfold Equation4130. intro H. specialize (H F4_0 F4_0). unfold magma_op, refa540_inst, refa540_op in H. discriminate H. Qed.

Lemma refa540_not4155 : ~ @Equation4155 Fin4 refa540_inst.
Proof. unfold Equation4155. intro H. specialize (H F4_0 F4_0). unfold magma_op, refa540_inst, refa540_op in H. discriminate H. Qed.

Lemma refa540_not4164 : ~ @Equation4164 Fin4 refa540_inst.
Proof. unfold Equation4164. intro H. specialize (H F4_0 F4_0). unfold magma_op, refa540_inst, refa540_op in H. discriminate H. Qed.

Lemma refa540_not4165 : ~ @Equation4165 Fin4 refa540_inst.
Proof. unfold Equation4165. intro H. specialize (H F4_0 F4_0). unfold magma_op, refa540_inst, refa540_op in H. discriminate H. Qed.

Lemma refa540_not4268 : ~ @Equation4268 Fin4 refa540_inst.
Proof. unfold Equation4268. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa540_inst, refa540_op in H. discriminate H. Qed.

Lemma refa540_not4269 : ~ @Equation4269 Fin4 refa540_inst.
Proof. unfold Equation4269. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa540_inst, refa540_op in H. discriminate H. Qed.

Lemma refa540_not4270 : ~ @Equation4270 Fin4 refa540_inst.
Proof. unfold Equation4270. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa540_inst, refa540_op in H. discriminate H. Qed.

Lemma refa540_not4272 : ~ @Equation4272 Fin4 refa540_inst.
Proof. unfold Equation4272. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa540_inst, refa540_op in H. discriminate H. Qed.

Lemma refa540_not4273 : ~ @Equation4273 Fin4 refa540_inst.
Proof. unfold Equation4273. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa540_inst, refa540_op in H. discriminate H. Qed.

Lemma refa540_not4276 : ~ @Equation4276 Fin4 refa540_inst.
Proof. unfold Equation4276. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa540_inst, refa540_op in H. discriminate H. Qed.

Lemma refa540_not4284 : ~ @Equation4284 Fin4 refa540_inst.
Proof. unfold Equation4284. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa540_inst, refa540_op in H. discriminate H. Qed.

Lemma refa540_not4290 : ~ @Equation4290 Fin4 refa540_inst.
Proof. unfold Equation4290. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa540_inst, refa540_op in H. discriminate H. Qed.

Lemma refa540_not4291 : ~ @Equation4291 Fin4 refa540_inst.
Proof. unfold Equation4291. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa540_inst, refa540_op in H. discriminate H. Qed.

Lemma refa540_not4314 : ~ @Equation4314 Fin4 refa540_inst.
Proof. unfold Equation4314. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa540_inst, refa540_op in H. discriminate H. Qed.

Lemma refa540_not4320 : ~ @Equation4320 Fin4 refa540_inst.
Proof. unfold Equation4320. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa540_inst, refa540_op in H. discriminate H. Qed.

Lemma refa540_not4321 : ~ @Equation4321 Fin4 refa540_inst.
Proof. unfold Equation4321. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa540_inst, refa540_op in H. discriminate H. Qed.

Lemma refa540_not4343 : ~ @Equation4343 Fin4 refa540_inst.
Proof. unfold Equation4343. intro H. specialize (H F4_0 F4_3). unfold magma_op, refa540_inst, refa540_op in H. discriminate H. Qed.

Lemma refa540_not4396 : ~ @Equation4396 Fin4 refa540_inst.
Proof. unfold Equation4396. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa540_inst, refa540_op in H. discriminate H. Qed.

Lemma refa540_not4399 : ~ @Equation4399 Fin4 refa540_inst.
Proof. unfold Equation4399. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa540_inst, refa540_op in H. discriminate H. Qed.

Lemma refa540_not4406 : ~ @Equation4406 Fin4 refa540_inst.
Proof. unfold Equation4406. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa540_inst, refa540_op in H. discriminate H. Qed.

Lemma refa540_not4408 : ~ @Equation4408 Fin4 refa540_inst.
Proof. unfold Equation4408. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa540_inst, refa540_op in H. discriminate H. Qed.

Lemma refa540_not4433 : ~ @Equation4433 Fin4 refa540_inst.
Proof. unfold Equation4433. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa540_inst, refa540_op in H. discriminate H. Qed.

Lemma refa540_not4436 : ~ @Equation4436 Fin4 refa540_inst.
Proof. unfold Equation4436. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa540_inst, refa540_op in H. discriminate H. Qed.

Lemma refa540_not4443 : ~ @Equation4443 Fin4 refa540_inst.
Proof. unfold Equation4443. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa540_inst, refa540_op in H. discriminate H. Qed.

Lemma refa540_not4445 : ~ @Equation4445 Fin4 refa540_inst.
Proof. unfold Equation4445. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa540_inst, refa540_op in H. discriminate H. Qed.

Lemma refa540_not4472 : ~ @Equation4472 Fin4 refa540_inst.
Proof. unfold Equation4472. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa540_inst, refa540_op in H. discriminate H. Qed.

Lemma refa540_not4473 : ~ @Equation4473 Fin4 refa540_inst.
Proof. unfold Equation4473. intro H. specialize (H F4_0 F4_2). unfold magma_op, refa540_inst, refa540_op in H. discriminate H. Qed.

Lemma refa540_not4479 : ~ @Equation4479 Fin4 refa540_inst.
Proof. unfold Equation4479. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa540_inst, refa540_op in H. discriminate H. Qed.

Lemma refa540_not4480 : ~ @Equation4480 Fin4 refa540_inst.
Proof. unfold Equation4480. intro H. specialize (H F4_0 F4_2). unfold magma_op, refa540_inst, refa540_op in H. discriminate H. Qed.

Lemma refa540_not4583 : ~ @Equation4583 Fin4 refa540_inst.
Proof. unfold Equation4583. intro H. specialize (H F4_0 F4_2). unfold magma_op, refa540_inst, refa540_op in H. discriminate H. Qed.

Lemma refa540_not4584 : ~ @Equation4584 Fin4 refa540_inst.
Proof. unfold Equation4584. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa540_inst, refa540_op in H. discriminate H. Qed.

Lemma refa540_not4587 : ~ @Equation4587 Fin4 refa540_inst.
Proof. unfold Equation4587. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa540_inst, refa540_op in H. discriminate H. Qed.

Lemma refa540_not4590 : ~ @Equation4590 Fin4 refa540_inst.
Proof. unfold Equation4590. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa540_inst, refa540_op in H. discriminate H. Qed.

Lemma refa540_not4591 : ~ @Equation4591 Fin4 refa540_inst.
Proof. unfold Equation4591. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa540_inst, refa540_op in H. discriminate H. Qed.

Lemma refa540_not4598 : ~ @Equation4598 Fin4 refa540_inst.
Proof. unfold Equation4598. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa540_inst, refa540_op in H. discriminate H. Qed.

Lemma refa540_not4599 : ~ @Equation4599 Fin4 refa540_inst.
Proof. unfold Equation4599. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa540_inst, refa540_op in H. discriminate H. Qed.

Lemma refa540_not4605 : ~ @Equation4605 Fin4 refa540_inst.
Proof. unfold Equation4605. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa540_inst, refa540_op in H. discriminate H. Qed.

Lemma refa540_not4606 : ~ @Equation4606 Fin4 refa540_inst.
Proof. unfold Equation4606. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa540_inst, refa540_op in H. discriminate H. Qed.

Lemma refa540_not4629 : ~ @Equation4629 Fin4 refa540_inst.
Proof. unfold Equation4629. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa540_inst, refa540_op in H. discriminate H. Qed.

Lemma refa540_not4636 : ~ @Equation4636 Fin4 refa540_inst.
Proof. unfold Equation4636. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa540_inst, refa540_op in H. discriminate H. Qed.

Lemma refa540_not4658 : ~ @Equation4658 Fin4 refa540_inst.
Proof. unfold Equation4658. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa540_inst, refa540_op in H. discriminate H. Qed.

(** ---- refa541 (Fin4) ---- *)

Definition refa541_op (x y : Fin4) : Fin4 :=
  match x, y with
  | F4_0, F4_0 => F4_2 | F4_0, F4_1 => F4_2 | F4_0, F4_2 => F4_1 | F4_0, F4_3 => F4_1
  | F4_1, F4_0 => F4_3 | F4_1, F4_1 => F4_3 | F4_1, F4_2 => F4_0 | F4_1, F4_3 => F4_0
  | F4_2, F4_0 => F4_2 | F4_2, F4_1 => F4_2 | F4_2, F4_2 => F4_0 | F4_2, F4_3 => F4_0
  | F4_3, F4_0 => F4_3 | F4_3, F4_1 => F4_3 | F4_3, F4_2 => F4_1 | F4_3, F4_3 => F4_1
  end.

#[local] Instance refa541_inst : Magma Fin4 := {| magma_op := refa541_op |}.

Lemma refa541_sat162 : @Equation162 Fin4 refa541_inst.
Proof. unfold Equation162, magma_op, refa541_inst, refa541_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa541_not4070 : ~ @Equation4070 Fin4 refa541_inst.
Proof. unfold Equation4070. intro H. specialize (H F4_0 F4_2). unfold magma_op, refa541_inst, refa541_op in H. discriminate H. Qed.

Lemma refa541_not4118 : ~ @Equation4118 Fin4 refa541_inst.
Proof. unfold Equation4118. intro H. specialize (H F4_0 F4_2). unfold magma_op, refa541_inst, refa541_op in H. discriminate H. Qed.

Lemma refa541_not4584 : ~ @Equation4584 Fin4 refa541_inst.
Proof. unfold Equation4584. intro H. specialize (H F4_0 F4_2). unfold magma_op, refa541_inst, refa541_op in H. discriminate H. Qed.

(** ---- refa542 (Fin4) ---- *)

Definition refa542_op (x y : Fin4) : Fin4 :=
  match x, y with
  | F4_0, F4_0 => F4_3 | F4_0, F4_1 => F4_2 | F4_0, F4_2 => F4_2 | F4_0, F4_3 => F4_3
  | F4_1, F4_0 => F4_3 | F4_1, F4_1 => F4_2 | F4_1, F4_2 => F4_2 | F4_1, F4_3 => F4_3
  | F4_2, F4_0 => F4_2 | F4_2, F4_1 => F4_2 | F4_2, F4_2 => F4_2 | F4_2, F4_3 => F4_2
  | F4_3, F4_0 => F4_3 | F4_3, F4_1 => F4_3 | F4_3, F4_2 => F4_3 | F4_3, F4_3 => F4_3
  end.

#[local] Instance refa542_inst : Magma Fin4 := {| magma_op := refa542_op |}.

Lemma refa542_sat3919 : @Equation3919 Fin4 refa542_inst.
Proof. unfold Equation3919, magma_op, refa542_inst, refa542_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa542_sat3929 : @Equation3929 Fin4 refa542_inst.
Proof. unfold Equation3929, magma_op, refa542_inst, refa542_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa542_not3308 : ~ @Equation3308 Fin4 refa542_inst.
Proof. unfold Equation3308. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa542_inst, refa542_op in H. discriminate H. Qed.

Lemma refa542_not3315 : ~ @Equation3315 Fin4 refa542_inst.
Proof. unfold Equation3315. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa542_inst, refa542_op in H. discriminate H. Qed.

Lemma refa542_not3318 : ~ @Equation3318 Fin4 refa542_inst.
Proof. unfold Equation3318. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa542_inst, refa542_op in H. discriminate H. Qed.

Lemma refa542_not3518 : ~ @Equation3518 Fin4 refa542_inst.
Proof. unfold Equation3518. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa542_inst, refa542_op in H. discriminate H. Qed.

Lemma refa542_not3519 : ~ @Equation3519 Fin4 refa542_inst.
Proof. unfold Equation3519. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa542_inst, refa542_op in H. discriminate H. Qed.

Lemma refa542_not3924 : ~ @Equation3924 Fin4 refa542_inst.
Proof. unfold Equation3924. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa542_inst, refa542_op in H. discriminate H. Qed.

Lemma refa542_not3925 : ~ @Equation3925 Fin4 refa542_inst.
Proof. unfold Equation3925. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa542_inst, refa542_op in H. discriminate H. Qed.

Lemma refa542_not4314 : ~ @Equation4314 Fin4 refa542_inst.
Proof. unfold Equation4314. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa542_inst, refa542_op in H. discriminate H. Qed.

Lemma refa542_not4435 : ~ @Equation4435 Fin4 refa542_inst.
Proof. unfold Equation4435. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa542_inst, refa542_op in H. discriminate H. Qed.

Lemma refa542_not4436 : ~ @Equation4436 Fin4 refa542_inst.
Proof. unfold Equation4436. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa542_inst, refa542_op in H. discriminate H. Qed.

(** ---- refa543 (Fin4) ---- *)

Definition refa543_op (x y : Fin4) : Fin4 :=
  match x, y with
  | F4_0, F4_0 => F4_3 | F4_0, F4_1 => F4_1 | F4_0, F4_2 => F4_1 | F4_0, F4_3 => F4_3
  | F4_1, F4_0 => F4_2 | F4_1, F4_1 => F4_3 | F4_1, F4_2 => F4_3 | F4_1, F4_3 => F4_3
  | F4_2, F4_0 => F4_0 | F4_2, F4_1 => F4_1 | F4_2, F4_2 => F4_3 | F4_2, F4_3 => F4_3
  | F4_3, F4_0 => F4_3 | F4_3, F4_1 => F4_3 | F4_3, F4_2 => F4_3 | F4_3, F4_3 => F4_3
  end.

#[local] Instance refa543_inst : Magma Fin4 := {| magma_op := refa543_op |}.

Lemma refa543_sat4110 : @Equation4110 Fin4 refa543_inst.
Proof. unfold Equation4110, magma_op, refa543_inst, refa543_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa543_not4070 : ~ @Equation4070 Fin4 refa543_inst.
Proof. unfold Equation4070. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa543_inst, refa543_op in H. discriminate H. Qed.

Lemma refa543_not4073 : ~ @Equation4073 Fin4 refa543_inst.
Proof. unfold Equation4073. intro H. specialize (H F4_1 F4_0). unfold magma_op, refa543_inst, refa543_op in H. discriminate H. Qed.

Lemma refa543_not4081 : ~ @Equation4081 Fin4 refa543_inst.
Proof. unfold Equation4081. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa543_inst, refa543_op in H. discriminate H. Qed.

Lemma refa543_not4084 : ~ @Equation4084 Fin4 refa543_inst.
Proof. unfold Equation4084. intro H. specialize (H F4_1 F4_0). unfold magma_op, refa543_inst, refa543_op in H. discriminate H. Qed.

(** ---- refa544 (Fin4) ---- *)

Definition refa544_op (x y : Fin4) : Fin4 :=
  match x, y with
  | F4_0, F4_0 => F4_3 | F4_0, F4_1 => F4_1 | F4_0, F4_2 => F4_3 | F4_0, F4_3 => F4_1
  | F4_1, F4_0 => F4_3 | F4_1, F4_1 => F4_0 | F4_1, F4_2 => F4_0 | F4_1, F4_3 => F4_3
  | F4_2, F4_0 => F4_2 | F4_2, F4_1 => F4_2 | F4_2, F4_2 => F4_2 | F4_2, F4_3 => F4_2
  | F4_3, F4_0 => F4_0 | F4_3, F4_1 => F4_0 | F4_3, F4_2 => F4_0 | F4_3, F4_3 => F4_1
  end.

#[local] Instance refa544_inst : Magma Fin4 := {| magma_op := refa544_op |}.

Lemma refa544_sat1443 : @Equation1443 Fin4 refa544_inst.
Proof. unfold Equation1443, magma_op, refa544_inst, refa544_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa544_not1432 : ~ @Equation1432 Fin4 refa544_inst.
Proof. unfold Equation1432. intro H. specialize (H F4_1 F4_2). unfold magma_op, refa544_inst, refa544_op in H. discriminate H. Qed.

Lemma refa544_not1635 : ~ @Equation1635 Fin4 refa544_inst.
Proof. unfold Equation1635. intro H. specialize (H F4_1 F4_2). unfold magma_op, refa544_inst, refa544_op in H. discriminate H. Qed.

(** ---- refa545 (Fin4) ---- *)

Definition refa545_op (x y : Fin4) : Fin4 :=
  match x, y with
  | F4_0, F4_0 => F4_3 | F4_0, F4_1 => F4_0 | F4_0, F4_2 => F4_3 | F4_0, F4_3 => F4_3
  | F4_1, F4_0 => F4_3 | F4_1, F4_1 => F4_3 | F4_1, F4_2 => F4_3 | F4_1, F4_3 => F4_3
  | F4_2, F4_0 => F4_2 | F4_2, F4_1 => F4_2 | F4_2, F4_2 => F4_3 | F4_2, F4_3 => F4_3
  | F4_3, F4_0 => F4_3 | F4_3, F4_1 => F4_3 | F4_3, F4_2 => F4_3 | F4_3, F4_3 => F4_3
  end.

#[local] Instance refa545_inst : Magma Fin4 := {| magma_op := refa545_op |}.

Lemma refa545_sat3681 : @Equation3681 Fin4 refa545_inst.
Proof. unfold Equation3681, magma_op, refa545_inst, refa545_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa545_not3671 : ~ @Equation3671 Fin4 refa545_inst.
Proof. unfold Equation3671. intro H. specialize (H F4_2 F4_1 F4_0). unfold magma_op, refa545_inst, refa545_op in H. discriminate H. Qed.

Lemma refa545_not3680 : ~ @Equation3680 Fin4 refa545_inst.
Proof. unfold Equation3680. intro H. specialize (H F4_1 F4_2 F4_0). unfold magma_op, refa545_inst, refa545_op in H. discriminate H. Qed.

Lemma refa545_not3702 : ~ @Equation3702 Fin4 refa545_inst.
Proof. unfold Equation3702. intro H. specialize (H F4_1 F4_2 F4_0). unfold magma_op, refa545_inst, refa545_op in H. discriminate H. Qed.

(** ---- refa546 (Fin4) ---- *)

Definition refa546_op (x y : Fin4) : Fin4 :=
  match x, y with
  | F4_0, F4_0 => F4_0 | F4_0, F4_1 => F4_1 | F4_0, F4_2 => F4_2 | F4_0, F4_3 => F4_3
  | F4_1, F4_0 => F4_1 | F4_1, F4_1 => F4_0 | F4_1, F4_2 => F4_0 | F4_1, F4_3 => F4_0
  | F4_2, F4_0 => F4_2 | F4_2, F4_1 => F4_2 | F4_2, F4_2 => F4_0 | F4_2, F4_3 => F4_0
  | F4_3, F4_0 => F4_3 | F4_3, F4_1 => F4_2 | F4_3, F4_2 => F4_0 | F4_3, F4_3 => F4_0
  end.

#[local] Instance refa546_inst : Magma Fin4 := {| magma_op := refa546_op |}.

Lemma refa546_sat647 : @Equation647 Fin4 refa546_inst.
Proof. unfold Equation647, magma_op, refa546_inst, refa546_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa546_not1023 : ~ @Equation1023 Fin4 refa546_inst.
Proof. unfold Equation1023. intro H. specialize (H F4_3 F4_1). unfold magma_op, refa546_inst, refa546_op in H. discriminate H. Qed.

(** ---- refa547 (Fin4) ---- *)

Definition refa547_op (x y : Fin4) : Fin4 :=
  match x, y with
  | F4_0, F4_0 => F4_0 | F4_0, F4_1 => F4_0 | F4_0, F4_2 => F4_3 | F4_0, F4_3 => F4_1
  | F4_1, F4_0 => F4_3 | F4_1, F4_1 => F4_2 | F4_1, F4_2 => F4_3 | F4_1, F4_3 => F4_1
  | F4_2, F4_0 => F4_1 | F4_2, F4_1 => F4_2 | F4_2, F4_2 => F4_3 | F4_2, F4_3 => F4_1
  | F4_3, F4_0 => F4_2 | F4_3, F4_1 => F4_2 | F4_3, F4_2 => F4_3 | F4_3, F4_3 => F4_1
  end.

#[local] Instance refa547_inst : Magma Fin4 := {| magma_op := refa547_op |}.

Lemma refa547_sat4121 : @Equation4121 Fin4 refa547_inst.
Proof. unfold Equation4121, magma_op, refa547_inst, refa547_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa547_not4131 : ~ @Equation4131 Fin4 refa547_inst.
Proof. unfold Equation4131. intro H. specialize (H F4_1 F4_0). unfold magma_op, refa547_inst, refa547_op in H. discriminate H. Qed.

Lemma refa547_not4284 : ~ @Equation4284 Fin4 refa547_inst.
Proof. unfold Equation4284. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa547_inst, refa547_op in H. discriminate H. Qed.

Lemma refa547_not4599 : ~ @Equation4599 Fin4 refa547_inst.
Proof. unfold Equation4599. intro H. specialize (H F4_1 F4_0). unfold magma_op, refa547_inst, refa547_op in H. discriminate H. Qed.

(** ---- refa548 (Fin4) ---- *)

Definition refa548_op (x y : Fin4) : Fin4 :=
  match x, y with
  | F4_0, F4_0 => F4_3 | F4_0, F4_1 => F4_1 | F4_0, F4_2 => F4_0 | F4_0, F4_3 => F4_1
  | F4_1, F4_0 => F4_2 | F4_1, F4_1 => F4_2 | F4_1, F4_2 => F4_1 | F4_1, F4_3 => F4_2
  | F4_2, F4_0 => F4_2 | F4_2, F4_1 => F4_2 | F4_2, F4_2 => F4_2 | F4_2, F4_3 => F4_2
  | F4_3, F4_0 => F4_2 | F4_3, F4_1 => F4_1 | F4_3, F4_2 => F4_3 | F4_3, F4_3 => F4_1
  end.

#[local] Instance refa548_inst : Magma Fin4 := {| magma_op := refa548_op |}.

Lemma refa548_sat1255 : @Equation1255 Fin4 refa548_inst.
Proof. unfold Equation1255, magma_op, refa548_inst, refa548_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa548_not817 : ~ @Equation817 Fin4 refa548_inst.
Proof. unfold Equation817. intro H. specialize (H F4_0). unfold magma_op, refa548_inst, refa548_op in H. discriminate H. Qed.

Lemma refa548_not1250 : ~ @Equation1250 Fin4 refa548_inst.
Proof. unfold Equation1250. intro H. specialize (H F4_1 F4_0 F4_2). unfold magma_op, refa548_inst, refa548_op in H. discriminate H. Qed.

Lemma refa548_not1254 : ~ @Equation1254 Fin4 refa548_inst.
Proof. unfold Equation1254. intro H. specialize (H F4_1 F4_0 F4_2). unfold magma_op, refa548_inst, refa548_op in H. discriminate H. Qed.

(** ---- refa549 (Fin4) ---- *)

Definition refa549_op (x y : Fin4) : Fin4 :=
  match x, y with
  | F4_0, F4_0 => F4_1 | F4_0, F4_1 => F4_3 | F4_0, F4_2 => F4_0 | F4_0, F4_3 => F4_1
  | F4_1, F4_0 => F4_2 | F4_1, F4_1 => F4_1 | F4_1, F4_2 => F4_3 | F4_1, F4_3 => F4_1
  | F4_2, F4_0 => F4_1 | F4_2, F4_1 => F4_1 | F4_2, F4_2 => F4_1 | F4_2, F4_3 => F4_2
  | F4_3, F4_0 => F4_2 | F4_3, F4_1 => F4_3 | F4_3, F4_2 => F4_3 | F4_3, F4_3 => F4_3
  end.

#[local] Instance refa549_inst : Magma Fin4 := {| magma_op := refa549_op |}.

Lemma refa549_sat1051 : @Equation1051 Fin4 refa549_inst.
Proof. unfold Equation1051, magma_op, refa549_inst, refa549_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa549_not1223 : ~ @Equation1223 Fin4 refa549_inst.
Proof. unfold Equation1223. intro H. specialize (H F4_0). unfold magma_op, refa549_inst, refa549_op in H. discriminate H. Qed.
