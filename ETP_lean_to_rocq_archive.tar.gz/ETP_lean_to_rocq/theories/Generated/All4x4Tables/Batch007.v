(** * All4x4 counterexamples — batch 7
    Auto-generated from Lean4 All4x4 files. *)

From Stdlib Require Import Utf8.

From ETP Require Import Magma.
From ETP Require Import FinMagma.
From ETP.Equations Require Import All.

Open Scope magma_scope.

(** ---- refa369 (Fin4) ---- *)

Definition refa369_op (x y : Fin4) : Fin4 :=
  match x, y with
  | F4_0, F4_0 => F4_3 | F4_0, F4_1 => F4_1 | F4_0, F4_2 => F4_3 | F4_0, F4_3 => F4_1
  | F4_1, F4_0 => F4_2 | F4_1, F4_1 => F4_3 | F4_1, F4_2 => F4_2 | F4_1, F4_3 => F4_3
  | F4_2, F4_0 => F4_2 | F4_2, F4_1 => F4_1 | F4_2, F4_2 => F4_3 | F4_2, F4_3 => F4_3
  | F4_3, F4_0 => F4_2 | F4_3, F4_1 => F4_3 | F4_3, F4_2 => F4_3 | F4_3, F4_3 => F4_3
  end.

#[local] Instance refa369_inst : Magma Fin4 := {| magma_op := refa369_op |}.

Lemma refa369_sat3492 : @Equation3492 Fin4 refa369_inst.
Proof. unfold Equation3492, magma_op, refa369_inst, refa369_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa369_not3253 : ~ @Equation3253 Fin4 refa369_inst.
Proof. unfold Equation3253. intro H. specialize (H F4_0). unfold magma_op, refa369_inst, refa369_op in H. discriminate H. Qed.

(** ---- refa370 (Fin4) ---- *)

Definition refa370_op (x y : Fin4) : Fin4 :=
  match x, y with
  | F4_0, F4_0 => F4_0 | F4_0, F4_1 => F4_0 | F4_0, F4_2 => F4_3 | F4_0, F4_3 => F4_3
  | F4_1, F4_0 => F4_3 | F4_1, F4_1 => F4_0 | F4_1, F4_2 => F4_2 | F4_1, F4_3 => F4_3
  | F4_2, F4_0 => F4_1 | F4_2, F4_1 => F4_0 | F4_2, F4_2 => F4_0 | F4_2, F4_3 => F4_1
  | F4_3, F4_0 => F4_0 | F4_3, F4_1 => F4_1 | F4_3, F4_2 => F4_3 | F4_3, F4_3 => F4_0
  end.

#[local] Instance refa370_inst : Magma Fin4 := {| magma_op := refa370_op |}.

Lemma refa370_sat2484 : @Equation2484 Fin4 refa370_inst.
Proof. unfold Equation2484, magma_op, refa370_inst, refa370_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa370_not2238 : ~ @Equation2238 Fin4 refa370_inst.
Proof. unfold Equation2238. intro H. specialize (H F4_2). unfold magma_op, refa370_inst, refa370_op in H. discriminate H. Qed.

Lemma refa370_not2644 : ~ @Equation2644 Fin4 refa370_inst.
Proof. unfold Equation2644. intro H. specialize (H F4_1). unfold magma_op, refa370_inst, refa370_op in H. discriminate H. Qed.

Lemma refa370_not4065 : ~ @Equation4065 Fin4 refa370_inst.
Proof. unfold Equation4065. intro H. specialize (H F4_2). unfold magma_op, refa370_inst, refa370_op in H. discriminate H. Qed.

(** ---- refa371 (Fin4) ---- *)

Definition refa371_op (x y : Fin4) : Fin4 :=
  match x, y with
  | F4_0, F4_0 => F4_3 | F4_0, F4_1 => F4_1 | F4_0, F4_2 => F4_3 | F4_0, F4_3 => F4_3
  | F4_1, F4_0 => F4_3 | F4_1, F4_1 => F4_3 | F4_1, F4_2 => F4_3 | F4_1, F4_3 => F4_3
  | F4_2, F4_0 => F4_3 | F4_2, F4_1 => F4_3 | F4_2, F4_2 => F4_1 | F4_2, F4_3 => F4_3
  | F4_3, F4_0 => F4_3 | F4_3, F4_1 => F4_3 | F4_3, F4_2 => F4_3 | F4_3, F4_3 => F4_3
  end.

#[local] Instance refa371_inst : Magma Fin4 := {| magma_op := refa371_op |}.

Lemma refa371_sat4444 : @Equation4444 Fin4 refa371_inst.
Proof. unfold Equation4444, magma_op, refa371_inst, refa371_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa371_not4270 : ~ @Equation4270 Fin4 refa371_inst.
Proof. unfold Equation4270. intro H. specialize (H F4_0 F4_2). unfold magma_op, refa371_inst, refa371_op in H. discriminate H. Qed.

Lemma refa371_not4272 : ~ @Equation4272 Fin4 refa371_inst.
Proof. unfold Equation4272. intro H. specialize (H F4_2 F4_0). unfold magma_op, refa371_inst, refa371_op in H. discriminate H. Qed.

Lemma refa371_not4314 : ~ @Equation4314 Fin4 refa371_inst.
Proof. unfold Equation4314. intro H. specialize (H F4_0 F4_2). unfold magma_op, refa371_inst, refa371_op in H. discriminate H. Qed.

Lemma refa371_not4320 : ~ @Equation4320 Fin4 refa371_inst.
Proof. unfold Equation4320. intro H. specialize (H F4_2 F4_0). unfold magma_op, refa371_inst, refa371_op in H. discriminate H. Qed.

Lemma refa371_not4343 : ~ @Equation4343 Fin4 refa371_inst.
Proof. unfold Equation4343. intro H. specialize (H F4_0 F4_2). unfold magma_op, refa371_inst, refa371_op in H. discriminate H. Qed.

Lemma refa371_not4470 : ~ @Equation4470 Fin4 refa371_inst.
Proof. unfold Equation4470. intro H. specialize (H F4_0 F4_2). unfold magma_op, refa371_inst, refa371_op in H. discriminate H. Qed.

Lemma refa371_not4472 : ~ @Equation4472 Fin4 refa371_inst.
Proof. unfold Equation4472. intro H. specialize (H F4_0 F4_2). unfold magma_op, refa371_inst, refa371_op in H. discriminate H. Qed.

Lemma refa371_not4473 : ~ @Equation4473 Fin4 refa371_inst.
Proof. unfold Equation4473. intro H. specialize (H F4_0 F4_2). unfold magma_op, refa371_inst, refa371_op in H. discriminate H. Qed.

Lemma refa371_not4479 : ~ @Equation4479 Fin4 refa371_inst.
Proof. unfold Equation4479. intro H. specialize (H F4_0 F4_2). unfold magma_op, refa371_inst, refa371_op in H. discriminate H. Qed.

Lemma refa371_not4480 : ~ @Equation4480 Fin4 refa371_inst.
Proof. unfold Equation4480. intro H. specialize (H F4_0 F4_2). unfold magma_op, refa371_inst, refa371_op in H. discriminate H. Qed.

Lemma refa371_not4482 : ~ @Equation4482 Fin4 refa371_inst.
Proof. unfold Equation4482. intro H. specialize (H F4_0 F4_2). unfold magma_op, refa371_inst, refa371_op in H. discriminate H. Qed.

(** ---- refa372 (Fin4) ---- *)

Definition refa372_op (x y : Fin4) : Fin4 :=
  match x, y with
  | F4_0, F4_0 => F4_3 | F4_0, F4_1 => F4_1 | F4_0, F4_2 => F4_1 | F4_0, F4_3 => F4_3
  | F4_1, F4_0 => F4_3 | F4_1, F4_1 => F4_3 | F4_1, F4_2 => F4_3 | F4_1, F4_3 => F4_3
  | F4_2, F4_0 => F4_1 | F4_2, F4_1 => F4_0 | F4_2, F4_2 => F4_3 | F4_2, F4_3 => F4_3
  | F4_3, F4_0 => F4_3 | F4_3, F4_1 => F4_3 | F4_3, F4_2 => F4_3 | F4_3, F4_3 => F4_3
  end.

#[local] Instance refa372_inst : Magma Fin4 := {| magma_op := refa372_op |}.

Lemma refa372_sat3676 : @Equation3676 Fin4 refa372_inst.
Proof. unfold Equation3676, magma_op, refa372_inst, refa372_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa372_sat4103 : @Equation4103 Fin4 refa372_inst.
Proof. unfold Equation4103, magma_op, refa372_inst, refa372_op. intros x y z w. destruct x, y, z, w; reflexivity. Qed.

Lemma refa372_not375 : ~ @Equation375 Fin4 refa372_inst.
Proof. unfold Equation375. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa372_inst, refa372_op in H. discriminate H. Qed.

Lemma refa372_not378 : ~ @Equation378 Fin4 refa372_inst.
Proof. unfold Equation378. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa372_inst, refa372_op in H. discriminate H. Qed.

Lemma refa372_not3666 : ~ @Equation3666 Fin4 refa372_inst.
Proof. unfold Equation3666. intro H. specialize (H F4_2 F4_1 F4_0). unfold magma_op, refa372_inst, refa372_op in H. discriminate H. Qed.

Lemma refa372_not3670 : ~ @Equation3670 Fin4 refa372_inst.
Proof. unfold Equation3670. intro H. specialize (H F4_2 F4_1 F4_0). unfold magma_op, refa372_inst, refa372_op in H. discriminate H. Qed.

Lemma refa372_not3671 : ~ @Equation3671 Fin4 refa372_inst.
Proof. unfold Equation3671. intro H. specialize (H F4_2 F4_1 F4_0). unfold magma_op, refa372_inst, refa372_op in H. discriminate H. Qed.

Lemma refa372_not3680 : ~ @Equation3680 Fin4 refa372_inst.
Proof. unfold Equation3680. intro H. specialize (H F4_1 F4_2 F4_0). unfold magma_op, refa372_inst, refa372_op in H. discriminate H. Qed.

Lemma refa372_not3698 : ~ @Equation3698 Fin4 refa372_inst.
Proof. unfold Equation3698. intro H. specialize (H F4_0 F4_2 F4_1). unfold magma_op, refa372_inst, refa372_op in H. discriminate H. Qed.

Lemma refa372_not3864 : ~ @Equation3864 Fin4 refa372_inst.
Proof. unfold Equation3864. intro H. specialize (H F4_2 F4_0). unfold magma_op, refa372_inst, refa372_op in H. discriminate H. Qed.

Lemma refa372_not3867 : ~ @Equation3867 Fin4 refa372_inst.
Proof. unfold Equation3867. intro H. specialize (H F4_2 F4_0). unfold magma_op, refa372_inst, refa372_op in H. discriminate H. Qed.

Lemma refa372_not3881 : ~ @Equation3881 Fin4 refa372_inst.
Proof. unfold Equation3881. intro H. specialize (H F4_0 F4_2). unfold magma_op, refa372_inst, refa372_op in H. discriminate H. Qed.

Lemma refa372_not3888 : ~ @Equation3888 Fin4 refa372_inst.
Proof. unfold Equation3888. intro H. specialize (H F4_0 F4_2). unfold magma_op, refa372_inst, refa372_op in H. discriminate H. Qed.

Lemma refa372_not4128 : ~ @Equation4128 Fin4 refa372_inst.
Proof. unfold Equation4128. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa372_inst, refa372_op in H. discriminate H. Qed.

Lemma refa372_not4269 : ~ @Equation4269 Fin4 refa372_inst.
Proof. unfold Equation4269. intro H. specialize (H F4_0 F4_2). unfold magma_op, refa372_inst, refa372_op in H. discriminate H. Qed.

Lemma refa372_not4314 : ~ @Equation4314 Fin4 refa372_inst.
Proof. unfold Equation4314. intro H. specialize (H F4_0 F4_2). unfold magma_op, refa372_inst, refa372_op in H. discriminate H. Qed.

Lemma refa372_not4320 : ~ @Equation4320 Fin4 refa372_inst.
Proof. unfold Equation4320. intro H. specialize (H F4_0 F4_2). unfold magma_op, refa372_inst, refa372_op in H. discriminate H. Qed.

Lemma refa372_not4598 : ~ @Equation4598 Fin4 refa372_inst.
Proof. unfold Equation4598. intro H. specialize (H F4_2 F4_1). unfold magma_op, refa372_inst, refa372_op in H. discriminate H. Qed.

Lemma refa372_not4599 : ~ @Equation4599 Fin4 refa372_inst.
Proof. unfold Equation4599. intro H. specialize (H F4_2 F4_1). unfold magma_op, refa372_inst, refa372_op in H. discriminate H. Qed.

Lemma refa372_not4605 : ~ @Equation4605 Fin4 refa372_inst.
Proof. unfold Equation4605. intro H. specialize (H F4_1 F4_2). unfold magma_op, refa372_inst, refa372_op in H. discriminate H. Qed.

Lemma refa372_not4606 : ~ @Equation4606 Fin4 refa372_inst.
Proof. unfold Equation4606. intro H. specialize (H F4_1 F4_2). unfold magma_op, refa372_inst, refa372_op in H. discriminate H. Qed.

Lemma refa372_not4630 : ~ @Equation4630 Fin4 refa372_inst.
Proof. unfold Equation4630. intro H. specialize (H F4_2 F4_1 F4_0). unfold magma_op, refa372_inst, refa372_op in H. discriminate H. Qed.

Lemma refa372_not4631 : ~ @Equation4631 Fin4 refa372_inst.
Proof. unfold Equation4631. intro H. specialize (H F4_2 F4_0 F4_1). unfold magma_op, refa372_inst, refa372_op in H. discriminate H. Qed.

Lemma refa372_not4635 : ~ @Equation4635 Fin4 refa372_inst.
Proof. unfold Equation4635. intro H. specialize (H F4_1 F4_2). unfold magma_op, refa372_inst, refa372_op in H. discriminate H. Qed.

Lemma refa372_not4636 : ~ @Equation4636 Fin4 refa372_inst.
Proof. unfold Equation4636. intro H. specialize (H F4_1 F4_2). unfold magma_op, refa372_inst, refa372_op in H. discriminate H. Qed.

Lemma refa372_not4647 : ~ @Equation4647 Fin4 refa372_inst.
Proof. unfold Equation4647. intro H. specialize (H F4_0 F4_1 F4_2). unfold magma_op, refa372_inst, refa372_op in H. discriminate H. Qed.

Lemma refa372_not4656 : ~ @Equation4656 Fin4 refa372_inst.
Proof. unfold Equation4656. intro H. specialize (H F4_2 F4_0 F4_1). unfold magma_op, refa372_inst, refa372_op in H. discriminate H. Qed.

Lemma refa372_not4658 : ~ @Equation4658 Fin4 refa372_inst.
Proof. unfold Equation4658. intro H. specialize (H F4_1 F4_2). unfold magma_op, refa372_inst, refa372_op in H. discriminate H. Qed.

Lemma refa372_not4666 : ~ @Equation4666 Fin4 refa372_inst.
Proof. unfold Equation4666. intro H. specialize (H F4_0 F4_1 F4_2). unfold magma_op, refa372_inst, refa372_op in H. discriminate H. Qed.

(** ---- refa373 (Fin4) ---- *)

Definition refa373_op (x y : Fin4) : Fin4 :=
  match x, y with
  | F4_0, F4_0 => F4_1 | F4_0, F4_1 => F4_3 | F4_0, F4_2 => F4_0 | F4_0, F4_3 => F4_1
  | F4_1, F4_0 => F4_2 | F4_1, F4_1 => F4_2 | F4_1, F4_2 => F4_1 | F4_1, F4_3 => F4_1
  | F4_2, F4_0 => F4_2 | F4_2, F4_1 => F4_2 | F4_2, F4_2 => F4_2 | F4_2, F4_3 => F4_2
  | F4_3, F4_0 => F4_1 | F4_3, F4_1 => F4_3 | F4_3, F4_2 => F4_3 | F4_3, F4_3 => F4_2
  end.

#[local] Instance refa373_inst : Magma Fin4 := {| magma_op := refa373_op |}.

Lemma refa373_sat1244 : @Equation1244 Fin4 refa373_inst.
Proof. unfold Equation1244, magma_op, refa373_inst, refa373_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa373_sat1250 : @Equation1250 Fin4 refa373_inst.
Proof. unfold Equation1250, magma_op, refa373_inst, refa373_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa373_sat1255 : @Equation1255 Fin4 refa373_inst.
Proof. unfold Equation1255, magma_op, refa373_inst, refa373_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa373_not1020 : ~ @Equation1020 Fin4 refa373_inst.
Proof. unfold Equation1020. intro H. specialize (H F4_0). unfold magma_op, refa373_inst, refa373_op in H. discriminate H. Qed.

Lemma refa373_not1239 : ~ @Equation1239 Fin4 refa373_inst.
Proof. unfold Equation1239. intro H. specialize (H F4_1 F4_0). unfold magma_op, refa373_inst, refa373_op in H. discriminate H. Qed.

(** ---- refa374 (Fin4) ---- *)

Definition refa374_op (x y : Fin4) : Fin4 :=
  match x, y with
  | F4_0, F4_0 => F4_2 | F4_0, F4_1 => F4_2 | F4_0, F4_2 => F4_0 | F4_0, F4_3 => F4_1
  | F4_1, F4_0 => F4_2 | F4_1, F4_1 => F4_0 | F4_1, F4_2 => F4_1 | F4_1, F4_3 => F4_2
  | F4_2, F4_0 => F4_2 | F4_2, F4_1 => F4_2 | F4_2, F4_2 => F4_2 | F4_2, F4_3 => F4_2
  | F4_3, F4_0 => F4_3 | F4_3, F4_1 => F4_3 | F4_3, F4_2 => F4_3 | F4_3, F4_3 => F4_0
  end.

#[local] Instance refa374_inst : Magma Fin4 := {| magma_op := refa374_op |}.

Lemma refa374_sat1250 : @Equation1250 Fin4 refa374_inst.
Proof. unfold Equation1250, magma_op, refa374_inst, refa374_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa374_not1225 : ~ @Equation1225 Fin4 refa374_inst.
Proof. unfold Equation1225. intro H. specialize (H F4_1 F4_3). unfold magma_op, refa374_inst, refa374_op in H. discriminate H. Qed.

Lemma refa374_not1251 : ~ @Equation1251 Fin4 refa374_inst.
Proof. unfold Equation1251. intro H. specialize (H F4_1 F4_3). unfold magma_op, refa374_inst, refa374_op in H. discriminate H. Qed.

(** ---- refa375 (Fin4) ---- *)

Definition refa375_op (x y : Fin4) : Fin4 :=
  match x, y with
  | F4_0, F4_0 => F4_3 | F4_0, F4_1 => F4_0 | F4_0, F4_2 => F4_3 | F4_0, F4_3 => F4_1
  | F4_1, F4_0 => F4_3 | F4_1, F4_1 => F4_2 | F4_1, F4_2 => F4_3 | F4_1, F4_3 => F4_1
  | F4_2, F4_0 => F4_2 | F4_2, F4_1 => F4_2 | F4_2, F4_2 => F4_3 | F4_2, F4_3 => F4_1
  | F4_3, F4_0 => F4_3 | F4_3, F4_1 => F4_2 | F4_3, F4_2 => F4_3 | F4_3, F4_3 => F4_1
  end.

#[local] Instance refa375_inst : Magma Fin4 := {| magma_op := refa375_op |}.

Lemma refa375_sat635 : @Equation635 Fin4 refa375_inst.
Proof. unfold Equation635, magma_op, refa375_inst, refa375_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa375_not639 : ~ @Equation639 Fin4 refa375_inst.
Proof. unfold Equation639. intro H. specialize (H F4_0 F4_2). unfold magma_op, refa375_inst, refa375_op in H. discriminate H. Qed.

Lemma refa375_not642 : ~ @Equation642 Fin4 refa375_inst.
Proof. unfold Equation642. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa375_inst, refa375_op in H. discriminate H. Qed.

Lemma refa375_not845 : ~ @Equation845 Fin4 refa375_inst.
Proof. unfold Equation845. intro H. specialize (H F4_0 F4_2). unfold magma_op, refa375_inst, refa375_op in H. discriminate H. Qed.

Lemma refa375_not1426 : ~ @Equation1426 Fin4 refa375_inst.
Proof. unfold Equation1426. intro H. specialize (H F4_0). unfold magma_op, refa375_inst, refa375_op in H. discriminate H. Qed.

(** ---- refa376 (Fin4) ---- *)

Definition refa376_op (x y : Fin4) : Fin4 :=
  match x, y with
  | F4_0, F4_0 => F4_0 | F4_0, F4_1 => F4_2 | F4_0, F4_2 => F4_0 | F4_0, F4_3 => F4_0
  | F4_1, F4_0 => F4_3 | F4_1, F4_1 => F4_3 | F4_1, F4_2 => F4_1 | F4_1, F4_3 => F4_1
  | F4_2, F4_0 => F4_2 | F4_2, F4_1 => F4_2 | F4_2, F4_2 => F4_0 | F4_2, F4_3 => F4_2
  | F4_3, F4_0 => F4_3 | F4_3, F4_1 => F4_3 | F4_3, F4_2 => F4_3 | F4_3, F4_3 => F4_3
  end.

#[local] Instance refa376_inst : Magma Fin4 := {| magma_op := refa376_op |}.

Lemma refa376_sat840 : @Equation840 Fin4 refa376_inst.
Proof. unfold Equation840, magma_op, refa376_inst, refa376_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa376_not105 : ~ @Equation105 Fin4 refa376_inst.
Proof. unfold Equation105. intro H. specialize (H F4_1 F4_2). unfold magma_op, refa376_inst, refa376_op in H. discriminate H. Qed.

Lemma refa376_not819 : ~ @Equation819 Fin4 refa376_inst.
Proof. unfold Equation819. intro H. specialize (H F4_2 F4_1). unfold magma_op, refa376_inst, refa376_op in H. discriminate H. Qed.

Lemma refa376_not835 : ~ @Equation835 Fin4 refa376_inst.
Proof. unfold Equation835. intro H. specialize (H F4_1 F4_0). unfold magma_op, refa376_inst, refa376_op in H. discriminate H. Qed.

Lemma refa376_not1224 : ~ @Equation1224 Fin4 refa376_inst.
Proof. unfold Equation1224. intro H. specialize (H F4_2 F4_1). unfold magma_op, refa376_inst, refa376_op in H. discriminate H. Qed.

Lemma refa376_not1226 : ~ @Equation1226 Fin4 refa376_inst.
Proof. unfold Equation1226. intro H. specialize (H F4_2 F4_1). unfold magma_op, refa376_inst, refa376_op in H. discriminate H. Qed.

Lemma refa376_not1249 : ~ @Equation1249 Fin4 refa376_inst.
Proof. unfold Equation1249. intro H. specialize (H F4_1 F4_2). unfold magma_op, refa376_inst, refa376_op in H. discriminate H. Qed.

(** ---- refa377 (Fin4) ---- *)

Definition refa377_op (x y : Fin4) : Fin4 :=
  match x, y with
  | F4_0, F4_0 => F4_0 | F4_0, F4_1 => F4_3 | F4_0, F4_2 => F4_1 | F4_0, F4_3 => F4_1
  | F4_1, F4_0 => F4_0 | F4_1, F4_1 => F4_1 | F4_1, F4_2 => F4_3 | F4_1, F4_3 => F4_2
  | F4_2, F4_0 => F4_0 | F4_2, F4_1 => F4_1 | F4_2, F4_2 => F4_2 | F4_2, F4_3 => F4_3
  | F4_3, F4_0 => F4_0 | F4_3, F4_1 => F4_1 | F4_3, F4_2 => F4_2 | F4_3, F4_3 => F4_3
  end.

#[local] Instance refa377_inst : Magma Fin4 := {| magma_op := refa377_op |}.

Lemma refa377_sat2584 : @Equation2584 Fin4 refa377_inst.
Proof. unfold Equation2584, magma_op, refa377_inst, refa377_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa377_sat2804 : @Equation2804 Fin4 refa377_inst.
Proof. unfold Equation2804, magma_op, refa377_inst, refa377_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa377_sat2973 : @Equation2973 Fin4 refa377_inst.
Proof. unfold Equation2973, magma_op, refa377_inst, refa377_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa377_sat4192 : @Equation4192 Fin4 refa377_inst.
Proof. unfold Equation4192, magma_op, refa377_inst, refa377_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa377_sat4209 : @Equation4209 Fin4 refa377_inst.
Proof. unfold Equation4209, magma_op, refa377_inst, refa377_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa377_not208 : ~ @Equation208 Fin4 refa377_inst.
Proof. unfold Equation208. intro H. specialize (H F4_2 F4_0). unfold magma_op, refa377_inst, refa377_op in H. discriminate H. Qed.

Lemma refa377_not280 : ~ @Equation280 Fin4 refa377_inst.
Proof. unfold Equation280. intro H. specialize (H F4_2 F4_0). unfold magma_op, refa377_inst, refa377_op in H. discriminate H. Qed.

Lemma refa377_not323 : ~ @Equation323 Fin4 refa377_inst.
Proof. unfold Equation323. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa377_inst, refa377_op in H. discriminate H. Qed.

Lemma refa377_not333 : ~ @Equation333 Fin4 refa377_inst.
Proof. unfold Equation333. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa377_inst, refa377_op in H. discriminate H. Qed.

Lemma refa377_not619 : ~ @Equation619 Fin4 refa377_inst.
Proof. unfold Equation619. intro H. specialize (H F4_2 F4_0). unfold magma_op, refa377_inst, refa377_op in H. discriminate H. Qed.

Lemma refa377_not832 : ~ @Equation832 Fin4 refa377_inst.
Proof. unfold Equation832. intro H. specialize (H F4_2 F4_0). unfold magma_op, refa377_inst, refa377_op in H. discriminate H. Qed.

Lemma refa377_not1035 : ~ @Equation1035 Fin4 refa377_inst.
Proof. unfold Equation1035. intro H. specialize (H F4_2 F4_0). unfold magma_op, refa377_inst, refa377_op in H. discriminate H. Qed.

Lemma refa377_not1228 : ~ @Equation1228 Fin4 refa377_inst.
Proof. unfold Equation1228. intro H. specialize (H F4_2 F4_0). unfold magma_op, refa377_inst, refa377_op in H. discriminate H. Qed.

Lemma refa377_not1248 : ~ @Equation1248 Fin4 refa377_inst.
Proof. unfold Equation1248. intro H. specialize (H F4_2 F4_0). unfold magma_op, refa377_inst, refa377_op in H. discriminate H. Qed.

Lemma refa377_not1478 : ~ @Equation1478 Fin4 refa377_inst.
Proof. unfold Equation1478. intro H. specialize (H F4_2 F4_0). unfold magma_op, refa377_inst, refa377_op in H. discriminate H. Qed.

Lemma refa377_not1634 : ~ @Equation1634 Fin4 refa377_inst.
Proof. unfold Equation1634. intro H. specialize (H F4_2 F4_0). unfold magma_op, refa377_inst, refa377_op in H. discriminate H. Qed.

Lemma refa377_not1681 : ~ @Equation1681 Fin4 refa377_inst.
Proof. unfold Equation1681. intro H. specialize (H F4_2 F4_0). unfold magma_op, refa377_inst, refa377_op in H. discriminate H. Qed.

Lemma refa377_not1884 : ~ @Equation1884 Fin4 refa377_inst.
Proof. unfold Equation1884. intro H. specialize (H F4_2 F4_0). unfold magma_op, refa377_inst, refa377_op in H. discriminate H. Qed.

Lemma refa377_not2050 : ~ @Equation2050 Fin4 refa377_inst.
Proof. unfold Equation2050. intro H. specialize (H F4_2 F4_0). unfold magma_op, refa377_inst, refa377_op in H. discriminate H. Qed.

Lemma refa377_not2124 : ~ @Equation2124 Fin4 refa377_inst.
Proof. unfold Equation2124. intro H. specialize (H F4_2 F4_0). unfold magma_op, refa377_inst, refa377_op in H. discriminate H. Qed.

Lemma refa377_not2290 : ~ @Equation2290 Fin4 refa377_inst.
Proof. unfold Equation2290. intro H. specialize (H F4_2 F4_0). unfold magma_op, refa377_inst, refa377_op in H. discriminate H. Qed.

Lemma refa377_not2337 : ~ @Equation2337 Fin4 refa377_inst.
Proof. unfold Equation2337. intro H. specialize (H F4_2 F4_0). unfold magma_op, refa377_inst, refa377_op in H. discriminate H. Qed.

Lemma refa377_not2493 : ~ @Equation2493 Fin4 refa377_inst.
Proof. unfold Equation2493. intro H. specialize (H F4_2 F4_0). unfold magma_op, refa377_inst, refa377_op in H. discriminate H. Qed.

Lemma refa377_not2530 : ~ @Equation2530 Fin4 refa377_inst.
Proof. unfold Equation2530. intro H. specialize (H F4_2 F4_0). unfold magma_op, refa377_inst, refa377_op in H. discriminate H. Qed.

Lemma refa377_not2659 : ~ @Equation2659 Fin4 refa377_inst.
Proof. unfold Equation2659. intro H. specialize (H F4_2 F4_0). unfold magma_op, refa377_inst, refa377_op in H. discriminate H. Qed.

Lemma refa377_not2706 : ~ @Equation2706 Fin4 refa377_inst.
Proof. unfold Equation2706. intro H. specialize (H F4_2 F4_0). unfold magma_op, refa377_inst, refa377_op in H. discriminate H. Qed.

Lemma refa377_not2733 : ~ @Equation2733 Fin4 refa377_inst.
Proof. unfold Equation2733. intro H. specialize (H F4_2 F4_0). unfold magma_op, refa377_inst, refa377_op in H. discriminate H. Qed.

Lemma refa377_not2852 : ~ @Equation2852 Fin4 refa377_inst.
Proof. unfold Equation2852. intro H. specialize (H F4_2 F4_0). unfold magma_op, refa377_inst, refa377_op in H. discriminate H. Qed.

Lemma refa377_not2872 : ~ @Equation2872 Fin4 refa377_inst.
Proof. unfold Equation2872. intro H. specialize (H F4_2 F4_0). unfold magma_op, refa377_inst, refa377_op in H. discriminate H. Qed.

Lemma refa377_not2909 : ~ @Equation2909 Fin4 refa377_inst.
Proof. unfold Equation2909. intro H. specialize (H F4_2 F4_0). unfold magma_op, refa377_inst, refa377_op in H. discriminate H. Qed.

Lemma refa377_not2946 : ~ @Equation2946 Fin4 refa377_inst.
Proof. unfold Equation2946. intro H. specialize (H F4_2 F4_0). unfold magma_op, refa377_inst, refa377_op in H. discriminate H. Qed.

Lemma refa377_not3055 : ~ @Equation3055 Fin4 refa377_inst.
Proof. unfold Equation3055. intro H. specialize (H F4_2 F4_0). unfold magma_op, refa377_inst, refa377_op in H. discriminate H. Qed.

Lemma refa377_not3075 : ~ @Equation3075 Fin4 refa377_inst.
Proof. unfold Equation3075. intro H. specialize (H F4_2 F4_0). unfold magma_op, refa377_inst, refa377_op in H. discriminate H. Qed.

Lemma refa377_not3112 : ~ @Equation3112 Fin4 refa377_inst.
Proof. unfold Equation3112. intro H. specialize (H F4_2 F4_0). unfold magma_op, refa377_inst, refa377_op in H. discriminate H. Qed.

Lemma refa377_not3149 : ~ @Equation3149 Fin4 refa377_inst.
Proof. unfold Equation3149. intro H. specialize (H F4_2 F4_0). unfold magma_op, refa377_inst, refa377_op in H. discriminate H. Qed.

Lemma refa377_not3309 : ~ @Equation3309 Fin4 refa377_inst.
Proof. unfold Equation3309. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa377_inst, refa377_op in H. discriminate H. Qed.

Lemma refa377_not3461 : ~ @Equation3461 Fin4 refa377_inst.
Proof. unfold Equation3461. intro H. specialize (H F4_2 F4_0). unfold magma_op, refa377_inst, refa377_op in H. discriminate H. Qed.

Lemma refa377_not3509 : ~ @Equation3509 Fin4 refa377_inst.
Proof. unfold Equation3509. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa377_inst, refa377_op in H. discriminate H. Qed.

Lemma refa377_not3674 : ~ @Equation3674 Fin4 refa377_inst.
Proof. unfold Equation3674. intro H. specialize (H F4_2 F4_0). unfold magma_op, refa377_inst, refa377_op in H. discriminate H. Qed.

Lemma refa377_not3712 : ~ @Equation3712 Fin4 refa377_inst.
Proof. unfold Equation3712. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa377_inst, refa377_op in H. discriminate H. Qed.

Lemma refa377_not3867 : ~ @Equation3867 Fin4 refa377_inst.
Proof. unfold Equation3867. intro H. specialize (H F4_2 F4_0). unfold magma_op, refa377_inst, refa377_op in H. discriminate H. Qed.

Lemma refa377_not3877 : ~ @Equation3877 Fin4 refa377_inst.
Proof. unfold Equation3877. intro H. specialize (H F4_2 F4_0). unfold magma_op, refa377_inst, refa377_op in H. discriminate H. Qed.

Lemma refa377_not4070 : ~ @Equation4070 Fin4 refa377_inst.
Proof. unfold Equation4070. intro H. specialize (H F4_2 F4_0). unfold magma_op, refa377_inst, refa377_op in H. discriminate H. Qed.

Lemma refa377_not4090 : ~ @Equation4090 Fin4 refa377_inst.
Proof. unfold Equation4090. intro H. specialize (H F4_2 F4_0). unfold magma_op, refa377_inst, refa377_op in H. discriminate H. Qed.

Lemma refa377_not4269 : ~ @Equation4269 Fin4 refa377_inst.
Proof. unfold Equation4269. intro H. specialize (H F4_1 F4_0). unfold magma_op, refa377_inst, refa377_op in H. discriminate H. Qed.

Lemma refa377_not4284 : ~ @Equation4284 Fin4 refa377_inst.
Proof. unfold Equation4284. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa377_inst, refa377_op in H. discriminate H. Qed.

Lemma refa377_not4396 : ~ @Equation4396 Fin4 refa377_inst.
Proof. unfold Equation4396. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa377_inst, refa377_op in H. discriminate H. Qed.

Lemma refa377_not4666 : ~ @Equation4666 Fin4 refa377_inst.
Proof. unfold Equation4666. intro H. specialize (H F4_0 F4_2 F4_1). unfold magma_op, refa377_inst, refa377_op in H. discriminate H. Qed.

(** ---- refa378 (Fin4) ---- *)

Definition refa378_op (x y : Fin4) : Fin4 :=
  match x, y with
  | F4_0, F4_0 => F4_3 | F4_0, F4_1 => F4_2 | F4_0, F4_2 => F4_3 | F4_0, F4_3 => F4_1
  | F4_1, F4_0 => F4_3 | F4_1, F4_1 => F4_3 | F4_1, F4_2 => F4_0 | F4_1, F4_3 => F4_2
  | F4_2, F4_0 => F4_1 | F4_2, F4_1 => F4_3 | F4_2, F4_2 => F4_3 | F4_2, F4_3 => F4_0
  | F4_3, F4_0 => F4_2 | F4_3, F4_1 => F4_0 | F4_3, F4_2 => F4_1 | F4_3, F4_3 => F4_3
  end.

#[local] Instance refa378_inst : Magma Fin4 := {| magma_op := refa378_op |}.

Lemma refa378_sat1523 : @Equation1523 Fin4 refa378_inst.
Proof. unfold Equation1523, magma_op, refa378_inst, refa378_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa378_sat2132 : @Equation2132 Fin4 refa378_inst.
Proof. unfold Equation2132, magma_op, refa378_inst, refa378_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa378_sat3497 : @Equation3497 Fin4 refa378_inst.
Proof. unfold Equation3497, magma_op, refa378_inst, refa378_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa378_sat3549 : @Equation3549 Fin4 refa378_inst.
Proof. unfold Equation3549, magma_op, refa378_inst, refa378_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa378_sat3903 : @Equation3903 Fin4 refa378_inst.
Proof. unfold Equation3903, magma_op, refa378_inst, refa378_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa378_sat3917 : @Equation3917 Fin4 refa378_inst.
Proof. unfold Equation3917, magma_op, refa378_inst, refa378_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa378_not1629 : ~ @Equation1629 Fin4 refa378_inst.
Proof. unfold Equation1629. intro H. specialize (H F4_0). unfold magma_op, refa378_inst, refa378_op in H. discriminate H. Qed.

Lemma refa378_not1832 : ~ @Equation1832 Fin4 refa378_inst.
Proof. unfold Equation1832. intro H. specialize (H F4_0). unfold magma_op, refa378_inst, refa378_op in H. discriminate H. Qed.

Lemma refa378_not2238 : ~ @Equation2238 Fin4 refa378_inst.
Proof. unfold Equation2238. intro H. specialize (H F4_0). unfold magma_op, refa378_inst, refa378_op in H. discriminate H. Qed.

Lemma refa378_not2441 : ~ @Equation2441 Fin4 refa378_inst.
Proof. unfold Equation2441. intro H. specialize (H F4_0). unfold magma_op, refa378_inst, refa378_op in H. discriminate H. Qed.

Lemma refa378_not3253 : ~ @Equation3253 Fin4 refa378_inst.
Proof. unfold Equation3253. intro H. specialize (H F4_0). unfold magma_op, refa378_inst, refa378_op in H. discriminate H. Qed.

Lemma refa378_not3459 : ~ @Equation3459 Fin4 refa378_inst.
Proof. unfold Equation3459. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa378_inst, refa378_op in H. discriminate H. Qed.

Lemma refa378_not3481 : ~ @Equation3481 Fin4 refa378_inst.
Proof. unfold Equation3481. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa378_inst, refa378_op in H. discriminate H. Qed.

Lemma refa378_not3509 : ~ @Equation3509 Fin4 refa378_inst.
Proof. unfold Equation3509. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa378_inst, refa378_op in H. discriminate H. Qed.

Lemma refa378_not3518 : ~ @Equation3518 Fin4 refa378_inst.
Proof. unfold Equation3518. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa378_inst, refa378_op in H. discriminate H. Qed.

Lemma refa378_not3522 : ~ @Equation3522 Fin4 refa378_inst.
Proof. unfold Equation3522. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa378_inst, refa378_op in H. discriminate H. Qed.

Lemma refa378_not3667 : ~ @Equation3667 Fin4 refa378_inst.
Proof. unfold Equation3667. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa378_inst, refa378_op in H. discriminate H. Qed.

Lemma refa378_not3675 : ~ @Equation3675 Fin4 refa378_inst.
Proof. unfold Equation3675. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa378_inst, refa378_op in H. discriminate H. Qed.

Lemma refa378_not3962 : ~ @Equation3962 Fin4 refa378_inst.
Proof. unfold Equation3962. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa378_inst, refa378_op in H. discriminate H. Qed.

Lemma refa378_not4065 : ~ @Equation4065 Fin4 refa378_inst.
Proof. unfold Equation4065. intro H. specialize (H F4_0). unfold magma_op, refa378_inst, refa378_op in H. discriminate H. Qed.

Lemma refa378_not4273 : ~ @Equation4273 Fin4 refa378_inst.
Proof. unfold Equation4273. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa378_inst, refa378_op in H. discriminate H. Qed.

Lemma refa378_not4275 : ~ @Equation4275 Fin4 refa378_inst.
Proof. unfold Equation4275. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa378_inst, refa378_op in H. discriminate H. Qed.

Lemma refa378_not4283 : ~ @Equation4283 Fin4 refa378_inst.
Proof. unfold Equation4283. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa378_inst, refa378_op in H. discriminate H. Qed.

Lemma refa378_not4290 : ~ @Equation4290 Fin4 refa378_inst.
Proof. unfold Equation4290. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa378_inst, refa378_op in H. discriminate H. Qed.

Lemma refa378_not4320 : ~ @Equation4320 Fin4 refa378_inst.
Proof. unfold Equation4320. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa378_inst, refa378_op in H. discriminate H. Qed.

Lemma refa378_not4380 : ~ @Equation4380 Fin4 refa378_inst.
Proof. unfold Equation4380. intro H. specialize (H F4_0). unfold magma_op, refa378_inst, refa378_op in H. discriminate H. Qed.

Lemma refa378_not4598 : ~ @Equation4598 Fin4 refa378_inst.
Proof. unfold Equation4598. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa378_inst, refa378_op in H. discriminate H. Qed.

Lemma refa378_not4635 : ~ @Equation4635 Fin4 refa378_inst.
Proof. unfold Equation4635. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa378_inst, refa378_op in H. discriminate H. Qed.

Lemma refa378_not4647 : ~ @Equation4647 Fin4 refa378_inst.
Proof. unfold Equation4647. intro H. specialize (H F4_0 F4_0 F4_1). unfold magma_op, refa378_inst, refa378_op in H. discriminate H. Qed.

(** ---- refa379 (Fin4) ---- *)

Definition refa379_op (x y : Fin4) : Fin4 :=
  match x, y with
  | F4_0, F4_0 => F4_0 | F4_0, F4_1 => F4_0 | F4_0, F4_2 => F4_1 | F4_0, F4_3 => F4_0
  | F4_1, F4_0 => F4_1 | F4_1, F4_1 => F4_1 | F4_1, F4_2 => F4_1 | F4_1, F4_3 => F4_0
  | F4_2, F4_0 => F4_1 | F4_2, F4_1 => F4_2 | F4_2, F4_2 => F4_2 | F4_2, F4_3 => F4_1
  | F4_3, F4_0 => F4_2 | F4_3, F4_1 => F4_3 | F4_3, F4_2 => F4_3 | F4_3, F4_3 => F4_3
  end.

#[local] Instance refa379_inst : Magma Fin4 := {| magma_op := refa379_op |}.

Lemma refa379_sat824 : @Equation824 Fin4 refa379_inst.
Proof. unfold Equation824, magma_op, refa379_inst, refa379_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa379_not825 : ~ @Equation825 Fin4 refa379_inst.
Proof. unfold Equation825. intro H. specialize (H F4_2 F4_3). unfold magma_op, refa379_inst, refa379_op in H. discriminate H. Qed.

Lemma refa379_not826 : ~ @Equation826 Fin4 refa379_inst.
Proof. unfold Equation826. intro H. specialize (H F4_2 F4_3). unfold magma_op, refa379_inst, refa379_op in H. discriminate H. Qed.

Lemma refa379_not1026 : ~ @Equation1026 Fin4 refa379_inst.
Proof. unfold Equation1026. intro H. specialize (H F4_2 F4_3). unfold magma_op, refa379_inst, refa379_op in H. discriminate H. Qed.

Lemma refa379_not1029 : ~ @Equation1029 Fin4 refa379_inst.
Proof. unfold Equation1029. intro H. specialize (H F4_2 F4_3). unfold magma_op, refa379_inst, refa379_op in H. discriminate H. Qed.

Lemma refa379_not1226 : ~ @Equation1226 Fin4 refa379_inst.
Proof. unfold Equation1226. intro H. specialize (H F4_2 F4_3). unfold magma_op, refa379_inst, refa379_op in H. discriminate H. Qed.

Lemma refa379_not1228 : ~ @Equation1228 Fin4 refa379_inst.
Proof. unfold Equation1228. intro H. specialize (H F4_3 F4_0). unfold magma_op, refa379_inst, refa379_op in H. discriminate H. Qed.

Lemma refa379_not1229 : ~ @Equation1229 Fin4 refa379_inst.
Proof. unfold Equation1229. intro H. specialize (H F4_2 F4_3). unfold magma_op, refa379_inst, refa379_op in H. discriminate H. Qed.

Lemma refa379_not1231 : ~ @Equation1231 Fin4 refa379_inst.
Proof. unfold Equation1231. intro H. specialize (H F4_3 F4_0). unfold magma_op, refa379_inst, refa379_op in H. discriminate H. Qed.

Lemma refa379_not1232 : ~ @Equation1232 Fin4 refa379_inst.
Proof. unfold Equation1232. intro H. specialize (H F4_2 F4_3). unfold magma_op, refa379_inst, refa379_op in H. discriminate H. Qed.

Lemma refa379_not1632 : ~ @Equation1632 Fin4 refa379_inst.
Proof. unfold Equation1632. intro H. specialize (H F4_2 F4_3). unfold magma_op, refa379_inst, refa379_op in H. discriminate H. Qed.

Lemma refa379_not2449 : ~ @Equation2449 Fin4 refa379_inst.
Proof. unfold Equation2449. intro H. specialize (H F4_2 F4_3). unfold magma_op, refa379_inst, refa379_op in H. discriminate H. Qed.

Lemma refa379_not3315 : ~ @Equation3315 Fin4 refa379_inst.
Proof. unfold Equation3315. intro H. specialize (H F4_0 F4_2). unfold magma_op, refa379_inst, refa379_op in H. discriminate H. Qed.

Lemma refa379_not3316 : ~ @Equation3316 Fin4 refa379_inst.
Proof. unfold Equation3316. intro H. specialize (H F4_0 F4_3). unfold magma_op, refa379_inst, refa379_op in H. discriminate H. Qed.

Lemma refa379_not3459 : ~ @Equation3459 Fin4 refa379_inst.
Proof. unfold Equation3459. intro H. specialize (H F4_2 F4_3). unfold magma_op, refa379_inst, refa379_op in H. discriminate H. Qed.

Lemma refa379_not3518 : ~ @Equation3518 Fin4 refa379_inst.
Proof. unfold Equation3518. intro H. specialize (H F4_0 F4_2). unfold magma_op, refa379_inst, refa379_op in H. discriminate H. Qed.

Lemma refa379_not3519 : ~ @Equation3519 Fin4 refa379_inst.
Proof. unfold Equation3519. intro H. specialize (H F4_0 F4_2). unfold magma_op, refa379_inst, refa379_op in H. discriminate H. Qed.

Lemma refa379_not3521 : ~ @Equation3521 Fin4 refa379_inst.
Proof. unfold Equation3521. intro H. specialize (H F4_0 F4_2). unfold magma_op, refa379_inst, refa379_op in H. discriminate H. Qed.

Lemma refa379_not3714 : ~ @Equation3714 Fin4 refa379_inst.
Proof. unfold Equation3714. intro H. specialize (H F4_0 F4_2). unfold magma_op, refa379_inst, refa379_op in H. discriminate H. Qed.

Lemma refa379_not3721 : ~ @Equation3721 Fin4 refa379_inst.
Proof. unfold Equation3721. intro H. specialize (H F4_3 F4_0). unfold magma_op, refa379_inst, refa379_op in H. discriminate H. Qed.

Lemma refa379_not3724 : ~ @Equation3724 Fin4 refa379_inst.
Proof. unfold Equation3724. intro H. specialize (H F4_0 F4_3). unfold magma_op, refa379_inst, refa379_op in H. discriminate H. Qed.

Lemma refa379_not3725 : ~ @Equation3725 Fin4 refa379_inst.
Proof. unfold Equation3725. intro H. specialize (H F4_2 F4_3). unfold magma_op, refa379_inst, refa379_op in H. discriminate H. Qed.

Lemma refa379_not3924 : ~ @Equation3924 Fin4 refa379_inst.
Proof. unfold Equation3924. intro H. specialize (H F4_0 F4_2). unfold magma_op, refa379_inst, refa379_op in H. discriminate H. Qed.

Lemma refa379_not3925 : ~ @Equation3925 Fin4 refa379_inst.
Proof. unfold Equation3925. intro H. specialize (H F4_2 F4_3). unfold magma_op, refa379_inst, refa379_op in H. discriminate H. Qed.

Lemma refa379_not3927 : ~ @Equation3927 Fin4 refa379_inst.
Proof. unfold Equation3927. intro H. specialize (H F4_3 F4_0). unfold magma_op, refa379_inst, refa379_op in H. discriminate H. Qed.

Lemma refa379_not3928 : ~ @Equation3928 Fin4 refa379_inst.
Proof. unfold Equation3928. intro H. specialize (H F4_2 F4_3). unfold magma_op, refa379_inst, refa379_op in H. discriminate H. Qed.

Lemma refa379_not4120 : ~ @Equation4120 Fin4 refa379_inst.
Proof. unfold Equation4120. intro H. specialize (H F4_3 F4_0). unfold magma_op, refa379_inst, refa379_op in H. discriminate H. Qed.

Lemma refa379_not4121 : ~ @Equation4121 Fin4 refa379_inst.
Proof. unfold Equation4121. intro H. specialize (H F4_2 F4_3). unfold magma_op, refa379_inst, refa379_op in H. discriminate H. Qed.

Lemma refa379_not4127 : ~ @Equation4127 Fin4 refa379_inst.
Proof. unfold Equation4127. intro H. specialize (H F4_3 F4_0). unfold magma_op, refa379_inst, refa379_op in H. discriminate H. Qed.

Lemma refa379_not4128 : ~ @Equation4128 Fin4 refa379_inst.
Proof. unfold Equation4128. intro H. specialize (H F4_2 F4_3). unfold magma_op, refa379_inst, refa379_op in H. discriminate H. Qed.

Lemma refa379_not4130 : ~ @Equation4130 Fin4 refa379_inst.
Proof. unfold Equation4130. intro H. specialize (H F4_3 F4_0). unfold magma_op, refa379_inst, refa379_op in H. discriminate H. Qed.

Lemma refa379_not4131 : ~ @Equation4131 Fin4 refa379_inst.
Proof. unfold Equation4131. intro H. specialize (H F4_2 F4_3). unfold magma_op, refa379_inst, refa379_op in H. discriminate H. Qed.

Lemma refa379_not4314 : ~ @Equation4314 Fin4 refa379_inst.
Proof. unfold Equation4314. intro H. specialize (H F4_0 F4_2). unfold magma_op, refa379_inst, refa379_op in H. discriminate H. Qed.

Lemma refa379_not4433 : ~ @Equation4433 Fin4 refa379_inst.
Proof. unfold Equation4433. intro H. specialize (H F4_0 F4_2). unfold magma_op, refa379_inst, refa379_op in H. discriminate H. Qed.

Lemma refa379_not4435 : ~ @Equation4435 Fin4 refa379_inst.
Proof. unfold Equation4435. intro H. specialize (H F4_0 F4_2). unfold magma_op, refa379_inst, refa379_op in H. discriminate H. Qed.

Lemma refa379_not4436 : ~ @Equation4436 Fin4 refa379_inst.
Proof. unfold Equation4436. intro H. specialize (H F4_0 F4_2). unfold magma_op, refa379_inst, refa379_op in H. discriminate H. Qed.

Lemma refa379_not4472 : ~ @Equation4472 Fin4 refa379_inst.
Proof. unfold Equation4472. intro H. specialize (H F4_3 F4_0). unfold magma_op, refa379_inst, refa379_op in H. discriminate H. Qed.

Lemma refa379_not4473 : ~ @Equation4473 Fin4 refa379_inst.
Proof. unfold Equation4473. intro H. specialize (H F4_2 F4_3). unfold magma_op, refa379_inst, refa379_op in H. discriminate H. Qed.

Lemma refa379_not4598 : ~ @Equation4598 Fin4 refa379_inst.
Proof. unfold Equation4598. intro H. specialize (H F4_3 F4_0). unfold magma_op, refa379_inst, refa379_op in H. discriminate H. Qed.

Lemma refa379_not4599 : ~ @Equation4599 Fin4 refa379_inst.
Proof. unfold Equation4599. intro H. specialize (H F4_2 F4_3). unfold magma_op, refa379_inst, refa379_op in H. discriminate H. Qed.

Lemma refa379_not4629 : ~ @Equation4629 Fin4 refa379_inst.
Proof. unfold Equation4629. intro H. specialize (H F4_2 F4_3). unfold magma_op, refa379_inst, refa379_op in H. discriminate H. Qed.

(** ---- refa38 (Fin7) ---- *)

Definition refa38_op (x y : Fin7) : Fin7 :=
  match x, y with
  | F7_0, F7_0 => F7_1 | F7_0, F7_1 => F7_2 | F7_0, F7_2 => F7_6 | F7_0, F7_3 => F7_5 | F7_0, F7_4 => F7_3 | F7_0, F7_5 => F7_4 | F7_0, F7_6 => F7_1
  | F7_1, F7_0 => F7_6 | F7_1, F7_1 => F7_1 | F7_1, F7_2 => F7_2 | F7_1, F7_3 => F7_1 | F7_1, F7_4 => F7_1 | F7_1, F7_5 => F7_5 | F7_1, F7_6 => F7_1
  | F7_2, F7_0 => F7_3 | F7_2, F7_1 => F7_2 | F7_2, F7_2 => F7_2 | F7_2, F7_3 => F7_2 | F7_2, F7_4 => F7_6 | F7_2, F7_5 => F7_4 | F7_2, F7_6 => F7_5
  | F7_3, F7_0 => F7_4 | F7_3, F7_1 => F7_1 | F7_3, F7_2 => F7_2 | F7_3, F7_3 => F7_3 | F7_3, F7_4 => F7_3 | F7_3, F7_5 => F7_5 | F7_3, F7_6 => F7_1
  | F7_4, F7_0 => F7_5 | F7_4, F7_1 => F7_1 | F7_4, F7_2 => F7_5 | F7_4, F7_3 => F7_3 | F7_4, F7_4 => F7_4 | F7_4, F7_5 => F7_4 | F7_4, F7_6 => F7_6
  | F7_5, F7_0 => F7_3 | F7_5, F7_1 => F7_5 | F7_5, F7_2 => F7_6 | F7_5, F7_3 => F7_5 | F7_5, F7_4 => F7_4 | F7_5, F7_5 => F7_5 | F7_5, F7_6 => F7_5
  | F7_6, F7_0 => F7_2 | F7_6, F7_1 => F7_1 | F7_6, F7_2 => F7_4 | F7_6, F7_3 => F7_1 | F7_6, F7_4 => F7_6 | F7_6, F7_5 => F7_5 | F7_6, F7_6 => F7_6
  end.

#[local] Instance refa38_inst : Magma Fin7 := {| magma_op := refa38_op |}.

Lemma refa38_sat3555 : @Equation3555 Fin7 refa38_inst.
Proof. unfold Equation3555, magma_op, refa38_inst, refa38_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa38_not3862 : ~ @Equation3862 Fin7 refa38_inst.
Proof. unfold Equation3862. intro H. specialize (H F7_0). unfold magma_op, refa38_inst, refa38_op in H. discriminate H. Qed.

Lemma refa38_not4065 : ~ @Equation4065 Fin7 refa38_inst.
Proof. unfold Equation4065. intro H. specialize (H F7_0). unfold magma_op, refa38_inst, refa38_op in H. discriminate H. Qed.

Lemma refa38_not4272 : ~ @Equation4272 Fin7 refa38_inst.
Proof. unfold Equation4272. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa38_inst, refa38_op in H. discriminate H. Qed.

Lemma refa38_not4283 : ~ @Equation4283 Fin7 refa38_inst.
Proof. unfold Equation4283. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa38_inst, refa38_op in H. discriminate H. Qed.

Lemma refa38_not4284 : ~ @Equation4284 Fin7 refa38_inst.
Proof. unfold Equation4284. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa38_inst, refa38_op in H. discriminate H. Qed.

Lemma refa38_not4290 : ~ @Equation4290 Fin7 refa38_inst.
Proof. unfold Equation4290. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa38_inst, refa38_op in H. discriminate H. Qed.

Lemma refa38_not4291 : ~ @Equation4291 Fin7 refa38_inst.
Proof. unfold Equation4291. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa38_inst, refa38_op in H. discriminate H. Qed.

Lemma refa38_not4314 : ~ @Equation4314 Fin7 refa38_inst.
Proof. unfold Equation4314. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa38_inst, refa38_op in H. discriminate H. Qed.

Lemma refa38_not4320 : ~ @Equation4320 Fin7 refa38_inst.
Proof. unfold Equation4320. intro H. specialize (H F7_0 F7_2). unfold magma_op, refa38_inst, refa38_op in H. discriminate H. Qed.

Lemma refa38_not4343 : ~ @Equation4343 Fin7 refa38_inst.
Proof. unfold Equation4343. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa38_inst, refa38_op in H. discriminate H. Qed.

Lemma refa38_not4380 : ~ @Equation4380 Fin7 refa38_inst.
Proof. unfold Equation4380. intro H. specialize (H F7_0). unfold magma_op, refa38_inst, refa38_op in H. discriminate H. Qed.

Lemma refa38_not4598 : ~ @Equation4598 Fin7 refa38_inst.
Proof. unfold Equation4598. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa38_inst, refa38_op in H. discriminate H. Qed.

Lemma refa38_not4599 : ~ @Equation4599 Fin7 refa38_inst.
Proof. unfold Equation4599. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa38_inst, refa38_op in H. discriminate H. Qed.

Lemma refa38_not4605 : ~ @Equation4605 Fin7 refa38_inst.
Proof. unfold Equation4605. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa38_inst, refa38_op in H. discriminate H. Qed.

Lemma refa38_not4606 : ~ @Equation4606 Fin7 refa38_inst.
Proof. unfold Equation4606. intro H. specialize (H F7_0 F7_3). unfold magma_op, refa38_inst, refa38_op in H. discriminate H. Qed.

Lemma refa38_not4608 : ~ @Equation4608 Fin7 refa38_inst.
Proof. unfold Equation4608. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa38_inst, refa38_op in H. discriminate H. Qed.

Lemma refa38_not4629 : ~ @Equation4629 Fin7 refa38_inst.
Proof. unfold Equation4629. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa38_inst, refa38_op in H. discriminate H. Qed.

Lemma refa38_not4635 : ~ @Equation4635 Fin7 refa38_inst.
Proof. unfold Equation4635. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa38_inst, refa38_op in H. discriminate H. Qed.

Lemma refa38_not4636 : ~ @Equation4636 Fin7 refa38_inst.
Proof. unfold Equation4636. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa38_inst, refa38_op in H. discriminate H. Qed.

(** ---- refa380 (Fin4) ---- *)

Definition refa380_op (x y : Fin4) : Fin4 :=
  match x, y with
  | F4_0, F4_0 => F4_0 | F4_0, F4_1 => F4_3 | F4_0, F4_2 => F4_1 | F4_0, F4_3 => F4_1
  | F4_1, F4_0 => F4_3 | F4_1, F4_1 => F4_1 | F4_1, F4_2 => F4_2 | F4_1, F4_3 => F4_3
  | F4_2, F4_0 => F4_0 | F4_2, F4_1 => F4_3 | F4_2, F4_2 => F4_2 | F4_2, F4_3 => F4_1
  | F4_3, F4_0 => F4_0 | F4_3, F4_1 => F4_1 | F4_3, F4_2 => F4_2 | F4_3, F4_3 => F4_3
  end.

#[local] Instance refa380_inst : Magma Fin4 := {| magma_op := refa380_op |}.

Lemma refa380_sat2347 : @Equation2347 Fin4 refa380_inst.
Proof. unfold Equation2347, magma_op, refa380_inst, refa380_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa380_not2503 : ~ @Equation2503 Fin4 refa380_inst.
Proof. unfold Equation2503. intro H. specialize (H F4_0 F4_2). unfold magma_op, refa380_inst, refa380_op in H. discriminate H. Qed.

(** ---- refa381 (Fin4) ---- *)

Definition refa381_op (x y : Fin4) : Fin4 :=
  match x, y with
  | F4_0, F4_0 => F4_3 | F4_0, F4_1 => F4_3 | F4_0, F4_2 => F4_3 | F4_0, F4_3 => F4_1
  | F4_1, F4_0 => F4_3 | F4_1, F4_1 => F4_2 | F4_1, F4_2 => F4_0 | F4_1, F4_3 => F4_0
  | F4_2, F4_0 => F4_3 | F4_2, F4_1 => F4_0 | F4_2, F4_2 => F4_1 | F4_2, F4_3 => F4_0
  | F4_3, F4_0 => F4_0 | F4_3, F4_1 => F4_1 | F4_3, F4_2 => F4_2 | F4_3, F4_3 => F4_3
  end.

#[local] Instance refa381_inst : Magma Fin4 := {| magma_op := refa381_op |}.

Lemma refa381_sat2949 : @Equation2949 Fin4 refa381_inst.
Proof. unfold Equation2949, magma_op, refa381_inst, refa381_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa381_sat3152 : @Equation3152 Fin4 refa381_inst.
Proof. unfold Equation3152, magma_op, refa381_inst, refa381_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa381_not2644 : ~ @Equation2644 Fin4 refa381_inst.
Proof. unfold Equation2644. intro H. specialize (H F4_1). unfold magma_op, refa381_inst, refa381_op in H. discriminate H. Qed.

Lemma refa381_not3253 : ~ @Equation3253 Fin4 refa381_inst.
Proof. unfold Equation3253. intro H. specialize (H F4_1). unfold magma_op, refa381_inst, refa381_op in H. discriminate H. Qed.

(** ---- refa382 (Fin4) ---- *)

Definition refa382_op (x y : Fin4) : Fin4 :=
  match x, y with
  | F4_0, F4_0 => F4_0 | F4_0, F4_1 => F4_0 | F4_0, F4_2 => F4_3 | F4_0, F4_3 => F4_0
  | F4_1, F4_0 => F4_3 | F4_1, F4_1 => F4_1 | F4_1, F4_2 => F4_0 | F4_1, F4_3 => F4_1
  | F4_2, F4_0 => F4_2 | F4_2, F4_1 => F4_2 | F4_2, F4_2 => F4_2 | F4_2, F4_3 => F4_2
  | F4_3, F4_0 => F4_3 | F4_3, F4_1 => F4_0 | F4_3, F4_2 => F4_0 | F4_3, F4_3 => F4_3
  end.

#[local] Instance refa382_inst : Magma Fin4 := {| magma_op := refa382_op |}.

Lemma refa382_sat618 : @Equation618 Fin4 refa382_inst.
Proof. unfold Equation618, magma_op, refa382_inst, refa382_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa382_sat827 : @Equation827 Fin4 refa382_inst.
Proof. unfold Equation827, magma_op, refa382_inst, refa382_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa382_not50 : ~ @Equation50 Fin4 refa382_inst.
Proof. unfold Equation50. intro H. specialize (H F4_1 F4_2). unfold magma_op, refa382_inst, refa382_op in H. discriminate H. Qed.

Lemma refa382_not378 : ~ @Equation378 Fin4 refa382_inst.
Proof. unfold Equation378. intro H. specialize (H F4_0 F4_2). unfold magma_op, refa382_inst, refa382_op in H. discriminate H. Qed.

Lemma refa382_not416 : ~ @Equation416 Fin4 refa382_inst.
Proof. unfold Equation416. intro H. specialize (H F4_1 F4_2). unfold magma_op, refa382_inst, refa382_op in H. discriminate H. Qed.

Lemma refa382_not417 : ~ @Equation417 Fin4 refa382_inst.
Proof. unfold Equation417. intro H. specialize (H F4_1 F4_2). unfold magma_op, refa382_inst, refa382_op in H. discriminate H. Qed.

Lemma refa382_not419 : ~ @Equation419 Fin4 refa382_inst.
Proof. unfold Equation419. intro H. specialize (H F4_1 F4_2). unfold magma_op, refa382_inst, refa382_op in H. discriminate H. Qed.

Lemma refa382_not420 : ~ @Equation420 Fin4 refa382_inst.
Proof. unfold Equation420. intro H. specialize (H F4_1 F4_2). unfold magma_op, refa382_inst, refa382_op in H. discriminate H. Qed.

Lemma refa382_not619 : ~ @Equation619 Fin4 refa382_inst.
Proof. unfold Equation619. intro H. specialize (H F4_1 F4_2). unfold magma_op, refa382_inst, refa382_op in H. discriminate H. Qed.

Lemma refa382_not620 : ~ @Equation620 Fin4 refa382_inst.
Proof. unfold Equation620. intro H. specialize (H F4_1 F4_2). unfold magma_op, refa382_inst, refa382_op in H. discriminate H. Qed.

Lemma refa382_not622 : ~ @Equation622 Fin4 refa382_inst.
Proof. unfold Equation622. intro H. specialize (H F4_1 F4_2). unfold magma_op, refa382_inst, refa382_op in H. discriminate H. Qed.

Lemma refa382_not623 : ~ @Equation623 Fin4 refa382_inst.
Proof. unfold Equation623. intro H. specialize (H F4_1 F4_2). unfold magma_op, refa382_inst, refa382_op in H. discriminate H. Qed.

Lemma refa382_not819 : ~ @Equation819 Fin4 refa382_inst.
Proof. unfold Equation819. intro H. specialize (H F4_1 F4_2). unfold magma_op, refa382_inst, refa382_op in H. discriminate H. Qed.

Lemma refa382_not820 : ~ @Equation820 Fin4 refa382_inst.
Proof. unfold Equation820. intro H. specialize (H F4_1 F4_2). unfold magma_op, refa382_inst, refa382_op in H. discriminate H. Qed.

Lemma refa382_not822 : ~ @Equation822 Fin4 refa382_inst.
Proof. unfold Equation822. intro H. specialize (H F4_1 F4_0). unfold magma_op, refa382_inst, refa382_op in H. discriminate H. Qed.

Lemma refa382_not823 : ~ @Equation823 Fin4 refa382_inst.
Proof. unfold Equation823. intro H. specialize (H F4_1 F4_2). unfold magma_op, refa382_inst, refa382_op in H. discriminate H. Qed.

Lemma refa382_not1021 : ~ @Equation1021 Fin4 refa382_inst.
Proof. unfold Equation1021. intro H. specialize (H F4_1 F4_2). unfold magma_op, refa382_inst, refa382_op in H. discriminate H. Qed.

Lemma refa382_not1022 : ~ @Equation1022 Fin4 refa382_inst.
Proof. unfold Equation1022. intro H. specialize (H F4_1 F4_2). unfold magma_op, refa382_inst, refa382_op in H. discriminate H. Qed.

Lemma refa382_not1023 : ~ @Equation1023 Fin4 refa382_inst.
Proof. unfold Equation1023. intro H. specialize (H F4_1 F4_2). unfold magma_op, refa382_inst, refa382_op in H. discriminate H. Qed.

Lemma refa382_not1025 : ~ @Equation1025 Fin4 refa382_inst.
Proof. unfold Equation1025. intro H. specialize (H F4_1 F4_0). unfold magma_op, refa382_inst, refa382_op in H. discriminate H. Qed.

Lemma refa382_not1028 : ~ @Equation1028 Fin4 refa382_inst.
Proof. unfold Equation1028. intro H. specialize (H F4_1 F4_0). unfold magma_op, refa382_inst, refa382_op in H. discriminate H. Qed.

Lemma refa382_not1224 : ~ @Equation1224 Fin4 refa382_inst.
Proof. unfold Equation1224. intro H. specialize (H F4_1 F4_2). unfold magma_op, refa382_inst, refa382_op in H. discriminate H. Qed.

Lemma refa382_not1225 : ~ @Equation1225 Fin4 refa382_inst.
Proof. unfold Equation1225. intro H. specialize (H F4_1 F4_0). unfold magma_op, refa382_inst, refa382_op in H. discriminate H. Qed.

Lemma refa382_not1228 : ~ @Equation1228 Fin4 refa382_inst.
Proof. unfold Equation1228. intro H. specialize (H F4_1 F4_0). unfold magma_op, refa382_inst, refa382_op in H. discriminate H. Qed.

Lemma refa382_not1229 : ~ @Equation1229 Fin4 refa382_inst.
Proof. unfold Equation1229. intro H. specialize (H F4_1 F4_0). unfold magma_op, refa382_inst, refa382_op in H. discriminate H. Qed.

Lemma refa382_not1231 : ~ @Equation1231 Fin4 refa382_inst.
Proof. unfold Equation1231. intro H. specialize (H F4_1 F4_0). unfold magma_op, refa382_inst, refa382_op in H. discriminate H. Qed.

Lemma refa382_not1232 : ~ @Equation1232 Fin4 refa382_inst.
Proof. unfold Equation1232. intro H. specialize (H F4_1 F4_2). unfold magma_op, refa382_inst, refa382_op in H. discriminate H. Qed.

Lemma refa382_not1428 : ~ @Equation1428 Fin4 refa382_inst.
Proof. unfold Equation1428. intro H. specialize (H F4_1 F4_2). unfold magma_op, refa382_inst, refa382_op in H. discriminate H. Qed.

Lemma refa382_not1429 : ~ @Equation1429 Fin4 refa382_inst.
Proof. unfold Equation1429. intro H. specialize (H F4_1 F4_2). unfold magma_op, refa382_inst, refa382_op in H. discriminate H. Qed.

Lemma refa382_not1630 : ~ @Equation1630 Fin4 refa382_inst.
Proof. unfold Equation1630. intro H. specialize (H F4_1 F4_2). unfold magma_op, refa382_inst, refa382_op in H. discriminate H. Qed.

Lemma refa382_not1631 : ~ @Equation1631 Fin4 refa382_inst.
Proof. unfold Equation1631. intro H. specialize (H F4_1 F4_0). unfold magma_op, refa382_inst, refa382_op in H. discriminate H. Qed.

Lemma refa382_not1833 : ~ @Equation1833 Fin4 refa382_inst.
Proof. unfold Equation1833. intro H. specialize (H F4_1 F4_2). unfold magma_op, refa382_inst, refa382_op in H. discriminate H. Qed.

Lemma refa382_not1837 : ~ @Equation1837 Fin4 refa382_inst.
Proof. unfold Equation1837. intro H. specialize (H F4_1 F4_2). unfold magma_op, refa382_inst, refa382_op in H. discriminate H. Qed.

Lemma refa382_not1838 : ~ @Equation1838 Fin4 refa382_inst.
Proof. unfold Equation1838. intro H. specialize (H F4_1 F4_2). unfold magma_op, refa382_inst, refa382_op in H. discriminate H. Qed.

Lemma refa382_not2036 : ~ @Equation2036 Fin4 refa382_inst.
Proof. unfold Equation2036. intro H. specialize (H F4_1 F4_2). unfold magma_op, refa382_inst, refa382_op in H. discriminate H. Qed.

Lemma refa382_not2243 : ~ @Equation2243 Fin4 refa382_inst.
Proof. unfold Equation2243. intro H. specialize (H F4_1 F4_2). unfold magma_op, refa382_inst, refa382_op in H. discriminate H. Qed.

Lemma refa382_not2246 : ~ @Equation2246 Fin4 refa382_inst.
Proof. unfold Equation2246. intro H. specialize (H F4_1 F4_2). unfold magma_op, refa382_inst, refa382_op in H. discriminate H. Qed.

Lemma refa382_not2443 : ~ @Equation2443 Fin4 refa382_inst.
Proof. unfold Equation2443. intro H. specialize (H F4_1 F4_2). unfold magma_op, refa382_inst, refa382_op in H. discriminate H. Qed.

Lemma refa382_not2446 : ~ @Equation2446 Fin4 refa382_inst.
Proof. unfold Equation2446. intro H. specialize (H F4_1 F4_0). unfold magma_op, refa382_inst, refa382_op in H. discriminate H. Qed.

Lemma refa382_not2646 : ~ @Equation2646 Fin4 refa382_inst.
Proof. unfold Equation2646. intro H. specialize (H F4_1 F4_2). unfold magma_op, refa382_inst, refa382_op in H. discriminate H. Qed.

Lemma refa382_not2852 : ~ @Equation2852 Fin4 refa382_inst.
Proof. unfold Equation2852. intro H. specialize (H F4_1 F4_2). unfold magma_op, refa382_inst, refa382_op in H. discriminate H. Qed.

Lemma refa382_not3255 : ~ @Equation3255 Fin4 refa382_inst.
Proof. unfold Equation3255. intro H. specialize (H F4_1 F4_2). unfold magma_op, refa382_inst, refa382_op in H. discriminate H. Qed.

Lemma refa382_not3256 : ~ @Equation3256 Fin4 refa382_inst.
Proof. unfold Equation3256. intro H. specialize (H F4_1 F4_2). unfold magma_op, refa382_inst, refa382_op in H. discriminate H. Qed.

Lemma refa382_not3258 : ~ @Equation3258 Fin4 refa382_inst.
Proof. unfold Equation3258. intro H. specialize (H F4_0 F4_2). unfold magma_op, refa382_inst, refa382_op in H. discriminate H. Qed.

Lemma refa382_not3259 : ~ @Equation3259 Fin4 refa382_inst.
Proof. unfold Equation3259. intro H. specialize (H F4_0 F4_2). unfold magma_op, refa382_inst, refa382_op in H. discriminate H. Qed.

Lemma refa382_not3261 : ~ @Equation3261 Fin4 refa382_inst.
Proof. unfold Equation3261. intro H. specialize (H F4_0 F4_2). unfold magma_op, refa382_inst, refa382_op in H. discriminate H. Qed.

Lemma refa382_not3262 : ~ @Equation3262 Fin4 refa382_inst.
Proof. unfold Equation3262. intro H. specialize (H F4_0 F4_2). unfold magma_op, refa382_inst, refa382_op in H. discriminate H. Qed.

Lemma refa382_not3315 : ~ @Equation3315 Fin4 refa382_inst.
Proof. unfold Equation3315. intro H. specialize (H F4_1 F4_3). unfold magma_op, refa382_inst, refa382_op in H. discriminate H. Qed.

Lemma refa382_not3316 : ~ @Equation3316 Fin4 refa382_inst.
Proof. unfold Equation3316. intro H. specialize (H F4_1 F4_3). unfold magma_op, refa382_inst, refa382_op in H. discriminate H. Qed.

Lemma refa382_not3320 : ~ @Equation3320 Fin4 refa382_inst.
Proof. unfold Equation3320. intro H. specialize (H F4_3 F4_1 F4_2). unfold magma_op, refa382_inst, refa382_op in H. discriminate H. Qed.

Lemma refa382_not3457 : ~ @Equation3457 Fin4 refa382_inst.
Proof. unfold Equation3457. intro H. specialize (H F4_1 F4_2). unfold magma_op, refa382_inst, refa382_op in H. discriminate H. Qed.

Lemma refa382_not3458 : ~ @Equation3458 Fin4 refa382_inst.
Proof. unfold Equation3458. intro H. specialize (H F4_1 F4_0). unfold magma_op, refa382_inst, refa382_op in H. discriminate H. Qed.

Lemma refa382_not3518 : ~ @Equation3518 Fin4 refa382_inst.
Proof. unfold Equation3518. intro H. specialize (H F4_1 F4_3). unfold magma_op, refa382_inst, refa382_op in H. discriminate H. Qed.

Lemma refa382_not3519 : ~ @Equation3519 Fin4 refa382_inst.
Proof. unfold Equation3519. intro H. specialize (H F4_1 F4_3). unfold magma_op, refa382_inst, refa382_op in H. discriminate H. Qed.

Lemma refa382_not3521 : ~ @Equation3521 Fin4 refa382_inst.
Proof. unfold Equation3521. intro H. specialize (H F4_1 F4_3). unfold magma_op, refa382_inst, refa382_op in H. discriminate H. Qed.

Lemma refa382_not3660 : ~ @Equation3660 Fin4 refa382_inst.
Proof. unfold Equation3660. intro H. specialize (H F4_1 F4_2). unfold magma_op, refa382_inst, refa382_op in H. discriminate H. Qed.

Lemma refa382_not3714 : ~ @Equation3714 Fin4 refa382_inst.
Proof. unfold Equation3714. intro H. specialize (H F4_1 F4_3). unfold magma_op, refa382_inst, refa382_op in H. discriminate H. Qed.

Lemma refa382_not3721 : ~ @Equation3721 Fin4 refa382_inst.
Proof. unfold Equation3721. intro H. specialize (H F4_1 F4_0). unfold magma_op, refa382_inst, refa382_op in H. discriminate H. Qed.

Lemma refa382_not3724 : ~ @Equation3724 Fin4 refa382_inst.
Proof. unfold Equation3724. intro H. specialize (H F4_0 F4_2). unfold magma_op, refa382_inst, refa382_op in H. discriminate H. Qed.

Lemma refa382_not3725 : ~ @Equation3725 Fin4 refa382_inst.
Proof. unfold Equation3725. intro H. specialize (H F4_0 F4_2). unfold magma_op, refa382_inst, refa382_op in H. discriminate H. Qed.

Lemma refa382_not3864 : ~ @Equation3864 Fin4 refa382_inst.
Proof. unfold Equation3864. intro H. specialize (H F4_1 F4_2). unfold magma_op, refa382_inst, refa382_op in H. discriminate H. Qed.

Lemma refa382_not3924 : ~ @Equation3924 Fin4 refa382_inst.
Proof. unfold Equation3924. intro H. specialize (H F4_1 F4_0). unfold magma_op, refa382_inst, refa382_op in H. discriminate H. Qed.

Lemma refa382_not3925 : ~ @Equation3925 Fin4 refa382_inst.
Proof. unfold Equation3925. intro H. specialize (H F4_0 F4_2). unfold magma_op, refa382_inst, refa382_op in H. discriminate H. Qed.

Lemma refa382_not3927 : ~ @Equation3927 Fin4 refa382_inst.
Proof. unfold Equation3927. intro H. specialize (H F4_1 F4_0). unfold magma_op, refa382_inst, refa382_op in H. discriminate H. Qed.

Lemma refa382_not3928 : ~ @Equation3928 Fin4 refa382_inst.
Proof. unfold Equation3928. intro H. specialize (H F4_0 F4_2). unfold magma_op, refa382_inst, refa382_op in H. discriminate H. Qed.

Lemma refa382_not4120 : ~ @Equation4120 Fin4 refa382_inst.
Proof. unfold Equation4120. intro H. specialize (H F4_1 F4_0). unfold magma_op, refa382_inst, refa382_op in H. discriminate H. Qed.

Lemma refa382_not4121 : ~ @Equation4121 Fin4 refa382_inst.
Proof. unfold Equation4121. intro H. specialize (H F4_0 F4_2). unfold magma_op, refa382_inst, refa382_op in H. discriminate H. Qed.

Lemma refa382_not4127 : ~ @Equation4127 Fin4 refa382_inst.
Proof. unfold Equation4127. intro H. specialize (H F4_1 F4_0). unfold magma_op, refa382_inst, refa382_op in H. discriminate H. Qed.

Lemma refa382_not4128 : ~ @Equation4128 Fin4 refa382_inst.
Proof. unfold Equation4128. intro H. specialize (H F4_0 F4_2). unfold magma_op, refa382_inst, refa382_op in H. discriminate H. Qed.

Lemma refa382_not4130 : ~ @Equation4130 Fin4 refa382_inst.
Proof. unfold Equation4130. intro H. specialize (H F4_0 F4_2). unfold magma_op, refa382_inst, refa382_op in H. discriminate H. Qed.

Lemma refa382_not4270 : ~ @Equation4270 Fin4 refa382_inst.
Proof. unfold Equation4270. intro H. specialize (H F4_0 F4_2). unfold magma_op, refa382_inst, refa382_op in H. discriminate H. Qed.

Lemma refa382_not4282 : ~ @Equation4282 Fin4 refa382_inst.
Proof. unfold Equation4282. intro H. specialize (H F4_1 F4_0 F4_2). unfold magma_op, refa382_inst, refa382_op in H. discriminate H. Qed.

Lemma refa382_not4284 : ~ @Equation4284 Fin4 refa382_inst.
Proof. unfold Equation4284. intro H. specialize (H F4_0 F4_2). unfold magma_op, refa382_inst, refa382_op in H. discriminate H. Qed.

Lemma refa382_not4314 : ~ @Equation4314 Fin4 refa382_inst.
Proof. unfold Equation4314. intro H. specialize (H F4_1 F4_3). unfold magma_op, refa382_inst, refa382_op in H. discriminate H. Qed.

Lemma refa382_not4433 : ~ @Equation4433 Fin4 refa382_inst.
Proof. unfold Equation4433. intro H. specialize (H F4_1 F4_3). unfold magma_op, refa382_inst, refa382_op in H. discriminate H. Qed.

Lemma refa382_not4435 : ~ @Equation4435 Fin4 refa382_inst.
Proof. unfold Equation4435. intro H. specialize (H F4_1 F4_0). unfold magma_op, refa382_inst, refa382_op in H. discriminate H. Qed.

Lemma refa382_not4436 : ~ @Equation4436 Fin4 refa382_inst.
Proof. unfold Equation4436. intro H. specialize (H F4_0 F4_2). unfold magma_op, refa382_inst, refa382_op in H. discriminate H. Qed.

Lemma refa382_not4472 : ~ @Equation4472 Fin4 refa382_inst.
Proof. unfold Equation4472. intro H. specialize (H F4_1 F4_0). unfold magma_op, refa382_inst, refa382_op in H. discriminate H. Qed.

Lemma refa382_not4473 : ~ @Equation4473 Fin4 refa382_inst.
Proof. unfold Equation4473. intro H. specialize (H F4_0 F4_2). unfold magma_op, refa382_inst, refa382_op in H. discriminate H. Qed.

Lemma refa382_not4598 : ~ @Equation4598 Fin4 refa382_inst.
Proof. unfold Equation4598. intro H. specialize (H F4_1 F4_0). unfold magma_op, refa382_inst, refa382_op in H. discriminate H. Qed.

Lemma refa382_not4599 : ~ @Equation4599 Fin4 refa382_inst.
Proof. unfold Equation4599. intro H. specialize (H F4_0 F4_2). unfold magma_op, refa382_inst, refa382_op in H. discriminate H. Qed.

Lemma refa382_not4629 : ~ @Equation4629 Fin4 refa382_inst.
Proof. unfold Equation4629. intro H. specialize (H F4_0 F4_2). unfold magma_op, refa382_inst, refa382_op in H. discriminate H. Qed.

(** ---- refa383 (Fin4) ---- *)

Definition refa383_op (x y : Fin4) : Fin4 :=
  match x, y with
  | F4_0, F4_0 => F4_2 | F4_0, F4_1 => F4_3 | F4_0, F4_2 => F4_3 | F4_0, F4_3 => F4_3
  | F4_1, F4_0 => F4_3 | F4_1, F4_1 => F4_3 | F4_1, F4_2 => F4_2 | F4_1, F4_3 => F4_3
  | F4_2, F4_0 => F4_2 | F4_2, F4_1 => F4_3 | F4_2, F4_2 => F4_1 | F4_2, F4_3 => F4_3
  | F4_3, F4_0 => F4_0 | F4_3, F4_1 => F4_1 | F4_3, F4_2 => F4_2 | F4_3, F4_3 => F4_3
  end.

#[local] Instance refa383_inst : Magma Fin4 := {| magma_op := refa383_op |}.

Lemma refa383_sat2385 : @Equation2385 Fin4 refa383_inst.
Proof. unfold Equation2385, magma_op, refa383_inst, refa383_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa383_not2644 : ~ @Equation2644 Fin4 refa383_inst.
Proof. unfold Equation2644. intro H. specialize (H F4_0). unfold magma_op, refa383_inst, refa383_op in H. discriminate H. Qed.

Lemma refa383_not4118 : ~ @Equation4118 Fin4 refa383_inst.
Proof. unfold Equation4118. intro H. specialize (H F4_0 F4_2). unfold magma_op, refa383_inst, refa383_op in H. discriminate H. Qed.

(** ---- refa384 (Fin4) ---- *)

Definition refa384_op (x y : Fin4) : Fin4 :=
  match x, y with
  | F4_0, F4_0 => F4_3 | F4_0, F4_1 => F4_2 | F4_0, F4_2 => F4_0 | F4_0, F4_3 => F4_1
  | F4_1, F4_0 => F4_1 | F4_1, F4_1 => F4_2 | F4_1, F4_2 => F4_1 | F4_1, F4_3 => F4_1
  | F4_2, F4_0 => F4_2 | F4_2, F4_1 => F4_2 | F4_2, F4_2 => F4_2 | F4_2, F4_3 => F4_2
  | F4_3, F4_0 => F4_2 | F4_3, F4_1 => F4_0 | F4_3, F4_2 => F4_3 | F4_3, F4_3 => F4_3
  end.

#[local] Instance refa384_inst : Magma Fin4 := {| magma_op := refa384_op |}.

Lemma refa384_sat437 : @Equation437 Fin4 refa384_inst.
Proof. unfold Equation437, magma_op, refa384_inst, refa384_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa384_not440 : ~ @Equation440 Fin4 refa384_inst.
Proof. unfold Equation440. intro H. specialize (H F4_0 F4_3). unfold magma_op, refa384_inst, refa384_op in H. discriminate H. Qed.

Lemma refa384_not817 : ~ @Equation817 Fin4 refa384_inst.
Proof. unfold Equation817. intro H. specialize (H F4_0). unfold magma_op, refa384_inst, refa384_op in H. discriminate H. Qed.

Lemma refa384_not1023 : ~ @Equation1023 Fin4 refa384_inst.
Proof. unfold Equation1023. intro H. specialize (H F4_0 F4_0). unfold magma_op, refa384_inst, refa384_op in H. discriminate H. Qed.

Lemma refa384_not1036 : ~ @Equation1036 Fin4 refa384_inst.
Proof. unfold Equation1036. intro H. specialize (H F4_0 F4_0). unfold magma_op, refa384_inst, refa384_op in H. discriminate H. Qed.

Lemma refa384_not1039 : ~ @Equation1039 Fin4 refa384_inst.
Proof. unfold Equation1039. intro H. specialize (H F4_0 F4_0). unfold magma_op, refa384_inst, refa384_op in H. discriminate H. Qed.

Lemma refa384_not1049 : ~ @Equation1049 Fin4 refa384_inst.
Proof. unfold Equation1049. intro H. specialize (H F4_0 F4_0). unfold magma_op, refa384_inst, refa384_op in H. discriminate H. Qed.

Lemma refa384_not1239 : ~ @Equation1239 Fin4 refa384_inst.
Proof. unfold Equation1239. intro H. specialize (H F4_3 F4_0). unfold magma_op, refa384_inst, refa384_op in H. discriminate H. Qed.

Lemma refa384_not1252 : ~ @Equation1252 Fin4 refa384_inst.
Proof. unfold Equation1252. intro H. specialize (H F4_0 F4_3). unfold magma_op, refa384_inst, refa384_op in H. discriminate H. Qed.

Lemma refa384_not1861 : ~ @Equation1861 Fin4 refa384_inst.
Proof. unfold Equation1861. intro H. specialize (H F4_0 F4_0). unfold magma_op, refa384_inst, refa384_op in H. discriminate H. Qed.

Lemma refa384_not3256 : ~ @Equation3256 Fin4 refa384_inst.
Proof. unfold Equation3256. intro H. specialize (H F4_0 F4_0). unfold magma_op, refa384_inst, refa384_op in H. discriminate H. Qed.

Lemma refa384_not3315 : ~ @Equation3315 Fin4 refa384_inst.
Proof. unfold Equation3315. intro H. specialize (H F4_0 F4_0). unfold magma_op, refa384_inst, refa384_op in H. discriminate H. Qed.

Lemma refa384_not3665 : ~ @Equation3665 Fin4 refa384_inst.
Proof. unfold Equation3665. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa384_inst, refa384_op in H. discriminate H. Qed.

Lemma refa384_not3677 : ~ @Equation3677 Fin4 refa384_inst.
Proof. unfold Equation3677. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa384_inst, refa384_op in H. discriminate H. Qed.

Lemma refa384_not3684 : ~ @Equation3684 Fin4 refa384_inst.
Proof. unfold Equation3684. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa384_inst, refa384_op in H. discriminate H. Qed.

Lemma refa384_not3721 : ~ @Equation3721 Fin4 refa384_inst.
Proof. unfold Equation3721. intro H. specialize (H F4_0 F4_2). unfold magma_op, refa384_inst, refa384_op in H. discriminate H. Qed.

Lemma refa384_not3862 : ~ @Equation3862 Fin4 refa384_inst.
Proof. unfold Equation3862. intro H. specialize (H F4_0). unfold magma_op, refa384_inst, refa384_op in H. discriminate H. Qed.

Lemma refa384_not4068 : ~ @Equation4068 Fin4 refa384_inst.
Proof. unfold Equation4068. intro H. specialize (H F4_0 F4_0). unfold magma_op, refa384_inst, refa384_op in H. discriminate H. Qed.

Lemma refa384_not4081 : ~ @Equation4081 Fin4 refa384_inst.
Proof. unfold Equation4081. intro H. specialize (H F4_0 F4_0). unfold magma_op, refa384_inst, refa384_op in H. discriminate H. Qed.

Lemma refa384_not4270 : ~ @Equation4270 Fin4 refa384_inst.
Proof. unfold Equation4270. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa384_inst, refa384_op in H. discriminate H. Qed.

(** ---- refa385 (Fin4) ---- *)

Definition refa385_op (x y : Fin4) : Fin4 :=
  match x, y with
  | F4_0, F4_0 => F4_3 | F4_0, F4_1 => F4_2 | F4_0, F4_2 => F4_3 | F4_0, F4_3 => F4_3
  | F4_1, F4_0 => F4_1 | F4_1, F4_1 => F4_1 | F4_1, F4_2 => F4_1 | F4_1, F4_3 => F4_1
  | F4_2, F4_0 => F4_2 | F4_2, F4_1 => F4_2 | F4_2, F4_2 => F4_2 | F4_2, F4_3 => F4_2
  | F4_3, F4_0 => F4_3 | F4_3, F4_1 => F4_3 | F4_3, F4_2 => F4_3 | F4_3, F4_3 => F4_3
  end.

#[local] Instance refa385_inst : Magma Fin4 := {| magma_op := refa385_op |}.

Lemma refa385_sat3933 : @Equation3933 Fin4 refa385_inst.
Proof. unfold Equation3933, magma_op, refa385_inst, refa385_op. intros x y z w. destruct x, y, z, w; reflexivity. Qed.

Lemma refa385_not3258 : ~ @Equation3258 Fin4 refa385_inst.
Proof. unfold Equation3258. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa385_inst, refa385_op in H. discriminate H. Qed.

Lemma refa385_not3259 : ~ @Equation3259 Fin4 refa385_inst.
Proof. unfold Equation3259. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa385_inst, refa385_op in H. discriminate H. Qed.

Lemma refa385_not3261 : ~ @Equation3261 Fin4 refa385_inst.
Proof. unfold Equation3261. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa385_inst, refa385_op in H. discriminate H. Qed.

Lemma refa385_not3262 : ~ @Equation3262 Fin4 refa385_inst.
Proof. unfold Equation3262. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa385_inst, refa385_op in H. discriminate H. Qed.

Lemma refa385_not3306 : ~ @Equation3306 Fin4 refa385_inst.
Proof. unfold Equation3306. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa385_inst, refa385_op in H. discriminate H. Qed.

Lemma refa385_not3308 : ~ @Equation3308 Fin4 refa385_inst.
Proof. unfold Equation3308. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa385_inst, refa385_op in H. discriminate H. Qed.

Lemma refa385_not3309 : ~ @Equation3309 Fin4 refa385_inst.
Proof. unfold Equation3309. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa385_inst, refa385_op in H. discriminate H. Qed.

Lemma refa385_not3461 : ~ @Equation3461 Fin4 refa385_inst.
Proof. unfold Equation3461. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa385_inst, refa385_op in H. discriminate H. Qed.

Lemma refa385_not3462 : ~ @Equation3462 Fin4 refa385_inst.
Proof. unfold Equation3462. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa385_inst, refa385_op in H. discriminate H. Qed.

Lemma refa385_not3464 : ~ @Equation3464 Fin4 refa385_inst.
Proof. unfold Equation3464. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa385_inst, refa385_op in H. discriminate H. Qed.

Lemma refa385_not3465 : ~ @Equation3465 Fin4 refa385_inst.
Proof. unfold Equation3465. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa385_inst, refa385_op in H. discriminate H. Qed.

Lemma refa385_not3509 : ~ @Equation3509 Fin4 refa385_inst.
Proof. unfold Equation3509. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa385_inst, refa385_op in H. discriminate H. Qed.

Lemma refa385_not3511 : ~ @Equation3511 Fin4 refa385_inst.
Proof. unfold Equation3511. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa385_inst, refa385_op in H. discriminate H. Qed.

Lemma refa385_not3512 : ~ @Equation3512 Fin4 refa385_inst.
Proof. unfold Equation3512. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa385_inst, refa385_op in H. discriminate H. Qed.

Lemma refa385_not3664 : ~ @Equation3664 Fin4 refa385_inst.
Proof. unfold Equation3664. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa385_inst, refa385_op in H. discriminate H. Qed.

Lemma refa385_not3665 : ~ @Equation3665 Fin4 refa385_inst.
Proof. unfold Equation3665. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa385_inst, refa385_op in H. discriminate H. Qed.

Lemma refa385_not3667 : ~ @Equation3667 Fin4 refa385_inst.
Proof. unfold Equation3667. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa385_inst, refa385_op in H. discriminate H. Qed.

Lemma refa385_not3668 : ~ @Equation3668 Fin4 refa385_inst.
Proof. unfold Equation3668. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa385_inst, refa385_op in H. discriminate H. Qed.

Lemma refa385_not3712 : ~ @Equation3712 Fin4 refa385_inst.
Proof. unfold Equation3712. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa385_inst, refa385_op in H. discriminate H. Qed.

Lemma refa385_not3714 : ~ @Equation3714 Fin4 refa385_inst.
Proof. unfold Equation3714. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa385_inst, refa385_op in H. discriminate H. Qed.

Lemma refa385_not3867 : ~ @Equation3867 Fin4 refa385_inst.
Proof. unfold Equation3867. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa385_inst, refa385_op in H. discriminate H. Qed.

Lemma refa385_not3868 : ~ @Equation3868 Fin4 refa385_inst.
Proof. unfold Equation3868. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa385_inst, refa385_op in H. discriminate H. Qed.

Lemma refa385_not3870 : ~ @Equation3870 Fin4 refa385_inst.
Proof. unfold Equation3870. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa385_inst, refa385_op in H. discriminate H. Qed.

Lemma refa385_not3871 : ~ @Equation3871 Fin4 refa385_inst.
Proof. unfold Equation3871. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa385_inst, refa385_op in H. discriminate H. Qed.

Lemma refa385_not3915 : ~ @Equation3915 Fin4 refa385_inst.
Proof. unfold Equation3915. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa385_inst, refa385_op in H. discriminate H. Qed.

Lemma refa385_not3917 : ~ @Equation3917 Fin4 refa385_inst.
Proof. unfold Equation3917. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa385_inst, refa385_op in H. discriminate H. Qed.

Lemma refa385_not3918 : ~ @Equation3918 Fin4 refa385_inst.
Proof. unfold Equation3918. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa385_inst, refa385_op in H. discriminate H. Qed.

Lemma refa385_not4070 : ~ @Equation4070 Fin4 refa385_inst.
Proof. unfold Equation4070. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa385_inst, refa385_op in H. discriminate H. Qed.

Lemma refa385_not4071 : ~ @Equation4071 Fin4 refa385_inst.
Proof. unfold Equation4071. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa385_inst, refa385_op in H. discriminate H. Qed.

Lemma refa385_not4073 : ~ @Equation4073 Fin4 refa385_inst.
Proof. unfold Equation4073. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa385_inst, refa385_op in H. discriminate H. Qed.

Lemma refa385_not4074 : ~ @Equation4074 Fin4 refa385_inst.
Proof. unfold Equation4074. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa385_inst, refa385_op in H. discriminate H. Qed.

Lemma refa385_not4118 : ~ @Equation4118 Fin4 refa385_inst.
Proof. unfold Equation4118. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa385_inst, refa385_op in H. discriminate H. Qed.

Lemma refa385_not4120 : ~ @Equation4120 Fin4 refa385_inst.
Proof. unfold Equation4120. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa385_inst, refa385_op in H. discriminate H. Qed.

Lemma refa385_not4121 : ~ @Equation4121 Fin4 refa385_inst.
Proof. unfold Equation4121. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa385_inst, refa385_op in H. discriminate H. Qed.

Lemma refa385_not4269 : ~ @Equation4269 Fin4 refa385_inst.
Proof. unfold Equation4269. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa385_inst, refa385_op in H. discriminate H. Qed.

Lemma refa385_not4270 : ~ @Equation4270 Fin4 refa385_inst.
Proof. unfold Equation4270. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa385_inst, refa385_op in H. discriminate H. Qed.

Lemma refa385_not4283 : ~ @Equation4283 Fin4 refa385_inst.
Proof. unfold Equation4283. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa385_inst, refa385_op in H. discriminate H. Qed.

Lemma refa385_not4284 : ~ @Equation4284 Fin4 refa385_inst.
Proof. unfold Equation4284. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa385_inst, refa385_op in H. discriminate H. Qed.

Lemma refa385_not4398 : ~ @Equation4398 Fin4 refa385_inst.
Proof. unfold Equation4398. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa385_inst, refa385_op in H. discriminate H. Qed.

Lemma refa385_not4399 : ~ @Equation4399 Fin4 refa385_inst.
Proof. unfold Equation4399. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa385_inst, refa385_op in H. discriminate H. Qed.

Lemma refa385_not4433 : ~ @Equation4433 Fin4 refa385_inst.
Proof. unfold Equation4433. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa385_inst, refa385_op in H. discriminate H. Qed.

Lemma refa385_not4470 : ~ @Equation4470 Fin4 refa385_inst.
Proof. unfold Equation4470. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa385_inst, refa385_op in H. discriminate H. Qed.

Lemma refa385_not4598 : ~ @Equation4598 Fin4 refa385_inst.
Proof. unfold Equation4598. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa385_inst, refa385_op in H. discriminate H. Qed.

Lemma refa385_not4599 : ~ @Equation4599 Fin4 refa385_inst.
Proof. unfold Equation4599. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa385_inst, refa385_op in H. discriminate H. Qed.

Lemma refa385_not4631 : ~ @Equation4631 Fin4 refa385_inst.
Proof. unfold Equation4631. intro H. specialize (H F4_0 F4_0 F4_1). unfold magma_op, refa385_inst, refa385_op in H. discriminate H. Qed.

Lemma refa385_not4656 : ~ @Equation4656 Fin4 refa385_inst.
Proof. unfold Equation4656. intro H. specialize (H F4_0 F4_0 F4_1). unfold magma_op, refa385_inst, refa385_op in H. discriminate H. Qed.

(** ---- refa386 (Fin4) ---- *)

Definition refa386_op (x y : Fin4) : Fin4 :=
  match x, y with
  | F4_0, F4_0 => F4_3 | F4_0, F4_1 => F4_0 | F4_0, F4_2 => F4_0 | F4_0, F4_3 => F4_3
  | F4_1, F4_0 => F4_1 | F4_1, F4_1 => F4_1 | F4_1, F4_2 => F4_1 | F4_1, F4_3 => F4_1
  | F4_2, F4_0 => F4_1 | F4_2, F4_1 => F4_2 | F4_2, F4_2 => F4_2 | F4_2, F4_3 => F4_2
  | F4_3, F4_0 => F4_3 | F4_3, F4_1 => F4_3 | F4_3, F4_2 => F4_3 | F4_3, F4_3 => F4_3
  end.

#[local] Instance refa386_inst : Magma Fin4 := {| magma_op := refa386_op |}.

Lemma refa386_sat3317 : @Equation3317 Fin4 refa386_inst.
Proof. unfold Equation3317, magma_op, refa386_inst, refa386_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa386_not3522 : ~ @Equation3522 Fin4 refa386_inst.
Proof. unfold Equation3522. intro H. specialize (H F4_2 F4_0). unfold magma_op, refa386_inst, refa386_op in H. discriminate H. Qed.

Lemma refa386_not3714 : ~ @Equation3714 Fin4 refa386_inst.
Proof. unfold Equation3714. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa386_inst, refa386_op in H. discriminate H. Qed.

Lemma refa386_not3721 : ~ @Equation3721 Fin4 refa386_inst.
Proof. unfold Equation3721. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa386_inst, refa386_op in H. discriminate H. Qed.

Lemma refa386_not3722 : ~ @Equation3722 Fin4 refa386_inst.
Proof. unfold Equation3722. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa386_inst, refa386_op in H. discriminate H. Qed.

Lemma refa386_not3915 : ~ @Equation3915 Fin4 refa386_inst.
Proof. unfold Equation3915. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa386_inst, refa386_op in H. discriminate H. Qed.

Lemma refa386_not3924 : ~ @Equation3924 Fin4 refa386_inst.
Proof. unfold Equation3924. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa386_inst, refa386_op in H. discriminate H. Qed.

Lemma refa386_not3927 : ~ @Equation3927 Fin4 refa386_inst.
Proof. unfold Equation3927. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa386_inst, refa386_op in H. discriminate H. Qed.

Lemma refa386_not4599 : ~ @Equation4599 Fin4 refa386_inst.
Proof. unfold Equation4599. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa386_inst, refa386_op in H. discriminate H. Qed.

Lemma refa386_not4629 : ~ @Equation4629 Fin4 refa386_inst.
Proof. unfold Equation4629. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa386_inst, refa386_op in H. discriminate H. Qed.

(** ---- refa387 (Fin4) ---- *)

Definition refa387_op (x y : Fin4) : Fin4 :=
  match x, y with
  | F4_0, F4_0 => F4_0 | F4_0, F4_1 => F4_2 | F4_0, F4_2 => F4_0 | F4_0, F4_3 => F4_1
  | F4_1, F4_0 => F4_3 | F4_1, F4_1 => F4_1 | F4_1, F4_2 => F4_0 | F4_1, F4_3 => F4_1
  | F4_2, F4_0 => F4_3 | F4_2, F4_1 => F4_1 | F4_2, F4_2 => F4_3 | F4_2, F4_3 => F4_1
  | F4_3, F4_0 => F4_0 | F4_3, F4_1 => F4_2 | F4_3, F4_2 => F4_0 | F4_3, F4_3 => F4_2
  end.

#[local] Instance refa387_inst : Magma Fin4 := {| magma_op := refa387_op |}.

Lemma refa387_sat1480 : @Equation1480 Fin4 refa387_inst.
Proof. unfold Equation1480, magma_op, refa387_inst, refa387_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa387_not1482 : ~ @Equation1482 Fin4 refa387_inst.
Proof. unfold Equation1482. intro H. specialize (H F4_0 F4_2). unfold magma_op, refa387_inst, refa387_op in H. discriminate H. Qed.

Lemma refa387_not2035 : ~ @Equation2035 Fin4 refa387_inst.
Proof. unfold Equation2035. intro H. specialize (H F4_2). unfold magma_op, refa387_inst, refa387_op in H. discriminate H. Qed.

Lemma refa387_not3457 : ~ @Equation3457 Fin4 refa387_inst.
Proof. unfold Equation3457. intro H. specialize (H F4_0 F4_3). unfold magma_op, refa387_inst, refa387_op in H. discriminate H. Qed.

Lemma refa387_not3462 : ~ @Equation3462 Fin4 refa387_inst.
Proof. unfold Equation3462. intro H. specialize (H F4_0 F4_3). unfold magma_op, refa387_inst, refa387_op in H. discriminate H. Qed.

Lemma refa387_not3511 : ~ @Equation3511 Fin4 refa387_inst.
Proof. unfold Equation3511. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa387_inst, refa387_op in H. discriminate H. Qed.

Lemma refa387_not3512 : ~ @Equation3512 Fin4 refa387_inst.
Proof. unfold Equation3512. intro H. specialize (H F4_0 F4_3). unfold magma_op, refa387_inst, refa387_op in H. discriminate H. Qed.

Lemma refa387_not3521 : ~ @Equation3521 Fin4 refa387_inst.
Proof. unfold Equation3521. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa387_inst, refa387_op in H. discriminate H. Qed.

Lemma refa387_not3522 : ~ @Equation3522 Fin4 refa387_inst.
Proof. unfold Equation3522. intro H. specialize (H F4_0 F4_3). unfold magma_op, refa387_inst, refa387_op in H. discriminate H. Qed.

Lemma refa387_not3862 : ~ @Equation3862 Fin4 refa387_inst.
Proof. unfold Equation3862. intro H. specialize (H F4_2). unfold magma_op, refa387_inst, refa387_op in H. discriminate H. Qed.

Lemma refa387_not4268 : ~ @Equation4268 Fin4 refa387_inst.
Proof. unfold Equation4268. intro H. specialize (H F4_0 F4_3). unfold magma_op, refa387_inst, refa387_op in H. discriminate H. Qed.

Lemma refa387_not4314 : ~ @Equation4314 Fin4 refa387_inst.
Proof. unfold Equation4314. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa387_inst, refa387_op in H. discriminate H. Qed.

Lemma refa387_not4606 : ~ @Equation4606 Fin4 refa387_inst.
Proof. unfold Equation4606. intro H. specialize (H F4_2 F4_3). unfold magma_op, refa387_inst, refa387_op in H. discriminate H. Qed.

(** ---- refa388 (Fin4) ---- *)

Definition refa388_op (x y : Fin4) : Fin4 :=
  match x, y with
  | F4_0, F4_0 => F4_1 | F4_0, F4_1 => F4_1 | F4_0, F4_2 => F4_3 | F4_0, F4_3 => F4_3
  | F4_1, F4_0 => F4_3 | F4_1, F4_1 => F4_2 | F4_1, F4_2 => F4_0 | F4_1, F4_3 => F4_3
  | F4_2, F4_0 => F4_0 | F4_2, F4_1 => F4_3 | F4_2, F4_2 => F4_3 | F4_2, F4_3 => F4_3
  | F4_3, F4_0 => F4_0 | F4_3, F4_1 => F4_1 | F4_3, F4_2 => F4_2 | F4_3, F4_3 => F4_3
  end.

#[local] Instance refa388_inst : Magma Fin4 := {| magma_op := refa388_op |}.

Lemma refa388_sat2736 : @Equation2736 Fin4 refa388_inst.
Proof. unfold Equation2736, magma_op, refa388_inst, refa388_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa388_not203 : ~ @Equation203 Fin4 refa388_inst.
Proof. unfold Equation203. intro H. specialize (H F4_0). unfold magma_op, refa388_inst, refa388_op in H. discriminate H. Qed.

Lemma refa388_not2238 : ~ @Equation2238 Fin4 refa388_inst.
Proof. unfold Equation2238. intro H. specialize (H F4_0). unfold magma_op, refa388_inst, refa388_op in H. discriminate H. Qed.

Lemma refa388_not2506 : ~ @Equation2506 Fin4 refa388_inst.
Proof. unfold Equation2506. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa388_inst, refa388_op in H. discriminate H. Qed.

Lemma refa388_not2662 : ~ @Equation2662 Fin4 refa388_inst.
Proof. unfold Equation2662. intro H. specialize (H F4_1 F4_2). unfold magma_op, refa388_inst, refa388_op in H. discriminate H. Qed.

Lemma refa388_not2672 : ~ @Equation2672 Fin4 refa388_inst.
Proof. unfold Equation2672. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa388_inst, refa388_op in H. discriminate H. Qed.

Lemma refa388_not2746 : ~ @Equation2746 Fin4 refa388_inst.
Proof. unfold Equation2746. intro H. specialize (H F4_1 F4_0). unfold magma_op, refa388_inst, refa388_op in H. discriminate H. Qed.

Lemma refa388_not4065 : ~ @Equation4065 Fin4 refa388_inst.
Proof. unfold Equation4065. intro H. specialize (H F4_0). unfold magma_op, refa388_inst, refa388_op in H. discriminate H. Qed.

Lemma refa388_not4320 : ~ @Equation4320 Fin4 refa388_inst.
Proof. unfold Equation4320. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa388_inst, refa388_op in H. discriminate H. Qed.

Lemma refa388_not4606 : ~ @Equation4606 Fin4 refa388_inst.
Proof. unfold Equation4606. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa388_inst, refa388_op in H. discriminate H. Qed.

(** ---- refa389 (Fin4) ---- *)

Definition refa389_op (x y : Fin4) : Fin4 :=
  match x, y with
  | F4_0, F4_0 => F4_0 | F4_0, F4_1 => F4_0 | F4_0, F4_2 => F4_3 | F4_0, F4_3 => F4_0
  | F4_1, F4_0 => F4_1 | F4_1, F4_1 => F4_1 | F4_1, F4_2 => F4_1 | F4_1, F4_3 => F4_1
  | F4_2, F4_0 => F4_2 | F4_2, F4_1 => F4_3 | F4_2, F4_2 => F4_2 | F4_2, F4_3 => F4_2
  | F4_3, F4_0 => F4_3 | F4_3, F4_1 => F4_2 | F4_3, F4_2 => F4_0 | F4_3, F4_3 => F4_3
  end.

#[local] Instance refa389_inst : Magma Fin4 := {| magma_op := refa389_op |}.

Lemma refa389_sat1032 : @Equation1032 Fin4 refa389_inst.
Proof. unfold Equation1032, magma_op, refa389_inst, refa389_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa389_sat1453 : @Equation1453 Fin4 refa389_inst.
Proof. unfold Equation1453, magma_op, refa389_inst, refa389_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa389_sat2260 : @Equation2260 Fin4 refa389_inst.
Proof. unfold Equation2260, magma_op, refa389_inst, refa389_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa389_sat2460 : @Equation2460 Fin4 refa389_inst.
Proof. unfold Equation2460, magma_op, refa389_inst, refa389_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa389_sat2650 : @Equation2650 Fin4 refa389_inst.
Proof. unfold Equation2650, magma_op, refa389_inst, refa389_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa389_sat3317 : @Equation3317 Fin4 refa389_inst.
Proof. unfold Equation3317, magma_op, refa389_inst, refa389_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa389_sat3320 : @Equation3320 Fin4 refa389_inst.
Proof. unfold Equation3320, magma_op, refa389_inst, refa389_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa389_not50 : ~ @Equation50 Fin4 refa389_inst.
Proof. unfold Equation50. intro H. specialize (H F4_3 F4_1). unfold magma_op, refa389_inst, refa389_op in H. discriminate H. Qed.

Lemma refa389_not101 : ~ @Equation101 Fin4 refa389_inst.
Proof. unfold Equation101. intro H. specialize (H F4_3 F4_1). unfold magma_op, refa389_inst, refa389_op in H. discriminate H. Qed.

Lemma refa389_not377 : ~ @Equation377 Fin4 refa389_inst.
Proof. unfold Equation377. intro H. specialize (H F4_2 F4_1). unfold magma_op, refa389_inst, refa389_op in H. discriminate H. Qed.

Lemma refa389_not378 : ~ @Equation378 Fin4 refa389_inst.
Proof. unfold Equation378. intro H. specialize (H F4_0 F4_2). unfold magma_op, refa389_inst, refa389_op in H. discriminate H. Qed.

Lemma refa389_not416 : ~ @Equation416 Fin4 refa389_inst.
Proof. unfold Equation416. intro H. specialize (H F4_3 F4_1). unfold magma_op, refa389_inst, refa389_op in H. discriminate H. Qed.

Lemma refa389_not417 : ~ @Equation417 Fin4 refa389_inst.
Proof. unfold Equation417. intro H. specialize (H F4_3 F4_1). unfold magma_op, refa389_inst, refa389_op in H. discriminate H. Qed.

Lemma refa389_not419 : ~ @Equation419 Fin4 refa389_inst.
Proof. unfold Equation419. intro H. specialize (H F4_3 F4_1). unfold magma_op, refa389_inst, refa389_op in H. discriminate H. Qed.

Lemma refa389_not420 : ~ @Equation420 Fin4 refa389_inst.
Proof. unfold Equation420. intro H. specialize (H F4_3 F4_1). unfold magma_op, refa389_inst, refa389_op in H. discriminate H. Qed.

Lemma refa389_not619 : ~ @Equation619 Fin4 refa389_inst.
Proof. unfold Equation619. intro H. specialize (H F4_3 F4_1). unfold magma_op, refa389_inst, refa389_op in H. discriminate H. Qed.

Lemma refa389_not620 : ~ @Equation620 Fin4 refa389_inst.
Proof. unfold Equation620. intro H. specialize (H F4_3 F4_1). unfold magma_op, refa389_inst, refa389_op in H. discriminate H. Qed.

Lemma refa389_not622 : ~ @Equation622 Fin4 refa389_inst.
Proof. unfold Equation622. intro H. specialize (H F4_3 F4_1). unfold magma_op, refa389_inst, refa389_op in H. discriminate H. Qed.

Lemma refa389_not623 : ~ @Equation623 Fin4 refa389_inst.
Proof. unfold Equation623. intro H. specialize (H F4_3 F4_1). unfold magma_op, refa389_inst, refa389_op in H. discriminate H. Qed.

Lemma refa389_not819 : ~ @Equation819 Fin4 refa389_inst.
Proof. unfold Equation819. intro H. specialize (H F4_3 F4_1). unfold magma_op, refa389_inst, refa389_op in H. discriminate H. Qed.

Lemma refa389_not820 : ~ @Equation820 Fin4 refa389_inst.
Proof. unfold Equation820. intro H. specialize (H F4_3 F4_1). unfold magma_op, refa389_inst, refa389_op in H. discriminate H. Qed.

Lemma refa389_not823 : ~ @Equation823 Fin4 refa389_inst.
Proof. unfold Equation823. intro H. specialize (H F4_3 F4_1). unfold magma_op, refa389_inst, refa389_op in H. discriminate H. Qed.

Lemma refa389_not1021 : ~ @Equation1021 Fin4 refa389_inst.
Proof. unfold Equation1021. intro H. specialize (H F4_3 F4_1). unfold magma_op, refa389_inst, refa389_op in H. discriminate H. Qed.

Lemma refa389_not1224 : ~ @Equation1224 Fin4 refa389_inst.
Proof. unfold Equation1224. intro H. specialize (H F4_3 F4_1). unfold magma_op, refa389_inst, refa389_op in H. discriminate H. Qed.

Lemma refa389_not1228 : ~ @Equation1228 Fin4 refa389_inst.
Proof. unfold Equation1228. intro H. specialize (H F4_3 F4_1). unfold magma_op, refa389_inst, refa389_op in H. discriminate H. Qed.

Lemma refa389_not1232 : ~ @Equation1232 Fin4 refa389_inst.
Proof. unfold Equation1232. intro H. specialize (H F4_3 F4_1). unfold magma_op, refa389_inst, refa389_op in H. discriminate H. Qed.

Lemma refa389_not1428 : ~ @Equation1428 Fin4 refa389_inst.
Proof. unfold Equation1428. intro H. specialize (H F4_3 F4_1). unfold magma_op, refa389_inst, refa389_op in H. discriminate H. Qed.

Lemma refa389_not1429 : ~ @Equation1429 Fin4 refa389_inst.
Proof. unfold Equation1429. intro H. specialize (H F4_3 F4_1). unfold magma_op, refa389_inst, refa389_op in H. discriminate H. Qed.

Lemma refa389_not1630 : ~ @Equation1630 Fin4 refa389_inst.
Proof. unfold Equation1630. intro H. specialize (H F4_3 F4_1). unfold magma_op, refa389_inst, refa389_op in H. discriminate H. Qed.

Lemma refa389_not1631 : ~ @Equation1631 Fin4 refa389_inst.
Proof. unfold Equation1631. intro H. specialize (H F4_3 F4_1). unfold magma_op, refa389_inst, refa389_op in H. discriminate H. Qed.

Lemma refa389_not1833 : ~ @Equation1833 Fin4 refa389_inst.
Proof. unfold Equation1833. intro H. specialize (H F4_3 F4_1). unfold magma_op, refa389_inst, refa389_op in H. discriminate H. Qed.

Lemma refa389_not1837 : ~ @Equation1837 Fin4 refa389_inst.
Proof. unfold Equation1837. intro H. specialize (H F4_3 F4_1). unfold magma_op, refa389_inst, refa389_op in H. discriminate H. Qed.

Lemma refa389_not2036 : ~ @Equation2036 Fin4 refa389_inst.
Proof. unfold Equation2036. intro H. specialize (H F4_3 F4_1). unfold magma_op, refa389_inst, refa389_op in H. discriminate H. Qed.

Lemma refa389_not2243 : ~ @Equation2243 Fin4 refa389_inst.
Proof. unfold Equation2243. intro H. specialize (H F4_3 F4_1). unfold magma_op, refa389_inst, refa389_op in H. discriminate H. Qed.

Lemma refa389_not2246 : ~ @Equation2246 Fin4 refa389_inst.
Proof. unfold Equation2246. intro H. specialize (H F4_3 F4_1). unfold magma_op, refa389_inst, refa389_op in H. discriminate H. Qed.

Lemma refa389_not2443 : ~ @Equation2443 Fin4 refa389_inst.
Proof. unfold Equation2443. intro H. specialize (H F4_3 F4_1). unfold magma_op, refa389_inst, refa389_op in H. discriminate H. Qed.

Lemma refa389_not2646 : ~ @Equation2646 Fin4 refa389_inst.
Proof. unfold Equation2646. intro H. specialize (H F4_3 F4_1). unfold magma_op, refa389_inst, refa389_op in H. discriminate H. Qed.

Lemma refa389_not2660 : ~ @Equation2660 Fin4 refa389_inst.
Proof. unfold Equation2660. intro H. specialize (H F4_2 F4_1). unfold magma_op, refa389_inst, refa389_op in H. discriminate H. Qed.

Lemma refa389_not2852 : ~ @Equation2852 Fin4 refa389_inst.
Proof. unfold Equation2852. intro H. specialize (H F4_3 F4_1). unfold magma_op, refa389_inst, refa389_op in H. discriminate H. Qed.

Lemma refa389_not3056 : ~ @Equation3056 Fin4 refa389_inst.
Proof. unfold Equation3056. intro H. specialize (H F4_2 F4_1). unfold magma_op, refa389_inst, refa389_op in H. discriminate H. Qed.

Lemma refa389_not3068 : ~ @Equation3068 Fin4 refa389_inst.
Proof. unfold Equation3068. intro H. specialize (H F4_2 F4_1). unfold magma_op, refa389_inst, refa389_op in H. discriminate H. Qed.

Lemma refa389_not3255 : ~ @Equation3255 Fin4 refa389_inst.
Proof. unfold Equation3255. intro H. specialize (H F4_3 F4_1). unfold magma_op, refa389_inst, refa389_op in H. discriminate H. Qed.

Lemma refa389_not3256 : ~ @Equation3256 Fin4 refa389_inst.
Proof. unfold Equation3256. intro H. specialize (H F4_3 F4_1). unfold magma_op, refa389_inst, refa389_op in H. discriminate H. Qed.

Lemma refa389_not3457 : ~ @Equation3457 Fin4 refa389_inst.
Proof. unfold Equation3457. intro H. specialize (H F4_3 F4_1). unfold magma_op, refa389_inst, refa389_op in H. discriminate H. Qed.

Lemma refa389_not3458 : ~ @Equation3458 Fin4 refa389_inst.
Proof. unfold Equation3458. intro H. specialize (H F4_3 F4_1). unfold magma_op, refa389_inst, refa389_op in H. discriminate H. Qed.

Lemma refa389_not3660 : ~ @Equation3660 Fin4 refa389_inst.
Proof. unfold Equation3660. intro H. specialize (H F4_3 F4_1). unfold magma_op, refa389_inst, refa389_op in H. discriminate H. Qed.

Lemma refa389_not3724 : ~ @Equation3724 Fin4 refa389_inst.
Proof. unfold Equation3724. intro H. specialize (H F4_0 F4_2). unfold magma_op, refa389_inst, refa389_op in H. discriminate H. Qed.

Lemma refa389_not3725 : ~ @Equation3725 Fin4 refa389_inst.
Proof. unfold Equation3725. intro H. specialize (H F4_0 F4_2). unfold magma_op, refa389_inst, refa389_op in H. discriminate H. Qed.

Lemma refa389_not3864 : ~ @Equation3864 Fin4 refa389_inst.
Proof. unfold Equation3864. intro H. specialize (H F4_3 F4_1). unfold magma_op, refa389_inst, refa389_op in H. discriminate H. Qed.

Lemma refa389_not3918 : ~ @Equation3918 Fin4 refa389_inst.
Proof. unfold Equation3918. intro H. specialize (H F4_3 F4_1). unfold magma_op, refa389_inst, refa389_op in H. discriminate H. Qed.

Lemma refa389_not3925 : ~ @Equation3925 Fin4 refa389_inst.
Proof. unfold Equation3925. intro H. specialize (H F4_0 F4_2). unfold magma_op, refa389_inst, refa389_op in H. discriminate H. Qed.

Lemma refa389_not3928 : ~ @Equation3928 Fin4 refa389_inst.
Proof. unfold Equation3928. intro H. specialize (H F4_0 F4_2). unfold magma_op, refa389_inst, refa389_op in H. discriminate H. Qed.

Lemma refa389_not4268 : ~ @Equation4268 Fin4 refa389_inst.
Proof. unfold Equation4268. intro H. specialize (H F4_3 F4_1). unfold magma_op, refa389_inst, refa389_op in H. discriminate H. Qed.

Lemma refa389_not4598 : ~ @Equation4598 Fin4 refa389_inst.
Proof. unfold Equation4598. intro H. specialize (H F4_2 F4_1). unfold magma_op, refa389_inst, refa389_op in H. discriminate H. Qed.

(** ---- refa39 (Fin9) ---- *)

Definition refa39_op (x y : Fin9) : Fin9 :=
  match x, y with
  | F9_0, F9_0 => F9_2 | F9_0, F9_1 => F9_3 | F9_0, F9_2 => F9_4 | F9_0, F9_3 => F9_6 | F9_0, F9_4 => F9_2 | F9_0, F9_5 => F9_6 | F9_0, F9_6 => F9_4 | F9_0, F9_7 => F9_4 | F9_0, F9_8 => F9_2
  | F9_1, F9_0 => F9_4 | F9_1, F9_1 => F9_2 | F9_1, F9_2 => F9_4 | F9_1, F9_3 => F9_5 | F9_1, F9_4 => F9_2 | F9_1, F9_5 => F9_3 | F9_1, F9_6 => F9_0 | F9_1, F9_7 => F9_7 | F9_1, F9_8 => F9_2
  | F9_2, F9_0 => F9_8 | F9_2, F9_1 => F9_8 | F9_2, F9_2 => F9_3 | F9_2, F9_3 => F9_3 | F9_2, F9_4 => F9_3 | F9_2, F9_5 => F9_0 | F9_2, F9_6 => F9_1 | F9_2, F9_7 => F9_2 | F9_2, F9_8 => F9_5
  | F9_3, F9_0 => F9_8 | F9_3, F9_1 => F9_8 | F9_3, F9_2 => F9_2 | F9_3, F9_3 => F9_3 | F9_3, F9_4 => F9_7 | F9_3, F9_5 => F9_0 | F9_3, F9_6 => F9_1 | F9_3, F9_7 => F9_2 | F9_3, F9_8 => F9_5
  | F9_4, F9_0 => F9_8 | F9_4, F9_1 => F9_8 | F9_4, F9_2 => F9_7 | F9_4, F9_3 => F9_2 | F9_4, F9_4 => F9_3 | F9_4, F9_5 => F9_0 | F9_4, F9_6 => F9_1 | F9_4, F9_7 => F9_3 | F9_4, F9_8 => F9_5
  | F9_5, F9_0 => F9_2 | F9_5, F9_1 => F9_4 | F9_5, F9_2 => F9_4 | F9_5, F9_3 => F9_7 | F9_5, F9_4 => F9_2 | F9_5, F9_5 => F9_2 | F9_5, F9_6 => F9_3 | F9_5, F9_7 => F9_4 | F9_5, F9_8 => F9_6
  | F9_6, F9_0 => F9_3 | F9_6, F9_1 => F9_2 | F9_6, F9_2 => F9_4 | F9_6, F9_3 => F9_7 | F9_6, F9_4 => F9_2 | F9_6, F9_5 => F9_4 | F9_6, F9_6 => F9_2 | F9_6, F9_7 => F9_4 | F9_6, F9_8 => F9_4
  | F9_7, F9_0 => F9_8 | F9_7, F9_1 => F9_8 | F9_7, F9_2 => F9_3 | F9_7, F9_3 => F9_2 | F9_7, F9_4 => F9_7 | F9_7, F9_5 => F9_0 | F9_7, F9_6 => F9_1 | F9_7, F9_7 => F9_3 | F9_7, F9_8 => F9_5
  | F9_8, F9_0 => F9_1 | F9_8, F9_1 => F9_5 | F9_8, F9_2 => F9_4 | F9_8, F9_3 => F9_7 | F9_8, F9_4 => F9_2 | F9_8, F9_5 => F9_2 | F9_8, F9_6 => F9_3 | F9_8, F9_7 => F9_7 | F9_8, F9_8 => F9_2
  end.

#[local] Instance refa39_inst : Magma Fin9 := {| magma_op := refa39_op |}.

Lemma refa39_sat3475 : @Equation3475 Fin9 refa39_inst.
Proof. unfold Equation3475, magma_op, refa39_inst, refa39_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa39_not3659 : ~ @Equation3659 Fin9 refa39_inst.
Proof. unfold Equation3659. intro H. specialize (H F9_0). unfold magma_op, refa39_inst, refa39_op in H. discriminate H. Qed.

Lemma refa39_not4065 : ~ @Equation4065 Fin9 refa39_inst.
Proof. unfold Equation4065. intro H. specialize (H F9_0). unfold magma_op, refa39_inst, refa39_op in H. discriminate H. Qed.

Lemma refa39_not4269 : ~ @Equation4269 Fin9 refa39_inst.
Proof. unfold Equation4269. intro H. specialize (H F9_0 F9_1). unfold magma_op, refa39_inst, refa39_op in H. discriminate H. Qed.

Lemma refa39_not4270 : ~ @Equation4270 Fin9 refa39_inst.
Proof. unfold Equation4270. intro H. specialize (H F9_0 F9_2). unfold magma_op, refa39_inst, refa39_op in H. discriminate H. Qed.

Lemma refa39_not4272 : ~ @Equation4272 Fin9 refa39_inst.
Proof. unfold Equation4272. intro H. specialize (H F9_0 F9_2). unfold magma_op, refa39_inst, refa39_op in H. discriminate H. Qed.

Lemma refa39_not4273 : ~ @Equation4273 Fin9 refa39_inst.
Proof. unfold Equation4273. intro H. specialize (H F9_0 F9_1). unfold magma_op, refa39_inst, refa39_op in H. discriminate H. Qed.

Lemma refa39_not4314 : ~ @Equation4314 Fin9 refa39_inst.
Proof. unfold Equation4314. intro H. specialize (H F9_0 F9_1). unfold magma_op, refa39_inst, refa39_op in H. discriminate H. Qed.

Lemma refa39_not4343 : ~ @Equation4343 Fin9 refa39_inst.
Proof. unfold Equation4343. intro H. specialize (H F9_0 F9_2). unfold magma_op, refa39_inst, refa39_op in H. discriminate H. Qed.

Lemma refa39_not4606 : ~ @Equation4606 Fin9 refa39_inst.
Proof. unfold Equation4606. intro H. specialize (H F9_0 F9_2). unfold magma_op, refa39_inst, refa39_op in H. discriminate H. Qed.

Lemma refa39_not4622 : ~ @Equation4622 Fin9 refa39_inst.
Proof. unfold Equation4622. intro H. specialize (H F9_0 F9_2 F9_2). unfold magma_op, refa39_inst, refa39_op in H. discriminate H. Qed.

Lemma refa39_not4631 : ~ @Equation4631 Fin9 refa39_inst.
Proof. unfold Equation4631. intro H. specialize (H F9_0 F9_0 F9_3). unfold magma_op, refa39_inst, refa39_op in H. discriminate H. Qed.

Lemma refa39_not4658 : ~ @Equation4658 Fin9 refa39_inst.
Proof. unfold Equation4658. intro H. specialize (H F9_0 F9_2). unfold magma_op, refa39_inst, refa39_op in H. discriminate H. Qed.

(** ---- refa390 (Fin4) ---- *)

Definition refa390_op (x y : Fin4) : Fin4 :=
  match x, y with
  | F4_0, F4_0 => F4_1 | F4_0, F4_1 => F4_1 | F4_0, F4_2 => F4_1 | F4_0, F4_3 => F4_3
  | F4_1, F4_0 => F4_3 | F4_1, F4_1 => F4_3 | F4_1, F4_2 => F4_2 | F4_1, F4_3 => F4_2
  | F4_2, F4_0 => F4_0 | F4_2, F4_1 => F4_1 | F4_2, F4_2 => F4_0 | F4_2, F4_3 => F4_0
  | F4_3, F4_0 => F4_0 | F4_3, F4_1 => F4_2 | F4_3, F4_2 => F4_0 | F4_3, F4_3 => F4_2
  end.

#[local] Instance refa390_inst : Magma Fin4 := {| magma_op := refa390_op |}.

Lemma refa390_sat2649 : @Equation2649 Fin4 refa390_inst.
Proof. unfold Equation2649, magma_op, refa390_inst, refa390_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa390_not2035 : ~ @Equation2035 Fin4 refa390_inst.
Proof. unfold Equation2035. intro H. specialize (H F4_0). unfold magma_op, refa390_inst, refa390_op in H. discriminate H. Qed.

Lemma refa390_not2847 : ~ @Equation2847 Fin4 refa390_inst.
Proof. unfold Equation2847. intro H. specialize (H F4_1). unfold magma_op, refa390_inst, refa390_op in H. discriminate H. Qed.

Lemma refa390_not3253 : ~ @Equation3253 Fin4 refa390_inst.
Proof. unfold Equation3253. intro H. specialize (H F4_1). unfold magma_op, refa390_inst, refa390_op in H. discriminate H. Qed.

Lemma refa390_not3456 : ~ @Equation3456 Fin4 refa390_inst.
Proof. unfold Equation3456. intro H. specialize (H F4_0). unfold magma_op, refa390_inst, refa390_op in H. discriminate H. Qed.

(** ---- refa391 (Fin4) ---- *)

Definition refa391_op (x y : Fin4) : Fin4 :=
  match x, y with
  | F4_0, F4_0 => F4_0 | F4_0, F4_1 => F4_0 | F4_0, F4_2 => F4_2 | F4_0, F4_3 => F4_3
  | F4_1, F4_0 => F4_2 | F4_1, F4_1 => F4_2 | F4_1, F4_2 => F4_2 | F4_1, F4_3 => F4_3
  | F4_2, F4_0 => F4_0 | F4_2, F4_1 => F4_1 | F4_2, F4_2 => F4_2 | F4_2, F4_3 => F4_2
  | F4_3, F4_0 => F4_0 | F4_3, F4_1 => F4_1 | F4_3, F4_2 => F4_1 | F4_3, F4_3 => F4_0
  end.

#[local] Instance refa391_inst : Magma Fin4 := {| magma_op := refa391_op |}.

Lemma refa391_sat2739 : @Equation2739 Fin4 refa391_inst.
Proof. unfold Equation2739, magma_op, refa391_inst, refa391_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa391_not2290 : ~ @Equation2290 Fin4 refa391_inst.
Proof. unfold Equation2290. intro H. specialize (H F4_1 F4_3). unfold magma_op, refa391_inst, refa391_op in H. discriminate H. Qed.

Lemma refa391_not2300 : ~ @Equation2300 Fin4 refa391_inst.
Proof. unfold Equation2300. intro H. specialize (H F4_1 F4_3). unfold magma_op, refa391_inst, refa391_op in H. discriminate H. Qed.

Lemma refa391_not2303 : ~ @Equation2303 Fin4 refa391_inst.
Proof. unfold Equation2303. intro H. specialize (H F4_1 F4_3). unfold magma_op, refa391_inst, refa391_op in H. discriminate H. Qed.

Lemma refa391_not2327 : ~ @Equation2327 Fin4 refa391_inst.
Proof. unfold Equation2327. intro H. specialize (H F4_1 F4_3). unfold magma_op, refa391_inst, refa391_op in H. discriminate H. Qed.

Lemma refa391_not2659 : ~ @Equation2659 Fin4 refa391_inst.
Proof. unfold Equation2659. intro H. specialize (H F4_1 F4_3). unfold magma_op, refa391_inst, refa391_op in H. discriminate H. Qed.

Lemma refa391_not3464 : ~ @Equation3464 Fin4 refa391_inst.
Proof. unfold Equation3464. intro H. specialize (H F4_3 F4_1). unfold magma_op, refa391_inst, refa391_op in H. discriminate H. Qed.

(** ---- refa392 (Fin4) ---- *)

Definition refa392_op (x y : Fin4) : Fin4 :=
  match x, y with
  | F4_0, F4_0 => F4_2 | F4_0, F4_1 => F4_0 | F4_0, F4_2 => F4_0 | F4_0, F4_3 => F4_1
  | F4_1, F4_0 => F4_2 | F4_1, F4_1 => F4_2 | F4_1, F4_2 => F4_1 | F4_1, F4_3 => F4_3
  | F4_2, F4_0 => F4_2 | F4_2, F4_1 => F4_2 | F4_2, F4_2 => F4_2 | F4_2, F4_3 => F4_2
  | F4_3, F4_0 => F4_3 | F4_3, F4_1 => F4_2 | F4_3, F4_2 => F4_3 | F4_3, F4_3 => F4_2
  end.

#[local] Instance refa392_inst : Magma Fin4 := {| magma_op := refa392_op |}.

Lemma refa392_sat1068 : @Equation1068 Fin4 refa392_inst.
Proof. unfold Equation1068, magma_op, refa392_inst, refa392_op. intros x y z w. destruct x, y, z, w; reflexivity. Qed.

Lemma refa392_not1231 : ~ @Equation1231 Fin4 refa392_inst.
Proof. unfold Equation1231. intro H. specialize (H F4_0 F4_3). unfold magma_op, refa392_inst, refa392_op in H. discriminate H. Qed.

Lemma refa392_not1239 : ~ @Equation1239 Fin4 refa392_inst.
Proof. unfold Equation1239. intro H. specialize (H F4_3 F4_0). unfold magma_op, refa392_inst, refa392_op in H. discriminate H. Qed.

Lemma refa392_not3724 : ~ @Equation3724 Fin4 refa392_inst.
Proof. unfold Equation3724. intro H. specialize (H F4_0 F4_3). unfold magma_op, refa392_inst, refa392_op in H. discriminate H. Qed.

Lemma refa392_not3925 : ~ @Equation3925 Fin4 refa392_inst.
Proof. unfold Equation3925. intro H. specialize (H F4_0 F4_3). unfold magma_op, refa392_inst, refa392_op in H. discriminate H. Qed.

Lemma refa392_not4673 : ~ @Equation4673 Fin4 refa392_inst.
Proof. unfold Equation4673. intro H. specialize (H F4_0 F4_1 F4_3). unfold magma_op, refa392_inst, refa392_op in H. discriminate H. Qed.

(** ---- refa393 (Fin4) ---- *)

Definition refa393_op (x y : Fin4) : Fin4 :=
  match x, y with
  | F4_0, F4_0 => F4_3 | F4_0, F4_1 => F4_2 | F4_0, F4_2 => F4_3 | F4_0, F4_3 => F4_1
  | F4_1, F4_0 => F4_3 | F4_1, F4_1 => F4_2 | F4_1, F4_2 => F4_1 | F4_1, F4_3 => F4_3
  | F4_2, F4_0 => F4_1 | F4_2, F4_1 => F4_1 | F4_2, F4_2 => F4_3 | F4_2, F4_3 => F4_2
  | F4_3, F4_0 => F4_2 | F4_3, F4_1 => F4_3 | F4_3, F4_2 => F4_2 | F4_3, F4_3 => F4_1
  end.

#[local] Instance refa393_inst : Magma Fin4 := {| magma_op := refa393_op |}.

Lemma refa393_sat3588 : @Equation3588 Fin4 refa393_inst.
Proof. unfold Equation3588, magma_op, refa393_inst, refa393_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa393_sat3994 : @Equation3994 Fin4 refa393_inst.
Proof. unfold Equation3994, magma_op, refa393_inst, refa393_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa393_not3253 : ~ @Equation3253 Fin4 refa393_inst.
Proof. unfold Equation3253. intro H. specialize (H F4_0). unfold magma_op, refa393_inst, refa393_op in H. discriminate H. Qed.

Lemma refa393_not3462 : ~ @Equation3462 Fin4 refa393_inst.
Proof. unfold Equation3462. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa393_inst, refa393_op in H. discriminate H. Qed.

Lemma refa393_not3522 : ~ @Equation3522 Fin4 refa393_inst.
Proof. unfold Equation3522. intro H. specialize (H F4_1 F4_0). unfold magma_op, refa393_inst, refa393_op in H. discriminate H. Qed.

Lemma refa393_not3880 : ~ @Equation3880 Fin4 refa393_inst.
Proof. unfold Equation3880. intro H. specialize (H F4_0 F4_2). unfold magma_op, refa393_inst, refa393_op in H. discriminate H. Qed.

Lemma refa393_not3915 : ~ @Equation3915 Fin4 refa393_inst.
Proof. unfold Equation3915. intro H. specialize (H F4_0 F4_2). unfold magma_op, refa393_inst, refa393_op in H. discriminate H. Qed.

Lemma refa393_not4065 : ~ @Equation4065 Fin4 refa393_inst.
Proof. unfold Equation4065. intro H. specialize (H F4_0). unfold magma_op, refa393_inst, refa393_op in H. discriminate H. Qed.

Lemma refa393_not4273 : ~ @Equation4273 Fin4 refa393_inst.
Proof. unfold Equation4273. intro H. specialize (H F4_0 F4_2). unfold magma_op, refa393_inst, refa393_op in H. discriminate H. Qed.

Lemma refa393_not4380 : ~ @Equation4380 Fin4 refa393_inst.
Proof. unfold Equation4380. intro H. specialize (H F4_0). unfold magma_op, refa393_inst, refa393_op in H. discriminate H. Qed.

Lemma refa393_not4647 : ~ @Equation4647 Fin4 refa393_inst.
Proof. unfold Equation4647. intro H. specialize (H F4_0 F4_0 F4_1). unfold magma_op, refa393_inst, refa393_op in H. discriminate H. Qed.

(** ---- refa394 (Fin4) ---- *)

Definition refa394_op (x y : Fin4) : Fin4 :=
  match x, y with
  | F4_0, F4_0 => F4_2 | F4_0, F4_1 => F4_2 | F4_0, F4_2 => F4_2 | F4_0, F4_3 => F4_3
  | F4_1, F4_0 => F4_3 | F4_1, F4_1 => F4_3 | F4_1, F4_2 => F4_2 | F4_1, F4_3 => F4_3
  | F4_2, F4_0 => F4_2 | F4_2, F4_1 => F4_2 | F4_2, F4_2 => F4_2 | F4_2, F4_3 => F4_3
  | F4_3, F4_0 => F4_3 | F4_3, F4_1 => F4_3 | F4_3, F4_2 => F4_2 | F4_3, F4_3 => F4_3
  end.

#[local] Instance refa394_inst : Magma Fin4 := {| magma_op := refa394_op |}.

Lemma refa394_sat3583 : @Equation3583 Fin4 refa394_inst.
Proof. unfold Equation3583, magma_op, refa394_inst, refa394_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa394_sat3587 : @Equation3587 Fin4 refa394_inst.
Proof. unfold Equation3587, magma_op, refa394_inst, refa394_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa394_not3519 : ~ @Equation3519 Fin4 refa394_inst.
Proof. unfold Equation3519. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa394_inst, refa394_op in H. discriminate H. Qed.

Lemma refa394_not3556 : ~ @Equation3556 Fin4 refa394_inst.
Proof. unfold Equation3556. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa394_inst, refa394_op in H. discriminate H. Qed.

Lemma refa394_not3925 : ~ @Equation3925 Fin4 refa394_inst.
Proof. unfold Equation3925. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa394_inst, refa394_op in H. discriminate H. Qed.

Lemma refa394_not3962 : ~ @Equation3962 Fin4 refa394_inst.
Proof. unfold Equation3962. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa394_inst, refa394_op in H. discriminate H. Qed.

Lemma refa394_not4155 : ~ @Equation4155 Fin4 refa394_inst.
Proof. unfold Equation4155. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa394_inst, refa394_op in H. discriminate H. Qed.

Lemma refa394_not4158 : ~ @Equation4158 Fin4 refa394_inst.
Proof. unfold Equation4158. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa394_inst, refa394_op in H. discriminate H. Qed.

Lemma refa394_not4165 : ~ @Equation4165 Fin4 refa394_inst.
Proof. unfold Equation4165. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa394_inst, refa394_op in H. discriminate H. Qed.

Lemma refa394_not4406 : ~ @Equation4406 Fin4 refa394_inst.
Proof. unfold Equation4406. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa394_inst, refa394_op in H. discriminate H. Qed.

Lemma refa394_not4435 : ~ @Equation4435 Fin4 refa394_inst.
Proof. unfold Equation4435. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa394_inst, refa394_op in H. discriminate H. Qed.

Lemma refa394_not4606 : ~ @Equation4606 Fin4 refa394_inst.
Proof. unfold Equation4606. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa394_inst, refa394_op in H. discriminate H. Qed.

Lemma refa394_not4635 : ~ @Equation4635 Fin4 refa394_inst.
Proof. unfold Equation4635. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa394_inst, refa394_op in H. discriminate H. Qed.

(** ---- refa395 (Fin4) ---- *)

Definition refa395_op (x y : Fin4) : Fin4 :=
  match x, y with
  | F4_0, F4_0 => F4_1 | F4_0, F4_1 => F4_1 | F4_0, F4_2 => F4_3 | F4_0, F4_3 => F4_3
  | F4_1, F4_0 => F4_2 | F4_1, F4_1 => F4_2 | F4_1, F4_2 => F4_2 | F4_1, F4_3 => F4_3
  | F4_2, F4_0 => F4_0 | F4_2, F4_1 => F4_0 | F4_2, F4_2 => F4_0 | F4_2, F4_3 => F4_3
  | F4_3, F4_0 => F4_0 | F4_3, F4_1 => F4_1 | F4_3, F4_2 => F4_2 | F4_3, F4_3 => F4_3
  end.

#[local] Instance refa395_inst : Magma Fin4 := {| magma_op := refa395_op |}.

Lemma refa395_sat257 : @Equation257 Fin4 refa395_inst.
Proof. unfold Equation257, magma_op, refa395_inst, refa395_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa395_sat263 : @Equation263 Fin4 refa395_inst.
Proof. unfold Equation263, magma_op, refa395_inst, refa395_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa395_not2035 : ~ @Equation2035 Fin4 refa395_inst.
Proof. unfold Equation2035. intro H. specialize (H F4_1). unfold magma_op, refa395_inst, refa395_op in H. discriminate H. Qed.

Lemma refa395_not2672 : ~ @Equation2672 Fin4 refa395_inst.
Proof. unfold Equation2672. intro H. specialize (H F4_0 F4_2). unfold magma_op, refa395_inst, refa395_op in H. discriminate H. Qed.

Lemma refa395_not2862 : ~ @Equation2862 Fin4 refa395_inst.
Proof. unfold Equation2862. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa395_inst, refa395_op in H. discriminate H. Qed.

Lemma refa395_not2865 : ~ @Equation2865 Fin4 refa395_inst.
Proof. unfold Equation2865. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa395_inst, refa395_op in H. discriminate H. Qed.

Lemma refa395_not2875 : ~ @Equation2875 Fin4 refa395_inst.
Proof. unfold Equation2875. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa395_inst, refa395_op in H. discriminate H. Qed.

Lemma refa395_not3319 : ~ @Equation3319 Fin4 refa395_inst.
Proof. unfold Equation3319. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa395_inst, refa395_op in H. discriminate H. Qed.

Lemma refa395_not3456 : ~ @Equation3456 Fin4 refa395_inst.
Proof. unfold Equation3456. intro H. specialize (H F4_0). unfold magma_op, refa395_inst, refa395_op in H. discriminate H. Qed.

(** ---- refa396 (Fin4) ---- *)

Definition refa396_op (x y : Fin4) : Fin4 :=
  match x, y with
  | F4_0, F4_0 => F4_3 | F4_0, F4_1 => F4_1 | F4_0, F4_2 => F4_3 | F4_0, F4_3 => F4_3
  | F4_1, F4_0 => F4_2 | F4_1, F4_1 => F4_3 | F4_1, F4_2 => F4_2 | F4_1, F4_3 => F4_3
  | F4_2, F4_0 => F4_2 | F4_2, F4_1 => F4_1 | F4_2, F4_2 => F4_3 | F4_2, F4_3 => F4_3
  | F4_3, F4_0 => F4_0 | F4_3, F4_1 => F4_1 | F4_3, F4_2 => F4_2 | F4_3, F4_3 => F4_3
  end.

#[local] Instance refa396_inst : Magma Fin4 := {| magma_op := refa396_op |}.

Lemma refa396_sat2420 : @Equation2420 Fin4 refa396_inst.
Proof. unfold Equation2420, magma_op, refa396_inst, refa396_op. intros x y z w. destruct x, y, z, w; reflexivity. Qed.

Lemma refa396_not2530 : ~ @Equation2530 Fin4 refa396_inst.
Proof. unfold Equation2530. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa396_inst, refa396_op in H. discriminate H. Qed.

Lemma refa396_not3065 : ~ @Equation3065 Fin4 refa396_inst.
Proof. unfold Equation3065. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa396_inst, refa396_op in H. discriminate H. Qed.

Lemma refa396_not3115 : ~ @Equation3115 Fin4 refa396_inst.
Proof. unfold Equation3115. intro H. specialize (H F4_0 F4_2). unfold magma_op, refa396_inst, refa396_op in H. discriminate H. Qed.

Lemma refa396_not4070 : ~ @Equation4070 Fin4 refa396_inst.
Proof. unfold Equation4070. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa396_inst, refa396_op in H. discriminate H. Qed.

Lemma refa396_not4128 : ~ @Equation4128 Fin4 refa396_inst.
Proof. unfold Equation4128. intro H. specialize (H F4_2 F4_0). unfold magma_op, refa396_inst, refa396_op in H. discriminate H. Qed.

(** ---- refa397 (Fin4) ---- *)

Definition refa397_op (x y : Fin4) : Fin4 :=
  match x, y with
  | F4_0, F4_0 => F4_0 | F4_0, F4_1 => F4_1 | F4_0, F4_2 => F4_3 | F4_0, F4_3 => F4_3
  | F4_1, F4_0 => F4_3 | F4_1, F4_1 => F4_1 | F4_1, F4_2 => F4_0 | F4_1, F4_3 => F4_2
  | F4_2, F4_0 => F4_0 | F4_2, F4_1 => F4_1 | F4_2, F4_2 => F4_2 | F4_2, F4_3 => F4_0
  | F4_3, F4_0 => F4_0 | F4_3, F4_1 => F4_1 | F4_3, F4_2 => F4_2 | F4_3, F4_3 => F4_3
  end.

#[local] Instance refa397_inst : Magma Fin4 := {| magma_op := refa397_op |}.

Lemma refa397_sat2804 : @Equation2804 Fin4 refa397_inst.
Proof. unfold Equation2804, magma_op, refa397_inst, refa397_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa397_sat2973 : @Equation2973 Fin4 refa397_inst.
Proof. unfold Equation2973, magma_op, refa397_inst, refa397_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa397_not2456 : ~ @Equation2456 Fin4 refa397_inst.
Proof. unfold Equation2456. intro H. specialize (H F4_2 F4_1). unfold magma_op, refa397_inst, refa397_op in H. discriminate H. Qed.

(** ---- refa398 (Fin4) ---- *)

Definition refa398_op (x y : Fin4) : Fin4 :=
  match x, y with
  | F4_0, F4_0 => F4_3 | F4_0, F4_1 => F4_1 | F4_0, F4_2 => F4_3 | F4_0, F4_3 => F4_3
  | F4_1, F4_0 => F4_3 | F4_1, F4_1 => F4_3 | F4_1, F4_2 => F4_3 | F4_1, F4_3 => F4_3
  | F4_2, F4_0 => F4_2 | F4_2, F4_1 => F4_0 | F4_2, F4_2 => F4_3 | F4_2, F4_3 => F4_3
  | F4_3, F4_0 => F4_0 | F4_3, F4_1 => F4_1 | F4_3, F4_2 => F4_2 | F4_3, F4_3 => F4_3
  end.

#[local] Instance refa398_inst : Magma Fin4 := {| magma_op := refa398_op |}.

Lemma refa398_sat2420 : @Equation2420 Fin4 refa398_inst.
Proof. unfold Equation2420, magma_op, refa398_inst, refa398_op. intros x y z w. destruct x, y, z, w; reflexivity. Qed.

Lemma refa398_not2449 : ~ @Equation2449 Fin4 refa398_inst.
Proof. unfold Equation2449. intro H. specialize (H F4_2 F4_1). unfold magma_op, refa398_inst, refa398_op in H. discriminate H. Qed.

(** ---- refa399 (Fin4) ---- *)

Definition refa399_op (x y : Fin4) : Fin4 :=
  match x, y with
  | F4_0, F4_0 => F4_1 | F4_0, F4_1 => F4_2 | F4_0, F4_2 => F4_0 | F4_0, F4_3 => F4_3
  | F4_1, F4_0 => F4_3 | F4_1, F4_1 => F4_2 | F4_1, F4_2 => F4_1 | F4_1, F4_3 => F4_3
  | F4_2, F4_0 => F4_2 | F4_2, F4_1 => F4_1 | F4_2, F4_2 => F4_3 | F4_2, F4_3 => F4_2
  | F4_3, F4_0 => F4_1 | F4_3, F4_1 => F4_3 | F4_3, F4_2 => F4_2 | F4_3, F4_3 => F4_1
  end.

#[local] Instance refa399_inst : Magma Fin4 := {| magma_op := refa399_op |}.

Lemma refa399_sat1029 : @Equation1029 Fin4 refa399_inst.
Proof. unfold Equation1029, magma_op, refa399_inst, refa399_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa399_not411 : ~ @Equation411 Fin4 refa399_inst.
Proof. unfold Equation411. intro H. specialize (H F4_0). unfold magma_op, refa399_inst, refa399_op in H. discriminate H. Qed.

Lemma refa399_not614 : ~ @Equation614 Fin4 refa399_inst.
Proof. unfold Equation614. intro H. specialize (H F4_0). unfold magma_op, refa399_inst, refa399_op in H. discriminate H. Qed.

Lemma refa399_not1036 : ~ @Equation1036 Fin4 refa399_inst.
Proof. unfold Equation1036. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa399_inst, refa399_op in H. discriminate H. Qed.

Lemma refa399_not1038 : ~ @Equation1038 Fin4 refa399_inst.
Proof. unfold Equation1038. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa399_inst, refa399_op in H. discriminate H. Qed.

Lemma refa399_not1045 : ~ @Equation1045 Fin4 refa399_inst.
Proof. unfold Equation1045. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa399_inst, refa399_op in H. discriminate H. Qed.

Lemma refa399_not1223 : ~ @Equation1223 Fin4 refa399_inst.
Proof. unfold Equation1223. intro H. specialize (H F4_0). unfold magma_op, refa399_inst, refa399_op in H. discriminate H. Qed.

Lemma refa399_not1426 : ~ @Equation1426 Fin4 refa399_inst.
Proof. unfold Equation1426. intro H. specialize (H F4_0). unfold magma_op, refa399_inst, refa399_op in H. discriminate H. Qed.

Lemma refa399_not1629 : ~ @Equation1629 Fin4 refa399_inst.
Proof. unfold Equation1629. intro H. specialize (H F4_0). unfold magma_op, refa399_inst, refa399_op in H. discriminate H. Qed.

Lemma refa399_not1832 : ~ @Equation1832 Fin4 refa399_inst.
Proof. unfold Equation1832. intro H. specialize (H F4_0). unfold magma_op, refa399_inst, refa399_op in H. discriminate H. Qed.

Lemma refa399_not2035 : ~ @Equation2035 Fin4 refa399_inst.
Proof. unfold Equation2035. intro H. specialize (H F4_0). unfold magma_op, refa399_inst, refa399_op in H. discriminate H. Qed.

Lemma refa399_not2238 : ~ @Equation2238 Fin4 refa399_inst.
Proof. unfold Equation2238. intro H. specialize (H F4_0). unfold magma_op, refa399_inst, refa399_op in H. discriminate H. Qed.

Lemma refa399_not2441 : ~ @Equation2441 Fin4 refa399_inst.
Proof. unfold Equation2441. intro H. specialize (H F4_0). unfold magma_op, refa399_inst, refa399_op in H. discriminate H. Qed.

Lemma refa399_not2847 : ~ @Equation2847 Fin4 refa399_inst.
Proof. unfold Equation2847. intro H. specialize (H F4_0). unfold magma_op, refa399_inst, refa399_op in H. discriminate H. Qed.

Lemma refa399_not3050 : ~ @Equation3050 Fin4 refa399_inst.
Proof. unfold Equation3050. intro H. specialize (H F4_0). unfold magma_op, refa399_inst, refa399_op in H. discriminate H. Qed.

Lemma refa399_not3253 : ~ @Equation3253 Fin4 refa399_inst.
Proof. unfold Equation3253. intro H. specialize (H F4_0). unfold magma_op, refa399_inst, refa399_op in H. discriminate H. Qed.

Lemma refa399_not3456 : ~ @Equation3456 Fin4 refa399_inst.
Proof. unfold Equation3456. intro H. specialize (H F4_0). unfold magma_op, refa399_inst, refa399_op in H. discriminate H. Qed.

Lemma refa399_not3862 : ~ @Equation3862 Fin4 refa399_inst.
Proof. unfold Equation3862. intro H. specialize (H F4_0). unfold magma_op, refa399_inst, refa399_op in H. discriminate H. Qed.

Lemma refa399_not4073 : ~ @Equation4073 Fin4 refa399_inst.
Proof. unfold Equation4073. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa399_inst, refa399_op in H. discriminate H. Qed.

Lemma refa399_not4118 : ~ @Equation4118 Fin4 refa399_inst.
Proof. unfold Equation4118. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa399_inst, refa399_op in H. discriminate H. Qed.

Lemma refa399_not4127 : ~ @Equation4127 Fin4 refa399_inst.
Proof. unfold Equation4127. intro H. specialize (H F4_0 F4_2). unfold magma_op, refa399_inst, refa399_op in H. discriminate H. Qed.

Lemma refa399_not4283 : ~ @Equation4283 Fin4 refa399_inst.
Proof. unfold Equation4283. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa399_inst, refa399_op in H. discriminate H. Qed.

Lemma refa399_not4398 : ~ @Equation4398 Fin4 refa399_inst.
Proof. unfold Equation4398. intro H. specialize (H F4_0 F4_0). unfold magma_op, refa399_inst, refa399_op in H. discriminate H. Qed.

Lemma refa399_not4435 : ~ @Equation4435 Fin4 refa399_inst.
Proof. unfold Equation4435. intro H. specialize (H F4_0 F4_0). unfold magma_op, refa399_inst, refa399_op in H. discriminate H. Qed.

Lemma refa399_not4470 : ~ @Equation4470 Fin4 refa399_inst.
Proof. unfold Equation4470. intro H. specialize (H F4_0 F4_0). unfold magma_op, refa399_inst, refa399_op in H. discriminate H. Qed.

Lemma refa399_not4656 : ~ @Equation4656 Fin4 refa399_inst.
Proof. unfold Equation4656. intro H. specialize (H F4_0 F4_0 F4_1). unfold magma_op, refa399_inst, refa399_op in H. discriminate H. Qed.

(** ---- refa4 (Fin8) ---- *)

Definition refa4_op (x y : Fin8) : Fin8 :=
  match x, y with
  | F8_0, F8_0 => F8_0 | F8_0, F8_1 => F8_2 | F8_0, F8_2 => F8_3 | F8_0, F8_3 => F8_4 | F8_0, F8_4 => F8_5 | F8_0, F8_5 => F8_6 | F8_0, F8_6 => F8_7 | F8_0, F8_7 => F8_1
  | F8_1, F8_0 => F8_4 | F8_1, F8_1 => F8_1 | F8_1, F8_2 => F8_6 | F8_1, F8_3 => F8_0 | F8_1, F8_4 => F8_7 | F8_1, F8_5 => F8_3 | F8_1, F8_6 => F8_5 | F8_1, F8_7 => F8_2
  | F8_2, F8_0 => F8_5 | F8_2, F8_1 => F8_3 | F8_2, F8_2 => F8_2 | F8_2, F8_3 => F8_7 | F8_2, F8_4 => F8_0 | F8_2, F8_5 => F8_1 | F8_2, F8_6 => F8_4 | F8_2, F8_7 => F8_6
  | F8_3, F8_0 => F8_6 | F8_3, F8_1 => F8_7 | F8_3, F8_2 => F8_4 | F8_3, F8_3 => F8_3 | F8_3, F8_4 => F8_1 | F8_3, F8_5 => F8_0 | F8_3, F8_6 => F8_2 | F8_3, F8_7 => F8_5
  | F8_4, F8_0 => F8_7 | F8_4, F8_1 => F8_6 | F8_4, F8_2 => F8_1 | F8_4, F8_3 => F8_5 | F8_4, F8_4 => F8_4 | F8_4, F8_5 => F8_2 | F8_4, F8_6 => F8_0 | F8_4, F8_7 => F8_3
  | F8_5, F8_0 => F8_1 | F8_5, F8_1 => F8_4 | F8_5, F8_2 => F8_7 | F8_5, F8_3 => F8_2 | F8_5, F8_4 => F8_6 | F8_5, F8_5 => F8_5 | F8_5, F8_6 => F8_3 | F8_5, F8_7 => F8_0
  | F8_6, F8_0 => F8_2 | F8_6, F8_1 => F8_0 | F8_6, F8_2 => F8_5 | F8_6, F8_3 => F8_1 | F8_6, F8_4 => F8_3 | F8_6, F8_5 => F8_7 | F8_6, F8_6 => F8_6 | F8_6, F8_7 => F8_4
  | F8_7, F8_0 => F8_3 | F8_7, F8_1 => F8_5 | F8_7, F8_2 => F8_0 | F8_7, F8_3 => F8_6 | F8_7, F8_4 => F8_2 | F8_7, F8_5 => F8_4 | F8_7, F8_6 => F8_1 | F8_7, F8_7 => F8_7
  end.

#[local] Instance refa4_inst : Magma Fin8 := {| magma_op := refa4_op |}.

Lemma refa4_sat63 : @Equation63 Fin8 refa4_inst.
Proof. unfold Equation63, magma_op, refa4_inst, refa4_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa4_sat222 : @Equation222 Fin8 refa4_inst.
Proof. unfold Equation222, magma_op, refa4_inst, refa4_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa4_sat503 : @Equation503 Fin8 refa4_inst.
Proof. unfold Equation503, magma_op, refa4_inst, refa4_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa4_sat633 : @Equation633 Fin8 refa4_inst.
Proof. unfold Equation633, magma_op, refa4_inst, refa4_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa4_sat706 : @Equation706 Fin8 refa4_inst.
Proof. unfold Equation706, magma_op, refa4_inst, refa4_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa4_sat1312 : @Equation1312 Fin8 refa4_inst.
Proof. unfold Equation1312, magma_op, refa4_inst, refa4_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa4_sat1692 : @Equation1692 Fin8 refa4_inst.
Proof. unfold Equation1692, magma_op, refa4_inst, refa4_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa4_sat2497 : @Equation2497 Fin8 refa4_inst.
Proof. unfold Equation2497, magma_op, refa4_inst, refa4_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa4_sat2903 : @Equation2903 Fin8 refa4_inst.
Proof. unfold Equation2903, magma_op, refa4_inst, refa4_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa4_sat3076 : @Equation3076 Fin8 refa4_inst.
Proof. unfold Equation3076, magma_op, refa4_inst, refa4_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa4_not50 : ~ @Equation50 Fin8 refa4_inst.
Proof. unfold Equation50. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa4_inst, refa4_op in H. discriminate H. Qed.

Lemma refa4_not56 : ~ @Equation56 Fin8 refa4_inst.
Proof. unfold Equation56. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa4_inst, refa4_op in H. discriminate H. Qed.

Lemma refa4_not65 : ~ @Equation65 Fin8 refa4_inst.
Proof. unfold Equation65. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa4_inst, refa4_op in H. discriminate H. Qed.

Lemma refa4_not66 : ~ @Equation66 Fin8 refa4_inst.
Proof. unfold Equation66. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa4_inst, refa4_op in H. discriminate H. Qed.

Lemma refa4_not73 : ~ @Equation73 Fin8 refa4_inst.
Proof. unfold Equation73. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa4_inst, refa4_op in H. discriminate H. Qed.

Lemma refa4_not75 : ~ @Equation75 Fin8 refa4_inst.
Proof. unfold Equation75. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa4_inst, refa4_op in H. discriminate H. Qed.

Lemma refa4_not105 : ~ @Equation105 Fin8 refa4_inst.
Proof. unfold Equation105. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa4_inst, refa4_op in H. discriminate H. Qed.

Lemma refa4_not107 : ~ @Equation107 Fin8 refa4_inst.
Proof. unfold Equation107. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa4_inst, refa4_op in H. discriminate H. Qed.

Lemma refa4_not108 : ~ @Equation108 Fin8 refa4_inst.
Proof. unfold Equation108. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa4_inst, refa4_op in H. discriminate H. Qed.

Lemma refa4_not117 : ~ @Equation117 Fin8 refa4_inst.
Proof. unfold Equation117. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa4_inst, refa4_op in H. discriminate H. Qed.

Lemma refa4_not124 : ~ @Equation124 Fin8 refa4_inst.
Proof. unfold Equation124. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa4_inst, refa4_op in H. discriminate H. Qed.

Lemma refa4_not127 : ~ @Equation127 Fin8 refa4_inst.
Proof. unfold Equation127. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa4_inst, refa4_op in H. discriminate H. Qed.

Lemma refa4_not160 : ~ @Equation160 Fin8 refa4_inst.
Proof. unfold Equation160. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa4_inst, refa4_op in H. discriminate H. Qed.

Lemma refa4_not167 : ~ @Equation167 Fin8 refa4_inst.
Proof. unfold Equation167. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa4_inst, refa4_op in H. discriminate H. Qed.

Lemma refa4_not206 : ~ @Equation206 Fin8 refa4_inst.
Proof. unfold Equation206. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa4_inst, refa4_op in H. discriminate H. Qed.

Lemma refa4_not209 : ~ @Equation209 Fin8 refa4_inst.
Proof. unfold Equation209. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa4_inst, refa4_op in H. discriminate H. Qed.

Lemma refa4_not211 : ~ @Equation211 Fin8 refa4_inst.
Proof. unfold Equation211. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa4_inst, refa4_op in H. discriminate H. Qed.

Lemma refa4_not221 : ~ @Equation221 Fin8 refa4_inst.
Proof. unfold Equation221. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa4_inst, refa4_op in H. discriminate H. Qed.

Lemma refa4_not229 : ~ @Equation229 Fin8 refa4_inst.
Proof. unfold Equation229. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa4_inst, refa4_op in H. discriminate H. Qed.

Lemma refa4_not231 : ~ @Equation231 Fin8 refa4_inst.
Proof. unfold Equation231. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa4_inst, refa4_op in H. discriminate H. Qed.

Lemma refa4_not261 : ~ @Equation261 Fin8 refa4_inst.
Proof. unfold Equation261. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa4_inst, refa4_op in H. discriminate H. Qed.

Lemma refa4_not263 : ~ @Equation263 Fin8 refa4_inst.
Proof. unfold Equation263. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa4_inst, refa4_op in H. discriminate H. Qed.

Lemma refa4_not264 : ~ @Equation264 Fin8 refa4_inst.
Proof. unfold Equation264. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa4_inst, refa4_op in H. discriminate H. Qed.

Lemma refa4_not273 : ~ @Equation273 Fin8 refa4_inst.
Proof. unfold Equation273. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa4_inst, refa4_op in H. discriminate H. Qed.

Lemma refa4_not280 : ~ @Equation280 Fin8 refa4_inst.
Proof. unfold Equation280. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa4_inst, refa4_op in H. discriminate H. Qed.

Lemma refa4_not283 : ~ @Equation283 Fin8 refa4_inst.
Proof. unfold Equation283. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa4_inst, refa4_op in H. discriminate H. Qed.

Lemma refa4_not412 : ~ @Equation412 Fin8 refa4_inst.
Proof. unfold Equation412. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa4_inst, refa4_op in H. discriminate H. Qed.

Lemma refa4_not413 : ~ @Equation413 Fin8 refa4_inst.
Proof. unfold Equation413. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa4_inst, refa4_op in H. discriminate H. Qed.

Lemma refa4_not414 : ~ @Equation414 Fin8 refa4_inst.
Proof. unfold Equation414. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa4_inst, refa4_op in H. discriminate H. Qed.

Lemma refa4_not416 : ~ @Equation416 Fin8 refa4_inst.
Proof. unfold Equation416. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa4_inst, refa4_op in H. discriminate H. Qed.

Lemma refa4_not419 : ~ @Equation419 Fin8 refa4_inst.
Proof. unfold Equation419. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa4_inst, refa4_op in H. discriminate H. Qed.

Lemma refa4_not420 : ~ @Equation420 Fin8 refa4_inst.
Proof. unfold Equation420. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa4_inst, refa4_op in H. discriminate H. Qed.

Lemma refa4_not426 : ~ @Equation426 Fin8 refa4_inst.
Proof. unfold Equation426. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa4_inst, refa4_op in H. discriminate H. Qed.

Lemma refa4_not429 : ~ @Equation429 Fin8 refa4_inst.
Proof. unfold Equation429. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa4_inst, refa4_op in H. discriminate H. Qed.

Lemma refa4_not436 : ~ @Equation436 Fin8 refa4_inst.
Proof. unfold Equation436. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa4_inst, refa4_op in H. discriminate H. Qed.

Lemma refa4_not437 : ~ @Equation437 Fin8 refa4_inst.
Proof. unfold Equation437. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa4_inst, refa4_op in H. discriminate H. Qed.

Lemma refa4_not439 : ~ @Equation439 Fin8 refa4_inst.
Proof. unfold Equation439. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa4_inst, refa4_op in H. discriminate H. Qed.

Lemma refa4_not440 : ~ @Equation440 Fin8 refa4_inst.
Proof. unfold Equation440. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa4_inst, refa4_op in H. discriminate H. Qed.

Lemma refa4_not464 : ~ @Equation464 Fin8 refa4_inst.
Proof. unfold Equation464. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa4_inst, refa4_op in H. discriminate H. Qed.

Lemma refa4_not466 : ~ @Equation466 Fin8 refa4_inst.
Proof. unfold Equation466. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa4_inst, refa4_op in H. discriminate H. Qed.

Lemma refa4_not473 : ~ @Equation473 Fin8 refa4_inst.
Proof. unfold Equation473. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa4_inst, refa4_op in H. discriminate H. Qed.

Lemma refa4_not474 : ~ @Equation474 Fin8 refa4_inst.
Proof. unfold Equation474. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa4_inst, refa4_op in H. discriminate H. Qed.

Lemma refa4_not476 : ~ @Equation476 Fin8 refa4_inst.
Proof. unfold Equation476. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa4_inst, refa4_op in H. discriminate H. Qed.

Lemma refa4_not477 : ~ @Equation477 Fin8 refa4_inst.
Proof. unfold Equation477. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa4_inst, refa4_op in H. discriminate H. Qed.

Lemma refa4_not501 : ~ @Equation501 Fin8 refa4_inst.
Proof. unfold Equation501. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa4_inst, refa4_op in H. discriminate H. Qed.

Lemma refa4_not504 : ~ @Equation504 Fin8 refa4_inst.
Proof. unfold Equation504. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa4_inst, refa4_op in H. discriminate H. Qed.

Lemma refa4_not511 : ~ @Equation511 Fin8 refa4_inst.
Proof. unfold Equation511. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa4_inst, refa4_op in H. discriminate H. Qed.

Lemma refa4_not513 : ~ @Equation513 Fin8 refa4_inst.
Proof. unfold Equation513. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa4_inst, refa4_op in H. discriminate H. Qed.

Lemma refa4_not615 : ~ @Equation615 Fin8 refa4_inst.
Proof. unfold Equation615. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa4_inst, refa4_op in H. discriminate H. Qed.

Lemma refa4_not616 : ~ @Equation616 Fin8 refa4_inst.
Proof. unfold Equation616. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa4_inst, refa4_op in H. discriminate H. Qed.

Lemma refa4_not617 : ~ @Equation617 Fin8 refa4_inst.
Proof. unfold Equation617. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa4_inst, refa4_op in H. discriminate H. Qed.

Lemma refa4_not619 : ~ @Equation619 Fin8 refa4_inst.
Proof. unfold Equation619. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa4_inst, refa4_op in H. discriminate H. Qed.

Lemma refa4_not622 : ~ @Equation622 Fin8 refa4_inst.
Proof. unfold Equation622. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa4_inst, refa4_op in H. discriminate H. Qed.

Lemma refa4_not623 : ~ @Equation623 Fin8 refa4_inst.
Proof. unfold Equation623. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa4_inst, refa4_op in H. discriminate H. Qed.

Lemma refa4_not629 : ~ @Equation629 Fin8 refa4_inst.
Proof. unfold Equation629. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa4_inst, refa4_op in H. discriminate H. Qed.

Lemma refa4_not632 : ~ @Equation632 Fin8 refa4_inst.
Proof. unfold Equation632. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa4_inst, refa4_op in H. discriminate H. Qed.

Lemma refa4_not639 : ~ @Equation639 Fin8 refa4_inst.
Proof. unfold Equation639. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa4_inst, refa4_op in H. discriminate H. Qed.

Lemma refa4_not640 : ~ @Equation640 Fin8 refa4_inst.
Proof. unfold Equation640. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa4_inst, refa4_op in H. discriminate H. Qed.

Lemma refa4_not642 : ~ @Equation642 Fin8 refa4_inst.
Proof. unfold Equation642. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa4_inst, refa4_op in H. discriminate H. Qed.

Lemma refa4_not643 : ~ @Equation643 Fin8 refa4_inst.
Proof. unfold Equation643. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa4_inst, refa4_op in H. discriminate H. Qed.

Lemma refa4_not669 : ~ @Equation669 Fin8 refa4_inst.
Proof. unfold Equation669. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa4_inst, refa4_op in H. discriminate H. Qed.

Lemma refa4_not670 : ~ @Equation670 Fin8 refa4_inst.
Proof. unfold Equation670. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa4_inst, refa4_op in H. discriminate H. Qed.

Lemma refa4_not676 : ~ @Equation676 Fin8 refa4_inst.
Proof. unfold Equation676. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa4_inst, refa4_op in H. discriminate H. Qed.

Lemma refa4_not677 : ~ @Equation677 Fin8 refa4_inst.
Proof. unfold Equation677. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa4_inst, refa4_op in H. discriminate H. Qed.

Lemma refa4_not679 : ~ @Equation679 Fin8 refa4_inst.
Proof. unfold Equation679. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa4_inst, refa4_op in H. discriminate H. Qed.

Lemma refa4_not680 : ~ @Equation680 Fin8 refa4_inst.
Proof. unfold Equation680. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa4_inst, refa4_op in H. discriminate H. Qed.

Lemma refa4_not704 : ~ @Equation704 Fin8 refa4_inst.
Proof. unfold Equation704. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa4_inst, refa4_op in H. discriminate H. Qed.

Lemma refa4_not707 : ~ @Equation707 Fin8 refa4_inst.
Proof. unfold Equation707. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa4_inst, refa4_op in H. discriminate H. Qed.

Lemma refa4_not713 : ~ @Equation713 Fin8 refa4_inst.
Proof. unfold Equation713. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa4_inst, refa4_op in H. discriminate H. Qed.

Lemma refa4_not716 : ~ @Equation716 Fin8 refa4_inst.
Proof. unfold Equation716. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa4_inst, refa4_op in H. discriminate H. Qed.

Lemma refa4_not818 : ~ @Equation818 Fin8 refa4_inst.
Proof. unfold Equation818. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa4_inst, refa4_op in H. discriminate H. Qed.

Lemma refa4_not819 : ~ @Equation819 Fin8 refa4_inst.
Proof. unfold Equation819. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa4_inst, refa4_op in H. discriminate H. Qed.

Lemma refa4_not820 : ~ @Equation820 Fin8 refa4_inst.
Proof. unfold Equation820. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa4_inst, refa4_op in H. discriminate H. Qed.

Lemma refa4_not822 : ~ @Equation822 Fin8 refa4_inst.
Proof. unfold Equation822. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa4_inst, refa4_op in H. discriminate H. Qed.

Lemma refa4_not823 : ~ @Equation823 Fin8 refa4_inst.
Proof. unfold Equation823. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa4_inst, refa4_op in H. discriminate H. Qed.

Lemma refa4_not826 : ~ @Equation826 Fin8 refa4_inst.
Proof. unfold Equation826. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa4_inst, refa4_op in H. discriminate H. Qed.

Lemma refa4_not832 : ~ @Equation832 Fin8 refa4_inst.
Proof. unfold Equation832. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa4_inst, refa4_op in H. discriminate H. Qed.

Lemma refa4_not833 : ~ @Equation833 Fin8 refa4_inst.
Proof. unfold Equation833. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa4_inst, refa4_op in H. discriminate H. Qed.

Lemma refa4_not835 : ~ @Equation835 Fin8 refa4_inst.
Proof. unfold Equation835. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa4_inst, refa4_op in H. discriminate H. Qed.

Lemma refa4_not836 : ~ @Equation836 Fin8 refa4_inst.
Proof. unfold Equation836. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa4_inst, refa4_op in H. discriminate H. Qed.

Lemma refa4_not842 : ~ @Equation842 Fin8 refa4_inst.
Proof. unfold Equation842. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa4_inst, refa4_op in H. discriminate H. Qed.

Lemma refa4_not843 : ~ @Equation843 Fin8 refa4_inst.
Proof. unfold Equation843. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa4_inst, refa4_op in H. discriminate H. Qed.

Lemma refa4_not845 : ~ @Equation845 Fin8 refa4_inst.
Proof. unfold Equation845. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa4_inst, refa4_op in H. discriminate H. Qed.

Lemma refa4_not846 : ~ @Equation846 Fin8 refa4_inst.
Proof. unfold Equation846. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa4_inst, refa4_op in H. discriminate H. Qed.

Lemma refa4_not872 : ~ @Equation872 Fin8 refa4_inst.
Proof. unfold Equation872. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa4_inst, refa4_op in H. discriminate H. Qed.

Lemma refa4_not873 : ~ @Equation873 Fin8 refa4_inst.
Proof. unfold Equation873. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa4_inst, refa4_op in H. discriminate H. Qed.

Lemma refa4_not879 : ~ @Equation879 Fin8 refa4_inst.
Proof. unfold Equation879. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa4_inst, refa4_op in H. discriminate H. Qed.

Lemma refa4_not882 : ~ @Equation882 Fin8 refa4_inst.
Proof. unfold Equation882. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa4_inst, refa4_op in H. discriminate H. Qed.

Lemma refa4_not906 : ~ @Equation906 Fin8 refa4_inst.
Proof. unfold Equation906. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa4_inst, refa4_op in H. discriminate H. Qed.

Lemma refa4_not907 : ~ @Equation907 Fin8 refa4_inst.
Proof. unfold Equation907. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa4_inst, refa4_op in H. discriminate H. Qed.

Lemma refa4_not917 : ~ @Equation917 Fin8 refa4_inst.
Proof. unfold Equation917. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa4_inst, refa4_op in H. discriminate H. Qed.

Lemma refa4_not1021 : ~ @Equation1021 Fin8 refa4_inst.
Proof. unfold Equation1021. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa4_inst, refa4_op in H. discriminate H. Qed.

Lemma refa4_not1022 : ~ @Equation1022 Fin8 refa4_inst.
Proof. unfold Equation1022. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa4_inst, refa4_op in H. discriminate H. Qed.

Lemma refa4_not1023 : ~ @Equation1023 Fin8 refa4_inst.
Proof. unfold Equation1023. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa4_inst, refa4_op in H. discriminate H. Qed.

Lemma refa4_not1025 : ~ @Equation1025 Fin8 refa4_inst.
Proof. unfold Equation1025. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa4_inst, refa4_op in H. discriminate H. Qed.

Lemma refa4_not1026 : ~ @Equation1026 Fin8 refa4_inst.
Proof. unfold Equation1026. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa4_inst, refa4_op in H. discriminate H. Qed.

Lemma refa4_not1028 : ~ @Equation1028 Fin8 refa4_inst.
Proof. unfold Equation1028. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa4_inst, refa4_op in H. discriminate H. Qed.

Lemma refa4_not1035 : ~ @Equation1035 Fin8 refa4_inst.
Proof. unfold Equation1035. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa4_inst, refa4_op in H. discriminate H. Qed.

Lemma refa4_not1038 : ~ @Equation1038 Fin8 refa4_inst.
Proof. unfold Equation1038. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa4_inst, refa4_op in H. discriminate H. Qed.

Lemma refa4_not1045 : ~ @Equation1045 Fin8 refa4_inst.
Proof. unfold Equation1045. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa4_inst, refa4_op in H. discriminate H. Qed.

Lemma refa4_not1046 : ~ @Equation1046 Fin8 refa4_inst.
Proof. unfold Equation1046. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa4_inst, refa4_op in H. discriminate H. Qed.

Lemma refa4_not1048 : ~ @Equation1048 Fin8 refa4_inst.
Proof. unfold Equation1048. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa4_inst, refa4_op in H. discriminate H. Qed.

Lemma refa4_not1049 : ~ @Equation1049 Fin8 refa4_inst.
Proof. unfold Equation1049. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa4_inst, refa4_op in H. discriminate H. Qed.

Lemma refa4_not1075 : ~ @Equation1075 Fin8 refa4_inst.
Proof. unfold Equation1075. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa4_inst, refa4_op in H. discriminate H. Qed.

Lemma refa4_not1076 : ~ @Equation1076 Fin8 refa4_inst.
Proof. unfold Equation1076. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa4_inst, refa4_op in H. discriminate H. Qed.

Lemma refa4_not1082 : ~ @Equation1082 Fin8 refa4_inst.
Proof. unfold Equation1082. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa4_inst, refa4_op in H. discriminate H. Qed.

Lemma refa4_not1083 : ~ @Equation1083 Fin8 refa4_inst.
Proof. unfold Equation1083. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa4_inst, refa4_op in H. discriminate H. Qed.

Lemma refa4_not1085 : ~ @Equation1085 Fin8 refa4_inst.
Proof. unfold Equation1085. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa4_inst, refa4_op in H. discriminate H. Qed.

Lemma refa4_not1109 : ~ @Equation1109 Fin8 refa4_inst.
Proof. unfold Equation1109. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa4_inst, refa4_op in H. discriminate H. Qed.

Lemma refa4_not1110 : ~ @Equation1110 Fin8 refa4_inst.
Proof. unfold Equation1110. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa4_inst, refa4_op in H. discriminate H. Qed.

Lemma refa4_not1112 : ~ @Equation1112 Fin8 refa4_inst.
Proof. unfold Equation1112. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa4_inst, refa4_op in H. discriminate H. Qed.

Lemma refa4_not1113 : ~ @Equation1113 Fin8 refa4_inst.
Proof. unfold Equation1113. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa4_inst, refa4_op in H. discriminate H. Qed.

Lemma refa4_not1122 : ~ @Equation1122 Fin8 refa4_inst.
Proof. unfold Equation1122. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa4_inst, refa4_op in H. discriminate H. Qed.

Lemma refa4_not1224 : ~ @Equation1224 Fin8 refa4_inst.
Proof. unfold Equation1224. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa4_inst, refa4_op in H. discriminate H. Qed.

Lemma refa4_not1225 : ~ @Equation1225 Fin8 refa4_inst.
Proof. unfold Equation1225. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa4_inst, refa4_op in H. discriminate H. Qed.

Lemma refa4_not1226 : ~ @Equation1226 Fin8 refa4_inst.
Proof. unfold Equation1226. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa4_inst, refa4_op in H. discriminate H. Qed.

Lemma refa4_not1228 : ~ @Equation1228 Fin8 refa4_inst.
Proof. unfold Equation1228. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa4_inst, refa4_op in H. discriminate H. Qed.

Lemma refa4_not1229 : ~ @Equation1229 Fin8 refa4_inst.
Proof. unfold Equation1229. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa4_inst, refa4_op in H. discriminate H. Qed.

Lemma refa4_not1231 : ~ @Equation1231 Fin8 refa4_inst.
Proof. unfold Equation1231. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa4_inst, refa4_op in H. discriminate H. Qed.

Lemma refa4_not1232 : ~ @Equation1232 Fin8 refa4_inst.
Proof. unfold Equation1232. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa4_inst, refa4_op in H. discriminate H. Qed.

Lemma refa4_not1238 : ~ @Equation1238 Fin8 refa4_inst.
Proof. unfold Equation1238. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa4_inst, refa4_op in H. discriminate H. Qed.

Lemma refa4_not1241 : ~ @Equation1241 Fin8 refa4_inst.
Proof. unfold Equation1241. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa4_inst, refa4_op in H. discriminate H. Qed.

Lemma refa4_not1248 : ~ @Equation1248 Fin8 refa4_inst.
Proof. unfold Equation1248. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa4_inst, refa4_op in H. discriminate H. Qed.

Lemma refa4_not1251 : ~ @Equation1251 Fin8 refa4_inst.
Proof. unfold Equation1251. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa4_inst, refa4_op in H. discriminate H. Qed.

Lemma refa4_not1252 : ~ @Equation1252 Fin8 refa4_inst.
Proof. unfold Equation1252. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa4_inst, refa4_op in H. discriminate H. Qed.

Lemma refa4_not1276 : ~ @Equation1276 Fin8 refa4_inst.
Proof. unfold Equation1276. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa4_inst, refa4_op in H. discriminate H. Qed.

Lemma refa4_not1278 : ~ @Equation1278 Fin8 refa4_inst.
Proof. unfold Equation1278. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa4_inst, refa4_op in H. discriminate H. Qed.

Lemma refa4_not1285 : ~ @Equation1285 Fin8 refa4_inst.
Proof. unfold Equation1285. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa4_inst, refa4_op in H. discriminate H. Qed.

Lemma refa4_not1286 : ~ @Equation1286 Fin8 refa4_inst.
Proof. unfold Equation1286. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa4_inst, refa4_op in H. discriminate H. Qed.

Lemma refa4_not1288 : ~ @Equation1288 Fin8 refa4_inst.
Proof. unfold Equation1288. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa4_inst, refa4_op in H. discriminate H. Qed.

Lemma refa4_not1289 : ~ @Equation1289 Fin8 refa4_inst.
Proof. unfold Equation1289. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa4_inst, refa4_op in H. discriminate H. Qed.

Lemma refa4_not1313 : ~ @Equation1313 Fin8 refa4_inst.
Proof. unfold Equation1313. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa4_inst, refa4_op in H. discriminate H. Qed.

Lemma refa4_not1315 : ~ @Equation1315 Fin8 refa4_inst.
Proof. unfold Equation1315. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa4_inst, refa4_op in H. discriminate H. Qed.

Lemma refa4_not1322 : ~ @Equation1322 Fin8 refa4_inst.
Proof. unfold Equation1322. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa4_inst, refa4_op in H. discriminate H. Qed.

Lemma refa4_not1325 : ~ @Equation1325 Fin8 refa4_inst.
Proof. unfold Equation1325. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa4_inst, refa4_op in H. discriminate H. Qed.

Lemma refa4_not1427 : ~ @Equation1427 Fin8 refa4_inst.
Proof. unfold Equation1427. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa4_inst, refa4_op in H. discriminate H. Qed.

Lemma refa4_not1428 : ~ @Equation1428 Fin8 refa4_inst.
Proof. unfold Equation1428. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa4_inst, refa4_op in H. discriminate H. Qed.

Lemma refa4_not1429 : ~ @Equation1429 Fin8 refa4_inst.
Proof. unfold Equation1429. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa4_inst, refa4_op in H. discriminate H. Qed.

Lemma refa4_not1431 : ~ @Equation1431 Fin8 refa4_inst.
Proof. unfold Equation1431. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa4_inst, refa4_op in H. discriminate H. Qed.

Lemma refa4_not1434 : ~ @Equation1434 Fin8 refa4_inst.
Proof. unfold Equation1434. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa4_inst, refa4_op in H. discriminate H. Qed.

Lemma refa4_not1435 : ~ @Equation1435 Fin8 refa4_inst.
Proof. unfold Equation1435. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa4_inst, refa4_op in H. discriminate H. Qed.

Lemma refa4_not1441 : ~ @Equation1441 Fin8 refa4_inst.
Proof. unfold Equation1441. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa4_inst, refa4_op in H. discriminate H. Qed.

Lemma refa4_not1442 : ~ @Equation1442 Fin8 refa4_inst.
Proof. unfold Equation1442. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa4_inst, refa4_op in H. discriminate H. Qed.

Lemma refa4_not1444 : ~ @Equation1444 Fin8 refa4_inst.
Proof. unfold Equation1444. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa4_inst, refa4_op in H. discriminate H. Qed.

Lemma refa4_not1445 : ~ @Equation1445 Fin8 refa4_inst.
Proof. unfold Equation1445. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa4_inst, refa4_op in H. discriminate H. Qed.

Lemma refa4_not1454 : ~ @Equation1454 Fin8 refa4_inst.
Proof. unfold Equation1454. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa4_inst, refa4_op in H. discriminate H. Qed.

Lemma refa4_not1455 : ~ @Equation1455 Fin8 refa4_inst.
Proof. unfold Equation1455. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa4_inst, refa4_op in H. discriminate H. Qed.

Lemma refa4_not1478 : ~ @Equation1478 Fin8 refa4_inst.
Proof. unfold Equation1478. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa4_inst, refa4_op in H. discriminate H. Qed.

Lemma refa4_not1479 : ~ @Equation1479 Fin8 refa4_inst.
Proof. unfold Equation1479. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa4_inst, refa4_op in H. discriminate H. Qed.

Lemma refa4_not1482 : ~ @Equation1482 Fin8 refa4_inst.
Proof. unfold Equation1482. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa4_inst, refa4_op in H. discriminate H. Qed.

Lemma refa4_not1488 : ~ @Equation1488 Fin8 refa4_inst.
Proof. unfold Equation1488. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa4_inst, refa4_op in H. discriminate H. Qed.

Lemma refa4_not1491 : ~ @Equation1491 Fin8 refa4_inst.
Proof. unfold Equation1491. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa4_inst, refa4_op in H. discriminate H. Qed.

Lemma refa4_not1515 : ~ @Equation1515 Fin8 refa4_inst.
Proof. unfold Equation1515. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa4_inst, refa4_op in H. discriminate H. Qed.

Lemma refa4_not1518 : ~ @Equation1518 Fin8 refa4_inst.
Proof. unfold Equation1518. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa4_inst, refa4_op in H. discriminate H. Qed.

Lemma refa4_not1519 : ~ @Equation1519 Fin8 refa4_inst.
Proof. unfold Equation1519. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa4_inst, refa4_op in H. discriminate H. Qed.

Lemma refa4_not1525 : ~ @Equation1525 Fin8 refa4_inst.
Proof. unfold Equation1525. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa4_inst, refa4_op in H. discriminate H. Qed.

Lemma refa4_not1526 : ~ @Equation1526 Fin8 refa4_inst.
Proof. unfold Equation1526. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa4_inst, refa4_op in H. discriminate H. Qed.

Lemma refa4_not1630 : ~ @Equation1630 Fin8 refa4_inst.
Proof. unfold Equation1630. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa4_inst, refa4_op in H. discriminate H. Qed.

Lemma refa4_not1631 : ~ @Equation1631 Fin8 refa4_inst.
Proof. unfold Equation1631. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa4_inst, refa4_op in H. discriminate H. Qed.

Lemma refa4_not1632 : ~ @Equation1632 Fin8 refa4_inst.
Proof. unfold Equation1632. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa4_inst, refa4_op in H. discriminate H. Qed.

Lemma refa4_not1634 : ~ @Equation1634 Fin8 refa4_inst.
Proof. unfold Equation1634. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa4_inst, refa4_op in H. discriminate H. Qed.

Lemma refa4_not1637 : ~ @Equation1637 Fin8 refa4_inst.
Proof. unfold Equation1637. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa4_inst, refa4_op in H. discriminate H. Qed.

Lemma refa4_not1638 : ~ @Equation1638 Fin8 refa4_inst.
Proof. unfold Equation1638. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa4_inst, refa4_op in H. discriminate H. Qed.

Lemma refa4_not1644 : ~ @Equation1644 Fin8 refa4_inst.
Proof. unfold Equation1644. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa4_inst, refa4_op in H. discriminate H. Qed.

Lemma refa4_not1645 : ~ @Equation1645 Fin8 refa4_inst.
Proof. unfold Equation1645. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa4_inst, refa4_op in H. discriminate H. Qed.

Lemma refa4_not1648 : ~ @Equation1648 Fin8 refa4_inst.
Proof. unfold Equation1648. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa4_inst, refa4_op in H. discriminate H. Qed.

Lemma refa4_not1654 : ~ @Equation1654 Fin8 refa4_inst.
Proof. unfold Equation1654. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa4_inst, refa4_op in H. discriminate H. Qed.

Lemma refa4_not1655 : ~ @Equation1655 Fin8 refa4_inst.
Proof. unfold Equation1655. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa4_inst, refa4_op in H. discriminate H. Qed.

Lemma refa4_not1658 : ~ @Equation1658 Fin8 refa4_inst.
Proof. unfold Equation1658. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa4_inst, refa4_op in H. discriminate H. Qed.

Lemma refa4_not1681 : ~ @Equation1681 Fin8 refa4_inst.
Proof. unfold Equation1681. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa4_inst, refa4_op in H. discriminate H. Qed.

Lemma refa4_not1682 : ~ @Equation1682 Fin8 refa4_inst.
Proof. unfold Equation1682. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa4_inst, refa4_op in H. discriminate H. Qed.

Lemma refa4_not1684 : ~ @Equation1684 Fin8 refa4_inst.
Proof. unfold Equation1684. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa4_inst, refa4_op in H. discriminate H. Qed.

Lemma refa4_not1685 : ~ @Equation1685 Fin8 refa4_inst.
Proof. unfold Equation1685. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa4_inst, refa4_op in H. discriminate H. Qed.

Lemma refa4_not1691 : ~ @Equation1691 Fin8 refa4_inst.
Proof. unfold Equation1691. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa4_inst, refa4_op in H. discriminate H. Qed.

Lemma refa4_not1694 : ~ @Equation1694 Fin8 refa4_inst.
Proof. unfold Equation1694. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa4_inst, refa4_op in H. discriminate H. Qed.

Lemma refa4_not1719 : ~ @Equation1719 Fin8 refa4_inst.
Proof. unfold Equation1719. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa4_inst, refa4_op in H. discriminate H. Qed.

Lemma refa4_not1721 : ~ @Equation1721 Fin8 refa4_inst.
Proof. unfold Equation1721. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa4_inst, refa4_op in H. discriminate H. Qed.

Lemma refa4_not1728 : ~ @Equation1728 Fin8 refa4_inst.
Proof. unfold Equation1728. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa4_inst, refa4_op in H. discriminate H. Qed.

Lemma refa4_not1731 : ~ @Equation1731 Fin8 refa4_inst.
Proof. unfold Equation1731. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa4_inst, refa4_op in H. discriminate H. Qed.

Lemma refa4_not1833 : ~ @Equation1833 Fin8 refa4_inst.
Proof. unfold Equation1833. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa4_inst, refa4_op in H. discriminate H. Qed.

Lemma refa4_not1834 : ~ @Equation1834 Fin8 refa4_inst.
Proof. unfold Equation1834. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa4_inst, refa4_op in H. discriminate H. Qed.

Lemma refa4_not1837 : ~ @Equation1837 Fin8 refa4_inst.
Proof. unfold Equation1837. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa4_inst, refa4_op in H. discriminate H. Qed.

Lemma refa4_not1838 : ~ @Equation1838 Fin8 refa4_inst.
Proof. unfold Equation1838. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa4_inst, refa4_op in H. discriminate H. Qed.

Lemma refa4_not1840 : ~ @Equation1840 Fin8 refa4_inst.
Proof. unfold Equation1840. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa4_inst, refa4_op in H. discriminate H. Qed.

Lemma refa4_not1841 : ~ @Equation1841 Fin8 refa4_inst.
Proof. unfold Equation1841. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa4_inst, refa4_op in H. discriminate H. Qed.

Lemma refa4_not1847 : ~ @Equation1847 Fin8 refa4_inst.
Proof. unfold Equation1847. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa4_inst, refa4_op in H. discriminate H. Qed.

Lemma refa4_not1851 : ~ @Equation1851 Fin8 refa4_inst.
Proof. unfold Equation1851. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa4_inst, refa4_op in H. discriminate H. Qed.

Lemma refa4_not1857 : ~ @Equation1857 Fin8 refa4_inst.
Proof. unfold Equation1857. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa4_inst, refa4_op in H. discriminate H. Qed.

Lemma refa4_not1858 : ~ @Equation1858 Fin8 refa4_inst.
Proof. unfold Equation1858. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa4_inst, refa4_op in H. discriminate H. Qed.

Lemma refa4_not1861 : ~ @Equation1861 Fin8 refa4_inst.
Proof. unfold Equation1861. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa4_inst, refa4_op in H. discriminate H. Qed.

Lemma refa4_not1884 : ~ @Equation1884 Fin8 refa4_inst.
Proof. unfold Equation1884. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa4_inst, refa4_op in H. discriminate H. Qed.

Lemma refa4_not1885 : ~ @Equation1885 Fin8 refa4_inst.
Proof. unfold Equation1885. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa4_inst, refa4_op in H. discriminate H. Qed.

Lemma refa4_not1887 : ~ @Equation1887 Fin8 refa4_inst.
Proof. unfold Equation1887. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa4_inst, refa4_op in H. discriminate H. Qed.

Lemma refa4_not1888 : ~ @Equation1888 Fin8 refa4_inst.
Proof. unfold Equation1888. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa4_inst, refa4_op in H. discriminate H. Qed.

Lemma refa4_not1894 : ~ @Equation1894 Fin8 refa4_inst.
Proof. unfold Equation1894. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa4_inst, refa4_op in H. discriminate H. Qed.

Lemma refa4_not1895 : ~ @Equation1895 Fin8 refa4_inst.
Proof. unfold Equation1895. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa4_inst, refa4_op in H. discriminate H. Qed.

Lemma refa4_not1897 : ~ @Equation1897 Fin8 refa4_inst.
Proof. unfold Equation1897. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa4_inst, refa4_op in H. discriminate H. Qed.

Lemma refa4_not1921 : ~ @Equation1921 Fin8 refa4_inst.
Proof. unfold Equation1921. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa4_inst, refa4_op in H. discriminate H. Qed.

Lemma refa4_not1924 : ~ @Equation1924 Fin8 refa4_inst.
Proof. unfold Equation1924. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa4_inst, refa4_op in H. discriminate H. Qed.

Lemma refa4_not1925 : ~ @Equation1925 Fin8 refa4_inst.
Proof. unfold Equation1925. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa4_inst, refa4_op in H. discriminate H. Qed.

Lemma refa4_not1931 : ~ @Equation1931 Fin8 refa4_inst.
Proof. unfold Equation1931. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa4_inst, refa4_op in H. discriminate H. Qed.

Lemma refa4_not2036 : ~ @Equation2036 Fin8 refa4_inst.
Proof. unfold Equation2036. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa4_inst, refa4_op in H. discriminate H. Qed.

Lemma refa4_not2037 : ~ @Equation2037 Fin8 refa4_inst.
Proof. unfold Equation2037. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa4_inst, refa4_op in H. discriminate H. Qed.

Lemma refa4_not2038 : ~ @Equation2038 Fin8 refa4_inst.
Proof. unfold Equation2038. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa4_inst, refa4_op in H. discriminate H. Qed.

Lemma refa4_not2040 : ~ @Equation2040 Fin8 refa4_inst.
Proof. unfold Equation2040. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa4_inst, refa4_op in H. discriminate H. Qed.

Lemma refa4_not2041 : ~ @Equation2041 Fin8 refa4_inst.
Proof. unfold Equation2041. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa4_inst, refa4_op in H. discriminate H. Qed.

Lemma refa4_not2050 : ~ @Equation2050 Fin8 refa4_inst.
Proof. unfold Equation2050. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa4_inst, refa4_op in H. discriminate H. Qed.

Lemma refa4_not2053 : ~ @Equation2053 Fin8 refa4_inst.
Proof. unfold Equation2053. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa4_inst, refa4_op in H. discriminate H. Qed.

Lemma refa4_not2054 : ~ @Equation2054 Fin8 refa4_inst.
Proof. unfold Equation2054. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa4_inst, refa4_op in H. discriminate H. Qed.

Lemma refa4_not2060 : ~ @Equation2060 Fin8 refa4_inst.
Proof. unfold Equation2060. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa4_inst, refa4_op in H. discriminate H. Qed.

Lemma refa4_not2061 : ~ @Equation2061 Fin8 refa4_inst.
Proof. unfold Equation2061. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa4_inst, refa4_op in H. discriminate H. Qed.

Lemma refa4_not2063 : ~ @Equation2063 Fin8 refa4_inst.
Proof. unfold Equation2063. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa4_inst, refa4_op in H. discriminate H. Qed.

Lemma refa4_not2064 : ~ @Equation2064 Fin8 refa4_inst.
Proof. unfold Equation2064. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa4_inst, refa4_op in H. discriminate H. Qed.

Lemma refa4_not2087 : ~ @Equation2087 Fin8 refa4_inst.
Proof. unfold Equation2087. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa4_inst, refa4_op in H. discriminate H. Qed.

Lemma refa4_not2091 : ~ @Equation2091 Fin8 refa4_inst.
Proof. unfold Equation2091. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa4_inst, refa4_op in H. discriminate H. Qed.

Lemma refa4_not2097 : ~ @Equation2097 Fin8 refa4_inst.
Proof. unfold Equation2097. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa4_inst, refa4_op in H. discriminate H. Qed.

Lemma refa4_not2098 : ~ @Equation2098 Fin8 refa4_inst.
Proof. unfold Equation2098. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa4_inst, refa4_op in H. discriminate H. Qed.

Lemma refa4_not2124 : ~ @Equation2124 Fin8 refa4_inst.
Proof. unfold Equation2124. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa4_inst, refa4_op in H. discriminate H. Qed.

Lemma refa4_not2125 : ~ @Equation2125 Fin8 refa4_inst.
Proof. unfold Equation2125. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa4_inst, refa4_op in H. discriminate H. Qed.

Lemma refa4_not2127 : ~ @Equation2127 Fin8 refa4_inst.
Proof. unfold Equation2127. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa4_inst, refa4_op in H. discriminate H. Qed.

Lemma refa4_not2128 : ~ @Equation2128 Fin8 refa4_inst.
Proof. unfold Equation2128. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa4_inst, refa4_op in H. discriminate H. Qed.

Lemma refa4_not2134 : ~ @Equation2134 Fin8 refa4_inst.
Proof. unfold Equation2134. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa4_inst, refa4_op in H. discriminate H. Qed.

Lemma refa4_not2240 : ~ @Equation2240 Fin8 refa4_inst.
Proof. unfold Equation2240. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa4_inst, refa4_op in H. discriminate H. Qed.

Lemma refa4_not2243 : ~ @Equation2243 Fin8 refa4_inst.
Proof. unfold Equation2243. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa4_inst, refa4_op in H. discriminate H. Qed.

Lemma refa4_not2246 : ~ @Equation2246 Fin8 refa4_inst.
Proof. unfold Equation2246. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa4_inst, refa4_op in H. discriminate H. Qed.

Lemma refa4_not2247 : ~ @Equation2247 Fin8 refa4_inst.
Proof. unfold Equation2247. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa4_inst, refa4_op in H. discriminate H. Qed.

Lemma refa4_not2253 : ~ @Equation2253 Fin8 refa4_inst.
Proof. unfold Equation2253. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa4_inst, refa4_op in H. discriminate H. Qed.

Lemma refa4_not2254 : ~ @Equation2254 Fin8 refa4_inst.
Proof. unfold Equation2254. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa4_inst, refa4_op in H. discriminate H. Qed.

Lemma refa4_not2257 : ~ @Equation2257 Fin8 refa4_inst.
Proof. unfold Equation2257. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa4_inst, refa4_op in H. discriminate H. Qed.

Lemma refa4_not2263 : ~ @Equation2263 Fin8 refa4_inst.
Proof. unfold Equation2263. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa4_inst, refa4_op in H. discriminate H. Qed.

Lemma refa4_not2264 : ~ @Equation2264 Fin8 refa4_inst.
Proof. unfold Equation2264. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa4_inst, refa4_op in H. discriminate H. Qed.

Lemma refa4_not2266 : ~ @Equation2266 Fin8 refa4_inst.
Proof. unfold Equation2266. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa4_inst, refa4_op in H. discriminate H. Qed.

Lemma refa4_not2290 : ~ @Equation2290 Fin8 refa4_inst.
Proof. unfold Equation2290. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa4_inst, refa4_op in H. discriminate H. Qed.

Lemma refa4_not2291 : ~ @Equation2291 Fin8 refa4_inst.
Proof. unfold Equation2291. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa4_inst, refa4_op in H. discriminate H. Qed.

Lemma refa4_not2294 : ~ @Equation2294 Fin8 refa4_inst.
Proof. unfold Equation2294. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa4_inst, refa4_op in H. discriminate H. Qed.

Lemma refa4_not2300 : ~ @Equation2300 Fin8 refa4_inst.
Proof. unfold Equation2300. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa4_inst, refa4_op in H. discriminate H. Qed.

Lemma refa4_not2301 : ~ @Equation2301 Fin8 refa4_inst.
Proof. unfold Equation2301. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa4_inst, refa4_op in H. discriminate H. Qed.

Lemma refa4_not2303 : ~ @Equation2303 Fin8 refa4_inst.
Proof. unfold Equation2303. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa4_inst, refa4_op in H. discriminate H. Qed.

Lemma refa4_not2327 : ~ @Equation2327 Fin8 refa4_inst.
Proof. unfold Equation2327. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa4_inst, refa4_op in H. discriminate H. Qed.

Lemma refa4_not2328 : ~ @Equation2328 Fin8 refa4_inst.
Proof. unfold Equation2328. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa4_inst, refa4_op in H. discriminate H. Qed.

Lemma refa4_not2330 : ~ @Equation2330 Fin8 refa4_inst.
Proof. unfold Equation2330. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa4_inst, refa4_op in H. discriminate H. Qed.

Lemma refa4_not2337 : ~ @Equation2337 Fin8 refa4_inst.
Proof. unfold Equation2337. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa4_inst, refa4_op in H. discriminate H. Qed.

Lemma refa4_not2338 : ~ @Equation2338 Fin8 refa4_inst.
Proof. unfold Equation2338. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa4_inst, refa4_op in H. discriminate H. Qed.

Lemma refa4_not2340 : ~ @Equation2340 Fin8 refa4_inst.
Proof. unfold Equation2340. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa4_inst, refa4_op in H. discriminate H. Qed.

Lemma refa4_not2443 : ~ @Equation2443 Fin8 refa4_inst.
Proof. unfold Equation2443. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa4_inst, refa4_op in H. discriminate H. Qed.

Lemma refa4_not2444 : ~ @Equation2444 Fin8 refa4_inst.
Proof. unfold Equation2444. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa4_inst, refa4_op in H. discriminate H. Qed.

Lemma refa4_not2446 : ~ @Equation2446 Fin8 refa4_inst.
Proof. unfold Equation2446. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa4_inst, refa4_op in H. discriminate H. Qed.

Lemma refa4_not2449 : ~ @Equation2449 Fin8 refa4_inst.
Proof. unfold Equation2449. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa4_inst, refa4_op in H. discriminate H. Qed.

Lemma refa4_not2456 : ~ @Equation2456 Fin8 refa4_inst.
Proof. unfold Equation2456. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa4_inst, refa4_op in H. discriminate H. Qed.

Lemma refa4_not2457 : ~ @Equation2457 Fin8 refa4_inst.
Proof. unfold Equation2457. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa4_inst, refa4_op in H. discriminate H. Qed.

Lemma refa4_not2460 : ~ @Equation2460 Fin8 refa4_inst.
Proof. unfold Equation2460. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa4_inst, refa4_op in H. discriminate H. Qed.

Lemma refa4_not2466 : ~ @Equation2466 Fin8 refa4_inst.
Proof. unfold Equation2466. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa4_inst, refa4_op in H. discriminate H. Qed.

Lemma refa4_not2467 : ~ @Equation2467 Fin8 refa4_inst.
Proof. unfold Equation2467. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa4_inst, refa4_op in H. discriminate H. Qed.

Lemma refa4_not2469 : ~ @Equation2469 Fin8 refa4_inst.
Proof. unfold Equation2469. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa4_inst, refa4_op in H. discriminate H. Qed.

Lemma refa4_not2493 : ~ @Equation2493 Fin8 refa4_inst.
Proof. unfold Equation2493. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa4_inst, refa4_op in H. discriminate H. Qed.

Lemma refa4_not2496 : ~ @Equation2496 Fin8 refa4_inst.
Proof. unfold Equation2496. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa4_inst, refa4_op in H. discriminate H. Qed.

Lemma refa4_not2503 : ~ @Equation2503 Fin8 refa4_inst.
Proof. unfold Equation2503. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa4_inst, refa4_op in H. discriminate H. Qed.

Lemma refa4_not2504 : ~ @Equation2504 Fin8 refa4_inst.
Proof. unfold Equation2504. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa4_inst, refa4_op in H. discriminate H. Qed.

Lemma refa4_not2530 : ~ @Equation2530 Fin8 refa4_inst.
Proof. unfold Equation2530. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa4_inst, refa4_op in H. discriminate H. Qed.

Lemma refa4_not2531 : ~ @Equation2531 Fin8 refa4_inst.
Proof. unfold Equation2531. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa4_inst, refa4_op in H. discriminate H. Qed.

Lemma refa4_not2533 : ~ @Equation2533 Fin8 refa4_inst.
Proof. unfold Equation2533. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa4_inst, refa4_op in H. discriminate H. Qed.

Lemma refa4_not2534 : ~ @Equation2534 Fin8 refa4_inst.
Proof. unfold Equation2534. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa4_inst, refa4_op in H. discriminate H. Qed.

Lemma refa4_not2540 : ~ @Equation2540 Fin8 refa4_inst.
Proof. unfold Equation2540. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa4_inst, refa4_op in H. discriminate H. Qed.

Lemma refa4_not2541 : ~ @Equation2541 Fin8 refa4_inst.
Proof. unfold Equation2541. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa4_inst, refa4_op in H. discriminate H. Qed.

Lemma refa4_not2543 : ~ @Equation2543 Fin8 refa4_inst.
Proof. unfold Equation2543. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa4_inst, refa4_op in H. discriminate H. Qed.

Lemma refa4_not2646 : ~ @Equation2646 Fin8 refa4_inst.
Proof. unfold Equation2646. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa4_inst, refa4_op in H. discriminate H. Qed.

Lemma refa4_not2647 : ~ @Equation2647 Fin8 refa4_inst.
Proof. unfold Equation2647. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa4_inst, refa4_op in H. discriminate H. Qed.

Lemma refa4_not2649 : ~ @Equation2649 Fin8 refa4_inst.
Proof. unfold Equation2649. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa4_inst, refa4_op in H. discriminate H. Qed.

Lemma refa4_not2650 : ~ @Equation2650 Fin8 refa4_inst.
Proof. unfold Equation2650. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa4_inst, refa4_op in H. discriminate H. Qed.

Lemma refa4_not2652 : ~ @Equation2652 Fin8 refa4_inst.
Proof. unfold Equation2652. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa4_inst, refa4_op in H. discriminate H. Qed.

Lemma refa4_not2653 : ~ @Equation2653 Fin8 refa4_inst.
Proof. unfold Equation2653. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa4_inst, refa4_op in H. discriminate H. Qed.

Lemma refa4_not2659 : ~ @Equation2659 Fin8 refa4_inst.
Proof. unfold Equation2659. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa4_inst, refa4_op in H. discriminate H. Qed.

Lemma refa4_not2660 : ~ @Equation2660 Fin8 refa4_inst.
Proof. unfold Equation2660. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa4_inst, refa4_op in H. discriminate H. Qed.

Lemma refa4_not2662 : ~ @Equation2662 Fin8 refa4_inst.
Proof. unfold Equation2662. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa4_inst, refa4_op in H. discriminate H. Qed.

Lemma refa4_not2670 : ~ @Equation2670 Fin8 refa4_inst.
Proof. unfold Equation2670. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa4_inst, refa4_op in H. discriminate H. Qed.

Lemma refa4_not2672 : ~ @Equation2672 Fin8 refa4_inst.
Proof. unfold Equation2672. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa4_inst, refa4_op in H. discriminate H. Qed.

Lemma refa4_not2696 : ~ @Equation2696 Fin8 refa4_inst.
Proof. unfold Equation2696. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa4_inst, refa4_op in H. discriminate H. Qed.

Lemma refa4_not2697 : ~ @Equation2697 Fin8 refa4_inst.
Proof. unfold Equation2697. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa4_inst, refa4_op in H. discriminate H. Qed.

Lemma refa4_not2699 : ~ @Equation2699 Fin8 refa4_inst.
Proof. unfold Equation2699. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa4_inst, refa4_op in H. discriminate H. Qed.

Lemma refa4_not2700 : ~ @Equation2700 Fin8 refa4_inst.
Proof. unfold Equation2700. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa4_inst, refa4_op in H. discriminate H. Qed.

Lemma refa4_not2706 : ~ @Equation2706 Fin8 refa4_inst.
Proof. unfold Equation2706. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa4_inst, refa4_op in H. discriminate H. Qed.

Lemma refa4_not2709 : ~ @Equation2709 Fin8 refa4_inst.
Proof. unfold Equation2709. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa4_inst, refa4_op in H. discriminate H. Qed.

Lemma refa4_not2733 : ~ @Equation2733 Fin8 refa4_inst.
Proof. unfold Equation2733. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa4_inst, refa4_op in H. discriminate H. Qed.

Lemma refa4_not2734 : ~ @Equation2734 Fin8 refa4_inst.
Proof. unfold Equation2734. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa4_inst, refa4_op in H. discriminate H. Qed.

Lemma refa4_not2736 : ~ @Equation2736 Fin8 refa4_inst.
Proof. unfold Equation2736. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa4_inst, refa4_op in H. discriminate H. Qed.

Lemma refa4_not2743 : ~ @Equation2743 Fin8 refa4_inst.
Proof. unfold Equation2743. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa4_inst, refa4_op in H. discriminate H. Qed.

Lemma refa4_not2744 : ~ @Equation2744 Fin8 refa4_inst.
Proof. unfold Equation2744. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa4_inst, refa4_op in H. discriminate H. Qed.

Lemma refa4_not2746 : ~ @Equation2746 Fin8 refa4_inst.
Proof. unfold Equation2746. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa4_inst, refa4_op in H. discriminate H. Qed.

Lemma refa4_not2849 : ~ @Equation2849 Fin8 refa4_inst.
Proof. unfold Equation2849. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa4_inst, refa4_op in H. discriminate H. Qed.

Lemma refa4_not2852 : ~ @Equation2852 Fin8 refa4_inst.
Proof. unfold Equation2852. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa4_inst, refa4_op in H. discriminate H. Qed.

Lemma refa4_not2855 : ~ @Equation2855 Fin8 refa4_inst.
Proof. unfold Equation2855. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa4_inst, refa4_op in H. discriminate H. Qed.

Lemma refa4_not2856 : ~ @Equation2856 Fin8 refa4_inst.
Proof. unfold Equation2856. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa4_inst, refa4_op in H. discriminate H. Qed.

Lemma refa4_not2862 : ~ @Equation2862 Fin8 refa4_inst.
Proof. unfold Equation2862. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa4_inst, refa4_op in H. discriminate H. Qed.

Lemma refa4_not2865 : ~ @Equation2865 Fin8 refa4_inst.
Proof. unfold Equation2865. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa4_inst, refa4_op in H. discriminate H. Qed.

Lemma refa4_not2872 : ~ @Equation2872 Fin8 refa4_inst.
Proof. unfold Equation2872. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa4_inst, refa4_op in H. discriminate H. Qed.

Lemma refa4_not2873 : ~ @Equation2873 Fin8 refa4_inst.
Proof. unfold Equation2873. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa4_inst, refa4_op in H. discriminate H. Qed.

Lemma refa4_not2899 : ~ @Equation2899 Fin8 refa4_inst.
Proof. unfold Equation2899. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa4_inst, refa4_op in H. discriminate H. Qed.

Lemma refa4_not2900 : ~ @Equation2900 Fin8 refa4_inst.
Proof. unfold Equation2900. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa4_inst, refa4_op in H. discriminate H. Qed.

Lemma refa4_not2902 : ~ @Equation2902 Fin8 refa4_inst.
Proof. unfold Equation2902. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa4_inst, refa4_op in H. discriminate H. Qed.

Lemma refa4_not2909 : ~ @Equation2909 Fin8 refa4_inst.
Proof. unfold Equation2909. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa4_inst, refa4_op in H. discriminate H. Qed.

Lemma refa4_not2910 : ~ @Equation2910 Fin8 refa4_inst.
Proof. unfold Equation2910. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa4_inst, refa4_op in H. discriminate H. Qed.

Lemma refa4_not2936 : ~ @Equation2936 Fin8 refa4_inst.
Proof. unfold Equation2936. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa4_inst, refa4_op in H. discriminate H. Qed.

Lemma refa4_not2937 : ~ @Equation2937 Fin8 refa4_inst.
Proof. unfold Equation2937. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa4_inst, refa4_op in H. discriminate H. Qed.

Lemma refa4_not2939 : ~ @Equation2939 Fin8 refa4_inst.
Proof. unfold Equation2939. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa4_inst, refa4_op in H. discriminate H. Qed.

Lemma refa4_not2940 : ~ @Equation2940 Fin8 refa4_inst.
Proof. unfold Equation2940. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa4_inst, refa4_op in H. discriminate H. Qed.

Lemma refa4_not2946 : ~ @Equation2946 Fin8 refa4_inst.
Proof. unfold Equation2946. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa4_inst, refa4_op in H. discriminate H. Qed.

Lemma refa4_not2947 : ~ @Equation2947 Fin8 refa4_inst.
Proof. unfold Equation2947. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa4_inst, refa4_op in H. discriminate H. Qed.

Lemma refa4_not2949 : ~ @Equation2949 Fin8 refa4_inst.
Proof. unfold Equation2949. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa4_inst, refa4_op in H. discriminate H. Qed.

Lemma refa4_not3052 : ~ @Equation3052 Fin8 refa4_inst.
Proof. unfold Equation3052. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa4_inst, refa4_op in H. discriminate H. Qed.

Lemma refa4_not3055 : ~ @Equation3055 Fin8 refa4_inst.
Proof. unfold Equation3055. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa4_inst, refa4_op in H. discriminate H. Qed.

Lemma refa4_not3056 : ~ @Equation3056 Fin8 refa4_inst.
Proof. unfold Equation3056. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa4_inst, refa4_op in H. discriminate H. Qed.

Lemma refa4_not3058 : ~ @Equation3058 Fin8 refa4_inst.
Proof. unfold Equation3058. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa4_inst, refa4_op in H. discriminate H. Qed.

Lemma refa4_not3065 : ~ @Equation3065 Fin8 refa4_inst.
Proof. unfold Equation3065. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa4_inst, refa4_op in H. discriminate H. Qed.

Lemma refa4_not3066 : ~ @Equation3066 Fin8 refa4_inst.
Proof. unfold Equation3066. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa4_inst, refa4_op in H. discriminate H. Qed.

Lemma refa4_not3068 : ~ @Equation3068 Fin8 refa4_inst.
Proof. unfold Equation3068. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa4_inst, refa4_op in H. discriminate H. Qed.

Lemma refa4_not3069 : ~ @Equation3069 Fin8 refa4_inst.
Proof. unfold Equation3069. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa4_inst, refa4_op in H. discriminate H. Qed.

Lemma refa4_not3075 : ~ @Equation3075 Fin8 refa4_inst.
Proof. unfold Equation3075. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa4_inst, refa4_op in H. discriminate H. Qed.

Lemma refa4_not3078 : ~ @Equation3078 Fin8 refa4_inst.
Proof. unfold Equation3078. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa4_inst, refa4_op in H. discriminate H. Qed.

Lemma refa4_not3079 : ~ @Equation3079 Fin8 refa4_inst.
Proof. unfold Equation3079. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa4_inst, refa4_op in H. discriminate H. Qed.

Lemma refa4_not3102 : ~ @Equation3102 Fin8 refa4_inst.
Proof. unfold Equation3102. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa4_inst, refa4_op in H. discriminate H. Qed.

Lemma refa4_not3103 : ~ @Equation3103 Fin8 refa4_inst.
Proof. unfold Equation3103. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa4_inst, refa4_op in H. discriminate H. Qed.

Lemma refa4_not3105 : ~ @Equation3105 Fin8 refa4_inst.
Proof. unfold Equation3105. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa4_inst, refa4_op in H. discriminate H. Qed.

Lemma refa4_not3106 : ~ @Equation3106 Fin8 refa4_inst.
Proof. unfold Equation3106. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa4_inst, refa4_op in H. discriminate H. Qed.

Lemma refa4_not3112 : ~ @Equation3112 Fin8 refa4_inst.
Proof. unfold Equation3112. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa4_inst, refa4_op in H. discriminate H. Qed.

Lemma refa4_not3113 : ~ @Equation3113 Fin8 refa4_inst.
Proof. unfold Equation3113. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa4_inst, refa4_op in H. discriminate H. Qed.

Lemma refa4_not3116 : ~ @Equation3116 Fin8 refa4_inst.
Proof. unfold Equation3116. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa4_inst, refa4_op in H. discriminate H. Qed.

Lemma refa4_not3139 : ~ @Equation3139 Fin8 refa4_inst.
Proof. unfold Equation3139. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa4_inst, refa4_op in H. discriminate H. Qed.

Lemma refa4_not3140 : ~ @Equation3140 Fin8 refa4_inst.
Proof. unfold Equation3140. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa4_inst, refa4_op in H. discriminate H. Qed.

Lemma refa4_not3142 : ~ @Equation3142 Fin8 refa4_inst.
Proof. unfold Equation3142. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa4_inst, refa4_op in H. discriminate H. Qed.

Lemma refa4_not3149 : ~ @Equation3149 Fin8 refa4_inst.
Proof. unfold Equation3149. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa4_inst, refa4_op in H. discriminate H. Qed.

Lemma refa4_not3150 : ~ @Equation3150 Fin8 refa4_inst.
Proof. unfold Equation3150. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa4_inst, refa4_op in H. discriminate H. Qed.

Lemma refa4_not3152 : ~ @Equation3152 Fin8 refa4_inst.
Proof. unfold Equation3152. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa4_inst, refa4_op in H. discriminate H. Qed.

Lemma refa4_not3254 : ~ @Equation3254 Fin8 refa4_inst.
Proof. unfold Equation3254. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa4_inst, refa4_op in H. discriminate H. Qed.

Lemma refa4_not3255 : ~ @Equation3255 Fin8 refa4_inst.
Proof. unfold Equation3255. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa4_inst, refa4_op in H. discriminate H. Qed.

Lemma refa4_not3256 : ~ @Equation3256 Fin8 refa4_inst.
Proof. unfold Equation3256. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa4_inst, refa4_op in H. discriminate H. Qed.

Lemma refa4_not3258 : ~ @Equation3258 Fin8 refa4_inst.
Proof. unfold Equation3258. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa4_inst, refa4_op in H. discriminate H. Qed.

Lemma refa4_not3261 : ~ @Equation3261 Fin8 refa4_inst.
Proof. unfold Equation3261. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa4_inst, refa4_op in H. discriminate H. Qed.

Lemma refa4_not3262 : ~ @Equation3262 Fin8 refa4_inst.
Proof. unfold Equation3262. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa4_inst, refa4_op in H. discriminate H. Qed.

Lemma refa4_not3268 : ~ @Equation3268 Fin8 refa4_inst.
Proof. unfold Equation3268. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa4_inst, refa4_op in H. discriminate H. Qed.

Lemma refa4_not3271 : ~ @Equation3271 Fin8 refa4_inst.
Proof. unfold Equation3271. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa4_inst, refa4_op in H. discriminate H. Qed.

Lemma refa4_not3272 : ~ @Equation3272 Fin8 refa4_inst.
Proof. unfold Equation3272. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa4_inst, refa4_op in H. discriminate H. Qed.

Lemma refa4_not3278 : ~ @Equation3278 Fin8 refa4_inst.
Proof. unfold Equation3278. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa4_inst, refa4_op in H. discriminate H. Qed.

Lemma refa4_not3279 : ~ @Equation3279 Fin8 refa4_inst.
Proof. unfold Equation3279. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa4_inst, refa4_op in H. discriminate H. Qed.

Lemma refa4_not3281 : ~ @Equation3281 Fin8 refa4_inst.
Proof. unfold Equation3281. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa4_inst, refa4_op in H. discriminate H. Qed.

Lemma refa4_not3306 : ~ @Equation3306 Fin8 refa4_inst.
Proof. unfold Equation3306. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa4_inst, refa4_op in H. discriminate H. Qed.

Lemma refa4_not3309 : ~ @Equation3309 Fin8 refa4_inst.
Proof. unfold Equation3309. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa4_inst, refa4_op in H. discriminate H. Qed.

Lemma refa4_not3315 : ~ @Equation3315 Fin8 refa4_inst.
Proof. unfold Equation3315. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa4_inst, refa4_op in H. discriminate H. Qed.

Lemma refa4_not3316 : ~ @Equation3316 Fin8 refa4_inst.
Proof. unfold Equation3316. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa4_inst, refa4_op in H. discriminate H. Qed.

Lemma refa4_not3318 : ~ @Equation3318 Fin8 refa4_inst.
Proof. unfold Equation3318. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa4_inst, refa4_op in H. discriminate H. Qed.

Lemma refa4_not3342 : ~ @Equation3342 Fin8 refa4_inst.
Proof. unfold Equation3342. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa4_inst, refa4_op in H. discriminate H. Qed.

Lemma refa4_not3343 : ~ @Equation3343 Fin8 refa4_inst.
Proof. unfold Equation3343. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa4_inst, refa4_op in H. discriminate H. Qed.

Lemma refa4_not3345 : ~ @Equation3345 Fin8 refa4_inst.
Proof. unfold Equation3345. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa4_inst, refa4_op in H. discriminate H. Qed.

Lemma refa4_not3346 : ~ @Equation3346 Fin8 refa4_inst.
Proof. unfold Equation3346. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa4_inst, refa4_op in H. discriminate H. Qed.

Lemma refa4_not3352 : ~ @Equation3352 Fin8 refa4_inst.
Proof. unfold Equation3352. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa4_inst, refa4_op in H. discriminate H. Qed.

Lemma refa4_not3353 : ~ @Equation3353 Fin8 refa4_inst.
Proof. unfold Equation3353. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa4_inst, refa4_op in H. discriminate H. Qed.

Lemma refa4_not3457 : ~ @Equation3457 Fin8 refa4_inst.
Proof. unfold Equation3457. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa4_inst, refa4_op in H. discriminate H. Qed.

Lemma refa4_not3458 : ~ @Equation3458 Fin8 refa4_inst.
Proof. unfold Equation3458. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa4_inst, refa4_op in H. discriminate H. Qed.

Lemma refa4_not3459 : ~ @Equation3459 Fin8 refa4_inst.
Proof. unfold Equation3459. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa4_inst, refa4_op in H. discriminate H. Qed.

Lemma refa4_not3461 : ~ @Equation3461 Fin8 refa4_inst.
Proof. unfold Equation3461. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa4_inst, refa4_op in H. discriminate H. Qed.

Lemma refa4_not3464 : ~ @Equation3464 Fin8 refa4_inst.
Proof. unfold Equation3464. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa4_inst, refa4_op in H. discriminate H. Qed.

Lemma refa4_not3465 : ~ @Equation3465 Fin8 refa4_inst.
Proof. unfold Equation3465. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa4_inst, refa4_op in H. discriminate H. Qed.

Lemma refa4_not3472 : ~ @Equation3472 Fin8 refa4_inst.
Proof. unfold Equation3472. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa4_inst, refa4_op in H. discriminate H. Qed.

Lemma refa4_not3474 : ~ @Equation3474 Fin8 refa4_inst.
Proof. unfold Equation3474. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa4_inst, refa4_op in H. discriminate H. Qed.

Lemma refa4_not3481 : ~ @Equation3481 Fin8 refa4_inst.
Proof. unfold Equation3481. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa4_inst, refa4_op in H. discriminate H. Qed.

Lemma refa4_not3482 : ~ @Equation3482 Fin8 refa4_inst.
Proof. unfold Equation3482. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa4_inst, refa4_op in H. discriminate H. Qed.

Lemma refa4_not3484 : ~ @Equation3484 Fin8 refa4_inst.
Proof. unfold Equation3484. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa4_inst, refa4_op in H. discriminate H. Qed.

Lemma refa4_not3509 : ~ @Equation3509 Fin8 refa4_inst.
Proof. unfold Equation3509. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa4_inst, refa4_op in H. discriminate H. Qed.

Lemma refa4_not3512 : ~ @Equation3512 Fin8 refa4_inst.
Proof. unfold Equation3512. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa4_inst, refa4_op in H. discriminate H. Qed.

Lemma refa4_not3518 : ~ @Equation3518 Fin8 refa4_inst.
Proof. unfold Equation3518. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa4_inst, refa4_op in H. discriminate H. Qed.

Lemma refa4_not3519 : ~ @Equation3519 Fin8 refa4_inst.
Proof. unfold Equation3519. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa4_inst, refa4_op in H. discriminate H. Qed.

Lemma refa4_not3521 : ~ @Equation3521 Fin8 refa4_inst.
Proof. unfold Equation3521. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa4_inst, refa4_op in H. discriminate H. Qed.

Lemma refa4_not3545 : ~ @Equation3545 Fin8 refa4_inst.
Proof. unfold Equation3545. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa4_inst, refa4_op in H. discriminate H. Qed.

Lemma refa4_not3546 : ~ @Equation3546 Fin8 refa4_inst.
Proof. unfold Equation3546. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa4_inst, refa4_op in H. discriminate H. Qed.

Lemma refa4_not3548 : ~ @Equation3548 Fin8 refa4_inst.
Proof. unfold Equation3548. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa4_inst, refa4_op in H. discriminate H. Qed.

Lemma refa4_not3549 : ~ @Equation3549 Fin8 refa4_inst.
Proof. unfold Equation3549. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa4_inst, refa4_op in H. discriminate H. Qed.

Lemma refa4_not3556 : ~ @Equation3556 Fin8 refa4_inst.
Proof. unfold Equation3556. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa4_inst, refa4_op in H. discriminate H. Qed.

Lemma refa4_not3558 : ~ @Equation3558 Fin8 refa4_inst.
Proof. unfold Equation3558. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa4_inst, refa4_op in H. discriminate H. Qed.

Lemma refa4_not3660 : ~ @Equation3660 Fin8 refa4_inst.
Proof. unfold Equation3660. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa4_inst, refa4_op in H. discriminate H. Qed.

Lemma refa4_not3661 : ~ @Equation3661 Fin8 refa4_inst.
Proof. unfold Equation3661. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa4_inst, refa4_op in H. discriminate H. Qed.

Lemma refa4_not3662 : ~ @Equation3662 Fin8 refa4_inst.
Proof. unfold Equation3662. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa4_inst, refa4_op in H. discriminate H. Qed.

Lemma refa4_not3664 : ~ @Equation3664 Fin8 refa4_inst.
Proof. unfold Equation3664. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa4_inst, refa4_op in H. discriminate H. Qed.

Lemma refa4_not3665 : ~ @Equation3665 Fin8 refa4_inst.
Proof. unfold Equation3665. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa4_inst, refa4_op in H. discriminate H. Qed.

Lemma refa4_not3668 : ~ @Equation3668 Fin8 refa4_inst.
Proof. unfold Equation3668. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa4_inst, refa4_op in H. discriminate H. Qed.

Lemma refa4_not3674 : ~ @Equation3674 Fin8 refa4_inst.
Proof. unfold Equation3674. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa4_inst, refa4_op in H. discriminate H. Qed.

Lemma refa4_not3675 : ~ @Equation3675 Fin8 refa4_inst.
Proof. unfold Equation3675. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa4_inst, refa4_op in H. discriminate H. Qed.

Lemma refa4_not3677 : ~ @Equation3677 Fin8 refa4_inst.
Proof. unfold Equation3677. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa4_inst, refa4_op in H. discriminate H. Qed.

Lemma refa4_not3678 : ~ @Equation3678 Fin8 refa4_inst.
Proof. unfold Equation3678. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa4_inst, refa4_op in H. discriminate H. Qed.

Lemma refa4_not3684 : ~ @Equation3684 Fin8 refa4_inst.
Proof. unfold Equation3684. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa4_inst, refa4_op in H. discriminate H. Qed.

Lemma refa4_not3685 : ~ @Equation3685 Fin8 refa4_inst.
Proof. unfold Equation3685. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa4_inst, refa4_op in H. discriminate H. Qed.

Lemma refa4_not3687 : ~ @Equation3687 Fin8 refa4_inst.
Proof. unfold Equation3687. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa4_inst, refa4_op in H. discriminate H. Qed.

Lemma refa4_not3712 : ~ @Equation3712 Fin8 refa4_inst.
Proof. unfold Equation3712. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa4_inst, refa4_op in H. discriminate H. Qed.

Lemma refa4_not3714 : ~ @Equation3714 Fin8 refa4_inst.
Proof. unfold Equation3714. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa4_inst, refa4_op in H. discriminate H. Qed.

Lemma refa4_not3721 : ~ @Equation3721 Fin8 refa4_inst.
Proof. unfold Equation3721. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa4_inst, refa4_op in H. discriminate H. Qed.

Lemma refa4_not3724 : ~ @Equation3724 Fin8 refa4_inst.
Proof. unfold Equation3724. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa4_inst, refa4_op in H. discriminate H. Qed.

Lemma refa4_not3725 : ~ @Equation3725 Fin8 refa4_inst.
Proof. unfold Equation3725. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa4_inst, refa4_op in H. discriminate H. Qed.

Lemma refa4_not3748 : ~ @Equation3748 Fin8 refa4_inst.
Proof. unfold Equation3748. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa4_inst, refa4_op in H. discriminate H. Qed.

Lemma refa4_not3749 : ~ @Equation3749 Fin8 refa4_inst.
Proof. unfold Equation3749. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa4_inst, refa4_op in H. discriminate H. Qed.

Lemma refa4_not3752 : ~ @Equation3752 Fin8 refa4_inst.
Proof. unfold Equation3752. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa4_inst, refa4_op in H. discriminate H. Qed.

Lemma refa4_not3759 : ~ @Equation3759 Fin8 refa4_inst.
Proof. unfold Equation3759. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa4_inst, refa4_op in H. discriminate H. Qed.

Lemma refa4_not3761 : ~ @Equation3761 Fin8 refa4_inst.
Proof. unfold Equation3761. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa4_inst, refa4_op in H. discriminate H. Qed.

Lemma refa4_not3864 : ~ @Equation3864 Fin8 refa4_inst.
Proof. unfold Equation3864. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa4_inst, refa4_op in H. discriminate H. Qed.

Lemma refa4_not3865 : ~ @Equation3865 Fin8 refa4_inst.
Proof. unfold Equation3865. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa4_inst, refa4_op in H. discriminate H. Qed.

Lemma refa4_not3867 : ~ @Equation3867 Fin8 refa4_inst.
Proof. unfold Equation3867. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa4_inst, refa4_op in H. discriminate H. Qed.

Lemma refa4_not3868 : ~ @Equation3868 Fin8 refa4_inst.
Proof. unfold Equation3868. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa4_inst, refa4_op in H. discriminate H. Qed.

Lemma refa4_not3870 : ~ @Equation3870 Fin8 refa4_inst.
Proof. unfold Equation3870. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa4_inst, refa4_op in H. discriminate H. Qed.

Lemma refa4_not3871 : ~ @Equation3871 Fin8 refa4_inst.
Proof. unfold Equation3871. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa4_inst, refa4_op in H. discriminate H. Qed.

Lemma refa4_not3877 : ~ @Equation3877 Fin8 refa4_inst.
Proof. unfold Equation3877. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa4_inst, refa4_op in H. discriminate H. Qed.

Lemma refa4_not3878 : ~ @Equation3878 Fin8 refa4_inst.
Proof. unfold Equation3878. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa4_inst, refa4_op in H. discriminate H. Qed.

Lemma refa4_not3880 : ~ @Equation3880 Fin8 refa4_inst.
Proof. unfold Equation3880. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa4_inst, refa4_op in H. discriminate H. Qed.

Lemma refa4_not3887 : ~ @Equation3887 Fin8 refa4_inst.
Proof. unfold Equation3887. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa4_inst, refa4_op in H. discriminate H. Qed.

Lemma refa4_not3888 : ~ @Equation3888 Fin8 refa4_inst.
Proof. unfold Equation3888. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa4_inst, refa4_op in H. discriminate H. Qed.

Lemma refa4_not3890 : ~ @Equation3890 Fin8 refa4_inst.
Proof. unfold Equation3890. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa4_inst, refa4_op in H. discriminate H. Qed.

Lemma refa4_not3917 : ~ @Equation3917 Fin8 refa4_inst.
Proof. unfold Equation3917. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa4_inst, refa4_op in H. discriminate H. Qed.

Lemma refa4_not3918 : ~ @Equation3918 Fin8 refa4_inst.
Proof. unfold Equation3918. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa4_inst, refa4_op in H. discriminate H. Qed.

Lemma refa4_not3924 : ~ @Equation3924 Fin8 refa4_inst.
Proof. unfold Equation3924. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa4_inst, refa4_op in H. discriminate H. Qed.

Lemma refa4_not3925 : ~ @Equation3925 Fin8 refa4_inst.
Proof. unfold Equation3925. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa4_inst, refa4_op in H. discriminate H. Qed.

Lemma refa4_not3927 : ~ @Equation3927 Fin8 refa4_inst.
Proof. unfold Equation3927. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa4_inst, refa4_op in H. discriminate H. Qed.

Lemma refa4_not3928 : ~ @Equation3928 Fin8 refa4_inst.
Proof. unfold Equation3928. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa4_inst, refa4_op in H. discriminate H. Qed.

Lemma refa4_not3951 : ~ @Equation3951 Fin8 refa4_inst.
Proof. unfold Equation3951. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa4_inst, refa4_op in H. discriminate H. Qed.

Lemma refa4_not3952 : ~ @Equation3952 Fin8 refa4_inst.
Proof. unfold Equation3952. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa4_inst, refa4_op in H. discriminate H. Qed.

Lemma refa4_not3955 : ~ @Equation3955 Fin8 refa4_inst.
Proof. unfold Equation3955. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa4_inst, refa4_op in H. discriminate H. Qed.

Lemma refa4_not3961 : ~ @Equation3961 Fin8 refa4_inst.
Proof. unfold Equation3961. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa4_inst, refa4_op in H. discriminate H. Qed.

Lemma refa4_not3962 : ~ @Equation3962 Fin8 refa4_inst.
Proof. unfold Equation3962. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa4_inst, refa4_op in H. discriminate H. Qed.

Lemma refa4_not3964 : ~ @Equation3964 Fin8 refa4_inst.
Proof. unfold Equation3964. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa4_inst, refa4_op in H. discriminate H. Qed.

Lemma refa4_not4066 : ~ @Equation4066 Fin8 refa4_inst.
Proof. unfold Equation4066. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa4_inst, refa4_op in H. discriminate H. Qed.

Lemma refa4_not4067 : ~ @Equation4067 Fin8 refa4_inst.
Proof. unfold Equation4067. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa4_inst, refa4_op in H. discriminate H. Qed.

Lemma refa4_not4068 : ~ @Equation4068 Fin8 refa4_inst.
Proof. unfold Equation4068. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa4_inst, refa4_op in H. discriminate H. Qed.

Lemma refa4_not4070 : ~ @Equation4070 Fin8 refa4_inst.
Proof. unfold Equation4070. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa4_inst, refa4_op in H. discriminate H. Qed.

Lemma refa4_not4071 : ~ @Equation4071 Fin8 refa4_inst.
Proof. unfold Equation4071. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa4_inst, refa4_op in H. discriminate H. Qed.

Lemma refa4_not4073 : ~ @Equation4073 Fin8 refa4_inst.
Proof. unfold Equation4073. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa4_inst, refa4_op in H. discriminate H. Qed.

Lemma refa4_not4074 : ~ @Equation4074 Fin8 refa4_inst.
Proof. unfold Equation4074. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa4_inst, refa4_op in H. discriminate H. Qed.

Lemma refa4_not4080 : ~ @Equation4080 Fin8 refa4_inst.
Proof. unfold Equation4080. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa4_inst, refa4_op in H. discriminate H. Qed.

Lemma refa4_not4081 : ~ @Equation4081 Fin8 refa4_inst.
Proof. unfold Equation4081. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa4_inst, refa4_op in H. discriminate H. Qed.

Lemma refa4_not4083 : ~ @Equation4083 Fin8 refa4_inst.
Proof. unfold Equation4083. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa4_inst, refa4_op in H. discriminate H. Qed.

Lemma refa4_not4090 : ~ @Equation4090 Fin8 refa4_inst.
Proof. unfold Equation4090. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa4_inst, refa4_op in H. discriminate H. Qed.

Lemma refa4_not4091 : ~ @Equation4091 Fin8 refa4_inst.
Proof. unfold Equation4091. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa4_inst, refa4_op in H. discriminate H. Qed.

Lemma refa4_not4093 : ~ @Equation4093 Fin8 refa4_inst.
Proof. unfold Equation4093. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa4_inst, refa4_op in H. discriminate H. Qed.

Lemma refa4_not4120 : ~ @Equation4120 Fin8 refa4_inst.
Proof. unfold Equation4120. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa4_inst, refa4_op in H. discriminate H. Qed.

Lemma refa4_not4121 : ~ @Equation4121 Fin8 refa4_inst.
Proof. unfold Equation4121. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa4_inst, refa4_op in H. discriminate H. Qed.

Lemma refa4_not4127 : ~ @Equation4127 Fin8 refa4_inst.
Proof. unfold Equation4127. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa4_inst, refa4_op in H. discriminate H. Qed.

Lemma refa4_not4128 : ~ @Equation4128 Fin8 refa4_inst.
Proof. unfold Equation4128. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa4_inst, refa4_op in H. discriminate H. Qed.

Lemma refa4_not4130 : ~ @Equation4130 Fin8 refa4_inst.
Proof. unfold Equation4130. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa4_inst, refa4_op in H. discriminate H. Qed.

Lemma refa4_not4131 : ~ @Equation4131 Fin8 refa4_inst.
Proof. unfold Equation4131. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa4_inst, refa4_op in H. discriminate H. Qed.

Lemma refa4_not4154 : ~ @Equation4154 Fin8 refa4_inst.
Proof. unfold Equation4154. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa4_inst, refa4_op in H. discriminate H. Qed.

Lemma refa4_not4155 : ~ @Equation4155 Fin8 refa4_inst.
Proof. unfold Equation4155. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa4_inst, refa4_op in H. discriminate H. Qed.

Lemma refa4_not4158 : ~ @Equation4158 Fin8 refa4_inst.
Proof. unfold Equation4158. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa4_inst, refa4_op in H. discriminate H. Qed.

Lemma refa4_not4164 : ~ @Equation4164 Fin8 refa4_inst.
Proof. unfold Equation4164. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa4_inst, refa4_op in H. discriminate H. Qed.

Lemma refa4_not4165 : ~ @Equation4165 Fin8 refa4_inst.
Proof. unfold Equation4165. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa4_inst, refa4_op in H. discriminate H. Qed.

Lemma refa4_not4167 : ~ @Equation4167 Fin8 refa4_inst.
Proof. unfold Equation4167. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa4_inst, refa4_op in H. discriminate H. Qed.

Lemma refa4_not4268 : ~ @Equation4268 Fin8 refa4_inst.
Proof. unfold Equation4268. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa4_inst, refa4_op in H. discriminate H. Qed.

Lemma refa4_not4269 : ~ @Equation4269 Fin8 refa4_inst.
Proof. unfold Equation4269. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa4_inst, refa4_op in H. discriminate H. Qed.

Lemma refa4_not4270 : ~ @Equation4270 Fin8 refa4_inst.
Proof. unfold Equation4270. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa4_inst, refa4_op in H. discriminate H. Qed.

Lemma refa4_not4272 : ~ @Equation4272 Fin8 refa4_inst.
Proof. unfold Equation4272. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa4_inst, refa4_op in H. discriminate H. Qed.

Lemma refa4_not4273 : ~ @Equation4273 Fin8 refa4_inst.
Proof. unfold Equation4273. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa4_inst, refa4_op in H. discriminate H. Qed.

Lemma refa4_not4275 : ~ @Equation4275 Fin8 refa4_inst.
Proof. unfold Equation4275. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa4_inst, refa4_op in H. discriminate H. Qed.

Lemma refa4_not4276 : ~ @Equation4276 Fin8 refa4_inst.
Proof. unfold Equation4276. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa4_inst, refa4_op in H. discriminate H. Qed.

Lemma refa4_not4283 : ~ @Equation4283 Fin8 refa4_inst.
Proof. unfold Equation4283. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa4_inst, refa4_op in H. discriminate H. Qed.

Lemma refa4_not4284 : ~ @Equation4284 Fin8 refa4_inst.
Proof. unfold Equation4284. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa4_inst, refa4_op in H. discriminate H. Qed.

Lemma refa4_not4290 : ~ @Equation4290 Fin8 refa4_inst.
Proof. unfold Equation4290. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa4_inst, refa4_op in H. discriminate H. Qed.

Lemma refa4_not4291 : ~ @Equation4291 Fin8 refa4_inst.
Proof. unfold Equation4291. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa4_inst, refa4_op in H. discriminate H. Qed.

Lemma refa4_not4293 : ~ @Equation4293 Fin8 refa4_inst.
Proof. unfold Equation4293. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa4_inst, refa4_op in H. discriminate H. Qed.

Lemma refa4_not4314 : ~ @Equation4314 Fin8 refa4_inst.
Proof. unfold Equation4314. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa4_inst, refa4_op in H. discriminate H. Qed.

Lemma refa4_not4320 : ~ @Equation4320 Fin8 refa4_inst.
Proof. unfold Equation4320. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa4_inst, refa4_op in H. discriminate H. Qed.

Lemma refa4_not4321 : ~ @Equation4321 Fin8 refa4_inst.
Proof. unfold Equation4321. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa4_inst, refa4_op in H. discriminate H. Qed.

Lemma refa4_not4343 : ~ @Equation4343 Fin8 refa4_inst.
Proof. unfold Equation4343. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa4_inst, refa4_op in H. discriminate H. Qed.

Lemma refa4_not4396 : ~ @Equation4396 Fin8 refa4_inst.
Proof. unfold Equation4396. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa4_inst, refa4_op in H. discriminate H. Qed.

Lemma refa4_not4398 : ~ @Equation4398 Fin8 refa4_inst.
Proof. unfold Equation4398. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa4_inst, refa4_op in H. discriminate H. Qed.

Lemma refa4_not4405 : ~ @Equation4405 Fin8 refa4_inst.
Proof. unfold Equation4405. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa4_inst, refa4_op in H. discriminate H. Qed.

Lemma refa4_not4406 : ~ @Equation4406 Fin8 refa4_inst.
Proof. unfold Equation4406. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa4_inst, refa4_op in H. discriminate H. Qed.

Lemma refa4_not4408 : ~ @Equation4408 Fin8 refa4_inst.
Proof. unfold Equation4408. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa4_inst, refa4_op in H. discriminate H. Qed.

Lemma refa4_not4433 : ~ @Equation4433 Fin8 refa4_inst.
Proof. unfold Equation4433. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa4_inst, refa4_op in H. discriminate H. Qed.

Lemma refa4_not4436 : ~ @Equation4436 Fin8 refa4_inst.
Proof. unfold Equation4436. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa4_inst, refa4_op in H. discriminate H. Qed.

Lemma refa4_not4442 : ~ @Equation4442 Fin8 refa4_inst.
Proof. unfold Equation4442. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa4_inst, refa4_op in H. discriminate H. Qed.

Lemma refa4_not4443 : ~ @Equation4443 Fin8 refa4_inst.
Proof. unfold Equation4443. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa4_inst, refa4_op in H. discriminate H. Qed.

Lemma refa4_not4445 : ~ @Equation4445 Fin8 refa4_inst.
Proof. unfold Equation4445. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa4_inst, refa4_op in H. discriminate H. Qed.

Lemma refa4_not4472 : ~ @Equation4472 Fin8 refa4_inst.
Proof. unfold Equation4472. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa4_inst, refa4_op in H. discriminate H. Qed.

Lemma refa4_not4473 : ~ @Equation4473 Fin8 refa4_inst.
Proof. unfold Equation4473. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa4_inst, refa4_op in H. discriminate H. Qed.

Lemma refa4_not4479 : ~ @Equation4479 Fin8 refa4_inst.
Proof. unfold Equation4479. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa4_inst, refa4_op in H. discriminate H. Qed.

Lemma refa4_not4480 : ~ @Equation4480 Fin8 refa4_inst.
Proof. unfold Equation4480. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa4_inst, refa4_op in H. discriminate H. Qed.

Lemma refa4_not4482 : ~ @Equation4482 Fin8 refa4_inst.
Proof. unfold Equation4482. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa4_inst, refa4_op in H. discriminate H. Qed.

Lemma refa4_not4583 : ~ @Equation4583 Fin8 refa4_inst.
Proof. unfold Equation4583. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa4_inst, refa4_op in H. discriminate H. Qed.

Lemma refa4_not4584 : ~ @Equation4584 Fin8 refa4_inst.
Proof. unfold Equation4584. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa4_inst, refa4_op in H. discriminate H. Qed.

Lemma refa4_not4585 : ~ @Equation4585 Fin8 refa4_inst.
Proof. unfold Equation4585. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa4_inst, refa4_op in H. discriminate H. Qed.

Lemma refa4_not4587 : ~ @Equation4587 Fin8 refa4_inst.
Proof. unfold Equation4587. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa4_inst, refa4_op in H. discriminate H. Qed.

Lemma refa4_not4588 : ~ @Equation4588 Fin8 refa4_inst.
Proof. unfold Equation4588. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa4_inst, refa4_op in H. discriminate H. Qed.

Lemma refa4_not4590 : ~ @Equation4590 Fin8 refa4_inst.
Proof. unfold Equation4590. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa4_inst, refa4_op in H. discriminate H. Qed.

Lemma refa4_not4591 : ~ @Equation4591 Fin8 refa4_inst.
Proof. unfold Equation4591. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa4_inst, refa4_op in H. discriminate H. Qed.

Lemma refa4_not4598 : ~ @Equation4598 Fin8 refa4_inst.
Proof. unfold Equation4598. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa4_inst, refa4_op in H. discriminate H. Qed.

Lemma refa4_not4599 : ~ @Equation4599 Fin8 refa4_inst.
Proof. unfold Equation4599. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa4_inst, refa4_op in H. discriminate H. Qed.

Lemma refa4_not4605 : ~ @Equation4605 Fin8 refa4_inst.
Proof. unfold Equation4605. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa4_inst, refa4_op in H. discriminate H. Qed.

Lemma refa4_not4606 : ~ @Equation4606 Fin8 refa4_inst.
Proof. unfold Equation4606. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa4_inst, refa4_op in H. discriminate H. Qed.

Lemma refa4_not4608 : ~ @Equation4608 Fin8 refa4_inst.
Proof. unfold Equation4608. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa4_inst, refa4_op in H. discriminate H. Qed.

Lemma refa4_not4629 : ~ @Equation4629 Fin8 refa4_inst.
Proof. unfold Equation4629. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa4_inst, refa4_op in H. discriminate H. Qed.

Lemma refa4_not4635 : ~ @Equation4635 Fin8 refa4_inst.
Proof. unfold Equation4635. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa4_inst, refa4_op in H. discriminate H. Qed.

Lemma refa4_not4636 : ~ @Equation4636 Fin8 refa4_inst.
Proof. unfold Equation4636. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa4_inst, refa4_op in H. discriminate H. Qed.

Lemma refa4_not4658 : ~ @Equation4658 Fin8 refa4_inst.
Proof. unfold Equation4658. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa4_inst, refa4_op in H. discriminate H. Qed.

(** ---- refa40 (Fin8) ---- *)

Definition refa40_op (x y : Fin8) : Fin8 :=
  match x, y with
  | F8_0, F8_0 => F8_1 | F8_0, F8_1 => F8_4 | F8_0, F8_2 => F8_2 | F8_0, F8_3 => F8_2 | F8_0, F8_4 => F8_1 | F8_0, F8_5 => F8_6 | F8_0, F8_6 => F8_0 | F8_0, F8_7 => F8_0
  | F8_1, F8_0 => F8_2 | F8_1, F8_1 => F8_3 | F8_1, F8_2 => F8_2 | F8_1, F8_3 => F8_4 | F8_1, F8_4 => F8_3 | F8_1, F8_5 => F8_6 | F8_1, F8_6 => F8_1 | F8_1, F8_7 => F8_1
  | F8_2, F8_0 => F8_2 | F8_2, F8_1 => F8_2 | F8_2, F8_2 => F8_2 | F8_2, F8_3 => F8_2 | F8_2, F8_4 => F8_2 | F8_2, F8_5 => F8_2 | F8_2, F8_6 => F8_2 | F8_2, F8_7 => F8_2
  | F8_3, F8_0 => F8_4 | F8_3, F8_1 => F8_2 | F8_3, F8_2 => F8_2 | F8_3, F8_3 => F8_0 | F8_3, F8_4 => F8_0 | F8_3, F8_5 => F8_6 | F8_3, F8_6 => F8_3 | F8_3, F8_7 => F8_3
  | F8_4, F8_0 => F8_0 | F8_4, F8_1 => F8_1 | F8_4, F8_2 => F8_2 | F8_4, F8_3 => F8_3 | F8_4, F8_4 => F8_5 | F8_4, F8_5 => F8_6 | F8_4, F8_6 => F8_5 | F8_4, F8_7 => F8_6
  | F8_5, F8_0 => F8_4 | F8_5, F8_1 => F8_4 | F8_5, F8_2 => F8_2 | F8_5, F8_3 => F8_4 | F8_5, F8_4 => F8_6 | F8_5, F8_5 => F8_4 | F8_5, F8_6 => F8_4 | F8_5, F8_7 => F8_6
  | F8_6, F8_0 => F8_1 | F8_6, F8_1 => F8_3 | F8_6, F8_2 => F8_2 | F8_6, F8_3 => F8_0 | F8_6, F8_4 => F8_5 | F8_6, F8_5 => F8_4 | F8_6, F8_6 => F8_7 | F8_6, F8_7 => F8_6
  | F8_7, F8_0 => F8_1 | F8_7, F8_1 => F8_3 | F8_7, F8_2 => F8_2 | F8_7, F8_3 => F8_0 | F8_7, F8_4 => F8_6 | F8_7, F8_5 => F8_6 | F8_7, F8_6 => F8_6 | F8_7, F8_7 => F8_6
  end.

#[local] Instance refa40_inst : Magma Fin8 := {| magma_op := refa40_op |}.

Lemma refa40_sat3352 : @Equation3352 Fin8 refa40_inst.
Proof. unfold Equation3352, magma_op, refa40_inst, refa40_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa40_not4065 : ~ @Equation4065 Fin8 refa40_inst.
Proof. unfold Equation4065. intro H. specialize (H F8_0). unfold magma_op, refa40_inst, refa40_op in H. discriminate H. Qed.

Lemma refa40_not4380 : ~ @Equation4380 Fin8 refa40_inst.
Proof. unfold Equation4380. intro H. specialize (H F8_0). unfold magma_op, refa40_inst, refa40_op in H. discriminate H. Qed.

(** ---- refa400 (Fin4) ---- *)

Definition refa400_op (x y : Fin4) : Fin4 :=
  match x, y with
  | F4_0, F4_0 => F4_1 | F4_0, F4_1 => F4_0 | F4_0, F4_2 => F4_2 | F4_0, F4_3 => F4_3
  | F4_1, F4_0 => F4_1 | F4_1, F4_1 => F4_0 | F4_1, F4_2 => F4_3 | F4_1, F4_3 => F4_2
  | F4_2, F4_0 => F4_0 | F4_2, F4_1 => F4_1 | F4_2, F4_2 => F4_2 | F4_2, F4_3 => F4_3
  | F4_3, F4_0 => F4_2 | F4_3, F4_1 => F4_1 | F4_3, F4_2 => F4_0 | F4_3, F4_3 => F4_3
  end.

#[local] Instance refa400_inst : Magma Fin4 := {| magma_op := refa400_op |}.

Lemma refa400_sat2100 : @Equation2100 Fin4 refa400_inst.
Proof. unfold Equation2100, magma_op, refa400_inst, refa400_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa400_not2043 : ~ @Equation2043 Fin4 refa400_inst.
Proof. unfold Equation2043. intro H. specialize (H F4_0 F4_2). unfold magma_op, refa400_inst, refa400_op in H. discriminate H. Qed.

(** ---- refa401 (Fin4) ---- *)

Definition refa401_op (x y : Fin4) : Fin4 :=
  match x, y with
  | F4_0, F4_0 => F4_0 | F4_0, F4_1 => F4_3 | F4_0, F4_2 => F4_3 | F4_0, F4_3 => F4_3
  | F4_1, F4_0 => F4_3 | F4_1, F4_1 => F4_1 | F4_1, F4_2 => F4_2 | F4_1, F4_3 => F4_2
  | F4_2, F4_0 => F4_3 | F4_2, F4_1 => F4_1 | F4_2, F4_2 => F4_2 | F4_2, F4_3 => F4_3
  | F4_3, F4_0 => F4_0 | F4_3, F4_1 => F4_1 | F4_3, F4_2 => F4_2 | F4_3, F4_3 => F4_3
  end.

#[local] Instance refa401_inst : Magma Fin4 := {| magma_op := refa401_op |}.

Lemma refa401_sat2513 : @Equation2513 Fin4 refa401_inst.
Proof. unfold Equation2513, magma_op, refa401_inst, refa401_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa401_sat2716 : @Equation2716 Fin4 refa401_inst.
Proof. unfold Equation2716, magma_op, refa401_inst, refa401_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa401_not385 : ~ @Equation385 Fin4 refa401_inst.
Proof. unfold Equation385. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa401_inst, refa401_op in H. discriminate H. Qed.

Lemma refa401_not1045 : ~ @Equation1045 Fin4 refa401_inst.
Proof. unfold Equation1045. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa401_inst, refa401_op in H. discriminate H. Qed.

Lemma refa401_not1921 : ~ @Equation1921 Fin4 refa401_inst.
Proof. unfold Equation1921. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa401_inst, refa401_op in H. discriminate H. Qed.

Lemma refa401_not2300 : ~ @Equation2300 Fin4 refa401_inst.
Proof. unfold Equation2300. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa401_inst, refa401_op in H. discriminate H. Qed.

Lemma refa401_not2327 : ~ @Equation2327 Fin4 refa401_inst.
Proof. unfold Equation2327. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa401_inst, refa401_op in H. discriminate H. Qed.

Lemma refa401_not2337 : ~ @Equation2337 Fin4 refa401_inst.
Proof. unfold Equation2337. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa401_inst, refa401_op in H. discriminate H. Qed.

Lemma refa401_not2540 : ~ @Equation2540 Fin4 refa401_inst.
Proof. unfold Equation2540. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa401_inst, refa401_op in H. discriminate H. Qed.

Lemma refa401_not2743 : ~ @Equation2743 Fin4 refa401_inst.
Proof. unfold Equation2743. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa401_inst, refa401_op in H. discriminate H. Qed.

Lemma refa401_not3306 : ~ @Equation3306 Fin4 refa401_inst.
Proof. unfold Equation3306. intro H. specialize (H F4_1 F4_0). unfold magma_op, refa401_inst, refa401_op in H. discriminate H. Qed.

Lemma refa401_not3346 : ~ @Equation3346 Fin4 refa401_inst.
Proof. unfold Equation3346. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa401_inst, refa401_op in H. discriminate H. Qed.

Lemma refa401_not3353 : ~ @Equation3353 Fin4 refa401_inst.
Proof. unfold Equation3353. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa401_inst, refa401_op in H. discriminate H. Qed.

Lemma refa401_not3546 : ~ @Equation3546 Fin4 refa401_inst.
Proof. unfold Equation3546. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa401_inst, refa401_op in H. discriminate H. Qed.

Lemma refa401_not3759 : ~ @Equation3759 Fin4 refa401_inst.
Proof. unfold Equation3759. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa401_inst, refa401_op in H. discriminate H. Qed.

Lemma refa401_not3887 : ~ @Equation3887 Fin4 refa401_inst.
Proof. unfold Equation3887. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa401_inst, refa401_op in H. discriminate H. Qed.

Lemma refa401_not4320 : ~ @Equation4320 Fin4 refa401_inst.
Proof. unfold Equation4320. intro H. specialize (H F4_1 F4_0). unfold magma_op, refa401_inst, refa401_op in H. discriminate H. Qed.

Lemma refa401_not4445 : ~ @Equation4445 Fin4 refa401_inst.
Proof. unfold Equation4445. intro H. specialize (H F4_1 F4_0). unfold magma_op, refa401_inst, refa401_op in H. discriminate H. Qed.

(** ---- refa402 (Fin4) ---- *)

Definition refa402_op (x y : Fin4) : Fin4 :=
  match x, y with
  | F4_0, F4_0 => F4_3 | F4_0, F4_1 => F4_1 | F4_0, F4_2 => F4_3 | F4_0, F4_3 => F4_1
  | F4_1, F4_0 => F4_2 | F4_1, F4_1 => F4_3 | F4_1, F4_2 => F4_2 | F4_1, F4_3 => F4_3
  | F4_2, F4_0 => F4_2 | F4_2, F4_1 => F4_1 | F4_2, F4_2 => F4_2 | F4_2, F4_3 => F4_1
  | F4_3, F4_0 => F4_2 | F4_3, F4_1 => F4_3 | F4_3, F4_2 => F4_2 | F4_3, F4_3 => F4_3
  end.

#[local] Instance refa402_inst : Magma Fin4 := {| magma_op := refa402_op |}.

Lemma refa402_sat3541 : @Equation3541 Fin4 refa402_inst.
Proof. unfold Equation3541, magma_op, refa402_inst, refa402_op. intros x y z w. destruct x, y, z, w; reflexivity. Qed.

Lemma refa402_not3253 : ~ @Equation3253 Fin4 refa402_inst.
Proof. unfold Equation3253. intro H. specialize (H F4_0). unfold magma_op, refa402_inst, refa402_op in H. discriminate H. Qed.

Lemma refa402_not3664 : ~ @Equation3664 Fin4 refa402_inst.
Proof. unfold Equation3664. intro H. specialize (H F4_1 F4_0). unfold magma_op, refa402_inst, refa402_op in H. discriminate H. Qed.

Lemma refa402_not3712 : ~ @Equation3712 Fin4 refa402_inst.
Proof. unfold Equation3712. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa402_inst, refa402_op in H. discriminate H. Qed.

Lemma refa402_not3722 : ~ @Equation3722 Fin4 refa402_inst.
Proof. unfold Equation3722. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa402_inst, refa402_op in H. discriminate H. Qed.

Lemma refa402_not4380 : ~ @Equation4380 Fin4 refa402_inst.
Proof. unfold Equation4380. intro H. specialize (H F4_0). unfold magma_op, refa402_inst, refa402_op in H. discriminate H. Qed.

Lemma refa402_not4599 : ~ @Equation4599 Fin4 refa402_inst.
Proof. unfold Equation4599. intro H. specialize (H F4_2 F4_1). unfold magma_op, refa402_inst, refa402_op in H. discriminate H. Qed.

Lemma refa402_not4631 : ~ @Equation4631 Fin4 refa402_inst.
Proof. unfold Equation4631. intro H. specialize (H F4_1 F4_0 F4_1). unfold magma_op, refa402_inst, refa402_op in H. discriminate H. Qed.

(** ---- refa403 (Fin4) ---- *)

Definition refa403_op (x y : Fin4) : Fin4 :=
  match x, y with
  | F4_0, F4_0 => F4_0 | F4_0, F4_1 => F4_1 | F4_0, F4_2 => F4_3 | F4_0, F4_3 => F4_1
  | F4_1, F4_0 => F4_3 | F4_1, F4_1 => F4_2 | F4_1, F4_2 => F4_3 | F4_1, F4_3 => F4_1
  | F4_2, F4_0 => F4_2 | F4_2, F4_1 => F4_0 | F4_2, F4_2 => F4_1 | F4_2, F4_3 => F4_0
  | F4_3, F4_0 => F4_2 | F4_3, F4_1 => F4_0 | F4_3, F4_2 => F4_2 | F4_3, F4_3 => F4_3
  end.

#[local] Instance refa403_inst : Magma Fin4 := {| magma_op := refa403_op |}.

Lemma refa403_sat167 : @Equation167 Fin4 refa403_inst.
Proof. unfold Equation167, magma_op, refa403_inst, refa403_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa403_not56 : ~ @Equation56 Fin4 refa403_inst.
Proof. unfold Equation56. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa403_inst, refa403_op in H. discriminate H. Qed.

Lemma refa403_not65 : ~ @Equation65 Fin4 refa403_inst.
Proof. unfold Equation65. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa403_inst, refa403_op in H. discriminate H. Qed.

Lemma refa403_not66 : ~ @Equation66 Fin4 refa403_inst.
Proof. unfold Equation66. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa403_inst, refa403_op in H. discriminate H. Qed.

Lemma refa403_not73 : ~ @Equation73 Fin4 refa403_inst.
Proof. unfold Equation73. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa403_inst, refa403_op in H. discriminate H. Qed.

Lemma refa403_not75 : ~ @Equation75 Fin4 refa403_inst.
Proof. unfold Equation75. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa403_inst, refa403_op in H. discriminate H. Qed.

Lemma refa403_not99 : ~ @Equation99 Fin4 refa403_inst.
Proof. unfold Equation99. intro H. specialize (H F4_1). unfold magma_op, refa403_inst, refa403_op in H. discriminate H. Qed.

Lemma refa403_not159 : ~ @Equation159 Fin4 refa403_inst.
Proof. unfold Equation159. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa403_inst, refa403_op in H. discriminate H. Qed.

Lemma refa403_not203 : ~ @Equation203 Fin4 refa403_inst.
Proof. unfold Equation203. intro H. specialize (H F4_1). unfold magma_op, refa403_inst, refa403_op in H. discriminate H. Qed.

Lemma refa403_not261 : ~ @Equation261 Fin4 refa403_inst.
Proof. unfold Equation261. intro H. specialize (H F4_0 F4_2). unfold magma_op, refa403_inst, refa403_op in H. discriminate H. Qed.

Lemma refa403_not264 : ~ @Equation264 Fin4 refa403_inst.
Proof. unfold Equation264. intro H. specialize (H F4_0 F4_2). unfold magma_op, refa403_inst, refa403_op in H. discriminate H. Qed.

Lemma refa403_not274 : ~ @Equation274 Fin4 refa403_inst.
Proof. unfold Equation274. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa403_inst, refa403_op in H. discriminate H. Qed.

Lemma refa403_not283 : ~ @Equation283 Fin4 refa403_inst.
Proof. unfold Equation283. intro H. specialize (H F4_0 F4_2). unfold magma_op, refa403_inst, refa403_op in H. discriminate H. Qed.

Lemma refa403_not411 : ~ @Equation411 Fin4 refa403_inst.
Proof. unfold Equation411. intro H. specialize (H F4_1). unfold magma_op, refa403_inst, refa403_op in H. discriminate H. Qed.

Lemma refa403_not615 : ~ @Equation615 Fin4 refa403_inst.
Proof. unfold Equation615. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa403_inst, refa403_op in H. discriminate H. Qed.

Lemma refa403_not616 : ~ @Equation616 Fin4 refa403_inst.
Proof. unfold Equation616. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa403_inst, refa403_op in H. discriminate H. Qed.

Lemma refa403_not619 : ~ @Equation619 Fin4 refa403_inst.
Proof. unfold Equation619. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa403_inst, refa403_op in H. discriminate H. Qed.

Lemma refa403_not620 : ~ @Equation620 Fin4 refa403_inst.
Proof. unfold Equation620. intro H. specialize (H F4_0 F4_2). unfold magma_op, refa403_inst, refa403_op in H. discriminate H. Qed.

Lemma refa403_not622 : ~ @Equation622 Fin4 refa403_inst.
Proof. unfold Equation622. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa403_inst, refa403_op in H. discriminate H. Qed.

Lemma refa403_not623 : ~ @Equation623 Fin4 refa403_inst.
Proof. unfold Equation623. intro H. specialize (H F4_0 F4_2). unfold magma_op, refa403_inst, refa403_op in H. discriminate H. Qed.

Lemma refa403_not629 : ~ @Equation629 Fin4 refa403_inst.
Proof. unfold Equation629. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa403_inst, refa403_op in H. discriminate H. Qed.

Lemma refa403_not630 : ~ @Equation630 Fin4 refa403_inst.
Proof. unfold Equation630. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa403_inst, refa403_op in H. discriminate H. Qed.

Lemma refa403_not632 : ~ @Equation632 Fin4 refa403_inst.
Proof. unfold Equation632. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa403_inst, refa403_op in H. discriminate H. Qed.

Lemma refa403_not633 : ~ @Equation633 Fin4 refa403_inst.
Proof. unfold Equation633. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa403_inst, refa403_op in H. discriminate H. Qed.

Lemma refa403_not639 : ~ @Equation639 Fin4 refa403_inst.
Proof. unfold Equation639. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa403_inst, refa403_op in H. discriminate H. Qed.

Lemma refa403_not640 : ~ @Equation640 Fin4 refa403_inst.
Proof. unfold Equation640. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa403_inst, refa403_op in H. discriminate H. Qed.

Lemma refa403_not642 : ~ @Equation642 Fin4 refa403_inst.
Proof. unfold Equation642. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa403_inst, refa403_op in H. discriminate H. Qed.

Lemma refa403_not643 : ~ @Equation643 Fin4 refa403_inst.
Proof. unfold Equation643. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa403_inst, refa403_op in H. discriminate H. Qed.

Lemma refa403_not667 : ~ @Equation667 Fin4 refa403_inst.
Proof. unfold Equation667. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa403_inst, refa403_op in H. discriminate H. Qed.

Lemma refa403_not669 : ~ @Equation669 Fin4 refa403_inst.
Proof. unfold Equation669. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa403_inst, refa403_op in H. discriminate H. Qed.

Lemma refa403_not670 : ~ @Equation670 Fin4 refa403_inst.
Proof. unfold Equation670. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa403_inst, refa403_op in H. discriminate H. Qed.

Lemma refa403_not676 : ~ @Equation676 Fin4 refa403_inst.
Proof. unfold Equation676. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa403_inst, refa403_op in H. discriminate H. Qed.

Lemma refa403_not677 : ~ @Equation677 Fin4 refa403_inst.
Proof. unfold Equation677. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa403_inst, refa403_op in H. discriminate H. Qed.

Lemma refa403_not679 : ~ @Equation679 Fin4 refa403_inst.
Proof. unfold Equation679. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa403_inst, refa403_op in H. discriminate H. Qed.

Lemma refa403_not680 : ~ @Equation680 Fin4 refa403_inst.
Proof. unfold Equation680. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa403_inst, refa403_op in H. discriminate H. Qed.

Lemma refa403_not704 : ~ @Equation704 Fin4 refa403_inst.
Proof. unfold Equation704. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa403_inst, refa403_op in H. discriminate H. Qed.

Lemma refa403_not706 : ~ @Equation706 Fin4 refa403_inst.
Proof. unfold Equation706. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa403_inst, refa403_op in H. discriminate H. Qed.

Lemma refa403_not707 : ~ @Equation707 Fin4 refa403_inst.
Proof. unfold Equation707. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa403_inst, refa403_op in H. discriminate H. Qed.

Lemma refa403_not713 : ~ @Equation713 Fin4 refa403_inst.
Proof. unfold Equation713. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa403_inst, refa403_op in H. discriminate H. Qed.

Lemma refa403_not817 : ~ @Equation817 Fin4 refa403_inst.
Proof. unfold Equation817. intro H. specialize (H F4_1). unfold magma_op, refa403_inst, refa403_op in H. discriminate H. Qed.

Lemma refa403_not1020 : ~ @Equation1020 Fin4 refa403_inst.
Proof. unfold Equation1020. intro H. specialize (H F4_1). unfold magma_op, refa403_inst, refa403_op in H. discriminate H. Qed.

Lemma refa403_not1223 : ~ @Equation1223 Fin4 refa403_inst.
Proof. unfold Equation1223. intro H. specialize (H F4_1). unfold magma_op, refa403_inst, refa403_op in H. discriminate H. Qed.

Lemma refa403_not1426 : ~ @Equation1426 Fin4 refa403_inst.
Proof. unfold Equation1426. intro H. specialize (H F4_1). unfold magma_op, refa403_inst, refa403_op in H. discriminate H. Qed.

Lemma refa403_not1629 : ~ @Equation1629 Fin4 refa403_inst.
Proof. unfold Equation1629. intro H. specialize (H F4_1). unfold magma_op, refa403_inst, refa403_op in H. discriminate H. Qed.

Lemma refa403_not1832 : ~ @Equation1832 Fin4 refa403_inst.
Proof. unfold Equation1832. intro H. specialize (H F4_1). unfold magma_op, refa403_inst, refa403_op in H. discriminate H. Qed.

Lemma refa403_not2035 : ~ @Equation2035 Fin4 refa403_inst.
Proof. unfold Equation2035. intro H. specialize (H F4_1). unfold magma_op, refa403_inst, refa403_op in H. discriminate H. Qed.

Lemma refa403_not2238 : ~ @Equation2238 Fin4 refa403_inst.
Proof. unfold Equation2238. intro H. specialize (H F4_1). unfold magma_op, refa403_inst, refa403_op in H. discriminate H. Qed.

Lemma refa403_not2441 : ~ @Equation2441 Fin4 refa403_inst.
Proof. unfold Equation2441. intro H. specialize (H F4_1). unfold magma_op, refa403_inst, refa403_op in H. discriminate H. Qed.

Lemma refa403_not2644 : ~ @Equation2644 Fin4 refa403_inst.
Proof. unfold Equation2644. intro H. specialize (H F4_1). unfold magma_op, refa403_inst, refa403_op in H. discriminate H. Qed.

Lemma refa403_not2849 : ~ @Equation2849 Fin4 refa403_inst.
Proof. unfold Equation2849. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa403_inst, refa403_op in H. discriminate H. Qed.

Lemma refa403_not2852 : ~ @Equation2852 Fin4 refa403_inst.
Proof. unfold Equation2852. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa403_inst, refa403_op in H. discriminate H. Qed.

Lemma refa403_not2853 : ~ @Equation2853 Fin4 refa403_inst.
Proof. unfold Equation2853. intro H. specialize (H F4_0 F4_2). unfold magma_op, refa403_inst, refa403_op in H. discriminate H. Qed.

Lemma refa403_not2855 : ~ @Equation2855 Fin4 refa403_inst.
Proof. unfold Equation2855. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa403_inst, refa403_op in H. discriminate H. Qed.

Lemma refa403_not2856 : ~ @Equation2856 Fin4 refa403_inst.
Proof. unfold Equation2856. intro H. specialize (H F4_0 F4_2). unfold magma_op, refa403_inst, refa403_op in H. discriminate H. Qed.

Lemma refa403_not2862 : ~ @Equation2862 Fin4 refa403_inst.
Proof. unfold Equation2862. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa403_inst, refa403_op in H. discriminate H. Qed.

Lemma refa403_not2863 : ~ @Equation2863 Fin4 refa403_inst.
Proof. unfold Equation2863. intro H. specialize (H F4_0 F4_2). unfold magma_op, refa403_inst, refa403_op in H. discriminate H. Qed.

Lemma refa403_not2865 : ~ @Equation2865 Fin4 refa403_inst.
Proof. unfold Equation2865. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa403_inst, refa403_op in H. discriminate H. Qed.

Lemma refa403_not2866 : ~ @Equation2866 Fin4 refa403_inst.
Proof. unfold Equation2866. intro H. specialize (H F4_0 F4_2). unfold magma_op, refa403_inst, refa403_op in H. discriminate H. Qed.

Lemma refa403_not2872 : ~ @Equation2872 Fin4 refa403_inst.
Proof. unfold Equation2872. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa403_inst, refa403_op in H. discriminate H. Qed.

Lemma refa403_not2873 : ~ @Equation2873 Fin4 refa403_inst.
Proof. unfold Equation2873. intro H. specialize (H F4_0 F4_2). unfold magma_op, refa403_inst, refa403_op in H. discriminate H. Qed.

Lemma refa403_not2875 : ~ @Equation2875 Fin4 refa403_inst.
Proof. unfold Equation2875. intro H. specialize (H F4_0 F4_2). unfold magma_op, refa403_inst, refa403_op in H. discriminate H. Qed.

Lemma refa403_not2899 : ~ @Equation2899 Fin4 refa403_inst.
Proof. unfold Equation2899. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa403_inst, refa403_op in H. discriminate H. Qed.

Lemma refa403_not2900 : ~ @Equation2900 Fin4 refa403_inst.
Proof. unfold Equation2900. intro H. specialize (H F4_0 F4_2). unfold magma_op, refa403_inst, refa403_op in H. discriminate H. Qed.

Lemma refa403_not2902 : ~ @Equation2902 Fin4 refa403_inst.
Proof. unfold Equation2902. intro H. specialize (H F4_0 F4_2). unfold magma_op, refa403_inst, refa403_op in H. discriminate H. Qed.

Lemma refa403_not2903 : ~ @Equation2903 Fin4 refa403_inst.
Proof. unfold Equation2903. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa403_inst, refa403_op in H. discriminate H. Qed.

Lemma refa403_not2909 : ~ @Equation2909 Fin4 refa403_inst.
Proof. unfold Equation2909. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa403_inst, refa403_op in H. discriminate H. Qed.

Lemma refa403_not2910 : ~ @Equation2910 Fin4 refa403_inst.
Proof. unfold Equation2910. intro H. specialize (H F4_0 F4_2). unfold magma_op, refa403_inst, refa403_op in H. discriminate H. Qed.

Lemma refa403_not2912 : ~ @Equation2912 Fin4 refa403_inst.
Proof. unfold Equation2912. intro H. specialize (H F4_0 F4_2). unfold magma_op, refa403_inst, refa403_op in H. discriminate H. Qed.

Lemma refa403_not2937 : ~ @Equation2937 Fin4 refa403_inst.
Proof. unfold Equation2937. intro H. specialize (H F4_0 F4_2). unfold magma_op, refa403_inst, refa403_op in H. discriminate H. Qed.

Lemma refa403_not2939 : ~ @Equation2939 Fin4 refa403_inst.
Proof. unfold Equation2939. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa403_inst, refa403_op in H. discriminate H. Qed.

Lemma refa403_not2940 : ~ @Equation2940 Fin4 refa403_inst.
Proof. unfold Equation2940. intro H. specialize (H F4_0 F4_2). unfold magma_op, refa403_inst, refa403_op in H. discriminate H. Qed.

Lemma refa403_not2946 : ~ @Equation2946 Fin4 refa403_inst.
Proof. unfold Equation2946. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa403_inst, refa403_op in H. discriminate H. Qed.

Lemma refa403_not2947 : ~ @Equation2947 Fin4 refa403_inst.
Proof. unfold Equation2947. intro H. specialize (H F4_0 F4_2). unfold magma_op, refa403_inst, refa403_op in H. discriminate H. Qed.

Lemma refa403_not2949 : ~ @Equation2949 Fin4 refa403_inst.
Proof. unfold Equation2949. intro H. specialize (H F4_0 F4_2). unfold magma_op, refa403_inst, refa403_op in H. discriminate H. Qed.

Lemma refa403_not3050 : ~ @Equation3050 Fin4 refa403_inst.
Proof. unfold Equation3050. intro H. specialize (H F4_1). unfold magma_op, refa403_inst, refa403_op in H. discriminate H. Qed.

Lemma refa403_not3253 : ~ @Equation3253 Fin4 refa403_inst.
Proof. unfold Equation3253. intro H. specialize (H F4_1). unfold magma_op, refa403_inst, refa403_op in H. discriminate H. Qed.

Lemma refa403_not3456 : ~ @Equation3456 Fin4 refa403_inst.
Proof. unfold Equation3456. intro H. specialize (H F4_1). unfold magma_op, refa403_inst, refa403_op in H. discriminate H. Qed.

Lemma refa403_not3659 : ~ @Equation3659 Fin4 refa403_inst.
Proof. unfold Equation3659. intro H. specialize (H F4_1). unfold magma_op, refa403_inst, refa403_op in H. discriminate H. Qed.

Lemma refa403_not3862 : ~ @Equation3862 Fin4 refa403_inst.
Proof. unfold Equation3862. intro H. specialize (H F4_1). unfold magma_op, refa403_inst, refa403_op in H. discriminate H. Qed.

Lemma refa403_not4065 : ~ @Equation4065 Fin4 refa403_inst.
Proof. unfold Equation4065. intro H. specialize (H F4_1). unfold magma_op, refa403_inst, refa403_op in H. discriminate H. Qed.

Lemma refa403_not4268 : ~ @Equation4268 Fin4 refa403_inst.
Proof. unfold Equation4268. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa403_inst, refa403_op in H. discriminate H. Qed.

Lemma refa403_not4269 : ~ @Equation4269 Fin4 refa403_inst.
Proof. unfold Equation4269. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa403_inst, refa403_op in H. discriminate H. Qed.

Lemma refa403_not4270 : ~ @Equation4270 Fin4 refa403_inst.
Proof. unfold Equation4270. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa403_inst, refa403_op in H. discriminate H. Qed.

Lemma refa403_not4272 : ~ @Equation4272 Fin4 refa403_inst.
Proof. unfold Equation4272. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa403_inst, refa403_op in H. discriminate H. Qed.

Lemma refa403_not4273 : ~ @Equation4273 Fin4 refa403_inst.
Proof. unfold Equation4273. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa403_inst, refa403_op in H. discriminate H. Qed.

Lemma refa403_not4275 : ~ @Equation4275 Fin4 refa403_inst.
Proof. unfold Equation4275. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa403_inst, refa403_op in H. discriminate H. Qed.

Lemma refa403_not4276 : ~ @Equation4276 Fin4 refa403_inst.
Proof. unfold Equation4276. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa403_inst, refa403_op in H. discriminate H. Qed.

Lemma refa403_not4283 : ~ @Equation4283 Fin4 refa403_inst.
Proof. unfold Equation4283. intro H. specialize (H F4_0 F4_2). unfold magma_op, refa403_inst, refa403_op in H. discriminate H. Qed.

Lemma refa403_not4284 : ~ @Equation4284 Fin4 refa403_inst.
Proof. unfold Equation4284. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa403_inst, refa403_op in H. discriminate H. Qed.

Lemma refa403_not4290 : ~ @Equation4290 Fin4 refa403_inst.
Proof. unfold Equation4290. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa403_inst, refa403_op in H. discriminate H. Qed.

Lemma refa403_not4291 : ~ @Equation4291 Fin4 refa403_inst.
Proof. unfold Equation4291. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa403_inst, refa403_op in H. discriminate H. Qed.

Lemma refa403_not4293 : ~ @Equation4293 Fin4 refa403_inst.
Proof. unfold Equation4293. intro H. specialize (H F4_0 F4_3). unfold magma_op, refa403_inst, refa403_op in H. discriminate H. Qed.

Lemma refa403_not4314 : ~ @Equation4314 Fin4 refa403_inst.
Proof. unfold Equation4314. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa403_inst, refa403_op in H. discriminate H. Qed.

Lemma refa403_not4320 : ~ @Equation4320 Fin4 refa403_inst.
Proof. unfold Equation4320. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa403_inst, refa403_op in H. discriminate H. Qed.

Lemma refa403_not4321 : ~ @Equation4321 Fin4 refa403_inst.
Proof. unfold Equation4321. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa403_inst, refa403_op in H. discriminate H. Qed.

Lemma refa403_not4343 : ~ @Equation4343 Fin4 refa403_inst.
Proof. unfold Equation4343. intro H. specialize (H F4_0 F4_2). unfold magma_op, refa403_inst, refa403_op in H. discriminate H. Qed.

Lemma refa403_not4380 : ~ @Equation4380 Fin4 refa403_inst.
Proof. unfold Equation4380. intro H. specialize (H F4_1). unfold magma_op, refa403_inst, refa403_op in H. discriminate H. Qed.

Lemma refa403_not4583 : ~ @Equation4583 Fin4 refa403_inst.
Proof. unfold Equation4583. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa403_inst, refa403_op in H. discriminate H. Qed.

Lemma refa403_not4584 : ~ @Equation4584 Fin4 refa403_inst.
Proof. unfold Equation4584. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa403_inst, refa403_op in H. discriminate H. Qed.

Lemma refa403_not4585 : ~ @Equation4585 Fin4 refa403_inst.
Proof. unfold Equation4585. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa403_inst, refa403_op in H. discriminate H. Qed.

Lemma refa403_not4587 : ~ @Equation4587 Fin4 refa403_inst.
Proof. unfold Equation4587. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa403_inst, refa403_op in H. discriminate H. Qed.

Lemma refa403_not4588 : ~ @Equation4588 Fin4 refa403_inst.
Proof. unfold Equation4588. intro H. specialize (H F4_0 F4_2). unfold magma_op, refa403_inst, refa403_op in H. discriminate H. Qed.

Lemma refa403_not4590 : ~ @Equation4590 Fin4 refa403_inst.
Proof. unfold Equation4590. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa403_inst, refa403_op in H. discriminate H. Qed.

Lemma refa403_not4591 : ~ @Equation4591 Fin4 refa403_inst.
Proof. unfold Equation4591. intro H. specialize (H F4_0 F4_2). unfold magma_op, refa403_inst, refa403_op in H. discriminate H. Qed.

Lemma refa403_not4598 : ~ @Equation4598 Fin4 refa403_inst.
Proof. unfold Equation4598. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa403_inst, refa403_op in H. discriminate H. Qed.

Lemma refa403_not4599 : ~ @Equation4599 Fin4 refa403_inst.
Proof. unfold Equation4599. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa403_inst, refa403_op in H. discriminate H. Qed.

Lemma refa403_not4605 : ~ @Equation4605 Fin4 refa403_inst.
Proof. unfold Equation4605. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa403_inst, refa403_op in H. discriminate H. Qed.

Lemma refa403_not4606 : ~ @Equation4606 Fin4 refa403_inst.
Proof. unfold Equation4606. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa403_inst, refa403_op in H. discriminate H. Qed.

Lemma refa403_not4608 : ~ @Equation4608 Fin4 refa403_inst.
Proof. unfold Equation4608. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa403_inst, refa403_op in H. discriminate H. Qed.

Lemma refa403_not4629 : ~ @Equation4629 Fin4 refa403_inst.
Proof. unfold Equation4629. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa403_inst, refa403_op in H. discriminate H. Qed.

Lemma refa403_not4635 : ~ @Equation4635 Fin4 refa403_inst.
Proof. unfold Equation4635. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa403_inst, refa403_op in H. discriminate H. Qed.

Lemma refa403_not4636 : ~ @Equation4636 Fin4 refa403_inst.
Proof. unfold Equation4636. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa403_inst, refa403_op in H. discriminate H. Qed.

Lemma refa403_not4658 : ~ @Equation4658 Fin4 refa403_inst.
Proof. unfold Equation4658. intro H. specialize (H F4_0 F4_3). unfold magma_op, refa403_inst, refa403_op in H. discriminate H. Qed.

(** ---- refa404 (Fin4) ---- *)

Definition refa404_op (x y : Fin4) : Fin4 :=
  match x, y with
  | F4_0, F4_0 => F4_0 | F4_0, F4_1 => F4_0 | F4_0, F4_2 => F4_3 | F4_0, F4_3 => F4_3
  | F4_1, F4_0 => F4_3 | F4_1, F4_1 => F4_3 | F4_1, F4_2 => F4_2 | F4_1, F4_3 => F4_2
  | F4_2, F4_0 => F4_1 | F4_2, F4_1 => F4_1 | F4_2, F4_2 => F4_2 | F4_2, F4_3 => F4_3
  | F4_3, F4_0 => F4_0 | F4_3, F4_1 => F4_0 | F4_3, F4_2 => F4_2 | F4_3, F4_3 => F4_3
  end.

#[local] Instance refa404_inst : Magma Fin4 := {| magma_op := refa404_op |}.

Lemma refa404_sat2259 : @Equation2259 Fin4 refa404_inst.
Proof. unfold Equation2259, magma_op, refa404_inst, refa404_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa404_not2441 : ~ @Equation2441 Fin4 refa404_inst.
Proof. unfold Equation2441. intro H. specialize (H F4_1). unfold magma_op, refa404_inst, refa404_op in H. discriminate H. Qed.

(** ---- refa405 (Fin4) ---- *)

Definition refa405_op (x y : Fin4) : Fin4 :=
  match x, y with
  | F4_0, F4_0 => F4_3 | F4_0, F4_1 => F4_2 | F4_0, F4_2 => F4_0 | F4_0, F4_3 => F4_1
  | F4_1, F4_0 => F4_3 | F4_1, F4_1 => F4_2 | F4_1, F4_2 => F4_0 | F4_1, F4_3 => F4_1
  | F4_2, F4_0 => F4_2 | F4_2, F4_1 => F4_3 | F4_2, F4_2 => F4_1 | F4_2, F4_3 => F4_0
  | F4_3, F4_0 => F4_2 | F4_3, F4_1 => F4_3 | F4_3, F4_2 => F4_1 | F4_3, F4_3 => F4_0
  end.

#[local] Instance refa405_inst : Magma Fin4 := {| magma_op := refa405_op |}.

Lemma refa405_sat528 : @Equation528 Fin4 refa405_inst.
Proof. unfold Equation528, magma_op, refa405_inst, refa405_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa405_sat562 : @Equation562 Fin4 refa405_inst.
Proof. unfold Equation562, magma_op, refa405_inst, refa405_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa405_sat2182 : @Equation2182 Fin4 refa405_inst.
Proof. unfold Equation2182, magma_op, refa405_inst, refa405_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa405_not107 : ~ @Equation107 Fin4 refa405_inst.
Proof. unfold Equation107. intro H. specialize (H F4_0 F4_2). unfold magma_op, refa405_inst, refa405_op in H. discriminate H. Qed.

Lemma refa405_not413 : ~ @Equation413 Fin4 refa405_inst.
Proof. unfold Equation413. intro H. specialize (H F4_0 F4_2). unfold magma_op, refa405_inst, refa405_op in H. discriminate H. Qed.

Lemma refa405_not416 : ~ @Equation416 Fin4 refa405_inst.
Proof. unfold Equation416. intro H. specialize (H F4_0 F4_2). unfold magma_op, refa405_inst, refa405_op in H. discriminate H. Qed.

Lemma refa405_not417 : ~ @Equation417 Fin4 refa405_inst.
Proof. unfold Equation417. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa405_inst, refa405_op in H. discriminate H. Qed.

Lemma refa405_not426 : ~ @Equation426 Fin4 refa405_inst.
Proof. unfold Equation426. intro H. specialize (H F4_0 F4_2). unfold magma_op, refa405_inst, refa405_op in H. discriminate H. Qed.

Lemma refa405_not440 : ~ @Equation440 Fin4 refa405_inst.
Proof. unfold Equation440. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa405_inst, refa405_op in H. discriminate H. Qed.

Lemma refa405_not476 : ~ @Equation476 Fin4 refa405_inst.
Proof. unfold Equation476. intro H. specialize (H F4_0 F4_2). unfold magma_op, refa405_inst, refa405_op in H. discriminate H. Qed.

Lemma refa405_not477 : ~ @Equation477 Fin4 refa405_inst.
Proof. unfold Equation477. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa405_inst, refa405_op in H. discriminate H. Qed.

Lemma refa405_not503 : ~ @Equation503 Fin4 refa405_inst.
Proof. unfold Equation503. intro H. specialize (H F4_0 F4_2). unfold magma_op, refa405_inst, refa405_op in H. discriminate H. Qed.

Lemma refa405_not504 : ~ @Equation504 Fin4 refa405_inst.
Proof. unfold Equation504. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa405_inst, refa405_op in H. discriminate H. Qed.

Lemma refa405_not511 : ~ @Equation511 Fin4 refa405_inst.
Proof. unfold Equation511. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa405_inst, refa405_op in H. discriminate H. Qed.

Lemma refa405_not614 : ~ @Equation614 Fin4 refa405_inst.
Proof. unfold Equation614. intro H. specialize (H F4_0). unfold magma_op, refa405_inst, refa405_op in H. discriminate H. Qed.

Lemma refa405_not817 : ~ @Equation817 Fin4 refa405_inst.
Proof. unfold Equation817. intro H. specialize (H F4_0). unfold magma_op, refa405_inst, refa405_op in H. discriminate H. Qed.

Lemma refa405_not1020 : ~ @Equation1020 Fin4 refa405_inst.
Proof. unfold Equation1020. intro H. specialize (H F4_0). unfold magma_op, refa405_inst, refa405_op in H. discriminate H. Qed.

Lemma refa405_not1225 : ~ @Equation1225 Fin4 refa405_inst.
Proof. unfold Equation1225. intro H. specialize (H F4_0 F4_2). unfold magma_op, refa405_inst, refa405_op in H. discriminate H. Qed.

Lemma refa405_not1241 : ~ @Equation1241 Fin4 refa405_inst.
Proof. unfold Equation1241. intro H. specialize (H F4_0 F4_2). unfold magma_op, refa405_inst, refa405_op in H. discriminate H. Qed.

Lemma refa405_not1251 : ~ @Equation1251 Fin4 refa405_inst.
Proof. unfold Equation1251. intro H. specialize (H F4_0 F4_2). unfold magma_op, refa405_inst, refa405_op in H. discriminate H. Qed.

Lemma refa405_not1276 : ~ @Equation1276 Fin4 refa405_inst.
Proof. unfold Equation1276. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa405_inst, refa405_op in H. discriminate H. Qed.

Lemma refa405_not1285 : ~ @Equation1285 Fin4 refa405_inst.
Proof. unfold Equation1285. intro H. specialize (H F4_0 F4_2). unfold magma_op, refa405_inst, refa405_op in H. discriminate H. Qed.

Lemma refa405_not1322 : ~ @Equation1322 Fin4 refa405_inst.
Proof. unfold Equation1322. intro H. specialize (H F4_0 F4_2). unfold magma_op, refa405_inst, refa405_op in H. discriminate H. Qed.

Lemma refa405_not1426 : ~ @Equation1426 Fin4 refa405_inst.
Proof. unfold Equation1426. intro H. specialize (H F4_0). unfold magma_op, refa405_inst, refa405_op in H. discriminate H. Qed.

Lemma refa405_not1629 : ~ @Equation1629 Fin4 refa405_inst.
Proof. unfold Equation1629. intro H. specialize (H F4_0). unfold magma_op, refa405_inst, refa405_op in H. discriminate H. Qed.

Lemma refa405_not1832 : ~ @Equation1832 Fin4 refa405_inst.
Proof. unfold Equation1832. intro H. specialize (H F4_0). unfold magma_op, refa405_inst, refa405_op in H. discriminate H. Qed.

Lemma refa405_not2037 : ~ @Equation2037 Fin4 refa405_inst.
Proof. unfold Equation2037. intro H. specialize (H F4_0 F4_2). unfold magma_op, refa405_inst, refa405_op in H. discriminate H. Qed.

Lemma refa405_not2038 : ~ @Equation2038 Fin4 refa405_inst.
Proof. unfold Equation2038. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa405_inst, refa405_op in H. discriminate H. Qed.

Lemma refa405_not2040 : ~ @Equation2040 Fin4 refa405_inst.
Proof. unfold Equation2040. intro H. specialize (H F4_0 F4_2). unfold magma_op, refa405_inst, refa405_op in H. discriminate H. Qed.

Lemma refa405_not2041 : ~ @Equation2041 Fin4 refa405_inst.
Proof. unfold Equation2041. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa405_inst, refa405_op in H. discriminate H. Qed.

Lemma refa405_not2060 : ~ @Equation2060 Fin4 refa405_inst.
Proof. unfold Equation2060. intro H. specialize (H F4_0 F4_2). unfold magma_op, refa405_inst, refa405_op in H. discriminate H. Qed.

Lemma refa405_not2088 : ~ @Equation2088 Fin4 refa405_inst.
Proof. unfold Equation2088. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa405_inst, refa405_op in H. discriminate H. Qed.

Lemma refa405_not2127 : ~ @Equation2127 Fin4 refa405_inst.
Proof. unfold Equation2127. intro H. specialize (H F4_0 F4_2). unfold magma_op, refa405_inst, refa405_op in H. discriminate H. Qed.

Lemma refa405_not2128 : ~ @Equation2128 Fin4 refa405_inst.
Proof. unfold Equation2128. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa405_inst, refa405_op in H. discriminate H. Qed.

Lemma refa405_not2134 : ~ @Equation2134 Fin4 refa405_inst.
Proof. unfold Equation2134. intro H. specialize (H F4_0 F4_2). unfold magma_op, refa405_inst, refa405_op in H. discriminate H. Qed.

Lemma refa405_not2238 : ~ @Equation2238 Fin4 refa405_inst.
Proof. unfold Equation2238. intro H. specialize (H F4_0). unfold magma_op, refa405_inst, refa405_op in H. discriminate H. Qed.

Lemma refa405_not2441 : ~ @Equation2441 Fin4 refa405_inst.
Proof. unfold Equation2441. intro H. specialize (H F4_0). unfold magma_op, refa405_inst, refa405_op in H. discriminate H. Qed.

Lemma refa405_not2644 : ~ @Equation2644 Fin4 refa405_inst.
Proof. unfold Equation2644. intro H. specialize (H F4_0). unfold magma_op, refa405_inst, refa405_op in H. discriminate H. Qed.

Lemma refa405_not2847 : ~ @Equation2847 Fin4 refa405_inst.
Proof. unfold Equation2847. intro H. specialize (H F4_0). unfold magma_op, refa405_inst, refa405_op in H. discriminate H. Qed.

Lemma refa405_not3050 : ~ @Equation3050 Fin4 refa405_inst.
Proof. unfold Equation3050. intro H. specialize (H F4_0). unfold magma_op, refa405_inst, refa405_op in H. discriminate H. Qed.

Lemma refa405_not3253 : ~ @Equation3253 Fin4 refa405_inst.
Proof. unfold Equation3253. intro H. specialize (H F4_0). unfold magma_op, refa405_inst, refa405_op in H. discriminate H. Qed.

Lemma refa405_not3456 : ~ @Equation3456 Fin4 refa405_inst.
Proof. unfold Equation3456. intro H. specialize (H F4_0). unfold magma_op, refa405_inst, refa405_op in H. discriminate H. Qed.

Lemma refa405_not3659 : ~ @Equation3659 Fin4 refa405_inst.
Proof. unfold Equation3659. intro H. specialize (H F4_0). unfold magma_op, refa405_inst, refa405_op in H. discriminate H. Qed.

Lemma refa405_not3864 : ~ @Equation3864 Fin4 refa405_inst.
Proof. unfold Equation3864. intro H. specialize (H F4_0 F4_2). unfold magma_op, refa405_inst, refa405_op in H. discriminate H. Qed.

Lemma refa405_not3865 : ~ @Equation3865 Fin4 refa405_inst.
Proof. unfold Equation3865. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa405_inst, refa405_op in H. discriminate H. Qed.

Lemma refa405_not3870 : ~ @Equation3870 Fin4 refa405_inst.
Proof. unfold Equation3870. intro H. specialize (H F4_0 F4_2). unfold magma_op, refa405_inst, refa405_op in H. discriminate H. Qed.

Lemma refa405_not3878 : ~ @Equation3878 Fin4 refa405_inst.
Proof. unfold Equation3878. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa405_inst, refa405_op in H. discriminate H. Qed.

Lemma refa405_not3880 : ~ @Equation3880 Fin4 refa405_inst.
Proof. unfold Equation3880. intro H. specialize (H F4_0 F4_2). unfold magma_op, refa405_inst, refa405_op in H. discriminate H. Qed.

Lemma refa405_not3890 : ~ @Equation3890 Fin4 refa405_inst.
Proof. unfold Equation3890. intro H. specialize (H F4_0 F4_2). unfold magma_op, refa405_inst, refa405_op in H. discriminate H. Qed.

Lemma refa405_not3917 : ~ @Equation3917 Fin4 refa405_inst.
Proof. unfold Equation3917. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa405_inst, refa405_op in H. discriminate H. Qed.

Lemma refa405_not3918 : ~ @Equation3918 Fin4 refa405_inst.
Proof. unfold Equation3918. intro H. specialize (H F4_0 F4_2). unfold magma_op, refa405_inst, refa405_op in H. discriminate H. Qed.

Lemma refa405_not3928 : ~ @Equation3928 Fin4 refa405_inst.
Proof. unfold Equation3928. intro H. specialize (H F4_0 F4_2). unfold magma_op, refa405_inst, refa405_op in H. discriminate H. Qed.

Lemma refa405_not3951 : ~ @Equation3951 Fin4 refa405_inst.
Proof. unfold Equation3951. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa405_inst, refa405_op in H. discriminate H. Qed.

Lemma refa405_not3955 : ~ @Equation3955 Fin4 refa405_inst.
Proof. unfold Equation3955. intro H. specialize (H F4_0 F4_2). unfold magma_op, refa405_inst, refa405_op in H. discriminate H. Qed.

Lemma refa405_not3964 : ~ @Equation3964 Fin4 refa405_inst.
Proof. unfold Equation3964. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa405_inst, refa405_op in H. discriminate H. Qed.

Lemma refa405_not4065 : ~ @Equation4065 Fin4 refa405_inst.
Proof. unfold Equation4065. intro H. specialize (H F4_0). unfold magma_op, refa405_inst, refa405_op in H. discriminate H. Qed.

Lemma refa405_not4269 : ~ @Equation4269 Fin4 refa405_inst.
Proof. unfold Equation4269. intro H. specialize (H F4_0 F4_2). unfold magma_op, refa405_inst, refa405_op in H. discriminate H. Qed.

Lemma refa405_not4270 : ~ @Equation4270 Fin4 refa405_inst.
Proof. unfold Equation4270. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa405_inst, refa405_op in H. discriminate H. Qed.

Lemma refa405_not4272 : ~ @Equation4272 Fin4 refa405_inst.
Proof. unfold Equation4272. intro H. specialize (H F4_0 F4_2). unfold magma_op, refa405_inst, refa405_op in H. discriminate H. Qed.

Lemma refa405_not4273 : ~ @Equation4273 Fin4 refa405_inst.
Proof. unfold Equation4273. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa405_inst, refa405_op in H. discriminate H. Qed.

Lemma refa405_not4284 : ~ @Equation4284 Fin4 refa405_inst.
Proof. unfold Equation4284. intro H. specialize (H F4_0 F4_2). unfold magma_op, refa405_inst, refa405_op in H. discriminate H. Qed.

Lemma refa405_not4290 : ~ @Equation4290 Fin4 refa405_inst.
Proof. unfold Equation4290. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa405_inst, refa405_op in H. discriminate H. Qed.

Lemma refa405_not4291 : ~ @Equation4291 Fin4 refa405_inst.
Proof. unfold Equation4291. intro H. specialize (H F4_0 F4_2). unfold magma_op, refa405_inst, refa405_op in H. discriminate H. Qed.

Lemma refa405_not4380 : ~ @Equation4380 Fin4 refa405_inst.
Proof. unfold Equation4380. intro H. specialize (H F4_0). unfold magma_op, refa405_inst, refa405_op in H. discriminate H. Qed.

Lemma refa405_not4584 : ~ @Equation4584 Fin4 refa405_inst.
Proof. unfold Equation4584. intro H. specialize (H F4_0 F4_2). unfold magma_op, refa405_inst, refa405_op in H. discriminate H. Qed.

Lemma refa405_not4585 : ~ @Equation4585 Fin4 refa405_inst.
Proof. unfold Equation4585. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa405_inst, refa405_op in H. discriminate H. Qed.

Lemma refa405_not4588 : ~ @Equation4588 Fin4 refa405_inst.
Proof. unfold Equation4588. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa405_inst, refa405_op in H. discriminate H. Qed.

Lemma refa405_not4590 : ~ @Equation4590 Fin4 refa405_inst.
Proof. unfold Equation4590. intro H. specialize (H F4_0 F4_2). unfold magma_op, refa405_inst, refa405_op in H. discriminate H. Qed.

Lemma refa405_not4598 : ~ @Equation4598 Fin4 refa405_inst.
Proof. unfold Equation4598. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa405_inst, refa405_op in H. discriminate H. Qed.

Lemma refa405_not4599 : ~ @Equation4599 Fin4 refa405_inst.
Proof. unfold Equation4599. intro H. specialize (H F4_0 F4_2). unfold magma_op, refa405_inst, refa405_op in H. discriminate H. Qed.

Lemma refa405_not4605 : ~ @Equation4605 Fin4 refa405_inst.
Proof. unfold Equation4605. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa405_inst, refa405_op in H. discriminate H. Qed.

Lemma refa405_not4635 : ~ @Equation4635 Fin4 refa405_inst.
Proof. unfold Equation4635. intro H. specialize (H F4_0 F4_2). unfold magma_op, refa405_inst, refa405_op in H. discriminate H. Qed.

(** ---- refa406 (Fin4) ---- *)

Definition refa406_op (x y : Fin4) : Fin4 :=
  match x, y with
  | F4_0, F4_0 => F4_3 | F4_0, F4_1 => F4_1 | F4_0, F4_2 => F4_1 | F4_0, F4_3 => F4_3
  | F4_1, F4_0 => F4_3 | F4_1, F4_1 => F4_3 | F4_1, F4_2 => F4_1 | F4_1, F4_3 => F4_3
  | F4_2, F4_0 => F4_3 | F4_2, F4_1 => F4_0 | F4_2, F4_2 => F4_0 | F4_2, F4_3 => F4_3
  | F4_3, F4_0 => F4_0 | F4_3, F4_1 => F4_1 | F4_3, F4_2 => F4_2 | F4_3, F4_3 => F4_3
  end.

#[local] Instance refa406_inst : Magma Fin4 := {| magma_op := refa406_op |}.

Lemma refa406_sat2812 : @Equation2812 Fin4 refa406_inst.
Proof. unfold Equation2812, magma_op, refa406_inst, refa406_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa406_not2441 : ~ @Equation2441 Fin4 refa406_inst.
Proof. unfold Equation2441. intro H. specialize (H F4_2). unfold magma_op, refa406_inst, refa406_op in H. discriminate H. Qed.

Lemma refa406_not4065 : ~ @Equation4065 Fin4 refa406_inst.
Proof. unfold Equation4065. intro H. specialize (H F4_2). unfold magma_op, refa406_inst, refa406_op in H. discriminate H. Qed.

(** ---- refa407 (Fin4) ---- *)

Definition refa407_op (x y : Fin4) : Fin4 :=
  match x, y with
  | F4_0, F4_0 => F4_1 | F4_0, F4_1 => F4_0 | F4_0, F4_2 => F4_0 | F4_0, F4_3 => F4_1
  | F4_1, F4_0 => F4_3 | F4_1, F4_1 => F4_3 | F4_1, F4_2 => F4_3 | F4_1, F4_3 => F4_2
  | F4_2, F4_0 => F4_0 | F4_2, F4_1 => F4_3 | F4_2, F4_2 => F4_3 | F4_2, F4_3 => F4_0
  | F4_3, F4_0 => F4_2 | F4_3, F4_1 => F4_0 | F4_3, F4_2 => F4_1 | F4_3, F4_3 => F4_1
  end.

#[local] Instance refa407_inst : Magma Fin4 := {| magma_op := refa407_op |}.

Lemma refa407_sat2125 : @Equation2125 Fin4 refa407_inst.
Proof. unfold Equation2125, magma_op, refa407_inst, refa407_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa407_not1426 : ~ @Equation1426 Fin4 refa407_inst.
Proof. unfold Equation1426. intro H. specialize (H F4_0). unfold magma_op, refa407_inst, refa407_op in H. discriminate H. Qed.

Lemma refa407_not2051 : ~ @Equation2051 Fin4 refa407_inst.
Proof. unfold Equation2051. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa407_inst, refa407_op in H. discriminate H. Qed.

Lemma refa407_not2088 : ~ @Equation2088 Fin4 refa407_inst.
Proof. unfold Equation2088. intro H. specialize (H F4_0 F4_2). unfold magma_op, refa407_inst, refa407_op in H. discriminate H. Qed.

Lemma refa407_not3862 : ~ @Equation3862 Fin4 refa407_inst.
Proof. unfold Equation3862. intro H. specialize (H F4_2). unfold magma_op, refa407_inst, refa407_op in H. discriminate H. Qed.

(** ---- refa408 (Fin4) ---- *)

Definition refa408_op (x y : Fin4) : Fin4 :=
  match x, y with
  | F4_0, F4_0 => F4_0 | F4_0, F4_1 => F4_3 | F4_0, F4_2 => F4_0 | F4_0, F4_3 => F4_3
  | F4_1, F4_0 => F4_2 | F4_1, F4_1 => F4_3 | F4_1, F4_2 => F4_2 | F4_1, F4_3 => F4_3
  | F4_2, F4_0 => F4_2 | F4_2, F4_1 => F4_1 | F4_2, F4_2 => F4_2 | F4_2, F4_3 => F4_1
  | F4_3, F4_0 => F4_0 | F4_3, F4_1 => F4_1 | F4_3, F4_2 => F4_0 | F4_3, F4_3 => F4_1
  end.

#[local] Instance refa408_inst : Magma Fin4 := {| magma_op := refa408_op |}.

Lemma refa408_sat162 : @Equation162 Fin4 refa408_inst.
Proof. unfold Equation162, magma_op, refa408_inst, refa408_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa408_sat1447 : @Equation1447 Fin4 refa408_inst.
Proof. unfold Equation1447, magma_op, refa408_inst, refa408_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa408_sat3089 : @Equation3089 Fin4 refa408_inst.
Proof. unfold Equation3089, magma_op, refa408_inst, refa408_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa408_not3058 : ~ @Equation3058 Fin4 refa408_inst.
Proof. unfold Equation3058. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa408_inst, refa408_op in H. discriminate H. Qed.

Lemma refa408_not3075 : ~ @Equation3075 Fin4 refa408_inst.
Proof. unfold Equation3075. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa408_inst, refa408_op in H. discriminate H. Qed.

Lemma refa408_not4073 : ~ @Equation4073 Fin4 refa408_inst.
Proof. unfold Equation4073. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa408_inst, refa408_op in H. discriminate H. Qed.

Lemma refa408_not4121 : ~ @Equation4121 Fin4 refa408_inst.
Proof. unfold Equation4121. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa408_inst, refa408_op in H. discriminate H. Qed.

Lemma refa408_not4599 : ~ @Equation4599 Fin4 refa408_inst.
Proof. unfold Equation4599. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa408_inst, refa408_op in H. discriminate H. Qed.

(** ---- refa409 (Fin4) ---- *)

Definition refa409_op (x y : Fin4) : Fin4 :=
  match x, y with
  | F4_0, F4_0 => F4_0 | F4_0, F4_1 => F4_3 | F4_0, F4_2 => F4_2 | F4_0, F4_3 => F4_3
  | F4_1, F4_0 => F4_3 | F4_1, F4_1 => F4_3 | F4_1, F4_2 => F4_3 | F4_1, F4_3 => F4_3
  | F4_2, F4_0 => F4_0 | F4_2, F4_1 => F4_0 | F4_2, F4_2 => F4_0 | F4_2, F4_3 => F4_3
  | F4_3, F4_0 => F4_0 | F4_3, F4_1 => F4_1 | F4_3, F4_2 => F4_2 | F4_3, F4_3 => F4_3
  end.

#[local] Instance refa409_inst : Magma Fin4 := {| magma_op := refa409_op |}.

Lemma refa409_sat224 : @Equation224 Fin4 refa409_inst.
Proof. unfold Equation224, magma_op, refa409_inst, refa409_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa409_not3509 : ~ @Equation3509 Fin4 refa409_inst.
Proof. unfold Equation3509. intro H. specialize (H F4_2 F4_1). unfold magma_op, refa409_inst, refa409_op in H. discriminate H. Qed.

Lemma refa409_not4362 : ~ @Equation4362 Fin4 refa409_inst.
Proof. unfold Equation4362. intro H. specialize (H F4_0 F4_2 F4_1). unfold magma_op, refa409_inst, refa409_op in H. discriminate H. Qed.

(** ---- refa41 (Fin11) ---- *)

Definition refa41_op (x y : Fin11) : Fin11 :=
  match x, y with
  | F11_0, F11_0 => F11_0 | F11_0, F11_1 => F11_2 | F11_0, F11_2 => F11_3 | F11_0, F11_3 => F11_4 | F11_0, F11_4 => F11_6 | F11_0, F11_5 => F11_1 | F11_0, F11_6 => F11_8 | F11_0, F11_7 => F11_5 | F11_0, F11_8 => F11_10 | F11_0, F11_9 => F11_7 | F11_0, F11_10 => F11_9
  | F11_1, F11_0 => F11_2 | F11_1, F11_1 => F11_1 | F11_1, F11_2 => F11_6 | F11_1, F11_3 => F11_5 | F11_1, F11_4 => F11_7 | F11_1, F11_5 => F11_4 | F11_1, F11_6 => F11_10 | F11_1, F11_7 => F11_9 | F11_1, F11_8 => F11_0 | F11_1, F11_9 => F11_8 | F11_1, F11_10 => F11_3
  | F11_2, F11_0 => F11_3 | F11_2, F11_1 => F11_6 | F11_2, F11_2 => F11_2 | F11_2, F11_3 => F11_8 | F11_2, F11_4 => F11_1 | F11_2, F11_5 => F11_7 | F11_2, F11_6 => F11_5 | F11_2, F11_7 => F11_10 | F11_2, F11_8 => F11_9 | F11_2, F11_9 => F11_4 | F11_2, F11_10 => F11_0
  | F11_3, F11_0 => F11_4 | F11_3, F11_1 => F11_5 | F11_3, F11_2 => F11_8 | F11_3, F11_3 => F11_3 | F11_3, F11_4 => F11_10 | F11_3, F11_5 => F11_9 | F11_3, F11_6 => F11_2 | F11_3, F11_7 => F11_6 | F11_3, F11_8 => F11_1 | F11_3, F11_9 => F11_0 | F11_3, F11_10 => F11_7
  | F11_4, F11_0 => F11_6 | F11_4, F11_1 => F11_7 | F11_4, F11_2 => F11_1 | F11_4, F11_3 => F11_10 | F11_4, F11_4 => F11_4 | F11_4, F11_5 => F11_8 | F11_4, F11_6 => F11_9 | F11_4, F11_7 => F11_0 | F11_4, F11_8 => F11_3 | F11_4, F11_9 => F11_5 | F11_4, F11_10 => F11_2
  | F11_5, F11_0 => F11_1 | F11_5, F11_1 => F11_4 | F11_5, F11_2 => F11_7 | F11_5, F11_3 => F11_9 | F11_5, F11_4 => F11_8 | F11_5, F11_5 => F11_5 | F11_5, F11_6 => F11_0 | F11_5, F11_7 => F11_3 | F11_5, F11_8 => F11_2 | F11_5, F11_9 => F11_10 | F11_5, F11_10 => F11_6
  | F11_6, F11_0 => F11_8 | F11_6, F11_1 => F11_10 | F11_6, F11_2 => F11_5 | F11_6, F11_3 => F11_2 | F11_6, F11_4 => F11_9 | F11_6, F11_5 => F11_0 | F11_6, F11_6 => F11_6 | F11_6, F11_7 => F11_1 | F11_6, F11_8 => F11_7 | F11_6, F11_9 => F11_3 | F11_6, F11_10 => F11_4
  | F11_7, F11_0 => F11_5 | F11_7, F11_1 => F11_9 | F11_7, F11_2 => F11_10 | F11_7, F11_3 => F11_6 | F11_7, F11_4 => F11_0 | F11_7, F11_5 => F11_3 | F11_7, F11_6 => F11_1 | F11_7, F11_7 => F11_7 | F11_7, F11_8 => F11_4 | F11_7, F11_9 => F11_2 | F11_7, F11_10 => F11_8
  | F11_8, F11_0 => F11_10 | F11_8, F11_1 => F11_0 | F11_8, F11_2 => F11_9 | F11_8, F11_3 => F11_1 | F11_8, F11_4 => F11_3 | F11_8, F11_5 => F11_2 | F11_8, F11_6 => F11_7 | F11_8, F11_7 => F11_4 | F11_8, F11_8 => F11_8 | F11_8, F11_9 => F11_6 | F11_8, F11_10 => F11_5
  | F11_9, F11_0 => F11_7 | F11_9, F11_1 => F11_8 | F11_9, F11_2 => F11_4 | F11_9, F11_3 => F11_0 | F11_9, F11_4 => F11_5 | F11_9, F11_5 => F11_10 | F11_9, F11_6 => F11_3 | F11_9, F11_7 => F11_2 | F11_9, F11_8 => F11_6 | F11_9, F11_9 => F11_9 | F11_9, F11_10 => F11_1
  | F11_10, F11_0 => F11_9 | F11_10, F11_1 => F11_3 | F11_10, F11_2 => F11_0 | F11_10, F11_3 => F11_7 | F11_10, F11_4 => F11_2 | F11_10, F11_5 => F11_6 | F11_10, F11_6 => F11_4 | F11_10, F11_7 => F11_8 | F11_10, F11_8 => F11_5 | F11_10, F11_9 => F11_1 | F11_10, F11_10 => F11_10
  end.

#[local] Instance refa41_inst : Magma Fin11 := {| magma_op := refa41_op |}.

Lemma refa41_sat670 : @Equation670 Fin11 refa41_inst.
Proof. unfold Equation670, magma_op, refa41_inst, refa41_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa41_sat677 : @Equation677 Fin11 refa41_inst.
Proof. unfold Equation677, magma_op, refa41_inst, refa41_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa41_sat2910 : @Equation2910 Fin11 refa41_inst.
Proof. unfold Equation2910, magma_op, refa41_inst, refa41_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa41_not75 : ~ @Equation75 Fin11 refa41_inst.
Proof. unfold Equation75. intro H. specialize (H F11_0 F11_1). unfold magma_op, refa41_inst, refa41_op in H. discriminate H. Qed.

Lemma refa41_not264 : ~ @Equation264 Fin11 refa41_inst.
Proof. unfold Equation264. intro H. specialize (H F11_0 F11_1). unfold magma_op, refa41_inst, refa41_op in H. discriminate H. Qed.

Lemma refa41_not513 : ~ @Equation513 Fin11 refa41_inst.
Proof. unfold Equation513. intro H. specialize (H F11_0 F11_1). unfold magma_op, refa41_inst, refa41_op in H. discriminate H. Qed.

Lemma refa41_not615 : ~ @Equation615 Fin11 refa41_inst.
Proof. unfold Equation615. intro H. specialize (H F11_0 F11_1). unfold magma_op, refa41_inst, refa41_op in H. discriminate H. Qed.

Lemma refa41_not616 : ~ @Equation616 Fin11 refa41_inst.
Proof. unfold Equation616. intro H. specialize (H F11_0 F11_1). unfold magma_op, refa41_inst, refa41_op in H. discriminate H. Qed.

Lemma refa41_not617 : ~ @Equation617 Fin11 refa41_inst.
Proof. unfold Equation617. intro H. specialize (H F11_0 F11_1). unfold magma_op, refa41_inst, refa41_op in H. discriminate H. Qed.

Lemma refa41_not619 : ~ @Equation619 Fin11 refa41_inst.
Proof. unfold Equation619. intro H. specialize (H F11_0 F11_1). unfold magma_op, refa41_inst, refa41_op in H. discriminate H. Qed.

Lemma refa41_not620 : ~ @Equation620 Fin11 refa41_inst.
Proof. unfold Equation620. intro H. specialize (H F11_0 F11_1). unfold magma_op, refa41_inst, refa41_op in H. discriminate H. Qed.

Lemma refa41_not622 : ~ @Equation622 Fin11 refa41_inst.
Proof. unfold Equation622. intro H. specialize (H F11_0 F11_1). unfold magma_op, refa41_inst, refa41_op in H. discriminate H. Qed.

Lemma refa41_not623 : ~ @Equation623 Fin11 refa41_inst.
Proof. unfold Equation623. intro H. specialize (H F11_0 F11_1). unfold magma_op, refa41_inst, refa41_op in H. discriminate H. Qed.

Lemma refa41_not629 : ~ @Equation629 Fin11 refa41_inst.
Proof. unfold Equation629. intro H. specialize (H F11_0 F11_1). unfold magma_op, refa41_inst, refa41_op in H. discriminate H. Qed.

Lemma refa41_not630 : ~ @Equation630 Fin11 refa41_inst.
Proof. unfold Equation630. intro H. specialize (H F11_0 F11_1). unfold magma_op, refa41_inst, refa41_op in H. discriminate H. Qed.

Lemma refa41_not632 : ~ @Equation632 Fin11 refa41_inst.
Proof. unfold Equation632. intro H. specialize (H F11_0 F11_1). unfold magma_op, refa41_inst, refa41_op in H. discriminate H. Qed.

Lemma refa41_not633 : ~ @Equation633 Fin11 refa41_inst.
Proof. unfold Equation633. intro H. specialize (H F11_0 F11_1). unfold magma_op, refa41_inst, refa41_op in H. discriminate H. Qed.

Lemma refa41_not639 : ~ @Equation639 Fin11 refa41_inst.
Proof. unfold Equation639. intro H. specialize (H F11_0 F11_1). unfold magma_op, refa41_inst, refa41_op in H. discriminate H. Qed.

Lemma refa41_not640 : ~ @Equation640 Fin11 refa41_inst.
Proof. unfold Equation640. intro H. specialize (H F11_0 F11_1). unfold magma_op, refa41_inst, refa41_op in H. discriminate H. Qed.

Lemma refa41_not642 : ~ @Equation642 Fin11 refa41_inst.
Proof. unfold Equation642. intro H. specialize (H F11_0 F11_1). unfold magma_op, refa41_inst, refa41_op in H. discriminate H. Qed.

Lemma refa41_not643 : ~ @Equation643 Fin11 refa41_inst.
Proof. unfold Equation643. intro H. specialize (H F11_0 F11_1). unfold magma_op, refa41_inst, refa41_op in H. discriminate H. Qed.

Lemma refa41_not667 : ~ @Equation667 Fin11 refa41_inst.
Proof. unfold Equation667. intro H. specialize (H F11_0 F11_1). unfold magma_op, refa41_inst, refa41_op in H. discriminate H. Qed.

Lemma refa41_not669 : ~ @Equation669 Fin11 refa41_inst.
Proof. unfold Equation669. intro H. specialize (H F11_0 F11_1). unfold magma_op, refa41_inst, refa41_op in H. discriminate H. Qed.

Lemma refa41_not676 : ~ @Equation676 Fin11 refa41_inst.
Proof. unfold Equation676. intro H. specialize (H F11_0 F11_1). unfold magma_op, refa41_inst, refa41_op in H. discriminate H. Qed.

Lemma refa41_not679 : ~ @Equation679 Fin11 refa41_inst.
Proof. unfold Equation679. intro H. specialize (H F11_0 F11_1). unfold magma_op, refa41_inst, refa41_op in H. discriminate H. Qed.

Lemma refa41_not680 : ~ @Equation680 Fin11 refa41_inst.
Proof. unfold Equation680. intro H. specialize (H F11_0 F11_1). unfold magma_op, refa41_inst, refa41_op in H. discriminate H. Qed.

Lemma refa41_not704 : ~ @Equation704 Fin11 refa41_inst.
Proof. unfold Equation704. intro H. specialize (H F11_0 F11_1). unfold magma_op, refa41_inst, refa41_op in H. discriminate H. Qed.

Lemma refa41_not706 : ~ @Equation706 Fin11 refa41_inst.
Proof. unfold Equation706. intro H. specialize (H F11_0 F11_1). unfold magma_op, refa41_inst, refa41_op in H. discriminate H. Qed.

Lemma refa41_not707 : ~ @Equation707 Fin11 refa41_inst.
Proof. unfold Equation707. intro H. specialize (H F11_0 F11_1). unfold magma_op, refa41_inst, refa41_op in H. discriminate H. Qed.

Lemma refa41_not713 : ~ @Equation713 Fin11 refa41_inst.
Proof. unfold Equation713. intro H. specialize (H F11_0 F11_1). unfold magma_op, refa41_inst, refa41_op in H. discriminate H. Qed.

Lemma refa41_not716 : ~ @Equation716 Fin11 refa41_inst.
Proof. unfold Equation716. intro H. specialize (H F11_0 F11_1). unfold magma_op, refa41_inst, refa41_op in H. discriminate H. Qed.

Lemma refa41_not818 : ~ @Equation818 Fin11 refa41_inst.
Proof. unfold Equation818. intro H. specialize (H F11_0 F11_1). unfold magma_op, refa41_inst, refa41_op in H. discriminate H. Qed.

Lemma refa41_not819 : ~ @Equation819 Fin11 refa41_inst.
Proof. unfold Equation819. intro H. specialize (H F11_0 F11_1). unfold magma_op, refa41_inst, refa41_op in H. discriminate H. Qed.

Lemma refa41_not820 : ~ @Equation820 Fin11 refa41_inst.
Proof. unfold Equation820. intro H. specialize (H F11_0 F11_1). unfold magma_op, refa41_inst, refa41_op in H. discriminate H. Qed.

Lemma refa41_not822 : ~ @Equation822 Fin11 refa41_inst.
Proof. unfold Equation822. intro H. specialize (H F11_0 F11_1). unfold magma_op, refa41_inst, refa41_op in H. discriminate H. Qed.

Lemma refa41_not823 : ~ @Equation823 Fin11 refa41_inst.
Proof. unfold Equation823. intro H. specialize (H F11_0 F11_1). unfold magma_op, refa41_inst, refa41_op in H. discriminate H. Qed.

Lemma refa41_not825 : ~ @Equation825 Fin11 refa41_inst.
Proof. unfold Equation825. intro H. specialize (H F11_0 F11_1). unfold magma_op, refa41_inst, refa41_op in H. discriminate H. Qed.

Lemma refa41_not826 : ~ @Equation826 Fin11 refa41_inst.
Proof. unfold Equation826. intro H. specialize (H F11_0 F11_1). unfold magma_op, refa41_inst, refa41_op in H. discriminate H. Qed.

Lemma refa41_not832 : ~ @Equation832 Fin11 refa41_inst.
Proof. unfold Equation832. intro H. specialize (H F11_0 F11_1). unfold magma_op, refa41_inst, refa41_op in H. discriminate H. Qed.

Lemma refa41_not833 : ~ @Equation833 Fin11 refa41_inst.
Proof. unfold Equation833. intro H. specialize (H F11_0 F11_1). unfold magma_op, refa41_inst, refa41_op in H. discriminate H. Qed.

Lemma refa41_not835 : ~ @Equation835 Fin11 refa41_inst.
Proof. unfold Equation835. intro H. specialize (H F11_0 F11_1). unfold magma_op, refa41_inst, refa41_op in H. discriminate H. Qed.

Lemma refa41_not836 : ~ @Equation836 Fin11 refa41_inst.
Proof. unfold Equation836. intro H. specialize (H F11_0 F11_1). unfold magma_op, refa41_inst, refa41_op in H. discriminate H. Qed.

Lemma refa41_not842 : ~ @Equation842 Fin11 refa41_inst.
Proof. unfold Equation842. intro H. specialize (H F11_0 F11_1). unfold magma_op, refa41_inst, refa41_op in H. discriminate H. Qed.

Lemma refa41_not843 : ~ @Equation843 Fin11 refa41_inst.
Proof. unfold Equation843. intro H. specialize (H F11_0 F11_1). unfold magma_op, refa41_inst, refa41_op in H. discriminate H. Qed.

Lemma refa41_not845 : ~ @Equation845 Fin11 refa41_inst.
Proof. unfold Equation845. intro H. specialize (H F11_0 F11_1). unfold magma_op, refa41_inst, refa41_op in H. discriminate H. Qed.

Lemma refa41_not846 : ~ @Equation846 Fin11 refa41_inst.
Proof. unfold Equation846. intro H. specialize (H F11_0 F11_1). unfold magma_op, refa41_inst, refa41_op in H. discriminate H. Qed.

Lemma refa41_not870 : ~ @Equation870 Fin11 refa41_inst.
Proof. unfold Equation870. intro H. specialize (H F11_0 F11_1). unfold magma_op, refa41_inst, refa41_op in H. discriminate H. Qed.

Lemma refa41_not872 : ~ @Equation872 Fin11 refa41_inst.
Proof. unfold Equation872. intro H. specialize (H F11_0 F11_1). unfold magma_op, refa41_inst, refa41_op in H. discriminate H. Qed.

Lemma refa41_not873 : ~ @Equation873 Fin11 refa41_inst.
Proof. unfold Equation873. intro H. specialize (H F11_0 F11_1). unfold magma_op, refa41_inst, refa41_op in H. discriminate H. Qed.

Lemma refa41_not879 : ~ @Equation879 Fin11 refa41_inst.
Proof. unfold Equation879. intro H. specialize (H F11_0 F11_1). unfold magma_op, refa41_inst, refa41_op in H. discriminate H. Qed.

Lemma refa41_not882 : ~ @Equation882 Fin11 refa41_inst.
Proof. unfold Equation882. intro H. specialize (H F11_0 F11_1). unfold magma_op, refa41_inst, refa41_op in H. discriminate H. Qed.

Lemma refa41_not883 : ~ @Equation883 Fin11 refa41_inst.
Proof. unfold Equation883. intro H. specialize (H F11_0 F11_1). unfold magma_op, refa41_inst, refa41_op in H. discriminate H. Qed.

Lemma refa41_not906 : ~ @Equation906 Fin11 refa41_inst.
Proof. unfold Equation906. intro H. specialize (H F11_0 F11_1). unfold magma_op, refa41_inst, refa41_op in H. discriminate H. Qed.

Lemma refa41_not907 : ~ @Equation907 Fin11 refa41_inst.
Proof. unfold Equation907. intro H. specialize (H F11_0 F11_1). unfold magma_op, refa41_inst, refa41_op in H. discriminate H. Qed.

Lemma refa41_not917 : ~ @Equation917 Fin11 refa41_inst.
Proof. unfold Equation917. intro H. specialize (H F11_0 F11_1). unfold magma_op, refa41_inst, refa41_op in H. discriminate H. Qed.

Lemma refa41_not1021 : ~ @Equation1021 Fin11 refa41_inst.
Proof. unfold Equation1021. intro H. specialize (H F11_0 F11_1). unfold magma_op, refa41_inst, refa41_op in H. discriminate H. Qed.

Lemma refa41_not1022 : ~ @Equation1022 Fin11 refa41_inst.
Proof. unfold Equation1022. intro H. specialize (H F11_0 F11_1). unfold magma_op, refa41_inst, refa41_op in H. discriminate H. Qed.

Lemma refa41_not1023 : ~ @Equation1023 Fin11 refa41_inst.
Proof. unfold Equation1023. intro H. specialize (H F11_0 F11_1). unfold magma_op, refa41_inst, refa41_op in H. discriminate H. Qed.

Lemma refa41_not1025 : ~ @Equation1025 Fin11 refa41_inst.
Proof. unfold Equation1025. intro H. specialize (H F11_0 F11_1). unfold magma_op, refa41_inst, refa41_op in H. discriminate H. Qed.

Lemma refa41_not1026 : ~ @Equation1026 Fin11 refa41_inst.
Proof. unfold Equation1026. intro H. specialize (H F11_0 F11_1). unfold magma_op, refa41_inst, refa41_op in H. discriminate H. Qed.

Lemma refa41_not1028 : ~ @Equation1028 Fin11 refa41_inst.
Proof. unfold Equation1028. intro H. specialize (H F11_0 F11_1). unfold magma_op, refa41_inst, refa41_op in H. discriminate H. Qed.

Lemma refa41_not1029 : ~ @Equation1029 Fin11 refa41_inst.
Proof. unfold Equation1029. intro H. specialize (H F11_0 F11_1). unfold magma_op, refa41_inst, refa41_op in H. discriminate H. Qed.

Lemma refa41_not1035 : ~ @Equation1035 Fin11 refa41_inst.
Proof. unfold Equation1035. intro H. specialize (H F11_0 F11_1). unfold magma_op, refa41_inst, refa41_op in H. discriminate H. Qed.

Lemma refa41_not1036 : ~ @Equation1036 Fin11 refa41_inst.
Proof. unfold Equation1036. intro H. specialize (H F11_0 F11_1). unfold magma_op, refa41_inst, refa41_op in H. discriminate H. Qed.

Lemma refa41_not1038 : ~ @Equation1038 Fin11 refa41_inst.
Proof. unfold Equation1038. intro H. specialize (H F11_0 F11_1). unfold magma_op, refa41_inst, refa41_op in H. discriminate H. Qed.

Lemma refa41_not1039 : ~ @Equation1039 Fin11 refa41_inst.
Proof. unfold Equation1039. intro H. specialize (H F11_0 F11_1). unfold magma_op, refa41_inst, refa41_op in H. discriminate H. Qed.

Lemma refa41_not1045 : ~ @Equation1045 Fin11 refa41_inst.
Proof. unfold Equation1045. intro H. specialize (H F11_0 F11_1). unfold magma_op, refa41_inst, refa41_op in H. discriminate H. Qed.

Lemma refa41_not1046 : ~ @Equation1046 Fin11 refa41_inst.
Proof. unfold Equation1046. intro H. specialize (H F11_0 F11_1). unfold magma_op, refa41_inst, refa41_op in H. discriminate H. Qed.

Lemma refa41_not1048 : ~ @Equation1048 Fin11 refa41_inst.
Proof. unfold Equation1048. intro H. specialize (H F11_0 F11_1). unfold magma_op, refa41_inst, refa41_op in H. discriminate H. Qed.

Lemma refa41_not1049 : ~ @Equation1049 Fin11 refa41_inst.
Proof. unfold Equation1049. intro H. specialize (H F11_0 F11_1). unfold magma_op, refa41_inst, refa41_op in H. discriminate H. Qed.

Lemma refa41_not1075 : ~ @Equation1075 Fin11 refa41_inst.
Proof. unfold Equation1075. intro H. specialize (H F11_0 F11_1). unfold magma_op, refa41_inst, refa41_op in H. discriminate H. Qed.

Lemma refa41_not1076 : ~ @Equation1076 Fin11 refa41_inst.
Proof. unfold Equation1076. intro H. specialize (H F11_0 F11_1). unfold magma_op, refa41_inst, refa41_op in H. discriminate H. Qed.

Lemma refa41_not1082 : ~ @Equation1082 Fin11 refa41_inst.
Proof. unfold Equation1082. intro H. specialize (H F11_0 F11_1). unfold magma_op, refa41_inst, refa41_op in H. discriminate H. Qed.

Lemma refa41_not1083 : ~ @Equation1083 Fin11 refa41_inst.
Proof. unfold Equation1083. intro H. specialize (H F11_0 F11_1). unfold magma_op, refa41_inst, refa41_op in H. discriminate H. Qed.

Lemma refa41_not1085 : ~ @Equation1085 Fin11 refa41_inst.
Proof. unfold Equation1085. intro H. specialize (H F11_0 F11_1). unfold magma_op, refa41_inst, refa41_op in H. discriminate H. Qed.

Lemma refa41_not1086 : ~ @Equation1086 Fin11 refa41_inst.
Proof. unfold Equation1086. intro H. specialize (H F11_0 F11_1). unfold magma_op, refa41_inst, refa41_op in H. discriminate H. Qed.

Lemma refa41_not1109 : ~ @Equation1109 Fin11 refa41_inst.
Proof. unfold Equation1109. intro H. specialize (H F11_0 F11_1). unfold magma_op, refa41_inst, refa41_op in H. discriminate H. Qed.

Lemma refa41_not1110 : ~ @Equation1110 Fin11 refa41_inst.
Proof. unfold Equation1110. intro H. specialize (H F11_0 F11_1). unfold magma_op, refa41_inst, refa41_op in H. discriminate H. Qed.

Lemma refa41_not1113 : ~ @Equation1113 Fin11 refa41_inst.
Proof. unfold Equation1113. intro H. specialize (H F11_0 F11_1). unfold magma_op, refa41_inst, refa41_op in H. discriminate H. Qed.

Lemma refa41_not1122 : ~ @Equation1122 Fin11 refa41_inst.
Proof. unfold Equation1122. intro H. specialize (H F11_0 F11_1). unfold magma_op, refa41_inst, refa41_op in H. discriminate H. Qed.

Lemma refa41_not1224 : ~ @Equation1224 Fin11 refa41_inst.
Proof. unfold Equation1224. intro H. specialize (H F11_0 F11_1). unfold magma_op, refa41_inst, refa41_op in H. discriminate H. Qed.

Lemma refa41_not1225 : ~ @Equation1225 Fin11 refa41_inst.
Proof. unfold Equation1225. intro H. specialize (H F11_0 F11_1). unfold magma_op, refa41_inst, refa41_op in H. discriminate H. Qed.

Lemma refa41_not1226 : ~ @Equation1226 Fin11 refa41_inst.
Proof. unfold Equation1226. intro H. specialize (H F11_0 F11_1). unfold magma_op, refa41_inst, refa41_op in H. discriminate H. Qed.

Lemma refa41_not1228 : ~ @Equation1228 Fin11 refa41_inst.
Proof. unfold Equation1228. intro H. specialize (H F11_0 F11_1). unfold magma_op, refa41_inst, refa41_op in H. discriminate H. Qed.

Lemma refa41_not1229 : ~ @Equation1229 Fin11 refa41_inst.
Proof. unfold Equation1229. intro H. specialize (H F11_0 F11_1). unfold magma_op, refa41_inst, refa41_op in H. discriminate H. Qed.

Lemma refa41_not1231 : ~ @Equation1231 Fin11 refa41_inst.
Proof. unfold Equation1231. intro H. specialize (H F11_0 F11_1). unfold magma_op, refa41_inst, refa41_op in H. discriminate H. Qed.

Lemma refa41_not1232 : ~ @Equation1232 Fin11 refa41_inst.
Proof. unfold Equation1232. intro H. specialize (H F11_0 F11_1). unfold magma_op, refa41_inst, refa41_op in H. discriminate H. Qed.

Lemma refa41_not1238 : ~ @Equation1238 Fin11 refa41_inst.
Proof. unfold Equation1238. intro H. specialize (H F11_0 F11_1). unfold magma_op, refa41_inst, refa41_op in H. discriminate H. Qed.

Lemma refa41_not1239 : ~ @Equation1239 Fin11 refa41_inst.
Proof. unfold Equation1239. intro H. specialize (H F11_0 F11_1). unfold magma_op, refa41_inst, refa41_op in H. discriminate H. Qed.

Lemma refa41_not1241 : ~ @Equation1241 Fin11 refa41_inst.
Proof. unfold Equation1241. intro H. specialize (H F11_0 F11_1). unfold magma_op, refa41_inst, refa41_op in H. discriminate H. Qed.

Lemma refa41_not1242 : ~ @Equation1242 Fin11 refa41_inst.
Proof. unfold Equation1242. intro H. specialize (H F11_0 F11_1). unfold magma_op, refa41_inst, refa41_op in H. discriminate H. Qed.

Lemma refa41_not1248 : ~ @Equation1248 Fin11 refa41_inst.
Proof. unfold Equation1248. intro H. specialize (H F11_0 F11_1). unfold magma_op, refa41_inst, refa41_op in H. discriminate H. Qed.

Lemma refa41_not1249 : ~ @Equation1249 Fin11 refa41_inst.
Proof. unfold Equation1249. intro H. specialize (H F11_0 F11_1). unfold magma_op, refa41_inst, refa41_op in H. discriminate H. Qed.

Lemma refa41_not1251 : ~ @Equation1251 Fin11 refa41_inst.
Proof. unfold Equation1251. intro H. specialize (H F11_0 F11_1). unfold magma_op, refa41_inst, refa41_op in H. discriminate H. Qed.

Lemma refa41_not1252 : ~ @Equation1252 Fin11 refa41_inst.
Proof. unfold Equation1252. intro H. specialize (H F11_0 F11_1). unfold magma_op, refa41_inst, refa41_op in H. discriminate H. Qed.

Lemma refa41_not1276 : ~ @Equation1276 Fin11 refa41_inst.
Proof. unfold Equation1276. intro H. specialize (H F11_0 F11_1). unfold magma_op, refa41_inst, refa41_op in H. discriminate H. Qed.

Lemma refa41_not1278 : ~ @Equation1278 Fin11 refa41_inst.
Proof. unfold Equation1278. intro H. specialize (H F11_0 F11_1). unfold magma_op, refa41_inst, refa41_op in H. discriminate H. Qed.

Lemma refa41_not1279 : ~ @Equation1279 Fin11 refa41_inst.
Proof. unfold Equation1279. intro H. specialize (H F11_0 F11_1). unfold magma_op, refa41_inst, refa41_op in H. discriminate H. Qed.

Lemma refa41_not1285 : ~ @Equation1285 Fin11 refa41_inst.
Proof. unfold Equation1285. intro H. specialize (H F11_0 F11_1). unfold magma_op, refa41_inst, refa41_op in H. discriminate H. Qed.

Lemma refa41_not1286 : ~ @Equation1286 Fin11 refa41_inst.
Proof. unfold Equation1286. intro H. specialize (H F11_0 F11_1). unfold magma_op, refa41_inst, refa41_op in H. discriminate H. Qed.

Lemma refa41_not1289 : ~ @Equation1289 Fin11 refa41_inst.
Proof. unfold Equation1289. intro H. specialize (H F11_0 F11_1). unfold magma_op, refa41_inst, refa41_op in H. discriminate H. Qed.

Lemma refa41_not1312 : ~ @Equation1312 Fin11 refa41_inst.
Proof. unfold Equation1312. intro H. specialize (H F11_0 F11_1). unfold magma_op, refa41_inst, refa41_op in H. discriminate H. Qed.

Lemma refa41_not1313 : ~ @Equation1313 Fin11 refa41_inst.
Proof. unfold Equation1313. intro H. specialize (H F11_0 F11_1). unfold magma_op, refa41_inst, refa41_op in H. discriminate H. Qed.

Lemma refa41_not1322 : ~ @Equation1322 Fin11 refa41_inst.
Proof. unfold Equation1322. intro H. specialize (H F11_0 F11_1). unfold magma_op, refa41_inst, refa41_op in H. discriminate H. Qed.

Lemma refa41_not1325 : ~ @Equation1325 Fin11 refa41_inst.
Proof. unfold Equation1325. intro H. specialize (H F11_0 F11_1). unfold magma_op, refa41_inst, refa41_op in H. discriminate H. Qed.

Lemma refa41_not1427 : ~ @Equation1427 Fin11 refa41_inst.
Proof. unfold Equation1427. intro H. specialize (H F11_0 F11_1). unfold magma_op, refa41_inst, refa41_op in H. discriminate H. Qed.

Lemma refa41_not1428 : ~ @Equation1428 Fin11 refa41_inst.
Proof. unfold Equation1428. intro H. specialize (H F11_0 F11_1). unfold magma_op, refa41_inst, refa41_op in H. discriminate H. Qed.

Lemma refa41_not1429 : ~ @Equation1429 Fin11 refa41_inst.
Proof. unfold Equation1429. intro H. specialize (H F11_0 F11_1). unfold magma_op, refa41_inst, refa41_op in H. discriminate H. Qed.

Lemma refa41_not1431 : ~ @Equation1431 Fin11 refa41_inst.
Proof. unfold Equation1431. intro H. specialize (H F11_0 F11_1). unfold magma_op, refa41_inst, refa41_op in H. discriminate H. Qed.

Lemma refa41_not1432 : ~ @Equation1432 Fin11 refa41_inst.
Proof. unfold Equation1432. intro H. specialize (H F11_0 F11_1). unfold magma_op, refa41_inst, refa41_op in H. discriminate H. Qed.

Lemma refa41_not1434 : ~ @Equation1434 Fin11 refa41_inst.
Proof. unfold Equation1434. intro H. specialize (H F11_0 F11_1). unfold magma_op, refa41_inst, refa41_op in H. discriminate H. Qed.

Lemma refa41_not1435 : ~ @Equation1435 Fin11 refa41_inst.
Proof. unfold Equation1435. intro H. specialize (H F11_0 F11_1). unfold magma_op, refa41_inst, refa41_op in H. discriminate H. Qed.

Lemma refa41_not1441 : ~ @Equation1441 Fin11 refa41_inst.
Proof. unfold Equation1441. intro H. specialize (H F11_0 F11_1). unfold magma_op, refa41_inst, refa41_op in H. discriminate H. Qed.

Lemma refa41_not1444 : ~ @Equation1444 Fin11 refa41_inst.
Proof. unfold Equation1444. intro H. specialize (H F11_0 F11_1). unfold magma_op, refa41_inst, refa41_op in H. discriminate H. Qed.

Lemma refa41_not1445 : ~ @Equation1445 Fin11 refa41_inst.
Proof. unfold Equation1445. intro H. specialize (H F11_0 F11_1). unfold magma_op, refa41_inst, refa41_op in H. discriminate H. Qed.

Lemma refa41_not1451 : ~ @Equation1451 Fin11 refa41_inst.
Proof. unfold Equation1451. intro H. specialize (H F11_0 F11_1). unfold magma_op, refa41_inst, refa41_op in H. discriminate H. Qed.

Lemma refa41_not1452 : ~ @Equation1452 Fin11 refa41_inst.
Proof. unfold Equation1452. intro H. specialize (H F11_0 F11_1). unfold magma_op, refa41_inst, refa41_op in H. discriminate H. Qed.

Lemma refa41_not1454 : ~ @Equation1454 Fin11 refa41_inst.
Proof. unfold Equation1454. intro H. specialize (H F11_0 F11_1). unfold magma_op, refa41_inst, refa41_op in H. discriminate H. Qed.

Lemma refa41_not1455 : ~ @Equation1455 Fin11 refa41_inst.
Proof. unfold Equation1455. intro H. specialize (H F11_0 F11_1). unfold magma_op, refa41_inst, refa41_op in H. discriminate H. Qed.

Lemma refa41_not1478 : ~ @Equation1478 Fin11 refa41_inst.
Proof. unfold Equation1478. intro H. specialize (H F11_0 F11_1). unfold magma_op, refa41_inst, refa41_op in H. discriminate H. Qed.

Lemma refa41_not1479 : ~ @Equation1479 Fin11 refa41_inst.
Proof. unfold Equation1479. intro H. specialize (H F11_0 F11_1). unfold magma_op, refa41_inst, refa41_op in H. discriminate H. Qed.

Lemma refa41_not1482 : ~ @Equation1482 Fin11 refa41_inst.
Proof. unfold Equation1482. intro H. specialize (H F11_0 F11_1). unfold magma_op, refa41_inst, refa41_op in H. discriminate H. Qed.

Lemma refa41_not1488 : ~ @Equation1488 Fin11 refa41_inst.
Proof. unfold Equation1488. intro H. specialize (H F11_0 F11_1). unfold magma_op, refa41_inst, refa41_op in H. discriminate H. Qed.

Lemma refa41_not1489 : ~ @Equation1489 Fin11 refa41_inst.
Proof. unfold Equation1489. intro H. specialize (H F11_0 F11_1). unfold magma_op, refa41_inst, refa41_op in H. discriminate H. Qed.

Lemma refa41_not1491 : ~ @Equation1491 Fin11 refa41_inst.
Proof. unfold Equation1491. intro H. specialize (H F11_0 F11_1). unfold magma_op, refa41_inst, refa41_op in H. discriminate H. Qed.

Lemma refa41_not1515 : ~ @Equation1515 Fin11 refa41_inst.
Proof. unfold Equation1515. intro H. specialize (H F11_0 F11_1). unfold magma_op, refa41_inst, refa41_op in H. discriminate H. Qed.

Lemma refa41_not1516 : ~ @Equation1516 Fin11 refa41_inst.
Proof. unfold Equation1516. intro H. specialize (H F11_0 F11_1). unfold magma_op, refa41_inst, refa41_op in H. discriminate H. Qed.

Lemma refa41_not1518 : ~ @Equation1518 Fin11 refa41_inst.
Proof. unfold Equation1518. intro H. specialize (H F11_0 F11_1). unfold magma_op, refa41_inst, refa41_op in H. discriminate H. Qed.

Lemma refa41_not1519 : ~ @Equation1519 Fin11 refa41_inst.
Proof. unfold Equation1519. intro H. specialize (H F11_0 F11_1). unfold magma_op, refa41_inst, refa41_op in H. discriminate H. Qed.

Lemma refa41_not1525 : ~ @Equation1525 Fin11 refa41_inst.
Proof. unfold Equation1525. intro H. specialize (H F11_0 F11_1). unfold magma_op, refa41_inst, refa41_op in H. discriminate H. Qed.

Lemma refa41_not1526 : ~ @Equation1526 Fin11 refa41_inst.
Proof. unfold Equation1526. intro H. specialize (H F11_0 F11_1). unfold magma_op, refa41_inst, refa41_op in H. discriminate H. Qed.

Lemma refa41_not1630 : ~ @Equation1630 Fin11 refa41_inst.
Proof. unfold Equation1630. intro H. specialize (H F11_0 F11_1). unfold magma_op, refa41_inst, refa41_op in H. discriminate H. Qed.

Lemma refa41_not1631 : ~ @Equation1631 Fin11 refa41_inst.
Proof. unfold Equation1631. intro H. specialize (H F11_0 F11_1). unfold magma_op, refa41_inst, refa41_op in H. discriminate H. Qed.

Lemma refa41_not1632 : ~ @Equation1632 Fin11 refa41_inst.
Proof. unfold Equation1632. intro H. specialize (H F11_0 F11_1). unfold magma_op, refa41_inst, refa41_op in H. discriminate H. Qed.

Lemma refa41_not1634 : ~ @Equation1634 Fin11 refa41_inst.
Proof. unfold Equation1634. intro H. specialize (H F11_0 F11_1). unfold magma_op, refa41_inst, refa41_op in H. discriminate H. Qed.

Lemma refa41_not1635 : ~ @Equation1635 Fin11 refa41_inst.
Proof. unfold Equation1635. intro H. specialize (H F11_0 F11_1). unfold magma_op, refa41_inst, refa41_op in H. discriminate H. Qed.

Lemma refa41_not1637 : ~ @Equation1637 Fin11 refa41_inst.
Proof. unfold Equation1637. intro H. specialize (H F11_0 F11_1). unfold magma_op, refa41_inst, refa41_op in H. discriminate H. Qed.

Lemma refa41_not1638 : ~ @Equation1638 Fin11 refa41_inst.
Proof. unfold Equation1638. intro H. specialize (H F11_0 F11_1). unfold magma_op, refa41_inst, refa41_op in H. discriminate H. Qed.

Lemma refa41_not1644 : ~ @Equation1644 Fin11 refa41_inst.
Proof. unfold Equation1644. intro H. specialize (H F11_0 F11_1). unfold magma_op, refa41_inst, refa41_op in H. discriminate H. Qed.

Lemma refa41_not1645 : ~ @Equation1645 Fin11 refa41_inst.
Proof. unfold Equation1645. intro H. specialize (H F11_0 F11_1). unfold magma_op, refa41_inst, refa41_op in H. discriminate H. Qed.

Lemma refa41_not1648 : ~ @Equation1648 Fin11 refa41_inst.
Proof. unfold Equation1648. intro H. specialize (H F11_0 F11_1). unfold magma_op, refa41_inst, refa41_op in H. discriminate H. Qed.

Lemma refa41_not1654 : ~ @Equation1654 Fin11 refa41_inst.
Proof. unfold Equation1654. intro H. specialize (H F11_0 F11_1). unfold magma_op, refa41_inst, refa41_op in H. discriminate H. Qed.

Lemma refa41_not1655 : ~ @Equation1655 Fin11 refa41_inst.
Proof. unfold Equation1655. intro H. specialize (H F11_0 F11_1). unfold magma_op, refa41_inst, refa41_op in H. discriminate H. Qed.

Lemma refa41_not1657 : ~ @Equation1657 Fin11 refa41_inst.
Proof. unfold Equation1657. intro H. specialize (H F11_0 F11_1). unfold magma_op, refa41_inst, refa41_op in H. discriminate H. Qed.

Lemma refa41_not1658 : ~ @Equation1658 Fin11 refa41_inst.
Proof. unfold Equation1658. intro H. specialize (H F11_0 F11_1). unfold magma_op, refa41_inst, refa41_op in H. discriminate H. Qed.

Lemma refa41_not1681 : ~ @Equation1681 Fin11 refa41_inst.
Proof. unfold Equation1681. intro H. specialize (H F11_0 F11_1). unfold magma_op, refa41_inst, refa41_op in H. discriminate H. Qed.

Lemma refa41_not1682 : ~ @Equation1682 Fin11 refa41_inst.
Proof. unfold Equation1682. intro H. specialize (H F11_0 F11_1). unfold magma_op, refa41_inst, refa41_op in H. discriminate H. Qed.

Lemma refa41_not1684 : ~ @Equation1684 Fin11 refa41_inst.
Proof. unfold Equation1684. intro H. specialize (H F11_0 F11_1). unfold magma_op, refa41_inst, refa41_op in H. discriminate H. Qed.

Lemma refa41_not1685 : ~ @Equation1685 Fin11 refa41_inst.
Proof. unfold Equation1685. intro H. specialize (H F11_0 F11_1). unfold magma_op, refa41_inst, refa41_op in H. discriminate H. Qed.

Lemma refa41_not1691 : ~ @Equation1691 Fin11 refa41_inst.
Proof. unfold Equation1691. intro H. specialize (H F11_0 F11_1). unfold magma_op, refa41_inst, refa41_op in H. discriminate H. Qed.

Lemma refa41_not1692 : ~ @Equation1692 Fin11 refa41_inst.
Proof. unfold Equation1692. intro H. specialize (H F11_0 F11_1). unfold magma_op, refa41_inst, refa41_op in H. discriminate H. Qed.

Lemma refa41_not1694 : ~ @Equation1694 Fin11 refa41_inst.
Proof. unfold Equation1694. intro H. specialize (H F11_0 F11_1). unfold magma_op, refa41_inst, refa41_op in H. discriminate H. Qed.

Lemma refa41_not1719 : ~ @Equation1719 Fin11 refa41_inst.
Proof. unfold Equation1719. intro H. specialize (H F11_0 F11_1). unfold magma_op, refa41_inst, refa41_op in H. discriminate H. Qed.

Lemma refa41_not1721 : ~ @Equation1721 Fin11 refa41_inst.
Proof. unfold Equation1721. intro H. specialize (H F11_0 F11_1). unfold magma_op, refa41_inst, refa41_op in H. discriminate H. Qed.

Lemma refa41_not1722 : ~ @Equation1722 Fin11 refa41_inst.
Proof. unfold Equation1722. intro H. specialize (H F11_0 F11_1). unfold magma_op, refa41_inst, refa41_op in H. discriminate H. Qed.

Lemma refa41_not1728 : ~ @Equation1728 Fin11 refa41_inst.
Proof. unfold Equation1728. intro H. specialize (H F11_0 F11_1). unfold magma_op, refa41_inst, refa41_op in H. discriminate H. Qed.

Lemma refa41_not1731 : ~ @Equation1731 Fin11 refa41_inst.
Proof. unfold Equation1731. intro H. specialize (H F11_0 F11_1). unfold magma_op, refa41_inst, refa41_op in H. discriminate H. Qed.

Lemma refa41_not1833 : ~ @Equation1833 Fin11 refa41_inst.
Proof. unfold Equation1833. intro H. specialize (H F11_0 F11_1). unfold magma_op, refa41_inst, refa41_op in H. discriminate H. Qed.

Lemma refa41_not1834 : ~ @Equation1834 Fin11 refa41_inst.
Proof. unfold Equation1834. intro H. specialize (H F11_0 F11_1). unfold magma_op, refa41_inst, refa41_op in H. discriminate H. Qed.

Lemma refa41_not1837 : ~ @Equation1837 Fin11 refa41_inst.
Proof. unfold Equation1837. intro H. specialize (H F11_0 F11_1). unfold magma_op, refa41_inst, refa41_op in H. discriminate H. Qed.

Lemma refa41_not1838 : ~ @Equation1838 Fin11 refa41_inst.
Proof. unfold Equation1838. intro H. specialize (H F11_0 F11_1). unfold magma_op, refa41_inst, refa41_op in H. discriminate H. Qed.

Lemma refa41_not1840 : ~ @Equation1840 Fin11 refa41_inst.
Proof. unfold Equation1840. intro H. specialize (H F11_0 F11_1). unfold magma_op, refa41_inst, refa41_op in H. discriminate H. Qed.

Lemma refa41_not1841 : ~ @Equation1841 Fin11 refa41_inst.
Proof. unfold Equation1841. intro H. specialize (H F11_0 F11_1). unfold magma_op, refa41_inst, refa41_op in H. discriminate H. Qed.

Lemma refa41_not1847 : ~ @Equation1847 Fin11 refa41_inst.
Proof. unfold Equation1847. intro H. specialize (H F11_0 F11_1). unfold magma_op, refa41_inst, refa41_op in H. discriminate H. Qed.

Lemma refa41_not1848 : ~ @Equation1848 Fin11 refa41_inst.
Proof. unfold Equation1848. intro H. specialize (H F11_0 F11_1). unfold magma_op, refa41_inst, refa41_op in H. discriminate H. Qed.

Lemma refa41_not1851 : ~ @Equation1851 Fin11 refa41_inst.
Proof. unfold Equation1851. intro H. specialize (H F11_0 F11_1). unfold magma_op, refa41_inst, refa41_op in H. discriminate H. Qed.

Lemma refa41_not1857 : ~ @Equation1857 Fin11 refa41_inst.
Proof. unfold Equation1857. intro H. specialize (H F11_0 F11_1). unfold magma_op, refa41_inst, refa41_op in H. discriminate H. Qed.

Lemma refa41_not1858 : ~ @Equation1858 Fin11 refa41_inst.
Proof. unfold Equation1858. intro H. specialize (H F11_0 F11_1). unfold magma_op, refa41_inst, refa41_op in H. discriminate H. Qed.

Lemma refa41_not1860 : ~ @Equation1860 Fin11 refa41_inst.
Proof. unfold Equation1860. intro H. specialize (H F11_0 F11_1). unfold magma_op, refa41_inst, refa41_op in H. discriminate H. Qed.

Lemma refa41_not1861 : ~ @Equation1861 Fin11 refa41_inst.
Proof. unfold Equation1861. intro H. specialize (H F11_0 F11_1). unfold magma_op, refa41_inst, refa41_op in H. discriminate H. Qed.

Lemma refa41_not1884 : ~ @Equation1884 Fin11 refa41_inst.
Proof. unfold Equation1884. intro H. specialize (H F11_0 F11_1). unfold magma_op, refa41_inst, refa41_op in H. discriminate H. Qed.

Lemma refa41_not1885 : ~ @Equation1885 Fin11 refa41_inst.
Proof. unfold Equation1885. intro H. specialize (H F11_0 F11_1). unfold magma_op, refa41_inst, refa41_op in H. discriminate H. Qed.

Lemma refa41_not1887 : ~ @Equation1887 Fin11 refa41_inst.
Proof. unfold Equation1887. intro H. specialize (H F11_0 F11_1). unfold magma_op, refa41_inst, refa41_op in H. discriminate H. Qed.

Lemma refa41_not1888 : ~ @Equation1888 Fin11 refa41_inst.
Proof. unfold Equation1888. intro H. specialize (H F11_0 F11_1). unfold magma_op, refa41_inst, refa41_op in H. discriminate H. Qed.

Lemma refa41_not1894 : ~ @Equation1894 Fin11 refa41_inst.
Proof. unfold Equation1894. intro H. specialize (H F11_0 F11_1). unfold magma_op, refa41_inst, refa41_op in H. discriminate H. Qed.

Lemma refa41_not1895 : ~ @Equation1895 Fin11 refa41_inst.
Proof. unfold Equation1895. intro H. specialize (H F11_0 F11_1). unfold magma_op, refa41_inst, refa41_op in H. discriminate H. Qed.

Lemma refa41_not1897 : ~ @Equation1897 Fin11 refa41_inst.
Proof. unfold Equation1897. intro H. specialize (H F11_0 F11_1). unfold magma_op, refa41_inst, refa41_op in H. discriminate H. Qed.

Lemma refa41_not1921 : ~ @Equation1921 Fin11 refa41_inst.
Proof. unfold Equation1921. intro H. specialize (H F11_0 F11_1). unfold magma_op, refa41_inst, refa41_op in H. discriminate H. Qed.

Lemma refa41_not1922 : ~ @Equation1922 Fin11 refa41_inst.
Proof. unfold Equation1922. intro H. specialize (H F11_0 F11_1). unfold magma_op, refa41_inst, refa41_op in H. discriminate H. Qed.

Lemma refa41_not1924 : ~ @Equation1924 Fin11 refa41_inst.
Proof. unfold Equation1924. intro H. specialize (H F11_0 F11_1). unfold magma_op, refa41_inst, refa41_op in H. discriminate H. Qed.

Lemma refa41_not1925 : ~ @Equation1925 Fin11 refa41_inst.
Proof. unfold Equation1925. intro H. specialize (H F11_0 F11_1). unfold magma_op, refa41_inst, refa41_op in H. discriminate H. Qed.

Lemma refa41_not1931 : ~ @Equation1931 Fin11 refa41_inst.
Proof. unfold Equation1931. intro H. specialize (H F11_0 F11_1). unfold magma_op, refa41_inst, refa41_op in H. discriminate H. Qed.

Lemma refa41_not2036 : ~ @Equation2036 Fin11 refa41_inst.
Proof. unfold Equation2036. intro H. specialize (H F11_0 F11_1). unfold magma_op, refa41_inst, refa41_op in H. discriminate H. Qed.

Lemma refa41_not2037 : ~ @Equation2037 Fin11 refa41_inst.
Proof. unfold Equation2037. intro H. specialize (H F11_0 F11_1). unfold magma_op, refa41_inst, refa41_op in H. discriminate H. Qed.

Lemma refa41_not2038 : ~ @Equation2038 Fin11 refa41_inst.
Proof. unfold Equation2038. intro H. specialize (H F11_0 F11_1). unfold magma_op, refa41_inst, refa41_op in H. discriminate H. Qed.

Lemma refa41_not2040 : ~ @Equation2040 Fin11 refa41_inst.
Proof. unfold Equation2040. intro H. specialize (H F11_0 F11_1). unfold magma_op, refa41_inst, refa41_op in H. discriminate H. Qed.

Lemma refa41_not2041 : ~ @Equation2041 Fin11 refa41_inst.
Proof. unfold Equation2041. intro H. specialize (H F11_0 F11_1). unfold magma_op, refa41_inst, refa41_op in H. discriminate H. Qed.

Lemma refa41_not2043 : ~ @Equation2043 Fin11 refa41_inst.
Proof. unfold Equation2043. intro H. specialize (H F11_0 F11_1). unfold magma_op, refa41_inst, refa41_op in H. discriminate H. Qed.

Lemma refa41_not2044 : ~ @Equation2044 Fin11 refa41_inst.
Proof. unfold Equation2044. intro H. specialize (H F11_0 F11_1). unfold magma_op, refa41_inst, refa41_op in H. discriminate H. Qed.

Lemma refa41_not2050 : ~ @Equation2050 Fin11 refa41_inst.
Proof. unfold Equation2050. intro H. specialize (H F11_0 F11_1). unfold magma_op, refa41_inst, refa41_op in H. discriminate H. Qed.

Lemma refa41_not2053 : ~ @Equation2053 Fin11 refa41_inst.
Proof. unfold Equation2053. intro H. specialize (H F11_0 F11_1). unfold magma_op, refa41_inst, refa41_op in H. discriminate H. Qed.

Lemma refa41_not2054 : ~ @Equation2054 Fin11 refa41_inst.
Proof. unfold Equation2054. intro H. specialize (H F11_0 F11_1). unfold magma_op, refa41_inst, refa41_op in H. discriminate H. Qed.

Lemma refa41_not2060 : ~ @Equation2060 Fin11 refa41_inst.
Proof. unfold Equation2060. intro H. specialize (H F11_0 F11_1). unfold magma_op, refa41_inst, refa41_op in H. discriminate H. Qed.

Lemma refa41_not2061 : ~ @Equation2061 Fin11 refa41_inst.
Proof. unfold Equation2061. intro H. specialize (H F11_0 F11_1). unfold magma_op, refa41_inst, refa41_op in H. discriminate H. Qed.

Lemma refa41_not2063 : ~ @Equation2063 Fin11 refa41_inst.
Proof. unfold Equation2063. intro H. specialize (H F11_0 F11_1). unfold magma_op, refa41_inst, refa41_op in H. discriminate H. Qed.

Lemma refa41_not2064 : ~ @Equation2064 Fin11 refa41_inst.
Proof. unfold Equation2064. intro H. specialize (H F11_0 F11_1). unfold magma_op, refa41_inst, refa41_op in H. discriminate H. Qed.

Lemma refa41_not2087 : ~ @Equation2087 Fin11 refa41_inst.
Proof. unfold Equation2087. intro H. specialize (H F11_0 F11_1). unfold magma_op, refa41_inst, refa41_op in H. discriminate H. Qed.

Lemma refa41_not2088 : ~ @Equation2088 Fin11 refa41_inst.
Proof. unfold Equation2088. intro H. specialize (H F11_0 F11_1). unfold magma_op, refa41_inst, refa41_op in H. discriminate H. Qed.

Lemma refa41_not2091 : ~ @Equation2091 Fin11 refa41_inst.
Proof. unfold Equation2091. intro H. specialize (H F11_0 F11_1). unfold magma_op, refa41_inst, refa41_op in H. discriminate H. Qed.

Lemma refa41_not2097 : ~ @Equation2097 Fin11 refa41_inst.
Proof. unfold Equation2097. intro H. specialize (H F11_0 F11_1). unfold magma_op, refa41_inst, refa41_op in H. discriminate H. Qed.

Lemma refa41_not2098 : ~ @Equation2098 Fin11 refa41_inst.
Proof. unfold Equation2098. intro H. specialize (H F11_0 F11_1). unfold magma_op, refa41_inst, refa41_op in H. discriminate H. Qed.

Lemma refa41_not2100 : ~ @Equation2100 Fin11 refa41_inst.
Proof. unfold Equation2100. intro H. specialize (H F11_0 F11_1). unfold magma_op, refa41_inst, refa41_op in H. discriminate H. Qed.

Lemma refa41_not2101 : ~ @Equation2101 Fin11 refa41_inst.
Proof. unfold Equation2101. intro H. specialize (H F11_0 F11_1). unfold magma_op, refa41_inst, refa41_op in H. discriminate H. Qed.

Lemma refa41_not2124 : ~ @Equation2124 Fin11 refa41_inst.
Proof. unfold Equation2124. intro H. specialize (H F11_0 F11_1). unfold magma_op, refa41_inst, refa41_op in H. discriminate H. Qed.

Lemma refa41_not2125 : ~ @Equation2125 Fin11 refa41_inst.
Proof. unfold Equation2125. intro H. specialize (H F11_0 F11_1). unfold magma_op, refa41_inst, refa41_op in H. discriminate H. Qed.

Lemma refa41_not2127 : ~ @Equation2127 Fin11 refa41_inst.
Proof. unfold Equation2127. intro H. specialize (H F11_0 F11_1). unfold magma_op, refa41_inst, refa41_op in H. discriminate H. Qed.

Lemma refa41_not2128 : ~ @Equation2128 Fin11 refa41_inst.
Proof. unfold Equation2128. intro H. specialize (H F11_0 F11_1). unfold magma_op, refa41_inst, refa41_op in H. discriminate H. Qed.

Lemma refa41_not2134 : ~ @Equation2134 Fin11 refa41_inst.
Proof. unfold Equation2134. intro H. specialize (H F11_0 F11_1). unfold magma_op, refa41_inst, refa41_op in H. discriminate H. Qed.

Lemma refa41_not2240 : ~ @Equation2240 Fin11 refa41_inst.
Proof. unfold Equation2240. intro H. specialize (H F11_0 F11_1). unfold magma_op, refa41_inst, refa41_op in H. discriminate H. Qed.

Lemma refa41_not2241 : ~ @Equation2241 Fin11 refa41_inst.
Proof. unfold Equation2241. intro H. specialize (H F11_0 F11_1). unfold magma_op, refa41_inst, refa41_op in H. discriminate H. Qed.

Lemma refa41_not2243 : ~ @Equation2243 Fin11 refa41_inst.
Proof. unfold Equation2243. intro H. specialize (H F11_0 F11_1). unfold magma_op, refa41_inst, refa41_op in H. discriminate H. Qed.

Lemma refa41_not2244 : ~ @Equation2244 Fin11 refa41_inst.
Proof. unfold Equation2244. intro H. specialize (H F11_0 F11_1). unfold magma_op, refa41_inst, refa41_op in H. discriminate H. Qed.

Lemma refa41_not2246 : ~ @Equation2246 Fin11 refa41_inst.
Proof. unfold Equation2246. intro H. specialize (H F11_0 F11_1). unfold magma_op, refa41_inst, refa41_op in H. discriminate H. Qed.

Lemma refa41_not2247 : ~ @Equation2247 Fin11 refa41_inst.
Proof. unfold Equation2247. intro H. specialize (H F11_0 F11_1). unfold magma_op, refa41_inst, refa41_op in H. discriminate H. Qed.

Lemma refa41_not2253 : ~ @Equation2253 Fin11 refa41_inst.
Proof. unfold Equation2253. intro H. specialize (H F11_0 F11_1). unfold magma_op, refa41_inst, refa41_op in H. discriminate H. Qed.

Lemma refa41_not2254 : ~ @Equation2254 Fin11 refa41_inst.
Proof. unfold Equation2254. intro H. specialize (H F11_0 F11_1). unfold magma_op, refa41_inst, refa41_op in H. discriminate H. Qed.

Lemma refa41_not2256 : ~ @Equation2256 Fin11 refa41_inst.
Proof. unfold Equation2256. intro H. specialize (H F11_0 F11_1). unfold magma_op, refa41_inst, refa41_op in H. discriminate H. Qed.

Lemma refa41_not2263 : ~ @Equation2263 Fin11 refa41_inst.
Proof. unfold Equation2263. intro H. specialize (H F11_0 F11_1). unfold magma_op, refa41_inst, refa41_op in H. discriminate H. Qed.

Lemma refa41_not2266 : ~ @Equation2266 Fin11 refa41_inst.
Proof. unfold Equation2266. intro H. specialize (H F11_0 F11_1). unfold magma_op, refa41_inst, refa41_op in H. discriminate H. Qed.

Lemma refa41_not2290 : ~ @Equation2290 Fin11 refa41_inst.
Proof. unfold Equation2290. intro H. specialize (H F11_0 F11_1). unfold magma_op, refa41_inst, refa41_op in H. discriminate H. Qed.

Lemma refa41_not2291 : ~ @Equation2291 Fin11 refa41_inst.
Proof. unfold Equation2291. intro H. specialize (H F11_0 F11_1). unfold magma_op, refa41_inst, refa41_op in H. discriminate H. Qed.

Lemma refa41_not2293 : ~ @Equation2293 Fin11 refa41_inst.
Proof. unfold Equation2293. intro H. specialize (H F11_0 F11_1). unfold magma_op, refa41_inst, refa41_op in H. discriminate H. Qed.

Lemma refa41_not2294 : ~ @Equation2294 Fin11 refa41_inst.
Proof. unfold Equation2294. intro H. specialize (H F11_0 F11_1). unfold magma_op, refa41_inst, refa41_op in H. discriminate H. Qed.

Lemma refa41_not2300 : ~ @Equation2300 Fin11 refa41_inst.
Proof. unfold Equation2300. intro H. specialize (H F11_0 F11_1). unfold magma_op, refa41_inst, refa41_op in H. discriminate H. Qed.

Lemma refa41_not2301 : ~ @Equation2301 Fin11 refa41_inst.
Proof. unfold Equation2301. intro H. specialize (H F11_0 F11_1). unfold magma_op, refa41_inst, refa41_op in H. discriminate H. Qed.

Lemma refa41_not2303 : ~ @Equation2303 Fin11 refa41_inst.
Proof. unfold Equation2303. intro H. specialize (H F11_0 F11_1). unfold magma_op, refa41_inst, refa41_op in H. discriminate H. Qed.

Lemma refa41_not2327 : ~ @Equation2327 Fin11 refa41_inst.
Proof. unfold Equation2327. intro H. specialize (H F11_0 F11_1). unfold magma_op, refa41_inst, refa41_op in H. discriminate H. Qed.

Lemma refa41_not2328 : ~ @Equation2328 Fin11 refa41_inst.
Proof. unfold Equation2328. intro H. specialize (H F11_0 F11_1). unfold magma_op, refa41_inst, refa41_op in H. discriminate H. Qed.

Lemma refa41_not2330 : ~ @Equation2330 Fin11 refa41_inst.
Proof. unfold Equation2330. intro H. specialize (H F11_0 F11_1). unfold magma_op, refa41_inst, refa41_op in H. discriminate H. Qed.

Lemma refa41_not2337 : ~ @Equation2337 Fin11 refa41_inst.
Proof. unfold Equation2337. intro H. specialize (H F11_0 F11_1). unfold magma_op, refa41_inst, refa41_op in H. discriminate H. Qed.

Lemma refa41_not2338 : ~ @Equation2338 Fin11 refa41_inst.
Proof. unfold Equation2338. intro H. specialize (H F11_0 F11_1). unfold magma_op, refa41_inst, refa41_op in H. discriminate H. Qed.

Lemma refa41_not2340 : ~ @Equation2340 Fin11 refa41_inst.
Proof. unfold Equation2340. intro H. specialize (H F11_0 F11_1). unfold magma_op, refa41_inst, refa41_op in H. discriminate H. Qed.

Lemma refa41_not2443 : ~ @Equation2443 Fin11 refa41_inst.
Proof. unfold Equation2443. intro H. specialize (H F11_0 F11_1). unfold magma_op, refa41_inst, refa41_op in H. discriminate H. Qed.

Lemma refa41_not2444 : ~ @Equation2444 Fin11 refa41_inst.
Proof. unfold Equation2444. intro H. specialize (H F11_0 F11_1). unfold magma_op, refa41_inst, refa41_op in H. discriminate H. Qed.

Lemma refa41_not2446 : ~ @Equation2446 Fin11 refa41_inst.
Proof. unfold Equation2446. intro H. specialize (H F11_0 F11_1). unfold magma_op, refa41_inst, refa41_op in H. discriminate H. Qed.

Lemma refa41_not2447 : ~ @Equation2447 Fin11 refa41_inst.
Proof. unfold Equation2447. intro H. specialize (H F11_0 F11_1). unfold magma_op, refa41_inst, refa41_op in H. discriminate H. Qed.

Lemma refa41_not2449 : ~ @Equation2449 Fin11 refa41_inst.
Proof. unfold Equation2449. intro H. specialize (H F11_0 F11_1). unfold magma_op, refa41_inst, refa41_op in H. discriminate H. Qed.

Lemma refa41_not2456 : ~ @Equation2456 Fin11 refa41_inst.
Proof. unfold Equation2456. intro H. specialize (H F11_0 F11_1). unfold magma_op, refa41_inst, refa41_op in H. discriminate H. Qed.

Lemma refa41_not2457 : ~ @Equation2457 Fin11 refa41_inst.
Proof. unfold Equation2457. intro H. specialize (H F11_0 F11_1). unfold magma_op, refa41_inst, refa41_op in H. discriminate H. Qed.

Lemma refa41_not2459 : ~ @Equation2459 Fin11 refa41_inst.
Proof. unfold Equation2459. intro H. specialize (H F11_0 F11_1). unfold magma_op, refa41_inst, refa41_op in H. discriminate H. Qed.

Lemma refa41_not2466 : ~ @Equation2466 Fin11 refa41_inst.
Proof. unfold Equation2466. intro H. specialize (H F11_0 F11_1). unfold magma_op, refa41_inst, refa41_op in H. discriminate H. Qed.

Lemma refa41_not2467 : ~ @Equation2467 Fin11 refa41_inst.
Proof. unfold Equation2467. intro H. specialize (H F11_0 F11_1). unfold magma_op, refa41_inst, refa41_op in H. discriminate H. Qed.

Lemma refa41_not2469 : ~ @Equation2469 Fin11 refa41_inst.
Proof. unfold Equation2469. intro H. specialize (H F11_0 F11_1). unfold magma_op, refa41_inst, refa41_op in H. discriminate H. Qed.

Lemma refa41_not2493 : ~ @Equation2493 Fin11 refa41_inst.
Proof. unfold Equation2493. intro H. specialize (H F11_0 F11_1). unfold magma_op, refa41_inst, refa41_op in H. discriminate H. Qed.

Lemma refa41_not2496 : ~ @Equation2496 Fin11 refa41_inst.
Proof. unfold Equation2496. intro H. specialize (H F11_0 F11_1). unfold magma_op, refa41_inst, refa41_op in H. discriminate H. Qed.

Lemma refa41_not2497 : ~ @Equation2497 Fin11 refa41_inst.
Proof. unfold Equation2497. intro H. specialize (H F11_0 F11_1). unfold magma_op, refa41_inst, refa41_op in H. discriminate H. Qed.

Lemma refa41_not2503 : ~ @Equation2503 Fin11 refa41_inst.
Proof. unfold Equation2503. intro H. specialize (H F11_0 F11_1). unfold magma_op, refa41_inst, refa41_op in H. discriminate H. Qed.

Lemma refa41_not2504 : ~ @Equation2504 Fin11 refa41_inst.
Proof. unfold Equation2504. intro H. specialize (H F11_0 F11_1). unfold magma_op, refa41_inst, refa41_op in H. discriminate H. Qed.

Lemma refa41_not2506 : ~ @Equation2506 Fin11 refa41_inst.
Proof. unfold Equation2506. intro H. specialize (H F11_0 F11_1). unfold magma_op, refa41_inst, refa41_op in H. discriminate H. Qed.

Lemma refa41_not2530 : ~ @Equation2530 Fin11 refa41_inst.
Proof. unfold Equation2530. intro H. specialize (H F11_0 F11_1). unfold magma_op, refa41_inst, refa41_op in H. discriminate H. Qed.

Lemma refa41_not2531 : ~ @Equation2531 Fin11 refa41_inst.
Proof. unfold Equation2531. intro H. specialize (H F11_0 F11_1). unfold magma_op, refa41_inst, refa41_op in H. discriminate H. Qed.

Lemma refa41_not2533 : ~ @Equation2533 Fin11 refa41_inst.
Proof. unfold Equation2533. intro H. specialize (H F11_0 F11_1). unfold magma_op, refa41_inst, refa41_op in H. discriminate H. Qed.

Lemma refa41_not2534 : ~ @Equation2534 Fin11 refa41_inst.
Proof. unfold Equation2534. intro H. specialize (H F11_0 F11_1). unfold magma_op, refa41_inst, refa41_op in H. discriminate H. Qed.

Lemma refa41_not2540 : ~ @Equation2540 Fin11 refa41_inst.
Proof. unfold Equation2540. intro H. specialize (H F11_0 F11_1). unfold magma_op, refa41_inst, refa41_op in H. discriminate H. Qed.

Lemma refa41_not2541 : ~ @Equation2541 Fin11 refa41_inst.
Proof. unfold Equation2541. intro H. specialize (H F11_0 F11_1). unfold magma_op, refa41_inst, refa41_op in H. discriminate H. Qed.

Lemma refa41_not2543 : ~ @Equation2543 Fin11 refa41_inst.
Proof. unfold Equation2543. intro H. specialize (H F11_0 F11_1). unfold magma_op, refa41_inst, refa41_op in H. discriminate H. Qed.

Lemma refa41_not2646 : ~ @Equation2646 Fin11 refa41_inst.
Proof. unfold Equation2646. intro H. specialize (H F11_0 F11_1). unfold magma_op, refa41_inst, refa41_op in H. discriminate H. Qed.

Lemma refa41_not2647 : ~ @Equation2647 Fin11 refa41_inst.
Proof. unfold Equation2647. intro H. specialize (H F11_0 F11_1). unfold magma_op, refa41_inst, refa41_op in H. discriminate H. Qed.

Lemma refa41_not2649 : ~ @Equation2649 Fin11 refa41_inst.
Proof. unfold Equation2649. intro H. specialize (H F11_0 F11_1). unfold magma_op, refa41_inst, refa41_op in H. discriminate H. Qed.

Lemma refa41_not2650 : ~ @Equation2650 Fin11 refa41_inst.
Proof. unfold Equation2650. intro H. specialize (H F11_0 F11_1). unfold magma_op, refa41_inst, refa41_op in H. discriminate H. Qed.

Lemma refa41_not2652 : ~ @Equation2652 Fin11 refa41_inst.
Proof. unfold Equation2652. intro H. specialize (H F11_0 F11_1). unfold magma_op, refa41_inst, refa41_op in H. discriminate H. Qed.

Lemma refa41_not2659 : ~ @Equation2659 Fin11 refa41_inst.
Proof. unfold Equation2659. intro H. specialize (H F11_0 F11_1). unfold magma_op, refa41_inst, refa41_op in H. discriminate H. Qed.

Lemma refa41_not2660 : ~ @Equation2660 Fin11 refa41_inst.
Proof. unfold Equation2660. intro H. specialize (H F11_0 F11_1). unfold magma_op, refa41_inst, refa41_op in H. discriminate H. Qed.

Lemma refa41_not2662 : ~ @Equation2662 Fin11 refa41_inst.
Proof. unfold Equation2662. intro H. specialize (H F11_0 F11_1). unfold magma_op, refa41_inst, refa41_op in H. discriminate H. Qed.

Lemma refa41_not2669 : ~ @Equation2669 Fin11 refa41_inst.
Proof. unfold Equation2669. intro H. specialize (H F11_0 F11_1). unfold magma_op, refa41_inst, refa41_op in H. discriminate H. Qed.

Lemma refa41_not2670 : ~ @Equation2670 Fin11 refa41_inst.
Proof. unfold Equation2670. intro H. specialize (H F11_0 F11_1). unfold magma_op, refa41_inst, refa41_op in H. discriminate H. Qed.

Lemma refa41_not2672 : ~ @Equation2672 Fin11 refa41_inst.
Proof. unfold Equation2672. intro H. specialize (H F11_0 F11_1). unfold magma_op, refa41_inst, refa41_op in H. discriminate H. Qed.

Lemma refa41_not2696 : ~ @Equation2696 Fin11 refa41_inst.
Proof. unfold Equation2696. intro H. specialize (H F11_0 F11_1). unfold magma_op, refa41_inst, refa41_op in H. discriminate H. Qed.

Lemma refa41_not2697 : ~ @Equation2697 Fin11 refa41_inst.
Proof. unfold Equation2697. intro H. specialize (H F11_0 F11_1). unfold magma_op, refa41_inst, refa41_op in H. discriminate H. Qed.

Lemma refa41_not2699 : ~ @Equation2699 Fin11 refa41_inst.
Proof. unfold Equation2699. intro H. specialize (H F11_0 F11_1). unfold magma_op, refa41_inst, refa41_op in H. discriminate H. Qed.

Lemma refa41_not2700 : ~ @Equation2700 Fin11 refa41_inst.
Proof. unfold Equation2700. intro H. specialize (H F11_0 F11_1). unfold magma_op, refa41_inst, refa41_op in H. discriminate H. Qed.

Lemma refa41_not2706 : ~ @Equation2706 Fin11 refa41_inst.
Proof. unfold Equation2706. intro H. specialize (H F11_0 F11_1). unfold magma_op, refa41_inst, refa41_op in H. discriminate H. Qed.

Lemma refa41_not2709 : ~ @Equation2709 Fin11 refa41_inst.
Proof. unfold Equation2709. intro H. specialize (H F11_0 F11_1). unfold magma_op, refa41_inst, refa41_op in H. discriminate H. Qed.

Lemma refa41_not2710 : ~ @Equation2710 Fin11 refa41_inst.
Proof. unfold Equation2710. intro H. specialize (H F11_0 F11_1). unfold magma_op, refa41_inst, refa41_op in H. discriminate H. Qed.

Lemma refa41_not2733 : ~ @Equation2733 Fin11 refa41_inst.
Proof. unfold Equation2733. intro H. specialize (H F11_0 F11_1). unfold magma_op, refa41_inst, refa41_op in H. discriminate H. Qed.

Lemma refa41_not2734 : ~ @Equation2734 Fin11 refa41_inst.
Proof. unfold Equation2734. intro H. specialize (H F11_0 F11_1). unfold magma_op, refa41_inst, refa41_op in H. discriminate H. Qed.

Lemma refa41_not2736 : ~ @Equation2736 Fin11 refa41_inst.
Proof. unfold Equation2736. intro H. specialize (H F11_0 F11_1). unfold magma_op, refa41_inst, refa41_op in H. discriminate H. Qed.

Lemma refa41_not2743 : ~ @Equation2743 Fin11 refa41_inst.
Proof. unfold Equation2743. intro H. specialize (H F11_0 F11_1). unfold magma_op, refa41_inst, refa41_op in H. discriminate H. Qed.

Lemma refa41_not2744 : ~ @Equation2744 Fin11 refa41_inst.
Proof. unfold Equation2744. intro H. specialize (H F11_0 F11_1). unfold magma_op, refa41_inst, refa41_op in H. discriminate H. Qed.

Lemma refa41_not2746 : ~ @Equation2746 Fin11 refa41_inst.
Proof. unfold Equation2746. intro H. specialize (H F11_0 F11_1). unfold magma_op, refa41_inst, refa41_op in H. discriminate H. Qed.

Lemma refa41_not2849 : ~ @Equation2849 Fin11 refa41_inst.
Proof. unfold Equation2849. intro H. specialize (H F11_0 F11_1). unfold magma_op, refa41_inst, refa41_op in H. discriminate H. Qed.

Lemma refa41_not2852 : ~ @Equation2852 Fin11 refa41_inst.
Proof. unfold Equation2852. intro H. specialize (H F11_0 F11_1). unfold magma_op, refa41_inst, refa41_op in H. discriminate H. Qed.

Lemma refa41_not2853 : ~ @Equation2853 Fin11 refa41_inst.
Proof. unfold Equation2853. intro H. specialize (H F11_0 F11_1). unfold magma_op, refa41_inst, refa41_op in H. discriminate H. Qed.

Lemma refa41_not2855 : ~ @Equation2855 Fin11 refa41_inst.
Proof. unfold Equation2855. intro H. specialize (H F11_0 F11_1). unfold magma_op, refa41_inst, refa41_op in H. discriminate H. Qed.

Lemma refa41_not2856 : ~ @Equation2856 Fin11 refa41_inst.
Proof. unfold Equation2856. intro H. specialize (H F11_0 F11_1). unfold magma_op, refa41_inst, refa41_op in H. discriminate H. Qed.

Lemma refa41_not2862 : ~ @Equation2862 Fin11 refa41_inst.
Proof. unfold Equation2862. intro H. specialize (H F11_0 F11_1). unfold magma_op, refa41_inst, refa41_op in H. discriminate H. Qed.

Lemma refa41_not2863 : ~ @Equation2863 Fin11 refa41_inst.
Proof. unfold Equation2863. intro H. specialize (H F11_0 F11_1). unfold magma_op, refa41_inst, refa41_op in H. discriminate H. Qed.

Lemma refa41_not2865 : ~ @Equation2865 Fin11 refa41_inst.
Proof. unfold Equation2865. intro H. specialize (H F11_0 F11_1). unfold magma_op, refa41_inst, refa41_op in H. discriminate H. Qed.

Lemma refa41_not2866 : ~ @Equation2866 Fin11 refa41_inst.
Proof. unfold Equation2866. intro H. specialize (H F11_0 F11_1). unfold magma_op, refa41_inst, refa41_op in H. discriminate H. Qed.

Lemma refa41_not2872 : ~ @Equation2872 Fin11 refa41_inst.
Proof. unfold Equation2872. intro H. specialize (H F11_0 F11_1). unfold magma_op, refa41_inst, refa41_op in H. discriminate H. Qed.

Lemma refa41_not2873 : ~ @Equation2873 Fin11 refa41_inst.
Proof. unfold Equation2873. intro H. specialize (H F11_0 F11_1). unfold magma_op, refa41_inst, refa41_op in H. discriminate H. Qed.

Lemma refa41_not2875 : ~ @Equation2875 Fin11 refa41_inst.
Proof. unfold Equation2875. intro H. specialize (H F11_0 F11_1). unfold magma_op, refa41_inst, refa41_op in H. discriminate H. Qed.

Lemma refa41_not2899 : ~ @Equation2899 Fin11 refa41_inst.
Proof. unfold Equation2899. intro H. specialize (H F11_0 F11_1). unfold magma_op, refa41_inst, refa41_op in H. discriminate H. Qed.

Lemma refa41_not2900 : ~ @Equation2900 Fin11 refa41_inst.
Proof. unfold Equation2900. intro H. specialize (H F11_0 F11_1). unfold magma_op, refa41_inst, refa41_op in H. discriminate H. Qed.

Lemma refa41_not2902 : ~ @Equation2902 Fin11 refa41_inst.
Proof. unfold Equation2902. intro H. specialize (H F11_0 F11_1). unfold magma_op, refa41_inst, refa41_op in H. discriminate H. Qed.

Lemma refa41_not2903 : ~ @Equation2903 Fin11 refa41_inst.
Proof. unfold Equation2903. intro H. specialize (H F11_0 F11_1). unfold magma_op, refa41_inst, refa41_op in H. discriminate H. Qed.

Lemma refa41_not2909 : ~ @Equation2909 Fin11 refa41_inst.
Proof. unfold Equation2909. intro H. specialize (H F11_0 F11_1). unfold magma_op, refa41_inst, refa41_op in H. discriminate H. Qed.

Lemma refa41_not2912 : ~ @Equation2912 Fin11 refa41_inst.
Proof. unfold Equation2912. intro H. specialize (H F11_0 F11_1). unfold magma_op, refa41_inst, refa41_op in H. discriminate H. Qed.

Lemma refa41_not2936 : ~ @Equation2936 Fin11 refa41_inst.
Proof. unfold Equation2936. intro H. specialize (H F11_0 F11_1). unfold magma_op, refa41_inst, refa41_op in H. discriminate H. Qed.

Lemma refa41_not2939 : ~ @Equation2939 Fin11 refa41_inst.
Proof. unfold Equation2939. intro H. specialize (H F11_0 F11_1). unfold magma_op, refa41_inst, refa41_op in H. discriminate H. Qed.

Lemma refa41_not2940 : ~ @Equation2940 Fin11 refa41_inst.
Proof. unfold Equation2940. intro H. specialize (H F11_0 F11_1). unfold magma_op, refa41_inst, refa41_op in H. discriminate H. Qed.

Lemma refa41_not2946 : ~ @Equation2946 Fin11 refa41_inst.
Proof. unfold Equation2946. intro H. specialize (H F11_0 F11_1). unfold magma_op, refa41_inst, refa41_op in H. discriminate H. Qed.

Lemma refa41_not2947 : ~ @Equation2947 Fin11 refa41_inst.
Proof. unfold Equation2947. intro H. specialize (H F11_0 F11_1). unfold magma_op, refa41_inst, refa41_op in H. discriminate H. Qed.

Lemma refa41_not2949 : ~ @Equation2949 Fin11 refa41_inst.
Proof. unfold Equation2949. intro H. specialize (H F11_0 F11_1). unfold magma_op, refa41_inst, refa41_op in H. discriminate H. Qed.

Lemma refa41_not3052 : ~ @Equation3052 Fin11 refa41_inst.
Proof. unfold Equation3052. intro H. specialize (H F11_0 F11_1). unfold magma_op, refa41_inst, refa41_op in H. discriminate H. Qed.

Lemma refa41_not3055 : ~ @Equation3055 Fin11 refa41_inst.
Proof. unfold Equation3055. intro H. specialize (H F11_0 F11_1). unfold magma_op, refa41_inst, refa41_op in H. discriminate H. Qed.

Lemma refa41_not3056 : ~ @Equation3056 Fin11 refa41_inst.
Proof. unfold Equation3056. intro H. specialize (H F11_0 F11_1). unfold magma_op, refa41_inst, refa41_op in H. discriminate H. Qed.

Lemma refa41_not3058 : ~ @Equation3058 Fin11 refa41_inst.
Proof. unfold Equation3058. intro H. specialize (H F11_0 F11_1). unfold magma_op, refa41_inst, refa41_op in H. discriminate H. Qed.

Lemma refa41_not3065 : ~ @Equation3065 Fin11 refa41_inst.
Proof. unfold Equation3065. intro H. specialize (H F11_0 F11_1). unfold magma_op, refa41_inst, refa41_op in H. discriminate H. Qed.

Lemma refa41_not3066 : ~ @Equation3066 Fin11 refa41_inst.
Proof. unfold Equation3066. intro H. specialize (H F11_0 F11_1). unfold magma_op, refa41_inst, refa41_op in H. discriminate H. Qed.

Lemma refa41_not3068 : ~ @Equation3068 Fin11 refa41_inst.
Proof. unfold Equation3068. intro H. specialize (H F11_0 F11_1). unfold magma_op, refa41_inst, refa41_op in H. discriminate H. Qed.

Lemma refa41_not3069 : ~ @Equation3069 Fin11 refa41_inst.
Proof. unfold Equation3069. intro H. specialize (H F11_0 F11_1). unfold magma_op, refa41_inst, refa41_op in H. discriminate H. Qed.

Lemma refa41_not3075 : ~ @Equation3075 Fin11 refa41_inst.
Proof. unfold Equation3075. intro H. specialize (H F11_0 F11_1). unfold magma_op, refa41_inst, refa41_op in H. discriminate H. Qed.

Lemma refa41_not3078 : ~ @Equation3078 Fin11 refa41_inst.
Proof. unfold Equation3078. intro H. specialize (H F11_0 F11_1). unfold magma_op, refa41_inst, refa41_op in H. discriminate H. Qed.

Lemma refa41_not3079 : ~ @Equation3079 Fin11 refa41_inst.
Proof. unfold Equation3079. intro H. specialize (H F11_0 F11_1). unfold magma_op, refa41_inst, refa41_op in H. discriminate H. Qed.

Lemma refa41_not3102 : ~ @Equation3102 Fin11 refa41_inst.
Proof. unfold Equation3102. intro H. specialize (H F11_0 F11_1). unfold magma_op, refa41_inst, refa41_op in H. discriminate H. Qed.

Lemma refa41_not3103 : ~ @Equation3103 Fin11 refa41_inst.
Proof. unfold Equation3103. intro H. specialize (H F11_0 F11_1). unfold magma_op, refa41_inst, refa41_op in H. discriminate H. Qed.

Lemma refa41_not3105 : ~ @Equation3105 Fin11 refa41_inst.
Proof. unfold Equation3105. intro H. specialize (H F11_0 F11_1). unfold magma_op, refa41_inst, refa41_op in H. discriminate H. Qed.

Lemma refa41_not3106 : ~ @Equation3106 Fin11 refa41_inst.
Proof. unfold Equation3106. intro H. specialize (H F11_0 F11_1). unfold magma_op, refa41_inst, refa41_op in H. discriminate H. Qed.

Lemma refa41_not3112 : ~ @Equation3112 Fin11 refa41_inst.
Proof. unfold Equation3112. intro H. specialize (H F11_0 F11_1). unfold magma_op, refa41_inst, refa41_op in H. discriminate H. Qed.

Lemma refa41_not3115 : ~ @Equation3115 Fin11 refa41_inst.
Proof. unfold Equation3115. intro H. specialize (H F11_0 F11_1). unfold magma_op, refa41_inst, refa41_op in H. discriminate H. Qed.

Lemma refa41_not3116 : ~ @Equation3116 Fin11 refa41_inst.
Proof. unfold Equation3116. intro H. specialize (H F11_0 F11_1). unfold magma_op, refa41_inst, refa41_op in H. discriminate H. Qed.

Lemma refa41_not3139 : ~ @Equation3139 Fin11 refa41_inst.
Proof. unfold Equation3139. intro H. specialize (H F11_0 F11_1). unfold magma_op, refa41_inst, refa41_op in H. discriminate H. Qed.

Lemma refa41_not3140 : ~ @Equation3140 Fin11 refa41_inst.
Proof. unfold Equation3140. intro H. specialize (H F11_0 F11_1). unfold magma_op, refa41_inst, refa41_op in H. discriminate H. Qed.

Lemma refa41_not3142 : ~ @Equation3142 Fin11 refa41_inst.
Proof. unfold Equation3142. intro H. specialize (H F11_0 F11_1). unfold magma_op, refa41_inst, refa41_op in H. discriminate H. Qed.

Lemma refa41_not3143 : ~ @Equation3143 Fin11 refa41_inst.
Proof. unfold Equation3143. intro H. specialize (H F11_0 F11_1). unfold magma_op, refa41_inst, refa41_op in H. discriminate H. Qed.

Lemma refa41_not3149 : ~ @Equation3149 Fin11 refa41_inst.
Proof. unfold Equation3149. intro H. specialize (H F11_0 F11_1). unfold magma_op, refa41_inst, refa41_op in H. discriminate H. Qed.

Lemma refa41_not3150 : ~ @Equation3150 Fin11 refa41_inst.
Proof. unfold Equation3150. intro H. specialize (H F11_0 F11_1). unfold magma_op, refa41_inst, refa41_op in H. discriminate H. Qed.

Lemma refa41_not3152 : ~ @Equation3152 Fin11 refa41_inst.
Proof. unfold Equation3152. intro H. specialize (H F11_0 F11_1). unfold magma_op, refa41_inst, refa41_op in H. discriminate H. Qed.

Lemma refa41_not3254 : ~ @Equation3254 Fin11 refa41_inst.
Proof. unfold Equation3254. intro H. specialize (H F11_0 F11_1). unfold magma_op, refa41_inst, refa41_op in H. discriminate H. Qed.

Lemma refa41_not3255 : ~ @Equation3255 Fin11 refa41_inst.
Proof. unfold Equation3255. intro H. specialize (H F11_0 F11_1). unfold magma_op, refa41_inst, refa41_op in H. discriminate H. Qed.

Lemma refa41_not3256 : ~ @Equation3256 Fin11 refa41_inst.
Proof. unfold Equation3256. intro H. specialize (H F11_0 F11_1). unfold magma_op, refa41_inst, refa41_op in H. discriminate H. Qed.

Lemma refa41_not3258 : ~ @Equation3258 Fin11 refa41_inst.
Proof. unfold Equation3258. intro H. specialize (H F11_0 F11_1). unfold magma_op, refa41_inst, refa41_op in H. discriminate H. Qed.

Lemma refa41_not3259 : ~ @Equation3259 Fin11 refa41_inst.
Proof. unfold Equation3259. intro H. specialize (H F11_0 F11_1). unfold magma_op, refa41_inst, refa41_op in H. discriminate H. Qed.

Lemma refa41_not3261 : ~ @Equation3261 Fin11 refa41_inst.
Proof. unfold Equation3261. intro H. specialize (H F11_0 F11_1). unfold magma_op, refa41_inst, refa41_op in H. discriminate H. Qed.

Lemma refa41_not3262 : ~ @Equation3262 Fin11 refa41_inst.
Proof. unfold Equation3262. intro H. specialize (H F11_0 F11_1). unfold magma_op, refa41_inst, refa41_op in H. discriminate H. Qed.

Lemma refa41_not3268 : ~ @Equation3268 Fin11 refa41_inst.
Proof. unfold Equation3268. intro H. specialize (H F11_0 F11_1). unfold magma_op, refa41_inst, refa41_op in H. discriminate H. Qed.

Lemma refa41_not3269 : ~ @Equation3269 Fin11 refa41_inst.
Proof. unfold Equation3269. intro H. specialize (H F11_0 F11_1). unfold magma_op, refa41_inst, refa41_op in H. discriminate H. Qed.

Lemma refa41_not3271 : ~ @Equation3271 Fin11 refa41_inst.
Proof. unfold Equation3271. intro H. specialize (H F11_0 F11_1). unfold magma_op, refa41_inst, refa41_op in H. discriminate H. Qed.

Lemma refa41_not3272 : ~ @Equation3272 Fin11 refa41_inst.
Proof. unfold Equation3272. intro H. specialize (H F11_0 F11_1). unfold magma_op, refa41_inst, refa41_op in H. discriminate H. Qed.

Lemma refa41_not3278 : ~ @Equation3278 Fin11 refa41_inst.
Proof. unfold Equation3278. intro H. specialize (H F11_0 F11_1). unfold magma_op, refa41_inst, refa41_op in H. discriminate H. Qed.

Lemma refa41_not3279 : ~ @Equation3279 Fin11 refa41_inst.
Proof. unfold Equation3279. intro H. specialize (H F11_0 F11_1). unfold magma_op, refa41_inst, refa41_op in H. discriminate H. Qed.

Lemma refa41_not3281 : ~ @Equation3281 Fin11 refa41_inst.
Proof. unfold Equation3281. intro H. specialize (H F11_0 F11_1). unfold magma_op, refa41_inst, refa41_op in H. discriminate H. Qed.

Lemma refa41_not3306 : ~ @Equation3306 Fin11 refa41_inst.
Proof. unfold Equation3306. intro H. specialize (H F11_0 F11_1). unfold magma_op, refa41_inst, refa41_op in H. discriminate H. Qed.

Lemma refa41_not3308 : ~ @Equation3308 Fin11 refa41_inst.
Proof. unfold Equation3308. intro H. specialize (H F11_0 F11_1). unfold magma_op, refa41_inst, refa41_op in H. discriminate H. Qed.

Lemma refa41_not3309 : ~ @Equation3309 Fin11 refa41_inst.
Proof. unfold Equation3309. intro H. specialize (H F11_0 F11_1). unfold magma_op, refa41_inst, refa41_op in H. discriminate H. Qed.

Lemma refa41_not3315 : ~ @Equation3315 Fin11 refa41_inst.
Proof. unfold Equation3315. intro H. specialize (H F11_0 F11_1). unfold magma_op, refa41_inst, refa41_op in H. discriminate H. Qed.

Lemma refa41_not3316 : ~ @Equation3316 Fin11 refa41_inst.
Proof. unfold Equation3316. intro H. specialize (H F11_0 F11_1). unfold magma_op, refa41_inst, refa41_op in H. discriminate H. Qed.

Lemma refa41_not3318 : ~ @Equation3318 Fin11 refa41_inst.
Proof. unfold Equation3318. intro H. specialize (H F11_0 F11_1). unfold magma_op, refa41_inst, refa41_op in H. discriminate H. Qed.

Lemma refa41_not3343 : ~ @Equation3343 Fin11 refa41_inst.
Proof. unfold Equation3343. intro H. specialize (H F11_0 F11_1). unfold magma_op, refa41_inst, refa41_op in H. discriminate H. Qed.

Lemma refa41_not3345 : ~ @Equation3345 Fin11 refa41_inst.
Proof. unfold Equation3345. intro H. specialize (H F11_0 F11_1). unfold magma_op, refa41_inst, refa41_op in H. discriminate H. Qed.

Lemma refa41_not3346 : ~ @Equation3346 Fin11 refa41_inst.
Proof. unfold Equation3346. intro H. specialize (H F11_0 F11_1). unfold magma_op, refa41_inst, refa41_op in H. discriminate H. Qed.

Lemma refa41_not3352 : ~ @Equation3352 Fin11 refa41_inst.
Proof. unfold Equation3352. intro H. specialize (H F11_0 F11_1). unfold magma_op, refa41_inst, refa41_op in H. discriminate H. Qed.

Lemma refa41_not3353 : ~ @Equation3353 Fin11 refa41_inst.
Proof. unfold Equation3353. intro H. specialize (H F11_0 F11_1). unfold magma_op, refa41_inst, refa41_op in H. discriminate H. Qed.

Lemma refa41_not3355 : ~ @Equation3355 Fin11 refa41_inst.
Proof. unfold Equation3355. intro H. specialize (H F11_0 F11_1). unfold magma_op, refa41_inst, refa41_op in H. discriminate H. Qed.

Lemma refa41_not3457 : ~ @Equation3457 Fin11 refa41_inst.
Proof. unfold Equation3457. intro H. specialize (H F11_0 F11_1). unfold magma_op, refa41_inst, refa41_op in H. discriminate H. Qed.

Lemma refa41_not3458 : ~ @Equation3458 Fin11 refa41_inst.
Proof. unfold Equation3458. intro H. specialize (H F11_0 F11_1). unfold magma_op, refa41_inst, refa41_op in H. discriminate H. Qed.

Lemma refa41_not3459 : ~ @Equation3459 Fin11 refa41_inst.
Proof. unfold Equation3459. intro H. specialize (H F11_0 F11_1). unfold magma_op, refa41_inst, refa41_op in H. discriminate H. Qed.

Lemma refa41_not3461 : ~ @Equation3461 Fin11 refa41_inst.
Proof. unfold Equation3461. intro H. specialize (H F11_0 F11_1). unfold magma_op, refa41_inst, refa41_op in H. discriminate H. Qed.

Lemma refa41_not3462 : ~ @Equation3462 Fin11 refa41_inst.
Proof. unfold Equation3462. intro H. specialize (H F11_0 F11_1). unfold magma_op, refa41_inst, refa41_op in H. discriminate H. Qed.

Lemma refa41_not3464 : ~ @Equation3464 Fin11 refa41_inst.
Proof. unfold Equation3464. intro H. specialize (H F11_0 F11_1). unfold magma_op, refa41_inst, refa41_op in H. discriminate H. Qed.

Lemma refa41_not3465 : ~ @Equation3465 Fin11 refa41_inst.
Proof. unfold Equation3465. intro H. specialize (H F11_0 F11_1). unfold magma_op, refa41_inst, refa41_op in H. discriminate H. Qed.

Lemma refa41_not3472 : ~ @Equation3472 Fin11 refa41_inst.
Proof. unfold Equation3472. intro H. specialize (H F11_0 F11_1). unfold magma_op, refa41_inst, refa41_op in H. discriminate H. Qed.

Lemma refa41_not3474 : ~ @Equation3474 Fin11 refa41_inst.
Proof. unfold Equation3474. intro H. specialize (H F11_0 F11_1). unfold magma_op, refa41_inst, refa41_op in H. discriminate H. Qed.

Lemma refa41_not3475 : ~ @Equation3475 Fin11 refa41_inst.
Proof. unfold Equation3475. intro H. specialize (H F11_0 F11_1). unfold magma_op, refa41_inst, refa41_op in H. discriminate H. Qed.

Lemma refa41_not3481 : ~ @Equation3481 Fin11 refa41_inst.
Proof. unfold Equation3481. intro H. specialize (H F11_0 F11_1). unfold magma_op, refa41_inst, refa41_op in H. discriminate H. Qed.

Lemma refa41_not3482 : ~ @Equation3482 Fin11 refa41_inst.
Proof. unfold Equation3482. intro H. specialize (H F11_0 F11_1). unfold magma_op, refa41_inst, refa41_op in H. discriminate H. Qed.

Lemma refa41_not3484 : ~ @Equation3484 Fin11 refa41_inst.
Proof. unfold Equation3484. intro H. specialize (H F11_0 F11_1). unfold magma_op, refa41_inst, refa41_op in H. discriminate H. Qed.

Lemma refa41_not3509 : ~ @Equation3509 Fin11 refa41_inst.
Proof. unfold Equation3509. intro H. specialize (H F11_0 F11_1). unfold magma_op, refa41_inst, refa41_op in H. discriminate H. Qed.

Lemma refa41_not3511 : ~ @Equation3511 Fin11 refa41_inst.
Proof. unfold Equation3511. intro H. specialize (H F11_0 F11_1). unfold magma_op, refa41_inst, refa41_op in H. discriminate H. Qed.

Lemma refa41_not3512 : ~ @Equation3512 Fin11 refa41_inst.
Proof. unfold Equation3512. intro H. specialize (H F11_0 F11_1). unfold magma_op, refa41_inst, refa41_op in H. discriminate H. Qed.

Lemma refa41_not3518 : ~ @Equation3518 Fin11 refa41_inst.
Proof. unfold Equation3518. intro H. specialize (H F11_0 F11_1). unfold magma_op, refa41_inst, refa41_op in H. discriminate H. Qed.

Lemma refa41_not3519 : ~ @Equation3519 Fin11 refa41_inst.
Proof. unfold Equation3519. intro H. specialize (H F11_0 F11_1). unfold magma_op, refa41_inst, refa41_op in H. discriminate H. Qed.

Lemma refa41_not3521 : ~ @Equation3521 Fin11 refa41_inst.
Proof. unfold Equation3521. intro H. specialize (H F11_0 F11_1). unfold magma_op, refa41_inst, refa41_op in H. discriminate H. Qed.

Lemma refa41_not3546 : ~ @Equation3546 Fin11 refa41_inst.
Proof. unfold Equation3546. intro H. specialize (H F11_0 F11_1). unfold magma_op, refa41_inst, refa41_op in H. discriminate H. Qed.

Lemma refa41_not3548 : ~ @Equation3548 Fin11 refa41_inst.
Proof. unfold Equation3548. intro H. specialize (H F11_0 F11_1). unfold magma_op, refa41_inst, refa41_op in H. discriminate H. Qed.

Lemma refa41_not3549 : ~ @Equation3549 Fin11 refa41_inst.
Proof. unfold Equation3549. intro H. specialize (H F11_0 F11_1). unfold magma_op, refa41_inst, refa41_op in H. discriminate H. Qed.

Lemma refa41_not3555 : ~ @Equation3555 Fin11 refa41_inst.
Proof. unfold Equation3555. intro H. specialize (H F11_0 F11_1). unfold magma_op, refa41_inst, refa41_op in H. discriminate H. Qed.

Lemma refa41_not3556 : ~ @Equation3556 Fin11 refa41_inst.
Proof. unfold Equation3556. intro H. specialize (H F11_0 F11_1). unfold magma_op, refa41_inst, refa41_op in H. discriminate H. Qed.

Lemma refa41_not3558 : ~ @Equation3558 Fin11 refa41_inst.
Proof. unfold Equation3558. intro H. specialize (H F11_0 F11_1). unfold magma_op, refa41_inst, refa41_op in H. discriminate H. Qed.

Lemma refa41_not3660 : ~ @Equation3660 Fin11 refa41_inst.
Proof. unfold Equation3660. intro H. specialize (H F11_0 F11_1). unfold magma_op, refa41_inst, refa41_op in H. discriminate H. Qed.

Lemma refa41_not3661 : ~ @Equation3661 Fin11 refa41_inst.
Proof. unfold Equation3661. intro H. specialize (H F11_0 F11_1). unfold magma_op, refa41_inst, refa41_op in H. discriminate H. Qed.

Lemma refa41_not3662 : ~ @Equation3662 Fin11 refa41_inst.
Proof. unfold Equation3662. intro H. specialize (H F11_0 F11_1). unfold magma_op, refa41_inst, refa41_op in H. discriminate H. Qed.

Lemma refa41_not3664 : ~ @Equation3664 Fin11 refa41_inst.
Proof. unfold Equation3664. intro H. specialize (H F11_0 F11_1). unfold magma_op, refa41_inst, refa41_op in H. discriminate H. Qed.

Lemma refa41_not3665 : ~ @Equation3665 Fin11 refa41_inst.
Proof. unfold Equation3665. intro H. specialize (H F11_0 F11_1). unfold magma_op, refa41_inst, refa41_op in H. discriminate H. Qed.

Lemma refa41_not3667 : ~ @Equation3667 Fin11 refa41_inst.
Proof. unfold Equation3667. intro H. specialize (H F11_0 F11_1). unfold magma_op, refa41_inst, refa41_op in H. discriminate H. Qed.

Lemma refa41_not3668 : ~ @Equation3668 Fin11 refa41_inst.
Proof. unfold Equation3668. intro H. specialize (H F11_0 F11_1). unfold magma_op, refa41_inst, refa41_op in H. discriminate H. Qed.

Lemma refa41_not3674 : ~ @Equation3674 Fin11 refa41_inst.
Proof. unfold Equation3674. intro H. specialize (H F11_0 F11_1). unfold magma_op, refa41_inst, refa41_op in H. discriminate H. Qed.

Lemma refa41_not3675 : ~ @Equation3675 Fin11 refa41_inst.
Proof. unfold Equation3675. intro H. specialize (H F11_0 F11_1). unfold magma_op, refa41_inst, refa41_op in H. discriminate H. Qed.

Lemma refa41_not3677 : ~ @Equation3677 Fin11 refa41_inst.
Proof. unfold Equation3677. intro H. specialize (H F11_0 F11_1). unfold magma_op, refa41_inst, refa41_op in H. discriminate H. Qed.

Lemma refa41_not3678 : ~ @Equation3678 Fin11 refa41_inst.
Proof. unfold Equation3678. intro H. specialize (H F11_0 F11_1). unfold magma_op, refa41_inst, refa41_op in H. discriminate H. Qed.

Lemma refa41_not3684 : ~ @Equation3684 Fin11 refa41_inst.
Proof. unfold Equation3684. intro H. specialize (H F11_0 F11_1). unfold magma_op, refa41_inst, refa41_op in H. discriminate H. Qed.

Lemma refa41_not3685 : ~ @Equation3685 Fin11 refa41_inst.
Proof. unfold Equation3685. intro H. specialize (H F11_0 F11_1). unfold magma_op, refa41_inst, refa41_op in H. discriminate H. Qed.

Lemma refa41_not3687 : ~ @Equation3687 Fin11 refa41_inst.
Proof. unfold Equation3687. intro H. specialize (H F11_0 F11_1). unfold magma_op, refa41_inst, refa41_op in H. discriminate H. Qed.

Lemma refa41_not3712 : ~ @Equation3712 Fin11 refa41_inst.
Proof. unfold Equation3712. intro H. specialize (H F11_0 F11_1). unfold magma_op, refa41_inst, refa41_op in H. discriminate H. Qed.

Lemma refa41_not3714 : ~ @Equation3714 Fin11 refa41_inst.
Proof. unfold Equation3714. intro H. specialize (H F11_0 F11_1). unfold magma_op, refa41_inst, refa41_op in H. discriminate H. Qed.

Lemma refa41_not3721 : ~ @Equation3721 Fin11 refa41_inst.
Proof. unfold Equation3721. intro H. specialize (H F11_0 F11_1). unfold magma_op, refa41_inst, refa41_op in H. discriminate H. Qed.

Lemma refa41_not3725 : ~ @Equation3725 Fin11 refa41_inst.
Proof. unfold Equation3725. intro H. specialize (H F11_0 F11_1). unfold magma_op, refa41_inst, refa41_op in H. discriminate H. Qed.

Lemma refa41_not3748 : ~ @Equation3748 Fin11 refa41_inst.
Proof. unfold Equation3748. intro H. specialize (H F11_0 F11_1). unfold magma_op, refa41_inst, refa41_op in H. discriminate H. Qed.

Lemma refa41_not3752 : ~ @Equation3752 Fin11 refa41_inst.
Proof. unfold Equation3752. intro H. specialize (H F11_0 F11_1). unfold magma_op, refa41_inst, refa41_op in H. discriminate H. Qed.

Lemma refa41_not3759 : ~ @Equation3759 Fin11 refa41_inst.
Proof. unfold Equation3759. intro H. specialize (H F11_0 F11_1). unfold magma_op, refa41_inst, refa41_op in H. discriminate H. Qed.

Lemma refa41_not3761 : ~ @Equation3761 Fin11 refa41_inst.
Proof. unfold Equation3761. intro H. specialize (H F11_0 F11_1). unfold magma_op, refa41_inst, refa41_op in H. discriminate H. Qed.

Lemma refa41_not3864 : ~ @Equation3864 Fin11 refa41_inst.
Proof. unfold Equation3864. intro H. specialize (H F11_0 F11_1). unfold magma_op, refa41_inst, refa41_op in H. discriminate H. Qed.

Lemma refa41_not3865 : ~ @Equation3865 Fin11 refa41_inst.
Proof. unfold Equation3865. intro H. specialize (H F11_0 F11_1). unfold magma_op, refa41_inst, refa41_op in H. discriminate H. Qed.

Lemma refa41_not3867 : ~ @Equation3867 Fin11 refa41_inst.
Proof. unfold Equation3867. intro H. specialize (H F11_0 F11_1). unfold magma_op, refa41_inst, refa41_op in H. discriminate H. Qed.

Lemma refa41_not3868 : ~ @Equation3868 Fin11 refa41_inst.
Proof. unfold Equation3868. intro H. specialize (H F11_0 F11_1). unfold magma_op, refa41_inst, refa41_op in H. discriminate H. Qed.

Lemma refa41_not3870 : ~ @Equation3870 Fin11 refa41_inst.
Proof. unfold Equation3870. intro H. specialize (H F11_0 F11_1). unfold magma_op, refa41_inst, refa41_op in H. discriminate H. Qed.

Lemma refa41_not3871 : ~ @Equation3871 Fin11 refa41_inst.
Proof. unfold Equation3871. intro H. specialize (H F11_0 F11_1). unfold magma_op, refa41_inst, refa41_op in H. discriminate H. Qed.

Lemma refa41_not3877 : ~ @Equation3877 Fin11 refa41_inst.
Proof. unfold Equation3877. intro H. specialize (H F11_0 F11_1). unfold magma_op, refa41_inst, refa41_op in H. discriminate H. Qed.

Lemma refa41_not3878 : ~ @Equation3878 Fin11 refa41_inst.
Proof. unfold Equation3878. intro H. specialize (H F11_0 F11_1). unfold magma_op, refa41_inst, refa41_op in H. discriminate H. Qed.

Lemma refa41_not3880 : ~ @Equation3880 Fin11 refa41_inst.
Proof. unfold Equation3880. intro H. specialize (H F11_0 F11_1). unfold magma_op, refa41_inst, refa41_op in H. discriminate H. Qed.

Lemma refa41_not3881 : ~ @Equation3881 Fin11 refa41_inst.
Proof. unfold Equation3881. intro H. specialize (H F11_0 F11_1). unfold magma_op, refa41_inst, refa41_op in H. discriminate H. Qed.

Lemma refa41_not3887 : ~ @Equation3887 Fin11 refa41_inst.
Proof. unfold Equation3887. intro H. specialize (H F11_0 F11_1). unfold magma_op, refa41_inst, refa41_op in H. discriminate H. Qed.

Lemma refa41_not3888 : ~ @Equation3888 Fin11 refa41_inst.
Proof. unfold Equation3888. intro H. specialize (H F11_0 F11_1). unfold magma_op, refa41_inst, refa41_op in H. discriminate H. Qed.

Lemma refa41_not3890 : ~ @Equation3890 Fin11 refa41_inst.
Proof. unfold Equation3890. intro H. specialize (H F11_0 F11_1). unfold magma_op, refa41_inst, refa41_op in H. discriminate H. Qed.

Lemma refa41_not3917 : ~ @Equation3917 Fin11 refa41_inst.
Proof. unfold Equation3917. intro H. specialize (H F11_0 F11_1). unfold magma_op, refa41_inst, refa41_op in H. discriminate H. Qed.

Lemma refa41_not3918 : ~ @Equation3918 Fin11 refa41_inst.
Proof. unfold Equation3918. intro H. specialize (H F11_0 F11_1). unfold magma_op, refa41_inst, refa41_op in H. discriminate H. Qed.

Lemma refa41_not3924 : ~ @Equation3924 Fin11 refa41_inst.
Proof. unfold Equation3924. intro H. specialize (H F11_0 F11_1). unfold magma_op, refa41_inst, refa41_op in H. discriminate H. Qed.

Lemma refa41_not3925 : ~ @Equation3925 Fin11 refa41_inst.
Proof. unfold Equation3925. intro H. specialize (H F11_0 F11_1). unfold magma_op, refa41_inst, refa41_op in H. discriminate H. Qed.

Lemma refa41_not3927 : ~ @Equation3927 Fin11 refa41_inst.
Proof. unfold Equation3927. intro H. specialize (H F11_0 F11_1). unfold magma_op, refa41_inst, refa41_op in H. discriminate H. Qed.

Lemma refa41_not3928 : ~ @Equation3928 Fin11 refa41_inst.
Proof. unfold Equation3928. intro H. specialize (H F11_0 F11_1). unfold magma_op, refa41_inst, refa41_op in H. discriminate H. Qed.

Lemma refa41_not3951 : ~ @Equation3951 Fin11 refa41_inst.
Proof. unfold Equation3951. intro H. specialize (H F11_0 F11_1). unfold magma_op, refa41_inst, refa41_op in H. discriminate H. Qed.

Lemma refa41_not3952 : ~ @Equation3952 Fin11 refa41_inst.
Proof. unfold Equation3952. intro H. specialize (H F11_0 F11_1). unfold magma_op, refa41_inst, refa41_op in H. discriminate H. Qed.

Lemma refa41_not3954 : ~ @Equation3954 Fin11 refa41_inst.
Proof. unfold Equation3954. intro H. specialize (H F11_0 F11_1). unfold magma_op, refa41_inst, refa41_op in H. discriminate H. Qed.

Lemma refa41_not3955 : ~ @Equation3955 Fin11 refa41_inst.
Proof. unfold Equation3955. intro H. specialize (H F11_0 F11_1). unfold magma_op, refa41_inst, refa41_op in H. discriminate H. Qed.

Lemma refa41_not3961 : ~ @Equation3961 Fin11 refa41_inst.
Proof. unfold Equation3961. intro H. specialize (H F11_0 F11_1). unfold magma_op, refa41_inst, refa41_op in H. discriminate H. Qed.

Lemma refa41_not3962 : ~ @Equation3962 Fin11 refa41_inst.
Proof. unfold Equation3962. intro H. specialize (H F11_0 F11_1). unfold magma_op, refa41_inst, refa41_op in H. discriminate H. Qed.

Lemma refa41_not4066 : ~ @Equation4066 Fin11 refa41_inst.
Proof. unfold Equation4066. intro H. specialize (H F11_0 F11_1). unfold magma_op, refa41_inst, refa41_op in H. discriminate H. Qed.

Lemma refa41_not4067 : ~ @Equation4067 Fin11 refa41_inst.
Proof. unfold Equation4067. intro H. specialize (H F11_0 F11_1). unfold magma_op, refa41_inst, refa41_op in H. discriminate H. Qed.

Lemma refa41_not4068 : ~ @Equation4068 Fin11 refa41_inst.
Proof. unfold Equation4068. intro H. specialize (H F11_0 F11_1). unfold magma_op, refa41_inst, refa41_op in H. discriminate H. Qed.

Lemma refa41_not4070 : ~ @Equation4070 Fin11 refa41_inst.
Proof. unfold Equation4070. intro H. specialize (H F11_0 F11_1). unfold magma_op, refa41_inst, refa41_op in H. discriminate H. Qed.

Lemma refa41_not4071 : ~ @Equation4071 Fin11 refa41_inst.
Proof. unfold Equation4071. intro H. specialize (H F11_0 F11_1). unfold magma_op, refa41_inst, refa41_op in H. discriminate H. Qed.

Lemma refa41_not4073 : ~ @Equation4073 Fin11 refa41_inst.
Proof. unfold Equation4073. intro H. specialize (H F11_0 F11_1). unfold magma_op, refa41_inst, refa41_op in H. discriminate H. Qed.

Lemma refa41_not4074 : ~ @Equation4074 Fin11 refa41_inst.
Proof. unfold Equation4074. intro H. specialize (H F11_0 F11_1). unfold magma_op, refa41_inst, refa41_op in H. discriminate H. Qed.

Lemma refa41_not4080 : ~ @Equation4080 Fin11 refa41_inst.
Proof. unfold Equation4080. intro H. specialize (H F11_0 F11_1). unfold magma_op, refa41_inst, refa41_op in H. discriminate H. Qed.

Lemma refa41_not4081 : ~ @Equation4081 Fin11 refa41_inst.
Proof. unfold Equation4081. intro H. specialize (H F11_0 F11_1). unfold magma_op, refa41_inst, refa41_op in H. discriminate H. Qed.

Lemma refa41_not4083 : ~ @Equation4083 Fin11 refa41_inst.
Proof. unfold Equation4083. intro H. specialize (H F11_0 F11_1). unfold magma_op, refa41_inst, refa41_op in H. discriminate H. Qed.

Lemma refa41_not4084 : ~ @Equation4084 Fin11 refa41_inst.
Proof. unfold Equation4084. intro H. specialize (H F11_0 F11_1). unfold magma_op, refa41_inst, refa41_op in H. discriminate H. Qed.

Lemma refa41_not4090 : ~ @Equation4090 Fin11 refa41_inst.
Proof. unfold Equation4090. intro H. specialize (H F11_0 F11_1). unfold magma_op, refa41_inst, refa41_op in H. discriminate H. Qed.

Lemma refa41_not4091 : ~ @Equation4091 Fin11 refa41_inst.
Proof. unfold Equation4091. intro H. specialize (H F11_0 F11_1). unfold magma_op, refa41_inst, refa41_op in H. discriminate H. Qed.

Lemma refa41_not4093 : ~ @Equation4093 Fin11 refa41_inst.
Proof. unfold Equation4093. intro H. specialize (H F11_0 F11_1). unfold magma_op, refa41_inst, refa41_op in H. discriminate H. Qed.

Lemma refa41_not4120 : ~ @Equation4120 Fin11 refa41_inst.
Proof. unfold Equation4120. intro H. specialize (H F11_0 F11_1). unfold magma_op, refa41_inst, refa41_op in H. discriminate H. Qed.

Lemma refa41_not4121 : ~ @Equation4121 Fin11 refa41_inst.
Proof. unfold Equation4121. intro H. specialize (H F11_0 F11_1). unfold magma_op, refa41_inst, refa41_op in H. discriminate H. Qed.

Lemma refa41_not4127 : ~ @Equation4127 Fin11 refa41_inst.
Proof. unfold Equation4127. intro H. specialize (H F11_0 F11_1). unfold magma_op, refa41_inst, refa41_op in H. discriminate H. Qed.

Lemma refa41_not4128 : ~ @Equation4128 Fin11 refa41_inst.
Proof. unfold Equation4128. intro H. specialize (H F11_0 F11_1). unfold magma_op, refa41_inst, refa41_op in H. discriminate H. Qed.

Lemma refa41_not4130 : ~ @Equation4130 Fin11 refa41_inst.
Proof. unfold Equation4130. intro H. specialize (H F11_0 F11_1). unfold magma_op, refa41_inst, refa41_op in H. discriminate H. Qed.

Lemma refa41_not4131 : ~ @Equation4131 Fin11 refa41_inst.
Proof. unfold Equation4131. intro H. specialize (H F11_0 F11_1). unfold magma_op, refa41_inst, refa41_op in H. discriminate H. Qed.

Lemma refa41_not4154 : ~ @Equation4154 Fin11 refa41_inst.
Proof. unfold Equation4154. intro H. specialize (H F11_0 F11_1). unfold magma_op, refa41_inst, refa41_op in H. discriminate H. Qed.

Lemma refa41_not4155 : ~ @Equation4155 Fin11 refa41_inst.
Proof. unfold Equation4155. intro H. specialize (H F11_0 F11_1). unfold magma_op, refa41_inst, refa41_op in H. discriminate H. Qed.

Lemma refa41_not4157 : ~ @Equation4157 Fin11 refa41_inst.
Proof. unfold Equation4157. intro H. specialize (H F11_0 F11_1). unfold magma_op, refa41_inst, refa41_op in H. discriminate H. Qed.

Lemma refa41_not4158 : ~ @Equation4158 Fin11 refa41_inst.
Proof. unfold Equation4158. intro H. specialize (H F11_0 F11_1). unfold magma_op, refa41_inst, refa41_op in H. discriminate H. Qed.

Lemma refa41_not4164 : ~ @Equation4164 Fin11 refa41_inst.
Proof. unfold Equation4164. intro H. specialize (H F11_0 F11_1). unfold magma_op, refa41_inst, refa41_op in H. discriminate H. Qed.

Lemma refa41_not4165 : ~ @Equation4165 Fin11 refa41_inst.
Proof. unfold Equation4165. intro H. specialize (H F11_0 F11_1). unfold magma_op, refa41_inst, refa41_op in H. discriminate H. Qed.

Lemma refa41_not4268 : ~ @Equation4268 Fin11 refa41_inst.
Proof. unfold Equation4268. intro H. specialize (H F11_0 F11_1). unfold magma_op, refa41_inst, refa41_op in H. discriminate H. Qed.

Lemma refa41_not4269 : ~ @Equation4269 Fin11 refa41_inst.
Proof. unfold Equation4269. intro H. specialize (H F11_0 F11_1). unfold magma_op, refa41_inst, refa41_op in H. discriminate H. Qed.

Lemma refa41_not4270 : ~ @Equation4270 Fin11 refa41_inst.
Proof. unfold Equation4270. intro H. specialize (H F11_0 F11_1). unfold magma_op, refa41_inst, refa41_op in H. discriminate H. Qed.

Lemma refa41_not4272 : ~ @Equation4272 Fin11 refa41_inst.
Proof. unfold Equation4272. intro H. specialize (H F11_0 F11_1). unfold magma_op, refa41_inst, refa41_op in H. discriminate H. Qed.

Lemma refa41_not4273 : ~ @Equation4273 Fin11 refa41_inst.
Proof. unfold Equation4273. intro H. specialize (H F11_0 F11_1). unfold magma_op, refa41_inst, refa41_op in H. discriminate H. Qed.

Lemma refa41_not4275 : ~ @Equation4275 Fin11 refa41_inst.
Proof. unfold Equation4275. intro H. specialize (H F11_0 F11_1). unfold magma_op, refa41_inst, refa41_op in H. discriminate H. Qed.

Lemma refa41_not4276 : ~ @Equation4276 Fin11 refa41_inst.
Proof. unfold Equation4276. intro H. specialize (H F11_0 F11_1). unfold magma_op, refa41_inst, refa41_op in H. discriminate H. Qed.

Lemma refa41_not4284 : ~ @Equation4284 Fin11 refa41_inst.
Proof. unfold Equation4284. intro H. specialize (H F11_0 F11_1). unfold magma_op, refa41_inst, refa41_op in H. discriminate H. Qed.

Lemma refa41_not4290 : ~ @Equation4290 Fin11 refa41_inst.
Proof. unfold Equation4290. intro H. specialize (H F11_0 F11_1). unfold magma_op, refa41_inst, refa41_op in H. discriminate H. Qed.

Lemma refa41_not4291 : ~ @Equation4291 Fin11 refa41_inst.
Proof. unfold Equation4291. intro H. specialize (H F11_0 F11_1). unfold magma_op, refa41_inst, refa41_op in H. discriminate H. Qed.

Lemma refa41_not4293 : ~ @Equation4293 Fin11 refa41_inst.
Proof. unfold Equation4293. intro H. specialize (H F11_0 F11_1). unfold magma_op, refa41_inst, refa41_op in H. discriminate H. Qed.

Lemma refa41_not4314 : ~ @Equation4314 Fin11 refa41_inst.
Proof. unfold Equation4314. intro H. specialize (H F11_0 F11_1). unfold magma_op, refa41_inst, refa41_op in H. discriminate H. Qed.

Lemma refa41_not4320 : ~ @Equation4320 Fin11 refa41_inst.
Proof. unfold Equation4320. intro H. specialize (H F11_0 F11_1). unfold magma_op, refa41_inst, refa41_op in H. discriminate H. Qed.

Lemma refa41_not4321 : ~ @Equation4321 Fin11 refa41_inst.
Proof. unfold Equation4321. intro H. specialize (H F11_0 F11_1). unfold magma_op, refa41_inst, refa41_op in H. discriminate H. Qed.

Lemma refa41_not4396 : ~ @Equation4396 Fin11 refa41_inst.
Proof. unfold Equation4396. intro H. specialize (H F11_0 F11_1). unfold magma_op, refa41_inst, refa41_op in H. discriminate H. Qed.

Lemma refa41_not4399 : ~ @Equation4399 Fin11 refa41_inst.
Proof. unfold Equation4399. intro H. specialize (H F11_0 F11_1). unfold magma_op, refa41_inst, refa41_op in H. discriminate H. Qed.

Lemma refa41_not4406 : ~ @Equation4406 Fin11 refa41_inst.
Proof. unfold Equation4406. intro H. specialize (H F11_0 F11_1). unfold magma_op, refa41_inst, refa41_op in H. discriminate H. Qed.

Lemma refa41_not4408 : ~ @Equation4408 Fin11 refa41_inst.
Proof. unfold Equation4408. intro H. specialize (H F11_0 F11_1). unfold magma_op, refa41_inst, refa41_op in H. discriminate H. Qed.

Lemma refa41_not4433 : ~ @Equation4433 Fin11 refa41_inst.
Proof. unfold Equation4433. intro H. specialize (H F11_0 F11_1). unfold magma_op, refa41_inst, refa41_op in H. discriminate H. Qed.

Lemma refa41_not4436 : ~ @Equation4436 Fin11 refa41_inst.
Proof. unfold Equation4436. intro H. specialize (H F11_0 F11_1). unfold magma_op, refa41_inst, refa41_op in H. discriminate H. Qed.

Lemma refa41_not4443 : ~ @Equation4443 Fin11 refa41_inst.
Proof. unfold Equation4443. intro H. specialize (H F11_0 F11_1). unfold magma_op, refa41_inst, refa41_op in H. discriminate H. Qed.

Lemma refa41_not4445 : ~ @Equation4445 Fin11 refa41_inst.
Proof. unfold Equation4445. intro H. specialize (H F11_0 F11_1). unfold magma_op, refa41_inst, refa41_op in H. discriminate H. Qed.

Lemma refa41_not4472 : ~ @Equation4472 Fin11 refa41_inst.
Proof. unfold Equation4472. intro H. specialize (H F11_0 F11_1). unfold magma_op, refa41_inst, refa41_op in H. discriminate H. Qed.

Lemma refa41_not4473 : ~ @Equation4473 Fin11 refa41_inst.
Proof. unfold Equation4473. intro H. specialize (H F11_0 F11_1). unfold magma_op, refa41_inst, refa41_op in H. discriminate H. Qed.

Lemma refa41_not4479 : ~ @Equation4479 Fin11 refa41_inst.
Proof. unfold Equation4479. intro H. specialize (H F11_0 F11_1). unfold magma_op, refa41_inst, refa41_op in H. discriminate H. Qed.

Lemma refa41_not4480 : ~ @Equation4480 Fin11 refa41_inst.
Proof. unfold Equation4480. intro H. specialize (H F11_0 F11_1). unfold magma_op, refa41_inst, refa41_op in H. discriminate H. Qed.

Lemma refa41_not4583 : ~ @Equation4583 Fin11 refa41_inst.
Proof. unfold Equation4583. intro H. specialize (H F11_0 F11_1). unfold magma_op, refa41_inst, refa41_op in H. discriminate H. Qed.

Lemma refa41_not4584 : ~ @Equation4584 Fin11 refa41_inst.
Proof. unfold Equation4584. intro H. specialize (H F11_0 F11_1). unfold magma_op, refa41_inst, refa41_op in H. discriminate H. Qed.

Lemma refa41_not4585 : ~ @Equation4585 Fin11 refa41_inst.
Proof. unfold Equation4585. intro H. specialize (H F11_0 F11_1). unfold magma_op, refa41_inst, refa41_op in H. discriminate H. Qed.

Lemma refa41_not4587 : ~ @Equation4587 Fin11 refa41_inst.
Proof. unfold Equation4587. intro H. specialize (H F11_0 F11_1). unfold magma_op, refa41_inst, refa41_op in H. discriminate H. Qed.

Lemma refa41_not4588 : ~ @Equation4588 Fin11 refa41_inst.
Proof. unfold Equation4588. intro H. specialize (H F11_0 F11_1). unfold magma_op, refa41_inst, refa41_op in H. discriminate H. Qed.

Lemma refa41_not4590 : ~ @Equation4590 Fin11 refa41_inst.
Proof. unfold Equation4590. intro H. specialize (H F11_0 F11_1). unfold magma_op, refa41_inst, refa41_op in H. discriminate H. Qed.

Lemma refa41_not4591 : ~ @Equation4591 Fin11 refa41_inst.
Proof. unfold Equation4591. intro H. specialize (H F11_0 F11_1). unfold magma_op, refa41_inst, refa41_op in H. discriminate H. Qed.

Lemma refa41_not4598 : ~ @Equation4598 Fin11 refa41_inst.
Proof. unfold Equation4598. intro H. specialize (H F11_0 F11_1). unfold magma_op, refa41_inst, refa41_op in H. discriminate H. Qed.

Lemma refa41_not4599 : ~ @Equation4599 Fin11 refa41_inst.
Proof. unfold Equation4599. intro H. specialize (H F11_0 F11_1). unfold magma_op, refa41_inst, refa41_op in H. discriminate H. Qed.

Lemma refa41_not4605 : ~ @Equation4605 Fin11 refa41_inst.
Proof. unfold Equation4605. intro H. specialize (H F11_0 F11_1). unfold magma_op, refa41_inst, refa41_op in H. discriminate H. Qed.

Lemma refa41_not4606 : ~ @Equation4606 Fin11 refa41_inst.
Proof. unfold Equation4606. intro H. specialize (H F11_0 F11_1). unfold magma_op, refa41_inst, refa41_op in H. discriminate H. Qed.

Lemma refa41_not4629 : ~ @Equation4629 Fin11 refa41_inst.
Proof. unfold Equation4629. intro H. specialize (H F11_0 F11_1). unfold magma_op, refa41_inst, refa41_op in H. discriminate H. Qed.

Lemma refa41_not4636 : ~ @Equation4636 Fin11 refa41_inst.
Proof. unfold Equation4636. intro H. specialize (H F11_0 F11_1). unfold magma_op, refa41_inst, refa41_op in H. discriminate H. Qed.

Lemma refa41_not4658 : ~ @Equation4658 Fin11 refa41_inst.
Proof. unfold Equation4658. intro H. specialize (H F11_0 F11_1). unfold magma_op, refa41_inst, refa41_op in H. discriminate H. Qed.

(** ---- refa410 (Fin4) ---- *)

Definition refa410_op (x y : Fin4) : Fin4 :=
  match x, y with
  | F4_0, F4_0 => F4_3 | F4_0, F4_1 => F4_1 | F4_0, F4_2 => F4_3 | F4_0, F4_3 => F4_3
  | F4_1, F4_0 => F4_3 | F4_1, F4_1 => F4_3 | F4_1, F4_2 => F4_2 | F4_1, F4_3 => F4_3
  | F4_2, F4_0 => F4_0 | F4_2, F4_1 => F4_3 | F4_2, F4_2 => F4_3 | F4_2, F4_3 => F4_3
  | F4_3, F4_0 => F4_2 | F4_3, F4_1 => F4_0 | F4_3, F4_2 => F4_1 | F4_3, F4_3 => F4_3
  end.

#[local] Instance refa410_inst : Magma Fin4 := {| magma_op := refa410_op |}.

Lemma refa410_sat2990 : @Equation2990 Fin4 refa410_inst.
Proof. unfold Equation2990, magma_op, refa410_inst, refa410_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa410_sat3302 : @Equation3302 Fin4 refa410_inst.
Proof. unfold Equation3302, magma_op, refa410_inst, refa410_op. intros x y z w. destruct x, y, z, w; reflexivity. Qed.

Lemma refa410_not47 : ~ @Equation47 Fin4 refa410_inst.
Proof. unfold Equation47. intro H. specialize (H F4_0). unfold magma_op, refa410_inst, refa410_op in H. discriminate H. Qed.

Lemma refa410_not99 : ~ @Equation99 Fin4 refa410_inst.
Proof. unfold Equation99. intro H. specialize (H F4_0). unfold magma_op, refa410_inst, refa410_op in H. discriminate H. Qed.

Lemma refa410_not151 : ~ @Equation151 Fin4 refa410_inst.
Proof. unfold Equation151. intro H. specialize (H F4_0). unfold magma_op, refa410_inst, refa410_op in H. discriminate H. Qed.

Lemma refa410_not203 : ~ @Equation203 Fin4 refa410_inst.
Proof. unfold Equation203. intro H. specialize (H F4_0). unfold magma_op, refa410_inst, refa410_op in H. discriminate H. Qed.

Lemma refa410_not283 : ~ @Equation283 Fin4 refa410_inst.
Proof. unfold Equation283. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa410_inst, refa410_op in H. discriminate H. Qed.

Lemma refa410_not411 : ~ @Equation411 Fin4 refa410_inst.
Proof. unfold Equation411. intro H. specialize (H F4_0). unfold magma_op, refa410_inst, refa410_op in H. discriminate H. Qed.

Lemma refa410_not614 : ~ @Equation614 Fin4 refa410_inst.
Proof. unfold Equation614. intro H. specialize (H F4_0). unfold magma_op, refa410_inst, refa410_op in H. discriminate H. Qed.

Lemma refa410_not817 : ~ @Equation817 Fin4 refa410_inst.
Proof. unfold Equation817. intro H. specialize (H F4_0). unfold magma_op, refa410_inst, refa410_op in H. discriminate H. Qed.

Lemma refa410_not1020 : ~ @Equation1020 Fin4 refa410_inst.
Proof. unfold Equation1020. intro H. specialize (H F4_0). unfold magma_op, refa410_inst, refa410_op in H. discriminate H. Qed.

Lemma refa410_not1223 : ~ @Equation1223 Fin4 refa410_inst.
Proof. unfold Equation1223. intro H. specialize (H F4_0). unfold magma_op, refa410_inst, refa410_op in H. discriminate H. Qed.

Lemma refa410_not1426 : ~ @Equation1426 Fin4 refa410_inst.
Proof. unfold Equation1426. intro H. specialize (H F4_0). unfold magma_op, refa410_inst, refa410_op in H. discriminate H. Qed.

Lemma refa410_not1629 : ~ @Equation1629 Fin4 refa410_inst.
Proof. unfold Equation1629. intro H. specialize (H F4_0). unfold magma_op, refa410_inst, refa410_op in H. discriminate H. Qed.

Lemma refa410_not1832 : ~ @Equation1832 Fin4 refa410_inst.
Proof. unfold Equation1832. intro H. specialize (H F4_0). unfold magma_op, refa410_inst, refa410_op in H. discriminate H. Qed.

Lemma refa410_not2035 : ~ @Equation2035 Fin4 refa410_inst.
Proof. unfold Equation2035. intro H. specialize (H F4_0). unfold magma_op, refa410_inst, refa410_op in H. discriminate H. Qed.

Lemma refa410_not2238 : ~ @Equation2238 Fin4 refa410_inst.
Proof. unfold Equation2238. intro H. specialize (H F4_0). unfold magma_op, refa410_inst, refa410_op in H. discriminate H. Qed.

Lemma refa410_not2441 : ~ @Equation2441 Fin4 refa410_inst.
Proof. unfold Equation2441. intro H. specialize (H F4_0). unfold magma_op, refa410_inst, refa410_op in H. discriminate H. Qed.

Lemma refa410_not2644 : ~ @Equation2644 Fin4 refa410_inst.
Proof. unfold Equation2644. intro H. specialize (H F4_0). unfold magma_op, refa410_inst, refa410_op in H. discriminate H. Qed.

Lemma refa410_not2849 : ~ @Equation2849 Fin4 refa410_inst.
Proof. unfold Equation2849. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa410_inst, refa410_op in H. discriminate H. Qed.

Lemma refa410_not2852 : ~ @Equation2852 Fin4 refa410_inst.
Proof. unfold Equation2852. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa410_inst, refa410_op in H. discriminate H. Qed.

Lemma refa410_not2855 : ~ @Equation2855 Fin4 refa410_inst.
Proof. unfold Equation2855. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa410_inst, refa410_op in H. discriminate H. Qed.

Lemma refa410_not2865 : ~ @Equation2865 Fin4 refa410_inst.
Proof. unfold Equation2865. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa410_inst, refa410_op in H. discriminate H. Qed.

Lemma refa410_not2875 : ~ @Equation2875 Fin4 refa410_inst.
Proof. unfold Equation2875. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa410_inst, refa410_op in H. discriminate H. Qed.

Lemma refa410_not2902 : ~ @Equation2902 Fin4 refa410_inst.
Proof. unfold Equation2902. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa410_inst, refa410_op in H. discriminate H. Qed.

Lemma refa410_not2912 : ~ @Equation2912 Fin4 refa410_inst.
Proof. unfold Equation2912. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa410_inst, refa410_op in H. discriminate H. Qed.

Lemma refa410_not2939 : ~ @Equation2939 Fin4 refa410_inst.
Proof. unfold Equation2939. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa410_inst, refa410_op in H. discriminate H. Qed.

Lemma refa410_not2949 : ~ @Equation2949 Fin4 refa410_inst.
Proof. unfold Equation2949. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa410_inst, refa410_op in H. discriminate H. Qed.

Lemma refa410_not3050 : ~ @Equation3050 Fin4 refa410_inst.
Proof. unfold Equation3050. intro H. specialize (H F4_0). unfold magma_op, refa410_inst, refa410_op in H. discriminate H. Qed.

Lemma refa410_not3261 : ~ @Equation3261 Fin4 refa410_inst.
Proof. unfold Equation3261. intro H. specialize (H F4_0 F4_3). unfold magma_op, refa410_inst, refa410_op in H. discriminate H. Qed.

Lemma refa410_not3269 : ~ @Equation3269 Fin4 refa410_inst.
Proof. unfold Equation3269. intro H. specialize (H F4_3 F4_0). unfold magma_op, refa410_inst, refa410_op in H. discriminate H. Qed.

Lemma refa410_not3281 : ~ @Equation3281 Fin4 refa410_inst.
Proof. unfold Equation3281. intro H. specialize (H F4_0 F4_2). unfold magma_op, refa410_inst, refa410_op in H. discriminate H. Qed.

Lemma refa410_not3306 : ~ @Equation3306 Fin4 refa410_inst.
Proof. unfold Equation3306. intro H. specialize (H F4_3 F4_0). unfold magma_op, refa410_inst, refa410_op in H. discriminate H. Qed.

Lemma refa410_not3309 : ~ @Equation3309 Fin4 refa410_inst.
Proof. unfold Equation3309. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa410_inst, refa410_op in H. discriminate H. Qed.

Lemma refa410_not3316 : ~ @Equation3316 Fin4 refa410_inst.
Proof. unfold Equation3316. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa410_inst, refa410_op in H. discriminate H. Qed.

Lemma refa410_not3319 : ~ @Equation3319 Fin4 refa410_inst.
Proof. unfold Equation3319. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa410_inst, refa410_op in H. discriminate H. Qed.

Lemma refa410_not3343 : ~ @Equation3343 Fin4 refa410_inst.
Proof. unfold Equation3343. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa410_inst, refa410_op in H. discriminate H. Qed.

Lemma refa410_not3346 : ~ @Equation3346 Fin4 refa410_inst.
Proof. unfold Equation3346. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa410_inst, refa410_op in H. discriminate H. Qed.

Lemma refa410_not3353 : ~ @Equation3353 Fin4 refa410_inst.
Proof. unfold Equation3353. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa410_inst, refa410_op in H. discriminate H. Qed.

Lemma refa410_not3471 : ~ @Equation3471 Fin4 refa410_inst.
Proof. unfold Equation3471. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa410_inst, refa410_op in H. discriminate H. Qed.

Lemma refa410_not3474 : ~ @Equation3474 Fin4 refa410_inst.
Proof. unfold Equation3474. intro H. specialize (H F4_0 F4_3). unfold magma_op, refa410_inst, refa410_op in H. discriminate H. Qed.

Lemma refa410_not3481 : ~ @Equation3481 Fin4 refa410_inst.
Proof. unfold Equation3481. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa410_inst, refa410_op in H. discriminate H. Qed.

Lemma refa410_not3484 : ~ @Equation3484 Fin4 refa410_inst.
Proof. unfold Equation3484. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa410_inst, refa410_op in H. discriminate H. Qed.

Lemma refa410_not3509 : ~ @Equation3509 Fin4 refa410_inst.
Proof. unfold Equation3509. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa410_inst, refa410_op in H. discriminate H. Qed.

Lemma refa410_not3512 : ~ @Equation3512 Fin4 refa410_inst.
Proof. unfold Equation3512. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa410_inst, refa410_op in H. discriminate H. Qed.

Lemma refa410_not3519 : ~ @Equation3519 Fin4 refa410_inst.
Proof. unfold Equation3519. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa410_inst, refa410_op in H. discriminate H. Qed.

Lemma refa410_not3522 : ~ @Equation3522 Fin4 refa410_inst.
Proof. unfold Equation3522. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa410_inst, refa410_op in H. discriminate H. Qed.

Lemma refa410_not3546 : ~ @Equation3546 Fin4 refa410_inst.
Proof. unfold Equation3546. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa410_inst, refa410_op in H. discriminate H. Qed.

Lemma refa410_not3549 : ~ @Equation3549 Fin4 refa410_inst.
Proof. unfold Equation3549. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa410_inst, refa410_op in H. discriminate H. Qed.

Lemma refa410_not3661 : ~ @Equation3661 Fin4 refa410_inst.
Proof. unfold Equation3661. intro H. specialize (H F4_0 F4_2). unfold magma_op, refa410_inst, refa410_op in H. discriminate H. Qed.

Lemma refa410_not3667 : ~ @Equation3667 Fin4 refa410_inst.
Proof. unfold Equation3667. intro H. specialize (H F4_0 F4_2). unfold magma_op, refa410_inst, refa410_op in H. discriminate H. Qed.

Lemma refa410_not3712 : ~ @Equation3712 Fin4 refa410_inst.
Proof. unfold Equation3712. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa410_inst, refa410_op in H. discriminate H. Qed.

Lemma refa410_not3722 : ~ @Equation3722 Fin4 refa410_inst.
Proof. unfold Equation3722. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa410_inst, refa410_op in H. discriminate H. Qed.

Lemma refa410_not3749 : ~ @Equation3749 Fin4 refa410_inst.
Proof. unfold Equation3749. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa410_inst, refa410_op in H. discriminate H. Qed.

Lemma refa410_not3752 : ~ @Equation3752 Fin4 refa410_inst.
Proof. unfold Equation3752. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa410_inst, refa410_op in H. discriminate H. Qed.

Lemma refa410_not3759 : ~ @Equation3759 Fin4 refa410_inst.
Proof. unfold Equation3759. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa410_inst, refa410_op in H. discriminate H. Qed.

Lemma refa410_not3862 : ~ @Equation3862 Fin4 refa410_inst.
Proof. unfold Equation3862. intro H. specialize (H F4_0). unfold magma_op, refa410_inst, refa410_op in H. discriminate H. Qed.

Lemma refa410_not4065 : ~ @Equation4065 Fin4 refa410_inst.
Proof. unfold Equation4065. intro H. specialize (H F4_0). unfold magma_op, refa410_inst, refa410_op in H. discriminate H. Qed.

Lemma refa410_not4284 : ~ @Equation4284 Fin4 refa410_inst.
Proof. unfold Equation4284. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa410_inst, refa410_op in H. discriminate H. Qed.

Lemma refa410_not4291 : ~ @Equation4291 Fin4 refa410_inst.
Proof. unfold Equation4291. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa410_inst, refa410_op in H. discriminate H. Qed.

Lemma refa410_not4362 : ~ @Equation4362 Fin4 refa410_inst.
Proof. unfold Equation4362. intro H. specialize (H F4_0 F4_3 F4_1). unfold magma_op, refa410_inst, refa410_op in H. discriminate H. Qed.

Lemma refa410_not4380 : ~ @Equation4380 Fin4 refa410_inst.
Proof. unfold Equation4380. intro H. specialize (H F4_0). unfold magma_op, refa410_inst, refa410_op in H. discriminate H. Qed.

Lemma refa410_not4587 : ~ @Equation4587 Fin4 refa410_inst.
Proof. unfold Equation4587. intro H. specialize (H F4_0 F4_2). unfold magma_op, refa410_inst, refa410_op in H. discriminate H. Qed.

Lemma refa410_not4606 : ~ @Equation4606 Fin4 refa410_inst.
Proof. unfold Equation4606. intro H. specialize (H F4_0 F4_2). unfold magma_op, refa410_inst, refa410_op in H. discriminate H. Qed.

Lemma refa410_not4658 : ~ @Equation4658 Fin4 refa410_inst.
Proof. unfold Equation4658. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa410_inst, refa410_op in H. discriminate H. Qed.

(** ---- refa411 (Fin4) ---- *)

Definition refa411_op (x y : Fin4) : Fin4 :=
  match x, y with
  | F4_0, F4_0 => F4_0 | F4_0, F4_1 => F4_1 | F4_0, F4_2 => F4_2 | F4_0, F4_3 => F4_3
  | F4_1, F4_0 => F4_2 | F4_1, F4_1 => F4_0 | F4_1, F4_2 => F4_1 | F4_1, F4_3 => F4_3
  | F4_2, F4_0 => F4_1 | F4_2, F4_1 => F4_2 | F4_2, F4_2 => F4_0 | F4_2, F4_3 => F4_3
  | F4_3, F4_0 => F4_1 | F4_3, F4_1 => F4_2 | F4_3, F4_2 => F4_0 | F4_3, F4_3 => F4_3
  end.

#[local] Instance refa411_inst : Magma Fin4 := {| magma_op := refa411_op |}.

Lemma refa411_sat1082 : @Equation1082 Fin4 refa411_inst.
Proof. unfold Equation1082, magma_op, refa411_inst, refa411_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa411_not1122 : ~ @Equation1122 Fin4 refa411_inst.
Proof. unfold Equation1122. intro H. specialize (H F4_0 F4_3). unfold magma_op, refa411_inst, refa411_op in H. discriminate H. Qed.

Lemma refa411_not1731 : ~ @Equation1731 Fin4 refa411_inst.
Proof. unfold Equation1731. intro H. specialize (H F4_0 F4_3). unfold magma_op, refa411_inst, refa411_op in H. discriminate H. Qed.

(** ---- refa412 (Fin4) ---- *)

Definition refa412_op (x y : Fin4) : Fin4 :=
  match x, y with
  | F4_0, F4_0 => F4_1 | F4_0, F4_1 => F4_0 | F4_0, F4_2 => F4_0 | F4_0, F4_3 => F4_1
  | F4_1, F4_0 => F4_1 | F4_1, F4_1 => F4_1 | F4_1, F4_2 => F4_1 | F4_1, F4_3 => F4_1
  | F4_2, F4_0 => F4_2 | F4_2, F4_1 => F4_2 | F4_2, F4_2 => F4_2 | F4_2, F4_3 => F4_2
  | F4_3, F4_0 => F4_1 | F4_3, F4_1 => F4_3 | F4_3, F4_2 => F4_3 | F4_3, F4_3 => F4_2
  end.

#[local] Instance refa412_inst : Magma Fin4 := {| magma_op := refa412_op |}.

Lemma refa412_sat1043 : @Equation1043 Fin4 refa412_inst.
Proof. unfold Equation1043, magma_op, refa412_inst, refa412_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa412_sat1271 : @Equation1271 Fin4 refa412_inst.
Proof. unfold Equation1271, magma_op, refa412_inst, refa412_op. intros x y z w. destruct x, y, z, w; reflexivity. Qed.

Lemma refa412_not3306 : ~ @Equation3306 Fin4 refa412_inst.
Proof. unfold Equation3306. intro H. specialize (H F4_3 F4_0). unfold magma_op, refa412_inst, refa412_op in H. discriminate H. Qed.

Lemma refa412_not3665 : ~ @Equation3665 Fin4 refa412_inst.
Proof. unfold Equation3665. intro H. specialize (H F4_3 F4_0). unfold magma_op, refa412_inst, refa412_op in H. discriminate H. Qed.

Lemma refa412_not3865 : ~ @Equation3865 Fin4 refa412_inst.
Proof. unfold Equation3865. intro H. specialize (H F4_3 F4_0). unfold magma_op, refa412_inst, refa412_op in H. discriminate H. Qed.

Lemma refa412_not3873 : ~ @Equation3873 Fin4 refa412_inst.
Proof. unfold Equation3873. intro H. specialize (H F4_3 F4_0 F4_1). unfold magma_op, refa412_inst, refa412_op in H. discriminate H. Qed.

Lemma refa412_not4070 : ~ @Equation4070 Fin4 refa412_inst.
Proof. unfold Equation4070. intro H. specialize (H F4_3 F4_0). unfold magma_op, refa412_inst, refa412_op in H. discriminate H. Qed.

Lemma refa412_not4071 : ~ @Equation4071 Fin4 refa412_inst.
Proof. unfold Equation4071. intro H. specialize (H F4_3 F4_0). unfold magma_op, refa412_inst, refa412_op in H. discriminate H. Qed.

Lemma refa412_not4073 : ~ @Equation4073 Fin4 refa412_inst.
Proof. unfold Equation4073. intro H. specialize (H F4_3 F4_0). unfold magma_op, refa412_inst, refa412_op in H. discriminate H. Qed.

Lemma refa412_not4584 : ~ @Equation4584 Fin4 refa412_inst.
Proof. unfold Equation4584. intro H. specialize (H F4_3 F4_0). unfold magma_op, refa412_inst, refa412_op in H. discriminate H. Qed.

Lemma refa412_not4598 : ~ @Equation4598 Fin4 refa412_inst.
Proof. unfold Equation4598. intro H. specialize (H F4_3 F4_0). unfold magma_op, refa412_inst, refa412_op in H. discriminate H. Qed.

(** ---- refa413 (Fin4) ---- *)

Definition refa413_op (x y : Fin4) : Fin4 :=
  match x, y with
  | F4_0, F4_0 => F4_2 | F4_0, F4_1 => F4_3 | F4_0, F4_2 => F4_2 | F4_0, F4_3 => F4_3
  | F4_1, F4_0 => F4_3 | F4_1, F4_1 => F4_2 | F4_1, F4_2 => F4_2 | F4_1, F4_3 => F4_3
  | F4_2, F4_0 => F4_0 | F4_2, F4_1 => F4_1 | F4_2, F4_2 => F4_2 | F4_2, F4_3 => F4_3
  | F4_3, F4_0 => F4_0 | F4_3, F4_1 => F4_1 | F4_3, F4_2 => F4_2 | F4_3, F4_3 => F4_2
  end.

#[local] Instance refa413_inst : Magma Fin4 := {| magma_op := refa413_op |}.

Lemma refa413_sat3145 : @Equation3145 Fin4 refa413_inst.
Proof. unfold Equation3145, magma_op, refa413_inst, refa413_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa413_not2665 : ~ @Equation2665 Fin4 refa413_inst.
Proof. unfold Equation2665. intro H. specialize (H F4_3 F4_0 F4_1). unfold magma_op, refa413_inst, refa413_op in H. discriminate H. Qed.

Lemma refa413_not3481 : ~ @Equation3481 Fin4 refa413_inst.
Proof. unfold Equation3481. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa413_inst, refa413_op in H. discriminate H. Qed.
