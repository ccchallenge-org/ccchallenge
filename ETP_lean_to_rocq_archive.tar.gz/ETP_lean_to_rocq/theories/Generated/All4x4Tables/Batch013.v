(** * All4x4 counterexamples — batch 13
    Auto-generated from Lean4 All4x4 files. *)

From Stdlib Require Import Utf8.

From ETP Require Import Magma.
From ETP Require Import FinMagma.
From ETP.Equations Require Import All.

Open Scope magma_scope.

(** ---- refa64 (Fin3) ---- *)

Definition refa64_op (x y : Fin3) : Fin3 :=
  match x, y with
  | F3_0, F3_0 => F3_0 | F3_0, F3_1 => F3_0 | F3_0, F3_2 => F3_2
  | F3_1, F3_0 => F3_2 | F3_1, F3_1 => F3_2 | F3_1, F3_2 => F3_2
  | F3_2, F3_0 => F3_0 | F3_2, F3_1 => F3_1 | F3_2, F3_2 => F3_2
  end.

#[local] Instance refa64_inst : Magma Fin3 := {| magma_op := refa64_op |}.

Lemma refa64_sat2322 : @Equation2322 Fin3 refa64_inst.
Proof. unfold Equation2322, magma_op, refa64_inst, refa64_op. intros x y z w. destruct x, y, z, w; reflexivity. Qed.

Lemma refa64_not231 : ~ @Equation231 Fin3 refa64_inst.
Proof. unfold Equation231. intro H. specialize (H F3_1 F3_0). unfold magma_op, refa64_inst, refa64_op in H. discriminate H. Qed.

Lemma refa64_not1637 : ~ @Equation1637 Fin3 refa64_inst.
Proof. unfold Equation1637. intro H. specialize (H F3_1 F3_0). unfold magma_op, refa64_inst, refa64_op in H. discriminate H. Qed.

Lemma refa64_not1657 : ~ @Equation1657 Fin3 refa64_inst.
Proof. unfold Equation1657. intro H. specialize (H F3_1 F3_0). unfold magma_op, refa64_inst, refa64_op in H. discriminate H. Qed.

Lemma refa64_not1721 : ~ @Equation1721 Fin3 refa64_inst.
Proof. unfold Equation1721. intro H. specialize (H F3_1 F3_0). unfold magma_op, refa64_inst, refa64_op in H. discriminate H. Qed.

Lemma refa64_not1731 : ~ @Equation1731 Fin3 refa64_inst.
Proof. unfold Equation1731. intro H. specialize (H F3_1 F3_0). unfold magma_op, refa64_inst, refa64_op in H. discriminate H. Qed.

Lemma refa64_not2340 : ~ @Equation2340 Fin3 refa64_inst.
Proof. unfold Equation2340. intro H. specialize (H F3_1 F3_0). unfold magma_op, refa64_inst, refa64_op in H. discriminate H. Qed.

Lemma refa64_not2496 : ~ @Equation2496 Fin3 refa64_inst.
Proof. unfold Equation2496. intro H. specialize (H F3_1 F3_0). unfold magma_op, refa64_inst, refa64_op in H. discriminate H. Qed.

Lemma refa64_not2506 : ~ @Equation2506 Fin3 refa64_inst.
Proof. unfold Equation2506. intro H. specialize (H F3_1 F3_0). unfold magma_op, refa64_inst, refa64_op in H. discriminate H. Qed.

Lemma refa64_not2530 : ~ @Equation2530 Fin3 refa64_inst.
Proof. unfold Equation2530. intro H. specialize (H F3_1 F3_0). unfold magma_op, refa64_inst, refa64_op in H. discriminate H. Qed.

Lemma refa64_not2533 : ~ @Equation2533 Fin3 refa64_inst.
Proof. unfold Equation2533. intro H. specialize (H F3_1 F3_0). unfold magma_op, refa64_inst, refa64_op in H. discriminate H. Qed.

Lemma refa64_not2543 : ~ @Equation2543 Fin3 refa64_inst.
Proof. unfold Equation2543. intro H. specialize (H F3_1 F3_0). unfold magma_op, refa64_inst, refa64_op in H. discriminate H. Qed.

Lemma refa64_not2652 : ~ @Equation2652 Fin3 refa64_inst.
Proof. unfold Equation2652. intro H. specialize (H F3_1 F3_0). unfold magma_op, refa64_inst, refa64_op in H. discriminate H. Qed.

Lemma refa64_not2672 : ~ @Equation2672 Fin3 refa64_inst.
Proof. unfold Equation2672. intro H. specialize (H F3_1 F3_0). unfold magma_op, refa64_inst, refa64_op in H. discriminate H. Qed.

Lemma refa64_not2706 : ~ @Equation2706 Fin3 refa64_inst.
Proof. unfold Equation2706. intro H. specialize (H F3_1 F3_0). unfold magma_op, refa64_inst, refa64_op in H. discriminate H. Qed.

Lemma refa64_not2709 : ~ @Equation2709 Fin3 refa64_inst.
Proof. unfold Equation2709. intro H. specialize (H F3_1 F3_0). unfold magma_op, refa64_inst, refa64_op in H. discriminate H. Qed.

Lemma refa64_not2746 : ~ @Equation2746 Fin3 refa64_inst.
Proof. unfold Equation2746. intro H. specialize (H F3_1 F3_0). unfold magma_op, refa64_inst, refa64_op in H. discriminate H. Qed.

Lemma refa64_not3058 : ~ @Equation3058 Fin3 refa64_inst.
Proof. unfold Equation3058. intro H. specialize (H F3_1 F3_0). unfold magma_op, refa64_inst, refa64_op in H. discriminate H. Qed.

Lemma refa64_not3078 : ~ @Equation3078 Fin3 refa64_inst.
Proof. unfold Equation3078. intro H. specialize (H F3_1 F3_0). unfold magma_op, refa64_inst, refa64_op in H. discriminate H. Qed.

Lemma refa64_not3105 : ~ @Equation3105 Fin3 refa64_inst.
Proof. unfold Equation3105. intro H. specialize (H F3_1 F3_0). unfold magma_op, refa64_inst, refa64_op in H. discriminate H. Qed.

Lemma refa64_not3115 : ~ @Equation3115 Fin3 refa64_inst.
Proof. unfold Equation3115. intro H. specialize (H F3_1 F3_0). unfold magma_op, refa64_inst, refa64_op in H. discriminate H. Qed.

Lemma refa64_not3139 : ~ @Equation3139 Fin3 refa64_inst.
Proof. unfold Equation3139. intro H. specialize (H F3_1 F3_0). unfold magma_op, refa64_inst, refa64_op in H. discriminate H. Qed.

Lemma refa64_not3142 : ~ @Equation3142 Fin3 refa64_inst.
Proof. unfold Equation3142. intro H. specialize (H F3_1 F3_0). unfold magma_op, refa64_inst, refa64_op in H. discriminate H. Qed.

Lemma refa64_not3152 : ~ @Equation3152 Fin3 refa64_inst.
Proof. unfold Equation3152. intro H. specialize (H F3_1 F3_0). unfold magma_op, refa64_inst, refa64_op in H. discriminate H. Qed.

Lemma refa64_not3255 : ~ @Equation3255 Fin3 refa64_inst.
Proof. unfold Equation3255. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa64_inst, refa64_op in H. discriminate H. Qed.

Lemma refa64_not3256 : ~ @Equation3256 Fin3 refa64_inst.
Proof. unfold Equation3256. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa64_inst, refa64_op in H. discriminate H. Qed.

Lemma refa64_not3258 : ~ @Equation3258 Fin3 refa64_inst.
Proof. unfold Equation3258. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa64_inst, refa64_op in H. discriminate H. Qed.

Lemma refa64_not3259 : ~ @Equation3259 Fin3 refa64_inst.
Proof. unfold Equation3259. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa64_inst, refa64_op in H. discriminate H. Qed.

Lemma refa64_not3261 : ~ @Equation3261 Fin3 refa64_inst.
Proof. unfold Equation3261. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa64_inst, refa64_op in H. discriminate H. Qed.

Lemma refa64_not3262 : ~ @Equation3262 Fin3 refa64_inst.
Proof. unfold Equation3262. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa64_inst, refa64_op in H. discriminate H. Qed.

Lemma refa64_not3268 : ~ @Equation3268 Fin3 refa64_inst.
Proof. unfold Equation3268. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa64_inst, refa64_op in H. discriminate H. Qed.

Lemma refa64_not3269 : ~ @Equation3269 Fin3 refa64_inst.
Proof. unfold Equation3269. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa64_inst, refa64_op in H. discriminate H. Qed.

Lemma refa64_not3271 : ~ @Equation3271 Fin3 refa64_inst.
Proof. unfold Equation3271. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa64_inst, refa64_op in H. discriminate H. Qed.

Lemma refa64_not3278 : ~ @Equation3278 Fin3 refa64_inst.
Proof. unfold Equation3278. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa64_inst, refa64_op in H. discriminate H. Qed.

Lemma refa64_not3459 : ~ @Equation3459 Fin3 refa64_inst.
Proof. unfold Equation3459. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa64_inst, refa64_op in H. discriminate H. Qed.

Lemma refa64_not3467 : ~ @Equation3467 Fin3 refa64_inst.
Proof. unfold Equation3467. intro H. specialize (H F3_0 F3_2 F3_1). unfold magma_op, refa64_inst, refa64_op in H. discriminate H. Qed.

Lemma refa64_not3472 : ~ @Equation3472 Fin3 refa64_inst.
Proof. unfold Equation3472. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa64_inst, refa64_op in H. discriminate H. Qed.

Lemma refa64_not3481 : ~ @Equation3481 Fin3 refa64_inst.
Proof. unfold Equation3481. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa64_inst, refa64_op in H. discriminate H. Qed.

Lemma refa64_not3537 : ~ @Equation3537 Fin3 refa64_inst.
Proof. unfold Equation3537. intro H. specialize (H F3_2 F3_1 F3_0). unfold magma_op, refa64_inst, refa64_op in H. discriminate H. Qed.

Lemma refa64_not3662 : ~ @Equation3662 Fin3 refa64_inst.
Proof. unfold Equation3662. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa64_inst, refa64_op in H. discriminate H. Qed.

Lemma refa64_not3665 : ~ @Equation3665 Fin3 refa64_inst.
Proof. unfold Equation3665. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa64_inst, refa64_op in H. discriminate H. Qed.

Lemma refa64_not3668 : ~ @Equation3668 Fin3 refa64_inst.
Proof. unfold Equation3668. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa64_inst, refa64_op in H. discriminate H. Qed.

Lemma refa64_not3677 : ~ @Equation3677 Fin3 refa64_inst.
Proof. unfold Equation3677. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa64_inst, refa64_op in H. discriminate H. Qed.

Lemma refa64_not3694 : ~ @Equation3694 Fin3 refa64_inst.
Proof. unfold Equation3694. intro H. specialize (H F3_0 F3_2 F3_1). unfold magma_op, refa64_inst, refa64_op in H. discriminate H. Qed.

Lemma refa64_not3820 : ~ @Equation3820 Fin3 refa64_inst.
Proof. unfold Equation3820. intro H. specialize (H F3_2 F3_1 F3_0). unfold magma_op, refa64_inst, refa64_op in H. discriminate H. Qed.

Lemma refa64_not4068 : ~ @Equation4068 Fin3 refa64_inst.
Proof. unfold Equation4068. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa64_inst, refa64_op in H. discriminate H. Qed.

Lemma refa64_not4090 : ~ @Equation4090 Fin3 refa64_inst.
Proof. unfold Equation4090. intro H. specialize (H F3_1 F3_0). unfold magma_op, refa64_inst, refa64_op in H. discriminate H. Qed.

Lemma refa64_not4131 : ~ @Equation4131 Fin3 refa64_inst.
Proof. unfold Equation4131. intro H. specialize (H F3_1 F3_0). unfold magma_op, refa64_inst, refa64_op in H. discriminate H. Qed.

Lemma refa64_not4155 : ~ @Equation4155 Fin3 refa64_inst.
Proof. unfold Equation4155. intro H. specialize (H F3_1 F3_0). unfold magma_op, refa64_inst, refa64_op in H. discriminate H. Qed.

Lemma refa64_not4165 : ~ @Equation4165 Fin3 refa64_inst.
Proof. unfold Equation4165. intro H. specialize (H F3_1 F3_0). unfold magma_op, refa64_inst, refa64_op in H. discriminate H. Qed.

Lemma refa64_not4269 : ~ @Equation4269 Fin3 refa64_inst.
Proof. unfold Equation4269. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa64_inst, refa64_op in H. discriminate H. Qed.

Lemma refa64_not4270 : ~ @Equation4270 Fin3 refa64_inst.
Proof. unfold Equation4270. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa64_inst, refa64_op in H. discriminate H. Qed.

Lemma refa64_not4272 : ~ @Equation4272 Fin3 refa64_inst.
Proof. unfold Equation4272. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa64_inst, refa64_op in H. discriminate H. Qed.

Lemma refa64_not4273 : ~ @Equation4273 Fin3 refa64_inst.
Proof. unfold Equation4273. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa64_inst, refa64_op in H. discriminate H. Qed.

Lemma refa64_not4314 : ~ @Equation4314 Fin3 refa64_inst.
Proof. unfold Equation4314. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa64_inst, refa64_op in H. discriminate H. Qed.

Lemma refa64_not4606 : ~ @Equation4606 Fin3 refa64_inst.
Proof. unfold Equation4606. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa64_inst, refa64_op in H. discriminate H. Qed.

Lemma refa64_not4622 : ~ @Equation4622 Fin3 refa64_inst.
Proof. unfold Equation4622. intro H. specialize (H F3_0 F3_1 F3_1). unfold magma_op, refa64_inst, refa64_op in H. discriminate H. Qed.

(** ---- refa640 (Fin4) ---- *)

Definition refa640_op (x y : Fin4) : Fin4 :=
  match x, y with
  | F4_0, F4_0 => F4_3 | F4_0, F4_1 => F4_0 | F4_0, F4_2 => F4_0 | F4_0, F4_3 => F4_1
  | F4_1, F4_0 => F4_1 | F4_1, F4_1 => F4_2 | F4_1, F4_2 => F4_0 | F4_1, F4_3 => F4_1
  | F4_2, F4_0 => F4_3 | F4_2, F4_1 => F4_2 | F4_2, F4_2 => F4_0 | F4_2, F4_3 => F4_2
  | F4_3, F4_0 => F4_3 | F4_3, F4_1 => F4_2 | F4_3, F4_2 => F4_3 | F4_3, F4_3 => F4_1
  end.

#[local] Instance refa640_inst : Magma Fin4 := {| magma_op := refa640_op |}.

Lemma refa640_sat838 : @Equation838 Fin4 refa640_inst.
Proof. unfold Equation838, magma_op, refa640_inst, refa640_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa640_not4316 : ~ @Equation4316 Fin4 refa640_inst.
Proof. unfold Equation4316. intro H. specialize (H F4_0 F4_0 F4_1). unfold magma_op, refa640_inst, refa640_op in H. discriminate H. Qed.

(** ---- refa641 (Fin4) ---- *)

Definition refa641_op (x y : Fin4) : Fin4 :=
  match x, y with
  | F4_0, F4_0 => F4_0 | F4_0, F4_1 => F4_1 | F4_0, F4_2 => F4_3 | F4_0, F4_3 => F4_1
  | F4_1, F4_0 => F4_3 | F4_1, F4_1 => F4_1 | F4_1, F4_2 => F4_3 | F4_1, F4_3 => F4_1
  | F4_2, F4_0 => F4_2 | F4_2, F4_1 => F4_0 | F4_2, F4_2 => F4_2 | F4_2, F4_3 => F4_0
  | F4_3, F4_0 => F4_2 | F4_3, F4_1 => F4_0 | F4_3, F4_2 => F4_2 | F4_3, F4_3 => F4_3
  end.

#[local] Instance refa641_inst : Magma Fin4 := {| magma_op := refa641_op |}.

Lemma refa641_sat3675 : @Equation3675 Fin4 refa641_inst.
Proof. unfold Equation3675, magma_op, refa641_inst, refa641_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa641_not3662 : ~ @Equation3662 Fin4 refa641_inst.
Proof. unfold Equation3662. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa641_inst, refa641_op in H. discriminate H. Qed.

Lemma refa641_not3665 : ~ @Equation3665 Fin4 refa641_inst.
Proof. unfold Equation3665. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa641_inst, refa641_op in H. discriminate H. Qed.

Lemma refa641_not3667 : ~ @Equation3667 Fin4 refa641_inst.
Proof. unfold Equation3667. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa641_inst, refa641_op in H. discriminate H. Qed.

Lemma refa641_not3677 : ~ @Equation3677 Fin4 refa641_inst.
Proof. unfold Equation3677. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa641_inst, refa641_op in H. discriminate H. Qed.

Lemma refa641_not3684 : ~ @Equation3684 Fin4 refa641_inst.
Proof. unfold Equation3684. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa641_inst, refa641_op in H. discriminate H. Qed.

Lemma refa641_not4270 : ~ @Equation4270 Fin4 refa641_inst.
Proof. unfold Equation4270. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa641_inst, refa641_op in H. discriminate H. Qed.

Lemma refa641_not4590 : ~ @Equation4590 Fin4 refa641_inst.
Proof. unfold Equation4590. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa641_inst, refa641_op in H. discriminate H. Qed.

Lemma refa641_not4635 : ~ @Equation4635 Fin4 refa641_inst.
Proof. unfold Equation4635. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa641_inst, refa641_op in H. discriminate H. Qed.

(** ---- refa642 (Fin4) ---- *)

Definition refa642_op (x y : Fin4) : Fin4 :=
  match x, y with
  | F4_0, F4_0 => F4_3 | F4_0, F4_1 => F4_0 | F4_0, F4_2 => F4_3 | F4_0, F4_3 => F4_1
  | F4_1, F4_0 => F4_3 | F4_1, F4_1 => F4_0 | F4_1, F4_2 => F4_3 | F4_1, F4_3 => F4_1
  | F4_2, F4_0 => F4_3 | F4_2, F4_1 => F4_2 | F4_2, F4_2 => F4_0 | F4_2, F4_3 => F4_1
  | F4_3, F4_0 => F4_3 | F4_3, F4_1 => F4_0 | F4_3, F4_2 => F4_3 | F4_3, F4_3 => F4_1
  end.

#[local] Instance refa642_inst : Magma Fin4 := {| magma_op := refa642_op |}.

Lemma refa642_sat657 : @Equation657 Fin4 refa642_inst.
Proof. unfold Equation657, magma_op, refa642_inst, refa642_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa642_not47 : ~ @Equation47 Fin4 refa642_inst.
Proof. unfold Equation47. intro H. specialize (H F4_2). unfold magma_op, refa642_inst, refa642_op in H. discriminate H. Qed.

Lemma refa642_not632 : ~ @Equation632 Fin4 refa642_inst.
Proof. unfold Equation632. intro H. specialize (H F4_2 F4_1). unfold magma_op, refa642_inst, refa642_op in H. discriminate H. Qed.

Lemma refa642_not639 : ~ @Equation639 Fin4 refa642_inst.
Proof. unfold Equation639. intro H. specialize (H F4_1 F4_2). unfold magma_op, refa642_inst, refa642_op in H. discriminate H. Qed.

Lemma refa642_not817 : ~ @Equation817 Fin4 refa642_inst.
Proof. unfold Equation817. intro H. specialize (H F4_2). unfold magma_op, refa642_inst, refa642_op in H. discriminate H. Qed.

Lemma refa642_not1426 : ~ @Equation1426 Fin4 refa642_inst.
Proof. unfold Equation1426. intro H. specialize (H F4_2). unfold magma_op, refa642_inst, refa642_op in H. discriminate H. Qed.

Lemma refa642_not3862 : ~ @Equation3862 Fin4 refa642_inst.
Proof. unfold Equation3862. intro H. specialize (H F4_2). unfold magma_op, refa642_inst, refa642_op in H. discriminate H. Qed.

Lemma refa642_not4065 : ~ @Equation4065 Fin4 refa642_inst.
Proof. unfold Equation4065. intro H. specialize (H F4_2). unfold magma_op, refa642_inst, refa642_op in H. discriminate H. Qed.

Lemma refa642_not4269 : ~ @Equation4269 Fin4 refa642_inst.
Proof. unfold Equation4269. intro H. specialize (H F4_2 F4_0). unfold magma_op, refa642_inst, refa642_op in H. discriminate H. Qed.

Lemma refa642_not4284 : ~ @Equation4284 Fin4 refa642_inst.
Proof. unfold Equation4284. intro H. specialize (H F4_0 F4_2). unfold magma_op, refa642_inst, refa642_op in H. discriminate H. Qed.

Lemma refa642_not4599 : ~ @Equation4599 Fin4 refa642_inst.
Proof. unfold Equation4599. intro H. specialize (H F4_2 F4_1). unfold magma_op, refa642_inst, refa642_op in H. discriminate H. Qed.

Lemma refa642_not4631 : ~ @Equation4631 Fin4 refa642_inst.
Proof. unfold Equation4631. intro H. specialize (H F4_2 F4_0 F4_1). unfold magma_op, refa642_inst, refa642_op in H. discriminate H. Qed.

(** ---- refa643 (Fin4) ---- *)

Definition refa643_op (x y : Fin4) : Fin4 :=
  match x, y with
  | F4_0, F4_0 => F4_3 | F4_0, F4_1 => F4_3 | F4_0, F4_2 => F4_1 | F4_0, F4_3 => F4_1
  | F4_1, F4_0 => F4_3 | F4_1, F4_1 => F4_2 | F4_1, F4_2 => F4_1 | F4_1, F4_3 => F4_0
  | F4_2, F4_0 => F4_3 | F4_2, F4_1 => F4_1 | F4_2, F4_2 => F4_1 | F4_2, F4_3 => F4_1
  | F4_3, F4_0 => F4_3 | F4_3, F4_1 => F4_2 | F4_3, F4_2 => F4_1 | F4_3, F4_3 => F4_0
  end.

#[local] Instance refa643_inst : Magma Fin4 := {| magma_op := refa643_op |}.

Lemma refa643_sat1697 : @Equation1697 Fin4 refa643_inst.
Proof. unfold Equation1697, magma_op, refa643_inst, refa643_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa643_not1654 : ~ @Equation1654 Fin4 refa643_inst.
Proof. unfold Equation1654. intro H. specialize (H F4_1 F4_3). unfold magma_op, refa643_inst, refa643_op in H. discriminate H. Qed.

Lemma refa643_not1657 : ~ @Equation1657 Fin4 refa643_inst.
Proof. unfold Equation1657. intro H. specialize (H F4_3 F4_1). unfold magma_op, refa643_inst, refa643_op in H. discriminate H. Qed.

Lemma refa643_not1840 : ~ @Equation1840 Fin4 refa643_inst.
Proof. unfold Equation1840. intro H. specialize (H F4_3 F4_2). unfold magma_op, refa643_inst, refa643_op in H. discriminate H. Qed.

Lemma refa643_not1860 : ~ @Equation1860 Fin4 refa643_inst.
Proof. unfold Equation1860. intro H. specialize (H F4_3 F4_2). unfold magma_op, refa643_inst, refa643_op in H. discriminate H. Qed.

Lemma refa643_not3261 : ~ @Equation3261 Fin4 refa643_inst.
Proof. unfold Equation3261. intro H. specialize (H F4_3 F4_2). unfold magma_op, refa643_inst, refa643_op in H. discriminate H. Qed.

Lemma refa643_not3306 : ~ @Equation3306 Fin4 refa643_inst.
Proof. unfold Equation3306. intro H. specialize (H F4_2 F4_0). unfold magma_op, refa643_inst, refa643_op in H. discriminate H. Qed.

Lemma refa643_not3309 : ~ @Equation3309 Fin4 refa643_inst.
Proof. unfold Equation3309. intro H. specialize (H F4_2 F4_0). unfold magma_op, refa643_inst, refa643_op in H. discriminate H. Qed.

Lemma refa643_not4121 : ~ @Equation4121 Fin4 refa643_inst.
Proof. unfold Equation4121. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa643_inst, refa643_op in H. discriminate H. Qed.

Lemma refa643_not4131 : ~ @Equation4131 Fin4 refa643_inst.
Proof. unfold Equation4131. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa643_inst, refa643_op in H. discriminate H. Qed.

Lemma refa643_not4158 : ~ @Equation4158 Fin4 refa643_inst.
Proof. unfold Equation4158. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa643_inst, refa643_op in H. discriminate H. Qed.

Lemma refa643_not4284 : ~ @Equation4284 Fin4 refa643_inst.
Proof. unfold Equation4284. intro H. specialize (H F4_2 F4_3). unfold magma_op, refa643_inst, refa643_op in H. discriminate H. Qed.

Lemma refa643_not4599 : ~ @Equation4599 Fin4 refa643_inst.
Proof. unfold Equation4599. intro H. specialize (H F4_3 F4_1). unfold magma_op, refa643_inst, refa643_op in H. discriminate H. Qed.

Lemma refa643_not4635 : ~ @Equation4635 Fin4 refa643_inst.
Proof. unfold Equation4635. intro H. specialize (H F4_1 F4_3). unfold magma_op, refa643_inst, refa643_op in H. discriminate H. Qed.

(** ---- refa644 (Fin4) ---- *)

Definition refa644_op (x y : Fin4) : Fin4 :=
  match x, y with
  | F4_0, F4_0 => F4_0 | F4_0, F4_1 => F4_1 | F4_0, F4_2 => F4_2 | F4_0, F4_3 => F4_1
  | F4_1, F4_0 => F4_3 | F4_1, F4_1 => F4_2 | F4_1, F4_2 => F4_3 | F4_1, F4_3 => F4_2
  | F4_2, F4_0 => F4_0 | F4_2, F4_1 => F4_1 | F4_2, F4_2 => F4_2 | F4_2, F4_3 => F4_3
  | F4_3, F4_0 => F4_2 | F4_3, F4_1 => F4_1 | F4_3, F4_2 => F4_0 | F4_3, F4_3 => F4_0
  end.

#[local] Instance refa644_inst : Magma Fin4 := {| magma_op := refa644_op |}.

Lemma refa644_sat3115 : @Equation3115 Fin4 refa644_inst.
Proof. unfold Equation3115, magma_op, refa644_inst, refa644_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa644_not2644 : ~ @Equation2644 Fin4 refa644_inst.
Proof. unfold Equation2644. intro H. specialize (H F4_3). unfold magma_op, refa644_inst, refa644_op in H. discriminate H. Qed.

Lemma refa644_not3065 : ~ @Equation3065 Fin4 refa644_inst.
Proof. unfold Equation3065. intro H. specialize (H F4_3 F4_0). unfold magma_op, refa644_inst, refa644_op in H. discriminate H. Qed.

Lemma refa644_not3152 : ~ @Equation3152 Fin4 refa644_inst.
Proof. unfold Equation3152. intro H. specialize (H F4_3 F4_0). unfold magma_op, refa644_inst, refa644_op in H. discriminate H. Qed.

Lemma refa644_not3456 : ~ @Equation3456 Fin4 refa644_inst.
Proof. unfold Equation3456. intro H. specialize (H F4_3). unfold magma_op, refa644_inst, refa644_op in H. discriminate H. Qed.

(** ---- refa645 (Fin4) ---- *)

Definition refa645_op (x y : Fin4) : Fin4 :=
  match x, y with
  | F4_0, F4_0 => F4_3 | F4_0, F4_1 => F4_2 | F4_0, F4_2 => F4_0 | F4_0, F4_3 => F4_1
  | F4_1, F4_0 => F4_3 | F4_1, F4_1 => F4_2 | F4_1, F4_2 => F4_0 | F4_1, F4_3 => F4_1
  | F4_2, F4_0 => F4_3 | F4_2, F4_1 => F4_2 | F4_2, F4_2 => F4_0 | F4_2, F4_3 => F4_1
  | F4_3, F4_0 => F4_3 | F4_3, F4_1 => F4_2 | F4_3, F4_2 => F4_0 | F4_3, F4_3 => F4_1
  end.

#[local] Instance refa645_inst : Magma Fin4 := {| magma_op := refa645_op |}.

Lemma refa645_sat516 : @Equation516 Fin4 refa645_inst.
Proof. unfold Equation516, magma_op, refa645_inst, refa645_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa645_not99 : ~ @Equation99 Fin4 refa645_inst.
Proof. unfold Equation99. intro H. specialize (H F4_0). unfold magma_op, refa645_inst, refa645_op in H. discriminate H. Qed.

Lemma refa645_not151 : ~ @Equation151 Fin4 refa645_inst.
Proof. unfold Equation151. intro H. specialize (H F4_0). unfold magma_op, refa645_inst, refa645_op in H. discriminate H. Qed.

Lemma refa645_not817 : ~ @Equation817 Fin4 refa645_inst.
Proof. unfold Equation817. intro H. specialize (H F4_0). unfold magma_op, refa645_inst, refa645_op in H. discriminate H. Qed.

Lemma refa645_not1020 : ~ @Equation1020 Fin4 refa645_inst.
Proof. unfold Equation1020. intro H. specialize (H F4_0). unfold magma_op, refa645_inst, refa645_op in H. discriminate H. Qed.

Lemma refa645_not1223 : ~ @Equation1223 Fin4 refa645_inst.
Proof. unfold Equation1223. intro H. specialize (H F4_0). unfold magma_op, refa645_inst, refa645_op in H. discriminate H. Qed.

Lemma refa645_not1629 : ~ @Equation1629 Fin4 refa645_inst.
Proof. unfold Equation1629. intro H. specialize (H F4_0). unfold magma_op, refa645_inst, refa645_op in H. discriminate H. Qed.

Lemma refa645_not1832 : ~ @Equation1832 Fin4 refa645_inst.
Proof. unfold Equation1832. intro H. specialize (H F4_0). unfold magma_op, refa645_inst, refa645_op in H. discriminate H. Qed.

Lemma refa645_not2035 : ~ @Equation2035 Fin4 refa645_inst.
Proof. unfold Equation2035. intro H. specialize (H F4_0). unfold magma_op, refa645_inst, refa645_op in H. discriminate H. Qed.

Lemma refa645_not3253 : ~ @Equation3253 Fin4 refa645_inst.
Proof. unfold Equation3253. intro H. specialize (H F4_0). unfold magma_op, refa645_inst, refa645_op in H. discriminate H. Qed.

Lemma refa645_not3659 : ~ @Equation3659 Fin4 refa645_inst.
Proof. unfold Equation3659. intro H. specialize (H F4_0). unfold magma_op, refa645_inst, refa645_op in H. discriminate H. Qed.

(** ---- refa646 (Fin4) ---- *)

Definition refa646_op (x y : Fin4) : Fin4 :=
  match x, y with
  | F4_0, F4_0 => F4_1 | F4_0, F4_1 => F4_0 | F4_0, F4_2 => F4_0 | F4_0, F4_3 => F4_1
  | F4_1, F4_0 => F4_3 | F4_1, F4_1 => F4_1 | F4_1, F4_2 => F4_2 | F4_1, F4_3 => F4_3
  | F4_2, F4_0 => F4_2 | F4_2, F4_1 => F4_3 | F4_2, F4_2 => F4_1 | F4_2, F4_3 => F4_0
  | F4_3, F4_0 => F4_1 | F4_3, F4_1 => F4_3 | F4_3, F4_2 => F4_1 | F4_3, F4_3 => F4_1
  end.

#[local] Instance refa646_inst : Magma Fin4 := {| magma_op := refa646_op |}.

Lemma refa646_sat414 : @Equation414 Fin4 refa646_inst.
Proof. unfold Equation414, magma_op, refa646_inst, refa646_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa646_not1020 : ~ @Equation1020 Fin4 refa646_inst.
Proof. unfold Equation1020. intro H. specialize (H F4_2). unfold magma_op, refa646_inst, refa646_op in H. discriminate H. Qed.

Lemma refa646_not1832 : ~ @Equation1832 Fin4 refa646_inst.
Proof. unfold Equation1832. intro H. specialize (H F4_2). unfold magma_op, refa646_inst, refa646_op in H. discriminate H. Qed.

(** ---- refa647 (Fin4) ---- *)

Definition refa647_op (x y : Fin4) : Fin4 :=
  match x, y with
  | F4_0, F4_0 => F4_3 | F4_0, F4_1 => F4_0 | F4_0, F4_2 => F4_0 | F4_0, F4_3 => F4_1
  | F4_1, F4_0 => F4_2 | F4_1, F4_1 => F4_3 | F4_1, F4_2 => F4_1 | F4_1, F4_3 => F4_0
  | F4_2, F4_0 => F4_1 | F4_2, F4_1 => F4_2 | F4_2, F4_2 => F4_3 | F4_2, F4_3 => F4_2
  | F4_3, F4_0 => F4_0 | F4_3, F4_1 => F4_1 | F4_3, F4_2 => F4_2 | F4_3, F4_3 => F4_3
  end.

#[local] Instance refa647_inst : Magma Fin4 := {| magma_op := refa647_op |}.

Lemma refa647_sat3147 : @Equation3147 Fin4 refa647_inst.
Proof. unfold Equation3147, magma_op, refa647_inst, refa647_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa647_not1020 : ~ @Equation1020 Fin4 refa647_inst.
Proof. unfold Equation1020. intro H. specialize (H F4_1). unfold magma_op, refa647_inst, refa647_op in H. discriminate H. Qed.

Lemma refa647_not1684 : ~ @Equation1684 Fin4 refa647_inst.
Proof. unfold Equation1684. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa647_inst, refa647_op in H. discriminate H. Qed.

Lemma refa647_not1894 : ~ @Equation1894 Fin4 refa647_inst.
Proof. unfold Equation1894. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa647_inst, refa647_op in H. discriminate H. Qed.

Lemma refa647_not2534 : ~ @Equation2534 Fin4 refa647_inst.
Proof. unfold Equation2534. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa647_inst, refa647_op in H. discriminate H. Qed.

Lemma refa647_not2697 : ~ @Equation2697 Fin4 refa647_inst.
Proof. unfold Equation2697. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa647_inst, refa647_op in H. discriminate H. Qed.

Lemma refa647_not2710 : ~ @Equation2710 Fin4 refa647_inst.
Proof. unfold Equation2710. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa647_inst, refa647_op in H. discriminate H. Qed.

Lemma refa647_not3556 : ~ @Equation3556 Fin4 refa647_inst.
Proof. unfold Equation3556. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa647_inst, refa647_op in H. discriminate H. Qed.

Lemma refa647_not3748 : ~ @Equation3748 Fin4 refa647_inst.
Proof. unfold Equation3748. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa647_inst, refa647_op in H. discriminate H. Qed.

Lemma refa647_not3752 : ~ @Equation3752 Fin4 refa647_inst.
Proof. unfold Equation3752. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa647_inst, refa647_op in H. discriminate H. Qed.

Lemma refa647_not4273 : ~ @Equation4273 Fin4 refa647_inst.
Proof. unfold Equation4273. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa647_inst, refa647_op in H. discriminate H. Qed.

Lemma refa647_not4320 : ~ @Equation4320 Fin4 refa647_inst.
Proof. unfold Equation4320. intro H. specialize (H F4_0 F4_2). unfold magma_op, refa647_inst, refa647_op in H. discriminate H. Qed.

Lemma refa647_not4684 : ~ @Equation4684 Fin4 refa647_inst.
Proof. unfold Equation4684. intro H. specialize (H F4_0 F4_1 F4_2). unfold magma_op, refa647_inst, refa647_op in H. discriminate H. Qed.

(** ---- refa648 (Fin4) ---- *)

Definition refa648_op (x y : Fin4) : Fin4 :=
  match x, y with
  | F4_0, F4_0 => F4_3 | F4_0, F4_1 => F4_0 | F4_0, F4_2 => F4_1 | F4_0, F4_3 => F4_3
  | F4_1, F4_0 => F4_1 | F4_1, F4_1 => F4_2 | F4_1, F4_2 => F4_2 | F4_1, F4_3 => F4_0
  | F4_2, F4_0 => F4_0 | F4_2, F4_1 => F4_3 | F4_2, F4_2 => F4_0 | F4_2, F4_3 => F4_2
  | F4_3, F4_0 => F4_2 | F4_3, F4_1 => F4_1 | F4_3, F4_2 => F4_3 | F4_3, F4_3 => F4_1
  end.

#[local] Instance refa648_inst : Magma Fin4 := {| magma_op := refa648_op |}.

Lemma refa648_sat826 : @Equation826 Fin4 refa648_inst.
Proof. unfold Equation826, magma_op, refa648_inst, refa648_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa648_not47 : ~ @Equation47 Fin4 refa648_inst.
Proof. unfold Equation47. intro H. specialize (H F4_0). unfold magma_op, refa648_inst, refa648_op in H. discriminate H. Qed.

Lemma refa648_not99 : ~ @Equation99 Fin4 refa648_inst.
Proof. unfold Equation99. intro H. specialize (H F4_0). unfold magma_op, refa648_inst, refa648_op in H. discriminate H. Qed.

Lemma refa648_not151 : ~ @Equation151 Fin4 refa648_inst.
Proof. unfold Equation151. intro H. specialize (H F4_0). unfold magma_op, refa648_inst, refa648_op in H. discriminate H. Qed.

Lemma refa648_not203 : ~ @Equation203 Fin4 refa648_inst.
Proof. unfold Equation203. intro H. specialize (H F4_0). unfold magma_op, refa648_inst, refa648_op in H. discriminate H. Qed.

Lemma refa648_not261 : ~ @Equation261 Fin4 refa648_inst.
Proof. unfold Equation261. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa648_inst, refa648_op in H. discriminate H. Qed.

Lemma refa648_not263 : ~ @Equation263 Fin4 refa648_inst.
Proof. unfold Equation263. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa648_inst, refa648_op in H. discriminate H. Qed.

Lemma refa648_not411 : ~ @Equation411 Fin4 refa648_inst.
Proof. unfold Equation411. intro H. specialize (H F4_0). unfold magma_op, refa648_inst, refa648_op in H. discriminate H. Qed.

Lemma refa648_not619 : ~ @Equation619 Fin4 refa648_inst.
Proof. unfold Equation619. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa648_inst, refa648_op in H. discriminate H. Qed.

Lemma refa648_not620 : ~ @Equation620 Fin4 refa648_inst.
Proof. unfold Equation620. intro H. specialize (H F4_0 F4_2). unfold magma_op, refa648_inst, refa648_op in H. discriminate H. Qed.

Lemma refa648_not622 : ~ @Equation622 Fin4 refa648_inst.
Proof. unfold Equation622. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa648_inst, refa648_op in H. discriminate H. Qed.

Lemma refa648_not623 : ~ @Equation623 Fin4 refa648_inst.
Proof. unfold Equation623. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa648_inst, refa648_op in H. discriminate H. Qed.

Lemma refa648_not629 : ~ @Equation629 Fin4 refa648_inst.
Proof. unfold Equation629. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa648_inst, refa648_op in H. discriminate H. Qed.

Lemma refa648_not630 : ~ @Equation630 Fin4 refa648_inst.
Proof. unfold Equation630. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa648_inst, refa648_op in H. discriminate H. Qed.

Lemma refa648_not632 : ~ @Equation632 Fin4 refa648_inst.
Proof. unfold Equation632. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa648_inst, refa648_op in H. discriminate H. Qed.

Lemma refa648_not633 : ~ @Equation633 Fin4 refa648_inst.
Proof. unfold Equation633. intro H. specialize (H F4_0 F4_2). unfold magma_op, refa648_inst, refa648_op in H. discriminate H. Qed.

Lemma refa648_not639 : ~ @Equation639 Fin4 refa648_inst.
Proof. unfold Equation639. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa648_inst, refa648_op in H. discriminate H. Qed.

Lemma refa648_not640 : ~ @Equation640 Fin4 refa648_inst.
Proof. unfold Equation640. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa648_inst, refa648_op in H. discriminate H. Qed.

Lemma refa648_not642 : ~ @Equation642 Fin4 refa648_inst.
Proof. unfold Equation642. intro H. specialize (H F4_0 F4_2). unfold magma_op, refa648_inst, refa648_op in H. discriminate H. Qed.

Lemma refa648_not643 : ~ @Equation643 Fin4 refa648_inst.
Proof. unfold Equation643. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa648_inst, refa648_op in H. discriminate H. Qed.

Lemma refa648_not819 : ~ @Equation819 Fin4 refa648_inst.
Proof. unfold Equation819. intro H. specialize (H F4_0 F4_2). unfold magma_op, refa648_inst, refa648_op in H. discriminate H. Qed.

Lemma refa648_not832 : ~ @Equation832 Fin4 refa648_inst.
Proof. unfold Equation832. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa648_inst, refa648_op in H. discriminate H. Qed.

Lemma refa648_not833 : ~ @Equation833 Fin4 refa648_inst.
Proof. unfold Equation833. intro H. specialize (H F4_0 F4_2). unfold magma_op, refa648_inst, refa648_op in H. discriminate H. Qed.

Lemma refa648_not835 : ~ @Equation835 Fin4 refa648_inst.
Proof. unfold Equation835. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa648_inst, refa648_op in H. discriminate H. Qed.

Lemma refa648_not836 : ~ @Equation836 Fin4 refa648_inst.
Proof. unfold Equation836. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa648_inst, refa648_op in H. discriminate H. Qed.

Lemma refa648_not842 : ~ @Equation842 Fin4 refa648_inst.
Proof. unfold Equation842. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa648_inst, refa648_op in H. discriminate H. Qed.

Lemma refa648_not843 : ~ @Equation843 Fin4 refa648_inst.
Proof. unfold Equation843. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa648_inst, refa648_op in H. discriminate H. Qed.

Lemma refa648_not845 : ~ @Equation845 Fin4 refa648_inst.
Proof. unfold Equation845. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa648_inst, refa648_op in H. discriminate H. Qed.

Lemma refa648_not1023 : ~ @Equation1023 Fin4 refa648_inst.
Proof. unfold Equation1023. intro H. specialize (H F4_0 F4_0). unfold magma_op, refa648_inst, refa648_op in H. discriminate H. Qed.

Lemma refa648_not1028 : ~ @Equation1028 Fin4 refa648_inst.
Proof. unfold Equation1028. intro H. specialize (H F4_0 F4_0). unfold magma_op, refa648_inst, refa648_op in H. discriminate H. Qed.

Lemma refa648_not1029 : ~ @Equation1029 Fin4 refa648_inst.
Proof. unfold Equation1029. intro H. specialize (H F4_0 F4_0). unfold magma_op, refa648_inst, refa648_op in H. discriminate H. Qed.

Lemma refa648_not1035 : ~ @Equation1035 Fin4 refa648_inst.
Proof. unfold Equation1035. intro H. specialize (H F4_0 F4_0). unfold magma_op, refa648_inst, refa648_op in H. discriminate H. Qed.

Lemma refa648_not1036 : ~ @Equation1036 Fin4 refa648_inst.
Proof. unfold Equation1036. intro H. specialize (H F4_0 F4_0). unfold magma_op, refa648_inst, refa648_op in H. discriminate H. Qed.

Lemma refa648_not1039 : ~ @Equation1039 Fin4 refa648_inst.
Proof. unfold Equation1039. intro H. specialize (H F4_0 F4_0). unfold magma_op, refa648_inst, refa648_op in H. discriminate H. Qed.

Lemma refa648_not1045 : ~ @Equation1045 Fin4 refa648_inst.
Proof. unfold Equation1045. intro H. specialize (H F4_0 F4_0). unfold magma_op, refa648_inst, refa648_op in H. discriminate H. Qed.

Lemma refa648_not1046 : ~ @Equation1046 Fin4 refa648_inst.
Proof. unfold Equation1046. intro H. specialize (H F4_0 F4_0). unfold magma_op, refa648_inst, refa648_op in H. discriminate H. Qed.

Lemma refa648_not1048 : ~ @Equation1048 Fin4 refa648_inst.
Proof. unfold Equation1048. intro H. specialize (H F4_0 F4_0). unfold magma_op, refa648_inst, refa648_op in H. discriminate H. Qed.

Lemma refa648_not1223 : ~ @Equation1223 Fin4 refa648_inst.
Proof. unfold Equation1223. intro H. specialize (H F4_0). unfold magma_op, refa648_inst, refa648_op in H. discriminate H. Qed.

Lemma refa648_not1426 : ~ @Equation1426 Fin4 refa648_inst.
Proof. unfold Equation1426. intro H. specialize (H F4_0). unfold magma_op, refa648_inst, refa648_op in H. discriminate H. Qed.

Lemma refa648_not1629 : ~ @Equation1629 Fin4 refa648_inst.
Proof. unfold Equation1629. intro H. specialize (H F4_0). unfold magma_op, refa648_inst, refa648_op in H. discriminate H. Qed.

Lemma refa648_not1832 : ~ @Equation1832 Fin4 refa648_inst.
Proof. unfold Equation1832. intro H. specialize (H F4_0). unfold magma_op, refa648_inst, refa648_op in H. discriminate H. Qed.

Lemma refa648_not2035 : ~ @Equation2035 Fin4 refa648_inst.
Proof. unfold Equation2035. intro H. specialize (H F4_0). unfold magma_op, refa648_inst, refa648_op in H. discriminate H. Qed.

Lemma refa648_not2238 : ~ @Equation2238 Fin4 refa648_inst.
Proof. unfold Equation2238. intro H. specialize (H F4_0). unfold magma_op, refa648_inst, refa648_op in H. discriminate H. Qed.

Lemma refa648_not2441 : ~ @Equation2441 Fin4 refa648_inst.
Proof. unfold Equation2441. intro H. specialize (H F4_0). unfold magma_op, refa648_inst, refa648_op in H. discriminate H. Qed.

Lemma refa648_not2646 : ~ @Equation2646 Fin4 refa648_inst.
Proof. unfold Equation2646. intro H. specialize (H F4_0 F4_0). unfold magma_op, refa648_inst, refa648_op in H. discriminate H. Qed.

Lemma refa648_not2647 : ~ @Equation2647 Fin4 refa648_inst.
Proof. unfold Equation2647. intro H. specialize (H F4_0 F4_0). unfold magma_op, refa648_inst, refa648_op in H. discriminate H. Qed.

Lemma refa648_not2649 : ~ @Equation2649 Fin4 refa648_inst.
Proof. unfold Equation2649. intro H. specialize (H F4_0 F4_0). unfold magma_op, refa648_inst, refa648_op in H. discriminate H. Qed.

Lemma refa648_not2650 : ~ @Equation2650 Fin4 refa648_inst.
Proof. unfold Equation2650. intro H. specialize (H F4_0 F4_0). unfold magma_op, refa648_inst, refa648_op in H. discriminate H. Qed.

Lemma refa648_not2652 : ~ @Equation2652 Fin4 refa648_inst.
Proof. unfold Equation2652. intro H. specialize (H F4_0 F4_0). unfold magma_op, refa648_inst, refa648_op in H. discriminate H. Qed.

Lemma refa648_not2659 : ~ @Equation2659 Fin4 refa648_inst.
Proof. unfold Equation2659. intro H. specialize (H F4_0 F4_0). unfold magma_op, refa648_inst, refa648_op in H. discriminate H. Qed.

Lemma refa648_not2660 : ~ @Equation2660 Fin4 refa648_inst.
Proof. unfold Equation2660. intro H. specialize (H F4_0 F4_0). unfold magma_op, refa648_inst, refa648_op in H. discriminate H. Qed.

Lemma refa648_not2662 : ~ @Equation2662 Fin4 refa648_inst.
Proof. unfold Equation2662. intro H. specialize (H F4_0 F4_0). unfold magma_op, refa648_inst, refa648_op in H. discriminate H. Qed.

Lemma refa648_not2669 : ~ @Equation2669 Fin4 refa648_inst.
Proof. unfold Equation2669. intro H. specialize (H F4_0 F4_0). unfold magma_op, refa648_inst, refa648_op in H. discriminate H. Qed.

Lemma refa648_not2670 : ~ @Equation2670 Fin4 refa648_inst.
Proof. unfold Equation2670. intro H. specialize (H F4_0 F4_0). unfold magma_op, refa648_inst, refa648_op in H. discriminate H. Qed.

Lemma refa648_not2672 : ~ @Equation2672 Fin4 refa648_inst.
Proof. unfold Equation2672. intro H. specialize (H F4_0 F4_0). unfold magma_op, refa648_inst, refa648_op in H. discriminate H. Qed.

Lemma refa648_not2849 : ~ @Equation2849 Fin4 refa648_inst.
Proof. unfold Equation2849. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa648_inst, refa648_op in H. discriminate H. Qed.

Lemma refa648_not2852 : ~ @Equation2852 Fin4 refa648_inst.
Proof. unfold Equation2852. intro H. specialize (H F4_0 F4_2). unfold magma_op, refa648_inst, refa648_op in H. discriminate H. Qed.

Lemma refa648_not2853 : ~ @Equation2853 Fin4 refa648_inst.
Proof. unfold Equation2853. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa648_inst, refa648_op in H. discriminate H. Qed.

Lemma refa648_not2855 : ~ @Equation2855 Fin4 refa648_inst.
Proof. unfold Equation2855. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa648_inst, refa648_op in H. discriminate H. Qed.

Lemma refa648_not2856 : ~ @Equation2856 Fin4 refa648_inst.
Proof. unfold Equation2856. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa648_inst, refa648_op in H. discriminate H. Qed.

Lemma refa648_not2862 : ~ @Equation2862 Fin4 refa648_inst.
Proof. unfold Equation2862. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa648_inst, refa648_op in H. discriminate H. Qed.

Lemma refa648_not2863 : ~ @Equation2863 Fin4 refa648_inst.
Proof. unfold Equation2863. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa648_inst, refa648_op in H. discriminate H. Qed.

Lemma refa648_not2865 : ~ @Equation2865 Fin4 refa648_inst.
Proof. unfold Equation2865. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa648_inst, refa648_op in H. discriminate H. Qed.

Lemma refa648_not2866 : ~ @Equation2866 Fin4 refa648_inst.
Proof. unfold Equation2866. intro H. specialize (H F4_0 F4_2). unfold magma_op, refa648_inst, refa648_op in H. discriminate H. Qed.

Lemma refa648_not2872 : ~ @Equation2872 Fin4 refa648_inst.
Proof. unfold Equation2872. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa648_inst, refa648_op in H. discriminate H. Qed.

Lemma refa648_not2873 : ~ @Equation2873 Fin4 refa648_inst.
Proof. unfold Equation2873. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa648_inst, refa648_op in H. discriminate H. Qed.

Lemma refa648_not2875 : ~ @Equation2875 Fin4 refa648_inst.
Proof. unfold Equation2875. intro H. specialize (H F4_0 F4_2). unfold magma_op, refa648_inst, refa648_op in H. discriminate H. Qed.

Lemma refa648_not3050 : ~ @Equation3050 Fin4 refa648_inst.
Proof. unfold Equation3050. intro H. specialize (H F4_0). unfold magma_op, refa648_inst, refa648_op in H. discriminate H. Qed.

Lemma refa648_not3255 : ~ @Equation3255 Fin4 refa648_inst.
Proof. unfold Equation3255. intro H. specialize (H F4_0 F4_3). unfold magma_op, refa648_inst, refa648_op in H. discriminate H. Qed.

Lemma refa648_not3256 : ~ @Equation3256 Fin4 refa648_inst.
Proof. unfold Equation3256. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa648_inst, refa648_op in H. discriminate H. Qed.

Lemma refa648_not3258 : ~ @Equation3258 Fin4 refa648_inst.
Proof. unfold Equation3258. intro H. specialize (H F4_0 F4_2). unfold magma_op, refa648_inst, refa648_op in H. discriminate H. Qed.

Lemma refa648_not3259 : ~ @Equation3259 Fin4 refa648_inst.
Proof. unfold Equation3259. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa648_inst, refa648_op in H. discriminate H. Qed.

Lemma refa648_not3261 : ~ @Equation3261 Fin4 refa648_inst.
Proof. unfold Equation3261. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa648_inst, refa648_op in H. discriminate H. Qed.

Lemma refa648_not3262 : ~ @Equation3262 Fin4 refa648_inst.
Proof. unfold Equation3262. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa648_inst, refa648_op in H. discriminate H. Qed.

Lemma refa648_not3306 : ~ @Equation3306 Fin4 refa648_inst.
Proof. unfold Equation3306. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa648_inst, refa648_op in H. discriminate H. Qed.

Lemma refa648_not3308 : ~ @Equation3308 Fin4 refa648_inst.
Proof. unfold Equation3308. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa648_inst, refa648_op in H. discriminate H. Qed.

Lemma refa648_not3309 : ~ @Equation3309 Fin4 refa648_inst.
Proof. unfold Equation3309. intro H. specialize (H F4_0 F4_2). unfold magma_op, refa648_inst, refa648_op in H. discriminate H. Qed.

Lemma refa648_not3315 : ~ @Equation3315 Fin4 refa648_inst.
Proof. unfold Equation3315. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa648_inst, refa648_op in H. discriminate H. Qed.

Lemma refa648_not3316 : ~ @Equation3316 Fin4 refa648_inst.
Proof. unfold Equation3316. intro H. specialize (H F4_0 F4_2). unfold magma_op, refa648_inst, refa648_op in H. discriminate H. Qed.

Lemma refa648_not3318 : ~ @Equation3318 Fin4 refa648_inst.
Proof. unfold Equation3318. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa648_inst, refa648_op in H. discriminate H. Qed.

Lemma refa648_not3319 : ~ @Equation3319 Fin4 refa648_inst.
Proof. unfold Equation3319. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa648_inst, refa648_op in H. discriminate H. Qed.

Lemma refa648_not3456 : ~ @Equation3456 Fin4 refa648_inst.
Proof. unfold Equation3456. intro H. specialize (H F4_0). unfold magma_op, refa648_inst, refa648_op in H. discriminate H. Qed.

Lemma refa648_not3660 : ~ @Equation3660 Fin4 refa648_inst.
Proof. unfold Equation3660. intro H. specialize (H F4_0 F4_0). unfold magma_op, refa648_inst, refa648_op in H. discriminate H. Qed.

Lemma refa648_not3661 : ~ @Equation3661 Fin4 refa648_inst.
Proof. unfold Equation3661. intro H. specialize (H F4_0 F4_0). unfold magma_op, refa648_inst, refa648_op in H. discriminate H. Qed.

Lemma refa648_not3662 : ~ @Equation3662 Fin4 refa648_inst.
Proof. unfold Equation3662. intro H. specialize (H F4_0 F4_0). unfold magma_op, refa648_inst, refa648_op in H. discriminate H. Qed.

Lemma refa648_not3664 : ~ @Equation3664 Fin4 refa648_inst.
Proof. unfold Equation3664. intro H. specialize (H F4_0 F4_0). unfold magma_op, refa648_inst, refa648_op in H. discriminate H. Qed.

Lemma refa648_not3665 : ~ @Equation3665 Fin4 refa648_inst.
Proof. unfold Equation3665. intro H. specialize (H F4_0 F4_0). unfold magma_op, refa648_inst, refa648_op in H. discriminate H. Qed.

Lemma refa648_not3667 : ~ @Equation3667 Fin4 refa648_inst.
Proof. unfold Equation3667. intro H. specialize (H F4_0 F4_0). unfold magma_op, refa648_inst, refa648_op in H. discriminate H. Qed.

Lemma refa648_not3668 : ~ @Equation3668 Fin4 refa648_inst.
Proof. unfold Equation3668. intro H. specialize (H F4_0 F4_0). unfold magma_op, refa648_inst, refa648_op in H. discriminate H. Qed.

Lemma refa648_not3712 : ~ @Equation3712 Fin4 refa648_inst.
Proof. unfold Equation3712. intro H. specialize (H F4_0 F4_0). unfold magma_op, refa648_inst, refa648_op in H. discriminate H. Qed.

Lemma refa648_not3714 : ~ @Equation3714 Fin4 refa648_inst.
Proof. unfold Equation3714. intro H. specialize (H F4_0 F4_0). unfold magma_op, refa648_inst, refa648_op in H. discriminate H. Qed.

Lemma refa648_not3721 : ~ @Equation3721 Fin4 refa648_inst.
Proof. unfold Equation3721. intro H. specialize (H F4_0 F4_0). unfold magma_op, refa648_inst, refa648_op in H. discriminate H. Qed.

Lemma refa648_not3722 : ~ @Equation3722 Fin4 refa648_inst.
Proof. unfold Equation3722. intro H. specialize (H F4_0 F4_0). unfold magma_op, refa648_inst, refa648_op in H. discriminate H. Qed.

Lemma refa648_not3724 : ~ @Equation3724 Fin4 refa648_inst.
Proof. unfold Equation3724. intro H. specialize (H F4_0 F4_0). unfold magma_op, refa648_inst, refa648_op in H. discriminate H. Qed.

Lemma refa648_not3725 : ~ @Equation3725 Fin4 refa648_inst.
Proof. unfold Equation3725. intro H. specialize (H F4_0 F4_0). unfold magma_op, refa648_inst, refa648_op in H. discriminate H. Qed.

Lemma refa648_not3862 : ~ @Equation3862 Fin4 refa648_inst.
Proof. unfold Equation3862. intro H. specialize (H F4_0). unfold magma_op, refa648_inst, refa648_op in H. discriminate H. Qed.

Lemma refa648_not4065 : ~ @Equation4065 Fin4 refa648_inst.
Proof. unfold Equation4065. intro H. specialize (H F4_0). unfold magma_op, refa648_inst, refa648_op in H. discriminate H. Qed.

Lemma refa648_not4268 : ~ @Equation4268 Fin4 refa648_inst.
Proof. unfold Equation4268. intro H. specialize (H F4_0 F4_2). unfold magma_op, refa648_inst, refa648_op in H. discriminate H. Qed.

Lemma refa648_not4269 : ~ @Equation4269 Fin4 refa648_inst.
Proof. unfold Equation4269. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa648_inst, refa648_op in H. discriminate H. Qed.

Lemma refa648_not4270 : ~ @Equation4270 Fin4 refa648_inst.
Proof. unfold Equation4270. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa648_inst, refa648_op in H. discriminate H. Qed.

Lemma refa648_not4283 : ~ @Equation4283 Fin4 refa648_inst.
Proof. unfold Equation4283. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa648_inst, refa648_op in H. discriminate H. Qed.

Lemma refa648_not4284 : ~ @Equation4284 Fin4 refa648_inst.
Proof. unfold Equation4284. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa648_inst, refa648_op in H. discriminate H. Qed.

Lemma refa648_not4314 : ~ @Equation4314 Fin4 refa648_inst.
Proof. unfold Equation4314. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa648_inst, refa648_op in H. discriminate H. Qed.

Lemma refa648_not4380 : ~ @Equation4380 Fin4 refa648_inst.
Proof. unfold Equation4380. intro H. specialize (H F4_0). unfold magma_op, refa648_inst, refa648_op in H. discriminate H. Qed.

Lemma refa648_not4583 : ~ @Equation4583 Fin4 refa648_inst.
Proof. unfold Equation4583. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa648_inst, refa648_op in H. discriminate H. Qed.

Lemma refa648_not4584 : ~ @Equation4584 Fin4 refa648_inst.
Proof. unfold Equation4584. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa648_inst, refa648_op in H. discriminate H. Qed.

Lemma refa648_not4585 : ~ @Equation4585 Fin4 refa648_inst.
Proof. unfold Equation4585. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa648_inst, refa648_op in H. discriminate H. Qed.

Lemma refa648_not4599 : ~ @Equation4599 Fin4 refa648_inst.
Proof. unfold Equation4599. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa648_inst, refa648_op in H. discriminate H. Qed.

Lemma refa648_not4629 : ~ @Equation4629 Fin4 refa648_inst.
Proof. unfold Equation4629. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa648_inst, refa648_op in H. discriminate H. Qed.

(** ---- refa649 (Fin4) ---- *)

Definition refa649_op (x y : Fin4) : Fin4 :=
  match x, y with
  | F4_0, F4_0 => F4_0 | F4_0, F4_1 => F4_3 | F4_0, F4_2 => F4_1 | F4_0, F4_3 => F4_3
  | F4_1, F4_0 => F4_3 | F4_1, F4_1 => F4_1 | F4_1, F4_2 => F4_2 | F4_1, F4_3 => F4_3
  | F4_2, F4_0 => F4_0 | F4_2, F4_1 => F4_3 | F4_2, F4_2 => F4_2 | F4_2, F4_3 => F4_3
  | F4_3, F4_0 => F4_0 | F4_3, F4_1 => F4_1 | F4_3, F4_2 => F4_2 | F4_3, F4_3 => F4_3
  end.

#[local] Instance refa649_inst : Magma Fin4 := {| magma_op := refa649_op |}.

Lemma refa649_sat2415 : @Equation2415 Fin4 refa649_inst.
Proof. unfold Equation2415, magma_op, refa649_inst, refa649_op. intros x y z w. destruct x, y, z, w; reflexivity. Qed.

Lemma refa649_not3306 : ~ @Equation3306 Fin4 refa649_inst.
Proof. unfold Equation3306. intro H. specialize (H F4_0 F4_2). unfold magma_op, refa649_inst, refa649_op in H. discriminate H. Qed.

Lemma refa649_not3346 : ~ @Equation3346 Fin4 refa649_inst.
Proof. unfold Equation3346. intro H. specialize (H F4_0 F4_2). unfold magma_op, refa649_inst, refa649_op in H. discriminate H. Qed.

Lemma refa649_not3353 : ~ @Equation3353 Fin4 refa649_inst.
Proof. unfold Equation3353. intro H. specialize (H F4_0 F4_2). unfold magma_op, refa649_inst, refa649_op in H. discriminate H. Qed.

Lemma refa649_not3546 : ~ @Equation3546 Fin4 refa649_inst.
Proof. unfold Equation3546. intro H. specialize (H F4_0 F4_2). unfold magma_op, refa649_inst, refa649_op in H. discriminate H. Qed.

Lemma refa649_not3556 : ~ @Equation3556 Fin4 refa649_inst.
Proof. unfold Equation3556. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa649_inst, refa649_op in H. discriminate H. Qed.

Lemma refa649_not3752 : ~ @Equation3752 Fin4 refa649_inst.
Proof. unfold Equation3752. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa649_inst, refa649_op in H. discriminate H. Qed.

Lemma refa649_not3759 : ~ @Equation3759 Fin4 refa649_inst.
Proof. unfold Equation3759. intro H. specialize (H F4_0 F4_2). unfold magma_op, refa649_inst, refa649_op in H. discriminate H. Qed.

Lemma refa649_not3925 : ~ @Equation3925 Fin4 refa649_inst.
Proof. unfold Equation3925. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa649_inst, refa649_op in H. discriminate H. Qed.

Lemma refa649_not3952 : ~ @Equation3952 Fin4 refa649_inst.
Proof. unfold Equation3952. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa649_inst, refa649_op in H. discriminate H. Qed.

Lemma refa649_not3962 : ~ @Equation3962 Fin4 refa649_inst.
Proof. unfold Equation3962. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa649_inst, refa649_op in H. discriminate H. Qed.

Lemma refa649_not4128 : ~ @Equation4128 Fin4 refa649_inst.
Proof. unfold Equation4128. intro H. specialize (H F4_0 F4_2). unfold magma_op, refa649_inst, refa649_op in H. discriminate H. Qed.

Lemma refa649_not4165 : ~ @Equation4165 Fin4 refa649_inst.
Proof. unfold Equation4165. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa649_inst, refa649_op in H. discriminate H. Qed.

Lemma refa649_not4320 : ~ @Equation4320 Fin4 refa649_inst.
Proof. unfold Equation4320. intro H. specialize (H F4_2 F4_0). unfold magma_op, refa649_inst, refa649_op in H. discriminate H. Qed.

Lemma refa649_not4435 : ~ @Equation4435 Fin4 refa649_inst.
Proof. unfold Equation4435. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa649_inst, refa649_op in H. discriminate H. Qed.

Lemma refa649_not4445 : ~ @Equation4445 Fin4 refa649_inst.
Proof. unfold Equation4445. intro H. specialize (H F4_2 F4_0). unfold magma_op, refa649_inst, refa649_op in H. discriminate H. Qed.

Lemma refa649_not4480 : ~ @Equation4480 Fin4 refa649_inst.
Proof. unfold Equation4480. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa649_inst, refa649_op in H. discriminate H. Qed.

Lemma refa649_not4606 : ~ @Equation4606 Fin4 refa649_inst.
Proof. unfold Equation4606. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa649_inst, refa649_op in H. discriminate H. Qed.

(** ---- refa65 (Fin3) ---- *)

Definition refa65_op (x y : Fin3) : Fin3 :=
  match x, y with
  | F3_0, F3_0 => F3_0 | F3_0, F3_1 => F3_1 | F3_0, F3_2 => F3_2
  | F3_1, F3_0 => F3_0 | F3_1, F3_1 => F3_2 | F3_1, F3_2 => F3_2
  | F3_2, F3_0 => F3_2 | F3_2, F3_1 => F3_1 | F3_2, F3_2 => F3_0
  end.

#[local] Instance refa65_inst : Magma Fin3 := {| magma_op := refa65_op |}.

Lemma refa65_sat3105 : @Equation3105 Fin3 refa65_inst.
Proof. unfold Equation3105, magma_op, refa65_inst, refa65_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa65_not2466 : ~ @Equation2466 Fin3 refa65_inst.
Proof. unfold Equation2466. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa65_inst, refa65_op in H. discriminate H. Qed.

Lemma refa65_not3659 : ~ @Equation3659 Fin3 refa65_inst.
Proof. unfold Equation3659. intro H. specialize (H F3_1). unfold magma_op, refa65_inst, refa65_op in H. discriminate H. Qed.

Lemma refa65_not4590 : ~ @Equation4590 Fin3 refa65_inst.
Proof. unfold Equation4590. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa65_inst, refa65_op in H. discriminate H. Qed.

(** ---- refa650 (Fin4) ---- *)

Definition refa650_op (x y : Fin4) : Fin4 :=
  match x, y with
  | F4_0, F4_0 => F4_1 | F4_0, F4_1 => F4_1 | F4_0, F4_2 => F4_3 | F4_0, F4_3 => F4_1
  | F4_1, F4_0 => F4_2 | F4_1, F4_1 => F4_1 | F4_1, F4_2 => F4_3 | F4_1, F4_3 => F4_2
  | F4_2, F4_0 => F4_0 | F4_2, F4_1 => F4_1 | F4_2, F4_2 => F4_1 | F4_2, F4_3 => F4_3
  | F4_3, F4_0 => F4_0 | F4_3, F4_1 => F4_1 | F4_3, F4_2 => F4_2 | F4_3, F4_3 => F4_1
  end.

#[local] Instance refa650_inst : Magma Fin4 := {| magma_op := refa650_op |}.

Lemma refa650_sat3007 : @Equation3007 Fin4 refa650_inst.
Proof. unfold Equation3007, magma_op, refa650_inst, refa650_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa650_not2909 : ~ @Equation2909 Fin4 refa650_inst.
Proof. unfold Equation2909. intro H. specialize (H F4_0 F4_2). unfold magma_op, refa650_inst, refa650_op in H. discriminate H. Qed.

(** ---- refa651 (Fin4) ---- *)

Definition refa651_op (x y : Fin4) : Fin4 :=
  match x, y with
  | F4_0, F4_0 => F4_0 | F4_0, F4_1 => F4_1 | F4_0, F4_2 => F4_3 | F4_0, F4_3 => F4_3
  | F4_1, F4_0 => F4_3 | F4_1, F4_1 => F4_1 | F4_1, F4_2 => F4_2 | F4_1, F4_3 => F4_2
  | F4_2, F4_0 => F4_0 | F4_2, F4_1 => F4_1 | F4_2, F4_2 => F4_2 | F4_2, F4_3 => F4_3
  | F4_3, F4_0 => F4_1 | F4_3, F4_1 => F4_2 | F4_3, F4_2 => F4_2 | F4_3, F4_3 => F4_3
  end.

#[local] Instance refa651_inst : Magma Fin4 := {| magma_op := refa651_op |}.

Lemma refa651_sat2337 : @Equation2337 Fin4 refa651_inst.
Proof. unfold Equation2337, magma_op, refa651_inst, refa651_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa651_not2530 : ~ @Equation2530 Fin4 refa651_inst.
Proof. unfold Equation2530. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa651_inst, refa651_op in H. discriminate H. Qed.

Lemma refa651_not2669 : ~ @Equation2669 Fin4 refa651_inst.
Proof. unfold Equation2669. intro H. specialize (H F4_0 F4_2). unfold magma_op, refa651_inst, refa651_op in H. discriminate H. Qed.

(** ---- refa652 (Fin4) ---- *)

Definition refa652_op (x y : Fin4) : Fin4 :=
  match x, y with
  | F4_0, F4_0 => F4_3 | F4_0, F4_1 => F4_3 | F4_0, F4_2 => F4_1 | F4_0, F4_3 => F4_3
  | F4_1, F4_0 => F4_3 | F4_1, F4_1 => F4_3 | F4_1, F4_2 => F4_1 | F4_1, F4_3 => F4_3
  | F4_2, F4_0 => F4_1 | F4_2, F4_1 => F4_1 | F4_2, F4_2 => F4_0 | F4_2, F4_3 => F4_0
  | F4_3, F4_0 => F4_3 | F4_3, F4_1 => F4_3 | F4_3, F4_2 => F4_1 | F4_3, F4_3 => F4_3
  end.

#[local] Instance refa652_inst : Magma Fin4 := {| magma_op := refa652_op |}.

Lemma refa652_sat4419 : @Equation4419 Fin4 refa652_inst.
Proof. unfold Equation4419, magma_op, refa652_inst, refa652_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa652_not4270 : ~ @Equation4270 Fin4 refa652_inst.
Proof. unfold Equation4270. intro H. specialize (H F4_2 F4_0). unfold magma_op, refa652_inst, refa652_op in H. discriminate H. Qed.

Lemma refa652_not4272 : ~ @Equation4272 Fin4 refa652_inst.
Proof. unfold Equation4272. intro H. specialize (H F4_0 F4_2). unfold magma_op, refa652_inst, refa652_op in H. discriminate H. Qed.

Lemma refa652_not4275 : ~ @Equation4275 Fin4 refa652_inst.
Proof. unfold Equation4275. intro H. specialize (H F4_0 F4_2). unfold magma_op, refa652_inst, refa652_op in H. discriminate H. Qed.

Lemma refa652_not4276 : ~ @Equation4276 Fin4 refa652_inst.
Proof. unfold Equation4276. intro H. specialize (H F4_0 F4_2). unfold magma_op, refa652_inst, refa652_op in H. discriminate H. Qed.

Lemma refa652_not4284 : ~ @Equation4284 Fin4 refa652_inst.
Proof. unfold Equation4284. intro H. specialize (H F4_2 F4_0). unfold magma_op, refa652_inst, refa652_op in H. discriminate H. Qed.

Lemma refa652_not4290 : ~ @Equation4290 Fin4 refa652_inst.
Proof. unfold Equation4290. intro H. specialize (H F4_0 F4_2). unfold magma_op, refa652_inst, refa652_op in H. discriminate H. Qed.

Lemma refa652_not4293 : ~ @Equation4293 Fin4 refa652_inst.
Proof. unfold Equation4293. intro H. specialize (H F4_0 F4_2). unfold magma_op, refa652_inst, refa652_op in H. discriminate H. Qed.

Lemma refa652_not4343 : ~ @Equation4343 Fin4 refa652_inst.
Proof. unfold Equation4343. intro H. specialize (H F4_0 F4_2). unfold magma_op, refa652_inst, refa652_op in H. discriminate H. Qed.

Lemma refa652_not4396 : ~ @Equation4396 Fin4 refa652_inst.
Proof. unfold Equation4396. intro H. specialize (H F4_0 F4_2). unfold magma_op, refa652_inst, refa652_op in H. discriminate H. Qed.

Lemma refa652_not4399 : ~ @Equation4399 Fin4 refa652_inst.
Proof. unfold Equation4399. intro H. specialize (H F4_0 F4_2). unfold magma_op, refa652_inst, refa652_op in H. discriminate H. Qed.

Lemma refa652_not4406 : ~ @Equation4406 Fin4 refa652_inst.
Proof. unfold Equation4406. intro H. specialize (H F4_0 F4_2). unfold magma_op, refa652_inst, refa652_op in H. discriminate H. Qed.

Lemma refa652_not4470 : ~ @Equation4470 Fin4 refa652_inst.
Proof. unfold Equation4470. intro H. specialize (H F4_0 F4_2). unfold magma_op, refa652_inst, refa652_op in H. discriminate H. Qed.

Lemma refa652_not4472 : ~ @Equation4472 Fin4 refa652_inst.
Proof. unfold Equation4472. intro H. specialize (H F4_2 F4_0). unfold magma_op, refa652_inst, refa652_op in H. discriminate H. Qed.

Lemma refa652_not4473 : ~ @Equation4473 Fin4 refa652_inst.
Proof. unfold Equation4473. intro H. specialize (H F4_0 F4_2). unfold magma_op, refa652_inst, refa652_op in H. discriminate H. Qed.

Lemma refa652_not4479 : ~ @Equation4479 Fin4 refa652_inst.
Proof. unfold Equation4479. intro H. specialize (H F4_2 F4_0). unfold magma_op, refa652_inst, refa652_op in H. discriminate H. Qed.

Lemma refa652_not4480 : ~ @Equation4480 Fin4 refa652_inst.
Proof. unfold Equation4480. intro H. specialize (H F4_0 F4_2). unfold magma_op, refa652_inst, refa652_op in H. discriminate H. Qed.

Lemma refa652_not4482 : ~ @Equation4482 Fin4 refa652_inst.
Proof. unfold Equation4482. intro H. specialize (H F4_2 F4_0). unfold magma_op, refa652_inst, refa652_op in H. discriminate H. Qed.

Lemma refa652_not4583 : ~ @Equation4583 Fin4 refa652_inst.
Proof. unfold Equation4583. intro H. specialize (H F4_0 F4_2). unfold magma_op, refa652_inst, refa652_op in H. discriminate H. Qed.

Lemma refa652_not4591 : ~ @Equation4591 Fin4 refa652_inst.
Proof. unfold Equation4591. intro H. specialize (H F4_0 F4_2). unfold magma_op, refa652_inst, refa652_op in H. discriminate H. Qed.

Lemma refa652_not4598 : ~ @Equation4598 Fin4 refa652_inst.
Proof. unfold Equation4598. intro H. specialize (H F4_0 F4_2). unfold magma_op, refa652_inst, refa652_op in H. discriminate H. Qed.

Lemma refa652_not4605 : ~ @Equation4605 Fin4 refa652_inst.
Proof. unfold Equation4605. intro H. specialize (H F4_0 F4_2). unfold magma_op, refa652_inst, refa652_op in H. discriminate H. Qed.

Lemma refa652_not4608 : ~ @Equation4608 Fin4 refa652_inst.
Proof. unfold Equation4608. intro H. specialize (H F4_0 F4_2). unfold magma_op, refa652_inst, refa652_op in H. discriminate H. Qed.

Lemma refa652_not4629 : ~ @Equation4629 Fin4 refa652_inst.
Proof. unfold Equation4629. intro H. specialize (H F4_0 F4_2). unfold magma_op, refa652_inst, refa652_op in H. discriminate H. Qed.

Lemma refa652_not4636 : ~ @Equation4636 Fin4 refa652_inst.
Proof. unfold Equation4636. intro H. specialize (H F4_0 F4_2). unfold magma_op, refa652_inst, refa652_op in H. discriminate H. Qed.

Lemma refa652_not4647 : ~ @Equation4647 Fin4 refa652_inst.
Proof. unfold Equation4647. intro H. specialize (H F4_0 F4_0 F4_2). unfold magma_op, refa652_inst, refa652_op in H. discriminate H. Qed.

Lemma refa652_not4656 : ~ @Equation4656 Fin4 refa652_inst.
Proof. unfold Equation4656. intro H. specialize (H F4_0 F4_0 F4_2). unfold magma_op, refa652_inst, refa652_op in H. discriminate H. Qed.

Lemma refa652_not4658 : ~ @Equation4658 Fin4 refa652_inst.
Proof. unfold Equation4658. intro H. specialize (H F4_0 F4_2). unfold magma_op, refa652_inst, refa652_op in H. discriminate H. Qed.

(** ---- refa653 (Fin4) ---- *)

Definition refa653_op (x y : Fin4) : Fin4 :=
  match x, y with
  | F4_0, F4_0 => F4_0 | F4_0, F4_1 => F4_2 | F4_0, F4_2 => F4_1 | F4_0, F4_3 => F4_3
  | F4_1, F4_0 => F4_0 | F4_1, F4_1 => F4_1 | F4_1, F4_2 => F4_3 | F4_1, F4_3 => F4_2
  | F4_2, F4_0 => F4_3 | F4_2, F4_1 => F4_1 | F4_2, F4_2 => F4_2 | F4_2, F4_3 => F4_0
  | F4_3, F4_0 => F4_1 | F4_3, F4_1 => F4_0 | F4_3, F4_2 => F4_2 | F4_3, F4_3 => F4_3
  end.

#[local] Instance refa653_inst : Magma Fin4 := {| magma_op := refa653_op |}.

Lemma refa653_sat3176 : @Equation3176 Fin4 refa653_inst.
Proof. unfold Equation3176, magma_op, refa653_inst, refa653_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa653_not2862 : ~ @Equation2862 Fin4 refa653_inst.
Proof. unfold Equation2862. intro H. specialize (H F4_0 F4_3). unfold magma_op, refa653_inst, refa653_op in H. discriminate H. Qed.

(** ---- refa654 (Fin4) ---- *)

Definition refa654_op (x y : Fin4) : Fin4 :=
  match x, y with
  | F4_0, F4_0 => F4_0 | F4_0, F4_1 => F4_3 | F4_0, F4_2 => F4_3 | F4_0, F4_3 => F4_3
  | F4_1, F4_0 => F4_2 | F4_1, F4_1 => F4_3 | F4_1, F4_2 => F4_2 | F4_1, F4_3 => F4_3
  | F4_2, F4_0 => F4_1 | F4_2, F4_1 => F4_1 | F4_2, F4_2 => F4_3 | F4_2, F4_3 => F4_3
  | F4_3, F4_0 => F4_0 | F4_3, F4_1 => F4_1 | F4_3, F4_2 => F4_2 | F4_3, F4_3 => F4_3
  end.

#[local] Instance refa654_inst : Magma Fin4 := {| magma_op := refa654_op |}.

Lemma refa654_sat2739 : @Equation2739 Fin4 refa654_inst.
Proof. unfold Equation2739, magma_op, refa654_inst, refa654_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa654_not2696 : ~ @Equation2696 Fin4 refa654_inst.
Proof. unfold Equation2696. intro H. specialize (H F4_0 F4_1). unfold magma_op, refa654_inst, refa654_op in H. discriminate H. Qed.

(** ---- refa655 (Fin5) ---- *)

Definition refa655_op (x y : Fin5) : Fin5 :=
  match x, y with
  | F5_0, F5_0 => F5_0 | F5_0, F5_1 => F5_2 | F5_0, F5_2 => F5_0 | F5_0, F5_3 => F5_4 | F5_0, F5_4 => F5_0
  | F5_1, F5_0 => F5_3 | F5_1, F5_1 => F5_1 | F5_1, F5_2 => F5_1 | F5_1, F5_3 => F5_1 | F5_1, F5_4 => F5_1
  | F5_2, F5_0 => F5_3 | F5_2, F5_1 => F5_2 | F5_2, F5_2 => F5_2 | F5_2, F5_3 => F5_2 | F5_2, F5_4 => F5_3
  | F5_3, F5_0 => F5_3 | F5_3, F5_1 => F5_2 | F5_3, F5_2 => F5_3 | F5_3, F5_3 => F5_3 | F5_3, F5_4 => F5_3
  | F5_4, F5_0 => F5_4 | F5_4, F5_1 => F5_4 | F5_4, F5_2 => F5_0 | F5_4, F5_3 => F5_4 | F5_4, F5_4 => F5_4
  end.

#[local] Instance refa655_inst : Magma Fin5 := {| magma_op := refa655_op |}.

Lemma refa655_sat1027 : @Equation1027 Fin5 refa655_inst.
Proof. unfold Equation1027, magma_op, refa655_inst, refa655_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa655_not822 : ~ @Equation822 Fin5 refa655_inst.
Proof. unfold Equation822. intro H. specialize (H F5_0 F5_1). unfold magma_op, refa655_inst, refa655_op in H. discriminate H. Qed.

Lemma refa655_not1028 : ~ @Equation1028 Fin5 refa655_inst.
Proof. unfold Equation1028. intro H. specialize (H F5_0 F5_1). unfold magma_op, refa655_inst, refa655_op in H. discriminate H. Qed.

Lemma refa655_not1225 : ~ @Equation1225 Fin5 refa655_inst.
Proof. unfold Equation1225. intro H. specialize (H F5_0 F5_1). unfold magma_op, refa655_inst, refa655_op in H. discriminate H. Qed.

Lemma refa655_not1228 : ~ @Equation1228 Fin5 refa655_inst.
Proof. unfold Equation1228. intro H. specialize (H F5_0 F5_1). unfold magma_op, refa655_inst, refa655_op in H. discriminate H. Qed.

Lemma refa655_not1231 : ~ @Equation1231 Fin5 refa655_inst.
Proof. unfold Equation1231. intro H. specialize (H F5_0 F5_1). unfold magma_op, refa655_inst, refa655_op in H. discriminate H. Qed.

Lemma refa655_not1631 : ~ @Equation1631 Fin5 refa655_inst.
Proof. unfold Equation1631. intro H. specialize (H F5_0 F5_1). unfold magma_op, refa655_inst, refa655_op in H. discriminate H. Qed.

Lemma refa655_not2446 : ~ @Equation2446 Fin5 refa655_inst.
Proof. unfold Equation2446. intro H. specialize (H F5_0 F5_1). unfold magma_op, refa655_inst, refa655_op in H. discriminate H. Qed.

Lemma refa655_not3316 : ~ @Equation3316 Fin5 refa655_inst.
Proof. unfold Equation3316. intro H. specialize (H F5_0 F5_2). unfold magma_op, refa655_inst, refa655_op in H. discriminate H. Qed.

Lemma refa655_not3458 : ~ @Equation3458 Fin5 refa655_inst.
Proof. unfold Equation3458. intro H. specialize (H F5_0 F5_1). unfold magma_op, refa655_inst, refa655_op in H. discriminate H. Qed.

Lemma refa655_not3925 : ~ @Equation3925 Fin5 refa655_inst.
Proof. unfold Equation3925. intro H. specialize (H F5_0 F5_1). unfold magma_op, refa655_inst, refa655_op in H. discriminate H. Qed.

(** ---- refa656 (Fin6) ---- *)

Definition refa656_op (x y : Fin6) : Fin6 :=
  match x, y with
  | F6_0, F6_0 => F6_0 | F6_0, F6_1 => F6_2 | F6_0, F6_2 => F6_0 | F6_0, F6_3 => F6_4 | F6_0, F6_4 => F6_5 | F6_0, F6_5 => F6_0
  | F6_1, F6_0 => F6_1 | F6_1, F6_1 => F6_1 | F6_1, F6_2 => F6_0 | F6_1, F6_3 => F6_0 | F6_1, F6_4 => F6_1 | F6_1, F6_5 => F6_0
  | F6_2, F6_0 => F6_3 | F6_2, F6_1 => F6_2 | F6_2, F6_2 => F6_2 | F6_2, F6_3 => F6_2 | F6_2, F6_4 => F6_2 | F6_2, F6_5 => F6_4
  | F6_3, F6_0 => F6_3 | F6_3, F6_1 => F6_3 | F6_3, F6_2 => F6_1 | F6_3, F6_3 => F6_3 | F6_3, F6_4 => F6_3 | F6_3, F6_5 => F6_4
  | F6_4, F6_0 => F6_4 | F6_4, F6_1 => F6_4 | F6_4, F6_2 => F6_0 | F6_4, F6_3 => F6_0 | F6_4, F6_4 => F6_4 | F6_4, F6_5 => F6_1
  | F6_5, F6_0 => F6_2 | F6_5, F6_1 => F6_2 | F6_5, F6_2 => F6_5 | F6_5, F6_3 => F6_5 | F6_5, F6_4 => F6_5 | F6_5, F6_5 => F6_5
  end.

#[local] Instance refa656_inst : Magma Fin6 := {| magma_op := refa656_op |}.

Lemma refa656_sat1032 : @Equation1032 Fin6 refa656_inst.
Proof. unfold Equation1032, magma_op, refa656_inst, refa656_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa656_not616 : ~ @Equation616 Fin6 refa656_inst.
Proof. unfold Equation616. intro H. specialize (H F6_0 F6_1). unfold magma_op, refa656_inst, refa656_op in H. discriminate H. Qed.

Lemma refa656_not825 : ~ @Equation825 Fin6 refa656_inst.
Proof. unfold Equation825. intro H. specialize (H F6_0 F6_2). unfold magma_op, refa656_inst, refa656_op in H. discriminate H. Qed.

Lemma refa656_not3318 : ~ @Equation3318 Fin6 refa656_inst.
Proof. unfold Equation3318. intro H. specialize (H F6_3 F6_0). unfold magma_op, refa656_inst, refa656_op in H. discriminate H. Qed.

Lemma refa656_not4131 : ~ @Equation4131 Fin6 refa656_inst.
Proof. unfold Equation4131. intro H. specialize (H F6_2 F6_5). unfold magma_op, refa656_inst, refa656_op in H. discriminate H. Qed.

(** ---- refa657 (Fin5) ---- *)

Definition refa657_op (x y : Fin5) : Fin5 :=
  match x, y with
  | F5_0, F5_0 => F5_0 | F5_0, F5_1 => F5_0 | F5_0, F5_2 => F5_3 | F5_0, F5_3 => F5_0 | F5_0, F5_4 => F5_1
  | F5_1, F5_0 => F5_2 | F5_1, F5_1 => F5_1 | F5_1, F5_2 => F5_1 | F5_1, F5_3 => F5_1 | F5_1, F5_4 => F5_1
  | F5_2, F5_0 => F5_3 | F5_2, F5_1 => F5_4 | F5_2, F5_2 => F5_2 | F5_2, F5_3 => F5_2 | F5_2, F5_4 => F5_2
  | F5_3, F5_0 => F5_3 | F5_3, F5_1 => F5_4 | F5_3, F5_2 => F5_3 | F5_3, F5_3 => F5_3 | F5_3, F5_4 => F5_3
  | F5_4, F5_0 => F5_3 | F5_4, F5_1 => F5_4 | F5_4, F5_2 => F5_3 | F5_4, F5_3 => F5_4 | F5_4, F5_4 => F5_4
  end.

#[local] Instance refa657_inst : Magma Fin5 := {| magma_op := refa657_op |}.

Lemma refa657_sat1033 : @Equation1033 Fin5 refa657_inst.
Proof. unfold Equation1033, magma_op, refa657_inst, refa657_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa657_not325 : ~ @Equation325 Fin5 refa657_inst.
Proof. unfold Equation325. intro H. specialize (H F5_0 F5_1). unfold magma_op, refa657_inst, refa657_op in H. discriminate H. Qed.

Lemma refa657_not377 : ~ @Equation377 Fin5 refa657_inst.
Proof. unfold Equation377. intro H. specialize (H F5_0 F5_4). unfold magma_op, refa657_inst, refa657_op in H. discriminate H. Qed.

Lemma refa657_not378 : ~ @Equation378 Fin5 refa657_inst.
Proof. unfold Equation378. intro H. specialize (H F5_1 F5_0). unfold magma_op, refa657_inst, refa657_op in H. discriminate H. Qed.

Lemma refa657_not822 : ~ @Equation822 Fin5 refa657_inst.
Proof. unfold Equation822. intro H. specialize (H F5_0 F5_4). unfold magma_op, refa657_inst, refa657_op in H. discriminate H. Qed.

Lemma refa657_not1026 : ~ @Equation1026 Fin5 refa657_inst.
Proof. unfold Equation1026. intro H. specialize (H F5_0 F5_1). unfold magma_op, refa657_inst, refa657_op in H. discriminate H. Qed.

Lemma refa657_not1028 : ~ @Equation1028 Fin5 refa657_inst.
Proof. unfold Equation1028. intro H. specialize (H F5_0 F5_4). unfold magma_op, refa657_inst, refa657_op in H. discriminate H. Qed.

Lemma refa657_not1225 : ~ @Equation1225 Fin5 refa657_inst.
Proof. unfold Equation1225. intro H. specialize (H F5_0 F5_4). unfold magma_op, refa657_inst, refa657_op in H. discriminate H. Qed.

Lemma refa657_not1229 : ~ @Equation1229 Fin5 refa657_inst.
Proof. unfold Equation1229. intro H. specialize (H F5_0 F5_4). unfold magma_op, refa657_inst, refa657_op in H. discriminate H. Qed.

Lemma refa657_not1231 : ~ @Equation1231 Fin5 refa657_inst.
Proof. unfold Equation1231. intro H. specialize (H F5_0 F5_4). unfold magma_op, refa657_inst, refa657_op in H. discriminate H. Qed.

Lemma refa657_not1631 : ~ @Equation1631 Fin5 refa657_inst.
Proof. unfold Equation1631. intro H. specialize (H F5_0 F5_4). unfold magma_op, refa657_inst, refa657_op in H. discriminate H. Qed.

Lemma refa657_not2446 : ~ @Equation2446 Fin5 refa657_inst.
Proof. unfold Equation2446. intro H. specialize (H F5_0 F5_4). unfold magma_op, refa657_inst, refa657_op in H. discriminate H. Qed.

Lemma refa657_not3458 : ~ @Equation3458 Fin5 refa657_inst.
Proof. unfold Equation3458. intro H. specialize (H F5_0 F5_4). unfold magma_op, refa657_inst, refa657_op in H. discriminate H. Qed.

(** ---- refa658 (Fin5) ---- *)

Definition refa658_op (x y : Fin5) : Fin5 :=
  match x, y with
  | F5_0, F5_0 => F5_0 | F5_0, F5_1 => F5_2 | F5_0, F5_2 => F5_0 | F5_0, F5_3 => F5_0 | F5_0, F5_4 => F5_2
  | F5_1, F5_0 => F5_1 | F5_1, F5_1 => F5_1 | F5_1, F5_2 => F5_4 | F5_1, F5_3 => F5_1 | F5_1, F5_4 => F5_1
  | F5_2, F5_0 => F5_3 | F5_2, F5_1 => F5_3 | F5_2, F5_2 => F5_2 | F5_2, F5_3 => F5_2 | F5_2, F5_4 => F5_2
  | F5_3, F5_0 => F5_4 | F5_3, F5_1 => F5_4 | F5_3, F5_2 => F5_4 | F5_3, F5_3 => F5_3 | F5_3, F5_4 => F5_3
  | F5_4, F5_0 => F5_3 | F5_4, F5_1 => F5_4 | F5_4, F5_2 => F5_3 | F5_4, F5_3 => F5_4 | F5_4, F5_4 => F5_4
  end.

#[local] Instance refa658_inst : Magma Fin5 := {| magma_op := refa658_op |}.

Lemma refa658_sat1030 : @Equation1030 Fin5 refa658_inst.
Proof. unfold Equation1030, magma_op, refa658_inst, refa658_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa658_not1229 : ~ @Equation1229 Fin5 refa658_inst.
Proof. unfold Equation1229. intro H. specialize (H F5_0 F5_1). unfold magma_op, refa658_inst, refa658_op in H. discriminate H. Qed.

Lemma refa658_not1231 : ~ @Equation1231 Fin5 refa658_inst.
Proof. unfold Equation1231. intro H. specialize (H F5_0 F5_1). unfold magma_op, refa658_inst, refa658_op in H. discriminate H. Qed.

Lemma refa658_not1232 : ~ @Equation1232 Fin5 refa658_inst.
Proof. unfold Equation1232. intro H. specialize (H F5_0 F5_1). unfold magma_op, refa658_inst, refa658_op in H. discriminate H. Qed.

(** ---- refa659 (Fin6) ---- *)

Definition refa659_op (x y : Fin6) : Fin6 :=
  match x, y with
  | F6_0, F6_0 => F6_0 | F6_0, F6_1 => F6_3 | F6_0, F6_2 => F6_3 | F6_0, F6_3 => F6_0 | F6_0, F6_4 => F6_5 | F6_0, F6_5 => F6_0
  | F6_1, F6_0 => F6_5 | F6_1, F6_1 => F6_1 | F6_1, F6_2 => F6_4 | F6_1, F6_3 => F6_1 | F6_1, F6_4 => F6_1 | F6_1, F6_5 => F6_1
  | F6_2, F6_0 => F6_5 | F6_2, F6_1 => F6_4 | F6_2, F6_2 => F6_2 | F6_2, F6_3 => F6_2 | F6_2, F6_4 => F6_2 | F6_2, F6_5 => F6_2
  | F6_3, F6_0 => F6_3 | F6_3, F6_1 => F6_3 | F6_3, F6_2 => F6_3 | F6_3, F6_3 => F6_3 | F6_3, F6_4 => F6_3 | F6_3, F6_5 => F6_3
  | F6_4, F6_0 => F6_5 | F6_4, F6_1 => F6_4 | F6_4, F6_2 => F6_4 | F6_4, F6_3 => F6_4 | F6_4, F6_4 => F6_4 | F6_4, F6_5 => F6_4
  | F6_5, F6_0 => F6_5 | F6_5, F6_1 => F6_5 | F6_5, F6_2 => F6_5 | F6_5, F6_3 => F6_5 | F6_5, F6_4 => F6_5 | F6_5, F6_5 => F6_5
  end.

#[local] Instance refa659_inst : Magma Fin6 := {| magma_op := refa659_op |}.

Lemma refa659_sat1037 : @Equation1037 Fin6 refa659_inst.
Proof. unfold Equation1037, magma_op, refa659_inst, refa659_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa659_not3931 : ~ @Equation3931 Fin6 refa659_inst.
Proof. unfold Equation3931. intro H. specialize (H F6_0 F6_1 F6_2). unfold magma_op, refa659_inst, refa659_op in H. discriminate H. Qed.

Lemma refa659_not4673 : ~ @Equation4673 Fin6 refa659_inst.
Proof. unfold Equation4673. intro H. specialize (H F6_0 F6_1 F6_4). unfold magma_op, refa659_inst, refa659_op in H. discriminate H. Qed.

(** ---- refa66 (Fin3) ---- *)

Definition refa66_op (x y : Fin3) : Fin3 :=
  match x, y with
  | F3_0, F3_0 => F3_0 | F3_0, F3_1 => F3_1 | F3_0, F3_2 => F3_2
  | F3_1, F3_0 => F3_1 | F3_1, F3_1 => F3_0 | F3_1, F3_2 => F3_0
  | F3_2, F3_0 => F3_1 | F3_2, F3_1 => F3_0 | F3_2, F3_2 => F3_1
  end.

#[local] Instance refa66_inst : Magma Fin3 := {| magma_op := refa66_op |}.

Lemma refa66_sat2808 : @Equation2808 Fin3 refa66_inst.
Proof. unfold Equation2808, magma_op, refa66_inst, refa66_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa66_sat3278 : @Equation3278 Fin3 refa66_inst.
Proof. unfold Equation3278, magma_op, refa66_inst, refa66_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa66_sat3306 : @Equation3306 Fin3 refa66_inst.
Proof. unfold Equation3306, magma_op, refa66_inst, refa66_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa66_sat3456 : @Equation3456 Fin3 refa66_inst.
Proof. unfold Equation3456, magma_op, refa66_inst, refa66_op. intros x. destruct x; reflexivity. Qed.

Lemma refa66_not417 : ~ @Equation417 Fin3 refa66_inst.
Proof. unfold Equation417. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa66_inst, refa66_op in H. discriminate H. Qed.

Lemma refa66_not427 : ~ @Equation427 Fin3 refa66_inst.
Proof. unfold Equation427. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa66_inst, refa66_op in H. discriminate H. Qed.

Lemma refa66_not440 : ~ @Equation440 Fin3 refa66_inst.
Proof. unfold Equation440. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa66_inst, refa66_op in H. discriminate H. Qed.

Lemma refa66_not477 : ~ @Equation477 Fin3 refa66_inst.
Proof. unfold Equation477. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa66_inst, refa66_op in H. discriminate H. Qed.

Lemma refa66_not504 : ~ @Equation504 Fin3 refa66_inst.
Proof. unfold Equation504. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa66_inst, refa66_op in H. discriminate H. Qed.

Lemma refa66_not511 : ~ @Equation511 Fin3 refa66_inst.
Proof. unfold Equation511. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa66_inst, refa66_op in H. discriminate H. Qed.

Lemma refa66_not614 : ~ @Equation614 Fin3 refa66_inst.
Proof. unfold Equation614. intro H. specialize (H F3_2). unfold magma_op, refa66_inst, refa66_op in H. discriminate H. Qed.

Lemma refa66_not825 : ~ @Equation825 Fin3 refa66_inst.
Proof. unfold Equation825. intro H. specialize (H F3_2 F3_0). unfold magma_op, refa66_inst, refa66_op in H. discriminate H. Qed.

Lemma refa66_not833 : ~ @Equation833 Fin3 refa66_inst.
Proof. unfold Equation833. intro H. specialize (H F3_2 F3_0). unfold magma_op, refa66_inst, refa66_op in H. discriminate H. Qed.

Lemma refa66_not835 : ~ @Equation835 Fin3 refa66_inst.
Proof. unfold Equation835. intro H. specialize (H F3_2 F3_0). unfold magma_op, refa66_inst, refa66_op in H. discriminate H. Qed.

Lemma refa66_not842 : ~ @Equation842 Fin3 refa66_inst.
Proof. unfold Equation842. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa66_inst, refa66_op in H. discriminate H. Qed.

Lemma refa66_not846 : ~ @Equation846 Fin3 refa66_inst.
Proof. unfold Equation846. intro H. specialize (H F3_2 F3_0). unfold magma_op, refa66_inst, refa66_op in H. discriminate H. Qed.

Lemma refa66_not870 : ~ @Equation870 Fin3 refa66_inst.
Proof. unfold Equation870. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa66_inst, refa66_op in H. discriminate H. Qed.

Lemma refa66_not872 : ~ @Equation872 Fin3 refa66_inst.
Proof. unfold Equation872. intro H. specialize (H F3_2 F3_0). unfold magma_op, refa66_inst, refa66_op in H. discriminate H. Qed.

Lemma refa66_not879 : ~ @Equation879 Fin3 refa66_inst.
Proof. unfold Equation879. intro H. specialize (H F3_2 F3_0). unfold magma_op, refa66_inst, refa66_op in H. discriminate H. Qed.

Lemma refa66_not883 : ~ @Equation883 Fin3 refa66_inst.
Proof. unfold Equation883. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa66_inst, refa66_op in H. discriminate H. Qed.

Lemma refa66_not906 : ~ @Equation906 Fin3 refa66_inst.
Proof. unfold Equation906. intro H. specialize (H F3_2 F3_0). unfold magma_op, refa66_inst, refa66_op in H. discriminate H. Qed.

Lemma refa66_not917 : ~ @Equation917 Fin3 refa66_inst.
Proof. unfold Equation917. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa66_inst, refa66_op in H. discriminate H. Qed.

Lemma refa66_not1023 : ~ @Equation1023 Fin3 refa66_inst.
Proof. unfold Equation1023. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa66_inst, refa66_op in H. discriminate H. Qed.

Lemma refa66_not1028 : ~ @Equation1028 Fin3 refa66_inst.
Proof. unfold Equation1028. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa66_inst, refa66_op in H. discriminate H. Qed.

Lemma refa66_not1038 : ~ @Equation1038 Fin3 refa66_inst.
Proof. unfold Equation1038. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa66_inst, refa66_op in H. discriminate H. Qed.

Lemma refa66_not1049 : ~ @Equation1049 Fin3 refa66_inst.
Proof. unfold Equation1049. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa66_inst, refa66_op in H. discriminate H. Qed.

Lemma refa66_not1082 : ~ @Equation1082 Fin3 refa66_inst.
Proof. unfold Equation1082. intro H. specialize (H F3_2 F3_0). unfold magma_op, refa66_inst, refa66_op in H. discriminate H. Qed.

Lemma refa66_not1109 : ~ @Equation1109 Fin3 refa66_inst.
Proof. unfold Equation1109. intro H. specialize (H F3_2 F3_0). unfold magma_op, refa66_inst, refa66_op in H. discriminate H. Qed.

Lemma refa66_not1223 : ~ @Equation1223 Fin3 refa66_inst.
Proof. unfold Equation1223. intro H. specialize (H F3_2). unfold magma_op, refa66_inst, refa66_op in H. discriminate H. Qed.

Lemma refa66_not1426 : ~ @Equation1426 Fin3 refa66_inst.
Proof. unfold Equation1426. intro H. specialize (H F3_2). unfold magma_op, refa66_inst, refa66_op in H. discriminate H. Qed.

Lemma refa66_not1629 : ~ @Equation1629 Fin3 refa66_inst.
Proof. unfold Equation1629. intro H. specialize (H F3_2). unfold magma_op, refa66_inst, refa66_op in H. discriminate H. Qed.

Lemma refa66_not1838 : ~ @Equation1838 Fin3 refa66_inst.
Proof. unfold Equation1838. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa66_inst, refa66_op in H. discriminate H. Qed.

Lemma refa66_not1857 : ~ @Equation1857 Fin3 refa66_inst.
Proof. unfold Equation1857. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa66_inst, refa66_op in H. discriminate H. Qed.

Lemma refa66_not1887 : ~ @Equation1887 Fin3 refa66_inst.
Proof. unfold Equation1887. intro H. specialize (H F3_2 F3_0). unfold magma_op, refa66_inst, refa66_op in H. discriminate H. Qed.

Lemma refa66_not1894 : ~ @Equation1894 Fin3 refa66_inst.
Proof. unfold Equation1894. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa66_inst, refa66_op in H. discriminate H. Qed.

Lemma refa66_not1925 : ~ @Equation1925 Fin3 refa66_inst.
Proof. unfold Equation1925. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa66_inst, refa66_op in H. discriminate H. Qed.

Lemma refa66_not2088 : ~ @Equation2088 Fin3 refa66_inst.
Proof. unfold Equation2088. intro H. specialize (H F3_2 F3_0). unfold magma_op, refa66_inst, refa66_op in H. discriminate H. Qed.

Lemma refa66_not2101 : ~ @Equation2101 Fin3 refa66_inst.
Proof. unfold Equation2101. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa66_inst, refa66_op in H. discriminate H. Qed.

Lemma refa66_not2124 : ~ @Equation2124 Fin3 refa66_inst.
Proof. unfold Equation2124. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa66_inst, refa66_op in H. discriminate H. Qed.

Lemma refa66_not2128 : ~ @Equation2128 Fin3 refa66_inst.
Proof. unfold Equation2128. intro H. specialize (H F3_2 F3_0). unfold magma_op, refa66_inst, refa66_op in H. discriminate H. Qed.

Lemma refa66_not2238 : ~ @Equation2238 Fin3 refa66_inst.
Proof. unfold Equation2238. intro H. specialize (H F3_2). unfold magma_op, refa66_inst, refa66_op in H. discriminate H. Qed.

Lemma refa66_not2441 : ~ @Equation2441 Fin3 refa66_inst.
Proof. unfold Equation2441. intro H. specialize (H F3_2). unfold magma_op, refa66_inst, refa66_op in H. discriminate H. Qed.

Lemma refa66_not2652 : ~ @Equation2652 Fin3 refa66_inst.
Proof. unfold Equation2652. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa66_inst, refa66_op in H. discriminate H. Qed.

Lemma refa66_not2662 : ~ @Equation2662 Fin3 refa66_inst.
Proof. unfold Equation2662. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa66_inst, refa66_op in H. discriminate H. Qed.

Lemma refa66_not2697 : ~ @Equation2697 Fin3 refa66_inst.
Proof. unfold Equation2697. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa66_inst, refa66_op in H. discriminate H. Qed.

Lemma refa66_not2744 : ~ @Equation2744 Fin3 refa66_inst.
Proof. unfold Equation2744. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa66_inst, refa66_op in H. discriminate H. Qed.

Lemma refa66_not2847 : ~ @Equation2847 Fin3 refa66_inst.
Proof. unfold Equation2847. intro H. specialize (H F3_2). unfold magma_op, refa66_inst, refa66_op in H. discriminate H. Qed.

Lemma refa66_not3050 : ~ @Equation3050 Fin3 refa66_inst.
Proof. unfold Equation3050. intro H. specialize (H F3_2). unfold magma_op, refa66_inst, refa66_op in H. discriminate H. Qed.

Lemma refa66_not3256 : ~ @Equation3256 Fin3 refa66_inst.
Proof. unfold Equation3256. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa66_inst, refa66_op in H. discriminate H. Qed.

Lemma refa66_not3259 : ~ @Equation3259 Fin3 refa66_inst.
Proof. unfold Equation3259. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa66_inst, refa66_op in H. discriminate H. Qed.

Lemma refa66_not3261 : ~ @Equation3261 Fin3 refa66_inst.
Proof. unfold Equation3261. intro H. specialize (H F3_2 F3_1). unfold magma_op, refa66_inst, refa66_op in H. discriminate H. Qed.

Lemma refa66_not3271 : ~ @Equation3271 Fin3 refa66_inst.
Proof. unfold Equation3271. intro H. specialize (H F3_2 F3_1). unfold magma_op, refa66_inst, refa66_op in H. discriminate H. Qed.

Lemma refa66_not3308 : ~ @Equation3308 Fin3 refa66_inst.
Proof. unfold Equation3308. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa66_inst, refa66_op in H. discriminate H. Qed.

Lemma refa66_not3315 : ~ @Equation3315 Fin3 refa66_inst.
Proof. unfold Equation3315. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa66_inst, refa66_op in H. discriminate H. Qed.

Lemma refa66_not3342 : ~ @Equation3342 Fin3 refa66_inst.
Proof. unfold Equation3342. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa66_inst, refa66_op in H. discriminate H. Qed.

Lemma refa66_not3462 : ~ @Equation3462 Fin3 refa66_inst.
Proof. unfold Equation3462. intro H. specialize (H F3_2 F3_0). unfold magma_op, refa66_inst, refa66_op in H. discriminate H. Qed.

Lemma refa66_not3464 : ~ @Equation3464 Fin3 refa66_inst.
Proof. unfold Equation3464. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa66_inst, refa66_op in H. discriminate H. Qed.

Lemma refa66_not3509 : ~ @Equation3509 Fin3 refa66_inst.
Proof. unfold Equation3509. intro H. specialize (H F3_2 F3_0). unfold magma_op, refa66_inst, refa66_op in H. discriminate H. Qed.

Lemma refa66_not3511 : ~ @Equation3511 Fin3 refa66_inst.
Proof. unfold Equation3511. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa66_inst, refa66_op in H. discriminate H. Qed.

Lemma refa66_not3518 : ~ @Equation3518 Fin3 refa66_inst.
Proof. unfold Equation3518. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa66_inst, refa66_op in H. discriminate H. Qed.

Lemma refa66_not3659 : ~ @Equation3659 Fin3 refa66_inst.
Proof. unfold Equation3659. intro H. specialize (H F3_2). unfold magma_op, refa66_inst, refa66_op in H. discriminate H. Qed.

Lemma refa66_not3862 : ~ @Equation3862 Fin3 refa66_inst.
Proof. unfold Equation3862. intro H. specialize (H F3_2). unfold magma_op, refa66_inst, refa66_op in H. discriminate H. Qed.

Lemma refa66_not4065 : ~ @Equation4065 Fin3 refa66_inst.
Proof. unfold Equation4065. intro H. specialize (H F3_2). unfold magma_op, refa66_inst, refa66_op in H. discriminate H. Qed.

Lemma refa66_not4283 : ~ @Equation4283 Fin3 refa66_inst.
Proof. unfold Equation4283. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa66_inst, refa66_op in H. discriminate H. Qed.

Lemma refa66_not4320 : ~ @Equation4320 Fin3 refa66_inst.
Proof. unfold Equation4320. intro H. specialize (H F3_2 F3_1). unfold magma_op, refa66_inst, refa66_op in H. discriminate H. Qed.

Lemma refa66_not4585 : ~ @Equation4585 Fin3 refa66_inst.
Proof. unfold Equation4585. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa66_inst, refa66_op in H. discriminate H. Qed.

Lemma refa66_not4590 : ~ @Equation4590 Fin3 refa66_inst.
Proof. unfold Equation4590. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa66_inst, refa66_op in H. discriminate H. Qed.

(** ---- refa660 (Fin5) ---- *)

Definition refa660_op (x y : Fin5) : Fin5 :=
  match x, y with
  | F5_0, F5_0 => F5_4 | F5_0, F5_1 => F5_3 | F5_0, F5_2 => F5_0 | F5_0, F5_3 => F5_1 | F5_0, F5_4 => F5_0
  | F5_1, F5_0 => F5_2 | F5_1, F5_1 => F5_4 | F5_1, F5_2 => F5_0 | F5_1, F5_3 => F5_1 | F5_1, F5_4 => F5_1
  | F5_2, F5_0 => F5_2 | F5_2, F5_1 => F5_3 | F5_2, F5_2 => F5_4 | F5_2, F5_3 => F5_1 | F5_2, F5_4 => F5_2
  | F5_3, F5_0 => F5_2 | F5_3, F5_1 => F5_3 | F5_3, F5_2 => F5_0 | F5_3, F5_3 => F5_4 | F5_3, F5_4 => F5_3
  | F5_4, F5_0 => F5_4 | F5_4, F5_1 => F5_4 | F5_4, F5_2 => F5_4 | F5_4, F5_3 => F5_4 | F5_4, F5_4 => F5_4
  end.

#[local] Instance refa660_inst : Magma Fin5 := {| magma_op := refa660_op |}.

Lemma refa660_sat1043 : @Equation1043 Fin5 refa660_inst.
Proof. unfold Equation1043, magma_op, refa660_inst, refa660_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa660_not105 : ~ @Equation105 Fin5 refa660_inst.
Proof. unfold Equation105. intro H. specialize (H F5_0 F5_1). unfold magma_op, refa660_inst, refa660_op in H. discriminate H. Qed.

Lemma refa660_not833 : ~ @Equation833 Fin5 refa660_inst.
Proof. unfold Equation833. intro H. specialize (H F5_0 F5_1). unfold magma_op, refa660_inst, refa660_op in H. discriminate H. Qed.

Lemma refa660_not1046 : ~ @Equation1046 Fin5 refa660_inst.
Proof. unfold Equation1046. intro H. specialize (H F5_0 F5_1). unfold magma_op, refa660_inst, refa660_op in H. discriminate H. Qed.

Lemma refa660_not1229 : ~ @Equation1229 Fin5 refa660_inst.
Proof. unfold Equation1229. intro H. specialize (H F5_0 F5_1). unfold magma_op, refa660_inst, refa660_op in H. discriminate H. Qed.

Lemma refa660_not1239 : ~ @Equation1239 Fin5 refa660_inst.
Proof. unfold Equation1239. intro H. specialize (H F5_0 F5_1). unfold magma_op, refa660_inst, refa660_op in H. discriminate H. Qed.

Lemma refa660_not1242 : ~ @Equation1242 Fin5 refa660_inst.
Proof. unfold Equation1242. intro H. specialize (H F5_0 F5_1). unfold magma_op, refa660_inst, refa660_op in H. discriminate H. Qed.

Lemma refa660_not3318 : ~ @Equation3318 Fin5 refa660_inst.
Proof. unfold Equation3318. intro H. specialize (H F5_0 F5_1). unfold magma_op, refa660_inst, refa660_op in H. discriminate H. Qed.

Lemma refa660_not3724 : ~ @Equation3724 Fin5 refa660_inst.
Proof. unfold Equation3724. intro H. specialize (H F5_0 F5_1). unfold magma_op, refa660_inst, refa660_op in H. discriminate H. Qed.

Lemma refa660_not3864 : ~ @Equation3864 Fin5 refa660_inst.
Proof. unfold Equation3864. intro H. specialize (H F5_0 F5_1). unfold magma_op, refa660_inst, refa660_op in H. discriminate H. Qed.

(** ---- refa661 (Fin5) ---- *)

Definition refa661_op (x y : Fin5) : Fin5 :=
  match x, y with
  | F5_0, F5_0 => F5_1 | F5_0, F5_1 => F5_2 | F5_0, F5_2 => F5_3 | F5_0, F5_3 => F5_0 | F5_0, F5_4 => F5_4
  | F5_1, F5_0 => F5_4 | F5_1, F5_1 => F5_0 | F5_1, F5_2 => F5_2 | F5_1, F5_3 => F5_1 | F5_1, F5_4 => F5_3
  | F5_2, F5_0 => F5_3 | F5_2, F5_1 => F5_1 | F5_2, F5_2 => F5_4 | F5_2, F5_3 => F5_2 | F5_2, F5_4 => F5_0
  | F5_3, F5_0 => F5_2 | F5_3, F5_1 => F5_4 | F5_3, F5_2 => F5_0 | F5_3, F5_3 => F5_3 | F5_3, F5_4 => F5_1
  | F5_4, F5_0 => F5_0 | F5_4, F5_1 => F5_3 | F5_4, F5_2 => F5_1 | F5_4, F5_3 => F5_4 | F5_4, F5_4 => F5_2
  end.

#[local] Instance refa661_inst : Magma Fin5 := {| magma_op := refa661_op |}.

Lemma refa661_sat1061 : @Equation1061 Fin5 refa661_inst.
Proof. unfold Equation1061, magma_op, refa661_inst, refa661_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa661_not817 : ~ @Equation817 Fin5 refa661_inst.
Proof. unfold Equation817. intro H. specialize (H F5_0). unfold magma_op, refa661_inst, refa661_op in H. discriminate H. Qed.

Lemma refa661_not1832 : ~ @Equation1832 Fin5 refa661_inst.
Proof. unfold Equation1832. intro H. specialize (H F5_0). unfold magma_op, refa661_inst, refa661_op in H. discriminate H. Qed.

Lemma refa661_not3456 : ~ @Equation3456 Fin5 refa661_inst.
Proof. unfold Equation3456. intro H. specialize (H F5_0). unfold magma_op, refa661_inst, refa661_op in H. discriminate H. Qed.

Lemma refa661_not4065 : ~ @Equation4065 Fin5 refa661_inst.
Proof. unfold Equation4065. intro H. specialize (H F5_0). unfold magma_op, refa661_inst, refa661_op in H. discriminate H. Qed.

Lemma refa661_not4598 : ~ @Equation4598 Fin5 refa661_inst.
Proof. unfold Equation4598. intro H. specialize (H F5_0 F5_1). unfold magma_op, refa661_inst, refa661_op in H. discriminate H. Qed.

(** ---- refa662 (Fin8) ---- *)

Definition refa662_op (x y : Fin8) : Fin8 :=
  match x, y with
  | F8_0, F8_0 => F8_5 | F8_0, F8_1 => F8_3 | F8_0, F8_2 => F8_4 | F8_0, F8_3 => F8_6 | F8_0, F8_4 => F8_0 | F8_0, F8_5 => F8_7 | F8_0, F8_6 => F8_2 | F8_0, F8_7 => F8_1
  | F8_1, F8_0 => F8_2 | F8_1, F8_1 => F8_5 | F8_1, F8_2 => F8_6 | F8_1, F8_3 => F8_7 | F8_1, F8_4 => F8_3 | F8_1, F8_5 => F8_4 | F8_1, F8_6 => F8_1 | F8_1, F8_7 => F8_0
  | F8_2, F8_0 => F8_6 | F8_2, F8_1 => F8_0 | F8_2, F8_2 => F8_5 | F8_2, F8_3 => F8_1 | F8_2, F8_4 => F8_7 | F8_2, F8_5 => F8_2 | F8_2, F8_6 => F8_4 | F8_2, F8_7 => F8_3
  | F8_3, F8_0 => F8_3 | F8_3, F8_1 => F8_2 | F8_3, F8_2 => F8_0 | F8_3, F8_3 => F8_5 | F8_3, F8_4 => F8_1 | F8_3, F8_5 => F8_6 | F8_3, F8_6 => F8_7 | F8_3, F8_7 => F8_4
  | F8_4, F8_0 => F8_7 | F8_4, F8_1 => F8_6 | F8_4, F8_2 => F8_3 | F8_4, F8_3 => F8_4 | F8_4, F8_4 => F8_5 | F8_4, F8_5 => F8_1 | F8_4, F8_6 => F8_0 | F8_4, F8_7 => F8_2
  | F8_5, F8_0 => F8_0 | F8_5, F8_1 => F8_1 | F8_5, F8_2 => F8_2 | F8_5, F8_3 => F8_3 | F8_5, F8_4 => F8_4 | F8_5, F8_5 => F8_5 | F8_5, F8_6 => F8_6 | F8_5, F8_7 => F8_7
  | F8_6, F8_0 => F8_1 | F8_6, F8_1 => F8_4 | F8_6, F8_2 => F8_7 | F8_6, F8_3 => F8_0 | F8_6, F8_4 => F8_2 | F8_6, F8_5 => F8_3 | F8_6, F8_6 => F8_5 | F8_6, F8_7 => F8_6
  | F8_7, F8_0 => F8_4 | F8_7, F8_1 => F8_7 | F8_7, F8_2 => F8_1 | F8_7, F8_3 => F8_2 | F8_7, F8_4 => F8_6 | F8_7, F8_5 => F8_0 | F8_7, F8_6 => F8_3 | F8_7, F8_7 => F8_5
  end.

#[local] Instance refa662_inst : Magma Fin8 := {| magma_op := refa662_op |}.

Lemma refa662_sat1101 : @Equation1101 Fin8 refa662_inst.
Proof. unfold Equation1101, magma_op, refa662_inst, refa662_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa662_not1684 : ~ @Equation1684 Fin8 refa662_inst.
Proof. unfold Equation1684. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa662_inst, refa662_op in H. discriminate H. Qed.

Lemma refa662_not3066 : ~ @Equation3066 Fin8 refa662_inst.
Proof. unfold Equation3066. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa662_inst, refa662_op in H. discriminate H. Qed.

(** ---- refa663 (Fin7) ---- *)

Definition refa663_op (x y : Fin7) : Fin7 :=
  match x, y with
  | F7_0, F7_0 => F7_2 | F7_0, F7_1 => F7_1 | F7_0, F7_2 => F7_0 | F7_0, F7_3 => F7_4 | F7_0, F7_4 => F7_5 | F7_0, F7_5 => F7_6 | F7_0, F7_6 => F7_3
  | F7_1, F7_0 => F7_2 | F7_1, F7_1 => F7_1 | F7_1, F7_2 => F7_0 | F7_1, F7_3 => F7_4 | F7_1, F7_4 => F7_5 | F7_1, F7_5 => F7_6 | F7_1, F7_6 => F7_3
  | F7_2, F7_0 => F7_2 | F7_2, F7_1 => F7_3 | F7_2, F7_2 => F7_0 | F7_2, F7_3 => F7_6 | F7_2, F7_4 => F7_1 | F7_2, F7_5 => F7_5 | F7_2, F7_6 => F7_4
  | F7_3, F7_0 => F7_2 | F7_3, F7_1 => F7_5 | F7_3, F7_2 => F7_0 | F7_3, F7_3 => F7_3 | F7_3, F7_4 => F7_6 | F7_3, F7_5 => F7_4 | F7_3, F7_6 => F7_1
  | F7_4, F7_0 => F7_2 | F7_4, F7_1 => F7_6 | F7_4, F7_2 => F7_0 | F7_4, F7_3 => F7_1 | F7_4, F7_4 => F7_4 | F7_4, F7_5 => F7_3 | F7_4, F7_6 => F7_5
  | F7_5, F7_0 => F7_2 | F7_5, F7_1 => F7_3 | F7_5, F7_2 => F7_0 | F7_5, F7_3 => F7_6 | F7_5, F7_4 => F7_1 | F7_5, F7_5 => F7_5 | F7_5, F7_6 => F7_4
  | F7_6, F7_0 => F7_2 | F7_6, F7_1 => F7_4 | F7_6, F7_2 => F7_0 | F7_6, F7_3 => F7_5 | F7_6, F7_4 => F7_3 | F7_6, F7_5 => F7_1 | F7_6, F7_6 => F7_6
  end.

#[local] Instance refa663_inst : Magma Fin7 := {| magma_op := refa663_op |}.

Lemma refa663_sat1119 : @Equation1119 Fin7 refa663_inst.
Proof. unfold Equation1119, magma_op, refa663_inst, refa663_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa663_not466 : ~ @Equation466 Fin7 refa663_inst.
Proof. unfold Equation466. intro H. specialize (H F7_1 F7_2). unfold magma_op, refa663_inst, refa663_op in H. discriminate H. Qed.

Lemma refa663_not1038 : ~ @Equation1038 Fin7 refa663_inst.
Proof. unfold Equation1038. intro H. specialize (H F7_1 F7_2). unfold magma_op, refa663_inst, refa663_op in H. discriminate H. Qed.

Lemma refa663_not1075 : ~ @Equation1075 Fin7 refa663_inst.
Proof. unfold Equation1075. intro H. specialize (H F7_1 F7_2). unfold magma_op, refa663_inst, refa663_op in H. discriminate H. Qed.

Lemma refa663_not1241 : ~ @Equation1241 Fin7 refa663_inst.
Proof. unfold Equation1241. intro H. specialize (H F7_1 F7_0). unfold magma_op, refa663_inst, refa663_op in H. discriminate H. Qed.

Lemma refa663_not1684 : ~ @Equation1684 Fin7 refa663_inst.
Proof. unfold Equation1684. intro H. specialize (H F7_1 F7_0). unfold magma_op, refa663_inst, refa663_op in H. discriminate H. Qed.

Lemma refa663_not1894 : ~ @Equation1894 Fin7 refa663_inst.
Proof. unfold Equation1894. intro H. specialize (H F7_1 F7_2). unfold magma_op, refa663_inst, refa663_op in H. discriminate H. Qed.

Lemma refa663_not2097 : ~ @Equation2097 Fin7 refa663_inst.
Proof. unfold Equation2097. intro H. specialize (H F7_1 F7_0). unfold magma_op, refa663_inst, refa663_op in H. discriminate H. Qed.

Lemma refa663_not3880 : ~ @Equation3880 Fin7 refa663_inst.
Proof. unfold Equation3880. intro H. specialize (H F7_1 F7_2). unfold magma_op, refa663_inst, refa663_op in H. discriminate H. Qed.

Lemma refa663_not3955 : ~ @Equation3955 Fin7 refa663_inst.
Proof. unfold Equation3955. intro H. specialize (H F7_0 F7_3). unfold magma_op, refa663_inst, refa663_op in H. discriminate H. Qed.

Lemma refa663_not4083 : ~ @Equation4083 Fin7 refa663_inst.
Proof. unfold Equation4083. intro H. specialize (H F7_1 F7_0). unfold magma_op, refa663_inst, refa663_op in H. discriminate H. Qed.

Lemma refa663_not4118 : ~ @Equation4118 Fin7 refa663_inst.
Proof. unfold Equation4118. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa663_inst, refa663_op in H. discriminate H. Qed.

Lemma refa663_not4158 : ~ @Equation4158 Fin7 refa663_inst.
Proof. unfold Equation4158. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa663_inst, refa663_op in H. discriminate H. Qed.

(** ---- refa664 (Fin5) ---- *)

Definition refa664_op (x y : Fin5) : Fin5 :=
  match x, y with
  | F5_0, F5_0 => F5_0 | F5_0, F5_1 => F5_2 | F5_0, F5_2 => F5_0 | F5_0, F5_3 => F5_4 | F5_0, F5_4 => F5_0
  | F5_1, F5_0 => F5_1 | F5_1, F5_1 => F5_1 | F5_1, F5_2 => F5_1 | F5_1, F5_3 => F5_1 | F5_1, F5_4 => F5_1
  | F5_2, F5_0 => F5_3 | F5_2, F5_1 => F5_4 | F5_2, F5_2 => F5_2 | F5_2, F5_3 => F5_2 | F5_2, F5_4 => F5_2
  | F5_3, F5_0 => F5_4 | F5_3, F5_1 => F5_3 | F5_3, F5_2 => F5_4 | F5_3, F5_3 => F5_3 | F5_3, F5_4 => F5_3
  | F5_4, F5_0 => F5_4 | F5_4, F5_1 => F5_4 | F5_4, F5_2 => F5_4 | F5_4, F5_3 => F5_4 | F5_4, F5_4 => F5_4
  end.

#[local] Instance refa664_inst : Magma Fin5 := {| magma_op := refa664_op |}.

Lemma refa664_sat1233 : @Equation1233 Fin5 refa664_inst.
Proof. unfold Equation1233, magma_op, refa664_inst, refa664_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa664_not822 : ~ @Equation822 Fin5 refa664_inst.
Proof. unfold Equation822. intro H. specialize (H F5_0 F5_1). unfold magma_op, refa664_inst, refa664_op in H. discriminate H. Qed.

Lemma refa664_not1025 : ~ @Equation1025 Fin5 refa664_inst.
Proof. unfold Equation1025. intro H. specialize (H F5_0 F5_1). unfold magma_op, refa664_inst, refa664_op in H. discriminate H. Qed.

Lemma refa664_not1028 : ~ @Equation1028 Fin5 refa664_inst.
Proof. unfold Equation1028. intro H. specialize (H F5_0 F5_1). unfold magma_op, refa664_inst, refa664_op in H. discriminate H. Qed.

Lemma refa664_not1225 : ~ @Equation1225 Fin5 refa664_inst.
Proof. unfold Equation1225. intro H. specialize (H F5_0 F5_1). unfold magma_op, refa664_inst, refa664_op in H. discriminate H. Qed.

Lemma refa664_not1229 : ~ @Equation1229 Fin5 refa664_inst.
Proof. unfold Equation1229. intro H. specialize (H F5_0 F5_1). unfold magma_op, refa664_inst, refa664_op in H. discriminate H. Qed.

Lemma refa664_not1631 : ~ @Equation1631 Fin5 refa664_inst.
Proof. unfold Equation1631. intro H. specialize (H F5_0 F5_1). unfold magma_op, refa664_inst, refa664_op in H. discriminate H. Qed.

Lemma refa664_not2446 : ~ @Equation2446 Fin5 refa664_inst.
Proof. unfold Equation2446. intro H. specialize (H F5_0 F5_1). unfold magma_op, refa664_inst, refa664_op in H. discriminate H. Qed.

Lemma refa664_not3315 : ~ @Equation3315 Fin5 refa664_inst.
Proof. unfold Equation3315. intro H. specialize (H F5_0 F5_2). unfold magma_op, refa664_inst, refa664_op in H. discriminate H. Qed.

Lemma refa664_not3316 : ~ @Equation3316 Fin5 refa664_inst.
Proof. unfold Equation3316. intro H. specialize (H F5_0 F5_2). unfold magma_op, refa664_inst, refa664_op in H. discriminate H. Qed.

Lemma refa664_not3458 : ~ @Equation3458 Fin5 refa664_inst.
Proof. unfold Equation3458. intro H. specialize (H F5_0 F5_1). unfold magma_op, refa664_inst, refa664_op in H. discriminate H. Qed.

Lemma refa664_not3518 : ~ @Equation3518 Fin5 refa664_inst.
Proof. unfold Equation3518. intro H. specialize (H F5_0 F5_3). unfold magma_op, refa664_inst, refa664_op in H. discriminate H. Qed.

Lemma refa664_not3519 : ~ @Equation3519 Fin5 refa664_inst.
Proof. unfold Equation3519. intro H. specialize (H F5_0 F5_3). unfold magma_op, refa664_inst, refa664_op in H. discriminate H. Qed.

Lemma refa664_not3521 : ~ @Equation3521 Fin5 refa664_inst.
Proof. unfold Equation3521. intro H. specialize (H F5_0 F5_2). unfold magma_op, refa664_inst, refa664_op in H. discriminate H. Qed.

Lemma refa664_not3714 : ~ @Equation3714 Fin5 refa664_inst.
Proof. unfold Equation3714. intro H. specialize (H F5_0 F5_2). unfold magma_op, refa664_inst, refa664_op in H. discriminate H. Qed.

Lemma refa664_not3721 : ~ @Equation3721 Fin5 refa664_inst.
Proof. unfold Equation3721. intro H. specialize (H F5_0 F5_1). unfold magma_op, refa664_inst, refa664_op in H. discriminate H. Qed.

Lemma refa664_not3724 : ~ @Equation3724 Fin5 refa664_inst.
Proof. unfold Equation3724. intro H. specialize (H F5_0 F5_1). unfold magma_op, refa664_inst, refa664_op in H. discriminate H. Qed.

Lemma refa664_not3725 : ~ @Equation3725 Fin5 refa664_inst.
Proof. unfold Equation3725. intro H. specialize (H F5_0 F5_1). unfold magma_op, refa664_inst, refa664_op in H. discriminate H. Qed.

Lemma refa664_not3924 : ~ @Equation3924 Fin5 refa664_inst.
Proof. unfold Equation3924. intro H. specialize (H F5_0 F5_1). unfold magma_op, refa664_inst, refa664_op in H. discriminate H. Qed.

Lemma refa664_not3925 : ~ @Equation3925 Fin5 refa664_inst.
Proof. unfold Equation3925. intro H. specialize (H F5_0 F5_1). unfold magma_op, refa664_inst, refa664_op in H. discriminate H. Qed.

Lemma refa664_not3927 : ~ @Equation3927 Fin5 refa664_inst.
Proof. unfold Equation3927. intro H. specialize (H F5_0 F5_1). unfold magma_op, refa664_inst, refa664_op in H. discriminate H. Qed.

Lemma refa664_not3928 : ~ @Equation3928 Fin5 refa664_inst.
Proof. unfold Equation3928. intro H. specialize (H F5_0 F5_1). unfold magma_op, refa664_inst, refa664_op in H. discriminate H. Qed.

Lemma refa664_not4120 : ~ @Equation4120 Fin5 refa664_inst.
Proof. unfold Equation4120. intro H. specialize (H F5_0 F5_1). unfold magma_op, refa664_inst, refa664_op in H. discriminate H. Qed.

Lemma refa664_not4121 : ~ @Equation4121 Fin5 refa664_inst.
Proof. unfold Equation4121. intro H. specialize (H F5_0 F5_1). unfold magma_op, refa664_inst, refa664_op in H. discriminate H. Qed.

Lemma refa664_not4127 : ~ @Equation4127 Fin5 refa664_inst.
Proof. unfold Equation4127. intro H. specialize (H F5_0 F5_1). unfold magma_op, refa664_inst, refa664_op in H. discriminate H. Qed.

Lemma refa664_not4128 : ~ @Equation4128 Fin5 refa664_inst.
Proof. unfold Equation4128. intro H. specialize (H F5_0 F5_1). unfold magma_op, refa664_inst, refa664_op in H. discriminate H. Qed.

Lemma refa664_not4130 : ~ @Equation4130 Fin5 refa664_inst.
Proof. unfold Equation4130. intro H. specialize (H F5_0 F5_1). unfold magma_op, refa664_inst, refa664_op in H. discriminate H. Qed.

Lemma refa664_not4131 : ~ @Equation4131 Fin5 refa664_inst.
Proof. unfold Equation4131. intro H. specialize (H F5_0 F5_1). unfold magma_op, refa664_inst, refa664_op in H. discriminate H. Qed.

Lemma refa664_not4314 : ~ @Equation4314 Fin5 refa664_inst.
Proof. unfold Equation4314. intro H. specialize (H F5_0 F5_2). unfold magma_op, refa664_inst, refa664_op in H. discriminate H. Qed.

Lemma refa664_not4433 : ~ @Equation4433 Fin5 refa664_inst.
Proof. unfold Equation4433. intro H. specialize (H F5_0 F5_2). unfold magma_op, refa664_inst, refa664_op in H. discriminate H. Qed.

Lemma refa664_not4435 : ~ @Equation4435 Fin5 refa664_inst.
Proof. unfold Equation4435. intro H. specialize (H F5_0 F5_1). unfold magma_op, refa664_inst, refa664_op in H. discriminate H. Qed.

Lemma refa664_not4436 : ~ @Equation4436 Fin5 refa664_inst.
Proof. unfold Equation4436. intro H. specialize (H F5_0 F5_1). unfold magma_op, refa664_inst, refa664_op in H. discriminate H. Qed.

Lemma refa664_not4472 : ~ @Equation4472 Fin5 refa664_inst.
Proof. unfold Equation4472. intro H. specialize (H F5_0 F5_1). unfold magma_op, refa664_inst, refa664_op in H. discriminate H. Qed.

Lemma refa664_not4473 : ~ @Equation4473 Fin5 refa664_inst.
Proof. unfold Equation4473. intro H. specialize (H F5_0 F5_1). unfold magma_op, refa664_inst, refa664_op in H. discriminate H. Qed.

Lemma refa664_not4598 : ~ @Equation4598 Fin5 refa664_inst.
Proof. unfold Equation4598. intro H. specialize (H F5_0 F5_1). unfold magma_op, refa664_inst, refa664_op in H. discriminate H. Qed.

Lemma refa664_not4599 : ~ @Equation4599 Fin5 refa664_inst.
Proof. unfold Equation4599. intro H. specialize (H F5_0 F5_1). unfold magma_op, refa664_inst, refa664_op in H. discriminate H. Qed.

Lemma refa664_not4629 : ~ @Equation4629 Fin5 refa664_inst.
Proof. unfold Equation4629. intro H. specialize (H F5_0 F5_1). unfold magma_op, refa664_inst, refa664_op in H. discriminate H. Qed.

(** ---- refa665 (Fin6) ---- *)

Definition refa665_op (x y : Fin6) : Fin6 :=
  match x, y with
  | F6_0, F6_0 => F6_0 | F6_0, F6_1 => F6_0 | F6_0, F6_2 => F6_3 | F6_0, F6_3 => F6_0 | F6_0, F6_4 => F6_5 | F6_0, F6_5 => F6_0
  | F6_1, F6_0 => F6_2 | F6_1, F6_1 => F6_1 | F6_1, F6_2 => F6_1 | F6_1, F6_3 => F6_1 | F6_1, F6_4 => F6_1 | F6_1, F6_5 => F6_1
  | F6_2, F6_0 => F6_3 | F6_2, F6_1 => F6_4 | F6_2, F6_2 => F6_2 | F6_2, F6_3 => F6_2 | F6_2, F6_4 => F6_2 | F6_2, F6_5 => F6_2
  | F6_3, F6_0 => F6_4 | F6_3, F6_1 => F6_4 | F6_3, F6_2 => F6_5 | F6_3, F6_3 => F6_3 | F6_3, F6_4 => F6_3 | F6_3, F6_5 => F6_3
  | F6_4, F6_0 => F6_4 | F6_4, F6_1 => F6_4 | F6_4, F6_2 => F6_4 | F6_4, F6_3 => F6_4 | F6_4, F6_4 => F6_4 | F6_4, F6_5 => F6_4
  | F6_5, F6_0 => F6_3 | F6_5, F6_1 => F6_3 | F6_5, F6_2 => F6_3 | F6_5, F6_3 => F6_5 | F6_5, F6_4 => F6_5 | F6_5, F6_5 => F6_5
  end.

#[local] Instance refa665_inst : Magma Fin6 := {| magma_op := refa665_op |}.

Lemma refa665_sat1233 : @Equation1233 Fin6 refa665_inst.
Proof. unfold Equation1233, magma_op, refa665_inst, refa665_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa665_not1026 : ~ @Equation1026 Fin6 refa665_inst.
Proof. unfold Equation1026. intro H. specialize (H F6_0 F6_1). unfold magma_op, refa665_inst, refa665_op in H. discriminate H. Qed.

Lemma refa665_not1228 : ~ @Equation1228 Fin6 refa665_inst.
Proof. unfold Equation1228. intro H. specialize (H F6_0 F6_2). unfold magma_op, refa665_inst, refa665_op in H. discriminate H. Qed.

(** ---- refa666 (Fin5) ---- *)

Definition refa666_op (x y : Fin5) : Fin5 :=
  match x, y with
  | F5_0, F5_0 => F5_0 | F5_0, F5_1 => F5_2 | F5_0, F5_2 => F5_0 | F5_0, F5_3 => F5_0 | F5_0, F5_4 => F5_3
  | F5_1, F5_0 => F5_3 | F5_1, F5_1 => F5_1 | F5_1, F5_2 => F5_3 | F5_1, F5_3 => F5_1 | F5_1, F5_4 => F5_3
  | F5_2, F5_0 => F5_2 | F5_2, F5_1 => F5_0 | F5_2, F5_2 => F5_2 | F5_2, F5_3 => F5_4 | F5_2, F5_4 => F5_2
  | F5_3, F5_0 => F5_3 | F5_3, F5_1 => F5_3 | F5_3, F5_2 => F5_3 | F5_3, F5_3 => F5_3 | F5_3, F5_4 => F5_3
  | F5_4, F5_0 => F5_4 | F5_4, F5_1 => F5_0 | F5_4, F5_2 => F5_4 | F5_4, F5_3 => F5_2 | F5_4, F5_4 => F5_4
  end.

#[local] Instance refa666_inst : Magma Fin5 := {| magma_op := refa666_op |}.

Lemma refa666_sat1233 : @Equation1233 Fin5 refa666_inst.
Proof. unfold Equation1233, magma_op, refa666_inst, refa666_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa666_not825 : ~ @Equation825 Fin5 refa666_inst.
Proof. unfold Equation825. intro H. specialize (H F5_0 F5_1). unfold magma_op, refa666_inst, refa666_op in H. discriminate H. Qed.

Lemma refa666_not829 : ~ @Equation829 Fin5 refa666_inst.
Proof. unfold Equation829. intro H. specialize (H F5_0 F5_1 F5_3). unfold magma_op, refa666_inst, refa666_op in H. discriminate H. Qed.

(** ---- refa667 (Fin6) ---- *)

Definition refa667_op (x y : Fin6) : Fin6 :=
  match x, y with
  | F6_0, F6_0 => F6_0 | F6_0, F6_1 => F6_5 | F6_0, F6_2 => F6_3 | F6_0, F6_3 => F6_0 | F6_0, F6_4 => F6_5 | F6_0, F6_5 => F6_0
  | F6_1, F6_0 => F6_2 | F6_1, F6_1 => F6_1 | F6_1, F6_2 => F6_1 | F6_1, F6_3 => F6_1 | F6_1, F6_4 => F6_1 | F6_1, F6_5 => F6_2
  | F6_2, F6_0 => F6_3 | F6_2, F6_1 => F6_4 | F6_2, F6_2 => F6_2 | F6_2, F6_3 => F6_2 | F6_2, F6_4 => F6_2 | F6_2, F6_5 => F6_3
  | F6_3, F6_0 => F6_3 | F6_3, F6_1 => F6_4 | F6_3, F6_2 => F6_3 | F6_3, F6_3 => F6_3 | F6_3, F6_4 => F6_3 | F6_3, F6_5 => F6_3
  | F6_4, F6_0 => F6_4 | F6_4, F6_1 => F6_3 | F6_4, F6_2 => F6_3 | F6_4, F6_3 => F6_4 | F6_4, F6_4 => F6_4 | F6_4, F6_5 => F6_3
  | F6_5, F6_0 => F6_5 | F6_5, F6_1 => F6_0 | F6_5, F6_2 => F6_0 | F6_5, F6_3 => F6_5 | F6_5, F6_4 => F6_5 | F6_5, F6_5 => F6_5
  end.

#[local] Instance refa667_inst : Magma Fin6 := {| magma_op := refa667_op |}.

Lemma refa667_sat1235 : @Equation1235 Fin6 refa667_inst.
Proof. unfold Equation1235, magma_op, refa667_inst, refa667_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa667_not1026 : ~ @Equation1026 Fin6 refa667_inst.
Proof. unfold Equation1026. intro H. specialize (H F6_0 F6_1). unfold magma_op, refa667_inst, refa667_op in H. discriminate H. Qed.

Lemma refa667_not1227 : ~ @Equation1227 Fin6 refa667_inst.
Proof. unfold Equation1227. intro H. specialize (H F6_0 F6_2 F6_1). unfold magma_op, refa667_inst, refa667_op in H. discriminate H. Qed.

Lemma refa667_not1230 : ~ @Equation1230 Fin6 refa667_inst.
Proof. unfold Equation1230. intro H. specialize (H F6_0 F6_2 F6_1). unfold magma_op, refa667_inst, refa667_op in H. discriminate H. Qed.

Lemma refa667_not1233 : ~ @Equation1233 Fin6 refa667_inst.
Proof. unfold Equation1233. intro H. specialize (H F6_0 F6_2 F6_1). unfold magma_op, refa667_inst, refa667_op in H. discriminate H. Qed.

Lemma refa667_not1234 : ~ @Equation1234 Fin6 refa667_inst.
Proof. unfold Equation1234. intro H. specialize (H F6_0 F6_2 F6_1). unfold magma_op, refa667_inst, refa667_op in H. discriminate H. Qed.

Lemma refa667_not1633 : ~ @Equation1633 Fin6 refa667_inst.
Proof. unfold Equation1633. intro H. specialize (H F6_0 F6_2 F6_1). unfold magma_op, refa667_inst, refa667_op in H. discriminate H. Qed.

Lemma refa667_not2452 : ~ @Equation2452 Fin6 refa667_inst.
Proof. unfold Equation2452. intro H. specialize (H F6_0 F6_2 F6_1). unfold magma_op, refa667_inst, refa667_op in H. discriminate H. Qed.

Lemma refa667_not3315 : ~ @Equation3315 Fin6 refa667_inst.
Proof. unfold Equation3315. intro H. specialize (H F6_0 F6_1). unfold magma_op, refa667_inst, refa667_op in H. discriminate H. Qed.

Lemma refa667_not3316 : ~ @Equation3316 Fin6 refa667_inst.
Proof. unfold Equation3316. intro H. specialize (H F6_0 F6_1). unfold magma_op, refa667_inst, refa667_op in H. discriminate H. Qed.

Lemma refa667_not3460 : ~ @Equation3460 Fin6 refa667_inst.
Proof. unfold Equation3460. intro H. specialize (H F6_0 F6_2 F6_1). unfold magma_op, refa667_inst, refa667_op in H. discriminate H. Qed.

Lemma refa667_not3518 : ~ @Equation3518 Fin6 refa667_inst.
Proof. unfold Equation3518. intro H. specialize (H F6_0 F6_1). unfold magma_op, refa667_inst, refa667_op in H. discriminate H. Qed.

Lemma refa667_not3519 : ~ @Equation3519 Fin6 refa667_inst.
Proof. unfold Equation3519. intro H. specialize (H F6_0 F6_2). unfold magma_op, refa667_inst, refa667_op in H. discriminate H. Qed.

Lemma refa667_not3521 : ~ @Equation3521 Fin6 refa667_inst.
Proof. unfold Equation3521. intro H. specialize (H F6_0 F6_1). unfold magma_op, refa667_inst, refa667_op in H. discriminate H. Qed.

Lemma refa667_not3714 : ~ @Equation3714 Fin6 refa667_inst.
Proof. unfold Equation3714. intro H. specialize (H F6_0 F6_1). unfold magma_op, refa667_inst, refa667_op in H. discriminate H. Qed.

Lemma refa667_not3721 : ~ @Equation3721 Fin6 refa667_inst.
Proof. unfold Equation3721. intro H. specialize (H F6_1 F6_0). unfold magma_op, refa667_inst, refa667_op in H. discriminate H. Qed.

Lemma refa667_not3724 : ~ @Equation3724 Fin6 refa667_inst.
Proof. unfold Equation3724. intro H. specialize (H F6_0 F6_1). unfold magma_op, refa667_inst, refa667_op in H. discriminate H. Qed.

Lemma refa667_not3725 : ~ @Equation3725 Fin6 refa667_inst.
Proof. unfold Equation3725. intro H. specialize (H F6_0 F6_1). unfold magma_op, refa667_inst, refa667_op in H. discriminate H. Qed.

Lemma refa667_not3924 : ~ @Equation3924 Fin6 refa667_inst.
Proof. unfold Equation3924. intro H. specialize (H F6_0 F6_1). unfold magma_op, refa667_inst, refa667_op in H. discriminate H. Qed.

Lemma refa667_not3925 : ~ @Equation3925 Fin6 refa667_inst.
Proof. unfold Equation3925. intro H. specialize (H F6_0 F6_1). unfold magma_op, refa667_inst, refa667_op in H. discriminate H. Qed.

Lemma refa667_not3927 : ~ @Equation3927 Fin6 refa667_inst.
Proof. unfold Equation3927. intro H. specialize (H F6_1 F6_0). unfold magma_op, refa667_inst, refa667_op in H. discriminate H. Qed.

Lemma refa667_not3928 : ~ @Equation3928 Fin6 refa667_inst.
Proof. unfold Equation3928. intro H. specialize (H F6_0 F6_1). unfold magma_op, refa667_inst, refa667_op in H. discriminate H. Qed.

Lemma refa667_not4120 : ~ @Equation4120 Fin6 refa667_inst.
Proof. unfold Equation4120. intro H. specialize (H F6_1 F6_0). unfold magma_op, refa667_inst, refa667_op in H. discriminate H. Qed.

Lemma refa667_not4121 : ~ @Equation4121 Fin6 refa667_inst.
Proof. unfold Equation4121. intro H. specialize (H F6_0 F6_1). unfold magma_op, refa667_inst, refa667_op in H. discriminate H. Qed.

Lemma refa667_not4127 : ~ @Equation4127 Fin6 refa667_inst.
Proof. unfold Equation4127. intro H. specialize (H F6_1 F6_0). unfold magma_op, refa667_inst, refa667_op in H. discriminate H. Qed.

Lemma refa667_not4128 : ~ @Equation4128 Fin6 refa667_inst.
Proof. unfold Equation4128. intro H. specialize (H F6_0 F6_1). unfold magma_op, refa667_inst, refa667_op in H. discriminate H. Qed.

Lemma refa667_not4130 : ~ @Equation4130 Fin6 refa667_inst.
Proof. unfold Equation4130. intro H. specialize (H F6_0 F6_1). unfold magma_op, refa667_inst, refa667_op in H. discriminate H. Qed.

Lemma refa667_not4131 : ~ @Equation4131 Fin6 refa667_inst.
Proof. unfold Equation4131. intro H. specialize (H F6_1 F6_0). unfold magma_op, refa667_inst, refa667_op in H. discriminate H. Qed.

Lemma refa667_not4314 : ~ @Equation4314 Fin6 refa667_inst.
Proof. unfold Equation4314. intro H. specialize (H F6_0 F6_1). unfold magma_op, refa667_inst, refa667_op in H. discriminate H. Qed.

Lemma refa667_not4433 : ~ @Equation4433 Fin6 refa667_inst.
Proof. unfold Equation4433. intro H. specialize (H F6_0 F6_1). unfold magma_op, refa667_inst, refa667_op in H. discriminate H. Qed.

Lemma refa667_not4435 : ~ @Equation4435 Fin6 refa667_inst.
Proof. unfold Equation4435. intro H. specialize (H F6_0 F6_1). unfold magma_op, refa667_inst, refa667_op in H. discriminate H. Qed.

Lemma refa667_not4436 : ~ @Equation4436 Fin6 refa667_inst.
Proof. unfold Equation4436. intro H. specialize (H F6_0 F6_1). unfold magma_op, refa667_inst, refa667_op in H. discriminate H. Qed.

Lemma refa667_not4472 : ~ @Equation4472 Fin6 refa667_inst.
Proof. unfold Equation4472. intro H. specialize (H F6_1 F6_0). unfold magma_op, refa667_inst, refa667_op in H. discriminate H. Qed.

Lemma refa667_not4473 : ~ @Equation4473 Fin6 refa667_inst.
Proof. unfold Equation4473. intro H. specialize (H F6_0 F6_1). unfold magma_op, refa667_inst, refa667_op in H. discriminate H. Qed.

Lemma refa667_not4598 : ~ @Equation4598 Fin6 refa667_inst.
Proof. unfold Equation4598. intro H. specialize (H F6_1 F6_0). unfold magma_op, refa667_inst, refa667_op in H. discriminate H. Qed.

Lemma refa667_not4599 : ~ @Equation4599 Fin6 refa667_inst.
Proof. unfold Equation4599. intro H. specialize (H F6_0 F6_1). unfold magma_op, refa667_inst, refa667_op in H. discriminate H. Qed.

Lemma refa667_not4629 : ~ @Equation4629 Fin6 refa667_inst.
Proof. unfold Equation4629. intro H. specialize (H F6_0 F6_1). unfold magma_op, refa667_inst, refa667_op in H. discriminate H. Qed.

(** ---- refa668 (Fin6) ---- *)

Definition refa668_op (x y : Fin6) : Fin6 :=
  match x, y with
  | F6_0, F6_0 => F6_0 | F6_0, F6_1 => F6_2 | F6_0, F6_2 => F6_0 | F6_0, F6_3 => F6_5 | F6_0, F6_4 => F6_5 | F6_0, F6_5 => F6_0
  | F6_1, F6_0 => F6_3 | F6_1, F6_1 => F6_1 | F6_1, F6_2 => F6_1 | F6_1, F6_3 => F6_1 | F6_1, F6_4 => F6_1 | F6_1, F6_5 => F6_4
  | F6_2, F6_0 => F6_2 | F6_2, F6_1 => F6_5 | F6_2, F6_2 => F6_2 | F6_2, F6_3 => F6_4 | F6_2, F6_4 => F6_2 | F6_2, F6_5 => F6_2
  | F6_3, F6_0 => F6_4 | F6_3, F6_1 => F6_3 | F6_3, F6_2 => F6_3 | F6_3, F6_3 => F6_3 | F6_3, F6_4 => F6_3 | F6_3, F6_5 => F6_4
  | F6_4, F6_0 => F6_2 | F6_4, F6_1 => F6_2 | F6_4, F6_2 => F6_4 | F6_4, F6_3 => F6_4 | F6_4, F6_4 => F6_4 | F6_4, F6_5 => F6_4
  | F6_5, F6_0 => F6_5 | F6_5, F6_1 => F6_5 | F6_5, F6_2 => F6_5 | F6_5, F6_3 => F6_5 | F6_5, F6_4 => F6_5 | F6_5, F6_5 => F6_5
  end.

#[local] Instance refa668_inst : Magma Fin6 := {| magma_op := refa668_op |}.

Lemma refa668_sat1235 : @Equation1235 Fin6 refa668_inst.
Proof. unfold Equation1235, magma_op, refa668_inst, refa668_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa668_not825 : ~ @Equation825 Fin6 refa668_inst.
Proof. unfold Equation825. intro H. specialize (H F6_0 F6_1). unfold magma_op, refa668_inst, refa668_op in H. discriminate H. Qed.

Lemma refa668_not1228 : ~ @Equation1228 Fin6 refa668_inst.
Proof. unfold Equation1228. intro H. specialize (H F6_1 F6_5). unfold magma_op, refa668_inst, refa668_op in H. discriminate H. Qed.

(** ---- refa669 (Fin7) ---- *)

Definition refa669_op (x y : Fin7) : Fin7 :=
  match x, y with
  | F7_0, F7_0 => F7_2 | F7_0, F7_1 => F7_1 | F7_0, F7_2 => F7_0 | F7_0, F7_3 => F7_5 | F7_0, F7_4 => F7_3 | F7_0, F7_5 => F7_4 | F7_0, F7_6 => F7_6
  | F7_1, F7_0 => F7_4 | F7_1, F7_1 => F7_1 | F7_1, F7_2 => F7_3 | F7_1, F7_3 => F7_6 | F7_1, F7_4 => F7_5 | F7_1, F7_5 => F7_0 | F7_1, F7_6 => F7_2
  | F7_2, F7_0 => F7_2 | F7_2, F7_1 => F7_6 | F7_2, F7_2 => F7_0 | F7_2, F7_3 => F7_1 | F7_2, F7_4 => F7_4 | F7_2, F7_5 => F7_5 | F7_2, F7_6 => F7_3
  | F7_3, F7_0 => F7_4 | F7_3, F7_1 => F7_2 | F7_3, F7_2 => F7_6 | F7_3, F7_3 => F7_3 | F7_3, F7_4 => F7_5 | F7_3, F7_5 => F7_0 | F7_3, F7_6 => F7_1
  | F7_4, F7_0 => F7_5 | F7_4, F7_1 => F7_2 | F7_4, F7_2 => F7_6 | F7_4, F7_3 => F7_0 | F7_4, F7_4 => F7_4 | F7_4, F7_5 => F7_3 | F7_4, F7_6 => F7_1
  | F7_5, F7_0 => F7_3 | F7_5, F7_1 => F7_2 | F7_5, F7_2 => F7_6 | F7_5, F7_3 => F7_4 | F7_5, F7_4 => F7_0 | F7_5, F7_5 => F7_5 | F7_5, F7_6 => F7_1
  | F7_6, F7_0 => F7_4 | F7_6, F7_1 => F7_3 | F7_6, F7_2 => F7_1 | F7_6, F7_3 => F7_2 | F7_6, F7_4 => F7_5 | F7_6, F7_5 => F7_0 | F7_6, F7_6 => F7_6
  end.

#[local] Instance refa669_inst : Magma Fin7 := {| magma_op := refa669_op |}.

Lemma refa669_sat124 : @Equation124 Fin7 refa669_inst.
Proof. unfold Equation124, magma_op, refa669_inst, refa669_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa669_sat1924 : @Equation1924 Fin7 refa669_inst.
Proof. unfold Equation1924, magma_op, refa669_inst, refa669_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa669_not439 : ~ @Equation439 Fin7 refa669_inst.
Proof. unfold Equation439. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa669_inst, refa669_op in H. discriminate H. Qed.

Lemma refa669_not1038 : ~ @Equation1038 Fin7 refa669_inst.
Proof. unfold Equation1038. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa669_inst, refa669_op in H. discriminate H. Qed.

Lemma refa669_not1075 : ~ @Equation1075 Fin7 refa669_inst.
Proof. unfold Equation1075. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa669_inst, refa669_op in H. discriminate H. Qed.

Lemma refa669_not1109 : ~ @Equation1109 Fin7 refa669_inst.
Proof. unfold Equation1109. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa669_inst, refa669_op in H. discriminate H. Qed.

Lemma refa669_not1241 : ~ @Equation1241 Fin7 refa669_inst.
Proof. unfold Equation1241. intro H. specialize (H F7_0 F7_6). unfold magma_op, refa669_inst, refa669_op in H. discriminate H. Qed.

Lemma refa669_not1288 : ~ @Equation1288 Fin7 refa669_inst.
Proof. unfold Equation1288. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa669_inst, refa669_op in H. discriminate H. Qed.

Lemma refa669_not1322 : ~ @Equation1322 Fin7 refa669_inst.
Proof. unfold Equation1322. intro H. specialize (H F7_1 F7_0). unfold magma_op, refa669_inst, refa669_op in H. discriminate H. Qed.

Lemma refa669_not1657 : ~ @Equation1657 Fin7 refa669_inst.
Proof. unfold Equation1657. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa669_inst, refa669_op in H. discriminate H. Qed.

Lemma refa669_not1684 : ~ @Equation1684 Fin7 refa669_inst.
Proof. unfold Equation1684. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa669_inst, refa669_op in H. discriminate H. Qed.

Lemma refa669_not1728 : ~ @Equation1728 Fin7 refa669_inst.
Proof. unfold Equation1728. intro H. specialize (H F7_1 F7_0). unfold magma_op, refa669_inst, refa669_op in H. discriminate H. Qed.

Lemma refa669_not1860 : ~ @Equation1860 Fin7 refa669_inst.
Proof. unfold Equation1860. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa669_inst, refa669_op in H. discriminate H. Qed.

Lemma refa669_not1894 : ~ @Equation1894 Fin7 refa669_inst.
Proof. unfold Equation1894. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa669_inst, refa669_op in H. discriminate H. Qed.

Lemma refa669_not2043 : ~ @Equation2043 Fin7 refa669_inst.
Proof. unfold Equation2043. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa669_inst, refa669_op in H. discriminate H. Qed.

Lemma refa669_not2097 : ~ @Equation2097 Fin7 refa669_inst.
Proof. unfold Equation2097. intro H. specialize (H F7_0 F7_6). unfold magma_op, refa669_inst, refa669_op in H. discriminate H. Qed.

Lemma refa669_not3281 : ~ @Equation3281 Fin7 refa669_inst.
Proof. unfold Equation3281. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa669_inst, refa669_op in H. discriminate H. Qed.

Lemma refa669_not3880 : ~ @Equation3880 Fin7 refa669_inst.
Proof. unfold Equation3880. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa669_inst, refa669_op in H. discriminate H. Qed.

Lemma refa669_not4083 : ~ @Equation4083 Fin7 refa669_inst.
Proof. unfold Equation4083. intro H. specialize (H F7_0 F7_6). unfold magma_op, refa669_inst, refa669_op in H. discriminate H. Qed.

Lemma refa669_not4118 : ~ @Equation4118 Fin7 refa669_inst.
Proof. unfold Equation4118. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa669_inst, refa669_op in H. discriminate H. Qed.

Lemma refa669_not4158 : ~ @Equation4158 Fin7 refa669_inst.
Proof. unfold Equation4158. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa669_inst, refa669_op in H. discriminate H. Qed.

(** ---- refa67 (Fin3) ---- *)

Definition refa67_op (x y : Fin3) : Fin3 :=
  match x, y with
  | F3_0, F3_0 => F3_0 | F3_0, F3_1 => F3_0 | F3_0, F3_2 => F3_0
  | F3_1, F3_0 => F3_1 | F3_1, F3_1 => F3_1 | F3_1, F3_2 => F3_0
  | F3_2, F3_0 => F3_1 | F3_2, F3_1 => F3_2 | F3_2, F3_2 => F3_1
  end.

#[local] Instance refa67_inst : Magma Fin3 := {| magma_op := refa67_op |}.

Lemma refa67_sat417 : @Equation417 Fin3 refa67_inst.
Proof. unfold Equation417, magma_op, refa67_inst, refa67_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa67_sat619 : @Equation619 Fin3 refa67_inst.
Proof. unfold Equation619, magma_op, refa67_inst, refa67_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa67_sat620 : @Equation620 Fin3 refa67_inst.
Proof. unfold Equation620, magma_op, refa67_inst, refa67_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa67_sat622 : @Equation622 Fin3 refa67_inst.
Proof. unfold Equation622, magma_op, refa67_inst, refa67_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa67_sat819 : @Equation819 Fin3 refa67_inst.
Proof. unfold Equation819, magma_op, refa67_inst, refa67_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa67_sat820 : @Equation820 Fin3 refa67_inst.
Proof. unfold Equation820, magma_op, refa67_inst, refa67_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa67_sat823 : @Equation823 Fin3 refa67_inst.
Proof. unfold Equation823, magma_op, refa67_inst, refa67_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa67_sat825 : @Equation825 Fin3 refa67_inst.
Proof. unfold Equation825, magma_op, refa67_inst, refa67_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa67_sat1023 : @Equation1023 Fin3 refa67_inst.
Proof. unfold Equation1023, magma_op, refa67_inst, refa67_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa67_sat1026 : @Equation1026 Fin3 refa67_inst.
Proof. unfold Equation1026, magma_op, refa67_inst, refa67_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa67_sat3259 : @Equation3259 Fin3 refa67_inst.
Proof. unfold Equation3259, magma_op, refa67_inst, refa67_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa67_sat3315 : @Equation3315 Fin3 refa67_inst.
Proof. unfold Equation3315, magma_op, refa67_inst, refa67_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa67_sat3462 : @Equation3462 Fin3 refa67_inst.
Proof. unfold Equation3462, magma_op, refa67_inst, refa67_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa67_sat3464 : @Equation3464 Fin3 refa67_inst.
Proof. unfold Equation3464, magma_op, refa67_inst, refa67_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa67_sat3662 : @Equation3662 Fin3 refa67_inst.
Proof. unfold Equation3662, magma_op, refa67_inst, refa67_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa67_sat3928 : @Equation3928 Fin3 refa67_inst.
Proof. unfold Equation3928, magma_op, refa67_inst, refa67_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa67_not47 : ~ @Equation47 Fin3 refa67_inst.
Proof. unfold Equation47. intro H. specialize (H F3_2). unfold magma_op, refa67_inst, refa67_op in H. discriminate H. Qed.

Lemma refa67_not414 : ~ @Equation414 Fin3 refa67_inst.
Proof. unfold Equation414. intro H. specialize (H F3_2 F3_0). unfold magma_op, refa67_inst, refa67_op in H. discriminate H. Qed.

Lemma refa67_not419 : ~ @Equation419 Fin3 refa67_inst.
Proof. unfold Equation419. intro H. specialize (H F3_2 F3_1). unfold magma_op, refa67_inst, refa67_op in H. discriminate H. Qed.

Lemma refa67_not427 : ~ @Equation427 Fin3 refa67_inst.
Proof. unfold Equation427. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa67_inst, refa67_op in H. discriminate H. Qed.

Lemma refa67_not429 : ~ @Equation429 Fin3 refa67_inst.
Proof. unfold Equation429. intro H. specialize (H F3_2 F3_0). unfold magma_op, refa67_inst, refa67_op in H. discriminate H. Qed.

Lemma refa67_not466 : ~ @Equation466 Fin3 refa67_inst.
Proof. unfold Equation466. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa67_inst, refa67_op in H. discriminate H. Qed.

Lemma refa67_not473 : ~ @Equation473 Fin3 refa67_inst.
Proof. unfold Equation473. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa67_inst, refa67_op in H. discriminate H. Qed.

Lemma refa67_not477 : ~ @Equation477 Fin3 refa67_inst.
Proof. unfold Equation477. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa67_inst, refa67_op in H. discriminate H. Qed.

Lemma refa67_not504 : ~ @Equation504 Fin3 refa67_inst.
Proof. unfold Equation504. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa67_inst, refa67_op in H. discriminate H. Qed.

Lemma refa67_not511 : ~ @Equation511 Fin3 refa67_inst.
Proof. unfold Equation511. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa67_inst, refa67_op in H. discriminate H. Qed.

Lemma refa67_not513 : ~ @Equation513 Fin3 refa67_inst.
Proof. unfold Equation513. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa67_inst, refa67_op in H. discriminate H. Qed.

Lemma refa67_not617 : ~ @Equation617 Fin3 refa67_inst.
Proof. unfold Equation617. intro H. specialize (H F3_2 F3_0). unfold magma_op, refa67_inst, refa67_op in H. discriminate H. Qed.

Lemma refa67_not630 : ~ @Equation630 Fin3 refa67_inst.
Proof. unfold Equation630. intro H. specialize (H F3_2 F3_0). unfold magma_op, refa67_inst, refa67_op in H. discriminate H. Qed.

Lemma refa67_not632 : ~ @Equation632 Fin3 refa67_inst.
Proof. unfold Equation632. intro H. specialize (H F3_2 F3_0). unfold magma_op, refa67_inst, refa67_op in H. discriminate H. Qed.

Lemma refa67_not639 : ~ @Equation639 Fin3 refa67_inst.
Proof. unfold Equation639. intro H. specialize (H F3_2 F3_0). unfold magma_op, refa67_inst, refa67_op in H. discriminate H. Qed.

Lemma refa67_not643 : ~ @Equation643 Fin3 refa67_inst.
Proof. unfold Equation643. intro H. specialize (H F3_2 F3_0). unfold magma_op, refa67_inst, refa67_op in H. discriminate H. Qed.

Lemma refa67_not667 : ~ @Equation667 Fin3 refa67_inst.
Proof. unfold Equation667. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa67_inst, refa67_op in H. discriminate H. Qed.

Lemma refa67_not669 : ~ @Equation669 Fin3 refa67_inst.
Proof. unfold Equation669. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa67_inst, refa67_op in H. discriminate H. Qed.

Lemma refa67_not676 : ~ @Equation676 Fin3 refa67_inst.
Proof. unfold Equation676. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa67_inst, refa67_op in H. discriminate H. Qed.

Lemma refa67_not680 : ~ @Equation680 Fin3 refa67_inst.
Proof. unfold Equation680. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa67_inst, refa67_op in H. discriminate H. Qed.

Lemma refa67_not707 : ~ @Equation707 Fin3 refa67_inst.
Proof. unfold Equation707. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa67_inst, refa67_op in H. discriminate H. Qed.

Lemma refa67_not832 : ~ @Equation832 Fin3 refa67_inst.
Proof. unfold Equation832. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa67_inst, refa67_op in H. discriminate H. Qed.

Lemma refa67_not833 : ~ @Equation833 Fin3 refa67_inst.
Proof. unfold Equation833. intro H. specialize (H F3_2 F3_0). unfold magma_op, refa67_inst, refa67_op in H. discriminate H. Qed.

Lemma refa67_not835 : ~ @Equation835 Fin3 refa67_inst.
Proof. unfold Equation835. intro H. specialize (H F3_2 F3_0). unfold magma_op, refa67_inst, refa67_op in H. discriminate H. Qed.

Lemma refa67_not842 : ~ @Equation842 Fin3 refa67_inst.
Proof. unfold Equation842. intro H. specialize (H F3_2 F3_0). unfold magma_op, refa67_inst, refa67_op in H. discriminate H. Qed.

Lemma refa67_not845 : ~ @Equation845 Fin3 refa67_inst.
Proof. unfold Equation845. intro H. specialize (H F3_2 F3_0). unfold magma_op, refa67_inst, refa67_op in H. discriminate H. Qed.

Lemma refa67_not870 : ~ @Equation870 Fin3 refa67_inst.
Proof. unfold Equation870. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa67_inst, refa67_op in H. discriminate H. Qed.

Lemma refa67_not872 : ~ @Equation872 Fin3 refa67_inst.
Proof. unfold Equation872. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa67_inst, refa67_op in H. discriminate H. Qed.

Lemma refa67_not879 : ~ @Equation879 Fin3 refa67_inst.
Proof. unfold Equation879. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa67_inst, refa67_op in H. discriminate H. Qed.

Lemma refa67_not883 : ~ @Equation883 Fin3 refa67_inst.
Proof. unfold Equation883. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa67_inst, refa67_op in H. discriminate H. Qed.

Lemma refa67_not906 : ~ @Equation906 Fin3 refa67_inst.
Proof. unfold Equation906. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa67_inst, refa67_op in H. discriminate H. Qed.

Lemma refa67_not917 : ~ @Equation917 Fin3 refa67_inst.
Proof. unfold Equation917. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa67_inst, refa67_op in H. discriminate H. Qed.

Lemma refa67_not1028 : ~ @Equation1028 Fin3 refa67_inst.
Proof. unfold Equation1028. intro H. specialize (H F3_2 F3_0). unfold magma_op, refa67_inst, refa67_op in H. discriminate H. Qed.

Lemma refa67_not1038 : ~ @Equation1038 Fin3 refa67_inst.
Proof. unfold Equation1038. intro H. specialize (H F3_2 F3_0). unfold magma_op, refa67_inst, refa67_op in H. discriminate H. Qed.

Lemma refa67_not1045 : ~ @Equation1045 Fin3 refa67_inst.
Proof. unfold Equation1045. intro H. specialize (H F3_2 F3_0). unfold magma_op, refa67_inst, refa67_op in H. discriminate H. Qed.

Lemma refa67_not1075 : ~ @Equation1075 Fin3 refa67_inst.
Proof. unfold Equation1075. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa67_inst, refa67_op in H. discriminate H. Qed.

Lemma refa67_not1082 : ~ @Equation1082 Fin3 refa67_inst.
Proof. unfold Equation1082. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa67_inst, refa67_op in H. discriminate H. Qed.

Lemma refa67_not1086 : ~ @Equation1086 Fin3 refa67_inst.
Proof. unfold Equation1086. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa67_inst, refa67_op in H. discriminate H. Qed.

Lemma refa67_not1109 : ~ @Equation1109 Fin3 refa67_inst.
Proof. unfold Equation1109. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa67_inst, refa67_op in H. discriminate H. Qed.

Lemma refa67_not1113 : ~ @Equation1113 Fin3 refa67_inst.
Proof. unfold Equation1113. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa67_inst, refa67_op in H. discriminate H. Qed.

Lemma refa67_not1122 : ~ @Equation1122 Fin3 refa67_inst.
Proof. unfold Equation1122. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa67_inst, refa67_op in H. discriminate H. Qed.

Lemma refa67_not1223 : ~ @Equation1223 Fin3 refa67_inst.
Proof. unfold Equation1223. intro H. specialize (H F3_2). unfold magma_op, refa67_inst, refa67_op in H. discriminate H. Qed.

Lemma refa67_not1426 : ~ @Equation1426 Fin3 refa67_inst.
Proof. unfold Equation1426. intro H. specialize (H F3_2). unfold magma_op, refa67_inst, refa67_op in H. discriminate H. Qed.

Lemma refa67_not1629 : ~ @Equation1629 Fin3 refa67_inst.
Proof. unfold Equation1629. intro H. specialize (H F3_2). unfold magma_op, refa67_inst, refa67_op in H. discriminate H. Qed.

Lemma refa67_not1838 : ~ @Equation1838 Fin3 refa67_inst.
Proof. unfold Equation1838. intro H. specialize (H F3_2 F3_1). unfold magma_op, refa67_inst, refa67_op in H. discriminate H. Qed.

Lemma refa67_not1840 : ~ @Equation1840 Fin3 refa67_inst.
Proof. unfold Equation1840. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa67_inst, refa67_op in H. discriminate H. Qed.

Lemma refa67_not1848 : ~ @Equation1848 Fin3 refa67_inst.
Proof. unfold Equation1848. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa67_inst, refa67_op in H. discriminate H. Qed.

Lemma refa67_not1857 : ~ @Equation1857 Fin3 refa67_inst.
Proof. unfold Equation1857. intro H. specialize (H F3_2 F3_0). unfold magma_op, refa67_inst, refa67_op in H. discriminate H. Qed.

Lemma refa67_not1861 : ~ @Equation1861 Fin3 refa67_inst.
Proof. unfold Equation1861. intro H. specialize (H F3_2 F3_0). unfold magma_op, refa67_inst, refa67_op in H. discriminate H. Qed.

Lemma refa67_not1885 : ~ @Equation1885 Fin3 refa67_inst.
Proof. unfold Equation1885. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa67_inst, refa67_op in H. discriminate H. Qed.

Lemma refa67_not1887 : ~ @Equation1887 Fin3 refa67_inst.
Proof. unfold Equation1887. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa67_inst, refa67_op in H. discriminate H. Qed.

Lemma refa67_not1894 : ~ @Equation1894 Fin3 refa67_inst.
Proof. unfold Equation1894. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa67_inst, refa67_op in H. discriminate H. Qed.

Lemma refa67_not1921 : ~ @Equation1921 Fin3 refa67_inst.
Proof. unfold Equation1921. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa67_inst, refa67_op in H. discriminate H. Qed.

Lemma refa67_not1925 : ~ @Equation1925 Fin3 refa67_inst.
Proof. unfold Equation1925. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa67_inst, refa67_op in H. discriminate H. Qed.

Lemma refa67_not2035 : ~ @Equation2035 Fin3 refa67_inst.
Proof. unfold Equation2035. intro H. specialize (H F3_2). unfold magma_op, refa67_inst, refa67_op in H. discriminate H. Qed.

Lemma refa67_not2238 : ~ @Equation2238 Fin3 refa67_inst.
Proof. unfold Equation2238. intro H. specialize (H F3_2). unfold magma_op, refa67_inst, refa67_op in H. discriminate H. Qed.

Lemma refa67_not2441 : ~ @Equation2441 Fin3 refa67_inst.
Proof. unfold Equation2441. intro H. specialize (H F3_2). unfold magma_op, refa67_inst, refa67_op in H. discriminate H. Qed.

Lemma refa67_not2644 : ~ @Equation2644 Fin3 refa67_inst.
Proof. unfold Equation2644. intro H. specialize (H F3_2). unfold magma_op, refa67_inst, refa67_op in H. discriminate H. Qed.

Lemma refa67_not2847 : ~ @Equation2847 Fin3 refa67_inst.
Proof. unfold Equation2847. intro H. specialize (H F3_2). unfold magma_op, refa67_inst, refa67_op in H. discriminate H. Qed.

Lemma refa67_not3050 : ~ @Equation3050 Fin3 refa67_inst.
Proof. unfold Equation3050. intro H. specialize (H F3_2). unfold magma_op, refa67_inst, refa67_op in H. discriminate H. Qed.

Lemma refa67_not3261 : ~ @Equation3261 Fin3 refa67_inst.
Proof. unfold Equation3261. intro H. specialize (H F3_2 F3_1). unfold magma_op, refa67_inst, refa67_op in H. discriminate H. Qed.

Lemma refa67_not3269 : ~ @Equation3269 Fin3 refa67_inst.
Proof. unfold Equation3269. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa67_inst, refa67_op in H. discriminate H. Qed.

Lemma refa67_not3271 : ~ @Equation3271 Fin3 refa67_inst.
Proof. unfold Equation3271. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa67_inst, refa67_op in H. discriminate H. Qed.

Lemma refa67_not3278 : ~ @Equation3278 Fin3 refa67_inst.
Proof. unfold Equation3278. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa67_inst, refa67_op in H. discriminate H. Qed.

Lemma refa67_not3279 : ~ @Equation3279 Fin3 refa67_inst.
Proof. unfold Equation3279. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa67_inst, refa67_op in H. discriminate H. Qed.

Lemma refa67_not3306 : ~ @Equation3306 Fin3 refa67_inst.
Proof. unfold Equation3306. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa67_inst, refa67_op in H. discriminate H. Qed.

Lemma refa67_not3308 : ~ @Equation3308 Fin3 refa67_inst.
Proof. unfold Equation3308. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa67_inst, refa67_op in H. discriminate H. Qed.

Lemma refa67_not3342 : ~ @Equation3342 Fin3 refa67_inst.
Proof. unfold Equation3342. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa67_inst, refa67_op in H. discriminate H. Qed.

Lemma refa67_not3346 : ~ @Equation3346 Fin3 refa67_inst.
Proof. unfold Equation3346. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa67_inst, refa67_op in H. discriminate H. Qed.

Lemma refa67_not3353 : ~ @Equation3353 Fin3 refa67_inst.
Proof. unfold Equation3353. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa67_inst, refa67_op in H. discriminate H. Qed.

Lemma refa67_not3459 : ~ @Equation3459 Fin3 refa67_inst.
Proof. unfold Equation3459. intro H. specialize (H F3_2 F3_0). unfold magma_op, refa67_inst, refa67_op in H. discriminate H. Qed.

Lemma refa67_not3472 : ~ @Equation3472 Fin3 refa67_inst.
Proof. unfold Equation3472. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa67_inst, refa67_op in H. discriminate H. Qed.

Lemma refa67_not3474 : ~ @Equation3474 Fin3 refa67_inst.
Proof. unfold Equation3474. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa67_inst, refa67_op in H. discriminate H. Qed.

Lemma refa67_not3481 : ~ @Equation3481 Fin3 refa67_inst.
Proof. unfold Equation3481. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa67_inst, refa67_op in H. discriminate H. Qed.

Lemma refa67_not3509 : ~ @Equation3509 Fin3 refa67_inst.
Proof. unfold Equation3509. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa67_inst, refa67_op in H. discriminate H. Qed.

Lemma refa67_not3511 : ~ @Equation3511 Fin3 refa67_inst.
Proof. unfold Equation3511. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa67_inst, refa67_op in H. discriminate H. Qed.

Lemma refa67_not3518 : ~ @Equation3518 Fin3 refa67_inst.
Proof. unfold Equation3518. intro H. specialize (H F3_2 F3_1). unfold magma_op, refa67_inst, refa67_op in H. discriminate H. Qed.

Lemma refa67_not3522 : ~ @Equation3522 Fin3 refa67_inst.
Proof. unfold Equation3522. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa67_inst, refa67_op in H. discriminate H. Qed.

Lemma refa67_not3545 : ~ @Equation3545 Fin3 refa67_inst.
Proof. unfold Equation3545. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa67_inst, refa67_op in H. discriminate H. Qed.

Lemma refa67_not3549 : ~ @Equation3549 Fin3 refa67_inst.
Proof. unfold Equation3549. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa67_inst, refa67_op in H. discriminate H. Qed.

Lemma refa67_not3558 : ~ @Equation3558 Fin3 refa67_inst.
Proof. unfold Equation3558. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa67_inst, refa67_op in H. discriminate H. Qed.

Lemma refa67_not3685 : ~ @Equation3685 Fin3 refa67_inst.
Proof. unfold Equation3685. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa67_inst, refa67_op in H. discriminate H. Qed.

Lemma refa67_not3864 : ~ @Equation3864 Fin3 refa67_inst.
Proof. unfold Equation3864. intro H. specialize (H F3_2 F3_1). unfold magma_op, refa67_inst, refa67_op in H. discriminate H. Qed.

Lemma refa67_not3867 : ~ @Equation3867 Fin3 refa67_inst.
Proof. unfold Equation3867. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa67_inst, refa67_op in H. discriminate H. Qed.

Lemma refa67_not3870 : ~ @Equation3870 Fin3 refa67_inst.
Proof. unfold Equation3870. intro H. specialize (H F3_2 F3_0). unfold magma_op, refa67_inst, refa67_op in H. discriminate H. Qed.

Lemma refa67_not3878 : ~ @Equation3878 Fin3 refa67_inst.
Proof. unfold Equation3878. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa67_inst, refa67_op in H. discriminate H. Qed.

Lemma refa67_not3880 : ~ @Equation3880 Fin3 refa67_inst.
Proof. unfold Equation3880. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa67_inst, refa67_op in H. discriminate H. Qed.

Lemma refa67_not3881 : ~ @Equation3881 Fin3 refa67_inst.
Proof. unfold Equation3881. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa67_inst, refa67_op in H. discriminate H. Qed.

Lemma refa67_not3887 : ~ @Equation3887 Fin3 refa67_inst.
Proof. unfold Equation3887. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa67_inst, refa67_op in H. discriminate H. Qed.

Lemma refa67_not3888 : ~ @Equation3888 Fin3 refa67_inst.
Proof. unfold Equation3888. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa67_inst, refa67_op in H. discriminate H. Qed.

Lemma refa67_not3917 : ~ @Equation3917 Fin3 refa67_inst.
Proof. unfold Equation3917. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa67_inst, refa67_op in H. discriminate H. Qed.

Lemma refa67_not3924 : ~ @Equation3924 Fin3 refa67_inst.
Proof. unfold Equation3924. intro H. specialize (H F3_2 F3_0). unfold magma_op, refa67_inst, refa67_op in H. discriminate H. Qed.

Lemma refa67_not3925 : ~ @Equation3925 Fin3 refa67_inst.
Proof. unfold Equation3925. intro H. specialize (H F3_2 F3_1). unfold magma_op, refa67_inst, refa67_op in H. discriminate H. Qed.

Lemma refa67_not3955 : ~ @Equation3955 Fin3 refa67_inst.
Proof. unfold Equation3955. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa67_inst, refa67_op in H. discriminate H. Qed.

Lemma refa67_not3962 : ~ @Equation3962 Fin3 refa67_inst.
Proof. unfold Equation3962. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa67_inst, refa67_op in H. discriminate H. Qed.

Lemma refa67_not3964 : ~ @Equation3964 Fin3 refa67_inst.
Proof. unfold Equation3964. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa67_inst, refa67_op in H. discriminate H. Qed.

Lemma refa67_not4065 : ~ @Equation4065 Fin3 refa67_inst.
Proof. unfold Equation4065. intro H. specialize (H F3_2). unfold magma_op, refa67_inst, refa67_op in H. discriminate H. Qed.

Lemma refa67_not4269 : ~ @Equation4269 Fin3 refa67_inst.
Proof. unfold Equation4269. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa67_inst, refa67_op in H. discriminate H. Qed.

Lemma refa67_not4270 : ~ @Equation4270 Fin3 refa67_inst.
Proof. unfold Equation4270. intro H. specialize (H F3_2 F3_0). unfold magma_op, refa67_inst, refa67_op in H. discriminate H. Qed.

Lemma refa67_not4273 : ~ @Equation4273 Fin3 refa67_inst.
Proof. unfold Equation4273. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa67_inst, refa67_op in H. discriminate H. Qed.

Lemma refa67_not4275 : ~ @Equation4275 Fin3 refa67_inst.
Proof. unfold Equation4275. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa67_inst, refa67_op in H. discriminate H. Qed.

Lemma refa67_not4283 : ~ @Equation4283 Fin3 refa67_inst.
Proof. unfold Equation4283. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa67_inst, refa67_op in H. discriminate H. Qed.

Lemma refa67_not4293 : ~ @Equation4293 Fin3 refa67_inst.
Proof. unfold Equation4293. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa67_inst, refa67_op in H. discriminate H. Qed.

Lemma refa67_not4314 : ~ @Equation4314 Fin3 refa67_inst.
Proof. unfold Equation4314. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa67_inst, refa67_op in H. discriminate H. Qed.

Lemma refa67_not4320 : ~ @Equation4320 Fin3 refa67_inst.
Proof. unfold Equation4320. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa67_inst, refa67_op in H. discriminate H. Qed.

Lemma refa67_not4380 : ~ @Equation4380 Fin3 refa67_inst.
Proof. unfold Equation4380. intro H. specialize (H F3_2). unfold magma_op, refa67_inst, refa67_op in H. discriminate H. Qed.

Lemma refa67_not4584 : ~ @Equation4584 Fin3 refa67_inst.
Proof. unfold Equation4584. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa67_inst, refa67_op in H. discriminate H. Qed.

Lemma refa67_not4585 : ~ @Equation4585 Fin3 refa67_inst.
Proof. unfold Equation4585. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa67_inst, refa67_op in H. discriminate H. Qed.

Lemma refa67_not4588 : ~ @Equation4588 Fin3 refa67_inst.
Proof. unfold Equation4588. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa67_inst, refa67_op in H. discriminate H. Qed.

Lemma refa67_not4590 : ~ @Equation4590 Fin3 refa67_inst.
Proof. unfold Equation4590. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa67_inst, refa67_op in H. discriminate H. Qed.

Lemma refa67_not4591 : ~ @Equation4591 Fin3 refa67_inst.
Proof. unfold Equation4591. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa67_inst, refa67_op in H. discriminate H. Qed.

Lemma refa67_not4598 : ~ @Equation4598 Fin3 refa67_inst.
Proof. unfold Equation4598. intro H. specialize (H F3_2 F3_0). unfold magma_op, refa67_inst, refa67_op in H. discriminate H. Qed.

Lemma refa67_not4606 : ~ @Equation4606 Fin3 refa67_inst.
Proof. unfold Equation4606. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa67_inst, refa67_op in H. discriminate H. Qed.

Lemma refa67_not4608 : ~ @Equation4608 Fin3 refa67_inst.
Proof. unfold Equation4608. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa67_inst, refa67_op in H. discriminate H. Qed.

Lemma refa67_not4635 : ~ @Equation4635 Fin3 refa67_inst.
Proof. unfold Equation4635. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa67_inst, refa67_op in H. discriminate H. Qed.

Lemma refa67_not4636 : ~ @Equation4636 Fin3 refa67_inst.
Proof. unfold Equation4636. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa67_inst, refa67_op in H. discriminate H. Qed.

(** ---- refa670 (Fin6) ---- *)

Definition refa670_op (x y : Fin6) : Fin6 :=
  match x, y with
  | F6_0, F6_0 => F6_0 | F6_0, F6_1 => F6_2 | F6_0, F6_2 => F6_1 | F6_0, F6_3 => F6_5 | F6_0, F6_4 => F6_3 | F6_0, F6_5 => F6_4
  | F6_1, F6_0 => F6_4 | F6_1, F6_1 => F6_2 | F6_1, F6_2 => F6_1 | F6_1, F6_3 => F6_3 | F6_1, F6_4 => F6_5 | F6_1, F6_5 => F6_0
  | F6_2, F6_0 => F6_3 | F6_2, F6_1 => F6_2 | F6_2, F6_2 => F6_1 | F6_2, F6_3 => F6_4 | F6_2, F6_4 => F6_0 | F6_2, F6_5 => F6_5
  | F6_3, F6_0 => F6_4 | F6_3, F6_1 => F6_2 | F6_3, F6_2 => F6_1 | F6_3, F6_3 => F6_3 | F6_3, F6_4 => F6_5 | F6_3, F6_5 => F6_0
  | F6_4, F6_0 => F6_5 | F6_4, F6_1 => F6_2 | F6_4, F6_2 => F6_1 | F6_4, F6_3 => F6_0 | F6_4, F6_4 => F6_4 | F6_4, F6_5 => F6_3
  | F6_5, F6_0 => F6_3 | F6_5, F6_1 => F6_2 | F6_5, F6_2 => F6_1 | F6_5, F6_3 => F6_4 | F6_5, F6_4 => F6_0 | F6_5, F6_5 => F6_5
  end.

#[local] Instance refa670_inst : Magma Fin6 := {| magma_op := refa670_op |}.

Lemma refa670_sat124 : @Equation124 Fin6 refa670_inst.
Proof. unfold Equation124, magma_op, refa670_inst, refa670_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa670_sat1924 : @Equation1924 Fin6 refa670_inst.
Proof. unfold Equation1924, magma_op, refa670_inst, refa670_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa670_not159 : ~ @Equation159 Fin6 refa670_inst.
Proof. unfold Equation159. intro H. specialize (H F6_0 F6_2). unfold magma_op, refa670_inst, refa670_op in H. discriminate H. Qed.

Lemma refa670_not375 : ~ @Equation375 Fin6 refa670_inst.
Proof. unfold Equation375. intro H. specialize (H F6_1 F6_0). unfold magma_op, refa670_inst, refa670_op in H. discriminate H. Qed.

(** ---- refa671 (Fin5) ---- *)

Definition refa671_op (x y : Fin5) : Fin5 :=
  match x, y with
  | F5_0, F5_0 => F5_3 | F5_0, F5_1 => F5_2 | F5_0, F5_2 => F5_0 | F5_0, F5_3 => F5_3 | F5_0, F5_4 => F5_2
  | F5_1, F5_0 => F5_0 | F5_1, F5_1 => F5_4 | F5_1, F5_2 => F5_1 | F5_1, F5_3 => F5_1 | F5_1, F5_4 => F5_0
  | F5_2, F5_0 => F5_2 | F5_2, F5_1 => F5_3 | F5_2, F5_2 => F5_2 | F5_2, F5_3 => F5_2 | F5_2, F5_4 => F5_2
  | F5_3, F5_0 => F5_2 | F5_3, F5_1 => F5_2 | F5_3, F5_2 => F5_3 | F5_3, F5_3 => F5_3 | F5_3, F5_4 => F5_3
  | F5_4, F5_0 => F5_4 | F5_4, F5_1 => F5_2 | F5_4, F5_2 => F5_4 | F5_4, F5_3 => F5_4 | F5_4, F5_4 => F5_2
  end.

#[local] Instance refa671_inst : Magma Fin5 := {| magma_op := refa671_op |}.

Lemma refa671_sat1259 : @Equation1259 Fin5 refa671_inst.
Proof. unfold Equation1259, magma_op, refa671_inst, refa671_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa671_not1242 : ~ @Equation1242 Fin5 refa671_inst.
Proof. unfold Equation1242. intro H. specialize (H F5_0 F5_1). unfold magma_op, refa671_inst, refa671_op in H. discriminate H. Qed.

(** ---- refa672 (Fin6) ---- *)

Definition refa672_op (x y : Fin6) : Fin6 :=
  match x, y with
  | F6_0, F6_0 => F6_3 | F6_0, F6_1 => F6_4 | F6_0, F6_2 => F6_1 | F6_0, F6_3 => F6_0 | F6_0, F6_4 => F6_5 | F6_0, F6_5 => F6_2
  | F6_1, F6_0 => F6_2 | F6_1, F6_1 => F6_1 | F6_1, F6_2 => F6_3 | F6_1, F6_3 => F6_4 | F6_1, F6_4 => F6_0 | F6_1, F6_5 => F6_5
  | F6_2, F6_0 => F6_5 | F6_2, F6_1 => F6_0 | F6_2, F6_2 => F6_4 | F6_2, F6_3 => F6_1 | F6_2, F6_4 => F6_2 | F6_2, F6_5 => F6_3
  | F6_3, F6_0 => F6_0 | F6_3, F6_1 => F6_2 | F6_3, F6_2 => F6_5 | F6_3, F6_3 => F6_3 | F6_3, F6_4 => F6_1 | F6_3, F6_5 => F6_4
  | F6_4, F6_0 => F6_1 | F6_4, F6_1 => F6_3 | F6_4, F6_2 => F6_2 | F6_4, F6_3 => F6_5 | F6_4, F6_4 => F6_4 | F6_4, F6_5 => F6_0
  | F6_5, F6_0 => F6_4 | F6_5, F6_1 => F6_5 | F6_5, F6_2 => F6_0 | F6_5, F6_3 => F6_2 | F6_5, F6_4 => F6_3 | F6_5, F6_5 => F6_1
  end.

#[local] Instance refa672_inst : Magma Fin6 := {| magma_op := refa672_op |}.

Lemma refa672_sat1312 : @Equation1312 Fin6 refa672_inst.
Proof. unfold Equation1312, magma_op, refa672_inst, refa672_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa672_sat2241 : @Equation2241 Fin6 refa672_inst.
Proof. unfold Equation2241, magma_op, refa672_inst, refa672_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa672_sat3355 : @Equation3355 Fin6 refa672_inst.
Proof. unfold Equation3355, magma_op, refa672_inst, refa672_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa672_sat4154 : @Equation4154 Fin6 refa672_inst.
Proof. unfold Equation4154, magma_op, refa672_inst, refa672_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa672_not1451 : ~ @Equation1451 Fin6 refa672_inst.
Proof. unfold Equation1451. intro H. specialize (H F6_0 F6_1). unfold magma_op, refa672_inst, refa672_op in H. discriminate H. Qed.

Lemma refa672_not2043 : ~ @Equation2043 Fin6 refa672_inst.
Proof. unfold Equation2043. intro H. specialize (H F6_0 F6_1). unfold magma_op, refa672_inst, refa672_op in H. discriminate H. Qed.

Lemma refa672_not3306 : ~ @Equation3306 Fin6 refa672_inst.
Proof. unfold Equation3306. intro H. specialize (H F6_0 F6_1). unfold magma_op, refa672_inst, refa672_op in H. discriminate H. Qed.

Lemma refa672_not4131 : ~ @Equation4131 Fin6 refa672_inst.
Proof. unfold Equation4131. intro H. specialize (H F6_0 F6_1). unfold magma_op, refa672_inst, refa672_op in H. discriminate H. Qed.

(** ---- refa673 (Fin6) ---- *)

Definition refa673_op (x y : Fin6) : Fin6 :=
  match x, y with
  | F6_0, F6_0 => F6_1 | F6_0, F6_1 => F6_3 | F6_0, F6_2 => F6_0 | F6_0, F6_3 => F6_4 | F6_0, F6_4 => F6_5 | F6_0, F6_5 => F6_2
  | F6_1, F6_0 => F6_2 | F6_1, F6_1 => F6_0 | F6_1, F6_2 => F6_5 | F6_1, F6_3 => F6_1 | F6_1, F6_4 => F6_3 | F6_1, F6_5 => F6_4
  | F6_2, F6_0 => F6_2 | F6_2, F6_1 => F6_3 | F6_2, F6_2 => F6_5 | F6_2, F6_3 => F6_1 | F6_2, F6_4 => F6_0 | F6_2, F6_5 => F6_4
  | F6_3, F6_0 => F6_1 | F6_3, F6_1 => F6_3 | F6_3, F6_2 => F6_0 | F6_3, F6_3 => F6_4 | F6_3, F6_4 => F6_5 | F6_3, F6_5 => F6_2
  | F6_4, F6_0 => F6_1 | F6_4, F6_1 => F6_0 | F6_4, F6_2 => F6_5 | F6_4, F6_3 => F6_2 | F6_4, F6_4 => F6_3 | F6_4, F6_5 => F6_4
  | F6_5, F6_0 => F6_4 | F6_5, F6_1 => F6_0 | F6_5, F6_2 => F6_3 | F6_5, F6_3 => F6_1 | F6_5, F6_4 => F6_5 | F6_5, F6_5 => F6_2
  end.

#[local] Instance refa673_inst : Magma Fin6 := {| magma_op := refa673_op |}.

Lemma refa673_sat1353 : @Equation1353 Fin6 refa673_inst.
Proof. unfold Equation1353, magma_op, refa673_inst, refa673_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa673_not99 : ~ @Equation99 Fin6 refa673_inst.
Proof. unfold Equation99. intro H. specialize (H F6_2). unfold magma_op, refa673_inst, refa673_op in H. discriminate H. Qed.

Lemma refa673_not411 : ~ @Equation411 Fin6 refa673_inst.
Proof. unfold Equation411. intro H. specialize (H F6_0). unfold magma_op, refa673_inst, refa673_op in H. discriminate H. Qed.

Lemma refa673_not1248 : ~ @Equation1248 Fin6 refa673_inst.
Proof. unfold Equation1248. intro H. specialize (H F6_0 F6_2). unfold magma_op, refa673_inst, refa673_op in H. discriminate H. Qed.

Lemma refa673_not1288 : ~ @Equation1288 Fin6 refa673_inst.
Proof. unfold Equation1288. intro H. specialize (H F6_0 F6_2). unfold magma_op, refa673_inst, refa673_op in H. discriminate H. Qed.

Lemma refa673_not2035 : ~ @Equation2035 Fin6 refa673_inst.
Proof. unfold Equation2035. intro H. specialize (H F6_0). unfold magma_op, refa673_inst, refa673_op in H. discriminate H. Qed.

Lemma refa673_not3862 : ~ @Equation3862 Fin6 refa673_inst.
Proof. unfold Equation3862. intro H. specialize (H F6_1). unfold magma_op, refa673_inst, refa673_op in H. discriminate H. Qed.

Lemma refa673_not4275 : ~ @Equation4275 Fin6 refa673_inst.
Proof. unfold Equation4275. intro H. specialize (H F6_0 F6_1). unfold magma_op, refa673_inst, refa673_op in H. discriminate H. Qed.

Lemma refa673_not4320 : ~ @Equation4320 Fin6 refa673_inst.
Proof. unfold Equation4320. intro H. specialize (H F6_0 F6_2). unfold magma_op, refa673_inst, refa673_op in H. discriminate H. Qed.

Lemma refa673_not4606 : ~ @Equation4606 Fin6 refa673_inst.
Proof. unfold Equation4606. intro H. specialize (H F6_0 F6_1). unfold magma_op, refa673_inst, refa673_op in H. discriminate H. Qed.

Lemma refa673_not4666 : ~ @Equation4666 Fin6 refa673_inst.
Proof. unfold Equation4666. intro H. specialize (H F6_0 F6_0 F6_5). unfold magma_op, refa673_inst, refa673_op in H. discriminate H. Qed.

(** ---- refa674 (Fin6) ---- *)

Definition refa674_op (x y : Fin6) : Fin6 :=
  match x, y with
  | F6_0, F6_0 => F6_1 | F6_0, F6_1 => F6_4 | F6_0, F6_2 => F6_3 | F6_0, F6_3 => F6_5 | F6_0, F6_4 => F6_2 | F6_0, F6_5 => F6_0
  | F6_1, F6_0 => F6_2 | F6_1, F6_1 => F6_3 | F6_1, F6_2 => F6_4 | F6_1, F6_3 => F6_5 | F6_1, F6_4 => F6_1 | F6_1, F6_5 => F6_0
  | F6_2, F6_0 => F6_5 | F6_2, F6_1 => F6_0 | F6_2, F6_2 => F6_4 | F6_2, F6_3 => F6_2 | F6_2, F6_4 => F6_1 | F6_2, F6_5 => F6_3
  | F6_3, F6_0 => F6_1 | F6_3, F6_1 => F6_4 | F6_3, F6_2 => F6_3 | F6_3, F6_3 => F6_5 | F6_3, F6_4 => F6_2 | F6_3, F6_5 => F6_0
  | F6_4, F6_0 => F6_5 | F6_4, F6_1 => F6_4 | F6_4, F6_2 => F6_0 | F6_4, F6_3 => F6_1 | F6_4, F6_4 => F6_2 | F6_4, F6_5 => F6_3
  | F6_5, F6_0 => F6_5 | F6_5, F6_1 => F6_0 | F6_5, F6_2 => F6_4 | F6_5, F6_3 => F6_2 | F6_5, F6_4 => F6_1 | F6_5, F6_5 => F6_3
  end.

#[local] Instance refa674_inst : Magma Fin6 := {| magma_op := refa674_op |}.

Lemma refa674_sat1370 : @Equation1370 Fin6 refa674_inst.
Proof. unfold Equation1370, magma_op, refa674_inst, refa674_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa674_not99 : ~ @Equation99 Fin6 refa674_inst.
Proof. unfold Equation99. intro H. specialize (H F6_0). unfold magma_op, refa674_inst, refa674_op in H. discriminate H. Qed.

Lemma refa674_not151 : ~ @Equation151 Fin6 refa674_inst.
Proof. unfold Equation151. intro H. specialize (H F6_0). unfold magma_op, refa674_inst, refa674_op in H. discriminate H. Qed.

Lemma refa674_not411 : ~ @Equation411 Fin6 refa674_inst.
Proof. unfold Equation411. intro H. specialize (H F6_0). unfold magma_op, refa674_inst, refa674_op in H. discriminate H. Qed.

Lemma refa674_not1248 : ~ @Equation1248 Fin6 refa674_inst.
Proof. unfold Equation1248. intro H. specialize (H F6_0 F6_1). unfold magma_op, refa674_inst, refa674_op in H. discriminate H. Qed.

Lemma refa674_not1278 : ~ @Equation1278 Fin6 refa674_inst.
Proof. unfold Equation1278. intro H. specialize (H F6_0 F6_1). unfold magma_op, refa674_inst, refa674_op in H. discriminate H. Qed.

Lemma refa674_not1315 : ~ @Equation1315 Fin6 refa674_inst.
Proof. unfold Equation1315. intro H. specialize (H F6_0 F6_1). unfold magma_op, refa674_inst, refa674_op in H. discriminate H. Qed.

Lemma refa674_not2043 : ~ @Equation2043 Fin6 refa674_inst.
Proof. unfold Equation2043. intro H. specialize (H F6_0 F6_1). unfold magma_op, refa674_inst, refa674_op in H. discriminate H. Qed.

Lemma refa674_not2050 : ~ @Equation2050 Fin6 refa674_inst.
Proof. unfold Equation2050. intro H. specialize (H F6_0 F6_2). unfold magma_op, refa674_inst, refa674_op in H. discriminate H. Qed.

Lemma refa674_not2124 : ~ @Equation2124 Fin6 refa674_inst.
Proof. unfold Equation2124. intro H. specialize (H F6_0 F6_1). unfold magma_op, refa674_inst, refa674_op in H. discriminate H. Qed.

Lemma refa674_not3862 : ~ @Equation3862 Fin6 refa674_inst.
Proof. unfold Equation3862. intro H. specialize (H F6_0). unfold magma_op, refa674_inst, refa674_op in H. discriminate H. Qed.

Lemma refa674_not4275 : ~ @Equation4275 Fin6 refa674_inst.
Proof. unfold Equation4275. intro H. specialize (H F6_0 F6_2). unfold magma_op, refa674_inst, refa674_op in H. discriminate H. Qed.

Lemma refa674_not4320 : ~ @Equation4320 Fin6 refa674_inst.
Proof. unfold Equation4320. intro H. specialize (H F6_0 F6_4). unfold magma_op, refa674_inst, refa674_op in H. discriminate H. Qed.

Lemma refa674_not4606 : ~ @Equation4606 Fin6 refa674_inst.
Proof. unfold Equation4606. intro H. specialize (H F6_0 F6_1). unfold magma_op, refa674_inst, refa674_op in H. discriminate H. Qed.

Lemma refa674_not4666 : ~ @Equation4666 Fin6 refa674_inst.
Proof. unfold Equation4666. intro H. specialize (H F6_0 F6_0 F6_1). unfold magma_op, refa674_inst, refa674_op in H. discriminate H. Qed.

(** ---- refa675 (Fin5) ---- *)

Definition refa675_op (x y : Fin5) : Fin5 :=
  match x, y with
  | F5_0, F5_0 => F5_4 | F5_0, F5_1 => F5_2 | F5_0, F5_2 => F5_3 | F5_0, F5_3 => F5_1 | F5_0, F5_4 => F5_0
  | F5_1, F5_0 => F5_3 | F5_1, F5_1 => F5_4 | F5_1, F5_2 => F5_0 | F5_1, F5_3 => F5_2 | F5_1, F5_4 => F5_1
  | F5_2, F5_0 => F5_1 | F5_2, F5_1 => F5_3 | F5_2, F5_2 => F5_4 | F5_2, F5_3 => F5_0 | F5_2, F5_4 => F5_2
  | F5_3, F5_0 => F5_2 | F5_3, F5_1 => F5_0 | F5_3, F5_2 => F5_1 | F5_3, F5_3 => F5_4 | F5_3, F5_4 => F5_3
  | F5_4, F5_0 => F5_0 | F5_4, F5_1 => F5_1 | F5_4, F5_2 => F5_2 | F5_4, F5_3 => F5_3 | F5_4, F5_4 => F5_4
  end.

#[local] Instance refa675_inst : Magma Fin5 := {| magma_op := refa675_op |}.

Lemma refa675_sat1537 : @Equation1537 Fin5 refa675_inst.
Proof. unfold Equation1537, magma_op, refa675_inst, refa675_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa675_not419 : ~ @Equation419 Fin5 refa675_inst.
Proof. unfold Equation419. intro H. specialize (H F5_0 F5_1). unfold magma_op, refa675_inst, refa675_op in H. discriminate H. Qed.

Lemma refa675_not427 : ~ @Equation427 Fin5 refa675_inst.
Proof. unfold Equation427. intro H. specialize (H F5_0 F5_1). unfold magma_op, refa675_inst, refa675_op in H. discriminate H. Qed.

Lemma refa675_not464 : ~ @Equation464 Fin5 refa675_inst.
Proof. unfold Equation464. intro H. specialize (H F5_0 F5_1). unfold magma_op, refa675_inst, refa675_op in H. discriminate H. Qed.

Lemma refa675_not504 : ~ @Equation504 Fin5 refa675_inst.
Proof. unfold Equation504. intro H. specialize (H F5_0 F5_1). unfold magma_op, refa675_inst, refa675_op in H. discriminate H. Qed.

Lemma refa675_not511 : ~ @Equation511 Fin5 refa675_inst.
Proof. unfold Equation511. intro H. specialize (H F5_0 F5_1). unfold magma_op, refa675_inst, refa675_op in H. discriminate H. Qed.

Lemma refa675_not513 : ~ @Equation513 Fin5 refa675_inst.
Proof. unfold Equation513. intro H. specialize (H F5_0 F5_1). unfold magma_op, refa675_inst, refa675_op in H. discriminate H. Qed.

Lemma refa675_not617 : ~ @Equation617 Fin5 refa675_inst.
Proof. unfold Equation617. intro H. specialize (H F5_0 F5_1). unfold magma_op, refa675_inst, refa675_op in H. discriminate H. Qed.

Lemma refa675_not639 : ~ @Equation639 Fin5 refa675_inst.
Proof. unfold Equation639. intro H. specialize (H F5_0 F5_1). unfold magma_op, refa675_inst, refa675_op in H. discriminate H. Qed.

Lemma refa675_not676 : ~ @Equation676 Fin5 refa675_inst.
Proof. unfold Equation676. intro H. specialize (H F5_0 F5_1). unfold magma_op, refa675_inst, refa675_op in H. discriminate H. Qed.

Lemma refa675_not716 : ~ @Equation716 Fin5 refa675_inst.
Proof. unfold Equation716. intro H. specialize (H F5_0 F5_1). unfold magma_op, refa675_inst, refa675_op in H. discriminate H. Qed.

Lemma refa675_not825 : ~ @Equation825 Fin5 refa675_inst.
Proof. unfold Equation825. intro H. specialize (H F5_0 F5_1). unfold magma_op, refa675_inst, refa675_op in H. discriminate H. Qed.

Lemma refa675_not833 : ~ @Equation833 Fin5 refa675_inst.
Proof. unfold Equation833. intro H. specialize (H F5_0 F5_1). unfold magma_op, refa675_inst, refa675_op in H. discriminate H. Qed.

Lemma refa675_not872 : ~ @Equation872 Fin5 refa675_inst.
Proof. unfold Equation872. intro H. specialize (H F5_0 F5_1). unfold magma_op, refa675_inst, refa675_op in H. discriminate H. Qed.

Lemma refa675_not906 : ~ @Equation906 Fin5 refa675_inst.
Proof. unfold Equation906. intro H. specialize (H F5_0 F5_1). unfold magma_op, refa675_inst, refa675_op in H. discriminate H. Qed.

Lemma refa675_not1023 : ~ @Equation1023 Fin5 refa675_inst.
Proof. unfold Equation1023. intro H. specialize (H F5_0 F5_1). unfold magma_op, refa675_inst, refa675_op in H. discriminate H. Qed.

Lemma refa675_not1045 : ~ @Equation1045 Fin5 refa675_inst.
Proof. unfold Equation1045. intro H. specialize (H F5_0 F5_1). unfold magma_op, refa675_inst, refa675_op in H. discriminate H. Qed.

Lemma refa675_not1082 : ~ @Equation1082 Fin5 refa675_inst.
Proof. unfold Equation1082. intro H. specialize (H F5_0 F5_1). unfold magma_op, refa675_inst, refa675_op in H. discriminate H. Qed.

Lemma refa675_not1109 : ~ @Equation1109 Fin5 refa675_inst.
Proof. unfold Equation1109. intro H. specialize (H F5_0 F5_1). unfold magma_op, refa675_inst, refa675_op in H. discriminate H. Qed.

Lemma refa675_not1122 : ~ @Equation1122 Fin5 refa675_inst.
Proof. unfold Equation1122. intro H. specialize (H F5_0 F5_1). unfold magma_op, refa675_inst, refa675_op in H. discriminate H. Qed.

Lemma refa675_not1231 : ~ @Equation1231 Fin5 refa675_inst.
Proof. unfold Equation1231. intro H. specialize (H F5_0 F5_1). unfold magma_op, refa675_inst, refa675_op in H. discriminate H. Qed.

Lemma refa675_not1239 : ~ @Equation1239 Fin5 refa675_inst.
Proof. unfold Equation1239. intro H. specialize (H F5_0 F5_1). unfold magma_op, refa675_inst, refa675_op in H. discriminate H. Qed.

Lemma refa675_not1278 : ~ @Equation1278 Fin5 refa675_inst.
Proof. unfold Equation1278. intro H. specialize (H F5_0 F5_1). unfold magma_op, refa675_inst, refa675_op in H. discriminate H. Qed.

Lemma refa675_not1285 : ~ @Equation1285 Fin5 refa675_inst.
Proof. unfold Equation1285. intro H. specialize (H F5_0 F5_1). unfold magma_op, refa675_inst, refa675_op in H. discriminate H. Qed.

Lemma refa675_not1289 : ~ @Equation1289 Fin5 refa675_inst.
Proof. unfold Equation1289. intro H. specialize (H F5_0 F5_1). unfold magma_op, refa675_inst, refa675_op in H. discriminate H. Qed.

Lemma refa675_not1312 : ~ @Equation1312 Fin5 refa675_inst.
Proof. unfold Equation1312. intro H. specialize (H F5_0 F5_1). unfold magma_op, refa675_inst, refa675_op in H. discriminate H. Qed.

Lemma refa675_not1434 : ~ @Equation1434 Fin5 refa675_inst.
Proof. unfold Equation1434. intro H. specialize (H F5_0 F5_1). unfold magma_op, refa675_inst, refa675_op in H. discriminate H. Qed.

Lemma refa675_not1444 : ~ @Equation1444 Fin5 refa675_inst.
Proof. unfold Equation1444. intro H. specialize (H F5_0 F5_1). unfold magma_op, refa675_inst, refa675_op in H. discriminate H. Qed.

Lemma refa675_not1451 : ~ @Equation1451 Fin5 refa675_inst.
Proof. unfold Equation1451. intro H. specialize (H F5_0 F5_1). unfold magma_op, refa675_inst, refa675_op in H. discriminate H. Qed.

Lemma refa675_not1479 : ~ @Equation1479 Fin5 refa675_inst.
Proof. unfold Equation1479. intro H. specialize (H F5_0 F5_1). unfold magma_op, refa675_inst, refa675_op in H. discriminate H. Qed.

Lemma refa675_not1632 : ~ @Equation1632 Fin5 refa675_inst.
Proof. unfold Equation1632. intro H. specialize (H F5_0 F5_1). unfold magma_op, refa675_inst, refa675_op in H. discriminate H. Qed.

Lemma refa675_not1645 : ~ @Equation1645 Fin5 refa675_inst.
Proof. unfold Equation1645. intro H. specialize (H F5_0 F5_1). unfold magma_op, refa675_inst, refa675_op in H. discriminate H. Qed.

Lemma refa675_not1654 : ~ @Equation1654 Fin5 refa675_inst.
Proof. unfold Equation1654. intro H. specialize (H F5_0 F5_1). unfold magma_op, refa675_inst, refa675_op in H. discriminate H. Qed.

Lemma refa675_not1691 : ~ @Equation1691 Fin5 refa675_inst.
Proof. unfold Equation1691. intro H. specialize (H F5_0 F5_1). unfold magma_op, refa675_inst, refa675_op in H. discriminate H. Qed.

Lemma refa675_not1722 : ~ @Equation1722 Fin5 refa675_inst.
Proof. unfold Equation1722. intro H. specialize (H F5_0 F5_1). unfold magma_op, refa675_inst, refa675_op in H. discriminate H. Qed.

Lemma refa675_not1838 : ~ @Equation1838 Fin5 refa675_inst.
Proof. unfold Equation1838. intro H. specialize (H F5_0 F5_1). unfold magma_op, refa675_inst, refa675_op in H. discriminate H. Qed.

Lemma refa675_not1840 : ~ @Equation1840 Fin5 refa675_inst.
Proof. unfold Equation1840. intro H. specialize (H F5_0 F5_1). unfold magma_op, refa675_inst, refa675_op in H. discriminate H. Qed.

Lemma refa675_not1887 : ~ @Equation1887 Fin5 refa675_inst.
Proof. unfold Equation1887. intro H. specialize (H F5_0 F5_1). unfold magma_op, refa675_inst, refa675_op in H. discriminate H. Qed.

Lemma refa675_not1921 : ~ @Equation1921 Fin5 refa675_inst.
Proof. unfold Equation1921. intro H. specialize (H F5_0 F5_1). unfold magma_op, refa675_inst, refa675_op in H. discriminate H. Qed.

Lemma refa675_not1925 : ~ @Equation1925 Fin5 refa675_inst.
Proof. unfold Equation1925. intro H. specialize (H F5_0 F5_1). unfold magma_op, refa675_inst, refa675_op in H. discriminate H. Qed.

Lemma refa675_not2043 : ~ @Equation2043 Fin5 refa675_inst.
Proof. unfold Equation2043. intro H. specialize (H F5_0 F5_1). unfold magma_op, refa675_inst, refa675_op in H. discriminate H. Qed.

Lemma refa675_not2053 : ~ @Equation2053 Fin5 refa675_inst.
Proof. unfold Equation2053. intro H. specialize (H F5_0 F5_1). unfold magma_op, refa675_inst, refa675_op in H. discriminate H. Qed.

Lemma refa675_not2060 : ~ @Equation2060 Fin5 refa675_inst.
Proof. unfold Equation2060. intro H. specialize (H F5_0 F5_1). unfold magma_op, refa675_inst, refa675_op in H. discriminate H. Qed.

Lemma refa675_not2064 : ~ @Equation2064 Fin5 refa675_inst.
Proof. unfold Equation2064. intro H. specialize (H F5_0 F5_1). unfold magma_op, refa675_inst, refa675_op in H. discriminate H. Qed.

Lemma refa675_not2088 : ~ @Equation2088 Fin5 refa675_inst.
Proof. unfold Equation2088. intro H. specialize (H F5_0 F5_1). unfold magma_op, refa675_inst, refa675_op in H. discriminate H. Qed.

Lemma refa675_not2137 : ~ @Equation2137 Fin5 refa675_inst.
Proof. unfold Equation2137. intro H. specialize (H F5_0 F5_1). unfold magma_op, refa675_inst, refa675_op in H. discriminate H. Qed.

Lemma refa675_not2241 : ~ @Equation2241 Fin5 refa675_inst.
Proof. unfold Equation2241. intro H. specialize (H F5_0 F5_1). unfold magma_op, refa675_inst, refa675_op in H. discriminate H. Qed.

Lemma refa675_not2244 : ~ @Equation2244 Fin5 refa675_inst.
Proof. unfold Equation2244. intro H. specialize (H F5_0 F5_1). unfold magma_op, refa675_inst, refa675_op in H. discriminate H. Qed.

Lemma refa675_not2254 : ~ @Equation2254 Fin5 refa675_inst.
Proof. unfold Equation2254. intro H. specialize (H F5_0 F5_1). unfold magma_op, refa675_inst, refa675_op in H. discriminate H. Qed.

Lemma refa675_not2263 : ~ @Equation2263 Fin5 refa675_inst.
Proof. unfold Equation2263. intro H. specialize (H F5_0 F5_1). unfold magma_op, refa675_inst, refa675_op in H. discriminate H. Qed.

Lemma refa675_not2267 : ~ @Equation2267 Fin5 refa675_inst.
Proof. unfold Equation2267. intro H. specialize (H F5_0 F5_1). unfold magma_op, refa675_inst, refa675_op in H. discriminate H. Qed.

Lemma refa675_not2293 : ~ @Equation2293 Fin5 refa675_inst.
Proof. unfold Equation2293. intro H. specialize (H F5_0 F5_1). unfold magma_op, refa675_inst, refa675_op in H. discriminate H. Qed.

Lemma refa675_not2338 : ~ @Equation2338 Fin5 refa675_inst.
Proof. unfold Equation2338. intro H. specialize (H F5_0 F5_1). unfold magma_op, refa675_inst, refa675_op in H. discriminate H. Qed.

Lemma refa675_not2444 : ~ @Equation2444 Fin5 refa675_inst.
Proof. unfold Equation2444. intro H. specialize (H F5_0 F5_1). unfold magma_op, refa675_inst, refa675_op in H. discriminate H. Qed.

Lemma refa675_not2447 : ~ @Equation2447 Fin5 refa675_inst.
Proof. unfold Equation2447. intro H. specialize (H F5_0 F5_1). unfold magma_op, refa675_inst, refa675_op in H. discriminate H. Qed.

Lemma refa675_not2449 : ~ @Equation2449 Fin5 refa675_inst.
Proof. unfold Equation2449. intro H. specialize (H F5_0 F5_1). unfold magma_op, refa675_inst, refa675_op in H. discriminate H. Qed.

Lemma refa675_not2470 : ~ @Equation2470 Fin5 refa675_inst.
Proof. unfold Equation2470. intro H. specialize (H F5_0 F5_1). unfold magma_op, refa675_inst, refa675_op in H. discriminate H. Qed.

Lemma refa675_not2530 : ~ @Equation2530 Fin5 refa675_inst.
Proof. unfold Equation2530. intro H. specialize (H F5_0 F5_1). unfold magma_op, refa675_inst, refa675_op in H. discriminate H. Qed.

Lemma refa675_not2647 : ~ @Equation2647 Fin5 refa675_inst.
Proof. unfold Equation2647. intro H. specialize (H F5_0 F5_1). unfold magma_op, refa675_inst, refa675_op in H. discriminate H. Qed.

Lemma refa675_not2660 : ~ @Equation2660 Fin5 refa675_inst.
Proof. unfold Equation2660. intro H. specialize (H F5_0 F5_1). unfold magma_op, refa675_inst, refa675_op in H. discriminate H. Qed.

Lemma refa675_not2669 : ~ @Equation2669 Fin5 refa675_inst.
Proof. unfold Equation2669. intro H. specialize (H F5_0 F5_1). unfold magma_op, refa675_inst, refa675_op in H. discriminate H. Qed.

Lemma refa675_not2699 : ~ @Equation2699 Fin5 refa675_inst.
Proof. unfold Equation2699. intro H. specialize (H F5_0 F5_1). unfold magma_op, refa675_inst, refa675_op in H. discriminate H. Qed.

Lemma refa675_not2853 : ~ @Equation2853 Fin5 refa675_inst.
Proof. unfold Equation2853. intro H. specialize (H F5_0 F5_1). unfold magma_op, refa675_inst, refa675_op in H. discriminate H. Qed.

Lemma refa675_not2855 : ~ @Equation2855 Fin5 refa675_inst.
Proof. unfold Equation2855. intro H. specialize (H F5_0 F5_1). unfold magma_op, refa675_inst, refa675_op in H. discriminate H. Qed.

Lemma refa675_not2936 : ~ @Equation2936 Fin5 refa675_inst.
Proof. unfold Equation2936. intro H. specialize (H F5_0 F5_1). unfold magma_op, refa675_inst, refa675_op in H. discriminate H. Qed.

Lemma refa675_not3075 : ~ @Equation3075 Fin5 refa675_inst.
Proof. unfold Equation3075. intro H. specialize (H F5_0 F5_1). unfold magma_op, refa675_inst, refa675_op in H. discriminate H. Qed.

Lemma refa675_not3079 : ~ @Equation3079 Fin5 refa675_inst.
Proof. unfold Equation3079. intro H. specialize (H F5_0 F5_1). unfold magma_op, refa675_inst, refa675_op in H. discriminate H. Qed.

Lemma refa675_not3103 : ~ @Equation3103 Fin5 refa675_inst.
Proof. unfold Equation3103. intro H. specialize (H F5_0 F5_1). unfold magma_op, refa675_inst, refa675_op in H. discriminate H. Qed.

Lemma refa675_not3105 : ~ @Equation3105 Fin5 refa675_inst.
Proof. unfold Equation3105. intro H. specialize (H F5_0 F5_1). unfold magma_op, refa675_inst, refa675_op in H. discriminate H. Qed.

Lemma refa675_not3116 : ~ @Equation3116 Fin5 refa675_inst.
Proof. unfold Equation3116. intro H. specialize (H F5_0 F5_1). unfold magma_op, refa675_inst, refa675_op in H. discriminate H. Qed.

Lemma refa675_not3143 : ~ @Equation3143 Fin5 refa675_inst.
Proof. unfold Equation3143. intro H. specialize (H F5_0 F5_1). unfold magma_op, refa675_inst, refa675_op in H. discriminate H. Qed.

Lemma refa675_not3261 : ~ @Equation3261 Fin5 refa675_inst.
Proof. unfold Equation3261. intro H. specialize (H F5_0 F5_1). unfold magma_op, refa675_inst, refa675_op in H. discriminate H. Qed.

Lemma refa675_not3269 : ~ @Equation3269 Fin5 refa675_inst.
Proof. unfold Equation3269. intro H. specialize (H F5_0 F5_1). unfold magma_op, refa675_inst, refa675_op in H. discriminate H. Qed.

Lemma refa675_not3306 : ~ @Equation3306 Fin5 refa675_inst.
Proof. unfold Equation3306. intro H. specialize (H F5_0 F5_1). unfold magma_op, refa675_inst, refa675_op in H. discriminate H. Qed.

Lemma refa675_not3342 : ~ @Equation3342 Fin5 refa675_inst.
Proof. unfold Equation3342. intro H. specialize (H F5_0 F5_1). unfold magma_op, refa675_inst, refa675_op in H. discriminate H. Qed.

Lemma refa675_not3346 : ~ @Equation3346 Fin5 refa675_inst.
Proof. unfold Equation3346. intro H. specialize (H F5_0 F5_1). unfold magma_op, refa675_inst, refa675_op in H. discriminate H. Qed.

Lemma refa675_not3353 : ~ @Equation3353 Fin5 refa675_inst.
Proof. unfold Equation3353. intro H. specialize (H F5_0 F5_1). unfold magma_op, refa675_inst, refa675_op in H. discriminate H. Qed.

Lemma refa675_not3355 : ~ @Equation3355 Fin5 refa675_inst.
Proof. unfold Equation3355. intro H. specialize (H F5_0 F5_1). unfold magma_op, refa675_inst, refa675_op in H. discriminate H. Qed.

Lemma refa675_not3459 : ~ @Equation3459 Fin5 refa675_inst.
Proof. unfold Equation3459. intro H. specialize (H F5_0 F5_1). unfold magma_op, refa675_inst, refa675_op in H. discriminate H. Qed.

Lemma refa675_not3481 : ~ @Equation3481 Fin5 refa675_inst.
Proof. unfold Equation3481. intro H. specialize (H F5_0 F5_1). unfold magma_op, refa675_inst, refa675_op in H. discriminate H. Qed.

Lemma refa675_not3518 : ~ @Equation3518 Fin5 refa675_inst.
Proof. unfold Equation3518. intro H. specialize (H F5_0 F5_1). unfold magma_op, refa675_inst, refa675_op in H. discriminate H. Qed.

Lemma refa675_not3545 : ~ @Equation3545 Fin5 refa675_inst.
Proof. unfold Equation3545. intro H. specialize (H F5_0 F5_1). unfold magma_op, refa675_inst, refa675_op in H. discriminate H. Qed.

Lemma refa675_not3556 : ~ @Equation3556 Fin5 refa675_inst.
Proof. unfold Equation3556. intro H. specialize (H F5_0 F5_1). unfold magma_op, refa675_inst, refa675_op in H. discriminate H. Qed.

Lemma refa675_not3558 : ~ @Equation3558 Fin5 refa675_inst.
Proof. unfold Equation3558. intro H. specialize (H F5_0 F5_1). unfold magma_op, refa675_inst, refa675_op in H. discriminate H. Qed.

Lemma refa675_not3667 : ~ @Equation3667 Fin5 refa675_inst.
Proof. unfold Equation3667. intro H. specialize (H F5_0 F5_1). unfold magma_op, refa675_inst, refa675_op in H. discriminate H. Qed.

Lemma refa675_not3675 : ~ @Equation3675 Fin5 refa675_inst.
Proof. unfold Equation3675. intro H. specialize (H F5_0 F5_1). unfold magma_op, refa675_inst, refa675_op in H. discriminate H. Qed.

Lemma refa675_not3714 : ~ @Equation3714 Fin5 refa675_inst.
Proof. unfold Equation3714. intro H. specialize (H F5_0 F5_1). unfold magma_op, refa675_inst, refa675_op in H. discriminate H. Qed.

Lemma refa675_not3748 : ~ @Equation3748 Fin5 refa675_inst.
Proof. unfold Equation3748. intro H. specialize (H F5_0 F5_1). unfold magma_op, refa675_inst, refa675_op in H. discriminate H. Qed.

Lemma refa675_not3752 : ~ @Equation3752 Fin5 refa675_inst.
Proof. unfold Equation3752. intro H. specialize (H F5_0 F5_1). unfold magma_op, refa675_inst, refa675_op in H. discriminate H. Qed.

Lemma refa675_not3761 : ~ @Equation3761 Fin5 refa675_inst.
Proof. unfold Equation3761. intro H. specialize (H F5_0 F5_1). unfold magma_op, refa675_inst, refa675_op in H. discriminate H. Qed.

Lemma refa675_not3865 : ~ @Equation3865 Fin5 refa675_inst.
Proof. unfold Equation3865. intro H. specialize (H F5_0 F5_1). unfold magma_op, refa675_inst, refa675_op in H. discriminate H. Qed.

Lemma refa675_not3887 : ~ @Equation3887 Fin5 refa675_inst.
Proof. unfold Equation3887. intro H. specialize (H F5_0 F5_1). unfold magma_op, refa675_inst, refa675_op in H. discriminate H. Qed.

Lemma refa675_not3924 : ~ @Equation3924 Fin5 refa675_inst.
Proof. unfold Equation3924. intro H. specialize (H F5_0 F5_1). unfold magma_op, refa675_inst, refa675_op in H. discriminate H. Qed.

Lemma refa675_not3951 : ~ @Equation3951 Fin5 refa675_inst.
Proof. unfold Equation3951. intro H. specialize (H F5_0 F5_1). unfold magma_op, refa675_inst, refa675_op in H. discriminate H. Qed.

Lemma refa675_not3962 : ~ @Equation3962 Fin5 refa675_inst.
Proof. unfold Equation3962. intro H. specialize (H F5_0 F5_1). unfold magma_op, refa675_inst, refa675_op in H. discriminate H. Qed.

Lemma refa675_not3964 : ~ @Equation3964 Fin5 refa675_inst.
Proof. unfold Equation3964. intro H. specialize (H F5_0 F5_1). unfold magma_op, refa675_inst, refa675_op in H. discriminate H. Qed.

Lemma refa675_not4073 : ~ @Equation4073 Fin5 refa675_inst.
Proof. unfold Equation4073. intro H. specialize (H F5_0 F5_1). unfold magma_op, refa675_inst, refa675_op in H. discriminate H. Qed.

Lemma refa675_not4081 : ~ @Equation4081 Fin5 refa675_inst.
Proof. unfold Equation4081. intro H. specialize (H F5_0 F5_1). unfold magma_op, refa675_inst, refa675_op in H. discriminate H. Qed.

Lemma refa675_not4120 : ~ @Equation4120 Fin5 refa675_inst.
Proof. unfold Equation4120. intro H. specialize (H F5_0 F5_1). unfold magma_op, refa675_inst, refa675_op in H. discriminate H. Qed.

Lemma refa675_not4127 : ~ @Equation4127 Fin5 refa675_inst.
Proof. unfold Equation4127. intro H. specialize (H F5_0 F5_1). unfold magma_op, refa675_inst, refa675_op in H. discriminate H. Qed.

Lemma refa675_not4131 : ~ @Equation4131 Fin5 refa675_inst.
Proof. unfold Equation4131. intro H. specialize (H F5_0 F5_1). unfold magma_op, refa675_inst, refa675_op in H. discriminate H. Qed.

Lemma refa675_not4154 : ~ @Equation4154 Fin5 refa675_inst.
Proof. unfold Equation4154. intro H. specialize (H F5_0 F5_1). unfold magma_op, refa675_inst, refa675_op in H. discriminate H. Qed.

Lemma refa675_not4167 : ~ @Equation4167 Fin5 refa675_inst.
Proof. unfold Equation4167. intro H. specialize (H F5_0 F5_1). unfold magma_op, refa675_inst, refa675_op in H. discriminate H. Qed.

Lemma refa675_not4275 : ~ @Equation4275 Fin5 refa675_inst.
Proof. unfold Equation4275. intro H. specialize (H F5_0 F5_1). unfold magma_op, refa675_inst, refa675_op in H. discriminate H. Qed.

Lemma refa675_not4283 : ~ @Equation4283 Fin5 refa675_inst.
Proof. unfold Equation4283. intro H. specialize (H F5_0 F5_1). unfold magma_op, refa675_inst, refa675_op in H. discriminate H. Qed.

Lemma refa675_not4290 : ~ @Equation4290 Fin5 refa675_inst.
Proof. unfold Equation4290. intro H. specialize (H F5_0 F5_1). unfold magma_op, refa675_inst, refa675_op in H. discriminate H. Qed.

Lemma refa675_not4362 : ~ @Equation4362 Fin5 refa675_inst.
Proof. unfold Equation4362. intro H. specialize (H F5_0 F5_1 F5_2). unfold magma_op, refa675_inst, refa675_op in H. discriminate H. Qed.

Lemma refa675_not4396 : ~ @Equation4396 Fin5 refa675_inst.
Proof. unfold Equation4396. intro H. specialize (H F5_0 F5_1). unfold magma_op, refa675_inst, refa675_op in H. discriminate H. Qed.

Lemma refa675_not4398 : ~ @Equation4398 Fin5 refa675_inst.
Proof. unfold Equation4398. intro H. specialize (H F5_0 F5_1). unfold magma_op, refa675_inst, refa675_op in H. discriminate H. Qed.

Lemma refa675_not4405 : ~ @Equation4405 Fin5 refa675_inst.
Proof. unfold Equation4405. intro H. specialize (H F5_0 F5_1). unfold magma_op, refa675_inst, refa675_op in H. discriminate H. Qed.

Lemma refa675_not4442 : ~ @Equation4442 Fin5 refa675_inst.
Proof. unfold Equation4442. intro H. specialize (H F5_0 F5_1). unfold magma_op, refa675_inst, refa675_op in H. discriminate H. Qed.

Lemma refa675_not4473 : ~ @Equation4473 Fin5 refa675_inst.
Proof. unfold Equation4473. intro H. specialize (H F5_0 F5_1). unfold magma_op, refa675_inst, refa675_op in H. discriminate H. Qed.

Lemma refa675_not4585 : ~ @Equation4585 Fin5 refa675_inst.
Proof. unfold Equation4585. intro H. specialize (H F5_0 F5_1). unfold magma_op, refa675_inst, refa675_op in H. discriminate H. Qed.

Lemma refa675_not4605 : ~ @Equation4605 Fin5 refa675_inst.
Proof. unfold Equation4605. intro H. specialize (H F5_0 F5_1). unfold magma_op, refa675_inst, refa675_op in H. discriminate H. Qed.

Lemma refa675_not4635 : ~ @Equation4635 Fin5 refa675_inst.
Proof. unfold Equation4635. intro H. specialize (H F5_0 F5_1). unfold magma_op, refa675_inst, refa675_op in H. discriminate H. Qed.

Lemma refa675_not4673 : ~ @Equation4673 Fin5 refa675_inst.
Proof. unfold Equation4673. intro H. specialize (H F5_0 F5_1 F5_2). unfold magma_op, refa675_inst, refa675_op in H. discriminate H. Qed.

(** ---- refa676 (Fin6) ---- *)

Definition refa676_op (x y : Fin6) : Fin6 :=
  match x, y with
  | F6_0, F6_0 => F6_1 | F6_0, F6_1 => F6_5 | F6_0, F6_2 => F6_5 | F6_0, F6_3 => F6_2 | F6_0, F6_4 => F6_0 | F6_0, F6_5 => F6_0
  | F6_1, F6_0 => F6_2 | F6_1, F6_1 => F6_5 | F6_1, F6_2 => F6_4 | F6_1, F6_3 => F6_1 | F6_1, F6_4 => F6_0 | F6_1, F6_5 => F6_0
  | F6_2, F6_0 => F6_2 | F6_2, F6_1 => F6_4 | F6_2, F6_2 => F6_4 | F6_2, F6_3 => F6_1 | F6_2, F6_4 => F6_3 | F6_2, F6_5 => F6_3
  | F6_3, F6_0 => F6_2 | F6_3, F6_1 => F6_4 | F6_3, F6_2 => F6_4 | F6_3, F6_3 => F6_2 | F6_3, F6_4 => F6_0 | F6_3, F6_5 => F6_0
  | F6_4, F6_0 => F6_2 | F6_4, F6_1 => F6_4 | F6_4, F6_2 => F6_4 | F6_4, F6_3 => F6_2 | F6_4, F6_4 => F6_3 | F6_4, F6_5 => F6_0
  | F6_5, F6_0 => F6_1 | F6_5, F6_1 => F6_4 | F6_5, F6_2 => F6_4 | F6_5, F6_3 => F6_1 | F6_5, F6_4 => F6_0 | F6_5, F6_5 => F6_0
  end.

#[local] Instance refa676_inst : Magma Fin6 := {| magma_op := refa676_op |}.

Lemma refa676_sat1437 : @Equation1437 Fin6 refa676_inst.
Proof. unfold Equation1437, magma_op, refa676_inst, refa676_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa676_not4065 : ~ @Equation4065 Fin6 refa676_inst.
Proof. unfold Equation4065. intro H. specialize (H F6_0). unfold magma_op, refa676_inst, refa676_op in H. discriminate H. Qed.

(** ---- refa677 (Fin5) ---- *)

Definition refa677_op (x y : Fin5) : Fin5 :=
  match x, y with
  | F5_0, F5_0 => F5_2 | F5_0, F5_1 => F5_2 | F5_0, F5_2 => F5_4 | F5_0, F5_3 => F5_2 | F5_0, F5_4 => F5_4
  | F5_1, F5_0 => F5_3 | F5_1, F5_1 => F5_3 | F5_1, F5_2 => F5_3 | F5_1, F5_3 => F5_3 | F5_1, F5_4 => F5_3
  | F5_2, F5_0 => F5_0 | F5_2, F5_1 => F5_0 | F5_2, F5_2 => F5_4 | F5_2, F5_3 => F5_4 | F5_2, F5_4 => F5_0
  | F5_3, F5_0 => F5_4 | F5_3, F5_1 => F5_1 | F5_3, F5_2 => F5_4 | F5_3, F5_3 => F5_1 | F5_3, F5_4 => F5_1
  | F5_4, F5_0 => F5_2 | F5_4, F5_1 => F5_3 | F5_4, F5_2 => F5_2 | F5_4, F5_3 => F5_2 | F5_4, F5_4 => F5_0
  end.

#[local] Instance refa677_inst : Magma Fin5 := {| magma_op := refa677_op |}.

Lemma refa677_sat1443 : @Equation1443 Fin5 refa677_inst.
Proof. unfold Equation1443, magma_op, refa677_inst, refa677_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa677_not3521 : ~ @Equation3521 Fin5 refa677_inst.
Proof. unfold Equation3521. intro H. specialize (H F5_0 F5_1). unfold magma_op, refa677_inst, refa677_op in H. discriminate H. Qed.

Lemma refa677_not4131 : ~ @Equation4131 Fin5 refa677_inst.
Proof. unfold Equation4131. intro H. specialize (H F5_1 F5_0). unfold magma_op, refa677_inst, refa677_op in H. discriminate H. Qed.

(** ---- refa678 (Fin6) ---- *)

Definition refa678_op (x y : Fin6) : Fin6 :=
  match x, y with
  | F6_0, F6_0 => F6_1 | F6_0, F6_1 => F6_5 | F6_0, F6_2 => F6_1 | F6_0, F6_3 => F6_5 | F6_0, F6_4 => F6_1 | F6_0, F6_5 => F6_5
  | F6_1, F6_0 => F6_2 | F6_1, F6_1 => F6_0 | F6_1, F6_2 => F6_2 | F6_1, F6_3 => F6_0 | F6_1, F6_4 => F6_2 | F6_1, F6_5 => F6_0
  | F6_2, F6_0 => F6_3 | F6_2, F6_1 => F6_1 | F6_2, F6_2 => F6_3 | F6_2, F6_3 => F6_1 | F6_2, F6_4 => F6_3 | F6_2, F6_5 => F6_1
  | F6_3, F6_0 => F6_4 | F6_3, F6_1 => F6_2 | F6_3, F6_2 => F6_4 | F6_3, F6_3 => F6_2 | F6_3, F6_4 => F6_4 | F6_3, F6_5 => F6_2
  | F6_4, F6_0 => F6_5 | F6_4, F6_1 => F6_3 | F6_4, F6_2 => F6_5 | F6_4, F6_3 => F6_3 | F6_4, F6_4 => F6_5 | F6_4, F6_5 => F6_3
  | F6_5, F6_0 => F6_0 | F6_5, F6_1 => F6_4 | F6_5, F6_2 => F6_0 | F6_5, F6_3 => F6_4 | F6_5, F6_4 => F6_0 | F6_5, F6_5 => F6_4
  end.

#[local] Instance refa678_inst : Magma Fin6 := {| magma_op := refa678_op |}.

Lemma refa678_sat161 : @Equation161 Fin6 refa678_inst.
Proof. unfold Equation161, magma_op, refa678_inst, refa678_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa678_not3050 : ~ @Equation3050 Fin6 refa678_inst.
Proof. unfold Equation3050. intro H. specialize (H F6_0). unfold magma_op, refa678_inst, refa678_op in H. discriminate H. Qed.

Lemma refa678_not4585 : ~ @Equation4585 Fin6 refa678_inst.
Proof. unfold Equation4585. intro H. specialize (H F6_0 F6_1). unfold magma_op, refa678_inst, refa678_op in H. discriminate H. Qed.

(** ---- refa679 (Fin6) ---- *)

Definition refa679_op (x y : Fin6) : Fin6 :=
  match x, y with
  | F6_0, F6_0 => F6_2 | F6_0, F6_1 => F6_2 | F6_0, F6_2 => F6_2 | F6_0, F6_3 => F6_4 | F6_0, F6_4 => F6_4 | F6_0, F6_5 => F6_4
  | F6_1, F6_0 => F6_3 | F6_1, F6_1 => F6_1 | F6_1, F6_2 => F6_1 | F6_1, F6_3 => F6_3 | F6_1, F6_4 => F6_3 | F6_1, F6_5 => F6_1
  | F6_2, F6_0 => F6_0 | F6_2, F6_1 => F6_5 | F6_2, F6_2 => F6_0 | F6_2, F6_3 => F6_0 | F6_2, F6_4 => F6_5 | F6_2, F6_5 => F6_5
  | F6_3, F6_0 => F6_3 | F6_3, F6_1 => F6_1 | F6_3, F6_2 => F6_1 | F6_3, F6_3 => F6_3 | F6_3, F6_4 => F6_3 | F6_3, F6_5 => F6_1
  | F6_4, F6_0 => F6_0 | F6_4, F6_1 => F6_5 | F6_4, F6_2 => F6_0 | F6_4, F6_3 => F6_0 | F6_4, F6_4 => F6_5 | F6_4, F6_5 => F6_5
  | F6_5, F6_0 => F6_2 | F6_5, F6_1 => F6_2 | F6_5, F6_2 => F6_2 | F6_5, F6_3 => F6_4 | F6_5, F6_4 => F6_4 | F6_5, F6_5 => F6_4
  end.

#[local] Instance refa679_inst : Magma Fin6 := {| magma_op := refa679_op |}.

Lemma refa679_sat1469 : @Equation1469 Fin6 refa679_inst.
Proof. unfold Equation1469, magma_op, refa679_inst, refa679_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa679_not1428 : ~ @Equation1428 Fin6 refa679_inst.
Proof. unfold Equation1428. intro H. specialize (H F6_0 F6_1). unfold magma_op, refa679_inst, refa679_op in H. discriminate H. Qed.

Lemma refa679_not1431 : ~ @Equation1431 Fin6 refa679_inst.
Proof. unfold Equation1431. intro H. specialize (H F6_0 F6_1). unfold magma_op, refa679_inst, refa679_op in H. discriminate H. Qed.

Lemma refa679_not1444 : ~ @Equation1444 Fin6 refa679_inst.
Proof. unfold Equation1444. intro H. specialize (H F6_0 F6_1). unfold magma_op, refa679_inst, refa679_op in H. discriminate H. Qed.

Lemma refa679_not1451 : ~ @Equation1451 Fin6 refa679_inst.
Proof. unfold Equation1451. intro H. specialize (H F6_0 F6_1). unfold magma_op, refa679_inst, refa679_op in H. discriminate H. Qed.

Lemma refa679_not4269 : ~ @Equation4269 Fin6 refa679_inst.
Proof. unfold Equation4269. intro H. specialize (H F6_0 F6_1). unfold magma_op, refa679_inst, refa679_op in H. discriminate H. Qed.

Lemma refa679_not4284 : ~ @Equation4284 Fin6 refa679_inst.
Proof. unfold Equation4284. intro H. specialize (H F6_1 F6_0). unfold magma_op, refa679_inst, refa679_op in H. discriminate H. Qed.

(** ---- refa68 (Fin3) ---- *)

Definition refa68_op (x y : Fin3) : Fin3 :=
  match x, y with
  | F3_0, F3_0 => F3_0 | F3_0, F3_1 => F3_1 | F3_0, F3_2 => F3_2
  | F3_1, F3_0 => F3_1 | F3_1, F3_1 => F3_0 | F3_1, F3_2 => F3_1
  | F3_2, F3_0 => F3_2 | F3_2, F3_1 => F3_0 | F3_2, F3_2 => F3_1
  end.

#[local] Instance refa68_inst : Magma Fin3 := {| magma_op := refa68_op |}.

Lemma refa68_sat643 : @Equation643 Fin3 refa68_inst.
Proof. unfold Equation643, magma_op, refa68_inst, refa68_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa68_sat846 : @Equation846 Fin3 refa68_inst.
Proof. unfold Equation846, magma_op, refa68_inst, refa68_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa68_sat2543 : @Equation2543 Fin3 refa68_inst.
Proof. unfold Equation2543, magma_op, refa68_inst, refa68_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa68_sat2746 : @Equation2746 Fin3 refa68_inst.
Proof. unfold Equation2746, magma_op, refa68_inst, refa68_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa68_not43 : ~ @Equation43 Fin3 refa68_inst.
Proof. unfold Equation43. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa68_inst, refa68_op in H. discriminate H. Qed.

Lemma refa68_not99 : ~ @Equation99 Fin3 refa68_inst.
Proof. unfold Equation99. intro H. specialize (H F3_1). unfold magma_op, refa68_inst, refa68_op in H. discriminate H. Qed.

Lemma refa68_not359 : ~ @Equation359 Fin3 refa68_inst.
Proof. unfold Equation359. intro H. specialize (H F3_1). unfold magma_op, refa68_inst, refa68_op in H. discriminate H. Qed.

Lemma refa68_not411 : ~ @Equation411 Fin3 refa68_inst.
Proof. unfold Equation411. intro H. specialize (H F3_2). unfold magma_op, refa68_inst, refa68_op in H. discriminate H. Qed.

Lemma refa68_not620 : ~ @Equation620 Fin3 refa68_inst.
Proof. unfold Equation620. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa68_inst, refa68_op in H. discriminate H. Qed.

Lemma refa68_not622 : ~ @Equation622 Fin3 refa68_inst.
Proof. unfold Equation622. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa68_inst, refa68_op in H. discriminate H. Qed.

Lemma refa68_not630 : ~ @Equation630 Fin3 refa68_inst.
Proof. unfold Equation630. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa68_inst, refa68_op in H. discriminate H. Qed.

Lemma refa68_not632 : ~ @Equation632 Fin3 refa68_inst.
Proof. unfold Equation632. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa68_inst, refa68_op in H. discriminate H. Qed.

Lemma refa68_not639 : ~ @Equation639 Fin3 refa68_inst.
Proof. unfold Equation639. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa68_inst, refa68_op in H. discriminate H. Qed.

Lemma refa68_not667 : ~ @Equation667 Fin3 refa68_inst.
Proof. unfold Equation667. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa68_inst, refa68_op in H. discriminate H. Qed.

Lemma refa68_not669 : ~ @Equation669 Fin3 refa68_inst.
Proof. unfold Equation669. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa68_inst, refa68_op in H. discriminate H. Qed.

Lemma refa68_not676 : ~ @Equation676 Fin3 refa68_inst.
Proof. unfold Equation676. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa68_inst, refa68_op in H. discriminate H. Qed.

Lemma refa68_not680 : ~ @Equation680 Fin3 refa68_inst.
Proof. unfold Equation680. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa68_inst, refa68_op in H. discriminate H. Qed.

Lemma refa68_not707 : ~ @Equation707 Fin3 refa68_inst.
Proof. unfold Equation707. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa68_inst, refa68_op in H. discriminate H. Qed.

Lemma refa68_not819 : ~ @Equation819 Fin3 refa68_inst.
Proof. unfold Equation819. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa68_inst, refa68_op in H. discriminate H. Qed.

Lemma refa68_not825 : ~ @Equation825 Fin3 refa68_inst.
Proof. unfold Equation825. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa68_inst, refa68_op in H. discriminate H. Qed.

Lemma refa68_not832 : ~ @Equation832 Fin3 refa68_inst.
Proof. unfold Equation832. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa68_inst, refa68_op in H. discriminate H. Qed.

Lemma refa68_not833 : ~ @Equation833 Fin3 refa68_inst.
Proof. unfold Equation833. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa68_inst, refa68_op in H. discriminate H. Qed.

Lemma refa68_not835 : ~ @Equation835 Fin3 refa68_inst.
Proof. unfold Equation835. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa68_inst, refa68_op in H. discriminate H. Qed.

Lemma refa68_not836 : ~ @Equation836 Fin3 refa68_inst.
Proof. unfold Equation836. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa68_inst, refa68_op in H. discriminate H. Qed.

Lemma refa68_not842 : ~ @Equation842 Fin3 refa68_inst.
Proof. unfold Equation842. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa68_inst, refa68_op in H. discriminate H. Qed.

Lemma refa68_not843 : ~ @Equation843 Fin3 refa68_inst.
Proof. unfold Equation843. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa68_inst, refa68_op in H. discriminate H. Qed.

Lemma refa68_not845 : ~ @Equation845 Fin3 refa68_inst.
Proof. unfold Equation845. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa68_inst, refa68_op in H. discriminate H. Qed.

Lemma refa68_not870 : ~ @Equation870 Fin3 refa68_inst.
Proof. unfold Equation870. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa68_inst, refa68_op in H. discriminate H. Qed.

Lemma refa68_not872 : ~ @Equation872 Fin3 refa68_inst.
Proof. unfold Equation872. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa68_inst, refa68_op in H. discriminate H. Qed.

Lemma refa68_not879 : ~ @Equation879 Fin3 refa68_inst.
Proof. unfold Equation879. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa68_inst, refa68_op in H. discriminate H. Qed.

Lemma refa68_not883 : ~ @Equation883 Fin3 refa68_inst.
Proof. unfold Equation883. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa68_inst, refa68_op in H. discriminate H. Qed.

Lemma refa68_not906 : ~ @Equation906 Fin3 refa68_inst.
Proof. unfold Equation906. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa68_inst, refa68_op in H. discriminate H. Qed.

Lemma refa68_not917 : ~ @Equation917 Fin3 refa68_inst.
Proof. unfold Equation917. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa68_inst, refa68_op in H. discriminate H. Qed.

Lemma refa68_not1020 : ~ @Equation1020 Fin3 refa68_inst.
Proof. unfold Equation1020. intro H. specialize (H F3_2). unfold magma_op, refa68_inst, refa68_op in H. discriminate H. Qed.

Lemma refa68_not1223 : ~ @Equation1223 Fin3 refa68_inst.
Proof. unfold Equation1223. intro H. specialize (H F3_2). unfold magma_op, refa68_inst, refa68_op in H. discriminate H. Qed.

Lemma refa68_not1426 : ~ @Equation1426 Fin3 refa68_inst.
Proof. unfold Equation1426. intro H. specialize (H F3_2). unfold magma_op, refa68_inst, refa68_op in H. discriminate H. Qed.

Lemma refa68_not1629 : ~ @Equation1629 Fin3 refa68_inst.
Proof. unfold Equation1629. intro H. specialize (H F3_2). unfold magma_op, refa68_inst, refa68_op in H. discriminate H. Qed.

Lemma refa68_not1832 : ~ @Equation1832 Fin3 refa68_inst.
Proof. unfold Equation1832. intro H. specialize (H F3_2). unfold magma_op, refa68_inst, refa68_op in H. discriminate H. Qed.

Lemma refa68_not2035 : ~ @Equation2035 Fin3 refa68_inst.
Proof. unfold Equation2035. intro H. specialize (H F3_2). unfold magma_op, refa68_inst, refa68_op in H. discriminate H. Qed.

Lemma refa68_not2238 : ~ @Equation2238 Fin3 refa68_inst.
Proof. unfold Equation2238. intro H. specialize (H F3_2). unfold magma_op, refa68_inst, refa68_op in H. discriminate H. Qed.

Lemma refa68_not2444 : ~ @Equation2444 Fin3 refa68_inst.
Proof. unfold Equation2444. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa68_inst, refa68_op in H. discriminate H. Qed.

Lemma refa68_not2449 : ~ @Equation2449 Fin3 refa68_inst.
Proof. unfold Equation2449. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa68_inst, refa68_op in H. discriminate H. Qed.

Lemma refa68_not2457 : ~ @Equation2457 Fin3 refa68_inst.
Proof. unfold Equation2457. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa68_inst, refa68_op in H. discriminate H. Qed.

Lemma refa68_not2459 : ~ @Equation2459 Fin3 refa68_inst.
Proof. unfold Equation2459. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa68_inst, refa68_op in H. discriminate H. Qed.

Lemma refa68_not2466 : ~ @Equation2466 Fin3 refa68_inst.
Proof. unfold Equation2466. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa68_inst, refa68_op in H. discriminate H. Qed.

Lemma refa68_not2496 : ~ @Equation2496 Fin3 refa68_inst.
Proof. unfold Equation2496. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa68_inst, refa68_op in H. discriminate H. Qed.

Lemma refa68_not2530 : ~ @Equation2530 Fin3 refa68_inst.
Proof. unfold Equation2530. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa68_inst, refa68_op in H. discriminate H. Qed.

Lemma refa68_not2534 : ~ @Equation2534 Fin3 refa68_inst.
Proof. unfold Equation2534. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa68_inst, refa68_op in H. discriminate H. Qed.

Lemma refa68_not2541 : ~ @Equation2541 Fin3 refa68_inst.
Proof. unfold Equation2541. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa68_inst, refa68_op in H. discriminate H. Qed.

Lemma refa68_not2647 : ~ @Equation2647 Fin3 refa68_inst.
Proof. unfold Equation2647. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa68_inst, refa68_op in H. discriminate H. Qed.

Lemma refa68_not2650 : ~ @Equation2650 Fin3 refa68_inst.
Proof. unfold Equation2650. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa68_inst, refa68_op in H. discriminate H. Qed.

Lemma refa68_not2652 : ~ @Equation2652 Fin3 refa68_inst.
Proof. unfold Equation2652. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa68_inst, refa68_op in H. discriminate H. Qed.

Lemma refa68_not2660 : ~ @Equation2660 Fin3 refa68_inst.
Proof. unfold Equation2660. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa68_inst, refa68_op in H. discriminate H. Qed.

Lemma refa68_not2662 : ~ @Equation2662 Fin3 refa68_inst.
Proof. unfold Equation2662. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa68_inst, refa68_op in H. discriminate H. Qed.

Lemma refa68_not2669 : ~ @Equation2669 Fin3 refa68_inst.
Proof. unfold Equation2669. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa68_inst, refa68_op in H. discriminate H. Qed.

Lemma refa68_not2697 : ~ @Equation2697 Fin3 refa68_inst.
Proof. unfold Equation2697. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa68_inst, refa68_op in H. discriminate H. Qed.

Lemma refa68_not2699 : ~ @Equation2699 Fin3 refa68_inst.
Proof. unfold Equation2699. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa68_inst, refa68_op in H. discriminate H. Qed.

Lemma refa68_not2710 : ~ @Equation2710 Fin3 refa68_inst.
Proof. unfold Equation2710. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa68_inst, refa68_op in H. discriminate H. Qed.

Lemma refa68_not2744 : ~ @Equation2744 Fin3 refa68_inst.
Proof. unfold Equation2744. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa68_inst, refa68_op in H. discriminate H. Qed.

Lemma refa68_not2847 : ~ @Equation2847 Fin3 refa68_inst.
Proof. unfold Equation2847. intro H. specialize (H F3_2). unfold magma_op, refa68_inst, refa68_op in H. discriminate H. Qed.

Lemma refa68_not3050 : ~ @Equation3050 Fin3 refa68_inst.
Proof. unfold Equation3050. intro H. specialize (H F3_2). unfold magma_op, refa68_inst, refa68_op in H. discriminate H. Qed.

Lemma refa68_not3253 : ~ @Equation3253 Fin3 refa68_inst.
Proof. unfold Equation3253. intro H. specialize (H F3_2). unfold magma_op, refa68_inst, refa68_op in H. discriminate H. Qed.

Lemma refa68_not3456 : ~ @Equation3456 Fin3 refa68_inst.
Proof. unfold Equation3456. intro H. specialize (H F3_2). unfold magma_op, refa68_inst, refa68_op in H. discriminate H. Qed.

Lemma refa68_not3659 : ~ @Equation3659 Fin3 refa68_inst.
Proof. unfold Equation3659. intro H. specialize (H F3_2). unfold magma_op, refa68_inst, refa68_op in H. discriminate H. Qed.

Lemma refa68_not3862 : ~ @Equation3862 Fin3 refa68_inst.
Proof. unfold Equation3862. intro H. specialize (H F3_2). unfold magma_op, refa68_inst, refa68_op in H. discriminate H. Qed.

Lemma refa68_not4066 : ~ @Equation4066 Fin3 refa68_inst.
Proof. unfold Equation4066. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa68_inst, refa68_op in H. discriminate H. Qed.

Lemma refa68_not4067 : ~ @Equation4067 Fin3 refa68_inst.
Proof. unfold Equation4067. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa68_inst, refa68_op in H. discriminate H. Qed.

Lemma refa68_not4071 : ~ @Equation4071 Fin3 refa68_inst.
Proof. unfold Equation4071. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa68_inst, refa68_op in H. discriminate H. Qed.

Lemma refa68_not4090 : ~ @Equation4090 Fin3 refa68_inst.
Proof. unfold Equation4090. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa68_inst, refa68_op in H. discriminate H. Qed.

Lemma refa68_not4120 : ~ @Equation4120 Fin3 refa68_inst.
Proof. unfold Equation4120. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa68_inst, refa68_op in H. discriminate H. Qed.

Lemma refa68_not4165 : ~ @Equation4165 Fin3 refa68_inst.
Proof. unfold Equation4165. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa68_inst, refa68_op in H. discriminate H. Qed.

Lemma refa68_not4270 : ~ @Equation4270 Fin3 refa68_inst.
Proof. unfold Equation4270. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa68_inst, refa68_op in H. discriminate H. Qed.

Lemma refa68_not4290 : ~ @Equation4290 Fin3 refa68_inst.
Proof. unfold Equation4290. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa68_inst, refa68_op in H. discriminate H. Qed.

Lemma refa68_not4293 : ~ @Equation4293 Fin3 refa68_inst.
Proof. unfold Equation4293. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa68_inst, refa68_op in H. discriminate H. Qed.

Lemma refa68_not4320 : ~ @Equation4320 Fin3 refa68_inst.
Proof. unfold Equation4320. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa68_inst, refa68_op in H. discriminate H. Qed.

Lemma refa68_not4396 : ~ @Equation4396 Fin3 refa68_inst.
Proof. unfold Equation4396. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa68_inst, refa68_op in H. discriminate H. Qed.

Lemma refa68_not4433 : ~ @Equation4433 Fin3 refa68_inst.
Proof. unfold Equation4433. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa68_inst, refa68_op in H. discriminate H. Qed.

Lemma refa68_not4473 : ~ @Equation4473 Fin3 refa68_inst.
Proof. unfold Equation4473. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa68_inst, refa68_op in H. discriminate H. Qed.

Lemma refa68_not4480 : ~ @Equation4480 Fin3 refa68_inst.
Proof. unfold Equation4480. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa68_inst, refa68_op in H. discriminate H. Qed.

Lemma refa68_not4583 : ~ @Equation4583 Fin3 refa68_inst.
Proof. unfold Equation4583. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa68_inst, refa68_op in H. discriminate H. Qed.

Lemma refa68_not4590 : ~ @Equation4590 Fin3 refa68_inst.
Proof. unfold Equation4590. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa68_inst, refa68_op in H. discriminate H. Qed.

Lemma refa68_not4598 : ~ @Equation4598 Fin3 refa68_inst.
Proof. unfold Equation4598. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa68_inst, refa68_op in H. discriminate H. Qed.

Lemma refa68_not4605 : ~ @Equation4605 Fin3 refa68_inst.
Proof. unfold Equation4605. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa68_inst, refa68_op in H. discriminate H. Qed.

Lemma refa68_not4608 : ~ @Equation4608 Fin3 refa68_inst.
Proof. unfold Equation4608. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa68_inst, refa68_op in H. discriminate H. Qed.

Lemma refa68_not4636 : ~ @Equation4636 Fin3 refa68_inst.
Proof. unfold Equation4636. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa68_inst, refa68_op in H. discriminate H. Qed.

(** ---- refa680 (Fin6) ---- *)

Definition refa680_op (x y : Fin6) : Fin6 :=
  match x, y with
  | F6_0, F6_0 => F6_2 | F6_0, F6_1 => F6_0 | F6_0, F6_2 => F6_4 | F6_0, F6_3 => F6_4 | F6_0, F6_4 => F6_0 | F6_0, F6_5 => F6_2
  | F6_1, F6_0 => F6_2 | F6_1, F6_1 => F6_5 | F6_1, F6_2 => F6_1 | F6_1, F6_3 => F6_1 | F6_1, F6_4 => F6_5 | F6_1, F6_5 => F6_2
  | F6_2, F6_0 => F6_3 | F6_2, F6_1 => F6_0 | F6_2, F6_2 => F6_1 | F6_2, F6_3 => F6_1 | F6_2, F6_4 => F6_0 | F6_2, F6_5 => F6_3
  | F6_3, F6_0 => F6_2 | F6_3, F6_1 => F6_5 | F6_3, F6_2 => F6_4 | F6_3, F6_3 => F6_4 | F6_3, F6_4 => F6_5 | F6_3, F6_5 => F6_2
  | F6_4, F6_0 => F6_3 | F6_4, F6_1 => F6_0 | F6_4, F6_2 => F6_4 | F6_4, F6_3 => F6_4 | F6_4, F6_4 => F6_0 | F6_4, F6_5 => F6_3
  | F6_5, F6_0 => F6_3 | F6_5, F6_1 => F6_5 | F6_5, F6_2 => F6_1 | F6_5, F6_3 => F6_1 | F6_5, F6_4 => F6_5 | F6_5, F6_5 => F6_3
  end.

#[local] Instance refa680_inst : Magma Fin6 := {| magma_op := refa680_op |}.

Lemma refa680_sat1465 : @Equation1465 Fin6 refa680_inst.
Proof. unfold Equation1465, magma_op, refa680_inst, refa680_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa680_not4070 : ~ @Equation4070 Fin6 refa680_inst.
Proof. unfold Equation4070. intro H. specialize (H F6_0 F6_1). unfold magma_op, refa680_inst, refa680_op in H. discriminate H. Qed.

Lemma refa680_not4073 : ~ @Equation4073 Fin6 refa680_inst.
Proof. unfold Equation4073. intro H. specialize (H F6_0 F6_2). unfold magma_op, refa680_inst, refa680_op in H. discriminate H. Qed.

Lemma refa680_not4118 : ~ @Equation4118 Fin6 refa680_inst.
Proof. unfold Equation4118. intro H. specialize (H F6_0 F6_1). unfold magma_op, refa680_inst, refa680_op in H. discriminate H. Qed.

Lemma refa680_not4121 : ~ @Equation4121 Fin6 refa680_inst.
Proof. unfold Equation4121. intro H. specialize (H F6_0 F6_2). unfold magma_op, refa680_inst, refa680_op in H. discriminate H. Qed.

Lemma refa680_not4599 : ~ @Equation4599 Fin6 refa680_inst.
Proof. unfold Equation4599. intro H. specialize (H F6_0 F6_2). unfold magma_op, refa680_inst, refa680_op in H. discriminate H. Qed.

Lemma refa680_not4631 : ~ @Equation4631 Fin6 refa680_inst.
Proof. unfold Equation4631. intro H. specialize (H F6_0 F6_0 F6_1). unfold magma_op, refa680_inst, refa680_op in H. discriminate H. Qed.

(** ---- refa681 (Fin5) ---- *)

Definition refa681_op (x y : Fin5) : Fin5 :=
  match x, y with
  | F5_0, F5_0 => F5_0 | F5_0, F5_1 => F5_1 | F5_0, F5_2 => F5_4 | F5_0, F5_3 => F5_4 | F5_0, F5_4 => F5_0
  | F5_1, F5_0 => F5_2 | F5_1, F5_1 => F5_1 | F5_1, F5_2 => F5_4 | F5_1, F5_3 => F5_4 | F5_1, F5_4 => F5_1
  | F5_2, F5_0 => F5_0 | F5_2, F5_1 => F5_3 | F5_2, F5_2 => F5_4 | F5_2, F5_3 => F5_4 | F5_2, F5_4 => F5_0
  | F5_3, F5_0 => F5_0 | F5_3, F5_1 => F5_1 | F5_3, F5_2 => F5_4 | F5_3, F5_3 => F5_4 | F5_3, F5_4 => F5_1
  | F5_4, F5_0 => F5_2 | F5_4, F5_1 => F5_3 | F5_4, F5_2 => F5_4 | F5_4, F5_3 => F5_4 | F5_4, F5_4 => F5_0
  end.

#[local] Instance refa681_inst : Magma Fin5 := {| magma_op := refa681_op |}.

Lemma refa681_sat1484 : @Equation1484 Fin5 refa681_inst.
Proof. unfold Equation1484, magma_op, refa681_inst, refa681_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa681_not4606 : ~ @Equation4606 Fin5 refa681_inst.
Proof. unfold Equation4606. intro H. specialize (H F5_0 F5_1). unfold magma_op, refa681_inst, refa681_op in H. discriminate H. Qed.

(** ---- refa682 (Fin7) ---- *)

Definition refa682_op (x y : Fin7) : Fin7 :=
  match x, y with
  | F7_0, F7_0 => F7_2 | F7_0, F7_1 => F7_1 | F7_0, F7_2 => F7_4 | F7_0, F7_3 => F7_6 | F7_0, F7_4 => F7_0 | F7_0, F7_5 => F7_5 | F7_0, F7_6 => F7_3
  | F7_1, F7_0 => F7_3 | F7_1, F7_1 => F7_1 | F7_1, F7_2 => F7_6 | F7_1, F7_3 => F7_4 | F7_1, F7_4 => F7_5 | F7_1, F7_5 => F7_2 | F7_1, F7_6 => F7_0
  | F7_2, F7_0 => F7_2 | F7_2, F7_1 => F7_1 | F7_2, F7_2 => F7_4 | F7_2, F7_3 => F7_3 | F7_2, F7_4 => F7_0 | F7_2, F7_5 => F7_6 | F7_2, F7_6 => F7_5
  | F7_3, F7_0 => F7_2 | F7_3, F7_1 => F7_1 | F7_3, F7_2 => F7_4 | F7_3, F7_3 => F7_3 | F7_3, F7_4 => F7_0 | F7_3, F7_5 => F7_5 | F7_3, F7_6 => F7_6
  | F7_4, F7_0 => F7_2 | F7_4, F7_1 => F7_1 | F7_4, F7_2 => F7_4 | F7_4, F7_3 => F7_5 | F7_4, F7_4 => F7_0 | F7_4, F7_5 => F7_3 | F7_4, F7_6 => F7_6
  | F7_5, F7_0 => F7_2 | F7_5, F7_1 => F7_1 | F7_5, F7_2 => F7_4 | F7_5, F7_3 => F7_3 | F7_5, F7_4 => F7_0 | F7_5, F7_5 => F7_5 | F7_5, F7_6 => F7_6
  | F7_6, F7_0 => F7_2 | F7_6, F7_1 => F7_1 | F7_6, F7_2 => F7_4 | F7_6, F7_3 => F7_3 | F7_6, F7_4 => F7_0 | F7_6, F7_5 => F7_5 | F7_6, F7_6 => F7_6
  end.

#[local] Instance refa682_inst : Magma Fin7 := {| magma_op := refa682_op |}.

Lemma refa682_sat65 : @Equation65 Fin7 refa682_inst.
Proof. unfold Equation65, magma_op, refa682_inst, refa682_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa682_sat1491 : @Equation1491 Fin7 refa682_inst.
Proof. unfold Equation1491, magma_op, refa682_inst, refa682_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa682_not55 : ~ @Equation55 Fin7 refa682_inst.
Proof. unfold Equation55. intro H. specialize (H F7_3 F7_1). unfold magma_op, refa682_inst, refa682_op in H. discriminate H. Qed.

Lemma refa682_not619 : ~ @Equation619 Fin7 refa682_inst.
Proof. unfold Equation619. intro H. specialize (H F7_3 F7_1). unfold magma_op, refa682_inst, refa682_op in H. discriminate H. Qed.

Lemma refa682_not642 : ~ @Equation642 Fin7 refa682_inst.
Proof. unfold Equation642. intro H. specialize (H F7_3 F7_0). unfold magma_op, refa682_inst, refa682_op in H. discriminate H. Qed.

Lemma refa682_not679 : ~ @Equation679 Fin7 refa682_inst.
Proof. unfold Equation679. intro H. specialize (H F7_3 F7_0). unfold magma_op, refa682_inst, refa682_op in H. discriminate H. Qed.

Lemma refa682_not713 : ~ @Equation713 Fin7 refa682_inst.
Proof. unfold Equation713. intro H. specialize (H F7_3 F7_1). unfold magma_op, refa682_inst, refa682_op in H. discriminate H. Qed.

Lemma refa682_not832 : ~ @Equation832 Fin7 refa682_inst.
Proof. unfold Equation832. intro H. specialize (H F7_3 F7_1). unfold magma_op, refa682_inst, refa682_op in H. discriminate H. Qed.

Lemma refa682_not845 : ~ @Equation845 Fin7 refa682_inst.
Proof. unfold Equation845. intro H. specialize (H F7_3 F7_0). unfold magma_op, refa682_inst, refa682_op in H. discriminate H. Qed.

Lemma refa682_not872 : ~ @Equation872 Fin7 refa682_inst.
Proof. unfold Equation872. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa682_inst, refa682_op in H. discriminate H. Qed.

Lemma refa682_not1434 : ~ @Equation1434 Fin7 refa682_inst.
Proof. unfold Equation1434. intro H. specialize (H F7_3 F7_1). unfold magma_op, refa682_inst, refa682_op in H. discriminate H. Qed.

Lemma refa682_not1478 : ~ @Equation1478 Fin7 refa682_inst.
Proof. unfold Equation1478. intro H. specialize (H F7_3 F7_1). unfold magma_op, refa682_inst, refa682_op in H. discriminate H. Qed.

Lemma refa682_not1518 : ~ @Equation1518 Fin7 refa682_inst.
Proof. unfold Equation1518. intro H. specialize (H F7_3 F7_0). unfold magma_op, refa682_inst, refa682_op in H. discriminate H. Qed.

Lemma refa682_not1525 : ~ @Equation1525 Fin7 refa682_inst.
Proof. unfold Equation1525. intro H. specialize (H F7_3 F7_0). unfold magma_op, refa682_inst, refa682_op in H. discriminate H. Qed.

Lemma refa682_not3867 : ~ @Equation3867 Fin7 refa682_inst.
Proof. unfold Equation3867. intro H. specialize (H F7_3 F7_1). unfold magma_op, refa682_inst, refa682_op in H. discriminate H. Qed.

Lemma refa682_not3877 : ~ @Equation3877 Fin7 refa682_inst.
Proof. unfold Equation3877. intro H. specialize (H F7_3 F7_1). unfold magma_op, refa682_inst, refa682_op in H. discriminate H. Qed.

Lemma refa682_not3915 : ~ @Equation3915 Fin7 refa682_inst.
Proof. unfold Equation3915. intro H. specialize (H F7_0 F7_3). unfold magma_op, refa682_inst, refa682_op in H. discriminate H. Qed.

Lemma refa682_not3962 : ~ @Equation3962 Fin7 refa682_inst.
Proof. unfold Equation3962. intro H. specialize (H F7_0 F7_3). unfold magma_op, refa682_inst, refa682_op in H. discriminate H. Qed.

Lemma refa682_not4070 : ~ @Equation4070 Fin7 refa682_inst.
Proof. unfold Equation4070. intro H. specialize (H F7_3 F7_1). unfold magma_op, refa682_inst, refa682_op in H. discriminate H. Qed.

Lemma refa682_not4090 : ~ @Equation4090 Fin7 refa682_inst.
Proof. unfold Equation4090. intro H. specialize (H F7_3 F7_1). unfold magma_op, refa682_inst, refa682_op in H. discriminate H. Qed.

Lemma refa682_not4118 : ~ @Equation4118 Fin7 refa682_inst.
Proof. unfold Equation4118. intro H. specialize (H F7_0 F7_3). unfold magma_op, refa682_inst, refa682_op in H. discriminate H. Qed.

Lemma refa682_not4155 : ~ @Equation4155 Fin7 refa682_inst.
Proof. unfold Equation4155. intro H. specialize (H F7_0 F7_3). unfold magma_op, refa682_inst, refa682_op in H. discriminate H. Qed.

Lemma refa682_not4275 : ~ @Equation4275 Fin7 refa682_inst.
Proof. unfold Equation4275. intro H. specialize (H F7_3 F7_1). unfold magma_op, refa682_inst, refa682_op in H. discriminate H. Qed.

Lemma refa682_not4320 : ~ @Equation4320 Fin7 refa682_inst.
Proof. unfold Equation4320. intro H. specialize (H F7_3 F7_1). unfold magma_op, refa682_inst, refa682_op in H. discriminate H. Qed.

Lemma refa682_not4666 : ~ @Equation4666 Fin7 refa682_inst.
Proof. unfold Equation4666. intro H. specialize (H F7_0 F7_3 F7_1). unfold magma_op, refa682_inst, refa682_op in H. discriminate H. Qed.

(** ---- refa683 (Fin6) ---- *)

Definition refa683_op (x y : Fin6) : Fin6 :=
  match x, y with
  | F6_0, F6_0 => F6_2 | F6_0, F6_1 => F6_3 | F6_0, F6_2 => F6_5 | F6_0, F6_3 => F6_0 | F6_0, F6_4 => F6_1 | F6_0, F6_5 => F6_4
  | F6_1, F6_0 => F6_2 | F6_1, F6_1 => F6_5 | F6_1, F6_2 => F6_3 | F6_1, F6_3 => F6_4 | F6_1, F6_4 => F6_1 | F6_1, F6_5 => F6_0
  | F6_2, F6_0 => F6_2 | F6_2, F6_1 => F6_5 | F6_2, F6_2 => F6_3 | F6_2, F6_3 => F6_4 | F6_2, F6_4 => F6_1 | F6_2, F6_5 => F6_0
  | F6_3, F6_0 => F6_1 | F6_3, F6_1 => F6_5 | F6_3, F6_2 => F6_3 | F6_3, F6_3 => F6_0 | F6_3, F6_4 => F6_2 | F6_3, F6_5 => F6_4
  | F6_4, F6_0 => F6_2 | F6_4, F6_1 => F6_3 | F6_4, F6_2 => F6_5 | F6_4, F6_3 => F6_0 | F6_4, F6_4 => F6_1 | F6_4, F6_5 => F6_4
  | F6_5, F6_0 => F6_1 | F6_5, F6_1 => F6_5 | F6_5, F6_2 => F6_3 | F6_5, F6_3 => F6_0 | F6_5, F6_4 => F6_2 | F6_5, F6_5 => F6_4
  end.

#[local] Instance refa683_inst : Magma Fin6 := {| magma_op := refa683_op |}.

Lemma refa683_sat860 : @Equation860 Fin6 refa683_inst.
Proof. unfold Equation860, magma_op, refa683_inst, refa683_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa683_sat1586 : @Equation1586 Fin6 refa683_inst.
Proof. unfold Equation1586, magma_op, refa683_inst, refa683_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa683_not47 : ~ @Equation47 Fin6 refa683_inst.
Proof. unfold Equation47. intro H. specialize (H F6_0). unfold magma_op, refa683_inst, refa683_op in H. discriminate H. Qed.

Lemma refa683_not614 : ~ @Equation614 Fin6 refa683_inst.
Proof. unfold Equation614. intro H. specialize (H F6_0). unfold magma_op, refa683_inst, refa683_op in H. discriminate H. Qed.

Lemma refa683_not819 : ~ @Equation819 Fin6 refa683_inst.
Proof. unfold Equation819. intro H. specialize (H F6_0 F6_3). unfold magma_op, refa683_inst, refa683_op in H. discriminate H. Qed.

Lemma refa683_not835 : ~ @Equation835 Fin6 refa683_inst.
Proof. unfold Equation835. intro H. specialize (H F6_0 F6_3). unfold magma_op, refa683_inst, refa683_op in H. discriminate H. Qed.

Lemma refa683_not842 : ~ @Equation842 Fin6 refa683_inst.
Proof. unfold Equation842. intro H. specialize (H F6_0 F6_3). unfold magma_op, refa683_inst, refa683_op in H. discriminate H. Qed.

Lemma refa683_not1428 : ~ @Equation1428 Fin6 refa683_inst.
Proof. unfold Equation1428. intro H. specialize (H F6_0 F6_3). unfold magma_op, refa683_inst, refa683_op in H. discriminate H. Qed.

Lemma refa683_not1431 : ~ @Equation1431 Fin6 refa683_inst.
Proof. unfold Equation1431. intro H. specialize (H F6_0 F6_1). unfold magma_op, refa683_inst, refa683_op in H. discriminate H. Qed.

Lemma refa683_not1434 : ~ @Equation1434 Fin6 refa683_inst.
Proof. unfold Equation1434. intro H. specialize (H F6_0 F6_1). unfold magma_op, refa683_inst, refa683_op in H. discriminate H. Qed.

Lemma refa683_not1441 : ~ @Equation1441 Fin6 refa683_inst.
Proof. unfold Equation1441. intro H. specialize (H F6_0 F6_1). unfold magma_op, refa683_inst, refa683_op in H. discriminate H. Qed.

Lemma refa683_not1444 : ~ @Equation1444 Fin6 refa683_inst.
Proof. unfold Equation1444. intro H. specialize (H F6_0 F6_1). unfold magma_op, refa683_inst, refa683_op in H. discriminate H. Qed.

Lemma refa683_not1454 : ~ @Equation1454 Fin6 refa683_inst.
Proof. unfold Equation1454. intro H. specialize (H F6_0 F6_3). unfold magma_op, refa683_inst, refa683_op in H. discriminate H. Qed.

Lemma refa683_not3862 : ~ @Equation3862 Fin6 refa683_inst.
Proof. unfold Equation3862. intro H. specialize (H F6_0). unfold magma_op, refa683_inst, refa683_op in H. discriminate H. Qed.

Lemma refa683_not4067 : ~ @Equation4067 Fin6 refa683_inst.
Proof. unfold Equation4067. intro H. specialize (H F6_0 F6_1). unfold magma_op, refa683_inst, refa683_op in H. discriminate H. Qed.

Lemma refa683_not4073 : ~ @Equation4073 Fin6 refa683_inst.
Proof. unfold Equation4073. intro H. specialize (H F6_0 F6_1). unfold magma_op, refa683_inst, refa683_op in H. discriminate H. Qed.

Lemma refa683_not4118 : ~ @Equation4118 Fin6 refa683_inst.
Proof. unfold Equation4118. intro H. specialize (H F6_0 F6_1). unfold magma_op, refa683_inst, refa683_op in H. discriminate H. Qed.

Lemma refa683_not4121 : ~ @Equation4121 Fin6 refa683_inst.
Proof. unfold Equation4121. intro H. specialize (H F6_0 F6_1). unfold magma_op, refa683_inst, refa683_op in H. discriminate H. Qed.

Lemma refa683_not4128 : ~ @Equation4128 Fin6 refa683_inst.
Proof. unfold Equation4128. intro H. specialize (H F6_0 F6_1). unfold magma_op, refa683_inst, refa683_op in H. discriminate H. Qed.

Lemma refa683_not4131 : ~ @Equation4131 Fin6 refa683_inst.
Proof. unfold Equation4131. intro H. specialize (H F6_0 F6_1). unfold magma_op, refa683_inst, refa683_op in H. discriminate H. Qed.

Lemma refa683_not4269 : ~ @Equation4269 Fin6 refa683_inst.
Proof. unfold Equation4269. intro H. specialize (H F6_0 F6_3). unfold magma_op, refa683_inst, refa683_op in H. discriminate H. Qed.

Lemma refa683_not4284 : ~ @Equation4284 Fin6 refa683_inst.
Proof. unfold Equation4284. intro H. specialize (H F6_0 F6_1). unfold magma_op, refa683_inst, refa683_op in H. discriminate H. Qed.

Lemma refa683_not4599 : ~ @Equation4599 Fin6 refa683_inst.
Proof. unfold Equation4599. intro H. specialize (H F6_0 F6_3). unfold magma_op, refa683_inst, refa683_op in H. discriminate H. Qed.

Lemma refa683_not4631 : ~ @Equation4631 Fin6 refa683_inst.
Proof. unfold Equation4631. intro H. specialize (H F6_0 F6_0 F6_1). unfold magma_op, refa683_inst, refa683_op in H. discriminate H. Qed.

(** ---- refa684 (Fin6) ---- *)

Definition refa684_op (x y : Fin6) : Fin6 :=
  match x, y with
  | F6_0, F6_0 => F6_1 | F6_0, F6_1 => F6_5 | F6_0, F6_2 => F6_4 | F6_0, F6_3 => F6_2 | F6_0, F6_4 => F6_0 | F6_0, F6_5 => F6_3
  | F6_1, F6_0 => F6_2 | F6_1, F6_1 => F6_5 | F6_1, F6_2 => F6_4 | F6_1, F6_3 => F6_1 | F6_1, F6_4 => F6_3 | F6_1, F6_5 => F6_0
  | F6_2, F6_0 => F6_2 | F6_2, F6_1 => F6_5 | F6_2, F6_2 => F6_4 | F6_2, F6_3 => F6_1 | F6_2, F6_4 => F6_3 | F6_2, F6_5 => F6_0
  | F6_3, F6_0 => F6_1 | F6_3, F6_1 => F6_5 | F6_3, F6_2 => F6_4 | F6_3, F6_3 => F6_2 | F6_3, F6_4 => F6_0 | F6_3, F6_5 => F6_3
  | F6_4, F6_0 => F6_1 | F6_4, F6_1 => F6_4 | F6_4, F6_2 => F6_5 | F6_4, F6_3 => F6_2 | F6_4, F6_4 => F6_3 | F6_4, F6_5 => F6_0
  | F6_5, F6_0 => F6_1 | F6_5, F6_1 => F6_4 | F6_5, F6_2 => F6_5 | F6_5, F6_3 => F6_2 | F6_5, F6_4 => F6_3 | F6_5, F6_5 => F6_0
  end.

#[local] Instance refa684_inst : Magma Fin6 := {| magma_op := refa684_op |}.

Lemma refa684_sat690 : @Equation690 Fin6 refa684_inst.
Proof. unfold Equation690, magma_op, refa684_inst, refa684_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa684_sat1586 : @Equation1586 Fin6 refa684_inst.
Proof. unfold Equation1586, magma_op, refa684_inst, refa684_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa684_not47 : ~ @Equation47 Fin6 refa684_inst.
Proof. unfold Equation47. intro H. specialize (H F6_0). unfold magma_op, refa684_inst, refa684_op in H. discriminate H. Qed.

Lemma refa684_not632 : ~ @Equation632 Fin6 refa684_inst.
Proof. unfold Equation632. intro H. specialize (H F6_0 F6_1). unfold magma_op, refa684_inst, refa684_op in H. discriminate H. Qed.

Lemma refa684_not642 : ~ @Equation642 Fin6 refa684_inst.
Proof. unfold Equation642. intro H. specialize (H F6_0 F6_1). unfold magma_op, refa684_inst, refa684_op in H. discriminate H. Qed.

Lemma refa684_not817 : ~ @Equation817 Fin6 refa684_inst.
Proof. unfold Equation817. intro H. specialize (H F6_0). unfold magma_op, refa684_inst, refa684_op in H. discriminate H. Qed.

Lemma refa684_not1434 : ~ @Equation1434 Fin6 refa684_inst.
Proof. unfold Equation1434. intro H. specialize (H F6_0 F6_1). unfold magma_op, refa684_inst, refa684_op in H. discriminate H. Qed.

Lemma refa684_not3915 : ~ @Equation3915 Fin6 refa684_inst.
Proof. unfold Equation3915. intro H. specialize (H F6_0 F6_1). unfold magma_op, refa684_inst, refa684_op in H. discriminate H. Qed.

Lemma refa684_not3925 : ~ @Equation3925 Fin6 refa684_inst.
Proof. unfold Equation3925. intro H. specialize (H F6_0 F6_1). unfold magma_op, refa684_inst, refa684_op in H. discriminate H. Qed.

Lemma refa684_not3952 : ~ @Equation3952 Fin6 refa684_inst.
Proof. unfold Equation3952. intro H. specialize (H F6_0 F6_1). unfold magma_op, refa684_inst, refa684_op in H. discriminate H. Qed.

Lemma refa684_not3962 : ~ @Equation3962 Fin6 refa684_inst.
Proof. unfold Equation3962. intro H. specialize (H F6_0 F6_1). unfold magma_op, refa684_inst, refa684_op in H. discriminate H. Qed.

Lemma refa684_not4065 : ~ @Equation4065 Fin6 refa684_inst.
Proof. unfold Equation4065. intro H. specialize (H F6_0). unfold magma_op, refa684_inst, refa684_op in H. discriminate H. Qed.

Lemma refa684_not4275 : ~ @Equation4275 Fin6 refa684_inst.
Proof. unfold Equation4275. intro H. specialize (H F6_0 F6_1). unfold magma_op, refa684_inst, refa684_op in H. discriminate H. Qed.

Lemma refa684_not4320 : ~ @Equation4320 Fin6 refa684_inst.
Proof. unfold Equation4320. intro H. specialize (H F6_0 F6_1). unfold magma_op, refa684_inst, refa684_op in H. discriminate H. Qed.
