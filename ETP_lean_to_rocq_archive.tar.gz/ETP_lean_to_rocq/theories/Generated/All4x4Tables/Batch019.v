(** * All4x4 counterexamples — batch 19
    Auto-generated from Lean4 All4x4 files. *)

From Stdlib Require Import Utf8.

From ETP Require Import Magma.
From ETP Require Import FinMagma.
From ETP.Equations Require Import All.

Open Scope magma_scope.

(** ---- refa91 (Fin3) ---- *)

Definition refa91_op (x y : Fin3) : Fin3 :=
  match x, y with
  | F3_0, F3_0 => F3_0 | F3_0, F3_1 => F3_0 | F3_0, F3_2 => F3_0
  | F3_1, F3_0 => F3_2 | F3_1, F3_1 => F3_1 | F3_1, F3_2 => F3_2
  | F3_2, F3_0 => F3_1 | F3_2, F3_1 => F3_1 | F3_2, F3_2 => F3_2
  end.

#[local] Instance refa91_inst : Magma Fin3 := {| magma_op := refa91_op |}.

Lemma refa91_sat25 : @Equation25 Fin3 refa91_inst.
Proof. unfold Equation25, magma_op, refa91_inst, refa91_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa91_sat156 : @Equation156 Fin3 refa91_inst.
Proof. unfold Equation156, magma_op, refa91_inst, refa91_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa91_sat159 : @Equation159 Fin3 refa91_inst.
Proof. unfold Equation159, magma_op, refa91_inst, refa91_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa91_sat616 : @Equation616 Fin3 refa91_inst.
Proof. unfold Equation616, magma_op, refa91_inst, refa91_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa91_sat1234 : @Equation1234 Fin3 refa91_inst.
Proof. unfold Equation1234, magma_op, refa91_inst, refa91_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa91_sat1654 : @Equation1654 Fin3 refa91_inst.
Proof. unfold Equation1654, magma_op, refa91_inst, refa91_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa91_sat1657 : @Equation1657 Fin3 refa91_inst.
Proof. unfold Equation1657, magma_op, refa91_inst, refa91_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa91_sat2043 : @Equation2043 Fin3 refa91_inst.
Proof. unfold Equation2043, magma_op, refa91_inst, refa91_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa91_sat2070 : @Equation2070 Fin3 refa91_inst.
Proof. unfold Equation2070, magma_op, refa91_inst, refa91_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa91_sat2691 : @Equation2691 Fin3 refa91_inst.
Proof. unfold Equation2691, magma_op, refa91_inst, refa91_op. intros x y z w. destruct x, y, z, w; reflexivity. Qed.

Lemma refa91_sat3081 : @Equation3081 Fin3 refa91_inst.
Proof. unfold Equation3081, magma_op, refa91_inst, refa91_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa91_sat3732 : @Equation3732 Fin3 refa91_inst.
Proof. unfold Equation3732, magma_op, refa91_inst, refa91_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa91_not619 : ~ @Equation619 Fin3 refa91_inst.
Proof. unfold Equation619. intro H. specialize (H F3_1 F3_0). unfold magma_op, refa91_inst, refa91_op in H. discriminate H. Qed.

Lemma refa91_not1634 : ~ @Equation1634 Fin3 refa91_inst.
Proof. unfold Equation1634. intro H. specialize (H F3_1 F3_0). unfold magma_op, refa91_inst, refa91_op in H. discriminate H. Qed.

Lemma refa91_not1637 : ~ @Equation1637 Fin3 refa91_inst.
Proof. unfold Equation1637. intro H. specialize (H F3_1 F3_0). unfold magma_op, refa91_inst, refa91_op in H. discriminate H. Qed.

Lemma refa91_not2037 : ~ @Equation2037 Fin3 refa91_inst.
Proof. unfold Equation2037. intro H. specialize (H F3_1 F3_0). unfold magma_op, refa91_inst, refa91_op in H. discriminate H. Qed.

Lemma refa91_not2053 : ~ @Equation2053 Fin3 refa91_inst.
Proof. unfold Equation2053. intro H. specialize (H F3_1 F3_0). unfold magma_op, refa91_inst, refa91_op in H. discriminate H. Qed.

Lemma refa91_not2063 : ~ @Equation2063 Fin3 refa91_inst.
Proof. unfold Equation2063. intro H. specialize (H F3_1 F3_0). unfold magma_op, refa91_inst, refa91_op in H. discriminate H. Qed.

Lemma refa91_not2327 : ~ @Equation2327 Fin3 refa91_inst.
Proof. unfold Equation2327. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa91_inst, refa91_op in H. discriminate H. Qed.

Lemma refa91_not2340 : ~ @Equation2340 Fin3 refa91_inst.
Proof. unfold Equation2340. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa91_inst, refa91_op in H. discriminate H. Qed.

Lemma refa91_not2496 : ~ @Equation2496 Fin3 refa91_inst.
Proof. unfold Equation2496. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa91_inst, refa91_op in H. discriminate H. Qed.

Lemma refa91_not2543 : ~ @Equation2543 Fin3 refa91_inst.
Proof. unfold Equation2543. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa91_inst, refa91_op in H. discriminate H. Qed.

Lemma refa91_not2699 : ~ @Equation2699 Fin3 refa91_inst.
Proof. unfold Equation2699. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa91_inst, refa91_op in H. discriminate H. Qed.

Lemma refa91_not2706 : ~ @Equation2706 Fin3 refa91_inst.
Proof. unfold Equation2706. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa91_inst, refa91_op in H. discriminate H. Qed.

Lemma refa91_not2733 : ~ @Equation2733 Fin3 refa91_inst.
Proof. unfold Equation2733. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa91_inst, refa91_op in H. discriminate H. Qed.

Lemma refa91_not2746 : ~ @Equation2746 Fin3 refa91_inst.
Proof. unfold Equation2746. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa91_inst, refa91_op in H. discriminate H. Qed.

Lemma refa91_not2902 : ~ @Equation2902 Fin3 refa91_inst.
Proof. unfold Equation2902. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa91_inst, refa91_op in H. discriminate H. Qed.

Lemma refa91_not2909 : ~ @Equation2909 Fin3 refa91_inst.
Proof. unfold Equation2909. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa91_inst, refa91_op in H. discriminate H. Qed.

Lemma refa91_not2936 : ~ @Equation2936 Fin3 refa91_inst.
Proof. unfold Equation2936. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa91_inst, refa91_op in H. discriminate H. Qed.

Lemma refa91_not2949 : ~ @Equation2949 Fin3 refa91_inst.
Proof. unfold Equation2949. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa91_inst, refa91_op in H. discriminate H. Qed.

Lemma refa91_not3112 : ~ @Equation3112 Fin3 refa91_inst.
Proof. unfold Equation3112. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa91_inst, refa91_op in H. discriminate H. Qed.

Lemma refa91_not3152 : ~ @Equation3152 Fin3 refa91_inst.
Proof. unfold Equation3152. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa91_inst, refa91_op in H. discriminate H. Qed.

Lemma refa91_not3255 : ~ @Equation3255 Fin3 refa91_inst.
Proof. unfold Equation3255. intro H. specialize (H F3_1 F3_0). unfold magma_op, refa91_inst, refa91_op in H. discriminate H. Qed.

Lemma refa91_not3256 : ~ @Equation3256 Fin3 refa91_inst.
Proof. unfold Equation3256. intro H. specialize (H F3_1 F3_0). unfold magma_op, refa91_inst, refa91_op in H. discriminate H. Qed.

Lemma refa91_not3258 : ~ @Equation3258 Fin3 refa91_inst.
Proof. unfold Equation3258. intro H. specialize (H F3_1 F3_0). unfold magma_op, refa91_inst, refa91_op in H. discriminate H. Qed.

Lemma refa91_not3259 : ~ @Equation3259 Fin3 refa91_inst.
Proof. unfold Equation3259. intro H. specialize (H F3_1 F3_0). unfold magma_op, refa91_inst, refa91_op in H. discriminate H. Qed.

Lemma refa91_not3261 : ~ @Equation3261 Fin3 refa91_inst.
Proof. unfold Equation3261. intro H. specialize (H F3_1 F3_0). unfold magma_op, refa91_inst, refa91_op in H. discriminate H. Qed.

Lemma refa91_not3262 : ~ @Equation3262 Fin3 refa91_inst.
Proof. unfold Equation3262. intro H. specialize (H F3_1 F3_0). unfold magma_op, refa91_inst, refa91_op in H. discriminate H. Qed.

Lemma refa91_not3459 : ~ @Equation3459 Fin3 refa91_inst.
Proof. unfold Equation3459. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa91_inst, refa91_op in H. discriminate H. Qed.

Lemma refa91_not3461 : ~ @Equation3461 Fin3 refa91_inst.
Proof. unfold Equation3461. intro H. specialize (H F3_1 F3_0). unfold magma_op, refa91_inst, refa91_op in H. discriminate H. Qed.

Lemma refa91_not3464 : ~ @Equation3464 Fin3 refa91_inst.
Proof. unfold Equation3464. intro H. specialize (H F3_1 F3_0). unfold magma_op, refa91_inst, refa91_op in H. discriminate H. Qed.

Lemma refa91_not3474 : ~ @Equation3474 Fin3 refa91_inst.
Proof. unfold Equation3474. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa91_inst, refa91_op in H. discriminate H. Qed.

Lemma refa91_not3512 : ~ @Equation3512 Fin3 refa91_inst.
Proof. unfold Equation3512. intro H. specialize (H F3_1 F3_0). unfold magma_op, refa91_inst, refa91_op in H. discriminate H. Qed.

Lemma refa91_not3549 : ~ @Equation3549 Fin3 refa91_inst.
Proof. unfold Equation3549. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa91_inst, refa91_op in H. discriminate H. Qed.

Lemma refa91_not3556 : ~ @Equation3556 Fin3 refa91_inst.
Proof. unfold Equation3556. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa91_inst, refa91_op in H. discriminate H. Qed.

Lemma refa91_not3662 : ~ @Equation3662 Fin3 refa91_inst.
Proof. unfold Equation3662. intro H. specialize (H F3_1 F3_0). unfold magma_op, refa91_inst, refa91_op in H. discriminate H. Qed.

Lemma refa91_not3665 : ~ @Equation3665 Fin3 refa91_inst.
Proof. unfold Equation3665. intro H. specialize (H F3_1 F3_0). unfold magma_op, refa91_inst, refa91_op in H. discriminate H. Qed.

Lemma refa91_not3668 : ~ @Equation3668 Fin3 refa91_inst.
Proof. unfold Equation3668. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa91_inst, refa91_op in H. discriminate H. Qed.

Lemma refa91_not3752 : ~ @Equation3752 Fin3 refa91_inst.
Proof. unfold Equation3752. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa91_inst, refa91_op in H. discriminate H. Qed.

Lemma refa91_not3759 : ~ @Equation3759 Fin3 refa91_inst.
Proof. unfold Equation3759. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa91_inst, refa91_op in H. discriminate H. Qed.

Lemma refa91_not3925 : ~ @Equation3925 Fin3 refa91_inst.
Proof. unfold Equation3925. intro H. specialize (H F3_1 F3_0). unfold magma_op, refa91_inst, refa91_op in H. discriminate H. Qed.

Lemma refa91_not4121 : ~ @Equation4121 Fin3 refa91_inst.
Proof. unfold Equation4121. intro H. specialize (H F3_1 F3_0). unfold magma_op, refa91_inst, refa91_op in H. discriminate H. Qed.

Lemma refa91_not4269 : ~ @Equation4269 Fin3 refa91_inst.
Proof. unfold Equation4269. intro H. specialize (H F3_1 F3_0). unfold magma_op, refa91_inst, refa91_op in H. discriminate H. Qed.

Lemma refa91_not4270 : ~ @Equation4270 Fin3 refa91_inst.
Proof. unfold Equation4270. intro H. specialize (H F3_1 F3_0). unfold magma_op, refa91_inst, refa91_op in H. discriminate H. Qed.

Lemma refa91_not4314 : ~ @Equation4314 Fin3 refa91_inst.
Proof. unfold Equation4314. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa91_inst, refa91_op in H. discriminate H. Qed.

Lemma refa91_not4409 : ~ @Equation4409 Fin3 refa91_inst.
Proof. unfold Equation4409. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa91_inst, refa91_op in H. discriminate H. Qed.

Lemma refa91_not4480 : ~ @Equation4480 Fin3 refa91_inst.
Proof. unfold Equation4480. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa91_inst, refa91_op in H. discriminate H. Qed.

Lemma refa91_not4599 : ~ @Equation4599 Fin3 refa91_inst.
Proof. unfold Equation4599. intro H. specialize (H F3_1 F3_0). unfold magma_op, refa91_inst, refa91_op in H. discriminate H. Qed.

(** ---- refa910 (Fin5) ---- *)

Definition refa910_op (x y : Fin5) : Fin5 :=
  match x, y with
  | F5_0, F5_0 => F5_1 | F5_0, F5_1 => F5_4 | F5_0, F5_2 => F5_1 | F5_0, F5_3 => F5_4 | F5_0, F5_4 => F5_4
  | F5_1, F5_0 => F5_2 | F5_1, F5_1 => F5_0 | F5_1, F5_2 => F5_2 | F5_1, F5_3 => F5_2 | F5_1, F5_4 => F5_0
  | F5_2, F5_0 => F5_3 | F5_2, F5_1 => F5_3 | F5_2, F5_2 => F5_2 | F5_2, F5_3 => F5_2 | F5_2, F5_4 => F5_0
  | F5_3, F5_0 => F5_1 | F5_3, F5_1 => F5_0 | F5_3, F5_2 => F5_1 | F5_3, F5_3 => F5_2 | F5_3, F5_4 => F5_0
  | F5_4, F5_0 => F5_3 | F5_4, F5_1 => F5_3 | F5_4, F5_2 => F5_1 | F5_4, F5_3 => F5_4 | F5_4, F5_4 => F5_4
  end.

#[local] Instance refa910_inst : Magma Fin5 := {| magma_op := refa910_op |}.

Lemma refa910_sat1480 : @Equation1480 Fin5 refa910_inst.
Proof. unfold Equation1480, magma_op, refa910_inst, refa910_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa910_not4666 : ~ @Equation4666 Fin5 refa910_inst.
Proof. unfold Equation4666. intro H. specialize (H F5_0 F5_0 F5_1). unfold magma_op, refa910_inst, refa910_op in H. discriminate H. Qed.

(** ---- refa911 (Fin6) ---- *)

Definition refa911_op (x y : Fin6) : Fin6 :=
  match x, y with
  | F6_0, F6_0 => F6_1 | F6_0, F6_1 => F6_5 | F6_0, F6_2 => F6_3 | F6_0, F6_3 => F6_2 | F6_0, F6_4 => F6_0 | F6_0, F6_5 => F6_4
  | F6_1, F6_0 => F6_2 | F6_1, F6_1 => F6_1 | F6_1, F6_2 => F6_0 | F6_1, F6_3 => F6_3 | F6_1, F6_4 => F6_4 | F6_1, F6_5 => F6_5
  | F6_2, F6_0 => F6_3 | F6_2, F6_1 => F6_2 | F6_2, F6_2 => F6_4 | F6_2, F6_3 => F6_0 | F6_2, F6_4 => F6_5 | F6_2, F6_5 => F6_1
  | F6_3, F6_0 => F6_2 | F6_3, F6_1 => F6_1 | F6_3, F6_2 => F6_0 | F6_3, F6_3 => F6_5 | F6_3, F6_4 => F6_4 | F6_3, F6_5 => F6_3
  | F6_4, F6_0 => F6_2 | F6_4, F6_1 => F6_4 | F6_4, F6_2 => F6_0 | F6_4, F6_3 => F6_3 | F6_4, F6_4 => F6_1 | F6_4, F6_5 => F6_5
  | F6_5, F6_0 => F6_4 | F6_5, F6_1 => F6_0 | F6_5, F6_2 => F6_1 | F6_5, F6_3 => F6_3 | F6_5, F6_4 => F6_2 | F6_5, F6_5 => F6_5
  end.

#[local] Instance refa911_inst : Magma Fin6 := {| magma_op := refa911_op |}.

Lemma refa911_sat1082 : @Equation1082 Fin6 refa911_inst.
Proof. unfold Equation1082, magma_op, refa911_inst, refa911_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa911_not4065 : ~ @Equation4065 Fin6 refa911_inst.
Proof. unfold Equation4065. intro H. specialize (H F6_0). unfold magma_op, refa911_inst, refa911_op in H. discriminate H. Qed.

(** ---- refa912 (Fin8) ---- *)

Definition refa912_op (x y : Fin8) : Fin8 :=
  match x, y with
  | F8_0, F8_0 => F8_1 | F8_0, F8_1 => F8_2 | F8_0, F8_2 => F8_3 | F8_0, F8_3 => F8_4 | F8_0, F8_4 => F8_6 | F8_0, F8_5 => F8_7 | F8_0, F8_6 => F8_5 | F8_0, F8_7 => F8_0
  | F8_1, F8_0 => F8_7 | F8_1, F8_1 => F8_0 | F8_1, F8_2 => F8_1 | F8_1, F8_3 => F8_2 | F8_1, F8_4 => F8_3 | F8_1, F8_5 => F8_6 | F8_1, F8_6 => F8_4 | F8_1, F8_7 => F8_5
  | F8_2, F8_0 => F8_7 | F8_2, F8_1 => F8_0 | F8_2, F8_2 => F8_1 | F8_2, F8_3 => F8_2 | F8_2, F8_4 => F8_3 | F8_2, F8_5 => F8_6 | F8_2, F8_6 => F8_4 | F8_2, F8_7 => F8_5
  | F8_3, F8_0 => F8_1 | F8_3, F8_1 => F8_2 | F8_3, F8_2 => F8_3 | F8_3, F8_3 => F8_4 | F8_3, F8_4 => F8_6 | F8_3, F8_5 => F8_7 | F8_3, F8_6 => F8_5 | F8_3, F8_7 => F8_0
  | F8_4, F8_0 => F8_1 | F8_4, F8_1 => F8_2 | F8_4, F8_2 => F8_3 | F8_4, F8_3 => F8_4 | F8_4, F8_4 => F8_6 | F8_4, F8_5 => F8_7 | F8_4, F8_6 => F8_5 | F8_4, F8_7 => F8_0
  | F8_5, F8_0 => F8_7 | F8_5, F8_1 => F8_0 | F8_5, F8_2 => F8_1 | F8_5, F8_3 => F8_2 | F8_5, F8_4 => F8_3 | F8_5, F8_5 => F8_6 | F8_5, F8_6 => F8_4 | F8_5, F8_7 => F8_5
  | F8_6, F8_0 => F8_7 | F8_6, F8_1 => F8_0 | F8_6, F8_2 => F8_1 | F8_6, F8_3 => F8_2 | F8_6, F8_4 => F8_3 | F8_6, F8_5 => F8_6 | F8_6, F8_6 => F8_4 | F8_6, F8_7 => F8_5
  | F8_7, F8_0 => F8_1 | F8_7, F8_1 => F8_2 | F8_7, F8_2 => F8_3 | F8_7, F8_3 => F8_4 | F8_7, F8_4 => F8_6 | F8_7, F8_5 => F8_7 | F8_7, F8_6 => F8_5 | F8_7, F8_7 => F8_0
  end.

#[local] Instance refa912_inst : Magma Fin8 := {| magma_op := refa912_op |}.

Lemma refa912_sat1184 : @Equation1184 Fin8 refa912_inst.
Proof. unfold Equation1184, magma_op, refa912_inst, refa912_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa912_not411 : ~ @Equation411 Fin8 refa912_inst.
Proof. unfold Equation411. intro H. specialize (H F8_0). unfold magma_op, refa912_inst, refa912_op in H. discriminate H. Qed.

Lemma refa912_not4275 : ~ @Equation4275 Fin8 refa912_inst.
Proof. unfold Equation4275. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa912_inst, refa912_op in H. discriminate H. Qed.

(** ---- refa913 (Fin8) ---- *)

Definition refa913_op (x y : Fin8) : Fin8 :=
  match x, y with
  | F8_0, F8_0 => F8_2 | F8_0, F8_1 => F8_4 | F8_0, F8_2 => F8_7 | F8_0, F8_3 => F8_5 | F8_0, F8_4 => F8_0 | F8_0, F8_5 => F8_6 | F8_0, F8_6 => F8_1 | F8_0, F8_7 => F8_3
  | F8_1, F8_0 => F8_0 | F8_1, F8_1 => F8_5 | F8_1, F8_2 => F8_2 | F8_1, F8_3 => F8_1 | F8_1, F8_4 => F8_7 | F8_1, F8_5 => F8_4 | F8_1, F8_6 => F8_3 | F8_1, F8_7 => F8_6
  | F8_2, F8_0 => F8_3 | F8_2, F8_1 => F8_1 | F8_2, F8_2 => F8_4 | F8_2, F8_3 => F8_6 | F8_2, F8_4 => F8_5 | F8_2, F8_5 => F8_0 | F8_2, F8_6 => F8_2 | F8_2, F8_7 => F8_7
  | F8_3, F8_0 => F8_7 | F8_3, F8_1 => F8_2 | F8_3, F8_2 => F8_3 | F8_3, F8_3 => F8_0 | F8_3, F8_4 => F8_4 | F8_3, F8_5 => F8_1 | F8_3, F8_6 => F8_6 | F8_3, F8_7 => F8_5
  | F8_4, F8_0 => F8_1 | F8_4, F8_1 => F8_3 | F8_4, F8_2 => F8_0 | F8_4, F8_3 => F8_7 | F8_4, F8_4 => F8_6 | F8_4, F8_5 => F8_2 | F8_4, F8_6 => F8_5 | F8_4, F8_7 => F8_4
  | F8_5, F8_0 => F8_5 | F8_5, F8_1 => F8_7 | F8_5, F8_2 => F8_6 | F8_5, F8_3 => F8_4 | F8_5, F8_4 => F8_1 | F8_5, F8_5 => F8_3 | F8_5, F8_6 => F8_0 | F8_5, F8_7 => F8_2
  | F8_6, F8_0 => F8_4 | F8_6, F8_1 => F8_6 | F8_6, F8_2 => F8_1 | F8_6, F8_3 => F8_3 | F8_6, F8_4 => F8_2 | F8_6, F8_5 => F8_5 | F8_6, F8_6 => F8_7 | F8_6, F8_7 => F8_0
  | F8_7, F8_0 => F8_6 | F8_7, F8_1 => F8_0 | F8_7, F8_2 => F8_5 | F8_7, F8_3 => F8_2 | F8_7, F8_4 => F8_3 | F8_7, F8_5 => F8_7 | F8_7, F8_6 => F8_4 | F8_7, F8_7 => F8_1
  end.

#[local] Instance refa913_inst : Magma Fin8 := {| magma_op := refa913_op |}.

Lemma refa913_sat873 : @Equation873 Fin8 refa913_inst.
Proof. unfold Equation873, magma_op, refa913_inst, refa913_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa913_not203 : ~ @Equation203 Fin8 refa913_inst.
Proof. unfold Equation203. intro H. specialize (H F8_0). unfold magma_op, refa913_inst, refa913_op in H. discriminate H. Qed.

Lemma refa913_not1223 : ~ @Equation1223 Fin8 refa913_inst.
Proof. unfold Equation1223. intro H. specialize (H F8_0). unfold magma_op, refa913_inst, refa913_op in H. discriminate H. Qed.

Lemma refa913_not4647 : ~ @Equation4647 Fin8 refa913_inst.
Proof. unfold Equation4647. intro H. specialize (H F8_0 F8_0 F8_1). unfold magma_op, refa913_inst, refa913_op in H. discriminate H. Qed.

(** ---- refa914 (Fin8) ---- *)

Definition refa914_op (x y : Fin8) : Fin8 :=
  match x, y with
  | F8_0, F8_0 => F8_1 | F8_0, F8_1 => F8_2 | F8_0, F8_2 => F8_5 | F8_0, F8_3 => F8_7 | F8_0, F8_4 => F8_3 | F8_0, F8_5 => F8_0 | F8_0, F8_6 => F8_4 | F8_0, F8_7 => F8_6
  | F8_1, F8_0 => F8_2 | F8_1, F8_1 => F8_3 | F8_1, F8_2 => F8_4 | F8_1, F8_3 => F8_6 | F8_1, F8_4 => F8_7 | F8_1, F8_5 => F8_5 | F8_1, F8_6 => F8_1 | F8_1, F8_7 => F8_0
  | F8_2, F8_0 => F8_3 | F8_2, F8_1 => F8_7 | F8_2, F8_2 => F8_6 | F8_2, F8_3 => F8_2 | F8_2, F8_4 => F8_1 | F8_2, F8_5 => F8_4 | F8_2, F8_6 => F8_0 | F8_2, F8_7 => F8_5
  | F8_3, F8_0 => F8_7 | F8_3, F8_1 => F8_3 | F8_3, F8_2 => F8_0 | F8_3, F8_3 => F8_6 | F8_3, F8_4 => F8_2 | F8_3, F8_5 => F8_5 | F8_3, F8_6 => F8_1 | F8_3, F8_7 => F8_4
  | F8_4, F8_0 => F8_3 | F8_4, F8_1 => F8_7 | F8_4, F8_2 => F8_6 | F8_4, F8_3 => F8_2 | F8_4, F8_4 => F8_1 | F8_4, F8_5 => F8_4 | F8_4, F8_6 => F8_0 | F8_4, F8_7 => F8_5
  | F8_5, F8_0 => F8_2 | F8_5, F8_1 => F8_3 | F8_5, F8_2 => F8_4 | F8_5, F8_3 => F8_6 | F8_5, F8_4 => F8_7 | F8_5, F8_5 => F8_5 | F8_5, F8_6 => F8_1 | F8_5, F8_7 => F8_0
  | F8_6, F8_0 => F8_7 | F8_6, F8_1 => F8_3 | F8_6, F8_2 => F8_0 | F8_6, F8_3 => F8_6 | F8_6, F8_4 => F8_2 | F8_6, F8_5 => F8_5 | F8_6, F8_6 => F8_1 | F8_6, F8_7 => F8_4
  | F8_7, F8_0 => F8_1 | F8_7, F8_1 => F8_2 | F8_7, F8_2 => F8_5 | F8_7, F8_3 => F8_7 | F8_7, F8_4 => F8_3 | F8_7, F8_5 => F8_0 | F8_7, F8_6 => F8_4 | F8_7, F8_7 => F8_6
  end.

#[local] Instance refa914_inst : Magma Fin8 := {| magma_op := refa914_op |}.

Lemma refa914_sat676 : @Equation676 Fin8 refa914_inst.
Proof. unfold Equation676, magma_op, refa914_inst, refa914_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa914_not1426 : ~ @Equation1426 Fin8 refa914_inst.
Proof. unfold Equation1426. intro H. specialize (H F8_0). unfold magma_op, refa914_inst, refa914_op in H. discriminate H. Qed.

Lemma refa914_not3862 : ~ @Equation3862 Fin8 refa914_inst.
Proof. unfold Equation3862. intro H. specialize (H F8_0). unfold magma_op, refa914_inst, refa914_op in H. discriminate H. Qed.

Lemma refa914_not4065 : ~ @Equation4065 Fin8 refa914_inst.
Proof. unfold Equation4065. intro H. specialize (H F8_0). unfold magma_op, refa914_inst, refa914_op in H. discriminate H. Qed.

(** ---- refa915 (Fin7) ---- *)

Definition refa915_op (x y : Fin7) : Fin7 :=
  match x, y with
  | F7_0, F7_0 => F7_1 | F7_0, F7_1 => F7_2 | F7_0, F7_2 => F7_5 | F7_0, F7_3 => F7_6 | F7_0, F7_4 => F7_4 | F7_0, F7_5 => F7_3 | F7_0, F7_6 => F7_0
  | F7_1, F7_0 => F7_3 | F7_1, F7_1 => F7_0 | F7_1, F7_2 => F7_6 | F7_1, F7_3 => F7_4 | F7_1, F7_4 => F7_2 | F7_1, F7_5 => F7_5 | F7_1, F7_6 => F7_1
  | F7_2, F7_0 => F7_0 | F7_2, F7_1 => F7_4 | F7_2, F7_2 => F7_3 | F7_2, F7_3 => F7_5 | F7_2, F7_4 => F7_6 | F7_2, F7_5 => F7_1 | F7_2, F7_6 => F7_2
  | F7_3, F7_0 => F7_5 | F7_3, F7_1 => F7_1 | F7_3, F7_2 => F7_4 | F7_3, F7_3 => F7_2 | F7_3, F7_4 => F7_0 | F7_3, F7_5 => F7_6 | F7_3, F7_6 => F7_3
  | F7_4, F7_0 => F7_2 | F7_4, F7_1 => F7_6 | F7_4, F7_2 => F7_1 | F7_4, F7_3 => F7_3 | F7_4, F7_4 => F7_5 | F7_4, F7_5 => F7_0 | F7_4, F7_6 => F7_4
  | F7_5, F7_0 => F7_6 | F7_5, F7_1 => F7_3 | F7_5, F7_2 => F7_2 | F7_5, F7_3 => F7_0 | F7_5, F7_4 => F7_1 | F7_5, F7_5 => F7_4 | F7_5, F7_6 => F7_5
  | F7_6, F7_0 => F7_4 | F7_6, F7_1 => F7_5 | F7_6, F7_2 => F7_0 | F7_6, F7_3 => F7_1 | F7_6, F7_4 => F7_3 | F7_6, F7_5 => F7_2 | F7_6, F7_6 => F7_6
  end.

#[local] Instance refa915_inst : Magma Fin7 := {| magma_op := refa915_op |}.

Lemma refa915_sat667 : @Equation667 Fin7 refa915_inst.
Proof. unfold Equation667, magma_op, refa915_inst, refa915_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa915_not411 : ~ @Equation411 Fin7 refa915_inst.
Proof. unfold Equation411. intro H. specialize (H F7_0). unfold magma_op, refa915_inst, refa915_op in H. discriminate H. Qed.

Lemma refa915_not1020 : ~ @Equation1020 Fin7 refa915_inst.
Proof. unfold Equation1020. intro H. specialize (H F7_0). unfold magma_op, refa915_inst, refa915_op in H. discriminate H. Qed.

Lemma refa915_not1223 : ~ @Equation1223 Fin7 refa915_inst.
Proof. unfold Equation1223. intro H. specialize (H F7_0). unfold magma_op, refa915_inst, refa915_op in H. discriminate H. Qed.

Lemma refa915_not1426 : ~ @Equation1426 Fin7 refa915_inst.
Proof. unfold Equation1426. intro H. specialize (H F7_0). unfold magma_op, refa915_inst, refa915_op in H. discriminate H. Qed.

Lemma refa915_not1629 : ~ @Equation1629 Fin7 refa915_inst.
Proof. unfold Equation1629. intro H. specialize (H F7_0). unfold magma_op, refa915_inst, refa915_op in H. discriminate H. Qed.

Lemma refa915_not1832 : ~ @Equation1832 Fin7 refa915_inst.
Proof. unfold Equation1832. intro H. specialize (H F7_0). unfold magma_op, refa915_inst, refa915_op in H. discriminate H. Qed.

Lemma refa915_not2035 : ~ @Equation2035 Fin7 refa915_inst.
Proof. unfold Equation2035. intro H. specialize (H F7_0). unfold magma_op, refa915_inst, refa915_op in H. discriminate H. Qed.

Lemma refa915_not2238 : ~ @Equation2238 Fin7 refa915_inst.
Proof. unfold Equation2238. intro H. specialize (H F7_0). unfold magma_op, refa915_inst, refa915_op in H. discriminate H. Qed.

Lemma refa915_not2441 : ~ @Equation2441 Fin7 refa915_inst.
Proof. unfold Equation2441. intro H. specialize (H F7_0). unfold magma_op, refa915_inst, refa915_op in H. discriminate H. Qed.

Lemma refa915_not2847 : ~ @Equation2847 Fin7 refa915_inst.
Proof. unfold Equation2847. intro H. specialize (H F7_0). unfold magma_op, refa915_inst, refa915_op in H. discriminate H. Qed.

Lemma refa915_not3050 : ~ @Equation3050 Fin7 refa915_inst.
Proof. unfold Equation3050. intro H. specialize (H F7_0). unfold magma_op, refa915_inst, refa915_op in H. discriminate H. Qed.

Lemma refa915_not3659 : ~ @Equation3659 Fin7 refa915_inst.
Proof. unfold Equation3659. intro H. specialize (H F7_0). unfold magma_op, refa915_inst, refa915_op in H. discriminate H. Qed.

Lemma refa915_not4380 : ~ @Equation4380 Fin7 refa915_inst.
Proof. unfold Equation4380. intro H. specialize (H F7_0). unfold magma_op, refa915_inst, refa915_op in H. discriminate H. Qed.

(** ---- refa916 (Fin5) ---- *)

Definition refa916_op (x y : Fin5) : Fin5 :=
  match x, y with
  | F5_0, F5_0 => F5_1 | F5_0, F5_1 => F5_0 | F5_0, F5_2 => F5_3 | F5_0, F5_3 => F5_4 | F5_0, F5_4 => F5_2
  | F5_1, F5_0 => F5_2 | F5_1, F5_1 => F5_3 | F5_1, F5_2 => F5_2 | F5_1, F5_3 => F5_1 | F5_1, F5_4 => F5_0
  | F5_2, F5_0 => F5_4 | F5_2, F5_1 => F5_4 | F5_2, F5_2 => F5_2 | F5_2, F5_3 => F5_4 | F5_2, F5_4 => F5_2
  | F5_3, F5_0 => F5_0 | F5_3, F5_1 => F5_1 | F5_3, F5_2 => F5_0 | F5_3, F5_3 => F5_3 | F5_3, F5_4 => F5_2
  | F5_4, F5_0 => F5_3 | F5_4, F5_1 => F5_3 | F5_4, F5_2 => F5_1 | F5_4, F5_3 => F5_0 | F5_4, F5_4 => F5_4
  end.

#[local] Instance refa916_inst : Magma Fin5 := {| magma_op := refa916_op |}.

Lemma refa916_sat1885 : @Equation1885 Fin5 refa916_inst.
Proof. unfold Equation1885, magma_op, refa916_inst, refa916_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa916_not1629 : ~ @Equation1629 Fin5 refa916_inst.
Proof. unfold Equation1629. intro H. specialize (H F5_0). unfold magma_op, refa916_inst, refa916_op in H. discriminate H. Qed.

Lemma refa916_not3050 : ~ @Equation3050 Fin5 refa916_inst.
Proof. unfold Equation3050. intro H. specialize (H F5_0). unfold magma_op, refa916_inst, refa916_op in H. discriminate H. Qed.

(** ---- refa917 (Fin7) ---- *)

Definition refa917_op (x y : Fin7) : Fin7 :=
  match x, y with
  | F7_0, F7_0 => F7_0 | F7_0, F7_1 => F7_2 | F7_0, F7_2 => F7_5 | F7_0, F7_3 => F7_0 | F7_0, F7_4 => F7_6 | F7_0, F7_5 => F7_2 | F7_0, F7_6 => F7_4
  | F7_1, F7_0 => F7_3 | F7_1, F7_1 => F7_3 | F7_1, F7_2 => F7_3 | F7_1, F7_3 => F7_3 | F7_1, F7_4 => F7_3 | F7_1, F7_5 => F7_3 | F7_1, F7_6 => F7_3
  | F7_2, F7_0 => F7_4 | F7_2, F7_1 => F7_6 | F7_2, F7_2 => F7_2 | F7_2, F7_3 => F7_2 | F7_2, F7_4 => F7_0 | F7_2, F7_5 => F7_6 | F7_2, F7_6 => F7_5
  | F7_3, F7_0 => F7_1 | F7_3, F7_1 => F7_1 | F7_3, F7_2 => F7_1 | F7_3, F7_3 => F7_1 | F7_3, F7_4 => F7_1 | F7_3, F7_5 => F7_1 | F7_3, F7_6 => F7_1
  | F7_4, F7_0 => F7_5 | F7_4, F7_1 => F7_0 | F7_4, F7_2 => F7_6 | F7_4, F7_3 => F7_4 | F7_4, F7_4 => F7_4 | F7_4, F7_5 => F7_0 | F7_4, F7_6 => F7_2
  | F7_5, F7_0 => F7_6 | F7_5, F7_1 => F7_5 | F7_5, F7_2 => F7_4 | F7_5, F7_3 => F7_5 | F7_5, F7_4 => F7_2 | F7_5, F7_5 => F7_5 | F7_5, F7_6 => F7_0
  | F7_6, F7_0 => F7_2 | F7_6, F7_1 => F7_4 | F7_6, F7_2 => F7_0 | F7_6, F7_3 => F7_6 | F7_6, F7_4 => F7_5 | F7_6, F7_5 => F7_4 | F7_6, F7_6 => F7_6
  end.

#[local] Instance refa917_inst : Magma Fin7 := {| magma_op := refa917_op |}.

Lemma refa917_sat2450 : @Equation2450 Fin7 refa917_inst.
Proof. unfold Equation2450, magma_op, refa917_inst, refa917_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa917_not3319 : ~ @Equation3319 Fin7 refa917_inst.
Proof. unfold Equation3319. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa917_inst, refa917_op in H. discriminate H. Qed.

(** ---- refa918 (Fin11) ---- *)

Definition refa918_op (x y : Fin11) : Fin11 :=
  match x, y with
  | F11_0, F11_0 => F11_2 | F11_0, F11_1 => F11_2 | F11_0, F11_2 => F11_2 | F11_0, F11_3 => F11_3 | F11_0, F11_4 => F11_9 | F11_0, F11_5 => F11_5 | F11_0, F11_6 => F11_6 | F11_0, F11_7 => F11_5 | F11_0, F11_8 => F11_9 | F11_0, F11_9 => F11_9 | F11_0, F11_10 => F11_2
  | F11_1, F11_0 => F11_8 | F11_1, F11_1 => F11_6 | F11_1, F11_2 => F11_3 | F11_1, F11_3 => F11_3 | F11_1, F11_4 => F11_8 | F11_1, F11_5 => F11_5 | F11_1, F11_6 => F11_6 | F11_1, F11_7 => F11_7 | F11_1, F11_8 => F11_8 | F11_1, F11_9 => F11_9 | F11_1, F11_10 => F11_3
  | F11_2, F11_0 => F11_0 | F11_2, F11_1 => F11_4 | F11_2, F11_2 => F11_6 | F11_2, F11_3 => F11_6 | F11_2, F11_4 => F11_4 | F11_2, F11_5 => F11_6 | F11_2, F11_6 => F11_6 | F11_2, F11_7 => F11_7 | F11_2, F11_8 => F11_8 | F11_2, F11_9 => F11_9 | F11_2, F11_10 => F11_4
  | F11_3, F11_0 => F11_4 | F11_3, F11_1 => F11_1 | F11_3, F11_2 => F11_1 | F11_3, F11_3 => F11_7 | F11_3, F11_4 => F11_4 | F11_3, F11_5 => F11_7 | F11_3, F11_6 => F11_7 | F11_3, F11_7 => F11_7 | F11_3, F11_8 => F11_7 | F11_3, F11_9 => F11_7 | F11_3, F11_10 => F11_1
  | F11_4, F11_0 => F11_9 | F11_4, F11_1 => F11_2 | F11_4, F11_2 => F11_2 | F11_4, F11_3 => F11_3 | F11_4, F11_4 => F11_9 | F11_4, F11_5 => F11_5 | F11_4, F11_6 => F11_6 | F11_4, F11_7 => F11_9 | F11_4, F11_8 => F11_9 | F11_4, F11_9 => F11_9 | F11_4, F11_10 => F11_2
  | F11_5, F11_0 => F11_0 | F11_5, F11_1 => F11_1 | F11_5, F11_2 => F11_1 | F11_5, F11_3 => F11_6 | F11_5, F11_4 => F11_4 | F11_5, F11_5 => F11_1 | F11_5, F11_6 => F11_6 | F11_5, F11_7 => F11_7 | F11_5, F11_8 => F11_8 | F11_5, F11_9 => F11_9 | F11_5, F11_10 => F11_1
  | F11_6, F11_0 => F11_0 | F11_6, F11_1 => F11_1 | F11_6, F11_2 => F11_2 | F11_6, F11_3 => F11_5 | F11_6, F11_4 => F11_4 | F11_6, F11_5 => F11_5 | F11_6, F11_6 => F11_7 | F11_6, F11_7 => F11_7 | F11_6, F11_8 => F11_7 | F11_6, F11_9 => F11_7 | F11_6, F11_10 => F11_10
  | F11_7, F11_0 => F11_10 | F11_7, F11_1 => F11_1 | F11_7, F11_2 => F11_2 | F11_7, F11_3 => F11_3 | F11_7, F11_4 => F11_1 | F11_7, F11_5 => F11_5 | F11_7, F11_6 => F11_6 | F11_7, F11_7 => F11_1 | F11_7, F11_8 => F11_9 | F11_7, F11_9 => F11_9 | F11_7, F11_10 => F11_10
  | F11_8, F11_0 => F11_10 | F11_8, F11_1 => F11_1 | F11_8, F11_2 => F11_2 | F11_8, F11_3 => F11_5 | F11_8, F11_4 => F11_1 | F11_8, F11_5 => F11_5 | F11_8, F11_6 => F11_5 | F11_8, F11_7 => F11_5 | F11_8, F11_8 => F11_5 | F11_8, F11_9 => F11_5 | F11_8, F11_10 => F11_10
  | F11_9, F11_0 => F11_0 | F11_9, F11_1 => F11_1 | F11_9, F11_2 => F11_2 | F11_9, F11_3 => F11_5 | F11_9, F11_4 => F11_4 | F11_9, F11_5 => F11_5 | F11_9, F11_6 => F11_5 | F11_9, F11_7 => F11_7 | F11_9, F11_8 => F11_7 | F11_9, F11_9 => F11_5 | F11_9, F11_10 => F11_10
  | F11_10, F11_0 => F11_8 | F11_10, F11_1 => F11_6 | F11_10, F11_2 => F11_6 | F11_10, F11_3 => F11_6 | F11_10, F11_4 => F11_8 | F11_10, F11_5 => F11_6 | F11_10, F11_6 => F11_6 | F11_10, F11_7 => F11_7 | F11_10, F11_8 => F11_8 | F11_10, F11_9 => F11_9 | F11_10, F11_10 => F11_6
  end.

#[local] Instance refa918_inst : Magma Fin11 := {| magma_op := refa918_op |}.

Lemma refa918_sat2712 : @Equation2712 Fin11 refa918_inst.
Proof. unfold Equation2712, magma_op, refa918_inst, refa918_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa918_not2253 : ~ @Equation2253 Fin11 refa918_inst.
Proof. unfold Equation2253. intro H. specialize (H F11_0 F11_1). unfold magma_op, refa918_inst, refa918_op in H. discriminate H. Qed.

Lemma refa918_not2256 : ~ @Equation2256 Fin11 refa918_inst.
Proof. unfold Equation2256. intro H. specialize (H F11_0 F11_1). unfold magma_op, refa918_inst, refa918_op in H. discriminate H. Qed.

Lemma refa918_not3458 : ~ @Equation3458 Fin11 refa918_inst.
Proof. unfold Equation3458. intro H. specialize (H F11_0 F11_3). unfold magma_op, refa918_inst, refa918_op in H. discriminate H. Qed.

(** ---- refa919 (Fin6) ---- *)

Definition refa919_op (x y : Fin6) : Fin6 :=
  match x, y with
  | F6_0, F6_0 => F6_1 | F6_0, F6_1 => F6_2 | F6_0, F6_2 => F6_3 | F6_0, F6_3 => F6_5 | F6_0, F6_4 => F6_2 | F6_0, F6_5 => F6_4
  | F6_1, F6_0 => F6_0 | F6_1, F6_1 => F6_1 | F6_1, F6_2 => F6_2 | F6_1, F6_3 => F6_3 | F6_1, F6_4 => F6_4 | F6_1, F6_5 => F6_5
  | F6_2, F6_0 => F6_5 | F6_2, F6_1 => F6_3 | F6_2, F6_2 => F6_1 | F6_2, F6_3 => F6_4 | F6_2, F6_4 => F6_0 | F6_2, F6_5 => F6_3
  | F6_3, F6_0 => F6_4 | F6_3, F6_1 => F6_4 | F6_3, F6_2 => F6_0 | F6_3, F6_3 => F6_1 | F6_3, F6_4 => F6_5 | F6_3, F6_5 => F6_2
  | F6_4, F6_0 => F6_3 | F6_4, F6_1 => F6_5 | F6_4, F6_2 => F6_5 | F6_4, F6_3 => F6_2 | F6_4, F6_4 => F6_1 | F6_4, F6_5 => F6_0
  | F6_5, F6_0 => F6_2 | F6_5, F6_1 => F6_0 | F6_5, F6_2 => F6_4 | F6_5, F6_3 => F6_0 | F6_5, F6_4 => F6_3 | F6_5, F6_5 => F6_1
  end.

#[local] Instance refa919_inst : Magma Fin6 := {| magma_op := refa919_op |}.

Lemma refa919_sat3113 : @Equation3113 Fin6 refa919_inst.
Proof. unfold Equation3113, magma_op, refa919_inst, refa919_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa919_not1632 : ~ @Equation1632 Fin6 refa919_inst.
Proof. unfold Equation1632. intro H. specialize (H F6_0 F6_1). unfold magma_op, refa919_inst, refa919_op in H. discriminate H. Qed.

Lemma refa919_not1654 : ~ @Equation1654 Fin6 refa919_inst.
Proof. unfold Equation1654. intro H. specialize (H F6_0 F6_1). unfold magma_op, refa919_inst, refa919_op in H. discriminate H. Qed.

Lemma refa919_not1832 : ~ @Equation1832 Fin6 refa919_inst.
Proof. unfold Equation1832. intro H. specialize (H F6_0). unfold magma_op, refa919_inst, refa919_op in H. discriminate H. Qed.

Lemma refa919_not2449 : ~ @Equation2449 Fin6 refa919_inst.
Proof. unfold Equation2449. intro H. specialize (H F6_0 F6_1). unfold magma_op, refa919_inst, refa919_op in H. discriminate H. Qed.

Lemma refa919_not2457 : ~ @Equation2457 Fin6 refa919_inst.
Proof. unfold Equation2457. intro H. specialize (H F6_0 F6_1). unfold magma_op, refa919_inst, refa919_op in H. discriminate H. Qed.

Lemma refa919_not2470 : ~ @Equation2470 Fin6 refa919_inst.
Proof. unfold Equation2470. intro H. specialize (H F6_0 F6_1). unfold magma_op, refa919_inst, refa919_op in H. discriminate H. Qed.

Lemma refa919_not3079 : ~ @Equation3079 Fin6 refa919_inst.
Proof. unfold Equation3079. intro H. specialize (H F6_0 F6_1). unfold magma_op, refa919_inst, refa919_op in H. discriminate H. Qed.

(** ---- refa92 (Fin3) ---- *)

Definition refa92_op (x y : Fin3) : Fin3 :=
  match x, y with
  | F3_0, F3_0 => F3_0 | F3_0, F3_1 => F3_0 | F3_0, F3_2 => F3_0
  | F3_1, F3_0 => F3_1 | F3_1, F3_1 => F3_1 | F3_1, F3_2 => F3_0
  | F3_2, F3_0 => F3_2 | F3_2, F3_1 => F3_2 | F3_2, F3_2 => F3_1
  end.

#[local] Instance refa92_inst : Magma Fin3 := {| magma_op := refa92_op |}.

Lemma refa92_sat1053 : @Equation1053 Fin3 refa92_inst.
Proof. unfold Equation1053, magma_op, refa92_inst, refa92_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa92_sat1271 : @Equation1271 Fin3 refa92_inst.
Proof. unfold Equation1271, magma_op, refa92_inst, refa92_op. intros x y z w. destruct x, y, z, w; reflexivity. Qed.

Lemma refa92_sat3322 : @Equation3322 Fin3 refa92_inst.
Proof. unfold Equation3322, magma_op, refa92_inst, refa92_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa92_sat3724 : @Equation3724 Fin3 refa92_inst.
Proof. unfold Equation3724, magma_op, refa92_inst, refa92_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa92_sat3925 : @Equation3925 Fin3 refa92_inst.
Proof. unfold Equation3925, magma_op, refa92_inst, refa92_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa92_sat4673 : @Equation4673 Fin3 refa92_inst.
Proof. unfold Equation4673, magma_op, refa92_inst, refa92_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa92_not426 : ~ @Equation426 Fin3 refa92_inst.
Proof. unfold Equation426. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa92_inst, refa92_op in H. discriminate H. Qed.

Lemma refa92_not427 : ~ @Equation427 Fin3 refa92_inst.
Proof. unfold Equation427. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa92_inst, refa92_op in H. discriminate H. Qed.

Lemma refa92_not429 : ~ @Equation429 Fin3 refa92_inst.
Proof. unfold Equation429. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa92_inst, refa92_op in H. discriminate H. Qed.

Lemma refa92_not430 : ~ @Equation430 Fin3 refa92_inst.
Proof. unfold Equation430. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa92_inst, refa92_op in H. discriminate H. Qed.

Lemma refa92_not832 : ~ @Equation832 Fin3 refa92_inst.
Proof. unfold Equation832. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa92_inst, refa92_op in H. discriminate H. Qed.

Lemma refa92_not833 : ~ @Equation833 Fin3 refa92_inst.
Proof. unfold Equation833. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa92_inst, refa92_op in H. discriminate H. Qed.

Lemma refa92_not836 : ~ @Equation836 Fin3 refa92_inst.
Proof. unfold Equation836. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa92_inst, refa92_op in H. discriminate H. Qed.

Lemma refa92_not1035 : ~ @Equation1035 Fin3 refa92_inst.
Proof. unfold Equation1035. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa92_inst, refa92_op in H. discriminate H. Qed.

Lemma refa92_not1038 : ~ @Equation1038 Fin3 refa92_inst.
Proof. unfold Equation1038. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa92_inst, refa92_op in H. discriminate H. Qed.

Lemma refa92_not1048 : ~ @Equation1048 Fin3 refa92_inst.
Proof. unfold Equation1048. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa92_inst, refa92_op in H. discriminate H. Qed.

Lemma refa92_not1238 : ~ @Equation1238 Fin3 refa92_inst.
Proof. unfold Equation1238. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa92_inst, refa92_op in H. discriminate H. Qed.

Lemma refa92_not1834 : ~ @Equation1834 Fin3 refa92_inst.
Proof. unfold Equation1834. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa92_inst, refa92_op in H. discriminate H. Qed.

Lemma refa92_not1847 : ~ @Equation1847 Fin3 refa92_inst.
Proof. unfold Equation1847. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa92_inst, refa92_op in H. discriminate H. Qed.

Lemma refa92_not1851 : ~ @Equation1851 Fin3 refa92_inst.
Proof. unfold Equation1851. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa92_inst, refa92_op in H. discriminate H. Qed.

Lemma refa92_not1860 : ~ @Equation1860 Fin3 refa92_inst.
Proof. unfold Equation1860. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa92_inst, refa92_op in H. discriminate H. Qed.

Lemma refa92_not3278 : ~ @Equation3278 Fin3 refa92_inst.
Proof. unfold Equation3278. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa92_inst, refa92_op in H. discriminate H. Qed.

Lemma refa92_not3279 : ~ @Equation3279 Fin3 refa92_inst.
Proof. unfold Equation3279. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa92_inst, refa92_op in H. discriminate H. Qed.

Lemma refa92_not3306 : ~ @Equation3306 Fin3 refa92_inst.
Proof. unfold Equation3306. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa92_inst, refa92_op in H. discriminate H. Qed.

Lemma refa92_not3318 : ~ @Equation3318 Fin3 refa92_inst.
Proof. unfold Equation3318. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa92_inst, refa92_op in H. discriminate H. Qed.

Lemma refa92_not3660 : ~ @Equation3660 Fin3 refa92_inst.
Proof. unfold Equation3660. intro H. specialize (H F3_2 F3_0). unfold magma_op, refa92_inst, refa92_op in H. discriminate H. Qed.

Lemma refa92_not3661 : ~ @Equation3661 Fin3 refa92_inst.
Proof. unfold Equation3661. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa92_inst, refa92_op in H. discriminate H. Qed.

Lemma refa92_not3665 : ~ @Equation3665 Fin3 refa92_inst.
Proof. unfold Equation3665. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa92_inst, refa92_op in H. discriminate H. Qed.

Lemma refa92_not3677 : ~ @Equation3677 Fin3 refa92_inst.
Proof. unfold Equation3677. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa92_inst, refa92_op in H. discriminate H. Qed.

Lemma refa92_not3684 : ~ @Equation3684 Fin3 refa92_inst.
Proof. unfold Equation3684. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa92_inst, refa92_op in H. discriminate H. Qed.

Lemma refa92_not3685 : ~ @Equation3685 Fin3 refa92_inst.
Proof. unfold Equation3685. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa92_inst, refa92_op in H. discriminate H. Qed.

Lemma refa92_not3687 : ~ @Equation3687 Fin3 refa92_inst.
Proof. unfold Equation3687. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa92_inst, refa92_op in H. discriminate H. Qed.

Lemma refa92_not3864 : ~ @Equation3864 Fin3 refa92_inst.
Proof. unfold Equation3864. intro H. specialize (H F3_2 F3_0). unfold magma_op, refa92_inst, refa92_op in H. discriminate H. Qed.

Lemma refa92_not3865 : ~ @Equation3865 Fin3 refa92_inst.
Proof. unfold Equation3865. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa92_inst, refa92_op in H. discriminate H. Qed.

Lemma refa92_not3867 : ~ @Equation3867 Fin3 refa92_inst.
Proof. unfold Equation3867. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa92_inst, refa92_op in H. discriminate H. Qed.

Lemma refa92_not3878 : ~ @Equation3878 Fin3 refa92_inst.
Proof. unfold Equation3878. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa92_inst, refa92_op in H. discriminate H. Qed.

Lemma refa92_not3881 : ~ @Equation3881 Fin3 refa92_inst.
Proof. unfold Equation3881. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa92_inst, refa92_op in H. discriminate H. Qed.

Lemma refa92_not3887 : ~ @Equation3887 Fin3 refa92_inst.
Proof. unfold Equation3887. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa92_inst, refa92_op in H. discriminate H. Qed.

Lemma refa92_not3888 : ~ @Equation3888 Fin3 refa92_inst.
Proof. unfold Equation3888. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa92_inst, refa92_op in H. discriminate H. Qed.

Lemma refa92_not4065 : ~ @Equation4065 Fin3 refa92_inst.
Proof. unfold Equation4065. intro H. specialize (H F3_2). unfold magma_op, refa92_inst, refa92_op in H. discriminate H. Qed.

Lemma refa92_not4269 : ~ @Equation4269 Fin3 refa92_inst.
Proof. unfold Equation4269. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa92_inst, refa92_op in H. discriminate H. Qed.

Lemma refa92_not4293 : ~ @Equation4293 Fin3 refa92_inst.
Proof. unfold Equation4293. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa92_inst, refa92_op in H. discriminate H. Qed.

Lemma refa92_not4314 : ~ @Equation4314 Fin3 refa92_inst.
Proof. unfold Equation4314. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa92_inst, refa92_op in H. discriminate H. Qed.

Lemma refa92_not4583 : ~ @Equation4583 Fin3 refa92_inst.
Proof. unfold Equation4583. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa92_inst, refa92_op in H. discriminate H. Qed.

Lemma refa92_not4591 : ~ @Equation4591 Fin3 refa92_inst.
Proof. unfold Equation4591. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa92_inst, refa92_op in H. discriminate H. Qed.

Lemma refa92_not4606 : ~ @Equation4606 Fin3 refa92_inst.
Proof. unfold Equation4606. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa92_inst, refa92_op in H. discriminate H. Qed.

Lemma refa92_not4608 : ~ @Equation4608 Fin3 refa92_inst.
Proof. unfold Equation4608. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa92_inst, refa92_op in H. discriminate H. Qed.

Lemma refa92_not4622 : ~ @Equation4622 Fin3 refa92_inst.
Proof. unfold Equation4622. intro H. specialize (H F3_0 F3_0 F3_1). unfold magma_op, refa92_inst, refa92_op in H. discriminate H. Qed.

Lemma refa92_not4631 : ~ @Equation4631 Fin3 refa92_inst.
Proof. unfold Equation4631. intro H. specialize (H F3_1 F3_0 F3_2). unfold magma_op, refa92_inst, refa92_op in H. discriminate H. Qed.

Lemma refa92_not4636 : ~ @Equation4636 Fin3 refa92_inst.
Proof. unfold Equation4636. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa92_inst, refa92_op in H. discriminate H. Qed.

Lemma refa92_not4647 : ~ @Equation4647 Fin3 refa92_inst.
Proof. unfold Equation4647. intro H. specialize (H F3_0 F3_0 F3_1). unfold magma_op, refa92_inst, refa92_op in H. discriminate H. Qed.

(** ---- refa920 (Fin6) ---- *)

Definition refa920_op (x y : Fin6) : Fin6 :=
  match x, y with
  | F6_0, F6_0 => F6_1 | F6_0, F6_1 => F6_0 | F6_0, F6_2 => F6_5 | F6_0, F6_3 => F6_4 | F6_0, F6_4 => F6_3 | F6_0, F6_5 => F6_2
  | F6_1, F6_0 => F6_2 | F6_1, F6_1 => F6_1 | F6_1, F6_2 => F6_3 | F6_1, F6_3 => F6_4 | F6_1, F6_4 => F6_5 | F6_1, F6_5 => F6_0
  | F6_2, F6_0 => F6_3 | F6_2, F6_1 => F6_2 | F6_2, F6_2 => F6_1 | F6_2, F6_3 => F6_0 | F6_2, F6_4 => F6_5 | F6_2, F6_5 => F6_4
  | F6_3, F6_0 => F6_5 | F6_3, F6_1 => F6_3 | F6_3, F6_2 => F6_4 | F6_3, F6_3 => F6_1 | F6_3, F6_4 => F6_2 | F6_3, F6_5 => F6_0
  | F6_4, F6_0 => F6_2 | F6_4, F6_1 => F6_4 | F6_4, F6_2 => F6_0 | F6_4, F6_3 => F6_5 | F6_4, F6_4 => F6_1 | F6_4, F6_5 => F6_3
  | F6_5, F6_0 => F6_4 | F6_5, F6_1 => F6_5 | F6_5, F6_2 => F6_3 | F6_5, F6_3 => F6_2 | F6_5, F6_4 => F6_0 | F6_5, F6_5 => F6_1
  end.

#[local] Instance refa920_inst : Magma Fin6 := {| magma_op := refa920_op |}.

Lemma refa920_sat474 : @Equation474 Fin6 refa920_inst.
Proof. unfold Equation474, magma_op, refa920_inst, refa920_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa920_not419 : ~ @Equation419 Fin6 refa920_inst.
Proof. unfold Equation419. intro H. specialize (H F6_0 F6_1). unfold magma_op, refa920_inst, refa920_op in H. discriminate H. Qed.

Lemma refa920_not513 : ~ @Equation513 Fin6 refa920_inst.
Proof. unfold Equation513. intro H. specialize (H F6_0 F6_1). unfold magma_op, refa920_inst, refa920_op in H. discriminate H. Qed.

Lemma refa920_not1629 : ~ @Equation1629 Fin6 refa920_inst.
Proof. unfold Equation1629. intro H. specialize (H F6_0). unfold magma_op, refa920_inst, refa920_op in H. discriminate H. Qed.

(** ---- refa921 (Fin11) ---- *)

Definition refa921_op (x y : Fin11) : Fin11 :=
  match x, y with
  | F11_0, F11_0 => F11_2 | F11_0, F11_1 => F11_7 | F11_0, F11_2 => F11_0 | F11_0, F11_3 => F11_4 | F11_0, F11_4 => F11_6 | F11_0, F11_5 => F11_0 | F11_0, F11_6 => F11_0 | F11_0, F11_7 => F11_8 | F11_0, F11_8 => F11_7 | F11_0, F11_9 => F11_8 | F11_0, F11_10 => F11_0
  | F11_1, F11_0 => F11_2 | F11_1, F11_1 => F11_5 | F11_1, F11_2 => F11_4 | F11_1, F11_3 => F11_1 | F11_1, F11_4 => F11_2 | F11_1, F11_5 => F11_1 | F11_1, F11_6 => F11_1 | F11_1, F11_7 => F11_1 | F11_1, F11_8 => F11_5 | F11_1, F11_9 => F11_1 | F11_1, F11_10 => F11_1
  | F11_2, F11_0 => F11_2 | F11_2, F11_1 => F11_3 | F11_2, F11_2 => F11_5 | F11_2, F11_3 => F11_1 | F11_2, F11_4 => F11_2 | F11_2, F11_5 => F11_2 | F11_2, F11_6 => F11_2 | F11_2, F11_7 => F11_2 | F11_2, F11_8 => F11_5 | F11_2, F11_9 => F11_2 | F11_2, F11_10 => F11_1
  | F11_3, F11_0 => F11_3 | F11_3, F11_1 => F11_3 | F11_3, F11_2 => F11_5 | F11_3, F11_3 => F11_9 | F11_3, F11_4 => F11_3 | F11_3, F11_5 => F11_10 | F11_3, F11_6 => F11_10 | F11_3, F11_7 => F11_10 | F11_3, F11_8 => F11_5 | F11_3, F11_9 => F11_3 | F11_3, F11_10 => F11_5
  | F11_4, F11_0 => F11_6 | F11_4, F11_1 => F11_7 | F11_4, F11_2 => F11_4 | F11_4, F11_3 => F11_4 | F11_4, F11_4 => F11_6 | F11_4, F11_5 => F11_4 | F11_4, F11_6 => F11_4 | F11_4, F11_7 => F11_1 | F11_4, F11_8 => F11_7 | F11_4, F11_9 => F11_1 | F11_4, F11_10 => F11_4
  | F11_5, F11_0 => F11_5 | F11_5, F11_1 => F11_5 | F11_5, F11_2 => F11_5 | F11_5, F11_3 => F11_9 | F11_5, F11_4 => F11_5 | F11_5, F11_5 => F11_9 | F11_5, F11_6 => F11_10 | F11_5, F11_7 => F11_10 | F11_5, F11_8 => F11_5 | F11_5, F11_9 => F11_5 | F11_5, F11_10 => F11_5
  | F11_6, F11_0 => F11_6 | F11_6, F11_1 => F11_6 | F11_6, F11_2 => F11_6 | F11_6, F11_3 => F11_9 | F11_6, F11_4 => F11_6 | F11_6, F11_5 => F11_9 | F11_6, F11_6 => F11_10 | F11_6, F11_7 => F11_10 | F11_6, F11_8 => F11_6 | F11_6, F11_9 => F11_6 | F11_6, F11_10 => F11_6
  | F11_7, F11_0 => F11_6 | F11_7, F11_1 => F11_7 | F11_7, F11_2 => F11_7 | F11_7, F11_3 => F11_9 | F11_7, F11_4 => F11_6 | F11_7, F11_5 => F11_9 | F11_7, F11_6 => F11_9 | F11_7, F11_7 => F11_10 | F11_7, F11_8 => F11_7 | F11_7, F11_9 => F11_6 | F11_7, F11_10 => F11_7
  | F11_8, F11_0 => F11_2 | F11_8, F11_1 => F11_3 | F11_8, F11_2 => F11_4 | F11_8, F11_3 => F11_1 | F11_8, F11_4 => F11_2 | F11_8, F11_5 => F11_8 | F11_8, F11_6 => F11_8 | F11_8, F11_7 => F11_8 | F11_8, F11_8 => F11_5 | F11_8, F11_9 => F11_8 | F11_8, F11_10 => F11_1
  | F11_9, F11_0 => F11_10 | F11_9, F11_1 => F11_9 | F11_9, F11_2 => F11_9 | F11_9, F11_3 => F11_9 | F11_9, F11_4 => F11_6 | F11_9, F11_5 => F11_9 | F11_9, F11_6 => F11_9 | F11_9, F11_7 => F11_10 | F11_9, F11_8 => F11_9 | F11_9, F11_9 => F11_1 | F11_9, F11_10 => F11_9
  | F11_10, F11_0 => F11_10 | F11_10, F11_1 => F11_10 | F11_10, F11_2 => F11_5 | F11_10, F11_3 => F11_9 | F11_10, F11_4 => F11_10 | F11_10, F11_5 => F11_10 | F11_10, F11_6 => F11_10 | F11_10, F11_7 => F11_10 | F11_10, F11_8 => F11_5 | F11_10, F11_9 => F11_10 | F11_10, F11_10 => F11_1
  end.

#[local] Instance refa921_inst : Magma Fin11 := {| magma_op := refa921_op |}.

Lemma refa921_sat854 : @Equation854 Fin11 refa921_inst.
Proof. unfold Equation854, magma_op, refa921_inst, refa921_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa921_not1225 : ~ @Equation1225 Fin11 refa921_inst.
Proof. unfold Equation1225. intro H. specialize (H F11_0 F11_1). unfold magma_op, refa921_inst, refa921_op in H. discriminate H. Qed.

Lemma refa921_not1241 : ~ @Equation1241 Fin11 refa921_inst.
Proof. unfold Equation1241. intro H. specialize (H F11_0 F11_1). unfold magma_op, refa921_inst, refa921_op in H. discriminate H. Qed.

Lemma refa921_not3867 : ~ @Equation3867 Fin11 refa921_inst.
Proof. unfold Equation3867. intro H. specialize (H F11_0 F11_3). unfold magma_op, refa921_inst, refa921_op in H. discriminate H. Qed.

(** ---- refa925 (Fin12) ---- *)

Definition refa925_op (x y : Fin12) : Fin12 :=
  match x, y with
  | F12_0, F12_0 => F12_5 | F12_0, F12_1 => F12_11 | F12_0, F12_2 => F12_3 | F12_0, F12_3 => F12_5 | F12_0, F12_4 => F12_0 | F12_0, F12_5 => F12_0 | F12_0, F12_6 => F12_11 | F12_0, F12_7 => F12_6 | F12_0, F12_8 => F12_0 | F12_0, F12_9 => F12_0 | F12_0, F12_10 => F12_11 | F12_0, F12_11 => F12_6
  | F12_1, F12_0 => F12_4 | F12_1, F12_1 => F12_2 | F12_1, F12_2 => F12_1 | F12_1, F12_3 => F12_4 | F12_1, F12_4 => F12_1 | F12_1, F12_5 => F12_1 | F12_1, F12_6 => F12_4 | F12_1, F12_7 => F12_1 | F12_1, F12_8 => F12_1 | F12_1, F12_9 => F12_1 | F12_1, F12_10 => F12_4 | F12_1, F12_11 => F12_1
  | F12_2, F12_0 => F12_2 | F12_2, F12_1 => F12_2 | F12_2, F12_2 => F12_7 | F12_2, F12_3 => F12_2 | F12_2, F12_4 => F12_8 | F12_2, F12_5 => F12_4 | F12_2, F12_6 => F12_4 | F12_2, F12_7 => F12_2 | F12_2, F12_8 => F12_4 | F12_2, F12_9 => F12_8 | F12_2, F12_10 => F12_2 | F12_2, F12_11 => F12_8
  | F12_3, F12_0 => F12_5 | F12_3, F12_1 => F12_11 | F12_3, F12_2 => F12_3 | F12_3, F12_3 => F12_5 | F12_3, F12_4 => F12_3 | F12_3, F12_5 => F12_3 | F12_3, F12_6 => F12_11 | F12_3, F12_7 => F12_1 | F12_3, F12_8 => F12_3 | F12_3, F12_9 => F12_3 | F12_3, F12_10 => F12_11 | F12_3, F12_11 => F12_1
  | F12_4, F12_0 => F12_4 | F12_4, F12_1 => F12_4 | F12_4, F12_2 => F12_7 | F12_4, F12_3 => F12_4 | F12_4, F12_4 => F12_7 | F12_4, F12_5 => F12_4 | F12_4, F12_6 => F12_4 | F12_4, F12_7 => F12_4 | F12_4, F12_8 => F12_4 | F12_4, F12_9 => F12_8 | F12_4, F12_10 => F12_4 | F12_4, F12_11 => F12_8
  | F12_5, F12_0 => F12_5 | F12_5, F12_1 => F12_5 | F12_5, F12_2 => F12_7 | F12_5, F12_3 => F12_5 | F12_5, F12_4 => F12_5 | F12_5, F12_5 => F12_4 | F12_5, F12_6 => F12_4 | F12_5, F12_7 => F12_5 | F12_5, F12_8 => F12_10 | F12_5, F12_9 => F12_5 | F12_5, F12_10 => F12_5 | F12_5, F12_11 => F12_5
  | F12_6, F12_0 => F12_5 | F12_6, F12_1 => F12_5 | F12_6, F12_2 => F12_10 | F12_6, F12_3 => F12_5 | F12_6, F12_4 => F12_6 | F12_6, F12_5 => F12_10 | F12_6, F12_6 => F12_4 | F12_6, F12_7 => F12_6 | F12_6, F12_8 => F12_10 | F12_6, F12_9 => F12_6 | F12_6, F12_10 => F12_5 | F12_6, F12_11 => F12_6
  | F12_7, F12_0 => F12_9 | F12_7, F12_1 => F12_7 | F12_7, F12_2 => F12_7 | F12_7, F12_3 => F12_9 | F12_7, F12_4 => F12_7 | F12_7, F12_5 => F12_7 | F12_7, F12_6 => F12_7 | F12_7, F12_7 => F12_1 | F12_7, F12_8 => F12_7 | F12_7, F12_9 => F12_7 | F12_7, F12_10 => F12_7 | F12_7, F12_11 => F12_8
  | F12_8, F12_0 => F12_8 | F12_8, F12_1 => F12_8 | F12_8, F12_2 => F12_7 | F12_8, F12_3 => F12_8 | F12_8, F12_4 => F12_8 | F12_8, F12_5 => F12_4 | F12_8, F12_6 => F12_4 | F12_8, F12_7 => F12_8 | F12_8, F12_8 => F12_10 | F12_8, F12_9 => F12_8 | F12_8, F12_10 => F12_8 | F12_8, F12_11 => F12_8
  | F12_9, F12_0 => F12_9 | F12_9, F12_1 => F12_9 | F12_9, F12_2 => F12_7 | F12_9, F12_3 => F12_9 | F12_9, F12_4 => F12_7 | F12_9, F12_5 => F12_9 | F12_9, F12_6 => F12_9 | F12_9, F12_7 => F12_9 | F12_9, F12_8 => F12_9 | F12_9, F12_9 => F12_8 | F12_9, F12_10 => F12_9 | F12_9, F12_11 => F12_8
  | F12_10, F12_0 => F12_9 | F12_10, F12_1 => F12_4 | F12_10, F12_2 => F12_10 | F12_10, F12_3 => F12_4 | F12_10, F12_4 => F12_10 | F12_10, F12_5 => F12_10 | F12_10, F12_6 => F12_9 | F12_10, F12_7 => F12_10 | F12_10, F12_8 => F12_10 | F12_10, F12_9 => F12_10 | F12_10, F12_10 => F12_4 | F12_10, F12_11 => F12_10
  | F12_11, F12_0 => F12_9 | F12_11, F12_1 => F12_11 | F12_11, F12_2 => F12_7 | F12_11, F12_3 => F12_9 | F12_11, F12_4 => F12_7 | F12_11, F12_5 => F12_11 | F12_11, F12_6 => F12_11 | F12_11, F12_7 => F12_9 | F12_11, F12_8 => F12_11 | F12_11, F12_9 => F12_7 | F12_11, F12_10 => F12_11 | F12_11, F12_11 => F12_8
  end.

#[local] Instance refa925_inst : Magma Fin12 := {| magma_op := refa925_op |}.

Lemma refa925_sat854 : @Equation854 Fin12 refa925_inst.
Proof. unfold Equation854, magma_op, refa925_inst, refa925_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa925_not107 : ~ @Equation107 Fin12 refa925_inst.
Proof. unfold Equation107. intro H. specialize (H F12_0 F12_1). unfold magma_op, refa925_inst, refa925_op in H. discriminate H. Qed.

Lemma refa925_not1248 : ~ @Equation1248 Fin12 refa925_inst.
Proof. unfold Equation1248. intro H. specialize (H F12_0 F12_1). unfold magma_op, refa925_inst, refa925_op in H. discriminate H. Qed.

Lemma refa925_not1251 : ~ @Equation1251 Fin12 refa925_inst.
Proof. unfold Equation1251. intro H. specialize (H F12_0 F12_1). unfold magma_op, refa925_inst, refa925_op in H. discriminate H. Qed.

(** ---- refa927 (Fin8) ---- *)

Definition refa927_op (x y : Fin8) : Fin8 :=
  match x, y with
  | F8_0, F8_0 => F8_1 | F8_0, F8_1 => F8_0 | F8_0, F8_2 => F8_3 | F8_0, F8_3 => F8_2 | F8_0, F8_4 => F8_4 | F8_0, F8_5 => F8_5 | F8_0, F8_6 => F8_6 | F8_0, F8_7 => F8_7
  | F8_1, F8_0 => F8_2 | F8_1, F8_1 => F8_5 | F8_1, F8_2 => F8_3 | F8_1, F8_3 => F8_4 | F8_1, F8_4 => F8_0 | F8_1, F8_5 => F8_1 | F8_1, F8_6 => F8_6 | F8_1, F8_7 => F8_7
  | F8_2, F8_0 => F8_4 | F8_2, F8_1 => F8_1 | F8_2, F8_2 => F8_3 | F8_2, F8_3 => F8_2 | F8_2, F8_4 => F8_0 | F8_2, F8_5 => F8_5 | F8_2, F8_6 => F8_6 | F8_2, F8_7 => F8_7
  | F8_3, F8_0 => F8_1 | F8_3, F8_1 => F8_0 | F8_3, F8_2 => F8_3 | F8_3, F8_3 => F8_2 | F8_3, F8_4 => F8_7 | F8_3, F8_5 => F8_5 | F8_3, F8_6 => F8_6 | F8_3, F8_7 => F8_4
  | F8_4, F8_0 => F8_6 | F8_4, F8_1 => F8_1 | F8_4, F8_2 => F8_3 | F8_4, F8_3 => F8_2 | F8_4, F8_4 => F8_4 | F8_4, F8_5 => F8_5 | F8_4, F8_6 => F8_0 | F8_4, F8_7 => F8_7
  | F8_5, F8_0 => F8_4 | F8_5, F8_1 => F8_5 | F8_5, F8_2 => F8_0 | F8_5, F8_3 => F8_2 | F8_5, F8_4 => F8_3 | F8_5, F8_5 => F8_1 | F8_5, F8_6 => F8_6 | F8_5, F8_7 => F8_7
  | F8_6, F8_0 => F8_0 | F8_6, F8_1 => F8_1 | F8_6, F8_2 => F8_3 | F8_6, F8_3 => F8_2 | F8_6, F8_4 => F8_4 | F8_6, F8_5 => F8_5 | F8_6, F8_6 => F8_6 | F8_6, F8_7 => F8_7
  | F8_7, F8_0 => F8_1 | F8_7, F8_1 => F8_0 | F8_7, F8_2 => F8_3 | F8_7, F8_3 => F8_2 | F8_7, F8_4 => F8_4 | F8_7, F8_5 => F8_5 | F8_7, F8_6 => F8_6 | F8_7, F8_7 => F8_7
  end.

#[local] Instance refa927_inst : Magma Fin8 := {| magma_op := refa927_op |}.

Lemma refa927_sat1112 : @Equation1112 Fin8 refa927_inst.
Proof. unfold Equation1112, magma_op, refa927_inst, refa927_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa927_not1629 : ~ @Equation1629 Fin8 refa927_inst.
Proof. unfold Equation1629. intro H. specialize (H F8_0). unfold magma_op, refa927_inst, refa927_op in H. discriminate H. Qed.

(** ---- refa928 (Fin10) ---- *)

Definition refa928_op (x y : Fin10) : Fin10 :=
  match x, y with
  | F10_0, F10_0 => F10_5 | F10_0, F10_1 => F10_7 | F10_0, F10_2 => F10_2 | F10_0, F10_3 => F10_2 | F10_0, F10_4 => F10_3 | F10_0, F10_5 => F10_3 | F10_0, F10_6 => F10_5 | F10_0, F10_7 => F10_9 | F10_0, F10_8 => F10_9 | F10_0, F10_9 => F10_3
  | F10_1, F10_0 => F10_1 | F10_1, F10_1 => F10_5 | F10_1, F10_2 => F10_8 | F10_1, F10_3 => F10_2 | F10_1, F10_4 => F10_2 | F10_1, F10_5 => F10_6 | F10_1, F10_6 => F10_4 | F10_1, F10_7 => F10_9 | F10_1, F10_8 => F10_6 | F10_1, F10_9 => F10_3
  | F10_2, F10_0 => F10_1 | F10_2, F10_1 => F10_0 | F10_2, F10_2 => F10_4 | F10_2, F10_3 => F10_5 | F10_2, F10_4 => F10_3 | F10_2, F10_5 => F10_2 | F10_2, F10_6 => F10_8 | F10_2, F10_7 => F10_9 | F10_2, F10_8 => F10_6 | F10_2, F10_9 => F10_7
  | F10_3, F10_0 => F10_9 | F10_3, F10_1 => F10_0 | F10_3, F10_2 => F10_5 | F10_3, F10_3 => F10_4 | F10_3, F10_4 => F10_3 | F10_3, F10_5 => F10_2 | F10_3, F10_6 => F10_8 | F10_3, F10_7 => F10_1 | F10_3, F10_8 => F10_6 | F10_3, F10_9 => F10_7
  | F10_4, F10_0 => F10_9 | F10_4, F10_1 => F10_0 | F10_4, F10_2 => F10_5 | F10_4, F10_3 => F10_4 | F10_4, F10_4 => F10_3 | F10_4, F10_5 => F10_2 | F10_4, F10_6 => F10_8 | F10_4, F10_7 => F10_1 | F10_4, F10_8 => F10_6 | F10_4, F10_9 => F10_7
  | F10_5, F10_0 => F10_1 | F10_5, F10_1 => F10_0 | F10_5, F10_2 => F10_5 | F10_5, F10_3 => F10_4 | F10_5, F10_4 => F10_2 | F10_5, F10_5 => F10_3 | F10_5, F10_6 => F10_8 | F10_5, F10_7 => F10_9 | F10_5, F10_8 => F10_6 | F10_5, F10_9 => F10_7
  | F10_6, F10_0 => F10_2 | F10_6, F10_1 => F10_0 | F10_6, F10_2 => F10_4 | F10_6, F10_3 => F10_4 | F10_6, F10_4 => F10_2 | F10_6, F10_5 => F10_2 | F10_6, F10_6 => F10_3 | F10_6, F10_7 => F10_0 | F10_6, F10_8 => F10_6 | F10_6, F10_9 => F10_7
  | F10_7, F10_0 => F10_0 | F10_7, F10_1 => F10_0 | F10_7, F10_2 => F10_1 | F10_7, F10_3 => F10_8 | F10_7, F10_4 => F10_1 | F10_7, F10_5 => F10_8 | F10_7, F10_6 => F10_1 | F10_7, F10_7 => F10_8 | F10_7, F10_8 => F10_4 | F10_7, F10_9 => F10_0
  | F10_8, F10_0 => F10_5 | F10_8, F10_1 => F10_7 | F10_8, F10_2 => F10_4 | F10_8, F10_3 => F10_9 | F10_8, F10_4 => F10_6 | F10_8, F10_5 => F10_0 | F10_8, F10_6 => F10_8 | F10_8, F10_7 => F10_1 | F10_8, F10_8 => F10_2 | F10_8, F10_9 => F10_3
  | F10_9, F10_0 => F10_1 | F10_9, F10_1 => F10_7 | F10_9, F10_2 => F10_5 | F10_9, F10_3 => F10_4 | F10_9, F10_4 => F10_5 | F10_9, F10_5 => F10_5 | F10_9, F10_6 => F10_3 | F10_9, F10_7 => F10_9 | F10_9, F10_8 => F10_6 | F10_9, F10_9 => F10_2
  end.

#[local] Instance refa928_inst : Magma Fin10 := {| magma_op := refa928_op |}.

Lemma refa928_sat1728 : @Equation1728 Fin10 refa928_inst.
Proof. unfold Equation1728, magma_op, refa928_inst, refa928_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa928_not99 : ~ @Equation99 Fin10 refa928_inst.
Proof. unfold Equation99. intro H. specialize (H F10_0). unfold magma_op, refa928_inst, refa928_op in H. discriminate H. Qed.

(** ---- refa93 (Fin3) ---- *)

Definition refa93_op (x y : Fin3) : Fin3 :=
  match x, y with
  | F3_0, F3_0 => F3_0 | F3_0, F3_1 => F3_0 | F3_0, F3_2 => F3_2
  | F3_1, F3_0 => F3_2 | F3_1, F3_1 => F3_0 | F3_1, F3_2 => F3_0
  | F3_2, F3_0 => F3_0 | F3_2, F3_1 => F3_1 | F3_2, F3_2 => F3_1
  end.

#[local] Instance refa93_inst : Magma Fin3 := {| magma_op := refa93_op |}.

Lemma refa93_sat2469 : @Equation2469 Fin3 refa93_inst.
Proof. unfold Equation2469, magma_op, refa93_inst, refa93_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa93_not203 : ~ @Equation203 Fin3 refa93_inst.
Proof. unfold Equation203. intro H. specialize (H F3_2). unfold magma_op, refa93_inst, refa93_op in H. discriminate H. Qed.

Lemma refa93_not2238 : ~ @Equation2238 Fin3 refa93_inst.
Proof. unfold Equation2238. intro H. specialize (H F3_1). unfold magma_op, refa93_inst, refa93_op in H. discriminate H. Qed.

Lemma refa93_not2443 : ~ @Equation2443 Fin3 refa93_inst.
Proof. unfold Equation2443. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa93_inst, refa93_op in H. discriminate H. Qed.

Lemma refa93_not2449 : ~ @Equation2449 Fin3 refa93_inst.
Proof. unfold Equation2449. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa93_inst, refa93_op in H. discriminate H. Qed.

Lemma refa93_not3659 : ~ @Equation3659 Fin3 refa93_inst.
Proof. unfold Equation3659. intro H. specialize (H F3_2). unfold magma_op, refa93_inst, refa93_op in H. discriminate H. Qed.

(** ---- refa930 (Fin12) ---- *)

Definition refa930_op (x y : Fin12) : Fin12 :=
  match x, y with
  | F12_0, F12_0 => F12_1 | F12_0, F12_1 => F12_2 | F12_0, F12_2 => F12_0 | F12_0, F12_3 => F12_10 | F12_0, F12_4 => F12_11 | F12_0, F12_5 => F12_9 | F12_0, F12_6 => F12_7 | F12_0, F12_7 => F12_8 | F12_0, F12_8 => F12_6 | F12_0, F12_9 => F12_4 | F12_0, F12_10 => F12_5 | F12_0, F12_11 => F12_3
  | F12_1, F12_0 => F12_1 | F12_1, F12_1 => F12_2 | F12_1, F12_2 => F12_0 | F12_1, F12_3 => F12_10 | F12_1, F12_4 => F12_11 | F12_1, F12_5 => F12_9 | F12_1, F12_6 => F12_7 | F12_1, F12_7 => F12_8 | F12_1, F12_8 => F12_6 | F12_1, F12_9 => F12_4 | F12_1, F12_10 => F12_5 | F12_1, F12_11 => F12_3
  | F12_2, F12_0 => F12_1 | F12_2, F12_1 => F12_2 | F12_2, F12_2 => F12_0 | F12_2, F12_3 => F12_10 | F12_2, F12_4 => F12_11 | F12_2, F12_5 => F12_9 | F12_2, F12_6 => F12_7 | F12_2, F12_7 => F12_8 | F12_2, F12_8 => F12_6 | F12_2, F12_9 => F12_4 | F12_2, F12_10 => F12_5 | F12_2, F12_11 => F12_3
  | F12_3, F12_0 => F12_10 | F12_3, F12_1 => F12_5 | F12_3, F12_2 => F12_3 | F12_3, F12_3 => F12_7 | F12_3, F12_4 => F12_8 | F12_3, F12_5 => F12_0 | F12_3, F12_6 => F12_4 | F12_3, F12_7 => F12_11 | F12_3, F12_8 => F12_9 | F12_3, F12_9 => F12_1 | F12_3, F12_10 => F12_2 | F12_3, F12_11 => F12_6
  | F12_4, F12_0 => F12_4 | F12_4, F12_1 => F12_11 | F12_4, F12_2 => F12_3 | F12_4, F12_3 => F12_1 | F12_4, F12_4 => F12_8 | F12_4, F12_5 => F12_6 | F12_4, F12_6 => F12_10 | F12_4, F12_7 => F12_5 | F12_4, F12_8 => F12_9 | F12_4, F12_9 => F12_7 | F12_4, F12_10 => F12_2 | F12_4, F12_11 => F12_0
  | F12_5, F12_0 => F12_4 | F12_5, F12_1 => F12_5 | F12_5, F12_2 => F12_9 | F12_5, F12_3 => F12_7 | F12_5, F12_4 => F12_2 | F12_5, F12_5 => F12_6 | F12_5, F12_6 => F12_10 | F12_5, F12_7 => F12_11 | F12_5, F12_8 => F12_3 | F12_5, F12_9 => F12_1 | F12_5, F12_10 => F12_8 | F12_5, F12_11 => F12_0
  | F12_6, F12_0 => F12_7 | F12_6, F12_1 => F12_8 | F12_6, F12_2 => F12_6 | F12_6, F12_3 => F12_4 | F12_6, F12_4 => F12_5 | F12_6, F12_5 => F12_3 | F12_6, F12_6 => F12_1 | F12_6, F12_7 => F12_2 | F12_6, F12_8 => F12_0 | F12_6, F12_9 => F12_10 | F12_6, F12_10 => F12_11 | F12_6, F12_11 => F12_9
  | F12_7, F12_0 => F12_7 | F12_7, F12_1 => F12_8 | F12_7, F12_2 => F12_6 | F12_7, F12_3 => F12_4 | F12_7, F12_4 => F12_5 | F12_7, F12_5 => F12_3 | F12_7, F12_6 => F12_1 | F12_7, F12_7 => F12_2 | F12_7, F12_8 => F12_0 | F12_7, F12_9 => F12_10 | F12_7, F12_10 => F12_11 | F12_7, F12_11 => F12_9
  | F12_8, F12_0 => F12_7 | F12_8, F12_1 => F12_8 | F12_8, F12_2 => F12_6 | F12_8, F12_3 => F12_4 | F12_8, F12_4 => F12_5 | F12_8, F12_5 => F12_3 | F12_8, F12_6 => F12_1 | F12_8, F12_7 => F12_2 | F12_8, F12_8 => F12_0 | F12_8, F12_9 => F12_10 | F12_8, F12_10 => F12_11 | F12_8, F12_11 => F12_9
  | F12_9, F12_0 => F12_4 | F12_9, F12_1 => F12_11 | F12_9, F12_2 => F12_9 | F12_9, F12_3 => F12_1 | F12_9, F12_4 => F12_2 | F12_9, F12_5 => F12_6 | F12_9, F12_6 => F12_10 | F12_9, F12_7 => F12_5 | F12_9, F12_8 => F12_3 | F12_9, F12_9 => F12_7 | F12_9, F12_10 => F12_8 | F12_9, F12_11 => F12_0
  | F12_10, F12_0 => F12_10 | F12_10, F12_1 => F12_5 | F12_10, F12_2 => F12_9 | F12_10, F12_3 => F12_7 | F12_10, F12_4 => F12_2 | F12_10, F12_5 => F12_0 | F12_10, F12_6 => F12_4 | F12_10, F12_7 => F12_11 | F12_10, F12_8 => F12_3 | F12_10, F12_9 => F12_1 | F12_10, F12_10 => F12_8 | F12_10, F12_11 => F12_6
  | F12_11, F12_0 => F12_10 | F12_11, F12_1 => F12_11 | F12_11, F12_2 => F12_3 | F12_11, F12_3 => F12_1 | F12_11, F12_4 => F12_8 | F12_11, F12_5 => F12_0 | F12_11, F12_6 => F12_4 | F12_11, F12_7 => F12_5 | F12_11, F12_8 => F12_9 | F12_11, F12_9 => F12_7 | F12_11, F12_10 => F12_2 | F12_11, F12_11 => F12_6
  end.

#[local] Instance refa930_inst : Magma Fin12 := {| magma_op := refa930_op |}.

Lemma refa930_sat879 : @Equation879 Fin12 refa930_inst.
Proof. unfold Equation879, magma_op, refa930_inst, refa930_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa930_not4065 : ~ @Equation4065 Fin12 refa930_inst.
Proof. unfold Equation4065. intro H. specialize (H F12_3). unfold magma_op, refa930_inst, refa930_op in H. discriminate H. Qed.

(** ---- refa94 (Fin3) ---- *)

Definition refa94_op (x y : Fin3) : Fin3 :=
  match x, y with
  | F3_0, F3_0 => F3_0 | F3_0, F3_1 => F3_1 | F3_0, F3_2 => F3_1
  | F3_1, F3_0 => F3_1 | F3_1, F3_1 => F3_0 | F3_1, F3_2 => F3_1
  | F3_2, F3_0 => F3_1 | F3_2, F3_1 => F3_1 | F3_2, F3_2 => F3_0
  end.

#[local] Instance refa94_inst : Magma Fin3 := {| magma_op := refa94_op |}.

Lemma refa94_sat3756 : @Equation3756 Fin3 refa94_inst.
Proof. unfold Equation3756, magma_op, refa94_inst, refa94_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa94_sat3823 : @Equation3823 Fin3 refa94_inst.
Proof. unfold Equation3823, magma_op, refa94_inst, refa94_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa94_sat4388 : @Equation4388 Fin3 refa94_inst.
Proof. unfold Equation4388, magma_op, refa94_inst, refa94_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa94_sat4469 : @Equation4469 Fin3 refa94_inst.
Proof. unfold Equation4469, magma_op, refa94_inst, refa94_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa94_not3253 : ~ @Equation3253 Fin3 refa94_inst.
Proof. unfold Equation3253. intro H. specialize (H F3_2). unfold magma_op, refa94_inst, refa94_op in H. discriminate H. Qed.

Lemma refa94_not3456 : ~ @Equation3456 Fin3 refa94_inst.
Proof. unfold Equation3456. intro H. specialize (H F3_2). unfold magma_op, refa94_inst, refa94_op in H. discriminate H. Qed.

Lemma refa94_not3862 : ~ @Equation3862 Fin3 refa94_inst.
Proof. unfold Equation3862. intro H. specialize (H F3_2). unfold magma_op, refa94_inst, refa94_op in H. discriminate H. Qed.

Lemma refa94_not4065 : ~ @Equation4065 Fin3 refa94_inst.
Proof. unfold Equation4065. intro H. specialize (H F3_2). unfold magma_op, refa94_inst, refa94_op in H. discriminate H. Qed.

Lemma refa94_not4273 : ~ @Equation4273 Fin3 refa94_inst.
Proof. unfold Equation4273. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa94_inst, refa94_op in H. discriminate H. Qed.

Lemma refa94_not4275 : ~ @Equation4275 Fin3 refa94_inst.
Proof. unfold Equation4275. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa94_inst, refa94_op in H. discriminate H. Qed.

Lemma refa94_not4290 : ~ @Equation4290 Fin3 refa94_inst.
Proof. unfold Equation4290. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa94_inst, refa94_op in H. discriminate H. Qed.

Lemma refa94_not4320 : ~ @Equation4320 Fin3 refa94_inst.
Proof. unfold Equation4320. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa94_inst, refa94_op in H. discriminate H. Qed.

Lemma refa94_not4396 : ~ @Equation4396 Fin3 refa94_inst.
Proof. unfold Equation4396. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa94_inst, refa94_op in H. discriminate H. Qed.

Lemma refa94_not4598 : ~ @Equation4598 Fin3 refa94_inst.
Proof. unfold Equation4598. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa94_inst, refa94_op in H. discriminate H. Qed.

Lemma refa94_not4605 : ~ @Equation4605 Fin3 refa94_inst.
Proof. unfold Equation4605. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa94_inst, refa94_op in H. discriminate H. Qed.

Lemma refa94_not4647 : ~ @Equation4647 Fin3 refa94_inst.
Proof. unfold Equation4647. intro H. specialize (H F3_0 F3_0 F3_2). unfold magma_op, refa94_inst, refa94_op in H. discriminate H. Qed.

Lemma refa94_not4656 : ~ @Equation4656 Fin3 refa94_inst.
Proof. unfold Equation4656. intro H. specialize (H F3_0 F3_0 F3_2). unfold magma_op, refa94_inst, refa94_op in H. discriminate H. Qed.

(** ---- refa95 (Fin3) ---- *)

Definition refa95_op (x y : Fin3) : Fin3 :=
  match x, y with
  | F3_0, F3_0 => F3_1 | F3_0, F3_1 => F3_1 | F3_0, F3_2 => F3_1
  | F3_1, F3_0 => F3_2 | F3_1, F3_1 => F3_2 | F3_1, F3_2 => F3_2
  | F3_2, F3_0 => F3_0 | F3_2, F3_1 => F3_0 | F3_2, F3_2 => F3_0
  end.

#[local] Instance refa95_inst : Magma Fin3 := {| magma_op := refa95_op |}.

Lemma refa95_sat2048 : @Equation2048 Fin3 refa95_inst.
Proof. unfold Equation2048, magma_op, refa95_inst, refa95_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa95_not47 : ~ @Equation47 Fin3 refa95_inst.
Proof. unfold Equation47. intro H. specialize (H F3_0). unfold magma_op, refa95_inst, refa95_op in H. discriminate H. Qed.

Lemma refa95_not99 : ~ @Equation99 Fin3 refa95_inst.
Proof. unfold Equation99. intro H. specialize (H F3_0). unfold magma_op, refa95_inst, refa95_op in H. discriminate H. Qed.

Lemma refa95_not151 : ~ @Equation151 Fin3 refa95_inst.
Proof. unfold Equation151. intro H. specialize (H F3_0). unfold magma_op, refa95_inst, refa95_op in H. discriminate H. Qed.

Lemma refa95_not203 : ~ @Equation203 Fin3 refa95_inst.
Proof. unfold Equation203. intro H. specialize (H F3_0). unfold magma_op, refa95_inst, refa95_op in H. discriminate H. Qed.

Lemma refa95_not411 : ~ @Equation411 Fin3 refa95_inst.
Proof. unfold Equation411. intro H. specialize (H F3_0). unfold magma_op, refa95_inst, refa95_op in H. discriminate H. Qed.

Lemma refa95_not614 : ~ @Equation614 Fin3 refa95_inst.
Proof. unfold Equation614. intro H. specialize (H F3_0). unfold magma_op, refa95_inst, refa95_op in H. discriminate H. Qed.

Lemma refa95_not817 : ~ @Equation817 Fin3 refa95_inst.
Proof. unfold Equation817. intro H. specialize (H F3_0). unfold magma_op, refa95_inst, refa95_op in H. discriminate H. Qed.

Lemma refa95_not1020 : ~ @Equation1020 Fin3 refa95_inst.
Proof. unfold Equation1020. intro H. specialize (H F3_0). unfold magma_op, refa95_inst, refa95_op in H. discriminate H. Qed.

Lemma refa95_not1223 : ~ @Equation1223 Fin3 refa95_inst.
Proof. unfold Equation1223. intro H. specialize (H F3_0). unfold magma_op, refa95_inst, refa95_op in H. discriminate H. Qed.

Lemma refa95_not1426 : ~ @Equation1426 Fin3 refa95_inst.
Proof. unfold Equation1426. intro H. specialize (H F3_0). unfold magma_op, refa95_inst, refa95_op in H. discriminate H. Qed.

Lemma refa95_not1629 : ~ @Equation1629 Fin3 refa95_inst.
Proof. unfold Equation1629. intro H. specialize (H F3_0). unfold magma_op, refa95_inst, refa95_op in H. discriminate H. Qed.

Lemma refa95_not1832 : ~ @Equation1832 Fin3 refa95_inst.
Proof. unfold Equation1832. intro H. specialize (H F3_0). unfold magma_op, refa95_inst, refa95_op in H. discriminate H. Qed.

Lemma refa95_not2088 : ~ @Equation2088 Fin3 refa95_inst.
Proof. unfold Equation2088. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa95_inst, refa95_op in H. discriminate H. Qed.

Lemma refa95_not2124 : ~ @Equation2124 Fin3 refa95_inst.
Proof. unfold Equation2124. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa95_inst, refa95_op in H. discriminate H. Qed.

Lemma refa95_not2128 : ~ @Equation2128 Fin3 refa95_inst.
Proof. unfold Equation2128. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa95_inst, refa95_op in H. discriminate H. Qed.

Lemma refa95_not2238 : ~ @Equation2238 Fin3 refa95_inst.
Proof. unfold Equation2238. intro H. specialize (H F3_0). unfold magma_op, refa95_inst, refa95_op in H. discriminate H. Qed.

Lemma refa95_not2441 : ~ @Equation2441 Fin3 refa95_inst.
Proof. unfold Equation2441. intro H. specialize (H F3_0). unfold magma_op, refa95_inst, refa95_op in H. discriminate H. Qed.

Lemma refa95_not2697 : ~ @Equation2697 Fin3 refa95_inst.
Proof. unfold Equation2697. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa95_inst, refa95_op in H. discriminate H. Qed.

Lemma refa95_not2699 : ~ @Equation2699 Fin3 refa95_inst.
Proof. unfold Equation2699. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa95_inst, refa95_op in H. discriminate H. Qed.

Lemma refa95_not2710 : ~ @Equation2710 Fin3 refa95_inst.
Proof. unfold Equation2710. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa95_inst, refa95_op in H. discriminate H. Qed.

Lemma refa95_not2744 : ~ @Equation2744 Fin3 refa95_inst.
Proof. unfold Equation2744. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa95_inst, refa95_op in H. discriminate H. Qed.

Lemma refa95_not2746 : ~ @Equation2746 Fin3 refa95_inst.
Proof. unfold Equation2746. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa95_inst, refa95_op in H. discriminate H. Qed.

Lemma refa95_not2900 : ~ @Equation2900 Fin3 refa95_inst.
Proof. unfold Equation2900. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa95_inst, refa95_op in H. discriminate H. Qed.

Lemma refa95_not2902 : ~ @Equation2902 Fin3 refa95_inst.
Proof. unfold Equation2902. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa95_inst, refa95_op in H. discriminate H. Qed.

Lemma refa95_not2909 : ~ @Equation2909 Fin3 refa95_inst.
Proof. unfold Equation2909. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa95_inst, refa95_op in H. discriminate H. Qed.

Lemma refa95_not2940 : ~ @Equation2940 Fin3 refa95_inst.
Proof. unfold Equation2940. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa95_inst, refa95_op in H. discriminate H. Qed.

Lemma refa95_not2947 : ~ @Equation2947 Fin3 refa95_inst.
Proof. unfold Equation2947. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa95_inst, refa95_op in H. discriminate H. Qed.

Lemma refa95_not2949 : ~ @Equation2949 Fin3 refa95_inst.
Proof. unfold Equation2949. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa95_inst, refa95_op in H. discriminate H. Qed.

Lemma refa95_not3050 : ~ @Equation3050 Fin3 refa95_inst.
Proof. unfold Equation3050. intro H. specialize (H F3_0). unfold magma_op, refa95_inst, refa95_op in H. discriminate H. Qed.

Lemma refa95_not3271 : ~ @Equation3271 Fin3 refa95_inst.
Proof. unfold Equation3271. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa95_inst, refa95_op in H. discriminate H. Qed.

Lemma refa95_not3278 : ~ @Equation3278 Fin3 refa95_inst.
Proof. unfold Equation3278. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa95_inst, refa95_op in H. discriminate H. Qed.

Lemma refa95_not3342 : ~ @Equation3342 Fin3 refa95_inst.
Proof. unfold Equation3342. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa95_inst, refa95_op in H. discriminate H. Qed.

Lemma refa95_not3346 : ~ @Equation3346 Fin3 refa95_inst.
Proof. unfold Equation3346. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa95_inst, refa95_op in H. discriminate H. Qed.

Lemma refa95_not3353 : ~ @Equation3353 Fin3 refa95_inst.
Proof. unfold Equation3353. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa95_inst, refa95_op in H. discriminate H. Qed.

Lemma refa95_not3472 : ~ @Equation3472 Fin3 refa95_inst.
Proof. unfold Equation3472. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa95_inst, refa95_op in H. discriminate H. Qed.

Lemma refa95_not3474 : ~ @Equation3474 Fin3 refa95_inst.
Proof. unfold Equation3474. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa95_inst, refa95_op in H. discriminate H. Qed.

Lemma refa95_not3481 : ~ @Equation3481 Fin3 refa95_inst.
Proof. unfold Equation3481. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa95_inst, refa95_op in H. discriminate H. Qed.

Lemma refa95_not3545 : ~ @Equation3545 Fin3 refa95_inst.
Proof. unfold Equation3545. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa95_inst, refa95_op in H. discriminate H. Qed.

Lemma refa95_not3549 : ~ @Equation3549 Fin3 refa95_inst.
Proof. unfold Equation3549. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa95_inst, refa95_op in H. discriminate H. Qed.

Lemma refa95_not3558 : ~ @Equation3558 Fin3 refa95_inst.
Proof. unfold Equation3558. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa95_inst, refa95_op in H. discriminate H. Qed.

Lemma refa95_not3659 : ~ @Equation3659 Fin3 refa95_inst.
Proof. unfold Equation3659. intro H. specialize (H F3_0). unfold magma_op, refa95_inst, refa95_op in H. discriminate H. Qed.

Lemma refa95_not3862 : ~ @Equation3862 Fin3 refa95_inst.
Proof. unfold Equation3862. intro H. specialize (H F3_0). unfold magma_op, refa95_inst, refa95_op in H. discriminate H. Qed.

Lemma refa95_not4065 : ~ @Equation4065 Fin3 refa95_inst.
Proof. unfold Equation4065. intro H. specialize (H F3_0). unfold magma_op, refa95_inst, refa95_op in H. discriminate H. Qed.

Lemma refa95_not4273 : ~ @Equation4273 Fin3 refa95_inst.
Proof. unfold Equation4273. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa95_inst, refa95_op in H. discriminate H. Qed.

Lemma refa95_not4275 : ~ @Equation4275 Fin3 refa95_inst.
Proof. unfold Equation4275. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa95_inst, refa95_op in H. discriminate H. Qed.

Lemma refa95_not4290 : ~ @Equation4290 Fin3 refa95_inst.
Proof. unfold Equation4290. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa95_inst, refa95_op in H. discriminate H. Qed.

Lemma refa95_not4320 : ~ @Equation4320 Fin3 refa95_inst.
Proof. unfold Equation4320. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa95_inst, refa95_op in H. discriminate H. Qed.

Lemma refa95_not4380 : ~ @Equation4380 Fin3 refa95_inst.
Proof. unfold Equation4380. intro H. specialize (H F3_0). unfold magma_op, refa95_inst, refa95_op in H. discriminate H. Qed.

Lemma refa95_not4588 : ~ @Equation4588 Fin3 refa95_inst.
Proof. unfold Equation4588. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa95_inst, refa95_op in H. discriminate H. Qed.

Lemma refa95_not4590 : ~ @Equation4590 Fin3 refa95_inst.
Proof. unfold Equation4590. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa95_inst, refa95_op in H. discriminate H. Qed.

Lemma refa95_not4605 : ~ @Equation4605 Fin3 refa95_inst.
Proof. unfold Equation4605. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa95_inst, refa95_op in H. discriminate H. Qed.

Lemma refa95_not4635 : ~ @Equation4635 Fin3 refa95_inst.
Proof. unfold Equation4635. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa95_inst, refa95_op in H. discriminate H. Qed.

(** ---- refa96 (Fin3) ---- *)

Definition refa96_op (x y : Fin3) : Fin3 :=
  match x, y with
  | F3_0, F3_0 => F3_0 | F3_0, F3_1 => F3_1 | F3_0, F3_2 => F3_2
  | F3_1, F3_0 => F3_0 | F3_1, F3_1 => F3_0 | F3_1, F3_2 => F3_1
  | F3_2, F3_0 => F3_1 | F3_2, F3_1 => F3_0 | F3_2, F3_2 => F3_0
  end.

#[local] Instance refa96_inst : Magma Fin3 := {| magma_op := refa96_op |}.

Lemma refa96_sat2517 : @Equation2517 Fin3 refa96_inst.
Proof. unfold Equation2517, magma_op, refa96_inst, refa96_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa96_not203 : ~ @Equation203 Fin3 refa96_inst.
Proof. unfold Equation203. intro H. specialize (H F3_2). unfold magma_op, refa96_inst, refa96_op in H. discriminate H. Qed.

Lemma refa96_not2256 : ~ @Equation2256 Fin3 refa96_inst.
Proof. unfold Equation2256. intro H. specialize (H F3_2 F3_1). unfold magma_op, refa96_inst, refa96_op in H. discriminate H. Qed.

Lemma refa96_not2263 : ~ @Equation2263 Fin3 refa96_inst.
Proof. unfold Equation2263. intro H. specialize (H F3_2 F3_1). unfold magma_op, refa96_inst, refa96_op in H. discriminate H. Qed.

Lemma refa96_not2266 : ~ @Equation2266 Fin3 refa96_inst.
Proof. unfold Equation2266. intro H. specialize (H F3_2 F3_0). unfold magma_op, refa96_inst, refa96_op in H. discriminate H. Qed.

Lemma refa96_not2293 : ~ @Equation2293 Fin3 refa96_inst.
Proof. unfold Equation2293. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa96_inst, refa96_op in H. discriminate H. Qed.

Lemma refa96_not2300 : ~ @Equation2300 Fin3 refa96_inst.
Proof. unfold Equation2300. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa96_inst, refa96_op in H. discriminate H. Qed.

Lemma refa96_not2303 : ~ @Equation2303 Fin3 refa96_inst.
Proof. unfold Equation2303. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa96_inst, refa96_op in H. discriminate H. Qed.

Lemma refa96_not2330 : ~ @Equation2330 Fin3 refa96_inst.
Proof. unfold Equation2330. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa96_inst, refa96_op in H. discriminate H. Qed.

Lemma refa96_not2449 : ~ @Equation2449 Fin3 refa96_inst.
Proof. unfold Equation2449. intro H. specialize (H F3_2 F3_0). unfold magma_op, refa96_inst, refa96_op in H. discriminate H. Qed.

Lemma refa96_not2533 : ~ @Equation2533 Fin3 refa96_inst.
Proof. unfold Equation2533. intro H. specialize (H F3_2 F3_0). unfold magma_op, refa96_inst, refa96_op in H. discriminate H. Qed.

Lemma refa96_not2709 : ~ @Equation2709 Fin3 refa96_inst.
Proof. unfold Equation2709. intro H. specialize (H F3_2 F3_0). unfold magma_op, refa96_inst, refa96_op in H. discriminate H. Qed.

Lemma refa96_not3065 : ~ @Equation3065 Fin3 refa96_inst.
Proof. unfold Equation3065. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa96_inst, refa96_op in H. discriminate H. Qed.

Lemma refa96_not3115 : ~ @Equation3115 Fin3 refa96_inst.
Proof. unfold Equation3115. intro H. specialize (H F3_2 F3_1). unfold magma_op, refa96_inst, refa96_op in H. discriminate H. Qed.

Lemma refa96_not3519 : ~ @Equation3519 Fin3 refa96_inst.
Proof. unfold Equation3519. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa96_inst, refa96_op in H. discriminate H. Qed.

Lemma refa96_not3749 : ~ @Equation3749 Fin3 refa96_inst.
Proof. unfold Equation3749. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa96_inst, refa96_op in H. discriminate H. Qed.

Lemma refa96_not4070 : ~ @Equation4070 Fin3 refa96_inst.
Proof. unfold Equation4070. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa96_inst, refa96_op in H. discriminate H. Qed.

Lemma refa96_not4128 : ~ @Equation4128 Fin3 refa96_inst.
Proof. unfold Equation4128. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa96_inst, refa96_op in H. discriminate H. Qed.

Lemma refa96_not4320 : ~ @Equation4320 Fin3 refa96_inst.
Proof. unfold Equation4320. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa96_inst, refa96_op in H. discriminate H. Qed.

(** ---- refa97 (Fin3) ---- *)

Definition refa97_op (x y : Fin3) : Fin3 :=
  match x, y with
  | F3_0, F3_0 => F3_0 | F3_0, F3_1 => F3_1 | F3_0, F3_2 => F3_2
  | F3_1, F3_0 => F3_0 | F3_1, F3_1 => F3_0 | F3_1, F3_2 => F3_2
  | F3_2, F3_0 => F3_0 | F3_2, F3_1 => F3_0 | F3_2, F3_2 => F3_1
  end.

#[local] Instance refa97_inst : Magma Fin3 := {| magma_op := refa97_op |}.

Lemma refa97_sat2310 : @Equation2310 Fin3 refa97_inst.
Proof. unfold Equation2310, magma_op, refa97_inst, refa97_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa97_sat2318 : @Equation2318 Fin3 refa97_inst.
Proof. unfold Equation2318, magma_op, refa97_inst, refa97_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa97_sat2351 : @Equation2351 Fin3 refa97_inst.
Proof. unfold Equation2351, magma_op, refa97_inst, refa97_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa97_sat2364 : @Equation2364 Fin3 refa97_inst.
Proof. unfold Equation2364, magma_op, refa97_inst, refa97_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa97_sat2385 : @Equation2385 Fin3 refa97_inst.
Proof. unfold Equation2385, magma_op, refa97_inst, refa97_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa97_sat2530 : @Equation2530 Fin3 refa97_inst.
Proof. unfold Equation2530, magma_op, refa97_inst, refa97_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa97_sat2706 : @Equation2706 Fin3 refa97_inst.
Proof. unfold Equation2706, magma_op, refa97_inst, refa97_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa97_sat2812 : @Equation2812 Fin3 refa97_inst.
Proof. unfold Equation2812, magma_op, refa97_inst, refa97_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa97_sat3458 : @Equation3458 Fin3 refa97_inst.
Proof. unfold Equation3458, magma_op, refa97_inst, refa97_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa97_not2293 : ~ @Equation2293 Fin3 refa97_inst.
Proof. unfold Equation2293. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa97_inst, refa97_op in H. discriminate H. Qed.

Lemma refa97_not2496 : ~ @Equation2496 Fin3 refa97_inst.
Proof. unfold Equation2496. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa97_inst, refa97_op in H. discriminate H. Qed.

Lemma refa97_not2543 : ~ @Equation2543 Fin3 refa97_inst.
Proof. unfold Equation2543. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa97_inst, refa97_op in H. discriminate H. Qed.

Lemma refa97_not2646 : ~ @Equation2646 Fin3 refa97_inst.
Proof. unfold Equation2646. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa97_inst, refa97_op in H. discriminate H. Qed.

Lemma refa97_not2652 : ~ @Equation2652 Fin3 refa97_inst.
Proof. unfold Equation2652. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa97_inst, refa97_op in H. discriminate H. Qed.

Lemma refa97_not2662 : ~ @Equation2662 Fin3 refa97_inst.
Proof. unfold Equation2662. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa97_inst, refa97_op in H. discriminate H. Qed.

Lemma refa97_not2709 : ~ @Equation2709 Fin3 refa97_inst.
Proof. unfold Equation2709. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa97_inst, refa97_op in H. discriminate H. Qed.

Lemma refa97_not3058 : ~ @Equation3058 Fin3 refa97_inst.
Proof. unfold Equation3058. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa97_inst, refa97_op in H. discriminate H. Qed.

Lemma refa97_not3065 : ~ @Equation3065 Fin3 refa97_inst.
Proof. unfold Equation3065. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa97_inst, refa97_op in H. discriminate H. Qed.

Lemma refa97_not3152 : ~ @Equation3152 Fin3 refa97_inst.
Proof. unfold Equation3152. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa97_inst, refa97_op in H. discriminate H. Qed.

Lemma refa97_not3253 : ~ @Equation3253 Fin3 refa97_inst.
Proof. unfold Equation3253. intro H. specialize (H F3_2). unfold magma_op, refa97_inst, refa97_op in H. discriminate H. Qed.

Lemma refa97_not3459 : ~ @Equation3459 Fin3 refa97_inst.
Proof. unfold Equation3459. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa97_inst, refa97_op in H. discriminate H. Qed.

Lemma refa97_not3461 : ~ @Equation3461 Fin3 refa97_inst.
Proof. unfold Equation3461. intro H. specialize (H F3_2 F3_0). unfold magma_op, refa97_inst, refa97_op in H. discriminate H. Qed.

Lemma refa97_not3525 : ~ @Equation3525 Fin3 refa97_inst.
Proof. unfold Equation3525. intro H. specialize (H F3_0 F3_1 F3_2). unfold magma_op, refa97_inst, refa97_op in H. discriminate H. Qed.

Lemma refa97_not3537 : ~ @Equation3537 Fin3 refa97_inst.
Proof. unfold Equation3537. intro H. specialize (H F3_0 F3_1 F3_2). unfold magma_op, refa97_inst, refa97_op in H. discriminate H. Qed.

Lemma refa97_not3659 : ~ @Equation3659 Fin3 refa97_inst.
Proof. unfold Equation3659. intro H. specialize (H F3_2). unfold magma_op, refa97_inst, refa97_op in H. discriminate H. Qed.

Lemma refa97_not4070 : ~ @Equation4070 Fin3 refa97_inst.
Proof. unfold Equation4070. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa97_inst, refa97_op in H. discriminate H. Qed.

Lemma refa97_not4090 : ~ @Equation4090 Fin3 refa97_inst.
Proof. unfold Equation4090. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa97_inst, refa97_op in H. discriminate H. Qed.

Lemma refa97_not4314 : ~ @Equation4314 Fin3 refa97_inst.
Proof. unfold Equation4314. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa97_inst, refa97_op in H. discriminate H. Qed.

Lemma refa97_not4320 : ~ @Equation4320 Fin3 refa97_inst.
Proof. unfold Equation4320. intro H. specialize (H F3_2 F3_1). unfold magma_op, refa97_inst, refa97_op in H. discriminate H. Qed.

Lemma refa97_not4622 : ~ @Equation4622 Fin3 refa97_inst.
Proof. unfold Equation4622. intro H. specialize (H F3_0 F3_1 F3_2). unfold magma_op, refa97_inst, refa97_op in H. discriminate H. Qed.

Lemma refa97_not4631 : ~ @Equation4631 Fin3 refa97_inst.
Proof. unfold Equation4631. intro H. specialize (H F3_1 F3_0 F3_2). unfold magma_op, refa97_inst, refa97_op in H. discriminate H. Qed.

(** ---- refa98 (Fin3) ---- *)

Definition refa98_op (x y : Fin3) : Fin3 :=
  match x, y with
  | F3_0, F3_0 => F3_0 | F3_0, F3_1 => F3_2 | F3_0, F3_2 => F3_1
  | F3_1, F3_0 => F3_0 | F3_1, F3_1 => F3_2 | F3_1, F3_2 => F3_1
  | F3_2, F3_0 => F3_2 | F3_2, F3_1 => F3_2 | F3_2, F3_2 => F3_0
  end.

#[local] Instance refa98_inst : Magma Fin3 := {| magma_op := refa98_op |}.

Lemma refa98_sat1847 : @Equation1847 Fin3 refa98_inst.
Proof. unfold Equation1847, magma_op, refa98_inst, refa98_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa98_sat1887 : @Equation1887 Fin3 refa98_inst.
Proof. unfold Equation1887, magma_op, refa98_inst, refa98_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa98_sat1921 : @Equation1921 Fin3 refa98_inst.
Proof. unfold Equation1921, magma_op, refa98_inst, refa98_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa98_sat3935 : @Equation3935 Fin3 refa98_inst.
Proof. unfold Equation3935, magma_op, refa98_inst, refa98_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa98_sat4023 : @Equation4023 Fin3 refa98_inst.
Proof. unfold Equation4023, magma_op, refa98_inst, refa98_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa98_not1109 : ~ @Equation1109 Fin3 refa98_inst.
Proof. unfold Equation1109. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa98_inst, refa98_op in H. discriminate H. Qed.

Lemma refa98_not1122 : ~ @Equation1122 Fin3 refa98_inst.
Proof. unfold Equation1122. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa98_inst, refa98_op in H. discriminate H. Qed.

Lemma refa98_not1629 : ~ @Equation1629 Fin3 refa98_inst.
Proof. unfold Equation1629. intro H. specialize (H F3_1). unfold magma_op, refa98_inst, refa98_op in H. discriminate H. Qed.

Lemma refa98_not1857 : ~ @Equation1857 Fin3 refa98_inst.
Proof. unfold Equation1857. intro H. specialize (H F3_2 F3_1). unfold magma_op, refa98_inst, refa98_op in H. discriminate H. Qed.

Lemma refa98_not3659 : ~ @Equation3659 Fin3 refa98_inst.
Proof. unfold Equation3659. intro H. specialize (H F3_1). unfold magma_op, refa98_inst, refa98_op in H. discriminate H. Qed.

Lemma refa98_not4065 : ~ @Equation4065 Fin3 refa98_inst.
Proof. unfold Equation4065. intro H. specialize (H F3_2). unfold magma_op, refa98_inst, refa98_op in H. discriminate H. Qed.

Lemma refa98_not4269 : ~ @Equation4269 Fin3 refa98_inst.
Proof. unfold Equation4269. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa98_inst, refa98_op in H. discriminate H. Qed.

Lemma refa98_not4270 : ~ @Equation4270 Fin3 refa98_inst.
Proof. unfold Equation4270. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa98_inst, refa98_op in H. discriminate H. Qed.

Lemma refa98_not4273 : ~ @Equation4273 Fin3 refa98_inst.
Proof. unfold Equation4273. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa98_inst, refa98_op in H. discriminate H. Qed.

Lemma refa98_not4275 : ~ @Equation4275 Fin3 refa98_inst.
Proof. unfold Equation4275. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa98_inst, refa98_op in H. discriminate H. Qed.

Lemma refa98_not4283 : ~ @Equation4283 Fin3 refa98_inst.
Proof. unfold Equation4283. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa98_inst, refa98_op in H. discriminate H. Qed.

Lemma refa98_not4290 : ~ @Equation4290 Fin3 refa98_inst.
Proof. unfold Equation4290. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa98_inst, refa98_op in H. discriminate H. Qed.

Lemma refa98_not4314 : ~ @Equation4314 Fin3 refa98_inst.
Proof. unfold Equation4314. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa98_inst, refa98_op in H. discriminate H. Qed.

Lemma refa98_not4320 : ~ @Equation4320 Fin3 refa98_inst.
Proof. unfold Equation4320. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa98_inst, refa98_op in H. discriminate H. Qed.

Lemma refa98_not4380 : ~ @Equation4380 Fin3 refa98_inst.
Proof. unfold Equation4380. intro H. specialize (H F3_1). unfold magma_op, refa98_inst, refa98_op in H. discriminate H. Qed.

Lemma refa98_not4583 : ~ @Equation4583 Fin3 refa98_inst.
Proof. unfold Equation4583. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa98_inst, refa98_op in H. discriminate H. Qed.

Lemma refa98_not4598 : ~ @Equation4598 Fin3 refa98_inst.
Proof. unfold Equation4598. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa98_inst, refa98_op in H. discriminate H. Qed.

Lemma refa98_not4605 : ~ @Equation4605 Fin3 refa98_inst.
Proof. unfold Equation4605. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa98_inst, refa98_op in H. discriminate H. Qed.

Lemma refa98_not4622 : ~ @Equation4622 Fin3 refa98_inst.
Proof. unfold Equation4622. intro H. specialize (H F3_0 F3_0 F3_1). unfold magma_op, refa98_inst, refa98_op in H. discriminate H. Qed.

Lemma refa98_not4635 : ~ @Equation4635 Fin3 refa98_inst.
Proof. unfold Equation4635. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa98_inst, refa98_op in H. discriminate H. Qed.

Lemma refa98_not4647 : ~ @Equation4647 Fin3 refa98_inst.
Proof. unfold Equation4647. intro H. specialize (H F3_0 F3_0 F3_1). unfold magma_op, refa98_inst, refa98_op in H. discriminate H. Qed.

Lemma refa98_not4656 : ~ @Equation4656 Fin3 refa98_inst.
Proof. unfold Equation4656. intro H. specialize (H F3_0 F3_0 F3_1). unfold magma_op, refa98_inst, refa98_op in H. discriminate H. Qed.

(** ---- refa99 (Fin3) ---- *)

Definition refa99_op (x y : Fin3) : Fin3 :=
  match x, y with
  | F3_0, F3_0 => F3_0 | F3_0, F3_1 => F3_0 | F3_0, F3_2 => F3_0
  | F3_1, F3_0 => F3_1 | F3_1, F3_1 => F3_1 | F3_1, F3_2 => F3_0
  | F3_2, F3_0 => F3_1 | F3_2, F3_1 => F3_0 | F3_2, F3_2 => F3_1
  end.

#[local] Instance refa99_inst : Magma Fin3 := {| magma_op := refa99_op |}.

Lemma refa99_sat3730 : @Equation3730 Fin3 refa99_inst.
Proof. unfold Equation3730, magma_op, refa99_inst, refa99_op. intros x y z w. destruct x, y, z, w; reflexivity. Qed.

Lemma refa99_not3255 : ~ @Equation3255 Fin3 refa99_inst.
Proof. unfold Equation3255. intro H. specialize (H F3_2 F3_0). unfold magma_op, refa99_inst, refa99_op in H. discriminate H. Qed.

Lemma refa99_not3256 : ~ @Equation3256 Fin3 refa99_inst.
Proof. unfold Equation3256. intro H. specialize (H F3_2 F3_0). unfold magma_op, refa99_inst, refa99_op in H. discriminate H. Qed.

Lemma refa99_not3862 : ~ @Equation3862 Fin3 refa99_inst.
Proof. unfold Equation3862. intro H. specialize (H F3_2). unfold magma_op, refa99_inst, refa99_op in H. discriminate H. Qed.

Lemma refa99_not4065 : ~ @Equation4065 Fin3 refa99_inst.
Proof. unfold Equation4065. intro H. specialize (H F3_2). unfold magma_op, refa99_inst, refa99_op in H. discriminate H. Qed.

Lemma refa99_not4269 : ~ @Equation4269 Fin3 refa99_inst.
Proof. unfold Equation4269. intro H. specialize (H F3_2 F3_0). unfold magma_op, refa99_inst, refa99_op in H. discriminate H. Qed.

Lemma refa99_not4314 : ~ @Equation4314 Fin3 refa99_inst.
Proof. unfold Equation4314. intro H. specialize (H F3_2 F3_1). unfold magma_op, refa99_inst, refa99_op in H. discriminate H. Qed.

Lemma refa99_not4583 : ~ @Equation4583 Fin3 refa99_inst.
Proof. unfold Equation4583. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa99_inst, refa99_op in H. discriminate H. Qed.

Lemma refa99_not4598 : ~ @Equation4598 Fin3 refa99_inst.
Proof. unfold Equation4598. intro H. specialize (H F3_2 F3_0). unfold magma_op, refa99_inst, refa99_op in H. discriminate H. Qed.

Lemma refa99_not4629 : ~ @Equation4629 Fin3 refa99_inst.
Proof. unfold Equation4629. intro H. specialize (H F3_2 F3_0). unfold magma_op, refa99_inst, refa99_op in H. discriminate H. Qed.
